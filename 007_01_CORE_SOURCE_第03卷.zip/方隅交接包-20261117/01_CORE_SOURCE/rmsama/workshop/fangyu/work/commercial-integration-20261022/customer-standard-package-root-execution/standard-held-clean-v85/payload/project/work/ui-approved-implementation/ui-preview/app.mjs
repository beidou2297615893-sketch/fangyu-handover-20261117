import {accountConnectionState} from './account-connection-state.mjs';
import {localDay,calendarControl,bindCalendars,collectCustomerIds} from './daily-ui.mjs';
import {helpButton,openAcquisitionHelp} from './pages/acquisition-help.mjs';
import {platformNotices,updatePlatformNotice,createCollectionMonitor,createVerificationActions,createAutomaticVerification} from './platform-notice.mjs';
import './canvas-fit.mjs';
import {activePlatform,platformName,renderPlatformSwitch} from './platform-ui.mjs';
import {setCustomerMediaScope,warmCustomerMedia} from './avatar.mjs';
import {renderWorkflowSummary,bindWorkflowSummary,workflowScope} from './pages/workflow-summary.mjs';
import {openRemoteManagement} from './pages/remote-management.mjs';
import {createBackend} from './backend.mjs';
import * as acquire from './pages/acquire.mjs';
import * as diversifiedAcquisition from './pages/diversified-acquisition.mjs';
import {sourceSelection,interactionScanChoice} from './pages/acquisition-source.mjs';
import * as presets from './pages/presets.mjs';
import * as reply from './pages/reply.mjs';
import * as customers from './pages/customers.mjs';
import {openOutcomeReport} from './pages/customer-outcomes.mjs';
import * as platformAccounts from './pages/accounts.mjs';
import * as rules from './pages/management-rules.mjs';
import * as aiModel from './pages/ai-model.mjs';
import * as contentOperations from './pages/content-operations.mjs';
import {createDeviceReconnect} from './device-reconnect.mjs';
import {createConnectionRecovery} from './connection-recovery.mjs';
import * as tone from './pages/management-tone.mjs';
import {customerControls,customerQuery,actorMatches as customerActorMatches} from './pages/customers-data.mjs';
import {openToneTools,openSettings,openRuleFiles,openCentralRuleFiles,localDates,versionLabel} from './pages/management-tools.mjs';
import {createPaneScroll} from './pane-scroll.mjs';
const app=document.getElementById('app');
const initialPage=location.hash.slice(1)||'login';
const backend=createBackend();
const state={acquisitionDay:localDay(),activePlatform:'xiaohongshu',platformWorkspaces:{},page:'login',store:'',user:'',scenario:'normal',connection:'loading',session:null,stores:[],catalog:{search:[],intent:[]},selection:null,capabilities:{presets:false},rememberedUsername:'',busy:false,platform:null,platformLoading:false,platformError:'',platformActionsReady:true};
const paneScroll=createPaneScroll(app,()=>state);
function showPlatformNotice(){updatePlatformNotice(state,document.getElementById('platform-notice-host'),id=>{
  if(id!==(state.activePlatform||'xiaohongshu'))switchPlatform(id);
  if(id===(state.activePlatform||'xiaohongshu'))navigate('accounts');
},verificationAction);automaticVerification.sync();}
const verificationAction=createVerificationActions({state,open:id=>backend.openAcquisitionVerification(id),resume:id=>backend.resumeVerifiedAcquisition(id),changed:showPlatformNotice,blocked:()=>backend.unconfirmed||Boolean(state.pendingAction?.unconfirmed),notify:toast});
const automaticVerification=createAutomaticVerification({state,act:verificationAction,blocked:()=>backend.unconfirmed||Boolean(state.pendingAction?.unconfirmed)});
const collectionMonitor=createCollectionMonitor({state,read:data=>backend.platform(data),changed:showPlatformNotice});
const pages={acquire:diversifiedAcquisition.keywordPage,diversified:diversifiedAcquisition,presets,reply,customers,rules,tone,aiModel,content:contentOperations,accounts:platformAccounts};
const titles={diversified:['多样化获客','从指定来源发现真实租房需求'],content:['内容运营','从账号人设到内容复盘'],acquire:['获客截流','发现真实租房需求'],reply:['意向回复','从社交平台，看见真实的租房需求'],customers:['客户工作台',''],presets:['门店获客预设','确认门店资料，配套搜索与客户判断规则'],rules:['获客规则',''],tone:['回复口吻',''],aiModel:['AI 模型','查看和修改公司使用的 DeepSeek 模型'],accounts:['平台与账号','软件自动准备，你只需登录平台账号']};
let cleanup,toastTimer,lastFocus;
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const icon=(file,cls='')=>`<img class="icon ${cls}" src="/assets/${file}" alt="">`;
function navigate(page){if(!titles[page]&&page!=='login')page='acquire';if(state.connection!=='preview'&&!state.session)page='login';if(page==='reply'&&state.page!=='reply'&&state.replyLive)state.replyLive.groupBy='post';if(page==='aiModel'&&state.page!==page&&state.aiModelSettings&&!state.aiModelSettings.saving)state.aiModelSettings.status='idle';if(state.page!==page&&(state.page==='diversified'||page==='diversified'))document.getElementById('modal')?.close();state.page=page;document.title=(titles[page]?.[0]||'员工登录')+' · 方隅工作台';if(location.hash!=='#'+page)history.replaceState(null,'','#'+page);render();window.scrollTo({top:0,behavior:'instant'});}
function toast(text){clearTimeout(toastTimer);const n=document.getElementById('toast');n.textContent=text;n.hidden=false;toastTimer=setTimeout(()=>n.hidden=true,3500);}
function update(mutator){const focused=document.activeElement;const key=focused?.id;const attr=['data-customer-sort','data-customer-filter','data-customer-filter-value','data-customer-page','data-customer-row','data-customer-check','data-customer-check-all','data-customer-action','data-customer-export','data-customer-evidence','data-customer-source'].find(name=>focused?.hasAttribute?.(name));const selector=key?'#'+CSS.escape(key):attr?`[${attr}="${CSS.escape(focused.getAttribute(attr))}"]`:'';const start=focused?.selectionStart;const end=focused?.selectionEnd;mutator(state);if(render()===false)return;if(selector){const n=document.querySelector(selector);if(n){n.focus({preventScroll:true});if(typeof start==='number'&&n.setSelectionRange){try{n.setSelectionRange(start,end);}catch{}}}}}
function modal({title,html,onConfirm,confirmLabel='确定',canClose}){
  const d=document.getElementById('modal'),owner={};d.__modalOwner=owner;if(!d.open)lastFocus=document.activeElement;const restoreFocus=lastFocus;
  const current=()=>d.__modalOwner===owner;
  const close=()=>{if(current()&&canClose?.()!==false)d.close();};
  d.innerHTML=`<div class="modal-header"><h2 id="modal-title">${esc(title)}</h2><button class="modal-close" aria-label="关闭">${icon('tabler-x.svg')}</button></div><div class="modal-content">${html}</div><div class="modal-actions"><button class="modal-cancel">${onConfirm?'取消':'关闭'}</button>${onConfirm?`<button class="primary modal-confirm">${esc(confirmLabel)}</button>`:''}</div>`;
  d.querySelector('.modal-close').onclick=close;d.querySelector('.modal-cancel').onclick=close;
  if(onConfirm)d.querySelector('.modal-confirm').onclick=async()=>{if(!current())return;const result=await onConfirm();if(result!==false)close();};
  if(!d.open)d.showModal();
  d.oncancel=e=>{if(!current()||canClose?.()===false)e.preventDefault();};
  d.onclose=()=>current()&&restoreFocus?.isConnected&&restoreFocus.focus();
  d.onclick=e=>{if(e.target===d){const r=d.getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)close();}};return d;
}
const viewModel=state;
let runtimeMetadataGeneration=0;
function updateRuntimeLabels(){
  const dates=localDates();document.querySelectorAll('[data-local-date]').forEach(node=>{node.textContent=dates[node.dataset.localDate]||dates.iso;});
  document.querySelectorAll('[data-runtime-version]').forEach(node=>{node.textContent=versionLabel(state);node.title=state.runtimeMetadata?.value?.release||state.runtimeMetadata?.error||'';});
}
async function refreshRuntimeStatus(){
  if(state.connection==='preview')return false;const generation=++runtimeMetadataGeneration;
  state.runtimeMetadata={status:'loading'};
  try{const value=await backend.runtimeStatus();if(generation!==runtimeMetadataGeneration)return false;state.runtimeMetadata={status:'ready',value};return true;}
  catch(error){if(generation===runtimeMetadataGeneration)state.runtimeMetadata={status:'error',error:error.message};return false;}
  finally{if(generation===runtimeMetadataGeneration)updateRuntimeLabels();}
}
let aiRuleGeneration=0;
function invalidateSensitiveViews(){
  state.authEpoch=(state.authEpoch||0)+1;aiRuleGeneration++;
  state.aiWorkbench=null;state.remoteManagementTool=null;state.contentWorkspace=null;state.keywordEffectUI=null;state.outcomesUI=null;state.publicContactsUI=null;
  document.getElementById('modal')?.close();
  setCustomerMediaScope('');
}
async function refreshAIRules(force=false){
  if(state.connection!=='connected'||!state.session||!state.storeId)return;
  const actor={username:state.user,storeId:state.storeId},scope=workflowScope(state);
  if(!force&&state.aiWorkbench?.scope===scope)return;
  const generation=++aiRuleGeneration;
  state.aiWorkbench={actor,scope,status:'loading',rules:state.aiWorkbench?.scope===scope?state.aiWorkbench.rules:null,readiness:null,error:''};
  const owns=()=>generation===aiRuleGeneration&&state.connection==='connected'&&state.session&&workflowScope(state)===scope;
  const results=await Promise.allSettled([backend.aiReadinessRead({storeId:actor.storeId}),backend.aiRulesRead({storeId:actor.storeId})]);
  if(!owns())return;
  const value=state.aiWorkbench,errors=[];
  for(const [index,result]of results.entries()){
    if(result.status==='rejected'){errors.push(result.reason?.message||'配置暂未读取');continue;}
    const data=result.value?.[index===0?'readiness':'rules'];
    if(data?.actor?.username!==actor.username||data?.actor?.storeId!==actor.storeId){errors.push('配置归属已变化，请刷新');continue;}
    value[index===0?'readiness':'rules']=data;
  }
  value.status=errors.length?'partial':'ready';value.error=errors.join('；');
  // Do not replace the active reply input while an employee is typing.
  if(!document.activeElement?.matches('textarea,input,select')&&!document.getElementById('modal')?.open)render();
}
function acceptBootstrap(result){
  invalidateSensitiveViews();
  const previousActor=JSON.stringify([state.user,state.storeId||'',state.session?.user?.role||'']);
  state.connection='connected';state.session=result.session||null;state.user=result.session?.user?.username||'';
  state.rememberedUsername=result.rememberedUsername||'';state.stores=Array.isArray(result.stores)?result.stores:[];
  state.workspaceError=result.workspaceError||null;
  state.catalog={search:Array.isArray(result.catalog?.search)?result.catalog.search:[],intent:Array.isArray(result.catalog?.intent)?result.catalog.intent:[]};state.selection=result.selection||null;state.materials=result.materials||null;state.assessmentReport=result.assessment||null;state.capabilities=result.capabilities||{presets:false};state.notice=result.notice||'';
  const store=state.stores.find(item=>item.id===state.selection?.storeId);
  state.storeId=store?.id||'';state.store=store?.name||'';
  state.customerView=null;state.customerDetail=null;
  const old=state.presets;state.presets={search:state.selection?.searchPresetId||state.catalog.search[0]?.id||'',intent:state.selection?.intentPresetId||state.catalog.intent[0]?.id||'',tab:old?.tab||'presets',showWords:old?.showWords||false,showRules:old?.showRules||false,materialKey:state.materials?.currentSelection?.materialKey||'',keywordIds:[...(state.materials?.currentSelection?.selectedKeywordIds||[])]};
  if(state.acquire&&store)state.acquire.region=store.region;
  if(previousActor!==JSON.stringify([state.user,state.storeId,state.session?.user?.role||''])){state.platformWorkspaces={};state.platform=null;state.platformError='';state.platformErrorCode='';state.platformAccountSelections={};state.acquisitionAttempt=null;state.customerView=null;state.customerDetail=null;state.customerSelectionFilter='';state.replyLive=null;state.replyDelivery=null;state.replyBatchIds=null;state.customerHandoff=null;state.toneTool=null;state.tonePreferences=null;state.tonePreferencesError='';state.tonePreferencesLoading=false;state.toneDraft=null;toneReadGeneration++;toneScopeGeneration++;state.tonePreferenceReadActor='' ;state.settingsTool=null;state.workspaceRefreshError='';document.getElementById('modal')?.close();}
}
function showActionError(error){if(['STORE_REQUIRED','STORE_FORBIDDEN','BUSINESS_RULES_FORBIDDEN'].includes(error?.code)){invalidateSensitiveViews();state.platformWorkspaces={};state.platform=null;state.customerView=null;state.customerDetail=null;state.replyLive=null;state.replyDelivery=null;state.rulesPage=null;state.storeId='';state.store='';state.customerLoading=false;state.workspaceError={code:error.code,message:'门店权限已变化，请重新加载门店资料。'};render();}if(['AUTH_REQUIRED','unauthenticated','session_expired'].includes(error?.code)){invalidateSensitiveViews();state.customerHandoff=null;state.toneTool=null;state.tonePreferences=null;state.tonePreferencesError='';state.tonePreferencesLoading=false;state.toneDraft=null;toneReadGeneration++;toneScopeGeneration++;state.tonePreferenceReadActor='' ;state.settingsTool=null;state.workspaceRefreshError='';document.getElementById('modal')?.close();state.session=null;state.user='';state.stores=[];state.store='';state.storeId='';state.capabilities={presets:false};navigate('login');}toast(error?.message||'操作未完成，请稍后重试。');}
async function reloadWorkspace(){
  if(state.busy)return false;const expected=actorKey(),attempt={};state.workspaceRefreshAttempt=attempt;state.busy=true;render();
  try{const result=await backend.bootstrap();if(expected!==actorKey())return false;acceptBootstrap(result);state.workspaceRefreshError='';if(!state.session)navigate('login');toast(state.notice||'门店资料已重新加载。');return true;}
  catch(error){if(expected===actorKey()){state.workspaceRefreshError=error.message;showActionError(error);}return false;}
  finally{if(state.workspaceRefreshAttempt===attempt){state.workspaceRefreshAttempt=null;state.busy=false;render();}}
}
function finishApplied(){
  const store=state.stores.find(item=>item.id===state.storeId),search=state.catalog.search.find(item=>item.id===state.presets.search),intent=state.catalog.intent.find(item=>item.id===state.presets.intent);
  state.acquire??={region:store?.region||'',time:'最近30天',platforms:['小红书','抖音'],status:'idle',stage:0,tick:0,read:0,added:0,analyzed:0,duplicates:0,records:[]};
  if(['running','paused'].includes(state.acquire.status)){state.acquire.records.unshift({text:'已应用门店预设，本次采集演示结束',status:'已停止'});Object.assign(state.acquire,{status:'idle',stage:0,tick:0,read:0,added:0,analyzed:0,duplicates:0,run:null});}
  Object.assign(state.acquire,{region:store?.region||'',searchPreset:search?.name||'',intentPreset:intent?.name||''});state.customerView=null;state.customerDetail=null;navigate('acquire');toast(state.assessmentReport?.status==='retry_required'?'门店预设已应用；客户重新评估待重试，可在判断规则中重新评估。':'中央配置已加载；选词和显示偏好已保存在本机，点击开始后才会采集');
}
async function verifyPending(){
  if(backend.interactionPending)return verifySourceInteractions();
  let pending=state.pendingAction;
  acceptBootstrap(await backend.bootstrap());
  if(pending?.platformOperation){
    if(state.session&&(state.user!==pending.username||state.storeId!==pending.storeId)){state.pendingAction=null;state.platform=null;toast('账号或门店已变化，请在原账号与门店核对上次操作。');if(state.user!==pending.username)navigate('login');return;}
    if(!state.session){state.pendingAction=null;navigate('login');return;}
    const actor=actorKey(),result=await backend.platform({platform:activePlatform(state)});if(actor!==actorKey())return;
    if(!result.platform)throw new Error('真实平台状态尚未确认。');
    if(!platformActorMatches(result.platform,actor)){await reconcilePlatformActor(actor);return;}
    acceptPlatformSnapshot(result.platform);state.platformError='';state.platformErrorCode='';
    if(pending.action==='account_connect'){
      const account=result.platform.accounts?.find(row=>row.id===pending.accountId);
      if(account?.loginJobId){
        const recovered=await backend.accountJob(account.loginJobId);
        if(actor!==actorKey()||!platformActorMatches(recovered.platform,actor)||recovered.job?.id!==account.loginJobId)return null;
        state.pendingAction=null;return {...recovered,platform:result.platform};
      }
      state.pendingAction=null;
      toast('暂时没有连上登录窗口，账号已保留，请稍后再点一键登录。');return null;
    }
    if(pending.action==='acquisition_start'&&state.pendingAction?.action==='acquisition_start')pending=state.pendingAction;
    if(pending.action==='acquisition_start'){
      const last=result.platform.lastRequest;
      if(last?.requestId!==pending.requestId||!['accepted','rejected'].includes(last.state)){pending.unconfirmed=true;state.pendingAction=pending;if(state.acquisitionAttempt)state.acquisitionAttempt.unconfirmed=true;toast(last?.requestId===pending.requestId&&last.message?last.message:'上次采集结果尚未确认，请继续核对；原操作编号和条件已保留。');return;}
      state.pendingAction=null;state.acquisitionAttempt=null;toast(last.state==='accepted'?'已核对上次采集已受理，当前进度以真实回执为准。':'已核对上次采集未受理：'+(last.message||'请确认条件后再开始。'));return;
    }
    state.pendingAction=null;toast('已核对当前真实状态，请确认后继续；未重复提交操作。');return;
  }
  state.pendingAction=null;
  if(pending?.action!=='login'&&pending?.username&&state.session&&state.user!==pending.username){state.loginError='账号状态已变化，请重新登录后核对门店预设。';navigate('login');return;}
  if(pending?.action==='login'){
    if(state.session?.user?.username===pending.username){state.loginDraft=undefined;state.loginError='';navigate('acquire');toast('已核对登录成功');}
    else{state.loginError=state.session?'已核对：当前仍为账号 '+state.user+'，本次登录尚未确认，请重新登录。':'已核对：尚未登录，请重新输入密码后尝试。';navigate('login');}
  }else if(pending?.action==='apply_preset'){
    const saved=state.selection,choice=pending.choice;
    if(saved?.storeId===choice.storeId&&saved.searchPresetId===choice.searchPresetId&&saved.intentPresetId===choice.intentPresetId&&saved.revision>choice.expectedRevision)finishApplied();
    else{if(!state.session)navigate('login');toast('已载入当前预设，请确认选择后再应用。');}
  }else if(pending?.action==='logout'){
    if(!state.session){state.loginDraft=undefined;navigate('login');toast('已核对退出登录');}
    else toast('已核对：账号仍在登录，可重新退出。');
  }else{if(!state.session)navigate('login');toast('已载入当前门店与预设，请确认后继续。');}
}
async function recoverAction(error){
  if(error?.code==='RESULT_UNCONFIRMED'){
    if(state.pendingAction)state.pendingAction.unconfirmed=true;
    toast('操作结果尚未确认，正在核对，请稍候…');
    try{return await verifyPending();}catch(failure){if(failure.code==='AUTH_REQUIRED')showActionError(failure);state.loginError='连接暂时中断，账号与本次进度已保留。';toast('连接暂时中断，软件会保留账号和本次进度。');}
  }else if(error?.code==='PRESET_REVISION_CONFLICT'){
    state.pendingAction=null;
    try{acceptBootstrap(await backend.bootstrap());toast('预设已在其他窗口变更，已载入最新内容，请重新选择后应用。');}catch(failure){showActionError(failure);}
  }else{state.pendingAction=null;showActionError(error);}
}
async function selectStore(storeId){
  if(state.busy)return;state.busy=true;state.storeSwitchTarget=storeId;render();
  try{if(backend.unconfirmed||state.pendingAction?.unconfirmed){await verifyPending();return;}state.pendingAction={action:'select_store',username:state.user};acceptBootstrap(await backend.selectStore(storeId));state.pendingAction=null;}
  catch(error){await recoverAction(error);}
  finally{state.storeSwitchTarget=null;state.busy=false;render();}
}
async function applyPreset(){
  if(state.busy||!state.capabilities.presets)return;
  const choice={storeId:state.storeId,searchPresetId:state.presets.search,intentPresetId:state.presets.intent,expectedRevision:state.selection?.revision};
  if(state.presets.materialKey&&!state.materials?.currentSelection?.automaticProfile){Object.assign(choice,{materialKey:state.presets.materialKey,keywordIds:[...(state.presets.keywordIds||[])],expectedMaterialRevision:state.materials?.currentSelection?.revision||0,expectedCatalogDigest:state.materials?.digest,confirmMaterialBinding:true});}
  state.busy=true;render();
  try{if(backend.unconfirmed||state.pendingAction?.unconfirmed){await verifyPending();return;}state.pendingAction={action:'apply_preset',choice,username:state.user};acceptBootstrap(await backend.applyPreset(choice));state.pendingAction=null;finishApplied();}
  catch(error){await recoverAction(error);}
  finally{state.busy=false;render();}
}
async function refreshAssessments(){
  if(state.busy||!state.session||!state.selection?.applied?.rentalAssessmentEnabled)return;
  state.busy=true;render();
  try{if(backend.unconfirmed||state.pendingAction?.unconfirmed){await verifyPending();return;}const actor=actorKey();state.pendingAction={action:'refresh_assessments',username:state.user};const result=await backend.refreshAssessments({storeId:state.storeId,expectedRevision:state.selection.revision});if(actor!==actorKey())return;acceptBootstrap(result);state.pendingAction=null;state.customerView=null;state.customerDetail=null;toast('现有客户已按当前租房与预算规则重新评估；原评级保留在历史中。');}
  catch(error){await recoverAction(error);}
  finally{state.busy=false;render();}
}
async function logout(){
  if(state.busy)return false;invalidateSensitiveViews();state.busy=true;
  try{if(backend.unconfirmed||state.pendingAction?.unconfirmed){await verifyPending();return !state.session;}state.pendingAction={action:'logout',username:state.user};acceptBootstrap(await backend.logout());state.pendingAction=null;state.loginDraft=undefined;state.acquire=undefined;state.reply=undefined;state.customers=undefined;navigate('login');if(state.notice)toast(state.notice);return true;}
  catch(error){await recoverAction(error);return !state.session;}
  finally{state.busy=false;render();}
}
let platformTimer,platformScope='',platformGeneration=0,platformFlight,manualPlatformGeneration=0;
const actorKey=()=>JSON.stringify([state.authEpoch||0,state.user,state.storeId||'',activePlatform(state)]);
const reconnectExistingDevice=createDeviceReconnect({state,prepare:data=>runPlatformOperation('platform_prepare',data),hasUnconfirmed:()=>Boolean(backend.unconfirmed||state.pendingAction?.unconfirmed||state.acquisitionAttempt?.unconfirmed)});
const recoverConnection=createConnectionRecovery({state,scope:actorKey,runtimeStatus:()=>backend.runtimeStatus(),refresh:refreshPlatform,prepare:preparePlatform,hasUnconfirmed:()=>Boolean(backend.unconfirmed||state.pendingAction?.unconfirmed||state.acquisitionAttempt?.unconfirmed),verifyPending,render});
function acceptPlatformSnapshot(platform){
  state.sourceInteractionPending=backend.interactionPending;
  warmCustomerMedia(platform?.acquisition?.recent,workflowScope(state));
  if(state.page!=='content'&&state.acquisitionDay&&(!state.acquisitionDaily||state.acquisitionDaily.scope!==actorKey()||state.acquisitionDaily.count!==acquisitionDaySignature(platform))&&!state.acquisitionDailyLoading)queueMicrotask(readAcquisitionDays);
  state.platform=platform;state.platformSnapshotScope=actorKey();if(platform?.device?.state==='online')state.deviceReconnectError='';showPlatformNotice();collectionMonitor.sync();queueMicrotask(()=>reconnectExistingDevice().catch(error=>{state.deviceReconnectError=error.message;}));const last=platform?.lastRequest;
  if(!last?.requestId||!['submitted','unconfirmed'].includes(last.state))return;
  if(state.acquisitionAttempt?.payload?.requestId!==last.requestId){
    const conditions=last.conditions&&typeof last.conditions==='object'?last.conditions:{};
    state.acquisitionAttempt={actor:actorKey(),payload:{...conditions,requestId:last.requestId},unconfirmed:true,recovered:true};
    state.acquire??={};state.acquire.region=typeof conditions.region==='string'?conditions.region:'';state.acquire.time=typeof conditions.time==='string'?conditions.time:'';state.acquire.selectedPlatform=conditions.platform||'';
    if(conditions.platform&&conditions.accountId){state.platformAccountSelections??={};state.platformAccountSelections[conditions.platform]=conditions.accountId;}
  }else state.acquisitionAttempt.unconfirmed=true;
  state.pendingAction={action:'acquisition_start',platformOperation:true,username:state.user,storeId:state.storeId,requestId:last.requestId,unconfirmed:true};
}
function platformActorMatches(platform,expected=actorKey()){return Boolean(platform?.actor&&JSON.stringify([state.authEpoch||0,platform.actor.username,platform.actor.storeId||'',activePlatform(state)])===expected);}
async function reconcilePlatformActor(expected){
  if(actorKey()!==expected)return;
  state.platform=null;state.platformError='账号或门店状态已变化，正在重新核对身份。';document.getElementById('modal')?.close();
  try{const boot=await backend.bootstrap();if(actorKey()!==expected)return;acceptBootstrap(boot);state.pendingAction=null;navigate(state.session?state.page:'login');toast('账号或门店状态已变化，请确认当前身份后继续。');}
  catch(error){if(actorKey()===expected){state.platformError=error.message;showActionError(error);}}
}
function platformSnapshotCurrent(){return state.platformSnapshotScope===actorKey()&&platformActorMatches(state.platform);}
// Content shares the scoped read path, but only accounts/acquire schedule polling.
function pollingScope(){return state.connection==='connected'&&state.session&&!state.connectionRecovering&&['accounts','acquire','diversified','content'].includes(state.page)&&(state.page!=='content'||state.storeId)&&document.visibilityState!=='hidden'?actorKey()+'|'+state.page:'';}
async function refreshPlatform({manual=false}={}){
  if(manual){
    if(state.connection!=='connected'||!state.session)return null;
    const expected=actorKey(),attempt=++manualPlatformGeneration,generation=platformGeneration;
    const current=()=>expected===actorKey()&&attempt===manualPlatformGeneration&&generation===platformGeneration;
    state.platformLoading=true;if(state.page==='content')render();
    try{const result=await backend.platform({platform:activePlatform(state)});if(!current())return null;if(!result?.platform)throw new Error('平台状态返回不完整，请稍后核对。');if(!platformActorMatches(result.platform,expected)){await reconcilePlatformActor(expected);return null;}acceptPlatformSnapshot(result.platform);state.platformError='';state.platformErrorCode='';state.platformUpdatedAt=Date.now();return result.platform;}
    catch(error){if(current()){state.platformError=error.message;state.platformErrorCode=error.code||'request_failed';state.connectionRecoveryMessage='';if(error.code==='AUTH_REQUIRED')showActionError(error);}return null;}
    finally{if(current()){state.platformLoading=false;render();}}
  }
  const scope=pollingScope();if(!scope)return null;
  if(platformFlight?.scope===scope&&platformFlight.generation===platformGeneration)return platformFlight.promise;
  const generation=platformGeneration,actor=actorKey();
  state.platformLoading=true;if(!state.platform||state.page==='content')render();
  const promise=(async()=>{
    try{
      const result=await backend.platform({platform:activePlatform(state)});
      if(generation!==platformGeneration||scope!==pollingScope())return null;
      if(!result?.platform||typeof result.platform!=='object')throw new Error('平台状态返回不完整，请稍后核对。');
      if(!platformActorMatches(result.platform,actor)){await reconcilePlatformActor(actor);return null;}
      acceptPlatformSnapshot(result.platform);state.platformError='';state.platformErrorCode='';state.platformUpdatedAt=Date.now();return result.platform;
    }catch(error){
      if(generation!==platformGeneration||scope!==pollingScope())return null;
      state.platformError=error.message||'平台状态暂未更新。';state.platformErrorCode=error.code||'request_failed';state.connectionRecoveryMessage='';
      if(error.code==='AUTH_REQUIRED')showActionError(error);
      return null;
    }finally{
      if(platformFlight?.promise===promise)platformFlight=null;
      if(generation===platformGeneration&&scope===pollingScope()){
        state.platformLoading=false;if(!document.activeElement?.matches('#page-content select,#page-content input'))render();clearTimeout(platformTimer);
        if(state.page!=='content')platformTimer=setTimeout(()=>refreshPlatform(),state.platformError?7000:3500);
      }
    }
  })();
  platformFlight={scope,generation,promise};return promise;
}
function syncPlatformPolling(){
  const scope=pollingScope();if(scope===platformScope)return;
  clearTimeout(platformTimer);platformScope=scope;platformGeneration++;state.platformLoading=false;
  if(scope&&(state.page!=='content'||!platformSnapshotCurrent()))queueMicrotask(()=>{if(scope===pollingScope())refreshPlatform();});
}
let customerScope='',customerGeneration=0,customerDetailGeneration=0,customerTimer,customerResolve,customerFlight,customerFlightKey='';
let customerSearchCompositionActor='',customerRenderPending=false;
const customerActor=()=>({username:state.user,storeId:state.storeId});
const customerActive=()=>state.connection==='connected'&&state.session&&state.page==='customers';
const interactionCustomerScope=()=>JSON.stringify([state.authEpoch||0,state.session?.user?.tenant_id||'',state.user,state.session?.user?.role||'',state.storeId||'',activePlatform(state)]);
function interactionCustomerLink(id,{loading=false}={}){
  const detail=state.customerDetail,link=detail?.interactionLink;
  return Boolean(state.session&&state.session.user?.username===state.user&&state.storeId&&/^[a-f0-9]{64}$/.test(id||'')
    &&customerActorMatches(state,detail)&&(detail.status==='ready'||loading&&detail.status==='loading')
    &&detail.id===id&&(detail.status==='loading'||detail.item?.id===id&&detail.item.platform===activePlatform(state))
    &&customerControls(state).selectedId===id&&link?.customerId===id&&link.username===state.user
    &&link.storeId===state.storeId&&link.platform===activePlatform(state)&&link.authEpoch===(state.authEpoch||0)
    &&link.role===(state.session.user.role||'')&&link.tenantId===(state.session.user.tenant_id||''))?link:null;
}
function clearInvalidInteractionCustomer(){
  const detail=state.customerDetail;
  if(!detail?.interactionLink||interactionCustomerLink(detail.id,{loading:true}))return;
  const controls=customerControls(state);if(controls.selectedId===detail.id)controls.selectedId='';
  state.customerDetail=null;customerDetailGeneration++;
}
function setCustomerSearchComposing(value){
  customerSearchCompositionActor=value&&customerActive()?actorKey():'';
  if(!customerSearchCompositionActor&&customerRenderPending){customerRenderPending=false;update(()=>{});}
}
async function loadCustomers(query=customerQuery(state),{background=false,force=false}={}){
  clearInvalidInteractionCustomer();
  if(state.connection!=='connected'||!state.session||!state.storeId||(!background&&!customerActive()))return null;
  const actor=actorKey(),scope=interactionCustomerScope(),params={...customerQuery(state),...query},key=scope+'|'+JSON.stringify(params);
  if(!force&&customerFlight&&customerFlightKey===key)return customerFlight;
  const cachedView=state.customerView,stamp=acquisitionDaySignature(state.platform);
  if(!force&&cachedView?.readScope===scope&&customerActorMatches(state,cachedView)&&cachedView.status==='ready'&&JSON.stringify(cachedView.requestQuery)===JSON.stringify(params)&&Date.now()-(cachedView.loadedAt||0)<10000&&cachedView.acquisitionSignature===stamp)return null;
  const generation=++customerGeneration,controls=customerControls(state),selectionFilter=JSON.stringify([params.query,params.filter,params.review||'all',params.acquiredDate||'',params.leaseGroup||'all']);
  const owns=()=>generation===customerGeneration&&actor===actorKey()&&scope===interactionCustomerScope()&&state.connection==='connected'&&Boolean(state.session);
  if(state.customerSelectionFilter&&state.customerSelectionFilter!==selectionFilter){controls.checkedIds=[];controls.selectedId='';state.customerDetail=null;}
  state.customerSelectionFilter=selectionFilter;
  if(!customerActorMatches(state,state.customerView)||state.customerView.status==='error')state.customerView={actor:customerActor(),status:'loading',items:[],stats:{}};
  state.customerLoading=true;if(customerActive())update(()=>{});
  clearTimeout(customerTimer);customerResolve?.(null);
  const promise=new Promise(resolve=>{
    customerResolve=resolve;
    customerTimer=setTimeout(async()=>{
      try{
        if(state.capabilities.customers!==true)throw new Error('客户功能尚未装入当前后台，请正常重开已验证的工作台版本。');
        const result=await backend.customers(params);if(!owns())return;
        if(!customerActorMatches(state,result.customers))throw new Error('客户范围回执不一致，请重新加载。');
        state.customerView={...result.customers,status:'ready',readScope:scope,requestQuery:{...params,page:result.customers.page||1},loadedAt:Date.now(),acquisitionSignature:stamp};
        warmCustomerMedia(result.customers.items,workflowScope(state));
        controls.page=result.customers.page||1;if(!result.customers.items?.some(row=>row.id===controls.selectedId)&&!interactionCustomerLink(controls.selectedId,{loading:true}))controls.selectedId='';
        if(customerActive()&&controls.selectedId)loadCustomerDetail(controls.selectedId);else state.customerDetail=null;
      }catch(error){if(owns()){
        if(customerActorMatches(state,state.customerView)&&state.customerView.status==='ready'&&['timeout','connection_failed'].includes(error.code))state.customerView={...state.customerView,error:error.message};
        else{state.customerView={actor:customerActor(),status:'error',items:[],stats:{},error:error.message};state.customerDetail=null;controls.selectedId='';controls.checkedIds=[];}
        if(customerActive()||error.code==='AUTH_REQUIRED')showActionError(error);
      }}finally{
        clearInvalidInteractionCustomer();
        if(owns()){state.customerLoading=false;if(customerActive())update(()=>{});}
        if(customerResolve===resolve)customerResolve=null;resolve(null);
      }
    },background?0:120);
  });
  customerFlight=promise;customerFlightKey=key;
  try{return await promise;}finally{if(customerFlight===promise){customerFlight=null;customerFlightKey='';}}
}
async function selectAllCustomers(checked){
  const controls=customerControls(state);if(!checked){update(()=>{controls.checkedIds=[];});return;}
  if(state.customerLoading||state.customerSelectingAll||!customerActive())return;
  const actor=actorKey(),query=customerQuery(state),signature=JSON.stringify(query);
  const valid=()=>customerActive()&&actorKey()===actor&&JSON.stringify(customerQuery(state))===signature;
  state.customerSelectingAll=true;update(()=>{});
  try{const ids=await collectCustomerIds({query,valid,read:async params=>{
    const r=await backend.customers(params);if(!customerActorMatches(state,r.customers))throw Error('客户范围已变化，请重新全选。');return r.customers;
  }});if(valid()){controls.checkedIds=ids;toast(`已选择当前筛选的全部 ${ids.length} 位客户`);}}
  catch(error){if(valid())toast(error.message);}
  finally{state.customerSelectingAll=false;if(actorKey()===actor)update(()=>{});}
}
async function loadCustomerDetail(id){
  clearInvalidInteractionCustomer();
  const actor=actorKey(),scope=interactionCustomerScope(),generation=++customerDetailGeneration,link=interactionCustomerLink(id,{loading:true});
  if(!customerActive()||!customerActorMatches(state,state.customerView)||!state.customerView.items?.some(row=>row.id===id)&&!link)return null;
  state.customerDetail={actor:customerActor(),id,status:'loading',...(link?{interactionLink:{...link}}:{})};update(()=>{});
  try{
    const result=await backend.customerDetail(id,{platform:activePlatform(state)});
    if(generation!==customerDetailGeneration||actor!==actorKey()||scope!==interactionCustomerScope()||!customerActive()||customerControls(state).selectedId!==id)return null;
    if(!customerActorMatches(state,result.customer)){
      await reconcilePlatformActor(actor);
      if(generation!==customerDetailGeneration||actor!==actorKey()||scope!==interactionCustomerScope()||!customerActive()||customerControls(state).selectedId!==id)return null;
      throw new Error('客户详情范围回执不一致，请重新选择客户。');
    }
    if(result.customer.id!==id||result.customer.item?.id!==id||link&&result.customer.item.platform!==activePlatform(state))throw new Error('客户详情回执不一致，请重新选择客户。');
    state.customerDetail={...result.customer,status:'ready',...(link?{interactionLink:{...link}}:{})};
    warmCustomerMedia([result.customer.item],workflowScope(state));
  }catch(error){
    if(generation===customerDetailGeneration&&actor===actorKey()&&scope===interactionCustomerScope()&&customerActive()){state.customerDetail={actor:customerActor(),id,status:'error',error:error.message};showActionError(error);}
  }finally{clearInvalidInteractionCustomer();if(generation===customerDetailGeneration&&actor===actorKey()&&scope===interactionCustomerScope()&&customerActive())update(()=>{});}
}
function syncCustomerLoading(){
  const scope=customerActive()?actorKey():'';if(scope===customerScope)return;
  customerScope=scope;customerDetailGeneration++;
  if(scope)queueMicrotask(()=>{if(customerActive()&&scope===customerScope)loadCustomers();});
}
let workspaceWarmScope='';
function scheduleWorkspaceWarmup(){
  if(state.connection!=='connected'||!state.session||!state.storeId)return;
  const scope=actorKey();if(scope===workspaceWarmScope)return;workspaceWarmScope=scope;
  queueMicrotask(async()=>{
    try{await platformFlight?.promise;}catch{}
    if(scope!==actorKey()||state.connection!=='connected'||!state.session)return;
    await Promise.allSettled([loadCustomers(undefined,{background:true}),rules.preload(state,ctx),reply.preload(state,ctx)]);
  });
}
async function exportCustomers(payload){
  if(state.customerExporting||!customerActive()||!customerActorMatches(state,state.customerView))return false;
  if(state.customerLoading){toast('客户筛选正在更新，请稍后再导出。');return false;}
  const snapshot=customers.customerExportSnapshot(state);
  if(!snapshot||JSON.stringify(snapshot.payload)!==JSON.stringify(payload)){toast('客户范围已变化，请核对列表后重新导出。');return false;}
  const actor=actorKey(),scope=JSON.stringify([state.authEpoch||0,state.session?.user?.id||'',state.session?.user?.tenant_id||'',state.session?.user?.role||'',state.session?.user?.cloud_bound,state.session?.user?.disabled,state.session?.user?.can_export,state.page]);
  const owns=()=>{
    const fresh=customers.customerExportSnapshot(state);
    return actor===actorKey()&&customerActive()&&scope===JSON.stringify([state.authEpoch||0,state.session?.user?.id||'',state.session?.user?.tenant_id||'',state.session?.user?.role||'',state.session?.user?.cloud_bound,state.session?.user?.disabled,state.session?.user?.can_export,state.page])
      &&Boolean(fresh&&fresh.view===snapshot.view&&fresh.signature===snapshot.signature);
  };
  state.customerExporting=true;
  try{
    const result=await backend.exportCustomers(payload),file=result.file;
    if(!owns())return false;
    if(!customerActorMatches(state,file)){await reconcilePlatformActor(actor);return false;}
    const mime='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
    if(file.contentType!==mime||typeof file.filename!=='string'||file.filename.length>150||/[\\/\x00-\x1f]/.test(file.filename)||!file.filename.endsWith('.xlsx')||typeof file.dataBase64!=='string'||file.dataBase64.length>16000000)throw new Error('Excel文件回执无效，请重新导出。');
    const binary=atob(file.dataBase64);if(!binary.startsWith('PK\x03\x04'))throw new Error('Excel内容格式不完整，请重新导出。');
    const bytes=Uint8Array.from(binary,char=>char.charCodeAt(0)),url=URL.createObjectURL(new Blob([bytes],{type:mime}));
    // The fitted workbench lives in a same-origin iframe. Start downloads from
    // its outer document so embedded browsers can surface the save operation.
    let downloadDocument=document;
    try{if(window.parent!==window&&window.parent.location.origin===location.origin)downloadDocument=window.parent.document;}catch{}
    const link=downloadDocument.createElement('a');link.href=url;link.download=file.filename;downloadDocument.body.append(link);link.click();link.remove();setTimeout(()=>URL.revokeObjectURL(url),30000);
    toast(`已生成${file.rowCount}位客户的Excel，交给浏览器下载。`);return true;
  }catch(error){if(owns())showActionError(error);return false;}
  finally{state.customerExporting=false;update(()=>{});}
}
async function openInteractionCustomer(id){
  if(!/^[a-f0-9]{64}$/.test(id||'')||!state.session||!state.storeId||activePlatform(state)!=='xiaohongshu')return;
  const actor=actorKey(),epoch=state.authEpoch||0,scope=interactionCustomerScope();
  navigate('customers');await loadCustomers();
  if(actorKey()!==actor||(state.authEpoch||0)!==epoch||scope!==interactionCustomerScope()||!customerActive()||state.customerView?.status!=='ready')return;
  const generation=++customerDetailGeneration;
  try{
    const result=await backend.customerDetail(id,{platform:'xiaohongshu'});
    if(generation!==customerDetailGeneration||actorKey()!==actor||(state.authEpoch||0)!==epoch||scope!==interactionCustomerScope()||!customerActive())return;
    if(!customerActorMatches(state,result.customer)||result.customer?.id!==id||result.customer?.item?.id!==id)throw Error('关联客户详情范围尚未核对。');
    customerControls(state).selectedId=id;state.customerDetail={...result.customer,status:'ready',interactionLink:{username:state.user,storeId:state.storeId,platform:activePlatform(state),authEpoch:state.authEpoch||0,role:state.session?.user?.role||'',tenantId:state.session?.user?.tenant_id||'',customerId:id}};update(()=>{});
  }catch(error){if(actorKey()===actor&&(state.authEpoch||0)===epoch&&scope===interactionCustomerScope())showActionError(error);}
}
function openCustomerSource(id){
  clearInvalidInteractionCustomer();
  const detail=state.customerDetail;
  if(!customerActorMatches(state,detail)||detail.status!=='ready'||detail.id!==id||detail.item?.id!==id)return;
  const allowed={'xiaohongshu':['xiaohongshu.com','www.xiaohongshu.com'],'douyin':['douyin.com','www.douyin.com'],'zhihu':['zhihu.com','www.zhihu.com'],'bilibili':['bilibili.com','www.bilibili.com'],'weibo':['weibo.com'],'kuaishou':['kuaishou.com','www.kuaishou.com'],'wechat_channels':['channels.weixin.qq.com','video.weixin.qq.com']};
  try{const url=new URL(detail.item.postUrl);if(url.protocol!=='https:'||url.username||url.password||url.port||!allowed[detail.item.platform]?.includes(url.hostname))throw new Error();window.open(url.href,'_blank','noopener');}
  catch{toast('这条客户记录的源帖地址尚未核对，已保留来源证据。');}
}
function openCustomerReply(id,{leadId}={}){
  clearInvalidInteractionCustomer();
  const detail=state.customerDetail;
  if(!customerActive()||!customerActorMatches(state,detail)||detail.status!=='ready'||detail.id!==id||detail.item?.id!==id)return;
  const prior=state.replyLive;
  if(prior&&(prior.dirty||prior.pending||prior.busy||prior.batchBusy||prior.batchPending)||state.replyDelivery?.busy||state.replyDelivery?.attempt){toast('回复页有未保存草稿或待核对操作，已保留。请先处理后再打开其他客户。');return;}
  if(leadId&&!detail.item.comments?.some(c=>c.id===leadId))return;
  const evidence=leadId||detail.item.codexReview?.evidenceLeadId||'';
  state.selectedCustomerEvidence={actor:`${state.authEpoch||0}|${state.user}|${state.storeId||''}|${activePlatform(state)}`,customerId:id,leadId:evidence,review:customerControls(state).review||'all'};
  state.replyChannel='comment';state.selectedCustomer=id;state.replyLive=null;navigate('reply');
}
function openCustomerBatch(ids){
  if(!customerActive()||!customerActorMatches(state,state.customerView)||state.customerLoading)return;
  if(!Array.isArray(ids)||!ids.length||ids.length>20||new Set(ids).size!==ids.length){toast('每批请选择1至20位客户，逐条选择原评论和草稿。');return;}
  state.replyBatchIds=[...ids];state.replyLive=null;state.selectedCustomer=ids[0];navigate('reply');
}
async function showDevelopmentLink(){
  if(state.busy)return false;state.busy=true;
  try{
    const actor=actorKey(),result=await backend.openDevelopment();if(actor!==actorKey())return false;if(!platformActorMatches({actor:result.actor},actor)){await reconcilePlatformActor(actor);return false;}
    const url=new URL(result.developmentURL,location.origin);
    if(!['127.0.0.1','localhost','[::1]'].includes(url.hostname)||!['http:','https:'].includes(url.protocol)||url.username||url.password)throw new Error('网页调试地址无效，请重新生成。');
    modal({title:'打开网页调试',html:`<p>网页与桌面使用同一真实后台。此链接单次有效，${esc(result.expiresIn||30)} 秒后过期。</p><p><a href="${esc(url.href)}" target="_blank" rel="noopener">打开网页调试</a></p><input aria-label="网页调试地址" value="${esc(url.href)}" readonly>`});
  }catch(error){showActionError(error);}
  finally{state.busy=false;}
  return false;
}
function acquireStats(){
  state.acquisitionDay ||= localDay();
  const raw=state.platform?.acquisition,snapshot=(!raw?.taskScope?.platform||raw.taskScope.platform===activePlatform(state))?raw:null,last=state.platform?.lastRequest,number=value=>Number.isSafeInteger(value)&&value>=0?value:'—',unknown=state.acquisitionAttempt?.unconfirmed||['submitted','unconfirmed'].includes(last?.state),attributed=last?.job?.taskId&&last.job.taskId===snapshot?.taskId;
  const day=state.acquisitionDay||'',daily=state.acquisitionDaily?.scope===actorKey()?state.acquisitionDaily.days?.[day]:null,dayReady=state.acquisitionDaily?.scope===actorKey()&&state.acquisitionDaily.ready;
  const values=day?[number(dayReady?daily?.added??0:null),number(dayReady?daily?.analyzed??0:null),number(dayReady?daily?.highIntent??0:null)]:state.connection==='preview'?[128,36,12]:unknown&&!attributed?['—','—','—']:[number(snapshot?.summary?.newCustomers),number(snapshot?.summary?.analyzedCustomers),number(snapshot?.summary?.highIntent)];
  return `<div class="top-stats" aria-label="${esc(day)}新增客户">${['新增客户','已分析','高意向'].map((label,index)=>`<div><span>${label}</span><strong>${values[index]}</strong></div>`).join('')}</div><div class="acquire-summary-bar"><div class="acquire-calendar">${calendarControl('acquire',day,'选择统计日期')}<span class="wb-calendar-caption">所选日期新增客户的分析结果</span></div><p class="acquire-read-count">本任务已读取评论 <strong>${number(snapshot?.counts?.read)}</strong> 条</p></div>`;
}
const acquisitionDaySignature=p=>JSON.stringify([p?.acquisition?.counts?.added,p?.acquisition?.summary?.analyzedCustomers,p?.acquisition?.summary?.highIntent]);
async function readAcquisitionDays(){
  if(!state.storeId||state.connection!=='connected'||state.acquisitionDailyLoading)return;const scope=actorKey();state.acquisitionDailyLoading=scope;
  try{const r=await backend.customers({platform:activePlatform(state),page:1,pageSize:20,sort:'time',audience:'all'});if(scope!==actorKey()||!customerActorMatches(state,r.customers))return;state.acquisitionDaily={scope,ready:true,count:acquisitionDaySignature(state.platform),days:r.customers.stats.days};render();}
  catch(error){if(scope===actorKey()){state.acquisitionDaily={scope,ready:false};showActionError(error);}}
  finally{if(state.acquisitionDailyLoading===scope)state.acquisitionDailyLoading=false;}
}
async function runPlatformOperation(action,data={}){
  if(state.busy)return null;const actor=actorKey();state.connectionRecoveryMessage='';state.busy=true;render();
  try{
    if(backend.unconfirmed||state.pendingAction?.unconfirmed){await verifyPending();return null;}
    state.pendingAction={action,platformOperation:true,username:state.user,storeId:state.storeId,requestId:data.requestId,accountId:data.accountId};
    const calls={platform_prepare:()=>backend.preparePlatform(data),account_create:()=>backend.createAccount(data),account_connect:()=>backend.connectAccount(data.accountId),account_check:()=>backend.checkAccount(data.accountId),account_safety:()=>backend.accountSafety(data.accountId),account_review_confirm:()=>backend.confirmAccountReview(data),account_verification_open:()=>backend.openAccountVerification(data.accountId),account_cancel:()=>backend.cancelAccount(data.jobId),acquisition_start:()=>backend.startAcquisition(data),acquisition_pause:()=>backend.pauseAcquisition(data.taskId),acquisition_resume:()=>backend.resumeAcquisition(data.taskId)};
    const result=await calls[action]();
    if(actor!==actorKey())return null;
    if(!platformActorMatches(result.platform,actor)){await reconcilePlatformActor(actor);return null;}
    state.pendingAction=null;const scoped=await backend.platform({platform:activePlatform(state)});if(actor!==actorKey())return null;if(!platformActorMatches(scoped.platform,actor))throw new Error('平台范围暂未核对，请刷新。');acceptPlatformSnapshot(scoped.platform);state.platformError='';state.platformErrorCode='';state.platformUpdatedAt=Date.now();return {...result,platform:scoped.platform};
  }catch(error){const unknown=['RESULT_UNCONFIRMED','REQUEST_UNCONFIRMED','COLLECTION_RESULT_UNCONFIRMED','LOGIN_RESULT_UNCONFIRMED'].includes(error.code)||(action==='acquisition_start'&&error.code==='PLATFORM_ACTION_FAILED');if(unknown&&state.pendingAction){state.pendingAction.unconfirmed=true;if(action==='acquisition_start'&&state.acquisitionAttempt)state.acquisitionAttempt.unconfirmed=true;error.code='RESULT_UNCONFIRMED';}if(actor===actorKey())return await recoverAction(error);return null;}
  finally{state.busy=false;render();}
}
async function verifySourceInteractions({silent=false}={}){
  const p=backend.interactionPending;if(!p)return true;
  if(state.sourceInteractionChecking)return false;
  if(!state.session||p.username!==state.user||p.storeId!==state.storeId){toast('请回到原员工账号与门店，核对这次互动检查。');return false;}
  const actor=actorKey();state.sourceInteractionChecking=true;render();
  try{
    const result=await backend.platform({platform:p.platform});if(actor!==actorKey())return false;
    if(!result?.platform||result.platform.actor?.username!==p.username||result.platform.actor?.storeId!==p.storeId)throw new Error('原任务所属账号与门店尚未核对。');
    if(p.platform===activePlatform(state))acceptPlatformSnapshot(result.platform);
    const confirmed=!backend.interactionPending;state.sourceInteractionPending=backend.interactionPending;
    if(!silent||confirmed)toast(confirmed?'已确认原检查已开始，没有重复发起。':'尚未确认原检查结果。已保留原任务与轮次，请稍后再核对。');
    return confirmed;
  }catch(error){if(actor===actorKey())showActionError(error);return false;}
  finally{state.sourceInteractionChecking=false;if(actor===actorKey())render();}
}
async function checkSourceInteractions(choice){
  if(state.busy)return false;
  if(backend.interactionPending){await verifySourceInteractions();return false;}
  if(backend.unconfirmed||state.pendingAction?.unconfirmed){await verifyPending();return false;}
  const current=interactionScanChoice(state);if(!current||JSON.stringify(current)!==JSON.stringify(choice)){toast('原任务状态已变化，请刷新后重新确认。');return false;}
  const actor=actorKey();state.busy=true;render();
  try{
    const result=await backend.sourceAction('source_interactions_check',choice);if(actor!==actorKey())return false;
    if(!platformActorMatches(result.platform,actor))throw new Error('检查回执归属尚未核对，请刷新原任务。');
    acceptPlatformSnapshot(result.platform);toast('已开始检查原账号的新增互动。');return true;
  }catch(error){
    if(actor!==actorKey())return false;
    state.sourceInteractionPending=backend.interactionPending;
    if(backend.interactionPending){toast('检查回执尚未确认，正在核对原任务；不会重复采集。');return await verifySourceInteractions();}
    showActionError(error);return false;
  }finally{state.busy=false;if(actor===actorKey())render();}
}
async function preparePlatform(options={}){const result=await runPlatformOperation('platform_prepare',options?.existingOnly===true?{existingOnly:true}:{});if(result)toast(result.platform?.device?.message||'本机连接准备状态已更新。');return result;}
let toneReadGeneration=0,toneScopeGeneration=0;
async function readTonePreferences(){
  if(state.connection!=='connected'||!state.session||!state.storeId)return null;
  const actor=actorKey(),generation=++toneReadGeneration;state.tonePreferenceReadActor=actor;state.tonePreferencesLoading=true;state.tonePreferencesError='';
  try{
    const result=await backend.tonePreferencesRead({storeId:state.storeId}),value=result.preferences;
    if(actor!==actorKey()||generation!==toneReadGeneration)return null;
    if(!platformActorMatches(value,actor)||!Number.isSafeInteger(value.revision)||value.revision<0)throw new Error('口吻方案归属未核对，请重新读取。');
    if(platformActorMatches(state.tonePreferences,actor)&&state.tonePreferences.revision>value.revision)return state.tonePreferences;
    state.tonePreferences=value;return value;
  }catch(error){if(actor===actorKey()&&generation===toneReadGeneration){state.tonePreferencesError=error.message;showActionError(error);}return null;}
  finally{if(actor===actorKey()&&generation===toneReadGeneration){state.tonePreferencesLoading=false;render();}}
}
async function saveTonePreferences(choice){
  if(state.busy||!state.storeId)return null;
  if(backend.unconfirmed||state.pendingAction?.unconfirmed){await verifyPending();return null;}
  const actor=actorKey(),storeId=state.storeId,scopeGeneration=toneScopeGeneration;
  const current=()=>actor===actorKey()&&scopeGeneration===toneScopeGeneration;
  state.acquisitionDailyLoading=false;
  toneReadGeneration++;state.tonePreferencesLoading=false;state.tonePreferencesError='';
  try{
    const result=await backend.tonePreferencesSave({storeId,...choice}),value=result.preferences;
    if(!current())return null;
    if(!platformActorMatches(value,actor))throw new Error('口吻方案归属未核对，请重新读取。');
    if(platformActorMatches(state.tonePreferences,actor)&&state.tonePreferences.revision>value.revision)throw new Error('口吻方案已有更新，请重新读取已保存方案。');
    state.acquisitionDailyLoading=false;
  toneReadGeneration++;state.tonePreferencesLoading=false;
    state.tonePreferences=value;return value;
  }catch(error){
    if(!current())return null;
    if(error.code==='RESULT_UNCONFIRMED'){
      try{
        const bootstrap=await backend.bootstrap();if(!current())return null;acceptBootstrap(bootstrap);if(!current())return null;
        const value=await readTonePreferences();
        if(!current())return null;
        if(value?.revision===choice.expectedRevision+1&&['identity','tone','salutation','focus','templates'].every(k=>JSON.stringify(value[k])===JSON.stringify(choice[k]))){state.tonePreferencesError='';return value;}
      }catch{}
    }
    if(current()){state.tonePreferencesError=error.message;showActionError(error);}return null;
  }
}
async function checkAccount(platformId){
  if(state.busy)return null;
  if(!state.storeId){chooseWorkStore('accounts');return null;}
  const row=platformRow(platformId),id=state.platformAccountSelections?.[platformId]||row?.accountId;
  if(!id){toast('请先连接这个平台的账号。');return null;}
  const actor=actorKey(),result=await runPlatformOperation('account_check',{accountId:id});
  if(result&&actor===actorKey()){toast(result.job?.message||'账号检查完成，请查看当前状态。');if(platformId==='douyin'&&state.page==='accounts'&&result.job?.windowOpen===true&&!accountConnectionState(platformId,result.job,state.platform?.accounts?.find(a=>a.id===id)).complete)showAccountJob(result.job,platformId,actor);}
  return result;
}
async function accountSafetyOperation(action,platformId,extra={}){
  if(state.busy||!state.storeId)return null;
  const row=platformRow(platformId),id=state.platformAccountSelections?.[platformId]||row?.accountId;
  if(!id){toast('请先选择当前门店的平台账号。');return null;}
  return runPlatformOperation(action,{accountId:id,...extra});
}
function chooseWorkStore(nextPage){
  if(!state.session){navigate('login');return;}
  if(!state.stores?.length){toast(state.notice||'当前账号的门店目录暂不可读，请刷新门店资料。');return;}
  modal({title:'选择本次使用的门店',html:`<label for="work-store-choice">门店</label><select id="work-store-choice">${state.stores.map(row=>`<option value="${esc(row.id)}">${esc(row.name)}</option>`).join('')}</select>`,confirmLabel:'使用这家门店',onConfirm:async()=>{const id=document.getElementById('work-store-choice')?.value;await selectStore(id);if(state.storeId!==id)return false;navigate(nextPage);return true;}});
}
async function startAcquisition(options={}){
  if(state.busy)return null;
  if(options.fresh){
    const expected=options.fresh.signature,current=acquire.freshAcquisitionCapture(state);
    if(!expected||current?.signature!==expected||backend.unconfirmed||state.pendingAction?.unconfirmed){toast('当前采集条件或待核状态已变化，请重新确认。');return null;}
    const refreshed=await refreshPlatform({manual:true});
    if(!refreshed||acquire.freshAcquisitionCapture(state)?.signature!==expected||backend.unconfirmed||state.pendingAction?.unconfirmed){toast('账号、门店、来源或原任务状态已变化，请刷新后重新确认。');return null;}
  }
  if(options.sourceKind&&acquire.freshSourceKind(state)!==options.sourceKind){toast('本页来源已变化，请重新选择并确认。');return null;}
  if(!state.storeId){chooseWorkStore('acquire');return null;}
  if(!state.platform||state.platformError)await refreshPlatform({manual:true});
  const platform=state.platform?.platforms?.find(row=>row.id===state.acquire?.selectedPlatform),accountId=state.platformAccountSelections?.[platform?.id]||platform?.accountId;
  if(!platform?.enabled){navigate('accounts');toast('请先连接本次使用的平台账号。');return null;}
  const account=state.platform?.accounts?.find(row=>row.id===accountId&&row.platform===platform.id);
  if(!accountId||account?.status!=='ready'){
    navigate('accounts');
    await connectAccount(platform.id,accountId);return null;
  }
  // The gateway projects this store's current validated words and policy on start.
  const actor=actorKey(),choice={storeId:state.storeId,expectedRevision:state.selection?.revision,platform:platform.id,accountId,region:state.acquire?.region||'',time:state.acquire?.time||'最近30天'};
  const selectedSource=sourceSelection(state);
  if(selectedSource?.source){
    if(selectedSource.accountId!==accountId||selectedSource.preview?.canStart!==true||!selectedSource.previewDigest){toast('来源或采集账号已变化，请重新核对来源。');return null;}
    Object.assign(choice,{source:selectedSource.source,commentWindow:selectedSource.commentWindow,execution:selectedSource.execution,previewDigest:selectedSource.previewDigest});
  }
  if(!state.acquisitionAttempt||state.acquisitionAttempt.actor!==actor||!state.acquisitionAttempt.unconfirmed){state.acquisitionAttempt={actor,payload:{...choice,requestId:crypto.randomUUID()},unconfirmed:false};}
  const result=await runPlatformOperation('acquisition_start',state.acquisitionAttempt.payload);
  if(result){state.acquisitionAttempt=null;toast('采集请求已提交，进度以真实回执为准。');}
  else if(!state.acquisitionAttempt?.unconfirmed&&!backend.unconfirmed&&!state.pendingAction?.unconfirmed)state.acquisitionAttempt=null;
  return result;
}
function ownedUnconfirmedTask(taskId){const last=state.platform?.lastRequest;return Boolean(state.acquisitionAttempt?.unconfirmed&&last?.requestId===state.acquisitionAttempt.payload.requestId&&['submitted','unconfirmed'].includes(last.state)&&last.job?.taskId===taskId&&state.platform?.acquisition?.canPause);}
async function pauseAcquisition(taskId){
  if(!ownedUnconfirmedTask(taskId)){const result=await runPlatformOperation('acquisition_pause',{taskId});if(result)toast('暂停请求已提交，正在核对任务状态。');return result;}
  if(state.busy)return null;const actor=actorKey();state.busy=true;render();
  try{
    if(backend.unconfirmed)await verifyPending();
    if(actor!==actorKey()||!state.platform?.acquisition?.canPause||(!ownedUnconfirmedTask(taskId)&&state.platform?.acquisition?.taskId!==taskId))return null;
    const result=await backend.pauseAcquisition(taskId);if(actor!==actorKey())return null;if(!platformActorMatches(result.platform,actor)){await reconcilePlatformActor(actor);return null;}
    const scoped=await backend.platform({platform:activePlatform(state)});if(actor!==actorKey()||!platformActorMatches(scoped.platform,actor))return null;acceptPlatformSnapshot(scoped.platform);state.platformError='';state.platformErrorCode='';toast(state.acquisitionAttempt?.unconfirmed?'已请求暂停有归属回执的任务；开始操作仍保留核对状态。':'暂停请求已提交，正在核对任务状态。');return result;
  }catch(error){if(actor===actorKey()){if(error.code==='RESULT_UNCONFIRMED')await recoverAction(error);else showActionError(error);}return null;}
  finally{state.busy=false;render();}
}
async function resumeAcquisition(taskId){const result=await runPlatformOperation('acquisition_resume',{taskId});if(result)toast('恢复请求已提交，正在核对任务状态。');return result;}
async function verifyAcquisition(){if(state.busy)return;state.busy=true;render();try{await verifyPending();}catch(error){showActionError(error);}finally{state.busy=false;render();}}
function platformRow(platformId){return state.platform?.platforms?.find(row=>row.id===platformId);}
function safeQrUrl(value){
  if(typeof value!=='string')return '';
  if(/^data:image\/(png|jpeg|webp);base64,[a-zA-Z0-9+/=]+$/.test(value)&&value.length<3000000)return value;
  try{const url=new URL(value,location.origin);return url.origin===location.origin&&url.pathname.startsWith('/api/workbench/')?url.href:'';}catch{return '';}
}
function showAccountJob(job,platformId,actor){
  if(actor!==actorKey()||state.page!=='accounts')return;
  const jobId=job?.id||job?.jobId,key=jobId||'platform:'+platformId,targetAccountId=job?.accountId;
  const autoDouyin=platformId==='douyin'&&!jobId&&Boolean(targetAccountId)&&job?.windowOpen===true,autoStarted=Date.now();let autoChecks=0;
  const needsContinue=value=>platformId==='xiaohongshu'&&value?.status==='failed'&&value?.windowOpen===true;
  const dialog=modal({title:'连接'+platformName(platformId)+'账号',html:'<div class="account-connection"><img class="connection-brand" src="/assets/brand-'+platformId+'.svg" alt=""><div id="account-job-phase" class="connection-label">等待平台登录</div><p id="account-job-message" role="status">正在读取连接回执…</p><img id="account-job-qr" width="256" height="256" alt="平台登录二维码" hidden><p id="account-job-browser" class="muted">请在本次打开的平台浏览器完成本人登录与网页验证码；身份核验通过后才显示已连接。</p><button type="button" id="account-job-cancel"'+(jobId?'':' hidden')+'>取消本次连接</button></div>',confirmLabel:needsContinue(job)?'继续登录并检查':jobId?'刷新状态':'检查连接',onConfirm:async()=>{if(connectionComplete){dialog.close();return false;}await check();return false;}});
  dialog.dataset.accountJob=key;const modalOwner=dialog.__modalOwner;let timer,closed=false,checking=false,connectionComplete=false,latestJob=job;
  const owns=()=>!closed&&dialog.open&&dialog.__modalOwner===modalOwner&&state.page==='accounts'&&dialog.dataset.accountJob===key&&document.getElementById('account-job-message')&&actor===actorKey()&&(!targetAccountId||!state.platformAccountSelections?.[platformId]||state.platformAccountSelections[platformId]===targetAccountId);
  function schedule(initial=false){
    if(!owns()||connectionComplete)return;
    if(jobId){timer=setTimeout(check,initial?1200:2500);return;}
    if(!autoDouyin||latestJob?.windowOpen!==true)return;
    if(autoChecks>=12||Date.now()-autoStarted>=120000){const browser=document.getElementById('account-job-browser');if(browser)browser.textContent='自动确认暂未完成，登录窗口和资料已保留；可点检查连接继续，无需重复扫码。';return;}
    timer=setTimeout(()=>check(true),initial?2500:autoChecks<3?5000:10000);
  }
  function display(value){
    if(!owns())return;latestJob=value;const initialAccount=(state.platform?.accounts||[]).find(a=>a.id===value?.accountId);const outcome=accountConnectionState(platformId,value,initialAccount),done=outcome.terminal;
    document.getElementById('account-job-message').textContent=value?.message||(typeof value?.error==='string'?value.error:value?.error?.message)||(done?'连接操作已返回，请核对账号状态。':'连接进行中，请在平台登录窗口完成确认。');
    const rowFeedback=state.accountPage;if(rowFeedback?.scope===JSON.stringify([state.authEpoch||0,state.connection,state.user||'',state.storeId||'',state.activePlatform||'xiaohongshu'])){rowFeedback.feedback[platformId]=document.getElementById('account-job-message').textContent;rowFeedback.failures??={};rowFeedback.failures[platformId]=['failed','cancelled','stopped'].includes(value?.status);}
    const phase=document.getElementById('account-job-phase');
    const account=(state.platform?.accounts||[]).find(a=>a.id===(value?.accountId||state.platformAccountSelections?.[platformId]));
    const committed=accountConnectionState(platformId,value,account).complete;
    if(committed)connectionComplete=true;
    if(phase)phase.textContent=outcome.phase;
    const browser=document.getElementById('account-job-browser');
    if(browser)browser.textContent=committed?'平台身份已核对，可以返回账号列表。':outcome.needsSnapshot?'登录操作已返回，尚未与本次账号记录核对成功；可刷新状态继续核对。':value?.windowOpen===true?(autoDouyin?'原抖音窗口保持打开，完成本人登录后会自动确认账号和昵称；已登录时无需重复扫码。':'平台浏览器仍保持打开，可在其中手动登录或完成网页验证码；再次切回请点原来的登录按钮。'):value?.persistentBrowser===true&&value?.windowOpen===false?'平台浏览器已关闭，登录资料仍保留；请点原来的登录按钮继续。':'请在本次打开的平台浏览器完成本人登录与网页验证码；身份核验通过后才显示已连接。';
    const image=document.getElementById('account-job-qr'),url=safeQrUrl(value?.qrUrl||value?.qr_url);image.hidden=!url;if(url)image.src=url;else image.removeAttribute('src');
    document.getElementById('account-job-cancel').hidden=!jobId||committed||(['cancelled','stopped'].includes(value?.status)&&value?.windowOpen!==true);
    document.getElementById('account-job-cancel').disabled=!jobId||(done&&value?.windowOpen!==true)||state.busy;
    document.getElementById('account-job-cancel').textContent=done&&value?.windowOpen===true?'关闭登录窗口':'取消本次连接';
    const confirm=dialog.querySelector?.('.modal-confirm');if(confirm)confirm.textContent=committed?'返回账号列表':needsContinue(value)?'继续登录并检查':jobId?'刷新状态':'检查连接';
    if(done){clearTimeout(timer);refreshPlatform({manual:true}).then(()=>{if(owns()){const row=(state.platform?.accounts||[]).find(a=>a.id===(value?.accountId||state.platformAccountSelections?.[platformId]));if(accountConnectionState(platformId,value,row).complete){const phase=document.getElementById('account-job-phase');if(phase)phase.textContent='已连接';connectionComplete=true;const browser=document.getElementById('account-job-browser');if(browser)browser.textContent='平台身份已核对，可以返回账号列表。';const confirm=dialog.querySelector('.modal-confirm');if(confirm)confirm.textContent='返回账号列表';const cancel=dialog.querySelector('.modal-cancel');if(cancel)cancel.hidden=true;const windowCancel=document.getElementById('account-job-cancel');if(windowCancel)windowCancel.hidden=true;}}});}return done;
  }
  async function check(automatic=false){
    if(!owns()||checking)return;checking=true;clearTimeout(timer);if(automatic&&autoDouyin)autoChecks++;
    try{if(needsContinue(latestJob)){await connectAccount(platformId,latestJob.accountId);return;}const result=jobId?await backend.accountJob(jobId):autoDouyin?await runPlatformOperation('account_check',{accountId:targetAccountId}):await checkAccount(platformId);if(!owns())return;if(!result){document.getElementById('account-job-message').textContent='本次检查未取得回执，请查看账号页的原因后重试。';return;}if(!platformActorMatches(result.platform,actor)){await reconcilePlatformActor(actor);return;}const scoped=await backend.platform({platform:activePlatform(state)});if(!owns()||!platformActorMatches(scoped.platform,actor))return;acceptPlatformSnapshot(scoped.platform);if(!display(result.job))schedule();}
    catch(error){if(owns()){document.getElementById('account-job-message').textContent='连接状态暂未更新：'+error.message;if(error.code==='AUTH_REQUIRED')showActionError(error);}}
    finally{checking=false;}
  }
  document.getElementById('account-job-cancel').onclick=async()=>{if(!jobId||!owns())return;const result=await runPlatformOperation('account_cancel',{jobId});if(owns()){if(result?.job)display(result.job);else await check();}};
  dialog.addEventListener('close',()=>{closed=true;clearTimeout(timer);},{once:true});
  if(!display(job))schedule(true);
}
async function connectAccount(platformId,accountId){
  if(state.busy)return null;
  if(!state.storeId){chooseWorkStore('accounts');return null;}
  const actor=actorKey(),current=()=>actor===actorKey();
  let row=platformRow(platformId);
  if(!state.platform||state.platformError){await refreshPlatform({manual:true});if(!current())return null;row=platformRow(platformId);}
  if(!row?.enabled){toast(row?.message||'当前平台尚未开通，请刷新账号状态核对。');return;}
  // One backend connect owns device preparation and its bounded wait.
  accountId||=state.platformAccountSelections?.[platformId]||row.accountId;
  if(!accountId){
    const name=Array.from((state.store||'门店')+' · '+(row.name||'平台')).slice(0,80).join('');
    const created=await runPlatformOperation('account_create',{platform:platformId,name});
    if(!created||!current())return null;
    accountId=created.job?.accountId||created.accountId||platformRow(platformId)?.accountId;
    if(!accountId)return null;
  }
  const result=await runPlatformOperation('account_connect',{accountId});if(result&&current()){if(state.page==='accounts')showAccountJob(result.job,platformId,actor);else toast('连接请求已提交，请在账号页核对状态。');return result;}return null;
}
const actions={publicContactAction:(action,data)=>backend.publicContactAction(action,data),outcomeAction:(action,data)=>backend.outcomeAction(action,data),mediaAction:(action,data)=>backend.mediaAction(action,data),mediaOutput:data=>backend.mediaOutput(data),dmAction:(action,data)=>backend.dmAction(action,data),interactionInboxAction:(action,data)=>backend.interactionInboxAction(action,data),openInteractionCustomer,keywordEffectAction:(action,data)=>backend.keywordEffectAction(action,data),intentCorrectionAction:(action,data)=>backend.intentCorrectionAction(action,data),checkSourceInteractions,verifySourceInteractions,sourceAction:(action,data)=>backend.sourceAction(action,data),livestreamAccounts:()=>backend.platform({platform:'douyin'}),livestreamAction:(action,data)=>backend.livestreamAction(action,data),contentAction:(action,data)=>backend.contentAction(action,data),verifyBlockedAcquisition:()=>{const n=platformNotices(state).find(n=>n.id===activePlatform(state));return n?verificationAction('open',n):undefined;},selectAllCustomers,refreshAIRules,accountWebsiteOpen:data=>backend.accountWebsiteOpen(data),accountWebsiteStatus:jobId=>backend.accountWebsiteStatus(jobId),accountDeleteRetry:data=>backend.accountDeleteRetry(data),accountDelete:data=>backend.accountDelete(data),accountDeleteRequest:data=>backend.accountDeleteRequest(data),accountMetadataRead:data=>backend.accountMetadataRead(data),accountMetadataSave:data=>backend.accountMetadataSave(data),accountCreate:data=>runPlatformOperation('account_create',data),memoExport:data=>backend.memoExport({...data,platform:activePlatform(state)}),remoteAction:(action,data)=>backend.remoteAction(action,data),remotePending:()=>backend.remotePending,openRemoteManagement:()=>openRemoteManagement(ctx),readBusinessRules:data=>backend.aiRulesRead({...data,view:'business'}),aiRulesExport:data=>backend.aiRulesExport(data),aiLocalRulesSave:data=>backend.aiLocalRulesSave(data),ruleBundle:(action,data)=>backend.ruleBundle(action,data),ruleBundlePending:()=>backend.ruleBundlePending,openRuleFiles:()=>openRuleFiles(ctx),openCentralRuleFiles:()=>openCentralRuleFiles(ctx),readAccountSafety:id=>accountSafetyOperation('account_safety',id),openAccountVerification:id=>accountSafetyOperation('account_verification_open',id),confirmAccountReview:(id,revision)=>accountSafetyOperation('account_review_confirm',id,{revision,confirmed:true}),openToneTools:()=>openToneTools(ctx),openSettings:()=>openSettings(ctx),reloadWorkspace,logout,refreshSettingsPlatform:()=>refreshPlatform({manual:true}),refreshRuntimeStatus,replyEditor:()=>document.querySelector('[data-live-draft]'),hasUnconfirmed:()=>backend.unconfirmed||Boolean(state.pendingAction?.unconfirmed),handoffAction:(kind,data)=>({read:backend.handoffRead,save:backend.handoffSave}[kind])(data),update,navigate,toast,modal,selectStore,applyPreset,refreshAssessments,refreshPlatform,recoverConnection,showDevelopmentLink,preparePlatform,connectAccount,checkAccount,readTonePreferences,saveTonePreferences,startAcquisition,pauseAcquisition,resumeAcquisition,verifyAcquisition,loadCustomers,loadCustomerDetail,exportCustomers,openCustomerSource,openCustomerReply,openCustomerBatch,setCustomerSearchComposing,replyCustomers:data=>backend.customers({...data,platform:activePlatform(state)}),replyRead:data=>backend.replyRead({...data,platform:activePlatform(state)}),replySave:data=>backend.replySave({...data,platform:activePlatform(state)}),replyReview:data=>backend.replyReview({...data,platform:activePlatform(state)}),replyCheck:data=>backend.replyCheck({...data,platform:activePlatform(state)}),deliveryAction:(kind,data)=>({prepare:backend.deliveryPrepare,start:backend.deliveryStart,status:backend.deliveryStatus,cancel:backend.deliveryCancel}[kind])({...data,platform:activePlatform(state)}),replyError:showActionError};
const ctx={viewModel,actions,state:viewModel,...actions};
function navButton(page,label,img){const current=state.page===page||(page==='rules'&&['tone','presets','aiModel'].includes(state.page));return `<button class="nav-btn ${current?'active':''}" data-nav="${page}" ${current?'aria-current="page"':''}>${icon(img)}<span>${label}</span></button>`;}
function shell(content){const dates=localDates();if(state.connection==='connected'&&state.session&&!state.storeId)content=`<div role="status"><p class="login-error">${esc(state.notice||state.capabilities?.reason||'请到管理页明确选择已授权门店分组。')}</p></div>`+content;if(state.workspaceError)content=`<div role="alert"><p class="login-error">${esc(state.workspaceError.message)}</p><button type="button" id="reload-workspace" ${state.busy?'disabled':''}>重新加载门店资料</button></div>`+content;const management=['presets','rules','tone','accounts','aiModel'].includes(state.page);const nav=`${navButton('acquire','获客','approved-icon-search.svg')}${navButton('diversified','多样化获客','icon-message-square-more.svg')}${navButton('reply','回复','icon-message-square-more.svg')}${navButton('customers','客户','approved-icon-user-round.svg')}${navButton('accounts','账号','approved-icon-user-round.svg')}${navButton('content','内容运营','icon-message-square-more.svg')}${navButton('rules','管理','approved-icon-settings.svg')}`;
if(['rules','tone','presets','aiModel'].includes(state.page))content=`<div role="navigation" aria-label="管理分类" style="display:flex;flex-wrap:wrap;gap:12px;margin-bottom:20px"><button type="button" class="rp-tab ${state.page==='rules'?'is-active':''}" data-nav="rules" aria-pressed="${state.page==='rules'}">获客规则</button><button type="button" class="rp-tab ${state.page==='tone'?'is-active':''}" data-nav="tone" aria-pressed="${state.page==='tone'}">回复口吻</button>${state.session?.user?.role==='admin'?`<button type="button" class="rp-tab ${state.page==='aiModel'?'is-active':''}" data-nav="aiModel" aria-pressed="${state.page==='aiModel'}">AI 模型</button>`:''}${state.connection==='connected'&&state.session&&state.storeId?'<button type="button" class="rp-tab" data-open-outcome-report>结果与投入</button>':''}</div>`+content;
return `<div class="shell" data-current="${state.page}" data-platform="${activePlatform(state)}"><div id="platform-notice-host" class="platform-notice-host" hidden></div><aside class="sidebar"><div class="brand"><span class="brand-mark"><img src="/assets/fy-approved-official-logo.png" alt="方隅公寓官方标志"></span><div class="brand-copy"><strong>方隅工作台</strong><span>渠道运营</span></div></div><nav class="side-nav" aria-label="主导航">${nav}</nav><img class="side-photo" src="/assets/${activePlatform(state)==='douyin'?'sidebar-night-photo.png':'sidebar-approved-photo.png'}" alt="阳光中的公寓建筑"><div class="side-quote"><strong>让更多人</strong><br>住进更好的城市生活</div></aside><div class="hero-photo"><img src="/assets/${activePlatform(state)==='douyin'?'header-night-apartment.png':'fy-approved-header-apartment.png'}" alt=""></div><header class="topbar ${management||state.page==='customers'?'has-date':''}">${management?`<time class="topbar-date" data-local-date="long">${dates.long}</time><span class="topbar-divider"></span>`:''}<button class="bell" aria-label="通知">${icon('fy-icon-58-bell.png')}</button><button class="account-button" aria-label="${esc(state.user||'演示账号')}账号菜单"><img class="avatar" src="/assets/approved-icon-user-round.svg" alt="员工账号"><span>${esc(state.user||'演示账号')}</span>${icon('tabler-chevron-down.svg')}</button>${state.page==='customers'?`<span class="topbar-divider"></span><time class="topbar-date" data-local-date="short">${dates.short}</time>`:''}</header>${state.page==='reply'?`<div class="date-label" data-local-date="iso">${dates.iso}</div>`:''}<main class="main"><div class="page-heading"><h1>${titles[state.page][0]}${state.page==='acquire'?helpButton():''}</h1><p>${titles[state.page][1]}</p></div>${state.page==='acquire'?acquireStats():''}<section id="page-content">${content}</section>${renderPlatformSwitch(state)}<footer class="page-footer">${state.connection==='preview'?'界面预览 · 示例数据':'方隅工作台'}&nbsp;&nbsp; <time data-local-date="iso">${dates.iso}</time></footer></main></div>`;}
function switchPlatform(value){
  if(!['xiaohongshu','douyin'].includes(value)||value===activePlatform(state)||state.busy)return;
  const prior=activePlatform(state),fields=['acquire','replyLive','replyDelivery','replyBatchIds','selectedCustomer','platform','platformUpdatedAt','customers','customerView','customerDetail'];
  // Never orphan a submitted write when its actor epoch changes.
  if(state.replyLive?.busy||state.replyLive?.pending||state.replyLive?.batchBusy||state.replyLive?.batchPending||state.replyDelivery?.busy||state.replyDelivery?.attempt){toast('请先核对当前回复操作结果。');return;}
  if(state.replyLive){const v=state.replyLive;v.generation++;v.refreshing=false;v.detailLoading=false;if(['loading','scheduled'].includes(v.status))v.status=v.loadedAt?'ready':'idle';}
  state.platformWorkspaces[prior]=Object.fromEntries(fields.map(key=>[key,state[key]]));
  state.acquisitionDailyLoading=false;
  toneReadGeneration++;state.tonePreferencesLoading=false;state.tonePreferenceReadActor='';
  invalidateSensitiveViews();platformGeneration++;manualPlatformGeneration++;customerGeneration++;customerDetailGeneration++;
  clearTimeout(platformTimer);clearTimeout(customerTimer);customerResolve?.(null);customerResolve=null;
  state.activePlatform=value;state.platform=null;state.platformError='';state.platformErrorCode='';state.platformLoading=false;platformScope='';customerScope='';platformFlight=null;
  for(const key of fields)state[key]=state.platformWorkspaces[value]?.[key];
  const replyActor=`${state.authEpoch||0}|${state.user}|${state.storeId||''}|${value}`;if(state.replyLive){state.replyLive.actor=replyActor;state.replyLive.generation++;}if(state.replyDelivery)state.replyDelivery.actor=replyActor;
  if(state.customerView?.status==='loading')state.customerView=null;if(state.customerDetail?.status==='loading')state.customerDetail=null;state.customerLoading=false;state.customerSearchCompositionActor='';
  state.customerHandoff=null;state.accountPage=null;state.acquisitionAttempt=null;
  if(state.acquire)state.acquire.selectedPlatform=value;
  render();
}
function login(){const preview=state.connection==='preview',waiting=state.connection==='loading';return `<main class="login-page"><section class="login-photo" aria-label="方隅公寓"><img src="/assets/login-approved-photo.png" alt="暖阳透过落地窗，洒在公寓客厅"><div class="login-caption">让每一次咨询，都有回应。<small>— 方隅公寓</small></div></section><section class="login-form-wrap"><span class="demo-pill">${preview?'演示界面':'员工登录'}</span><div class="login-wordmark" aria-label="方隅公寓，高档一居租方隅"><div class="login-wordmark-top"><span class="login-wordmark-mark"><img src="/assets/fy-approved-official-logo.png" alt="方隅官方标志"></span><strong>方隅公寓</strong></div><small>高档一居租方隅</small></div><h1>欢迎回来</h1><form class="login-form" id="login-form"><label class="field-label" for="login-name">员工用户名</label><div class="login-input">${icon('fy-icon-16-user.png')}<input id="login-name" autocomplete="username" value="${esc(state.loginDraft?.username??state.rememberedUsername)}" placeholder="请输入用户名" aria-describedby="login-error" ${waiting?'disabled':''}></div><label class="field-label" for="login-pass">密码</label><div class="login-input">${icon('fy-icon-43-lock.png')}<input id="login-pass" type="password" autocomplete="current-password" aria-label="密码" ${waiting?'disabled':''}><button type="button" class="password-eye" aria-label="显示密码">${icon('fy-icon-45-eye.png')}</button></div><div class="login-options"><label class="remember"><input id="login-remember" type="checkbox" ${(state.loginDraft?.rememberUsername??Boolean(state.rememberedUsername||preview))?'checked':''}>记住用户名</label><button type="button" id="forgot-password">忘记密码？联系管理员。</button></div><button class="login-submit" type="submit" ${waiting||state.busy?'disabled':''}>${waiting?'正在连接…':state.busy?'正在验证…':backend.unconfirmed?'核对登录状态':'登录工作台'} ${icon('icon-arrow-right.svg')}</button><div class="login-meta"><span><i class="service-dot"></i>${preview?'演示服务已就绪':waiting?'正在连接本地服务':state.connection==='error'?'服务连接待重试':'本地服务已连接'}</span><span><button type="button" id="login-help">使用帮助</button>│&nbsp; <span data-runtime-version title="${esc(state.runtimeMetadata?.value?.release||'')}">${esc(versionLabel(state))}</span></span></div><p id="login-error" class="login-error" aria-live="polite">${esc(state.loginError||state.connectionError||'')}</p></form></section></main>`;}
function tools(){if(state.connection!=='preview')return '';return `<details class="preview-tools"><summary>预览状态</summary><div><span>${state.connection==='preview'?'仅演示数据':(state.capabilities.customers?'仅切换回复页示例':'仅切换回复与客户示例')}</span><button data-scenario="normal">正常</button><button data-scenario="empty">空数据</button><button data-scenario="loading">加载中</button><button data-scenario="error">失败与重试</button><button data-scenario="long">长评论</button><button data-nav="login">返回登录</button></div></details>`;}
async function submitLogin(event){
  event.preventDefault();if(state.busy)return;
  const name=document.getElementById('login-name'),password=document.getElementById('login-pass'),error=document.getElementById('login-error');
  const username=name.value.trim();state.loginDraft={username,rememberUsername:document.getElementById('login-remember').checked};
  if(backend.unconfirmed||state.pendingAction?.unconfirmed){state.busy=true;error.textContent='正在核对上次操作结果，请稍候…';try{await verifyPending();}catch{state.loginError='暂时无法核对，请稍后点击登录按钮再次核对。';}finally{state.busy=false;render();}return;}
  if(!username){error.textContent=state.connection==='preview'?'请输入演示用户名':'请输入员工用户名';name.focus();return;}
  if(state.connection==='preview'){state.user=username;state.store||='古北店';navigate('acquire');toast('欢迎回来，已进入界面预览');return;}
  if(!password.value){error.textContent='请输入密码';password.focus();return;}
  state.busy=true;document.querySelector('.login-submit').disabled=true;error.textContent='正在验证账号，请稍候…';state.loginError='';
  try{
    if(state.connection==='error'){const boot=await backend.bootstrap();if(!boot)throw new Error('当前服务未提供员工登录，请从桌面方隅工作台打开。');acceptBootstrap(boot);}
    state.pendingAction={action:'login',username};
    acceptBootstrap(await backend.login({username,password:password.value,rememberUsername:state.loginDraft.rememberUsername}));
    state.pendingAction=null;state.loginDraft=undefined;password.value='';state.connectionError='';navigate('acquire');toast(state.notice||(state.store?'登录成功，门店：'+state.store:'登录成功，请到管理页选择已授权门店分组'));
  }catch(failure){if(failure?.code==='RESULT_UNCONFIRMED'){password.value='';await recoverAction(failure);}else{state.pendingAction=null;state.loginError=failure.message||'登录未完成，请稍后重试。';}}
  finally{password.value='';state.busy=false;render();if(state.page==='login')document.getElementById('login-pass')?.focus();}
}
function render(){
  clearInvalidInteractionCustomer();
  state.sourceInteractionPending=backend.interactionPending;
  // Preserve the actual IME input node while list/detail responses update data.
  // Navigation or an identity change must always render immediately.
  if(customerSearchCompositionActor===actorKey()&&customerActive()){customerRenderPending=true;return false;}
  customerSearchCompositionActor='';customerRenderPending=false;
  paneScroll.save();
  cleanup?.();cleanup=undefined;document.body.dataset.page=state.page;
  setCustomerMediaScope(state.connection==='connected'&&state.session?workflowScope(state):'');
  const mod=pages[state.page];
  if(state.page==='login'){
    app.innerHTML=login()+tools();
    document.getElementById('login-form').addEventListener('submit',submitLogin);
    document.querySelector('.password-eye').onclick=()=>{const i=document.getElementById('login-pass');i.type=i.type==='password'?'text':'password';document.querySelector('.password-eye').setAttribute('aria-label',i.type==='text'?'隐藏密码':'显示密码');};
    document.getElementById('forgot-password').onclick=()=>modal({title:'联系管理员',html:'<p>如需重置员工账号，请联系门店管理员。</p>'+ (state.connection==='preview'?'<p class="muted">当前为界面演示，无需输入真实账号或密码。</p>':'<p class="muted">请使用已开通的方隅员工账号登录。</p>')});
    document.getElementById('login-help').onclick=()=>modal({title:'使用帮助',html:state.connection==='preview'?'<p>填写任意演示用户名即可预览工作台。</p><p>可依次查看获客、回复、客户和门店预设。所有操作仅改变本地演示状态。</p>':'<p>使用已开通的管理员或员工账号与密码登录。管理员需明确选择云端已绑定门店分组。勾选“记住用户名”只保存用户名，不保存密码。</p><p>登录后可保存门店预设，查看平台连接、采集状态与本机可见客户，并导出Excel；回复页可逐条保存与核对草稿，发送需另行完整核对并明确授权；当前平台暂停与许可约束继续生效。</p>'});
  }else{
    app.innerHTML=shell(mod?mod.render(state):'')+tools();
    if(mod?.bind)cleanup=mod.bind(document.getElementById('page-content'),ctx);
    bindWorkflowSummary(app,ctx);
    document.querySelectorAll('[data-switch-platform]').forEach(button=>button.addEventListener('click',()=>switchPlatform(button.dataset.switchPlatform)));
    document.getElementById('reload-workspace')?.addEventListener('click',reloadWorkspace);
    document.querySelector('.bell').onclick=()=>modal({title:'工作提醒',html:state.connection==='preview'?'<p>待回复客户 <strong>12</strong> 位，建议优先查看超高意向和高意向客户。</p><p class="muted">此处为示例提醒。</p>':'<p>请在回复页查看当前员工可见客户，选择原评论后保存与核对草稿。</p><p>真实发送需完整核对并明确授权，且须满足平台与设备条件。</p>',confirmLabel:'查看意向回复',onConfirm:()=>navigate('reply')});
    document.querySelector('.account-button').onclick=()=>{modal({title:(state.user||'演示账号')+' · 渠道运营',html:`<p>当前门店：${esc(state.store||'待管理员分配')}</p><p>${state.connection==='preview'?'演示账号的操作仅保留在当前预览。':'当前显示真实登录、门店、平台、本机客户和回复草稿；草稿核对不代表已发送。'}</p>${state.connection==='preview'?'':'<p><button type="button" id="open-development">打开网页调试</button></p>'}`,confirmLabel:state.connection==='preview'?'退出预览':'退出登录',onConfirm:()=>state.connection==='preview'?navigate('login'):logout()});document.getElementById('open-development')?.addEventListener('click',showDevelopmentLink);};
    document.querySelectorAll('[data-info]').forEach(b=>b.onclick=()=>b.dataset.info==='口吻方案'?openToneTools(ctx):openSettings(ctx));
  }
  bindCalendars(app);
  app.querySelectorAll('[data-acquisition-help]').forEach(el=>el.addEventListener('click',()=>openAcquisitionHelp(ctx)));
  document.querySelector('[data-acquire-day]')?.addEventListener('change',event=>{state.acquisitionDay=event.target.value||localDay();render();if(!state.acquisitionDaily?.ready)void readAcquisitionDays();});
  document.querySelectorAll('[data-nav]').forEach(b=>b.onclick=()=>navigate(b.dataset.nav));
  app.querySelector('[data-open-outcome-report]')?.addEventListener('click',()=>openOutcomeReport(ctx));
  document.querySelectorAll('[data-scenario]').forEach(b=>b.onclick=()=>{state.scenario=b.dataset.scenario;if(state.scenario==='normal'){state.reply=undefined;state.customers=undefined;}render();toast({normal:'已还原正常示例',empty:'查看空数据状态',loading:'查看加载状态',error:'查看失败与重试',long:'查看长评论状态'}[state.scenario]);});
  app.querySelectorAll('a[href]').forEach(a=>a.addEventListener('click',e=>{if(!a.getAttribute('href').startsWith('#')){e.preventDefault();modal({title:'查看源帖',html:'<p>本地预览展示来源信息，不打开真实平台。</p>'});}}));
  paneScroll.restore();
  showPlatformNotice();collectionMonitor.sync();
  syncPlatformPolling();
  if(state.page==='presets'&&state.connection==='connected'&&state.session&&state.storeId&&state.aiWorkbench?.scope!==workflowScope(state))queueMicrotask(()=>refreshAIRules());
  scheduleWorkspaceWarmup();
  syncCustomerLoading();
  reply.sync(state,ctx);
  if(state.page==='reply'&&state.session&&state.storeId&&!platformActorMatches(state.tonePreferences,actorKey())&&!state.tonePreferencesLoading&&state.tonePreferenceReadActor!==actorKey())queueMicrotask(readTonePreferences);
}
document.addEventListener('visibilitychange',syncPlatformPolling);
document.addEventListener('visibilitychange',updateRuntimeLabels);
window.addEventListener('focus',updateRuntimeLabels);
window.addEventListener('hashchange',()=>navigate(location.hash.slice(1)||'login'));
window.addEventListener('error',e=>console.error('Workbench:',e.message));
render();
backend.bootstrap().then(result=>{
  if(result){acceptBootstrap(result);navigate(state.session?(initialPage==='login'?'acquire':initialPage):'login');if(state.notice)toast(state.notice);}
  else{state.connection='preview';state.store='古北店';state.user='小林';navigate(initialPage);}
}).catch(error=>{state.connection='error';state.connectionError=error.message;navigate('login');}).finally(()=>{if(state.connection!=='preview')refreshRuntimeStatus();});


