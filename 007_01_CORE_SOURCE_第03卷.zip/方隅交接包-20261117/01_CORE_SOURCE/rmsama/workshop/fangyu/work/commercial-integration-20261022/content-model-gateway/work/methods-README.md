# 内容模型可信方法目录与Node校验器

来源仅为同级content-workflow-extension/workflow_methods.py，固定SHA256 `60806e678ed6a96a7f3a7a3116a20024e97ac648f59c16cf5cf0eb8838e6b094`。没有修改权威Python、父目录稿件、其他候选或生产；没有网络、模型或平台调用。

## 生产闭包及接口

仅需`server/content_methods.cjs`及相邻`server/content-methods.json`。`METHODS-PINS.json`保留评审、导出与部署核对信息；Python导出器和work测试夹具不需要放进云运行闭包。

```javascript
const {getMethod, methodDigest, validateContentOutput, CATALOG_DIGEST} = require('./content_methods.cjs');
const spec = getMethod('writing');
const methodSha = methodDigest('writing');
const clean = validateContentOutput('writing', parsedModelOutput, scopedEvidence);
```

同名别名`validateOutput`也可调用。getMethod返回完整可信spec深拷贝，包括固定instructions/outputSchema。它不接收或拼接业务资料、用户system、endpoint、模型、密钥或自定义schema。调用方必须只将可信instructions用于系统约束，将业务资料置于用户数据中。此模块不实现鉴权、预算、账号绑定、网关发起或模型失败回退。

成功校验返回独立标准JSON副本。未知方法抛Error，code为`CONTENT_METHOD_UNKNOWN`；输出违反合同为`CONTENT_OUTPUT_INVALID`；静态目录字节或来源pin不符时，模块加载即以`CONTENT_METHOD_CATALOG_CHANGED`拒绝。错误只含固定reason，不包含业务原文、密钥或模型原始输出。

## 固定摘要

- 每个methodDigest都在Python侧计算：`sha256(json.dumps(get_method(id), ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False).encode('utf-8'))`。它不是JS重新序列化后的摘要，避免schema里1e12被Python写作`1000000000000.0`而产生错误摘要。
- CATALOG_DIGEST为`5a3696cd2be46b9cf24d9be8db2e823af7860226efb4fb515a466596d36f8b31`：同一canonical算法计算catalog中除catalogDigest字段之外的完整payload。
- 原始catalog文件SHA256为`9a5dce493758bae88bcbf4e747807790e4505fb77f45f438e1363cf45a00bfdd`，校验器内固定这一字节pin；不从客户端或可变配置接受新pin。
- exporter读取权威文件后先核sha，再执行已核的同一份字节，导出17个get_method完整spec。权威版本变化需要评审后更新pin、重新导出及更新CJS目录pin，不能静默改版。

## Python语义对齐

对象字段必须恰好匹配required，所有层级禁止额外字段。字符串按Unicode码点而不是UTF-16单元计长；Cf/Cs、Python空白字符和正则数字范围从本机Python3.12/Unicode15.0的表导出，避免Node Unicode版本或trim/\d差异。输出拒异常控制符但保留换行、回车和制表符；原始证据text不执行输出字符规范化，保持连续原文引用语义。整体JSON大小包括Python默认分隔空格与ASCII转义上限。

evidence只允许`{id:{text,kind}}`，最多1000条，ID最多120码点、text最多20000码点、kind最多40码点。facts须有真实自有证据项，kind严格等于fact，quote为连续原文子串；未知/拼接引文、hypothesis冒充fact拒绝。artifact中的evidenceIds/sourceEvidenceIds也必须存在。证据查找用Map，原型继承名字不构成证据。

所有模型输出仍待人工审核；published/approved/sent等状态键和system/provider字段均不在schema中。JavaScript独有的Proxy、accessor、Symbol、隐藏属性、稀疏或带额外属性数组以及非JSON集合在值读取前拒绝；不将其当作Python dict/list。只接受有限JSON数学数值，bool不能冒充int，非整数不能用于integer字段。JavaScript解析后无法区分数字词法1.0和1，整数位置用Number.isInteger，返回JSON正规化为1，Python客户端再验为int；不宣称保留原始数值词法。原权威schema其他范围和业务字段保持不变。

## 复核与TDD证据

导出：`python -B tools/export_methods.py`。只读核对：`python -B tools/export_methods.py --check`。另加`--test-fixtures`才会生成/检查work/methods-python-oracle.json；其中example_result仅用于合成测试，标记testOnly及productionDefaultOutput=false。生产catalog和CJS没有样例结果、example_result或默认生成结果。

Node命令：`node --test tests/content-methods.test.cjs`。本机Node v22.23.4执行67项全部通过。尚未在真实云Nodejs20.19执行，也没有真实模型或部署验收。

分段红绿日志：公共API缺失→1通过；Python语义对照先11失败→63通过；JS非JSON对象防线先3失败→67通过。每个Python oracle用例的预期结果由固定来源validate_result给出，涵盖17模块、引文/假设、表情长度、空白、Unicode数字、未知引用与状态字段。另验证多字段注入、目录篡改、getter/代理不被调用、原型名字、非有限数字与非JSON集合。

当前模块只保证可信方法和结果校验。网关仍须绑定企业/账号/门店/actor/请求、预算与来源摘要，并保持未知结果不重派；这些由主窗口集成，不由本模块绕过。
