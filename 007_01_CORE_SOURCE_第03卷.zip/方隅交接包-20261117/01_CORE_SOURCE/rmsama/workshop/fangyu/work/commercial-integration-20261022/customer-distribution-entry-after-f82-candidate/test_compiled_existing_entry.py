"""Compile only the reviewed entry over the exact retained F82 dependencies.

Representative compiled data-selection test only. This is deliberately not the
new aggregate product and does not test a cloud lease or any platform login.
"""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import marshal
import os
import shutil
import struct
import subprocess
import sys
import types
import uuid
from PyInstaller.archive.readers import CArchiveReader
from PyInstaller.archive.writers import CArchiveWriter
sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
BASE = HERE.parent/'f82-standard-package-candidate/standard-held-clean-v82'
sha = lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
read = lambda path:json.loads(path.read_text('utf-8-sig'))
previous = read(HERE/'ADAPTED-ENTRY-RESULTS.json')
assert previous['status'] == 'PASS_ADAPTED_CLEAN_ENTRY_SOURCE_ONLY'
adapted = Path(previous['ownFixture'])/'standard_entry.py'
assert sha(adapted) == previous['adaptedEntrySha256']
old_portable = BASE/'dist/FangyuWorkbench'
old_exe = old_portable/'FangyuWorkbench.exe'
old_manifest = read(BASE/'FILE-MANIFEST.json')
row = next(item for item in old_manifest['files'] if item['path'] == 'FangyuWorkbench.exe')
assert sha(old_exe) == row['sha256']
root = HERE/('compiled-entry-fixture-'+uuid.uuid4().hex)
root.mkdir()
portable = root/'portable'
shutil.copytree(old_portable, portable)
new_exe = portable/old_exe.name
old = CArchiveReader(str(old_exe))
app_entries = [name for name, item in old.toc.items() if item[4] == 's'
    and not name.startswith(('pyi','pyiboot'))]
assert app_entries == ['standard_entry'], app_entries
cookie = old_exe.read_bytes()[old._end_offset-old._COOKIE_LENGTH:old._end_offset]
pylib = struct.unpack(old._COOKIE_FORMAT, cookie)[-1].rstrip(b'\0').decode('ascii')

class ReviewedEntryWriter(CArchiveWriter):
    def _write_entry(self, fp, entry):
        name, _, compress, kind = entry
        if kind == 'o':
            return super()._write_entry(fp, entry)
        if name == 'standard_entry':
            return super()._write_entry(fp, (name, str(adapted), compress, 's'))
        return self._write_blob(fp, old.extract(name), name, kind, compress=compress)

entries = [(name,None,bool(item[3]),item[4]) for name,item in old.toc.items()]
entries += [(name,None,False,'o') for name in old.options]
archive = root/'reviewed-entry.pkg'
ReviewedEntryWriter(str(archive), entries, pylib)
new_exe.write_bytes(old_exe.read_bytes()[:old._start_offset]+archive.read_bytes())
new = CArchiveReader(str(new_exe))
assert new.options == old.options
assert new.extract('PYZ.pyz') == old.extract('PYZ.pyz')
for name in old.toc:
    if name != 'standard_entry':
        assert new.extract(name) == old.extract(name), name

def normalized(code):
    if isinstance(code,types.CodeType):
        return (code.co_argcount,code.co_posonlyargcount,code.co_kwonlyargcount,
            code.co_nlocals,code.co_stacksize,code.co_flags,code.co_code,code.co_name,
            code.co_qualname,code.co_exceptiontable,tuple(normalized(v) for v in code.co_consts),
            code.co_names,code.co_varnames,code.co_freevars,code.co_cellvars)
    if isinstance(code,tuple):
        return tuple(normalized(v) for v in code)
    return code

assert normalized(marshal.loads(new.extract('standard_entry'))) == normalized(
    compile(adapted.read_bytes(),str(adapted),'exec'))
environment = dict(os.environ)
for key in ('PYTHONHOME','PYTHONPATH','VIRTUAL_ENV'):
    environment.pop(key,None)
for key in ('LOCALAPPDATA','APPDATA','TEMP','TMP'):
    folder = root/key.lower()
    folder.mkdir()
    environment[key] = str(folder)
environment['PYTHONDONTWRITEBYTECODE'] = '1'
groups = []
runs = []

def run(name,args,expected):
    result_path = root/(name+'.json')
    result = subprocess.run([str(new_exe),'--check','--result-file',str(result_path),*args],
        cwd=portable,env=environment,capture_output=True,timeout=90,
        creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
    (root/(name+'.stdout.txt')).write_bytes(result.stdout)
    (root/(name+'.stderr.txt')).write_bytes(result.stderr)
    assert result.returncode == expected,(name,result.returncode,result.stderr[-500:])
    report = read(result_path)
    assert report['status'] == ('PASS' if expected == 0 else 'FAIL'),report
    runs.append({'case':name,'exitCode':result.returncode,'report':report,
        'resultSha256':sha(result_path)})
    return report

default = run('default-own-directory',[],0)
assert default['frozen'] is True
own_root = Path(environment['LOCALAPPDATA'])/'FangyuWorkbenchStandard'
assert (own_root/'data').is_dir() and (own_root/'state').is_dir()
assert not (own_root/'data/workspace.sqlite3').exists()
groups.append('actual compiled default verifies full original public closure and uses only isolated ordinary directories')
existing = Path(previous['ownFixture'])/'existing-project'
descriptor = existing/'work/ui-native-r57/state/production-workspace.json'
existing_data = Path(previous['ownFixture'])/'existing-data'
protected = [descriptor,existing_data/'workspace.sqlite3',existing_data/'assistant/device.dpapi']
before = {str(p):sha(p) for p in protected}
explicit = run('explicit-original-workspace',[
    '--existing-project-root',str(existing),'--binding-sha256',sha(descriptor)],0)
assert explicit['frozen'] is True
assert (existing/'work/ui-native-r57/state/lifecycle').exists() or any(
    p.is_file() and p.name != 'production-workspace.json'
    for p in (existing/'work/ui-native-r57/state').rglob('*'))
assert {str(p):sha(p) for p in protected} == before
groups.append('actual compiled explicit path reads original native DPAPI descriptor and preserves existing database/vault/binding bytes')
ordinary_before = {p.relative_to(own_root).as_posix():sha(p)
    for p in own_root.rglob('*') if p.is_file()}
bad = run('wrong-binding-pin',[
    '--existing-project-root',str(existing),'--binding-sha256','0'*64],1)
assert '原工作资料设置已经变化' in bad['message']
assert {p.relative_to(own_root).as_posix():sha(p)
    for p in own_root.rglob('*') if p.is_file()} == ordinary_before
assert {str(p):sha(p) for p in protected} == before
groups.append('actual compiled wrong binding pin fails without creating/falling back to another customer database')
result = {'status':'PASS_REPRESENTATIVE_COMPILED_EXISTING_DATA_ENTRY',
    'utc':datetime.now(timezone.utc).isoformat(),'groupCount':len(groups),'groups':groups,
    'originalExeSha256':sha(old_exe),'derivedExeSha256':sha(new_exe),
    'adaptedEntrySha256':sha(adapted),'sourceEntryEvidenceSha256':sha(HERE/'ADAPTED-ENTRY-RESULTS.json'),
    'originalPyzBytesUnchanged':True,'allOtherArchiveEntriesExact':True,
    'entryNormalizedCodeTypeIncludesExceptionTableExact':True,
    'existingProtectedBytesExact':True,'actualWindowsDpapi':True,
    'realCompiledExecutions':len(runs),'runs':runs,'ownFixture':str(root),
    'actualNewAggregateProductCompiled':False,'serviceOrCloudLeaseExercised':False,
    'platformModelNativeRequests':0,'productionOrRealSessionsRead':False,
    'originalFormalOrInstalledModified':False,'newAuthorSignatureClaimed':False,
    'next':'Reapply the reviewed selector during final aggregate build and test new readlease/entry together.'}
(HERE/'COMPILED-ENTRY-RESULTS.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n','utf-8')
print(json.dumps({k:v for k,v in result.items() if k not in ('runs','ownFixture')},ensure_ascii=False))
