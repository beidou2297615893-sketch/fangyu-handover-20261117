# 客户读取用途候选：完成受信接点与真实编译验证

本候选只写本目录，没有修改 F82、正式安装、生产数据或原许可。源码候选11文件：6个原源有界改动、1个新 carrier、4份新用途材料 JSON。目标是抖音账号连接与原视频评论的 customer_distribution_read 分发用途，不是整体商业产品批准。

## 实际通过

- 最终真实 EXE：compiled-probe-final/dist/FangyuWorkbench/factory-f73ab4861a114d3cb2e4724ed103f823/RESULTS.json，12组 PASS、3次自有 HTTP、0平台/模型/真实云请求/浏览器进程，全部自有服务已关闭。
- 实际原 standard_entry 的 load_host 校验完整3860文件闭包及原 RELEASE，原 host/create_backend、原 AppServer/Core/Store、活动账号 _components 和原评论 policy 进入 customer_distribution_read。EXE复用成熟普通 F82 PyInstaller spec，只替换自有 probe 入口与 console；没有生成或安装商业包。
- 实际走原 Service.bind → DPAPI DeviceVault → 原 _run/Runner → 原 DeviceSession → 原账号归属 admission。仅替换外部云响应边界为自有合成合同响应；没有手塞 executor、device/session、内部 scope、QA permit 或 release_approved。结果中 qaIdentityInjected=False 指未使用内部 QA 身份/许可通道，并非没有自有合成员工与账号夹具。
- 未绑定设备仍拒绝。云端 hold、禁用员工、外租户、错公司、材料篡改、hardlink、source-mode混用、原403设备撤销、stop均不能由材料 scope 覆盖；public_send_hold=True、release_approved=False、小红书hold保持。
- 原 HTTP 不增加 scope/review/approval 入口，伪造动作由原 host 返回403。抖音搜索及 XHS review均未获得本候选许可。
- 无 index：实际 compiled 中由受信QA调用原 host 时省去该资源映射，仍 scope=None、组件拒绝。它是原host分支代表；完整无index包的实际EXE证据沿既有 F82 package independent review，不冒称本轮另编了一份无index商业包。
- 最终源码真实非frozen入口另2组 PASS：compiled-probe-final/payload/source-factory-921fe09da87a4d2b90f6a73f306536b4/RESULTS.json。同包 index存在，host不创建/导入carrier，原pilot/source公司合同仍 internal_self_use_read，账号/评论均resolve成功；另外故意误挂typed frozen载体时拒绝，移除后恢复原internal。没有把源码正常启动和拒绝误用混为一项。

## 接点与材料

原 host 只有实际 sys.frozen 才读取并创建分发 carrier。loader/index/每purpose文档都由原 read_public 与 RELEASE 固定；carrier 绑定实际 executable/project/release 根、原公司环境与公开发送hold。每purpose独立 source、active vendor、运行库、许可、来源材料及大小/SHA；范围79与88条材料。

新 carrier 仅把受信客户用途传到原 PlatformRuntime/AppServer。原连接 _binding、_DouyinConnectionCall、DouyinConnectionService、原 DeviceSession/权限/锁/生命周期未改；评论原 fixed命令、Bridge类型、主页面20条、禁搜索/回复/私信、身份前后核对限制保持。AST-BOUNDARY-AUDIT 记录每个原函数边界；换行被自有写入器统一，未冒称整文件旧字节等价。

XHS预留接口 authority.runtime_license_review(server,'xiaohongshu_guarded_read') 只返回 None 或原 RuntimeLicensePolicy schema。原 frozen material_root 仍是主EXE目录；原policy独立验证 CLI artifact/tree/guard/四材料，不另造XHS授权策略。目前不附该review，不改变 internal_qa_only guard 或 natural身份/会话/读取用途。

## 保留的 RED 与修复

早期 source 测试负例把原403当400、且尝试JSON解析原HTML拒绝回执；只修自有断言与解析，未改产品。

第一次 actual compiled 负例修改公司平台hold，实际先被更早的原 DeviceSession 配置绑定拒绝；调整为准确的 xhs_app_context_unavailable 预期，保留此早期原守卫。

第二次 actual compiled 的 hardlink 反例揭示新 carrier 只复用原 _plain 时未拒绝多链接。仅在新 carrier 增加完整父路径、regular-file、nlink=1与读取后身份重核；原 RuntimeLicensePolicy 不变。按修后实际字节重新派生并编译。中间 compiled-probe-3 EXE因随后补源码入口条件，没有作为最终成功证据。所有旧日志、RED与派生目录都保留。

## 合版与未验证

详见 INTERFACE.md、MERGE-REPIN.md。新文档是本候选准确派生字节的材料样本；root合版后需要重新计算旧用途依赖图、SOURCE、backend-dependencies、新用途材料、RELEASE/SHIPPED及实际编译入口，再独审。不能把本轮成功代替未来合版成功，不能全局替换scope。

仍未验证：真实云员工/设备注册、本人自然登录与账号网页、实际Native/WebView进程与签名、真实平台读取与规则授权、实际采集速度、第二普通电脑。普通完整商业包与安装/正式运行未变更。软件开源许可、用户工程授权、云身份、平台权限与真人验收分别记录；未发送评论、私信或发布。

附：公开小红书来源核对里“28个包源码文件”精确构成为27个Python模块＋1个py.typed，root后继已证明实际CLI EXE PYZ的27模块与发布源码编译等价。本候选不重复ASR或XHS材料研究。
