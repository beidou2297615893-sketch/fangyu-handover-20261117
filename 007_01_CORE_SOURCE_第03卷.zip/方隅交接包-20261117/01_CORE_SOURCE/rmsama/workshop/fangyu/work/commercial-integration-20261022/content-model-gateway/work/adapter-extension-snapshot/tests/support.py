"""Real Store and frozen ContentWorkbench fixtures for the public workflow seam.

Only the injected model callable and host authority callback are test boundaries.
No production paths, customer databases or internal implementation stubs are used.
"""
from __future__ import annotations

from copy import deepcopy
import hashlib
import importlib
import importlib.util
import json
from pathlib import Path
import sys
import tempfile
import uuid


ROOT = Path(__file__).resolve().parents[1]
BASELINE = Path(__file__).resolve().parent / 'baseline'
READ_ACTIONS = frozenset(('content_workspace_read', 'content_knowledge_search', 'content_methods_read'))
PRESERVED_ENTITIES = ('customers', 'leads', 'replies', 'tasks', 'ai_assessments',
                      'manual_reviews', 'rules', 'sop')


def verify_baseline():
    manifest = json.loads((BASELINE / 'BASELINE-SHA256.json').read_text('utf-8'))
    for row in manifest['files']:
        path = (BASELINE / row['snapshotPath']).resolve()
        if not path.is_relative_to(BASELINE.resolve()):
            raise RuntimeError('Test baseline path is outside the frozen directory')
        if hashlib.sha256(path.read_bytes()).hexdigest() != row['sha256']:
            raise RuntimeError('Frozen baseline changed: ' + row['snapshotPath'])
    return manifest


verify_baseline()
for path in (str(BASELINE), str(ROOT)):
    if path not in sys.path:
        sys.path.insert(0, path)

base_module = importlib.import_module('content_workbench')
if Path(base_module.__file__).resolve() != (BASELINE / 'content_workbench.py').resolve():
    raise RuntimeError('Tests must import the frozen ContentWorkbench, never a live checkout')
ContentWorkbench = base_module.ContentWorkbench
ContentError = base_module.ContentError

_store_spec = importlib.util.spec_from_file_location('workflow_frozen_real_store', BASELINE / 'store.py')
_store_module = importlib.util.module_from_spec(_store_spec)
sys.modules[_store_spec.name] = _store_module
_store_spec.loader.exec_module(_store_module)
Store = _store_module.Store


class WorkflowFixture:
    """One tenant and real temporary SQLite Store; all records are synthetic.

    Public helper contract:
      store, user, account, authority
      make(model_adapter=None), call(workbench, action, **fields)
      read(workbench) -> workspace, close()

    ``call`` uses the latest scoped workspace revision unless explicitly supplied.
    Replays should pass the original expectedRevision and requestId explicitly.
    """

    def __init__(self):
        temp_root = Path('C:\\积木软件工坊\\项目\\方隅公寓客户版\\work\\commercial-integration-20261022\\content-model-gateway\\work\\adapter-runtimes')
        temp_root.mkdir(parents=True, exist_ok=True)
        self._temp_root = temp_root.resolve()
        self._temp = tempfile.TemporaryDirectory(prefix='workflow-', dir=self._temp_root)
        self.directory = Path(self._temp.name).resolve()
        self.store = Store(self.directory / 'data')
        self.store_id = 'fixture-store-a'
        self.user = dict(id='fixture-user-a', username='fixture-operator-a', role='operator',
                         tenant_id='fixture-tenant-a', cloud_bound=True, disabled=False)
        self.other_user = {**self.user, 'id': 'fixture-user-b', 'username': 'fixture-operator-b'}
        self.account = dict(id='fixture-account-a', tenant_id=self.user['tenant_id'],
                            cloud_owner=self.user['username'], platform='xiaohongshu',
                            store_id=self.store_id, display_name='虚构内容账号甲')
        self.second_account = {**self.account, 'id': 'fixture-account-b', 'display_name': '虚构内容账号乙'}
        self.foreign_account = {**self.account, 'id': 'fixture-account-other',
                                'cloud_owner': self.other_user['username']}
        self._authority_id = 'fixture-host-session'
        self.store.put('users', deepcopy(self.user))
        self.store.put('users', deepcopy(self.other_user))
        for account in (self.account, self.second_account, self.foreign_account):
            self.store.put('accounts', deepcopy(account))
        self.store.put('stores', dict(id=self.store_id, tenant_id=self.user['tenant_id'],
                                     name='虚构门店', disabled=False))
        self.store.put('fixture_host_authority', dict(id=self._authority_id,
            tenant_id=self.user['tenant_id'], user_id=self.user['id'],
            username=self.user['username'], store_id=self.store_id, active=True))
        for entity in PRESERVED_ENTITIES:
            self.store.put(entity, dict(id='preserved-' + entity, tenant_id=self.user['tenant_id'],
                marker='保留的虚构既有客户业务记录', payload={'original': True, 'entity': entity},
                text='原始评论与人工结论均保留', grade='manual-fixture'))
        self.initial_customer_records = self.customer_records()

    def authority(self, db, actor, scope, save):
        """Host-owned permission boundary backed by actual fixture Store records."""
        def get(entity, key):
            row = db.execute('SELECT body FROM records WHERE entity=? AND id=? AND tenant_id=?',
                             (entity, key, scope.tenant_id)).fetchone()
            return json.loads(row['body']) if row else None
        host = get('fixture_host_authority', self._authority_id)
        store = get('stores', scope.store_id)
        return bool(type(save) is bool and host and host.get('active') is True
                    and host.get('user_id') == actor.get('id')
                    and host.get('username') == actor.get('username')
                    and host.get('store_id') == scope.store_id
                    and store and store.get('disabled') is not True)

    def make(self, model_adapter=None):
        module = importlib.import_module('content_workflow')
        return module.ContentWorkflowWorkbench(self.store,
            root_dir=self.directory / 'content-artifacts', model_adapter=model_adapter)

    def read(self, workbench):
        return workbench.execute('content_workspace_read', deepcopy(self.user), self.store_id,
            {'accountId': self.account['id'], 'platform': self.account['platform']},
            authority_check=self.authority)['workspace']

    def call(self, workbench, action, **fields):
        data = {'accountId': self.account['id'], 'platform': self.account['platform'], **fields}
        if action not in READ_ACTIONS:
            if 'expectedRevision' not in data:
                workspace = workbench.execute('content_workspace_read', deepcopy(self.user), self.store_id,
                    {k: data[k] for k in ('accountId', 'platform')},
                    authority_check=self.authority)['workspace']
                data['expectedRevision'] = workspace['revision']
            data.setdefault('requestId', uuid.uuid4().hex)
        return workbench.execute(action, deepcopy(self.user), self.store_id, data,
                                 authority_check=self.authority)

    def customer_records(self):
        return {entity: sorted(self.store.list(entity, self.user['tenant_id']),
                               key=lambda row: row['id']) for entity in PRESERVED_ENTITIES}

    def close(self):
        directory = Path(self._temp.name).resolve()
        if not directory.is_relative_to(self._temp_root) or directory == self._temp_root:
            raise RuntimeError('Refusing to clean a fixture outside the task test directory')
        self._temp.cleanup()
