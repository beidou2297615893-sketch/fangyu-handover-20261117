from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,zipfile
D=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_text('utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
summary=read(D/'CODE-PACKAGE.json')
assert summary['status']=='HELD_CODE_CANDIDATE_NOT_DEPLOYED'
index=read(D/'CODE-PACKAGE-FILES.json')
archive=D/'customer-read-cloud-held.zip'
assert sha(archive)==summary['codeZipSha256']
with zipfile.ZipFile(archive) as z:
    actual={}
    for info in z.infolist():
        assert not info.is_dir() and info.filename not in actual
        raw=z.read(info)
        actual[info.filename]={'path':info.filename,'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw)}
assert sorted(actual.values(),key=lambda r:r['path'])==index
assert len(index)==5617
baseline=read(D.parent/'content-cloud-v3-final2/FILES-SHA256.json')
before={r['path']:r for r in baseline}
changed=[name for name in sorted(set(before)|set(actual)) if name not in before or name not in actual or before[name]['sha256']!=actual[name]['sha256']]
assert changed==sorted(['devices.cjs','index.js','release.cjs','service.cjs','customer_read_release.cjs'])
result={'status':'HELD_PACKAGE_EXACT_ARCHIVE_VERIFIED','utc':datetime.now(timezone.utc).isoformat(),
    'files':len(index),'actualArchiveCrcAndHashesVerified':True,'changedPaths':changed,
    'codeZipSha256':sha(archive),'productionOrEnvironmentWritten':False,
    'sourceServiceReviewSha256':sha(D/'ROOT-SOURCE-SERVICE-REVIEW.json'),
    'manualDependency':'Existing CloudBase CLI login/credential recovery; preserve breakpoint, no retry loop.',
    'rootLiveExecs':[],'notCommercialOrRealPlatformAcceptance':True}
(D/'CODE-PACKAGE-VERIFIED.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n','utf-8')
print(json.dumps(result,ensure_ascii=False))
