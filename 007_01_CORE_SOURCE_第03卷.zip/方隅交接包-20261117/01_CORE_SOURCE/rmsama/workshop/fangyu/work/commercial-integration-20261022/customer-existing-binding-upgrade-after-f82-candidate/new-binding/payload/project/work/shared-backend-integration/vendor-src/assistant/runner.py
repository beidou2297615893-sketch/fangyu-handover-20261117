"""Single-worker outbox: a command is recorded BEFORE execution, never replayed.

The poll thread remains available for heartbeats while the platform worker runs.
Raw platform logs, cookies and credentials must never be executor return values.
"""
import json,sqlite3,time,threading
import re
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from integrations import IntegrationError
from .ai_workflow import AIContextRequired
from .transport import CloudError
from core.page_errors import PageOperationFailure, PAGE_ERROR_MESSAGES
from core.response_journal import ResponseJournal,payload_hash

SAFE_AI_MESSAGES={
    'AI_PROVIDER_BALANCE':'企业 AI 余额不足，充值后点继续分析',
    'AI_PROVIDER_AUTH':'企业 AI 密钥无效，请管理员检查后点继续分析',
    'AI_DAILY_BUDGET':'今日 AI 预算已用完，评论已保留待分析',
    'AI_NOT_CONFIGURED':'请管理员配置企业 AI',
                        'AI_CONFIG_CHANGED':'企业 AI 配置已变化，请核对新模型后继续',
    'AI_DISABLED':'企业 AI 已暂停，评论已保留待分析',
    'AI_CONTEXT_REQUIRED':'AI 分析缺少必要上下文，请补齐后继续分析',
    'AI_INVALID_OUTPUT':'AI 返回结果未通过校验，评论仍待分析',
    'AI_BILLING_UNKNOWN':'上次 AI 费用待核实，暂未重新请求',
    'AI_LEDGER_CONFLICT':'AI 用量记录暂时无法核对，请稍后查看',
    'AI_INVALID_INPUT':'AI 分析内容未通过校验，请检查任务信息',
    'AI_UNPRICED_MODEL':'当前 AI 模型尚未配置计费价格，请联系管理员',
    'AI_TENANT_MISMATCH':'企业 AI 权限校验失败，请联系管理员',
    'AI_ADMIN_REQUIRED':'当前账号没有企业 AI 管理权限',
    'AI_PROVIDER_TIMEOUT':'企业 AI 请求超时，请稍后查看任务状态',
    'AI_PROVIDER_UNAVAILABLE':'企业 AI 服务暂不可用，请稍后查看任务状态',
    'AI_PROVIDER_BODY_TOO_LARGE':'企业 AI 返回内容超出限制，评论仍待分析',
    'AI_PROVIDER_INVALID_RESPONSE':'企业 AI 返回内容无效，评论仍待分析',
    'AI_PROVIDER_REJECTED':'企业 AI 拒绝了本次请求，请联系管理员',
    'AI_IN_PROGRESS':'同一内容正在分析，请稍后查看',
    'AI_TRANSACTION_UNAVAILABLE':'企业 AI 记录暂不可用，请稍后查看',
    'AI_SERVICE_UNAVAILABLE':'企业 AI 服务暂不可用，请稍后查看',
    'AI_UNAVAILABLE':'企业 AI 暂不可用，请稍后查看',
    'AI_AUTH_REQUIRED':'企业登录已失效，请重新登录后继续分析',
}

def failure_result(error):
    # The exception text may contain SDK/provider bodies. Only these trusted AI
    # exception types and exact local codes may cross the device result boundary.
    if type(error) is PageOperationFailure:
        code=error.code
        message=PAGE_ERROR_MESSAGES.get(code) if type(code) is str else None
        if message:return {'code':code,'retryable':False,'error':message,'message':message}
    if isinstance(error,(IntegrationError,AIContextRequired)):
        code=getattr(error,'code',None)
        message=SAFE_AI_MESSAGES.get(code) if isinstance(code,str) else None
        if message:return {'code':code,'retryable':False,'error':message,'message':message}
    return {'code':'execution_error','retryable':False}

HOLD_ALLOWED_ACTIONS=frozenset(('diagnostics','update_check','keyword_suggest','task_stop',
    'leads_list','lead_score','reply_status','reply_prepare','reply_pending','reply_approve','workspace_state',
    'continuous_pause','continuous_status','keyword_recommend','keyword_library','intent_correct','lead_handle',
    'intent_analyze_pending','update_download','update_install','update_status',
    'reply_review','reply_queue_prepare','reply_queue_cancel','reply_queue_status'))

class Journal:
    def __init__(self,path):
        self.db=sqlite3.connect(path)
        self.db.execute('PRAGMA synchronous=FULL')
        self.db.execute('CREATE TABLE IF NOT EXISTS executions(id TEXT PRIMARY KEY,state TEXT NOT NULL,result TEXT)')
        self.db.execute("UPDATE executions SET state='ready',result=? WHERE state='claimed'",(json.dumps({'status':'failed','result':{'code':'execution_uncertain','retryable':False}}),))
        self.db.commit()

    def claim(self,ident):
        try:self.db.execute('INSERT INTO executions VALUES (?, ?, NULL)',(ident,'claimed'));self.db.commit();return True
        except sqlite3.IntegrityError:return False

    def complete(self,ident,outcome):
        self.db.execute("UPDATE executions SET state='ready',result=? WHERE id=?",(json.dumps(outcome,ensure_ascii=False),ident));self.db.commit()

    def pending(self):return self.db.execute("SELECT id,result FROM executions WHERE state='ready' LIMIT 1").fetchone()
    def acknowledge(self,ident):self.db.execute("UPDATE executions SET state='sent',result=NULL WHERE id=?",(ident,));self.db.commit()
    def close(self):self.db.close()

class AssistantRunner:
    def __init__(self,cloud,token,journal,execute,version='unknown',on_revoke=lambda:None,
                 on_hold=lambda:None,on_resume=lambda:None,require_release_state=False,initial_hold=False,
                 platform_qa_device_id='',on_permissions=lambda value:None,
                 on_qa_continuous=lambda _allowed,_remaining,_started:None,
                 contact_journal=None,contact_tenant='',contact_owner='',on_contact_sync=lambda _error:None,
                 contact_sync_autostart=True,portable_employee_release=False,
                 employee_device_id='',on_employee_release=lambda _allowed,_seconds,_started:None,
                 accept_commands=True,workbench_source_release='',*,
                 customer_read_request=None,on_customer_read_release=lambda _lease:None):
        if workbench_source_release not in ('','fangyu-admin-local-v1'):
            raise ValueError('source release marker invalid')
        self.customer_read_request=customer_read_request
        self.customer_read_reason=''
        self.on_customer_read_release=on_customer_read_release
        self.workbench_source_release=workbench_source_release
        if type(accept_commands) is not bool:raise ValueError('指令接收模式无效')
        self.accept_commands=accept_commands
        self.cloud=cloud;self.token=token;self.journal=journal;self.execute=execute;self.version=version
        self.worker=ThreadPoolExecutor(max_workers=1,thread_name_prefix='platform-worker')
        self.future=None;self.running_id=None;self.revoked=False;self.on_revoke=on_revoke
        self.on_hold=on_hold;self.on_resume=on_resume
        self.require_release_state=require_release_state;self.hold_active=initial_hold;self.hold_notified=False
        self.platform_qa_device_id=platform_qa_device_id
        self.on_permissions=on_permissions
        self.on_qa_continuous=on_qa_continuous
        self.portable_employee_release=portable_employee_release
        self.employee_device_id=employee_device_id
        self.on_employee_release=on_employee_release
        self.on_reply_trial=lambda _value,_started:None
        self.contact_journal=contact_journal;self.contact_tenant=contact_tenant;self.contact_owner=contact_owner
        self.response_journal=ResponseJournal(contact_journal.store) if contact_journal else None
        self.on_contact_sync=on_contact_sync
        self.contact_error='';self.response_error=''
        self.contact_stop=threading.Event()
        self.contact_thread=None
        if contact_sync_autostart and self.contact_journal and self.contact_tenant and self.contact_owner:
            self.contact_thread=threading.Thread(target=self._contact_loop,name='contact-sync',daemon=True)
            self.contact_thread.start()
        self.qa_continuous_max_batches=2

    def step(self):
        if self.revoked:return 60
        try:
            if self.future and self.future.done():
                try:value=self.future.result();outcome={'status':'succeeded','result':value}
                except Exception as error:outcome={'status':'failed','result':failure_result(error)}
                self.journal.complete(self.running_id,outcome);self.future=None;self.running_id=None
            pending=self.journal.pending() if self.accept_commands else None
            delivery_error=None
            if pending:
                ident,raw=pending;outcome=json.loads(raw)
                try:self.cloud.call('device_result',{'command_id':ident,**outcome},self.token)
                except CloudError as error:
                    if error.status==413:
                        self.journal.complete(ident,{'status':'failed','result':{'code':'result_too_large','retryable':False}})
                    if error.status in (401,403):raise
                    delivery_error=error
                else:self.journal.acknowledge(ident)
            # A failed receipt must not starve the active task's heartbeat or stop command.
            # Do not claim new business work while its predecessor's result is unacknowledged.
            poll_started=time.monotonic()
            poll={'version':self.version,'running_id':self.running_id,
                  'busy':not self.accept_commands or self.future is not None or delivery_error is not None}
            if self.workbench_source_release:
                poll['workbench_source_release']=self.workbench_source_release
            summary=self._contact_sync_summary()
            if summary is not None:poll['contact_sync']=summary
            from .customer_read_lease import poll_fields,from_heartbeat
            poll.update(poll_fields(self.customer_read_request,self))
            response=self.cloud.call('device_poll',poll,self.token)
            read_lease=from_heartbeat(self.customer_read_request,self,response,poll_started)
            self.on_customer_read_release(read_lease)
            read_value=response.get('customer_read_release')
            read_reason=read_value.get('reason') if type(read_value) is dict else None
            self.customer_read_reason=('ALLOWED' if read_lease is not None else read_reason
                if read_reason in ('POLICY_DISABLED','PROTOCOL_MISMATCH','VERSION_MISMATCH',
                    'DEVICE_REVOKED','OWNER_INACTIVE','ROLE_INELIGIBLE','DEVICE_OFFLINE','COMPANY_MISMATCH')
                else 'UNCONFIRMED')
            self.on_reply_trial(response.get('reply_trial'),poll_started)
            if isinstance(response.get('owner_permissions'),dict):self.on_permissions(response['owner_permissions'])
            held=response.get('safety_hold') is True or (self.require_release_state and response.get('safety_hold') is not False)
            if self.platform_qa_device_id:
                held=(held or response.get('safety_hold') is not False
                      or response.get('platform_qa_device_id')!=self.platform_qa_device_id
                      or response.get('platform_qa_version')!='1.1.7-qa.1' or self.version!='1.1.7-qa.1')
            if self.customer_read_request is not None:
                held=held or read_lease is None
            release=response.get('employee_release')
            self.employee_release_reason=release.get('reason','') if isinstance(release,dict) else ''
            employee_seconds=release.get('lease_seconds') if isinstance(release,dict) else None
            employee_allowed=(self.portable_employee_release
                and response.get('safety_hold') is False
                and isinstance(release,dict) and release.get('allowed') is True
                and bool(self.employee_device_id) and release.get('device_id')==self.employee_device_id
                and self.version=='1.1.8-pilot.1' and release.get('version')==self.version
                and release.get('continuous_read') is True
                and type(employee_seconds) is int and 0<employee_seconds<=45
                and poll_started+employee_seconds>time.monotonic())
            if self.workbench_source_release:
                employee_allowed=(employee_allowed
                    and release.get('workbench_source_release')==self.workbench_source_release
                    and release.get('platforms')==['xiaohongshu','douyin'])
            if self.portable_employee_release:
                held=held or not employee_allowed
            if held:
                self.qa_continuous_max_batches=2
                self.on_qa_continuous(False,0,poll_started)
                if self.portable_employee_release:self.on_employee_release(False,0,poll_started)
                self.hold_active=True
                if not self.hold_notified:
                    self.on_hold();self.hold_notified=True
            elif self.hold_active:
                self.on_resume();self.hold_active=False;self.hold_notified=False
            if not held:
                if self.portable_employee_release:
                    self.on_employee_release(True,employee_seconds,poll_started)
                remaining=response.get('continuous_qa_remaining_seconds')
                authorized=(self.platform_qa_device_id and response.get('continuous_qa') is True
                    and type(remaining) is int and 0<remaining<=1800)
                # Only an authenticated heartbeat with both exact mode fields
                # can remove the legacy two-batch limit. Old QA remains two.
                self.qa_continuous_max_batches=(0 if authorized
                    and response.get('continuous_qa_mode')=='device_readonly'
                    and type(response.get('continuous_qa_max_batches')) is int
                    and response['continuous_qa_max_batches']==0 else 2)
                self.on_qa_continuous(bool(authorized),remaining if authorized else 0,poll_started)
            command=response.get('command') if self.accept_commands else None
            if command:
                control=command.get('control') is True and command.get('action')=='task_stop'
                if held and command.get('action') not in HOLD_ALLOWED_ACTIONS:
                    if self.journal.claim(command['id']):
                        self.journal.complete(command['id'],{'status':'failed','result':{'code':'safety_hold','retryable':False}})
                elif self.future and not control:raise RuntimeError('Cloud assigned concurrent work')
                elif control and self.journal.claim(command['id']):
                    try:outcome={'status':'succeeded','result':self.execute(command)}
                    except Exception:outcome={'status':'failed','result':{'code':'stop_failed','retryable':False}}
                    self.journal.complete(command['id'],outcome)
                elif not control and self.journal.claim(command['id']):
                    self.running_id=command['id'];self.future=self.worker.submit(self.execute,command)
            if delivery_error:raise delivery_error
            return max(1,min(30,int(response.get('poll_after',15))))
        except CloudError as error:
            self.on_customer_read_release(None)
            if error.status in (401,403):self.revoked=True;self.on_revoke()
            raise

    def _contact_loop(self):
        while not self.contact_stop.is_set() and not self.revoked:
            try:
                self._sync_contacts()
                if not self.revoked:self._sync_responses()
            except Exception:
                self.contact_error='联系记录同步待核实';self._emit_contact_sync()
            if self.contact_stop.wait(30):break

    def _contact_sync_summary(self):
        if not self.contact_journal or not self.response_journal or not self.contact_tenant or not self.contact_owner:
            return None
        try:
            contacts=self.contact_journal.status(self.contact_tenant,self.contact_owner)
            responses=self.response_journal.status(self.contact_tenant,self.contact_owner)
            values={'pending_contacts':max(0,contacts['unsynced']-contacts['needs_identity']),
                    'needs_identity':contacts['needs_identity'],
                    'pending_responses':responses['pending'],'blocked_responses':responses['blocked']}
            return values if all(type(value) is int and 0<=value<=1000000 for value in values.values()) else None
        except Exception:
            return None

    def _emit_contact_sync(self):
        self.on_contact_sync('；'.join(value for value in (self.contact_error,self.response_error) if value))

    def _sync_contacts(self):
        if not self.contact_journal or not self.contact_tenant or not self.contact_owner:return
        events=self.contact_journal.pending(self.contact_tenant,self.contact_owner,5)
        if not events:
            self.contact_error='';self._emit_contact_sync()
            return
        try:
            response=self.cloud.call('contact_events_sync',{'events':events},self.token)
            accepted=response.get('accepted_event_ids')
            if not isinstance(accepted,list) or any(not isinstance(item,str) for item in accepted):
                raise ValueError('Invalid contact sync receipt')
            expected={event['event_id'] for event in events}
            if not set(accepted).issubset(expected):raise ValueError('Contact sync receipt contained unknown ID')
            self.contact_journal.acknowledge(self.contact_tenant,self.contact_owner,accepted)
            self.contact_error='' if len(accepted)==len(events) else '部分联系记录尚未同步'
            self._emit_contact_sync()
        except CloudError as error:
            if error.code=='CONTACT_SENDER_UNCLAIMED':
                self.contact_error='发送账号身份未确认，联系记录尚未同步'
            else:self.contact_error='联系记录尚未同步'
            self._emit_contact_sync()
            if error.status in (401,403) and error.code!='CONTACT_SENDER_UNCLAIMED':
                self.revoked=True;self.on_revoke()
        except Exception:
            self.contact_error='联系记录同步待核实';self._emit_contact_sync()

    def _sync_responses(self):
        if not self.response_journal or not self.contact_tenant or not self.contact_owner or self.revoked:return
        pending=self.response_journal.pending(self.contact_tenant,self.contact_owner,5)
        if not pending:
            if self.response_journal.status(self.contact_tenant,self.contact_owner)['blocked']:
                self.response_error='客户回应证据待人工核对，尚未归档'
            else:self.response_error=''
            self._emit_contact_sync()
            return
        if any(not self.contact_journal.is_uploaded(self.contact_tenant,self.contact_owner,row['sent_event_id'])
               for row in pending):
            self.response_error='客户回应等待发送记录同步';self._emit_contact_sync();return
        expected={row['observation_id']:payload_hash(row) for row in pending}
        try:
            result=self.cloud.call('contact_responses_sync',{'observations':pending},self.token)
            if not isinstance(result,dict) or type(result.get('count')) is not int or result['count']!=len(pending):
                raise ValueError('Invalid response ACK count')
            accepted=result.get('accepted')
            ids=result.get('accepted_observation_ids')
            if (not isinstance(accepted,list) or not isinstance(ids,list) or len(accepted)!=len(pending) or
                    len(ids)!=len(pending) or len(set(ids))!=len(ids) or set(ids)!=set(expected)):
                raise ValueError('Invalid response ACK IDs')
            receipts={}
            for row in accepted:
                if (not isinstance(row,dict) or set(row)!={'observation_id','customer_id','reused','payload_hash'} or
                        row.get('observation_id') not in expected or row['observation_id'] in receipts or
                        not isinstance(row.get('customer_id'),str) or
                        not re.fullmatch(r'cu_[a-f0-9]{64}',row['customer_id']) or
                        type(row.get('reused')) is not bool or
                        row.get('payload_hash')!=expected[row['observation_id']]):
                    raise ValueError('Invalid response ACK item')
                receipts[row['observation_id']]=row['payload_hash']
            if set(receipts)!=set(expected):raise ValueError('Incomplete response ACK')
            self.response_journal.acknowledge(self.contact_tenant,self.contact_owner,receipts)
            self.response_error='';self._emit_contact_sync()
        except CloudError as error:
            self.response_error='客户回应尚未同步'
            if error.code in ('CONTACT_RESPONSE_UNVERIFIED','CONTACT_RESPONSE_CONFLICT','CONTACT_INVALID_INPUT'):
                self.response_journal.block(self.contact_tenant,self.contact_owner,expected,error.code)
                self.response_error='客户回应证据待人工核对，尚未归档'
            self._emit_contact_sync()
            if error.status in (401,403):
                self.revoked=True;self.on_revoke()
        except Exception:
            self.response_error='客户回应同步待核实';self._emit_contact_sync()

    def close(self):
        self.contact_stop.set()
        if self.contact_thread:self.contact_thread.join(timeout=10)
        self.worker.shutdown(wait=True,cancel_futures=True)
