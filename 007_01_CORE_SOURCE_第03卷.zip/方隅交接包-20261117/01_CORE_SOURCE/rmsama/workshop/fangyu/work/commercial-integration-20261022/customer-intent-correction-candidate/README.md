# 人工纠错候选

先读 `HANDOFF.md`、`CONTRACT.md`、`PATCH-MANIFEST.json` 和 `DELIVERY.json`。

本目录是源码候选及合成验证证据，没有安装/启动入口。`candidate/` 是 9 份建议源文件，`before/` 保留 v66 原字节，`source-view/` 仅供原客户模块固定依赖验证。不要整目录复制到工程；root 仅合并 `integration.patch` 的必要 hunk，并保留独立候选的现有改动。

9 份源文件均已列入 `FINAL-FILES-SHA256.json`。最小补丁的 SHA256 为 `5aa3d3ae0b1d8e8779026af2a6b6fcfb4bc4288ff727bc302d0ab3779079e32b`。若用 Git，应以命令级 `-c core.autocrlf=false` 保留原字节，不改用户全局配置。

路径：`C:/积木软件工坊/项目/方隅公寓客户版/work/commercial-integration-20261022/customer-intent-correction-candidate`。
