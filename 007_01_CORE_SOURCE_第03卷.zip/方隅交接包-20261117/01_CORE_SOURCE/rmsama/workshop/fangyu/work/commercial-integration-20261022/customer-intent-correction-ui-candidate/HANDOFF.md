# 人工纠错 UI 候选交接

状态：候选完成并停写，未合并、未安装。没有更改 S/U、生产数据或运行实例；未访问 50660，未启动服务，未请求模型或平台。

## 交付

- `customer-intent-correction.patch`：相对 U 的可审统一补丁。
- `candidate/`：4 个既有文件的候选版本，以及新增 `pages/customer-intent-correction.mjs`。
- `BASE-HASHES.json` / `CANDIDATE-HASHES.json`：原版本、候选和交付时实际源码 SHA-256；交付时 5 项都仍匹配原基线（新文件原先不存在）。
- `RESULTS.json`：20 组行为通过（含摘要与取消恢复）。`ENTRY-RESULTS.json`：4 组实际客户页 render/bind 接线通过，含未知保存→原键读取→确认取消→明确 cancelled 后解锁。
- `tests/correction-ui-tests.mjs`、`tests/customer-entry-tests.mjs`：可重复 Node DOM 检查。测试依赖复用 work 下已有 linkedom，不新增产品依赖。

本目录：`C:/积木软件工坊/项目/方隅公寓客户版/work/commercial-integration-20261022/customer-intent-correction-ui-candidate`。

## 变化

客户原评论详情新增“人工核对 → 更正这条评论的意向”。有多条评论时可明确选择原评论；默认服务器的 representativeLeadId。展开后同时展示 AI 原判断、已有人工更正、人工理由、员工和时间。选择意向、填写 1—300 字理由后只保存当前 leadId。保存后重新读取列表和详情，汇总仍可能由该客户其他评论决定。

人工历史按最新在前显示最近 10 次，注明完整历史保留；原 AI 判断始终单列。原文、理由和记录全转义，长文本可换行。沿用浅色详情画风、17px 正文字号和至少 45px 按钮，窄窗按钮占整行；不改公共 CSS。

只有 customer_intent_read / customer_intent_correct / customer_intent_cancel 三个受控动作。backend 单独保留其明确 mutation_committed=false；不因 HTTP 4xx 猜测未提交，也不让通用 bootstrap 清除更正断点。

## 原请求与作用域

- 提交前持久记录员工 / 门店 / 平台 / 客户 / 评论 / 原请求号 / 版本摘要；不落盘原文、人工理由或客户昵称。
- 结果未知锁住这条更正，按钮只核对原请求。not_found 不生成新键；仅内存仍有原 payload 且用户明确点“按原内容重试一次”时原键、原内容重试。
- 刷新后没有原 payload，not_found 保留断点，不提供新提交入口；若提交前已保存 requestDigest，可由用户明确确认“取消这次待确认更正”，以原键与精确摘要请求服务器原子取消。只有 saved / cancelled 的完整、匹配回执可清除断点；取消失败或丢回执仍只读回查，不重新取消或换键。旧断点无摘要不能猜测取消。
- requestDigest 对完整公共 correct payload 的键排序、reason 去首尾空白、JSON UTF-8 做 SHA-256。已逐一比对当前 Native `DIGEST-VECTORS.json`，包含中文、换行、emoji、null。
- 员工、门店、平台、authEpoch 或所选客户变化，旧响应不采用，也不删除原作用域断点。
- 明确事务未提交 / CAS 失败保留输入，要求重新读取判断。已保存的相同人工判断不重复新增历史。

## 合同核对

已对照 `../customer-intent-correction-candidate/CONTRACT.md`：单条评论 ID、opaque 64 hex version/sourceDigest、status/level、原 saved receipt 字段、预提交失败、历史最新在前全部一致。实现时发现历史顺序需按最新在前取前 10 条，已修并增行为检查。

Native 的数据库原子保存/取消与 AI 写回 CAS 由独立候选实现。本 UI 的 20 组行为和 4 组客户页入口是 Node DOM + 合成 HTTP 形状传输，不冒称真实平台、完整客户端或真实浏览器视觉验证。旧 AI 不覆盖人工判断的数据库保证由 Native/Core 候选负责；UI 检查了收到不同 AI 判断时仍保留人工标记与人工选择。另验证原保存胜出取消竞争时显示 saved，迟到取消响应跨作用域不采用。

2026-10-23 恢复收尾：已重跑上述两套检查并刷新补丁、候选 SHA-256。所有源文件在本次封版时仍匹配 BASE-HASHES（新增文件仍不存在）；源目录未改。纠错 UI 目录从此停写，交总控审查合并。

## 合并与待验收

先审核并合并 Native/Core 受控合同，再逐文件校验 BASE-HASHES 后合并本补丁；冻结版本之后若源文件有变化，应重放最小 diff，不能整目录覆盖。

root 后续独立合成浏览器建议链：客户有两条评论 → 打开原评论纠错 → 第一条改为“不相关”并写理由 → 保存 → 看原 AI、人工标记、第二条判断保持 → 丢失保存回执后核对原请求 → 换门店 / 平台迟到隔离 → 390px / 1280px 布局与键盘检查。尚未进行该浏览器或真实账号验收。
