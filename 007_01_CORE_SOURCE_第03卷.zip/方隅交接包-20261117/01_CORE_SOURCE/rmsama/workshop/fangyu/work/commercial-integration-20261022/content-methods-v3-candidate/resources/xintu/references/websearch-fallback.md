# WebSearch Fallback

Use when `JUSTONE_API_TOKEN` is missing, Just One API returns no usable notes, or the business request fails after retries.

Do **not** stop the workflow. Continue with bounded public search and label all outputs `data_source=websearch`, `data_unverified=true`.

## When to trigger

- `JUSTONE_API_TOKEN` is not set
- `fetch_topic_evidence.py` or `fetch_style_samples.py` exits non-zero or returns zero items
- User explicitly asks for zero-config research

## Search patterns

Use the WebSearch tool (or equivalent real-time search) with queries such as:

```
site:xiaohongshu.com <关键词>
site:xhslink.com <关键词>
"<关键词>" 小红书 笔记
```

For topic direction only, broader queries are acceptable:

```
小红书 <关键词> 爆款
小红书 <关键词> 最近
```

Prefer result titles/snippets that clearly reference Xiaohongshu notes. Ignore unrelated forum reposts when identifiable.

## What you may record

From search snippets only:

- visible title
- visible URL
- visible snippet/summary
- inferred note type if explicitly stated (`视频`, `图文`)

## What you must not invent

- likes, collects, comments, views
- publish dates not shown in the snippet
- note body text not shown in the snippet
- "this is trending platform-wide"

## Normalized fallback record

Field names mirror `../scripts/justone_xhs.py` output so the two sources can share one table.
`interaction_value` stays `null` — it is a sort key, and WebSearch has nothing to sort by.

```json
{
  "rank": 1,
  "keyword": "the search term used",
  "post_id": "extracted from the URL when present, else null",
  "post_url": "https://...",
  "title": "exact visible title",
  "snippet": "visible snippet only",
  "content_type": "unknown",
  "author_name": "",
  "metrics": {
    "likes": null,
    "collects": null,
    "comments": null
  },
  "interaction_value": null,
  "data_source": "websearch",
  "data_unverified": true
}
```

Rank by relevance to the search term, and say so — it is not an engagement ranking.

## Output disclaimer (required)

Include one line near the top of topic/style results:

> 数据源：WebSearch 公开搜索兜底｜无互动数｜结论未经平台数据验证

## After fallback

- Topic radar may still rank candidates by **pattern fit**, not engagement.
- Note writer may still draft copy, but mark `style_confidence=low` unless user style library exists.
- Never mix WebSearch records with Just One API metrics in the same table without a `data_source` column.

## Optional enrich

If the user later provides note links or screenshots, replace fallback records with inspected evidence and remove `data_unverified`.
