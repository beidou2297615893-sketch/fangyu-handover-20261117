# Layout Readability Gate

Use after visual concept selection and after any generated cover/first-frame asset exists.

## Copy length limits (3:4 feed)

| Element | Limit |
|---|---|
| Main headline | 2 lines max; ~9 Chinese chars per line preferred |
| Qualifier | ≤ 12 Chinese chars |
| Proof label | ≤ 8 Chinese chars |
| Slide/page headline | one idea; ≤ 14 Chinese chars |

## Spacing rules

- Headline must remain readable at feed thumbnail scale.
- Do not place text over faces, hands, key UI, or proof objects.
- Decorative strokes, rings, or underlines must not cross glyphs.
- Keep one visual center; avoid two competing focal points.

## Post-generation rejection checklist

Reject and revise if any answer is yes:

- Is text clipped or touching card borders?
- Does the cover promise something the body/video does not deliver?
- Is the headline unreadable at thumbnail size?
- For video: does the first frame mismatch second 0-3 of the edit?
- For carousel: does the cover repeat slide 2 content instead of promising the package?

## Repair order

1. Shorten copy.
2. Increase whitespace / safe margins.
3. Remove decorative elements.
4. Regenerate or switch visual mode (brief-only if generation fails twice).

## Mode-specific notes

- `carousel_cover`: optimize for save/list promise; one proof object only.
- `video_first_frame`: must match opening shot; caption carries search keywords, not the frame.
- `carousel_slide_system`: each slide one job; slide 1 ≠ cover repeat.
