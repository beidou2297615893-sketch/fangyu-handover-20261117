from pathlib import Path,PurePosixPath
from collections import defaultdict
import argparse,hashlib,json,zipfile
HERE=Path(__file__).resolve().parent
def main():
    parser=argparse.ArgumentParser();parser.add_argument('--sample',required=True);options=parser.parse_args()
    if options.sample not in ('standard-held-sample-v71','standard-held-sample-v71-secured-native','standard-held-sample-v72-secured-native','standard-held-clean-v72'):
        raise RuntimeError('Explicit fixed sample name required')
    sample=HERE/options.sample;built=json.loads((sample/'BUILD.json').read_text('utf-8'))
    archive=sample/built['portableZip'];groups=defaultdict(lambda:{'files':0,'bytes':0,'compressedBytes':0})
    findings={'privateDataFiles':[],'productionBindingFiles':[],'modelWeights':[],'ffmpegBinaries':[],'venvFiles':[]}
    with zipfile.ZipFile(archive) as z:
        for item in z.infolist():
            relative=PurePosixPath(item.filename);name=relative.name.lower();suffix=relative.suffix.lower()
            if suffix in ('.sqlite','.sqlite3','.db','.dpapi','.pfx','.p12') or name in ('cookies.json','storage_state.json','.env','device.token','vault.json'):
                findings['privateDataFiles'].append(item.filename)
            if name=='production-workspace.json':findings['productionBindingFiles'].append(item.filename)
            if suffix in ('.safetensors','.gguf','.ckpt','.pt','.pth','.onnx'):findings['modelWeights'].append(item.filename)
            if name in ('ffmpeg.exe','ffprobe.exe'):findings['ffmpegBinaries'].append(item.filename)
            if name in ('pyvenv.cfg','activate','activate.bat','activate.ps1') or '/scripts/python.exe' in item.filename.lower():findings['venvFiles'].append(item.filename)
            group='full public project' if item.filename.startswith('project/') else 'Microsoft WebView2 offline prerequisite' if item.filename.startswith('prerequisites/') else 'frozen host and launcher'
            groups[group]['files']+=1;groups[group]['bytes']+=item.file_size;groups[group]['compressedBytes']+=item.compress_size
    report={'status':'PASS_STATIC_PACKAGE_CONTENT_BOUNDARIES' if not any(findings.values()) else 'FINDINGS',
        'sample':options.sample,'archiveSha256':hashlib.sha256(archive.read_bytes()).hexdigest(),
        'archiveBytes':archive.stat().st_size,'groups':dict(groups),'findings':findings,
        'existingRuntimeRequired':True,'bundledGpuOrModelRuntime':False,'GPLFfmpegBinaryIncluded':False,
        'publicHistoricalProvenancePathsRetained':True,
        'notEquivalentToCommercialApprovalOrSecondPhysicalPc':True}
    with (sample/'PACKAGE-CONTENT-SCAN.json').open('x',encoding='utf-8') as stream:json.dump(report,stream,ensure_ascii=False,indent=2);stream.write('\n')
    print(json.dumps({'status':report['status'],'bytes':report['archiveBytes'],'groups':report['groups'],'findings':findings},ensure_ascii=True))
if __name__=='__main__':main()
