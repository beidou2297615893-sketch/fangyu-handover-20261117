"""Real candidate HTTP/Native/Business/Workflow/Core; synthetic authority only."""
from pathlib import Path
import http.client,importlib.util,json,os,sys,threading
from unittest.mock import patch
sys.dont_write_bytecode=True
W=Path(__file__).parent
S=Path('C:/积木软件工坊/项目/方隅公寓客户版/work/parallel-integration-20261018/final-integration/stage-02/project')
blocked=[]
def fence(event,args):
    if event in ('socket.connect','socket.bind') and (not isinstance(args[1],tuple) or args[1][0]!='127.0.0.1'):
        blocked.append(event);raise RuntimeError('External network forbidden')
    if event=='socket.getaddrinfo' and args[0] not in ('127.0.0.1',None):
        blocked.append(event);raise RuntimeError('External DNS forbidden')
    if event in ('subprocess.Popen','os.system','os.startfile','os.posix_spawn'):
        blocked.append(event);raise RuntimeError('Child process forbidden')
    if event=='sqlite3.connect' and not Path(args[0]).resolve().is_relative_to(W):
        blocked.append(event);raise RuntimeError('Noncandidate database forbidden')
    if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):
        path=Path(os.fsdecode(args[0])).absolute();mode,flags=args[1] or '',args[2] or 0
        writes=any(c in str(mode) for c in 'wax+') or isinstance(flags,int) and bool(flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC))
        roots=(W,S,Path(sys.prefix),Path(sys.base_prefix))
        if not (path.is_relative_to(W) if writes else any(path.is_relative_to(root) for root in roots)):
            blocked.append('open:'+path.name);raise RuntimeError('Nonfixture path forbidden')
sys.addaudithook(fence)
from test_intent_correction import CorrectionTests,VENDOR
def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path);module=importlib.util.module_from_spec(spec);sys.modules[name]=module;spec.loader.exec_module(module);return module
native=load('intent_candidate_native',W/'candidate/work/ui-native-r57/workbench_backend.py')
host=load('intent_candidate_host',W/'candidate/work/ui-native-r57/ui_native_host.py')
from customer_intent_workbench import IntentCorrectionWorkbench
case=CorrectionTests();case.setUp();results=[]
# Only the enterprise identity and published configuration transport are
# synthetic. Actual dispatch, selected-store calculation, customer membership,
# Business principal, atomic writer, host request gates and receipts are real.
backend=native.WorkbenchBackend.__new__(native.WorkbenchBackend)
backend.closed=False;backend.lock=threading.RLock();backend.core=case.core;backend.company=case.company
backend.customer_workbench=case.customers;backend.remote_management=None
backend.customer_intent_factory=IntentCorrectionWorkbench
profile={'role':'operator','_workbench_stores':[{'id':'gubei'}]};identity_calls=0;late_failure=False
def identity(token):
    global identity_calls
    if token!='fixture-token':raise native.WorkbenchError('AUTH_REQUIRED','Synthetic employee required',401)
    identity_calls+=1
    if late_failure and identity_calls%2==0:raise native.WorkbenchError('AUTH_REQUIRED','Synthetic revoked after commit',401)
    user=case.core.store.get('users',case.user['id'])
    if user['disabled']:raise native.WorkbenchError('AUTH_REQUIRED','Synthetic employee disabled',401)
    return user,profile
backend._identity=identity
def central(user,profile,store,**kwargs):
    assert store in {row['id'] for row in profile['_workbench_stores']}
    return {'store_id':store}
backend._activate_central_config=central
server=host.StaticServer(W,{'web/index.html':{'path':'unused','sha256':'0'*64,'size':0}},backend=backend,cookie_name='intent_fixture')
worker=threading.Thread(target=server.serve_forever,daemon=True);worker.start()
origin='http://127.0.0.1:'+str(server.server_port)
headers={'Content-Type':'application/json','Origin':origin,'X-Fangyu-CSRF':server.csrf_token,'Cookie':'intent_fixture=fixture-token'}
def call(action,data,status=200,override=None):
    connection=http.client.HTTPConnection('127.0.0.1',server.server_port,timeout=10)
    connection.request('POST','/api/workbench',json.dumps({'action':action,'data':data}).encode(),override or headers)
    response=connection.getresponse();raw=response.read();found=response.status;connection.close()
    parsed=json.loads(raw) if raw.startswith(b'{') else {'text':'blocked'}
    assert found==status,(found,status,parsed)
    return parsed
try:
    read=call('customer_intent_read',case.scope)['intentCorrection']
    payload={**case.scope,'requestId':'http-commit','expectedVersion':read['version'],'sourceDigest':read['sourceDigest'],
             'status':'graded','level':'high','reason':'核对这一条评论'}
    first=call('customer_intent_correct',payload)['intentCorrection']
    assert first['manualIntent']['level']=='high' and first['aiIntent']['level']=='low'
    assert call('customer_intent_correct',payload)['intentCorrection']['receipt']==first['receipt']
    assert call('customer_intent_read',{**case.scope,'requestId':'http-commit'})['intentCorrection']['receipt']==first['receipt']
    results.append('actual host → Native → Business.intent_correct → AIWorkflow.correct → atomic Core Store + replay')
    conflict=call('customer_intent_correct',{**payload,'reason':'不同内容'},409)
    assert conflict['error']['mutation_committed'] is False
    call('customer_intent_read',case.scope,403,{**headers,'X-Fangyu-CSRF':'wrong'})
    call('customer_intent_read',case.scope,403,{**headers,'Origin':'https://example.invalid'})
    call('customer_intent_read',case.scope,401,{**headers,'Cookie':'intent_fixture=bad-token'})
    results.append('same-origin / CSRF / session + exact original-key conflict')
    call('customer_intent_correct',{**payload,'accountId':'account-b'},400)
    call('customer_intent_read',{**case.scope,'leadId':'lead-2'},404)
    profile['_workbench_stores']=[{'id':'other'}]
    denied=call('customer_intent_correct',payload,403);assert denied['error']['mutation_committed'] is False
    profile['_workbench_stores']=[{'id':'gubei'}]
    results.append('same stable customer across accounts, other-store comment and current-store switch rejected')
    read=call('customer_intent_read',case.scope)['intentCorrection']
    next_payload={**payload,'requestId':'lost-after-save','expectedVersion':read['version'],'level':'medium'}
    original=IntentCorrectionWorkbench.correct
    def drop_response(self,*args):
        original(self,*args)
        raise OSError('Synthetic lost return after commit')
    with patch.object(IntentCorrectionWorkbench,'correct',drop_response):
        lost=call('customer_intent_correct',next_payload,503)
    assert lost['error']['code']=='INTENT_RESULT_UNCONFIRMED' and 'mutation_committed' not in lost['error']
    found=call('customer_intent_read',{**case.scope,'requestId':'lost-after-save'})['intentCorrection']
    assert found['receipt']['state']=='saved' and len(found['history'])==2
    results.append('post-commit lost return remains unknown; read original receipt resolves without resend')
    read=call('customer_intent_read',case.scope)['intentCorrection']
    last={**payload,'requestId':'late-scope','expectedVersion':read['version'],'status':'uncertain','level':None}
    identity_calls=0;late_failure=True
    late=call('customer_intent_correct',last,409)
    assert late['error']['mutation_committed'] is True
    late_failure=False
    assert call('customer_intent_read',{**case.scope,'requestId':'late-scope'})['intentCorrection']['receipt']['state']=='saved'
    results.append('saved then enterprise identity changed: committed flag retained; original receipt recoverable')
    read=call('customer_intent_read',case.scope)['intentCorrection']
    cancelling={**payload,'requestId':'http-cancel','expectedVersion':read['version']}
    cancelled=call('customer_intent_cancel',case.cancellation(cancelling))['intentCorrection']
    assert cancelled['receipt']['state']=='cancelled'
    assert call('customer_intent_read',{**case.scope,'requestId':'http-cancel'})['intentCorrection']['receipt']==cancelled['receipt']
    denied=call('customer_intent_correct',cancelling,409)
    assert denied['error']['code']=='INTENT_REQUEST_CANCELLED' and denied['error']['mutation_committed'] is False
    already_saved=call('customer_intent_cancel',case.cancellation(last))['intentCorrection']
    assert already_saved['receipt']['state']=='saved'
    results.append('explicit atomic cancellation tombstone blocks late original write; saved wins returns original receipt')
    assert not blocked,blocked
    (W/('HTTP-VENDOR-RESULT.json' if VENDOR else 'HTTP-RESULT.json')).write_text(json.dumps({'status':'PASS','groups':results,'external_requests':0,'platform_calls':0,
        'model_calls':0,'production_database_reads_or_writes':0,'blocked_attempts':blocked,
        'authority_seams':['synthetic saved employee identity','synthetic published store config'],'mocked_correction':False},ensure_ascii=False,indent=2),'utf-8')
    print(json.dumps({'status':'PASS','groups':len(results)},ensure_ascii=False))
finally:
    server.shutdown();server.server_close();worker.join(timeout=2);case.tearDown()
