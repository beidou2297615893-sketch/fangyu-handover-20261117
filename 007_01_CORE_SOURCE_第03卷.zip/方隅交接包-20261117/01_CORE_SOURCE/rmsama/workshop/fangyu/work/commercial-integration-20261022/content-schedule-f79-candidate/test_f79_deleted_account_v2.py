"""Original pinned Native factory; owned synthetic identity/assets/receipts only."""
from pathlib import Path
from copy import deepcopy
from datetime import datetime,timezone,timedelta
from io import BytesIO
import ast,base64,hashlib,http.client,importlib.util,importlib,json,os,sys,threading,time,uuid
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;P=W.parents[2];case=sys.argv[1]
OUT=W/('factory-'+case+'-'+uuid.uuid4().hex[:8]);OUT.mkdir();(OUT/'http').mkdir()
def save(name,value):(OUT/name).write_text(json.dumps(value,ensure_ascii=False,indent=2,default=str)+'\n','utf-8')
def load(name,path):
    module=importlib.util.module_from_spec(importlib.util.spec_from_loader(name,loader=None));module.__file__=str(path);sys.modules[name]=module
    exec(compile(path.read_bytes(),str(path),'exec'),module.__dict__);return module
if case=='baseline':
    F=P/'work/parallel-integration-20261018/final-integration/candidate-unified-v79';S=F/'project';stage=json.loads((F/'STAGED.json').read_text('utf-8'))
else:
    inputs=json.loads((W/'QA-INPUTS.json').read_text('utf-8'));S=Path(inputs['project']);stage=inputs['stage']
R=Path(stage['release']);blocked=[]
def audit(event,args):
    if event in ('subprocess.Popen','os.system','os.startfile','os.posix_spawn'):blocked.append(event);raise RuntimeError('No child process')
    if event in ('socket.connect','socket.bind') and (not isinstance(args[1],tuple) or args[1][0] not in ('127.0.0.1','::1')):blocked.append(event);raise RuntimeError('No external socket')
    if event=='socket.getaddrinfo' and args[0] not in ('127.0.0.1','::1','localhost',None):blocked.append(event);raise RuntimeError('No external DNS')
    if event=='sqlite3.connect' and not Path(args[0]).resolve().is_relative_to(W):blocked.append(event);raise RuntimeError('Own DB only')
    if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):
        path=Path(os.fsdecode(args[0])).absolute();mode,flags=args[1] or '',args[2] or 0
        if (any(c in str(mode) for c in 'wax+') or isinstance(flags,int) and flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC)) and not path.is_relative_to(W):blocked.append(event);raise RuntimeError('Own writes only')
sys.addaudithook(audit)
fixture=load('schedule_original_identity_fixture',P/'work/acquisition-core-repair-20261018/gui-fixture/base_fixture.py')
cloud=fixture.CloudStandin(json.loads((P/'work/central-store-config/compiled-fixture.json').read_text('utf-8-sig')))
company=json.loads((S/'work/app/company.json').read_text('utf-8-sig'))
def transport(*args,**kwargs):
    result=cloud(*args,**kwargs);result['environment_id']=company['managedWorkspace']['environment_id'];return result
integration=load('integrations',R/'resources/platform-runtime/vendor-src/integrations.py');integration.request_json=transport
host=load('schedule_original_native_host',R/'ui_native_host.py');_,files=host.verify_release(R,stage['manifest_sha256']);host.verify_backend_dependencies(R,files,S)
backend=None;server=None;worker=None;headers={};events=[];checks=[];sessions={};passed=False;sequence=0
controls={};grant_phases=[];total_click_calls=0
def state():
    if backend is None:return {}
    with backend.core.store.connect() as db:rows={(r['entity'],r['id']):r['body'] for r in db.execute("SELECT entity,id,body FROM records WHERE entity!='users' ORDER BY entity,id")}
    return rows
def snapshot(value):return {'records':len(value),'digest':hashlib.sha256(json.dumps(sorted((list(k),v) for k,v in value.items()),ensure_ascii=False).encode()).hexdigest()}
def dispatches():return sum(s.clicks for s in sessions.values())
def request(method,path,data=None,expected=200):
    global sequence
    sequence+=1;number=sequence;before=state();clicks=total_click_calls;response=None
    try:
        conn=http.client.HTTPConnection('127.0.0.1',server.server_port,timeout=45)
        conn.request(method,path,json.dumps(data,ensure_ascii=False).encode() if data is not None else None,headers)
        response=conn.getresponse();raw=response.read();found=dict(response.getheaders());status=response.status;conn.close()
        try:body=json.loads(raw)
        except ValueError:body={'rawResponseText':raw.decode('utf-8',errors='replace')}
    finally:
        after=state();logged=deepcopy(data)
        if logged and logged.get('action')=='login':logged['data']['password']='synthetic password omitted'
        entry={'sequence':number,'request':logged,'httpStatus':response.status if response else None,'body':locals().get('body'),
            'before':snapshot(before),'after':snapshot(after),'recordChanges':[{'entity':k[0],'id':k[1],'before':before.get(k),'after':after.get(k)} for k in sorted(set(before)|set(after)) if before.get(k)!=after.get(k)],
            'syntheticClickIncrement':total_click_calls-clicks,'allSyntheticClicks':total_click_calls,
            'concurrentRequestDeltaMayOverlap':case in ('pressure50','pressure100','contention')}
        save('http/'+str(number).zfill(4)+'.json',entry);events.append({k:v for k,v in entry.items() if k not in ('recordChanges','body')})
    assert status==expected,(status,expected,body)
    return body,found
def action(name,data,expected=200):return request('POST','/api/workbench',{'action':name,'data':data},expected)[0]
def workspace(base):return action('content_workspace_read',base)['workspace']
def write(action_name,base,**data):return action(action_name,{**base,'expectedRevision':workspace(base)['revision'],'requestId':uuid.uuid4().hex,**data})
def setup_account(index=1):
    aid='schedule-account-'+str(index);uid='schedule-uid-'+str(index)
    backend.core.store.put('accounts',{'id':aid,'tenant_id':user['tenant_id'],'cloud_owner':user['username'],'store_id':store,
        'platform':'xiaohongshu','platform_uid':uid,'platform_nickname':'合成排程账号'+str(index),'status':'disconnected'})
    base={'storeId':store,'accountId':aid,'platform':'xiaohongshu'}
    image=write('content_asset_import',base,name='已授权合成图.png',mime='image/png',dataBase64=png,source='authorized_real',rightsConfirmed=True)['result']['asset']
    draft=write('content_draft_save',base,draft={'title':'入住前核对计划'+str(index),'body':'入住时间和房源信息均须本人另行核实。','format':'image','assetIds':[image['id']]})['workspace']['drafts'][-1]
    write('content_draft_audit',base,draftId=draft['id'],decision='approve',note='合成人工核对，不是实际门店事实')
    return base,draft
def plan(base,draft,offset=-2,grace=60,key=None):
    return action('content_schedule_plan',{**base,'draftId':draft['id'],'draftVersion':draft['version'],
        'plannedAt':(datetime.now(timezone(timedelta(hours=8)))+timedelta(seconds=offset)).isoformat(timespec='seconds'),
        'timezone':'Asia/Shanghai','graceMinutes':grace,'requestId':key or uuid.uuid4().hex})['schedule']
def arm(base,row,key=None,expected=200):
    return action('content_schedule_arm',{**base,'scheduleId':row['id'],'expectedScheduleRevision':row['revision'],
        'snapshotDigest':row['snapshot']['snapshotDigest'],'accountUid':row['snapshot']['accountUid'],
        'humanConfirmed':True,'futureExecutionConfirmed':True,'requestId':key or uuid.uuid4().hex},expected)
def tick(base,row):return action('content_schedule_tick',{**base,'scheduleId':row['id'],'requestId':uuid.uuid4().hex})['schedule']
def read(base,row):return action('content_schedule_read',{**base,'scheduleId':row['id']})['schedule']
def make_port():
    (OUT/'synthetic-assets').mkdir(exist_ok=True)
    cls=backend._content_component();portmod=importlib.import_module(cls.__module__.rsplit('.',1)[0]+'.publishing_port')
    source=P/'work/commercial-integration-20261022/publishing-execution-candidate/test_publication.py'
    tree=ast.parse(source.read_text('utf-8'));selected=[n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef)) and n.name in ('codec','SyntheticSession')]
    namespace={'PublicationObserver':portmod.PublicationObserver,'StrictPublishJSON':portmod.StrictPublishJSON,
        'threading':threading,'time':time,'json':json,'uuid':uuid,'hashlib':hashlib,'Path':Path,'re':__import__('re')}
    exec(compile(ast.Module(body=selected,type_ignores=[]),str(source),'exec'),namespace)
    def session_provider(envelope):
        snap=envelope['snapshot'];aid=snap['scope']['account_id']
        if aid not in sessions:
            obj=namespace['SyntheticSession'](backend.core.store);original=obj.binding
            obj.binding=lambda obj=obj,original=original,snap=deepcopy(snap):{**original(),'accountId':snap['scope']['account_id'],'accountUid':snap['accountUid'],'owner':snap['owner']}
            # Original fixture's response identity is explicit and synthetic.
            original_emit=obj.emit;obj.emit=lambda uid=snap['accountUid'],original_emit=original_emit:original_emit(uid)
            original_click=obj.click_once
            def counted_click(*args,original_click=original_click):
                global total_click_calls
                total_click_calls+=1;return original_click(*args)
            obj.click_once=counted_click
            obj.mode=controls.get('mode','success');sessions[aid]=obj
        return sessions[aid]
    def grant(envelope,phase):
        snap=envelope['snapshot'];scope=snap['scope']
        grant_phases.append({'phase':phase,'accountId':scope['account_id'],'intentId':envelope['intentId'],'requestId':envelope['requestId']})
        if phase=='preflight' and controls.get('waitPreflight'):
            controls['entered'].set();assert controls['release'].wait(10),'Synthetic preflight release missing'
        return {'contract':'fangyu-publication-capability-v1','enabled':True,'centralVerified':True,'action':'publish',
            'tenantId':scope['tenant_id'],'storeId':scope['store_id'],'accountId':scope['account_id'],'accountUid':snap['accountUid'],
            'owner':snap['owner'],'platform':'xiaohongshu','intentId':envelope['intentId'],'requestId':envelope['requestId'],
            'snapshotDigest':envelope['snapshotDigest'],'deviceId':'executor-1','grantRevision':'d'*64,'expiresAt':time.time()+60,
            'adapterRevision':'owned-publish-port-v1','wireRevision':'SYNTHETIC-ONLY-v1'}
    backend._content_publish_port=portmod.OwnedPublishPort(store=backend.core.store,authority=grant,session_provider=session_provider,
        lease_acquire=backend.core.acquire_account_mode,lease_release=backend.core.release_account_mode,stage_dir=OUT/'synthetic-assets')
    return session_provider
try:
    backend=host.create_backend(R,files,project_root=S,data_dir=OUT/'data',company=company)
    server=host.StaticServer(R,files,backend=backend,cookie_name='schedule_fixture_session');worker=threading.Thread(target=server.serve_forever,daemon=True);worker.start();origin='http://127.0.0.1:'+str(server.server_port)
    boot,_=request('GET','/api/workbench/bootstrap');headers.update({'Origin':origin,'Content-Type':'application/json','X-Fangyu-CSRF':boot['csrfToken']})
    logged,h=request('POST','/api/workbench',{'action':'login','data':{'username':'fixture-admin','password':fixture.PASSWORD}})
    headers['Cookie']=h['Set-Cookie'].split(';',1)[0];headers['X-Fangyu-CSRF']=logged['csrfToken'];user=backend.core.session(headers['Cookie'].split('=',1)[1]);store=cloud.first_store
    if logged['selection']['storeId']!=store:action('select_store',{'storeId':store,'expectedRevision':logged['selection']['revision']})
    if case=='baseline':
        before=state();red=action('content_schedule_read',{'storeId':store,'accountId':'not-created','platform':'xiaohongshu'},403)
        assert state()==before and dispatches()==0;checks.append('RED_EXPECTED_F79_HAS_NO_CONTENT_EXECUTION_QUEUE');save('BASELINE-RED.json',red)
    else:
        from PIL import Image
        image=BytesIO();Image.new('RGB',(4,4),'blue').save(image,format='PNG');png=base64.b64encode(image.getvalue()).decode()
        base,draft=setup_account();row=plan(base,draft)
        before=state();action('content_schedule_arm',{**base,'scheduleId':row['id'],'expectedScheduleRevision':row['revision'],'snapshotDigest':row['snapshot']['snapshotDigest'],'accountUid':row['snapshot']['accountUid'],'humanConfirmed':False,'futureExecutionConfirmed':True,'requestId':uuid.uuid4().hex},409)
        assert state()==before and dispatches()==0
        row=arm(base,row)['schedule'];assert row['liveSessionEnabled'] and row['state']=='armed' and not dispatches()
        if case=='held':
            row=tick(base,row);assert row['state']=='blocked' and row['reasonCode'] and not dispatches(),row
            same=tick(base,row);assert same['state']=='blocked' and not dispatches();checks.append('Default original publication hold is recorded, zero external or synthetic clicks, no tick retry')
        else:
            provider=make_port();row=tick(base,row);assert row['state']=='published' and dispatches()==1,row
            tick(base,row);assert dispatches()==1;checks.append('Fixed due item through original publication/lease/observer: one synthetic receipt, replay no dispatch')
            if case=='account-removed':
                sessions.clear();target,d=setup_account(2);r=arm(target,plan(target,d))['schedule']
                old_schedule=deepcopy(backend.core.store.get('content_schedule_execution_v1',r['id']))
                old_attempt=deepcopy(backend.core.store.get('content_publication_attempt_v1',r['intentId']))
                account=backend.core.store.get('accounts',target['accountId'])
                removed=backend.core.handle('account_delete',{'id':target['accountId'],'expected_account_digest':backend.core.account_delete_digest(account)},user)
                assert backend.core.store.get('accounts',target['accountId']) is None,removed
                after_delete=state()
                answer=action('content_schedule_tick',{**target,'scheduleId':r['id'],'requestId':r['publishRequestId']},403)
                assert answer['error']['code']=='ACCOUNT_FORBIDDEN' and state()==after_delete and dispatches()==0
                assert backend.core.store.get('content_schedule_execution_v1',r['id'])==old_schedule
                assert backend.core.store.get('content_publication_attempt_v1',r['intentId'])==old_attempt
                checks.append('F79 original Core CAS account deletion retained schedule/intent/key byte-identical; actual Native HTTP due tick rejects removed account before synthetic dispatch (Core deletion seam, not Native deletion-entry retest)')
            elif case=='safety':
                sessions.clear();base2,draft2=setup_account(2);row2=arm(base2,plan(base2,draft2))['schedule']
                controls['mode']='unknown';unknown=tick(base2,row2);assert unknown['state']=='unknown' and dispatches()==1
                original_key=unknown['publishRequestId'];original_intent=unknown['intentId'];before=state()
                tick(base2,unknown);assert state()==before and dispatches()==1
                action('content_schedule_reconcile',{**base2,'scheduleId':unknown['id'],'requestId':'wrong-key'},409)
                arm(base2,unknown,expected=409)
                assert state()==before and dispatches()==1
                sessions[base2['accountId']].emit()
                settled=action('content_schedule_reconcile',{**base2,'scheduleId':unknown['id'],'requestId':original_key})['schedule']
                assert settled['state']=='published' and settled['publishRequestId']==original_key and settled['intentId']==original_intent and dispatches()==1
                checks.append('Unknown exact original intent/key preserved; no tick retry/rearm/wrong-key; original observer status settles once')
                controls.clear();sessions.clear();base3,draft3=setup_account(3);row3=arm(base3,plan(base3,draft3))['schedule']
                write('content_draft_save',base3,draft={'id':draft3['id'],'title':'修改后的新版本','body':'新版本须重新审核。','format':'image','assetIds':draft3['assetIds']})
                stale=tick(base3,row3);assert stale['state']=='needs_review' and not dispatches() and not stale['liveSessionEnabled']
                arm(base3,stale,expected=409);checks.append('Changed draft/audit invalidates fixed approval before preflight; no dispatch')
                base4,draft4=setup_account(4);row4=arm(base4,plan(base4,draft4,offset=-55,grace=1))['schedule']
                time.sleep(6);expired=tick(base4,row4);assert expired['state']=='needs_review' and expired['reasonCode']=='CONTENT_SCHEDULE_APPROVAL_EXPIRED' and not dispatches()
                checks.append('Real clock expiry/missed grace invalidates approval, no catch-up dispatch')
                base5,draft5=setup_account(5);row5=arm(base5,plan(base5,draft5))['schedule']
                before=state();action('content_schedule_read',{**base3,'scheduleId':row5['id']},404);assert state()==before
                paused=action('content_schedule_control',{**base5,'scheduleId':row5['id'],'expectedScheduleRevision':row5['revision'],'operation':'pause','requestId':uuid.uuid4().hex})['schedule']
                assert paused['state']=='paused';tick(base5,paused);assert not dispatches()
                active=arm(base5,paused)['schedule'];assert active['state']=='armed'
                controls.update(waitPreflight=True,entered=threading.Event(),release=threading.Event());finished={}
                def concurrent_tick():
                    try:finished['row']=tick(base5,active)
                    except BaseException as error:finished['error']=repr(error)
                t=threading.Thread(target=concurrent_tick);t.start();assert controls['entered'].wait(5)
                claiming=read(base5,active);cancelled=action('content_schedule_control',{**base5,'scheduleId':active['id'],'expectedScheduleRevision':claiming['revision'],'operation':'cancel','requestId':uuid.uuid4().hex})['schedule']
                assert cancelled['stopRequested'] is True
                controls['release'].set();t.join(10);assert not t.is_alive() and 'error' not in finished,finished
                assert finished['row']['state']=='blocked' and finished['row']['reasonCode']=='CONTENT_SCHEDULE_STOPPED' and not dispatches(),finished
                checks.append('Pause/re-arm explicit; cancel during original external preflight is rechecked atomically before reservation, zero click')
                controls.clear();base6,draft6=setup_account(6);row6=arm(base6,plan(base6,draft6))['schedule']
                old_key=row6['publishRequestId'];backend._content_schedule_grants.clear();before=state()
                waiting=tick(base6,row6);assert waiting['needsSessionConfirmation'] and waiting['publishRequestId']==old_key and state()==before and not dispatches()
                checks.append('Lost RAM session grant prevents due dispatch without mutating durable plan/original key')
            elif case in ('pressure50','pressure100'):
                from concurrent.futures import ThreadPoolExecutor
                amount=int(case.removeprefix('pressure'));sessions.clear();items=[];started=time.monotonic()
                for i in range(2,amount+2):
                    target,d=setup_account(i);r=arm(target,plan(target,d))['schedule'];items.append((target,r))
                before_dispatch=dispatches()
                with ThreadPoolExecutor(max_workers=8) as pool:completed=list(pool.map(lambda item:tick(*item),items))
                assert len(completed)==amount and all(r['state']=='published' for r in completed)
                assert dispatches()-before_dispatch==amount
                assert len({r['scope']['account_id'] for r in completed})==amount
                before=state()
                with ThreadPoolExecutor(max_workers=8) as pool:list(pool.map(lambda item:tick(*item),items))
                assert state()==before and dispatches()==amount
                action('content_schedule_read',{**items[0][0],'scheduleId':items[-1][1]['id']},404)
                assert state()==before
                save('LOAD.json',{'accounts':amount,'concurrentWorkers':8,'seconds':time.monotonic()-started,'publishedSyntheticReceipts':amount,'repeatDispatch':0,'crossAccountReadDenied':True,'notPlatformCapacity':True})
                checks.append(str(amount)+' original-factory synthetic accounts: fixed content/account/time, bounded concurrent execution, repeat tick zero dispatch, cross-account isolated')
            elif case=='contention':
                from concurrent.futures import ThreadPoolExecutor
                sessions.clear();controls['mode']='unknown';items=[]
                for index in (2,3):
                    # Two distinct approved drafts in ONE original account.
                    image=write('content_asset_import',base,name='并发合成图.png',mime='image/png',dataBase64=png,source='authorized_real',rightsConfirmed=True)['result']['asset']
                    new=write('content_draft_save',base,draft={'title':'同账号并发稿'+str(index),'body':'合成内容，不涉及真实发布。','format':'image','assetIds':[image['id']]})['workspace']['drafts'][-1]
                    write('content_draft_audit',base,draftId=new['id'],decision='approve',note='合成核对')
                    items.append(arm(base,plan(base,new))['schedule'])
                with ThreadPoolExecutor(max_workers=2) as pool:done=list(pool.map(lambda r:tick(base,r),items))
                assert sorted(r['state'] for r in done)==['blocked','unknown'] and dispatches()==1,done
                original=next(r for r in done if r['state']=='unknown');other=next(r for r in done if r['state']=='blocked')
                assert other['reasonCode']=='PUBLISH_SLOT_BUSY'
                try:backend.core.acquire_account_mode(base['accountId'],user['tenant_id'],'replies','foreign-schedule-probe')
                except Exception:pass
                else:raise AssertionError('Original publication unknown did not block foreign reply mode')
                original_attempt=backend.core.store.get('content_publication_attempt_v1',original['intentId'])
                cancelled=action('content_schedule_control',{**base,'scheduleId':original['id'],'expectedScheduleRevision':original['revision'],'operation':'cancel','requestId':uuid.uuid4().hex})['schedule']
                assert cancelled['state']=='unknown' and cancelled['stopRequested']
                arm(base,cancelled,expected=409);tick(base,cancelled)
                assert backend.core.store.get('content_publication_attempt_v1',original['intentId'])==original_attempt and dispatches()==1
                checks.append('Concurrent distinct due items on one account: one unknown click, other original slot denied; foreign replies blocked; cancel/re-arm preserves unknown exact original attempt/key')
            elif case=='recover-claim':
                sessions.clear();target,d=setup_account(2);r=arm(target,plan(target,d))['schedule'];original_key=r['publishRequestId'];original_intent=r['intentId']
                controls.update(waitPreflight=True,entered=threading.Event(),release=threading.Event());finished={}
                def interrupted_tick():
                    try:finished['row']=tick(target,r)
                    except BaseException as error:finished['error']=repr(error)
                t=threading.Thread(target=interrupted_tick);t.start();assert controls['entered'].wait(5)
                try:
                    claimed=read(target,r);assert claimed['state']=='claimed' and claimed['publication']['state']=='prepared'
                    paused=action('content_schedule_control',{**target,'scheduleId':r['id'],'expectedScheduleRevision':claimed['revision'],
                        'operation':'recover','humanConfirmed':True,'requestId':uuid.uuid4().hex})['schedule']
                    assert paused['state']=='paused' and paused['publishRequestId']==original_key
                    renewed=arm(target,paused)['schedule'];assert renewed['liveSessionEnabled'] and renewed['publishRequestId']==original_key and renewed['intentId']==original_intent
                finally:controls['release'].set();t.join(10)
                assert not t.is_alive() and 'error' not in finished and finished['row']['state']=='armed' and not dispatches(),finished
                kept=read(target,renewed);assert kept['liveSessionEnabled'] and kept['approvalDigest']==renewed['approvalDigest']
                controls.clear();done=tick(target,kept);assert done['state']=='published' and done['publishRequestId']==original_key and done['intentId']==original_intent and dispatches()==1
                checks.append('Explicit recovery of prepared-only claimed item keeps original intent/key; late old worker cannot revoke/overwrite newer approval; only renewed single claim dispatches')
            elif case=='reopen':
                sessions.clear();target,d=setup_account(2);key='explicit-arm-before-reopen';r=plan(target,d);arm_input={**target,'scheduleId':r['id'],'expectedScheduleRevision':r['revision'],
                    'snapshotDigest':r['snapshot']['snapshotDigest'],'accountUid':r['snapshot']['accountUid'],'humanConfirmed':True,'futureExecutionConfirmed':True,'requestId':key}
                r=action('content_schedule_arm',arm_input)['schedule'];old_key=r['publishRequestId'];old_intent=r['intentId'];before=state()
                save('REOPEN-BEFORE.json',[{'entity':k[0],'id':k[1],'body':v} for k,v in before.items()])
                server.shutdown();worker.join(5);server.server_close();backend.close()
                backend=host.create_backend(R,files,project_root=S,data_dir=OUT/'data',company=company)
                server=host.StaticServer(R,files,backend=backend,cookie_name='schedule_fixture_session');worker=threading.Thread(target=server.serve_forever,daemon=True);worker.start();origin='http://127.0.0.1:'+str(server.server_port);headers.clear()
                boot,_=request('GET','/api/workbench/bootstrap');headers.update({'Origin':origin,'Content-Type':'application/json','X-Fangyu-CSRF':boot['csrfToken']})
                logged,h=request('POST','/api/workbench',{'action':'login','data':{'username':'fixture-admin','password':fixture.PASSWORD}})
                headers['Cookie']=h['Set-Cookie'].split(';',1)[0];headers['X-Fangyu-CSRF']=logged['csrfToken'];user=backend.core.session(headers['Cookie'].split('=',1)[1])
                after=state();save('REOPEN-DIFF.json',[{'entity':k[0],'id':k[1],'before':before.get(k),'after':after.get(k)} for k in sorted(set(before)|set(after)) if before.get(k)!=after.get(k)])
                changes=[k for k in set(before)|set(after) if before.get(k)!=after.get(k)]
                assert changes==[('ui_workbench_preferences_v1','remembered-username')],changes
                old_preference=json.loads(before[changes[0]]);new_preference=json.loads(after[changes[0]])
                assert {k:v for k,v in old_preference.items() if k!='updated_at'}=={k:v for k,v in new_preference.items() if k!='updated_at'}
                before=after # Only original login's documented preference timestamp changed.
                looked=read(target,r);assert looked['needsSessionConfirmation'] and not looked['liveSessionEnabled']
                action('content_schedule_arm',arm_input);again=tick(target,r)
                assert not again['liveSessionEnabled'] and again['publishRequestId']==old_key and again['intentId']==old_intent and not dispatches() and state()==before
                checks.append('Actual factory close/reopen keeps durable plan/approval/old key byte-identical, original arm replay cannot grant a new session or dispatch')
                fresh=arm(target,looked)['schedule'];assert fresh['liveSessionEnabled']
                options=logged.get('stores',[]);different=next((x['id'] for x in options if x['id']!=store),None)
                if different:
                    selection=action('select_store',{'storeId':different,'expectedRevision':logged['selection']['revision']})['selection']
                    action('select_store',{'storeId':store,'expectedRevision':selection['revision']})
                    before=state();lost=tick(target,fresh);assert not lost['liveSessionEnabled'] and lost['needsSessionConfirmation'] and state()==before and not dispatches()
                    checks.append('Switch store away/back changes original selection revision; previous RAM approval cannot silently reactivate')
    passed=True
    save('RESULTS.json',{'status':'PASS_EXPECTED_BASELINE_RED' if case=='baseline' else 'PASS','case':case,'checks':checks,
        'stage':stage,'syntheticClicks':total_click_calls,'remainingFixtureSessionClicks':dispatches(),'grantPhases':grant_phases,'realPlatformModelCalls':0,'notCustomerPublishingAcceptance':True})
finally:
    if controls.get('release'):controls['release'].set()
    try:save('FINAL-CAPTURE.json',{'status':'PASS' if passed else 'RED_CAPTURED','events':events,'records':[{'entity':k[0],'id':k[1],'body':v} for k,v in state().items()], 'syntheticClicks':total_click_calls,'blocked':blocked})
    finally:
        if server:server.shutdown();worker.join(5);server.server_close()
        if backend:backend.close()
        save('FINAL.json',{'status':'PASS' if passed else 'RED_CAPTURED','allOwnServersClosed':server is None or not worker.is_alive(),'httpRequests':len(events),'blocked':blocked,'realExternalCalls':0})
print(str(OUT)+' '+('PASS' if passed else 'RED'))
