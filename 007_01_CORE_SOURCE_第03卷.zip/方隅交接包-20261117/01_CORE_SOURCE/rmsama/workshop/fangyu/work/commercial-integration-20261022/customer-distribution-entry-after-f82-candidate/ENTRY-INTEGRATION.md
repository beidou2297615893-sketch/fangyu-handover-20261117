# 显式原资料目录的启动接缝

本目录仅验证安装版启动时复用原资料目录，不改现有人用入口，不产生平台授权。

1. 沿用原 clean entry 构造器；在其 CLEAN_ENTRY AST 改写完成之后、PyInstaller 编译之前调用 `adapt_clean_entry.adapt_entry`，传入实际新 entry SHA 和固定 selector 字节。只新增两个显式本机参数和资料目录选择，原完整清单、代码审计及加载器函数 AST 不变。
2. 普通分发默认没有参数，仍仅初始化 `LOCALAPPDATA/FangyuWorkbenchStandard`。只有本机启动器明确附带原项目根目录与原 production-workspace.json SHA，才使用原 RELEASE 精确校验的 workspace_binding.py、原 Windows DPAPI 身份核对和原 SQLite 文件。部分参数、错公司、错 device、错 hash 或无数据库均报错，不退回空库、不重新登记设备。
3. 程序 project_root 始终是编译包自身的受校验代码位置。原项目根目录仅提供 data/state，不提供代码、许可或设备租约。不能为使用源码启动器而放宽 frozen-only customer authority。
4. 新客户发行版本必须在材料绑定前固定为 `1.2.0-read.1`。原 builder 把 releaseVersion 重设为 r57-standard-internal-v82 的赋值需要在新派生 builder 中明确适配；不能在材料生成后再改公司描述。
5. 本轮实际编译用原 F82 bootloader、PYZ 与依赖，只替换已审的 entry CodeType，运行三次 --check：默认目录、显式原目录、错误 binding SHA。它只证明编译入口的数据选择有效，不代表新合版已编译，也不代表 cloud readlease、自然验证窗或真实平台已通过。
6. 另外独立的旧绑定升级证据在相邻 customer-existing-binding-upgrade-after-f82-candidate：实际原 Service.bind 一次、Windows DPAPI、原 Service.stop、新 Service.start 和原认证心跳，5 条合成 protected rows 不变，新版不 enroll。它是 source/frozen 代表，不与本轮编译入口拼接冒称最终一条 compiled 业务链。

最终仍须在同一新合版的实际 compiled main EXE 中合验目录、原绑定、readlease 及业务入口，之后再更新本机启动器。不得覆盖当前客户数据或重启本人现有窗口。
