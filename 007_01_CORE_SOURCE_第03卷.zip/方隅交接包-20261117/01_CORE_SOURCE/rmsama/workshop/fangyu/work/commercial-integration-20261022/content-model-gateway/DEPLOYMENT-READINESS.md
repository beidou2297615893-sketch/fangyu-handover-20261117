# 内容生成接入准备核查

结论：第二版本地候选已修复HQ多店与两类设备标识接缝，真实云代码已只读核实。新接口未部署，真实私有成员/门店/执行设备/账号声明映射未知，不能判定生产已可启用。

## 当前部署证据

| 项目 | 本轮观察 |
| --- | --- |
| 官方读取 | 既有CloudBase CLI 3.5.5，ListFunctions、ListVersionByFunction、GetFunctionAddress |
| 函数/环境 | fangyu-workspace，fh6-d5ga45c0ddae7008c，ap-shanghai |
| 运行时/状态 | Nodejs20.19，Deployment completed；$LATEST为Active |
| 平台原样修改时间 | 2026-10-19 09:41:44；未推断其时区 |
| 代码ZIP SHA256 | 976de75d98b4aa72cad06b786c3c7eeea71f54ccbdb4957c4ce2d1f4b120e0ac；下载摘要等于官方CodeSha256 |
| 源码 | 19顶层文件逐字节匹配work/local-rules-integration/cloud/live-backups/after-QeaHL2 |
| 历史部署记录 | cloud/DEPLOYMENT.json为DEPLOYED_EXACT_READBACK，live_tree_sha256=80606e70cd53435d7c00cdfb4f53848cd4275b746b0614266b75a2d51ae4173f |

证据为baseline/LIVE-CLOUD-SHA256.json及work/LIVE-CODE-READ.json。官方CLI使用已有认证，没有手工提取/输出凭据，没有请求环境变量或私有业务整库，取码地址未保存或输出。未调用业务HTTP、新模型或平台。HTTP路由别名、真实请求执行和候选Node20.19云运行未验。

真实部署已有中央store_config与10月19日approved_intent_policy，但没有content_generate、content_generate_status或content_generation_capability。第一版旧workspace基线漏掉实际增量，本次已换真实19文件基线，不能用旧包覆盖。

## 身份与范围

| 关系 | 事实与未知 |
| --- | --- |
| 企业→租户 | 原Native算法：cloud-加SHA256(environment换行company)前24位。公开部署标识推导为cloud-5f633971ed95c5a0e0187b71；未读真实会话或策略，当前实际配置是否匹配未知。 |
| 成员→店 | 原中央resolver：admin为公司目录，operator为原store_id匹配中央目录的单店。10月17日真实14店核验仅为历史；今天私有目录未查，不把14当今天事实。 |
| 登录安装→执行设备 | Native记住登录用token_urlsafe(24)标识；云设备注册用randomBytes(18)标识，命名空间不同，不应直接相等。 |
| 执行设备→小红书 | devices.owner/revoked/digest及xhs_claims.device_id/account_id/uid_hash为原权威；当前真实记录未读，具体匹配未知。未创建声明。 |
| 账号→店 | 云声明没有账号门店字段。Native须用现有账号记录另核所选店；profile中央范围可用不表示选中账号已核验。 |
| 抖音 | 无等效权威登记，此云路径仍拒绝。 |

只读参考实际19源码、Native integrations.py、assistant/service.py、core/engine.py及workbench_backend.py的中央/账号检查。没有执行vault.read、读取DPAPI、本机真实DB或账号明细。

## 修复和边界

复用原中央authority、manifest/version与grant语义，在原事务预留、派发前、结果保存和回读核当前scope及版本。HQ无需固定店，operator原单店不放宽。运行中撤店、变grant/catalog仍结算usage且永久丢弃候选。客户端所选店不是授权。

执行设备从唯一原账号声明关联原devices，再核owner/未撤销/期望ID；记住登录和refresh不再误把安装ID当执行设备。换期望设备、其他成员设备、重复声明、撤销均拒绝。合法续期且授权未变可按原键读回原结果。

ai_profile投影默认关闭，中央范围及原AI配置/feature通过才available，缺失原因明确；不返回claim/UID/secret。细节见PROFILE-CONTRACT.md。Native账号门店、设备本机绑定及P1撤店/P2归档保护仍需接线前后检查。

## 合并与待验

相对真实部署改5文件、新增7云文件与3客户端文件。其中原键恢复、服务额度、发布规则辅助模块是待审基础增量，当前线上没有。原费用集合fangyu_ai_budget/ledger/cache不变。新原键索引fangyu_ai_request_index只追踪采用后请求；有限额度使用fangyu_product_quota_periods/requests；发布规则操作使用fangyu_intent_policy_versions/publications。未真实建表、迁移或回填，未给历史unknown造索引。

PRODUCT_ACCESS_POLICY缺失保留原试点权限；有限额度须服务器可信周期。CONTENT_GENERATION_POLICY缺失默认关闭。本轮没有读取或改变实际环境变量，所以真实策略状态未知。新增基础接口及集合采用要由总控在现有发布链审核，不能当已上线。

integration.patch相对根cloud/，只对独立当前源码准备副本合并，逐块保留总控最新P1中央撤店/P2归档保护和其他已接受增量。不要覆盖Native或其他作者候选。第二版包/补丁/固定文件见DELIVERY、PATCH-MANIFEST、CANDIDATE-FILES；第一版保留但已被替代。

新增154通过；历史核心107/115，8项旧提示词/版本断言在真实线上逐项同样失败；原service基线及候选均8/8；Python29/29；方法导出通过。Windows Node22合成数据库/provider不能证明真实CloudBase事务、Node20.19、真实模型质量或平台有效性。Native完整接线、公开原任务恢复、真实私有映射、显式启用和正式部署仍待总控验收。本轮没有真实付费模型或平台调用。
