"""Dedicated managed live child; never modifies the existing parent window.

Local WebView2 document-created registration completes before any platform URL.
No GUI, profile or network is opened merely by importing this module.
"""
import json,sys,threading,urllib.request,hashlib
from pathlib import Path
from urllib.parse import urlparse,parse_qs

PREPARATION_HTML='<!doctype html><meta charset="utf-8"><title>准备直播窗口</title><p>正在准备本账号的直播接收窗口；尚未打开平台。</p>'
ALLOWED={'/api/connect','/api/poll','/api/livestream/result','/api/disconnect'}
SOURCE_PINS={'observer': '0eadc73101e446298e5cc2f0520f2bf812a865adae426a4483b9b33408271d5e', 'control': '2fd78708424e0ca4ac486248edaf34d08cc6f98bcd251828a1f786f7727c1c1f'}

def checked_source(path,kind):
 path=Path(path);body=path.read_bytes()
 if path.is_symlink() or getattr(path.lstat(),'st_file_attributes',0)&0x400 or kind not in SOURCE_PINS or hashlib.sha256(body).hexdigest()!=SOURCE_PINS[kind]:raise ValueError('直播接收组件版本已变化，没有执行')
 return body.decode('utf-8')

def official_room(value,web_rid):
 p=urlparse(value)
 return p.scheme=='https' and p.hostname=='live.douyin.com' and not p.port and not p.username and not p.password and p.path in ('/'+web_rid,'/'+web_rid+'/') and not p.query and not p.fragment

def observer_script(raw,web_rid):
 # WebView2 also injects into subframes; only the explicitly chosen top page
 # gets the passive observer. No pywebview API is needed at document creation.
 return '(function(){if(window!==window.top||location.protocol!=="https:"||location.hostname!=="live.douyin.com"||location.port||location.pathname.replace(/\\/$/,"")!=='+json.dumps('/'+web_rid)+')return;const module={exports:{}};\n'+raw+'\nmodule.exports(window);})();'

def register_then_navigate(core,script,url,continue_on_ui,on_ready,on_error):
 """Inject once, then schedule navigation only after the registration Task.

 continue_on_ui supplies the original EdgeChrome UI TaskScheduler. Never call
 Wait/Result on an incomplete task from the UI thread.
 """
 task=core.AddScriptToExecuteOnDocumentCreatedAsync(script)
 def registered(done):
  try:
   if not done.IsCompleted or done.IsCanceled or done.IsFaulted:raise RuntimeError('document_created_registration_failed')
   if not str(done.Result):raise RuntimeError('document_created_registration_unconfirmed')
   on_ready();core.Navigate(url)
  except Exception as error:on_error(error)
 continue_on_ui(task,registered)
 return task

class LiveRelay:
 def __init__(self,config,spec,state):self.bridge=config['bridge'];self.spec=spec;self.state=state;self.window=None;self.conn_id=None
 def request(self,options):
  if not official_room(self.window.get_current_url() or '',self.spec['webRid']):raise ValueError('直播页已离开原房间；不会连接其他页面')
  u=urlparse(str(options.get('url','')));method=options.get('method','GET')
  if u.scheme!='http' or u.hostname!='127.0.0.1' or u.port!=self.bridge['port'] or u.path not in ALLOWED or u.username or u.password or u.fragment or method not in ('GET','POST'):raise ValueError('受控直播连接请求越界')
  raw=options.get('data');data=str(raw).encode() if raw is not None else None
  if data and len(data)>6291456:raise ValueError('直播回执超过有界上限')
  value=json.loads(data) if data else None
  if u.path=='/api/connect':
   if method!='POST' or not isinstance(value,dict) or set(value)!={'site','url','title','userAgent'} or value['site']!='douyin.com' or not official_room(value['url'],self.spec['webRid']) or any(not isinstance(value[k],str) or len(value[k])>500 for k in ('title','userAgent')) or self.conn_id is not None:raise ValueError('只允许登记原直播子页一次')
  elif u.path=='/api/poll':
   if method!='GET' or not self.conn_id or parse_qs(u.query)!={'site':['douyin.com'],'id':[self.conn_id]}:raise ValueError('直播控制连接不属于原子页')
  elif u.path=='/api/livestream/result':
   if method!='POST' or not self.conn_id or not isinstance(value,dict) or value.get('connId')!=self.conn_id:raise ValueError('直播回执不属于原子页')
  elif u.path=='/api/disconnect':
   if method!='POST' or not self.conn_id or not isinstance(value,dict) or value.get('id')!=self.conn_id:raise ValueError('只可撤销自己的控制监听')
  req=urllib.request.Request(u.geturl(),data=data,method=method,headers={'Content-Type':'application/json','Authorization':'Bearer '+self.bridge['token']})
  with urllib.request.urlopen(req,timeout=36 if u.path=='/api/poll' else 10) as response:
   text=response.read(6291457)
   if len(text)>6291456:raise ValueError('直播连接响应超过有界上限')
   if u.path=='/api/connect' and response.status==200:
    ident=json.loads(text).get('id')
    if ident:self.conn_id=ident;self.state('control_connected',connId=ident,accountConfirmed=False)
   return {'status':response.status,'responseText':text.decode('utf-8')}
 def dispatch(self,options,request_id,document_id):
  if not isinstance(request_id,str) or len(request_id)>100 or not isinstance(document_id,str) or len(document_id)>100:raise ValueError('直播连接请求标识无效')
  def work():
   try:value={'ok':True,'value':self.request(options)}
   except Exception:value={'ok':False,'error':'原直播连接已离开或暂不可用；请核对原窗口'}
   js='(()=>{const r=window.__workbenchRelay;if(r&&r.documentId==='+json.dumps(document_id)+'){const f=r.pending['+json.dumps(request_id)+'];if(f)f('+json.dumps(value,ensure_ascii=True)+');}})()'
   try:self.window.evaluate_js(js)
   except Exception:pass
  threading.Thread(target=work,daemon=True).start()

def main(spec_path=None):
 spec=json.loads(Path(spec_path or sys.argv[1]).read_text('utf-8'));config=json.loads(Path(spec['config']).read_text('utf-8'))
 import webview
 from webview.platforms import edgechromium
 from System import Action,String
 from System.Threading.Tasks import Task
 state_path=Path(spec['statePath']);current={'requestId':spec['requestId'],'accountId':spec['accountId'],'webRid':spec['webRid'],'windowOpen':False,'accountConfirmed':False,'platformLoginConfirmed':False}
 state_lock=threading.Lock()
 def state(status,**values):
  with state_lock:
   current.update(state=status,**values);temp=state_path.with_suffix('.tmp');temp.write_text(json.dumps(current,ensure_ascii=False),'utf-8');temp.replace(state_path)
 room='https://live.douyin.com/'+spec['webRid'];raw=checked_source(spec['observer'],'observer');script=observer_script(raw,spec['webRid'])
 class ManagedLiveEdge(edgechromium.EdgeChrome):
  def on_navigation_start(self,sender,args):
   url=str(args.Uri)
   if not url.startswith('about:') and not official_room(url,spec['webRid']):args.Cancel=True;state('page_blocked',code='LIVE_ROOM_NAVIGATION_BLOCKED');return
   super().on_navigation_start(sender,args)
  def on_new_window_request(self,sender,args):args.Handled=True
  def on_webview_ready(self,sender,args):
   if not args.IsSuccess:state('failed',code='LIVE_WINDOW_INITIALIZATION_FAILED');return
   # Original initialization only loads fixed local preparation HTML.
   super().on_webview_ready(sender,args)
   def continuation(task,callback):task.ContinueWith(Action[Task[String]](callback),self.syncContextTaskScheduler)
   register_then_navigate(sender.CoreWebView2,script,room,continuation,lambda:state('observer_registered',documentCreatedRegistered=True),lambda e:state('failed',code='LIVE_DOCUMENT_CREATED_FAILED'))
 edgechromium.EdgeChrome=ManagedLiveEdge  # This dedicated helper process only.
 relay=LiveRelay(config,spec,state)
 window=webview.create_window('直播窗口 · '+spec['accountName'],html=PREPARATION_HTML,js_api=relay,width=1180,height=820);relay.window=window
 def loaded():
  if not official_room(window.get_current_url() or '',spec['webRid']):return
  state('page_loaded',pageLoaded=True,documentCreatedRegistered=True)
  # Control waits for the existing pywebview-ready API. No page token is used.
  control=checked_source(spec['control'],'control').replace("server:'http://127.0.0.1:19432'","server:'http://127.0.0.1:"+str(config['bridge']['port'])+"'").replace("token:''","token:'managed-relay-marker'")
  # Adapt the original GM relay without placing its bearer token in the page.
  prefix='''if(!window.__workbenchManagedLive){window.__workbenchManagedLive=true;
const unsafeWindow=window;
const relayState=window.__workbenchRelay={documentId:crypto.randomUUID(),pending:{},serial:0};
const GM_xmlhttpRequest=options=>{const id=String(++relayState.serial);let done=false;
 const timer=setTimeout(()=>finish({ok:false,error:'原直播连接请求超时'}),options.timeout||35000);
 function finish(r){if(done)return;done=true;clearTimeout(timer);delete relayState.pending[id];if(r.ok)options.onload?.(r.value);else options.onerror?.(r.error);}
 relayState.pending[id]=finish;
 window.pywebview.api.dispatch({url:options.url,method:options.method||'GET',data:options.data},id,relayState.documentId).catch(()=>finish({ok:false,error:'原直播连接不可用'}));
};
'''
  wrapped=prefix+control+'\n}'
  window.evaluate_js('(()=>{const start=()=>{'+wrapped+'};if(window.pywebview?.api)start();else window.addEventListener("pywebviewready",start,{once:true});})()')
 window.events.loaded+=loaded
 state('opening')
 webview.settings['OPEN_EXTERNAL_LINKS_IN_BROWSER']=False
 webview.settings['ALLOW_DOWNLOADS']=False
 webview.start(gui='edgechromium',private_mode=False,storage_path=spec['profile'])
 state('closed',windowOpen=False)

if __name__=='__main__':main()
