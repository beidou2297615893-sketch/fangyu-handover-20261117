# Voice Cold Start

Use when account DNA is missing and/or the style library reports `voice_anchor=insufficient`.

The failure mode to prevent: writing like a generic national dry-goods account because market samples
are the only available text. Market samples teach **structure**, not **who is speaking**.

## Default stance (even with zero style refs)

**Still draft. Still sound human.** An empty style library is not permission to write like a tutorial
blog or a listicle farm.

When voice evidence is thin:

1. Infer whatever you can from this turn (身份、城市、品类、口头抱怨、用户原话选题)
2. Apply the **human texture recipe** below — required, not optional
3. Label `voice_source=provisional` + `voice_confidence=low|medium`
4. Mark invented-looking specifics as `[此处需你补真实细节]` instead of faking a biography
5. After the draft, offer: 贴 1 篇旧笔记进风格库，下回会更像你

Do **not** block the whole turn on a questionnaire. Ask at most 1 clarifying question **in parallel
with** a usable draft, or ask nothing if the brief already has enough nouns.

## Hard rule

Do **not** draft with `voice_source=market_samples` as the speaking voice.

| State | Draft? | Label |
|---|---|---|
| ≥2 user style refs | Yes, full voice | `user_library` |
| DNA voice rules | Yes | `dna` |
| Conversation clues + human texture recipe | Yes (default) | `provisional` |
| Only market / WebSearch samples, no human texture | No — rewrite | — |

If the user wants something immediately and the brief is thin, still draft with the human texture
recipe and low confidence — never fall back to 干货腔.

## Human texture recipe (required when style library is empty)

Every publish-ready body must include **at least 4 of 6**:

1. **正面判断** — 直接说你怎么想，禁止「不是A而是B」「说实话」「说白了」抬价
2. **一个不完美** — 踩坑、犹豫、局限、适用边界（一句就够）
3. **一个可感细节** — 时间、次数、物件、对话碎片、具体场景；没有真细节就写占位符，不要编造人生
4. **口语节奏** — 长短句有高低差；先交主干（谁做了什么）；禁止三项以上同构排比
5. **对一个人说话** — 像回朋友消息，不要对「大家」「宝子们」广播（除非 DNA 明确要求）
6. **事情讲完就停** — 可以留一个具体问题；不要升华到人生/时代，不要空 CTA

### Mini before/after

| 生硬（禁止） | 更像人（默认） |
|---|---|
| `分享 5 个提升效率的方法，希望对你有帮助` | `我试了一个月，真正留下来的只有这 3 个。其余两个是智商税` |
| `真正的成长，不是逼自己更狠，而是学会停下来` | `我把早起读书冥想全砍了。留到现在的，只有一件事还能让我轻松一点` |
| `说白了，你只是在用努力惩罚自己` | `清单越写越长，人越来越空。我当时就觉得不对，又不敢停` |

### Texture sources (priority)

1. User's own words in this chat (选题原文、抱怨、口头禅) — reuse lightly, don't parody
2. Concrete nouns in the brief (城市、品类、产品、流程)
3. Honest uncertainty + boundary — always available, needs no style library
4. Market samples — structure / section order only

## 60-second voice probe (optional, ≤1–2 asks)

Only ask what would materially change the draft. Prefer drafting first.

1. **你是谁 / 对谁说话** — 一句话
2. **一句你会发的开头** 或忌口词
3. **一个具体锚点** — 城市 / 品类 / 产品

Skip anything already answered. Do not turn this into a brand workshop.

## Provisional voice card

Write 4-6 lines when useful; reuse for the session:

```markdown
## Provisional voice
- speaker: ...
- reader: ...
- concrete nouns to keep: ...
- sentence length: short bursts | mixed
- stance: peer | specialist | diary
- human texture: 判断 + 不完美 + 可感细节 + 口语
- words to avoid: 大家呀 / 干货满满 / 闭眼入 / 希望对你有所帮助
```

## Market samples = scaffolding only

Extract: title mechanics, section rhythm, CTA placement, emoji density.

Discard: identity words, city/category nouns, hype lexicon, openings that work in any niche.

## Anti-patterns (reject in self-check)

- 全国干货腔 / 清单号口吻 / 空洞情绪开头
- 无第一人称、无判断、无不完美的「说明书正文」
- 用市场高赞笔记的人称和情绪词顶替说话人
- 把用户选题压短后，正文也跟着变空

## After the draft

Offer one of:

1. 把临时文风写入 DNA Voice 段
2. 收录 1 篇旧笔记到风格库（最有效）
3. 定稿进 Obsidian（`obsidian-archive.md`）
