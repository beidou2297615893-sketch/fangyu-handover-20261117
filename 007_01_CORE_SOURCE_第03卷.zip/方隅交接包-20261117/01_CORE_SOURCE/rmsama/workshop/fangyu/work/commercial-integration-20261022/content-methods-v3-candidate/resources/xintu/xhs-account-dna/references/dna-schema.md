# Account DNA Schema

## Required sections

- Evidence date and source list
- Positioning sentence: audience + problem + distinctive method + outcome
- Primary audience: jobs, pains, desired change, current awareness
- Three content pillars: purpose, proof, recurring formats, exclusions
- Voice: sentence length, stance, technical depth, phrases to use/avoid
- Visual system: palette, face usage, proof objects, density, forbidden patterns
- Proven signals: evidence and confidence
- Current hypotheses: hypothesis, evidence needed, expiry/review date
- Avoid list: off-position topics, unsupported claims, repetitive packaging
- Next three tests: variable, control, success signal

Never merge facts and hypotheses into the same bullet.

