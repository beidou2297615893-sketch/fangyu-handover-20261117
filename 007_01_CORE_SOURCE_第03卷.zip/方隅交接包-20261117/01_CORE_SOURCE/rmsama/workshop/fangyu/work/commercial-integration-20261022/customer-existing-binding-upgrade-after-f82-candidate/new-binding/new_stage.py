"""Relocatable standard Windows entry over the unchanged fixed r57 host.

This independently installed application initializes only its own empty data
directory. It grants no enterprise/device/platform permissions. Existing local
production binding and sessions are never consulted or copied.
"""
from pathlib import Path, PurePosixPath
import argparse, hashlib, http.client, importlib.util, importlib.machinery, json, os, socket, stat, sys
import threading
import time, uuid
sys.dont_write_bytecode = True
RELEASE_ID = 'ui-r57-20261023T095243Z-1c9a271f'
RELEASE_SHA = '295984d0359df693a35ce30a0c5a04b7360857af14f96e166e52b86c52a5645b'
CLOSURE_SHA = '562e8eef5452d4d3fc22378e9f7e238f4c497494541dd1a22115aa6d60933415'

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def exact(path, expected):
    for item in (path, *path.parents):
        info = item.lstat()
        if item.is_symlink() or getattr(info, 'st_file_attributes', 0) & 1024:
            raise RuntimeError('程序路径不能包含链接或重定向')
    before = path.stat()
    if not stat.S_ISREG(before.st_mode) or before.st_nlink != 1:
        raise RuntimeError('程序文件类型无效')
    raw = path.read_bytes()
    after = path.stat()
    if (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns) != (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns) or sha(raw) != expected:
        raise RuntimeError('程序文件校验失败')
    return raw

def output(value, path=None):
    raw = json.dumps(value, ensure_ascii=False, indent=2) + '\n'
    if path:
        with Path(path).open('x', encoding='utf-8') as stream:
            stream.write(raw)
    elif sys.stdout is not None:
        print(raw)

def load_host(root):
    project = root / 'project'
    closure = json.loads(exact(project / 'SHIPPED-PINS.json', CLOSURE_SHA))
    names = set()
    for row in closure['files']:
        relative = PurePosixPath(row['path'])
        if relative.is_absolute() or '..' in relative.parts or ':' in str(relative) or ('\\' in str(relative)) or (str(relative) in names):
            raise RuntimeError('程序清单路径无效')
        names.add(str(relative))
        raw = exact(project / relative, row['sha256'])
        if len(raw) != row['bytes']:
            raise RuntimeError('程序文件长度不匹配')
    actual = set()
    for path in project.rglob('*'):
        info = path.lstat()
        if path.is_symlink() or getattr(info, 'st_file_attributes', 0) & 1024:
            raise RuntimeError('程序目录包含未允许的链接或重定向')
        if '__pycache__' in path.relative_to(project).parts or path.suffix.lower() in ('.pyc', '.pyo'):
            raise RuntimeError('程序目录包含未允许的 Python 缓存代码')
        if path.is_file():
            actual.add(path.relative_to(project).as_posix())
    if actual != names | {'SHIPPED-PINS.json'}:
        raise RuntimeError('程序实际文件集合与完整清单不一致')
    code_pins = {row['path']: row for row in closure['files']}
    original_get_code = importlib.machinery.SourceFileLoader.get_code

    def source_only(loader, fullname):
        path = Path(loader.path).absolute()
        if path.is_relative_to(project):
            relative = path.relative_to(project).as_posix()
            row = code_pins.get(relative)
            if row is None or path.suffix.lower() != '.py':
                raise ImportError('未允许的程序代码来源')
            raw = exact(path, row['sha256'])
            return compile(raw, str(path), 'exec', dont_inherit=True, optimize=0)
        return original_get_code(loader, fullname)
    importlib.machinery.SourceFileLoader.get_code = source_only

    def code_audit(event, args):
        if event == 'open' and isinstance(args[0], (str, bytes, os.PathLike)):
            path = Path(os.fsdecode(args[0])).absolute()
            if path.is_relative_to(project) and path.suffix.lower() in ('.pyc', '.pyo'):
                raise PermissionError('程序不接受缓存字节码')
        if event == 'import' and len(args) > 1 and isinstance(args[1], str):
            path = Path(args[1]).absolute()
            if path.is_relative_to(project) and path.suffix.lower() in ('.pyd', '.dll', '.pyc', '.pyo'):
                row = code_pins.get(path.relative_to(project).as_posix())
                if row is None or path.suffix.lower() in ('.pyc', '.pyo'):
                    raise ImportError('未允许的扩展程序来源')
                exact(path, row['sha256'])
    sys.addaudithook(code_audit)
    release = project / 'work/ui-native-r57/releases' / RELEASE_ID
    raw = exact(release / 'RELEASE.json', RELEASE_SHA)
    manifest = json.loads(raw)
    entry = next((row for row in manifest['files'] if row['path'] == 'ui_native_host.py'))
    module = importlib.util.module_from_spec(importlib.util.spec_from_loader('fangyu_standard_native_host', loader=None))
    module.__file__ = str(release / 'ui_native_host.py')
    sys.modules[module.__name__] = module
    exec(compile(exact(release / 'ui_native_host.py', entry['sha256'].lower()), module.__file__, 'exec'), module.__dict__)
    return (module, project, release, closure)

def short_native_icon(release, state):
    """Keep .NET's legacy Icon file constructor below its path length limit."""
    manifest = json.loads(exact(release / 'RELEASE.json', RELEASE_SHA))
    row = next((item for item in manifest['files'] if item['path'] == 'resources/brand.ico'), None)
    if row is None:
        return
    source = release / 'resources/brand.ico'
    raw = exact(source, row['sha256'].lower())
    target = state / 'window.ico'
    if target.exists():
        exact(target, sha(raw))
    else:
        with target.open('xb') as stream:
            stream.write(raw)
        exact(target, sha(raw))
    if len(str(target)) >= 248:
        raise RuntimeError('Windows 用户资料路径过长，请使用标准用户资料目录')
    import webview
    original = webview.start

    def start(*args, **kwargs):
        if kwargs.get('icon') == str(source):
            kwargs['icon'] = str(target)
        return original(*args, **kwargs)
    webview.start = start

def own_directories():
    local = os.environ.get('LOCALAPPDATA')
    if not local or not Path(local).is_absolute():
        raise RuntimeError('Windows 用户资料目录不可用')
    root = Path(local) / 'FangyuWorkbenchStandard'
    for folder in (root, root / 'data', root / 'state'):
        folder.mkdir(parents=True, exist_ok=True)
        for item in (folder, *folder.parents):
            if item.is_symlink() or getattr(item.lstat(), 'st_file_attributes', 0) & 1024:
                raise RuntimeError('工作资料目录不能重定向')
    return (root / 'data', root / 'state')

def main():
    root = Path(sys.executable).resolve().parent if getattr(sys, 'frozen', False) else Path(__file__).resolve().parent
    parser = argparse.ArgumentParser(description='方隅工作台')
    group = parser.add_mutually_exclusive_group()
    group.add_argument('--check', action='store_true')
    group.add_argument('--self-test', action='store_true')
    parser.add_argument('--result-file')
    args = parser.parse_args()
    host, project, release, closure = load_host(root)
    data, state = own_directories()
    if args.check or args.self_test:
        argv = ['--check'] if args.check else ['--self-test']
        code = host.main(release, RELEASE_SHA, state, argv, project_root=project, data_dir=data)
        if code:
            raise RuntimeError('启动检查未通过')
        output({'status': 'PASS', 'releaseId': RELEASE_ID, 'frozen': getattr(sys, 'frozen', False) is True, 'internalStandardCandidate': True, 'commercialDistributionApproved': False, 'action': argv[0], 'closureFilesVerified': len(closure['files'])}, args.result_file)
        return 0
    short_native_icon(release, state)
    return host.main(release, RELEASE_SHA, state, [], project_root=project, data_dir=data)

import traceback,threading,time,http.client
from copy import deepcopy
if hasattr(sys.stdout,'reconfigure'):sys.stdout.reconfigure(encoding='utf-8')
ACTUAL_COMPILED=getattr(sys,'frozen',False) is True
B=Path(__file__).resolve().parent;T=B.parent;W=B/'payload';OUT=T/'new-stage-evidence';OUT.mkdir()
sys.frozen=True;sys.executable=str(W/'FangyuWorkbench.exe')
backend=None;passed=False;checks=[];device_calls=[];responses=[]
old=json.loads((T/'old-stage-evidence-resume/OLD-BINDING-RECEIPT.json').read_bytes())
save=lambda n,v:(OUT/n).write_bytes((json.dumps(v,ensure_ascii=False,indent=2)+'\n').encode())
def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m);return m
def audit(event,args):
    if event in ('subprocess.Popen','os.system','os.startfile','os.posix_spawn'):raise RuntimeError('No platform/native/process')
    if event in ('socket.connect','socket.bind') and (not isinstance(args[1],tuple) or args[1][0] not in ('127.0.0.1','::1')):raise RuntimeError('Loopback only')
    if event=='socket.getaddrinfo' and args[0] not in ('127.0.0.1','::1','localhost',None):raise RuntimeError('No external DNS')
    if event=='sqlite3.connect' and not Path(args[0]).resolve().is_relative_to(T):raise RuntimeError('Own DB only')
sys.addaudithook(audit)
port=json.loads((T/'ORIGINAL-CLOUD-BRIDGE.json').read_bytes())['port']
def actual_cloud(operation,data,token=''):
    c=http.client.HTTPConnection('127.0.0.1',port,timeout=30);c.request('POST','/call',json.dumps({'operation':operation,'data':data,'token':token}).encode(),{'Content-Type':'application/json'})
    r=c.getresponse();out=json.loads(r.read());c.close();assert r.status==200,out
    if out['status']!=200:
        from assistant.transport import CloudError
        raise CloudError(out['status'],str(out.get('data',{}).get('error','own-cloud-rejected')))
    return out['data']
class OwnOriginalCloud:
    def __init__(self,*a,**k):pass
    def call(self,operation,data,credential):
        device_calls.append(operation);assert operation not in ('device_enroll','pair_create'),'Upgrade must never bind again'
        value=actual_cloud(operation,data,credential)
        if operation=='device_poll':responses.append({'version':data.get('version'),'protocol':data.get('customer_read_protocol'),'response':{k:value.get(k) for k in ('safety_hold','customer_read_release','employee_release')}})
        return value
    def close(self):pass
try:
    host,project,release,closure=load_host(W);manifest,files=host.verify_release(release,RELEASE_SHA);host.verify_backend_dependencies(release,files,project)
    E=T.parent/'customer-distribution-entry-after-f82-candidate';F=T.parents[2]/'work/parallel-integration-20261018/final-integration/candidate-unified-v82/project'
    adapter_path=E/'existing_workspace_entry.py';support_path=F/'work/ui-native-r57/workspace_binding.py'
    assert sha(adapter_path.read_bytes())=='58cd9c8066533eb9196ef69fcad325bd0be9fb47a333dbf236d5b776bac3b33a'
    assert sha(support_path.read_bytes())=='903f498084ad56deacf86e6436a57a3479506f6a3a46124dc11a58d96984c7c5'
    adapter=load('own_existing_entry',adapter_path);support=load('own_original_workspace_binding',support_path)
    root=Path(old['existingRoot']);before_paths={str(p.relative_to(T)) for p in T.rglob('*')}
    assert adapter.select_existing_workspace(None,None,support) is None
    try:adapter.select_existing_workspace(str(root),'0'*64,support)
    except adapter.ExistingWorkspaceSelectionError:pass
    else:raise AssertionError('Changed hash accepted')
    assert {str(p.relative_to(T)) for p in T.rglob('*')}==before_paths
    selected,state=adapter.select_existing_workspace(str(root),old['bindingSha256'],support)
    assert selected==Path(old['dataDir']) and state==root/'work/ui-native-r57/state'
    # Bad descriptor copies reference the same OLD data; no data/vault copy,
    # new device, migration or fallback workspace is permitted.
    original=json.loads((root/support.BINDING_RELATIVE).read_bytes())
    for field,value in [('company_id','other-company'),('device_id','OtherOwnDevice000000000000')]:
        neg=T/('negative-'+field);path=neg/support.BINDING_RELATIVE;path.parent.mkdir(parents=True)
        bad={**original,field:value};path.write_bytes(json.dumps(bad).encode());before={str(p.relative_to(T)) for p in T.rglob('*')}
        try:adapter.select_existing_workspace(str(neg),sha(path.read_bytes()),support)
        except support.WorkspaceBindingError:pass
        else:raise AssertionError(field+' mismatch accepted')
        assert before=={str(p.relative_to(T)) for p in T.rglob('*')}
    checks.append({'group':'explicit-existing-selection-actual-old-service-dpapi-and-negative-company-device-hash','noEmptyFallback':True})
    DATA=selected;vault=DATA/'assistant/device.dpapi';assert sha(vault.read_bytes())==old['vaultSha256']
    fixture=load('own_new_ui_cloud',W/'qa-fixtures/cloud_fixture.py');cloud=fixture.CloudStandin(json.loads((W/'qa-fixtures/compiled-fixture.json').read_bytes()))
    company=json.loads((project/'work/app/company.json').read_bytes());assert company['releaseVersion']=='1.2.0-read.1'
    integration=load('integrations',release/'resources/platform-runtime/vendor-src/integrations.py')
    def transport(*a,**k):
        op=(a[1] if len(a)>1 else k.get('data',{})).get('operation');assert op not in ('intent_analyze','ai_attempt_status')
        value=cloud(*a,**k);value['environment_id']=company['managedWorkspace']['environment_id'];return value
    integration.request_json=transport
    backend=host.create_backend(release,files,project_root=project,data_dir=DATA,company=company)
    runtime=backend.platform_runtime;app=runtime.server;core=backend.core
    app._configure_bundled();runtime._platform_setup=True
    def projection():
        entities=old['protectedEntities']
        with core.store.connect() as db:
            return [tuple(r) for r in db.execute('SELECT entity,id,tenant_id,body FROM records WHERE entity IN ('+','.join('?' for _ in entities)+') ORDER BY entity,id',entities)]
    digest=lambda rows:sha(json.dumps(rows,ensure_ascii=False,separators=(',',':')).encode())
    baseline=projection();assert len(baseline)==old['protectedRows'] and digest(baseline)==old['protectedRowsSha256']
    saved=runtime.service.vault.read();assert saved['device']['id']==old['deviceId'] and sha(saved['token'].encode())==old['tokenSha256']
    from assistant.customer_read_lease import current,enrollment_fields,from_heartbeat
    assert enrollment_fields(app)=={'version':'1.2.0-read.1','customer_read_protocol':'fangyu-customer-read-v1'}
    runtime.service.cloud_factory=OwnOriginalCloud;runtime.service.start()
    deadline=time.monotonic()+25
    while not current(app,'douyin_owned_connection') and time.monotonic()<deadline:time.sleep(.03)
    assert current(app,'douyin_owned_connection'),{'state':runtime.service.status(),'responses':responses}
    assert current(app,'douyin_owned_video_comments') and current(app,'douyin_owned_keyword_search_page')
    rr=runtime.service._customer_read_runner;executor=runtime.service.executor
    assert rr and executor and executor._xhs_app_session and rr.execute is executor
    assert rr.accept_commands is False and rr.portable_employee_release is False
    assert not core._employee_release_allowed() and not core.employee_release_device_id and core.employee_release_until_monotonic==0
    assert sha(vault.read_bytes())==old['vaultSha256'] and runtime.service.vault.read()==saved
    assert projection()==baseline
    assert device_calls.count('device_enroll')==0 and device_calls.count('device_poll')>=1
    checks.append({'group':'same-original-dpapi-token-device-old-bind-to-new-original-service-start-heartbeat','readPurposes':3,'generalEmployeeGrant':False,'enrollCalls':0,'sameEncryptedVaultBytes':True,'protectedRowsExact':len(baseline)})
    # Actual authenticated response rejected for mismatched company/device.
    valid={'safety_hold':False,'customer_read_release':responses[-1]['response']['customer_read_release']}
    for field,value in [('company_id','other-company'),('device_id','OtherOwnDevice000000000000')]:
        bad=deepcopy(valid);bad['customer_read_release'][field]=value
        assert from_heartbeat(rr.customer_read_request,rr,bad,time.monotonic()) is None
    assert all(not current(app,p) for p in ('unknown-purpose','xiaohongshu_natural_read','xiaohongshu_identity_observation','xiaohongshu_session_recovery'))
    user=core.store.list('users')[0]
    try:runtime._executor(user)
    except Exception as e:assert getattr(e,'code',None)=='DEVICE_LEASE_UNCONFIRMED',str(e)
    else:raise AssertionError('Read upgrade widened default executor')
    assert company['runtime']['public_send_hold'] is True and company['runtime']['release_approved'] is False
    checks.append({'group':'new-lease-does-not-upgrade-general-send-or-unreviewed-purpose','mismatchedHeartbeatCases':2,'defaultExecutorBlocked':True,'publicSendHeld':True})
    assert runtime.service.stop(timeout=15)
    assert projection()==baseline and digest(projection())==old['protectedRowsSha256'] and sha(vault.read_bytes())==old['vaultSha256']
    assert runtime.service.vault.read()==saved
    save('UPGRADE-RESULTS.json',{'status':'PASS_EXISTING_ACTUAL_SERVICE_BINDING_UPGRADE','actualCompiledExe':ACTUAL_COMPILED,'sourceFrozenRepresentativeOnly':not ACTUAL_COMPILED,
        'oldVersion':'1.1.8-pilot.1','newVersion':'1.2.0-read.1','groups':checks,'groupCount':len(checks),'sameDataDir':str(DATA),'sameWindowsDpapiVault':True,
        'vaultSha256':old['vaultSha256'],'tokenSha256':old['tokenSha256'],'deviceId':old['deviceId'],'protectedRowsSha256':digest(baseline),'protectedRows':len(baseline),
        'deviceCalls':device_calls,'actualAuthenticatedOriginalCloudResponses':responses,'explicitOriginalSelection':True,'rebindOrDeviceReplacement':False,
        'platformModelNativeCalls':0,'productionDataReadOrWritten':False,'serviceSourceSha256':sha((release/'resources/platform-runtime/vendor-src/assistant/service.py').read_bytes()),
        'helperSha256':sha((project/'work/ui-runtime-r55/src/assistant/customer_read_lease.py').read_bytes())})
    passed=True
finally:
    if sys.exc_info()[0]:save('ERROR.json',{'traceback':traceback.format_exc()})
    if backend:backend.close()
    save('CLOSED.json',{'passed':passed,'ownBackendClosed':backend is None or runtime.service.closed,'cloudKeptForFinalCallAudit':True,'platformNativeModelCalls':0})
    print(json.dumps({'status':'PASS_UPGRADE' if passed else 'RED','evidence':str(OUT)},ensure_ascii=False))
