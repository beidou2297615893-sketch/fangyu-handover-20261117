"""Own representative entries only; never run against an author sealed directory."""
from pathlib import Path
import ast, sys
W=Path(__file__).resolve().parent;P=W.parents[2]
B=W/(sys.argv[1] if len(sys.argv)>1 else 'compiled-probe-final')
def exact_write(path,raw):
    path.parent.mkdir(parents=True,exist_ok=True)
    if path.exists():
        if path.read_bytes()!=raw:raise RuntimeError('Existing own input differs; preserve evidence')
    else:path.write_bytes(raw)
source=(P/'work/acquisition-core-repair-20261018/gui-fixture/base_fixture.py').read_text('utf-8')
nodes=[node for node in ast.parse(source).body if isinstance(node,(ast.FunctionDef,ast.ClassDef)) and node.name in ('digest','CloudStandin')]
assert len(nodes)==2
cloud="from copy import deepcopy\nimport hashlib,json,secrets,time\nPASSWORD='fixture-password-123'\nCOMPANY='fangyu-apartment-client'\n"+'\n'.join(ast.get_source_segment(source,node) for node in nodes)+'\n'
exact_write(B/'payload/qa-fixtures/cloud_fixture.py',cloud.encode('utf-8'))
exact_write(B/'payload/qa-fixtures/compiled-fixture.json',(P/'work/central-store-config/compiled-fixture.json').read_bytes())
prefix=(B/'standard_loader_prefix.py').read_text('utf-8')
body=(W/'probe_body.py.in').read_text('utf-8')
exact_write(B/'probe_entry.py',(prefix+'\n'+body).encode('utf-8'))
company_path=str(P/'work/parallel-integration-20261018/final-integration/candidate-unified-v82/project/work/app/company.json').replace('\\','/')
source_body='SOURCE_COMPANY_PATH='+repr(company_path)+'\n'+(W/'source_entry_check.py.in').read_text('utf-8')
exact_write(B/'source_entry_check.py',(prefix+'\n'+source_body).encode('utf-8'))
print('Own source and compiled entry inputs ready; no platform action')
