from pathlib import Path
U=Path(r'C:/积木软件工坊/项目/方隅公寓客户版/work/parallel-integration-20261018/final-integration/stage-02/project/work/ui-approved-implementation/ui-preview')
p=U/'pages/content-operations.mjs';s=p.read_text('utf-8')
s="import {renderWorkflow,bindWorkflow} from './content-workflow.mjs';\n"+s
old='${content}</div></div>`;'
assert s.count(old)==1
s=s.replace('<div id="co-tab-panel" role="tabpanel"','${renderWorkflow(state,u,w)}<div id="co-tab-panel" role="tabpanel"')
s=s.replace(old,"${u.workflowUI?.open?'':content}</div></div>`;")
s=s.replace("<button type=\"button\" class=\"co-button\" disabled title=\"未连接创作模型，可先准备提示词或手工编辑\">${icon('fy-icon-62-ai.png')}生成草稿 · 待配置</button>","<button type=\"button\" class=\"co-button\" data-wf-method=\"${d.format==='video'?'video':'writing'}\" ${w?.workflowContract!=='fangyu-content-workflow-v1'?'disabled':''}>${icon('fy-icon-62-ai.png')}${w?.workflowCapabilities?.canRunTasks?'生成草稿':'准备生成任务'}</button>")
s=s.replace("button('导出内容包','export-draft'","button('导出草稿文本','export-draft'").replace("button('导出内容包','export-selected'","button('导出草稿文本','export-selected'")
s=s.replace("u.notice='内容包已导出，未向平台发布。';","u.notice='草稿文本已导出，未向平台发布。';")
s=s.replace('return ()=>{disposed=true;};','const releaseWorkflow=bindWorkflow(root,ctx,u);\n  return ()=>{disposed=true;releaseWorkflow?.();};')
p.write_text(s,'utf-8')
p=U/'backend.mjs';s=p.read_text('utf-8')
old="'content_workspace_read','content_persona_save','content_topic_save','content_draft_save','content_draft_audit','content_schedule_save','content_metrics_save','content_export','content_prompt_prepare','content_asset_import','content_render_cards'"
new=old+",'content_knowledge_import','content_knowledge_search','content_methods_read','content_task_prepare','content_task_run','content_task_apply','content_package_build'"
assert s.count(old)==1;s=s.replace(old,new)
old="if(remoteActions.has(action)&&result?.error?.mutation_committed===false)failure.mutationCommitted=false;"
assert s.count(old)==1;s=s.replace(old,"if((remoteActions.has(action)||content)&&result?.error?.mutation_committed===false)failure.mutationCommitted=false;")
p.write_text(s,'utf-8')
