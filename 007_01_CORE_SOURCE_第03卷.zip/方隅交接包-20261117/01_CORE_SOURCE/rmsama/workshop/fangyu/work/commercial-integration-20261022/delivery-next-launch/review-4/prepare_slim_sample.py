"""Reuse original installer detection, omit only WebView2 offline prerequisite."""
from pathlib import Path
from collections import defaultdict
import hashlib,json,shutil,zipfile
HERE=Path(__file__).resolve().parent
SAMPLE=HERE/'standard-sample-v70'
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def main():
    archive=SAMPLE/'FangyuWorkbench-standard-sample-v70.zip'
    groups=defaultdict(lambda:{'files':0,'bytes':0,'compressedBytes':0})
    with zipfile.ZipFile(archive) as source:
        for row in source.infolist():
            group=('Microsoft WebView2 offline prerequisite' if row.filename.startswith('prerequisites/') else
                   'full public project' if row.filename.startswith('project/') else 'frozen host and launcher')
            groups[group]['files']+=1;groups[group]['bytes']+=row.file_size;groups[group]['compressedBytes']+=row.compress_size
    slim=SAMPLE/'slim';slim.mkdir(exist_ok=False)
    target=slim/'FangyuWorkbench-standard-sample-v70-requires-WebView2.zip'
    with zipfile.ZipFile(target,'x',zipfile.ZIP_DEFLATED,compresslevel=5) as output,zipfile.ZipFile(archive) as source:
        for row in source.infolist():
            if not row.filename.startswith('prerequisites/'):
                output.writestr(row,source.read(row.filename))
    setup=slim/'FangyuWorkbenchSetup-standard-sample-v70-requires-WebView2.exe'
    shutil.copy2(SAMPLE/'dist/FangyuWorkbenchSetup.exe',setup)
    with setup.open('ab') as output,target.open('rb') as source:shutil.copyfileobj(source,output)
    with zipfile.ZipFile(setup) as z:
        if z.testzip():raise RuntimeError('Slim installer embedded archive corrupt')
    report={'status':'SLIM_REPRESENTATIVE_BUILT_BACKEND_GATE_PENDING','groups':dict(groups),
        'fullZipBytes':archive.stat().st_size,'slimZipBytes':target.stat().st_size,
        'zipBytesSaved':archive.stat().st_size-target.stat().st_size,
        'slimInstallerBytes':setup.stat().st_size,'slimZipSha256':sha(target),'slimInstallerSha256':sha(setup),
        'originalInstallerBytesUnchanged':True,'oldInstallerHasExistingWebView2Detection':True,
        'missingWebView2Behavior':'Explicitly stops and asks user to install official runtime; no automatic download.',
        'existingWebView2FirstStartVerified':False,'backendGateDiscovered':True,
        'sourceAndGuardBytesEdited':False,'privateDataIncluded':False,'bundledFfmpeg':False}
    (slim/'SIZE-AND-BOUNDARIES.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n','utf-8')
    print(json.dumps({'groups':report['groups'],'fullZipBytes':report['fullZipBytes'],'slimZipBytes':report['slimZipBytes'],'slimInstallerBytes':report['slimInstallerBytes']},ensure_ascii=True))
if __name__=='__main__':main()
