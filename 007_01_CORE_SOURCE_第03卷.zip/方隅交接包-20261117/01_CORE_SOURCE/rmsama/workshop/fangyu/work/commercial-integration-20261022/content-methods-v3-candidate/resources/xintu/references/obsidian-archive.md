# Obsidian Archive

After a package passes `xhs-publish-guard` (or the user accepts a draft), offer to archive it into the
user's Obsidian vault. Archiving is optional and never automatic.

## When to offer

- End of a production chain (carousel or video package ready)
- End of a topic-radar session with ranked candidates the user wants to keep
- After DNA / provisional voice is confirmed
- When the user says 存一下 / 沉淀 / 放进笔记 / Obsidian

Ask once:

> 要把这篇定稿落到 Obsidian 吗？给我仓库路径，或说「用默认目录」。

## Default paths

Prefer project vault if present, else a suite default the user can change:

| Kind | Default relative path |
|---|---|
| Carousel / image note | `20-小红书/图文/YYYY-MM-DD-短标题.md` |
| Video package | `20-小红书/视频/YYYY-MM-DD-短标题.md` |
| Topic batch | `20-小红书/选题/YYYY-MM-DD-主题.md` |
| Account DNA snapshot | `20-小红书/账号/account-dna.md` |

Resolve the vault root in this order:

1. User-specified absolute path this turn
2. Env `XHS_OBSIDIAN_VAULT`
3. Workspace `.obsidian/` parent (if the current workspace is an Obsidian vault)
4. `~/Documents/Obsidian/xhs-creator/` (create if the user confirms)

Never write outside the chosen vault without confirmation.

## Note template (carousel / video)

```markdown
---
type: xhs-note
format: carousel|video
status: draft|ready|published
title: ...
created: YYYY-MM-DD
tags: [xhs, ...]
voice_source: user_library|dna|provisional|market_samples
---

# {{title}}

## 元信息
- 格式:
- 推荐标题:
- 备选标题:
- 标题任务: feed|search|hybrid
- 风格来源:
- 质检结果: go|revise|stop

## 正文 / 配文

...

## 标签
...

## CTA
...

## 视觉备忘
- 封面/首帧要点:
- slide 大纲:（如有）

## 视频附件（仅 video）
- 口播/分镜摘要或链接:
- script_boundary:

## 待补细节
- [此处需你补真实细节] 列表

## 来源
- DNA:
- 风格库条目:
- 市场样本:（只记结构，不记可抄原文）
```

## Topic batch template

```markdown
---
type: xhs-topics
created: YYYY-MM-DD
data_source: justone_api|websearch
---

# 选题 {{主题}}

| 选题 | 适配度 | 新鲜度 | 证据强度 | 建议格式 | 备注 |
|---|---|---|---|---|---|
| ... | | | | | |

## 本轮推荐
...

## 数据局限
...
```

## Write behaviour

1. Show the target path and a short preview before writing.
2. Create parent folders as needed.
3. If the file exists, append a dated section or ask to overwrite — never silent overwrite.
4. After write, tell the user the absolute path (Obsidian can open it from there).
5. Optionally also append one line to `~/.xhs/draft-ledger.jsonl` for suite-side history.

## What not to put in Obsidian

- API tokens
- Raw Just One JSON dumps with full payloads (summarise instead)
- Other creators' full note bodies copied from market samples

## Relationship to suite storage

| Artifact | Suite default | Obsidian |
|---|---|---|
| Account DNA | `~/.xhs/account-dna.md` | Optional mirror under `20-小红书/账号/` |
| Style library | `~/.xhs/style-library/` | Do not duplicate; link or mention ids |
| Publish package | chat / temp | Primary long-term home when user opts in |
