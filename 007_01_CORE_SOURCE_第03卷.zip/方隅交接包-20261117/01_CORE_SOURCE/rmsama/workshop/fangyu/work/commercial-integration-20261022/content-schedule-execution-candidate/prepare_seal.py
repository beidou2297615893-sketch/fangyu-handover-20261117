from pathlib import Path
import ast,difflib,hashlib,json,shutil
W=Path(__file__).resolve().parent;P=W.parents[2];S=W/'source-candidate'
F=P/'work/parallel-integration-20261018/final-integration/candidate-unified-v77/project'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(name,v):(W/name).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n','utf-8')
base=json.loads((W/'BASE-HASHES.json').read_text('utf-8'))
expected={
 'work/ui-native-r57/content_extension_loader.py','work/ui-native-r57/freeze_ui.py',
 'work/ui-native-r57/ui_native_host.py','work/ui-native-r57/workbench_backend.py',
 'work/ui-approved-implementation/ui-preview/backend.mjs','work/ui-approved-implementation/ui-preview/pages/content-operations.mjs'}
new={'work/ui-native-r57/content_schedule.py','work/ui-approved-implementation/ui-preview/pages/content-schedule.mjs'}
changed={rel for rel,record in base['files'].items() if sha(S/rel)!=record['sha256']}
assert changed==expected,(changed,expected)
for rel,record in base['files'].items():assert sha(F/rel)==record['sha256']
overlay=W/'overlay';assert not overlay.exists();patch=[];records=[]
for rel in sorted(changed|new):
    raw=(S/rel).read_bytes();old=(F/rel).read_bytes() if rel in changed else b''
    if old:
        assert raw.count(b'\r\n')>0 if old.count(b'\r\n') else b'\r\n' not in raw
        assert raw.count(b'\n')==raw.count(b'\r\n') if old.count(b'\n')==old.count(b'\r\n') else True
    target=overlay/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw)
    patch.extend(difflib.unified_diff(old.decode('utf-8').splitlines(keepends=True),raw.decode('utf-8').splitlines(keepends=True),fromfile='a/'+rel if old else '/dev/null',tofile='b/'+rel))
    records.append({'path':rel,'beforeSha256':hashlib.sha256(old).hexdigest() if old else None,'afterSha256':sha(target),
        'bytesBefore':len(old),'bytesAfter':len(raw),'beforeCrlf':old.count(b'\r\n'),'afterCrlf':raw.count(b'\r\n')})
(W/'CHANGES.patch').write_bytes(''.join(patch).encode('utf-8'))
save('SOURCE-FILES.json',{'baseRootPinsSha256':base['rootPinsSha256'],'overlay':'overlay','files':records})
protected=['content_workbench.py','content_workflow.py','content_publishing.py','publishing_port.py','publication_protocol.py',
    'publication_authority_host.py','owned_publication_host.py','publication_policy.py']
proof={name:sha(S/'work/ui-native-r57'/name) for name in protected}
for name,pin in proof.items():assert pin==sha(F/'work/ui-native-r57'/name)
original=ast.parse((F/'work/ui-native-r57/ui_native_host.py').read_bytes());candidate=ast.parse((S/'work/ui-native-r57/ui_native_host.py').read_bytes())
guards=('read_public','verify_release','verify_backend_dependencies','create_backend')
for name in guards:
    def get(tree):return next(n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name==name)
    assert ast.dump(get(original),include_attributes=False)==ast.dump(get(candidate),include_attributes=False),name
core_count=0
for rel in base['files']:
    if rel.startswith('work/ui-runtime-r55/src/') and rel.endswith('.py'):
        assert sha(S/rel)==base['files'][rel]['sha256'];core_count+=1
save('PROTECTED-SOURCE-CHECK.json',{'status':'PASS','unchangedPublicationAndWorkflow':proof,
    'nativeSourceCacheAndFactoryGuardsAstUnchanged':list(guards),'originalCoreSourceFilesUnchanged':core_count,
    'wirePolicyUnchangedHeld':True,'changedExistingFiles':len(changed),'newSourceFiles':len(new)})
c=P.parents[1]/'核心组件/社媒人设与内容运营组件库/runtime/projects/Yht20927__douyin-cli'
assert c.is_dir(),str(c)
save('UPSTREAM-REUSE.json',{'skill':'social-ops-components','selected':'Yht20927/douyin-cli','localCommit':'4073159bea585de6d33a4747a475669440737932',
    'readSourcePins':{name:sha(c/name) for name in ('SKILL.md','LICENSE','lib/commands/campaign.js','lib/memory/campaigns.js','package.json')},
    'license':'MIT / Copyright (c) 2026 Yht20927','remoteChecked':'https://github.com/Yht20927/douyin-cli',
    'remoteSourceChecked':'https://raw.githubusercontent.com/Yht20927/douyin-cli/main/lib/commands/campaign.js','remoteLatestCommitNotClaimed':True,
    'reuse':'Fixed account at plan time, persisted due items, idempotence and pause/resume design; no upstream source copied into product.',
    'notImported':'Comment campaign semantics, detached Node daemon and its independent better-sqlite3 database conflict with original publication/auth/Store contracts.',
    'windowsAndDependencies':'Upstream requires Node >=18, better-sqlite3 native addon and browser bridge. Existing Python/SQLite seam avoids adding that ABI/runtime/credential path. New code uses only Python stdlib and existing UI modules.',
    'realUpstreamPlatformInvocation':False})
print(json.dumps({'sourceFiles':len(records),'sourcePinsSha256':sha(W/'SOURCE-FILES.json'),'patchSha256':sha(W/'CHANGES.patch'),'protected':True}))
