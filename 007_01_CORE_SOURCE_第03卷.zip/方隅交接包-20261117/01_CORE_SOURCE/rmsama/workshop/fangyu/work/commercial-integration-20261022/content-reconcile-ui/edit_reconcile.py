from pathlib import Path
u=Path(r'C:/积木软件工坊/项目/方隅公寓客户版/work/parallel-integration-20261018/final-integration/stage-02/project/work/ui-approved-implementation/ui-preview')
p=u/'backend.mjs';s=p.read_text(encoding='utf-8');s=s.replace("'content_task_run','content_task_apply'", "'content_task_run','content_task_reconcile','content_task_apply'");p.write_text(s,encoding='utf-8')
p=u/'pages/content-workflow.mjs';s=p.read_text(encoding='utf-8')
old="${['running','unknown'].includes(task.state)?'<p class=\"co-note\">原执行结果仍待核对，不会重新调用模型。可继续处理其他本地草稿。</p>':''}"
new="${['running','unknown'].includes(task.state)?`<p class=\"co-note\">${w.workflowCapabilities?.canReconcileTasks===true?'查询上次结果，不重新生成。结果未确认前，保留原任务与编号。':'原执行结果仍待核对。结果查询尚未开放，原任务与编号已保留。'}</p>${!readOnly&&task.runRequestId&&w.workflowCapabilities?.canReconcileTasks===true?btn('核对原结果','reconcile-run',{disabled:!!f.pending||!!f.localUnknown,extra:`data-request=\"${esc(task.runRequestId)}\" data-task=\"${esc(task.id)}\"`}):''}`:''}"
assert old in s;s=s.replace(old,new)
old="${!readOnly&&task.runRequestId?btn('核对原执行结果','check-run'"
new="${!readOnly&&task.runRequestId&&!['running','unknown'].includes(task.state)?btn('读取本地执行记录','check-run'"
assert old in s;s=s.replace(old,new)
s=s.replace("btn('核对原执行记录','check-run'", "btn('读取本地执行记录','check-run'")
s=s.replace("f.notice=STATES[t.state]||'执行结果仍待核对。';", "f.notice='已读取本机记录：'+(STATES[t.state]||'执行结果仍待核对。');")
anchor="async function action(ctx,u,element)"
addition='''async function reconcileRun(ctx,u,requestId,taskId){
  const state=ctx.state,f=wf(state,u),scope=f.scope,w=state.contentWorkspace;
  if(f.pending||!current(state,u,f)||!validateResponse(state,u,{workspace:w},scope))return;
  const task=arr(dataOf(w),'tasks').find(t=>t.id===taskId);
  if(!task||task.runRequestId!==requestId||!['running','unknown'].includes(task.state))throw Error('原任务状态已变化，请先读取本地执行记录。');
  if(w.workflowCapabilities?.canReconcileTasks!==true)throw Error('结果查询尚未开放，原任务与编号已保留。');
  if(u.pending||u.uncertain||u.readRequired||f.localUnknown)throw Error('请先核对当前内容的原保存结果。');
  remember(f.persistScope,requestId,taskId);
  if(!readSaved(f.persistScope).some(r=>r.requestId===requestId&&r.taskId===taskId))throw Error('无法保存原执行核对断点，本次尚未查询。');
  const payload={storeId:state.storeId,accountId:u.accountId,platform:state.activePlatform||'xiaohongshu',taskId,expectedRevision:w.revision,requestId};
  const sequence=++f.sequence;
  update(ctx,()=>{f.pending='正在查询上次结果，不重新生成…';f.error='';f.notice='';f.saved=readSaved(f.persistScope);f.runUnknown={requestId,taskId};});
  try{
    const response=await ctx.contentAction('content_task_reconcile',payload);
    if(!current(state,u,f)||!validateResponse(state,u,response,scope)||f.sequence!==sequence)return;
    const receipt=response.receipt,t=response.result?.task,stored=arr(dataOf(response.workspace),'tasks').find(row=>row.id===taskId);
    if(receipt?.found!==true||receipt.action!=='content_task_run'||receipt.requestId!==requestId||t?.id!==taskId||t.runRequestId!==requestId
      ||stored?.runRequestId!==requestId||stored.state!==t.state||receipt.state!==t.state)throw Error('原执行回执尚未匹配，继续保留原编号。');
    const queried=response.result.reconciled===true&&response.result.modelCalled===false&&response.result.statusChecked===true&&response.result.newGenerationDispatched===false;
    if(!queried&&!(response.replayed===true&&CLOSED.has(t.state)))throw Error('原执行查询结果尚未确认，继续保留原编号。');
    update(ctx,()=>{
      adopt(ctx,u,response);f.taskId=taskId;f.mode='tasks';
      if(CLOSED.has(t.state)){forget(f.persistScope,requestId);f.saved=readSaved(f.persistScope);f.runUnknown=null;}
      f.notice=t.state==='succeeded'?(response.replayed?'原结果已完成，已读取原回执，请核对后采用。':'已找回原生成结果，请核对来源与假设后采用。')
        :['running','unknown'].includes(t.state)?'上次结果仍未确认，已保留原编号；没有重新生成。':STATES[t.state]||'原任务已保留，请核对结果。';
    });
  }catch(error){if(current(state,u,f)&&f.scope===scope&&f.sequence===sequence)update(ctx,()=>{f.notice='';f.error=error?.message||'上次结果仍待核对，已保留原编号。';f.saved=readSaved(f.persistScope);});}
  finally{if(current(state,u,f)&&f.scope===scope&&f.sequence===sequence)update(ctx,()=>{f.pending='';});}
}
'''
assert anchor in s;s=s.replace(anchor,addition+anchor)
s=s.replace("  if(kind==='check-run'){", "  if(kind==='reconcile-run'){await reconcileRun(ctx,u,element.dataset.request,element.dataset.task);return;}\n  if(kind==='check-run'){")
p.write_text(s,encoding='utf-8')
