from pathlib import Path
from datetime import datetime,timezone
import difflib,hashlib,json
W=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
files=json.loads((W/'CAS-FILES.json').read_text(encoding='utf-8'))
for src,rel in [('customer_outcomes_workbench.py','work/ui-native-r57/customer_outcomes_workbench.py'),('customer-outcomes.mjs','work/ui-approved-implementation/ui-preview/pages/customer-outcomes.mjs')]:
    (W/'candidate'/rel).write_bytes((W/src).read_bytes())
patch=[]
for rel,pins in files.items():
    before=W/'base'/rel;after=W/'candidate'/rel
    assert (sha(before) if before.exists() else None)==pins['baseSha256']
    pins['candidateSha256']=sha(after)
    old=before.read_text(encoding='utf-8').splitlines(keepends=True) if before.exists() else []
    new=after.read_text(encoding='utf-8').splitlines(keepends=True)
    patch.extend(difflib.unified_diff(old,new,fromfile='a/'+rel if before.exists() else '/dev/null',tofile='b/'+rel))
(W/'CHANGES.patch').write_text(''.join(patch),encoding='utf-8',newline='\n')
(W/'CAS-FILES.json').write_text(json.dumps(files,indent=2)+'\n',encoding='utf-8')
record={'timestampUtc':datetime.now(timezone.utc).isoformat(),'status':'CANDIDATE_PENDING_ROOT_MERGE_AND_CUA','files':files,'patchSha256':sha(W/'CHANGES.patch'),'readme':'Native/UI original bases are preserved byte-for-byte; root media changes occurred after these bases and must be retained with minimal hunks. Do not replace whole shared files. New two resources are exact standalone copies. No S/N writes.'}
(W/'PACKAGE.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'status':record['status'],'files':len(files),'patchSha256':record['patchSha256']}))
