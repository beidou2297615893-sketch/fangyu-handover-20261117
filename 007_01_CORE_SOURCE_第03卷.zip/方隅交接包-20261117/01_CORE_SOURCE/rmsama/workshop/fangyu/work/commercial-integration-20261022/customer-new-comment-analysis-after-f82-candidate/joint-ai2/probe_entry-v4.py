"""Relocatable standard Windows entry over the unchanged fixed r57 host.

This independently installed application initializes only its own empty data
directory. It grants no enterprise/device/platform permissions. Existing local
production binding and sessions are never consulted or copied.
"""
from pathlib import Path, PurePosixPath
import argparse, hashlib, http.client, importlib.util, importlib.machinery, json, os, socket, stat, sys
import threading
import time, uuid
sys.dont_write_bytecode = True
RELEASE_ID = 'ui-r57-20261023T095243Z-1c9a271f'
RELEASE_SHA = '9478f5a203756167b6db40a901c83d28c7ea6be03f7a05728a76b6108d3db01f'
CLOSURE_SHA = 'd6b26491a39dc636376ec0e6b297bb4e58ac94242d5fe0eadc05e03f6f48f1ee'

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def exact(path, expected):
    for item in (path, *path.parents):
        info = item.lstat()
        if item.is_symlink() or getattr(info, 'st_file_attributes', 0) & 1024:
            raise RuntimeError('程序路径不能包含链接或重定向')
    before = path.stat()
    if not stat.S_ISREG(before.st_mode) or before.st_nlink != 1:
        raise RuntimeError('程序文件类型无效')
    raw = path.read_bytes()
    after = path.stat()
    if (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns) != (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns) or sha(raw) != expected:
        raise RuntimeError('程序文件校验失败')
    return raw

def output(value, path=None):
    raw = json.dumps(value, ensure_ascii=False, indent=2) + '\n'
    if path:
        with Path(path).open('x', encoding='utf-8') as stream:
            stream.write(raw)
    elif sys.stdout is not None:
        print(raw)

def load_host(root):
    project = root / 'project'
    closure = json.loads(exact(project / 'SHIPPED-PINS.json', CLOSURE_SHA))
    names = set()
    for row in closure['files']:
        relative = PurePosixPath(row['path'])
        if relative.is_absolute() or '..' in relative.parts or ':' in str(relative) or ('\\' in str(relative)) or (str(relative) in names):
            raise RuntimeError('程序清单路径无效')
        names.add(str(relative))
        raw = exact(project / relative, row['sha256'])
        if len(raw) != row['bytes']:
            raise RuntimeError('程序文件长度不匹配')
    actual = set()
    for path in project.rglob('*'):
        info = path.lstat()
        if path.is_symlink() or getattr(info, 'st_file_attributes', 0) & 1024:
            raise RuntimeError('程序目录包含未允许的链接或重定向')
        if '__pycache__' in path.relative_to(project).parts or path.suffix.lower() in ('.pyc', '.pyo'):
            raise RuntimeError('程序目录包含未允许的 Python 缓存代码')
        if path.is_file():
            actual.add(path.relative_to(project).as_posix())
    if actual != names | {'SHIPPED-PINS.json'}:
        raise RuntimeError('程序实际文件集合与完整清单不一致')
    code_pins = {row['path']: row for row in closure['files']}
    original_get_code = importlib.machinery.SourceFileLoader.get_code

    def source_only(loader, fullname):
        path = Path(loader.path).absolute()
        if path.is_relative_to(project):
            relative = path.relative_to(project).as_posix()
            row = code_pins.get(relative)
            if row is None or path.suffix.lower() != '.py':
                raise ImportError('未允许的程序代码来源')
            raw = exact(path, row['sha256'])
            return compile(raw, str(path), 'exec', dont_inherit=True, optimize=0)
        return original_get_code(loader, fullname)
    importlib.machinery.SourceFileLoader.get_code = source_only

    def code_audit(event, args):
        if event == 'open' and isinstance(args[0], (str, bytes, os.PathLike)):
            path = Path(os.fsdecode(args[0])).absolute()
            if path.is_relative_to(project) and path.suffix.lower() in ('.pyc', '.pyo'):
                raise PermissionError('程序不接受缓存字节码')
        if event == 'import' and len(args) > 1 and isinstance(args[1], str):
            path = Path(args[1]).absolute()
            if path.is_relative_to(project) and path.suffix.lower() in ('.pyd', '.dll', '.pyc', '.pyo'):
                row = code_pins.get(path.relative_to(project).as_posix())
                if row is None or path.suffix.lower() in ('.pyc', '.pyo'):
                    raise ImportError('未允许的扩展程序来源')
                exact(path, row['sha256'])
    sys.addaudithook(code_audit)
    release = project / 'work/ui-native-r57/releases' / RELEASE_ID
    raw = exact(release / 'RELEASE.json', RELEASE_SHA)
    manifest = json.loads(raw)
    entry = next((row for row in manifest['files'] if row['path'] == 'ui_native_host.py'))
    module = importlib.util.module_from_spec(importlib.util.spec_from_loader('fangyu_standard_native_host', loader=None))
    module.__file__ = str(release / 'ui_native_host.py')
    sys.modules[module.__name__] = module
    exec(compile(exact(release / 'ui_native_host.py', entry['sha256'].lower()), module.__file__, 'exec'), module.__dict__)
    return (module, project, release, closure)

def short_native_icon(release, state):
    """Keep .NET's legacy Icon file constructor below its path length limit."""
    manifest = json.loads(exact(release / 'RELEASE.json', RELEASE_SHA))
    row = next((item for item in manifest['files'] if item['path'] == 'resources/brand.ico'), None)
    if row is None:
        return
    source = release / 'resources/brand.ico'
    raw = exact(source, row['sha256'].lower())
    target = state / 'window.ico'
    if target.exists():
        exact(target, sha(raw))
    else:
        with target.open('xb') as stream:
            stream.write(raw)
        exact(target, sha(raw))
    if len(str(target)) >= 248:
        raise RuntimeError('Windows 用户资料路径过长，请使用标准用户资料目录')
    import webview
    original = webview.start

    def start(*args, **kwargs):
        if kwargs.get('icon') == str(source):
            kwargs['icon'] = str(target)
        return original(*args, **kwargs)
    webview.start = start

def own_directories():
    local = os.environ.get('LOCALAPPDATA')
    if not local or not Path(local).is_absolute():
        raise RuntimeError('Windows 用户资料目录不可用')
    root = Path(local) / 'FangyuWorkbenchStandard'
    for folder in (root, root / 'data', root / 'state'):
        folder.mkdir(parents=True, exist_ok=True)
        for item in (folder, *folder.parents):
            if item.is_symlink() or getattr(item.lstat(), 'st_file_attributes', 0) & 1024:
                raise RuntimeError('工作资料目录不能重定向')
    return (root / 'data', root / 'state')

def main():
    root = Path(sys.executable).resolve().parent if getattr(sys, 'frozen', False) else Path(__file__).resolve().parent
    parser = argparse.ArgumentParser(description='方隅工作台')
    group = parser.add_mutually_exclusive_group()
    group.add_argument('--check', action='store_true')
    group.add_argument('--self-test', action='store_true')
    parser.add_argument('--result-file')
    args = parser.parse_args()
    host, project, release, closure = load_host(root)
    data, state = own_directories()
    if args.check or args.self_test:
        argv = ['--check'] if args.check else ['--self-test']
        code = host.main(release, RELEASE_SHA, state, argv, project_root=project, data_dir=data)
        if code:
            raise RuntimeError('启动检查未通过')
        output({'status': 'PASS', 'releaseId': RELEASE_ID, 'frozen': getattr(sys, 'frozen', False) is True, 'internalStandardCandidate': True, 'commercialDistributionApproved': False, 'action': argv[0], 'closureFilesVerified': len(closure['files'])}, args.result_file)
        return 0
    short_native_icon(release, state)
    return host.main(release, RELEASE_SHA, state, [], project_root=project, data_dir=data)

if hasattr(sys.stdout,'reconfigure'):sys.stdout.reconfigure(encoding='utf-8')
"""Own cloud responses only; no browser, platform, model or arbitrary process."""
import traceback
from copy import deepcopy
from types import SimpleNamespace
import uuid,subprocess,shlex

actual_compiled = getattr(sys, 'frozen', False) is True
if actual_compiled:
    W = Path(sys.executable).resolve().parent
else:
    W = Path(__file__).resolve().parent / 'payload'
    sys.frozen = True
    sys.executable = str(W / 'FangyuWorkbench.exe')
P = W/'project'
OUT = W/('factory-'+uuid.uuid4().hex); OUT.mkdir()
events, checks, processes, threads = [], [], [], []
backend = server = None
admission_checks=[]
tamper = [False]
save = lambda name,value:(OUT/name).write_text(json.dumps(value,ensure_ascii=False,indent=2,default=str),'utf-8')
def audit(event,args):
    if event=='subprocess.Popen':
        argv=args[1];argv=[part.strip('"') for part in shlex.split(argv,posix=False)] if isinstance(argv,str) else argv
        br=P/'work/ui-runtime-r55/work/runtime/douyin-bridge'
        assert Path(argv[0]).resolve()==br/'node.exe',argv
        assert Path(argv[1]).resolve() in (br/'cli.js',W/'qa-fixtures/search_bridge_fixture.cjs'),argv
        assert Path(args[2]).resolve().is_relative_to(OUT) or (Path(argv[1]).resolve()==br/'cli.js' and argv[2]=='connections' and Path(args[2]).resolve()==br),args
        if Path(argv[1]).resolve()==br/'cli.js' and argv[2] in ('search','comment-page'):
            from core import adapters as adapter_module
            account_root=Path(args[2]).resolve()
            mode=core.account_mode_status(account_root.name,user['tenant_id'])
            assert mode['mode']=='collection' and mode['status']=='active' and mode['owner'].startswith('batch:')
            assert account_root in getattr(adapter_module._account_lock_owner,'paths',set())
            channel=core.adapters.channel_locks.get('douyin:'+str(account_root.parent));assert channel and channel.locked(),'Original shared Douyin Bridge channel not held'
            foreign=type(core.continuous.leases)(core.store,'foreign-search-synthetic-runtime')
            try:foreign.acquire(account_root.name,user['tenant_id'],'replies','foreign-reply')
            except ValueError:pass
            else:raise AssertionError('Original atomic collection lease bypassed')
            admission_checks.append({'command':argv[2],'originalBatchLease':True,'originalOsAndChannelLocks':True,'foreignReplyRejected':True})
        processes.append(list(argv))
    if event in ('os.system','os.startfile','os.posix_spawn'):
        raise RuntimeError('No platform/browser process')
    if event in ('socket.connect','socket.bind') and (not isinstance(args[1],tuple) or args[1][0] not in ('127.0.0.1','::1')):
        raise RuntimeError('Loopback only')
    if event=='socket.getaddrinfo' and args[0] not in ('127.0.0.1','::1','localhost',None):
        raise RuntimeError('No external DNS')
    if event=='sqlite3.connect' and not Path(args[0]).resolve().is_relative_to(OUT):
        raise RuntimeError('Own DB only')
    if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):
        path=Path(os.fsdecode(args[0])).absolute();mode,flags=args[1] or '',args[2] or 0
        writing=any(c in str(mode) for c in 'wax+') or isinstance(flags,int) and flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC)
        if writing and not path.is_relative_to(OUT) and not (tamper[0] and path.is_relative_to(P)):
            raise RuntimeError('Own evidence/data or explicit own-copy tamper only')
sys.addaudithook(audit)

def load(name,path):
    module=importlib.util.module_from_spec(importlib.util.spec_from_loader(name,loader=None));module.__file__=str(path)
    sys.modules[name]=module;exec(compile(path.read_bytes(),str(path),'exec'),module.__dict__);return module

def denied(call, code=None):
    try:call()
    except Exception as error:
        if code is not None:assert str(error)==code,(str(error),code)
        return type(error).__name__+': '+str(error)
    raise AssertionError('Expected original guard rejection')

def binding_denied():
    return denied(lambda:connection._binding(runtime.service))

passed=False
try:
    host,project,release,closure=load_host(W)
    manifest,files=host.verify_release(release,RELEASE_SHA)
    host.verify_backend_dependencies(release,files,project)
    fixture=load('customer_read_own_cloud',W/'qa-fixtures/cloud_fixture.py')
    cloud=fixture.CloudStandin(json.loads((W/'qa-fixtures/compiled-fixture.json').read_bytes()))
    company=json.loads((project/'work/app/company.json').read_bytes())
    provider_calls=[];profile_calls=[]
    profile={'revision':1,'enabled':True,'configured':True,'provider':'deepseek','model':'deepseek-flash','rules_version':'owned-analysis-rules-v1'}
    def transport(*args,**kwargs):
        url=args[0] if args else kwargs['url'];data=args[1] if len(args)>1 else kwargs['data'];token=args[2] if len(args)>2 else kwargs.get('token','')
        operation=data['operation']
        if operation in ('ai_profile','intent_analyze'):
            value=cloud(url,{'operation':'me'},token)
            if operation=='ai_profile':
                profile_calls.append(operation);value['config']=deepcopy(profile)
            else:
                assert data['request_id'] and data['submission_id'] and data['expected_revision']==profile['revision']
                assert data['expected_rules_version']==profile['rules_version']
                assert data['city']=='上海' and data['post']['title'] and data['comments']
                provider_calls.append({'operation':operation,'request_id':data['request_id'],'aliases':[r['id'] for r in data['comments']]})
                value.update(rules_version=profile['rules_version'],provider='deepseek',model='deepseek-flash',results=[{
                    'id':row['id'],'status':'graded','level':'high','reason':'合成测试：本人明确求租公寓并提供预算和租期。',
                    'evidence':[row['text']],'region_status':'matched','content_region':'上海古北',
                    'key_info':[{'type':'budget','value':'6000','evidence':'预算6000'}]} for row in data['comments']])
        else:value=cloud(*args,**kwargs)
        value['environment_id']=company['managedWorkspace']['environment_id'];return value
    integration=load('integrations',release/'resources/platform-runtime/vendor-src/integrations.py')
    integration.request_json=transport
    backend=host.create_backend(release,files,project_root=project,data_dir=OUT/'data',company=company)
    runtime=backend.platform_runtime;core=backend.core
    runtime.server._configure_bundled();runtime._platform_setup=True
    from assistant import douyin_connection_service as connection
    from core.douyin_comments_policy import DouyinCommentsPolicy
    from core.douyin_search_policy import DouyinSearchPolicy
    assert runtime.server.company['runtime']['public_send_hold'] is True
    server=host.StaticServer(release,files,backend=backend,cookie_name='customer_read_fixture_session')
    thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start();threads.append(thread)
    origin='http://127.0.0.1:'+str(server.server_port);headers={}
    def request(method,path,payload=None):
        c=http.client.HTTPConnection('127.0.0.1',server.server_port,timeout=40)
        c.request(method,path,json.dumps(payload,ensure_ascii=False).encode() if payload is not None else None,headers)
        r=c.getresponse();raw=r.read();h=dict(r.getheaders());status=r.status;c.close()
        try:value=json.loads(raw)
        except ValueError:value={'nonJsonResponse':True}
        events.append({'method':method,'path':path,'action':payload.get('action') if payload else None,'status':status})
        return status,value,h
    _,boot,_=request('GET','/api/workbench/bootstrap')
    headers.update({'Content-Type':'application/json','Origin':origin,'X-Fangyu-CSRF':boot['csrfToken']})
    status,logged,h=request('POST','/api/workbench',{'action':'login','data':{'username':'fixture-admin','password':fixture.PASSWORD}})
    assert status==200,(status,logged)
    headers['Cookie']=h['Set-Cookie'].split(';',1)[0];headers['X-Fangyu-CSRF']=logged['csrfToken']
    user=core.session(headers['Cookie'].split('=',1)[1]);store=cloud.first_store
    # The real Service.bind, DPAPI vault, _run, Runner and DeviceSession consume
    # only owned synthetic cloud responses. No device ID/session is injected.
    device_calls=[];commands=[];outcomes={}
    cloud_port=json.loads((W.parents[1]/'ORIGINAL-CLOUD-BRIDGE.json').read_bytes())['port']
    def cloud_control(path,data=None):
        c=http.client.HTTPConnection('127.0.0.1',cloud_port,timeout=30)
        c.request('POST','/'+path,json.dumps(data or {}).encode(),{'Content-Type':'application/json'})
        r=c.getresponse();out=json.loads(r.read());c.close();assert r.status==200,out
        return out
    def actual_cloud(operation,data,token=''):
        out=cloud_control('call',{'operation':operation,'data':data,'token':token})
        if out['status']!=200:
            from assistant.transport import CloudError
            raise CloudError(out['status'],str(out.get('data',{}).get('error','own-cloud-rejected')))
        return out['data']
    class OwnDeviceCloud:
        def __init__(self,*args,**kwargs):pass
        def call(self,operation,data,credential):
            device_calls.append(operation)
            return actual_cloud(operation,data,credential)
        def close(self):pass
    from assistant.customer_read_lease import current as current_read_lease,enrollment_fields
    own_token=actual_cloud('login',{'username':'fixture-admin','password':fixture.PASSWORD})['token']
    pair=actual_cloud('pair_create',{'name':'抖音客户只读隔离电脑',**enrollment_fields(runtime.server)},own_token)
    runtime.service.cloud_factory=OwnDeviceCloud
    runtime.service.bind(pair['pair_code'])
    deadline=time.monotonic()+10
    while runtime.service.state!='online' and time.monotonic()<deadline:time.sleep(.03)
    assert runtime.service.state=='online',runtime.service.status()
    original_binding=connection._binding(runtime.service)
    assert original_binding[3]==runtime.service.device['id'] and len(original_binding[3])>=16
    deadline=time.monotonic()+25
    while not current_read_lease(runtime.server,'douyin_owned_keyword_search_page') and time.monotonic()<deadline:time.sleep(.03)
    assert current_read_lease(runtime.server,'douyin_owned_keyword_search_page')
    assert current_read_lease(runtime.server,'douyin_owned_video_comments')
    assert current_read_lease(runtime.server,'douyin_owned_connection')
    assert not core._employee_release_allowed() and not core.employee_release_device_id and core.employee_release_until_monotonic==0
    runner=runtime.service._customer_read_runner
    assert runner.accept_commands is False and runner.portable_employee_release is False
    checks.append({'group':'actual-original-cloud-login-pair-enroll-poll-and-private-readlease',
        'actualCreateService':True,'realCloudNetwork':False,'fakeDeviceSessionOrLease':False,
        'generalEmployeeGrant':False,'remoteCommands':False,'scopeDoesNotGrantSends':True})
    account={'id':'owned-customer-account','tenant_id':user['tenant_id'],'cloud_owner':user['username'],
        'store_id':store,'platform':'douyin','status':'ready','name':'隔离账号','platform_uid':'9007199254741999'}
    core.store.put('accounts',account)
    assert connection._binding(runtime.service,account['id'])[4]['id']==account['id']
    checks.append({'group':'original-cloud-bind-runner-dpapi-session-and-owned-account-admission',
        'deviceEnrollCalls':device_calls.count('device_enroll'),'pollObserved':device_calls.count('device_poll')>0,
        'originalDeviceSessionCreated':True,'actualOriginalCloudServiceLoopback':True,'nativeUiLoginTransportSynthetic':True,'nativeOrPlatformLoginClaim':False})

    # Explicit-local original page analysis is tested; no worker is replaced.
    assert getattr(runtime.service,'ai_worker',None) is None,'Explicit local original flow must own page analysis'
    br=P/'work/ui-runtime-r55/work/runtime/douyin-bridge'
    vm_process=subprocess.Popen([str(br/'node.exe'),str(W/'qa-fixtures/search_bridge_fixture.cjs'),str(br),str(OUT)],
        cwd=OUT,stdout=(OUT/'VM.stdout.log').open('wb'),stderr=(OUT/'VM.stderr.log').open('wb'),
        creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
    deadline=time.monotonic()+15
    while not (OUT/'VM-READY.json').exists() and time.monotonic()<deadline:
        assert vm_process.poll() is None,(OUT/'VM.stderr.log').read_text('utf-8');time.sleep(.03)
    ready=json.loads((OUT/'VM-READY.json').read_bytes())
    def vm_control(path,data=None):
        c=http.client.HTTPConnection('127.0.0.1',ready['port'],timeout=10)
        c.request('POST','/fixture/'+path,json.dumps(data or {}).encode(),
            {'Authorization':'Bearer '+ready['token'],'Content-Type':'application/json'})
        r=c.getresponse();raw=r.read();c.close();assert r.status==200,(r.status,raw)
        return json.loads(raw)
    config=runtime.server.bridge.root(user['tenant_id'])/'config.json';config.parent.mkdir(parents=True,exist_ok=True)
    config.write_text(json.dumps({'bridge':{'host':'127.0.0.1','port':ready['port'],'token':ready['token']},
        'riskControl':{'minInterval':0,'maxInterval':0,'maxConsecutiveFailures':3},'llm':{'enabled':False}}),'utf-8')
    _,generated_script=runtime.server.bridge.prepare(user['tenant_id'])
    runtime.server.bridge.processes[user['tenant_id']]=vm_process
    class OwnSyntheticWindow:
        def poll(self):return None
        def terminate(self):pass
        def wait(self,*a,**k):return 0
    accounts=[]
    for index,found in enumerate(ready['accounts']):
        row={**account,'id':'owned-customer-search-account-'+str(index),'conn_id':found['connId'],
            'platform_uid':found['uid'],'name':'合成已登录账号'+str(index+1)}
        core.store.put('accounts',row);accounts.append(row)
        directory=core.store.directory/'accounts'/user['tenant_id']/row['id']/'managed-window'
        directory.mkdir(parents=True,exist_ok=True);state_path=str(directory/('state-'+found['marker']+'.json'))
        spec={'platform':'douyin','name':row['name'],'marker':found['marker'],'config':str(config),
            'script':str(generated_script),'profile':str(directory/'profile'),'state_path':state_path}
        (directory/'window.json').write_text(json.dumps(spec,ensure_ascii=False),'utf-8')
        runtime.server.account_connections.owned[row['id']]={'process':OwnSyntheticWindow(),
            'marker':found['marker'],'state_path':state_path,'opened_at':time.time()}
    account=accounts[0]
    user={**user,'_workbench_store_id':store}
    chosen=accounts[0]
    selected_status,selected,_=request('POST','/api/workbench',{'action':'select_store','data':{'storeId':store}})
    assert selected_status==200,(selected_status,selected)
    status,checked,_=request('POST','/api/workbench',{'action':'account_check','data':{'accountId':chosen['id']}})
    assert status==200,(status,checked)
    assert checked['job']['status']=='ready',checked
    assert checked['job']['platformLoginConfirmed'] is True and checked['job']['bindingVerified'] is True
    fresh=core.store.get('accounts',chosen['id'])
    assert fresh['platform_uid']==ready['accounts'][0]['uid'] and fresh['platform_nickname']=='合成当前账号'
    assert runtime._connection_account(user,fresh)['status']=='ready'
    snapshot=checked['platform'];assert snapshot.get('accounts'),snapshot
    shown=next(row for row in snapshot['accounts'] if row['id']==fresh['id'])
    assert '合成当前账号' in json.dumps(shown,ensure_ascii=False),shown
    assert runtime._collection_readiness(user,fresh)==('','')
    denied(lambda:runtime._executor(user))
    checks.append({'group':'v3-actual-original-http-check-account-button-uid-nickname-and-ready-snapshot',
        'actualOriginalHttpEntry':True,'originalStatusCliAndFullUserscriptVm':True,
        'nicknameVisibleInSnapshot':True,'uidMatchesOwnedVm':True,'defaultExecutorStillClosed':True})
    def acquire(name,chosen):
        before=len(provider_calls)
        value=runtime.start_acquisition(user,{'taskName':name,'platform':'douyin',
            'accountId':chosen['id'],'keywords':['上海古北'],'dailyLimit':3,'targetCount':20,
            'time':'all','storeId':store,'intentMode':'all',
            'city':next(r['city'] for r in cloud.manifest['stores'] if r['id']==store),
            'area':next(r.get('area','') for r in cloud.manifest['stores'] if r['id']==store)})
        assert value['result']['accepted'] is True,value
        ident=value['result']['taskId'];worker=runtime._runs[ident];worker.join(180)
        assert not worker.is_alive(),'Original outer worker did not exit'
        task=core.store.get('tasks',ident)
        save('TASK-'+str(len(checks))+'.json',task)
        assert not task.get('status')=='failed' and not task.get('last_platform_error'),task
        return task,len(provider_calls)-before
    # FIRST and hardest: truly NEW original Core import, page journal, original
    # LocalAIWorkflow/LocalAIAttempts, validation/cache/CAS, public projection.
    task,provider_delta=acquire('合成新增评论并实际分析',accounts[0])
    leads=core.store.list('leads',user['tenant_id']);assert len(leads)==1,leads
    lead=leads[0];ai=lead.get('ai_intent') or {}
    assert provider_delta==1 and len(provider_calls)==1,(provider_calls,task)
    assert lead['task_id']==task['id'] and task['account_id']==accounts[0]['id']
    assert ai.get('status')=='graded' and ai.get('level')=='high' and lead['analysis_status']=='graded',lead
    assert ai.get('cache_key') and core.store.get('ai_cache',ai['cache_key'])
    attempts=core.store.list('ai_attempts',user['tenant_id']);assert len(attempts)==1 and attempts[0]['state']=='validated',attempts
    job=core.store.get('ai_jobs',task['id']);assert job and job['status']=='completed' and job['pending']==0 and job['analyzed']==1,job
    status,presented,_=request('POST','/api/workbench',{'action':'customers','data':{'platform':'douyin','page':1,'pageSize':20}})
    assert status==200,(status,presented)
    save('CUSTOMER-PRESENTATION.json',presented)
    rows=presented['customers']['items'];assert len(rows)==1,rows
    assert 'high' in json.dumps(rows[0]) and 'graded' in json.dumps(rows[0]),rows[0]
    checks.append({'group':'actually-new-owned-comment-core-import-original-ai-workflow-validation-cache-cas-and-customer-projection',
        'newComments':1,'providerRequests':provider_delta,'originalAttemptValidated':True,'originalJobCompleted':True,
        'taskAndAccountBound':True,'httpCustomerProjectionGradedHigh':True,'syntheticProviderOnly':True})
    first_bytes=core.store.get('leads',lead['id'])
    second,delta=acquire('合成重复页同账号',accounts[0]);summary=(second.get('last_result') or {}).get('summary') or {}
    assert summary.get('imported')==0 and summary.get('duplicates')==1 and delta==0,(second,delta)
    assert core.store.get('leads',lead['id'])==first_bytes and len(core.store.list('leads',user['tenant_id']))==1
    third,delta=acquire('合成相同评论换账号',accounts[1]);summary=(third.get('last_result') or {}).get('summary') or {}
    assert summary.get('imported')==0 and summary.get('duplicates')==1 and delta==0,(third,delta)
    assert core.store.get('leads',lead['id'])==first_bytes and len(provider_calls)==1
    checks.append({'group':'repeat-page-and-second-account-stable-source-dedup-no-repeat-analysis','duplicateBatches':2,'newProviderRequests':0,'originalFirstAiAndTaskBytesPreserved':True})
    # A separate genuine original import deliberately has NO task_id. Preserve
    # its original manual grade and unresolved reply while collecting its page.
    legacy={'platform':'douyin','source_type':'comment','source_id':'comment:923456789012345679',
        'comment_id':'923456789012345679','note_url':'https://www.douyin.com/video/1234567890123456789',
        'text':'上海古北求租公寓，预算6000，想住一个月','author':'合成求租客户','author_id':'9876543210123457',
        'content_title':'上海古北求租一个月公寓','content_author':'合成帖子作者'}
    assert core._import([legacy],user['tenant_id'],user)['imported']==1
    old=next(x for x in core.store.list('leads',user['tenant_id']) if x.get('comment_id')==legacy['comment_id'])
    assert 'task_id' not in old
    old.update(manual_intent={'status':'graded','level':'medium','reason':'合成原人工判断'},
        ai_intent={'status':'graded','level':'low','reason':'合成原AI判断'},reply_status='unknown',reply_state='unknown')
    core.store.put('leads',old)
    reply={'id':'own-legacy-unknown-reply','tenant_id':user['tenant_id'],'cloud_owner':user['username'],
        'lead_id':old['id'],'account_id':accounts[0]['id'],'author_id':user['id'],'status':'unknown','text':'合成原回复结果未知'}
    core.store.put('replies',reply)
    # Actual old importer dedups by comment ID, not the changing actor UID.
    for acc in accounts:vm_control('options',{'uid':acc['platform_uid'],'options':{'commentId':legacy['comment_id']}})
    fourth,delta=acquire('合成历史无任务评论去重',accounts[1]);summary=(fourth.get('last_result') or {}).get('summary') or {}
    assert summary.get('imported')==0 and summary.get('duplicates')==1 and delta==0,(fourth,delta)
    assert core.store.get('leads',old['id'])==old and 'task_id' not in core.store.get('leads',old['id'])
    assert core.store.get('replies',reply['id'])==reply and len(provider_calls)==1
    checks.append({'group':'original-taskless-history-dedup-keeps-manual-ai-unknown-reply-and-taskless-association','duplicates':1,'newProviderRequests':0,'customerAndReplyExact':True})
    # Pending data is inserted through ORIGINAL Core importer under the true
    # first task/account; no queue/AI implementation or authority is replaced.
    pending={**legacy,'source_id':'comment:923456789012345680','comment_id':'923456789012345680',
        'author_id':'9876543210123458','task_id':task['id']}
    assert core._import([pending],user['tenant_id'],user)['imported']==1
    row=next(x for x in core.store.list('leads',user['tenant_id']) if x.get('comment_id')==pending['comment_id'])
    before=(len(provider_calls),len(profile_calls),len(core.store.list('ai_attempts',user['tenant_id'])))
    cloud_control('qa-policy',{'enabled':False})
    deadline=time.monotonic()+15
    while current_read_lease(runtime.server,'douyin_owned_video_comments') and time.monotonic()<deadline:time.sleep(.03)
    assert not current_read_lease(runtime.server,'douyin_owned_video_comments')
    denied(lambda:runtime._analyze_collection_page(runtime.service.executor,user,task['id'],[row['id']]))
    assert (len(provider_calls),len(profile_calls),len(core.store.list('ai_attempts',user['tenant_id'])))==before
    assert core.store.get('leads',row['id'])==row
    checks.append({'group':'actual-cloud-read-policy-loss-rejects-pending-analysis-before-profile-provider-or-attempt','providerRequests':0,'pendingRowExact':True,'fakeLease':False})
    cloud_control('qa-policy',{'enabled':True})
    deadline=time.monotonic()+15
    while not current_read_lease(runtime.server,'douyin_owned_video_comments') and time.monotonic()<deadline:time.sleep(.03)
    assert current_read_lease(runtime.server,'douyin_owned_video_comments')
    paused=runtime.pause_acquisition(user,{'taskId':task['id']});assert paused['result']['accepted'] is True,paused
    assert core.store.get('tasks',task['id'])['status']=='paused'
    before=(len(provider_calls),len(profile_calls),len(core.store.list('ai_attempts',user['tenant_id'])))
    denied(lambda:runtime._analyze_collection_page(runtime.service.executor,user,task['id'],[row['id']]))
    assert (len(provider_calls),len(profile_calls),len(core.store.list('ai_attempts',user['tenant_id'])))==before
    assert core.store.get('leads',row['id'])==row
    checks.append({'group':'original-pause-task-blocks-model-for-owned-pending-comment','originalPauseAccepted':True,'providerRequests':0,'pendingRowExact':True})
    save('PROVIDER-CALLS.json',{'calls':provider_calls,'profileReads':len(profile_calls),'actualPaidModelRequests':0,'transport':'only own deterministic provider response at original integrations request seam'})
    save('AI-JOBS.json',core.store.list('ai_jobs',user['tenant_id']));save('AI-ATTEMPTS.json',core.store.list('ai_attempts',user['tenant_id']))
    save('COMMENT-STATES.json',core.store.list('leads',user['tenant_id']))
    passed=True
finally:
    if sys.exc_info()[0]:save('ERROR.json',{'traceback':traceback.format_exc()})
    if 'vm_control' in globals():
        try:vm_control('shutdown')
        except Exception:pass
    if server:server.shutdown();server.server_close()
    if backend:backend.close()
    if 'vm_process' in globals() and vm_process.poll() is None:vm_process.terminate();vm_process.wait(5)
    if 'cloud_control' in globals():
        try:cloud_control('shutdown')
        except Exception:pass
    for thread in threads:thread.join(3)
    save('HTTP.json',events);save('PROCESSES.json',processes);save('ADMISSION-LOCKS.json',admission_checks)
    save('RESULTS.json',{'status':'PASS' if passed else 'RED','groups':checks,'groupCount':len(checks),
        'actualCompiledExe':False,'sourceFrozenRepresentativeOnly':True,'actualNodeProcesses':len(processes),
        'realPlatformRequests':0,'realModelRequests':0,'realCloudDeployment':False,'nativeWindows':0,
        'allOwnServicesClosed':all(not t.is_alive() for t in threads) and (backend is None or getattr(runtime.service,'thread',None) is None or not runtime.service.thread.is_alive()),
        'newCommentAiFlowActuallyTested':True,'productSourcePatched':False})
    print(json.dumps({'status':'PASS' if passed else 'RED','groups':len(checks),'evidence':str(OUT)},ensure_ascii=False))
