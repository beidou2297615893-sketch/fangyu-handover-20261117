"""Own derived payload only. Preserve F82, standard held decisions and originals."""
from pathlib import Path
import ast, hashlib, json, shutil, datetime, sys

W = Path(__file__).resolve().parent
P = W.parents[2]
AUTHOR = W.parent / 'f82-standard-package-candidate'
BASE = AUTHOR / 'standard-held-clean-v82'
SOURCE = W / 'source-candidate'
B = W / (sys.argv[1] if len(sys.argv)>1 else 'compiled-probe')
PROJECT = B / 'payload/project'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
read = lambda p: json.loads(p.read_bytes())
def save(p, value):
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', 'utf-8')

if PROJECT.exists(): raise RuntimeError('Keep prior probe evidence; do not overwrite')
B.mkdir(exist_ok=True)
assert sha(AUTHOR/'FINAL-RECEIPT.json') == '69d0b8946a3da256e4101cd3842c7fa8eb294843796518caaa63faffc83a377b'
shutil.copytree(BASE/'payload/project', PROJECT)
rid = read(BASE/'STAGE.json')['releaseId']
R = PROJECT/'work/ui-native-r57/releases'/rid
for source in SOURCE.rglob('*.py'):
    rel = source.relative_to(SOURCE); target = PROJECT/rel
    target.parent.mkdir(parents=True, exist_ok=True); shutil.copy2(source,target)
for source, dest in [
    ('work/ui-native-r57/ui_native_host.py','ui_native_host.py'),
    ('work/shared-backend-integration/platform_runtime.py','resources/platform-runtime/platform_runtime.py'),
    ('work/shared-backend-integration/customer_read_distribution.py','resources/platform-runtime/customer_read_distribution.py'),
    ('work/shared-backend-integration/vendor-src/app.py','resources/platform-runtime/vendor-src/app.py'),
    ('work/shared-backend-integration/vendor-src/assistant/douyin_connection_service.py','resources/platform-runtime/vendor-src/assistant/douyin_connection_service.py')]:
    shutil.copy2(SOURCE/source, R/dest)

# SOURCE mirrors continue to describe actual bytes; this adds no permissions.
for root in (PROJECT/'work/shared-backend-integration/vendor-src',R/'resources/platform-runtime/vendor-src'):
    doc=read(root/'SOURCE.json')
    for name,row in doc['files'].items():
        if (root/name).is_file(): row['candidate_sha256']=sha(root/name)
    save(root/'SOURCE.json',doc)
deps=read(R/'resources/backend-dependencies.json')
for row in deps['files']:
    path=PROJECT/'work/ui-runtime-r55/src'/row['path']
    row.update(size=path.stat().st_size,sha256=sha(path).upper())
save(R/'resources/backend-dependencies.json',deps)

# Mature held loader compatibility re-derived with the SAME false decisions.
# Inner code manifest excludes its generated guard and native manifest, as before.
guard=R/'resources/platform-runtime/vendor-src/assistant/employee_distribution.py'
contract=read(PROJECT/'HELD-STANDARD-MANIFEST.json')
excluded={guard.relative_to(PROJECT).as_posix(),(R/'RELEASE.json').relative_to(PROJECT).as_posix()}
code=[]
for path in sorted(PROJECT.rglob('*')):
    if path.is_file() and path.relative_to(PROJECT).as_posix() not in excluded and path.suffix.lower() in ('.py','.js','.mjs','.exe','.dll','.pyd'):
        code.append({'path':path.relative_to(PROJECT).as_posix(),'bytes':path.stat().st_size,'sha256':sha(path)})
contract['codeFiles']=code;contract['codeFileCount']=len(code)
assert contract['channel']=='internal_standard_candidate' and contract['commercialDistributionApproved'] is False and contract['platformExecutionApproved'] is False
save(PROJECT/'HELD-STANDARD-MANIFEST.json',contract)
original=P/'work/parallel-integration-20261018/final-integration/candidate-unified-v82/project/work/shared-backend-integration/vendor-src/assistant/employee_distribution.py'
body=original.read_text('utf-8').replace('\r\n','\n')
needle='def runtime_config_valid(config):\n';assert body.count(needle)==1
body=body.replace(needle,needle+'    if held_standard_config_valid(config):\n        return True\n')
body+=(AUTHOR/'held_standard_contract.py.in').read_text('utf-8').replace('@@MANIFEST_SHA@@',repr(sha(PROJECT/'HELD-STANDARD-MANIFEST.json')))
ast.parse(body);guard.write_text(body,'utf-8')

source=PROJECT/'work/ui-runtime-r55/src';runtime=source.parent/'work/runtime/douyin-bridge'
vendor=R/'resources/platform-runtime/vendor-src'
roots={'source':source,'vendor':vendor,'douyin_runtime':runtime,'release':R}
company=read(PROJECT/'work/app/company.json');runtime_config=company['runtime'];managed=company['managedWorkspace']
binding={key:company.get(key) for key in ('id','edition','personalMode','authMode','releaseVersion','platforms')}|{
    'environment_id':managed['environment_id'],'endpoint':managed['endpoint'],
    'role':runtime_config['role'],'ui_entry':runtime_config['ui_entry'],'public_send_hold':True,
    'executable':runtime_config['executable'],'cli_source_sha256':runtime_config['cli_source_sha256'],
    'xiaohongshu_automation':runtime_config['xiaohongshu_automation']}
evidence={'schema':'customer_read_license_source_evidence_v1',
    'reviewer_ref':'Codex bounded independent source and original license review',
    'prior_readiness_final_sha256':'d99c908febf0a388e57d6b9537680f063d008126d96bb210973f6b04fe463a02',
    'source_materials':'Actual fixed candidate code; each purpose hashes exact active/canonical runtime bytes.',
    'license_basis':'Actual Bridge LICENSE retains Yht20927 MIT; copyright and permission notice retained.',
    'license_url':'https://github.com/Yht20927/douyin-cli/blob/main/LICENSE',
    'unverified':['actual Native loaded browser process','platform authorization and login/read','second ordinary PC'],
    'send_grant':False,'not_account_or_device_enrollment':True,
    'source_function_guards_preserved':['original _binding','DeviceSession','tenant/account/store','stop/lifecycle','Bridge/Router','Core access','fixed command'],
    'engineering_runtime_verification':'Pending representative own compiled factory; not asserted in this material review.'}
save(R/'resources/customer-read/distribution-evidence.json',evidence)
index={'schema':'fangyu_customer_read_material_index_v1','scope':'customer_distribution_read',
    'company_binding':binding,'executable':runtime_config['executable'],'reviews':[]}
for purpose, original_review in [('douyin_owned_connection',vendor/'douyin-connection-review.json'),
        ('douyin_owned_video_comments',source/'resources/douyin-owned-comments/review.json')]:
    old=read(original_review);materials={}
    def add(root,path,role):
        f=roots[root]/path
        materials[(root,path)]={'root':root,'path':path,'bytes':f.stat().st_size,'sha256':sha(f),'role':role}
    for row in old['materials']:
        add(row['root'],row['path'],'source' if row['role']=='source' else 'dependency')
    # Bind every actually shadowed Python source in addition to canonical material.
    for path in sorted(vendor.rglob('*.py')): add('vendor',path.relative_to(vendor).as_posix(),'source')
    for path in ('ui_native_host.py','resources/platform-runtime/platform_runtime.py','resources/platform-runtime/customer_read_distribution.py'):
        add('release',path,'source')
    for path in ('core/douyin_comments_policy.py','core/runtime_license_policy.py'): add('source',path,'source')
    add('douyin_runtime','LICENSE','license')
    add('release','resources/customer-read/distribution-evidence.json','review_evidence')
    limits=old.get('material_limits',old.get('limits'))
    review={'schema':'fangyu_customer_read_purpose_review_v1','scope':'customer_distribution_read',
        'purpose':purpose,'company_binding':binding,'limits':limits,'materials':list(materials.values()),
        'distribution_basis':{'reviewer_ref':evidence['reviewer_ref'],
            'reviewed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'license':'MIT',
            'license_material':{'root':'douyin_runtime','path':'LICENSE'},
            'permission':'scoped_customer_read_only',
            'evidence_material':{'root':'release','path':'resources/customer-read/distribution-evidence.json'}},
        'evidence':{'review_layer':'license_and_source','real_platform_verified':False,
            'native_loaded_bytes_verified':False,'public_send_grant':False}}
    path='resources/customer-read/'+purpose+'.json';save(R/path,review)
    index['reviews'].append({'purpose':purpose,'path':path,'bytes':(R/path).stat().st_size,'sha256':sha(R/path)})
save(R/'resources/customer-read/review-index.json',index)

# Package-derived review files are examples for THIS exact runtime layout.
# Root must regenerate against its final merged source and company version.
for path in sorted((R/'resources/customer-read').glob('*.json')):
    save(SOURCE/'work/shared-backend-integration/customer-read'/path.name,read(path))
release=read(R/'RELEASE.json')
release['files']=[{'path':path.relative_to(R).as_posix(),'size':path.stat().st_size,'sha256':sha(path).upper()}
    for path in sorted(R.rglob('*')) if path.is_file() and path.name!='RELEASE.json']
save(R/'RELEASE.json',release)
closure=read(PROJECT/'SHIPPED-PINS.json')
closure['files']=[{'path':path.relative_to(PROJECT).as_posix(),'bytes':path.stat().st_size,'sha256':sha(path)}
    for path in sorted(PROJECT.rglob('*')) if path.is_file() and path.name!='SHIPPED-PINS.json']
save(PROJECT/'SHIPPED-PINS.json',closure)
entry=(AUTHOR/'standard_entry.py.in').read_text('utf-8')
for key,val in [('RELEASE_ID',rid),('RELEASE_SHA',sha(R/'RELEASE.json')),('CLOSURE_SHA',sha(PROJECT/'SHIPPED-PINS.json'))]:
    entry=entry.replace('@@'+key+'@@',repr(val))
tree=ast.parse(entry);tree.body=tree.body[:-1];entry=ast.unparse(tree)+'\n'
(B/'standard_loader_prefix.py').write_text(entry,'utf-8')
save(B/'PROBE-INPUTS.json',{'release_id':rid,'release_sha256':sha(R/'RELEASE.json'),
    'closure_sha256':sha(PROJECT/'SHIPPED-PINS.json'),'purpose_index_sha256':sha(R/'resources/customer-read/review-index.json'),
    'source_files':len(list(SOURCE.rglob('*.py'))),'sourceWritesOutsideOwnDirectory':False,
    'heldManifestFalseDecisionsUnchanged':True,'platformRequests':0})
print(json.dumps({'ownProject':str(PROJECT),'ownRelease':str(R),'purposeMaterials':[len(read(R/item['path'])['materials']) for item in index['reviews']],'closureFiles':len(closure['files'])},ensure_ascii=False))
