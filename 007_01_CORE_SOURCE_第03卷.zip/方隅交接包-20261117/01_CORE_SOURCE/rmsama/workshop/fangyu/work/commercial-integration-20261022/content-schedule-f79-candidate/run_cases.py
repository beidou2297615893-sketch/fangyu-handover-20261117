from pathlib import Path
import json,os,subprocess,sys
W=Path(__file__).resolve().parent;label=sys.argv[1];cases=sys.argv[2:];rows=[]
try:
 for case in cases:
  before=set(W.glob('factory-'+case+'-*'))
  with (W/('factory-'+case+'.log')).open('xb') as log:
   r=subprocess.run([sys.executable,'-B',str(W/'test_factory_schedule.py'),case],cwd=W,env={**os.environ,'PYTHONIOENCODING':'utf-8','PYTHONDONTWRITEBYTECODE':'1'},stdout=log,stderr=subprocess.STDOUT,timeout=300)
  added=set(W.glob('factory-'+case+'-*'))-before;assert len(added)==1;out=added.pop();row={'case':case,'exitCode':r.returncode,'directory':str(out)};rows.append(row)
  if r.returncode:print((W/('factory-'+case+'.log')).read_text('utf-8',errors='replace')[-5000:]);raise RuntimeError(case+' RED')
  print('PASS '+case,flush=True)
finally:(W/('CASE-RUNS-'+label+'.json')).write_text(json.dumps({'rows':rows,'allPassed':len(rows)==len(cases) and all(r['exitCode']==0 for r in rows),'realPlatformModelCalls':0},ensure_ascii=False,indent=2)+'\n','utf-8')
