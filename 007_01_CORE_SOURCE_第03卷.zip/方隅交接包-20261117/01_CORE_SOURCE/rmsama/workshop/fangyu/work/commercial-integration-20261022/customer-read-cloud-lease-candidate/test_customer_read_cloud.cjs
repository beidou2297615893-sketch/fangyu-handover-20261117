'use strict';
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const crypto=require('node:crypto');
const D=__dirname,ROOT=path.join(D,'cloud-candidate-final');
const {createService}=require(path.join(ROOT,'service.cjs'));
const {releaseState}=require(path.join(ROOT,'release.cjs'));
const policy=require(path.join(ROOT,'customer_read_release.cjs'));
const oldFactory=require('../content-cloud-v3-final2/candidate/service.cjs').createService;
const ENV='customer-read-own-memory-fixture',COMPANY=policy.COMPANY;
const PW='Own-Synthetic-Password-2026';
const req={version:policy.VERSION,customer_read_protocol:policy.PROTOCOL};
const checks=[],artifacts={};let calls=0;
function fixture(extra={},initial=null,factory=createService){
 let state=structuredClone(initial),now=1792756800000;
 const store={transaction:async callback=>{const out=await callback(structuredClone(state));state=out.state;return out.result;}};
 const service=factory({store,environmentId:ENV,companyId:COMPANY,initialAdmin:'fixture-root',initialPassword:PW,
   clock:()=>now,releaseApproved:false,customerReadReleaseEnabled:true,customerReadReleaseVersion:policy.VERSION,...extra});
 return {call:async(operation,data={},token='')=>{calls++;return service({environment_id:ENV,operation,...data},token);},
  snapshot:()=>structuredClone(state),advance:ms=>{now+=ms;}};
}
async function login(f,name='fixture-root'){const out=await f.call('login',{username:name,password:PW});assert.equal(out.status,200);return out.data.token;}
async function enroll(f,user,fields=req){
 const pair=await f.call('pair_create',{name:'自有合成电脑',...fields},user);assert.equal(pair.status,200);
 const token=crypto.randomBytes(32).toString('base64url');
 const enrolled=await f.call('device_enroll',{device_token:token,...fields},pair.data.pair_code);assert.equal(enrolled.status,200);
 return {token,id:enrolled.data.device.id,pairCode:pair.data.pair_code};
}
function grant(out,device){assert.equal(out.status,200);assert.deepEqual(out.data.customer_read_release,{
 schema:policy.SCHEMA,allowed:true,company_id:COMPANY,device_id:device.id,version:policy.VERSION,
 scope:'customer_distribution_read',platforms:[...policy.PLATFORMS],capabilities:[...policy.CAPABILITIES],
 lease_seconds:45,public_send_allowed:false,reason:'ALLOWED'});assert.equal(out.data.safety_hold,false);
 assert.equal(out.data.employee_release.allowed,false);assert.equal(out.data.platform_qa_device_id,'');assert.equal(out.data.command,null);}
async function check(name,fn){await fn();checks.push({name,status:'PASS'});}
async function main(){
 await check('default closed release configuration and exact company/version flags',async()=>{
  for(const env of [{},{COMPANY_ID:COMPANY},{COMPANY_ID:COMPANY,FANGYU_CUSTOMER_READ_RELEASE_ENABLED:true,FANGYU_CUSTOMER_READ_RELEASE_VERSION:policy.VERSION},
   {COMPANY_ID:'other',FANGYU_CUSTOMER_READ_RELEASE_ENABLED:'1',FANGYU_CUSTOMER_READ_RELEASE_VERSION:policy.VERSION},
   {COMPANY_ID:COMPANY,FANGYU_CUSTOMER_READ_RELEASE_ENABLED:'1',FANGYU_CUSTOMER_READ_RELEASE_VERSION:'1.1.8-pilot.1'}])assert.equal(releaseState(env).customerReadReleaseEnabled,false);
  const r=releaseState({COMPANY_ID:COMPANY,FANGYU_CUSTOMER_READ_RELEASE_ENABLED:'1',FANGYU_CUSTOMER_READ_RELEASE_VERSION:policy.VERSION});
  assert.equal(r.customerReadReleaseEnabled,true);assert.equal(r.active,false);assert.equal(r.version,'');assert.equal(r.employeeReleaseEnabled,false);
 });
 const f=fixture(),admin=await login(f),device=await enroll(f,admin);
 await check('real login pairing one-time enrollment and authenticated fresh poll on new admin device',async()=>{
  const out=await f.call('device_poll',req,device.token);grant(out,device);
  artifacts.allowedHeartbeat=out.data;
  const duplicate=await f.call('device_enroll',{...req,device_token:crypto.randomBytes(32).toString('base64url')},device.pairCode);
  assert.equal(duplicate.status,409);
  assert.notEqual(device.id,'development-fixed-id');
 });
 await check('operator real account and pairing use same limited lease without developer identity',async()=>{
  assert.equal((await f.call('member_save',{username:'fixture-operator',password:PW,role:'operator'},admin)).status,200);
  const user=await login(f,'fixture-operator'),other=await enroll(f,user);grant(await f.call('device_poll',req,other.token),other);
  assert.equal((await f.call('device_poll',req,admin)).status,401);
 });
 await check('metadata alone does not enroll; bad or missing protocol and version close heartbeat',async()=>{
  assert.equal((await f.call('device_enroll',{device_token:device.token,...req},'invented-pair-code')).status,401);
  const bads=[{}, {version:policy.VERSION}, {...req,customer_read_protocol:'wrong'}, {...req,version:'1.1.8-pilot.1'},
   {...req,version:true}, {customer_read_protocol:policy.PROTOCOL}];
  for(const fields of bads){const out=await f.call('device_poll',fields,device.token);assert.equal(out.status,200);assert.equal(out.data.safety_hold,true);
   if(Object.hasOwn(fields,'customer_read_protocol')){assert.equal(out.data.customer_read_release.allowed,false);assert.equal(out.data.customer_read_release.lease_seconds,0);}
   else assert.equal(Object.hasOwn(out.data,'customer_read_release'),false);}
  grant(await f.call('device_poll',req,device.token),device);
 });
 await check('new lease never grants remote task or public message operations',async()=>{
  for(const [action,data] of [['task_run',{task_id:'own-task',max_batches:1}],['reply_send',{reply_id:'own-reply',account_id:'own-account',authorized:true}],['reply_queue_send',{queue_id:'own-queue',authorized:true}]]){
   const out=await f.call('command_submit',{device_id:device.id,request_id:crypto.randomBytes(18).toString('base64url'),action,data},admin);assert.equal(out.status,423);}
  assert.equal(f.snapshot().commands.length,0);grant(await f.call('device_poll',req,device.token),device);
 });
 await check('cloud policy disabled or wrong configured version stops grant and enrollment',async()=>{
  for(const opts of [{customerReadReleaseEnabled:false},{customerReadReleaseEnabled:'1'},{customerReadReleaseVersion:'1.1.8-pilot.1'}]){
   const off=fixture(opts,f.snapshot());const poll=await off.call('device_poll',req,device.token);
   assert.equal(poll.data.customer_read_release.allowed,false);assert.equal(poll.data.customer_read_release.reason,'POLICY_DISABLED');assert.equal(poll.data.safety_hold,true);
   assert.equal((await off.call('pair_create',{...req,name:'拒绝电脑'},admin)).status,423);}
 });
 await check('revocation and owner disable invalidate actual authenticated device',async()=>{
  const revoked=fixture({},f.snapshot());assert.equal((await revoked.call('device_revoke',{device_id:device.id},admin)).status,200);
  assert.equal((await revoked.call('device_poll',req,device.token)).status,401);
  const disabled=fixture({},f.snapshot());assert.equal((await disabled.call('member_save',{username:'fixture-operator',role:'operator',disabled:true},admin)).status,200);
  const snapshot=disabled.snapshot(),operatorDevice=snapshot.devices.find(d=>d.owner==='fixture-operator');
  assert.equal(policy.leaseForDevice({companyId:COMPANY,enabled:true,version:policy.VERSION,requestVersion:policy.VERSION,protocol:policy.PROTOCOL,
   device:operatorDevice,owner:snapshot.users.find(u=>u.username==='fixture-operator'),now:1792756800}).allowed,false);
 });
 await check('company storage isolation and token substitution fail in original service',async()=>{
  const foreign=fixture({companyId:'other-company'},f.snapshot());assert.equal((await foreign.call('device_poll',req,device.token)).status,403);
  assert.equal((await f.call('device_poll',req,'invented-device-token')).status,401);
  assert.equal((await f.call('device_poll',{...req,environment_id:'foreign-env'},device.token)).status,400);
 });
 await check('lease policy exact numeric freshness, roles, company, version, and protocol deny',async()=>{
  const state=f.snapshot(),d=state.devices.find(d=>d.id===device.id),owner=state.users.find(u=>u.username===d.owner);
  const valid={companyId:COMPANY,enabled:true,version:policy.VERSION,requestVersion:policy.VERSION,protocol:policy.PROTOCOL,device:d,owner,now:1792756800};
  assert.equal(policy.leaseForDevice(valid).allowed,true);
  for(const patch of [{now:1792756891},{now:true},{device:{...d,last_seen:true}},{device:{...d,last_seen:1792756801}},
   {owner:{...owner,role:'viewer'}},{owner:{...owner,username:'different'}},{companyId:'foreign'},{requestVersion:''},
   {device:{...d,version:'1.1.8-pilot.1'}},{device:{...d,revoked:true}},{protocol:true}]){
   const out=policy.leaseForDevice({...valid,...patch});assert.equal(out.allowed,false);assert.equal(out.public_send_allowed,false);assert.deepEqual(out.capabilities,[]);assert.equal(out.lease_seconds,0);}
 });
 await check('legacy pilot employee heartbeat is byte-equivalent with customer feature on or off',async()=>{
  const opts={employeeReleaseEnabled:true,employeeReleaseVersion:'1.1.8-pilot.1'};
  const old=fixture(opts,null,oldFactory),a=await login(old);
  assert.equal((await old.call('member_save',{username:'legacy-operator',password:PW,role:'operator'},a)).status,200);
  const u=await login(old,'legacy-operator'),d=await enroll(old,u,{version:'1.1.8-pilot.1'}),snapshot=old.snapshot();
  const original=fixture(opts,snapshot,oldFactory),current=fixture(opts,snapshot),off=fixture({...opts,customerReadReleaseEnabled:false},snapshot);
  const payload={version:'1.1.8-pilot.1'},expected=await original.call('device_poll',payload,d.token);
  assert.equal(expected.data.employee_release.allowed,true);assert.equal(Object.hasOwn(expected.data,'customer_read_release'),false);
  assert.deepEqual(await current.call('device_poll',payload,d.token),expected);assert.deepEqual(await off.call('device_poll',payload,d.token),expected);
  assert.deepEqual(current.snapshot(),original.snapshot());
 });
 const result={status:'PASS',groups:checks.length,actualServiceRequests:calls,checks,actualFactory:true,actualLoginPairEnrollPoll:true,
  oldLegacyCompared:true,externalCloudRequests:0,platformRequests:0,productionWrites:0,artifacts,utc:new Date().toISOString()};
 fs.writeFileSync(path.join(D,'CLOUD-SERVICE-TEST-RESULTS.json'),JSON.stringify(result,null,2)+'\n');
 console.log(JSON.stringify({...result,checks:undefined,artifacts:undefined}));
}
module.exports={fixture,login,enroll,req};
if(require.main===module)main().catch(error=>{console.error(error.stack);process.exitCode=1;});
