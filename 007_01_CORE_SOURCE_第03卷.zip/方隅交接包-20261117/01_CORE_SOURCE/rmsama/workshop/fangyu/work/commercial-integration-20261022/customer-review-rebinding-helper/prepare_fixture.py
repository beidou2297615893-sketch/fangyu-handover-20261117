from pathlib import Path
import hashlib,json,shutil,datetime
W=Path(__file__).resolve().parent;A=W.parent/'customer-read-purpose-after-f82-candidate';I=W.parent/'customer-read-purpose-after-f82-independent-review';B=W/'own-compiled'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
fixed={A/'FINAL-RECEIPT.json':'b0d839d70ea5276566ecc484c565c907715450dba23993b386b1cf4bdd376f52',A/'SEALED.json':'a897f52fc3fcb7e5a6d5086ada0d3cc2b2e42b9a1ae6f5ae0a6b2503c4a5107c',A/'SOURCE-FILES.json':'b57efbf967fb1d1e23b86deb2b852f9dbfa1e21f1c13bd1f6661f33b9f388135',I/'FINAL-RECEIPT.json':'b4faa36859349e9b68b274fead8ad01e181551aebeadfc472425f260fa57cddf',I/'SEALED.json':'99aba9eb25882f861330f65fe7b60f609068512e993d18ac2ae18569f98e5279'}
for p,pin in fixed.items():assert sha(p)==pin
assert not B.exists();B.mkdir()
src=I/'independent-compiled/dist/FangyuWorkbench/project';shutil.copytree(src,B/'payload/project')
for p in ['cloud_fixture.py','compiled-fixture.json']:
 out=B/'payload/qa-fixtures'/p;out.parent.mkdir(exist_ok=True,parents=True);shutil.copy2(I/'independent-compiled/dist/FangyuWorkbench/qa-fixtures'/p,out)
shutil.copy2(A/'build_probe.py',W/'build_probe.py')
shutil.copy2(I/'independent-compiled/standard_loader_prefix.py',B/'standard_loader_prefix.py')
rid=json.loads((I/'independent-compiled/PROBE-INPUTS.json').read_bytes())['release_id'];project=B/'payload/project';release=project/'work/ui-native-r57/releases'/rid
inputs={'authorAndIndependentFixed':{str(p):pin for p,pin in fixed.items()},'project':str(project),'release':str(release),'copiedMatureBuildSha256':sha(W/'build_probe.py'),'prefixSha256':sha(B/'standard_loader_prefix.py'),'noAuthorOrIndependentDbCopied':True,'timestamp':(datetime.datetime.now(datetime.timezone.utc)-datetime.timedelta(minutes=1)).isoformat()}
(W/'INPUTS.json').write_text(json.dumps(inputs,ensure_ascii=False,indent=2)+'\n','utf-8')
from customer_review_rebinder import rebind_customer_reviews
before={n:sha(project/n) for n in ['SHIPPED-PINS.json','HELD-STANDARD-MANIFEST.json']};before[str(release/'RELEASE.json')]=sha(release/'RELEASE.json')
result=rebind_customer_reviews(project,release,'independent-local-review:'+fixed[I/'FINAL-RECEIPT.json'],inputs['timestamp'])
assert all(sha(project/n)==pin for n,pin in before.items())
(W/'FIRST-REBIND.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n','utf-8')
print('Own final-payload helper rebind succeeded; only four JSON changed, manifests untouched')
