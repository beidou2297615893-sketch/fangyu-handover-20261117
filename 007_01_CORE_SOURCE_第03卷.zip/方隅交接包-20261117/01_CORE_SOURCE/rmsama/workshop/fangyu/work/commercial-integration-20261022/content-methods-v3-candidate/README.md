# 完整业务方法：第三版独立候选

本候选只在本目录准备，未改已封版v2、现用Native/stage/前端、云配置或真实客户数据。ZIP是叠加在已审核v2及记录Native快照上的方法增量，不是整套生产部署包。

## 实际接入

已核xintu1314/xhs-creator-suite@babb659a96af4d8886b8f343ee8c3c3c32a66656的9个完整SKILL及24份参考原字节。复查43项目后追加4个MIT项目的8份完整资源：mengke的主页/评论回复/成交路径，chenjin的小红书起号和日历手册，pigbiglong的知识记录指南，veeicwgy的内容发布包说明。共41份正文、5个MIT来源。来源、commit、路径、原文SHA、许可与方法对应见RESOURCE-MAPPING、METHOD-VERSIONS和resources；5份MIT完整版权声明同时嵌入Native、client及cloud目录，且保留licenses原件。CC BY-NC的dbskill未纳入商业候选。

17项业务现在均有完整正文或明确标注的指南适配。方法选择最少必要资源，每次只装该方法正文及必要参考，未把43项目全塞进提示词。修订/学习/知识/日历/内容包有适配边界；评论回复有完整方法，DM仅筛选问题及通用草稿，未宣称完整对话或真实发送。

这不是将短_TASKS换成另一段泛化文字。公开链路测试确认选定完整正文和原SHA实际进入provider系统消息，客户输入及前置产物只进user数据。原schema、连续原文引用、人工采用、原请求恢复保留。上游文档里的脚本/API/外部记忆/发布操作只作为不可执行的方法说明；没有新增执行器、网络、费用、模型权重或真实平台动作。

## 版本与旧任务

旧17个v1 spec、digest及旧cloud/content-methods.json原字节保留。新任务默认资源版v3；run、reconcile、apply及前置产物校验均按原任务methodDigest取冻结版本。旧准备任务不自动换方法；旧unknown在Native和云同时升级后仍用原method digest和原请求号读回原结果，provider调用仍1次。unknown不能换方法版本或新键绕过占用。

wire和v2的精确10项trusted_context不变。云以已有method_id/method_digest选择可信版本；旧v1沿用原catalog绑定锚点，新方法目录不改变旧费用上下文。客户端和Native目录来自同一固定资源spec，业务字段不能自选正文、schema或资源。

Native content_workflow.py仅6处方法调用点变化（12行增删），保留原CRLF和所有其他P1/P2逻辑。云仅改内容方法选择/验证/目录绑定3文件，中央scope、设备授权、原预算、服务额度、原键索引均沿v2；不把整目录覆盖回当前工程。

## 设计、验证与采用

DESIGN.md先给固定对应；最难定位→选题→写作链先红后绿，之后才扩量。完整正文、跨阶段引文、人工采用/审核包、旧版本前置产物、旧unknown恢复和资源损坏拒绝均有公开接口验证。

最终193项Node、11项Python通过；原service8项通过。历史AI/额度/规则107/115通过，另外8个旧10月10日提示词/版本断言与已封版v2及真实线上对照一致，未回退10月19日已批准规则。VERIFICATION.json保留准确日志。Windows Node22与合成provider/storage不能证明真实CloudBase/Node20.19、真实模型质量或平台有效性。

integration-v3.patch相对根为native/、client/、cloud/。采用时先核BASELINE-PINS、HOST-PINS和当前总控候选差异，逐块合并P1/P2及Native作者最新接线，再由宿主批准最终合并字节的pins。候选目录manifest只是证据，不是代码授权。新cloud/content-methods-v3.json必须纳入闭包，旧content-methods.json不可删除。包只含合并增量、原资源与审查资料；完整离线复跑还依赖本目录baseline/tests及原v2，不能把ZIP当独立完整软件运行。

方法全文接入不代表全部业务执行器接通。联网取帖/采样、真实图像或视频制作、Hermes/Obsidian外部写入、定时执行、媒体上传和发布仍未接。17项schema沿原四字段输出推荐候选，额外方案和缺口放summary/hypotheses，未扩充原UI或承诺1:1复刻上游所有交互产物。完整43项目业务映射原样保留在evidence，没有将它们全部标为已集成。
