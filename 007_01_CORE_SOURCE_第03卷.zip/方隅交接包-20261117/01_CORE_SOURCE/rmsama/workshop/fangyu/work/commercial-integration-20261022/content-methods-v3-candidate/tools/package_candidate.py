"""Freeze an overlay only; apply its patch exclusively inside a new work child."""
from datetime import datetime,timezone
import difflib
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import zipfile

ROOT=Path(__file__).resolve().parents[1]
CHANGED=('native/workflow_methods.py','native/content_workflow.py','client/gateway_adapter.py',
 'client/trusted_method_pins.py','cloud/content_methods.cjs','cloud/content_contract.cjs','cloud/content_gateway.cjs')
ADDED=('cloud/content-methods-v3.json',)
NODE=r'C:\积木软件工坊\核心组件\社媒人设与内容运营组件库\runtime\tools\node-v22.23.4-win-x64\node.exe'
SDK=r'C:\积木软件工坊\项目\方隅公寓客户版\work\cloud\workspace\node_modules'
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def save(name,value):(ROOT/name).write_bytes(json.dumps(value,ensure_ascii=False,indent=2).encode('utf8'))

def main():
 verified=json.loads((ROOT/'VERIFICATION.json').read_text('utf8'));assert verified['offlineCandidateVerified']
 assert not verified['requiresRebaseAgainstCurrentSource'],'Concurrent source update needs parent review first'
 parts=[];records=[]
 for name in CHANGED+ADDED:
  old=(ROOT/'baseline'/name).read_bytes().decode('utf8') if name in CHANGED else ''
  new=(ROOT/name).read_bytes().decode('utf8')
  parts.append('diff --git a/'+name+' b/'+name+'\n')
  if name in ADDED:parts.append('new file mode 100644\n')
  parts.extend(difflib.unified_diff(old.splitlines(keepends=True),new.splitlines(keepends=True),
   fromfile='a/'+name if name in CHANGED else '/dev/null',tofile='b/'+name))
  records.append({'path':name,'baselineSha256':sha(ROOT/'baseline'/name) if name in CHANGED else None,
   'sha256':sha(ROOT/name),'bytes':(ROOT/name).stat().st_size})
 patch=ROOT/'integration-v3.patch';patch.write_bytes(''.join(parts).encode('utf8'))
 smoke=Path(tempfile.mkdtemp(prefix='patch-smoke-',dir=ROOT/'work'))
 for folder in ('native','client','cloud'):shutil.copytree(ROOT/'baseline'/folder,smoke/folder)
 (smoke/'cloud/site/assets').mkdir(parents=True)
 checks=[]
 for command in (["git","-c","core.autocrlf=false","apply","--check",str(patch)],
                 ["git","-c","core.autocrlf=false","apply",str(patch)]):
  done=subprocess.run(command,cwd=smoke,capture_output=True,text=True,encoding='utf8',errors='replace')
  checks.append({'command':command,'exitCode':done.returncode})
  assert done.returncode==0,'Isolated patch apply failed'
 for name in CHANGED+ADDED:assert (smoke/name).read_bytes()==(ROOT/name).read_bytes(),name
 native_pins={n:sha(ROOT/'native'/n) for n in ('content_workbench.py','workflow_methods.py','workflow_knowledge.py','content_workflow.py')}
 save('HOST-PINS.json',{'trustedParentMustApproveTheseBytes':True,'sourceOverlayBase':'v2 sealed cloud/client + recorded Native snapshot',
  'extensionSourcePins':native_pins,'extensionLoaderSha256':sha(ROOT/'native/content_extension_loader.py'),
  'adapterSha256':sha(ROOT/'client/gateway_adapter.py'),'trustedMethodPinsSha256':sha(ROOT/'client/trusted_method_pins.py'),
  'requiredUnchangedLegacyCatalogSha256':sha(ROOT/'cloud/content-methods.json'),
  'newCatalogSha256':sha(ROOT/'cloud/content-methods-v3.json'),
  'note':'Manifest is evidence, not authority. Merge latest P1/P2 first; approve final merged byte pins in the host.'})
 environment=dict(os.environ,NODE_PATH=SDK,PYTHONDONTWRITEBYTECODE='1')
 node_script="global.fetch=()=>{throw Error('network forbidden')};require('./cloud/index.js');const m=require('./cloud/content_methods.cjs');if(m.getMethod('persona').version!==3)process.exit(2);"
 done=subprocess.run([NODE,'-e',node_script],cwd=smoke,env=environment,capture_output=True,text=True,encoding='utf8',errors='replace')
 assert done.returncode==0,'Patched production cloud closure cannot import'
 py_script="import importlib.util,pathlib; p=pathlib.Path('native');s=importlib.util.spec_from_file_location('loader',p/'content_extension_loader.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m);m.load_extension(p.resolve(),"+repr(native_pins)+");from client.gateway_adapter import ContentGatewayAdapter"
 done=subprocess.run([sys.executable,'-X','utf8','-B','-c',py_script],cwd=smoke,env=environment,capture_output=True,text=True,encoding='utf8',errors='replace')
 assert done.returncode==0,'Patched Native/client closure cannot import'
 save('CANDIDATE-FILES.json',{'candidateRevision':3,'files':records,'wireProtocolChanged':False,
  'requiredUnchanged':['cloud/content-methods.json','native/content_workbench.py','native/workflow_knowledge.py','native/content_extension_loader.py'],
  'parentMustMergeAgainstCurrentSource':True,'allMITNoticesEmbeddedInRuntimeCopies':True})
 save('PATCH-MANIFEST.json',{'patchSha256':sha(patch),'checks':checks,'smokeDirectory':str(smoke),
  'allPatchedBytesMatchTestedCandidate':True,'cloudImportsPassed':True,'nativeAndClientPinnedImportsPassed':True,
  'modifiedFiles':len(CHANGED),'addedFiles':len(ADDED),'nativeWorkflowChangedLines':12,
  'productionModified':False,'v2Modified':False})
 documents=('README.md','DESIGN.md','RESOURCE-MAPPING.json','METHOD-VERSIONS.json','VERIFICATION.json',
  'HOST-PINS.json','BASELINE-PINS.json','CANDIDATE-FILES.json','PATCH-MANIFEST.json','integration-v3.patch',
  'outputs/完整方法接入与验证说明.md')
 paths=[ROOT/n for n in CHANGED+ADDED+documents]
 for folder in ('resources','licenses','evidence'):
  paths.extend(p for p in (ROOT/folder).rglob('*') if p.is_file())
 paths=sorted(set(paths))
 archive_path=ROOT/'outputs/content-methods-v3-candidate.zip'
 with zipfile.ZipFile(archive_path,'w',zipfile.ZIP_DEFLATED) as archive:
  for path in paths:archive.write(path,str(path.relative_to(ROOT)).replace('\\','/'))
 with zipfile.ZipFile(archive_path) as archive:
  assert len(archive.namelist())==len(paths)==len(set(archive.namelist()))
  for name in archive.namelist():assert hashlib.sha256(archive.read(name)).hexdigest()==sha(ROOT/name),name
 delivery={'candidateRevision':3,'frozenAtUtc':datetime.now(timezone.utc).isoformat(),'candidateComplete':True,
  'package':{'path':str(archive_path.relative_to(ROOT)).replace('\\','/'),'sha256':sha(archive_path),'bytes':archive_path.stat().st_size,'entries':len(paths)},
  'patchSha256':sha(patch),'patchExactBytesPassed':True,'runtimeImportClosurePassed':True,
  'resourceDocuments':41,'MITProjects':5,'currentMethodsWithResources':17,'legacyVersionsRetained':17,
  'nodeChecks':193,'pythonChecks':11,'inheritedCorePassed':107,'inheritedCoreTotal':115,
  'eightOldAssertionsUnchanged':True,'inheritedServicePassed':8,'v2Unchanged':True,
  'productionDeployed':False,'realModelsCalled':False,'allBusinessExecutorsIntegrated':False,
  'limits':['No real model quality/real platform acceptance','DM dialogue, media rendering, external memory, scheduling and publishing executors still incomplete',
   'Parent Native adapter/profile integration and final merged pins are not completed by this overlay']}
 save('DELIVERY.json',delivery)
 all_paths=paths+[archive_path,ROOT/'DELIVERY.json']
 all_paths+=list((ROOT/'tools').glob('*.py'))+list((ROOT/'tests').glob('*.py'))+list((ROOT/'tests').glob('*.cjs'))+list((ROOT/'tests').glob('*.json'))
 save('FILES-SHA256.json',[{'path':str(p.relative_to(ROOT)).replace('\\','/'),'sha256':sha(p),'bytes':p.stat().st_size} for p in sorted(set(all_paths))])
 print(json.dumps(delivery,ensure_ascii=False))

if __name__=='__main__':main()
