"""Create one independently pinned copy of the sealed draft, check and prepare.

Writes only review-4. Installation remains code-disabled. Root separately
reviews the resulting bytes, plan and recovery acknowledgement before install.
"""
from pathlib import Path
import ast,hashlib,json,pprint,subprocess,sys

sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
P=HERE.parents[3]
SOURCE=HERE.parent/'install_next_launch.DRAFT.py'
SOURCE_SHA='0fb1fd17be8518541123232666e9f659c0a1b34f39f1ac2c24aacaade986a3d4'
SPEC={
    'release_id':'ui-r57-20261022T204121Z-caf80777',
    'unified_sha':'c6eca73ebcb112fe068c094bc5a3f1ef992aa561d77c4e71ee01c84e28de17ac',
    'files':3152,
    'release_sha':'d1bdf8a511db9a8568d990a48fcda9ea6ae2e4a1b8224ffcb5e811cf7e23f98c',
    'candidate_launcher_sha':'50611f5bbeb51bd03842f39ff2206b18343e00bb99bf980d1279dda0a1e2a4f8',
    'recovery_checkpoint':True,'delivery':'delivery-v71','http_groups':70,
    'staged_sha':'6d94f903a42bedd88a0215d8f906684798c202fd85c03f3530045a520c7b86b4',
    'evidence':{
        'frozen-native/SUMMARY.json':'14831a73f4c931859898ca4dbdbe4043b4a751cee3cb326e8e3213fd7c21a107',
        'frozen-native/CLOSURE-RESULTS.json':'8dbb3863a89aa43c9391d1251664f0eb8f8b35c8b2f7ae1283777a49bb349de3',
        'frozen-native/INDEPENDENT-FINAL-VALIDATION.json':'d37abf6d98c43f15369a116a6af92888136ffaa5884ffb6634986be86b150662',
        'frozen-native/MEDIA-OUTCOMES-SUMMARY.json':'45da8008e0aa7f820e64071cc53f4344eadff695aa6dcde76a607ed45c586cc0',
        'frozen-native/SOURCE-SCHEDULER-FINAL.json':'971b5b08bf1d721490987b8040e6b697ffc401ee67d577e2b748c1eb96e26ec1',
        'frozen-native/SOURCE-SCHEDULER-PRECONDITION.json':'54b244f4529e8c0acd1462b89c34e0b9a1f22fac5557cfcd0498a07e393da1d3',
        'frozen-native/READINESS-UI-FINAL.json':'e538b2123231033886443a498e2a1359d0b18e23c3c68d3f2c6f4ea96e8d78c5',
        'frozen-native/RESULTS-candidate-unified-v71.json':'6c5f8cc51ae303746512e21d1a0c239f5112f5fb306058a22352df0308e6da98',
        'frozen-native/FROZEN-NATIVE-HTTP-RESULTS-candidate-unified-v71.json':'d0b1ba304be80e7f27b573df31cfed6af836f0eda0128ced1e3d72d927c91e6d',
        'frozen-native/GATEWAY-HTTP-RESULTS.json':'83dd2a825ba07d551393d52f149aa3e2d0bb55da1680dc2b9896f0271f82fe6c',
        'frozen-native/ASSERTION-PRESERVATION.json':'d65ba6f42c3eea13eaa70fb900d2681f138e6485236ba2f5c5f2c06c6db76dc0',
    },
}
def sha(raw):return hashlib.sha256(raw).hexdigest()
def dump(path,value):
    with path.open('x',encoding='utf-8') as stream:json.dump(value,stream,ensure_ascii=False,indent=2);stream.write('\n')
def main():
    raw=SOURCE.read_bytes()
    if sha(raw)!=SOURCE_SHA:raise RuntimeError('Sealed draft bytes changed')
    body=raw.decode('utf-8')
    needle='ACCEPTED = {}  # Deliberately empty until root reviews final immutable pins.'
    expected="expected = P / 'work/commercial-integration-20261022/delivery-next-launch'"
    if body.count(needle)!=1 or body.count(expected)!=1:raise RuntimeError('Sealed template differs')
    body=body.replace(needle,'ACCEPTED = '+pprint.pformat({'candidate-unified-v71':SPEC},sort_dicts=True,width=110)+'  # Root final fixed pins; one candidate only.')
    body=body.replace(expected,"expected = P / 'work/commercial-integration-20261022/delivery-next-launch/review-4'")
    tree=ast.parse(body)
    flags={node.targets[0].id:ast.literal_eval(node.value) for node in tree.body if isinstance(node,ast.Assign)
        and len(node.targets)==1 and isinstance(node.targets[0],ast.Name) and node.targets[0].id in ('ACCEPTED','INSTALLATION_REVIEWED')}
    if flags['INSTALLATION_REVIEWED'] is not False or set(flags['ACCEPTED'])!={'candidate-unified-v71'}:raise RuntimeError('Review copy gates changed')
    target=HERE/'install_next_launch.v71.REVIEWED.py'
    with target.open('xb') as stream:stream.write(body.encode('utf-8'))
    outputs={}
    for action in ('--check','--prepare'):
        child=subprocess.run([sys.executable,'-I','-B',str(target),'--candidate','candidate-unified-v71',action],
            cwd=HERE,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=90)
        path=HERE/('V71-'+action[2:].upper()+'.log')
        with path.open('xb') as stream:stream.write(child.stdout)
        if child.returncode:raise RuntimeError('Review copy '+action+' failed; exact output preserved')
        outputs[action]=child.stdout.decode('utf-8',errors='replace').strip()
    folder=HERE/'next-launch-prepared/candidate-unified-v71'
    plan=folder/'CANONICAL-DELEGATION-PREPARED.json';draft=folder/'launcher.py.DRAFT'
    receipt={'status':'PASS_V71_CHECK_PREPARED_NOT_INSTALLED','candidate':'candidate-unified-v71',
        'reviewedInstaller':str(target),'reviewedInstallerSha256':sha(target.read_bytes()),
        'sealedDraftSourceSha256':SOURCE_SHA,'sealedDraftModified':False,
        'changesFromSealedDraft':['Single fixed v71 allowlist entry including 11 acceptance JSON pins','Expected self folder changed to review-4 only'],
        'preparedPlan':str(plan),'preparedPlanSha256':sha(plan.read_bytes()),
        'preparedLauncherDraft':str(draft),'preparedLauncherDraftSha256':sha(draft.read_bytes()),
        'evidenceJsonCount':len(SPEC['evidence']),'httpGroups':70,'recoveryCheckpoint':True,
        'INSTALLATION_REVIEWED':False,'installed':False,'productionWrites':0,'NMutations':0,
        'rootOwnReviewAndInstallRequired':True,'originalCasInstallerSha256':'9909f60d16ad3eaed54b9f97ea0d275ad38510c679ba651ce05af44d920ed0f6',
        'outputs':outputs}
    dump(HERE/'V71-PREPARED-REVIEW.json',receipt)
    print(json.dumps({key:receipt[key] for key in ('status','reviewedInstallerSha256','preparedPlanSha256','preparedLauncherDraftSha256','INSTALLATION_REVIEWED','installed')},ensure_ascii=True))
if __name__=='__main__':main()
