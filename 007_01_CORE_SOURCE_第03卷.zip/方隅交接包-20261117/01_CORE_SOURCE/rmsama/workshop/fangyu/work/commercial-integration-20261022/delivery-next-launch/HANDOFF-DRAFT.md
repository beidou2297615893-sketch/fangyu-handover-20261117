# 下一次入口安装草案交接

状态：草案审查和合成行为验证已完成，最终固定版本待 root 提供。未准备实际候选、未安装、未启动应用，S/N/业务数据/平台会话均未改。

入口为本目录 `install_next_launch.DRAFT.py`，实际 SHA256 `0fb1fd17be8518541123232666e9f659c0a1b34f39f1ac2c24aacaade986a3d4`。`ACCEPTED={}`，`INSTALLATION_REVIEWED=False`。它复用 delivery-v66 流程与原 `install_canonical_delegation.py`（固定 SHA256 `9909f60d16ad3eaed54b9f97ea0d275ad38510c679ba651ce05af44d920ed0f6`），没有复制改写原 CAS/备份/回滚逻辑。原模块以 `compile(..., optimize=0)` 装载，-O 不会移除其断言守卫。

验证：17/17 合成行为通过，包括空 allowlist/路径拒绝、只读 check、prepare 仅写自有 work、闭包/binding/旧入口/STAGED/证据篡改拒绝、安装默认禁用、原双文件成功提交及原字节备份、第二写失败回滚、第三方冲突保留、-O 下未审计划真实拒绝、recovery ack、损坏 v65 恢复闭包拒绝、重复 prepare 相同字节接受及本地计划篡改拒绝。真实 CLI --check/--prepare/--install 在空 allowlist 下均拒绝。

独立只读重新核对 v65 恢复闭包 2777 文件，UNIFIED `c6bc35bc5e2b44c437bf9b8262897d33faf4a5a5c7c1b5f859be130589735268` 完整；正式 launcher `c55ed17e0b06b37765942e6eaf5f4506d16a4c92fc55d96308bf8069d00feba4`、FROZEN `fbd4f3d810658b4f571e41c7fe06d0771111900c6eab941229888a7a5a693702`、binding `14cf53964f5d44d123e989805ea741669ab3f05054e730ddcb299a0aac51a9cb` 前后完全相同。binding 仅按原字节哈希，没有解析生产配置。

原报告 12 项已陈旧，恢复时落盘第13项测试错误要求至少6个 assert，实际原安装器没有6个；已改成真正 -O 行为拒绝验证，产品草案不因此改动。首次失败日志及旧元数据在 `review-before-resume`，新原始日志在 `SYNTHETIC-TESTS.log`，当前证据为 `DRAFT-VALIDATION.json` / `INDEPENDENT-REVIEW.json` / `SOURCE.json`。

下一步 root 提供最终不可变候选名、release_id、UNIFIED SHA/文件数、RELEASE SHA、candidate launcher SHA、STAGED SHA，以及 delivery/frozen-native 下固定验收 JSON 哈希和组数，才可填入 `ACCEPTED` 单条固定配置并执行 --check、--prepare。保持 `INSTALLATION_REVIEWED=False`；root 审查准备结果后自己决定安装。未将临时 v69 视为最终版。

原安装器限制：这是逐文件 CAS、原字节备份、进程内异常回滚与冲突保护，不是跨两个文件的单次原子交换，也没有自动断电恢复。最终安装时应用需保持退出，保留备份与事务日志。没有扩大为服务/进程管理器。

本目录之外无写入。已停写，待 root 明确续接。
