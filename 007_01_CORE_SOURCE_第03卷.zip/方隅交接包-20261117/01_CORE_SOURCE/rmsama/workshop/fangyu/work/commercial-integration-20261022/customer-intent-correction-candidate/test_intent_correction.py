"""Candidate Native service -> actual Business/AI workflow -> actual SQLite.
Only synthetic local records. No platform, model, cloud, or user-session I/O.
"""
from pathlib import Path
from copy import deepcopy
import hashlib,importlib.util,json,os,sys,tempfile,unittest
from concurrent.futures import ThreadPoolExecutor
from unittest.mock import patch
sys.dont_write_bytecode=True
W=Path(__file__).parent; S=Path('C:/积木软件工坊/项目/方隅公寓客户版/work/parallel-integration-20261018/final-integration/stage-02/project')
R=S/'work/ui-runtime-r55/src'; N=S/'work/ui-native-r57'; C=W/'candidate'
def fixture_fence(event,args):
    if event in ('subprocess.Popen','os.system','os.startfile','os.posix_spawn'):
        raise RuntimeError('Child process forbidden')
    if event in ('socket.connect','socket.bind') and (not isinstance(args[1],tuple) or args[1][0]!='127.0.0.1'):
        raise RuntimeError('External request forbidden')
    if event=='socket.getaddrinfo' and args[0] not in ('127.0.0.1',None):raise RuntimeError('External DNS forbidden')
    if event=='sqlite3.connect' and not Path(args[0]).resolve().is_relative_to(W):raise RuntimeError('Real DB forbidden')
    if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):
        path=Path(os.fsdecode(args[0])).absolute();mode,flags=args[1] or '',args[2] or 0
        writes=any(c in str(mode) for c in 'wax+') or isinstance(flags,int) and bool(flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC))
        if writes and not path.is_relative_to(W):raise RuntimeError('Noncandidate write forbidden')
sys.addaudithook(fixture_fence)
sys.path[:0]=[str(R),str(C/'work/ui-native-r57'),str(N)]
import assistant
assistant.__path__.insert(0,str(C/'work/ui-runtime-r55/src/assistant'))
VENDOR='--vendor' in sys.argv
if VENDOR:
    sys.argv.remove('--vendor')
    spec=importlib.util.spec_from_file_location('assistant.business',C/'work/shared-backend-integration/vendor-src/assistant/business.py')
    business=importlib.util.module_from_spec(spec);sys.modules['assistant.business']=business;spec.loader.exec_module(business)
from core.engine import Core
from assistant.customer_list import _person
from customer_workbench import CustomerWorkbench
from customer_intent_workbench import IntentCorrectionWorkbench
from assistant.intent_correction import IntentCorrectionError,persist_ai_result,digest

class CorrectionTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(dir=W);self.core=Core(Path(self.tmp.name)/'db',R/'resources',defer_startup_recovery=True)
        self.company={'id':'fangyu-apartment-client','name':'Synthetic correction','edition':'customer','personalMode':False,
            'authMode':'managed','managedWorkspace':{'environment_id':'correction-fixture','endpoint':'https://example.invalid'}}
        tenant='cloud-'+hashlib.sha256(b'correction-fixture\nfangyu-apartment-client').hexdigest()[:24]
        uid=hashlib.sha256((tenant+'\nalice').encode()).hexdigest()
        self.user={'id':uid,'tenant_id':tenant,'username':'alice','role':'operator','cloud_bound':True,'disabled':False}
        self.core.store.put('users',self.user);self.core.store.put('tenants',{'id':tenant,'tenant_id':tenant,'name':'Synthetic'})
        for aid,store in [('account-a','gubei'),('account-b','gubei'),('account-c','other')]:
            self.core.store.put('accounts',{'id':aid,'tenant_id':tenant,'cloud_owner':'alice','store_id':store,'platform':'xiaohongshu'})
            self.core.store.put('tasks',{'id':'task-'+aid,'tenant_id':tenant,'cloud_owner':'alice','account_id':aid,'store_id':store,'platform':'xiaohongshu'})
        self.leads=[]
        for i,aid in enumerate(('account-a','account-b','account-c')):
            lead={'id':'lead-'+str(i),'tenant_id':tenant,'cloud_owner':'alice','task_id':'task-'+aid,'platform':'xiaohongshu',
                'store_id':'other' if i==2 else 'gubei','author_id':'same-person','comment_id':'comment-'+str(i),'author':'合成客户',
                'text':'需要古北两个月公寓 '+str(i),'note_url':'https://www.xiaohongshu.com/explore/0123456789abcdef01234567',
                'created_at':'2026-10-23T00:00:00Z','ai_intent':{'status':'graded','level':'low','reason':'synthetic old AI'}}
            self.core.store.put('leads',lead);self.leads.append(deepcopy(lead))
        self.customers=CustomerWorkbench(self.core,self.company,W/'source-view')
        self.service=IntentCorrectionWorkbench(self.core,self.customers,self.company)
        self.customer_id=_person(self.leads[0])[0]
        self.scope={'storeId':'gubei','customerId':self.customer_id,'leadId':'lead-0','platform':'xiaohongshu'}
    def tearDown(self):self.tmp.cleanup()
    def payload(self,request='correction-one'):
        current=self.service.read(self.user,'gubei',self.scope)
        return {**self.scope,'requestId':request,'expectedVersion':current['version'],'sourceDigest':current['sourceDigest'],
            'status':'graded','level':'high','reason':'已核对原评论明确两个月需求'}
    def cancellation(self,data):
        return {**self.scope,'requestId':data['requestId'],'requestDigest':digest({**data,'reason':data['reason'].strip()})}
    def test_original_chain_single_comment_and_receipt(self):
        before=self.core.store.get('leads','lead-0');data=self.payload()
        result=self.service.correct(self.user,'gubei',data)
        self.assertEqual(result['currentIntent']['level'],'high')
        self.assertEqual(result['receipt']['state'],'saved')
        self.assertEqual(self.core.store.get('leads','lead-0')['ai_intent'],before['ai_intent'])
        self.assertNotIn('manual_intent',self.core.store.get('leads','lead-1'))
        replay=self.service.correct(self.user,'gubei',data)
        self.assertEqual(result['receipt'],replay['receipt'])
        self.assertEqual(len(replay['history']),1)
        self.assertEqual(len(self.core.store.list('intent_corrections_v1',self.user['tenant_id'])),1)
    def test_cross_account_customer_and_store_isolation(self):
        _actor,_pub,_item,person=self.customers.detail_context(self.user,'gubei',self.customer_id,platform='xiaohongshu')
        self.assertEqual({c['lead_id'] for c in person['comments']},{'lead-0','lead-1'})
        self.service.correct(self.user,'gubei',self.payload())
        scope={**self.scope,'leadId':'lead-1'}
        second=self.service.read(self.user,'gubei',scope)
        self.assertEqual(second['currentIntent']['level'],'low')
        self.assertIsNone(second['manualIntent'])
        with self.assertRaises(Exception):self.service.read(self.user,'gubei',{**self.scope,'leadId':'lead-2'})
        with self.assertRaises(Exception):self.service.read(self.user,'other',self.scope)
        other=self.service.read(self.user,'other',{**self.scope,'storeId':'other','leadId':'lead-2'})
        self.assertEqual(other['history'],[])
        self.assertIsNone(other['manualIntent'])
    def test_version_and_source_cas(self):
        original=self.payload()
        lead=self.core.store.get('leads','lead-0');lead['ai_intent']['level']='medium';self.core.store.put('leads',lead)
        with self.assertRaises(IntentCorrectionError) as caught:self.service.correct(self.user,'gubei',original)
        self.assertEqual(caught.exception.code,'INTENT_VERSION_CONFLICT');self.assertIs(caught.exception.mutation_committed,False)
        fresh=self.payload('source-cas');lead['text']='原文已变化';self.core.store.put('leads',lead)
        with self.assertRaises(IntentCorrectionError) as caught:self.service.correct(self.user,'gubei',fresh)
        self.assertEqual(caught.exception.code,'INTENT_SOURCE_CHANGED')
        self.assertEqual(self.core.store.list('intent_corrections_v1'),[])
    def test_concurrent_edit_and_request_conflict(self):
        one=self.payload('one');two={**one,'requestId':'two','level':'medium'}
        def save(data):
            try:return self.service.correct(self.user,'gubei',data)['receipt']['state']
            except IntentCorrectionError as exc:return exc.code
        with ThreadPoolExecutor(max_workers=2) as pool:results=list(pool.map(save,(one,two)))
        self.assertEqual(sorted(results),['INTENT_VERSION_CONFLICT','saved'])
        saved=one if results[0]=='saved' else two
        with self.assertRaises(IntentCorrectionError) as caught:self.service.correct(self.user,'gubei',{**saved,'reason':'另一个理由'})
        self.assertEqual(caught.exception.code,'INTENT_REQUEST_CONFLICT')
    def test_disabled_wrong_owner_and_unknown_receipt(self):
        result=self.service.read(self.user,'gubei',{**self.scope,'requestId':'not-yet-known'})
        self.assertEqual(result['receipt'],{'requestId':'not-yet-known','state':'not_found'})
        original=self.payload()
        row=self.core.store.get('users',self.user['id']);row['disabled']=True;self.core.store.put('users',row)
        with self.assertRaises(Exception):self.service.correct(self.user,'gubei',original)
        self.assertTrue(self.core.store.get('users',self.user['id'])['disabled'])
        self.assertNotIn('manual_intent',self.core.store.get('leads','lead-0'))
    def test_ai_reanalysis_keeps_manual_and_original_ai(self):
        from assistant.ai_workflow import LocalAIWorkflow,effective_intent
        from assistant import intent_rule_management
        result=self.service.correct(self.user,'gubei',self.payload())
        before=self.core.store.get('leads','lead-0')
        workflow=LocalAIWorkflow(self.core,lambda *a:(_ for _ in ()).throw(AssertionError('No model call allowed')),company=lambda:self.company)
        task=self.core.store.get('tasks','task-account-a')
        actual=workflow.analyze(self.user,task,[deepcopy(before)],replace_existing=True)
        self.assertEqual(actual['analyzed'],0)
        after=self.core.store.get('leads','lead-0')
        self.assertEqual(after,before);self.assertEqual(effective_intent(after)['level'],'high')
    def test_atomic_rollback_if_history_insert_fails(self):
        data=self.payload()
        with self.core.store.connect() as db:
            db.execute("CREATE TRIGGER reject_correction BEFORE INSERT ON records WHEN NEW.entity='intent_corrections_v1' BEGIN SELECT RAISE(ABORT,'synthetic rollback'); END")
        with self.assertRaises(IntentCorrectionError) as caught:self.service.correct(self.user,'gubei',data)
        self.assertIs(caught.exception.mutation_committed,False)
        self.assertNotIn('manual_intent',self.core.store.get('leads','lead-0'))
        self.assertEqual(self.core.store.list('intent_corrections_v1'),[])
        self.assertFalse(any(row.get('action')=='intent_correct' for row in self.core.store.list('audit')))
    def test_two_cores_late_ai_write_preserves_manual_and_ai_history(self):
        second=Core(Path(self.tmp.name)/'db',R/'resources',defer_startup_recovery=True)
        before=second.store.get('leads','lead-0');before['ai_intent_history']=[{'reason':'earlier AI kept'}]
        second.store.put('leads',before)
        task=second.store.get('tasks',before['task_id'])
        late={**deepcopy(before),'ai_intent':{'status':'graded','level':'very_low','reason':'late synthetic model'},
            'ai_intent_history':[*before['ai_intent_history'],{'ai_intent':deepcopy(before['ai_intent'])}]}
        self.service.correct(self.user,'gubei',self.payload())
        self.assertFalse(persist_ai_result(second,before,late,task))
        final=second.store.get('leads','lead-0')
        self.assertEqual(final['manual_intent']['level'],'high')
        self.assertEqual(final['ai_intent'],before['ai_intent'])
        self.assertEqual(final['ai_intent_history'],before['ai_intent_history'])
    def test_two_cores_ai_wins_forces_manual_reread_and_preserves_history(self):
        second=Core(Path(self.tmp.name)/'db',R/'resources',defer_startup_recovery=True)
        data=self.payload();before=second.store.get('leads','lead-0');task=second.store.get('tasks',before['task_id'])
        updated={**deepcopy(before),'ai_intent':{'status':'graded','level':'medium','reason':'new analysis'},
            'ai_intent_history':[{'ai_intent':deepcopy(before['ai_intent'])}]}
        self.assertTrue(persist_ai_result(second,before,updated,task))
        with self.assertRaises(IntentCorrectionError) as caught:self.service.correct(self.user,'gubei',data)
        self.assertEqual(caught.exception.code,'INTENT_VERSION_CONFLICT')
        fresh=self.payload('reread-after-ai');self.service.correct(self.user,'gubei',fresh)
        final=second.store.get('leads','lead-0')
        self.assertEqual(final['ai_intent'],updated['ai_intent']);self.assertEqual(final['ai_intent_history'],updated['ai_intent_history'])
    def test_two_cores_simultaneous_manual_only_one_version_wins(self):
        second=Core(Path(self.tmp.name)/'db',R/'resources',defer_startup_recovery=True)
        other=IntentCorrectionWorkbench(second,CustomerWorkbench(second,self.company,W/'source-view'),self.company)
        one=self.payload('cross-core-a');two={**one,'requestId':'cross-core-b','level':'medium'}
        import threading
        barrier=threading.Barrier(2)
        def save(service,data):
            barrier.wait()
            try:return service.correct(self.user,'gubei',data)['receipt']['state']
            except IntentCorrectionError as exc:return exc.code
        with ThreadPoolExecutor(max_workers=2) as pool:
            futures=[pool.submit(save,self.service,one),pool.submit(save,other,two)]
            results=[f.result(timeout=10) for f in futures]
        self.assertEqual(sorted(results),['INTENT_VERSION_CONFLICT','saved'])
        self.assertEqual(len(self.core.store.list('intent_corrections_v1')),1)
    def test_two_cores_ai_rejects_changed_source_even_when_intent_unchanged(self):
        second=Core(Path(self.tmp.name)/'db',R/'resources',defer_startup_recovery=True)
        before=second.store.get('leads','lead-0');task=second.store.get('tasks',before['task_id'])
        changed={**task,'store_id':'other'};self.core.store.put('tasks',changed)
        updated={**deepcopy(before),'ai_intent':{'status':'graded','level':'high'}}
        self.assertFalse(persist_ai_result(second,before,updated,task))
        self.assertEqual(self.core.store.get('leads','lead-0'),before)
    def test_two_cores_simultaneous_ai_and_manual_cannot_overwrite_each_other(self):
        import threading
        second=Core(Path(self.tmp.name)/'db',R/'resources',defer_startup_recovery=True)
        before=second.store.get('leads','lead-0');task=second.store.get('tasks',before['task_id']);data=self.payload('ai-manual-race')
        updated={**deepcopy(before),'ai_intent':{'status':'graded','level':'medium','reason':'race AI'},
            'ai_intent_history':[{'ai_intent':deepcopy(before['ai_intent'])}]}
        barrier=threading.Barrier(2)
        def ai():barrier.wait();return persist_ai_result(second,before,updated,task)
        def manual():
            barrier.wait()
            try:self.service.correct(self.user,'gubei',data);return 'saved'
            except IntentCorrectionError as exc:return exc.code
        with ThreadPoolExecutor(max_workers=2) as pool:
            a,m=pool.submit(ai),pool.submit(manual);ai_result,manual_result=a.result(timeout=10),m.result(timeout=10)
        final=second.store.get('leads','lead-0')
        if ai_result:
            self.assertEqual(manual_result,'INTENT_VERSION_CONFLICT');self.assertNotIn('manual_intent',final)
            self.assertEqual(final['ai_intent_history'],updated['ai_intent_history'])
        else:
            self.assertEqual(manual_result,'saved');self.assertEqual(final['manual_intent']['level'],'high')
            self.assertEqual(final['ai_intent'],before['ai_intent'])
    def test_commit_response_unknown_keeps_original_receipt(self):
        from contextlib import contextmanager
        original=self.core.store.connect
        data=self.payload('commit-unknown')
        class Connection:
            def __init__(self,db):self.db=db
            def __getattr__(self,name):return getattr(self.db,name)
            def commit(self):self.db.commit();raise OSError('Synthetic lost commit acknowledgement')
        @contextmanager
        def connection():
            with original() as db:yield Connection(db)
        with patch.object(self.core.store,'connect',connection):
            with self.assertRaises(IntentCorrectionError) as caught:self.service.correct(self.user,'gubei',data)
        self.assertEqual(caught.exception.code,'INTENT_RESULT_UNCONFIRMED')
        self.assertIsNone(caught.exception.mutation_committed)
        result=self.service.read(self.user,'gubei',{**self.scope,'requestId':'commit-unknown'})
        self.assertEqual(result['receipt']['state'],'saved');self.assertEqual(len(result['history']),1)
    def test_other_employee_and_tenant_cannot_read_or_correct(self):
        for tenant,name in ((self.user['tenant_id'],'bob'),('different-tenant','alice')):
            ident=hashlib.sha256((tenant+'\n'+name).encode()).hexdigest()
            user={**self.user,'id':ident,'tenant_id':tenant,'username':name}
            self.core.store.put('users',user)
            with self.assertRaises(Exception):self.service.read(user,'gubei',self.scope)
            with self.assertRaises(Exception):self.service.correct(user,'gubei',self.payload('foreign-'+name))
        self.assertEqual(self.core.store.list('intent_corrections_v1'),[])
    def test_cancel_wins_blocks_late_save_and_allows_new_request(self):
        data=self.payload('cancel-wins');cancel=self.cancellation(data)
        first=self.service.cancel(self.user,'gubei',cancel)
        self.assertEqual(first['receipt']['state'],'cancelled');self.assertEqual(first['history'],[])
        self.assertEqual(self.service.cancel(self.user,'gubei',cancel)['receipt'],first['receipt'])
        with self.assertRaises(IntentCorrectionError) as caught:self.service.correct(self.user,'gubei',data)
        self.assertEqual(caught.exception.code,'INTENT_REQUEST_CANCELLED');self.assertIs(caught.exception.mutation_committed,False)
        self.assertNotIn('manual_intent',self.core.store.get('leads','lead-0'))
        self.assertEqual(self.service.read(self.user,'gubei',{**self.scope,'requestId':'cancel-wins'})['receipt']['state'],'cancelled')
        saved=self.service.correct(self.user,'gubei',self.payload('after-explicit-cancel'))
        self.assertEqual(saved['receipt']['state'],'saved');self.assertEqual(len(saved['history']),1)
    def test_save_wins_cancel_returns_original_saved_without_new_history(self):
        data=self.payload('save-wins');saved=self.service.correct(self.user,'gubei',data)
        result=self.service.cancel(self.user,'gubei',self.cancellation(data))
        self.assertEqual(result['receipt'],saved['receipt']);self.assertEqual(len(result['history']),1)
        with self.assertRaises(IntentCorrectionError) as caught:
            self.service.cancel(self.user,'gubei',{**self.cancellation(data),'requestDigest':'0'*64})
        self.assertEqual(caught.exception.code,'INTENT_REQUEST_CONFLICT')
        self.assertEqual(len(self.core.store.list('audit')),1)
    def test_cancel_and_save_two_core_atomic_competition(self):
        import threading
        second=Core(Path(self.tmp.name)/'db',R/'resources',defer_startup_recovery=True)
        other=IntentCorrectionWorkbench(second,CustomerWorkbench(second,self.company,W/'source-view'),self.company)
        data=self.payload('cancel-save-race');cancel=self.cancellation(data);barrier=threading.Barrier(2)
        def save():
            barrier.wait()
            try:return self.service.correct(self.user,'gubei',data)['receipt']['state']
            except IntentCorrectionError as exc:return exc.code
        def stop():barrier.wait();return other.cancel(self.user,'gubei',cancel)['receipt']['state']
        with ThreadPoolExecutor(max_workers=2) as pool:
            a,b=pool.submit(save),pool.submit(stop);save_result,cancel_result=a.result(timeout=10),b.result(timeout=10)
        final=second.store.get('leads','lead-0')
        if cancel_result=='cancelled':
            self.assertEqual(save_result,'INTENT_REQUEST_CANCELLED');self.assertNotIn('manual_intent',final)
        else:self.assertEqual(save_result,'saved');self.assertEqual(final['manual_intent']['level'],'high')
        self.assertEqual(len(self.core.store.list('intent_corrections_v1')),1)
    def test_cancel_scope_and_digest_guards(self):
        data=self.payload('cancel-scope');cancel=self.cancellation(data)
        for wrong in ({**cancel,'storeId':'other'},{**cancel,'leadId':'lead-2'},{**cancel,'requestDigest':''},{**cancel,'extra':'no'}):
            with self.assertRaises(Exception):self.service.cancel(self.user,'gubei',wrong)
        self.assertEqual(self.core.store.list('intent_corrections_v1'),[])

if __name__=='__main__':
    suite=unittest.defaultTestLoader.loadTestsFromTestCase(CorrectionTests)
    names=[test.id().split('.')[-1] for test in suite]
    result=unittest.TextTestRunner(verbosity=2).run(suite)
    (W/('BEHAVIOR-VENDOR-RESULT.json' if VENDOR else 'BEHAVIOR-RESULT.json')).write_text(json.dumps({
        'status':'PASS' if result.wasSuccessful() else 'FAIL','testsRun':result.testsRun,'tests':names,
        'failures':[str(test) for test,_ in result.failures],'errors':[str(test) for test,_ in result.errors],
        'business':'current vendor' if VENDOR else 'preserved r55','platform_calls':0,'model_calls':0,'production_mutations':0,
        'database':'synthetic original Core Store only'},indent=2),'utf-8')
    raise SystemExit(0 if result.wasSuccessful() else 1)
