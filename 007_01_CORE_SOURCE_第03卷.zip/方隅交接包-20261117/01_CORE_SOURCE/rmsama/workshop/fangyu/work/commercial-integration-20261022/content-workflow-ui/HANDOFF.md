# v66 内容工作流前端交接

2026-10-23 00:15 左右已停写产品。当前证据是 Node DOM 事件行为 + 实际 Native HTTP + 受信合成模型；本子 agent 的 CUA inventory 为空，没有浏览器截图，不能称视觉/真实模型/平台验收。主控继续实际浏览器验收。

## 产品文件（U 下，仅这四个）

- pages/content-operations.mjs — d3c3c95962bcc77072cb66e6f8b03a9c447c85a61c02b53261f7fe5c729f1b92
- pages/content-operations.css — 48f6aa0600d44e4a4993d51763dc521382cb46a8ef3a74da69af2bfbee832cd2
- **新增** pages/content-workflow.mjs — 864ede98d9e006a78a4c55f37c39522de297be6e7edf528d8e37f5b6afb46606（需要随页面一起进入发行包）
- backend.mjs — 7c06dfac494396ede57ce721a48844b3a9b3e8b8a44b4202a872c4a82d178d90

前一版原件在 before-v66；三个 mjs 均通过 node --check。

## 已接操作

保留原五页签/11动作，页签切换收起任务面板但保留输入。17方法分布到相关页签，资料与引用、任务与结果共用当前账号与门店；引用原文、假设、生成结果和人工采用分别可见。采用人设/选题/草稿回到原编辑器；其他方法保存为本账号方案。审核建议不能替代原人工勾选。

已接7 Native动作。knowledge_import完整UTF8 envelope上限500000字节，其他内容133120，原素材300000逻辑不变。默认 canRunTasks=false 时只准备，不伪造生成。

模型运行单独保存作用域、requestId/taskId摘要，running/unknown不能走本地保存重试；丢失回执按原编号读取，账号/门店/登录世代切换迟到响应不覆盖当前工作区。未执行503显式 mutation_committed=false 转成客户端 mutationCommitted=false。仅本地保存可核对后按原编号重试；确认已保存的prepare/apply从当前工作区恢复对应记录。

按root补 source_interactions_check **只进 sourceAction 白名单**。未加进sourceRead/sourceLocal；网络结果未知后正常全局mutation barrier阻止再发。root负责modal保存/核对原taskId+scan，不能自己增加scan重试。

## 实测

DOM-NATIVE-RESULTS.json：25项通过。使用 linkedom 0.18.12（仅work测试依赖，不进产品），真实页面render/bind的事件驱动，不调用私有页面函数。通过真实 createBackend→Origin/CSRF/cookie→Native→Store。

- 原账号选择/读取；17方法逐项 prepare/run/apply。
- UTF8/CRLF/emoji原文与假设类别保留，准备后显示冻结输入与原引用。
- 视频生成→采用→原编辑器补配文→原稿修订；配文保留，口播更新，同稿新版本。
- 原审核三项勾选→人工通过→新审核包；保留视频配文和口播，明确缺视频素材，published=false。
- 真实合成模型完成后丢失客户端回执→只读原请求恢复；总run次数只增加1次。localStorage只有scope/requestId/taskId。
- 未配置通道分支不显示可执行生成；明确未派发错误保留prepared任务。
- 账号乙的延迟资料搜索在切到甲后不覆盖甲的workspace/输入。

BACKEND-BOUNDARIES.json：3项mock transport行为测试通过。覆盖503未执行标记、内容未知回执无自动重试、source_interactions_check作为mutation且同scan不自动第二次派发。

实际发现：合成排期样例含 fixture-account，后端正确拒绝。前端原先把任何accountId显示成“当前账号”，已改为匹配时显示昵称、不匹配显示“账号不匹配，不能采用”。独立fixture合成模型将排期引用改为本次scope账号和input原稿，随后17方法全通过。另两次失败是测试断言读取导入顺序/包嵌套位置错误，测试已修，不改真实行为。

## 可供主控浏览器验证的服务

- URL http://127.0.0.1:50660/#content
- PID 21448 / exec session 8010（本agent拥有，当前未停止；不要按旧56287/57917）
- fixture-admin / fixture-password-123
- 合成内容账号甲 workflow-first：仅被读过；可供主控独立视觉链。
- 合成内容账号乙 workflow-second：已有合成资料、17方法结果、视频和审核包；可直接查看样式/结果。
- SERVER.json记录Native源码哈希；本机默认adapter不因此启用。
- native_fixture.py是Native agent测试脚本复制，数据与写入仅在本W/run-...；除排期合成模型引用补齐外无改动，不触生产目录/账号/平台。

建议最难视觉链：选择甲→资料与引用导入虚构原文→内容创作/视频脚本→准备后核对原引用→生成→采用→原编辑器添加视频配文并保存→修订原稿→采用→核对双字段→发布前人工勾选→导出审核内容包。再检查390px宽度下任务列表/原文长文本/表单和弹窗。

## 明确未验证与下一轮

本子agent未完成真实浏览器视觉/390px验收，由主控补；没有调用真实模型、平台评论/私信/发布。原保存丢失的prepare/apply/package恢复分支已实现，尚未单独做本轮事件故障注入；模型回执丢失链已实测。

root已派 integrated_fixture 修复100任务整理上限、过期依赖递归校验。当前UI未猜归档字段，待其给最小Native合同再增量补归档/历史操作，不重做17方法。
