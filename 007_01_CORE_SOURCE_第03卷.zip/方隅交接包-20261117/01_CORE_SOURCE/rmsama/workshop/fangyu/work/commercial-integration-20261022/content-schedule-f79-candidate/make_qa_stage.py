from pathlib import Path
import contextlib,importlib.util,json,sys
W=Path(__file__).resolve().parent;S=W/'source-candidate';N=S/'work/ui-native-r57'
sys.dont_write_bytecode=True
spec=importlib.util.spec_from_file_location('content_schedule_original_freezer',N/'freeze_ui.py')
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
with (W/'qa-stage.log').open('w',encoding='utf-8') as log,contextlib.redirect_stdout(log):module.main(['--stage'])
reports=sorted((N/'candidates').glob('*.json'),key=lambda p:p.stat().st_mtime_ns)
stage=json.loads(reports[-1].read_text('utf-8'));assert Path(stage['release']).is_relative_to(S)
(W/'QA-INPUTS.json').write_text(json.dumps({'label':'qa-local-content-schedule-f79-only','notFormalFrozenOrDistribution':True,
    'project':str(S),'stage':stage},ensure_ascii=False,indent=2)+'\n','utf-8')
print(json.dumps({'label':'qa-local-content-schedule-f79-only','release':stage['release_id'],'files':stage['files'],'manifest':stage['manifest_sha256']}))
