"""Relocatable standard Windows entry over the unchanged fixed r57 host.

This independently installed application initializes only its own empty data
directory. It grants no enterprise/device/platform permissions. Existing local
production binding and sessions are never consulted or copied.
"""
from pathlib import Path, PurePosixPath
import argparse, hashlib, http.client, importlib.util, importlib.machinery, json, os, socket, stat, sys
import threading
import time, uuid
sys.dont_write_bytecode = True
RELEASE_ID = 'ui-r57-20261023T095243Z-1c9a271f'
RELEASE_SHA = '7350cac18bc023a560ec3592b8d623ccc1213192c0a773c670dd7dab259b1f56'
CLOSURE_SHA = 'a1b6486649cafe9fac8cd15d4aaacdc0ffbe1aa5c5cda59f8c2e27aae9177f21'

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def exact(path, expected):
    for item in (path, *path.parents):
        info = item.lstat()
        if item.is_symlink() or getattr(info, 'st_file_attributes', 0) & 1024:
            raise RuntimeError('程序路径不能包含链接或重定向')
    before = path.stat()
    if not stat.S_ISREG(before.st_mode) or before.st_nlink != 1:
        raise RuntimeError('程序文件类型无效')
    raw = path.read_bytes()
    after = path.stat()
    if (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns) != (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns) or sha(raw) != expected:
        raise RuntimeError('程序文件校验失败')
    return raw

def output(value, path=None):
    raw = json.dumps(value, ensure_ascii=False, indent=2) + '\n'
    if path:
        with Path(path).open('x', encoding='utf-8') as stream:
            stream.write(raw)
    elif sys.stdout is not None:
        print(raw)

def load_host(root):
    project = root / 'project'
    closure = json.loads(exact(project / 'SHIPPED-PINS.json', CLOSURE_SHA))
    names = set()
    for row in closure['files']:
        relative = PurePosixPath(row['path'])
        if relative.is_absolute() or '..' in relative.parts or ':' in str(relative) or ('\\' in str(relative)) or (str(relative) in names):
            raise RuntimeError('程序清单路径无效')
        names.add(str(relative))
        raw = exact(project / relative, row['sha256'])
        if len(raw) != row['bytes']:
            raise RuntimeError('程序文件长度不匹配')
    actual = set()
    for path in project.rglob('*'):
        info = path.lstat()
        if path.is_symlink() or getattr(info, 'st_file_attributes', 0) & 1024:
            raise RuntimeError('程序目录包含未允许的链接或重定向')
        if '__pycache__' in path.relative_to(project).parts or path.suffix.lower() in ('.pyc', '.pyo'):
            raise RuntimeError('程序目录包含未允许的 Python 缓存代码')
        if path.is_file():
            actual.add(path.relative_to(project).as_posix())
    if actual != names | {'SHIPPED-PINS.json'}:
        raise RuntimeError('程序实际文件集合与完整清单不一致')
    code_pins = {row['path']: row for row in closure['files']}
    original_get_code = importlib.machinery.SourceFileLoader.get_code

    def source_only(loader, fullname):
        path = Path(loader.path).absolute()
        if path.is_relative_to(project):
            relative = path.relative_to(project).as_posix()
            row = code_pins.get(relative)
            if row is None or path.suffix.lower() != '.py':
                raise ImportError('未允许的程序代码来源')
            raw = exact(path, row['sha256'])
            return compile(raw, str(path), 'exec', dont_inherit=True, optimize=0)
        return original_get_code(loader, fullname)
    importlib.machinery.SourceFileLoader.get_code = source_only

    def code_audit(event, args):
        if event == 'open' and isinstance(args[0], (str, bytes, os.PathLike)):
            path = Path(os.fsdecode(args[0])).absolute()
            if path.is_relative_to(project) and path.suffix.lower() in ('.pyc', '.pyo'):
                raise PermissionError('程序不接受缓存字节码')
        if event == 'import' and len(args) > 1 and isinstance(args[1], str):
            path = Path(args[1]).absolute()
            if path.is_relative_to(project) and path.suffix.lower() in ('.pyd', '.dll', '.pyc', '.pyo'):
                row = code_pins.get(path.relative_to(project).as_posix())
                if row is None or path.suffix.lower() in ('.pyc', '.pyo'):
                    raise ImportError('未允许的扩展程序来源')
                exact(path, row['sha256'])
    sys.addaudithook(code_audit)
    release = project / 'work/ui-native-r57/releases' / RELEASE_ID
    raw = exact(release / 'RELEASE.json', RELEASE_SHA)
    manifest = json.loads(raw)
    entry = next((row for row in manifest['files'] if row['path'] == 'ui_native_host.py'))
    module = importlib.util.module_from_spec(importlib.util.spec_from_loader('fangyu_standard_native_host', loader=None))
    module.__file__ = str(release / 'ui_native_host.py')
    sys.modules[module.__name__] = module
    exec(compile(exact(release / 'ui_native_host.py', entry['sha256'].lower()), module.__file__, 'exec'), module.__dict__)
    return (module, project, release, closure)

def short_native_icon(release, state):
    """Keep .NET's legacy Icon file constructor below its path length limit."""
    manifest = json.loads(exact(release / 'RELEASE.json', RELEASE_SHA))
    row = next((item for item in manifest['files'] if item['path'] == 'resources/brand.ico'), None)
    if row is None:
        return
    source = release / 'resources/brand.ico'
    raw = exact(source, row['sha256'].lower())
    target = state / 'window.ico'
    if target.exists():
        exact(target, sha(raw))
    else:
        with target.open('xb') as stream:
            stream.write(raw)
        exact(target, sha(raw))
    if len(str(target)) >= 248:
        raise RuntimeError('Windows 用户资料路径过长，请使用标准用户资料目录')
    import webview
    original = webview.start

    def start(*args, **kwargs):
        if kwargs.get('icon') == str(source):
            kwargs['icon'] = str(target)
        return original(*args, **kwargs)
    webview.start = start

def own_directories():
    local = os.environ.get('LOCALAPPDATA')
    if not local or not Path(local).is_absolute():
        raise RuntimeError('Windows 用户资料目录不可用')
    root = Path(local) / 'FangyuWorkbenchStandard'
    for folder in (root, root / 'data', root / 'state'):
        folder.mkdir(parents=True, exist_ok=True)
        for item in (folder, *folder.parents):
            if item.is_symlink() or getattr(item.lstat(), 'st_file_attributes', 0) & 1024:
                raise RuntimeError('工作资料目录不能重定向')
    return (root / 'data', root / 'state')

def main():
    root = Path(sys.executable).resolve().parent if getattr(sys, 'frozen', False) else Path(__file__).resolve().parent
    parser = argparse.ArgumentParser(description='方隅工作台')
    group = parser.add_mutually_exclusive_group()
    group.add_argument('--check', action='store_true')
    group.add_argument('--self-test', action='store_true')
    parser.add_argument('--result-file')
    args = parser.parse_args()
    host, project, release, closure = load_host(root)
    data, state = own_directories()
    if args.check or args.self_test:
        argv = ['--check'] if args.check else ['--self-test']
        code = host.main(release, RELEASE_SHA, state, argv, project_root=project, data_dir=data)
        if code:
            raise RuntimeError('启动检查未通过')
        output({'status': 'PASS', 'releaseId': RELEASE_ID, 'frozen': getattr(sys, 'frozen', False) is True, 'internalStandardCandidate': True, 'commercialDistributionApproved': False, 'action': argv[0], 'closureFilesVerified': len(closure['files'])}, args.result_file)
        return 0
    short_native_icon(release, state)
    return host.main(release, RELEASE_SHA, state, [], project_root=project, data_dir=data)

"""All phase hashes/own delta operands were fixed before this QA EXE compiled."""
from pathlib import Path
import hashlib,importlib.util,json,os,sys,traceback,uuid
assert getattr(sys,'frozen',False) is True
SCENARIOS=[{'name': 'baseline_rebound', 'expected': 'accepted', 'releaseId': 'ui-r57-20261023T095243Z-1c9a271f', 'releaseSha256': '5234850e33c6657d7f4cde7ef2b55bd23b67489e718adc2754b04168a41b8de2', 'closureSha256': '6be23f6693fd842aa311e18c899d7c0f15897df8738bcede960b4518ec0b8453', 'files': [{'path': 'work/app/company.json', 'sha256': '60fa38e150de304b174ac21d1c8f078582d7b3d8bf802e5c603b63f3428233c3'}, {'path': 'HELD-STANDARD-MANIFEST.json', 'sha256': 'eb39256a93de96fbf14f237a324850c4283c28bc60ce5803f560f5ed9c41a7a2'}, {'path': 'work/shared-backend-integration/vendor-src/app.py', 'sha256': 'cec15333e9ed43d1f23698b99e9b238e1d28b4d7504ad9dfdaba830d132ac31d'}, {'path': 'work/shared-backend-integration/vendor-src/SOURCE.json', 'sha256': 'f0532f233d75905594ee34a079c94ee7da78d3359220c67982118ee2807e8f09'}, {'path': 'work/ui-native-r57/releases/ui-r57-20261023T095243Z-1c9a271f/resources/platform-runtime/vendor-src/app.py', 'sha256': 'cec15333e9ed43d1f23698b99e9b238e1d28b4d7504ad9dfdaba830d132ac31d'}, {'path': 'work/ui-native-r57/releases/ui-r57-20261023T095243Z-1c9a271f/resources/platform-runtime/vendor-src/SOURCE.json', 'sha256': '07360a330e92990e02866bc1238bd6124164ff64e3ff96463445ae48d6ad8884'}, {'path': 'work/ui-native-r57/releases/ui-r57-20261023T095243Z-1c9a271f/resources/platform-runtime/vendor-src/assistant/employee_distribution.py', 'sha256': 'a12dfb048cddcf9e8fb29f4eda2bc9b9ad96f20faa0b59a943e0ded33d53080e'}, {'path': 'work/ui-native-r57/releases/ui-r57-20261023T095243Z-1c9a271f/RELEASE.json', 'sha256': '5234850e33c6657d7f4cde7ef2b55bd23b67489e718adc2754b04168a41b8de2'}, {'path': 'SHIPPED-PINS.json', 'sha256': '6be23f6693fd842aa311e18c899d7c0f15897df8738bcede960b4518ec0b8453'}, {'path': 'work/ui-native-r57/releases/ui-r57-20261023T095243Z-1c9a271f/resources/customer-read/distribution-evidence.json', 'sha256': 'a99835f5cad99714cc3b4f88b20241dd61b50cc40cf20ded2dc2ad118487d124'}, {'path': 'work/ui-native-r57/releases/ui-r57-20261023T095243Z-1c9a271f/resources/customer-read/douyin_owned_connection.json', 'sha256': '38bc5f888567f4ed2978977a742d409bd9d7254583613d8a1a823c6a27bde5fb'}, {'path': 'work/ui-native-r57/releases/ui-r57-20261023T095243Z-1c9a271f/resources/customer-read/douyin_owned_video_comments.json', 'sha256': 'c5fcb289acc153e0587b8618e4ea8a3ad608ca9573f60cfdaa8d00250ee0b3db'}, {'path': 'work/ui-native-r57/releases/ui-r57-20261023T095243Z-1c9a271f/resources/customer-read/review-index.json', 'sha256': 'a33e846e9e58c73989686c75be1a877a362e1cd537b5dc42569700e90a7dd43a'}]}, {'name': 'company_old_material', 'expected': 'rejected', 'releaseId': 'ui-r57-20261023T095243Z-1c9a271f', 'releaseSha256': '51acaf56fb41998fbd5cc43d256041b7e8840d2a00046558854fdfa777b8203c', 'closureSha256': '01829b694942fe09c76fe2a0a92cf469097c8139b18314ff96512352b78325f2', 'files': [{'path': 'work/app/company.json', 'sha256': '80f1828b5ea5e245ef3eead58b0ca41e595a169ea1785e183a09b1d03055ab05'}, {'path': 'HELD-STANDARD-MANIFEST.json', 'sha256': '9f54e1ae3ed9fec9d87b85e54033a565e3685ebaf2e8109ec9ddf8ad74d6ad0c'}, {'path': 'work/shared-backend-integration/vendor-src/app.py', 'sha256': 'cec15333e9ed43d1f23698b99e9b238e1d28b4d7504ad9dfdaba830d132ac31d'}, {'path': 'work/shared-backend-integration/vendor-src/SOURCE.json', 'sha256': 'f0532f233d75905594ee34a079c94ee7da78d3359220c67982118ee2807e8f09'}, {'path': 'work/ui-native-r57/releases/ui-r57-20261023T095243Z-1c9a271f/resources/platform-runtime/vendor-src/app.py', 'sha256': 'cec15333e9ed43d1f23698b99e9b238e1d28b4d7504ad9dfdaba830d132ac31d'}, {'path': 'work/ui-native-r57/releases/ui-r57-20261023T095243Z-1c9a271f/resources/platform-runtime/vendor-src/SOURCE.json', 'sha256': '07360a330e92990e02866bc1238bd6124164ff64e3ff96463445ae48d6ad8884'}, {'path': 'work/ui-native-r57/releases/ui-r57-20261023T095243Z-1c9a271f/resources/platform-runtime/vendor-src/assistant/employee_distribution.py', 'sha256': 'f3282d7eab7b9f216668ce857e3a059dd910dff24cb9e29e6b87fe8a98a1c3fa'}, {'path': 'work/ui-native-r57/releases/ui-r57-20261023T095243Z-1c9a271f/RELEASE.json', 'sha256': '51acaf56fb41998fbd5cc43d256041b7e8840d2a00046558854fdfa777b8203c'}, {'path': 'SHIPPED-PINS.json', 'sha256': '01829b694942fe09c76fe2a0a92cf469097c8139b18314ff96512352b78325f2'}, {'path': 'work/ui-native-r57/releases/ui-r57-20261023T095243Z-1c9a271f/resources/customer-read/distribution-evidence.json', 'sha256': 'a99835f5cad99714cc3b4f88b20241dd61b50cc40cf20ded2dc2ad118487d124'}, {'path': 'work/ui-native-r57/releases/ui-r57-20261023T095243Z-1c9a271f/resources/customer-read/douyin_owned_connection.json', 'sha256': '38bc5f888567f4ed2978977a742d409bd9d7254583613d8a1a823c6a27bde5fb'}, {'path': 'work/ui-native-r57/releases/ui-r57-20261023T095243Z-1c9a271f/resources/customer-read/douyin_owned_video_comments.json', 'sha256': 'c5fcb289acc153e0587b8618e4ea8a3ad608ca9573f60cfdaa8d00250ee0b3db'}, {'path': 'work/ui-native-r57/releases/ui-r57-20261023T095243Z-1c9a271f/resources/customer-read/review-index.json', 'sha256': 'a33e846e9e58c73989686c75be1a877a362e1cd537b5dc42569700e90a7dd43a'}]}, {'name': 'company_rebound', 'expected': 'accepted', 'releaseId': 'ui-r57-20261023T095243Z-1c9a271f', 'releaseSha256': '6ae462967d200ff75ff4e09359a50ad53e0f1dab5b5218e58433fa013a270b9f', 'closureSha256': '708a7ae78546339f63d7768a287ef3ed092f93ca7a669363562aa6204ba5c6d7', 'files': [{'path': 'work/app/company.json', 'sha256': '80f1828b5ea5e245ef3eead58b0ca41e595a169ea1785e183a09b1d03055ab05'}, {'path': 'HELD-STANDARD-MANIFEST.json', 'sha256': '9f54e1ae3ed9fec9d87b85e54033a565e3685ebaf2e8109ec9ddf8ad74d6ad0c'}, {'path': 'work/shared-backend-integration/vendor-src/app.py', 'sha256': 'cec15333e9ed43d1f23698b99e9b238e1d28b4d7504ad9dfdaba830d132ac31d'}, {'path': 'work/shared-backend-integration/vendor-src/SOURCE.json', 'sha256': 'f0532f233d75905594ee34a079c94ee7da78d3359220c67982118ee2807e8f09'}, {'path': 'work/ui-native-r57/releases/ui-r57-20261023T095243Z-1c9a271f/resources/platform-runtime/vendor-src/app.py', 'sha256': 'cec15333e9ed43d1f23698b99e9b238e1d28b4d7504ad9dfdaba830d132ac31d'}, {'path': 'work/ui-native-r57/releases/ui-r57-20261023T095243Z-1c9a271f/resources/platform-runtime/vendor-src/SOURCE.json', 'sha256': '07360a330e92990e02866bc1238bd6124164ff64e3ff96463445ae48d6ad8884'}, {'path': 'work/ui-native-r57/releases/ui-r57-20261023T095243Z-1c9a271f/resources/platform-runtime/vendor-src/assistant/employee_distribution.py', 'sha256': 'f3282d7eab7b9f216668ce857e3a059dd910dff24cb9e29e6b87fe8a98a1c3fa'}, {'path': 'work/ui-native-r57/releases/ui-r57-20261023T095243Z-1c9a271f/RELEASE.json', 'sha256': '6ae462967d200ff75ff4e09359a50ad53e0f1dab5b5218e58433fa013a270b9f'}, {'path': 'SHIPPED-PINS.json', 'sha256': '708a7ae78546339f63d7768a287ef3ed092f93ca7a669363562aa6204ba5c6d7'}, {'path': 'work/ui-native-r57/releases/ui-r57-20261023T095243Z-1c9a271f/resources/customer-read/distribution-evidence.json', 'sha256': '550d1ed3cf585a36f055db21b76b168d69f7cc47a3587b1691200fd48615a8eb'}, {'path': 'work/ui-native-r57/releases/ui-r57-20261023T095243Z-1c9a271f/resources/customer-read/douyin_owned_connection.json', 'sha256': 'f5b2bdcf63e997e400e773a2ee7e4c19006f0834c43be105f50fa96e817fcbb3'}, {'path': 'work/ui-native-r57/releases/ui-r57-20261023T095243Z-1c9a271f/resources/customer-read/douyin_owned_video_comments.json', 'sha256': 'b158c55509520d5f90724833d7996b0032bac503c951e9e8fe210d68836cfcda'}, {'path': 'work/ui-native-r57/releases/ui-r57-20261023T095243Z-1c9a271f/resources/customer-read/review-index.json', 'sha256': 'a3bea8ccdc0183a26bd55b28390e8b3fc719909c12344540fb46b2e3dbb6392b'}]}, {'name': 'vendor_old_material', 'expected': 'rejected', 'releaseId': 'ui-r57-20261023T095243Z-1c9a271f', 'releaseSha256': 'f5bfd7d3b271b4868240e0b3e8d81370d6aeaca33eaad6074eed00e012c6a693', 'closureSha256': 'c302db79cd47db9f2609d62d1571c54fdbc119b11045ac4b41b72a57da55d42e', 'files': [{'path': 'work/app/company.json', 'sha256': '80f1828b5ea5e245ef3eead58b0ca41e595a169ea1785e183a09b1d03055ab05'}, {'path': 'HELD-STANDARD-MANIFEST.json', 'sha256': '03fd6618d64003111821bb8c5a8f06a44c40deda2447230150617ad888c79069'}, {'path': 'work/shared-backend-integration/vendor-src/app.py', 'sha256': '847dd048a4ca8df26ffbc85a0708186dbea15c1d34ded42449bfe2021d30617b'}, {'path': 'work/shared-backend-integration/vendor-src/SOURCE.json', 'sha256': '2b49908f83e7a3545a55d2f9c217477e4e1ceaaa5521eade4fcf75dfc992dfee'}, {'path': 'work/ui-native-r57/releases/ui-r57-20261023T095243Z-1c9a271f/resources/platform-runtime/vendor-src/app.py', 'sha256': '847dd048a4ca8df26ffbc85a0708186dbea15c1d34ded42449bfe2021d30617b'}, {'path': 'work/ui-native-r57/releases/ui-r57-20261023T095243Z-1c9a271f/resources/platform-runtime/vendor-src/SOURCE.json', 'sha256': '752ec3aa6550b06d62f999a71754878a94af9b7c6fc6881c66b6052ffbd9f035'}, {'path': 'work/ui-native-r57/releases/ui-r57-20261023T095243Z-1c9a271f/resources/platform-runtime/vendor-src/assistant/employee_distribution.py', 'sha256': '142cc318fb66e984a092ad3b94225458ca215c8bbd7f6f60c53ef0f289f28a96'}, {'path': 'work/ui-native-r57/releases/ui-r57-20261023T095243Z-1c9a271f/RELEASE.json', 'sha256': 'f5bfd7d3b271b4868240e0b3e8d81370d6aeaca33eaad6074eed00e012c6a693'}, {'path': 'SHIPPED-PINS.json', 'sha256': 'c302db79cd47db9f2609d62d1571c54fdbc119b11045ac4b41b72a57da55d42e'}, {'path': 'work/ui-native-r57/releases/ui-r57-20261023T095243Z-1c9a271f/resources/customer-read/distribution-evidence.json', 'sha256': '550d1ed3cf585a36f055db21b76b168d69f7cc47a3587b1691200fd48615a8eb'}, {'path': 'work/ui-native-r57/releases/ui-r57-20261023T095243Z-1c9a271f/resources/customer-read/douyin_owned_connection.json', 'sha256': 'f5b2bdcf63e997e400e773a2ee7e4c19006f0834c43be105f50fa96e817fcbb3'}, {'path': 'work/ui-native-r57/releases/ui-r57-20261023T095243Z-1c9a271f/resources/customer-read/douyin_owned_video_comments.json', 'sha256': 'b158c55509520d5f90724833d7996b0032bac503c951e9e8fe210d68836cfcda'}, {'path': 'work/ui-native-r57/releases/ui-r57-20261023T095243Z-1c9a271f/resources/customer-read/review-index.json', 'sha256': 'a3bea8ccdc0183a26bd55b28390e8b3fc719909c12344540fb46b2e3dbb6392b'}]}, {'name': 'vendor_rebound', 'expected': 'accepted', 'releaseId': 'ui-r57-20261023T095243Z-1c9a271f', 'releaseSha256': '7aea7b5d51e8adaeb59236ef340d719a7c7afdfbf4a60900898c677116db9468', 'closureSha256': '969a9ac87e05a50a861d0ebc2330f5acc33211a4204a0463440df0d8a6092fb9', 'files': [{'path': 'work/app/company.json', 'sha256': '80f1828b5ea5e245ef3eead58b0ca41e595a169ea1785e183a09b1d03055ab05'}, {'path': 'HELD-STANDARD-MANIFEST.json', 'sha256': '03fd6618d64003111821bb8c5a8f06a44c40deda2447230150617ad888c79069'}, {'path': 'work/shared-backend-integration/vendor-src/app.py', 'sha256': '847dd048a4ca8df26ffbc85a0708186dbea15c1d34ded42449bfe2021d30617b'}, {'path': 'work/shared-backend-integration/vendor-src/SOURCE.json', 'sha256': '2b49908f83e7a3545a55d2f9c217477e4e1ceaaa5521eade4fcf75dfc992dfee'}, {'path': 'work/ui-native-r57/releases/ui-r57-20261023T095243Z-1c9a271f/resources/platform-runtime/vendor-src/app.py', 'sha256': '847dd048a4ca8df26ffbc85a0708186dbea15c1d34ded42449bfe2021d30617b'}, {'path': 'work/ui-native-r57/releases/ui-r57-20261023T095243Z-1c9a271f/resources/platform-runtime/vendor-src/SOURCE.json', 'sha256': '752ec3aa6550b06d62f999a71754878a94af9b7c6fc6881c66b6052ffbd9f035'}, {'path': 'work/ui-native-r57/releases/ui-r57-20261023T095243Z-1c9a271f/resources/platform-runtime/vendor-src/assistant/employee_distribution.py', 'sha256': '142cc318fb66e984a092ad3b94225458ca215c8bbd7f6f60c53ef0f289f28a96'}, {'path': 'work/ui-native-r57/releases/ui-r57-20261023T095243Z-1c9a271f/RELEASE.json', 'sha256': '7aea7b5d51e8adaeb59236ef340d719a7c7afdfbf4a60900898c677116db9468'}, {'path': 'SHIPPED-PINS.json', 'sha256': '969a9ac87e05a50a861d0ebc2330f5acc33211a4204a0463440df0d8a6092fb9'}, {'path': 'work/ui-native-r57/releases/ui-r57-20261023T095243Z-1c9a271f/resources/customer-read/distribution-evidence.json', 'sha256': '861c4178d9abe3d0ded01aefe521fc67948868a83f674d7b70216473e41e5f03'}, {'path': 'work/ui-native-r57/releases/ui-r57-20261023T095243Z-1c9a271f/resources/customer-read/douyin_owned_connection.json', 'sha256': 'ca43af1a002a849ad351cb7da92a449e845be1bd05b35db221987f659174f8e8'}, {'path': 'work/ui-native-r57/releases/ui-r57-20261023T095243Z-1c9a271f/resources/customer-read/douyin_owned_video_comments.json', 'sha256': '79d5315c5b1e65d4e73f36f31bbe092097716a5518eb437b602c9ee101dd5245'}, {'path': 'work/ui-native-r57/releases/ui-r57-20261023T095243Z-1c9a271f/resources/customer-read/review-index.json', 'sha256': '1dddb354db5d9e14a34e5e25c441c0da4500d4f3e772f502668bc5e0bac47624'}]}, {'name': 'helper_old_material', 'expected': 'rejected', 'releaseId': 'ui-r57-20261023T095243Z-1c9a271f', 'releaseSha256': 'a0bb0770fd9f1678fd0bf7dcac6d09932a4a0bb8b97b8039053c59993b30e419', 'closureSha256': '6d24c512d2ee92c521ebe0a46e88646c16fc45de2c82ecda3885aa8c371da71e', 'files': [{'path': 'work/app/company.json', 'sha256': '80f1828b5ea5e245ef3eead58b0ca41e595a169ea1785e183a09b1d03055ab05'}, {'path': 'HELD-STANDARD-MANIFEST.json', 'sha256': '03fd6618d64003111821bb8c5a8f06a44c40deda2447230150617ad888c79069'}, {'path': 'work/shared-backend-integration/vendor-src/app.py', 'sha256': '847dd048a4ca8df26ffbc85a0708186dbea15c1d34ded42449bfe2021d30617b'}, {'path': 'work/shared-backend-integration/vendor-src/SOURCE.json', 'sha256': '2b49908f83e7a3545a55d2f9c217477e4e1ceaaa5521eade4fcf75dfc992dfee'}, {'path': 'work/ui-native-r57/releases/ui-r57-20261023T095243Z-1c9a271f/resources/platform-runtime/vendor-src/app.py', 'sha256': '847dd048a4ca8df26ffbc85a0708186dbea15c1d34ded42449bfe2021d30617b'}, {'path': 'work/ui-native-r57/releases/ui-r57-20261023T095243Z-1c9a271f/resources/platform-runtime/vendor-src/SOURCE.json', 'sha256': '752ec3aa6550b06d62f999a71754878a94af9b7c6fc6881c66b6052ffbd9f035'}, {'path': 'work/ui-native-r57/releases/ui-r57-20261023T095243Z-1c9a271f/resources/platform-runtime/vendor-src/assistant/employee_distribution.py', 'sha256': 'a962ba5be9b69b8a09441527c317159c918677e81d8f4be48c4e6e6165b8f016'}, {'path': 'work/ui-native-r57/releases/ui-r57-20261023T095243Z-1c9a271f/RELEASE.json', 'sha256': 'a0bb0770fd9f1678fd0bf7dcac6d09932a4a0bb8b97b8039053c59993b30e419'}, {'path': 'SHIPPED-PINS.json', 'sha256': '6d24c512d2ee92c521ebe0a46e88646c16fc45de2c82ecda3885aa8c371da71e'}, {'path': 'work/ui-native-r57/releases/ui-r57-20261023T095243Z-1c9a271f/resources/customer-read/distribution-evidence.json', 'sha256': '861c4178d9abe3d0ded01aefe521fc67948868a83f674d7b70216473e41e5f03'}, {'path': 'work/ui-native-r57/releases/ui-r57-20261023T095243Z-1c9a271f/resources/customer-read/douyin_owned_connection.json', 'sha256': 'ca43af1a002a849ad351cb7da92a449e845be1bd05b35db221987f659174f8e8'}, {'path': 'work/ui-native-r57/releases/ui-r57-20261023T095243Z-1c9a271f/resources/customer-read/douyin_owned_video_comments.json', 'sha256': '79d5315c5b1e65d4e73f36f31bbe092097716a5518eb437b602c9ee101dd5245'}, {'path': 'work/ui-native-r57/releases/ui-r57-20261023T095243Z-1c9a271f/resources/customer-read/review-index.json', 'sha256': '1dddb354db5d9e14a34e5e25c441c0da4500d4f3e772f502668bc5e0bac47624'}]}, {'name': 'helper_rebound', 'expected': 'accepted', 'releaseId': 'ui-r57-20261023T095243Z-1c9a271f', 'releaseSha256': 'c7bfc59643fd1b011c1fb21c4423423da6f6844b3265839554e79df912dca1ae', 'closureSha256': '24feb13c85c18e5f0ae459df09f18c3e0db81e38b01869d56f70a4574e0de6ed', 'files': [{'path': 'work/app/company.json', 'sha256': '80f1828b5ea5e245ef3eead58b0ca41e595a169ea1785e183a09b1d03055ab05'}, {'path': 'HELD-STANDARD-MANIFEST.json', 'sha256': '03fd6618d64003111821bb8c5a8f06a44c40deda2447230150617ad888c79069'}, {'path': 'work/shared-backend-integration/vendor-src/app.py', 'sha256': '847dd048a4ca8df26ffbc85a0708186dbea15c1d34ded42449bfe2021d30617b'}, {'path': 'work/shared-backend-integration/vendor-src/SOURCE.json', 'sha256': '2b49908f83e7a3545a55d2f9c217477e4e1ceaaa5521eade4fcf75dfc992dfee'}, {'path': 'work/ui-native-r57/releases/ui-r57-20261023T095243Z-1c9a271f/resources/platform-runtime/vendor-src/app.py', 'sha256': '847dd048a4ca8df26ffbc85a0708186dbea15c1d34ded42449bfe2021d30617b'}, {'path': 'work/ui-native-r57/releases/ui-r57-20261023T095243Z-1c9a271f/resources/platform-runtime/vendor-src/SOURCE.json', 'sha256': '752ec3aa6550b06d62f999a71754878a94af9b7c6fc6881c66b6052ffbd9f035'}, {'path': 'work/ui-native-r57/releases/ui-r57-20261023T095243Z-1c9a271f/resources/platform-runtime/vendor-src/assistant/employee_distribution.py', 'sha256': 'a962ba5be9b69b8a09441527c317159c918677e81d8f4be48c4e6e6165b8f016'}, {'path': 'work/ui-native-r57/releases/ui-r57-20261023T095243Z-1c9a271f/RELEASE.json', 'sha256': 'c7bfc59643fd1b011c1fb21c4423423da6f6844b3265839554e79df912dca1ae'}, {'path': 'SHIPPED-PINS.json', 'sha256': '24feb13c85c18e5f0ae459df09f18c3e0db81e38b01869d56f70a4574e0de6ed'}, {'path': 'work/ui-native-r57/releases/ui-r57-20261023T095243Z-1c9a271f/resources/customer-read/distribution-evidence.json', 'sha256': 'd3c15ef3f3bd9388175556d7be74e754866b2eae589fd4099d6268e9a9ce9da7'}, {'path': 'work/ui-native-r57/releases/ui-r57-20261023T095243Z-1c9a271f/resources/customer-read/douyin_owned_connection.json', 'sha256': '370c9bb77a9bd6c9fc81a97aadc3d2c101ed71213947f4e00e11a77c632d476e'}, {'path': 'work/ui-native-r57/releases/ui-r57-20261023T095243Z-1c9a271f/resources/customer-read/douyin_owned_video_comments.json', 'sha256': 'eef359dff211d0d07fe3bc3e91fd3d7146476b5e4fea5c8b289088b6a6a50ed5'}, {'path': 'work/ui-native-r57/releases/ui-r57-20261023T095243Z-1c9a271f/resources/customer-read/review-index.json', 'sha256': 'e1bfdabb83ff3c175a050fef5cbf7f3a14238168aa630253c3fbebe829a49414'}]}]
W=Path(sys.executable).resolve().parent;project=W/'project';name=sys.argv[sys.argv.index('--case')+1]
case=next(c for c in SCENARIOS if c['name']==name);out=W/('case-'+name+'-'+uuid.uuid4().hex);out.mkdir();backend=None;passed=False
# Trusted QA-only file transition, exact operands fixed inside this EXE, never
# an HTTP/body-selected scope or manifest.  No new pin is calculated at runtime.
for row in case['files']:
 source=W/'qa-scenarios'/name/row['path'];raw=source.read_bytes();assert hashlib.sha256(raw).hexdigest()==row['sha256'];(project/row['path']).write_bytes(raw)
RELEASE_ID=case['releaseId'];RELEASE_SHA=case['releaseSha256'];CLOSURE_SHA=case['closureSha256']
def audit(event,args):
 if event in ('subprocess.Popen','os.system','os.startfile','os.posix_spawn'):raise RuntimeError('No browser/process')
 if event in ('socket.connect','socket.bind') and (not isinstance(args[1],tuple) or args[1][0] not in ('127.0.0.1','::1')):raise RuntimeError('No external network')
 if event=='socket.getaddrinfo' and args[0] not in ('127.0.0.1','::1','localhost',None):raise RuntimeError('No DNS')
 if event=='sqlite3.connect' and not Path(args[0]).resolve().is_relative_to(out):raise RuntimeError('Own DB only')
sys.addaudithook(audit)
result={'case':name,'expected':case['expected'],'actualCompiled':True,'outerPinsEmbeddedBeforeCompilation':True,'realCloudPlatformModel':0,'servicesClosed':False}
try:
 host,project,release,closure=load_host(W)
 _,files=host.verify_release(release,RELEASE_SHA);host.verify_backend_dependencies(release,files,project)
 company=json.loads((project/'work/app/company.json').read_bytes())
 backend=host.create_backend(release,files,project_root=project,data_dir=out/'data',company=company)
 runtime=backend.platform_runtime;app=runtime.server;app._configure_bundled();runtime._platform_setup=True
 from assistant.douyin_connection_service import _components
 from core.douyin_comments_policy import DouyinCommentsPolicy
 try:connection=_components(app)
 except ValueError as e:connection=None;result['connectionError']=str(e)
 comment=DouyinCommentsPolicy(app).resolve();result.update({'scope':app._runtime_license_usage_scope(),'connection':connection,'comment':comment,'closureFiles':len(closure['files'])})
 if case['expected']=='accepted':assert len(connection)==64 and comment['purpose']=='douyin_owned_video_comments' and result['scope']=='customer_distribution_read'
 else:assert connection is None and comment is None
 assert app.company['runtime']['public_send_hold'] is True and app.company['runtime']['release_approved'] is False
 assert app._customer_read_authority.runtime_license_review(app,'xiaohongshu_guarded_read') is None
 passed=True
finally:
 if sys.exc_info()[0]:result['error']=traceback.format_exc()
 if backend:backend.close()
 result.update(status='PASS' if passed else 'RED',servicesClosed=True)
 (out/'RESULTS.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n','utf-8')
 print(json.dumps({'status':result['status'],'case':name,'out':str(out)},ensure_ascii=False))
