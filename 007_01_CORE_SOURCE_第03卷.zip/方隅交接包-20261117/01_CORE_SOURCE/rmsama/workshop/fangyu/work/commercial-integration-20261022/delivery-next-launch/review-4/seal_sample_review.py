from pathlib import Path
import argparse,difflib,hashlib,json
HERE=Path(__file__).resolve().parent
P=HERE.parents[3]
BASE=P/'work/parallel-integration-20261018/final-integration/candidate-unified-v71'
def sha(raw):return hashlib.sha256(raw).hexdigest()
def main():
    parser=argparse.ArgumentParser();parser.add_argument('--native',action='store_true');parser.add_argument('--secured-native',action='store_true')
    parser.add_argument('--qa2',action='store_true')
    parser.add_argument('--version',type=int,choices=(71,72),default=71);parser.add_argument('--clean',action='store_true');options=parser.parse_args()
    source_base=P/('work/parallel-integration-20261018/final-integration/candidate-unified-v'+str(options.version))
    suffix='-qa2' if options.qa2 else '-secured-native' if options.secured_native else '-native' if options.native else ''
    sample=HERE/(('standard-held-clean-v' if options.clean else 'standard-held-sample-v')+str(options.version)+('' if options.clean else suffix))
    project=sample/'payload/project'
    source=json.loads((source_base/'UNIFIED-PINS.json').read_text('utf-8'))
    shipped=json.loads((project/'SHIPPED-PINS.json').read_text('utf-8'))
    before={r['path']:r for r in source['files']};after={r['path']:r for r in shipped['files']}
    changed=[];patch=[]
    for relative,row in sorted(after.items()):
        raw=(project/relative).read_bytes()
        if sha(raw)!=row['sha256'] or len(raw)!=row['bytes']:raise RuntimeError('Shipped input changed')
        if relative in before and before[relative]['sha256']!=row['sha256']:
            original=(source_base/'project'/relative).read_bytes()
            changed.append({'path':relative,'sourceSha256':sha(original),'derivedSha256':sha(raw),'sourceBytes':len(original),'derivedBytes':len(raw)})
            if Path(relative).suffix in ('.json','.py'):
                patch.extend(difflib.unified_diff(original.decode('utf-8-sig').replace('\r\n','\n').splitlines(True),raw.decode('utf-8-sig').replace('\r\n','\n').splitlines(True),fromfile='source-v'+str(options.version)+'/'+relative,tofile='held-standard/'+relative))
    built=json.loads((sample/'BUILD.json').read_text('utf-8'))
    result={'status':'FIXED_FOR_INDEPENDENT_READONLY_REVIEW_INTERNAL_CANDIDATE','sample':sample.name,
        'sourceCandidate':'candidate-unified-v'+str(options.version),'sourceClosureSha256':sha((source_base/'UNIFIED-PINS.json').read_bytes()),
        'sourceFiles':len(before),'shippedFiles':len(after),'changedExistingFiles':changed,
        'omittedLocalInstallationDescriptors':sorted(set(before)-set(after)),
        'addedFiles':[{'path':name,'sha256':after[name]['sha256'],'bytes':after[name]['bytes']} for name in sorted(set(after)-set(before))],
        'pins':{name:sha((sample/name).read_bytes()) for name in ('standard_entry.py','STAGE.json','BUILD.json','FILE-MANIFEST.json')},
        'projectPins':{name:sha((project/name).read_bytes()) for name in ('SHIPPED-PINS.json','HELD-STANDARD-MANIFEST.json')},
        'nativeManifestSha256':sha(next((project/'work/ui-native-r57/releases').glob('*/RELEASE.json')).read_bytes()),
        'compiledEntrySha256':sha((sample/'dist/FangyuWorkbench/FangyuWorkbench.exe').read_bytes()),
        'installerSourceSha256':sha((sample/'installer.original.py').read_bytes()),
        'portableZip':built['portableZip'],'portableZipSha256':built['portableSha256'],
        'installer':built['installer'],'installerSha256':built['installerSha256'],
        'buildAndArchiveStoppedWriting':True,'qaEvidenceMutationsRestrictedToOwnExtractedCopy':True,
        'S_F_N_ProductionModified':False,'releaseApproved':False,'automation':'hold','publicSendHold':True,
        'commercialDistributionApproved':False,'nativeStartEvidencePending':not options.native}
    for name,value in (('SOURCE-DERIVED-PINS.json',json.dumps(result,ensure_ascii=False,indent=2)+'\n'),('SOURCE-DERIVED-DIFF.patch',''.join(patch))):
        with (sample/name).open('x',encoding='utf-8') as stream:stream.write(value)
    print(json.dumps({'sample':sample.name,'changed':len(changed),'added':len(set(after)-set(before)),'omitted':len(set(before)-set(after)),'fixed':True},ensure_ascii=True))
if __name__=='__main__':main()
