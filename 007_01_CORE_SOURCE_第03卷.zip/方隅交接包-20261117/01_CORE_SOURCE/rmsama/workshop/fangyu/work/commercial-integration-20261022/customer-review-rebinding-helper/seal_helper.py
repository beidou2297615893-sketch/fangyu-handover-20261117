from pathlib import Path
import ast,datetime,difflib,hashlib,json,subprocess
W=Path(__file__).resolve().parent;A=W.parent/'customer-read-purpose-after-f82-candidate';I=W.parent/'customer-read-purpose-after-f82-independent-review';B=W/'own-compiled';D=B/'dist/FangyuWorkbench'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(Path(p).read_text('utf-8-sig'))
write=lambda n,v:(W/n).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n','utf-8')
cfg=read(W/'INPUTS.json')
for p,pin in cfg['authorAndIndependentFixed'].items():assert sha(p)==pin
source=read(A/'SOURCE-FILES.json')
for r in source['files']:assert sha(A/'source-candidate'/r['path'])==r['sha256']
result=read(W/'CASE-RESULTS.json');assert result['status']=='PASS' and result['actualCompiledCases']==7 and result['compileCount']==1
assert all(c['exitCode']==0 and c['result']['servicesClosed'] and c['result']['actualCompiled'] for c in result['cases'])
assert read(W/'HELPER-UNIT.json')['status']=='PASS'
project=D/'project';shipped=read(project/'SHIPPED-PINS.json')
for r in shipped['files']:
 p=project/r['path'];assert sha(p)==r['sha256'] and p.stat().st_size==r['bytes']
rebounds=read(W/'REBIND-RESULTS.json')
for r in rebounds:
 assert len(r['files'])==4 and r['releaseAndShippedNotWritten'] and r['mainExeShaNotEmbedded']
 for p,pin in r['internalReviewsUnchanged'].items():assert sha(p)==pin
cleanup=read(W/'JUNCTION-CLEANUP-ADDENDUM.json');assert cleanup['linkRemoved'] and cleanup['targetAndSentinelUnchanged']
assert not Path(cleanup['link']).exists() and sha(Path(cleanup['target'])/'sentinel.txt')==cleanup['sentinelSha256']
proc_cmd="$r=@(Get-CimInstance Win32_Process | Where-Object { $_.CommandLine -and $_.CommandLine.Contains('customer-review-rebinding-helper') -and !$_.CommandLine.Contains('seal_helper.py') -and $_.Name -in @('python.exe','node.exe','FangyuWorkbench.exe') } | Select-Object ProcessId,ParentProcessId,Name); ConvertTo-Json -InputObject $r -Compress"
processes=json.loads(subprocess.run(['powershell.exe','-NoProfile','-Command',proc_cmd],capture_output=True,text=True,check=True).stdout or '[]');assert processes==[]
write('PROCESS-STATUS.json',{'ownProcesses':processes,'allSevenActualExeCasesExited0':True,'servicesClosed':True,'junctionSafelyRemoved':True,'oldSealedReceiptsUnchanged':True})
helper=W/'customer_review_rebinder.py';ast.parse(helper.read_bytes());raw=helper.read_bytes()
(W/'CHANGES.patch').write_bytes(''.join(difflib.unified_diff([],raw.decode().splitlines(True),fromfile='/dev/null',tofile='b/customer_review_rebinder.py')).encode())
write('SOURCE-FILES.json',{'newToolSourceOnly':True,'files':[{'path':'customer_review_rebinder.py','beforeSha256':None,'sha256':sha(helper),'bytes':len(raw)}],'noProductSourceEdited':True,'noNewDependencies':True})
write('DERIVATION.json',{'authorFinalSha256':cfg['authorAndIndependentFixed'][str(A/'FINAL-RECEIPT.json')],'authorSourceManifestSha256':cfg['authorAndIndependentFixed'][str(A/'SOURCE-FILES.json')],'authorPrepareProbeSha256':sha(A/'prepare_probe.py'),'independentFinalSha256':cfg['authorAndIndependentFixed'][str(I/'FINAL-RECEIPT.json')],'source':'Mature material-generation block extracted; fixed company contract, exact two purpose adapters, held stability verification added','mitRuntimeLicenseSha256':'3723b8dae8c5e727627eb68f8dbcd46def7132a18bf50427f689d9cd41d3f9da','noUpstreamDownloadOrNewLicense':True})
files=['customer_review_rebinder.py','README.md','SOURCE-FILES.json','CHANGES.patch','DERIVATION.json','INPUTS.json','FIRST-REBIND.json','HELPER-UNIT.json','FIXTURE-AST-BOUNDARY.json','SCENARIOS.json','REBIND-RESULTS.json','CASE-RESULTS.json','PROCESS-STATUS.json','JUNCTION-CLEANUP-ADDENDUM.json','cleanup_own_junction.py','prepare_fixture.py','prepare_cases.py','factory_cases_body.py.in','run_cases.py','seal_helper.py','prepare.log','cases-prepare.log','cases-run.log','build_probe.py']
paths=[W/p for p in files]+[B/'BUILD-RECEIPT.json',B/'BUILD.log',B/'probe_entry.py']
paths.extend(W/c['evidence'] for c in result['cases']);paths.extend(B.glob('run-*.log'))
write('EVIDENCE-PINS.json',{'files':[{'path':str(p.relative_to(W)).replace('\\','/'),'sha256':sha(p),'bytes':p.stat().st_size} for p in paths]})
receipt={'status':'SEALED_LOCAL_REBIND_HELPER_AND_COMPILED_FACTORY_TEST_PASS','callable':'rebind_customer_reviews(project, release, evidence_reference, reviewed_at)','source':'customer_review_rebinder.py','sourceSha256':sha(helper),'sourceManifestSha256':sha(W/'SOURCE-FILES.json'),'patchSha256':sha(W/'CHANGES.patch'),'dependencyDerivationSha256':sha(W/'DERIVATION.json'),'onlyFourCustomerJsonWritten':True,'originalInternalReviewsAndCompanyHelperReleaseShippedNotWrittenByFunction':True,'originalBuilderStillOwnsHeldHelperReleaseShipped':True,'unknownPurposeOrChangedCarrierContractRejectedBeforeWrite':True,'heldMustAlreadyBeStable':True,'mainExeShaNotEmbedded':True,'preserved':{'purposeCount':2,'purposeLimits':True,'evidenceFalse':True,'publicSendHold':True,'releaseApprovedFalse':True,'noQaPortableOrEmployeeDeviceGrant':True},'validation':{'helperPureChecks':4,'actualCompiledFactoryCases':7,'baselineCases':1,'oldRejectToReboundAcceptPairs':3,'pairs':['company releaseVersion','active and canonical vendor bytes (comment only)','stable held compatibility helper bytes (comment only)'],'compileCount':1,'allScenarioClosuresEmbeddedBeforeCompile':True,'originalLoadHostVerifyDepsFactoryInEveryCase':True,'sourceLogicChangesForFixtures':'app AST exact; held helper only derived manifest pin, remaining byte change comment','factoryLayer':'component material resolution; device chain referenced fixed preceding independent review, not re-executed here','caseEvidence':'CASE-RESULTS.json','finalProjectClosureFiles':len(shipped['files']),'allFinalProjectBytesRechecked':True},'actualCloudPlatformModelNativeCalls':0,'canonicalSourceFrozenInstalledOutputsProductionWrites':0,'allOwnServicesClosed':True,'junctionCleanup':{'appendReceipt':'JUNCTION-CLEANUP-ADDENDUM.json','priorStatedReasonOnly':'blocked by policy','safeReplacement':'os.rmdir verified junction only','targetUntouched':True,'oldSealedEvidenceNotEdited':True},'limitations':['Only reviewed two Douyin purposes; XHS and DYsearch need explicitly reviewed adapter before this tool can accept those slots.','Material binding is not source/license approval, employee enrollment, native/platform authorization or commercial release approval.','Function is index-last/fail-closed, not four-file database transaction; use caller original candidate backup/rebuild workflow.','Formal aggregate must regenerate its own held/helper first, then these four files, then original RELEASE/SHIPPED and actual aggregate factory.'],'evidencePinsSha256':sha(W/'EVIDENCE-PINS.json'),'wholeGoalComplete':False}
write('FINAL-RECEIPT.json',receipt)
write('SEALED.json',{'status':'SEALED_STOP_WRITING','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'finalReceiptSha256':sha(W/'FINAL-RECEIPT.json'),'toolSourceSha256':sha(helper),'evidencePinsSha256':sha(W/'EVIDENCE-PINS.json'),'allOwnServicesClosed':True,'onlyDeliverableSource':'customer_review_rebinder.py','notReleaseApproval':True})
print(json.dumps({p:sha(W/p) for p in ['FINAL-RECEIPT.json','SEALED.json','customer_review_rebinder.py','SOURCE-FILES.json','JUNCTION-CLEANUP-ADDENDUM.json']},ensure_ascii=False))
