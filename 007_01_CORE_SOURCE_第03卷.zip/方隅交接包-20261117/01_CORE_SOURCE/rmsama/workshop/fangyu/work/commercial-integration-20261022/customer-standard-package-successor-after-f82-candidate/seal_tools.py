from pathlib import Path
import ast,difflib,hashlib,json
C=Path(__file__).resolve().parent;W=C.parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,v):
 with p.open('x',encoding='utf8') as f:json.dump(v,f,ensure_ascii=False,indent=2);f.write('\n')
before=(W/'f82-standard-package-candidate/build_clean_next.py').read_text('utf8');after=(C/'build_clean_next.py').read_text('utf8')
funcs=lambda text:{n.name:ast.dump(n,include_attributes=False) for n in ast.parse(text).body if isinstance(n,ast.FunctionDef)}
b,a=funcs(before),funcs(after);same={n:a.get(n)==body for n,body in b.items()};assert {n for n,equal in same.items() if not equal}=={'stage','build','main'}
(C/'BUILDER-DIFF.patch').write_text(''.join(difflib.unified_diff(before.splitlines(keepends=True),after.splitlines(keepends=True),fromfile='a/f82/build_clean_next.py',tofile='b/successor/build_clean_next.py',n=3)),'utf8')
original=json.loads((C/'DERIVATION.json').read_bytes());final={**original,'derivedBuilderSha256':sha(C/'build_clean_next.py'),'originalFunctionAstIdentical':same,'naturalHelperInputCorrection':'source-v66-worker/component/artifacts, never r55/src; no new sibling','protectedInstallerSourceUnmodified':True}
write(C/'DERIVATION-FINAL.json',final)
result=C/'tool-fixture-46b12d04e7ad4e858b57ed22fd00ea96/RESULTS.json';tests=json.loads(result.read_bytes());assert len(tests['groups'])==6 and all(r.get('passed') for r in tests['groups'])
for p in C.glob('*.py'):ast.parse(p.read_bytes())
receipt={'status':'SEALED_TOOLING_ONLY_NO_ACTUAL_SUCCESSOR_BUILD','sourceBuilderSha256':original['sourceBuilderSha256'],'derivedBuilderSha256':sha(C/'build_clean_next.py'),'localRepresentativeGroups':6,'results':{'path':result.relative_to(C).as_posix(),'sha256':sha(result)},'originalFunctionsAstUnchanged':same,'stageFinalizeBuildSplit':True,'releaseVersionBeforeCompanyHeld':'1.2.0-read.1','sealedCleanEntryAdapterSha256':'4b41e4d4c5ec1bcaafbb17c41b1489d15429a5b1313586ec56a467acc8a8b405','externalSiblingWhitelist':['platform-cli-customer-read'],'naturalHelperInsideProjectOnly':True,'actualFinalRootPinsAvailable':False,'actualRootSourceStaged':False,'actualRootFinalized':False,'actualSuccessorCompiled':False,'installerExecuted':False,'productOrUserWindowOpened':False,'productionOrCanonicalOrOutputsWritten':False,'pending':['Actual root final pins and SHA; exact actual closed CLI payload descriptor and SHA.','Root stage and final threeDY revision4 -> CLI -> natural3 generation.','Final actual source/compiled/factory/package/Native/ordinary computer acceptance, root scheduled.'],'ownedServicesStarted':0,'remainingOwnedChildProcesses':0}
write(C/'FINAL-RECEIPT.json',receipt)
names=['build_clean_next.py','standard_entry.py.in','held_standard_contract.py.in','adapt_clean_entry.py','existing_workspace_entry.py','prepare_external_descriptor.py','derive_builder.py','successor_sections.py.in','test_tool_contract.py','DERIVATION-FINAL.json','BUILDER-DIFF.patch','RUNBOOK.md','FINAL-RECEIPT.json']
write(C/'SOURCE-FILES.json',{'files':[{'path':n,'bytes':(C/n).stat().st_size,'sha256':sha(C/n)} for n in names]})
write(C/'SEALED.json',{'status':'sealed-tooling-stop-writing','sourceFilesSha256':sha(C/'SOURCE-FILES.json'),'receiptSha256':sha(C/'FINAL-RECEIPT.json'),'files':[{'path':n,'sha256':sha(C/n)} for n in names]})
print(json.dumps({'builderSha256':sha(C/'build_clean_next.py'),'finalSha256':sha(C/'FINAL-RECEIPT.json'),'sealedSha256':sha(C/'SEALED.json'),'sourceSha256':sha(C/'SOURCE-FILES.json'),'diffSha256':sha(C/'BUILDER-DIFF.patch'),'actualStageOrCompile':False}))
