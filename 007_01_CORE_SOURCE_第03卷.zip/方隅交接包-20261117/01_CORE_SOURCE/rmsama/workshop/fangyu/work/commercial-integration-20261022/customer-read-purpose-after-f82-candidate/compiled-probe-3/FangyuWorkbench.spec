# -*- mode: python ; coding: utf-8 -*-
from PyInstaller.utils.hooks import collect_all
from PyInstaller.utils.hooks import copy_metadata

datas = []
binaries = []
hiddenimports = ['__future__', 'abc', 'argparse', 'asyncio', 'base64', 'binascii', 'bisect', 'calendar', 'cgi', 'codecs', 'collections', 'collections.abc', 'concurrent', 'concurrent.futures', 'contextlib', 'contextvars', 'copy', 'csv', 'ctypes', 'ctypes.wintypes', 'dataclasses', 'datetime', 'decimal', 'difflib', 'doctest', 'email', 'email.utils', 'enum', 'errno', 'fcntl', 'fractions', 'functools', 'getpass', 'gettext', 'glob', 'hashlib', 'heapq', 'hmac', 'html', 'html.entities', 'http', 'http.client', 'http.cookies', 'http.server', 'importlib', 'importlib.abc', 'importlib.machinery', 'importlib.metadata', 'importlib.util', 'inspect', 'io', 'ipaddress', 'itertools', 'json', 'locale', 'logging', 'marshal', 'math', 'mimetypes', 'msvcrt', 'ntpath', 'operator', 'optparse', 'os', 'os.path', 'pathlib', 'pdb', 'pkgutil', 'platform', 'queue', 'random', 're', 'secrets', 'shlex', 'shutil', 'signal', 'socket', 'socketserver', 'sqlite3', 'ssl', 'stat', 'string', 'stringprep', 'struct', 'subprocess', 'sys', 'tempfile', 'termios', 'textwrap', 'threading', 'time', 'traceback', 'tty', 'types', 'typing', 'unicodedata', 'urllib', 'urllib.error', 'urllib.parse', 'urllib.request', 'uuid', 'warnings', 'wave', 'weakref', 'webbrowser', 'winreg', 'wsgiref', 'wsgiref.simple_server', 'wsgiref.types', 'xml', 'xml.dom.expatbuilder', 'xml.dom.minidom', 'xml.dom.xmlbuilder', 'xml.etree.ElementTree', 'xml.parsers.expat', 'xml.sax.handler', 'xml.sax.xmlreader', 'zipfile', 'zlib']
datas += copy_metadata('pywebview')
tmp_ret = collect_all('webview')
datas += tmp_ret[0]; binaries += tmp_ret[1]; hiddenimports += tmp_ret[2]
tmp_ret = collect_all('pythonnet')
datas += tmp_ret[0]; binaries += tmp_ret[1]; hiddenimports += tmp_ret[2]
tmp_ret = collect_all('clr_loader')
datas += tmp_ret[0]; binaries += tmp_ret[1]; hiddenimports += tmp_ret[2]
tmp_ret = collect_all('PIL')
datas += tmp_ret[0]; binaries += tmp_ret[1]; hiddenimports += tmp_ret[2]
tmp_ret = collect_all('cryptography')
datas += tmp_ret[0]; binaries += tmp_ret[1]; hiddenimports += tmp_ret[2]
tmp_ret = collect_all('tuf')
datas += tmp_ret[0]; binaries += tmp_ret[1]; hiddenimports += tmp_ret[2]
tmp_ret = collect_all('securesystemslib')
datas += tmp_ret[0]; binaries += tmp_ret[1]; hiddenimports += tmp_ret[2]
tmp_ret = collect_all('httpx')
datas += tmp_ret[0]; binaries += tmp_ret[1]; hiddenimports += tmp_ret[2]


a = Analysis(
    ['C:/积木软件工坊/项目/方隅公寓客户版/work/commercial-integration-20261022/customer-read-purpose-after-f82-candidate/compiled-probe-3/probe_entry.py'],
    pathex=[],
    binaries=binaries,
    datas=datas,
    hiddenimports=hiddenimports,
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    noarchive=False,
    optimize=0,
)
pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name='FangyuWorkbench',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    console=True,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon=['C:/积木软件工坊/项目/方隅公寓客户版/work/parallel-integration-20261018/final-integration/candidate-unified-v82/project/work/app/src/resources/brand.ico'],
)
coll = COLLECT(
    exe,
    a.binaries,
    a.datas,
    strip=False,
    upx=True,
    upx_exclude=[],
    name='FangyuWorkbench',
)
