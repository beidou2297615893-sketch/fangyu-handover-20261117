"""固化当前已验界面；只复制公开源码/图片，不读取客户数据或修改桌面图标。"""
from pathlib import Path
import argparse
import datetime
import hashlib
import json
import os
import re
import sys
import uuid

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
PROJECT = HERE.parent.parent
PREVIEW = PROJECT / 'work/ui-approved-implementation/ui-preview'
FALLBACK = PROJECT / 'work/ui-runtime-r56/src/web/workspace/assets'
VENV = PROJECT / 'work/desktop-python'
ASSET_PATTERN = re.compile(r'[A-Za-z0-9][A-Za-z0-9._-]+\.(?:png|webp|jpe?g|svg|woff2)')
SOURCE_PATTERN = re.compile(
    r'''(?P<quote>["'])(?P<path>(?:/|\./|\.\./)?[A-Za-z0-9][A-Za-z0-9_./-]*\.(?:html|css|mjs|js))(?:[?#][^"']*)?(?P=quote)''')


def collect_source_files(preview=PREVIEW):
    """Follow static local entry/module/style references without executing code."""
    from ui_native_host import read_public
    preview = Path(os.path.abspath(preview))
    pending = [preview / name for name in ('index.html', 'styles.css', 'app.mjs')]
    found = set()
    while pending:
        source = pending.pop()
        if source in found:
            continue
        if not source.is_file():
            raise ValueError('界面入口或引用模块不存在：' + str(source))
        body = read_public(source).decode('utf-8')
        found.add(source)
        for match in SOURCE_PATTERN.finditer(body):
            name = match['path']
            candidate = (preview / name.lstrip('/') if name.startswith('/')
                         else source.parent / name)
            candidate = Path(os.path.abspath(candidate))
            if not candidate.is_relative_to(preview):
                raise ValueError('界面模块引用超出本实例预览目录。')
            pending.append(candidate)
    return sorted(found)


def sha(raw):
    return hashlib.sha256(raw).hexdigest().upper()


def copy_public(source, target):
    from ui_native_host import read_public
    body = read_public(source)
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open('xb') as stream:
        stream.write(body)
    return body


def launcher_source(release_id, manifest_sha, host_sha, lifecycle_sha=None):
    return '''"""Fixed 方隅 UI release entry; no business App import."""
from pathlib import Path
import hashlib
import importlib.util
import json
import os
import stat
import sys
sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
RELEASE = ROOT / 'releases/%s'
MANIFEST_SHA256 = '%s'
HOST_SHA256 = '%s'
LIFECYCLE_SHA256 = '%s'
_LIFECYCLE = None

def record(stage, error=None):
    try:
        if _LIFECYCLE is not None:
            _LIFECYCLE.record(stage, error=error)
    except Exception:
        pass

def diagnostics():
    global _LIFECYCLE
    if not LIFECYCLE_SHA256:
        return
    try:
        path = RELEASE / 'lifecycle_log.py'
        raw = pinned(path, LIFECYCLE_SHA256)
        name = 'fangyu_ui_lifecycle_log_' + hashlib.sha256(str(path.resolve()).encode()).hexdigest()[:16]
        child = sys.modules.get(name)
        if child is None:
            child = importlib.util.module_from_spec(importlib.util.spec_from_loader(name, loader=None))
            child.__file__ = str(path)
            sys.modules[name] = child
            exec(compile(raw, str(path), 'exec'), child.__dict__)
        _LIFECYCLE = child.LifecycleLog(ROOT / 'state', RELEASE.name)
        child.install_hooks(_LIFECYCLE)
    except Exception:
        _LIFECYCLE = None

def pinned(path, expected):
    for item in (path, *path.parents):
        info = item.lstat()
        if item.is_symlink() or getattr(info, 'st_file_attributes', 0) & 0x400:
            raise RuntimeError('界面启动路径不能是链接。')
    before = path.stat()
    if not stat.S_ISREG(before.st_mode) or before.st_nlink != 1:
        raise RuntimeError('界面启动文件无效。')
    raw = path.read_bytes()
    after = path.stat()
    if ((before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns)
            != (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns)
            or hashlib.sha256(raw).hexdigest().upper() != expected):
        raise RuntimeError('界面版本校验失败，请恢复已固化版本。')
    return raw

def main():
    diagnostics()
    record('launcher_start')
    module = None
    try:
        pinned(RELEASE / 'RELEASE.json', MANIFEST_SHA256)
        record('manifest_verified')
        source = pinned(RELEASE / 'ui_native_host.py', HOST_SHA256)
        record('host_import_started')
        module = importlib.util.module_from_spec(importlib.util.spec_from_loader('fangyu_native_ui_host', loader=None))
        module.__file__ = str(RELEASE / 'ui_native_host.py')
        sys.modules[module.__name__] = module
        exec(compile(source, module.__file__, 'exec'), module.__dict__)
        record('host_imported')
        record('host_main_start')
        result = module.main(RELEASE, MANIFEST_SHA256, ROOT / 'state', project_root=ROOT.parent.parent)
        record('launcher_exit')
        return result
    except Exception as error:
        record('launcher_failed', error)
        if any(arg in sys.argv for arg in ('--check', '--self-test')):
            raise
        if module is not None and callable(getattr(module, 'notify_error', None)):
            module.notify_error(error)
            return 1
        raise

if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except Exception as error:
        if any(arg in sys.argv for arg in ('--check', '--self-test')):
            print(json.dumps({'status': 'FAIL', 'error_type': type(error).__name__, 'message': '启动检查未通过，请查看启动记录。'}, ensure_ascii=False))
        elif os.name == 'nt':
            import ctypes
            ctypes.windll.user32.MessageBoxW(None, '界面未能启动，请查看本版本的启动状态。', '方隅工作台 · 打开提示', 0x10)
        raise SystemExit(1)
''' % (release_id, manifest_sha, host_sha, lifecycle_sha or '')


def promote_candidate(report_path):
    """Promote only a validated staged snapshot; no build, installer or data migration."""
    from ui_native_host import read_public, verify_release, verify_backend_dependencies
    report_path = Path(report_path).absolute()
    if report_path.parent != HERE / 'candidates' or report_path.suffix != '.json':
        raise ValueError('只能晋级本项目候选目录中的版本记录。')
    report = json.loads(read_public(report_path).decode('utf-8'))
    release_id = report.get('release_id', '')
    if not re.fullmatch(r'ui-r57-\d{8}T\d{6}Z-[0-9a-f]{8}', release_id):
        raise ValueError('候选版本编号无效。')
    release = HERE / 'releases' / release_id
    manifest, files = verify_release(release, report['manifest_sha256'])
    verify_backend_dependencies(release, files, PROJECT)
    host_sha = files['ui_native_host.py']['sha256']
    expected = launcher_source(release_id, report['manifest_sha256'], host_sha,
        files.get('lifecycle_log.py', {}).get('sha256')).encode('utf-8')
    candidate = HERE / ('run_candidate.' + release_id + '.py')
    body = read_public(candidate, report['launcher_sha256'])
    if body != expected:
        raise ValueError('候选启动器与已核验版本不一致。')
    old_launcher = HERE / 'run_workbench.py'
    stamp = datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')
    if old_launcher.exists():
        backup = HERE / 'launcher-backups' / (stamp + '-' + uuid.uuid4().hex[:8] + '.py')
        backup.parent.mkdir(exist_ok=True)
        copy_public(old_launcher, backup)
    temporary = HERE / ('run_workbench.' + uuid.uuid4().hex + '.tmp')
    temporary.write_bytes(body)
    os.replace(temporary, old_launcher)
    result = {**report, 'status': 'FROZEN', 'launcher': str(old_launcher),
              'launcher_sha256': sha(body), 'promoted_from': str(report_path)}
    (HERE / 'FROZEN.json').write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
    return result


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--freeze', action='store_true', help='将定稿界面复制为独立版本并生成启动器')
    parser.add_argument('--stage', action='store_true', help='生成候选快照，保持桌面稳定入口不变')
    parser.add_argument('--promote', type=Path, help='验证后晋级指定候选记录，不重新构建')
    options = parser.parse_args(argv)
    if options.freeze and options.stage:
        parser.error('候选暂存与直接晋级不能同时执行')
    if options.promote:
        if options.freeze or options.stage:
            parser.error('晋级与构建不能同时执行')
        print(json.dumps(promote_candidate(options.promote), ensure_ascii=False, indent=2))
        return 0
    source_files = collect_source_files()
    texts = '\n'.join(item.read_text('utf-8') for item in source_files)
    names = sorted(set(ASSET_PATTERN.findall(texts)))
    assets = {}
    for name in names:
        source = PREVIEW / 'assets' / name
        if not source.is_file():
            source = FALLBACK / name
        if not source.is_file():
            raise ValueError('缺少界面资源：' + name)
        assets[name] = source
    plan = {'status': 'READY_TO_FREEZE', 'source_files': len(source_files),
            'assets': names, 'runtime': str(VENV / 'Scripts/pythonw.exe'),
            'business_data_access': True, 'connected_features': ['employee_login', 'store_presets', 'platform_accounts', 'collection', 'customers', 'customer_export', 'reply_drafts', 'reply_review', 'explicit_reply_delivery', 'reviewed_reply_batch', 'reply_delivery_status_cancel', 'customer_internal_handoff', 'local_reply_templates', 'workspace_settings', 'runtime_version'],
            'desktop_shortcut_changed': False}
    if not (options.freeze or options.stage):
        print(json.dumps(plan, ensure_ascii=False, indent=2))
        return 0
    stamp = datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')
    release_id = 'ui-r57-' + stamp + '-' + uuid.uuid4().hex[:8]
    release = HERE / 'releases' / release_id
    release.mkdir(parents=True, exist_ok=False)
    source_pins = {}
    for source in source_files:
        name = source.relative_to(PREVIEW).as_posix()
        body = copy_public(source, release / 'web' / name)
        source_pins[str(source)] = sha(body)
    for name, source in assets.items():
        body = copy_public(source, release / 'web/assets' / name)
        source_pins[str(source)] = sha(body)
    copy_public(HERE / 'ui_native_host.py', release / 'ui_native_host.py')
    for name in ('workspace_binding.py', 'lifecycle_log.py'):
        body = copy_public(HERE / name, release / name)
        source_pins[str(HERE / name)] = sha(body)
    copy_public(HERE / 'workbench_backend.py', release / 'workbench_backend.py')
    copy_public(HERE / 'customer_workbench.py', release / 'customer_workbench.py')
    keyword_body=copy_public(HERE/'keyword_effect_workbench.py',release/'keyword_effect_workbench.py')
    source_pins[str(HERE/'keyword_effect_workbench.py')]=sha(keyword_body)
    copy_public(HERE / 'customer_intent_workbench.py', release / 'customer_intent_workbench.py')
    for name in ('knowledge_file_import.py','knowledge_file_vendor/docx2txt.py','knowledge_file_vendor/LICENSE-docx2txt.txt','knowledge_file_vendor/PINS.json'):
        body=copy_public(HERE/name,release/'resources/knowledge-file-import'/name)
        source_pins[str(HERE/name)]=sha(body)
    for name in ('pdf_text_import.py', 'knowledge_pdf_vendor/PINS.json', 'knowledge_pdf_vendor/LICENSE-pypdf.txt', 'knowledge_pdf_vendor/pypdf/__init__.py', 'knowledge_pdf_vendor/pypdf/_cmap.py', 'knowledge_pdf_vendor/pypdf/_codecs/__init__.py', 'knowledge_pdf_vendor/pypdf/_codecs/_codecs.py', 'knowledge_pdf_vendor/pypdf/_codecs/adobe_glyphs.py', 'knowledge_pdf_vendor/pypdf/_codecs/core_font_metrics.py', 'knowledge_pdf_vendor/pypdf/_codecs/pdfdoc.py', 'knowledge_pdf_vendor/pypdf/_codecs/std.py', 'knowledge_pdf_vendor/pypdf/_codecs/symbol.py', 'knowledge_pdf_vendor/pypdf/_codecs/zapfding.py', 'knowledge_pdf_vendor/pypdf/_configuration.py', 'knowledge_pdf_vendor/pypdf/_crypt_providers/__init__.py', 'knowledge_pdf_vendor/pypdf/_crypt_providers/_base.py', 'knowledge_pdf_vendor/pypdf/_crypt_providers/_cryptography.py', 'knowledge_pdf_vendor/pypdf/_crypt_providers/_fallback.py', 'knowledge_pdf_vendor/pypdf/_crypt_providers/_pycryptodome.py', 'knowledge_pdf_vendor/pypdf/_doc_common.py', 'knowledge_pdf_vendor/pypdf/_encryption.py', 'knowledge_pdf_vendor/pypdf/_page.py', 'knowledge_pdf_vendor/pypdf/_page_labels.py', 'knowledge_pdf_vendor/pypdf/_protocols.py', 'knowledge_pdf_vendor/pypdf/_reader.py', 'knowledge_pdf_vendor/pypdf/_text_extraction/__init__.py', 'knowledge_pdf_vendor/pypdf/_text_extraction/_layout_mode/__init__.py', 'knowledge_pdf_vendor/pypdf/_text_extraction/_layout_mode/_fixed_width_page.py', 'knowledge_pdf_vendor/pypdf/_text_extraction/_layout_mode/_text_state_manager.py', 'knowledge_pdf_vendor/pypdf/_text_extraction/_layout_mode/_text_state_params.py', 'knowledge_pdf_vendor/pypdf/_text_extraction/_text_extractor.py', 'knowledge_pdf_vendor/pypdf/_utils.py', 'knowledge_pdf_vendor/pypdf/_version.py', 'knowledge_pdf_vendor/pypdf/_writer.py', 'knowledge_pdf_vendor/pypdf/actions/__init__.py', 'knowledge_pdf_vendor/pypdf/actions/_actions.py', 'knowledge_pdf_vendor/pypdf/annotations/__init__.py', 'knowledge_pdf_vendor/pypdf/annotations/_base.py', 'knowledge_pdf_vendor/pypdf/annotations/_markup_annotations.py', 'knowledge_pdf_vendor/pypdf/annotations/_non_markup_annotations.py', 'knowledge_pdf_vendor/pypdf/constants.py', 'knowledge_pdf_vendor/pypdf/errors.py', 'knowledge_pdf_vendor/pypdf/filters.py', 'knowledge_pdf_vendor/pypdf/generic/__init__.py', 'knowledge_pdf_vendor/pypdf/generic/_appearance_stream.py', 'knowledge_pdf_vendor/pypdf/generic/_base.py', 'knowledge_pdf_vendor/pypdf/generic/_color.py', 'knowledge_pdf_vendor/pypdf/generic/_data_structures.py', 'knowledge_pdf_vendor/pypdf/generic/_files.py', 'knowledge_pdf_vendor/pypdf/generic/_fit.py', 'knowledge_pdf_vendor/pypdf/generic/_font.py', 'knowledge_pdf_vendor/pypdf/generic/_image_inline.py', 'knowledge_pdf_vendor/pypdf/generic/_image_xobject.py', 'knowledge_pdf_vendor/pypdf/generic/_link.py', 'knowledge_pdf_vendor/pypdf/generic/_outline.py', 'knowledge_pdf_vendor/pypdf/generic/_rectangle.py', 'knowledge_pdf_vendor/pypdf/generic/_utils.py', 'knowledge_pdf_vendor/pypdf/generic/_viewerpref.py', 'knowledge_pdf_vendor/pypdf/pagerange.py', 'knowledge_pdf_vendor/pypdf/papersizes.py', 'knowledge_pdf_vendor/pypdf/py.typed', 'knowledge_pdf_vendor/pypdf/types.py', 'knowledge_pdf_vendor/pypdf/xmp.py'):
        body=copy_public(HERE/name,release/'resources/knowledge-file-import'/name)
        source_pins[str(HERE/name)]=sha(body)
    outcome_body=copy_public(HERE/'customer_outcomes_workbench.py',release/'customer_outcomes_workbench.py')
    source_pins[str(HERE/'customer_outcomes_workbench.py')]=sha(outcome_body)
    contact_body=copy_public(HERE/'customer_public_contacts.py',release/'customer_public_contacts.py')
    source_pins[str(HERE/'customer_public_contacts.py')]=sha(contact_body)
    copy_public(HERE / 'reply_workbench.py', release / 'reply_workbench.py')
    copy_public(HERE / 'reply_delivery.py', release / 'reply_delivery.py')
    for name in ('voice_samples.py','voice_samples_vendor/ingest_style_reference.py',
                 'voice_samples_vendor/LICENSE-xintu.txt'):
        body=copy_public(HERE/name,release/'resources/voice-samples'/name)
        source_pins[str(HERE/name)]=sha(body)
    for name in ('content_workbench.py','content_vendor/check_copy.py','content_vendor/diagnose_metrics.py',
                 'content_vendor/LICENSE-xintu.txt','content_vendor/method-bundle.json',
                 'content_extension_loader.py','content_workflow.py','workflow_methods.py','workflow_knowledge.py',
                 'workflow_vendor/normalize.py','workflow_vendor/LICENSE','workflow_vendor/PINS.json',
                 'publishing_dom_methods.py','publishing_port.py','content_publishing.py','content_schedule.py','publication_protocol.py','publication_authority_host.py','owned_publication_host.py','publication_policy.py','publishing_vendor/LICENSE-white0dew',
                 'guided_vendor/manifest.json', 'guided_vendor/LICENSE-agency.txt', 'guided_vendor/roles-01.json', 'guided_vendor/roles-02.json', 'guided_vendor/roles-03.json', 'guided_vendor/roles-04.json', 'guided_vendor/roles-05.json', 'guided_vendor/roles-06.json', 'guided_vendor/roles-07.json'):
        body=copy_public(HERE/name,release/'resources/content-workbench'/name)
        source_pins[str(HERE/name)]=sha(body)
    for name in ('cpu_media_engine.py','media_production.py','media_native.py'):
        body=copy_public(HERE/'content-media'/name,release/'resources/content-media'/name)
        source_pins[str(HERE/'content-media'/name)]=sha(body)
    for name in ('gateway_adapter.py','trusted_method_pins.py'):
        body=copy_public(HERE/'content_gateway'/name,release/'resources/content-gateway'/name)
        source_pins[str(HERE/'content_gateway'/name)]=sha(body)
    for name in ('store_materials.py','store_materials_catalog.json','rental_assessment.py',
                 'approved_intent_policy.json','store_search_profiles.json'):
        body=copy_public(HERE/name,release/name)
        source_pins[str(HERE/name)]=sha(body)
    remote_source = HERE / 'remote_management.py'
    body = copy_public(remote_source, release / 'resources/remote_management.py')
    source_pins[str(remote_source)] = sha(body)
    platform_source = PROJECT / 'work/shared-backend-integration'
    platform_files = [platform_source / 'platform_runtime.py']
    platform_files += sorted((platform_source / 'vendor-src').rglob('*.py'))
    platform_files += [platform_source / 'vendor-src/SOURCE.json',
                       platform_source / 'vendor-src/douyin-connection-review.json']
    for source in platform_files:
        body = copy_public(source, release / 'resources/platform-runtime' / source.relative_to(platform_source))
        source_pins[str(source)] = sha(body)
    legacy = PROJECT / 'work/ui-runtime-r55/src'
    dependency_entries = []
    for source in sorted(legacy.rglob('*.py')):
        from ui_native_host import read_public
        body = read_public(source)
        dependency_entries.append({'path': source.relative_to(legacy).as_posix(),
                                   'size': len(body), 'sha256': sha(body)})
        source_pins[str(source)] = sha(body)
    dependency_body = {'schema': 'fangyu-existing-login-components-v1',
                       'source': 'work/ui-runtime-r55/src', 'files': dependency_entries}
    (release / 'resources').mkdir(exist_ok=True)
    (release / 'resources/backend-dependencies.json').write_text(
        json.dumps(dependency_body, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    copy_public(PROJECT / 'work/ui-runtime-r55/src/resources/brand.ico', release / 'resources/brand.ico')
    licenses = [FALLBACK / 'tabler-LICENSE.txt',
                PROJECT / 'work/ui-runtime-r56/src/resources/approved-ui-lucide-LICENSE.txt',
                PROJECT / 'work/ui-runtime-r55/src/resources/licenses/XlsxWriter-3.2.9-LICENSE.txt']
    licenses += sorted((PREVIEW / 'assets').glob('*LICENSE*'))
    licenses += sorted((PREVIEW / 'assets').glob('*source*.md'))
    packages = VENV / 'Lib/site-packages'
    for pattern in ('pywebview-*.dist-info/licenses/LICENSE', 'pythonnet-*.dist-info/licenses/LICENSE',
                    'clr_loader-*.dist-info/licenses/LICENSE', 'bottle-*.dist-info/licenses/LICENSE'):
        for license_path in packages.glob(pattern):
            copy_public(license_path, release / 'resources/licenses' /
                        (license_path.parent.parent.name + '-LICENSE.txt'))
    for license_path in licenses:
        if not license_path.is_file():
            raise ValueError('缺少资产来源或许可：' + str(license_path))
        destination = release / 'resources/licenses' / license_path.name
        if not destination.exists():
            copy_public(license_path, destination)
    # Reject edits made during this freeze, without locking the editable preview.
    for source, expected in source_pins.items():
        if sha(Path(source).read_bytes()) != expected:
            raise ValueError('固化时预览文件发生变化，请定稿后重新运行。')
    entries = []
    for path in sorted(release.rglob('*')):
        if path.is_file():
            body = path.read_bytes()
            entries.append({'path': path.relative_to(release).as_posix(),
                            'size': len(body), 'sha256': sha(body)})
    manifest = {'schema': 'fangyu_native_ui_release_v1', 'company_id': 'fangyu-apartment-client',
                'release_id': release_id, 'created_utc': stamp,
                'mode': 'shared-employee-backend', 'files': entries}
    raw = (json.dumps(manifest, ensure_ascii=False, indent=2) + '\n').encode('utf-8')
    (release / 'RELEASE.json').write_bytes(raw)
    manifest_sha = sha(raw)
    host_sha = next(item['sha256'] for item in entries if item['path'] == 'ui_native_host.py')
    from ui_native_host import verify_release
    verify_release(release, manifest_sha)
    launcher = launcher_source(release_id, manifest_sha, host_sha,
        next(item['sha256'] for item in entries if item['path'] == 'lifecycle_log.py')).encode('utf-8')
    candidate = HERE / ('run_candidate.' + release_id + '.py')
    candidate.write_bytes(launcher)
    report = {**plan, 'status': 'STAGED', 'release': str(release), 'release_id': release_id,
              'manifest_sha256': manifest_sha, 'launcher': str(candidate),
              'launcher_sha256': sha(launcher), 'files': len(entries)}
    report_path = HERE / 'candidates' / (release_id + '.json')
    report_path.parent.mkdir(exist_ok=True)
    report_path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
    if options.freeze:
        report = promote_candidate(report_path)
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
