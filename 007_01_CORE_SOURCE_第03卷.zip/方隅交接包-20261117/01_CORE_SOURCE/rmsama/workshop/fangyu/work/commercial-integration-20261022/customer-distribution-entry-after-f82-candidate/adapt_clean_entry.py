"""Derive the existing clean entry without changing its verified code loader.

This is a packaging adapter, not a new permission source. The default launch
still uses its own ordinary user directories. The explicit upgrade path runs
the original, hash-verified workspace and Windows DPAPI verifier.
"""
from pathlib import Path
import ast
import hashlib

HERE = Path(__file__).resolve().parent
BASE_ENTRY_SHA = '102815dd0e021f41068f6bfe01090ddbfb373f967154adca5bcc12eb0baa815e'
SELECTOR_SHA = '58cd9c8066533eb9196ef69fcad325bd0be9fb47a333dbf236d5b776bac3b33a'

SUPPORT_LOADER = '''
def verified_existing_workspace_support(release):
    manifest = json.loads(exact(release / 'RELEASE.json', RELEASE_SHA))
    rows = [row for row in manifest['files'] if row['path'] == 'workspace_binding.py']
    if len(rows) != 1:
        raise RuntimeError('工作资料核对组件清单不完整。')
    row = rows[0]
    raw = exact(release / 'workspace_binding.py', row['sha256'].lower())
    if len(raw) != row['size']:
        raise RuntimeError('工作资料核对组件长度不匹配。')
    module = importlib.util.module_from_spec(importlib.util.spec_from_loader(
        'fangyu_verified_existing_workspace', loader=None))
    module.__file__ = str(release / 'workspace_binding.py')
    sys.modules[module.__name__] = module
    exec(compile(raw, module.__file__, 'exec', dont_inherit=True, optimize=0), module.__dict__)
    return module


def selected_directories(release, existing_project_root=None, binding_sha256=None):
    if existing_project_root is None and binding_sha256 is None:
        return own_directories()
    support = verified_existing_workspace_support(release)
    selected = select_existing_workspace(existing_project_root, binding_sha256, support)
    if selected is None:
        raise RuntimeError('原工作资料的启动设置不完整。')
    return selected
'''


def adapt_entry(raw, selector_raw, *, expected_entry_sha=None):
    """Adapt a clean entry after its builder has rendered release/closure pins."""
    if expected_entry_sha is not None and hashlib.sha256(raw).hexdigest() != expected_entry_sha:
        raise ValueError('Clean entry input does not match its reviewed pin')
    if hashlib.sha256(selector_raw).hexdigest() != SELECTOR_SHA:
        raise ValueError('Existing workspace selector does not match its reviewed pin')
    text = raw.decode('utf-8').replace('\r\n', '\n')
    tree = ast.parse(text)
    main_nodes = [node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == 'main']
    if len(main_nodes) != 1 or any(isinstance(node, ast.FunctionDef) and node.name in
            ('selected_directories', 'verified_existing_workspace_support', 'select_existing_workspace')
            for node in tree.body):
        raise ValueError('Expected exactly one unadapted clean entry main')
    node = main_nodes[0]
    lines = text.splitlines(keepends=True)
    original_main = ''.join(lines[node.lineno-1:node.end_lineno])
    expected = "    parser.add_argument('--result-file')\n"
    selected = '    data, state = own_directories()\n'
    if original_main.count(expected) != 1 or original_main.count(selected) != 1:
        raise ValueError('Clean entry argument/data selection seam changed')
    updated_main = original_main.replace(expected, expected +
        "    parser.add_argument('--existing-project-root')\n" +
        "    parser.add_argument('--binding-sha256')\n")
    updated_main = updated_main.replace(selected,
        '    data, state = selected_directories(release, args.existing_project_root, args.binding_sha256)\n')
    selector_tree = ast.parse(selector_raw.decode('utf-8'))
    selector_lines = selector_raw.decode('utf-8').splitlines(keepends=True)
    # Retain the exact reviewed selector definitions; the entry already imports
    # Path/hashlib and this block adds the only missing standard-library import.
    definitions = '\n\n'.join(''.join(selector_lines[item.lineno-1:item.end_lineno]).rstrip()
        for item in selector_tree.body if isinstance(item, (ast.ClassDef, ast.FunctionDef)))
    inserted = '\nimport re\n\n' + definitions + '\n\n' + SUPPORT_LOADER + '\n'
    result = ''.join(lines[:node.lineno-1]) + inserted + updated_main + ''.join(lines[node.end_lineno:])
    result = result.replace(
        'This independently installed application initializes only its own empty data\n'
        'directory. It grants no enterprise/device/platform permissions. Existing local\n'
        'production binding and sessions are never consulted or copied.',
        'Default launches initialize only the ordinary application data directory.\n'
        'An explicitly pinned local upgrade reuses the original verified workspace.\n'
        'Neither path grants enterprise, device, platform or sending permission.')
    before_functions = {item.name:ast.dump(item, include_attributes=False) for item in tree.body
        if isinstance(item, ast.FunctionDef)}
    result_tree = ast.parse(result)
    after_functions = {item.name:ast.dump(item, include_attributes=False) for item in result_tree.body
        if isinstance(item, ast.FunctionDef)}
    for name, body in before_functions.items():
        if name != 'main' and after_functions.get(name) != body:
            raise ValueError('Original entry function changed: ' + name)
    compile(result, '<adapted-clean-entry>', 'exec', dont_inherit=True, optimize=0)
    return result.encode('utf-8')
