# Just One API

Token env var: `JUSTONE_API_TOKEN`. Shared by `xhs-topic-radar` and `xhs-note-writer`.

## Base URL and auth

- Default: `https://api.justoneapi.com`
- Mainland alternative: `http://47.117.133.51:30015`
- Pass `token` as query parameter
- Timeout: 120 seconds

### Token handling

The token travels in the query string, so it can land in shell history and server logs. Store it once
in the shell profile or a `.env`, then let scripts read the environment:

```bash
echo 'export JUSTONE_API_TOKEN="<token>"' >> ~/.zshrc && source ~/.zshrc
```

Never inline the token in a command you hand to the user, never write it into skill files, and never
include it in saved JSON.

## Endpoints

| Purpose | Path | Key params |
|---|---|---|
| Keyword search | `/api/xiaohongshu/search-note/v4` | `keyword`, `page=1`, `sortType=popularity_descending`, `timeFilter`, `noteType` |
| Note detail | `/api/xiaohongshu/get-note-detail/v1` | `noteId` |

### noteType

- `ALL` — topic radar default
- `NORMAL_NOTE` — carousel/image style sampling
- `VIDEO_NOTE` — video caption/style sampling

## Business response handling

Require `code == 0`.

| Code | Action |
|---|---|
| 0 | Process |
| 100 | Stop; invalid token → fall back to WebSearch |
| 301, 500 | Retry up to twice |
| 302, 303 | Back off; may fall back to WebSearch |
| 400 | Fix parameters |
| 600-602 | Stop; permission/balance issue → WebSearch |

## Suite scripts

All three share `../scripts/justone_xhs.py`, accept `--output` (parent dirs are created), and echo JSON to stdout.

```bash
# Topic evidence
python3 xhs-topic-radar/scripts/fetch_topic_evidence.py \
  --keyword "AI工具" --count 10 --pages 2 --output ~/.xhs/topic-evidence/latest.json

# Style samples
python3 xhs-note-writer/scripts/fetch_style_samples.py \
  --keyword "AI工具" --format carousel --count 8 --output ~/.xhs/style-samples/ai-carousel.json

# Note detail for deconstruction
python3 xhs-reference-deconstructor/scripts/fetch_note_detail.py \
  --note "https://www.xiaohongshu.com/explore/<noteId>" --output ~/.xhs/references/latest.json
```

## Request cost

Each kept note with `--detail` costs one extra request. Ranking and truncation happen **before**
detail retrieval, so `--count` directly controls spend. Raise `--pages` only when one page cannot
fill `--count`.

## Fallback

When Just One API is unavailable, read `websearch-fallback.md` and continue. Do not use browser automation as a default substitute.

## Field extraction caution

Nested `data` shapes vary. Pass `--keep-raw` to `fetch_note_detail.py` when debugging. Never invent missing body text or metrics.
