from pathlib import Path
p=Path(r'C:/积木软件工坊/项目/方隅公寓客户版/work/parallel-integration-20261018/final-integration/stage-02/project/work/ui-approved-implementation/ui-preview/pages/content-workflow.mjs')
s=p.read_text(encoding='utf-8')
s=s.replace("${btn('资料与引用','open-knowledge')}", "${btn('检查生成服务','check-service',{disabled:!!f.pending})}${btn('资料与引用','open-knowledge')}",1)
s=s.replace("</div></div>${supported?`<div class=\"wf-stage-actions\">", "</div></div>${supported?'<p class=\"co-small\">检查服务不会生成内容，资料和草稿可继续编辑保存。</p>':''}${supported?`<div class=\"wf-stage-actions\">",1)
old="if(writing&&(response.receipt?.requestId!==payload.requestId"
new="if(action==='content_methods_read'&&(response.result?.contract!==CONTRACT||!Array.isArray(response.result.methods)))throw Error('生成服务与方法状态尚未核对，本地资料仍保留。');if(writing&&(response.receipt?.requestId!==payload.requestId"
assert old in s;s=s.replace(old,new,1)
anchor="  if(kind==='close'){"
addition="  if(kind==='check-service'){if(f.pending)return;update(ctx,()=>{f.open=true;f.methodsLoaded=true;f.error='';f.notice='';});await request(ctx,u,'content_methods_read',{},r=>{f.specs=r.result.methods;f.notice=r.workspace.workflowCapabilities?.canRunTasks===true?'生成服务已核对可用，执行任务仍需单独确认。':'生成服务暂不可用，可继续保存资料与编辑草稿。';});return;}\n"
assert anchor in s;s=s.replace(anchor,addition+anchor,1)
p.write_text(s,encoding='utf-8')
