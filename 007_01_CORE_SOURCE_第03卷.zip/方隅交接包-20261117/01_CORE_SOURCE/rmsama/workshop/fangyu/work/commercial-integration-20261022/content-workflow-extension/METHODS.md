# 17个内容方法模块与结果校验

本模块是可注入宿主模型的结构化任务规范及标准库校验器。只新增`workflow_methods.py`、`tests/test_methods.py`与本文；没有网络、文件写入、模型调用、发布、发送或实际调度逻辑。规范和中文任务说明独立编写，不复制许可不明的作者方法文案，也不依赖上游仓库运行。

## 公共接口

```python
from workflow_methods import METHODS, get_method, validate_result, example_result

spec = get_method("writing")
# 将 spec["instructions"] 与 spec["outputSchema"] 交给宿主模型网关。
checked = validate_result("writing", model_result, evidence)
```

`METHODS`提供17项目录快照。每项含`id/title/module/outputSchema/instructions`，以及`version=1`、`requiresHumanReview=True`。`outputSchema`是完整四字段JSON Schema，对象均拒绝未知键。`get_method`返回深拷贝；更改返回值或公开目录快照不会改变内部校验规范。未知方法抛`ValueError`。

结果必须恰好包含：

```json
{
  "summary": "待人工审核的产物说明",
  "facts": [{"quote": "连续原文", "evidenceId": "source-id"}],
  "hypotheses": ["明确标为推断的内容"],
  "artifact": {}
}
```

`facts`和`hypotheses`允许为空。`evidence`只能是`{id: {text: str, kind: str}}`，每条仅这两个字段；事实条目的`quote`必须是相应`text`的连续原文子串，且`kind`严格等于`fact`。改写、跨片段拼接、未知ID、引用`hypothesis`证据充当事实均拒绝。其他非空`kind`可以作为背景证据引用，但不能成为`facts`。artifact内所有`evidenceIds/sourceEvidenceIds`也必须存在于证据字典。

校验成功返回独立的标准JSON数据副本；输入及证据不修改。它验证结构和引用关系，不判断原始证据本身真假，也不取代公司/账号权限、素材授权、HTML转义或人工内容审核。证据须由宿主在当前可信账号范围内加载，不能直接接受模型自报的证据正文与kind。

## artifact合同

下表所有列出的对象字段均为必填，未列出的字段拒绝。`str[]`表示字符串列表，`int`拒绝bool和浮点数。

| id | artifact字段 |
|---|---|
| strategy | `goal, audience, positioningOptions:str[], channelRoles:[{platform,purpose}], milestones:[{name,successMetric,days:int}]` |
| persona | `name, positioning, audience, pillars:str[], voice:str[], avoid:str[]` |
| homepage | `nickname, bio, pinnedNotes:[{title,purpose}], visualBrief` |
| research | `question, findings:[{title,detail,evidenceIds:str[]}], sourceGaps:str[]` |
| topics | `topics:[{title,column,format:image或video,goal,evidenceIds:str[]}]` |
| columns | `columns:[{name,purpose}], cadence` |
| writing | `title, body, tags:str[]` |
| video | `title, script, scenes:[{shot,voice,durationSeconds:int}]` |
| visual | `title, style, ratio:3:4或9:16或1:1, pages:[{page:int,headline,body,visualBrief}]` |
| knowledge | `items:[{title,content,sourceEvidenceIds:str[],tags:str[]}], taxonomy:str[]` |
| revision | `title, changes:[{target:title或body或script,original,replacement,reason}], revisedBody` |
| audit | `findings:[{severity:info或warning或blocking,location,issue,suggestion,evidenceIds:str[]}], nextActions:str[]` |
| package | `title, platform:xiaohongshu或douyin, format:image或video, body, tags:str[], assetRefs:str[]` |
| scheduling | `timezone, slots:[{dayOffset:int,time:HH:MM,contentId,accountId}], notes:str[]` |
| engagement | `replies:[{channel:comment_reply或dm,targetId,reply,rationale,evidenceIds:str[]}], notes:str[]` |
| growth | `metrics:[{metric,current:number,target:number}], experiments:[{hypothesis,action,successMetric,days:int}], cautions:str[]` |
| learning | `lessons:[{observation,proposedRule,evidenceIds:str[]}], nextTests:str[]` |

`package`仅形成内容包元数据，资产引用是宿主已有资产标识，由宿主核对归属后另做本地包。`scheduling`仅形成相对日期排期草案，不创建真实任务。`engagement`只生成草稿：`channel=comment_reply`时targetId为明确评论ID，`channel=dm`时为候选收件人UID；UID文本不证明收件人身份或授权，不从昵称猜UID，也不新增“对象已验证”标志。真正回复/私信需要宿主独立核对身份、权限和执行合同。`learning`只形成候选规则，不激活规则。没有任何方法能返回`published/approved/sent/status`等执行或批准字段，嵌套位置的未知状态键同样拒绝。所有返回值仍需人工审核；宿主不能把模型正文里的成功宣称当作真实执行回执。

## 上限

全部字符串、列表及数值的准确上限保存在每项`outputSchema`中，供网关和前端直接读取，不另建第二份规则。当前输出字符串须非空且不能只含空白；若后续schema明确`minLength=0`，则仍按原合同允许空值。所有输出字符串与现有`base.text`采用相同字符限制：拒绝Unicode类别Cf/Cs以及ord小于32的控制字符，但允许换行、回车、制表符；不会静默删字符。原始证据正文不执行此输出规范化，保持原文及引用比对，引用中的输出文字仍必须满足字符合同。写作/视频/修订标题与选题标题最多120字；写作正文10000字，最多20个标签、每标签60字，为宿主拼接标签预留空间；视频逐字稿与修订正文12000字。证据ID120字、每条引文2000字。根`facts/hypotheses`各最多100条。

人设name/positioning/audience上限分别为80/400/600；pillars最多6项、每项90字，voice/avoid分别最多8项、每项70字，拼接后均落在现有600字字段内。选题column/goal分别不超过80字。修订target只允许title/body/script；original仍须由宿主核对是对应原稿字段中的连续原文，不因结构通过就省略关系核验。原文引用完整保存在artifact；现有字段的短摘要由宿主另存，不能截断后冒充原引文。

- 证据字典最多1000条，每条原文最多20000字，kind最多40字；未知证据字段拒绝。
- topics最多100项，栏目最多30项，视频镜头最多80个，每镜头1—600秒；视觉最多50页，页码1—50。
- 排期最多100项，dayOffset为0—365；策略里程碑1—365天，增长实验1—90天。
- 数字必须有限；增长指标范围0—1e12。NaN、Infinity、bool冒充数字、超大整数等均抛`ValueError`。
- 整个结果以ASCII转义JSON序列化后不得超过2000000个字符，保证是有限、标准JSON。非JSON类型和额外字段均拒绝。

## 样例与验证

`example_result(method_id)`返回固定虚构测试夹具，根`facts`为空，summary明确为虚构测试。只用于测试和开发演示，不作为生产默认输出、模型失败回退或已生成业务结果。

公共接口已按TDD分段验证：先有缺失模块的红灯，再有写作合同绿灯；完整目录先因缺16项失败，再17项通过；引用反例先出现6项失败，再通过；超大整数边界先出现两个OverflowError，再修为稳定`ValueError`。与现有Store合同对齐时，先新增21个上限/修订target反例全部失败，再收紧对应schema使其通过。随后用Cf、Cs、异常控制字符三个子反例先红后绿，保留正常换行/回车/制表符正例。互动合同先以DM草稿合法正例产生红灯，再补渠道/对象结构使其通过，同时验证未知渠道和伪造“收件人已验证”字段被拒绝。本机Python3.12运行12项测试全部通过，覆盖17方法正例、目录隔离、原文/推断证据、嵌套引用、互动渠道、未知/发布状态键、必填字段、枚举、长度、列表、时间、字符和数值边界、非JSON类型、返回深拷贝。

执行：在本目录用Python3.10+运行`python -B -m unittest discover -s tests -p test_methods.py -v`。本轮已执行Windows Python3.12；没有声称其他运行环境或真实模型/平台链路已验收。
