# 内容任务修复：总控派生版合同

源文件：stage-02/project/work/ui-native-r57/content_workflow.py。

原作者候选 content-workflow-extension 不修改。原 SHA b3cf0ba0162aad94bf885298137b565793b3adf41a1af713cf3c43b63c19d22c；本次派生 SHA 802ec2e4640f03a8dc3a912ff48a6d263f55f64a4ee6ee40bfd466aeae297aff。仅本文件变更。Native 固定 pin、动作白名单、host 和 UI 由各自负责人接入。

## 新动作

均沿原 Native cookie/Origin/CSRF/当前门店/员工/账号归属与原 Store。HTTP data 中 storeId 由 Native 提取，其余传组件。

- `content_task_archive` 写：`storeId,accountId,platform,expectedRevision,requestId,taskId`。result 为 `{taskId,archived:true,archivedAt,alreadyArchived:boolean}`。返回正常 `{workspace,result,receipt}`，活动 tasks/artifacts 移出对应项，`workspace.workflow.archivedTaskCount` 增加；重复归档不加数量。仅同账号同员工同门店可见。
- `content_task_history` 读：`storeId,accountId,platform` 加可选 `taskId`，或可选 `beforeRevision,limit`。**不收 expectedRevision/requestId**。始终返回 `{workspace,result}`。
- 历史列表：limit 默认20，最大50；beforeRevision 为正整数。result 为 `{items:[{task:<不含input的原task>,archivedAt,archivedRevision}],hasMore,nextBeforeRevision}`。按归档 revision 倒序；未完时以 nextBeforeRevision 继续；没有下一页时为 null。
- 历史详情：taskId 与分页参数互斥。result 为 `{task:<含原input>,artifact:<原产物或null>,archivedAt,archivedRevision,readOnly:true}`。

归档不改原任务 state；界面独立“已归档”区只读，不提供 run/apply。prepared 归档意味着取消当前准备任务，重新准备需新任务。running、unknown、requiresReconciliation 拒绝 `CONTENT_TASK_RECONCILIATION_REQUIRED` 409；归档后新键 run/apply 拒绝 `CONTENT_TASK_ARCHIVED` 409。跨账号历史详情返回 `CONTENT_RECORD_MISSING`，不泄漏归属信息。

原 requestId 的读取与精确重放仍保留：`content_workspace_read(requestId)` 可核对；原 action/payload 原样重放返回原 result，绝不重复模型派发或恢复任务。换 payload/action 重用旧键仍 `CONTENT_REQUEST_CONFLICT`。所有写继续 CAS 与写后 authority 检查。

## 原 Store 持久化与依赖

原 SQLite records 新增三个 entity：content_workflow_archive_v1、content_workflow_artifact_index_v1、content_workflow_receipt_v1，不新增数据库或账号系统。记录键包含原 workspaceId；每条校验 scope、owner、digest。归档完整 task/input/artifact，活动工作区移除相应项；回执转入永久 journal，与工作区更新同事务。普通旧内容动作也能核对转移后的旧键。

引用仍可解析归档的有效产物；原稿、选题、人设、方案、审核、导出包不删除。生成包、修订稿继续追溯原任务证据。已应用产物作为已接受历史快照，不因应用人设本身改变当前人设而失效。

准备、运行前、运行回写、采用前均核对依赖：拒绝 candidate_stale、非成功任务、失效上下文、摘要/关联不一致；有界 DAG 检查最多12层、64次不同校验，拒绝环。已应用历史保留，明确失效祖先依然拒绝。

## 证据范围

- RED.log：原作者版本复现失效产物未拒绝与缺少归档动作。
- 55-regression.log：原作者55个测试逐条未修改，派生版全部通过。
- repair-tests.log：12个新增真实 Store 公共接口测试通过，含100归档再100、跨scope/CAS、unknown/running、写后撤权回滚、重启后旧键、引用不丢、原审核包、环检测。
- test_repair_http.py / HTTP-RESULTS.json：基于独立审查13组实际 Native HTTP harness 增量转为14组正向回归，全部通过。包含中央撤店P1回归，活动/归档失效产物拒绝，真实HTTP归档100再新增100，历史分页，跨scope，unknown/running，归档后新稿/重新审核/新包保留原始引用。测试前后源SHA一致，实际Native认证、Origin、CSRF、同Store、锁外合成模型链均使用现有产品实现。

HTTP测试时 Native SHA 8d2c7e4d5516a4cad4f40064a8240ee9d3bcc47249a68174c2e7d93b3d9035e4，host SHA ad5e5171e3977f602b5df87560f8215d4b900e585420f11c47bc9263df9a39d9。原请求留存在同一 SQLite 数据库中，完整备份应包含整个原 Store 的 records，而非只抽取活动 workspace 一行。

本次只解决活动任务容量与依赖失效。资料100条/总文本50万字、方案250、内容包100、原业务各集合500等既有独立容量仍保留，未宣称无限历史容量、真实模型质量、平台操作或已安装交付。归档是保留历史的本地操作，非平台发布。
