# 知识文档与证据检索模块

已完成独立Python模块，供现有ContentWorkbench/同一Store调用。14项公开接口测试通过，Python3.12.9；未修改ContentWorkbench、生产、旧组件库或既有研究材料。没有模型、网络、文件抓取、SQLite连接或第二知识库数据库。

## 实际复用与最小闭包

- 原项目：veeicwgy/ip-publisher，固定提交`2121445098d46cfa2947e3088f84b1255fa8fa13`。
- 原文件：`ip_publisher/kb/normalize.py`，实际调用`normalize_text`与`extract_keywords`。MIT原文本保存在`workflow_vendor/LICENSE`。
- 随包只需`workflow_knowledge.py`和`workflow_vendor/normalize.py`、`workflow_vendor/LICENSE`、`workflow_vendor/PINS.json`，没有第三方依赖。
- `normalize.py`固定SHA256：`d17449da9cf2942b0e0cc1bbabe29b4793daa6af3dff67b918fd4850e8e33f93`；MIT文本SHA256：`b578bcab423726caace355bf28d4b62eaa7762c3fde9612e7de70791a510c3bb`。
- 根模块源码内固定repo/commit/两个摘要；PINS只用于一致性核对，不能改PINS给修改后的源码自授权。加载时读取并核验代码与许可，直接compile/exec已核验的同一份字节，避免再读一次源码。
- 固定组件被修改、缺失或PINS偏离时，新的模块加载抛`VendorIntegrityError('knowledge_vendor_integrity_failed')`。已经加载的进程继续运行内存里已核验的代码，不承诺热监控；升级应走代码审查、固定摘要更新和重启。

## 公开函数

```python
from workflow_knowledge import import_document, search, check_citations

document = import_document('入住须知', '古北公寓允许养猫，需提前登记。', 'fact', '虚构手册')
# 主体自行保存document到同一Store。下次查询只传该企业/账号有权读取的文档。
hits = search([document], '古北公寓养猫', limit=5)
validated = check_citations([{'evidenceId': hits[0]['evidenceId'], 'quote': '需提前登记'}], hits)
```

`import_document(title,text,kind,source_label) -> dict`

- `title`为非空字符串，最多120字符；`text`非空白，最多100000字符；`kind`只能`fact`或`hypothesis`；`source_label`可空，最多500字符，只作显示标签，即使内容像URL或本机路径也不访问。
- 输出`id,title,text,kind,sourceLabel,sha256,chunks`。文档ID是`doc-`加原始text UTF-8的完整SHA256。相同正文即相同ID，标题、来源标签和事实/假设标签不改变ID；主体保存时处理重复导入/版本与标签更新，不同时向search传两个相同ID文档。
- 分片保留全部原字符，每片最多500字符；100000字符产生200片，少于500片上限。片段字段为`id,text,start,end,sha256`，片ID形如`doc-<sha>:c001`。
- `start`从0开始、`end`不含终点，都是**Python Unicode字符坐标**，满足`chunk.text == document.text[start:end]`。没有先normalize再伪装原文位置。浏览器如用JavaScript UTF-16下标做高亮，需要转换字符坐标，不能把Emoji当一个UTF-16单元。

`search(documents:list,query,limit=5) -> list[dict]`

- 只读取传入文档，不读取模块全局知识库、用户目录、文件、网络或数据库；不修改传入对象。总文档数由主体在同Store按100/200等配额限制并按权限选取。
- `query`最多500字符；空白查询返回空列表。`limit`为1—20的整数，bool不当作整数接受。
- 对原始文档及每片摘要、ID、连续坐标和标签进行核对，持久化数据被改坏时抛`KnowledgeError`，不默默用错误证据。重复文档ID明确拒绝。
- 上游归一化只用于匹配视图，原文不改写。上游关键词提取之外补中文二字词与单字查询，支持无空格中文问题；按片段、标题和完整查询匹配加权，稳定排序，无命中时不回退无关文档。
- 每项输出恰为`evidenceId,documentId,title,text,start,end,kind,score,documentSha256`。结果是复制出的当前原文证据。score是词面相关度，不是事实真实性或模型置信度；它不是向量检索或语义理解服务。

`check_citations(citations,evidence) -> list[dict]`

- citations最多20项，每项为当前`evidenceId`字符串，或`{evidenceId,quote}`。evidence为本次search结果列表，可最多500项。
- 只接受当前结果中存在的引用；quote如提供，必须是该原始片段里的非空连续原句，最多500字符。未知、重复、额外字段、错误坐标/摘要/标签或非有限/无界score明确拒绝。
- 返回复制后的证据行，提供quote时附quote；始终保留原来的`kind`，不把hypothesis升级为fact。
- 此函数校验当前传入证据的归属与引用文字，不替代主体的企业/账号权限或真实来源审核。fact也是调用方的材料类别，不表示模块已证明事实为真。

## 主体接入与失败处理

普通输入合同错误抛`KnowledgeError(ValueError)`，只含固定错误码，不把正文、来源或凭据写进错误。组件完整性问题在导入时抛`VendorIntegrityError(RuntimeError)`。由主体转成可理解的界面状态，保留现有文档与任务，不能因组件不可用清库或自动重新分析/计费。

本模块不构造AI文章或模板文章。检索证据可交给主体现有生成通道；生成结果引用须用同一批hits核对，并保留原帖事实、假设、来源与版本。

## 验证

测试边界由本轮主窗口任务明确指定，无额外确认。使用公开函数，不访问生产数据。命令：在本扩展目录，以Python执行`-X utf8 -B -m unittest discover -s tests -p test_knowledge.py -v`。

14项测试覆盖原文/CRLF/空白和坐标、已知摘要与稳定ID、100000字符边界、类型与长度拒绝、中文相关片段、英文空白归一化但原文不变、仅传入范围检索、输入不变、损坏证据、引用真实性与假设标签、文件/网络禁止条件、组件及PINS篡改和引用分数溢出拒绝。

先红后绿日志均在`logs/knowledge-*.log`：import、chinese-search、citations、citation-score-bound分别留失败证据；最终`knowledge-GREEN-final.log`记录14通过、0失败。文件/网络禁止是测试条件，不是操作系统安全沙箱。真实客户端集成、UI和同Store存取验收仍由主窗口完成。
