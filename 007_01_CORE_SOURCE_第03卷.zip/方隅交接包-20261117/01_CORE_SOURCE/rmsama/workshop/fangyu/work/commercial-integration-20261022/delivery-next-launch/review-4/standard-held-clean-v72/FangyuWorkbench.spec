# -*- mode: python ; coding: utf-8 -*-
from PyInstaller.utils.hooks import collect_all
from PyInstaller.utils.hooks import copy_metadata

datas = []
binaries = []
hiddenimports = ['__future__', 'argparse', 'base64', 'binascii', 'calendar', 'collections', 'concurrent', 'contextlib', 'contextvars', 'copy', 'csv', 'ctypes', 'dataclasses', 'datetime', 'decimal', 'email', 'enum', 'errno', 'fcntl', 'fractions', 'functools', 'glob', 'hashlib', 'hmac', 'html', 'http', 'importlib', 'inspect', 'io', 'ipaddress', 'json', 'logging', 'math', 'mimetypes', 'msvcrt', 'ntpath', 'operator', 'os', 'pathlib', 'platform', 'queue', 'random', 're', 'secrets', 'shutil', 'signal', 'socket', 'socketserver', 'sqlite3', 'ssl', 'stat', 'struct', 'subprocess', 'sys', 'tempfile', 'threading', 'time', 'traceback', 'types', 'typing', 'unicodedata', 'urllib', 'uuid', 'warnings', 'webbrowser', 'winreg', 'wsgiref', 'xml', 'zipfile', 'zlib']
datas += copy_metadata('pywebview')
tmp_ret = collect_all('webview')
datas += tmp_ret[0]; binaries += tmp_ret[1]; hiddenimports += tmp_ret[2]
tmp_ret = collect_all('pythonnet')
datas += tmp_ret[0]; binaries += tmp_ret[1]; hiddenimports += tmp_ret[2]
tmp_ret = collect_all('clr_loader')
datas += tmp_ret[0]; binaries += tmp_ret[1]; hiddenimports += tmp_ret[2]
tmp_ret = collect_all('PIL')
datas += tmp_ret[0]; binaries += tmp_ret[1]; hiddenimports += tmp_ret[2]
tmp_ret = collect_all('cryptography')
datas += tmp_ret[0]; binaries += tmp_ret[1]; hiddenimports += tmp_ret[2]
tmp_ret = collect_all('tuf')
datas += tmp_ret[0]; binaries += tmp_ret[1]; hiddenimports += tmp_ret[2]
tmp_ret = collect_all('securesystemslib')
datas += tmp_ret[0]; binaries += tmp_ret[1]; hiddenimports += tmp_ret[2]
tmp_ret = collect_all('httpx')
datas += tmp_ret[0]; binaries += tmp_ret[1]; hiddenimports += tmp_ret[2]


a = Analysis(
    ['C:/积木软件工坊/项目/方隅公寓客户版/work/commercial-integration-20261022/delivery-next-launch/review-4/standard-held-clean-v72/standard_entry.py'],
    pathex=[],
    binaries=binaries,
    datas=datas,
    hiddenimports=hiddenimports,
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    noarchive=False,
    optimize=0,
)
pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name='FangyuWorkbench',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    console=False,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon=['C:/积木软件工坊/项目/方隅公寓客户版/work/parallel-integration-20261018/final-integration/candidate-unified-v72/project/work/app/src/resources/brand.ico'],
)
coll = COLLECT(
    exe,
    a.binaries,
    a.datas,
    strip=False,
    upx=True,
    upx_exclude=[],
    name='FangyuWorkbench',
)
