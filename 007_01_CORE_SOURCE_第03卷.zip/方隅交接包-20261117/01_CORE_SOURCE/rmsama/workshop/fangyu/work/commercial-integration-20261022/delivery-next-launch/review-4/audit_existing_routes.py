"""Read-only source/closure audit; output is restricted to this review folder.

No business-module imports, HTTP, platform/model actions, installers, builds,
process starts/stops, production config parsing, or native writes.
"""
from pathlib import Path, PurePosixPath
from collections import Counter
from datetime import datetime, timezone
import ast
import hashlib
import json
import stat
import sys

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
P = Path('C:/积木软件工坊/项目/方隅公寓客户版')
W = P / 'work/commercial-integration-20261022'
F = P / 'work/parallel-integration-20261018/final-integration'
N = P / 'work/ui-native-r57'
EXPECTED = W / 'delivery-next-launch/review-4'
assert HERE == EXPECTED

PINS = {
    'work/ui-native-r57/run_workbench.py': 'c55ed17e0b06b37765942e6eaf5f4506d16a4c92fc55d96308bf8069d00feba4',
    'work/ui-native-r57/FROZEN.json': 'fbd4f3d810658b4f571e41c7fe06d0771111900c6eab941229888a7a5a693702',
    'work/ui-native-r57/state/production-workspace.json': '14cf53964f5d44d123e989805ea741669ab3f05054e730ddcb299a0aac51a9cb',
    'work/parallel-integration-20261018/integration/entry/install_canonical_delegation.py': '9909f60d16ad3eaed54b9f97ea0d275ad38510c679ba651ce05af44d920ed0f6',
    'work/commercial-integration-20261022/delivery-next-launch/install_next_launch.DRAFT.py': '0fb1fd17be8518541123232666e9f659c0a1b34f39f1ac2c24aacaade986a3d4',
}


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def plain_read(path):
    for item in (path, *path.parents):
        info = item.lstat()
        if item.is_symlink() or getattr(info, 'st_file_attributes', 0) & 0x400:
            raise RuntimeError('Reparse path refused: ' + path.name)
    before = path.stat()
    if not stat.S_ISREG(before.st_mode) or before.st_nlink != 1:
        raise RuntimeError('Non-plain file refused: ' + path.name)
    raw = path.read_bytes()
    after = path.stat()
    if (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns) != (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns):
        raise RuntimeError('Read changed: ' + path.name)
    return raw


def parsed(path):
    return json.loads(plain_read(path).decode('utf-8-sig'))


def group(path):
    parts = PurePosixPath(path).parts
    if parts[:3] == ('work', 'ui-runtime-r55', 'src'):
        return 'work/ui-runtime-r55/src'
    if parts[:4] == ('work', 'ui-runtime-r55', 'work', 'runtime'):
        return 'work/ui-runtime-r55/work/runtime'
    if parts[:3] == ('work', 'ui-native-r57', 'releases'):
        return 'work/ui-native-r57/releases'
    return '/'.join(parts[:3])


def manifest_summary(candidate):
    base = F / candidate
    raw = plain_read(base / 'UNIFIED-PINS.json')
    manifest = json.loads(raw.decode('utf-8-sig'))
    rows = manifest['files']
    counts = Counter(group(row['path']) for row in rows)
    forbidden_binary = [row['path'] for row in rows if PurePosixPath(row['path']).name.lower() in ('ffmpeg.exe', 'ffprobe.exe')]
    models = [row['path'] for row in rows if PurePosixPath(row['path']).suffix.lower() in ('.safetensors', '.gguf', '.ckpt', '.pt', '.pth', '.onnx')]
    staged = parsed(base / 'STAGED.json')
    release = Path(staged['release'])
    release_manifest = parsed(release / 'RELEASE.json')
    return {
        'candidate': candidate, 'manifestSha256': digest(raw), 'fileCount': len(rows),
        'bytes': sum(row['bytes'] for row in rows), 'groups': dict(sorted(counts.items())),
        'releaseId': staged['release_id'], 'releaseSha256': digest(plain_read(release / 'RELEASE.json')),
        'externalHostRuntime': manifest.get('external_host_runtime'),
        'ffmpegBinariesInClosure': forbidden_binary, 'modelWeightsInClosure': models,
        'releaseManifestKeys': sorted(release_manifest),
        'scope': 'Metadata inventory only; this is not acceptance or final-version selection.',
    }


def verify_v65():
    base = F / 'candidate-unified-v65'
    raw = plain_read(base / 'UNIFIED-PINS.json')
    expected = 'c6bc35bc5e2b44c437bf9b8262897d33faf4a5a5c7c1b5f859be130589735268'
    if digest(raw) != expected:
        raise RuntimeError('v65 recovery manifest differs')
    rows = json.loads(raw.decode('utf-8-sig'))['files']
    if len(rows) != 2777:
        raise RuntimeError('v65 recovery count differs')
    seen = set()
    for row in rows:
        rel = PurePosixPath(row['path'])
        if rel.is_absolute() or '..' in rel.parts or ':' in str(rel) or '\\' in str(rel) or str(rel) in seen:
            raise RuntimeError('Invalid v65 member')
        seen.add(str(rel))
        body = plain_read(base / 'project' / rel)
        if len(body) != row['bytes'] or digest(body) != row['sha256']:
            raise RuntimeError('v65 recovery member differs: ' + str(rel))
    return {'candidate': 'candidate-unified-v65', 'manifestSha256': expected, 'filesVerified': len(seen), 'intact': True}


def source_fact(relative):
    raw = plain_read(P / relative)
    tree = ast.parse(raw, filename=relative)
    functions = [node.name for node in ast.walk(tree) if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))]
    return {'path': relative, 'sha256': digest(raw), 'bytes': len(raw), 'functions': functions}


def main():
    pinned = {}
    for relative, expected in PINS.items():
        actual = digest(plain_read(P / relative))
        if actual != expected:
            raise RuntimeError('Protected pin differs: ' + relative)
        pinned[relative] = actual
    draft = ast.parse(plain_read(W / 'delivery-next-launch/install_next_launch.DRAFT.py'))
    values = {}
    for node in draft.body:
        if isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name) and node.targets[0].id in ('ACCEPTED', 'INSTALLATION_REVIEWED'):
            values[node.targets[0].id] = ast.literal_eval(node.value)
    if values != {'ACCEPTED': {}, 'INSTALLATION_REVIEWED': False}:
        raise RuntimeError('Sealed draft gates changed')
    sources = [source_fact(relative) for relative in (
        'work/packaging/build_release.py', 'work/packaging/installer.py',
        'work/assistant/build_launcher.py',
        'work/new-ui-direct-release/release-plan/build_public_release.py',
        'work/parallel-integration-20261018/final-integration/freeze_unified.py',
    )]
    status = {
        'schema': 'fangyu-next-launch-readonly-route-review-v1',
        'createdAtUtc': datetime.now(timezone.utc).isoformat(),
        'status': 'PASS_READONLY_ROUTE_AUDIT_FINAL_PINS_PENDING',
        'protectedPins': pinned, 'sealedDraftGates': values,
        'v65RecoveryClosure': verify_v65(),
        'inventoryV70Nonfinal': manifest_summary('candidate-unified-v70'),
        'matureExistingSources': sources,
        'operationalGates': {
            'finalCandidateChosen': False, 'installationReviewed': False,
            'candidatePrepared': False, 'canonicalInstalled': False,
            'buildOrInstallerExecuted': False, 'processOrAppAction': False,
            'liveBindingParsed': False, 'liveBusinessDataRead': False,
            'externalPlatformOrCloudRequest': False, 'localModelOrGpuLoaded': False,
            'writesOutsideThisReviewFolder': False,
        },
    }
    target = HERE / 'READONLY-ROUTE-AUDIT.json'
    with target.open('x', encoding='utf-8') as stream:
        json.dump(status, stream, ensure_ascii=False, indent=2)
        stream.write('\n')
    print(json.dumps({
        'status': status['status'], 'v65VerifiedFiles': status['v65RecoveryClosure']['filesVerified'],
        'v70NonfinalInventoryFiles': status['inventoryV70Nonfinal']['fileCount'],
        'v70FfmpegBinaries': len(status['inventoryV70Nonfinal']['ffmpegBinariesInClosure']),
        'v70ModelWeights': len(status['inventoryV70Nonfinal']['modelWeightsInClosure']),
        'result': str(target), 'nativeWrites': 0, 'install': False,
    }, ensure_ascii=False))


if __name__ == '__main__':
    main()
