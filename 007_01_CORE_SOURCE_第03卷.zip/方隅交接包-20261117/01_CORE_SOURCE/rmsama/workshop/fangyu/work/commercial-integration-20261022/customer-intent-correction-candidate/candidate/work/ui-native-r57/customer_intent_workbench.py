"""Narrow local bridge to the original Business intent_correct workflow."""
from types import SimpleNamespace
from assistant.business import BusinessExecutor
from assistant.intent_correction import (IntentCorrectionError,scoped_lead,project,request_key,ENTITY,receipt,ID,cancel)

BASE={'storeId','customerId','leadId','platform'}
SAVE=BASE|{'requestId','expectedVersion','sourceDigest','status','level','reason'}
CANCEL=BASE|{'requestId','requestDigest'}

class IntentCorrectionWorkbench:
    def __init__(self,core,customers,company):
        self.core=core;self.customers=customers;self.company=company
    def context(self,user,store_id,data,*,save=False,cancelling=False):
        if (not isinstance(data,dict) or (set(data)!=CANCEL if cancelling else set(data)!=SAVE if save else set(data) not in (BASE,BASE|{'requestId'}))):
            raise IntentCorrectionError('INTENT_INPUT_INVALID','人工判断参数无效',400)
        if data['storeId']!=store_id:
            raise IntentCorrectionError('INTENT_SCOPE_CHANGED','当前门店已变化，请返回原门店核对',403)
        actor,public,item,person=self.customers.detail_context(user,store_id,data['customerId'],platform=data['platform'])
        if not isinstance(data['leadId'],str) or not ID.fullmatch(data['leadId']) or not any(c['lead_id']==data['leadId'] for c in person['comments']):
            raise IntentCorrectionError('INTENT_COMMENT_UNAVAILABLE','这条评论不属于当前可见客户',404)
        if 'requestId' in data and (not isinstance(data['requestId'],str) or not ID.fullmatch(data['requestId'])):
            raise IntentCorrectionError('INTENT_INPUT_INVALID','操作编号无效',400)
        translated={ {'storeId':'store_id','customerId':'customer_id','leadId':'lead_id','requestId':'request_id',
            'expectedVersion':'expected_version','sourceDigest':'source_digest','requestDigest':'request_digest'}.get(k,k):v for k,v in data.items()}
        with self.core.store.connect() as db:lead,_task=scoped_lead(self.core,actor,translated,db)
        return actor,lead,translated
    def read(self,user,store_id,data):
        with self.core.lock:
            actor,lead,translated=self.context(user,store_id,data)
            prior=None
            if data.get('requestId'):
                prior=self.core.store.get(ENTITY,request_key(actor,data['requestId']))
                if prior and any(prior.get(k)!=translated[k] for k in ('customer_id','lead_id','store_id','platform')):
                    raise IntentCorrectionError('INTENT_REQUEST_CONFLICT','原操作不属于当前客户或门店',409)
            result=project(self.core,actor,lead,translated,record=prior)
            if data.get('requestId') and not prior:result['receipt']={'requestId':data['requestId'],'state':'not_found'}
            return result
    def correct(self,user,store_id,data):
        with self.core.lock:
            try:
                actor,lead,translated=self.context(user,store_id,data,save=True)
            except IntentCorrectionError:raise
            except Exception as error:
                raise IntentCorrectionError(getattr(error,'code','INTENT_SCOPE_CHANGED'),
                    str(error) if hasattr(error,'code') else '原评论或当前员工权限无法核对',getattr(error,'status',403)) from None
            # No service/device preparation and no platform login is involved.
            # The original executor reads the authenticated saved employee and
            # routes intent_correct to the original AIWorkflow.correct method.
            executor=BusinessExecutor(SimpleNamespace(core=self.core,company=self.company),
                self.company['managedWorkspace']['environment_id'],self.company['id'],actor['username'])
            result=executor({'owner':actor['username'],'principal':{'username':actor['username'],'role':actor['role']},
                'action':'intent_correct','data':translated})
            try:
                fresh,current,_=self.context(user,store_id,data,save=True)
                return project(self.core,fresh,current,translated,record=result['record'])
            except Exception as exc:
                raise IntentCorrectionError('INTENT_RESULT_UNCONFIRMED','判断已保存，返回前范围变化，请查询原操作',409,
                    mutation_committed=True) from exc
    def cancel(self,user,store_id,data):
        with self.core.lock:
            try:actor,lead,translated=self.context(user,store_id,data,cancelling=True)
            except IntentCorrectionError:raise
            except Exception as error:
                raise IntentCorrectionError(getattr(error,'code','INTENT_SCOPE_CHANGED'),
                    str(error) if hasattr(error,'code') else '原评论或员工权限无法核对',getattr(error,'status',403)) from None
            result=cancel(self.core,actor,translated)
            try:
                fresh,current,_=self.context(user,store_id,data,cancelling=True)
                return project(self.core,fresh,current,translated,record=result['record'])
            except Exception as exc:
                raise IntentCorrectionError('INTENT_RESULT_UNCONFIRMED','原操作核对结果未返回，请查询原编号',409,
                    mutation_committed=True) from exc
