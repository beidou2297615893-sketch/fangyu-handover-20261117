---
name: xhs-growth-review
description: >-
  Diagnose Xiaohongshu carousel and video performance separately using exposure, click, retention, completion, and
  engagement data compared to the account's own history. Produces one-variable follow-up experiments. Use for 流量复盘,
  笔记诊断, 视频数据分析, 图文数据复盘.
---

# Xiaohongshu Growth Review

Turn post data into a bounded diagnosis and a single next experiment. Read `references/format-benchmarks.md`.

## Workflow

1. Record `format`: `carousel`, `image`, or `video`. Do not mix formats in one baseline.
2. Collect metrics using `references/metrics-schema.md`. Preserve missing values as missing.
3. Require at least three comparable posts **in the same format** for group claims; prefer five or more.
4. Run `scripts/diagnose_metrics.py` when JSON input is available.
5. Compare target vs account median for that format and topic when possible.
6. Diagnose earliest supported funnel break (see format-benchmarks).
7. Route the fix to exactly one downstream skill; do not recommend multi-variable rewrites.
8. Propose DNA updates per the promotion rules below; never edit `account-dna.md` silently.

## Promoting a learning into account DNA

A single post never changes the DNA. Promote only when all three hold:

- the same signal repeated across **3+ posts in the same format**
- the direction survived at least one deliberate counter-test
- it changes a decision (pillar, format, hook style, avoid list), not just a number

When promoting, output a diff block for the user to approve — do not write the file directly:

```
DNA 更新提案（需你确认）
段落: 内容支柱 2
现状: 工具测评
建议: 工具测评（限定为「我实际用满一周的工具」）
依据: 3 篇同格式笔记，未满一周的测评收藏中位数低 40%
置信度: medium
```

Anything below the bar goes into `Current hypotheses` with a review date instead.

## Funnel stages

- Distribution — exposure weak vs baseline
- Click — exposure exists but CTR weak
- Early retention — carousel fold / video 3s weak
- Completion/value — video completion or carousel save value weak
- Interaction — comments, profile visits, follows weak

## Fix routing

| Bottleneck | First skill to rerun |
|---|---|
| exposure | `xhs-account-dna` or `xhs-topic-radar` |
| click | title refresh in `xhs-note-writer` + `xhs-visual-lab` |
| early retention | `xhs-video-director` opening OR carousel fold rewrite in `xhs-note-writer` |
| completion/value | tighten proof path in production skill |
| interaction | CTA/proof/discussion angle in `xhs-note-writer` |

## Rules

- Never diagnose shadow banning from one weak post.
- Do not compare raw likes across very different exposures.
- Video-only metrics stay missing for carousel posts.
- Distinguish facts, calculations, and hypotheses.

## Output

Return evidence table, format, earliest supported bottleneck, confidence, missing data, keep/change list, one downstream skill to rerun, and next single-variable experiment.
