"""Device-local original AI keys. Metadata only; cloud ledger remains authoritative."""
import hashlib
import json
import re
import threading
import uuid
from copy import deepcopy
from datetime import datetime, timezone


class AIRequestReview(ValueError):
    code = 'PRODUCT_REQUEST_UNKNOWN'


def _digest(value):
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True,
                                    allow_nan=False, separators=(',', ':')).encode()).hexdigest()


def _now():
    return datetime.now(timezone.utc).isoformat()


class LocalAIAttempts:
    """Persist before dispatch, query only the old key after an uncertain outcome.

    A status read never frees money, grants new entitlement, or proves an old
    untracked request unexecuted. A retained result is re-read using the SAME
    original key, then subjected to the workflow's existing validation/CAS.
    """
    def __init__(self, core, cloud, *, host_context=lambda: {}):
        self.core, self.cloud, self.host_context = core, cloud, host_context
        self.lock = threading.RLock()

    def _principal(self, user):
        if not isinstance(user, dict) or not all(isinstance(user.get(k), str) and user[k]
                                                for k in ('id', 'tenant_id', 'username', 'role')):
            raise AIRequestReview('当前员工身份需核对，未开始新分析')
        saved = self.core.store.get('users', user['id'])
        fields = ('id', 'tenant_id', 'username', 'role', 'cloud_bound')
        if (not saved or saved.get('disabled') or
                any(saved.get(k) != user.get(k) for k in fields)):
            raise AIRequestReview('当前员工身份已变化，未开始新分析')
        host = self.host_context()
        if not isinstance(host, dict):
            raise AIRequestReview('当前设备归属需核对，未开始新分析')
        return _digest({k: saved.get(k) for k in fields}), _digest(host)

    def _owned(self, user, row):
        return row and row.get('tenant_id') == user['tenant_id'] and row.get('owner') == user['username']

    def call(self, user, operation, payload, *, context, lead_ids=(), explicit_new=False, source_binding=None, existing_only=False):
        if operation not in ('intent_analyze', 'keyword_suggest') or not isinstance(payload, dict):
            raise AIRequestReview('不支持此分析操作')
        if ('request_id' in payload or type(explicit_new) is not bool
                or type(existing_only) is not bool or existing_only and explicit_new):
            raise AIRequestReview('分析编号只能由当前本机原操作提供')
        if source_binding is not None:
            from .source_intent_analysis import _ArchivedSourceBinding
            if type(source_binding) is not _ArchivedSourceBinding or operation != 'intent_analyze':
                raise AIRequestReview('来源分析需要原服务器捕获')
            source_binding.check(user)
            context = {**context, 'archived_source': source_binding.context_digest}
        principal, host = self._principal(user)
        normalized = {k: v for k, v in payload.items() if k not in ('expected_revision', 'expected_rules_version',
            'expected_policy_revision', 'expected_policy_digest', 'expected_effective_facts_digest')}
        ident = _digest([user['tenant_id'], user['username'], operation, normalized])
        context_digest = _digest(context)
        lead_hashes = sorted({_digest([user['tenant_id'], user['username'], item]) for item in lead_ids})
        if len(lead_hashes) > 50:
            raise AIRequestReview('本批评论数量需核对')
        with self.lock, self.core.lock:
            row = self.core.store.get('ai_attempts', ident)
            if existing_only and (not row or row.get('state')=='not_dispatched'):
                raise AIRequestReview('原批请求尚未匹配，评论与断点已保留；未开始新分析')
            if row and (not self._owned(user, row) or row.get('principal_digest') != principal or
                        row.get('host_digest') != host or row.get('operation') != operation):
                raise AIRequestReview('原分析的员工或设备范围已变化，请核对原请求')
            # Changing a batch must not bypass a possibly paid attempt for its
            # overlapping comments. This stores hashes, never original text/IDs.
            if lead_hashes:
                for previous in self.core.store.list('ai_attempts', user['tenant_id']):
                    if (previous.get('id') != ident and self._owned(user, previous) and
                            previous.get('state') in ('submitted', 'unknown', 'response_received') and
                            set(lead_hashes).intersection(previous.get('lead_digests') or [])):
                        raise AIRequestReview('本批包含结果待核对的原评论，未开始新分析')
            previous = deepcopy(row)
            context_changed = bool(row and row.get('context_digest') != context_digest)
            if row and row.get('state') == 'not_dispatched' and explicit_new:
                row = None
            elif context_changed and row.get('state') == 'validated':
                if explicit_new:
                    row = None
                else:
                    raise AIRequestReview('原分析配置或核验规则已变化，需先核对原请求')
            if not row:
                row = {'id': ident, 'tenant_id': user['tenant_id'], 'owner': user['username'],
                       'operation': operation, 'request_id': str(uuid.uuid4()),
                       'principal_digest': principal, 'host_digest': host,
                       'input_digest': _digest(normalized), 'context_digest': context_digest,
                       'lead_digests': lead_hashes, 'state': 'prepared', 'created_at': _now()}
            original = row['request_id']
        if previous and previous.get('state') == 'not_dispatched' and not explicit_new:
            raise AIRequestReview('原操作本轮未开始，需明确重新操作；未自动请求')
        if previous and (previous.get('state') in ('submitted', 'unknown', 'known_unbilled') or
                         context_changed and previous.get('state') not in ('validated', 'not_dispatched')):
            status = self.cloud(user, 'ai_attempt_status', {'operation_kind': operation, 'request_id': original})
            self._assert_context(user, principal, host)
            if (not isinstance(status, dict) or status.get('request_id') != original or
                    status.get('operation_kind') != operation or status.get('read_only') is not True or
                    status.get('retry_allowed') is not False or status.get('billing_verified') is not False or
                    type(status.get('execution_confirmed')) not in (bool, type(None)) or
                    type(status.get('reservation_retained')) not in (bool, type(None)) or
                    type(status.get('result_available')) is not bool or
                    type(status.get('requires_revalidation')) is not bool or
                    (status.get('execution_kind') not in ('unknown','known_unbilled','cache_hit','provider_result') and
                     not (status.get('state') in ('unknown','legacy_untracked') and status.get('execution_kind') is None)) or
                    status.get('state') not in ('unknown','legacy_untracked','known_unbilled','succeeded','completed_no_result')):
                raise AIRequestReview('原分析核对回执无效，未重复请求')
            if (status.get('state') == 'known_unbilled' and status.get('execution_confirmed') is False
                    and status.get('reservation_retained') is False and status.get('result_available') is False
                    and status.get('execution_kind')=='known_unbilled' and explicit_new):
                # Only this explicit new operation can replace a proved-unbilled
                # attempt. Never interpret legacy_untracked/unknown as unbilled.
                row['request_id'] = str(uuid.uuid4())
                row['previous_request_id'] = original
                row['previous_resolution'] = 'known_unbilled'
                row['context_digest'] = context_digest
                original = row['request_id']
            elif not (not context_changed and status.get('state') == 'succeeded' and status.get('execution_confirmed') is True and
                      status.get('result_available') is True and status.get('requires_revalidation') is False):
                raise AIRequestReview('原分析结果尚未核对，保留原编号与预留；未重复请求')
        self._assert_context(user, principal, host)
        submission = str(uuid.uuid4())
        first_dispatch = not previous or original != previous.get('request_id')
        with self.lock, self.core.lock, self.core.store.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            self._assert_transaction_context(db, user, principal, host)
            found = db.execute('SELECT body FROM records WHERE entity=? AND id=?', ('ai_attempts', ident)).fetchone()
            latest = json.loads(found['body']) if found else None
            if latest and previous and latest != previous:
                raise AIRequestReview('原分析记录已变化，请核对当前操作')
            if latest and not previous:
                raise AIRequestReview('相同分析正在处理，请核对原请求')
            if previous and not latest:
                raise AIRequestReview('原分析记录已缺失，请核对原请求')
            # The initial scan is only an early check. Separate processes/core
            # locks can race, so overlap must be checked under the SAME write
            # transaction as the original-key registration.
            if lead_hashes:
                others = db.execute('SELECT body FROM records WHERE entity=? AND tenant_id=?',
                                    ('ai_attempts', user['tenant_id'])).fetchall()
                for item in others:
                    prior = json.loads(item['body'])
                    if (prior.get('id') != ident and self._owned(user, prior) and
                            prior.get('state') in ('submitted', 'unknown', 'response_received') and
                            set(lead_hashes).intersection(prior.get('lead_digests') or [])):
                        raise AIRequestReview('本批包含结果待核对的原评论，未开始新分析')
            if latest and latest.get('request_id') != original:
                archived = {**latest, 'id': _digest(['history', ident, latest['request_id']])}
                if row.get('previous_request_id') == latest['request_id']:
                    archived['resolution_state'] = row.get('previous_resolution')
                db.execute('INSERT INTO records VALUES(?,?,?,?)', ('ai_attempt_history', archived['id'],
                           user['tenant_id'], json.dumps(archived, ensure_ascii=False)))
            if source_binding is not None:
                source_binding.register_attempt(user, db, row)
            row.update(state='submitted', submission_id=submission, updated_at=_now())
            db.execute('INSERT OR REPLACE INTO records VALUES(?,?,?,?)', ('ai_attempts', ident,
                       user['tenant_id'], json.dumps(row, ensure_ascii=False)))
            self._assert_transaction_context(db, user, principal, host)
        try:
            if source_binding is not None:
                source_binding.dispatch_check(user)
            value = self.cloud(user, operation, {**payload, 'request_id': original, 'submission_id': submission})
            self._assert_context(user, principal, host)
        except Exception as error:
            from integrations import IntegrationError
            proof=getattr(error,'no_dispatch_receipt',None) if isinstance(error,IntegrationError) else None
            trusted_host=self.host_context()
            no_dispatch=bool(first_dispatch and getattr(error,'code',None) in
                ('AI_NOT_CONFIGURED','AI_DAILY_BUDGET','PRODUCT_ANALYSIS_LIMIT') and isinstance(proof,dict) and
                proof.get('contract')=='ai_no_dispatch_v1' and proof.get('no_dispatch') is True and
                proof.get('proof_scope')=='current_submission' and proof.get('request_id')==original and
                proof.get('submission_id')==submission and proof.get('operation_kind')==operation and
                proof.get('actor')==user['username'] and
                isinstance(trusted_host,dict) and trusted_host.get('environment_id') and trusted_host.get('company_id') and
                proof.get('environment_id')==trusted_host['environment_id'] and
                proof.get('company_id')==trusted_host['company_id'] and
                type(payload.get('expected_revision')) is int and
                type(proof.get('config_revision')) is int and
                proof['config_revision']==payload['expected_revision'] and
                isinstance(payload.get('expected_rules_version'),str) and
                proof.get('rules_version')==payload['expected_rules_version'] and
                all(isinstance(proof.get(k),str) and re.fullmatch(r'[a-f0-9]{64}',proof[k])
                    for k in ('input_digest','context_digest')))
            if no_dispatch:
                try:self._assert_context(user,principal,host)
                except AIRequestReview:no_dispatch=False
            self._transition(user, ident, original, submission, principal, host,
                             'not_dispatched' if no_dispatch else 'unknown', proof if no_dispatch else None)
            raise
        if not self._transition(user, ident, original, submission, principal, host, 'response_received'):
            raise AIRequestReview('原分析记录已变化，结果暂不写入')
        return value, {'id': ident, 'request_id': original, 'submission_id': submission, 'principal': principal, 'host': host}

    def _transition(self, user, ident, original, submission, principal, host, state, proof=None):
        with self.lock, self.core.lock, self.core.store.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            found = db.execute('SELECT body FROM records WHERE entity=? AND id=?', ('ai_attempts', ident)).fetchone()
            current = json.loads(found['body']) if found else None
            if (not self._owned(user, current) or current.get('request_id') != original or
                    current.get('submission_id') != submission):
                return False
            if state == 'response_received':
                self._assert_transaction_context(db, user, principal, host)
            if state == 'not_dispatched':
                try:self._assert_transaction_context(db, user, principal, host)
                except AIRequestReview:state,proof='unknown',None
            updated = {**current, 'state': state, 'updated_at': _now()}
            if proof:updated['no_dispatch_proof']=proof
            db.execute('UPDATE records SET body=? WHERE entity=? AND id=? AND tenant_id=?',
                       (json.dumps(updated, ensure_ascii=False), 'ai_attempts', ident, user['tenant_id']))
            return True

    def _assert_context(self, user, principal, host):
        if self._principal(user) != (principal, host):
            raise AIRequestReview('原分析的身份或设备已变化，结果暂不写入')

    def _assert_transaction_context(self, db, user, principal, host):
        found = db.execute('SELECT body FROM records WHERE entity=? AND id=? AND tenant_id=?',
                           ('users', user['id'], user['tenant_id'])).fetchone()
        saved = json.loads(found['body']) if found else None
        fields = ('id', 'tenant_id', 'username', 'role', 'cloud_bound')
        if (not saved or saved.get('disabled') or
                _digest({k: saved.get(k) for k in fields}) != principal or
                _digest(self.host_context()) != host):
            raise AIRequestReview('原分析的身份或设备已变化，结果暂不写入')

    def validated(self, user, receipt):
        self._assert_context(user, receipt['principal'], receipt['host'])
        with self.lock, self.core.lock, self.core.store.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            self._assert_transaction_context(db, user, receipt['principal'], receipt['host'])
            found = db.execute('SELECT body FROM records WHERE entity=? AND id=?', ('ai_attempts', receipt['id'])).fetchone()
            row = json.loads(found['body']) if found else None
            if (not self._owned(user, row) or row.get('request_id') != receipt['request_id'] or
                    row.get('submission_id') != receipt['submission_id']):
                raise AIRequestReview('原分析记录已变化，结果暂不写入')
            db.execute('UPDATE records SET body=? WHERE entity=? AND id=? AND tenant_id=?',
                       (json.dumps({**row, 'state': 'validated', 'updated_at': _now()}, ensure_ascii=False),
                        'ai_attempts', receipt['id'], user['tenant_id']))
            self._assert_transaction_context(db, user, receipt['principal'], receipt['host'])

    def list(self, user, data):
        if set(data) != {'limit'} or type(data['limit']) is not int or not 1 <= data['limit'] <= 50:
            raise AIRequestReview('分析核对清单参数无效')
        principal, host = self._principal(user)
        rows = [row for row in self.core.store.list('ai_attempts', user['tenant_id']) if self._owned(user, row)]
        rows.sort(key=lambda row: row.get('updated_at', row.get('created_at', '')), reverse=True)
        items = [{'request_id': row['request_id'], 'operation_kind': row['operation'],
                  'state': row['state'], 'created_at': row['created_at'],
                  'updated_at': row.get('updated_at', row['created_at']),
                  'scope_matches': row.get('principal_digest') == principal and row.get('host_digest') == host}
                 for row in rows[:data['limit']]]
        self._assert_context(user, principal, host)
        return {'items': items, 'total': len(rows), 'read_only': True, 'executes_model': False,
                'billing_verified': False, 'source': 'local_attempt_metadata'}

    def status(self, user, data):
        if (set(data) != {'request_id'} or not isinstance(data['request_id'], str) or
                not re.fullmatch(r'[0-9a-fA-F-]{36}', data['request_id'])):
            raise AIRequestReview('请核对本机原分析编号')
        principal, host = self._principal(user)
        rows = self.core.store.list('ai_attempts', user['tenant_id'])
        row = next((item for item in rows if self._owned(user, item) and item.get('request_id') == data['request_id']), None)
        if not row or row.get('principal_digest') != principal or row.get('host_digest') != host:
            raise AIRequestReview('原分析的员工或设备范围需核对')
        if row.get('state') == 'not_dispatched':
            # This proof covers ONLY the observed first local submission. The
            # server's legacy/untracked history remains unknown.
            return {'request_id': row['request_id'], 'operation_kind': row['operation'],
                    'state': 'legacy_untracked', 'execution_confirmed': None, 'execution_kind': 'unknown',
                    'result_available': False, 'requires_revalidation': True, 'reservation_retained': None,
                    'read_only': True, 'retry_allowed': False, 'billing_verified': False,
                    'current_submission_no_dispatch': True, 'proof_scope': 'current_submission'}
        result = self.cloud(user, 'ai_attempt_status', {'operation_kind': row['operation'], 'request_id': row['request_id']})
        self._assert_context(user, principal, host)
        if (not isinstance(result, dict) or result.get('request_id') != row['request_id'] or
                result.get('operation_kind') != row['operation'] or result.get('read_only') is not True or
                result.get('retry_allowed') is not False or result.get('billing_verified') is not False or
                result.get('state') not in ('unknown', 'succeeded', 'known_unbilled', 'completed_no_result', 'legacy_untracked') or
                type(result.get('execution_confirmed')) not in (bool, type(None)) or
                type(result.get('reservation_retained')) not in (bool, type(None)) or
                result.get('execution_kind') not in (None, 'cache_hit', 'provider_result', 'known_unbilled', 'unknown') or
                type(result.get('result_available')) is not bool or type(result.get('requires_revalidation')) is not bool):
            raise AIRequestReview('原分析核对回执无效，未重复请求')
        keys = ('request_id', 'operation_kind', 'state', 'execution_confirmed', 'execution_kind',
                'result_available', 'requires_revalidation', 'reservation_retained', 'read_only',
                'retry_allowed', 'billing_verified')
        projected = {key: result.get(key) for key in keys}
        if projected['state'] in ('unknown','legacy_untracked') and projected['execution_kind'] is None:
            projected['execution_kind'] = 'unknown'
        return projected
