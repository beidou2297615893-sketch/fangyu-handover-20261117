---
name: xhs-account-dna
description: >-
  Build or update a durable Xiaohongshu account profile from creator goals, profile screenshots, past posts,
  and performance evidence. Use when defining positioning, audience, content pillars, voice, visual boundaries,
  topic fit, or when other Xiaohongshu workflows need a shared account context. Also use for 账号定位, 账号DNA,
  人设, 内容支柱, 对标定位, 小红书账号规划.
---

# Xiaohongshu Account DNA

Create a reusable account specification that downstream topic, writing, video, visual, and review skills can read.

## Gathering the creator's own posts

This suite has no scraper for the user's own account, and it does not need one — the user has direct
access to their data. Ask for it in this order and stop as soon as there is enough to position:

1. **Creator app export** — 创作中心 › 数据中心, for exposure/CTR/save medians per post
2. **Pasted notes** — 5-20 titles + bodies; ingest the best ones with
   `../xhs-note-writer/scripts/ingest_style_reference.py` so writing skills reuse the same voice
3. **Profile screenshot** — bio, tabs, pinned notes, follower count

Three posts with metrics beat twenty without. Say what is missing rather than inferring around it.
Just One API covers the *market*, not the user's own account — never substitute competitor data for
the creator's own numbers.

## Cold start

With no post history, produce a **provisional DNA**: positioning sentence, one audience hypothesis,
three candidate pillars, and the next three tests. Mark every field `hypothesis`, set a review date
after the first 5 posts, and let downstream skills run on it rather than blocking them.

## Workflow

1. Collect the minimum available evidence: creator goal, profile/bio, 5-20 representative posts, and metrics when available.
2. Separate facts from inference. Never infer audience or positioning from one post alone.
3. Identify proven signals: recurring topics, formats, hooks, visual patterns, and posts that outperform the account baseline.
4. Draft the account DNA with the schema in `references/dna-schema.md`.
5. Mark uncertain fields and request only the missing decision that would materially change the positioning.
6. Save or return a complete Markdown profile using `assets/account-dna-template.md`.

## Rules

- Prefer one clear audience and three content pillars over a broad list of AI topics.
- Describe value in audience language, not tool names.
- Keep `proven`, `hypothesis`, and `avoid` sections distinct.
- Do not claim shadow banning or platform penalties without direct evidence.
- Do not overwrite an existing DNA silently. Show what changed and why.
- When metrics are available, compare against the account's own median rather than platform-wide guesses.

## Output

Return: positioning sentence, audience jobs/pains, three content pillars, recurring formats, voice rules, visual rules, proof ledger, avoid list, current hypotheses, and the next three content tests.

