"""Offline final verification; never deploys or invokes a real model."""
from __future__ import annotations
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import shutil
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parent
NODE = Path(r'C:\积木软件工坊\核心组件\社媒人设与内容运营组件库\runtime\tools\node-v22.23.4-win-x64\node.exe')
SDK = Path(r'C:\积木软件工坊\项目\方隅公寓客户版\work\cloud\workspace\node_modules')


def execute(name, arguments):
    environment = dict(os.environ, NODE_PATH=str(SDK), PYTHONIOENCODING='utf-8', PYTHONUTF8='1')
    completed = subprocess.run(arguments, cwd=ROOT, env=environment, capture_output=True,
                               text=True, encoding='utf-8', errors='replace', timeout=120)
    output = completed.stdout + completed.stderr
    relative = 'work/' + name + '.log'
    (ROOT / relative).write_text(output, encoding='utf-8')
    return {'name': name, 'exitCode': completed.returncode, 'log': relative,
            'failedNames': re.findall(r'^not ok \d+ - (.+)$', output, re.M),
            'nodeCounts': {key: int(value) for key, value in re.findall(r'^# (tests|pass|fail|skipped) (\d+)$', output, re.M)},
            'pythonTests': int(re.search(r'Ran (\d+) tests?', output).group(1)) if re.search(r'Ran (\d+) tests?', output) else None}


def main():
    manifest = json.loads((ROOT / 'baseline/CLOUD-SHA256.json').read_text('utf-8-sig'))
    source_changes = []
    for row in manifest['files']:
        for location in (Path(manifest['source']) / row['path'], ROOT / 'baseline/cloud' / row['path']):
            if hashlib.sha256(location.read_bytes()).hexdigest() != row['sha256']:
                source_changes.append(str(location))
    assert not source_changes, 'Read-only authoritative source/baseline changed'
    live_manifest=json.loads((ROOT/'baseline/LIVE-CLOUD-SHA256.json').read_text('utf-8'))
    live_tests=ROOT/'work/live-regression-baseline'
    live_tests.mkdir(exist_ok=True)
    # site.cjs enumerates this directory on import; these contract tests never
    # serve the site. An empty fixture directory avoids copying unrelated media.
    (live_tests/'site/assets').mkdir(parents=True,exist_ok=True)
    for row in live_manifest['files']:
        for location in (Path(live_manifest['source'])/row['path'],ROOT/'baseline/live'/row['path']):
            assert hashlib.sha256(location.read_bytes()).hexdigest()==row['sha256'],row['path']
        shutil.copy2(ROOT/'baseline/live'/row['path'],live_tests/row['path'])
    for name in ('ai_enterprise.test.cjs','service.test.cjs'):
        shutil.copy2(ROOT/'baseline/cloud'/name,live_tests/name)
    historical_pattern='policy describes inquiry|versioned keyword contract|v10 rental eligibility|v11 distinguishes experience|v12 keeps viewing|v10 fixed boundaries|rental contract separates|a cleaned duration fact'
    commands = [
        ('NODE-FINAL', [str(NODE), '--test', 'tests/content-gateway.test.cjs', 'tests/content-review.test.cjs',
                        'tests/content-methods.test.cjs', 'tests/store-replay.test.cjs',
                        'tests/content-profile.test.cjs','tests/content-authority.test.cjs','tests/approved-live-contract.test.cjs']),
        ('LEGACY-CORE-FINAL', [str(NODE), '--test', 'server/ai_enterprise.test.cjs', 'server/product_entitlements.test.cjs',
                              'server/intent_policy_publication.test.cjs', 'server/intent_policy_service.test.cjs']),
        ('LIVE-CONTRACT-HISTORICAL-ASSERTIONS', [str(NODE),'--test','--test-name-pattern='+historical_pattern,
            str(live_tests/'ai_enterprise.test.cjs')]),
        ('SERVICE-BASELINE', [str(NODE), '--test', str(live_tests/'service.test.cjs')]),
        ('SERVICE-CANDIDATE', [str(NODE), '--test', 'server/service.test.cjs']),
        ('PYTHON-FINAL', [sys.executable, '-X', 'utf8', '-B', '-m', 'unittest', 'discover', '-s', 'tests', '-p', 'test_*.py', '-v']),
        ('METHODS-EXPORT', [sys.executable, '-X', 'utf8', '-B', 'tools/export_methods.py', '--check', '--test-fixtures']),
    ]
    checks = []
    for name, command in commands:
        result = execute(name, command)
        checks.append(result)
        print(json.dumps(result, ensure_ascii=False), flush=True)
    by_name = {check['name']: check for check in checks}
    baseline = by_name['SERVICE-BASELINE']
    candidate = by_name['SERVICE-CANDIDATE']
    baseline_equal = baseline['failedNames'] == candidate['failedNames']
    obsolete=by_name['LIVE-CONTRACT-HISTORICAL-ASSERTIONS']['failedNames']
    legacy=by_name['LEGACY-CORE-FINAL']
    historical_equal=legacy['failedNames']==obsolete and len(obsolete)==8
    required = [check for check in checks if check['name'] not in ('SERVICE-BASELINE', 'SERVICE-CANDIDATE','LEGACY-CORE-FINAL','LIVE-CONTRACT-HISTORICAL-ASSERTIONS')]
    passed = all(check['exitCode'] == 0 for check in required) and baseline_equal and historical_equal
    result = {'verifiedAt': datetime.now(timezone.utc).isoformat(), 'offlineCandidateVerified': passed,
              'candidateRevision':2,'authoritativeSourceFilesUnchanged':len(live_manifest['files']),
              'priorFoundationFilesUnchanged':len(manifest['files']),'checks': checks,
              'historicalContractAssertionsMatchActualLive':historical_equal,'historicalContractFailedNames':obsolete,
              'existingServiceFailuresUnchanged': baseline_equal, 'existingServiceFailedNames': baseline['failedNames'],
              'liveCodeIdentityVerified':True,'liveCodeSha256':live_manifest['liveCode']['codeSha256'],
              'liveCloudVerified': False, 'liveModelVerified': False, 'nativeIntegrated': False,
              'paidCalls': 0, 'deploymentPerformed': False,
              'limits': ['Node22 only; real cloud Node20.19 not executed', 'Synthetic transaction/provider boundaries',
                         'Douyin authoritative account binding absent: denied', 'Native integration/reconcile remains a separate author task',
                         '8 old prompt/version assertions also fail against exact deployed approved code; preserved, not reverted']}
    (ROOT / 'VERIFICATION.json').write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
    assert passed, 'Final checks failed; inspect fixed logs and retain unknown states'


if __name__ == '__main__':
    main()
