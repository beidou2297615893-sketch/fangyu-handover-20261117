"""Explicit local upgrade selection, using the original workspace/DPAPI verifier.

The normal distribution does not discover or copy another installation. Only a
local launcher that explicitly supplies both existing root and binding hash uses
this path. A successful data selection grants no cloud, device or platform lease.
The compiled entry must pass its own verified workspace_binding module here.
"""
from pathlib import Path
import hashlib
import re


class ExistingWorkspaceSelectionError(RuntimeError):
    pass


def select_existing_workspace(project_root, binding_sha256, support):
    if project_root is None and binding_sha256 is None:
        return None
    if (type(project_root) is not str or not project_root or project_root != project_root.strip()
            or '\x00' in project_root or type(binding_sha256) is not str
            or not re.fullmatch(r'[0-9A-Fa-f]{64}', binding_sha256)):
        raise ExistingWorkspaceSelectionError('原工作资料的启动设置不完整，已有资料不会被替换。')
    root=Path(project_root)
    if not root.is_absolute() or '..' in root.parts or str(root).startswith('\\\\'):
        raise ExistingWorkspaceSelectionError('请使用原来的本机工作资料位置。')
    # Original _plain/_read/resolve_workspace enforce plain paths, one company,
    # the SQLite header and matching metadata from the existing Windows vault.
    support._plain(root,directory=True)
    if root.resolve(strict=True)!=root:
        raise ExistingWorkspaceSelectionError('原工作资料位置发生重定向，请核对后重新打开。')
    relative=Path('work/ui-native-r57/state/production-workspace.json')
    if support.BINDING_RELATIVE!=relative or support.COMPANY_ID!='fangyu-apartment-client':
        raise ExistingWorkspaceSelectionError('工作资料核对组件不匹配。')
    descriptor=root/relative
    raw=support._read(descriptor,16384)
    if hashlib.sha256(raw).hexdigest()!=binding_sha256.lower():
        raise ExistingWorkspaceSelectionError('原工作资料设置已经变化，请核对后重新打开。')
    data=support.resolve_workspace(root,company_id='fangyu-apartment-client')
    state=root/relative.parent
    support._plain(state,directory=True)
    if support._read(descriptor,16384)!=raw:
        raise ExistingWorkspaceSelectionError('原工作资料设置在打开时发生变化，请重新打开。')
    return data,state
