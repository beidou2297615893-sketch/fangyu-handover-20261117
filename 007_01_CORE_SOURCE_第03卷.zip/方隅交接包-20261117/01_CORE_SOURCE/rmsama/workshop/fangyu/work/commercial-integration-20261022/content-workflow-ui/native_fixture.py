"""Actual Native HTTP and trusted extension; no platform/provider IO.

The synthetic model is supplied only through the public trusted-host constructor.
Run with --serve for a persistent product-UI fixture; --candidate for frozen QA.
"""
from pathlib import Path
from copy import deepcopy
import argparse, hashlib, http.client, importlib.util, json, os, sys, threading, time, uuid

sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent
P=W.parents[2]
F=P/'work/parallel-integration-20261018/final-integration'
SOURCE=F/'stage-02/project'

def load(name,path):
    spec=importlib.util.spec_from_loader(name,loader=None)
    module=importlib.util.module_from_spec(spec);module.__file__=str(path);sys.modules[name]=module
    exec(compile(path.read_bytes(),str(path),'exec'),module.__dict__)
    return module

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--serve',action='store_true');parser.add_argument('--candidate',default='')
    opts=parser.parse_args()
    if opts.candidate and not __import__('re').fullmatch(r'candidate-unified-v[0-9]+',opts.candidate):raise ValueError('Explicit versioned candidate required')
    S=F/opts.candidate/'project' if opts.candidate else SOURCE
    staged=json.loads(((F/opts.candidate if opts.candidate else F/'candidate-unified-v65')/'STAGED.json').read_text('utf-8'))
    release=Path(staged['release']);N=release if opts.candidate else S/'work/ui-native-r57'
    native_files=['workbench_backend.py','ui_native_host.py','content_extension_loader.py',
        'content_workflow.py','workflow_methods.py','workflow_knowledge.py']
    content_root=N/'resources/content-workbench' if opts.candidate else N
    before={name:sha((N if name in native_files[:2] else content_root)/name) for name in native_files}
    owned=W/('run-'+time.strftime('%Y%m%d-%H%M%S')+'-'+uuid.uuid4().hex[:6]);owned.mkdir()
    original=load('workflow_http_cloud_fixture',P/'work/acquisition-core-repair-20261018/gui-fixture/base_fixture.py')
    readable=[W,S,F/'candidate-unified-v65',original.HERE,P/'work/central-store-config',
        Path(sys.prefix),Path(sys.base_prefix),Path(os.environ.get('WINDIR','C:/Windows'))/'Fonts']
    blocked=[]
    def audit(event,args):
        if event in ('socket.connect','socket.bind') and (not isinstance(args[1],tuple) or args[1][0] not in ('127.0.0.1','::1')):
            blocked.append(event);raise RuntimeError('External socket forbidden')
        if event=='socket.getaddrinfo' and args[0] not in ('127.0.0.1','::1','localhost',None):
            blocked.append(event);raise RuntimeError('External DNS forbidden')
        if event in ('subprocess.Popen','os.system','os.startfile','os.posix_spawn'):
            blocked.append(event);raise RuntimeError('External process forbidden')
        if event=='sqlite3.connect' and not Path(args[0]).resolve().is_relative_to(owned):
            blocked.append(event);raise RuntimeError('Nonfixture database forbidden')
        if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):
            target=Path(os.fsdecode(args[0])).absolute();mode,flags=args[1] or '',args[2] or 0
            writing=any(c in str(mode) for c in 'wax+') or isinstance(flags,int) and bool(flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC))
            permitted=target.is_relative_to(W) if writing else any(target.is_relative_to(p) for p in readable)
            if not permitted:blocked.append('path:'+target.name);raise RuntimeError('Nonfixture path forbidden')
    sys.addaudithook(audit)
    sys.path[:0]=[str(S/'work/ui-runtime-r55/src'),str(N)]
    integration=load('integrations',N/'resources/platform-runtime/vendor-src/integrations.py' if opts.candidate else S/'work/shared-backend-integration/vendor-src/integrations.py')
    cloud=original.CloudStandin(json.loads((P/'work/central-store-config/compiled-fixture.json').read_text('utf-8-sig')))
    integration.request_json=cloud
    host=load('workflow_actual_host',N/'ui_native_host.py')
    examples=load('workflow_synthetic_results',content_root/'workflow_methods.py')

    class Model:
        def __init__(self):self.mode='success';self.calls=[];self.entered=threading.Event();self.release=threading.Event()
        def __call__(self,envelope):
            self.calls.append(deepcopy(envelope));mode=self.mode
            self.entered.set()
            if mode=='block' and not self.release.wait(15):raise TimeoutError('synthetic fixture wait expired')
            if mode in ('unknown','known_not_executed'):return {'requestId':envelope['requestId'],'state':mode}
            result=examples.example_result(envelope['method']['id'])
            if envelope['method']['id']=='scheduling':
                # Synthetic result references the actual synthetic task context.
                result['artifact']['slots'][0].update(accountId=envelope['scope']['account_id'],contentId=envelope['input']['draft']['id'])
            facts=[e for e in envelope['input']['evidence'] if e['kind']=='fact']
            if facts:result['facts']=[{'evidenceId':facts[0]['evidenceId'],'quote':facts[0]['text']}]
            if mode=='invalid':result['unexpected_execute']='forbidden'
            if envelope['method']['id']=='revision':
                draft=envelope['input']['draft'];target='script' if draft['format']=='video' else 'body'
                result['artifact'].update(title=draft['title'],changes=[{'target':target,'original':draft[target],
                    'replacement':'修订后的虚构内容。','reason':'只用于合成验证'}],revisedBody='修订后的虚构内容。')
            return {'requestId':envelope['requestId'],'state':'succeeded','output':result}
    model=Model()
    company=dict(id='fangyu-apartment-client',name='内容流程隔离验证',edition='customer',personalMode=False,
        authMode='managed',platforms=['xiaohongshu','douyin'],managedWorkspace={'environment_id':'overnight-fixture','endpoint':'https://example.invalid/fixture'})
    if opts.candidate:
        files=host.verify_release(release,staged['manifest_sha256']);host.verify_backend_dependencies(release,files,S)
        backend=host.create_backend(release,files,project_root=S,data_dir=owned/'data',company=company,content_model_adapter=model)
    else:
        files={r['path']:r for r in json.loads((release/'RELEASE.json').read_text('utf-8'))['files']}
        native=load('workflow_actual_backend',N/'workbench_backend.py')
        from customer_workbench import CustomerWorkbench
        extra={}
        if opts.serve:
            runtime_module=load('workflow_ui_actual_platform_runtime',S/'work/shared-backend-integration/platform_runtime.py')
            def runtime_factory(**kwargs):
                runtime=runtime_module.PlatformRuntime(**kwargs)
                runtime._device=lambda user:{'state':'online','bound':True,'message':'内容流程隔离验证，没有真实平台会话'}
                runtime._readiness=lambda *a:('','')
                # Accounts stay disconnected. Content editing is local, while
                # platform collection/connection must not execute in this UI.
                return runtime
            extra['platform_factory']=runtime_factory
        backend=native.WorkbenchBackend(S,data_dir=owned/'data',company=company,content_model_adapter=model,
            customer_factory=CustomerWorkbench,**extra)
    if opts.serve and not opts.candidate:
        server=host.DevelopmentServer(release,files,backend=backend,cookie_name='workflow_fixture_session',
            source_root=S/'work/ui-approved-implementation/ui-preview',assets_root=release/'web/assets')
    else:server=host.StaticServer(release,files,backend=backend,cookie_name='workflow_fixture_session')
    thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
    origin='http://127.0.0.1:'+str(server.server_port);headers={};trace=[]

    def request(method,path,payload=None,expected=200,override=None,body=None):
        conn=http.client.HTTPConnection('127.0.0.1',server.server_port,timeout=30)
        raw=body if body is not None else json.dumps(payload,ensure_ascii=False).encode() if payload is not None else None
        conn.request(method,path,raw,headers if override is None else override)
        response=conn.getresponse();raw=response.read();status=response.status;found=dict(response.getheaders());conn.close()
        result=json.loads(raw) if raw and 'json' in found.get('Content-Type','') else {'text':raw.decode('utf-8')}
        assert status==expected,(method,path,status,result)
        return result,found
    def action(name,data,expected=200,override=None):return request('POST','/api/workbench',{'action':name,'data':data},expected,override)[0]
    try:
        boot,_=request('GET','/api/workbench/bootstrap');headers.update({'Content-Type':'application/json','Origin':origin,'X-Fangyu-CSRF':boot['csrfToken']})
        logged,found=request('POST','/api/workbench',{'action':'login','data':{'username':'fixture-admin','password':original.PASSWORD}})
        headers['Cookie']=found['Set-Cookie'].split(';',1)[0];headers['X-Fangyu-CSRF']=logged['csrfToken']
        token=headers['Cookie'].split('=',1)[1];user=backend.core.session(token);store=cloud.first_store
        if logged['selection']['storeId']!=store:action('select_store',{'storeId':store,'expectedRevision':logged['selection']['revision']})
        for ident in ('workflow-first','workflow-second'):
            backend.core.store.put('accounts',dict(id=ident,tenant_id=user['tenant_id'],cloud_owner=user['username'],
                store_id=store,platform='xiaohongshu',status='disconnected',name='合成内容账号'+('甲' if ident.endswith('first') else '乙')))
        for entity in ('leads','replies','ui_workbench_tone_preferences_v1','ai_cache','manual_intent'):
            backend.core.store.put(entity,dict(id='protected-'+entity,tenant_id=user['tenant_id'],cloud_owner=user['username'],text='旧业务原文不变'))
        def protected():
            with backend.core.store.connect() as db:
                return [tuple(r) for r in db.execute("SELECT entity,id,tenant_id,body FROM records WHERE id LIKE 'protected-%' ORDER BY entity,id")]
        original_rows=protected();base=dict(storeId=store,accountId='workflow-first',platform='xiaohongshu')
        revision=0
        def read(**extra):
            nonlocal revision
            value=action('content_workspace_read',{**base,**extra});revision=value['workspace']['revision'];return value
        def save(name,expected=200,**data):
            nonlocal revision
            payload={**base,'requestId':'http-'+uuid.uuid4().hex,'expectedRevision':revision,**data}
            result=action(name,payload,expected)
            if expected==200:revision=result['workspace']['revision']
            return result,payload
        def prepare(method='writing',**extra):return save('content_task_prepare',methodId=method,query='公共厨房',**extra)[0]['result']['task']['id']
        read()
        if opts.serve:
            metadata=dict(pid=os.getpid(),origin=origin,url=origin+'/#content',username='fixture-admin',password=original.PASSWORD,
                syntheticModel=True,sourceHashes=before,dataDir=str(owned/'data'),accounts=['workflow-first','workflow-second'])
            (W/'SERVER.json').write_text(json.dumps(metadata,ensure_ascii=False,indent=2),'utf-8');print(json.dumps(metadata,ensure_ascii=False),flush=True)
            while True:
                (W/'LIVE-STATUS.json').write_text(json.dumps(dict(pid=os.getpid(),observedAt=time.time(),serverAlive=thread.is_alive(),
                    syntheticModelCalls=len(model.calls),blocked=blocked),ensure_ascii=False,indent=2),'utf-8')
                time.sleep(5)

        methods=action('content_methods_read',base);assert len(methods['result']['methods'])==17
        document={'title':'虚构古北资料😀','text':'公共厨房每周四打扫。\r\n原文包含😀，只用于合成测试。','kind':'fact','sourceLabel':'本人提供的虚构说明'}
        imported,import_request=save('content_knowledge_import',document=document)
        evidence=action('content_knowledge_search',{**base,'query':'公共厨房'})['result']['evidence'];assert evidence and '公共厨房' in evidence[0]['text']
        assert action('content_knowledge_search',{**base,'accountId':'workflow-second','query':'公共厨房'})['result']['evidence']==[]
        replay=action('content_knowledge_import',import_request);assert replay['replayed']
        action('content_knowledge_import',{**import_request,'document':{**document,'kind':'hypothesis'}},409)
        trace.append('actual HTTP 17 methods, UTF-8 exact knowledge import/search, scoped citations and idempotency')
        history=[]
        for method in ('research','topics','writing'):
            task=prepare(method,artifactIds=history[-2:]);result,_=save('content_task_run',taskId=task)
            assert result['result']['task']['state']=='succeeded' and result['result']['task']['generated']
            history.append(result['result']['artifactId'])
            applied,_=save('content_task_apply',taskId=task)
            if method=='writing':draft_id=applied['result']['appliedRefs']['draftIds'][0]
        assert len(read()['workspace']['drafts'])==1
        save('content_render_cards',draftId=draft_id,theme='clean')
        save('content_draft_audit',draftId=draft_id,decision='approve',note='仅合成核验')
        packet,_=save('content_package_build',draftId=draft_id)
        assert packet['result']['package']['published'] is False and packet['result']['package']['citations']
        assert packet['result']['mime']=='text/markdown;charset=utf-8'
        trace.append('HTTP research → topics → writing → explicit apply → original cards/audit → cited local package')

        task=prepare();backend._content_model_adapter=None;prior=read()['workspace'];calls=len(model.calls)
        action('content_task_run',{**base,'accountId':'workflow-second','expectedRevision':0,
            'requestId':'wrong-account-'+uuid.uuid4().hex,'taskId':task},409)
        assert len(model.calls)==calls
        unavailable,payload=save('content_task_run',expected=503,taskId=task)
        assert unavailable['error']['code']=='CONTENT_MODEL_UNAVAILABLE' and unavailable['error']['mutation_committed'] is False
        assert read()['workspace']==prior and len(model.calls)==calls
        backend._content_model_adapter=model
        trace.append('default absent model rejects before dispatch with explicit uncommitted receipt and intact prepared task')

        model.mode='unknown';unknown,key=save('content_task_run',taskId=task);calls=len(model.calls)
        assert unknown['receipt']['state']=='unknown'
        repeated=action('content_task_run',key);assert repeated['replayed'] and len(model.calls)==calls
        save('content_task_run',expected=409,taskId=task);assert len(model.calls)==calls
        assert read(requestId=key['requestId'])['receipt']['state']=='unknown'
        save('content_draft_save',draft={'title':'未知任务期间本地编辑','body':'保留独立本地工作','format':'image'})
        trace.append('unknown response persists original key; exact replay/new key do not call model twice; local drafts remain writable')

        for mode in ('known_not_executed','invalid'):
            model.mode=mode;task=prepare();done,key=save('content_task_run',taskId=task)
            expected='completed_invalid' if mode=='invalid' else mode
            assert done['receipt']['state']==expected
            count=len(model.calls);action('content_task_run',key);assert len(model.calls)==count
        trace.append('known-not-executed and invalid results keep nonretryable original receipts without installing a draft')

        model.mode='block';model.entered.clear();model.release.clear();task=prepare();run_payload={**base,'taskId':task,'requestId':'concurrent-'+uuid.uuid4().hex,'expectedRevision':revision}
        outcome=[]
        worker=threading.Thread(target=lambda:outcome.append(action('content_task_run',run_payload)));worker.start()
        assert model.entered.wait(5),'model was not entered'
        count=len(model.calls);pending_replay=action('content_task_run',run_payload)
        assert pending_replay['replayed'] and pending_replay['receipt']['state']=='running' and len(model.calls)==count
        start=time.monotonic();concurrent=read();assert time.monotonic()-start<2.5
        save('content_persona_save',persona={'name':'并发保存','positioning':'本地保存不能被模型锁阻塞','audience':'虚构读者'})
        assert not model.release.is_set() and worker.is_alive()
        model.release.set();worker.join(10);assert not worker.is_alive()
        assert outcome[0]['result']['task']['state']=='needs_revalidation'
        assert read()['workspace']['persona']['name']=='并发保存'
        trace.append('actual second HTTP thread reads/writes before model release; both host and Native global locks released; stale candidate retained')

        def blocked_run():
            nonlocal revision
            model.mode='block';model.entered.clear();model.release.clear();task=prepare()
            args={**base,'taskId':task,'requestId':'authority-'+uuid.uuid4().hex,'expectedRevision':revision};answers=[]
            t=threading.Thread(target=lambda:answers.append(action('content_task_run',args,403)));t.start();assert model.entered.wait(5)
            return t,answers,args
        worker,answers,key=blocked_run();account=backend.core.store.get('accounts','workflow-first')
        backend.core.store.put('accounts',{**account,'cloud_owner':'another-employee'});model.release.set();worker.join(10)
        assert answers[0]['error']['mutation_committed'] is True
        backend.core.store.put('accounts',account);pending=read(requestId=key['requestId'])
        assert pending['receipt']['state']=='running'
        calls=len(model.calls);action('content_task_run',key);assert len(model.calls)==calls
        trace.append('account owner change while model is running rejects result; dispatched 403 remains committed/pending and original key cannot redispatch')
        worker,answers,key=blocked_run();token_hash=hashlib.sha256(token.encode()).hexdigest()
        with backend.core.store.connect() as db:db.execute('UPDATE sessions SET expires=0 WHERE token=?',(token_hash,))
        model.release.set();worker.join(10);assert answers[0]['error']['mutation_committed'] is True
        with backend.core.store.connect() as db:db.execute('UPDATE sessions SET expires=? WHERE token=?',(time.time()+3600,token_hash))
        assert read(requestId=key['requestId'])['receipt']['state']=='running'
        trace.append('session revoked during model execution cannot install output; original dispatch remains for reconciliation')

        worker,answers,key=blocked_run()
        current,_=request('GET','/api/workbench/bootstrap')
        other_store=next(row['id'] for row in cloud.manifest['stores'] if row['id']!=store)
        switched=action('select_store',{'storeId':other_store,'expectedRevision':current['selection']['revision']})
        model.release.set();worker.join(10)
        assert answers[0]['error']['mutation_committed'] is True
        action('select_store',{'storeId':store,'expectedRevision':switched['selection']['revision']})
        assert read(requestId=key['requestId'])['receipt']['state']=='running'
        trace.append('actual store switch while a model request waits returns immediately, blocks late installation and retains original receipt')

        model.mode='success';read()
        large={'title':'十万字中文资料','text':'中'*100000,'kind':'hypothesis','sourceLabel':'合成预算边界'}
        big,payload=save('content_knowledge_import',document=large)
        assert len(json.dumps({'action':'content_knowledge_import','data':payload},ensure_ascii=False).encode())>300000
        payload={**base,'requestId':'boundary-'+uuid.uuid4().hex,'expectedRevision':revision,'document':{'title':'边界','text':'边界测试。','kind':'hypothesis','sourceLabel':'合成'}}
        raw=json.dumps({'action':'content_knowledge_import','data':payload},ensure_ascii=False).encode();body=raw+b' '*(500000-len(raw))
        boundary,_=request('POST','/api/workbench',body=body);revision=boundary['workspace']['revision']
        request('POST','/api/workbench',body=body+b' ',expected=413)
        request('POST','/api/workbench',{'action':'content_task_prepare','data':{'bogus':'x'*140000}},expected=413)
        request('POST','/api/workbench',{'action':'content_asset_import','data':{'bogus':'x'*300000}},expected=413)
        action('content_methods_read',base,403,override={**headers,'X-Fangyu-CSRF':'wrong'})
        action('content_methods_read',base,401,override={k:v for k,v in headers.items() if k!='Cookie'})
        action('content_task_undeclared',base,403)
        trace.append('knowledge-only 500000-byte transport, 100000 Chinese characters, strict old per-action budgets, CSRF/session/explicit whitelist')
        assert protected()==original_rows
        assert not blocked,blocked
        after={name:sha((N if name in native_files[:2] else content_root)/name) for name in native_files}
        assert before==after,'Native sources changed during verification'
        report=dict(status='PASS_WORKFLOW_FROZEN_HTTP' if opts.candidate else 'PASS_WORKFLOW_SOURCE_HTTP',checks=len(trace),trace=trace,
            nativeFiles=after,modelCalls=len(model.calls),syntheticModel=True,realModelCalls=0,platformRequests=0,productionAccess=False,
            oldRowsUnchanged=True,blockedExternalAttempts=blocked,candidate=opts.candidate or None)
        (W/('RESULTS-'+opts.candidate+'.json' if opts.candidate else 'HTTP-RESULTS.json')).write_text(json.dumps(report,ensure_ascii=False,indent=2),'utf-8')
        print(json.dumps(report,ensure_ascii=False),flush=True)
    finally:
        server.shutdown();server.server_close();thread.join(5);backend.close()

if __name__=='__main__':main()
