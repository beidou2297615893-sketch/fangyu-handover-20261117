# Title Craft

Generate titles separately from long body drafting. Return 5-8 candidates, then one recommendation.

Titles serve two jobs that often conflict: **feed stop** (thumb-stopping in the feed) and **search match**
(people typing a scene or intent into search). Do not collapse every brief into a short punch line.

## Length bands (not a hard ceiling)

| Band | Typical length | When to prefer |
|---|---|---|
| Punch | 8-18 字 | Feed-first, contrast/pain hooks, video captions |
| Search | 18-32 字 | Scene + place + intent keywords; reusable topic lines |
| Hybrid | 14-26 字 | One concrete scene + one payoff |

Xiaohongshu truncates long titles in some surfaces, but **search and save behaviour still reward
specific intent words**. Prefer clarity over artificial shortness. Only compress when the user asks
for a feed-punch title, or when a long line repeats itself.

Never rewrite a user-supplied reusable topic title into a short slogan without asking. Offer a punch
variant beside it; keep the original as a candidate unless it fails a compliance gate.

## Preferred angles

| Angle | Shape | Example pattern |
|---|---|---|
| Result | 数字 + 结果 | `8 个 Skill 覆盖创作全流程` |
| Pain | 痛点 + 反转 | `还在靠临时 prompt 发笔记？` |
| Audience | 人群 + 收益 | `Cursor 用户的内容工作流` |
| Scene | 地点/场景 + 意图 | `西安周末带娃去哪玩不踩雷` |
| Intent | 动作词 + 对象 | `第一次做小红书封面怎么排` |
| Contrast | 以前 vs 现在 | `以前靠灵感，现在有流水线` |
| Workflow | 方法 + 对象 | `小红书创作可以这样拆` |
| Proof | 经历 + Outcome | `我把自己用的流程开源了` |
| List | N 个 + 类别 | `5 个环节解决发布前焦虑` |
| Question | 疑问 + 承诺 | `做小红书到底先定位还是先选题？` |

Scene and Intent angles may run longer. That is intentional — they carry searchable nouns the punch
band often drops.

## Candidate mix (required)

Among the 5-8 candidates, include **at least**:

- 2 punch titles
- 2 search/intent titles (concrete nouns: place, crowd, object, action when the brief has them)
- 1 that preserves any user-supplied topic wording if present

When recommending, say which job the winner serves (`feed` / `search` / `hybrid`). If the brief has
place or intent words (城市、门店品类、人群、具体动作), the default recommendation should keep them
unless the user explicitly wants a short feed title.

## Review rules

- One primary idea per title; secondary keywords only if they are true to the body.
- Front-load the most distinctive noun (place, crowd, object, or result) — not filler like `分享` / `推荐`.
- Title promise must match fold line (carousel) or first 3 seconds (video).
- Reject candidates that require proof the package does not contain.
- Do not strip place/intent words just to hit 18 characters.

## Compliance gates (reject, do not merely flag)

Reject a title candidate when:

- it uses absolute claims the body cannot support (`最强`, `第一`, `100%`, `保证`)
- it uses `保姆级` / `手把手` but the content is opinion/list-only without reproducible steps
- it implies medical, financial, or guaranteed outcome language
- it copies a reference title with noun swaps only

## Output

Return:

- 5-8 candidates tagged by angle **and** job (`feed` / `search` / `hybrid`)
- 1 recommended title + reason (name the job it wins)
- 1 alternate of the other job (if the winner is punch, give a search alternate, and vice versa)
- similarity-risk note if reference-inspired
- `title_compression_note` when a user topic line was shortened, with the original kept as backup
