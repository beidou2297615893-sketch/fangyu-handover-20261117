# 手动检查生成服务入口（停写）

只改 U/pages/content-workflow.mjs。内容运营工作流工具条新增“检查生成服务”，使用已有 content_methods_read，返回同作用域的方法与能力后更新界面。没有新 action、生成请求、自动轮询、付费调用或平台动作。

首次打开原面板的一次核对仍保留；手动点击标记该次方法检查，避免重复触发自动检查。检查失败保持已有资料、任务、草稿、未保存输入，显示失败，可再次明确点击；生成能力false时写明可继续保存资料与编辑草稿。返回方法合同无效则在采用workspace前拒绝，不把错误能力装入页面。

service-ui-tests.mjs / RESULTS.json：5组真实render/bind Node DOM合成测试PASS（false→手动检查true→原prepared任务可执行；双击1读；失败保留数据、无轮询且手动重试；跨scope迟到隔离；仍关闭准确提示；错误方法合同不采用）。content-reconcile-ui原10项PASS、archive-ui原5项PASS。

未运行真实服务、未访问50660、未碰任何账号/平台/模型、未做浏览器视觉断言。ROOT负责Native和CUA最终验收。

PRODUCT-FILES.json为唯一产品修改最终SHA；before保留改前helper。来源四文件以及backend/content-operations/css未改。
