"""Export the pinned Python method contracts. No model or platform invocation."""
from __future__ import annotations

import argparse
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import sys
import types
import unicodedata

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT.parent / 'content-workflow-extension/workflow_methods.py'
SOURCE_SHA256 = '60806e678ed6a96a7f3a7a3116a20024e97ac648f59c16cf5cf0eb8838e6b094'
IDS = ('strategy', 'persona', 'homepage', 'research', 'topics', 'columns', 'writing',
       'video', 'visual', 'knowledge', 'revision', 'audit', 'package', 'scheduling',
       'engagement', 'growth', 'learning')


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True,
                      separators=(',', ':'), allow_nan=False)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def packed(value):
    return (json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + '\n').encode('utf-8')


def authority():
    raw = SOURCE.read_bytes()
    if sha(raw) != SOURCE_SHA256:
        raise RuntimeError('Authoritative source pin changed; review required')
    module = types.ModuleType('_pinned_content_method_authority')
    module.__file__ = str(SOURCE)
    # Execute the already-verified bytes; never read an unpinned second copy.
    exec(compile(raw, str(SOURCE), 'exec'), module.__dict__)
    if set(module.METHODS) != set(IDS):
        raise RuntimeError('The authoritative method set changed')
    return module


def ranges(points):
    result = []
    for cp in points:
        if result and cp == result[-1][1] + 1:
            result[-1][1] = cp
        else:
            result.append([cp, cp])
    return result


def unicode_rules():
    forbidden, whitespace, digits = [], [], []
    for cp in range(sys.maxunicode + 1):
        char = chr(cp)
        category = unicodedata.category(char)
        if category in ('Cf', 'Cs'):
            forbidden.append(cp)
        if char.isspace():
            whitespace.append(cp)
        if category == 'Nd':
            digits.append(cp)
    return {'unicodeVersion': unicodedata.unidata_version,
            'pythonMajorMinor': '.'.join(map(str, sys.version_info[:2])),
            'forbiddenOutputRanges': ranges(forbidden),
            'whitespaceRanges': ranges(whitespace), 'decimalDigitRanges': ranges(digits),
            'allowedC0Controls': [9, 10, 13]}


def write_or_check(path, raw, check):
    if check:
        if not path.is_file() or path.read_bytes() != raw:
            raise RuntimeError('Generated file differs: ' + path.name)
    else:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(raw)


def fixtures(module, digests, check):
    """Explicit test-only oracle; production export never contains examples."""
    cases = []
    def add(name, method, output, evidence=None):
        evidence = {} if evidence is None else evidence
        try:
            module.validate_result(method, output, evidence)
            accepted = True
        except ValueError:
            accepted = False
        cases.append({'name': name, 'methodId': method, 'output': output,
                      'evidence': evidence, 'acceptedByPython': accepted})
    for method in IDS:
        add('valid-' + method, method, module.example_result(method))
    evidence = {'source': {'text': '预算三千，月底入住。', 'kind': 'fact'}}
    for name, quote, ref, kind in [
        ('exact-fact', '预算三千', 'source', 'fact'),
        ('fabricated-fact', '预算五千', 'source', 'fact'),
        ('spliced-fact', '预算三千月底入住', 'source', 'fact'),
        ('unknown-fact', '预算三千', 'missing', 'fact'),
        ('hypothesis-as-fact', '预算三千', 'source', 'hypothesis')]:
        value = module.example_result('writing')
        value['facts'] = [{'quote': quote, 'evidenceId': ref}]
        ev = deepcopy(evidence); ev['source']['kind'] = kind
        add(name, 'writing', value, ev)
    for name, text in [('astral-at-title-limit', '🏡' * 120),
                       ('astral-over-title-limit', '🏡' * 121),
                       ('python-whitespace-next-line', '\x85'),
                       ('format-character', 'a\u200bb'),
                       ('control-character', 'a\x01b'),
                       ('allowed-line-controls', 'a\n\r\tb')]:
        value = module.example_result('writing'); value['artifact']['title'] = text
        add(name, 'writing', value)
    for name, raw in [('raw-bom-source-not-output', '\ufeff'),
                      ('raw-python-whitespace-source', '\x85')]:
        add(name, 'writing', module.example_result('writing'), {'source': {'text': raw, 'kind': 'fact'}})
    for time in ['09:00', '09:0٣', '09:0𝟜', '24:00', '09:00\n']:
        value = module.example_result('scheduling'); value['artifact']['slots'][0]['time'] = time
        add('time-' + time, 'scheduling', value)
    for method in IDS:
        value = module.example_result(method); value['artifact']['published'] = True
        add('injected-published-' + method, method, value)
    for method, member in [('topics', 'topics'), ('knowledge', 'items')]:
        value = module.example_result(method)
        value['artifact'][member][0]['sourceEvidenceIds' if method == 'knowledge' else 'evidenceIds'] = ['missing']
        add('unknown-nested-evidence-' + method, method, value)
    value = module.example_result('revision'); value['artifact']['changes'][0]['target'] = '正文首句'
    add('uncontrolled-revision-target', 'revision', value)
    value = module.example_result('video'); value['artifact']['scenes'][0]['durationSeconds'] = True
    add('boolean-duration', 'video', value)
    value = module.example_result('video'); value['artifact']['scenes'][0]['durationSeconds'] = 1.5
    add('fraction-duration', 'video', value)
    value = module.example_result('engagement')
    value['artifact']['replies'][0].update(channel='dm', targetId='fixture-recipient-uid')
    add('dm-draft', 'engagement', value)
    value = module.example_result('writing'); value['hypotheses'] = ['汉' * 2000] * 100
    value['facts'] = [{'quote': '汉' * 2000, 'evidenceId': 'long-source'}] * 100
    add('ascii-json-total-limit', 'writing', value, {'long-source': {'text': '汉' * 2000, 'kind': 'fact'}})
    raw = packed({'testOnly': True, 'productionDefaultOutput': False,
                  'sourceSha256': SOURCE_SHA256, 'methodDigests': digests, 'cases': cases})
    write_or_check(ROOT / 'work/methods-python-oracle.json', raw, check)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--check', action='store_true', help='Read-only deterministic export check')
    parser.add_argument('--test-fixtures', action='store_true', help='Also export test-only Python oracle cases')
    args = parser.parse_args()
    sys.dont_write_bytecode = True
    module = authority()
    methods = {key: module.get_method(key) for key in IDS}
    digests = {key: sha(canonical(spec).encode('utf-8')) for key, spec in methods.items()}
    payload = {'schemaVersion': 1,
        'canonicalization': 'python-json-ensure_ascii_false-sort_keys-compact-v1',
        'source': {'relativePath': '../content-workflow-extension/workflow_methods.py', 'sha256': SOURCE_SHA256},
        'unicodeRules': unicode_rules(), 'methodOrder': list(IDS),
        'methods': methods, 'methodDigests': digests}
    catalog_digest = sha(canonical(payload).encode('utf-8'))
    catalog = {**payload, 'catalogDigest': catalog_digest}
    raw = packed(catalog)
    pins = {'schemaVersion': 1, 'source': payload['source'],
        'canonicalization': payload['canonicalization'],
        'catalog': {'relativePath': 'server/content-methods.json', 'sha256': sha(raw),
                    'canonicalDigest': catalog_digest}, 'methodDigests': digests,
        'unicodeRules': {'unicodeVersion': payload['unicodeRules']['unicodeVersion'],
                         'pythonMajorMinor': payload['unicodeRules']['pythonMajorMinor']}}
    write_or_check(ROOT / 'server/content-methods.json', raw, args.check)
    write_or_check(ROOT / 'METHODS-PINS.json', packed(pins), args.check)
    if args.test_fixtures:
        fixtures(module, digests, args.check)
    print(json.dumps({'checkedOnly': args.check, 'methods': len(methods),
                      'catalogSha256': sha(raw), 'catalogDigest': catalog_digest,
                      'sourceSha256': SOURCE_SHA256, 'testFixtures': args.test_fixtures}))


if __name__ == '__main__':
    main()
