# 独立内容模型网关：第二版候选

第二版修复总部多店和两类设备标识接缝，以当前真实云代码重新合并。仍为独立准备包，没有部署、启用真实模型或修改现有软件。第一版ZIP保持原字节，仅作历史留存，后续采用第二版。

content_generate和只读content_generate_status包含17种固定方法，沿用原企业会话、提供者、配置、每日金额预算。模型在事务外调用一次，原键先持久落盘；unknown保留原预留，不换号重派。客户端不能传模型、密钥、任意地址、系统指令或任意schema。

## 真实基线与范围

官方GetFunctionAddress只读取码ZIP SHA256：976de75d98b4aa72cad06b786c3c7eeea71f54ccbdb4957c4ce2d1f4b120e0ac。19个顶层源码与10月19日after-QeaHL2部署后备份逐字节相同。证据为baseline/LIVE-CLOUD-SHA256.json。没有请求环境变量、读取私有业务整库或手动提取凭据。

相对真实19文件：修改ai_contract.cjs、ai_enterprise.cjs、store_config.cjs、service.cjs、index.js共5个；新增内容合同、执行器、方法实现、目录4个，以及原键恢复、服务额度、发布规则辅助3个云模块；客户端3个Python文件。后三个云模块是待合并AI基础增量，当前线上不含它们，不能称为已上线。没有夹带旧候选中无关的获客交接或联系方式交付模块。

10月19日已批准标准、默认提示词、模型和价格保留。没有发布规则覆盖时，两种旧AI提示词与实际线上逐字相同。ai_provider.cjs、approved_intent_policy.json、readonly_routes.cjs、devices.cjs保持真实原字节。原每日预算/费用账本/缓存集合保持；新增原键索引只追踪采用后的请求，不补造历史索引。有限服务额度时内容每次1槽、缓存0、unknown保留；槽不是付款或真实供应商账单证明。新增集合及启用条件见DEPLOYMENT-READINESS.md。

## 权威范围

中央store_config原authority、manifest和版本在原事务内读取。HQ无固定user.store_id也可使用中央授权店；operator仍限原单店。预留、派发前、结果保存及回读均核中央范围与版本。运行中撤店、变grant/catalog或撤设备时，实际usage结算，候选永久丢弃，权限恢复也不会复活。

执行设备由原xhs_claims账号声明关联devices，再核owner、未撤销、唯一声明和请求期望ID。软件记住登录的session.deviceId是不同安装标识，不用来推定平台设备；expected_device_id只是待核对断言，不能创建权限。HQ角色不授予使用别人账号的权限。云声明没有账号门店字段，Native仍须核对本地账号与所选门店的关联。

抖音缺等效权威云登记，本路径明确拒绝；独立组件库中的抖音素材能力未改。

## 默认关闭、验证和采用

CONTENT_GENERATION_POLICY缺失时默认关闭。ai_profile新增只读content_generation_capability；缺字段、未显式available或可信范围不全时Native不得注入适配器。profile不验选中账号、不调用模型。合同见PROFILE-CONTRACT.md，适配器仍精确使用ADAPTER.md原10项上下文和原wire字段。

新增验证154项通过；历史AI/额度/规则115项中107通过，另8项在原样真实线上基线同样失败，仍断言10月10日旧提示词/版本。保留对照，不回退现行已批准规则。原service在真实基线及候选均8/8，Python29/29，固定方法导出通过。最终以VERIFICATION.json为准。Windows Node22合成验证不等于真实CloudBase/Node20.19或内容质量验收。

本版为content-model-gateway-candidate-v2.zip。integration.patch相对根为cloud/，只能合到独立的真实源码准备副本。总控须核对最新生产基线及其他增量，逐块保留P1中央撤店/P2归档保护后冻结最终字节，不能覆盖生产或旧work/cloud/workspace。工具仅在本网关work试装。

实际私有租户/成员/门店/执行设备/账号声明映射未读，仍未知；Native接线、公开原任务恢复、显式启用及真实部署待总控完成。当前生产代码没有新内容接口，不能称为已上线。完整核查见DEPLOYMENT-READINESS.md。

补丁试装已按原始CRLF/LF保存并逐字节核对所有12个云改动文件，生产依赖导入通过。最初按文本正规化换行会破坏方法目录固定摘要，现已在打包工具修复；源方法和客户端pins未更改。总控仍应冻结自己最终合并字节。
