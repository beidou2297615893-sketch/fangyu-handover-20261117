from copy import deepcopy
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import tempfile
import unittest
from test_resource_chain import ROOT,NODE,module,load_native

class Integrity(unittest.TestCase):
 def temp(self):
  d=tempfile.TemporaryDirectory(prefix='integrity-',dir=ROOT/'work');self.addCleanup(d.cleanup);return Path(d.name)
 def test_all_legacy_contracts_are_exact_and_resource_coverage_does_not_claim_executor_completion(self):
  old=json.loads((ROOT/'baseline/cloud/content-methods.json').read_bytes())
  methods=module(ROOT/'native/workflow_methods.py');pins=module(ROOT/'client/trusted_method_pins.py')
  versions=json.loads((ROOT/'METHOD-VERSIONS.json').read_text('utf8'))
  for method,spec in old['methods'].items():
   digest=old['methodDigests'][method]
   self.assertEqual(methods.get_method(method,digest),spec)
   self.assertEqual(pins.get_trusted_method(method,digest),spec)
   self.assertEqual(methods.get_method(method)['outputSchema'],spec['outputSchema'])
   self.assertEqual(methods.get_method(method)['version'],3)
  self.assertEqual(versions['legacyMethodsPreserved'],17);self.assertEqual(versions['currentResourceMethods'],17)
  self.assertIn('完整DM',methods.get_method('engagement')['remainingGap'])
  self.assertIn('定时执行器未接',methods.get_method('scheduling')['remainingGap'])
 def test_selected_text_is_complete_and_native_client_share_each_current_digest(self):
  methods=module(ROOT/'native/workflow_methods.py');pins=module(ROOT/'client/trusted_method_pins.py')
  index=json.loads((ROOT/'resources/resource-index.json').read_bytes())
  resources={(r['repo'],r['path']):r for r in index['files']}
  for method in methods.METHODS:
   spec=methods.get_method(method);self.assertEqual(pins.get_trusted_method(method),spec)
   actual=hashlib.sha256(json.dumps(spec,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
   self.assertEqual(pins.trusted_method_digest(method),actual)
   for resource in spec.get('resourceManifest',[]):
    self.assertIn(resources[(resource['repo'],resource['path'])]['text'],spec['instructions'])
    self.assertEqual(resource['sha256'],hashlib.sha256(resources[(resource['repo'],resource['path'])]['text'].encode()).hexdigest())
 def test_changed_native_method_bundle_is_rejected_by_existing_trusted_closure(self):
  target=self.temp()/'native';shutil.copytree(ROOT/'native',target)
  loader=module(ROOT/'native/content_extension_loader.py')
  pins={n:hashlib.sha256((ROOT/'native'/n).read_bytes()).hexdigest() for n in loader.SOURCES}
  path=target/'content_vendor/method-bundle.json';path.write_bytes(path.read_bytes()+b' ')
  with self.assertRaises(loader.ContentExtensionLoadError):loader.load_extension(target,pins)
 def test_changed_native_method_source_cannot_authorize_itself_via_local_metadata(self):
  target=self.temp()/'native';shutil.copytree(ROOT/'native',target)
  loader=module(ROOT/'native/content_extension_loader.py')
  pins={n:hashlib.sha256((ROOT/'native'/n).read_bytes()).hexdigest() for n in loader.SOURCES}
  path=target/'workflow_methods.py';path.write_bytes(path.read_bytes()+b'\n# changed\n')
  with self.assertRaises(loader.ContentExtensionLoadError):loader.load_extension(target,pins)
 def test_changed_client_catalog_is_rejected_before_transport_can_be_used(self):
  target=self.temp()/'client';shutil.copytree(ROOT/'client',target)
  p=target/'trusted_method_pins.py';p.write_bytes(p.read_bytes()+b'\n# corrupt\n')
  with self.assertRaises(RuntimeError) as caught:module(target/'gateway_adapter.py')
  self.assertEqual(type(caught.exception).__name__,'GatewayConfigurationError')
 def test_changed_cloud_resource_catalog_is_rejected_at_fixed_import(self):
  target=self.temp()/'cloud';target.mkdir()
  for name in ('content_methods.cjs','content-methods.json','content-methods-v3.json'):shutil.copy2(ROOT/'cloud'/name,target/name)
  p=target/'content-methods-v3.json';p.write_bytes(p.read_bytes()+b' ')
  script="try{require(process.argv[1]);process.exit(2)}catch(e){if(e.code!=='CONTENT_METHOD_CATALOG_CHANGED')process.exit(3)}"
  done=subprocess.run([str(NODE),'-e',script,str(target/'content_methods.cjs')],capture_output=True,timeout=10)
  self.assertEqual(done.returncode,0)
 def test_business_forgery_of_complete_method_metadata_is_not_a_trusted_version(self):
  pins=module(ROOT/'client/trusted_method_pins.py');spec=pins.get_trusted_method('persona')
  spec['instructions']+=' client-forgery'
  forged=hashlib.sha256(json.dumps(spec,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
  with self.assertRaises(ValueError):pins.get_trusted_method('persona',forged)
 def test_all_five_MIT_notices_travel_with_native_client_and_cloud_catalog(self):
  native=module(ROOT/'native/workflow_methods.py');client=module(ROOT/'client/trusted_method_pins.py')
  cloud=json.loads((ROOT/'cloud/content-methods-v3.json').read_bytes())
  notices=cloud['source']['licenseNotices'];self.assertEqual(len(notices),5)
  self.assertEqual(native.RESOURCE_LICENSE_NOTICES,notices);self.assertEqual(client.RESOURCE_LICENSE_NOTICES,notices)
  for row in notices:
   self.assertTrue(row['text'].startswith('MIT License'))
   self.assertEqual(hashlib.sha256(row['text'].encode('utf8')).hexdigest(),row['sha256'])

if __name__=='__main__':unittest.main()
