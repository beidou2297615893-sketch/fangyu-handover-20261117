import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import {webcrypto} from 'node:crypto';
import {parseHTML} from '../content-workflow-ui/node_modules/linkedom/esm/index.js';
import {openOutcomeEditor,openOutcomeReport,parseCents,requestDigest,renderOutcomeReport} from './ui-harness/pages/customer-outcomes.mjs';
import {createBackend} from './ui-harness/backend.mjs';
import * as customers from './ui-harness/pages/customers.mjs';
import {customerControls} from './ui-harness/pages/customers-data.mjs';
const W=new URL('./',import.meta.url),fixture=JSON.parse(fs.readFileSync(new URL('UI-FIXTURES.json',W),'utf8'));
const clone=x=>structuredClone(x),results=[];if(!globalThis.crypto)Object.defineProperty(globalThis,'crypto',{value:webcrypto});
const settle=async()=>{for(let i=0;i<9;i++)await new Promise(r=>setTimeout(r,0));};
function harness({memory=new Map(),behavior='success'}={}){
  const {document,window}=parseHTML('<html><head></head><body><main></main><dialog id="modal"></dialog></body></html>');
  globalThis.document=document;globalThis.localStorage={getItem:k=>memory.get(k)||null,setItem:(k,v)=>memory.set(k,v),removeItem:k=>memory.delete(k)};
  const dialog=document.querySelector('dialog');dialog.open=false;dialog.close=()=>{dialog.open=false;dialog.dispatchEvent(new window.Event('close'));};
  const state={authEpoch:1,connection:'connected',user:'alice',storeId:'gubei',activePlatform:'xiaohongshu',page:'customers',session:{user:{username:'alice',tenant_id:'fictional-tenant',role:'operator'}}};
  const calls=[],deferred=[],receipts=new Map(),notes=[];let mode=behavior,version=0,modalCount=0;
  const resultView=data=>{const v=clone(fixture.read);v.actor={username:state.user,storeId:data.storeId};v.customerId=data.customerId;v.platform=data.platform;v.version=version;
    if(data.requestId){v.receipt=receipts.get(data.requestId)||{requestId:data.requestId,state:'not_found',requestDigest:null,version:null};}
    return v;};
  const backend=createBackend(async(url,options)=>{
    const {action,data}=JSON.parse(options.body);calls.push({action,data:clone(data)});
    if(mode==='unrelated-error'&&!action.startsWith('customer_outcome_'))throw Error('unrelated lost write');
    let v;
    if(action==='customer_outcome_save'){
      if(mode==='validation')return {ok:false,status:409,json:async()=>({ok:false,error:{code:'OUTCOME_VERSION_CONFLICT',message:'请重新读取',mutation_committed:false}})};
      const prior=receipts.get(data.requestId);
      if(!prior){version++;receipts.set(data.requestId,{requestId:data.requestId,state:'accepted',requestDigest:await requestDigest(data),version});}
      v=resultView(data);v.receipt=receipts.get(data.requestId);
      if(mode==='lost-save')throw Error('synthetic response lost');
    }else if(action==='customer_outcome_read')v=resultView(data);
    else if(action==='customer_outcome_cancel'){
      if(!receipts.has(data.requestId))receipts.set(data.requestId,{requestId:data.requestId,state:'cancelled',requestDigest:data.requestDigest,version:null});
      v=resultView(data);
    }else if(action==='customer_outcome_report'){v=clone(fixture.report);v.actor={username:state.user,storeId:data.storeId};Object.assign(v,{dateFrom:data.dateFrom,dateTo:data.dateTo});}
    else throw Error('Unexpected action '+action);
    const response=()=>({ok:true,status:200,json:async()=>({ok:true,customerOutcomes:v})});
    if(mode==='delayed')return new Promise(resolve=>deferred.push(()=>resolve(response())));
    if(mode==='wrong-actor')v.actor.username='other-employee';
    return response();
  });
  const ctx={state,actions:{outcomeAction:(a,d)=>backend.outcomeAction(a,d),replyError:e=>notes.push(e.message)},toast:m=>notes.push(m),update:f=>f(state),
    modal:({title,html})=>{modalCount++;dialog.__modalOwner={};dialog.innerHTML=`<h2>${title}</h2><button data-close>关闭</button><div>${html}</div>`;dialog.open=true;dialog.querySelector('[data-close]').onclick=()=>dialog.close();return dialog;}};
  return {document,window,dialog,state,ctx,calls,memory,backend,receipts,deferred,notes,get modalCount(){return modalCount},get mode(){return mode},set mode(v){mode=v},open:()=>openOutcomeEditor(ctx,fixture.base.customerId,'xiaohongshu')};
}
function input(h,name,value){const el=h.dialog.querySelector(`[data-outcome-field="${name}"]`);assert.ok(el,name);el.value=value;el.dispatchEvent(new h.window.Event('input',{bubbles:true}));}
function fill(h){input(h,'fact','本人核对的合成事实');input(h,'source','合成电话');const c=h.dialog.querySelector('[data-outcome-confirm]');c.checked=true;c.dispatchEvent(new h.window.Event('change',{bubbles:true}));}
function click(h,selector){const el=h.dialog.querySelector(selector);assert.ok(el,selector);el.click();}
{
 assert.equal(parseCents('100.01'),10001);assert.equal(parseCents('0'),0);for(const value of ['1.234','NaN','-1','1e3'])assert.throws(()=>parseCents(value));
 assert.equal(await requestDigest(fixture.saveRequest),fixture.saved.receipt.requestDigest);results.push('Exact integer-fen parsing and JS canonical request digest agree with actual original-Store Python receipt');
}
{
 const h=harness();h.open();await settle();assert.deepEqual(h.calls,[{action:'customer_outcome_read',data:fixture.base}]);assert.ok(h.dialog.querySelector('[data-outcome-editor]'));assert.match(h.dialog.textContent,/人工登记 · 未独立对账/);assert.equal(h.dialog.querySelector('details').open,undefined);assert.match(h.dialog.innerHTML,/font-size:17px/);assert.equal(h.dialog.querySelector('[data-outcome-save]').disabled,false);results.push('Real modal render/bind reads only one visible customer, uses 17px controls and concise notice with collapsed history');
 fill(h);click(h,'[data-outcome-save]');await settle();assert.equal(h.calls.filter(c=>c.action==='customer_outcome_save').length,1);assert.equal(h.memory.size,0);assert.match(h.dialog.textContent,/已保存/);assert.equal(h.backend.unconfirmed,false);results.push('Actual bound save constructs scoped CAS/manual evidence payload, persists original key before dispatch and clears only a matching receipt');
}
{
 const h=harness();h.open();await settle();fill(h);h.mode='lost-save';click(h,'[data-outcome-save]');await settle();assert.equal(h.memory.size,1);const p=JSON.parse([...h.memory.values()][0]);assert.ok(p.requestId&&p.requestDigest);assert.equal(p.fact,undefined);assert.equal(p.source,undefined);assert.ok(h.dialog.querySelector('[data-outcome-recover]'));assert.ok(h.dialog.querySelector('[data-outcome-save]').disabled);
 h.mode='success';click(h,'[data-outcome-recover]');await settle();assert.equal(h.memory.size,0);assert.equal(h.calls.filter(c=>c.action==='customer_outcome_save').length,1);assert.match(h.dialog.textContent,/没有重复登记/);assert.equal(h.dialog.querySelector('[data-outcome-field="fact"]').value,'');results.push('Lost response locks duplicate save, retains metadata only and recovers the original receipt without resending or leaving saved form text armed');
}
{
 const h=harness();h.open();await settle();fill(h);h.mode='lost-save';click(h,'[data-outcome-save]');await settle();h.receipts.clear();h.mode='success';click(h,'[data-outcome-recover]');await settle();assert.ok(h.dialog.querySelector('[data-outcome-cancel]'));assert.equal(h.memory.size,1);click(h,'[data-outcome-cancel]');await settle();assert.equal(h.memory.size,0);assert.match(h.dialog.textContent,/迟到的保存不会/);results.push('not_found never silently unlocks save: explicit original-key cancellation confirms a tombstone before further editing');
}
{
 const h=harness();h.open();await settle();fill(h);h.mode='validation';click(h,'[data-outcome-save]');await settle();assert.equal(h.memory.size,0);assert.equal(h.dialog.querySelector('[data-outcome-field="fact"]').value,'本人核对的合成事实');assert.equal(h.backend.unconfirmed,false);results.push('Definite CAS rejection releases only the uncommitted request and preserves input, without generic bootstrap recovery');
}
{
 const h=harness({behavior:'delayed'});h.open();const count=h.modalCount;h.dialog.close();h.deferred[0]();await settle();assert.equal(h.modalCount,count);assert.equal(h.dialog.open,false);
 const other=harness({behavior:'delayed'});other.open();const prior=other.modalCount;other.state.storeId='another-store';other.deferred[0]();await settle();assert.equal(other.modalCount,prior);results.push('Dialog close and store/actor epoch fencing discard late reads instead of reopening or rendering foreign customer facts');
}
{
 const h=harness({behavior:'delayed'});h.open();h.ctx.modal({title:'其他业务',html:'应保留当前窗口'});const count=h.modalCount;h.deferred[0]();await settle();assert.equal(h.modalCount,count);assert.match(h.dialog.textContent,/应保留当前窗口/);results.push('A different modal owner supersedes the outstanding view; late result cannot replace another business dialog');
}
{
 const h=harness({behavior:'wrong-actor'});h.open();await settle();assert.equal(h.state.outcomesUI.view,null);assert.match(h.dialog.textContent,/回执不匹配/);results.push('Wrong-actor response is rejected before adoption and leaves no available save action');
}
{
 const h=harness();openOutcomeReport(h.ctx);await settle();assert.equal(h.calls[0].action,'customer_outcome_report');assert.match(h.dialog.textContent,/实际回款/);assert.match(h.dialog.textContent,/¥100.01/);assert.match(h.dialog.textContent,/暂不计算/);assert.ok(h.dialog.querySelector('details'));assert.equal(h.dialog.querySelectorAll('table th').length,2);click(h,'[data-outcome-costs]');await settle();assert.deepEqual(h.calls.at(-1).data,{storeId:'gubei',customerId:'',platform:null});assert.ok(h.dialog.querySelector('[data-outcome-field="costCategory"]'));results.push('Statistics prioritizes customer/money counts; denominator, missing-cost and non-profit rules are folded; costs use current employee/store across platforms');
}
{
 const h=harness();h.mode='unrelated-error';await assert.rejects(h.backend.login({}));assert.equal(h.backend.unconfirmed,true);await h.backend.outcomeAction('customer_outcome_read',fixture.base);assert.equal(h.backend.unconfirmed,true);assert.throws(()=>h.backend.outcomeAction('customer_outcome_delete',fixture.base));results.push('Narrow outcome action whitelist and independent original-key recovery remain available without clearing unrelated unknown operations');
}
{
 const h=harness();h.state.customerView={...clone(fixture.listing),status:'ready'};h.state.customerDetail={...clone(fixture.detail),status:'ready'};customerControls(h.state).selectedId=fixture.base.customerId;
 const root=h.document.querySelector('main');root.innerHTML=customers.render(h.state);customers.bind(root,h.ctx);const entry=root.querySelector('[data-customer-outcomes]');assert.ok(entry);entry.click();await settle();assert.equal(h.calls.at(-1).action,'customer_outcome_read');assert.equal(h.calls.at(-1).data.customerId,fixture.base.customerId);results.push('Current actual customers.render/bind detail secondary entry opens the same authorized author_key outcome editor');
}
{
 const h=harness();h.state.page='rules';const source=fs.readFileSync(new URL('ui-harness/app.mjs',W),'utf8');const body=source.slice(source.indexOf('function shell(content)'),source.indexOf('\nfunction switchPlatform'));
 const context={state:h.state,localDates:()=>({long:'今天',short:'今天',iso:'2026-10-23'}),esc:String,icon:()=>'',navButton:()=>'',activePlatform:()=>h.state.activePlatform,titles:{rules:['管理','']},renderPlatformSwitch:()=>''};vm.createContext(context);vm.runInContext(body,context);const root=h.document.querySelector('main');root.innerHTML=context.shell('<p>实际规则页</p>');const app=root;const ctx=h.ctx;const open=openOutcomeReport;new Function('app','ctx','openOutcomeReport',source.split('\n').find(l=>l.includes("app.querySelector('[data-open-outcome-report]')")))(app,ctx,open);root.querySelector('[data-open-outcome-report]').click();await settle();assert.equal(h.calls.at(-1).action,'customer_outcome_report');results.push('Actual app shell management navigation and actual binding line open local results/spend report for the signed-in employee');
}
fs.writeFileSync(new URL('UI-RESULTS.json',W),JSON.stringify({passed:results.length,results,scope:'Actual candidate DOM render/bind with linkedom/createBackend and actual Core-derived fictional envelopes; no browser layout or production/platform/model claim'},null,2));console.log(JSON.stringify({passed:results.length,results},null,2));
