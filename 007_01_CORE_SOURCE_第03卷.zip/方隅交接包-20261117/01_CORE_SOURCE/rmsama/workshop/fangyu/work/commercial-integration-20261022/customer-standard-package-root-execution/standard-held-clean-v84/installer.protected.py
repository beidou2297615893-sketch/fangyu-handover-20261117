"""User-level self extracting installer. ZIP payload is appended at build time."""
from pathlib import Path
import os, sys, zipfile, subprocess, base64, threading, tkinter as tk, json, re, uuid, shutil, tempfile, stat, hashlib
from tkinter import messagebox

TITLE='我的获客工作台'
TARGET=Path(os.environ['LOCALAPPDATA'])/'owner-workbenchWorkspaceApp'
EXECUTABLE=TITLE+'.exe'
APP_ID='owner-workbench'
WEBVIEW2_URL='https://developer.microsoft.com/microsoft-edge/webview2/'
PRIVATE_EVALUATION_VERSION='1.1.7-qa.1'
PRIVATE_EVALUATION_CLI_SHA256='2580bd579de76191a5bfd33109c612287f19c94bc55dc10fb64873a31676bb31'
PRIVATE_EVALUATION_ENVIRONMENT='fh6-d5ga45c0ddae7008c'
PRIVATE_EVALUATION_ENDPOINT=('https://fh6-d5ga45c0ddae7008c-1439321968.'
                             'ap-shanghai.app.tcloudbase.com/fangyu-workspace')
PORTABLE_EMPLOYEE_VERSION='1.1.8-pilot.1'
EMPLOYEE_PILOT_ROOT_SHA256='612acf8e3eba346e6b231855125c014f1ab818c778b2975987d0ef947dfbee9f'
EMPLOYEE_PILOT_PREFIX=('https://fh6-d5ga45c0ddae7008c-1439321968.'
                       'tcloudbaseapp.com/fangyu-employee-pilot/v1/')
EMPLOYEE_PILOT_TARGET='fangyu-employee-pilot-update.zip'


def pilot_update_policy(config,read_bytes,exists=None):
    """Pin a separate pilot root in the fixed install, never in company.json."""
    if not portable_employee_layout(config):return
    if config['releaseSequence']==1:
        if exists and (exists('update-config.json') or exists('update-trust/root.json')):
            raise ValueError('旧版员工包不能附带未启用的更新信任根')
        return
    try:
        policy=json.loads(read_bytes('update-config.json').decode('utf-8-sig'))
        root=read_bytes('update-trust/root.json')
    except (OSError,KeyError,UnicodeError,ValueError) as error:
        raise ValueError('员工更新引导包缺少固定公开策略或信任根') from error
    feed=policy.get('updateFeed') if isinstance(policy,dict) else None
    expected={'enabled':True,'metadata_url':EMPLOYEE_PILOT_PREFIX+'metadata/',
              'targets_url':EMPLOYEE_PILOT_PREFIX+'targets/',
              'trusted_root':'update-trust/root.json','target':EMPLOYEE_PILOT_TARGET,
              'channel':'employee-pilot'}
    if (not isinstance(policy,dict) or set(policy)!={'company_id','updateFeed'}
            or policy['company_id']!=config['id']
            or feed!=expected or hashlib.sha256(root).hexdigest()!=EMPLOYEE_PILOT_ROOT_SHA256):
        raise ValueError('员工更新引导包公开根或固定地址不匹配')

def portable_employee_layout(config):
    """Recognize the held, portable pilot; employee/device grants remain server-side."""
    if not isinstance(config,dict):return False
    runtime=config.get('runtime');managed=config.get('managedWorkspace')
    return bool(config.get('id')=='fangyu-apartment-client'
                and config.get('edition')=='customer' and config.get('personalMode') is False
                and config.get('authMode')=='managed' and config.get('releaseVersion')==PORTABLE_EMPLOYEE_VERSION
                and type(config.get('releaseSequence')) is int and config['releaseSequence']>0
                and set(config.get('platforms') or [])=={'xiaohongshu'}
                and isinstance(managed,dict)
                and managed.get('environment_id')==PRIVATE_EVALUATION_ENVIRONMENT
                and managed.get('endpoint')==PRIVATE_EVALUATION_ENDPOINT
                and isinstance(runtime,dict) and runtime.get('role')=='local_assistant_only'
                and runtime.get('ui_entry')=='employee_workspace'
                and runtime.get('executable')=='方隅公寓本地助手.exe'
                and runtime.get('xiaohongshu_read_transport')=='guarded_cli_v1'
                and runtime.get('cli_source_sha256')==PRIVATE_EVALUATION_CLI_SHA256
                and runtime.get('portable_employee_release') is True
                and runtime.get('release_approved') is False
                and runtime.get('xiaohongshu_automation')=='hold'
                and not any(key in runtime for key in ('private_evaluation',
                    'private_evaluation_session_id','platform_qa_device_id'))
                and 'localCliPaths' not in config
                and isinstance(config.get('updateFeed'),dict)
                and set(config['updateFeed'])=={'enabled'}
                and config['updateFeed']['enabled'] is False)

def private_evaluation_layout(config):
    """Recognize the single held, local evaluation shape; app checks its DPAPI permit."""
    if not isinstance(config,dict):return False
    runtime=config.get('runtime');managed=config.get('managedWorkspace');feed=config.get('updateFeed')
    return bool(config.get('id')=='fangyu-apartment-client'
                and config.get('edition')=='customer' and config.get('personalMode') is False
                and config.get('authMode')=='managed' and config.get('releaseVersion')==PRIVATE_EVALUATION_VERSION
                and set(config.get('platforms') or [])=={'xiaohongshu'}
                and isinstance(managed,dict)
                and managed.get('environment_id')==PRIVATE_EVALUATION_ENVIRONMENT
                and managed.get('endpoint')==PRIVATE_EVALUATION_ENDPOINT
                and isinstance(runtime,dict) and runtime.get('role')=='local_assistant_only'
                and runtime.get('ui_entry')=='employee_workspace'
                and runtime.get('executable')=='方隅公寓本地助手.exe'
                and runtime.get('xiaohongshu_read_transport')=='guarded_cli_v1'
                and runtime.get('cli_source_sha256')==PRIVATE_EVALUATION_CLI_SHA256
                and runtime.get('private_evaluation') is True
                and isinstance(runtime.get('private_evaluation_session_id'),str)
                and re.fullmatch(r'[0-9a-f]{32}',runtime['private_evaluation_session_id']) is not None
                and runtime.get('release_approved') is False
                and runtime.get('xiaohongshu_automation')=='hold'
                and not runtime.get('platform_qa_device_id')
                and (feed is None or isinstance(feed,dict) and feed.get('enabled') is False))

def managed_employee_layout(config):
    runtime=config.get('runtime') or {}
    return (config.get('id')=='fangyu-apartment-client'
            and runtime.get('role')=='local_assistant_only'
            and runtime.get('ui_entry')=='employee_workspace'
            and ((runtime.get('release_approved') is True
                  and runtime.get('private_evaluation') is not True
                  and 'portable_employee_release' not in runtime)
                 or private_evaluation_layout(config)
                 or portable_employee_layout(config)))

LEGACY_APARTMENT_INTENT_KEYWORDS=(
    ('high',['预约','看房','入住','预算']),
    ('medium',['价格','租金','地址','地铁','房型']),
    ('low',['看看','了解']),
)
def upgraded_default_intent_rules(existing,current):
    if not isinstance(existing,list) or not isinstance(current,list):return None
    if tuple((item.get('level'),item.get('keywords')) for item in existing)!=LEGACY_APARTMENT_INTENT_KEYWORDS:return None
    replacements={item.get('level'):item.get('keywords') for item in current}
    if any(not isinstance(replacements.get(level),list) for level,_ in LEGACY_APARTMENT_INTENT_KEYWORDS):return None
    return [{**item,'keywords':list(replacements[item['level']])} for item in existing]

def merge_company_config(current,packaged):
    """Keep local business edits while taking release-controlled Fangyu policy."""
    if current.get('id')!=packaged.get('id'):
        raise ValueError('现有程序标识不匹配，停止覆盖')
    merged=dict(current)
    for key in ('releaseVersion','releaseSequence','runtime','dataNotice','publicSiteUrl','updateFeed'):
        if key in packaged:merged[key]=packaged[key]
    if merged.get('id')=='fangyu-apartment-client':
        for key in ('edition','personalMode','authMode','platforms','accountLimit','features','managedWorkspace'):
            if key in packaged:merged[key]=packaged[key]
        if 'publicSiteUrl' not in packaged:merged.pop('publicSiteUrl',None)
        if 'updateFeed' not in packaged:merged.pop('updateFeed',None)
        upgraded=upgraded_default_intent_rules(merged.get('intentRules'),packaged.get('intentRules'))
        if upgraded:merged['intentRules']=upgraded
    merged.pop('localCliPaths',None)
    return merged

def webview2_version():
    import winreg
    key=r'SOFTWARE\Microsoft\EdgeUpdate\Clients\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}'
    for hive in (winreg.HKEY_CURRENT_USER,winreg.HKEY_LOCAL_MACHINE):
        for flag in (winreg.KEY_WOW64_32KEY,winreg.KEY_WOW64_64KEY):
            try:
                with winreg.OpenKey(hive,key,0,winreg.KEY_READ|flag) as handle:value=str(winreg.QueryValueEx(handle,'pv')[0])
                if int(value.split('.')[0])>=86:return value
            except (OSError,ValueError):pass
    return None

def managed_layout(base,config,initial=True):
    """Return the verified app bundle for a stable-launcher installation."""
    manifest=base/'installation.json'
    if not manifest.is_file():return base,None
    value=json.loads(manifest.read_text('utf-8-sig'))
    runtime=config.get('runtime') or {}
    if (not isinstance(value,dict) or set(value)!={'company_id','executable','launcher'}
            or value['company_id']!='fangyu-apartment-client' or config.get('id')!=value['company_id']
            or not managed_employee_layout(config)
            or not isinstance(value['executable'],str)
            or re.search(r'[<>:"/\\|?*\x00-\x1f]',value['executable'])
            or not value['executable'].lower().endswith('.exe')
            or value['executable']!=runtime.get('executable')
            or value['launcher']!='方隅助手启动器.exe'):
        raise ValueError('受控安装布局与方隅员工工作台配置不一致')
    pointer=json.loads((base/'active.json').read_text('utf-8-sig'))
    release=pointer.get('release') if isinstance(pointer,dict) else None
    if type(release) is not int or release<1 or (initial and pointer.get('previous') is not None):
        raise ValueError('首版发布指针无效')
    bundle=base/'releases'/str(release)
    if not (bundle/value['executable']).is_file():raise ValueError('受控安装缺少客户程序')
    bundled=json.loads((bundle/'company.json').read_text('utf-8-sig'))
    if (initial and bundled!=config) or bundled.get('id')!=config.get('id'):
        raise ValueError('安装摘要与客户程序配置不一致')
    if not (base/value['launcher']).is_file():raise ValueError('受控安装缺少固定启动器')
    pilot_update_policy(config,lambda relative:(base/relative).read_bytes(),
                        lambda relative:(base/relative).exists())
    return bundle,value

def metadata(archive):
    global TITLE,TARGET,EXECUTABLE,APP_ID
    with zipfile.ZipFile(archive) as z:
        config=json.loads(z.read('company.json').decode('utf-8-sig'))
        pilot_update_policy(config,z.read,lambda relative:relative in z.namelist())
    APP_ID=config.get('id','')
    if not re.fullmatch(r'[a-z][a-z0-9_-]{1,40}',APP_ID): raise ValueError('企业标识必须为 2 至 41 位 ASCII 小写字母、数字、下划线或短横线')
    name=config.get('name','')
    if not isinstance(name,str) or not name.strip() or len(name)>80 or re.search(r'[<>:"/\\|?*\x00-\x1f]',name):raise ValueError('企业名称不能用于安全文件名')
    runtime=config.get('runtime',{})
    workspace=(APP_ID=='fangyu-apartment-client' and runtime.get('ui_entry')=='employee_workspace')
    TITLE='方隅工作台' if workspace else name+'本地助手' if runtime.get('role')=='local_assistant_only' else name
    installation=None
    with zipfile.ZipFile(archive) as z:
        if 'installation.json' in z.namelist():installation=json.loads(z.read('installation.json').decode('utf-8-sig'))
    if (private_evaluation_layout(config) or 'portable_employee_release' in runtime) and installation is None:
        raise ValueError('员工安装包缺少固定启动器受控布局')
    if installation is not None:
        if (not isinstance(installation,dict) or set(installation)!={'company_id','executable','launcher'}
                or installation.get('company_id')!=APP_ID
                or installation.get('executable')!=runtime.get('executable')
                or installation.get('launcher')!='方隅助手启动器.exe'
                or not workspace or not managed_employee_layout(config)):
            raise ValueError('受控安装入口与客户配置不一致')
        EXECUTABLE=installation['launcher']
    else:
        EXECUTABLE=runtime.get('executable',TITLE+'.exe')
    if not isinstance(EXECUTABLE,str) or re.search(r'[<>:"/\\|?*\x00-\x1f]',EXECUTABLE) or not EXECUTABLE.lower().endswith('.exe'):raise ValueError('程序入口必须是当前目录中的 EXE 文件名')
    TARGET=Path(os.environ['LOCALAPPDATA'])/(APP_ID+'WorkspaceApp')
    return config

def ps(script):
    encoded=base64.b64encode(script.encode('utf-16le')).decode('ascii')
    windows=Path(os.environ.get('SystemRoot',r'C:\Windows'))
    shell=windows/'System32/WindowsPowerShell/v1.0/powershell.exe'
    environment={**os.environ,'PSModulePath':str(shell.parent/'Modules')}
    subprocess.run([str(shell),'-NoProfile','-NonInteractive','-EncodedCommand',encoded],check=True,
                   creationflags=0x08000000,stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=environment)

def quote(text): return "'"+str(text).replace("'","''")+"'"

def verify_microsoft_runtime(runtime):
    windows=Path(os.environ.get('SystemRoot',r'C:\Windows'))
    security=windows/'System32/WindowsPowerShell/v1.0/Modules/Microsoft.PowerShell.Security/Microsoft.PowerShell.Security.psd1'
    script="Import-Module -Name "+quote(security)+" -ErrorAction Stop; $s=Get-AuthenticodeSignature -LiteralPath "+quote(runtime)+"; if($s.Status -ne 'Valid' -or $s.SignerCertificate.Subject -notmatch 'Microsoft Corporation'){exit 2}"
    try:ps(script)
    except (OSError,subprocess.CalledProcessError):
        raise ValueError('内附 WebView2 安装程序签名未通过验证，请从微软官方页面下载安装后重试。') from None

def runtime_status_text(version, archive):
    """Describe the actual prerequisite payload without preparing or downloading it."""
    if version:
        return '已检测到 WebView2 ' + version
    with zipfile.ZipFile(archive) as bundle:
        offline = 'prerequisites/MicrosoftEdgeWebView2RuntimeInstallerX64.exe' in bundle.namelist()
    if offline:
        return '将使用内附离线包自动准备 WebView2 Runtime'
    return '需要电脑已有 WebView2；缺少时安装会停止，不会自动下载。'

def prepare_runtime(archive):
    if webview2_version():return
    name='prerequisites/MicrosoftEdgeWebView2RuntimeInstallerX64.exe'
    with tempfile.TemporaryDirectory(prefix='workbench-webview2-') as folder:
        runtime=Path(folder)/'MicrosoftEdgeWebView2RuntimeInstallerX64.exe'
        with zipfile.ZipFile(archive) as z:
            if name not in z.namelist():raise ValueError('缺少WebView2离线运行时，请安装微软官方运行时后重试。')
            runtime.write_bytes(z.read(name))
        verify_microsoft_runtime(runtime)
        result=subprocess.run([str(runtime),'/silent','/install'],timeout=300,creationflags=0x08000000)
        if result.returncode not in (0,3010) or not webview2_version():
            raise ValueError('WebView2安装未完成，请检查系统权限或重启后重试。返回码：'+str(result.returncode))

def checked_install_target():
    parent=Path(os.environ['LOCALAPPDATA']).resolve()
    if TARGET.name!=APP_ID+'WorkspaceApp' or TARGET.parent.resolve()!=parent:
        raise ValueError('安装目录超出当前用户目录')
    try: attributes=TARGET.lstat()
    except FileNotFoundError: attributes=None
    if attributes and (getattr(attributes,'st_file_attributes',0)&getattr(stat,'FILE_ATTRIBUTE_REPARSE_POINT',0) or TARGET.is_symlink()):
        raise ValueError('安装目录不能是链接或重解析点')
    target=TARGET.resolve()
    if target.parent!=parent:raise ValueError('安装目录超出当前用户目录')
    return parent,target

def reject_managed_downgrade(target,packaged):
    """Never let an older bootstrap replace a newer signed managed release."""
    if not target.exists():return
    manifest=target/'installation.json'
    pointer=target/'active.json'
    if not manifest.is_file():
        if pointer.exists():raise ValueError('现有受控安装清单缺失，停止覆盖')
        return
    summary=target/'company.json'
    if not summary.is_file():raise ValueError('现有受控安装配置缺失，停止覆盖')
    current_summary=json.loads(summary.read_text('utf-8-sig'))
    bundle,installation=managed_layout(target,current_summary,initial=False)
    if not installation:raise ValueError('现有受控安装布局无效，停止覆盖')
    active=json.loads(pointer.read_text('utf-8-sig'))
    current=json.loads((bundle/'company.json').read_text('utf-8-sig'))
    sequences=(active.get('release'),current.get('releaseSequence'),
               current_summary.get('releaseSequence'))
    if any(type(value) is not int or value<1 for value in sequences):
        raise ValueError('现有受控安装发布序号无效，停止覆盖')
    incoming=packaged.get('releaseSequence')
    if type(incoming) is not int or max(sequences)>incoming:
        raise ValueError('已安装更新版本，请直接打开桌面工作台')

def shortcut_guard_script():
    """Preserve foreign/unknown links; serialize this installer's per-path writes."""
    return "function Get-CanonicalShortcutPath([string]$value) {\n    if ([string]::IsNullOrWhiteSpace($value) -or -not [IO.Path]::IsPathRooted($value)) { throw '快捷方式目标无法核对' }\n    return [IO.Path]::GetFullPath($value).TrimEnd([char[]]'\\/')\n}\nfunction Save-InstanceShortcut([string]$linkPath,[string]$expectedTarget,[string]$workingDirectory,[string]$iconLocation) {\n    $mutex=$null; $locked=$false\n    try {\n        $linkPath=Get-CanonicalShortcutPath $linkPath\n        $expectedTarget=Get-CanonicalShortcutPath $expectedTarget\n        $hasher=[Security.Cryptography.SHA256]::Create()\n        try { $key=[BitConverter]::ToString($hasher.ComputeHash([Text.Encoding]::UTF8.GetBytes($linkPath.ToUpperInvariant()))).Replace('-','') }\n        finally { $hasher.Dispose() }\n        $mutex=[Threading.Mutex]::new($false,('Local\\FangyuShortcut_'+$key))\n        try { $locked=$mutex.WaitOne(10000) }\n        catch [Threading.AbandonedMutexException] { $locked=$true }\n        if (-not $locked) { return $false }\n        if (Test-Path -LiteralPath $linkPath) {\n            $item=Get-Item -LiteralPath $linkPath -Force -ErrorAction Stop\n            if ($item.PSIsContainer -or (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0)) { return $false }\n            $shortcut=$w.CreateShortcut($linkPath)\n            $oldTarget=Get-CanonicalShortcutPath ([string]$shortcut.TargetPath)\n            if (-not [string]::Equals($oldTarget,$expectedTarget,[StringComparison]::OrdinalIgnoreCase)) { return $false }\n        } else { $shortcut=$w.CreateShortcut($linkPath) }\n        $shortcut.TargetPath=$expectedTarget\n        if ($workingDirectory) { $shortcut.WorkingDirectory=$workingDirectory }\n        if ($iconLocation) { $shortcut.IconLocation=$iconLocation }\n        $shortcut.Save()\n        return $true\n    } catch { return $false }\n    finally {\n        if ($locked) { $mutex.ReleaseMutex() }\n        if ($null -ne $mutex) { $mutex.Dispose() }\n    }\n}\n"

def extract(archive,shortcuts=True):
    packaged=metadata(archive)
    parent,target=checked_install_target()
    reject_managed_downgrade(target,packaged)
    staging=parent/(APP_ID+'WorkspaceApp.staging-'+uuid.uuid4().hex)
    backup=parent/(APP_ID+'WorkspaceApp.previous-'+uuid.uuid4().hex)
    staging.mkdir()
    base=staging.resolve()
    with zipfile.ZipFile(archive) as z:
        for item in z.infolist():
            destination=(base/item.filename).resolve()
            if not destination.is_relative_to(base) or ':' in item.filename: raise ValueError('安装包路径无效')
        if z.testzip():raise ValueError('安装包完整性校验失败')
        z.extractall(base)
    if not (base/EXECUTABLE).is_file():raise ValueError('安装包缺少程序入口')
    packaged=json.loads((base/'company.json').read_text('utf-8-sig'))
    bundle,installation=managed_layout(base,packaged)
    legacy_shortcut_title=None
    # Updates preserve local customer branding and company settings. Data is a sibling,
    # never in this program payload or touched by the installer.
    if target.exists():
        existing=target/'company.json'
        old_bundle=target
        if existing.is_file():
            old_summary=json.loads(existing.read_text('utf-8-sig'))
            old_bundle,old_installation=managed_layout(target,old_summary,initial=False)
            current=json.loads((old_bundle/'company.json').read_text('utf-8-sig')) if old_installation else old_summary
            current_runtime=current.get('runtime') or {}
            if (installation and current_runtime.get('role')=='local_assistant_only'
                    and current_runtime.get('ui_entry')!='employee_workspace'):
                legacy_shortcut_title=current.get('name','')+'本地助手'
            merged=merge_company_config(current,packaged)
            (base/'company.json').write_text(json.dumps(merged,ensure_ascii=False,indent=2),encoding='utf-8')
            if installation:(bundle/'company.json').write_text(json.dumps(merged,ensure_ascii=False,indent=2),encoding='utf-8')
        custom=old_bundle/'客户定制'
        if custom.exists():
            if custom.is_symlink() or not custom.resolve().is_relative_to(target):raise ValueError('定制目录路径无效')
            for original in custom.rglob('*'):
                if original.is_symlink() or not original.resolve().is_relative_to(custom.resolve()):raise ValueError('定制目录不能包含外部链接')
                if original.is_file():
                    destination=bundle/'客户定制'/original.relative_to(custom)
                    destination.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(original,destination)
    # Uninstaller script validates the exact expected directory before recursive removal.
    uninstall=r'''$expected=Join-Path $env:LOCALAPPDATA '__DIRECTORY__'
$target=[IO.Path]::GetFullPath($PSScriptRoot)
if ($target -ne [IO.Path]::GetFullPath($expected)) { throw '卸载路径验证失败' }
$item=Get-Item -LiteralPath $target -Force
if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw '卸载目录不能是链接或重解析点' }
Add-Type -AssemblyName System.Windows.Forms
$ok=[System.Windows.Forms.MessageBox]::Show('删除软件程序？业务数据和账号资料将保留。请先关闭软件。',__CAPTION__,'YesNo')
if ($ok -ne 'Yes') { exit }
$shortcut=Join-Path ([Environment]::GetFolderPath('Desktop')) __SHORTCUT__
$menu=Join-Path ([Environment]::GetFolderPath('Programs')) __TITLE__
$menuShortcut=Join-Path $menu __SHORTCUT__
$expectedExe=Join-Path $target __EXECUTABLE__
foreach ($link in @($shortcut,$menuShortcut)) {
    if (Test-Path -LiteralPath $link -PathType Leaf) {
        $shell=New-Object -ComObject WScript.Shell
        $existing=$shell.CreateShortcut($link)
        if ([string]::Equals($existing.TargetPath,$expectedExe,[StringComparison]::OrdinalIgnoreCase)) {
            Remove-Item -LiteralPath $link -Force
        }
    }
}
if ((Test-Path -LiteralPath $menu -PathType Container) -and -not (Get-ChildItem -LiteralPath $menu -Force | Select-Object -First 1)) {
    Remove-Item -LiteralPath $menu
}
Remove-Item -LiteralPath $target -Recurse -Force
'''
    uninstall=(uninstall.replace('__DIRECTORY__',APP_ID+'WorkspaceApp')
               .replace('__CAPTION__',quote('卸载'+TITLE))
               .replace('__SHORTCUT__',quote(TITLE+'.lnk'))
               .replace('__TITLE__',quote(TITLE))
               .replace('__EXECUTABLE__',quote(EXECUTABLE)))
    (base/'卸载软件.ps1').write_text(uninstall,encoding='utf-8-sig')
    (base/'卸载软件.cmd').write_text('@echo off\r\npowershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0卸载软件.ps1"\r\n',encoding='gbk')
    moved=False
    try:
        if target.exists():os.replace(target,backup);moved=True
        os.replace(staging,target)
    except Exception:
        if moved and not target.exists():os.replace(backup,target)
        raise
    exe=target/EXECUTABLE
    script=shortcut_guard_script()+"$w=New-Object -ComObject WScript.Shell; $shortcutFailure=$false; $d=[Environment]::GetFolderPath('Desktop'); $link=Join-Path $d "+quote(TITLE+'.lnk')+"; if(-not (Save-InstanceShortcut $link "+quote(exe)+" "+quote(target)+" "+quote(str(exe)+',0')+")){$shortcutFailure=$true}"
    script+="; $m=Join-Path ([Environment]::GetFolderPath('Programs')) "+quote(TITLE)+"; New-Item -ItemType Directory -Force -Path $m | Out-Null; $link=Join-Path $m "+quote(TITLE+'.lnk')+"; if(-not (Save-InstanceShortcut $link "+quote(exe)+" "+quote(target)+" "+quote(str(exe)+',0')+")){$shortcutFailure=$true}"
    if not installation:
        script+="; $link=Join-Path $m '更换图片与文案.lnk'; if(-not (Save-InstanceShortcut $link "+quote(target/bundle.relative_to(base)/'客户定制')+" '' '')){$shortcutFailure=$true}"
    if legacy_shortcut_title:
        old_exe=target/packaged['runtime']['executable']
        script+=("; $oldExe="+quote(old_exe)+"; $oldTitle="+quote(legacy_shortcut_title)
                 +"; $oldDesktop=Join-Path ([Environment]::GetFolderPath('Desktop')) ($oldTitle+'.lnk')"
                 +"; $oldMenu=Join-Path ([Environment]::GetFolderPath('Programs')) $oldTitle"
                 +"; $oldMenuLink=Join-Path $oldMenu ($oldTitle+'.lnk')"
                 +"; foreach($oldLink in @($oldDesktop,$oldMenuLink)) { if(Test-Path -LiteralPath $oldLink -PathType Leaf) { $oldTarget=$w.CreateShortcut($oldLink).TargetPath; if([string]::Equals($oldTarget,$oldExe,[StringComparison]::OrdinalIgnoreCase)) { Remove-Item -LiteralPath $oldLink -Force } } }"
                 +"; if((Test-Path -LiteralPath $oldMenu -PathType Container) -and -not (Get-ChildItem -LiteralPath $oldMenu -Force | Select-Object -First 1)) { Remove-Item -LiteralPath $oldMenu }")
    script+="; if($shortcutFailure){exit 3}"
    if shortcuts:
        try:ps(script)
        except (OSError,subprocess.CalledProcessError):
            (target/'快捷方式创建失败.txt').write_text('程序已安装，请从以下路径启动'+TITLE+'：\n'+str(exe)+'\n',encoding='utf-8')
    if moved:(target/'previous-version.txt').write_text(str(backup),encoding='utf-8')
    return exe

def main():
    if '--self-test-install' in sys.argv:
        sandbox=Path(sys.argv[sys.argv.index('--self-test-install')+1]).resolve()
        if not sandbox.name.startswith('qa-install-'):raise ValueError('测试安装必须使用qa-install-前缀目录')
        sandbox.mkdir(parents=True,exist_ok=True)
        os.environ['LOCALAPPDATA']=str(sandbox)
        archive_path=sys.executable if getattr(sys,'frozen',False) else sys.argv[1]
        exe=extract(archive_path,shortcuts=False)
        (sandbox/'install-result.json').write_text(json.dumps({'executable':str(exe),'target':str(TARGET),'shortcuts':False},ensure_ascii=False),encoding='utf-8')
        return
    if '--verify-payload' in sys.argv:
        output=Path(sys.argv[sys.argv.index('--verify-payload')+1])
        metadata(sys.executable)
        with zipfile.ZipFile(sys.executable) as archive:
            bad=archive.testzip()
            if bad: raise RuntimeError(bad)
            output.write_text('verified '+str(len(archive.infolist()))+' files',encoding='utf-8')
        return
    archive_path=sys.executable if getattr(sys,'frozen',False) else sys.argv[1]
    try: metadata(archive_path)
    except Exception as ex:
        error_root=tk.Tk();error_root.withdraw();messagebox.showerror('安装包无效',str(ex));error_root.destroy();return
    root=tk.Tk();root.iconbitmap(str(Path(getattr(sys,'_MEIPASS',Path(__file__).resolve().parents[2]/'src/resources'))/'brand.ico'));root.title(TITLE+' · 安装');root.geometry('620x365');root.configure(bg='#f6f7f8');root.resizable(False,False)
    tk.Label(root,text=TITLE,font=('Microsoft YaHei UI',22,'bold'),bg='#f6f7f8',fg='#33465d').pack(pady=(28,12))
    tk.Label(root,text=('安装到当前用户，无需管理员权限。\n员工登录、采集与平台连接均在同一个工作台窗口。' if TITLE.endswith('工作台') else '安装到当前用户，无需管理员权限。\n网页安排任务，本地助手负责平台登录与执行。'),font=('Microsoft YaHei UI',11),bg='#f6f7f8').pack()
    tk.Label(root,text=str(TARGET),font=('Microsoft YaHei UI',9),bg='#f6f7f8',wraplength=570).pack(pady=16)
    status=tk.StringVar(value='安装前请先退出正在运行的软件。')
    tk.Label(root,textvariable=status,bg='#f6f7f8',font=('Microsoft YaHei UI',10)).pack()
    button=tk.Button(root,text='安装到此电脑',bg='#33465d',fg='white',font=('Microsoft YaHei UI',12),width=22)
    button.pack(pady=14)
    version=webview2_version()
    tk.Label(root,text=runtime_status_text(version,archive_path),font=('Microsoft YaHei UI',9),bg='#f6f7f8',fg='#33465d').pack()
    def runtime_link():
        import webbrowser
        webbrowser.open(WEBVIEW2_URL)
    tk.Button(root,text='Microsoft 官方运行时下载页',command=runtime_link,relief='flat',bg='#f6f7f8',fg='#33465d').pack()
    def finished(exe,error):
        if error:
            status.set('安装未完成');button.config(state='normal');messagebox.showerror('安装失败',error);return
        if (exe.parent/'快捷方式创建失败.txt').exists():
            status.set('程序已安装，但快捷方式未创建；可点击下方按钮打开。')
        else:status.set('安装完成，桌面快捷方式已创建。')
        button.config(text='打开'+TITLE,state='normal',command=lambda:os.startfile(exe))
    def work():
        try: prepare_runtime(archive_path);exe=extract(archive_path); error=None
        except Exception as e: exe=None;error=str(e)
        root.after(0,lambda:finished(exe,error))
    def start():
        button.config(state='disabled');status.set('正在准备运行环境并安装，请稍候……');threading.Thread(target=work,daemon=True).start()
    button.config(command=start);root.mainloop()

if __name__=='__main__':main()
