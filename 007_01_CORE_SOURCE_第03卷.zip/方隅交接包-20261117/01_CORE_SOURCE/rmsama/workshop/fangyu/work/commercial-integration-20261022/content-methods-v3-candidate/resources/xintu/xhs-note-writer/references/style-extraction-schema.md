# Style Extraction Schema

Produce one extraction block per reference note, then one merged `format_profile`.

## Per-reference record

- `post_id`
- `post_url`
- `format`: `carousel` or `video`
- `title`: exact visible title
- `metrics`: likes, collects, comments when visible; null otherwise
- `observable_copy`: only text actually retrieved
- `title_pattern`: e.g. number + result + audience, question + payoff, contrast hook
- `opening_move`: first line strategy
- `structure`: paragraph/list/step/qa/story/mixed
- `line_rhythm`: short bursts, medium paragraphs, heavy line breaks
- `emoji_usage`: none, light markers, section headers
- `proof_style`: screenshot, demo, personal result, list, quote, none visible
- `cta_style`: comment bait, save prompt, follow prompt, discussion question, soft none
- `tag_pattern`: count estimate and broad/specific mix when visible
- `transferable_mechanics`: bullet list
- `do_not_copy`: author-specific context, stories, exact phrases
- `missing_evidence`: e.g. full body unavailable

## Merged format_profile

After reviewing references of the same format:

- `voice_source`: `user_library` | `dna` | `provisional` | `market_structure_only`
- `dominant_title_patterns`
- `dominant_openings`
- `dominant_structures`
- `caption_length_band` (for video) or `body_length_band` (for carousel)
- `emoji_policy`
- `cta_policy`
- `tag_policy`
- `confidence`: high | medium | low
- `dna_conflicts`: patterns that conflict with account DNA avoid list

`voice_source=market_structure_only` means market samples may inform structure/CTA placement, but
must not supply identity words, openings, or stance. Prefer `provisional` or `user_library` for tone.

When `voice_source=user_library` and ≥2 user references exist, market samples may inform structure but must not override user voice mechanics.

## Confidence rules

- `high`: 3+ references agree on a mechanic and DNA does not conflict
- `medium`: 2 references agree, or 3 agree but DNA partially conflicts
- `low`: fewer than 3 usable references or missing body text for most samples
