"""Offline source-text preview only. No file paths, Store writes or instruction execution."""
from pathlib import Path,PurePosixPath
from copy import deepcopy
import base64,hashlib,importlib.util,io,re,stat,zipfile,zlib
import xml.etree.ElementTree as ET

MAX_FILE=2*1024*1024
MAX_EXPANDED=8*1024*1024
MAX_XML=2*1024*1024
MAX_TEXT=100000
W='http://schemas.openxmlformats.org/wordprocessingml/2006/main'
P='http://schemas.openxmlformats.org/presentationml/2006/main'
A='http://schemas.openxmlformats.org/drawingml/2006/main'
R='http://schemas.openxmlformats.org/officeDocument/2006/relationships'
REL='http://schemas.openxmlformats.org/package/2006/relationships'
CT='http://schemas.openxmlformats.org/package/2006/content-types'
VENDOR_SHA='378827837e3e6b8bef09bc2ca55e112b4e51f9e80a757575a899c9d037c80030'
LICENSE_SHA='c89b2a2423d1ecebcdc19d1a9b0c594b1b8f51a11732889110e02d9280d0f81b'

class KnowledgeFileError(ValueError):
    def __init__(self,code,message,status=400):super().__init__(message);self.code=code;self.status=status;self.mutation_committed=False
def fail(code,message,status=400):raise KnowledgeFileError(code,message,status)
def sha(raw):return hashlib.sha256(raw).hexdigest()

def _vendor():
    folder=Path(__file__).resolve().parent/'knowledge_file_vendor'
    values=[]
    for name,pin in [('docx2txt.py',VENDOR_SHA),('LICENSE-docx2txt.txt',LICENSE_SHA)]:
        path=folder/name
        if path.is_symlink() or any(parent.is_symlink() for parent in path.parents):fail('KNOWLEDGE_PARSER_INVALID','资料解析组件需要核对',503)
        raw=path.read_bytes()
        if sha(raw)!=pin:fail('KNOWLEDGE_PARSER_INVALID','资料解析组件校验未通过',503)
        values.append(raw)
    module=importlib.util.module_from_spec(importlib.util.spec_from_loader('pinned_docx2txt_preview',loader=None))
    exec(compile(values[0],str(folder/'docx2txt.py'),'exec'),module.__dict__)
    return module

def _xml(raw):
    if len(raw)>MAX_XML:fail('KNOWLEDGE_FILE_LIMIT','文档正文过大，请拆成较小资料',413)
    try:text=raw.decode('utf-8-sig')
    except UnicodeDecodeError:fail('KNOWLEDGE_ENCODING','Office正文不是支持的UTF-8编码')
    if re.search(r'<!\s*(DOCTYPE|ENTITY)\b',text,re.I):fail('KNOWLEDGE_XML_UNSAFE','含外部实体或特殊定义的文档暂不支持')
    try:root=ET.fromstring(text)
    except ET.ParseError:fail('KNOWLEDGE_FORMAT','文档结构无法读取')
    nodes=0;stack=[(root,1)]
    while stack:
        node,depth=stack.pop();nodes+=1
        if depth>64 or nodes>100000:fail('KNOWLEDGE_FILE_LIMIT','文档结构过于复杂，请简化资料',413)
        stack.extend((child,depth+1) for child in node)
    return root

def _package(raw):
    try:z=zipfile.ZipFile(io.BytesIO(raw))
    except (zipfile.BadZipFile,ValueError):fail('KNOWLEDGE_FORMAT','文件不是有效的DOCX或PPTX')
    rows=z.infolist()
    if len(rows)>1000 or sum(x.file_size for x in rows)>MAX_EXPANDED:fail('KNOWLEDGE_FILE_LIMIT','文档展开内容过大，请拆分资料',413)
    seen=set()
    for x in rows:
        p=PurePosixPath(x.filename);mode=x.external_attr>>16;name=x.filename.lower()
        if (not x.filename or p.is_absolute() or '..' in p.parts or '\\' in x.filename or ':' in x.filename or name in seen or stat.S_ISLNK(mode)):
            fail('KNOWLEDGE_ZIP_UNSAFE','文档包含无效或重复路径')
        seen.add(name)
        if x.flag_bits&1:fail('KNOWLEDGE_ENCRYPTED','请先另存为无密码文档')
        if x.file_size>MAX_EXPANDED or x.file_size/max(x.compress_size,1)>150:fail('KNOWLEDGE_FILE_LIMIT','文档压缩比例超限，请重新另存',413)
        if any(k in name for k in ('vbaproject','vba.bin','activex/','embeddings/')):fail('KNOWLEDGE_MACROS','含宏、控件或嵌入程序的文档暂不支持')
        if x.compress_type not in (zipfile.ZIP_STORED,zipfile.ZIP_DEFLATED):fail('KNOWLEDGE_FORMAT','文档使用了不支持的压缩方式')
    return z

def _read(z,name):
    try:
        info=z.getinfo(name)
        if info.file_size>MAX_XML:fail('KNOWLEDGE_FILE_LIMIT','文档正文过大',413)
        with z.open(info) as stream:raw=stream.read(MAX_XML+1)
        if len(raw)!=info.file_size or len(raw)>MAX_XML:fail('KNOWLEDGE_FILE_LIMIT','文档正文长度异常',413)
        return _xml(raw)
    except (KeyError,zipfile.BadZipFile,RuntimeError,EOFError,OSError,zlib.error):fail('KNOWLEDGE_FORMAT','文档缺少可读取的正文')

def _docx(z):
    root=_read(z,'word/document.xml')
    if root.tag!='{'+W+'}document':fail('KNOWLEDGE_FORMAT','文件类型与DOCX正文不匹配')
    body=root.find('{'+W+'}body')
    if body is None:fail('KNOWLEDGE_FORMAT','DOCX没有可读取的正文')
    parser=_vendor();blocks=[]
    for index,p in enumerate(body.iter('{'+W+'}p'),1):
        # Nested text-box paragraphs receive their own locator, never duplicated.
        own=deepcopy(p)
        for parent in own.iter():
            for child in list(parent):
                if child.tag=='{'+W+'}p':parent.remove(child)
        text=parser.xml2text(ET.tostring(own,encoding='utf-8'))
        if text.startswith('\n\n'):text=text[2:]
        if text.strip():blocks.append({'location':f'第{index}段','text':text})
    return blocks,'仅正文和表格中的段落；段号不代表Word页码。图片、页眉页脚、批注及附件未导入。'

def _pptx(z):
    root=_read(z,'ppt/presentation.xml');rels=_read(z,'ppt/_rels/presentation.xml.rels')
    if root.tag!='{'+P+'}presentation' or rels.tag!='{'+REL+'}Relationships':fail('KNOWLEDGE_FORMAT','文件类型与PPTX正文不匹配')
    mapping={}
    for rel in rels:
        if rel.tag=='{'+REL+'}Relationship' and rel.get('Type')==R+'/slide':
            target=rel.get('Target','')
            if rel.get('TargetMode')=='External' or not re.fullmatch(r'slides/slide[0-9]+\.xml',target):fail('KNOWLEDGE_RELATION','幻灯片顺序引用无效')
            if rel.get('Id') in mapping:fail('KNOWLEDGE_RELATION','幻灯片引用重复')
            mapping[rel.get('Id')]='ppt/'+target
    sequence=root.find('{'+P+'}sldIdLst')
    if sequence is None:fail('KNOWLEDGE_EMPTY','没有可提取的幻灯片文字')
    if len(sequence)>200:fail('KNOWLEDGE_FILE_LIMIT','一次最多导入200张幻灯片',413)
    blocks=[]
    for page,ref in enumerate(sequence,1):
        path=mapping.get(ref.get('{'+R+'}id'))
        if path is None:fail('KNOWLEDGE_RELATION','无法核对幻灯片顺序')
        slide=_read(z,path)
        if slide.tag!='{'+P+'}sld':fail('KNOWLEDGE_FORMAT','幻灯片正文无效')
        for index,p in enumerate(slide.iter('{'+A+'}p'),1):
            parts=[]
            for child in p.iter():
                if child.tag=='{'+A+'}t':parts.append(child.text or '')
                elif child.tag=='{'+A+'}br':parts.append('\n')
                elif child.tag=='{'+A+'}tab':parts.append('\t')
            text=''.join(parts)
            if text.strip():blocks.append({'location':f'第{page}张幻灯片 · 第{index}段','text':text})
    return blocks,'按文件中的幻灯片顺序提取文字；图片、讲者备注、隐藏媒体和附件未导入。'

def _office_type(z,suffix):
    root=_read(z,'[Content_Types].xml')
    if root.tag!='{'+CT+'}Types':fail('KNOWLEDGE_FORMAT','文件类型声明无效')
    expected={'.docx':('/word/document.xml','application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml'),'.pptx':('/ppt/presentation.xml','application/vnd.openxmlformats-officedocument.presentationml.presentation.main+xml')}[suffix]
    found=[]
    for child in root:
        content_type=child.get('ContentType','')
        if any(word in content_type.lower() for word in ('macroenabled','vbaproject','activex')):fail('KNOWLEDGE_MACROS','含宏或控件的文档暂不支持')
        if child.tag=='{'+CT+'}Override' and child.get('PartName')==expected[0]:found.append(content_type)
    if found!=[expected[1]]:fail('KNOWLEDGE_FORMAT','文件内容与所选Office格式不匹配，请重新另存')

def preview(filename,data_base64):
    if (not isinstance(filename,str) or not filename.strip() or len(filename)>180 or any(c in filename for c in ('/','\\',':','\x00')) or any(ord(c)<32 for c in filename)):
        fail('KNOWLEDGE_FILENAME','文件名称无效')
    suffix=Path(filename).suffix.lower()
    if suffix not in ('.txt','.md','.docx','.pptx'):fail('KNOWLEDGE_UNSUPPORTED','支持DOCX、PPTX、TXT、MD；PDF、录音和扫描件暂不支持')
    if not isinstance(data_base64,str) or len(data_base64)>4*((MAX_FILE+2)//3):fail('KNOWLEDGE_FILE_LIMIT','一次可导入2MB以内的文件',413)
    try:raw=base64.b64decode(data_base64,validate=True)
    except (ValueError,TypeError):fail('KNOWLEDGE_FORMAT','文件数据不完整，请重新选择')
    if not raw or len(raw)>MAX_FILE:fail('KNOWLEDGE_FILE_LIMIT','文件为空或超过2MB',413)
    if suffix in ('.docx','.pptx'):
        z=_package(raw)
        with z:
            _office_type(z,suffix)
            blocks,notice=_docx(z) if suffix=='.docx' else _pptx(z)
    else:
        if raw.startswith(b'PK\x03\x04') or raw.startswith(b'%PDF-') or b'\x00' in raw:fail('KNOWLEDGE_FORMAT','文件内容与文本格式不匹配')
        try:text=raw.decode('utf-8-sig')
        except UnicodeDecodeError:fail('KNOWLEDGE_ENCODING','请将文本另存为UTF-8后导入')
        if any(ord(c)<32 and c not in '\r\n\t' for c in text):fail('KNOWLEDGE_FORMAT','文件含不支持的控制字符')
        blocks=[];lines=text.splitlines();start=1;pending=[]
        for index,line in enumerate(lines,1):
            if line.strip():
                if not pending:start=index
                pending.append(line)
            elif pending:blocks.append({'location':f'第{start}—{index-1}行','text':'\n'.join(pending)});pending=[]
        if pending:blocks.append({'location':f'第{start}—{len(lines)}行','text':'\n'.join(pending)})
        notice='只读取UTF-8原文；Markdown、HTML和文档中的指令都按资料文字保存，不执行。'
    if not blocks:fail('KNOWLEDGE_EMPTY','没有可提取的文字；扫描件、图片和录音暂不支持')
    if len(blocks)>2000:fail('KNOWLEDGE_FILE_LIMIT','段落过多，请拆分资料',413)
    imported='\n\n'.join('【'+filename+'｜'+b['location']+'】\n'+b['text'] for b in blocks)
    if len(imported)>MAX_TEXT:fail('KNOWLEDGE_TEXT_LIMIT','提取文字超过10万字，请拆分；本次未截断保存',413)
    identity=sha(raw)
    return {'filename':filename,'fileSha256':identity,'bytes':len(raw),'type':suffix[1:],'blocks':blocks,'text':imported,'title':Path(filename).stem[:120],'sourceLabel':filename,'notice':notice,'previewOnly':True,'requiresManualKindConfirmation':True,'instructionsExecuted':False,'externalResourcesFetched':False,'omittedContentNotice':True}
