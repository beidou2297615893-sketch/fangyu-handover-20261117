"""Derive bounded cloud changes from the last exact production code readback."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import shutil

D=Path(__file__).resolve().parent
BASE=D.parent/'content-cloud-v3-final2'
S=BASE/'candidate'
T=D/'cloud-candidate-final'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text('utf-8-sig'))
assert not T.exists()
readback=read(BASE/'DEPLOYMENT-READBACK.json')
assert readback['status']=='DEPLOYED_EXACT_FULL_READBACK'
assert readback['treeSha256']=='744ec24509d6602618543d6c760130de1d7b45a0acc05be89aa09592a03c5a02'
pins={r['path']:r for r in read(BASE/'FILES-SHA256.json')}
T.mkdir()
origins=[]
for path in S.iterdir():
 if not path.is_file():continue
 assert sha(path)==pins[path.name]['sha256']
 shutil.copy2(path,T/path.name)
 origins.append({'path':path.name,'beforeSha256':sha(path)})
def change(name,old,new,count=1):
 p=T/name;raw=p.read_bytes();a=old.encode();b=new.encode()
 assert raw.count(a)==count,(name,old[:100],raw.count(a))
 p.write_bytes(raw.replace(a,b))
change('devices.cjs',"const {adminWorkbenchFor,sourceFields}=require('./admin_workbench_policy.cjs');", "const {adminWorkbenchFor,sourceFields}=require('./admin_workbench_policy.cjs');\nconst customerRead=require('./customer_read_release.cjs');")
change('devices.cjs',"platformQaDeviceId='',qaContinuousUntil=0,continuousReadonlyDeviceId=''}){", "platformQaDeviceId='',qaContinuousUntil=0,continuousReadonlyDeviceId='',customerReadReleaseEnabled=false,customerReadReleaseVersion=''}){")
change('devices.cjs'," const employeePolicy=safetyHold&&employeeReleaseEnabled===true&&employeeReleaseVersion==='1.1.8-pilot.1';", " const employeePolicy=safetyHold&&employeeReleaseEnabled===true&&employeeReleaseVersion==='1.1.8-pilot.1';\n const customerReadPolicy=customerRead.configEnabled(companyId,customerReadReleaseEnabled,customerReadReleaseVersion);\n const matchingCustomerReadRequest=customerReadPolicy&&customerRead.requestMatches(payload);\n const customerReadLease=d=>customerRead.leaseForDevice({companyId,enabled:customerReadReleaseEnabled,version:customerReadReleaseVersion,requestVersion:payload.version,protocol:payload.customer_read_protocol,device:d,owner:d&&state.users.find(u=>u.username===d.owner&&!u.disabled),now});")
change('devices.cjs',"status===200&&op==='device_poll'?{...data,safety_hold:safetyHold&&!qaForDevice(pollingDevice)&&!employeeForDevice(pollingDevice),", "status===200&&op==='device_poll'?{...data,safety_hold:safetyHold&&!qaForDevice(pollingDevice)&&!employeeForDevice(pollingDevice)&&!(matchingCustomerReadRequest&&customerReadLease(pollingDevice).allowed),\n   ...(Object.hasOwn(payload,'customer_read_protocol')?{customer_read_release:customerReadLease(pollingDevice)}:{}),")
change('devices.cjs',"if(safetyHold&&!qaPairing&&!employeePolicy)return respond(423", "if(safetyHold&&!qaPairing&&!employeePolicy&&!matchingCustomerReadRequest)return respond(423",2)
change('devices.cjs',"&&!(qaPairing&&payload.version===pairingVersion)&&!(releaseApproved&&payload.version===releaseVersion))", "&&!(qaPairing&&payload.version===pairingVersion)&&!(releaseApproved&&payload.version===releaseVersion)\n      &&!matchingCustomerReadRequest)")
change('release.cjs'," return {active,version:active?version:'',pairingAllowed,pairingVersion:pairingAllowed?qaVersion:'',", " const customerReadVersion=String(env.FANGYU_CUSTOMER_READ_RELEASE_VERSION||'');\n const customerReadReleaseEnabled=env.COMPANY_ID==='fangyu-apartment-client'\n  && !active && env.FANGYU_CUSTOMER_READ_RELEASE_ENABLED==='1' && customerReadVersion==='1.2.0-read.1';\n return {active,version:active?version:'',pairingAllowed,pairingVersion:pairingAllowed?qaVersion:'',\n  customerReadReleaseEnabled,customerReadReleaseVersion:customerReadReleaseEnabled?customerReadVersion:'',")
change('service.cjs',"employeeReleaseEnabled = false, employeeReleaseVersion = '', platformQaDeviceId", "employeeReleaseEnabled = false, employeeReleaseVersion = '', customerReadReleaseEnabled = false, customerReadReleaseVersion = '', platformQaDeviceId")
change('service.cjs',"pairingApproved,pairingVersion,employeeReleaseEnabled,employeeReleaseVersion,\n          platformQaDeviceId", "pairingApproved,pairingVersion,employeeReleaseEnabled,employeeReleaseVersion,\n          customerReadReleaseEnabled,customerReadReleaseVersion,platformQaDeviceId")
change('index.js',"employeeReleaseEnabled:release.employeeReleaseEnabled,employeeReleaseVersion:release.employeeReleaseVersion,", "employeeReleaseEnabled:release.employeeReleaseEnabled,employeeReleaseVersion:release.employeeReleaseVersion,\n    customerReadReleaseEnabled:release.customerReadReleaseEnabled,customerReadReleaseVersion:release.customerReadReleaseVersion,")
shutil.copy2(D/'new-source/customer_read_release.cjs',T/'customer_read_release.cjs')
rows=[]
for before in origins:
 p=T/before['path']
 if sha(p)!=before['beforeSha256']:rows.append({**before,'afterSha256':sha(p),'bytes':p.stat().st_size})
rows.append({'path':'customer_read_release.cjs','beforeSha256':None,'afterSha256':sha(T/'customer_read_release.cjs'),'bytes':(T/'customer_read_release.cjs').stat().st_size})
result={'utc':datetime.now(timezone.utc).isoformat(),'status':'SOURCE_CANDIDATE_NOT_TESTED_OR_DEPLOYED',
 'baseExactReadbackTreeSha256':readback['treeSha256'],'fixedSpecSha256':sha(D/'CUSTOMER-READ-LEASE-SPEC.json'),
 'sourceFiles':rows,'invariants':['old employee_release and pilot checks unchanged','remote command allowances unchanged','public sends not granted','new policy default false','new exact protocol/version only'],
 'productionOrEnvironmentOrPrivateStateWritten':False,'externalRequests':0}
(D/'SOURCE-CANDIDATE.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n','utf-8')
print(json.dumps({'status':result['status'],'sourceFiles':len(rows)}))
