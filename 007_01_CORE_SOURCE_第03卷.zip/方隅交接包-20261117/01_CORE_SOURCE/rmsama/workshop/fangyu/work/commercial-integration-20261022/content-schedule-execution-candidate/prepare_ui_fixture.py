from pathlib import Path
W=Path(__file__).resolve().parent
source=W.parent/'content-guided-methods-candidate/serve_guided_ui.py'
text=source.read_text('utf-8')
old="stage=json.loads((W/'BACKEND-STAGE.json').read_text('utf-8'));S=W/'project';R=Path(stage['release']);out=W/('ui-http-'+uuid.uuid4().hex)"
new="inputs=json.loads((W/'QA-INPUTS.json').read_text('utf-8'));stage=inputs['stage'];S=Path(inputs['project']);R=Path(stage['release']);out=W/('ui-http-'+uuid.uuid4().hex)"
assert text.count(old)==1;text=text.replace(old,new)
text=text.replace("'guided-ui-account'","'schedule-ui-account'").replace("'platformNickname':'合成内容昵称'","'platformNickname':'合成内容昵称','platform_uid':'schedule-ui-uid'")
marker="info={'origin':"
seed="""from PIL import Image
from io import BytesIO
import base64
base={'storeId':cloud.first_store,'accountId':'schedule-ui-account','platform':'xiaohongshu'}
trace=[]
def content(name,**data):
 current,_=setup_request('POST',{'action':'content_workspace_read','data':base})
 payload={'action':name,'data':{**base,'requestId':uuid.uuid4().hex,'expectedRevision':current['workspace']['revision'],**data}}
 result,_=setup_request('POST',payload);trace.append({'request':payload,'body':result});return result
buf=BytesIO();Image.new('RGB',(4,4),'blue').save(buf,format='PNG')
asset=content('content_asset_import',name='授权合成图.png',mime='image/png',source='authorized_real',rightsConfirmed=True,dataBase64=base64.b64encode(buf.getvalue()).decode())['result']['asset']
draft=content('content_draft_save',draft={'title':'本人核对后的合成日历稿','body':'内容与房源均为验收样例，需要本人核实。','format':'image','assetIds':[asset['id']]})['workspace']['drafts'][-1]
content('content_draft_audit',draftId=draft['id'],decision='approve',note='合成明确核对')
backend.core.store.put('accounts',{'id':'schedule-ui-account-2','tenant_id':user['tenant_id'],'cloud_owner':user['username'],'store_id':cloud.first_store,'platform':'xiaohongshu','status':'disconnected','name':'合成第二账号','platform_uid':'schedule-ui-uid-2'})
(out/'UI-SEED-HTTP.json').write_text(json.dumps(trace,ensure_ascii=False,indent=2),'utf-8')
"""
assert text.count(marker)==1;text=text.replace(marker,seed+marker)
# Avoid shadowing the imported asset's name field in the seed helper.
text=text.replace('def content(name,**data):','def content(action_name,**data):').replace("payload={'action':name,","payload={'action':action_name,")
(W/'serve_schedule_ui.py').write_text(text,'utf-8')
print('Original full index/fit Native HTTP UI fixture adapted, synthetic assets only')
