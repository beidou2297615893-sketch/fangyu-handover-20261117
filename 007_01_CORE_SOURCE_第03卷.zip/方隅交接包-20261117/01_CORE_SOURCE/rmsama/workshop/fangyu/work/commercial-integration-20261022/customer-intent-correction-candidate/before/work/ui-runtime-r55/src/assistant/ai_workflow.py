"""Local reusable keyword library and semantic results; provider keys stay in cloud."""
import hashlib
import json
import re
import threading
from copy import deepcopy
from datetime import datetime, timezone
from urllib.parse import urlsplit

LEVELS = ('super_high', 'high', 'medium', 'low', 'very_low')
RULE_VERSION = 'apartment-intent-v2'
INFO_TYPES = frozenset(('budget', 'move_in', 'commute', 'room_type', 'location'))
KEYWORD_POOL_LIMIT = 500

class KeywordRevisionConflict(ValueError):
    pass

class AIContextRequired(ValueError):
    code = 'AI_CONTEXT_REQUIRED'

class AIProfileChanged(ValueError):
    code = 'AI_CONFIG_CHANGED'

def expected_rules_version(profile):
    version = profile.get('rules_version') if isinstance(profile, dict) else None
    if not isinstance(version, str) or not version or len(version) > 256:
        raise AIProfileChanged('企业 AI 规则版本无法核对，请刷新后再分析')
    return version

def verify_result_rules_version(value, expected):
    if not isinstance(value, dict) or value.get('rules_version') != expected:
        raise AIProfileChanged('企业 AI 规则已变化，结果未保存，请刷新后再分析')

def published_policy_metadata(profile):
    value = profile.get('published_policy') if isinstance(profile, dict) else None
    if value is None:
        return None
    from .company_intent_policy import safe_projection, CompanyIntentPolicyError
    try:
        return safe_projection(value)
    except CompanyIntentPolicyError:
        raise AIProfileChanged('公司规则版本回执无法核对，未开始新分析') from None

def stable_published_policy(profile):
    value = published_policy_metadata(profile)
    # facts_as_of is a read timestamp, not a version. Effective fact hashes and
    # valid-until bind expiration without making every profile read a new key.
    return {key: item for key, item in value.items() if key != 'facts_as_of'} if value else None

def verify_applied_policy(value, profile, request_id):
    expected = stable_published_policy(profile)
    if expected is None:
        if value.get('applied_policy') is not None:
            raise AIProfileChanged('公司规则适用范围已变化，结果未保存')
        return None
    from .company_intent_policy import safe_projection, CompanyIntentPolicyError
    try:
        applied = safe_projection(value.get('applied_policy'), applied=True,
                                  expected_original_request_id=request_id)
    except CompanyIntentPolicyError:
        raise AIProfileChanged('分析结果未对应原公司规则与请求，结果未保存') from None
    if (value.get('policy_revalidation_required') is not False or
            {key: item for key, item in applied.items() if key not in ('facts_as_of', 'original_request_id')} != expected):
        raise AIProfileChanged('公司规则或资料有效期已变化，结果未保存')
    return applied

def optional_context_text(value, limit):
    if value is None:return ''
    if not isinstance(value,str) or len(value)>limit:
        raise AIContextRequired('AI 分析上下文字段类型或长度不符合要求，评论保持待分析')
    return value

TASK_CONTEXT_FIELDS = ('id', 'tenant_id', 'cloud_owner', 'store_id', 'platform', 'account_id', 'scope',
    'note_url', 'keywords', 'excludes', 'region', 'city', 'area', 'intent_mode',
    'date_from', 'date_to', 'comment_date_range', 'comment_date_from', 'comment_date_to',
    'search_pages', 'unknown_policy', 'excluded_authors', 'excluded_bloggers',
    'high_intent_words', 'medium_intent_words', 'negative_intent_words',
    'comment_keyword_mode', 'comment_depth', 'source_blogger', 'blogger_unknown_policy')
LEAD_CONTEXT_FIELDS = ('tenant_id', 'task_id', 'cloud_owner', 'text', 'parent_text',
    'content_title', 'content_author', 'author', 'author_id', 'content_author_id',
    'note_url', 'url', 'published_at', 'ip_location', 'region')

def digest(value):
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True,
                                     separators=(',', ':')).encode()).hexdigest()

def timestamp():
    return datetime.now(timezone.utc).isoformat()

def keyword_text(value, label='关键词'):
    if (not isinstance(value,str) or not value.strip() or len(value.strip())>80
            or any(ord(char)<32 for char in value) or re.search(r'https?://|www\.|[/\\]',value,re.I)):
        raise ValueError(f'{label}格式不正确')
    return value.strip()

def keyword_candidates(values, source='manual'):
    if not isinstance(values,list) or len(values)>KEYWORD_POOL_LIMIT:
        raise ValueError('关键词池最多500条')
    result=[];seen=set()
    for item in values:
        word=keyword_text(item if isinstance(item,str) else item.get('keyword') if isinstance(item,dict) else None)
        if word in seen:continue
        seen.add(word)
        meta=item if isinstance(item,dict) else {}
        group=meta.get('group','')
        reason=meta.get('reason','')
        if not isinstance(group,str) or len(group)>40 or not isinstance(reason,str) or len(reason)>300:
            raise ValueError('关键词说明格式不正确')
        result.append({'keyword':word,'group':group.strip(),'recommended':meta.get('recommended') is True,
                       'reason':reason.strip(),'source':source})
    return result

def keyword_selection(values):
    if not isinstance(values,list) or len(values)>KEYWORD_POOL_LIMIT:
        raise ValueError('已选关键词最多500条')
    return list(dict.fromkeys(keyword_text(value) for value in values))

def model_metadata(value, fallback=None):
    """Keep only recognized model identity, never provider payloads or credentials."""
    fallback = fallback or {}
    model = value.get('model') or fallback.get('model')
    allowed = {'deepseek-flash': 'deepseek', 'deepseek-v4-pro': 'deepseek',
               'gpt-6.1-sol': 'openai', 'gpt-5.4-mini': 'openai'}
    base = next((name for name in allowed if model == name or
                 isinstance(model, str) and model.startswith(name+'-') and
                 re.fullmatch(r'\d{4}-\d{2}-\d{2}',model[len(name)+1:])), None)
    if not base:
        return {}
    provider = value.get('provider') or fallback.get('provider') or allowed[base]
    if provider != allowed[base]:
        return {}
    configured = value.get('configured_model') or fallback.get('model') or base
    if configured not in allowed or allowed[configured] != provider:
        configured = base
    effort = value.get('reasoning_effort', fallback.get('reasoning_effort'))
    return {'provider': provider, 'model': model, 'configured_model': configured,
            **({'reasoning_effort': effort} if effort in
               ('none', 'low', 'medium', 'high', 'xhigh', 'max') else {})}

def effective_intent(lead):
    manual = lead.get('manual_intent')
    ai = lead.get('ai_intent')
    if isinstance(manual,dict):return manual
    if isinstance(ai,dict):return ai
    if lead.get('analysis_status')=='missing_text':
        return {'status':'uncertain','level':None,'source':'metadata',
                'reason':'缺少评论正文，未调用 AI，请核对原评论'}
    return {'status':'pending','level':None}

def post_identity(lead):
    url=str(lead.get('note_url') or lead.get('url') or '')
    parts=urlsplit(url)
    return ((parts.hostname or '')+parts.path)[:200] or digest([lead.get('content_title'),lead.get('content_author')])

class LocalAIWorkflow:
    def __init__(self, core, cloud, *, company=None, host_context=None):
        self.core, self.cloud = core, cloud
        self.company = company if company is not None else {}
        self.lock = threading.RLock()
        from .ai_attempts import LocalAIAttempts
        self.attempts = LocalAIAttempts(core, lambda user, operation, data: self.cloud(user, operation, data), host_context=host_context or
                                       (lambda: {'company': self._current_company()}))

    def _current_company(self):
        value = self.company() if callable(self.company) else self.company
        if not isinstance(value, dict):
            raise ValueError('当前可信企业配置需核对')
        return value

    def _regrade_collection_idle(self, task_id):
        collection = self.core.store.get('continuous_tasks', task_id) or {}
        return (task_id not in getattr(self.core, 'running', {}) and
                collection.get('status') in (None, 'paused', 'idle') and
                not collection.get('inflight'))

    def _key(self, user, kind, payload, profile):
        identity = [user['tenant_id'], user['username'], kind, payload, profile.get('model'),
                       profile.get('rules_version'), profile.get('revision'), RULE_VERSION,
                       profile.get('provider'), profile.get('reasoning_effort')]
        published = stable_published_policy(profile)
        return digest(identity + ([published] if published is not None else []))

    def _cached(self, user, key):
        record = self.core.store.get('ai_cache', key)
        return record.get('value') if record and record.get('tenant_id') == user['tenant_id'] else None

    def _put_cache(self, user, key, value, *, db=None):
        row = {'id': key, 'tenant_id': user['tenant_id'], 'value': value, 'created_at': timestamp()}
        if db is None:
            self.core.store.put('ai_cache', row)
        else:
            db.execute('INSERT OR REPLACE INTO records VALUES(?,?,?,?)',
                ('ai_cache', key, user['tenant_id'], json.dumps(row, ensure_ascii=False)))

    def _regional_id(self,user,city,area):
        return digest(['regional-keywords-v1',user['tenant_id'],user['username'],city,area])

    def _regional_legacy(self,db,user,city,area):
        rows=db.execute('SELECT body FROM records WHERE entity=? AND tenant_id=?',
                        ('keyword_libraries',user['tenant_id'])).fetchall()
        legacy=[]
        for item in rows:
            row=json.loads(item['body'])
            request=row.get('request') or {}
            if (row.get('kind')=='regional_state' or row.get('owner')!=user['username'] or
                    request.get('city')!=city or (request.get('area') or '')!=area):
                continue
            legacy.append(row)
        if not legacy:return None
        row=max(legacy,key=lambda item:(item.get('updated_at') or item.get('created_at') or '',item['id']))
        candidates=keyword_candidates(row.get('keywords') or [],'legacy')
        selected=keyword_selection(row.get('selected') or [])
        known={item['keyword'] for item in candidates}
        candidates.extend(keyword_candidates([word for word in selected if word not in known],'legacy'))
        return {'id':self._regional_id(user,city,area),'tenant_id':user['tenant_id'],
                'owner':user['username'],'kind':'regional_state',
                'request':{'city':city,'area':area,'seeds':request.get('seeds') or [],
                           'count':request.get('count') if request.get('count') in (10,20,50,100) else 50},
                'keywords':candidates[:KEYWORD_POOL_LIMIT],'selected':selected,'revision':0,
                'created_at':row.get('created_at') or timestamp(),
                'updated_at':row.get('updated_at') or row.get('created_at') or timestamp()}

    def _regional_current(self,db,user,city,area):
        ident=self._regional_id(user,city,area)
        found=db.execute('SELECT body FROM records WHERE entity=? AND id=? AND tenant_id=?',
                         ('keyword_libraries',ident,user['tenant_id'])).fetchone()
        if found:
            row=json.loads(found['body'])
            if row.get('owner')!=user['username'] or row.get('kind')!='regional_state':
                raise ValueError('关键词库归属不匹配')
            return row
        return self._regional_legacy(db,user,city,area)

    def keyword_state(self,user,data):
        """Read or atomically save the owner's durable regional candidate pool."""
        if not isinstance(data,dict) or set(data)-{'mode','city','area','seeds','count','keywords','selected','expected_revision'}:
            raise ValueError('关键词库参数不正确')
        mode=data.get('mode')
        if mode not in ('read','save'):raise ValueError('关键词库操作不正确')
        city=data.get('city','');area=data.get('area','')
        if not isinstance(city,str) or not isinstance(area,str) or len(city.strip())>60 or len(area.strip())>80:
            raise ValueError('城市或区域格式不正确')
        city,area=city.strip(),area.strip()
        if mode=='save' and not city:raise ValueError('保存关键词请填写城市')
        if mode=='read':
            if set(data)-{'mode','city','area'}:raise ValueError('读取关键词库参数不正确')
            with self.core.store.connect() as db:
                if city:row=self._regional_current(db,user,city,area)
                else:
                    records=db.execute('SELECT body FROM records WHERE entity=? AND tenant_id=?',
                                       ('keyword_libraries',user['tenant_id'])).fetchall()
                    own=[json.loads(item['body']) for item in records]
                    own=[item for item in own if item.get('owner')==user['username']
                         and isinstance((item.get('request') or {}).get('city'),str)
                         and (item.get('request') or {}).get('city')]
                    latest=max(own,key=lambda item:(item.get('updated_at') or item.get('created_at') or '',
                                                    item.get('kind')=='regional_state',item['id']),default=None)
                    request=latest.get('request') or {} if latest else {}
                    row=self._regional_current(db,user,request.get('city',''),request.get('area') or '') if latest else None
            return {'library':self._regional_view(row)}
        revision=data.get('expected_revision')
        if type(revision) is not int or revision<0:raise ValueError('保存关键词需当前版本')
        seeds=data.get('seeds')
        if seeds is not None:
            if not isinstance(seeds,list) or len(seeds)>20:raise ValueError('需求词最多20条')
            seeds=list(dict.fromkeys(keyword_text(word,'需求词') for word in seeds))
        count=data.get('count')
        if count is not None and (type(count) is not int or count not in (10,20,50,100)):
            raise ValueError('单次推荐数量为10、20、50或100')
        supplied=keyword_candidates(data['keywords']) if 'keywords' in data else None
        selected=keyword_selection(data['selected']) if 'selected' in data else None
        with self.core.store.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            current=self._regional_current(db,user,city,area)
            existing_revision=current.get('revision',0) if current else 0
            if revision!=existing_revision:raise KeywordRevisionConflict('关键词库已更新，请刷新后重试')
            existing=current.get('keywords',[]) if current else []
            merged=list(existing);known={item['keyword'] for item in merged}
            for item in supplied or []:
                if item['keyword'] not in known:merged.append(item);known.add(item['keyword'])
            chosen=selected if selected is not None else current.get('selected',[]) if current else []
            for word in chosen:
                if word not in known:
                    merged.append({'keyword':word,'group':'','recommended':False,'reason':'','source':'manual'})
                    known.add(word)
            if len(merged)>KEYWORD_POOL_LIMIT:raise ValueError('关键词池最多500条')
            now=timestamp()
            row={'id':self._regional_id(user,city,area),'tenant_id':user['tenant_id'],
                 'owner':user['username'],'kind':'regional_state',
                 'request':{'city':city,'area':area,'seeds':seeds if seeds is not None else
                            (current.get('request') or {}).get('seeds',[]) if current else [],
                            'count':count if count is not None else (current.get('request') or {}).get('count',50) if current else 50},
                 'keywords':merged,'selected':chosen,'revision':existing_revision+1,
                 'created_at':current.get('created_at',now) if current else now,'updated_at':now}
            db.execute('INSERT OR REPLACE INTO records VALUES(?,?,?,?)',
                       ('keyword_libraries',row['id'],row['tenant_id'],json.dumps(row,ensure_ascii=False)))
        return {'library':self._regional_view(row)}

    def _regional_view(self,row):
        if row is None:return None
        return {key:row.get(key) for key in ('id','request','keywords','selected','revision','created_at','updated_at')}

    def _append_recommendations(self,user,payload,words):
        city,area=payload['city'],payload['area']
        additions=keyword_candidates(words,'ai')
        with self.core.store.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            current=self._regional_current(db,user,city,area)
            existing=current.get('keywords',[]) if current else []
            merged=list(existing);known={item['keyword'] for item in merged}
            for item in additions:
                if item['keyword'] not in known:merged.append(item);known.add(item['keyword'])
            if len(merged)>KEYWORD_POOL_LIMIT:raise ValueError('关键词池最多500条；请先整理已选词')
            if current and len(merged)==len(existing):return self._regional_view(current)
            now=timestamp()
            row={'id':self._regional_id(user,city,area),'tenant_id':user['tenant_id'],
                 'owner':user['username'],'kind':'regional_state',
                 'request':{key:payload[key] for key in ('city','area','seeds','count')},
                 'keywords':merged,'selected':current.get('selected',[]) if current else [],
                 'revision':(current.get('revision',0) if current else 0)+1,
                 'created_at':current.get('created_at',now) if current else now,'updated_at':now}
            db.execute('INSERT OR REPLACE INTO records VALUES(?,?,?,?)',
                       ('keyword_libraries',row['id'],row['tenant_id'],json.dumps(row,ensure_ascii=False)))
        return self._regional_view(row)

    def keywords(self, user, data):
        city = str(data.get('city', '')).strip()
        if not city or len(city) > 60: raise ValueError('请填写获客城市')
        count = data.get('count', 50)
        if type(count) is not int or count not in (10,20,50,100): raise ValueError('推荐数量为10、20、50或100')
        seeds = data.get('seeds', [])
        if not isinstance(seeds, list) or not seeds or len(seeds) > 20 or any(not isinstance(s, str) or not s.strip() or len(s) > 80 for s in seeds):
            raise ValueError('请填写需求关键词')
        area=data.get('area','')
        if not isinstance(area,str) or len(area.strip())>80:raise ValueError('目标区域格式不正确')
        excludes=data.get('exclude_keywords',[])
        if not isinstance(excludes,list) or len(excludes)>KEYWORD_POOL_LIMIT:raise ValueError('已有关键词最多500条')
        excludes=sorted(set(keyword_text(word,'已有关键词') for word in excludes))
        payload = {'city': city, 'area': area.strip(),
                   'seeds': list(dict.fromkeys(keyword_text(word,'需求词') for word in seeds)), 'count': count,
                   **({'exclude_keywords':excludes} if excludes else {})}
        profile = self.cloud(user, 'ai_profile', {})
        profile = profile.get('config', profile)
        rules_version = expected_rules_version(profile)
        key = self._key(user, 'keywords', payload, profile)
        with self.lock:
            cached = self._cached(user, key)
            if cached:
                library=self._append_recommendations(user,payload,cached['keywords'])
                return {**cached, 'library_id': key, 'library':library,'cache_hit': True, 'source': 'local_cache'}
            with self.core.store.connect() as db:
                current=self._regional_current(db,user,payload['city'],payload['area'])
            if current and len(current.get('keywords') or [])+count>KEYWORD_POOL_LIMIT:
                raise ValueError('关键词池剩余空间不足，请先整理已选词或减少单次推荐数量')
            value, attempt = self.attempts.call(user, 'keyword_suggest', {**payload,
                **({'expected_revision':profile['revision']} if type(profile.get('revision')) is int else {}),
                'expected_rules_version':rules_version}, context={key: profile.get(key) for key in
                    ('revision', 'rules_version', 'provider', 'model', 'reasoning_effort')}, explicit_new=True)
            verify_result_rules_version(value, rules_version)
            words = value.get('keywords')
            if not isinstance(words, list) or len(words) != count or any(not isinstance(w, dict) or not isinstance(w.get('keyword'), str) or not w['keyword'].strip() for w in words):
                raise ValueError('关键词返回格式不正确，请稍后重试')
            # Never persist credentials or raw provider messages, even if a future gateway adds them.
            safe = {'keywords': [{k: w.get(k) for k in ('keyword', 'group', 'recommended', 'reason')} for w in words],
                    **model_metadata(value, profile), 'rules_version': rules_version,
                    'source': 'cloud_ai', 'cache_hit': bool(value.get('cache_hit'))}
            self.attempts.validated(user, attempt)
            library=self._append_recommendations(user,payload,safe['keywords'])
            self._put_cache(user, key, safe)
            self.core.store.put('keyword_libraries', {'id': key, 'tenant_id': user['tenant_id'],
                'owner': user['username'], 'request': payload, 'keywords': safe['keywords'],
                'selected': [], 'created_at': timestamp()})
            return {**safe, 'library_id': key, 'library':library}

    def library(self, user, data):
        rows = [r for r in self.core.store.list('keyword_libraries', user['tenant_id']) if r.get('owner') == user['username']]
        ident = data.get('library_id')
        if ident:
            row = next((r for r in rows if r['id'] == ident), None)
            if not row: raise ValueError('关键词组合不存在')
            if 'selected' in data:
                selected = data['selected']
                # Employee may edit/add keywords; confirmation persists the exact approved search queue.
                selected=keyword_selection(selected)
                row = {**row, 'selected': selected, 'updated_at': timestamp()}
                self.core.store.put('keyword_libraries', row)
            rows = [row]
        return {'items': [{k: r.get(k) for k in ('id', 'request', 'keywords', 'selected', 'created_at', 'updated_at')} for r in sorted(rows, key=lambda r:r.get('updated_at') or r['created_at'], reverse=True)]}

    def analyze(self, user, task, leads, replace_existing=False, expected_profile=None, explicit_retry=False, *, existing_only=False):
        return self._analyze(user, task, leads, replace_existing, expected_profile, explicit_retry, existing_only=existing_only)

    def analyze_archived_source(self, user, binding):
        from .source_intent_analysis import _ArchivedSourceBinding
        if type(binding) is not _ArchivedSourceBinding:
            raise ValueError('来源分析必须使用原服务器捕获')
        binding.check(user)
        return self._analyze(user, None, binding.leads, _source_binding=binding)

    def _analyze(self, user, task, leads, replace_existing=False, expected_profile=None, explicit_retry=False, *, _source_binding=None, existing_only=False):
        """One same-post batch. Caller must enforce lead ownership before entering."""
        if not leads: return {'analyzed': 0}
        if len(leads) > 50: raise ValueError('一次最多分析50条评论')
        if len({lead['id'] for lead in leads}) != len(leads):
            raise ValueError('同批评论标识重复')
        post_ids = {post_identity(l) for l in leads}
        if len(post_ids) != 1: raise ValueError('同批分析必须来自同一帖子')
        task_id, user_id = (task.get('id') if _source_binding is None else None), user.get('id')
        if not user_id or (_source_binding is None and not task_id):
            raise ValueError('AI分析任务或员工已失效')
        task_context = {key: task.get(key) for key in TASK_CONTEXT_FIELDS} if _source_binding is None else {}
        original_leads = {lead['id']: {key: lead.get(key) for key in LEAD_CONTEXT_FIELDS} for lead in leads}
        previous_states = {}
        with self.core.lock:
            if _source_binding is not None:
                current_user = _source_binding.check(user)
                eligible = leads
            else:
                current_user = self.core.store.get('users', user_id)
                current_task = self.core.store.get('tasks', task_id)
                if (not current_user or current_user.get('disabled') or
                        any(current_user.get(key) != user.get(key) for key in
                            ('id', 'tenant_id', 'username', 'role', 'cloud_bound')) or
                        not current_task or any(current_task.get(key) != value for key, value in task_context.items())):
                    raise ValueError('AI分析任务或员工已失效')
                self.core._task_access(current_user, current_task, user['tenant_id'])
                if replace_existing and not self._regrade_collection_idle(task_id):
                    raise AIContextRequired('请先暂停采集并等待当前读取结束，再维护旧意向结果')
                eligible = []
                for original in leads:
                    current = self.core.store.get('leads', original['id'])
                    if (not current or current.get('tenant_id') != user['tenant_id'] or
                            current.get('task_id') != task_id or current.get('manual_intent') or
                            current.get('cloud_owner') not in (None, user['username']) or
                            any(current.get(key) != value for key, value in original_leads[original['id']].items())):
                        continue
                    old_ai = current.get('ai_intent')
                    if replace_existing:
                        if (not isinstance(old_ai, dict) or old_ai != original.get('ai_intent') or
                                not isinstance(current.get('ai_intent_history', []), list)):
                            continue
                        previous_states[original['id']] = deepcopy({key: current.get(key) for key in
                            ('ai_intent', 'analysis_status', 'content_region', 'verification_status')})
                    elif old_ai:
                        continue
                    eligible.append(original)
            from .intent_rule_management import IntentRuleManagement
            from core.service_plans import require_feature
            require_feature(self._current_company(), 'intent_analysis')
            policy_manager = IntentRuleManagement(self.core, user['tenant_id'], user['username'],
                                                  self._current_company())
            policy_snapshot = policy_manager.snapshot(current_user)
        leads = eligible
        if not leads:
            return {'analyzed': 0, 'cache_hits': 0}
        city = task.get('city') if _source_binding is None else _source_binding.city
        if not isinstance(city, str) or not city.strip() or not city.strip().removesuffix('市').strip() or len(city.strip()) > 80:
            raise AIContextRequired('采集任务缺少可核实的目标城市，评论保持待分析')
        if any(not isinstance(lead.get('text'), str) or not lead['text'].strip() or len(lead['text'])>3000 for lead in leads):
            raise AIContextRequired('评论无正文，需核实后才能分析')
        first = next((lead for lead in leads if lead.get('content_title') or lead.get('title')), leads[0])
        title = optional_context_text(first.get('content_title'),500) or optional_context_text(first.get('title'),500)
        post = {'id': post_identity(first),
                'title': title, 'author': optional_context_text(first.get('content_author'),120)}
        if not post['title'].strip():
            raise AIContextRequired('缺少可核实的帖子标题，评论保持待分析')
        context = {'city': city.strip(), 'area': optional_context_text(task.get('area') if _source_binding is None else _source_binding.area,80), 'post': post}
        from core.intent_policy import task_analysis_rules, GUBEI_ANALYSIS_VERSION
        scoped_rules = task_analysis_rules(task) if _source_binding is None else ''
        if scoped_rules:
            # Context participates in the existing cache and attempt fingerprints.
            # Old grades/unknown attempts stay untouched; no automatic regrade.
            context['rules'] = scoped_rules
        profile = self.cloud(user, 'ai_profile', {})
        profile = profile.get('config', profile)
        rules_version = expected_rules_version(profile)
        published = stable_published_policy(profile)
        if published and published['enabled'] is False:
            raise AIProfileChanged('公司意向规则已暂停，请先核对当前版本；未开始新分析')
        policy_expectations = ({'expected_policy_revision': published['policy_revision'],
            'expected_policy_digest': published['policy_digest'],
            'expected_effective_facts_digest': published['effective_facts_digest']} if published else {})
        if replace_existing:
            if expected_profile is not None:
                fields = ('revision', 'rules_version', 'provider', 'model')
                if (not isinstance(expected_profile, dict) or set(expected_profile) != set(fields) or
                        type(expected_profile['revision']) is not int or expected_profile['revision'] < 0 or
                        any(not isinstance(expected_profile[key], str) or not expected_profile[key]
                            for key in fields[1:]) or
                        any(profile.get(key) != expected_profile[key] for key in fields)):
                    raise AIProfileChanged('企业 AI 配置已变化，请刷新后再分析')
            # The cloud profile exposes the effective rules version, including
            # the server contract and administrator policy hash. A row already
            # on that version cannot be charged again through this path.
            leads = [lead for lead in leads if
                     previous_states[lead['id']]['ai_intent'].get('rules_version') != profile.get('rules_version')]
            if not leads:
                return {'analyzed': 0, 'cache_hits': 0}
        resolved, missing, keys = {}, [], {}
        for lead in leads:
            ip_location=optional_context_text(lead.get('ip_location'),80)
            if not ip_location:ip_location=optional_context_text(lead.get('region'),80)
            commenter_id,post_author_id=lead.get('author_id'),lead.get('content_author_id')
            commenter_key=str(commenter_id).strip() if commenter_id is not None else ''
            post_author_key=str(post_author_id).strip() if post_author_id is not None else ''
            is_post_author=bool(commenter_key and commenter_key.casefold() not in ('0','unknown','null','none','-')
                and commenter_key==post_author_key)
            comment = {'id': lead['id'], 'text': lead['text'],
                       'author': optional_context_text(lead.get('author'),120),
                       'is_post_author': is_post_author,
                       'parent_text': optional_context_text(lead.get('parent_text'),3000),
                       'published_at': optional_context_text(lead.get('published_at'),80),
                       'ip_location': ip_location}
            from core.intent_policy import POLICY_VERSION
            key = self._key(user, 'intent', {**context, 'comment': comment,
                'local_policy': {'revision': policy_snapshot['revision'], 'digest': policy_snapshot['digest'],
                                 'validation_version': POLICY_VERSION}}, profile)
            keys[lead['id']] = key
            cached = self._cached(user, key)
            if cached:
                if published:
                    verify_applied_policy({'applied_policy': cached.get('applied_policy'),
                        'policy_revalidation_required': False}, profile,
                        (cached.get('applied_policy') or {}).get('original_request_id'))
                resolved[lead['id']] = cached
            else: missing.append(comment)
        checked = {}; attempt = None
        if missing:
            # Keep persisted lead IDs and local cache keys untouched. Only the
            # provider-facing batch uses short, deterministic aliases; map a
            # complete one-to-one response back before validating or saving.
            alias_by_id = {ident: f'c{index:03d}' for index, ident in
                           enumerate(sorted(comment['id'] for comment in missing), 1)}
            id_by_alias = {alias: ident for ident, alias in alias_by_id.items()}
            aliased_comments = [{**comment, 'id': alias_by_id[comment['id']]}
                                for comment in missing]
            from .ai_attempts import AIRequestReview
            try:
                value, attempt = self.attempts.call(user, 'intent_analyze', {**context, 'comments': aliased_comments,
                    **policy_expectations,
                    **({'expected_revision':profile['revision']} if type(profile.get('revision')) is int else {}),
                    'expected_rules_version':rules_version}, context={
                        'profile': {key: profile.get(key) for key in
                                    ('revision', 'rules_version', 'provider', 'model', 'reasoning_effort')},
                        **({'published_policy': published} if published else {}),
                        'local_policy': {'revision': policy_snapshot['revision'], 'digest': policy_snapshot['digest']}},
                        lead_ids=[comment['id'] for comment in missing], explicit_new=replace_existing or explicit_retry,
                        existing_only=existing_only,
                        **({'source_binding': _source_binding} if _source_binding is not None else {}))
            except AIRequestReview:
                if _source_binding is not None:
                    raise
                current_user = self.core.store.get('users', user_id)
                if (not current_user or current_user.get('disabled') or
                        any(current_user.get(key) != user.get(key) for key in
                            ('id', 'tenant_id', 'username', 'role', 'cloud_bound'))):
                    # Preserve the established zero-write result on revoked
                    # ownership; the original attempt metadata remains unknown.
                    return {'analyzed': 0, 'cache_hits': len(leads) - len(missing)}
                raise
            verify_result_rules_version(value, rules_version)
            applied_policy = verify_applied_policy(value, profile, attempt['request_id'])
            aliased_results = value.get('results')
            if not isinstance(aliased_results, list) or len(aliased_results) != len(missing) or any(
                    not isinstance(row, dict) or not isinstance(row.get('id'), str)
                    for row in aliased_results):
                raise ValueError('AI分析不完整，评论保持待分析')
            returned_aliases = [row['id'] for row in aliased_results]
            if (len(set(returned_aliases)) != len(returned_aliases) or
                    set(returned_aliases) != set(id_by_alias)):
                raise ValueError('AI分析标识无法一一核对，评论保持待分析')
            results = [{**row, 'id': id_by_alias[row['id']]} for row in aliased_results]
            for result in results:
                status, level = result.get('status'), result.get('level')
                if status not in ('graded', 'uncertain', 'unrelated') or (status == 'graded' and level not in LEVELS) or (status != 'graded' and level is not None):
                    raise ValueError('AI意向格式无效，评论保持待分析')
                evidence = result.get('evidence')
                comment = next(c for c in missing if c['id'] == result['id'])
                sources = (comment['text'], comment['parent_text'], post['title'])
                if not isinstance(evidence, list) or (status == 'graded' and not evidence) or any(not isinstance(e, str) or not e.strip() or len(e) > 300 or not any(e in source for source in sources) for e in evidence):
                    raise ValueError('AI依据格式无效')
                facts = result.get('key_info')
                if not isinstance(facts, list) or len(facts) > 8 or (status == 'unrelated' and facts):
                    raise ValueError('AI关键信息格式无效')
                for fact in facts:
                    if not isinstance(fact, dict) or set(fact) != {'type', 'value', 'evidence'} or fact['type'] not in INFO_TYPES or not isinstance(fact['value'], str) or not fact['value'].strip() or len(fact['value']) > 80 or not isinstance(fact['evidence'], str) or not fact['evidence'].strip() or len(fact['evidence']) > 160 or fact['value'] not in fact['evidence'] or fact['evidence'] not in comment['text']:
                        raise ValueError('AI关键信息无法在评论原文核对')
                reason = result.get('reason')
                if not isinstance(reason, str) or not reason.strip() or len(reason) > 500:
                    raise ValueError('AI分析理由无效')
                checked[result['id']] = {**{k: result.get(k) for k in ('status', 'level', 'reason', 'evidence', 'region_status', 'content_region', 'key_info')},
                                         **({'applied_policy': applied_policy} if applied_policy else {}),
                                         **model_metadata(value, profile)}
            resolved.update(checked)
        # Re-read safe cloud metadata outside the local lock after transport;
        # a response matching the starting version alone can already be stale.
        final_profile = self.cloud(user, 'ai_profile', {})
        final_profile = final_profile.get('config', final_profile)
        if (not isinstance(final_profile, dict) or any(final_profile.get(key) != profile.get(key)
                for key in ('revision', 'rules_version', 'provider', 'model', 'reasoning_effort')) or
                stable_published_policy(final_profile) != published):
            raise AIProfileChanged('企业 AI 配置在分析期间已变化，结果未保存，请刷新后核对')
        written = 0
        with self.core.lock:
            current_user = self.core.store.get('users', user_id)
            if (not current_user or current_user.get('disabled') or
                    any(current_user.get(key) != user.get(key) for key in
                        ('id', 'tenant_id', 'username', 'role', 'cloud_bound'))):
                return {'analyzed': 0, 'cache_hits': len(leads) - len(missing)}
            if _source_binding is not None:
                current_user = _source_binding.check(user)
            else:
                current_task = self.core.store.get('tasks', task_id)
                if not current_task or any(current_task.get(key) != value for key, value in task_context.items()):
                    return {'analyzed': 0, 'cache_hits': len(leads) - len(missing)}
                try:
                    self.core._task_access(current_user, current_task, user['tenant_id'])
                except ValueError:
                    return {'analyzed': 0, 'cache_hits': len(leads) - len(missing)}
            require_feature(self._current_company(), 'intent_analysis')
            policy_manager.assert_snapshot(policy_snapshot, current_user)
            from core.intent_policy import apply_intent_policy
            original_by_id = {lead['id']: lead for lead in leads}
            for ident, result in resolved.items():
                source = original_by_id[ident]
                own_comment = {**source, 'id': ident,
                    'is_post_author': bool(source.get('author_id') and source.get('content_author_id')
                                           and source['author_id'] == source['content_author_id'])}
                guard_input = {key: deepcopy(result.get(key)) for key in
                    ('status', 'level', 'reason', 'evidence', 'region_status', 'content_region', 'key_info')}
                resolved[ident] = {**apply_intent_policy(own_comment, guard_input, policy_snapshot['policy'], context),
                    **({'applied_policy': deepcopy(result['applied_policy'])} if result.get('applied_policy') else {}),
                    **model_metadata(result, profile), 'local_policy_revision': policy_snapshot['revision'],
                    'local_policy_digest': policy_snapshot['digest'],
                    'provider_criteria_source': 'trusted_cloud_company_policy',
                    'local_criteria_applied_to_provider': False,
                    **({'scoped_prompt_version': GUBEI_ANALYSIS_VERSION} if scoped_rules else {})}
            if replace_existing:
                if not self._regrade_collection_idle(task_id):
                    return {'analyzed': 0, 'cache_hits': len(leads) - len(missing)}
            if attempt:
                self.attempts.validated(user, attempt)
            if _source_binding is not None:
                written = _source_binding.persist(self, user, resolved, keys, checked, profile, rules_version)
            else:
                for ident in checked:
                    self._put_cache(user, keys[ident], resolved[ident])
                for original in leads:
                    lead = self.core.store.get('leads', original['id'])
                    if not lead or lead.get('tenant_id') != user['tenant_id'] or lead.get('manual_intent'): continue
                    # Recheck the source, task and employee binding after the paid request.
                    if lead.get('task_id') != task_id or any(lead.get(key) != value for key, value in original_leads[original['id']].items()): continue
                    if lead.get('cloud_owner') and lead['cloud_owner'] != user['username']: continue
                    if replace_existing:
                        previous = previous_states[lead['id']]
                        if (not isinstance(lead.get('ai_intent_history', []), list) or
                                any(lead.get(key) != value for key, value in previous.items())):
                            continue
                        lead['ai_intent_history'] = [*lead.get('ai_intent_history', []),
                            {**deepcopy(previous), 'archived_at': timestamp()}]
                    elif lead.get('ai_intent'):
                        continue
                    lead['ai_intent'] = {**resolved[lead['id']], **model_metadata(resolved[lead['id']], profile),
                        'rules_version': rules_version, 'cache_key': keys[lead['id']], 'analyzed_at': timestamp()}
                    lead['analysis_status'] = lead['ai_intent']['status']
                    lead['content_region']=lead['ai_intent'].get('content_region') or ''
                    if lead['ai_intent'].get('region_status')=='unknown':lead['verification_status']='pending'
                    # Metadata uncertainty is separate from a confident rental-intent grade.
                    # AI context inference does not upgrade a missing date or exact-area proof.
                    self.core.store.put('leads', lead)
                    written += 1
        last = next(iter(resolved.values()), {})
        return {'analyzed': written, 'cache_hits': len(leads) - len(missing),
                **model_metadata(last, profile)}

    def correct(self, user, lead, data):
        level = data.get('level')
        status = data.get('status', 'graded')
        if status not in ('graded','uncertain','unrelated') or (status == 'graded' and level not in LEVELS):
            raise ValueError('意向等级无效')
        with self.core.lock:
            current = self.core._get('leads', lead['id'], user['tenant_id'])
            current['manual_intent'] = {'status': status, 'level': level if status == 'graded' else None,
                'reason': str(data.get('reason', '人工调整'))[:300], 'by': user['id'], 'updated_at': timestamp()}
            self.core.store.put('leads', current)
            self.core._audit(user, 'intent_correct', current['id'], user['tenant_id'])
        return current
