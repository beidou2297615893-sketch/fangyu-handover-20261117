"""Explicit employee/store/account live child-window selections, original Store."""
from copy import deepcopy
from .livestream_admission import LivestreamAdmission,LiveError,fail,get,put,digest,stamp,number,ID,REQUEST,binding

SOURCES='livestream_source_selections_v1'
SELECTIONS='livestream_source_selection_requests_v1'
def source_key(user,store,account,room):return digest(['page-live-source-v1',user['tenant_id'],user['id'],store,account,room])
def public(row):
 return {k:deepcopy(row[k]) for k in ('id','version','accountId','accountName','webRid','liveConnId','windowTitle','city','area','confirmedAt') if k in row}|{'accountCheck':'confirmed_at_selection','message':'已明确确认此账号与直播窗口；开始前会再次核对，不会自动选择其他窗口'}
class LivestreamSources:
 def __init__(self,core):self.core,self.store=core,core.store;self.admission=LivestreamAdmission(core)
 def read(self,user,store,account,authority):
  with self.store.connect() as db:
   self.admission._actor(db,user,store,authority,account)
   rows=[]
   for item in db.execute('SELECT body FROM records WHERE entity=? AND tenant_id=?',(SOURCES,user['tenant_id'])):
    import json
    row=json.loads(item['body'])
    if row.get('ownerId')==user['id'] and row.get('owner')==user['username'] and row.get('storeId')==store and row.get('accountId')==account['id']:rows.append(public(row))
   return {'sources':sorted(rows,key=lambda r:(r['webRid'],r['id'])),'maximumConfiguredRooms':10,'tenRoomCapacityVerified':False}
 def resolve(self,user,store,account,data,authority):
  if not isinstance(data.get('sourceId'),str) or not ID.fullmatch(data['sourceId']) or type(data.get('expectedVersion')) is not int:fail('LIVE_SOURCE_REQUIRED','请先明确选择并确认直播窗口',400)
  with self.store.connect() as db:
   self.admission._actor(db,user,store,authority,account);row=get(db,SOURCES,data['sourceId'],user['tenant_id'])
   if (not row or row.get('ownerId')!=user['id'] or row.get('owner')!=user['username'] or row.get('storeId')!=store or row.get('accountId')!=account['id']):fail('LIVE_SOURCE_FORBIDDEN','直播窗口选择不属于当前账号与门店',403)
   if row.get('version')!=data['expectedVersion'] or row.get('parentAccountBinding')!=binding(account):fail('LIVE_SOURCE_CHANGED','直播来源或原账号已变化，请重新核对原窗口选择',409)
   return row
 def select(self,user,store,account,data,authority,guard,transport):
  if (set(data)!={'storeId','accountId','webRid','liveConnId','expectedVersion','requestId','confirmed','city','area','intentPolicySnapshot','localPromptVersion'} or data.get('storeId')!=store or data.get('accountId')!=account['id'] or data.get('confirmed') is not True or not number(data.get('webRid')) or not isinstance(data.get('liveConnId'),str) or not ID.fullmatch(data['liveConnId']) or not isinstance(data.get('requestId'),str) or not REQUEST.fullmatch(data['requestId']) or type(data.get('expectedVersion')) is not int or data['expectedVersion']<0):fail('LIVE_SELECTION_INPUT_INVALID','请确认本人账号、房间和明确选中的直播窗口',400)
  if (not isinstance(data['city'],str) or not data['city'].strip().removesuffix('市').strip() or len(data['city'])>80 or not isinstance(data['area'],str) or len(data['area'])>80 or any(ord(c)<32 for c in data['city']+data['area'])):fail('LIVE_ANALYSIS_CONTEXT_REQUIRED','请明确直播需求判断的目标城市；区域可留空，不会猜测客户所在地',400)
  ident=source_key(user,store,account['id'],data['webRid']);key=digest(['live-select',user['tenant_id'],user['id'],data['requestId']]);signature=digest([data,binding(account)])
  with self.store.connect() as db:
   db.execute('BEGIN IMMEDIATE');self.admission._actor(db,user,store,authority,account);old=get(db,SELECTIONS,key,user['tenant_id'])
   if old:
    if old.get('signature')!=signature:fail('LIVE_SELECTION_REQUEST_CHANGED','原窗口确认编号的内容已变化',409)
    current=get(db,SOURCES,ident,user['tenant_id']);return {'state':old['state'],'requestId':data['requestId'],'source':public(old['source']) if old.get('source') else None,'isCurrent':bool(current and old.get('source',{}).get('version')==current.get('version')),'message':old.get('message','原窗口确认结果待核对；不会自动重试')}
   current=get(db,SOURCES,ident,user['tenant_id'])
   if (current or {}).get('version',0)!=data['expectedVersion']:fail('LIVE_SOURCE_CHANGED','直播来源已在其他窗口修改，请重新读取后确认',409)
   if not current and len(self.read(user,store,account,authority)['sources'])>=10:fail('LIVE_ROOM_CONFIG_LIMIT','最多保存10个直播房间；真实十房容量仍待验证',409)
  guard();owner='live-source:'+key;self.core.acquire_account_mode(account['id'],user['tenant_id'],'collection',owner)
  try:
   guard()
   with self.store.connect() as db:
    db.execute('BEGIN IMMEDIATE');self.admission._actor(db,user,store,authority,account)
    if get(db,SELECTIONS,key,user['tenant_id']):fail('LIVE_SELECTION_IN_PROGRESS','原窗口确认正在处理，请核对原编号',409)
    current=get(db,SOURCES,ident,user['tenant_id'])
    if (current or {}).get('version',0)!=data['expectedVersion']:fail('LIVE_SOURCE_CHANGED','直播来源已变化，请重新读取后确认',409)
    receipt={'id':key,'tenant_id':user['tenant_id'],'ownerId':user['id'],'owner':user['username'],'storeId':store,'requestId':data['requestId'],'signature':signature,'state':'unknown','createdAt':stamp()};put(db,SELECTIONS,receipt)
   value=transport(account,data,guard);guard()
   if (not isinstance(value,dict) or value.get('contract')!='fangyu-live-source-selection-v1' or value.get('state')!='selected' or value.get('parentConnId')!=account['conn_id'] or value.get('connId')!=data['liveConnId'] or value.get('accountUid')!=account['platform_uid'] or value.get('webRid')!=data['webRid'] or not isinstance(value.get('selectionId'),str) or not ID.fullmatch(value['selectionId'])):fail(value.get('code','LIVE_SELECTION_UNCONFIRMED') if isinstance(value,dict) else 'LIVE_SELECTION_UNCONFIRMED',value.get('message','当前账号与直播窗口尚未核对，原确认编号保留') if isinstance(value,dict) else '当前窗口核对回执未知',409)
   with self.store.connect() as db:
    db.execute('BEGIN IMMEDIATE');self.admission._actor(db,user,store,authority,account);current=get(db,SOURCES,ident,user['tenant_id'])
    if (current or {}).get('version',0)!=data['expectedVersion']:fail('LIVE_SOURCE_CHANGED','核对期间直播来源已修改，本次不覆盖',409)
    if current is None:
     import json
     configured=sum(1 for item in db.execute('SELECT body FROM records WHERE entity=? AND tenant_id=?',(SOURCES,user['tenant_id'])) if (lambda r:r.get('ownerId')==user['id'] and r.get('storeId')==store and r.get('accountId')==account['id'])(json.loads(item['body'])))
     if configured>=10:fail('LIVE_ROOM_CONFIG_LIMIT','最多保存10个直播房间；真实十房容量仍待验证',409)
    row={'id':ident,'tenant_id':user['tenant_id'],'ownerId':user['id'],'owner':user['username'],'storeId':store,'accountId':account['id'],'accountName':account.get('platform_nickname') or account.get('name') or '当前抖音账号','webRid':data['webRid'],'liveConnId':data['liveConnId'],'windowTitle':str(value.get('title') or '直播窗口')[:200],'intentPolicySnapshot':deepcopy(data['intentPolicySnapshot']),'localPromptVersion':data['localPromptVersion'],'city':data['city'].strip(),'area':data['area'].strip(),'version':data['expectedVersion']+1,'parentAccountBinding':binding(account),'bridgeSelectionId':value['selectionId'],'confirmedAt':stamp()}
    put(db,SOURCES,row);receipt.update(state='selected',source=deepcopy(row),finishedAt=stamp());put(db,SELECTIONS,receipt)
   return {'state':'selected','source':public(row),'requestId':data['requestId'],'isCurrent':True}
  finally:self.core.release_account_mode(account['id'],user['tenant_id'],owner)
