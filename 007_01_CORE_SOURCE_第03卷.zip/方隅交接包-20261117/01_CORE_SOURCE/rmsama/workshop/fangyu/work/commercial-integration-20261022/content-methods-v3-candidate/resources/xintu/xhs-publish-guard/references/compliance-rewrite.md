# Compliance Rewrite Guide

Use during writing and final review. Default rule: convert unsupported objective claims into bounded personal experience.

## High-risk patterns

| Risk | Example | Safer rewrite |
|---|---|---|
| Absolute efficacy | `最好用的工具` | `我自己用得最顺手的` |
| Guarantee | `保证涨粉` | `我这次改了标题后点击率高了一些` |
| Universal | `所有人都该装` | `如果你也用 Cursor，可能值得试` |
| Medical/financial certainty | `治愈`, `稳赚` | remove or reframe as non-advice experience |
| Hype without proof | `天花板`, `封神`, `闭眼入` | replace with concrete outcome or delete |
| Off-platform bait | `扣1`, `私信领取` | replace with in-platform discussion prompt |

## Format-specific checks

### Carousel

- Fold line must deliver within 3 visible lines.
- Lists/tutorials must actually contain the steps promised.
- `[此处需你补真实细节]` must remain until user supplies evidence.

### Video

- Caption must not duplicate the spoken script.
- On-screen text in the shot table must stay ≤ 12 Chinese chars per line.
- Do not claim demo results that the video does not show.

## Blocker vs fix

- **Blocker**: misleading promise, unsupported claim, rights-sensitive copy, cover/content mismatch.
- **Must fix**: weak hook, unclear audience, missing proof, AI-voice patterns from `../../references/ai-voice-guardrails.md`.
- **Improve**: tag density, repetition, CTA softness.

Run `../scripts/check_copy.py` for deterministic phrase flags; treat hits as review prompts, not legal conclusions.
