"""Portable business core; no web framework, paid service or implicit external write."""
import csv
import hashlib
import hmac
import io
import json
import secrets
import sqlite3
import threading
import time
import re
import shutil
import os
import stat
from contextlib import closing, nullcontext
from datetime import datetime
from pathlib import Path
from uuid import uuid4
from .store import Store
from .contact_journal import ContactJournal, contact_event
from .reply_trial import ReplyTrial
from .adapters import Adapters, AdapterBusy, AdapterAuthRequired, AdapterSafetyRequired, PageUnavailable, account_execution_lock, xhs_image_url
from .page_errors import CoreError, PageOperationFailure, PAGE_ERROR_MESSAGES
from .backups import BackupManager
from .selection import normalize_task_rules, classify_intent, identity_decision
from .pipeline import collect_batch
from . import collection_inbox
from .platform_failure import AdapterPlatformFailure,validated as validated_platform_failure
from .continuous import ContinuousCollector, normalize_continuous_task, filter_comment
from .review_queue import ReviewedReplyQueues, require_reply_permission, snapshot as reply_snapshot
from .account_safety import summarize_activity, account_review_view
from .zhihu import answer_url
from .wechat_channels import video_reference
from .entitlements import normalize_policy,require_platform,check_account_limit,capability_summary,EntitlementError
from .platform_capabilities import platform_runtime_unavailable_reason
from .publication import normalize_draft,resolve_image_paths,build_xhs_args,parse_xhs_receipt,unknown_outcome,recover_publication,build_zhihu_answer_args,zhihu_answer_html

def evaluate_xhs_identity(account, result, accounts):
    """Pure XHS status/identity decision shared by account_check and candidate login.

    ``result`` is the unwrapped CLI status data. ``accounts`` contains only the
    tenant's account records. No store, network, or task status is changed here.
    """
    authenticated = result.get('authenticated') is True
    profile = result.get('user') if isinstance(result.get('user'), dict) else {}
    nickname = str(profile.get('nickname') or profile.get('nick_name') or '').strip()
    incomplete = profile.get('guest') is True or not nickname or nickname == 'Unknown'
    uid = str(profile.get('id') or profile.get('user_id') or profile.get('red_id') or '').strip()
    if authenticated and (incomplete or not uid or account.get('platform_uid') and account['platform_uid'] != uid):
        mismatch = bool(not incomplete and uid and account.get('platform_uid'))
        return {'status': 'identity_mismatch' if mismatch else 'identity_unverified',
                'authenticated': authenticated and not incomplete, 'verified': False,
                'uid': '', 'nickname': '', 'avatar': '', 'duplicate_ids': (),
                'message': '扫码账号与原账号不一致，已暂停任务；请用原账号重新扫码或新建账号记录' if mismatch
                else '小红书返回访客资料或缺少可核对的身份信息，已暂停任务；请检查手机验证并重新登录'}
    duplicates = tuple(item['id'] for item in accounts
                       if item['id'] != account['id'] and item.get('platform') == 'xiaohongshu'
                       and item.get('platform_uid') == uid) if authenticated else ()
    if duplicates:
        return {'status': 'duplicate_identity', 'authenticated': authenticated,
                'verified': False, 'uid': '', 'nickname': '', 'avatar': '',
                'duplicate_ids': duplicates,
                'message': '同一小红书账号已用于另一条本机记录；相关任务均已暂停，请管理员清理重复记录后重新核对'}
    return {'status': 'ready' if authenticated else 'login_required',
            'authenticated': authenticated, 'verified': authenticated,
            'uid': uid if authenticated else '', 'nickname': nickname,
            'avatar': xhs_image_url(profile.get('avatar') or profile.get('image') or profile.get('avatar_url')) if authenticated else '',
            'duplicate_ids': (),
            'message': '账号联网验证通过' if authenticated else '请先登录'}

_APARTMENT_DEFAULT_MEDIUM=('价格','租金','地址','地铁','房型','还在吗','还有么','多少钱','问价','几楼')
def _default_price_inquiry(text,word):
    inquiry=(re.search(r'(?:请问|想问|问一下|想了解|咨询).{0,12}'+re.escape(word),text)
             or re.search(re.escape(word)+r'(?:是|大概)?(?:多少|[?？])',text))
    if not inquiry:return False
    complaint=re.search(r'太贵|这么贵|那么贵|贵了|涨价|涨了|离谱|不值|坑人|为什么.{0,8}贵|怎么.{0,5}贵',text)
    current_request=re.search(r'想租|要租|求租|准备租|打算租|看房|想看房',text)
    return not complaint or bool(current_request)

def now(): return datetime.now().isoformat(timespec='seconds')
_SOURCE_PROGRESS_FIELDS=('content_title','note_url','content_author','content_author_avatar_url',
                         'content_cover_url','content_published_at')
_DISCOVERY_PROGRESS_FIELDS=('author','author_avatar_url',*_SOURCE_PROGRESS_FIELDS)
def _display_summary(row,fields):
    result={}
    for field in fields:
        value=row.get(field)
        if not isinstance(value,str):continue
        if field.endswith('avatar_url') or field=='content_cover_url':value=xhs_image_url(value)
        elif field=='note_url':
            if len(value)>2048 or not re.fullmatch(r'https://(?:[A-Za-z0-9-]+\.)?xiaohongshu\.com/(?:explore|search_result)/[A-Za-z0-9]+(?:\?[^\s]*)?',value):value=''
        else:value=value[:300]
        result[field]=value
    return result
def password_hash(password,salt=None):
    salt=salt or secrets.token_hex(16)
    return salt+':'+hashlib.pbkdf2_hmac('sha256',password.encode(),salt.encode(),310000).hex()
def check_password(password,stored):
    return hmac.compare_digest(password_hash(password,stored.split(':')[0]),stored)

class Core:
    ENTITIES={'tenants','users','accounts','tasks','leads','templates','assets','replies','audit','reply_queues','publications'}
    def __init__(self,data_dir,resources_dir=None,*,defer_startup_recovery=False):
        if type(defer_startup_recovery) is not bool:raise ValueError("启动恢复模式无效")
        self.startup_recovery_deferred=defer_startup_recovery
        self.store=Store(data_dir)
        self.contact_journal=ContactJournal(self.store)
        self.reply_trial=ReplyTrial(self.store)
        self.resources_dir=Path(resources_dir) if resources_dir else None
        self.adapters=Adapters(self.resources_dir/'adapters' if self.resources_dir else None,self.store.directory/'adapters')
        self.adapters.platform_guard=self._platform_execution_guard
        self.remote_safety_hold=False
        # Volatile lease refreshed only by the selected device's authenticated QA heartbeat.
        self.qa_continuous_device_id=''
        self.qa_continuous_until_monotonic=0.0
        self.qa_continuous_max_batches=2
        # Volatile employee read lease; never persisted in the customer config.
        self.employee_release_device_id=''
        self.employee_release_until_monotonic=0.0
        self.lock=threading.RLock()
        # Set by the host from its local deployment config, never tenant/API input.
        self.deployment_config={}
        self.running=set()
        self.sequences={}
        # Runtime evidence only; never store account details or synthetic percentages.
        self._progress_lock=threading.Lock()
        self._task_progress={}
        if not defer_startup_recovery:
            for item in self.store.list('publications'):
                if item.get('status')=='sending':self.store.put('publications',recover_publication(item))
            # A crash during an external write must never turn into an automatic retry.
            for reply in self.store.list('replies'):
                if reply.get('status')=='sending':
                    reply.update(status='unknown',last_error='程序在发送时退出，请人工核实')
                    lead=self.store.get('leads',reply.get('lead_id'))
                    account=self.store.get('accounts',reply.get('account_id')) if reply.get('account_id') else None
                    if lead and lead.get('tenant_id')==reply.get('tenant_id'):
                        self._contact_record('unknown',{'username':'system'},reply['tenant_id'],lead,reply,account,[('replies',reply)])
                    else:self.store.put('replies',reply)
            # If a platform call finished but its terminal journal write failed,
            # the durable reply state repairs that missing outcome on next startup.
            for tenant,owner,start in self.contact_journal.unfinished_attempts():
                reply=self.store.get('replies',start['reply']['id'])
                if not reply or reply.get('tenant_id')!=tenant:continue
                kind={'sent':'sent','unknown':'unknown','approved':'failed'}.get(reply.get('status'))
                if not kind:continue
                sender=start['sender']
                event=contact_event(kind,start['lead'],start['reply'],
                                    {'id':sender['account_id'],'nickname':sender['nickname']})
                self.contact_journal.append(event,tenant,owner)
            for queue in self.store.list('reply_queues'):
                if queue.get('status')=='running': queue.update(status='interrupted',message='程序退出，队列未自动恢复'); self.store.put('reply_queues',queue)
            for task in self.store.list('tasks'):
                if task.get('sequence_status')=='running': task.update(sequence_status='interrupted',sequence_message='程序退出，连续采集未自动恢复'); self.store.put('tasks',task)
        self.continuous=ContinuousCollector(self,defer_startup_recovery=defer_startup_recovery)
        self.reviewed_reply_queues=ReviewedReplyQueues(self,defer_startup_recovery=defer_startup_recovery)

    def start_continuous_scheduler(self):
        self.continuous.start_scheduler()

    def close_continuous_scheduler(self,wait=False):
        self.continuous.close(wait=wait)
        self.reviewed_reply_queues.close()

    def account_mode_status(self,account_id,tenant):
        self._get('accounts',account_id,tenant)
        return self.continuous.leases.get(account_id,tenant) or {'mode':'idle','status':'idle'}

    def acquire_account_mode(self,account_id,tenant,mode,owner):
        self._get('accounts',account_id,tenant)
        try:return self.continuous.leases.acquire(account_id,tenant,mode,owner)
        except ValueError as exc:raise CoreError(str(exc)) from exc

    def release_account_mode(self,account_id,tenant,owner):
        return self.continuous.leases.release(account_id,tenant,owner)

    def stop_owned_reply_queues(self,tenant,username,reason='设备连接中断，后续回复已停止'):
        return self.reviewed_reply_queues.stop_owned(tenant,username,reason)

    def _public_reply_guard(self,platform,trial_context=None):
        self._platform_execution_guard(platform)
        runtime=self.deployment_config.get('runtime') or {}
        if platform=='xiaohongshu' and isinstance(runtime,dict) and runtime.get('portable_employee_release') is True:
            raise CoreError('员工试用版公开发送尚未开放；已审核内容保持原状态')
        if (platform=='xiaohongshu' and runtime.get('platform_qa_device_id') and trial_context
                and self.deployment_config.get('id')=='fangyu-apartment-client'):
            user,reply,snapshot,proof=trial_context
            if self.reply_trial.allows(runtime['platform_qa_device_id'],user,reply,snapshot,proof):return
        if runtime.get('platform_qa_device_id'):
            raise CoreError('内部只读验收不允许公开发送；已审核内容保持原状态')
        if (runtime.get('public_send_hold') is True or runtime.get('public_reply_hold') is True
                or runtime.get('public_replies')=='hold'):
            raise CoreError('公开回复当前暂停；已审核内容保持原状态')

    def _qa_continuous_allowed(self):
        runtime=self.deployment_config.get('runtime') or {}
        if isinstance(runtime,dict) and runtime.get('portable_employee_release') is True:
            return self._employee_release_allowed()
        device=runtime.get('platform_qa_device_id') if isinstance(runtime,dict) else ''
        if not device:return True
        return (not self.remote_safety_hold and self.qa_continuous_device_id==device
                and time.monotonic()<self.qa_continuous_until_monotonic)
    def _qa_continuous_batch_limit(self):
        # A static deployment setting alone never removes the QA batch limit.
        return 0 if self._qa_continuous_allowed() and type(self.qa_continuous_max_batches) is int and self.qa_continuous_max_batches==0 else 2
    def _employee_release_allowed(self):
        runtime=self.deployment_config.get('runtime') or {}
        return (self.deployment_config.get('id')=='fangyu-apartment-client'
                and self.deployment_config.get('releaseVersion')=='1.1.8-pilot.1'
                and isinstance(runtime,dict) and runtime.get('portable_employee_release') is True
                and runtime.get('xiaohongshu_automation')=='hold'
                and runtime.get('release_approved') is False
                and not self.remote_safety_hold and bool(self.employee_release_device_id)
                and time.monotonic()<self.employee_release_until_monotonic)
    def _set_task_progress(self,ident,stage,state='running',**counts):
        tick=time.monotonic()
        with self._progress_lock:
            previous=self._task_progress.get(ident,{})
            fresh=not previous or (state=='running' and previous.get('state')!='running')
            value={} if fresh else dict(previous)
            if fresh:value.update(run_id=uuid4().hex,started_at=now(),started_at_epoch=time.time(),
                                  _started=tick,read=0,imported=0)
            value.update(stage=stage,state=state,updated_at=now(),
                         revision=1 if fresh else previous['revision']+1)
            value.update({key:int(number) for key,number in counts.items()
                          if key in ('read','imported','batch_read','discovered_notes','browsed_notes') and type(number) is int and number>=0})
            for key,fields in (('current_source',_SOURCE_PROGRESS_FIELDS),('latest_discovery',_DISCOVERY_PROGRESS_FIELDS)):
                if isinstance(counts.get(key),dict):value[key]=_display_summary(counts[key],fields)
            if state!='running':value['_finished']=tick
            if state=='failed':value['error_code']='collection_failed'
            self._task_progress[ident]=value

    def task_progress(self,ident):
        with self._progress_lock:
            value=dict(self._task_progress.get(ident,{}))
        if not value:return None
        value['elapsed_seconds']=round(max(0,value.get('_finished',time.monotonic())-value['_started']),1)
        return {key:item for key,item in value.items() if not key.startswith('_')}

    def _record(self,data,tenant):
        return {**data,'id':data.get('id') or uuid4().hex,'tenant_id':tenant,'created_at':data.get('created_at') or now(),'updated_at':now()}
    def _public(self,record): return {k:v for k,v in record.items() if k!='password_hash'}
    def _policy(self):
        try:return normalize_policy(self.deployment_config,[x['id'] for x in self.adapters.manifests()])
        except EntitlementError as exc:raise CoreError(str(exc)) from exc
    def require_platform(self,platform):
        try:return require_platform(self._policy(),platform)
        except EntitlementError as exc:raise CoreError(str(exc)) from exc
    def _platform_execution_guard(self,platform):
        unavailable=platform_runtime_unavailable_reason(platform)
        if unavailable:raise CoreError(unavailable)
        runtime=self.deployment_config.get('runtime') or {}
        if (platform=='xiaohongshu' and self.remote_safety_hold):
            raise CoreError('企业云端未确认平台操作可用；本机已暂停小红书登录、采集与发送')
        if (platform=='xiaohongshu'
                and self.deployment_config.get('id')=='fangyu-apartment-client'
                and isinstance(runtime,dict)
                and runtime.get('xiaohongshu_automation')=='hold'
                and not self._employee_release_allowed()
                and not self._page_read_allowed()):
            raise CoreError('方隅小红书自动登录、采集与发送已暂停；第三方 CLI 保护与真实流程尚未验收')
    def _page_read_allowed(self,action=None):
        from assistant.xhs_page_read_policy import current_read_decision
        return current_read_decision(self,action) is not None
    def _require_customer_xhs_identity(self,account,tenant):
        if self.deployment_config.get('id')!='fangyu-apartment-client' or account.get('platform')!='xiaohongshu':return
        if account.get('status')=='session_recovery_required':
            raise CoreError('小红书会话恢复待管理员检查，已停止平台操作')
        uid=str(account.get('platform_uid') or '').strip()
        if not uid:
            account['status']='identity_unverified';self.store.put('accounts',account)
            raise CoreError('小红书账号缺少可核对的身份标识，已暂停平台操作；请在本地助手检查登录身份')
        duplicates=[item for item in self.store.list('accounts',tenant)
                    if item['id']!=account['id'] and item.get('platform')=='xiaohongshu'
                    and item.get('platform_uid')==uid]
        if duplicates:
            ids={account['id'],*(item['id'] for item in duplicates)}
            for item in (account,*duplicates):
                item['status']='duplicate_identity';self.store.put('accounts',item)
            for task in self.store.list('tasks',tenant):
                if task.get('account_id') in ids:
                    task.update(status='paused',last_message='同一小红书身份存在多个账号记录')
                    self.store.put('tasks',task)
            raise CoreError('同一小红书身份存在多个本机账号记录，已暂停平台操作；请管理员清理重复记录')
    def _platforms(self):
        allowed=self._policy()['platforms']
        return [x for x in self.adapters.manifests() if x['id'] in allowed]
    def _company(self,tenant):
        business=self.store.get('tenants',tenant) or {}
        if isinstance(business.get('business_rules'),dict): return business['business_rules']
        if self.resources_dir:
            configs=[]
            for path in sorted((self.resources_dir/'companies').glob('*.json')):
                try: config=json.loads(path.read_text(encoding='utf-8-sig'))
                except (ValueError,OSError): continue
                configs.append(config)
            exact=next((config for config in configs if config.get('id')==business.get('company_id')),None)
            if exact is not None:return exact
            return next((config for config in configs if config.get('industry')==business.get('industry')), {})
        return {}
    def _classify(self,row,tenant,company=None):
        self._classify_rule(row,tenant,company)
        row.update(system_grade=row['grade'],system_grade_reason=row.get('grade_reason',''),manual_grade='')
    def _classify_rule(self,row,tenant,company=None):
        if row.get('source_type')=='note':
            row.update(grade='C',grade_reason='搜索笔记仅为候选内容，不能确认作者有客户意向'); return
        task=self.store.get('tasks',row.get('task_id','')) if row.get('task_id') else None
        custom=classify_intent(row,task) if task and task.get('tenant_id')==tenant else None
        if custom:
            row.update(custom); return
        # A commenter's intent is expressed in the comment, not the source post title.
        text=str(row.get('text',''))
        config=self._company(tenant) if company is None else company
        for rule in config.get('intentRules',[]):
            default_medium=(rule.get('level')=='medium' and rule.get('reason')=='咨询房源条件，待确认时间与预算'
                            and tuple(rule.get('keywords',()))==_APARTMENT_DEFAULT_MEDIUM)
            matched=[word for word in rule.get('keywords',[]) if word and word in text
                     and (not default_medium or word not in ('价格','租金') or _default_price_inquiry(text,word))]
            if matched:
                row.update(grade={'high':'A','medium':'B','low':'C'}.get(rule.get('level'),'C'),grade_reason='规则判断（待人工核实）：'+rule.get('reason','')+'；命中：'+'、'.join(matched)); return
        row.update(grade='C',grade_reason='规则未命中明确需求，待人工核实')
    def _validate_reply_text(self,text):
        if not text.strip(): raise CoreError('回复内容不能为空')
        if re.search(r'\{[^{}]+\}|\{\{.*?\}\}|【(?:待填|填写|替换)[^】]*】',text): raise CoreError('回复仍含未填写的模板变量，请补齐后再审核或发送')
    def _render_template(self,template,tenant):
        business=self.store.get('tenants',tenant)
        body=str(template.get('text') or template.get('content') or '')
        for label in ('公司名称','企业名称'):
            body=body.replace('{'+label+'}',business.get('name',''))
        for field in self._company(tenant).get('profileSchema',[]):
            if not isinstance(field,dict) or not field.get('label') or not field.get('key'): continue
            value=business.get(field['key'])
            if value is not None and str(value).strip():body=body.replace('{'+str(field['label'])+'}',str(value))
        return body
    def _template_matches(self,template,text,grade):
        return (not template.get('grade') or template['grade']==grade) and any(word and word.casefold() in text.casefold() for word in template.get('keywords',[]))
    def _employee_quota(self,user,tenant):
        config=self._company(tenant).get('defaultRules',{})
        limit=int(user.get('daily_send_limit') or config.get('employeeDailyReplyLimit') or 10)
        today=datetime.now().date().isoformat()
        used=sum(1 for r in self.store.list('replies',tenant) if r.get('sent_by',r.get('attempted_by'))==user['id'] and r.get('status') in ('sending','sent','unknown') and (r.get('attempted_at') or r.get('sent_at','')).startswith(today))
        used+=sum(1 for r in self.store.list('ui_dm_drafts_v1',tenant) if r.get('attempted_by')==user['id'] and r.get('state') in ('sending','sent','unknown') and r.get('attempted_at','').startswith(today))
        if used>=limit: raise CoreError('当前员工今日回复限额已用完（%s 条）'%limit)
    def _audit(self,user,action,detail,tenant=None):
        self.store.put('audit',self._record({'actor':user.get('username','system'),'action':action,'detail':detail},tenant or user.get('tenant_id','system')))
    def _admin(self,user):
        if user.get('role')!='admin': raise CoreError('此操作需要管理员权限')
    def livestream_admission(self):
        from .livestream_admission import LivestreamAdmission
        return LivestreamAdmission(self)

    def interaction_inbox(self,user,store_id,action,data,*,authority_check):
        """Local event views/dispositions, through the original Store and scope."""
        from .interaction_inbox import InteractionInbox
        return InteractionInbox(self).execute(action,user,store_id,data,authority_check=authority_check)

    def _account_access(self,user,account):
        if user.get('cloud_bound'):
            if account.get('cloud_owner')==user.get('username'):return
            raise CoreError('只能连接自己的平台账号')
        if user.get('role')=='admin':return
        raise CoreError('只能连接自己的平台账号')
    def _task_access(self,user,task,tenant,*,db=None):
        if not user.get('cloud_bound'):return
        owner=task.get('cloud_owner')
        if owner and owner!=user.get('username'):raise CoreError('只能操作自己的采集任务')
        account_id=task.get('account_id')
        if account_id:
            self._account_access(user,self._get('accounts',account_id,tenant,db=db))
        elif not owner:
            raise CoreError('此任务没有可核实的员工归属，请管理员重新分配')
    def _scope(self,user,data):
        tenant=data.get('tenant_id') or user['tenant_id']
        if tenant!=user['tenant_id']: self._admin(user)
        if not self.store.get('tenants',tenant): raise CoreError('企业不存在')
        return tenant
    def _get(self,entity,id,tenant,*,db=None):
        if db is None:record=self.store.get(entity,id)
        else:
            # Authorization during an existing write transaction must read
            # that same snapshot, including its uncommitted account changes.
            row=db.execute('SELECT body FROM records WHERE entity=? AND id=?',(entity,id)).fetchone()
            record=json.loads(row['body']) if row else None
        if not record or record['tenant_id']!=tenant: raise CoreError('记录不存在或无权访问')
        return record
    def session(self,token):
        if not token: return None
        with self.store.connect() as db:
            row=db.execute('SELECT user_id FROM sessions WHERE token=? AND expires>?',(hashlib.sha256(token.encode()).hexdigest(),time.time())).fetchone()
        user=self.store.get('users',row['user_id']) if row else None
        return self._public(user) if user and not user.get('disabled') else None
    def _login(self,data):
        user=next((u for u in self.store.list('users') if u['username']==data.get('username')),None)
        if not user or user.get('disabled') or not check_password(data.get('password',''),user['password_hash']): raise CoreError('账号或密码错误')
        token=secrets.token_urlsafe(32)
        with self.store.connect() as db:
            db.execute('DELETE FROM sessions WHERE expires<?',(time.time(),))
            db.execute('INSERT INTO sessions VALUES(?,?,?)',(hashlib.sha256(token.encode()).hexdigest(),user['id'],time.time()+43200))
        self._audit(user,'login','本地登录')
        return {'token':token,'user':self._public(user)}
    def handle(self,action,data=None,user=None,*,execution_guard=None):
        data=data or {}
        if action in ('run_task','run_task_sequence','cancel_task','account_check','verify_adapter','send_reply','run_reply_queue','cancel_reply_queue','publish_content'):
            # Long read-only CLI calls run outside the global mutation lock.
            return self._handle(action,data,user,execution_guard=execution_guard)
        with self.lock: return self._handle(action,data,user,execution_guard=execution_guard)
    def _handle(self,action,data,user,*,execution_guard=None):
        runtime=self.deployment_config.get('runtime') or {}
        customer_douyin_task=False
        if action in ('run_task','run_task_sequence','resume_task'):
            from .douyin_customer_tasks import core_action_allowed
            customer_douyin_task=core_action_allowed(self,action,data,user)
        if action in ('continuous_start','continuous_resume') and not self._qa_continuous_allowed():
            raise CoreError('员工持续采集许可待云端确认或已过期' if isinstance(runtime,dict)
                            and runtime.get('portable_employee_release') is True
                            else '指定设备持续只读验收未获云端短期确认')
        if (self.deployment_config.get('id')=='fangyu-apartment-client'
                and isinstance(runtime,dict)
                and runtime.get('xiaohongshu_automation')=='hold'
                and not (self._employee_release_allowed() and action in (
                    'account_login_spec','account_check','verify_adapter','run_task',
                    'run_task_sequence','resume_task','continuous_start','continuous_resume'))
                and not self._page_read_allowed(action)
                and not customer_douyin_task
                and action in ('account_login_spec','account_check','verify_adapter',
                               'run_task','run_task_sequence','resume_task','continuous_start','continuous_resume',
                               'send_reply','run_reply_queue','run_reviewed_reply_queue','publish_content','confirm_publication')):
            raise CoreError('方隅小红书自动登录、采集与发送已暂停；第三方 CLI 保护与真实流程尚未验收')
        if action=='personal_enter':
            if self.deployment_config.get('edition')!='owner' or self.deployment_config.get('personalMode') is not True:
                raise CoreError('客户版本需要登录')
            users=self.store.list('users')
            owners=[u for u in users if u.get('personal_owner') and not u.get('disabled')]
            if not owners:
                admins=[u for u in users if u.get('role')=='admin' and not u.get('disabled')]
                if len({u['tenant_id'] for u in users})>1:raise CoreError('旧数据包含多个工作区，请先明确迁移目标')
                if admins: owner=admins[0]
                elif users:raise CoreError('旧数据没有可用的本机所有者')
                else:
                    tenant=self._record({'name':'我的工作台','industry':'general'},'')
                    tenant['tenant_id']=tenant['id'];self.store.put('tenants',tenant)
                    owner=self._record({'username':'本机自用','role':'admin','password_hash':password_hash(secrets.token_urlsafe(48))},tenant['id'])
                owner['personal_owner']=True;self.store.put('users',owner)
            else:owner=owners[0]
            token=secrets.token_urlsafe(32)
            with self.store.connect() as db:
                db.execute('DELETE FROM sessions WHERE expires<?',(time.time(),))
                db.execute('INSERT INTO sessions VALUES(?,?,?)',(hashlib.sha256(token.encode()).hexdigest(),owner['id'],time.time()+43200))
            return {'user':self._public(owner),'token':token}
        if action=='status': return {'initialized':bool(self.store.list('users')),'platforms':self._platforms()}
        if action=='bootstrap':
            if self.store.list('users'): raise CoreError('已完成初始化')
            if len(data.get('password',''))<10: raise CoreError('密码至少 10 位')
            username=data.get('username','').strip()
            if not username: raise CoreError('请输入管理员账号')
            tenant=self._record({'name':data.get('company_name') or self.deployment_config.get('name') or '本地运营工作台','industry':self.deployment_config.get('industry') or 'general'},'')
            tenant['tenant_id']=tenant['id']; self.store.put('tenants',tenant)
            admin=self._record({'username':username,'role':'admin','password_hash':password_hash(data['password'])},tenant['id']); self.store.put('users',admin)
            return self._login(data)
        if action=='login': return self._login(data)
        if action=='logout':
            with self.store.connect() as db: db.execute('DELETE FROM sessions WHERE token=?',(hashlib.sha256(data.get('token','').encode()).hexdigest(),))
            return {'ok':True}
        if not user: raise CoreError('请先登录')
        # Refresh permissions: callers cannot keep stale privileges after an account change.
        current=self.store.get('users',user.get('id'))
        if not current or current.get('disabled'): raise CoreError('账号已停用')
        user=self._public(current)
        tenant=self._scope(user,data)
        if action in ('select_account','account_browser_context','account_login_spec','account_check'):
            account=self._get('accounts',data.get('id'),tenant)
            self.require_platform(account['platform'])
            if user.get('cloud_bound'):self._account_access(user,account)
        if action=='verify_adapter':self.require_platform(data.get('platform'))
        if action=='exclude_lead_identity':
            self._admin(user)
            with self.lock:
                lead=self._get('leads',data.get('id'),tenant)
                if not lead.get('task_id'):raise CoreError('此线索没有关联采集任务，请在任务设置里填写排除规则')
                task=self._get('tasks',lead['task_id'],tenant)
                kind=data.get('kind')
                if kind=='author':
                    value=lead.get('author_id') or lead.get('author');field='excluded_authors'
                elif kind=='blogger':
                    value=(lead.get('author_id') or lead.get('author')) if lead.get('source_type')=='note' else (lead.get('content_author_id') or lead.get('content_author'))
                    field='excluded_bloggers'
                else:raise CoreError('排除类型无效')
                value=str(value or '').strip()
                if not value:raise CoreError('平台未提供该身份，不能猜测排除对象')
                values=list(task.get(field) or [])
                if value.casefold() not in {str(x).casefold() for x in values}:values.append(value)
                result=self._save({'entity':'tasks','record':{'id':task['id'],field:values}},user,tenant)
                self._audit(user,action,task['id']+':'+kind,tenant)
                return {'task_id':result['id'],'message':'已加入本任务排除规则；后续采集生效，已有线索保留。'}
        if action in ('save_publication','approve_publication','publish_content','confirm_publication'):
            return self._publication(action,data,user,tenant)
        if action=='select_account':
            account=self._get('accounts',data.get('id'),user['tenant_id'])
            active=dict(current.get('active_accounts') or {})
            active[account['platform']]=account['id']
            current['active_accounts']=active
            self.store.put('users',current)
            return {'account':account,'user':self._public(current)}
        if action in ('account_browser_context','account_delete_context'):
            account=self._get('accounts',data.get('id'),user['tenant_id'])
            if action=='account_delete_context':self._admin(user)
            if action!='account_delete_context' or user.get('cloud_bound'):
                self._account_access(user,account)
            return {'tenant':user['tenant_id'],'account':account}
        if action in ('account_login_spec','account_check'):
            account=self._get('accounts',data.get('id'),tenant)
            if account.get('platform')=='xiaohongshu' and account.get('status')=='session_recovery_required':
                raise CoreError('小红书会话恢复待管理员检查，已停止平台操作')
            directory=self.store.directory/'accounts'/tenant/account['id']
            if action=='account_login_spec':
                self._account_access(user,account)
                if account['platform'] in ('douyin','kuaishou','zhihu','wechat_channels'): raise CoreError('该平台请使用连接账号向导并绑定明确浏览器窗口')
                args=self.adapters.manifest(account['platform']).get('auth_args',['login','--qrcode'])
                spec=self.adapters.account_spec(account['platform'],directory,args)
                # The bundled QR CLI waits up to four minutes for phone approval.
                # Allow its own timeout and a short account-check margin.
                spec['timeout']=255
                account['status']='logging_in'; self.store.put('accounts',account)
                self._audit(user,action,account['id'],tenant)
                return spec
            unavailable=platform_runtime_unavailable_reason(account.get('platform'))
            if unavailable:raise CoreError(unavailable)
            try:
                if account['platform']=='wechat_channels':
                    result=self.adapters._wechat_read('check',{'_account_dir':str(directory)})
                    account.update(status='connected_unverified',checked_at=now()); self.store.put('accounts',account)
                    return {**result,'account':account}
                if account['platform']=='zhihu':
                    if not callable(self.adapters.profile_checker):raise CoreError('知乎连接管理器未就绪')
                    self.adapters.profile_checker(account.get('conn_id'))
                    account.update(status='ready',checked_at=now());self.store.put('accounts',account)
                    return {'authenticated':False,'verified':False,'connected':True,'account':account,'message':'指定知乎窗口已连接；请核对登录身份后验证搜索'}
                manifest=self.adapters.manifest(account['platform'])
                args=manifest.get('status_args',['status','--json'])
                payload=self.adapters.execute(account['platform'],args,directory)
                if account['platform'] in ('douyin','kuaishou'):
                    if not account.get('conn_id'): raise CoreError('请从连接列表明确绑定浏览器连接')
                    connections=payload.get('data',{}).get('connections',[]) if account['platform']=='kuaishou' and isinstance(payload,dict) and payload.get('ok') is True else payload
                    connected=next((x for x in connections if str(x.get('id'))==str(account['conn_id']) and (account['platform']=='kuaishou' or x.get('alive') is True)),None) if isinstance(connections,list) else None
                    account.update(status='unverified' if connected else 'login_required',checked_at=now()); self.store.put('accounts',account)
                    return {'authenticated':False,'verified':False,'connected':bool(connected),'account':account,'message':'已连接指定浏览器窗口；平台登录身份仍需员工在窗口中确认' if connected else '指定浏览器连接不在线'}
                result=payload.get('data',payload) if isinstance(payload,dict) else {}
                if not isinstance(result,dict):result={}
                if account['platform']=='xiaohongshu':
                    decision=evaluate_xhs_identity(account,result,self.store.list('accounts',tenant))
                    status=decision['status']
                    if status in ('identity_mismatch','identity_unverified'):
                        account.update(status=status,checked_at=now())
                        self.store.put('accounts',account)
                        for task in self.store.list('tasks',tenant):
                            if task.get('account_id')==account['id']:
                                task.update(status='paused',last_message='账号身份与记录不一致' if status=='identity_mismatch' else '无法确认账号身份')
                                self.store.put('tasks',task)
                        return {'authenticated':decision['authenticated'],'verified':False,
                                'account':account,'message':decision['message']}
                    if status=='duplicate_identity':
                        duplicate_ids={account['id'],*decision['duplicate_ids']}
                        for item in (account,*[self.store.get('accounts',i) for i in decision['duplicate_ids']]):
                            item.update(status='duplicate_identity',checked_at=now())
                            self.store.put('accounts',item)
                        for task in self.store.list('tasks',tenant):
                            if task.get('account_id') in duplicate_ids:
                                task.update(status='paused',last_message='同一小红书身份存在多个账号记录')
                                self.store.put('tasks',task)
                        return {'authenticated':decision['authenticated'],'verified':False,
                                'account':account,'message':decision['message']}
                    account.update(status=status,checked_at=now())
                    if decision['nickname'] and decision['nickname']!='Unknown':
                        account['name']=decision['nickname']; account['platform_nickname']=decision['nickname']
                    if decision['verified']:
                        account['platform_uid']=decision['uid']
                        if decision['avatar']:account['platform_avatar_url']=decision['avatar']
                    self.store.put('accounts',account)
                    return {'authenticated':decision['authenticated'],'verified':decision['verified'],
                            'account':account,'message':decision['message']}
                authenticated=result.get('authenticated') is True
                verified=False
                profile=result.get('user') if isinstance(result.get('user'),dict) else {}
                nickname=str(profile.get('nickname') or profile.get('nick_name') or '').strip()
                account.update(status='ready' if verified else ('credential_present' if authenticated else 'login_required'),checked_at=now())
                if nickname and nickname!='Unknown': account['name']=nickname; account['platform_nickname']=nickname
                self.store.put('accounts',account)
                return {'authenticated':authenticated,'verified':verified,'account':account,'message':'账号联网验证通过' if verified else ('本地凭据存在，仍需验证只读搜索' if authenticated else '请先登录')}
            except PageUnavailable as exc:
                # A local helper/protocol failure says nothing about whether
                # the phone session or the saved platform identity expired.
                raise PageOperationFailure(exc.code) from None
            except AdapterSafetyRequired as exc:
                if account['platform']=='xiaohongshu':
                    # A preflight risk hold is not evidence that saved login
                    # expired, for either the browser or the native CLI route.
                    raise CoreError(str(exc)) from None
                account.update(status='login_required',checked_at=now()); self.store.put('accounts',account)
                for task in self.store.list('tasks',tenant):
                    if task.get('account_id')==account['id']: task.update(status='paused',last_message='账号登录异常'); self.store.put('tasks',task)
                raise CoreError(str(exc)) from None
            except Exception as exc:
                if account['platform']=='xiaohongshu' and not isinstance(exc,AdapterAuthRequired):
                    # Auth expiry has a dedicated adapter exception. A CLI
                    # protocol/start/verification failure must retain the last
                    # confirmed identity; the activity journal retains the hold.
                    for task in self.store.list('tasks',tenant):
                        if task.get('account_id')==account['id']:
                            task.update(status='paused',last_message='连接检查未完成，登录记录仍保留')
                            self.store.put('tasks',task)
                    raise CoreError(str(exc)) from None
                account.update(status='login_required',checked_at=now()); self.store.put('accounts',account)
                for task in self.store.list('tasks',tenant):
                    if task.get('account_id')==account['id']: task.update(status='paused',last_message='账号登录异常'); self.store.put('tasks',task)
                raise CoreError(str(exc))
        if action=='verify_adapter':
            self._admin(user)
            platform=str(data.get('platform',''))
            if platform=='wechat_channels': raise CoreError('视频号不提供身份验证；请检查单一客户端连接后试采集')
            if platform=='kuaishou': raise CoreError('快手不支持关键词测试；请检查指定连接，并运行作品评论任务验证采集')
            if not any(x['id']==platform for x in self.adapters.manifests()): raise CoreError('未知平台')
            account=self._get('accounts',data.get('account_id'),tenant) if data.get('account_id') else None
            if not account: raise CoreError('请先创建并选择平台账号')
            if user.get('cloud_bound'):self._account_access(user,account)
            if account and account.get('platform')!=platform: raise CoreError('账号平台不匹配')
            if platform=='xiaohongshu' and account.get('status') in ('identity_mismatch','identity_unverified','duplicate_identity'):
                raise CoreError('小红书账号身份未核实；请用原账号重新扫码并完成身份检查，不能靠搜索验证解除暂停')
            self._require_customer_xhs_identity(account,tenant)
            directory=self.store.directory/'accounts'/tenant/account['id'] if account else None
            try: result=self.adapters.verify(platform,data.get('keyword') or '租房',directory,account.get('conn_id') if account else None)
            except Exception as exc: raise CoreError(str(exc))
            if account: account.update(status='ready',checked_at=now()); self.store.put('accounts',account)
            self._audit(user,'verify_adapter',platform,tenant); return result
        if action=='dashboard':
            counts={e:len(self.store.list(e,tenant)) for e in ('tasks','leads','accounts','replies','assets')}
            return {'counts':counts,'tenant':self.store.get('tenants',tenant),'platforms':self._platforms(),'capabilities':capability_summary(self._policy(),self.store.list('accounts',tenant))}
        if action=='list':
            entity=data.get('entity')
            if entity not in self.ENTITIES: raise CoreError('未知数据类型')
            if entity in ('users','audit','reply_queues'): self._admin(user)
            rows=self.store.list(entity,None if entity=='tenants' and user['role']=='admin' else tenant)
            if user.get('cloud_bound'):
                if entity=='accounts':rows=[x for x in rows if x.get('cloud_owner')==user.get('username')]
                elif entity=='tasks':
                    visible=[]
                    for task in rows:
                        try:self._task_access(user,task,tenant)
                        except CoreError:continue
                        visible.append(task)
                    rows=visible
            return [self._public(x) for x in rows]
        if action=='save': return self._save(data,user,tenant)
        if action=='account_delete' or (action=='delete' and data.get('entity')=='accounts'):
            return self._delete_account(data,user,tenant)
        if action=='delete':
            entity=data.get('entity')
            if entity not in self.ENTITIES or entity in ('audit','replies','tenants','reply_queues','publications'): raise CoreError('该数据不可删除')
            if entity in ('users','accounts'): self._admin(user)
            record=self._get(entity,data.get('id'),tenant)
            if entity=='tasks':self._task_access(user,record,tenant)
            if entity=='users' and record['id']==user['id']: raise CoreError('不能删除当前账号')
            if entity=='tasks' and (record['id'] in self.running or record['id'] in self.sequences or self.continuous.is_active(record['id'])): raise CoreError('请先停止运行中的任务再删除')
            self.store.delete(entity,record['id']); self._audit(user,'delete',entity+':'+record['id'],tenant)
            return {'ok':True}
        if action=='import_csv':
            rows=list(csv.DictReader(io.StringIO(data.get('content','').lstrip('\ufeff'))))
            if len(rows)>20000: raise CoreError('单次最多导入 20000 条')
            for row in rows:
                if row.get('reply_status'): row['historical_reply_status']=str(row['reply_status'])+'（CSV导入，未核实）'
            return self._import(rows,tenant,user)
        if action=='export_csv':
            fields=['platform','source_id','title','author','text','url','published_at','region','grade','system_grade','system_grade_reason','manual_grade','grade_reason','reply_status','historical_reply_status','source_type','demo']
            out=io.StringIO(); writer=csv.DictWriter(out,fieldnames=fields,extrasaction='ignore'); writer.writeheader()
            for row in self.store.list('leads',tenant):
                writer.writerow({k:("'"+str(v) if isinstance(v,str) and v.startswith(('=','+','-','@','\t','\r')) else v) for k,v in row.items()})
            return {'filename':'线索导出.csv','content':'\ufeff'+out.getvalue()}
        if action=='run_task': return self._run(data,user,tenant,execution_guard=execution_guard) if execution_guard else self._run(data,user,tenant)
        if action=='run_task_sequence': return self._run_sequence(data,user,tenant,execution_guard=execution_guard) if execution_guard else self._run_sequence(data,user,tenant)
        if action in ('continuous_start','continuous_resume','continuous_pause','continuous_status'):
            task=self._get('tasks',data.get('id'),tenant)
            self._task_access(user,task,tenant)
            if action=='continuous_status':return self.continuous.result(task)
            if action=='continuous_pause':return self.continuous.pause(task)
            self.require_platform(task.get('platform'))
            self._platform_execution_guard(task.get('platform'))
            if task.get('continuous_enabled') is not True:raise CoreError('请先将任务保存为持续采集')
            if task.get('platform')=='xiaohongshu':
                account=self._get('accounts',task.get('account_id'),tenant)
                self._account_access(user,account)
                path=self.store.directory/'accounts'/tenant/account['id']/'platform-activity.jsonl'
                review=account_review_view(path)
                if review['requires_review']:
                    raise CoreError('采集请求暂未被小红书接受，请查看手机是否有提醒，并到小红书账号页核对'
                                    if review['review_reason']=='verification_required'
                                    else '账号安全记录暂无法核对，已停止采集'
                                    if review['review_reason']=='unknown'
                                    else '账号有待复核的异常，请先在本机账号安全记录复核')
            try:
                normalize_continuous_task(task)
                return self.continuous.start(task,user,resume=action=='continuous_resume')
            except ValueError as exc:raise CoreError(str(exc)) from exc
        if action=='account_mode_status':
            account=self._get('accounts',data.get('id'),tenant)
            self._account_access(user,account)
            return self.account_mode_status(account['id'],tenant)
        if action=='cancel_task':
            with self.lock:
                task=self._get('tasks',data.get('id'),tenant)
                self._task_access(user,task,tenant)
                if task.get('continuous_enabled'):
                    return self.continuous.pause(task)
                event=self.sequences.get(task['id'])
                if event: event.set()
                cancelled=self.adapters.cancel(task['id'])
                task.update(status='paused',last_message='已请求暂停')
                if event: task.update(sequence_status='stopped',sequence_message='已请求暂停连续采集')
                self.store.put('tasks',task)
            self._audit(user,'cancel_task',task['id'],tenant)
            return {'cancelled':cancelled,'status':'paused'}
        if action=='resume_task':
            task=self._get('tasks',data.get('id'),tenant)
            self._task_access(user,task,tenant)
            if task['id'] in self.running or task['id'] in self.sequences: raise CoreError('任务仍在结束中，请稍后恢复')
            task.pop('pause_reason',None)
            task.update(status='ready',last_message='已恢复，可继续下一批'); self.store.put('tasks',task)
            self._audit(user,'resume_task',task['id'],tenant); return task
        if action=='preview_template':
            # Local preview deliberately creates no reply and invokes no platform.
            template=self._get('templates',data.get('id'),tenant)
            draft=data.get('draft') or {}
            template={**template,**{k:draft[k] for k in ('text','keywords','grade') if k in draft}}
            if not isinstance(template.get('keywords',[]),list) or any(not isinstance(w,str) for w in template.get('keywords',[])):raise CoreError('触发关键词格式无效')
            if template.get('grade','') not in ('','A','B','C'):raise CoreError('意向等级无效')
            sample=str(data.get('sample',''))[:10000]
            body=self._render_template(template,tenant)
            return {'matched':self._template_matches(template,sample,data.get('grade','C')),
                    'text':body,'unresolved':list(dict.fromkeys(re.findall(r'\{[^{}]+\}',body))),
                    'source':'本地模板和企业资料；未创建回复或发送'}
        if action=='suggest_reply':
            lead=self._get('leads',data.get('lead_id'),tenant)
            text=str(lead.get('title',''))+' '+str(lead.get('text',''))
            base=self._company(tenant).get('templates',[])
            industry=self.store.get('tenants',tenant).get('industry')
            templates=[t for t in self.store.list('templates',tenant) if not t.get('industry') or t['industry']==industry] or base
            templates=[{**t,'keywords':t.get('keywords') or next((x.get('keywords',[]) for x in base if x.get('name')==t.get('name')),[])} for t in templates]
            match=next((t for t in templates if self._template_matches(t,text,lead.get('grade','C'))),None)
            if not match: raise CoreError('没有匹配的规则模板，请人工撰写草稿')
            body=self._render_template(match,tenant)
            return self._reply('draft_reply',{'lead_id':lead['id'],'text':body},user,tenant)
        if action=='run_reply_queue': return self._reply_queue(data,user,tenant)
        if action in ('prepare_reply_queue','run_reviewed_reply_queue','cancel_reviewed_reply_queue','reviewed_reply_queue_status'):
            try:
                if action=='prepare_reply_queue':return self.reviewed_reply_queues.prepare(data,user,tenant)
                queue=self._get('reply_queues',data.get('id'),tenant)
                if not queue.get('reviewed'):raise CoreError('不是已确认回复队列')
                self.reviewed_reply_queues._access(queue,user)
                if action=='run_reviewed_reply_queue':return self.reviewed_reply_queues.start(queue,data,user)
                if action=='cancel_reviewed_reply_queue':return self.reviewed_reply_queues.cancel(queue,user)
                return queue
            except ValueError as exc:raise CoreError(str(exc)) from exc
        if action=='cancel_reply_queue':
            self._admin(user)
            queue=self._get('reply_queues',data.get('id'),tenant)
            queue.update(status='cancelled',message='已取消后续发送；正在执行的单条需等待结果'); self.store.put('reply_queues',queue)
            self._audit(user,'cancel_reply_queue',queue['id'],tenant); return queue
        if action in ('draft_reply','approve_reply','review_reply','copy_reply','mark_reply_sent','send_reply'): return self._reply(action,data,user,tenant)
        if action=='backup':
            self._admin(user)
            result=BackupManager(self.store).create()
            self._audit(user,'backup',result['path']); return result
        if action=='restore':
            self._admin(user)
            if self.running or self.sequences or any(self.continuous.is_active(x['id']) for x in self.store.list('tasks')) or any(x.get('status')=='sending' for x in self.store.list('replies')) or any(x.get('status')=='sending' for x in self.store.list('publications')) or any(x.get('status') in ('running','awaiting_collection') for x in self.store.list('reply_queues')): raise CoreError('仍有任务或发送正在运行，请完成或暂停后再恢复')
            if not check_password(data.get('password',''),current['password_hash']): raise CoreError('管理员密码错误')
            path=Path(data.get('path','')).resolve(); root=(self.store.directory/'backups').resolve()
            if path.parent!=root or not path.is_file(): raise CoreError('只能恢复本工作区 backups 内的备份')
            result=BackupManager(self.store).restore(path)
            restored_tenants=self.store.list('tenants')
            self._audit(user,'restore',str(path),restored_tenants[0]['id'] if restored_tenants else user['tenant_id']); return result
        raise CoreError('未知操作：'+str(action))
    def _save(self,data,user,tenant):
        entity=data.get('entity'); incoming=dict(data.get('record') or {})
        if entity=='tasks' and any(key in incoming for key in ('pipeline','_query_page','_pipeline_next')):
            raise CoreError('采集断点由读取流程维护，不能通过任务编辑改写')
        incoming.pop('created_at',None); incoming.pop('updated_at',None)
        if entity not in self.ENTITIES or entity in ('audit','replies','reply_queues','publications'): raise CoreError('不可直接写入该数据')
        if entity in ('users','tenants'): self._admin(user)
        old=self._get(entity,incoming['id'],tenant) if incoming.get('id') else {}
        if entity=='tasks' and (incoming.get('scope')=='livestream_chat' or 'livestream_only' in incoming or old.get('scope')=='livestream_chat'):
            raise CoreError('直播分析任务由受控直播来源维护，不能改作关键词或视频评论任务')
        if entity=='leads' and ('live_source' in incoming or old.get('source_type')!='livestream_chat' and (incoming.get('source_type')=='livestream_chat' or str(incoming.get('source_id','')).startswith('live-chat:'))
                or old.get('source_type')=='livestream_chat' and any(k in incoming and incoming[k]!=old.get(k) for k in ('source_type','source_id','text','author_id','store_id','url','note_url','comment_id'))):
            raise CoreError('直播原文及来源由受控接纳流程维护，不能通过线索编辑伪造或改写')
        if entity=='accounts':
            if old:self._account_access(user,old)
            elif (user.get('cloud_bound') and incoming.get('cloud_owner')!=user.get('username')) or (not user.get('cloud_bound') and user.get('role')!='admin'):
                raise CoreError('只能创建自己的平台账号')
        if entity=='leads' and user.get('cloud_bound'):
            if old:
                if old.get('task_id'):
                    self._task_access(user,self._get('tasks',old['task_id'],tenant),tenant)
                elif old.get('cloud_owner')!=user.get('username'):
                    raise CoreError('此评论没有可核实的员工归属，不能修改')
                if incoming.get('task_id',old.get('task_id'))!=old.get('task_id') or incoming.get('cloud_owner',old.get('cloud_owner'))!=old.get('cloud_owner'):
                    raise CoreError('不能更改评论的采集任务或员工归属')
            else:
                if incoming.get('cloud_owner') not in (None,user.get('username')):
                    raise CoreError('不能替其他员工创建评论')
                if incoming.get('task_id'):
                    self._task_access(user,self._get('tasks',incoming['task_id'],tenant),tenant)
        record=self._record({**old,**incoming},tenant)
        if entity=='leads' and user.get('cloud_bound'):
            record['cloud_owner']=old.get('cloud_owner') or user['username']
        if entity=='accounts':
            self.require_platform(record.get('platform'))
            if old and record.get('cloud_owner')!=old.get('cloud_owner'):
                raise CoreError('已有平台账号不能通过编辑转移员工归属')
            try:check_account_limit(self._policy(),self.store.list('accounts',tenant),old.get('id'))
            except EntitlementError as exc:raise CoreError(str(exc)) from exc
            record['name']=str(record.get('name','')).strip()
            if not record['name']: raise CoreError('请填写账号名称')
            if old and record.get('platform')!=old.get('platform'): raise CoreError('已有账号不能更改平台，请新建独立账号')
            if record.get('platform') not in {x['id'] for x in self.adapters.manifests()}: raise CoreError('该平台尚未接入工作台')
            record['conn_id']=str(record.get('conn_id','')).strip()
            if record['conn_id'] and any(x['id']!=record['id'] and x.get('platform')==record.get('platform') and x.get('conn_id')==record['conn_id'] for x in self.store.list('accounts',tenant)):
                raise CoreError('此浏览器连接已绑定其他账号，请使用独立账号窗口')
        if entity=='tenants':
            record['tenant_id']=record['id']
            if old and old.get('industry')!=record.get('industry'):
                supplied=incoming.get('business_rules')
                config=supplied if isinstance(supplied,dict) and supplied.get('industry')==record.get('industry') else None
                if self.resources_dir and config is None:
                    for path in sorted((self.resources_dir/'companies').glob('*.json')):
                        candidate=json.loads(path.read_text('utf-8-sig'))
                        if candidate.get('industry')==record.get('industry'): config=candidate; break
                if not config: raise CoreError('该行业没有已安装配置，请先通过交付工厂添加行业组件')
                for template in self.store.list('templates',tenant):
                    if not template.get('industry'): template['industry']=old.get('industry'); self.store.put('templates',template)
                record.update(business_rules=config,company_id=config.get('id'))
        if entity=='users':
            if not old:
                limit=int(self._company(tenant).get('employeeLimit') or 10)
                if len(self.store.list('users',tenant))>=limit: raise CoreError('当前企业员工数量已达到配置上限（%s 人）'%limit)
            if 'daily_send_limit' in record:
                record['daily_send_limit']=int(record['daily_send_limit'])
                if not 1<=record['daily_send_limit']<=1000: raise CoreError('员工每日回复限额必须为 1—1000')
            record.pop('password_hash',None)
            record['username']=str(record.get('username','')).strip()
            if not record['username']: raise CoreError('账号不能为空')
            if record.get('role') not in ('admin','operator'): raise CoreError('员工角色无效')
            if any(x['username']==record['username'] and x['id']!=record['id'] for x in self.store.list('users')): raise CoreError('账号已存在')
            if record['id']==user['id'] and (record.get('role')!='admin' or record.get('disabled')): raise CoreError('不能降级或停用当前管理员')
            password=record.pop('password','')
            if password and len(password)<10: raise CoreError('密码至少 10 位')
            record['password_hash']=password_hash(password) if password else old.get('password_hash')
            if not record['password_hash']: raise CoreError('新员工必须设置密码')
        if entity=='tasks':
            if old:self._task_access(user,old,tenant)
            if ('source_ref' in incoming and incoming.get('source_ref')!=(old or {}).get('source_ref')
                    or old and old.get('source_ref') and any(record.get(k)!=old.get(k)
                        for k in ('platform','account_id','scope','note_url','store_id','keywords','source_kind'))):
                raise CoreError('指定来源快照不可直接改写，请新建来源任务以保留原断点')
            if user.get('cloud_bound'):
                if incoming.get('cloud_owner') not in (None,user.get('username')):
                    raise CoreError('不能替其他员工创建采集任务')
                record['cloud_owner']=user['username']
            if old and (record['id'] in self.running or record['id'] in self.sequences or self.continuous.is_active(record['id'])):
                raise CoreError('请先暂停任务并等待本批结束，再修改任务设置')
            self.require_platform(record.get('platform'))
            if record.get('account_id'):
                account=self._get('accounts',record['account_id'],tenant)
                if user.get('cloud_bound'):self._account_access(user,account)
                if account.get('platform')!=record.get('platform'):
                    raise CoreError('执行账号与任务平台不一致，请重新选择账号')
            if not old or any(record.get(key)!=old.get(key) for key in ('platform','scope','account_id')):
                unavailable=platform_runtime_unavailable_reason(record.get('platform'))
                if unavailable:raise CoreError(unavailable)
            account_replaced=bool(old and old.get('account_removed') and not old.get('account_id') and record.get('account_id'))
            if account_replaced:
                history=list(old.get('account_checkpoint_history') or [])
                history.append({k:old.get(k) for k in ('removed_account_name','pipeline','next_cursor','next_page','exhausted') if k in old})
                record.update(account_checkpoint_history=history,account_removed=False,next_cursor='',next_page=1,exhausted=False)
                record.pop('pipeline',None)
                record['last_message']='已更换执行账号，请开始新一轮采集；客户与历史记录保留'
            normalize_task_rules(record)
            record.setdefault('scope','search')
            if record['scope'] not in ('search','comments','search_comments'): raise CoreError('采集方式无效')
            if record['scope']=='search_comments':
                if record.get('platform') not in ('xiaohongshu','douyin','zhihu','wechat_channels'): raise CoreError('此平台尚未支持关键词到评论流程')
                if not record.get('keywords'): raise CoreError('请至少设置一个检索关键词')
                if old and any(record.get(k)!=old.get(k) for k in (('keywords','platform','scope') if account_replaced else ('keywords','platform','account_id','scope'))):
                    raise CoreError('关键词评论任务的检索词、平台、账号与方式不可中途改换，请新建任务以保留原断点')
            if record.get('platform')=='kuaishou' and record['scope']!='comments': raise CoreError('快手当前只支持指定作品评论，不支持关键词搜索')
            extension_source=record.get('source_kind') in ('profiles','own_interactions')
            if extension_source and (not user.get('cloud_bound') or record.get('platform')!='xiaohongshu'
                    or record['scope']!='comments' or record.get('note_url') or record.get('keywords')):
                raise CoreError('扩展来源必须由当前员工明确选择并保存计划')
            if record['scope']=='comments' and not extension_source:
                expected='https://www.douyin.com/video/' if record.get('platform')=='douyin' else (('https://www.kuaishou.com/short-video/','https://www.kuaishou.com/photo/') if record.get('platform')=='kuaishou' else 'https://www.xiaohongshu.com/')
                if record.get('platform')=='wechat_channels':video_reference(record.get('note_url'))
                elif record.get('platform')=='zhihu':answer_url(record.get('note_url'))
                elif not str(record.get('note_url','')).startswith(expected): raise CoreError('评论任务需填写对应平台完整内容链接')
            if record.get('platform')=='kuaishou':
                record['max_pages']=int(record.get('max_pages',3))
                if not 1<=record['max_pages']<=10: raise CoreError('快手单批评论页数必须为 1—10')
            for key in ('keywords','excludes'):
                value=record.get(key,[]); record[key]=[x.strip() for x in value.split(',') if x.strip()] if isinstance(value,str) else value
                if not isinstance(record[key],list): raise CoreError('关键词必须为列表')
            for key,default in [('time_start','00:00'),('time_end','23:59')]:
                record.setdefault(key,default)
                try: datetime.strptime(record[key],'%H:%M')
                except ValueError: raise CoreError('运行时间格式必须 HH:MM')
            for key in ('date_from','date_to'):
                if record.get(key):
                    try: datetime.strptime(record[key],'%Y-%m-%d')
                    except ValueError: raise CoreError('日期格式必须 YYYY-MM-DD')
            if record.get('date_from') and record.get('date_to') and record['date_from']>record['date_to']:
                raise CoreError('发布时间起不能晚于发布时间止')
            record['daily_limit']=int(record.get('daily_limit') or 20)
            record['search_pages']=int(record.get('search_pages',3))
            if not 1<=record['search_pages']<=50:raise CoreError('每个关键词搜索页数范围 1—50')
            if not 1<=record['daily_limit']<=1000: raise CoreError('每日限额范围 1—1000')
            record.setdefault('unknown_policy','exclude'); record.setdefault('status','ready')
            record['target_count']=int(record.get('target_count') or 100)
            if not 1<=record['target_count']<=10000: raise CoreError('目标总量范围 1—10000')
            record.setdefault('next_page',1)
            try:normalize_continuous_task(record)
            except ValueError as exc:raise CoreError(str(exc)) from exc
        if entity=='assets':
            root=(self.store.directory/'assets'/tenant).resolve()
            path=Path(record.get('path','')).resolve()
            if not path.is_relative_to(root) or not path.is_file(): raise CoreError('素材必须位于当前企业专属素材目录且文件存在')
            record['path']=str(path)
        if entity=='accounts' and record.get('platform')=='wechat_channels':
            if any(x.get('platform')=='wechat_channels' and x['id']!=record['id'] for x in self.store.list('accounts')): raise CoreError('视频号当前只支持一个本机微信会话账号，不支持多账号')
            if record.get('status')=='ready': raise CoreError('视频号连接不能标记为已验证身份')
        if entity=='templates':
            record.setdefault('industry',self.store.get('tenants',tenant).get('industry'))
            if record.get('grade','') not in ('','A','B','C'):raise CoreError('意向等级无效')
            keywords=record.get('keywords',[])
            if not isinstance(keywords,list) or any(not isinstance(w,str) for w in keywords):raise CoreError('触发关键词格式无效')
            record['keywords']=list(dict.fromkeys(w.strip() for w in keywords if w.strip()))
        if entity=='leads':
            if incoming.get('reply_status') and incoming['reply_status']!=old.get('reply_status','未回复'): raise CoreError('回复状态只能通过审核发送流程改变')
            if old and any(record.get(k)!=old.get(k) for k in ('platform','source_id','task_id','comment_id','note_url','source_type','target_comment_id','target_author_id')): raise CoreError('线索来源不可更改')
            if not old:
                self._validate_lead(record); self.require_platform(record['platform']); self._classify(record,tenant)
                if not self.store.insert_lead(record): raise CoreError('该来源线索已存在')
                self._audit(user,'create_lead',record['id'],tenant); return record
            # Rule output is immutable through the manual editing endpoint.
            for key in ('system_grade','system_grade_reason','grade_reason','manual_grade_by','manual_grade_at'):
                if key in old:record[key]=old[key]
                else:record.pop(key,None)
            grade_changed='grade' in incoming and incoming['grade']!=old.get('grade')
            manual=incoming.get('grade') if grade_changed and incoming.get('manual_grade',old.get('manual_grade'))==old.get('manual_grade') else incoming.get('manual_grade')
            if 'manual_grade' in incoming or ('grade' in incoming and incoming['grade']!=old.get('grade')):
                if manual not in ('','A','B','C'):raise CoreError('意向等级无效')
                if not manual and not old.get('system_grade') and old.get('manual_grade'):
                    raise CoreError('旧记录未保存系统判断，不能自动恢复，请选择人工等级')
                record.update(manual_grade=manual,grade=manual or old.get('system_grade') or old.get('grade','C'),
                              manual_grade_by=user['id'],manual_grade_at=now())
        self.store.put(entity,record)
        if entity=='users' and (incoming.get('password') or record.get('disabled') or (old and old.get('role')!=record.get('role'))):
            with self.store.connect() as db: db.execute('DELETE FROM sessions WHERE user_id=?',(record['id'],))
        self._audit(user,'save',entity+':'+record['id'],tenant)
        return self._public(record)
    def _publication_snapshot(self,record,tenant):
        self.require_platform(record.get('platform','xiaohongshu'))
        draft=normalize_draft(record)
        account=self._get('accounts',draft['account_id'],tenant)
        if account.get('platform')!=draft['platform']:raise CoreError('发布账号与内容平台不一致')
        paths=resolve_image_paths(draft,self.store.list('assets',tenant),tenant,self.store.directory/'assets'/tenant) if draft['platform']=='xiaohongshu' else []
        digest=hashlib.sha256(json.dumps(draft,sort_keys=True,ensure_ascii=False).encode())
        if draft['platform']=='zhihu':digest.update(str(account.get('conn_id','')).encode())
        for path in paths:
            with Path(path).open('rb') as source:
                for chunk in iter(lambda:source.read(1024*1024),b''):digest.update(chunk)
        return draft,account,paths,digest.hexdigest()
    def _publication(self,action,data,user,tenant):
        if self.deployment_config.get('features',{}).get('publications') is False:
            raise CoreError('当前工作台用于客户线索获取，未开放作品发布')
        with self.lock:
            if action=='save_publication':
                incoming=data.get('record') or {}
                old=self._get('publications',incoming['id'],tenant) if incoming.get('id') else {}
                if old.get('status') in ('sending','unknown','published'):raise CoreError('已尝试发布的内容不可改写或重复发送')
                draft=normalize_draft(incoming)
                self._publication_snapshot(draft,tenant)
                record=self._record({**draft,'id':old.get('id'),'created_at':old.get('created_at'),'status':'draft','created_by':old.get('created_by',user['id'])},tenant)
                self.store.put('publications',record);self._audit(user,action,record['id'],tenant)
                return record
            self._admin(user)
            record=self._get('publications',data.get('id'),tenant)
            if action=='confirm_publication':
                if record.get('status')!='unknown' or data.get('confirmed') is not True:raise CoreError('仅可人工核实结果不明的发布')
                url=str(data.get('url','')).strip()
                if record.get('platform')=='zhihu':
                    question=record['question_url'].rsplit('/',1)[-1]
                    if not re.fullmatch(r'https://www\.zhihu\.com/question/'+re.escape(question)+r'/answer/[1-9][0-9]{0,31}',url):raise CoreError('请填写本问题下已核实的完整回答链接')
                elif not re.fullmatch(r'https://www\.xiaohongshu\.com/explore/[0-9a-fA-F]{24}(?:\?[^\s]*)?',url):raise CoreError('请填写已在平台核实的笔记链接')
                record.update(status='published',url=url,verified_by=user['id'],verification='manual',message='管理员已在平台核实发布成功',updated_at=now())
                self.store.put('publications',record);self._audit(user,action,record['id'],tenant);return record
            draft,account,paths,fingerprint=self._publication_snapshot(record,tenant)
            if action=='approve_publication':
                if record.get('status')!='draft':raise CoreError('仅本地草稿可以审核')
                self._validate_reply_text(draft['title']+'\n'+draft['body'])
                record.update(status='approved',approval_hash=fingerprint,approved_by=user['id'],updated_at=now())
                self.store.put('publications',record);self._audit(user,action,record['id'],tenant);return record
            if data.get('authorized') is not True:raise CoreError('请明确确认此账号、内容和图片的真实对外发布')
            if record.get('status')!='approved':raise CoreError('仅已审核内容可以发布；结果不明禁止重发')
            if record.get('approval_hash')!=fingerprint:raise CoreError('内容或图片已改变，请重新保存并审核')
            manifest=self.adapters.manifest(draft['platform'])
            if not manifest.get('publication_transport_verified'):raise CoreError('发布运行组件尚未完成无重试保护验证')
            if account.get('status')!='ready':raise CoreError('请先登录并验证该发布账号')
            if any(x['id']!=record['id'] and x.get('approval_hash')==fingerprint and x.get('status') in ('sending','published','unknown') for x in self.store.list('publications',tenant)):
                raise CoreError('此账号相同内容已有发布尝试，请先核实原记录')
            # Execute against a private copy of reviewed bytes, not mutable assets.
            staging=self.store.directory/'work'/'publication-images'/tenant/record['id']
            staging.mkdir(parents=True,exist_ok=True)
            staged=[]
            digest=hashlib.sha256(json.dumps(draft,sort_keys=True,ensure_ascii=False).encode())
            if draft['platform']=='zhihu':digest.update(str(account.get('conn_id','')).encode())
            for index,path in enumerate(paths):
                target=staging/(str(index)+Path(path).suffix.lower())
                shutil.copyfile(path,target)
                with target.open('rb') as source:
                    for chunk in iter(lambda:source.read(1024*1024),b''):digest.update(chunk)
                staged.append(str(target.resolve()))
            if digest.hexdigest()!=fingerprint:raise CoreError('图片在准备发布时发生变化，请重新审核')
            if draft['platform']=='zhihu':
                body_path=(staging/'answer.html').resolve()
                body_path.write_text(zhihu_answer_html(draft['body']),encoding='utf-8')
                args=build_zhihu_answer_args(draft,account.get('conn_id'),body_path)
            else:args=build_xhs_args(draft,staged)
            directory=self.store.directory/'accounts'/tenant/account['id']
            record.update(status='sending',attempted_at=now(),attempted_by=user['id'],updated_at=now())
            self.store.put('publications',record);self._audit(user,'publish_attempt',record['id'],tenant)
        try:
            payload=self.adapters.execute(draft['platform'],args,directory,job_id='publish-'+record['id'],timeout=180)
            outcome=parse_xhs_receipt(payload) if draft['platform']=='xiaohongshu' else unknown_outcome('知乎命令已返回，需到问题页面核实回答并登记链接；本次不自动重发')
        except AdapterBusy as error:
            outcome={'status':'approved','message':str(error),'automatic_retry':False}
        except Exception as error:
            outcome=unknown_outcome(str(error))
        with self.lock:
            record.update(outcome,updated_at=now())
            if record['status']=='approved':
                record.pop('attempted_at',None);record.pop('attempted_by',None)
            self.store.put('publications',record);self._audit(user,'publish_result',{'id':record['id'],'status':record['status']},tenant)
        return record
    def _validate_lead(self,row):
        row['platform']=str(row.get('platform') or 'xiaohongshu')
        row['source_id']=str(row.get('source_id') or row.get('url') or '').strip()
        if not row['source_id']: raise CoreError('线索缺少来源 ID 或原帖链接')
        row.setdefault('stage','待跟进'); row.setdefault('reply_status','未回复'); row.setdefault('grade','C')
    def _import(self,rows,tenant,user,*,collection_task=None,observed_comments=None,
                source_page_complete=False,source_inbox_update=None,source_guard=None):
        if any(row.get('source_type')=='livestream_chat' or 'live_source' in row or str(row.get('source_id','')).startswith('live-chat:') for row in rows):
            raise CoreError('直播聊天须通过独立的受控消息接纳合同，不作为视频评论导入')
        prepared=[]
        company=self._company(tenant)
        allowed={'platform','source_id','title','author','text','url','published_at','region','grade','stage','assignee','task_id','demo','comment_id','note_url','author_id','author_avatar_url','source_type','historical_reply_status','parent_id','target_comment_id','target_author_id','content_author','content_author_id','content_title','content_author_avatar_url','content_cover_url','content_published_at','filter_review_reason','parent_text','comment_level','ip_location','semantic_city','semantic_area','location_city','location_area','location_evidence','comment_date_evidence','verification_status','post_date_status'}
        for row in rows:
            record=self._record({k:v for k,v in row.items() if k in allowed},tenant)
            if collection_task is not None and 'comment_time_evidence' in row:
                from .acquisition_sources import platform_time_evidence
                raw=row['comment_time_evidence']
                record['comment_time_evidence']=platform_time_evidence(raw.get('raw') if type(raw) is dict else None)
            if collection_task is not None and collection_task.get('_source_page') is not None:
                record['analysis_status']='pending'
            # This timestamp is written by the local importer, never supplied
            # by an adapter. Preserve legacy records; new rows carry the actual
            # host offset so a subsequent strict preflight can count them.
            record['created_at']=datetime.now().astimezone().isoformat(timespec='seconds')
            for field in ('author_avatar_url','content_author_avatar_url','content_cover_url'):
                if field in record:record[field]=xhs_image_url(record[field])
            if user.get('cloud_bound'):
                if record.get('task_id'):
                    self._task_access(user,self._get('tasks',record['task_id'],tenant),tenant)
                record['cloud_owner']=user['username']
            self._validate_lead(record); self.require_platform(record['platform']); self._classify(record,tenant,company); prepared.append(record)
        observations={}
        if collection_task is None:
            imported=self.store.insert_leads(prepared)
        else:
            observations=self.store.insert_collection_page(prepared,tenant_id=tenant,
                task_id=collection_task['id'],owner=user['username'],
                account_id=collection_task['account_id'],platform=collection_task['platform'],
                observations=observed_comments or [],source_page=collection_task.get('_source_page'),
                query_page=collection_task.get('_query_page'),
                source_page_complete=source_page_complete,source_inbox_update=source_inbox_update,source_guard=source_guard)
            imported=observations.pop('imported')
        self._audit(user,'import',{'imported':imported,'duplicates':len(rows)-imported},tenant)
        return {'imported':imported,'duplicates':len(rows)-imported,**observations}
    def _purge_cloud_xhs_session(self,tenant,ident):
        """Remove this account's CLI and owned WebView login, retaining activity."""
        root=self.store.directory.resolve()
        accounts=root/'accounts'
        tenant_dir=accounts/tenant
        account_dir=tenant_dir/ident
        config=account_dir/'.xiaohongshu-cli'
        profile=account_dir/'xhs-browser-profile'
        scoped=(accounts,tenant_dir,account_dir,config,profile)
        if (any(path.is_symlink() or hasattr(path,'is_junction') and path.is_junction()
                or path.exists() and getattr(os.lstat(path),'st_file_attributes',0)
                   & getattr(stat,'FILE_ATTRIBUTE_REPARSE_POINT',0) for path in scoped)
                or tenant_dir.resolve(strict=False).parent!=accounts.resolve(strict=False)
                or account_dir.resolve(strict=False).parent!=tenant_dir.resolve(strict=False)
                or not account_dir.resolve(strict=False).is_relative_to(root)
                or config.resolve(strict=False).parent!=account_dir.resolve(strict=False)
                or profile.resolve(strict=False).parent!=account_dir.resolve(strict=False)):
            raise CoreError('账号登录目录无法安全核对，未删除账号')
        known={'cookies.json','token_cache.json','index_cache.json','search_sessions.json'}
        try:
            if config.exists() and not config.is_dir():
                raise CoreError('账号登录目录异常，未删除账号')
            entries=list(config.iterdir()) if config.exists() else []
            if any(path.name not in known or path.is_dir() or path.is_symlink()
                   or getattr(os.lstat(path),'st_file_attributes',0)
                      & getattr(stat,'FILE_ATTRIBUTE_REPARSE_POINT',0) for path in entries):
                raise CoreError('账号登录目录有未识别的文件，未删除账号；请先人工核实')
            if profile.exists():
                if not profile.is_dir():
                    raise CoreError('网页登录目录异常，未删除账号')
                pending=[profile]
                while pending:
                    folder=pending.pop()
                    with os.scandir(folder) as contents:
                        for item in contents:
                            path=Path(item.path)
                            if (item.is_symlink() or hasattr(path,'is_junction') and path.is_junction()
                                    or getattr(os.lstat(path),'st_file_attributes',0)
                                       & getattr(stat,'FILE_ATTRIBUTE_REPARSE_POINT',0)):
                                raise CoreError('网页登录目录含重定向，未删除账号')
                            if item.is_dir(follow_symlinks=False):pending.append(path)
                # The caller holds this account's execution lock; a live
                # window or locked file must fail without removing the record.
                shutil.rmtree(profile)
            for path in entries:path.unlink()
            if config.exists():config.rmdir()
        except OSError:
            raise CoreError('账号登录状态清理失败，未删除账号；请检查本机文件权限') from None
    def _delete_account(self,data,user,tenant):
        account=self._get('accounts',data.get('id'),tenant)
        if (account.get('platform')=='xiaohongshu'
                and self.deployment_config.get('id')=='fangyu-apartment-client'):
            directory=self.store.directory/'accounts'/tenant/account['id']
            try:
                with account_execution_lock(directory):
                    return self._delete_account_locked(data,user,tenant)
            except AdapterBusy:
                raise CoreError('该账号仍在执行平台操作，请等待结束后再删除') from None
        return self._delete_account_locked(data,user,tenant)

    @staticmethod
    def account_delete_digest(account):
        keys=('id','tenant_id','cloud_owner','store_id','platform','platform_uid','platform_nickname','name','remarks','conn_id','status','identity_recovery_pending')
        return hashlib.sha256(json.dumps({k:account.get(k) for k in keys},ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()

    def _delete_account_locked(self,data,user,tenant):
        account=self._get('accounts',data.get('id'),tenant)
        if user.get('cloud_bound'):
            # The bound employee may remove only their own platform account.
            # Local assistant requests must not forge an administrator role.
            self._account_access(user,account)
        else:
            self._admin(user)
        expected=data.get('expected_account_digest')
        if expected is not None and (not isinstance(expected,str) or not re.fullmatch('[a-f0-9]{64}',expected) or expected!=self.account_delete_digest(account)):
            raise CoreError('账号确认后的身份或资料已变化，本次未删除，请重新核对')
        ident=account['id']
        tasks=[x for x in self.store.list('tasks',tenant) if x.get('account_id')==ident]
        if any(t['id'] in self.running or t['id'] in self.sequences or self.continuous.is_active(t['id']) for t in tasks):
            raise CoreError('这个账号正在采集，请先停止任务并等待结束后再删除')
        for entity,status in (('replies','sending'),('publications','sending'),('reply_queues','running')):
            if any(x.get('account_id')==ident and x.get('status')==status for x in self.store.list(entity,tenant)):
                raise CoreError('这个账号正在发送或处理消息队列，请等待结束后再删除')
        remove_cli_session=(account.get('platform')=='xiaohongshu'
                            and self.deployment_config.get('id')=='fangyu-apartment-client')
        if remove_cli_session:
            self._purge_cloud_xhs_session(tenant,ident)
        updates=[]
        for task in tasks:
            task.update(account_id='',account_removed=True,removed_account_name=account.get('name',''),status='paused',sequence_status='stopped',last_message='执行账号已移除，请重新选择账号后再开始')
            updates.append(('tasks',task))
        for employee in self.store.list('users',tenant):
            active=employee.get('active_accounts') or {}
            filtered={key:value for key,value in active.items() if value!=ident}
            if filtered!=active:
                employee['active_accounts']=filtered;updates.append(('users',employee))
        with self.store.connect() as db:
            for entity,record in updates:
                db.execute('UPDATE records SET body=? WHERE entity=? AND id=? AND tenant_id=?',(json.dumps(record,ensure_ascii=False),entity,record['id'],tenant))
            db.execute('DELETE FROM records WHERE entity=? AND id=? AND tenant_id=?',('accounts',ident,tenant))
        self._audit(user,'account_delete',{'id':ident,'affected_tasks':len(tasks)},tenant)
        message=('账号已从软件移除，本机登录凭据和缓存已清除；客户、评分、草稿及安全记录保留。相关任务请重新选择账号。'
                 if remove_cli_session else '账号已从软件移除，客户、评分、草稿和历史记录均已保留。相关任务请重新选择账号。')
        return {'ok':True,'deleted_id':ident,'affected_tasks':len(tasks),'message':message}

    def _run(self,data,user,tenant,sequence_event=None,continuous_owner=None,*,execution_guard=None):
        task=self._get('tasks',data.get('id'),tenant)
        if task.get('scope')=='livestream_chat':raise CoreError('直播分析任务只能查询原直播采集编号，不能作为视频评论或关键词采集执行')
        if isinstance(task.get('strategy_source'),dict) and not callable(execution_guard):
            raise CoreError('私有策略快照须通过原任务单批入口执行')
        if execution_guard:execution_guard()
        self._task_access(user,task,tenant)
        self.require_platform(task.get('platform'))
        if not data.get('demo'):self._platform_execution_guard(task.get('platform'))
        if continuous_owner and not self._qa_continuous_allowed():
            runtime=self.deployment_config.get('runtime') or {}
            raise CoreError('员工持续采集许可已失效，断点保留' if isinstance(runtime,dict)
                            and runtime.get('portable_employee_release') is True
                            else '指定设备持续只读验收已失效，断点保留')
        with self.lock:
            task=self._get('tasks',data.get('id'),tenant)
            self._task_access(user,task,tenant)
            if task.get('account_removed'):raise CoreError('请先为任务重新选择执行账号')
            if self.continuous.is_active(task['id']) and continuous_owner!=task['id']:
                raise CoreError('该任务正在持续采集，请先暂停')
            if task['id'] in self.sequences and self.sequences[task['id']] is not sequence_event: raise CoreError('该任务正在连续执行，请先暂停连续任务')
            if task['id'] in self.running: raise CoreError('该任务正在运行，请勿重复启动')
            lease_owner=('continuous:' if continuous_owner else 'batch:')+task['id']
            if task.get('account_id') and not data.get('demo'):
                self.acquire_account_mode(task['account_id'],tenant,'collection',lease_owner)
            self.running.add(task['id'])
        self._set_task_progress(task['id'],'preparing')
        runtime=self.adapters.xhs_page_runtime
        try:
            batch_scope=(runtime.collection_scope(user,task,execution_guard)
                         if task.get('platform')=='xiaohongshu' and runtime is not None and not data.get('demo')
                         else nullcontext())
            with batch_scope:
                result=self._run_inner({**data,'_continuous_execution':continuous_owner is not None},user,tenant,task,execution_guard=execution_guard) if execution_guard else self._run_inner({**data,'_continuous_execution':continuous_owner is not None},user,tenant,task)
            failed=result.get('status')=='blocked'
            if failed:self._set_task_progress(task['id'],'failed','failed')
            elif sequence_event is None:
                latest=self._get('tasks',task['id'],tenant)
                self._set_task_progress(task['id'],'completed','completed',
                    imported=result.get('imported',0),read=(latest.get('last_batch') or {}).get('read',0))
            return result
        except Exception:
            self._set_task_progress(task['id'],'failed','failed')
            raise
        finally:
            with self.lock:
                pending=(runtime is not None and runtime.has_pending_batch(task['id']))
                if not pending:
                    self.running.discard(task['id'])
                    if not continuous_owner and task.get('account_id') and not data.get('demo'):
                        self.release_account_mode(task['account_id'],tenant,lease_owner)
    def _sequence_wait(self,event):
        return event.wait(40)

    def _collection_summary(self,task,user,status,stop_reason,counts):
        """Pure local eligibility check; never probe the platform or claim quota."""
        rows=[row for row in self.store.list('leads',task['tenant_id']) if row.get('task_id')==task['id']]
        today=datetime.now().date().isoformat()
        daily=sum(row.get('created_at','').startswith(today) for row in rows)
        remaining=max(0,min(int(task.get('target_count',100))-len(rows),
                            int(task.get('daily_limit',20))-daily))
        current=self.store.get('users',user['id'])
        allowed=(status in ('stopped','completed') and stop_reason not in ('user_paused','task_paused','operator_disabled')
                 and task.get('status')=='ready' and not task.get('exhausted') and remaining>0
                 and bool(current) and not current.get('disabled') and not task.get('account_removed'))
        if allowed:
            try:
                self.require_platform(task.get('platform'))
                self._platform_execution_guard(task.get('platform'))
                if task.get('account_id'):
                    account=self._get('accounts',task['account_id'],task['tenant_id'])
                    self._account_access(user,account)
                    allowed=account.get('status')=='ready'
            except (CoreError,OSError,ValueError):allowed=False
        progress=self.task_progress(task['id']) or {}
        return {**counts,'run_id':progress.get('run_id'),'batches':task.get('sequence_batches',0),
                'exhausted':bool(task.get('exhausted')),'remaining':remaining,
                'can_continue':bool(allowed),'stop_reason':stop_reason}

    def _run_sequence(self,data,user,tenant,*,execution_guard=None):
        task=self._get('tasks',data.get('id'),tenant)
        if isinstance(task.get('strategy_source'),dict) and not callable(execution_guard):
            raise CoreError('私有策略快照须通过原任务单批入口执行')
        if execution_guard:execution_guard()
        self._task_access(user,task,tenant)
        self.require_platform(task.get('platform'))
        unavailable=platform_runtime_unavailable_reason(task.get('platform'))
        if unavailable:raise CoreError(unavailable)
        batches=int(data.get('max_batches',50))
        if not 1<=batches<=50: raise CoreError('连续执行单次最多 50 批')
        # The workbench promotes one queued comment, returns to its original
        # analyzer, then re-enters. A direct multi-batch caller cannot skip it.
        if collection_inbox.enabled(task):batches=1
        if task.get('status')=='paused': raise CoreError('任务已暂停，请先明确恢复任务')
        event=threading.Event()
        with self.lock:
            task=self._get('tasks',data.get('id'),tenant)
            self._task_access(user,task,tenant)
            if task.get('account_removed'):raise CoreError('请先为任务重新选择执行账号')
            if task['id'] in self.running or task['id'] in self.sequences or self.continuous.is_active(task['id']): raise CoreError('该任务已在执行，不能重复启动连续采集')
            self.sequences[task['id']]=event
            task.update(sequence_status='running',sequence_batches=0,sequence_message='开始连续采集，每批间隔至少 40 秒')
            self.store.put('tasks',task)
        self._set_task_progress(task['id'],'preparing',read=0,imported=0)
        zero_batches=0; imported=0; read_total=0; duplicates=0; final_status='stopped'; message='已达到本次连续执行批数上限'
        stop_reason='batch_limit'; filtered=0; deferred=0; filter_reasons={}; platform_pages=0; platform_error=None
        observation_counts={key:0 for key in ('observed_comments','linked_existing','source_conflicts')}
        comment_time_unknown=0
        try:
            for index in range(batches):
                if event.is_set(): stop_reason='user_paused'; message='用户已暂停连续采集'; break
                current=self.store.get('users',user['id'])
                if not current or current.get('disabled'): stop_reason='operator_disabled'; message='操作员工已停用，连续采集停止'; break
                task=self._get('tasks',task['id'],tenant)
                if task.get('status')=='paused': stop_reason='task_paused'; message='任务已暂停'; break
                try:
                    result=self._run({'id':task['id']},self._public(current),tenant,sequence_event=event,execution_guard=execution_guard) if execution_guard else self._run({'id':task['id']},self._public(current),tenant,sequence_event=event)
                except CoreError as exc: final_status='failed'; stop_reason='execution_failed'; message=str(exc); break
                if result.get('status')=='blocked':
                    final_status='failed';stop_reason='execution_failed';message=result.get('message','采集异常')
                    platform_error=validated_platform_failure(result.get('platform_error'));break
                imported+=result.get('imported',0); duplicates+=result.get('duplicates',0)
                for key in observation_counts:
                    value=result.get(key,0)
                    if type(value) is int and value>=0:observation_counts[key]+=value
                with self.lock:
                    task=self._get('tasks',task['id'],tenant)
                    batch=task.get('last_batch') or {}
                    comment_time_unknown+=batch.get('comment_time_unknown',0)
                    read_total+=batch.get('read',0); filtered+=batch.get('filtered',0); deferred+=batch.get('deferred',0)
                    platform_pages+=batch.get('platform_pages',1)
                    for reason,count in batch.get('filter_reasons',{}).items():
                        filter_reasons[reason]=filter_reasons.get(reason,0)+count
                    task.update(sequence_batches=index+1,sequence_message='已执行 %s 批，本次新增 %s 条'%(index+1,imported))
                    self.store.put('tasks',task)
                self._set_task_progress(task['id'],'saving',read=read_total,imported=imported)
                if event.is_set(): stop_reason='user_paused'; message='用户已暂停连续采集'; break
                if result.get('exhausted'):
                    final_status='completed'; stop_reason='range_exhausted'; message='本轮采集范围完成'; break
                if int(result.get('accumulated',0))>=int(task.get('target_count',100)):
                    final_status='completed'; stop_reason='target_reached'; message='已达到任务目标总量'; break
                today=datetime.now().date().isoformat()
                daily_count=sum(1 for lead in self.store.list('leads',tenant) if lead.get('task_id')==task['id'] and lead.get('created_at','').startswith(today))
                if daily_count>=int(task.get('daily_limit',20)): stop_reason='daily_limit'; message='已达到今天的线索上限'; break
                # A page checkpoint is progress for resuming, but it is not a
                # newly found lead. Stop after three empty batches as promised.
                zero_batches=zero_batches+1 if not result.get('imported') else 0
                if zero_batches>=3: stop_reason='three_empty_batches'; message='连续 3 批无新增线索，停止连续采集'; break
                if index+1<batches:
                    self._set_task_progress(task['id'],'waiting')
                    if self._sequence_wait(event): stop_reason='user_paused'; message='用户已暂停连续采集'; break
        except Exception as exc: final_status='failed'; stop_reason='execution_failed'; message='连续采集停止：'+str(exc)
        finally:
            with self.lock:
                task=self._get('tasks',task['id'],tenant)
                task.update(sequence_status=final_status,sequence_message=message)
                summary=self._collection_summary(task,user,final_status,stop_reason,
                    {'read':read_total,'filtered':filtered,'duplicates':duplicates,'imported':imported,
                     'deferred':deferred,'filter_reasons':filter_reasons,'platform_pages':platform_pages,
                     'comment_time_unknown':comment_time_unknown,**observation_counts})
                if platform_error:summary['platform_error']=platform_error
                task['last_result']={'status':final_status,'summary':summary,'completed_at':now()}
                self.store.put('tasks',task); self.sequences.pop(task['id'],None)
            self._set_task_progress(task['id'],final_status,final_status,imported=imported)
            self._audit(user,'task_sequence',{'task_id':task['id'],'batches':task.get('sequence_batches',0),'message':message},tenant)
        return {'status':final_status,'message':message,'batches':task.get('sequence_batches',0),'imported':imported,'duplicates':duplicates,'summary':summary,'task':task}
    def _run_inner(self,data,user,tenant,task,*,execution_guard=None):
        current=datetime.now().strftime('%H:%M'); start=task.get('time_start','00:00'); end=task.get('time_end','23:59')
        in_hours=start<=current<=end if start<=end else current>=start or current<=end
        if not in_hours: raise CoreError('当前不在任务运行时段')
        if task.get('status')=='paused': raise CoreError('任务已暂停，请先恢复任务')
        today=datetime.now().date().isoformat()
        used=sum(1 for x in self.store.list('leads',tenant) if x.get('task_id')==task['id'] and x.get('created_at','').startswith(today))
        continuous_execution=data.get('_continuous_execution') is True
        remaining=None if continuous_execution else int(task.get('daily_limit',20))-used
        if remaining is not None and remaining<=0: raise CoreError('已达到今天的线索上限')
        accumulated=sum(1 for x in self.store.list('leads',tenant) if x.get('task_id')==task['id'])
        if remaining is not None:
            remaining=min(remaining,int(task.get('target_count',100))-accumulated)
            if remaining<=0: raise CoreError('已达到任务目标总量')
        if task.get('exhausted') and not data.get('demo'): raise CoreError('本轮采集范围已完成，请新建或调整检索任务')
        try:
            from .acquisition_sources import load_plan,comment_time_status
            source_plan=load_plan(self.store,task) if not data.get('demo') else None
            if task.get('source_kind') in ('profiles','own_interactions') and source_plan is None:
                raise CoreError('来源计划尚未完整保存，未开始读取')
            def source_guard():
                if execution_guard:execution_guard()
                if source_plan is not None:
                    latest=self._get('tasks',task['id'],tenant)
                    if latest.get('source_ref')!=task.get('source_ref') or load_plan(self.store,latest)!=source_plan:
                        raise CoreError('指定来源或账号归属已变化；断点保留')
            inbox=None
            if data.get('demo'):
                items=[{'platform':task.get('platform','xiaohongshu'),'source_id':'demo-'+task['id'],'title':'【演示】想找通勤方便的公寓','text':'【演示数据，不是真实客户】预算和区域待确认','demo':True}]
            else:
                if task.get('account_id'):
                    account=self._get('accounts',task['account_id'],tenant)
                    if user.get('cloud_bound'):self._account_access(user,account)
                    allowed=('connected_unverified',) if account.get('platform')=='wechat_channels' else ('ready','已登录','正常')
                    if account.get('status') not in allowed: raise RuntimeError('账号未连接或未确认登录，任务已暂停')
                    if account.get('platform')!=task.get('platform'): raise RuntimeError('账号平台与任务不一致')
                    self._require_customer_xhs_identity(account,tenant)
                    task['_account_dir']=str(self.store.directory/'accounts'/tenant/account['id'])
                    if account.get('platform') in ('douyin','kuaishou','zhihu'):
                        if not account.get('conn_id'): raise RuntimeError('该平台账号必须绑定明确的浏览器连接')
                        task['_conn_id']=str(account['conn_id'])
                else: raise RuntimeError('请先选择隔离账号并确认登录')
                inbox=collection_inbox.pending(self.store,task)
                if inbox and not collection_inbox.enabled(task):
                    raise CoreError('原页待处理方式已变化，已保留原记录；未读取下一页')
                if inbox:
                    items=collection_inbox.current(inbox,task,remaining=remaining)
                elif source_plan is not None and source_plan['config']['kind'] in ('profiles','own_interactions'):
                    from .acquisition_extension_runtime import collect_page
                    items=collect_page(self.adapters,self.store,task,source_plan,source_guard,
                        lambda stage,**counts:self._set_task_progress(task['id'],stage,**counts))
                elif source_plan is not None or task.get('scope')=='search_comments' or (task.get('continuous_enabled') and task.get('scope')=='comments'):
                    def checkpoint():
                        with self.lock:
                            latest=self._get('tasks',task['id'],tenant)
                            if latest.get('status')=='paused': raise RuntimeError('任务已暂停')
                            latest['pipeline']=task['pipeline']; self.store.put('tasks',latest)
                    items=collect_batch(self.adapters,task,checkpoint,
                        lambda stage,**counts:self._set_task_progress(task['id'],stage,**counts),
                        before_read=source_guard if source_plan is not None else execution_guard,
                        fixed_sources=source_plan['config']['items'] if source_plan is not None else None)
                else:
                    self._set_task_progress(task['id'],'reading_comments' if task.get('scope')=='comments' else 'searching')
                    if execution_guard:execution_guard()
                    items=self.adapters.comments(task.get('platform'),task) if task.get('scope')=='comments' else self.adapters.search(task.get('platform'),task)
                task.pop('_account_dir',None)
                task.pop('_conn_id',None)
            if not data.get('demo') and collection_inbox.enabled(task):
                if inbox is None:inbox=collection_inbox.stage(self.store,task,items)
                if inbox:items=collection_inbox.current(inbox,task,remaining=remaining)
            page_read=(len(inbox['items']) if not inbox['read_reported'] else 0) if inbox else len(items)
            page_count=int(not inbox['read_reported']) if inbox else 1
            self._set_task_progress(task['id'],'filtering',batch_read=len(items))
            selected=[]; selected_by_source={}; duplicate_metadata=[]; observed_comments=[]; duplicates=0; filter_reasons={}
            comment_time_unknown=0
            def rejected(reason):
                filter_reasons[reason]=filter_reasons.get(reason,0)+1
            stored_by_source={(x.get('platform'),x.get('source_id')):x for x in self.store.list('leads',tenant)}
            existing=set(stored_by_source)
            for item in items:
                item['task_id']=task['id']
                item.setdefault('source_type','comment' if task.get('scope') in ('comments','search_comments') else 'note')
                if not data.get('demo'):
                    if source_plan is not None:
                        time_status=comment_time_status(item,source_plan)
                        if time_status=='outside':rejected('comment_time');continue
                        if time_status=='unknown':
                            comment_time_unknown+=1
                            reason='评论发表时间待核，尚不能确认命中精确时间窗'
                            item['filter_review_reason']='；'.join(filter(None,[item.get('filter_review_reason'),reason]))
                            item['verification_status']='pending'
                    decision,reason=identity_decision(item,task)
                    if decision=='exclude': rejected('identity'); continue
                    if decision=='review': item.update(filter_review_reason=reason,stage='待核实')
                    self._classify(item,tenant)
                    if task.get('intent_mode')=='A' and item.get('grade')!='A': rejected('intent'); continue
                    if task.get('intent_mode')=='AB' and item.get('grade') not in ('A','B'): rejected('intent'); continue
                    text=' '.join(str(item.get(x,'')) for x in ('title','text'))
                    if any(word in text for word in task.get('excludes',[])): rejected('excluded_word'); continue
                    match_keywords=(not task.get('continuous_enabled') and (task.get('scope') not in ('comments','search_comments') or task.get('comment_keyword_mode','match')=='match'))
                    if match_keywords and task.get('keywords') and not any(word in text for word in task['keywords']): rejected('keyword'); continue
                    if task.get('continuous_enabled'):
                        filter_reason=filter_comment(item,task)
                        if filter_reason:rejected(filter_reason);continue
                    exclude=False; filter_reason=''
                    from .pipeline import uses_post_dates,post_date_status
                    post_dates=uses_post_dates(task)
                    date_field='content_published_at' if post_dates else 'published_at'
                    if post_dates:
                        item['post_date_status']=post_date_status(item.get('content_published_at'),task)
                        if item['post_date_status']=='unverified':
                            reason='平台未提供帖子日期，所选帖子时间范围待核实'
                            previous=str(item.get('filter_review_reason') or '')
                            item['filter_review_reason']='；'.join(dict.fromkeys(filter(None,[*previous.split('；'),reason])))
                            item['verification_status']='pending'
                    for field,expected in ([] if task.get('continuous_enabled') else [('region',task.get('region')),(date_field,task.get('date_from') or task.get('date_to'))]):
                        # Missing post metadata is not proof the comment is
                        # outside its explicit all-time scope. Keep it flagged.
                        if post_dates and field==date_field and item['post_date_status']=='unverified':continue
                        if not expected: continue
                        value=item.get(field)
                        if not value:
                            if task.get('unknown_policy','exclude')!='keep': exclude=True; filter_reason=filter_reason or 'missing_metadata'
                        elif field=='region' and expected not in str(value): exclude=True; filter_reason=filter_reason or 'region'
                        elif field==date_field:
                            date=str(value)[:10]
                            try: datetime.strptime(date,'%Y-%m-%d')
                            except ValueError:
                                if task.get('unknown_policy','exclude')!='keep': exclude=True; filter_reason=filter_reason or 'missing_metadata'
                                continue
                            if task.get('date_from') and date<task['date_from']: exclude=True; filter_reason=filter_reason or 'date'
                            if task.get('date_to') and date>task['date_to']: exclude=True; filter_reason=filter_reason or 'date'
                    if exclude: rejected(filter_reason); continue
                item['task_id']=task['id']; item['platform']=task.get('platform','xiaohongshu')
                item.setdefault('source_type','comment' if task.get('scope')=='comments' else 'note')
                source=(item['platform'],str(item.get('source_id') or item.get('url') or ''))
                observed_comments.append(dict(item))
                if source in existing:
                    duplicates+=1
                    metadata={key:(xhs_image_url(value) if key in ('author_avatar_url','content_author_avatar_url','content_cover_url') else value)
                        for key,value in item.items() if key in ('platform','source_id','comment_id','author_id','note_url','author_avatar_url','target_comment_id','target_author_id','content_title','content_author',
                            'content_author_id','content_author_avatar_url','content_cover_url','content_published_at')}
                    if source in selected_by_source:
                        first=selected_by_source[source]
                        for field,value in metadata.items():
                            if field not in ('platform','source_id') and not first.get(field) and value:first[field]=value
                    else:
                        old=stored_by_source.get(source)
                        owns=not user.get('cloud_bound') or old and old.get('cloud_owner')==user.get('username')
                        if old and not owns and not old.get('cloud_owner') and old.get('task_id'):
                            try:self._task_access(user,self._get('tasks',old['task_id'],tenant),tenant);owns=True
                            except CoreError:pass
                        if old and owns:
                            # Only the scoped store check may restore a missing
                            # comment body; never merge text between two newly
                            # observed rows on source ID alone.
                            if type(item.get('text')) is str:
                                metadata['text']=item['text']
                            metadata['existing_lead_id']=old['id']
                            # Store rechecks these identities against current rows
                            # before replacing a nonempty, possibly expired image URL.
                            metadata['refresh_task_id']=task['id']
                            metadata['refresh_account_id']=task.get('account_id')
                            metadata['refresh_owner']=user.get('username')
                            duplicate_metadata.append(metadata)
                    continue
                existing.add(source); selected.append(item); selected_by_source[source]=item
            with self.lock:
                latest=self._get('tasks',task['id'],tenant)
                if latest.get('status')=='paused': raise RuntimeError('任务已暂停，采集结果未导入')
                if source_plan is not None:source_guard()
                page_complete=remaining is None or len(selected)<=remaining
                if inbox:page_complete=page_complete and inbox['index']+len(items)==len(inbox['items'])
                self._set_task_progress(task['id'],'saving',batch_read=len(items))
                page_rows=selected[:remaining]
                # Store each stable comment once across collecting accounts,
                # but retain observations of existing comments in this task.
                # Deferred originals cannot be linked or acknowledged yet.
                observation_mode=(not data.get('demo') and user.get('cloud_bound')
                    and task.get('platform') in ('xiaohongshu','douyin')
                    and task.get('scope') in ('comments','search_comments'))
                if observation_mode:
                    acknowledged={(row['platform'],str(row.get('source_id') or row.get('url') or '')) for row in page_rows}
                    page_observations=[row for row in observed_comments if
                        (row['platform'],str(row.get('source_id') or row.get('url') or '')) in acknowledged
                        or (row['platform'],str(row.get('source_id') or row.get('url') or '')) in stored_by_source]
                    result=self._import(page_rows,tenant,user,collection_task=task,observed_comments=page_observations,
                        source_page_complete=page_complete,
                        source_inbox_update=collection_inbox.advance(inbox,len(items)) if inbox and task.get('_source_page') is not None else None,
                        source_guard=source_guard if task.get('_source_page') is not None else None)
                else:
                    result=self._import(page_rows,tenant,user)
                result['duplicates']+=duplicates
                if duplicate_metadata:self.store.enrich_leads_missing(tenant,duplicate_metadata)
                latest_discovery=None
                if result['imported'] and selected[:remaining]:
                    latest_discovery=_display_summary(selected[:remaining][-1],_DISCOVERY_PROGRESS_FIELDS)
                    self._set_task_progress(task['id'],'saving',latest_discovery=latest_discovery)
                if task.get('_source_page') is not None and page_complete:task.pop('source_scan_pending',None)
                task.pop('_source_page',None)
                task.pop('_query_page',None)
                accumulated+=result['imported']; info=task.pop('_page_info',{})
                pipeline_next=task.pop('_pipeline_next',None)
                if page_complete and not data.get('demo'):
                    if source_plan is not None or task.get('scope')=='search_comments' or (task.get('continuous_enabled') and task.get('scope')=='comments'):
                        task['pipeline']=pipeline_next
                        task['exhausted']=pipeline_next['keyword_index']>=(len(source_plan['config']['items']) if source_plan is not None else
                            1 if task.get('scope')=='comments' else len(task['keywords']))
                    elif task.get('scope')=='comments':
                        cursor=info.get('cursor','')
                        task['exhausted']=info.get('has_more') is False or not cursor
                        task['next_cursor']=cursor
                    elif task.get('platform')=='wechat_channels':
                        task['next_cursor']=info.get('cursor','')
                        task['exhausted']=info.get('has_more') is False
                    elif task.get('platform') in ('xiaohongshu','douyin'):
                        task['next_page']=int(task.get('next_page',1))+1
                        task['exhausted']=info.get('has_more') is False or not items
                    else: task['exhausted']=True
                batch_stats={'read':page_read,'platform_pages':page_count,'filtered':len(items)-len(selected)-duplicates,'duplicates':result['duplicates'],'imported':result['imported'],'filter_reasons':filter_reasons,'completed_at':now(),'deferred':0 if remaining is None else max(0,len(selected)-remaining)}
                batch_stats.update({key:result[key] for key in ('observed_comments','linked_existing','source_conflicts') if key in result})
                if source_plan is not None:batch_stats['comment_time_unknown']=comment_time_unknown
                if latest_discovery:batch_stats['latest_discovery']=latest_discovery
                progress=self.task_progress(task['id']) or {}
                batch_stats.update({key:progress[key] for key in ('run_id','started_at_epoch') if key in progress})
                task.update(status='ready',last_run=now(),accumulated=accumulated,last_batch=batch_stats,last_message='演示完成' if data.get('demo') else '读取 %s 条，筛除 %s 条，重复 %s 条，新增 %s 条；累计 %s / %s；%s'%(batch_stats['read'],batch_stats['filtered'],batch_stats['duplicates'],result['imported'],accumulated,task.get('target_count',100),'已达到目标' if accumulated>=int(task.get('target_count',100)) else '本轮采集范围完成' if task.get('exhausted') else '可继续下一批'))
                task.pop('last_platform_error',None)
                if continuous_execution:
                    task['last_message']='读取 %s 条，重复 %s 条，新增 %s 条；累计 %s 条；%s'%(len(items),result['duplicates'],result['imported'],accumulated,'本轮已读完，等待增量检查' if task.get('exhausted') else '按断点继续下一批')
                if inbox:self.store.put_records([('tasks',task),(collection_inbox.ENTITY,collection_inbox.advance(inbox,len(items)))])
                else:self.store.put('tasks',task)
                return {**result,'status':'demo' if data.get('demo') else 'completed','message':task['last_message'],'accumulated':accumulated,'next_page':task.get('next_page'),'exhausted':task.get('exhausted',False),'progressed':bool(inbox) or task.get('scope')=='search_comments' and page_complete and not data.get('demo')}
        except Exception as exc:
            task.pop('_account_dir',None)
            task.pop('_conn_id',None)
            task.pop('_pipeline_next',None)
            task.pop('_page_info',None)
            task.pop('_source_page',None)
            task.pop('_query_page',None)
            if isinstance(exc,PageUnavailable):
                message=(PAGE_ERROR_MESSAGES.get(exc.code) if type(exc.code) is str else None)
                message=message or str(PageOperationFailure(None))
            else:
                message=str(exc)
            if isinstance(exc,AdapterAuthRequired) and task.get('account_id'):
                account=self.store.get('accounts',task['account_id'])
                if account and account.get('tenant_id')==tenant:
                    account.update(status='login_required',checked_at=now())
                    self.store.put('accounts',account)
            latest=self.store.get('tasks',task['id']) or {}
            if task.get('source_kind') in ('profiles','own_interactions') and latest.get('source_ref')==task.get('source_ref'):
                # The Store may already have atomically committed a source page.
                # Never roll its cursor/inbox back because later display/audit failed.
                task=latest
            task.update(status='paused',pause_reason=latest.get('pause_reason') if latest.get('pause_reason') in ('user_continuous','user_reply_switch') else 'collection_error',last_message=message,last_run=now()); self.store.put('tasks',task)
            self._audit(user,'task_blocked',message,tenant)
            facts=(validated_platform_failure(getattr(exc,'platform_error',None))
                if isinstance(exc,(AdapterPlatformFailure,AdapterAuthRequired)) else None)
            if facts:
                task['last_platform_error']=facts
            else:
                task.pop('last_platform_error',None)
            self.store.put('tasks',task)
            return {'status':'blocked','imported':0,'duplicates':0,'message':message,
                **({'platform_error':facts} if facts else {})}
    def _reply_recipient(self,lead,channel,user=None,account=None):
        if lead.get('source_type')=='livestream_chat' and channel!='dm':
            raise CoreError('直播聊天不是视频评论，不能发送评论回复；请核对原来源')
        if lead.get('readonly_archive') is True:
            resolver=getattr(self,'archived_reply_targets',{}).get((lead.get('tenant_id'),lead.get('cloud_owner')))
            if resolver is None:raise CoreError('原评论本机路由尚未核对，请回到原来源核对')
            return resolver.resolve(lead,channel,user=user,account=account)
        fields=('platform','author_id') if channel=='dm' else ('platform','comment_id','note_url','url')
        return {field:str(lead.get(field) or '') for field in fields}

    def _resolved_reply_lead(self,lead,channel,user=None,account=None):
        recipient=self._reply_recipient(lead,channel,user=user,account=account)
        # Route only in RAM. Contact events and all persisted lead updates keep
        # the original source and empty immutable archive sending fields.
        return {**lead,**{key:recipient[key] for key in ('platform','comment_id','note_url','url') if key in recipient}}

    def _check_reply_recipient(self,reply,lead,user=None,account=None):
        if reply.get('recipient')!=self._reply_recipient(lead,reply.get('channel','comment'),user=user,account=account):
            raise CoreError('客户或评论来源已变更，或旧草稿未保存收件人；请重新保存草稿并审核')

    def _contact_owner(self,lead,user,tenant):
        owner=str(lead.get('cloud_owner') or '')
        if not owner and lead.get('task_id'):
            task=self._get('tasks',lead['task_id'],tenant)
            owner=str(task.get('cloud_owner') or '')
        if user.get('cloud_bound') and not owner:
            raise CoreError('客户记录缺少可核实的员工归属，不能确认或发送回复')
        return owner

    def _contact_record(self,kind,user,tenant,lead,reply,account=None,records=()):
        owner=self._contact_owner(lead,user,tenant)
        return self.contact_journal.append(contact_event(kind,lead,reply,account),tenant,owner,records)

    def _reply(self,action,data,user,tenant):
        if action=='draft_reply':
            lead=self._get('leads',data.get('lead_id'),tenant)
            try:require_reply_permission(self,user,lead)
            except ValueError as exc:raise CoreError(str(exc)) from exc
            text=str(data.get('text','')).strip()
            if not text: raise CoreError('回复内容不能为空')
            channel=data.get('channel','comment')
            if channel not in ('comment','dm'): raise CoreError('消息方式无效')
            if channel=='dm' and (lead.get('platform')!='douyin' or not str(lead.get('author_id') or '').isdigit()):
                raise CoreError('私信目前仅支持具有用户 ID 的抖音客户')
            existing=[r for r in self.store.list('replies',tenant) if r.get('lead_id')==lead['id']]
            if any(r.get('status') in ('sent','unknown','sending','copied') for r in existing):
                raise CoreError('该线索已发送、发送结果待核实或已复制待确认，不可重复创建发送')
            superseded=[]
            for previous in existing:
                if previous.get('status') in ('draft','approved'):
                    previous.update(status='superseded',updated_at=now())
                    superseded.append(previous)
            reply=self._record({'lead_id':lead['id'],'text':text,'channel':channel,'recipient':self._reply_recipient(lead,channel,user=user),'status':'draft','author_id':user['id'],'version':len(existing)+1},tenant)
            self.store.put_many('replies',[*superseded,reply])
        else:
            reply=self._get('replies',data.get('id'),tenant); lead=self._get('leads',reply['lead_id'],tenant)
            try:require_reply_permission(self,user,lead,reply if action in ('approve_reply','review_reply') else None)
            except ValueError as exc:raise CoreError(str(exc)) from exc
            if action=='send_reply': return self._send_reply(data,user,tenant,reply,lead)
            self._check_reply_recipient(reply,lead,user=user)
            contact_kind=None;contact_account=None;contact_records=[];account=None
            if action in ('approve_reply','review_reply'):
                if reply['status']!='draft': raise CoreError('仅草稿可以审核')
                self._validate_reply_text(reply['text'])
                if action=='review_reply' or user.get('role')!='admin':
                    if data.get('confirmed') is not True:raise CoreError('请明确确认本条回复内容和执行账号')
                    account=self._get('accounts',data.get('account_id'),tenant)
                    if user.get('cloud_bound'):self._account_access(user,account)
                    if account.get('platform')!=lead.get('platform'):raise CoreError('回复账号与评论平台不一致')
                    reply.update(approval_snapshot=reply_snapshot(self,reply,lead,account,user=user),review_account_id=account['id'])
                elif data.get('account_id'):
                    account=self._get('accounts',data['account_id'],tenant)
                    if user.get('cloud_bound'):self._account_access(user,account)
                    reply.update(approval_snapshot=reply_snapshot(self,reply,lead,account,user=user),review_account_id=account['id'])
                reply.update(status='approved',approved_by=user['id'])
                contact_kind='reviewed';contact_account=account if reply.get('review_account_id') else None
            elif action=='copy_reply':
                if reply['status'] not in ('approved','copied'): raise CoreError('回复必须先通过管理员审核')
                self._validate_reply_text(reply['text']); self._employee_quota(user,tenant)
                reply['status']='copied'
                contact_kind='copied'
            elif action=='mark_reply_sent':
                if data.get('confirmed') is not True or reply['status']!='copied': raise CoreError('请复制审核后的回复，并明确确认已人工发送')
                if any(x.get('lead_id')==lead['id'] and x.get('status') in ('sent','unknown') for x in self.store.list('replies',tenant)): raise CoreError('该线索已有发送记录，禁止重复发送')
                self._validate_reply_text(reply['text']); self._employee_quota(user,tenant)
                reply.update(status='sent',sent_at=now(),sent_by=user['id']); lead['reply_status']='sent'
                contact_kind='external_reported';contact_records.append(('leads',lead))
        if action!='draft_reply':
            reply['updated_at']=now()
            if contact_kind:self._contact_record(contact_kind,user,tenant,lead,reply,contact_account,
                                                  [('replies',reply),*contact_records])
            else:self.store.put('replies',reply)
        self._audit(user,action,reply['id'],tenant)
        return {'text':reply['text'],'url':lead.get('url',''),'reply':reply} if action=='copy_reply' else reply

    def _send_reply(self,data,user,tenant,reply,lead,mode_owner=None):
        lease_owner=mode_owner or 'reply:'+reply['id']
        with self.lock:
            reply=self._get('replies',reply['id'],tenant)
            lead=self._get('leads',reply['lead_id'],tenant)
            context=self._prepare_send(data,user,tenant,reply,lead)
            if context is None:return reply
            account,task,directory=context
            self.acquire_account_mode(account['id'],tenant,'replies',lease_owner)
            try:
                reply.update(status='sending',attempted_at=now(),attempted_by=user['id'],account_id=account['id'],idempotency_key=reply['id'])
                attempt_audit=self._record({'actor':user.get('username','system'),'action':'send_attempt','detail':reply['id']},tenant)
                records=[('replies',reply),('audit',attempt_audit)]
                if (self.deployment_config.get('runtime') or {}).get('platform_qa_device_id'):
                    records.append(self.reply_trial.attempt(tenant,reply['id']))
                self._contact_record('send_started',user,tenant,lead,reply,account,
                                     records)
            except Exception:
                if not mode_owner:self.release_account_mode(account['id'],tenant,lease_owner)
                raise
        error=None; busy=False; safety_blocked=False
        try:
            with self.lock:
                current_lead=self._get('leads',reply['lead_id'],tenant)
                self._check_reply_recipient(reply,current_lead,user=user,account=account)
                routing_lead=self._resolved_reply_lead(current_lead,reply.get('channel','comment'),user=user,account=account)
            sending_lead={**routing_lead,'_conn_id':account.get('conn_id'),'_message_channel':reply.get('channel','comment')}
            result=self.adapters.send(account['platform'],sending_lead,reply['text'],directory)
            if not isinstance(result,dict) or result.get('success') is not True: raise RuntimeError('发送适配器未返回明确成功，必须人工核实')
        except AdapterBusy as exc: error=str(exc); busy=True
        except AdapterSafetyRequired as exc: error=str(exc); safety_blocked=True
        except Exception as exc: error=str(exc)
        with self.lock:
            records=[]
            if error is None:
                reply.update(status='sent',sent_at=now(),sent_by=user['id'])
                # The platform call ran outside this lock. Persist only the reply
                # state onto the latest lead, preserving intent corrections and
                # other updates made meanwhile. The contact event below still
                # uses the frozen pre-send lead and intent evidence.
                current_lead=self.store.get('leads',lead['id'])
                if current_lead and current_lead.get('tenant_id')==tenant:
                    current_lead['reply_status']='sent'
                    records.append(('leads',current_lead))
                if reply.get('channel','comment')=='comment':
                    platform_reply_id=result.get('platform_comment_id') or result.get('source_id')
                    if isinstance(platform_reply_id,str) and re.fullmatch(r'[A-Za-z0-9_-]{1,160}',platform_reply_id):
                        reply['platform_reply_id']=platform_reply_id
            elif busy or safety_blocked:
                reply.update(status='approved',last_error=error)
                for key in ('attempted_at','attempted_by','account_id','idempotency_key'): reply.pop(key,None)
                if safety_blocked:
                    account['status']='check_required'; records.append(('accounts',account))
                    if task: task.update(status='paused',last_message=error); records.append(('tasks',task))
            else:
                reply.update(status='unknown',last_error=error); account['status']='check_required'; records.append(('accounts',account))
                if task: task.update(status='paused',last_message='发送结果不明，请核实'); records.append(('tasks',task))
            kind='sent' if error is None else 'failed' if busy or safety_blocked else 'unknown'
            result_audit=self._record({'actor':user.get('username','system'),'action':'send_result',
                                       'detail':{'id':reply['id'],'status':reply['status']}},tenant)
            records=[('replies',reply),*records,('audit',result_audit)]
            try:self._contact_record(kind,user,tenant,lead,reply,account,records)
            except Exception:
                # The platform call has already happened. Preserve its known or
                # uncertain result even if the contact journal cannot commit.
                self.store.put_records(records)
                if not mode_owner:self.release_account_mode(account['id'],tenant,lease_owner)
                raise
            if not mode_owner:self.release_account_mode(account['id'],tenant,lease_owner)
        return reply

    def _prepare_send(self,data,user,tenant,reply,lead):
        self.require_platform(lead.get('platform'))
        trial_account=self._get('accounts',data.get('account_id'),tenant)
        self._public_reply_guard(lead.get('platform'),(user,reply,reply_snapshot(self,reply,lead,trial_account,user=user),data.get('reply_trial')))
        try:require_reply_permission(self,user,lead)
        except ValueError as exc:raise CoreError(str(exc)) from exc
        if data.get('authorized') is not True: raise CoreError('需明确确认本条内容的真实对外发送')
        if reply['status']=='sent': return None
        self._check_reply_recipient(reply,lead,user=user)
        if reply['status'] not in ('approved','copied'): raise CoreError('仅审核通过的回复可发送；结果不明不可重试')
        self._validate_reply_text(reply['text']); self._employee_quota(user,tenant)
        if any(r['id']!=reply['id'] and r.get('lead_id')==lead['id'] and r.get('status') in ('sending','sent','unknown') for r in self.store.list('replies',tenant)): raise CoreError('该线索已有发送记录，禁止重复发送')
        account=self._get('accounts',data.get('account_id'),tenant)
        if user.get('cloud_bound'):self._account_access(user,account)
        if account.get('platform')=='kuaishou': raise CoreError('快手适配器仅支持读取评论；请使用审核后复制、人工回复流程')
        if account.get('status')!='ready' or account.get('platform')!=lead.get('platform'): raise CoreError('账号未登录或平台不匹配')
        self._require_customer_xhs_identity(account,tenant)
        actual=reply_snapshot(self,reply,lead,account,user=user)
        if reply.get('approval_snapshot') and reply['approval_snapshot']!=actual:
            raise CoreError('已审核内容、来源或执行账号已改变，请重新保存并审核')
        # Legacy administrator approvals acquire the account snapshot only after
        # explicit single-send confirmation; reviewed queues always require one.
        reply.setdefault('approval_snapshot',actual)
        if lead.get('demo'): raise CoreError('演示线索禁止外部发送')
        task=self._get('tasks',lead['task_id'],tenant) if lead.get('task_id') else {}
        if task.get('status')=='paused' and task.get('pause_reason') not in ('user_continuous','user_reply_switch'): raise CoreError('原任务已暂停，不能发送')
        current=datetime.now().strftime('%H:%M'); start=task.get('time_start','00:00'); end=task.get('time_end','23:59')
        if not (start<=current<=end if start<=end else current>=start or current<=end): raise CoreError('当前不在运行时段')
        today=datetime.now().date().isoformat()
        sent=sum(1 for r in self.store.list('replies',tenant) if r.get('account_id')==account['id'] and r.get('status') in ('sending','sent','unknown') and r.get('attempted_at','').startswith(today))
        sent+=sum(1 for r in self.store.list('ui_dm_drafts_v1',tenant) if r.get('account_id')==account['id'] and r.get('state') in ('sending','sent','unknown') and r.get('attempted_at','').startswith(today))
        if sent>=int(account.get('daily_send_limit') or 20): raise CoreError('该账号今日发送额度已用完')
        directory=self.store.directory/'accounts'/tenant/account['id']
        manifest=self.adapters.manifest(account['platform'])
        if not manifest.get('reply_contract_verified') or not manifest.get('isolation_guard'): raise CoreError('发送适配器契约或账号隔离尚未验证')
        try:self.adapters.require_account_safe(account['platform'],directory)
        except AdapterSafetyRequired as exc:
            account['status']='check_required'; self.store.put('accounts',account)
            if task: task.update(status='paused',last_message=str(exc)); self.store.put('tasks',task)
            raise CoreError(str(exc)) from None
        if reply.get('channel','comment')=='dm':
            if account['platform']!='douyin' or not manifest.get('dm_contract_verified'): raise CoreError('此平台私信适配器尚未验证')
            if not str(lead.get('author_id') or '').isdigit() or int(lead['author_id'])<=0: raise CoreError('缺少有效的抖音客户用户 ID')
        else:
            routing_lead=self._resolved_reply_lead(lead,reply.get('channel','comment'),user=user,account=account)
            if not routing_lead.get('comment_id') or not routing_lead.get('note_url'):raise CoreError('此线索缺少可回复的评论来源')
        if account['platform']=='douyin' and not account.get('conn_id'): raise CoreError('请先绑定明确的抖音浏览器连接')
        return account,task,directory

    def _reply_queue(self,data,user,tenant):
        self._admin(user)
        if self.deployment_config.get('id')=='fangyu-apartment-client':
            raise CoreError('方隅首版公开回复必须逐条确认，不能启动批量发送队列')
        if data.get('authorized') is not True:raise CoreError('管理员必须明确授权本次已审批回复队列')
        account=self._get('accounts',data.get('account_id'),tenant)
        self._public_reply_guard(account.get('platform'))
        owner='legacy-queue:'+uuid4().hex
        self.acquire_account_mode(account['id'],tenant,'replies',owner)
        try:return self._legacy_reply_queue(data,user,tenant,owner)
        finally:self.release_account_mode(account['id'],tenant,owner)

    def _legacy_reply_queue(self,data,user,tenant,mode_owner):
        self._admin(user)
        if self.deployment_config.get('id')=='fangyu-apartment-client':
            raise CoreError('方隅首版公开回复必须逐条确认，不能启动批量发送队列')
        ids=data.get('reply_ids')
        if data.get('authorized') is not True: raise CoreError('管理员必须明确授权本次已审批回复队列')
        if not isinstance(ids,list) or not 1<=len(ids)<=20 or len(set(ids))!=len(ids): raise CoreError('队列须包含 1—20 条互不重复的回复 ID')
        account=self._get('accounts',data.get('account_id'),tenant)
        with self.lock:
            for id in ids:
                reply=self._get('replies',id,tenant)
                if reply.get('channel')=='dm': raise CoreError('私信请在线索详情逐条确认发送')
                if reply.get('status') not in ('approved','copied'): raise CoreError('队列中含未经审批、已发送或结果不明的回复')
                self._validate_reply_text(reply['text'])
            queue=self._record({'reply_ids':ids,'account_id':account['id'],'authorized_by':user['id'],'status':'running','sent':0,'processed':0,'message':'顺序处理已审批队列'},tenant)
            self.store.put('reply_queues',queue); self._audit(user,'authorize_reply_queue',queue['id'],tenant)
        for id in ids:
            queue=self._get('reply_queues',queue['id'],tenant)
            if queue['status']!='running': return queue
            try:
                current=self.store.get('users',user['id'])
                if not current or current.get('disabled') or current.get('role')!='admin': raise CoreError('队列授权管理员已停用或降级')
                reply=self._get('replies',id,tenant); lead=self._get('leads',reply['lead_id'],tenant)
                result=self._send_reply({'id':id,'account_id':account['id'],'authorized':True},current,tenant,reply,lead,mode_owner=mode_owner)
                queue=self._get('reply_queues',queue['id'],tenant)
                queue['processed']+=1
                if result['status']=='sent': queue['sent']+=1
                else: queue.update(status='stopped',message=('发送结果不明，队列已停止，禁止自动重试' if result['status']=='unknown'
                    else '账号安全复核中，本条未发送，队列已停止' if '账号安全复核' in result.get('last_error','')
                    else '账号通道忙，本条未发送，队列已停止'))
            except Exception as exc:
                queue=self._get('reply_queues',queue['id'],tenant); queue.update(status='stopped',message=str(exc))
            self.store.put('reply_queues',queue)
            if queue['status']!='running': return queue
        queue.update(status='completed',message='本次已审批队列处理完成'); self.store.put('reply_queues',queue)
        return queue
