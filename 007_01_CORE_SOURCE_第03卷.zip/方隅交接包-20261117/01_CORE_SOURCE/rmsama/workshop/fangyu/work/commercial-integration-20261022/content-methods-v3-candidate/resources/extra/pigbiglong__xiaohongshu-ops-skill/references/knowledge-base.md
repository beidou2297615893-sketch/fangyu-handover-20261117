# 小红书知识库 — 使用规范

本文件定义知识库的使用方式：把每次分析、选题、发布、回复、复盘中产生的有效信息，沉淀成可检索、可复用的结构化记录。

---

## 目录结构

```
~/xhs-knowledge-base/
├── README.md           # 总览入口
├── accounts/           # 账号定位、诊断、竞品分析
├── topics/             # 选题、争议点、标题骨架、内容方向
├── patterns/           # 爆款结构、封面模板、互动钩子、复用规则
├── actions/            # 发布、回复、下载、抓取、复刻记录
└── reviews/            # 复盘、失败原因、下次调整
```

---

## 文件命名规则

```
accounts/2026-03-19-account-analysis-xxx.md
topics/2026-03-19-topic-ideas-xxx.md
patterns/2026-03-19-title-hook-pattern.md
actions/2026-03-19-publish-xxx.md
reviews/2026-03-19-reply-retro.md
```

- 日期在最前，方便按时间排序
- brief 2-6 个关键词概括主题
- 一份文件只记录一个核心结论

---

## 数据结构

每条记录至少包含：

```yaml
id: 2026-03-19-xxx
type: account|topic|pattern|action|review
status: active|deprecated|experimental
created_at: 2026-03-19T10:00:00+08:00
source_url: "https://..."
tags: [tag1, tag2]
```

### 分类型字段

| 类型 | 必填字段 |
|------|---------|
| account | 定位、受众、内容支柱、语气、红线 |
| topic | 问题、角度、支撑信号、风险等级 |
| pattern | 标题模板、封面模板、正文模板、CTA模板、适用条件 |
| action | 任务类型、输入、执行步骤、结果、阻塞点 |
| review | 什么有效、什么无效、原因、下次修正 |

---

## 与 Hermes Holographic Memory 的衔接

关键结论需要 **双写**：

```python
from hermes_tools import write_file, fact_store

# 1. 写到文件（长期存档、AI 搜索）
write_file(
    path='~/xhs-knowledge-base/patterns/2026-03-19-xxx.md',
    content='...'
)

# 2. 同步到 Holographic Memory（跨会话快速检索）
fact_store(
    action='add',
    content='小红书已验证模式：XXX（总结自分析）',
    category='general',
    tags='xhs,pattern'
)
```

---

## 更新时机

| 时机 | 动作 |
|------|------|
| 任务前 | 先读 README.md，再检索历史记录 |
| 任务中 | 有高价值结论就记临时摘要 |
| 任务后 | 至少补一条结构化记录 |
| 失败后 | 失败原因、回退策略必须单独记 |
| 周期复盘 | 合并临时记录，废弃过期 pattern |

---

## 检索方法

```bash
# 通过 CLI 搜索
python ~/.hermes/skills/social-media/xiaohongshu-ops/scripts/xhs-cli.py search <keyword>

# 列出最近条目
python ~/.hermes/skills/social-media/xiaohongshu-ops/scripts/xhs-cli.py list
```
