# 客户读取用途材料重绑工具

唯一工具源码是 `customer_review_rebinder.py`，标准库、Python 3.11、Windows；不需要模型、网络或新增依赖。复用已封作者 `prepare_probe.py` 的材料生成逻辑，依赖作者11源和独审固定回执，未新建许可策略。

```python
from customer_review_rebinder import rebind_customer_reviews

result = rebind_customer_reviews(
    project=actual_project_absolute_path,
    release=actual_release_absolute_path,
    evidence_reference="final-source-review:<actual sealed receipt SHA256>",
    reviewed_at="2026-10-23T12:00:00+00:00",  # 实际明确审查时间，带时区且不可是未来
)
```

调用顺序：先完成真实合版源码与原用途依赖图/SOURCE/依赖固定；按原builder生成稳定的held兼容清单及其helper；再调用此函数；最后由原builder固定 `RELEASE`、`SHIPPED` 和编译入口。函数不会替调用者写这两个清单、company、helper、canonical source或原internal reviews。

只写传入release下 `resources/customer-read/` 的四份JSON：证据、账号连接purpose、视频评论purpose、索引。索引最后替换，过渡时摘要不一致会拒绝读取；不是跨四文件的数据库事务，调用者应在自己未运行的候选/既有备份流程内使用。发生中断需恢复该候选四文件或重建后再调，不对已运行实例热更新。

返回实际四文件的路径/大小/前后SHA、相对release路径、按原客户材料比较的变动material pins、材料数量、held/helper摘要和原internal review摘要。索引不含主EXE SHA，没有自引用环；独立CLI/node等真实材料仍按各自实际字节固定。

函数只支持已审的 `douyin_owned_connection` 与 `douyin_owned_video_comments` 两purpose；保原limits、三个证据False、public_send_hold=True、release_approved=False。公司绑定算法、载体purpose声明或现有索引出现未知purpose会明确拒绝、零输出写入。不会猜XHS/DYsearch review字段，不会用新用途替换旧internal用途，也不根据调用字符串自行批准源或许可证。

调用前验证实际目录、无重解析/符号链接/多硬链接、MIT原件固定摘要、原公司合同、held兼容清单的真实全代码集合与helper固定摘要。代码/公司变化后先使原builder稳定，不能为了让重绑通过翻QA/portable标志或去hold。

调用者必须先审最终代码；`evidence_reference` 只是显式技术审查标识，不会联网读取、不代表真实平台/Native/云设备批准。源码/材料、原员工设备、账号/租约、平台授权与真实首用是不同验收层。

测试仅在本工具自有payload。实际QA EXE编译一次，七种预先固定的闭包场景分别运行原 `load_host → verify_release → verify_backend_dependencies → create_backend`；对公司版本、vendor字节、held helper字节逐一证明旧材料拒绝、重绑恢复两个原purpose。每个场景的完整闭包SHA和文件变更操作数都在编译前嵌入QA入口，不接受HTTP选择，也不临时跳过完整性门。此为材料与工厂层，不冒称重复真实设备绑定或平台读取；原设备链引用已封独审。
