from pathlib import Path
p=Path(r'C:/积木软件工坊/项目/方隅公寓客户版/work/parallel-integration-20261018/final-integration/stage-02/project/work/ui-approved-implementation/ui-preview/pages/content-workflow.mjs')
s=p.read_text(encoding='utf-8').replace("f.pending='正在查询上次结果，不重新生成…';f.error='';f.notice='';", "f.pending='正在查询上次结果，不重新生成…';f.recovered=true;f.error='';f.notice='';")
p.write_text(s,encoding='utf-8')
