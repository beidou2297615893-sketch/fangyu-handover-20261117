from pathlib import Path
import shutil
W=Path(__file__).resolve().parent
S=Path('C:/积木软件工坊/项目/方隅公寓客户版/work/parallel-integration-20261018/final-integration/stage-02/project/work/ui-approved-implementation/ui-preview')
H=W/'ui-harness'
for p in S.rglob('*.mjs'):
    target=H/p.relative_to(S);target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,target)
for p in (W/'candidate/work/ui-approved-implementation/ui-preview').rglob('*.mjs'):
    target=H/p.relative_to(W/'candidate/work/ui-approved-implementation/ui-preview');target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,target)
