"""Use installed official CLI with argv, avoiding PowerShell native JSON quoting.

Exactly one read-only API request, no raw output/temporary URL persisted.
"""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,io,json,re,subprocess,urllib.request,zipfile
D=Path(__file__).resolve().parent
NODE=Path('C:/Users/rmsama/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node.exe')
CLI=Path('C:/Users/rmsama/AppData/Roaming/npm/node_modules/@cloudbase/cli/bin/tcb')
base=json.loads((D.parent/'content-cloud-v3-final2/DEPLOYMENT-READBACK.json').read_text('utf-8-sig'))
assert base['status']=='DEPLOYED_EXACT_FULL_READBACK'
assert base['treeSha256']=='744ec24509d6602618543d6c760130de1d7b45a0acc05be89aa09592a03c5a02'
args=[str(NODE),str(CLI),'api','scf','GetFunctionAddress','-e','fh6-d5ga45c0ddae7008c','--body',json.dumps({'FunctionName':'fangyu-workspace','Namespace':'fh6-d5ga45c0ddae7008c'},separators=(',',':')),'--json']
r=subprocess.run(args,capture_output=True,timeout=50)
raw=re.sub(r'\x1b\[[0-9;]*[a-zA-Z]','',r.stdout.decode('utf-8',errors='replace'))
other=r.stderr.decode('utf-8',errors='replace')
report={'utc':datetime.now(timezone.utc).isoformat(),'operation':'GetFunctionAddress','cliExitCode':r.returncode,
 'argvDirect':True,'installedOfficialCli':True,'productionWrites':False,'privateDatabaseRead':False,'environmentVariablesRead':False,'rawOutputPersisted':False,'temporaryUrlPersisted':False}
def find(v,key):
    if isinstance(v,dict):
        if key in v:return v[key]
        for c in v.values():
            out=find(c,key)
            if out is not None:return out
    if isinstance(v,list):
        for c in v:
            out=find(c,key)
            if out is not None:return out
    return None
if r.returncode:
    combined=(raw+'\n'+other).lower()
    report.update(status='READ_ONLY_CLI_FAILED_NOT_DEPLOYED',diagnosticSignals={
        'loginOrCredential':bool(re.search(r'login|credential|unauthori[sz]ed|authfailure|登录|凭证',combined)),
        'jsonOrArgument':bool(re.search(r'json|unknown option|argument|参数',combined)),
        'networkOrTimeout':bool(re.search(r'timeout|enotfound|econn|network|超时|网络',combined)),
        'permission':bool(re.search(r'permission|accessdenied|权限',combined))})
else:
    obj=json.loads(raw[raw.index('{'):raw.rindex('}')+1])
    url=find(obj,'Url');assert isinstance(url,str) and url.startswith('https://')
    with urllib.request.urlopen(url,timeout=50) as response:data=response.read(50_000_001)
    assert len(data)<=50_000_000
    actual={}
    with zipfile.ZipFile(io.BytesIO(data)) as archive:
        for info in archive.infolist():
            if info.is_dir():continue
            assert not info.filename.startswith('/') and '..' not in Path(info.filename).parts and info.filename not in actual
            body=archive.read(info)
            actual[info.filename]={'sha256':hashlib.sha256(body).hexdigest(),'bytes':len(body)}
    h=hashlib.sha256()
    for name in sorted(actual):h.update((name+'\0'+actual[name]['sha256']+'\n').encode())
    report.update(files=len(actual),treeSha256=h.hexdigest(),codeZipSha256=hashlib.sha256(data).hexdigest(),codeZipBytes=len(data))
    expected=json.loads((D.parent/'content-cloud-v3-final2/FILES-SHA256.json').read_text('utf-8-sig'))
    rows={row['path']:row for row in expected}
    differences=[name for name in sorted(set(rows)|set(actual)) if name not in rows or name not in actual or any(rows[name][k]!=actual[name][k] for k in ('sha256','bytes'))]
    report['differences']=differences
    report['status']='EXACT_LIVE_BASELINE_RECONFIRMED' if not differences and h.hexdigest()==base['treeSha256'] else 'LIVE_BASELINE_CHANGED_STOP'
target=D/'DIRECT-SDK-READBACK.json';assert not target.exists()
target.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n','utf-8')
print(json.dumps(report,ensure_ascii=False))
if report['status']!='EXACT_LIVE_BASELINE_RECONFIRMED':raise SystemExit(3)
