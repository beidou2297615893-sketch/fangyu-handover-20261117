# 已授权公共验证边界

总控明确要求并已授权以下边界，不另建鉴权体系。

1. 原createService公开content_generate/content_generate_status：真实服务登录和会话、可信门店/设备账号登记、原企业配置与feature、原共享AI预算和原键回执均经过生产实现。只替换外部事务数据库和provider边界；抓账号/门店越权、预算复用、并发和unknown重派。不能证明真实CloudBase并发或真实模型。
2. 可信17方法公开校验器：与固定Python方法spec对应，验证输出schema与原文引用；不能证明事实的真实性或内容审美质量。
3. Native注入的Python callable/envelope边界：由现有宿主提供已认证transport和当前可信上下文，检查摘要/方法/scope，异常保留unknown、不重试；不能代替宿主当前CSRF/登录接线验收。
4. 真实本地Store的prepare/run/产物公开接口，串接候选云服务与合成provider：验证原任务结果落回与上下文变化保护；不能证明收费模型内容质量或真实平台动作。

红绿以关键链路逐步推进，先验证相同原键并发只派发一次且共享预算中unknown保留预留。保留最初失败日志、最终日志及固定来源。

第二版沿用以上公开边界，增加真实中央store_config目录与profile合同、HQ授权店/单店operator/撤店结算、记住登录与refresh不同执行设备标识、合法续期原键恢复。实际线上19文件只读取码固定，旧规则断言在真实基线对照，不为旧测试回退现行批准标准。
