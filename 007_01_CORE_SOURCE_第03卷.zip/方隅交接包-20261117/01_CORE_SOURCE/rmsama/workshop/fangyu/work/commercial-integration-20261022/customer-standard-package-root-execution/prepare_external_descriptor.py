"""Read-only artifact inventory for ROOT REVIEW, never approval or execution."""
import argparse,hashlib,importlib.util,json,re
from pathlib import Path
C=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('--source',required=True);p.add_argument('--source-receipt',required=True);p.add_argument('--source-receipt-sha256',required=True);p.add_argument('--output-name',required=True);a=p.parse_args()
if not re.fullmatch('[A-Za-z0-9_-]+[.]json',a.output_name) or not re.fullmatch('[0-9a-f]{64}',a.source_receipt_sha256):raise RuntimeError('Fixed receipt and local output basename required')
spec=importlib.util.spec_from_file_location('fixed_clean_successor_tools',C/'build_clean_next.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
source=Path(a.source);receipt=Path(a.source_receipt)
if not source.is_absolute() or not receipt.is_absolute() or hashlib.sha256(m.safe_read(receipt)).hexdigest()!=a.source_receipt_sha256:raise RuntimeError('Explicit source receipt SHA differs')
doc={'schema':'fixed_customer_read_sibling_payload_v1','name':'platform-cli-customer-read','source':str(source),'files':m._inventory(source),'public_send_grant':False,'login_grant':False,'dataIncluded':False}
m.EXTERNAL_INPUTS=doc;m.EXTERNAL_INPUTS_SHA=a.source_receipt_sha256;m._external_descriptor()
output=C/a.output_name
with output.open('x',encoding='utf8') as f:json.dump(doc,f,ensure_ascii=False,indent=2);f.write('\n')
provenance={'status':'ACTUAL_TREE_SNAPSHOT_FOR_ROOT_REVIEW_NOT_BUILD_OR_LICENSE_APPROVAL','sourceReceipt':str(receipt),'sourceReceiptSha256':a.source_receipt_sha256,'inventorySha256':hashlib.sha256(m.safe_read(output)).hexdigest(),'files':len(doc['files']),'executedComponent':False,'validatedReceiptContentAgainstEachArtifact':False,'rootMustReviewActualSnapshotBeforeSupplyingItsShaToBuilder':True}
with (C/(a.output_name+'.provenance.json')).open('x',encoding='utf8') as f:json.dump(provenance,f,ensure_ascii=False,indent=2);f.write('\n')
print(json.dumps(provenance,ensure_ascii=True))
