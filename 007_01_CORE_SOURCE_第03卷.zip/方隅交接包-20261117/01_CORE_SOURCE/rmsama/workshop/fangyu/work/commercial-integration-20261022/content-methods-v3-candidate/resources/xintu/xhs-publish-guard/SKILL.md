---
name: xhs-publish-guard
description: >-
  Final quality gate for carousel and video packages: title, cover/first frame, body/caption, script, tags, and CTA.
  Checks promise alignment, AI voice, unsupported claims, format consistency, and compliance. Advises only; never publishes.
  Use for 发布前检查, 文案体检, 合规改写, 终审.
---

# Xiaohongshu Publish Guard

Final advisor gate before the user publishes manually. This skill does **not** publish, schedule, upload, or automate interactions.

Read `references/compliance-rewrite.md`, `../references/ai-voice-guardrails.md`, and
`../references/voice-cold-start.md`. After a `go`, offer `../references/obsidian-archive.md`.

## Workflow

1. Collect the full package and note `format`: `carousel` or `video`.
2. Read account DNA / provisional voice when available. If the body reads like interchangeable dry-goods
   (no judgment, no imperfection, no situational detail), flag **Must fix** and rewrite with the human
   texture recipe — do not only ask the user to fill a style library.
3. Run `scripts/check_copy.py <file> --format <carousel|video>` on the body/caption, and again without
   `--format` on the title and CTA. Passing the format enables the length-band check
   (carousel 300-800, video 80-220 non-whitespace chars).
4. Review with `references/review-rubric.md`.
5. Title checks (see `../xhs-note-writer/references/title-craft.md`):
   - Do not fail a title only for exceeding 18 characters
   - If the brief had place/intent words, confirm they survived in at least the search alternate
   - If a user topic line was compressed, require the original kept as backup or ask the user
6. Format-specific checks:
   - **carousel**: fold line payoff, slide/cover promise match, save value visible early, not 全国干货腔
   - **video**: caption ≠ script, first-frame/opening alignment, on-screen text length sane
7. Classify findings:
   - Blocker
   - Must fix
   - Improve
   - Keep
8. Rewrite only affected parts; preserve factual meaning.
9. Return `go`, `revise`, or `stop` with reasons.
10. On `go` (or user-accepted revise), ask once whether to archive into Obsidian.

## Reading script output

- `flags[].category=conditional_claim` means the phrase (`保姆级`, `手把手`) is only a problem because
  no reproducible steps were detected. Confirm manually before flagging it to the user.
- `length_check` is advisory; a deliberate short-form note is not a blocker.
- Zero flags is not a pass. The rubric and promise-alignment review still apply.

## Rules

- Apply compliance during rewrite, not only at the end.
- Reject title/body mismatches across formats.
- Treat script flags as human-review prompts.
- Do not publish or message on the user's behalf.
