from pathlib import Path
from datetime import datetime,timezone
import ast,hashlib,json
D=Path(__file__).resolve().parent
W=D.parent
FIXED=W/'xhs-customer-runtime-after-f82-candidate/shared-read-lease-qa-v1'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
interface=json.loads((FIXED/'INTERFACE.json').read_text('utf-8-sig'))
assert sha(FIXED/'INTERFACE.json')=='f4c82e9b629c8af2afd88e6aa2e21aac050ed40171e9de4ddc92b877907e4932'
row=next(r for r in interface['files'] if r['path']=='work/shared-backend-integration/platform_runtime.py')
source=FIXED/'source'/row['path'];assert sha(source)==row['sha256']
calls=[]
for cls in ast.parse(source.read_bytes()).body:
    if not isinstance(cls,ast.ClassDef):continue
    for fn in cls.body:
        if not isinstance(fn,(ast.FunctionDef,ast.AsyncFunctionDef)):continue
        for n in ast.walk(fn):
            if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr in ('_executor','_readiness','_prepare_for_connection'):
                calls.append({'function':fn.name,'line':n.lineno,'call':ast.unparse(n)})
result={'status':'INDEPENDENT_ROOT_STATIC_MAIN_FLOW_GAPS_IDENTIFIED_NOT_A_RUNTIME_PASS','utc':datetime.now(timezone.utc).isoformat(),
    'skillActuallyRead':'codebase-design','fixedInterfaceSha256':sha(FIXED/'INTERFACE.json'),'sourceSha256':sha(source),
    'callSites':sorted(calls,key=lambda r:r['line']),
    'gapsReportedToExclusiveRuntimeAuthor':[
        {'function':'snapshot','lines':[645,666],'impact':'old general readiness can misreport connection even when purpose-scoped collection readiness is true'},
        {'function':'create_account','lines':[1053,1054,1056],'impact':'original account-add preparation still uses old general scope'},
        {'function':'_analyze_collection_page.visible','lines':[2653],'impact':'page data may persist while original analysis scheduling is rejected by old default executor'}],
    'requiredFix':'Map actual connection and per-task collection purpose at these exact read call sites. Preserve original principal/store/task/DeviceSession/AI stop/attempt/CAS. Do not alter default executor or send grants.',
    'originalClosedFunctions':['livestream_guard','dm_guard','reply_guard'],
    'naturalPurposes':'identity/session/verification each needs its own real material; CLI read is not their authority',
    'ownerAcknowledgement':'knowledge_review_4 acknowledged v3 follow-up, preserving fixed v2 and ongoing QA bytes',
    'productSourceWritten':False,'productionReadOrWritten':False,'runtimeOrPlatformSuccessClaimed':False}
(D/'CALLSITE-REVIEW.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n','utf-8')
print(json.dumps({'status':result['status'],'callSites':len(calls),'reviewSha256':sha(D/'CALLSITE-REVIEW.json')},ensure_ascii=False))
