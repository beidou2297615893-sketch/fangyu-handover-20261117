/* Atomic enterprise ledger/cache, using the same real CloudBase transaction as workspace auth. */
const crypto = require('node:crypto');
const {AiError, defaults, safeConfig, saveConfig, normalizeInput, prompt, validateOutput, validateIntentBatchSafe, tariff, usageOf,
  actualMicro, reservationMicro, dayOf, hash, RULES_VERSION, MODELS, OPENAI_MODELS,
  reasoningEffort, apiKeyFor, effectiveRulesVersion} = require('./ai_contract.cjs');
const {createProvider, ProviderError} = require('./ai_provider.cjs');
const {createProductEntitlements}=require('./product_entitlements.cjs');
const {createAiRequestRecovery}=require('./ai_request_recovery.cjs');
const {normalizePublishedPolicy,policyDigest,effectiveSnapshot}=require('./intent_policy_publication.cjs');
const {authorizeContent,contentContextCurrent,contentContextHash,contentInputHash,contentMessages,contentMaxTokens,contentCapability}=require('./content_contract.cjs');
const {createContentGateway}=require('./content_gateway.cjs');
const OPERATIONS = new Set(['ai_config_read', 'ai_config_save', 'ai_profile', 'ai_attempt_status', 'keyword_suggest', 'intent_analyze',
  'intent_policy_read','intent_policy_publish','intent_policy_publish_status','content_generate','content_generate_status']);
const COLLECTIONS = {budget: 'fangyu_ai_budget', ledger: 'fangyu_ai_ledger', cache: 'fangyu_ai_cache'};
const POLICY_COLLECTIONS={versions:'fangyu_intent_policy_versions',publications:'fangyu_intent_policy_publications'};
const microsToCny = n => n / 1000000;
function usageTotals(previous, usage, unknown, now, costMicro = 0) {
  const totals = previous || {tracking_started_at: now, known_requests: 0, unknown_requests: 0,
    prompt_tokens: 0, completion_tokens: 0, total_tokens: 0, confirmed_cost_micro: 0};
  if (unknown) return {...totals, unknown_requests: totals.unknown_requests + 1};
  if (!usage) return totals;
  return {...totals, known_requests: totals.known_requests + 1,
    prompt_tokens: totals.prompt_tokens + usage.prompt_tokens,
    completion_tokens: totals.completion_tokens + usage.completion_tokens,
    total_tokens: totals.total_tokens + usage.prompt_tokens + usage.completion_tokens,
    confirmed_cost_micro: totals.confirmed_cost_micro + costMicro};
}
function usageSummary(totals) {
  const {confirmed_cost_micro, ...visible} = totals;
  return {...visible, confirmed_cost_cny: microsToCny(confirmed_cost_micro),
    has_unknown_billing: totals.unknown_requests > 0};
}
function employeeConfig(config) {
  const {daily_budget_cny, usd_cny_rate, price_version, price_source, last_save_id, intent_policy, ...visible} = safeConfig(config);
  return visible;
}
function analysisForRole(data, isAdmin) {
  if (isAdmin) return data;
  const {billing, budget, validation_issue, ...visible} = data;
  return visible;
}
function budgetMetadata(value, config, now) {
  const limit = Math.round(config.daily_budget_cny * 1000000);
  const spent = value?.spent_micro || 0, reserved = value?.reserved_micro || 0;
  return {day: dayOf(now), limit_cny: microsToCny(limit), spent_cny: microsToCny(spent),
    reserved_cny: microsToCny(reserved), remaining_cny: microsToCny(Math.max(0, limit - spent - reserved))};
}
function repoFor(transaction, companyId) {
  if (!transaction?.collection) throw new AiError('AI_TRANSACTION_UNAVAILABLE', '企业 AI 事务存储尚未配置', 503);
  const ref = (type, key) => transaction.collection(COLLECTIONS[type]).doc(hash(`${companyId}\n${key}`));
  return {
    get: async (type, key) => {
      const snapshot = await ref(type, key).get();
      const value = Array.isArray(snapshot.data) ? snapshot.data[0] : snapshot.data;
      if (value && value.companyId !== companyId) throw new AiError('AI_TENANT_MISMATCH', '企业 AI 隔离检查失败', 403);
      if (!value) return null;
      const {_id, ...document} = value;
      return document;
    },
    set: (type, key, value) => {
      const {_id, ...document} = value;
      return ref(type, key).set({...document, companyId});
    }
  };
}
function createEnterpriseAi({store, companyId, environmentId, clock = Date.now, provider = createProvider(), retryDelay = ms => new Promise(r => setTimeout(r, ms)),
  requestTimeoutMs = 45000, deadlineClock = () => performance.now(), productEntitlements=createProductEntitlements({companyId,clock}),contentGeneration=null}) {
  if (!Number.isFinite(requestTimeoutMs) || requestTimeoutMs < 1 || requestTimeoutMs > 45000) throw new TypeError('AI request timeout must be between 1 and 45000 ms');
  const requestRecovery=createAiRequestRecovery({companyId,clock});
  function transact(identity, callback, requireAuth = true) {
    return store.transaction(async (state, transaction) => {
      if (!state || state.companyId !== companyId) throw new AiError('AI_TENANT_MISMATCH', '企业 AI 隔离检查失败', 403);
      const now = Math.floor(clock() / 1000);
      const session = state.sessions?.find(s => s.digest === identity.sessionDigest && s.username === identity.username && s.expires > now);
      const user = session && state.users?.find(u => u.username === identity.username && !u.disabled);
      if (requireAuth) {
        if (!user) throw new AiError('AI_AUTH_REQUIRED', '请重新登录', 401);
        if (identity.adminOnly && user.role !== 'admin') throw new AiError('AI_ADMIN_REQUIRED', '需要管理员权限', 403);
      }
      const next = structuredClone(state);
      const result = await callback(next, repoFor(transaction, companyId), user,transaction);
      return {state: next, result};
    });
  }
  async function configAction(payload, identity) {
    identity = {...identity, adminOnly: payload.operation !== 'ai_profile' || payload.connectivity_check === true};
    return transact(identity, async (state, repo, user) => {
      let config = {...defaults(), ...state.enterpriseAi};
      // Read every document before writing: CloudBase may replay the transaction callback.
      const budget = await repo.get('budget', dayOf(clock()));
      if (payload.operation === 'ai_config_save') {
        if(state.enterpriseIntentPolicy&&payload.config?.intent_policy!==undefined)
          throw new AiError('AI_CONFIG_CHANGED','公司已有发布规则，请在公司规则发布入口更新分级标准',409);
        if (payload.request_id !== undefined &&
            (typeof payload.request_id !== 'string' ||
              !/^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(payload.request_id)))
          throw new AiError('AI_INVALID_INPUT', '配置保存请求标识格式不正确');
        if (payload.expected_revision !== undefined &&
            (!Number.isSafeInteger(payload.expected_revision) || payload.expected_revision < 0))
          throw new AiError('AI_INVALID_INPUT', 'AI 配置版本格式不正确');
        if (payload.expected_revision !== undefined && payload.expected_revision !== config.revision)
          throw new AiError('AI_CONFIG_CHANGED', '企业 AI 配置已更新，请刷新后再试', 409);
        config = saveConfig(config, payload);
        state.enterpriseAi = config;
        state.audit.push({user: identity.username, operation: 'ai_config_save', time: Math.floor(clock() / 1000)});
        state.audit = state.audit.slice(-300);
      }
      config=policyConfig(state,config).config;
      const contentProfile=payload.operation==='ai_profile'?{content_generation_capability:contentCapability({settings:contentGeneration,
        config,user,productEntitlements,environmentId,companyId})}:{};
      if (user.role !== 'admin') return {config: employeeConfig(config),...contentProfile};
      return {config: safeConfig(config),...contentProfile, budget: budgetMetadata(budget, config, clock()),
        usage: {today: usageSummary(budget?.usage_totals || usageTotals(null, null, false, clock())),
          cumulative: usageSummary(state.aiUsageTotals || usageTotals(null, null, false, clock())),
          coverage: 'since_tracking_start'}};
    });
  }
  function policyConfig(state,config={...defaults(),...state.enterpriseAi}){
    if(state.enterpriseIntentPolicy&&(state.enterpriseIntentPolicy.version!==1||
      !Number.isSafeInteger(state.enterpriseIntentPolicy.revision)||state.enterpriseIntentPolicy.revision<1))
      throw new AiError('AI_POLICY_INVALID','公司发布规则存储版本无效');
    const snapshot=state.enterpriseIntentPolicy?effectiveSnapshot(state.enterpriseIntentPolicy,clock()):null;
    return {snapshot,config:snapshot?{...config,intent_policy:snapshot.criteria,
      published_policy_context:snapshot.meta,published_policy_facts:snapshot.effectiveFacts}:config};
  }
  function policyExpectation(payload,snapshot){
    if(!snapshot)return;
    const allowed=new Set(['environment_id','operation','city','area','industry','rules','post','comments','request_id','submission_id',
      'expected_revision','expected_rules_version','expected_policy_revision','expected_policy_digest','expected_effective_facts_digest']);
    if(Object.keys(payload).some(k=>!allowed.has(k)))throw new AiError('AI_INVALID_INPUT','发布规则分析参数包含未授权字段');
    if(typeof payload.request_id!=='string'||!/^[A-Za-z0-9_.:-]{8,128}$/.test(payload.request_id)||payload.request_id.startsWith('input:')||
      snapshot.meta.enabled!==true||!Number.isSafeInteger(payload.expected_policy_revision)||
      payload.expected_policy_revision!==snapshot.meta.policy_revision||
      payload.expected_policy_digest!==snapshot.meta.policy_digest||
      payload.expected_effective_facts_digest!==snapshot.meta.effective_facts_digest)
      throw new AiError('AI_CONFIG_CHANGED','公司意向规则或有效资料已变化，请先读取当前发布版本',409);
  }
  const appliedPolicy=(plan,key)=>plan.policySnapshot?{...plan.policySnapshot.meta,original_request_id:key??null}:null;
  const samePolicy=(before,after)=>!!before===!!after&&(!before||
    ['policy_revision','policy_digest','effective_facts_digest','enabled'].every(k=>before.meta[k]===after.meta[k]));
  async function currentPolicy(plan,identity){
    return transact(identity,async(state)=>!samePolicy(plan.policySnapshot,policyConfig(state).snapshot));
  }
  async function policyAction(payload,identity){
    const operation=payload.operation;
    const allowed=operation==='intent_policy_read'?['environment_id','operation']:
      operation==='intent_policy_publish_status'?['environment_id','operation','idempotency_key']:
      ['environment_id','operation','policy','expected_policy_revision','idempotency_key','source_local_revision','source_local_digest'];
    if(Object.keys(payload).some(k=>!allowed.includes(k)))throw new AiError('AI_INVALID_INPUT','公司规则参数包含未授权字段');
    if(Buffer.byteLength(JSON.stringify(payload))>350000)throw new AiError('AI_INVALID_INPUT','公司规则请求过大');
    const key=payload.idempotency_key;
    if(operation!=='intent_policy_read'&&(typeof key!=='string'||! /^[A-Za-z0-9_.:-]{8,128}$/.test(key)))
      throw new AiError('AI_INVALID_INPUT','公司规则原发布编号格式无效');
    let normalized,fingerprint;
    if(operation==='intent_policy_publish'){
      if(!Number.isSafeInteger(payload.expected_policy_revision)||payload.expected_policy_revision<0||
        payload.source_local_revision!==undefined&&(!Number.isSafeInteger(payload.source_local_revision)||payload.source_local_revision<0)||
        payload.source_local_digest!==undefined&&(typeof payload.source_local_digest!=='string'||!/^[a-f0-9]{64}$/.test(payload.source_local_digest)))
        throw new AiError('AI_INVALID_INPUT','公司规则版本或来源摘要格式无效');
      normalized=normalizePublishedPolicy(payload.policy);
      fingerprint=policyDigest({policy:normalized,expected_policy_revision:payload.expected_policy_revision,
        source_local_revision:payload.source_local_revision??null,source_local_digest:payload.source_local_digest??null});
    }
    return transact({...identity,adminOnly:operation!=='intent_policy_read'},async(state,_repo,user,transaction)=>{
      if(operation==='intent_policy_read'){
        let canPublish=user.role==='admin';
        if(canPublish)try{productEntitlements.requireFeature('strategy');}catch{canPublish=false;}
        return {summary:policyConfig(state).snapshot?.meta??null,
          can_publish:canPublish,...(user.role==='admin'&&state.enterpriseIntentPolicy?{policy:structuredClone(state.enterpriseIntentPolicy.policy)}:{})};
      }
      const ident=hash(JSON.stringify([companyId,user.username,key]));
      const receiptRef=transaction.collection(POLICY_COLLECTIONS.publications).doc(ident);
      const fetched=await receiptRef.get(),prior=Array.isArray(fetched.data)?fetched.data[0]:fetched.data;
      if(prior){
        if(prior.companyId!==companyId||prior.username!==user.username||prior.idempotency_key!==key||
          !prior.response||prior.response.publication_id!==ident)
          throw new AiError('AI_CONFIG_CHANGED','原规则发布记录范围需核对',409);
        if(operation==='intent_policy_publish'&&prior.request_digest!==fingerprint)
          throw new AiError('AI_CONFIG_CHANGED','原发布编号已用于不同内容，请核对原发布记录',409);
        return structuredClone(prior.response);
      }
      if(operation==='intent_policy_publish_status')return {state:'unknown',mutation_committed:null,read_only:true,idempotency_key:key};
      productEntitlements.requireFeature('strategy');
      const current=state.enterpriseIntentPolicy;
      if(current)effectiveSnapshot(current,clock());
      const revision=current?.revision??0;
      if(payload.expected_policy_revision!==revision)throw new AiError('AI_CONFIG_CHANGED','公司规则版本已更新，请核对后再发布',409);
      const next={version:1,revision:revision+1,policy:normalized,digest:policyDigest(normalized),
        published_at:new Date(clock()).toISOString(),published_by:user.username,publication_id:ident,publication_key:key,
        source_local_revision:payload.source_local_revision??null,source_local_digest:payload.source_local_digest??null};
      const versionRef=transaction.collection(POLICY_COLLECTIONS.versions).doc(hash(JSON.stringify([companyId,next.revision])));
      const versionSnap=await versionRef.get(),versionRow=Array.isArray(versionSnap.data)?versionSnap.data[0]:versionSnap.data;
      if(versionRow)throw new AiError('AI_CONFIG_CHANGED','公司规则历史版本已存在，请核对当前发布记录',409);
      const response={state:'succeeded',mutation_committed:true,idempotency_key:key,publication_id:ident,
        summary:effectiveSnapshot(next,clock()).meta};
      state.enterpriseIntentPolicy=next;
      await versionRef.set({...next,companyId});
      await receiptRef.set({companyId,username:user.username,idempotency_key:key,request_digest:fingerprint,
        response,created_at:clock()});
      return response;
    });
  }
  async function reserve(operation, input, identity, expectedRevision, expectedRulesVersion,requestKey,submissionId,payload) {
    const requestId = crypto.randomUUID();
    return transact(identity, async (state, repo, user,transaction) => {
      productEntitlements.requireFeature(operation==='intent_analyze'?'intent_analysis':'strategy');
      const {config, snapshot:publishedSnapshot}=policyConfig(state);
      const policySnapshot=operation==='intent_analyze'?publishedSnapshot:null;
      if(operation==='intent_analyze')policyExpectation(payload,policySnapshot);
      const contentBinding=operation==='content_generate'?authorizeContent({state,user,identity,input,companyId,settings:contentGeneration}):null;
       if (expectedRevision !== undefined) {
         if (!Number.isSafeInteger(expectedRevision) || expectedRevision < 0)
           throw new AiError('AI_INVALID_INPUT', 'AI 配置版本格式不正确');
         if (expectedRevision !== config.revision)
           throw new AiError('AI_CONFIG_CHANGED', '企业 AI 配置已更新，请刷新后再试', 409);
       }
       // Optional for older clients. When supplied, compare the effective
       // server contract and enterprise policy before cache or budget work.
       if (expectedRulesVersion !== undefined) {
         if (typeof expectedRulesVersion !== 'string' || !expectedRulesVersion || expectedRulesVersion.length > 256)
           throw new AiError('AI_INVALID_INPUT', 'AI 规则版本格式不正确');
         if (expectedRulesVersion !== effectiveRulesVersion(config))
           throw new AiError('AI_CONFIG_CHANGED', '企业 AI 规则已更新，请刷新后再试', 409);
       }
       if (!['openai', 'deepseek'].includes(config.provider))
         throw new AiError('AI_INVALID_INPUT', '企业 AI 服务商配置无效，请管理员重新保存', 503);
       const selectedProvider = config.provider;
       const catalog = selectedProvider === 'openai' ? OPENAI_MODELS : MODELS;
       // Never replace an invalid saved selection with a default, especially a dearer model.
       if (!Object.hasOwn(catalog, config.model))
         throw new AiError('AI_UNPRICED_MODEL', '企业 AI 模型配置无效，请管理员重新保存', 503);
       const selectedModel = config.model;
       if (selectedProvider === 'openai' && config.reasoning_effort != null &&
           !catalog[selectedModel].efforts.includes(config.reasoning_effort))
         throw new AiError('AI_INVALID_INPUT', '企业 AI 推理档位配置无效，请管理员重新保存', 503);
       const selectedEffort = selectedProvider === 'openai' ? reasoningEffort(config, selectedModel) : null;
       const selectedKey = apiKeyFor(config, selectedProvider);
       const now = clock(), day = dayOf(now), price = tariff(selectedModel, now, config);
       const contextHash = contentBinding?contentContextHash(companyId,input,config,selectedEffort,contentBinding):hash(JSON.stringify({companyId, operation, provider: selectedProvider, model: selectedModel,
         reasoning_effort: selectedEffort, usd_cny_rate: config.usd_cny_rate, rules_version: effectiveRulesVersion(config),
        schema_version: RULES_VERSION, revision: config.revision, input}));
      const cache = await repo.get('cache', contextHash);
      const budget = await repo.get('budget', day) || {day, spent_micro: 0, reserved_micro: 0, request_count: 0};
      // Older callers have no explicit request ID. Retry only a server ledger
      // that proves the previous attempt unbilled; unknown attempts keep their
      // original key across crashes, cache expiry and service-period changes.
      let quotaKey=requestKey??cache?.product_quota_key??contextHash;
      if(requestKey===undefined&&cache?.request_id&&cache.status!=='ready'){
        const prior=await repo.get('ledger',cache.request_id);
        if(prior?.context_hash===contextHash&&prior.status==='unbilled'&&prior.reservation_retained===false&&
          typeof cache.request_id==='string'&&/^[a-f0-9-]{36}$/i.test(cache.request_id))
          quotaKey=contextHash+':'+cache.request_id;
      }
      const legacyLedger=cache?.request_id?await repo.get('ledger',cache.request_id):null;
      const recovery=await requestRecovery.inspect({transaction,user,operation,key:quotaKey,
        inputHash:contentBinding?contentInputHash(input,companyId):hash(JSON.stringify({companyId,operation,input})),contextHash,cache,legacyLedger,readLedger:id=>repo.get('ledger',id)});
      const recoverySnapshot={revision:config.revision,rules_version:effectiveRulesVersion(config),provider:selectedProvider,
        model:selectedModel,reasoning_effort:selectedEffort};
      // Return a sentinel from this same authenticated transaction: throwing
      // after a proof would roll it back; an outer catch cannot prove that an
      // original key had no earlier execution. No index or money writes here.
      const refuse=error=>({refused:true,error:{code:error.code,message:error.message,status:error.status},
        rejectionReceipt:requestKey!==undefined?requestRecovery.rejectionReceipt({plan:recovery,user,environmentId,
          submissionId,cache,legacyLedger,snapshot:recoverySnapshot}):null});
      if (!config.enabled || !selectedKey)
        return refuse(new AiError('AI_NOT_CONFIGURED', '请联系管理员启用企业 AI', 503));
      if (cache?.status === 'ready' && cache.expires_at > now) {
         await productEntitlements.reserve({transaction,user,operation,key:quotaKey,inputHash:contextHash,
           providerRequestId:requestId,amount:input.comments?.length||1,cached:true});
         await requestRecovery.begin({transaction,user,plan:recovery,providerRequestId:requestId,cache,snapshot:recoverySnapshot});
         return {cached: true, isAdmin: user.role === 'admin', output: cache.output, provider: selectedProvider, model: cache.actual_model || selectedModel,
           configured_model: selectedModel, reasoning_effort: selectedEffort, rules_version: effectiveRulesVersion(config),
          budget: budgetMetadata(budget, config, now),policySnapshot,
          ...(contentBinding?{contentBinding,contentInput:input,config,contextHash,operation}: {})};
      }
      if (cache?.status === 'in_flight' && cache.expires_at > now) {
        throw new AiError('AI_IN_PROGRESS', '同一内容正在分析，请稍后读取', 409);
      }
      const messages = contentBinding?contentMessages(input):prompt(operation, input, config);
      const maxTokens = contentBinding?contentMaxTokens(input):operation === 'keyword_suggest' ? Math.min(16384, Math.max(2048, input.count * 128)) : Math.min(16384, 1024 + input.comments.length * 256);
       const reservation = reservationMicro(messages, maxTokens, selectedModel, config);
      const limit = Math.round(config.daily_budget_cny * 1000000);
      if (budget.spent_micro + budget.reserved_micro + reservation.micro > limit) {
        return refuse(new AiError('AI_DAILY_BUDGET', '企业今日 AI 预算不足，请明日再试或由管理员调整预算', 429));
      }
      const ledger = {request_id: requestId, operation, day, username: identity.username, context_hash: contextHash,
         provider: selectedProvider, model: selectedModel, configured_model: selectedModel, reasoning_effort: selectedEffort,
         rules_version: effectiveRulesVersion(config), schema_version: RULES_VERSION,
         price_version: price.price_version, price_window: price.window, usd_cny_rate: price.usd_cny_rate || null,
         price_per_million: {hit: price.hit, miss: price.miss, write: price.write || price.miss, output: price.output}, reserved_micro: reservation.micro,
        prompt_bound: reservation.prompt_bound, max_tokens: maxTokens, status: 'reserved', created_at: now, attempts: [],
        ...(policySnapshot?{applied_policy:policySnapshot.meta}:{}),
        ...(contentBinding?{content_binding_stamp:contentBinding.stamp,content_task_id:input.task_id,
          content_method_digest:input.method_digest,content_input_digest:input.input_digest,content_scope:input.scope}:{})};
      let productQuota;
      try{productQuota=await productEntitlements.reserve({transaction,user,operation,key:quotaKey,inputHash:contextHash,
        providerRequestId:requestId,amount:input.comments?.length||1});}
      catch(error){if(error instanceof AiError&&error.code==='PRODUCT_ANALYSIS_LIMIT')return refuse(error);throw error;}
      const recoveryPlan=await requestRecovery.begin({transaction,user,plan:recovery,providerRequestId:requestId,snapshot:recoverySnapshot});
      await repo.set('budget', day, {...budget, reserved_micro: budget.reserved_micro + reservation.micro, request_count: budget.request_count + 1});
      await repo.set('ledger', requestId, ledger);
       await repo.set('cache', contextHash, {status: 'in_flight', request_id: requestId, provider: selectedProvider,
         model: selectedModel, rules_version: effectiveRulesVersion(config),product_quota_key:quotaKey,
         expires_at:Math.min(now+120000,policySnapshot?.nextBoundaryMs??Infinity)});
       return {requestId, day, contextHash, operation, apiKey: selectedKey, provider: selectedProvider, model: selectedModel,
         isAdmin: user.role === 'admin',
         reasoningEffort: selectedEffort, config, messages, maxTokens, price, reservation,productQuota,recoveryPlan,policySnapshot,
         ...(contentBinding?{contentBinding,contentInput:input}: {})};
    });
  }
  async function markAttempt(plan, identity, attempt) {
    return transact(identity, async (state, repo,_user,transaction) => {
      productEntitlements.requireFeature(plan.operation==='intent_analyze'?'intent_analysis':'strategy');
      if(plan.operation==='intent_analyze'&&!samePolicy(plan.policySnapshot,policyConfig(state).snapshot))
        throw new AiError('AI_CONFIG_CHANGED','公司规则或资料有效期已变化，原请求保留待核对',409);
      if(plan.contentBinding&&!contentContextCurrent({state,user:_user,identity,plan,companyId,settings:contentGeneration,config:policyConfig(state).config}))
        throw new AiError('AI_CONTENT_CONTEXT_CHANGED','生成前账号、门店、规则或配置已变化，未重新派发',409);
      const ledger = await repo.get('ledger', plan.requestId);
      const indexed=await requestRecovery.loadPlan({transaction,plan:plan.recoveryPlan});
      if (!ledger || ledger.status !== 'reserved') throw new AiError('AI_LEDGER_CONFLICT', 'AI 请求状态异常，请稍后再试', 503);
      await repo.set('ledger', plan.requestId, {...ledger, attempts: [...ledger.attempts, {attempt, started_at: clock()}]});
      await requestRecovery.mark({transaction,plan:plan.recoveryPlan,row:indexed});
    });
  }
  async function settle(plan, identity, {usage = null, output = null, errorCode = '', knownUnbilled = false, httpStatus = 0, validationIssue = null}) {
    // Settlement survives logout/revocation so a completed bill can never lose its accounting.
    return transact(identity, async (state, repo,_user,transaction) => {
      const ledger = await repo.get('ledger', plan.requestId);
      const budget = await repo.get('budget', plan.day);
      const cache = await repo.get('cache', plan.contextHash);
      const indexed=await requestRecovery.loadPlan({transaction,plan:plan.recoveryPlan});
      if (!ledger || !budget) throw new AiError('AI_LEDGER_CONFLICT', 'AI 用量记录暂时无法核对', 503);
      if (ledger.status !== 'reserved') return ledger;
      let contentResultAllowed=true;
      if(plan.contentBinding&&output)try{
        productEntitlements.requireFeature('strategy');
        contentResultAllowed=contentContextCurrent({state,user:_user,identity,plan,companyId,settings:contentGeneration,config:policyConfig(state).config});
      }catch{contentResultAllowed=false;}
      if(plan.contentBinding&&output&&!contentResultAllowed){
        // Money still settles after revocation; the private candidate never becomes reusable.
        output=null;errorCode='AI_CONTENT_CONTEXT_CHANGED';validationIssue='content_context_changed';
      }
      const actual = usage ? actualMicro(usage, plan.price) : null;
      // Usage outside our token bound indicates a changed provider contract; keep the full
      // reservation and record the overrun rather than silently understating consumption.
      const withinBound = usage && usage.prompt_tokens <= plan.reservation.prompt_bound && usage.completion_tokens <= plan.maxTokens;
      const unknown = !knownUnbilled && (!usage || !withinBound);
      const status = unknown ? 'billing_unknown' : knownUnbilled ? 'unbilled' : output ? 'settled' : 'invalid_output';
      const updated = {...ledger, status, completed_at: clock(), usage, actual_cost_micro: actual,
        error_code: errorCode || (unknown ? 'AI_BILLING_UNKNOWN' : ''), http_status: httpStatus,
        validation_issue: validationIssue,
        reservation_retained: !!unknown};
      await productEntitlements.settle({transaction,plan:plan.productQuota,outcome:unknown?'unknown':knownUnbilled?'released':'confirmed'});
      if (!unknown) await repo.set('budget', plan.day, {...budget,
        reserved_micro: Math.max(0, budget.reserved_micro - ledger.reserved_micro), spent_micro: budget.spent_micro + (actual || 0),
        usage_totals: usageTotals(budget.usage_totals, usage, false, clock(), actual || 0)});
      // A verified overrun is still a known liability in addition to the retained reserve.
      if (usage && !withinBound) await repo.set('budget', plan.day, {...budget,
        spent_micro: budget.spent_micro + Math.max(0, actual - ledger.reserved_micro),
        usage_totals: usageTotals(budget.usage_totals, null, true, clock())});
      if (unknown && (!usage || withinBound)) await repo.set('budget', plan.day, {...budget,
        usage_totals: usageTotals(budget.usage_totals, null, true, clock())});
      state.aiUsageTotals = usageTotals(state.aiUsageTotals, unknown ? null : usage, unknown, clock(), unknown ? 0 : actual || 0);
      await repo.set('ledger', plan.requestId, updated);
      if (cache?.request_id === plan.requestId) await repo.set('cache', plan.contextHash, output && !unknown
         ? {status: 'ready', request_id: plan.requestId,product_quota_key:cache.product_quota_key, output, provider: plan.provider, model: plan.model,
             actual_model: usage?.response_model || plan.model,
            rules_version: effectiveRulesVersion(plan.config), schema_version: RULES_VERSION,
            ...(plan.policySnapshot?{applied_policy:plan.policySnapshot.meta}:{}),
            expires_at:Math.min(clock()+24*3600000,plan.policySnapshot?.nextBoundaryMs??Infinity)}
        : {status: 'failed', request_id: plan.requestId,product_quota_key:cache.product_quota_key, error_code: updated.error_code, expires_at: clock()});
      await requestRecovery.finish({transaction,plan:plan.recoveryPlan,row:indexed,ledger:updated,hasOutput:!!output&&!unknown});
      return updated;
    }, false);
  }
  const contentGateway=createContentGateway({transact,policyConfig,reserve,markAttempt,settle,requestRecovery,
    provider,companyId,environmentId,contentGeneration,productEntitlements});
  async function handle(payload, identity) {
    // The same monotonic deadline includes reservation, attempt bookkeeping and
    // a possible 429 backoff; a retry never receives a fresh 45-second timer.
    const deadline = deadlineClock() + requestTimeoutMs;
    const remaining = () => Math.max(0, Math.floor(deadline - deadlineClock()));
    let plan;
    try {
      if(payload.operation==='content_generate'||payload.operation==='content_generate_status')
        return await contentGateway.handle(payload,identity,remaining);
      if(payload.operation==='ai_attempt_status'){
        if(payload.operation_kind==='content_generate')
          throw new AiError('AI_CONTENT_STATUS_SCOPE_REQUIRED','内容生成须按原任务的账号、门店和资料范围核对',400);
        if(Object.keys(payload).some(key=>!['environment_id','operation','operation_kind','request_id'].includes(key)))
          throw new AiError('AI_INVALID_INPUT','原AI请求核对参数包含未授权字段');
        const data=await transact(identity,async(state,repo,user,transaction)=>{
          const {config}=policyConfig(state);
          let resultPermission=true;
          try{productEntitlements.requireFeature(payload.operation_kind==='intent_analyze'?'intent_analysis':'strategy');}
          catch{resultPermission=false;}
          return requestRecovery.status({transaction,user,operation:payload.operation_kind,key:payload.request_id,
            readLedger:id=>repo.get('ledger',id),readCache:key=>repo.get('cache',key),
            currentRevision:config.revision,currentRulesVersion:effectiveRulesVersion(config),resultPermission});
        });
        return {status:200,data};
      }
      if(payload.operation.startsWith('intent_policy_'))return {status:200,data:await policyAction(payload,identity)};
      if (payload.operation.startsWith('ai_config_') || payload.operation === 'ai_profile') {
        if(payload.operation==='ai_profile'&&Object.keys(payload).some(key=>!['environment_id','operation','connectivity_check'].includes(key)))
          throw new AiError('AI_INVALID_INPUT','AI状态查询不接受客户端租户、模型或权限参数',400);
        if (payload.operation === 'ai_profile' && payload.connectivity_check !== undefined &&
            typeof payload.connectivity_check !== 'boolean')
          throw new AiError('AI_INVALID_INPUT', '连通性检查参数无效');
        const profile = await configAction(payload, identity);
        if (payload.operation !== 'ai_profile' || payload.connectivity_check !== true)
          return {status: 200, data: payload.operation==='ai_profile'?{...profile,read_only:true,mutation_committed:false,auto_retry:false}:profile};
        // Authorization is checked by the CloudBase transaction above. Never
        // make a network call in a transaction callback, which may be replayed.
        let observed;
        try { observed = await provider.checkConnectivity?.(); } catch {}
        const reachability = ['reachable','unreachable','timeout'].includes(observed?.reachability)
          ? observed.reachability : 'unreachable';
        const status = Number.isInteger(observed?.http_status) && observed.http_status >= 100 && observed.http_status <= 599
          ? observed.http_status : 0;
        const allowedCauses = new Set(['ENOTFOUND','EAI_AGAIN','ETIMEDOUT','ECONNREFUSED','ECONNRESET',
          'ENETUNREACH','EHOSTUNREACH','UND_ERR_CONNECT_TIMEOUT','CERT_HAS_EXPIRED',
          'UNABLE_TO_VERIFY_LEAF_SIGNATURE','TIMEOUT','BODY_LIMIT','NETWORK_OTHER']);
        const suppliedCode = observed?.error?.cause?.code;
        const causeCode = allowedCauses.has(suppliedCode) ? suppliedCode : 'NETWORK_OTHER';
        const connectivity = {reachability, http_status:status,
          error:reachability === 'reachable' && observed?.error == null ? null : {cause:{code:causeCode}}};
        // A session revoked during the probe must not receive the admin result.
        await transact({...identity, adminOnly:true}, async () => null);
        return {status:200, data:{...profile, connectivity}};
      }
      if(payload.submission_id!==undefined&&(typeof payload.submission_id!=='string'||
        !/^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(payload.submission_id)||
        typeof payload.request_id!=='string'))throw new AiError('AI_INVALID_INPUT','本次分析提交标识格式不正确');
      const {submission_id:submissionId,...modelPayload}=payload;
      const input = normalizeInput(payload.operation, modelPayload);
       plan = await reserve(payload.operation, input, identity, payload.expected_revision, payload.expected_rules_version,payload.request_id,submissionId,payload);
      if(plan.refused)return {status:plan.error.status,data:{code:plan.error.code,error:plan.error.message,ai_status:'pending',
        ...(plan.rejectionReceipt?{rejection_receipt:plan.rejectionReceipt}:{})}};
      if (plan.cached) return {status: 200, data: analysisForRole({...plan.output, count: plan.output.keywords?.length || plan.output.results?.length,
         source: 'cloud_ai', provider: plan.provider, model: plan.model, configured_model: plan.configured_model,
         reasoning_effort: plan.reasoning_effort, rules_version: plan.rules_version, cache_hit: true,
         ...(plan.policySnapshot?{applied_policy:appliedPolicy(plan,payload.request_id),policy_revalidation_required:await currentPolicy(plan,identity)}:{}),
        billing: {status: 'cache_hit', actual_cost_cny: 0}, budget: plan.budget}, plan.isAdmin)};
      let response, providerError;
      for (let attempt = 1; attempt <= 2; attempt++) {
        if (!remaining()) { providerError = new ProviderError('AI_PROVIDER_TIMEOUT', {knownUnbilled: true}); break; }
        await markAttempt(plan, identity, attempt);
        const timeoutMs = remaining();
        if (!timeoutMs) { providerError = new ProviderError('AI_PROVIDER_TIMEOUT', {knownUnbilled: true}); break; }
        try {
           response = await provider({provider: plan.provider, apiKey: plan.apiKey, model: plan.model,
             reasoningEffort: plan.reasoningEffort, messages: plan.messages,
            maxTokens: plan.maxTokens, tenantId: hash(companyId), timeoutMs});
          providerError = null; break;
        } catch (error) {
          providerError = error instanceof ProviderError ? error : new ProviderError('AI_PROVIDER_UNAVAILABLE');
          if (!(providerError.knownUnbilled && providerError.retryable && attempt < 2)) break;
          if (remaining() <= 250) { providerError = new ProviderError('AI_PROVIDER_TIMEOUT', {knownUnbilled: true}); break; }
          await retryDelay(250);
        }
      }
      if (providerError) {
        const ledger = await settle(plan, identity, {errorCode: providerError.code, knownUnbilled: providerError.knownUnbilled, httpStatus: providerError.httpStatus});
        const isAdmin = await transact(identity, async (_state, _repo, user) => user.role === 'admin');
         const providerLabel = plan.provider === 'openai' ? 'OpenAI' : 'DeepSeek';
         const message = providerError.code === 'AI_PROVIDER_BALANCE' ? `企业 ${providerLabel} API 余额不足，请管理员检查后点继续分析`
           : providerError.code === 'AI_PROVIDER_AUTH' ? `企业 ${providerLabel} API 密钥无效，请管理员检查后点继续分析`
          : '企业 AI 暂时不可用，评论保持待分析，请稍后再试';
         return {status: 502, data: analysisForRole({code: providerError.code, error: message, ai_status: 'pending',
           provider: plan.provider, configured_model: plan.model, reasoning_effort: plan.reasoningEffort,
          billing: {status: ledger.status, reservation_retained: ledger.reservation_retained, request_id: plan.requestId}}, isAdmin)};
      }
       const usage = usageOf(response, plan.model);
      let output, validationError;
      try {
        if (!usage) throw new AiError('AI_BILLING_UNKNOWN', 'AI 用量返回不完整，暂未完成分析', 502);
        const choice = response?.choices?.[0];
        if (choice?.finish_reason !== 'stop' || typeof choice?.message?.content !== 'string') {
          const error = new AiError('AI_INVALID_OUTPUT', 'AI 返回不完整，暂未完成分析', 502);
          error.validation_issue = choice?.finish_reason !== 'stop' ? 'response_incomplete' : 'response_content_type';
          throw error;
        }
        let parsed;
        try { parsed = JSON.parse(choice.message.content); } catch {
          const error = new AiError('AI_INVALID_OUTPUT', 'AI 返回格式不正确，暂未完成分析', 502);
          error.validation_issue = 'response_json_parse'; throw error;
        }
         const secrets = [plan.apiKey, apiKeyFor(plan.config, 'deepseek'), apiKeyFor(plan.config, 'openai')];
         output = payload.operation === 'intent_analyze'
           ? validateIntentBatchSafe(parsed, input, secrets)
           : validateOutput(payload.operation, parsed, input, secrets);
      } catch (error) { validationError = error instanceof AiError ? error : new AiError('AI_INVALID_OUTPUT', 'AI 返回内容未通过校验', 502); }
      const ledger = await settle(plan, identity, {usage, output, errorCode: validationError?.code || '', validationIssue: validationError?.validation_issue || null});
      const isAdmin = await transact(identity, async (_state, _repo, user) => user.role === 'admin');
      if (validationError || ledger.reservation_retained) return {status: 502, data: analysisForRole({code: validationError?.code || 'AI_BILLING_UNKNOWN',
        error: validationError?.message || 'AI 用量无法核对，暂未完成分析', ai_status: 'pending',
         validation_issue: validationError?.validation_issue || null,
         provider: plan.provider, model: usage?.response_model || null, configured_model: plan.model,
         reasoning_effort: plan.reasoningEffort,
        billing: {status: ledger.status, reservation_retained: ledger.reservation_retained, request_id: plan.requestId}}, isAdmin)};
      // Recheck the session before returning private analysis after a long network call.
      return {status: 200, data: analysisForRole({...output, count: output.keywords?.length || output.results?.length, source: 'cloud_ai',
         provider: plan.provider, model: usage.response_model || plan.model, configured_model: plan.model,
         reasoning_effort: plan.reasoningEffort, rules_version: effectiveRulesVersion(plan.config), cache_hit: false,
         ...(plan.policySnapshot?{applied_policy:appliedPolicy(plan,payload.request_id),policy_revalidation_required:await currentPolicy(plan,identity)}:{}),
        billing: {status: ledger.status, request_id: plan.requestId, actual_cost_cny: microsToCny(ledger.actual_cost_micro),
          usage: ledger.usage, price_version: ledger.price_version, price_window: ledger.price_window}}, isAdmin)};
    } catch (error) {
      // Errors before/after a network call are safe metadata only. No raw exception text.
      const e = error?.code==='AI_POLICY_INVALID'?new AiError('AI_POLICY_INVALID','公司意向规则或公寓资料格式无效，请核对字段、来源和有效期'):
        error instanceof AiError ? error : plan && !plan.cached
        ? new AiError('AI_LEDGER_CONFLICT', '企业 AI 账本状态待核对，请管理员检查', 503)
        : new AiError('AI_SERVICE_UNAVAILABLE', '企业 AI 服务暂时不可用，请稍后再试', 503);
       return {status: e.status, data: {code: e.code, error: e.message, ai_status: 'pending',
         ...(plan && !plan.cached ? {provider: plan.provider, configured_model: plan.model,
           reasoning_effort: plan.reasoningEffort} : {})}};
    }
  }
  return {handle};
}
module.exports = {createEnterpriseAi, OPERATIONS, COLLECTIONS, POLICY_COLLECTIONS, budgetMetadata, repoFor};
