"""Fresh read-only original SDK code check. No configuration or private state reads."""
from pathlib import Path
import importlib.util,json
D=Path(__file__).resolve().parent
baseline=json.loads((D.parent/'content-cloud-v3-final2/DEPLOYMENT-READBACK.json').read_text('utf-8-sig'))
assert baseline['status']=='DEPLOYED_EXACT_FULL_READBACK'
assert baseline['treeSha256']=='744ec24509d6602618543d6c760130de1d7b45a0acc05be89aa09592a03c5a02'
spec=importlib.util.spec_from_file_location('original_readonly_cloud_code_check',D.parent/'content-cloud-v3-delivery/tools/check_live_code_readonly.py')
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
module.ROOT=D
module.EXPECTED=baseline['codeZipSha256']
module.main()
