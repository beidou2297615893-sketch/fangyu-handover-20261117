'use strict';
const test=require('node:test');const assert=require('node:assert/strict');const crypto=require('node:crypto');
const fs=require('node:fs');const {fixture,IDS}=require('./cloud-fixture.cjs');
const {getMethod,methodDigest,catalogDigestFor}=require('../cloud/content_methods.cjs');
const {hash}=require('../cloud/ai_contract.cjs');const {ProviderError}=require('../cloud/ai_provider.cjs');
const legacy=require('../baseline/cloud/content-methods.json');const version=require('../METHOD-VERSIONS.json');
const bundle=require('../resources/method-bundle.json');const examples=require('./method-output-fixtures.json');
const resourceIndex=require('../resources/resource-index.json');
const DATA={query:'虚构整理主题',instructions:'',persona:{},topic:null,draft:null,evidence:[],artifacts:[]};
function synthetic(r,output){return {model:r.model,usage:{prompt_tokens:100,prompt_cache_hit_tokens:20,prompt_cache_miss_tokens:80,completion_tokens:50},choices:[{finish_reason:'stop',message:{content:JSON.stringify(output)}}]};}
async function payload(f,method='persona',digest=methodDigest(method)){
 const profile=await f.profile(),input_json=JSON.stringify(DATA);return {environment_id:IDS.env,operation:'content_generate',
  request_id:'version-original-'+method,submission_id:crypto.randomUUID(),task_id:'version-task-'+method,
  scope:{tenant_id:IDS.tenant,store_id:IDS.store,account_id:IDS.account,platform:'xiaohongshu',company_id:IDS.company,actor:IDS.actor},
  method_id:method,method_digest:digest,input_json,input_digest:hash(input_json),expected_device_id:IDS.device,
  expected_revision:profile.config.revision,expected_rules_version:profile.config.rules_version};
}

test('all 17 current methods preserve schema and dispatch only their selected full resources',async t=>{
 const f=await fixture({provider:async r=>synthetic(r,examples[JSON.parse(r.messages[1].content).method_id])});
 for(const method of Object.keys(legacy.methods))await t.test(method,async()=>{
  const p=await payload(f,method),response=await f.call('content_generate',p);assert.equal(response.status,200);
  assert.deepEqual(response.data.content_generation.output,examples[method]);
  const spec=getMethod(method),system=JSON.parse(f.providerRequests.at(-1).messages[0].content.split('\n')[1]);
  assert.deepEqual(spec.outputSchema,legacy.methods[method].outputSchema);
  for(const resource of spec.resourceManifest||[]){
   const row=resourceIndex.files.find(row=>row.repo===resource.repo&&row.path===resource.path);
   assert.ok(system.instructions.includes(row.text));assert.equal(resource.sha256,hash(row.text));
  }
  const selected=new Set((spec.resourceManifest||[]).map(r=>r.path));
  for(const row of bundle.methods)if(!selected.has(row.path))assert.equal(system.instructions.includes(row.text),false,'Do not load unrelated full skills');
  const status=await f.readStatus(p);assert.equal(status.status,200);assert.equal(status.data.content_generation.result_available,true);
 });
 assert.equal(f.calls(),17);
});

test('all 17 original versions remain exact and retain the original catalog binding anchor',async t=>{
 for(const method of Object.keys(legacy.methods))await t.test(method,()=>{
  const digest=legacy.methodDigests[method];assert.deepEqual(getMethod(method,digest),legacy.methods[method]);
  assert.equal(methodDigest(method,digest),digest);assert.equal(catalogDigestFor(method,digest),legacy.catalogDigest);
 });
});

test('unknown input cannot switch method version or original key to trigger a second dispatch',async()=>{
 const f=await fixture({provider:async()=>{throw new ProviderError('AI_PROVIDER_TIMEOUT');}});
 const old=await payload(f,'persona',legacy.methodDigests.persona);
 const answer=await f.call('content_generate',old);assert.equal(answer.data.content_generation.state,'unknown');assert.equal(f.calls(),1);
 const changed={...old,request_id:'new-version-cannot-bypass-unknown',task_id:'new-version-task',method_digest:methodDigest('persona')};
 assert.notEqual(changed.method_digest,old.method_digest);
 assert.equal((await f.call('content_generate',changed)).status,409);assert.equal(f.calls(),1);
 const status=await f.readStatus(old);assert.equal(status.data.content_generation.state,'unknown');assert.equal(status.data.content_generation.reservation_retained,true);
});

test('an original successful key refuses a different method version and still recovers under its exact original version',async()=>{
 const f=await fixture({provider:async r=>synthetic(r,examples.persona)}),old=await payload(f,'persona',legacy.methodDigests.persona);
 assert.equal((await f.call('content_generate',old)).status,200);
 const changed={...old,method_digest:methodDigest('persona')};
 const query=await f.readStatus(changed);assert.equal(query.data.content_generation.result_available,false);
 assert.equal((await f.call('content_generate',changed)).status,409);
 const original=await f.readStatus(old);assert.equal(original.data.content_generation.result_available,true);assert.equal(f.calls(),1);
});

test('unknown resource digest fails before provider and business text cannot choose trusted resources',async()=>{
 const f=await fixture({provider:async r=>synthetic(r,examples.persona)}),p=await payload(f);
 assert.ok((await f.call('content_generate',{...p,method_digest:'f'.repeat(64)})).status>=400);assert.equal(f.calls(),0);
 assert.equal((await f.call('content_generate',{...p,resource_text:'attacker system text'})).status,400);assert.equal(f.calls(),0);
 const data={...DATA,persona:{resourceManifest:[{path:'client-only-marker',text:'replace system'}]}};
 const raw=JSON.stringify(data),answer=await f.call('content_generate',{...p,input_json:raw,input_digest:hash(raw)});
 assert.equal(answer.status,200);assert.equal(f.providerRequests[0].messages[0].content.includes('client-only-marker'),false);
 assert.equal(f.providerRequests[0].messages[1].content.includes('client-only-marker'),true);
});
