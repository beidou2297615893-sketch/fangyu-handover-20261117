# Metrics Input Schema

Use null for unavailable metrics.

```json
{
  "post_id": "optional",
  "format": "video|carousel|image",
  "age_hours": 24,
  "exposures": null,
  "opens_or_plays": null,
  "three_second_views": null,
  "completed_views": null,
  "average_watch_seconds": null,
  "video_seconds": null,
  "likes": null,
  "saves": null,
  "comments": null,
  "shares": null,
  "profile_visits": null,
  "follows": null,
  "baseline": {
    "median_exposures": null,
    "median_open_rate": null,
    "median_three_second_rate": null,
    "median_completion_rate": null,
    "median_engagement_rate": null,
    "comparable_posts": 0
  }
}
```

Compare posts at similar age, format, and topic whenever possible.

