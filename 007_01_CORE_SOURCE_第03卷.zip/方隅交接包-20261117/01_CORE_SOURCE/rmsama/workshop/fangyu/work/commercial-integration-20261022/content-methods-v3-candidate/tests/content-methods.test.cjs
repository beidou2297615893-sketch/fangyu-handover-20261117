'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const vm = require('node:vm');
const { getMethod, methodDigest, validateContentOutput, CATALOG_DIGEST } = require('../cloud/content_methods.cjs');
const oracle = JSON.parse(fs.readFileSync(path.join(__dirname, '../work/methods-python-oracle.json'), 'utf8'));
const IDS = ['strategy', 'persona', 'homepage', 'research', 'topics', 'columns', 'writing',
  'video', 'visual', 'knowledge', 'revision', 'audit', 'package', 'scheduling', 'engagement', 'growth', 'learning'];

test('all seventeen full schemas and canonical Python digests are trusted detached specifications', () => {
  assert.equal(oracle.testOnly, true);
  assert.equal(oracle.productionDefaultOutput, false);
  assert.equal(Object.keys(oracle.methodDigests).length, 17);
  for (const id of IDS) {
    const spec = getMethod(id);
    assert.equal(spec.id, id);
    assert.equal(spec.module, id);
    assert.equal(spec.requiresHumanReview, true);
    assert.deepEqual(spec.outputSchema.required, ['summary', 'facts', 'hypotheses', 'artifact']);
    assert.equal(spec.outputSchema.additionalProperties, false);
    assert.equal(methodDigest(id), oracle.methodDigests[id]);
    spec.instructions = 'untrusted override';
    spec.outputSchema.properties.summary.maxLength = 0;
    assert.notEqual(getMethod(id).instructions, 'untrusted override');
    assert.equal(getMethod(id).outputSchema.properties.summary.maxLength, 2000);
  }
  // Literal independent pins include the growth schema's Python float encoding.
  assert.equal(methodDigest('writing','ac510d276be39c9d58b31364161c36019eb4665379536e12313fc8060f31b1e5'), 'ac510d276be39c9d58b31364161c36019eb4665379536e12313fc8060f31b1e5');
  assert.equal(methodDigest('growth','0385a6da1aa555c22c23f0663a579fc5c530fbb9fcc8ba9f293445068fd113ac'), '0385a6da1aa555c22c23f0663a579fc5c530fbb9fcc8ba9f293445068fd113ac');
  for (const id of ['toString', '__proto__', 'constructor', '', null, 1]) assert.throws(() => getMethod(id));
});

for (const row of oracle.cases) {
  test('matches pinned Python validation: ' + row.name.replace(/[\r\n]/g, '_'), () => {
    if (row.acceptedByPython) assert.deepEqual(validateContentOutput(row.methodId, row.output, row.evidence), row.output);
    else assert.throws(() => validateContentOutput(row.methodId, row.output, row.evidence));
  });
}

test('injected system, provider, schema, approval and send fields are rejected at all output levels', () => {
  const base = oracle.cases.find(v => v.name === 'valid-writing').output;
  for (const key of ['system', 'systemPrompt', 'endpoint', 'model', 'apiKey', 'outputSchema', 'approved', 'sent']) {
    for (const placement of ['root', 'artifact', 'fact']) {
      const value = structuredClone(base);
      if (placement === 'fact') value.facts = [{ quote: '原文', evidenceId: 'source', [key]: 'injected' }];
      else (placement === 'root' ? value : value.artifact)[key] = 'injected';
      assert.throws(() => validateContentOutput('writing', value, { source: { text: '原文', kind: 'fact' } }));
    }
  }
});

test('catalog file tampering is rejected at module load before exposing a method', () => {
  const filename = path.join(__dirname, '../cloud/content_methods.cjs');
  const code = fs.readFileSync(filename, 'utf8');
  const bytes = fs.readFileSync(path.join(__dirname, '../cloud/content-methods.json'));
  assert.equal(crypto.createHash('sha256').update(bytes).digest('hex'), '9a5dce493758bae88bcbf4e747807790e4505fb77f45f438e1363cf45a00bfdd');
  const tampered = Buffer.from(bytes.toString('utf8').replace('不得编造经历', '允许编造经历'));
  const context = { module: { exports: {} }, __dirname: path.dirname(filename),
    require(name) { return name === 'node:fs' ? { readFileSync() { return tampered; } } : require(name); } };
  assert.throws(() => vm.runInNewContext(code, context, { filename }), error => error.code === 'CONTENT_METHOD_CATALOG_CHANGED');
});

test('non-JSON descriptors, symbols and array properties cannot execute or hide fields', () => {
  const base = oracle.cases.find(v => v.name === 'valid-writing').output;
  let reads = 0;
  const accessor = structuredClone(base);
  Object.defineProperty(accessor.artifact, 'body', { enumerable: true, get() { reads++; return 'getter-content'; } });
  assert.throws(() => validateContentOutput('writing', accessor, {}));
  assert.equal(reads, 0);
  const hidden = structuredClone(base);
  Object.defineProperty(hidden.artifact, 'apiKey', { enumerable: false, value: 'hidden-injection' });
  assert.throws(() => validateContentOutput('writing', hidden, {}));
  const symbol = structuredClone(base);
  symbol.artifact[Symbol('system')] = 'hidden-injection';
  assert.throws(() => validateContentOutput('writing', symbol, {}));
  const richArray = structuredClone(base);
  richArray.artifact.tags.extra = 'hidden-injection';
  assert.throws(() => validateContentOutput('writing', richArray, {}));
});

test('evidence records are data properties and prototype names do not invent evidence', () => {
  const base = structuredClone(oracle.cases.find(v => v.name === 'valid-writing').output);
  let reads = 0;
  const evidence = {};
  Object.defineProperty(evidence, 'source', { enumerable: true, get() { reads++; return { text: '原文', kind: 'fact' }; } });
  assert.throws(() => validateContentOutput('writing', base, evidence));
  assert.equal(reads, 0);
  base.facts = [{ quote: '原文', evidenceId: 'toString' }];
  assert.throws(() => validateContentOutput('writing', base, {}));
  base.facts = [{ quote: '原文', evidenceId: '__proto__' }];
  const realOwnSource = JSON.parse('{"__proto__":{"text":"原文","kind":"fact"}}');
  assert.deepEqual(validateContentOutput('writing', base, realOwnSource).facts, base.facts);
});

test('proxy values are not accepted as parsed JSON and are rejected before invoking traps', () => {
  const base = structuredClone(oracle.cases.find(v => v.name === 'valid-writing').output);
  let reads = 0;
  const proxy = new Proxy(base, { get(target, key, receiver) { reads++; return Reflect.get(target, key, receiver); } });
  assert.throws(() => validateContentOutput('writing', proxy, {}));
  assert.equal(reads, 0);
});

test('non-finite numbers, booleans, fractions, BigInt and non-JSON collections are rejected', () => {
  const sample = id => structuredClone(oracle.cases.find(v => v.name === 'valid-' + id).output);
  for (const value of [NaN, Infinity, -Infinity, true, 1000000000001, 1n, new Number(1)]) {
    const output = sample('growth');
    output.artifact.metrics = [{ metric: '测试', current: value, target: 1 }];
    assert.throws(() => validateContentOutput('growth', output, {}));
  }
  for (const value of [true, 1.5, -1, 0, 601]) {
    const output = sample('video'); output.artifact.scenes[0].durationSeconds = value;
    assert.throws(() => validateContentOutput('video', output, {}));
  }
  const output = sample('writing'); output.artifact.tags = new Set(['tag']);
  assert.throws(() => validateContentOutput('writing', output, {}));
});

test('grounded writing output is returned as independent data through the public boundary', () => {
  const output = { summary: '待人工审核', facts: [{ quote: '预算三千', evidenceId: 'source-1' }],
    hypotheses: ['通勤偏好仍需确认'], artifact: { title: '看房前先确认', body: '请先核对预算与租期。', tags: ['租房'] } };
  const evidence = { 'source-1': { text: '预算三千，月底入住。', kind: 'fact' } };
  const clean = validateContentOutput('writing', output, evidence);
  assert.deepEqual(clean, output);
  clean.artifact.tags.push('编辑');
  assert.deepEqual(output.artifact.tags, ['租房']);
  assert.equal(getMethod('writing').requiresHumanReview, true);
  assert.match(methodDigest('writing'), /^[a-f0-9]{64}$/);
  assert.match(CATALOG_DIGEST, /^[a-f0-9]{64}$/);
});
