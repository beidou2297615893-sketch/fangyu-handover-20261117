# Visual Review Checklist

Score each direction 1-5:

- feed-scale headline readability
- one-glance audience clarity
- visible proof
- differentiation from recent account covers
- creator authenticity
- product/UI truthfulness
- first-frame continuity
- information density
- color contrast without visual fatigue
- ease of producing a consistent series

Reject if the title needs full-screen reading, the proof is fabricated, or the cover promises content absent from the post.

