from pathlib import Path
import hashlib,json,datetime,socket
T=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):p.write_bytes((json.dumps(v,ensure_ascii=False,indent=2)+'\n').encode())
B=T/'joint-ai2';D=B/'payload/factory-6712aea2ec6d49a8913c70e3d775e77c'
result=json.loads((D/'RESULTS.json').read_bytes());assert result['status']=='PASS' and result['allOwnServicesClosed']
start=json.loads((D/'ACTUAL-HTTP-START.json').read_bytes());assert start['status']==200 and 'city' not in start['request'] and 'area' not in start['request']
provider=json.loads((D/'PROVIDER-CALLS.json').read_bytes());assert len(provider['calls'])==1 and provider['actualPaidModelRequests']==0
states=json.loads((D/'COMMENT-STATES.json').read_bytes());assert len(states)==1 and states[0]['ai_intent']['status']=='graded' and states[0]['ai_intent']['level']=='high'
present=json.loads((D/'CUSTOMER-PRESENTATION.json').read_bytes());items=present['customers']['items'];assert len(items)==1 and items[0]['analysisStatus']=='graded' and items[0]['intentLevel']=='high'
bridge=json.loads((T/'ORIGINAL-CLOUD-BRIDGE-RESULTS.json').read_bytes());assert bridge['status']=='STOPPED'
port=json.loads((T/'ORIGINAL-CLOUD-BRIDGE.json').read_bytes())['port'];s=socket.socket();s.settimeout(.5);closed=s.connect_ex(('127.0.0.1',port))!=0;s.close();assert closed
C=T.parent/'next-release-f82-expansion-composition/project';pins=json.loads((T/'ACTUAL-ANALYSIS-SOURCE-PINS.json').read_bytes())
for r in pins['files']:assert sha(C/r['path'])==r['sha256']
receipt={'status':'PASS_FORMAL_HTTP_NEW_COMMENT_ANALYSIS_AND_READ','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'evidence':str(D),
 'actualFormalHttpAcquisitionStart':True,'requestHasNoCityOrArea':True,'trustedDirectoryInjectsCityArea':True,'newComments':1,'originalWorkflowProviderRequests':1,
 'originalAiAttemptValidated':True,'originalAiCacheWritten':True,'originalAiJobCompleted':True,'originalHttpCustomersGradedHigh':True,'originalTaskAndAccountBinding':True,
 'actualOriginalFactoryServiceRunnerCoreStoreAiWorkflow':True,'productSourcePatchNeeded':False,'sourceFrozenRepresentativeOnly':True,'actualCompiledMainExe':False,
 'realPlatformModelOrCloudDeployment':False,'nativeWindows':0,'allOwnServicesClosed':True,
 'notReplayedThisNarrowFinal':['cross-account/repeated-page matrix','taskless legacy matrix','stop/lease-expiry model-request matrix'],
 'scopeRefinement':'Parent narrowed final acceptance to one actual formal HTTP start/new comment/AI/read hardest chain; no old full matrices repeated.',
 'priorRedPreserved':['ordinary held descriptor overwritten by source overlay (QA derivation)','optional ai_worker attribute QA expectation','direct Runtime omitted city: original AI_CONTEXT_REQUIRED and zero provider','direct positive AI followed by disallowed POST customers: original GET route required'],
 'criticalSourcePinsSha256':sha(T/'ACTUAL-ANALYSIS-SOURCE-PINS.json'),'httpEntryReadPinsSha256':sha(T/'HTTP-ENTRY-AND-READ-FUNCTION-PINS.json'),
 'unverified':['actual final compiled main EXE','actual deployed cloud policy','real platform/natural login and model provider','customer production data']}
save(T/'FINAL-RECEIPT.json',receipt)
readme='# 新评论原分析链验证\n\n正式本机 HTTP acquisition_start 请求已通过：请求没有 city/area，由原后台按已授权门店目录注入“上海／闵行区”；原 Service/Runner/真实短租约、原 Core/Store 入库、原 LocalAIWorkflow/LocalAIAttempts 校验与 CAS，最终原 GET customers 明确呈现 graded/high。新增评论 1 条、合成 provider 回执 1 次、原 validated attempt 1 个、原 ai_cache 1 条、原 ai_job completed/pending0。\n\n这是原代码 source/frozen 路径代表。仅平台页面与企业 AI 返回值为自有合成边界；原 createService 设备云合同在独立内存 HTTP 运行。没有真实平台、模型、云部署或 Native 窗口，不能代替最终编译和真人验收。产品源码无需补丁。13 个关键业务源码与固定 C 字节一致；原 HTTP 启动、身份、回执及读取 5 函数与 C AST 一致，客户投影模块字节一致。成熟 release 的无关内容模块 hash 常量差异明确保留，不冒称整 Native backend 模块相同。\n\n原先红证据保留：QA 派生把源码公司描述覆盖普通 held 包；可选 ai_worker 属性误假设；直接 Runtime 漏城市被原安全约束拒；直接 Runtime 有效城市已分析成功，但错误 POST customers 被拒，正式读取应 GET。最终改用正式 HTTP，由原后台注入目录字段，没有手填城市通过。\n\n按总控最新收窄，本次最终只跑最难新增评论 HTTP 全链，不重跑重复页／跨账号／历史无 task_id／停止与租约失效全矩阵；这些不能冒称本次新验。全部自有服务已关闭。本目录封存后停写。\n'
(T/'REVIEW.md').write_bytes(readme.encode())
paths=['FINAL-RECEIPT.json','REVIEW.md','ROOT-INPUTS.json','ACTUAL-ANALYSIS-SOURCE-PINS.json','HTTP-ENTRY-AND-READ-FUNCTION-PINS.json','prepare_payload.py','prepare_payload_v2.py','serve_original_cloud.cjs','serve_original_cloud_v2.cjs','ORIGINAL-CLOUD-BRIDGE.json','ORIGINAL-CLOUD-BRIDGE-RESULTS.json','probe_setup.py.in','probe_setup-v4.py.in','probe_main.py.in','probe_main-v4.py.in','probe_main-http.py.in','seal_final.py','joint-ai2/standard_loader_prefix.py','joint-ai2/PROBE-INPUTS.json','joint-ai2/probe_entry.py','joint-ai2/probe_entry-v3.py','joint-ai2/probe_entry-v4.py','joint-ai2/probe_entry-http.py','joint-ai2/payload/qa-fixtures/search_bridge_fixture.cjs']
paths += [p.relative_to(T).as_posix() for p in sorted(D.iterdir()) if p.is_file() and p.suffix=='.json']
for old in (T/'joint-ai/payload',B/'payload'):
 for e in old.glob('factory-*/ERROR.json'):paths.append(e.relative_to(T).as_posix())
rows=[{'path':p,'bytes':(T/p).stat().st_size,'sha256':sha(T/p)} for p in sorted(set(paths))]
save(T/'SEALED.json',{'schema':'formal-http-new-comment-ai-evidence-v1','evidence':rows,'noProductSourceChange':True,'noFurtherWrites':True,'dataVaultNotExported':True})
print(json.dumps({'FINAL':sha(T/'FINAL-RECEIPT.json'),'SEALED':sha(T/'SEALED.json'),'evidence':str(D),'groups':result['groupCount'],'files':len(rows)},ensure_ascii=False))
