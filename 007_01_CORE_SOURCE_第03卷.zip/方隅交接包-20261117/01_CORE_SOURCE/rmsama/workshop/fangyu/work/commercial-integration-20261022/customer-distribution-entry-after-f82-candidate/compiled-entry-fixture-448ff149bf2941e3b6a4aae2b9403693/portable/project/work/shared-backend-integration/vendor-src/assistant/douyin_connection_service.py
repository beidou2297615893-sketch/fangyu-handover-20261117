"""Explicit own Douyin connection; original engine remains the state machine.

The fixed material review applies only to this source/internal connection use.
It is neither an account grant nor a general read/reply/DM component grant.
"""
import hashlib
import json
from pathlib import Path
import re
import secrets
import subprocess
import sys
import threading
import time
import unicodedata

from core import CoreError
from core.adapters import account_execution_lock, AdapterBusy
from core.runtime_license_policy import _plain, _file_hash
from core.service_plans import require_feature
from .business import BusinessExecutor
from .xhs_app_context import _DeviceSession
from .dy_browser_login import request_show

_PURPOSE='douyin_owned_connection'
_REVIEW_SHA='1D504F0574C6ADFC55A051A1EDD74162BB79BF6DFE78BF4E1AE8A32D92618111'
_LOGIN_HELPER_SHA='400ABD4C4786F88F3E00DF25A109D995A3238548C248F7E1A9D789B913A199FA'
_ACCOUNT_CONNECTIONS_SHA='BD7730E10F224376D29A053353267FA3CFE62404E6C4FDE7B68D4513686A12BD'
_SOURCE=Path(__FANGYU_SOURCE_ROOT__)
_REVIEW_PATH=Path(__FANGYU_DOUYIN_REVIEW_PATH__)
_ACTOR=('id','tenant_id','username','role','disabled','cloud_bound',
        'development_local_only','can_reply','permission_revision')
_STATES=frozenset(('ready','waiting_login','checking','choose_window','failed','disconnected'))


def _digest(value):
    return hashlib.sha256(json.dumps(value,sort_keys=True,ensure_ascii=False,
        separators=(',',':'),allow_nan=False).encode()).hexdigest()


def _components(server):
    """Fresh bounded disk facts, outside the original Core commit lock."""
    from bridge import BridgeManager
    import account_connections
    overlay=_plain(_REVIEW_PATH.parent/'account_connections.py',_REVIEW_PATH.parent)
    if (Path(account_connections.__file__).resolve()!=overlay.resolve()
            or _file_hash(overlay).upper()!=_ACCOUNT_CONNECTIONS_SHA):
        raise ValueError('component_review_pending')
    if (Path(server.core.resources_dir)!=_SOURCE/'resources'
            or type(server.bridge) is not BridgeManager
            or server.bridge.runtime!=_SOURCE.parent/'work/runtime/douyin-bridge'
            or server._runtime_license_usage_scope('internal_self_use_read')!='internal_self_use_read'):
        raise ValueError('component_review_pending')
    if any((server.bridge.runtime/'node_modules'/name).exists()
           for name in ('bufferutil','utf-8-validate')):
        raise ValueError('unreviewed_optional_runtime')
    review=_plain(_REVIEW_PATH,_REVIEW_PATH.parent)
    if _file_hash(review).upper()!=_REVIEW_SHA:raise ValueError('component_review_pending')
    value=json.loads(review.read_text('utf-8'))
    if (set(value)!={'schema','purpose','scope','company_id','material_limits','materials','evidence'}
            or value['schema']!=1 or value['purpose']!=_PURPOSE
            or value['scope']!='internal_self_use_read'
            or value['company_id']!=server.company.get('id')
            or value['material_limits']!={'account_network':'fixed_identity_js_only',
                'native_loaded_bytes_verified':False,'public_send_grant':False}
            or not isinstance(value['materials'],list) or not value['materials']):
        raise ValueError('component_review_pending')
    facts=[];seen=set()
    for item in value['materials']:
        if (type(item) is not dict or set(item)!={'root','path','sha256','bytes','role'}
                or item['root'] not in ('source','douyin_runtime')
                or type(item['path']) is not str or '\\' in item['path'] or ':' in item['path']
                or any(x in ('','.','..') for x in item['path'].split('/'))
                or (item['root'],item['path']) in seen):
            raise ValueError('component_review_pending')
        root=_SOURCE if item['root']=='source' else server.bridge.runtime
        path=_plain(root/item['path'],root)
        if path.stat().st_size!=item['bytes'] or _file_hash(path).upper()!=item['sha256']:
            raise ValueError('component_review_pending')
        seen.add((item['root'],item['path']));facts.append(item)
    return _digest([_REVIEW_SHA,_ACCOUNT_CONNECTIONS_SHA,facts,server.company.get('id'),'internal_self_use_read'])


def _binding(service,account_id=None):
    from app import AppServer
    from .service import AssistantService
    if type(service) is not AssistantService:raise ValueError('current_scope_unavailable')
    server,core=service.server,service.server.core
    if (type(server) is not AppServer or server.assistant_service is not service
            or not server.employee_workspace_mode):raise ValueError('current_scope_unavailable')
    with core.lock:
        with service.lock:
            executor=service.executor;device=dict(service.device or {})
            if (service.closed or service.stop_event.is_set() or server.closing
                    or service.state!='online' or type(executor) is not BusinessExecutor):
                raise ValueError('current_scope_unavailable')
        user=service._local_user(read_only=True)
        stored=core.store.get('users',user.get('id'))
        session=getattr(executor,'_xhs_app_session',None)
        if (type(session) is not _DeviceSession or session.service is not service
                or session.executor is not executor or session.core is not core
                or not stored or stored.get('disabled') or stored.get('cloud_bound') is not True
                or stored.get('development_local_only') is True
                or stored.get('role') not in ('admin','operator')
                or (stored.get('id'),stored.get('tenant_id'),stored.get('username'))!=
                    (executor.user_id,executor.tenant,executor.owner)
                or device.get('owner')!=executor.owner or not device.get('id')
                or core.remote_safety_hold):raise ValueError('current_scope_unavailable')
        session.check()
        for config in (server.company,core.deployment_config):
            runtime=config.get('runtime') or {}
            if type(runtime) is not dict:raise ValueError('current_scope_unavailable')
            if runtime.get('douyin_automation') in ('hold','disabled','blocked'):
                raise ValueError('platform_scope_held')
            qa=runtime.get('platform_qa_device_id')
            if qa not in (None,'') and (qa!=device['id'] or not core._qa_continuous_allowed()):
                raise ValueError('device_read_lease_unconfirmed')
            if runtime.get('portable_employee_release') not in (None,False):
                if (runtime.get('portable_employee_release') is not True
                        or not core._employee_release_allowed()
                        or core.employee_release_device_id!=device['id']):
                    raise ValueError('device_read_lease_unconfirmed')
        core.require_platform('douyin');server._platform_execution_guard('douyin')
        require_feature(server.company,'acquisition')
        account=None
        if account_id is not None:
            account=core._get('accounts',account_id,executor.tenant)
            core._account_access(user,account)
            if (account.get('platform')!='douyin' or account.get('cloud_owner')!=executor.owner
                    or account.get('requires_review') not in (None,False)
                    or account.get('risk_state') not in (None,'','normal','safe')
                    or account.get('status') in ('disabled','session_recovery_required')):
                raise ValueError('account_scope_held')
        session.check()
        return user,executor,session,device['id'],account,stored


def douyin_connection_availability(service):
    value={'platform':'douyin','purpose':_PURPOSE,'status':'blocked',
        'account_ready':False,'platform_read_only':True}
    try:
        _binding(service);_components(service.server)
        value['status']='available'
    except (CoreError,ValueError,OSError,TypeError,KeyError):pass
    return value


def _identity(value):
    if type(value) is not dict or value.get('authenticated') is not True:
        raise ValueError('identity_unconfirmed')
    uid,nickname=value.get('uid'),value.get('nickname')
    if (type(uid) is not str or re.fullmatch(r'[0-9]{1,160}',uid) is None or not uid.strip('0')
            or type(nickname) is not str or len(nickname)>160
            or any(unicodedata.category(x) in ('Cc','Cs') for x in nickname)):
        raise ValueError('identity_unconfirmed')
    return {'uid':uid,'nickname':nickname}


class _DouyinConnectionCall:
    """One exact original Service/DeviceSession call, no HTTP-carried grant."""
    def __init__(self,helper,user,executor,session,device_id,account,stored,revision):
        self.helper=helper;self.manager=helper.service.server.account_connections
        self.thread=threading.current_thread();self.active=True
        self.user_id=user['id'];self.executor=executor;self.session=session;self.device_id=device_id
        self.account_id=account['id'];self.tenant=account['tenant_id'];self.owner=account['cloud_owner']
        self.actor=_digest({k:stored.get(k) for k in _ACTOR})
        self.saved_uid=str(account.get('platform_uid') or '');self.accepted_uid=None
        self.revision=revision;self.created=None;self.owned=self.manager.owned.get(self.account_id)

    def check(self):
        if (not self.active or self.thread is not threading.current_thread()
                or self.helper.service.server.account_connections is not self.manager):
            raise ValueError('current_scope_unavailable')
        user,executor,session,device_id,account,stored=_binding(self.helper.service,self.account_id)
        if (executor is not self.executor or session is not self.session or device_id!=self.device_id
                or user['id']!=self.user_id or account['tenant_id']!=self.tenant
                or account.get('cloud_owner')!=self.owner
                or _digest({k:stored.get(k) for k in _ACTOR})!=self.actor
                or str(account.get('platform_uid') or '') not in
                    (self.saved_uid,self.accepted_uid if self.accepted_uid is not None else self.saved_uid)
                or self.manager.owned.get(self.account_id) is not self.owned):
            raise ValueError('current_scope_unavailable')
        review=_plain(_REVIEW_PATH,_REVIEW_PATH.parent)
        if _file_hash(review).upper()!=_REVIEW_SHA:raise ValueError('component_review_pending')
        return account

    def before_io(self):
        if _components(self.helper.service.server)!=self.revision:
            raise ValueError('component_review_pending')
        return self.check()

    def register_owned(self,item):
        if self.manager.owned.get(self.account_id) is not item:raise ValueError('owned_window_changed')
        self.created=item;self.owned=item
        self.check()

    def admit_identity(self,identity):
        self.check();observed=_identity(identity)
        if self.saved_uid and self.saved_uid!=observed['uid']:raise ValueError('identity_changed')
        self.accepted_uid=observed['uid']

    def owned_connection(self,items,account):
        self.check();owned=self.owned
        if (owned is None or owned['process'].poll() is not None
                or len(items)!=1 or type(owned.get('marker')) is not str
                or '#workbench-account='+owned['marker'] not in items[0].get('url','')
                or items[0].get('id')!=account.get('conn_id')):
            raise ValueError('owned_window_unconfirmed')


class DouyinConnectionService:
    def __init__(self,service):
        self.service=service;self.lock=threading.RLock();self.pending={};self.closed=False

    def _cleanup(self,ident,item):
        manager=self.service.server.account_connections
        # Closing the retained exact process must not require a still-current
        # dictionary/actor binding. A later owned item is never closed/removed.
        process=item['process']
        if process.poll() is None:
            process.terminate()
            try:process.wait(timeout=3)
            except subprocess.TimeoutExpired:process.kill();process.wait(timeout=3)
        if process.poll() is None:raise ValueError('owned_window_cleanup_pending')
        if manager.owned.get(ident) is item:
            manager.owned.pop(ident)
            for mapping in (manager.states,manager.cache,manager.identity_failures):mapping.pop(ident,None)
        with self.lock:
            if self.pending.get(ident) is item:self.pending.pop(ident)

    def close(self):
        with self.lock:self.closed=True;items=list(self.pending.items())
        for ident,item in items:
            try:self._cleanup(ident,item)
            except Exception:pass  # Exact owned process stays retained for retry.

    def _open_browser(self,call,user,account):
        """Reuse the original Bridge/state machine with a persistent showable UI."""
        call.before_io()
        manager=call.manager;bridge=self.service.server.bridge
        if bridge.external(call.tenant):raise ValueError('owned_bridge_required')
        bridge.start(call.tenant);_,script=bridge.prepare(call.tenant)
        directory=(self.service.server.core.store.directory/'accounts'/call.tenant/
            call.account_id/'managed-window')
        directory.mkdir(parents=True,exist_ok=True)
        marker=secrets.token_hex(20)
        spec={'platform':'douyin','name':account['name'],'marker':marker,
            'config':str(bridge.root(call.tenant)/'config.json'),'script':str(script),
            'profile':str(directory/'profile'),
            'state_path':str(directory/('state-'+marker+'.json')),
            'show_path':str(directory/('show-'+marker+'.json')),'source_root':str(_SOURCE)}
        path=directory/'window.json';path.write_text(json.dumps(spec,ensure_ascii=False),'utf-8')
        executable=Path(sys.executable)
        if executable.name.lower()=='python.exe' and executable.with_name('pythonw.exe').exists():
            executable=executable.with_name('pythonw.exe')
        call.before_io()
        helper=_plain(Path(__file__).with_name('dy_browser_login.py'),Path(__file__).parent)
        if _file_hash(helper).upper()!=_LOGIN_HELPER_SHA:
            raise ValueError('component_review_pending')
        with (directory/'window.log').open('ab') as log:
            process=subprocess.Popen([str(executable),'-B',str(helper),str(path)],
                stdout=log,stderr=log,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
        item={'process':process,'marker':marker,'opened_at':time.time(),
            'state_path':spec['state_path'],'show_path':spec['show_path']}
        manager.owned[call.account_id]=item;call.register_owned(item)
        with self.service.server.core.lock:
            call.check();manager.persist(call.account_id,status='logging_in',conn_id='')
            state=manager.result('waiting_login','已打开抖音浏览器，请在窗口完成本人登录或网页验证。',candidates=[])
            manager.states[call.account_id]=state
            manager.persist(call.account_id,connection_message=state['message'])
        return state

    def _dto(self,call,state):
        account=call.check();status=state.get('status')
        if status not in _STATES:status='failed'
        owned=call.owned
        live=bool(owned is not None and owned['process'].poll() is None)
        observed=None;verified=False
        if status=='ready':
            observed=_identity(state.get('identity'))
            call.owned_connection(state.get('candidates') or [],account)
            if str(account.get('platform_uid') or '')!=observed['uid']:
                raise ValueError('identity_changed')
            verified=True
        return {'platform':'douyin','purpose':_PURPOSE,'account_id':call.account_id,
            'state':status,'platform_login_confirmed':verified,'binding_verified':verified,
            'owned_window_active':live,'observed_identity':observed,'account_ready':False,
            'platform_read_only':True,'auto_retry':False,
            'message':str(state.get('message') or '')[:1000],
            'error_code':state.get('error_code') if state.get('error_code') in
                ('LOGIN_WINDOW_PROCESS_FAILED',) else None}

    def execute(self,operation,data):
        if (operation not in ('start','status') or type(data) is not dict or set(data)!={'account_id'}
                or type(data['account_id']) is not str
                or re.fullmatch(r'[A-Za-z0-9_-]{1,160}',data['account_id']) is None):
            raise ValueError('connection_request_invalid')
        ident=data['account_id']
        with self.lock:
            if self.closed:raise ValueError('current_scope_unavailable')
            pending=self.pending.get(ident)
        if pending is not None:self._cleanup(ident,pending)
        user,executor,session,device_id,account,stored=_binding(self.service,ident)
        revision=_components(self.service.server)
        call=_DouyinConnectionCall(self,user,executor,session,device_id,account,stored,revision)
        manager=call.manager;core=self.service.server.core
        directory=core.store.directory/'accounts'/executor.tenant/ident
        try:
            with account_execution_lock(directory):
                mode=core.account_mode_status(ident,executor.tenant)
                if mode.get('status')=='active':raise ValueError('account_in_use')
                call.check()
                if operation=='start':
                    if call.owned is not None and call.owned['process'].poll() is None:
                        call.before_io();request_show(call.owned)
                        state=manager.status(user,ident,force=True,_owned_call=call)
                    else:
                        lock=manager.locks.setdefault(ident,threading.Lock())
                        if not lock.acquire(False):raise ValueError('connection_check_in_progress')
                        try:state=self._open_browser(call,user,account)
                        finally:lock.release()
                elif call.owned is None or call.owned['process'].poll() is not None:
                    state=manager.result('disconnected','')
                else:state=manager.status(user,ident,force=True,_owned_call=call)
                return self._dto(call,state)
        except AdapterBusy:raise ValueError('account_in_use') from None
        except Exception:
            if call.created is not None:
                with self.lock:self.pending[ident]=call.created
                try:self._cleanup(ident,call.created)
                except Exception:pass
            raise
        finally:call.active=False
