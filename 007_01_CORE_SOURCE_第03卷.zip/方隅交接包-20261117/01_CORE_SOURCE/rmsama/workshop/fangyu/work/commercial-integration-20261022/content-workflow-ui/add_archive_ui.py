from pathlib import Path
U=Path(r'C:/积木软件工坊/项目/方隅公寓客户版/work/parallel-integration-20261018/final-integration/stage-02/project/work/ui-approved-implementation/ui-preview')
p=U/'pages/content-workflow.mjs';s=p.read_text('utf-8')
def replace(old,new):
    global s
    assert old in s,old[:160]
    s=s.replace(old,new)
replace("'content_workspace_read','content_knowledge_search','content_methods_read'", "'content_workspace_read','content_knowledge_search','content_methods_read','content_task_history'")
replace("runUnknown:null};return u.workflowUI;", "runUnknown:null,historyItems:[],historyNext:null,historyMore:false,historyLoaded:false,historyDetail:null};return u.workflowUI;")
replace("function resultPanel(f,w){const flow=dataOf(w),task=arr(flow,'tasks').find(t=>t.id===f.taskId),artifact=arr(flow,'artifacts').find(a=>a.id===task?.artifactId);", "function resultPanel(f,w,{taskOverride=null,artifactOverride=null,readOnly=false}={}){const flow=dataOf(w),task=taskOverride||arr(flow,'tasks').find(t=>t.id===f.taskId),artifact=artifactOverride||arr(flow,'artifacts').find(a=>a.id===task?.artifactId);")
replace("const applied=!!task.appliedRefs,canRun=", "const applied=!!task.appliedRefs,canArchive=!readOnly&&!f.pending&&!f.localUnknown&&!['running','unknown'].includes(task.state)&&!task.requiresReconciliation&&!f.saved.some(r=>r.taskId===task.id),canRun=")
replace("${taskInputs(task)}${task.state==='prepared'?", "${taskInputs(task)}${task.state==='prepared'&&!readOnly?")
replace("${task.runRequestId?btn('核对原执行结果'", "${!readOnly&&task.runRequestId?btn('核对原执行结果'")
replace("<div class=\"co-actions\">${btn(applied?'已采用':applyLabel,'apply',{primary:true,disabled:!canApply||applied})}</div>", "${!readOnly?`<div class=\"co-actions\">${btn(applied?'已采用':applyLabel,'apply',{primary:true,disabled:!canApply||applied})}</div>`:''}")
replace("</div>`:''}</section>`;\n}", "</div>`:''}${!readOnly?`<div class=\"wf-archive-action\">${btn(task.state==='prepared'?'取消准备并归档':'归档本任务','archive',{disabled:!canArchive,extra:`data-task=\"${esc(task.id)}\"`})}<p class=\"co-small\">归档保留资料与结果，已采用的草稿和方案不受影响。执行中或结果待核对时不能归档。</p></div>`:'<p class=\"co-note\">这份历史记录只供查看，不能再次生成或采用。已保存的草稿和方案仍可在原页面继续编辑。</p>'}</section>`;\n}")
needle="function knowledgePanel(f,w)"
assert needle in s
s=s.replace(needle,"""function historyPanel(f,w){const detail=f.historyDetail;return `<p class="co-small">历史按当前账号独立保存。归档释放活动任务位置，不删除引用、原稿或执行记录。</p><div class="wf-task-layout"><div class="wf-task-list">${f.historyItems.map(item=>`<button type="button" data-wf-action="history-task" data-task="${esc(item.task.id)}" class="${detail?.task?.id===item.task.id?'is-selected':''}"><strong>${esc(titleTask(item.task))}</strong><span>${esc(item.task.query)}</span><small>已归档 · ${stamp(item.archivedAt)}</small></button>`).join('')||`<p class="co-small">${f.historyLoaded?'还没有归档任务。':'正在读取当前账号的历史记录。'}</p>`}${f.historyMore?btn('读取更早记录','history-more',{disabled:!!f.pending}):''}</div><div>${detail?`<p class="wf-history-label">归档于 ${stamp(detail.archivedAt)} · 只读历史</p>${resultPanel(f,w,{taskOverride:detail.task,artifactOverride:detail.artifact,readOnly:true})}`:'<p class="co-small">选择一条历史记录，查看完整输入、原文引用与候选结果。</p>'}</div></div>`;}
"""+needle)
replace("${btn('任务与结果 '+arr(flow,'tasks').length,'open-tasks')}", "${btn('任务与结果 '+arr(flow,'tasks').length,'open-tasks')}${btn('已归档','open-history')}")
replace("f.mode==='tasks'?'任务与结果':esc", "f.mode==='tasks'?'任务与结果':f.mode==='history'?'已归档任务':esc")
replace("f.mode==='tasks'?tasksPanel(f,w):`", "f.mode==='tasks'?tasksPanel(f,w):f.mode==='history'?historyPanel(f,w):`")
needle="  if(kind==='view-task')"
assert needle in s
s=s.replace(needle,"""  if(kind==='open-history'||kind==='history-more'){const append=kind==='history-more';if(append&&!f.historyMore)return;update(ctx,()=>{f.open=true;f.mode='history';f.error='';f.notice='';});await request(ctx,u,'content_task_history',{limit:20,...(append?{beforeRevision:f.historyNext}:{})},r=>{if(!Array.isArray(r.result?.items))throw Error('历史记录尚未核对。');const items=append?[...f.historyItems,...r.result.items]:r.result.items;f.historyItems=[...new Map(items.map(item=>[item.task.id,item])).values()];f.historyNext=r.result.nextBeforeRevision;f.historyMore=r.result.hasMore===true;f.historyLoaded=true;if(!append)f.historyDetail=null;});return;}
  if(kind==='history-task'){const taskId=element.dataset.task;await request(ctx,u,'content_task_history',{taskId},r=>{if(r.result?.readOnly!==true||r.result?.task?.id!==taskId)throw Error('历史任务归属尚未核对。');f.historyDetail=r.result;f.mode='history';});return;}
  if(kind==='archive'){const taskId=element.dataset.task,t=arr(dataOf(w),'tasks').find(t=>t.id===taskId);if(!t)throw Error('请重新选择当前账号的任务。');if(['running','unknown'].includes(t.state)||t.requiresReconciliation||f.saved.some(r=>r.taskId===taskId))throw Error('请先核对原执行结果，执行中或结果未知的任务不能归档。');ask(ctx,t.state==='prepared'?'取消这次准备并归档？':'归档这项任务？','<p>归档后保留完整输入、引用和结果，可在“已归档”查看。原任务不能再次生成或采用，已保存的草稿和方案继续保留。</p>',guarded(ctx,u,f,()=>request(ctx,u,'content_task_archive',{taskId},()=>{f.taskId='';f.mode='tasks';f.historyLoaded=false;f.notice='任务已归档，历史可查，已保存的草稿和方案仍保留。';})));return;}
"""+needle)
p.write_text(s,'utf-8')
p=U/'backend.mjs';s=p.read_text('utf-8')
s=s.replace("const contentRead=['content_workspace_read','content_knowledge_search','content_methods_read']", "const contentRead=['content_workspace_read','content_knowledge_search','content_methods_read','content_task_history']")
old="'content_task_apply','content_package_build'].includes(action)";assert old in s
s=s.replace(old,"'content_task_apply','content_package_build','content_task_archive','content_task_history'].includes(action)")
p.write_text(s,'utf-8')
