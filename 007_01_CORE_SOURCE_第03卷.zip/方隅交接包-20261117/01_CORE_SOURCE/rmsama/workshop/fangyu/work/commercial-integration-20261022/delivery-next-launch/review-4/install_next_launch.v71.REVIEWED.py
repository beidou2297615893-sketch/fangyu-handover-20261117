"""Next-launch review draft. Default CHECK; no app/service/process actions.

Derived from delivery-v66's fixed allowlist and original CAS/backup installer.
No final version or hash is guessed. ACCEPTED is empty and installation is
code-disabled until root approves the final immutable release and evidence.
--prepare, once pinned, writes only within this work directory.
"""
from pathlib import Path, PurePosixPath
import argparse
import hashlib
import importlib.util
import json
import re
import stat
import sys

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
P = Path('C:/积木软件工坊/项目/方隅公寓客户版')
F = P / 'work/parallel-integration-20261018/final-integration'
N = P / 'work/ui-native-r57'
GENERIC = P / 'work/parallel-integration-20261018/integration/entry/install_canonical_delegation.py'
GENERIC_SHA = '9909f60d16ad3eaed54b9f97ea0d275ad38510c679ba651ce05af44d920ed0f6'
BINDING_SHA = '14cf53964f5d44d123e989805ea741669ab3f05054e730ddcb299a0aac51a9cb'
OLD_LAUNCHER_SHA = 'c55ed17e0b06b37765942e6eaf5f4506d16a4c92fc55d96308bf8069d00feba4'
OLD_FROZEN_SHA = 'fbd4f3d810658b4f571e41c7fe06d0771111900c6eab941229888a7a5a693702'

# New versions require a newly reviewed allowlist entry, including their own
# frozen evidence. A CLI argument cannot substitute a directory or trust hash.
ACCEPTED = {'candidate-unified-v71': {'candidate_launcher_sha': '50611f5bbeb51bd03842f39ff2206b18343e00bb99bf980d1279dda0a1e2a4f8',
                           'delivery': 'delivery-v71',
                           'evidence': {'frozen-native/ASSERTION-PRESERVATION.json': 'd65ba6f42c3eea13eaa70fb900d2681f138e6485236ba2f5c5f2c06c6db76dc0',
                                        'frozen-native/CLOSURE-RESULTS.json': '8dbb3863a89aa43c9391d1251664f0eb8f8b35c8b2f7ae1283777a49bb349de3',
                                        'frozen-native/FROZEN-NATIVE-HTTP-RESULTS-candidate-unified-v71.json': 'd0b1ba304be80e7f27b573df31cfed6af836f0eda0128ced1e3d72d927c91e6d',
                                        'frozen-native/GATEWAY-HTTP-RESULTS.json': '83dd2a825ba07d551393d52f149aa3e2d0bb55da1680dc2b9896f0271f82fe6c',
                                        'frozen-native/INDEPENDENT-FINAL-VALIDATION.json': 'd37abf6d98c43f15369a116a6af92888136ffaa5884ffb6634986be86b150662',
                                        'frozen-native/MEDIA-OUTCOMES-SUMMARY.json': '45da8008e0aa7f820e64071cc53f4344eadff695aa6dcde76a607ed45c586cc0',
                                        'frozen-native/READINESS-UI-FINAL.json': 'e538b2123231033886443a498e2a1359d0b18e23c3c68d3f2c6f4ea96e8d78c5',
                                        'frozen-native/RESULTS-candidate-unified-v71.json': '6c5f8cc51ae303746512e21d1a0c239f5112f5fb306058a22352df0308e6da98',
                                        'frozen-native/SOURCE-SCHEDULER-FINAL.json': '971b5b08bf1d721490987b8040e6b697ffc401ee67d577e2b748c1eb96e26ec1',
                                        'frozen-native/SOURCE-SCHEDULER-PRECONDITION.json': '54b244f4529e8c0acd1462b89c34e0b9a1f22fac5557cfcd0498a07e393da1d3',
                                        'frozen-native/SUMMARY.json': '14831a73f4c931859898ca4dbdbe4043b4a751cee3cb326e8e3213fd7c21a107'},
                           'files': 3152,
                           'http_groups': 70,
                           'recovery_checkpoint': True,
                           'release_id': 'ui-r57-20261022T204121Z-caf80777',
                           'release_sha': 'd1bdf8a511db9a8568d990a48fcda9ea6ae2e4a1b8224ffcb5e811cf7e23f98c',
                           'staged_sha': '6d94f903a42bedd88a0215d8f906684798c202fd85c03f3530045a520c7b86b4',
                           'unified_sha': 'c6eca73ebcb112fe068c094bc5a3f1ef992aa561d77c4e71ee01c84e28de17ac'}}  # Root final fixed pins; one candidate only.
INSTALLATION_REVIEWED = False  # Draft cannot install, even after an allowlist is filled.
V65_ROLLBACK_FILES = 2777

V65_UNIFIED_SHA = 'c6bc35bc5e2b44c437bf9b8262897d33faF4A5A5c7c1b5f859be130589735268'.lower()


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def exact(path, expected):
    for item in (path, *path.parents):
        info = item.lstat()
        if item.is_symlink() or getattr(info, 'st_file_attributes', 0) & 0x400:
            raise RuntimeError('Links are not accepted: ' + path.name)
    before = path.stat()
    if not stat.S_ISREG(before.st_mode) or before.st_nlink != 1:
        raise RuntimeError('Expected a regular single-link file: ' + path.name)
    raw = path.read_bytes()
    after = path.stat()
    if (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns) != (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns):
        raise RuntimeError('File changed while reading: ' + path.name)
    if sha(raw) != expected.lower():
        raise RuntimeError('Pinned bytes changed: ' + path.name)
    return raw


def read_json(raw):
    return json.loads(raw.decode('utf-8-sig'))


def closure(base, expected, count=None):
    pins = read_json(exact(base / 'UNIFIED-PINS.json', expected))
    if count is not None and len(pins['files']) != count:
        raise RuntimeError('Unexpected closure file count')
    seen = set()
    for row in pins['files']:
        rel = PurePosixPath(row['path'])
        if rel.is_absolute() or '..' in rel.parts or ':' in str(rel) or '\\' in str(rel) or str(rel) in seen:
            raise RuntimeError('Invalid closure member')
        seen.add(str(rel))
        raw = exact(base / 'project' / rel, row['sha256'])
        if len(raw) != row['bytes']:
            raise RuntimeError('Closure size mismatch')
    return len(seen)


def load_installer():
    raw = exact(GENERIC, GENERIC_SHA)
    module = importlib.util.module_from_spec(importlib.util.spec_from_loader('reviewed_entry_installer', loader=None))
    module.__file__ = str(GENERIC)
    exec(compile(raw, str(GENERIC), 'exec', optimize=0), module.__dict__)
    return module



def reviewed_spec(candidate):
    if not isinstance(candidate, str) or not re.fullmatch(r'candidate-unified-v[0-9]+', candidate) or candidate not in ACCEPTED:
        raise RuntimeError('Candidate needs a reviewed fixed-pin entry')
    spec = ACCEPTED[candidate]
    fields = {'release_id', 'unified_sha', 'files', 'release_sha', 'candidate_launcher_sha',
              'recovery_checkpoint', 'evidence', 'delivery', 'http_groups', 'staged_sha'}
    if not isinstance(spec, dict) or set(spec) != fields:
        raise RuntimeError('Reviewed candidate schema is incomplete')
    if not re.fullmatch(r'ui-r57-[0-9]{8}T[0-9]{6}Z-[a-f0-9]{8}', spec['release_id']):
        raise RuntimeError('Reviewed release identifier is invalid')
    if not re.fullmatch(r'delivery-v[0-9]+', spec['delivery']):
        raise RuntimeError('Reviewed evidence folder is invalid')
    for key in ('unified_sha', 'release_sha', 'candidate_launcher_sha', 'staged_sha'):
        if not isinstance(spec[key], str) or not re.fullmatch(r'[a-f0-9]{64}', spec[key]):
            raise RuntimeError('A fixed reviewed SHA256 is required')
    if type(spec['files']) is not int or spec['files'] < 1 or type(spec['http_groups']) is not int or spec['http_groups'] < 32:
        raise RuntimeError('Reviewed closure and evidence counts are invalid')
    if type(spec['recovery_checkpoint']) is not bool or not isinstance(spec['evidence'], dict):
        raise RuntimeError('Reviewed evidence schema is invalid')
    if len(spec['evidence']) < 5 or 'frozen-native/SUMMARY.json' not in spec['evidence']:
        raise RuntimeError('Reviewed frozen acceptance evidence is incomplete')
    for key, pin in spec['evidence'].items():
        rel = PurePosixPath(key)
        if rel.is_absolute() or '..' in rel.parts or ':' in key or '\\' in key or rel.parts[0] != 'frozen-native' or rel.suffix != '.json':
            raise RuntimeError('Reviewed evidence member is invalid')
        if not isinstance(pin, str) or not re.fullmatch(r'[a-f0-9]{64}', pin):
            raise RuntimeError('Reviewed evidence SHA256 is required')
    return spec


def check(candidate, allow_current_new=False):
    if candidate not in ACCEPTED:
        raise RuntimeError('Candidate needs a reviewed fixed-pin entry')
    spec = reviewed_spec(candidate)
    evidence_root = P / 'work/commercial-integration-20261022' / spec['delivery']
    base = F / candidate
    count = closure(base, spec['unified_sha'], spec['files'])
    # Preserve an actually intact v65 rollback, including its older guarded CLI.
    closure(F / 'candidate-unified-v65', V65_UNIFIED_SHA, V65_ROLLBACK_FILES)
    exact(GENERIC, GENERIC_SHA)
    for rel, pin in spec['evidence'].items():
        exact(evidence_root / rel, pin)
    summary = read_json(exact(evidence_root / 'frozen-native/SUMMARY.json', spec['evidence']['frozen-native/SUMMARY.json']))
    if summary['totalHttpGroups'] != spec['http_groups'] or summary['realModelCalls'] or summary['realPlatformRequests'] or summary['productionAccess']:
        raise RuntimeError('Acceptance evidence is not the isolated frozen run')
    exact(N / 'state/production-workspace.json', BINDING_SHA)
    exact(base / 'project/work/ui-native-r57/state/production-workspace.json', BINDING_SHA)
    staged = read_json(exact(base / 'STAGED.json', spec['staged_sha']))
    release = base / 'project/work/ui-native-r57/releases' / spec['release_id']
    if staged['release_id'] != spec['release_id'] or Path(staged['release']) != release or staged['manifest_sha256'].lower() != spec['release_sha']:
        raise RuntimeError('Release descriptor does not match this candidate')
    exact(release / 'RELEASE.json', spec['release_sha'])
    if not allow_current_new:
        exact(N / 'run_workbench.py', OLD_LAUNCHER_SHA)
        exact(N / 'FROZEN.json', OLD_FROZEN_SHA)
    return spec, base, staged, release, count


def write_same_or_new(path, raw):
    # Used only for local draft preparation; never silently replaces a draft.
    for item in path.parents:
        if item.is_symlink() or getattr(item.lstat(), 'st_file_attributes', 0) & 0x400:
            raise RuntimeError('Draft parent cannot be a link')
    if path.exists():
        exact(path, sha(raw))
    else:
        with path.open('xb') as stream:
            stream.write(raw)


def prepare(candidate):
    spec, base, staged, release, count = check(candidate)
    folder = HERE / 'next-launch-prepared' / candidate
    for item in (folder, *folder.parents):
        if item.exists() and (item.is_symlink() or getattr(item.lstat(), 'st_file_attributes', 0) & 0x400):
            raise RuntimeError('Preparation path cannot be a link')
    folder.mkdir(parents=True, exist_ok=True)
    source = base / 'project/work/ui-native-r57' / ('run_candidate.' + spec['release_id'] + '.py')
    body = exact(source, spec['candidate_launcher_sha']).decode('utf-8')
    needle = "RELEASE = ROOT / 'releases/" + spec['release_id'] + "'"
    replacement = "PROJECT_ROOT = ROOT.parent.parent / 'work/parallel-integration-20261018/final-integration/" + candidate + "/project'\nRELEASE = PROJECT_ROOT / 'work/ui-native-r57/releases/" + spec['release_id'] + "'\nBINDING_SHA256 = '" + BINDING_SHA.upper() + "'"
    if body.count(needle) != 1 or body.count('project_root=ROOT.parent.parent') != 1:
        raise RuntimeError('Launcher template changed; review required')
    body = body.replace(needle, replacement).replace('project_root=ROOT.parent.parent', 'project_root=PROJECT_ROOT')
    needle = "        pinned(RELEASE / 'RELEASE.json', MANIFEST_SHA256)"
    if body.count(needle) != 1:
        raise RuntimeError('Launcher manifest check changed')
    body = body.replace(needle, "        pinned(ROOT / 'state/production-workspace.json', BINDING_SHA256)\n        pinned(PROJECT_ROOT / 'work/ui-native-r57/state/production-workspace.json', BINDING_SHA256)\n" + needle)
    compile(body, 'reviewed_next_launch.py', 'exec')
    raw = body.encode('utf-8')
    draft = folder / 'launcher.py.DRAFT'
    independent = N / ('run_delegated_candidate.' + spec['release_id'] + '.py')
    write_same_or_new(draft, raw)
    plan = {
        'status': 'PREPARED_NOT_INSTALLED', 'release_id': spec['release_id'],
        'release': str(release), 'manifest_sha256': staged['manifest_sha256'],
        'launcher': str(independent), 'launcher_sha256': sha(raw).upper(),
        'expected_previous_launcher_sha256': OLD_LAUNCHER_SHA.upper(),
        'expected_previous_frozen_sha256': OLD_FROZEN_SHA.upper(),
        'runtime_project_root': str(base / 'project'), 'installation_state_root': str(N / 'state'),
        'workspace_binding_sha256': BINDING_SHA.upper(), 'full_closure_files_verified': count,
        'full_closure_manifest_sha256': spec['unified_sha'].upper(),
        'validation': str(P / 'work/commercial-integration-20261022' / spec['delivery'] / 'frozen-native/SUMMARY.json'),
        'recovery_checkpoint': spec['recovery_checkpoint'], 'installed': False,
        'production_cloud_activation': False, 'production_data_migration': False,
        'scope': 'Reviewed next-launch entry only; preserve live data, sessions, v65 rollback, and old CLI.',
    }
    write_same_or_new(folder / 'CANONICAL-DELEGATION-PREPARED.json', (json.dumps(plan, ensure_ascii=False, indent=2) + '\n').encode('utf-8'))
    return folder, plan, raw


def install(candidate, recovery_ack):
    if INSTALLATION_REVIEWED is not True:
        raise RuntimeError('Installation is disabled in this review draft; root must approve final pins and this switch first')
    reviewed_spec(candidate)
    if ACCEPTED[candidate]['recovery_checkpoint'] and not recovery_ack:
        raise RuntimeError('This candidate is a recovery checkpoint; explicit acknowledgement is required')
    folder, plan, raw = prepare(candidate)
    # This is the first permitted write outside the delivery folder. It happens
    # only after --install, fixed acceptance checks, and explicit checkpoint ack.
    write_same_or_new(Path(plan['launcher']), raw)
    module = load_installer()
    module.HERE, module.P, module.NATIVE, module.OUT = folder, P, N, F / candidate
    previous = sys.argv
    try:
        sys.argv = [str(GENERIC), '--install']
        module.main()  # original exclusive backup + two-file CAS + failure rollback
    finally:
        sys.argv = previous


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--candidate', required=True)
    actions = parser.add_mutually_exclusive_group()
    actions.add_argument('--check', action='store_true')
    actions.add_argument('--prepare', action='store_true')
    actions.add_argument('--install', action='store_true')
    parser.add_argument('--ack-recovery-checkpoint', action='store_true')
    args = parser.parse_args()
    expected = P / 'work/commercial-integration-20261022/delivery-next-launch/review-4'
    if HERE != expected:
        raise RuntimeError('Keep this reviewed draft in its project delivery folder')
    if args.install:
        install(args.candidate, args.ack_recovery_checkpoint)
    elif args.prepare:
        folder, _, _ = prepare(args.candidate)
        print(json.dumps({'status': 'PREPARED_NOT_INSTALLED', 'folder': str(folder), 'restart': False}, ensure_ascii=False))
    else:
        _, _, _, _, count = check(args.candidate)
        print(json.dumps({'status': 'CHECK_ONLY', 'candidate': args.candidate, 'verifiedFiles': count, 'writes': 0, 'restart': False}))


if __name__ == '__main__':
    main()
