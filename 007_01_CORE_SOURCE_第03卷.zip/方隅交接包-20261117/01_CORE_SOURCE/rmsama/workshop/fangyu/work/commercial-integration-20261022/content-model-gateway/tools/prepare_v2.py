"""Prepare an isolated merge against the exact current live code, never deploy."""
from pathlib import Path
import json
import shutil

ROOT = Path(__file__).resolve().parents[1]


def replace_once(text, old, new):
    assert text.count(old) == 1, old[:100]
    return text.replace(old, new, 1)


def main():
    saved = ROOT / 'work/v1-source'
    assert not saved.exists(), 'Preparation is a one-time source rebase'
    saved.mkdir()
    shutil.copytree(ROOT / 'server', saved / 'server')
    for name in ('CANDIDATE-FILES.json', 'PATCH-MANIFEST.json', 'DELIVERY.json', 'VERIFICATION.json', 'integration.patch'):
        shutil.copy2(ROOT / name, saved / name)
    live = ROOT / 'baseline/live'
    for path in live.iterdir():
        if path.name != 'ai_enterprise.cjs':
            shutil.copy2(path, ROOT / 'server' / path.name)

    # Retain every approved 10-19 prompt/validation change. Add only the already
    # reviewed published-policy metadata support required by the AI foundation.
    contract = (live / 'ai_contract.cjs').read_text('utf8')
    foundation = (ROOT / 'baseline/cloud/ai_contract.cjs').read_text('utf8')
    start, stop = 'function effectiveRulesVersion(config) {', 'function validateIntentPolicy(value) {'
    contract = contract[:contract.index(start)] + foundation[foundation.index(start):foundation.index(stop)] + contract[contract.index(stop):]
    marker = '    price_version: provider ==='
    contract = replace_once(contract, marker, '    ...(c.published_policy_context?{published_policy:structuredClone(c.published_policy_context)}:{}),\n' + marker)
    old = "  return [{role: 'system', content: `${common}\\n规则版本：${effectiveRulesVersion(config)}\\n${instructions}${policy}${rentalBoundary}${eligibilityBoundary}${keyInfoTimingBoundary}${additions}${intentContract}`},\n    {role: 'user', content: JSON.stringify(input)}];"
    new = foundation[foundation.index("  const published=operation==='intent_analyze'"):foundation.index('\n}', foundation.index("  const published=operation==='intent_analyze'"))]
    contract = replace_once(contract, old, new)
    (ROOT / 'server/ai_contract.cjs').write_text(contract, encoding='utf8', newline='\n')

    service = (live / 'service.cjs').read_text('utf8')
    service = replace_once(service, "const CONTRACT =", "const {createProductEntitlements}=require('./product_entitlements.cjs');\nconst CONTRACT =")
    service = replace_once(service, 'sharedFeatureEnabled = SHARED_FEATURE_ENABLED, aiProvider, aiRetryDelay})',
                           'sharedFeatureEnabled = SHARED_FEATURE_ENABLED, aiProvider, aiRetryDelay, productAccessPolicy, servicePeriod, contentGeneration=null})')
    service = replace_once(service, '  const enterpriseAi = createEnterpriseAi({store, companyId, clock, provider: aiProvider, retryDelay: aiRetryDelay});',
                           '  const productEntitlements=createProductEntitlements({companyId,clock,productAccessPolicy,servicePeriod});\n  const enterpriseAi = createEnterpriseAi({store, companyId, environmentId, clock, provider: aiProvider, retryDelay: aiRetryDelay,productEntitlements,contentGeneration});')
    service = replace_once(service, "    if (!payload || payload.environment_id !== environmentId)",
                           "    const readonlyAi=payload?.operation==='content_generate_status'||payload?.operation==='ai_profile'&&payload.connectivity_check!==true;\n    const readonlyFlags=readonlyAi?{read_only:true,mutation_committed:false,auto_retry:false}:{};\n    if (!payload || payload.environment_id !== environmentId)")
    service = replace_once(service, "{error: '环境 ID 不匹配'}", "{error: '环境 ID 不匹配',...readonlyFlags}")
    service = replace_once(service, '      if (!stored) {', "      if (!stored) {\n        if(readonlyAi)return {state:stored,result:reply(503,{code:'AI_CONTENT_STORAGE_UNAVAILABLE',...readonlyFlags})};")
    service = replace_once(service, "{error: '公司隔离检查失败'}", "{error: '公司隔离检查失败',...readonlyFlags}")
    service = replace_once(service, 'const finish = (status, data) => ({state, result: reply(status, data)});',
                           'const finish = (status, data) => ({state:readonlyAi?stored:state, result: reply(status, {...data,...readonlyFlags})});')
    service = replace_once(service, "if (AI_OPERATIONS.has(payload.operation)) return {state, result:",
                           "if (AI_OPERATIONS.has(payload.operation)) return {state:readonlyAi?stored:state, result:")
    (ROOT / 'server/service.cjs').write_text(service, encoding='utf8', newline='\n')

    index = (live / 'index.js').read_text('utf8')
    index = replace_once(index, 'let service;', "const {productOptionsFromEnvironment}=require('./product_entitlements.cjs');\nconst {contentOptionsFromEnvironment}=require('./content_contract.cjs');\nlet service;")
    index = replace_once(index, '  const options = {env: environmentId};', '  const productOptions=productOptionsFromEnvironment(process.env);\n  const contentOptions=contentOptionsFromEnvironment(process.env);\n  const options = {env: environmentId};')
    index = replace_once(index, 'service = createService({store, environmentId, companyId, initialAdmin:',
                         'service = createService({store, environmentId, companyId,...productOptions,...contentOptions, initialAdmin:')
    (ROOT / 'server/index.js').write_text(index, encoding='utf8', newline='\n')
    print(json.dumps({'rebasedOnLiveFiles':19,'v1SourcePreserved':str(saved),'productionChanged':False},ensure_ascii=False))


if __name__ == '__main__':
    main()
