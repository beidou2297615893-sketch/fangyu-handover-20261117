# Topic Evidence Schema

For each candidate record:

- `data_source`: `justone_api` or `websearch`
- `data_unverified`: true when WebSearch fallback was used
- source URL or supplied artifact
- platform and visible search term
- author and post ID when visible
- title and visible format
- publish date and visible metrics when available
- factual evidence
- inferred pattern, clearly labeled
- account fit: 1-5 with reason
- freshness: current, evergreen, aging, or unknown
- evidence strength: high, medium, or low
- production cost: low, medium, or high
- original adaptation angle
- non-reusable creator context

