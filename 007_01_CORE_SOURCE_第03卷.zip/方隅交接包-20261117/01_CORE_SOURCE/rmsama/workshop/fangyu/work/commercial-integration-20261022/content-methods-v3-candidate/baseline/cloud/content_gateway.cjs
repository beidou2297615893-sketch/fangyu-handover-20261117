'use strict';
/* Runner over enterprise transaction/reservation/settlement seams, not new auth. */
const {AiError,usageOf,apiKeyFor,effectiveRulesVersion,reasoningEffort}=require('./ai_contract.cjs');
const {ProviderError}=require('./ai_provider.cjs');
const {normalizeContentPayload,contentInputHash,contentContextHash,authorizeContent,contentSettings,resultEnvelope}=require('./content_contract.cjs');
const {validateContentOutput}=require('./content_methods.cjs');
function nativeOutputSize(value){
 // Match the fixed Native core's Python json.dumps(..., ensure_ascii=False)
 // separators. Number spelling is conservative when Python prefers exponents.
 if(Array.isArray(value))return 2+Math.max(0,value.length-1)*2+value.reduce((n,item)=>n+nativeOutputSize(item),0);
 if(value&&typeof value==='object')return 2+Math.max(0,Object.keys(value).length-1)*2+
  Object.entries(value).reduce((n,[key,item])=>n+Buffer.byteLength(JSON.stringify(key))+2+nativeOutputSize(item),0);
 const encoded=JSON.stringify(value);
 return Buffer.byteLength(encoded)+(/e-[1-9]$/.test(encoded)?1:0);
}
function checkedOutput(input,value,secrets=[]){
 const serialized=JSON.stringify(value);
 if(typeof serialized!=='string'||Buffer.byteLength(serialized)>120000||nativeOutputSize(value)>120000||
  secrets.some(secret=>typeof secret==='string'&&secret.length>0&&serialized.includes(secret)))
  throw new AiError('AI_CONTENT_INVALID_OUTPUT','生成内容未通过输出与资料检查',502);
 try{return validateContentOutput(input.method_id,value,Object.fromEntries(input.data.evidence.map(e=>[e.evidenceId,{text:e.text,kind:e.kind}])));}
 catch{throw new AiError('AI_CONTENT_INVALID_OUTPUT','生成内容未通过输出与资料检查',502);}
}
function createContentGateway({transact,policyConfig,reserve,markAttempt,settle,requestRecovery,provider,
 companyId,environmentId,contentGeneration,productEntitlements,clock=Date.now}){
 async function originalResult(payload,input,identity,status=200,error=null){
  const result=await transact(identity,async(state,repo,user,transaction)=>{
   const {config}=policyConfig(state),settings=contentSettings(contentGeneration);
   // Disabling generation must not turn an original-key query into a dispatch.
   // Existing auth + binding are still mandatory; disabled features cannot reveal output.
   const binding=await authorizeContent({state,user,identity,input,companyId,environmentId,
    settings:settings?{...settings,enabled:true}:null,transaction,now:Math.floor(clock()/1000)});
   let permission=settings?.enabled===true&&config.enabled===true&&!!apiKeyFor(config,config.provider);
   try{productEntitlements.requireFeature('strategy');}catch{permission=false;}
   const meta=await requestRecovery.status({transaction,user,operation:'content_generate',key:payload.request_id,
    readLedger:id=>repo.get('ledger',id),readCache:key=>repo.get('cache',key),
    currentRevision:config.revision,currentRulesVersion:effectiveRulesVersion(config),resultPermission:permission});
   if(meta.input_digest&&meta.input_digest!==contentInputHash(input,companyId))
    throw new AiError('AI_CONTENT_REQUEST_SCOPE','原内容请求的资料或归属不一致',403);
   const effort=config.provider==='openai'?reasoningEffort(config,config.model):null;
   const sameContext=meta.context_digest===contentContextHash(companyId,input,config,effort,binding)&&
    payload.expected_revision===config.revision&&payload.expected_rules_version===effectiveRulesVersion(config);
   let output,available=!!meta.result_available&&sameContext;
   if(available){
    const cache=await repo.get('cache',meta.context_digest);
    try{output=checkedOutput(input,cache.output,[apiKeyFor(config,'deepseek'),apiKeyFor(config,'openai')]);}
    catch{available=false;}
   }
   const known=meta.state==='known_unbilled'&&meta.execution_confirmed===false&&meta.reservation_retained===false;
   const resultState=known?'known_not_executed':meta.state==='succeeded'?'succeeded':meta.state==='completed_no_result'?'completed_no_result':'unknown';
   return resultEnvelope(input,payload,{state:resultState,result_available:available,execution_confirmed:meta.execution_confirmed,
    reservation_retained:meta.reservation_retained,coverage:meta.coverage,context_digest:meta.context_digest??null,
    config_revision:meta.config_revision??null,rules_version:meta.rules_version??null,
    requires_revalidation:known?!sameContext:!!meta.requires_revalidation||!sameContext,cache_hit:!!meta.cache_hit,
    ...(available?{output}: {})});
  });
  return {status,data:{content_generation:result,...(error?{code:error.code,error:error.message}:{}),
   read_only:payload.operation==='content_generate_status',mutation_committed:payload.operation==='content_generate',auto_retry:false}};
 }
 async function handle(payload,identity,remaining){
  let input,plan,dispatched=false;
  try{
   if(payload.environment_id!==environmentId)throw new AiError('AI_CONTENT_ENVIRONMENT','企业环境不匹配',400);
   input=normalizeContentPayload(payload,companyId);
   if(payload.operation==='content_generate_status')return await originalResult(payload,input,identity);
   plan=await reserve('content_generate',input,identity,payload.expected_revision,payload.expected_rules_version,
    payload.request_id,payload.submission_id,payload);
   if(plan.refused){
    const proof=plan.rejectionReceipt;
    return {status:plan.error.status,data:{code:plan.error.code,error:plan.error.message,auto_retry:false,
     content_generation:resultEnvelope(input,payload,proof?{state:'known_not_executed',coverage:'current_submission',
      submission_id:payload.submission_id,execution_confirmed:false,reservation_retained:false}:{}),
     ...(proof?{rejection_receipt:proof}: {})}};
   }
   if(plan.cached)return await originalResult(payload,input,identity);
   if(!remaining()){
    await settle(plan,identity,{errorCode:'AI_PROVIDER_TIMEOUT',knownUnbilled:true});
    return await originalResult(payload,input,identity,502,new AiError('AI_CONTENT_DEADLINE','本次生成尚未派发，原请求已保留',502));
   }
   await markAttempt(plan,identity,1);
   const timeoutMs=remaining();
   if(!timeoutMs){
    await settle(plan,identity,{errorCode:'AI_PROVIDER_TIMEOUT',knownUnbilled:true});
    return await originalResult(payload,input,identity,502,new AiError('AI_CONTENT_DEADLINE','本次生成尚未派发，原请求已保留',502));
   }
   let response,providerFailure;
   dispatched=true;
   try{response=await provider({provider:plan.provider,apiKey:plan.apiKey,model:plan.model,reasoningEffort:plan.reasoningEffort,
    messages:plan.messages,maxTokens:plan.maxTokens,tenantId:require('./ai_contract.cjs').hash(companyId),timeoutMs});}
   catch(error){providerFailure=error instanceof ProviderError?error:new ProviderError('AI_PROVIDER_UNAVAILABLE');}
   if(providerFailure){
    await settle(plan,identity,{errorCode:providerFailure.code,knownUnbilled:providerFailure.knownUnbilled===true,httpStatus:providerFailure.httpStatus});
    return await originalResult(payload,input,identity,502,new AiError('AI_CONTENT_PROVIDER_UNAVAILABLE','内容生成尚未取得可用结果，请按原请求核对',502));
   }
   const usage=usageOf(response,plan.model);
   let output,validationError;
   try{
    if(!usage)throw new AiError('AI_BILLING_UNKNOWN','模型用量尚无法核对，原预算预留保留',502);
    const choice=response?.choices?.[0];
    if(choice?.finish_reason!=='stop'||typeof choice?.message?.content!=='string'||Buffer.byteLength(choice.message.content)>300000)
     throw new AiError('AI_CONTENT_INVALID_OUTPUT','生成内容未完整返回',502);
    let parsed;try{parsed=JSON.parse(choice.message.content);}catch{throw new AiError('AI_CONTENT_INVALID_OUTPUT','生成内容格式未通过检查',502);}
    output=checkedOutput(input,parsed,[plan.apiKey,apiKeyFor(plan.config,'deepseek'),apiKeyFor(plan.config,'openai')]);
   }catch(error){validationError=error instanceof AiError?error:new AiError('AI_CONTENT_INVALID_OUTPUT','生成内容未通过检查',502);}
   const ledger=await settle(plan,identity,{usage,output,errorCode:validationError?.code||''});
   const failed=validationError||ledger.status!=='settled';
   return await originalResult(payload,input,identity,failed?502:200,failed?
    validationError||new AiError('AI_CONTENT_CONTEXT_CHANGED','生成期间上下文已变化，候选不可应用，请核对原任务',502):null);
  }catch(error){
   // A local refusal before the one provider invocation may safely release this
   // plan. Settlement failure or any post-dispatch error never implies no bill.
   if(plan&&!plan.cached&&!plan.refused&&!dispatched){try{await settle(plan,identity,{errorCode:'AI_CONTENT_PRE_DISPATCH_REFUSED',knownUnbilled:true});}catch{}}
   const e=error instanceof AiError?error:new AiError('AI_CONTENT_STORAGE_UNAVAILABLE','原内容请求暂无法核对，请保留原编号',503);
   return {status:e.status,data:{code:e.code,error:e.message,auto_retry:false,
    read_only:payload.operation==='content_generate_status',...(input?{content_generation:resultEnvelope(input,payload)}:{})}};
  }
 }
 return {handle};
}
module.exports={createContentGateway};
