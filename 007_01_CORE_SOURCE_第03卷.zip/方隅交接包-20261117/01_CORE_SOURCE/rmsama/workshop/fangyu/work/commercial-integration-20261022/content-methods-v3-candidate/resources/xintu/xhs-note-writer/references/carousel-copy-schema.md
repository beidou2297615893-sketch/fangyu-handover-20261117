# Carousel / Image Copy Schema

## Required fields

- `title`: specific and truthful; punch band ~8-18 字 or search/intent band ~18-32 字 (see `title-craft.md`)
- `title_job`: `feed` | `search` | `hybrid`
- `hook_line`: first visible line in body
- `body`: scannable markdown/plain text for the note body
- `slide_outline`: optional list of 3-9 slide jobs when carousel
- `tags`: 5-10 tags, `#` optional
- `cta`: one natural action prompt
- `proof_artifact`: what original evidence the copy relies on
- `similarity_risk`: low | medium | high with reason

## Body structure patterns (pick one)

- `problem -> steps -> result`
- `mistake list -> fix`
- `tool/workflow -> demo -> outcome`
- `before/after -> method`
- `faq/quick answers`

## Carousel slide outline item

- slide number
- visual job (cover, step, comparison, result, recap)
- headline on slide
- proof element

## Quality checks

- Payoff visible before slide 3 or second paragraph
- Each slide/section has one job
- No paragraph longer than 4 short mobile lines
- At least one creator-owned proof point
- Title promise matches first body line
