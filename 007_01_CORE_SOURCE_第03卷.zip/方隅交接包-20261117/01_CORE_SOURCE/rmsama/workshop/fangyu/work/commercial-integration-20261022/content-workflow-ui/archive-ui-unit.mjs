import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath,pathToFileURL} from 'node:url';
import {parseHTML} from 'linkedom';
const W=path.dirname(fileURLToPath(import.meta.url));
const U='C:/积木软件工坊/项目/方隅公寓客户版/work/parallel-integration-20261018/final-integration/stage-02/project/work/ui-approved-implementation/ui-preview';
const {renderWorkflow,bindWorkflow}=await import(pathToFileURL(U+'/pages/content-workflow.mjs'));
const {document,window}=parseHTML('<html><body><main></main></body></html>');globalThis.document=document;
globalThis.localStorage={getItem:()=>null,setItem(){},removeItem(){}};
const timestamp='2026-10-23T00:00:00Z';
const makeTask=(id,state='prepared')=>({id,methodId:'writing',query:'虚构历史 '+id,state,evidenceIds:[],artifactIds:[],createdAt:timestamp,input:{evidence:[{evidenceId:'e1',kind:'fact',title:'虚构原文',text:'公共厨房<script>不会执行</script>',sourceLabel:'测试文档'}]}});
let working={actor:{username:'unit-user',storeId:'unit-store',platform:'xiaohongshu',accountId:'unit-account',accountNickname:'虚构账号'},revision:1,workflowContract:'fangyu-content-workflow-v1',workflow:{schemaVersion:1,tasks:[makeTask('task-prepared'),makeTask('task-running','running'),makeTask('task-unknown','unknown'),{...makeTask('task-reconciling','succeeded'),requiresReconciliation:true}],artifacts:[],documents:[]},workflowCapabilities:{canRunTasks:true},drafts:[{id:'draft-retained',title:'已采用的草稿'}],topics:[]};
const histories=Array.from({length:22},(_,i)=>({task:makeTask('history-'+i),artifact:null,archivedAt:timestamp,archivedRevision:100-i,readOnly:true}));
const state={authEpoch:1,storeId:'unit-store',activePlatform:'xiaohongshu',session:{user:{username:'unit-user'}},contentWorkspace:structuredClone(working)};
const u={accountId:'unit-account',tab:'creation',forms:{draft:{},topic:{}},dirty:{}};state.contentOperationsUI=u;
const root=document.querySelector('main'),calls=[],results=[];let cleanup=()=>{},pending=0,dropArchive=false,lastReceipt=null,delayHistory=false,releaseHistory=null;
const ctx={state,update:fn=>{fn();render();},toast(){},modal:({onConfirm})=>onConfirm(),contentAction:async(action,data)=>{calls.push({action,data:structuredClone(data)});pending++;try{
  let result={},receipt;
  if(action==='content_methods_read')result={contract:'fangyu-content-workflow-v1',methods:[]};
  else if(action==='content_workspace_read')receipt=lastReceipt;
  else if(action==='content_task_archive'){
    const task=working.workflow.tasks.find(t=>t.id===data.taskId);assert.ok(task);assert.ok(!['running','unknown'].includes(task.state)&&!task.requiresReconciliation);
    working.workflow.tasks=working.workflow.tasks.filter(t=>t.id!==task.id);working.revision++;histories.unshift({task:structuredClone(task),artifact:null,archivedAt:timestamp,archivedRevision:200+working.revision,readOnly:true});
    result={taskId:task.id,archived:true,archivedAt:timestamp,alreadyArchived:false};receipt={requestId:data.requestId,action,state:'succeeded',found:true};lastReceipt=receipt;
    if(dropArchive){dropArchive=false;throw Error('synthetic archive receipt loss');}
  }else if(action==='content_task_history'){
    assert.equal(data.requestId,undefined);assert.equal(data.expectedRevision,undefined);
    if(data.taskId)result=histories.find(h=>h.task.id===data.taskId);
    else{const all=histories.filter(h=>!data.beforeRevision||h.archivedRevision<data.beforeRevision),items=all.slice(0,data.limit);result={items:items.map(h=>({task:h.task,archivedAt:h.archivedAt,archivedRevision:h.archivedRevision})),hasMore:all.length>items.length,nextBeforeRevision:all.length>items.length?items.at(-1).archivedRevision:null};}
    if(delayHistory){delayHistory=false;await new Promise(r=>releaseHistory=r);}
  }else throw Error('Unexpected '+action);
  return {workspace:structuredClone(working),result,receipt};
}finally{pending--;}}};
function render(){cleanup();root.innerHTML=renderWorkflow(state,u,state.contentWorkspace);cleanup=bindWorkflow(root,ctx,u);}
const tick=()=>new Promise(r=>setTimeout(r,1));
async function idle(){for(let i=0;i<300;i++){await tick();if(!pending&&!u.workflowUI.pending){await tick();if(!pending)return;}}throw Error('pending timeout');}
const el=s=>{const n=root.querySelector(s);assert.ok(n,'Missing '+s);return n;};
async function click(s){const n=el(s);assert.equal(n.disabled,false);n.dispatchEvent(new window.Event('click'));await idle();}
function selectTask(id){u.workflowUI.open=true;u.workflowUI.mode='tasks';u.workflowUI.taskId=id;render();}
try{
  render();selectTask('task-running');assert.equal(el('[data-wf-action="archive"]').disabled,true);selectTask('task-unknown');assert.equal(el('[data-wf-action="archive"]').disabled,true);selectTask('task-reconciling');assert.equal(el('[data-wf-action="archive"]').disabled,true);results.push('running / unknown / requiresReconciliation archive control disabled');
  await idle();selectTask('task-prepared');dropArchive=true;await click('[data-wf-action="archive"]');assert.ok(u.workflowUI.localUnknown);await click('[data-wf-action="check-local"]');assert.equal(u.workflowUI.localUnknown,null);assert.equal(state.contentWorkspace.workflow.tasks.some(t=>t.id==='task-prepared'),false);assert.equal(state.contentWorkspace.drafts[0].id,'draft-retained');assert.equal(calls.filter(c=>c.action==='content_task_archive').length,1);results.push('Lost archive receipt reconciles exactly once; adopted draft retained');
  await click('[data-wf-action="open-history"]');assert.equal(u.workflowUI.historyItems.length,20);assert.equal(u.workflowUI.historyMore,true);await click('[data-wf-action="history-more"]');assert.equal(u.workflowUI.historyItems.length,23);assert.equal(u.workflowUI.historyMore,false);assert.equal(new Set(u.workflowUI.historyItems.map(i=>i.task.id)).size,23);results.push('History cursor fetch loads 20 + 3 records without duplicating rows or write metadata');
  await click('[data-wf-action="history-task"][data-task="task-prepared"]');assert.match(root.textContent,/只读历史/);assert.match(root.textContent,/公共厨房<script>不会执行<\/script>/);assert.equal(root.querySelector('script'),null);assert.equal(root.querySelector('[data-wf-action="run"]'),null);assert.equal(root.querySelector('[data-wf-action="apply"]'),null);assert.equal(root.querySelector('[data-wf-action="archive"]'),null);results.push('Archived detail retains original input as escaped text and exposes no run/apply/archive controls');
  delayHistory=true;el('[data-wf-action="open-history"]').dispatchEvent(new window.Event('click'));for(let i=0;i<100&&!releaseHistory;i++)await tick();assert.ok(releaseHistory);u.accountId='unit-other';state.contentWorkspace={...structuredClone(working),actor:{...working.actor,accountId:'unit-other'}};render();releaseHistory();await idle();assert.equal(u.workflowUI.historyItems.length,0);assert.equal(state.contentWorkspace.actor.accountId,'unit-other');results.push('Late history response is isolated after account switch');
  fs.writeFileSync(path.join(W,'ARCHIVE-UI-UNIT.json'),JSON.stringify({passed:results.length,failed:0,scope:'Node DOM event fixture; synthetic contract, not Native archive validation',results,calls},null,2));console.log(JSON.stringify({passed:results.length}));
}catch(error){fs.writeFileSync(path.join(W,'ARCHIVE-UI-UNIT.json'),JSON.stringify({passed:results.length,failed:1,error:error.stack,text:root.textContent,results,calls},null,2));console.error(error.stack);process.exitCode=1;}
