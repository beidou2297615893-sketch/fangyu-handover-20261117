// Account-scoped content operations. No platform, model or publishing transport lives here.
const esc=value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const icon=file=>`<img class="co-icon" src="/assets/${file}" alt="" aria-hidden="true">`;
const TABS=[['persona','账号人设'],['topics','选题'],['creation','内容创作'],['drafts','草稿与发布'],['metrics','复盘']];
const PLATFORM={xiaohongshu:'小红书',douyin:'抖音'};
const MUTATIONS=new Set(['content_persona_save','content_topic_save','content_draft_save','content_draft_audit','content_schedule_save','content_metrics_save','content_export','content_prompt_prepare','content_asset_import','content_render_cards']);
const STATUS={draft:'草稿',needs_review:'待核对',needs_material:'待补素材',changes_requested:'需要修改',approved:'已人工核对',planned:'提醒计划',paused:'已暂停',cancelled:'已取消',reminder_only:'仅提醒',prepared:'已准备'};
const EMPTY_PERSONA=()=>({name:'',positioning:'',audience:'',pillars:'',voice:'',avoid:'',evidence:''});
const EMPTY_TOPIC=()=>({title:'',column:'',format:'image',goal:'',proof:''});
const EMPTY_DRAFT=()=>({title:'',body:'',script:'',format:'image',notes:'',assetIds:[]});
const METRICS=[['exposures','曝光'],['opens','打开'],['likes','点赞'],['saves','收藏'],['comments','评论'],['inquiries','咨询'],['appointments','预约'],['deals','成交']];
const beijingInput=()=>new Intl.DateTimeFormat('sv-SE',{timeZone:'Asia/Shanghai',year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',hour12:false}).format(new Date()).replace(' ','T');
const EMPTY_METRIC=()=>Object.fromEntries([['draftId',''],['observedAt',beijingInput()],...METRICS.map(([key])=>[key,''])]);
const nameOf=account=>account?.platformNickname||account?.platform_nickname||account?.name||'未提供昵称';
const username=state=>state.session?.user?.username||state.user||'';
const scopeKey=state=>JSON.stringify([state.authEpoch||0,username(state),state.storeId||'',state.activePlatform||'xiaohongshu']);
function ui(state){
  const scope=scopeKey(state);
  if(state.contentOperationsUI?.scope!==scope){
    state.contentOperationsUI={scope,accountId:'',tab:'creation',pending:'',status:'idle',error:'',notice:'',sequence:0,
      forms:{persona:EMPTY_PERSONA(),topic:EMPTY_TOPIC(),draft:EMPTY_DRAFT(),metric:EMPTY_METRIC()},
      dirty:{},assetCache:{},assetLoading:new Set(),assetErrors:{},reviewMode:false,checks:{},scheduleAt:'',scheduleNote:'',
      rightsConfirmed:false,assetSource:'authorized_real',theme:'clean',promptText:'',promptStage:'',readRequired:false,uncertain:null};
  }
  return state.contentOperationsUI;
}
function accounts(state){
  const p=state.platform;
  if(!p||p.actor?.username!==username(state)||p.actor?.storeId!==state.storeId)return [];
  return (Array.isArray(p.accounts)?p.accounts:[]).filter(a=>a&&typeof a.id==='string'&&a.id
    &&a.platform===(state.activePlatform||'xiaohongshu')&&(!a.storeId||a.storeId===state.storeId)
    &&(!a.store_id||a.store_id===state.storeId));
}
function workspace(state){
  const u=ui(state),w=state.contentWorkspace,a=w?.actor;
  return a?.username===username(state)&&a.storeId===state.storeId&&a.platform===(state.activePlatform||'xiaohongshu')
    &&a.accountId===u.accountId&&accounts(state).some(x=>x.id===u.accountId)&&Number.isInteger(w.revision)?w:null;
}
const list=(w,key)=>Array.isArray(w?.[key])?w[key]:[];
const selectedDraft=(state)=>list(workspace(state),'drafts').find(x=>x.id===ui(state).forms.draft.id)||null;
const dirty=u=>Object.values(u.dirty).some(Boolean);
const formatName=value=>value==='video'?'视频脚本':'图文笔记';
const statusName=value=>STATUS[value]||'待核对';
const displayDate=value=>{if(!value)return '时间未填写';const d=new Date(value);return Number.isNaN(d.getTime())?'时间待核对':new Intl.DateTimeFormat('zh-CN',{timeZone:'Asia/Shanghai',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',hour12:false}).format(d);};
const safeDataUrl=value=>typeof value==='string'&&value.length<=3_000_000&&/^data:image\/(?:png|jpeg);base64,[A-Za-z0-9+/=\r\n]+$/.test(value)?value:'';
const button=(label,action,{primary=false,disabled=false,extra='',file=''}={})=>`<button type="button" class="co-button ${primary?'co-primary':''}" data-co-action="${action}" ${disabled?'disabled':''} ${extra}>${file?icon(file):''}${label}</button>`;
function field(group,key,label,value,{area=false,max=600,placeholder='',type='text',required=false,rows=3}={}){
  const id=`co-${group}-${key}`,attrs=`id="${id}" data-co-form="${group}" data-co-field="${key}" ${max?`maxlength="${max}"`:''} ${required?'required':''} placeholder="${esc(placeholder)}"`;
  return `<label class="co-field" for="${id}"><span>${label}${required?'<small class="co-required">必填</small>':''}</span>${area?`<textarea ${attrs} rows="${rows}">${esc(value)}</textarea>`:`<input ${attrs} type="${type}" value="${esc(value)}">`}</label>`;
}
function promptPanel(u){return u.promptText?`<section class="co-prompt" aria-label="已准备的提示词"><div class="co-section-title"><h3>提示词已准备</h3>${button('复制提示词','copy-prompt',{file:'fy-icon-25-copy.png'})}</div><p>可复制交给已配置的创作工具。本次未调用模型，也未生成成稿。</p><textarea data-co-prompt readonly aria-label="可审阅的创作提示词">${esc(u.promptText)}</textarea></section>`:'';}
function panelHeading(title,description='',actions=''){return `<div class="co-section-title"><div><h2>${title}</h2>${description?`<p>${description}</p>`:''}</div>${actions}</div>`;}
function empty(title,description,file='fy-icon-28-file.png'){return `<div class="co-empty">${icon(file)}<h3>${title}</h3><p>${description}</p></div>`;}
function hydrate(state,w){
  const u=ui(state);
  if(!u.dirty.persona)u.forms.persona={...EMPTY_PERSONA(),...(w.persona||{})};
  if(u.forms.draft.id&&!u.dirty.draft){const draft=list(w,'drafts').find(x=>x.id===u.forms.draft.id);if(draft)u.forms.draft=draftForm(draft);}
}
function draftForm(draft){return {id:draft.id,topicId:draft.topicId||'',title:draft.title||'',body:draft.body||'',script:draft.script||'',format:draft.format||'image',notes:draft.notes||'',assetIds:[...(draft.assetIds||[])]};}
function notice(state){const u=ui(state);return `${u.error?`<div class="co-feedback co-error" role="alert"><strong>这一步尚未完成</strong><p>${esc(u.error)}</p>${u.readRequired?'<p>编辑内容已保留，请先核对原保存结果。不会自动换编号重复提交。</p>':''}${u.uncertain&&u.originalChecked?button('按原编号重试保存','retry-original',{disabled:!!u.pending}):''}</div>`:''}${u.notice?`<p class="co-feedback co-success" role="status">${esc(u.notice)}</p>`:''}${u.pending?`<p class="co-working" role="status">${esc(u.pending)}</p>`:''}`;}
function accountHeader(state){
  const u=ui(state),rows=accounts(state),current=rows.find(a=>a.id===u.accountId),platform=state.activePlatform||'xiaohongshu';
  return `<div class="co-account-bar"><div class="co-fixed-store"><span>当前门店</span><strong>${esc(state.store||state.stores?.find(x=>x.id===state.storeId)?.name||'请先选择门店')}</strong><span class="co-platform"><img src="/assets/brand-${platform==='douyin'?'douyin':'xiaohongshu'}.svg" alt="">${PLATFORM[platform]||'平台待核对'}</span></div><label class="co-account-label" for="co-account"><span>发布账号</span><select id="co-account" data-co-account ${u.pending||u.uncertain?'disabled':''}><option value="">请先选择账号</option>${rows.map(a=>`<option value="${esc(a.id)}" ${a.id===u.accountId?'selected':''}>${esc(nameOf(a))}</option>`).join('')}</select></label>${current?`<div class="co-account-confirm"><strong>${esc(nameOf(current))}</strong><span>人设、草稿和计划归此账号</span></div>`:''}<button type="button" class="co-text-button" data-co-action="refresh" ${!u.accountId||u.pending?'disabled':''}>${icon('fy-icon-31-sync.png')}${u.uncertain?'核对原保存结果':'刷新'}</button></div>`;
}
function renderPersona(state){
  const u=ui(state),p=u.forms.persona,w=workspace(state),disabled=!!u.pending||u.readRequired;
  return `<div class="co-columns co-persona-layout"><section class="co-panel">${panelHeading('账号人设','先写真实身份，再确定内容要为谁解决什么问题。')}
    <div class="co-form-grid">${field('persona','name','人设名称',p.name,{max:80,placeholder:'填写本账号的人设名称'})}${field('persona','positioning','定位一句话',p.positioning,{max:400,placeholder:'你的真实身份、服务对象和价值'})}</div>
    ${field('persona','audience','目标受众',p.audience,{area:true,max:600,placeholder:'谁会需要你的内容，他们正在解决什么问题？'})}
    ${field('persona','pillars','内容支柱 / 栏目',p.pillars,{area:true,max:600,placeholder:'每行填写一个长期内容方向，例如真实服务经验、区域生活信息'})}
    <div class="co-form-grid">${field('persona','voice','表达口吻',p.voice,{area:true,max:600,placeholder:'希望怎样表达；哪些说法像你'})}${field('persona','avoid','禁说项与边界',p.avoid,{area:true,max:600,placeholder:'不能承诺、尚未核实、不能公开的内容'})}</div>
    ${field('persona','evidence','事实与资料出处',p.evidence,{area:true,max:1200,placeholder:'记录事实来自哪份门店资料、哪次本人核实；假设单独标明'})}
    <div class="co-actions">${button('保存人设','save-persona',{primary:true,disabled,file:'fy-icon-28-file.png'})}${button('准备人设提示','prompt-persona',{disabled,file:'fy-icon-62-ai.png'})}<span class="co-small">${w?.persona?'已保存的人设可继续编辑':'尚未保存人设'}</span></div>${promptPanel(u)}</section>
    <aside class="co-panel co-summary"><span class="co-eyebrow">账号定位</span><h2>${esc(p.name||'从真实的你开始')}</h2><p class="co-summary-lead">${esc(p.positioning||'填写左侧表单，保存后供本账号选题与创作参考。')}</p><dl><dt>为谁服务</dt><dd>${esc(p.audience||'待填写')}</dd><dt>长期内容方向</dt><dd>${esc(p.pillars||'待填写')}</dd><dt>表达方式</dt><dd>${esc(p.voice||'待填写')}</dd><dt>事实来源</dt><dd>${esc(p.evidence||'待补充')}</dd></dl><p class="co-note">人设由你填写和采用。复盘不会静默改写已保存的人设。</p></aside></div>`;
}
function renderTopics(state){
  const u=ui(state),w=workspace(state),t=u.forms.topic,topics=list(w,'topics'),disabled=!!u.pending||u.readRequired;
  return `<div class="co-columns co-topic-layout"><section class="co-panel">${panelHeading('选题池','每个选题保留受众问题、事实依据与内容形式。',button('新增选题','new-topic',{disabled}))}
    ${topics.length?`<div class="co-topic-list">${topics.map(topic=>`<article class="co-topic-row ${topic.id===t.id?'is-active':''}"><div><span class="co-kicker">${esc(topic.column||'未分栏目')} · ${formatName(topic.format)}</span><h3>${esc(topic.title)}</h3><p>${esc(topic.goal||'目标待补充')}</p></div><div class="co-row-actions">${button('编辑','edit-topic',{extra:`data-id="${esc(topic.id)}"`,disabled})}${button('用这个选题','use-topic',{extra:`data-id="${esc(topic.id)}"`,disabled})}</div></article>`).join('')}</div>`:empty('先存下一个值得写的选题','从受众真实的问题出发，手工添加；没有核实的热度不会被虚构。')}
    <div class="co-actions">${button('准备选题提示','prompt-planning',{disabled,file:'fy-icon-62-ai.png'})}</div>${promptPanel(u)}</section>
    <section class="co-panel">${panelHeading(t.id?'编辑选题':'新增选题')}${field('topic','title','选题主题',t.title,{max:120,required:true,placeholder:'这篇内容具体回答什么问题？'})}${field('topic','column','所属栏目',t.column,{max:80,placeholder:'例如区域生活、租住答疑'})}<label class="co-field"><span>内容形式</span><select id="co-topic-format" data-co-form="topic" data-co-field="format"><option value="image" ${t.format==='image'?'selected':''}>图文笔记</option><option value="video" ${t.format==='video'?'selected':''}>视频脚本</option></select></label>${field('topic','goal','受众问题与目标',t.goal,{area:true,max:80,placeholder:'给谁看，希望对方看完能做什么？'})}${field('topic','proof','可用证据 / 资料出处',t.proof,{area:true,max:600,placeholder:'公开来源或已核实门店资料；缺少的事实也写在这里'})}<div class="co-actions">${button('保存选题','save-topic',{primary:true,disabled})}</div></section></div>`;
}
function assetLabel(asset){return asset.source==='generated_concept'?'概念素材，非实景':asset.source==='text_card'?'文字卡片':'已授权实景素材';}
function imageFor(u,asset){return safeDataUrl(u.assetCache[asset.id]||asset.dataUrl);}
function assetTile(asset,u,{selected=false,selectable=false,index=0}={}){
  const src=imageFor(u,asset);
  return `<div class="co-asset ${selected?'is-selected':''}"><div class="co-asset-picture">${src?`<img src="${esc(src)}" alt="${esc(asset.name||'内容素材')}">`:`<button type="button" data-co-action="load-asset" data-id="${esc(asset.id)}" aria-label="读取${esc(asset.name||'素材')}预览">${icon('fy-icon-45-eye.png')}<span>${u.assetLoading.has(asset.id)?'读取中…':'查看图片'}</span></button>`}${index?`<span class="co-image-number">${index}</span>`:''}</div><div class="co-asset-caption">${selectable?`<label><input type="checkbox" data-co-asset-check="${esc(asset.id)}" ${selected?'checked':''}><span>${esc(asset.name||'未命名图片')}</span></label>`:`<span>${esc(asset.name||'未命名图片')}</span>`}<small>${assetLabel(asset)}${u.assetErrors[asset.id]?` · ${esc(u.assetErrors[asset.id])}`:''}</small>${selected&&selectable?`<div class="co-asset-order"><button type="button" data-co-action="asset-earlier" data-id="${esc(asset.id)}" aria-label="将${esc(asset.name||'图片')}前移">前移</button><button type="button" data-co-action="asset-later" data-id="${esc(asset.id)}" aria-label="将${esc(asset.name||'图片')}后移">后移</button></div>`:''}</div></div>`;
}
function assetArea(state){
  const u=ui(state),w=workspace(state),assets=list(w,'assets'),draft=u.forms.draft,disabled=!!u.pending||u.readRequired;
  return `<details class="co-assets-section" ${u.assetsOpen?'open':''} data-co-assets-section><summary>图片与素材 <span>${draft.assetIds.length} 张已选择 / ${assets.length} 张素材</span></summary><div class="co-assets-body"><p class="co-small">勾选并调整图片顺序，再保存草稿。导入的预览副本会缩小，原文件不变。</p>${assets.length?`<div class="co-asset-grid">${[...assets].sort((a,b)=>{const ai=draft.assetIds.indexOf(a.id),bi=draft.assetIds.indexOf(b.id);return (ai<0?999:ai)-(bi<0?999:bi);}).map(a=>assetTile(a,u,{selected:draft.assetIds.includes(a.id),selectable:true,index:draft.assetIds.includes(a.id)?draft.assetIds.indexOf(a.id)+1:0})).join('')}</div>`:''}<div class="co-import-controls"><label class="co-field"><span>素材类型</span><select data-co-asset-source><option value="authorized_real" ${u.assetSource==='authorized_real'?'selected':''}>本人有权使用的真实素材</option><option value="generated_concept" ${u.assetSource==='generated_concept'?'selected':''}>AI概念素材（非实景）</option></select></label><label class="co-check-line"><input type="checkbox" data-co-rights ${u.rightsConfirmed?'checked':''}>我确认有权使用这张图片</label><label class="co-button co-upload ${disabled||!u.rightsConfirmed?'is-disabled':''}">${icon('fy-icon-27-import.png')}导入图片<input type="file" data-co-file accept="image/png,image/jpeg" ${disabled||!u.rightsConfirmed?'disabled':''}></label></div><p class="co-small">支持PNG/JPG，导入预览副本最多80KB。只保存素材，不上传到平台。</p></div></details>`;
}
function draftPreview(state,draft=ui(state).forms.draft,{review=false}={}){
  const u=ui(state),w=workspace(state),account=accounts(state).find(a=>a.id===u.accountId),assets=draft.assetIds?.map(id=>list(w,'assets').find(a=>a.id===id)).filter(Boolean)||[],index=Math.min(u.previewIndex||0,Math.max(assets.length-1,0)),asset=assets[index],src=asset&&imageFor(u,asset);
  return `<aside class="co-preview ${review?'co-review-preview':''}"><div class="co-preview-heading"><span>草稿预览，未发布</span>${assets.length?`<div>${button('上一张','preview-prev',{disabled:index===0,extra:'aria-label="上一张图片"'})}<span>${index+1} / ${assets.length}</span>${button('下一张','preview-next',{disabled:index>=assets.length-1,extra:'aria-label="下一张图片"'})}</div>`:''}</div><div class="co-preview-paper"><div class="co-preview-account">${icon('approved-icon-user-round.svg')}<div><strong>${esc(nameOf(account))}</strong><span>${esc(state.store||'当前门店')}</span></div><span class="co-badge">草稿</span></div><h2>${esc(draft.title||'这篇内容的标题')}</h2>${draft.format!=='video'?`<div class="co-preview-image">${src?`<img src="${esc(src)}" alt="${esc(asset.name||'所选图片')}">${asset.source==='generated_concept'?'<span class="co-concept-label">AI概念素材 · 非真实房源</span>':''}`:empty('放入你的第一张图片','导入有权使用的实景，或保存正文后生成文字卡片。')}</div>`:'<span class="co-format-label">视频口播稿预览 · 尚未制作视频</span>'}<div class="co-preview-body">${esc(draft.format==='video'?draft.script||'填写口播稿后，会在这里显示。':draft.body||'填写正文后，会在这里显示。')}</div>${assets.length>1?`<div class="co-preview-thumbs">${assets.map((a,i)=>`<button type="button" data-co-action="preview-select" data-index="${i}" aria-label="预览第${i+1}张图片" aria-pressed="${i===index}">${imageFor(u,a)?`<img src="${esc(imageFor(u,a))}" alt="${esc(a.name)}">`:icon('fy-icon-28-file.png')}<span>${i+1}</span></button>`).join('')}</div>`:''}</div></aside>`;
}
function renderCreation(state){
  const u=ui(state),w=workspace(state),d=u.forms.draft,disabled=!!u.pending||u.readRequired,stored=selectedDraft(state);
  const topics=list(w,'topics'),topic=topics.find(t=>t.id===d.topicId);
  return `<div class="co-columns co-creation-layout"><section class="co-panel co-editor">
    <div class="co-title-field">${field('draft','title','本篇主题',d.title,{max:120,required:true,placeholder:'为这篇内容写一个清楚的标题'})}${button('使用账号人设','go-persona',{file:'fy-icon-16-user.png'})}</div>
    <details class="co-topic-picker"><summary>${topic?'已关联选题：'+esc(topic.title):'从选题池选择主题'}<span>可选</span></summary><label class="co-field"><span>已存选题</span><select id="co-draft-topic" data-co-draft-topic><option value="">直接创作</option>${topics.map(t=>`<option value="${esc(t.id)}" ${d.topicId===t.id?'selected':''}>${esc(t.title)}</option>`).join('')}</select></label></details>
    ${field('draft','notes','已核实的门店资料 / 待补事实',d.notes,{area:true,max:1200,rows:3,placeholder:'填写本篇可使用的事实和出处；价格、空房与服务以本人核实为准'})}
    <div class="co-field"><span>内容形式</span><div class="co-segmented" role="group" aria-label="内容形式">${[['image','图文笔记','fy-icon-28-file.png'],['video','视频脚本','fy-icon-55-play.png']].map(([id,label,file])=>button(label,'draft-format',{extra:`data-format="${id}" aria-pressed="${d.format===id}"`,file})).join('')}</div></div>
    ${field('draft','body',d.format==='video'?'视频配文':'正文内容',d.body,{area:true,max:12000,rows:d.format==='video'?3:6,required:d.format!=='video',placeholder:d.format==='video'?'发布视频时使用的配文，与口播稿分开保存。':'写下本篇正文。保留原文，保存时生成新版本。'})}
    ${d.format==='video'?field('draft','script','连续口播稿 / 分镜',d.script,{area:true,max:12000,rows:7,required:true,placeholder:'填写口播内容和分镜，不会自动生成或发布视频。'}):''}
    <div class="co-editor-meta"><span>${d.format==='video'?d.script.length:d.body.length} / 12000</span><span>${stored?`已存版本 ${Number(stored.version)||1}`:'尚未保存'}${u.dirty.draft?' · 有未保存修改':''}</span></div>
    ${assetArea(state)}
    <div class="co-actions co-editor-actions">${button('保存并预览','save-draft',{primary:true,disabled,file:'fy-icon-28-file.png'})}<button type="button" class="co-button" disabled title="未连接创作模型，可先准备提示词或手工编辑">${icon('fy-icon-62-ai.png')}生成草稿 · 待配置</button>${stored?button('发布前核对','open-review',{disabled:disabled||!!u.dirty.draft}):''}</div>
    <details class="co-extra-tools"><summary>卡片与 AI 创作工具<span>排版、提示词与新草稿</span></summary><div class="co-actions">${button('准备写作提示',d.format==='video'?'prompt-video':'prompt-writing',{disabled})}${stored?button('另建草稿','new-draft',{disabled}):''}</div><div class="co-render-tools"><label>卡片样式<select data-co-card-theme><option value="clean" ${u.theme==='clean'?'selected':''}>清爽排版</option><option value="sketch" ${u.theme==='sketch'?'selected':''}>手绘纸感</option></select></label>${button('生成文字卡片','render-cards',{disabled:disabled||!stored||!!u.dirty.draft||w?.capabilities?.canRenderCards!==true,file:'fy-icon-24-template.png'})}<span class="co-small">先保存正文；卡片仅排版，不生成房源实景。</span></div>${promptPanel(u)}</details>
  </section>${draftPreview(state)}</div>`;
}
function renderDrafts(state){
  const u=ui(state),w=workspace(state),drafts=list(w,'drafts'),schedules=list(w,'schedules'),disabled=!!u.pending||u.readRequired;
  return `<div class="co-columns co-draft-layout"><section class="co-panel">${panelHeading('我的内容草稿','原稿与每次保存版本均保留。',button('新建内容','new-draft',{primary:true,disabled}))}${drafts.length?`<div class="co-draft-list">${drafts.map(d=>`<article class="co-draft-row"><div><span class="co-kicker">${formatName(d.format)} · 版本 ${Number(d.version)||1}</span><h3>${esc(d.title)}</h3><p>${esc((d.format==='video'?d.script:d.body)||'')}</p><span class="co-badge ${d.status==='approved'?'co-badge-green':''}">${statusName(d.status)}</span><span class="co-small">${displayDate(d.updatedAt)}</span></div><div class="co-row-actions">${button('继续编辑','edit-draft',{disabled,extra:`data-id="${esc(d.id)}"`})}${button('发布前核对','review-draft',{disabled,extra:`data-id="${esc(d.id)}"`})}${button('导出内容包','export-draft',{disabled,extra:`data-id="${esc(d.id)}"`})}${Array.isArray(d.history)&&d.history.length?`<details class="co-history"><summary>历史版本（${d.history.length}）</summary>${d.history.map(h=>`<div><span>版本 ${h.version} · ${esc(h.title)}</span>${button('恢复为新版本','restore-draft',{disabled,extra:`data-id="${esc(d.id)}" data-version="${Number(h.version)}"`})}</div>`).join('')}</details>`:''}</div></article>`).join('')}</div>`:empty('草稿从这里累积','先到内容创作填写正文、导入素材，再保存第一份草稿。')}</section><aside class="co-panel co-calendar">${panelHeading('发布计划','这里保存提醒，不会自动发帖。')}${schedules.length?`<div class="co-schedules">${[...schedules].sort((a,b)=>String(a.plannedAt).localeCompare(String(b.plannedAt))).map(s=>{const d=drafts.find(d=>d.id===s.draftId);return `<article><time>${esc(displayDate(s.plannedAt))}</time><strong>${esc(d?.title||'草稿待核对')}</strong><span class="co-badge">${statusName(s.status)}</span><p>${esc(s.note||'')}</p>${s.status!=='cancelled'?`<div class="co-row-actions">${button(s.status==='paused'?'恢复提醒':'暂停提醒','schedule-status',{disabled,extra:`data-id="${esc(s.id)}" data-status="${s.status==='paused'?'planned':'paused'}"`})}${button('取消计划','schedule-status',{disabled,extra:`data-id="${esc(s.id)}" data-status="cancelled"`})}</div>`:''}</article>`;}).join('')}</div>`:empty('还没有发布计划','在草稿“发布前核对”中完成检查，再记录计划时间。','fy-icon-11-calendar.png')}<p class="co-note">平台发布尚未接通。到期后由本人核对并手动发布；保存计划不等于已发布。</p></aside></div>`;
}
function renderMetrics(state){
  const u=ui(state),w=workspace(state),m=u.forms.metric,metrics=list(w,'metrics'),drafts=list(w,'drafts'),disabled=!!u.pending||u.readRequired;
  const latestByDraft=new Map();
  for(const record of metrics){const previous=latestByDraft.get(record.draftId);if(!previous||Date.parse(record.observedAt)>=Date.parse(previous.observedAt))latestByDraft.set(record.draftId,record);}
  const total=key=>{const known=[...latestByDraft.values()].filter(m=>Number.isInteger(m[key]));return {count:known.length,value:known.reduce((a,m)=>a+m[key],0)};};
  return `<div class="co-columns co-metrics-layout"><section class="co-panel">${panelHeading('内容表现','各内容只汇总最近一次观察值，历史记录保留；缺少的数据留空。')}<div class="co-summary-numbers">${[['inquiries','咨询'],['appointments','预约'],['deals','成交']].map(([key,label])=>{const t=total(key);return `<div><span>${label}</span><strong>${t.count?t.value:'—'}</strong><small>${t.count} 篇内容已填写</small></div>`;}).join('')}</div>${metrics.length?`<div class="co-table-wrap"><table><caption>已记录的观察数据</caption><thead><tr><th>内容</th><th>观察时间</th><th>曝光</th><th>咨询</th><th>成交</th><th></th></tr></thead><tbody>${metrics.map(m=>`<tr><td>${esc(drafts.find(d=>d.id===m.draftId)?.title||'内容待核对')}</td><td>${displayDate(m.observedAt)}</td><td>${m.exposures??'未填写'}</td><td>${m.inquiries??'未填写'}</td><td>${m.deals??'未填写'}</td><td>${button('编辑','edit-metric',{disabled,extra:`data-id="${esc(m.id)}"`})}</td></tr>`).join('')}</tbody></table></div>`:empty('先记录一次真实表现','没有填写的指标显示“未填写”，不会按0处理，也不会据此推断ROI。','fy-icon-15-table.png')}<div class="co-actions">${button('准备复盘提示','prompt-learning',{disabled,file:'fy-icon-62-ai.png'})}</div>${promptPanel(u)}</section><section class="co-panel">${panelHeading(m.id?'编辑指标':'记录指标','同一观察时长的数据更适合比较。',m.id?button('另记一条','new-metric',{disabled}):'')}<label class="co-field"><span>对应内容</span><select id="co-metric-draftId" data-co-form="metric" data-co-field="draftId"><option value="">请选择已存草稿</option>${drafts.map(d=>`<option value="${esc(d.id)}" ${m.draftId===d.id?'selected':''}>${esc(d.title)}</option>`).join('')}</select></label>${field('metric','observedAt','观察时间（北京时间）',m.observedAt,{type:'datetime-local',max:0,required:true})}<div class="co-form-grid co-metric-inputs">${METRICS.map(([key,label])=>field('metric',key,label,m[key],{type:'number',max:0,placeholder:'未填写'})).join('')}</div><div class="co-actions">${button('保存指标','save-metric',{primary:true,disabled})}</div><p class="co-note">仅保存本人录入的数据。没有可追溯的成本与转化，不计算ROI，也不自动修改人设或选题。</p></section></div>`;
}
function auditSummary(draft){
  const audit=draft.audit||{},issues=Array.isArray(audit.flags)?audit.flags:[];
  return `<div class="co-audit-result"><span class="co-badge">${statusName(draft.status)}</span>${issues.length?`<ul>${issues.map(i=>`<li>${esc(typeof i==='string'?i:i.phrase||i.message||i.label||'有一项需核对')}</li>`).join('')}</ul>`:'<p>规则检查与人工结论分开记录，措辞检查仅供参考。</p>'}${audit.lengthCheck?'<p>篇幅与建议区间不同，请结合平台和内容检查。</p>':''}${audit.humanReviewed?`<p>本人核对：${audit.decision==='approve'?'通过':'需要修改'}${audit.note?' · '+esc(audit.note):''}</p>`:''}</div>`;
}
function renderReview(state){
  const u=ui(state),w=workspace(state),d=selectedDraft(state);
  if(!d){u.reviewMode=false;return renderDrafts(state);}
  const account=accounts(state).find(a=>a.id===u.accountId),disabled=!!u.pending||u.readRequired,checked=['facts','account','assets'].every(k=>u.checks[k]);
  return `<section class="co-review"><button type="button" class="co-text-button co-back" data-co-action="close-review">${icon('tabler-chevron-down.svg')}返回草稿</button><div class="co-review-title"><h2>发布前核对</h2><div class="co-publishing-account">${icon('approved-icon-user-round.svg')}<div><strong>发布账号 <b>${esc(nameOf(account))}</b></strong><span><img src="/assets/brand-${state.activePlatform==='douyin'?'douyin':'xiaohongshu'}.svg" alt="">${PLATFORM[state.activePlatform]||'当前平台'} · ${esc(state.store||'当前门店')}</span></div></div></div><div class="co-columns co-review-layout"><div><h3>内容预览 <small>版本 ${Number(d.version)||1}</small></h3>${draftPreview(state,d,{review:true})}</div><section class="co-review-controls"><div class="co-section-title"><h3>内容检查</h3><span class="co-small">措辞检查仅供参考</span></div><div class="co-panel co-checklist">${[['facts','价格与空房','确认价格、空房状态、活动及服务信息准确。'],['account','账号与门店',`${nameOf(account)} · ${state.store||'当前门店'}`],['assets','图片与正文','确认素材有权使用、图片顺序正确，概念图不冒充实景。']].map(([id,title,detail])=>`<label class="co-review-check"><input type="checkbox" data-co-review-check="${id}" ${u.checks[id]?'checked':''}><div><strong>${title}</strong><p>${esc(detail)}</p></div></label>`).join('')}</div><div class="co-actions">${button('运行内容检查','audit-draft',{disabled})}</div>${auditSummary(d)}<label class="co-field"><span>本次核对说明</span><textarea id="co-audit-note" data-co-audit-note maxlength="1200" rows="3" placeholder="记录已核对内容或需要修改的问题">${esc(u.auditNote||'')}</textarea></label><div class="co-actions">${button('保存人工核对结果','approve-draft',{primary:true,disabled:disabled||!checked})}${button('退回修改','reject-draft',{disabled})}</div><h3 class="co-subheading">发布方式</h3><div class="co-release-mode"><strong>本人核对后手动发布</strong><p>可导出内容包，由本人在目标平台核对并发布。</p><span class="co-small">自动发布尚未接通</span></div><details class="co-schedule-editor" ${u.scheduleOpen?'open':''}><summary>保存发布提醒</summary><label class="co-field"><span>计划时间（北京时间）</span><input id="co-schedule-time" type="datetime-local" data-co-schedule-time value="${esc(u.scheduleAt)}"></label><label class="co-field"><span>计划备注</span><textarea id="co-schedule-note" maxlength="600" data-co-schedule-note rows="2">${esc(u.scheduleNote)}</textarea></label>${button('保存提醒计划','save-schedule',{disabled})}<p class="co-small">仅保存计划，不执行发布。</p></details><div class="co-actions">${button('导出内容包','export-selected',{primary:true,disabled,file:'fy-icon-26-export.png'})}${button('返回修改','edit-selected',{disabled})}</div></section></div></section>`;
}
export function render(state){
  const u=ui(state),w=workspace(state),knownAccount=accounts(state).some(a=>a.id===u.accountId);
  let content;
  if(!state.storeId)content=empty('先选择门店','内容运营与门店资料、账号分别绑定，请先在工作台选择门店。','fy-icon-02-building.png');
  else if(!u.accountId||!knownAccount)content=empty('先选好这次运营的账号','选好后读取这个账号的人设、选题、草稿与计划。其他账号的内容不会混在一起。','fy-icon-16-user.png');
  else if(!w)content=empty(u.pending?'正在读取内容工作区':'工作区尚未读取',u.error?'可点击上方“刷新”重新读取，未自动提交任何内容。':'账号选好后，读取已保存的内容。','fy-icon-28-file.png');
  else content=u.reviewMode?renderReview(state):({persona:renderPersona,topics:renderTopics,creation:renderCreation,drafts:renderDrafts,metrics:renderMetrics}[u.tab]||renderCreation)(state);
  return `<div class="content-operations" data-co-scope="${esc(u.scope)}" aria-busy="${!!u.pending}">${accountHeader(state)}${notice(state)}${!u.reviewMode?`<div class="co-tabs" role="tablist" aria-label="内容运营流程">${TABS.map(([id,label])=>`<button type="button" role="tab" id="co-tab-${id}" data-co-tab="${id}" aria-selected="${u.tab===id}" aria-controls="co-tab-panel" tabindex="${u.tab===id?'0':'-1'}">${label}</button>`).join('')}</div>`:''}<div id="co-tab-panel" role="tabpanel" ${!u.reviewMode?`aria-labelledby="co-tab-${u.tab}"`:''}>${content}</div></div>`;
}
function set(ctx,fn){if(typeof ctx.update==='function')ctx.update(()=>fn());else fn();}
function confirm(ctx,title,html,onConfirm){if(typeof ctx.modal==='function')ctx.modal({title,html,confirmLabel:'确认继续',onConfirm});else if(globalThis.confirm?.(`${title}\n${html.replace(/<[^>]*>/g,'')}`))onConfirm();}
function ifClean(ctx,group,fn){const u=ui(ctx.state);if(group?u.dirty[group]:dirty(u))confirm(ctx,'还有未保存的修改','<p>继续后会切换编辑内容。请先确认已保存需要保留的修改。</p>',fn);else fn();}
function accept(ctx,response,scope,accountId){
  const state=ctx.state,w=response?.workspace,a=w?.actor;
  if(scopeKey(state)!==scope||ui(state).accountId!==accountId)return false;
  if(!a||a.username!==username(state)||a.storeId!==state.storeId||a.platform!==(state.activePlatform||'xiaohongshu')||a.accountId!==accountId||!Number.isInteger(w.revision))throw Error('内容工作区归属无法核对，请重新读取。');
  return true;
}
async function request(ctx,action,data={},success,{replay=false}={}){
  const state=ctx.state,u=ui(state),w=workspace(state),scope=scopeKey(state),accountId=u.accountId;
  if(u.pending)return null;
  if(!accountId||!accounts(state).some(a=>a.id===accountId))return null;
  if(typeof ctx.contentAction!=='function'){set(ctx,()=>{u.notice='';u.error='内容运营连接尚未接入，请稍后刷新。';});return null;}
  const writing=MUTATIONS.has(action);
  if(writing&&(!w||u.readRequired&&!replay)){set(ctx,()=>{u.notice='';u.error='请先刷新核对当前工作区，再保存修改。';});return null;}
  if(replay&&(!u.uncertain||u.uncertain.action!==action||data.requestId!==u.uncertain.payload.requestId))return null;
  const sequence=++u.sequence;
  const requestId=writing?(replay?u.uncertain.payload.requestId:crypto.randomUUID()):null;
  const payload={storeId:state.storeId,accountId,platform:state.activePlatform||'xiaohongshu',...(writing?{expectedRevision:w.revision,requestId}:{}),...data};
  const original=replay?u.uncertain:{action,payload:structuredClone(payload),previousIds:Object.fromEntries(['topics','drafts','assets','metrics','schedules','promptTasks'].map(k=>[k,list(w,k).map(x=>x.id)]))};
  let acknowledged=false;
  set(ctx,()=>{u.pending=action==='content_workspace_read'?'正在读取工作区…':action==='content_render_cards'?'正在排版文字卡片…':'正在保存本次操作…';u.error='';u.notice='';});
  try{
    const response=await ctx.contentAction(action,payload);
    if(!accept(ctx,response,scope,accountId)||ui(state)!==u||u.sequence!==sequence)return null;
    if(writing&&(response.receipt?.requestId!==requestId||response.receipt.action!==action||response.receipt.state!=='succeeded'))throw Error('保存回执尚未核对，请使用原请求检查。');
    acknowledged=true;
    set(ctx,()=>{state.contentWorkspace=response.workspace;u.status='ready';if(writing){u.uncertain=null;u.readRequired=false;u.originalChecked=false;}else if(!u.uncertain)u.readRequired=false;hydrate(state,response.workspace);success?.(response);});
    return response;
  }catch(error){
    if(scopeKey(state)===scope&&ui(state)===u&&u.accountId===accountId&&u.sequence===sequence)set(ctx,()=>{
      u.error=error?.message||'操作未完成，已保留编辑内容。';
      if(writing&&!acknowledged&&error?.mutationCommitted!==false){u.readRequired=true;u.uncertain=original;u.originalChecked=false;}
    });
    return null;
  }finally{if(scopeKey(state)===scope&&ui(state)===u&&u.sequence===sequence)set(ctx,()=>{u.pending='';});}
}
function findSaved(w,key,returned,input,previousIds=[]){
  if(returned?.id)return list(w,key).find(x=>x.id===returned.id)||returned;
  if(input?.id)return list(w,key).find(x=>x.id===input.id);
  const candidates=list(w,key).filter(x=>!previousIds.includes(x.id)&&x.title===input?.title);
  return candidates.length===1?candidates[0]:null;
}
function editDraft(ctx,id,tab='creation'){
  const state=ctx.state,u=ui(state),d=list(workspace(state),'drafts').find(x=>x.id===id);
  if(!d)return;
  ifClean(ctx,'draft',()=>set(ctx,()=>{u.forms.draft=draftForm(d);u.dirty.draft=false;u.tab=tab;u.reviewMode=tab==='review';u.checks={};u.auditNote='';u.previewIndex=0;u.assetsOpen=false;u.error='';}));
}
async function loadAsset(ctx,id){
  const state=ctx.state,u=ui(state),w=workspace(state),scope=scopeKey(state),accountId=u.accountId;
  if(!w||u.assetLoading.has(id)||u.assetCache[id]||!list(w,'assets').some(x=>x.id===id)||typeof ctx.contentAction!=='function')return;
  u.assetLoading.add(id);
  try{const response=await ctx.contentAction('content_workspace_read',{storeId:state.storeId,platform:state.activePlatform||'xiaohongshu',accountId,assetId:id});
    if(accept(ctx,response,scope,accountId)&&ui(state)===u){const asset=response.result?.asset;if(asset?.id!==id||!safeDataUrl(asset.dataUrl))throw Error('图片预览未准备好');set(ctx,()=>{u.assetCache[id]=asset.dataUrl;delete u.assetErrors[id];});}
  }catch(error){if(scopeKey(state)===scope&&ui(state)===u)set(ctx,()=>{u.assetErrors[id]='预览未读取，可重试';});}
  finally{if(scopeKey(state)===scope&&ui(state)===u)set(ctx,()=>{u.assetLoading.delete(id);});}
}
function cacheAssets(u,result){for(const asset of [...(Array.isArray(result?.assets)?result.assets:[]),...(result?.asset?[result.asset]:[])])if(asset.id&&safeDataUrl(asset.dataUrl))u.assetCache[asset.id]=asset.dataUrl;}
function dateISO(value,label){if(!/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}$/.test(value))throw Error(`请填写${label}。`);const d=new Date(value+':00+08:00');if(Number.isNaN(d.getTime()))throw Error(`${label}格式无法识别。`);return d.toISOString();}
function validForm(ctx,group){
  const u=ui(ctx.state),f=u.forms[group];
  if(group==='topic'&&!f.title.trim())throw Error('先填写选题主题。');
  if(group==='draft'&&(!f.title.trim()||!(f.format==='video'?f.script:f.body).trim()))throw Error(f.format==='video'?'先填写标题和口播稿。':'先填写标题和正文。');
  if(group==='metric'&&!f.draftId)throw Error('先选择对应内容。');
  return f;
}
function download(result){
  if(typeof result?.content!=='string'||!result.fileName)throw Error('导出文件尚未准备好。');
  const mime=['text/markdown','text/plain','application/json'].includes(result.mime)?result.mime:'text/plain';
  const url=URL.createObjectURL(new Blob([result.content],{type:mime+';charset=utf-8'})),link=document.createElement('a');
  link.href=url;link.download=String(result.fileName).split(/[\\/]/).pop();document.body.append(link);link.click();link.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);
}
async function prepareImage(file){
  if(!file||!['image/png','image/jpeg'].includes(file.type))throw Error('请选择PNG或JPG图片。');
  if(file.size>20*1024*1024)throw Error('图片过大，请选择20MB以内的PNG或JPG。');
  const objectUrl=URL.createObjectURL(file);
  try{
    const image=new Image();image.src=objectUrl;await image.decode();
    if(image.naturalWidth*image.naturalHeight>80_000_000)throw Error('图片尺寸过大，请先缩小后导入。');
    if(file.size<=80*1024&&image.naturalWidth<=4096&&image.naturalHeight<=4096&&image.naturalWidth*image.naturalHeight<=6_000_000){const bytes=new Uint8Array(await file.arrayBuffer());let value='';for(let i=0;i<bytes.length;i+=32768)value+=String.fromCharCode(...bytes.subarray(i,i+32768));return {name:file.name.slice(0,100),mime:file.type,dataBase64:btoa(value)};}
    const canvas=document.createElement('canvas');
    for(const limit of [1600,1200,960,720]){
      const ratio=Math.min(1,limit/Math.max(image.naturalWidth,image.naturalHeight));
      canvas.width=Math.max(1,Math.round(image.naturalWidth*ratio));canvas.height=Math.max(1,Math.round(image.naturalHeight*ratio));
      const context=canvas.getContext('2d');context.fillStyle='#fff';context.fillRect(0,0,canvas.width,canvas.height);context.drawImage(image,0,0,canvas.width,canvas.height);
      for(const quality of [.84,.72,.6,.46]){const data=canvas.toDataURL('image/jpeg',quality),base64=data.split(',')[1];if(Math.ceil(base64.length*3/4)<=80*1024)return {name:file.name.replace(/\.[^.]*$/,'').slice(0,90)+'-预览.jpg',mime:'image/jpeg',dataBase64:base64};}
    }
    throw Error('这张图片缩小后仍较大，请选择更小的预览图。');
  }finally{URL.revokeObjectURL(objectUrl);}
}
function recoverSaved(state,original,response){
  const u=ui(state),w=response.workspace,p=original.payload,a=original.action;
  if(a==='content_persona_save'){u.forms.persona={...EMPTY_PERSONA(),...w.persona};u.dirty.persona=false;}
  if(a==='content_topic_save'){const saved=findSaved(w,'topics',response.result?.topic,p.topic,original.previousIds.topics);if(saved){u.forms.topic={...EMPTY_TOPIC(),...saved};u.dirty.topic=false;}}
  if(a==='content_draft_save'){const saved=findSaved(w,'drafts',response.result?.draft,p.draft,original.previousIds.drafts);if(saved){u.forms.draft=draftForm(saved);u.dirty.draft=false;}u.tab='drafts';}
  if(a==='content_render_cards'){const d=list(w,'drafts').find(d=>d.id===p.draftId);if(d){u.forms.draft=draftForm(d);u.dirty.draft=false;u.assetsOpen=true;}cacheAssets(u,response.result);}
  if(a==='content_asset_import'){const added=list(w,'assets').filter(a=>!original.previousIds.assets.includes(a.id));if(added.length===1){u.forms.draft.assetIds=[...new Set([...u.forms.draft.assetIds,added[0].id])];u.dirty.draft=true;u.assetsOpen=true;}cacheAssets(u,response.result);}
  if(a==='content_metrics_save'){const saved=response.result?.metric||list(w,'metrics').find(m=>m.id===p.metric.id||!original.previousIds.metrics.includes(m.id));if(saved)u.forms.metric.id=saved.id;u.dirty.metric=false;}
  if(a==='content_prompt_prepare'){const task=response.result?.promptTask||list(w,'promptTasks').find(t=>!original.previousIds.promptTasks.includes(t.id));if(task?.promptText)u.promptText=task.promptText;}
  if(a==='content_export'&&response.result?.content)download(response.result);
  u.uncertain=null;u.readRequired=false;u.originalChecked=false;u.error='';u.notice='原保存已确认成功，未创建新的重复操作。';
}
async function action(ctx,element){
  const state=ctx.state,u=ui(state),w=workspace(state),kind=element.dataset.coAction,id=element.dataset.id;
  if(u.pending&&kind!=='copy-prompt')return;
  try{
    if(kind==='refresh'){const original=u.uncertain;await request(ctx,'content_workspace_read',original?{requestId:original.payload.requestId}:{},r=>{
      if(!original){u.notice='已读取当前账号工作区，未自动提交任何修改。';return;}
      const receipt=r.receipt;if(receipt?.requestId!==original.payload.requestId)throw Error('原保存回执未匹配，请继续核对。');
      if(receipt.found===true&&receipt.state==='succeeded'&&receipt.action===original.action)recoverSaved(state,original,r);
      else if(receipt.found===false&&receipt.state==='not_found'){u.originalChecked=true;u.error='本机当前未找到原保存回执；编辑内容仍保留。可以继续核对，或明确按原编号重试。';u.readRequired=true;}
      else throw Error('原保存状态尚未明确，已保留原编号。');
    });return;}
    if(kind==='retry-original'){const original=u.uncertain;if(!original||!u.originalChecked)return;confirm(ctx,'按原编号重试本次保存？','<p>将使用完全相同的账号、内容、版本与请求编号；不会创建新的保存编号，也不会发布到平台。</p>',()=>request(ctx,original.action,original.payload,r=>recoverSaved(state,original,r),{replay:true}));return;}
    if(kind==='go-persona'){set(ctx,()=>{u.tab='persona';});return;}
    if(kind==='new-topic'){ifClean(ctx,'topic',()=>set(ctx,()=>{u.forms.topic=EMPTY_TOPIC();u.dirty.topic=false;}));return;}
    if(kind==='edit-topic'){const t=list(w,'topics').find(x=>x.id===id);if(t)ifClean(ctx,'topic',()=>set(ctx,()=>{u.forms.topic={...EMPTY_TOPIC(),...t};u.dirty.topic=false;}));return;}
    if(kind==='use-topic'){const t=list(w,'topics').find(x=>x.id===id);if(t)ifClean(ctx,'draft',()=>set(ctx,()=>{u.forms.draft={...EMPTY_DRAFT(),title:t.title,format:t.format,topicId:t.id};u.dirty.draft=true;u.tab='creation';u.reviewMode=false;}));return;}
    if(kind==='new-draft'){ifClean(ctx,'draft',()=>set(ctx,()=>{u.forms.draft=EMPTY_DRAFT();u.dirty.draft=false;u.tab='creation';u.reviewMode=false;u.previewIndex=0;}));return;}
    if(kind==='edit-draft'||kind==='review-draft'){editDraft(ctx,id,kind==='review-draft'?'review':'creation');return;}
    if(kind==='open-review'){if(!selectedDraft(state)||u.dirty.draft)throw Error('请先保存本版草稿，再进行发布前核对。');set(ctx,()=>{u.reviewMode=true;u.checks={};u.auditNote='';});return;}
    if(kind==='close-review'){set(ctx,()=>{u.reviewMode=false;u.tab='drafts';});return;}
    if(kind==='edit-selected'){set(ctx,()=>{u.reviewMode=false;u.tab='creation';});return;}
    if(kind==='draft-format'){set(ctx,()=>{u.forms.draft.format=element.dataset.format;u.dirty.draft=true;});return;}
    if(kind==='preview-prev'||kind==='preview-next'||kind==='preview-select'){set(ctx,()=>{u.previewIndex=kind==='preview-select'?Number(element.dataset.index):Math.max(0,(u.previewIndex||0)+(kind==='preview-next'?1:-1));});return;}
    if(kind==='load-asset'){await loadAsset(ctx,id);return;}
    if(kind==='asset-earlier'||kind==='asset-later'){const ids=u.forms.draft.assetIds,index=ids.indexOf(id),target=index+(kind==='asset-earlier'?-1:1);if(index>=0&&target>=0&&target<ids.length)set(ctx,()=>{[ids[index],ids[target]]=[ids[target],ids[index]];u.dirty.draft=true;});return;}
    if(kind==='save-persona'){const persona=Object.fromEntries(Object.keys(EMPTY_PERSONA()).map(k=>[k,u.forms.persona[k]||'']));await request(ctx,'content_persona_save',{persona},()=>{u.dirty.persona=false;u.notice='账号人设已保存。';});return;}
    if(kind==='save-topic'){const topic=validForm(ctx,'topic'),previousIds=list(w,'topics').map(t=>t.id),data=Object.fromEntries(['id','title','column','format','goal','proof'].filter(k=>topic[k]!==undefined).map(k=>[k,topic[k]]));await request(ctx,'content_topic_save',{topic:data},r=>{const saved=findSaved(r.workspace,'topics',r.result?.topic,data,previousIds);if(saved)u.forms.topic={...EMPTY_TOPIC(),...saved};u.dirty.topic=false;u.notice='选题已保存到当前账号。';});return;}
    if(kind==='save-draft'){const draft=validForm(ctx,'draft'),previousIds=list(w,'drafts').map(d=>d.id),data=Object.fromEntries(['id','topicId','title','body','script','format','notes','assetIds'].filter(k=>draft[k]!==undefined&&!(k==='topicId'&&!draft[k])).map(k=>[k,draft[k]]));await request(ctx,'content_draft_save',{draft:data},r=>{const saved=findSaved(r.workspace,'drafts',r.result?.draft,data,previousIds);if(saved)u.forms.draft=draftForm(saved);u.dirty.draft=false;u.notice='本版草稿已保存，尚未发布。';});return;}
    if(kind==='restore-draft'){confirm(ctx,'恢复这份历史版本？','<p>旧版本会保存为一个新版本，现有原稿和历史仍会保留；需要重新核对。</p>',()=>request(ctx,'content_draft_save',{draft:{id,restoreVersion:Number(element.dataset.version)}},()=>{u.notice='历史内容已保存为新版本，请重新核对。';}));return;}
    if(kind==='audit-draft'||kind==='approve-draft'||kind==='reject-draft'){
      const draft=selectedDraft(state);if(!draft)throw Error('先选择已保存的草稿。');
      if(kind==='approve-draft'&&!['facts','account','assets'].every(k=>u.checks[k]))throw Error('请先逐项核对价格、账号门店与素材。');
      const data={draftId:draft.id,...(kind==='audit-draft'?{}:{decision:kind==='approve-draft'?'approve':'changes_requested',note:u.auditNote||''})};
      await request(ctx,'content_draft_audit',data,()=>{u.notice=kind==='audit-draft'?'内容检查已保存，请继续本人核对。':kind==='approve-draft'?'人工核对结果已保存，尚未发布。':'修改意见已保存。';});return;
    }
    if(kind==='save-schedule'){const d=selectedDraft(state);if(!d)throw Error('先选择已存草稿。');const schedule={draftId:d.id,plannedAt:dateISO(u.scheduleAt,'计划时间'),note:u.scheduleNote||'',status:'planned'};await request(ctx,'content_schedule_save',{schedule},()=>{u.notice='提醒计划已保存，不会自动发布。';u.scheduleOpen=false;});return;}
    if(kind==='schedule-status'){const s=list(w,'schedules').find(x=>x.id===id);if(s)await request(ctx,'content_schedule_save',{schedule:{id:s.id,draftId:s.draftId,plannedAt:s.plannedAt,note:s.note||'',status:element.dataset.status}},()=>{u.notice='提醒计划状态已保存，未执行发布。';});return;}
    if(kind==='save-metric'){const form=validForm(ctx,'metric'),metric={...(form.id?{id:form.id}:{}),draftId:form.draftId,observedAt:dateISO(form.observedAt,'观察时间')};for(const [key,label]of METRICS){const value=form[key];if(value!==''&&(!/^\d+$/.test(String(value))||!Number.isSafeInteger(Number(value))))throw Error(`${label}只能填写非负整数，缺少的数据请留空。`);metric[key]=value===''?null:Number(value);}await request(ctx,'content_metrics_save',{metric},r=>{u.dirty.metric=false;const record=r.result?.metric;if(record?.id)u.forms.metric.id=record.id;u.notice='真实指标已保存，未填写项保持空缺。';});return;}
    if(kind==='edit-metric'){const m=list(w,'metrics').find(x=>x.id===id);if(m)ifClean(ctx,'metric',()=>set(ctx,()=>{u.forms.metric={...EMPTY_METRIC(),...m,observedAt:new Intl.DateTimeFormat('sv-SE',{timeZone:'Asia/Shanghai',year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',hour12:false}).format(new Date(m.observedAt)).replace(' ','T')};for(const [k]of METRICS)u.forms.metric[k]=m[k]??'';u.dirty.metric=false;}));return;}
    if(kind==='new-metric'){ifClean(ctx,'metric',()=>set(ctx,()=>{u.forms.metric=EMPTY_METRIC();u.dirty.metric=false;}));return;}
    if(kind.startsWith('prompt-')){const stage=kind.slice(7),instructions=stage==='writing'||stage==='video'?u.forms.draft.notes||'':'';await request(ctx,'content_prompt_prepare',{stage,...(selectedDraft(state)?{draftId:selectedDraft(state).id}:{}),...(instructions?{instructions}:{})},r=>{const prompt=r.result?.promptTask;if(typeof prompt?.promptText!=='string')throw Error('提示词任务尚未准备好。');u.promptText=prompt.promptText;u.promptStage=stage;u.notice='仅准备了可审阅提示词，未调用模型。';});return;}
    if(kind==='copy-prompt'){try{await navigator.clipboard.writeText(u.promptText);ctx.toast?.('提示词已复制');}catch{const field=document.querySelector('[data-co-prompt]');field?.focus();field?.select();}return;}
    if(kind==='render-cards'){const d=selectedDraft(state);if(!d||u.dirty.draft)throw Error('先保存本版草稿，再生成卡片。');await request(ctx,'content_render_cards',{draftId:d.id,theme:u.theme},r=>{cacheAssets(u,r.result);const saved=list(r.workspace,'drafts').find(x=>x.id===d.id);if(saved)u.forms.draft=draftForm(saved);u.dirty.draft=false;u.assetsOpen=true;u.notice='文字卡片已保存为草稿新版本，请重新核对内容与顺序。';});return;}
    if(kind==='export-draft'||kind==='export-selected'){const draftId=id||selectedDraft(state)?.id;if(!draftId)throw Error('先选择已存草稿。');await request(ctx,'content_export',{draftId},r=>{download(r.result);u.notice='内容包已导出，未向平台发布。';});return;}
  }catch(error){set(ctx,()=>{u.notice='';u.error=error?.message||'操作尚未完成。';});}
}
export function bind(root,ctx){
  const state=ctx.state,u=ui(state),scope=u.scope;let disposed=false;
  const account=root.querySelector('[data-co-account]');
  account?.addEventListener('change',e=>{const id=e.target.value;const change=()=>set(ctx,()=>{u.sequence++;u.accountId=id;u.status='idle';u.error='';u.notice='';u.pending='';u.forms={persona:EMPTY_PERSONA(),topic:EMPTY_TOPIC(),draft:EMPTY_DRAFT(),metric:EMPTY_METRIC()};u.dirty={};u.assetCache={};u.assetErrors={};u.assetLoading=new Set();u.reviewMode=false;u.readRequired=false;u.uncertain=null;u.promptText='';state.contentWorkspace=null;});ifClean(ctx,null,change);if(dirty(u)&&u.accountId!==id)e.target.value=u.accountId;});
  root.querySelectorAll('[data-co-tab]').forEach(element=>{
    element.addEventListener('click',()=>set(ctx,()=>{u.tab=element.dataset.coTab;u.reviewMode=false;u.error='';u.notice='';}));
    element.addEventListener('keydown',e=>{const direction=e.key==='ArrowRight'?1:e.key==='ArrowLeft'?-1:0;if(!direction)return;e.preventDefault();const index=TABS.findIndex(([key])=>key===u.tab);set(ctx,()=>{u.tab=TABS[(index+direction+TABS.length)%TABS.length][0];});root.ownerDocument.getElementById('co-tab-'+u.tab)?.focus();});
  });
  root.querySelectorAll('[data-co-form]').forEach(element=>element.addEventListener(element.tagName==='SELECT'?'change':'input',()=>{
    const group=element.dataset.coForm,key=element.dataset.coField;u.forms[group][key]=element.value;u.dirty[group]=true;
    // Keep the live editor node and IME selection intact while updating preview text.
    if(group==='draft'){
      const preview=root.querySelector('.co-preview-paper h2'),body=root.querySelector('.co-preview-body');
      if(preview)preview.textContent=u.forms.draft.title||'这篇内容的标题';
      if(body)body.textContent=u.forms.draft.format==='video'?u.forms.draft.script||'填写口播稿后，会在这里显示。':u.forms.draft.body||'填写正文后，会在这里显示。';
      const meta=root.querySelector('.co-editor-meta');if(meta)meta.innerHTML=`<span>${u.forms.draft.format==='video'?u.forms.draft.script.length:u.forms.draft.body.length} / 12000</span><span>有未保存修改</span>`;
      root.querySelectorAll('[data-co-action="open-review"],[data-co-action="render-cards"]').forEach(b=>b.disabled=true);
    }
  }));
  root.querySelector('[data-co-draft-topic]')?.addEventListener('change',e=>set(ctx,()=>{const t=list(workspace(state),'topics').find(t=>t.id===e.target.value);u.forms.draft.topicId=e.target.value;if(t&&!u.forms.draft.title)u.forms.draft.title=t.title;u.dirty.draft=true;}));
  root.querySelectorAll('[data-co-action]').forEach(element=>element.addEventListener('click',()=>action(ctx,element)));
  root.querySelector('[data-co-assets-section]')?.addEventListener('toggle',e=>{u.assetsOpen=e.target.open;});
  root.querySelectorAll('[data-co-asset-check]').forEach(element=>element.addEventListener('change',()=>set(ctx,()=>{const id=element.dataset.coAssetCheck,ids=u.forms.draft.assetIds;u.forms.draft.assetIds=element.checked?[...new Set([...ids,id])]:ids.filter(x=>x!==id);u.dirty.draft=true;u.previewIndex=0;})));
  root.querySelector('[data-co-asset-source]')?.addEventListener('change',e=>{u.assetSource=e.target.value;});
  root.querySelector('[data-co-rights]')?.addEventListener('change',e=>set(ctx,()=>{u.rightsConfirmed=e.target.checked;}));
  root.querySelector('[data-co-card-theme]')?.addEventListener('change',e=>{u.theme=e.target.value;});
  root.querySelector('[data-co-schedule-time]')?.addEventListener('input',e=>{u.scheduleAt=e.target.value;});
  root.querySelector('[data-co-schedule-note]')?.addEventListener('input',e=>{u.scheduleNote=e.target.value;});
  root.querySelector('[data-co-audit-note]')?.addEventListener('input',e=>{u.auditNote=e.target.value;});
  root.querySelectorAll('[data-co-review-check]').forEach(element=>element.addEventListener('change',()=>set(ctx,()=>{u.checks[element.dataset.coReviewCheck]=element.checked;})));
  root.querySelector('[data-co-file]')?.addEventListener('change',async e=>{
    const file=e.target.files?.[0];if(!file||!u.rightsConfirmed||u.pending)return;
    const accountId=u.accountId;set(ctx,()=>{u.pending='正在准备图片预览副本…';u.error='';u.notice='';});
    try{const image=await prepareImage(file);if(scopeKey(state)!==scope||ui(state)!==u||u.accountId!==accountId)return;u.pending='';await request(ctx,'content_asset_import',{...image,source:u.assetSource,rightsConfirmed:true},r=>{cacheAssets(u,r.result);const asset=r.result?.asset;if(asset?.id){u.forms.draft.assetIds=[...new Set([...u.forms.draft.assetIds,asset.id])];u.dirty.draft=true;}u.rightsConfirmed=false;u.assetsOpen=true;u.notice='图片已导入当前账号，请保存草稿以保留图片选择。';});}
    catch(error){if(scopeKey(state)===scope&&ui(state)===u)set(ctx,()=>{u.error=error.message;u.pending='';});}
  });
  if(u.pending||u.readRequired)root.querySelectorAll('input,textarea,select').forEach(element=>element.disabled=true);
  if(u.accountId&&accounts(state).some(a=>a.id===u.accountId)&&!workspace(state)&&!u.pending&&!u.error)queueMicrotask(()=>{if(!disposed&&ui(state)===u&&scopeKey(state)===scope)request(ctx,'content_workspace_read');});
  const first=ui(state).forms.draft.assetIds?.[u.previewIndex||0];
  if(first&&!u.assetCache[first]&&!u.assetLoading.has(first)&&!u.assetErrors[first])queueMicrotask(()=>{if(!disposed)loadAsset(ctx,first);});
  return ()=>{disposed=true;};
}
