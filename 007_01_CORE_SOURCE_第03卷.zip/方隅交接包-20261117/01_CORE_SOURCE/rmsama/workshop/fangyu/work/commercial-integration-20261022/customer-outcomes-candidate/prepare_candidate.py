from pathlib import Path
import hashlib,json
W=Path(__file__).resolve().parent
S=Path('C:/积木软件工坊/项目/方隅公寓客户版/work/parallel-integration-20261018/final-integration/stage-02/project')
files={}
def edit(rel,change):
    source=S/rel;raw=source.read_bytes();before=W/'base'/rel
    before.parent.mkdir(parents=True,exist_ok=True)
    if before.exists():assert before.read_bytes()==raw,'Source changed since exact base capture: '+rel
    else:before.write_bytes(raw)
    newline='\r\n' if b'\r\n' in raw else '\n'
    text=raw.decode('utf-8').replace('\r\n','\n');text=change(text)
    output=W/'candidate'/rel;output.parent.mkdir(parents=True,exist_ok=True);output.write_bytes(text.replace('\n',newline).encode('utf-8'))
    files[rel]={'baseSha256':hashlib.sha256(raw).hexdigest(),'candidateSha256':hashlib.sha256(output.read_bytes()).hexdigest()}
def replace(text,old,new):
    assert text.count(old)==1,(old[:100],text.count(old));return text.replace(old,new)
def backend(t):
    t=replace(t,'CUSTOMER_ACTIONS = frozenset(',"OUTCOME_ACTIONS = frozenset({'customer_outcome_read','customer_outcome_save','customer_outcome_cancel','customer_outcome_report'})\nCUSTOMER_ACTIONS = OUTCOME_ACTIONS | frozenset(")
    t=replace(t,'customer_intent_factory=None,','customer_intent_factory=None, outcomes_factory=None,')
    t=replace(t,'        self.customer_intent_factory = customer_intent_factory','        self.customer_intent_factory = customer_intent_factory\n        self.outcomes_factory = outcomes_factory')
    t=replace(t,'    def _customer_dispatch(self, action, data, token):','    def _customer_dispatch(self, action, data, token):\n        if action in OUTCOME_ACTIONS:\n            return self._customer_outcome_dispatch(action,data,token)')
    method='''    def _customer_outcome_dispatch(self,action,data,token):
        invoked=False;committed=False;write=action in ('customer_outcome_save','customer_outcome_cancel')
        try:
            with self.lock:
                user,profile=self._identity(token);store_id=self._selected_store(user,profile)
                factory=getattr(self,'outcomes_factory',None)
                if factory is None or self.customer_workbench is None:
                    raise WorkbenchError('OUTCOME_UNAVAILABLE','客户结果组件尚未装入当前版本',503)
                service=factory(self.core,self.customer_workbench)
                method={'customer_outcome_read':service.read,'customer_outcome_save':service.save,
                    'customer_outcome_cancel':service.cancel,'customer_outcome_report':service.report}[action]
                invoked=True;result=method(user,store_id,data);committed=write
                fresh,fresh_profile=self._identity(token)
                if (any(fresh.get(k)!=user.get(k) for k in ('id','tenant_id','username','role','cloud_bound'))
                        or self._selected_store(fresh,fresh_profile)!=store_id):
                    raise WorkbenchError('OUTCOME_SCOPE_CHANGED','当前员工或门店已变化，请回原范围核对',403)
                if write:
                    service.read(fresh,store_id,{k:data[k] for k in ('storeId','customerId','platform')})
                return {'customerOutcomes':result}
        except Exception as error:
            uncertain=committed or (invoked and write and not hasattr(error,'mutation_committed'))
            failure=WorkbenchError('OUTCOME_RESULT_UNCONFIRMED' if uncertain else getattr(error,'code','OUTCOME_UNAVAILABLE'),
                '结果待核对，请回原员工和门店查询原操作；不要重复登记' if uncertain else str(error) if hasattr(error,'code') else '客户结果暂不可用，请保留输入',
                409 if uncertain else getattr(error,'status',503))
            failure.mutation_committed=True if committed else getattr(error,'mutation_committed',None if uncertain else False)
            raise failure from None

'''
    return replace(t,'    def _customer_intent_dispatch(self,action,data,token):',method+'    def _customer_intent_dispatch(self,action,data,token):')
def host(t):
    t=replace(t,"API_ACTIONS = API_ACTIONS | frozenset(('keyword_effect_read',))","API_ACTIONS = API_ACTIONS | frozenset(('keyword_effect_read','customer_outcome_read','customer_outcome_save','customer_outcome_cancel','customer_outcome_report'))")
    t=t.replace("'keyword_effect_workbench.py',","'keyword_effect_workbench.py', 'customer_outcomes_workbench.py',")
    begin=t.index('def _keyword_effect_factory(root, files):');end=t.index('\n\ndef create_backend(',begin)
    factory=t[begin:end].replace('_keyword_effect_factory','_customer_outcomes_factory').replace('keyword_effect_workbench.py','customer_outcomes_workbench.py').replace('fangyu_keyword_effect_','fangyu_customer_outcomes_').replace('KeywordEffectWorkbench','CustomerOutcomesWorkbench')
    t=t[:end]+'\n\n'+factory+t[end:]
    return replace(t,"        extra['keyword_factory'] = keyword_factory","        extra['keyword_factory'] = keyword_factory\n    outcomes_factory = _customer_outcomes_factory(root,files)\n    if outcomes_factory is not None:\n        extra['outcomes_factory'] = outcomes_factory")
def freezer(t):
    old="    copy_public(HERE / 'customer_intent_workbench.py', release / 'customer_intent_workbench.py')"
    return replace(t,old,old+"\n    outcome_body=copy_public(HERE/'customer_outcomes_workbench.py',release/'customer_outcomes_workbench.py')\n    source_pins[str(HERE/'customer_outcomes_workbench.py')]=sha(outcome_body)")
for name,fn in [('workbench_backend.py',backend),('ui_native_host.py',host),('freeze_ui.py',freezer)]:edit('work/ui-native-r57/'+name,fn)
rel='work/ui-native-r57/customer_outcomes_workbench.py';target=W/'candidate'/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes((W/'customer_outcomes_workbench.py').read_bytes());files[rel]={'baseSha256':None,'candidateSha256':hashlib.sha256(target.read_bytes()).hexdigest()}
native_files=dict(files)
def web_backend(t):
    t=replace(t,"const INBOX_ACTIONS=new Set(","const OUTCOME_ACTIONS=new Set(['customer_outcome_read','customer_outcome_save','customer_outcome_cancel','customer_outcome_report']);\nconst INBOX_ACTIONS=new Set(")
    t=replace(t,"    const keywordRead=action==='keyword_effect_read';","    const keywordRead=action==='keyword_effect_read';\n    const outcomeLocal=OUTCOME_ACTIONS.has(action),outcomeRead=outcomeLocal&&!['customer_outcome_save','customer_outcome_cancel'].includes(action);")
    t=replace(t,'const read=get||inboxLocal||','const read=get||outcomeLocal||inboxLocal||')
    t=replace(t,'const shortRead=get||inboxRead||','const shortRead=get||outcomeRead||inboxRead||')
    t=replace(t,"(remoteActions.has(action)||content||intentCorrection||action==='source_interactions_check')","(remoteActions.has(action)||content||intentCorrection||outcomeLocal||action==='source_interactions_check')")
    return replace(t,'  return {...safety,interactionInboxAction:',"  return {...safety,outcomeAction:(action,data)=>{if(!OUTCOME_ACTIONS.has(action))throw new WorkbenchError('客户结果操作无效','INPUT_INVALID');return request(action,data);},interactionInboxAction:")
def web_app(t):
    t=replace(t,"import * as customers from './pages/customers.mjs';","import * as customers from './pages/customers.mjs';\nimport {openOutcomeReport} from './pages/customer-outcomes.mjs';")
    t=replace(t,'const actions={interactionInboxAction:','const actions={outcomeAction:(action,data)=>backend.outcomeAction(action,data),interactionInboxAction:')
    t=replace(t,'state.keywordEffectUI=null;','state.keywordEffectUI=null;state.outcomesUI=null;')
    old=">AI 模型</button>`:''}</div>`+content;"
    t=replace(t,old,">AI 模型</button>`:''}${state.connection==='connected'&&state.session&&state.storeId?'<button type=\"button\" class=\"rp-tab\" data-open-outcome-report>结果与投入</button>':''}</div>`+content;")
    return replace(t,"  document.querySelectorAll('[data-nav]').forEach(b=>b.onclick=()=>navigate(b.dataset.nav));","  document.querySelectorAll('[data-nav]').forEach(b=>b.onclick=()=>navigate(b.dataset.nav));\n  app.querySelector('[data-open-outcome-report]')?.addEventListener('click',()=>openOutcomeReport(ctx));")
def web_customers(t):
    t=replace(t,"import {openHandoff} from './customer-handoff.mjs';","import {openHandoff} from './customer-handoff.mjs';\nimport {openOutcomeEditor} from './customer-outcomes.mjs';")
    old="${personalTools(state)?'<button type=\"button\" class=\"cs-secondary\" data-customer-handoff>客户备忘</button>':''}</div></aside>`;"
    t=replace(t,old,"${personalTools(state)?'<button type=\"button\" class=\"cs-secondary\" data-customer-handoff>客户备忘</button>':''}<button type=\"button\" class=\"cs-secondary\" data-customer-outcomes ${loading||failed?'disabled':''}>跟进结果</button></div></aside>`;")
    return replace(t,"  root.querySelector('[data-customer-handoff]')?.addEventListener('click',()=>handoff(false));","  root.querySelector('[data-customer-handoff]')?.addEventListener('click',()=>handoff(false));\n  root.querySelector('[data-customer-outcomes]')?.addEventListener('click',()=>{const id=currentId(),detail=ctx.state.customerDetail;if(id&&sameActor()&&actorMatches(ctx.state,detail)&&detail.id===id&&detail.status==='ready'&&detail.item?.id===id)openOutcomeEditor(ctx,id,ctx.state.activePlatform||'xiaohongshu');});")
U='work/ui-approved-implementation/ui-preview/'
for rel,fn in [('app.mjs',web_app),('backend.mjs',web_backend),('pages/customers.mjs',web_customers)]:edit(U+rel,fn)
rel=U+'pages/customer-outcomes.mjs';target=W/'candidate'/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes((W/'customer-outcomes.mjs').read_bytes());files[rel]={'baseSha256':None,'candidateSha256':hashlib.sha256(target.read_bytes()).hexdigest()}
(W/'BASE-NATIVE-HASHES.json').write_text(json.dumps(native_files,indent=2),encoding='utf-8')
(W/'CAS-FILES.json').write_text(json.dumps(files,indent=2),encoding='utf-8')
print(json.dumps(files,indent=2))
