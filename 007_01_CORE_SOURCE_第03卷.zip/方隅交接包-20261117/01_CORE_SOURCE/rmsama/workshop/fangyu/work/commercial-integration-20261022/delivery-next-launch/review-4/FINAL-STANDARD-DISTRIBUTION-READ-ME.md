# v72 标准版内部候选交接

已生成可执行的轻量 ZIP 和沿用原安装路线的自解压 EXE，并完成独立目录内真实 Native 首启、正常关闭和隔离后端验证。当前仍为内部 held 候选：`release_approved=false`、自动化关闭、对外发送关闭，中央身份、设备、账号授权保持原规则；尚未批准商业分发。

本目录：`C:/积木软件工坊/项目/方隅公寓客户版/work/commercial-integration-20261022/delivery-next-launch/review-4`

文件所在目录：`C:/积木软件工坊/项目/方隅公寓客户版/work/commercial-integration-20261022/delivery-next-launch/review-4/standard-held-clean-v72`

| 文件 | 大小 | SHA-256 |
| --- | ---: | --- |
| `FangyuWorkbench-standard-held-clean-v72.zip` | 269,874,772 字节 | `e6735a21731d37517e080a7352a874747d67ec82ada695c2a99b7282d59b1af3` |
| `FangyuWorkbenchSetup-standard-held-clean-v72.exe` | 281,243,616 字节 | `344f863c4427e8be90406bc5d3d5173f773db5546fe7be2783015ddb752ae2e7` |

ZIP 完整路径：`C:/积木软件工坊/项目/方隅公寓客户版/work/commercial-integration-20261022/delivery-next-launch/review-4/standard-held-clean-v72/FangyuWorkbench-standard-held-clean-v72.zip`

EXE 完整路径：`C:/积木软件工坊/项目/方隅公寓客户版/work/commercial-integration-20261022/delivery-next-launch/review-4/standard-held-clean-v72/FangyuWorkbenchSetup-standard-held-clean-v72.exe`

## 来源和复用路线

固定源为 root 的 `candidate-unified-v72`，完整源清单 3,152 文件、Native 196 资源。使用现有 PyInstaller onedir 和原 appended-ZIP 自解压安装器，安装器源码逐字未改。程序包必须包含完整公共 project、后端、三个平台 CLI、导出和知识等依赖；仅打包 release 目录无法闭合运行时。没有复制开发 venv。

派生公共 project 3,150 条目：去掉原机绑定和两个本机候选描述符，增加精确 held 标准契约。已有 project 仅修改公司分发配置、frozen 适配 guard 及其 RELEASE 清单；源/派生 SHA、完整差异均在候选目录 `SOURCE-DERIVED-PINS.json` 和 `SOURCE-DERIVED-DIFF.patch`。另有可搬运入口负责精确文件集合校验、受 pin 约束的源码加载，以及在独立 state 中复制已核 icon，避免原 .NET Icon 对过深路径的限制。未改 `sys.frozen`，未把源码验收冒充正式发布批准。

## 验证与证据

- `c72/RESULT.json`：真实干净 EXE 默认启动原 WebView2 Native，登录页 ready、字体 loaded、六张图无失败、窗口铺满；仅按自有 PID 正常关闭并退出。使用新建空资料目录、仅 Windows PATH，去掉 Python/venv 环境；未登录员工或平台。没有人工图审结论。
- `standard-held-sample-v72-qa2/relocation-qa/RESULT.json`：单独内部 QA runner 使用原 fixture profile，在程序自建 fresh UUID 根中验证真实后端、客户列表/详情、实际单行 XLSX 和知识导入/检索。七项拒绝负例全部通过：提前批准、开启自动化、解除发送 hold、旧 wrapper pin、缺失/篡改 manifest、篡改 wrapper 字节。
- `standard-held-clean-v72/PACKAGE-CONTENT-SCAN.json`：包内无私人数据库、原生产 binding、venv、模型权重或 FFmpeg binary。历史公共来源文档中的本机路径按 root 要求保留，它们不是运行依赖。
- `SLIM-WEBVIEW2-DETECTION.json`：原安装器实测检测到本机既有 WebView2 后直接返回，无下载、运行时安装或正式应用安装。
- `FINAL-STANDARD-DISTRIBUTION-HANDOFF.json`：交接索引固定上述实际文件 SHA、最终源 pins 和独立审查报告。此前已封元数据中的 `nativeStartEvidencePending=true` 由实际 `c72/RESULT.json` 取代；QA 记录中的未来 final pins 提示由本次 v72 固定源取代，审中母包不重写。

干净产品入口没有 SAMPLE、固定合成身份、合成 UI 数据或 `--runtime-smoke` / `--native-smoke` 执行支路；测试 runner 不作为对人的正式产品。

## 大小与普通电脑条件

轻量 ZIP 中公共 project 压缩后 238,984,876 字节，冻结 host 29,996,020 字节。保留的 v70 完整离线代表样本约 482.7 MB，其中微软离线 WebView2 约 213.0 MB、公共 project 238.8 MB、冻结 host 30.0 MB。两者源版本不同，差值只用于说明主要体积来源。

轻量版要求 Windows 10/11 x64、可用的 .NET 桌面环境和已安装 WebView2；原安装器在缺少 WebView2 时会提示补装，不会自动下载。无 Python、venv、本地模型或独显要求。包内不捆 GPL FFmpeg；视频能力须另外具备受核工具及字体，缺少或版本不符会报告不可用。第二台物理电脑、真实企业/平台登录和采集发送仍未验证。

正常安装层级已通过。更深的非标准测试层级曾出现 .NET 图标路径限制、Native 载入超时；红证据保留，没有靠加长超时或跳过 DOM 校验将其记为通过。

原安装器固定使用 `%LOCALAPPDATA%/fangyu-apartment-clientWorkspaceApp`；此实际默认目录未由本 agent 执行安装。ZIP 如作后续隔离核验，建议只解压到一个浅层专用目录，避免反复套入压缩包全名或深层证据目录。正常资料根为 `%LOCALAPPDATA%/FangyuWorkbenchStandard/data`，QA2 则仅使用独立 UUID 根，不能作为对人分发内容。

## 生产边界

本 agent 未写真实 N、生产数据库、session 或 binding，未安装到真实应用目录，未创建快捷方式、安装 WebView2、加载模型或调用实际外部平台。历史 v71 下一启动准备副本仍为 `INSTALLATION_REVIEWED=false`，仅供追溯；root 已独立准备并安装真实 v72。本交接不再使用 production profile 启动测试，保持 root 当前真实窗口与两个 PID。

v70 原 guard 拒绝、v71 未列缓存字节码执行、旧 QA 普通 data 污染，以及深目录失败均保留为红证据。后继闭包校验、缓存拒绝和 QA 隔离的独审结论以最终索引所列报告为准。
