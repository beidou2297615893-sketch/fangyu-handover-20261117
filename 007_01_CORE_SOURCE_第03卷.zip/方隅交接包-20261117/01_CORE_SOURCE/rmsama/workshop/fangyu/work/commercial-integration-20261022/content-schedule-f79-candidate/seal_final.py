from pathlib import Path
import datetime,hashlib,json,subprocess
W=Path(__file__).resolve().parent;P=W.parents[2];B=W.parent;S=W/'source-candidate';F=P/'work/parallel-integration-20261018/final-integration/candidate-unified-v79';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
put=lambda n,x:(W/n).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n','utf-8')
assert sha(W/'BASE-FINAL-PINS.json')=='3719840ea39dfe4874fe800f48fe9b58a92987649bd524a39b8074816b6efd64'
basepins=json.loads((W/'BASE-FINAL-PINS.json').read_text('utf-8'));assert sha(F/'UNIFIED-PINS.json')==basepins['unifiedPinsSha256'];assert sha(F/'STAGED.json')==basepins['stagedSha256']
source=json.loads((W/'SOURCE-FILES.json').read_text('utf-8'));base=json.loads((W/'BASE-HASHES.json').read_text('utf-8'));expected={r['path'] for r in source['files'] if r['beforeSha256']}
for row in source['files']:assert sha(W/'overlay'/row['path'])==row['afterSha256']==sha(S/row['path'])
assert {r for r,pin in base['files'].items() if sha(S/r)!=pin['sha256']}==expected
for row,pin in base['files'].items():assert sha(F/'project'/row)==pin['sha256']
qa=json.loads((W/'QA-INPUTS.json').read_text('utf-8'));stage=qa['stage'];R=Path(stage['release']);assert R.is_relative_to(S);assert sha(R/'RELEASE.json').lower()==stage['manifest_sha256'].lower()
official=json.loads((Path(json.loads((F/'STAGED.json').read_text('utf-8'))['release'])/'RELEASE.json').read_text('utf-8'));local=json.loads((R/'RELEASE.json').read_text('utf-8'));a={r['path'] for r in official['files']};b={r['path'] for r in local['files']}
missing=sorted(a-b);added=sorted(b-a);assert len(missing)==4 and len(added)==2 and len(b)==272,(missing,added)
assert all('license' in r.lower() for r in missing)
put('QA-STAGE-SCOPE.json',{'label':qa['label'],'privateQaNotFormalFreezeOrDistribution':True,'officialF79Resources':274,'candidateQaResources':272,'addedModules':added,'externalRuntimeLicenseResourcesNotCopiedByPrivateStage':missing,'originalReadPublicDependencyAndFactoryGuardsUsed':True})
cases=[];labels=set();failures=[]
for case in ('held','safety','contention','reopen','recover-claim','pressure50','pressure100','account-removed'):
 found=[]
 for folder in W.glob('factory-'+case+'-*'):
  if (folder/'RESULTS.json').is_file():
   r=json.loads((folder/'RESULTS.json').read_text('utf-8'));final=json.loads((folder/'FINAL.json').read_text('utf-8'))
   if r['status']=='PASS':found.append((folder,r,final))
  elif (folder/'FINAL.json').is_file():failures.append(str(folder.relative_to(W)))
 assert len(found)==1,(case,found)
 folder,r,final=found[0];assert final['status']=='PASS' and final['allOwnServersClosed'] and final['realExternalCalls']==0 and not final['blocked']
 labels.update(r['checks']);cases.append({'case':case,'directory':folder.name,'httpRequestsNotGroups':final['httpRequests'],'checks':r['checks'],'syntheticClickCallsNotRealPublication':r['syntheticClicks'],'resultsSha256':sha(folder/'RESULTS.json'),'finalCaptureSha256':sha(folder/'FINAL-CAPTURE.json'),'allOwnServersClosed':True})
baseline=next(W.glob('factory-baseline-*'));br=json.loads((baseline/'RESULTS.json').read_text('utf-8'));assert br['status']=='PASS_EXPECTED_BASELINE_RED'
baseline_final=json.loads((baseline/'FINAL.json').read_text('utf-8'));assert baseline_final['allOwnServersClosed'] and not baseline_final['blocked'] and br['syntheticClicks']==0
ui=json.loads((W/'UI-SERVER.json').read_text('utf-8'));U=Path(ui['directory']);ur=json.loads((U/'UI-RESULTS.json').read_text('utf-8'));uf=json.loads((U/'FINAL.json').read_text('utf-8'))
assert ur['status']=='PASS' and len(ur['results'])==13 and not ur['errors'];assert uf['status']=='STOPPED_OWN_HTTP_FIXTURE' and uf['realModelPlatformCalls']==0
assert all(x['effectiveMinFont']>=14.4 for x in ur['layout'])
ps="@(Get-CimInstance Win32_Process | Where-Object { $_.CommandLine -and $_.CommandLine.Contains('content-schedule-f79-candidate') -and !$_.CommandLine.Contains('seal_final.py') -and $_.Name -match 'python|node' } | Select-Object ProcessId,Name) | ConvertTo-Json -Compress"
raw=subprocess.check_output(['powershell','-NoProfile','-Command',ps],text=True,encoding='utf-8-sig').strip();live=json.loads(raw) if raw else [];assert not live,live
put('PROCESS-CLEANUP.json',{'allOwnServersAndBrowserClosed':True,'ownPythonNodeProcesses':live,'allFactoryFinallyCaptured':True,'nativeUserWindowOrProductionTouched':False})
old=B/'content-schedule-execution-candidate';assert sha(old/'SEALED.json')=='f2bb58eabc75948fa502eb50c8e20d79e2707dafba4ddb5c7db8ba740f03f0bf'
(W/'HANDOFF.md').write_text('''# F79 内容排程增量候选

仅合 overlay 清单 8 源：6 个现存文件小改与 2 个新模块。不要复制整份 source-candidate、旧 G11 文件或私有 QA release 到正式版本。真实 F79 是唯一 baseline，所有 before/after SHA 在 SOURCE-FILES.json。唯一实际冲突为 web backend 的长 return 行；仅向 F79 现有内容白名单插入六动作，移除这段即逐字恢复 F79。Native/backend 三方干净，账号删除 CAS、重新获客一行 passthrough、原账号模式/未知请求护栏全部保留。

可保存每项固定版本、账号身份、时刻和固定偏移时区；本人另行明确启用后，当前已登录 App 会话领取到期项，衔接原 publish_prepare/publish_confirm、approval、Store、模式租约。重复 tick 不重发；改稿/审核/账号身份/到期失效需重核；暂停、取消、恢复有逐项记录。原 unknown 只能核对原 intent/key，不更换请求。授权仅在 RAM，不保存 token；重开或选店变动后不能自动恢复授权。关闭 App 没有后台守护进程。原提醒仍清楚标注不执行发布。

本轮重跑原七场景与实际原 Native HTTP/完整 index/fit 的双宽 UI 13 检查；50/100 合成账号是原工厂离线压力，不证明平台吞吐或账号容量。另补 F79 原 Core CAS 删除自有合成账号后，到期 Native HTTP 在原 ACCOUNT_FORBIDDEN 前置门拒绝，Store/原计划/intent/key 不变、零派发。原 Native 删除入口未在此额外例中重测，F79 原删除业务/源码护栏未修改。该例首轮误预计内容组件错误码，完整红保留；新 v2 仅采用已证实更早的原 Native 错误码，零写/零派发断言不变，产品没改。

实际默认发布仍暂停：保存/启用/领取是排程状态，不能当成真实发布成功。正向例用原 OwnedPublishPort、原租约/观察器及明确合成授权和外部回执；自然企业/本人授权、实际平台 wire、验证码/登录、真实发布与平台容量仍未验。生产新内容生成服务原样，不调用模型、没有费用。

私有 QA stage 272 资源：相对正式 F79 274，新增两个模块、未拷原四个外部 runtime 许可文件。原 verify/read_public/依赖校验/create_backend 真实执行；此 QA 不称正式冻结或分发闭包。root 后续须正常完整 freeze。

800 个受保护 F79 文件逐字一致，Native cache/factory 与平台账号 dispatch/identity AST 一致。所有源码原换行保留，全部自有进程/服务关闭。S/F/N/outputs、本人会话、生产数据均未写，真实发布/平台/模型调用为零。
''','utf-8')
summary={'status':'PASS_SOURCE_ONLY_F79_CONTENT_SCHEDULE_ADAPTATION','base':'exact F79','rootBasePinsSha256':sha(W/'BASE-FINAL-PINS.json'),'sourceFiles':8,'existingFilesChanged':6,'newModules':2,'actualThreeWayConflicts':1,'conflictResolution':'exact six schedule action names into F79 web whitelist only','qaStage':stage['release_id'],'qaManifestSha256':sha(R/'RELEASE.json'),'qaResources':272,'notFormalFreezeOrDistribution':True,'scenarioRuns':len(cases),'uniqueCheckLabelsNotHttpRequests':len(labels),'httpRequestsNotGroups':sum(r['httpRequestsNotGroups'] for r in cases),'scenarios':cases,'baselineF79ExpectedNoQueueRed':{'directory':baseline.name,'resultsSha256':sha(baseline/'RESULTS.json'),'syntheticDispatch':0},'ui':{'directory':U.name,'actualOriginalNativeHttpIndexFit':True,'developmentHeadless':True,'checks':13,'widths':[1255,390],'minimumEffectiveFont':min(x['effectiveMinFont'] for x in ur['layout'])},'protectedF79Files':800,'coreRuntimeAccountDeleteCasFreshModeUnknownGuardsBytePreserved':True,'allOwnProcessesClosed':True,'realPlatformModelCalls':0,'realPublication':0,'knownFixtureRedPreserved':failures,'limitations':['Default original publishing hold remains; no natural cloud/device/person grant verified','Synthetic original OwnedPublishPort receipts are not real platform acceptance','Current App-session poll only; no closed-App daemon or DST database','Private QA stage omits four external runtime license resources; root must normal-freeze full release','Deleted-account extra case uses original Core CAS plus real Native due refusal, not Native delete entry retest'],'writeProductProductionInstall':False,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
put('SUMMARY.json',summary)
put('FINAL-RECEIPT.json',{**summary,'evidence':{n:sha(W/n) for n in ['SUMMARY.json','SOURCE-FILES.json','CHANGES.patch','MERGE-RESOLUTION.json','PROTECTED-SOURCE-CHECK.json','QA-STAGE-SCOPE.json','PROCESS-CLEANUP.json']},'oldG11SourceSealUnchanged':True,'writeStopped':True})
members=[{'path':p.relative_to(W).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(W.rglob('*')) if p.is_file() and not p.is_relative_to(S) and p.name!='SEALED.json']
put('SEALED.json',{'status':'SEALED_READ_ONLY','finalReceiptSha256':sha(W/'FINAL-RECEIPT.json'),'summarySha256':sha(W/'SUMMARY.json'),'sourcePinsSha256':sha(W/'SOURCE-FILES.json'),'patchSha256':sha(W/'CHANGES.patch'),'membersOutsideReproducibleSourceCopy':members,'sourceCopyOnlyEightChangedInputsBoundBySourceManifestAndOriginalBaseHashes':True,'writeStopped':True})
print(json.dumps({'receipt':sha(W/'FINAL-RECEIPT.json'),'seal':sha(W/'SEALED.json'),'sourcePins':sha(W/'SOURCE-FILES.json'),'patch':sha(W/'CHANGES.patch'),'summary':sha(W/'SUMMARY.json'),'scenarios':len(cases),'httpRequestsNotGroups':summary['httpRequestsNotGroups'],'uiChecks':13},ensure_ascii=False))
