// Fixed-account queue UI. The original Native publication command owns sending.
const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const LABEL={planned:'尚未启用',armed:'已启用本次计划',claimed:'正在处理原请求',blocked:'未能执行',unknown:'原发布结果待核对',published:'已发布并有回执',not_sent:'已确认未发出',needs_review:'原审批已失效',paused:'已暂停',cancelled:'已取消'};
const loops=new WeakMap();
const key=state=>JSON.stringify([state.authEpoch||0,state.session?.user?.username||state.user||'',state.storeId||'',state.activePlatform||'xiaohongshu']);
const id=()=>globalThis.crypto?.randomUUID?.().replaceAll('-','')||('cs'+Date.now()+Math.random().toString(36).slice(2));
const date=(v,zone)=>new Intl.DateTimeFormat('zh-CN',{timeZone:zone==='Asia/Shanghai'?'Asia/Shanghai':'UTC',year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',hour12:false}).format(new Date(v));
const name=a=>a?.platformNickname||a?.platform_nickname||a?.name||a?.id||'当前账号';
const button=(label,action,extra='',disabled=false)=>`<button type="button" class="co-button" data-cs-action="${action}" ${extra} ${disabled?'disabled':''}>${esc(label)}</button>`;
function ui(u){return u.scheduleExecutionUI??={scope:u.scope,rows:[],loaded:false,loading:false,pending:'',error:'',notice:'',draftId:'',plannedAt:'',timezone:'Asia/Shanghai',graceMinutes:15,editor:false,uncertain:null,show:30};}
function detail(row){return `data-id="${esc(row.id)}" data-account="${esc(row.scope.account_id)}"`;}
function when(row){
  if(row.timezone==='Asia/Shanghai'||row.timezone==='UTC')return `${date(row.plannedAt,row.timezone)} ${row.timezone==='Asia/Shanghai'?'北京时间':'UTC'}`;
  return `${row.localPlannedAt?.replace('T',' ')||row.plannedAt}（${row.timezone} 固定偏移）`;
}
export function renderSchedule(state,u,w,accounts){
  const v=ui(u),disabled=!!u.pending||!!v.pending||!!v.uncertain,approved=(w?.drafts||[]).filter(d=>d.status==='approved'),current=accounts.find(a=>a.id===u.accountId);
  const rows=[...v.rows].sort((a,b)=>a.plannedAt.localeCompare(b.plannedAt));
  return `<style>.cs-queue{min-width:0;overflow-wrap:anywhere;font-size:17px}.cs-queue .co-small,.cs-queue .co-note,.cs-queue .co-section-title p,.cs-queue .co-badge,.cs-queue time,.cs-queue .co-button,.cs-queue summary{font-size:17px}.cs-queue .co-section-title{flex-wrap:wrap}.cs-queue .co-badge{white-space:normal}.cs-queue .co-schedules article{min-width:0}.cs-queue .co-note{overflow-wrap:anywhere}</style><section class="cs-queue" aria-label="固定账号内容日历"><div class="co-section-title"><div><h2>内容日历</h2><p>每项固定稿件版本、发布账号和执行时刻。</p></div>${button('读取计划','read','',disabled)}</div>
  <p class="co-note">保存计划不会发布。本人明确启用后，软件在当前登录会话检查到期项目；关闭、退出或切换门店后需重新启用。实际发布授权或协议未接通时会停止并说明原因。</p>
  ${v.error?`<p class="co-feedback co-error" role="alert">${esc(v.error)}</p>`:''}${v.notice?`<p class="co-feedback co-success" role="status">${esc(v.notice)}</p>`:''}${v.pending?`<p class="co-working" role="status">${esc(v.pending)}</p>`:''}
  ${v.uncertain?`<p class="co-note">上次操作回执未确认，原计划与请求已保留。${button('核对原操作','check-original')}${v.uncertain.notFound?button('按原请求重试','retry-original'):''}</p>`:''}
  <details class="co-schedule-editor" data-cs-editor ${v.editor?'open':''}><summary>为当前账号保存执行计划</summary><p class="co-small">固定账号：<strong>${esc(name(current))}</strong>。其他账号请先在上方切换，内容和审批不会复制过去。</p>
  <label class="co-field"><span>已人工核对的稿件</span><select data-cs-field="draftId" ${disabled?'disabled':''}><option value="">请选择本账号稿件</option>${approved.map(d=>`<option value="${esc(d.id)}" ${v.draftId===d.id?'selected':''}>${esc(d.title)} · 版本 ${d.version}</option>`).join('')}</select></label>
  <label class="co-field"><span>计划时刻</span><input type="datetime-local" data-cs-field="plannedAt" value="${esc(v.plannedAt)}" ${disabled?'disabled':''}></label>
  <label class="co-field"><span>时区（固定偏移）</span><select data-cs-field="timezone" ${disabled?'disabled':''}>${[['Asia/Shanghai','北京时间 UTC+08:00'],['UTC','UTC+00:00'],['UTC-05:00','UTC-05:00'],['UTC+01:00','UTC+01:00']].map(([value,label])=>`<option value="${value}" ${v.timezone===value?'selected':''}>${label}</option>`).join('')}</select></label>
  <label class="co-field"><span>到期宽限（分钟）</span><input type="number" min="1" max="1440" data-cs-field="graceMinutes" value="${Number(v.graceMinutes)||15}" ${disabled?'disabled':''}></label>
  <p class="co-small">超过宽限不会补发；不自动换算夏令时。改稿、重审或账号身份变化会使原授权失效。</p>${button('保存待确认计划','plan','',disabled||!approved.length)}</details>
  <div class="co-actions">${button('检查已启用的到期项','due','',disabled||!rows.some(r=>r.state==='armed'&&r.liveSessionEnabled))}<span class="co-small">共 ${rows.length} 项 · ${accounts.length} 个当前可访问账号</span></div>
  ${!v.loaded?'<p class="co-small">读取后查看本门店账号的固定计划。</p>':!rows.length?'<p class="co-small">还没有执行计划。旧提醒保留在下方。</p>':`<div class="co-schedules">${rows.slice(0,v.show).map(row=>`<article data-cs-row="${esc(row.id)}"><time>${esc(when(row))}</time><strong>${esc(row.snapshot.title)}</strong><span class="co-small">${esc(row.snapshot.accountNickname)} · 版本 ${row.draftVersion}</span><span class="co-badge">${esc(LABEL[row.state]||'待核对')}${row.needsSessionConfirmation?' · 需本会话重新确认':''}</span><p>${esc(row.message||'')}</p><div class="co-row-actions">${['planned','paused','blocked','not_sent'].includes(row.state)||row.state==='armed'&&row.needsSessionConfirmation?button('核对并启用','arm',detail(row),disabled):''}${row.state==='unknown'?button('仅核对原发布','reconcile',detail(row),disabled):''}${!['published','cancelled'].includes(row.state)?button('暂停','pause',detail(row),disabled)+button('取消后续执行','cancel',detail(row),disabled):''}${button('逐项记录','events',detail(row),disabled)}</div></article>`).join('')}</div>${rows.length>v.show?button('继续显示计划','more'):''}`}
  </section>`;
}
export function bindSchedule(root,ctx,u,w,accounts){
  const state=ctx.state,v=ui(u),scope=key(state),accountIds=new Set(accounts.map(a=>a.id));let disposed=false;
  const valid=()=>key(state)===scope&&state.contentOperationsUI===u&&ui(u)===v;
  const update=fn=>{if(valid()){if(typeof ctx.update==='function')ctx.update(fn);else fn();}};
  const base=accountId=>({storeId:state.storeId,platform:state.activePlatform||'xiaohongshu',accountId});
  const accept=(row,accountId)=>{if(!row||row.owner!==(state.session?.user?.username||state.user)||row.scope?.store_id!==state.storeId||row.scope?.account_id!==accountId||row.scope?.platform!==(state.activePlatform||'xiaohongshu'))throw Error('计划归属已变化，请重新读取。');return row;};
  const send=async(action,payload,{poll=false,replay=false}={})=>{
    if(!valid()||!accountIds.has(payload.accountId)||v.pending||v.uncertain&&!replay&&!action.endsWith('_read'))return null;
    const capture=structuredClone(payload);if(!action.endsWith('_read')&&!capture.requestId)capture.requestId=id();
    if(!poll)update(()=>{v.pending='正在核对原计划…';v.error='';});else v.pending='正在检查到期计划…';
    try{
      const answer=await ctx.contentAction(action,capture);if(!valid())return null;
      if(answer.scheduleContract!=='fangyu-content-schedule-execution-v1')throw Error('日历执行组件尚未完整接通，请正常更新。');
      if(answer.schedule){const row=accept(answer.schedule,capture.accountId);v.rows=[...v.rows.filter(r=>r.id!==row.id),row];}
      if(Array.isArray(answer.schedules))v.rows=[...v.rows.filter(r=>r.scope.account_id!==capture.accountId),...answer.schedules.map(r=>accept(r,capture.accountId))];
      return answer;
    }catch(error){
      if(valid()){
        v.error=error.message||'本次操作未确认。';
        if(!action.endsWith('_read')&&(!error.status||error.status>=500))v.uncertain={action,payload:capture};
      }
      return null;
    }finally{if(valid()){v.pending='';if(!poll)update(()=>{});}}
  };
  const readAll=async()=>{if(!valid()||v.loading||v.pending)return;v.loading=true;try{for(const account of accounts){if(!valid())return;await send('content_schedule_read',base(account.id),{poll:true});}if(valid())v.loaded=true;}finally{if(valid()){v.loading=false;update(()=>{});}}};
  const due=async()=>{
    if(!valid()||v.pending||v.uncertain||ctx.hasUnconfirmed?.())return;
    for(const row of [...v.rows]){
      if(!valid()||v.uncertain)return;
      if(row.state==='armed'&&row.liveSessionEnabled&&new Date(row.plannedAt).getTime()<=Date.now())await send('content_schedule_tick',{...base(row.scope.account_id),scheduleId:row.id},{poll:true});
    }
    update(()=>{});
  };
  const ensureLoop=()=>{
    const old=loops.get(state);if(old?.scope===scope)return;
    if(old)clearTimeout(old.timer);
    const loop={scope,timer:null};loops.set(state,loop);
    const poll=async()=>{if(!valid()){loops.delete(state);return;}await due();if(valid())loop.timer=setTimeout(poll,15000);else loops.delete(state);};
    loop.timer=setTimeout(poll,15000);
  };
  root.querySelector('[data-cs-editor]')?.addEventListener('toggle',e=>{v.editor=e.target.open;});
  root.querySelectorAll('[data-cs-field]').forEach(el=>el.addEventListener(el.tagName==='SELECT'?'change':'input',()=>{v[el.dataset.csField]=el.value;}));
  root.querySelectorAll('[data-cs-action]').forEach(el=>el.addEventListener('click',async()=>{
    const action=el.dataset.csAction,row=v.rows.find(r=>r.id===el.dataset.id&&r.scope.account_id===el.dataset.account);
    if(action==='read'){await readAll();ensureLoop();return;}
    if(action==='more'){update(()=>{v.show+=30;});return;}
    if(action==='due'){await due();return;}
    if(action==='plan'){
      const draft=(w?.drafts||[]).find(d=>d.id===v.draftId&&d.status==='approved');
      if(!draft||!v.plannedAt){update(()=>{v.error='请选择本账号已核对稿件和执行时刻。';});return;}
      const offset=v.timezone==='Asia/Shanghai'?'+08:00':v.timezone==='UTC'?'+00:00':v.timezone.slice(3);
      const answer=await send('content_schedule_plan',{...base(u.accountId),draftId:draft.id,draftVersion:draft.version,plannedAt:v.plannedAt+(v.plannedAt.length===16?':00':'')+offset,timezone:v.timezone,graceMinutes:Number(v.graceMinutes)});
      if(answer)update(()=>{v.notice='固定计划已保存，尚未启用；请逐项核对并启用。';v.editor=false;v.loaded=true;});return;
    }
    if(action==='check-original'&&v.uncertain){
      const saved=v.uncertain,p=saved.payload;
      const answer=await send('content_schedule_read',{...base(p.accountId),...(p.scheduleId?{scheduleId:p.scheduleId}:{requestId:p.requestId})},{replay:true});
      if(answer)update(()=>{if(answer.schedule){v.uncertain=null;v.notice='已读取原计划和原发布状态，没有重新派发。';}else{v.uncertain.notFound=true;v.notice='暂未找到原保存回执，可再次核对或显式按原请求重试。';}});return;
    }
    if(action==='retry-original'&&v.uncertain?.notFound){const saved=v.uncertain;const answer=await send(saved.action,saved.payload,{replay:true});if(answer)update(()=>{v.uncertain=null;v.notice='已按原编号核对保存结果。';});return;}
    if(!row)return;
    if(action==='events'){const answer=await send('content_schedule_read',{...base(row.scope.account_id),scheduleId:row.id});if(answer&&valid())ctx.modal?.({title:'本项执行记录',html:`<div class="co-schedules">${(answer.events||[]).map(e=>`<article><time>${esc(e.at)}</time><strong>${esc(LABEL[e.state]||'待核对')}</strong><p>${esc(e.message)}</p></article>`).join('')}</div>`,confirmLabel:'知道了',onConfirm:()=>{}});return;}
    if(action==='arm'){
      ctx.modal?.({title:'核对并启用本次到期执行',html:`<p><strong>${esc(row.snapshot.accountNickname)}</strong> · ${esc(row.snapshot.title)} · 固定版本 ${row.draftVersion}</p><p>${esc(when(row))}，宽限 ${row.graceMinutes} 分钟。</p><p>确认后授权软件在当前登录会话到期尝试单次执行原发布流程。请核对正文、图片顺序、授权与事实；实际企业发布权限和协议未接通时不会发出。错过宽限或改稿后须重新确认。</p><p style="white-space:pre-wrap">${esc(row.snapshot.body)}</p>`,confirmLabel:'已核对，启用本次计划',onConfirm:async()=>{
        if(!valid())return false;const answer=await send('content_schedule_arm',{...base(row.scope.account_id),scheduleId:row.id,expectedScheduleRevision:row.revision,snapshotDigest:row.snapshot.snapshotDigest,accountUid:row.snapshot.accountUid,humanConfirmed:true,futureExecutionConfirmed:true});
        if(answer){ensureLoop();update(()=>{v.notice='已启用本次固定计划；关闭或切换门店后需重新确认。';});}return !!answer;}});return;
    }
    if(action==='reconcile'){await send('content_schedule_reconcile',{...base(row.scope.account_id),scheduleId:row.id,requestId:row.publishRequestId});return;}
    if(action==='pause'||action==='cancel')await send('content_schedule_control',{...base(row.scope.account_id),scheduleId:row.id,expectedScheduleRevision:row.revision,operation:action});
  }));
  if(u.tab==='drafts'&&!u.reviewMode&&w&&!v.loaded&&!v.loading&&!v.pending&&!v.error)queueMicrotask(()=>{if(!disposed&&valid())readAll();});
  if(v.rows.some(r=>r.state==='armed'&&r.liveSessionEnabled))ensureLoop();
  return ()=>{disposed=true;};
}
