"""Relocatable standard Windows entry over the unchanged fixed r57 host.

This independently installed application initializes only its own empty data
directory. It grants no enterprise/device/platform permissions. Existing local
production binding and sessions are never consulted or copied.
"""
from pathlib import Path, PurePosixPath
import argparse, hashlib, http.client, importlib.util, importlib.machinery, json, os, socket, stat, sys
import threading
import time, uuid
sys.dont_write_bytecode = True
RELEASE_ID = 'ui-r57-20261023T095243Z-1c9a271f'
RELEASE_SHA = 'fb27101405e99ff0bd90cf0802477951c80372e06128b4d8dacf3496fecf5fd4'
CLOSURE_SHA = 'ca4037a8539bd2a4ae3d64b4453859b73905e360442eebcef8de9d7eeedb881c'

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def exact(path, expected):
    for item in (path, *path.parents):
        info = item.lstat()
        if item.is_symlink() or getattr(info, 'st_file_attributes', 0) & 1024:
            raise RuntimeError('程序路径不能包含链接或重定向')
    before = path.stat()
    if not stat.S_ISREG(before.st_mode) or before.st_nlink != 1:
        raise RuntimeError('程序文件类型无效')
    raw = path.read_bytes()
    after = path.stat()
    if (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns) != (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns) or sha(raw) != expected:
        raise RuntimeError('程序文件校验失败')
    return raw

def output(value, path=None):
    raw = json.dumps(value, ensure_ascii=False, indent=2) + '\n'
    if path:
        with Path(path).open('x', encoding='utf-8') as stream:
            stream.write(raw)
    elif sys.stdout is not None:
        print(raw)

def load_host(root):
    project = root / 'project'
    closure = json.loads(exact(project / 'SHIPPED-PINS.json', CLOSURE_SHA))
    names = set()
    for row in closure['files']:
        relative = PurePosixPath(row['path'])
        if relative.is_absolute() or '..' in relative.parts or ':' in str(relative) or ('\\' in str(relative)) or (str(relative) in names):
            raise RuntimeError('程序清单路径无效')
        names.add(str(relative))
        raw = exact(project / relative, row['sha256'])
        if len(raw) != row['bytes']:
            raise RuntimeError('程序文件长度不匹配')
    actual = set()
    for path in project.rglob('*'):
        info = path.lstat()
        if path.is_symlink() or getattr(info, 'st_file_attributes', 0) & 1024:
            raise RuntimeError('程序目录包含未允许的链接或重定向')
        if '__pycache__' in path.relative_to(project).parts or path.suffix.lower() in ('.pyc', '.pyo'):
            raise RuntimeError('程序目录包含未允许的 Python 缓存代码')
        if path.is_file():
            actual.add(path.relative_to(project).as_posix())
    if actual != names | {'SHIPPED-PINS.json'}:
        raise RuntimeError('程序实际文件集合与完整清单不一致')
    code_pins = {row['path']: row for row in closure['files']}
    original_get_code = importlib.machinery.SourceFileLoader.get_code

    def source_only(loader, fullname):
        path = Path(loader.path).absolute()
        if path.is_relative_to(project):
            relative = path.relative_to(project).as_posix()
            row = code_pins.get(relative)
            if row is None or path.suffix.lower() != '.py':
                raise ImportError('未允许的程序代码来源')
            raw = exact(path, row['sha256'])
            return compile(raw, str(path), 'exec', dont_inherit=True, optimize=0)
        return original_get_code(loader, fullname)
    importlib.machinery.SourceFileLoader.get_code = source_only

    def code_audit(event, args):
        if event == 'open' and isinstance(args[0], (str, bytes, os.PathLike)):
            path = Path(os.fsdecode(args[0])).absolute()
            if path.is_relative_to(project) and path.suffix.lower() in ('.pyc', '.pyo'):
                raise PermissionError('程序不接受缓存字节码')
        if event == 'import' and len(args) > 1 and isinstance(args[1], str):
            path = Path(args[1]).absolute()
            if path.is_relative_to(project) and path.suffix.lower() in ('.pyd', '.dll', '.pyc', '.pyo'):
                row = code_pins.get(path.relative_to(project).as_posix())
                if row is None or path.suffix.lower() in ('.pyc', '.pyo'):
                    raise ImportError('未允许的扩展程序来源')
                exact(path, row['sha256'])
    sys.addaudithook(code_audit)
    release = project / 'work/ui-native-r57/releases' / RELEASE_ID
    raw = exact(release / 'RELEASE.json', RELEASE_SHA)
    manifest = json.loads(raw)
    entry = next((row for row in manifest['files'] if row['path'] == 'ui_native_host.py'))
    module = importlib.util.module_from_spec(importlib.util.spec_from_loader('fangyu_standard_native_host', loader=None))
    module.__file__ = str(release / 'ui_native_host.py')
    sys.modules[module.__name__] = module
    exec(compile(exact(release / 'ui_native_host.py', entry['sha256'].lower()), module.__file__, 'exec'), module.__dict__)
    return (module, project, release, closure)

def short_native_icon(release, state):
    """Keep .NET's legacy Icon file constructor below its path length limit."""
    manifest = json.loads(exact(release / 'RELEASE.json', RELEASE_SHA))
    row = next((item for item in manifest['files'] if item['path'] == 'resources/brand.ico'), None)
    if row is None:
        return
    source = release / 'resources/brand.ico'
    raw = exact(source, row['sha256'].lower())
    target = state / 'window.ico'
    if target.exists():
        exact(target, sha(raw))
    else:
        with target.open('xb') as stream:
            stream.write(raw)
        exact(target, sha(raw))
    if len(str(target)) >= 248:
        raise RuntimeError('Windows 用户资料路径过长，请使用标准用户资料目录')
    import webview
    original = webview.start

    def start(*args, **kwargs):
        if kwargs.get('icon') == str(source):
            kwargs['icon'] = str(target)
        return original(*args, **kwargs)
    webview.start = start

def own_directories():
    local = os.environ.get('LOCALAPPDATA')
    if not local or not Path(local).is_absolute():
        raise RuntimeError('Windows 用户资料目录不可用')
    root = Path(local) / 'FangyuWorkbenchStandard'
    for folder in (root, root / 'data', root / 'state'):
        folder.mkdir(parents=True, exist_ok=True)
        for item in (folder, *folder.parents):
            if item.is_symlink() or getattr(item.lstat(), 'st_file_attributes', 0) & 1024:
                raise RuntimeError('工作资料目录不能重定向')
    return (root / 'data', root / 'state')

def main():
    root = Path(sys.executable).resolve().parent if getattr(sys, 'frozen', False) else Path(__file__).resolve().parent
    parser = argparse.ArgumentParser(description='方隅工作台')
    group = parser.add_mutually_exclusive_group()
    group.add_argument('--check', action='store_true')
    group.add_argument('--self-test', action='store_true')
    parser.add_argument('--result-file')
    args = parser.parse_args()
    host, project, release, closure = load_host(root)
    data, state = own_directories()
    if args.check or args.self_test:
        argv = ['--check'] if args.check else ['--self-test']
        code = host.main(release, RELEASE_SHA, state, argv, project_root=project, data_dir=data)
        if code:
            raise RuntimeError('启动检查未通过')
        output({'status': 'PASS', 'releaseId': RELEASE_ID, 'frozen': getattr(sys, 'frozen', False) is True, 'internalStandardCandidate': True, 'commercialDistributionApproved': False, 'action': argv[0], 'closureFilesVerified': len(closure['files'])}, args.result_file)
        return 0
    short_native_icon(release, state)
    return host.main(release, RELEASE_SHA, state, [], project_root=project, data_dir=data)

import traceback,threading,time,http.client
from copy import deepcopy
if hasattr(sys.stdout,'reconfigure'):sys.stdout.reconfigure(encoding='utf-8')
ACTUAL_COMPILED=getattr(sys,'frozen',False) is True
B=Path(__file__).resolve().parent;T=B.parent;W=B/'payload';OUT=T/'old-stage-evidence-resume';OUT.mkdir()
DATA=T/'existing-data';assert DATA.is_dir();sys.frozen=True;sys.executable=str(W/'FangyuWorkbench.exe')
backend=server=None;thread=None;passed=False
save=lambda n,v:(OUT/n).write_bytes((json.dumps(v,ensure_ascii=False,indent=2)+'\n').encode())
def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m);return m
def audit(event,args):
    if event in ('subprocess.Popen','os.system','os.startfile','os.posix_spawn'):raise RuntimeError('No platform/native/process')
    if event in ('socket.connect','socket.bind') and (not isinstance(args[1],tuple) or args[1][0] not in ('127.0.0.1','::1')):raise RuntimeError('Loopback only')
    if event=='sqlite3.connect' and not Path(args[0]).resolve().is_relative_to(T):raise RuntimeError('Own DB only')
sys.addaudithook(audit)
port=json.loads((T/'ORIGINAL-CLOUD-BRIDGE.json').read_bytes())['port'];device_calls=[]
def actual_cloud(operation,data,token=''):
    c=http.client.HTTPConnection('127.0.0.1',port,timeout=30);c.request('POST','/call',json.dumps({'operation':operation,'data':data,'token':token}).encode(),{'Content-Type':'application/json'})
    r=c.getresponse();out=json.loads(r.read());c.close();assert r.status==200,out
    if out['status']!=200:
        from assistant.transport import CloudError
        raise CloudError(out['status'],str(out.get('data',{}).get('error','own-cloud-rejected')))
    return out['data']
class OwnOriginalCloud:
    def __init__(self,*a,**k):pass
    def call(self,operation,data,credential):device_calls.append(operation);return actual_cloud(operation,data,credential)
    def close(self):pass
try:
    host,project,release,closure=load_host(W);manifest,files=host.verify_release(release,RELEASE_SHA)
    host.verify_backend_dependencies(release,files,project)
    fixture=load('own_old_ui_cloud',W/'qa-fixtures/cloud_fixture.py')
    cloud=fixture.CloudStandin(json.loads((W/'qa-fixtures/compiled-fixture.json').read_bytes()))
    company=json.loads((project/'work/app/company.json').read_bytes());assert company['releaseVersion']=='1.1.8-pilot.1'
    integration=load('integrations',release/'resources/platform-runtime/vendor-src/integrations.py')
    def transport(*a,**k):v=cloud(*a,**k);v['environment_id']=company['managedWorkspace']['environment_id'];return v
    integration.request_json=transport
    backend=host.create_backend(release,files,project_root=project,data_dir=DATA,company=company)
    runtime=backend.platform_runtime;core=backend.core;runtime.server._configure_bundled();runtime._platform_setup=True
    server=host.StaticServer(release,files,backend=backend,cookie_name='own_old_binding_session')
    thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
    origin='http://127.0.0.1:'+str(server.server_port);headers={}
    def request(action,data=None):
        c=http.client.HTTPConnection('127.0.0.1',server.server_port,timeout=90)
        c.request('GET' if action is None else 'POST','/api/workbench/bootstrap' if action is None else '/api/workbench',
            None if action is None else json.dumps({'action':action,'data':data or {}}).encode(),headers)
        r=c.getresponse();out=json.loads(r.read());h=dict(r.getheaders());c.close();return r.status,out,h
    _,boot,_=request(None);headers={'Content-Type':'application/json','Origin':origin,'X-Fangyu-CSRF':boot['csrfToken']}
    status,logged,h=request('login',{'username':'fixture-admin','password':fixture.PASSWORD});assert status==200,logged
    headers['Cookie']=h['Set-Cookie'].split(';',1)[0];user=core.session(headers['Cookie'].split('=',1)[1]);store=cloud.first_store
    runtime.service.cloud_factory=OwnOriginalCloud
    before_saved=runtime.service.vault.read();assert before_saved['state']=='bound'
    before_vault_sha=hashlib.sha256(runtime.service.vault.path.read_bytes()).hexdigest()
    runtime.service.start()
    deadline=time.monotonic()+15
    while device_calls.count('device_poll')<1 and time.monotonic()<deadline:time.sleep(.03)
    assert device_calls.count('device_poll')>=1,runtime.service.status()
    assert runtime.service.state in ('online','held'),runtime.service.status()
    assert hashlib.sha256(runtime.service.vault.path.read_bytes()).hexdigest()==before_vault_sha
    saved=runtime.service.vault.read();assert saved['state']=='bound'
    account={'id':'owned-existing-account','tenant_id':user['tenant_id'],'cloud_owner':user['username'],
        'store_id':store,'platform':'douyin','status':'ready','name':'原合成账号','platform_uid':'9007199254741999'}
    task={'id':'owned-existing-task','tenant_id':user['tenant_id'],'cloud_owner':user['username'],
        'account_id':account['id'],'store_id':store,'platform':'douyin','status':'paused','pause_reason':'owned_saved_checkpoint',
        'scope':'search_comments','keywords':['上海古北'],'pipeline':{'keyword_index':2,'search_page':1,'cursor':'owned-original-cursor'},
        'sequence_status':'stopped','last_message':'原合成断点保留','accumulated':23}
    core.store.put('accounts',account);core.store.put('tasks',task)
    assert core._import([{'platform':'douyin','source_type':'comment','source_id':'comment:923456789012345678',
        'comment_id':'923456789012345678','note_url':'https://www.douyin.com/video/1234567890123456789',
        'text':'合成历史求租评论','author':'合成客户','author_id':'9876543210123456','task_id':task['id']}],user['tenant_id'],user)['imported']==1
    lead=core.store.list('leads',user['tenant_id'])[0];lead.update(ai_intent={'status':'graded','level':'high','reason':'原合成判断'},manual_intent={'status':'graded','level':'medium','reason':'原人工更正'},reply_status='unknown');core.store.put('leads',lead)
    core.store.put('replies',{'id':'owned-existing-reply','tenant_id':user['tenant_id'],'cloud_owner':user['username'],
        'lead_id':lead['id'],'account_id':account['id'],'status':'unknown','text':'合成未确认回复，禁止自动重发'})
    core.store.put('douyin_customer_task_read_pages_v1',{'id':'owned-existing-read-key','tenant_id':user['tenant_id'],
        'cloud_owner':user['username'],'state':'started','logical_key':'owned-original-key','binding':{'task':task['id']}})
    entities=('accounts','tasks','leads','replies','ai_cache','rental_assessments_v1','douyin_customer_task_read_pages_v1')
    def projection():
        with core.store.connect() as db:
            return [tuple(r) for r in db.execute('SELECT entity,id,tenant_id,body FROM records WHERE entity IN ('+','.join('?' for _ in entities)+') ORDER BY entity,id',entities)]
    protected=projection();vault_path=runtime.service.vault.path;vault_sha=hashlib.sha256(vault_path.read_bytes()).hexdigest()
    device_id=saved['device']['id'];token_sha=hashlib.sha256(saved['token'].encode()).hexdigest()
    assert runtime.service.stop(timeout=15) and projection()==protected
    assert hashlib.sha256(vault_path.read_bytes()).hexdigest()==vault_sha
    root=T/'existing-project';state=root/'work/ui-native-r57/state';state.mkdir(parents=True)
    descriptor=state/'production-workspace.json'
    binding={'schema':'fangyu-production-workspace-v1','company_id':company['id'],'data_dir':str(DATA),
        'device_id':device_id,'owner':saved['device']['owner'],'environment_id':company['managedWorkspace']['environment_id']}
    descriptor.write_bytes((json.dumps(binding,ensure_ascii=False,indent=2)+'\n').encode())
    receipt={'status':'OLD_ACTUAL_SERVICE_BOUND_AND_STOPPED','actualCompiledExe':ACTUAL_COMPILED,
        'sourceFrozenRepresentativeOnly':not ACTUAL_COMPILED,'version':'1.1.8-pilot.1','dataDir':str(DATA),
        'existingRoot':str(root),'bindingSha256':hashlib.sha256(descriptor.read_bytes()).hexdigest(),
        'vaultSha256':vault_sha,'deviceId':device_id,'tokenSha256':token_sha,'owner':saved['device']['owner'],
        'protectedRowsSha256':hashlib.sha256(json.dumps(protected,ensure_ascii=False,separators=(',',':')).encode()).hexdigest(),
        'protectedEntities':entities,'protectedRows':len(protected),'deviceEnrollCalls':device_calls.count('device_enroll'),
        'devicePollCalls':device_calls.count('device_poll'),'serviceSourceSha256':hashlib.sha256((release/'resources/platform-runtime/vendor-src/assistant/service.py').read_bytes()).hexdigest(),
        'actualOriginalServiceBind':True,'bindProvenInPriorStage':True,'resumedExistingVaultWithoutRebind':True,'oldState':runtime.service.state,'actualWindowsDpapi':True,'noCredentialsInReceipt':True,
        'platformModelNativeCalls':0,'cloudKeptAliveForSameDeviceUpgrade':True}
    save('OLD-BINDING-RECEIPT.json',receipt);passed=True
finally:
    if sys.exc_info()[0]:save('ERROR.json',{'traceback':traceback.format_exc()})
    if server:server.shutdown();server.server_close()
    if backend:backend.close()
    if thread:thread.join(4)
    save('CLOSED.json',{'passed':passed,'oldOwnServiceAndHttpClosed':thread is None or not thread.is_alive(),
        'cloudIntentionallyKeptForUpgrade':True,'platformNativeModelCalls':0})
    print(json.dumps({'status':'PASS_OLD_BINDING' if passed else 'RED','evidence':str(OUT)},ensure_ascii=False))
