# 原分发路线与下一次入口准备审查

本轮只读审查完成，最终固定版本仍由 root 提供。没有构建、安装、启动、停止或重装软件，没有修改 S、N、真实业务数据、平台会话或绑定。所有本轮文件只写在本 review-4 目录。

## 当前入口与恢复基线

- 正式入口仍委派 `candidate-unified-v65`，版本 `ui-r57-20261022T153627Z-4d546d79`。launcher `c55ed17e0b06b37765942e6eaf5f4506d16a4c92fc55d96308bf8069d00feba4`；FROZEN `fbd4f3d810658b4f571e41c7fe06d0771111900c6eab941229888a7a5a693702`；binding 仅按原字节哈希核对 `14cf53964f5d44d123e989805ea741669ab3f05054e730ddcb299a0aac51a9cb`，未解析其内容。
- 本审者重新逐文件核对 v65 恢复闭包全部 2777 文件，UNIFIED `c6bc35bc5e2b44c437bf9b8262897d33faf4a5a5c7c1b5f859be130589735268` 完整。
- 2026-10-23 本轮只读进程观察：`N/state/active.json` 留存 PID 61188 的 v65 回执，但该 PID 在系统中不存在，目标 run_workbench/ui-native/candidate Python 进程筛选为空。这是陈旧回执，不是当前运行证明；最终安装前仍由 root 再观察一次。
- sealed 草案 SHA `0fb1fd17be8518541123232666e9f659c0a1b34f39f1ac2c24aacaade986a3d4` 未改，`ACCEPTED={}`、`INSTALLATION_REVIEWED=False`。原 CAS 安装器 SHA `9909f60d16ad3eaed54b9f97ea0d275ad38510c679ba651ce05af44d920ed0f6` 未改。
- 原 scoped 业务备份回执仍为 `W/BACKUP-BEFORE-NEXT-RELEASE.json`：1888 评论、1129 位客户、40 任务，归档 SHA `2918ddbca0ba6586610e3ea517351358489233c0f420e06e176b162abbe58bec`。本审者只读备份摘要，没有打开业务明细。

## 复用原成熟路线

现有入口为 `work/packaging/build_release.py`，现有工具链是客户项目已有 Python 环境中的 PyInstaller：`--onedir --windowed` 固化 Python/PyWebView/pythonnet/clr_loader/Pillow；复制已核验的公开平台运行库和许可；生成逐文件 SHA 清单及便携 ZIP；再以 `--onefile --windowed` 构建原 `work/packaging/installer.py`，把同一 ZIP 追加到安装程序并执行 `--verify-payload`。原 `installer.py` 已有临时目录解压、路径检查、旧安装备份、用户定制保留、WebView2 微软签名核验和用户级安装路线。该路线有旧隔离安装回执，不需新造安装器。

旧独立候选记录 `work/packaging/candidate-release.json` 为 1966 文件、payload probe 通过；其状态为 `internal_candidate_deferred_by_user`。旧 QA 安装 `qa-install-20260924_105946/install-result.json` 留有安装目录与程序入口。它们只能证明旧链路运行过，不能代表本轮 r57 已打包或已获发布认可。

**不能直接运行旧构建 main。** 旧入口仍固定 `work/app/src/app.py`、1.1.7、旧单小红书产品审批和旧 launcher 接口；当前运行的是 r57 host + r55 后端 +完整公开闭包。直接运行会构建旧产品，也会写旧 packaging/dist、outputs 和审批链。本轮仅定位原路线，未调用其 preflight/import/main 或冻结安装程序。

应复用原打包/安装容器，最小适配为显式接入最终 r57 固定入口和其完整公开文件映射、重定向本轮独立构建输出，再保持原安装器的备份和数据隔离语义；适配完成后再做一个隔离目录安装/启动/关闭与数据保留检查。不能拿旧 feed、旧 TUF 目标或旧 1.1.x 版本号直接打开 r57 更新。

## 必须是完整项目闭包

`freeze_unified.py` 已复用 `freeze_ui.py --stage` 输出 `UNIFIED-PINS.json` 和 `STAGED.json`；它明确声明 `external_host_runtime.portable_runtime_included=false`。这不是可脱离当前电脑运行的便携客户端。

非最终 v70 的只读盘点为 3125 个公开闭包文件，382865048 字节；它只用于说明依赖范围，不视作最终允许版本：

| 必须保留的部分 | v70 盘点 | 原因 |
|---|---:|---|
| r57 固定 release | 184 文件，含 RELEASE.json | 183 项固定资源与清单；host、页面、账号/客户/回复/内容/素材/结果等能力 |
| `work/ui-runtime-r55/src` | 772 | host 的 backend-dependencies.json 对整套 r55 Python 逐文件核验，单拷 release 会缺后端 |
| `work/ui-runtime-r55/work/runtime` | 50 | 已有公开 Node/平台运行库，不能遗漏其启动路径 |
| 当前三个已审 CLI component 子树 | 每套 297 | login/speed/v66 worker 各自固定来源与组件核验，不任意合并或删除 |
| `work/app/src` 与公司配置 | 752 + 1 | 现有组件/许可/配置及相对路径依赖；公开配置需正式分发净化，不能夹带本机私密字段 |
| r56 资源、共享后台 adapter、content-media/vendor/gateway、方法/口吻/业务规则及固定更新入口 | 由最终 UNIFIED 精确清单决定 | 不能依据文件名猜测无用后再删除；对减包必须另建固定候选并验证 |
| Python/pywebview/pythonnet/clr_loader/Pillow/XlsxWriter 等实际依赖 + .NET/WebView2 | 当前 UNIFIED 未含独立宿主运行时 | 普通 Windows 电脑需要冻结 runtime；不能把本机 venv 当作可搬运运行库 |

正式本机下一次入口仍按最终 UNIFIED 的全部精确列表验证并保留现有绑定。独立电脑安装包则需从同一最终公开代码闭包装配新的分发清单：使用独立初始化/绑定、受净化配置、相对启动路径和自有数据目录；不得把本机 production-workspace 绑定、真实 DB、DPAPI/Vault、Cookie、profile、session、运行锁或私有备份带出。它是一次新的分发冻结与验收，不能仅把现有 candidate/project 整目录压缩后称开箱可用。

## 普通电脑与媒体工具边界

- v70 精确闭包内没有 ffmpeg.exe、ffprobe.exe 或模型权重（`.safetensors/.gguf/.ckpt/.pt/.pth/.onnx`）。本链 CPU FFmpeg/Pillow，不需要本地大模型或 GPU。
- 当前媒体 adapter 仅发现系统已有 FFmpeg，并核对 FFmpeg、同目录 ffprobe 以及 Windows YaHei 字体的三项固定 SHA；不自动下载、不改 PATH、不接受浏览器指定可执行文件。
- 已有媒体 ROUTE.md 记录实际 FFmpeg 8.1.1 full_build 开启 `--enable-gpl --enable-version3`、GPLv3-or-later。这份本机 GPL 二进制不得捆入商业包，字体文件也不复制。
- **无模型/GPU需求不等于所有普通电脑媒体功能开箱可用。** 新电脑未具备这三项已审工具字节时，当前实现会准确返回 `MEDIA_TOOL_UNAVAILABLE` 或工具不匹配，需另做核准的外置工具配置或合适 LGPL 工具选型与小样验证。当前本机完整 6 秒渲染/播放证据由 root 持有，本审者没有替代或扩大其验收范围。
- WebView2 沿用已有微软签名离线运行时方案；Windows 10/11 x64、.NET Framework 4.6.2+ 与第二台实体机仍按实际验收写，不能用旧本机 QA 代替。

## 等最终 pins 后只准备

root 提供最终 immutable candidate、release_id、UNIFIED SHA/文件数、RELEASE SHA、candidate launcher SHA、STAGED SHA、delivery/frozen-native 证据 JSON SHA 与总组数后，才在 review-4 独立副本加入单条固定允许项。保留 sealed 原草案不动；独立副本只允许 `--check` 和 `--prepare`，仍保持 `INSTALLATION_REVIEWED=False`。真正双文件 CAS 安装、安装开关审核和最终实际原入口验收由 root 执行。

原安装器为逐文件 CAS、原字节备份和进程内失败回滚，不是跨两个文件的单次原子交换，也没有自动断电恢复。root 安装时确认应用已退出并保存事务日志/备份。

## 能力与证据

已评估当前 Skill/插件目录；没有需要新安装的专用 Windows 打包能力。复用已验证的原 PyInstaller/原安装器，因此未为已知路线重复网络选型。读取并应用 context-mode 的大输出本地筛选方法；当前可发现工具目录没有 ctx_execute/ctx_search，使用本地只读脚本保留完整结构化证据、只返回摘要，没有声称 hooks 自动接管。

可重读证据：本目录 `READONLY-ROUTE-AUDIT.json` 与 `audit_existing_routes.py`。脚本仅使用标准库解析/哈希，不 import 产品模块，不执行构建或安装；v65 全闭包及五项受保护 pin 均核对通过。
