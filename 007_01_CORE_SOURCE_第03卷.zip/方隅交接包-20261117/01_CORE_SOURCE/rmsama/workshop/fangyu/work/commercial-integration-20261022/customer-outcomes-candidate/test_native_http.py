"""Real Native StaticServer/dispatch and Core/Store; synthetic authority only."""
import sys
sys.dont_write_bytecode=True;sys.argv.append('--http-fixture')
from test_outcomes import OutcomesTests,W,CustomerOutcomesWorkbench,digest
import http.client,importlib.util,json,threading
def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m);return m
N=W/'candidate/work/ui-native-r57'
native=load('outcomes_native',N/'workbench_backend.py');host=load('outcomes_host',N/'ui_native_host.py')
case=OutcomesTests();case.setUp();backend=native.WorkbenchBackend.__new__(native.WorkbenchBackend)
backend.closed=False;backend.lock=threading.RLock();backend.core=case.core;backend.company=case.company;backend.customer_workbench=case.customers;backend.outcomes_factory=CustomerOutcomesWorkbench;backend.remote_management=None
profile={'role':'operator','_workbench_stores':[{'id':'gubei'}]};identity_calls=0;deny_after=False
def identity(token):
    global identity_calls
    if token!='synthetic-token':raise native.WorkbenchError('AUTH_REQUIRED','合成员工身份无效',401)
    identity_calls+=1
    if deny_after and identity_calls%2==0:raise native.WorkbenchError('AUTH_REQUIRED','合成保存后身份撤销',401)
    return case.core.store.get('users',case.user['id']),profile
backend._identity=identity;backend._activate_central_config=lambda user,profile,store,**kw:{'store_id':store}
server=host.StaticServer(W,{'web/index.html':{'path':'unused','sha256':'0'*64,'size':0}},backend=backend,cookie_name='outcomes_fixture')
thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
origin='http://127.0.0.1:'+str(server.server_port)
headers={'Content-Type':'application/json','Origin':origin,'X-Fangyu-CSRF':server.csrf_token,'Cookie':'outcomes_fixture=synthetic-token'}
results=[]
def call(action,data,status=200,override=None):
    c=http.client.HTTPConnection('127.0.0.1',server.server_port,timeout=10)
    c.request('POST','/api/workbench',json.dumps({'action':action,'data':data},ensure_ascii=False).encode(),override or headers)
    r=c.getresponse();raw=r.read();found=r.status;c.close();v=json.loads(raw) if raw.startswith(b'{') else {'text':'blocked'}
    assert found==status,(found,status,v);return v
try:
    before=case.snapshot();case.add_lead('two',task='task-b')
    req=case.request('responded');saved=call('customer_outcome_save',req)['customerOutcomes'];assert saved['receipt']['state']=='accepted'
    recovered=call('customer_outcome_read',{**case.base,'requestId':req['requestId']})['customerOutcomes'];assert recovered['receipt']['requestDigest']==digest(req)
    duplicate=call('customer_outcome_save',req)['customerOutcomes'];assert duplicate['version']==1 and len(duplicate['history'])==1
    report=call('customer_outcome_report',{'storeId':'gubei','dateFrom':'2026-10-23','dateTo':'2026-10-23'})['customerOutcomes'];assert report['visibleCustomers']==1 and report['registeredCustomers']==1
    results.append('Native HTTP save → same-key read/retry → original Core/Store author_key cross-account dedup → statistics')
    req=case.request('visited');identity_calls=0;deny_after=True
    uncertain=call('customer_outcome_save',req,409);assert uncertain['error']['code']=='OUTCOME_RESULT_UNCONFIRMED';deny_after=False
    recovery=call('customer_outcome_read',{**case.base,'requestId':req['requestId']})['customerOutcomes'];assert recovery['receipt']['state']=='accepted' and recovery['version']==2
    results.append('Actual committed save followed by authority loss returns unknown; original key recovers once without duplicate mutation')
    pending=case.request('signed');cancel=call('customer_outcome_cancel',{**case.base,'requestId':pending['requestId'],'requestDigest':digest(pending)})['customerOutcomes'];assert cancel['receipt']['state']=='cancelled'
    assert call('customer_outcome_save',pending)['customerOutcomes']['version']==2
    results.append('Unknown-key cancellation tombstone atomically blocks late save; accepted request cancellation preserves original save')
    call('customer_outcome_save',{**req,'fact':'changed'},409);call('customer_outcome_read',{**case.base,'storeId':'other'},403)
    call('customer_outcome_read',{**case.base,'employee':'bob'},400)
    call('customer_outcome_read',case.base,403,{**headers,'Origin':'https://example.invalid'})
    call('customer_outcome_read',case.base,403,{**headers,'X-Fangyu-CSRF':'wrong'})
    call('customer_outcome_read',case.base,401,{**headers,'Cookie':'outcomes_fixture=bad'})
    call('customer_outcome_delete',case.base,403)
    results.append('Exact fields and no arbitrary delete; original Cookie/Origin/CSRF/customer/store authority fail closed')
    profile['_workbench_stores']=[{'id':'other'}];call('customer_outcome_read',case.base,403);profile['_workbench_stores']=[{'id':'gubei'}]
    backend.outcomes_factory=None;call('customer_outcome_read',case.base,503);backend.outcomes_factory=CustomerOutcomesWorkbench
    results.append('Enterprise current store and absent helper return explicit denial/unavailable')
    raw=(N/'customer_outcomes_workbench.py').read_bytes();entry={'path':'customer_outcomes_workbench.py','sha256':__import__('hashlib').sha256(raw).hexdigest(),'size':len(raw)}
    factory=host._customer_outcomes_factory(N,{'customer_outcomes_workbench.py':entry});assert factory.__name__=='CustomerOutcomesWorkbench'
    damaged={**entry,'sha256':'0'*64}
    try:host._customer_outcomes_factory(N,{'customer_outcomes_workbench.py':damaged})
    except Exception:pass
    else:raise AssertionError('Damaged helper loaded')
    results.append('Manifest-pinned helper factory executes local verified bytes without release sys.path and rejects a damaged resource')
finally:
    server.shutdown();server.server_close();thread.join(3);case.tearDown()
(W/'HTTP-RESULTS.json').write_text(json.dumps({'passed':len(results),'results':results,'realPlatformOrModelCalls':0,'productionAccess':False,'scope':'Original StaticServer and real candidate dispatch/Core/Store; synthetic enterprise authority; no browser or production acceptance'},ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'passed':len(results),'results':results},ensure_ascii=False,indent=2))
