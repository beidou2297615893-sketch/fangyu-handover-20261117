'use strict';
const readline=require('node:readline');
const path=require('node:path');
const {fixture,IDS,loadActualModules}=require('./cloud-fixture.cjs');
globalThis.fetch=()=>{throw Error('REAL_NETWORK_FORBIDDEN');};
for(const name of ['node:http','node:https']){const m=require(name);m.get=globalThis.fetch;m.request=globalThis.fetch;}
const net=require('node:net');net.connect=globalThis.fetch;net.createConnection=globalThis.fetch;
let current,output,dispatch;
async function handle(m){
 if(m.command==='init'){
  output=m.output;
  const sourceDir=m.legacy?path.resolve(__dirname,'../../content-model-gateway/server'):path.resolve(__dirname,'../cloud');
  current=await fixture({sourceDir,provider:async r=>({model:r.model,
   usage:{prompt_tokens:100,prompt_cache_hit_tokens:20,prompt_cache_miss_tokens:80,completion_tokens:50},
   choices:[{finish_reason:'stop',message:{content:JSON.stringify(output)}}]})});
  dispatch=p=>current.call(p.operation,p);
  const profile=await current.profile();return {context:{environment_id:IDS.env,company_id:IDS.company,
   tenant_id:IDS.tenant,store_id:IDS.store,account_id:IDS.account,platform:'xiaohongshu',actor:IDS.actor,
   device_id:IDS.device,expected_revision:profile.config.revision,expected_rules_version:profile.config.rules_version}};
 }
 if(m.command==='upgrade'){
  const {createService}=loadActualModules(path.resolve(__dirname,'../cloud'));
  const service=createService(current.options);dispatch=p=>service(p,current.staff);return {upgraded:true};
 }
 if(m.command==='configure'){output=m.output;return {configured:true};}
 if(m.command==='call')return dispatch(m.payload);
 if(m.command==='stats')return {calls:current.calls(),messages:current.providerRequests.map(r=>r.messages),
  states:current.memory.rows('fangyu_ai_ledger').map(r=>r.status)};
 throw Error('UNKNOWN_TEST_COMMAND');
}
const input=readline.createInterface({input:process.stdin,crlfDelay:Infinity});let q=Promise.resolve();
input.on('line',line=>{q=q.then(async()=>{let m;try{m=JSON.parse(line);const value=await handle(m);
 process.stdout.write(JSON.stringify({id:m.id,ok:true,value})+'\n');}catch{
 process.stdout.write(JSON.stringify({id:m?.id,ok:false,error:'SYNTHETIC_BRIDGE_FAILED'})+'\n');}});});
