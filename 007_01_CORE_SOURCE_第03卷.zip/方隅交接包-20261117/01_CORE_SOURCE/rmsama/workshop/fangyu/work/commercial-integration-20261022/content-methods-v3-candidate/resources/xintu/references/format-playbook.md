# Format Playbook: Carousel vs Video

Use this when the user has not chosen a format, or when packaging one topic for both channels.

## Choose a format first

| Signal | Prefer |
|---|---|
| Saveable steps, lists, comparisons, SOP | `carousel` |
| Demo, screen recording, before/after motion, trust via face/voice | `video` |
| User already has footage or a workflow to show | `video` |
| User wants 6+ pages of structured text | `carousel` |
| Same topic, two deliveries | run both branches; do not merge into one asset |

## Shared package (both formats)

Every deliverable, regardless of format, should include:

- audience in one glance
- one core promise
- one original proof artifact
- title candidates (3+) + one recommended title
- tags (5-10)
- one natural CTA
- compliance pass before calling the package ready

## Carousel branch

```
topic → xhs-note-writer (format=carousel) → xhs-visual-lab (mode=carousel_cover + optional slide system) → xhs-publish-guard
```

Outputs:

- fold-line body (first 3 visible lines matter most)
- optional slide outline (6+ slides when the content is tutorial/list heavy)
- cover brief tuned for 3:4 feed readability

Do not put the full spoken script in carousel body.

## Video branch

```
topic → xhs-video-director → xhs-note-writer (format=video) → xhs-visual-lab (mode=video_first_frame) → xhs-publish-guard
```

Outputs:

- spoken script + shot table (video-director)
- publish caption only (note-writer); not a duplicate of the script
- first-frame brief must match second 0-3 of the edit

## Cross-format consistency rules

- Title promise must match carousel fold line OR video first 3 seconds.
- Cover/first-frame must not promise something the body or video does not deliver.
- Tags may overlap, but carousel can lean save/tutorial tags; video can lean search/discovery tags.
- Proof level must stay identical across formats; never strengthen claims in one format only.

## When to produce both

Use both only when the user explicitly wants dual delivery or a series launch:

1. Produce video branch first if demo proof is the main asset.
2. Derive carousel from the structured proof, not from the transcript verbatim.
3. Run publish-guard separately for each package.
