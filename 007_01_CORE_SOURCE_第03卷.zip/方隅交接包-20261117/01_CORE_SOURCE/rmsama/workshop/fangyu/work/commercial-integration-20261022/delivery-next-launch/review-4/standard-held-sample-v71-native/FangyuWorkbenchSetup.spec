# -*- mode: python ; coding: utf-8 -*-


a = Analysis(
    ['C:/积木软件工坊/项目/方隅公寓客户版/work/commercial-integration-20261022/delivery-next-launch/review-4/standard-held-sample-v71-native/installer.original.py'],
    pathex=[],
    binaries=[],
    datas=[('C:/积木软件工坊/项目/方隅公寓客户版/work/parallel-integration-20261018/final-integration/candidate-unified-v71/project/work/app/src/resources/brand.ico', '.')],
    hiddenimports=[],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    noarchive=False,
    optimize=0,
)
pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.datas,
    [],
    name='FangyuWorkbenchSetup',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    upx_exclude=[],
    runtime_tmpdir=None,
    console=False,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon=['C:/积木软件工坊/项目/方隅公寓客户版/work/parallel-integration-20261018/final-integration/candidate-unified-v71/project/work/app/src/resources/brand.ico'],
)
