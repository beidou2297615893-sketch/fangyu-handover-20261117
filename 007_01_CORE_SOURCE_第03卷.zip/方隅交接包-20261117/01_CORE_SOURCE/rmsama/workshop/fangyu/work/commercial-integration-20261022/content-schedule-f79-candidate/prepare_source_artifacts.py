from pathlib import Path
import ast,difflib,hashlib,json,shutil
W=Path(__file__).resolve().parent;P=W.parents[2];S=W/'source-candidate';F=P/'work/parallel-integration-20261018/final-integration/candidate-unified-v79/project'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
put=lambda n,x:(W/n).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n','utf-8')
base=json.loads((W/'BASE-HASHES.json').read_text('utf-8'));merge=json.loads((W/'MERGE-RESOLUTION.json').read_text('utf-8'))
old={r['path'] for r in merge['rows'] if r['f79Before'] is not None};new={r['path'] for r in merge['rows'] if r['f79Before'] is None}
changed={rel for rel,pin in base['files'].items() if sha(S/rel)!=pin['sha256']};assert changed==old and len(old)==6 and len(new)==2
for rel,pin in base['files'].items():assert sha(F/rel)==pin['sha256']
overlay=W/'overlay';overlay.mkdir();rows=[];patch=[]
for rel in sorted(old|new):
 b=(F/rel).read_bytes() if rel in old else b'';a=(S/rel).read_bytes();dst=overlay/rel;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(a)
 assert not b or bool(b.count(b'\r\n'))==bool(a.count(b'\r\n')),(rel,'EOL changed')
 rows.append({'path':rel,'beforeSha256':hashlib.sha256(b).hexdigest() if b else None,'afterSha256':sha(dst),'bytesBefore':len(b),'bytesAfter':len(a),'beforeCrlf':b.count(b'\r\n'),'afterCrlf':a.count(b'\r\n')})
 patch.extend(difflib.unified_diff(b.decode().replace('\r\n','\n').splitlines(True),a.decode().replace('\r\n','\n').splitlines(True),fromfile='a/'+rel if b else '/dev/null',tofile='b/'+rel))
put('SOURCE-FILES.json',{'base':'exact F79','baseRootPinsSha256':base['rootPinsSha256'],'overlay':'overlay','files':rows});(W/'CHANGES.patch').write_text(''.join(patch),'utf-8')
protected={}
for rel,pin in base['files'].items():
 if rel.startswith('work/ui-runtime-r55/src/') or rel.startswith('work/shared-backend-integration/') or rel in ['work/ui-approved-implementation/ui-preview/app.mjs','work/ui-approved-implementation/ui-preview/pages/accounts.mjs','work/ui-approved-implementation/ui-preview/pages/diversified-acquisition.mjs']:
  assert sha(S/rel)==pin['sha256'];protected[rel]=pin['sha256']
native=['content_workbench.py','content_workflow.py','content_publishing.py','publishing_port.py','publication_protocol.py','publication_authority_host.py','owned_publication_host.py','publication_policy.py']
for name in native:
 rel='work/ui-native-r57/'+name;assert sha(S/rel)==sha(F/rel);protected[rel]=sha(F/rel)
guards={}
for rel,names in [('work/ui-native-r57/ui_native_host.py',['read_public','verify_release','verify_backend_dependencies','create_backend']),('work/ui-native-r57/workbench_backend.py',['_platform_dispatch','_identity'])]:
 a=ast.parse((F/rel).read_bytes());b=ast.parse((S/rel).read_bytes())
 for name in names:
  select=lambda t:next(n for n in ast.walk(t) if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name==name)
  assert ast.dump(select(a),include_attributes=False)==ast.dump(select(b),include_attributes=False),(rel,name);guards[rel+':'+name]='AST identical'
rel='work/ui-approved-implementation/ui-preview/backend.mjs';insert="'content_schedule_plan','content_schedule_read','content_schedule_arm','content_schedule_control','content_schedule_tick','content_schedule_reconcile',".encode();assert (S/rel).read_bytes().replace(insert,b'',1)==(F/rel).read_bytes()
put('PROTECTED-SOURCE-CHECK.json',{'status':'PASS','allF79CoreAndPlatformRuntimeSourceByteIdentical':True,'protectedFileCount':len(protected),'files':protected,'guards':guards,'webBackendMinusSixActionNamesByteIdenticalToF79':True,'F79AccountDeleteCasFreshPassthroughModeUnknownGuardsPreserved':True})
print(json.dumps({'overlay':len(rows),'sourcePinsSha256':sha(W/'SOURCE-FILES.json'),'patchSha256':sha(W/'CHANGES.patch'),'protected':len(protected)},ensure_ascii=False))
