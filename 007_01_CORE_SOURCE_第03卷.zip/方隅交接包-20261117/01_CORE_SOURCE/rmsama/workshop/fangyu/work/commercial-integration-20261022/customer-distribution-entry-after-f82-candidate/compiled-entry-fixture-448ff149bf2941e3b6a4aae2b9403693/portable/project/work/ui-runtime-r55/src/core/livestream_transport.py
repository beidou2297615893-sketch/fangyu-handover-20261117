"""Fixed live CLI over the original adapter, account lock and lifecycle."""
from pathlib import Path
import hashlib
PINS={'livestream_admission_cli.mjs': '1992fe05863c78c6761de7c2765b1ced25a9c580e4f31921ba5bbd0e27a147cb', 'lib/livestream/bounded_decoder.mjs': 'a4645f211672720cd5d00288efe651db68b7e9ffd89954b4f63ab53b0e4f1885', 'lib/livestream/dyhub_decoder.mjs': '916a23b9aa732c6b5bf4e1f459204aa91efe00b3913dc42bd6a3c53da4609974', 'lib/livestream/dyhub_normalizer.mjs': '8bc1ae7c80eec874f9d1a247079c8a4fb6242d8960c44126dbc1f90d850262a1', 'lib/livestream/protobuf.cjs': '14260b088114ea634d95abafe8e7f8bedf1666dcd1e6df94ddd3e0e7c9c63abc', 'lib/livestream/long.cjs': 'ea6da8d5fff04abc358b94488dbbb7eeb46e5027cc05303b1761cea94bef7821', 'lib/livestream/LICENSES.txt': '3f79bf0d79b588c9b18618a30555958c5d86c19647c3cd62c0f7d650e9df14bf', 'lib/client/bridge-client.js': 'ed1c6439b0d0436c2a91f5f2b5ce84ce8fed86b8f9d6255a2304809158902c45', 'lib/server/router.js': '44a5164fa1e3bed5213d4e969d4a0359527d3cfac268bfa7e1c66af7e0337696', 'lib/server/registry.js': '5664a6d5a335230c2d1fc61d638c7b2dddd41155f73b38bdf302df7c71e23734', 'lib/server/ws-hub.js': 'ea880fcd11e7464c17c596d0798e0893d4bab6a9018500c1cc77c2ac5739b5c1', 'lib/server/livestream.js': '96bc8d918d125abb2d7b3842975d6e99c2c2a89e2000008d8d9d7229adab5144', 'lib/livestream/page_observer.cjs': '0eadc73101e446298e5cc2f0520f2bf812a865adae426a4483b9b33408271d5e', 'scripts/douyin-live.user.js': '2fd78708424e0ca4ac486248edaf34d08cc6f98bcd251828a1f786f7727c1c1f'}
def _invoke(adapters,account,operation,data,guard,directory):
 from .adapters import account_execution_lock
 if account.get('platform')!='douyin' or not callable(guard) or operation not in ('connections','select','capture'):raise ValueError('直播仅允许原账号下的固定只读命令')
 root=Path(adapters.manifest('douyin')['search_args'][0]).parent
 if len(PINS)!=14:raise ValueError('直播只读组件尚未封定')
 for name,pin in PINS.items():
  p=root/name
  if not p.is_file() or p.is_symlink() or getattr(p.lstat(),'st_file_attributes',0)&0x400 or hashlib.sha256(p.read_bytes()).hexdigest()!=pin:raise ValueError('直播只读组件已变化，未执行')
 args=[str(root/'livestream_admission_cli.mjs'),operation,'--parent-conn-id',account['conn_id'],'--expected-uid',account['platform_uid'],'--request-id',data['requestId']]
 if operation!='connections':args+=['--conn-id',data['liveConnId'],'--room',data['webRid']]
 if operation=='capture':args+=['--selection-id',data['bridgeSelectionId'],'--timeout',str(data['timeoutMs'])]
 if getattr(adapters._dm_calls,'guard',None) is not None:raise ValueError('直播读取不能嵌套其他账号操作')
 with account_execution_lock(directory):
  adapters._dm_calls.guard=guard
  try:
   guard();value=adapters.execute('douyin',args,directory,job_id='live:'+data['requestId'],timeout=40)
   if not isinstance(value,dict):raise ValueError('直播原请求回执无法核对')
   return value
  finally:del adapters._dm_calls.guard
def capture(adapters,account,data,guard,directory):return _invoke(adapters,account,'capture',data,guard,directory)
def control(adapters,account,operation,data,guard,directory):return _invoke(adapters,account,operation,data,guard,directory)
