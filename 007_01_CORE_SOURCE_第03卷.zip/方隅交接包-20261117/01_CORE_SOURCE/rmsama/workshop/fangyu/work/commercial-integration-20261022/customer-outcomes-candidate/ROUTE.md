# 客户结果登记路线

按实际读取的 revops/SKILL.md，只采用唯一事实来源、先定义事实再统计、范围去重和各环节分母。现有原客户 author_key、员工/门店授权、Core/Store 与 ContactJournal 保留。

主任务已按 agent-reach 的 gh 路线尝试，当前无 GitHub 登录，不要求本人操作；公开核查 marmelab/atomic-crm 的 MIT 方案与阶段配置。来源：https://github.com/marmelab/atomic-crm/blob/main/README.md 和 https://github.com/marmelab/atomic-crm/blob/main/doc/src/content/docs/developers/customizing.mdx 。其 Node22/Docker/Supabase 完整迁移不适配普通电脑、现有 Store 和轻量增量包，因此复用阶段与证据分离思路，不另建 CRM 或下载新运行栈。

缺口是原 ContactJournal 仅接受已定义的发送/复制等事件，严格要求原 reply/lead 快照，并含同步出站语义；人工到访/签约/回款不能伪装成发送事件。新增薄资源只在原 Store 的 records 中追加客户结果及操作回执，不新建库、不改原联系事件、正文、意向、AI、会话或外部发送状态。

首条代表链：原 Core/Store+CustomerHistory 可见客户，保存人工结果→原 key 恢复→跨账号同 author_key 去重→只读统计。事件均写明人工登记、事实日期/说明/来源；无需猜联系方式。撤销另添事件，原事实历史保留；不根据意向、点赞、复制或 SOP 自动升级，也不因跳阶段补前序事实。

统计仅本机当前员工、已授权当前门店。原 author_key 在同平台跨账号去重；跨平台身份不推定合并。结果按事实日期范围，阶段分母及交集明确，不冒充获客同期转化率。金额人民币整数分，成本缺项为未知，显式零不等于缺项；回款/投入比只在软件/人工/渠道均明确且投入>0后计算。无已核贡献利润，不提供 ROI；所有金额均标人工登记、未独立对账。

S只读；所有候选、合成数据、测试与补丁均在本文件夹。无生产、平台、模型、真实账单或外部CRM同步访问。
