'use strict';

// Pure policy publication data helpers. No database, provider, or actor lookup.
const {AiError,DEFAULT_INTENT_POLICY,validateIntentPolicy,hash}=require('./ai_contract.cjs');
const CONTRACT='company_intent_policy_v1';
const CONTROL=/[\p{Cc}\p{Cf}\p{Cs}]/u;
const POLICY_KEYS=new Set(['name','enabled','criteria','facts']);
const FACT_KEYS=new Set(['id','name','city','areas','room_types','rent_min','rent_max','effective_from','effective_until','evidence_reference']);
const HEX=/^[a-f0-9]{64}$/;

function invalid(message){throw new AiError('AI_POLICY_INVALID',message,400);}
function object(value,label){
  if(!value||typeof value!=='object'||Array.isArray(value)||![Object.prototype,null].includes(Object.getPrototypeOf(value)))invalid(label+' must be an object');
  if(Reflect.ownKeys(value).some(key=>typeof key!=='string'||!Object.getOwnPropertyDescriptor(value,key).enumerable||!Object.hasOwn(Object.getOwnPropertyDescriptor(value,key),'value')))invalid(label+' has a non-JSON field');
  return value;
}
function exactKeys(value,allowed,label){object(value,label);if(Object.keys(value).some(key=>!allowed.has(key)))invalid(label+' has an unsupported field');}
function textValue(value,max,label,{empty=true,fallback=''}={}){
  if(value===undefined)value=fallback;
  if(typeof value!=='string'||value.length>max||CONTROL.test(value))invalid(label+' must be bounded plain text');
  const out=value.trim();
  if(out.length>max||(!empty&&!out))invalid(label+' has invalid length');
  return out;
}
function listValue(value,label){
  if(value===undefined)value=[];
  if(!Array.isArray(value)||value.length>50)invalid(label+' must have at most 50 entries');
  return [...new Set(value.map(item=>textValue(item,80,label,{empty:false})))].sort();
}
function rentValue(value,label){
  if(value===undefined||value===null)return null;
  if(!Number.isSafeInteger(value)||value<0||value>10000000)invalid(label+' must be a bounded integer');
  return value;
}
function dateValue(value,label){
  const raw=textValue(value,40,label);
  if(!raw)return '';
  const match=/^(\d{4})-(\d{2})-(\d{2})[T ](\d{2}):(\d{2})(?::(\d{2})(?:\.(\d{1,9}))?)?(Z|[+-]\d{2}:\d{2})$/.exec(raw);
  if(!match)invalid(label+' requires an explicit timezone');
  const [,ys,mos,ds,hs,mis,ss='0',fraction='',zone]=match;
  const [year,month,day,hour,minute,second]=[ys,mos,ds,hs,mis,ss].map(Number);
  if(year<1||month<1||month>12||day<1||day>31||hour>23||minute>59||second>59||/[1-9]/.test(fraction.slice(3)))invalid(label+' has an invalid date or precision');
  const milli=Number((fraction+'000').slice(0,3));
  const local=new Date(0);local.setUTCFullYear(year,month-1,day);local.setUTCHours(hour,minute,second,milli);
  if(local.getUTCFullYear()!==year||local.getUTCMonth()!==month-1||local.getUTCDate()!==day)invalid(label+' has an invalid calendar date');
  let offset=0;
  if(zone!=='Z'){
    const zh=Number(zone.slice(1,3)),zm=Number(zone.slice(4,6));
    if(zh>23||zm>59)invalid(label+' has an invalid timezone');
    offset=(zone[0]==='-'?-1:1)*(zh*60+zm)*60000;
  }
  const date=new Date(local.getTime()-offset);
  if(!Number.isFinite(date.getTime())||date.getUTCFullYear()<1||date.getUTCFullYear()>9999)invalid(label+' is outside supported dates');
  return date.toISOString();
}
function normalizeFact(value){
  exactKeys(value,FACT_KEYS,'fact');
  const id=textValue(value.id,64,'fact.id',{empty:false});
  if(!/^[A-Za-z0-9_-]{1,64}$/.test(id))invalid('fact.id is invalid');
  const out={id,name:textValue(value.name,120,'fact.name'),city:textValue(value.city,80,'fact.city'),
    areas:listValue(value.areas,'fact.areas'),room_types:listValue(value.room_types,'fact.room_types'),
    rent_min:rentValue(value.rent_min,'fact.rent_min'),rent_max:rentValue(value.rent_max,'fact.rent_max'),
    effective_from:dateValue(value.effective_from,'fact.effective_from'),effective_until:dateValue(value.effective_until,'fact.effective_until'),
    evidence_reference:textValue(value.evidence_reference,200,'fact.evidence_reference')};
  if(out.rent_min!==null&&out.rent_max!==null&&out.rent_min>out.rent_max)invalid('fact rent range is reversed');
  if(out.effective_from&&out.effective_until&&Date.parse(out.effective_from)>=Date.parse(out.effective_until))invalid('fact validity interval is empty');
  return out;
}
function normalizePublishedPolicy(value){
  exactKeys(value,POLICY_KEYS,'policy');
  const enabled=value.enabled===undefined?true:value.enabled;
  if(typeof enabled!=='boolean')invalid('policy.enabled must be boolean');
  const inputCriteria=value.criteria===undefined?DEFAULT_INTENT_POLICY:value.criteria;
  object(inputCriteria,'policy.criteria');
  for(const item of Object.values(inputCriteria))if(typeof item!=='string'||CONTROL.test(item))invalid('policy.criteria must be plain text');
  const criteria=validateIntentPolicy(inputCriteria);
  const inputFacts=value.facts===undefined?[]:value.facts;
  if(!Array.isArray(inputFacts)||inputFacts.length>200)invalid('policy.facts must have at most 200 entries');
  const facts=inputFacts.map(normalizeFact).sort((a,b)=>a.id<b.id?-1:a.id>b.id?1:0);
  if(new Set(facts.map(item=>item.id)).size!==facts.length)invalid('fact identifiers must be unique');
  return {name:textValue(value.name,120,'policy.name',{empty:false,fallback:'租房意向与资料匹配规则'}),enabled,criteria,facts};
}
function canonical(value,seen=new Set()){
  if(value===null)return 'null';
  if(typeof value==='string')return JSON.stringify(value);
  if(typeof value==='boolean')return value?'true':'false';
  if(typeof value==='number'){if(!Number.isSafeInteger(value))invalid('digest values must be safe integers');return JSON.stringify(value);}
  if(typeof value!=='object'||seen.has(value))invalid('digest value must be acyclic JSON');
  seen.add(value);
  let result;
  if(Array.isArray(value)){
    if(Reflect.ownKeys(value).length!==value.length+1||Array.from({length:value.length},(_,i)=>i).some(i=>!Object.hasOwn(value,i)))invalid('digest array must be dense JSON');
    result='['+value.map(item=>canonical(item,seen)).join(',')+']';
  }else{
    object(value,'digest value');
    result='{'+Object.keys(value).sort().map(key=>JSON.stringify(key)+':'+canonical(value[key],seen)).join(',')+'}';
  }
  seen.delete(value);return result;
}
// This also fingerprints trusted publication request JSON; callers normalize policies first.
function policyDigest(value){return hash(canonical(value));}
function provenanceString(value,label,min,max,pattern){
  if(value===undefined||value===null)return null;
  if(typeof value!=='string'||value.length<min||value.length>max||!pattern.test(value))invalid(label+' is invalid');
  return value;
}
function effectiveSnapshot(record,nowMS){
  object(record,'record');
  if(!Number.isSafeInteger(record.revision)||record.revision<0)invalid('record.revision must be a nonnegative integer');
  if(!Number.isSafeInteger(nowMS))invalid('snapshot clock must be integer milliseconds');
  const clock=new Date(nowMS);
  if(!Number.isFinite(clock.getTime())||clock.getUTCFullYear()<1||clock.getUTCFullYear()>9999)invalid('snapshot clock is outside supported dates');
  const policy=normalizePublishedPolicy(record.policy),digest=policyDigest(policy);
  if(typeof record.digest!=='string'||!HEX.test(record.digest)||record.digest!==digest)invalid('stored policy digest is invalid');
  const publication_id=provenanceString(record.publication_id,'publication_id',1,128,/^[A-Za-z0-9_.:-]+$/);
  const publication_key=provenanceString(record.publication_key,'publication_key',8,128,/^[A-Za-z0-9_.:-]+$/);
  const source_local_digest=provenanceString(record.source_local_digest,'source_local_digest',64,64,HEX);
  const source_local_revision=record.source_local_revision===undefined||record.source_local_revision===null?null:record.source_local_revision;
  if(source_local_revision!==null&&(!Number.isSafeInteger(source_local_revision)||source_local_revision<0))invalid('source_local_revision is invalid');
  const effectiveFacts=[];let incomplete=0,expired=0,future=0,nextBoundaryMs=null;
  const boundary=ms=>{if(ms>nowMS&&(nextBoundaryMs===null||ms<nextBoundaryMs))nextBoundaryMs=ms;};
  for(const fact of policy.facts){
    if(!fact.name||!fact.city||!fact.effective_from||!fact.effective_until||!fact.evidence_reference){incomplete++;continue;}
    const start=Date.parse(fact.effective_from),end=Date.parse(fact.effective_until);
    if(nowMS>=end){expired++;continue;}
    if(nowMS<start){future++;boundary(start);continue;}
    effectiveFacts.push(fact);boundary(end);
  }
  const flags={contract:CONTRACT,scope:'company',enabled:policy.enabled,source:'operator_recorded',independently_verified:false,inventory_verified:false};
  const meta={contract:CONTRACT,scope:'company',policy_revision:record.revision,policy_digest:digest,
    effective_facts_digest:policyDigest({...flags,facts:effectiveFacts}),enabled:policy.enabled,
    facts_as_of:clock.toISOString(),facts_valid_until:nextBoundaryMs===null?null:new Date(nextBoundaryMs).toISOString(),
    usable_fact_count:effectiveFacts.length,incomplete_fact_count:incomplete,expired_fact_count:expired,future_fact_count:future,
    source:'operator_recorded',independently_verified:false,inventory_verified:false,
    publication_id,publication_key,source_local_revision,source_local_digest};
  return {meta,criteria:policy.criteria,effectiveFacts,nextBoundaryMs};
}
module.exports={normalizePublishedPolicy,policyDigest,effectiveSnapshot};
