/* Trusted service entitlements. Quota units are resource slots, never payments. */
const crypto = require('node:crypto');
const {AiError} = require('./ai_contract.cjs');
const FEATURES = ['acquisition','intent_analysis','export','handoff','strategy','team'];
const NAMES = {experience:'体验',professional:'专业获客',team:'团队企业'};
const COLLECTIONS = {period: 'fangyu_product_quota_periods', request: 'fangyu_product_quota_requests'};
const hash = value => crypto.createHash('sha256').update(value).digest('hex');
const KEY = /^[A-Za-z0-9_.:-]{8,128}$/;
class ProductEntitlementError extends AiError {
  constructor(code,message,status=403){super('PRODUCT_'+code,message,status);this.mutation_committed=false;}
}
const fail = (code,message,status) => {throw new ProductEntitlementError(code,message,status);};
function policyFor(value,now){
  if(value===undefined)return {configured:false,package:'pilot_existing',name:'现有试点权限',features:[...FEATURES],seat_limit:null,store_limit:null,analysis_quota:null,billing_period:null,expired:false};
  const keys=['package','name','features','expires_at','seat_limit','store_limit','analysis_quota','billing_period'];
  if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).some(k=>!keys.includes(k))||
    !['experience','professional','team'].includes(value.package)||!Array.isArray(value.features)||
    value.features.some(k=>!FEATURES.includes(k))||new Set(value.features).size!==value.features.length)
    fail('POLICY_INVALID','企业服务权益配置无效');
  for(const k of ['seat_limit','store_limit','analysis_quota'])if(value[k]!=null&&(!Number.isSafeInteger(value[k])||value[k]<0))fail('POLICY_INVALID','企业服务额度配置无效');
  if(value.expires_at!=null&&(!Number.isFinite(value.expires_at)||value.expires_at<=0))fail('POLICY_INVALID','服务到期时间无效');
  if(![undefined,null,'month','quarter','year','pilot'].includes(value.billing_period))fail('POLICY_INVALID','服务周期配置无效');
  const name=value.name||NAMES[value.package];
  if(typeof name!=='string'||name.length>60)fail('POLICY_INVALID','功能版本名称无效');
  return {configured:true,package:value.package,name,features:[...value.features],
    seat_limit:value.seat_limit??null,store_limit:value.store_limit??null,analysis_quota:value.analysis_quota??null,
    billing_period:value.billing_period??null,expires_at:value.expires_at??null,expired:value.expires_at!=null&&now/1000>=value.expires_at};
}
function periodFor(value){
  if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).some(k=>!['id','start_at','end_at'].includes(k))||
    typeof value.id!=='string'||!KEY.test(value.id)||!Number.isSafeInteger(value.start_at)||value.start_at<0||
    !Number.isSafeInteger(value.end_at)||value.end_at<=value.start_at)
    fail('PERIOD_REQUIRED','分析额度需先配置可信服务周期，暂不能开始新的分析',409);
  return {id:value.id,start_at:value.start_at,end_at:value.end_at};
}
function productOptionsFromEnvironment(environment){
  const options={};
  for(const [field,option] of [['PRODUCT_ACCESS_POLICY','productAccessPolicy'],['PRODUCT_SERVICE_PERIOD','servicePeriod']]){
    if(!Object.hasOwn(environment,field))continue;
    const raw=environment[field];let value;
    if(typeof raw!=='string'||!raw.trim()||raw.length>8192)fail('SERVER_CONFIG_INVALID','企业服务配置无效，需管理员核对',503);
    try{value=JSON.parse(raw);if(option==='productAccessPolicy')policyFor(value,Date.now());else periodFor(value);}
    catch{fail('SERVER_CONFIG_INVALID','企业服务配置无效，需管理员核对',503);}
    options[option]=value;
  }
  return options;
}
function repoFor(transaction,companyId){
  if(!transaction?.collection)fail('STORAGE_UNAVAILABLE','服务额度事务存储尚未配置',503);
  const ref=(kind,key)=>transaction.collection(COLLECTIONS[kind]).doc(hash(`${companyId}\n${key}`));
  return {async get(kind,key){const snap=await ref(kind,key).get(),row=Array.isArray(snap.data)?snap.data[0]:snap.data;
    if(!row)return null;if(row.companyId!==companyId)fail('TENANT_MISMATCH','服务额度企业范围需核对');
    const {_id,...value}=row;return value;},set(kind,key,value){const {_id,...clean}=value;return ref(kind,key).set({...clean,companyId});}};
}
const requestId=(username,operation,key)=>hash(JSON.stringify([username,operation,key]));
const counts=users=>({seats:users.filter(u=>!u.disabled).length,stores:new Set(users.filter(u=>!u.disabled&&u.store_id).map(u=>u.store_id)).size});
function createProductEntitlements({companyId,productAccessPolicy,servicePeriod,clock=Date.now}){
  if(typeof companyId!=='string'||!companyId||companyId.length>200)fail('TENANT_INVALID','服务企业范围无效');
  const current=()=>policyFor(productAccessPolicy,clock());
  function requireFeature(feature){const p=current();if(p.expired)fail('EXPIRED','当前服务权益已到期；核对、撤回和安全停止仍可执行');
    if(!p.features.includes(feature))fail('FEATURE_DENIED','当前服务版本未开放此功能');return p;}
  function validateMemberChange(state,next){
    if(Object.hasOwn(next,'store_id')&&(typeof next.store_id!=='string'||next.store_id&&!/^[A-Za-z0-9_-]{1,80}$/.test(next.store_id)))fail('STORE_INVALID','门店分组标识无效',400);
    const before=counts(state.users),after=counts(state.users.filter(u=>u.username!==next.username).concat(next));
    // Deactivation and reductions remain possible after expiry or downgrade.
    if(after.seats<=before.seats&&after.stores<=before.stores)return;
    const p=requireFeature('team');
    if(p.seat_limit!=null&&after.seats>p.seat_limit&&after.seats>before.seats)fail('SEAT_LIMIT','启用成员已达到服务席位上限',429);
    if(p.store_limit!=null&&after.stores>p.store_limit&&after.stores>before.stores)fail('STORE_LIMIT','启用成员的门店分组已达到服务上限',429);
  }
  function assertPeriod(row,period){if(row&&(row.period_id!==period.id||row.start_at!==period.start_at||row.end_at!==period.end_at||
    ['reserved_units','confirmed_units','unknown_units'].some(k=>!Number.isSafeInteger(row[k])||row[k]<0)||row.unknown_units>row.reserved_units))
    fail('PERIOD_CONFLICT','服务周期或用量账本需核对',409);}
  function assertRequest(row,{username,operation,key}){if(row&&(row.username!==username||row.operation!==operation||row.request_key!==key||
    !['reserved','confirmed','released','unknown','cached','cancelled'].includes(row.status)))fail('REQUEST_SCOPE','原额度请求范围需核对',409);}
  async function reserve({transaction,user,operation,key,inputHash,providerRequestId,amount,cached=false}){
    if(!user||!['operator','admin'].includes(user.role)||user.disabled||typeof user.username!=='string'||!user.username)fail('AUTH_REQUIRED','需有效的企业成员身份开始分析');
    const p=requireFeature(operation==='intent_analyze'?'intent_analysis':'strategy');
    // Content uses one existing service resource slot, not a second allowance.
    // Financial cost is still reserved/settled only by the shared AI budget.
    if(!['intent_analyze','content_generate'].includes(operation)||p.analysis_quota==null)return null;
    if(typeof key!=='string'||!KEY.test(key)||typeof inputHash!=='string'||! /^[a-f0-9]{64}$/.test(inputHash)||
      !Number.isSafeInteger(amount)||amount<1)fail('REQUEST_INVALID','分析额度请求编号或单位无效',400);
    const period=periodFor(servicePeriod),now=clock();
    if(now/1000<period.start_at||now/1000>=period.end_at)fail('PERIOD_INACTIVE','服务额度周期尚未开始或已结束，暂不能开始新的分析',403);
    const repo=repoFor(transaction,companyId),id=requestId(user.username,operation,key),old=await repo.get('request',id);
    assertRequest(old,{username:user.username,operation,key});
    if(old?.status==='cancelled')fail('REQUEST_CANCELLED','原请求已取消；请核对后使用新编号',409);
    if(old&&old.input_hash!==inputHash)fail('REQUEST_CONFLICT','同一分析编号内容已变化，请先核对原请求',409);
    if(old&&['reserved','unknown'].includes(old.status))fail('REQUEST_UNKNOWN','原分析结果尚未核对，额度仍保留，请勿重复提交',409);
    if(old?.status==='released')fail('REQUEST_RELEASED','原分析已确认未消耗；重试请使用新请求编号',409);
    if(old&&['confirmed','cached'].includes(old.status)){if(cached)return {replayed:true,request_id:id,period_id:old.period_id};
      fail('REQUEST_RESOLVED','原分析已登记消耗，请读取结果或核对后使用新编号',409);}
    const saved=await repo.get('period',period.id);assertPeriod(saved,period);
    const budget=saved||{period_id:period.id,start_at:period.start_at,end_at:period.end_at,reserved_units:0,confirmed_units:0,unknown_units:0};
    if(!cached&&budget.reserved_units+budget.confirmed_units+amount>p.analysis_quota)fail('ANALYSIS_LIMIT','当前服务周期的分析额度不足，暂未开始新的分析',429);
    const row={username:user.username,store_id:user.store_id||'',operation,request_key:key,input_hash:inputHash,
      provider_request_id:providerRequestId,period_id:period.id,amount:cached?0:amount,status:cached?'cached':'reserved',created_at:now};
    if(!cached)await repo.set('period',period.id,{...budget,reserved_units:budget.reserved_units+amount});
    await repo.set('request',id,row);
    return {request_id:id,period_id:period.id,username:user.username,operation,request_key:key,
      input_hash:inputHash,provider_request_id:providerRequestId,amount:row.amount};
  }
  async function settle({transaction,plan,outcome}){
    if(!plan||plan.replayed)return;const repo=repoFor(transaction,companyId),row=await repo.get('request',plan.request_id);
    assertRequest(row,{username:plan.username,operation:plan.operation,key:plan.request_key});
    if(!row||row.provider_request_id!==plan.provider_request_id||row.input_hash!==plan.input_hash||row.period_id!==plan.period_id||row.amount!==plan.amount)
      fail('SETTLEMENT_SCOPE','服务额度结算来源需核对',503);
    if(row.status!=='reserved')return;
    const budget=await repo.get('period',row.period_id);
    if(!budget||budget.reserved_units<row.amount||!['confirmed','released','unknown'].includes(outcome))fail('SETTLEMENT_CONFLICT','服务额度用量暂无法核对',503);
    const next={...budget};
    if(outcome==='unknown')next.unknown_units+=row.amount;
    else {next.reserved_units-=row.amount;if(outcome==='confirmed')next.confirmed_units+=row.amount;}
    await repo.set('period',row.period_id,next);await repo.set('request',plan.request_id,{...row,status:outcome,completed_at:clock()});
  }
  async function summary({state,transaction}){
    const p=current(),active=counts(state.users);let period=null,budget=null,periodError=false;
    if(p.analysis_quota!=null){try{period=periodFor(servicePeriod);}catch(e){if(!(e instanceof ProductEntitlementError))throw e;periodError=true;}
      if(period){budget=await repoFor(transaction,companyId).get('period',period.id);assertPeriod(budget,period);}}
    const reserved=budget?.reserved_units||0,confirmed=budget?.confirmed_units||0;
    return {current:p,period,period_configured:!periodError&&!!period,period_active:!!period&&clock()/1000>=period.start_at&&clock()/1000<period.end_at,
      usage:{unit:'comment_analysis_slots',confirmed,reserved,unknown:budget?.unknown_units||0,remaining:p.analysis_quota==null?null:Math.max(0,p.analysis_quota-confirmed-reserved)},
      allocation:{enabled_members:active.seats,enabled_member_store_groups:active.stores,seat_scope:'all_enabled_login_members',store_scope:'enabled_member_store_bindings'},
      payment_enabled:false,payment_provider:'not_configured',price:null,billing_verified:false,
      message:'服务资源额度由云端事务核对；本机执行、分析槽消耗与平台实际收费、成交和到账分别记录。'};
  }
  async function status({transaction,user,key,operation}){
    if(operation!=='intent_analyze'||typeof key!=='string'||!KEY.test(key))fail('REQUEST_INVALID','请使用原分析操作与请求编号核对',400);
    const repo=repoFor(transaction,companyId),id=requestId(user.username,operation,key),row=await repo.get('request',id);
    assertRequest(row,{username:user.username,operation,key});
    if(!row&&current().analysis_quota==null)return {request_id:key,operation_kind:operation,state:'not_tracked',
      execution_confirmed:null,reservation_retained:null,units:null,unit:'comment_analysis_slots',billing_verified:false,
      message:'当前服务未追踪此请求的分析槽，不能据此证明模型未执行；未创建取消记录。'};
    if(!row){await repo.set('request',id,{username:user.username,operation,request_key:key,status:'cancelled',created_at:clock()});
      return {request_id:key,operation_kind:operation,state:'cancelled',execution_confirmed:false,reservation_retained:false};}
    return {request_id:key,operation_kind:operation,state:row.status==='reserved'?'unknown':row.status,
      period_id:row.period_id||null,units:row.amount??0,execution_confirmed:['confirmed','cached'].includes(row.status)?true:['released','cancelled'].includes(row.status)?false:null,
      reservation_retained:['reserved','unknown'].includes(row.status),unit:'comment_analysis_slots',billing_verified:false};
  }
  return {requireFeature,validateMemberChange,reserve,settle,summary,status};
}
module.exports={createProductEntitlements,ProductEntitlementError,policyFor,periodFor,productOptionsFromEnvironment,COLLECTIONS};
