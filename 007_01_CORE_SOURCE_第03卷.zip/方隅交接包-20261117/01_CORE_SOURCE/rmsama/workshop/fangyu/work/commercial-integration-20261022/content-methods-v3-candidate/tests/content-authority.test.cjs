'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const crypto=require('node:crypto');
const {fixture,IDS}=require('./cloud-fixture.cjs');
const {hash}=require('../cloud/ai_contract.cjs');
const {methodDigest}=require('../cloud/content_methods.cjs');
const DATA={query:'整理虚构资料形成账号定位',instructions:'',persona:{},topic:null,draft:null,evidence:[],artifacts:[]};
const PASSWORD='[REDACTED:assigned_secret]';
const OUTPUT={summary:'待审核定位',facts:[],hypotheses:['仅合成资料'],artifact:{name:'虚构账号',positioning:'提供整理方法',audience:'整理入门者',pillars:['整理步骤'],voice:['直接'],avoid:['保证效果']}};
function synthetic(r){return {model:r.model,usage:{prompt_tokens:100,prompt_cache_hit_tokens:20,prompt_cache_miss_tokens:80,completion_tokens:50},choices:[{finish_reason:'stop',message:{content:JSON.stringify(OUTPUT)}}]};}
async function payload(f,scope={}){const {config}=await f.profile();const raw=JSON.stringify(DATA);return {
 environment_id:IDS.env,operation:'content_generate',request_id:'authority-original-request',submission_id:crypto.randomUUID(),
 scope:{tenant_id:IDS.tenant,store_id:IDS.store,account_id:IDS.account,platform:'xiaohongshu',company_id:IDS.company,actor:IDS.actor,...scope},
 task_id:'authority-task',method_id:'persona',method_digest:methodDigest('persona'),input_json:raw,input_digest:hash(raw),
 expected_device_id:IDS.device,expected_revision:config.revision,expected_rules_version:config.rules_version};}

test('HQ with no fixed store can generate for its own platform account in either currently authorized central store',async()=>{
 const f=await fixture({provider:synthetic});
 await f.changeTrustedState(state=>{const user=state.users.find(u=>u.username===IDS.actor);user.role='admin';delete user.store_id;});
 const profile=await f.profile();assert.equal(profile.content_generation_capability.available,true);
 assert.equal(profile.content_generation_capability.store_scope_verified,true);
 assert.equal(profile.content_generation_capability.store_scope_type,'company');
 assert.equal(profile.content_generation_capability.store_scope_count,2);
 const p=await payload(f,{store_id:IDS.storeB}),answer=await f.call('content_generate',p);
 assert.equal(answer.status,200);assert.deepEqual(answer.data.content_generation.output,OUTPUT);assert.equal(f.calls(),1);
 const status=await f.readStatus(p);assert.equal(status.status,200);assert.equal(status.data.content_generation.result_available,true);
});

test('remembered-login ID and platform executor ID may differ through login and refresh without changing account ownership',async()=>{
 const f=await fixture({provider:synthetic}),loginDevice='fixture-remembered-installation-32';
 const login=await f.call('login',{username:IDS.actor,password:PASSWORD,remember_device:true,device_id:loginDevice},'');
 assert.equal(login.status,200);assert.notEqual(login.data.device_id,IDS.device);
 const p=await payload(f),answer=await f.call('content_generate',p,login.data.token);
 assert.equal(answer.status,200);assert.deepEqual(answer.data.content_generation.output,OUTPUT);
 const refresh=await f.call('refresh',{device_id:loginDevice,next_refresh_token:'rd_'+'R'.repeat(43)},login.data.refresh_token);
 assert.equal(refresh.status,200);assert.equal(refresh.data.device_id,loginDevice);
 const status=await f.readStatus(p,refresh.data.token);
 assert.equal(status.status,200);assert.equal(status.data.content_generation.result_available,true);assert.equal(f.calls(),1);
 const forged=await f.call('content_generate',{...p,expected_device_id:loginDevice},refresh.data.token);
 assert.equal(forged.status,403);assert.equal(f.calls(),1);
});

test('operator cannot use another central store and HQ cannot invent a central store',async t=>{
 for(const hq of [false,true])await t.test(hq?'HQ unknown store':'operator other store',async()=>{
  const f=await fixture({provider:synthetic});
  if(hq)await f.changeTrustedState(state=>{state.users.find(u=>u.username===IDS.actor).role='admin';});
  const p=await payload(f,{store_id:hq?'fy_s_ffffffffffffffffffffffff':IDS.storeB});
  const answer=await f.call('content_generate',p);assert.equal(answer.status,403);assert.equal(f.calls(),0);
  assert.equal((await f.profile(f.admin)).budget.reserved_cny,0);
 });
});

test('central store removal during generation settles actual usage but cannot resurrect its discarded candidate',async()=>{
 let f,removed;
 f=await fixture({provider:async r=>{
  await f.changeCentralCatalogue(manifest=>{removed=structuredClone(manifest.stores);manifest.stores=manifest.stores.filter(row=>row.id!==IDS.storeB);manifest.catalog_digest='d'.repeat(64);});
  return synthetic(r);
 }});
 await f.changeTrustedState(state=>{const u=state.users.find(u=>u.username===IDS.actor);u.role='admin';delete u.store_id;});
 const p=await payload(f,{store_id:IDS.storeB}),answer=await f.call('content_generate',p);
 assert.equal(answer.data.content_generation.result_available,false);assert.equal(Object.hasOwn(answer.data.content_generation,'output'),false);
 const budget=(await f.profile(f.admin)).budget;assert.equal(budget.reserved_cny,0);assert.ok(budget.spent_cny>0);
 await f.changeCentralCatalogue(manifest=>{manifest.stores=removed;manifest.catalog_digest='c'.repeat(64);});
 const status=await f.readStatus(p);assert.equal(status.status,200);
 assert.equal(status.data.content_generation.state,'completed_no_result');assert.equal(status.data.content_generation.result_available,false);
 assert.equal((await f.call('content_generate',p)).status,409);assert.equal(f.calls(),1);
});

test('a changed central catalog or operator grant during generation discards output even while the store still exists',async t=>{
 for(const change of ['catalog','grant'])await t.test(change,async()=>{
  let f;f=await fixture({provider:async r=>{
   if(change==='catalog')await f.changeCentralCatalogue(manifest=>{manifest.catalog_digest='e'.repeat(64);});
   else await f.changeTrustedState(state=>{state.users.find(u=>u.username===IDS.actor).store_id=IDS.storeB;});
   return synthetic(r);
  }});
  const p=await payload(f),answer=await f.call('content_generate',p);
  assert.equal(answer.data.content_generation.result_available,false);assert.equal(f.calls(),1);
  const budget=(await f.profile(f.admin)).budget;assert.equal(budget.reserved_cny,0);assert.ok(budget.spent_cny>0);
 });
});

test('revoked executor, changed expected device and another member device never gain account authority',async t=>{
 for(const kind of ['revoked','other_owned_device','other_member','duplicate_claim'])await t.test(kind,async()=>{
  const f=await fixture({provider:synthetic}),p=await payload(f);
  await f.changeTrustedState(state=>{
   if(kind==='revoked')state.devices[0].revoked=true;
   if(kind==='other_owned_device'){
    state.devices.push({...state.devices[0],id:'other-executor-device',digest:hash('different-executor-token')});p.expected_device_id='other-executor-device';
   }
   if(kind==='other_member')state.devices[0].owner=IDS.admin;
   if(kind==='duplicate_claim')state.xhs_claims.push({...state.xhs_claims[0],device_id:'conflicting-device',uid_hash:hash('another-platform-identity')});
  });
  const answer=await f.call('content_generate',p);assert.equal(answer.status,403);assert.equal(f.calls(),0);
 });
});

test('executor revocation during generation settles usage and permanently withholds the output',async()=>{
 let f;f=await fixture({provider:async r=>{await f.changeTrustedState(state=>{state.devices[0].revoked=true;});return synthetic(r);}});
 const p=await payload(f),answer=await f.call('content_generate',p);
 assert.equal(answer.data.content_generation.result_available,false);
 const budget=(await f.profile(f.admin)).budget;assert.equal(budget.reserved_cny,0);assert.ok(budget.spent_cny>0);
 await f.changeTrustedState(state=>{state.devices[0].revoked=false;});
 const status=await f.readStatus(p);assert.equal(status.data.content_generation.state,'completed_no_result');
 assert.equal(status.data.content_generation.result_available,false);assert.equal(f.calls(),1);
});
