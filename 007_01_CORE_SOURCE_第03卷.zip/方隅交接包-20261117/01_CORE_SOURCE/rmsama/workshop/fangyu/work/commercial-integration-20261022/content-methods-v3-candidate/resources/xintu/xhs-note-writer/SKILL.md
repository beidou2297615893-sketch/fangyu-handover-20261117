---
name: xhs-note-writer
description: >-
  Write Xiaohongshu titles and publish copy for carousel/image notes and video captions. Samples high-engagement references
  via Just One API, applies voice and compliance rules during drafting, and outputs format-specific packages aligned with
  account DNA. Use for 笔记正文, 图文文案, 视频配文, 标题, 种草, 干货笔记, 避雷帖, or copy distinct from a video spoken script.
---

# Xiaohongshu Note Writer

Write **titles + publish copy**. Spoken scripts and shot tables belong to `xhs-video-director`.

Read `../references/ai-voice-guardrails.md`, `../references/voice-cold-start.md`, and
`../references/format-playbook.md` before drafting.

## Format split

| Format | Writes | Does not write |
|---|---|---|
| `carousel` / `image` | Title matrix, fold-line body, slide outline, tags, CTA | Final designed slides, cover PNG |
| `video` | Title matrix, short caption, tags, CTA | Spoken script, shot table, on-screen text |

## Workflow

1. Read account DNA from `~/.xhs/account-dna.md` or workspace `.xhs/account-dna.md`.
2. Confirm format: `carousel` or `video`. If unclear, ask once; otherwise infer from `../references/format-playbook.md`.
3. Collect topic, promised value, proof artifacts, and 1-2 search keywords. Keep any user-supplied
   reusable topic title intact as a candidate — do not auto-compress it.
4. Load **user style library** for the same format:
   - Read `references/user-style-library.md`
   - Run `scripts/load_style_library.py --format <carousel|video>`
   - If user pasted new samples in chat, ingest with `scripts/ingest_style_reference.py` first
5. Resolve voice before drafting (see `../references/voice-cold-start.md`):
   - `voice_anchor=user_library` or DNA voice → proceed
   - otherwise build a provisional voice from this chat + the **human texture recipe**, then draft
   - Ask at most 1 voice question if needed; **do not** block the turn or fall back to 干货腔
   - **Do not** use market samples as the speaking voice
6. Probe external market samples only for **structure** (after voice texture is set), or when the user
   asks for trend alignment:
   - **Primary**: `scripts/fetch_style_samples.py` with `JUSTONE_API_TOKEN`
   - **Fallback**: WebSearch per `../references/websearch-fallback.md`
7. Extract patterns with `references/style-extraction-schema.md`. User library / provisional voice =
   tone; Just One API / WebSearch = secondary mechanics only.
8. Generate titles with `references/title-craft.md` (punch + search mix; 5-8 candidates + dual-job rec).
9. Draft 2-3 copy options using format schema + voice guardrails. Reject 全国干货腔 in self-check.
10. Mark missing user evidence as `[此处需你补真实细节]`; never invent.
11. Self-check against `xhs-publish-guard` rubric items 1-6 and compliance rewrite guide.
12. Return the recommended package; offer Obsidian archive per `../references/obsidian-archive.md`.

## Carousel writing rules

- **Fold gate**: first 3 visible lines decide whether the rest is read.
- At least 2 of: audience anchor, concrete result/number, open loop, colloquial pain line.
- Paragraphs: 1-3 short lines; blank line between paragraphs; default 300-800 chars.
- Note types to choose from: 干货教程, 清单合集, 经验复盘, 种草测评, 避雷拔草, 观点判断, 工具推荐.
- Include one original proof artifact and one honest limit when reviewing tools/workflows.
- Optional slide outline when content is list/tutorial heavy (6+ slides).
- See `references/carousel-copy-schema.md`.

## Video caption rules

- Line 1 = search-facing summary (~15-25 chars when possible).
- 80-220 chars unless user asks for longer.
- Complement the video; never paste the spoken script.
- See `references/video-caption-schema.md`.

## Style sampling

Read `../references/justone-api.md` and `../references/websearch-fallback.md`.

Priority:

1. User uploads in `~/.xhs/style-library/`
2. Account DNA voice rules
3. Provisional voice card from the cold-start probe
4. Just One API market samples — **structure only**, never as speaking voice
5. WebSearch snippets when API unavailable (`style_confidence=low`, still not primary voice)

Split external searches by `noteType`:

- `NORMAL_NOTE` for carousel
- `VIDEO_NOTE` for video captions

### Ingest user samples

```bash
python3 scripts/ingest_style_reference.py --file ./my-note.md --format carousel --label "我的代表作"
python3 scripts/ingest_style_reference.py --file ./my-script.md --format video --label "口播语气"

# Paste directly from the clipboard instead of a file
pbpaste | python3 scripts/ingest_style_reference.py --file - --format carousel --label "我的干货风"

python3 scripts/load_style_library.py --format carousel
```

`load_style_library.py` auto-discovers a project-level `.xhs/style-library/` by walking up from the
current directory, and merges it ahead of the global `~/.xhs/style-library/`. It reports
`voice_anchor=user_library` once 2+ references exist for the format.

## Output

Return:

- format (`carousel` or `video`)
- `voice_source` + confidence (`user_library` | `dna` | `provisional` | blocked-until-probe)
- style evidence summary (structure vs voice separated)
- title candidates tagged `feed` / `search` / `hybrid` + recommended + alternate job
- 2-3 copy options + recommendation
- body/caption, tags, CTA
- carousel only: slide outline when useful
- video only: `script_boundary` sentence
- placeholders needing user input
- similarity-risk notes
- optional Obsidian path suggestion

## Handoffs

- Video script/shots → `xhs-video-director`
- Cover/first frame/slide visual system → `xhs-visual-lab`
- Final gate → `xhs-publish-guard`
- Archive → `../references/obsidian-archive.md`
