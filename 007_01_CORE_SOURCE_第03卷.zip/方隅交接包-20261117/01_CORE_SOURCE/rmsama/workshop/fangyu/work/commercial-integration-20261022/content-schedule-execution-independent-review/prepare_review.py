from pathlib import Path
import ast,difflib,hashlib,json
W=Path(__file__).resolve().parent;P=W.parents[2];C=W.parent/'content-schedule-execution-candidate'
B=P/'work/parallel-integration-20261018/final-integration/candidate-unified-v77/project'
sha=lambda b:hashlib.sha256(b).hexdigest()
expected={'FINAL-RECEIPT.json':'e7166a7bd9be6953080ec68039b5cbe77876359447fe6c590b5bd3ac350b7638','SEALED.json':'f2bb58eabc75948fa502eb50c8e20d79e2707dafba4ddb5c7db8ba740f03f0bf','SOURCE-FILES.json':'b59840aaf2ede05083a95d7008fb0cb71fcd4298a138d9826e0fba2f4dcff650','CHANGES.patch':'099a1a9d0e951848cf3c9b08e37548437e68b042463fa412dab9204abfd2c772'}
for name,pin in expected.items():assert sha((C/name).read_bytes())==pin,name
manifest=json.loads((C/'SOURCE-FILES.json').read_text('utf-8'));rows=manifest['files'];assert len(rows)==8
patch=[];summary=[]
for row in rows:
 name=row['path'];before=(B/name).read_bytes() if row['beforeSha256'] else b'';after=(C/'overlay'/name).read_bytes()
 assert (sha(before)==row['beforeSha256']) if row['beforeSha256'] else not (B/name).exists()
 assert sha(after)==row['afterSha256']
 assert (C/'source-candidate'/name).read_bytes()==after
 if name.endswith('.py'):ast.parse(after)
 chunks=list(difflib.unified_diff(before.decode('utf-8-sig').splitlines(True),after.decode('utf-8-sig').splitlines(True),fromfile='a/'+name,tofile='b/'+name))
 if row['beforeSha256']:patch.extend(chunks)
 summary.append({'path':name,'before':row['beforeSha256'],'after':row['afterSha256'],'bytes':len(after)})
(W/'EXISTING-FILE-DIFF.patch').write_text(''.join(patch),'utf-8',newline='')
receipt=json.loads((C/'FINAL-RECEIPT.json').read_text('utf-8'))
for name,pin in receipt['evidence'].items():assert sha((C/name).read_bytes())==pin,name
for name in ('test_factory_schedule.py','QA-INPUTS.json'):(W/name).write_bytes((C/name).read_bytes())
(W/'STATIC-RESULTS.json').write_text(json.dumps({'status':'PASS_FIXED_AUTHOR_INPUTS_AND_OVERLAY','fixed':expected,'source':summary,'authorEvidencePinsChecked':len(receipt['evidence']),'fixtureSourceSha256':sha((W/'test_factory_schedule.py').read_bytes()),'execution':'New owned data/loopback only; author source and original QA release read-only; no product edits or synthetic approvals transplanted into source.'},ensure_ascii=False,indent=2),'utf-8')
print(json.dumps({'status':'STATIC_INPUTS_FIXED','sourceFiles':len(rows),'authorEvidencePinsChecked':len(receipt['evidence'])}))
