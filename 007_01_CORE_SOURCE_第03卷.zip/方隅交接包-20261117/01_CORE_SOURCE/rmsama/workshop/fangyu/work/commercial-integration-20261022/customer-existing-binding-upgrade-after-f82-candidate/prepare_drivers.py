from pathlib import Path
import ast,hashlib,json,shutil
T=Path(__file__).resolve().parent;W=T.parent
Q=W/'douyin-search-customer-after-f82-candidate'
B=T/'old-binding';fixtures=B/'payload/qa-fixtures';fixtures.mkdir()
for name in ('cloud_fixture.py','compiled-fixture.json'):
    shutil.copy2(Q/'source-joint1/payload/qa-fixtures'/name,fixtures/name)
bridge=(W/'xhs-customer-runtime-after-f82-candidate/serve_original_cloud.cjs').read_text('utf-8')
bridge=bridge.replace("ROOT=path.join(D,'../customer-read-cloud-lease-candidate/cloud-candidate-final')",
    'ROOT='+json.dumps(str(W/'customer-read-cloud-lease-candidate/cloud-candidate-final').replace('\\','/')))
bridge=bridge.replace('factory-probe-7/payload/project/work/app/company.json','old-binding/payload/project/work/app/company.json')
bridge=bridge.replace("releaseApproved:false,customerReadReleaseEnabled:enabled", "releaseApproved:false,employeeReleaseEnabled:true,employeeReleaseVersion:'1.1.8-pilot.1',customerReadReleaseEnabled:enabled")
(T/'serve_upgrade_cloud.cjs').write_bytes(bridge.encode())
body=(T/'old_stage.py.in').read_text('utf-8');ast.parse(body)
(B/'old_stage.py').write_bytes(((B/'standard_loader_prefix.py').read_text('utf-8')+'\n'+body).encode())
print('Original old Service driver and single persistent original dual-contract memory cloud ready')
