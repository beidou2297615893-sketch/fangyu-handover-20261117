# 客户结果与实际投入候选交接

状态：候选行为通过，未合 S、未冻结、未安装，待 root 组合媒体/发布后真实 CUA。已停写；原 delivery-next-launch sealed 草案保持不动。

仅8文件增量：3个 Native 公共文件的最小插入/白名单/factory/freezer hunks + 新 `customer_outcomes_workbench.py`；app/backend/customers 的小入口和窄动作 + 新 `pages/customer-outcomes.mjs`。`base/` 是原字节，`candidate/` 是对应新字节，`CAS-FILES.json` / `PACKAGE.json` 有全部 base/final pins，`CHANGES.patch` 为标准文本 diff。root 已在此 base 后合媒体，禁止整文件覆盖当前 S；用原字节前后构造最小 hunks，保留媒体与发布变更。补丁 SHA：4a9a3d6cfb4fa48bd4c9da968609e04f3f62d04ad6f6bc177604f966a8b3e084。

验证 `VALIDATION.json`：12组原 Core/SQLite/CustomerHistory 行为、6组实际 Native StaticServer HTTP、13组 linkedom 实际 DOM render/bind 与 createBackend 通过，含当前客户 render/bind 次级按钮、真实 app shell 管理入口。补丁内4个 Python 与4个 JS 文件语法通过。测试只用候选内合成 SQLite，审计钩子拒绝候选外 DB/写入与外部网络/模型/平台；HTTP仅127.0.0.1。真实 N launcher/FROZEN/binding 前后未变。不是浏览器布局、生产或用户视觉验收。

最难链已实际通过：原客户 author_key 跨两个账号聚合1客→人工登记→原 key恢复/同 key重试不重复→统计。两个独立 Core 对同 SQLite 并发竞争同版本只成功1次；回执写失败时同事务的事件也回滚。保存后身份撤销返回 unknown；原 key恢复 accepted。not_found 不解除待核对锁，显式取消用同 SQLite 原子 tombstone 阻止迟到保存。accepted 的取消只确认已保存，不删除事实。撤销是新事件，保留原历史；更正可先撤销再新增。

动作只允许：`customer_outcome_read`、`customer_outcome_save`、`customer_outcome_cancel`、`customer_outcome_report`。Native工厂从 manifest固定bytes局部exec装载，不依赖release sys.path，损坏资源拒绝。新 helper 不提前import BusinessExecutor，不碰此前vendor唯一来源守卫。只在原Store的 `customer_outcome_events`/`customer_outcome_receipts` 追加事件和回执，无第二库、无 ContactJournal伪造发送/同步事件。事件保留原客户/评论/任务/账号来源引用、实际日期/事实/来源/人工确认；不复制原文或改AI、发送、会话。

界面：原客户详情新增“跟进结果”；管理分类新增“结果与投入”。17px浅色表单；人工登记/未对账一句，历史折叠。统计先人数/回款/已登记投入/回款投入比，成本明细/分母/口径折叠。无digest/request字段展示。金额元输入经严格字符串转换整数分；漏项未知，显式零可登记。软件/人工/渠道类别均明确且投入>0才计算回款/投入比；缺贡献利润，ROI始终为空。所有金额是人工登记未独立对账，不把高意向/点赞/复制变成业务事实。

统计范围为本机当前员工/当前门店，真实可见且来源门店明确的原客户；同平台跨账号按原author_key，跨平台不推断合并。按事实日期范围计去重人数；跳阶段不补前序。环节比例为同范围前后事件客户交集/前一事件客户数，首项和无效用本期任一结果客户为分母；不是同期获客转化率。撤销对当前统计生效，历史仍可核对。

下一步 root 先审最小hunks和pins，组合合入后更新冻结与当前 S 实际 HTTP/CUA；重点实际点客户结果保存/恢复、历史撤销、管理统计/投入。随后定向续接本 agent 填最终安装 allowlist 并只 prepare；本轮未安装。
