"""Create the next-entry review draft from the already reviewed v66 flow.

This generator writes only to its own work directory. It never installs.
"""
from pathlib import Path
import hashlib

HERE=Path(__file__).resolve().parent
SOURCE=HERE.parent/'delivery-v66/install_next_launch.DRAFT.py'
text=SOURCE.read_text(encoding='utf-8')
begin=text.index('ACCEPTED = {')
end=text.index('\nV65_UNIFIED_SHA',begin)
text=text[:begin]+'''ACCEPTED = {}  # Deliberately empty until root reviews final immutable pins.
INSTALLATION_REVIEWED = False  # Draft cannot install, even after an allowlist is filled.
V65_ROLLBACK_FILES = 2777
'''+text[end:]
text=text.replace('import json\n','import json\nimport re\nimport stat\n')
text=text.replace('before.st_ino, before.st_size, before.st_mtime_ns','before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns')
text=text.replace('after.st_ino, after.st_size, after.st_mtime_ns','after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns')
text=text.replace('if not path.is_file() or before.st_nlink != 1:', 'if not stat.S_ISREG(before.st_mode) or before.st_nlink != 1:')
text=text.replace("exec(compile(raw, str(GENERIC), 'exec'), module.__dict__)","exec(compile(raw, str(GENERIC), 'exec', optimize=0), module.__dict__)")
text=text.replace("closure(F / 'candidate-unified-v65', V65_UNIFIED_SHA, 2777)","closure(F / 'candidate-unified-v65', V65_UNIFIED_SHA, V65_ROLLBACK_FILES)")
text=text.replace("    spec = ACCEPTED[candidate]\n", "    spec = reviewed_spec(candidate)\n    evidence_root = P / 'work/commercial-integration-20261022' / spec['delivery']\n")
text=text.replace("exact(HERE / rel, pin)","exact(evidence_root / rel, pin)")
text=text.replace("summary = read_json((HERE / 'frozen-native/SUMMARY.json').read_bytes())", "summary = read_json(exact(evidence_root / 'frozen-native/SUMMARY.json', spec['evidence']['frozen-native/SUMMARY.json']))")
text=text.replace("summary['totalHttpGroups'] != 32", "summary['totalHttpGroups'] != spec['http_groups']")
text=text.replace("staged = read_json((base / 'STAGED.json').read_bytes())", "staged = read_json(exact(base / 'STAGED.json', spec['staged_sha']))")
text=text.replace("'validation': str(HERE / 'frozen-native/SUMMARY.json'),", "'validation': str(P / 'work/commercial-integration-20261022' / spec['delivery'] / 'frozen-native/SUMMARY.json'),")
text=text.replace("'scope': 'Recovery checkpoint only; preserve live data, sessions, v65, and old CLI; next-launch only.',", "'scope': 'Reviewed next-launch entry only; preserve live data, sessions, v65 rollback, and old CLI.',")
text=text.replace("def install(candidate, recovery_ack):\n", "def install(candidate, recovery_ack):\n    if INSTALLATION_REVIEWED is not True:\n        raise RuntimeError('Installation is disabled in this review draft; root must approve final pins and this switch first')\n    reviewed_spec(candidate)\n")
text=text.replace("raise RuntimeError('v66 is a recovery checkpoint. Review the next feature release first; explicit acknowledgement is required.')", "raise RuntimeError('This candidate is a recovery checkpoint; explicit acknowledgement is required')")
text=text.replace("parser.add_argument('--candidate', required=True, choices=sorted(ACCEPTED))", "parser.add_argument('--candidate', required=True)")
text=text.replace("P / 'work/commercial-integration-20261022/delivery-v66'", "P / 'work/commercial-integration-20261022/delivery-next-launch'")
intro='''"""Next-launch review draft. Default CHECK; no app/service/process actions.

Derived from delivery-v66's fixed allowlist and original CAS/backup installer.
No final version or hash is guessed. ACCEPTED is empty and installation is
code-disabled until root approves the final immutable release and evidence.
--prepare, once pinned, writes only within this work directory.
"""'''
text=intro+text[text.index('\nfrom pathlib'):]
marker='\ndef check(candidate, allow_current_new=False):'
function='''
def reviewed_spec(candidate):
    if not isinstance(candidate, str) or not re.fullmatch(r'candidate-unified-v[0-9]+', candidate) or candidate not in ACCEPTED:
        raise RuntimeError('Candidate needs a reviewed fixed-pin entry')
    spec = ACCEPTED[candidate]
    fields = {'release_id', 'unified_sha', 'files', 'release_sha', 'candidate_launcher_sha',
              'recovery_checkpoint', 'evidence', 'delivery', 'http_groups', 'staged_sha'}
    if not isinstance(spec, dict) or set(spec) != fields:
        raise RuntimeError('Reviewed candidate schema is incomplete')
    if not re.fullmatch(r'ui-r57-[0-9]{8}T[0-9]{6}Z-[a-f0-9]{8}', spec['release_id']):
        raise RuntimeError('Reviewed release identifier is invalid')
    if not re.fullmatch(r'delivery-v[0-9]+', spec['delivery']):
        raise RuntimeError('Reviewed evidence folder is invalid')
    for key in ('unified_sha', 'release_sha', 'candidate_launcher_sha', 'staged_sha'):
        if not isinstance(spec[key], str) or not re.fullmatch(r'[a-f0-9]{64}', spec[key]):
            raise RuntimeError('A fixed reviewed SHA256 is required')
    if type(spec['files']) is not int or spec['files'] < 1 or type(spec['http_groups']) is not int or spec['http_groups'] < 32:
        raise RuntimeError('Reviewed closure and evidence counts are invalid')
    if type(spec['recovery_checkpoint']) is not bool or not isinstance(spec['evidence'], dict):
        raise RuntimeError('Reviewed evidence schema is invalid')
    if len(spec['evidence']) < 5 or 'frozen-native/SUMMARY.json' not in spec['evidence']:
        raise RuntimeError('Reviewed frozen acceptance evidence is incomplete')
    for key, pin in spec['evidence'].items():
        rel = PurePosixPath(key)
        if rel.is_absolute() or '..' in rel.parts or ':' in key or '\\\\' in key or rel.parts[0] != 'frozen-native' or rel.suffix != '.json':
            raise RuntimeError('Reviewed evidence member is invalid')
        if not isinstance(pin, str) or not re.fullmatch(r'[a-f0-9]{64}', pin):
            raise RuntimeError('Reviewed evidence SHA256 is required')
    return spec

'''
assert text.count(marker)==1
text=text.replace(marker,'\n'+function+marker)
compile(text,'install_next_launch.DRAFT.py','exec')
out=HERE/'install_next_launch.DRAFT.py'
assert not out.exists(),'Do not silently replace an existing review draft'
out.write_text(text,encoding='utf-8',newline='\n')
(HERE/'SOURCE.json').write_text(__import__('json').dumps({'source':str(SOURCE),'sourceSha256':hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
 'outputSha256':hashlib.sha256(out.read_bytes()).hexdigest(),'allowlistEntries':0,'installationReviewed':False,'productionWrites':0},ensure_ascii=False,indent=2),encoding='utf-8')
print(str(out))
