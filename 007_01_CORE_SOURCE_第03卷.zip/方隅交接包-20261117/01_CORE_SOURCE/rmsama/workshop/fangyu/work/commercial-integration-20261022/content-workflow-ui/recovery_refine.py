from pathlib import Path
p=Path(r'C:/积木软件工坊/项目/方隅公寓客户版/work/parallel-integration-20261018/final-integration/stage-02/project/work/ui-approved-implementation/ui-preview/pages/content-workflow.mjs')
s=p.read_text('utf-8')
s=s.replace("orphans=f.saved.filter(r=>!tasks.some(t=>t.id===r.taskId))", "orphans=f.saved.filter(r=>!tasks.some(t=>t.id===r.taskId&&t.runRequestId===r.requestId))")
s=s.replace("原执行暂未在任务列表核对到，仍保留原编号，不会重新生成。", "原执行的最终回执待核对，仍保留原编号，不会重新生成。")
s=s.replace("const original={action,payload:structuredClone(payload),done};", "const original={action,payload:structuredClone(payload),done,taskIds:arr(dataOf(workspace),'tasks').map(t=>t.id)};")
s=s.replace("if(run){f.runUnknown={requestId,taskId:data.taskId};", "if(run){f.recovered=false;f.runUnknown={requestId,taskId:data.taskId};")
old="if(receipt.found===true&&receipt.state==='succeeded'&&receipt.action===original.action){f.localUnknown=null;f.originalChecked=false;original.done?.(r);f.notice='原本地保存已确认成功，没有重复创建。';}"
new="""if(receipt.found===true&&receipt.state==='succeeded'&&receipt.action===original.action){
      if(original.action==='content_package_build'){f.originalChecked=true;f.error='审核内容包已保存；可以按原编号重新下载，不会再次打包。';return;}
      const recovered={...r,result:{...r.result}};
      if(original.action==='content_task_prepare'){const matches=arr(dataOf(r.workspace),'tasks').filter(t=>!original.taskIds.includes(t.id)&&t.sourceRevision===original.payload.expectedRevision&&t.methodId===original.payload.methodId&&t.query===original.payload.query.trim());if(matches.length!==1)throw Error('保存已确认，但对应任务仍需核对；请查看任务列表。');recovered.result.task=matches[0];}
      if(original.action==='content_task_apply'){const task=arr(dataOf(r.workspace),'tasks').find(t=>t.id===original.payload.taskId);if(!task?.appliedRefs)throw Error('采用记录已保存，对应内容仍需核对。');recovered.result.appliedRefs=task.appliedRefs;}
      f.localUnknown=null;f.originalChecked=false;original.done?.(recovered);f.notice='原本地保存已确认成功，没有重复创建。';}"""
assert old in s;s=s.replace(old,new)
s=s.replace("btn('按原编号重试本地保存','retry-local'", "btn(f.localUnknown?.action==='content_package_build'?'按原编号重新下载':'按原编号重试本地保存','retry-local'")
p.write_text(s,'utf-8')
