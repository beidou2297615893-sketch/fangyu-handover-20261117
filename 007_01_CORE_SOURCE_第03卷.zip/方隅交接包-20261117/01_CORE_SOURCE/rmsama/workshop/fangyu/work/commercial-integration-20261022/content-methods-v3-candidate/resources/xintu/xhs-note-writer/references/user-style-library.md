# User Style Library

Store the creator's own notes, captions, or scripts so writing skills mirror **their** voice—not only market samples.

## Default location

- Global: `~/.xhs/style-library/`
- Project: `<workspace>/.xhs/style-library/`

`load_style_library.py` walks up from the current directory (stopping at the repo root) to find a
project library, searches it before the global one, and merges by `id`. Pass `--workspace-root` to
override the discovery.

```
style-library/
├── index.json
├── carousel/
│   └── *.json
└── video/
    └── *.json
```

## What users can upload

| Input | Format | Examples |
|---|---|---|
| 图文正文 | `carousel` | 粘贴自己的笔记、`.md` / `.txt` 导出 |
| 视频配文 | `video` | 发布 caption、简介 |
| 口播稿/脚本 | `video` | `.md` 脚本；写作 skill 只参考语气与结构，不复制进 caption |
| 混合素材 | either | 标题 + 正文分文件；ingest 时合并 |

Do not require users to upload files—they can paste in chat and ask the agent to ingest once.

## Ingest command

```bash
python3 xhs-note-writer/scripts/ingest_style_reference.py \
  --file ~/Downloads/my-note.md \
  --format carousel \
  --label "我的干货风" \
  --title "可选标题"
```

Paste from stdin (`--file -` and a bare `-` both work):

```bash
pbpaste | python3 xhs-note-writer/scripts/ingest_style_reference.py \
  --file - --format video --label "口播转caption风"
```

Write to a project library instead of the global one:

```bash
python3 xhs-note-writer/scripts/ingest_style_reference.py \
  --file ./note.md --format carousel --label "本项目风格" --root .xhs/style-library
```

## Record schema

Each reference JSON contains:

- `id`, `format`, `label`, `title`, `body`, `source_type` (`user_upload`)
- optional `tags`, `notes`, `ingested_at`
- `observable_copy` only—no invented metrics

## Priority in writing

When `xhs-note-writer` runs:

1. **User style library** (same format) — primary voice anchor
2. **Account DNA** — positioning, avoid list, pillars
3. **Provisional voice card** — from `../../references/voice-cold-start.md` when 1-2 are empty
4. **Just One API / WebSearch** — secondary market **mechanics** only; never speaking voice

If ≥2 user references exist for the format, label output `voice_anchor=user_library` and do not let market samples override DNA conflicts.

If the library is empty, still draft with the human texture recipe in
`../../references/voice-cold-start.md` (`voice_source=provisional`). Do not wait for uploads, and do
not speak in market-sample 干货腔.

## Rules

- Never copy user uploads verbatim into new posts; extract mechanics only.
- User library beats generic market style when they conflict.
- Do not ingest others' notes without rights; user uploads should be their own work or licensed references they provide.
- Video scripts inform caption **tone and rhythm**, not full caption text.
