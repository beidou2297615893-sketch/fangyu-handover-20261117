from pathlib import Path
import ast,hashlib,json,re,shutil
from datetime import datetime,timezone,timedelta
from customer_review_rebinder import rebind_customer_reviews,RebindError
W=Path(__file__).resolve().parent;B=W/'own-compiled';cfg=json.loads((W/'INPUTS.json').read_bytes());project=Path(cfg['project']);release=Path(cfg['release']);rid=release.name;R=release.relative_to(project).as_posix()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(Path(p).read_bytes())
save=lambda p,v:Path(p).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n','utf-8')
ref='independent-local-review:b4faa36859349e9b68b274fead8ad01e181551aebeadfc472425f260fa57cddf';stamp=cfg['timestamp'];four=[release/'resources/customer-read'/n for n in ['distribution-evidence.json','douyin_owned_connection.json','douyin_owned_video_comments.json','review-index.json']]
unit=[]
def rejects(name,fn,prefix):
 before={str(p):p.read_bytes() for p in four}
 try:fn()
 except RebindError as e:assert str(e).startswith(prefix),(name,str(e))
 else:raise AssertionError('Helper must refuse '+name)
 assert all(p.read_bytes()==before[str(p)] for p in four)
 unit.append({'check':name,'result':'PASS','fourOutputsUnchanged':True})
rejects('future_timestamp',lambda:rebind_customer_reviews(project,release,ref,datetime.now(timezone.utc)+timedelta(days=1)),'review_timestamp')
index=four[-1];raw=index.read_bytes();doc=read(index);doc['reviews'].append({'purpose':'unreviewed_dysearch'});save(index,doc)
try:rejects('unknown_existing_purpose',lambda:rebind_customer_reviews(project,release,ref,stamp),'unsupported_existing_customer_purpose')
finally:index.write_bytes(raw)
helper=release/'resources/platform-runtime/vendor-src/assistant/employee_distribution.py';raw=helper.read_bytes()
try:
 helper.write_bytes(re.sub(rb"(?m)^HELD_STANDARD_MANIFEST_SHA256 = '[0-9a-f]{64}'",b"HELD_STANDARD_MANIFEST_SHA256 = '"+b'0'*64+b"'",raw));rejects('unstable_held_helper',lambda:rebind_customer_reviews(project,release,ref,stamp),'held_compatibility_not_stable:helper_pin')
finally:helper.write_bytes(raw)
result=rebind_customer_reviews(project,release,ref,stamp);pins=[sha(p) for p in four];again=rebind_customer_reviews(project,release,ref,stamp);assert [sha(p) for p in four]==pins
unit.append({'check':'same_inputs_and_explicit_time_idempotent_four_json','result':'PASS'})
save(W/'HELPER-UNIT.json',{'status':'PASS','checks':unit,'network':0})

def refresh_held():
 # Reuse the original held builder derivation, not the rebind function.
 contract=read(project/'HELD-STANDARD-MANIFEST.json');company=read(project/'work/app/company.json');excluded={helper.relative_to(project).as_posix(),(release/'RELEASE.json').relative_to(project).as_posix()}
 contract['companyConfigDigest']=hashlib.sha256(json.dumps(company,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
 contract['codeFiles']=[{'path':p.relative_to(project).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(project.rglob('*')) if p.is_file() and p.suffix.lower() in {'.py','.js','.mjs','.exe','.dll','.pyd'} and p.relative_to(project).as_posix() not in excluded];contract['codeFileCount']=len(contract['codeFiles']);assert contract['commercialDistributionApproved'] is False and contract['platformExecutionApproved'] is False
 save(project/'HELD-STANDARD-MANIFEST.json',contract)
 body=helper.read_text('utf-8');body,n=re.subn(r"(?m)^HELD_STANDARD_MANIFEST_SHA256 = '[0-9a-f]{64}'","HELD_STANDARD_MANIFEST_SHA256 = '"+sha(project/'HELD-STANDARD-MANIFEST.json')+"'",body);assert n==1;helper.write_text(body,'utf-8')
def manifests():
 d=read(release/'RELEASE.json');d['files']=[{'path':p.relative_to(release).as_posix(),'size':p.stat().st_size,'sha256':sha(p).upper()} for p in sorted(release.rglob('*')) if p.is_file() and p.name!='RELEASE.json'];save(release/'RELEASE.json',d)
 d=read(project/'SHIPPED-PINS.json');d['files']=[{'path':p.relative_to(project).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(project.rglob('*')) if p.is_file() and p.name!='SHIPPED-PINS.json'];save(project/'SHIPPED-PINS.json',d)
paths=['work/app/company.json','HELD-STANDARD-MANIFEST.json','work/shared-backend-integration/vendor-src/app.py','work/shared-backend-integration/vendor-src/SOURCE.json',R+'/resources/platform-runtime/vendor-src/app.py',R+'/resources/platform-runtime/vendor-src/SOURCE.json',helper.relative_to(project).as_posix(),R+'/RELEASE.json','SHIPPED-PINS.json']+[p.relative_to(project).as_posix() for p in four]
scenarios=[];rebinds=[]
def snapshot(name,expected):
 manifests();out=B/'payload/qa-scenarios'/name;out.mkdir(parents=True)
 for rel in paths:
  dest=out/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(project/rel,dest)
 scenarios.append({'name':name,'expected':expected,'releaseId':rid,'releaseSha256':sha(release/'RELEASE.json'),'closureSha256':sha(project/'SHIPPED-PINS.json'),'files':[{'path':p,'sha256':sha(project/p)} for p in paths]})
snapshot('baseline_rebound','accepted')
company=read(project/'work/app/company.json');company['releaseVersion']=str(company['releaseVersion'])+'-owned-rebind-test';save(project/'work/app/company.json',company);refresh_held();snapshot('company_old_material','rejected')
rebinds.append(rebind_customer_reviews(project,release,ref,stamp));snapshot('company_rebound','accepted')
for root in [project/'work/shared-backend-integration/vendor-src',release/'resources/platform-runtime/vendor-src']:
 with (root/'app.py').open('ab') as f:f.write(b'\n# Own material-binding fixture; unchanged Python AST.\n')
 doc=read(root/'SOURCE.json')
 for name,row in doc['files'].items():
  if (root/name).is_file():row['candidate_sha256']=sha(root/name)
 save(root/'SOURCE.json',doc)
refresh_held();snapshot('vendor_old_material','rejected')
rebinds.append(rebind_customer_reviews(project,release,ref,stamp));snapshot('vendor_rebound','accepted')
with helper.open('ab') as f:f.write(b'\n# Own stable held-helper material-byte fixture; no guard logic change.\n')
snapshot('helper_old_material','rejected')
rebinds.append(rebind_customer_reviews(project,release,ref,stamp));snapshot('helper_rebound','accepted')
save(W/'REBIND-RESULTS.json',rebinds);save(W/'SCENARIOS.json',scenarios)
prefix=(B/'standard_loader_prefix.py').read_text('utf-8')
body=(W/'factory_cases_body.py.in').read_text('utf-8').replace('@@SCENARIOS@@',repr(scenarios))
(B/'probe_entry.py').write_text(prefix+'\n'+body,'utf-8')
print(json.dumps({'caseCount':len(scenarios),'pairs':3,'entrySha256':sha(B/'probe_entry.py'),'compileOnce':True}))
