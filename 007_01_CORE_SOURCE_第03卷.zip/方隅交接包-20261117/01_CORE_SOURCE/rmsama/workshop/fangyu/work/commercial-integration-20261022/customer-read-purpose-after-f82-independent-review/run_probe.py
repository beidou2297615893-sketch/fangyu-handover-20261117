from pathlib import Path
import os,subprocess,json,hashlib,datetime
W=Path(__file__).resolve().parent;B=W/'independent-compiled';D=B/'dist/FangyuWorkbench';exe=D/'FangyuWorkbench.exe'
assert exe.is_file() and (D/'qa-fixtures/physical-junction').lstat().st_file_attributes&0x400
env={k:v for k,v in os.environ.items() if k not in ('PYTHONHOME','PYTHONPATH','VIRTUAL_ENV')}
for key in ['TEMP','TMP','LOCALAPPDATA','APPDATA']:
 p=B/'run-environment'/key;p.mkdir(parents=True,exist_ok=True);env[key]=str(p)
env.update(PYTHONDONTWRITEBYTECODE='1',PYTHONIOENCODING='utf-8')
with (B/'INDEPENDENT-ACTUAL-COMPILED.log').open('x',encoding='utf-8') as log:
 r=subprocess.run([str(exe),'--owned-customer-read-probe'],cwd=D,env=env,creationflags=subprocess.CREATE_NO_WINDOW,stdout=log,stderr=subprocess.STDOUT,timeout=180)
(W/'ACTUAL-RUN.json').write_text(json.dumps({'exitCode':r.returncode,'exeSha256':hashlib.sha256(exe.read_bytes()).hexdigest(),'entrySha256':hashlib.sha256((B/'probe_entry.py').read_bytes()).hexdigest(),'hiddenOwnCompiledExe':True,'authorExeNotRun':True,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat()},indent=2)+'\n','utf-8')
assert r.returncode==0,'See own INDEPENDENT-ACTUAL-COMPILED.log'
print('Independent actual compiled process exited0')
