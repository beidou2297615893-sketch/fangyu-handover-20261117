from pathlib import Path
import hashlib,json,shutil,subprocess,sys
W=Path(__file__).resolve().parent;A=W.parent/'customer-read-purpose-after-f82-candidate';P=W.parents[2]
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
fixed={'FINAL-RECEIPT.json':'b0d839d70ea5276566ecc484c565c907715450dba23993b386b1cf4bdd376f52','SEALED.json':'a897f52fc3fcb7e5a6d5086ada0d3cc2b2e42b9a1ae6f5ae0a6b2503c4a5107c','SOURCE-FILES.json':'b57efbf967fb1d1e23b86deb2b852f9dbfa1e21f1c13bd1f6661f33b9f388135','CANDIDATE.patch':'c342aa236868a6d6c28b3960fa494a7f47ca08dfb15bcacedb176a744b88e0fb'}
for n,pin in fixed.items():assert sha(A/n)==pin,(n,sha(A/n))
manifest=json.loads((A/'SOURCE-FILES.json').read_bytes());assert len(manifest['files'])==11
for r in manifest['files']:
 src=A/'source-candidate'/r['path'];assert sha(src)==r['sha256'];dest=W/'source-candidate'/r['path'];dest.parent.mkdir(parents=True,exist_ok=True)
 assert not dest.exists();shutil.copy2(src,dest)
scripts=['prepare_probe.py','prepare_entry.py','build_probe.py','source_entry_check.py.in']
for n in scripts:assert not (W/n).exists();shutil.copy2(A/n,W/n)
shutil.copy2(W/'independent_probe_body.py.in',W/'probe_body.py.in')
(W/'FIXED-INPUTS.json').write_text(json.dumps({'author':str(A),'fixed':fixed,'authorSources':manifest['files'],'reusedScripts':[{'path':n,'sha256':sha(A/n)} for n in scripts],'independentBodySha256':sha(W/'probe_body.py.in'),'originalSourceCompany':'immutable F82/company.json','onlyExternalResponseBoundarySynthetic':True,'noAuthorExeOrStateRunOrCopied':True,'derivedFourPurposeDocumentsWillRebindActualOwnBytes':True},ensure_ascii=False,indent=2)+'\n','utf-8')
for command in [('prepare_probe.py','independent-compiled'),('prepare_entry.py','independent-compiled')]:
 r=subprocess.run([str(P/'work/desktop-python/Scripts/python.exe'),'-X','utf8','-B',str(W/command[0]),command[1]],cwd=W,capture_output=True,text=True,encoding='utf-8');(W/(command[0]+'.log')).write_text(r.stdout+r.stderr,'utf-8');assert r.returncode==0,command
print('Pinned author inputs and own payload prepared; no EXE started')
