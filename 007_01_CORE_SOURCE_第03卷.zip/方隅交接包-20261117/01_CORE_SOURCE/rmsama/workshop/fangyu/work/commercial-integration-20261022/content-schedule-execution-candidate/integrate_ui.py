from pathlib import Path
import hashlib,json
W=Path(__file__).resolve().parent;S=W/'source-candidate'
p=S/'work/ui-approved-implementation/ui-preview/pages/content-operations.mjs'
raw=p.read_bytes();nl=b'\r\n' if b'\r\n' in raw else b'\n';text=raw.decode().replace('\r\n','\n')
changes=[
 ("import {renderMedia,bindMedia} from './content-media.mjs';","import {renderMedia,bindMedia} from './content-media.mjs';\nimport {renderSchedule,bindSchedule} from './content-schedule.mjs';"),
 ('<aside class="co-panel co-calendar">${panelHeading(\'发布计划\'', '<aside class="co-panel co-calendar">${renderSchedule(state,u,w,accounts(state))}<details class="co-extra-tools"><summary>旧版提醒计划（不执行发布）</summary>${panelHeading(\'发布计划\''),
 ('平台发布尚未接通。到期后由本人核对并手动发布；保存计划不等于已发布。</p></aside>', '旧版记录仅提醒，不参与上方执行队列；原记录不会自动升级或发布。</p></details></aside>'),
 ('可导出内容包，由本人在目标平台核对并发布。','可导出内容包，由本人在目标平台核对并发布；也可回到草稿页保存固定账号执行计划。'),
 ('const releaseWorkflow=bindWorkflow(root,ctx,u),releaseMedia=bindMedia(root,ctx,u,workspace(state));','const releaseWorkflow=bindWorkflow(root,ctx,u),releaseMedia=bindMedia(root,ctx,u,workspace(state)),releaseSchedule=bindSchedule(root,ctx,u,workspace(state),accounts(state));'),
 ('return ()=>{disposed=true;releaseWorkflow?.();releaseMedia?.();};','return ()=>{disposed=true;releaseWorkflow?.();releaseMedia?.();releaseSchedule?.();};')]
for old,new in changes:
    assert text.count(old)==1,(old[:100],text.count(old));text=text.replace(old,new)
p.write_bytes(text.encode().replace(b'\n',nl))
(W/'UI-INTEGRATION.json').write_text(json.dumps({'path':p.relative_to(S).as_posix(),'beforeSha256':hashlib.sha256(raw).hexdigest(),'afterSha256':hashlib.sha256(p.read_bytes()).hexdigest(),'changes':len(changes)},ensure_ascii=False,indent=2)+'\n','utf-8')
print('Existing calendar and bindings adapted; no stylesheet or original page layout replaced')
