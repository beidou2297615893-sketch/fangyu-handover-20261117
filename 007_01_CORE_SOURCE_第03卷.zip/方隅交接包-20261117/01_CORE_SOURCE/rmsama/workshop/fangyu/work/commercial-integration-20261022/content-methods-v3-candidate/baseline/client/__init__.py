"""Host-injected content gateway candidate; no network transport is installed."""
from .gateway_adapter import ContentGatewayAdapter, GatewayConfigurationError

__all__ = ['ContentGatewayAdapter', 'GatewayConfigurationError']
