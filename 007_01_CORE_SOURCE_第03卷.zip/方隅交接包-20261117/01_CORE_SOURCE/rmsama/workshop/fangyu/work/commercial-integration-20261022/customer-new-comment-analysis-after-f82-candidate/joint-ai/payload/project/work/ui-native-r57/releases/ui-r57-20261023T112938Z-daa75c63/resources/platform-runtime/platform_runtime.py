"""Explicit customer account/collection adapter over the preserved r55 runtime.

No platform or cloud action starts during construction. A verified frontend
principal is required for every public operation. The original AppServer,
AssistantService and BusinessExecutor types retain their authority checks.
"""
from copy import deepcopy
from datetime import datetime, timedelta, timezone
import base64
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import stat
import sys
import threading
import time
from uuid import uuid4


COMPANY_ID = 'fangyu-apartment-client'
_COLLECTION_DIAGNOSTIC_ENTITY = 'workbench_collection_diagnostic_v1'
_COLLECTION_RUN_ENTITY = 'workbench_collection_run_v1'
_COLLECTION_ANALYSIS_ENTITY = 'workbench_collection_page_analysis_v1'
_COLLECTION_REQUIRED_COUNTS = ('read','filtered','imported','duplicates')
_COLLECTION_OBSERVATION_COUNTS = ('observed_comments','linked_existing','source_conflicts')
_COLLECTION_SOURCE_COUNTS = _COLLECTION_OBSERVATION_COUNTS+('comment_time_unknown',)
_MAX_SAFE_COUNT = 9007199254740991
_COLLECTION_ANALYSIS_HOLD_CODES = frozenset(('AI_INVALID_OUTPUT','AI_BILLING_UNKNOWN',
    'AI_PROVIDER_TIMEOUT','AI_PROVIDER_UNAVAILABLE','AI_PROVIDER_INVALID_RESPONSE',
    'AI_PROVIDER_BALANCE','AI_PROVIDER_AUTH','PRODUCT_REQUEST_UNKNOWN'))
DIRECTORY = Path(__file__).resolve().parent
_BROWSER_LOGIN_HELPER_SHA = '1EB9714204E3A8CCEABE014E24D1477B73B34025C2247B3D75EBD93168C6FE0A'


def _browser_login_helper_valid(path):
    """Recheck the one frozen source helper immediately before child launch."""
    from core.runtime_license_policy import _plain, _file_hash
    expected = DIRECTORY / 'vendor-src/assistant/browser_login_window.py'
    try:
        if Path(path) != expected:
            return False
        checked = _plain(expected, expected.parent)
        return _file_hash(checked).upper() == _BROWSER_LOGIN_HELPER_SHA
    except (OSError, ValueError, TypeError):
        return False


def analysis_blocks_new_batch(pending, job):
    """Admission only; never alters a saved source or repeats an AI request."""
    if pending is None:
        return False
    confirmed_backlog=(pending.get('status')=='pending' and not pending.get('code')
        and job.get('status')=='completed' and not job.get('code')
        and type(job.get('pending')) is int and job['pending']==0
        and all(pending.get(key) and pending.get(key)==job.get(key) for key in ('id','tenant_id','owner')))
    return not confirmed_backlog


def _safe_observation_counts(source):
    """Optional counters never invalidate an older four-counter receipt."""
    return {key:value if type(value:=source.get(key)) is int and 0<=value<=_MAX_SAFE_COUNT else 0
        for key in _COLLECTION_OBSERVATION_COUNTS}


def _safe_source_counts(source):
    value=source.get('comment_time_unknown')
    return {**_safe_observation_counts(source),
        'comment_time_unknown':value if type(value) is int and 0<=value<=_MAX_SAFE_COUNT else 0}


def collection_observation(progress, receipt, active, analysis_job=None):
    """Public task snapshot metadata only; never reads platform state or tokens."""
    progress=progress or {};receipt=receipt or {};analysis_job=analysis_job or {}
    value={'observedAt':datetime.now(timezone.utc).isoformat()}
    stamps=[]
    for raw in (progress.get('updated_at'),receipt.get('updated_at'),analysis_job.get('updated_at')):
        if not isinstance(raw,str) or len(raw)>64:continue
        try:
            parsed=datetime.fromisoformat(raw.replace('Z','+00:00'))
            if parsed.tzinfo is None:parsed=parsed.replace(tzinfo=timezone(timedelta(hours=8)))
            stamps.append(parsed.astimezone(timezone.utc))
        except (ValueError,OverflowError):continue
    if stamps:value['progressAt']=max(stamps).isoformat()
    elapsed=progress.get('elapsed_seconds')
    if type(elapsed) in (int,float) and 0<=elapsed<31536000:value['elapsedSeconds']=elapsed
    pages=receipt.get('pages')
    if type(pages) is int and pages>=0:value['confirmedPages']=pages
    waiting=receipt.get('next_read_at')
    if active and isinstance(waiting,str) and len(waiting)<=64:
        try:
            stamp=datetime.fromisoformat(waiting)
            if stamp.tzinfo is not None:value['nextReadAt']=stamp.isoformat()
        except ValueError:pass
    return value


def wait_for_collection_slot(cancel, until):
    """A cancellable load-management wait; never retries a platform request."""
    while not cancel.is_set():
        remaining=until-time.time()
        if remaining<=0:return True
        if cancel.wait(min(remaining,.25)):return False
    return False


class PlatformRuntimeError(ValueError):
    def __init__(self, code, message, status=409, *, mutation_committed=False):
        super().__init__(message)
        self.code, self.status = code, status
        self.mutation_committed = mutation_committed


def _load(name, path, **values):
    previous = sys.modules.get(name)
    if previous is not None:
        if Path(previous.__file__).resolve() != path.resolve():
            raise PlatformRuntimeError('RUNTIME_IMPORT_CONFLICT', '已有运行组件来源不同，请独立重开开发后台', 503)
        if any(getattr(previous,key,None) != value for key,value in values.items()):
            raise PlatformRuntimeError('RUNTIME_PROJECT_CONFLICT', '运行组件已绑定其他工程，请独立重开开发后台', 503)
        return previous
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    module.__dict__.update(values)
    sys.modules[name] = module
    try:
        spec.loader.exec_module(module)
    except BaseException:
        sys.modules.pop(name, None)
        raise
    return module


def _modules(project):
    source = project / 'work/ui-runtime-r55/src'
    if str(source) not in sys.path:
        sys.path.insert(0, str(source))
    _load('account_connections', DIRECTORY / 'vendor-src/account_connections.py',
          __FANGYU_SOURCE_ROOT__=str(source))
    _load('assistant.employee_distribution', DIRECTORY / 'vendor-src/assistant/employee_distribution.py')
    _load('assistant.business', DIRECTORY / 'vendor-src/assistant/business.py')
    _load('assistant.dy_browser_login', DIRECTORY / 'vendor-src/assistant/dy_browser_login.py')
    _load('assistant.douyin_connection_service', DIRECTORY / 'vendor-src/assistant/douyin_connection_service.py',
        __FANGYU_SOURCE_ROOT__=str(source),
        __FANGYU_DOUYIN_REVIEW_PATH__=str(DIRECTORY / 'vendor-src/douyin-connection-review.json'))
    app = _load('app', DIRECTORY / 'vendor-src/app.py',
                __FANGYU_SOURCE_ROOT__=str(source),
                __FANGYU_RUNTIME_ROOT__=str(project / 'work/app/work/runtime'),
                __FANGYU_GUARDED_CLI_RUNTIME_ROOT__=str(project / 'work/source-v66-worker/component/artifacts/platform-cli-guarded'),
                __FANGYU_DOUYIN_RUNTIME_ROOT__=str(project / 'work/ui-runtime-r55/work/runtime/douyin-bridge'))
    _load('assistant.runner', DIRECTORY / 'vendor-src/assistant/runner.py')
    _load('assistant.browser_login_window', DIRECTORY / 'vendor-src/assistant/browser_login_window.py')
    _load('assistant.browser_login_service', DIRECTORY / 'vendor-src/assistant/browser_login_service.py')
    _load('assistant.xhs_browser_login', DIRECTORY / 'vendor-src/assistant/xhs_browser_login.py')
    service = _load('assistant.service', DIRECTORY / 'vendor-src/assistant/service.py')
    overlay=_load('fangyu_douyin_pipeline_overlay', DIRECTORY / 'vendor-src/douyin_pipeline_overlay.py',
        __FANGYU_SOURCE_ROOT__=str(source))
    overlay.install(project)
    return app, service


class PlatformRuntime:
    def __init__(self, project_root, core=None, company=None, data_dir=None, *, cloud_factory=None, customer_read_authority=None):
        self.project = Path(project_root).resolve()
        if core is not None:
            raise PlatformRuntimeError('CORE_OWNERSHIP', '平台运行库需拥有同一原始 Core，请由后台复用 runtime.core', 503)
        if company is None:
            company = json.loads((self.project / 'work/app/company.json').read_text('utf-8-sig'))
        company = deepcopy(company)
        managed = company.get('managedWorkspace') if isinstance(company, dict) else None
        if (not isinstance(company, dict) or company.get('id') != COMPANY_ID
                or company.get('edition') != 'customer' or company.get('personalMode') is not False
                or company.get('authMode') != 'managed' or not isinstance(managed, dict)
                or not managed.get('environment_id') or not managed.get('endpoint')):
            raise PlatformRuntimeError('CUSTOMER_CONFIG_REQUIRED', '只能使用当前方隅客户员工配置', 503)
        self.data_dir = Path(data_dir).resolve() if data_dir is not None else (
            Path(os.environ.get('LOCALAPPDATA', Path.home() / 'AppData/Local')) / (COMPANY_ID + 'Workspace')).resolve()
        self._instance_lock = None
        self._acquire_instance_lock()
        try:
            app, service = _modules(self.project)
            self.server = app.AppServer(('127.0.0.1', 0), self.data_dir,
                employee_workspace=True, trusted_company=company,
                defer_startup_recovery=True, defer_platform_setup=True,
                customer_read_authority=customer_read_authority)
        except BaseException:
            self._release_instance_lock()
            raise
        self.core = self.server.core
        self.server.update_startup_gate = None
        self.server.update_startup_pending = False
        self.server.explicit_local_actions = True
        self.server.browser_login_enabled = True
        self.server.browser_login_helper_path = DIRECTORY / 'vendor-src/assistant/browser_login_window.py'
        self.server.browser_login_helper_validator = _browser_login_helper_valid
        options = {'cloud_factory': cloud_factory} if cloud_factory is not None else {}
        try:
            self.service = service.AssistantService(self.server, explicit_local=True, **options)
        except BaseException:
            try:
                self.server.close_owned_jobs()
                self.server.server_close()
            finally:
                self._release_instance_lock()
            raise
        self.server.assistant_service = self.service
        self.integrations = self.server.integrations
        self.lock = threading.RLock()
        self.closed = False
        self.started = False
        self._platform_setup = False
        self._runs = {}
        self._run_cancels = {}
        self._run_lock = threading.RLock()
        self._douyin_observations = {}
        self._verification_waits = {}
        from core.source_scheduler import SourceScheduler
        self.source_scheduler=SourceScheduler(self)
        self.core.continuous.source_schedule_tick=self.source_scheduler.tick

    def _acquire_instance_lock(self):
        self.data_dir.mkdir(parents=True,exist_ok=True)
        stream = (self.data_dir / 'instance.lock').open('a+b')
        try:
            import msvcrt
            stream.seek(0)
            if not stream.read(1):
                stream.write(b'1')
                stream.flush()
            stream.seek(0)
            msvcrt.locking(stream.fileno(),msvcrt.LK_NBLCK,1)
        except (OSError,ImportError):
            stream.close()
            raise PlatformRuntimeError('WORKSPACE_IN_USE','当前员工工作台已在其他进程中打开，请先正常退出原工作台',409) from None
        self._instance_lock = stream

    def _release_instance_lock(self):
        stream, self._instance_lock = self._instance_lock, None
        if stream is None:
            return
        try:
            import msvcrt
            stream.seek(0)
            msvcrt.locking(stream.fileno(),msvcrt.LK_UNLCK,1)
        finally:
            stream.close()

    def _principal(self, user):
        if self.closed:
            raise PlatformRuntimeError('RUNTIME_CLOSED', '工作台正在关闭，请重新打开', 503)
        expected_tenant = 'cloud-' + hashlib.sha256((
            self.server.company['managedWorkspace']['environment_id'] + '\n' + COMPANY_ID).encode()).hexdigest()[:24]
        saved = self.core.store.get('users', user.get('id')) if isinstance(user, dict) else None
        if (not saved or saved.get('disabled') or saved.get('cloud_bound') is not True
                or saved.get('development_local_only') is True or saved.get('role') not in ('operator','admin')
                or saved.get('tenant_id') != expected_tenant
                or any(saved.get(key) != user.get(key) for key in ('id','tenant_id','username','role'))):
            raise PlatformRuntimeError('AUTH_REQUIRED', '请先使用当前企业员工账号登录', 401)
        return {**self.core._public(saved),'_workbench_store_id':user.get('_workbench_store_id','')}

    def _device(self, user):
        saved = self.service.vault.read()
        device = self.service.device or (saved or {}).get('device') or {}
        owner = device.get('owner')
        if owner and owner != user['username']:
            return {'state': 'other_owner', 'bound': False,
                    'message': '这台电脑已绑定其他员工，请管理员核对设备归属'}
        state = self.service.state
        bound = bool(saved and saved.get('state') == 'bound' and device.get('id'))
        messages = {'unbound':'请连接当前员工电脑', 'pending':'电脑绑定等待确认',
                    'binding':'正在连接当前电脑', 'offline':'工作连接尚未恢复，请点击重新连接',
                    'online':'企业连接已确认', 'held':'企业连接保持安全暂停',
                    'revoked':'设备授权已撤回，请管理员核对', 'error':'设备连接未完成，请手动重试',
                    'stopped':'设备连接已停止，请手动重试'}
        reason=getattr(self.service,'employee_release_reason','')
        message=messages.get(state,'设备连接待核对')
        if state=='offline' and self.service.thread is not None and self.service.thread.is_alive():
            message='正在恢复工作连接；网络未恢复时可点击重新连接检查'
        if state=='held' and reason in ('ROLE_INELIGIBLE','POLICY_DISABLED','VERSION_MISMATCH'):
            message={'ROLE_INELIGIBLE':'本机已绑定，当前管理员设备许可尚待开通',
                     'POLICY_DISABLED':'本机已绑定，企业设备许可尚待开通',
                     'VERSION_MISMATCH':'本机已绑定，请更新到当前允许的平台运行版本'}[reason]
        return {'state':state, 'bound':bound, 'message':message,
                'reasonCode':reason if reason in ('ROLE_INELIGIBLE','POLICY_DISABLED','VERSION_MISMATCH',
                    'DEVICE_REVOKED','OWNER_INACTIVE','DEVICE_OFFLINE','ALLOWED') else ''}

    def _prepare_for_connection(self, user):
        """One explicit connect click prepares this employee's own runtime.

        Preparation may enroll a device and start its existing heartbeat. It
        does not create a platform account, open a login or collect anything.
        A subsequent status read must confirm the authenticated lease.
        """
        device = self._device(user)
        if (not self._platform_setup or not device['bound']
                or self.service.executor is None or self.service.state in ('unbound','offline','stopped','error')):
            self.prepare(user)
        deadline=time.monotonic()+6
        while (self.service.state in ('binding','offline','unbound')
                and self.service.thread is not None and self.service.thread.is_alive()
                and time.monotonic()<deadline):
            self.service.stop_event.wait(.05)
        self._executor(user)

    def _executor(self, user, *, online=True):
        user = self._principal(user)
        device = self._device(user)
        executor = self.service.executor
        if (not device['bound'] or executor is None or self.service.closed
                or self.service.state not in (('online',) if online else ('online','held'))
                or executor.core is not self.core or executor.owner != user['username']
                or executor.tenant != user['tenant_id'] or executor.user_id != user['id']):
            raise PlatformRuntimeError('DEVICE_NOT_READY', device['message'])
        session = getattr(executor, '_xhs_app_session', None)
        if session is None:
            raise PlatformRuntimeError('DEVICE_SESSION_UNAVAILABLE', '设备员工会话尚未确认')
        try:
            session.check()
        except Exception:
            raise PlatformRuntimeError('DEVICE_SESSION_UNAVAILABLE', '设备员工会话尚未确认') from None
        runtime=self.server.company.get('runtime') or {}
        if (online and runtime.get('workbench_source_release')=='fangyu-admin-local-v1'
                and not self.core._employee_release_allowed()):
            raise PlatformRuntimeError('DEVICE_LEASE_UNCONFIRMED','当前本机平台许可尚未确认，请等待设备状态刷新')
        return executor

    def _account(self, user, ident):
        if not isinstance(ident,str) or not re.fullmatch(r'[A-Za-z0-9_-]{1,160}',ident):
            raise PlatformRuntimeError('INVALID_INPUT','平台账号编号无效',400)
        try:
            account=self.core._get('accounts',ident,user['tenant_id'])
            self.core._account_access(user,account)
            if user.get('role') == 'admin' and (account.get('cloud_owner') != user['username']
                    or not user.get('_workbench_store_id') or account.get('store_id') != user['_workbench_store_id']):
                raise ValueError('账号不属于当前管理员与门店')
            self.core.require_platform(account.get('platform'))
            return account
        except ValueError:
            raise PlatformRuntimeError('ACCOUNT_FORBIDDEN','账号不存在或不属于当前员工',403) from None

    def _task(self, user, ident):
        if not isinstance(ident,str) or not re.fullmatch(r'[A-Za-z0-9_-]{1,160}',ident):
            raise PlatformRuntimeError('INVALID_INPUT','采集任务编号无效',400)
        try:
            task=self.core._get('tasks',ident,user['tenant_id'])
            self.core._task_access(user,task,user['tenant_id'])
            if user.get('role') == 'admin' and (task.get('cloud_owner') != user['username']
                    or not user.get('_workbench_store_id') or task.get('store_id') != user['_workbench_store_id']):
                raise ValueError('任务未绑定当前管理员与门店')
            return task
        except ValueError:
            raise PlatformRuntimeError('TASK_FORBIDDEN','任务不存在或不属于当前员工',403) from None

    def _readiness(self, user, account=None):
        device = self._device(user)
        if not device['bound'] or self.service.state != 'online' or self.service.executor is None:
            return 'device_not_ready', device['message']
        runtime=self.server.company.get('runtime') or {}
        if (runtime.get('workbench_source_release')=='fangyu-admin-local-v1'
                and not self.core._employee_release_allowed()):
            return 'device_lease_unconfirmed','当前本机平台许可尚未确认，请等待设备状态刷新'
        if account and account.get('platform') not in self.server.company.get('platforms', []):
            return 'platform_forbidden', '当前企业未开放此平台'
        if account and account.get('platform') == 'xiaohongshu':
            runtime = self.server.company.get('runtime') or {}
            if runtime.get('xiaohongshu_automation') == 'hold' and not self.core._employee_release_allowed() and not self.core._page_read_allowed():
                return 'platform_held', '小红书平台操作保持原有安全暂停，请先核对企业平台许可'
        if self.core.remote_safety_hold:
            return 'platform_held', '企业服务尚未确认平台操作，已保留现有账号与断点'
        if account and account.get('platform') == 'xiaohongshu':
            if (account.get('identity_recovery_pending')
                    or (self.data_dir/'accounts'/user['tenant_id']/account['id']/'.xiaohongshu-cli/.browser-session-commit.json').exists()):
                return 'recovery_pending','账号身份提交尚未完成，采集保持暂停'
        return '', ''

    def _task_running(self, task):
        if not task:
            return False
        ident=task['id']
        thread=self._runs.get(ident)
        return bool(ident in self.core.running or ident in self.core.sequences
            or thread is not None and thread.is_alive())

    def _douyin_window(self, account):
        """Read only this process's owned handle; never probe the platform."""
        item=self.server.account_connections.owned.get(account['id'])
        try:
            process=item.get('process') if isinstance(item,dict) else None
            marker=item.get('marker') if isinstance(item,dict) else None
            if process is not None and process.poll() is None and isinstance(marker,str) and marker:
                return item,process,marker
        except (OSError,ValueError,AttributeError):
            pass
        return None

    @staticmethod
    def _douyin_binding(account):
        values=[account.get(key) for key in ('tenant_id','cloud_owner','store_id','conn_id','platform_uid')]
        return hashlib.sha256(json.dumps(values,ensure_ascii=False).encode('utf-8')).hexdigest()

    @staticmethod
    def _douyin_scope(user, account):
        return user['tenant_id'],user['username'],user.get('_workbench_store_id',''),account['id']

    def _douyin_operation(self, user, account, action):
        # Invalidate before IO; an exception or a late older result cannot
        # restore an earlier positive observation. This is not authorization.
        key=self._douyin_scope(user,account)
        with self.lock:
            attempt=object()
            self._douyin_observations[key]={'attempt':attempt}
        result=self._douyin_result(self.service.douyin_connection(action,{'account_id':account['id']}))
        result['accountId']=account['id']
        current=self._account(user,account['id'])
        with self.lock:
            if self._douyin_observations.get(key,{}).get('attempt') is attempt:
                self._douyin_observations[key]={'attempt':attempt,'result':result,
                    'window':self._douyin_window(current),'binding':self._douyin_binding(current)}
            else:
                result=self._douyin_observations.get(key,{}).get('result') or {
                    'id':'','status':'unknown','message':'抖音连接正在核对，请查看当前状态'}
        return result

    def _connection_account(self, user, account):
        if not account or account.get('platform')!='douyin':
            return account
        # Persisted risk/recovery/disabled states retain their original guard.
        if account.get('status') not in ('ready','disconnected','logging_in','waiting_login',
                'checking','choose_window','failed','unknown','unverified','login_required'):
            return account
        message='请点“连接抖音”打开已保存的浏览器，再检查连接'
        status='disconnected'
        window=self._douyin_window(account)
        with self.lock:
            observed=self._douyin_observations.get(self._douyin_scope(user,account),{})
            previous=observed.get('window')
            if window is not None:
                status='unverified'
                message='抖音浏览器已打开，请检查连接'
                if (previous is not None and previous[0] is window[0] and previous[1] is window[1]
                        and previous[2]==window[2] and observed.get('binding')==self._douyin_binding(account)):
                    result=observed.get('result') or {}
                    status=result.get('status','unverified')
                    message=result.get('message') or message
                    if status=='ready' and (account.get('status')!='ready' or result.get('windowOpen') is not True):
                        status=account['status'] if account.get('status')!='ready' else 'unverified'
                        message='抖音账号尚未就绪，请检查连接'
        return {**account,'status':status,'connection_message':message}

    def _collection_readiness(self, user, account):
        code,message=self._readiness(user,account)
        if not code and account and account.get('platform')=='douyin':
            connected=self._connection_account(user,account)
            if connected.get('status')!='ready':
                return 'douyin_connection_required',connected.get('connection_message') or '请先连接并核实抖音账号'
        return code,message

    def _task_active(self, task, continuous=None):
        if not task:
            return False
        if self._task_running(task):
            return True
        if continuous is None:
            continuous=self.core.continuous.status(task) if task.get('continuous_enabled') else {}
        return bool(continuous.get('inflight'))

    @staticmethod
    def _collection_history(task):
        """One committed batch/sequence only; never merge different run IDs."""
        result=task.get('last_result')
        summary=result.get('summary') if isinstance(result,dict) else None
        source=summary if isinstance(summary,dict) else task.get('last_batch')
        if not isinstance(source,dict):
            return {}
        values={key:value for key,value in source.items()
            if key in _COLLECTION_REQUIRED_COUNTS+_COLLECTION_SOURCE_COUNTS
            and type(value) is int and 0 <= value <= _MAX_SAFE_COUNT}
        if values and isinstance(source.get('run_id'),str):
            values['run_id']=source['run_id']
        return values

    @classmethod
    def _collection_binding(cls, task):
        scope=cls._task_scope(task)
        if scope is None:return None
        extra={key:deepcopy(task.get(key)) for key in (
            'id','tenant_id','cloud_owner','comment_depth','time_start','time_end',
            'comment_date_from','comment_date_to','excluded_authors','excluded_bloggers',
            'high_intent_words','medium_intent_words','negative_intent_words',
            'blogger_unknown_policy','strategy_source','source_ref')}
        return hashlib.sha256(json.dumps([scope,extra],ensure_ascii=True,
            sort_keys=True,separators=(',',':')).encode('utf-8')).hexdigest()

    def _collection_receipt(self, user, task, active=False):
        if not task:return None
        row=self.core.store.get(_COLLECTION_RUN_ENTITY,task['id'])
        if (not row or row.get('tenant_id')!=user['tenant_id'] or row.get('owner')!=user['username']
                or row.get('binding')!=self._collection_binding(task)):
            return None
        if active:
            control=self._run_cancels.get(task['id'])
            if not control or row.get('attempt_id')!=control.get('attempt'):return None
        else:
            if row.get('status') not in ('stopped','completed','paused','failed'):return None
            # Parent counts describe all confirmed pages of this bound task.
            # A resume that only checks AI can create a different Core progress
            # ID without reading a platform page; it must not hide old counts.
            if not (row.get('pages') or row.get('units')):return None
        counts=row.get('counts')
        if (type(counts) is not dict or any(type(counts.get(key)) is not int or counts[key]<0
                for key in _COLLECTION_REQUIRED_COUNTS)):return None
        return {**row,'counts':{**counts,**_safe_source_counts(counts)}}

    def _batch_resumable(self, user, task, account):
        result=task.get('last_result')
        summary=result.get('summary') if isinstance(result,dict) else None
        if (not self._current_comment_policy(task) or task.get('status')!='ready' or task.get('sequence_status')!='stopped'
                or not isinstance(result,dict) or result.get('status')!='stopped'
                or not isinstance(summary,dict) or summary.get('stop_reason')!='batch_limit'
                or summary.get('can_continue') is not True or summary.get('exhausted') is not False
                or task.get('exhausted') or not account or account.get('status')!='ready'):
            return False
        # Reuse Core's local current-actor/platform/quota check. The saved flag
        # alone is not authority, and this check never starts a platform call.
        try:
            return self.core._collection_summary(task,user,'stopped','batch_limit',{}).get('can_continue') is True
        except (ValueError,TypeError,OSError):
            return False

    @staticmethod
    def _current_comment_policy(task):
        # Do not silently reinterpret an older strict-comment/IP task's cursor.
        source=task.get('source_ref') if task else None
        fixed=(type(source) is dict and source.get('schema')=='acquisition-source/1'
            and source.get('kind') in ('note_links','profiles','own_interactions') and task.get('scope')=='comments'
            and type(source.get('count')) is int and 1<=source['count']<=100)
        return bool(task and (task.get('scope')=='search_comments' or fixed)
            and task.get('comment_keyword_mode','match')=='all'
            and task.get('continuous_enabled') is False and task.get('region','')==''
            and task.get('unknown_policy','exclude')=='exclude')

    @staticmethod
    def _task_scope(task, selected_store=None):
        """Public start conditions of this already-authorized task, not identity."""
        if not task or selected_store is not None and task.get('store_id')!=selected_store:
            return None
        fields={'storeId':('store_id',''),'platform':('platform',''),'accountId':('account_id',''),
            'region':('region',''),'city':('city',''),'area':('area',''),
            'dateFrom':('date_from',''),'dateTo':('date_to',''),'scope':('scope',''),
            'commentDateRange':('comment_date_range','all'),'intentMode':('intent_mode','all'),
            'commentKeywordMode':('comment_keyword_mode','match'),'unknownPolicy':('unknown_policy','exclude')}
        result={key:task.get(source,default) for key,(source,default) in fields.items()}
        if (any(not isinstance(value,str) or len(value)>160 or any(ord(c)<32 for c in value)
                for value in result.values()) or result['platform'] not in ('xiaohongshu','douyin')
                or not re.fullmatch(r'[A-Za-z0-9_-]{1,80}',result['storeId'])
                or not re.fullmatch(r'[A-Za-z0-9_-]{1,160}',result['accountId'])):
            return None
        try:
            for key in ('dateFrom','dateTo'):
                if result[key] and (not re.fullmatch(r'\d{4}-\d{2}-\d{2}',result[key])
                        or datetime.strptime(result[key],'%Y-%m-%d').date().isoformat()!=result[key]):
                    return None
            if bool(result['dateFrom'])!=bool(result['dateTo']) or result['dateFrom']>result['dateTo']:
                return None
        except ValueError:
            return None
        if (result['commentKeywordMode'] not in ('all','match') or result['unknownPolicy'] not in ('exclude','keep')
                or type(task.get('continuous_enabled',False)) is not bool):
            return None
        result['continuousEnabled']=task.get('continuous_enabled',False)
        for key,source,maximum in (('keywords','keywords',80),('excludes','excludes',100)):
            values=task.get(source,[])
            if (not isinstance(values,list) or len(values)>100 or any(not isinstance(value,str)
                    or len(value)>maximum or any(ord(c)<32 for c in value) for value in values)):
                return None
            result[key]=list(dict.fromkeys(value.strip() for value in values)) if key=='keywords' else list(values)
        source=task.get('source_ref')
        fixed=(type(source) is dict and source.get('schema')=='acquisition-source/1'
            and source.get('kind') in ('note_links','profiles','own_interactions') and task.get('scope')=='comments'
            and type(source.get('count')) is int and 1<=source['count']<=100
            and all(type(source.get(k)) is str and re.fullmatch('[a-f0-9]{64}',source[k]) for k in ('digest','source_digest')))
        if (not result['keywords'] and not fixed) or any(not word for word in result['keywords']):
            return None
        if fixed:result['source']={'kind':source['kind'],'count':source['count'],'sourceDigest':source['source_digest']}
        for key,source,default,maximum in (('dailyLimit','daily_limit',20,1000),('targetCount','target_count',100,10000)):
            value=task.get(source,default)
            if type(value) is not int or not 1<=value<=maximum:
                return None
            result[key]=value
        return result

    @staticmethod
    def _analysis_confirmed(result):
        return (isinstance(result,dict) and result.get('status') in ('graded','uncertain','unrelated')
            and (result.get('level') in ('super_high','high','medium','low','very_low')
                if result.get('status')=='graded' else result.get('level') is None))

    def snapshot(self, user, *, platform=None):
        user = self._principal(user)
        if platform is not None and (type(platform) is not str or platform not in ('xiaohongshu','douyin')):
            raise PlatformRuntimeError('PLATFORM_INVALID','请选择小红书或抖音',400)
        selected_platform=platform
        from assistant.business import account_view
        accounts = self.core.handle('list', {'entity':'accounts'}, user)
        tasks = [row for row in self.core.handle('list', {'entity':'tasks'}, user) if row.get('scope')!='livestream_chat']
        if platform is not None:
            selected_store=user.get('_workbench_store_id')
            accounts=[row for row in accounts if row.get('platform')==platform
                and selected_store and row.get('store_id')==selected_store
                and row.get('cloud_owner')==user['username']]
            tasks=[row for row in tasks if row.get('platform')==platform
                and selected_store and row.get('store_id')==selected_store
                and row.get('cloud_owner')==user['username']]
        if user.get('role') == 'admin':
            selected=user.get('_workbench_store_id')
            accounts=[row for row in accounts if selected and row.get('cloud_owner')==user['username']
                and row.get('store_id') == selected]
            tasks=[row for row in tasks if selected and row.get('cloud_owner')==user['username']
                and row.get('store_id')==selected]
        tasks.sort(key=lambda row:(str(row.get('updated_at','')),str(row.get('created_at',''))), reverse=True)
        projected = []
        for account in accounts:
            code, message = self._readiness(user, account)
            connected=self._connection_account(user,account)
            collection_code,collection_message=self._collection_readiness(user,account)
            if not collection_code and account.get('status')!='ready':
                collection_code,collection_message='account_not_ready','请先连接并核实当前平台账号'
            projected.append({**account_view(connected), 'name':str(account.get('platform_nickname') or account.get('name') or '')[:100],
                'remarks':(account.get('remarks') if isinstance(account.get('remarks'),str) else str(account.get('name') or ''))[:100],
                'collectionReady':not bool(collection_code),'collectionReasonCode':collection_code,
                'collectionMessage':collection_message,
                'status':('identity_recovery_pending' if code=='recovery_pending' else
                    'login_required' if account.get('status')=='check_required' else account_view(connected).get('status') or 'login_required'),
                'requiresReview':code in ('account_review_required','recovery_pending'), 'canConnect':not code,
                'message':message or ('登录已退出，请点击一键登录' if account.get('status')=='check_required'
                    else connected.get('connection_message','')), 'reasonCode':code,
                'loginJobId': self._active_login_job_id(user, account)})
        platforms = []
        for platform, name in (('xiaohongshu','小红书'),('douyin','抖音')):
            if selected_platform is not None and platform!=selected_platform:
                continue
            allowed = platform in self.server.company.get('platforms', [])
            account = next((row for row in projected if row['platform'] == platform), None)
            code, message = self._readiness(user, {'id':account['id'] if account else '', 'platform':platform}) if allowed else (
                'platform_forbidden','当前企业未开放此平台')
            platforms.append({'id':platform,'name':name,'enabled':allowed,
                'accountId':account['id'] if account else '', 'accountName':account['name'] if account else '',
                'status':account.get('status','disconnected') if account else 'disconnected',
                'requiresReview':bool(account and account['requiresReview']),
                'canConnect':not code, 'message':message or (account.get('message','') if account else ''), 'reasonCode':code})
        # Real workers outrank persisted inflight flags left by an old process.
        task = next((row for row in tasks if self._task_running(row)),None)
        if task is None:
            task=next((row for row in tasks if self._task_active(row)),tasks[0] if tasks else None)
        progress = (self.core.task_progress(task['id']) or {}) if task else {}
        continuous = self.core.continuous.status(task) if task and task.get('continuous_enabled') else {}
        active = self._task_active(task,continuous)
        # A newly submitted worker can precede Core's fresh progress event.
        # Its old terminal progress must not appear to be the current run.
        if active and progress.get('state') in ('completed','failed','paused','stopped'):
            progress={}
        account = (next((row for row in accounts if row['id'] == task.get('account_id')), None) if task else
                   next((row for row in accounts if row.get('status') == 'ready'), accounts[0] if accounts else None))
        code, message = self._collection_readiness(user, account)
        if not code and (not account or account.get('status') != 'ready'):
            code, message = 'account_not_ready','请先连接并核实当前平台账号'
        status = 'running' if active else (task.get('status','idle') if task else 'idle')
        if not active and task and status != 'paused':
            terminal=progress.get('state')
            sequence=task.get('sequence_status')
            if terminal in ('completed','failed','paused','stopped'):
                status=terminal
            elif sequence in ('completed','failed','stopped'):
                status=sequence
        counts = {'read':0,'added':0,'analyzed':0,'duplicates':0,
            'observedComments':0,'linkedExisting':0,'sourceConflicts':0}
        if task and task.get('source_ref'):counts['commentTimeUnknown']=0
        history=self._collection_history(task) if task and not active else {}
        if progress and (progress.get('state')=='running' or not progress.get('run_id')
                or progress.get('run_id')!=history.get('run_id')):
            history={}
        count_source=history or progress
        receipt=self._collection_receipt(user,task,active)
        if receipt:
            count_source=receipt['counts']
            if not active:
                history={**receipt['counts'],'run_id':receipt.get('core_run_id')}
                # The immutable parent receipt still records failure. A real
                # paused task can expose explicit continuation after review;
                # readiness/risk guards below continue to block it meanwhile.
                status='paused' if task.get('status')=='paused' else receipt['status']
        for target, field in (('read','read'),('filtered','filtered'),('added','imported'),('duplicates','duplicates')):
            value = count_source.get(field, continuous.get(field, 0) if not history else 0)
            if type(value) is int and value >= 0:
                counts[target] = value
        for target,field in (('observedComments','observed_comments'),('linkedExisting','linked_existing'),
                ('sourceConflicts','source_conflicts'),('commentTimeUnknown','comment_time_unknown')):
            if target=='commentTimeUnknown' and 'commentTimeUnknown' not in counts:continue
            counts[target]=_safe_source_counts(count_source).get(field,0)
        records=[]
        if history:
            labels=(('read','读取'),('filtered','筛除'),('imported','新增'),('duplicates','重复'))
            records=[{'text':'，'.join(f'{label} {history[key]} 条' for key,label in labels if key in history),
                'status':'本批已结束' if status in ('stopped','completed') else '已保存结果'}]
        if task:
            visible_leads = [row for row in self._task_leads(user,task['id'])
                if row.get('task_id') == task['id'] and not row.get('demo')
                and (selected_platform is None or (row.get('platform')==selected_platform
                    and row.get('tenant_id')==user['tenant_id']
                    and row.get('cloud_owner') in (None,'',user['username'])
                    and row.get('store_id') in (None,'',user.get('_workbench_store_id'))))]
            counts['added'] = len(visible_leads)
            counts['analyzed'] = sum(1 for row in visible_leads
                if self._analysis_confirmed(row.get('manual_intent') or row.get('ai_intent')))
        if not active and status != 'paused' and progress.get('state') == 'failed':
            status = 'failed'
            message = message or '本批采集未完成，已保存内容与原断点保留，请核对账号或平台许可'
        batch_resumable=bool(task and not active and status=='stopped' and not code
            and self._batch_resumable(user,task,account))
        analysis_context_hold=False
        try:
            analysis_pending=self._pending_collection_analysis(user,task) if task else None
        except PlatformRuntimeError as error:
            if error.code!='AI_CONTEXT_REQUIRED':raise
            # Read projection only: never repair or reinterpret the saved batch.
            analysis_context_hold=True
            analysis_message='评论已保存；分析已暂停，请核对原任务范围后处理'
            saved_analysis=self.core.store.get(_COLLECTION_ANALYSIS_ENTITY,task['id']) or {}
            analysis_context_page=(saved_analysis if saved_analysis.get('tenant_id')==user['tenant_id']
                and saved_analysis.get('owner')==user['username'] and isinstance(saved_analysis.get('lead_ids'),list) else {})
            analysis_pending={'status':'pending','code':'AI_CONTEXT_REQUIRED'}
        ai_job=self.core.store.get('ai_jobs',task['id']) if task else None
        ai_job=ai_job if ai_job and ai_job.get('tenant_id')==user['tenant_id'] else {}
        analysis_blocked=analysis_blocks_new_batch(analysis_pending,ai_job)
        analysis_hold=bool(analysis_context_hold or (analysis_pending and (analysis_pending.get('code') in _COLLECTION_ANALYSIS_HOLD_CODES
            or ai_job.get('code') in _COLLECTION_ANALYSIS_HOLD_CODES)))
        backlog=max(0,counts['added']-counts['analyzed'])
        if analysis_pending and not active:
            status='paused'
            analysis_message={'AI_DISABLED':'评论已保存；企业AI暂未启用，启用后继续分析原批次',
                'AI_NOT_CONFIGURED':'评论已保存；企业AI尚未配置，配置后继续分析原批次',
                'AI_BILLING_UNKNOWN':'评论已保存；原分析请求结果未确认，不会自动重复提交',
                'AI_PROVIDER_BALANCE':'评论已保存；企业AI余额不足，请管理员处理并核对原分析请求',
                'AI_PROVIDER_AUTH':'评论已保存；企业AI认证未通过，请管理员检查配置',
                'AI_DAILY_BUDGET':'评论已保存；今日分析预算已到，原批次保留',
                'AI_INVALID_OUTPUT':'评论已保存；原分析结果不完整，尚未计为分析完成',
                'PRODUCT_REQUEST_UNKNOWN':'评论与断点已保存；原分析请求尚无可核对结果。继续操作只核对原请求，不会重复分析',
                'AI_PROVIDER_TIMEOUT':'评论已保存；原分析请求超时，结果需核对，不会自动重提',
                'AI_IN_PROGRESS':'评论已保存；原分析请求仍在处理，不会重复提交',
                'AI_CONTEXT_REQUIRED':'评论已保存；分析已暂停，请核对原任务范围后处理',
                'AI_CONFIG_CHANGED':'评论已保存；企业AI配置已变化，请核对配置后处理'}.get(
                    analysis_pending.get('code'),'评论已保存，先完成原批意向分析，再继续读取')
            if not code:message=(analysis_message if analysis_context_hold else '待分析已达200条上限；原评论与断点保留，请先完成分析或人工复核'
                if analysis_hold and backlog>=200 else '原分析结果待核，已保留；可继续采集，新评论先入库，待分析达200条后暂停'
                if analysis_hold else analysis_message if analysis_blocked else '旧任务还有待分析评论，已保留；可继续原任务，或按当前条件开始新批次')
        if task and not active and not code and task.get('pause_reason')=='collection_error':
            from core.platform_failure import validated,message as failure_message
            failure=validated(task.get('last_platform_error'))
            # Legacy text verification_required can originate from bare461.
            # Text matching is not evidence of a platform login/captcha signal.
            message=failure_message(failure) if failure else '平台读取未完成，已保存评论和断点'
        local_mode_blocked=bool(task and not active and task.get('pause_reason')=='account_mode_blocked')
        if local_mode_blocked and not code:
            message=task.get('last_message') or '账号有尚未结束的操作，请先核对后继续原任务'
        raw_workspace = {'accounts':projected,'tasks':[{key:row[key] for key in (
            'id','name','platform','account_id','status','scope','created_at','updated_at','continuous_enabled') if key in row} for row in tasks[:100]]}
        return {'device':self._device(user), 'platforms':platforms,'accounts':projected,
            'acquisition':{'taskId':task['id'] if task else '',
                'taskScope':self._task_scope(task,user.get('_workbench_store_id')),'status':status,
                'taskStoreId':task.get('store_id','') if task else '',
                'taskPlatform':task.get('platform','') if task else '',
                'accountRemoved':bool(task and task.get('account_removed') is True and not task.get('account_id')),
                'phase':'waiting' if active and receipt and receipt.get('next_read_at') else 'reading' if active and analysis_hold else 'analyzing' if analysis_pending else progress.get('stage','preparing' if active else status if history else 'idle'),
                'counts':counts,'records':records,'recent':[],
                'observation':collection_observation(progress,receipt,active,ai_job),
                'analysis':{**{key:ai_job.get(key) for key in ('status','code','pending','provider','model')},'hold':analysis_hold,'pending':backlog,
                    **({'scopeCode':'AI_CONTEXT_REQUIRED','scopeMessage':analysis_message,'message':analysis_message,
                        'pageCode':analysis_context_page.get('code'),'queuedPending':len(analysis_context_page.get('lead_ids',[])),
                        'jobPending':ai_job.get('pending')} if analysis_context_hold else {})},
                'platformError':None if local_mode_blocked else self._collection_platform_error(task),
                'verificationId':receipt.get('attempt_id','') if receipt else '',
                'verification':self._verification_state(user,task),
                'sourceScan':((task.get('pipeline') or {}).get('extension') or {}).get('scan',1) if task and task.get('source_kind')=='own_interactions' else 0,
                'canCheckInteractions':bool(not analysis_context_hold and not active and not code and task and self._can_check_interactions(user,task,account)),
                'canStart':not code and not active and not analysis_blocked, 'canPause':active,
                'canResume':bool(not analysis_context_hold and task and self._current_comment_policy(task) and not active and not code and not (analysis_hold and backlog>=200) and (status=='paused' or batch_resumable or analysis_pending or task.get('source_scan_pending') is True)),
                'message':message or ('正在采集，等待真实后台返回' if active
                    else '旧任务使用旧筛选条件，请重新开始获客；历史与断点已保留' if task and not self._current_comment_policy(task)
                    else '已暂停，原断点保留' if status == 'paused'
                    else {'page_limit':'本次已连续读取10页，可从原断点继续',
                          'time_budget':'本次采集时长已到，原断点保留，可继续',
                          'no_progress':'本页断点没有前进，已停止，请核对后继续',
                          'three_empty_batches':'连续3页无新增，已停止，原断点保留'}.get(receipt.get('stop_reason'))
                         if receipt and receipt.get('stop_reason') in ('page_limit','time_budget','no_progress','three_empty_batches')
                    else '本批采集已结束，可从原断点继续' if batch_resumable
                    else '本批采集已完成，已保存真实结果' if status == 'completed' else '请选择条件后开始采集'),
                'reasonCode':code},
            'capabilities':{'accounts':True,'collection':not code,'automaticAI':False,
                'automaticReply':False,'remoteCommands':False,'automaticUpdates':False},
            'rawWorkspace':raw_workspace}

    def prepare(self, user, *, existing_only=False):
        if type(existing_only) is not bool:
            raise PlatformRuntimeError('INVALID_INPUT','连接参数格式无效',400)
        user = self._principal(user)
        if self._device(user)['state'] == 'other_owner':
            raise PlatformRuntimeError('DEVICE_OWNER_MISMATCH', '这台电脑已绑定其他员工，请管理员核对')
        with self.lock:
            device=self._device(user)
            if device['state']=='other_owner':
                raise PlatformRuntimeError('DEVICE_OWNER_MISMATCH','这台电脑已绑定其他员工，请管理员核对')
            if existing_only and not device['bound']:
                raise PlatformRuntimeError('DEVICE_NOT_BOUND','本机尚未绑定，请从账号页连接当前员工电脑')
            if not self._platform_setup:
                self.server._configure_bundled()
                self._platform_setup = True
            if existing_only:
                self.service.start()
            elif not self._device(user)['bound']:
                from assistant.employee_workspace import pair
                pair(self.server, user)
            else:
                self.service.start()
            self.started = True
        return self.snapshot(user)

    @staticmethod
    def _deletion_key(user,store,request):
        return hashlib.sha256(json.dumps(['account-delete-v1',user['tenant_id'],user['id'],store,request],separators=(',',':')).encode()).hexdigest()

    @staticmethod
    def _deletion_public(row,replayed=False):
        return {key:deepcopy(row[key]) for key in ('requestId','accountId','platform','nickname','state','message')}|{'replayed':replayed}

    def account_delete_request(self,user,data):
        user=self._principal(user)
        if (type(data) is not dict or set(data)!={'requestId'} or type(data['requestId']) is not str
                or not re.fullmatch(r'[A-Za-z0-9_-]{16,80}',data['requestId'])):
            raise PlatformRuntimeError('INVALID_INPUT','请保留原账号移除操作编号',400)
        store=user.get('_workbench_store_id')
        if not store:raise PlatformRuntimeError('ACCOUNT_SCOPE_FORBIDDEN','请先选择当前门店',403)
        key=self._deletion_key(user,store,data['requestId'])
        row=self.core.store.get('workbench_account_deletion_v1',key)
        if row is None:return {'requestId':data['requestId'],'state':'not_started','message':'未找到这个原操作回执，未重新移除账号','replayed':True}
        if (row.get('tenant_id')!=user['tenant_id'] or row.get('ownerId')!=user['id'] or row.get('owner')!=user['username'] or row.get('storeId')!=store):
            raise PlatformRuntimeError('ACCOUNT_SCOPE_FORBIDDEN','原账号移除操作不属于当前员工与门店',403)
        return self._deletion_public(row,True)

    def delete_account(self,user,data):
        user=self._principal(user);store=user.get('_workbench_store_id')
        if (type(data) is not dict or set(data)!={'accountId','platform','expectedNickname','confirmed','requestId'}
                or data.get('platform') not in ('xiaohongshu','douyin') or data['confirmed'] is not True
                or type(data['expectedNickname']) is not str or len(data['expectedNickname'])>100
                or any(ord(c)<32 for c in data['expectedNickname'])
                or type(data['requestId']) is not str or not re.fullmatch(r'[A-Za-z0-9_-]{16,80}',data['requestId'])):
            raise PlatformRuntimeError('ACCOUNT_DELETE_CONFIRMATION_REQUIRED','请本人核对原账号昵称和平台后确认移除',400)
        if not store:raise PlatformRuntimeError('ACCOUNT_SCOPE_FORBIDDEN','请先选择当前门店',403)
        key=self._deletion_key(user,store,data['requestId'])
        fingerprint=hashlib.sha256(json.dumps(data,sort_keys=True,ensure_ascii=False,separators=(',',':')).encode()).hexdigest()
        # Only the destructive original call is protected by the original
        # service/Business/Core locks. Never hold Core or a Store transaction
        # while waiting for the service's connection/job locks.
        with self._run_lock:
            with self.core.store.connect() as db:
                db.execute('BEGIN IMMEDIATE')
                raw=db.execute('SELECT body FROM records WHERE entity=? AND id=? AND tenant_id=?',('workbench_account_deletion_v1',key,user['tenant_id'])).fetchone()
                if raw:
                    row=json.loads(raw['body'])
                    if row.get('inputDigest')!=fingerprint:raise PlatformRuntimeError('ACCOUNT_DELETE_REQUEST_CONFLICT','原操作编号对应的账号或确认内容已变化，请查询原回执',409)
                    return self._deletion_public(row,True)
            self._executor(user,online=False)
            account=self._account(user,data['accountId'])
            if (account.get('platform')!=data['platform'] or account.get('cloud_owner')!=user['username'] or account.get('store_id')!=store):
                raise PlatformRuntimeError('ACCOUNT_SCOPE_FORBIDDEN','此账号不属于当前员工、门店或平台',403)
            nickname=str(account.get('platform_nickname') or account.get('name') or '')[:100]
            if nickname!=data['expectedNickname']:
                raise PlatformRuntimeError('ACCOUNT_DELETE_IDENTITY_CHANGED','账号昵称已变化，本次未移除；请重新核对当前账号',409)
            if self.core.account_mode_status(account['id'],user['tenant_id']).get('status')=='active':
                raise PlatformRuntimeError('ACCOUNT_BUSY','这个账号仍有未结束的原操作，请先核对采集、发送或未知结果',409)
            binding=self.core.account_delete_digest(account)
            row={'id':key,'tenant_id':user['tenant_id'],'ownerId':user['id'],'owner':user['username'],'storeId':store,
                'requestId':data['requestId'],'accountId':account['id'],'platform':account['platform'],'nickname':nickname,
                'inputDigest':fingerprint,'accountDigest':binding,'state':'unknown','message':'原移除操作已登记，结果待核对；不会自动再次移除',
                'createdAt':datetime.now(timezone.utc).isoformat()}
            with self.core.store.connect() as db:
                db.execute('BEGIN IMMEDIATE')
                old=db.execute('SELECT body FROM records WHERE entity=? AND id=? AND tenant_id=?',('workbench_account_deletion_v1',key,user['tenant_id'])).fetchone()
                if old:
                    old=json.loads(old['body'])
                    if old.get('inputDigest')!=fingerprint:raise PlatformRuntimeError('ACCOUNT_DELETE_REQUEST_CONFLICT','原操作内容已变化，请查询原回执',409)
                    return self._deletion_public(old,True)
                for entry in db.execute('SELECT body FROM records WHERE entity=? AND tenant_id=?',('workbench_account_deletion_v1',user['tenant_id'])):
                    pending=json.loads(entry['body'])
                    if pending.get('accountId')==account['id'] and pending.get('state')=='unknown':
                        raise PlatformRuntimeError('ACCOUNT_DELETE_ORIGINAL_REQUIRED','此账号已有未确认的原移除操作，请保留原编号核对，不要另建操作',409)
                db.execute('INSERT INTO records VALUES(?,?,?,?)',('workbench_account_deletion_v1',key,user['tenant_id'],json.dumps(row,ensure_ascii=False)))
            try:
                result=self.service.delete_account(account['id'],expected_account_digest=binding)
                if not isinstance(result,dict) or result.get('ok') is not True or result.get('deleted_id')!=account['id']:
                    raise ValueError('unconfirmed original account deletion result')
            except Exception as error:
                # Conservative boundary: after entering the mature service its
                # cleanup/audit may have partly committed. A missing success
                # receipt must never authorize a new key or another delete.
                safe_messages=('账号确认后的身份或资料已变化，本次未删除，请重新核对',
                    '这个账号正在采集，请先停止任务并等待结束后再删除',
                    '这个账号正在发送或处理消息队列，请等待结束后再删除',
                    '该账号仍在另一助手进程执行平台操作，请等待结束后再删除',
                    '该账号仍在执行平台操作，请等待结束后再删除',
                    '账号登录状态清理失败，未删除账号；请检查本机文件权限')
                detail=str(error) if str(error) in safe_messages else '原账号移除未取得确定回执'
                row['message']=detail+'。请核对原操作，软件不会自动重删。'
                row['finishedAt']=datetime.now(timezone.utc).isoformat()
                self.core.store.put('workbench_account_deletion_v1',row)
                raise PlatformRuntimeError('ACCOUNT_DELETE_RESULT_UNCONFIRMED',row['message'],409,mutation_committed=None) from None
            row.update(state='deleted',message=result.get('message') or '账号已从软件移除，客户与历史记录保留。',finishedAt=datetime.now(timezone.utc).isoformat())
            self.core.store.put('workbench_account_deletion_v1',row)
            return self._deletion_public(row)

    @staticmethod
    def _verification_window_visible(job):
        process=job.get('process')
        if os.name!='nt' or process is None or process.poll() is not None or type(getattr(process,'pid',None)) is not int:return False
        # Observe only a visible top-level window of OUR registered child PID.
        # Starting a worker/process alone is never an opened-window receipt.
        import ctypes
        from ctypes import wintypes
        found=[];callback=ctypes.WINFUNCTYPE(wintypes.BOOL,wintypes.HWND,wintypes.LPARAM)
        user32=ctypes.WinDLL('user32',use_last_error=True)
        user32.IsWindowVisible.argtypes=[wintypes.HWND];user32.IsWindowVisible.restype=wintypes.BOOL
        user32.GetWindowThreadProcessId.argtypes=[wintypes.HWND,ctypes.POINTER(wintypes.DWORD)]
        def visit(hwnd,_):
            pid=wintypes.DWORD();user32.GetWindowThreadProcessId(hwnd,ctypes.byref(pid))
            if pid.value==process.pid and user32.IsWindowVisible(hwnd):found.append(True);return False
            return True
        user32.EnumWindows.argtypes=[callback,wintypes.LPARAM];user32.EnumWindows.restype=wintypes.BOOL
        user32.EnumWindows(callback(visit),0)
        return bool(found)

    def _verification_job_result(self,user,job):
        self._account(user,job['account_id'])
        visible=self._verification_window_visible(job)
        state=job.get('status','running');failed=state=='failed'
        status='failed' if failed else 'verification_open' if visible else 'completed' if job['worker_done'].is_set() else 'verification_opening'
        message=('原账号网页未成功打开，请保留账号并核对本机网页登录组件；未自动采集。' if failed else
            '此账号原有浏览器窗口已显示；网页加载与登录状态仍请本人核对，未自动采集。' if visible else
            '此账号原网页已关闭；账号与采集断点保留。' if status=='completed' else
            '正在打开此账号原有小红书网页，尚未确认窗口显示；未自动采集。')
        return {'id':job['id'],'jobId':job['id'],'accountId':job['account_id'],'status':status,'phase':job.get('phase','manual_verification'),
            'message':message,'windowOpen':visible,'windowEvidence':'visible_owned_child_window' if visible else 'owned_child_not_visible',
            'pageLoaded':False,'platformLoginConfirmed':False,'autoResume':False,
            'persistentBrowser':True,**({'errorCode':'VERIFICATION_WINDOW_FAILED'} if failed else {})}

    @staticmethod
    def _account_metadata_view(account):
        # These are the original reviewed login helpers' fixed entry URLs,
        # not account identity or an editable navigation grant.
        entry={'xiaohongshu':'https://www.xiaohongshu.com/explore',
               'douyin':'https://www.douyin.com/'}[account['platform']]
        binding={key:account.get(key) for key in ('id','tenant_id','cloud_owner','store_id',
            'platform','name','remarks','url','platform_uid','conn_id','status','identity_recovery_pending')}
        digest=hashlib.sha256(json.dumps(binding,ensure_ascii=False,sort_keys=True,
            separators=(',',':'),allow_nan=False).encode()).hexdigest()
        remarks=account.get('remarks') if isinstance(account.get('remarks'),str) else str(account.get('name') or '')
        return {'accountId':account['id'],'platform':account['platform'],
            'name':remarks,'remarks':remarks,
            'platformNickname':str(account.get('platform_nickname') or '')[:100],
            'url':entry,'urlEditable':False,'metadataDigest':digest,
            'message':'登录网址由原连接流程固定，当前可修改备注；备注不改变平台身份或登录状态'}

    def account_metadata(self,user,data,*,save=False):
        user=self._principal(user)
        fields={'accountId','platform'}|({'name','expectedMetadataDigest'} if save else set())
        if (type(data) is not dict or not fields.issubset(data)
                or set(data)-fields-({'url'} if save else set())
                or type(data.get('platform')) is not str or data['platform'] not in ('xiaohongshu','douyin')):
            raise PlatformRuntimeError('INVALID_INPUT','账号资料参数无效',400)
        if data['platform'] not in self.server.company.get('platforms',[]):
            raise PlatformRuntimeError('PLATFORM_FORBIDDEN','企业尚未开放此平台',403)
        if save and (type(data['name']) is not str or not 1<=len(data['name'].strip())<=100
                or any(ord(char)<32 or ord(char)==127 for char in data['name'])
                or type(data['expectedMetadataDigest']) is not str
                or re.fullmatch(r'[0-9a-f]{64}',data['expectedMetadataDigest']) is None):
            raise PlatformRuntimeError('INVALID_INPUT','请填写1至100字备注并读取当前资料版本',400)
        with self.core.lock:
            try:account=self._account(user,data['accountId'])
            except PlatformRuntimeError as error:
                if error.code!='ACCOUNT_FORBIDDEN':raise
                raise PlatformRuntimeError('ACCOUNT_SCOPE_FORBIDDEN','账号不属于当前平台、门店或本人',403) from None
            if (account.get('platform')!=data['platform']
                    or account.get('cloud_owner')!=user['username']
                    or not user.get('_workbench_store_id')
                    or account.get('store_id')!=user['_workbench_store_id']):
                raise PlatformRuntimeError('ACCOUNT_SCOPE_FORBIDDEN','账号不属于当前平台、门店或本人',403)
            current=self._account_metadata_view(account)
            if not save:return current
            if 'url' in data and data['url']!=current['url']:
                raise PlatformRuntimeError('ACCOUNT_URL_READ_ONLY','当前登录网址由原连接流程固定，仅支持修改备注',403)
            if data['expectedMetadataDigest']!=current['metadataDigest']:
                raise PlatformRuntimeError('ACCOUNT_METADATA_CONFLICT','账号资料或原绑定已变化，请重新读取',409)
            # Only local remarks enter the original Core save. Original name
            # can be refreshed from the platform; the separate remark survives.
            protected={key:deepcopy(value) for key,value in account.items()
                if key not in ('remarks','created_at','updated_at')}
            try:
                self.core.handle('save',{'entity':'accounts','record':{
                    'id':account['id'],'remarks':data['name'].strip()}},user)
            except Exception:
                raise PlatformRuntimeError('ACCOUNT_METADATA_RESULT_UNCONFIRMED',
                    '原账号保存未取得确定回执，请读取原账号资料核对，不要自动重复保存',503,
                    mutation_committed=None) from None
            try:
                self._principal(user)
                after=self._account(user,account['id'])
            except Exception:
                raise PlatformRuntimeError('ACCOUNT_METADATA_RESULT_UNCONFIRMED',
                    '备注已提交，当前身份或账号归属需重新核对；请读取原账号，不要自动重复保存',409,
                    mutation_committed=True) from None
            if any(after.get(key)!=value for key,value in protected.items()):
                raise PlatformRuntimeError('ACCOUNT_METADATA_RESULT_UNCONFIRMED',
                    '备注提交后原绑定发生变化，请读取当前账号核对',409,mutation_committed=True)
            return self._account_metadata_view(after)

    def create_account(self, user, data):
        user = self._principal(user)
        if (type(data) is not dict or set(data) != {'platform','name'}
                or data.get('platform') not in self.server.company.get('platforms', [])):
            raise PlatformRuntimeError('PLATFORM_FORBIDDEN', '请选择当前企业已开放的平台', 403)
        if not isinstance(data['name'],str) or not 1 <= len(data['name'].strip()) <= 100 or any(ord(char)<32 for char in data['name']):
            raise PlatformRuntimeError('INVALID_INPUT','请填写1至100字的账号名称',400)
        self._prepare_for_connection(user)
        executor = self._executor(user, online=False)
        if data['platform'] == 'xiaohongshu':
            code,message=self._readiness(user,{'id':'','platform':'xiaohongshu'})
            if code:
                raise PlatformRuntimeError(code.upper(),message)
            result = self._execute(executor,user,'account_create',data)
        else:
            result = self.service.create_account_slot(data)
        row = result.get('account') if isinstance(result,dict) and isinstance(result.get('account'),dict) else result
        ident = row.get('id') if isinstance(row,dict) else None
        if not isinstance(ident,str):
            raise PlatformRuntimeError('ACCOUNT_RESULT_UNCONFIRMED','账号记录已提交，结果需刷新核对，请勿重复创建',503,mutation_committed=None)
        with self.core.lock:
            user=self._principal(user)
            record=self.core._get('accounts',ident,user['tenant_id'])
            selected=user.get('_workbench_store_id')
            if (not selected or record.get('cloud_owner') != user['username']
                    or record.get('store_id') not in (None,'',selected)):
                raise PlatformRuntimeError('ACCOUNT_SCOPE_UNCONFIRMED','新账号归属未核实，请保留原结果核对',503,mutation_committed=True)
            record['store_id']=selected
            record.setdefault('status','login_required')
            self.core.store.put('accounts',record)
        self._account(user,ident)
        return {'result':{'accountId':ident,'status':'created','message':'账号记录已创建，请连接并核实平台身份'}, **self.snapshot(user)}

    def connect_account(self, user, data):
        user = self._principal(user)
        if type(data) is not dict or set(data) != {'accountId'}:
            raise PlatformRuntimeError('INVALID_INPUT', '连接账号参数无效', 400)
        self._prepare_for_connection(user)
        account = self._account(user,data['accountId'])
        code, message = self._readiness(user,account)
        if code=='account_review_required' and account['platform']=='xiaohongshu':
            return self._recover_xhs_identity(user,account)
        if code:
            raise PlatformRuntimeError(code.upper(),message)
        if account['platform'] == 'xiaohongshu':
            try:
                result = self.service.start_account_login(account['id'])
            except PlatformRuntimeError:
                raise
            except Exception as error:
                # A registered owned window is the result; losing its return
                # must not make the employee open another login window.
                existing = self._active_login_job_id(user, account)
                if existing:
                    result = {'login_job': existing}
                elif str(error) in ('浏览器登录助手来源未确认','浏览器登录助手校验未通过','浏览器登录助手未就绪'):
                    raise PlatformRuntimeError('LOGIN_COMPONENT_NOT_READY', '本机登录组件暂未就绪，账号资料已保留', 503) from None
                else:
                    raise PlatformRuntimeError('LOGIN_START_FAILED', '登录窗口暂未打开，账号资料已保留，请稍后再点登录', 503) from None
        elif account['platform'] == 'douyin':
            result = self._douyin_operation(user,account,'start')
        else:
            raise PlatformRuntimeError('PLATFORM_UNSUPPORTED','此平台尚未接入当前账号连接界面')
        if account['platform'] == 'xiaohongshu':
            result=self._login_result(user,result)
        return {'result':result, **self.snapshot(user)}

    def _active_login_job_id(self, user, account):
        """Only a live job of this already-authorized exact account/actor."""
        with self.server.job_lock:
            for job in reversed(list(self.server.jobs.values())):
                ident = job.get('id')
                done = job.get('worker_done')
                if (job.get('kind') != 'assistant_account_login'
                        or job.get('account_id') != account['id']
                        or job.get('owner_id') != user['id'] or job.get('tenant_id') != user['tenant_id']
                        or not isinstance(ident, str) or re.fullmatch(r'[a-f0-9]{24}', ident) is None
                        or not isinstance(done, threading.Event) or done.is_set()):
                    continue
                if job.get('status') in ('pending','running') or job.get('window_open') is True:
                    return ident
        return ''

    @staticmethod
    def _douyin_result(value):
        value=value if isinstance(value,dict) else {}
        state=value.get('state','unknown')
        confirmed=(state=='ready' and value.get('platform_login_confirmed') is True
                   and value.get('binding_verified') is True)
        messages={'ready':'抖音平台身份已核实，请按采集条件开始',
                  'waiting_login':'请在抖音窗口完成本人登录，然后检查连接',
                  'checking':'正在核实抖音登录状态',
                  'choose_window':'抖音窗口归属未确认，请保留本次打开的登录窗口',
                  'disconnected':'请点“连接抖音”打开已保存的浏览器，再检查连接',
                  'failed':'抖音登录未完成，请核对本次登录窗口'}
        message=value.get('message')
        message=message[:1000] if isinstance(message,str) else ''
        # An unverified ready claim never supplies a success message.
        if state=='ready' and not confirmed:message='抖音平台身份尚未核实，请检查连接'
        return {'id':'','status':'ready' if confirmed else state if state in messages and state!='ready' else 'unknown',
                'platformLoginConfirmed':confirmed,'bindingVerified':confirmed,
                'windowOpen':value.get('owned_window_active') is True,
                'persistentBrowser':value.get('owned_window_active') is True,
                'errorCode':value.get('error_code') if value.get('error_code')=='LOGIN_WINDOW_PROCESS_FAILED' else '',
                'message':message or messages.get(state,'抖音连接结果尚未确认，请检查连接')}

    def check_account(self, user, data):
        """Read only the current employee/store account's actual platform state."""
        user=self._principal(user)
        if type(data) is not dict or set(data)!={'accountId'}:
            raise PlatformRuntimeError('INVALID_INPUT','检查账号参数无效',400)
        self._prepare_for_connection(user)
        account=self._account(user,data['accountId'])
        code,message=self._readiness(user,account)
        if code=='account_review_required' and account['platform']=='xiaohongshu':
            return self._recover_xhs_identity(user,account)
        if code:raise PlatformRuntimeError(code.upper(),message)
        if account['platform']=='douyin':
            result=self._douyin_operation(user,account,'status')
        elif account['platform']=='xiaohongshu':
            pending=self.service.retry_existing_account_login(account['id'])
            if pending is not None:
                return {'result':self._login_result(user,pending),**self.snapshot(user)}
            value=self._execute(self._executor(user),user,'account_status',{'account_id':account['id']})
            confirmed=isinstance(value,dict) and value.get('status')=='ready'
            result={'id':'','status':'ready' if confirmed else 'disconnected',
                    'message':'小红书平台身份已核实' if confirmed else '小红书身份尚未核实，请连接本人账号'}
        else:raise PlatformRuntimeError('PLATFORM_UNSUPPORTED','此平台尚未接入账号检查')
        return {'result':result,**self.snapshot(user)}

    def _recover_xhs_identity(self,user,account):
        """One explicit same-UID status; no ordinary account_check or task admission."""
        from core.xhs_identity_recovery import (trusted_scope,IdentityRecoveryError,
            credential_fingerprint,digest)
        from core.engine import evaluate_xhs_identity
        from assistant.browser_session_commit import account_revision,commit_identity_revalidation
        directory=self.data_dir/'accounts'/user['tenant_id']/account['id']
        connection=self.server.account_connections.locks.setdefault(account['id'],threading.Lock())
        if not connection.acquire(blocking=False):
            raise PlatformRuntimeError('ACCOUNT_BUSY','此账号正在核对身份，请等待本次检查结束')
        try:
            self._verification_idle(user,account)
            if (account.get('identity_recovery_pending')
                    or (directory/'.xiaohongshu-cli/.browser-session-commit.json').exists()):
                raise IdentityRecoveryError('RECOVERY_PENDING')
            candidate_provider=self._recovery_candidate_provider(user,account,directory)
            try:cookie_binding=credential_fingerprint(directory)
            except IdentityRecoveryError:
                if candidate_provider is None:raise
                cookie_binding=None
            saved=self.service.vault.read()
            session=getattr(self._executor(user),'_xhs_app_session',None)
            original_actor={key:user.get(key) for key in ('id','tenant_id','username','role','_workbench_store_id')}
            binding={'actor':original_actor,'account_id':account['id'],
                'tenant_id':account['tenant_id'],'device_id':saved['device']['id'],
                'session':session.binding.hex(),'cookie':cookie_binding,
                'auth_generation':str(account.get('auth_generation') or '')}
            box={}
            def guard():
                try:
                    current_actor=self._principal(user)
                    if {key:current_actor.get(key) for key in original_actor}!=original_actor:return False
                    self._executor(user)
                    if (not self.core._employee_release_allowed()
                            or self.core.employee_release_device_id!=saved['device']['id']
                            or self.service.vault.read()!=saved
                            or getattr(self.service.executor,'_xhs_app_session',None) is not session
                            or self._recovery_cookie_binding(directory)!=(box['scope'].active_credential if box else cookie_binding)):return False
                    current=self._account(user,account['id'])
                    expected=box['scope'].expected_revision if box else account_revision(account)
                    return account_revision(current)==expected
                except Exception:return False
            def finish(attempt,payload):
                attempt.receipt()
                value=payload.get('data',payload) if isinstance(payload,dict) else None
                profile=value.get('user') if isinstance(value,dict) else None
                uid=next((profile.get(key) for key in ('id','user_id','red_id') if profile.get(key)),None) if isinstance(profile,dict) else None
                nickname=(profile.get('nickname') or profile.get('nick_name')) if isinstance(profile,dict) else None
                if (not isinstance(payload,dict) or 'ok' in payload and payload['ok'] is not True
                        or not isinstance(value,dict) or value.get('authenticated') is not True
                        or not isinstance(profile,dict) or profile.get('guest',False) is not False
                        or not isinstance(uid,str) or not 1<=len(uid.strip())<=160
                        or not isinstance(nickname,str) or not 1<=len(nickname.strip())<=100):
                    raise IdentityRecoveryError('RECOVERY_IDENTITY_UNVERIFIED')
                from assistant.browser_login_coordinator import BrowserLoginCoordinator
                def current():
                    safe=guard()
                    if safe:
                        try:attempt.check()
                        except IdentityRecoveryError:safe=False
                    return {**account,'exists':True,'revision':account_revision(account),
                        'cloud_paused':not safe,'safety_paused':False,'access_revoked':False}
                def claim(uid):
                    self.service._claim_xhs_account({**account,'platform_uid':uid},_identity_attempt=attempt)
                    attempt.receipt()
                    return True
                def commit(candidate,decision,original):
                    return commit_identity_revalidation(self.core.store,directory,account,decision,attempt)=='committed'
                coordinator=BrowserLoginCoordinator(stage=lambda:attempt.scope.candidate or directory,
                    status=lambda candidate:payload,local_accounts=lambda:self.core.store.list('accounts',user['tenant_id']),
                    claim=claim,commit=commit,discard=lambda candidate:None,current=current,
                    cancelled=lambda:False,deadline=attempt.deadline,expected_revision=account_revision(account))
                outcome=coordinator.run()
                if outcome.state!='completed':raise IdentityRecoveryError('RECOVERY_'+outcome.code.upper())
                return {'id':'','status':'ready','platformLoginConfirmed':True,
                    'message':'账号身份已核实，采集仍暂停','collectionAuthorized':False,'autoResume':False}
            scope=trusted_scope(self.core.adapters,account,directory,guard=guard,finish=finish,
                binding=binding,lease_until=self.core.employee_release_until_monotonic,
                source_sha=(self.server.company.get('runtime') or {}).get('cli_source_sha256',''),
                candidate_provider=candidate_provider)
            box['scope']=scope
            result=self.core.adapters.execute('xiaohongshu',['status','--json'],directory,
                _identity_recovery_scope=scope)
            return {'result':result,**self.snapshot(user)}
        except IdentityRecoveryError as error:
            raise PlatformRuntimeError(error.code,'本次账号身份尚未完成核实，采集保持暂停；未自动重试') from None
        finally:connection.release()

    @staticmethod
    def _recovery_cookie_binding(directory):
        from core.xhs_identity_recovery import credential_fingerprint,IdentityRecoveryError
        if not (directory/'.xiaohongshu-cli/cookies.json').exists():return None
        return credential_fingerprint(directory)

    def _recovery_candidate_provider(self,user,account,directory):
        """Select one registered owned capture window; never open or replace one here."""
        from core.xhs_identity_recovery import IdentityRecoveryError
        from assistant.browser_login_service import _profile_scope,_staging_scope
        from assistant.xhs_browser_login import _candidate,_signal,_ack
        profile=directory/'xhs-browser-profile'
        windows=self._verification_windows(user,account)
        # A historical profile or legacy verification-only helper has no
        # capture protocol. It does not own the existing CLI session.
        if not any(job.get('identity_capture_capable') is True for job in windows):return None
        if (not _profile_scope(self.data_dir,directory,profile) or not profile.is_dir()
                or len(windows)!=1 or windows[0].get('identity_capture_capable') is not True):
            raise IdentityRecoveryError('RECOVERY_HANDOFF_UNAVAILABLE')
        job=windows[0];stage=directory/'work/browser-login'/job['id']
        if not _staging_scope(self.data_dir,directory,stage) or not stage.is_dir():
            raise IdentityRecoveryError('RECOVERY_HANDOFF_UNAVAILABLE')
        def capture(attempt):
            attempt.check()
            if job.get('window_open') is not True or job['process'].poll() is not None:
                raise IdentityRecoveryError('RECOVERY_HANDOFF_UNAVAILABLE')
            # No old candidate may satisfy a new explicit action.
            previous={item.name for item in stage.glob('candidate-*.ready.json')}
            _signal(stage,'capture.flag')
            deadline=min(attempt.deadline,time.monotonic()+12)
            while time.monotonic()<deadline:
                attempt.check()
                if (stage/'cancel.flag').exists() or job['process'].poll() is not None:
                    raise IdentityRecoveryError('RECOVERY_HANDOFF_UNAVAILABLE')
                markers=[item for item in stage.glob('candidate-*.ready.json') if item.name not in previous]
                if len(markers)>1:raise IdentityRecoveryError('RECOVERY_CANDIDATE_INVALID')
                if markers:
                    selected=_candidate(stage,markers[0])
                    if selected is None:raise IdentityRecoveryError('RECOVERY_CANDIDATE_INVALID')
                    number,candidate,cookie=selected
                    def cleanup(success):
                        from assistant.cli_staging import discard_cli_candidate
                        discard_cli_candidate(cookie)
                        _ack(stage,number,'completed' if success else 'failed')
                        markers[0].unlink(missing_ok=True)
                    attempt.scope.cleanup=cleanup
                    return candidate
                self.service.stop_event.wait(.05)
            raise IdentityRecoveryError('RECOVERY_HANDOFF_UNAVAILABLE')
        return capture

    def _verification_windows(self, user, account):
        with self.server.job_lock:
            return [job for job in self.server.jobs.values()
                if job.get('kind')=='assistant_account_login' and job.get('account_id')==account['id']
                and job.get('owner_id')==user['id'] and job.get('tenant_id')==user['tenant_id']
                and job.get('purpose')=='manual_verification' and isinstance(job.get('worker_done'),threading.Event)
                and not job['worker_done'].is_set()
                and (job.get('process') is None or job['process'].poll() is None)]

    def _verification_idle(self, user, account):
        with self.core.lock:
            tasks=[task for task in self.core.store.list('tasks',user['tenant_id'])
                   if task.get('account_id')==account['id']]
            if any(self._task_active(task) for task in tasks):
                raise PlatformRuntimeError('ACCOUNT_BUSY','请先等待当前账号请求结束，再处理人工验证',409)
        with self.server.job_lock:
            if any(job.get('kind')=='assistant_account_login' and job.get('account_id')==account['id']
                   and job.get('purpose')!='manual_verification' and
                   (job.get('status')=='running' or job.get('process') is not None and job['process'].poll() is None)
                   for job in self.server.jobs.values()):
                raise PlatformRuntimeError('ACCOUNT_BUSY','请先关闭现有登录窗口，再打开人工验证窗口',409)

    def _safety_result(self, user, account):
        summary=self.service.account_safety_status(account['id'])
        revision=summary.get('activity_revision_bytes')
        if type(revision) is not int or revision<0:
            raise PlatformRuntimeError('SAFETY_RESULT_INVALID','安全提醒尚未取得有效版本，请重新读取',503)
        required=summary.get('state')=='review_required'
        window=any(self._verification_window_visible(job) for job in self._verification_windows(user,account))
        return {'accountId':account['id'],'status':'review_required' if required else 'review_recorded',
            'revision':revision,'reviewRequired':required,'reviewReason':summary.get('review_reason','unknown'),
            'verificationWindowOpen':window,'canConfirmReview':False,
            'message':('在原账号网页完成平台验证后，直接点击“检查连接”；采集保持暂停'
                if required else '当前安全记录已读取；检查连接不会自动继续采集')}

    def read_account_safety(self, user, data):
        user=self._principal(user)
        if type(data) is not dict or set(data)!={'accountId'}:
            raise PlatformRuntimeError('INVALID_INPUT','安全提醒参数无效',400)
        account=self._account(user,data['accountId'])
        if account.get('platform')!='xiaohongshu':
            raise PlatformRuntimeError('PLATFORM_UNSUPPORTED','当前人工验证仅用于小红书',400)
        return {'result':self._safety_result(user,account),**self.snapshot(user)}

    def confirm_account_review(self, user, data):
        self._principal(user)
        raise PlatformRuntimeError('IDENTITY_RECHECK_REQUIRED',
            '请在原账号完成平台验证后，直接点击检查连接；无需额外确认复核',409)

    def open_account_verification(self, user, data):
        """Only a fixed existing owned profile; no candidate or platform probes."""
        user=self._principal(user)
        if type(data) is not dict or set(data)!={'accountId'}:
            raise PlatformRuntimeError('INVALID_INPUT','人工验证窗口参数无效',400)
        self._executor(user)
        account=self._account(user,data['accountId'])
        code,message=self._readiness(user,account)
        if account.get('platform')!='xiaohongshu' or code not in ('','account_review_required'):
            raise PlatformRuntimeError(code.upper() if code else 'PLATFORM_UNSUPPORTED',message or '当前人工验证仅用于小红书')
        if account.get('disabled') is True or account.get('status') in (
                'disabled','revoked','duplicate_identity','duplicate_identity_remote','identity_mismatch',
                'identity_unverified','session_recovery_required'):
            raise PlatformRuntimeError('ACCOUNT_IDENTITY_REQUIRED','请先核对当前账号身份，人工验证窗口未打开',409)
        from assistant.browser_login_service import _profile_scope,_staging_scope
        from assistant.xhs_browser_login import _signal
        root=self.data_dir/'accounts'/user['tenant_id']/account['id']
        profile=root/'xhs-browser-profile'
        if not _profile_scope(self.data_dir,root,profile) or not profile.is_dir() or not account.get('platform_uid'):
            raise PlatformRuntimeError('OWNED_PROFILE_REQUIRED','未找到此账号原有浏览器资料，请保留账号并核对登录来源',409)
        binding=tuple(account.get(key) for key in ('id','tenant_id','cloud_owner','platform','platform_uid','store_id'))
        def authorize():
            # Serialize watcher readiness with the existing session commit lock.
            with self.core.lock:
                actor=self._principal(user);self._executor(actor)
                fresh=self._account(actor,account['id'])
                reason,explanation=self._readiness(actor,fresh)
                if (reason not in ('','account_review_required') or binding!=tuple(fresh.get(key) for key in
                        ('id','tenant_id','cloud_owner','platform','platform_uid','store_id'))):
                    raise PlatformRuntimeError('VERIFICATION_SCOPE_CHANGED','人工验证的原账号或本机许可已变化',409)
                if not _profile_scope(self.data_dir,root,profile) or not profile.is_dir():
                    raise PlatformRuntimeError('OWNED_PROFILE_REQUIRED','原浏览器资料已变化，验证窗口停止',409)
                return actor
        with self._run_lock,self.core.lock:
            authorize()
            # A completed owned login browser is the same human workspace.
            # Transfer its candidate consumer before using it for task resume.
            with self.server.job_lock:
                owned=[job for job in self.server.jobs.values()
                    if job.get('kind')=='assistant_account_login' and job.get('account_id')==account['id']
                    and job.get('owner_id')==user['id'] and job.get('tenant_id')==user['tenant_id']
                    and job.get('persistent_browser') is True and job.get('identity_capture_capable') is True
                    and isinstance(job.get('worker_done'),threading.Event) and not job['worker_done'].is_set()
                    and job.get('process') is not None and job['process'].poll() is None]
                if len(owned)==1 and (owned[0].get('status')=='completed' or
                        owned[0].get('status')=='failed' and owned[0].get('phase')=='waiting_manual_check'):
                    owned[0].update(purpose='manual_verification',status='running',phase='manual_verification')
            self._verification_idle(user,account)
            existing=self._verification_windows(user,account)
            if existing:
                current=existing[0]
                if self._verification_window_visible(current):
                    stage=root/'work/browser-login'/current['id']
                    if not _staging_scope(self.data_dir,root,stage) or not stage.is_dir():
                        raise PlatformRuntimeError('VERIFICATION_WINDOW_INVALID','原验证窗口状态需核对',409)
                    _signal(stage,'focus.flag')
                return {'result':self._verification_job_result(user,current),**self.snapshot(user)}
            ident=uuid4().hex[:24];stage=root/'work/browser-login'/ident
            if not _staging_scope(self.data_dir,root,stage):
                raise PlatformRuntimeError('VERIFICATION_WINDOW_INVALID','人工验证目录无效',409)
            job={'id':ident,'kind':'assistant_account_login','mode':'browser','purpose':'manual_verification',
                'persistent_browser':False,'window_open':False,'account_id':account['id'],
                'owner_id':user['id'],'tenant_id':user['tenant_id'],'status':'running',
                'phase':'manual_verification','cancel_file':str(stage/'cancel.flag'),'worker_done':threading.Event()}
            # job_lock is a non-reentrant Lock. Scope/idle/snapshot helpers
            # acquire it themselves, so only registration belongs inside it.
            with self.server.job_lock:
                if self.server.closing:raise PlatformRuntimeError('RUNTIME_CLOSED','工作台正在关闭',503)
                if any(other.get('account_id')==account['id'] and other.get('kind')=='assistant_account_login'
                        and other.get('status')=='running' for other in self.server.jobs.values()):
                    raise PlatformRuntimeError('ACCOUNT_BUSY','当前账号窗口正在处理中，请稍候',409)
                self.server.jobs[ident]=job
        def worker():
            process=None
            try:
                from core.adapters import account_execution_lock
                from assistant.owned_helper_process import login_helper_argv
                from assistant.browser_login_service import _cancel_marker
                import app
                import subprocess
                with self.core.adapters.channel_guard:
                    channel=self.core.adapters.channel_locks.setdefault('xiaohongshu:'+str(root.resolve()),threading.Lock())
                if not channel.acquire(blocking=False):raise ValueError('account_busy')
                try:
                    with account_execution_lock(root):
                        authorize();stage.mkdir(parents=True,exist_ok=False)
                        helper=self.server.browser_login_helper_path
                        if not self.server.browser_login_helper_validator(helper):raise ValueError('helper_unverified')
                        command=login_helper_argv(stage,stage/'cancel.flag',profile)
                        argv=[command.argv[0],'-B',str(helper),*command.argv[2:],'--keep-open','--explicit-capture-only']
                        with self.core.lock,self.server.job_lock:
                            authorize()
                            process=subprocess.Popen(argv,shell=False,stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,
                                stderr=subprocess.DEVNULL,cwd=str(app.ROOT),
                                creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0),
                                env={**os.environ,'FANGYU_LOGIN_SOURCE_ROOT':str(app.ROOT)})
                            job.update(process=process,window_open=False,identity_capture_capable=True)
                finally:channel.release()
                while process.poll() is None:
                    job['window_open']=self._verification_window_visible(job)
                    try:authorize()
                    except Exception:_cancel_marker(job)
                    if job.get('status')=='cancelled':_cancel_marker(job)
                    job['worker_done'].wait(.2)
                job.update(status='completed',phase='manual_verification_closed')
            except Exception:
                job.update(status='failed',phase='manual_verification_failed')
            finally:
                job['window_open']=False;job['worker_done'].set()
        thread=threading.Thread(target=worker,name='owned-manual-xhs-verification',daemon=True)
        job['worker']=thread;thread.start()
        return {'result':self._verification_job_result(user,job),**self.snapshot(user)}

    def _verification_task(self,user,data):
        user=self._principal(user)
        if type(data) is not dict or set(data)!={'taskId'}:
            raise PlatformRuntimeError('INVALID_INPUT','请选择原采集任务',400)
        task=self._task(user,data['taskId']);account=self._account(user,task.get('account_id'))
        if task.get('platform')!='xiaohongshu' or account.get('platform')!='xiaohongshu':
            raise PlatformRuntimeError('PLATFORM_UNSUPPORTED','此验证入口用于原小红书任务',400)
        self._executor(user);self._verification_idle(user,account)
        if not self._current_comment_policy(task):
            raise PlatformRuntimeError('TASK_POLICY_CHANGED','任务条件已变化，请保留原记录',409)
        return user,task,account

    @staticmethod
    def _source_receipt_partition(task):
        from core.acquisition_extension_runtime import receipt_partition
        return receipt_partition(task)

    def _can_check_interactions(self,user,task,account):
        if not task or task.get('source_kind')!='own_interactions' or not task.get('exhausted'):return False
        if not self._current_comment_policy(task) or self._task_active(task):return False
        cp=(task.get('pipeline') or {}).get('extension')
        if not cp or cp.get('jobs') or account.get('status')!='ready':return False
        from core.acquisition_sources import load_plan
        try:
            load_plan(self.core.store,task)
            if self._collection_readiness(user,account)[0]:return False
            if self._collection_analysis_backlog(user,task['id'])>=200:return False
            # Original task target and daily account limits continue to apply.
            summary=self.core._collection_summary(task,user,'stopped','new_scan',{})
            return summary['remaining']>0
        except (ValueError,KeyError,TypeError):return False

    def _verified_scope(self,user,task,account):
        identity=tuple(account.get(k) for k in ('id','tenant_id','cloud_owner','store_id','platform','platform_uid'))
        value=[user['tenant_id'],user['username'],task['id'],identity,self._collection_binding(task)]
        from core.acquisition_extension_runtime import source_scan
        if source_scan(task):value.append(source_scan(task))
        return hashlib.sha256(json.dumps(value,ensure_ascii=True,sort_keys=True).encode()).hexdigest()

    def _verified_task_pages(self,user,task,account):
        from core.xhs_verified_resume import verified_pages
        directory=self.core.store.directory/'accounts'/user['tenant_id']/account['id']
        return verified_pages(directory,task['id'],self._verified_scope(user,task,account),account,partition=self._source_receipt_partition(task))

    def _commit_verified_browser(self,user,task,account,context,continuation_guard=lambda:None):
        from assistant.browser_login_service import _profile_scope,_staging_scope
        from assistant.xhs_browser_login import _candidate,_signal,_ack,validate_browser_candidate
        from assistant.cli_staging import discard_cli_candidate
        from assistant.browser_session_commit import account_revision
        directory=self.data_dir/'accounts'/user['tenant_id']/account['id']
        windows=self._verification_windows(user,account)
        if (len(windows)!=1 or windows[0].get('identity_capture_capable') is not True
                or windows[0].get('window_open') is not True or not account.get('platform_uid')):
            raise PlatformRuntimeError('VERIFICATION_WINDOW_REQUIRED','请保持此账号的原验证窗口打开，再继续原任务',409)
        job=windows[0];proc=job.get('process');stage=directory/'work/browser-login'/job['id']
        profile=directory/'xhs-browser-profile'
        if (proc is None or not _profile_scope(self.data_dir,directory,profile) or not profile.is_dir()
                or not _staging_scope(self.data_dir,directory,stage) or not stage.is_dir()):
            raise PlatformRuntimeError('VERIFICATION_WINDOW_INVALID','原验证窗口需重新核对',409)
        executor=self._executor(user);binding=self._collection_binding(task);revision=account_revision(account)
        selected=[]
        def authorize():
            continuation_guard()
            actor=self._principal(user)
            if self._executor(actor) is not executor:raise ValueError('device_changed')
            current=self._task(actor,task['id']);fresh=self._account(actor,account['id'])
            if (current.get('account_id')!=account['id'] or self._collection_binding(current)!=binding
                    or account_revision(fresh)!=revision or not self._current_comment_policy(current)
                    or job.get('status')!='running' or proc.poll() is not None
                    or (stage/'cancel.flag').exists()):raise ValueError('verification_scope_changed')
            self._verification_idle(actor,fresh)
        def capture():
            authorize();previous={p.name for p in stage.glob('candidate-*.ready.json')}
            _signal(stage,'capture.flag');deadline=time.monotonic()+12
            while time.monotonic()<deadline:
                authorize()
                markers=[p for p in stage.glob('candidate-*.ready.json') if p.name not in previous]
                if len(markers)>1:raise ValueError('verification_candidate_invalid')
                if markers:
                    candidate=_candidate(stage,markers[0])
                    if candidate is None:raise ValueError('verification_candidate_invalid')
                    selected.append((markers[0],candidate));return candidate
                self.service.stop_event.wait(.05)
            raise ValueError('verification_capture_unconfirmed')
        # The shared validator owns the account/process lock through capture,
        # status and commit. Adapter.execute owns its own non-reentrant channel.
        completed=False
        try:
            outcome,diagnostic=validate_browser_candidate(self.service,user,account,directory,stage,job,proc,
                capture,verified_resume=context,authorize=authorize)
            completed=outcome.state=='completed'
            if not completed:
                raise PlatformRuntimeError('VERIFICATION_NOT_FINISHED','本次账号会话尚未核实，请完成本人验证后再继续；原任务已保留',409)
        except PlatformRuntimeError:raise
        except Exception:
            raise PlatformRuntimeError('VERIFICATION_NOT_FINISHED','本次验证结果尚未确认，原任务已保留，请核对窗口状态',409) from None
        finally:
            for marker,candidate in selected:
                discard_cli_candidate(candidate[2]);_ack(stage,candidate[0],'completed' if completed else 'failed')
                marker.unlink(missing_ok=True)

    def _verification_state(self,user,task):
        wait=getattr(self,'_verification_waits',{}).get(task['id']) if task else None
        if not wait or wait['owner']!=(user['tenant_id'],user['username']):return {}
        if wait['binding']!=self._collection_binding(task):return {}
        return {'state':wait.get('state','waiting_user'),'message':wait.get('message','')}

    def _watch_acquisition_verification(self,user,task,account):
        """One passive readiness wait per exact failed receipt and owned window."""
        from core.xhs_verified_resume import failed_page
        from assistant.browser_login_service import _staging_scope
        directory=self.data_dir/'accounts'/user['tenant_id']/account['id']
        context=failed_page(directory,task['id'],self._verified_scope(user,task,account),partition=self._source_receipt_partition(task))
        if context is None:return
        windows=self._verification_windows(user,account)
        if len(windows)!=1:return
        job=windows[0];stage=directory/'work/browser-login'/job['id']
        if not _staging_scope(self.data_dir,directory,stage):return
        with self._run_lock:
            waits=self._verification_waits
            prior=waits.get(task['id'])
            if (prior and prior['receipt']==context['receipt_sha256']
                    and prior.get('thread') and prior['thread'].is_alive()):return
            if prior:prior['cancel'].set()
            wait={'owner':(user['tenant_id'],user['username']),'binding':self._collection_binding(task),
                'receipt':context['receipt_sha256'],'request':uuid4().hex,'cancel':threading.Event(),
                'state':'waiting_user','message':'已打开原账号页面，等待本人完成验证；通过后自动继续采集。'}
            waits[task['id']]=wait
        raw=json.loads((directory/'.workbench-page-receipts'/task['id']/(context['page']+'.json')).read_text('utf-8'))
        payload=json.loads(raw['result']['stdout'])
        reason='authentication_required' if payload['error']['code']=='not_authenticated' else 'verification_required'
        target='https://www.xiaohongshu.com/explore'
        pipeline=task.get('pipeline') or {};notes=pipeline.get('notes');index=pipeline.get('note_index')
        if reason=='verification_required' and type(notes) is list and type(index) is int and 0<=index<len(notes):
            from assistant.xhs_cli_page_worker import validate_args
            candidate=notes[index].get('url') if type(notes[index]) is dict else None
            try:
                validate_args(['comments',candidate,'--json'])
                from urllib.parse import urlsplit
                parsed=urlsplit(candidate)
                if parsed.hostname=='www.xiaohongshu.com' and parsed.path.startswith('/explore/'):target=candidate
            except (ValueError,TypeError):pass
        def worker():
            try:
                deadline=time.monotonic()+15
                while time.monotonic()<deadline and not wait['cancel'].is_set() and not self.closed:
                    windows=self._verification_windows(user,account)
                    if (len(windows)==1 and windows[0]['id']==job['id'] and windows[0].get('window_open')
                            and windows[0].get('identity_capture_capable') and stage.is_dir()):break
                    wait['cancel'].wait(.2)
                else:raise ValueError('window_not_ready')
                request=stage/'verification-watch.json'
                if request.is_symlink():raise ValueError('verification_scope_changed')
                temporary=stage/('verification-watch-'+wait['request']+'.tmp')
                with temporary.open('x',encoding='utf-8') as stream:
                    json.dump({'version':1,'request':wait['request'],'reason':reason,'url':target},stream)
                os.replace(temporary,request)
                ready=stage/('verification-ready-'+wait['request']+'.json')
                while not wait['cancel'].wait(.5) and not self.closed:
                    actor,fresh,current=self._verification_task(user,{'taskId':task['id']})
                    if (self._collection_binding(fresh)!=wait['binding']
                            or self._verified_scope(actor,fresh,current)!=context['scope']):return
                    active=self._verification_windows(actor,current)
                    if not active or active[0]['id']!=job['id']:raise ValueError('window_closed')
                    if not ready.exists():continue
                    if ready.is_symlink() or ready.stat().st_size>512:raise ValueError('readiness_invalid')
                    observed=json.loads(ready.read_text('ascii'))
                    if observed!={'version':1,'request':wait['request'],'state':'ready'}:raise ValueError('readiness_invalid')
                    latest=failed_page(directory,task['id'],self._verified_scope(actor,fresh,current),partition=self._source_receipt_partition(fresh))
                    if latest!=context:raise ValueError('receipt_changed')
                    ready.unlink();wait.update(state='checking',message='网页验证状态已变化，正在核对账号并继续原任务…')
                    self.resume_verified_acquisition(actor,{'taskId':task['id']},automatic=wait)
                    wait.update(state='resumed',message='验证已通过，原任务已继续。')
                    return
                wait.update(state='cancelled',message='验证等待已停止，原断点保留。')
            except Exception:
                if wait['cancel'].is_set():wait.update(state='cancelled',message='验证等待已停止，原断点保留。')
                else:wait.update(state='waiting_user',message='本次验证尚未核实，请在原网页完成验证；可用继续按钮手动核对一次。')
        thread=threading.Thread(target=worker,name='human-verification-'+task['id'],daemon=True)
        wait['thread']=thread;thread.start()

    def open_acquisition_verification(self,user,data):
        user,task,account=self._verification_task(user,data)
        result=self.open_account_verification(user,{'accountId':account['id']})
        self._watch_acquisition_verification(user,task,account)
        result['result'].update(taskId=task['id'],accountId=account['id'])
        return result

    def resume_verified_acquisition(self,user,data,*,automatic=None):
        user,task,account=self._verification_task(user,data)
        waits=getattr(self,'_verification_waits',{})
        if automatic is None and waits.get(task['id']):waits[task['id']]['cancel'].set()
        def continuation_guard():
            if automatic is not None and (automatic['cancel'].is_set() or waits.get(task['id']) is not automatic):
                raise PlatformRuntimeError('VERIFICATION_CANCELLED','验证等待已停止，原断点保留',409)
        continuation_guard()
        binding=self._collection_binding(task)
        # A confirmed handoff can survive a lost local response without a new probe.
        pages=self._verified_task_pages(user,task,account)
        if not pages:
            from core.xhs_verified_resume import failed_page
            directory=self.data_dir/'accounts'/user['tenant_id']/account['id']
            try:context=failed_page(directory,task['id'],self._verified_scope(user,task,account),partition=self._source_receipt_partition(task))
            except (OSError,ValueError,TypeError):context=None
            if context is None:
                raise PlatformRuntimeError('VERIFICATION_RECEIPT_REQUIRED','原失败页尚未确认，已保留断点，不会重复请求',409)
            if not self._verification_windows(user,account):
                # Reopen the same owned WebView profile after a human closed it;
                # never create an account or treat website login as verified.
                self.open_account_verification(user,{'accountId':account['id']})
            deadline=time.monotonic()+12
            while time.monotonic()<deadline:
                windows=self._verification_windows(user,account)
                if len(windows)==1 and windows[0].get('window_open') is True and windows[0].get('identity_capture_capable') is True:break
                self.service.stop_event.wait(.05)
            else:raise PlatformRuntimeError('VERIFICATION_WINDOW_OPENING','原账号网页正在打开，请保持网页打开后再次点继续；原任务已保留',409)
            self._commit_verified_browser(user,task,account,context,continuation_guard)
            fresh=self._task(self._principal(user),task['id']);account=self._account(user,fresh['account_id'])
            if self._collection_binding(fresh)!=binding:
                raise PlatformRuntimeError('TASK_SCOPE_CHANGED','原任务条件已变化，断点保留',409)
            pages=self._verified_task_pages(user,fresh,account)
        if not pages:
            raise PlatformRuntimeError('VERIFICATION_RECEIPT_REQUIRED','账号已核对，但原失败页尚未确认，保留断点，请联系管理员',409)
        with self._run_lock:
            continuation_guard()
            response=self.resume_acquisition(user,data)
        response['result'].update(accountId=account['id'])
        return response

    def account_job(self, user, data):
        user = self._principal(user)
        if type(data) is not dict or set(data) != {'jobId'}:
            raise PlatformRuntimeError('INVALID_INPUT','账号进度参数无效',400)
        owned=self._owned_job(user,data['jobId'])
        if owned.get('purpose')=='manual_verification':
            return {'result':self._verification_job_result(user,owned),**self.snapshot(user)}
        result=self._login_result(user,self.service.account_job_status(data['jobId']),data['jobId'])
        return {'result':result, **self.snapshot(user)}

    def cancel_account(self, user, data):
        user = self._principal(user)
        if type(data) is not dict or set(data) != {'jobId'}:
            raise PlatformRuntimeError('INVALID_INPUT','取消登录参数无效',400)
        self._owned_job(user,data['jobId'])
        result=self._login_result(user,self.service.cancel_account_login(data['jobId']),data['jobId'])
        return {'result':result, **self.snapshot(user)}

    def _login_result(self, user, value, ident=None):
        """Only the canonical owned job projection crosses the local gateway."""
        if not isinstance(value,dict):
            raise PlatformRuntimeError('LOGIN_RESULT_UNCONFIRMED','登录任务结果需刷新核对，请勿重复打开登录',503,mutation_committed=None)
        nested=value.get('login_job')
        if isinstance(nested,str):
            ident=nested
            self._owned_job(user,ident)
            value=self.service.account_job_status(ident)
        elif isinstance(nested,dict):
            ident=nested.get('id') or nested.get('job_id') or nested.get('jobId')
            value=nested
        else:
            ident=ident or value.get('id') or value.get('jobId')
        if not isinstance(ident,str) or not re.fullmatch(r'[A-Za-z0-9_-]{1,160}',ident):
            raise PlatformRuntimeError('LOGIN_RESULT_UNCONFIRMED','登录任务编号需刷新核对，请勿重复打开登录',503,mutation_committed=None)
        job=self._owned_job(user,ident)
        state=value.get('status',job.get('status','unknown'))
        state=state if state in ('pending','running','completed','cancelled','failed','ready','unknown') else 'unknown'
        phase=value.get('phase',job.get('phase',''))
        phase=phase if isinstance(phase,str) and re.fullmatch(r'[a-z0-9_]{1,80}',phase) else ''
        messages={'pending':'登录正在准备，请稍候','running':'请在弹出的平台窗口完成登录',
            'completed':'平台登录检查已完成，请核对账号状态','cancelled':'登录已取消，已有账号资料保留',
            'failed':'登录未完成，请核对弹出的平台窗口后手动重试','ready':'平台账号已核实',
            'unknown':'登录结果需核对，请先刷新原登录任务'}
        window_open=value.get('window_open') is True
        result={'id':ident,'accountId':job.get('account_id'),'status':state,'phase':phase,'message':messages[state],
                'windowOpen':window_open,'persistentBrowser':value.get('persistent_browser') is True}
        account=self._account(user,job.get('account_id'))
        identity_conflict=(state=='failed' and job.get('error_code')=='cloud_claim_failed'
            and account.get('platform')=='xiaohongshu' and account.get('status')=='duplicate_identity_remote')
        if identity_conflict:
            result['message']='网页登录已完成，但企业账号身份登记冲突，已暂停；请管理员核对原账号登记，无需重复扫码'
        elif state=='failed' and job.get('error_code')=='identity_mismatch':
            result['message']='网页登录的账号与本条记录绑定的账号不同；请登录原账号，或在新增账号条目连接新账号'
        elif window_open and state=='failed':
            result['message']='浏览器已保留，请完成网页登录或验证后，再点登录检查；不会另开窗口'
        elif window_open and state in ('running','pending'):
            result['message']='浏览器已保留，请在窗口完成本人登录或网页验证；无需赶时间'
        elif window_open and state=='completed':
            result['message']='平台登录检查已完成，浏览器保持打开；请核对账号状态'
        if state == 'running' and value.get('qr_ready') is True:
            image=self._owned_qr(job,ident)
            if image:
                result['qrUrl']=image
                result['message']='请使用平台手机应用扫描二维码，并在手机上确认登录'
        return result

    def _owned_qr(self, job, ident):
        # Caller has just rechecked the job's account/employee/device scope.
        # Never resolve a frontend path or return the stored private file path.
        if not re.fullmatch(r'[a-f0-9]{24,32}',ident):
            return None
        folder=self.data_dir/'work'
        expected=folder/(ident+'.png')
        if job.get('qr_path') != str(expected):
            return None
        try:
            for path in (folder,expected):
                attrs=path.lstat()
                if path.is_symlink() or getattr(attrs,'st_file_attributes',0) & getattr(stat,'FILE_ATTRIBUTE_REPARSE_POINT',0):
                    return None
            if expected.resolve().parent != folder.resolve() or not 32 < expected.stat().st_size <= 512*1024:
                return None
            content=expected.read_bytes()
            if not content.startswith(b'\x89PNG\r\n\x1a\n') or len(content)>512*1024:
                return None
            return 'data:image/png;base64,'+base64.b64encode(content).decode('ascii')
        except OSError:
            return None

    def _owned_job(self, user, ident):
        job = self.server.jobs.get(ident) if isinstance(ident,str) else None
        if not job or job.get('kind') != 'assistant_account_login':
            raise PlatformRuntimeError('JOB_NOT_FOUND','登录任务不存在或已经结束',404)
        self._account(user,job.get('account_id'))
        self._executor(user,online=False)
        return job

    def _execute(self, executor, user, action, data):
        allowed = {'account_create','account_status','task_save','task_run','task_stop','task_resume',
                   'continuous_start','continuous_resume','continuous_pause','continuous_status',
                   'reply_queue_send'}
        if action not in allowed:
            raise PlatformRuntimeError('ACTION_FORBIDDEN','此批次未开放该操作',403)
        if action=='task_run':
            control=self._run_cancels.get(data.get('task_id'))
            if control and control.get('analysis_stop') and control['analysis_stop'].is_set():
                raise PlatformRuntimeError('ANALYSIS_PENDING','分析已停止，评论和断点已保留',409)
        return executor({'owner':user['username'], 'principal':{'username':user['username'],'role':user['role']},
                         'action':action,'data':data})

    def livestream_guard(self,user,account_id):
        # No prepare/login/claim or browser action. Reuse the current employee
        # device/session and natural connection observation before any read.
        user=self._principal(user);executor=self._executor(user)
        account=self._account(user,account_id)
        if account.get('platform')!='douyin' or account.get('status')!='ready':
            raise PlatformRuntimeError('LIVE_ACCOUNT_NOT_READY','请先核对本人抖音账号连接',409)
        if not account.get('conn_id') or not re.fullmatch('[1-9][0-9]{0,19}',str(account.get('platform_uid') or '')):
            raise PlatformRuntimeError('LIVE_IDENTITY_REQUIRED','直播读取需要本人稳定身份与固定窗口',409)
        if any(row.get('id')!=account['id'] and row.get('platform')=='douyin' and row.get('platform_uid')==account['platform_uid'] for row in self.core.store.list('accounts',user['tenant_id'])):
            raise PlatformRuntimeError('LIVE_DUPLICATE_ACCOUNT','同一平台身份存在多条账号记录，请先核对',409)
        code,message=self._collection_readiness(user,account)
        if code:raise PlatformRuntimeError(code.upper(),message,409)
        self.server._platform_execution_guard('douyin')
        executor._guard_platform_qa_command('task_run',{'max_batches':1})
        return executor

    def dm_guard(self,user,account_id,*,for_send=False):
        # Reuse the original device/session/license/QA/account gates. This does
        # not create a grant, bypass a held profile, or add a new account mode.
        user=self._principal(user);executor=self._executor(user)
        account=self._account(user,account_id)
        if account.get('platform')!='douyin':
            raise PlatformRuntimeError('DM_PLATFORM_UNAVAILABLE','此平台私信传输尚未接通',422)
        if account.get('status')!='ready':
            raise PlatformRuntimeError('DM_ACCOUNT_NOT_READY','请先在账号页核对本人登录状态',409)
        code,message=self._readiness(user,account)
        if code:raise PlatformRuntimeError(code.upper(),message)
        self.server._platform_execution_guard(account['platform'])
        executor._guard_platform_qa_command('reply_queue_send' if for_send else 'task_run',{} if for_send else {'max_batches':1})
        if for_send:self.core._public_reply_guard(account['platform'])
        if not account.get('conn_id') or not re.fullmatch('[1-9][0-9]{0,24}',str(account.get('platform_uid') or '')):
            raise PlatformRuntimeError('DM_IDENTITY_REQUIRED','请先核对本人抖音稳定身份与固定窗口',409)
        return executor

    def reply_guard(self,user,account_id):
        user=self._principal(user)
        executor=self._executor(user)
        account=self._account(user,account_id)
        code,message=self._readiness(user,account)
        if code:raise PlatformRuntimeError(code.upper(),message)
        self.server._platform_execution_guard(account['platform'])
        executor._guard_platform_qa_command('reply_queue_send',{})
        self.core._public_reply_guard(account['platform'])
        executor._claim_xhs_account(account)
        return executor

    def start_reply_queue(self,user,queue_id):
        user=self._principal(user)
        queue=self.core._get('reply_queues',queue_id,user['tenant_id'])
        self.core.reviewed_reply_queues._access(queue,user)
        executor=self.reply_guard(user,queue['account_id'])
        return self._execute(executor,user,'reply_queue_send',{'queue_id':queue_id,'authorized':True})

    def _task_input(self, data):
        allowed = {'platform','accountId','keywords','region','city','area','dailyLimit','targetCount',
                   'commentDateRange','intentMode','dateFrom','dateTo','excludes','taskName','time','rentalAssessment','storeId','requestBinding',
                   'source','commentWindow','execution','previewDigest'}
        if type(data) is not dict or set(data) - allowed or not {'platform','accountId'} <= set(data):
            raise PlatformRuntimeError('INVALID_INPUT','采集条件需重新核对',400)
        source_config=None
        if 'source' in data:
            from core.acquisition_sources import normalize_config,capabilities
            source_config=normalize_config(data['platform'],data['source'],data.get('commentWindow'),data.get('execution'))
            if 'previewDigest' in data:
                from core.acquisition_sources import digest as source_hash
                if data['previewDigest']!=source_hash(source_config):
                    raise PlatformRuntimeError('SOURCE_PREVIEW_CHANGED','来源条件已变化，请重新解析确认',409,mutation_committed=False)
            if not capabilities(data['platform'])[source_config['kind']]['canStart']:
                raise PlatformRuntimeError('SOURCE_NOT_INTEGRATED','此来源可保存预设，受控读取尚未接通',422,mutation_committed=False)
            if not isinstance(data.get('storeId'),str) or not re.fullmatch('[A-Za-z0-9_-]{1,80}',data['storeId']):
                raise PlatformRuntimeError('INVALID_INPUT','请选择当前授权门店',400)
        elif any(key in data for key in ('commentWindow','execution','previewDigest')):
            raise PlatformRuntimeError('INVALID_INPUT','评论窗口和检查方式须绑定明确来源',400)
        if 'requestBinding' in data:
            if source_config is not None:
                from core.acquisition_sources import validate_source_binding as validate_binding
            else:from core.acquisition_receipts import validate_binding
            if not validate_binding(data['requestBinding'],{key:value for key,value in data.items() if key!='requestBinding'}):
                raise PlatformRuntimeError('INVALID_INPUT','采集操作回执绑定无效',400)
        if (data['platform'] not in self.server.company.get('platforms', []) or
                source_config is None and (not isinstance(data.get('keywords'),list) or not 1 <= len(data['keywords']) <= 100
                or any(not isinstance(word,str) or not 1 <= len(word.strip()) <= 80 for word in data['keywords']))):
            raise PlatformRuntimeError('INVALID_INPUT','请选择已开放平台和有效搜索词',400)
        daily_default=100 if data['platform']=='xiaohongshu' else 20
        for key,default,maximum in (('dailyLimit',daily_default,1000),('targetCount',100,10000)):
            number=data.get(key,default)
            if type(number) is not int or not 1 <= number <= maximum:
                raise PlatformRuntimeError('INVALID_INPUT','采集数量范围无效',400)
        for key in ('region','city','area','taskName'):
            if key in data and (not isinstance(data[key],str) or len(data[key])>100 or any(ord(char)<32 for char in data[key])):
                raise PlatformRuntimeError('INVALID_INPUT','采集条件格式无效',400)
        if data.get('intentMode','all') not in ('all','AB','A'):
            raise PlatformRuntimeError('INVALID_INPUT','意向筛选范围无效',400)
        context = data.get('rentalAssessment')
        if context is not None and (not isinstance(context, dict)
                or set(context) != {'enabled','storeId','ruleVersion','materialKey'}
                or context['enabled'] is not True
                or not isinstance(context['storeId'],str)
                or not re.fullmatch(r'[A-Za-z0-9_-]{1,80}',context['storeId'])
                or not isinstance(context['ruleVersion'],str) or not 1<=len(context['ruleVersion'])<=160
                or context['materialKey'] is not None and (not isinstance(context['materialKey'],str)
                    or not 1<=len(context['materialKey'])<=160)):
            raise PlatformRuntimeError('INVALID_INPUT','租房判断上下文需重新核对',400)
        excludes=data.get('excludes',[])
        if not isinstance(excludes,list) or any(not isinstance(word,str) or len(word)>100 for word in excludes):
            raise PlatformRuntimeError('INVALID_INPUT','排除词需为文本列表',400)
        date_from, date_to = data.get('dateFrom',''), data.get('dateTo','')
        if 'time' in data and source_config is None:
            selected = data['time']
            if selected == '24h':
                raise PlatformRuntimeError('TIME_PRECISION_UNAVAILABLE', '当前采集组件按日期筛选，暂不能精确筛选过去24小时，请选择近7天、30天或90天', 422)
            if selected not in ('3d','7d','30d','90d','all'):
                raise PlatformRuntimeError('TIME_RANGE_INVALID','此时间范围尚未接入，请重新选择',400)
            if selected != 'all':
                today = datetime.now(timezone(timedelta(hours=8))).date()
                date_from = (today - timedelta(days=int(selected[:-1])-1)).isoformat()
                date_to = today.isoformat()
            else:
                date_from = date_to = ''
        try:
            if date_from:
                datetime.strptime(date_from,'%Y-%m-%d')
            if date_to:
                datetime.strptime(date_to,'%Y-%m-%d')
            if date_from and date_to and date_from>date_to:
                raise ValueError('range')
        except (TypeError,ValueError):
            raise PlatformRuntimeError('INVALID_INPUT','采集时间范围无效',400) from None
        if source_config is not None:date_from=date_to=''
        task={'name':data.get('taskName') or ({'note_links':'指定帖子评论采集','profiles':'指定博主评论采集','own_interactions':'本人互动检查'}[source_config['kind']] if source_config is not None else '工作台关键词采集'), 'platform':data['platform'],
            'account_id':data['accountId'],'keywords':[] if source_config is not None else list(dict.fromkeys(word.strip() for word in data['keywords'])),
            'scope':'comments' if source_config is not None else 'search_comments','continuous_enabled':False,'comment_keyword_mode':'all','unknown_policy':'exclude',
            'daily_limit':data.get('dailyLimit',daily_default),
            'target_count':data.get('targetCount',100),'comment_date_range':'all' if source_config is not None else data.get('commentDateRange','all'),
            'region':'','city':data.get('city',''),'area':data.get('area',''),
            'date_from':date_from,'date_to':date_to,
            'excludes':data.get('excludes',[]),'intent_mode':data.get('intentMode','all')}
        if source_config is not None:
            if source_config['kind']=='note_links':task['note_url']=source_config['items'][0]['url']
            else:task['source_kind']=source_config['kind']
        return task

    def resolve_source_input(self,user,data):
        user=self._principal(user)
        if type(data) is not dict or set(data)-{'storeId','platform','accountId','source','commentWindow','execution'}:
            raise PlatformRuntimeError('INVALID_INPUT','来源预览参数无效',400)
        if data.get('storeId')!=user.get('_workbench_store_id'):
            raise PlatformRuntimeError('SOURCE_SCOPE_CHANGED','请先选择当前授权门店',403)
        account=self._account(user,data.get('accountId'))
        if account.get('store_id')!=data['storeId'] or account.get('platform')!=data.get('platform'):
            raise PlatformRuntimeError('SOURCE_SCOPE_CHANGED','请选择当前门店的平台账号',403)
        value=deepcopy(data)
        if type(data.get('source')) is dict and data['source'].get('kind')=='preset':
            from core.acquisition_sources import resolve_preset
            with self.core.lock:
                value.update(resolve_preset(self.core.store,user,data['storeId'],data['platform'],data['accountId'],
                    data['source'],data.get('commentWindow'),data.get('execution')))
        return value

    def source_preview(self,user,data):
        value=self.resolve_source_input(user,data)
        from core.acquisition_sources import preview_config
        return preview_config(value.get('platform'),value.get('source'),value.get('commentWindow'),value.get('execution'))

    def save_source_preset(self,user,data,authority_check=None):
        return self._source_configuration(user,data,schedule=False,save=True,authority_check=authority_check)

    def list_source_presets(self,user,data):
        return self._source_configuration(user,data,schedule=False,save=False)

    def save_source_schedule(self,user,data,authority_check=None):
        return self._source_configuration(user,data,schedule=True,save=True,authority_check=authority_check)

    def list_source_schedules(self,user,data):
        return self._source_configuration(user,data,schedule=True,save=False)

    def _source_configuration(self,user,data,*,schedule,save,authority_check=None):
        user=self._principal(user)
        if (type(data) is not dict or data.get('storeId')!=user.get('_workbench_store_id')
                or not isinstance(data.get('storeId'),str) or not re.fullmatch('[A-Za-z0-9_-]{1,80}',data['storeId'])
                or not save and (set(data)-{'storeId','requestId'} or 'storeId' not in data)):
            raise PlatformRuntimeError('SOURCE_SCOPE_CHANGED','请先选择当前授权门店',403)
        from core.acquisition_sources import save_configuration,list_configurations,read_configuration_receipt
        with self.core.lock:
            if save:return save_configuration(self.core.store,user,data['storeId'],data,schedule=schedule,authority_check=authority_check)
            result={'items':list_configurations(self.core.store,user,data['storeId'],schedule=schedule),
                'automaticExecution':False}
            if 'requestId' in data:result['receipt']=read_configuration_receipt(self.core.store,user,data['storeId'],data['requestId'],schedule=schedule)
            return result

    def run_scheduled_source_page(self,user,spec,ident,session_grant,bind_task):
        # One original guarded task batch; no new runner, CLI, login or model.
        from core.acquisition_sources import PRESETS,digest,load_plan
        from core.source_scheduler import account_binding
        from core.acquisition_extension_runtime import source_scan,next_interaction_scan
        actor=self._principal(user);executor=self._executor(actor)
        def guard():
            fresh=self._principal(session_grant())
            if (any(fresh.get(k)!=actor.get(k) for k in ('id','tenant_id','username','role','_workbench_store_id'))
                    or fresh.get('_workbench_store_id')!=spec['store'] or self._executor(fresh) is not executor):
                raise PlatformRuntimeError('SOURCE_SESSION_CHANGED','员工或设备会话已变化',403)
            account=self._account(fresh,spec['account'])
            preset=self.core.store.get(PRESETS,spec['preset'])
            if (account_binding(account)!=spec['account_binding'] or account.get('status')!='ready'
                    or account.get('requires_review') or not preset or preset.get('version')!=spec['preset_version']
                    or digest(preset.get('config'))!=spec['config_digest']
                    or (preset.get('tenant_id'),preset.get('owner'),preset.get('store_id'),preset.get('account_id'))!=
                        (fresh['tenant_id'],fresh['username'],spec['store'],spec['account'])):
                raise PlatformRuntimeError('SOURCE_EXECUTION_CHANGED','原预设或账号已变化，请重新确认',409)
            code,message=self._collection_readiness(fresh,account)
            if code:raise PlatformRuntimeError(code.upper(),message)
            self.server._platform_execution_guard('xiaohongshu')
            return fresh
        with self._run_lock:
            guard()
            if any(t.is_alive() for t in self._runs.values()) or self.core.running or self.core.sequences:
                raise PlatformRuntimeError('COLLECTION_BUSY','已有采集正在处理，定期检查已暂停',409)
            task=self.core.store.get('tasks',ident) if ident else None
            if ident and task is None:
                raise PlatformRuntimeError('SOURCE_TASK_UNCONFIRMED','原任务尚未核对，原编号保留；不会另建任务',409)
            if task is None:
                values=self.resolve_source_input(actor,{'storeId':spec['store'],'platform':spec['platform'],
                    'accountId':spec['account'],'source':{'kind':'preset','id':spec['preset'],'version':spec['preset_version']},'execution':{'mode':'once'}})
                payload=self._task_input(values)
                bind_task(None)
                saved=self._execute(executor,actor,'task_save',payload)
                ident=saved['id'];bind_task(ident)
                task=self.core._get('tasks',ident,actor['tenant_id']);task['store_id']=spec['store'];self.core.store.put('tasks',task)
                self._install_source_plan(actor,saved,values)
            task=self._task(actor,ident);plan=load_plan(self.core.store,task)
            if (task.get('account_id')!=spec['account'] or task.get('store_id')!=spec['store']
                    or digest(plan['config'])!=spec['config_digest'] or task.get('status')=='paused'):
                raise PlatformRuntimeError('SOURCE_TASK_CONFIRMATION_REQUIRED','请先在原任务核对暂停或条件变化，断点保留',409)
            if task.get('exhausted') and task.get('source_kind')=='own_interactions':
                task=next_interaction_scan(self.core.store,task,plan,source_scan(task)+1,guard)
            guard();before=self._collection_lead_snapshot(actor,ident,executor)
            control={'event':threading.Event(),'attempt':uuid4().hex,'binding':self._collection_binding(task),'recover_unsent':False,'verified_retry':{},'source_schedule_guard':guard}
            self._run_cancels[ident]=control;executor._explicit_task_ids.add(ident);cli_pages=None
            try:
                cli_pages=self._begin_cli_pages(executor,actor,ident,control)
                guard();result=self._execute(executor,actor,'task_run',{'task_id':ident,'max_batches':1})
                summary=result.get('summary') if isinstance(result,dict) else None
                if (not isinstance(summary,dict) or result.get('status') not in ('stopped','completed')
                        or type(summary.get('exhausted')) is not bool or type(summary.get('can_continue')) is not bool
                        or not (summary['exhausted'] or summary['can_continue'])):
                    raise PlatformRuntimeError('SOURCE_RESULT_UNCONFIRMED','原读取结果待核对，不会自动重派',503)
                # Original Core has already saved page/cursor. Queue analysis
                # through the original journal; the scheduler never calls AI.
                guard();self._queue_collection_analysis(actor,ident,self._new_collection_lead_ids(actor,ident,executor,before))
                return {'exhausted':summary['exhausted'],'kind':plan['config']['kind']}
            finally:
                if cli_pages is not None:cli_pages.end_xhs_cli_pages(ident)
                mode=control.get('collection_mode')
                runtime=self.core.adapters.xhs_page_runtime
                if mode and (runtime is None or not runtime.has_pending_batch(ident)):
                    self.core.release_account_mode(*mode)
                if self._run_cancels.get(ident) is control:self._run_cancels.pop(ident,None)

    def _install_source_plan(self,user,saved,data):
        if 'source' not in data:return
        from core.acquisition_sources import normalize_config,install_plan
        try:
            with self.core.lock:
                task=self.core._get('tasks',saved['id'],user['tenant_id'])
                self.core._task_access(user,task,user['tenant_id'])
                if data.get('storeId')!=user.get('_workbench_store_id'):
                    raise PlatformRuntimeError('SOURCE_SCOPE_CHANGED','当前门店已变化，任务未启动',403)
                # The task was just validated by the original BusinessExecutor.
                # Its source reference and private plan commit together next.
                if not task.get('store_id'):
                    task['store_id']=data['storeId'];self.core.store.put('tasks',task)
                config=normalize_config(data['platform'],data['source'],data.get('commentWindow'),data.get('execution'))
                return install_plan(self.core.store,task,user,config,(data.get('requestBinding') or {}).get('created_at'))
        except Exception:
            with self.core.lock:
                current=self.core.store.get('tasks',saved['id'])
                if current and current.get('tenant_id')==user['tenant_id'] and current.get('cloud_owner')==user['username']:
                    current.update(status='paused',pause_reason='source_plan_unconfirmed')
                    self.core.store.put('tasks',current)
            error=PlatformRuntimeError('SOURCE_PLAN_UNCONFIRMED','任务已保存，来源快照未确认；请核对原任务，不要重复开始',503,mutation_committed=True)
            error.task_id=saved['id'];raise error from None

    def task_save(self, user, data):
        user = self._principal(user)
        task = self._task_input(data)
        executor = self._executor(user)
        account = self._account(user,task['account_id'])
        if 'source' in data and (data['storeId']!=user.get('_workbench_store_id')
                or account.get('store_id')!=data['storeId'] or account.get('cloud_owner')!=user['username']):
            raise PlatformRuntimeError('SOURCE_SCOPE_CHANGED','请选择当前员工和门店的采集账号',403,mutation_committed=False)
        code,message=self._readiness(user,account)
        if code:
            raise PlatformRuntimeError(code.upper(),message)
        saved=self._execute(executor,user,'task_save',task)
        self._install_source_plan(user,saved,data)
        return {'result':{'taskId':saved['id'],'status':'ready','accepted':False}, **self.snapshot(user)}

    def start_acquisition(self, user, data):
        user = self._principal(user)
        task = self._task_input(data)
        if 'source' in data and 'requestBinding' not in data:
            raise PlatformRuntimeError('SOURCE_BINDING_REQUIRED','请先解析确认来源，再从工作台开始',400,mutation_committed=False)
        self._prepare_for_connection(user)
        executor = self._executor(user)
        account = self._account(user,task['account_id'])
        if 'source' in data and (data['storeId']!=user.get('_workbench_store_id')
                or account.get('store_id')!=data['storeId'] or account.get('cloud_owner')!=user['username']):
            raise PlatformRuntimeError('SOURCE_SCOPE_CHANGED','请选择当前员工和门店的采集账号',403,mutation_committed=False)
        code, message = self._collection_readiness(user,account)
        if code:
            raise PlatformRuntimeError(code.upper(),message)
        if account.get('status') != 'ready':
            raise PlatformRuntimeError('ACCOUNT_NOT_READY','请先连接并核实平台账号')
        with self._run_lock:
            if any(thread.is_alive() for thread in self._runs.values()):
                raise PlatformRuntimeError('COLLECTION_BUSY','已有采集正在处理，请先暂停或等待本批结束')
            saved = self._execute(executor,user,'task_save',task)
            if data.get('storeId'):
                with self.core.lock:
                    record=self.core._get('tasks',saved['id'],user['tenant_id'])
                    record['store_id']=data['storeId']
                    self.core.store.put('tasks',record)
            self._install_source_plan(user,saved,data)
            if data.get('rentalAssessment'):
                self._remember_rental_context(user, saved['id'], data['rentalAssessment'])
            if data.get('requestBinding'):
                from core.acquisition_receipts import ENTITY
                if 'source' in data:
                    from core.acquisition_sources import prepared_source_receipt as prepared_receipt
                else:from core.acquisition_receipts import prepared_receipt
                try:
                    with self.core.lock:
                        task_record=self._task(user,saved['id'])
                        self.core.store.put(ENTITY,prepared_receipt(user,task_record,data['requestBinding']))
                except Exception:
                    error=PlatformRuntimeError('COLLECTION_RESULT_UNCONFIRMED','任务已保存，回执绑定尚未确认；请核对原任务',503,mutation_committed=True)
                    error.task_id=saved['id'];raise error from None
            return self._start_task(executor,user,saved['id'])

    def _remember_rental_context(self, user, task_id, values):
        """Host-supplied context from its freshly authorized store selection.

        The HTTP gateway never accepts this field from a client. The material
        key is provenance, not permission; only the host's opaque store ID is
        attached to a newly saved task belonging to this employee.
        """
        task=self._task(user,task_id)
        context={'id':task_id,'tenant_id':user['tenant_id'],'owner':user['username'],
            'store_id':values['storeId'],'rule_version':values['ruleVersion'],
            'material_key':values['materialKey'],'enabled':True,'assessment_status':'pending',
            'created_at':datetime.now(timezone.utc).isoformat()}
        try:
            with self.core.lock,self.core.store.connect() as db:
                db.execute('BEGIN IMMEDIATE')
                fresh=db.execute('SELECT body FROM records WHERE entity=? AND id=? AND tenant_id=?',
                    ('tasks',task_id,user['tenant_id'])).fetchone()
                if not fresh:
                    raise PlatformRuntimeError('TASK_FORBIDDEN','任务归属已变化',403)
                task=json.loads(fresh['body'])
                self.core._task_access(user,task,user['tenant_id'])
                task['store_id']=values['storeId']
                for entity,record in (('tasks',task),('rental_task_context_v1',context)):
                    db.execute('INSERT OR REPLACE INTO records VALUES(?,?,?,?)',
                        (entity,record['id'],user['tenant_id'],json.dumps(record,ensure_ascii=False,allow_nan=False)))
        except Exception:
            error=PlatformRuntimeError('RENTAL_CONTEXT_UNCONFIRMED','任务已保存，判断上下文未确认；请核对原任务，不要重复采集',503,mutation_committed=True)
            error.task_id=task_id
            raise error from None

    def _collection_failure_facts(self, error):
        """Bounded facts from exact loaded code objects; never serialize an error."""
        facts={'stage':'unknown','code':'unknown','exception_kind':'unknown',
            'connection_state':'unknown','platform_login_confirmed':None,'binding_verified':None}
        from core.platform_failure import validated
        platform_error=validated(getattr(error,'platform_error',None)) if type(error) is PlatformRuntimeError else None
        if platform_error:
            return {**facts,'stage':'platform','code':platform_error['cli_code'],
                'exception_kind':'PlatformRuntimeError','platform_error':platform_error}
        kinds={ValueError:'ValueError',RuntimeError:'RuntimeError',TypeError:'TypeError',
            KeyError:'KeyError',AttributeError:'AttributeError',OSError:'OSError'}
        source=self.project/'work/ui-runtime-r55/src'
        specs=(
            ('assistant.business',DIRECTORY/'vendor-src/assistant/business.py',
                (('BusinessExecutor._execute','executor_dispatch'),('BusinessExecutor._verify_first_douyin_search','douyin_preflight'))),
            ('assistant.douyin_connection_service',DIRECTORY/'vendor-src/assistant/douyin_connection_service.py',
                (('DouyinConnectionService.execute','connection_status'),('_binding','connection_binding'),
                 ('_components','connection_components'),('_DouyinConnectionCall.check','connection_scope'),
                 ('_DouyinConnectionCall.owned_connection','connection_owned_window'))),
            ('account_connections',DIRECTORY/'vendor-src/account_connections.py',
                (('AccountConnections.status','connection_status'),('verify_douyin','connection_identity'))),
            ('assistant.service',DIRECTORY/'vendor-src/assistant/service.py',(('AssistantService._local_user','device_identity'),)),
            ('assistant.xhs_app_context',source/'assistant/xhs_app_context.py', (('_DeviceSession.check','device_session'),)),
            ('core.engine',source/'core/engine.py',(('Core._handle','core_admission'),('Core._run_sequence','core_sequence'))),
            ('core.adapters',source/'core/adapters.py',(('Adapters.manifest','adapter_manifest'),)),
        )
        codes={};dy_code=None
        for name,path,methods in specs:
            module=sys.modules.get(name)
            if module is None or Path(getattr(module,'__file__','')).resolve()!=path.resolve():
                continue
            for attr,stage in methods:
                value=module
                for part in attr.split('.'):
                    value=getattr(value,part,None)
                code=getattr(value,'__code__',None)
                if code is not None:
                    codes[code]=stage
                    if stage=='douyin_preflight':dy_code=code
            for attr in ('CoreError','AdapterBusy','AppContextRequired'):
                kind=getattr(module,attr,None)
                if isinstance(kind,type) and kind.__name__==attr:
                    kinds[kind]=attr
        facts['exception_kind']=kinds.get(type(error),'unknown')
        trace=error.__traceback__
        for _ in range(64):
            if trace is None:break
            frame=trace.tb_frame;code=frame.f_code
            if code in codes:facts['stage']=codes[code]
            if code is dy_code:
                state=frame.f_locals.get('state')
                if type(state) is dict:
                    value=state.get('state')
                    if type(value) is str and value in ('ready','waiting_login','checking','choose_window','failed','disconnected'):
                        facts['connection_state']=value
                    for key in ('platform_login_confirmed','binding_verified'):
                        value=state.get(key)
                        facts[key]=value if type(value) is bool else None
            trace=trace.tb_next
        if facts['stage']=='douyin_preflight':
            facts['code']={'waiting_login':'dy_login_unconfirmed','checking':'dy_connection_checking',
                'choose_window':'dy_window_unconfirmed','failed':'dy_connection_failed',
                'disconnected':'dy_connection_disconnected'}.get(facts['connection_state'],'unknown')
            if facts['connection_state']=='ready' and any(facts[key] is False for key in ('platform_login_confirmed','binding_verified')):
                facts['code']='dy_identity_unconfirmed'
        return facts

    @staticmethod
    def _collection_platform_error(task):
        from core.platform_failure import validated
        return validated(task.get('last_platform_error')) if task else None

    def _collection_diagnostic(self, user, ident, attempt, *, error=None, clear=False):
        # This private entity is not in Core's public entity/API allowlist.
        # Diagnostics are best effort and cannot replace a collection guard.
        try:
            facts=self._collection_failure_facts(error) if error is not None else None
            with self.core.lock:
                actor=self._principal(user)
                self._task(actor,ident)
                old=self.core.store.get(_COLLECTION_DIAGNOSTIC_ENTITY,ident)
                scope=(actor['tenant_id'],actor['username'],ident)
                if old and tuple(old.get(key) for key in ('tenant_id','owner','task_id'))!=scope:
                    return
                if error is not None or clear:
                    if not old or old.get('attempt_id')!=attempt:return
                    if clear:
                        self.core.store.delete(_COLLECTION_DIAGNOSTIC_ENTITY,ident)
                        return
                elif old:
                    # Do not retain the previous failure if a new receipt
                    # cannot be written; unavailable is safer than stale.
                    self.core.store.delete(_COLLECTION_DIAGNOSTIC_ENTITY,ident)
                record={'id':ident,'tenant_id':scope[0],'owner':scope[1],'task_id':ident,'attempt_id':attempt,
                    'state':'failed' if facts else 'running','updated_at':datetime.now(timezone.utc).isoformat(),
                    **(facts or {'stage':'unknown','code':'unknown','exception_kind':'unknown',
                        'connection_state':'unknown','platform_login_confirmed':None,'binding_verified':None})}
                self.core.store.put(_COLLECTION_DIAGNOSTIC_ENTITY,record)
        except Exception:
            pass

    @staticmethod
    def _collection_now():
        return time.monotonic()

    def _begin_cli_pages(self,executor,user,ident,control):
        task=self._task(self._principal(user),ident)
        if task.get('platform')!='xiaohongshu':return None
        adapters=self.core.adapters
        start=getattr(adapters,'begin_xhs_cli_pages',None)
        if not callable(start):return None
        original=self._account(user,task['account_id'])
        identity=tuple(original.get(k) for k in ('id','tenant_id','cloud_owner','store_id','platform','platform_uid'))
        def guard():
            if callable(control.get('source_schedule_guard')):control['source_schedule_guard']()
            if self.closed or control['event'].is_set() or control.get('analysis_stop') and control['analysis_stop'].is_set():
                raise PlatformRuntimeError('TASK_PAUSED','本次采集已停止，保留断点')
            actor=self._principal(user);current=self._task(actor,ident)
            if current.get('status')=='paused' or self._collection_binding(current)!=control['binding']:
                raise PlatformRuntimeError('TASK_SCOPE_CHANGED','原任务条件已变化，采集停止')
            if self._executor(actor) is not executor:raise PlatformRuntimeError('DEVICE_CHANGED','本机执行身份已变化')
            account=self._account(actor,current['account_id'])
            if tuple(account.get(k) for k in ('id','tenant_id','cloud_owner','store_id','platform','platform_uid'))!=identity:
                raise PlatformRuntimeError('ACCOUNT_SCOPE_CHANGED','原采集账号已变化')
            if control.get('verified_retry') and any(account.get(k)!=original.get(k) for k in ('auth_generation','identity_revalidation_generation')):
                raise PlatformRuntimeError('ACCOUNT_SCOPE_CHANGED','验证后的账号会话已变化，采集停止')
            code,message=self._collection_readiness(actor,account)
            if code:raise PlatformRuntimeError(code.upper(),message)
            from assistant.business import private_task_binding
            if isinstance(current.get('strategy_source'),dict):
                latest=executor._strategy_tasks().guard_task_action(ident,'task_run',{'task_id':ident,'max_batches':1},actor)
                if private_task_binding(latest)!=private_task_binding(current):
                    raise PlatformRuntimeError('TASK_SCOPE_CHANGED','原策略或账号已变化，采集停止')
            self.server._platform_execution_guard('xiaohongshu')
            executor._guard_platform_qa_command('task_run',{'task_id':ident,'max_batches':1})
            owner='batch:'+ident
            from core import CoreError
            try:self.core.acquire_account_mode(account['id'],actor['tenant_id'],'collection',owner)
            except CoreError as error:
                error._account_mode_blocked=True
                raise
            control['collection_mode']=(account['id'],actor['tenant_id'],owner)
        scope=self._verified_scope(user,task,original)
        directory=self.core.store.directory/'accounts'/user['tenant_id']/task['account_id']
        from assistant.browser_session_commit import account_revision
        if any(grant.get('account_revision')!=account_revision(original) for grant in (control.get('verified_retry') or {}).values()):
            raise PlatformRuntimeError('ACCOUNT_SCOPE_CHANGED','验证后的账号状态已变化，请保留原任务',409)
        start(ident,directory,scope,guard,recover_unsent=control.get('recover_unsent') is True,verified_retry=control.get('verified_retry'),receipt_partition=self._source_receipt_partition(task))
        return adapters

    def _bounded_collection(self, executor, user, ident, control):
        """Continue confirmed pages to the real task boundary, grading each page.

        Original per-request pacing, cancellation and admission checks remain.
        Page size, elapsed time and duplicate-only pages do not finish a range.
        An uncertain result or a cursor that does not advance is never replayed.
        """
        receipt={'id':ident,'tenant_id':user['tenant_id'],'owner':user['username'],
            'attempt_id':control['attempt'],'binding':control['binding'],
            'pages':0,'units':0,'status':'running','stop_reason':'running','core_run_id':None,
            'counts':{**dict.fromkeys(_COLLECTION_REQUIRED_COUNTS,0),
                **dict.fromkeys(_COLLECTION_SOURCE_COUNTS,0)},
            'created_at':datetime.now(timezone.utc).isoformat()}
        with self.core.lock:
            previous=self.core.store.get(_COLLECTION_RUN_ENTITY,ident)
            if (previous and previous.get('tenant_id')==user['tenant_id'] and previous.get('owner')==user['username']
                    and previous.get('binding')==control['binding']
                    and type(previous.get('counts')) is dict
                    and all(type(previous['counts'].get(k)) is int and previous['counts'][k]>=0 for k in _COLLECTION_REQUIRED_COUNTS)
                    and all(type(previous.get(k)) is int and previous[k]>=0 for k in ('pages','units'))):
                receipt.update(counts={**{key:previous['counts'][key] for key in _COLLECTION_REQUIRED_COUNTS},
                    **_safe_source_counts(previous['counts'])},pages=previous['pages'],units=previous['units'],
                    created_at=previous.get('created_at',receipt['created_at']),attempt_started_at=receipt['created_at'])
        def save():
            with self.core.lock:
                current=self._task(self._principal(user),ident)
                if self._collection_binding(current)!=control['binding']:
                    raise PlatformRuntimeError('TASK_SCOPE_CHANGED','原任务条件已变化，采集停止；断点保留')
                progress=self.core.task_progress(ident) or {}
                summary=(current.get('last_result') or {}).get('summary') or {}
                receipt['core_run_id']=progress.get('run_id') or summary.get('run_id')
                receipt['updated_at']=datetime.now(timezone.utc).isoformat()
                self.core.store.put(_COLLECTION_RUN_ENTITY,deepcopy(receipt))
        save()
        wake=threading.Event();finished=threading.Event();errors=[]
        control['analysis_stop']=threading.Event()
        def analyze_saved():
            try:
                while not control['event'].is_set() and not control['analysis_stop'].is_set() and not self.closed:
                    with self.core.lock:
                        current=self._task(self._principal(user),ident)
                        queued=self._pending_collection_analysis(user,current)
                    if queued:
                        self._drain_collection_analysis(executor,user,ident)
                        continue
                    if finished.is_set():return
                    wake.wait(.1);wake.clear()
            except BaseException as error:
                errors.append(error);control['analysis_stop'].set()
        worker=None;cli_pages=None
        try:
            cli_pages=self._begin_cli_pages(executor,user,ident,control)
            # Explicit resume reconciles the saved journal first. Only the new
            # pages of this exact task enter its one analysis worker.
            try:
                self._drain_collection_analysis(executor,user,ident,reconcile=control.get('recover_unsent') is True)
            except PlatformRuntimeError as error:
                if control.get('recover_unsent') is not True or error.code not in _COLLECTION_ANALYSIS_HOLD_CODES:
                    raise
                # Explicit continuation can save new pages while this exact
                # analysis remains held. It never clears or repeats the request.
                control['analysis_hold']=True;receipt['analysis_hold']=True
                save()
            if not control.get('analysis_hold'):
                worker=threading.Thread(target=analyze_saved,name='task-analysis-'+ident,daemon=True)
                worker.start()
            while True:
                if errors:raise errors[0]
                with self._run_lock:
                    actor=self._principal(user)
                    task=self._task(actor,ident)
                    if control['event'].is_set() or task.get('status')=='paused' or self.closed:
                        receipt.update(status='paused',stop_reason='user_paused');break
                    if (task.get('exhausted') or type(task.get('accumulated')) is int
                            and type(task.get('target_count')) is int
                            and task['accumulated']>=task['target_count']):
                        receipt.update(status='completed',stop_reason='range_exhausted');break
                    if (self._collection_binding(task)!=control['binding']
                            or not self._current_comment_policy(task)):
                        raise PlatformRuntimeError('TASK_SCOPE_CHANGED','原任务条件已变化，采集停止；断点保留')
                    if self._executor(actor) is not executor:
                        raise PlatformRuntimeError('DEVICE_CHANGED','本机执行身份已变化，采集停止')
                    account=self._account(actor,task.get('account_id'))
                    code,message=self._collection_readiness(actor,account)
                    if code:raise PlatformRuntimeError(code.upper(),message)
                    if control.get('analysis_hold') and self._collection_analysis_backlog(actor,ident)>=200:
                        receipt.update(status='paused',stop_reason='analysis_backlog');break
                    before=self._collection_checkpoint(task)
                # A pause between the check and Core admission writes paused to
                # the original task. Core rechecks it before creating a sequence
                # and before reading. No automatic resume runs between pages.
                if control['event'].is_set():
                    receipt.update(status='paused',stop_reason='user_paused');break
                before_leads=self._collection_lead_snapshot(actor,ident,executor)
                result=self._execute(executor,actor,'task_run',{'task_id':ident,'max_batches':1})
                summary=result.get('summary') if type(result) is dict else None
                from core.platform_failure import validated,message
                platform_error=validated(summary.get('platform_error')) if type(summary) is dict else None
                if platform_error and result.get('status')=='failed':
                    error=PlatformRuntimeError('PLATFORM_READ_FAILED',message(platform_error),503)
                    error.platform_error=platform_error
                    raise error
                if (not isinstance(summary,dict) or result.get('status') not in ('stopped','completed')
                        or any(type(summary.get(key)) is not int or summary[key]<0
                               for key in _COLLECTION_REQUIRED_COUNTS)
                        or type(summary.get('can_continue')) is not bool
                        or type(summary.get('exhausted')) is not bool):
                    raise PlatformRuntimeError('COLLECTION_RESULT_UNCONFIRMED',
                        '本页结果未确认，已停止；不会自动重复读取')
                for key in _COLLECTION_REQUIRED_COUNTS:receipt['counts'][key]+=summary[key]
                for key,value in _safe_source_counts(summary).items():
                    receipt['counts'][key]=min(_MAX_SAFE_COUNT,receipt['counts'][key]+value)
                receipt['pages']+=summary.get('platform_pages',1)
                receipt['units']+=1
                # Persist the confirmed page before analysis. If analysis fails,
                # its imported rows and cursor remain; no page is submitted twice.
                save()
                page_ids=self._new_collection_lead_ids(actor,ident,executor,before_leads)
                self._queue_collection_analysis(actor,ident,page_ids,hold=control.get('analysis_hold') is True)
                wake.set()
                # Bound the durable backlog without coupling each page to a model call.
                while not control['event'].is_set() and not self.closed:
                    if errors:raise errors[0]
                    with self.core.lock:
                        pending=self._pending_collection_analysis(self._principal(actor),self._task(actor,ident))
                    if control.get('analysis_hold'):
                        if self._collection_analysis_backlog(actor,ident)>=200:
                            receipt.update(status='paused',stop_reason='analysis_backlog')
                        break
                    if len((pending or {}).get('lead_ids',[]))<200:break
                    control['event'].wait(.05)
                with self.core.lock:
                    task=self._task(self._principal(user),ident)
                    after=self._collection_checkpoint(task)
                if control['event'].is_set() or task.get('status')=='paused':
                    receipt.update(status='paused',stop_reason='user_paused')
                elif summary['exhausted'] or result['status']=='completed':
                    receipt.update(status='completed',stop_reason=summary.get('stop_reason','range_exhausted'))
                elif not summary['can_continue']:
                    receipt.update(status='stopped',stop_reason=summary.get('stop_reason','not_resumable'))
                elif before==after:
                    receipt.update(status='stopped',stop_reason='no_progress')
                save()
                if receipt['status']!='running':break
                # Space confirmed collection units without simulating unrelated
                # browsing, modifying identity or replaying a failed request.
                until=time.time()+5
                receipt['next_read_at']=datetime.fromtimestamp(until,timezone.utc).isoformat()
                save()
                if not wait_for_collection_slot(control['event'],until):
                    receipt.update(status='paused',stop_reason='user_paused');break
                receipt.pop('next_read_at',None)
                save()
            finished.set();wake.set()
            if worker is not None:worker.join()
            if errors:raise errors[0]
            save()
        except BaseException:
            receipt.update(status='paused' if control['event'].is_set() else 'failed',
                stop_reason='user_paused' if control['event'].is_set() else 'execution_failed')
            try:save()
            except Exception:pass
            raise
        finally:
            # Parent run remains alive (and owns the workspace lock) until the
            # original in-flight attempt has saved or recorded uncertainty.
            control['analysis_stop'].set();finished.set();wake.set()
            if worker is not None:worker.join()
            if cli_pages is not None:cli_pages.end_xhs_cli_pages(ident)
            mode=control.get('collection_mode')
            runtime=self.core.adapters.xhs_page_runtime
            if mode and (runtime is None or not runtime.has_pending_batch(ident)):
                self.core.release_account_mode(*mode)

    def _collection_checkpoint(self,task):
        from core.collection_inbox import progress
        return json.dumps([task.get('pipeline'),progress(self.core.store,task)],
            ensure_ascii=True,sort_keys=True,separators=(',',':'))

    def _pending_collection_analysis(self,user,task):
        row=self.core.store.get(_COLLECTION_ANALYSIS_ENTITY,task['id'])
        if not row or row.get('status')=='completed':return None
        if (row.get('tenant_id')!=user['tenant_id'] or row.get('owner')!=user['username']
                or row.get('binding')!=self._collection_binding(task)
                or not isinstance(row.get('lead_ids'),list)):
            raise PlatformRuntimeError('AI_CONTEXT_REQUIRED','原批分析范围已变化，保留原记录，不会自动重提',409)
        return row

    def _collection_analysis_backlog(self,user,ident):
        return sum(not self._analysis_confirmed(row.get('manual_intent') or row.get('ai_intent'))
            for row in self._task_leads(user,ident) if not row.get('demo'))

    def _queue_collection_analysis(self,user,ident,lead_ids,*,hold=False):
        with self.core.lock:
            task=self._task(self._principal(user),ident)
            previous=self._pending_collection_analysis(user,task)
            if previous and previous.get('code') and not (hold and previous.get('code') in _COLLECTION_ANALYSIS_HOLD_CODES):
                raise PlatformRuntimeError(previous['code'],'原分析待核对，保留已采集评论',409)
            lead_ids=list(dict.fromkeys([*((previous or {}).get('lead_ids') or []),*lead_ids]))
            if not lead_ids:return
            self.core.store.put(_COLLECTION_ANALYSIS_ENTITY,{
                'id':ident,'tenant_id':user['tenant_id'],'owner':user['username'],
                'binding':self._collection_binding(task),'lead_ids':list(dict.fromkeys(lead_ids)),
                'status':'pending','code':previous.get('code','') if hold and previous else '',
                'updated_at':datetime.now(timezone.utc).isoformat()})

    def _drain_collection_analysis(self,executor,user,ident,*,reconcile=False):
        recovered_confirmed_ids=None
        with self.core.lock:
            task=self._task(self._principal(user),ident)
            queued=self._pending_collection_analysis(user,task)
            if queued is None:
                # Recover only this explicitly selected task's saved rows. This
                # also covers a process exit after Core committed a page but
                # before its analysis journal was created. The original AI
                # workflow still decides attempt uncertainty and eligibility.
                candidates=self._collection_lead_snapshot(user,ident,executor)
                pending=[]
                for lead_id in candidates:
                    row=self.core.store.get('leads',lead_id) or {}
                    analysis=row.get('manual_intent') or row.get('ai_intent') or {}
                    if (not row.get('demo') and str(row.get('text') or '').strip()
                            and analysis.get('status') not in ('graded','uncertain','unrelated')):
                        pending.append(lead_id)
                job=self.core.store.get('ai_jobs',ident) or {}
                unresolved=(job.get('tenant_id')==user['tenant_id']
                    and job.get('owner')==user['username'] and job.get('status')=='paused')
                if pending:
                    self._queue_collection_analysis(user,ident,pending)
                    queued=self._pending_collection_analysis(user,task)
                elif unresolved:
                    recovered_confirmed_ids=list(candidates)
        if queued is None:
            if recovered_confirmed_ids is not None:
                result=self._analyze_collection_page(executor,user,ident,recovered_confirmed_ids,reconcile=reconcile)
                if not isinstance(result,dict) or result.get('status')!='completed':
                    raise PlatformRuntimeError('ANALYSIS_PENDING','原批分析状态尚未完成核对',503)
            return
        try:
            self._assess_collection_page(user,ident)
            result=self._analyze_collection_page(executor,user,ident,queued['lead_ids'],reconcile=reconcile)
            if not isinstance(result,dict) or result.get('status')!='completed':
                code=result.get('code','ANALYSIS_PENDING') if isinstance(result,dict) else 'ANALYSIS_PENDING'
                raise PlatformRuntimeError(code,'本批已保存，意向分析待完成；完成后才读取下一页',503)
        except Exception as error:
            with self.core.lock:
                current=self._pending_collection_analysis(self._principal(user),self._task(user,ident))
                if current and set(queued['lead_ids']).issubset(current['lead_ids']):
                    self.core.store.put(_COLLECTION_ANALYSIS_ENTITY,{**current,'status':'pending',
                        'code':getattr(error,'code','ANALYSIS_PENDING'),
                        'updated_at':datetime.now(timezone.utc).isoformat()})
            raise
        with self.core.lock:
            current=self._pending_collection_analysis(self._principal(user),self._task(user,ident))
            if not current or not set(queued['lead_ids']).issubset(current['lead_ids']):
                raise PlatformRuntimeError('AI_CONTEXT_REQUIRED','原批分析范围已变化，停止下一页读取',409)
            remaining=[key for key in current['lead_ids'] if key not in set(queued['lead_ids'])]
            self.core.store.put(_COLLECTION_ANALYSIS_ENTITY,{**current,'lead_ids':remaining,'status':'pending' if remaining else 'completed','code':'',
                'updated_at':datetime.now(timezone.utc).isoformat()})

    def _assess_collection_page(self,user,ident):
        callback=getattr(self,'_rental_after_import',None)
        context=self.core.store.get('rental_task_context_v1',ident)
        if (callback is None or not context or context.get('enabled') is not True):return
        if context.get('owner')!=user['username'] or context.get('tenant_id')!=user['tenant_id']:
            raise PlatformRuntimeError('ANALYSIS_SCOPE_CHANGED','本批已保存，判断任务归属已变化',403)
        try:
            result=callback(user,ident)
            if not isinstance(result,dict) or result.get('status') in (
                    'requires_engine_update','historical_contract_unverified'):
                raise ValueError('assessment not completed')
        except Exception:
            with self.core.lock:
                current=self.core.store.get('rental_task_context_v1',ident)
                if current and current.get('owner')==user['username'] and current.get('tenant_id')==user['tenant_id']:
                    self.core.store.put('rental_task_context_v1',{**current,'assessment_status':'retry_required'})
            raise PlatformRuntimeError('ANALYSIS_PENDING','本批评论已保存，意向分析尚未完成；保留原任务，不会重复采集',503) from None
        with self.core.lock:
            current=self.core.store.get('rental_task_context_v1',ident)
            if current and current.get('owner')==user['username'] and current.get('tenant_id')==user['tenant_id']:
                self.core.store.put('rental_task_context_v1',{**current,'assessment_status':'completed',
                    'assessed_at':datetime.now(timezone.utc).isoformat()})

    def _task_leads(self,user,ident):
        reader=getattr(self.core.store,'list_task_leads',None)
        if callable(reader):return reader(user['tenant_id'],ident)
        # Compatibility with injected stores; normal SQLite uses task prefilter.
        return [row for row in self.core.store.list('leads',user['tenant_id']) if row.get('task_id')==ident]

    def _collection_lead_snapshot(self,user,ident,executor):
        if not callable(getattr(getattr(executor,'ai',None),'analyze',None)):return {}
        return {row['id']:hashlib.sha256(str(row.get('text') or '').encode('utf-8')).hexdigest()
            for row in self._task_leads(user,ident)
            if row.get('task_id')==ident and row.get('cloud_owner') in (None,'',user['username'])}

    def _new_collection_lead_ids(self,user,ident,executor,before):
        after=self._collection_lead_snapshot(user,ident,executor)
        return [ident for ident,value in after.items() if before.get(ident)!=value]

    def _analyze_collection_page(self,executor,user,ident,lead_ids,*,reconcile=False):
        """Use the original task AI workflow for this page, without a background pilot.

        The original workflow owns policy validation, cache, durable attempts,
        billing uncertainty and output CAS. This layer only schedules fixed IDs.
        """
        ai=getattr(executor,'ai',None)
        if not callable(getattr(ai,'analyze',None)):return {'status':'unavailable','analyzed':0}
        from assistant.ai_workflow import post_identity
        from assistant.ai_worker import safe_error_code,REVIEW_CODES
        actor=self._principal(user);task=self._task(actor,ident)
        scope=tuple(task.get(key) for key in ('id','tenant_id','cloud_owner','store_id','platform','account_id'))
        ids=list(dict.fromkeys(value for value in lead_ids if isinstance(value,str)))
        def visible():
            fresh=self._principal(user);current=self._task(fresh,ident)
            control=getattr(self,'_run_cancels',{}).get(ident)
            if (self.closed or current.get('status')=='paused'
                    or control and (control['event'].is_set() or control.get('analysis_stop') and control['analysis_stop'].is_set())):
                raise PlatformRuntimeError('AI_CONTEXT_REQUIRED','采集已暂停，不再提交新的分析请求',409)
            if (tuple(current.get(key) for key in ('id','tenant_id','cloud_owner','store_id','platform','account_id'))!=scope
                    or self._executor(fresh) is not executor):
                raise PlatformRuntimeError('AI_CONTEXT_REQUIRED','分析的员工、门店或任务已变化，保留本批评论',409)
            rows=[row for key in ids if (row:=self.core.store.get('leads',key)) is not None]
            rows=list(executor._analysis_visible_leads(fresh,current,rows=rows))
            for row in rows:
                result=row.get('manual_intent') or row.get('ai_intent')
                if row.get('task_id')==ident and not row.get('demo') and result and not self._analysis_confirmed(result):
                    raise PlatformRuntimeError('AI_INVALID_OUTPUT',
                        '本批已有未确认的分析结果，保持待分析；不会跳过或自动重提',409)
            return fresh,current,[row for row in rows if row.get('task_id')==ident
                and not row.get('demo') and not row.get('manual_intent') and not row.get('ai_intent')
                and isinstance(row.get('text'),str) and row['text'].strip()]
        previous=self.core.store.get('ai_jobs',ident) or {}
        review=previous.get('tenant_id')==actor['tenant_id'] and previous.get('status')=='paused' and previous.get('code') in REVIEW_CODES
        if reconcile and not review:
            from assistant.ai_attempts import _digest
            hashes={_digest([actor['tenant_id'],actor['username'],key]) for key in ids}
            review=any(row.get('owner')==actor['username'] and row.get('state') in ('unknown','submitted','response_received')
                and hashes.intersection(row.get('lead_digests') or [])
                for row in self.core.store.list('ai_attempts',actor['tenant_id']))
        if review and not reconcile:
            raise PlatformRuntimeError(previous['code'],'已有分析请求结果尚未核对，评论已保存，不会自动重复提交',409)
        actor,task,pending=visible()
        if not pending:
            # A remaining row may have been confirmed manually while paused.
            # Close only the unchanged, owned job; do not leave a stale pending
            # counter or overwrite an in-flight/unknown result from another turn.
            with self.core.lock:
                current=self.core.store.get('ai_jobs',ident) or {}
                if current!=previous:
                    raise PlatformRuntimeError('AI_CONTEXT_REQUIRED','分析状态已变化，请核对原批次',409)
                if current:
                    if (current.get('tenant_id')!=actor['tenant_id']
                            or current.get('owner')!=actor['username']
                            or current.get('store_id')!=task.get('store_id')
                            or current.get('status')=='running'
                            or current.get('code')=='AI_IN_PROGRESS'
                            or current.get('code') in REVIEW_CODES):
                        raise PlatformRuntimeError('AI_CONTEXT_REQUIRED','原分析请求仍需核对，未修改计数',409)
                    self.core.store.put('ai_jobs',{**current,'status':'completed','code':'','pending':0,
                        'updated_at':datetime.now(timezone.utc).isoformat()})
            return {'status':'completed','analyzed':0,'pending':0}
        analyzed=0
        def record(status,code='',remaining=None,profile=None,failure=None):
            value={'id':ident,'tenant_id':actor['tenant_id'],'task_id':ident,'owner':actor['username'],
                'store_id':task.get('store_id'),'status':status,'code':code,
                'pending':len(pending) if remaining is None else remaining,'analyzed':analyzed,
                'retry_count':0,'updated_at':datetime.now(timezone.utc).isoformat()}
            if profile is not None:
                value.update(profile_revision=profile.get('revision'),provider=profile.get('provider'),model=profile.get('model'))
            if failure is not None:
                # Private structured diagnostics: no provider body, comment,
                # credentials, local frame variables or arbitrary error text.
                trace=failure.__traceback__;locations=[]
                while trace is not None and len(locations)<12:
                    frame=trace.tb_frame
                    locations.append({'module':str(frame.f_globals.get('__name__',''))[:100],
                        'function':frame.f_code.co_name[:100],'line':trace.tb_lineno})
                    trace=trace.tb_next
                raw=getattr(failure,'code',None);http=getattr(failure,'http_status',None)
                value['last_check']={'error_kind':type(failure).__name__[:80],
                    'code':raw if isinstance(raw,str) and re.fullmatch('[A-Z_]{1,80}',raw) else 'unknown',
                    'http_status':http if type(http) is int and 100<=http<=599 else None,'locations':locations}
            self.core.store.put('ai_jobs',value)
        try:
            response=ai.cloud(actor,'ai_profile',{})
            profile=response.get('config',response)
            if not isinstance(profile,dict) or type(profile.get('revision')) is not int:
                record('pending','AI_CONFIG_CHANGED');return {'status':'pending','analyzed':0,'pending':len(pending)}
            if profile.get('enabled') is not True or profile.get('configured') is not True:
                code='AI_DISABLED' if profile.get('enabled') is not True else 'AI_NOT_CONFIGURED'
                record('pending',code,profile=profile)
                return {'status':'pending','code':code,'analyzed':0,'pending':len(pending)}
        except Exception as error:
            code=safe_error_code(error);record('pending',code)
            raise PlatformRuntimeError(code,'本批评论已保存，企业AI暂不可用，未重复提交',503) from None
        groups={}
        for row in pending:groups.setdefault(post_identity(row),[]).append(row['id'])
        record('running',profile=profile)
        try:
            for group in groups.values():
                for offset in range(0,len(group),20):
                    actor,task,fresh=visible();lookup={row['id']:row for row in fresh}
                    current=[lookup[key] for key in group[offset:offset+20] if key in lookup]
                    if not current:continue
                    # Explicit continuation may reconcile the exact old batch.
                    # The attempt layer rejects unmatched/reshaped requests and
                    # reads the original key before any retained-result lookup.
                    if review:
                        ai.analyze(actor,task,current,replace_existing=False,explicit_retry=False,existing_only=True)
                        review=False
                    else:
                        ai.analyze(actor,task,current,replace_existing=False,explicit_retry=False)
                    complete=0
                    for row in current:
                        stored=self.core.store.get('leads',row['id']) or {}
                        result=stored.get('manual_intent') or stored.get('ai_intent') or {}
                        if self._analysis_confirmed(result):complete+=1
                    if complete!=len(current):
                        raise PlatformRuntimeError('AI_INVALID_OUTPUT','本批分析尚未完整保存，不会自动重提',503)
                    analyzed+=complete
                    record('running',remaining=len(pending)-analyzed,profile=profile)
        except Exception as error:
            code=safe_error_code(error)
            if review and code not in REVIEW_CODES:
                code=previous.get('code') if previous.get('code') in REVIEW_CODES else 'PRODUCT_REQUEST_UNKNOWN'
            record('paused',code,len(pending)-analyzed,profile,failure=error)
            if isinstance(error,PlatformRuntimeError):raise
            raise PlatformRuntimeError(code,'本批评论已保存，分析结果尚未完整确认；原请求保留，不会自动重提',503) from None
        record('completed',remaining=0,profile=profile)
        return {'status':'completed','analyzed':analyzed,'pending':0}

    def _start_task(self, executor, user, ident, *, recover_unsent=False,verified_retry=None):
        with self._run_lock:
            if any(thread.is_alive() for thread in self._runs.values()):
                raise PlatformRuntimeError('COLLECTION_BUSY','已有采集正在处理，请先暂停或等待本批结束')
            for wait in self._verification_waits.values():wait['cancel'].set()
            executor._explicit_task_ids.add(ident)
            attempt=uuid4().hex
            task=self._task(user,ident)
            bounded=bool(task.get('platform')=='xiaohongshu' and self._current_comment_policy(task)
                and self._collection_binding(task))
            control={'event':threading.Event(),'attempt':attempt,'binding':self._collection_binding(task),'recover_unsent':recover_unsent is True,'verified_retry':dict(verified_retry or {})}
            self._run_cancels[ident]=control
            self._collection_diagnostic(user,ident,attempt)
            def run():
                try:
                    from core.acquisition_receipts import ENTITY,task_digest
                    with self.core.lock:
                        receipt=self.core.store.get(ENTITY,ident)
                        if receipt is not None and receipt.get('state')=='prepared':
                            current=self._task(self._principal(user),ident)
                            if (receipt.get('binding') or {}).get('schema')=='workbench-acquisition-source-binding/1':
                                from core.acquisition_sources import task_digest
                            if (receipt.get('owner')!=user['username'] or receipt.get('tenant_id')!=user['tenant_id']
                                    or receipt.get('taskConditionsDigest')!=task_digest(current)):
                                raise PlatformRuntimeError('REQUEST_SCOPE_INVALID','原任务回执归属已变化',409)
                            self.core.store.put(ENTITY,{**receipt,'state':'started',
                                'started_at':datetime.now(timezone.utc).isoformat()})
                    if bounded:self._bounded_collection(executor,user,ident,control)
                    else:
                        # Auxiliary platforms keep their original single batch.
                        self._drain_collection_analysis(executor,user,ident)
                        before_leads=self._collection_lead_snapshot(user,ident,executor)
                        self._execute(executor,user,'task_run',{'task_id':ident,'max_batches':1})
                        self._queue_collection_analysis(user,ident,
                            self._new_collection_lead_ids(user,ident,executor,before_leads))
                        self._drain_collection_analysis(executor,user,ident)
                except Exception as error:
                    if control['event'].is_set():
                        self.core._set_task_progress(ident,'paused','paused')
                        self._collection_diagnostic(user,ident,attempt,clear=True)
                    elif getattr(error,'_account_mode_blocked',False) is True:
                        # Only an exception from the original atomic local mode
                        # gate carries this marker; platform errors keep their path.
                        with self.core.lock:
                            current=self._task(self._principal(user),ident)
                            current.update(status='paused',pause_reason='account_mode_blocked',last_message=str(error))
                            self.core.store.put('tasks',current)
                        self.core._set_task_progress(ident,'paused','paused')
                        self._collection_diagnostic(user,ident,attempt,error=error)
                    else:
                        self.core._set_task_progress(ident,'failed','failed')
                        self._collection_diagnostic(user,ident,attempt,error=error)
                else:
                    self._collection_diagnostic(user,ident,attempt,clear=True)
                finally:
                    with self._run_lock:
                        if self._run_cancels.get(ident) is control:self._run_cancels.pop(ident,None)
            thread = threading.Thread(target=run,name='explicit-workbench-collection',daemon=True)
            self._runs[ident] = thread
            try:
                thread.start()
            except BaseException:
                self._run_cancels.pop(ident,None)
                self._collection_diagnostic(user,ident,attempt,clear=True)
                error=PlatformRuntimeError('COLLECTION_RESULT_UNCONFIRMED','任务已保存，启动结果需按原任务核对，请勿重新提交',503,mutation_committed=True)
                error.task_id=ident
                raise error from None
        try:
            return {'result':{'taskId':ident,'status':'submitted','accepted':True,'maxBatches':None if bounded else 1}, **self.snapshot(user)}
        except Exception:
            error=PlatformRuntimeError('COLLECTION_RESULT_UNCONFIRMED','任务已提交，结果需按原任务核对，请勿重新提交',503,mutation_committed=True)
            error.task_id=ident
            raise error from None

    def pause_acquisition(self, user, data):
        user = self._principal(user)
        if type(data) is not dict or set(data) != {'taskId'}:
            raise PlatformRuntimeError('INVALID_INPUT','暂停任务参数无效',400)
        executor = self._executor(user,online=False)
        with self._run_lock:
            task=self._task(user,data['taskId'])
            wait=self._verification_waits.get(data['taskId'])
            if wait:wait['cancel'].set()
            control=self._run_cancels.get(data['taskId'])
            if control and control.get('binding')==self._collection_binding(task):control['event'].set()
            result = self._execute(executor,user,'task_stop',{'task_id':data['taskId']})
        state=result.get('status','paused') if isinstance(result,dict) else 'paused'
        return {'result':{'taskId':data['taskId'],'status':state if state in ('paused','stopped','cancelled') else 'paused',
                          'accepted':True}, **self.snapshot(user)}

    def check_source_interactions(self,user,data):
        user=self._principal(user)
        if type(data) is not dict or set(data)!={'taskId','scan'} or type(data['scan']) is not int or not 2<=data['scan']<=1000000:
            raise PlatformRuntimeError('INVALID_INPUT','请选择原本人互动任务与下一检查轮次',400)
        executor=self._executor(user)
        with self._run_lock,self.core.lock:
            task=self._task(user,data['taskId']);account=self._account(user,task.get('account_id'))
            from core.acquisition_extension_runtime import source_scan,next_interaction_scan
            from core.acquisition_sources import load_plan
            current=source_scan(task)
            if not current:raise PlatformRuntimeError('SOURCE_KIND_MISMATCH','请选择本人互动任务',409)
            if current==data['scan']:
                return {'result':{'taskId':task['id'],'scan':current,'alreadyAccepted':True},**self.snapshot(user)}
            if current+1!=data['scan']:raise PlatformRuntimeError('SOURCE_SCAN_CHANGED','原检查轮次已变化，请核对结果',409)
            if (any(thread.is_alive() for thread in self._runs.values()) or self.core.running or self.core.sequences
                    or not self._can_check_interactions(user,task,account)):
                raise PlatformRuntimeError('SOURCE_SCAN_NOT_READY','请先完成原轮次、核对账号或分析状态；未开始新检查',409)
            plan=load_plan(self.core.store,task)
            def guard():
                actor=self._principal(user);fresh=self._task(actor,task['id']);selected=self._account(actor,task['account_id'])
                if self._executor(actor) is not executor:raise PlatformRuntimeError('DEVICE_CHANGED','本机执行身份已变化',409)
                if self._collection_binding(fresh)!=self._collection_binding(task) or selected!=account:
                    raise PlatformRuntimeError('TASK_SCOPE_CHANGED','原账号或任务已变化',409)
                code,message=self._collection_readiness(actor,selected)
                if code:raise PlatformRuntimeError(code.upper(),message)
                self.server._platform_execution_guard('xiaohongshu')
                executor._guard_platform_qa_command('task_run',{'task_id':task['id'],'max_batches':1})
            next_interaction_scan(self.core.store,task,plan,data['scan'],guard)
            try:
                return self._start_task(executor,user,task['id'],recover_unsent=True)
            except Exception as exc:
                # The scan CAS is committed even when dispatch is refused or its
                # result is unknown. Keep this scan and recover its original task.
                exc.mutation_committed=True
                raise

    def resume_acquisition(self, user, data):
        user = self._principal(user)
        if type(data) is not dict or set(data) != {'taskId'}:
            raise PlatformRuntimeError('INVALID_INPUT','继续任务参数无效',400)
        executor = self._executor(user)
        task = self._task(user,data['taskId'])
        account = self._account(user,task.get('account_id'))
        code, message = self._collection_readiness(user,account)
        if code:
            raise PlatformRuntimeError(code.upper(),message)
        with self._run_lock:
            if (any(thread.is_alive() for thread in self._runs.values())
                    or self.core.running or self.core.sequences or self._task_active(task)):
                raise PlatformRuntimeError('COLLECTION_BUSY','已有采集正在处理，请先暂停或等待本批结束')
            task=self._task(user,data['taskId'])
            if not self._current_comment_policy(task):
                raise PlatformRuntimeError('TASK_POLICY_CHANGED','旧任务使用旧筛选条件，请重新开始获客；历史与断点已保留')
            account=self._account(user,task.get('account_id'))
            code,message=self._collection_readiness(user,account)
            if code:raise PlatformRuntimeError(code.upper(),message)
            if account.get('status')!='ready':
                raise PlatformRuntimeError('ACCOUNT_NOT_READY','请先连接并核实平台账号')
            if (task.get('status')!='paused' and not self._batch_resumable(user,task,account)
                    and task.get('source_scan_pending') is not True and not self._pending_collection_analysis(user,task)):
                raise PlatformRuntimeError('TASK_NOT_RESUMABLE','原任务尚不满足继续条件，请先核对采集状态')
            queued=self._pending_collection_analysis(user,task)
            if queued and queued.get('code') in _COLLECTION_ANALYSIS_HOLD_CODES and self._collection_analysis_backlog(user,task['id'])>=200:
                raise PlatformRuntimeError('ANALYSIS_BACKLOG_LIMIT','待分析已达200条暂停线；原评论与断点保留，请先完成分析或人工复核',409)
            verified_retry=self._verified_task_pages(user,task,account) if task.get('platform')=='xiaohongshu' else {}
            self._execute(executor,user,'task_resume',{'task_id':task['id']})
            return self._start_task(executor,user,task['id'],recover_unsent=True,verified_retry=verified_retry)

    def close(self):
        with self.lock:
            if self.closed and self._instance_lock is None:
                return
            self.closed = True
        self.source_scheduler.close()
        with self._run_lock:
            for control in self._run_cancels.values():control['event'].set()
        try:
            self.server.close_owned_jobs()
            self.server.server_close()
            for thread in tuple(self._runs.values()):
                if thread is not threading.current_thread() and thread.is_alive():
                    thread.join(8)
            if any(thread.is_alive() for thread in self._runs.values()):
                # Keep the compatible workspace lock until the process/worker
                # actually exits; another backend must not race final writes.
                raise PlatformRuntimeError('RUNTIME_STOPPING','本批采集尚在退出，暂时保留工作区独占锁',503)
        finally:
            if not any(thread.is_alive() for thread in self._runs.values()):
                self._release_instance_lock()


__all__ = ['PlatformRuntime', 'PlatformRuntimeError']
