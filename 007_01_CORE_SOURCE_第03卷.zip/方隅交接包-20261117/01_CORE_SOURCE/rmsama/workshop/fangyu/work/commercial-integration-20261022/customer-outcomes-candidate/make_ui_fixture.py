import sys
sys.dont_write_bytecode=True
from test_outcomes import OutcomesTests,W,EVENTS,RECEIPTS
import json
case=OutcomesTests();case.setUp()
try:
    before=case.read();listing=case.customers.list(case.user,'gubei',{});detail=case.customers.detail(case.user,'gubei',case.cid,platform='xiaohongshu')
    request=case.request('payment',amountCents=10001);saved=case.service.save(case.user,'gubei',request)
    report=case.report()
    (W/'UI-FIXTURES.json').write_text(json.dumps({'base':case.base,'saveRequest':request,'read':before,'saved':saved,'report':report,'listing':listing,'detail':detail,'scope':'Original Core/Store/CustomerHistory with fictional data only'},ensure_ascii=False,indent=2),encoding='utf-8')
finally:case.tearDown()
