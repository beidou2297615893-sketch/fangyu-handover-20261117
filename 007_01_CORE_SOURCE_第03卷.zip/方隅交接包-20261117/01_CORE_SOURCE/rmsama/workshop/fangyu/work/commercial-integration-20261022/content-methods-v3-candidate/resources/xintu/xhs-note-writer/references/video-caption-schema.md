# Video Caption Schema

Video captions are **publish metadata**, not spoken scripts.

## Required fields

- `title`: specific; prefer search-facing nouns; punch ~8-18 字 or search/intent ~18-32 字 (see `title-craft.md`)
- `title_job`: `feed` | `search` | `hybrid`
- `caption`: 80-220 Chinese characters by default
- `first_line`: must stand alone in feed/search preview
- `tags`: 5-10 tags
- `cta`: comment/save/follow prompt tied to delivered value
- `script_boundary`: one sentence clarifying what stays in the video vs caption
- `similarity_risk`: low | medium | high with reason

## Caption structure

1. Result or conflict in line 1
2. Who it helps + one proof hint
3. What the viewer will see (not a step dump)
4. Save/comment/follow reason
5. Optional soft series mention

## Do not include

- Full spoken script or timestamped lines
- Long tool feature lists better shown on screen
- Absolute claims or fake metrics
- Copy-paste of reference captions

## Quality checks

- Readable without opening the video
- Keywords appear naturally, not stuffed
- Caption adds context the first frame may not show
- CTA matches actual content delivered in the video
