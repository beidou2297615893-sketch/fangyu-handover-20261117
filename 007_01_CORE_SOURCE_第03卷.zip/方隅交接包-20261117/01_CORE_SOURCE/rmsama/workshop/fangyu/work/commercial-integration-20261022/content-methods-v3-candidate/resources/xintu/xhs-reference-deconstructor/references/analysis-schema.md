# Reference Analysis Contract

## Facts

Only observable title, cover, structure, claims, format, sequence, metrics, and CTA.

## Inference

- intended audience and pain
- hook and promise
- proof mechanism
- narrative structure
- visual hierarchy
- save/comment motive
- confidence and missing evidence

## Reuse boundary

- transferable mechanics
- creator-owned context
- wording or visuals not to copy
- similarity risks

## Original transformations

For each option include audience, new thesis, original evidence, format, hook, structure, and similarity-risk score.

