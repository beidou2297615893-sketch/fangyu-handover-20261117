"""Private source-only component selection for one own-video comment page.

This decision contains no account, login, device or search/send grant.
"""
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import re
from .runtime_license_policy import _plain, _file_hash

_PURPOSE = 'douyin_owned_video_comments'
_REVIEW_SHA='4BAE38A5A0060EA0A2521F1D6A59CF02DA7FDB42B229055FA041F682B43838B1'
_SOURCE = Path(__file__).resolve().parents[1]


def _digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False,
        separators=(',', ':'), allow_nan=False).encode()).hexdigest()


class DouyinCommentsPolicy:
    def __init__(self, server):
        self._server = server
        self._self_hash = _file_hash(Path(__file__)).upper()

    def _snapshot(self):
        from bridge import BridgeManager
        server = self._server
        if (Path(server.core.resources_dir) != _SOURCE / 'resources'
                or type(server.bridge) is not BridgeManager
                or server.bridge.runtime != _SOURCE.parent / 'work/runtime/douyin-bridge'
                or server._runtime_license_usage_scope('internal_self_use_read') != 'internal_self_use_read'
                or server.company.get('id') != 'fangyu-apartment-client'
                or server.closing):
            raise ValueError('douyin_comment_component_pending')
        runtime = server.bridge.runtime
        if any((runtime / 'node_modules' / name).exists()
               for name in ('bufferutil', 'utf-8-validate')):
            raise ValueError('douyin_comment_component_pending')
        manifest = server.core.adapters.manifest('douyin')
        arguments = [str(runtime / 'cli.js'), 'comment-page', '{source_id}',
            '--count', '{limit}', '--cursor', '{cursor}', '--conn-id', '{conn_id}',
            '--no-store', '--no-log']
        if (manifest.get('comments_args') != arguments
                or Path(manifest.get('executable', '')) != runtime / 'node.exe'
                or manifest.get('prefix_args') not in (None, [])
                or manifest.get('env') not in (None,{})
                or manifest.get('mapper') != 'douyin_bridge'
                or manifest.get('paged_comments') is not True
                or manifest.get('isolation_guard') is not True):
            raise ValueError('douyin_comment_component_pending')
        return deepcopy({'company': server.company.get('id'), 'runtime': str(runtime),
            'args': arguments, 'executable': str(runtime / 'node.exe'),
            'purpose': _PURPOSE, 'scope': 'internal_self_use_read'})

    def current_review(self):
        """Small fixed-revision check only; never an execution admission."""
        if (_file_hash(_plain(Path(__file__), _SOURCE)).upper() != self._self_hash
                or _file_hash(_plain(_SOURCE / 'resources/douyin-owned-comments/review.json', _SOURCE)).upper()
                    != _REVIEW_SHA):
            raise ValueError('douyin_comment_component_pending')
        return _REVIEW_SHA

    def resolve(self):
        try:
            snapshot = self._snapshot()
            self.current_review()
            record = json.loads((_SOURCE / 'resources/douyin-owned-comments/review.json').read_text('utf8'))
            if (set(record) != {'schema', 'purpose', 'scope', 'company_id', 'limits', 'materials', 'evidence'}
                    or record['schema'] != 1 or record['purpose'] != _PURPOSE
                    or record['scope'] != 'internal_self_use_read'
                    or record['company_id'] != snapshot['company']
                    or record['limits'] != {'main_page_only': True, 'max_comments': 20,
                        'search': False, 'reply': False, 'dm': False,
                        'platform_identity_before_after': True, 'real_platform_verified': False}
                    or type(record['materials']) is not list or not record['materials']):
                raise ValueError('douyin_comment_component_pending')
            facts, seen = [], set()
            for item in record['materials']:
                if (type(item) is not dict or set(item) != {'root', 'path', 'sha256', 'bytes', 'role'}
                        or item['root'] not in ('source', 'douyin_runtime')
                        or type(item['path']) is not str or '\\' in item['path'] or ':' in item['path']
                        or any(p in ('', '.', '..') for p in item['path'].split('/'))
                        or (item['root'], item['path']) in seen
                        or not re.fullmatch(r'[0-9A-F]{64}', item['sha256'])
                        or type(item['bytes']) is not int or item['bytes'] < 0):
                    raise ValueError('douyin_comment_component_pending')
                root = _SOURCE if item['root'] == 'source' else self._server.bridge.runtime
                path = _plain(root / item['path'], root)
                before = path.stat()
                if before.st_size != item['bytes'] or _file_hash(path).upper() != item['sha256']:
                    raise ValueError('douyin_comment_component_pending')
                after = path.stat()
                if (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns) != (
                        after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns):
                    raise ValueError('douyin_comment_component_pending')
                seen.add((item['root'], item['path'])); facts.append(item)
            if snapshot != self._snapshot():
                raise ValueError('douyin_comment_component_pending')
            self.current_review()
            return {'purpose': _PURPOSE, 'revision': _digest([_REVIEW_SHA, facts, snapshot])}
        except (ValueError, TypeError, KeyError, OSError):
            return None
