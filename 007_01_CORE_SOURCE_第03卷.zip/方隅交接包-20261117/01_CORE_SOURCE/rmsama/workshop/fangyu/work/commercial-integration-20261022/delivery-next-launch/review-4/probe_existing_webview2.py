"""Read-only original installer prerequisite branch, no real installation."""
from pathlib import Path
import hashlib,importlib.util,json,os
HERE=Path(__file__).resolve().parent
def main():
    sample=HERE/'standard-held-clean-v72'
    source=sample/'installer.original.py';raw=source.read_bytes()
    expected='5f76f4c384f71f0465ec410d9e363d68a63e8222456353c5f28aeb6ef0288aee'
    if hashlib.sha256(raw).hexdigest()!=expected:raise RuntimeError('Original installer bytes differ')
    owned=HERE/'existing-webview2-probe';owned.mkdir(exist_ok=False)
    os.environ['LOCALAPPDATA']=str(owned);os.environ['TEMP']=str(owned);os.environ['TMP']=str(owned)
    module=importlib.util.module_from_spec(importlib.util.spec_from_loader('original_installer_prerequisite_probe',loader=None))
    module.__file__=str(source)
    exec(compile(raw,str(source),'exec'),module.__dict__)
    version=module.webview2_version()
    if not version:raise RuntimeError('Original installer did not detect existing WebView2')
    archive=sample/json.loads((sample/'BUILD.json').read_text('utf-8'))['portableZip']
    module.prepare_runtime(archive)  # Existing-runtime early return; no install.
    files=list(owned.iterdir())
    if files:raise RuntimeError('Existing-runtime branch unexpectedly wrote temporary files')
    report={'status':'PASS_ORIGINAL_INSTALLER_EXISTING_WEBVIEW2_EARLY_RETURN',
        'detectedVersion':version,'originalInstallerSha256':expected,'runtimeInstalled':False,
        'temporaryFilesCreated':0,'downloads':0,'realApplicationInstallation':False,
        'missingRuntimeBehavior':'Slim archive contains no offline runtime; original installer stops with instructions instead of downloading.'}
    (HERE/'SLIM-WEBVIEW2-DETECTION.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n','utf-8')
    print(json.dumps(report,ensure_ascii=True))
if __name__=='__main__':main()
