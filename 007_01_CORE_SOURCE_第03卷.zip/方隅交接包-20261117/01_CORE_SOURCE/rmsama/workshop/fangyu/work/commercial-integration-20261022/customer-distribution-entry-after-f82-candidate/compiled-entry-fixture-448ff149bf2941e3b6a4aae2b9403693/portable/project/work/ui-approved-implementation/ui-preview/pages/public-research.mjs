// Explicit public query only. Local storage contains request metadata, never query/snippets.
const STORAGE='fangyu-public-research-pending-v1';
const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function saved(scope){try{const rows=JSON.parse(localStorage.getItem(STORAGE)||'[]');return Array.isArray(rows)?rows.find(r=>r?.scope===scope&&typeof r.requestId==='string'&&['content_public_research_preview','content_public_research_import'].includes(r.action))||null:null;}catch{return null;}}
function remember(scope,pending){try{const raw=JSON.parse(localStorage.getItem(STORAGE)||'[]'),rows=Array.isArray(raw)?raw:[];const kept=rows.filter(r=>r?.scope!==scope).slice(-49);if(pending)kept.push({scope,requestId:pending.requestId,action:pending.action});localStorage.setItem(STORAGE,JSON.stringify(kept));return !pending||saved(scope)?.requestId===pending.requestId;}catch{return false;}}
function ui(f){return f.publicResearchUI??=( {open:false,query:'',selectedId:'',selected:[],busy:false,error:'',notice:'',pending:saved(f.persistScope),retryReady:false} );}
const history=w=>Array.isArray(w?.workflow?.publicResearch)?w.workflow.publicResearch:[];
function chosen(f,w){const r=ui(f);return history(w).find(s=>s.id===r.selectedId)||null;}
function date(value){const d=new Date(value);return Number.isFinite(d.valueOf())?d.toLocaleString('zh-CN',{hour12:false}):'时间待核对';}
export function renderPublicResearch(f,w){
 const r=ui(f),rows=history(w),snapshot=chosen(f,w),blocked=Boolean(r.busy||f.pending||f.localUnknown),hold=Boolean(r.pending),searchHold=hold&&!r.retryReady,canSave=w?.capabilities?.canSave===true;
 return `<details class="wf-text-import wf-public-research" data-pr-panel ${r.open?'open':''} style="font-size:17px;min-width:0"><summary>联网找参考</summary><p style="font-size:17px">只搜索这里填写的内容</p><label class="co-field"><span>公开检索词</span><input style="font-size:17px" data-pr-query maxlength="160" value="${esc(r.query)}" placeholder="输入需要查找的公开主题" ${blocked||searchHold?'disabled':''}></label><div class="co-actions"><button class="co-button co-primary" style="font-size:17px" data-pr-search ${blocked||searchHold||!canSave||!r.query.trim()?'disabled':''}>${r.retryReady?'重新联网找参考':'联网找参考'}</button>${hold?`<button class="co-button" style="font-size:17px" data-pr-check ${r.busy||f.pending?'disabled':''}>核对原检索记录</button>`:''}</div><p style="font-size:17px">只返回公开来源网址和搜索摘要；原文未抓取，内容均待核实。</p>${r.error?`<p role="alert" style="font-size:17px">${esc(r.error)}</p>`:''}${r.notice?`<p role="status" style="font-size:17px">${esc(r.notice)}</p>`:''}${hold?`<p style="font-size:17px">${r.retryReady?'原失败记录保留。只有本人点击重新搜索，才会发起一次新的公开检索。':'原操作待核对。先读取本地记录，不重新联网。'}</p>`:''}${rows.length?`<label class="co-field"><span>已保存的检索</span><select style="font-size:17px" data-pr-history ${blocked?'disabled':''}><option value="">选择原检索记录</option>${[...rows].reverse().map(s=>`<option value="${esc(s.id)}" ${r.selectedId===s.id?'selected':''}>${esc(s.query)} · ${esc(date(s.retrievedAt||s.createdAt))}</option>`).join('')}</select></label>`:''}${snapshot?`<p style="font-size:17px">${esc(snapshot.query)} · ${esc(date(snapshot.retrievedAt||snapshot.createdAt))}</p>${snapshot.state==='received'?`<div>${snapshot.results.map(result=>`<label style="display:block;padding:12px 0;border-bottom:1px solid #dce8ee;font-size:17px;overflow-wrap:anywhere"><span style="display:flex;gap:10px;align-items:start"><input type="checkbox" data-pr-result="${esc(result.id)}" ${r.selected.includes(result.id)?'checked':''} ${blocked||hold?'disabled':''} style="width:18px;height:18px;flex:none"><strong>${esc(result.title)}</strong></span><span style="display:block;margin:8px 0;overflow-wrap:anywhere">${esc(result.url)}</span><span style="display:block">${esc(result.snippet)}</span>${result.restrictedView?'<span style="display:block;margin-top:8px">摘要含标准化或受限显示，请核对来源，不能当完整原文。</span>':''}</label>`).join('')}</div><div class="co-actions"><button class="co-button co-primary" style="font-size:17px" data-pr-import ${blocked||hold||!canSave||!r.selected.length?'disabled':''}>将勾选摘要存为待核资料</button></div><p style="font-size:17px">保存后仍需在下次内容任务中明确选择引用，不会自动生成或发布。</p>`:'<p style="font-size:17px">原检索结果尚未确认，不能导入资料，也不会自动重搜。</p>'}`:''}</details>`;
}
export function bindPublicResearch(root,{f,workspace,valid,validate,adopt,update,send,base,canWrite}){
 const r=ui(f),current=()=>valid()&&ui(f)===r;
 root.querySelector('[data-pr-panel]')?.addEventListener('toggle',event=>{if(current())r.open=event.target.open;});
 root.querySelector('[data-pr-query]')?.addEventListener('input',event=>{if(!current()||r.busy||r.pending&&!r.retryReady)return;r.query=event.target.value;const button=root.querySelector('[data-pr-search]');if(button)button.disabled=!r.query.trim()||!canWrite();});
 root.querySelector('[data-pr-history]')?.addEventListener('change',event=>{if(current()&&!r.busy)update(()=>{r.selectedId=event.target.value;r.selected=[];r.error='';});});
 root.querySelectorAll('[data-pr-result]').forEach(el=>el.addEventListener('change',()=>{if(!current()||r.busy||r.pending)return;const s=chosen(f,workspace());if(!s?.results.some(v=>v.id===el.dataset.prResult))return;update(()=>{r.selected=el.checked?[...new Set([...r.selected,el.dataset.prResult])]:r.selected.filter(id=>id!==el.dataset.prResult);});}));
 async function call(action,data,writing=true){
  if(!current()||r.busy||f.pending||writing&&(!canWrite()||f.localUnknown||r.pending&&!(action==='content_public_research_preview'&&r.retryReady)))return;
  const w=workspace();if(!w||!validate({workspace:w}))return;
  const requestId=writing?crypto.randomUUID():data.requestId,payload={...base(),...(writing?{expectedRevision:w.revision,requestId}:{}),...data};
  if(writing&&!remember(f.persistScope,{requestId,action})){update(()=>{r.error='无法保存原操作编号，本次尚未联网或保存。';});return;}
  const pending=writing?{requestId,action}:r.pending;
  update(()=>{r.busy=true;f.pending=writing?'正在处理本次公开资料…':'正在读取原检索记录…';r.pending=pending;r.retryReady=false;r.error='';r.notice='';if(action==='content_public_research_preview'){r.selectedId='';r.selected=[];}});
  try{
   const response=await send(action,payload);if(!current()||!validate(response))return;
   const receipt=response.receipt;
   if(!receipt||receipt.requestId!==requestId||receipt.action!==(writing?action:pending?.action)||receipt.found===false)throw Error('原操作回执尚未核对，编号已保留，不重新联网。');
   if(!['succeeded','unknown'].includes(receipt.state))throw Error('原操作状态待核对，编号已保留。');
   update(()=>{
    adopt(response);const snapshot=response.result?.publicResearch||history(response.workspace).find(s=>s.requestId===requestId);
    if(snapshot&&typeof snapshot.id==='string'&&typeof snapshot.digest==='string')r.selectedId=snapshot.id;
    if(receipt.state==='succeeded'){remember(f.persistScope,null);r.pending=null;r.notice=action==='content_public_research_import'||receipt.action==='content_public_research_import'?'勾选摘要已保存为待核资料，请在内容任务中选择引用。':'公开摘要已取得，请核对来源后勾选。';}
    else{
     r.pending=pending;
     const age=snapshot?Date.now()-Date.parse(snapshot.createdAt):0;
     r.retryReady=receipt.action==='content_public_research_preview'&&snapshot?.state==='unknown'&&Boolean(snapshot.completedAt||Number.isFinite(age)&&age>=30000);
     if(r.retryReady&&!r.query)r.query=snapshot.query;
     r.notice=r.retryReady?'原结果未取得，失败记录已保留。可修改公开检索词后本人重新点击；同词十分钟内最多三次。':'原检索仍在处理中，没有新增资料；请稍后核对原记录。';
    }
    r.selected=[];
   });
  }catch(error){if(current())update(()=>{r.error=error?.message||'原操作待核对，编号已保留。';r.notice='';r.selectedId='';r.selected=[];if(error?.mutationCommitted===false){remember(f.persistScope,null);r.pending=null;}});}
  finally{if(current())update(()=>{r.busy=false;f.pending='';});}
 }
 root.querySelector('[data-pr-search]')?.addEventListener('click',()=>{const query=r.query.trim();if(query&&query.length<=160)call('content_public_research_preview',{query,confirmedPublicQuery:true});});
 root.querySelector('[data-pr-check]')?.addEventListener('click',()=>{if(r.pending)call('content_workspace_read',{requestId:r.pending.requestId},false);});
 root.querySelector('[data-pr-import]')?.addEventListener('click',()=>{const snapshot=chosen(f,workspace());if(snapshot?.state!=='received'||!r.selected.length)return;const resultRefs=snapshot.results.filter(v=>r.selected.includes(v.id)).map(v=>({id:v.id,digest:v.digest}));if(resultRefs.length===r.selected.length)call('content_public_research_import',{searchId:snapshot.id,searchDigest:snapshot.digest,resultRefs});});
}
