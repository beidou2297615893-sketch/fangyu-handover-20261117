from pathlib import Path
ROOT=Path(__file__).resolve().parent
candidate=ROOT/'candidate'
def edit(relative,pairs):
    path=candidate/relative
    value=(ROOT/'base'/relative).read_text(encoding='utf-8')
    for old,new in pairs:
        assert value.count(old)==1,(relative,old[:100],value.count(old))
        value=value.replace(old,new)
    path.write_text(value,encoding='utf-8',newline='')
edit('pages/customers.mjs',[
    ("import {openHandoff} from './customer-handoff.mjs';", "import {openHandoff} from './customer-handoff.mjs';\nimport {renderIntentCorrection,bindIntentCorrection} from './customer-intent-correction.mjs';"),
    ("${s.evidenceOpen?evidenceSummary(p):''}<div class=\"cs-detail-actions\">", "${s.evidenceOpen?evidenceSummary(p):''}${!loading&&!failed?renderIntentCorrection(state,p):''}<div class=\"cs-detail-actions\">"),
    ('function bindConnected(root,ctx){\n  bindCustomerAvatars(root);','function bindConnected(root,ctx){\n  bindCustomerAvatars(root);\n  bindIntentCorrection(root,ctx);')
])
edit('app.mjs',[("const actions={checkSourceInteractions", "const actions={intentCorrectionAction:(action,data)=>backend.intentCorrectionAction(action,data),checkSourceInteractions")])
edit('backend.mjs',[
    ("const content=action.startsWith('content_');", "const content=action.startsWith('content_');\n    // Single-comment corrections retain their own original request receipt in the\n    // detail helper. Generic bootstrap recovery must never clear that receipt.\n    const intentCorrection=['customer_intent_read','customer_intent_correct','customer_intent_cancel'].includes(action);\n    const intentRead=action==='customer_intent_read';"),
    ('const read=get||rule||content||sourceLocal||', 'const read=get||rule||content||intentCorrection||sourceLocal||'),
    ('const shortRead=get||ruleRead||contentRead||sourceRead||', 'const shortRead=get||ruleRead||contentRead||intentRead||sourceRead||'),
    ("catch { if(sourceLocal&&!sourceRead)", "catch { if(intentCorrection&&!intentRead)throw new WorkbenchError('更正结果尚未确认，请核对原操作。','CUSTOMER_INTENT_RESULT_UNCONFIRMED');if(sourceLocal&&!sourceRead)"),
    ("(remoteActions.has(action)||content||action==='source_interactions_check')&&result?.error?.mutation_committed===false", "(remoteActions.has(action)||content||intentCorrection||action==='source_interactions_check')&&result?.error?.mutation_committed===false"),
    ("if(error instanceof WorkbenchError)throw error;\n      if(sourceLocal", "if(error instanceof WorkbenchError)throw error;\n      if(intentCorrection&&!intentRead)throw new WorkbenchError('更正结果尚未确认，请核对原操作。','CUSTOMER_INTENT_RESULT_UNCONFIRMED');\n      if(sourceLocal"),
    ("return {...safety,sourceAction:", "return {...safety,intentCorrectionAction:(action,data)=>{if(!['customer_intent_read','customer_intent_correct','customer_intent_cancel'].includes(action))throw new WorkbenchError('评论更正操作无效','INPUT_INVALID');return request(action,data);},sourceAction:")
])
css=(ROOT/'base/pages/customers.css').read_text(encoding='utf-8')
css+='''
/* Single-comment correction: scoped to the customer detail, no global changes. */
.customers-page .cs-intent-correction{grid-column:1/-1;min-width:0;margin:18px 0;padding:16px;background:#f2faf9;border:1px solid #c9e3e1;border-radius:9px;color:#24485f;font-size:17px;line-height:1.6}
.customers-page .cs-correction-heading{display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:8px;font-size:19px}
.customers-page .cs-correction-heading button{font:inherit;color:#087c83;white-space:normal;text-align:left}
.customers-page .cs-correction-scope{margin:10px 0;color:#446579}
.customers-page .cs-correction-field{display:grid;gap:7px;margin:14px 0;font-weight:600}
.customers-page .cs-correction-field select,.customers-page .cs-correction-field textarea{box-sizing:border-box;width:100%;min-width:0;max-width:100%;border:1px solid #b8d7da;border-radius:6px;padding:10px;background:white;color:#24485f;font:inherit;font-weight:400;line-height:1.6}
.customers-page .cs-correction-field textarea{resize:vertical;min-height:110px}
.customers-page .cs-correction-field select{min-height:46px}
.customers-page .cs-correction-quote{margin:12px 0 6px;padding:12px;background:white;border-left:3px solid #188b91;white-space:pre-wrap;overflow-wrap:anywhere}
.customers-page .cs-correction-source{font-size:15px;color:#607b8c;margin:6px 0;overflow-wrap:anywhere}
.customers-page .cs-correction-judgment{margin:12px 0;padding:10px 0;border-top:1px solid #dcebea;overflow-wrap:anywhere}
.customers-page .cs-correction-judgment p,.customers-page .cs-correction-history p{white-space:pre-wrap;margin:5px 0}
.customers-page .cs-correction-judgment ul{padding-left:21px;margin:5px 0}
.customers-page .cs-correction-history{margin:12px 0;font-size:15px}.customers-page .cs-correction-history summary{cursor:pointer;font-weight:600}
.customers-page .cs-correction-message{margin:10px 0;color:#355b6b;overflow-wrap:anywhere}
.customers-page .cs-correction-actions{display:flex;gap:10px;align-items:center;flex-wrap:wrap}
.customers-page .cs-correction-actions button{min-height:45px;padding:10px 15px;border-radius:6px;font:inherit;line-height:1.4;white-space:normal}
.customers-page .cs-correction-actions small{flex-basis:100%;font-size:15px;color:#63798b}
.customers-page .cs-intent-correction button:disabled,.customers-page .cs-intent-correction select:disabled{opacity:.6;cursor:not-allowed}
.customers-page .cs-intent-correction :is(button,textarea,select,summary):focus-visible{outline:2px solid #008c9a;outline-offset:3px}
@media(max-width:600px){.customers-page .cs-intent-correction{padding:12px}.customers-page .cs-correction-actions button{width:100%}}
'''
(candidate/'pages/customers.css').write_text(css,encoding='utf-8',newline='')
print('candidate files prepared; source untouched')
