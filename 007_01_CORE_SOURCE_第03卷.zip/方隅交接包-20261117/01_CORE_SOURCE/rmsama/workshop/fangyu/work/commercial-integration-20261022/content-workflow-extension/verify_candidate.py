"""Run scoped synthetic checks and freeze a reviewable source-only candidate."""
from __future__ import annotations
import hashlib
import json
from pathlib import Path
import platform
import sys
import unittest
import zipfile
from datetime import datetime, timezone, timedelta

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def dump(name, value):
    (HERE / name).write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding='utf-8')

def main():
    suite = unittest.TestLoader().discover(str(HERE / 'tests'))
    with (HERE / 'FINAL-tests.log').open('w', encoding='utf-8') as stream:
        result = unittest.TextTestRunner(stream=stream, verbosity=2).run(suite)
    production = ['content_workflow.py', 'workflow_methods.py', 'workflow_knowledge.py',
                  'content_extension_loader.py', 'workflow_vendor/normalize.py',
                  'workflow_vendor/LICENSE', 'workflow_vendor/PINS.json']
    pins = {p: sha(HERE / p) for p in production}
    baseline = HERE / 'tests/baseline/content_workbench.py'
    tested = {'content_workbench.py': sha(baseline), **{p: pins[p] for p in
              ('content_workflow.py', 'workflow_methods.py', 'workflow_knowledge.py')}}
    dump('TESTED-LOADER-PINS.json', tested)
    current = Path('C:/积木软件工坊/项目/方隅公寓客户版/work/parallel-integration-20261018/final-integration/stage-02/project/work/ui-native-r57/content_workbench.py')
    receipt = {'checkedAt': datetime.now(timezone(timedelta(hours=8))).isoformat(),
        'status': 'CANDIDATE_VERIFIED_NOT_INTEGRATED' if result.wasSuccessful() else 'FAILED',
        'python': platform.python_version(), 'tests': result.testsRun,
        'failures': len(result.failures), 'errors': len(result.errors), 'skipped': len(result.skipped),
        'syntheticOnly': True, 'sameStoreAndWorkspace': True, 'newDatabase': False,
        'productionSourcePins': pins, 'testedBaselineSha256': sha(baseline),
        'currentStageBaseMatchesTested': current.is_file() and sha(current) == sha(baseline),
        'productionDataRead': False, 'productionDataModified': False, 'platformRequests': 0,
        'paidModelCalls': 0, 'realModelVerified': False, 'hostModelAdapterImplemented': False,
        'uiImplementedByThisTask': False, 'platformExecutionImplemented': False,
        'installed': False, 'newActions': ['content_methods_read', 'content_knowledge_import',
            'content_knowledge_search', 'content_task_prepare', 'content_task_run',
            'content_task_apply', 'content_package_build'],
        'openWork': ['host content model gateway and original-key reconciliation',
                     'frontend/HTTP/CSRF/auth/lock integration', 'trusted freeze and install',
                     'real model quality and real platform validation']}
    dump('VERIFICATION.json', receipt)
    if not result.wasSuccessful():
        print(json.dumps({k: receipt[k] for k in ('status','tests','failures','errors','skipped')}, ensure_ascii=False))
        return 1
    package_files = production + ['README.md', 'METHODS.md', 'KNOWLEDGE.md',
                                  'TESTED-LOADER-PINS.json', 'VERIFICATION.json']
    dump('CANDIDATE-FILES.json', {'scope': 'New source-only additions; retain host base/vendor, never copy tests Store to production.',
                                 'files': [{'path': p, 'sha256': sha(HERE / p)} for p in package_files]})
    with zipfile.ZipFile(HERE / 'content-workflow-candidate.zip', 'w', compression=zipfile.ZIP_DEFLATED) as archive:
        for name in package_files + ['CANDIDATE-FILES.json']:
            archive.write(HERE / name, name)
    all_files = [{'path': str(p.relative_to(HERE)), 'sha256': sha(p)} for p in sorted(HERE.rglob('*'))
                 if p.is_file() and p.name != 'FILES-SHA256.json' and '__pycache__' not in p.parts]
    dump('FILES-SHA256.json', {'files': all_files, 'testLog': 'FINAL-tests.log',
                             'sourceCandidate': 'content-workflow-candidate.zip'})
    print(json.dumps({k: receipt[k] for k in ('status','python','tests','failures','errors','skipped',
                                             'currentStageBaseMatchesTested')}, ensure_ascii=False))
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
