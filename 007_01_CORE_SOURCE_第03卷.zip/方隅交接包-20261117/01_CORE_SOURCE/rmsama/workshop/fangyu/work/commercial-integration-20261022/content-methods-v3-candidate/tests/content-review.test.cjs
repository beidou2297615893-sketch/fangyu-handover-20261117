'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const {fixture, memoryDb, loadActualModules, IDS, NOW, SECRET} = require('./cloud-fixture.cjs');
const {methodDigest} = require('../cloud/content_methods.cjs');
const {ProviderError} = require('../cloud/ai_provider.cjs');
const hash = value => crypto.createHash('sha256').update(value).digest('hex');
const DATA = {query: '为虚构账号梳理人设', instructions: '只写待审核候选', persona: {}, topic: null,
  draft: null, evidence: [], artifacts: []};
const OUTPUT = {summary: '虚构账号的人设候选', facts: [], hypotheses: ['定位需要人工确认'],
  artifact: {name: '虚构账号', positioning: '面向新手分享整理经验', audience: '需要基础整理方法的读者',
    pillars: ['整理步骤'], voice: ['直接'], avoid: ['绝对保证']}};
function synthetic(request, output = OUTPUT) {
  return {model: request.model, ...(request.provider === 'openai' ? {service_tier: 'default'} : {}),
    usage: request.provider === 'openai'
      ? {prompt_tokens: 100, completion_tokens: 50, total_tokens: 150,
        prompt_tokens_details: {cached_tokens: 0}, completion_tokens_details: {reasoning_tokens: 0}}
      : {prompt_tokens: 100, prompt_cache_hit_tokens: 20, prompt_cache_miss_tokens: 80, completion_tokens: 50},
    choices: [{finish_reason: 'stop', message: {content: JSON.stringify(output)}}]};
}
async function payload(f, overrides = {}) {
  const {config} = await f.profile();
  const raw = JSON.stringify(DATA);
  return {environment_id: IDS.env, operation: 'content_generate', request_id: 'review-original-key',
    submission_id: crypto.randomUUID(), task_id: 'review-task-a',
    scope: {tenant_id: IDS.tenant, store_id: IDS.store, account_id: IDS.account, platform: 'xiaohongshu',
      company_id: IDS.company, actor: IDS.actor}, method_id: 'persona', method_digest: methodDigest('persona'),
    input_json: raw, input_digest: hash(raw), expected_device_id: IDS.device,
    expected_revision: config.revision, expected_rules_version: config.rules_version, ...overrides};
}
function changedInput(original, data) {
  const input_json = JSON.stringify(data);
  return {...original, input_json, input_digest: hash(input_json)};
}
function options(quota) {
  return {policy: {package: 'team', features: ['acquisition', 'intent_analysis', 'export', 'handoff', 'strategy', 'team'],
    analysis_quota: quota, seat_limit: 100, store_limit: 100, billing_period: 'pilot'},
    servicePeriod: {id: 'fixture-review-period', start_at: NOW / 1000 - 60, end_at: NOW / 1000 + 86400}};
}
function intent(key, count = 1) {
  return {request_id: key, city: '杭州', area: '滨江',
    post: {id: 'review-post', title: '杭州租房讨论', text: '租房避坑经验'},
    comments: Array.from({length: count}, (_, i) => ({id: `comment-${i}`, text: '下个月想租一室一厅',
      published_at: '2026-10-22', ip_location: '浙江'}))};
}
function businessProvider(request) {
  const input = JSON.parse(request.messages[1].content);
  if (input.business_data) return synthetic(request);
  return synthetic(request, {results: input.comments.map(comment => ({id: comment.id, status: 'graded', level: 'high',
    evidence: ['下个月想租'], reason: '本人表达求租条件', region_status: 'unknown', content_region: '', key_info: []}))});
}
function heldProvider() {
  let release, started;
  const waiting = new Promise(resolve => {release = resolve;});
  const began = new Promise(resolve => {started = resolve;});
  return {release, began, provider: async request => {started(); await waiting; return synthetic(request);}};
}
function unavailable(response) {
  assert.equal(response.data.content_generation?.result_available ?? false, false);
  assert.equal(Object.hasOwn(response.data.content_generation || {}, 'output'), false);
  assert.equal(JSON.stringify(response).includes(SECRET), false);
}
const statusFor = (f, p, token = f.staff) => f.call('content_generate_status',
  {...p, operation: 'content_generate_status'}, token);

test('unknown original input cannot dispatch again through same/new key, JSON key order, copied task, config change or restart', async () => {
  const f = await fixture({...options(3), replay: true, provider: async () => {
    throw new ProviderError('AI_PROVIDER_TIMEOUT');
  }});
  const p = await payload(f);
  assert.equal((await f.call('content_generate', p)).status, 502);
  assert.equal(f.calls(), 1);
  const status = await statusFor(f, p);
  assert.equal(status.data.content_generation.state, 'unknown');
  assert.equal(status.data.content_generation.reservation_retained, true);
  const reordered = Object.fromEntries(Object.entries(DATA).reverse());
  const candidates = [p, {...p, request_id: 'review-new-key-a'},
    changedInput({...p, request_id: 'review-order-key'}, reordered),
    {...p, request_id: 'review-new-task-key', task_id: 'review-copied-task'}];
  for (const candidate of candidates) {
    const response = await f.call('content_generate', candidate);
    assert.ok(response.status >= 400);
    unavailable(response);
  }
  assert.equal((await f.call('ai_config_save', {config: {rules_version: 'review-rules-changed'}}, f.admin)).status, 200);
  const fresh = await payload(f, {request_id: 'review-config-new-key', task_id: 'review-other-task'});
  assert.ok((await f.call('content_generate', fresh)).status >= 400);
  f.restart();
  f.advance(3 * 60 * 1000);
  assert.ok((await f.call('content_generate', fresh)).status >= 400);
  assert.equal(f.calls(), 1);
  const [quota] = f.memory.rows('fangyu_product_quota_periods');
  assert.equal(quota.reserved_units, 1);
  assert.equal(quota.unknown_units, 1);
  assert.equal(quota.confirmed_units, 0);
  assert.equal(f.memory.rows('fangyu_ai_budget')[0].spent_micro, 0);
  assert.ok(f.memory.rows('fangyu_ai_budget')[0].reserved_micro > 0);
});

test('content costs one existing quota slot, cached content costs zero, and original intent analysis shares the same quota and money', async () => {
  const f = await fixture({...options(3), provider: businessProvider});
  const p = await payload(f);
  assert.equal((await f.call('content_generate', p)).status, 200);
  const cached = await f.call('content_generate', {...p, request_id: 'review-cache-key'});
  assert.equal(cached.status, 200);
  assert.equal(cached.data.content_generation.cache_hit, true);
  assert.equal(f.calls(), 1);
  const analyzed = await f.call('intent_analyze', intent('review-intent-key', 2));
  assert.equal(analyzed.status, 200);
  assert.equal(f.calls(), 2);
  const [quota] = f.memory.rows('fangyu_product_quota_periods');
  assert.equal(quota.confirmed_units, 3);
  assert.equal(quota.reserved_units, 0);
  const quotaRows = f.memory.rows('fangyu_product_quota_requests');
  assert.equal(quotaRows.find(row => row.request_key === p.request_id).amount, 1);
  assert.equal(quotaRows.find(row => row.request_key === 'review-cache-key').amount, 0);
  assert.equal(quotaRows.find(row => row.request_key === 'review-intent-key').amount, 2);
  const denied = await f.call('content_generate', changedInput({...p, request_id: 'review-no-slots'}, {...DATA, query: '另一项虚构定位'}));
  assert.equal(denied.status, 429);
  assert.equal(denied.data.code, 'PRODUCT_ANALYSIS_LIMIT');
  assert.equal(f.calls(), 2);
  const budgets = f.memory.rows('fangyu_ai_budget');
  assert.equal(budgets.length, 1);
  assert.equal(budgets[0].request_count, 2);
  assert.equal(budgets[0].spent_micro,
    f.memory.rows('fangyu_ai_ledger').reduce((sum, row) => sum + row.actual_cost_micro, 0));
});

test('unknown content holds shared quota and daily budget against original intent operations', async () => {
  const f = await fixture({...options(1), provider: async () => {throw new ProviderError('AI_PROVIDER_TIMEOUT');}});
  const p = await payload(f);
  assert.equal((await f.call('content_generate', p)).status, 502);
  const quotaDenied = await f.call('intent_analyze', intent('review-intent-denied'));
  assert.equal(quotaDenied.status, 429);
  assert.equal(quotaDenied.data.code, 'PRODUCT_ANALYSIS_LIMIT');
  assert.equal((await f.call('ai_config_save', {config: {daily_budget_cny: 0}}, f.admin)).status, 200);
  const moneyDenied = await f.call('intent_analyze', intent('review-intent-money-denied'));
  assert.equal(moneyDenied.status, 429);
  assert.equal(moneyDenied.data.code, 'AI_DAILY_BUDGET');
  assert.equal(f.calls(), 1);
});

test('content status is strictly read-only for missing/success/stale/failed-auth results, including housekeeping', async () => {
  const f = await fixture({provider: businessProvider});
  const p = await payload(f);
  assert.equal((await f.call('content_generate', p)).status, 200);
  await f.changeTrustedState(state => {
    state.attempts['fixture-expired'] = {count: 1, until: 1};
    state.sessions.push({username: 'fixture-expired', digest: 'expired', expires: 1});
    state.rememberedDevices.push({username: 'fixture-expired', deviceId: 'expired', digest: 'expired', idleExpires: 1, absoluteExpires: 1});
  });
  let before = f.memory.snapshot(), writes = f.memory.stats().committedWrites;
  const found = await statusFor(f, p);
  assert.equal(found.status, 200);
  assert.equal(found.data.content_generation.result_available, true);
  assert.equal(found.data.content_generation.read_only, true);
  assert.equal(found.data.mutation_committed, false);
  const fixtureStatus = await f.readStatus(p);
  assert.equal(fixtureStatus.status, 200, 'fixture readStatus must force a genuine status operation');
  assert.equal(fixtureStatus.data.content_generation.read_only, true);
  const missing = await statusFor(f, {...p, request_id: 'review-missing-original'});
  assert.equal(missing.status, 200);
  assert.equal(missing.data.content_generation.state, 'unknown');
  assert.equal(missing.data.content_generation.execution_confirmed, null);
  assert.equal(missing.data.content_generation.reservation_retained, null);
  assert.equal(missing.data.content_generation.retry_allowed, false);
  assert.equal(missing.data.content_generation.coverage, 'legacy_untracked');
  unavailable(missing);
  const denied = await statusFor(f, p, '');
  assert.equal(denied.status, 401);
  assert.deepEqual(f.memory.snapshot(), before);
  assert.equal(f.memory.stats().committedWrites, writes);
  await f.call('ai_config_save', {config: {rules_version: 'review-status-stale'}}, f.admin);
  before = f.memory.snapshot(); writes = f.memory.stats().committedWrites;
  unavailable(await statusFor(f, p));
  assert.deepEqual(f.memory.snapshot(), before);
  assert.equal(f.memory.stats().committedWrites, writes);
});

test('cold-store content status never initializes an administrator or workspace', async () => {
  const configured = await fixture({provider: businessProvider});
  const p = await payload(configured);
  const memory = memoryDb(), {createStore, createService} = loadActualModules();
  const service = createService({store: createStore(memory.db, IDS.company), companyId: IDS.company,
    environmentId: IDS.env, initialAdmin: IDS.admin, initialPassword: 'Fixture-Only-Password-12345',
    contentGeneration: {enabled: true, tenantId: IDS.tenant, revision: 1}, aiProvider: businessProvider});
  const before = memory.snapshot();
  const response = await service({...p, operation: 'content_generate_status'}, '');
  assert.equal(response.status, 503);
  assert.equal(response.data.read_only, true);
  assert.equal(response.data.mutation_committed, false);
  assert.deepEqual(memory.snapshot(), before);
  assert.equal(memory.stats().committedWrites, 0);
});

for (const variant of ['disabled-user', 'role', 'store', 'device', 'device-owner', 'claim', 'config', 'feature']) {
  test(`in-flight ${variant} change still settles known usage but never exposes reusable content`, async () => {
    const gate = heldProvider(), settings = options(5);
    const f = await fixture({...settings, provider: gate.provider});
    const p = await payload(f), running = f.call('content_generate', p);
    const started = await Promise.race([gate.began.then(() => true), running.then(() => false)]);
    assert.equal(started, true);
    try {
      if (variant === 'config') await f.call('ai_config_save', {config: {rules_version: 'review-midflight'}}, f.admin);
      else if (variant === 'feature') settings.policy.features = settings.policy.features.filter(feature => feature !== 'strategy');
      else await f.changeTrustedState(state => {
        const actor = state.users.find(row => row.username === IDS.actor);
        if (variant === 'disabled-user') actor.disabled = true;
        if (variant === 'role') actor.role = 'origin_partner';
        if (variant === 'store') actor.store_id = 'fixture-store-b';
        if (variant === 'device') state.devices[0].revoked = true;
        if (variant === 'device-owner') state.devices[0].owner = IDS.admin;
        if (variant === 'claim') state.xhs_claims[0].uid_hash = hash('fixture-platform-uid-changed');
      });
    } finally {gate.release();}
    const response = await running;
    unavailable(response);
    assert.equal(f.calls(), 1);
    const [ledger] = f.memory.rows('fangyu_ai_ledger'), [budget] = f.memory.rows('fangyu_ai_budget');
    assert.ok(ledger.actual_cost_micro > 0);
    assert.equal(ledger.reservation_retained, false);
    assert.ok(budget.spent_micro > 0);
    assert.equal(budget.reserved_micro, 0);
    assert.equal(f.memory.rows('fangyu_product_quota_periods')[0].confirmed_units, 1);
    const before = f.memory.snapshot();
    unavailable(await statusFor(f, p));
    assert.deepEqual(f.memory.snapshot(), before);
    if (!['config', 'feature'].includes(variant))
      assert.equal(f.memory.rows('fangyu_ai_cache').some(row => row.status === 'ready'), false);
  });
}

test('server defaults disabled, absent trusted bindings and douyin never dispatch, and errors/metadata exclude provider secrets', async () => {
  for (const contentOptions of [null, {enabled: false, tenantId: IDS.tenant, revision: 1}]) {
    const f = await fixture({contentOptions, provider: businessProvider});
    const response = await f.call('content_generate', await payload(f));
    assert.equal(response.status, 503); unavailable(response); assert.equal(f.calls(), 0);
  }
  const f = await fixture({provider: async () => {throw new Error(`private transport failed ${SECRET}`);}});
  const p = await payload(f);
  const douyin = await f.call('content_generate', {...p, scope: {...p.scope, platform: 'douyin'}});
  assert.equal(douyin.status, 403); unavailable(douyin); assert.equal(f.calls(), 0);
  await f.changeTrustedState(state => {state.xhs_claims = [];});
  const noClaim = await f.call('content_generate', p);
  assert.equal(noClaim.status, 403); unavailable(noClaim); assert.equal(f.calls(), 0);
  const errorFixture = await fixture({provider: async () => {throw new Error(`private transport failed ${SECRET}`);}});
  const original = await payload(errorFixture);
  const failed = await errorFixture.call('content_generate', original);
  assert.equal(failed.status, 502); unavailable(failed);
  const status = await statusFor(errorFixture, original); unavailable(status);
  assert.equal(JSON.stringify(await errorFixture.profile(errorFixture.admin)).includes(SECRET), false);
  assert.equal(JSON.stringify(await errorFixture.profile()).includes(SECRET), false);
});
