# 第二版交接

本轮只写content-model-gateway目录。实际云、原workspace、Native、stage、其他作者候选和真实数据未改。第一版ZIP原摘要dd15bb0264078058b0457e3e83da7b1ac31a310a23506a6149515d3c2ca4d3f9保留，本轮已由第二版替代。

真实基线：官方只读取码ZIP 976de75d98b4aa72cad06b786c3c7eeea71f54ccbdb4957c4ce2d1f4b120e0ac，19源码匹配10月19日after-QeaHL2。旧27文件快照与原件未改，但不再是补丁生产基线。

已修复：HQ无需固定店的中央多店授权；operator原单店限制；记住登录安装ID与平台执行设备分开；生成前后中央catalog/grant/账号设备复核；运行中撤店/撤设备照实结算usage并永久丢弃候选；合法续期仍可按原键读回同一未变授权结果。profile只读、默认关闭、缺失原因准确，合同见PROFILE-CONTRACT.md。

相对真实部署修改5文件、新增7云文件和3客户端文件。原键恢复、服务额度和发布规则模块是待审基础增量，当前线上没有。现行已批准默认规则、提供者、模型价格与原中央只读路由保留。无无关获客模块夹带。

验证：新增154通过；历史核心107/115，8项旧提示词/版本断言在真实线上逐项同样失败；原service基线和候选均8/8；Python29/29；方法导出通过。首次漏NODE_PATH和基线测试空assets目录缺失属于测试装配错误，保留日志，不冒充业务红测。业务红绿为RED/GREEN-central-HQ与RED/GREEN-remembered-device。

采用前读DEPLOYMENT-READINESS.md、PROFILE-CONTRACT.md及最终DELIVERY/PATCH-MANIFEST/CANDIDATE-FILES。integration.patch以cloud/为相对根，在独立当前真实源码准备副本合并。与总控最新P1中央撤店/P2归档保护逐块对照，不整文件覆盖。build工具仅在本目录work试装并核对生产依赖导入。

真实私有身份映射、服务器内容策略状态仍未知，未读取或更改。新API未部署，Native接线及公开reconcile由对应作者完成；真实Node20.19/CloudBase、模型质量和平台动作未验。本轮无真实模型、付费、新权限或生产部署。

补丁试装已按原始CRLF/LF保存并逐字节核对所有12个云改动文件，生产依赖导入通过。最初按文本正规化换行会破坏方法目录固定摘要，现已在打包工具修复；源方法和客户端pins未更改。总控仍应冻结自己最终合并字节。
