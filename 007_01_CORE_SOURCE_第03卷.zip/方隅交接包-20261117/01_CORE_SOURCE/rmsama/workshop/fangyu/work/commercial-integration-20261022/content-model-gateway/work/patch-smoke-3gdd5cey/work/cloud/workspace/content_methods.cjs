'use strict';
// Trusted static contracts only. Business evidence never becomes system instructions here.
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { types } = require('node:util');

const SOURCE_SHA256 = '60806e678ed6a96a7f3a7a3116a20024e97ac648f59c16cf5cf0eb8838e6b094';
const CATALOG_BYTES_SHA256 = '9a5dce493758bae88bcbf4e747807790e4505fb77f45f438e1363cf45a00bfdd';
const CATALOG_DIGEST = '5a3696cd2be46b9cf24d9be8db2e823af7860226efb4fb515a466596d36f8b31';

function failure(reason, code = 'CONTENT_OUTPUT_INVALID') {
  const error = new Error('Content method contract validation failed');
  error.code = code;
  error.reason = reason;
  error.status = 400;
  return error;
}

let catalog;
try {
  const bytes = fs.readFileSync(path.join(__dirname, 'content-methods.json'));
  if (crypto.createHash('sha256').update(bytes).digest('hex') !== CATALOG_BYTES_SHA256) throw new Error();
  catalog = JSON.parse(bytes.toString('utf8'));
  if (catalog.source.sha256 !== SOURCE_SHA256 || catalog.catalogDigest !== CATALOG_DIGEST
      || catalog.schemaVersion !== 1 || catalog.methodOrder.length !== 17) throw new Error();
} catch (_) {
  throw failure('catalog_pin_mismatch', 'CONTENT_METHOD_CATALOG_CHANGED');
}

function specFor(id) {
  if (typeof id !== 'string' || !Object.hasOwn(catalog.methods, id)) throw failure('unknown_method', 'CONTENT_METHOD_UNKNOWN');
  return catalog.methods[id];
}

function clone(value) { return JSON.parse(JSON.stringify(value)); }
function getMethod(id) { return clone(specFor(id)); }
function methodDigest(id) { specFor(id); return catalog.methodDigests[id]; }

function plainObject(value) {
  return value !== null && typeof value === 'object' && !types.isProxy(value) && !Array.isArray(value)
    && (Object.getPrototypeOf(value) === Object.prototype || Object.getPrototypeOf(value) === null);
}

function dataKeys(value) {
  if (!plainObject(value)) throw failure('invalid_object');
  const keys = Reflect.ownKeys(value);
  for (const key of keys) {
    if (typeof key !== 'string') throw failure('invalid_fields');
    const descriptor = Object.getOwnPropertyDescriptor(value, key);
    if (!descriptor || !descriptor.enumerable || !Object.hasOwn(descriptor, 'value')) throw failure('invalid_object_property');
  }
  return keys;
}

function plainArray(value, schema) {
  if (types.isProxy(value) || !Array.isArray(value) || Object.getPrototypeOf(value) !== Array.prototype
      || value.length < schema.minItems || value.length > schema.maxItems) throw failure('invalid_list');
  const keys = Reflect.ownKeys(value);
  if (keys.length !== value.length + 1) throw failure('invalid_list_property');
  for (let i = 0; i < value.length; i++) {
    const descriptor = Object.getOwnPropertyDescriptor(value, String(i));
    if (!descriptor || !descriptor.enumerable || !Object.hasOwn(descriptor, 'value')) throw failure('invalid_list_property');
  }
  return value;
}

function inRanges(codePoint, ranges) {
  let low = 0; let high = ranges.length - 1;
  while (low <= high) {
    const middle = (low + high) >>> 1;
    if (codePoint < ranges[middle][0]) high = middle - 1;
    else if (codePoint > ranges[middle][1]) low = middle + 1;
    else return true;
  }
  return false;
}

const unicode = catalog.unicodeRules;
const DIGITS = '[' + unicode.decimalDigitRanges.map(([a, b]) =>
  '\\u{' + a.toString(16) + '}' + (a === b ? '' : '-\\u{' + b.toString(16) + '}')).join('') + ']';
const patterns = new Map();
function fullMatch(pattern, value) {
  if (!patterns.has(pattern)) patterns.set(pattern, new RegExp('^(?:' + pattern.replace(/\\d/g, DIGITS) + ')$', 'u'));
  const matched = patterns.get(pattern).exec(value);
  return matched !== null && matched[0] === value;
}

function validate(schema, value, outputText = true) {
  const kind = schema.type;
  if (kind === 'object') {
    const keys = dataKeys(value);
    if (keys.length !== schema.required.length || keys.some(key => !Object.hasOwn(schema.properties, key))) throw failure('invalid_fields');
    for (const key of schema.required) {
      if (!Object.hasOwn(value, key)) throw failure('invalid_fields');
      validate(schema.properties[key], value[key], outputText);
    }
  } else if (kind === 'array') {
    for (const item of plainArray(value, schema)) validate(schema.items, item, outputText);
  } else if (kind === 'string') {
    if (typeof value !== 'string' || value.length > schema.maxLength * 2) throw failure('invalid_string');
    const chars = Array.from(value);
    if (chars.length < schema.minLength || chars.length > schema.maxLength) throw failure('invalid_string');
    if (schema.minLength && chars.every(c => inRanges(c.codePointAt(0), unicode.whitespaceRanges))) throw failure('empty_string');
    if (outputText && chars.some(c => {
      const cp = c.codePointAt(0);
      return inRanges(cp, unicode.forbiddenOutputRanges) || (cp < 32 && !unicode.allowedC0Controls.includes(cp));
    })) throw failure('invalid_text_characters');
    if (schema.enum && !schema.enum.includes(value)) throw failure('invalid_choice');
    if (schema.pattern && !fullMatch(schema.pattern, value)) throw failure('invalid_pattern');
  } else if (kind === 'number' || kind === 'integer') {
    if (typeof value !== 'number' || !Number.isFinite(value) || (kind === 'integer' && !Number.isInteger(value))
        || value < schema.minimum || value > schema.maximum) throw failure('invalid_number');
  } else throw failure('invalid_schema', 'CONTENT_METHOD_CATALOG_CHANGED');
}

function asciiJsonLength(value) {
  function separatorSpaces(node) {
    if (Array.isArray(node)) return Math.max(0, node.length - 1) + node.reduce((n, child) => n + separatorSpaces(child), 0);
    if (plainObject(node)) {
      const keys = Object.keys(node);
      return keys.length + Math.max(0, keys.length - 1) + keys.reduce((n, key) => n + separatorSpaces(node[key]), 0);
    }
    return 0;
  }
  return JSON.stringify(value).replace(/[\u007f-\uffff]/g, char => '\\u' + char.charCodeAt(0).toString(16).padStart(4, '0')).length
    + separatorSpaces(value);
}

function validateContentOutput(id, value, evidence) {
  const spec = specFor(id);
  validate(spec.outputSchema, value);
  const evidenceKeys = dataKeys(evidence);
  if (evidenceKeys.length > 1000) throw failure('invalid_evidence');
  const stringSchema = limit => ({ type: 'string', minLength: 1, maxLength: limit });
  const recordSchema = { type: 'object', required: ['text', 'kind'], additionalProperties: false,
    properties: { text: stringSchema(20000), kind: stringSchema(40) } };
  const sources = new Map();
  for (const key of evidenceKeys) {
    validate(stringSchema(120), key);
    validate(recordSchema, evidence[key], false);
    sources.set(key, evidence[key]);
  }
  for (const fact of value.facts) {
    const source = sources.get(fact.evidenceId);
    if (!source || source.kind !== 'fact' || !source.text.includes(fact.quote)) throw failure('unsupported_fact_quote');
  }
  function checkReferences(node) {
    if (Array.isArray(node)) for (const child of node) checkReferences(child);
    else if (plainObject(node)) for (const [key, child] of Object.entries(node)) {
      if (key === 'evidenceIds' || key === 'sourceEvidenceIds') {
        if (child.some(ref => !sources.has(ref))) throw failure('unknown_evidence_reference');
      } else checkReferences(child);
    }
  }
  checkReferences(value.artifact);
  if (asciiJsonLength(value) > 2000000) throw failure('result_too_large');
  return clone(value);
}

module.exports = Object.freeze({ getMethod, methodDigest, validateContentOutput,
  validateOutput: validateContentOutput, CATALOG_DIGEST });
