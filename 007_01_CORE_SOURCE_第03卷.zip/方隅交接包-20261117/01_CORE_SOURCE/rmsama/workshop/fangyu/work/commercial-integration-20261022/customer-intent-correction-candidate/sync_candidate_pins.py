from pathlib import Path
import hashlib,re
W=Path(__file__).parent;C=W/'candidate'
p=C/'work/ui-native-r57/customer_workbench.py';text=p.read_text('utf-8')
for name in ('business.py','ai_workflow.py','intent_correction.py'):
    source=C/'work/ui-runtime-r55/src/assistant'/name;sha=hashlib.sha256(source.read_bytes()).hexdigest().upper()
    text,n=re.subn(r"('assistant/"+re.escape(name)+r"':')[A-F0-9]{64}",r'\g<1>'+sha,text);assert n==1
    target=W/'source-view/work/ui-runtime-r55/src/assistant'/name;target.write_bytes(source.read_bytes())
p.write_text(text,'utf-8')
print('Candidate source pins synchronized')
