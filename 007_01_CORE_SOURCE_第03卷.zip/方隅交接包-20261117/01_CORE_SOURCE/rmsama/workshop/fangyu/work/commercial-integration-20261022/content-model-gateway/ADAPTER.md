Python 内容生成适配器已完成离线验证。真实内容工作区的原任务经适配器进入真实云服务业务代码，严格核对输出后回到同一个 Store，并能生成保留引用的待审稿和审核包。本轮没有连接真实模型服务、使用真实凭据、部署云函数或接入 Native。

运行入口为 `client.gateway_adapter.ContentGatewayAdapter`。必须由宿主注入已有鉴权闭包中的 `transport(payload)` 和 `trusted_context()`；缺少任一回调即抛出 `GatewayConfigurationError`，没有可运行的默认网络传输器。

```python
from client import ContentGatewayAdapter

# 两个函数均由宿主现有鉴权与云请求链提供。
adapter = ContentGatewayAdapter(
    transport=host_content_transport,
    trusted_context=host_trusted_content_context,
)
workbench = ContentWorkflowWorkbench(existing_store, model_adapter=adapter)

# 只读核对必须显式发起，保留当时完整 envelope 与原请求键。
result = adapter.status(original_envelope)
```

`transport(payload)` 返回恰好 `{status: int, data: dict}`。`trusted_context()` 返回恰好以下十项：`environment_id`、`company_id`、`tenant_id`、`store_id`、`account_id`、`platform`、`actor`、`device_id`、`expected_revision`、`expected_rules_version`。这些值来自宿主可信状态，不能直接使用页面传入值。每次请求前后都重新调用该回调；期间任何值变化都会隐藏输出并返回 `unknown`。云端仍须独立执行真实权限、设备、版本、功能开关与预算检查。

适配器向核心仅返回以下三种形状，不增加执行证明、计费结论或模型参数：

```text
{requestId, state: "succeeded", output}
{requestId, state: "known_not_executed"}
{requestId, state: "unknown"}
```

入站 envelope 的完整方法说明和 schema 必须匹配固定的 17 项可信方法。可信目录从已经核对字节的 `workflow_methods.py` 生成；运行时不从当前工作目录或原 extension 动态导入方法。适配器先验证同目录 `trusted_method_pins.py` 的硬编码 SHA256，再直接编译同一份已验证字节，避免先校验后另行读取。修改该文件会在模块加载时明确失败。

| 固定对象 | SHA256 |
| --- | --- |
| 方法权威源 workflow_methods.py | `60806e678ed6a96a7f3a7a3116a20024e97ac648f59c16cf5cf0eb8838e6b094` |
| 嵌入目录 Python canonical 摘要 | `1543dcaba765e55e41b2ed9dfb8761a9edae994a31e7bb5d6c1b7f9b04a59d77` |
| trusted_method_pins.py 文件 | `7e4809836daea4a9426621c3a67d4d6508a50d2a1a7aacbeaafe53f8a8d1b092` |

方法包括 strategy、persona、homepage、research、topics、columns、writing、video、visual、knowledge、revision、audit、package、scheduling、engagement、growth、learning。每个方法的完整 spec 和 Python canonical digest 均固定；测试逐项证明实际派发其对应 method_id 与 digest。

业务输入使用 `json.dumps(input, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False)` 生成原文 JSON，UTF-8 摘要必须等于 envelope 的 `inputDigest`，上限 160000 字节。服务校验原 JSON 字节摘要，不能先在 JavaScript 解析后重新序列化来替代。真实服务测试已覆盖 `1.0`、中文和 emoji 的跨语言差异。

输出上限与固定核心 `_json_size` 一致：`json.dumps(output, ensure_ascii=False, allow_nan=False)` 的 UTF-8 字节数不得超过 120000；该判断保留 Python 默认分隔符中的空格，不使用 compact JSON 长度替代。单测覆盖正好上限，以及默认格式超出一字节、compact 格式仍低于上限的拒绝情况。服务的原模型文本解析上限与最终结构化业务输出上限由服务分别控制。

请求 wire 恰好包含：`environment_id`、`operation`、`request_id`、`submission_id`、`scope`、`task_id`、`method_id`、`method_digest`、`input_json`、`input_digest`、`expected_device_id`、`expected_revision`、`expected_rules_version`。`operation` 仅为 `content_generate` 或 `content_generate_status`。每次生成或查询都会创建新的 UUID4 `submission_id`，原始 `request_id`、task、scope、method 和 input 绑定不变。不发送方法 instructions/schema/system、model、key 或 endpoint 等顶层控制字段；业务 `input.instructions` 仍属于不可信内容数据。

接收结果时先核对外层工作区 contract、环境与公司，再核对 generation contract、原请求、任务、输入摘要、固定方法摘要与完整 scope。服务返回 `retry_allowed` 必须严格为 false，`read_only` 必须与本次操作匹配。`coverage` 必须为 `stable_request_index_v1` 或 `current_submission`；后者还必须回显本次 submission UUID。

成功必须同时满足 HTTP 200、`state=succeeded`、`result_available=true`、`execution_confirmed=true`、`reservation_retained=false` 和可用输出。未结清的预留不会安装候选。输出的业务 schema、引用真实性和不含执行字段，由真实服务和原核心各自检查，适配器不替代二者。

`known_not_executed` 必须有完整绑定的服务器证明：`execution_confirmed=false`、`reservation_retained=false`、`result_available=false`、无输出，并满足上述 coverage 约束。带证明的预算拒绝可使用 HTTP 402；HTTP 错误本身不能证明未执行。超时、异常、无证明拒绝、completed_no_result、旧结果、版本不符及其他情况均返回 `unknown`，不暴露无效模型文本和内部异常。

服务器可选恢复信息 `context_digest`、`config_revision`、`rules_version`、`requires_revalidation`、`cache_hit` 已按最终服务协议支持。存在时分别校验摘要形状、当前版本、当前规则、严格 false 和布尔类型。需要重验的输出不会返回为成功。预算拒绝可以不带这些可选项。

适配器没有自动重试、自动查询、HTTP 客户端、权限库或凭据读取。模块初始化只读取固定的同目录方法文件；请求期间的外部能力完全来自宿主回调。传输异常也只会发起一次 transport 调用。status 是显式只读操作，不能转换成新一次 generate。

本地原任务处于 `unknown` 时，即使云端按原键已查回成功，适配器也不会私自写入 Store。现有 extension 没有公开的恢复结果入库动作；Native 接入仍需实现经过原账号权限、task/input/method/版本复核的 reconcile 动作。完整链测试明确证明：成功响应丢失后，两次 status 均可读回云端结果，提供方调用仍为一次，本地原任务和无候选状态保持原样。不可用换请求键重跑或绕开公开权限直接保存结果来填补此缺口。

验证文件为 `tests/test_gateway_adapter.py`、`tests/test_full_chain.py` 和仅供测试的 `tests/node_bridge.cjs`。桥使用实际 `createService` 与 root 提供的测试 fixture，网络入口被禁止，合成 provider 必须显式传入 fixtureOutput；生产适配器没有默认文案或模型替代物。

- 适配器 23 项通过：17 方法实际派发、上下文双检、完整方法固定、输入摘要、只读状态、未执行证明、版本元数据、输出大小边界、结算状态、固定路径加载与无自动重试等。
- 完整链 6 项通过：原任务产物→草稿审核→保留引用的审核包；预算不足无模型调用；超时保留预算；伪引用拒绝且无候选；响应丢失后同键只读恢复；Python 小数和 Unicode 原文字节。
- 所有完整链测试均使用同一个真实 Store 和既有工作区，保留虚构客户等既有业务记录；模型调用在数据库事务之外。测试不把技术成功当作内容认可、真实云端验证或真实发布。

源与运行时证据全部保存在本项目 `work/adapter-*`。固定 extension/core 与原 55 项测试的公共 Store fixture 按源字节摘要复制到测试快照；唯一适配为将 fixture 的 temp_root 指向本网关 `work/adapter-runtimes`。原 extension 源、测试与 work 均未修改。`work/adapter-extension-source-pins.json` 记录快照来源与实际字节摘要，MIT 知识切片闭包也逐文件固定。

`work/adapter-logs` 保留先红后绿证据。`RED-full-chain.log` 记录最初实际服务恢复元数据导致的拒绝，随后按协议严格支持后主链通过；`RED-output-contract.log` 是中间输出策略的历史证据，最终策略以 `RED-core-output-spacing.log`、`GREEN-core-output-spacing.log` 和最终汇总测试为准。`SETUP-full-chain-snapshot-path.log` 单独保留一次快照布局修正，不作为业务验收失败。最终文件清单与测试结果见 `work/adapter-files.sha256.json`、`work/adapter-verification.json`。


第二版接入前另读PROFILE-CONTRACT.md。真实profile缺字段或非显式可用不得启用；执行device_id取现有platform service绑定，不取记住软件登录安装ID。新增profile字段留在宿主门禁，适配器精确10项上下文和wire字段不变。
