from pathlib import Path
W=Path(__file__).resolve().parent
s=(W/'test_factory_schedule.py').read_text('utf-8')
anchor="            elif case=='contention':"
assert s.count(anchor)==1
extra='''            elif case=='independent-claims':
                from concurrent.futures import ThreadPoolExecutor
                sessions.clear();controls['mode']='unknown';target,d=setup_account(2);r=arm(target,plan(target,d))['schedule']
                gate=threading.Barrier(2)
                def same_claim(index):
                    gate.wait(5);return tick(target,r)
                with ThreadPoolExecutor(max_workers=2) as pool:answers=list(pool.map(same_claim,(1,2)))
                unknown=read(target,r)
                assert unknown['state']=='unknown' and dispatches()==1 and unknown['intentId']==r['intentId'] and unknown['publishRequestId']==r['publishRequestId']
                assert all(a['intentId']==r['intentId'] and a['publishRequestId']==r['publishRequestId'] for a in answers)
                before=state();tick(target,unknown);assert state()==before and dispatches()==1
                checks.append('INDEPENDENT two simultaneous ticks of SAME schedule: one original unknown dispatch, same original intent/key, repeated tick zero record change/click')
                account=deepcopy(backend.core.store.get('accounts',target['accountId']));foreign=deepcopy(account);foreign['cloud_owner']='other-fixture-employee'
                backend.core.store.put('accounts',foreign);before=state()
                action('content_schedule_read',{**target,'scheduleId':r['id']},403)
                action('content_schedule_tick',{**target,'scheduleId':r['id'],'requestId':uuid.uuid4().hex},403)
                action('content_schedule_read',{**target,'platform':'douyin','scheduleId':r['id']},403)
                assert state()==before and dispatches()==1
                backend.core.store.put('accounts',account)
                checks.append('INDEPENDENT current account owner revocation/wrong platform denies reads and ticks, zero schedule records changed and zero dispatch')
                controls.clear();target3,d3=setup_account(3);r3=arm(target3,plan(target3,d3))['schedule'];old=deepcopy(backend.core.store.get('accounts',target3['accountId']))
                changed=deepcopy(old);changed['platform_uid']='different-fixture-uid';backend.core.store.put('accounts',changed)
                click_count=total_click_calls;stale=tick(target3,r3)
                assert stale['state']=='needs_review' and not stale['liveSessionEnabled'] and total_click_calls==click_count
                checks.append('INDEPENDENT fixed platform UID changed after explicit approval: needs_review before preflight, RAM grant revoked, zero click')
'''
(W/'test_independent_claims.py').write_text(s.replace(anchor,extra+anchor),'utf-8')
