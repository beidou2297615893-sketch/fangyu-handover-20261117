import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {pathToFileURL,fileURLToPath} from 'node:url';
import {parseHTML} from 'linkedom';
const W=path.dirname(fileURLToPath(import.meta.url));
const U='C:/积木软件工坊/项目/方隅公寓客户版/work/parallel-integration-20261018/final-integration/stage-02/project/work/ui-approved-implementation/ui-preview';
const server=JSON.parse(fs.readFileSync(path.join(W,'SERVER.json'),'utf8'));
const {document,window}=parseHTML('<html><body><main id="root"></main></body></html>');
globalThis.document=document;globalThis.location={origin:server.origin};
const storage=new Map();globalThis.localStorage={getItem:k=>storage.get(k)||null,setItem:(k,v)=>storage.set(k,v),removeItem:k=>storage.delete(k)};globalThis.sessionStorage={getItem:()=>null,setItem(){},removeItem(){}};
const downloads=[];const createElement=document.createElement.bind(document);document.createElement=name=>{const el=createElement(name);if(name==='a')el.click=()=>downloads.push({name:el.download,href:el.href});return el;};
const page=await import(pathToFileURL(U+'/pages/content-operations.mjs'));
const {createBackend}=await import(pathToFileURL(U+'/backend.mjs'));
let cookie='',inFlight=0,mode='',deferredRelease=null,lateResponse=null;const events=[],results=[],errors=[];
const backend=createBackend(async (url,opts)=>{const headers={...opts.headers,Origin:server.origin,...(cookie?{Cookie:cookie}:{})};const response=await fetch(server.origin+url,{...opts,headers});const cookies=response.headers.get('set-cookie');if(cookies)cookie=cookies.split(';')[0];return response;});
await backend.bootstrap();const logged=await backend.login({username:server.username,password:server.password});
const storeId=logged.selection.storeId;
const state={authEpoch:1,storeId,store:'合成验证门店',activePlatform:'xiaohongshu',session:logged.session,platform:{actor:{username:server.username,storeId},accounts:[{id:'workflow-first',name:'合成内容账号甲',platform:'xiaohongshu',storeId},{id:'workflow-second',name:'合成内容账号乙',platform:'xiaohongshu',storeId}]}};
const root=document.querySelector('#root');let cleanup=()=>{};
const ctx={state,update:fn=>{fn();render();},toast:message=>events.push({toast:message}),modal:({title,onConfirm})=>{events.push({confirm:title});Promise.resolve(onConfirm()).catch(e=>errors.push(e.stack));},contentAction:async(action,payload)=>{inFlight++;events.push({action,requestId:payload.requestId,accountId:payload.accountId});try{
  if(mode==='unavailable'&&action==='content_task_run'){mode='';throw Object.assign(Error('生成通道尚未配置'),{mutationCommitted:false});}
  const value=await backend.contentAction(action,payload);
  if(mode==='lose-run'&&action==='content_task_run'){mode='';throw Error('合成：回执在本地代理丢失');}
  if((mode==='lose-prepare'&&action==='content_task_prepare')||(mode==='lose-apply'&&action==='content_task_apply')||(mode==='lose-package'&&action==='content_package_build')){mode='';throw Error('合成：本地保存回执在代理丢失');}
  if(mode==='delay-read'&&action==='content_knowledge_search'){mode='';lateResponse=value;await new Promise(resolve=>deferredRelease=resolve);}
  return value;
}finally{inFlight--;}}};
function render(){cleanup();root.innerHTML=page.render(state);cleanup=page.bind(root,ctx);}
const tick=()=>new Promise(r=>setTimeout(r,10));
async function settled(){for(let n=0;n<700;n++){await tick();if(!inFlight&&!state.contentOperationsUI?.pending&&!state.contentOperationsUI?.workflowUI?.pending){await tick();if(!inFlight)return;}}throw Error('UI did not settle');}
function get(selector){const e=root.querySelector(selector);assert.ok(e,'Missing control '+selector+'\n'+root.textContent.slice(0,1600));return e;}
async function click(selector){const e=get(selector);assert.ok(!e.disabled,'Disabled '+selector);e.dispatchEvent(new window.Event('click',{bubbles:true}));await settled();}
function value(selector,value){const e=get(selector);if(e.tagName==='SELECT'){for(const option of e.querySelectorAll('option'))option.selected=option.value===value;Object.defineProperty(e,'value',{configurable:true,value,writable:true});}else e.value=value;e.dispatchEvent(new window.Event(e.tagName==='SELECT'?'change':'input',{bubbles:true}));}
function text(){return root.textContent;}
function u(){return state.contentOperationsUI;}
function report(name,details){results.push({name,pass:true,details});}
const stage={strategy:'persona',persona:'persona',homepage:'persona',research:'topics',columns:'topics',topics:'topics',writing:'creation',video:'creation',visual:'creation',revision:'creation',audit:'drafts',package:'drafts',scheduling:'drafts',engagement:'drafts',growth:'metrics',learning:'metrics'};
async function openMethod(id){if(id==='knowledge')await click('[data-wf-action="open-knowledge"]');else await click(`[data-co-tab="${stage[id]}"]`);await click(`[data-wf-method="${id}"]`);}
async function prepare(id){await openMethod(id);value('#wf-query','公共厨房 UI 合成核验 '+id);value('#wf-instructions','只用虚构资料。保留原文与假设，不能说已发布。');await click('[data-wf-action="prepare"]');assert.equal(u().workflowUI.error,'');assert.equal(state.contentWorkspace.workflow.tasks.find(t=>t.id===u().workflowUI.taskId).state,'prepared');assert.match(text(),/本次已冻结的输入与引用/);return u().workflowUI.taskId;}
async function generate(id){const taskId=await prepare(id);await click('[data-wf-action="run"]');assert.equal(u().workflowUI.error,'');assert.equal(state.contentWorkspace.workflow.tasks.find(t=>t.id===taskId).state,'succeeded');return taskId;}
async function run(){
  render();value('[data-co-account]','workflow-second');await settled();assert.equal(state.contentWorkspace.actor.accountId,'workflow-second');report('Original account selector + Native workspace read');
  await click('[data-wf-action="open-knowledge"]');assert.equal(u().workflowUI.specs.length,17);
  value('#wf-doc-title','UI合成公共厨房说明😀');value('#wf-doc-source','虚构门店说明，仅用于测试');value('#wf-doc-text','公共厨房每周四打扫。\r\n资料保持😀原文；禁止把这段当成真实经营承诺。');await click('[data-wf-action="import"]');assert.equal(u().workflowUI.error,'');assert.equal(state.contentWorkspace.workflow.documents.find(d=>d.title==='UI合成公共厨房说明😀').text,'公共厨房每周四打扫。\r\n资料保持😀原文；禁止把这段当成真实经营承诺。');
  value('#wf-doc-title','UI合成假设');value('[data-wf-doc="kind"]','hypothesis');value('#wf-doc-text','公共厨房可能吸引喜欢做饭的住户，这尚未核实。');await click('[data-wf-action="import"]');assert.equal(state.contentWorkspace.workflow.documents.find(d=>d.title==='UI合成假设').kind,'hypothesis');report('Knowledge UTF-8 original text and hypothesis classification');
  const methods=['strategy','persona','homepage','research','columns','topics','writing','visual','knowledge','video','revision','audit','package','scheduling','engagement','growth','learning'];
  let videoId='';
  for(const id of methods){
    const taskId=await generate(id);assert.match(text(),/原文引用/);assert.match(text(),/待核假设/);await click('[data-wf-action="apply"]');assert.equal(u().workflowUI.error,'',id);const task=state.contentWorkspace.workflow.tasks.find(t=>t.id===taskId);assert.ok(task.appliedRefs,id);
    if(id==='video'){videoId=u().forms.draft.id;assert.equal(u().forms.draft.format,'video');value('[data-co-form="draft"][data-co-field="body"]','合成保留视频配文：公共厨房相关须本人核实。');await click('[data-co-action="save-draft"]');assert.equal(u().error,'');}
    if(id==='revision'){assert.equal(u().forms.draft.id,videoId);assert.equal(u().forms.draft.body,'合成保留视频配文：公共厨房相关须本人核实。');assert.equal(u().forms.draft.script,'修订后的虚构内容。');}
    report('17-method UI→Native path: '+id,{taskId,adopted:task.appliedRefs});
  }
  await click('[data-wf-action="close"]');await click('[data-co-tab="drafts"]');await click(`[data-co-action="review-draft"][data-id="${videoId}"]`);for(const key of ['facts','account','assets']){const e=get(`[data-co-review-check="${key}"]`);e.checked=true;e.dispatchEvent(new window.Event('change',{bubbles:true}));}await click('[data-co-action="approve-draft"]');assert.equal(u().error,'');await click('[data-wf-action="build-package"]');assert.equal(u().workflowUI.error,'');assert.match(u().workflowUI.notice,/尚未发布/);const packet=state.contentWorkspace.workflow.packages.at(-1).export.package;assert.equal(packet.body,'合成保留视频配文：公共厨房相关须本人核实。');assert.equal(packet.script,'修订后的虚构内容。');assert.equal(packet.published,false);assert.equal(packet.state,'needs_video_asset');assert.equal(downloads.length,1);report('Original manual audit + package build: caption/script retained, missing video explicit, no publish');
  u().reviewMode=false;render();const lostTask=await prepare('writing');mode='lose-run';const beforeRun=events.filter(e=>e.action==='content_task_run').length;await click('[data-wf-action="run"]');assert.ok(u().workflowUI.runUnknown);assert.equal(u().workflowUI.localUnknown,null);assert.equal(get('[data-wf-action="run"]').disabled,true);let saved=JSON.parse(storage.get('fangyu-content-workflow-pending-v1'));assert.deepEqual(Object.keys(saved.at(-1)).sort(),['requestId','scope','taskId']);assert.equal(saved.at(-1).taskId,lostTask);
  await click('[data-wf-action="open-tasks"]');assert.equal(u().workflowUI.runUnknown,null);assert.equal(u().workflowUI.saved.length,0);assert.equal(events.filter(e=>e.action==='content_task_run').length,beforeRun+1);report('Lost real Native run receipt → original read reconciliation, exactly one generation, only scoped IDs persisted');
  await prepare('writing');mode='unavailable';await click('[data-wf-action="run"]');assert.equal(u().workflowUI.runUnknown,null);assert.equal(u().workflowUI.localUnknown,null);assert.equal(u().workflowUI.saved.length,0);assert.match(u().workflowUI.error,/未配置/);report('Explicit undispatched error clears pending model receipt and preserves prepared task (client injected)');
  // Model not configured is a real UI capability branch; no synthetic call is dispatched.
  state.contentWorkspace.workflowCapabilities.canRunTasks=false;render();assert.equal(get('[data-wf-action="run"]').disabled,true);assert.match(text(),/生成通道尚未接通/);report('Absent model capability is prepare-only, no fabricated generation');
  state.contentWorkspace.workflowCapabilities.canRunTasks=true;render();
  await openMethod('research');value('#wf-evidence-query','公共厨房');mode='delay-read';get('[data-wf-action="search"]').dispatchEvent(new window.Event('click',{bubbles:true}));for(let n=0;n<100&&!deferredRelease;n++)await tick();assert.ok(deferredRelease);const old=u().workflowUI;value('[data-co-account]','workflow-first');for(let n=0;n<100&&state.contentWorkspace?.actor?.accountId!=='workflow-first';n++)await tick();const switched=state.contentWorkspace;assert.equal(u().accountId,'workflow-first');deferredRelease();await settled();assert.notEqual(u().workflowUI,old);assert.equal(state.contentWorkspace.actor.accountId,'workflow-first');assert.equal(u().workflowUI.evidence.length,0);assert.equal(state.contentWorkspace,switched);report('Late account-B knowledge response cannot overwrite switched account-A workspace/input');
  // This account is only read: root uses account A for independent visual verification.
  assert.equal(events.filter(e=>e.accountId==='workflow-first'&&e.action!=='content_workspace_read').length,0);
  assert.equal(errors.length,0);report('No event errors; account A read only; model/Native data synthetic only');
}
async function runEdges(){
  render();value('[data-co-account]','workflow-second');await settled();
  await openMethod('writing');value('#wf-query','公共厨房 原保存恢复专项');const before=state.contentWorkspace.workflow.tasks.length;
  mode='lose-prepare';await click('[data-wf-action="prepare"]');assert.ok(u().workflowUI.localUnknown);assert.equal(u().workflowUI.runUnknown,null);
  await click('[data-wf-action="check-local"]');assert.equal(u().workflowUI.error,'');assert.equal(u().workflowUI.localUnknown,null);assert.equal(state.contentWorkspace.workflow.tasks.length,before+1);const prepared=state.contentWorkspace.workflow.tasks.find(t=>t.id===u().workflowUI.taskId);assert.equal(prepared.query,'公共厨房 原保存恢复专项');assert.equal(events.filter(e=>e.action==='content_task_prepare').length,1);report('Lost prepare receipt → exact sourceRevision/new-task recovery, one create');
  await click('[data-wf-action="run"]');mode='lose-apply';await click('[data-wf-action="apply"]');assert.ok(u().workflowUI.localUnknown);await click('[data-wf-action="check-local"]');assert.equal(u().workflowUI.localUnknown,null);assert.ok(u().forms.draft.id);assert.equal(events.filter(e=>e.action==='content_task_apply').length,1);report('Lost apply receipt → original task appliedRefs restores original editor, one apply');
  await click('[data-co-action="open-review"]');for(const key of ['facts','account','assets']){const e=get(`[data-co-review-check="${key}"]`);e.checked=true;e.dispatchEvent(new window.Event('change',{bubbles:true}));}await click('[data-co-action="approve-draft"]');
  const packages=state.contentWorkspace.workflow.packages.length;mode='lose-package';await click('[data-wf-action="build-package"]');assert.ok(u().workflowUI.localUnknown);const original=u().workflowUI.localUnknown.payload.requestId;await click('[data-wf-action="check-local"]');assert.equal(u().workflowUI.originalChecked,true);assert.match(text(),/按原编号重新下载/);await click('[data-wf-action="retry-local"]');assert.equal(u().workflowUI.localUnknown,null);assert.equal(downloads.length,1);assert.equal(state.contentWorkspace.workflow.packages.length,packages+1);assert.ok(events.filter(e=>e.action==='content_package_build').every(e=>e.requestId===original));report('Lost package receipt → confirm saved → explicit same-key download replay, one package');
  assert.equal(errors.length,0);
}
const output=process.env.UI_EDGE_ONLY?'LOCAL-RECOVERY-RESULTS.json':'DOM-NATIVE-RESULTS.json';
try{await (process.env.UI_EDGE_ONLY?runEdges():run());fs.writeFileSync(path.join(W,output),JSON.stringify({passed:results.length,failed:0,scope:'Node linkedom event behaviour against actual Native HTTP, synthetic model only. No browser layout proof.',results,events,downloads},null,2));console.log(JSON.stringify({passed:results.length,failed:0}));}
catch(e){fs.writeFileSync(path.join(W,output),JSON.stringify({passed:results.length,failed:1,error:e.stack,uiText:text(),uiError:u()?.error,workflowError:u()?.workflowUI?.error,results,events},null,2));console.error(e.stack);process.exitCode=1;}
