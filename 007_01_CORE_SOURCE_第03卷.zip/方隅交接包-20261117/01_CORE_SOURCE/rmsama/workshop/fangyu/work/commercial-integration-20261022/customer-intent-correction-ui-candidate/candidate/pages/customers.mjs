import {calendarControl} from '../daily-ui.mjs';
import {personalTools} from '../platform-ui.mjs';
import {evidenceSummary,assessmentLabel} from './workflow-summary.mjs';
import {customerModel,customerControls,customerQuery,actorMatches,count} from './customers-data.mjs';
import {openHandoff} from './customer-handoff.mjs';
import {renderIntentCorrection,bindIntentCorrection} from './customer-intent-correction.mjs';
import {customerAvatar,postCover,bindCustomerAvatars} from '../avatar.mjs';
const PEOPLE = [
  {id:'xiaoyu',name:'小雨',avatar:'portrait-woman-1.png',need:'长宁·3500元·下月入住',level:'超高意向',rank:3,tone:'urgent',time:'今天 10:24',timeOrder:4,replied:false,channel:'小红书',post:'古北求租',quote:'下月入住，预算3500，想周末看房。',next:'确认周末看房时间'},
  {id:'chen',name:'陈先生',avatar:'portrait-man-1.png',need:'九号线·一居·近地铁',level:'高意向',rank:2,tone:'high',time:'昨天 16:20',timeOrder:3,replied:false,channel:'抖音',post:'通勤租房',quote:'想在古北找一居室，最好近地铁。',next:'确认房源偏好与入住安排'},
  {id:'lin',name:'林女士',avatar:'portrait-woman-2.png',need:'近地铁·下月入住',level:'中意向',rank:1,tone:'medium',time:'昨天 14:08',timeOrder:2,replied:false,channel:'小红书',post:'长宁租房',quote:'九号线附近有没有精装一居？预算3000左右。',next:'确认预算与入住安排'},
  {id:'zhou',name:'周先生',avatar:'portrait-man-1.png',need:'两人住·短租',level:'中意向',rank:1,tone:'medium',time:'10月13日',timeOrder:1,replied:false,channel:'抖音',post:'公寓咨询',quote:'两个人想短租两个月，想了解一下合适的房源。',next:'了解租期与区域偏好'}
];
const esc=value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const icon=(name,cls='')=>`<img class="cs-icon ${cls}" src="/assets/${name}" alt="" aria-hidden="true">`;
const badge=p=>`<span class="cs-badge cs-${p.tone}">${p.level}</span>`;
const LONG_QUOTE='下个月和朋友一起搬到上海，想在古北附近找一间采光好的一居室。预算3500元左右，希望近地铁，可以养猫，有独立厨房和卫生间。我们周末都方便看房，也想了解押金、水电和最短租期。';
function data(state){
  state.customers??={};
  const s=state.customers;s.platform=state.activePlatform||'xiaohongshu';const defaults={query:'',sort:'intent',sortDirection:'desc',filter:'all',filterOpen:false,selectedId:'',checkedIds:[],evidenceOpen:false,handedOffIds:[],handoffNotes:{},repliedIds:[]};
  for(const [key,value]of Object.entries(defaults))if(s[key]===undefined)s[key]=value;
  if(state.selectedCustomer){s.selectedId=state.selectedCustomer==='rain'?'xiaoyu':state.selectedCustomer;delete state.selectedCustomer;}
  return s;
}
const isReplied=(p,s)=>p.replied||s.repliedIds.includes(p.id);
function visible(s){
  const query=s.query.trim().toLowerCase();
  let list=PEOPLE.filter(p=>(!query||`${p.name}${p.need}${p.channel}${p.post}${p.level}`.toLowerCase().includes(query))&&(s.filter==='all'||(s.filter==='high'&&p.rank>1)||(s.filter==='medium'&&p.rank===1)||(s.filter==='replied'&&isReplied(p,s))||(s.filter==='pending'&&!isReplied(p,s))));
  const order=s.sortDirection==='asc'?1:-1;
  return list.sort((a,b)=>{let value=0;if(s.sort==='intent')value=a.rank-b.rank;else if(s.sort==='reply')value=Number(isReplied(b,s))-Number(isReplied(a,s));else if(s.sort==='time')value=a.timeOrder-b.timeOrder;else if(s.sort==='post')value=`${a.channel}${a.post}`.localeCompare(`${b.channel}${b.post}`,'zh-CN');return value*order||b.timeOrder-a.timeOrder;});
}
function row(p,s){
  const replied=isReplied(p,s),handed=s.handedOffIds.includes(p.id),action=p.rank===3?'人工回复':replied?'整理交接':'待回复';
  return `<tr class="${s.selectedId===p.id?'is-current':''}" data-customer-row="${p.id}" tabindex="0" aria-label="查看${p.name}客户详情"><td class="cs-check-col"><input type="checkbox" data-customer-check="${p.id}" aria-label="选择${p.name}" ${s.checkedIds.includes(p.id)?'checked':''}></td><td class="cs-person-col"><div class="cs-person-cell"><img src="/assets/${p.avatar}" alt="${p.name}的示例头像"><span><strong>${p.name}</strong><span>${p.need}</span></span></div></td><td class="cs-intent-col">${badge(p)}</td><td class="cs-contact-col"><span class="cs-contact-time"><i class="cs-dot ${replied?'is-green':p.id==='zhou'?'is-muted':''}"></i>${p.time}</span><span class="cs-contact-status">${replied?'已回复':p.id==='zhou'?'未回复':'待回复'}</span></td><td class="cs-channel-col"><strong>${p.channel}</strong><span>${p.post}</span></td><td class="cs-next-col"><button type="button" data-customer-action="${p.id}" class="cs-row-action">${handed?'已整理':action}</button></td></tr>`;
}
function stateScreen(scenario){
  const info={empty:['fy-state-01-empty-customers.png','还没有客户记录','开始获客后，客户需求与来源会集中显示在这里。'],loading:['fy-state-04-loading.png','正在整理客户清单','稍等片刻，客户与联系记录即将准备好。'],error:['fy-state-03-error.png','客户清单暂时没有加载出来','可以重新试一次，已保存的交接记录仍会保留。']}[scenario];
  return `<div class="customers-page"><div class="cs-stats">${[['客户总量',0],['高意向',0],['已回复',0],['待交接',0]].map(([title,count])=>`<div class="cs-stat"><span class="cs-stat-icon">${icon('tabler-upgrade-users.svg')}</span><span><small>${title}</small><strong>${count}</strong></span></div>`).join('')}</div><div class="cs-state-screen" role="status"><img src="/assets/${info[0]}" alt=""><h2>${info[1]}</h2><p>${info[2]}</p>${scenario==='error'?'<button type="button" class="cs-primary cs-state-retry" data-customer-retry>重新加载</button>':scenario==='loading'?'<span>正在加载…</span>':''}</div></div>`;
}
export function render(state){
  if(state.connection!=='preview')return renderConnected(state);
  const s=data(state),channel=state.activePlatform==='douyin'?'抖音':'小红书',people=visible(s).filter(p=>p.channel===channel),p=people.find(x=>x.id===s.selectedId);
  const detail=p?`<aside class="cs-detail-panel cs-post-detail"><div class="cs-post-picture"><img class="cs-post-cover" src="/assets/login-approved-photo.png" alt="示例原帖图片"></div><div class="cs-post-title"><h2>${esc(p.post)}</h2><button type="button" class="cs-source" data-customer-source>打开原帖 ${icon('tabler-external-link.svg')}</button></div><div class="cs-detail-person"><img src="/assets/${p.avatar}" alt="示例头像"><strong>${p.name}</strong>${badge(p)}</div><blockquote class="cs-quote">${esc(p.quote)}</blockquote><div class="cs-detail-actions"><button type="button" class="cs-primary" data-customer-reply>回复</button><button type="button" class="cs-secondary" data-customer-handoff>客户备忘</button></div></aside>`:'<aside class="cs-detail-panel is-empty" aria-label="客户详情"></aside>';
  return `<div class="customers-page"><div class="cs-workspace"><section class="cs-list-panel"><div class="cs-list-toolbar"><label class="cs-search">${icon('fy-icon-07-search.png')}<input id="customer-search" type="search" data-customer-search value="${esc(s.query)}" placeholder="搜索客户"></label></div><div class="cs-table-wrap" aria-busy="${Boolean(state.customerLoading)}">${state.customerLoading?'<div class="cs-refresh-line" role="status" aria-label="正在更新筛选结果"></div>':''}<table><thead><tr><th class="cs-person-col">客户与评论</th><th class="cs-intent-col">意向</th><th class="cs-contact-col">回复状态</th></tr></thead><tbody>${people.map(x=>`<tr data-customer-row="${x.id}" tabindex="0" class="${p?.id===x.id?'is-current':''}"><td class="cs-person-col"><div class="cs-person-cell"><img src="/assets/${x.avatar}" alt="示例头像"><span><strong>${x.name}</strong><span>${esc(x.quote)}</span></span></div></td><td class="cs-intent-col">${badge(x)}</td><td class="cs-contact-col">待回复</td></tr>`).join('')}</tbody></table></div><div class="cs-table-footer">共 ${people.length} 条</div></section>${detail}</div></div>`;
}
function toReply(ctx,p){ctx.update(state=>{state.reply??={};state.reply.selectedId=p.id;state.reply.tab=state.reply.sentIds?.includes(p.id)?'replied':'pending';state.reply.draft=state.reply.savedDrafts?.[p.id]??`你好，已了解你的租房需求。\n方便确认一下看房时间吗？`;state.reply.evidenceOpen=false;});ctx.navigate('reply');}
function handoff(ctx,p){
  const s=data(ctx.state),done=s.handedOffIds.includes(p.id);
  ctx.modal({title:'客户备忘',html:`<div class="cs-handoff-preview"><h3>${p.name} · ${p.level}</h3><p>${p.quote}</p><dl><dt>来源</dt><dd>${p.channel} · ${p.post}</dd><dt>下一步</dt><dd>${p.next}</dd><dt>门店</dt><dd>${esc(ctx.state.store||'古北店')}</dd></dl><label>我的记录<textarea id="cs-handoff-note" placeholder="记录本次需求…">${esc(s.handoffNotes[p.id]||(done?'需求与来源信息已整理，可安排同事接续联系。':''))}</textarea></label></div>`,confirmLabel:done?'完成':'保存备忘',onConfirm:()=>{
    const note=document.getElementById('cs-handoff-note')?.value.trim()||'';
    ctx.update(state=>{const v=data(state);if(!v.handedOffIds.includes(p.id))v.handedOffIds.push(p.id);v.handoffNotes[p.id]=note;});
    ctx.toast('示例备忘已保存');
  }});
}
export function bind(root,ctx){
  if(ctx.state.connection!=='preview')return bindConnected(root,ctx);
  const s=data(ctx.state);
  root.querySelector('[data-customer-day]')?.addEventListener('change',e=>ctx.update(state=>{data(state).acquiredDate=e.target.value;data(state).checkedIds=[];}));
  root.querySelector('[data-customer-day-clear]')?.addEventListener('click',()=>ctx.update(state=>{data(state).acquiredDate='';data(state).checkedIds=[];}));
  root.querySelector('[data-customer-retry]')?.addEventListener('click',()=>{ctx.update(state=>{state.scenario='normal';});ctx.toast('客户清单已重新加载');});
  const search=root.querySelector('[data-customer-search]');
  let composing=false;
  search?.addEventListener('compositionstart',()=>{composing=true;});
  search?.addEventListener('input',e=>{
    const value=e.target.value;
    if(composing||e.isComposing){s.query=value;return;}
    if(s.query===value)return;
    ctx.update(state=>{data(state).query=value;});
  });
  search?.addEventListener('compositionend',e=>{composing=false;const value=e.target.value;ctx.update(state=>{data(state).query=value;});});
  root.querySelector('[data-customer-filter]')?.addEventListener('click',()=>ctx.update(state=>{data(state).filterOpen=!data(state).filterOpen;}));
  root.querySelectorAll('[data-customer-filter-value]').forEach(el=>el.addEventListener('click',()=>ctx.update(state=>{const v=data(state);v.filter=el.dataset.customerFilterValue;v.filterOpen=false;})));
  root.querySelectorAll('[data-customer-sort]').forEach(el=>el.addEventListener('click',()=>ctx.update(state=>{const v=data(state);v.sortDirection=v.sort===el.dataset.customerSort&&v.sortDirection==='desc'?'asc':'desc';v.sort=el.dataset.customerSort;})));
  root.querySelectorAll('[data-customer-row]').forEach(el=>{const select=()=>ctx.update(state=>{const v=data(state);v.selectedId=el.dataset.customerRow;v.evidenceOpen=false;});el.addEventListener('click',e=>{if(e.target.closest('button,input'))return;select();});el.addEventListener('keydown',e=>{if(e.target===el&&(e.key==='Enter'||e.key===' ')){e.preventDefault();select();}});});
  root.querySelectorAll('[data-customer-check]').forEach(el=>el.addEventListener('change',()=>ctx.update(state=>{const v=data(state),id=el.dataset.customerCheck;v.checkedIds=el.checked?[...new Set([...v.checkedIds,id])]:v.checkedIds.filter(value=>value!==id);})));
  root.querySelector('[data-customer-check-all]')?.addEventListener('change',event=>ctx.update(state=>{data(state).checkedIds=event.target.checked?PEOPLE.map(p=>p.id):[];}));
  root.querySelectorAll('[data-customer-action]').forEach(el=>el.addEventListener('click',()=>{const p=PEOPLE.find(v=>v.id===el.dataset.customerAction);if(isReplied(p,s))handoff(ctx,p);else toReply(ctx,p);}));
  const selected=()=>PEOPLE.find(v=>v.id===data(ctx.state).selectedId)||PEOPLE[0];
  root.querySelector('[data-customer-reply]')?.addEventListener('click',()=>toReply(ctx,selected()));
  root.querySelector('[data-customer-handoff]')?.addEventListener('click',()=>handoff(ctx,selected()));
  root.querySelector('[data-customer-evidence]')?.addEventListener('click',()=>ctx.update(state=>{data(state).evidenceOpen=!data(state).evidenceOpen;}));
  root.querySelector('[data-customer-evidence-link]')?.addEventListener('click',()=>ctx.update(state=>{data(state).evidenceOpen=true;}));
  root.querySelector('[data-customer-source]')?.addEventListener('click',()=>{const p=selected();ctx.modal({title:`${p.channel}源帖`,html:`<div class="cs-source-preview"><img src="/assets/fy-login-apartment-photo.webp" alt="示例公寓房源"><h3>${p.post}</h3><p>${p.quote}</p><p>${p.channel} · ${p.time}</p><small>界面演示用来源内容。</small></div>`,confirmLabel:'知道了'});});
  root.querySelector('[data-customer-history]')?.addEventListener('click',()=>{const p=selected();ctx.modal({title:'交接记录',html:`<p><strong>${p.name}</strong></p><div class="cs-record-line"><span>${s.handedOffIds.includes(p.id)?'刚刚':'今天 10:24'}</span><p>${s.handedOffIds.includes(p.id)?'已整理需求、来源和下一步安排，等待同事接续联系。':'尚未整理交接，可先确认需求和看房时间。'}</p></div>`,confirmLabel:'知道了'});});
  root.querySelector('[data-customer-more]')?.addEventListener('click',()=>{const p=selected();ctx.modal({title:'客户操作',html:`<h3>${p.name}</h3><p>${p.need}</p><p>可以在右侧查看来源证据、进行人工回复或整理交接。</p>`,confirmLabel:'知道了'});});
  root.querySelector('[data-customer-batch]')?.addEventListener('click',()=>{const chosen=PEOPLE.filter(p=>s.checkedIds.includes(p.id)),eligible=chosen.filter(p=>p.rank===1),manual=chosen.filter(p=>p.rank>1);ctx.modal({title:'批量回复',html:`<p>已选 <strong>${chosen.length}</strong> 位客户，可批量回复 <strong>${eligible.length}</strong> 位中意向客户。</p>${manual.length?`<p class="cs-modal-note">${manual.map(p=>p.name).join('、')}建议人工回复。</p>`:''}<div class="cs-batch-names">${eligible.map(p=>`<span>${p.name}</span>`).join('')}</div><label class="cs-batch-label">回复内容<textarea id="cs-batch-draft" maxlength="200">你好，看到你正在了解租房。我们有合适的房源可供参考，方便说一下你的入住时间吗？</textarea></label><p class="cs-modal-note">本次为界面演示，确认后仅更新示例状态。</p>`,confirmLabel:eligible.length?'确认批量演示':'知道了',onConfirm:eligible.length?()=>{const draft=document.getElementById('cs-batch-draft')?.value.trim()||'';if(!draft){ctx.toast('请先填写回复内容');return false;}ctx.update(state=>{const v=data(state);v.lastBatchDraft=draft;state.reply??={};state.reply.sentIds??=['anna'];state.reply.savedDrafts??={};for(const p of eligible){state.reply.savedDrafts[p.id]=draft;if(!v.repliedIds.includes(p.id))v.repliedIds.push(p.id);if(!state.reply.sentIds.includes(p.id))state.reply.sentIds.push(p.id);}});ctx.toast(`已完成 ${eligible.length} 位客户的示例回复`);}:undefined});});
  root.querySelector('[data-customer-export]')?.addEventListener('click',()=>{const list=visible(s);ctx.modal({title:'Excel导出预览',html:`<p>当前清单共 <strong>${list.length}</strong> 位客户。</p><div class="cs-export-preview"><table><thead><tr><th>客户</th><th>意向</th><th>渠道</th></tr></thead><tbody>${list.map(p=>`<tr><td>${p.name}</td><td>${p.level}</td><td>${p.channel}</td></tr>`).join('')}</tbody></table></div><p class="cs-modal-note">此处展示导出列与确认流程。</p>`,confirmLabel:'确认预览',onConfirm:()=>ctx.toast('导出预览已确认')});});
}

function liveStats(){return '';}
function liveState(model){
  const kind=model.status==='error'?'error':model.status==='loading'?'loading':'empty';
  const [asset,title,text]={empty:['fy-state-01-empty-customers.png','还没有客户记录',model.scope==='employee-local-history'?'本机当前员工可见客户将显示在这里；旧记录的门店归属尚未核实。':'采集到的客户会显示在这里。'],loading:['fy-state-04-loading.png','正在读取客户清单','正在核对当前员工可见客户与来源。'],error:['fy-state-03-error.png','客户清单暂时没有加载出来',model.error||'请重新加载当前员工可见客户。']}[kind];
  if(kind==='loading')return '<div class="cs-skeleton" role="status" aria-label="正在加载客户"><div></div><div></div><div></div><div></div><div></div></div>';
  return `<div class="cs-state-screen" role="status"><img src="/assets/${asset}" alt=""><h2>${title}</h2><p>${esc(text)}</p>${kind==='error'?'<button type="button" class="cs-primary cs-state-retry" data-customer-retry>重新加载</button>':kind==='loading'?'<span>正在加载…</span>':''}</div>`;
}
const liveFilterLabels={all:'全部客户',high:'超高 / 高意向',medium:'中意向',low:'低意向',uncertain:'信息不足',unanalyzed:'尚未分析',unrelated:'不相关',pending:'待回复',replied:'已回复'};
const liveBadge=(p,detail=false)=>`<span class="cs-badge cs-${['urgent','high','medium','low'].includes(p.tone)?p.tone:'muted'}"${detail?' style="flex-shrink:0"':''}>${esc(p.level||'意向未分级')}</span>`;
const contactClock=new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Shanghai',year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',hourCycle:'h23'});
function contactTime(value){
  if(typeof value!=='string'||!/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d{1,6})?(?:Z|[+-]\d{2}:\d{2})$/.test(value))return {label:'暂无联系时间',title:''};
  const time=new Date(value);if(!Number.isFinite(time.getTime()))return {label:'暂无联系时间',title:''};
  const parts=Object.fromEntries(contactClock.formatToParts(time).map(part=>[part.type,part.value]));
  return {label:`${parts.year.padStart(4,'0')}-${parts.month}-${parts.day} ${parts.hour}:${parts.minute}`,title:value};
}
function liveRow(p,s){
  return `<tr class="${s.selectedId===p.id?'is-current':''}" data-customer-row="${esc(p.id)}" tabindex="0" aria-label="查看${esc(p.name||'客户')}客户详情"><td class="cs-check-col"><input type="checkbox" data-customer-check="${esc(p.id)}" aria-label="选择${esc(p.name||'客户')}" ${s.checkedIds.includes(p.id)?'checked':''}></td><td class="cs-person-col"><div class="cs-person-cell">${customerAvatar(p)}<span><strong>${esc(p.name||'未命名客户')}</strong><span>${esc(p.quote||p.need||'原评论未记录')}</span>${p.leaseGroup?`<small>租期：${esc(p.leaseGroup)} · ${esc(p.storeFit?.status||'适配待核对')}</small>`:''}</span></div></td><td class="cs-intent-col">${liveBadge(p)}</td><td class="cs-contact-col"><span class="cs-contact-status">${esc(p.contactLabel||(p.replied?'已回复':'待回复'))}</span></td></tr>`;
}
function liveDetail(state,model){
  const s=model.controls;if(!s.selectedId)return '<aside class="cs-detail-panel is-empty" aria-label="客户详情"><div class="cs-empty-detail"><img src="/assets/approved-icon-user-round.svg" alt=""><strong>选择一位客户</strong><p>查看原评论、需求分析与联系记录</p></div></aside>';
  const summary=model.items.find(p=>p.id===s.selectedId),detail=state.customerDetail,accepted=actorMatches(state,detail)&&detail.id===s.selectedId;
  const p=accepted&&detail.item?.id===s.selectedId?detail.item:summary;if(!p)return '<aside class="cs-detail-panel is-empty" aria-label="客户详情"><div class="cs-empty-detail"><img src="/assets/approved-icon-user-round.svg" alt=""><strong>选择一位客户</strong><p>查看原评论、需求分析与联系记录</p></div></aside>';
  const loading=!accepted||detail.status==='loading',failed=accepted&&detail.status==='error';
  return `<aside class="cs-detail-panel cs-post-detail" aria-label="客户详情"><div class="cs-post-picture">${postCover(p,'cs-post-cover')}</div><div class="cs-post-title"><h2>${esc(p.postTitle||'原帖标题未记录')}</h2><button type="button" class="cs-source" data-customer-source ${loading||failed||!p.postUrl?'disabled':''}>打开原帖 ${icon('tabler-external-link.svg')}</button></div><div class="cs-detail-person">${customerAvatar(p)}<strong>${esc(p.name||'未命名客户')}</strong>${liveBadge(p,true)}</div><blockquote class="cs-quote">${esc(loading?'正在读取原评论…':failed?detail.error||'详情暂时无法读取':p.quote||'原评论未记录')}</blockquote>${p.need?`<p class="cs-need">${esc(p.need)}</p>`:''}${p.leaseGroup?`<p class="cs-need"><strong>租期：${esc(p.leaseGroup)}</strong> · ${esc(p.storeFit?.status||'适配待核对')}</p>`:''}<button type="button" class="cs-evidence-toggle" data-customer-evidence aria-expanded="${s.evidenceOpen}">判断依据 ${icon('tabler-chevron-down.svg')}</button>${s.evidenceOpen?evidenceSummary(p):''}${!loading&&!failed?renderIntentCorrection(state,p):''}<div class="cs-detail-actions"><button type="button" class="cs-primary" data-customer-reply ${loading||failed?'disabled':''}>${icon('tabler-message-dots.svg')}回复</button>${personalTools(state)?'<button type="button" class="cs-secondary" data-customer-handoff>客户备忘</button>':''}</div></aside>`;
}
function renderConnected(state){
  const model=customerModel(state),s=model.controls;
  if(model.status!=='ready')return `<div class="customers-page cs-connected">${liveStats(model.stats)}${liveState(model)}</div>`;
  const allChecked=model.total>0&&s.checkedIds.length===model.total,page=Number.isSafeInteger(model.page)?model.page:1,pages=Number.isSafeInteger(model.pages)&&model.pages>0?model.pages:1,selected=s.checkedIds.length;
  return `<div class="customers-page cs-connected">${liveStats(model.stats)}<div class="cs-workspace"><section class="cs-list-panel" aria-label="客户清单"><div class="cs-list-toolbar"><div class="cs-top-tools">${calendarControl('customers',s.acquiredDate||'','按新增日期筛选客户')}${s.acquiredDate?'<button type="button" class="rp-text-link" data-customer-day-clear>清除日期</button>':''}${state.storeId==='fy_s_d343f3a378f48e1bab55df4f'?`<label>租期 <select data-customer-lease aria-label="按租期分组查看客户">${['all','1至3个月','4至11个月','12个月','未说明','其他租期','租期待确认'].map(key=>`<option value="${key}" ${s.leaseGroup===key?'selected':''}>${key==='all'?'全部租期':key}${key==='all'?'':` · ${count(model.stats.leaseGroups?.[key]||0)}`}</option>`).join('')}</select></label>`:''}<label class="cs-search">${icon('fy-icon-07-search.png')}<input id="customer-search" type="search" data-customer-search value="${esc(s.query)}" maxlength="100" placeholder="搜索客户" aria-label="搜索客户"></label><div class="cs-filter-wrap"><button type="button" class="cs-filter ${s.filter!=='all'?'is-filtered':''}" data-customer-filter aria-expanded="${s.filterOpen}">${icon('fy-icon-09-filter.png')}筛选</button>${s.filterOpen?`<div class="cs-filter-menu" role="menu">${Object.entries(liveFilterLabels).map(([key,label])=>`<button type="button" data-customer-filter-value="${key}" role="menuitemradio" aria-checked="${s.filter===key}" class="${s.filter===key?'is-selected':''}">${label}</button>`).join('')}</div>`:''}</div><span class="cs-toolbar-divider"></span><div class="cs-sort"><span>排序:</span>${[['intent','意向'],['reply','回复'],['time','时间'],['post','帖子']].map(([key,label])=>`<button type="button" data-customer-sort="${key}" aria-pressed="${s.sort===key}" class="${s.sort===key?'is-active':''}">${label}${s.sort===key?`<span>${s.sortDirection==='desc'?'↓':'↑'}</span>`:''}</button>`).join('')}</div></div><div class="cs-batch-tools"><span class="cs-selection">${state.customerSelectingAll?'正在选择全部筛选结果…':`已选 <strong>${selected}</strong> 位客户`}</span><button type="button" class="cs-export" data-customer-export ${state.customerExporting?'disabled':''}>${icon('tabler-upgrade-export.svg')}${state.customerExporting?'正在导出…':selected?'导出已选':'导出Excel'}</button></div></div><div class="cs-table-wrap" aria-busy="${Boolean(state.customerLoading)}">${state.customerLoading?'<div class="cs-refresh-line" role="status" aria-label="正在更新筛选结果"></div>':''}<table><thead><tr><th class="cs-check-col"><input type="checkbox" data-customer-check-all aria-label="全选当前筛选的所有客户" title="全选当前筛选结果的所有页" ${allChecked?'checked':''} ${state.customerLoading||state.customerSelectingAll?'disabled':''}></th><th class="cs-person-col">客户与需求</th><th class="cs-intent-col">意向 <span class="cs-table-sort-mark">⌃<br>⌄</span></th><th class="cs-contact-col">回复状态</th></tr></thead><tbody>${model.items.map(p=>liveRow(p,s)).join('')}</tbody></table>${!model.items.length?'<div class="cs-empty"><strong>没有找到相关客户</strong><span>试试其他关键词或筛选条件。</span></div>':''}</div><div class="cs-table-footer"><span>共 ${count(model.total)} 条${model.scope==='employee-local-history'?' · 本机当前员工可见客户':''}</span><div><button type="button" data-customer-page="previous" aria-label="上一页" ${page<=1?'disabled':''}>${icon('tabler-chevron-down.svg','cs-prev')}</button><span class="cs-page-current">${page}</span><span class="cs-page-total">/ ${pages}</span><button type="button" data-customer-page="next" aria-label="下一页" ${page>=pages?'disabled':''}>${icon('tabler-chevron-down.svg','cs-next')}</button></div></div></section>${liveDetail(state,model)}</div></div>`;
}
export function customerExportSnapshot(state){
  const view=state.customerView,params=customerQuery(state),s=customerControls(state);
  const queryKey=value=>JSON.stringify(['platform','query','filter','sort','sortDirection','page','pageSize','acquiredDate','leaseGroup'].map(key=>value?.[key]));
  if(state.customerLoading||!actorMatches(state,view)||view.status!=='ready'
      ||!view.requestQuery||queryKey(view.requestQuery)!==queryKey(params))return null;
  const selectedIds=[...s.checkedIds],amount=selectedIds.length||view.total;
  if(!Number.isSafeInteger(amount)||amount<0)return null;
  const {platform,query,filter,sort,sortDirection,acquiredDate,leaseGroup}=params;
  return {view,amount,payload:{platform,query,filter,sort,sortDirection,acquiredDate,...(leaseGroup?{leaseGroup}:{}),...(selectedIds.length?{selectedIds}:{})},
    signature:JSON.stringify([state.user,state.storeId,state.activePlatform||'xiaohongshu',params,selectedIds,view.total])};
}
function bindConnected(root,ctx){
  bindCustomerAvatars(root);
  bindIntentCorrection(root,ctx);
  root.querySelector('[data-customer-lease]')?.addEventListener('change',event=>{ctx.update(state=>{const c=customerControls(state);c.leaseGroup=event.target.value;c.page=1;c.checkedIds=[];c.selectedId='';});ctx.actions.loadCustomers?.();});
  const model=customerModel(ctx.state),boundActor=JSON.stringify([ctx.state.user,ctx.state.storeId,ctx.state.activePlatform||'xiaohongshu']);
  const sameActor=()=>boundActor===JSON.stringify([ctx.state.user,ctx.state.storeId,ctx.state.activePlatform||'xiaohongshu']);
  const accepted=()=>sameActor()&&!ctx.state.customerLoading&&!ctx.state.customerSelectingAll&&actorMatches(ctx.state,ctx.state.customerView)&&ctx.state.customerView.status==='ready';
  const change=fn=>{if(!accepted())return false;ctx.update(state=>fn(customerControls(state)));return true;};
  const request=()=>{if(sameActor())ctx.actions.loadCustomers?.(customerQuery(ctx.state));};
  const select=id=>{if(!accepted()||!customerModel(ctx.state).items.some(item=>item.id===id))return;change(s=>{s.selectedId=id;s.evidenceOpen=false;});return ctx.actions.loadCustomerDetail?.(id);};
  const currentId=()=>{const s=customerControls(ctx.state);return accepted()&&customerModel(ctx.state).items.some(item=>item.id===s.selectedId)?s.selectedId:'';};
  const later=kind=>{if(!accepted())return;ctx.modal({title:kind,html:`<p>${kind==='整理交接'||kind==='交接记录'?'客户交接将在后续批次接入；本次未保存或修改交接状态。':'回复草稿与人工确认发送将在下一批接入；本次未生成草稿或发送消息。'}</p><p>当前可以筛选客户、核对来源及导出Excel。</p>`,confirmLabel:'知道了'});};
  root.querySelector('[data-customer-day]')?.addEventListener('change',e=>{change(s=>{s.acquiredDate=e.target.value;s.page=1;s.checkedIds=[];});request();});
  root.querySelector('[data-customer-day-clear]')?.addEventListener('click',()=>{change(s=>{s.acquiredDate='';s.page=1;s.checkedIds=[];});request();});
  root.querySelector('[data-customer-retry]')?.addEventListener('click',request);
  const search=root.querySelector('[data-customer-search]');let composing=false;
  search?.addEventListener('compositionstart',()=>{composing=true;ctx.actions.setCustomerSearchComposing?.(true);});
  const searchChanged=event=>{if(!accepted())return;const value=String(event.target.value||'').slice(0,100);if(composing||event.isComposing){customerControls(ctx.state).query=value;return;}change(s=>{s.query=value;s.page=1;});request();};
  search?.addEventListener('input',searchChanged);
  search?.addEventListener('compositionend',event=>{
    composing=false;
    // Keep the committed text even if an in-flight request changed the list to
    // an error state; retry must use the completed Chinese query.
    if(sameActor()){const s=customerControls(ctx.state);s.query=String(event.target.value||'').slice(0,100);s.page=1;}
    searchChanged(event);ctx.actions.setCustomerSearchComposing?.(false);
  });
  root.querySelector('[data-customer-filter]')?.addEventListener('click',()=>change(s=>{s.filterOpen=!s.filterOpen;}));
  root.querySelectorAll('[data-customer-filter-value]').forEach(el=>el.addEventListener('click',()=>{if(!Object.hasOwn(liveFilterLabels,el.dataset.customerFilterValue))return;if(change(s=>{s.filter=el.dataset.customerFilterValue;s.filterOpen=false;s.page=1;}))request();}));
  root.querySelectorAll('[data-customer-sort]').forEach(el=>el.addEventListener('click',()=>{const sort=el.dataset.customerSort;if(!['intent','reply','time','post'].includes(sort))return;if(change(s=>{s.sortDirection=s.sort===sort&&s.sortDirection==='desc'?'asc':'desc';s.sort=sort;s.page=1;}))request();}));
  root.querySelectorAll('[data-customer-row]').forEach(el=>{el.addEventListener('click',event=>{if(event.target.closest?.('button,input'))return;select(el.dataset.customerRow);});el.addEventListener('keydown',event=>{if(event.target===el&&['Enter',' '].includes(event.key)){event.preventDefault();select(el.dataset.customerRow);}});});
  root.querySelectorAll('[data-customer-action]').forEach(el=>el.addEventListener('click',async()=>{const id=el.dataset.customerAction;await select(id);if(sameActor())ctx.actions.openCustomerReply?.(id);}));
  root.querySelectorAll('[data-customer-check]').forEach(el=>el.addEventListener('change',()=>{const id=el.dataset.customerCheck;if(!customerModel(ctx.state).items.some(item=>item.id===id))return;change(s=>{s.checkedIds=el.checked?[...new Set([...s.checkedIds,id])]:s.checkedIds.filter(value=>value!==id);});}));
  const allBox=root.querySelector('[data-customer-check-all]');if(allBox)allBox.indeterminate=model.controls.checkedIds.length>0&&model.controls.checkedIds.length<model.total;
  root.querySelector('[data-customer-check-all]')?.addEventListener('change',event=>{if(accepted())ctx.actions.selectAllCustomers?.(event.target.checked);});
  root.querySelectorAll('[data-customer-page]').forEach(el=>el.addEventListener('click',()=>{const current=customerModel(ctx.state),delta=el.dataset.customerPage==='previous'?-1:1,next=(current.page||1)+delta;if(next<1||next>(current.pages||1))return;if(change(s=>{s.page=next;s.selectedId='';s.evidenceOpen=false;}))request();}));
  root.querySelector('[data-customer-evidence]')?.addEventListener('click',()=>change(s=>{s.evidenceOpen=!s.evidenceOpen;}));
  root.querySelector('[data-customer-evidence-link]')?.addEventListener('click',()=>change(s=>{s.evidenceOpen=true;}));
  root.querySelector('[data-customer-source]')?.addEventListener('click',()=>{const id=currentId(),detail=ctx.state.customerDetail;if(id&&actorMatches(ctx.state,detail)&&detail.id===id&&detail.status==='ready'&&detail.item?.id===id&&detail.item?.postUrl)ctx.actions.openCustomerSource?.(id);});
  root.querySelector('[data-customer-reply]')?.addEventListener('click',()=>{if(typeof ctx.actions.openCustomerReply!=='function'){later('人工回复');return;}const id=currentId(),detail=ctx.state.customerDetail;if(id&&sameActor()&&actorMatches(ctx.state,detail)&&detail.id===id&&detail.status==='ready'&&detail.item?.id===id)ctx.actions.openCustomerReply(id);});
  root.querySelector('[data-customer-batch]')?.addEventListener('click',()=>{if(typeof ctx.actions.openCustomerBatch!=='function'){later('批量回复');return;}if(sameActor())ctx.actions.openCustomerBatch([...customerControls(ctx.state).checkedIds]);});
  const handoff=history=>{if(!personalTools(ctx.state))return;const id=currentId();if(!id)return;if(typeof ctx.actions.handoffAction!=='function'){later(history?'交接记录':'整理交接');return;}openHandoff(ctx,id,history);};
  root.querySelector('[data-customer-handoff]')?.addEventListener('click',()=>handoff(false));
  root.querySelector('[data-customer-history]')?.addEventListener('click',()=>handoff(true));
  root.querySelector('[data-customer-more]')?.addEventListener('click',()=>{const id=currentId(),p=customerModel(ctx.state).items.find(item=>item.id===id);if(!p)return;ctx.modal({title:'客户操作',html:`<h3>${esc(p.name||'未命名客户')}</h3><p>${esc(p.need||'需求信息未填写')}</p><p>可查看需求与来源证据，或使用Excel导出当前筛选结果。</p>`,confirmLabel:'知道了'});});
  root.querySelector('[data-customer-export]')?.addEventListener('click',()=>{
    if(!accepted()||ctx.state.customerExporting)return;
    const snapshot=!composing&&customerExportSnapshot(ctx.state);
    if(!snapshot){ctx.toast('客户筛选正在更新，请核对列表后再导出。');return;}
    const s=customerControls(ctx.state);
    if(s.checkedIds.length>3000){ctx.toast('已选客户最多导出3000位，请减少勾选数量后重试。');return;}
    const {payload,amount}=snapshot;
    ctx.modal({title:'导出Excel',html:`<p>将导出${s.checkedIds.length?'已选':'当前筛选的全部'} <strong>${count(amount)}</strong> 位客户。</p><p>包含客户、需求、当前意向、预算口径、自报收入、历史评级、联系状态及来源信息。</p><p class="cs-modal-note">按筛选导出最多3000位；已选客户最多3000位。超过上限时请缩小范围或减少勾选。</p>`,confirmLabel:'确认导出',onConfirm:()=>{
      const fresh=!composing&&customerExportSnapshot(ctx.state);
      if(!accepted()||!fresh||fresh.view!==snapshot.view||fresh.signature!==snapshot.signature){ctx.toast('客户范围已变化，请核对列表后重新导出。');return false;}
      return ctx.actions.exportCustomers?.(payload);
    }});
  });
  return ()=>{composing=false;};
}
