"""Candidate workflows over the SAME Store, scope, revision and receipt journal.

No platform implementation or default model is installed by this module.
"""
from copy import deepcopy
import json
import hashlib
import re
import uuid
import importlib

def _sibling(name):
    # Production uses the frozen private package created by content_extension_loader.
    # The flat branch is for this repository's explicit, pinned test harness only.
    return importlib.import_module('.' + name, __package__) if __package__ else importlib.import_module(name)

_base = _sibling('content_workbench')
BASE_ACTIONS, BASE, ENTITY = _base.ACTIONS, _base.BASE, _base.ENTITY
ContentWorkbench, ContentScope, ContentError = _base.ContentWorkbench, _base.ContentScope, _base.ContentError
digest, fail, fields, ident, now, text = _base.digest, _base.fail, _base.fields, _base.ident, _base.now, _base.text

WORKFLOW_CONTRACT = 'fangyu-content-workflow-v1'
READ_ACTIONS = frozenset(('content_knowledge_search', 'content_methods_read'))
ACTION_FIELDS = {
    'content_knowledge_import': ({'document'}, {'document'}),
    'content_knowledge_search': ({'query', 'limit'}, {'query'}),
    'content_methods_read': (set(), set()),
    'content_task_prepare': ({'methodId', 'query', 'instructions', 'topicId', 'draftId', 'evidenceIds', 'artifactIds'}, {'methodId', 'query'}),
    'content_task_run': ({'taskId'}, {'taskId'}),
    'content_task_apply': ({'taskId'}, {'taskId'}),
    'content_package_build': ({'draftId'}, {'draftId'}),
}
EXTENSION_ACTIONS = frozenset(ACTION_FIELDS)


def _json_size(value):
    try:
        return len(json.dumps(value, ensure_ascii=False, allow_nan=False).encode('utf-8'))
    except (TypeError, ValueError, OverflowError, UnicodeError):
        fail('CONTENT_INPUT_INVALID', '内容必须是有效的JSON资料')


class ContentWorkflowWorkbench(ContentWorkbench):
    def __init__(self, store, root_dir=None, model_adapter=None):
        super().__init__(store, root_dir)
        self.model_adapter = model_adapter

    @staticmethod
    def _state(row):
        state = row.setdefault('workflow', {'schemaVersion': 1, 'documents': [], 'tasks': [],
                                            'artifacts': [], 'plans': [], 'packages': []})
        if not isinstance(state, dict) or state.get('schemaVersion') != 1:
            fail('CONTENT_RECORD_INVALID', '内容工作流版本需要核对', 409)
        for name in ('documents', 'tasks', 'artifacts', 'plans', 'packages'):
            items = state.get(name)
            if not isinstance(items, list) or len(items) > 300:
                fail('CONTENT_RECORD_INVALID', '内容工作流记录需要核对', 409)
            ids = [item.get('id') for item in items if isinstance(item, dict)]
            if len(ids) != len(items) or any(not isinstance(i, str) for i in ids) or len(set(ids)) != len(ids):
                fail('CONTENT_RECORD_INVALID', '内容工作流记录需要核对', 409)
        return state

    def _public(self, row, user, account):
        answer = super()._public(row, user, account)
        answer['workflow'] = deepcopy(self._state(row))
        answer['workflowContract'] = WORKFLOW_CONTRACT
        answer['capabilities'].update(canGenerate=callable(self.model_adapter),
            generationStatus='host_adapter_configured' if callable(self.model_adapter) else 'host_adapter_required')
        answer['workflowCapabilities'] = {'canSearchKnowledge': True,
            'canRunTasks': callable(self.model_adapter), 'canExecutePlatforms': False,
            'modelVerifiedByThisModule': False, 'publishingStatus': 'package_only'}
        return answer

    @staticmethod
    def _item(items, key):
        ident(key)
        value = next((v for v in items if v['id'] == key), None)
        if value is None:
            fail('CONTENT_RECORD_MISSING', '请重新选择当前账号下的任务或资料', 409)
        return value

    def _arguments(self, action, user, store_id, data):
        optional, required = ACTION_FIELDS[action]
        save = action not in READ_ACTIONS
        fields(data, BASE | optional | ({'expectedRevision', 'requestId'} if save else set()),
               BASE | required | ({'expectedRevision', 'requestId'} if save else set()))
        if _json_size(data) > 500_000:
            fail('CONTENT_LIMIT', '单次资料较大，请分段整理后导入', 413)
        scope = ContentScope(user.get('tenant_id') if isinstance(user, dict) else '',
                             ident(store_id), ident(data['accountId']), data['platform'])
        scope.checked()
        if save and (type(data['expectedRevision']) is not int or data['expectedRevision'] < 0):
            fail('CONTENT_INPUT_INVALID', '请提供当前工作区版本')
        request = ident(data['requestId']) if save else None
        return scope, save, request, digest({'action': action, 'data': {k: v for k, v in data.items() if k != 'requestId'}})

    def _prior(self, row, action, request, input_hash):
        receipts = row.setdefault('receipts', [])
        if not isinstance(receipts, list):
            fail('CONTENT_RECORD_INVALID', '内容回执需要核对', 409)
        old = next((r for r in receipts if r.get('requestId') == request), None)
        if old and (old.get('action') != action or old.get('inputDigest') != input_hash):
            fail('CONTENT_REQUEST_CONFLICT', '同一请求编号的内容已变化，请核对原操作', 409)
        return old

    def _save(self, db, scope, actor, row, action, request, input_hash, result, authority_check, receipt_state='succeeded'):
        self._authorized(db, actor, scope, authority_check, True)
        row['revision'] += 1
        row['updatedAt'] = now()
        receipt = {'requestId': request, 'action': action, 'revision': row['revision'],
                   'inputDigest': input_hash, 'state': receipt_state}
        row['lastReceipt'] = receipt
        row.setdefault('receipts', []).append({**receipt, 'result': deepcopy(result)})
        self._write(db, scope, row)
        return receipt

    @staticmethod
    def _write(db, scope, row):
        if _json_size(row) > 8_000_000:
            fail('CONTENT_LIMIT', '内容工作区较大，请先导出整理', 409)
        db.execute('INSERT OR REPLACE INTO records VALUES(?,?,?,?)',
                   (ENTITY, row['id'], scope.tenant_id, json.dumps(row, ensure_ascii=False, allow_nan=False)))

    def execute(self, action, user, store_id, data, authority_check=None):
        if action in BASE_ACTIONS:
            return super().execute(action, user, store_id, data, authority_check)
        if action not in ACTION_FIELDS:
            fail('CONTENT_ACTION_FORBIDDEN', '当前内容操作尚未开放', 403)
        scope, save, request, input_hash = self._arguments(action, user, store_id, data)
        if action == 'content_task_run':
            return self._run(user, scope, data, request, input_hash, authority_check)
        with self.store.connect() as db:
            db.execute('BEGIN IMMEDIATE' if save else 'BEGIN')
            actor, account = self._authorized(db, user, scope, authority_check, save)
            row = self._workspace(db, scope, actor)
            state = self._state(row)
            if save:
                old = self._prior(row, action, request, input_hash)
                if old:
                    return {'workspace': self._public(row, actor, account), 'result': deepcopy(old['result']),
                            'receipt': {**{k: v for k, v in old.items() if k != 'result'}, 'found': True}, 'replayed': True}
                if row['revision'] != data['expectedRevision']:
                    fail('CONTENT_REVISION_CONFLICT', '内容已更新，请重新读取后保存', 409)
            result = self._operate(action, data, row, state, scope, actor, db)
            receipt = self._save(db, scope, actor, row, action, request, input_hash, result, authority_check) if save else None
            answer = {'workspace': self._public(row, actor, account), 'result': result}
            if receipt:
                answer['receipt'] = {**receipt, 'found': True}
            return answer

    def _operate(self, action, data, row, state, scope, actor, db):
        if action == 'content_methods_read':
            methods = _sibling('workflow_methods')
            METHODS, get_method = methods.METHODS, methods.get_method
            return {'methods': [get_method(key) for key in METHODS],
                    'contract': WORKFLOW_CONTRACT, 'platformExecution': False}
        if action == 'content_knowledge_import':
            import_document = _sibling('workflow_knowledge').import_document
            doc = fields(data['document'], {'title', 'text', 'kind', 'sourceLabel'}, {'title', 'text', 'kind', 'sourceLabel'})
            try:
                imported = import_document(doc['title'], doc['text'], doc['kind'], doc['sourceLabel'])
            except ValueError:
                fail('CONTENT_INPUT_INVALID', '请提供有来源标记的有效文本资料')
            old = next((v for v in state['documents'] if v['id'] == imported['id']), None)
            if old and any(old.get(k) != imported.get(k) for k in ('title', 'kind', 'sourceLabel')):
                fail('CONTENT_SOURCE_CONFLICT', '相同正文已有不同来源或资料类型，请先核对原记录', 409)
            if not old:
                if len(state['documents']) >= 100 or sum(len(d['text']) for d in state['documents']) + len(imported['text']) > 500_000:
                    fail('CONTENT_LIMIT', '本账号资料较多，请先整理后导入', 409)
                imported.update(importedAt=now(), importedBy=actor['username'], version=1,
                                verificationStatus='source_assertion_unverified')
                state['documents'].append(imported)
            return {'document': deepcopy(old or imported), 'alreadyImported': old is not None}
        if action == 'content_knowledge_search':
            search = _sibling('workflow_knowledge').search
            query = text(data['query'], 500, '检索内容')
            limit = data.get('limit', 5)
            if type(limit) is not int or not 1 <= limit <= 20:
                fail('CONTENT_INPUT_INVALID', '检索条数应为1到20')
            try:
                evidence = search(state['documents'], query, limit)
            except ValueError:
                fail('CONTENT_INPUT_INVALID', '检索资料需要核对')
            return {'evidence': evidence, 'factsAreSourceAssertions': True}
        if action == 'content_task_prepare':
            get_method = _sibling('workflow_methods').get_method
            method = data['methodId']
            try:
                spec = get_method(method)
            except (ValueError, KeyError, TypeError):
                fail('CONTENT_INPUT_INVALID', '请选择已配置的业务方法')
            query = text(data['query'], 500, '任务主题')
            instructions = text(data.get('instructions', ''), 2000, '任务要求', empty=True)
            evidence = self._all_evidence(state)
            if 'evidenceIds' in data:
                ids = self._ids(data['evidenceIds'], 20)
                if any(i not in evidence for i in ids):
                    fail('CONTENT_SOURCE_CHANGED', '所选资料不属于当前账号或已变化', 409)
            else:
                search = _sibling('workflow_knowledge').search
                ids = [e['evidenceId'] for e in search(state['documents'], query, 8)] if state['documents'] else []
                if data.get('draftId'):
                    # Carry the ORIGINAL evidence, not unconditionally the old claims.
                    # The next output must select and quote sources again.
                    self._find(row, 'drafts', data['draftId'])
                    origins = [a for a in state['artifacts'] if data['draftId'] in a.get('appliedRefs', {}).get('draftIds', [])]
                    if origins:
                        previous = self._item(state['tasks'], origins[-1]['taskId'])
                        ids = list(dict.fromkeys(ids + previous['evidenceIds']))
                        if len(ids) > 20:
                            fail('CONTENT_LIMIT', '原稿引用较多，请明确选择本次修订资料', 409)
            selected = self._ids(data.get('artifactIds', []), 8)
            task = {'id': uuid.uuid4().hex, 'methodId': method, 'methodDigest': digest(spec),
                    'query': query, 'instructions': instructions, 'evidenceIds': ids,
                    'artifactIds': selected, 'topicId': data.get('topicId', ''),
                    'draftId': data.get('draftId', ''), 'state': 'prepared', 'generated': False,
                    'createdAt': now(), 'createdBy': actor['username'], 'sourceRevision': row['revision']}
            task['input'] = self._context(row, state, task)
            if _json_size(task['input']) > 160_000:
                fail('CONTENT_LIMIT', '资料较多，请缩小任务引用范围', 409)
            task['inputDigest'] = digest(task['input'])
            if len(state['tasks']) >= 100:
                fail('CONTENT_LIMIT', '本账号内容任务较多，请先整理', 409)
            state['tasks'].append(task)
            return {'task': self._task_view(task), 'modelCalled': False}
        if action == 'content_task_apply':
            return self._apply(row, state, data['taskId'], scope)
        if action == 'content_package_build':
            return self._package(db, row, state, scope, data['draftId'])
        fail('CONTENT_ACTION_FORBIDDEN', '当前内容操作尚未开放', 403)

    @staticmethod
    def _ids(value, maximum):
        if (not isinstance(value, list) or len(value) > maximum
            or any(not isinstance(i, str) or not 1 <= len(i) <= 160 for i in value)
            or len(set(value)) != len(value)):
            fail('CONTENT_INPUT_INVALID', '所选引用列表无效')
        return value[:]

    @staticmethod
    def _all_evidence(state):
        result = {}
        try:
            # Use the same public integrity checks for explicit and searched refs.
            _sibling('workflow_knowledge').search(state['documents'], '资料完整性核对', 1)
            for doc in state['documents']:
                raw = doc['text']
                if doc['kind'] not in ('fact', 'hypothesis') or hashlib.sha256(raw.encode('utf-8')).hexdigest() != doc['sha256']:
                    raise ValueError()
                for c in doc['chunks']:
                    if (type(c['start']) is not int or type(c['end']) is not int
                        or not 0 <= c['start'] < c['end'] <= len(raw) or raw[c['start']:c['end']] != c['text']):
                        raise ValueError()
                    result[c['id']] = {'evidenceId': c['id'], 'documentId': doc['id'],
                        'title': doc['title'], 'text': c['text'], 'start': c['start'], 'end': c['end'],
                        'kind': doc['kind'], 'sourceLabel': doc['sourceLabel'], 'documentSha256': doc['sha256']}
        except (KeyError, TypeError, ValueError, AttributeError):
            fail('CONTENT_RECORD_INVALID', '资料原文或切片需要重新核对', 409)
        return result

    def _context(self, row, state, task):
        all_evidence = self._all_evidence(state)
        if any(i not in all_evidence for i in task['evidenceIds']):
            fail('CONTENT_SOURCE_CHANGED', '引用资料已变化', 409)
        topic = self._find(row, 'topics', task['topicId']) if task['topicId'] else None
        draft = self._find(row, 'drafts', task['draftId']) if task['draftId'] else None
        artifacts = [self._item(state['artifacts'], key) for key in task['artifactIds']]
        if any(digest(a['output']) != a['outputDigest'] for a in artifacts):
            fail('CONTENT_RECORD_INVALID', '前置任务产物需要重新核对', 409)
        return {'query': task['query'], 'instructions': task['instructions'],
                'persona': {k: deepcopy(v) for k, v in row['persona'].items() if k != 'history'},
                'topic': deepcopy(topic),
                'draft': {k: deepcopy(v) for k, v in draft.items() if k != 'history'} if draft else None,
                'evidence': [deepcopy(all_evidence[i]) for i in task['evidenceIds']],
                'artifacts': [{k: deepcopy(a[k]) for k in ('id', 'methodId', 'output', 'outputDigest')} for a in artifacts]}

    @staticmethod
    def _task_view(task):
        return {k: deepcopy(v) for k, v in task.items() if k != 'input'}

    def _apply(self, row, state, task_id, scope):
        task = self._item(state['tasks'], task_id)
        if task.get('appliedRefs') is not None:
            return {'appliedRefs': deepcopy(task['appliedRefs']), 'alreadyApplied': True}
        if task['state'] != 'succeeded' or not task.get('artifactId'):
            fail('CONTENT_TASK_NOT_APPLICABLE', '任务尚未完成或资料待重新核对，不能应用', 409)
        if digest(_sibling('workflow_methods').get_method(task['methodId'])) != task['methodDigest']:
            fail('CONTENT_METHOD_CHANGED', '生成时的方法版本已变化，请先重新核对产物', 409)
        if digest(self._context(row, state, task)) != task['inputDigest']:
            fail('CONTENT_SOURCE_CHANGED', '任务所用资料或原稿已更新，结果仍保留，请重新核对', 409)
        artifact = self._item(state['artifacts'], task['artifactId'])
        if digest(artifact['output']) != artifact['outputDigest']:
            fail('CONTENT_RECORD_INVALID', '任务产物需要重新核对', 409)
        value = artifact['output']['artifact']
        method = task['methodId']
        refs = {'draftIds': [], 'topicIds': [], 'planIds': [], 'personaVersion': None}
        if method == 'persona':
            old = row['persona']
            persona = {k: text(value[k], limit, k, empty=k not in ('name', 'positioning'))
                       for k, limit in {'name': 80, 'positioning': 400, 'audience': 600}.items()}
            for key in ('pillars', 'voice', 'avoid'):
                persona[key] = text('\n'.join(value[key]), 600, key, empty=True)
            persona['evidence'] = f"已关联{len(artifact['output']['facts'])}段原文引用，完整引文与待核假设保留在任务产物中。"
            persona.update(version=old.get('version', 0) + 1, updatedAt=now(), status='user_accepted_proposal')
            persona['history'] = deepcopy(old.get('history', [])) + [deepcopy(persona)]
            row['persona'] = persona
            refs['personaVersion'] = persona['version']
        elif method == 'topics':
            if len(row['topics']) + len(value['topics']) > 500:
                fail('CONTENT_LIMIT', '选题较多，请先整理', 409)
            evidence = {e['evidenceId']: e for e in task['input']['evidence']}
            for topic in value['topics']:
                item = {k: text(topic.get(k, ''), limit, k, empty=k != 'title') for k, limit in
                        {'title': 120, 'column': 80, 'goal': 80}.items()}
                item.update(id=uuid.uuid4().hex, format=topic['format'], status='planned', updatedAt=now(),
                    proof=f"已关联{len(topic['evidenceIds'])}段资料，原文引用保留在选题任务中。")
                self._upsert(row, 'topics', item)
                refs['topicIds'].append(item['id'])
        elif method in ('writing', 'video', 'revision'):
            old = self._find(row, 'drafts', task['draftId']) if method == 'revision' and task['draftId'] else None
            if method == 'revision' and old is None:
                fail('CONTENT_INPUT_INVALID', '修订任务需要明确原稿')
            fmt = old['format'] if old else 'video' if method == 'video' else 'image'
            body = value['body'] if method == 'writing' else value['script'] if method == 'video' else value['revisedBody']
            if method == 'writing' and value['tags']:
                body += '\n\n' + ' '.join('#' + tag.lstrip('#') for tag in value['tags'])
            if old:
                for change in value['changes']:
                    target = change['target']
                    if target not in ('title', 'body', 'script') or change['original'] not in old[target]:
                        fail('CONTENT_SOURCE_CHANGED', '修订说明与原文不一致，产物已保留', 409)
            draft = {'id': old['id'] if old else uuid.uuid4().hex,
                'topicId': old['topicId'] if old else task['topicId'],
                'format': fmt, 'title': text(value['title'], 120, '标题'),
                'body': text(body, 12000, '正文') if fmt == 'image' else old['body'] if old else '',
                'script': text(body, 12000, '口播') if fmt == 'video' else old['script'] if old else '',
                'notes': old['notes'] if old else '模型生成候选，来源、价格、服务及素材仍需人工核对。',
                'assetIds': deepcopy(old['assetIds']) if old else [], 'status': 'draft', 'audit': None,
                'version': old['version'] + 1 if old else 1, 'updatedAt': now(),
                'history': deepcopy(old['history']) if old else []}
            if old and old['assetIds']:
                draft['assetsNeedReview'] = True
            draft['history'].append(self._draft_snapshot(draft))
            self._upsert(row, 'drafts', draft)
            refs['draftIds'].append(draft['id'])
            artifact['draftTextDigest'] = digest({k: draft[k] for k in ('title', 'body', 'script')})
        else:
            if method == 'package':
                if value['platform'] != scope.platform:
                    fail('CONTENT_ACCOUNT_CHANGED', '内容包平台与当前账号不同', 403)
                for key in value['assetRefs']:
                    self._find(row, 'assets', key)
            if method == 'scheduling':
                for slot in value['slots']:
                    if slot['accountId'] != scope.account_id:
                        fail('CONTENT_ACCOUNT_CHANGED', '排期包含其他账号，请分别准备任务', 403)
                    self._find(row, 'drafts', slot['contentId'])
            if len(state['plans']) >= 250:
                fail('CONTENT_LIMIT', '运营方案较多，请先整理', 409)
            plan = {'id': uuid.uuid4().hex, 'methodId': method, 'artifactId': artifact['id'],
                    'value': deepcopy(value), 'state': 'user_accepted_proposal',
                    'createdAt': now(), 'executed': False, 'accountId': scope.account_id}
            state['plans'].append(plan)
            refs['planIds'].append(plan['id'])
        artifact.update(state='applied', appliedAt=now(), appliedRefs=deepcopy(refs))
        task.update(appliedAt=now(), appliedRefs=deepcopy(refs))
        return {'appliedRefs': refs, 'alreadyApplied': False, 'platformExecuted': False}

    def _package(self, db, row, state, scope, draft_id):
        draft = self._find(row, 'drafts', draft_id)
        audit = draft.get('audit')
        if (draft.get('status') != 'approved' or not isinstance(audit, dict)
            or audit.get('draftVersion') != draft['version'] or audit.get('humanReviewed') is not True
            or audit.get('decision') != 'approve'):
            fail('CONTENT_AUDIT_REQUIRED', '请先核对并审核当前版本的稿件', 409)
        origins = [a for a in state['artifacts'] if draft_id in a.get('appliedRefs', {}).get('draftIds', [])]
        origin = origins[-1] if origins else None
        if origin and origin.get('draftTextDigest') != digest({k: draft[k] for k in ('title', 'body', 'script')}):
            fail('CONTENT_SOURCE_CHANGED', '稿件文字已修改，请重新核对引用并通过修订任务应用', 409)
        if origin and digest(origin['output']) != origin['outputDigest']:
            fail('CONTENT_RECORD_INVALID', '来源产物需要核对', 409)
        assets = []
        for key in draft['assetIds']:
            asset = self._asset_read(db, scope, row, key)
            if asset.get('rightsConfirmed') is not True:
                fail('CONTENT_RIGHTS_REQUIRED', '请先核对素材授权')
            assets.append({k: deepcopy(asset[k]) for k in ('id', 'name', 'mime', 'sha256', 'source')})
        package_id = digest([WORKFLOW_CONTRACT, scope.checked(), self._draft_snapshot(draft), audit,
                             assets, origin['outputDigest'] if origin else None])
        old = next((p for p in state['packages'] if p['id'] == package_id), None)
        if old:
            return deepcopy(old['export'])
        if len(state['packages']) >= 100:
            fail('CONTENT_LIMIT', '内容包较多，请先整理', 409)
        citations = deepcopy(origin['output']['facts']) if origin else []
        source_task = self._item(state['tasks'], origin['taskId']) if origin else None
        source_evidence = source_task['input']['evidence'] if source_task else []
        source_titles = list(dict.fromkeys(e['title'] for e in source_evidence))
        packet = {'id': package_id, 'platform': scope.platform, 'accountId': scope.account_id,
            'draftId': draft_id, 'draftVersion': draft['version'], 'format': draft['format'],
            'title': draft['title'], 'body': draft['body'], 'script': draft['script'], 'assets': assets,
            'state': 'needs_video_asset' if draft['format'] == 'video' else 'needs_asset_review' if draft.get('assetsNeedReview') else 'package_ready' if assets else 'needs_assets',
            'published': False, 'platformExecuted': False, 'audit': deepcopy(audit),
            'citations': citations, 'hypotheses': deepcopy(origin['output']['hypotheses']) if origin else [],
            'sourceEvidence': deepcopy(source_evidence), 'factsVerified': False,
            'provenanceStatus': 'source_quotes_reviewed_by_user' if origin else 'manual_draft_user_reviewed',
            'createdAt': now()}
        content = '# ' + draft['title'] + '\n\n'
        if draft['format'] == 'video':
            if draft['body']:
                content += '## 视频配文\n\n' + draft['body'] + '\n\n'
            content += '## 口播脚本\n\n' + draft['script']
        else:
            content += draft['body']
            if draft['script']:
                content += '\n\n## 配套口播\n\n' + draft['script']
        if source_titles:
            content += '\n\n## 参考资料\n\n' + '\n'.join('- ' + title for title in source_titles)
        content += '\n\n## 发布准备\n\n此内容包尚未发布。请核对实际价格、服务、发文账号及素材授权。\n'
        if not assets or draft['format'] == 'video':
            content += '图片或视频素材尚未备齐，需要继续制作并核对。\n'
        if draft.get('assetsNeedReview'):
            content += '修订已保留原有配图，请核对图片与新文案是否一致。\n'
        output = {'package': packet, 'fileName': re.sub(r'[\x00-\x1f\\/:*?"<>|]', '', draft['title'])[:60] + '.md',
                  'mime': 'text/markdown;charset=utf-8', 'content': content}
        state['packages'].append({'id': package_id, 'draftId': draft_id, 'draftVersion': draft['version'],
                                   'state': packet['state'], 'export': deepcopy(output)})
        return output

    def _run(self, user, scope, data, request, input_hash, authority_check):
        methods = _sibling('workflow_methods')
        get_method, validate_result = methods.get_method, methods.validate_result
        action = 'content_task_run'
        # Commit the action key BEFORE calling the injected external boundary.
        # A crash after this commit is pending/unknown, never permission to replay.
        with self.store.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            actor, account = self._authorized(db, user, scope, authority_check, True)
            row = self._workspace(db, scope, actor)
            state = self._state(row)
            old = self._prior(row, action, request, input_hash)
            if old:
                return {'workspace': self._public(row, actor, account), 'result': deepcopy(old['result']),
                        'receipt': {**{k: v for k, v in old.items() if k != 'result'}, 'found': True}, 'replayed': True}
            if row['revision'] != data['expectedRevision']:
                fail('CONTENT_REVISION_CONFLICT', '内容已更新，请重新读取后执行', 409)
            task = self._item(state['tasks'], data['taskId'])
            if task['state'] != 'prepared':
                fail('CONTENT_TASK_ALREADY_RUN', '该任务已有执行记录，请先核对原请求，不能重复执行', 409)
            spec = get_method(task['methodId'])
            if digest(spec) != task['methodDigest']:
                fail('CONTENT_METHOD_CHANGED', '方法版本已变化，请重新准备任务', 409)
            if digest(self._context(row, state, task)) != task['inputDigest']:
                fail('CONTENT_SOURCE_CHANGED', '任务所用资料或稿件已更新，请重新准备', 409)
            if not callable(self.model_adapter):
                fail('CONTENT_MODEL_UNAVAILABLE', '尚未接通宿主模型，任务已保留且未执行', 503)
            if _json_size(row) > 6_500_000 or len(state['artifacts']) >= 250:
                fail('CONTENT_LIMIT', '请先整理内容工作区，再执行新任务', 409)
            run_id = digest([WORKFLOW_CONTRACT, scope.checked(), actor['username'], request])
            task.update(state='running', runId=run_id, runRequestId=request, startedAt=now(),
                        retryAllowed=False, requiresReconciliation=True)
            envelope = {'contract': WORKFLOW_CONTRACT, 'requestId': run_id, 'taskId': task['id'],
                'scope': {**scope.checked(), 'actor': actor['username']},
                'method': spec, 'input': deepcopy(task['input']), 'inputDigest': task['inputDigest'],
                'requirements': {'platformActionsAllowed': False, 'humanReviewRequired': True,
                                 'sourceTextIsUntrustedData': True}}
            result = {'task': self._task_view(task), 'modelCalled': None, 'dispatchReserved': True, 'retryAllowed': False}
            self._save(db, scope, actor, row, action, request, input_hash, result, authority_check, 'running')
        # No Store connection or write transaction is held here.
        outcome, output, error = 'unknown', None, 'CONTENT_MODEL_RESULT_UNKNOWN'
        try:
            response = self.model_adapter(deepcopy(envelope))
            if (isinstance(response, dict) and set(response) <= {'state', 'requestId', 'output'}
                and response.get('requestId') == run_id):
                if response.get('state') == 'known_not_executed' and response.get('output') is None:
                    outcome, error = 'known_not_executed', 'CONTENT_MODEL_NOT_EXECUTED'
                elif response.get('state') == 'succeeded':
                    outcome, error = 'completed_invalid', 'CONTENT_MODEL_OUTPUT_INVALID'
                    if _json_size(response.get('output')) <= 120_000:
                        citations = {e['evidenceId']: {'text': e['text'], 'kind': e['kind']}
                                     for e in envelope['input']['evidence']}
                        output = validate_result(envelope['method']['id'], response.get('output'), citations)
                        outcome, error = 'succeeded', None
        except Exception:
            # Do not persist provider exceptions, credentials, raw invalid text or tracebacks.
            # If validation was reached, provider execution happened but output is unusable.
            output = None
        with self.store.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            actor, account = self._authorized(db, user, scope, authority_check, True)
            row = self._workspace(db, scope, actor)
            state = self._state(row)
            current = self._item(state['tasks'], data['taskId'])
            if current.get('runId') != run_id or current['state'] != 'running':
                fail('CONTENT_RECORD_INVALID', '任务执行回执需要核对，未自动重试', 409)
            stale = False
            if output is not None:
                try:
                    stale = digest(self._context(row, state, current)) != current['inputDigest']
                except ContentError as exc:
                    if exc.code not in ('CONTENT_RECORD_MISSING', 'CONTENT_SOURCE_CHANGED'):
                        raise
                    stale = True
                artifact = {'id': uuid.uuid4().hex, 'taskId': current['id'], 'methodId': current['methodId'],
                    'output': output, 'outputDigest': digest(output), 'sourceDigest': current['inputDigest'],
                    'state': 'candidate_stale' if stale else 'candidate', 'humanReviewed': False,
                    'createdAt': now(), 'modelRequestId': run_id}
                state['artifacts'].append(artifact)
                current['artifactId'] = artifact['id']
                if stale:
                    outcome, error = 'needs_revalidation', 'CONTENT_SOURCE_CHANGED'
            current.update(state=outcome, generated=output is not None, errorCode=error,
                           requiresReconciliation=outcome == 'unknown', requiresRevalidation=stale,
                           completedAt=now(), retryAllowed=False, billingVerified=False,
                           generatorKind='injected_host_adapter', modelExecutionVerified=False)
            result = {'task': self._task_view(current), 'artifactId': current.get('artifactId'),
                      'modelCalled': True, 'requiresHumanReview': True, 'published': False}
            self._authorized(db, actor, scope, authority_check, True)
            row['revision'] += 1
            row['updatedAt'] = now()
            receipt = self._prior(row, action, request, input_hash)
            if receipt is None:
                fail('CONTENT_RECORD_INVALID', '原请求回执缺失，未重新执行', 409)
            receipt.update(state=outcome, revision=row['revision'], result=deepcopy(result), retryAllowed=False)
            row['lastReceipt'] = {k: deepcopy(v) for k, v in receipt.items() if k != 'result'}
            self._write(db, scope, row)
            return {'workspace': self._public(row, actor, account), 'result': result,
                    'receipt': {**row['lastReceipt'], 'found': True}}
