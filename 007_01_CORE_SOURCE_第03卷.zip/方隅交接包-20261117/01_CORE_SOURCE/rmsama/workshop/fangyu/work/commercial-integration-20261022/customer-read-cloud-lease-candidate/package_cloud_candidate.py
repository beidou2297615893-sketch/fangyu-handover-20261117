"""Assemble a held code-only candidate; does not deploy or read secrets."""
from pathlib import Path,PurePosixPath
from datetime import datetime,timezone
import hashlib,json,shutil,zipfile
D=Path(__file__).resolve().parent
BASE=D.parent/'content-cloud-v3-final2'
T=D/'code-package'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text('utf-8-sig'))
assert not T.exists()
review=read(D/'ROOT-SOURCE-SERVICE-REVIEW.json')
assert review['status']=='ROOT_SOURCE_SERVICE_VALIDATED_NOT_DEPLOYED'
expected={row['path']:row for row in read(BASE/'FILES-SHA256.json')}
changes={row['path']:row for row in review['sourceFiles']}
assert set(changes)=={'index.js','devices.cjs','release.cjs','service.cjs','customer_read_release.cjs'}
for row in changes.values():assert sha(D/'cloud-candidate-final'/row['path'])==row['afterSha256']
T.mkdir()
rows=[]
for name in sorted(set(expected)|set(changes)):
    p=PurePosixPath(name)
    assert not p.is_absolute() and '..' not in p.parts
    old=BASE/'candidate'/name
    if name in expected:
        assert old.is_file() and not old.is_symlink()
        assert not getattr(old.stat(),'st_file_attributes',0)&0x400
        assert sha(old)==expected[name]['sha256'] and old.stat().st_size==expected[name]['bytes']
    src=D/'cloud-candidate-final'/name if name in changes else old
    dst=T/name
    dst.parent.mkdir(parents=True,exist_ok=True)
    shutil.copy2(src,dst)
    rows.append({'path':name,'sha256':sha(dst),'bytes':dst.stat().st_size})
assert len(expected)==5616 and len(rows)==5617
assert 'CONTENT_RELEASE_ENABLED=false' in (T/'content_release.cjs').read_text('utf-8').replace(' ','')
assert 'LEGACY_AI_EXTENSIONS_ENABLED=false' in (T/'legacy_release.cjs').read_text('utf-8').replace(' ','')
index=D/'CODE-PACKAGE-FILES.json'
index.write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n','utf-8')
h=hashlib.sha256()
for row in rows:h.update((row['path']+'\0'+row['sha256']+'\n').encode())
archive=D/'customer-read-cloud-held.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for row in rows:z.write(T/row['path'],row['path'])
result={'status':'HELD_CODE_CANDIDATE_NOT_DEPLOYED','utc':datetime.now(timezone.utc).isoformat(),
    'files':len(rows),'treeSha256':h.hexdigest(),'fileIndexSha256':sha(index),
    'codeZipSha256':sha(archive),'codeZipBytes':archive.stat().st_size,
    'sourceChanges':review['sourceFiles'],'baselineTreeSha256':read(BASE/'DEPLOYMENT-READBACK.json')['treeSha256'],
    'customerReadEnabledByCodeAlone':False,'contentAndLegacyFeaturesClosed':True,
    'externalActions':False,'environmentOrPrivateStateReadOrWritten':False,
    'deploymentBlock':'Original official CloudBase CLI currently reports login/credential error; preserve breakpoint. No new credentials requested.',
    'pending':['local client compiled integration','independent source review','fresh live baseline CAS','existing account login recovery','code deploy/readback','two exact non-secret read feature flags with configuration-preservation verification']}
(D/'CODE-PACKAGE.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n','utf-8')
print(json.dumps({k:result[k] for k in ('status','files','treeSha256','codeZipSha256','codeZipBytes')},ensure_ascii=False))
