---
name: xhs-series-planner
description: >-
  Turn one Xiaohongshu topic, project, experiment, or product workflow into a coherent multi-post series with
  distinct episode jobs, escalating proof, callbacks, and follow-up hooks. Use when planning 5-10 related posts,
  building a repeatable 栏目, 系列规划, 连载, 选题日历, 内容排期, or avoiding isolated one-off content.
---

# Xiaohongshu Series Planner

Design a series in which every episode earns its place and advances the viewer's understanding.

## Workflow

1. Read the account DNA and define the series promise in one sentence.
2. Choose a series arc:
   - Build in public: problem -> build -> test -> result -> iteration.
   - Investigation: question -> evidence -> comparison -> conclusion.
   - Transformation: before -> interventions -> checkpoints -> after.
   - Curriculum: foundations -> application -> mistakes -> advanced use.
3. Define one job per episode. Do not split a list mechanically.
4. Vary content functions across discovery, trust, save value, proof, and conversation.
5. Add a concrete asset or evidence item to each episode.
6. Add a natural callback and next-episode hook without withholding the current episode's promised value.
7. Check that titles are distinct and the series remains understandable out of order.

Use `references/series-schema.md` for the planning table.

## Output

Return the series promise, audience journey, 5-10 episode plan, production dependencies, publishing order, and success signal for each episode.

