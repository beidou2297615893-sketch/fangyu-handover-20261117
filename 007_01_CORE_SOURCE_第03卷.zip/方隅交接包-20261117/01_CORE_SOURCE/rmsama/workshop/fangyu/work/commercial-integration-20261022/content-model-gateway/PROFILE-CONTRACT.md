# Native只读能力合同

既有成员会话鉴权的ai_profile结果data新增content_generation_capability，contract固定fangyu-content-capability-v1。请求仅environment_id、operation、可选connectivity_check；读取此能力不要请求真实connectivity_check。默认profile严格只读，不探测模型。

| 字段 | 含义 |
| --- | --- |
| enabled / available / reason | 服务器是否显式开启、所有配置与当前中央范围是否通过、拒绝原因 |
| tenant_id / tenant_mapping_verified / policy_revision | 服务器策略租户、与原Native摘要算法匹配、策略版本；不可由客户端选择 |
| config_revision / rules_version | 原企业AI当前版本 |
| supported_platforms | 当前仅xiaohongshu |
| store_scope_verified / store_scope_type / store_scope_count | 原中央范围核对、company或store、授权店数；不是选中账号核验 |
| central_catalog_revision / central_catalog_digest | 原manifest版本和摘要 |
| central_grant_revision | 与原store_config_read相同的会话及授权指纹；不是授权凭证 |
| selected_account_verified | 永远false，Native及生成时另核 |
| generation_scope_check_required / read_only | 永远true |

缺字段、旧服务器、contract不符、enabled/available非严格true、租户未核或可信上下文不完整时，Native不得装真实生成适配器。中央版本可与既有store_config_read结果比对。新增字段留在宿主门禁，不能加进适配器精确10项trusted_context；wire字段不变。

reason枚举：server_policy_missing、server_policy_invalid、tenant_mapping_missing、server_disabled、tenant_mapping_mismatch、member_not_allowed、store_scope_required、central_scope_unavailable、feature_unavailable、ai_disabled、provider_not_configured、model_unavailable、ready。HQ没有固定store_id是正常状态，有中央公司目录即可ready；operator缺单店授权或授权店被撤则不可用。

expected_device_id取现有platform service已绑定执行设备，不能取Integrations.sessions记住登录安装ID，不新建、切换或认领设备。服务器以原账号声明关联执行设备再核owner、未撤销、唯一账号/UID声明；客户端ID只是待核对断言。

原grant_revision含session摘要和到期时间。每次仍用原authority核当前会话；缓存绑定同一成员角色/授权集合的稳定摘要和中央版本，允许合法续期读原结果。授权、设备、目录、配置变化不可交付旧候选，不自动重派。

profile不返回claim、UID、账号/设备明文或secret，也不证明本地账号属于所选店、平台Cookie有效、预算足够或模型已可调用。生成仍独立核完整scope和预算。当前真实生产源码无此字段，第二版未部署，不能拿合成profile冒充服务器回执。
