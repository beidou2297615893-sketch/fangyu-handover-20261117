from pathlib import Path
import hashlib,json
W=Path(__file__).resolve().parent;S=W/'source-candidate';N=S/'work/ui-native-r57'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
actions="'content_schedule_plan','content_schedule_read','content_schedule_arm','content_schedule_control','content_schedule_tick','content_schedule_reconcile'"
edits=[]
def edit(path,replacements):
    raw=path.read_bytes();newline=b'\r\n' if b'\r\n' in raw else b'\n';body=raw.decode('utf-8').replace('\r\n','\n')
    for old,new,count in replacements:
        found=body.count(old);assert found==count,(path.name,old[:90],found,count)
        body=body.replace(old,new)
    changed=body.encode('utf-8').replace(b'\n',newline);path.write_bytes(changed)
    edits.append({'path':path.relative_to(S).as_posix(),'beforeSha256':hashlib.sha256(raw).hexdigest(),'afterSha256':sha(path),'bytesBefore':len(raw),'bytesAfter':len(changed)})
edit(N/'content_extension_loader.py',[
    ("'content_publishing.py', 'publication_protocol.py'","'content_publishing.py', 'content_schedule.py', 'publication_protocol.py'",1),
    ("cls = modules['content_publishing'].ContentPublicationWorkbench","cls = modules['content_schedule'].ContentScheduleWorkbench",1)])
edit(N/'freeze_ui.py',[("'content_publishing.py','publication_protocol.py'","'content_publishing.py','content_schedule.py','publication_protocol.py'",1)])
oldtuple="('content_task_run','content_task_reconcile','content_publish_confirm','content_publish_reconcile')"
newtuple="('content_task_run','content_task_reconcile','content_publish_confirm','content_publish_reconcile','content_schedule_tick','content_schedule_reconcile')"
edit(N/'ui_native_host.py',[
    ("'content_publish_prepare','content_publish_confirm','content_publish_read','content_publish_reconcile'","'content_publish_prepare','content_publish_confirm','content_publish_read','content_publish_reconcile',"+actions,1),
    (oldtuple,newtuple,1)])
backend=N/'workbench_backend.py'
body=backend.read_bytes().decode('utf-8');old_loader=__import__('re').search(r"CONTENT_EXTENSION_LOADER_SHA = '([0-9a-f]{64})'",body).group(1)
edit(backend,[
    ("'content_publish_prepare','content_publish_confirm','content_publish_read','content_publish_reconcile'","'content_publish_prepare','content_publish_confirm','content_publish_read','content_publish_reconcile',"+actions,1),
    (old_loader,sha(N/'content_extension_loader.py'),1),
    ("    'content_publishing.py':", "    'content_schedule.py': '"+sha(N/'content_schedule.py')+"',\n    'content_publishing.py':",1),
    ("action.startswith('content_publish_')","(action.startswith('content_publish_') or action in ('content_schedule_tick','content_schedule_reconcile'))",1),
    ("            workbench=component(self.core.store,model_adapter=host_model if callable(adapter) else None,publish_port=publication_port)",
     "            workbench=component(self.core.store,model_adapter=host_model if callable(adapter) else None,publish_port=publication_port)\n            with self.lock:\n                if not hasattr(self,'_content_schedule_grants'):self._content_schedule_grants={}\n                workbench.schedule_grants=self._content_schedule_grants\n                workbench.schedule_session_key=hashlib.sha256(token.encode()).hexdigest()",1),
    (oldtuple,newtuple,4)])
edit(S/'work/ui-approved-implementation/ui-preview/backend.mjs',[
    ("'content_guided_catalog_read','content_guided_read','content_guided_save','content_store_context_read'",actions+",'content_guided_catalog_read','content_guided_read','content_guided_save','content_store_context_read'",1)])
(W/'INTEGRATION-EDITS.json').write_text(json.dumps(edits,ensure_ascii=False,indent=2)+'\n','utf-8')
print(json.dumps({'edited':len(edits),'newModuleSha256':sha(N/'content_schedule.py')}))
