# 配文和口播双字段保留修复

仅修改本独立候选，没有修改stage、当前v65、生产数据或会话。旧源码包及摘要已保存在`work/backups/before-video-caption-fix`，旧ZIP摘要为a38847e8a502dd9bce70cb7d4e235d4f464d71f032818f509cca9746546e1513。新包以本目录最新VERIFICATION.json、TESTED-LOADER-PINS.json、CANDIDATE-FILES.json为准，不混用旧pins。

原问题：revision按稿型构造草稿时，把次要字段固定清空。旧video的body配文会在修订script后消失；旧image的script配套口播也有同类问题。

修复：只更新该稿型的主要字段，另一字段沿用旧稿；素材、备注、历史和原文引用沿用既有保留合同。内容包元数据保留两字段，Markdown相应区分视频配文、口播脚本或配套口播，避免导出再次遗漏。

公开接口正例使用同一真实临时Store，通过原content_draft_save保存body/script双字段、配图和备注，再经注入的虚构revision结果、task_apply、原人工审核和package_build核验。视频正例覆盖配文、修订后的口播、原配图、备注、历史原文、引文及导出；图文正例覆盖正文改变而配套口播不变；既有修订素材/引用保留测试同时通过。旧客户业务哨兵不变。

先红后绿证据：RED-video-caption-retention.log、RED-image-companion-retention.log、GREEN-dual-field-retention.log。最终整套结果见FINAL-tests.log与VERIFICATION.json；源码包由verify_candidate.py按新的四源码pins重建，不含测试Store。
