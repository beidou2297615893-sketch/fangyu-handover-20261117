# 第三版设计与固定资源对应

使用本地已核MIT方法正文，保留许可、来源commit、路径与SHA256。先定位→选题→写作单链，再扩展确有资源的方法。
旧17方法及digest逐字保留，新任务才选新版本；run/reconcile/apply/前置产物均按原任务digest取法。云对旧方法使用原catalog绑定锚点，原键status不换方法、不产生新费用。
客户资料及前置产物仅进入user数据；固定正文来自受信目录。无新网络、费用或执行器。

| 业务 | 完整来源 | 状态 |
| --- | --- | --- |
| 目标与策略 | @chenjin-cmd/agent-skills-launch-pack_:skills/xiaohongshu-account-launch-expert/SKILL.md, @chenjin-cmd/agent-skills-launch-pack_:skills/xiaohongshu-account-launch-expert/references/launch-playbook.md | full_method_text 当前趋势/官方规则未联网核验；只能基于提供资料形成待审计划。 |
| 账号人设 | xhs-account-dna/SKILL.md, xhs-account-dna/assets/account-dna-template.md, xhs-account-dna/references/dna-schema.md | full_method_text  |
| 账号主页 | @mengke-wang/xiaohongshu-ai-workbench:xiaohongshu-profile/SKILL.md | full_method_text 只有主页诊断/改写候选，不写平台主页。 |
| 对标研究 | xhs-reference-deconstructor/SKILL.md, references/justone-api.md, references/websearch-fallback.md, xhs-reference-deconstructor/references/analysis-schema.md | full_method_text 全文分析方法已接；联网取帖/API/实时指标未接。 |
| 内容选题 | xhs-topic-radar/SKILL.md, references/justone-api.md, references/websearch-fallback.md, xhs-topic-radar/references/evidence-schema.md | full_method_text 选题全文已接；实时采样和外部API未接。 |
| 栏目与节奏 | xhs-series-planner/SKILL.md, xhs-series-planner/references/series-schema.md | full_method_text  |
| 笔记与文案 | xhs-note-writer/SKILL.md, references/ai-voice-guardrails.md, references/voice-cold-start.md, references/justone-api.md, references/websearch-fallback.md, xhs-publish-guard/references/compliance-rewrite.md, xhs-publish-guard/references/review-rubric.md, references/format-playbook.md, references/obsidian-archive.md, xhs-note-writer/references/carousel-copy-schema.md, xhs-note-writer/references/video-caption-schema.md, xhs-note-writer/references/style-extraction-schema.md, xhs-note-writer/references/title-craft.md, xhs-note-writer/references/user-style-library.md | full_method_text  |
| 视频脚本 | xhs-video-director/SKILL.md, references/format-playbook.md, xhs-video-director/references/shot-schema.md | full_method_text 完整脚本/分镜方法，不代表视频生成或渲染完成。 |
| 图文视觉 | xhs-visual-lab/SKILL.md, references/format-playbook.md, xhs-visual-lab/assets/cover-brief-template.md, xhs-visual-lab/references/layout-readability-gate.md, xhs-visual-lab/references/visual-checklist.md | full_method_text 完整视觉方法，不代表图片生成或渲染完成。 |
| 素材知识 | @pigbiglong/xiaohongshu-ops-skill:references/knowledge-base.md | complete_reference_guide 完整记录指南已接文字整理；Hermes记忆双写和外部文件库未接。 |
| 草稿修订 | xhs-publish-guard/SKILL.md, references/ai-voice-guardrails.md, references/voice-cold-start.md, xhs-publish-guard/references/compliance-rewrite.md, xhs-publish-guard/references/review-rubric.md, references/obsidian-archive.md, xhs-note-writer/references/title-craft.md | adapted_full_resource  |
| 内容审核 | xhs-publish-guard/SKILL.md, references/ai-voice-guardrails.md, references/voice-cold-start.md, xhs-publish-guard/references/compliance-rewrite.md, xhs-publish-guard/references/review-rubric.md, references/obsidian-archive.md, xhs-note-writer/references/title-craft.md | full_method_text  |
| 内容包 | @veeicwgy/ip-publisher:skills/ip-publisher/SKILL.md, @veeicwgy/ip-publisher:docs/publish-package.md | adapted_publish_package_text 只输出所选小红书范围的待审内容包，不接媒体制作、平台分发或Wechatsync。 |
| 排期草案 | @chenjin-cmd/agent-skills-launch-pack_:skills/xiaohongshu-account-launch-expert/SKILL.md, @chenjin-cmd/agent-skills-launch-pack_:skills/xiaohongshu-account-launch-expert/references/launch-playbook.md | adapted_calendar_playbook 起号日历为计划；实际日期/时区需用户资料，定时执行器未接。 |
| 互动草稿 | @mengke-wang/xiaohongshu-ai-workbench:xiaohongshu-comment-reply/SKILL.md, @mengke-wang/xiaohongshu-ai-workbench:xiaohongshu-conversion-path/SKILL.md | full_comment_method_dm_questions_only 评论回复有完整方法，私信仅筛选问题和草稿适配；没有完整DM对话方法或发送执行器。 |
| 增长复盘 | xhs-growth-review/SKILL.md, xhs-growth-review/references/format-benchmarks.md, xhs-growth-review/references/metrics-schema.md | full_method_text  |
| 经验学习 | xhs-growth-review/SKILL.md, xhs-growth-review/references/format-benchmarks.md, xhs-growth-review/references/metrics-schema.md | adapted_full_resource  |

原9方法+24份参考及4个MIT项目的8份追加全文，共41份原字节已核。每任务只装必要资源，不把43项目全拼进提示词。
九方法包的6项缺口经43项目复查补入对应完整方法/指南；修订、学习、知识、日历、内容包及DM适配范围如表说明，不能把方法正文当已接通执行器。
homepage/comment来自mengke；strategy/calendar来自chenjin小红书起号；knowledge来自pigbiglong完整记录指南；package来自veeicwgy。dbskill的CC BY-NC许可未进入商业候选。
公开验证边界：真实临时Store prepare/run/apply/reconcile→可信envelope→注入式适配器→真实createService；只替换外部数据库/provider。验证完整正文实际进入provider、跨阶段引用、原任务恢复和资源损坏拒绝；不能证明真实模型内容质量。
