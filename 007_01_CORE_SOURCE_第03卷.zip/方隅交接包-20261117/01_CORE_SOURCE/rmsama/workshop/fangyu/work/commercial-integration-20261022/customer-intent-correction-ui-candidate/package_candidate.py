from pathlib import Path
import hashlib,json,difflib,datetime
W=Path(__file__).resolve().parent
baseline=json.loads((W/'BASE-HASHES.json').read_text(encoding='utf-8-sig'))
source=Path(baseline['source'])
files=['app.mjs','backend.mjs','pages/customers.mjs','pages/customers.css','pages/customer-intent-correction.mjs']
dig=lambda p:hashlib.sha256(p.read_bytes()).hexdigest() if p.exists() else None
manifest=[];diff=[]
for relative in files:
    old=W/'base'/relative;new=W/'candidate'/relative
    oldtext=old.read_text(encoding='utf-8').splitlines(keepends=True) if old.exists() else []
    newtext=new.read_text(encoding='utf-8').splitlines(keepends=True)
    diff.extend(difflib.unified_diff(oldtext,newtext,fromfile='a/'+relative if old.exists() else '/dev/null',tofile='b/'+relative))
    manifest.append({'path':relative,'baseSha256':dig(old),'candidateSha256':dig(new),'currentSourceSha256':dig(source/relative),'sourceStillMatchesBase':dig(source/relative)==dig(old)})
(W/'customer-intent-correction.patch').write_text(''.join(diff),encoding='utf-8',newline='')
(W/'CANDIDATE-HASHES.json').write_text(json.dumps({'createdUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceModifiedByThisTask':False,'files':manifest,'patchSha256':dig(W/'customer-intent-correction.patch')},ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(manifest,ensure_ascii=False,indent=2))
