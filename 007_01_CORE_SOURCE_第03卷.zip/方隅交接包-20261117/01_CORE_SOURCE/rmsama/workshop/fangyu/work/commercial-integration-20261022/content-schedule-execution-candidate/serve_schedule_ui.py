"""Owned full Native HTTP fixture for development Chromium; no Native window."""
from pathlib import Path
import hashlib,http.client,importlib.util,json,os,sys,threading,time,uuid
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;P=W.parents[2];inputs=json.loads((W/'QA-INPUTS.json').read_text('utf-8'));stage=inputs['stage'];S=Path(inputs['project']);R=Path(stage['release']);out=W/('ui-http-'+uuid.uuid4().hex);out.mkdir();stop=out/'STOP';events=[]
def audit(event,args):
 if event in ('subprocess.Popen','os.system','os.startfile','os.posix_spawn'):raise RuntimeError('No child process')
 if event in ('socket.connect','socket.bind') and (not isinstance(args[1],tuple) or args[1][0] not in ('127.0.0.1','::1')):raise RuntimeError('Loopback only')
 if event=='socket.getaddrinfo' and args[0] not in ('127.0.0.1','::1','localhost',None):raise RuntimeError('No external DNS')
 if event=='sqlite3.connect' and not Path(args[0]).resolve().is_relative_to(out):raise RuntimeError('Own DB only')
 if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):
  path=Path(os.fsdecode(args[0])).absolute();mode,flags=args[1] or '',args[2] or 0
  if (any(c in str(mode) for c in 'wax+') or isinstance(flags,int) and flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC)) and not path.is_relative_to(out) and path!=W/'UI-SERVER.json':raise RuntimeError('Own writes only')
sys.addaudithook(audit)
def load(name,path):
 m=importlib.util.module_from_spec(importlib.util.spec_from_loader(name,loader=None));m.__file__=str(path);sys.modules[name]=m;exec(compile(path.read_bytes(),str(path),'exec'),m.__dict__);return m
fixture=load('guided_ui_original_identity',P/'work/acquisition-core-repair-20261018/gui-fixture/base_fixture.py');cloud=fixture.CloudStandin(json.loads((P/'work/central-store-config/compiled-fixture.json').read_text('utf-8-sig')));company=json.loads((S/'work/app/company.json').read_text('utf-8-sig'))
def transport(*a,**k):
 result=cloud(*a,**k);result['environment_id']=company['managedWorkspace']['environment_id'];return result
integration=load('integrations',R/'resources/platform-runtime/vendor-src/integrations.py');integration.request_json=transport
host=load('guided_ui_actual_host',R/'ui_native_host.py');_,files=host.verify_release(R,stage['manifest_sha256']);host.verify_backend_dependencies(R,files,S)
def model(envelope):events.append({'operation':'generation','requestId':envelope['requestId']});return {'state':'unknown','requestId':envelope['requestId']}
def status(envelope):events.append({'operation':'status','requestId':envelope['requestId']});return {'state':'unknown','requestId':envelope['requestId']}
model.status=status
backend=host.create_backend(R,files,project_root=S,data_dir=out/'data',company=company,content_model_adapter=model)
server=host.StaticServer(R,files,backend=backend,cookie_name='guided_ui_session');thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
origin='http://127.0.0.1:'+str(server.server_port);headers={}
def setup_request(method,payload=None):
 c=http.client.HTTPConnection('127.0.0.1',server.server_port,timeout=30);c.request(method,'/api/workbench/bootstrap' if method=='GET' else '/api/workbench',json.dumps(payload).encode() if payload else None,headers);r=c.getresponse();raw=r.read();status=r.status;h=dict(r.getheaders());c.close();assert status==200,(status,raw[:300]);return json.loads(raw),h
boot,_=setup_request('GET');headers.update({'Origin':origin,'Content-Type':'application/json','X-Fangyu-CSRF':boot['csrfToken']});logged,h=setup_request('POST',{'action':'login','data':{'username':'fixture-admin','password':fixture.PASSWORD}});headers.update(Cookie=h['Set-Cookie'].split(';',1)[0]);headers['X-Fangyu-CSRF']=logged['csrfToken']
if logged['selection']['storeId']!=cloud.first_store:setup_request('POST',{'action':'select_store','data':{'storeId':cloud.first_store,'expectedRevision':logged['selection']['revision']}})
user=backend.core.session(headers['Cookie'].split('=',1)[1]);backend.core.store.put('accounts',{'id':'schedule-ui-account','tenant_id':user['tenant_id'],'cloud_owner':user['username'],'store_id':cloud.first_store,'platform':'xiaohongshu','status':'disconnected','name':'合成运营账号','platformNickname':'合成内容昵称','platform_uid':'schedule-ui-uid'})
from PIL import Image
from io import BytesIO
import base64
base={'storeId':cloud.first_store,'accountId':'schedule-ui-account','platform':'xiaohongshu'}
trace=[]
def content(action_name,**data):
 current,_=setup_request('POST',{'action':'content_workspace_read','data':base})
 payload={'action':action_name,'data':{**base,'requestId':uuid.uuid4().hex,'expectedRevision':current['workspace']['revision'],**data}}
 result,_=setup_request('POST',payload);trace.append({'request':payload,'body':result});return result
buf=BytesIO();Image.new('RGB',(4,4),'blue').save(buf,format='PNG')
asset=content('content_asset_import',name='授权合成图.png',mime='image/png',source='authorized_real',rightsConfirmed=True,dataBase64=base64.b64encode(buf.getvalue()).decode())['result']['asset']
draft=content('content_draft_save',draft={'title':'本人核对后的合成日历稿','body':'内容与房源均为验收样例，需要本人核实。','format':'image','assetIds':[asset['id']]})['workspace']['drafts'][-1]
content('content_draft_audit',draftId=draft['id'],decision='approve',note='合成明确核对')
backend.core.store.put('accounts',{'id':'schedule-ui-account-2','tenant_id':user['tenant_id'],'cloud_owner':user['username'],'store_id':cloud.first_store,'platform':'xiaohongshu','status':'disconnected','name':'合成第二账号','platform_uid':'schedule-ui-uid-2'})
(out/'UI-SEED-HTTP.json').write_text(json.dumps(trace,ensure_ascii=False,indent=2),'utf-8')
info={'origin':'http://127.0.0.1:'+str(server.server_port),'username':'fixture-admin','password':fixture.PASSWORD,'directory':str(out),'stop':str(stop),'stage':stage,'syntheticOnly':True};(W/'UI-SERVER.json').write_text(json.dumps(info,ensure_ascii=False,indent=2),'utf-8');print(info['origin'],flush=True)
try:
 deadline=time.monotonic()+900
 while not stop.exists() and time.monotonic()<deadline:time.sleep(.2)
finally:
 server.shutdown();thread.join(3);server.server_close();backend.close();(out/'FINAL.json').write_text(json.dumps({'status':'STOPPED_OWN_HTTP_FIXTURE','modelEvents':events,'realModelPlatformCalls':0,'nativeWindow':False,'productionAccess':False},ensure_ascii=False,indent=2),'utf-8')
