import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath,pathToFileURL} from 'node:url';
import {parseHTML} from '../../content-workflow-ui/node_modules/linkedom/esm/index.js';
const W=fileURLToPath(new URL('../',import.meta.url)),base=JSON.parse(fs.readFileSync(W+'BASE-HASHES.json','utf8').replace(/^\uFEFF/,''));
// Keep the actual candidate customer page render/bind unchanged. Resolve its
// unedited imports read-only from the frozen source; write only this W module.
let code=fs.readFileSync(W+'candidate/pages/customers.mjs','utf8');
code=code.replace(/from (['"])(\.\.?\/[^'"]+)\1/g,(_,quote,relative)=>{
 const own=path.resolve(W+'candidate/pages',relative),original=path.resolve(base.source+'/pages',relative);
 return `from ${quote}${pathToFileURL(fs.existsSync(own)?own:original).href}${quote}`;
});
fs.writeFileSync(W+'tests/customer-entry-runtime.mjs',code);
const {render,bind}=await import('./customer-entry-runtime.mjs');
const {customerControls}=await import('../candidate/pages/customers-data.mjs');
const {document,window}=parseHTML('<html><body><main></main></body></html>');globalThis.document=document;
const storage=new Map();globalThis.localStorage={getItem:k=>storage.get(k)||null,setItem:(k,v)=>storage.set(k,v),removeItem:k=>storage.delete(k)};
const element=document.querySelector('main'),calls=[],H='a'.repeat(64);
const item={id:'a'.repeat(64),name:'合成客户',platform:'xiaohongshu',quote:'同一客户的一条原评论',postTitle:'原帖标题',level:'高意向',tone:'high',intentSource:'ai',intentLevel:'high',representativeLeadId:'comment-a',comments:[{id:'comment-a',text:'同一客户的一条原评论',postTitle:'原帖标题'}]};
const state={authEpoch:1,user:'synthetic',storeId:'store-a',page:'customers',connection:'connected',activePlatform:'xiaohongshu',session:{user:{role:'operator'}},customerView:{actor:{username:'synthetic',storeId:'store-a'},status:'ready',items:[item],total:1,page:1,pages:1},customerDetail:{actor:{username:'synthetic',storeId:'store-a'},id:item.id,status:'ready',item}};customerControls(state).selectedId=item.id;
let cleanup;const ctx={state,update:fn=>{fn(state);paint();},actions:{intentCorrectionAction:async(action,data)=>{calls.push({action,data});return {intentCorrection:{actor:{username:'synthetic',storeId:'store-a'},scope:'single-comment',customerId:item.id,leadId:'comment-a',platform:'xiaohongshu',version:H,sourceDigest:H,aiIntent:{status:'graded',level:'high',reason:'合成原AI理由'},manualIntent:null,currentIntent:{status:'graded',level:'high'},history:[]}};}},toast(){}};
function paint(){cleanup?.();element.innerHTML=render(state);cleanup=bind(element,ctx);}
paint();assert.ok(element.querySelector('aside[aria-label="客户详情"] [data-correction-open]'));assert.ok(element.querySelector('[data-customer-reply]'));assert.ok(element.querySelector('[data-customer-check-all]'));element.querySelector('[data-correction-open]').click();await new Promise(r=>setTimeout(r,0));assert.equal(calls.length,1);assert.equal(calls[0].data.leadId,'comment-a');assert.match(element.textContent,/合成原AI理由/);assert.ok(element.querySelector('[data-correction-level]'));assert.ok(element.querySelector('[data-customer-source]'));state.customerDetail.status='loading';paint();assert.equal(element.querySelector('[data-correction-open]'),null);state.customerDetail.status='error';paint();assert.equal(element.querySelector('[data-correction-open]'),null);cleanup?.();
// Exercise cancellation through the actual customer page's bind, including its
// modal handoff. Transport alone is synthetic; the candidate page is unchanged.
const modals=[];ctx.modal=config=>modals.push(config);
ctx.actions.intentCorrectionAction=async(action,data)=>{
 calls.push({action,data});
 if(action==='customer_intent_correct')throw Error('synthetic response loss');
 const value={actor:{username:'synthetic',storeId:'store-a'},scope:'single-comment',customerId:item.id,leadId:'comment-a',platform:'xiaohongshu',version:H,sourceDigest:H,aiIntent:{status:'graded',level:'high',reason:'合成原AI理由'},manualIntent:null,currentIntent:{status:'graded',level:'high'},history:[]};
 if(action==='customer_intent_read'&&data.requestId)value.receipt={requestId:data.requestId,state:'not_found'};
 if(action==='customer_intent_cancel')value.receipt={...data,state:'cancelled',cancelledAt:'2026-10-23T01:00:00Z'};
 return {intentCorrection:value};
};
state.customerDetail.status='ready';state.customerIntentCorrection=null;paint();element.querySelector('[data-correction-open]').click();await new Promise(r=>setTimeout(r,0));
const selected=element.querySelector('[data-correction-level]');for(const o of selected.querySelectorAll('option'))o.removeAttribute('selected');[...selected.querySelectorAll('option')].find(o=>o.value==='unrelated').setAttribute('selected','');selected.dispatchEvent(new window.Event('change',{bubbles:true}));
const reason=element.querySelector('[data-correction-reason]');reason.value='人工核对为转租';reason.dispatchEvent(new window.Event('input',{bubbles:true}));element.querySelector('[data-correction-save]').click();
for(let n=0;n<12;n++)await new Promise(r=>setTimeout(r,0));assert.ok(state.customerIntentCorrection.pending);assert.equal(element.querySelector('[data-correction-cancel]'),null);
element.querySelector('[data-correction-check]').click();await new Promise(r=>setTimeout(r,0));element.querySelector('[data-correction-cancel]').click();assert.equal(modals.length,1);assert.equal(calls.at(-1).action,'customer_intent_read');
await modals[0].onConfirm();await new Promise(r=>setTimeout(r,0));assert.equal(calls.at(-1).action,'customer_intent_cancel');assert.equal(state.customerIntentCorrection.pending,null);assert.match(element.textContent,/已取消/);assert.ok(element.querySelector('[data-customer-reply]'));cleanup?.();
const result={passed:4,results:['Actual customer page render includes inline correction beside original detail and keeps reply/selection actions','Actual customer page bind opens exact original-comment read and displays original AI reason','Loading/error detail suppress correction controls','Actual customer page unknown-save recovery requires original-key not_found and modal confirmation before cancellation; exact cancelled receipt unlocks save'],scope:'Node DOM entry integration; read-only imports from source, all emitted test files in W. No browser screenshots/Native/real records.'};fs.writeFileSync(W+'ENTRY-RESULTS.json',JSON.stringify(result,null,2));console.log(JSON.stringify(result,null,2));
