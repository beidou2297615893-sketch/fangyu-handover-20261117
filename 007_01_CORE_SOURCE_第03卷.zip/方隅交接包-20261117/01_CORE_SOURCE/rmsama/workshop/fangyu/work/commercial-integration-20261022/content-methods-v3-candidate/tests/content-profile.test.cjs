'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const crypto=require('node:crypto');
const {fixture,IDS,memoryDb,loadActualModules,SECRET}=require('./cloud-fixture.cjs');
const nativeTenant='cloud-'+crypto.createHash('sha256').update(IDS.env+'\n'+IDS.company).digest('hex').slice(0,24);

test('authenticated read-only profile explicitly enables content only for the trusted Native tenant mapping',async()=>{
 const f=await fixture({contentOptions:{enabled:true,tenantId:nativeTenant,revision:4}});
 const before=f.memory.stats().committedWrites,profile=await f.profile();
 assert.equal(profile.content_generation_capability.contract,'fangyu-content-capability-v1');
 assert.equal(profile.content_generation_capability.enabled,true);
 assert.equal(profile.content_generation_capability.available,true);
 assert.equal(profile.content_generation_capability.reason,'ready');
 assert.equal(profile.content_generation_capability.tenant_id,nativeTenant);
 assert.equal(profile.content_generation_capability.tenant_mapping_verified,true);
 assert.equal(profile.content_generation_capability.policy_revision,4);
 assert.equal(profile.content_generation_capability.config_revision,profile.config.revision);
 assert.equal(profile.content_generation_capability.rules_version,profile.config.rules_version);
 assert.equal(profile.content_generation_capability.selected_account_verified,false);
 assert.deepEqual(profile.content_generation_capability.supported_platforms,['xiaohongshu']);
 assert.equal(f.memory.stats().committedWrites,before);assert.equal(f.calls(),0);
});

test('missing, disabled and invalid server content policy stay diagnosable without enabling generation',async t=>{
 const {contentOptionsFromEnvironment}=require('../cloud/content_contract.cjs');
 const cases=[
  [{},'server_policy_missing',false],
  [{CONTENT_GENERATION_POLICY:'{invalid'},'server_policy_invalid',false],
  [{CONTENT_GENERATION_POLICY:JSON.stringify({enabled:true,revision:1})},'tenant_mapping_missing',true],
  [{CONTENT_GENERATION_POLICY:JSON.stringify({enabled:false,tenantId:nativeTenant,revision:1})},'server_disabled',false],
  [{CONTENT_GENERATION_POLICY:JSON.stringify({enabled:true,tenantId:'different-native-tenant',revision:1})},'tenant_mapping_mismatch',true],
 ];
 for(const [environment,reason,enabled] of cases)await t.test(reason,async()=>{
  const options=contentOptionsFromEnvironment(environment);
  const f=await fixture({contentOptions:options.contentGeneration});const profile=await f.profile();
  assert.equal(profile.content_generation_capability.available,false);
  assert.equal(profile.content_generation_capability.enabled,enabled);
  assert.equal(profile.content_generation_capability.reason,reason);assert.equal(f.calls(),0);
 });
});

test('profile refuses a client-selected tenant and never returns claims, UID or provider credentials',async()=>{
 const f=await fixture({contentOptions:{enabled:true,tenantId:nativeTenant,revision:1}});
 const forged=await f.call('ai_profile',{tenant_id:'attacker-selected-tenant'});
 assert.equal(forged.status,400);assert.equal(f.calls(),0);
 const profile=await f.profile();
 const serialized=JSON.stringify(profile);
 assert.equal(serialized.includes(SECRET),false);
 const capability=profile.content_generation_capability;
 assert.equal(Object.keys(capability).some(key=>/claim|uid|secret|key|account_id|device_id/.test(key)),false);
});

test('profile reports unavailable member-store, feature and AI configuration without model calls',async t=>{
 for(const kind of ['member_without_store','feature_disabled','ai_disabled','provider_not_configured'])await t.test(kind,async()=>{
  const policy={package:'team',features:['team','strategy','intent_analysis']};
  const f=await fixture({policy,contentOptions:{enabled:true,tenantId:nativeTenant,revision:1}});
  let token=f.staff,expected=kind;
  if(kind==='member_without_store'){
   await f.changeTrustedState(state=>{state.users.find(user=>user.username===IDS.actor).store_id='';});expected='store_scope_required';
  }
  if(kind==='feature_disabled'){policy.features=['team','intent_analysis'];expected='feature_unavailable';}
  if(kind==='ai_disabled')assert.equal((await f.call('ai_config_save',{config:{enabled:false}},f.admin)).status,200);
  if(kind==='provider_not_configured')await f.changeTrustedState(state=>{state.enterpriseAi.api_key='';});
  const profile=await f.profile(token);assert.equal(profile.content_generation_capability.available,false);
  assert.equal(profile.content_generation_capability.reason,expected);assert.equal(f.calls(),0);
 });
});

test('default profile is strictly read-only for cold storage, housekeeping and expired authentication',async t=>{
 await t.test('cold storage',async()=>{
  const memory=memoryDb(),{createService,createStore}=loadActualModules();
  const service=createService({store:createStore(memory.db,IDS.company),companyId:IDS.company,environmentId:IDS.env});
  const response=await service({operation:'ai_profile',environment_id:IDS.env},'');
  assert.equal(response.status,503);assert.equal(response.data.read_only,true);assert.equal(memory.stats().committedWrites,0);
 });
 await t.test('housekeeping and expired auth',async()=>{
  const f=await fixture({contentOptions:{enabled:true,tenantId:nativeTenant,revision:1}});
  await f.changeTrustedState(state=>{
   state.sessions.push({username:'expired-fixture-user',digest:'f'.repeat(64),expires:1});
   state.rememberedDevices.push({username:'expired-fixture-user',idleExpires:1,absoluteExpires:1});
   state.attempts['expired-fixture-user']={count:1,until:1};
  });
  let before=f.memory.stats().committedWrites;
  const profile=await f.profile();assert.equal(profile.read_only,true);assert.equal(profile.mutation_committed,false);
  assert.equal(f.memory.stats().committedWrites,before);assert.equal(f.calls(),0);
  f.advance(9*3600000);before=f.memory.stats().committedWrites;
  const denied=await f.call('ai_profile',{},f.staff);assert.equal(denied.status,401);
  assert.equal(denied.data.read_only,true);assert.equal(f.memory.stats().committedWrites,before);
 });
});
