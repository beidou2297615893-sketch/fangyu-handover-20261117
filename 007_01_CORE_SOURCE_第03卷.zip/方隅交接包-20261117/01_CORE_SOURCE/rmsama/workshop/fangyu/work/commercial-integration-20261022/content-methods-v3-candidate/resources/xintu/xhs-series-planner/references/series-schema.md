# Series Planning Schema

For each episode include:

- sequence number
- audience question
- episode job
- working title
- opening hook
- core proof or asset
- format: talking head, screen demo, carousel, experiment, review, or hybrid
- standalone value delivered
- callback to prior episode
- next-episode bridge
- production dependency
- success signal

Reject episodes that repeat the same job with different nouns.

