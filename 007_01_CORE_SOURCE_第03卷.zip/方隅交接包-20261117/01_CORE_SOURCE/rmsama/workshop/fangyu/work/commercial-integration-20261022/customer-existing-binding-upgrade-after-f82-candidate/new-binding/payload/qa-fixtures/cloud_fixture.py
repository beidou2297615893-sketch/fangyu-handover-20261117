from copy import deepcopy
import hashlib,json,secrets,time
PASSWORD='[REDACTED:assigned_secret]'
COMPANY='fangyu-apartment-client'
def digest(value):
    raw = value if isinstance(value, bytes) else json.dumps(value, ensure_ascii=False,
        sort_keys=True, separators=(',', ':'), allow_nan=False).encode()
    return hashlib.sha256(raw).hexdigest()
class CloudStandin:
    """Same directory envelope as central client Cloud, credentials/session per actor."""
    def __init__(self, compiled):
        self.manifest = deepcopy(compiled['manifest'])
        self.configs = {r['store_id']: deepcopy(r['config']) for r in compiled['documents']
            if r.get('doc_type') == 'store_config_version'}
        if len(self.manifest['stores']) != 14 or {r['id'] for r in self.manifest['stores']} != set(self.configs):
            raise ValueError('Central fixture must contain the complete 14-store projection')
        self.calls, self.sessions = [], {}
        self.first_store = self.manifest['stores'][0]['id']

    def __call__(self, url, data, token=''):
        from integrations import IntegrationError
        op = data['operation']; self.calls.append(op)
        if op == 'login':
            name = data.get('username')
            if name not in ('fixture-admin', 'fixture-operator') or data.get('password') != PASSWORD:
                error = IntegrationError('隔离账号或密码错误'); error.http_status = 401; raise error
            token = 'fixture-' + secrets.token_urlsafe(24)
            self.sessions[token] = name
        else:
            name = self.sessions.get(token)
            if not name:
                error = IntegrationError('隔离会话已失效'); error.http_status = 401; raise error
        role = 'admin' if name == 'fixture-admin' else 'operator'
        user = {'username': name, 'role': role, 'disabled': False, 'can_reply': True,
            'can_export': True, **({'store_id': self.first_store} if role == 'operator' else {})}
        result = {'contract': 'fangyu-workspace-v1', 'company_id': COMPANY,
            'environment_id': 'overnight-fixture', 'user': user}
        if op == 'login':
            result.update(token=token, expires=time.time() + 36000)
        elif op == 'logout':
            self.sessions.pop(token, None)
        elif op == 'store_config_read':
            rows = [r for r in self.manifest['stores'] if role == 'admin' or r['id'] == self.first_store]
            result.update(schema='store-config-v1', read_only=True, mutation_committed=False,
                catalog_revision=self.manifest['active_revision'], catalog_digest=self.manifest['catalog_digest'],
                source_versions=deepcopy(self.manifest['source_versions']),
                actor={'username': name, 'role': role},
                scope={'type': 'company' if role == 'admin' else 'store', 'store_ids': [r['id'] for r in rows]},
                stores=deepcopy(rows))
            if data.get('store_id'):
                store = data['store_id']
                if store not in {r['id'] for r in rows}:
                    error = IntegrationError('隔离门店无授权'); error.http_status = 403; raise error
                config = deepcopy(self.configs[store])
                result.update(store_id=store, config=config, config_digest=digest(config))
        elif op != 'me':
            raise RuntimeError('Unsupported external standin operation: ' + op)
        return result
