"""Targeted independent review of final correction bytes; synthetic records only.

Reuse the saved fixture, not a new product or a second customer database design.
The extra cases cover receipts in another valid scope, the last transaction
write failing, and the original cached-AI/legacy-correction caller contract.
"""
from pathlib import Path
import hashlib,json,os,sys,unittest
from copy import deepcopy
from test_intent_correction import CorrectionTests,W,S,VENDOR

blocked=[]
def final_review_fence(event,args):
    if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):
        path=Path(os.fsdecode(args[0])).resolve()
        mode,flags=args[1] or '',args[2] or 0
        writes=any(c in str(mode) for c in 'wax+') or isinstance(flags,int) and bool(flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC))
        roots=(W.resolve(),S.resolve(),Path(sys.prefix).resolve(),Path(sys.base_prefix).resolve())
        if not (path.is_relative_to(roots[0]) if writes else any(path.is_relative_to(root) for root in roots)):
            blocked.append('open:'+path.name)
            raise RuntimeError('Review must not read real data, sessions, or outside code')
sys.addaudithook(final_review_fence)

class FinalReviewTests(CorrectionTests):
    # Exclude inherited tests from this targeted suite; the saved 18-test
    # evidence remains authoritative and is not silently overwritten here.
    def test_review_receipts_bound_to_original_valid_scope(self):
        from assistant.intent_correction import IntentCorrectionError
        for state in ('saved','cancelled'):
            payload=self.payload('scope-'+state)
            original=(self.service.correct(self.user,'gubei',payload) if state=='saved' else
                      self.service.cancel(self.user,'gubei',self.cancellation(payload)))
            for other in ({**self.scope,'leadId':'lead-1'},
                          {**self.scope,'storeId':'other','leadId':'lead-2'}):
                store=other['storeId']
                with self.assertRaises(IntentCorrectionError) as caught:
                    self.service.read(self.user,store,{**other,'requestId':payload['requestId']})
                self.assertEqual(caught.exception.code,'INTENT_REQUEST_CONFLICT')
                current=self.service.read(self.user,store,other)
                wrong={**payload,**other,'expectedVersion':current['version'],'sourceDigest':current['sourceDigest']}
                with self.assertRaises(IntentCorrectionError) as caught:self.service.correct(self.user,store,wrong)
                self.assertEqual(caught.exception.code,'INTENT_REQUEST_CONFLICT')
                with self.assertRaises(IntentCorrectionError) as caught:
                    self.service.cancel(self.user,store,{**self.cancellation(payload),**other})
                self.assertEqual(caught.exception.code,'INTENT_REQUEST_CONFLICT')
                self.assertIsNone(self.service.read(self.user,store,other)['manualIntent'])
            reread=self.service.read(self.user,'gubei',{**self.scope,'requestId':payload['requestId']})
            self.assertEqual(reread['receipt'],original['receipt'])

    def test_review_audit_failure_rolls_back_save_and_cancel(self):
        from assistant.intent_correction import IntentCorrectionError
        for cancelling in (False,True):
            payload=self.payload('rollback-final-'+str(cancelling))
            before=deepcopy(self.core.store.get('leads','lead-0'))
            with self.core.store.connect() as db:
                db.execute("CREATE TRIGGER reject_last_write BEFORE INSERT ON records WHEN NEW.entity='audit' BEGIN SELECT RAISE(ABORT,'synthetic final-write rollback'); END")
            with self.assertRaises(IntentCorrectionError) as caught:
                if cancelling:self.service.cancel(self.user,'gubei',self.cancellation(payload))
                else:self.service.correct(self.user,'gubei',payload)
            self.assertIs(caught.exception.mutation_committed,False)
            self.assertEqual(self.core.store.get('leads','lead-0'),before)
            self.assertEqual(self.core.store.list('intent_corrections_v1'),[])
            self.assertEqual(self.core.store.list('audit'),[])
            with self.core.store.connect() as db:db.execute('DROP TRIGGER reject_last_write')
            self.assertEqual(self.service.read(self.user,'gubei',{**self.scope,'requestId':payload['requestId']})['receipt']['state'],'not_found')

    def _cached_analysis(self):
        from assistant.ai_workflow import LocalAIWorkflow,post_identity
        from assistant.intent_rule_management import IntentRuleManagement
        from core.intent_policy import POLICY_VERSION
        lead=self.core.store.get('leads','lead-0')
        lead.pop('ai_intent');lead.update(content_title='古北公寓出租',parent_text='',published_at='',ip_location='')
        self.core.store.put('leads',lead)
        task=self.core.store.get('tasks',lead['task_id']);task.update(city='上海',area='古北')
        self.core.store.put('tasks',task)
        profile={'revision':1,'rules_version':'synthetic-review-rules-v1','provider':'deepseek','model':'deepseek-flash'}
        calls=[]
        def cloud(_user,operation,data):
            calls.append(operation)
            self.assertEqual(operation,'ai_profile','No model or other provider operation is permitted')
            return deepcopy(profile)
        workflow=LocalAIWorkflow(self.core,cloud,company=lambda:self.company)
        snapshot=IntentRuleManagement(self.core,self.user['tenant_id'],self.user['username'],self.company).snapshot(self.user)
        context={'city':'上海','area':'古北','post':{'id':post_identity(lead),'title':lead['content_title'],'author':''}}
        comment={'id':lead['id'],'text':lead['text'],'author':lead['author'],'is_post_author':False,
                 'parent_text':'','published_at':'','ip_location':''}
        key=workflow._key(self.user,'intent',{**context,'comment':comment,
            'local_policy':{'revision':snapshot['revision'],'digest':snapshot['digest'],'validation_version':POLICY_VERSION}},profile)
        workflow._put_cache(self.user,key,{'status':'graded','level':'high','reason':'合成已缓存分析',
            'evidence':[lead['text']],'region_status':'matched','content_region':'古北','key_info':[]})
        return workflow,task,lead,calls,key

    def test_review_actual_cached_analyze_and_legacy_correct_contract(self):
        from assistant.ai_workflow import effective_intent
        workflow,task,lead,calls,key=self._cached_analysis()
        result=workflow.analyze(self.user,task,[deepcopy(lead)])
        self.assertEqual(result['analyzed'],1);self.assertEqual(result['cache_hits'],1)
        self.assertEqual(calls,['ai_profile','ai_profile'])
        analyzed=self.core.store.get('leads',lead['id'])
        self.assertEqual(analyzed['ai_intent']['cache_key'],key)
        legacy=workflow.correct(self.user,deepcopy(analyzed),{'level':'medium','reason':'原调用仍返回单条评论'})
        self.assertEqual(legacy['id'],lead['id']);self.assertEqual(effective_intent(legacy)['level'],'medium')
        self.assertEqual(legacy['ai_intent'],analyzed['ai_intent'])
        self.assertEqual(self.core.store.list('intent_corrections_v1'),[])

    def test_review_metadata_cas_keeps_pending_then_reuses_cached_result(self):
        from types import SimpleNamespace
        from unittest.mock import patch
        from core.engine import Core
        from assistant.business import BusinessExecutor
        from assistant import intent_correction
        from test_intent_correction import R
        workflow,task,lead,calls,key=self._cached_analysis()
        executor=BusinessExecutor(SimpleNamespace(core=self.core,company=self.company),
            self.company['managedWorkspace']['environment_id'],self.company['id'],self.user['username'])
        executor.ai=workflow
        second=Core(Path(self.tmp.name)/'db',R/'resources',defer_startup_recovery=True)
        real_persist=intent_correction.persist_ai_result;attempts=[]
        def concurrent_metadata(core,before,updated,task_snapshot):
            if not attempts:
                fresh=second.store.get('leads',lead['id']);fresh['review_seen_at']='synthetic-later-view'
                second.store.put('leads',fresh)
            saved=real_persist(core,before,updated,task_snapshot);attempts.append(saved)
            return saved
        with patch.object(intent_correction,'persist_ai_result',concurrent_metadata):
            first=executor.analyze_pending(self.user,{'task_id':task['id']})
            self.assertEqual((first['analyzed'],first['pending'],first['cache_hits']),(0,1,1))
            self.assertNotIn('ai_intent',second.store.get('leads',lead['id']))
            retry=executor.analyze_pending(self.user,{'task_id':task['id']})
        self.assertEqual((retry['analyzed'],retry['pending'],retry['cache_hits']),(1,0,1))
        self.assertEqual(attempts,[False,True])
        current=second.store.get('leads',lead['id'])
        self.assertEqual(current['review_seen_at'],'synthetic-later-view')
        self.assertEqual(current['ai_intent']['cache_key'],key)
        self.assertEqual(calls,['ai_profile']*4)

    def test_review_release_pinned_helper_without_native_sys_path(self):
        import importlib.util,tempfile
        from test_intent_correction import N,C
        path=C/'work/ui-native-r57/ui_native_host.py'
        spec=importlib.util.spec_from_file_location('review_pinned_host',path)
        host=importlib.util.module_from_spec(spec);spec.loader.exec_module(host)
        with tempfile.TemporaryDirectory(dir=W) as directory:
            root=Path(directory);(root/'web').mkdir();(root/'resources').mkdir()
            bodies={'ui_native_host.py':path.read_bytes(),
                    'customer_intent_workbench.py':(C/'work/ui-native-r57/customer_intent_workbench.py').read_bytes(),
                    'web/index.html':b'<html></html>','web/app.mjs':b'','web/styles.css':b''}
            files=[]
            for name,body in bodies.items():
                (root/name).write_bytes(body)
                files.append({'path':name,'size':len(body),'sha256':hashlib.sha256(body).hexdigest()})
            raw=json.dumps({'schema':host.SCHEMA,'company_id':host.COMPANY_ID,'files':files}).encode()
            (root/'RELEASE.json').write_bytes(raw)
            _,checked=host.verify_release(root,hashlib.sha256(raw).hexdigest())
            original_path=list(sys.path)
            try:
                native_paths={(C/'work/ui-native-r57').resolve(),N.resolve(),root.resolve()}
                sys.path[:]=[value for value in sys.path if Path(value or '.').resolve() not in native_paths]
                self.assertFalse(any(Path(value or '.').resolve() in native_paths for value in sys.path))
                factory=host.load_customer_intent_factory(root,checked)
                self.assertTrue(factory.__module__.startswith('fangyu_customer_intent_workbench_'))
                # The host injects a class object, no global same-name import or
                # customer_intent_workbench sys.path is used by the action.
                service=factory(self.core,self.customers,self.company)
                saved=service.correct(self.user,'gubei',self.payload('release-helper'))
                self.assertEqual(saved['receipt']['state'],'saved')
                (root/'customer_intent_workbench.py').write_bytes(b'raise AssertionError("must not execute corrupted helper")')
                with self.assertRaises(host.UIHostError):host.load_customer_intent_factory(root,checked)
            finally:sys.path[:]=original_path

if __name__=='__main__':
    names=[name for name in FinalReviewTests.__dict__ if name.startswith('test_review_')]
    suite=unittest.TestSuite(FinalReviewTests(name) for name in names)
    result=unittest.TextTestRunner(verbosity=2).run(suite)
    files={p.relative_to(W/'candidate').as_posix():hashlib.sha256(p.read_bytes()).hexdigest()
           for p in sorted((W/'candidate').rglob('*.py'))}
    output={'status':'PASS' if result.wasSuccessful() else 'FAIL','testsRun':result.testsRun,'tests':names,
            'failures':[str(test) for test,_ in result.failures],'errors':[str(test) for test,_ in result.errors],
            'business':'current vendor' if VENDOR else 'preserved r55','candidateFiles':files,
            'blockedAttempts':blocked,'modelCalls':0,'platformCalls':0,'productionDatabaseReadsOrWrites':0}
    (W/('FINAL-REVIEW-VENDOR-RESULT.json' if VENDOR else 'FINAL-REVIEW-RESULT.json')).write_text(json.dumps(output,ensure_ascii=False,indent=2),'utf-8')
    raise SystemExit(0 if result.wasSuccessful() else 1)
