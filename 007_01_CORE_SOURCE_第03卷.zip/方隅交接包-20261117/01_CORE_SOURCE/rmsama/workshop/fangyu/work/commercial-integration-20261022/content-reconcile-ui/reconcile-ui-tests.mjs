import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath,pathToFileURL} from 'node:url';
import {parseHTML} from '../content-workflow-ui/node_modules/linkedom/esm/index.js';
const W=path.dirname(fileURLToPath(import.meta.url));
const U='C:/积木软件工坊/项目/方隅公寓客户版/work/parallel-integration-20261018/final-integration/stage-02/project/work/ui-approved-implementation/ui-preview';
const {renderWorkflow,bindWorkflow}=await import(pathToFileURL(U+'/pages/content-workflow.mjs'));
const {createBackend}=await import(pathToFileURL(U+'/backend.mjs'));
const {document}=parseHTML('<html><body><main></main></body></html>');globalThis.document=document;
const storage=new Map();globalThis.localStorage={getItem:k=>storage.get(k)||null,setItem:(k,v)=>storage.set(k,v),removeItem:k=>storage.delete(k)};
const root=document.querySelector('main'),results=[];
const original='original-run-key-20261023';
const task=(state='unknown')=>({id:'original-task',methodId:'writing',query:'虚构门店内容',state,runRequestId:original,input:{evidence:[]},evidenceIds:[],artifactIds:[],createdAt:'2026-10-23T04:00:00Z',requiresReconciliation:['running','unknown'].includes(state)});
const workspace=(state='unknown')=>({actor:{username:'synthetic',storeId:'gubei',platform:'xiaohongshu',accountId:'account-a',accountNickname:'测试账号甲'},revision:7,workflowContract:'fangyu-content-workflow-v1',workflow:{schemaVersion:1,tasks:[task(state)],artifacts:[],documents:[]},workflowCapabilities:{canRunTasks:true,canReconcileTasks:true},drafts:[],topics:[]});
let oldCleanup=()=>{};
function setup({state='unknown',capability=true,mode='unknown'}={}){oldCleanup();storage.clear();let w=workspace(state);w.workflowCapabilities.canReconcileTasks=capability;let calls=[],active=0,release,behavior=mode;
 const s={authEpoch:1,session:{user:{username:'synthetic',role:'admin'}},user:'synthetic',storeId:'gubei',activePlatform:'xiaohongshu',contentWorkspace:w};const u={accountId:'account-a',tab:'creation',forms:{draft:{},topic:{}},dirty:{}};s.contentOperationsUI=u;
 const answer=()=>{const terminal=['success','replayed','mismatch'].includes(behavior),next=structuredClone(w),t=next.workflow.tasks[0];next.revision++;t.state=terminal?'succeeded':'unknown';t.requiresReconciliation=!terminal;if(terminal){t.artifactId='candidate-a';next.workflow.artifacts=[{id:'candidate-a',taskId:t.id,methodId:'writing',state:'candidate',output:{summary:'虚构候选',artifact:{title:'虚构标题',body:'虚构正文'},facts:[],hypotheses:[]}}];}const r={workspace:next,result:{task:structuredClone(t),reconciled:true,modelCalled:false,statusChecked:true,newGenerationDispatched:false},receipt:{found:true,action:'content_task_run',requestId:original,state:t.state}};if(behavior==='replayed'){r.replayed=true;r.result={task:structuredClone(t),modelCalled:true};}if(behavior==='mismatch')r.receipt.requestId='wrong-key';w=next;return r;};
 const ctx={state:s,update:f=>{f();paint();},toast(){},modal:c=>c.onConfirm(),contentAction:async(action,data)=>{calls.push({action,data:structuredClone(data)});active++;try{
  if(action==='content_workspace_read'){const t=w.workflow.tasks[0];return {workspace:structuredClone(w),receipt:{found:true,action:'content_task_run',requestId:data.requestId,state:t.state}};}
  assert.equal(action,'content_task_reconcile');assert.deepEqual(data,{storeId:'gubei',accountId:'account-a',platform:'xiaohongshu',taskId:'original-task',expectedRevision:s.contentWorkspace.revision,requestId:original});
  if(behavior==='timeout')throw Error('查询暂时超时，保留原结果待核对');
  if(behavior==='unavailable')throw Object.assign(Error('服务尚未提供查询'),{code:'CONTENT_RECONCILE_UNAVAILABLE',mutationCommitted:false});
  if(behavior==='delay')return await new Promise(r=>release=()=>r(answer()));
  return answer();
 }finally{active--;}}};
 function paint(){oldCleanup();root.innerHTML=renderWorkflow(s,u,s.contentWorkspace);oldCleanup=bindWorkflow(root,ctx,u);}
 renderWorkflow(s,u,w);Object.assign(u.workflowUI,{open:true,mode:'tasks',taskId:'original-task',methodsLoaded:true,recovered:true});paint();
 return {s,u,calls,ctx,paint,get active(){return active},release:()=>release?.(),set behavior(value){behavior=value}};
}
async function settle(){for(let i=0;i<8;i++)await new Promise(r=>setTimeout(r,0));}
function click(selector){const e=root.querySelector(selector);assert.ok(e,selector);e.click();return e;}
const reconcile='[data-wf-action="reconcile-run"]';
{
 const h=setup();assert.match(root.textContent,/查询上次结果，不重新生成/);const button=click(reconcile);button.click();await settle();assert.equal(h.calls.length,1);assert.equal(h.calls[0].data.requestId,original);assert.equal(h.u.workflowUI.saved[0].requestId,original);assert.equal(h.s.contentWorkspace.workflow.tasks[0].state,'unknown');assert.match(root.textContent,/没有重新生成/);assert.equal(h.u.workflowUI.localUnknown,null);results.push('Explicit click uses original run key and revision; double click dispatches one status action; unknown preserves original receipt');
}
{
 const h=setup({mode:'success'});click(reconcile);await settle();assert.equal(h.u.workflowUI.saved.length,0);assert.equal(h.u.workflowUI.runUnknown,null);assert.equal(h.s.contentWorkspace.workflow.tasks[0].state,'succeeded');assert.ok(root.querySelector('[data-wf-action="apply"]'));assert.equal(root.querySelector(reconcile),null);assert.match(root.textContent,/已找回原生成结果/);assert.equal(h.calls.length,1);results.push('Recovered candidate becomes manually adoptable and clears only matching original run receipt');
}
{
 const h=setup({mode:'replayed'});click(reconcile);await settle();assert.equal(h.u.workflowUI.saved.length,0);assert.match(root.textContent,/已读取原回执/);assert.equal(h.calls.length,1);results.push('Terminal replay accepts original content_task_run receipt without claiming a new status or model dispatch');
}
{
 const h=setup({capability:false});assert.equal(root.querySelector(reconcile),null);assert.match(root.textContent,/结果查询尚未开放/);assert.equal(h.calls.length,0);const forged=document.createElement('button');forged.dataset.wfAction='reconcile-run';forged.dataset.task='original-task';forged.dataset.request=original;root.append(forged);const cleanup=bindWorkflow(root,h.ctx,h.u);forged.click();await settle();cleanup();assert.equal(h.calls.length,0);results.push('Absent capability has explicit unavailable text and no fake query button; forged UI action also refused');
}
{
 for(const mode of ['timeout','unavailable','mismatch']){const h=setup({mode});click(reconcile);await settle();assert.equal(h.u.workflowUI.saved[0].requestId,original);assert.equal(h.u.workflowUI.runUnknown.requestId,original);assert.equal(h.u.workflowUI.localUnknown,null);assert.equal(h.s.contentWorkspace.workflow.tasks[0].state,'unknown');assert.equal(h.calls.length,1);assert.ok(root.querySelector('[role="alert"]'));}results.push('Timeout, explicit unavailable and wrong receipt never clear original run or create local-save retry');
}
{
 const h=setup({mode:'delay'});click(reconcile);assert.equal(h.active,1);h.s.authEpoch++;h.s.storeId='other';h.u.accountId='account-b';h.s.contentWorkspace={...workspace(),actor:{username:'synthetic',storeId:'other',platform:'xiaohongshu',accountId:'account-b'},revision:99};h.paint();h.behavior='success';h.release();await settle();assert.equal(h.s.contentWorkspace.revision,99);assert.equal(h.s.contentWorkspace.actor.accountId,'account-b');assert.equal(h.calls.length,1);assert.ok([...storage.values()].some(v=>v.includes(original)));results.push('Late status response after employee epoch/store/account change cannot overwrite current workspace or clear old persisted receipt');
}
{
 const h=setup();const key='fangyu-content-workflow-pending-v1';localStorage.setItem(key,JSON.stringify([{scope:JSON.stringify(['synthetic','gubei','xiaohongshu','account-a']),requestId:original,taskId:'original-task'}]));h.u.workflowUI=undefined;renderWorkflow(h.s,h.u,h.s.contentWorkspace);Object.assign(h.u.workflowUI,{open:true,mode:'tasks',taskId:'original-task',methodsLoaded:true});h.paint();await settle();assert.equal(h.calls.length,1);assert.equal(h.calls[0].action,'content_workspace_read');assert.equal(h.u.workflowUI.saved[0].requestId,original);assert.match(root.textContent,/核对原结果/);results.push('Refresh restores original run summary; automatic recovery reads local workspace only, never cloud status or generation');
}
{
 const h=setup();const before=localStorage.setItem;localStorage.setItem=()=>{throw Error('disk-full')};click(reconcile);await settle();localStorage.setItem=before;assert.equal(h.calls.length,0);assert.match(root.textContent,/无法保存原执行核对断点/);results.push('Persistent receipt failure stops status call and shows accurate message');
}
{
 const h=setup({state:'running'});click(reconcile);await settle();assert.equal(h.calls.length,1);assert.equal(h.s.contentWorkspace.workflow.tasks[0].state,'unknown');assert.equal(h.u.workflowUI.saved[0].requestId,original);results.push('Running original task follows same status-only path and remains blocked until a real final result');
}
{
 let calls=0;const backend=createBackend(async(url,options)=>{calls++;assert.equal(JSON.parse(options.body).action,'content_task_reconcile');throw Error('synthetic-network-loss')});await assert.rejects(()=>backend.contentAction('content_task_reconcile',{requestId:original,taskId:'original-task'}),e=>e.code==='CONTENT_RESULT_UNCONFIRMED');assert.equal(calls,1);assert.equal(backend.unconfirmed,false);
 const unavailable=createBackend(async()=>({ok:false,status:503,json:async()=>({ok:false,error:{code:'CONTENT_RECONCILE_UNAVAILABLE',mutation_committed:false,message:'未提供查询'}})}));await assert.rejects(()=>unavailable.contentAction('content_task_reconcile',{requestId:original}),e=>e.code==='CONTENT_RECONCILE_UNAVAILABLE'&&e.mutationCommitted===false);results.push('Backend whitelist treats reconcile as content mutation, preserving own unknown result and explicit uncommitted 503 metadata');
}
oldCleanup();fs.writeFileSync(W+'/RESULTS.json',JSON.stringify({passed:results.length,results,scope:'Node real production render/bind/backend modules, synthetic transport only; no real model/platform/service fees or browser visual claims.'},null,2));console.log(JSON.stringify({passed:results.length,results},null,2));
