from pathlib import Path
import hashlib,json
W=Path(__file__).resolve().parent;P=W.parents[2]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text('utf-8-sig'))
def save(name,v):(W/name).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n','utf-8')
inputs=read(W/'QA-INPUTS.json');stage=inputs['stage'];R=Path(stage['release']);manifest=read(R/'RELEASE.json')
assert sha(R/'RELEASE.json').upper()==stage['manifest_sha256'] and stage['files']==len(manifest['files'])==272
for entry in manifest['files']:
    path=R/entry['path'];assert path.stat().st_size==entry['size'] and sha(path).upper()==entry['sha256']
base=read(W/'BASE-FINAL-PINS.json');F=P/'work/parallel-integration-20261018/final-integration/candidate-unified-v77'
old=read(Path(read(F/'STAGED.json')['release'])/'RELEASE.json');before={e['path'] for e in old['files']};after={e['path'] for e in manifest['files']}
missing=sorted(before-after);added=sorted(after-before)
assert len(missing)==4 and all(x.startswith('resources/licenses/') for x in missing)
assert added==['resources/content-workbench/content_schedule.py','web/pages/content-schedule.mjs']
save('QA-STAGE-SCOPE.json',{'label':inputs['label'],'notFormalFreezeOrDistribution':True,'resources':272,
    'manifestSha256':sha(R/'RELEASE.json'),'baseFormalF77Resources':274,'addedFiles':added,
    'externalRuntimeLicenseFilesNotCopied':missing,'allListed272ActualBytesVerified':True})
cases=('held','safety','contention','reopen','recover-claim','pressure50','pressure100');runs=[];evidence=[];checks=set()
for case in cases:
    choices=[]
    for folder in W.glob('factory-'+case+'-*'):
        if not (folder/'RESULTS.json').is_file():continue
        value=read(folder/'RESULTS.json')
        if value['status']=='PASS' and value['stage']['manifest_sha256']==stage['manifest_sha256']:choices.append(folder)
    assert choices,case
    folder=max(choices,key=lambda p:(p/'RESULTS.json').stat().st_mtime_ns)
    value=read(folder/'RESULTS.json');final=read(folder/'FINAL.json');capture=read(folder/'FINAL-CAPTURE.json')
    assert final['status']=='PASS' and final['allOwnServersClosed'] and not final['blocked'] and capture['status']=='PASS'
    assert value['realPlatformModelCalls']==final['realExternalCalls']==0
    raw=sorted((folder/'http').glob('*.json'));assert len(raw)==final['httpRequests']==len(capture['events'])
    for event in map(read,raw):assert event['httpStatus'] is not None and event['body'] is not None
    checks.update(value['checks']);runs.append({'case':case,'directory':folder.name,'httpRequestsNotGroups':len(raw),
        'checks':value['checks'],'totalSyntheticClicks':value['syntheticClicks'],'resultsSha256':sha(folder/'RESULTS.json'),
        'allOwnServersClosed':True})
    evidence.extend([folder/'RESULTS.json',folder/'FINAL.json',folder/'FINAL-CAPTURE.json',*raw])
    if case.startswith('pressure'):
        load=read(folder/'LOAD.json');assert load['accounts']==int(case.removeprefix('pressure'))==load['publishedSyntheticReceipts']
        assert load['repeatDispatch']==0 and load['crossAccountReadDenied'] and load['notPlatformCapacity'];evidence.append(folder/'LOAD.json')
    if case=='reopen':
        difference=read(folder/'REOPEN-DIFF.json');assert len(difference)==1 and difference[0]['entity']=='ui_workbench_preferences_v1' and difference[0]['id']=='remembered-username'
        left,right=read_body=difference[0]['before'],difference[0]['after'];left,right=json.loads(left),json.loads(right)
        assert {k:v for k,v in left.items() if k!='updated_at'}=={k:v for k,v in right.items() if k!='updated_at'}
        evidence.extend([folder/'REOPEN-BEFORE.json',folder/'REOPEN-DIFF.json'])
info=read(W/'UI-SERVER.json');ui=Path(info['directory']);assert info['stage']['manifest_sha256']==stage['manifest_sha256']
uiresult=read(ui/'UI-RESULTS.json');assert uiresult['status']=='PASS' and not uiresult['errors'] and len(uiresult['results'])==13
assert sorted(x['width'] for x in uiresult['layout'])==[390,1255]
assert all(x['effectiveMinFont']>=14.4 and x['outer']['scroll']<=x['outer']['width']+1 and x['inner']['documentScroll']<=x['inner']['innerWidth']+1 for x in uiresult['layout'])
uifinal=read(ui/'FINAL.json');assert uifinal['status']=='STOPPED_OWN_HTTP_FIXTURE' and not uifinal['modelEvents'] and uifinal['realModelPlatformCalls']==0
evidence.extend([ui/'UI-RESULTS.json',ui/'FINAL.json',ui/'UI-SEED-HTTP.json',ui/'calendar-1255.png',ui/'calendar-390.png'])
cleanup=read(W/'PROCESS-CLEANUP.json');assert cleanup['ownPythonNodeProcesses']==[]
source=read(W/'SOURCE-FILES.json');assert len(source['files'])==8
for item in source['files']:assert sha(W/'overlay'/item['path'])==item['afterSha256']==sha(W/'source-candidate'/item['path'])
summary={'status':'PASS_SOURCE_ONLY_CONTENT_SCHEDULE_EXECUTION_CANDIDATE','base':'F77','sourceFiles':8,
    'rootBasePinsSha256':sha(W/'BASE-FINAL-PINS.json'),'qaStage':stage['release_id'],'qaManifestSha256':sha(R/'RELEASE.json'),
    'factoryScenarioRuns':len(runs),'uniqueBusinessAssertionsNotHttpRequests':len(checks),'capturedHttpRequestsNotGroups':sum(r['httpRequestsNotGroups'] for r in runs),
    'scenarios':runs,'ui':{'directory':ui.name,'developmentHeadlessOriginalFullIndexFitNativeHttp':True,'checks':13,'widths':[1255,390],
        'effectiveMinimumFont':min(x['effectiveMinFont'] for x in uiresult['layout'])},
    'fixedDraftVersionAccountUidTimeTimezone':True,'explicitFutureApprovalAndRamOnlyLiveSessionGrant':True,
    'dueAtomicClaimOriginalPublishCommand':True,'originalStoreActorStoreAccountAndModeLeases':True,
    'unknownOnlyOriginalIntentKeyNoRedispatch':True,'explicitPreparedClaimRecoveryPreservesOriginalKey':True,
    'latePriorWorkerCannotClobberNewApproval':True,'changedContentOrExpiredGraceDisarms':True,
    'sameAccountUnknownBlocksOtherDueItemAndReply':True,'oldReminderNotUpgraded':True,
    'allServicesStopped':True,'realPlatformModelCalls':0,'productionAccess':False,'canonicalFreezeInstallOutputsWritten':False,
    'limits':['Original publication WIRE_POLICY remains None and default host authority/transport is unavailable. No real platform publication acceptance.',
        'Due checks run in the explicitly armed current client session, not while the software is closed. Switching store/reopening requires fresh explicit enable.',
        'Timezones are explicit fixed offsets; no automatic daylight-saving transitions.',
        '50/100 accounts use declared synthetic identities/receipts through original factory; not evidence of real platform capacity.',
        'Original not_sent exposes no finer port reason; original message is retained rather than inferring login/captcha/network.',
        '272-resource private QA stage omits four external runtime license copies and is not a distributable release.',
        'No Native window, customer live session, ordinary-PC installation or user visual approval was performed.'],
    'historicalRedPreserved':['F77 rejects new queue action with 403/no writes.','Fixture name collision/non-JSON status expectation and missing synthetic temp directory corrected only in harness.',
        'Real UI busy state, scoped font and stale detached toggle event fixes retain original RED captures.','Reopen whole-Store RED was exactly the original remembered-username timestamp; all other records byte-identical.',
        'Previous QA revision refused prepared-claim recovery; final original factory RED→GREEN keeps same intent/key.',
        'Collapsed editor UI test waits for attached hidden selector after switch; no product relaxation.']}
save('SUMMARY.json',summary)
evidence.extend([W/name for name in ('SUMMARY.json','SOURCE-FILES.json','CHANGES.patch','PROTECTED-SOURCE-CHECK.json','UPSTREAM-REUSE.json','QA-STAGE-SCOPE.json','QA-INPUTS.json','PROCESS-CLEANUP.json','BASE-FINAL-PINS.json','test_factory_schedule.py','test_schedule_ui.mjs','serve_schedule_ui.py')])
receipt={**summary,'sourcePinsSha256':sha(W/'SOURCE-FILES.json'),'minimalPatchSha256':sha(W/'CHANGES.patch'),
    'evidence':{path.relative_to(W).as_posix():sha(path) for path in evidence},'writeStopped':True}
save('FINAL-RECEIPT.json',receipt)
(W/'HANDOFF.md').write_text('内容日历执行候选已封存，尚未安装或合入运行版。\n\n固定版本、账号、时区与时刻的计划可保存、本人明确启用、到期领取，并交给原受控发布命令。未知结果只查原请求；暂停取消、错过宽限、改稿失效、会话重开及未派发断点恢复均有实际工厂证据。50/100账号为合成负载，不能当成平台容量。\n\n原发布协议仍关闭，默认工厂准确停在发布授权/原账号窗口尚未接通；未真实外发。原完整宽窄界面与13项交互已验，未操作本人窗口或普通电脑实机。8源最小差异在overlay，原发布器、Store、身份、模式租约和旧提醒未改。\n\n该QA快照少4个外部运行时许可副本，不可分发；后续需独立源码审查及正式装配，不将本候选标为完整目标完成。\n','utf-8')
save('SEALED.json',{'status':'SEALED_READ_ONLY','finalReceiptSha256':sha(W/'FINAL-RECEIPT.json'),'summarySha256':sha(W/'SUMMARY.json'),
    'sourcePinsSha256':sha(W/'SOURCE-FILES.json'),'patchSha256':sha(W/'CHANGES.patch'),'writeStopped':True,
    'scope':'8 source-only overlay + exact QA evidence. Existing failed artifacts retained, no canonical/production changes.'})
print(json.dumps({'receiptSha256':sha(W/'FINAL-RECEIPT.json'),'summarySha256':sha(W/'SUMMARY.json'),'sealSha256':sha(W/'SEALED.json'),
    'sourcePinsSha256':sha(W/'SOURCE-FILES.json'),'patchSha256':sha(W/'CHANGES.patch'),'factoryScenarios':len(runs),'httpRequests':summary['capturedHttpRequestsNotGroups'],'uiChecks':13}))
