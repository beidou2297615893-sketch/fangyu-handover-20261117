# 内容工作流扩展实施范围

本轮按已核实的用户“三合一、允许并行agent”授权和获客主体派工实现。只写本目录；现有stage、canonical、生产数据库/账号会话、云及组件原件只读。没有收费模型/平台调用或新增依赖。

使用已读取的social-ops-components定位已安装MIT实现，tdd对主窗口已明确的ContentWorkbench.execute、真实临时Store和注入模型边界做逐段红绿验证。测试边界已由本次明确任务指定，不额外请求确认。方法合同沿用本轮完整17模块及独立术语，不缩回辅助功能。

根负责content_workflow.py及业务测试；知识agent只写workflow_knowledge.py/vendor及对应测试；方法agent只写workflow_methods.py及对应测试；验证agent只写tests/support.py、tests/baseline与security测试。产品修改、模型真实接线、UI、平台执行和v66合并由获客主体统一完成。
