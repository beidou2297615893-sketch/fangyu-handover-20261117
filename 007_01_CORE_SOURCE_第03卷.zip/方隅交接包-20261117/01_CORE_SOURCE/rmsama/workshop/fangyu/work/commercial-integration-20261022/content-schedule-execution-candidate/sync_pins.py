from pathlib import Path
import hashlib,re
N=Path(__file__).resolve().parent/'source-candidate/work/ui-native-r57'
path=N/'workbench_backend.py';raw=path.read_bytes()
for name in ('content_schedule.py',):
    pattern=re.compile(rb"('"+re.escape(name.encode())+rb"': ')[0-9a-f]{64}")
    assert len(pattern.findall(raw))==1
    raw=pattern.sub(lambda m:m[1]+hashlib.sha256((N/name).read_bytes()).hexdigest().encode(),raw)
path.write_bytes(raw)
for path in N.glob('*.py'):compile(path.read_bytes(),str(path),'exec')
print('Pins synchronized; all Native source compiled without pycache')
