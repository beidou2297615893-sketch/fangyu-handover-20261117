客户读取用途独审通过，限本地工程和合成云合同层，未获真实平台或商业采集批准。

唯一作者输入为已封存11文件（6个原源有界改、1个新carrier、4份用途材料）。作者目录只读；独审未启动作者EXE、未复制作者数据库。使用成熟原held F82派生流程，在自有目录按7份精确Python源码重建自有4份材料、RELEASE/SHIPPED和原兼容guard固定值，再用原PyInstaller spec编译独立QA入口。原held的False决策未改变。材料日期与本次字节重新绑定是夹具派生，不是新审批。

实际独立EXE 5个复合factory组、3次HTTP通过：

1. 原standard load_host完整3860文件闭包→原verify_release/依赖→create_backend；有读取材料但未绑定设备仍拒绝。
2. 原Service.bind→DPAPI Vault→Runner→DeviceSession，只有外部云响应替换为合成合同；获得自有合成设备后原账号归属链可用，云hold、员工禁用、外租户账号仍拒绝。没有手塞executor、session或internal scope。
3. 独立核8种非目标purpose、搜索与XHS review仍无授权；HTTP没有选择scope/review的入口，伪动作403。发送、release_approved与XHS hold保持。DM/live并未重新执行整条业务；确认其无新purpose返回且原实现未改，不扩写为真实DM/live验收。
4. 错root载体（仅负例）、错公司、索引原始字节变更、索引和许可实际hardlink均拒绝；自有物理junction实物也经新材料helper直接拒绝。junction项是材料helper反例，未冒称另一正向factory。所有原闭包字节恢复。
5. 原403设备撤权和stop后绑定拒绝；恢复文件后原release/依赖完整性门再次通过。

实际非frozen Python原factory另2组通过：带index仍不载carrier、仍原internal；受信负例误附typed frozen载体后scope为None且不回退internal，移除后恢复。

静态逐方法边界与11输入封后复核通过；原binding、Service/Runner/DeviceSession、Core权限、账号/模式/发送实现保持。实际合版仍须按MERGE-REPIN重新固定活跃vendor、原用途图、新材料、RELEASE/SHIPPED并跑合版工厂；不能直接套作者或本独审样本材料。

未验证真实云注册、本人自然登录、Native/WebView、平台规则授权与读取、第二普通电脑或商业分发；真实云/平台/模型/浏览器0。此结果不替代它们。自有服务全部终态。仅清理自有测试junction的命令被自动审查拒绝且未执行，故保留该无进程的本地实物证据；不影响服务停机或验收边界。
