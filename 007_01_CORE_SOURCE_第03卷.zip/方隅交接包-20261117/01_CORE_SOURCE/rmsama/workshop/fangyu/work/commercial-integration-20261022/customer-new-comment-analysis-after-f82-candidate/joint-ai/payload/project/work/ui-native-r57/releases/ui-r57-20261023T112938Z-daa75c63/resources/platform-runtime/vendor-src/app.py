"""Loopback-only desktop/browser host with configured enterprise cloud services."""
import argparse
import base64
import hashlib
import json
import logging
import mimetypes
import os
from pathlib import Path
import secrets
import stat
import shutil
import sys
import subprocess
import threading
import time
import re
import urllib.request
import webbrowser
from http.cookies import SimpleCookie
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import unquote, urlparse, parse_qs

from core import Core, CoreError
from ui_customization import load_customization, replacement_asset
from core.runtime_guards import cli_runtime_tree_sha256, opencli_evaluate_guard_verified, opencli_publication_guard_verified
from core.runtime_license_policy import RuntimeLicensePolicy
from bridge import BridgeManager, KuaishouBridgeManager
from account_browser import open_account_browser
from account_connections import AccountConnections
from wechat_channels_connection import WechatChannelsConnection
from opencli_bridge import OpenCLIBridge,OpenCLIBridgeError
from integrations import Integrations, IntegrationError, EmployeeLoginRequired
from assistant import employee_workspace as local_workspace
from assistant import private_evaluation
from assistant import employee_distribution
from assistant import development_workspace as dev_workspace
from assistant import saved_media
from assistant.local_runtime_errors import LocalPlatformRuntimeError

ROOT = Path(__FANGYU_SOURCE_ROOT__)  # Trusted original source resources; not an HTTP input.
ALLOWED_ASSETS = {'.png','.jpg','.jpeg','.webp','.pdf','.xlsx','.xls','.docx','.doc','.txt','.md','.csv'}

def apply_customer_release_policy(config, packaged=False):
    if config.get('id')!='fangyu-apartment-client':return config
    runtime=config.get('runtime') if isinstance(config.get('runtime'),dict) else {}
    # Internal QA is a process argument, never an activation copied from company.json.
    runtime={key:value for key,value in runtime.items() if key!='platform_qa_device_id'}
    activated=(packaged and config.get('edition')=='customer'
               and config.get('personalMode') is False and config.get('authMode')=='managed'
               and runtime.get('role')=='local_assistant_only'
               and runtime.get('release_approved') is True
               and runtime.get('xiaohongshu_automation')=='enabled'
               and isinstance(runtime.get('cli_source_sha256'),str)
               and re.fullmatch(r'[0-9a-f]{64}',runtime['cli_source_sha256']) is not None
               and isinstance(config.get('releaseVersion'),str) and bool(config['releaseVersion'].strip()))
    # Product routes are local capabilities; cloud leases and feature guards
    # still decide whether a bound employee may execute a platform action.
    return {**config,'platforms':['xiaohongshu','douyin','zhihu','wechat_channels','bilibili','kuaishou','weibo'],'edition':'customer',
            'personalMode':False,'authMode':'managed',
            'runtime':{**runtime,'xiaohongshu_automation':'enabled' if activated else 'hold'}}

def production_employee_workspace(config, packaged=False):
    """Select the bundled workspace only for an approved Fangyu customer release."""
    runtime=config.get('runtime') if isinstance(config.get('runtime'),dict) else {}
    return bool(packaged and config.get('id')=='fangyu-apartment-client'
                and config.get('edition')=='customer'
                and config.get('personalMode') is False
                and config.get('authMode')=='managed'
                and runtime.get('role')=='local_assistant_only'
                and runtime.get('ui_entry')=='employee_workspace'
                and runtime.get('release_approved') is True
                and runtime.get('xiaohongshu_automation')=='enabled'
                and isinstance(runtime.get('cli_source_sha256'),str)
                and re.fullmatch(r'[0-9a-f]{64}',runtime['cli_source_sha256']) is not None
                and isinstance(config.get('releaseVersion'),str)
                and bool(config['releaseVersion'].strip()))


def private_evaluation_workspace(config, capability, packaged=False):
    """Open the normal employee window only with a validated local permit."""
    return bool(packaged and private_evaluation.runtime_config_valid(config, capability))

def production_natural_workspace(config, packaged=False):
    """Select natural reading only when the approved bundle requests it."""
    if not production_employee_workspace(config,packaged=packaged):return False
    route=(config.get('runtime') or {}).get('xiaohongshu_read_transport')
    # Earlier releases have no marker. Preserve their route instead of silently
    # migrating an existing installation or enabling source QA from a config.
    if route in (None,'guarded_cli_v1'):return False
    if route!='natural_page_v1':
        raise ValueError('正式工作台的小红书读取路线无效，请使用完整的已验收版本')
    return True


def portable_browser_readonly_demo(config, *, packaged=False, native_window=False):
    """Explicit local demo selector; the bundled policy and cloud lease remain held."""
    return bool(native_window and employee_distribution.packaged_workspace(config, packaged=packaged))

def internal_platform_qa_config(config, device_id, packaged=False):
    """Opt in one source assistant; cloud confirmation remains mandatory."""
    runtime=config.get('runtime') or {}
    if (packaged or config.get('id')!='fangyu-apartment-client'
            or config.get('releaseVersion')!='1.1.7-qa.1'
            or runtime.get('release_approved') is True
            or runtime.get('xiaohongshu_automation')!='hold'
            or not isinstance(device_id,str) or not re.fullmatch(r'[A-Za-z0-9_-]{16,80}',device_id)
            or not isinstance(runtime.get('cli_source_sha256'),str)
            or runtime['cli_source_sha256']!=hashlib.sha256((ROOT/'platform_cli.py').read_bytes()).hexdigest()):
        raise ValueError('内部平台验收只允许指定设备的当前源码助手和已核对 CLI')
    return {**config,'runtime':{**runtime,'xiaohongshu_automation':'enabled',
                                'platform_qa_device_id':device_id}}

def company_config():
    external=(Path(sys.executable).parent if getattr(sys,'frozen',False) else ROOT.parent)/'company.json'
    path=external if external.exists() else ROOT/'resources'/'companies'/'general.json'
    config=json.loads(path.read_text('utf-8-sig')) if path.exists() else {'id':'workspace-default','name':'本地运营工作台','industry':'general'}
    if not re.fullmatch(r'[a-z][a-z0-9_-]{1,40}',config.get('id','')): raise ValueError('企业配置ID无效')
    return apply_customer_release_policy(config,packaged=bool(getattr(sys,'frozen',False)))

def guarded_cli_runtime_valid(executable,manifest_path,company,private_capability=None):
    if not executable.is_file() or not manifest_path.is_file():return False
    try:
        guard=json.loads(manifest_path.read_text('utf-8'))
        if not isinstance(guard,dict):return False
        valid=(guard.get('request_transport')=='single_attempt_all'
               and guard.get('activity_recording')=='account_local_v1'
               and guard.get('risk_stop')=='review_required'
               and guard.get('automatic_action_replay') is False
               and guard.get('purpose') in ('internal_qa_only','release_verified')
               and hashlib.sha256(executable.read_bytes()).hexdigest()==guard.get('exe_sha256')
               and cli_runtime_tree_sha256(executable.parent)==guard.get('runtime_tree_sha256'))
        if company.get('id')=='fangyu-apartment-client':
            runtime=company.get('runtime') or {}
            expected=runtime.get('cli_source_sha256') if isinstance(runtime,dict) else None
            valid=(valid and isinstance(expected,str) and re.fullmatch(r'[0-9a-f]{64}',expected) is not None
                   and guard.get('source_sha256')==expected)
            if isinstance(runtime,dict) and runtime.get('release_approved') is True:
                valid=valid and guard.get('purpose')=='release_verified'
            elif isinstance(runtime,dict) and runtime.get('portable_employee_release') is True:
                source_workbench=employee_distribution.workbench_source_config_valid(company)
                if source_workbench:
                    valid=(valid and guard.get('exe_sha256')==employee_distribution.WORKBENCH_EXE_SHA256
                           and guard.get('runtime_tree_sha256')==employee_distribution.WORKBENCH_TREE_SHA256)
                valid=(valid and (employee_distribution.packaged_workspace(
                    company,packaged=bool(getattr(sys,'frozen',False)))
                    or source_workbench)
                       and guard.get('purpose')=='internal_qa_only'
                       and guard.get('source_sha256')==(employee_distribution.WORKBENCH_SOURCE_SHA256
                           if source_workbench else employee_distribution.SOURCE_SHA256)
                       and hashlib.sha256((ROOT/'platform_cli.py').read_bytes()).hexdigest()==expected)
            elif isinstance(runtime,dict) and runtime.get('private_evaluation') is True:
                qa_id=runtime.get('platform_qa_device_id') or ''
                valid=(valid and private_evaluation.runtime_config_valid(company,private_capability,qa_id)
                       and guard.get('purpose')=='internal_qa_only'
                       and guard.get('source_sha256')==private_evaluation.SOURCE_SHA256)
            if isinstance(runtime,dict) and runtime.get('platform_qa_device_id'):
                if runtime.get('private_evaluation') is True:
                    valid=(valid and private_evaluation.runtime_config_valid(
                        company,private_capability,runtime['platform_qa_device_id']))
                else:
                    valid=(valid and not getattr(sys,'frozen',False)
                           and guard.get('purpose')=='internal_qa_only'
                           and hashlib.sha256((ROOT/'platform_cli.py').read_bytes()).hexdigest()==expected)
        return valid
    except (ValueError,OSError):return False

def source_guarded_cli_selection(path, company, *, owner_instance=None):
    """Choose a source runtime and its wrapper identity, without granting use."""
    from assistant.self_operating_read import _OwnerReadInstance
    owner=(type(owner_instance) is _OwnerReadInstance and owner_instance.check()==company)
    if (getattr(sys,'frozen',False) or not isinstance(path,str) or not path or len(path)>500
            or any(ord(c)<32 for c in path) or not Path(path).is_absolute()
            or '..' in Path(path).parts or not isinstance(company,dict)
            or (not owner and (company.get('id')!='fangyu-apartment-client' or company.get('authMode')!='managed'))):
        raise ValueError('源码运行库选择只允许本项目的受控目录')
    runtime=company.get('runtime')
    if (not isinstance(runtime,dict) or runtime.get('release_approved') not in (None,False)
            or runtime.get('private_evaluation') not in (None,False)
            or runtime.get('portable_employee_release') not in (None,False)
            or runtime.get('platform_qa_device_id')):
        raise ValueError('源码运行库选择不与发行或设备验收模式混用')
    work_root=ROOT.parents[1]
    selected=Path(path)
    try:relative=selected.relative_to(work_root)
    except ValueError:raise ValueError('源码运行库须位于本项目 work 内') from None
    if not relative.parts:raise ValueError('源码运行库须选择独立目录')
    current=work_root
    for part in ('',*relative.parts):
        if part:current=current/part
        attrs=current.lstat()
        if (not stat.S_ISDIR(attrs.st_mode) or current.is_symlink()
                or getattr(attrs,'st_file_attributes',0)&getattr(stat,'FILE_ATTRIBUTE_REPARSE_POINT',0)):
            raise ValueError('源码运行库目录不允许链接或重定向')
    executable,manifest=selected/'platform-cli.exe',selected/'guard-manifest.json'
    for item in (executable,manifest):
        attrs=item.lstat()
        if (not stat.S_ISREG(attrs.st_mode) or item.is_symlink()
                or getattr(attrs,'st_file_attributes',0)&getattr(stat,'FILE_ATTRIBUTE_REPARSE_POINT',0)):
            raise ValueError('源码运行库文件无效')
    if not 0<manifest.stat().st_size<=65536:raise ValueError('源码运行库清单无效')
    configured=json.loads(json.dumps(company))
    configured['runtime']['cli_source_sha256']=hashlib.sha256((ROOT/'platform_cli.py').read_bytes()).hexdigest()
    if not guarded_cli_runtime_valid(executable,manifest,configured):
        raise ValueError('源码运行库与当前 wrapper 未通过原守卫核对')
    return configured,selected


class _TrustedStartupRuntimeReview:
    """Source main's pinned local file; never a request/company approval input."""
    def __init__(self, path, digest, company, *, owner_instance=None):
        from assistant.self_operating_read import _OwnerReadInstance
        if owner_instance is not None and (type(owner_instance) is not _OwnerReadInstance or owner_instance.check()!=company):
            raise ValueError('自营审核实例绑定无效')
        self._owner_instance=owner_instance
        fixed=ROOT.parents[1]/'component-reviews'/'xiaohongshu'/'guarded-cli-internal-read.json'
        if owner_instance is not None:fixed=owner_instance.directory/'component-review.json'
        if (getattr(sys,'frozen',False) or not isinstance(path,str) or len(path)>500
                or any(ord(c)<32 for c in path) or not Path(path).is_absolute()
                or Path(path)!=fixed or not isinstance(digest,str)
                or re.fullmatch(r'[0-9a-fA-F]{64}',digest) is None):
            raise ValueError('组件审核文件只允许绑定固定源码自用入口')
        self._path,self._digest=fixed,digest.lower()
        self._review=self._read(company)

    def _read(self, company):
        if (getattr(sys,'frozen',False) or not isinstance(company,dict)
                or (self._owner_instance is None and (company.get('id')!='fangyu-apartment-client'
                or company.get('authMode')!='managed'))
                or (self._owner_instance is not None and self._owner_instance.check()!=company)):
            raise ValueError('组件审核文件的公司或源码用途不匹配')
        root=ROOT.parents[1]
        current=root
        for part in ('',*self._path.relative_to(root).parts):
            if part:current=current/part
            attrs=current.lstat()
            if current.is_symlink() or getattr(attrs,'st_file_attributes',0)&getattr(stat,'FILE_ATTRIBUTE_REPARSE_POINT',0):
                raise ValueError('组件审核文件不允许链接目录')
        with self._path.open('rb') as stream:data=stream.read(65537)
        if not data or len(data)>65536 or hashlib.sha256(data).hexdigest()!=self._digest:
            raise ValueError('组件审核文件摘要不匹配或内容超长')
        def pairs(items):
            result={}
            for key,item in items:
                if key in result:raise ValueError('组件审核文件有重复字段')
                result[key]=item
            return result
        try:review=json.loads(data.decode('utf-8'),object_pairs_hook=pairs)
        except (UnicodeError,ValueError):raise ValueError('组件审核文件格式无效') from None
        checked=RuntimeLicensePolicy(review,server=None,source_wrapper=ROOT/'platform_cli.py',
            material_root=root,usage_scope='internal_self_use_read',runtime_validator=guarded_cli_runtime_valid)
        review=checked._review  # Reuse original schema; never convert an approval.
        if (review is None or review['company_id']!=company['id']
                or review['route']!='guarded_cli_v1' or review['usage_scope']!='internal_self_use_read'
                or str(review['review']['revision']).startswith('recorded-mainflow-')
                or str(review['review']['reviewer_ref']).startswith('synthetic-')):
            raise ValueError('组件审核文件用途或审核来源未通过核对')
        return review

    @property
    def review(self):
        return json.loads(json.dumps(self._review))

    def current(self, company):
        try:return self._read(company)==self._review
        except (OSError,ValueError,TypeError):return False


class AppServer(ThreadingHTTPServer):
    daemon_threads = True
    def __init__(self, address, data_dir, platform_qa_device_id='', employee_workspace=False, install_root=None, development_workspace=False, xhs_page_transport=False,
                 xhs_natural_transport=False, private_evaluation_capability=None, xhs_browser_readonly_demo=False,
                 *, runtime_license_review=None, runtime_license_usage_scope=None, runtime_license_review_binding=None,
                 manual_owned_read_start=False, guarded_cli_runtime=None, self_operating_instance=None,
                 owner_metadata_recovery=False, trusted_company=None,
                 defer_startup_recovery=False, defer_platform_setup=False, customer_read_authority=None):
        if runtime_license_review_binding is not None and (
                type(runtime_license_review_binding) is not _TrustedStartupRuntimeReview
                or getattr(sys,'frozen',False) or runtime_license_usage_scope!='internal_self_use_read'
                or runtime_license_review!=runtime_license_review_binding.review):
            raise ValueError('启动组件审核绑定无效')
        if type(defer_startup_recovery) is not bool or type(defer_platform_setup) is not bool:
            raise ValueError('启动恢复或平台装配模式无效')
        if trusted_company is not None and (type(trusted_company) is not dict or self_operating_instance is not None):
            raise ValueError('可信员工配置无效')
        if customer_read_authority is not None:
            authority_module=sys.modules.get('fangyu_customer_read_distribution')
            if (authority_module is None or not authority_module.is_authority(customer_read_authority)
                    or runtime_license_review is not None or runtime_license_review_binding is not None
                    or runtime_license_usage_scope is not None):
                raise ValueError('客户读取用途宿主绑定无效')
        self._customer_read_authority=customer_read_authority
        self._runtime_license_review_binding=runtime_license_review_binding
        from assistant.self_operating_read import _OwnerReadInstance, OwnerReadWorkspace
        self.self_operating_instance=self_operating_instance
        self.self_operating_read=self_operating_instance is not None
        if (type(owner_metadata_recovery) is not bool or owner_metadata_recovery
                and (not self.self_operating_read or getattr(sys,'frozen',False))):
            raise ValueError('元数据恢复只用于原源码自营实例')
        self.owner_metadata_recovery=owner_metadata_recovery
        if self.self_operating_read and (type(self_operating_instance) is not _OwnerReadInstance
                or getattr(sys,'frozen',False) or not employee_workspace or install_root or development_workspace
                or platform_qa_device_id or xhs_page_transport or xhs_natural_transport
                or private_evaluation_capability or xhs_browser_readonly_demo or manual_owned_read_start
                or not guarded_cli_runtime or Path(data_dir)!=self_operating_instance.directory/'data'):
            raise ValueError('自营只读入口不能混用客户、安装、设备或原数据目录')
        selected_company=(self_operating_instance.check() if self.self_operating_read else
            json.loads(json.dumps(trusted_company)) if trusted_company is not None else None)
        self._source_guarded_cli_runtime=None
        if employee_distribution.workbench_source_config_valid(selected_company):
            self._source_guarded_cli_runtime=Path(__FANGYU_GUARDED_CLI_RUNTIME_ROOT__)
        if guarded_cli_runtime is not None:
            if (not employee_workspace or install_root or development_workspace or platform_qa_device_id
                    or xhs_page_transport or xhs_natural_transport or private_evaluation_capability
                    or xhs_browser_readonly_demo or manual_owned_read_start):
                raise ValueError('源码运行库选择仅限原源码员工工作台')
            selected_company,self._source_guarded_cli_runtime=source_guarded_cli_selection(
                guarded_cli_runtime,selected_company if self.self_operating_read else company_config(),
                owner_instance=self_operating_instance)
        if type(manual_owned_read_start) is not bool:raise ValueError("手动启动模式无效")
        if manual_owned_read_start and (getattr(sys,"frozen",False) or not employee_workspace
                or install_root or development_workspace or platform_qa_device_id
                or xhs_page_transport or xhs_natural_transport or private_evaluation_capability
                or xhs_browser_readonly_demo):
            raise ValueError("手动起用仅限原源码员工工作台，不与授权或安装模式混用")
        self.manual_owned_read_start=manual_owned_read_start
        if self.self_operating_read:self_operating_instance.prepare_data()
        super().__init__(address, Handler)
        self.employee_workspace_mode=bool(employee_workspace)
        self.employee_pair_lock=threading.Lock()
        data_dir=Path(data_dir).resolve()
        self.core = Core(data_dir, ROOT/'resources',defer_startup_recovery=manual_owned_read_start or self.self_operating_read or defer_startup_recovery)
        if self.self_operating_read and any(u.get('personal_owner') is not True for u in self.core.store.list('users')):
            self.server_close();raise ValueError('自营实例不接管已有员工或管理员身份')
        if manual_owned_read_start or defer_startup_recovery:self.core.remote_safety_hold=True
        from assistant.xhs_app_context import XhsAppHostContext
        self._xhs_app_context = XhsAppHostContext(self)
        self.integrations = Integrations(self.core)
        self.failures = {}
        self.started = time.time()
        self.company=selected_company if selected_company is not None else company_config()
        self.private_evaluation_capability=private_evaluation_capability
        self.install_root=Path(install_root).resolve() if install_root else None
        if self.install_root:
            from assistant.update_coordinator import load_update_policy
            self.company=load_update_policy(self.company,self.install_root)
        if self.employee_workspace_mode and not (
                self.self_operating_read or production_employee_workspace(self.company, packaged=bool(getattr(sys,'frozen',False)))
                or employee_distribution.packaged_workspace(self.company,
                                                           packaged=bool(getattr(sys,'frozen',False)))
                or private_evaluation_workspace(self.company,self.private_evaluation_capability,
                                                packaged=bool(getattr(sys,'frozen',False)))
                or (not getattr(sys,'frozen',False)
                    and self.company.get('id')=='fangyu-apartment-client'
                    and self.company.get('authMode')=='managed')):
            self.server_close()
            raise ValueError('本机员工工作台仅允许方隅源码验收或已批准正式客户包')
        self.development_workspace=False
        self.development_signed_out=False
        self.development_identity_lock=threading.Lock()
        self.development_identity_condition=threading.Condition(self.development_identity_lock)
        self.development_identity_pending=False
        self.development_identity_last_failure=-1e9
        self.development_identity_snapshot=None
        self.development_identity_generation=0
        self.development_reauth_lock=threading.Lock()
        self.development_reauth_pending=False
        self.development_reauth_last_attempt=-1e9
        if development_workspace:
            if not dev_workspace.enabled(self.company, self.employee_workspace_mode,
                                         platform_qa_device_id, address):
                self.server_close()
                raise ValueError('开发直入仅允许指定验收电脑的方隅源码员工工作台')
            self.development_workspace=True
        if platform_qa_device_id:
            self.company=internal_platform_qa_config(self.company,platform_qa_device_id,
                                                     packaged=bool(getattr(sys,'frozen',False)))
            self.core.remote_safety_hold=True
        # Personal upgrades gain the new connector; customer platform entitlements stay fixed.
        if not self.self_operating_read and self.company.get('edition')=='owner' and self.company.get('personalMode') is True:
            self.company['platforms']=list(dict.fromkeys([*self.company.get('platforms',[]),'wechat_channels']))
        self.customization_dir=(Path(sys.executable).parent if getattr(sys,"frozen",False) else ROOT.parent)/"客户定制"
        self.ui_customization=load_customization(self.customization_dir)
        self.core.deployment_config=json.loads(json.dumps(self.company))
        self.jobs = {}
        self.job_lock = threading.Lock()
        if self.self_operating_read:
            self._owner_http_threads=set();self._owner_http_started=False
            self._owner_close_lock=threading.Lock()
        self.closing = False
        # The Native host supplies this fixed source-owned runtime in both forms.
        runtime=Path(__FANGYU_DOUYIN_RUNTIME_ROOT__)
        if self.self_operating_read:
            from assistant.owner_douyin_read import owner_runtime_root
            self.bridge=BridgeManager(data_dir,owner_runtime_root())
        else:
            self.bridge=BridgeManager(data_dir,runtime)
        self.kuaishou_bridge=KuaishouBridgeManager(data_dir,runtime.parent/'kuaishou-bridge',runtime)
        opencli_runtime=runtime.parent/'opencli'
        guarded_opencli=runtime.parent/'opencli-guarded'
        if (guarded_opencli/'node.exe').is_file() and opencli_evaluate_guard_verified(guarded_opencli):
            opencli_runtime=guarded_opencli
        guarded_v2=runtime.parent/'opencli-guarded-v2'
        if (guarded_v2/'node.exe').is_file() and opencli_publication_guard_verified(guarded_v2):
            opencli_runtime=guarded_v2
        if not getattr(sys,'frozen',False) and not (opencli_runtime/'node.exe').is_file():
            opencli_runtime=ROOT.parents[2]/'opencli-build/runtime'
        # The customer edition has an explicit platform allowlist. Do not fall
        # back to legacy Zhihu access when a configuration omits platforms.
        self.opencli=OpenCLIBridge(data_dir,opencli_runtime) if 'zhihu' in self.company.get('platforms',[]) else None
        if self.opencli:self.core.adapters.profile_checker=self.opencli.require_profile
        # Defer only the old CLI startup check for the explicit source page
        # constructor. This is selection, not permission; fixed review and all
        # original read/session/Native gates still precede platform activity.
        self._defer_cli_for_source_page_read=bool(not getattr(sys,'frozen',False)
            and self.employee_workspace_mode and platform_qa_device_id
            and self.company.get('id')=='fangyu-apartment-client'
            and xhs_page_transport and xhs_natural_transport)
        if not defer_platform_setup:self._configure_bundled()
        self.core.adapters.platform_guard=self._platform_execution_guard
        self.xhs_page_runtime=None
        browser_demo=portable_browser_readonly_demo(self.company,
            packaged=bool(getattr(sys,'frozen',False)),native_window=self.employee_workspace_mode)
        if xhs_browser_readonly_demo and not browser_demo:
            self.server_close()
            raise ValueError('浏览器只读演示仅允许完整员工安装包的本机窗口')
        try:
            production_natural=bool(self.employee_workspace_mode and production_natural_workspace(
                self.company,packaged=bool(getattr(sys,'frozen',False))))
        except ValueError:
            self.server_close()
            raise
        if production_natural:
            xhs_page_transport=True
            xhs_natural_transport=True
        if xhs_browser_readonly_demo:
            xhs_page_transport=True
            xhs_natural_transport=True
        if xhs_natural_transport and not xhs_page_transport:
            self.server_close()
            raise ValueError('自然页面读取需由指定源码网页采集入口启用')
        if xhs_page_transport:
            source_qa=(not getattr(sys,'frozen',False) and self.employee_workspace_mode
                       and bool(platform_qa_device_id) and self.company.get('id')=='fangyu-apartment-client')
            if not (production_natural or source_qa or xhs_browser_readonly_demo and browser_demo):
                self.server_close()
                raise ValueError('页面采集仅允许方隅源码验收、已批准客户包或显式本机演示')
            from assistant.xhs_page_runtime import XhsPageRuntime
            from xhs_page_window import launch_helper
            self.xhs_page_runtime=XhsPageRuntime(self.core,launch_helper,natural_mode=xhs_natural_transport,
                app_context_factory=self._xhs_app_context)
            self.core.adapters.xhs_page_runtime=self.xhs_page_runtime
        # Source-only fixed material review: no HTTP/company approval input.
        from assistant.xhs_page_read_policy import XhsPageReadPolicy
        self._xhs_page_read_policy=XhsPageReadPolicy(self)
        self.core._xhs_page_read_policy=self._xhs_page_read_policy
        from assistant.xhs_identity_policy import XhsIdentityObservationPolicy
        self._xhs_identity_contexts={}
        self._xhs_identity_policy=XhsIdentityObservationPolicy(self)
        from assistant.xhs_session_policy import XhsSessionRecoveryPolicy
        self._xhs_session_contexts={}
        self._xhs_session_policy=XhsSessionRecoveryPolicy(self)
        self._xhs_native_provider=None
        if self.xhs_page_runtime is not None:
            from assistant.owned_xhs_native.provider import OwnedXhsNativeProvider
            self._xhs_native_provider=OwnedXhsNativeProvider(self,page_policy=self._xhs_page_read_policy,
                identity_policy=self._xhs_identity_policy,session_policy=self._xhs_session_policy)
            self.xhs_page_runtime.owned_helper_factory=self._xhs_native_provider.factory
            self.xhs_page_runtime.owned_identity_factory=self._xhs_native_provider.identity_factory
            self.xhs_page_runtime.owned_session_factory=self._xhs_native_provider.session_factory
        self.account_connections=AccountConnections(self)
        self.wechat_channels=WechatChannelsConnection(self,runtime.parent/'wechat-channels')
        from core.wechat_preview_policy import WechatPreviewPolicy
        self._wechat_preview_policy=WechatPreviewPolicy(self)
        self._self_operating_reads=OwnerReadWorkspace(self,self_operating_instance) if self.self_operating_read else None
        # Only a trusted Python host may inject an audited, fixed review.  No
        # company JSON, HTTP body, QA permit or adapter declaration grants it.
        if self._customer_read_authority is not None:
            runtime_license_review=self._customer_read_authority.runtime_license_review(
                self,'xiaohongshu_guarded_read')
            runtime_license_usage_scope='customer_distribution_read'
        self._runtime_license_policy=RuntimeLicensePolicy(
            runtime_license_review, server=self, source_wrapper=ROOT/'platform_cli.py',
            material_root=(Path(sys.executable).parent if getattr(sys,'frozen',False) else ROOT.parents[1]),
            usage_scope=runtime_license_usage_scope,
            usage_scope_provider=lambda:self._runtime_license_usage_scope(runtime_license_usage_scope),
            runtime_validator=guarded_cli_runtime_valid)
        from core.bilibili_read_policy import BilibiliReadPolicy
        self._bilibili_read_policy=BilibiliReadPolicy(self)
        from core.douyin_comments_policy import DouyinCommentsPolicy
        self._douyin_comments_policy=DouyinCommentsPolicy(self)
        from core.douyin_search_policy import DouyinSearchPolicy
        self._douyin_search_policy=DouyinSearchPolicy(self)  # default pending; trusted purpose review is separate

    @property
    def platform_read_license_policy(self):
        policy=getattr(self,'_runtime_license_policy',None)
        binding=getattr(self,'_runtime_license_review_binding',None)
        current=binding is None or type(binding) is _TrustedStartupRuntimeReview and binding.current(self.company)
        original=policy.resolve() if current and isinstance(policy,RuntimeLicensePolicy) else None
        if binding is not None and (not current or not binding.current(self.company)):
            original={'xiaohongshu':False,'revision':hashlib.sha256(b'local-startup-review-unavailable-v1').hexdigest()}
        from core.bilibili_read_policy import BilibiliReadPolicy
        bili=getattr(self,'_bilibili_read_policy',None)
        extra=bili.resolve() if type(bili) is BilibiliReadPolicy and bili._server is self else None
        if type(extra) is not dict or type(extra.get('bilibili')) is not bool:return original
        previous=original if type(original) is dict else {}
        revision=hashlib.sha256(json.dumps(['platform_read_component_selection_v1',
            previous.get('revision'),extra.get('revision')],sort_keys=True,separators=(',',':')).encode()).hexdigest()
        return {**previous,'bilibili':extra['bilibili'],'revision':revision}

    def _runtime_license_usage_scope(self, requested=None):
        """Recognize actual deployment use; freezing is not component approval."""
        if requested not in (None,'internal_self_use_read','customer_distribution_read'):
            return None
        authority=getattr(self,'_customer_read_authority',None)
        if authority is not None:
            scope=authority.scope_for(self)
            return scope if requested is None or requested==scope else None
        company=self.company
        runtime=company.get('runtime') if isinstance(company,dict) else None
        if not isinstance(runtime,dict):runtime={}
        packaged=bool(getattr(sys,'frozen',False))
        capability=getattr(self,'private_evaluation_capability',None)
        scope=None
        try:
            if runtime.get('private_evaluation') not in (None,False):
                if (runtime.get('private_evaluation') is not True
                        or not packaged or not private_evaluation.runtime_config_valid(
                            company,capability,runtime.get('platform_qa_device_id') or '')):
                    return None
                private_evaluation.ensure_current(capability)
                scope='internal_self_use_read'
            elif runtime.get('portable_employee_release') not in (None,False):
                if employee_distribution.workbench_source_config_valid(company):
                    scope='internal_self_use_read'
                elif employee_distribution.packaged_workspace(company,packaged=packaged):
                    scope='customer_distribution_read'
                else:return None
            elif production_employee_workspace(company,packaged=packaged):
                scope='customer_distribution_read'
            elif not packaged:
                # A source process can inspect release artifacts internally;
                # release_approved by itself never means this is distribution.
                scope='internal_self_use_read'
        except Exception:return None
        return scope if requested is None or requested==scope else None

    def _customer_distribution_purpose(self,purpose):
        authority=getattr(self,'_customer_read_authority',None)
        module=sys.modules.get('fangyu_customer_read_distribution')
        if authority is None or module is None or not module.is_authority(authority):
            return None
        return authority.resolve(self,purpose)

    def bridge_for(self,platform='douyin'):
        self.core.require_platform(platform)
        if platform=='zhihu':return self.opencli
        if platform=='douyin':return self.bridge
        if platform=='kuaishou':return self.kuaishou_bridge
        raise CoreError('该平台不使用浏览器连接服务')

    def _platform_execution_guard(self,platform):
        if self.self_operating_read:
            return self._self_operating_reads.execution_guard(platform)
        if self.manual_owned_read_start:
            raise CoreError("手动工作台尚缺完整权威许可，平台操作保持暂停")
        private_capability=getattr(self,'private_evaluation_capability',None)
        if platform=='xiaohongshu' and private_capability:
            private_evaluation.ensure_current(private_capability)
        self.core._platform_execution_guard(platform)
        if platform=='bilibili' and self.employee_workspace_mode:
            # Bili uses its own fixed source component policy. Reuse the
            # original bound employee/device guards for every adapter action.
            from assistant.bilibili_setup_service import _binding
            _binding(getattr(self,'assistant_service',None),execution=True)
        if platform=='xiaohongshu':
            from assistant.xhs_page_read_policy import current_read_decision
            if current_read_decision(self.core) is not None:
                # Only this private source/read call supersedes the old CLI gate.
                return
        runtime=self.company.get('runtime') or {}
        portable=(platform=='xiaohongshu' and (employee_distribution.packaged_workspace(
            self.company,packaged=bool(getattr(sys,'frozen',False)))
            or employee_distribution.workbench_source_config_valid(self.company)))
        if portable:
            assistant=getattr(self,'assistant_service',None)
            if not assistant or assistant.state!='online' or not (assistant.device or {}).get('owner'):
                raise CoreError('企业连接尚未确认，请稍后再试')
        if (platform=='xiaohongshu' and self.company.get('id')=='fangyu-apartment-client'
                and isinstance(runtime,dict)
                and (portable or (runtime.get('release_approved') is True or runtime.get('platform_qa_device_id'))
                     and runtime.get('xiaohongshu_automation')=='enabled')):
            qa_device=runtime.get('platform_qa_device_id')
            if qa_device:
                assistant=getattr(self,'assistant_service',None)
                if (not assistant or (assistant.device or {}).get('id')!=qa_device
                        or assistant.state!='online' or self.company.get('releaseVersion')!='1.1.7-qa.1'):
                    raise CoreError('指定内部验收电脑尚未获得云端确认，平台操作保持暂停')
            if not guarded_cli_runtime_valid(self.guarded_cli_executable,self.guarded_cli_manifest,
                                             self.company,private_capability):
                raise LocalPlatformRuntimeError('cli_runtime_invalid')
            selected=self.core.adapters.manifest('xiaohongshu')
            if (Path(selected['executable']).resolve()!=self.guarded_cli_executable.resolve()
                    or selected.get('prefix_args')!=['xiaohongshu']
                    or selected.get('isolation_guard') is not True):
                raise LocalPlatformRuntimeError('cli_adapter_invalid')

    def process_request(self,request,client_address):
        if self.self_operating_read:
            from assistant.owner_normal_close import owner_process_request
            return owner_process_request(self,request,client_address)
        return super().process_request(request,client_address)

    def close_owned_jobs(self):
        if not self.self_operating_read:return self._close_owned_jobs()
        if not self._owner_close_lock.acquire(blocking=False):return False
        try:return self._close_owned_jobs()
        finally:self._owner_close_lock.release()

    def _close_owned_jobs(self):
        if self.self_operating_read:
            from assistant.owner_normal_close import begin_owner_close
            if not begin_owner_close(self):return False
        elif self._self_operating_reads is not None and not self._self_operating_reads.close():
            # The original account lock/registry stays owned until physical
            # login exit is confirmed. Do not let generic close drop it.
            self.closing=True
            return False
        with self.job_lock:
            self.closing=True
            processes=[job.get('process') for job in self.jobs.values() if job.get('process')]
        auto_update=getattr(self,'auto_update_worker',None)
        if auto_update:auto_update.close(timeout=5)
        assistant=getattr(self,'assistant_service',None)
        tracked=getattr(self,'tracked_reply_service',None)
        if tracked:tracked.close(timeout=8)
        if assistant:assistant.stop(timeout=0)
        for event in list(self.core.sequences.values()):event.set()
        close_scheduler=getattr(self.core,'close_continuous_scheduler',None)
        if callable(close_scheduler):close_scheduler(wait=False)
        ai_worker=getattr(self,'ai_worker',None)
        if ai_worker and callable(getattr(ai_worker,'close',None)):ai_worker.close()
        self.core.adapters.close()
        for process in processes:
            if process.poll() is None:
                process.terminate()
                try:process.wait(timeout=3)
                except subprocess.TimeoutExpired:process.kill();process.wait(timeout=3)
        self.account_connections.close()
        self.bridge.close();self.kuaishou_bridge.close()
        if self.opencli:self.opencli.close()
        if assistant and not assistant.stop(timeout=30):
            logging.error('Assistant worker is still stopping')
            if self.self_operating_read:return False
        if self.self_operating_read:
            from assistant.owner_normal_close import owner_physical_closed
            closed=owner_physical_closed(self)
            if closed:
                mutex=getattr(self,'_owner_instance_mutex',None)
                if mutex is not None:mutex.record_owned_close()
            return closed

    def start_auto_updates(self):
        if (self.manual_owned_read_start or self.closing or getattr(self,'update_startup_pending',False)
                or not self.install_root or not (self.company.get('updateFeed') or {}).get('enabled')
                or getattr(self,'auto_update_worker',None)):
            return
        from assistant.auto_update import AutoUpdateWorker
        from assistant.business import server_update_coordinator
        self.auto_update_worker=AutoUpdateWorker(server_update_coordinator(self)).start()

    def _configure_bundled(self):
        """Resolve runtime paths per installation, not development machine."""
        bin_dir = Path(sys.executable).parent if getattr(sys,'frozen',False) else Path(__FANGYU_RUNTIME_ROOT__)
        allowed=set(self.company.get('platforms') or [])
        cli = bin_dir/'platform-cli'/'platform-cli.exe'
        selected=getattr(self,'_source_guarded_cli_runtime',None)
        guarded=(selected if selected is not None else bin_dir/'platform-cli-guarded')/'platform-cli.exe'
        guard_path=guarded.parent/'guard-manifest.json'
        self.guarded_cli_executable=guarded
        self.guarded_cli_manifest=guard_path
        if self.manual_owned_read_start or self.owner_metadata_recovery:return  # Preserve original adapter files in held/recovery mode.
        guarded_ok=guarded_cli_runtime_valid(guarded,guard_path,self.company,
                                             self.private_evaluation_capability)
        if ('xiaohongshu' in allowed and not guarded_ok
                and (self.company.get('runtime') or {}).get('xiaohongshu_automation')!='hold'
                and not self._defer_cli_for_source_page_read):
            raise RuntimeError('小红书 CLI 防护运行库未通过验证，禁止启动自动化')
        if guarded_ok:cli=guarded
        adapter_root=self.core.store.directory/'adapters'; adapter_root.mkdir(exist_ok=True)
        oc=self.opencli.runtime if self.opencli else None
        if 'zhihu' in allowed and oc and (oc/'node.exe').is_file() and (oc/'dist/src/main.js').is_file():
            path=adapter_root/'zhihu.json'
            previous=json.loads(path.read_text('utf-8')) if path.exists() else {'id':'zhihu'}
            previous.update(executable=str(oc/'node.exe'),prefix_args=['--require',str(ROOT/'resources/opencli-managed.cjs'),str(oc/'dist/src/main.js')],isolation_guard=True,reply_contract_verified=False,publication_transport_verified=opencli_publication_guard_verified(oc),evaluate_single_attempt_verified=opencli_evaluate_guard_verified(oc))
            path.write_text(json.dumps(previous,ensure_ascii=False,indent=2),'utf-8')
        for platform in ('xiaohongshu',):
            if platform=='xiaohongshu' and not guarded_ok:continue
            if platform not in allowed or not cli.exists(): continue
            path=adapter_root/(platform+'.json')
            previous=json.loads(path.read_text('utf-8')) if path.exists() else {'id':platform}
            previous.update(executable=str(cli),prefix_args=[platform],isolation_guard=True,reply_contract_verified=platform=='xiaohongshu',publication_transport_verified=platform=='xiaohongshu' and guarded_ok)
            path.write_text(json.dumps(previous,ensure_ascii=False,indent=2),'utf-8')
        wx_manifest=ROOT/'resources/adapters/wechat_channels.json'
        if 'wechat_channels' in allowed and wx_manifest.is_file():
            wx_base=json.loads(wx_manifest.read_text('utf-8-sig'))
            wx_base.pop('executable',None)
            (adapter_root/'wechat_channels.json').write_text(json.dumps(wx_base,ensure_ascii=False,indent=2),'utf-8')
        dy=self.bridge.runtime
        if 'douyin' in allowed and (dy/'node.exe').exists():
            path=adapter_root/'douyin.json'
            previous=json.loads(path.read_text('utf-8')) if path.exists() else {'id':'douyin'}
            base=json.loads((ROOT/'resources'/'adapters'/'douyin.json').read_text('utf-8-sig'))
            # A bundled command is not evidence of reviewed recipient/delivery semantics.
            previous.update(executable=str(dy/'node.exe'),isolation_guard=True,reply_contract_verified=True,dm_contract_verified=False,paged_comments=base.get('paged_comments',False))
            for key in ('search_args','comments_args','status_args'):
                previous[key]=[str(dy/'cli.js') if x=='cli.js' else x for x in base.get(key,[])]
            path.write_text(json.dumps(previous,ensure_ascii=False,indent=2),'utf-8')

        ks=bin_dir/'kuaishou-bridge'
        if 'kuaishou' in allowed and (ks/'cli.js').exists() and (dy/'node.exe').exists():
            path=adapter_root/'kuaishou.json'
            previous=json.loads(path.read_text('utf-8')) if path.exists() else {'id':'kuaishou'}
            base=json.loads((ROOT/'resources'/'adapters'/'kuaishou.json').read_text('utf-8-sig'))
            previous.update(executable=str(dy/'node.exe'),isolation_guard=True,reply_contract_verified=False)
            for key in ('comments_args','status_args'):
                previous[key]=[str(ks/'cli.js') if x=='cli.js' else x for x in base.get(key,[])]
            path.write_text(json.dumps(previous,ensure_ascii=False,indent=2),'utf-8')

class Handler(BaseHTTPRequestHandler):
    server_version = 'LocalWorkspace/1.0'
    def log_message(self, fmt, *args):
        # Never log request bodies, passwords or URL query credentials.
        logging.info('%s %s',self.command,self.path.split('?')[0])
    def host_ok(self):
        return self.headers.get('Host') in ('127.0.0.1:'+str(self.server.server_port),'localhost:'+str(self.server.server_port))
    def token(self):
        try:
            cookie=SimpleCookie(self.headers.get('Cookie',''))
            name=('owner_session_'+self.server.company['selfOperatingRead']['instance_id']
                  if self.server.self_operating_read else 'session')
            return cookie[name].value if name in cookie else '' 
        except Exception: return ''
    def user(self):
        user=self.server.core.session(self.token())
        if getattr(self.server,'development_workspace',False):
            local=dev_workspace.local_operator(self.server)
            if not local:return None
            return dev_workspace.verified_or_local(self.server,local)
        if self.server.company.get('authMode')=='managed' and user and not user.get('cloud_bound'):return None
        return self.server.integrations.verify_identity(user)
    def assistant_only(self):
        runtime=self.server.company.get('runtime') or {}
        return (runtime.get('role')=='local_assistant_only'
                or (self.server.company.get('id')=='fangyu-apartment-client'
                    and getattr(self.server,'assistant_service',None) is not None))
    def respond(self, data, code=200, cookie=None, persistent=False, cookie_max_age=None):
        body=json.dumps(data,ensure_ascii=False).encode('utf-8')
        self.send_response(code); self.security_headers()
        self.send_header('Content-Type','application/json; charset=utf-8')
        self.send_header('Content-Length',str(len(body)))
        if cookie is not None:
            max_age = (min(cookie_max_age, 90 * 86400)
                       if type(cookie_max_age) is int and cookie_max_age > 0 and persistent else
                       28800 if persistent else None)
            name=('owner_session_'+self.server.company['selfOperatingRead']['instance_id']
                  if self.server.self_operating_read else 'session')
            self.send_header('Set-Cookie',name+'='+cookie+'; HttpOnly; SameSite=Strict; Path=/'
                             + ('; Max-Age=0' if not cookie else '; Max-Age='+str(max_age) if max_age else ''))
        self.end_headers(); self.wfile.write(body)
    def security_headers(self,embed=False,workspace=False):
        self.send_header('X-Content-Type-Options','nosniff')
        self.send_header('X-Frame-Options','SAMEORIGIN' if embed else 'DENY')
        self.send_header('Referrer-Policy','no-referrer')
        self.send_header('Cache-Control','no-store')
        ancestors="'self'" if embed else "'none'"
        if workspace:
            self.send_header('Content-Security-Policy',"default-src 'none'; script-src 'self'; style-src 'self'; connect-src 'self'; img-src 'self' data: https://*.xhscdn.com https://*.xiaohongshu.com; form-action 'self'; frame-ancestors 'none'; object-src 'none'; base-uri 'none'")
        else:
            self.send_header('Content-Security-Policy',"default-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'; connect-src 'self'; frame-ancestors "+ancestors+"; object-src 'none'; base-uri 'none'")
    def file(self,path,attachment=False,embed=False):
        try: body=path.read_bytes()
        except OSError: self.respond({'error':'文件不存在'},404); return
        self.send_response(200); self.security_headers(embed)
        self.send_header('Content-Type',mimetypes.guess_type(path.name)[0] or 'application/octet-stream')
        self.send_header('Content-Length',str(len(body)))
        if attachment: self.send_header('Content-Disposition','attachment')
        self.end_headers(); self.wfile.write(body)
    def do_GET(self):
        if not self.host_ok(): self.respond({'error':'仅允许本机访问'},403); return
        path=unquote(urlparse(self.path).path)
        capability=getattr(self.server,'private_evaluation_capability',None)
        if capability and capability.probe and path!='/health':
            self.respond({'error':'安装探测只允许读取健康状态'},403);return
        if (getattr(self.server,'update_startup_pending',False)
                and path not in ('/health','/workspace','/assistant','/assistant-ui.js',
                                 '/assistant-ui.css','/gsap.min.js')
                and not path.startswith('/assets/')):
            self.respond({'error':'客户端正在完成更新启动检查，请稍后'},503);return
        if path=='/workspace':
            if not self.server.employee_workspace_mode:
                self.respond({'error':'本机员工工作台未启用'},404); return
            query=parse_qs(urlparse(self.path).query,keep_blank_values=True)
            if any(key!='asset' for key in query) or len(query.get('asset',['']))!=1:
                self.respond({'error':'页面资源不存在'},404); return
            try:
                name=query.get('asset',[''])[0]
                if self.server.self_operating_read and name=='app.mjs':
                    body,content_type=(ROOT/'web/workspace/self-operating-read.mjs').read_bytes(),'text/javascript; charset=utf-8'
                else:body,content_type=local_workspace.asset(self.server,name)
            except local_workspace.WorkspaceError as ex:
                self.respond({'error':str(ex)},ex.status);return
            self.send_response(200);self.security_headers(workspace=True)
            self.send_header('Content-Type',content_type)
            self.send_header('Content-Length',str(len(body)))
            self.end_headers();self.wfile.write(body);return
        if path in ('/assistant','/assistant-ui.js','/assistant-ui.css','/gsap.min.js'):
            if not getattr(self.server,'assistant_service',None):self.respond({'error':'助手模式未启动'},404);return
            self.file(ROOT/'web'/('assistant.html' if path=='/assistant' else path[1:]));return
        if path.startswith('/assets/'):
            name=path[len('/assets/'):]
            if not name or '/' in name or '\\' in name or ':' in name or (Path(name).suffix.lower() not in {'.png','.webp'} and not re.fullmatch(r'platform-[a-z]+\.svg',name)):
                self.respond({'error':'图片路径无效'},403);return
            base=(ROOT/'web/assets').resolve();target=(base/name).resolve()
            if target.parent!=base:self.respond({'error':'图片路径无效'},403);return
            self.file(replacement_asset(self.server.customization_dir,self.server.ui_customization,name) or target);return
        if path.startswith('/saved-avatar/'):
            if not self.server.employee_workspace_mode:
                self.respond({'error':'头像不可用'},404);return
            user=self.user()
            if not user:
                self.respond({'error':'请先登录'},401);return
            try:
                local_workspace.require_owner(self.server,user)
            except local_workspace.WorkspaceError:
                self.respond({'error':'头像不可访问'},403);return
            query=parse_qs(urlparse(self.path).query,keep_blank_values=True)
            if set(query)!={'kind'} or len(query['kind'])!=1:
                self.respond({'error':'头像不可用'},404);return
            try:
                body,content_type=saved_media.saved_avatar(
                    self.server.core,user,path[len('/saved-avatar/'):],query['kind'][0])
            except saved_media.MediaForbidden:
                self.respond({'error':'头像不可访问'},403);return
            except saved_media.MediaUnavailable:
                self.respond({'error':'头像不可用'},404);return
            latest_user=self.user()
            if (not latest_user or latest_user.get('id')!=user.get('id')
                    or latest_user.get('tenant_id')!=user.get('tenant_id')
                    or latest_user.get('username')!=user.get('username')):
                self.respond({'error':'头像不可访问'},403);return
            try:
                local_workspace.require_owner(self.server,latest_user)
            except local_workspace.WorkspaceError:
                self.respond({'error':'头像不可访问'},403);return
            self.send_response(200);self.security_headers(workspace=True)
            self.send_header('Content-Type',content_type)
            self.send_header('Content-Length',str(len(body)))
            self.end_headers();self.wfile.write(body);return
        if path in ('/','/index.html','/app.js','/style.css','/frontdesk-ui.js','/frontdesk.css','/reference-flow.js','/reference-match.css', '/ui-components.js', '/ui-components.css', '/ui-workspace.js', '/ui-customization.js', '/customer-workspace.css', '/customer-workspace.js', '/customer-login.js', '/customer-start.js', '/vendor/motion-13.4.0.js'):
            if path in ('/','/index.html') and self.server.employee_workspace_mode:
                self.send_response(302);self.security_headers()
                self.send_header('Location','/workspace');self.end_headers();return
            if path in ('/','/index.html') and getattr(self.server,'assistant_service',None):
                location=self.server.company.get('managedWorkspace',{}).get('endpoint','')
                if location:
                    self.send_response(302); self.send_header('Location',location); self.end_headers(); return
            if self.assistant_only():
                self.respond({'error':'本地运营页面不在助手包中提供'},404); return
            self.file(ROOT/'web'/('index.html' if path=='/' else path[1:])); return
        if path=='/health': self.respond({'app':'local-lead-workspace','version':self.server.company.get('releaseVersion','unknown')}); return
        if path.startswith('/owner-login-qr/') and self.server.self_operating_read:
            try:
                data=self.server._self_operating_reads._login.qr(self.token(),path.rsplit('/',1)[1])
            except CoreError:
                self.respond({'error':'本次二维码尚不可用或本人会话已变化'},404);return
            self.send_response(200);self.security_headers();self.send_header('Content-Type','image/png')
            self.send_header('Cache-Control','no-store');self.send_header('Content-Length',str(len(data)))
            self.end_headers();self.wfile.write(data);return
        if path.startswith('/assistant-qr/'):
            # The assistant has a device pairing, not a local web login cookie.
            # Only the running assistant's unguessable login job can serve a QR.
            assistant=getattr(self.server,'assistant_service',None)
            if self.server.employee_workspace_mode:
                user=self.user()
                try:local_workspace.require_owner(self.server,user) if user else None
                except local_workspace.WorkspaceError:user=None
                if not user:self.respond({'error':'请先从员工工作台登录'},401);return
            job=self.server.jobs.get(path.rsplit('/',1)[1]) if assistant else None
            if not job or job.get('kind')!='assistant_account_login' or job.get('status')!='running' or not job.get('qr_path'):
                self.respond({'error':'二维码尚未生成'},404); return
            self.file(Path(job['qr_path'])); return
        if not self.user(): self.respond({'error':'请先登录'},401); return
        if path.startswith('/references/'):
            filename=Path(path).name
            self.file(ROOT/'resources'/'references'/filename); return
        if path.startswith('/qr/'):
            job=self.server.jobs.get(path.rsplit('/',1)[1])
            if not job or job.get('user_id')!=self.user()['id'] or not job.get('qr_path'):
                self.respond({'error':'二维码尚未生成'},404); return
            self.file(Path(job['qr_path'])); return
        if path.startswith('/asset/'):
            asset_id=path.rsplit('/',1)[1]
            asset=next((x for x in self.server.core.handle('list',{'entity':'assets'},self.user()) if x['id']==asset_id),None)
            if not asset: self.respond({'error':'文件不存在'},404); return
            target=Path(asset['path']).resolve()
            if not target.is_relative_to((self.server.core.store.directory/'assets').resolve()): self.respond({'error':'无权访问该路径'},403); return
            self.file(target, target.suffix.lower() not in {'.png','.jpg','.jpeg','.webp','.pdf'},embed=target.suffix.lower()=='.pdf'); return
        if path=='/help':
            personal=self.server.company.get('edition')=='owner' and self.server.company.get('personalMode') is True
            self.file(ROOT/'resources'/('help-personal.html' if personal else 'help.html'),embed=True); return
        if path=='/bridge-script':
            user=self.user()
            if user['role']!='admin': self.respond({'error':'需要管理员权限'},403); return
            platform=parse_qs(urlparse(self.path).query).get('platform',['douyin'])[0]
            try:manager=self.server.bridge_for(platform)
            except CoreError as ex:self.respond({'error':str(ex)},400);return
            filename='工作台_快手连接.user.js' if platform=='kuaishou' else '工作台_抖音连接.user.js'
            self.file(manager.root(user['tenant_id'])/filename,True); return
        self.respond({'error':'页面不存在'},404)
    def do_POST(self):
        if not self.host_ok() or self.path!='/api': self.respond({'error':'不允许的请求'},403); return
        if getattr(self.server,'update_startup_pending',False):
            gate=getattr(self.server,'update_startup_gate',None)
            if (gate is None or not gate.wait(4) or self.server.closing
                    or self.server.update_startup_pending):
                self.respond({'error':'客户端正在完成更新启动检查，请稍后'},503);return
        origin=self.headers.get('Origin')
        if origin and origin not in ('http://127.0.0.1:'+str(self.server.server_port),'http://localhost:'+str(self.server.server_port)):
            self.respond({'error':'不允许跨站请求'},403); return
        if self.headers.get('X-Local-App')!='1' or not self.headers.get('Content-Type','').startswith('application/json'):
            self.respond({'error':'请求格式错误'},403); return
        try:
            length=int(self.headers.get('Content-Length','0'))
            if length<=0 or length>29*1024*1024: raise CoreError('请求大小超出限制')
            payload=json.loads(self.rfile.read(length)); action=payload.get('action'); data=payload.get('data') or {}
            if not isinstance(data,dict): raise CoreError('请求参数格式错误')
            capability=getattr(self.server,'private_evaluation_capability',None)
            if capability and capability.probe and action!='assistant_status':
                self.respond({'error':'安装探测只允许读取未绑定状态'},403);return
            core=self.server.core
            if self.server.self_operating_read and action not in ('personal_enter','me','status','logout','desktop_workspace'):
                raise CoreError('自营只读试点不启动采集任务、AI、联系或发送')
            if self.server.self_operating_read and action=='personal_enter' and (not origin or data):
                raise CoreError('本人进入须由本机页面明确确认，不接受身份参数')
            if self.server.closing:raise CoreError('软件正在退出，请重新打开后操作')
            if action in ('tracked_reply_start','tracked_reply_status'):
                if (not self.server.employee_workspace_mode or not origin or length>8192):
                    self.respond({'error':'受控网页回复仅限本机员工工作台'},403);return
                user=self.user()
                if not user:
                    self.respond({'error':'请先登录员工工作台'},401);return
                from assistant.tracked_reply_service import TrackedReplyService
                with self.server.job_lock:
                    service=getattr(self.server,'tracked_reply_service',None)
                    if service is None:
                        service=TrackedReplyService(self.server)
                        self.server.tracked_reply_service=service
                if action=='tracked_reply_start':
                    self.respond(service.start(user,data));return
                if set(data)!={'job_id'}:
                    raise CoreError('网页回复状态参数无效')
                self.respond(service.status(user,data['job_id']));return
            if action=='desktop_workspace':
                if not self.server.employee_workspace_mode:
                    self.respond({'error':'本机员工工作台未启用'},404);return
                if (not origin or length>2*1024*1024 or
                        self.headers.get('Content-Type','').split(';',1)[0].strip().lower()!='application/json'):
                    self.respond({'error':'请求来源或大小无效'},403);return
                operation=data.get('operation')
                fields={key:value for key,value in data.items() if key!='operation'}
                if self.server.self_operating_read:
                    identity=local_workspace.identity(self.server)
                    if operation=='me':
                        user=self.server._self_operating_reads._actor(self.token())
                        self.respond({**identity,'user':core._public(user)});return
                    from assistant.platform_receipt_archive import ReceiptArchiveError
                    from assistant.source_intent_analysis import SourceIntentError
                    from assistant.self_operating_acquisition import OwnerAcquisitionError
                    if operation=='product_action' and fields.get('action') in ('keyword_recommend','keyword_library','keyword_state','owner_keyword_attempt_status'):
                        from assistant.owner_keyword_workflow import OwnerKeywordError
                        try:result=self.server._self_operating_reads.dispatch(self.token(),operation,fields)
                        except Exception as error:
                            committed=getattr(error,'mutation_committed',None) if isinstance(error,OwnerKeywordError) else None
                            if committed is not True and committed is not False:committed=None
                            safe={'error':'原关键词操作需要核对；保留原编号，不自动建议或保存。',
                                  'code':'OWNER_KEYWORD_REVIEW','mutation_committed':committed,'auto_retry':False}
                            if isinstance(error,OwnerKeywordError):
                                request=getattr(error,'request_id',None);submission=getattr(error,'submission_id',None)
                                if (type(request) is str and type(submission) is str
                                    and re.fullmatch(r'[0-9a-fA-F-]{36}',request) and re.fullmatch(r'[0-9a-fA-F-]{36}',submission)
                                    and getattr(error,'operation_kind',None)=='keyword_suggest'
                                    and getattr(error,'state',None) in ('prepared','submitted','unknown','not_dispatched','response_received','validated')):
                                    safe.update(request_id=request,submission_id=submission,operation_kind='keyword_suggest',state=error.state)
                            self.respond(safe,500 if committed is None else 400);return
                        self.respond({**identity,**result});return
                    try:result=self.server._self_operating_reads.dispatch(self.token(),operation,fields)
                    except ReceiptArchiveError as error:
                        self.respond({'error':str(error),'code':error.code,
                                      'mutation_committed':error.mutation_committed,'auto_retry':False},
                                     500 if error.mutation_committed is None else 400);return
                    except SourceIntentError as error:
                        self.respond({'error':str(error),'code':'SOURCE_INTENT_REVIEW',
                                      'mutation_committed':error.mutation_committed,'auto_retry':False},
                                     500 if error.mutation_committed is None else 400);return
                    except OwnerAcquisitionError as error:
                        self.respond({'error':str(error),'code':'OWNER_ACQUISITION_REVIEW',
                                      'mutation_committed':error.mutation_committed,'auto_retry':False},
                                     500 if error.mutation_committed is None else 400);return
                    if operation=='product_action' and fields.get('action')=='owner_handoff_package_download':
                        from assistant.owner_contact_handoff_package import _OwnerHandoffPackageDownload
                        if (type(result) is not dict or set(result)!={'result'}
                                or type(result['result']) is not _OwnerHandoffPackageDownload):
                            raise CoreError('人工交接资料包下载来源无法核对')
                        try:result['result'].emit(self)
                        except OwnerAcquisitionError as error:
                            self.respond({'error':str(error),'code':'OWNER_ACQUISITION_REVIEW',
                                          'mutation_committed':error.mutation_committed,'auto_retry':False},
                                         500 if error.mutation_committed is None else 400)
                        return
                    self.respond({**identity,**result});return
                if operation=='development_reauth':
                    if not getattr(self.server,'development_workspace',False):
                        self.respond({'error':'开发员工会话恢复未启用'},403);return
                    if set(fields)!={'password'}:
                        self.respond({'error':'员工会话恢复参数无效'},403);return
                    try:result=dev_workspace.reauth(self.server,fields['password'])
                    except local_workspace.WorkspaceError as ex:
                        self.respond({'error':str(ex)},ex.status);return
                    self.respond({**local_workspace.identity(self.server),
                                  **local_workspace.public(result),
                                  'development_local_only':False});return
                if operation=='login':
                    if getattr(self.server,'development_workspace',False):
                        self.respond({'error':'开发工作台仅限已绑定员工；退出后请完整关闭并重新打开，切换账号请使用正式登录模式'},403)
                        return
                    key='workspace:'+self.client_address[0]
                    failures=[x for x in self.server.failures.get(key,[]) if time.time()-x<300]
                    if len(failures)>=8:raise local_workspace.WorkspaceError('登录尝试过多，请稍后重试',429)
                    try:result=self.server.integrations.enter(fields,employee_only=True)
                    except EmployeeLoginRequired as ex:
                        self.respond({'error':str(ex),'code':'ADMIN_WORKSPACE_ONLY'},403);return
                    except (IntegrationError,ValueError):
                        self.server.failures[key]=failures+[time.time()];raise
                    self.server.failures.pop(key,None)
                    token=result.pop('token')
                    cookie_max_age=result.pop('cookie_max_age',None)
                    self.respond({**local_workspace.identity(self.server),**local_workspace.public(result)},
                                 cookie=token,persistent=True,cookie_max_age=cookie_max_age);return
                try:
                    user=self.user()
                    result=local_workspace.gateway(self.server,user,operation,fields,self.token())
                except local_workspace.WorkspaceError as ex:
                    self.respond({'error':str(ex),'mutation_committed':ex.mutation_committed},ex.status);return
                if operation=='logout':
                    self.respond({**local_workspace.identity(self.server),**result,
                                  **({'error':'本机已退出；云端注销未确认，请管理员核对设备会话'}
                                     if result.get('remote_revoked') is False else {})},
                                 code=503 if result.get('remote_revoked') is False else 200,
                                 cookie='');return
                self.respond({**local_workspace.identity(self.server),**result,
                              'development_local_only':bool(user and user.get('development_local_only'))});return
            if action in ('assistant_manual_permission_snapshot','assistant_status','assistant_bind','assistant_replace_pair','assistant_workspace_state','assistant_account_login','assistant_account_identity_observe','assistant_account_slot_create','assistant_new_account_login','assistant_account_delete','assistant_job_status','assistant_account_safety','assistant_account_signal','assistant_cancel_login','assistant_bilibili_setup_observe','assistant_bilibili_setup_confirm','assistant_bilibili_setup_status','assistant_bilibili_setup_cancel','assistant_douyin_connection_start','assistant_douyin_connection_status','assistant_wechat_preview_configure','assistant_wechat_preview_check'):
                assistant=getattr(self.server,'assistant_service',None)
                if not assistant:raise CoreError('请从本地助手入口打开')
                if action=='assistant_account_slot_create' and not self.server.employee_workspace_mode:
                    self.respond({'error':'账号记录仅允许本人已连接的员工工作台创建'},403);return
                if self.server.employee_workspace_mode:
                    if action=='assistant_status':
                        user=self.user()
                        status=assistant.status()
                        if not user:
                            status={'state':status['state'],'local_workspace':True,
                                    'workspace_url':'/workspace'}
                        else:
                            try:local_workspace.require_owner(self.server,user)
                            except local_workspace.WorkspaceError:
                                status={'state':status['state'],'local_workspace':True,
                                        'workspace_url':'/workspace'}
                            else:status={**status,'local_workspace':True,'workspace_url':'/workspace'}
                        self.respond(status);return
                    if action in ('assistant_bind','assistant_replace_pair'):
                        self.respond({'error':'请从员工工作台连接本机'},403);return
                    user=self.user()
                    if not user:
                        self.respond({'error':'请先从员工工作台登录'},401);return
                    try:local_workspace.require_owner(self.server,user)
                    except local_workspace.WorkspaceError as ex:
                        self.respond({'error':str(ex)},ex.status);return
                if getattr(self.server,'manual_owned_read_start',False):
                    if action=='assistant_manual_permission_snapshot':
                        if data:raise CoreError('权限快照核对不接受额外参数')
                        self.respond(assistant.manual_permission_snapshot());return
                    if action not in ('assistant_status','assistant_workspace_state','assistant_account_safety'):
                        self.respond({'error':'手动工作台仅可查看原记录，平台许可未确认','code':'manual_authority_pending'},403);return
                if action=='assistant_manual_permission_snapshot':raise CoreError('请从手动工作台入口核对权限快照')
                if action=='assistant_status':self.respond(assistant.status());return
                if action=='assistant_workspace_state':self.respond(assistant.workspace_state());return
                if action in ('assistant_wechat_preview_configure','assistant_wechat_preview_check'):
                    if not self.server.employee_workspace_mode:
                        self.respond({'error':'视频号预览仅允许本人本机员工工作台'},403);return
                    try:result=assistant.wechat_preview(action.removeprefix('assistant_wechat_preview_'),data)
                    except Exception:
                        self.respond({'purpose':'wechat_channels_single_session_preview','auto_retry':False,
                            'lookup_required':True,'error':'本次连接结果未确认，请只检查原账号；不会自动重试'},400);return
                    self.respond(result);return
                if action in ('assistant_douyin_connection_start','assistant_douyin_connection_status'):
                    if not self.server.employee_workspace_mode:
                        self.respond({'error':'抖音本人连接仅允许原本机员工工作台'},403);return
                    try:result=assistant.douyin_connection(action.removeprefix('assistant_douyin_connection_'),data)
                    except Exception:
                        # A window or DB write can precede an uncertain reply.
                        # Never echo bridge errors, URLs, tokens or paths.
                        self.respond({'error':'抖音本次连接结果未确认，请只检查原账号状态；不会自动重试'},400);return
                    self.respond(result);return
                if action.startswith('assistant_bilibili_setup_'):
                    if not self.server.employee_workspace_mode:
                        self.respond({'error':'B站本人配置仅允许原本机员工工作台'},403);return
                    operation=action.removeprefix('assistant_bilibili_setup_')
                    try:
                        if length>72*1024:raise ValueError('B站本人配置请求超出固定大小')
                        result=assistant.bilibili_setup(operation,data)
                    except Exception:
                        # Never log the credential-bearing request or an
                        # untrusted exception. Only the original ID is echoed.
                        lookup={key:data[key] for key in ('account_id','setup_id')
                            if type(data.get(key)) is str and re.fullmatch(
                                r'[A-Za-z0-9_-]{1,160}' if key=='account_id' else r'[0-9a-f]{32}',data[key])}
                        self.respond({'purpose':'owned_credential_setup',**lookup,'auto_retry':False,
                            'lookup_required':True,'error':'B站本次配置结果未确认，请核对或取消原编号；不会自动重试'},400);return
                    self.respond(result);return
                if action=='assistant_account_slot_create':
                    try:result=assistant.create_account_slot(data)
                    except (CoreError,ValueError,TypeError) as exc:
                        self.respond({'purpose':'account_slot_create','status':'rejected','error':str(exc),
                            'mutation_committed':False,'auto_retry':False,'refresh_required':False},400);return
                    self.respond(result,500 if result.get('status')=='outcome_unknown' else 200);return
                if action=='assistant_account_identity_observe':
                    if (set(data)!={'account_id'} or not isinstance(data['account_id'],str)
                            or re.fullmatch(r'[A-Za-z0-9_-]{1,160}',data['account_id']) is None):
                        raise ValueError('身份观测只接受本人的原账号编号')
                    self.respond(assistant.start_account_identity_observation(data['account_id']));return
                if action=='assistant_account_login':self.respond(assistant.start_account_login(data.get('account_id')));return
                if action=='assistant_new_account_login':self.respond(assistant.start_new_account_login());return
                if action=='assistant_cancel_login':self.respond(assistant.cancel_account_login(data.get('job_id')));return
                if action=='assistant_account_delete':self.respond(assistant.delete_account(data.get('account_id')));return
                if action=='assistant_job_status':self.respond(assistant.account_job_status(data.get('job_id')));return
                if action=='assistant_account_safety':self.respond(assistant.account_safety_status(data.get('account_id')));return
                if action=='assistant_account_signal':self.respond(assistant.record_account_signal(data.get('account_id'),data.get('kind'),data.get('revision')));return
                try:self.respond((assistant.replace_pending if action=='assistant_replace_pair' else assistant.bind)(data.get('code','')))
                except ValueError:raise
                except Exception:raise CoreError('连接企业服务失败，请检查网络后使用同一配对码重试') from None
                return
            if self.assistant_only():
                raise CoreError('本地助手仅处理网页工作台下达的任务')
            user=self.user()
            if action=='cloud_enter' or (action=='login' and self.server.company.get('authMode')=='managed'):
                key='cloud:'+self.client_address[0]
                failures=[x for x in self.server.failures.get(key,[]) if time.time()-x<300]
                if len(failures)>=8:raise CoreError('登录尝试过多，请 5 分钟后重试')
                try:result=self.server.integrations.enter(data)
                except (IntegrationError,ValueError):
                    self.server.failures[key]=failures+[time.time()];raise
                self.server.failures.pop(key,None)
                token=result.pop('token');self.respond(result,cookie=token);return
            if action=='save' and data.get('entity')=='users':
                target=core.store.get('users',(data.get('record') or {}).get('id',''))
                if target and target.get('cloud_bound'):raise CoreError('云端成员请在云端团队管理中编辑')
            if action in ('integration_status','integration_save','keyword_suggest','cloud_login','cloud_logout','cloud_list','cloud_publish','cloud_members','cloud_member_save'):
                try:
                    result=self.server.integrations.handle(action,data,user)
                except IntegrationError as ex:
                    raise CoreError(str(ex)) from None
                self.respond(result);return
            if action=='me': self.respond({'user':user}); return
            if action=='personal_enter':
                result=core.handle(action,data)
                token=result.pop('token');self.respond(result,cookie=token);return
            if action=='status':
                self.respond({**core.handle('status'),'company':{'authMode':self.server.company.get('authMode','local'),'id':self.server.company['id'],'name':self.server.company['name'],'industry':self.server.company.get('industry','apartment'),'platform':self.server.company.get('platform','xiaohongshu'),'theme':self.server.company.get('theme',{}),'personalMode':self.server.company.get('edition')=='owner' and self.server.company.get('personalMode') is True,'shortName':self.server.company.get('shortName',''),'uiCustomization':self.server.ui_customization,'uiAssets':{k:self.server.company.get('uiAssets',{}).get(k,'') for k in ('logo','loginImage','loginWatermark')}}}); return
            if action=='shutdown':
                if not user or user['role']!='admin': raise CoreError('需要管理员权限')
                with self.server.job_lock:self.server.closing=True
                self.respond({'ok':True})
                def stop():
                    try:self.server.close_owned_jobs()
                    finally:self.server.shutdown()
                threading.Thread(target=stop,daemon=True).start(); return
            if action=='login':
                key=self.client_address[0]; failures=self.server.failures.get(key,[])
                failures=[x for x in failures if time.time()-x<300]
                if len(failures)>=10: raise CoreError('登录尝试过多，请 5 分钟后重试')
                try: result=core.handle(action,data)
                except CoreError: self.server.failures[key]=failures+[time.time()]; raise
                self.server.failures.pop(key,None); token=result.pop('token'); self.respond(result,cookie=token); return
            if action=='bootstrap':
                if self.server.company.get('authMode')=='managed':raise CoreError('员工账号由老板或管理员分配，不支持自行注册')
                result=core.handle(action,data); self.seed(result['user']); token=result.pop('token'); self.respond(result,cookie=token); return
            if action=='logout':
                core.handle('logout',{'token':self.token()},user); self.respond({'ok':True},cookie=''); return
            if action=='upload_asset':
                if not user: raise CoreError('请先登录')
                name=Path(str(data.get('name','')).replace('\\','/')).name
                suffix=Path(name).suffix.lower()
                if suffix not in ALLOWED_ASSETS: raise CoreError('不支持的文件格式')
                raw=base64.b64decode(data.get('base64',''),validate=True)
                if len(raw)>20*1024*1024: raise CoreError('单个文件不得超过 20 MB')
                directory=core.store.directory/'assets'/user['tenant_id']; directory.mkdir(parents=True,exist_ok=True)
                target=directory/(secrets.token_hex(12)+suffix); target.write_bytes(raw)
                result=core.handle('save',{'entity':'assets','record':{'name':name,'path':str(target),'kind':data.get('kind','内部资料')}},user)
                self.respond(result); return
            if action=='diagnostics':
                if not user or user['role']!='admin': raise CoreError('需要管理员权限')
                self.respond({'platforms':[{k:v for k,v in p.items() if k in ('id','name','version','status','available','search_verified','description','verification_level')} for p in core._platforms()],'data_directory':str(core.store.directory),'paid_services':'未接入','host':'仅监听 127.0.0.1'}); return
            if action=='open_backup_folder':
                if not user or user['role']!='admin':raise CoreError('需要管理员权限')
                directory=core.store.directory/'backups';directory.mkdir(exist_ok=True)
                os.startfile(str(directory));self.respond({'path':str(directory)});return
            if action=='account_delete' or (action=='delete' and data.get('entity')=='accounts'):
                core.handle('account_delete_context',data,user)
                with self.server.job_lock:
                    if any(j.get('account_id')==data.get('id') and j.get('status')=='running' and j.get('kind')!='account_login' for j in self.server.jobs.values()):
                        raise CoreError('这个账号正在连接或登录，请等待完成后再删除')
                    connection_lock=self.server.account_connections.locks.setdefault(data.get('id'),threading.Lock())
                    if not connection_lock.acquire(False):raise CoreError('正在检查这个账号，请稍后再删除')
                    try:
                        for pending in self.server.jobs.values():
                            if pending.get('account_id')==data.get('id') and pending.get('kind')=='account_login' and pending.get('status')=='running':
                                pending.update(status='cancelled',error='账号已移除，扫码登录已取消')
                                process=pending.get('process')
                                if process and process.poll() is None:
                                    process.terminate()
                                    try:process.wait(timeout=3)
                                    except subprocess.TimeoutExpired:process.kill();process.wait(timeout=3)
                        result=core.handle('account_delete',data,user)
                        self.server.account_connections.release_account(data.get('id'))
                    finally:connection_lock.release()
                self.respond(result);return
            if action in ('wechat_channels_status','wechat_channels_configure','wechat_channels_open_folder','wechat_channels_launch'):
                context=core.handle('account_browser_context',data,user)
                if context['account']['platform']!='wechat_channels':raise CoreError('请选择视频号连接账号')
                method={'wechat_channels_status':'status','wechat_channels_configure':'configure','wechat_channels_open_folder':'open_folder','wechat_channels_launch':'launch'}[action]
                if method=='status':result=self.server.wechat_channels.status(user,data)
                else:
                    with self.server.job_lock:result=getattr(self.server.wechat_channels,method)(user,data)
                self.respond(result);return
            if action=='account_connection_status':
                context=core.handle('account_browser_context',data,user)
                if context['account']['platform']=='wechat_channels':
                    self.respond(self.server.wechat_channels.status(user,data));return
                self.respond(self.server.account_connections.status(user,data.get('id')));return
            if action=='account_connect':
                context=core.handle('account_browser_context',data,user)
                if context['account']['platform']=='wechat_channels':
                    self.respond(self.server.wechat_channels.status(user,data));return
                with self.server.job_lock:
                    if self.server.closing:raise CoreError('软件正在退出')
                    core.handle('account_browser_context',data,user)
                    for pending in self.server.jobs.values():
                        if pending.get('kind')=='account_connect' and pending.get('account_id')==data.get('id') and pending.get('status')=='running':
                            if pending['user_id']!=user['id']:raise CoreError('另一位员工正在连接此账号，请稍后')
                            self.respond({'job_id':pending['id']});return
                    job_id=secrets.token_hex(12)
                    job={'id':job_id,'kind':'account_connect','account_id':data.get('id'),'status':'running','user_id':user['id']}
                    self.server.jobs[job_id]=job
                def connect_run():
                    try:
                        job['result']=self.server.account_connections.connect(user,data.get('id'),data.get('mode','auto'))
                        job['status']='completed'
                    except Exception as exc:
                        job['result']={'status':'failed','step':'failed','message':str(exc),'next_action':'重试连接'}
                        job['error']=str(exc);job['status']='failed'
                        self.server.account_connections.persist(data.get('id'),status='unverified',connection_message=str(exc))
                threading.Thread(target=connect_run,daemon=True).start()
                self.respond({'job_id':job_id});return
            if action=='account_check':
                context=core.handle('account_browser_context',data,user)
                if context['account']['platform']=='wechat_channels':
                    self.respond(self.server.wechat_channels.status(user,data));return
                if context['account']['platform'] in ('douyin','kuaishou'):
                    state=self.server.account_connections.status(user,data.get('id'),force=True)
                    self.respond({**state,'verified':state['status']=='ready','authenticated':state['status']=='ready','connected':state['status'] in ('ready','waiting_login','connected_unverified'),'account':core.store.get('accounts',data.get('id'))});return
            if action=='account_browser_open':
                context=core.handle('account_browser_context',data,user)
                with self.server.job_lock:
                    if self.server.closing: raise CoreError('软件正在退出')
                    context=core.handle('account_browser_context',data,user)
                    self.server.bridge_for(context['account']['platform']).start(context['tenant'])
                    result=open_account_browser(core.store.directory,context['tenant'],context['account'])
                self.respond(result);return
            if action=='account_extension_folder':
                context=core.handle('account_browser_context',data,user)
                if context['account']['platform']!='zhihu':raise CoreError('此平台不使用知乎连接扩展')
                directory=self.server.opencli.runtime/'extension'
                if not (directory/'manifest.json').is_file():raise CoreError('扩展文件尚未装配')
                os.startfile(str(directory))
                self.respond({'path':str(directory),'message':'已打开扩展文件夹。请在此账号浏览器的扩展管理页开启开发者模式，选择“加载已解压的扩展程序”，选择这个文件夹。'});return
            if action=='account_attach_existing':
                if not user or user['role']!='admin':raise CoreError('需要管理员权限')
                context=core.handle('account_browser_context',data,user)
                if context['account']['platform']!='douyin':raise CoreError('当前仅支持复用已有抖音连接')
                with self.server.job_lock,core.lock:
                    if core.running or core.sequences:raise CoreError('请先停止采集任务，再切换连接')
                    configured=self.server.company.get('localCliPaths',{}).get('douyin')
                    if not configured:raise CoreError('此实例尚未配置现有抖音CLI位置，请使用首次连接设置')
                    source=Path(configured).resolve()
                    if not source.is_file():raise CoreError('没有找到原有抖音CLI配置，请联系管理员设置现有CLI位置')
                    result=self.server.bridge.attach_existing(context['tenant'],source,start_if_needed=True)
                self.respond(result);return
            if action=='account_connection_state':
                context=core.handle('account_browser_context',data,user)
                account=context['account']
                manager=self.server.bridge_for(account['platform'])
                # Do not start a service merely by viewing its state.
                if account['platform']=='zhihu':
                    try:running=manager.status()['state']!='stopped'
                    except OpenCLIBridgeError as exc:
                        self.respond({'running':False,'connections':[],'bound':None,'account_status':account.get('status','unverified'),'connection_error':str(exc)});return
                else:
                    proc=manager.processes.get(context['tenant'])
                    running=bool(proc and proc.poll() is None) or (account['platform']=='douyin' and manager.external(context['tenant']))
                try:connections=manager.connections(context['tenant']) if running else []
                except (ValueError,subprocess.TimeoutExpired):
                    self.respond({'running':False,'connections':[],'bound':None,'mode':'existing' if account['platform']=='douyin' and manager.external(context['tenant']) else 'private','account_status':account.get('status','unverified'),'connection_error':'连接服务暂时不可用，请重新连接；不会自动采集或回复。'});return
                assigned={x.get('conn_id') for x in core.handle('list',{'entity':'accounts'},user)
                          if x.get('platform')==account['platform'] and x['id']!=account['id']}
                available=[x for x in connections if x.get('alive') and x.get('id') not in assigned]
                bound=next((x for x in available if x.get('id')==account.get('conn_id')),None)
                self.respond({'running':running,'connections':available,'bound':bound,'mode':'existing' if account['platform']=='douyin' and manager.external(context['tenant']) else 'private',
                              'account_status':account.get('status','unverified')});return
            if action=='account_bind_connection':
                context=core.handle('account_browser_context',data,user)
                account=context['account']
                connections=self.server.bridge_for(account['platform']).connections(context['tenant'])
                connection=next((x for x in connections if x.get('id')==data.get('conn_id') and x.get('alive')),None)
                if not connection: raise CoreError('所选窗口已断开，请刷新连接列表')
                record={**account,'conn_id':connection['id'],'status':'unverified'}
                result=core.handle('save',{'entity':'accounts','record':record},user)
                self.respond(result);return
            if action in ('bridge_start','bridge_connections'):
                if not user or user['role']!='admin': raise CoreError('需要管理员权限')
                core.require_platform(data.get('platform','douyin'))
                manager=self.server.bridge_for(data.get('platform','douyin'))
                with self.server.job_lock:
                    if self.server.closing:raise CoreError('软件正在退出')
                    result=manager.start(user['tenant_id']) if action=='bridge_start' else manager.connections(user['tenant_id'])
                self.respond(result);return
            if action=='job_status':
                if not user: raise CoreError('请先登录')
                job=self.server.jobs.get(data.get('id'))
                if not job or job['user_id']!=user['id']: raise CoreError('任务不存在')
                visible={k:v for k,v in job.items() if k not in ('qr_path','process')}
                if job.get('kind')=='account_login':
                    qr=Path(job.get('qr_path',''))
                    visible['qr_ready']=qr.is_file() and qr.stat().st_size>32
                self.respond(visible); return
            if action=='account_login_cancel':
                core.handle('account_browser_context',data,user)
                with self.server.job_lock:
                    for pending in self.server.jobs.values():
                        if pending.get('kind')=='account_login' and pending.get('account_id')==data.get('id') and pending.get('status')=='running':
                            if pending.get('user_id')!=user['id']:raise CoreError('该账号正在由另一位管理员登录')
                            pending.update(status='cancelled',error='已取消本次扫码登录')
                            proc=pending.get('process')
                            if proc and proc.poll() is None:proc.terminate()
                    with core.lock:
                        account=core._get('accounts',data.get('id'),user['tenant_id'])
                        if account.get('status')=='logging_in':
                            account['status']='login_required';core.store.put('accounts',account)
                self.respond({'ok':True});return
            if action=='account_login':
                with self.server.job_lock:
                    spec=None
                    for pending in self.server.jobs.values():
                        if pending.get('kind')=='account_login' and pending.get('account_id')==data.get('id') and pending.get('status')=='running':
                            if not user or pending['user_id']!=user['id']: raise CoreError('该账号正在由另一位管理员登录，请稍后再试')
                            self.respond({'login_job':pending['id']});return
                    spec=core.handle('account_login_spec',data,user)
                    job_id=secrets.token_hex(12)
                    qr_dir=core.store.directory/'work'; qr_dir.mkdir(exist_ok=True)
                    qr_path=qr_dir/(job_id+'.png')
                    job={'id':job_id,'kind':'account_login','account_id':data['id'],'status':'running','user_id':user['id'],'qr_path':str(qr_path)}
                    self.server.jobs[job_id]=job
                def login_run():
                    try:
                        with self.server.job_lock:
                            if self.server.closing:raise CoreError('软件正在退出')
                            if job['status']=='cancelled':return
                            core.handle('account_browser_context',data,user)
                            core.adapters._guard_platform('xiaohongshu')
                            proc=subprocess.Popen(spec['argv'],env={**os.environ,**spec['env'],'WORKSPACE_QR_PATH':str(qr_path)},cwd=spec['cwd'],stdout=subprocess.PIPE,stderr=subprocess.PIPE,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
                            job['process']=proc
                        try: stdout,stderr=proc.communicate(timeout=240)
                        except subprocess.TimeoutExpired: proc.kill(); proc.communicate(); raise CoreError('扫码登录超时，请重试')
                        if proc.returncode:
                            # Never echo vendor output: it may contain QR URLs or credentials.
                            error_file=qr_path.with_suffix('.error.json')
                            if error_file.is_file():
                                raise CoreError('二维码生成或写入失败，请检查本项目数据目录权限后重新生成。')
                            raise CoreError('平台登录没有完成。请重新生成二维码；如反复失败，请检查网络或平台验证提示。')
                        with self.server.job_lock:
                            if job['status']=='cancelled':return
                            job.update(status='completed',result=core.handle('account_check',data,user))
                    except Exception as ex:
                        if job['status']=='cancelled':return
                        with core.lock:
                            account=core.store.get('accounts',data['id'])
                            if account and account.get('status')=='logging_in':
                                account['status']='login_required';core.store.put('accounts',account)
                        job.update(status='failed',error=str(ex))
                    finally: job.pop('process',None)
                threading.Thread(target=login_run,daemon=True).start(); self.respond({'login_job':job_id}); return
            if action in ('run_task','run_task_sequence','verify_adapter','account_check','send_reply','run_reply_queue','publish_content'):
                if not user: raise CoreError('请先登录')
                job_id=secrets.token_hex(12)
                job={'id':job_id,'status':'running','user_id':user['id'],'kind':action,'account_id':data.get('account_id') or (data.get('id') if action=='account_check' else None)}
                with self.server.job_lock:
                    if job.get('account_id'):core._get('accounts',job['account_id'],user['tenant_id'])
                    self.server.jobs[job_id]=job
                def run():
                    try:
                        if self.server.closing:raise CoreError('软件正在退出')
                        job.update(status='completed',result=core.handle(action,data,user))
                    except Exception as ex: job.update(status='failed',error=str(ex))
                threading.Thread(target=run,daemon=True).start(); self.respond({'job_id':job_id}); return
            result=core.handle(action,data,user); self.respond(result)
        except (CoreError,ValueError,TypeError,OpenCLIBridgeError) as ex: self.respond({'error':str(ex)},400)
        except Exception:
            logging.exception('request failed')
            self.respond({'error':'本地操作未完成，请查看工作台日志或联系管理员'},500)
    def seed(self,user):
        core=self.server.core
        config=self.server.company
        tenant=core.store.get('tenants',user['tenant_id'])
        tenant.update(industry=config.get('industry','公寓'),company_id=config.get('id'),business_rules=config,**config.get('profile',{}))
        core.handle('save',{'entity':'tenants','record':tenant},user)
        for template in config.get('templates',[]):
            core.handle('save',{'entity':'templates','record':{'name':template['name'],'text':template.get('content',template.get('text','')),'keywords':template.get('keywords',[])}},user)

def update_startup_health(server,*,serving=False):
    """Probe loopback on the existing desktop server or serve one preflight request."""
    handler=None
    if not serving:
        old_timeout=server.timeout
        server.timeout=3
        handler=threading.Thread(target=server.handle_request,name='update-startup-health',daemon=True)
        handler.start()
    try:
        with urllib.request.urlopen('http://127.0.0.1:'+str(server.server_port)+'/health',timeout=3) as response:
            state=json.load(response)
        if (response.status!=200 or state.get('app')!='local-lead-workspace'
                or state.get('version')!=server.company.get('releaseVersion','unknown')):
            raise ValueError('新版本本机健康接口未通过检查')
    finally:
        if handler:
            handler.join(timeout=4)
            server.timeout=old_timeout
    if handler and handler.is_alive():raise ValueError('新版本本机健康接口未正常完成')


def confirm_update_startup(server,release,*,serving=False,cancelled=None):
    """Complete only the stable launcher's provisional local startup transaction.

    Call after local server/Core initialization and before cloud workers start.
    This never downloads, installs, or rolls back a running application's data.
    """
    if release is None:return
    root=getattr(server,'install_root',None)
    if not root:raise ValueError('更新启动确认缺少固定安装目录')
    from assistant.update_coordinator import UpdateCoordinator,installed_executable
    executable=installed_executable(root,server.company['id'])
    coordinator=UpdateCoordinator(root,server.core.store.directory,server.company,executable=executable)
    if coordinator._active_release()!=release:
        raise ValueError('启动程序发布序号与固定入口不一致')
    if coordinator.journal_path.exists():
        if getattr(server,'closing',False) or callable(cancelled) and cancelled():
            raise ValueError('原生窗口已关闭，更新启动尚未确认')
        if serving:update_startup_health(server,serving=True)
        else:update_startup_health(server)
        if getattr(server,'closing',False) or callable(cancelled) and cancelled():
            raise ValueError('原生窗口已关闭，更新启动尚未确认')
        coordinator.confirm_healthy(release)


def main():
    from assistant.owned_helper_dispatch import dispatch_owned_helper
    helper_exit=dispatch_owned_helper(sys.argv[1:])
    if helper_exit is not None:
        if helper_exit==2:print('helper_arguments_invalid')
        return helper_exit
    parser=argparse.ArgumentParser(allow_abbrev=False); parser.add_argument('--data-dir'); parser.add_argument('--port',type=int,default=0)
    mode=parser.add_mutually_exclusive_group()
    mode.add_argument('--headless','--no-browser',dest='headless',action='store_true',help=argparse.SUPPRESS)
    mode.add_argument('--browser',action='store_true',help='在默认浏览器打开本机工作台')
    mode.add_argument('--assistant',action='store_true',help='启动网页工作台的本地助手')
    parser.add_argument('--employee-workspace',action='store_true',help='内部验收：本机同窗口员工工作台，需 --assistant')
    parser.add_argument('--manual-owned-read',action='store_true',help='源码手动工作台：保留旧任务，关闭自动处理；平台许可未确认时保持暂停')
    parser.add_argument('--development-workspace',action='store_true',help='仅指定验收电脑源码直入已绑定员工工作台')
    parser.add_argument('--platform-qa-device',default='',help='内部验收：仅使用指定已配对电脑，需云端同时开启')
    parser.add_argument('--self-operating-read',default='',help='源码自营只读：全新独立 work 实例目录，不接管原客户数据')
    parser.add_argument('--owner-primary-platforms',action='store_true',help='新空自营实例的三主平台产品范围；各平台用途与账号仍须独立核实')
    parser.add_argument('--owner-upgrade-primary',action='store_true',help=argparse.SUPPRESS)
    parser.add_argument('--owner-upgrade-recovery-key',default='',help=argparse.SUPPRESS)
    parser.add_argument('--guarded-cli-runtime',default='',help='源码自用：选择本项目 work 内已核对的 guarded CLI 目录；不解除平台暂停')
    parser.add_argument('--runtime-license-review',default='',help='源码自用：绑定固定本地组件审核文件；不代替账号和设备权限')
    parser.add_argument('--runtime-license-review-sha256',default='',help='上述已审核文件的固定 SHA256，须成对提供')
    parser.add_argument('--browser-account-login',action='store_true',help=argparse.SUPPRESS)
    parser.add_argument('--xhs-page-transport',action='store_true',help=argparse.SUPPRESS)
    parser.add_argument('--xhs-natural-transport',action='store_true',help=argparse.SUPPRESS)
    parser.add_argument('--xhs-browser-readonly-demo',action='store_true',help=argparse.SUPPRESS)
    parser.add_argument('--install-root',help=argparse.SUPPRESS)
    parser.add_argument('--update-release',type=int,help=argparse.SUPPRESS)
    parser.add_argument('--managed-platform-window',help=argparse.SUPPRESS); args=parser.parse_args()
    if args.owner_primary_platforms and not args.self_operating_read:
        parser.error('三主平台范围只用于新的独立自营实例，不修改客户或旧标记')
    if (args.owner_upgrade_primary or args.owner_upgrade_recovery_key) and (
            not args.self_operating_read or args.headless or args.browser
            or args.owner_upgrade_primary and (args.owner_primary_platforms or args.owner_upgrade_recovery_key)):
        parser.error('原实例升级须明确选择原生起用或同key元数据恢复')
    if args.self_operating_read and args.managed_platform_window:
        parser.error('自营只读不进入原 managed 平台窗口用途')
    if args.guarded_cli_runtime and not args.self_operating_read and (getattr(sys,'frozen',False) or not args.assistant
            or not args.employee_workspace or args.install_root or args.update_release is not None
            or args.managed_platform_window or args.platform_qa_device or args.development_workspace
            or args.browser_account_login or args.xhs_page_transport or args.xhs_natural_transport
            or args.xhs_browser_readonly_demo or args.manual_owned_read):
        parser.error('源码运行库选择仅限原源码助手，不与安装、设备验收或网页模式混用')
    if bool(args.runtime_license_review)!=bool(args.runtime_license_review_sha256):
        parser.error('组件审核文件与固定摘要须成对提供')
    if args.runtime_license_review and not args.self_operating_read and (getattr(sys,'frozen',False) or not args.assistant
            or not args.employee_workspace or args.install_root or args.update_release is not None
            or args.managed_platform_window or args.xhs_page_transport or args.xhs_natural_transport
            or args.xhs_browser_readonly_demo):
        parser.error('组件审核文件仅限原源码助手的 guarded CLI 内部自用入口')
    if args.manual_owned_read and (getattr(sys,'frozen',False) or not args.assistant or not args.employee_workspace
            or args.install_root or args.update_release is not None or args.platform_qa_device
            or args.development_workspace or args.browser_account_login or args.xhs_page_transport
            or args.xhs_natural_transport or args.xhs_browser_readonly_demo or args.managed_platform_window):
        parser.error('--manual-owned-read 仅限独立源码助手员工工作台')
    if args.update_release is not None and (not args.install_root or args.update_release<1):
        parser.error('--update-release 必须由固定启动入口配合 --install-root 提供')
    if args.platform_qa_device and not args.assistant:
        parser.error('--platform-qa-device 必须与 --assistant 一起使用')
    if args.employee_workspace and (not args.assistant or getattr(sys,'frozen',False)):
        parser.error('--employee-workspace 仅允许当前源码助手与 --assistant 一起使用')
    if args.development_workspace and (not args.assistant or not args.employee_workspace
            or not args.platform_qa_device or getattr(sys,'frozen',False)):
        parser.error('--development-workspace 仅允许指定电脑的源码员工工作台')
    if args.platform_qa_device and getattr(sys,'frozen',False):
        parser.error('--platform-qa-device 仅允许当前源码助手验收')
    if args.browser_account_login and (getattr(sys,'frozen',False) or not args.assistant
            or not args.employee_workspace or not args.platform_qa_device):
        parser.error('--browser-account-login 仅允许指定电脑的源码员工工作台验收')
    if args.xhs_page_transport and (getattr(sys,'frozen',False) or not args.assistant
            or not args.employee_workspace or not args.platform_qa_device):
        parser.error('--xhs-page-transport 仅允许指定电脑的源码员工工作台验收')
    if args.xhs_natural_transport and not args.xhs_page_transport:
        parser.error('--xhs-natural-transport 必须通过源码网页采集验收入口启用')
    if args.xhs_browser_readonly_demo and (not getattr(sys,'frozen',False) or args.headless
            or args.browser or args.employee_workspace or args.development_workspace
            or args.platform_qa_device or args.browser_account_login or args.xhs_page_transport
            or args.xhs_natural_transport or args.managed_platform_window):
        parser.error('--xhs-browser-readonly-demo 仅允许员工安装包的原生本机窗口')
    if args.managed_platform_window:
        from managed_platform_window import main as run_platform_window
        run_platform_window(args.managed_platform_window)
        return
    owner_instance=None
    owner_upgrade_request=None
    if args.self_operating_read:
        if (getattr(sys,'frozen',False) or not args.guarded_cli_runtime or args.assistant or args.employee_workspace
                or args.data_dir or args.install_root or args.update_release is not None or args.platform_qa_device
                or args.development_workspace or args.browser_account_login or args.xhs_page_transport
                or args.xhs_natural_transport or args.xhs_browser_readonly_demo or args.manual_owned_read
                or args.managed_platform_window):
            parser.error('自营只读须使用独立新实例，不与客户、设备、安装或原目录入口混用')
        from assistant.self_operating_read import open_owner_read_instance
        owner_instance=open_owner_read_instance(args.self_operating_read,str(ROOT.parents[1]),
            hashlib.sha256((ROOT/'platform_cli.py').read_bytes()).hexdigest(),
            product='primary_platforms_v2' if args.owner_primary_platforms else 'xiaohongshu_v1',
            existing_only=bool(args.owner_upgrade_primary or args.owner_upgrade_recovery_key))
        if args.owner_upgrade_primary or args.owner_upgrade_recovery_key:
            from assistant.owner_primary_entry import prepare_owner_upgrade_request
            owner_upgrade_request=prepare_owner_upgrade_request(owner_instance,
                key=args.owner_upgrade_recovery_key or None,
                metadata_recovery=bool(args.owner_upgrade_recovery_key))
    config=owner_instance.check() if owner_instance else company_config()
    if args.guarded_cli_runtime:
        config,_=source_guarded_cli_selection(args.guarded_cli_runtime,config,owner_instance=owner_instance)
    startup_review_binding=(_TrustedStartupRuntimeReview(args.runtime_license_review,
        args.runtime_license_review_sha256,config,owner_instance=owner_instance) if args.runtime_license_review else None)
    if args.xhs_browser_readonly_demo and not portable_browser_readonly_demo(
            config,packaged=bool(getattr(sys,'frozen',False)),native_window=True):
        parser.error('--xhs-browser-readonly-demo 需要完整的员工安装包配置')
    runtime=config.get('runtime') or {}
    if runtime.get('portable_employee_release') is not None:
        if not employee_distribution.packaged_workspace(
                config,packaged=bool(getattr(sys,'frozen',False))):
            raise ValueError('员工安装包配置不完整，请使用完整安装包重新安装')
    private_declared=bool(runtime.get('private_evaluation') or runtime.get('private_evaluation_session_id'))
    assistant_mode=bool(not owner_instance and (runtime.get('role')=='local_assistant_only'
                        or args.assistant or (not args.headless and not args.browser)))
    data_dir=(owner_instance.directory/'data') if owner_instance else Path(args.data_dir) if args.data_dir else Path(os.environ.get('LOCALAPPDATA',str(Path.home())))/(config['id']+('Assistant' if assistant_mode else 'Workspace'))
    data_dir=data_dir.resolve()
    private_capability=None
    if args.manual_owned_read and private_declared:parser.error('手动起用不进入私下安装用途')
    if private_declared:
        if not getattr(sys,'frozen',False) or args.browser:
            raise ValueError('私下安装验收只允许本机冻结程序的桌面入口或受控探测')
        private_capability=private_evaluation.validate(config,sys.executable,data_dir,
                                                       headless=args.headless)
        if args.install_root and Path(args.install_root).resolve()!=private_capability.install_root:
            raise ValueError('私下安装固定启动目录与当前许可不匹配')
        private_evaluation.prepare_fresh_data(private_capability)
    # Customer assistant packages keep their role even when launched with a
    # diagnostic --headless or --browser flag.
    employee_workspace_mode=bool(owner_instance or args.employee_workspace or production_employee_workspace(
        config, packaged=bool(getattr(sys,'frozen',False)))
        or employee_distribution.packaged_workspace(config,packaged=bool(getattr(sys,'frozen',False)))
        or private_evaluation_workspace(
            config,private_capability,packaged=bool(getattr(sys,'frozen',False))))
    production_natural=production_natural_workspace(config,packaged=bool(getattr(sys,'frozen',False)))
    if owner_instance:owner_instance.prepare_data()
    data_dir=data_dir.resolve(); data_dir.mkdir(parents=True,exist_ok=True)
    provisional_update=(data_dir/'assistant/updates/transaction.json').exists()
    if args.manual_owned_read and provisional_update:raise ValueError('待确认更新须先由原更新入口核实，手动工作台未启动')
    if provisional_update and (args.update_release is None or args.headless or args.browser):
        raise ValueError('待确认更新必须由固定入口启动原生窗口完成检查')
    owner_mutex=None
    if owner_instance:
        from assistant.owner_normal_close import acquire_owner_instance_lock
        try:
            owner_mutex=acquire_owner_instance_lock(owner_instance)
        except OSError as error:
            raise ValueError('原工作台锁仍待核对；本次未启动或接管旧窗口') from error
        lockfile=owner_mutex._file
    else:
        lockfile=(data_dir/'instance.lock').open('a+b')
        if os.name=='nt':
            import msvcrt
            if lockfile.tell()==0: lockfile.write(b'1'); lockfile.flush()
            lockfile.seek(0)
            try:msvcrt.locking(lockfile.fileno(),msvcrt.LK_NBLCK,1)
            except OSError:
                if args.manual_owned_read:
                    lockfile.close()
                    raise ValueError('原工作台正在运行，手动模式未启动')
                try:
                    running=json.loads((data_dir/'running.json').read_text('utf-8'))
                    parsed=urlparse(running['url'])
                    if parsed.hostname!='127.0.0.1': return
                    with urllib.request.urlopen(running['url']+'/health',timeout=2) as r:
                        if json.load(r).get('app')=='local-lead-workspace' and not args.headless:
                            if args.browser or running.get('mode')=='browser':
                                webbrowser.open(running['url']+('/workspace' if employee_workspace_mode else '/assistant' if assistant_mode else ''))
                                return
                            from desktop import focus_process_window
                            for _ in range(20):
                                if focus_process_window(running.get('pid')):break
                                time.sleep(.2)
                except Exception: pass
                return
    logging.basicConfig(filename=data_dir/'workspace.log',level=logging.INFO,encoding='utf-8',format='%(asctime)s %(levelname)s %(message)s')
    try:
        server=AppServer(('127.0.0.1',args.port),data_dir,platform_qa_device_id=args.platform_qa_device,
                         employee_workspace=employee_workspace_mode,install_root=args.install_root,
                         development_workspace=args.development_workspace,
                         private_evaluation_capability=private_capability,
                         xhs_page_transport=bool(args.xhs_page_transport or production_natural),
                         xhs_natural_transport=bool(args.xhs_natural_transport or production_natural),
                         xhs_browser_readonly_demo=args.xhs_browser_readonly_demo,
                         manual_owned_read_start=args.manual_owned_read,
                         guarded_cli_runtime=args.guarded_cli_runtime or None,
                         self_operating_instance=owner_instance,
                         owner_metadata_recovery=bool(args.owner_upgrade_recovery_key),
                         runtime_license_review=startup_review_binding.review if startup_review_binding else None,
                         runtime_license_usage_scope='internal_self_use_read' if startup_review_binding else None,
                         runtime_license_review_binding=startup_review_binding)
        if owner_mutex is not None:
            owner_mutex.bind_server(server)
    except Exception:
        if owner_mutex is None:lockfile.close()
        elif owner_mutex._server is None:owner_mutex.release()
        raise
    try:
        if owner_upgrade_request is not None:owner_upgrade_request.bind_server(server,owner_mutex)
        if args.owner_upgrade_recovery_key:
            # Real original Factory/Server/Owner/Core and deferred startup;
            # no serving, Native, running.json rewrite or platform start.
            owner_upgrade_request.bind_metadata_recovery()
            return 0  # Original finally still closes and consumes real cap.
        server.update_startup_pending=provisional_update
        server.browser_login_enabled=bool(args.browser_account_login or production_employee_workspace(
            config,packaged=bool(getattr(sys,'frozen',False)))
            or employee_distribution.packaged_workspace(config,packaged=bool(getattr(sys,'frozen',False)))
            or private_evaluation_workspace(
                config,private_capability,packaged=bool(getattr(sys,'frozen',False))))
        server.browser_login_helper_path=ROOT/'assistant'/'browser_login_window.py'
        server.update_startup_gate=threading.Event() if provisional_update else None
        if not provisional_update:confirm_update_startup(server,args.update_release)
        if assistant_mode:
            from assistant.service import AssistantService
            if private_capability:
                class PrivateEvaluationService(AssistantService):
                    def start(self):
                        private_evaluation.activate_bound_assistant(
                            self,self.server.private_evaluation_capability)
                        return super().start()
                server.assistant_service=PrivateEvaluationService(server)
            else:
                server.assistant_service=AssistantService(server)
            if not (private_capability and private_capability.probe):
                server.assistant_service.start()
        if not owner_instance:server.start_auto_updates()
        url='http://127.0.0.1:'+str(server.server_port)
        def save_running():
            (data_dir/'running.json').write_text(json.dumps({'pid':os.getpid(),'url':url,
                'mode':'headless-test' if args.headless else ('browser' if args.browser else 'assistant')}),encoding='utf-8')
        if not provisional_update:save_running()
        if sys.stdout: print(url,flush=True)
        if args.headless:server.serve_forever(poll_interval=.5)
        elif args.browser:
            webbrowser.open(url+('/workspace' if employee_workspace_mode else '/assistant' if assistant_mode else ''))
            server.serve_forever(poll_interval=.5)
        else:
            from desktop import run_desktop,show_desktop_error
            def native_ready(window):
                if server.closing or getattr(window,'_workspace_startup_cancelled',False):
                    raise ValueError('原生窗口已关闭，更新启动尚未确认')
                save_running()
                confirm_update_startup(server,args.update_release,serving=True,
                    cancelled=lambda:bool(getattr(window,'_workspace_startup_cancelled',False)))
                server.update_startup_pending=False
                server.update_startup_gate.set()
                server.start_auto_updates()
            window_suffix='工作台' if employee_workspace_mode else '本地助手' if assistant_mode else '运营台'
            window_title=config['name'] if config['name'].endswith(window_suffix) else config['name']+window_suffix
            try:run_desktop(server,url+('/workspace' if employee_workspace_mode else '/assistant' if assistant_mode else ''),data_dir,window_title,ready_callback=native_ready if provisional_update else None,ready_timeout=45 if provisional_update else None)
            except Exception as ex:show_desktop_error(ex);raise
    except KeyboardInterrupt: pass
    finally:
        if owner_mutex is None:
            server.close_owned_jobs();server.server_close();lockfile.close()
        else:
            from assistant.owner_normal_close import finish_owner_main,OwnerClosePending
            from desktop import request_owner_close_retry
            while True:
                try:
                    closed_capability=finish_owner_main(server,owner_mutex,
                        require_upgrade_capability=owner_upgrade_request is not None)
                    break
                except OwnerClosePending as error:
                    logging.warning('Owner normal close held: %s',error.code)
                    # Only an explicit normal-main retry runs another close
                    # check. Cancel keeps this process and its original mutex.
                    request_owner_close_retry(error.code)
            # Root's fixed reviewed same-process upgrade finalizer consumes the
            # exact capability at this seam before releasing the original lock.
            # No callback/approval/path from an HTTP caller is accepted here.
            if owner_upgrade_request is not None:
                while True:
                    try:
                        owner_upgrade_request.finish(closed_capability)
                        break
                    except (Exception,KeyboardInterrupt):
                        logging.warning('Owner upgrade finalizer held; original mutex retained')
                        request_owner_close_retry('OWNER_UPGRADE_FINALIZER_PENDING')
            while True:
                try:
                    owner_mutex.release()
                    break
                except (Exception,KeyboardInterrupt):
                    logging.warning('Owner main mutex release held; explicit normal retry required')
                    request_owner_close_retry('OWNER_MUTEX_RELEASE_PENDING')

if __name__=='__main__': raise SystemExit(main())



