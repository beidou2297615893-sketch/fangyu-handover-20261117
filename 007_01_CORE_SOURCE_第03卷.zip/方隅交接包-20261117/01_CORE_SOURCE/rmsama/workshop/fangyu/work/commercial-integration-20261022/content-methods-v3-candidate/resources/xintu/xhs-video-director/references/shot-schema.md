# Shot Table Schema

| Time | Visual | Spoken line | On-screen text | Capture method | Edit cue | Required asset |
|---|---|---|---|---|---|---|

## Capture choices

- Phone footage: face, emotion, hands, physical context, result reaction.
- Native screen recording: UI, cursor actions, before/after states, reproducible steps.
- Graphic card: score, comparison, timeline, system diagram, transition.

## Delivery package

- three hook options
- final spoken script
- timestamped shot table
- phone-shot checklist
- screen-recording checklist
- cover and first-frame text
- captions that preserve spoken meaning

