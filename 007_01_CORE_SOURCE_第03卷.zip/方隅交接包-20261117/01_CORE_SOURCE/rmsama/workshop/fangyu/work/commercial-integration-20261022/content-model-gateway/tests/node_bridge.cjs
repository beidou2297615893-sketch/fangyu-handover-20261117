'use strict';
// Persistent offline test bridge. NEVER import this provider into production.
const readline = require('node:readline');
const {fixture, IDS} = require('./cloud-fixture.cjs');
const {ProviderError} = require('../server/ai_provider.cjs');

const denied = () => { throw new Error('TEST_NETWORK_FORBIDDEN'); };
globalThis.fetch = denied;
for (const name of ['node:http', 'node:https']) {
  const network = require(name); network.request = denied; network.get = denied;
}
const net = require('node:net'); net.connect = denied; net.createConnection = denied;

let current = null, fixtureOutput = null, providerMode = 'success';
const copy = value => structuredClone(value);

function syntheticProvider(request) {
  if (providerMode === 'timeout') throw new ProviderError('AI_PROVIDER_TIMEOUT');
  if (fixtureOutput === null) throw new Error('EXPLICIT_SYNTHETIC_OUTPUT_REQUIRED');
  return {model: request.model, ...(request.provider === 'openai' ? {service_tier: 'default'} : {}),
    usage: request.provider === 'openai'
      ? {prompt_tokens: 100, completion_tokens: 50, total_tokens: 150,
          prompt_tokens_details: {cached_tokens: 0}, completion_tokens_details: {reasoning_tokens: 0}}
      : {prompt_tokens: 100, prompt_cache_hit_tokens: 20, prompt_cache_miss_tokens: 80, completion_tokens: 50},
    choices: [{finish_reason: 'stop', message: {content: JSON.stringify(fixtureOutput)}}]};
}

async function handle(message) {
  if (message.command === 'init') {
    if (!message.fixtureOutput || typeof message.fixtureOutput !== 'object') throw new Error('EXPLICIT_OUTPUT_REQUIRED');
    fixtureOutput = copy(message.fixtureOutput);
    providerMode = message.mode || 'success';
    current = await fixture({provider: syntheticProvider, budget: message.budget === undefined ? 5 : message.budget});
    const profile = await current.profile();
    return {trusted_context: {environment_id: IDS.env, company_id: IDS.company,
      tenant_id: IDS.tenant, store_id: IDS.store, account_id: IDS.account, platform: 'xiaohongshu',
      actor: IDS.actor, device_id: IDS.device, expected_revision: profile.config.revision,
      expected_rules_version: profile.config.rules_version}};
  }
  if (!current) throw new Error('BRIDGE_NOT_INITIALIZED');
  if (message.command === 'configure') {
    if (Object.hasOwn(message, 'fixtureOutput')) fixtureOutput = copy(message.fixtureOutput);
    if (Object.hasOwn(message, 'mode')) providerMode = message.mode;
    return {configured: true};
  }
  if (message.command === 'call') {
    const payload = message.payload;
    if (!payload || !['content_generate', 'content_generate_status'].includes(payload.operation)) throw new Error('TEST_OPERATION_REJECTED');
    return current.call(payload.operation, payload);
  }
  if (message.command === 'stats') {
    const profile = await current.profile(current.admin);
    return {providerCalls: current.calls(), providerTransactions: copy(current.providerTransactions),
      spent: profile.budget.spent_cny, reserved: profile.budget.reserved_cny,
      ledgerStates: current.memory.rows('fangyu_ai_ledger').map(row => row.status)};
  }
  if (message.command === 'close') return {closed: true};
  throw new Error('UNKNOWN_BRIDGE_COMMAND');
}

const input = readline.createInterface({input: process.stdin, crlfDelay: Infinity});
let queue = Promise.resolve();
input.on('line', line => {
  queue = queue.then(async () => {
    let message;
    try {
      message = JSON.parse(line);
      const result = await handle(message);
      process.stdout.write(JSON.stringify({id: message.id, ok: true, result}) + '\n');
    } catch {
      process.stdout.write(JSON.stringify({id: message?.id ?? null, ok: false, error: 'synthetic_bridge_failed'}) + '\n');
    }
  });
});
