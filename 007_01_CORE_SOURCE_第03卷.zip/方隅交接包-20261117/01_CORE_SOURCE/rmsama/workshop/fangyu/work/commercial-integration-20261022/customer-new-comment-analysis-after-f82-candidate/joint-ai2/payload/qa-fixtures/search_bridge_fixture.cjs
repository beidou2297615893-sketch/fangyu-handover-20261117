'use strict';
// Only the external page is synthetic. Actual Router, Registry, BridgeClient
// (in the real CLI child) and the COMPLETE original userscript run unchanged
// except its two documented local Bridge config literals.
const fs=require('fs'),path=require('path'),http=require('http'),vm=require('vm');
const ROOT=process.argv[2],OUT=process.argv[3];
const {Router}=require(path.join(ROOT,'lib/server/router'));
const {ConnectionRegistry}=require(path.join(ROOT,'lib/server/registry'));
const {WebSocketHub}=require(path.join(ROOT,'lib/server/ws-hub'));
const TOKEN='own-search-loopback-token-000000000000';
const registry=new ConnectionRegistry(),hub=new WebSocketHub({registry});
const router=new Router({registry,wsHub:hub,strictConnections:true,allowedSite:'douyin.com',token:TOKEN});
const browsers=[],expressions=[],wire=[];let port,closed=false,searchCount=0;
const save=()=>fs.writeFileSync(path.join(OUT,'VM-EVIDENCE.json'),JSON.stringify({expressions,wire,searchCount,realPlatformNetwork:0},null,2));
const server=http.createServer(async(req,res)=>{
 try{
  if(req.url.startsWith('/fixture/')){
   if(req.headers.authorization!=='Bearer '+TOKEN){res.writeHead(403);return res.end('{}');}
   let raw='';for await(const c of req)raw+=c;const d=raw?JSON.parse(raw):{};let value;
   if(req.url==='/fixture/options'){Object.assign(browsers.find(b=>b.uid===d.uid).options,d.options);value={ok:true};}
   else if(req.url==='/fixture/log')value={expressions,wire,searchCount,browsers:browsers.map(b=>({uid:b.uid,connId:b.connId}))};
   else if(req.url==='/fixture/shutdown'){value={ok:true};setTimeout(close,20);}
   else throw Error('No such owned fixture route');
   res.writeHead(200,{'Content-Type':'application/json'});res.end(JSON.stringify(value));return;
  }
  return await router.handle(req,res);
 }catch(e){res.writeHead(500,{'Content-Type':'application/json'});res.end(JSON.stringify({error:String(e)}));}
});
async function browser(uid,marker){
 const b={uid,marker,options:{},timers:new Set(),requests:new Set(),closed:false};browsers.push(b);
 const later=(fn,ms)=>{const timer=setTimeout(()=>{b.timers.delete(timer);if(!b.closed)fn();},ms);b.timers.add(timer);return timer;};
 const context={console:{log(){},warn(){}},TextEncoder,TextDecoder,Uint8Array,ArrayBuffer,
  URLSearchParams,URL,BigInt,JSON,Map,Set,Date,Promise,setTimeout:later,clearTimeout,
  screen:{width:1255,height:1100},navigator:{userAgent:'OWNED-SYNTHETIC-SEARCH',language:'zh-CN',platform:'Win32'},
  location:{href:'https://www.douyin.com/#workbench-account='+marker,hostname:'www.douyin.com',protocol:'https:'},
  document:{title:'自有搜索质量夹具',cookie:''},history:{pushState(){},replaceState(){}},addEventListener(){},
  atob:v=>Buffer.from(v,'base64').toString('binary'),btoa:v=>Buffer.from(v,'binary').toString('base64'),
  localStorage:{getItem(){return null;}},WebSocket:class{constructor(){throw Error('No platform WebSocket allowed');}}};
 context.fetch=async(url,init)=>{
  const u=new URL(url,'https://www.douyin.com');if(u.hostname!=='www.douyin.com')throw Error('No external network');
  const record={uid,path:u.pathname,query:Object.fromEntries(u.searchParams),method:init?.method||'GET'};
  if(record.method!=='GET')throw Error('No writes');wire.push(record);save();let value;
  if(u.pathname==='/aweme/v1/web/query/user/')value={status_code:0,user_uid:b.options.wrongUid||uid,user:{uid:b.options.wrongUid||uid,nickname:'合成当前账号'}};
  else if(u.pathname==='/aweme/v1/web/general/search/single/'){
   if(u.searchParams.get('offset')!=='0'||!['1','2','3','20'].includes(u.searchParams.get('count')))throw Error('Original first-page bound lost');
   searchCount++;value=b.options.corruptSearch?{status_code:10000}: {status_code:0,data:[{aweme_info:{aweme_id:'1234567890123456789',desc:'上海古北求租一个月公寓',author:{nickname:'合成帖子作者',uid:'1234567890123456'},create_time:Math.floor(Date.now()/1000)-3600,statistics:{play_count:1}}}]};
  }else if(u.pathname==='/aweme/v1/web/comment/list/'){
   if(u.searchParams.get('cursor')!=='0'||u.searchParams.get('aweme_id')!=='1234567890123456789')throw Error('Original fixed video/page bound lost');
   value={status_code:0,comments:[{cid:b.options.commentId||'923456789012345678',text:b.options.commentText||'上海古北求租公寓，预算6000，想住一个月',digg_count:0,reply_comment_total:0,create_time:Math.floor(Date.now()/1000)-3500,user:{uid:'9876543210123456',nickname:'合成求租客户'}}],has_more:false,cursor:0};
  }else throw Error('No unlisted page endpoint');
  return {ok:true,status:200,headers:{get:()=> 'application/json'},text:async()=>JSON.stringify(value),json:async()=>value};
 };
 context.window=context;context.unsafeWindow=context;vm.createContext(context);
 context.eval=source=>{expressions.push({uid,source});save();return vm.runInContext(source,context);};
 context.GM_xmlhttpRequest=options=>{
  const u=new URL(options.url);if(u.hostname!=='127.0.0.1'||Number(u.port)!==port)throw Error('Only own Bridge');
  const req=http.request({host:'127.0.0.1',port,path:u.pathname+u.search,method:options.method||'GET',headers:options.headers},res=>{
   let raw='';res.on('data',c=>raw+=c);res.on('end',()=>options.onload?.({status:res.statusCode,responseText:raw}));
  });b.requests.add(req);req.on('close',()=>b.requests.delete(req));req.on('error',e=>{if(!b.closed)options.onerror?.(e);});
  if(options.data)req.write(options.data);req.end();
 };
 let source=fs.readFileSync(path.join(ROOT,'scripts/douyin.user.js'),'utf8');
 source=source.replace("server: 'http://127.0.0.1:19432'","server: 'http://127.0.0.1:"+port+"'").replace("token: '',","token: '"+TOKEN+"',");
 vm.runInContext(source,context,{filename:'ACTUAL-complete-douyin.user.js'});
 for(let n=0;n<200;n++){
  const c=registry.getAll('douyin.com').find(c=>c.url?.includes(marker));
  if(c){b.connId=c.id;return {uid,marker,connId:c.id};}await new Promise(r=>setTimeout(r,10));
 }
 throw Error('Actual userscript failed to register');
}
async function close(){if(closed)return;closed=true;save();for(const b of browsers){b.closed=true;for(const t of b.timers)clearTimeout(t);for(const r of b.requests)r.destroy();}
 for(const p of router._pending.values()){clearTimeout(p.timer);p.reject?.();}for(const w of router._pollWaiters.values())for(const x of w){clearTimeout(x.timer);x.res.end('{}');}
 server.closeAllConnections();await new Promise(r=>server.close(r));}
(async()=>{await new Promise(r=>server.listen(0,'127.0.0.1',r));port=server.address().port;
 const accounts=await Promise.all([browser('9007199254741999','owned-search-window-one'),browser('9007199254742001','owned-search-window-two')]);
 fs.writeFileSync(path.join(OUT,'VM-READY.json'),JSON.stringify({port,token:TOKEN,accounts}));
})().catch(e=>{console.error(e);process.exitCode=1;close();});
