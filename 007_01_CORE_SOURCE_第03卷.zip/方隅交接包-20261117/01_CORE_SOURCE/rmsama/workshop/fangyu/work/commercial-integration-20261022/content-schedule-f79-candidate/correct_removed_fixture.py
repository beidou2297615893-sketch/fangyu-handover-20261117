from pathlib import Path
import json
W=Path(__file__).resolve().parent;s=(W/'test_f79_deleted_account.py').read_text('utf-8');needle="answer['error']['code']=='CONTENT_ACCOUNT_CHANGED'"
assert s.count(needle)==1;s=s.replace(needle,"answer['error']['code']=='ACCOUNT_FORBIDDEN'")
(W/'test_f79_deleted_account_v2.py').write_text(s,'utf-8')
(W/'F79-REMOVED-ACCOUNT-FIXTURE-NOTE.md').write_text('首轮额外删除交互测试误以为会到达内容组件的CONTENT_ACCOUNT_CHANGED，实际原Native workbench_backend先在现存账号权限门返回ACCOUNT_FORBIDDEN。原完整业务body、403、Store digest无变化、派发增量0都已捕获；这更早的原门保持有效。仅新v2夹具改为精确原Native错误码，保留全部零写/零派发/原schedule-intent-key逐字相同断言；旧RED目录与夹具保留，产品不改。Core删除为自有合成账号的原CAS调用，不冒充Native删除入口新验收。\n','utf-8')
print('Fixture v2 expects the existing earlier Native account guard, all safety assertions unchanged')
