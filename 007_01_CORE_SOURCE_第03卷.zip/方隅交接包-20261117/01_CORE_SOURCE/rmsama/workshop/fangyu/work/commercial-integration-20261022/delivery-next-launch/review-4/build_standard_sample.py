"""Representative v70 standard distribution; all writes stay in review-4.

Reuses the pinned public closure, original PyInstaller runtime and original
self-extracting installer. Never imports or executes the old product builder.
"""
from pathlib import Path, PurePosixPath
from datetime import datetime, timezone
import argparse, ast, hashlib, importlib.util, json, os, shutil, stat, subprocess, sys, zipfile

sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
P=HERE.parents[3]
BASE=P/'work/parallel-integration-20261018/final-integration/candidate-unified-v70'
PYTHON=P/'work/desktop-python/Scripts/python.exe'
SAMPLE=HERE/'standard-sample-v70'
DIST=SAMPLE/'dist'
NAME='FangyuWorkbench'
HELD_STANDARD=False
INCLUDE_WEBVIEW2=True
VERSION=70
CLEAN_ENTRY=False
UNIFIED_SHA=''
SOURCE_INSPECT=HERE/'INPUT-DISTRIBUTION-INSPECTION.json'
INSTALLER_SOURCE=P/'work/packaging/installer.py'


def sha(raw):return hashlib.sha256(raw).hexdigest()
def js(path):return json.loads(path.read_text('utf-8-sig'))
def dump(path,value):
    with path.open('x',encoding='utf-8') as stream:json.dump(value,stream,ensure_ascii=False,indent=2);stream.write('\n')
def safe_read(path):
    for part in (path,*path.parents):
        if part.is_symlink() or getattr(part.lstat(),'st_file_attributes',0)&0x400:raise RuntimeError('Link input refused')
    info=path.stat()
    if not stat.S_ISREG(info.st_mode) or info.st_nlink!=1:raise RuntimeError('Non-plain input refused')
    raw=path.read_bytes()
    if (info.st_dev,info.st_ino,info.st_size,info.st_mtime_ns)!=(path.stat().st_dev,path.stat().st_ino,path.stat().st_size,path.stat().st_mtime_ns):raise RuntimeError('Input changed')
    return raw


def own_environment():
    env=dict(os.environ)
    for key in ('PYTHONHOME','PYTHONPATH','VIRTUAL_ENV'):env.pop(key,None)
    for key,folder in (('PYINSTALLER_CONFIG_DIR','build-cache'),('TEMP','temp'),('TMP','temp'),('LOCALAPPDATA','build-localappdata'),('APPDATA','build-appdata')):
        target=SAMPLE/folder;target.mkdir(parents=True,exist_ok=True);env[key]=str(target)
    env['PYTHONDONTWRITEBYTECODE']='1';env['PYTHONIOENCODING']='utf-8'
    return env


def run(argv,log,timeout=900):
    with (SAMPLE/log).open('x',encoding='utf-8') as stream:
        process=subprocess.run([str(a) for a in argv],cwd=HERE,env=own_environment(),stdout=stream,stderr=subprocess.STDOUT,
            timeout=timeout,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
    if process.returncode:raise RuntimeError('Tool failed; see '+log)


def stage():
    if SAMPLE.exists():raise RuntimeError('Representative directory already exists; preserve it')
    raw=safe_read(BASE/'UNIFIED-PINS.json');manifest=json.loads(raw)
    if VERSION==70:
        fixed=js(HERE/'READONLY-ROUTE-AUDIT.json')['inventoryV70Nonfinal'];expected_sha=fixed['manifestSha256'];expected_count=3125
    elif VERSION==71:
        expected_sha='c6eca73ebcb112fe068c094bc5a3f1ef992aa561d77c4e71ee01c84e28de17ac';expected_count=3152
    else:
        expected_sha='1a1c49af3fee70e1270a5fe71e12d24b6a35480814dc16c7a02205ae0d139295';expected_count=3152
    if sha(raw)!=expected_sha or len(manifest['files'])!=expected_count:raise RuntimeError('Fixed source input differs')
    staged=js(BASE/'STAGED.json');release_id=staged['release_id']
    SAMPLE.mkdir();project=SAMPLE/'payload/project';project.mkdir(parents=True)
    omitted=[];copied=[]
    for row in manifest['files']:
        relative=PurePosixPath(row['path'])
        if relative.is_absolute() or '..' in relative.parts or ':' in str(relative) or '\\' in str(relative):raise RuntimeError('Invalid public member')
        if str(relative).startswith(('work/ui-native-r57/state/','work/ui-native-r57/candidates/','work/ui-native-r57/run_candidate.')):
            omitted.append(str(relative));continue
        source=BASE/'project'/relative;body=safe_read(source)
        if sha(body)!=row['sha256'] or len(body)!=row['bytes']:raise RuntimeError('Public sample member differs')
        if source.name.lower() in ('ffmpeg.exe','ffprobe.exe') or source.suffix.lower() in ('.safetensors','.gguf','.ckpt','.pt','.pth','.onnx'):
            raise RuntimeError('Unwanted model/GPL runtime')
        target=project/relative;target.parent.mkdir(parents=True,exist_ok=True)
        with target.open('xb') as stream:stream.write(body)
        copied.append(str(relative))
    company=js(project/'work/app/company.json')
    company.pop('localCliPaths',None);company.pop('updateFeed',None)
    company['releaseVersion']='r57-standard-internal-v'+str(VERSION)
    company['runtime'].pop('portable_employee_release',None)
    company['runtime']['executable']=NAME+'.exe'
    company['runtime']['release_approved']=False
    company['runtime']['public_send_hold']=True
    company['runtime']['xiaohongshu_automation']='hold'
    if HELD_STANDARD:
        company['runtime']['standard_distribution_schema']='fangyu-held-standard-r57/1'
        company['runtime']['standard_native_release_id']=release_id
    (project/'work/app/company.json').write_text(json.dumps(company,ensure_ascii=False,indent=2)+'\n','utf-8')
    dump(SAMPLE/'payload/company.json',company)
    derived=[]
    if HELD_STANDARD:
        release=project/'work/ui-native-r57/releases'/release_id
        guard=release/'resources/platform-runtime/vendor-src/assistant/employee_distribution.py'
        app=release/'resources/platform-runtime/vendor-src/app.py'
        release_manifest=release/'RELEASE.json'
        excluded={guard.relative_to(project).as_posix(),release_manifest.relative_to(project).as_posix()}
        code=[]
        for name in sorted(copied):
            if name in excluded:continue
            path=project/name
            if path.suffix.lower() in ('.py','.js','.mjs','.exe','.dll','.pyd'):
                body=path.read_bytes();code.append({'path':name,'bytes':len(body),'sha256':sha(body)})
        contract={'schema':'fangyu-held-standard-code-manifest-v1','companyId':'fangyu-apartment-client',
            'channel':'internal_standard_candidate','commercialDistributionApproved':False,'platformExecutionApproved':False,
            'nativeReleaseId':release_id,'sourceClosureSha256':sha(raw),
            'wrapperSha256':company['runtime']['cli_source_sha256'],
            'companyConfigDigest':sha(json.dumps(company,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode()),
            'codeFileCount':len(code),'codeFiles':code,
            'excludedFromInnerManifest':[guard.relative_to(project).as_posix(),release_manifest.relative_to(project).as_posix()],
            'outerCompiledEntryPinsAllFilesIncludingGuardAndNativeManifest':True}
        dump(project/'HELD-STANDARD-MANIFEST.json',contract);copied.append('HELD-STANDARD-MANIFEST.json')
        source_guard=guard.read_bytes();source_app=app.read_bytes();source_release=release_manifest.read_bytes()
        body=source_guard.decode('utf-8').replace('\r\n','\n')
        needle='def runtime_config_valid(config):\n'
        if body.count(needle)!=1:raise RuntimeError('Source package gate changed')
        body=body.replace(needle,needle+'    if held_standard_config_valid(config):\n        return True\n')
        body+=(HERE/'held_standard_contract.py.in').read_text('utf-8').replace('@@MANIFEST_SHA@@',repr(sha((project/'HELD-STANDARD-MANIFEST.json').read_bytes())))
        ast.parse(body);guard.write_text(body,'utf-8')
        release_doc=json.loads(source_release)
        for row in release_doc['files']:
            if row['path']==guard.relative_to(release).as_posix():
                row['sha256']=sha(guard.read_bytes()).upper();row['size']=guard.stat().st_size
        release_doc['heldStandardDistributionCompatibility']={'internalOnly':True,'commercialApproved':False,
            'derivedFromNativeReleaseSha256':sha(source_release),'contractManifest':'HELD-STANDARD-MANIFEST.json'}
        release_manifest.write_text(json.dumps(release_doc,ensure_ascii=False,indent=2)+'\n','utf-8')
        for path,source in ((guard,source_guard),(release_manifest,source_release)):
            derived.append({'path':path.relative_to(project).as_posix(),'sourceSha256':sha(source),'derivedSha256':sha(path.read_bytes())})
        # These are pure synthetic QA assets, not existing users or sessions.
        if not CLEAN_ENTRY:
            fixture=js(P/'work/central-store-config/compiled-fixture.json')
            dump(project/'STANDARD-QA-FIXTURE.json',{'manifest':fixture['manifest'],'documents':fixture['documents']})
            copied.append('STANDARD-QA-FIXTURE.json')
            qa=(HERE/'standard_functional_qa.py').read_bytes()
            with (project/'STANDARD-FUNCTIONAL-QA.py').open('xb') as stream:stream.write(qa)
            copied.append('STANDARD-FUNCTIONAL-QA.py')
    entries=[]
    for name in sorted(copied):
        body=(project/name).read_bytes();entries.append({'path':name,'bytes':len(body),'sha256':sha(body)})
    dump(project/'SHIPPED-PINS.json',{'schema':'fangyu-standard-full-public-project-v1','representativeSampleOnly':not CLEAN_ENTRY,
        'internalStandardCandidate':True,'commercialDistributionApproved':False,
        'releaseId':release_id,'sourceClosureSha256':sha(raw),'sourceFiles':expected_count,'files':entries,
        'privateInstallationDescriptorsOmitted':omitted,'existingDataOrSecretsIncluded':False})
    release=project/'work/ui-native-r57/releases'/release_id
    template=(HERE/'standard_entry.py.in').read_text('utf-8')
    for token,value in (('RELEASE_ID',release_id),('RELEASE_SHA',sha((release/'RELEASE.json').read_bytes())),
                        ('CLOSURE_SHA',sha((project/'SHIPPED-PINS.json').read_bytes())),('SAMPLE',True)):
        template=template.replace('@@'+token+'@@',repr(value))
    if CLEAN_ENTRY:
        tree=ast.parse(template)
        main_guard=tree.body[-1]
        if not isinstance(main_guard,ast.If):raise RuntimeError('Entry template main guard differs')
        clean_main=ast.parse('''
def main():
    root=Path(sys.executable).resolve().parent if getattr(sys,'frozen',False) else Path(__file__).resolve().parent
    parser=argparse.ArgumentParser(description='方隅工作台')
    group=parser.add_mutually_exclusive_group()
    group.add_argument('--check',action='store_true')
    group.add_argument('--self-test',action='store_true')
    parser.add_argument('--result-file')
    args=parser.parse_args()
    host,project,release,closure=load_host(root)
    data,state=own_directories()
    if args.check or args.self_test:
        argv=['--check'] if args.check else ['--self-test']
        code=host.main(release,RELEASE_SHA,state,argv,project_root=project,data_dir=data)
        if code:raise RuntimeError('启动检查未通过')
        output({'status':'PASS','releaseId':RELEASE_ID,'frozen':getattr(sys,'frozen',False) is True,
            'internalStandardCandidate':True,'commercialDistributionApproved':False,
            'action':argv[0],'closureFilesVerified':len(closure['files'])},args.result_file)
        return 0
    short_native_icon(release,state)
    return host.main(release,RELEASE_SHA,state,[],project_root=project,data_dir=data)
''').body
        tree.body=[node for node in tree.body[:-1] if not
            (isinstance(node,ast.FunctionDef) and node.name in ('smoke','native_smoke','main')) and not
            (isinstance(node,ast.Assign) and any(isinstance(target,ast.Name) and target.id=='SAMPLE' for target in node.targets))]+clean_main+[main_guard]
        template=ast.unparse(ast.fix_missing_locations(tree))+'\n'
        if any(text in template for text in ('SAMPLE','CloudStandin','STANDARD-QA','runtime-smoke','native-smoke')):
            raise RuntimeError('Clean entry retained a synthetic QA branch')
    ast.parse(template)
    with (SAMPLE/'standard_entry.py').open('x',encoding='utf-8') as stream:stream.write(template)
    dump(SAMPLE/'STAGE.json',{'status':'REPRESENTATIVE_PUBLIC_CLOSURE_STAGED_NOT_APPROVED','releaseId':release_id,
        'sourceClosureSha256':sha(raw),'copiedFiles':len(entries),'omittedDescriptors':omitted,
        'nativeSourceBytesUnchanged':not HELD_STANDARD,'derivedFiles':derived,'cleanEntry':CLEAN_ENTRY,
        'syntheticQaAssetsIncluded':not CLEAN_ENTRY,'companyConfigSanitized':True,'newDataPolicy':'LOCALAPPDATA/FangyuWorkbenchStandard/data',
        'productionBindingIncluded':False,'productionDataIncluded':False,'installerSourceSha256':sha(safe_read(INSTALLER_SOURCE))})
    print(json.dumps({'status':'STAGED_SAMPLE_ONLY','files':len(entries),'omitted':len(omitted)},ensure_ascii=True))


def build():
    report=js(SAMPLE/'STAGE.json')
    stdlib=js(SOURCE_INSPECT)['stdlibImports']
    base=[PYTHON,'-I','-B','-m','PyInstaller','--noconfirm','--clean','--distpath',DIST,
        '--workpath',SAMPLE/'pyinstaller','--specpath',SAMPLE]
    args=base+['--onedir','--windowed','--name',NAME]
    for name in ('webview','pythonnet','clr_loader','PIL','cryptography','tuf','securesystemslib','httpx'):
        args+=['--collect-all',name]
    for name in stdlib:args+=['--hidden-import',name]
    args+=['--copy-metadata','pywebview','--icon',BASE/'project/work/app/src/resources/brand.ico',SAMPLE/'standard_entry.py']
    run(args,'client-build.log')
    portable=DIST/NAME
    shutil.copytree(SAMPLE/'payload/project',portable/'project')
    shutil.copy2(SAMPLE/'payload/company.json',portable/'company.json')
    if INCLUDE_WEBVIEW2:
        prerequisite=P/'work/packaging/prerequisites/MicrosoftEdgeWebView2RuntimeInstallerX64.exe'
        if not prerequisite.is_file():raise RuntimeError('Existing Microsoft WebView2 offline prerequisite missing')
        (portable/'prerequisites').mkdir();shutil.copy2(prerequisite,portable/'prerequisites'/prerequisite.name)
    (portable/'使用说明.txt').write_text('方隅工作台\n\n双击 FangyuWorkbench.exe 打开。首次使用请用管理员分配的企业员工账号登录。\n本包不会提供其他电脑的登录状态或客户资料。\n\n本包为内部标准候选，尚未批准交给员工正式使用。\n视频制作需要已核验的外置 FFmpeg，本包不附该工具，也不会自动下载。\n需要电脑已有微软 WebView2；缺少时请联系管理员准备。\n','utf-8-sig')
    installer_copy=SAMPLE/'installer.original.py'
    with installer_copy.open('xb') as stream:stream.write(safe_read(INSTALLER_SOURCE))
    if sha(installer_copy.read_bytes())!=report['installerSourceSha256']:raise RuntimeError('Original installer changed')
    run(base+['--onefile','--windowed','--name','FangyuWorkbenchSetup','--icon',BASE/'project/work/app/src/resources/brand.ico',
        '--add-data',str(BASE/'project/work/app/src/resources/brand.ico')+';.',installer_copy],'installer-build.log')
    files=[]
    for path in sorted(portable.rglob('*')):
        if path.is_file():files.append({'path':path.relative_to(portable).as_posix(),'bytes':path.stat().st_size,'sha256':sha(path.read_bytes())})
    dump(SAMPLE/'FILE-MANIFEST.json',{'status':'REPRESENTATIVE_SAMPLE_ONLY','files':files,'count':len(files),
        'bytes':sum(row['bytes'] for row in files),'modelWeightsIncluded':False,'ffmpegBinaryIncluded':False,'venvIncluded':False})
    archive=SAMPLE/('FangyuWorkbench-'+SAMPLE.name+'.zip')
    with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=5) as z:
        for row in files:z.write(portable/row['path'],row['path'])
    setup=SAMPLE/('FangyuWorkbenchSetup-'+SAMPLE.name+'.exe')
    shutil.copy2(DIST/'FangyuWorkbenchSetup.exe',setup)
    with setup.open('ab') as stream,archive.open('rb') as source:shutil.copyfileobj(source,stream)
    with zipfile.ZipFile(setup) as z:
        bad=z.testzip()
        if bad:raise RuntimeError('Embedded original-installer payload corrupt')
    dump(SAMPLE/'BUILD.json',{'status':'REPRESENTATIVE_DISTRIBUTION_BUILT_NOT_APPROVED','files':len(files),
        'bytes':sum(row['bytes'] for row in files),'portableZip':archive.name,'portableSha256':sha(archive.read_bytes()),
        'installer':setup.name,'installerSha256':sha(setup.read_bytes()),'installerBytes':setup.stat().st_size,
        'originalInstallerUnmodified':True,'productionWrites':False,'localModelOrGpu':False,'bundledFfmpeg':False})
    print(json.dumps({'status':'REPRESENTATIVE_DISTRIBUTION_BUILT_NOT_APPROVED','files':len(files),'installerBytes':setup.stat().st_size},ensure_ascii=True))


def main():
    global SAMPLE,DIST,HELD_STANDARD,INCLUDE_WEBVIEW2,VERSION,BASE,CLEAN_ENTRY
    parser=argparse.ArgumentParser();parser.add_argument('--stage',action='store_true');parser.add_argument('--build',action='store_true')
    parser.add_argument('--held-standard',action='store_true');parser.add_argument('--slim',action='store_true')
    parser.add_argument('--version',type=int,choices=(70,71,72),default=70)
    parser.add_argument('--clean-entry',action='store_true')
    parser.add_argument('--revision',choices=('native','secured-native','qa2'))
    args=parser.parse_args()
    HELD_STANDARD=args.held_standard;INCLUDE_WEBVIEW2=not args.slim;VERSION=args.version;CLEAN_ENTRY=args.clean_entry
    BASE=P/('work/parallel-integration-20261018/final-integration/candidate-unified-v'+str(VERSION))
    if HELD_STANDARD:SAMPLE=HERE/('standard-held-sample-v'+str(VERSION));DIST=SAMPLE/'dist'
    if args.revision:SAMPLE=HERE/(SAMPLE.name+'-'+args.revision);DIST=SAMPLE/'dist'
    if CLEAN_ENTRY:SAMPLE=HERE/('standard-held-clean-v'+str(VERSION));DIST=SAMPLE/'dist'
    if args.stage:stage()
    if args.build:build()


if __name__=='__main__':main()
