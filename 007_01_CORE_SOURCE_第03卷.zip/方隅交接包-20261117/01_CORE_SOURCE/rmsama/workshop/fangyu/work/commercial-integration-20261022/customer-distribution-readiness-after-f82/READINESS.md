# 客户分发用途核对与后继范围

结论：F82 已是可运行、可安装的技术包，但普通 held 包的账号与平台读取用途尚未接成客户分发合同。实际 compiled 路径已修好，不能再归因为运行目录；也不能把 scope=None 当成云端账号已验证。用户已经授权实现商业分发，未缺重复的工程授权。

## 真实阻断

- 当前包的 HELD-STANDARD-MANIFEST 明确 channel=internal_standard_candidate、commercialDistributionApproved=False、platformExecutionApproved=False。兼容函数只允许加载 held 软件，不产生平台许可。
- 活动 vendor AppServer._runtime_license_usage_scope：frozen 当前包无 portable_employee_release，且不满足正式 employee 分发分支，返回 None。不能在 company.json 加旧 pilot/QA 标记使其变绿。
- PlatformRuntime 构造原 AppServer 时没有传 runtime_license_review / runtime_license_usage_scope；旧 _TrustedStartupRuntimeReview 又拒绝 frozen，并只接受 internal_self_use_read。
- 抖音账号 _components 与原评论 DouyinCommentsPolicy 明确要求 internal_self_use_read；账号 review、评论 review 是不同 purpose，均未进行客户分发审查。评论还固定原企业、主页面20条及原固定命令。
- 抖音关键词搜索的 review 默认 None、实际 review 文件不存在、frozen 被拒绝，search_verified=False。账号/评论分发不能顺带解锁搜索。
- RuntimeLicensePolicy 原 schema 真正支持 customer_distribution_read，按公司、route、实际 wrapper/exe/tree/guard、四份材料、review revision 绑定；它不是 HTTP 可输入的 scope 开关。
- XHS natural page read、identity observation、session recovery 是三个独立原合同，分别 source-only/internal、禁止 frozen 或客户分发。identity/session 不能借 read review 解锁，更不能借身份观察直接清风险或置账号 ready。

## 许可材料已核实与补齐

抖音实际 Bridge 保留 Yht20927 的完整 MIT 许可，可在保留版权与许可通知的条件下复制、修改、分发和销售。其 Node 依赖及现有通知材料仍要绑定实际分发字节；作者开源许可不是抖音平台账号、接口或自动化使用授权。[上游原许可](https://github.com/Yht20927/douyin-cli/blob/main/LICENSE)

XHS 当前本地 wheel 与 PyPI 0.6.4 资产完全相同，SHA256 为 7168c427e3b06ea069c505ab387da8b647fd7d292bcbb12474c00fc687fcb5bb。sdist 的28个源码与 wheel 全同；真正 v0.6.4 tag 为 368b1cf58e4c7548c82073b949577e38ed2cb39a，28个源码也全同。旧引用 4d63f3c0… 有4个源码不同，不应称为该 wheel 的 exact commit。

发布 wheel 的 License-Expression、sdist 的 pyproject、上游声明均为 Apache-2.0。完整非截断 tag 树、wheel、sdist 均无独立 LICENSE/NOTICE 文件；已记录不存在，而不是伪造原件。自有 public-materials 已保存原资产、原声明、官方 Apache 2.0 全文及关系证据。可以据此形成诚实的来源与许可补充材料：附官方标准全文、作者/版本/来源、改动说明，并说明上游本来没有独立 NOTICE；不拿另一个小红书项目的 MIT 代替。Apache 的 NOTICE 保留义务针对上游实际附带的 NOTICE，不要求捏造一个。[发布元数据](https://pypi.org/pypi/xiaohongshu-cli/0.6.4/json)、[官方条款](https://www.apache.org/licenses/LICENSE-2.0)

原 F82 四份 XHS 材料并非不存在：53份原许可解码哈希全同，291个编译依赖文件与实际 guarded runtime 全同。旧材料的 unresolved 记录可由上述诚实公开补充解决；原记录不修改。但旧 build evidence 明确 original_validator_checked=False、production_approval=False、running_loaded_bytes_verified=False；补许可不等于编译入口、真实 Native 或平台读取验收。

## 最小工程候选

先做抖音账号连接与原视频评论两个成熟且已具 MIT 原件的 purpose，保持旧 internal 分支及普通 held 缺省行为。

1. 新独立客户读取分发描述，固定 package/release、原企业环境、每 purpose 材料与实际运行根。使用真实材料与代表验证形成独立审查，不复制 internal review 改 scope；未知 Native/platform 证据如实保留，public_send_grant=False。
2. 受信 host 先按原 release/backend dependency 验证描述及 loader，再把不可由 HTTP/company/QA permit 选择的载体注入原 PlatformRuntime/AppServer。没有描述时仍 scope=None；错误描述立即拒绝，不退到 internal。
3. 原 _runtime_license_usage_scope 仅对该受信载体、当前准确企业配置与包闭包返回 customer_distribution_read。不得设置 release_approved、portable 标记，或虚构内部身份。
4. _components 与 CommentsPolicy 各自选择准确用途的分发 review，完整验证源/运行库/账号 overlay/固定命令/大小哈希/生命周期快照。原 main_page_only、max_comments=20、identity_before_after、禁 search/reply/dm 均保持。
5. 原企业 heartbeat、员工 DeviceSession、租户/门店权限、账号 UID 归属与连接、原 BrowserRegistry、锁、停止、revision/CAS/unknown 恢复继续逐次检查。材料通过不是账号或设备授权。
6. 搜索、XHS CLI、三个 natural purposes、DM/live 与发送单独审查；本候选不改其许可或公开发送 hold。

## 最难验收链与证据边界

真正 compiled host → 原 load_host/verify_backend_dependencies → 原 create_backend → host 载体 → 原 AppServer scope(customer) → 活动账号 _components → 原评论 resolve；用自有夹具走原 Core/Store/Node/Router，不启动 Native 窗口或访问平台。必须同时证实无描述 held=None；错企业、错用途、错材料、scope伪输入、旧 internal review 冒用拒绝；原员工/设备撤销、账号变更、锁/停止、CAS 不因此失效。

需区分：源码 factory 通过、真正编译入口通过、真实 Native 身份与登录通过、真实平台读通过、第二普通电脑通过。后四项中没有实证的部分不得写完成。新客户的自然登录、扫码/人脸、云端员工/设备注册须在本人可操作时实际验收，不能在工程中合成。当前没有证据表明平台已批准此商业自动化用途；开源许可与用户工程授权不能替代该外部事实。

本轮无生产凭据读取、无平台/模型请求、无本人窗口、无新费用、无产品/安装包改写，未生成批准值。后继候选由 root 另行安排独审与实际合版。
