"""Verify the already-tested archive/pins and write delivery evidence only."""
from __future__ import annotations
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parents[1]


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    verification = json.loads((ROOT / 'VERIFICATION.json').read_text('utf-8'))
    assert verification['offlineCandidateVerified']
    code = json.loads((ROOT / 'CANDIDATE-FILES.json').read_text('utf-8'))
    for row in code['files']:
        assert digest(ROOT / row['path']) == row['sha256'], row['path']
    archive_path = ROOT / 'content-model-gateway-candidate-v2.zip'
    with zipfile.ZipFile(archive_path) as archive:
        names = archive.namelist()
        assert len(names) == len(set(names)) == len(code['files'])+14
        for name in names:
            assert not Path(name).is_absolute() and '..' not in Path(name).parts
            assert hashlib.sha256(archive.read(name)).hexdigest() == digest(ROOT / name), name
    patch = json.loads((ROOT / 'PATCH-MANIFEST.json').read_text('utf-8'))
    assert patch['patchedTextMatchesTestedCandidate'] and all(c['exitCode'] == 0 for c in patch['checks'])
    result = {'asOfClientDate': '2026-10-23', 'checkedAtUtc': datetime.now(timezone.utc).isoformat(),
              'candidateRevision':2,'candidateComplete': True, 'productionDeployed': False, 'liveModelCalls': 0,
              'productionReadinessVerified':False,'liveCodeIdentityVerified':True,'liveCodeSha256':verification['liveCodeSha256'],
              'scope': str(ROOT), 'sourceFilesUnchanged': verification['authoritativeSourceFilesUnchanged'],
              'testedCandidateCodeFiles': len(code['files']),'serverModifiedFiles':patch['modifiedServerFiles'],'serverAddedFiles':patch['newServerFiles'],
              'clientAddedFiles':3,'checks':verification['checks'],
              'historicalContractAssertionsMatchActualLive':verification['historicalContractAssertionsMatchActualLive'],
              'existingServiceFailuresUnchanged':verification['existingServiceFailuresUnchanged'],
              'priorV1Archive':{'path':'content-model-gateway-candidate.zip','sha256':digest(ROOT/'content-model-gateway-candidate.zip'),'superseded':True},
              'package': {'path': archive_path.name, 'bytes': archive_path.stat().st_size,
                          'sha256': digest(archive_path), 'entriesChecked': len(names)},
              'patch': {'path': 'integration.patch', 'sha256': digest(ROOT / 'integration.patch'),
                        'isolatedApplyCheckPassed': True},
              'remainingIntegration': ['Real private tenant/store/account/device mapping remains unknown; explicit server enable not performed',
                                       'Native public original-task reconcile, full closure freeze and integration',
                                       'Real CloudBase/Node20.19 and model quality validation',
                                       'Douyin authoritative binding not available: denied']}
    (ROOT / 'DELIVERY.json').write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
    paths = [ROOT / name for name in names]
    paths += [ROOT / 'DELIVERY.json', archive_path, ROOT / 'verify_candidate.py']
    paths += sorted((ROOT / 'tools').glob('*.py')) + sorted((ROOT / 'tests').glob('*.cjs')) + sorted((ROOT / 'tests').glob('*.py'))
    paths = sorted(set(paths))
    hashes = [{'path': str(path.relative_to(ROOT)).replace('\\', '/'), 'sha256': digest(path), 'bytes': path.stat().st_size} for path in paths]
    (ROOT / 'FILES-SHA256.json').write_text(json.dumps(hashes, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps(result, ensure_ascii=False))


if __name__ == '__main__':
    main()
