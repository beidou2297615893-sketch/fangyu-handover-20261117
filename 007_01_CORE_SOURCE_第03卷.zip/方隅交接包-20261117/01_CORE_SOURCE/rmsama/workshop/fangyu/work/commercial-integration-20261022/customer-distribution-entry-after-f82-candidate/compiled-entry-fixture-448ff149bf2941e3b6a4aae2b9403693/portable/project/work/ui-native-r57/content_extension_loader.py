"""Load only host-pinned bytes into a private content-workflow package.

The host, not a candidate-directory manifest, supplies the four source pins.
Sources are read once, kept open, verified and compiled from those same bytes.
This verifies a trusted local closure; it is not a sandbox for arbitrary code.
"""
from __future__ import annotations

import hashlib
import importlib.machinery
import json
import os
from pathlib import Path
import re
import stat
import sys
import threading
import types
import uuid

SOURCES = ('content_workbench.py', 'workflow_methods.py',
           'workflow_knowledge.py', 'public_search_provider.py', 'public_research_workbench.py', 'content_workflow.py',
           'publishing_dom_methods.py', 'publishing_port.py', 'content_publishing.py', 'content_schedule.py', 'publication_protocol.py', 'publication_authority_host.py', 'owned_publication_host.py', 'publication_policy.py')
RESOURCES = ('public_research_vendor/click-license-0.txt', 'public_research_vendor/ddgs-license-0.txt', 'public_research_vendor/DEPENDENCY-PINS.json', 'public_research_vendor/LICENSE-primp.txt', 'public_research_vendor/lxml-license-0.txt', 'public_research_vendor/lxml-license-1.txt',
             'content_vendor/check_copy.py', 'content_vendor/diagnose_metrics.py',
             'content_vendor/LICENSE-xintu.txt', 'content_vendor/method-bundle.json',
             'workflow_vendor/normalize.py', 'workflow_vendor/LICENSE', 'workflow_vendor/PINS.json',
             'publishing_vendor/LICENSE-white0dew',
             'guided_vendor/manifest.json', 'guided_vendor/LICENSE-agency.txt', 'guided_vendor/roles-01.json', 'guided_vendor/roles-02.json', 'guided_vendor/roles-03.json', 'guided_vendor/roles-04.json', 'guided_vendor/roles-05.json', 'guided_vendor/roles-06.json', 'guided_vendor/roles-07.json')
_CACHE = {}
_LOCK = threading.RLock()
_MAX_FILE_BYTES = 1_000_000


class ContentExtensionLoadError(RuntimeError):
    code = 'CONTENT_EXTENSION_UNAVAILABLE'
    status = 503


def _reparse(info):
    return bool(getattr(info, 'st_file_attributes', 0) & 0x400)


def _file_signature(info):
    if not stat.S_ISREG(info.st_mode) or _reparse(info) or info.st_nlink != 1:
        raise ValueError('unsafe_file')
    return (info.st_dev, info.st_ino, info.st_mode, info.st_size,
            info.st_mtime_ns, info.st_nlink, getattr(info, 'st_file_attributes', 0))


def _directory_signature(info):
    if not stat.S_ISDIR(info.st_mode) or _reparse(info):
        raise ValueError('unsafe_directory')
    # Unrelated additions may change directory times but cannot change identity.
    return info.st_dev, info.st_ino, info.st_mode


def _open_source(path):
    if os.name != 'nt':
        return os.open(path, os.O_RDONLY | getattr(os, 'O_NOFOLLOW', 0))
    # Open the final component itself and deny write/delete sharing until the
    # verified closure has executed. A file replacement cannot race a reread.
    import ctypes
    from ctypes import wintypes
    import msvcrt
    kernel = ctypes.WinDLL('kernel32', use_last_error=True)
    create = kernel.CreateFileW
    create.argtypes = (wintypes.LPCWSTR, wintypes.DWORD, wintypes.DWORD,
                       ctypes.c_void_p, wintypes.DWORD, wintypes.DWORD, wintypes.HANDLE)
    create.restype = wintypes.HANDLE
    handle = create(str(path), 0x80000000, 1, None, 3, 0x00200000, None)
    if handle == ctypes.c_void_p(-1).value:
        raise OSError(ctypes.get_last_error(), 'trusted source could not be opened')
    try:
        return msvcrt.open_osfhandle(handle, os.O_RDONLY | getattr(os, 'O_BINARY', 0))
    except BaseException:
        close = kernel.CloseHandle
        close.argtypes, close.restype = (wintypes.HANDLE,), wintypes.BOOL
        close(handle)
        raise


class _ClosureRead:
    def __init__(self, directory):
        self.directory = directory
        self.directories = {}
        self.files = {}

    def chain(self, path):
        for parent in reversed(path.parents):
            info = parent.lstat()
            if parent.is_symlink():
                raise ValueError('linked_parent')
            signature = _directory_signature(info)
            previous = self.directories.setdefault(parent, signature)
            if previous != signature:
                raise ValueError('directory_changed')

    def read(self, relative, expected=None):
        path = self.directory / relative
        self.chain(path)
        before = path.lstat()
        if path.is_symlink() or not 0 < before.st_size <= _MAX_FILE_BYTES:
            raise ValueError('invalid_source')
        signature = _file_signature(before)
        fd = _open_source(path)
        self.files[path] = (fd, signature)
        if _file_signature(os.fstat(fd)) != signature:
            raise ValueError('opened_file_changed')
        parts, total = [], 0
        while True:
            block = os.read(fd, 65_536)
            if not block:
                break
            parts.append(block)
            total += len(block)
            if total > _MAX_FILE_BYTES:
                raise ValueError('source_too_large')
        raw = b''.join(parts)
        if len(raw) != signature[3] or (expected is not None and hashlib.sha256(raw).hexdigest() != expected):
            raise ValueError('host_pin_mismatch')
        self.audit()
        return raw

    def audit(self):
        for path, signature in self.directories.items():
            if path.is_symlink() or _directory_signature(path.lstat()) != signature:
                raise ValueError('directory_changed')
        for path, (fd, signature) in self.files.items():
            if (path.is_symlink() or _file_signature(path.lstat()) != signature
                    or _file_signature(os.fstat(fd)) != signature):
                raise ValueError('file_changed')

    def close(self):
        for fd, _ in reversed(tuple(self.files.values())):
            os.close(fd)
        self.files.clear()


def _module(package, name, path, code):
    qualified = package.__name__ + '.' + name
    module = types.ModuleType(qualified)
    module.__file__ = str(path)
    module.__package__ = package.__name__
    module.__spec__ = importlib.machinery.ModuleSpec(qualified, loader=None, origin=str(path))
    # Dataclass definitions and relative imports resolve this exact namespace.
    sys.modules[qualified] = module
    setattr(package, name, module)
    exec(code, module.__dict__)
    return module


def load_extension(directory: Path, expected_pins: dict):
    """Return ContentWorkflowWorkbench from a complete, host-pinned directory.

    ``expected_pins`` is exactly {source_filename: sha256_hex} for SOURCES. Local
    PINS files cannot authorize source changes. The supplied directory must be
    absolute, have no '..', and contain the fixed source/resource closure.
    """
    guard = None
    namespace = None
    with _LOCK:
        try:
            if type(expected_pins) is not dict:
                raise ValueError('invalid_host_pins')
            host_pins = dict(expected_pins)
            if (set(host_pins) != set(SOURCES)
                    or any(type(v) is not str or re.fullmatch(r'[0-9a-fA-F]{64}', v) is None
                           for v in host_pins.values())):
                raise ValueError('invalid_host_pins')
            pins = {name: host_pins[name].lower() for name in SOURCES}
            directory = Path(directory)
            if not directory.is_absolute() or '..' in directory.parts:
                raise ValueError('absolute_directory_required')
            guard = _ClosureRead(directory)
            raw = {name: guard.read(name, pins[name]) for name in SOURCES}
            resources = {name: guard.read(name) for name in RESOURCES}
            cache_key = (str(directory), tuple(pins.items()),
                         tuple((name, hashlib.sha256(data).hexdigest()) for name, data in resources.items()))
            if cache_key in _CACHE:
                guard.audit()
                return _CACHE[cache_key]
            # Compile only the bytes checked above; do not ask an import loader
            # to reopen a checked path, read pycache, or consult the process CWD.
            compiled = {name: compile(data, str(directory / name), 'exec') for name, data in raw.items()}
            namespace = '_fangyu_content_extension_' + uuid.uuid4().hex
            package = types.ModuleType(namespace)
            package.__package__ = namespace
            package.__path__ = [str(directory)]
            package.__file__ = str(directory / '__init__.py')
            package.__spec__ = importlib.machinery.ModuleSpec(namespace, loader=None, is_package=True)
            package.__spec__.submodule_search_locations = [str(directory)]
            sys.modules[namespace] = package
            modules = {}
            for name in SOURCES:
                stem = name[:-3]
                modules[stem] = _module(package, stem, directory / name, compiled[name])
                guard.audit()
            base = modules['content_workbench']
            for name, pin in base.VENDOR_PINS.items():
                if hashlib.sha256(resources['content_vendor/' + name]).hexdigest() != pin:
                    raise ValueError('base_vendor_changed')
            knowledge = modules['workflow_knowledge']
            contract = knowledge._PIN_CONTRACT
            if json.loads(resources['workflow_vendor/PINS.json']) != contract:
                raise ValueError('knowledge_manifest_changed')
            for name, record in contract['files'].items():
                if hashlib.sha256(resources['workflow_vendor/' + name]).hexdigest() != record['sha256']:
                    raise ValueError('knowledge_vendor_changed')
            for name, expected in modules['content_workflow'].ContentWorkflowWorkbench.GUIDED_RESOURCE_PINS.items():
                if name not in resources or hashlib.sha256(resources[name]).hexdigest()!=expected:
                    raise ValueError('guided_resource_changed')
            cls = modules['content_schedule'].ContentScheduleWorkbench
            if not isinstance(cls, type) or not issubclass(cls, base.ContentWorkbench):
                raise ValueError('invalid_extension_class')
            if hashlib.sha256(resources['publishing_vendor/LICENSE-white0dew']).hexdigest() != '59fe3847a53ba1887150e7c6c9814aaa3c0c252ad61364a5a7841f05f5e81626':
                raise ValueError('publication_license_changed')
            guard.audit()
            _CACHE[cache_key] = cls
            return cls
        except BaseException as error:
            if namespace is not None:
                for name in tuple(sys.modules):
                    if name == namespace or name.startswith(namespace + '.'):
                        sys.modules.pop(name, None)
            if not isinstance(error, Exception):
                raise
            raise ContentExtensionLoadError('内容工作流组件未通过完整性核验，请保留原稿并完整更新') from None
        finally:
            if guard is not None:
                guard.close()
