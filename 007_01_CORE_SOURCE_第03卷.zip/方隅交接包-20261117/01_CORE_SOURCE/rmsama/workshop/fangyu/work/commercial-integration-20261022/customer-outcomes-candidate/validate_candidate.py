from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,subprocess,sys
W=Path(__file__).resolve().parent
P=Path('C:/积木软件工坊/项目/方隅公寓客户版');N=P/'work/ui-native-r57'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
protected=['run_workbench.py','FROZEN.json','state/production-workspace.json']
before={x:sha(N/x) for x in protected}
env={**os.environ,'PYTHONUTF8':'1','PYTHONDONTWRITEBYTECODE':'1'}
results=[]
def run(label,args):
    r=subprocess.run(args,cwd=W,env=env,capture_output=True,timeout=60)
    (W/(label+'.log')).write_bytes(r.stdout+r.stderr)
    if r.returncode:raise RuntimeError(label+' failed; see preserved log')
    results.append({'label':label,'exitCode':r.returncode,'logSha256':sha(W/(label+'.log'))})
run('PACKAGE',[sys.executable,str(W/'package_candidate.py')])
for p in (W/'candidate/work/ui-native-r57').glob('*.py'):compile(p.read_bytes(),str(p),'exec')
run('CORE-TESTS',[sys.executable,str(W/'test_outcomes.py')])
run('HTTP-TESTS',[sys.executable,str(W/'test_native_http.py')])
run('MAKE-UI-FIXTURE',[sys.executable,str(W/'make_ui_fixture.py')])
run('UI-HARNESS',[sys.executable,str(W/'prepare_ui_harness.py')])
for p in (W/'candidate/work/ui-approved-implementation/ui-preview').rglob('*.mjs'):run('SYNTAX-'+p.stem,['node','--check',str(p)])
run('DOM-TESTS',['node',str(W/'test_ui.mjs')])
after={x:sha(N/x) for x in protected};assert after==before
report={'timestampUtc':datetime.now(timezone.utc).isoformat(),'status':'PASS_CANDIDATE_ROOT_MERGE_CUA_PENDING','coreStoreBehaviorTests':12,'nativeHttpGroups':json.loads((W/'HTTP-RESULTS.json').read_text(encoding='utf-8'))['passed'],'actualDomRenderBindGroups':json.loads((W/'UI-RESULTS.json').read_text(encoding='utf-8'))['passed'],'runs':results,'packageSha256':sha(W/'PACKAGE.json'),'patchSha256':sha(W/'CHANGES.patch'),'protectedBefore':before,'protectedAfter':after,'protectedUnchanged':True,'productionWrites':0,'realCustomerDataOrSessionsRead':False,'realPlatformOrModelCalls':0,'applicationStarted':False,'browserVisualAccepted':False,'sourceMerged':False}
(W/'VALIDATION.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in report.items() if k!='runs'},ensure_ascii=True))
