"""Own synthetic SQLite/vault only; no real user profile, service or platform."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,importlib.util,json,sqlite3,sys,uuid
sys.dont_write_bytecode=True
D=Path(__file__).resolve().parent
P=D.parents[2];C=D.parent/'next-release-f82-expansion-composition/project'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    module=importlib.util.module_from_spec(spec);sys.modules[name]=module;spec.loader.exec_module(module);return module
support_path=C/'work/ui-native-r57/workspace_binding.py'
integrations_path=C/'work/ui-runtime-r55/src/integrations.py'
support=load('own_original_workspace_binding',support_path)
integrations=load('own_original_integrations_for_synthetic_vault',integrations_path)
entry=load('own_existing_workspace_entry',D/'existing_workspace_entry.py')
T=D/('own-fixture-'+uuid.uuid4().hex);T.mkdir()
root=T/'existing-project';state=root/'work/ui-native-r57/state';state.mkdir(parents=True)
data=T/'existing-data';data.mkdir();(data/'assistant').mkdir()
db=data/'workspace.sqlite3'
with sqlite3.connect(db) as connection:
    connection.execute('CREATE TABLE existing_rows (id TEXT PRIMARY KEY, body TEXT NOT NULL)')
    connection.executemany('INSERT INTO existing_rows VALUES (?,?)',[(str(i),'仅自有合成客户'+str(i)) for i in range(3)])
vault=data/'assistant/device.dpapi'
metadata={'state':'bound','token':'OwnSyntheticDeviceToken_12345678901234567890123456789',
    'company_id':'fangyu-apartment-client','environment_id':'own-fixture-env',
    'device':{'id':'OwnSyntheticDevice_1234567890','owner':'own-fixture-user'}}
vault.write_bytes(integrations.protect(json.dumps(metadata).encode()))
descriptor=state/'production-workspace.json'
binding={'schema':'fangyu-production-workspace-v1','company_id':'fangyu-apartment-client',
    'data_dir':str(data),'device_id':metadata['device']['id'],'owner':metadata['device']['owner'],'environment_id':metadata['environment_id']}
def write_binding(value):descriptor.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n','utf-8')
write_binding(binding)
before={str(p.relative_to(T)):sha(p) for p in [db,vault,descriptor]}
groups=[]
def rejected(fn):
    try:fn()
    except (entry.ExistingWorkspaceSelectionError,support.WorkspaceBindingError,FileNotFoundError):return
    raise AssertionError('Expected original closed selection')
assert entry.select_existing_workspace(None,None,support) is None
groups.append('ordinary default does not discover or create another workspace')
assert entry.select_existing_workspace(str(root),sha(descriptor),support)==(data,state)
groups.append('explicit pinned existing root reuses original SQLite and actual native DPAPI metadata check')
for r,h in [(None,sha(descriptor)),(str(root),None),('relative/path',sha(descriptor)),(str(root),'f'*64)]:
    rejected(lambda r=r,h=h:entry.select_existing_workspace(r,h,support))
groups.append('missing or changed settings never fall back to empty directories')
write_binding({**binding,'company_id':'other-company'})
rejected(lambda:entry.select_existing_workspace(str(root),sha(descriptor),support))
write_binding(binding)
groups.append('original company isolation rejects foreign descriptor')
oldvault=vault.read_bytes()
vault.write_bytes(integrations.protect(json.dumps({**metadata,'device':{**metadata['device'],'id':'DifferentOwnDevice_1234567890'}}).encode()))
rejected(lambda:entry.select_existing_workspace(str(root),sha(descriptor),support))
vault.write_bytes(oldvault)
groups.append('original DPAPI device mismatch is not treated as migration or enrollment')
dbraw=db.read_bytes();db.write_bytes(b'not a sqlite database')
rejected(lambda:entry.select_existing_workspace(str(root),sha(descriptor),support))
db.write_bytes(dbraw)
groups.append('missing or invalid old database cannot create a new workspace')
assert entry.select_existing_workspace(str(root),sha(descriptor),support)==(data,state)
after={str(p.relative_to(T)):sha(p) for p in [db,vault,descriptor]}
assert before==after
with sqlite3.connect(db.as_uri()+'?mode=ro',uri=True) as connection:
    assert connection.execute('SELECT COUNT(*) FROM existing_rows').fetchone()[0]==3
result={'status':'PASS_SYNTHETIC_EXISTING_WORKSPACE_SELECTION','utc':datetime.now(timezone.utc).isoformat(),
    'groups':groups,'groupCount':len(groups),'beforeAfterExact':True,'syntheticRowsPreserved':3,
    'adapterSha256':sha(D/'existing_workspace_entry.py'),'originalWorkspaceBindingSha256':sha(support_path),
    'originalIntegrationsSha256':sha(integrations_path),'actualNativeDpapi':True,
    'originalServiceBindOrCloudLeaseMigrationTested':False,'actualMainExeTested':False,
    'realProfilesOrSessionsRead':False,'productionOrFormalWritten':False,'allServicePlatformOrModelCalls':0,
    'requiredNext':'Embed into clean compiled entry with verified shipped support source; test actual compiled default and explicit existing workspace paths, then old bound Service/token upgrade.'}
(D/'EXISTING-SELECTION-RESULTS.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n','utf-8')
print(json.dumps(result,ensure_ascii=False))
