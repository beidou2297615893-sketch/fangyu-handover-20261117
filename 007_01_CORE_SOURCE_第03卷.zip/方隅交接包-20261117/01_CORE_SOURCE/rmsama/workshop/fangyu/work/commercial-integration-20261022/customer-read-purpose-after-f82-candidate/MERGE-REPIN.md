# 合版与重新固定顺序

这是独立候选，未写正式目录。源码候选共7个 Python（6个有界原源、1个新 carrier）及4份新用途 JSON。freeze_ui.py 仅可选复制新 loader 与 customer-read JSON；无 index 不建立载体。

当前4份 JSON 是针对本候选自有 F82 派生实际运行根制作的真实材料样本，不是任意后继版本的通用许可。root 合版后须重算：

1. 先将有界源改动合进 root 自己的 composition，保原 work/app 镜像不被顺带改写；原 internal scope/purpose/limits/evidence、DM/live 门保持原值。原账号 _binding、_DouyinConnectionCall 和 DouyinConnectionService AST 均未改。
2. 原依赖图中的 SOURCE 映射、评论/连接等 internal reviews、DM7/live14、原 helper/consumer pins 需要按合后实际字节重算。新用途不会替代旧 review；不能因新用途通过就声称旧 internal 引用闭包自动有效。复用 combined-bridge-final-pin-review 的精确用途图而不是全局替换 scope。
3. 原 freezer 把新 loader 和新文档复制到准确 active release/resources。backend-dependencies 仍准确指向 canonical r55/src；新客户分发材料另绑定 canonical 与实际 active vendor 两侧。不要把 work/app 同名镜像认成活动账号接点。
4. 普通包原 held 兼容 manifest 仍保持原3个 False 决策，只按成熟 builder 重新计算代码清单与其生成 helper 的固定 SHA。新 scope 不是通过 portable/QA 标记、release_approved=True 或去掉 hold 产生的。
5. 最终派生公司版本/实际 Native release ID/活动 helper 稳定后，重新生成每 purpose 新 review 的真实材料路径、大小、SHA 与 company_binding，再生成 index。声明 source/许可审查及已有证据层；尚无 Native/平台证据仍明确 False。原 RuntimeLicensePolicy 需要的 CLI exe/tree 不与主 EXE 混淆。
6. 重新计算 RELEASE、SHIPPED，随后编译原 standard entry；主 EXE 外层封包固定，index 不反向包含该 EXE 的 SHA，避免自引用环。最终实际 compiled 再跑原 factory/正常云端设备合同边界与拒绝链，不能把本候选的成功代替合后成功。

XHS 后继只沿 INTERFACE.md 的 runtime_license_review(server,'xiaohongshu_guarded_read') 返回原 schema 与原 frozen exe material_root；其当前 pending review 可以被构造器接受，但绝不据此解锁 internal_qa_only guard 或自然身份/会话用途。抖音搜索、公开发送、DM/live 合同本候选均未放权。

本候选的源码写入统一了换行，AST-BOUNDARY-AUDIT 明确没有冒称全文件旧字节等价。CANDIDATE.patch 为有界逻辑 hunk；root 可按原文件换行应用这些 hunk，再对实际最终字节作完整 repin。
