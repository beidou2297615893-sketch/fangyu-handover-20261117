"""Exact bounded derivation of reviewed builder; never invokes it."""
from pathlib import Path
import ast,difflib,hashlib,json,shutil
C=Path(__file__).resolve().parent;W=C.parent;OLD=W/'f82-standard-package-candidate';ENTRY=W/'customer-distribution-entry-after-f82-candidate'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
source=OLD/'build_clean_next.py';assert sha(source)=='4e686e224c64a06f13cd6fbd448af7bddc2106b8b092d567b94f36bb2e36cfd8'
if (C/'build_clean_next.py').exists():raise RuntimeError('Keep prior derived tool')
before=source.read_text('utf8');text=before
for name in ('standard_entry.py.in','held_standard_contract.py.in'):
 shutil.copy2(OLD/name,C/name)
for name in ('adapt_clean_entry.py','existing_workspace_entry.py'):shutil.copy2(ENTRY/name,C/name)
assert sha(C/'adapt_clean_entry.py')=='4b41e4d4c5ec1bcaafbb17c41b1489d15429a5b1313586ec56a467acc8a8b405'
assert sha(C/'existing_workspace_entry.py')=='58cd9c8066533eb9196ef69fcad325bd0be9fb47a333dbf236d5b776bac3b33a'
text=text.replace('import argparse, ast, hashlib, importlib.util, json, os, shutil, stat, subprocess, sys, zipfile','import argparse, ast, hashlib, importlib.util, json, os, re, shutil, stat, subprocess, sys, zipfile')
text=text.replace("BASE=P/'work/parallel-integration-20261018/final-integration/candidate-unified-v82'","BASE=None # Requires the caller's explicit new final root pins and path.")
text=text.replace('VERSION=82\n','VERSION=None\n')
text=text.replace("company['releaseVersion']='r57-standard-internal-v'+str(VERSION)","company['releaseVersion']=RELEASE_VERSION")
text=text.replace("    if VERSION!=82 or ROOT_PINS is None:raise RuntimeError('Root final v82 pins required')","    _validate_root_inputs()")
start=text.index('    entries=[]\n',text.index('def stage():'))
end=text.index('\n\ndef build():',start)
new_end='''    release=project/'work/ui-native-r57/releases'/release_id
    _company_held(company)
    _held_stable(project,release)
    helper=_verify_helper(project,release)
    _copy_external_cli()
    dump(SAMPLE/'STAGE.json',{'status':'CLEAN_HELD_STAGED_AWAITING_PURPOSE_MATERIALS_NOT_BUILDABLE',
        'releaseId':release_id,'sourceClosureSha256':sha(raw),'rootPinsSha256':ROOT_PINS_SHA,
        'externalDescriptorSha256':EXTERNAL_INPUTS_SHA,'copiedSourceFiles':len(copied),
        'omittedDescriptors':omitted,'derivedFiles':derived,'companyVersion':RELEASE_VERSION,
        'companySha256':sha(safe_read(project/'work/app/company.json')),
        'heldManifestSha256':sha(safe_read(project/'HELD-STANDARD-MANIFEST.json')),
        'helper':helper,'syntheticQaAssetsIncluded':False,'cleanEntry':True,
        'globalReleaseApproved':False,'publicSendHold':True,'productionBindingIncluded':False,
        'productionDataIncluded':False,'installationApproved':False,
        'installerSourceSha256':sha(safe_read(INSTALLER_SOURCE))})
    print(json.dumps({'status':'STAGED_AWAITING_MATERIALS_NOT_BUILDABLE','files':len(copied),
        'companyVersion':RELEASE_VERSION,'payloadRoot':str(SAMPLE/'payload')},ensure_ascii=True))
'''
text=text[:start]+new_end+text[end:]
text=text.replace('def build():\n    report=js(SAMPLE/\'STAGE.json\')',"def build():\n    _require_finalized()\n    report=js(SAMPLE/'STAGE.json')")
text=text.replace("    shutil.copytree(SAMPLE/'payload/project',portable/'project')\n    shutil.copy2(SAMPLE/'payload/company.json',portable/'company.json')", "    # Only these two fixed closed code roots and the sanitized company copy.\n    # Natural helper remains inside project; no new sibling is invented.\n    for member in ('project','platform-cli-customer-read'):\n        shutil.copytree(SAMPLE/'payload'/member,portable/member)\n    shutil.copy2(SAMPLE/'payload/company.json',portable/'company.json')")
old="""    files=[]
    for path in sorted(portable.rglob('*')):
        if path.is_file():files.append({'path':path.relative_to(portable).as_posix(),'bytes':path.stat().st_size,'sha256':sha(path.read_bytes())})"""
assert text.count(old)==1;text=text.replace(old,'    files=_inventory(portable)')
old_main=text.index('\ndef main():\n')
text=text[:old_main]+'\n'+(C/'successor_sections.py.in').read_text('utf8')
text=text.replace('"""Clean held v82 distribution; all writes stay in this new owned tooling directory.', '"""Clean held successor tooling; all writes stay in this new owned directory.')
ast.parse(text);compile(text,'derived-builder','exec')
(C/'build_clean_next.py').write_text(text,'utf8')
(C/'BUILDER-DIFF.patch').write_text(''.join(difflib.unified_diff(before.splitlines(keepends=True),text.splitlines(keepends=True),fromfile='a/f82/build_clean_next.py',tofile='b/successor/build_clean_next.py',n=3)),'utf8')
old_tree=ast.parse(before);new_tree=ast.parse(text);funcs=lambda tree:{n.name:ast.dump(n,include_attributes=False) for n in tree.body if isinstance(n,ast.FunctionDef)}
original=funcs(old_tree);derived=funcs(new_tree);changes={n:original[n]==derived.get(n) for n in original}
inputs=[source,OLD/'standard_entry.py.in',OLD/'held_standard_contract.py.in',ENTRY/'adapt_clean_entry.py',ENTRY/'existing_workspace_entry.py']
result={'sourceBuilderSha256':sha(source),'derivedBuilderSha256':sha(C/'build_clean_next.py'),'originalFunctionAstIdentical':changes,'expectedChangedOriginalFunctions':['stage','build','main'],'protectedInstallerStillFixedSha256':'5f9b4d7ab00b6348d07d15a241ad804cf593ec137d576e5a3ce67476df01dca9','inputs':[{'path':str(p),'sha256':sha(p),'bytes':p.stat().st_size} for p in inputs],'actualFinalRootPinsProvided':False,'actualSuccessorStaged':False,'actualSuccessorBuilt':False}
assert {n for n,equal in changes.items() if not equal}=={'stage','build','main'}
(C/'DERIVATION.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n','utf8')
print(json.dumps({'derivedSha256':result['derivedBuilderSha256'],'originalFunctionAstIdentical':changes,'actualStageOrBuild':False}))
