from pathlib import Path
import hashlib,json,shutil,subprocess
W=Path(__file__).resolve().parent;B=W.parent;P=W.parents[2];C=B/'content-schedule-execution-candidate'
F=P/'work/parallel-integration-20261018/final-integration/candidate-unified-v79';OLD=F.parent/'candidate-unified-v77/project'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(C/'SEALED.json')=='f2bb58eabc75948fa502eb50c8e20d79e2707dafba4ddb5c7db8ba740f03f0bf'
assert sha(C/'FINAL-RECEIPT.json')=='e7166a7bd9be6953080ec68039b5cbe77876359447fe6c590b5bd3ac350b7638'
assert sha(C/'SOURCE-FILES.json')=='b59840aaf2ede05083a95d7008fb0cb71fcd4298a138d9826e0fba2f4dcff650'
D=B/'delivery-v79/FINAL-PINS.json';assert sha(D)=='3719840ea39dfe4874fe800f48fe9b58a92987649bd524a39b8074816b6efd64'
pins=json.loads(D.read_text('utf-8'));assert sha(F/'UNIFIED-PINS.json')==pins['unifiedPinsSha256']
manifest=json.loads((F/'UNIFIED-PINS.json').read_text('utf-8'));S=F/'project';assert len(manifest['files'])==3308
for row in manifest['files']:assert sha(S/row['path'])==row['sha256']
source=json.loads((C/'SOURCE-FILES.json').read_text('utf-8'));out=W/'merged-inputs';out.mkdir();scratch=W/'merge-conflicts';scratch.mkdir();rows=[]
for row in source['files']:
 rel=row['path'];theirs=C/'overlay'/rel;assert sha(theirs)==row['afterSha256'];ours=S/rel;base=OLD/rel;dst=out/rel;dst.parent.mkdir(parents=True,exist_ok=True)
 if row['beforeSha256'] is None:
  assert not ours.exists();dst.write_bytes(theirs.read_bytes());status='new'
 else:
  assert sha(base)==row['beforeSha256']
  r=subprocess.run(['git','merge-file','-p','--diff3',str(ours),str(base),str(theirs)],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
  assert r.returncode in (0,1),(rel,r.returncode,r.stderr.decode(errors='replace'))
  if r.returncode:
   (scratch/(Path(rel).name+'.conflict')).write_bytes(r.stdout);status='conflict';dst.write_bytes(ours.read_bytes())
  else:
   text=r.stdout.decode().replace('\r\n','\n');eol='\r\n' if ours.read_bytes().count(b'\r\n') else '\n';dst.write_bytes(text.replace('\n',eol).encode());status='merged-clean'
 rows.append({'path':rel,'f77Before':row['beforeSha256'],'f79Before':sha(ours) if ours.exists() else None,'sealedG11After':sha(theirs),'mergeStatus':status,'mergedSha256':sha(dst)})
(W/'MERGE-PREPARATION.json').write_text(json.dumps({'exactF79RootPinsSha256':sha(D),'source':'sealed G11 overlay only','rows':rows},ensure_ascii=False,indent=2)+'\n','utf-8')
shutil.copyfile(D,W/'BASE-FINAL-PINS.json')
print(json.dumps({'files':len(rows),'conflicts':[r['path'] for r in rows if r['mergeStatus']=='conflict'],'f79ChangedSince77':[r['path'] for r in rows if r['f77Before']!=r['f79Before']]},ensure_ascii=False))
