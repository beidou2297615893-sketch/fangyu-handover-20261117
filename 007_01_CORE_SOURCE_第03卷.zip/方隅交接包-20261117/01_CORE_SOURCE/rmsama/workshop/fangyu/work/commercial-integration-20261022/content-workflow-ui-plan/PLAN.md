# 内容工作流回接现有页面：最小实施计划

范围：只读当前候选与已认可新增页面，未改 stage、冻结候选或作者文件。快照摘要见 SNAPSHOT.json；作者仍可能继续修改，接入前按摘要重读差异。

已实际读取 codebase-design、social-ops-components 两项 Skill，沿用同一 ContentWorkbench Interface 和已核实的 MIT 归一化模块，不增加第二个软件、客户库、模型下载或发布执行器。

## 产品入口

保留已经认可的“账号人设 / 选题 / 内容创作 / 草稿与发布 / 复盘”五个页签与浅蓝绿色、左编右预览布局。顶部继续清楚显示门店、平台和账号昵称。

新增一个轻量的“资料与引用”入口管理本账号文本资料；每个现有页签放与当前工作相关的方法按钮。方法打开同一套任务面板：填写主题 → 选择资料 → 核对任务 → 执行 → 查看结果 → 人工采用。任务记录持久保留，不把 17 项代码目录直接堆给用户。

每个任务表单只让用户提供：主题、补充要求、可选当前选题/原稿、可选资料片段/前序产物。右侧显示本次将使用的资料原文、资料标签、来源名称和账号；后端已有权限与来源摘要负责执行核验。请求编号、Schema、digest 只留内部。

## 17 类方法落点

| 方法 ID | 现有页签和入口 | 结果显示 / 采用后的实际变化 |
|---|---|---|
| strategy | 账号人设 → 运营策略 | 受众、定位备选、渠道作用、里程碑；保存为本账号方案，不自动改人设 |
| persona | 账号人设 → 生成定位候选 | 与现有人设并排核对；“采用这版人设”写入原 persona 与版本历史 |
| homepage | 账号人设 → 主页建议 | 昵称、简介、置顶内容、视觉建议；保存方案，不修改平台主页 |
| research | 选题 → 基于资料研究 | 发现、引用和资料缺口；当前为已导入资料研究，不能标“已联网调研” |
| columns | 选题 → 栏目规划 | 栏目和节奏方案；采用后保留在方案区，可继续作为选题前序输入 |
| topics | 选题 → 生成选题 | 标题、栏目、形式、受众问题与引用；采用后进原选题池，保持原编辑/用此选题入口 |
| writing | 内容创作 → 生成图文草稿 | 标题、正文、标签与引用；采用后进原 draft，status=draft，未审核/未发布 |
| video | 内容创作 → 生成视频脚本 | 连续口播与分镜；采用后进原 video draft。视频配文仍由当前独立字段管理，不冒充视频已制作 |
| visual | 内容创作 → 配图方案 | 每页标题、正文、构图说明、比例；保存视觉方案。已有文字卡渲染仍是单独实际动作，视觉方案不是已生成图片 |
| knowledge | 资料与引用 → 整理资料建议 | 提炼条目/分类与来源；采用后是资料整理方案。真实导入仍用 knowledge_import，不能把模型提炼内容静默升级为事实材料 |
| revision | 内容创作/原草稿 → 按要求修订 | 原句、替换句、理由与新版正文并排；采用后同 draft 新版本，原图保留且要求重新核对图片，重置人工审核 |
| audit | 发布前核对 → AI 内容检查 | 风险级别、位置、问题、建议与引用；仅检查建议，不能代替现有三项人工勾选或人工 approve |
| package | 发布前核对 → 整理内容包建议 | 内容/标签/素材引用建议；采用为方案。真正本地打包用 package_build，不能把此方法产物当包已完成 |
| scheduling | 草稿与发布 → 排期建议 | 相对日期、北京时间、草稿和账号；采用为方案，实际提醒仍由已有 schedule_save 明确逐条保存，不启动自动发布 |
| engagement | 草稿与发布 → 互动草稿 | 评论回复或私信草稿、明确目标、理由、引用；仅草稿，不从昵称猜 UID、不跨接自动发送 |
| growth | 复盘 → 增长建议 | 当前/目标指标、实验、观察周期、注意项；保存实验方案，不修改现有人设或采集规则 |
| learning | 复盘 → 复盘建议 | 观察、候选规则、下一次测试与引用；采用为复盘方案，不激活软件规则 |

不要新增 17 个顶层导航。可用“更多方法”折叠当前阶段的次要按钮；常用生成、修订、审核保持显眼。每个方法都必须有可执行 prepare/run/查看/采用链，不以工具简介或链接替代。

## Native Interface

延续 ctx.contentAction(action,payload) → 原 Native 认证/当前店/账号归属 → 同一 Store 的 ContentWorkflowWorkbench.execute。原 11 动作保持，白名单精确新增以下 7 个，禁用任意 content_* 执行。

公共请求：`storeId` 供 Native 核当前店并剥离；组件 BASE 为 `accountId/platform`。所有写请求带 `expectedRevision/requestId`。读请求不带写字段。不能从前端传 tenant、actor、model adapter 或凭证。

| action | 类型 | 动作字段 | 主要结果 |
|---|---|---|---|
| content_methods_read | 读 | 无 | result.methods、contract=fangyu-content-workflow-v1、platformExecution=false |
| content_knowledge_import | 写 | document:{title,text,kind:fact\|hypothesis,sourceLabel} | result.document、alreadyImported；原文和分片在 workflow.documents |
| content_knowledge_search | 读 | query、limit 可选 1–20 | result.evidence；factsAreSourceAssertions=true |
| content_task_prepare | 写 | methodId、query；instructions/topicId/draftId/evidenceIds/artifactIds 可选 | result.task(state=prepared)、modelCalled=false |
| content_task_run | 写 | taskId | result.task、artifactId、modelCalled；回执状态不保证 succeeded |
| content_task_apply | 写 | taskId | result.appliedRefs:{draftIds,topicIds,planIds,personaVersion}、alreadyApplied；平台未执行 |
| content_package_build | 写 | draftId | result.package、fileName、mime、content；本地 Markdown/元数据包 |

工作区新增 `workflowContract`、`workflow={documents,tasks,artifacts,plans,packages}`、`workflowCapabilities`。前端必须核对原 actor/store/account/platform 和 schema 后使用，所有文字按纯文本转义。保留旧 revision/CAS，切换账号或门店时丢弃迟到响应与本地未提交视图。

限制直接复用服务端定义：主题 500 字、要求 2000 字；每次最多 20 片证据、8 个前序产物；文档正文 100000 字，账号资料正文总量 500000 字。UI 在提交前按完整 UTF-8 JSON 字节估算，不以字符数代替 HTTP 限额，不静默截断。Native 只给 knowledge_import 增加明确请求预算，其他动作仍按现有独立上限。

当前 host 全局锁包围整个 content.execute；task_run 必须在短锁身份核对后释放全局锁执行，模型调用不能占住工作台。组件在模型前保留派发记录、模型调用后同一事务重新查身份/门店。不能只证明 Store 事务外就遗漏 Native 全局锁。

## 模型接线与实际可用状态

只在 Native 端对接已授权、当前账号有权使用的现有模型配置；不新增收费服务、默认密钥或本地权重。UI 不接触密钥。模型 Adapter 接收 contract、稳定执行 requestId、method schema、input、scope；返回同一个 requestId 和 state/output。

未配置时仍可导入/检索资料、准备任务、手工编辑和审核包；任务面板显示“生成通道尚未接通，任务已保存”。禁用执行按钮，不能把准备提示词称为生成完成。`callable(adapter)` 仅证明接线存在，不能展示“平台/模型已实测成功”。测试阶段用明确标注的合成模型 Adapter，不调用真实付费模型。

## 回执与防重复：必须先改再开生成按钮

现有 content-operations request/recoverSaved 只接受写回执 succeeded，未知本地保存允许核对 not_found 后原编号重试。生成任务不能照搬这一分支。

1. prepare 保存成功后取真实 task.id 与最新 workspace.revision，核对来源清单后 run；不能在每次页面刷新时重新 prepare/run。
2. run 发送前保存完整原请求。无论响应、超时、重开，均通过已有 content_workspace_read(requestId=原编号) 查询记录及 task.runRequestId。既有 `running/unknown` 必须显示“执行结果待核对”，保留断点与输入，禁用再次执行；不把回执未完成当请求未送达。
3. run 可返回 `succeeded/running/unknown/known_not_executed/completed_invalid/needs_revalidation`。这些是任务结果，先验证回执 identity，再依据 task.state 呈现；不抛成通用“保存失败”导致用户反复点击。生成成功必须有对应 artifact、generated=true；采用成功必须有 appliedRefs，不能仅看 HTTP 200。
4. `known_not_executed` 明确未执行，`completed_invalid` 说明结果不合约，`needs_revalidation` 表示生成期间资料变化，三者均保留原任务。当前组件都 retryAllowed=false；新任务必须用户明确选择重新准备，不复用旧任务触发第二次模型调用。
5. `CONTENT_MODEL_UNAVAILABLE` 当前为组件调用前 503。Native 若可证明未派发，应输出明确 mutation_committed=false，让前端保留 prepared 状态；不能把所有 503 泛化为未执行。
6. apply 由用户显式点击，409（原稿/资料/method变化）显示产物仍保留、不能覆盖当前稿。重复 apply 不新增第二份草稿或选题。未知 apply/导入/打包延续普通原编号核对，但不能清掉未确定的 run 记录。
7. 不把一条未知模型任务永久锁死全账号其他本地工作。建议任务运行/未知状态只锁该任务运行与采用，以及本面板敏感输入；其他草稿本地编辑可继续。若资料因此变化，候选由后端 needs_revalidation 保留，绝不自动覆盖。

## 结果显示与实际采用

统一结果面板展示“总结 / 产物 / 原文引用 / 待核假设”。产物按 method-specific 字段显示成可读段落/表格，不将原始 JSON 暴露给普通用户。引用明确带资料名、原文、来源标签；kind=fact 仍是上传资料的说法，不显示“AI已证实”。引用坐标是 Python Unicode 字符坐标，前端高亮需 Array.from(text) 转换，不能直接 JS slice 误切 Emoji。

按钮名称对应真实结果：“采用为人设”“加入选题池”“保存为草稿”“保存修订版”“保存为方案”。采用后定位真实新条目并继续原编辑/审核，避免出现第二套人设/草稿库。

发布前核对的主导出动作改接 content_package_build，要求当前稿版人工 approve 与版本吻合。图片未齐、视频未做、旧配图需重核分别显示 needs_assets / needs_video_asset / needs_asset_review 的业务含义。既有普通正文导出可留在次级“导出草稿文本”，不再用同一个“内容包”名称表示两种完成程度。

## 最难代表链与验收顺序

先做一条完整代表链再铺 17 方法按钮：

1. 两个合成账号建立独立 workspace。甲导入含中文/Emoji/CRLF 的古北虚构事实和单独假设，乙检索不到；甲检索相关原文。
2. research/strategy 候选 → 明确采用方案 → topics 以此前产物为输入 → 采用进原选题池。所有引用可追溯，不把假设当事实。
3. 从选题创建 writing → 人工执行合成模型 → 结果按字段展示 → 采用到原草稿 → 用现有图片素材/文字卡 → 当前人工审核 → package_build 输出带引用与素材状态的本地包。
4. 对同稿 revision：显示原句对照 → 保存同一 draft 的新版本 → 旧版本/图片仍在、审核失效 → 重新人工审核 → 包保留最初来源原文。
5. 在 run 派发成功后故意丢回执；核对 running/unknown，不发第二次模型。期间另一路本地草稿可读写，Native 全局锁不阻塞。切账号/店/员工后旧响应不得露出或采用。
6. 再完成 video（配文/口播不混）、audit 不伪造人工批准、package/scheduling/engagement 均不执行平台、growth/learning 不改规则，其余方法逐项行为可达。

验收分层：扩展公开 execute 测试 → Native HTTP 白名单/CSRF/作用域/超限/原回执 → 当前真实 UI 的上述链 → 冻结版本实际启动及旧页回归。合成模型/平台替身只能证明接线，不冒充真实模型生成质量、平台发布或自动定时服务完成。

## 实施所有权与顺序

1. 总控完成 v65 冻结，作者确认扩展稳定并交四源码+vendor闭包 SHA。
2. 总控独占 Native backend/host/freezer/backend.mjs，扩展固定闭包并加入 7 动作、分类、大小、锁和模型 Adapter。此前冻结候选不可后补文件。
3. UI 作者在 content-operations.mjs/css 里增量挂入口与共享任务面板；若拆分辅助 mjs，仅是当前页面实现，需显式导入和冻结，不另起独立路由。
4. 优先修 task_run receipt 状态，再接按钮。普通11动作及已完成错误处理、累计指标、窄屏样式保持。
5. 完整链通过后才能把“待配置”按钮改为可执行；冻结下一候选并核对正式启动版本。仍有平台/本人核验依赖的模块保留明确状态，不能称“三合一全部完成”。
