# AI Voice Guardrails

Apply during writing, not only at final review. Goal: sound like a **specific** creator, not a
generic national dry-goods account.

When DNA and style library are empty, read `voice-cold-start.md` and still draft with the **human
texture recipe**. Empty library ≠ dry-goods voice. Market samples must not become the speaking voice.

## Human texture defaults (no style library)

Apply on every draft when `voice_source` is not `user_library`:

- Prefer peer-to-peer tone over broadcast host tone
- Put a judgment early, from the front (`我觉得…` / `我后来只改了…`) — never via 翻案腔
- Keep one honest limit or failed attempt
- Keep one sensory / situational detail, or an explicit `[此处需你补真实细节]`
- Vary sentence length; allow fragments; ban essay transitions
- CTA asks something answerable in one comment, not `关注我`

Self-check before return: if the body could be posted by any account in any niche after swapping
two nouns, rewrite for texture — do not ship it.

Inspired by [human-writing](https://github.com/KKKKhazix/human-writing): 活人感先来自材料与说话位置，
不是口头禅和假口语。

## Hard bans in Xiaohongshu copy

- 大家好呀 / 今天来跟大家分享一下
- 随着…的发展 / 在当今社会
- 综上所述 / 总的来说 / 值得一提的是
- 希望对你有所帮助 / 本文将从…三个方面
- 首先…其次…最后…（书面排比版）
- 让我们一起 / 不妨试着
- 空泛夸饰：`超强` `无敌` `天花板` without proof
- 无信息情绪开头：`真的绝了！！！` with no concrete detail in the same line
- **全国干货腔**：去掉城市/身份/品类后，换到任何赛道仍成立的正文
- **清单号口吻**：只有 `N 个方法` 堆叠，没有说话人的判断、限制或具体场景
- **翻案腔**：`不是A而是B` / `你以为…其实` / `表面…实际` / `说到底` 及同类抬价句
- **路标词**：`说实话` / `说白了` / `先说结论` / `值得注意的是`
- **标点表演**：正文不用破折号 `——`；冒号只允许引出人物原话，不用 `核心是：`

## Good openings (imitate the shape, not the words)

The pattern that works: a concrete number, object, place, or failure in the first line, with the
audience implied rather than announced.

| Shape | Example |
|---|---|
| 时间成本 + 结果 | `折腾了三个周末，我把发笔记这件事拆成了 8 步` |
| 失败前置 | `前 20 篇笔记都没破 500，问题不在标题` |
| 具体对象 + 反差 | `同一个选题，图文 300 赞，视频 4 万` |
| 场景痛点 | `每次想发笔记，卡在"今天写啥"就过去半小时` |
| 地点/场景 + 意图 | `在西安找周末带娃点，我已经替你踩过三个坑` |
| 判断先行 | `成长这事，我后来只敢留三条，其余全砍了` |

Each one carries a fact the reader can check or relate to. Compare with a banned opening like
`大家好呀，今天来跟大家分享一下我的创作流程` — same topic, zero information in line 1.

If the opening could be pasted onto another niche without editing nouns, rewrite it.

## Replace pattern

Convert unsupported objective claims into bounded personal experience:

- `最好` → `我自己用过最顺手的`
- `保证` → `我这次的结果是`
- `所有人` → `如果你也…可能会`
- `100%` → remove or cite a personal measurement

## Carousel-specific rhythm

- First 3 visible lines are the fold gate; at least 2 of: audience/scene anchor, concrete result, open loop.
- Keep at least one concrete noun the reader can place (city, product, workflow, crowd) when the brief has it.
- One paragraph = one idea; 1-3 short lines; blank line between paragraphs.
- Default length band: 300-800 Chinese characters unless the user requests otherwise.
- At least one honest imperfection or limit when reviewing products/workflows.
- Match provisional/DNA stance; do not borrow market-sample identity words.

## Video-caption-specific rhythm

- Line 1 = search-facing summary; do not open with hello or background.
- 80-220 Chinese characters unless user asks for longer.
- Never paste the spoken script; summarize outcome + audience + save/comment reason.

## Emoji policy

- Use as structure markers (`✅` `1️⃣` `👇`), not decoration every line.
- Target 8-15 emojis per carousel; fewer in video captions.
- Do not replace nouns with emoji.

## Missing user evidence

Mark placeholders explicitly: `[此处需你补真实细节]` and do not invent experiences to fill them.

## Deterministic check

`xhs-publish-guard/scripts/check_copy.py <file> --format <carousel|video>` flags the banned phrases
above plus length-band violations. It cannot judge whether a line is *interesting* — that stays a
human/model judgement against the good-opening shapes.
