"""Actual original clean entry and support; synthetic existing data only."""
from pathlib import Path
from datetime import datetime, timezone
import ast
import hashlib
import importlib.util
import json
import sqlite3
import sys
import uuid
sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
W = HERE.parent
BASE = W/'f82-standard-package-candidate/standard-held-clean-v82'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module

adapter = load('own_clean_entry_adapter', HERE/'adapt_clean_entry.py')
source = BASE/'standard_entry.py'
selector = HERE/'existing_workspace_entry.py'
adapted = adapter.adapt_entry(source.read_bytes(), selector.read_bytes(),
    expected_entry_sha=adapter.BASE_ENTRY_SHA)
fixture = HERE/('adapted-entry-fixture-'+uuid.uuid4().hex)
fixture.mkdir()
adapted_path = fixture/'standard_entry.py'
adapted_path.write_bytes(adapted)
entry = load('own_adapted_clean_entry', adapted_path)
release = BASE/'payload/project/work/ui-native-r57/releases'/entry.RELEASE_ID
assert sha(release/'RELEASE.json') == entry.RELEASE_SHA
support = entry.verified_existing_workspace_support(release)
integrations = load('own_original_integrations_entry_qa',
    W/'next-release-f82-expansion-composition/project/work/ui-runtime-r55/src/integrations.py')
root = fixture/'existing-project'
state = root/'work/ui-native-r57/state'
state.mkdir(parents=True)
data = fixture/'existing-data'
(data/'assistant').mkdir(parents=True)
database = data/'workspace.sqlite3'
with sqlite3.connect(database) as connection:
    connection.execute('CREATE TABLE previous_customers (id INTEGER PRIMARY KEY, detail TEXT)')
    connection.executemany('INSERT INTO previous_customers VALUES (?, ?)',
        [(1,'自有合成客户甲'), (2,'自有合成客户乙')])
vault = data/'assistant/device.dpapi'
metadata = {'state':'bound', 'token':'OnlyOwnSyntheticDeviceToken_'+uuid.uuid4().hex,
    'company_id':'fangyu-apartment-client', 'environment_id':'own-entry-test',
    'device':{'id':'own-entry-device', 'owner':'own-entry-owner'}}
vault.write_bytes(integrations.protect(json.dumps(metadata).encode()))
descriptor = state/'production-workspace.json'
binding = {'schema':'fangyu-production-workspace-v1', 'company_id':'fangyu-apartment-client',
    'data_dir':str(data), 'device_id':metadata['device']['id'],
    'owner':metadata['device']['owner'], 'environment_id':metadata['environment_id']}
descriptor.write_text(json.dumps(binding)+'\n', 'utf-8')
protected = [database, vault, descriptor]
before = {str(path.relative_to(fixture)):sha(path) for path in protected}
groups = []
assert entry.selected_directories(release, str(root), sha(descriptor)) == (data, state)
groups.append('adapted clean entry loads exact original release support and reuses synthetic Windows DPAPI-bound data')

def reject(call):
    try:
        call()
    except (entry.ExistingWorkspaceSelectionError, support.WorkspaceBindingError,
            RuntimeError, FileNotFoundError):
        return
    raise AssertionError('Expected closed explicit existing selection')

for supplied_root, supplied_hash in [(str(root), None), (None, sha(descriptor)),
        (str(root), '0'*64), ('relative-project', sha(descriptor))]:
    reject(lambda:entry.selected_directories(release, supplied_root, supplied_hash))
assert not (fixture/'FangyuWorkbenchStandard').exists()
groups.append('invalid explicit settings fail before any ordinary fallback or new directory')

# A tiny separate test installation binds the same original support bytes to a
# manifest. It does not replace or edit the held package's original release.
own_release = fixture/'own-public-release'
own_release.mkdir()
support_path = own_release/'workspace_binding.py'
support_path.write_bytes((release/'workspace_binding.py').read_bytes())
own_manifest = {'files':[{'path':'workspace_binding.py', 'size':support_path.stat().st_size,
    'sha256':sha(support_path)}]}
manifest_path = own_release/'RELEASE.json'
manifest_path.write_text(json.dumps(own_manifest), 'utf-8')
previous_release_sha = entry.RELEASE_SHA
entry.RELEASE_SHA = sha(manifest_path)
assert entry.verified_existing_workspace_support(own_release).COMPANY_ID == 'fangyu-apartment-client'
support_path.write_bytes(support_path.read_bytes()+b'\n# own tamper test\n')
reject(lambda:entry.verified_existing_workspace_support(own_release))
entry.RELEASE_SHA = previous_release_sha
groups.append('support bytes are verified against the exact release before execution; tamper rejected')

# Execute the actual adapted main in an isolated child, but replace no service,
# cloud or native functions. --help exits in original argparse before load_host.
import subprocess
help_run = subprocess.run([sys.executable, str(adapted_path), '--help'],
    capture_output=True, text=True, encoding='utf-8', errors='replace')
assert help_run.returncode == 0
assert '--existing-project-root' in help_run.stdout and '--binding-sha256' in help_run.stdout
groups.append('actual adapted main parses explicit upgrade options without starting host or native window')

before_tree = ast.parse(source.read_text('utf-8'))
after_tree = ast.parse(adapted.decode('utf-8'))
functions = lambda tree:{node.name:ast.dump(node,include_attributes=False)
    for node in tree.body if isinstance(node,ast.FunctionDef)}
old_functions = functions(before_tree)
new_functions = functions(after_tree)
unchanged = sorted(name for name in old_functions if name != 'main')
assert all(old_functions[name] == new_functions[name] for name in unchanged)
groups.append('original host closure loader, code audit, hash checks, icon and default directory functions remain exact AST')

# Default delegates to the unchanged own_directories; test that branch without
# consulting a real user's LOCALAPPDATA or profile.
original_directories = entry.own_directories
entry.own_directories = lambda: ('own-default-data', 'own-default-state')
assert entry.selected_directories(release) == ('own-default-data', 'own-default-state')
entry.own_directories = original_directories
groups.append('ordinary default selects only original own directory branch, without existing support or vault lookup')
after = {str(path.relative_to(fixture)):sha(path) for path in protected}
assert before == after
with sqlite3.connect(database.as_uri()+'?mode=ro', uri=True) as connection:
    assert connection.execute('SELECT COUNT(*) FROM previous_customers').fetchone()[0] == 2
result = {'status':'PASS_ADAPTED_CLEAN_ENTRY_SOURCE_ONLY', 'utc':datetime.now(timezone.utc).isoformat(),
    'groups':groups, 'groupCount':len(groups), 'unchangedOriginalEntryFunctions':unchanged,
    'originalEntrySha256':sha(source), 'adapterSha256':sha(HERE/'adapt_clean_entry.py'),
    'selectorSha256':sha(selector), 'adaptedEntrySha256':sha(adapted_path),
    'originalReleaseSha256':entry.RELEASE_SHA, 'originalSupportSha256':sha(release/'workspace_binding.py'),
    'syntheticDatabaseRowsPreserved':2, 'protectedBytesUnchanged':True,
    'actualWindowsDpapi':True, 'ownFixture':str(fixture),
    'defaultDirectoryBranchOnlyTestedWithoutCreatingProfile':True,
    'mainExeCompiled':False, 'originalServiceStarted':False, 'productionOrRealSessionsRead':False,
    'platformModelNativeRequests':0,
    'next':'Apply after final builder stage and before real main EXE compilation; test actual compiled default and explicit existing workspace entry.'}
(HERE/'ADAPTED-ENTRY-RESULTS.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n','utf-8')
print(json.dumps(result,ensure_ascii=False))
