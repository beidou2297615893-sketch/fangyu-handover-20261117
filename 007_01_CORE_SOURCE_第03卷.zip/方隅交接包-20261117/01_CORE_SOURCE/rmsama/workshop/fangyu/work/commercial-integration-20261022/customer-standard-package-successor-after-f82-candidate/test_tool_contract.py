"""Local tooling units/AST and refusal probes. Not an F83/root acceptance."""
import ast,copy,hashlib,importlib.util,json,os,subprocess,sys,traceback,uuid
from pathlib import Path
C=Path(__file__).resolve().parent;OUT=C/('tool-fixture-'+uuid.uuid4().hex);OUT.mkdir()
spec=importlib.util.spec_from_file_location('owned_successor_tools',C/'build_clean_next.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
rows=[]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n','utf8')
def save():write(OUT/'RESULTS.json',{'groups':rows,'rootFinalPinsNotProvided':True,'actualSuccessorStageOrBuild':False,'noCompilerOrInstallerOrProductExecuted':True})
def record(name,fn):
 row={'name':name};rows.append(row)
 try:row['evidence']=fn();row['passed']=True
 finally:save()
def reject(fn):
 try:fn()
 except (RuntimeError,ValueError,KeyError,FileNotFoundError):return True
 raise AssertionError('Expected refusal')
def missing_roots():
 r=subprocess.run([sys.executable,'-I','-B',str(C/'build_clean_next.py'),'--stage'],capture_output=True)
 assert r.returncode!=0 and not list(C.glob('standard-held-clean-v*'))
 rp=OUT/'not-root-final-pins.json';ep=OUT/'not-external-pins.json';write(rp,{});write(ep,{})
 bad=subprocess.run([sys.executable,'-I','-B',str(C/'build_clean_next.py'),'--stage','--version','83','--base',str(OUT/'candidate-unified-v83'),'--root-pins',str(rp),'--root-pins-sha256','0'*64,'--external-payloads',str(ep),'--external-payloads-sha256','0'*64],capture_output=True)
 assert bad.returncode!=0 and b'Explicit root/external descriptor SHA differs' in bad.stderr and not list(C.glob('standard-held-clean-v*'))
 old=copy.deepcopy(m.ROOT_PINS);m.VERSION=83;m.ROOT_PINS={'rootExplicitFinalPins':False};m.ROOT_PINS_SHA='0'*64
 assert reject(m._validate_root_inputs)
 m.ROOT_PINS={'rootExplicitFinalPins':True,'candidate':'candidate-unified-v83','fixtureOnly':True};assert reject(m._validate_root_inputs);m.ROOT_PINS=old
 return {'argumentRefusalExit':r.returncode,'wrongExplicitShaRefusalExit':bad.returncode,'missingOrQaDescriptorsRefused':True,'newReleaseClaimed':False}
def company():
 v={'releaseVersion':m.RELEASE_VERSION,'edition':'customer','personalMode':False,'authMode':'managed','runtime':{'release_approved':False,'public_send_hold':True,'xiaohongshu_automation':'hold','executable':'FangyuWorkbench.exe'}}
 m._company_held(v)
 for field,bad in [('release_approved',True),('public_send_hold',False),('portable_employee_release',True)]:
  t=copy.deepcopy(v);t['runtime'][field]=bad;assert reject(lambda:m._company_held(t))
 old=copy.deepcopy(v);old['releaseVersion']='r57-standard-v82';assert reject(lambda:m._company_held(old))
 return {'releaseVersion':'1.2.0-read.1','oldVersionAndGrantFlagsRefused':True}
def entry():
 before,after=m._render_clean_entry('fixture-release-no-acceptance','a'*64,'b'*64);bt=ast.parse(before);at=ast.parse(after)
 funcs=lambda t:{n.name:ast.dump(n,include_attributes=False) for n in t.body if isinstance(n,ast.FunctionDef)}
 b,a=funcs(bt),funcs(at)
 assert all(a[name]==body for name,body in b.items() if name!='main')
 text=after.decode();assert '--existing-project-root' in text and '--binding-sha256' in text and 'selected_directories(release, args.existing_project_root, args.binding_sha256)' in text
 assert 'data, state = own_directories()' not in text[text.index('def main():'):]
 for name in ('load_host','exact','own_directories','short_native_icon'):assert a[name]==b[name]
 (OUT/'entry-before.py').write_bytes(before);(OUT/'entry-after.py').write_bytes(after)
 return {'adapter':m.ADAPTER_SHA,'entryBeforeSha256':hashlib.sha256(before).hexdigest(),'entryAfterSha256':hashlib.sha256(after).hexdigest(),'originalFunctionsExceptMainAstUnchanged':True,'originalCacheGuardAstUnchanged':True}
def external():
 source=OUT/'source/platform-cli-customer-read';source.mkdir(parents=True);(source/'platform-cli.exe').write_bytes(b'not an executable - synthetic inventory only')
 write(source/'guard-manifest.json',{'purpose':'customer_distribution_read_only','public_send_grant':False,'login_grant':False,'read_commands':['status','whoami','search','read','comments','sub-comments']})
 doc={'schema':'fixed_customer_read_sibling_payload_v1','name':'platform-cli-customer-read','source':str(source),'files':m._inventory(source),'public_send_grant':False,'login_grant':False,'dataIncluded':False}
 m.EXTERNAL_INPUTS=doc;m.EXTERNAL_INPUTS_SHA='c'*64;m.SAMPLE=OUT/'synthetic-sample';(m.SAMPLE/'payload').mkdir(parents=True);m._copy_external_cli();m._assert_rows(m.SAMPLE/'payload/platform-cli-customer-read',doc['files'])
 t=copy.deepcopy(doc);t['name']='arbitrary-other-program';m.EXTERNAL_INPUTS=t;assert reject(m._external_descriptor)
 t=copy.deepcopy(doc);t['files'].append({'path':'qa-fixtures/private.json','sha256':'0'*64,'bytes':0});m.EXTERNAL_INPUTS=t;assert reject(m._external_descriptor)
 m.EXTERNAL_INPUTS=doc;(source/'extra.json').write_text('{}','ascii');assert reject(m._external_descriptor)
 (source/'extra.json').unlink();return {'closedSyntheticTreeCopied':True,'otherSiblingQaAndUnlistedFilesRefused':True,'executableWasNotRun':True}
def inventory():
 root=OUT/'inventory';root.mkdir();p=root/'plain.py';p.write_text('VALUE=1\n','ascii');fixed=m._inventory(root);m._assert_rows(root,fixed)
 (root/'late.pyc').write_bytes(b'not executable');assert reject(lambda:m._inventory(root));(root/'late.pyc').unlink()
 linked=root/'hardlink.py';os.link(p,linked)
 try:assert reject(lambda:m._inventory(root))
 finally:linked.unlink()
 assert reject(lambda:m._relative('a\\b')) and reject(lambda:m._relative('../escape'))
 return {'singleLinkAndExactInventoryRequired':True,'cacheHardlinkAndTraversalRefused':True}
def purposes():
 project=OUT/'purpose-fixture/project';release=project/'work/ui-native-r57/releases/fixture-release';release.mkdir(parents=True)
 v={'releaseVersion':m.RELEASE_VERSION,'edition':'customer','personalMode':False,'authMode':'managed','runtime':{'release_approved':False,'public_send_hold':True,'xiaohongshu_automation':'hold','executable':'FangyuWorkbench.exe'}};write(project/'work/app/company.json',v)
 binding={'releaseVersion':m.RELEASE_VERSION};records=[]
 for purpose in sorted(m.REQUIRED_PURPOSES):
  path='resources/customer-read/'+purpose+'.json';doc={'company_binding':binding,'evidence':{'real_platform_verified':False,'native_loaded_bytes_verified':False,'public_send_grant':False}}
  if purpose in ('xiaohongshu_natural_read','xiaohongshu_identity_observation','xiaohongshu_session_recovery'):doc['schema']='fangyu_customer_natural_material_review_v1'
  write(release/path,doc);records.append({'purpose':purpose,'path':path,'bytes':(release/path).stat().st_size,'sha256':sha(release/path)})
 index={'schema':'fangyu_customer_read_material_index_v1','scope':'customer_distribution_read','company_binding':binding,'executable':'FangyuWorkbench.exe','reviews':records};ip=release/'resources/customer-read/review-index.json';write(ip,index)
 good=m._purpose_materials(project,release);assert len(good['purposes'])==7
 t=copy.deepcopy(index);t['reviews'].pop();write(ip,t);assert reject(lambda:m._purpose_materials(project,release));write(ip,index)
 body=release/records[0]['path'];body.write_text('{}','ascii');assert reject(lambda:m._purpose_materials(project,release))
 assert reject(lambda:m._all_false_evidence({'evidence':{'public_send_grant':True}}))
 return {'syntheticSevenPurposeShapeAccepted':True,'missingStaleAndSendGrantRefused':True,'noPolicyOrFactoryAcceptanceClaimed':True}
try:
 for name,fn in [('explicit_root_gate',missing_roots),('company_before_held',company),('original_entry_adapter',entry),('external_sibling_closed_copy',external),('plain_inventory',inventory),('purpose_union_only_license_source_layer',purposes)]:record(name,fn)
 print(json.dumps({'output':str(OUT),'groups':len(rows),'allPassed':True,'actualStageOrBuild':False}))
except Exception:
 (OUT/'ERROR.log').write_text(traceback.format_exc(),'utf8');raise
finally:save()
