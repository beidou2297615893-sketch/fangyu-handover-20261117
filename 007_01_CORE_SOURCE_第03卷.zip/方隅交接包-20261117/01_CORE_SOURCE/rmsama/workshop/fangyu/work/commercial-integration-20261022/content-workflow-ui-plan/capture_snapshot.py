from pathlib import Path
import hashlib,json,datetime

W=Path(r'C:/积木软件工坊/项目/方隅公寓客户版/work/commercial-integration-20261022')
S=W.parents[1]/'work/parallel-integration-20261018/final-integration/stage-02/project'
U=S/'work/ui-approved-implementation/ui-preview'
paths=[W/'content-workflow-extension'/name for name in ('content_workflow.py','workflow_methods.py','workflow_knowledge.py','content_extension_loader.py','METHODS.md','KNOWLEDGE.md','TEST-SEAMS.md')]
paths += [W/'content-workflow-extension/workflow_vendor'/name for name in ('normalize.py','LICENSE','PINS.json')]
paths += [U/'pages'/name for name in ('content-operations.mjs','content-operations.css')]
paths += [U/'backend.mjs',S/'work/ui-native-r57/content_workbench.py']
paths += [W.parents[1]/'outputs/三合一新增功能样图'/name for name in ('内容创作.png','发布前核对.png')]
records=[]
for p in paths:
    raw=p.read_bytes();stat=p.stat()
    records.append({'path':str(p),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'lastModifiedUtc':datetime.datetime.fromtimestamp(stat.st_mtime,datetime.timezone.utc).isoformat()})
result={'capturedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'note':'Read-only snapshot, not a frozen closure or validation; candidate author may still be editing. No production data or model calls.','files':records}
(W/'content-workflow-ui-plan/SNAPSHOT.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),'utf-8')
print(json.dumps({'files':len(records),'sha256':{Path(r['path']).name:r['sha256'] for r in records}},ensure_ascii=False))
