# v66 内容工作流 Native 接线交接

2026-10-23 00:00，北京时间。本作者指定产品文件已停写，可由总控冻结下一候选。未安装、未修改生产库或冻结候选、未请求真实模型与平台。

## 已完成

1. `workbench_backend.py` 显式新增七动作，原十一动作保留。新增受信构造参数 `content_model_adapter=None`，页面不能提交 adapter/actor/凭证。默认未接模型时保留 prepared，返回 `CONTENT_MODEL_UNAVAILABLE` / 503 / `error.mutation_committed=false`。
2. 先按宿主固定 SHA 核加载器字节，再由 loader 用宿主固定四源码 SHA 核整套闭包，在私有包执行同一份已核字节。旧内容模块和四 vendor 文件原样保留；新三业务源码、加载器、知识归一化及许可等七文件均与作者最终55项验证的候选摘要完全一致，采用视频修订修复后的 `b3cf0ba0…`。
3. `content_task_run` 在 Native 短锁完成真实会话、员工、门店和账号鉴权，然后在 Native 与 HTTP host 全局锁之外执行。模块仍先提交原请求编号，再调用受信宿主；回写时重新核当前 session、员工、账号和当前门店。
4. 已派发后的权限异常通过 `error.mutation_committed=true` 告知前端保持原执行编号；不把晚到 403/409 伪装为“没发送”。running/unknown/known_not_executed/completed_invalid/needs_revalidation 回执保持组件原值，不自动重发。
5. HTTP 仅 `content_knowledge_import` 接受500000 UTF-8字节的完整请求；其他内容133120、图片300000、既有来源300000、旧动作16384字节的预算保持。仍检查 Origin、CSRF、Host、Cookie 和显式动作白名单。500000是本地请求上限，不代表资料已上传到模型。
6. freezer显式装入12项内容闭包并进入原 source_pins/RELEASE 流程。未手动后补任何冻包。

## 可核证据

- `PRODUCT-FILES.json`：三宿主文件、新七文件全部 SHA、固定四源码 pins、12项 freezer 闭包、基础文件未改。
- `HTTP-RESULTS.json`：10组真实 Native HTTP 回归通过。覆盖17方法、资料→引用→research/topics/writing→采用原选题/草稿→原文字卡/人工审核/内容包、默认无模型、unknown原键不重发、明确未执行/非法结果、真实第二HTTP线程并发写、账号归属/会话/门店改变、10万中文字与专用字节预算、旧客户/回复/SOP/AI/人工记录原始 SQL 行保留。
- `../three-in-one-content-http/HTTP-RESULTS.json`：旧11动作16组回归通过，含原权限、素材、CAS、重放、导出、SOP和后台重建保留。
- `before/`：本作者修改前 Native/host/freezer原件。

并发测试明确等待合成模型进入并阻塞，另一HTTP请求在释放模型前完成原人设读写，且耗时小于2.5秒；不是等模型超时后才写入。资料变化后候选标 `needs_revalidation`，不覆盖新的本地人设。

## 给UI作者的独立服务

`test_workflow_http.py --serve` 当前 PID 68728，统一执行 session 63140；http://127.0.0.1:56287/#content 。合成员工 `fixture-admin` / `fixture-password-123`，合成内容账号甲/乙。

此服务实际使用完整产品UI、Native host/backend/Store和ContentWorkflow扩展；通过受信构造函数注入明确合成Model。所有输出都有虚构测试文案；这不是生产默认适配器。平台账号为 disconnected，禁止测试采集/账号连接。网络、进程、外部数据库通过审计 hook 拒绝。

当前服务保留给UI作者。进程是否活着以 session/PID/HTTP为准；SERVER.json/LIVE-STATUS.json不是单独的存活证明。关闭只终止本 session；不关闭其他Python或真实工作台。

## 下一步与未验证

- 生产内容模型网关尚未接通。接口可注入不等于已接真实DeepSeek，不借用意向分析接口伪造内容任务，不新增模型权重、依赖或付费调用。
- UI实际17方法链由UI作者继续验证；本报告只证明后端HTTP和闭包。视频方法为脚本/分镜候选，内容包为本地Markdown与元数据，仍不是制作完视频或已发布。
- 总控冻结候选后执行：

```powershell
& 'C:/积木软件工坊/项目/方隅公寓客户版/work/desktop-python/Scripts/python.exe' -X utf8 'C:/积木软件工坊/项目/方隅公寓客户版/work/commercial-integration-20261022/content-workflow-native/test_workflow_http.py' --candidate candidate-unified-v66
& 'C:/积木软件工坊/项目/方隅公寓客户版/work/desktop-python/Scripts/python.exe' -X utf8 'C:/积木软件工坊/项目/方隅公寓客户版/work/commercial-integration-20261022/three-in-one-content-http/test_content_http.py' --candidate candidate-unified-v66
```

两个测试均先核真实冻结清单与依赖后装载冻包，报告单独带候选版本。此时尚未运行上述冻结命令。

新增来源 kinds 由来源作者持有；Native没有 `note_links` 专属硬编码，本作者未改来源逻辑、Core、Runtime、SOURCE.json或UI。后续kind的真实采集证据仍由其负责。
