from pathlib import Path
import hashlib,json,shutil,ast
W=Path(__file__).resolve().parent;P=W.parents[2];F=P/'work/parallel-integration-20261018/final-integration/candidate-unified-v79/project';O=W/'merged-inputs';C=W.parent/'content-schedule-execution-candidate';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
rel='work/ui-approved-implementation/ui-preview/backend.mjs';original=(F/rel).read_bytes();insert="'content_schedule_plan','content_schedule_read','content_schedule_arm','content_schedule_control','content_schedule_tick','content_schedule_reconcile',"
needle="contentAction:(action,data)=>{if(![";s=original.decode();assert s.count(needle)==1 and insert not in s
resolved=s.replace(needle,needle+insert,1).encode();(O/rel).write_bytes(resolved);assert resolved.replace(insert.encode(),b'',1)==original
S=W/'source-candidate';assert not S.exists();shutil.copytree(F,S)
merge=json.loads((W/'MERGE-PREPARATION.json').read_text('utf-8'));rows=merge['rows']
for row in rows:
 dst=S/row['path'];dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes((O/row['path']).read_bytes())
 row['composedSha256']=sha(dst)
 if row['mergeStatus']=='conflict':row['resolution']='Exact six schedule action names inserted into F79 contentAction whitelist; removing insertion restores F79 bytes exactly'
base={p.relative_to(F).as_posix():{'sha256':sha(p),'bytes':p.stat().st_size,'crlf':p.read_bytes().count(b'\r\n')} for p in F.rglob('*') if p.is_file()}
(W/'BASE-HASHES.json').write_text(json.dumps({'base':'F79','rootPinsSha256':sha(W/'BASE-FINAL-PINS.json'),'files':base},ensure_ascii=False,indent=2)+'\n','utf-8')
(W/'MERGE-RESOLUTION.json').write_text(json.dumps({'rows':rows,'noWholeOldFileOverwrite':True,'onlyLongReturnConflictResolvedByExactInsertion':True},ensure_ascii=False,indent=2)+'\n','utf-8')
for name in ['make_qa_stage.py','test_factory_schedule.py','test_schedule_ui.mjs','serve_schedule_ui.py']:
 b=(C/name).read_bytes();text=b.decode().replace('candidate-unified-v77','candidate-unified-v79').replace('qa-local-content-schedule-only','qa-local-content-schedule-f79-only').replace('RED_EXPECTED_F77','RED_EXPECTED_F79');(W/name).write_bytes(text.encode())
print(json.dumps({'composed':len(base),'overlayFiles':len(rows),'conflictResolution':'exact six names only','source':str(S)},ensure_ascii=False))
