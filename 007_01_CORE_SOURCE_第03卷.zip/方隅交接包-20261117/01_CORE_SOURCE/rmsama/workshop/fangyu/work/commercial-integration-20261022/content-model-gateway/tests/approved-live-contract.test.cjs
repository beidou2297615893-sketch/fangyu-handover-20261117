'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const live=require('../baseline/live/ai_contract.cjs');
const candidate=require('../server/ai_contract.cjs');
const {fixture,IDS}=require('./cloud-fixture.cjs');

test('current deployed approved criteria, version, model catalogs and price sources remain exact',()=>{
 assert.equal(candidate.RULES_VERSION,'apartment-rental-20261019-approved-v1');
 assert.deepEqual(candidate.DEFAULT_INTENT_POLICY,require('../baseline/live/approved_intent_policy.json').criteria);
 for(const name of ['DEFAULT_INTENT_POLICY','MODELS','OPENAI_MODELS','PRICE_VERSION','OPENAI_PRICE_VERSION','PRICE_SOURCE'])
  assert.deepEqual(candidate[name],live[name],name);
});

test('without a published override both AI prompts remain identical to the freshly verified deployed code',()=>{
 const samples=[['keyword_suggest',{city:'上海',area:'浦江',count:10,rules:'通勤',exclude_keywords:['上海租房']}],
  ['intent_analyze',{city:'上海',post:{id:'fixture-post',title:'上海公寓招租',text:'目前可租'},comments:[
   {id:'one',text:'明天能看看吗'},{id:'two',text:'我下个月入住，想租这间'},{id:'three',text:'我只找房东直租'},
   {id:'four',text:'只是咨询一下管家号码'},{id:'five',text:'已租好，不再找了'},{id:'six',text:'下个月要去外地租房'}]}]];
 for(const [operation,raw] of samples){
  const input=live.normalizeInput(operation,raw);
  assert.deepEqual(candidate.normalizeInput(operation,raw),input);
  assert.deepEqual(candidate.prompt(operation,input,candidate.defaults()),live.prompt(operation,input,live.defaults()));
 }
});

test('central directory reads preserve live HQ/operator permissions, original grant revisions and zero writes',async()=>{
 const f=await fixture(),before=f.memory.stats().committedWrites;
 const hq=await f.call('store_config_read',{},f.admin),staff=await f.call('store_config_read');
 assert.equal(hq.status,200);assert.equal(hq.data.scope.type,'company');assert.equal(hq.data.stores.length,2);
 assert.equal(staff.status,200);assert.equal(staff.data.scope.type,'store');assert.deepEqual(staff.data.scope.store_ids,[IDS.store]);
 const profile=await f.profile();assert.equal(profile.content_generation_capability.central_grant_revision,staff.data.scope.grant_revision);
 assert.equal(profile.content_generation_capability.central_catalog_digest,staff.data.catalog_digest);
 assert.equal((await f.call('store_config_read',{store_id:IDS.storeB})).status,403);
 assert.equal(f.memory.stats().committedWrites,before);assert.equal(f.calls(),0);
});
