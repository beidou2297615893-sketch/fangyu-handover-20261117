# Format Benchmark Notes

Compare posts only within the same format unless explicitly analyzing a format shift experiment.

## Separate baselines

| Format | Primary entry metric | Primary value metric | Primary interaction signal |
|---|---|---|---|
| `carousel` / `image` | exposure → click (CTR) | read depth / saves | saves + comments |
| `video` | exposure → click (CTR) | 3s retention → completion | comments + profile visits |

Never compare video completion rate to carousel read behavior as if they were the same funnel stage.

## Carousel funnel language

1. Distribution — exposure vs account median
2. Click — CTR vs median for carousel posts
3. Early read — do saves/comments suggest the fold line worked?
4. Save value — saves disproportionately low vs opens
5. Discussion — comments/profile visits weak despite adequate saves

## Video funnel language

1. Distribution — exposure vs account median
2. Click — CTR vs median for video posts
3. Early retention — 3-second rate vs median
4. Completion — completion rate vs median for similar length
5. Interaction — comments/profile visits/follows vs median

## Missing fields

- Video-only fields (3s, completion) stay missing for carousel posts; do not impute zero.
- Require ≥3 comparable posts in the same format before group-level claims.
- Prefer account medians over platform-wide "good/bad" thresholds.

## Fix routing after diagnosis

| Earliest supported bottleneck | First fix skill |
|---|---|
| exposure | account-dna, topic-radar, tag/positioning review |
| click / CTR | title-craft + visual-lab |
| early retention / fold failure | video-director opening OR carousel fold rewrite |
| completion / save value | video-director middle OR carousel body structure |
| interaction | note-writer CTA/proof/discussion angle |

Change one primary variable per follow-up experiment.
