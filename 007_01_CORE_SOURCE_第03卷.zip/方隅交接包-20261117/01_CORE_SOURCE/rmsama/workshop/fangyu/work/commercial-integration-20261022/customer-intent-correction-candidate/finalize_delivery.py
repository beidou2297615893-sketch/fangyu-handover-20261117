"""Emit review artifacts in this candidate only; never apply to stage."""
from pathlib import Path
from datetime import datetime,timezone
import ast,difflib,hashlib,json
W=Path(__file__).resolve().parent;C=W/'candidate';B=W/'before'
baseline=json.loads((W/'BASELINE.json').read_text('utf-8'))
S=Path(baseline['source'])
base={row['path']:row['sha256'] for row in baseline['files']}
def sha(raw):return hashlib.sha256(raw).hexdigest()
rows=[];chunks=[]
for path in sorted(C.rglob('*.py')):
    rel=path.relative_to(C).as_posix();raw=path.read_bytes();old=B/rel
    assert not raw.startswith(b'\xef\xbb\xbf'),rel
    ast.parse(raw,filename=rel)
    oldraw=old.read_bytes() if old.exists() else b''
    if old.exists():assert sha(oldraw)==base[rel],rel
    if oldraw==raw:continue
    before=oldraw.decode('utf-8').splitlines(True);after=raw.decode('utf-8').splitlines(True)
    patch=''.join(difflib.unified_diff(before,after,
        fromfile='a/'+rel if old.exists() else '/dev/null',tofile='b/'+rel,n=3))
    chunks.append(patch)
    rows.append({'path':rel,'change':'modify' if old.exists() else 'add',
        'baselineSha256':sha(oldraw) if old.exists() else None,'candidateSha256':sha(raw),'size':len(raw),
        'baselineCurrentStageSha256':sha((S/rel).read_bytes()) if (S/rel).is_file() else None,
        'baselineMatchesCurrentStage':sha((S/rel).read_bytes())==sha(oldraw) if old.exists() and (S/rel).is_file() else not (S/rel).exists(),
        'hunks':patch.count('@@ -'),'addedLines':sum(x.startswith('+') and not x.startswith('+++') for x in patch.splitlines()),
        'deletedLines':sum(x.startswith('-') and not x.startswith('---') for x in patch.splitlines())})
patch=''.join(chunks).encode('utf-8')
(W/'integration.patch').write_bytes(patch)
pins={row['path']:row['candidateSha256'] for row in rows}
for suffix in ('RESULT.json','VENDOR-RESULT.json'):
    data=json.loads((W/('BEHAVIOR-'+suffix)).read_text('utf-8'));assert data['status']=='PASS' and data['testsRun']==18
    data=json.loads((W/('HTTP-'+suffix)).read_text('utf-8'));assert data['status']=='PASS' and len(data['groups'])==6
    data=json.loads((W/('FINAL-REVIEW-'+suffix)).read_text('utf-8'));assert data['status']=='PASS' and data['testsRun']==5
    assert all(data['candidateFiles'][name]==digest for name,digest in pins.items())
customer=ast.parse((C/'work/ui-native-r57/customer_workbench.py').read_bytes())
dependencies=next(ast.literal_eval(node.value) for node in customer.body if isinstance(node,ast.Assign)
                  and any(isinstance(target,ast.Name) and target.id=='DEPENDENCY_SHA256' for target in node.targets))
for name in ('business.py','ai_workflow.py','intent_correction.py'):
    assert dependencies['assistant/'+name].lower()==pins['work/ui-runtime-r55/src/assistant/'+name]
    assert (W/'source-view/work/ui-runtime-r55/src/assistant'/name).read_bytes()==(C/'work/ui-runtime-r55/src/assistant'/name).read_bytes()
freeze=(C/'work/ui-native-r57/freeze_ui.py').read_bytes()
assert b'\r\n' not in freeze
assert freeze.count(b"copy_public(HERE / 'customer_intent_workbench.py', release / 'customer_intent_workbench.py')")==1
result={'status':'PASS','source':'v66 saved baseline; no stage writes','generatedAt':datetime.now(timezone.utc).isoformat(),
    'files':rows,'patchSha256':sha(patch),'patchBytes':len(patch),'dependencyPinsVerified':True,
    'sourceViewMatches':True,'utf8WithoutBOM':True,'allPythonParses':True,'freezerOriginalLFStylePreserved':True,
    'expectedConcurrentRootChange':['work/ui-native-r57/workbench_backend.py']}
assert all(row['baselineMatchesCurrentStage'] or row['path']=='work/ui-native-r57/workbench_backend.py' for row in rows)
(W/'PATCH-MANIFEST.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),'utf-8')
(W/'FINAL-FILES-SHA256.json').write_text(json.dumps({'files':pins},ensure_ascii=False,indent=2),'utf-8')
print(json.dumps({'status':'READY_FOR_ROOT_MERGE','files':len(rows),'hunks':sum(row['hunks'] for row in rows),'patchSha256':sha(patch)},ensure_ascii=False))
