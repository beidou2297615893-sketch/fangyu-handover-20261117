/* Durable original-client-key index. Existing AI ledger owns all money. */
const {AiError,hash}=require('./ai_contract.cjs');
const COLLECTION='fangyu_ai_request_index';
const KEY=/^[A-Za-z0-9_.:-]{8,128}$/;
const OPERATIONS=new Set(['intent_analyze','keyword_suggest','content_generate']);
const unresolved=new Set(['reserved','dispatching','unknown']);
const fail=(code,message)=>{throw new AiError('PRODUCT_'+code,message,409);};
function createAiRequestRecovery({companyId,clock=Date.now}){
 const ref=(transaction,username,operation,key)=>{
  if(!transaction?.collection)fail('STORAGE_UNAVAILABLE','原AI请求事务存储未配置，暂不能开始');
  return transaction.collection(COLLECTION).doc(hash(JSON.stringify([companyId,username,operation,key])));
 };
 function scope(user,operation,key){
  if(!user||!['admin','operator'].includes(user.role)||user.disabled||typeof user.username!=='string'||!user.username||
     !OPERATIONS.has(operation)||typeof key!=='string'||!KEY.test(key)||key.startsWith('input:'))
    fail('REQUEST_INVALID','请使用当前员工的原AI操作与请求编号核对');
 }
 async function get(transaction,user,operation,key){
  const snap=await ref(transaction,user.username,operation,key).get();
  const row=Array.isArray(snap.data)?snap.data[0]:snap.data;
  if(!row)return null;
  if(row.companyId!==companyId||row.username!==user.username||row.operation!==operation||row.request_key!==key)
   fail('REQUEST_SCOPE','原AI请求的企业与员工范围需核对');
  if(row.version!==1||typeof row.input_hash!=='string'||!/^[a-f0-9]{64}$/.test(row.input_hash)||
    !['input_anchor','reserved','dispatching','unknown','succeeded','cached','known_unbilled','completed_no_result'].includes(row.status)||
    (row.status==='input_anchor'?(typeof row.target_key!=='string'||!KEY.test(row.target_key)||row.target_key.startsWith('input:')):
     (typeof row.context_hash!=='string'||!/^[a-f0-9]{64}$/.test(row.context_hash)||
      !Number.isSafeInteger(row.config_revision)||row.config_revision<0||
      typeof row.rules_version!=='string'||!row.rules_version||row.rules_version.length>256)))
   fail('REQUEST_SCOPE','原AI请求索引格式需核对，状态保持未知');
  const {_id,...value}=row;return value;
 }
 function set(transaction,user,operation,key,row){
  return ref(transaction,user.username,operation,key).set({...row,companyId,username:user.username,operation,request_key:key});
 }
 const sharedRef=(transaction,operation,inputHash)=>transaction.collection(COLLECTION).doc(hash(JSON.stringify([companyId,'shared_input',operation,inputHash,'company'])));
 async function shared(transaction,operation,inputHash){
  const snap=await sharedRef(transaction,operation,inputHash).get(),row=Array.isArray(snap.data)?snap.data[0]:snap.data;
  if(!row)return null;
  if(row.companyId!==companyId||row.operation!==operation||row.input_hash!==inputHash||row.status!=='company_input_anchor'||
    typeof row.target_username!=='string'||!row.target_username||typeof row.target_key!=='string'||!KEY.test(row.target_key)||row.target_key.startsWith('input:'))
   fail('REQUEST_SCOPE','企业原AI内容占用范围需核对');
  return row;
 }
 async function inspect({transaction,user,operation,key,inputHash,contextHash,cache,legacyLedger,readLedger}){
  scope(user,operation,key);
  const row=await get(transaction,user,operation,key);
  const anchorKey='input:'+inputHash,anchor=await get(transaction,user,operation,anchorKey);
  const previous=anchor?.target_key&&anchor.target_key!==key?await get(transaction,user,operation,anchor.target_key):null;
  const companyAnchor=await shared(transaction,operation,inputHash);
  const companyPrevious=companyAnchor?(companyAnchor.target_username===user.username&&companyAnchor.target_key===key?row:
   await get(transaction,{username:companyAnchor.target_username},operation,companyAnchor.target_key)):null;
  if(companyAnchor&&!companyPrevious||anchor&&!row&&anchor.target_key===key||anchor&&anchor.target_key!==key&&!previous)
   fail('REQUEST_UNKNOWN','原AI内容占用记录的索引缺失，请先核对，不会重复调用模型');
  const priorProof=companyPrevious?await readLedger(companyPrevious.provider_request_id||companyPrevious.result_reference):null;
  const indexedLedger=row?await readLedger(row.provider_request_id||row.result_reference):null;
  if(row&&row.input_hash!==inputHash)fail('REQUEST_CONFLICT','同一AI请求编号的内容已变化，请先核对原请求');
  if(row){
   if(unresolved.has(row.status))fail('REQUEST_UNKNOWN','原AI请求结果仍未知，请按原编号核对，暂勿重复分析');
   if(row.status==='known_unbilled')fail('REQUEST_RELEASED','原AI请求已确认未计费；重新确认后请使用新操作编号');
   if(!indexedLedger||indexedLedger.operation!==operation||indexedLedger.context_hash!==row.context_hash||
     row.provider_request_id&&indexedLedger.username!==user.username||
     ['succeeded','cached'].includes(row.status)&&indexedLedger.status!=='settled')
    fail('REQUEST_UNKNOWN','原AI请求的费用与结果证据尚未核对，请保留原编号');
   if(!['succeeded','cached','completed_no_result'].includes(row.status))fail('REQUEST_SCOPE','原AI请求状态需核对');
   if(row.context_hash!==contextHash||!cache||cache.status!=='ready'||cache.expires_at<=clock()||
      cache.request_id!==row.result_reference||row.status==='completed_no_result')
    fail('REQUEST_RESOLVED','原AI请求已完成，结果已过期或版本变化；不会重复调用模型，请核对历史状态');
  }
  if(!row&&previous&&unresolved.has(previous.status))
   fail('REQUEST_UNKNOWN','相同内容的原AI请求仍未知，换编号或规则版本不会自动重试');
  if(!row&&companyPrevious&&(!priorProof||priorProof.operation!==operation||priorProof.context_hash!==companyPrevious.context_hash||
    companyPrevious.provider_request_id&&priorProof.username!==companyAnchor.target_username||unresolved.has(companyPrevious.status)||
    ['succeeded','cached'].includes(companyPrevious.status)&&priorProof.status!=='settled'||
    companyPrevious.status==='known_unbilled'&&priorProof.status!=='unbilled'||
    companyPrevious.status==='completed_no_result'&&priorProof.status!=='invalid_output'))
   fail('REQUEST_UNKNOWN','企业相同内容仍有未知AI占用，请先核对，不会重复调用模型');
  if(!row&&cache?.status==='ready'&&(!legacyLedger||legacyLedger.operation!==operation||legacyLedger.context_hash!==contextHash||legacyLedger.status!=='settled'))
   fail('REQUEST_UNKNOWN','既有AI缓存的费用与结果证据尚未核对，暂不能恢复');
  // Legacy records lack a permanent client index. A surviving trusted cache
  // link may prove an old unknown attempt; expiry never makes it unexecuted.
  if(!row&&legacyLedger&&legacyLedger.operation===operation&&
     legacyLedger.context_hash===contextHash&&['reserved','billing_unknown'].includes(legacyLedger.status))
   fail('REQUEST_UNKNOWN','历史AI请求仍有未核对预留，请保留原编号；缓存到期不代表未执行');
  return {row,anchorKey,inputHash,contextHash,key,operation,username:user.username};
 }
 async function begin({transaction,user,plan,providerRequestId,cache=null,snapshot}){
  if(plan.row)return {...plan,providerRequestId:plan.row.provider_request_id,replayed:true};
  const cached=cache?.status==='ready'&&cache.expires_at>clock();
  const row={version:1,status:cached?'cached':'reserved',input_hash:plan.inputHash,context_hash:plan.contextHash,
   provider_request_id:cached?null:providerRequestId,result_reference:cached?cache.request_id:null,
   config_revision:snapshot.revision,rules_version:snapshot.rules_version,provider:snapshot.provider,
   model:snapshot.model,reasoning_effort:snapshot.reasoning_effort??null,created_at:clock(),updated_at:clock()};
  await set(transaction,user,plan.operation,plan.key,row);
  await set(transaction,user,plan.operation,plan.anchorKey,{version:1,status:'input_anchor',target_key:plan.key,input_hash:plan.inputHash,updated_at:clock()});
  await sharedRef(transaction,plan.operation,plan.inputHash).set({companyId,operation:plan.operation,input_hash:plan.inputHash,
   status:'company_input_anchor',target_username:user.username,target_key:plan.key,updated_at:clock()});
  return {...plan,providerRequestId:row.provider_request_id,replayed:false};
 }
 async function loadPlan({transaction,plan}){
  const user={username:plan.username,role:'operator'},row=await get(transaction,user,plan.operation,plan.key);
  if(!row||row.input_hash!==plan.inputHash||row.context_hash!==plan.contextHash||row.provider_request_id!==plan.providerRequestId)
   fail('SETTLEMENT_SCOPE','原AI请求索引与费用账本来源需核对');
  return row;
 }
 async function mark({transaction,plan,row}){
  if(!['reserved','dispatching'].includes(row.status))fail('REQUEST_UNKNOWN','原AI请求不能再次启动模型');
  await set(transaction,{username:plan.username},plan.operation,plan.key,{...row,status:'dispatching',updated_at:clock()});
 }
 async function finish({transaction,plan,row,ledger,hasOutput}){
  const status=ledger.status==='settled'&&hasOutput?'succeeded':ledger.status==='unbilled'?'known_unbilled':
   ledger.status==='invalid_output'?'completed_no_result':'unknown';
  await set(transaction,{username:plan.username},plan.operation,plan.key,{...row,status,
   result_reference:status==='succeeded'?plan.providerRequestId:null,updated_at:clock(),completed_at:clock()});
 }
 async function status({transaction,user,operation,key,readLedger,readCache,currentRevision,currentRulesVersion,resultPermission=true}){
  scope(user,operation,key);
  const row=await get(transaction,user,operation,key);
  const base={request_id:key,operation_kind:operation,read_only:true,retry_allowed:false,billing_verified:false};
  if(!row)return {...base,state:'legacy_untracked',coverage:'legacy_untracked',execution_confirmed:null,
   reservation_retained:null,result_available:false,requires_revalidation:true};
  if(row.status==='input_anchor')fail('REQUEST_INVALID','请使用原操作编号，不使用内部内容索引');
  const ledger=await readLedger(row.provider_request_id||row.result_reference);
  if(ledger&&(row.provider_request_id&&ledger.username!==user.username||ledger.operation!==operation||ledger.context_hash!==row.context_hash))
   fail('REQUEST_SCOPE','原AI请求费用记录范围需核对');
  if(!ledger||
    row.status==='succeeded'&&ledger.status!=='settled'||
    row.status==='cached'&&ledger.status!=='settled'||
    row.status==='known_unbilled'&&ledger.status!=='unbilled'||
    row.status==='completed_no_result'&&ledger.status!=='invalid_output')
   return {...base,state:'unknown',coverage:'stable_request_index_v1',execution_confirmed:null,
    reservation_retained:null,result_available:false,requires_revalidation:true};
  const cache=await readCache(row.context_hash);
  const resolved=['succeeded','cached','completed_no_result'].includes(row.status);
  const available=resolved&&row.status!=='completed_no_result'&&cache?.status==='ready'&&cache.expires_at>clock()&&
   cache.request_id===row.result_reference;
  const stale=row.config_revision!==currentRevision||row.rules_version!==currentRulesVersion;
  return {...base,state:unresolved.has(row.status)?'unknown':row.status==='cached'?'succeeded':row.status,
   coverage:'stable_request_index_v1',input_digest:row.input_hash,context_digest:row.context_hash,
   config_revision:row.config_revision,rules_version:row.rules_version,
   execution_confirmed:resolved?true:row.status==='known_unbilled'?false:null,cache_hit:row.status==='cached',
   execution_kind:row.status==='cached'?'cache_hit':resolved?'provider_result':row.status==='known_unbilled'?'known_unbilled':'unknown',
   reservation_retained:unresolved.has(row.status)?true:row.status==='unknown'?true:false,
   result_available:!!available&&!stale&&resultPermission,requires_revalidation:!!stale||!available||!resultPermission};
 }
 function rejectionReceipt({plan,user,environmentId,submissionId,cache,legacyLedger,snapshot}){
  // This proves ONLY the current authenticated submission reached a refusal
  // before begin/reserve/provider. It never turns absent historical evidence
  // into known_unbilled. Keep status(), indexes and all financial rows intact.
  if(!plan||plan.row||cache||legacyLedger||typeof environmentId!=='string'||!environmentId||
    typeof submissionId!=='string'||!/^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(submissionId))return null;
  scope(user,plan.operation,plan.key);
  if(plan.username!==user.username||!Number.isSafeInteger(snapshot.revision)||snapshot.revision<0||
    typeof snapshot.rules_version!=='string'||!snapshot.rules_version||snapshot.rules_version.length>256)
   fail('REQUEST_SCOPE','本次提交拒绝的可信来源需核对');
  return {contract:'ai_no_dispatch_v1',environment_id:environmentId,company_id:companyId,actor:user.username,
   operation_kind:plan.operation,request_id:plan.key,submission_id:submissionId,no_dispatch:true,
   proof_scope:'current_submission',input_digest:plan.inputHash,context_digest:plan.contextHash,
   config_revision:snapshot.revision,rules_version:snapshot.rules_version};
 }
 return {inspect,begin,loadPlan,mark,finish,status,rejectionReceipt};
}
module.exports={createAiRequestRecovery,COLLECTION};
