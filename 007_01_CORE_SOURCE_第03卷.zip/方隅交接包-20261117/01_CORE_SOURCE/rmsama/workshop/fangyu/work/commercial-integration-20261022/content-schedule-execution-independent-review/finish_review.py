from pathlib import Path
import ast,hashlib,json
W=Path(__file__).resolve().parent;P=W.parents[2];C=W.parent/'content-schedule-execution-candidate'
B=P/'work/parallel-integration-20261018/final-integration/candidate-unified-v77/project';S=C/'source-candidate'
sha=lambda b:hashlib.sha256(b).hexdigest()
read=lambda p:json.loads(p.read_text('utf-8-sig'))
def write(name,data):
 with (W/name).open('x',encoding='utf-8') as stream:stream.write(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
def pin(p):return {'path':p.relative_to(W).as_posix(),'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size}
static=read(W/'STATIC-RESULTS.json')
for name,h in static['fixed'].items():assert sha((C/name).read_bytes())==h
manifest=read(C/'SOURCE-FILES.json')
for row in manifest['files']:assert sha((C/'overlay'/row['path']).read_bytes())==row['afterSha256'] and (C/'overlay'/row['path']).read_bytes()==(S/row['path']).read_bytes()
def funcs(raw):
 result={}
 def walk(node,prefix=''):
  for n in ast.iter_child_nodes(node):
   if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef)):
    name=prefix+n.name
    if not isinstance(n,ast.ClassDef):result[name]=ast.dump(n,include_attributes=False)
    walk(n,name+'.')
 walk(ast.parse(raw));return result
deltas=[]
for row in manifest['files']:
 if row['beforeSha256'] and row['path'].endswith('.py'):
  before,after=funcs((B/row['path']).read_bytes()),funcs((S/row['path']).read_bytes())
  deltas.append({'path':row['path'],'changedFunctions':sorted(n for n in before.keys()|after.keys() if before.get(n)!=after.get(n)),'unchangedFunctions':sum(before.get(n)==after.get(n) for n in before)})
host_path='work/ui-native-r57/ui_native_host.py';before,after=funcs((B/host_path).read_bytes()),funcs((S/host_path).read_bytes())
assert [n for n in before.keys()|after.keys() if before.get(n)!=after.get(n)]==['StaticHandler.dispatch_api']
protected=['content_workbench.py','content_workflow.py','content_publishing.py','publishing_port.py','publication_protocol.py','publication_authority_host.py','owned_publication_host.py','publication_policy.py']
protected_pins={}
for name in protected:
 rel='work/ui-native-r57/'+name;a=(B/rel).read_bytes();assert a==(S/rel).read_bytes();protected_pins[name]=sha(a)
core=[]
for f in (B/'work/ui-runtime-r55/src').rglob('*'):
 if f.is_file():
  rel=f.relative_to(B);assert f.read_bytes()==(S/rel).read_bytes();core.append(str(rel))
js=(S/'work/ui-approved-implementation/ui-preview/pages/content-schedule.mjs').read_text('utf-8')
assert all(n not in js for n in ('localStorage','sessionStorage','indexedDB'))
write('GUARD-REVIEW.json',{'status':'PASS','functionAstDelta':deltas,'originalPublicationFilesByteIdentical':protected_pins,'originalCoreFilesByteIdentical':len(core),'sourceCacheGuardAndFactories':'All Native host functions byte-equivalent AST except StaticHandler.dispatch_api, which only exempts tick/reconcile from waiting lock. do_POST/read_public/verify_release/verify_backend_dependencies/create_backend and source-cache guards unchanged.','sessionGrant':'Only host RAM dictionary keyed (scheduleId, approvalDigest), value token+store+selection-revision digest. Durable approval is an audit record of fixed source/time/account, not an executable session grant. Arm replay deliberately never restores a grant.','unknown':'Tick uses durable row.publishRequestId and intentId; unknown does not re-arm; reconciliation rejects different key; original publication policy/AccountModeLeases remain authoritative.','ui':'No browser persistent storage of session grants. Initial bind reads plans; only explicit modal arm grants execution; due polling uses only armed/liveSessionEnabled rows. All source values escaped.'})
scenarios=[];evidence=[];expected={'held','reopen','recover-claim','safety','independent-claims'}
for d in sorted(W.glob('factory-*')):
 r=read(d/'RESULTS.json');f=read(d/'FINAL.json');assert r['status']=='PASS' and f['status']=='PASS' and f['allOwnServersClosed'] and r['realPlatformModelCalls']==0
 assert r['case'] in expected;expected.remove(r['case'])
 scenarios.append({'case':r['case'],'directory':d.name,'httpRequestsNotGroups':f['httpRequests'],'assertions':r['checks'],'syntheticClicks':r['syntheticClicks'],'serversStopped':True})
 for p in sorted(d.rglob('*')):
  if p.is_file() and ('data' not in p.relative_to(d).parts) and p.suffix=='.json':evidence.append(pin(p))
assert not expected and sum(x['httpRequestsNotGroups'] for x in scenarios)==183
write('RESULTS.json',{'status':'PASS_LIMITED_INDEPENDENT_REVIEW','scenarioRuns':5,'httpRequestsNotGroups':183,'businessAssertions':sum(len(s['assertions']) for s in scenarios),'scenarios':scenarios,'authorInputPinsRechecked':True,'authorUiAndLoadOnlyReferenced':'Author 13 full-fit UI and 50/100 synthetic-account pressure tests hash-verified, not rerun. One fixed 390 screenshot visually inspected as developer evidence, not user approval.','realExternalPlatformModelCalls':0,'productionAccess':False,'nativeWindow':False,'allOwnedServersClosed':True,'evidence':evidence})
with (W/'REVIEW.md').open('x',encoding='utf-8') as stream:stream.write('定时内容执行候选有限独审通过，无阻断。固定8个源码文件及1752项作者证据摘要均核对。独立新跑5场景、183个原工厂HTTP请求，使用原Core/Store/AccountModeLeases和发布观察器；只有边界授权与发布回执为合成，未触真实平台。\n\n已实际验证默认发布关闭不点击、unknown仅查原编号、固定稿件变化及错过宽限停止、重开与切门店不沿用会话授权、旧arm请求重放不重授、取消/恢复后的旧线程不能覆盖新授权。同计划双tick仅一次合成unknown；账号owner撤回和错平台拒绝，固定UID变化先使审批失效。\n\n审批历史持久保存，执行会话许可只在RAM；两者用途分开。原发布协议、企业/账号授权与共享mode租约未放宽。原发布8文件和Core源码逐字未改，Native完整性与cacheguard函数不变。\n\n本审未重跑作者50/100压力或13项UI，只核固定证据并看一张390截图；未验证真实平台发布、关闭软件后执行、普通电脑编译包、Native或本人视觉认可。原WIRE_POLICY/发布hold保持，不能当作商业自动发布验收。所有自有服务结束，候选与生产未写。\n')
write('FINAL-RECEIPT.json',{'status':'PASS_LIMITED_INDEPENDENT_REVIEW_NO_BLOCKER','candidate':str(C),'fixedInputs':static['fixed'],'static':pin(W/'STATIC-RESULTS.json'),'guards':pin(W/'GUARD-REVIEW.json'),'results':pin(W/'RESULTS.json'),'review':pin(W/'REVIEW.md'),'scenarioRuns':5,'httpRequestsNotGroups':183,'authorUiAndPressureIndependentlyRerun':False,'realPlatformPublishingValidated':False,'commercialReleaseApproved':False,'canonicalInstallApproved':False,'productionWrites':False,'servicesStopped':True})
write('SEALED.json',{'status':'SEALED_INDEPENDENT_REVIEW_STOPPED','files':[pin(W/name) for name in ('FINAL-RECEIPT.json','REVIEW.md','RESULTS.json','GUARD-REVIEW.json','STATIC-RESULTS.json','prepare_review.py','prepare_extra.py','test_factory_schedule.py','test_independent_claims.py','finish_review.py')]})
print(json.dumps({n:sha((W/n).read_bytes()) for n in ('FINAL-RECEIPT.json','SEALED.json','RESULTS.json','GUARD-REVIEW.json')},ensure_ascii=False))
