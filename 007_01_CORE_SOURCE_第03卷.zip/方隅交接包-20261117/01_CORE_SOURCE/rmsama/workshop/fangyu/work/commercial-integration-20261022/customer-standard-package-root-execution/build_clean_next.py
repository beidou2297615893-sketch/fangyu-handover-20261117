"""Clean held successor tooling; all writes stay in this new owned directory.

Reuses the pinned public closure, original PyInstaller runtime and original
protected self-extracting installer. Never imports or executes the old product builder.
"""
from pathlib import Path, PurePosixPath
from datetime import datetime, timezone
import argparse, ast, hashlib, importlib.util, json, os, re, shutil, stat, subprocess, sys, zipfile

sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
P=HERE.parents[2]
BASE=None # Requires the caller's explicit new final root pins and path.
PYTHON=P/'work/desktop-python/Scripts/python.exe'
SAMPLE=HERE/'standard-held-clean-v82'
DIST=SAMPLE/'dist'
NAME='FangyuWorkbench'
HELD_STANDARD=False
INCLUDE_WEBVIEW2=True
VERSION=None
ROOT_PINS=None
CLEAN_ENTRY=False
UNIFIED_SHA=''
SOURCE_INSPECT=HERE/'INPUT-DISTRIBUTION-INSPECTION.json'
INSTALLER_SOURCE=P/'work/commercial-integration-20261022/final-installer-upgrade-audit/runtime-message-candidate/installer.runtime-message-shortcut.py'


def sha(raw):return hashlib.sha256(raw).hexdigest()
def js(path):return json.loads(path.read_text('utf-8-sig'))
def dump(path,value):
    with path.open('x',encoding='utf-8') as stream:json.dump(value,stream,ensure_ascii=False,indent=2);stream.write('\n')
def safe_read(path):
    for part in (path,*path.parents):
        if part.is_symlink() or getattr(part.lstat(),'st_file_attributes',0)&0x400:raise RuntimeError('Link input refused')
    info=path.stat()
    if not stat.S_ISREG(info.st_mode) or info.st_nlink!=1:raise RuntimeError('Non-plain input refused')
    raw=path.read_bytes()
    if (info.st_dev,info.st_ino,info.st_size,info.st_mtime_ns)!=(path.stat().st_dev,path.stat().st_ino,path.stat().st_size,path.stat().st_mtime_ns):raise RuntimeError('Input changed')
    return raw


def own_environment():
    env=dict(os.environ)
    for key in ('PYTHONHOME','PYTHONPATH','VIRTUAL_ENV'):env.pop(key,None)
    for key,folder in (('PYINSTALLER_CONFIG_DIR','build-cache'),('TEMP','temp'),('TMP','temp'),('LOCALAPPDATA','build-localappdata'),('APPDATA','build-appdata')):
        target=SAMPLE/folder;target.mkdir(parents=True,exist_ok=True);env[key]=str(target)
    env['PYTHONDONTWRITEBYTECODE']='1';env['PYTHONIOENCODING']='utf-8'
    return env


def run(argv,log,timeout=900):
    with (SAMPLE/log).open('x',encoding='utf-8') as stream:
        process=subprocess.run([str(a) for a in argv],cwd=HERE,env=own_environment(),stdout=stream,stderr=subprocess.STDOUT,
            timeout=timeout,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
    if process.returncode:raise RuntimeError('Tool failed; see '+log)


def stage():
    if SAMPLE.exists():raise RuntimeError('Representative directory already exists; preserve it')
    if sha(safe_read(INSTALLER_SOURCE))!='5f9b4d7ab00b6348d07d15a241ad804cf593ec137d576e5a3ce67476df01dca9':raise RuntimeError('Reviewed protected installer source changed')
    raw=safe_read(BASE/'UNIFIED-PINS.json');manifest=json.loads(raw)
    _validate_root_inputs()
    expected_sha=ROOT_PINS['unifiedPinsSha256'];expected_count=ROOT_PINS['unifiedFileCount']
    if sha(safe_read(BASE/'STAGED.json'))!=ROOT_PINS['stagedSha256']:raise RuntimeError('Root staged pin differs')
    if sha(raw)!=expected_sha or len(manifest['files'])!=expected_count:raise RuntimeError('Fixed source input differs')
    staged=js(BASE/'STAGED.json');release_id=staged['release_id']
    if release_id!=ROOT_PINS['releaseId'] or sha(safe_read(Path(staged['release'])/'RELEASE.json'))!=ROOT_PINS['manifestSha256']:raise RuntimeError('Root release pin differs')
    SAMPLE.mkdir();project=SAMPLE/'payload/project';project.mkdir(parents=True)
    omitted=[];copied=[]
    for row in manifest['files']:
        relative=PurePosixPath(row['path'])
        if relative.is_absolute() or '..' in relative.parts or ':' in str(relative) or '\\' in str(relative):raise RuntimeError('Invalid public member')
        if str(relative).startswith(('work/ui-native-r57/state/','work/ui-native-r57/candidates/','work/ui-native-r57/run_candidate.')):
            omitted.append(str(relative));continue
        source=BASE/'project'/relative;body=safe_read(source)
        if sha(body)!=row['sha256'] or len(body)!=row['bytes']:raise RuntimeError('Public sample member differs')
        if source.name.lower() in ('ffmpeg.exe','ffprobe.exe') or source.suffix.lower() in ('.safetensors','.gguf','.ckpt','.pt','.pth','.onnx'):
            raise RuntimeError('Unwanted model/GPL runtime')
        target=project/relative;target.parent.mkdir(parents=True,exist_ok=True)
        with target.open('xb') as stream:stream.write(body)
        copied.append(str(relative))
    company=js(project/'work/app/company.json')
    company.pop('localCliPaths',None);company.pop('updateFeed',None)
    company['releaseVersion']=RELEASE_VERSION
    company['runtime'].pop('portable_employee_release',None)
    company['runtime']['executable']=NAME+'.exe'
    company['runtime']['release_approved']=False
    company['runtime']['public_send_hold']=True
    company['runtime']['xiaohongshu_automation']='hold'
    if HELD_STANDARD:
        company['runtime']['standard_distribution_schema']='fangyu-held-standard-r57/1'
        company['runtime']['standard_native_release_id']=release_id
    (project/'work/app/company.json').write_text(json.dumps(company,ensure_ascii=False,indent=2)+'\n','utf-8')
    dump(SAMPLE/'payload/company.json',company)
    derived=[]
    if HELD_STANDARD:
        release=project/'work/ui-native-r57/releases'/release_id
        guard=release/'resources/platform-runtime/vendor-src/assistant/employee_distribution.py'
        app=release/'resources/platform-runtime/vendor-src/app.py'
        release_manifest=release/'RELEASE.json'
        excluded={guard.relative_to(project).as_posix(),release_manifest.relative_to(project).as_posix()}
        code=[]
        for name in sorted(copied):
            if name in excluded:continue
            path=project/name
            if path.suffix.lower() in ('.py','.js','.mjs','.exe','.dll','.pyd'):
                body=path.read_bytes();code.append({'path':name,'bytes':len(body),'sha256':sha(body)})
        contract={'schema':'fangyu-held-standard-code-manifest-v1','companyId':'fangyu-apartment-client',
            'channel':'internal_standard_candidate','commercialDistributionApproved':False,'platformExecutionApproved':False,
            'nativeReleaseId':release_id,'sourceClosureSha256':sha(raw),
            'wrapperSha256':company['runtime']['cli_source_sha256'],
            'companyConfigDigest':sha(json.dumps(company,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode()),
            'codeFileCount':len(code),'codeFiles':code,
            'excludedFromInnerManifest':[guard.relative_to(project).as_posix(),release_manifest.relative_to(project).as_posix()],
            'outerCompiledEntryPinsAllFilesIncludingGuardAndNativeManifest':True}
        dump(project/'HELD-STANDARD-MANIFEST.json',contract);copied.append('HELD-STANDARD-MANIFEST.json')
        source_guard=guard.read_bytes();source_app=app.read_bytes();source_release=release_manifest.read_bytes()
        body=source_guard.decode('utf-8').replace('\r\n','\n')
        needle='def runtime_config_valid(config):\n'
        if body.count(needle)!=1:raise RuntimeError('Source package gate changed')
        body=body.replace(needle,needle+'    if held_standard_config_valid(config):\n        return True\n')
        body+=(HERE/'held_standard_contract.py.in').read_text('utf-8').replace('@@MANIFEST_SHA@@',repr(sha((project/'HELD-STANDARD-MANIFEST.json').read_bytes())))
        ast.parse(body);guard.write_text(body,'utf-8')
        release_doc=json.loads(source_release)
        for row in release_doc['files']:
            if row['path']==guard.relative_to(release).as_posix():
                row['sha256']=sha(guard.read_bytes()).upper();row['size']=guard.stat().st_size
        release_doc['heldStandardDistributionCompatibility']={'internalOnly':True,'commercialApproved':False,
            'derivedFromNativeReleaseSha256':sha(source_release),'contractManifest':'HELD-STANDARD-MANIFEST.json'}
        release_manifest.write_text(json.dumps(release_doc,ensure_ascii=False,indent=2)+'\n','utf-8')
        for path,source in ((guard,source_guard),(release_manifest,source_release)):
            derived.append({'path':path.relative_to(project).as_posix(),'sourceSha256':sha(source),'derivedSha256':sha(path.read_bytes())})
        # These are pure synthetic QA assets, not existing users or sessions.
        if not CLEAN_ENTRY:
            fixture=js(P/'work/central-store-config/compiled-fixture.json')
            dump(project/'STANDARD-QA-FIXTURE.json',{'manifest':fixture['manifest'],'documents':fixture['documents']})
            copied.append('STANDARD-QA-FIXTURE.json')
            qa=(HERE/'standard_functional_qa.py').read_bytes()
            with (project/'STANDARD-FUNCTIONAL-QA.py').open('xb') as stream:stream.write(qa)
            copied.append('STANDARD-FUNCTIONAL-QA.py')
    release=project/'work/ui-native-r57/releases'/release_id
    _company_held(company)
    _held_stable(project,release)
    helper=_verify_helper(project,release)
    _copy_external_cli()
    dump(SAMPLE/'STAGE.json',{'status':'CLEAN_HELD_STAGED_AWAITING_PURPOSE_MATERIALS_NOT_BUILDABLE',
        'releaseId':release_id,'sourceClosureSha256':sha(raw),'rootPinsSha256':ROOT_PINS_SHA,
        'externalDescriptorSha256':EXTERNAL_INPUTS_SHA,'copiedSourceFiles':len(copied),
        'omittedDescriptors':omitted,'derivedFiles':derived,'companyVersion':RELEASE_VERSION,
        'companySha256':sha(safe_read(project/'work/app/company.json')),
        'heldManifestSha256':sha(safe_read(project/'HELD-STANDARD-MANIFEST.json')),
        'helper':helper,'syntheticQaAssetsIncluded':False,'cleanEntry':True,
        'globalReleaseApproved':False,'publicSendHold':True,'productionBindingIncluded':False,
        'productionDataIncluded':False,'installationApproved':False,
        'installerSourceSha256':sha(safe_read(INSTALLER_SOURCE))})
    print(json.dumps({'status':'STAGED_AWAITING_MATERIALS_NOT_BUILDABLE','files':len(copied),
        'companyVersion':RELEASE_VERSION,'payloadRoot':str(SAMPLE/'payload')},ensure_ascii=True))


def build():
    _require_finalized()
    report=js(SAMPLE/'STAGE.json')
    stdlib=js(SOURCE_INSPECT)['stdlibImports']
    base=[PYTHON,'-I','-B','-m','PyInstaller','--noconfirm','--clean','--distpath',DIST,
        '--workpath',SAMPLE/'pyinstaller','--specpath',SAMPLE]
    args=base+['--onedir','--windowed','--name',NAME]
    for name in ('webview','pythonnet','clr_loader','PIL','cryptography','tuf','securesystemslib','httpx'):
        args+=['--collect-all',name]
    for name in stdlib:args+=['--hidden-import',name]
    args+=['--copy-metadata','pywebview','--icon',BASE/'project/work/app/src/resources/brand.ico',SAMPLE/'standard_entry.py']
    run(args,'client-build.log')
    portable=DIST/NAME
    # Only these two fixed closed code roots and the sanitized company copy.
    # Natural helper remains inside project; no new sibling is invented.
    for member in ('project','platform-cli-customer-read'):
        shutil.copytree(SAMPLE/'payload'/member,portable/member)
    shutil.copy2(SAMPLE/'payload/company.json',portable/'company.json')
    if INCLUDE_WEBVIEW2:
        prerequisite=P/'work/packaging/prerequisites/MicrosoftEdgeWebView2RuntimeInstallerX64.exe'
        if not prerequisite.is_file():raise RuntimeError('Existing Microsoft WebView2 offline prerequisite missing')
        (portable/'prerequisites').mkdir();shutil.copy2(prerequisite,portable/'prerequisites'/prerequisite.name)
    (portable/'使用说明.txt').write_text('方隅工作台\n\n双击 FangyuWorkbench.exe 打开。首次使用请用管理员分配的企业员工账号登录。\n本包不会提供其他电脑的登录状态或客户资料。\n\n本包为内部标准候选，尚未批准交给员工正式使用。\n视频制作需要已核验的外置 FFmpeg，本包不附该工具，也不会自动下载。\n需要电脑已有微软 WebView2；缺少时请联系管理员准备。\n','utf-8-sig')
    installer_copy=SAMPLE/'installer.protected.py'
    with installer_copy.open('xb') as stream:stream.write(safe_read(INSTALLER_SOURCE))
    if sha(installer_copy.read_bytes())!=report['installerSourceSha256']:raise RuntimeError('Original installer changed')
    run(base+['--onefile','--windowed','--name','FangyuWorkbenchSetup','--icon',BASE/'project/work/app/src/resources/brand.ico',
        '--add-data',str(BASE/'project/work/app/src/resources/brand.ico')+';.',installer_copy],'installer-build.log')
    files=_inventory(portable)
    dump(SAMPLE/'FILE-MANIFEST.json',{'status':'REPRESENTATIVE_SAMPLE_ONLY','files':files,'count':len(files),
        'bytes':sum(row['bytes'] for row in files),'modelWeightsIncluded':False,'ffmpegBinaryIncluded':False,'venvIncluded':False})
    archive=SAMPLE/('FangyuWorkbench-'+SAMPLE.name+'.zip')
    with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=5) as z:
        for row in files:z.write(portable/row['path'],row['path'])
    setup=SAMPLE/('FangyuWorkbenchSetup-'+SAMPLE.name+'.exe')
    shutil.copy2(DIST/'FangyuWorkbenchSetup.exe',setup)
    with setup.open('ab') as stream,archive.open('rb') as source:shutil.copyfileobj(source,stream)
    with zipfile.ZipFile(setup) as z:
        bad=z.testzip()
        if bad:raise RuntimeError('Embedded original-installer payload corrupt')
    dump(SAMPLE/'BUILD.json',{'status':'REPRESENTATIVE_DISTRIBUTION_BUILT_NOT_APPROVED','files':len(files),
        'bytes':sum(row['bytes'] for row in files),'portableZip':archive.name,'portableSha256':sha(archive.read_bytes()),
        'installer':setup.name,'installerSha256':sha(setup.read_bytes()),'installerBytes':setup.stat().st_size,
        'originalInstallerUnmodified':False,'protectedInstallerUnmodifiedFromReviewedSuccessor':True,'productionWrites':False,'localModelOrGpu':False,'bundledFfmpeg':False})
    print(json.dumps({'status':'REPRESENTATIVE_DISTRIBUTION_BUILT_NOT_APPROVED','files':len(files),'installerBytes':setup.stat().st_size},ensure_ascii=True))


# Successor packaging helpers. No grant, installer change or product execution.
RELEASE_VERSION='1.2.0-read.1'
ADAPTER_SHA='4b41e4d4c5ec1bcaafbb17c41b1489d15429a5b1313586ec56a467acc8a8b405'
SELECTOR_SHA='58cd9c8066533eb9196ef69fcad325bd0be9fb47a333dbf236d5b776bac3b33a'
NATURAL_HELPER_MANIFEST_SHA='576a60b99eb5f75d6a85b26c2713d5d080552b788b2fe9863746d1337ebce76d'
REQUIRED_PURPOSES=frozenset(('douyin_owned_connection','douyin_owned_video_comments','douyin_owned_keyword_search_page','xiaohongshu_guarded_read','xiaohongshu_natural_read','xiaohongshu_identity_observation','xiaohongshu_session_recovery'))
ROOT_PINS_SHA=None
EXTERNAL_INPUTS=None
EXTERNAL_INPUTS_SHA=None
CODE_EXT=frozenset(('.py','.js','.mjs','.exe','.dll','.pyd'))


def _relative(value):
    if type(value) is not str or not value or '\\' in value or ':' in value or any(p in ('','.','..') for p in value.split('/')):raise RuntimeError('Unsafe inventory member')
    return PurePosixPath(value)


def _inventory(root):
    root=Path(root)
    for part in (root,*root.parents):
        if part.is_symlink() or getattr(part.lstat(),'st_file_attributes',0)&0x400:raise RuntimeError('Linked inventory root refused')
    if not root.is_dir():raise RuntimeError('Inventory root missing')
    rows=[]
    for path in sorted(root.rglob('*'),key=lambda p:p.relative_to(root).as_posix()):
        info=path.lstat()
        if path.is_symlink() or getattr(info,'st_file_attributes',0)&0x400:raise RuntimeError('Linked inventory member refused')
        relative=path.relative_to(root).as_posix();_relative(relative)
        if '__pycache__' in path.parts or path.suffix.lower() in ('.pyc','.pyo'):raise RuntimeError('Disk Python cache refused')
        if path.is_file():
            body=safe_read(path);rows.append({'path':relative,'bytes':len(body),'sha256':sha(body)})
        elif not path.is_dir():raise RuntimeError('Non-plain inventory member refused')
    return rows


def _assert_rows(root,rows):
    if type(rows) is not list or not rows or len(rows)>30000:raise RuntimeError('Fixed inventory required')
    names=set()
    for row in rows:
        if type(row) is not dict or set(row)!={'path','bytes','sha256'} or type(row['bytes']) is not int or row['bytes']<0 or type(row['sha256']) is not str or not re.fullmatch('[0-9a-f]{64}',row['sha256']):raise RuntimeError('Invalid fixed inventory')
        _relative(row['path'])
        if row['path'] in names:raise RuntimeError('Duplicate fixed inventory member')
        names.add(row['path'])
    if _inventory(root)!=sorted(rows,key=lambda r:r['path']):raise RuntimeError('Actual complete tree differs from fixed inventory')


def _company_held(company):
    runtime=company.get('runtime')
    if type(runtime) is not dict or company.get('releaseVersion')!=RELEASE_VERSION or company.get('edition')!='customer' or company.get('personalMode') is not False or company.get('authMode')!='managed' or runtime.get('release_approved') is not False or runtime.get('public_send_hold') is not True or runtime.get('xiaohongshu_automation')!='hold' or runtime.get('executable')!=NAME+'.exe' or 'portable_employee_release' in runtime:raise RuntimeError('Original clean held company decisions changed')
    if any(k in runtime for k in ('private_evaluation','private_evaluation_session_id','platform_qa_device_id')):raise RuntimeError('QA/private runtime option refused')


def _validate_root_inputs():
    if ROOT_PINS is None or ROOT_PINS_SHA is None or ROOT_PINS.get('rootExplicitFinalPins') is not True or ROOT_PINS.get('candidate')!='candidate-unified-v'+str(VERSION) or ROOT_PINS.get('fixtureOnly') is True:raise RuntimeError('Explicit actual final root pins required; QA descriptors refused')
    raw=safe_read(BASE/'UNIFIED-PINS.json');doc=json.loads(raw);staged=js(BASE/'STAGED.json')
    if sha(raw)!=ROOT_PINS['unifiedPinsSha256'] or len(doc['files'])!=ROOT_PINS['unifiedFileCount'] or sha(safe_read(BASE/'STAGED.json'))!=ROOT_PINS['stagedSha256'] or staged['release_id']!=ROOT_PINS['releaseId']:raise RuntimeError('Root final source/stage inputs changed')
    release=BASE/'project/work/ui-native-r57/releases'/staged['release_id']
    if Path(staged['release'])!=release or sha(safe_read(release/'RELEASE.json'))!=ROOT_PINS['manifestSha256']:raise RuntimeError('Root final release input changed')
    return staged['release_id']


def _external_descriptor():
    if EXTERNAL_INPUTS is None or type(EXTERNAL_INPUTS_SHA) is not str:raise RuntimeError('Explicit fixed external CLI descriptor required')
    doc=EXTERNAL_INPUTS
    if set(doc)!={'schema','name','source','files','public_send_grant','login_grant','dataIncluded'} or doc['schema']!='fixed_customer_read_sibling_payload_v1' or doc['name']!='platform-cli-customer-read' or doc['public_send_grant'] is not False or doc['login_grant'] is not False or doc['dataIncluded'] is not False:raise RuntimeError('Only explicit customer-read CLI sibling is accepted')
    source=Path(doc['source'])
    if not source.is_absolute() or '..' in source.parts or source.name!='platform-cli-customer-read':raise RuntimeError('Fixed CLI source root differs')
    for row in doc['files']:
        parts=_relative(row['path']).parts
        if parts[0].lower() in ('project','data','state','vault','qa-fixtures','fixtures','profiles','sessions','logs') or Path(row['path']).suffix.lower() in ('.db','.sqlite','.sqlite3','.gguf','.safetensors','.onnx','.ckpt','.pth','.pt'):raise RuntimeError('Private/QA/model external payload refused')
    _assert_rows(source,doc['files'])
    if not {'platform-cli.exe','guard-manifest.json'}.issubset({r['path'] for r in doc['files']}):raise RuntimeError('Customer CLI executable/guard missing')
    guard=js(source/'guard-manifest.json')
    if guard.get('purpose')!='customer_distribution_read_only' or guard.get('public_send_grant') is not False or guard.get('login_grant') is not False or set(guard.get('read_commands',()))!={'status','whoami','search','read','comments','sub-comments'}:raise RuntimeError('Original customer-read CLI guard differs')
    return doc


def _copy_external_cli():
    doc=_external_descriptor();target=SAMPLE/'payload/platform-cli-customer-read'
    if target.exists():raise RuntimeError('Keep the prior external payload; do not overwrite')
    target.mkdir(parents=True)
    for row in doc['files']:
        raw=safe_read(Path(doc['source'])/row['path'])
        if len(raw)!=row['bytes'] or sha(raw)!=row['sha256']:raise RuntimeError('External CLI changed during copy')
        dest=target/row['path'];dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(raw)
    _assert_rows(target,doc['files'])


def _verify_helper(project,release):
    suffix=Path('resources/xhs-page-helper/FangyuXhsPageHelper')
    roots=[project/'work/source-v66-worker/component/artifacts/xhs-page-helper/FangyuXhsPageHelper',release/suffix]
    source_rows=None
    for root in roots:
        raw=safe_read(root/'HELPER-PACKAGE.json')
        if sha(raw)!=NATURAL_HELPER_MANIFEST_SHA:raise RuntimeError('Natural helper fixed manifest differs')
        doc=json.loads(raw)
        if doc.get('schema')!='portable_xhs_page_helper_v1' or doc.get('entry')!='FangyuXhsPageHelper.exe':raise RuntimeError('Natural helper contract differs')
        rows=doc['files']+[{'path':'HELPER-PACKAGE.json','bytes':len(raw),'sha256':sha(raw)}]
        _assert_rows(root,rows)
        if source_rows is not None and source_rows!=rows:raise RuntimeError('Natural helper source/release copies differ')
        source_rows=rows
    return {'sourceAndReleaseCopiesEqual':True,'filesEach':len(source_rows),'manifestSha256':NATURAL_HELPER_MANIFEST_SHA,'programSiblingCreated':False}


def _held_stable(project,release):
    company=js(project/'work/app/company.json');_company_held(company)
    helper=release/'resources/platform-runtime/vendor-src/assistant/employee_distribution.py'
    doc=js(project/'HELD-STANDARD-MANIFEST.json');raw=safe_read(project/'HELD-STANDARD-MANIFEST.json')
    pins=[n.value.value for n in ast.parse(safe_read(helper)).body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='HELD_STANDARD_MANIFEST_SHA256' for t in n.targets) and isinstance(n.value,ast.Constant)]
    excluded={helper.relative_to(project).as_posix(),(release/'RELEASE.json').relative_to(project).as_posix()}
    if pins!=[sha(raw)] or doc.get('commercialDistributionApproved') is not False or doc.get('platformExecutionApproved') is not False or doc.get('channel')!='internal_standard_candidate' or doc.get('nativeReleaseId')!=release.name or set(doc['excludedFromInnerManifest'])!=excluded:raise RuntimeError('Original held helper/false decisions are not stable')
    if doc['companyConfigDigest']!=sha(json.dumps(company,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode()):raise RuntimeError('Held company digest is stale')
    actual=[r for r in _inventory(project) if Path(r['path']).suffix.lower() in CODE_EXT and r['path'] not in excluded]
    if doc['codeFiles']!=actual or doc['codeFileCount']!=len(actual):raise RuntimeError('Code changed after held staging; restage before material review')
    return sha(raw)


def _all_false_evidence(value):
    false_keys={'commercialDistributionApproved','platformExecutionApproved','public_send_grant','publicSendGrant','send_grant','native_loaded_bytes_verified','real_platform_verified','realPlatformVerified','nativeVerified','loginGrant','public_send_grant'}
    if type(value) is dict:
        for key,item in value.items():
            if key in false_keys and item is not False:raise RuntimeError('A purpose material claims an unverified external grant')
            _all_false_evidence(item)
    elif type(value) is list:
        for item in value:_all_false_evidence(item)


def _purpose_materials(project,release):
    company=js(project/'work/app/company.json');_company_held(company)
    index_path=release/'resources/customer-read/review-index.json';index=js(index_path)
    if index.get('schema')!='fangyu_customer_read_material_index_v1' or index.get('scope')!='customer_distribution_read' or index.get('executable')!=NAME+'.exe' or index.get('company_binding',{}).get('releaseVersion')!=RELEASE_VERSION:raise RuntimeError('Final customer-read material index missing or stale')
    records=index.get('reviews')
    if type(records) is not list or len(records)!=len(REQUIRED_PURPOSES) or {r.get('purpose') for r in records}!=REQUIRED_PURPOSES:raise RuntimeError('Final three DY, CLI and natural-three material union required')
    for row in records:
        if set(row)!={'purpose','path','bytes','sha256'}:raise RuntimeError('Purpose index record differs')
        rel=_relative(row['path'])
        if rel.parts[:2]!=('resources','customer-read'):raise RuntimeError('Purpose outside fixed customer-read directory')
        path=release/rel;raw=safe_read(path)
        if len(raw)!=row['bytes'] or sha(raw)!=row['sha256']:raise RuntimeError('Stale purpose material pin')
        material=json.loads(raw);_all_false_evidence(material)
        if 'company_binding' in material and material['company_binding']!=index['company_binding']:raise RuntimeError('Purpose company binding is stale')
        if row['purpose'] in {'xiaohongshu_natural_read','xiaohongshu_identity_observation','xiaohongshu_session_recovery'} and material.get('schema')!='fangyu_customer_natural_material_review_v1':raise RuntimeError('Natural purpose schema differs')
    return {'indexSha256':sha(safe_read(index_path)),'purposes':sorted(REQUIRED_PURPOSES),'licenseSourceMaterialsOnly':True,'platformOrAccountApprovalClaimed':False}


def _render_clean_entry(release_id,release_sha,closure_sha):
    # This exact block is inherited from the reviewed clean builder.
    template=(HERE/'standard_entry.py.in').read_text('utf-8')
    for token,value in (('RELEASE_ID',release_id),('RELEASE_SHA',release_sha),('CLOSURE_SHA',closure_sha),('SAMPLE',True)):
        template=template.replace('@@'+token+'@@',repr(value))
    tree=ast.parse(template);main_guard=tree.body[-1]
    if not isinstance(main_guard,ast.If):raise RuntimeError('Entry template main guard differs')
    original_main=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='main')
    # The sealed current template already has the same clean main function.
    # Explicitly reconstructing the original AST-removal step retains no QA path.
    tree.body=[n for n in tree.body[:-1] if not (isinstance(n,ast.FunctionDef) and n.name in ('smoke','native_smoke','main')) and not (isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='SAMPLE' for t in n.targets))]+[original_main,main_guard]
    rendered=(ast.unparse(ast.fix_missing_locations(tree))+'\n').encode('utf8')
    if any(word in rendered.decode('utf8') for word in ('SAMPLE','CloudStandin','STANDARD-QA','runtime-smoke','native-smoke')):raise RuntimeError('Clean entry retained a QA branch')
    adapter_raw=safe_read(HERE/'adapt_clean_entry.py');selector_raw=safe_read(HERE/'existing_workspace_entry.py')
    if sha(adapter_raw)!=ADAPTER_SHA or sha(selector_raw)!=SELECTOR_SHA:raise RuntimeError('Sealed existing-workspace adapter changed')
    module=importlib.util.module_from_spec(importlib.util.spec_from_loader('reviewed_clean_entry_adapter',loader=None));module.__file__=str(HERE/'adapt_clean_entry.py')
    exec(compile(adapter_raw,module.__file__,'exec',dont_inherit=True,optimize=0),module.__dict__)
    adapted=module.adapt_entry(rendered,selector_raw,expected_entry_sha=sha(rendered));ast.parse(adapted)
    return rendered,adapted


def finalize():
    _validate_root_inputs();stage_doc=js(SAMPLE/'STAGE.json')
    if stage_doc['rootPinsSha256']!=ROOT_PINS_SHA or stage_doc['externalDescriptorSha256']!=EXTERNAL_INPUTS_SHA:raise RuntimeError('Stage belongs to different explicit inputs')
    if (SAMPLE/'FINALIZED.json').exists():raise RuntimeError('Preserve the prior finalized artifact')
    project=SAMPLE/'payload/project';release=project/'work/ui-native-r57/releases'/stage_doc['releaseId']
    _company_held(js(project/'work/app/company.json'))
    if safe_read(SAMPLE/'payload/company.json')!=safe_read(project/'work/app/company.json'):raise RuntimeError('Outer company copy changed')
    _assert_rows(SAMPLE/'payload/platform-cli-customer-read',_external_descriptor()['files'])
    _held_stable(project,release);helper=_verify_helper(project,release);materials=_purpose_materials(project,release)
    # All purpose generators have finished. These are the original builder's
    # RELEASE/SHIPPED manifests, calculated from the actual final bytes.
    release_doc=js(release/'RELEASE.json')
    release_doc['files']=[{'path':r['path'],'size':r['bytes'],'sha256':r['sha256'].upper()} for r in _inventory(release) if r['path']!='RELEASE.json']
    (release/'RELEASE.json').write_text(json.dumps(release_doc,ensure_ascii=False,indent=2)+'\n','utf8')
    entries=[r for r in _inventory(project) if r['path']!='SHIPPED-PINS.json']
    closure={'schema':'fangyu-standard-full-public-project-v1','representativeSampleOnly':False,'internalStandardCandidate':True,'commercialDistributionApproved':False,'releaseId':release.name,'sourceClosureSha256':ROOT_PINS['unifiedPinsSha256'],'sourceFiles':ROOT_PINS['unifiedFileCount'],'files':entries,'privateInstallationDescriptorsOmitted':stage_doc['omittedDescriptors'],'existingDataOrSecretsIncluded':False}
    dump(project/'SHIPPED-PINS.json',closure)
    before,adapted=_render_clean_entry(release.name,sha(safe_read(release/'RELEASE.json')),sha(safe_read(project/'SHIPPED-PINS.json')))
    with (SAMPLE/'clean-entry-before-adapter.py').open('xb') as stream:stream.write(before)
    with (SAMPLE/'standard_entry.py').open('xb') as stream:stream.write(adapted)
    stdlib=set()
    for row in entries:
        path=project/row['path']
        if path.suffix=='.py':
            tree=ast.parse(safe_read(path))
            for node in ast.walk(tree):
                if isinstance(node,ast.Import):stdlib.update(n.name.split('.')[0] for n in node.names if n.name.split('.')[0] in sys.stdlib_module_names)
                elif isinstance(node,ast.ImportFrom) and node.level==0 and node.module and node.module.split('.')[0] in sys.stdlib_module_names:stdlib.add(node.module.split('.')[0])
    dump(SOURCE_INSPECT,{'status':'ACTUAL_FINAL_STAGED_SOURCE_STDLIB_UNION_NOT_RUNTIME_ACCEPTANCE','sourceClosureSha256':ROOT_PINS['unifiedPinsSha256'],'shippedSha256':sha(safe_read(project/'SHIPPED-PINS.json')),'stdlibImports':sorted(stdlib)})
    payload_rows=_inventory(SAMPLE/'payload')
    dump(SAMPLE/'FINALIZED.json',{'status':'CLEAN_HELD_FINALIZED_NOT_COMPILED_OR_APPROVED','rootPinsSha256':ROOT_PINS_SHA,'externalDescriptorSha256':EXTERNAL_INPUTS_SHA,'releaseId':release.name,'releaseSha256':sha(safe_read(release/'RELEASE.json')),'shippedSha256':sha(safe_read(project/'SHIPPED-PINS.json')),'entryBeforeAdapterSha256':sha(before),'entrySha256':sha(adapted),'sourceInspectionSha256':sha(safe_read(SOURCE_INSPECT)),'helper':helper,'customerReadMaterials':materials,'payloadFiles':payload_rows,'companyVersion':RELEASE_VERSION,'globalReleaseApproved':False,'publicSendHold':True,'installationApproved':False})
    print(json.dumps({'status':'FINALIZED_NOT_COMPILED_NOT_APPROVED','files':len(entries),'payloadFiles':len(payload_rows),'adapterUsed':ADAPTER_SHA}))


def _require_finalized():
    _validate_root_inputs();doc=js(SAMPLE/'FINALIZED.json')
    if doc.get('status')!='CLEAN_HELD_FINALIZED_NOT_COMPILED_OR_APPROVED' or doc['rootPinsSha256']!=ROOT_PINS_SHA or doc['externalDescriptorSha256']!=EXTERNAL_INPUTS_SHA or doc['entrySha256']!=sha(safe_read(SAMPLE/'standard_entry.py')) or doc['sourceInspectionSha256']!=sha(safe_read(SOURCE_INSPECT)):raise RuntimeError('Finalized build inputs changed')
    _assert_rows(SAMPLE/'payload',doc['payloadFiles']);_company_held(js(SAMPLE/'payload/company.json'))
    return doc


def main():
    global BASE,VERSION,SAMPLE,DIST,SOURCE_INSPECT,HELD_STANDARD,INCLUDE_WEBVIEW2,CLEAN_ENTRY,ROOT_PINS,ROOT_PINS_SHA,EXTERNAL_INPUTS,EXTERNAL_INPUTS_SHA
    parser=argparse.ArgumentParser(description='Reviewed clean-held successor: stage, then root material generation, finalize, build')
    action=parser.add_mutually_exclusive_group(required=True)
    for name in ('stage','finalize','build'):action.add_argument('--'+name,action='store_true')
    parser.add_argument('--version',required=True,type=int)
    parser.add_argument('--base',required=True)
    parser.add_argument('--root-pins',required=True);parser.add_argument('--root-pins-sha256',required=True)
    parser.add_argument('--external-payloads',required=True);parser.add_argument('--external-payloads-sha256',required=True)
    args=parser.parse_args()
    if args.version<=82:raise RuntimeError('This successor requires a new explicit final root version; not old F82/QA pins')
    for value in (args.root_pins_sha256,args.external_payloads_sha256):
        if not re.fullmatch('[0-9a-f]{64}',value):raise RuntimeError('Explicit input SHA256 required')
    root_path=Path(args.root_pins);external_path=Path(args.external_payloads);BASE=Path(args.base)
    if not root_path.is_absolute() or not external_path.is_absolute() or not BASE.is_absolute() or '..' in BASE.parts:raise RuntimeError('Actual absolute input roots required')
    if sha(safe_read(root_path))!=args.root_pins_sha256 or sha(safe_read(external_path))!=args.external_payloads_sha256:raise RuntimeError('Explicit root/external descriptor SHA differs')
    ROOT_PINS=js(root_path);ROOT_PINS_SHA=args.root_pins_sha256;EXTERNAL_INPUTS=js(external_path);EXTERNAL_INPUTS_SHA=args.external_payloads_sha256;VERSION=args.version
    if BASE.name!='candidate-unified-v'+str(VERSION):raise RuntimeError('Actual fixed source root differs')
    HELD_STANDARD=True;INCLUDE_WEBVIEW2=False;CLEAN_ENTRY=True
    SAMPLE=HERE/('standard-held-clean-v'+str(VERSION));DIST=SAMPLE/'dist';SOURCE_INSPECT=SAMPLE/'INPUT-DISTRIBUTION-INSPECTION.json'
    _validate_root_inputs()
    if args.stage:stage()
    elif args.finalize:finalize()
    else:build()


if __name__=='__main__':main()
