# Xiaohongshu Account DNA

Updated: YYYY-MM-DD

## Positioning

## Primary audience

## Content pillars

1. 
2. 
3. 

## Voice

## Visual system

## Proven signals

## Current hypotheses

## Avoid

## Next three tests

