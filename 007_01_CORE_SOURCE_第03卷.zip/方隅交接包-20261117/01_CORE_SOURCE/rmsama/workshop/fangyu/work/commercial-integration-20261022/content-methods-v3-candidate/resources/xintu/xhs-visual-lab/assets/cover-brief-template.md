# Cover Production Brief

- Ratio: 3:4
- Primary promise:
- Short qualifier:
- Proof object:
- Creator/photo usage:
- Composition:
- Background:
- Palette:
- Typography:
- Elements to preserve:
- Elements to avoid:
- Matching first frame:
- Thumbnail test:

