# 新评论原分析链验证

正式本机 HTTP acquisition_start 请求已通过：请求没有 city/area，由原后台按已授权门店目录注入“上海／闵行区”；原 Service/Runner/真实短租约、原 Core/Store 入库、原 LocalAIWorkflow/LocalAIAttempts 校验与 CAS，最终原 GET customers 明确呈现 graded/high。新增评论 1 条、合成 provider 回执 1 次、原 validated attempt 1 个、原 ai_cache 1 条、原 ai_job completed/pending0。

这是原代码 source/frozen 路径代表。仅平台页面与企业 AI 返回值为自有合成边界；原 createService 设备云合同在独立内存 HTTP 运行。没有真实平台、模型、云部署或 Native 窗口，不能代替最终编译和真人验收。产品源码无需补丁。13 个关键业务源码与固定 C 字节一致；原 HTTP 启动、身份、回执及读取 5 函数与 C AST 一致，客户投影模块字节一致。成熟 release 的无关内容模块 hash 常量差异明确保留，不冒称整 Native backend 模块相同。

原先红证据保留：QA 派生把源码公司描述覆盖普通 held 包；可选 ai_worker 属性误假设；直接 Runtime 漏城市被原安全约束拒；直接 Runtime 有效城市已分析成功，但错误 POST customers 被拒，正式读取应 GET。最终改用正式 HTTP，由原后台注入目录字段，没有手填城市通过。

按总控最新收窄，本次最终只跑最难新增评论 HTTP 全链，不重跑重复页／跨账号／历史无 task_id／停止与租约失效全矩阵；这些不能冒称本次新验。全部自有服务已关闭。本目录封存后停写。
