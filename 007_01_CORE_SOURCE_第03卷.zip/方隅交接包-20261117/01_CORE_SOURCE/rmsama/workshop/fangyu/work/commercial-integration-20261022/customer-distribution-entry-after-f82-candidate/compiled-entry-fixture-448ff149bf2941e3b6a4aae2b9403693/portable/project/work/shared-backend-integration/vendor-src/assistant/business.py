"""Explicit adapter to the existing Core. No generic remote handle/exec endpoint."""
import hashlib,logging,math,re,secrets,threading,time
from copy import deepcopy
from datetime import datetime
from pathlib import Path
from core import CoreError
from core.engine import password_hash
from core.adapters import account_execution_lock, AdapterBusy, PageUnavailable, xhs_image_url
from core.page_errors import PageOperationFailure
from core.account_safety import account_review_view
from .ai_workflow import LocalAIWorkflow, effective_intent, post_identity
from .lead_groups import group_rows
from .employee_distribution import runtime_config_valid as employee_runtime_config_valid

ACCOUNT_FIELDS=('id','name','platform','status','platform_nickname','platform_avatar_url')
TASK_FIELDS=('id','name','platform','account_id','keywords','excludes','region','intent_mode','date_from','date_to','daily_limit','scope','note_url','status','last_batch','last_result','last_run','last_message','sequence_status','sequence_message','sequence_batches','accumulated','exhausted','search_pages','target_count','time_start','time_end','unknown_policy','excluded_authors','excluded_bloggers','high_intent_words','medium_intent_words','negative_intent_words','comment_keyword_mode','comment_depth','source_blogger','blogger_unknown_policy','created_at','updated_at')
LEAD_FIELDS=('id','platform','source_id','task_id','title','author','author_id','text','url','note_url','comment_id','parent_id','comment_level','content_title','content_author','grade','system_grade','manual_grade','grade_reason','published_at','region','reply_status','reply_state','source_type','created_at','updated_at','score')
REPLY_FIELDS=('id','lead_id','text','status','last_error','review_account_id')
CONTINUOUS_FIELDS=('id','status','inflight','batches','read','imported','duplicates','filtered','next_run_at','next_run_epoch','message','last_error','wait_reason','last_batch','daily_imported','daily_milestones','started_at','created_at','updated_at')
TASK_FIELDS += ('continuous_enabled','city','area','comment_date_range','comment_date_from','comment_date_to','continuous_status','source_kind')
LEAD_FIELDS += ('ai_intent','manual_intent','analysis_status','verification_status','ip_location','content_region','parent_text','handling_status','content_author_id','group_key','author_avatar_url','content_author_avatar_url','content_cover_url','content_published_at')
def pick(record,fields):return {key:record[key] for key in fields if key in record}
def private_task_binding(task):
    # Checkpoints/counters legitimately change; the original execution identity
    # and private snapshot must remain the same for every request of this run.
    return deepcopy(pick(task,('id','account_id','platform','scope','keywords',
                              'continuous_enabled','strategy_source')))

def account_view(record):
    value=pick(record,ACCOUNT_FIELDS)
    if 'platform_nickname' in value:value['platform_nickname']=str(value['platform_nickname'])[:100]
    if 'platform_avatar_url' in value:value['platform_avatar_url']=xhs_image_url(value['platform_avatar_url'])
    return value

def lead_view(record):
    value=pick(record,LEAD_FIELDS)
    for field in ('author_avatar_url','content_author_avatar_url','content_cover_url'):
        if field in value:value[field]=xhs_image_url(value[field])
    if 'score' in value and (type(value['score']) not in (int,float) or not math.isfinite(value['score'])):
        value.pop('score')
    return value

def canonical_reply(replies):
    """Confirmed or unresolved send evidence cannot be replaced by a draft."""
    states={'none','draft','approved','copied','sending','sent','unknown'}
    current=[{**reply,'status':reply.get('status') if reply.get('status') in states else 'unknown'}
             for reply in replies if reply.get('status')!='superseded']
    def evidence_key(reply):
        return ({'sent':3,'unknown':2,'sending':1}.get(reply['status'],0),
                str(reply.get('updated_at','')),str(reply.get('created_at','')),str(reply.get('id','')))
    return max(current,key=evidence_key) if current else None

def xiaohongshu_held(server):
    company_runtime=server.company.get('runtime') or {}
    core_runtime=(getattr(server.core,'deployment_config',{}) or {}).get('runtime') or {}
    employee_lease=(employee_runtime_config_valid(server.company)
                    and employee_runtime_config_valid(getattr(server.core,'deployment_config',{}))
                    and server.core._employee_release_allowed())
    from .xhs_page_read_policy import current_read_decision
    page_read=current_read_decision(server.core) is not None
    return (getattr(server.core,'remote_safety_hold',False)
            or (isinstance(company_runtime,dict) and company_runtime.get('xiaohongshu_automation')=='hold'
                and not employee_lease and not page_read)
            or (isinstance(core_runtime,dict) and core_runtime.get('xiaohongshu_automation')=='hold'
                and not employee_lease and not page_read))


_update_coordinator_init_lock = threading.Lock()


def server_update_coordinator(server):
    """One coordinator and one idle rule for manual and automatic updates."""
    with _update_coordinator_init_lock:
        if hasattr(server, 'update_coordinator'):
            return server.update_coordinator
        from .update_coordinator import UpdateCoordinator, installed_executable
        core = server.core

        def idle():
            if getattr(server, 'closing', False) or core.running or core.sequences:
                return False
            with server.job_lock:
                if any(job.get('status') == 'running' or job.get('process')
                       and job['process'].poll() is None for job in server.jobs.values()):
                    return False
            if any(x.get('status') == 'sending' for x in core.store.list('replies')):
                return False
            if any(x.get('status') == 'sending' for x in core.store.list('publications')):
                return False
            if any(x.get('status') in ('running', 'awaiting_collection')
                   for x in core.store.list('reply_queues')):
                return False
            if any(x.get('status') in ('queued', 'running', 'waiting')
                   for x in core.store.list('continuous_tasks')):
                return False
            return True

        install_root = getattr(server, 'install_root', None)
        server.update_coordinator = UpdateCoordinator(
            install_root, core.store.directory, server.company, idle_check=idle,
            executable=installed_executable(install_root, server.company['id']))
        return server.update_coordinator

LEGACY_APARTMENT_INTENT_KEYWORDS=(
    ('high',['预约','看房','入住','预算']),
    ('medium',['价格','租金','地址','地铁','房型']),
    ('low',['看看','了解']),
)
def upgraded_default_intent_rules(existing,current):
    """Only migrate the shipped default keywords; preserve customer edits and reasons."""
    if not isinstance(existing,list) or not isinstance(current,list):return None
    if tuple((item.get('level'),item.get('keywords')) for item in existing)!=LEGACY_APARTMENT_INTENT_KEYWORDS:return None
    replacements={item.get('level'):item.get('keywords') for item in current}
    if any(not isinstance(replacements.get(level),list) for level,_ in LEGACY_APARTMENT_INTENT_KEYWORDS):return None
    return [{**item,'keywords':list(replacements[item['level']])} for item in existing]

class BusinessExecutor:
    def __init__(self,server,environment_id,company_id,owner):
        if server.company['id']!=company_id:raise ValueError('本机企业与助手绑定不一致')
        self.server=server;self.core=server.core;self.owner=owner
        self.tenant='cloud-'+hashlib.sha256((environment_id+'\n'+company_id).encode()).hexdigest()[:24]
        self.user_id=hashlib.sha256((self.tenant+'\n'+owner).encode()).hexdigest()
        self._export_snapshots={}
        self._export_lock=threading.Lock()
        self._intent_refresh_lock=threading.Lock()
        self._response_monitor_lock=threading.Lock()
        self.account_claim=None
        self._explicit_task_ids=set()
        def ai_host_context():
            assistant = getattr(self.server, 'assistant_service', None)
            device = dict(getattr(assistant, 'device', None) or {})
            vault = getattr(assistant, 'vault', None)
            binding = vault.read() if vault and callable(getattr(vault, 'read', None)) else {}
            return {'environment_id': environment_id, 'company_id': company_id, 'owner': owner,
                    'binding': {key: (binding or {}).get(key)
                                for key in ('environment_id', 'company_id', 'state')},
                    'device': {key: device.get(key) for key in ('id', 'owner')}}
        self.ai=LocalAIWorkflow(self.core,self._ai_cloud,company=lambda:self.server.company,
                               host_context=ai_host_context)

    def _strategy_tasks(self):
        from .strategy_tasks import StrategyTasks
        return StrategyTasks(self.core, self.tenant, self.owner, self.server.company)

    def _require_product_feature(self, feature):
        from core.service_plans import require_feature, ProductAccessError
        try:
            return require_feature(getattr(getattr(self, 'server', None), 'company', {}), feature)
        except ProductAccessError as exc:
            error = CoreError(str(exc))
            error.mutation_committed = False
            raise error from None

    def _task_view(self, task, user):
        from .strategy_tasks import is_strategy_task
        return self._strategy_tasks().project_task(task, user) if is_strategy_task(task) else pick(task, TASK_FIELDS)

    def _ai_cloud(self,user,operation,data):
        from .employee_workspace import _cloud
        return _cloud(self.server,user,operation,data)

    def _claim_xhs_account(self,account):
        if self.server.company.get('id')!='fangyu-apartment-client' or account.get('platform')!='xiaohongshu':return
        self.core._require_customer_xhs_identity(account,self.tenant)
        if not callable(self.account_claim):
            raise CoreError('企业账号身份校验尚未连接，停止小红书平台操作')
        self.account_claim(account)

    def _export_page(self, user, token, offset, limit, rows=None, view=None):
        now=time.monotonic()
        with self._export_lock:
            for ident,entry in list(self._export_snapshots.items()):
                if now-entry['created']>7200 or now-entry['last_used']>1800:
                    del self._export_snapshots[ident]
            if token=='begin':
                if offset or rows is None:
                    raise ValueError('导出快照必须从第一页开始')
                if len(rows)>10000:
                    raise ValueError('导出超过一万条，请先筛选缩小范围')
                if len(self._export_snapshots)>=2:
                    oldest=min(self._export_snapshots,key=lambda ident:self._export_snapshots[ident]['last_used'])
                    del self._export_snapshots[oldest]
                token=secrets.token_urlsafe(24)
                self._export_snapshots[token]={'owner':user['username'],'items':rows,'created':now,'last_used':now,'view':view or {}}
            entry=self._export_snapshots.get(token)
            if not entry or entry['owner']!=user['username']:
                raise ValueError('导出快照已失效，请重新开始')
            entry['last_used']=now
            items=entry['items']
            return {**entry.get('view',{}),'items':items[offset:offset+limit],'total':len(items),'offset':offset,
                    'limit':limit,'snapshot':token}

    def _xiaohongshu_held(self):
        return xiaohongshu_held(self.server)

    def _account_review(self,account,user):
        if account.get('platform')!='xiaohongshu':
            return {'requires_review':False,'review_reason':'none'}
        self.core._account_access(user,account)
        path=Path(self.core.store.directory)/'accounts'/user['tenant_id']/account['id']/'platform-activity.jsonl'
        return account_review_view(path)

    def _guard_platform_qa_command(self,action,data,command=None):
        # Read-only QA is a local execution boundary as well as a cloud policy.
        # Keep the two process-owned config copies restrictive if they diverge.
        configs=(self.server.company,getattr(self.core,'deployment_config',{}) or {})
        qa=any(isinstance(config.get('runtime'),dict)
               and config['runtime'].get('platform_qa_device_id') for config in configs)
        if not qa:return
        if action=='reply_send' and command and isinstance(command.get('reply_trial'),dict):
            from core.review_queue import snapshot as reply_snapshot
            user=self.principal(command,read_only=True)
            reply=self.core._get('replies',data.get('reply_id'),self.tenant)
            lead=self.core._get('leads',reply['lead_id'],self.tenant)
            account=self.core._get('accounts',data.get('account_id'),self.tenant)
            self.core._public_reply_guard(lead.get('platform'),(user,reply,reply_snapshot(self.core,reply,lead,account),command.get('reply_trial')))
            return
        if action in ('reply_send','reply_queue_send'):
            raise CoreError('内部只读验收不允许公开发送；已审核草稿保持原状态')
        if action=='task_resume':
            raise CoreError('内部只读验收不允许恢复连续采集，请核对后另建单批任务')
        if action in ('continuous_start','continuous_resume'):
            if not self.core._qa_continuous_allowed():
                raise CoreError('指定设备持续只读验收未获云端短期确认')
        if action=='task_run' and (type(data.get('max_batches')) is not int or data['max_batches']!=1):
            raise CoreError('内部只读验收只允许明确指定 max_batches=1 的单批采集')

    def principal(self,command,*,read_only=False):
        profile=command.get('principal') or {}
        username=profile.get('username');role=profile.get('role')
        cross_review=command.get('action') in ('reply_pending','reply_approve','diagnostics','update_check','update_download','update_install','update_status') and role=='admin'
        if command.get('owner')!=self.owner or role not in ('admin','operator') or (username!=self.owner and not cross_review):
            raise ValueError('任务员工身份与设备绑定不一致')
        with self.core.lock:
            if read_only:
                # Login commit guards run inside a SQLite write transaction.
                # Read the existing employee; never create/update it from a
                # second connection or promote a cached administrator locally.
                user_id=hashlib.sha256((self.tenant+'\n'+username).encode()).hexdigest()
                user=self.core.store.get('users',user_id)
                if (not user or user.get('tenant_id')!=self.tenant
                        or user.get('username')!=username or not user.get('cloud_bound')
                        or user.get('disabled')):
                    raise ValueError('本机员工身份已失效，登录已停止')
                return self.core._public({**user,'role':role})
            config=self.server.company
            tenant_record=self.core.store.get('tenants',self.tenant)
            if not tenant_record:
                tenant=self.core._record({'id':self.tenant,'name':config['name'],'company_id':config['id'],'industry':config.get('industry','general'),'business_rules':config},self.tenant)
                self.core.store.put('tenants',tenant)
            elif config.get('id')=='fangyu-apartment-client':
                business=tenant_record.get('business_rules') or {}
                upgraded=upgraded_default_intent_rules(business.get('intentRules'),config.get('intentRules'))
                if upgraded:
                    tenant_record['business_rules']={**business,'intentRules':upgraded}
                    self.core.store.put('tenants',tenant_record)
            user_id=hashlib.sha256((self.tenant+'\n'+username).encode()).hexdigest()
            previous=self.core.store.get('users',user_id) or {}
            user=self.core._record({**previous,'id':user_id,'username':username,'role':role,'disabled':False,'cloud_bound':True,'password_hash':previous.get('password_hash') or password_hash(secrets.token_urlsafe(48))},self.tenant)
            if type(profile.get('can_reply')) is bool:user['can_reply']=profile['can_reply']
            self.core.store.put('users',user)
            return self.core._public(user)

    def sync_permissions(self,permissions):
        if type(permissions.get('can_reply')) is not bool:return
        with self.core.lock:
            user=self.core.store.get('users',self.user_id)
            if user:
                user['can_reply']=permissions['can_reply']
                self.core.store.put('users',user)

    def _verify_first_xhs_search(self,user,task,*,lease_owner=None,execution_guard=None,retain_result=False):
        if task.get('platform')=='douyin':
            self._verify_first_douyin_search(user,task)
            return
        if task.get('platform')!='xiaohongshu':return
        if self._xiaohongshu_held():
            raise CoreError('小红书自动采集已暂停；当前不进行平台搜索验证')
        if task.get('source_kind') in ('profiles','own_interactions'):
            # These sources verify their own bounded user-post/notification read.
            # Never introduce an unrelated keyword search before that request.
            # Retain the original hold, task/account access and frozen identity.
            if execution_guard is not None:execution_guard()
            self.core._task_access(user,task,user['tenant_id'])
            account=self.core._get('accounts',task.get('account_id'),user['tenant_id'])
            self.core._account_access(user,account)
            if account.get('platform')!='xiaohongshu' or account.get('status')!='ready':
                raise CoreError('请先在本地助手完成当前小红书账号登录')
            self._claim_xhs_account(account)
            from core.acquisition_sources import load_plan
            from core.acquisition_extension_runtime import bound_scope
            plan=load_plan(self.core.store,task)
            if not plan or plan.get('config',{}).get('kind')!=task['source_kind']:
                raise CoreError('原来源方案尚未就绪，请返回工作台核对')
            bound_scope(task,account,plan)
            if execution_guard is not None:execution_guard()
            return
        runtime=self.core.adapters.xhs_page_runtime
        from .xhs_page_read_policy import current_read_decision
        page_decision=current_read_decision(self.core) if runtime is not None else None
        if runtime is not None:
            if page_decision is None:
                raise CoreError('页面组件材料与内部只读用途尚未完成审查')
            if page_decision.is_verified(user,task):return
        else:
            manifest=next((item for item in self.core.adapters.manifests() if item['id']=='xiaohongshu'),None)
            if manifest and manifest.get('search_verified'):return
        account=self.core._get('accounts',task.get('account_id'),user['tenant_id'])
        self.core._account_access(user,account)
        if account.get('platform')!='xiaohongshu' or account.get('status')!='ready':
            raise CoreError('请先在本地助手完成当前小红书账号登录')
        original_binding=private_task_binding(task)
        self._claim_xhs_account(account)
        from .strategy_tasks import is_strategy_task
        strategy_task=is_strategy_task(task)
        borrowed_lease=lease_owner is not None
        owner=lease_owner if borrowed_lease else 'verify:'+task['id']
        if borrowed_lease and owner not in ('continuous:'+task['id'],'batch:'+task['id']):
            raise CoreError('首次搜索验证不能借用其他操作的账号归属')
        def verification_guard():
            if execution_guard is not None:
                execution_guard()
            if strategy_task:
                latest=self._strategy_tasks().guard_task_action(task['id'],'task_run',
                    {'task_id':task['id'],'max_batches':1},user)
                if private_task_binding(latest)!=original_binding:
                    raise CoreError('原任务或执行账号已变化，请核实；未开始搜索验证')
            if borrowed_lease:
                lease=self.core.account_mode_status(account['id'],user['tenant_id'])
                if (lease.get('status')!='active' or lease.get('mode')!='collection'
                        or lease.get('owner')!=owner
                        or lease.get('runtime_id')!=self.core.continuous.leases.runtime_id):
                    raise CoreError('首次搜索验证的原采集归属已变化')
        verification_guard()
        keyword=next((str(item).strip() for item in task.get('keywords',[]) if str(item).strip()),'租房')
        directory=Path(self.core.store.directory)/'accounts'/user['tenant_id']/account['id']
        try:
            # The customer workbench has no inherited admin account page. Probe the
            # same read-only search the employee is about to run, once per adapter.
            self.core._set_task_progress(task['id'],'searching')
            runtime=self.core.adapters.xhs_page_runtime
            if not borrowed_lease:
                try:self.core.acquire_account_mode(account['id'],user['tenant_id'],'collection',owner)
                except CoreError as error:
                    error._account_mode_blocked=True
                    raise
            read_scope=None
            keep_result=False
            try:
                verification_guard()
                if runtime is None:
                    self.core.adapters.verify('xiaohongshu',keyword,str(directory))
                else:
                    read_scope=runtime.first_search_scope(user,task,verification_guard)
                    self.core.adapters.verify('xiaohongshu',keyword,str(directory),
                        read_scope=read_scope,page_read_decision=page_decision)
                    read_scope.require_result()
                    keep_result=retain_result
                    return read_scope if retain_result else None
            finally:
                if not keep_result and read_scope is not None:
                    read_scope.release_result()
                if not borrowed_lease and (runtime is None or not runtime.has_pending_batch(task['id'])):
                    self.core.release_account_mode(account['id'],user['tenant_id'],owner)
        except PageUnavailable as exc:
            self.core._set_task_progress(task['id'],'failed','failed')
            failure=PageOperationFailure(exc.code)
            logging.warning('First Xiaohongshu page search unavailable (%s)',failure.code)
            raise failure from None
        except Exception as exc:
            logging.exception('First Xiaohongshu read-only search verification failed')
            raise CoreError('首次只读搜索验证未通过；请在本地助手确认账号登录状态后重试') from exc

    def _verify_first_douyin_search(self,user,task):
        """Reuse the original first-search probe on an explicit own task only."""
        if (not employee_runtime_config_valid(self.server.company)
                or not self.core._employee_release_allowed()
                or self.server.core.remote_safety_hold):
            raise CoreError('本机设备的平台读取许可尚未确认')
        session=getattr(self,'_xhs_app_session',None)
        if session is None:raise CoreError('当前设备会话尚未确认')
        session.check()
        account=self.core._get('accounts',task.get('account_id'),user['tenant_id'])
        self.core._account_access(user,account)
        if account.get('platform')!='douyin' or account.get('cloud_owner')!=self.owner:
            raise CoreError('当前抖音账号归属尚未确认')
        state=self.server.assistant_service.douyin_connection('status',{'account_id':account['id']})
        if (state.get('state')!='ready' or state.get('platform_login_confirmed') is not True
                or state.get('binding_verified') is not True):
            raise CoreError('请先完成本人抖音登录并检查连接')
        session.check()
        account=self.core._get('accounts',account['id'],user['tenant_id'])
        manifest=self.core.adapters.manifest('douyin')
        if manifest.get('search_verified'):return
        keyword=next((str(item).strip() for item in task.get('keywords',[]) if str(item).strip()),'租房')
        directory=Path(self.core.store.directory)/'accounts'/user['tenant_id']/account['id']
        self.core._set_task_progress(task['id'],'searching')
        self.server._platform_execution_guard('douyin')
        self.core.adapters.verify('douyin',keyword,str(directory),account.get('conn_id'))
        session.check()

    def _lead_access(self,user,lead,task_cache=None):
        """A local comment belongs to its collecting employee unless shared explicitly."""
        task_id=lead.get('task_id')
        if task_id:
            task=task_cache.get(task_id) if task_cache is not None else None
            if task is None:
                task=self.core._get('tasks',task_id,self.tenant)
                if task_cache is not None:task_cache[task_id]=task
            self.core._task_access(user,task,self.tenant)
        elif not lead.get('cloud_owner'):
            raise CoreError('此评论没有可核实的员工归属，不能直接操作')
        if lead.get('cloud_owner') and lead['cloud_owner']!=user['username']:
            raise CoreError('只能查看和操作自己的本机评论')

    def _analysis_visible_leads(self,user,task,rows=None):
        """One local queue view; known foreign rows never block the owner's batch.

        Task/actor access failures still abort. Only the existing explicit
        tenant/owner exclusions are filtered; storage and other errors propagate.
        Legacy unowned comments may still inherit their original owned task.
        """
        current=self.core.store.get('users',user.get('id'))
        if (not current or current.get('disabled') or
                any(current.get(key)!=user.get(key) for key in
                    ('id','tenant_id','username','role','cloud_bound'))):
            raise CoreError('当前员工身份已变化，意向分析队列暂不可用')
        task=self.core._get('tasks',task['id'],self.tenant)
        self.core._task_access(current,task,self.tenant)
        task_cache={task['id']:task}
        for lead in self.core.store.list('leads',self.tenant) if rows is None else rows:
            if lead.get('task_id')!=task['id']:continue
            if (lead.get('tenant_id')!=self.tenant or
                    lead.get('cloud_owner') and lead['cloud_owner']!=current['username']):
                continue
            self._lead_access(current,lead,task_cache=task_cache)
            yield lead

    def manual_reply_action(self, action, data, user, *, scope_guard):
        """Trusted local product bridge; never exposed as a runner send action."""
        from core.review_queue import require_reply_permission
        def fail(reason, committed=False):
            error=CoreError(reason);error.mutation_committed=committed;raise error
        fields={'reply_id'} if action=='reply_copy' else {'reply_id','confirmed'}
        if (action not in ('reply_copy','reply_manual_confirm') or not isinstance(data,dict)
                or set(data)!=fields or not isinstance(data.get('reply_id'),str)
                or re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_-]{0,159}',data['reply_id']) is None
                or action=='reply_manual_confirm' and data.get('confirmed') is not True
                or not callable(scope_guard)):
            fail('人工联系参数无效或尚未明确确认')
        with self.core.lock:
            def fresh():
                saved=self.core.store.get('users',user.get('id'))
                if (not saved or saved.get('disabled') or saved.get('cloud_bound') is not True
                        or saved.get('role') not in ('operator','admin') or saved.get('development_local_only') is True
                        or (saved.get('username'),saved.get('tenant_id'))!=(self.owner,self.tenant)
                        or any(saved.get(key)!=user.get(key) for key in ('id','username','tenant_id','role','cloud_bound'))
                        or scope_guard() is not True):
                    fail('当前员工、公司或电脑范围已变化')
                return saved
            actor=fresh();reply=self.core._get('replies',data['reply_id'],self.tenant)
            lead=self.core._get('leads',reply.get('lead_id'),self.tenant)
            try:
                self._lead_access(actor,lead);require_reply_permission(self.core,actor,lead,reply)
                if reply.get('author_id')!=actor['id'] or lead.get('cloud_owner')!=self.owner:
                    fail('只能处理本人保存的原回复与评论')
                if reply.get('channel','comment')!='comment' or lead.get('platform')!='xiaohongshu':
                    fail('人工定位流程暂只支持小红书原评论')
                if reply.get('status')!=('approved' if action=='reply_copy' else 'copied'):
                    fail('原回复状态已变化，请先读取；未知结果不可重试')
                if any(queue.get('authorized_by')==actor['id']
                        and queue.get('status') in ('ready','awaiting_collection','running')
                        and reply['id'] in (queue.get('reply_ids') or [])
                        for queue in self.core.store.list('reply_queues',self.tenant)):
                    fail('此回复仍在本人原待发送清单中，请先取消原队列，再选择人工联系')
                account=self.core._get('accounts',reply.get('review_account_id'),self.tenant)
                self.core._account_access(actor,account)
                from core.review_queue import snapshot
                if reply.get('approval_snapshot')!=snapshot(self.core,reply,lead,account,user=actor):
                    fail('原审核内容、评论或执行账号已变化')
                fresh()
            except (CoreError,ValueError) as exc:
                if not hasattr(exc,'mutation_committed'):exc.mutation_committed=False
                raise
            try:
                result=self.core._reply('copy_reply' if action=='reply_copy' else 'mark_reply_sent',
                    {'id':reply['id'],**({'confirmed':True} if action=='reply_manual_confirm' else {})},actor,self.tenant)
            except Exception as exc:
                # Core may have committed contact evidence before audit failed.
                # Preserve uncertainty; a client must read the original reply.
                error=CoreError('人工操作结果待核对，请读取原回复，暂勿重复确认');error.mutation_committed=None
                raise error from exc
            try:
                actor=fresh();require_reply_permission(self.core,actor,lead,reply)
            except Exception as exc:
                error=CoreError('结果返回时范围已变化，请在原账号与电脑读取原回复');error.mutation_committed=None
                raise error from exc
            current=result['reply'] if action=='reply_copy' else result
            return {'reply':pick(current,REPLY_FIELDS),'text':current.get('text',''),
                'contact_outcome':'copied' if action=='reply_copy' else 'external_reported',
                'manual_only':True,'platform_verified':False,'response_check_started':False}

    def __call__(self,command):
        from .xhs_app_context import executor_call
        with executor_call(self,command):
            return self._execute(command)

    def _execute(self,command):
        action=command['action'];data=command.get('data') or {}
        if not isinstance(data,dict):raise ValueError('任务参数格式错误')
        if action in ('customer_response_check_start','customer_response_check_status',
                      'customer_response_check_cancel'):
            user=self.principal(command,read_only=action!='customer_response_check_start')
            if (user.get('role')!='operator' or user.get('cloud_bound') is not True or
                    user.get('development_local_only') is True):
                raise CoreError('回信检查仅限已绑定的正式员工')
            from .customer_response_monitor import CustomerResponseMonitor
            if not hasattr(self,'response_monitor'):
                with self._response_monitor_lock:
                    if not hasattr(self,'response_monitor'):
                        self.response_monitor=CustomerResponseMonitor(self)
            method={'customer_response_check_start':self.response_monitor.start,
                    'customer_response_check_status':self.response_monitor.status,
                    'customer_response_check_cancel':self.response_monitor.cancel}[action]
            return method(data,user)
        if action=='intent_correct' and 'expected_version' in data:
            # A local manual correction uses the already-authenticated employee;
            # never revive a disabled user or acquire any platform session here.
            user=self.principal(command,read_only=True)
            lead=self.core._get('leads',data.get('lead_id'),self.tenant)
            self._lead_access(user,lead)
            return self.ai.correct(user,lead,data)
        if action=='lead_detail':
            if (set(data)!={'lead_id'} or not isinstance(data['lead_id'],str)
                    or not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_-]{0,159}',data['lead_id'])):
                raise ValueError('原评论详情查询参数无效')
            user=self.principal(command,read_only=True)
            lead=self.core._get('leads',data['lead_id'],self.tenant)
            self._lead_access(user,lead)
            return lead_view(lead)
        if action in ('customer_list','customer_detail','customer_seen'):
            from .customer_list import CustomerHistory
            user=self.principal(command,read_only=True)
            history=CustomerHistory(self.core,self.tenant,self.owner,lead_access=self._lead_access)
            if action=='customer_list':return history.customer_list(data,user)
            if action=='customer_seen':return history.customer_seen(data,user)
            if set(data)!={'author_key'}:raise ValueError('客户详情查询参数无效')
            return history.customer_detail(data['author_key'],user)
        if action=='keyword_state':
            user=self.principal(command,read_only=True)
            if user.get('role')!='operator':raise ValueError('关键词库仅限绑定员工')
            return self.ai.keyword_state(user,data)
        if action=='contact_receipt_status':
            if set(data)!={'reply_id'} or not isinstance(data['reply_id'],str) or not data['reply_id']:
                raise ValueError('联系记录查询参数无效')
            user=self.principal(command,read_only=True)
            reply=self.core._get('replies',data['reply_id'],self.tenant)
            lead=self.core._get('leads',reply['lead_id'],self.tenant)
            self._lead_access(user,lead)
            receipt=self.core.contact_journal.receipt(self.tenant,self.owner,reply['id'],lead['id'])
            return {**receipt,'reply_status':reply.get('status','unknown')}
        self._guard_platform_qa_command(action,data,command)
        user=self.principal(command)
        if action in ('task_save','task_run','task_resume','continuous_start','continuous_resume'):
            self._require_product_feature('acquisition')
        if action in ('keyword_recommend','keyword_library','keyword_suggest'):
            self._require_product_feature('strategy')
        if action=='intent_analyze_pending':
            self._require_product_feature('intent_analysis')
        if action=='leads_list' and data.get('snapshot'):
            self._require_product_feature('export')
        from .strategy_tasks import is_strategy_task
        task_ident=data.get('id') if action=='task_save' else data.get('task_id')
        strategy_task=self.core.store.get('tasks',task_ident) if isinstance(task_ident,str) else None
        if strategy_task and strategy_task.get('scope')=='livestream_chat' and action in ('task_save','task_run','task_resume','continuous_start','continuous_resume'):
            raise CoreError('直播分析任务不能改作关键词或视频评论采集；请查询原直播采集编号')
        if is_strategy_task(strategy_task) and action in ('task_save','task_run','task_stop','task_resume',
                'continuous_start','continuous_resume','continuous_pause'):
            self._strategy_tasks().guard_task_action(strategy_task,action,data,user)
        local_account_record=(action=='account_create' and data.get('platform') in
                              ('douyin','zhihu','wechat_channels','bilibili','kuaishou','weibo'))
        if self._xiaohongshu_held() and not local_account_record and action in (
                'account_create','account_connect','account_status','task_save','task_run','task_resume','continuous_start','continuous_resume','reply_send','reply_queue_send'):
            raise CoreError('小红书自动采集与发送已暂停：第三方 CLI 保护与真实流程尚未验收')
        call=lambda action,data=None:self.core.handle(action,data or {},user)
        if action=='workspace_state':
            accounts=call('list',{'entity':'accounts'});tasks=call('list',{'entity':'tasks'})
            # Monitoring is a local read. Count only records visible to this
            # employee, once per snapshot; no platform or model request.
            task_ids={item['id'] for item in tasks[:100]}
            totals={key:{'saved_total':0,'analyzed_total':0,'pending':0,'excluded_missing_text':0} for key in task_ids}
            for lead in self.core.store.list('leads',self.tenant):
                if lead.get('task_id') not in totals or lead.get('demo'):continue
                try:self._lead_access(user,lead)
                except CoreError:continue
                counts=totals[lead['task_id']];counts['saved_total']+=1
                result=lead.get('manual_intent') or lead.get('ai_intent')
                if isinstance(result,dict) and result.get('status') in ('graded','uncertain','unrelated'):
                    counts['analyzed_total']+=1
                elif isinstance(lead.get('text'),str) and lead['text'].strip():counts['pending']+=1
                else:counts['excluded_missing_text']+=1
            snapshots=[]
            for task in tasks[:100]:
                snapshot=self._task_view(task,user)
                progress=self.core.task_progress(task['id'])
                if is_strategy_task(task):
                    from .strategy_tasks import project_strategy_progress
                    progress=project_strategy_progress(progress)
                if progress:snapshot['progress']=progress
                analysis=self.core.store.get('ai_jobs',task['id'])
                if analysis and analysis.get('tenant_id')==self.tenant:
                    if is_strategy_task(task):
                        from .strategy_tasks import project_strategy_analysis
                        snapshot['analysis']=project_strategy_analysis(analysis)
                    else:
                        snapshot['analysis']=pick(analysis,('status','pending','excluded_missing_text','last_analyzed','code','message','retry_count','retry_after'))
                snapshot['analysis']={**snapshot.get('analysis',{}),**totals[task['id']]}
                if task.get('continuous_enabled'):
                    snapshot['continuous']=pick(call('continuous_status',{'id':task['id']}).get('continuous',{}),CONTINUOUS_FIELDS)
                snapshots.append(snapshot)
            return {'accounts':[{**account_view(x),**self._account_review(x,user)} for x in accounts[:100]],
                    'tasks':snapshots,'account_count':len(accounts),'task_count':len(tasks),
                    'truncated':len(accounts)>100 or len(tasks)>100,
                    'owner_company_order_link':__import__('assistant.company_owner_order_link',fromlist=['CAP']).CAP.copy()}
        if action in ('continuous_start','continuous_pause','continuous_resume','continuous_status'):
            if set(data)!={'task_id'}:raise ValueError('采集任务参数无效')
            if action in ('continuous_start','continuous_resume') and self._intent_refresh_lock.locked():
                raise CoreError('意向规则维护正在进行，请等待本批完成后再采集')
            task=self.core._get('tasks',data['task_id'],self.tenant)
            self.core._task_access(user,task,self.tenant)
            if action in ('continuous_start','continuous_resume'):
                account=self.core._get('accounts',task.get('account_id'),self.tenant)
                self.core._account_access(user,account)
                review=self._account_review(account,user)
                if review['requires_review']:
                    raise CoreError('采集请求暂未被小红书接受，请查看手机是否有提醒，并到小红书账号页核对'
                                    if review['review_reason']=='verification_required'
                                    else '账号安全记录暂无法核对，已停止采集'
                                    if review['review_reason']=='unknown'
                                    else '账号有待复核的异常，请先在本机账号安全记录复核')
                self._claim_xhs_account(account)
            if action in ('continuous_start','continuous_resume') and not self.core.continuous.is_active(task['id']):
                # Reserve the account before the first read-only search probe so
                # it cannot overlap a reply or another collection. The collector
                # reacquires this same lease when it accepts the task.
                lease_owner='continuous:'+task['id']
                self.core.acquire_account_mode(account['id'],self.tenant,'collection',lease_owner)
                read_scope=None
                try:
                    read_scope=self._verify_first_xhs_search(user,task,lease_owner=lease_owner,retain_result=True)
                    with self.core.lock:
                        try:
                            if read_scope is not None:
                                read_scope.require_result()
                                # Consume this exact closed logical result in
                                # the same Core lock as the accepted start. No
                                # cancel/new worker can enter this handoff gap.
                                read_scope.release_result()
                            result=call(action,{'id':task['id']})
                        finally:
                            # The original collector may claim as soon as Core
                            # unlocks. Consume only this closed logical scope.
                            if read_scope is not None:
                                read_scope.release_result()
                except Exception:
                    if read_scope is not None:
                        read_scope.release_result()
                    runtime=self.core.adapters.xhs_page_runtime
                    if runtime is None or not runtime.has_pending_batch(task['id']):
                        self.core.release_account_mode(account['id'],self.tenant,lease_owner)
                    raise
                finally:
                    if read_scope is not None:
                        read_scope.release_result()
            else:
                result=call(action,{'id':task['id']})
            if action in ('continuous_start','continuous_resume'):
                # An accepted employee start includes automatic analysis of saved
                # comments. Retry a previous format failure once through the same
                # worker; never clear authentication, balance or unknown billing.
                previous=self.core.store.get('ai_jobs',task['id'])
                if (previous and previous.get('tenant_id')==self.tenant and
                        previous.get('status')=='paused' and previous.get('code')=='AI_INVALID_OUTPUT'):
                    self.core.store.put('ai_jobs',{**previous,'status':'ready','retry_after':0,
                        'retry_count':0,'message':'采集已开始，已保存评论自动排队分析'})
            if isinstance(result.get('task'),dict):result['task']=self._task_view(result['task'],user)
            if isinstance(result.get('continuous'),dict):result['continuous']=pick(result['continuous'],CONTINUOUS_FIELDS)
            return result
        if action=='keyword_recommend':return self.ai.keywords(user,data)
        if action=='keyword_library':return self.ai.library(user,data)
        if action=='intent_correct':
            lead=self.core._get('leads',data.get('lead_id'),self.tenant)
            self._lead_access(user,lead)
            return lead_view(self.ai.correct(user,lead,data))
        if action=='lead_handle':
            if data.get('status') not in ('pending','ignored'):raise ValueError('处理状态无效')
            with self.core.lock:
                lead=self.core._get('leads',data.get('lead_id'),self.tenant)
                self._lead_access(user,lead)
                lead['handling_status']=data['status']
                self.core.store.put('leads',lead)
            return lead_view(lead)
        if action=='intent_analyze_pending':
            result=self.analyze_pending(user,data,explicit_retry=True)
            previous=self.core.store.get('ai_jobs',data.get('task_id'))
            if previous and previous.get('tenant_id')==self.tenant:
                pending=result.get('pending',0)
                excluded=result.get('excluded_missing_text',0)
                previous.update(status='pending' if excluded and not pending else 'ready',
                                pending=pending,excluded_missing_text=excluded,
                                last_analyzed=result.get('analyzed',0),retry_count=0,retry_after=0,
                                message='无正文评论待核实' if excluded and not pending else '',
                                updated_at=datetime.now().isoformat())
                previous.update({k:result[k] for k in ('provider','model','configured_model','reasoning_effort') if k in result})
                for field in ('code','pause_reason','paused_at','last_error','context_preflight_checked'):
                    previous.pop(field,None)
                self.core.store.put('ai_jobs',previous)
            worker=getattr(getattr(self.server,'assistant_service',None),'ai_worker',None)
            if worker:worker.retry_after=0
            return result
        if action=='account_create':
            if set(data)-{'name','platform'}:raise ValueError('账号参数越界')
            record={**data,'cloud_owner':self.owner}
            if local_account_record:record['status']='login_required'
            return account_view(call('save',{'entity':'accounts','record':record}))
        if action=='account_delete':
            account=self.core._get('accounts',data.get('account_id'),self.tenant)
            self.core._account_access(user,account)
            if account.get('platform')=='xiaohongshu':
                directory=Path(self.core.store.directory)/'accounts'/self.tenant/account['id']
                try:
                    with account_execution_lock(directory):
                        return call('account_delete',{'id':account['id'],**({'expected_account_digest':data['expected_account_digest']} if 'expected_account_digest' in data else {})})
                except AdapterBusy:
                    raise CoreError('该账号仍在另一助手进程执行平台操作，请等待结束后再删除') from None
            return call('account_delete',{'id':account['id'],**({'expected_account_digest':data['expected_account_digest']} if 'expected_account_digest' in data else {})})
        if action=='account_connect':
            account=self.core._get('accounts',data.get('account_id'),self.tenant)
            self.core._account_access(user,account)
            if account['platform']=='xiaohongshu':
                return {'status':'local_login_required','message':'请在助手电脑点击“打开本机平台登录”，用同一员工账号登录后为这个小红书账号扫码。二维码只留在本机。'}
            if account['platform'] not in ('douyin','kuaishou'):
                raise CoreError('这个平台需要在助手上扫码登录，网页连接流程尚未接入')
            state=self.server.account_connections.connect(user,account['id'],'new')
            return pick(state,('status','step','message','next_action'))
        if action=='account_status':
            account=self.core._get('accounts',data.get('account_id'),self.tenant)
            self.core._account_access(user,account)
            if account['platform'] in ('douyin','kuaishou'):
                state=self.server.account_connections.status(user,account['id'],force=True)
                return {**account_view(account),**pick(state,('status','step','message','next_action'))}
            if account.get('platform_uid'):self._claim_xhs_account(account)
            call('account_check',{'id':account['id']})
            checked=self.core._get('accounts',account['id'],self.tenant)
            if checked.get('status')=='ready':self._claim_xhs_account(checked)
            return account_view(self.core._get('accounts',account['id'],self.tenant))
        if action=='keyword_suggest':
            if set(data)!={'seed'}:raise ValueError('关键词联想参数无效')
            return self.server.integrations.handle('keyword_suggest',{'seed':data['seed']},user)
        if action=='task_save':
            if set(data)-set(TASK_FIELDS) or set(data)&{'status','last_batch','last_result','last_run','last_message','sequence_status','sequence_message','sequence_batches','accumulated','exhausted','continuous_status','created_at','updated_at'}:raise ValueError('任务参数越界')
            return self._task_view(call('save',{'entity':'tasks','record':data}),user)
        if action=='task_run':
            task=self.core._get('tasks',data.get('task_id'),user['tenant_id'])
            self.core._task_access(user,task,user['tenant_id'])
            self.core._set_task_progress(task['id'],'preparing')
            lease_owner='batch:'+task['id']
            leased=False
            try:
                original_binding=private_task_binding(task)
                account=self.core._get('accounts',task.get('account_id'),user['tenant_id'])
                self.core._account_access(user,account)
                # The same original owner is reacquired by Core; never release
                # between the first platform probe and that task's collection.
                try:self.core.acquire_account_mode(account['id'],user['tenant_id'],'collection',lease_owner)
                except CoreError as error:
                    error._account_mode_blocked=True
                    raise
                leased=True
                self._claim_xhs_account(account)
                private_guard=None
                if is_strategy_task(task):
                    def private_guard():
                        # The strategy service captures trusted company config;
                        # reconstruct it so a later manager withdrawal is read.
                        latest=self._strategy_tasks().guard_task_action(task['id'],'task_run',data,user)
                        if private_task_binding(latest)!=original_binding:
                            raise CoreError('原任务或执行账号已变化，请核实；不会换账号继续')
                        return latest
                    task=private_guard()
                if task.get('status')!='paused':self._verify_first_xhs_search(user,task,lease_owner=lease_owner,execution_guard=private_guard)
                run_data={'id':data.get('task_id'),'max_batches':min(50,max(1,int(data.get('max_batches',50))))}
                if private_guard:
                    task=private_guard()
                    result=self.core.handle('run_task_sequence',run_data,user,execution_guard=private_guard)
                else:result=call('run_task_sequence',run_data)
            except Exception:
                self.core._set_task_progress(task['id'],'failed','failed')
                raise
            finally:
                runtime=self.core.adapters.xhs_page_runtime
                if leased and (runtime is None or not runtime.has_pending_batch(task['id'])):
                    self.core.release_account_mode(account['id'],user['tenant_id'],lease_owner)
            if result.get('summary') and self._xiaohongshu_held():
                result['summary']['can_continue']=False
                task=self.core._get('tasks',task['id'],user['tenant_id'])
                task['last_result']={'status':result['status'],'summary':result['summary'],'completed_at':task.get('last_run')}
                self.core.store.put('tasks',task)
            if is_strategy_task(task):
                completion=self._strategy_tasks().finish_exhausted(task['id'],user)
                # Only committed counters cross the employee boundary. Adapter
                # errors and raw checkpoints may contain private search words.
                def continuation_guard():
                    self._require_product_feature('acquisition')
                    return private_guard()
                projected=self._strategy_tasks().project_completion(task['id'],user,result.get('summary'),
                    original_binding=original_binding,completion=completion,
                    continuation_guard=continuation_guard,scope_held=self._xiaohongshu_held)
                return {**pick(result,('status','batches','imported','duplicates')),
                        'message':projected['task']['last_message'],**projected}
            return pick(result,('status','message','batches','imported','duplicates','summary'))
        if action=='task_stop':return call('cancel_task',{'id':data.get('task_id')})
        if action=='task_resume':
            task=self.core._get('tasks',data.get('task_id'),user['tenant_id'])
            account=self.core._get('accounts',task.get('account_id'),user['tenant_id'])
            self.core._account_access(user,account)
            self._claim_xhs_account(account)
            return self._task_view(call('resume_task',{'id':task['id']}),user)
        if action=='lead_score':
            if data.get('grade') not in ('A','B','C'):raise ValueError('意向等级无效')
            self._lead_access(user,self.core._get('leads',data.get('lead_id'),self.tenant))
            return pick(call('save',{'entity':'leads','record':{'id':data.get('lead_id'),'manual_grade':data['grade']}}),LEAD_FIELDS)
        if action=='leads_list':
            sort=data.get('sort','newest');reply_filter=data.get('reply_state','')
            if sort not in ('intent','newest') or reply_filter not in ('','unreplied','sent'):
                raise ValueError('评论排序或回复筛选参数无效')
            view={'view_contract':'lead-view-v1','sort':sort,'reply_state':reply_filter}
            offset=max(0,int(data.get('offset',0)));limit=max(1,min(25,int(data.get('limit',25))))
            snapshot=data.get('snapshot')
            if snapshot is not None and (not isinstance(snapshot,str) or not snapshot or len(snapshot)>80):
                raise ValueError('导出快照参数无效')
            if snapshot and snapshot!='begin':
                return self._export_page(user,snapshot,offset,limit)
            query=str(data.get('query','')).casefold();items=call('list',{'entity':'leads'})
            visible=[]
            for item in items:
                try:self._lead_access(user,item)
                except CoreError:continue
                visible.append(item)
            items=visible
            items=[x for x in items if not x.get('demo') and (not data.get('platform') or x.get('platform')==data['platform']) and (not data.get('grade') or x.get('grade')==data['grade']) and (not data.get('task_id') or x.get('task_id')==data['task_id']) and (not data.get('region') or data['region'] in str(x.get('region',''))) and (not data.get('date_from') or str(x.get('published_at',''))[:10]>=data['date_from']) and (not data.get('date_to') or str(x.get('published_at',''))[:10]<=data['date_to']) and (not query or query in ' '.join(str(x.get(k,'')) for k in ('author','author_id','text','content_title','content_author','source_id')).casefold())]
            visible_ids={item['id'] for item in items}
            related={}
            for reply in call('list',{'entity':'replies'}):
                if reply.get('lead_id') in visible_ids:related.setdefault(reply['lead_id'],[]).append(reply)
            latest={ident:canonical_reply(replies) for ident,replies in related.items()}
            items=[{**item,'reply_state':(latest.get(item['id']) or {}).get('status','none')} for item in items]
            if reply_filter=='unreplied':items=[item for item in items if item['reply_state'] in ('none','draft','approved','copied')]
            elif reply_filter=='sent':items=[item for item in items if item['reply_state']=='sent']
            if data.get('intent_level'):
                if data['intent_level'] not in ('priority','super_high','high','medium','low','very_low','pending','uncertain','unrelated'):raise ValueError('意向筛选无效')
                requested=data['intent_level']
                items=[x for x in items if (effective_intent(x).get('level') if effective_intent(x).get('status')=='graded' else effective_intent(x).get('status')) in (('super_high','high') if requested=='priority' else (requested,))
                       and (requested!='pending' or isinstance(x.get('text'),str) and x['text'].strip())]
            if data.get('worklist') not in (None,'','pending','all'):raise ValueError('待处理筛选无效')
            if data.get('worklist')=='pending':
                items=[x for x in items if x['reply_state']!='sent' and x.get('handling_status')!='ignored' and effective_intent(x).get('status')!='unrelated' and effective_intent(x).get('level')!='very_low']
            analysis_pending_total=sum(not x.get('manual_intent') and not x.get('ai_intent')
                and isinstance(x.get('text'),str) and bool(x['text'].strip()) for x in items)
            view['analysis_pending_total']=analysis_pending_total
            view['analysis_analyzed_total']=sum(bool(x.get('manual_intent') or x.get('ai_intent')) for x in items)
            view['analysis_missing_text_total']=sum(not x.get('manual_intent') and not x.get('ai_intent')
                and not (isinstance(x.get('text'),str) and x['text'].strip()) for x in items)
            items.sort(key=lambda x:(str(x.get('created_at','')),str(x.get('published_at','')),str(x.get('id',''))),reverse=True)
            if sort=='intent':
                def intent_key(item):
                    semantic=effective_intent(item)
                    if item.get('ai_intent') or item.get('manual_intent'):
                        return ({'super_high':0,'high':1,'medium':2,'low':3,'very_low':6}.get(semantic.get('level'),4 if semantic.get('status')!='unrelated' else 7),0)
                    score=item.get('score')
                    finite=type(score) in (int,float) and math.isfinite(score)
                    return ({'A':4,'B':5,'C':6}.get(item.get('grade'),7),-score if finite else 0)
                items.sort(key=intent_key)
                items.sort(key=lambda x: x['reply_state']=='sent' or x.get('handling_status')=='ignored')
            items,grouping=group_rows(items,data)
            view.update(grouping)
            if snapshot=='begin':
                return self._export_page(user,snapshot,offset,limit,[lead_view(x) for x in items],view)
            return {**view,'items':[lead_view(x) for x in items[offset:offset+limit]],'total':len(items),'offset':offset,'limit':limit}
        if action=='reply_status':
            self._lead_access(user,self.core._get('leads',data.get('lead_id'),self.tenant))
            replies=[x for x in call('list',{'entity':'replies'}) if x.get('lead_id')==data['lead_id']]
            current=canonical_reply(replies)
            return pick(current,REPLY_FIELDS) if current else {'status':'none'}
        if action=='reply_pending':
            if user.get('role')!='admin':raise CoreError('回复审核由管理员管理')
            replies=[x for x in call('list',{'entity':'replies'}) if x.get('status')=='draft']
            replies.sort(key=lambda x:(str(x.get('updated_at','')),str(x.get('id',''))),reverse=True)
            items=[]
            visible=0
            owner={'username':self.owner,'cloud_bound':True}
            for reply in replies:
                try:
                    lead=self.core._get('leads',reply['lead_id'],self.tenant)
                    self._lead_access(owner,lead)
                except CoreError:continue
                visible+=1
                if len(items)>=10:continue
                text=str(reply.get('text',''))
                original=str(lead.get('text',''))
                items.append({'id':reply['id'],'lead_id':lead['id'],'text':text[:1000],
                    'needs_rewrite':len(text)>1000,
                    'updated_at':reply.get('updated_at',''),'author':str(lead.get('author',''))[:120],
                    'author_id':str(lead.get('author_id',''))[:160],
                    'comment_id':str(lead.get('comment_id',''))[:160],
                    'content_author':str(lead.get('content_author',''))[:120],
                    'comment_text':original[:500],'comment_truncated':len(original)>500,
                    'source_url':str(lead.get('note_url') or lead.get('url',''))[:1000],
                    'content_title':str(lead.get('content_title',''))[:300]})
            return {'items':items,'total':visible}
        if action=='reply_prepare':
            if len(str(data.get('text','')))>1000:raise ValueError('回复草稿最多 1000 字')
            self._lead_access(user,self.core._get('leads',data.get('lead_id'),self.tenant))
            return pick(call('draft_reply',{'lead_id':data.get('lead_id'),'text':data.get('text',''),'channel':'comment'}),REPLY_FIELDS)
        if action=='reply_review':
            if data.get('confirmed') is not True:raise ValueError('请先核对原评论和回复内容')
            reply=self.core._get('replies',data.get('reply_id'),self.tenant)
            self._lead_access(user,self.core._get('leads',reply['lead_id'],self.tenant))
            return pick(call('review_reply',{'id':reply['id'],'account_id':data.get('account_id'),'confirmed':True}),REPLY_FIELDS)
        if action=='reply_queue_prepare':
            ids=data.get('reply_ids')
            if not isinstance(ids,list) or not 1<=len(ids)<=20:raise ValueError('请确认1至20条回复')
            for ident in ids:
                reply=self.core._get('replies',ident,self.tenant)
                self._lead_access(user,self.core._get('leads',reply['lead_id'],self.tenant))
            return call('prepare_reply_queue',{'reply_ids':ids,'account_id':data.get('account_id'),'confirmed':data.get('confirmed') is True})
        if action in ('reply_queue_send','reply_queue_cancel','reply_queue_status'):
            if action=='reply_queue_send' and data.get('authorized') is not True:raise ValueError('请确认发送已审核回复')
            if action=='reply_queue_send':
                queue=self.core._get('reply_queues',data.get('queue_id'),self.tenant)
                account=self.core._get('accounts',queue.get('account_id'),self.tenant)
                self.core._account_access(user,account)
                self._claim_xhs_account(account)
            mapping={'reply_queue_send':'run_reviewed_reply_queue','reply_queue_cancel':'cancel_reviewed_reply_queue','reply_queue_status':'reviewed_reply_queue_status'}
            return call(mapping[action],{'id':data.get('queue_id'),'authorized':data.get('authorized') is True})
        if action=='reply_approve':
            reply=self.core._get('replies',data.get('reply_id'),self.tenant)
            lead=self.core._get('leads',reply['lead_id'],self.tenant)
            self._lead_access({'username':self.owner,'cloud_bound':True},lead)
            return pick(call('approve_reply',{'id':reply['id']}),REPLY_FIELDS)
        if action=='reply_send':
            if data.get('authorized') is not True:raise ValueError('必须明确确认真实发送')
            reply=self.core._get('replies',data.get('reply_id'),self.tenant)
            self._lead_access(user,self.core._get('leads',reply['lead_id'],self.tenant))
            account=self.core._get('accounts',data.get('account_id'),self.tenant)
            self.core._account_access(user,account)
            self._claim_xhs_account(account)
            return pick(call('send_reply',{'id':data.get('reply_id'),'account_id':data.get('account_id'),'authorized':True,'reply_trial':command.get('reply_trial')}),REPLY_FIELDS)
        if action=='diagnostics':
            return {'assistant':'available','active_tasks':len(self.core.running),'company_configured':True,'platforms':self.server.company.get('platforms',[])}
        if action=='update_check':
            if user.get('role')!='admin':raise CoreError('更新由管理员管理')
            return self._updates().check()
        if action in ('update_download','update_install','update_status'):
            if user.get('role')!='admin':raise CoreError('更新由管理员管理')
            coordinator=self._updates()
            return coordinator.check(download=True) if action=='update_download' else coordinator.request_install() if action=='update_install' else coordinator.status()
        raise CoreError('此远程业务动作尚未接入，未执行任何平台操作')

    def _updates(self):
        return server_update_coordinator(self.server)

    def stop_owned_tasks(self):
        self.core.continuous.revoke_executor(self)
        user=self.core.store.get('users',self.user_id)
        if not user:return
        if not getattr(self.server,'explicit_local_actions',False) and hasattr(self.core,'stop_owned_reply_queues'):
            self.core.stop_owned_reply_queues(self.tenant,self.owner)
        for task in self.core.store.list('tasks',self.tenant):
            if getattr(self.server,'explicit_local_actions',False) and task['id'] not in self._explicit_task_ids:continue
            account=self.core.store.get('accounts',task.get('account_id')) if task.get('account_id') else None
            owner=task.get('cloud_owner') or (account or {}).get('cloud_owner')
            collection=self.core.store.get('continuous_tasks',task['id']) if task.get('continuous_enabled') else None
            if owner==self.owner and task.get('continuous_enabled'):
                # Abort of an in-flight CLI is handled by AssistantService first.
                # Pause only active collection; preserve blocked/failed evidence.
                self.core._task_access(user,task,self.tenant)
                self.core.continuous.pause(task,only_active=True)
            if owner==self.owner and task['id'] in self.core.running:
                # cancel_task calls the unconditional continuous_pause path.
                # Use it for a legacy manual batch only when no terminal
                # continuous record exists to preserve.
                if not task.get('continuous_enabled') or not collection or collection.get('status')=='idle':
                    self.core.handle('cancel_task',{'id':task['id']},user)

    def reanalyze_existing(self,user,data):
        """Bounded development maintenance; never clear grades or start collection."""
        if (not getattr(self.server,'development_workspace',False) or
                user.get('role')!='operator' or user.get('cloud_bound') is not True or
                user.get('tenant_id')!=self.tenant or user.get('username')!=self.owner):
            raise CoreError('意向规则维护仅限本机已绑定开发工作台')
        if (not isinstance(data,dict) or set(data)-{'task_id','lead_ids','expected_profile','local_prompt_confirmation'} or
                not isinstance(data.get('task_id'),str) or not data['task_id']):
            raise CoreError('意向规则维护参数无效')
        writing='lead_ids' in data or 'expected_profile' in data
        local_confirmation=data.get('local_prompt_confirmation')
        if 'local_prompt_confirmation' in data and not writing:
            raise CoreError('本地提示词重评必须明确选择原评论小批次')
        if writing:
            self._require_product_feature('intent_analysis')
        import re
        from urllib.parse import urlsplit
        def source_post(lead):
            value=lead.get('note_url') or lead.get('url')
            if not isinstance(value,str) or len(value)>2048:return ''
            try:
                parsed=urlsplit(value)
                if (parsed.scheme!='https' or parsed.hostname not in ('xiaohongshu.com','www.xiaohongshu.com')
                        or parsed.port not in (None,443) or parsed.username or parsed.password):return ''
            except ValueError:return ''
            match=re.fullmatch(r'/(?:explore|search_result|discovery/item)/([A-Za-z0-9]{24})/?',parsed.path)
            return match.group(1).lower() if match else ''
        if writing:
            ids=data.get('lead_ids');expected=data.get('expected_profile')
            if (not isinstance(ids,list) or not 1<=len(ids)<=20 or
                    any(not isinstance(i,str) or not i for i in ids) or len(set(ids))!=len(ids) or
                    not isinstance(expected,dict) or
                    set(expected)!={'revision','rules_version','provider','model'} or
                    expected.get('provider')!='deepseek' or expected.get('model')!='deepseek-flash'):
                raise CoreError('意向规则维护批次无效')
        if not self._intent_refresh_lock.acquire(blocking=False):
            raise CoreError('意向规则维护正在进行，请等待本批完成')
        try:
            with self.core.lock:
                task=self.core._get('tasks',data['task_id'],self.tenant)
                self.core._task_access(user,task,self.tenant)
                from core.intent_policy import task_analysis_prompt_state
                expected_local=task_analysis_prompt_state(task,None)['expected_version']
                if local_confirmation is not None and (not isinstance(local_confirmation,dict)
                        or set(local_confirmation)!={'expected_version','confirmed'}
                        or local_confirmation.get('confirmed') is not True or expected_local is None
                        or local_confirmation.get('expected_version')!=expected_local):
                    raise CoreError('当前任务本地提示词版本或本人确认已变化，未开始新分析')
                continuous=self.core.store.get('continuous_tasks',task['id']) or {}
                if (task['id'] in self.core.running or continuous.get('inflight') or
                        continuous.get('status') not in ('paused','idle',None)):
                    raise CoreError('请先暂停采集再维护意向规则')
                leads=[]
                for lead in self.core.store.list('leads',self.tenant):
                    if lead.get('task_id')!=task['id'] or lead.get('demo'):continue
                    self._lead_access(user,lead)
                    leads.append(lead)
                if writing:
                    by_id={lead['id']:lead for lead in leads}
                    if any(i not in by_id for i in ids):
                        raise CoreError('维护批次包含其他任务的评论')
                    batch=[by_id[i] for i in ids]
                    if (any(not source_post(lead) for lead in batch) or
                            len({source_post(lead) for lead in batch})!=1 or
                            len({post_identity(lead) for lead in batch})!=1 or
                            any(lead.get('manual_intent') or not isinstance(lead.get('ai_intent'),dict)
                                or not isinstance(lead.get('text'),str) or not lead['text'].strip()
                                for lead in batch)):
                        raise CoreError('维护批次仅限同帖已有 AI 结果，人工结果保持优先')
            if writing:
                return self.ai.analyze(user,task,batch,replace_existing=True,expected_profile=expected,local_prompt_confirmation=local_confirmation)
            profile=self._ai_cloud(user,'ai_profile',{}).get('config',{})
            if not profile.get('enabled') or not profile.get('configured'):
                raise CoreError('企业 AI 尚未启用')
            if profile.get('provider')!='deepseek' or profile.get('model')!='deepseek-flash':
                raise CoreError('本次意向规则维护仅使用已确认的 DeepSeek 模型')
            expected={key:profile.get(key) for key in ('revision','rules_version','provider','model')}
            groups={};local_groups={};local_states={};local_unverified=0;excluded=0;manual=0;current=0;unverified_post=0
            for lead in leads:
                if lead.get('manual_intent'):manual+=1;continue
                if not isinstance(lead.get('text'),str) or not lead['text'].strip():excluded+=1;continue
                previous=lead.get('ai_intent')
                if not isinstance(previous,dict):continue
                local_state=task_analysis_prompt_state(task,previous)
                state=local_state['status'];local_states[state]=local_states.get(state,0)+1
                if previous.get('rules_version')==profile.get('rules_version'):
                    if state in ('unrecorded','different'):
                        if not source_post(lead):local_unverified+=1;continue
                        local_groups.setdefault(post_identity(lead),[]).append(lead['id'])
                    else:current+=1
                    continue
                if not source_post(lead):unverified_post+=1;continue
                groups.setdefault(post_identity(lead),[]).append(lead['id'])
            return {'task_id':task['id'],'expected_profile':expected,'groups':list(groups.values()),
                    'eligible':sum(map(len,groups.values())),'current':current,
                    'manual_preserved':manual,'excluded_missing_text':excluded,
                    'excluded_unverified_post':unverified_post,
                    'local_prompt':{'status':'not_applicable' if expected_local is None else 'versioned',
                        'expected_version':expected_local,'states':local_states,'groups':list(local_groups.values()),
                        'eligible':sum(map(len,local_groups.values())),'excluded_unverified_post':local_unverified,
                        'explicit_confirmation_required':True,'metadata_source':'client_local_prompt',
                        'provider_execution_verified':False,
                        'notice':'仅核对客户端本地提示词版本；本人明确确认小批次后才可新分析，结果未知仍核对原编号。'}}
        finally:self._intent_refresh_lock.release()

    def analyze_pending(self,user,data,*,explicit_retry=False):
        task=self.core._get('tasks',data.get('task_id'),self.tenant)
        self.core._task_access(user,task,self.tenant)
        BusinessExecutor._require_product_feature(self, 'intent_analysis')
        groups={}
        excluded_missing_text=0
        for lead in self._analysis_visible_leads(user,task):
            if lead.get('task_id')!=task['id'] or lead.get('demo') or lead.get('manual_intent') or lead.get('ai_intent'):continue
            if not isinstance(lead.get('text'),str) or not lead['text'].strip():
                with self.core.lock:
                    current=self.core.store.get('leads',lead['id'])
                    if (not current or current.get('tenant_id')!=self.tenant or
                            current.get('manual_intent') or current.get('ai_intent') or
                            isinstance(current.get('text'),str) and current['text'].strip()):
                        continue
                    self._lead_access(user,current)
                    if current.get('analysis_status')!='missing_text' or current.get('verification_status')!='pending':
                        current.update(analysis_status='missing_text',verification_status='pending')
                        self.core.store.put('leads',current)
                    excluded_missing_text+=1
                continue
            key=post_identity(lead)
            groups.setdefault(key,[]).append(lead)
        if not groups:return {'analyzed':0,'pending':0,'excluded_missing_text':excluded_missing_text}
        # Keep structured outputs small enough to validate consistently; the
        # independent worker drains every remaining same-post batch automatically.
        batch=next(iter(groups.values()))[:20]
        result=self.ai.analyze(user,task,batch,explicit_retry=explicit_retry)
        with self.core.lock:
            current_user=self.core.store.get('users',user['id']) if user.get('id') else None
            if (not current_user or current_user.get('disabled') or
                    any(current_user.get(key)!=user.get(key) for key in
                        ('id','tenant_id','username','role','cloud_bound'))):
                return {**result,'pending':0}
            try:
                current_task=self.core._get('tasks',task['id'],self.tenant)
                self.core._task_access(current_user,current_task,self.tenant)
            except CoreError:
                return {**result,'pending':0}
            pending=0;excluded_missing_text=0
            for lead in self.core.store.list('leads',self.tenant):
                if lead.get('task_id')!=task['id'] or lead.get('demo') or lead.get('manual_intent') or lead.get('ai_intent'):continue
                try:self._lead_access(current_user,lead)
                except CoreError:continue
                if not isinstance(lead.get('text'),str) or not lead['text'].strip():excluded_missing_text+=1
                else:pending+=1
        return {**result,'pending':pending,'excluded_missing_text':excluded_missing_text}
