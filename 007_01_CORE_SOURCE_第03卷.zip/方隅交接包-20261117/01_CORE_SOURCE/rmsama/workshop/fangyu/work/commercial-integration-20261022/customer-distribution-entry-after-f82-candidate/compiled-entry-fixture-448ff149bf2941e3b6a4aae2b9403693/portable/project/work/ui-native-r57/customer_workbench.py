"""Employee-local customer history over preserved, pinned r55 modules.

This interface performs local customer reads, internal handoff persistence and
in-memory XLSX generation. Its
store context identifies the authenticated employee's current cloud context;
legacy history without a store binding is never relabelled as verified store data.
"""
import base64
from copy import deepcopy
from datetime import datetime, timedelta, timezone
import hashlib
import html
import importlib
import importlib.util
import io
import json
import re
import sys
from pathlib import Path
from types import SimpleNamespace
from urllib.parse import urlsplit,urlencode

from core import CoreError
from core.service_plans import ProductAccessError, require_feature

COMPANY_ID = 'fangyu-apartment-client'
SCOPE = 'employee-local-history'
DEPENDENCY_SHA256 = {
    'assistant/intent_correction.py':'F1D406F87A38D313E772E6649D213B8B7783272A4453B3FD58698C4029382291',
    'assistant/customer_list.py':'B07140CD3B52476DF8FC2CB4B58D601CFCA42E8C4BE8CDFF6672C693BC2FDD0C',
    'assistant/business.py':'06F6B87C3ABCEB8048362B6E887FB7772A55C74B5EDCFCC3B4BF3657A611DDF2',
    'assistant/ai_workflow.py':'E64063D62D632762A499C96D6C197B7D185458264DB10B42032737984D2AF814',
    'xlsxwriter/__init__.py':'F81B0587E6FC5A979724A31CD288753E722D4EA29D0BF2310B5F50FE93BF13D3',
    'xlsxwriter/workbook.py':'4B4A3820B4877EF31920CE13630D66AABF4AED5E9F9C7A7A7E27694276B7E2F9',
    'xlsxwriter/worksheet.py':'DB89556547C80594596BC9E264AF9B9AC4453713748CFC7D09B052DFA05AA1AD',
}
FILTERS = frozenset(('all','high','medium','low','uncertain','unanalyzed','unrelated','pending','replied'))
SORTS = frozenset(('intent','reply','time','post'))
LEVELS = {'super_high':('超高意向',3,'urgent'), 'high':('高意向',2,'high'),
          'medium':('中意向',1,'medium'), 'low':('低意向',0,'low'),
          'very_low':('极低意向',-1,'muted')}
CONTACT_LABELS = {'sent':'已回复', 'external_reported':'已登记联系',
    'unknown':'发送结果待确认', 'copied':'已复制，未确认发送',
    'legacy_sent_unverified':'历史发送记录未确认', 'uncontacted':'未回复'}
PLATFORMS = {'xiaohongshu':'小红书','douyin':'抖音','zhihu':'知乎',
    'wechat_channels':'视频号','bilibili':'哔哩哔哩','kuaishou':'快手','weibo':'微博'}
QUERY_FIELDS = frozenset(('query','filter','sort','sortDirection','page','pageSize','platform','intent','acquiredDate','leaseGroup'))
KEY = re.compile(r'[0-9a-f]{64}\Z')
STORE = re.compile(r'[A-Za-z0-9_-]{1,80}\Z')
HANDOFF_ENTITY='ui_customer_handoff_v1'
REQUEST=re.compile(r'[A-Za-z0-9_-]{1,160}\Z')


def _digest(value):
    return hashlib.sha256(json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()


class CustomerWorkbenchError(ValueError):
    def __init__(self, code, message, status=400):
        super().__init__(message)
        self.code, self.status = code, status


def _fail(code, message, status=400):
    raise CustomerWorkbenchError(code, message, status)


def _text(value, limit=2000):
    if not isinstance(value, str):
        return ''
    return re.sub(r'[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]', '', value)[:limit]


def _avatar_url(person):
    # Reuse only this visible customer's recorded avatar, with no platform read.
    values = [person.get('avatar_url')]
    values.extend((comment.get('lead') or {}).get('author_avatar_url')
                  for comment in person.get('comments') or [])
    for value in values:
        if not isinstance(value,str) or not value or len(value)>2048 or re.search(r'[\s\x00-\x1f\x7f]',value):
            continue
        try:
            parsed=urlsplit(value)
            if parsed.scheme in ('http','https') and parsed.hostname and not parsed.username and not parsed.password:
                parsed.port  # Reject malformed authority before returning it.
                return value
        except ValueError:
            continue
    return ''


def _epoch(value):
    if type(value) in (int,float):
        return value if 0 <= value <= 253402300799 else 0
    if not isinstance(value,str):
        return 0
    try:
        parsed = datetime.fromisoformat(value.replace('Z','+00:00'))
        if parsed.tzinfo is None:
            parsed = parsed.replace(tzinfo=timezone.utc)
        return parsed.timestamp()
    except (ValueError, OverflowError, OSError):
        return 0


def _time(value):
    stamp = _epoch(value)
    return datetime.fromtimestamp(stamp, timezone.utc).isoformat(timespec='seconds') if stamp else ''


def _load_preserved(path, name):
    module = sys.modules.get(name)
    if module is not None:
        if Path(module.__file__).resolve() != path.resolve():
            _fail('CUSTOMER_DEPENDENCY', '客户历史组件来源需核对', 503)
        return module
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    try:
        spec.loader.exec_module(module)
    except Exception:
        sys.modules.pop(name, None)
        raise
    return module


class CustomerWorkbench:
    def __init__(self, core, company, project_root, *, rental_reader=None):
        self.core, self.company = core, deepcopy(company)
        # Optional read boundary for separate current rental assessments. None
        # preserves historical display; an assessed unknown is a current result.
        self.rental_reader = rental_reader
        self.rental_batch_reader = None
        managed = self.company.get('managedWorkspace') if isinstance(self.company,dict) else None
        if (not isinstance(self.company,dict) or self.company.get('id') != COMPANY_ID
                or self.company.get('edition') != 'customer' or self.company.get('personalMode') is not False
                or self.company.get('authMode') != 'managed' or not isinstance(managed,dict)
                or not isinstance(managed.get('environment_id'),str) or not managed['environment_id']):
            _fail('CUSTOMER_CONFIG', '客户历史需要当前企业员工配置', 503)
        self.tenant = 'cloud-'+hashlib.sha256((managed['environment_id']+'\n'+COMPANY_ID).encode()).hexdigest()[:24]
        self.source = Path(project_root).resolve()/'work/ui-runtime-r55/src'
        for relative, expected in DEPENDENCY_SHA256.items():
            path = self.source/relative
            try:
                digest = hashlib.sha256(path.read_bytes()).hexdigest().upper()
            except OSError:
                _fail('CUSTOMER_DEPENDENCY', '客户历史组件暂不可读', 503)
            if digest != expected:
                _fail('CUSTOMER_DEPENDENCY', '客户历史组件校验未通过', 503)
        # Load the exact old implementation without replacing the optional
        # platform runtime's separately assembled assistant.business module.
        self.history_type = _load_preserved(self.source/'assistant/customer_list.py',
            'assistant._r57_customer_history').CustomerHistory
        self.access_function = _load_preserved(self.source/'assistant/business.py',
            'assistant._r57_customer_business').BusinessExecutor._lead_access

    def _actor(self, user, store_id):
        if not isinstance(user,dict) or not isinstance(store_id,str) or not STORE.fullmatch(store_id):
            _fail('AUTH_REQUIRED', '请先使用企业员工账号登录', 401)
        saved = self.core.store.get('users', user.get('id'))
        if (not saved or saved.get('disabled') or saved.get('cloud_bound') is not True
                or saved.get('development_local_only') is True or saved.get('role') not in ('operator','admin')
                or saved.get('tenant_id') != self.tenant
                or any(saved.get(key) != user.get(key) for key in ('id','tenant_id','username','role','cloud_bound'))
                or not isinstance(saved.get('username'),str) or not saved['username']):
            _fail('AUTH_REQUIRED', '员工身份已变化，请重新登录', 401)
        if saved['role'] == 'admin' and user.get('_workbench_store_id') != store_id:
            _fail('STORE_FORBIDDEN','请先选择当前已授权门店分组',403)
        return {**saved,'_workbench_store_id':store_id}, {'username':saved['username'], 'storeId':store_id}

    @staticmethod
    def platform_filter(data):
        if 'platform' not in data:
            return None
        value = data['platform']
        if type(value) is not str or value not in ('xiaohongshu','douyin'):
            _fail('PLATFORM_INVALID','请选择小红书或抖音')
        return value

    def _history(self, user, store_id, platform=None):
        access = SimpleNamespace(core=self.core, tenant=self.tenant)
        def lead_access(actor, lead, task_cache=None):
            self.access_function(access, actor, lead, task_cache=task_cache)
            # r55 does not create a store field for historical leads/tasks.
            # Explicit bindings, if present, must never be silently reassigned.
            task = (task_cache or {}).get(lead.get('task_id')) or {}
            if platform is not None and (lead.get('platform') != platform
                    or task.get('platform') not in (None,'',platform)):
                raise CoreError('此客户来源不属于当前平台')
            if actor.get('role') == 'admin' and not any(record.get('store_id') for record in (lead,task)):
                raise CoreError('历史客户未核实来源门店，管理员多店视图不推断归属')
            for record in (lead, task):
                explicit = record.get('store_id')
                if explicit not in (None,'') and explicit != store_id:
                    raise CoreError('此客户来源不属于当前门店上下文')
        return self.history_type(self.core,self.tenant,user['username'],lead_access=lead_access)

    def _options(self, data, export=False):
        if not isinstance(data,dict) or set(data)-QUERY_FIELDS-{'audience'}-({'selectedIds'} if export else set()):
            _fail('INVALID_INPUT', '客户筛选参数无效')
        query = data.get('query','')
        selected, sort, direction = data.get('filter','all'),data.get('sort','intent'),data.get('sortDirection','desc')
        page, size = data.get('page',1),data.get('pageSize',20)
        audience=data.get('audience','all')
        intent=data.get('intent','all');date=data.get('acquiredDate','')
        lease=data.get('leaseGroup','all')
        if lease not in ('all','1至3个月','4至11个月','12个月','未说明','其他租期','租期待确认'):
            _fail('INVALID_INPUT','请选择有效租期分组')
        if intent not in ('all','super_high','high','medium','low','very_low','uncertain','unanalyzed','unrelated') or not isinstance(date,str):
            _fail('INVALID_INPUT','意向或采集日期无效')
        if date:
            try:
                if datetime.strptime(date,'%Y-%m-%d').strftime('%Y-%m-%d')!=date:raise ValueError()
            except ValueError:_fail('INVALID_INPUT','请选择有效日期')
        if (not isinstance(query,str) or len(query)>100
                or not isinstance(selected,str) or selected not in FILTERS
                or not isinstance(sort,str) or sort not in SORTS
                or not isinstance(direction,str) or direction not in ('asc','desc')
                or type(page) is not int or not 1<=page<=1000000
                or type(size) is not int or size not in (20,50)
                or audience not in ('all','prospects')):
            _fail('INVALID_INPUT', '客户筛选、排序或分页参数无效')
        return {'query':query.strip().casefold(),'filter':selected,'sort':sort,
                'sortDirection':direction,'page':page,'pageSize':size,'audience':audience,
                'platform':self.platform_filter(data),'intent':intent,'acquiredDate':date,'leaseGroup':lease}

    @staticmethod
    def _representative_source(person):
        """A quoted comment, judgement, and source must come from one record."""
        comments = person.get('comments') or []
        comment = next((comment for comment in comments
            if comment['lead_id']==person.get('representative_intent_lead_id')), None)
        comment = comment or (comments[0] if comments else None)
        if comment is None:
            post = person.get('primary_post') or {}
            return {}, person.get('latest_comment') or '', post.get('title') or '帖子标题未提供', post.get('note_url') or ''
        lead = comment.get('lead') or {}
        post = next((post for post in person.get('posts',[])
                     if post.get('post_key')==comment.get('post_key')),{})
        return (comment.get('intent') or {}, comment.get('text') or '',
                lead.get('content_title') or lead.get('title') or post.get('title') or '帖子标题未提供',
                comment.get('note_url') or post.get('note_url') or '')

    def _with_rental_assessment(self, person, user, store_id, assessments=None):
        """Use only already visible comments; never merge current with old grades."""
        if not callable(self.rental_reader):
            return person
        assessed = []
        for comment in person.get('comments') or []:
            assessment = (assessments.get(comment['lead_id']) if assessments is not None
                          else self.rental_reader(user, store_id, comment['lead_id']))
            if assessment is not None:
                assessed.append((comment, assessment))
        person['_rental_assessments'] = {comment['lead_id']:deepcopy(assessment)
            for comment,assessment in assessed if isinstance(assessment,dict)}
        if not assessed:
            return person
        comment, assessment = max(assessed, key=lambda pair:(
            _epoch(pair[0].get('published_at')) or _epoch(pair[0].get('created_at')),
            _epoch(pair[0].get('created_at')), pair[0]['lead_id']))
        person['_legacy_intent_level'] = self.history_type._top_level(person)
        person['_legacy_intent_lead_id'] = person.get('representative_intent_lead_id') or ''
        person['_rental_assessment'] = deepcopy(assessment) if isinstance(assessment,dict) else {
            'intent_level':'unknown', 'reason':'当前判断格式需复核', 'review_required':True}
        person['representative_intent_lead_id'] = comment['lead_id']
        return person

    @staticmethod
    def _rental_evidence(assessment):
        values = []
        for value in assessment.get('evidence') if isinstance(assessment.get('evidence'),list) else []:
            quote = value.get('quote') if isinstance(value,dict) else value
            if isinstance(quote,str) and quote.strip() and quote not in values:
                values.append(quote)
        reason = assessment.get('reason')
        if isinstance(reason,str) and reason.strip() and reason not in values:
            values.insert(0,reason)
        return values

    @staticmethod
    def _financial_fields(assessment, *, full=False):
        """Expose recorded financial evidence without inferring missing units."""
        assessment = assessment if isinstance(assessment,dict) else {}
        original = assessment.get('budget')
        original = original if isinstance(original,dict) else {}
        scalar_fields = ('amount_min','amount_max','monthly_unit_rent_cap',
            'annual_equivalent_monthly','occupants')
        text_fields = ('limit_kind','currency','currency_raw','period','cost_scope',
            'allocation','normalization_formula','normalization_label')
        budget = {field:original.get(field) if type(original.get(field)) in (int,float) else None
                  for field in scalar_fields}
        budget.update({field:_text(original.get(field),500) or None for field in text_fields})
        quote = original.get('raw_quote')
        budget['raw_quote'] = quote if full and isinstance(quote,str) else _text(quote,32000) or None
        budget['comparable'] = original.get('comparable') is True
        budget['missing_fields'] = [_text(field,80) for field in original.get('missing_fields',[])
            if isinstance(field,str)] if isinstance(original.get('missing_fields'),list) else []
        period = {'month':'月','year':'年','day':'日','week':'周','one_time':'一次性'}.get(
            budget.get('period'),'周期未确认')
        currency = budget.get('currency') or '币种未确认'
        scope = {'rent_only':'仅租金','all_in':'含费用总额','deposit':'押金',
            'rent_and_fees':'租金及费用'}.get(budget.get('cost_scope'),'费用范围未确认')
        allocation = {'whole_unit':'整套','per_person':'每人','per_room':'每间'}.get(
            budget.get('allocation'),'人数/整套口径未确认')
        budget_basis = ' · '.join((currency,period,scope,allocation))
        budget_summary = '未提供预算' if not budget['raw_quote'] else (
            _text(budget['raw_quote'],160)+'（'+budget_basis+'）')
        income = assessment.get('income_self_report')
        if (not isinstance(income,dict) or income.get('subject')!='self'
                or income.get('self_reported') is not True):
            income = None
        else:
            raw = income.get('raw_quote')
            income = {field:income.get(field) if type(income.get(field)) in (int,float) else None
                for field in ('amount_min','amount_max') } | {
                field:_text(income.get(field),500) or None for field in ('currency','period','tax_basis') } | {
                'raw_quote':raw if full and isinstance(raw,str) else _text(raw,32000) or None,
                'subject':'self','self_reported':True,'verified':False}
        income_basis = ''
        if income is not None:
            income_basis = ' · '.join(('本人自报未验证',income.get('currency') or '币种未确认',
                {'month':'月','year':'年','day':'日','week':'周'}.get(income.get('period'),'周期未确认'),
                {'net':'税后','gross':'税前'}.get(income.get('tax_basis'),'税前/税后未确认')))
        income_summary = (_text(income.get('raw_quote'),160)+'（'+income_basis+'）') \
            if income is not None and income.get('raw_quote') else '未提供收入自报'
        matches = assessment.get('store_matches')
        matches = [{'store_id':_text(value.get('store_id'),80) or None,
                    'fit_status':_text(value.get('fit_status'),80) or 'not_comparable',
                    'price_verified':value.get('price_verified') is True}
                   for value in matches if isinstance(value,dict)] if isinstance(matches,list) else []
        return {'budget':budget,'budgetSummary':budget_summary,'budgetBasis':budget_basis,
                'incomeSelfReport':income,'incomeSummary':income_summary,'incomeBasis':income_basis,
                'storeMatches':matches}

    def _legacy_summary(self, person):
        level = person.get('_legacy_intent_level', self.history_type._top_level(person))
        graded = LEVELS.get(level)
        label, rank, _ = graded if graded else ('不相关' if level=='unrelated' else '未分级',None,'muted')
        return {'level':level, 'label':label, 'rank':rank, 'source':'historical',
                'representativeLeadId':person.get('_legacy_intent_lead_id',
                    person.get('representative_intent_lead_id') or '')}

    @staticmethod
    def _media_url(store_id,lead_id,kind):
        if not store_id or not lead_id:return ''
        return '/api/workbench/media?'+urlencode({'storeId':store_id,'leadId':lead_id,'kind':kind})

    def media(self,user,store_id,lead_id,kind,fetcher=None):
        from assistant.saved_media import saved_avatar,MediaForbidden
        if kind not in ('author','post_author','cover'):
            _fail('INVALID_INPUT','图片类型无效')
        def visible():
            actor,_=self._actor(user,store_id)
            try:
                people=self._history(actor,store_id)._build(actor)
                if not any(comment.get('lead_id')==lead_id for person in people.values()
                        for comment in person.get('comments') or []):
                    _fail('CUSTOMER_UNAVAILABLE','来源不在当前员工与门店范围',403)
            except CoreError:
                _fail('CUSTOMER_UNAVAILABLE','来源不在当前员工与门店范围',403)
            return actor
        with self.core.lock:actor=visible()
        try:
            result=saved_avatar(self.core,actor,lead_id,kind,presentation=True,**({'fetcher':fetcher} if fetcher is not None else {}))
        except MediaForbidden:
            _fail('CUSTOMER_UNAVAILABLE','图片不在当前员工可见范围',403)
        with self.core.lock:visible()
        return result

    def _project(self, person, detail=False,store_id=None):
        comments = person.get('comments') or []
        avatar=_avatar_url(person)
        avatar_comment=next((comment for comment in comments
            if (comment.get('lead') or {}).get('author_avatar_url')==avatar),None)
        avatar_lead=(avatar_comment or {}).get('lead_id') or person.get('representative_intent_lead_id') or (comments[0]['lead_id'] if comments else '')
        intent, quote, post_title, post_url = self._representative_source(person)
        assessment = person.get('_rental_assessment')
        representative=next((comment for comment in comments if comment['lead_id']==person.get('representative_intent_lead_id')),None)
        original=(representative or {}).get('lead') or {}
        recorded=original.get('manual_intent') or original.get('ai_intent')
        recorded=recorded if isinstance(recorded,dict) and recorded.get('status') in ('graded','uncertain','unrelated') else None
        # Legacy keyword grades are retained in the historical disclosure, but
        # cannot masquerade as a completed current model/manual judgment.
        level_key = 'pending'
        if recorded is not None:
            level_key=recorded.get('level') if recorded['status']=='graded' else recorded['status']
        graded = LEVELS.get(level_key)
        label,rank,tone = graded if graded else (
            '不相关' if level_key=='unrelated' else '信息不足' if level_key=='uncertain' else '尚未分析',None,'muted')
        facts = intent.get('key_info') if isinstance(intent.get('key_info'),list) else []
        need = ' · '.join(_text(fact.get('value'),80) for fact in facts
            if isinstance(fact,dict) and fact.get('type') in ('budget','move_in','commute','room_type','location')
            and isinstance(fact.get('value'),str) and fact['value'].strip())
        evidence = [_text(value,500) for value in (intent.get('evidence') or [])
                    if isinstance(value,str) and value.strip()] if isinstance(intent.get('evidence'),list) else []
        reason = _text(intent.get('reason'),500)
        if reason and reason not in evidence:
            evidence.insert(0,reason)
        if assessment is not None and recorded is None:
            # Deterministic sidecars provide lease and fit clues, never a
            # completed model judgment or a replacement for saved AI/manual.
            evidence = [_text(value,500) for value in self._rental_evidence(assessment)]
            need = _text(quote,80)
        state = person['contact_state']
        replied = state=='sent'
        eligibility='uncertain'
        if recorded is not None:
            if recorded['status']=='unrelated':eligibility='non_target'
            elif recorded['status']=='graded':eligibility='rental_seeker'
        acquired=[_epoch(c.get('created_at') or (c.get('lead') or {}).get('created_at')) for c in comments]
        first=min((v for v in acquired if v),default=0)
        acquired_date=datetime.fromtimestamp(first,timezone(timedelta(hours=8))).strftime('%Y-%m-%d') if first else ''
        result = {'acquiredDate':acquired_date,'id':person['author_key'], 'name':_text(person.get('nickname'),300) or '昵称未提供',
            'avatarUrl':self._media_url(store_id,avatar_lead,'author') if avatar else '',
            'need':need or '需求待补充', 'level':label, 'rank':rank, 'tone':tone,
            'contactAt':_time(person.get('last_contact_at')), 'contactLabel':CONTACT_LABELS.get(state,'联系状态待确认'),
            'contactState':state, 'replied':replied, 'channel':PLATFORMS.get(person['platform'],'来源平台未提供'),
            'platform':person['platform'], 'postTitle':_text(post_title,500),
            'postUrl':_text(post_url,2048), 'quote':_text(quote,32000),
            'coverUrl':self._media_url(store_id,person.get('representative_intent_lead_id') or (comments[0]['lead_id'] if comments else ''),'cover'),
            'nextStep':'查看联系记录' if replied else '核对原评论与发送结果' if state=='unknown' else '查看需求后人工回复',
            'sourceNotice':'帖子日期未提供，时间范围待核实' if (
                (representative or (comments[0] if comments else {})).get('lead') or {}).get('post_date_status')=='unverified' else '',
            'evidence':evidence[:9],
            'intentSource':('manual' if original.get('manual_intent') else 'ai') if recorded is not None else 'rental-assessment' if assessment is not None else 'legacy',
            'intentLevel':level_key,
            'analysisStatus':recorded['status'] if recorded is not None else 'pending',
            'intentRuleVersion':_text(recorded.get('rules_version'),200) if recorded is not None else _text(assessment.get('rule_version'),200) if assessment is not None else '',
            'intentProvider':_text(recorded.get('provider'),80) if recorded is not None else '',
            'intentModel':_text(recorded.get('model'),100) if recorded is not None else '',
            'assessmentSourceDigest':_text(assessment.get('source_digest'),200) if assessment is not None else '',
            'assessmentRuleSourceDigest':_text(assessment.get('rule_source_digest'),200) if assessment is not None else '',
            'assessmentContractDigest':_text(assessment.get('contract_digest'),200) if assessment is not None else '',
            'assessmentBundleRevision':_text(assessment.get('bundle_revision'),200) if assessment is not None else '',
            'representativeLeadId':person.get('representative_intent_lead_id') or '',
            'eligibility':eligibility,
            'reviewRequired':assessment.get('review_required') is not False if assessment is not None else False}
        typed_live=original.get('source_type')=='livestream_chat'
        result.update(sourceType=original.get('source_type','comment'),sourceLabel='直播聊天原文' if typed_live else '评论原文',sourceLinkLabel='打开直播间' if typed_live else '打开原帖',commentReplyAllowed=not typed_live)
        if typed_live:result.update(nextStep='查看直播聊天与需求判断；不提供评论回复',sourceNotice='直播聊天来源时间未提供' if not original.get('published_at') else '')
        result.update(self._financial_fields(assessment))
        if (store_id=='fy_s_d343f3a378f48e1bab55df4f' and isinstance(assessment,dict)
                and assessment.get('gubei_rule_version')=='gubei-human-approved-20261021-v2'):
            result.update(leaseGroup=assessment['lease_group'],leaseTerm=deepcopy(assessment['lease_term']),
                storeFit=deepcopy(assessment['store_fit']),manualReplyOnly=True)
        if detail:
            result['legacyIntent'] = self._legacy_summary(person)
            result['comments'] = [{'id':comment['lead_id'], 'text':_text(comment.get('text'),32000),
                'sourceType':(comment.get('lead') or {}).get('source_type','comment'),
                'sourceLabel':'直播聊天原文' if (comment.get('lead') or {}).get('source_type')=='livestream_chat' else '评论原文',
                'commentReplyAllowed':(comment.get('lead') or {}).get('source_type')!='livestream_chat',
                'publishedAt':_text(comment.get('published_at'),100),
                'postTitle':_text((comment.get('lead') or {}).get('content_title') or (comment.get('lead') or {}).get('title'),500),
                'postUrl':_text(comment.get('note_url'),2048),
                'coverUrl':self._media_url(store_id,comment['lead_id'],'cover')} for comment in comments]
        return result

    @staticmethod
    def _is_prospect(item):
        return (item.get('eligibility') in ('rental_seeker','')
            and item.get('intentLevel') not in ('unrelated','unknown')
            and item.get('rank') is not None)

    def _matching(self, user, store_id, options):
        history = self._history(user,store_id,options.get('platform'))
        people = history._build(user)
        assessments = None
        if callable(self.rental_batch_reader):
            lead_ids = list(dict.fromkeys(comment['lead_id'] for person in people.values()
                                         for comment in person.get('comments') or []))
            assessments = self.rental_batch_reader(user,store_id,lead_ids)
        handoffs=self._handoff_records(user,store_id)
        latest={}
        for record in handoffs:
            if record['version']>latest.get(record['customerId'],{}).get('version',0):latest[record['customerId']]=record
        rows = []
        query = options['query']
        for person in people.values():
            self._with_rental_assessment(person,user,store_id,assessments)
            item = self._project(person,store_id=store_id)
            if options.get('audience')=='prospects' and not self._is_prospect(item):
                continue
            self._handoff_summary(item,latest.get(item['id']))
            if query and query not in (' '.join((item['name'],item['need'],item['channel'],item['level'],
                    str(person.get('author_id') or ''),*(str(comment.get('text') or '')+' '+str(comment.get('note_url') or '')
                    for comment in person['comments'])))).casefold():
                continue
            rows.append((person,item))
        days={}
        for person,item in rows:
            day=item['acquiredDate']
            if not day:continue
            count=days.setdefault(day,{'added':0,'analyzed':0,'highIntent':0})
            count['added']+=1
            count['analyzed']+=int(any(isinstance((c.get('lead') or {}).get('manual_intent') or (c.get('lead') or {}).get('ai_intent'),dict) and ((c.get('lead') or {}).get('manual_intent') or (c.get('lead') or {}).get('ai_intent')).get('status') in ('graded','uncertain','unrelated') for c in person.get('comments',[])))
            count['highIntent']+=int(item['rank'] is not None and item['rank']>=2)
        lease_counts={key:sum(item.get('leaseGroup')==key for _,item in rows) for key in ('1至3个月','4至11个月','12个月','未说明','其他租期','租期待确认')}
        rows=[(person,item) for person,item in rows if (options.get('leaseGroup','all')=='all' or item.get('leaseGroup')==options['leaseGroup'])]
        rows=[(person,item) for person,item in rows if (options.get('intent','all')=='all' or item['intentLevel']==options['intent'] or options['intent']=='uncertain' and item['analysisStatus']=='uncertain' or options['intent']=='unanalyzed' and item['analysisStatus']=='pending') and (not options.get('acquiredDate') or item['acquiredDate']==options['acquiredDate'])]
        stats = {'leaseGroups':lease_counts,'days':days,'total':len(rows), 'high':sum(item['rank'] is not None and item['rank']>=2 for _,item in rows),
                 'replied':sum(item['replied'] for _,item in rows),
                 'handoff':sum(not item['handoff']['prepared'] for _,item in rows)}
        selected = options['filter']
        rows = [(person,item) for person,item in rows if selected=='all'
            or selected=='high' and item['rank'] is not None and item['rank']>=2
            or selected=='medium' and item['rank']==1
            or selected=='low' and item['rank'] is not None and item['rank']<=0
            or selected=='uncertain' and item['analysisStatus']=='uncertain'
            or selected=='unanalyzed' and item['analysisStatus']=='pending'
            or selected=='unrelated' and item['analysisStatus']=='unrelated'
            or selected=='pending' and not item['replied']
            or selected=='replied' and item['replied']]
        # Every sort applies to the full permitted result before paging.
        rows.sort(key=lambda pair:pair[1]['id'])
        rows.sort(key=lambda pair:_epoch(pair[0].get('latest_published_at') or pair[0].get('last_comment_at')),reverse=True)
        sort = options['sort']
        def key(pair):
            person,item = pair
            if sort=='intent': return item['rank'] if item['rank'] is not None else -2
            if sort=='reply': return (item['replied'],_epoch(person.get('last_contact_at')))
            if sort=='time': return _epoch(person.get('latest_published_at') or person.get('last_comment_at'))
            return (item['platform'],item['postTitle'].casefold())
        rows.sort(key=key, reverse=options['sortDirection']=='desc')
        return rows, stats

    def list(self, user, store_id, data):
        options = self._options(data)
        with self.core.lock:
            actor, public = self._actor(user,store_id)
            rows, stats = self._matching(actor,store_id,options)
            total = len(rows)
            pages = (total+options['pageSize']-1)//options['pageSize']
            page = min(options['page'], max(1,pages))
            start = (page-1)*options['pageSize']
            return {'actor':public,'scope':SCOPE,'items':[item for _,item in rows[start:start+options['pageSize']]],
                'stats':stats,'total':total,'page':page,'pageSize':options['pageSize'],'pages':pages}

    def acquisition_summary(self, user, store_id, task_id, *, platform=None):
        """Current customer projections for people touched by one visible task.

        An analyzed comment requires the exact current, persisted assessment;
        provisional unknowns, changed sources and expired results do not count.
        """
        if not isinstance(task_id,str) or len(task_id)>180:
            _fail('INVALID_INPUT','采集任务编号无效')
        empty = {'recent':[],'summary':{'newCustomers':0,'analyzedCustomers':0,'highIntent':0,'replied':0},'analyzed':0}
        with self.core.lock:
            actor,_ = self._actor(user,store_id)
            if not task_id:
                return empty
            options={'sort':'time'}
            if platform is not None:options['platform']=platform
            rows,_ = self._matching(actor,store_id,self._options(options))
            visible = [(person,item) for person,item in rows if any(
                (comment.get('lead') or {}).get('task_id')==task_id
                for comment in person.get('comments') or [])]
            if not visible:
                return empty
            saved = {}
            for record in self.core.store.list('rental_assessments_v1',self.tenant):
                assessment = record.get('assessment')
                if (record.get('tenant_id')!=self.tenant or record.get('owner')!=actor['username']
                        or record.get('task_id')!=task_id or not isinstance(assessment,dict)
                        or not record.get('rule_version') or not record.get('source_digest')
                        or assessment.get('rule_version')!=record.get('rule_version')
                        or assessment.get('source_digest')!=record.get('source_digest')):
                    continue
                key = (record.get('lead_id'),record['rule_version'],record['source_digest'])
                saved.setdefault(key,[]).append(assessment)
            analyzed = set()
            rule_analyzed = set()
            for person,_ in visible:
                for comment in person.get('comments') or []:
                    if (comment.get('lead') or {}).get('task_id')!=task_id:
                        continue
                    persisted=(comment.get('lead') or {}).get('manual_intent') or (comment.get('lead') or {}).get('ai_intent')
                    if isinstance(persisted,dict) and persisted.get('status') in ('graded','uncertain','unrelated'):
                        analyzed.add(comment['lead_id'])
                    current = person.get('_rental_assessments',{}).get(comment['lead_id'])
                    if not isinstance(current,dict):
                        continue
                    key = (comment['lead_id'],current.get('rule_version'),current.get('source_digest'))
                    # The host adds provenance to the read projection. Compare
                    # the persisted judgment itself, retaining every semantic
                    # field and the exact source/rule identity above.
                    judgment={name:value for name,value in current.items() if name not in
                        ('contract_digest','rule_source_digest','bundle_revision','calibrated')}
                    if any(judgment==assessment for assessment in saved.get(key,[])):
                        rule_analyzed.add(comment['lead_id'])
            return {'recent':[{'id':item['id'],'name':item['name'],'copy':item['need'],'avatarUrl':item['avatarUrl'],
                'level':item['level']} for _,item in [pair for pair in visible if self._is_prospect(pair[1])][:3]],
                'summary':{'newCustomers':sum((min(person.get('comments') or [],key=lambda c:_epoch(c.get('created_at') or (c.get('lead') or {}).get('created_at'))).get('lead') or {}).get('task_id')==task_id for person,_ in visible if person.get('comments')),
                    'analyzedCustomers':sum(any(c['lead_id'] in analyzed for c in person.get('comments',[])) for person,_ in visible),'highIntent':sum(item['rank'] is not None and item['rank']>=2
                    for _,item in visible),'replied':sum(item['replied'] for _,item in visible)},
                'analyzed':len(analyzed),'ruleAnalyzed':len(rule_analyzed)}

    def _analysis_rule_notice(self, actor, store_id, person):
        # This detail-only projection reads the selected judgment's own task.
        # It never scans the task list, changes a grade, or dispatches analysis.
        representative = next((comment for comment in person.get('comments') or []
            if comment.get('lead_id') == person.get('representative_intent_lead_id')), None)
        lead = (representative or {}).get('lead') or {}
        recorded = lead.get('manual_intent') or lead.get('ai_intent')
        if not isinstance(recorded, dict) or recorded.get('status') not in ('graded','uncertain','unrelated'):
            return {'kind':'no_saved_result', 'label':'尚未保存分析判断',
                'notice':'租期等线索不代表 AI 已完成分析。'}
        if recorded is lead.get('manual_intent'):
            return {'kind':'manual', 'label':'当前采用人工判断',
                'notice':'保留已保存的人工复核结果。'}
        unavailable = {'kind':'unavailable', 'label':'规则版本暂未核对',
            'notice':'来源信息不足，原判断保持。'}
        if not lead.get('task_id'):
            return unavailable
        try:
            task = self.core._get('tasks', lead['task_id'], self.tenant)
            self.core._task_access(actor, task, self.tenant)
        except CoreError:
            return unavailable
        if task.get('store_id') != store_id:
            return unavailable
        from core.intent_policy import task_analysis_prompt_state
        status = task_analysis_prompt_state(task, recorded)['status']
        if status == 'not_applicable':
            return None
        labels = {
            'unrecorded':('AI 规则版本未记录','历史记录缺少本地规则版本，原判断保持。'),
            'different':('AI 规则与当前版本不同','已保存的规则版本有变化，原判断保持。'),
            'current':('已记录当前本地规则','版本记录已核对，云端执行效果仍需复核。'),
        }
        if status not in labels:
            return unavailable
        label, notice = labels[status]
        return {'kind':status, 'label':label, 'notice':notice}

    def detail_context(self, user, store_id, ident, *, platform=None):
        if not isinstance(ident,str) or not KEY.fullmatch(ident):
            _fail('INVALID_INPUT','客户编号无效')
        if platform is not None:
            self.platform_filter({'platform':platform})
        with self.core.lock:
            actor, public = self._actor(user,store_id)
            try:
                person = self._history(actor,store_id,platform).customer_detail(ident,actor)
            except CoreError:
                _fail('CUSTOMER_UNAVAILABLE','客户不存在或不在当前可见范围',404)
            self._with_rental_assessment(person,actor,store_id)
            item=self._project(person,detail=True,store_id=store_id)
            item['sourceHistory']=self._source_history(actor,store_id,person)
            item['analysisRuleNotice']=self._analysis_rule_notice(actor,store_id,person)
            records=self._handoff_records(actor,store_id,ident)
            self._handoff_summary(item,records[0] if records else None)
            return actor,public,item,person

    def _source_history(self,user,store_id,person):
        """Selected-customer read only; never added to the list's row loop."""
        empty={'items':[],'taskCount':0,'rediscoveredComments':0,'hasConflict':False,'available':True}
        reader=getattr(self.core.store,'read_customer_source_history',None)
        if not callable(reader):return {**empty,'available':False}
        ids=list(dict.fromkeys(c['lead_id'] for c in person.get('comments',[]) if c.get('lead_id')))
        try:
            rows=reader(tenant_id=self.tenant,owner=user['username'],store_id=store_id,lead_ids=ids)
        except (ValueError,OSError):
            return {**empty,'available':False}
        groups={};rediscovered=set()
        for row in rows:
            key=(row['task_id'],row['account_id'],row['platform'])
            relation=row['relation']
            group=groups.setdefault(key,{'taskId':row['task_id'],'accountId':row['account_id'],
                'taskName':_text(row.get('task_name'),120),
                'accountNickname':_text(row.get('account_nickname'),100) or '账号昵称未记录',
                'platform':row['platform'],'firstSeenAt':'','lastSeenAt':'','hasConflict':False,
                'relation':'original','_leads':set(),'_first':[],'_last':[]})
            group['_leads'].add(row['lead_id'])
            group['hasConflict']=group['hasConflict'] or row['has_conflict']
            if relation=='rediscovered':group['relation']='rediscovered';rediscovered.add(row['lead_id'])
            for source,target in (('first_seen_at','_first'),('last_seen_at','_last')):
                value=_text(row.get(source),80)
                if value and _epoch(value):group[target].append(value)
        items=[]
        for group in groups.values():
            if not group['taskName']:
                group['taskName']='原采集任务' if group['relation']=='original' else '再次采集任务'
            group['commentCount']=len(group.pop('_leads'))
            first,last=group.pop('_first'),group.pop('_last')
            group['firstSeenAt']=min(first,key=_epoch) if first else ''
            group['lastSeenAt']=max(last,key=_epoch) if last else ''
            items.append(group)
        items.sort(key=lambda row:_epoch(row['lastSeenAt']),reverse=True)
        return {**empty,'items':items,'taskCount':len(items),'rediscoveredComments':len(rediscovered),
            'hasConflict':any(row['hasConflict'] for row in items)}

    def detail(self, user, store_id, ident, *, platform=None):
        _actor,public,item,_person=self.detail_context(user,store_id,ident,platform=platform)
        return {'actor':public,'scope':SCOPE,'id':ident,'item':item}

    def _handoff_records(self,user,store_id,ident=None):
        if user.get('role') != 'admin':
            return []
        records=[r for r in self.core.store.list(HANDOFF_ENTITY,self.tenant)
            if r.get('tenant_id')==self.tenant and r.get('owner')==user['username']
            and r.get('userId')==user['id'] and r.get('storeId')==store_id
            and (ident is None or r.get('customerId')==ident)]
        return sorted(records,key=lambda r:r['version'],reverse=True)

    @staticmethod
    def _handoff_summary(item,latest):
        item['handoff']={'prepared':bool(latest),'version':latest['version'] if latest else 0,
            'updatedAt':latest['createdAt'] if latest else '', 'author':latest['author'] if latest else ''}
        if latest:item['nextStep']=latest['nextStep'] or '已整理内部交接，查看交接记录'

    def handoff(self,user,store_id,data,*,save=False):
        fields={'storeId','id','expectedVersion','sourceDigest','note','nextStep','requestId'} if save else {'storeId','id'}
        if (not isinstance(data,dict) or (set(data)!=fields and not (
                not save and set(data)==fields|{'requestId'})) or data.get('storeId')!=store_id
                or not isinstance(data.get('id'),str) or not KEY.fullmatch(data['id'])):
            _fail('INPUT_INVALID','客户交接参数无效')
        request=data.get('requestId')
        if (save or request is not None) and (not isinstance(request,str) or not REQUEST.fullmatch(request)):
            _fail('INPUT_INVALID','交接操作编号无效')
        if save:
            if (type(data['expectedVersion']) is not int or data['expectedVersion']<0
                    or not isinstance(data['sourceDigest'],str) or not KEY.fullmatch(data['sourceDigest'])
                    or any(not isinstance(data[k],str) or len(data[k])>limit or '\x00' in data[k]
                        for k,limit in (('note',4000),('nextStep',1000)))
                    or not (data['note'].strip() or data['nextStep'].strip())):
                _fail('INPUT_INVALID','请填写内部备注或下一步；备注最多4000字，下一步最多1000字')
        with self.core.lock:
            # Reuse the exact visible customer boundary before consulting any
            # request receipt; guessed customer/request ids reveal nothing.
            actor,public=self._actor(user,store_id)
            if actor.get('role') != 'admin':
                _fail('MEMO_ADMIN_REQUIRED','客户备忘仅限管理员本人使用',403)
            current=self.detail(user,store_id,data['id'])
            actor,public=self._actor(user,store_id)
            person=self._history(actor,store_id).customer_detail(data['id'],actor)
            # Snapshot the current original projection, independently of a
            # prior handoff's internal nextStep shown in customer detail.
            self._with_rental_assessment(person,actor,store_id)
            item=self._project(person,detail=True,store_id=store_id)
            source_digest=_digest({'item':item,'sources':[c.get('lead') for c in person.get('comments') or []]})
            records=self._handoff_records(actor,store_id,data['id'])
            receipt=None
            request_key=_digest([self.tenant,actor['id'],store_id,request]) if request is not None else None
            prior=self.core.store.get(HANDOFF_ENTITY,request_key) if request_key else None
            if prior and (prior.get('tenant_id')!=self.tenant or prior.get('owner')!=actor['username'] or prior.get('userId')!=actor['id']
                    or prior.get('storeId')!=store_id or prior.get('customerId')!=data['id']):
                _fail('HANDOFF_REQUEST_CONFLICT','同一交接操作编号已用于其他客户',409)
            if save:
                signature=_digest(data)
                if prior:
                    if prior['signature']!=signature:_fail('HANDOFF_REQUEST_CONFLICT','同一交接操作编号的内容已变化',409)
                else:
                    version=records[0]['version'] if records else 0
                    if data['expectedVersion']!=version:
                        _fail('HANDOFF_VERSION_CONFLICT','交接记录已由另一窗口更新；请保留输入并读取当前版本',409)
                    if data['sourceDigest']!=source_digest:
                        _fail('HANDOFF_SOURCE_CHANGED','客户需求或来源已变化；请保留输入并重新核对',409)
                    prior={'id':request_key,'tenant_id':self.tenant,'owner':actor['username'],'userId':actor['id'],
                        'storeId':store_id,'customerId':data['id'],'version':version+1,'author':actor['username'],
                        'createdAt':datetime.now(timezone.utc).isoformat(),'snapshot':item,'sourceDigest':source_digest,
                        'storeContext':{'id':store_id,'meaning':'整理时当前门店；历史来源门店未核实'},
                        'note':data['note'],'nextStep':data['nextStep'],'requestId':request,'signature':signature}
                    try:
                        # One append is also its immutable request receipt. The
                        # original store transaction commits both or neither.
                        self.core.store.put(HANDOFF_ENTITY,prior)
                    except Exception:
                        _fail('HANDOFF_RESULT_UNCONFIRMED','交接保存结果待核对；请保留输入并查询原操作，不要重复保存',503)
                    records=[prior,*records]
            if request is not None:
                receipt={'requestId':request,'state':'accepted' if prior else 'not_found',
                    'version':prior['version'] if prior else None}
            def safe(record):
                return {k:deepcopy(record[k]) for k in ('version','author','createdAt','snapshot','sourceDigest',
                    'storeContext','note','nextStep','requestId')}
            return {'actor':public,'id':data['id'],'scope':SCOPE,'snapshot':item,'sourceDigest':source_digest,
                'storeContext':{'id':store_id,'meaning':'整理时当前门店；历史来源门店未核实'},
                'version':records[0]['version'] if records else 0,'latest':safe(records[0]) if records else None,
                'history':[safe(r) for r in records],'receipt':receipt}

    def memo_export(self, user, store_id, data):
        """One already visible customer and this administrator's saved memo."""
        if (not isinstance(data,dict) or set(data)-{'storeId','id','platform'}
                or not {'storeId','id'}.issubset(data) or data['storeId']!=store_id):
            _fail('INPUT_INVALID','客户备忘导出参数无效')
        platform=self.platform_filter(data)
        def permitted():
            actor,public=self._actor(user,store_id)
            if actor.get('role')!='admin':
                _fail('MEMO_ADMIN_REQUIRED','客户备忘仅限管理员本人使用',403)
            if user.get('can_export') is False or actor.get('can_export') is False:
                _fail('EXPORT_FORBIDDEN','当前账号没有导出权限',403)
            try:require_feature(self.company,'export')
            except ProductAccessError as error:_fail('EXPORT_FORBIDDEN',str(error),403)
            return actor,public
        with self.core.lock:
            actor,public=permitted()
            detail=self.detail(actor,store_id,data['id'],platform=platform)
            request={'storeId':store_id,'id':data['id']}
            current=self.handoff(actor,store_id,request)
            latest=current['latest']
            if not latest:
                _fail('MEMO_REQUIRED','请先保存这位客户的本人备忘',409)
            if latest['sourceDigest']!=current['sourceDigest']:
                _fail('MEMO_SOURCE_CHANGED','客户原话已变化，请读取当前客户并保存最新备忘',409)
            item=detail['item']
            def human_time(value):
                stamp=_epoch(value)
                return datetime.fromtimestamp(stamp,timezone(timedelta(hours=8))).strftime('%Y-%m-%d %H:%M') if stamp else '未提供'
            def field(label,value):
                return '<dt>'+html.escape(label)+'</dt><dd>'+html.escape(str(value or '未填写'))+'</dd>'
            comments=''.join('<article><h3>'+html.escape(c.get('postTitle') or '原帖标题未提供')+
                '</h3><p>'+html.escape(c.get('text') or '原话未提供')+'</p><small>'+human_time(c.get('publishedAt'))+
                '</small></article>' for c in item.get('comments') or [])
            body=('<!doctype html><html lang="zh-CN"><meta charset="utf-8">'
                '<meta name="viewport" content="width=device-width,initial-scale=1">'
                '<meta http-equiv="Content-Security-Policy" content="default-src \'none\'; style-src \'unsafe-inline\'">'
                '<title>客户简报</title><style>body{max-width:780px;margin:40px auto;padding:0 24px;'
                'font:16px/1.7 system-ui;color:#243435}dt,h2{font-weight:600}dd{margin:0 0 16px;'
                'white-space:pre-wrap}article{border-top:1px solid #ddd}p{white-space:pre-wrap}</style>'
                '<h1>客户简报</h1><dl>'+field('客户昵称',item['name'])+
                field('来源平台',item['channel'])+field('当前意向',item['level'])+
                field('联系情况',item['contactLabel'])+'</dl><h2>客户原话</h2>'+comments+
                '<h2>本人备忘</h2><dl>'+field('备注',latest['note'])+
                field('下一步',latest['nextStep'])+field('保存时间',human_time(latest['createdAt']))+
                '</dl></html>')
            permitted()
            after=self.handoff(actor,store_id,request)
            if (after['sourceDigest']!=current['sourceDigest']
                    or after['latest']!=latest):
                _fail('MEMO_EXPORT_CHANGED','客户或备忘已变化，本次未生成文件，请重新读取',409)
            return {'actor':public,'scope':SCOPE,'filename':'客户简报.html',
                'contentType':'text/html; charset=utf-8','rowCount':1,
                'dataBase64':base64.b64encode(body.encode('utf-8')).decode('ascii')}

    def export(self, user, store_id, data):
        options = self._options(data,export=True)
        selected = data.get('selectedIds')
        if selected is not None and (not isinstance(selected,list) or not 1<=len(selected)<=3000
                or any(not isinstance(value,str) or not KEY.fullmatch(value) for value in selected)
                or len(set(selected))!=len(selected)):
            _fail('INVALID_INPUT','请选择至多3000个不重复的客户编号')
        with self.core.lock:
            actor, public = self._actor(user,store_id)
            if user.get('can_export') is False or actor.get('can_export') is False:
                _fail('EXPORT_FORBIDDEN','当前员工没有导出权限',403)
            try:
                require_feature(self.company,'export')
            except ProductAccessError as error:
                _fail('EXPORT_FORBIDDEN',str(error),403)
            rows, _ = self._matching(actor,store_id,options)
            if selected is not None:
                selected_set = set(selected)
                rows = [pair for pair in rows if pair[1]['id'] in selected_set]
                if len(rows)!=len(selected_set):
                    _fail('EXPORT_SCOPE_CHANGED','所选客户已失权或不再符合筛选，本次未生成文件',409)
            if len(rows)>3000:
                _fail('EXPORT_LIMIT','当前筛选超过3000位客户，请缩小范围后导出',409)
            content = self._xlsx([self._export_item(person,item) for person,item in rows])
            return {'actor':public,'scope':SCOPE,'filename':'方隅客户清单.xlsx',
                'contentType':'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                'rowCount':len(rows),'dataBase64':base64.b64encode(content).decode('ascii')}

    def _export_item(self, person, display):
        """Export complete stored strings, independently of UI display limits."""
        intent, quote, post_title, post_url = self._representative_source(person)
        facts = intent.get('key_info') if isinstance(intent.get('key_info'),list) else []
        need = ' · '.join(fact['value'] for fact in facts if isinstance(fact,dict)
            and fact.get('type') in ('budget','move_in','commute','room_type','location')
            and isinstance(fact.get('value'),str) and fact['value'].strip())
        evidence = [value for value in intent.get('evidence',[]) if isinstance(value,str) and value.strip()] \
            if isinstance(intent.get('evidence'),list) else []
        reason = intent.get('reason')
        if isinstance(reason,str) and reason and reason not in evidence:
            evidence.insert(0,reason)
        assessment = person.get('_rental_assessment')
        if assessment is not None and display.get('intentSource') not in ('manual','ai'):
            # Match the visible current judgment: an already recorded manual/AI
            # result keeps its own evidence instead of a newer rule's readiness.
            # Translate readiness only at this human-facing export boundary;
            # stored state, original quotes and machine responses stay intact.
            reason_labels = {
                'requires_engine_update':'当前规则尚未完成这条来源的判断，需要升级软件或重新核对规则；不能据此认定已完成判断。',
                'historical_contract_unverified':'这条历史记录所用的判断规则尚未核实，暂不能作为当前判断依据。',
            }
            reason = assessment.get('reason')
            public_assessment = {**assessment,
                'reason':reason_labels.get(reason,reason) if isinstance(reason,str) else reason}
            evidence = self._rental_evidence(public_assessment)
            need = ''
        return {**display,'name':person.get('nickname') or '昵称未提供',
            'postTitle':post_title,'postUrl':post_url,
            'need':need or '需求信息尚未整理',
            'quote':quote,
            'evidence':evidence,
            'intentRuleVersion':assessment.get('rule_version') or '' if assessment is not None else '',
            'legacyIntentLabel':self._legacy_summary(person)['label'],
            **self._financial_fields(assessment,full=True)}

    def _xlsx(self, items):
        writer = importlib.import_module('xlsxwriter')
        if (writer.__version__!='3.2.9'
                or Path(writer.__file__).resolve()!=(self.source/'xlsxwriter/__init__.py').resolve()):
            _fail('CUSTOMER_DEPENDENCY','本机Excel组件来源或版本需核对',503)
        columns = [('name','客户昵称'),('need','已保存需求'),('level','当前意向'),
            ('contactLabel','联系记录'),('contactAt','最近联系时间'),('channel','平台'),
            ('postTitle','原帖标题'),('postUrl','原帖链接'),('quote','原评论'),('evidence','当前判断依据'),
            ('budgetRawQuote','预算原话'),('budgetBasis','预算怎么算'),
            ('incomeRawQuote','收入自报原话'),('incomeBasis','收入怎么算'),
            ('legacyIntentLabel','历史意向 仅供参考')]
        cells = []
        for item in items:
            item = {**item,'budgetRawQuote':item['budget'].get('raw_quote') or '',
                'incomeRawQuote':(item['incomeSelfReport'] or {}).get('raw_quote') or ''}
            # Only presentation values change. Internal IDs still govern
            # scope, selection and matching; they never become export columns.
            raw_time = item.get('contactAt')
            if isinstance(raw_time,str) and raw_time:
                try:
                    from datetime import datetime, timezone, timedelta
                    parsed = datetime.fromisoformat(raw_time.replace('Z','+00:00'))
                    item['contactAt'] = (parsed.astimezone(timezone(timedelta(hours=8))).strftime('%Y-%m-%d %H:%M')
                        if parsed.tzinfo else raw_time+'（时区未注明）')
                except ValueError:
                    item['contactAt'] = raw_time+'（时间待确认）'
            for basis in ('budgetBasis','incomeBasis'):
                value = str(item.get(basis) or '')
                for code,label in (('CNY','人民币'),('RMB','人民币'),('USD','美元'),('EUR','欧元'),('HKD','港币'),('JPY','日元'),('GBP','英镑')):
                    value = value.replace(code,label)
                item[basis] = value
            item['channel'] = {'xiaohongshu':'小红书','douyin':'抖音','weibo':'微博'}.get(item.get('channel'),item.get('channel',''))
            row = []
            for field,_ in columns:
                value = '\n'.join(item[field]) if isinstance(item[field],list) else str(item[field])
                if len(value)>32767:
                    _fail('EXPORT_CELL_LIMIT','原评论或已保存字段超过Excel单元格上限，本次未生成文件，请缩小或核对范围',409)
                try:
                    value.encode('utf-8')
                except UnicodeError:
                    _fail('EXPORT_ENCODING','原保存字段包含不可编码内容，本次未生成文件',409)
                row.append(value)
            cells.append(row)
        stream = io.BytesIO()
        workbook = writer.Workbook(stream, {'in_memory':True,'strings_to_formulas':False,
            'strings_to_urls':False,'strings_to_numbers':False})
        sheet = workbook.add_worksheet('客户清单')
        header = workbook.add_format({'bold':True,'text_wrap':True})
        body = workbook.add_format({'text_wrap':True,'valign':'top'})
        for column,(_,label) in enumerate(columns):
            sheet.write_string(0,column,label,header)
        for row,values in enumerate(cells,1):
            for column,value in enumerate(values):
                if sheet.write_string(row,column,value,body)!=0:
                    workbook.close()
                    _fail('EXPORT_ENCODING','Excel字段未能完整写入，本次未生成文件',409)
        sheet.freeze_panes(1,2)
        sheet.set_column(0,len(columns)-1,24)
        if items: sheet.autofilter(0,0,len(items),len(columns)-1)
        notice = workbook.add_worksheet('范围说明')
        notice.set_column(0,0,100)
        notice.write_string(0,0,'本清单按当前员工的查看权限和筛选条件整理。部分历史记录所属门店还需确认。')
        notice.write_string(1,0,'联系结果尚未确认的记录，不算已回复。')
        notice.write_string(2,0,'本清单供跟进参考，不代表已经联系成功、成交或收款。')
        workbook.close()
        return stream.getvalue()
