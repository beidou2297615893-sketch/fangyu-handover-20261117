"""Reuses the mature ordinary F82 PyInstaller spec. Own probe, no installer."""
from pathlib import Path
import os, shutil, subprocess, json, hashlib, sys
W=Path(__file__).resolve().parent;P=W.parents[2];B=W/(sys.argv[1] if len(sys.argv)>1 else 'compiled-probe')
A=W.parent/'f82-standard-package-candidate/standard-held-clean-v82'
spec=(A/'FangyuWorkbench.spec').read_text('utf-8')
old=str(A/'standard_entry.py').replace('\\','/');new=str(B/'probe_entry.py').replace('\\','/')
assert spec.count(old)==1
(B/'FangyuWorkbench.spec').write_text(spec.replace(old,new).replace('console=False','console=True'),'utf-8')
env={k:v for k,v in os.environ.items() if k not in ('PYTHONHOME','PYTHONPATH','VIRTUAL_ENV')}
for key,name in [('PYINSTALLER_CONFIG_DIR','build-cache'),('TEMP','temp'),('TMP','temp'),('LOCALAPPDATA','build-localappdata'),('APPDATA','build-appdata')]:
    folder=B/name;folder.mkdir(exist_ok=True);env[key]=str(folder)
env.update(PYTHONDONTWRITEBYTECODE='1',PYTHONIOENCODING='utf-8')
with (B/'BUILD.log').open('x',encoding='utf-8') as log:
    result=subprocess.run([str(P/'work/desktop-python/Scripts/python.exe'),'-I','-B','-m','PyInstaller',
        '--noconfirm','--clean','--distpath',str(B/'dist'),'--workpath',str(B/'pyinstaller'),str(B/'FangyuWorkbench.spec')],
        cwd=B,env=env,stdout=log,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW,timeout=600)
assert result.returncode==0,'See own BUILD.log'
shutil.copytree(B/'payload/project',B/'dist/FangyuWorkbench/project')
shutil.copytree(B/'payload/qa-fixtures',B/'dist/FangyuWorkbench/qa-fixtures')
exe=B/'dist/FangyuWorkbench/FangyuWorkbench.exe'
(B/'BUILD-RECEIPT.json').write_text(json.dumps({'compiled':True,'entry_sha256':hashlib.sha256((B/'probe_entry.py').read_bytes()).hexdigest(),
    'exe_sha256':hashlib.sha256(exe.read_bytes()).hexdigest(),'runtime_spec':'Original mature F82 standard spec; only own entry path and console mode changed',
    'nativeWindowOpened':False,'productOrInstalledWrites':False},indent=2),'utf-8')
print(str(exe))
