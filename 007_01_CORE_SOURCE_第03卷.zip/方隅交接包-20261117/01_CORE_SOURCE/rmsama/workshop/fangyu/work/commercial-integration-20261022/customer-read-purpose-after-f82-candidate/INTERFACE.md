# 共享受信 host 接口

本候选独占5个原源：work/ui-native-r57/ui_native_host.py、work/shared-backend-integration/platform_runtime.py、该目录 vendor-src/app.py、vendor-src/assistant/douyin_connection_service.py、work/ui-runtime-r55/src/core/douyin_comments_policy.py。新共享模块为 resources/platform-runtime/customer_read_distribution.py（制作源在 work/shared-backend-integration/customer_read_distribution.py）。不修改 work/app 镜像、原 internal review 或正式/已冻结包。

受信 host 在原 verify_backend_dependencies/read_public 后读取 resources/customer-read/review-index.json、其引用的各独立文档。无 index 时不创建载体，原 held scope=None。索引与 loader 均须列入原 release manifest；浏览器/HTTP/company JSON 不可选择它们。载体仅 frozen、准确实际 exe/project/release 根和原企业配置生效。

索引固定字段：schema=fangyu_customer_read_material_index_v1、scope=customer_distribution_read、company_binding（非员工凭据的固定企业/环境/平台/hold）、executable、reviews=[{purpose,path,sha256,bytes}]。材料路径相对受信根，禁止链接、路径穿越和不同运行根复用。

PlatformRuntime(..., customer_read_authority=None) → 原 AppServer(..., customer_read_authority=None) 为仅 Python host 的 keyword-only 参数。AppServer._runtime_license_usage_scope 在载体存在时仅返回其严格绑定的 customer scope 或 None；不会回退 internal。原员工、设备、账号、锁与发送守卫不由此参数产生或取代。

抖音：authority.resolve(server, 'douyin_owned_connection' | 'douyin_owned_video_comments') 返回 None 或 {purpose,scope,revision}；原 _components / CommentsPolicy 在验证原 Bridge/账号 overlay/固定命令后分别消费。每 purpose 单独材料与保留 limits。搜索、DM、live 不消费这两个目的。

XHS 后继固定接口：authority.runtime_license_review(server, 'xiaohongshu_guarded_read') 返回 None 或 **原 RuntimeLicensePolicy 完整 schema review 字典**，不包装成另一种许可策略、不生成批准结论。原 AppServer 在其构造函数创建 RuntimeLicensePolicy 前读取该结果，仍调用原 RuntimeLicensePolicy 校验。material_root 严格沿原 frozen 合同 **Path(sys.executable).resolve().parent**；材料路径应相对该根（通常 project/...），不能指向开发机绝对目录。返回 review 的 company_id 与 scope 必须和载体匹配，route 仍 guarded_cli_v1；真实 wrapper/exe/tree/guard 与四份材料由原 policy 独立验证。

索引可包含该 XHS 文档，但仅当后继真实材料形成后由受信 host 固定绑定。当前抖音候选不附 XHS review，不改 XHS 原工件、runtime validator、natural identity/session/read 或其分发限制。Native、平台与真实云端注册另列验收，不能把 scope 或组件 resolve 成功写成执行成功。

主工作台EXE由外层包/seal固定，其原compiled入口固定SHIPPED/RELEASE再固定index。index不反嵌主EXE SHA，避免EXE→closure→index→EXE自引用；原RuntimeLicensePolicy对独立CLI artifact的exe/tree校验保持。

源码 N/run_workbench.py：host 仅在实际 sys.frozen 为真时创建分发 carrier；源码包即使带同一 index 也忽略其分发描述，沿原 internal 合同启动。源码被误传/伪造 carrier 仍拒绝。两例分开验收。
