import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath,pathToFileURL} from 'node:url';
import {parseHTML} from '../content-workflow-ui/node_modules/linkedom/esm/index.js';
const W=path.dirname(fileURLToPath(import.meta.url));
const U='C:/积木软件工坊/项目/方隅公寓客户版/work/parallel-integration-20261018/final-integration/stage-02/project/work/ui-approved-implementation/ui-preview';
const {renderWorkflow,bindWorkflow}=await import(pathToFileURL(U+'/pages/content-workflow.mjs'));
const {document}=parseHTML('<html><body><main></main></body></html>');globalThis.document=document;globalThis.localStorage={getItem:()=>null,setItem(){},removeItem(){}};
const root=document.querySelector('main');let cleanup=()=>{};const results=[];
function workspace(){return {actor:{username:'synthetic',storeId:'gubei',platform:'xiaohongshu',accountId:'account-a'},revision:1,capabilities:{generationStatus:'service_not_checked'},workflowContract:'fangyu-content-workflow-v1',workflowCapabilities:{canRunTasks:false,canReconcileTasks:false},workflow:{schemaVersion:1,tasks:[{id:'prepared-a',methodId:'writing',state:'prepared',query:'虚构主题',evidenceIds:[],artifactIds:[],input:{evidence:[]}}],artifacts:[],documents:[{id:'document-a',title:'已有资料',text:'已保存的合成资料'}]},drafts:[{id:'draft-a',title:'已有草稿',body:'旧正文'}],topics:[]};}
function setup(mode='available',open=false){cleanup();const s={authEpoch:1,user:'synthetic',session:{user:{username:'synthetic'}},storeId:'gubei',activePlatform:'xiaohongshu',contentWorkspace:workspace()};const u={accountId:'account-a',tab:'creation',forms:{draft:{title:'未保存标题',body:'未保存正文'},topic:{}},dirty:{draft:true}};s.contentOperationsUI=u;let calls=[],release,behavior=mode;
const result=()=>{const w=structuredClone(s.contentWorkspace);w.workflowCapabilities={canRunTasks:behavior!=='unavailable',canReconcileTasks:behavior!=='unavailable'};return {workspace:w,result:{contract:behavior==='invalid'?'invalid-contract':'fangyu-content-workflow-v1',methods:[{id:'writing',title:'虚构图文方法'}]}}};
const ctx={state:s,update:fn=>{fn();paint()},toast(){},contentAction:async(action,data)=>{calls.push({action,data:structuredClone(data)});assert.equal(action,'content_methods_read');assert.deepEqual(data,{storeId:'gubei',accountId:'account-a',platform:'xiaohongshu'});if(behavior==='failure')throw Error('生成服务暂时无法连接，本地资料仍保留');if(behavior==='delay')return await new Promise(r=>release=r);return result();}};
function paint(){cleanup();root.innerHTML=renderWorkflow(s,u,s.contentWorkspace);cleanup=bindWorkflow(root,ctx,u);}
renderWorkflow(s,u,s.contentWorkspace);Object.assign(u.workflowUI,{open,mode:'task',taskId:'prepared-a',methodsLoaded:true,documents:{title:'正在写资料',text:'未保存资料',kind:'fact',sourceLabel:''},query:'未保存任务主题'});paint();return {s,u,ctx,calls,paint,result,release:r=>release?.(r),set mode(v){behavior=v}};}
const select='[data-wf-action="check-service"]';async function settle(){for(let i=0;i<8;i++)await new Promise(r=>setTimeout(r,0));}
{
 const h=setup('available',true);assert.equal(root.querySelector('[data-wf-action="run"]').disabled,true);assert.equal(h.calls.length,0);const b=root.querySelector(select);b.click();b.click();await settle();assert.equal(h.calls.length,1);assert.equal(h.s.contentWorkspace.workflowCapabilities.canRunTasks,true);assert.equal(root.querySelector('[data-wf-action="run"]').disabled,false);assert.equal(h.u.workflowUI.specs[0].id,'writing');assert.match(root.textContent,/执行任务仍需单独确认/);assert.equal(h.u.forms.draft.body,'未保存正文');assert.equal(h.u.dirty.draft,true);results.push('false capability -> explicit methods read -> true and run enabled; double click one read, no generation, unsaved editor preserved');
}
{
 const h=setup('failure');const before=structuredClone(h.s.contentWorkspace);root.querySelector(select).click();await settle();assert.deepEqual(h.s.contentWorkspace,before);assert.equal(h.u.workflowUI.documents.text,'未保存资料');assert.equal(h.u.workflowUI.query,'未保存任务主题');assert.equal(h.u.forms.draft.body,'未保存正文');assert.equal(h.calls.length,1);assert.match(root.textContent,/本地资料仍保留/);h.paint();await settle();assert.equal(h.calls.length,1);h.mode='available';root.querySelector(select).click();await settle();assert.equal(h.calls.length,2);assert.equal(h.s.contentWorkspace.workflowCapabilities.canRunTasks,true);results.push('Failed service read retains saved/unsaved local data, does not poll automatically, explicit retry recovers');
}
{
 const h=setup('delay');root.querySelector(select).click();assert.equal(h.calls.length,1);const old=h.result();h.s.authEpoch++;h.s.storeId='other-store';h.u.accountId='account-b';h.s.contentWorkspace={...workspace(),revision:22,actor:{username:'synthetic',storeId:'other-store',platform:'xiaohongshu',accountId:'account-b'}};h.paint();h.release(old);await settle();assert.equal(h.s.contentWorkspace.revision,22);assert.equal(h.s.contentWorkspace.workflowCapabilities.canRunTasks,false);assert.equal(h.u.workflowUI.specs.length,0);results.push('Late availability response after scope/epoch switch cannot enable another account or replace its methods');
}
{
 const h=setup('unavailable');root.querySelector(select).click();await settle();assert.equal(h.s.contentWorkspace.workflowCapabilities.canRunTasks,false);assert.match(root.textContent,/生成服务暂不可用，可继续保存资料与编辑草稿/);assert.equal(h.calls.length,1);results.push('Valid but disabled service accurately remains unavailable with local editing explanation');
}
{
 const h=setup('invalid');const before=structuredClone(h.s.contentWorkspace);root.querySelector(select).click();await settle();assert.deepEqual(h.s.contentWorkspace,before);assert.match(root.textContent,/方法状态尚未核对/);assert.equal(h.u.workflowUI.localUnknown,null);assert.equal(h.calls.length,1);results.push('Invalid method contract is rejected before workspace adoption and never creates a mutation retry');
}
cleanup();fs.writeFileSync(W+'/RESULTS.json',JSON.stringify({passed:results.length,results,scope:'Production workflow UI module render/bind, Node DOM and synthetic methods-read response; no service/model/platform request or CUA visual claim.'},null,2));console.log(JSON.stringify({passed:results.length,results},null,2));
