from pathlib import Path
import hashlib,json,shutil
W=Path(__file__).resolve().parent
P=W.parents[2]
F=P/'work/parallel-integration-20261018/final-integration/candidate-unified-v77'
D=W.parent/'delivery-v77/FINAL-PINS.json'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(D)=='ee76c8c7de89bad321f871ee7f9f287a2f70eaf64b4c544a2a8b30006fc37b9c'
pins=json.loads(D.read_text('utf-8'))
assert sha(F/'UNIFIED-PINS.json')==pins['unifiedPinsSha256']
S=F/'project';target=W/'source-candidate'
assert not target.exists()
shutil.copytree(S,target)
shutil.copyfile(D,W/'BASE-FINAL-PINS.json')
files={p.relative_to(S).as_posix():{'sha256':sha(p),'bytes':p.stat().st_size,'crlf':p.read_bytes().count(b'\r\n')} for p in S.rglob('*') if p.is_file()}
(W/'BASE-HASHES.json').write_text(json.dumps({'base':'F77','rootPinsSha256':sha(D),'files':files},ensure_ascii=False,indent=2)+'\n','utf-8')
print(json.dumps({'copied':len(files),'bytes':sum(x['bytes'] for x in files.values()),'target':str(target)}))
