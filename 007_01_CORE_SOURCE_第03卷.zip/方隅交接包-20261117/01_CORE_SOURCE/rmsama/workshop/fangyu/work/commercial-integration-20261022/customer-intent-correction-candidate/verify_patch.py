"""Apply the minimal patch only to new owned source-only temporary folders."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,subprocess,tempfile
W=Path(__file__).resolve().parent
manifest=json.loads((W/'PATCH-MANIFEST.json').read_text('utf-8'))
S=Path(json.loads((W/'BASELINE.json').read_text('utf-8'))['source'])
def sha(raw):return hashlib.sha256(raw).hexdigest()
rows=[]
for current_native in (False,True):
    with tempfile.TemporaryDirectory(prefix='patch-review-',dir=W) as directory:
        target=Path(directory).resolve();assert target.is_relative_to(W)
        native='work/ui-native-r57/workbench_backend.py'
        root_native=(S/native).read_bytes() if current_native else None
        for row in manifest['files']:
            if row['change']=='modify':
                raw=root_native if current_native and row['path']==native else (W/'before'/row['path']).read_bytes()
                p=target/row['path'];p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw)
        env={**os.environ,'GIT_CEILING_DIRECTORIES':str(W)}
        commands=[]
        for options in (['--check'],[]):
            result=subprocess.run(['git','-c','core.autocrlf=false','apply',*options,str(W/'integration.patch')],cwd=target,env=env,
                                  capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=30)
            commands.append({'check':bool(options),'returncode':result.returncode,'stdout':result.stdout,'stderr':result.stderr})
            assert result.returncode==0,commands[-1]
        for row in manifest['files']:
            raw=(target/row['path']).read_bytes()
            if current_native and row['path']==native:
                # Root has four v3 content pins in this same file. Prove that
                # the candidate hunk preserves every independent root line.
                before=(W/'before'/native).read_text('utf-8').splitlines()
                current=root_native.decode('utf-8').splitlines()
                candidate=(W/'candidate'/native).read_text('utf-8')
                changed=[(a,b) for a,b in zip(before,current) if a!=b]
                assert len(before)==len(current) and len(changed)==4,changed
                for old,new in changed:
                    assert old in candidate
                    candidate=candidate.replace(old,new,1)
                assert raw.decode('utf-8').replace('\r\n','\n')==candidate
            else:assert sha(raw)==row['candidateSha256'],row['path']
        rows.append({'scenario':'current root Native v3 pins + saved v66 baseline' if current_native else 'saved v66 baseline',
                     'filesVerified':len(manifest['files']),'independentRootPinsPreserved':4 if current_native else 0,'commands':commands})
(W/'PATCH-APPLY-RESULT.json').write_text(json.dumps({'status':'PASS','checkedAt':datetime.now(timezone.utc).isoformat(),
    'patchSha256':manifest['patchSha256'],'scenarios':rows,'stageWrites':0,'productionReadsOrWrites':0},ensure_ascii=False,indent=2),'utf-8')
print(json.dumps({'status':'PASS','scenarios':len(rows),'filesPerScenario':len(manifest['files'])}))
