# F79 内容排程增量候选

仅合 overlay 清单 8 源：6 个现存文件小改与 2 个新模块。不要复制整份 source-candidate、旧 G11 文件或私有 QA release 到正式版本。真实 F79 是唯一 baseline，所有 before/after SHA 在 SOURCE-FILES.json。唯一实际冲突为 web backend 的长 return 行；仅向 F79 现有内容白名单插入六动作，移除这段即逐字恢复 F79。Native/backend 三方干净，账号删除 CAS、重新获客一行 passthrough、原账号模式/未知请求护栏全部保留。

可保存每项固定版本、账号身份、时刻和固定偏移时区；本人另行明确启用后，当前已登录 App 会话领取到期项，衔接原 publish_prepare/publish_confirm、approval、Store、模式租约。重复 tick 不重发；改稿/审核/账号身份/到期失效需重核；暂停、取消、恢复有逐项记录。原 unknown 只能核对原 intent/key，不更换请求。授权仅在 RAM，不保存 token；重开或选店变动后不能自动恢复授权。关闭 App 没有后台守护进程。原提醒仍清楚标注不执行发布。

本轮重跑原七场景与实际原 Native HTTP/完整 index/fit 的双宽 UI 13 检查；50/100 合成账号是原工厂离线压力，不证明平台吞吐或账号容量。另补 F79 原 Core CAS 删除自有合成账号后，到期 Native HTTP 在原 ACCOUNT_FORBIDDEN 前置门拒绝，Store/原计划/intent/key 不变、零派发。原 Native 删除入口未在此额外例中重测，F79 原删除业务/源码护栏未修改。该例首轮误预计内容组件错误码，完整红保留；新 v2 仅采用已证实更早的原 Native 错误码，零写/零派发断言不变，产品没改。

实际默认发布仍暂停：保存/启用/领取是排程状态，不能当成真实发布成功。正向例用原 OwnedPublishPort、原租约/观察器及明确合成授权和外部回执；自然企业/本人授权、实际平台 wire、验证码/登录、真实发布与平台容量仍未验。生产新内容生成服务原样，不调用模型、没有费用。

私有 QA stage 272 资源：相对正式 F79 274，新增两个模块、未拷原四个外部 runtime 许可文件。原 verify/read_public/依赖校验/create_backend 真实执行；此 QA 不称正式冻结或分发闭包。root 后续须正常完整 freeze。

800 个受保护 F79 文件逐字一致，Native cache/factory 与平台账号 dispatch/identity AST 一致。所有源码原换行保留，全部自有进程/服务关闭。S/F/N/outputs、本人会话、生产数据均未写，真实发布/平台/模型调用为零。
