---
name: xhs-reference-deconstructor
description: >-
  Deconstruct a Xiaohongshu reference post, screenshot, link, script, or cover into evidence, hook, structure,
  visual logic, interaction motive, and transferable principles, then create non-copying adaptation angles.
  Use for 爆款拆解, 二创, reference analysis, 对标分析, 这条笔记为什么火, 帮我分析这个链接,
  or turning a popular post into an original concept for another account.
---

# Xiaohongshu Reference Deconstructor

Turn a reference into original creative decisions rather than a rewritten copy.

Read `../references/justone-api.md` and `../references/websearch-fallback.md`.

## Step 0: retrieve the reference

When the user supplies a link, share text, or note id, fetch the note before analyzing:

```bash
python3 scripts/fetch_note_detail.py \
  --note "https://www.xiaohongshu.com/explore/<noteId>" \
  --output ~/.xhs/references/latest.json
```

Accepts full URLs, pasted share text, or a bare 24-char note id; `--note` is repeatable for batch comparison.

| State | Route |
|---|---|
| `JUSTONE_API_TOKEN` set | `fetch_note_detail.py` |
| Token missing or API error | Ask for a screenshot/paste, or use WebSearch snippets (`data_unverified`) |
| `body_available=false` | Analyze visible fields only; never reconstruct the body from memory |

## Workflow

1. Inspect all user-provided material. Retrieve the note per Step 0 before analyzing a link.
2. Extract observable facts first: title, cover text, format, sequence, visible metrics, claims, and calls to action.
3. Infer the audience problem, hook, value promise, proof mechanism, narrative structure, visual hierarchy, and save/comment motive.
4. Separate transferable mechanics from creator-owned context.
5. Produce at least three transformations that change the audience, proof, format, experiment, or point of view.
6. Score similarity risk and reject options that only swap nouns, reorder bullets, or restyle the cover.
7. Recommend one direction that best matches the account DNA.

Read `references/analysis-schema.md` for the output contract.

## Transformation Standard

A valid adaptation must add at least two of:

- original test or dataset;
- creator's own failure, result, or opinion;
- different audience or use case;
- different content format;
- comparison, challenge, or longitudinal follow-up;
- new workflow or decision framework.

Do not reproduce proprietary visuals, wording, personal stories, or repository code without permission and applicable license rights.

