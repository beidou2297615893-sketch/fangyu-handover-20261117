﻿$expected=Join-Path $env:LOCALAPPDATA 'fangyu-apartment-clientWorkspaceApp'
$target=[IO.Path]::GetFullPath($PSScriptRoot)
if ($target -ne [IO.Path]::GetFullPath($expected)) { throw '卸载路径验证失败' }
$item=Get-Item -LiteralPath $target -Force
if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw '卸载目录不能是链接或重解析点' }
Add-Type -AssemblyName System.Windows.Forms
$ok=[System.Windows.Forms.MessageBox]::Show('删除软件程序？业务数据和账号资料将保留。请先关闭软件。','卸载方隅工作台','YesNo')
if ($ok -ne 'Yes') { exit }
$shortcut=Join-Path ([Environment]::GetFolderPath('Desktop')) '方隅工作台.lnk'
$menu=Join-Path ([Environment]::GetFolderPath('Programs')) '方隅工作台'
$menuShortcut=Join-Path $menu '方隅工作台.lnk'
$expectedExe=Join-Path $target 'FangyuWorkbench.exe'
foreach ($link in @($shortcut,$menuShortcut)) {
    if (Test-Path -LiteralPath $link -PathType Leaf) {
        $shell=New-Object -ComObject WScript.Shell
        $existing=$shell.CreateShortcut($link)
        if ([string]::Equals($existing.TargetPath,$expectedExe,[StringComparison]::OrdinalIgnoreCase)) {
            Remove-Item -LiteralPath $link -Force
        }
    }
}
if ((Test-Path -LiteralPath $menu -PathType Container) -and -not (Get-ChildItem -LiteralPath $menu -Force | Select-Object -First 1)) {
    Remove-Item -LiteralPath $menu
}
Remove-Item -LiteralPath $target -Recurse -Force
