from __future__ import annotations

from copy import deepcopy
import hashlib
import json
import importlib.util
import os
from pathlib import Path
import shutil
import sys
import tempfile
import unittest
import uuid
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from client.gateway_adapter import ContentGatewayAdapter, GatewayConfigurationError
from client.trusted_method_pins import get_trusted_method, trusted_method_digest


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False)


def context():
    return {'environment_id': 'fixture-env', 'company_id': 'fixture-company',
            'tenant_id': 'fixture-tenant', 'store_id': 'fixture-store',
            'account_id': 'fixture-account', 'platform': 'xiaohongshu',
            'actor': 'fixture-operator', 'device_id': 'fixture-device',
            'expected_revision': 3, 'expected_rules_version': 'fixture-rules-v1'}


def envelope():
    ctx = context()
    content = {'query': '厨房选题', 'instructions': '', 'persona': {}, 'topic': None,
               'draft': None, 'evidence': [], 'artifacts': []}
    return {'contract': 'fangyu-content-workflow-v1', 'requestId': 'a' * 64,
            'taskId': 'fixture-task', 'scope': {k: ctx[k] for k in
                ('tenant_id', 'store_id', 'account_id', 'platform', 'company_id', 'actor')},
            'method': get_trusted_method('writing'), 'input': content,
            'inputDigest': hashlib.sha256(canonical(content).encode()).hexdigest(),
            'requirements': {'platformActionsAllowed': False, 'humanReviewRequired': True,
                             'sourceTextIsUntrustedData': True}}


def output():
    return {'summary': '虚构待审稿', 'facts': [], 'hypotheses': ['仍需人工审核'],
            'artifact': {'title': '厨房使用提示', 'body': '请先核对厨房实际开放时间。', 'tags': ['虚构']}}


def server_response(payload, state='succeeded', *, coverage='stable_request_index_v1'):
    generation = {'contract': 'fangyu-content-generation-v1',
        'request_id': payload['request_id'], 'task_id': payload['task_id'],
        'input_digest': payload['input_digest'], 'method_id': payload['method_id'],
        'method_digest': payload['method_digest'], 'scope': deepcopy(payload['scope']),
        'state': state, 'result_available': state == 'succeeded',
        'execution_confirmed': True if state == 'succeeded' else False,
        'reservation_retained': False, 'retry_allowed': False,
        'read_only': payload['operation'] == 'content_generate_status', 'coverage': coverage}
    if coverage == 'current_submission':
        generation['submission_id'] = payload['submission_id']
    if state == 'succeeded':
        generation['output'] = output()
    return {'status': 200, 'data': {'contract': 'fangyu-workspace-v1',
        'environment_id': payload['environment_id'], 'company_id': payload['scope']['company_id'],
        'content_generation': generation}}


class GatewayAdapterTests(unittest.TestCase):
    def test_success_is_bound_to_the_original_request_and_emits_only_wire_fields(self):
        calls = []
        def transport(payload):
            calls.append(deepcopy(payload))
            return server_response(payload)
        adapter = ContentGatewayAdapter(transport=transport, trusted_context=context)
        result = adapter(envelope())
        self.assertEqual(result, {'requestId': 'a' * 64, 'state': 'succeeded', 'output': output()})
        self.assertEqual(len(calls), 1)
        self.assertEqual(calls[0]['method_digest'], trusted_method_digest('writing'))
        self.assertEqual(set(calls[0]), {'environment_id', 'operation', 'request_id', 'submission_id',
            'scope', 'task_id', 'method_id', 'method_digest', 'input_json', 'input_digest',
            'expected_device_id', 'expected_revision', 'expected_rules_version'})
        self.assertNotIn('instructions', calls[0])
        self.assertEqual(calls[0]['input_json'], canonical(envelope()['input']))

    def test_known_not_executed_requires_authoritative_current_scope_proof(self):
        for coverage in ('stable_request_index_v1', 'current_submission'):
            with self.subTest(coverage=coverage):
                adapter = ContentGatewayAdapter(transport=lambda payload: server_response(payload,
                    'known_not_executed', coverage=coverage), trusted_context=context)
                self.assertEqual(adapter(envelope()), {'requestId': 'a' * 64, 'state': 'known_not_executed'})

    def test_status_uses_only_the_read_only_operation_and_original_key(self):
        calls = []
        def transport(payload):
            calls.append(deepcopy(payload))
            return server_response(payload)
        result = ContentGatewayAdapter(transport, context).status(envelope())
        self.assertEqual(result['state'], 'succeeded')
        self.assertEqual(len(calls), 1)
        self.assertEqual(calls[0]['operation'], 'content_generate_status')
        self.assertEqual(calls[0]['request_id'], envelope()['requestId'])

    def test_budget_denial_can_prove_not_executed_without_being_http_success(self):
        def transport(payload):
            response = server_response(payload, 'known_not_executed', coverage='current_submission')
            response['status'] = 402
            return response
        self.assertEqual(ContentGatewayAdapter(transport, context)(envelope()),
                         {'requestId': 'a' * 64, 'state': 'known_not_executed'})

    def test_success_requires_reservation_to_be_released(self):
        for retained in (True, None):
            def transport(payload):
                response = server_response(payload)
                response['data']['content_generation']['reservation_retained'] = retained
                return response
            self.assertEqual(ContentGatewayAdapter(transport, context)(envelope())['state'], 'unknown')

    def test_output_limit_matches_core_python_spacing_at_and_above_boundary(self):
        candidate = output()
        candidate['artifact']['body'] = ''
        serialized_size = lambda: len(json.dumps(candidate, ensure_ascii=False, allow_nan=False).encode('utf-8'))
        overhead = serialized_size()
        padding = 120_000 - overhead
        candidate['artifact']['body'] = '字' * (padding // 3) + 'x' * (padding % 3)
        self.assertEqual(serialized_size(), 120_000)
        def transport(payload):
            response = server_response(payload)
            response['data']['content_generation']['output'] = candidate
            return response
        adapter = ContentGatewayAdapter(transport, context)
        self.assertEqual(adapter(envelope())['state'], 'succeeded')
        candidate['artifact']['body'] += 'x'
        self.assertLess(len(canonical(candidate).encode('utf-8')), 120_000)
        self.assertEqual(adapter(envelope())['state'], 'unknown')

    def test_recovery_metadata_is_typed_and_bound_to_current_rules_and_revision(self):
        values = {'context_digest': 'b' * 64, 'config_revision': context()['expected_revision'],
                  'rules_version': context()['expected_rules_version'], 'requires_revalidation': False, 'cache_hit': False}
        def transport(payload):
            response = server_response(payload)
            response['data']['content_generation'].update(values)
            return response
        adapter = ContentGatewayAdapter(transport, context)
        self.assertEqual(adapter(envelope())['state'], 'succeeded')
        for field, invalid in [('context_digest', 'bad'), ('config_revision', 999),
                               ('rules_version', 'changed'), ('requires_revalidation', True), ('cache_hit', 0)]:
            original = values[field]
            values[field] = invalid
            self.assertEqual(adapter(envelope())['state'], 'unknown')
            values[field] = original

    def test_missing_host_callbacks_are_not_a_runnable_default(self):
        for args in [(), (lambda payload: {},), (None, context)]:
            with self.assertRaises(GatewayConfigurationError):
                ContentGatewayAdapter(*args)

    def test_scope_mismatch_never_reaches_transport(self):
        calls = []
        adapter = ContentGatewayAdapter(lambda payload: calls.append(payload), context)
        for key in envelope()['scope']:
            value = envelope()
            value['scope'][key] = 'other'
            self.assertEqual(adapter(value)['state'], 'unknown')
        self.assertEqual(calls, [])

    def test_full_method_spec_is_pinned_including_schema_and_instructions(self):
        calls = []
        adapter = ContentGatewayAdapter(lambda payload: calls.append(payload), context)
        for field, changed in [('instructions', 'untrusted system'), ('requiresHumanReview', False),
                               ('outputSchema', {}), ('extra', 'untrusted')]:
            value = envelope()
            value['method'][field] = changed
            self.assertEqual(adapter(value)['state'], 'unknown')
        self.assertEqual(calls, [])

    def test_all_seventeen_methods_can_use_their_exact_generated_spec(self):
        methods = ['strategy', 'persona', 'homepage', 'research', 'topics', 'columns',
                   'writing', 'video', 'visual', 'knowledge', 'revision', 'audit',
                   'package', 'scheduling', 'engagement', 'growth', 'learning']
        for method in methods:
            value = envelope()
            value['method'] = get_trusted_method(method)
            calls = []
            def transport(payload):
                calls.append(deepcopy(payload))
                return server_response(payload, 'unknown')
            result = ContentGatewayAdapter(transport, context)(value)
            self.assertEqual(result['state'], 'unknown')
            self.assertEqual(len(calls), 1)
            self.assertEqual(calls[0]['method_id'], method)
            self.assertEqual(calls[0]['method_digest'], trusted_method_digest(method))
        self.assertEqual(len(methods), 17)

    def test_input_digest_requirements_and_extra_wire_controls_fail_before_dispatch(self):
        calls = []
        values = []
        bad = envelope(); bad['inputDigest'] = 'b' * 64; values.append(bad)
        bad = envelope(); bad['requirements']['platformActionsAllowed'] = True; values.append(bad)
        bad = envelope(); bad['endpoint'] = 'https://never-called.invalid'; values.append(bad)
        bad = envelope(); bad['input']['invalid'] = float('nan'); values.append(bad)
        bad = envelope(); bad['input']['large'] = '字' * 160_001; values.append(bad)
        adapter = ContentGatewayAdapter(lambda payload: calls.append(payload), context)
        for value in values:
            self.assertEqual(adapter(value)['state'], 'unknown')
        self.assertEqual(calls, [])

    def test_context_is_checked_again_and_result_hidden_after_change(self):
        for field in context():
            current = context()
            calls = []
            def trusted():
                return current
            def transport(payload):
                calls.append(payload)
                current[field] = 4 if field == 'expected_revision' else 'changed'
                return server_response(payload)
            self.assertEqual(ContentGatewayAdapter(transport, trusted)(envelope())['state'], 'unknown')
            self.assertEqual(len(calls), 1)

    def test_transport_exception_is_unknown_without_retry_or_error_payload(self):
        calls = []
        contexts = []
        def transport(payload):
            calls.append(payload)
            raise TimeoutError('synthetic-private-error-canary')
        def trusted():
            contexts.append(1)
            return context()
        result = ContentGatewayAdapter(transport, trusted)(envelope())
        self.assertEqual(result, {'requestId': 'a' * 64, 'state': 'unknown'})
        self.assertEqual(len(calls), 1)
        self.assertEqual(len(contexts), 2)
        self.assertNotIn('canary', canonical(result))

    def test_every_response_binding_must_match(self):
        changes = [
            ('request_id', 'other'), ('task_id', 'other'), ('input_digest', 'b' * 64),
            ('method_id', 'persona'), ('method_digest', 'b' * 64),
            ('scope', {**envelope()['scope'], 'account_id': 'other'}),
            ('contract', 'other'), ('coverage', 'legacy_untracked'),
            ('retry_allowed', True), ('read_only', True),
            ('result_available', False), ('execution_confirmed', None),
        ]
        for key, changed in changes:
            with self.subTest(field=key):
                def transport(payload):
                    response = server_response(payload)
                    response['data']['content_generation'][key] = changed
                    return response
                self.assertEqual(ContentGatewayAdapter(transport, context)(envelope())['state'], 'unknown')

    def test_outer_contract_environment_company_http_and_execution_are_checked(self):
        for field in ('contract', 'environment_id', 'company_id'):
            def transport(payload):
                response = server_response(payload)
                response['data'][field] = 'other'
                return response
            self.assertEqual(ContentGatewayAdapter(transport, context)(envelope())['state'], 'unknown')
        for status in (True, 201, 400, 500):
            def transport(payload):
                response = server_response(payload)
                response['status'] = status
                return response
            self.assertEqual(ContentGatewayAdapter(transport, context)(envelope())['state'], 'unknown')

    def test_not_executed_rejects_weak_proof_retained_reservation_and_wrong_submission(self):
        for field, changed in [('coverage', 'legacy_untracked'), ('execution_confirmed', None),
                               ('reservation_retained', True), ('result_available', True),
                               ('submission_id', 'a-previous-submission'), ('retry_allowed', True)]:
            def transport(payload):
                response = server_response(payload, 'known_not_executed', coverage='current_submission')
                response['data']['content_generation'][field] = changed
                return response
            self.assertEqual(ContentGatewayAdapter(transport, context)(envelope())['state'], 'unknown')

    def test_unknown_invalid_and_no_result_states_do_not_authorize_retry(self):
        for state in ('unknown', 'completed_no_result', 'completed_invalid', 'running', 'legacy_untracked'):
            calls = []
            def transport(payload):
                calls.append(payload)
                return server_response(payload, state)
            result = ContentGatewayAdapter(transport, context)(envelope())
            self.assertEqual(result, {'requestId': 'a' * 64, 'state': 'unknown'})
            self.assertEqual(len(calls), 1)

    def test_submission_is_a_new_uuid_but_original_request_key_never_changes(self):
        calls = []
        def transport(payload):
            calls.append(deepcopy(payload))
            return server_response(payload, 'unknown')
        adapter = ContentGatewayAdapter(transport, context)
        adapter(envelope())
        adapter.status(envelope())
        self.assertEqual([p['request_id'] for p in calls], ['a' * 64, 'a' * 64])
        self.assertNotEqual(calls[0]['submission_id'], calls[1]['submission_id'])
        self.assertTrue(all(uuid.UUID(p['submission_id']).version == 4 for p in calls))

    def test_status_rejects_non_read_only_response_and_does_not_generate(self):
        calls = []
        def transport(payload):
            calls.append(payload)
            response = server_response(payload)
            response['data']['content_generation']['read_only'] = False
            return response
        result = ContentGatewayAdapter(transport, context).status(envelope())
        self.assertEqual(result['state'], 'unknown')
        self.assertEqual([p['operation'] for p in calls], ['content_generate_status'])

    def test_no_network_credentials_or_files_are_read_during_calls(self):
        def denied(*args, **kwargs):
            raise AssertionError('forbidden external access')
        adapter = ContentGatewayAdapter(lambda payload: server_response(payload), context)
        with patch('builtins.open', denied), patch('pathlib.Path.read_bytes', denied), patch('socket.socket', denied):
            self.assertEqual(adapter(envelope())['state'], 'succeeded')

    def test_output_and_wire_are_detached_from_caller_objects(self):
        value = envelope()
        before = deepcopy(value)
        raw = []
        def transport(payload):
            response = server_response(payload)
            raw.append(response)
            payload['scope']['actor'] = 'mutated-transport-local-copy'
            return response
        result = ContentGatewayAdapter(transport, context)(value)
        result['output']['artifact']['tags'].append('local-edit')
        self.assertEqual(value, before)
        self.assertEqual(raw[0]['data']['content_generation']['output']['artifact']['tags'], ['虚构'])

    def test_fixed_path_pins_ignore_poisoned_cwd_and_changed_pins_fail_new_load(self):
        with tempfile.TemporaryDirectory(prefix='pins-', dir=ROOT / 'work/adapter-logs') as temporary:
            directory = Path(temporary)
            (directory / 'trusted_method_pins.py').write_text("raise RuntimeError('cwd poison')", encoding='utf-8')
            (directory / 'workflow_methods.py').write_text("raise RuntimeError('cwd poison')", encoding='utf-8')
            previous = Path.cwd()
            try:
                os.chdir(directory)
                spec = importlib.util.spec_from_file_location('fresh_gateway_adapter', ROOT / 'client/gateway_adapter.py')
                module = importlib.util.module_from_spec(spec)
                spec.loader.exec_module(module)
                self.assertEqual(module.ContentGatewayAdapter(lambda payload: server_response(payload), context)(envelope())['state'], 'succeeded')
            finally:
                os.chdir(previous)
            shutil.copyfile(ROOT / 'client/gateway_adapter.py', directory / 'gateway_adapter.py')
            shutil.copyfile(ROOT / 'client/trusted_method_pins.py', directory / 'trusted_method_pins.py')
            with (directory / 'trusted_method_pins.py').open('a', encoding='utf-8') as stream:
                stream.write('\n# changed pins\n')
            spec = importlib.util.spec_from_file_location('changed_gateway_adapter', directory / 'gateway_adapter.py')
            module = importlib.util.module_from_spec(spec)
            with self.assertRaisesRegex(RuntimeError, 'trusted_method_pins_changed'):
                spec.loader.exec_module(module)


if __name__ == '__main__':
    unittest.main()
