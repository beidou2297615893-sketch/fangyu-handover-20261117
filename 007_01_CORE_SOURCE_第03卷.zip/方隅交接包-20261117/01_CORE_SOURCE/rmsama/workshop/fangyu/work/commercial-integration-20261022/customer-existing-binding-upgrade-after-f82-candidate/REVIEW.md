# 原绑定升级验证

结论：原 1.1.8-pilot.1 的实际 AssistantService.bind 生成 Windows DPAPI 绑定后，停止旧 Service；revision 5 新原 host/create_backend 通过明确指定且 hash 固定的原工作资料选择，使用同一目录、同一加密 vault、同一 token 和同一云 device，直接 AssistantService.start/Runner/DeviceSession 取得新 1.2.0-read.1 的 45 秒客户只读租约。没有重新绑定、旋转 token、替换 device 或创建空工作区。

原 createService 连续同一内存 state 总计 13 次认证请求；全阶段仅一次 device_enroll，新版本零 enroll。5 条原记录的 entity/id/tenant_id/body 字节投影完全一致，覆盖账号、评论及 AI/人工判断、暂停任务、unknown 回复和已启动未确认页断点；没有恢复或重派这些 unknown 工作。原加密 DPAPI 文件 SHA 与 token SHA 前后完全一致。

公司/device 不符、错误 descriptor SHA、缺少绑定均拒绝，不创建新的资料目录。新只读租约不授 general employee/default executor 或发送权限；原 public_send_hold 保持，未审自然用途仍拒绝。

最初旧阶段的 bind 已成功，但测试误把旧版应保持的 held 状态当成失败，old-stage-evidence/ERROR.json 保留。续接旧 vault 并使用原 start，不重 bind；最终原云请求审计证明只有一次 enroll。因此此红例是探针前提修正，不是改产品守卫或伪造 online。

这是实际 Windows DPAPI、原 factory/Service/Runner 与原 createService 本机内存 HTTP 的 **source/frozen 路径代表性验证**。本次没有编译主 EXE，没有实际云部署/真实平台/本人账号/Native UI/模型请求，没有修改生产或正式包。最终 compiled 入口及本人实际工作资料升级由总控后继独立验收，不以本报告替代。

全部自有 Service/backend/HTTP/云桥已关闭；云桥 session 47791、旧续接 10951、新升级 72559 均已退出。运行脚本都在本目录；原云桥需连续活到新阶段完毕，不能分成两份新云 state。
