import {escape as esc,customerControls,actorMatches} from './customers-data.mjs';

const labels={super_high:'超高意向',high:'高意向',medium:'中意向',low:'低意向',very_low:'极低意向',uncertain:'信息不足',unrelated:'不相关',pending:'尚未分析'};
const levels=['super_high','high','medium','low','very_low'];
const scope=s=>JSON.stringify([s.authEpoch||0,s.user||'',s.storeId||'',s.activePlatform||'xiaohongshu']);
const actor=s=>[s.user||'',s.storeId||'',s.activePlatform||'xiaohongshu'];
const hex=value=>typeof value==='string'&&/^[a-f0-9]{64}$/.test(value);
const key=(s,customerId,leadId)=>'fangyu.intent-correction.v1:'+JSON.stringify([...actor(s),customerId,leadId]);
const choice=value=>value?.status==='graded'&&levels.includes(value.level)?value.level:['uncertain','unrelated'].includes(value?.status)?value.status:'';
const label=value=>labels[choice(value)]||'尚未分析';
const evidence=value=>Array.isArray(value?.evidence)?value.evidence.filter(v=>typeof v==='string'):typeof value?.evidence==='string'?[value.evidence]:[];

export async function correctionRequestDigest(data){
  const ordered=Object.fromEntries(Object.keys(data).sort().map(k=>[k,k==='reason'?data[k].trim():data[k]]));
  const bytes=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(JSON.stringify(ordered)));
  return [...new Uint8Array(bytes)].map(v=>v.toString(16).padStart(2,'0')).join('');
}

function pendingFromStorage(s,customerId,leadId){
  try{const p=JSON.parse(localStorage.getItem(key(s,customerId,leadId))||'null');
    return p?.schema===1&&JSON.stringify(p.actor)===JSON.stringify(actor(s))&&p.customerId===customerId&&p.leadId===leadId&&typeof p.requestId==='string'&&/^[A-Za-z0-9_-]{1,160}$/.test(p.requestId)&&hex(p.expectedVersion)&&hex(p.sourceDigest)?p:null;
  }catch{return null;}
}
function pendingKey(h){return 'fangyu.intent-correction.v1:'+JSON.stringify([...h.actor,h.customerId,h.leadId]);}
function remember(h,data,requestDigest){
  const value={schema:1,actor:h.actor,customerId:h.customerId,leadId:h.leadId,requestId:data.requestId,expectedVersion:data.expectedVersion,sourceDigest:data.sourceDigest,requestDigest};
  const serialized=JSON.stringify(value);localStorage.setItem(pendingKey(h),serialized);
  if(localStorage.getItem(pendingKey(h))!==serialized)throw Error('无法保留更正断点，请恢复本机存储后再保存。');
  h.pending={...value,payload:{...data},notFound:false};
}
function clearPending(h){try{localStorage.removeItem(pendingKey(h));}catch{}h.pending=null;}
function owns(ctx,h){return ctx.state.customerIntentCorrection===h&&scope(ctx.state)===h.scope&&ctx.state.page==='customers'&&customerControls(ctx.state).selectedId===h.customerId;}
function update(ctx,h){if(owns(ctx,h))ctx.update(()=>{});}
function selection(state,p){
  const comments=Array.isArray(p?.comments)?p.comments.filter(c=>typeof c?.id==='string'&&c.id&&typeof c.text==='string'):[];
  if(!comments.length)return null;
  let h=state.customerIntentCorrection;
  if(!h||h.scope!==scope(state)||h.customerId!==p.id||!comments.some(c=>c.id===h.leadId)){
    const leadId=comments.some(c=>c.id===p.representativeLeadId)?p.representativeLeadId:comments[0].id;
    h={scope:scope(state),actor:actor(state),customerId:p.id,leadId,open:false,busy:false,view:null,selection:'',reason:'',dirty:false,message:'',pending:pendingFromStorage(state,p.id,leadId)};
    state.customerIntentCorrection=h;
  }
  return {h,comments,comment:comments.find(c=>c.id===h.leadId)};
}
function judgment(title,value){return `<div class="cs-correction-judgment"><strong>${title}：${esc(label(value))}</strong>${value?.reason?`<p>${esc(value.reason)}</p>`:''}${evidence(value).length?`<ul>${evidence(value).map(v=>`<li>${esc(v)}</li>`).join('')}</ul>`:''}</div>`;}
function history(rows){if(!Array.isArray(rows)||!rows.length)return '';return `<details class="cs-correction-history"><summary>查看人工更正记录（${rows.length}）</summary>${rows.length>10?'<p>显示最近 10 次更正，完整历史仍保留。</p>':''}${rows.slice(0,10).map(r=>`<p><strong>${esc(label(r.before))} → ${esc(label(r.after))}</strong><br>${esc(r.after?.reason||'')}<br><small>${esc(r.by||'员工')} · ${esc(r.updatedAt||'时间未记录')}</small></p>`).join('')}</details>`;}

export function renderIntentCorrection(state,p){
  if(state.customerDetail?.status!=='ready'||!actorMatches(state,state.customerDetail)||state.customerDetail.id!==p?.id||p.platform!==(state.activePlatform||'xiaohongshu'))return '';
  const selected=selection(state,p);if(!selected)return '';
  const {h,comments,comment}=selected,locked=h.busy||Boolean(h.pending),ready=Boolean(h.view);
  return `<section class="cs-intent-correction" aria-label="单条评论人工纠错"><div class="cs-correction-heading"><strong>人工核对</strong><button type="button" class="text-button" data-correction-open aria-expanded="${h.open}">${h.open?'收起':'更正这条评论的意向'}</button></div>${!h.open?h.pending?'<p role="status">这条评论有一次更正待核对。</p>':'':`<p class="cs-correction-scope">只更正下方这一条评论，其他历史评论保持原判断。</p>${comments.length>1?`<label class="cs-correction-field">选择原评论<select data-correction-comment ${locked?'disabled':''}>${comments.map((c,i)=>`<option value="${esc(c.id)}" ${c.id===h.leadId?'selected':''}>${i+1}. ${esc(c.text.slice(0,60))} · ${esc(c.postTitle||'原帖')}</option>`).join('')}</select></label>`:''}<blockquote class="cs-correction-quote">${esc(comment.text||'原评论为空')}</blockquote><p class="cs-correction-source">${esc(comment.postTitle||'原帖标题未记录')} · ${esc(comment.publishedAt||'评论时间未记录')}</p>${ready?`${judgment('AI 原判断',h.view.aiIntent)}${h.view.manualIntent?`${judgment('人工更正',h.view.manualIntent)}<p class="cs-correction-source">${esc(h.view.manualIntent.by||'员工')} · ${esc(h.view.manualIntent.updatedAt||'时间未记录')}</p>`:''}<label class="cs-correction-field">更正为<select data-correction-level ${locked?'disabled':''}><option value="">请选择意向</option>${[...levels,'uncertain','unrelated'].map(v=>`<option value="${v}" ${h.selection===v?'selected':''}>${labels[v]}</option>`).join('')}</select></label><label class="cs-correction-field">人工理由<textarea data-correction-reason maxlength="300" rows="3" placeholder="例如：这条评论是在转租，不是在求租。" ${locked?'readonly':''}>${esc(h.reason)}</textarea></label><p class="cs-correction-source">AI 原判断会保留。客户汇总仍可能由其他评论决定。</p>${history(h.view.history)}`:''}<p class="cs-correction-message" role="status" aria-live="polite">${esc(h.message||(!ready?'正在读取这条评论的判断…':''))}</p><div class="cs-correction-actions">${h.pending?`<button type="button" class="cs-primary" data-correction-check ${h.busy?'disabled':''}>核对上次更正</button>${h.pending.notFound&&h.pending.payload?`<button type="button" class="cs-secondary" data-correction-retry ${h.busy?'disabled':''}>按原内容重试一次</button>`:''}${h.pending.notFound&&hex(h.pending.requestDigest)?`<button type="button" class="text-button" data-correction-cancel ${h.busy?'disabled':''}>取消这次待确认更正</button>`:''}<small>未确认前不会重复提交。${h.pending.payload?'':'当前仅保留原请求断点，请先核对原结果。'}</small>`:`<button type="button" class="cs-primary" data-correction-save ${h.busy||!ready?'disabled':''}>${h.busy?'正在保存…':'保存这条更正'}</button><button type="button" class="text-button" data-correction-read ${h.busy?'disabled':''}>重新读取判断</button>`}</div>`}</section>`;
}

function accept(h,result){
  const v=result?.intentCorrection;
  if(!v||v.scope!=='single-comment'||v.actor?.username!==h.actor[0]||v.actor?.storeId!==h.actor[1]||v.platform!==h.actor[2]||v.customerId!==h.customerId||v.leadId!==h.leadId||!hex(v.version)||!hex(v.sourceDigest))throw Error('更正回执与当前评论不一致，请核对原操作。');
  return v;
}
function saved(h,v){
  const r=v.receipt,p=h.pending;
  return Boolean(p&&r?.requestId===p.requestId&&r.state==='saved'&&r.customerId===h.customerId&&r.leadId===h.leadId&&r.platform===h.actor[2]&&r.storeId===h.actor[1]&&hex(r.version)&&r.sourceDigest===p.sourceDigest&&(!p.requestDigest||r.requestDigest===p.requestDigest));
}
function cancelled(h,v){const r=v.receipt,p=h.pending;return Boolean(p&&r?.requestId===p.requestId&&r.state==='cancelled'&&r.customerId===h.customerId&&r.leadId===h.leadId&&r.platform===h.actor[2]&&r.storeId===h.actor[1]&&hex(r.requestDigest)&&(!p.requestDigest||r.requestDigest===p.requestDigest));}
function adopt(h,v,reset=false){h.view=v;if(reset&&!h.dirty){h.selection=choice(v.currentIntent);h.reason=v.manualIntent?.reason||'';}}
function fields(h){return {storeId:h.actor[1],customerId:h.customerId,leadId:h.leadId,platform:h.actor[2]};}
function refresh(ctx,h){if(!owns(ctx,h))return;ctx.actions.loadCustomers?.();ctx.actions.loadCustomerDetail?.(h.customerId);}
async function read(ctx,h){
  if(!owns(ctx,h)||h.busy)return;h.busy=true;h.message=h.pending?'正在核对上次更正…':'正在读取判断…';update(ctx,h);
  try{const result=await ctx.actions.intentCorrectionAction('customer_intent_read',{...fields(h),...(h.pending?{requestId:h.pending.requestId}:{})});
    if(!owns(ctx,h))return;const v=accept(h,result);adopt(h,v,!h.pending);
    if(h.pending){if(saved(h,v)){clearPending(h);h.dirty=false;adopt(h,v,true);h.message='更正已保存，已保留 AI 原判断。';refresh(ctx,h);}
      else if(cancelled(h,v)){clearPending(h);h.dirty=false;adopt(h,v,true);h.message='这次待确认更正已取消，可重新填写并保存。';}
      else if(v.receipt?.requestId===h.pending.requestId&&v.receipt.state==='not_found'){h.pending.notFound=true;h.message=h.pending.payload?'暂未找到原回执。可继续核对，或手动按原内容重试；不会生成新请求。':'暂未找到原回执，已保留断点。无法确认前不能重新提交。';}
      else throw Error('尚未取得上次更正的明确回执，请继续核对。');
    }else h.message='';
  }catch(error){if(owns(ctx,h)){h.message=error.message||'暂时无法读取判断，请稍后核对。';ctx.actions.replyError?.(error);}}
  finally{h.busy=false;update(ctx,h);}
}
async function save(ctx,h,retry=false){
  if(!owns(ctx,h)||h.busy||!h.view||h.pending&&!retry)return;
  let data;
  if(retry){if(!h.pending?.notFound||!h.pending.payload)return;data=h.pending.payload;h.pending.notFound=false;}
  else{
    if(![...levels,'uncertain','unrelated'].includes(h.selection)){h.message='请选择更正后的意向。';update(ctx,h);return;}
    const reason=h.reason.trim();if(!reason||[...reason].length>300){h.message='请填写 1—300 字的人工理由。';update(ctx,h);return;}
    if(h.view.manualIntent&&choice(h.view.manualIntent)===h.selection&&h.view.manualIntent.reason===reason){h.message='这条评论已是该人工判断，无需再次保存。';update(ctx,h);return;}
    data={...fields(h),requestId:crypto.randomUUID(),expectedVersion:h.view.version,sourceDigest:h.view.sourceDigest,status:levels.includes(h.selection)?'graded':h.selection,level:levels.includes(h.selection)?h.selection:null,reason};
    h.busy=true;update(ctx,h);
    try{const digest=await correctionRequestDigest(data);if(!owns(ctx,h)){h.busy=false;return;}remember(h,data,digest);}catch{h.busy=false;h.message='无法保留更正断点，请恢复本机存储后再保存。';update(ctx,h);return;}
  }
  h.busy=true;h.message=retry?'正在按原内容核对保存…':'正在保存这条评论的更正…';update(ctx,h);
  try{const result=await ctx.actions.intentCorrectionAction('customer_intent_correct',data);
    if(!owns(ctx,h))return;const v=accept(h,result);if(!saved(h,v))throw Error('保存结果尚未确认，请核对上次更正。');
    clearPending(h);h.dirty=false;adopt(h,v,true);h.message='这条评论已更正，AI 原判断已保留。';refresh(ctx,h);
  }catch(error){if(owns(ctx,h)){if(error.mutationCommitted===false){clearPending(h);h.message=`${error.message}。输入已保留，请重新读取判断后核对。`;h.view=null;}else h.message='更正结果待核对，已保留原请求，不会自动重复保存。';ctx.actions.replyError?.(error);}}
  finally{h.busy=false;update(ctx,h);}
}
async function cancel(ctx,h){
  if(!owns(ctx,h)||h.busy||!h.pending?.notFound||!hex(h.pending.requestDigest))return;
  h.busy=true;h.pending.notFound=false;h.message='正在核对并取消原请求…';update(ctx,h);
  try{const result=await ctx.actions.intentCorrectionAction('customer_intent_cancel',{...fields(h),requestId:h.pending.requestId,requestDigest:h.pending.requestDigest});
    if(!owns(ctx,h))return;const v=accept(h,result);
    if(saved(h,v)){clearPending(h);h.dirty=false;adopt(h,v,true);h.message='原更正已经保存，已显示原结果。';refresh(ctx,h);}
    else if(cancelled(h,v)){clearPending(h);h.dirty=false;adopt(h,v,true);h.message='这次待确认更正已取消，可重新填写并保存。';}
    else throw Error('取消结果尚未确认');
  }catch(error){if(owns(ctx,h)){h.message='取消结果待核对，已保留原请求，请核对上次更正。';ctx.actions.replyError?.(error);}}
  finally{h.busy=false;update(ctx,h);}
}
export function bindIntentCorrection(root,ctx){
  const h=ctx.state.customerIntentCorrection;if(!h||!owns(ctx,h))return;
  root.querySelector('[data-correction-open]')?.addEventListener('click',()=>{if(!owns(ctx,h))return;h.open=!h.open;update(ctx,h);if(h.open&&!h.view&&!h.busy)read(ctx,h);});
  root.querySelector('[data-correction-comment]')?.addEventListener('change',event=>{if(!owns(ctx,h)||h.busy||h.pending)return;const p=ctx.state.customerDetail?.item,c=p?.comments?.find(c=>c.id===event.target.value);if(!c)return;
    // Switching a comment is explicit; the previously entered explanation is not
    // silently submitted or copied onto this different original comment.
    const next={...h,leadId:c.id,open:true,view:null,selection:'',reason:'',dirty:false,message:'',pending:pendingFromStorage(ctx.state,h.customerId,c.id)};ctx.state.customerIntentCorrection=next;update(ctx,next);read(ctx,next);
  });
  for(const [selector,field] of [['[data-correction-level]','selection'],['[data-correction-reason]','reason']])root.querySelector(selector)?.addEventListener(field==='selection'?'change':'input',event=>{if(owns(ctx,h)&&!h.busy&&!h.pending){h[field]=event.target.value;h.dirty=true;}});
  root.querySelector('[data-correction-read]')?.addEventListener('click',()=>read(ctx,h));
  root.querySelector('[data-correction-check]')?.addEventListener('click',()=>read(ctx,h));
  root.querySelector('[data-correction-save]')?.addEventListener('click',()=>save(ctx,h));
  root.querySelector('[data-correction-retry]')?.addEventListener('click',()=>save(ctx,h,true));
  root.querySelector('[data-correction-cancel]')?.addEventListener('click',()=>{
    if(!owns(ctx,h)||h.busy||!h.pending?.notFound||!hex(h.pending.requestDigest)||typeof ctx.modal!=='function')return;
    ctx.modal({title:'取消这次待确认更正',html:'<p>取消后，原请求即使稍后到达，也会被拦住。</p><p>如果原更正已经保存，将显示已保存的结果。确认取消后可以重新填写。</p>',confirmLabel:'确认取消这次更正',onConfirm:async()=>{await cancel(ctx,h);return true;}});
  });
}
