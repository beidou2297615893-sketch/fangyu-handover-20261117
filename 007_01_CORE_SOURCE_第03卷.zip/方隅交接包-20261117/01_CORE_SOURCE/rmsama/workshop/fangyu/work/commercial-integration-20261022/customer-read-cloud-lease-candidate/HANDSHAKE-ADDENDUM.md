# 客户只读握手补充

原固定协议文档未改，原 SHA 保持不变。

`pair_create` 和 `device_enroll` 的原请求也必须包含原协议的相同两项元数据：`version=1.2.0-read.1`、`customer_read_protocol=fangyu-customer-read-v1`。它们只说明客户端版本，不是读取授权；原用户登录、一次配对码、设备令牌和企业隔离检查保持有效。

实际授权仍只有已绑定设备经过原认证 `device_poll` 得到的 `customer_read_release`。设备注册回执不附此读取授权，版本在首次真实心跳更新。未启用服务端新开关时，这两项元数据不能连接新设备或获授权。

原 `device_permission_snapshot` 仍是只读旧权限事实快照，不能生成或续期新的读取授权；新的客户模式只能由真实心跳维护读取租约。

云候选尚未部署。原 `employee_release`、旧 pilot 判断、远程命令、公开发送规则和其他客户未改。
