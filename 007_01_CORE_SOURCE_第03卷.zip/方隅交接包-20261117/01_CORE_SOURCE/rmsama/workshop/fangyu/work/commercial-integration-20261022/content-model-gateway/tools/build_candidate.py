"""Build a reviewable patch and test it only inside this candidate's work tree."""
from __future__ import annotations
import difflib
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import tempfile
import zipfile
import os

ROOT = Path(__file__).resolve().parents[1]
CHANGED = ('ai_contract.cjs','ai_enterprise.cjs','store_config.cjs','service.cjs','index.js')
ADDED = ('ai_request_recovery.cjs','product_entitlements.cjs','intent_policy_publication.cjs',
         'content_contract.cjs','content_gateway.cjs','content_methods.cjs','content-methods.json')
CLIENT = ('client/__init__.py', 'client/gateway_adapter.py', 'client/trusted_method_pins.py')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    manifest = json.loads((ROOT / 'baseline/LIVE-CLOUD-SHA256.json').read_text('utf-8-sig'))
    baseline = ROOT / 'baseline/live'
    assert sha(ROOT/'work/actual-live-code.zip')==manifest['liveCode']['codeSha256']
    expected = {row['path']: row['sha256'] for row in manifest['files']}
    for name, digest in expected.items():
        if sha(baseline / name) != digest or sha(Path(manifest['source']) / name) != digest:
            raise RuntimeError('Authoritative source changed; review before rebasing: ' + name)
    parts = []
    records = []
    for name in CHANGED + ADDED:
        # Preserve raw CRLF/LF bytes: content-methods.json is authenticated by its
        # exact file digest, so universal-newline decoding would break runtime.
        old = (baseline / name).read_bytes().decode('utf-8') if name in CHANGED else ''
        new = (ROOT / 'server' / name).read_bytes().decode('utf-8')
        destination = 'cloud/' + name
        parts.append('diff --git a/' + destination + ' b/' + destination + '\n')
        if name in ADDED:
            parts.append('new file mode 100644\n')
        parts.extend(difflib.unified_diff(old.splitlines(keepends=True), new.splitlines(keepends=True),
            fromfile='a/' + destination if name in CHANGED else '/dev/null', tofile='b/' + destination))
        records.append({'target': destination, 'candidate': 'server/' + name,
                        'baseSha256': expected.get(name), 'candidateSha256': sha(ROOT / 'server' / name)})
    patch = ROOT / 'integration.patch'
    patch.write_text(''.join(parts), encoding='utf-8', newline='\n')
    # Never apply to the source project. The smoke checkout is a new child path.
    smoke = Path(tempfile.mkdtemp(prefix='patch-smoke-', dir=ROOT / 'work'))
    destination = smoke / 'cloud'
    destination.mkdir(parents=True)
    for name in expected:
        shutil.copy2(baseline / name, destination / name)
    commands = (["git","-c","core.autocrlf=false", "apply", "--check", "--ignore-space-change", str(patch)],
                ["git","-c","core.autocrlf=false", "apply", "--ignore-space-change", str(patch)])
    checks = []
    for command in commands:
        completed = subprocess.run(command, cwd=smoke, capture_output=True, text=True, encoding='utf-8', errors='replace')
        checks.append({'command': command, 'exitCode': completed.returncode, 'output': completed.stdout + completed.stderr})
        if completed.returncode:
            (ROOT / 'work/PATCH-SMOKE.json').write_text(json.dumps(checks, ensure_ascii=False, indent=2), encoding='utf-8')
            raise RuntimeError('Patch failed in isolated smoke checkout')
    for name in CHANGED + ADDED:
        if (destination / name).read_bytes() != (ROOT / 'server' / name).read_bytes():
            raise RuntimeError('Patched bytes differ from tested candidate: ' + name)
    (destination/'site/assets').mkdir(parents=True)
    node=r'C:\积木软件工坊\核心组件\社媒人设与内容运营组件库\runtime\tools\node-v22.23.4-win-x64\node.exe'
    environment=dict(os.environ,NODE_PATH=r'C:\积木软件工坊\项目\方隅公寓客户版\work\cloud\workspace\node_modules')
    loaded=subprocess.run([node,'-e',"const p=require('./cloud/index.js');if(typeof p.createStore!=='function')process.exit(2);require('./cloud/content_contract.cjs');"],
                          cwd=smoke,env=environment,capture_output=True,text=True,encoding='utf8',errors='replace')
    assert loaded.returncode==0, 'Isolated production dependency closure cannot load'
    result = {'candidateRevision':2,'authoritativeSourceUnchanged': True, 'modifiedServerFiles': len(CHANGED), 'newServerFiles': len(ADDED),
              'liveCodeSha256':manifest['liveCode']['codeSha256'],'isolatedProductionImportsPassed':True,
              'patchRoot':'cloud/; apply only to an explicitly prepared copy of the verified live source',
              'smokeDirectory': str(smoke),
              'checks': checks, 'patchedTextMatchesTestedCandidate': True,'patchedBytesMatchTestedCandidate':True,
              'lineEndings': 'Exact raw byte comparison after git apply; preserves catalog CRLF/LF authentication.',
              'records': records, 'client': [{'path': name, 'sha256': sha(ROOT / name)} for name in CLIENT],
              'patchSha256': sha(patch)}
    (ROOT / 'PATCH-MANIFEST.json').write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
    code_files = tuple('server/' + name for name in CHANGED + ADDED) + CLIENT
    code_manifest = {'scope': 'Reviewed candidate only; no deployment or live provider calls',
                     'files': [{'path': name, 'bytes': (ROOT / name).stat().st_size, 'sha256': sha(ROOT / name)}
                               for name in code_files],
                     'candidateRevision':2,'liveCodeSha256':manifest['liveCode']['codeSha256'],
                     'requiredUnmodifiedOriginals': {name: expected[name] for name in ('ai_provider.cjs','approved_intent_policy.json','readonly_routes.cjs','devices.cjs')},
                     'trustedMethodSourceSha256': '60806e678ed6a96a7f3a7a3116a20024e97ac648f59c16cf5cf0eb8838e6b094',
                     'serverEnabledByDefault': False, 'mockOutputsInProduction': False}
    (ROOT / 'CANDIDATE-FILES.json').write_text(json.dumps(code_manifest, ensure_ascii=False, indent=2), encoding='utf-8')
    package = ROOT / 'content-model-gateway-candidate-v2.zip'
    documents = ('README.md', 'ADAPTER.md', 'HANDOFF.md', 'TEST-SEAMS.md', 'GLOSSARY.md',
                 'SCOPE-REVIEW.md', 'METHODS-PINS.json', 'PATCH-MANIFEST.json', 'integration.patch',
                 'VERIFICATION.json','CANDIDATE-FILES.json','baseline/LIVE-CLOUD-SHA256.json',
                 'PROFILE-CONTRACT.md','DEPLOYMENT-READINESS.md')
    with zipfile.ZipFile(package, 'w', zipfile.ZIP_DEFLATED) as archive:
        for relative in tuple('server/' + name for name in CHANGED + ADDED) + CLIENT + documents:
            archive.write(ROOT / relative, relative)
    print(json.dumps({'patch': str(patch), 'package': str(package), 'packageSha256': sha(package),
                      'files': len(CHANGED) + len(ADDED) + len(CLIENT) + len(documents),
                      'patchedTextMatchesTestedCandidate': True}, ensure_ascii=False))


if __name__ == '__main__':
    main()
