from pathlib import Path
import hashlib,json,datetime
W=Path(__file__).resolve().parent;C=W/'source-candidate';B=W/'compiled-probe-final'
P=W.parents[2];A=W.parent/'f82-standard-package-candidate'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text('utf-8-sig'))
def save(p,value):p.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n','utf-8')
assert sha(A/'FINAL-RECEIPT.json')=='69d0b8946a3da256e4101cd3842c7fa8eb294843796518caaa63faffc83a377b'
assert sha(A/'EVIDENCE-PINS.json')==read(A/'FINAL-RECEIPT.json')['evidenceManifestSha256']
base=A/'standard-held-clean-v82/payload/project';bm=base/'SHIPPED-PINS.json'
anchored=[row['sha256'] for row in read(A/'EVIDENCE-PINS.json')['files'] if row['path'].replace('\\','/').endswith('/project/SHIPPED-PINS.json')]
assert sha(bm) in anchored,'Base payload must equal the sealed actual distribution closure'
for row in read(bm)['files']:
    path=base/row['path'];assert path.stat().st_size==row['bytes'] and sha(path)==row['sha256'],row['path']
source_rows=read(W/'SOURCE-FILES.json')['files']
fixed=Path(read(W/'BASELINE.json')['fixedInput'])
for row in source_rows:
    assert sha(C/row['path'])==row['sha256']
    if row['beforeSha256'] is not None:assert sha(fixed/row['path'])==row['beforeSha256']
dist=B/'dist/FangyuWorkbench';project=dist/'project';inputs=read(B/'PROBE-INPUTS.json')
release=project/'work/ui-native-r57/releases'/inputs['release_id']
assert sha(project/'SHIPPED-PINS.json')==inputs['closure_sha256']
assert sha(release/'RELEASE.json')==inputs['release_sha256']
for row in read(project/'SHIPPED-PINS.json')['files']:
    path=project/row['path'];assert path.stat().st_size==row['bytes'] and sha(path)==row['sha256'] and path.stat().st_nlink==1,row['path']
mapping=[]
for row in source_rows:
    rel=row['path'];path=project/rel
    if '/customer-read/' in rel:path=release/'resources/customer-read'/Path(rel).name
    assert sha(path)==row['sha256'],rel
    mapping.append({'candidate':rel,'actualCompiledPath':path.relative_to(W).as_posix(),'sha256':sha(path)})
result=dist/'factory-f73ab4861a114d3cb2e4724ed103f823/RESULTS.json'
source_result=B/'payload/source-factory-921fe09da87a4d2b90f6a73f306536b4/RESULTS.json'
assert read(result)['status']=='PASS' and read(result)['groupCount']==12 and read(result)['actualCompiledExe'] is True
assert read(source_result)['status']=='PASS' and len(read(source_result)['groups'])==2
assert read(W/'CLEANUP.json')['ownProcessCount']==0
assert sha(dist/'FangyuWorkbench.exe')==read(B/'BUILD-RECEIPT.json')['exe_sha256']
assert sha(B/'probe_entry.py')==read(B/'BUILD-RECEIPT.json')['entry_sha256']
runtime=[{'path':path.relative_to(dist).as_posix(),'bytes':path.stat().st_size,'sha256':sha(path)}
    for path in sorted((dist/'_internal').rglob('*')) if path.is_file()]
save(W/'ACTUAL-COMPILED-INPUTS.json',{'baseSealedShippedFilesVerified':len(read(bm)['files']),
    'finalShippedFilesAfterOwnTamperRestoredVerified':len(read(project/'SHIPPED-PINS.json')['files']),
    'sourceMapping':mapping,'runtimeFiles':runtime,'ownCompiledExeSha256':sha(dist/'FangyuWorkbench.exe'),
    'actualCompiledResultSha256':sha(result),'actualSourceResultSha256':sha(source_result),
    'f82OriginalSourceFilesUnchanged':True,'sourceCandidateFiles':len(source_rows)})
save(W/'IN-PROGRESS.json',{'status':'FINAL_SEALED','ownServicesClosed':True,'ownProcesses':0,
    'actualCompiledGroups':12,'actualSourceGroups':2,'productWrites':False,'platformRequests':0})
selected=set(path for path in W.iterdir() if path.is_file() and path.name not in ('FINAL-RECEIPT.json','SEALED.json','EVIDENCE-PINS.json'))
selected.update(path for path in C.rglob('*') if path.is_file())
for root in [path for path in W.iterdir() if path.is_dir() and path.name.startswith('compiled-probe')]:
    for pattern in ('*.json','*.log','*.py','*.spec'):
        selected.update(root.glob(pattern))
    for pattern in ('**/factory-*/RESULTS.json','**/factory-*/HTTP.json','**/factory-*/ERROR.json','**/source-factory-*/RESULTS.json','**/source-factory-*/ERROR.json','**/FangyuWorkbench.exe'):
        selected.update(root.glob(pattern))
selected.update([project/'SHIPPED-PINS.json',project/'HELD-STANDARD-MANIFEST.json',release/'RELEASE.json',
    release/'resources/backend-dependencies.json',release/'resources/platform-runtime/vendor-src/SOURCE.json'])
pins=[{'path':path.relative_to(W).as_posix(),'bytes':path.stat().st_size,'sha256':sha(path)} for path in sorted(selected) if path.is_file()]
save(W/'EVIDENCE-PINS.json',{'schema':'customer-read-bounded-evidence-manifest-v1','files':pins,
    'excluded':'Reproducible build caches, repeated runtime copies and synthetic DB/vault files; final runtime and full project fixed by ACTUAL-COMPILED-INPUTS and SHIPPED.'})
final={'schema':'customer-read-purpose-candidate-final-v1','createdUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'status':'CANDIDATE_READY_FOR_INDEPENDENT_REVIEW_NOT_COMMERCIAL_RELEASE','sourceFiles':len(source_rows),
    'sourceFilesSha256':sha(W/'SOURCE-FILES.json'),'patchSha256':sha(W/'CANDIDATE.patch'),
    'interfaceSha256':sha(W/'INTERFACE.md'),'mergeRepinSha256':sha(W/'MERGE-REPIN.md'),
    'actualCompiledExeSha256':sha(dist/'FangyuWorkbench.exe'),'actualCompiledResult':result.relative_to(W).as_posix(),
    'actualCompiledGroups':12,'actualSourceResult':source_result.relative_to(W).as_posix(),'actualSourceGroups':2,
    'actualInputsSha256':sha(W/'ACTUAL-COMPILED-INPUTS.json'),'evidenceManifestSha256':sha(W/'EVIDENCE-PINS.json'),
    'ownProcesses':0,'ownServicesClosed':True,'productionWrites':False,'platformRequests':0,'modelRequests':0,
    'normalOwnCloudContractUsed':True,'internalQaPermitOrScopeInjected':False,
    'nativePlatformAndRealCloudUnverified':True,'readinessReviewFinal':'d99c908febf0a388e57d6b9537680f063d008126d96bb210973f6b04fe463a02',
    'next':'Independent review; root actual merged byte repin/freeze/compiled/normal real customer enrollment and platform verification separately.'}
save(W/'FINAL-RECEIPT.json',final)
save(W/'SEALED.json',{'schema':'customer-read-purpose-seal-v1','finalSha256':sha(W/'FINAL-RECEIPT.json'),
    'sourceFilesSha256':sha(W/'SOURCE-FILES.json'),'evidenceManifestSha256':sha(W/'EVIDENCE-PINS.json'),
    'ownServicesClosed':True,'candidateStoppedWriting':True})
print(json.dumps({'FINAL':sha(W/'FINAL-RECEIPT.json'),'SEALED':sha(W/'SEALED.json'),
    'SOURCE':sha(W/'SOURCE-FILES.json'),'PATCH':sha(W/'CANDIDATE.patch'),'files':len(source_rows)},ensure_ascii=False))
