from pathlib import Path
import ast,difflib,hashlib,json,datetime
W=Path(__file__).resolve().parent;A=W.parent/'customer-read-purpose-after-f82-candidate';P=W.parents[2]
B=P/'work/parallel-integration-20261018/final-integration/candidate-unified-v82/project'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
manifest=json.loads((A/'SOURCE-FILES.json').read_bytes());rows=[]
allowed={
 'work/ui-native-r57/ui_native_host.py':{'create_backend'},
 'work/ui-native-r57/freeze_ui.py':{'main'},
 'work/shared-backend-integration/platform_runtime.py':{'PlatformRuntime.__init__'},
 'work/shared-backend-integration/vendor-src/app.py':{'AppServer.__init__','AppServer._runtime_license_usage_scope'},
 'work/shared-backend-integration/vendor-src/assistant/douyin_connection_service.py':{'_components'},
 'work/ui-runtime-r55/src/core/douyin_comments_policy.py':{'DouyinCommentsPolicy._snapshot','DouyinCommentsPolicy.resolve'}}
def methods(raw):
 result={}
 for n in ast.parse(raw).body:
  if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)):result[n.name]=ast.dump(n,include_attributes=False)
  elif isinstance(n,ast.ClassDef):
   for f in n.body:
    if isinstance(f,(ast.FunctionDef,ast.AsyncFunctionDef)):result[n.name+'.'+f.name]=ast.dump(f,include_attributes=False)
 return result
for r in manifest['files']:
 rel=r['path'];path=A/'source-candidate'/rel;raw=path.read_bytes();assert sha(path)==r['sha256']
 if r['beforeSha256'] is not None:
  assert sha(B/rel)==r['beforeSha256'];old=(B/rel).read_bytes()
  m,n=methods(old),methods(raw);changed={k for k in m if m[k]!=n.get(k)}
  assert changed==allowed[rel],(rel,changed)
  rows.append({'path':rel,'originalSha256':sha(B/rel),'candidateSha256':sha(path),'changedOriginalMethods':sorted(changed),'newMethods':sorted(set(n)-set(m)),'unchangedOriginalMethods':len(m)-len(changed),'beforeCRLF':old.count(b'\r\n'),'afterCRLF':raw.count(b'\r\n'),'beforeLoneLF':old.count(b'\n')-old.count(b'\r\n'),'afterLoneLF':raw.count(b'\n')-raw.count(b'\r\n')})
 else:
  assert not (B/rel).exists()
  if path.suffix=='.py':ast.parse(raw)
carrier=(A/'source-candidate/work/shared-backend-integration/customer_read_distribution.py').read_text('utf-8')
assert "_PURPOSES = frozenset(('douyin_owned_connection', 'douyin_owned_video_comments'))" in carrier
assert 'info.st_nlink != 1' in carrier and 'not getattr(sys, \'frozen\', False)' in carrier
assert 'type(server) is not AppServer' in carrier and 'self._token is not _TOKEN' in carrier
assert "'public_send_grant': False" in carrier and "'dm': False" in carrier and "'search': False" in carrier
report={'status':'STATIC_PRESEAL_OBSERVATION_NOT_ACCEPTANCE','observedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceManifestObservedSha256':sha(A/'SOURCE-FILES.json'),'sourceFiles':len(manifest['files']),'originalMethodBoundaries':rows,'observations':['Only manifest-verifying frozen host constructs carrier; source normal host ignores present index.','Exactly two Douyin purposes; XHS interface returns original schema for original independent policy, no attached review in this candidate.','Original source binding, DeviceSession, Runner, account ownership, lease and sends unchanged by AST.','Customer scope is component material scope, never employee/device/platform enrollment.','Material whole ancestry/no reparse/regular/singlelink and before-after identity checked.','Source line endings normalized by author; no byte-equivalence claim.','Material examples bind exact author-derived closure; final aggregate must re-derive, not copy approval.'],'candidateExecutionBeforeSeal':False,'liveOrProductionRead':False}
(W/'STATIC-PRESEAL.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n','utf-8')
print(json.dumps({'status':report['status'],'files':len(manifest['files']),'changedMethods':[r['changedOriginalMethods'] for r in rows]},ensure_ascii=False))
