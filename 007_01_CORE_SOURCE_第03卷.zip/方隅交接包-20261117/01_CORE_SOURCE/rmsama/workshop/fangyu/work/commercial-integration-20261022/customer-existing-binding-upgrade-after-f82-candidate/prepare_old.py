"""Own old binding factory: original F82 Service, explicit legacy version only."""
from pathlib import Path
import ast,hashlib,json,shutil
T=Path(__file__).resolve().parent;P=T.parents[2];W=T.parent
A=W/'f82-standard-package-candidate';BASE=A/'standard-held-clean-v82'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_bytes())
def save(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((json.dumps(v,ensure_ascii=False,indent=2)+'\n').encode())
assert sha(A/'FINAL-RECEIPT.json')=='69d0b8946a3da256e4101cd3842c7fa8eb294843796518caaa63faffc83a377b'
B=T/'old-binding';PROJECT=B/'payload/project';assert not PROJECT.exists()
shutil.copytree(BASE/'payload/project',PROJECT)
rid=read(BASE/'STAGE.json')['releaseId'];R=PROJECT/'work/ui-native-r57/releases'/rid
company=read(PROJECT/'work/app/company.json');company['releaseVersion']='1.1.8-pilot.1'
save(PROJECT/'work/app/company.json',company);save(B/'payload/company.json',company)
guard=R/'resources/platform-runtime/vendor-src/assistant/employee_distribution.py'
contract=read(PROJECT/'HELD-STANDARD-MANIFEST.json')
contract['companyConfigDigest']=hashlib.sha256(json.dumps(company,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
excluded={guard.relative_to(PROJECT).as_posix(),(R/'RELEASE.json').relative_to(PROJECT).as_posix()}
contract['codeFiles']=[{'path':p.relative_to(PROJECT).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p)}
    for p in sorted(PROJECT.rglob('*')) if p.is_file() and p.relative_to(PROJECT).as_posix() not in excluded and p.suffix.lower() in ('.py','.js','.mjs','.exe','.dll','.pyd')]
contract['codeFileCount']=len(contract['codeFiles'])
assert contract['commercialDistributionApproved'] is False and contract['platformExecutionApproved'] is False
save(PROJECT/'HELD-STANDARD-MANIFEST.json',contract)
original=P/'work/parallel-integration-20261018/final-integration/candidate-unified-v82/project/work/shared-backend-integration/vendor-src/assistant/employee_distribution.py'
text=original.read_text('utf-8').replace('\r\n','\n');needle='def runtime_config_valid(config):\n';assert text.count(needle)==1
text=text.replace(needle,needle+'    if held_standard_config_valid(config):\n        return True\n')
text+=(A/'held_standard_contract.py.in').read_text('utf-8').replace('@@MANIFEST_SHA@@',repr(sha(PROJECT/'HELD-STANDARD-MANIFEST.json')))
ast.parse(text);guard.write_bytes(text.encode())
release=read(R/'RELEASE.json');release['files']=[{'path':p.relative_to(R).as_posix(),'size':p.stat().st_size,'sha256':sha(p).upper()}
    for p in sorted(R.rglob('*')) if p.is_file() and p.name!='RELEASE.json'];save(R/'RELEASE.json',release)
closure=read(PROJECT/'SHIPPED-PINS.json');closure['files']=[{'path':p.relative_to(PROJECT).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p)}
    for p in sorted(PROJECT.rglob('*')) if p.is_file() and p.name!='SHIPPED-PINS.json'];save(PROJECT/'SHIPPED-PINS.json',closure)
entry=(A/'standard_entry.py.in').read_text('utf-8')
for key,value in [('RELEASE_ID',rid),('RELEASE_SHA',sha(R/'RELEASE.json')),('CLOSURE_SHA',sha(PROJECT/'SHIPPED-PINS.json'))]:entry=entry.replace('@@'+key+'@@',repr(value))
tree=ast.parse(entry);tree.body=tree.body[:-1];(B/'standard_loader_prefix.py').write_bytes((ast.unparse(tree)+'\n').encode())
save(B/'PREPARATION.json',{'status':'OLD_BINDING_PREPARED_NOT_EXECUTED','version':'1.1.8-pilot.1',
    'actualServiceSource':str(R/'resources/platform-runtime/vendor-src/assistant/service.py'),
    'originalF82ServiceSha256':sha(R/'resources/platform-runtime/vendor-src/assistant/service.py'),
    'releaseSha256':sha(R/'RELEASE.json'),'closureSha256':sha(PROJECT/'SHIPPED-PINS.json'),
    'newCustomerCarrierOrLeaseInjected':False,'portableOrQaIdentityAdded':False,
    'purpose':'Original actual Service.bind only; not a claim of old platform execution or commercial approval'})
print(json.dumps({'status':'PREPARED','oldServiceSha256':sha(R/'resources/platform-runtime/vendor-src/assistant/service.py'),'newStageDependency':'await final revision5 seal'}))
