from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
D=Path(__file__).resolve().parent
T=D/'cloud-candidate-final'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text('utf-8-sig'))
source=read(D/'SOURCE-CANDIDATE.json')
for row in source['sourceFiles']:
    assert sha(T/row['path'])==row['afterSha256']
result=read(D/'CLOUD-SERVICE-TEST-RESULTS.json')
assert result['status']=='PASS' and result['groups']==10 and result['actualServiceRequests']==43
assert result['externalCloudRequests']==result['platformRequests']==result['productionWrites']==0
pins=[{'path':str(p.relative_to(D)).replace('\\','/'),'sha256':sha(p),'bytes':p.stat().st_size}
      for p in [D/'CUSTOMER-READ-LEASE-SPEC.json',D/'HANDSHAKE-ADDENDUM.md',D/'test_customer_read_cloud.cjs',D/'CLOUD-SERVICE-TEST-RESULTS.json',D/'SOURCE-CANDIDATE.json']]
report={'status':'ROOT_SOURCE_SERVICE_VALIDATED_NOT_DEPLOYED','utc':datetime.now(timezone.utc).isoformat(),
    'sourceFiles':source['sourceFiles'],'evidenceFiles':pins,'originalCloudFactory':True,
    'groups':10,'actualServiceRequests':43,'defaultClosed':True,'originalEmployeeResponseCompared':True,
    'productionOrEnvironmentOrPrivateStateWritten':False,'realCloudOrPlatformVerified':False,
    'knownPending':['client original Runner/DPAPI/DeviceSession integration','independent review','actual code and config deployment/readback','ordinary compiled package with final review materials','Native/platform/second PC'],
    'firstAttemptPreserved':{'folder':'cloud-candidate','reason':'constructor exact LF/CRLF assertion; no production write'},
    'actualRuntimeSnapshot':{'path':'../status-visibility/CURRENT-STATUS-20261023T120826Z.json','sha256':sha(D.parent/'status-visibility/CURRENT-STATUS-20261023T120826Z.json')}}
(D/'ROOT-SOURCE-SERVICE-REVIEW.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n','utf-8')
print(json.dumps({'status':report['status'],'reviewSha256':sha(D/'ROOT-SOURCE-SERVICE-REVIEW.json')},ensure_ascii=False))
