---
name: xhs-visual-lab
description: >-
  Design carousel covers, carousel slide systems, and video first frames from account DNA, title, proof, and format mode.
  Use for 封面, 首帧, 轮播视觉, A/B视觉, slide 排版方案, or feed-scale readability review before asset production.
---

# Xiaohongshu Visual Lab

Produce visual decisions and production briefs before generating assets. This skill does not publish.

Read `../references/format-playbook.md` and `references/layout-readability-gate.md`.

## Mode switch (required)

| Mode | Use when | Deliverable |
|---|---|---|
| `carousel_cover` | image/carousel note | 3:4 cover brief + thumbnail test |
| `carousel_slide_system` | 6+ slide tutorial/list | slide hierarchy + repeated visual system |
| `video_first_frame` | video note | first-frame brief matching second 0-3 |

Ask once if mode is unclear. Do not design a cover when the user is making a video unless they also need a custom upload frame.

## Workflow

1. Read account DNA and inspect face/product/screenshot/reference images.
2. Reduce to one primary promise + one proof object.
3. Create three distinct directions:
   - emotion/conflict
   - result/proof
   - saveable framework/list
4. Specify hierarchy, crop, palette, typography, proof placement.
5. For `video_first_frame`, require continuity with the opening shot plan from `xhs-video-director`.
6. For `carousel_slide_system`, assign one job per slide; slide 1 must not duplicate the cover.
7. Evaluate with `references/visual-checklist.md` and `references/layout-readability-gate.md`.
8. Recommend one direction + tradeoffs.
9. If generation is requested, output prompts/brief via `assets/cover-brief-template.md`.

## Rules

- Optimize for feed thumbnail readability.
- One headline, one qualifier, one proof object on covers.
- Preserve creator identity and product truth.
- Avoid repeating the same dark template every post.
- Video first frame must match the first 3 seconds, not the caption paragraph.

## Output

- mode
- three concepts
- thumbnail-readability checks
- recommended direction
- production brief / generation prompt
- layout gate pass or repair notes
