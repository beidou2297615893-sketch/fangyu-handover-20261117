# 普通 clean-held 后继制作工具

这里只是可执行制作工具，未提供或伪造新正式版本 pins，未实际 stage/finalize/build 新版，也未编译、安装、启动产品。原 F82 与所有正式目录均未修改。缺实际最终源闭包时必须停在准备完成；局部夹具通过不是 F83 或后继版本验收。

`build_clean_next.py` 精确派生自原 F82 成熟工具（SHA `4e686e224c64a06f13cd6fbd448af7bddc2106b8b092d567b94f36bb2e36cfd8`）。原 `sha/js/dump/safe_read/own_environment/run` 六函数 AST 完全保留；原函数仅 stage/build/main 调整。原模板及 protected installer（`5f9b4d7ab00b6348d07d15a241ad804cf593ec137d576e5a3ce67476df01dca9`）不改。`DERIVATION-FINAL.json` 与 `BUILDER-DIFF.patch` 给出最终差异。

每一步都须传实际 root descriptor 的绝对路径和精确 SHA，以及实际外置 CLI descriptor 的路径和精确 SHA。root descriptor 沿成熟字段：`candidate`、`rootExplicitFinalPins:true`、`unifiedPinsSha256`、`unifiedFileCount`、`stagedSha256`、`releaseId`、`manifestSha256`；candidate 必须与实际 `candidate-unified-v<version>` 一致。版本必须晚于82，拒 `fixtureOnly:true`、缺 descriptor、错 SHA、旧闭包和任意非固定 base。工具不会自行生成“root 已验收”的 descriptor。

命令形状（所有尖括号都必须由 root 的真实输入替换）：

```
python.exe -I -B build_clean_next.py --stage --version <真实版本整数> --base <实际candidate根> --root-pins <实际root文件> --root-pins-sha256 <实际SHA> --external-payloads <实际CLI清单> --external-payloads-sha256 <实际SHA>
```

同一组固定输入再次使用 `--finalize` 或 `--build`，三个动作互斥。只会写工具所在目录下 `standard-held-clean-v<version>`。`--build` 只有在同一组输入的 finalize 完成、entry/inspection/全部payload实际字节未改变后才能进入原编译流程。这里不实际调用它。

执行顺序：

1. stage 先把公司 `releaseVersion` 固定为 `1.2.0-read.1`，随后生成成熟 HELD manifest 与兼容 helper；保持 release_approved=False、public_send_hold=True、xiaohongshu_automation=hold、no portable/no QA，并复制唯一外置 CLI 到 payload sibling。stage 此时不生成最终 SHIPPED 或 entry，状态明确为等待用途材料、不可 build。
2. root 用最终实际 payload 字节生成三DY材料。只接受 `three-douyin-customer-materials-after-f82-candidate/revision-4/customer_review_rebinder_v4.py`，SHA `831865fc8a79dbb322763f458be91fdb48fd0d65e2c33f70293cfd154f237db4`，FINAL `7f220e18a1e4c423227291f61ec5c83591472778b67d3ce2e36394f44f8df4ac`、SEALED `62b16e69be01e3fc3623598310114173d6c74580aaeea9cba2b6b684757e2906`。旧两purpose工具与v3不可替代。
3. root 再运行封定的 XHS CLI 材料生成，再由 knowledge 最终自然3生成器追加材料。此工具不自动调用/猜测这些生成器，也不会把 source/license 审查升为账号、云、Native或平台许可。七个独立purpose必须完整保留。
4. finalize 校验 held helper/完整code清单仍稳定、两份自然helper真实闭包一致、外置CLI未变、全部七用途材料与当前版本、文件SHA/长度吻合，所有外部未验字段保持False。随后只按实际树重算 RELEASE/SHIPPED，计算当前源的 stdlib union，按原 CLEAN_ENTRY AST 步骤移除QA分支，再调用已封 `adapt_clean_entry.py`（`4b41e4d4c5ec1bcaafbb17c41b1489d15429a5b1313586ec56a467acc8a8b405`）。默认资料位置仍原普通用户目录；只有明确传入原project和binding hash才沿原 DPAPI/Workspace verifier选择资料，程序代码仍当前包自身。
5. root 才统一调用 build：仍原 PyInstaller collect-all、模板、slim流程和 protected SFX installer；只复制 `project`、`company.json`、`platform-cli-customer-read` 三项，不盲拷其它 sibling、QA、数据或 vault。最终 outer FILE-MANIFEST 覆盖 CLI 与自然helper实际所有字节，index不反嵌主EXE SHA。

最终自然helper唯一路径已按真实工厂红例纠正：source input 为 `project/work/source-v66-worker/component/artifacts/xhs-page-helper/FangyuXhsPageHelper/`，freeze固定复制到当前 release 的 `resources/xhs-page-helper/FangyuXhsPageHelper/`；两份377文件/manifest `576a60b99eb5f75d6a85b26c2713d5d080552b788b2fe9863746d1337ebce76d`须完全吻合。r55/src不得包含EXE/DLL/PYD。此前 r55/src/resources 合同已撤回，不能再使用；不创建自然helper program sibling，runtime仍只读typed authority._release。

唯一 program sibling 是 `platform-cli-customer-read`。外置清单 schema=`fixed_customer_read_sibling_payload_v1`，精确字段：`schema,name,source,files,public_send_grant:false,login_grant:false,dataIncluded:false`；files每项 `{path,bytes,sha256}` 覆盖完整真实树，source是绝对固定目录。CLI exe/guard必须在清单里，guard仍 customer_distribution_read_only、六个原只读命令、无登录/发送批准。拒额外文件、链接、hardlink、Python缓存、QA/private/model内容和其它 sibling。

`prepare_external_descriptor.py` 可对 root 指定且已封回执固定的实际 CLI 作只读完整清单快照，仅在本工具目录新建清单和来源记录；它不执行CLI，也不声称回执内每项工件已独立验收。root 必须审真实快照后才把其SHA交给 builder。参数为 `--source <实际platform-cli-customer-read根> --source-receipt <实际封定回执> --source-receipt-sha256 <实际SHA> --output-name <新清单名.json>`。不要拿测试目录的合成文件清单做交付。

局部验证6组只覆盖工具接口、原entry函数/缓存guard AST、已封适配器、公司先固定版本/hold、关闭的外置清单复制、缓存/hardlink/路径拒、七用途材料缺失或过时拒绝。未调用编译器/installer/产品，未获取正式root pins，也未验证最终源码组合、最终 EXE、实际 Native、目标普通电脑或真实平台。工具本身的 green 不代表这些门已通过。
