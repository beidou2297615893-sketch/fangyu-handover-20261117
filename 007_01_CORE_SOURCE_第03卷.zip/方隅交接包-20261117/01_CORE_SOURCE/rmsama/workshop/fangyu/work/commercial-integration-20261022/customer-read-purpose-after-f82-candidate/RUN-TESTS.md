# 重用入口与参数

不要在本sealed目录重跑生成脚本。独审可copy2最终 `compiled-probe-final/dist/FangyuWorkbench` 整棵自有QA运行目录到独立目录，再运行其中 `FangyuWorkbench.exe --owned-customer-read-probe`；它由真实exe相对定位project/qa-fixtures并创建新factory，12组均不访问平台或Native。保留普通环境隔离的 TEMP/TMP/LOCALAPPDATA/APPDATA 指向独审自有目录。

需要独立改入口/断言才复制 source-candidate、下列脚本及模板到同级独立W后执行：

1. `python -X utf8 prepare_probe.py own-compiled`：验证固定F82作者FINAL，复制原clean公开项目，应用7源，按自身真实字节重建held兼容清单及79/88用途材料、RELEASE/SHIPPED；原held决策保持False。不触原包。
2. `python -X utf8 prepare_entry.py own-compiled`：从现有成熟自有cloud夹具提取最少定义，创建自身qa-fixtures与两个入口；已有输入不同则拒绝覆盖。
3. `python -X utf8 own-compiled/source_entry_check.py`：实际非frozen Source/index两个原factory反例与正例。
4. `python -X utf8 build_probe.py own-compiled`：原普通 F82 spec，仅改自有entry路径/console；PyInstaller环境缓存/TEMP/APPDATA均在自身B目录，最长600秒，隐藏子窗口。
5. 隐藏进程运行 `own-compiled/dist/FangyuWorkbench/FangyuWorkbench.exe --owned-customer-read-probe`，最长180秒；结果在其自身新factory-*目录。只用自身输出，完成关闭服务。

上述四份新JSON按生成时的真实审查日期/源字节绑定，自身重派生可能具有不同SHA，不应预期与作者byte-for-byte相同；输入代码与断言的来源对应要独立记录。测试边界是自有云合同响应，未走真人云注册/自然登录/平台。最终代码已通过真实compiled12+真实source2；旧RED目录仅用于定位，不要作为最终输入。
