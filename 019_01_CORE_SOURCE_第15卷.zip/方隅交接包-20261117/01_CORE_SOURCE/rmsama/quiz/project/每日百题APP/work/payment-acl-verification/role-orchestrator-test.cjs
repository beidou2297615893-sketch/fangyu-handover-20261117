'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict'),{run}=require('./role-orchestrator.cjs');
const fn='dailyHundredPaymentProbeV1',env='fh6-d5ga45c0ddae7008c',initial='22f1d70988a09c3fcdbd675ceec80ce278c60e14b87810b63fa0a8e75103f09e';
function fixture(fault=''){
 const state={updated:false,marked:false,invoked:[],delays:0},old={functionId:'id-a',name:'translation',runtime:'Nodejs20.19',modifyTime:'1',status:'Active'},probe={functionId:'probe',name:fn,runtime:'Nodejs20.19',modifyTime:'2',status:'Active'};
 const route={domain:'old.invalid',path:'/old',upstreamResourceName:'translation',upstreamResourceType:'function',enable:true,enableAuth:false,enablePathTransmission:true};
 const adapter={packageHash:'a'.repeat(64),async mark(){state.marked=true},async updateCode(){if(fault==='timeout')throw Error();state.updated=true;return {RequestId:'fake'}},async getCodeHash(){return fault==='wrong-original'&&!state.updated?'b'.repeat(64):fault==='wrong-new'&&state.updated?'b'.repeat(64):state.updated?'a'.repeat(64):initial},async delay(){state.delays++},async call(a){
  if(a[0]==='fn'&&a[1]==='list')return [old,probe];if(a[0]==='routes')return [state.updated&&fault==='route-change'?{...route,path:'/changed'}:route];
  if(a.includes('GetFunction'))return {FunctionName:fn,Namespace:env,Type:'Event',Runtime:'Nodejs20.19',Handler:'isolated-probe.main',Status:'Active',Role:fault==='role'?'wrong':'TCB_QcsRole',Environment:{Variables:[]}};
  if(a.includes('ListTriggers'))return {TotalCount:fault==='trigger'?1:0};
  if(a[0]==='permission')return {PermissionList:[{Resource:a[2].split(':')[1],Permission:fault==='acl'?'READONLY':'ADMINONLY'}]};
  if(a[0]==='fn'&&a[1]==='invoke'){const action=JSON.parse(a[a.indexOf('-d')+1]).action;state.invoked.push(action);return {functionType:'Event',InvokeResult:0,RetMsg:JSON.stringify(action==='verify-transaction'?{verified:fault!=='transaction-failed',paymentEnabled:false}:{initialized:fault!=='policy-enabled',paymentEnabled:false})};}
  throw Error('unexpected');
 }};return {adapter,state};
}
test('only updates own verified probe then invokes fixed transaction and policy checks',async()=>{
 const f=fixture();assert.equal((await run(f.adapter)).verified,true);assert.equal(f.state.updated,true);assert.deepEqual(f.state.invoked,['verify-disabled-policy','verify-transaction','verify-disabled-policy']);
});
test('bad original hash, role, trigger, ACL or policy stop before code update',async()=>{
 for(const v of ['wrong-original','role','trigger','acl','policy-enabled']){const f=fixture(v);await assert.rejects(run(f.adapter));assert.equal(f.state.marked,false);assert.equal(f.state.updated,false);}
});
test('uncertain update, wrong new hash or old route change never runs transaction',async()=>{
 for(const v of ['timeout','wrong-new','route-change']){const f=fixture(v);await assert.rejects(run(f.adapter));assert.equal(f.state.marked,true);assert.ok(!f.state.invoked.includes('verify-transaction'));}
});
test('transaction failure does not report verified',async()=>{const f=fixture('transaction-failed');await assert.rejects(run(f.adapter));assert.equal(f.state.updated,true);});
