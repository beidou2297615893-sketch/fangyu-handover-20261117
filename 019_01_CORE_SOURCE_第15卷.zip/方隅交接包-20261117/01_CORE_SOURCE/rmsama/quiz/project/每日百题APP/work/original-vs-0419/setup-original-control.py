import control as c
from pathlib import Path
import subprocess,time
r=Path('V:/work/original-vs-0419')
def js(port,name):
    out=subprocess.check_output(['node',str(r/'cdp.cjs'),str(port),str(r/name)],timeout=15)
    print(out.decode(),flush=True)
def launch(pkg,component,port):
    c.adb('shell','am','start','-n',pkg+'/'+component);time.sleep(.8)
    pid=c.adb('shell','pidof',pkg).decode().strip()
    c.adb('forward','tcp:'+str(port),'localabstract:webview_devtools_remote_'+pid)
c.adb('reverse','tcp:18765','tcp:18765')
c.adb('install','-r',r/'original-control/source/android/app/build/outputs/apk/dev/debug/app-dev-debug.apk')
c.adb('shell','appops','set','com.futureyyy.tijing.dev','SYSTEM_ALERT_WINDOW','allow')
c.adb('shell','pm','grant','com.futureyyy.tijing.dev','android.permission.POST_NOTIFICATIONS')
launch('com.jimusoft.railwaymp.canvas419','com.jimusoft.railwaymp.MainActivity',18786)
js(18786,'start-hidden-host.js')
c.adb('shell','settings','put','secure','enabled_accessibility_services','com.futureyyy.tijing.dev/com.futureyyy.tijing.QuizAccessibilityService')
launch('com.futureyyy.tijing.dev','com.futureyyy.tijing.MainActivity',18787)
js(18787,'import-original-control.js')
js(18787,'start-original-control.js')
time.sleep(.5);c.click('START')
time.sleep(.5)
c.adb('shell','am','start','-n','com.jimusoft.railwaymp.canvas419/com.jimusoft.railwaymp.MainActivity')
time.sleep(.8);c.snap('original-control-ready')
print('Original control ready on the same first railway question.',flush=True)
