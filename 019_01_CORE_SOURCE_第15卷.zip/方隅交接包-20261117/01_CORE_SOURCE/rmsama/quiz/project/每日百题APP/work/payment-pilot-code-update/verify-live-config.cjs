'use strict';
const crypto=require('node:crypto'),{setTimeout:delay}=require('node:timers/promises');
async function verify(client,expected,{attempts=8,pause=1000}={}){try{
 if(expected?.FunctionName!=='dailyHundredBillingV1'||expected.Namespace!=='fh6-d5ga45c0ddae7008c'||!Array.isArray(expected.Environment?.Variables)||!Number.isInteger(attempts)||attempts<1||attempts>8)throw Error();
 const want=new Map();for(const x of expected.Environment.Variables){if(!x||typeof x.Key!=='string'||typeof x.Value!=='string'||want.has(x.Key))throw Error();want.set(x.Key,x.Value)}
 for(const key of ['BILLING_ENABLED','BILLING_NATIVE_ADMISSION_READY','BILLING_NATIVE_RELEASE_VERIFIED','BILLING_CLOUD_ACL_VERIFIED','BILLING_PILOT_ENABLED'])if(want.get(key)!=='true')throw Error();
 for(let i=0;i<attempts;i++){const d=await client.GetFunction({FunctionName:expected.FunctionName,Namespace:expected.Namespace});if(d?.FunctionName!==expected.FunctionName||d.Namespace!==expected.Namespace||d.Type!=='Event'||d.Runtime!=='Nodejs20.19'||d.Handler!=='production-entry.main')throw Error();if(d.Status==='Updating'){if(i+1<attempts)await delay(pause);continue}if(d.Status!=='Active'||!Array.isArray(d.Environment?.Variables)||d.Environment.Variables.length!==want.size)throw Error();const seen=new Set();for(const x of d.Environment.Variables){if(!x||typeof x.Key!=='string'||typeof x.Value!=='string'||!want.has(x.Key)||seen.has(x.Key))throw Error();seen.add(x.Key);const a=Buffer.from(x.Value),b=Buffer.from(want.get(x.Key));try{if(a.length!==b.length||!crypto.timingSafeEqual(a,b))throw Error()}finally{a.fill(0);b.fill(0)}}return true;}return false;
 }catch{return false}}
module.exports={verify};
