'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const {createLedger}=require('./free-ledger');

// Serializable, rollback-capable in-memory stand-in for SDK transactions.
function fakeDb(){
  let docs=new Map(),queue=Promise.resolve();
  return {runTransaction(fn){
    const work=queue.then(async()=>{
      const next=new Map([...docs].map(([k,v])=>[k,structuredClone(v)]));
      const tx={collection(){return {doc(id){return {async get(){return {data:next.has(id)?{_id:id,...structuredClone(next.get(id))}:null}},async set(v){const exists=next.has(id);next.set(id,structuredClone(v));return exists?{updated:1}:{updated:0,upserted:[{_id:id}]}}}}}}};
      const r=await fn(tx);docs=next;return r;
    });queue=work.catch(()=>{});return work;
  },snapshot(){return structuredClone([...docs]);}};
}
const digest='ab'.repeat(32),bind='cd'.repeat(32),other='ef'.repeat(32);
const setup=()=>{const db=fakeDb();return {db,ledger:createLedger({db,deviceKey:Buffer.alloc(32,7)})}};
test('upgrading used/reserved local records preserves all three consumed slots',async()=>{
  const {ledger}=setup();
  const m=await ledger.migrate(digest,{one:'used',two:'reserved',three:'used'});
  assert.equal(m.remaining,0);assert.equal(m.used,2);assert.equal(m.reserved,1);
  await assert.rejects(ledger.reserve(digest,'four',bind));
});
test('first successful migration survives same device reinstall; repeating cannot erase old usage',async()=>{
  const {db,ledger}=setup();await ledger.migrate(digest,{one:'used',two:'reserved'});
  const fresh=createLedger({db,deviceKey:Buffer.alloc(32,7)});
  const result=await fresh.migrate(digest,{});assert.equal(result.remaining,1);
  const storage=JSON.stringify(db.snapshot());assert.equal(storage.includes(digest),false);
});
test('a later legacy snapshot can only increase, never reset, the existing ledger',async()=>{
  const {ledger}=setup();await ledger.migrate(digest,{});
  await ledger.migrate(digest,{oldA:'used',oldB:'reserved'});
  assert.equal((await ledger.migrate(digest,{})).remaining,1);
  assert.equal((await ledger.migrate(digest,{oldB:'used'})).used,2);
});
test('conflicting over-capacity migration rolls back without overwriting existing usage',async()=>{
  const {ledger}=setup();await ledger.migrate(digest,{one:'used',two:'used'});
  await assert.rejects(ledger.migrate(digest,{three:'used',four:'used'}));
  assert.deepEqual(await ledger.status(digest),{used:2,reserved:0,remaining:1});
});
test('concurrent attempts cannot exceed three slots, same run is idempotent, changed binding fails',async()=>{
  const {ledger}=setup();await ledger.migrate(digest,{});
  const attempts=await Promise.allSettled(['a','b','c','d','e'].map(id=>ledger.reserve(digest,id,bind)));
  assert.equal(attempts.filter(r=>r.status==='fulfilled').length,3);
  const item=attempts.find(r=>r.status==='fulfilled').value;
  assert.equal((await ledger.reserve(digest,item.runId,bind)).status,'reserved');
  await assert.rejects(ledger.reserve(digest,item.runId,other));
});
test('confirm and release are idempotent and release does not free confirmed use',async()=>{
  const {ledger}=setup();await ledger.migrate(digest,{});
  await ledger.reserve(digest,'a',bind);await ledger.confirm(digest,'a',bind);
  await ledger.confirm(digest,'a',bind);await assert.rejects(ledger.release(digest,'a',bind));
  await ledger.reserve(digest,'b',bind);await ledger.release(digest,'b',bind);await ledger.release(digest,'b',bind);
  assert.equal((await ledger.status(digest)).remaining,2);
});
test('lost reserve or confirm response can be retried without consuming an extra slot',async()=>{
  const {ledger}=setup();await ledger.migrate(digest,{});
  await ledger.reserve(digest,'lost',bind);await ledger.reserve(digest,'lost',bind);
  await ledger.confirm(digest,'lost',bind);await ledger.confirm(digest,'lost',bind);
  assert.deepEqual(await ledger.status(digest),{used:1,reserved:0,remaining:2});
});
test('confirmed run may resume with its original binding and consumes no extra slot',async()=>{
  const {ledger}=setup();await ledger.migrate(digest,{});
  await ledger.reserve(digest,'run',bind);await ledger.confirm(digest,'run',bind);
  assert.equal((await ledger.resume(digest,'run',bind)).status,'authorized');
  await assert.rejects(ledger.resume(digest,'run',other));
  assert.equal((await ledger.status(digest)).remaining,2);
});
test('a previously used device cannot get fresh quota from an empty post-reinstall snapshot',async()=>{
  const {ledger}=setup();await ledger.migrate(digest,{one:'used',two:'used',three:'used'});
  assert.equal((await ledger.migrate(digest,{})).remaining,0);
  await assert.rejects(ledger.reserve(digest,'new',bind));
});
test('invalid identity, missing or malformed legacy state, and unknown device all fail closed',async()=>{
  const {ledger}=setup();
  await assert.rejects(ledger.migrate('bad',{}));await assert.rejects(ledger.migrate(digest));
  await assert.rejects(ledger.migrate(digest,{run:'unexpected'}));await assert.rejects(ledger.migrate(digest,{a:'used',b:'used',c:'used',d:'used'}));
  await assert.rejects(ledger.reserve(digest,'a',bind));
});

