import control as c
import os,subprocess,json,re,time
from pathlib import Path
def replace(node,value):
    assert re.fullmatch(r'[A-Za-z0-9_:/.-]+',value)
    a,b,d,e=map(int,re.findall(r'\d+',node.get('bounds')));c.tap((a+d)//2,(b+e)//2)
    c.adb('shell','input','keycombination','113','29');c.adb('shell','input','text',value)
    c.adb('shell','input','keyevent','4');time.sleep(.2)
cli=Path(os.environ['APPDATA'])/'npm/node_modules/@cloudbase/cli/bin/tcb'
raw=subprocess.check_output(['node',str(cli),'fn','detail','dailyHundredImportV1Event','-e','fh6-d5ga45c0ddae7008c','--json'],stderr=subprocess.DEVNULL,timeout=40)
env=json.loads(raw[raw.index(b'{'):])['data']['Environment']['Variables'];key=next(x['Value'] for x in env if x['Key']=='DEEPSEEK_API_KEY')
del raw,env
fields=[n for n in c.nodes() if n.get('class')=='android.widget.EditText']
replace(fields[0],'https://api.deepseek.com')
fields=[n for n in c.nodes() if n.get('class')=='android.widget.EditText'];replace(fields[1],'deepseek-chat')
node=next(n for n in c.nodes() if n.get('class')=='android.widget.EditText' and n.get('password')=='true')
replace(node,key);del key
c.adb('shell','input','swipe','500','2100','500','1250','350');time.sleep(.2)
c.click('保存配置')
print('Official unchanged APK configured: direct HTTPS provider, deepseek-chat, key hidden; no thinking parameter or proxy added.')
