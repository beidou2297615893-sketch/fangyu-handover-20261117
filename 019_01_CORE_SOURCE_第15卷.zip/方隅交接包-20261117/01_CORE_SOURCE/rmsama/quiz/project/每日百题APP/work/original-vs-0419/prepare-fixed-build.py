from pathlib import Path
import shutil
r=Path('V:/work/original-vs-0419/fixed-current');r.mkdir()
old=Path('V:/work/verify-0419-device-a10-final')
for name in ['prepare.py','build.py','test-repos.gradle']:shutil.copy2(old/name,r/name)
p=r/'build.py';s=p.read_text(encoding='utf-8')
s=s.replace("ROOT = Path('V:/work/verify-0419-device-a10-final')","ROOT = Path('V:/work/original-vs-0419/fixed-current')")
s=s.replace("':app:assembleDevDebug', '--offline'","':app:testDevDebugUnitTest', ':app:assembleDevDebug', '--offline'")
p.write_text(s,encoding='utf-8')
print('Prepared an independent frozen build for the existing-fallback correction.')
