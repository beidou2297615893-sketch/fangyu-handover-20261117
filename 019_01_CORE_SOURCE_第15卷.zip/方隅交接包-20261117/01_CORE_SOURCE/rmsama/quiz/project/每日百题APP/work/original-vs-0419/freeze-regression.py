from pathlib import Path
import hashlib,json
r=Path('V:/work/original-vs-0419');main=Path('V:/work/tijing-bankassist/android/app/src/main/java')
stage=r/'regression-stage/app/src/diagnosticShared/java'
rows=[]
for file in sorted(main.rglob('*.kt')):
    key=file.relative_to(main).as_posix();shared=stage/key
    digest=hashlib.sha256(file.read_bytes()).hexdigest()
    rows.append({'path':key,'sha256':digest,'shared':shared.exists(),'equal':shared.exists() and shared.read_bytes()==file.read_bytes()})
(r/'regression-source-manifest.json').write_text(json.dumps(rows,indent=2),encoding='utf-8')
assert len(rows)==40 and sum(x['equal'] for x in rows)==38
print('Frozen production source: 40 files, 38 compiled shared files identical.')
