import control as c
import sys, json
sys.stdout.reconfigure(encoding='utf-8')
if sys.argv[1]=='threads':
    names=c.adb('shell','ls','-t','/data/anr').decode().split()
    raw=c.adb('exec-out','cat','/data/anr/'+names[0]).decode(errors='replace').replace('\r','')
    (c.R/'original-thread-dump.txt').write_text(raw,encoding='utf-8')
    for b in raw.split('\n\n'):
        if b.startswith('"main"') or b.startswith('"QuizCapture"') or ('ModelClient' in b and b.startswith('"')): print(b)
elif sys.argv[1]=='events':
    j=[json.loads(l) for l in c.adb('exec-out','run-as','com.jimusoft.railwaymp','cat','files/events.jsonl').splitlines()]
    at=max(i for i,r in enumerate(j) if r['evt']=='start')
    j=j[at:]
    (c.R/'original-run-events.json').write_text(json.dumps(j,ensure_ascii=False,indent=2),encoding='utf-8')
    rows=[r for r in j if r['evt']=='confirm']
    print({'confirmed':len(rows),'correct':sum(r['data']['correct'] for r in rows),'last':j[-1]})
