package com.futureyyy.tijing
import java.io.File
import javax.imageio.ImageIO
import com.google.gson.JsonParser
fun main(){
 val d=File("V:/work/ocr0419-evidence/hd100")
 val source=JsonParser.parseString(File(d,"replay-manifest.json").readText()).asJsonObject.getAsJsonArray("rows").associate{e->val r=e.asJsonObject;r["file"].asString to r["sourcePath"].asString}
 val all=JsonParser.parseString(File(d,"replay-paddle.json").readText()).asJsonArray
 var accepted=0;var negative=0
 for(el in all){val r=el.asJsonObject;val file=r["file"].asString.removePrefix("page-");val img=ImageIO.read(File(source.getValue(file)));val w=img.width;val h=img.height;val pix=img.getRGB(0,0,w,h,null,0,w)
 val nodes=r["lines"].asJsonArray.map{t->val line=t.asJsonObject;val b=line["box"].asJsonArray;VisibleQuestionReader.Node(line["text"].asString,NormalizedBox(b[0].asFloat,b[1].asFloat,b[2].asFloat,b[3].asFloat))}
 val tested=nodes.asSequence().windowed(4).mapNotNull {RomanChoiceEvidence.read(w,h,pix,it)}.firstOrNull()
 if(file.startsWith("replay-q20-")){require(tested!=null);require(tested.map{it.text}==listOf("管理,IV","管理,III","管理,II","管理,I")); accepted++} else {require(tested==null);negative++}
 }
 println("Q20 complete IV/III/II/I, unrelated real frames rejected="+negative+" positive="+accepted)
}
