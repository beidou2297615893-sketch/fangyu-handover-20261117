'use strict';
const {createProductionMain}=require('./billing-event');
const disabled=createProductionMain();
// This is a server-side ledger binding, not remote attestation of a user's
// device or third-party app. Authentication and run-binding immutability remain
// enforced by the runtime and transactional paid-only run core.
function validateRunBinding(owner,runId,binding){
  return /^i[a-f0-9]{32}$/.test(owner)&&typeof runId==='string'&&/^[A-Za-z0-9_-]{1,128}$/.test(runId)&&typeof binding==='string'&&/^[a-f0-9]{64}$/.test(binding);
}
async function defaultDatabase(){const sdk=require('@cloudbase/node-sdk'),app=sdk.init({env:sdk.SYMBOL_CURRENT_ENV});return app.database({throwOnCode:true,timeout:2500});}
async function enabledPolicies(db){
  if(!db||typeof db.runTransaction!=='function')throw Error('unavailable');
  await db.runTransaction(async tx=>{
    for(const name of ['daily_hundred_installation_v1','daily_hundred_payment_v1']){
      const r=await tx.collection(name).doc('policy').get();
      if(!r||r.code||!r.data||r.data._id!=='policy'||r.data.kind!=='policy'||r.data.schema!==1||r.data.enabled!==true)throw Error('unavailable');
    }
  },3);
}
function createProductionEntry({environment=process.env,databaseFactory=defaultDatabase}={}){
  return async function main(event){
    try{
      // Avoid even accessing credentials or creating a DB client unless the
      // server operator explicitly enabled both production and native gate.
      if(environment.BILLING_ENABLED!=='true'||environment.BILLING_NATIVE_ADMISSION_READY!=='true'||environment.BILLING_NATIVE_RELEASE_VERIFIED!=='true'||environment.BILLING_CLOUD_ACL_VERIFIED!=='true')return disabled(event);
      const {validateProductionSettings}=require('./production-config');
      const settings=validateProductionSettings(environment,environment.BILLING_APPROVED_ORIGIN);
      const pilot=require('./pilot-policy').pilotPolicy(environment,settings.registrationKey);
      const db=await databaseFactory();await enabledPolicies(db);
      const {createInternalRuntime}=require('./runtime');
      const handler=createInternalRuntime({db,settings,verifyTaskBinding:validateRunBinding,recoveryEnabledForOfflineTest:false,productionReady:true,pilot});
      return await handler(event);
    }catch{return disabled(event);}
  };
}
// Safe until an explicitly configured deployment sets both gates and policies.
const main=createProductionEntry();
module.exports={createProductionEntry,main};
