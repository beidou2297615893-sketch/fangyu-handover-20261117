'use strict';
// Browser client SDK only: never pass an admin/server SDK. No login or settings
// are created by this module. Callers must supply a real separately verified session.
const crypto=require('node:crypto');
const NAMES=Object.freeze(['daily_hundred_payment_v1','daily_hundred_installation_v1']);
async function verifyClient(db,session,kind,randomId=()=>crypto.randomBytes(16).toString('hex')){
 if(!db||typeof db.collection!=='function'||!['anonymous','registered'].includes(kind)||!session||typeof session.access_token!=='string'||!session.access_token||!session.user||session.user.is_anonymous!==(kind==='anonymous'))return {verified:false,reason:'identity-unverified'};
 const token=randomId();if(typeof token!=='string'||!/^[a-f0-9]{32}$/.test(token))return {verified:false,reason:'invalid-test-id'};
 const id='acl-test-'+token;
 for(const name of NAMES){
  const collection=db.collection(name),operations=[()=>collection.doc(id).get(),()=>collection.where({_id:id}).limit(1).get(),()=>collection.doc(id).set({kind:'temporary-acl-test',token})];
  for(const operation of operations){
   try{await operation();return {verified:false,reason:'unexpected-access',testId:id};}
   catch(error){if(error?.code!=='DATABASE_PERMISSION_DENIED'&&error?.errCode!=='DATABASE_PERMISSION_DENIED')return {verified:false,reason:'indeterminate'};}
  }
 }
 return {verified:true};
}
module.exports={verifyClient};
