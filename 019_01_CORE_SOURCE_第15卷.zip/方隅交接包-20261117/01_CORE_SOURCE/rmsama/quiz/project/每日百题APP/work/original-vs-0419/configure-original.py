import os, subprocess, json, time, re
from pathlib import Path
import control as c

def replace_field(node, value):
    a,b,d,e=map(int,re.findall(r'\d+',node.get('bounds')))
    c.tap((a+d)//2,(b+e)//2)
    c.adb('shell','input','keycombination','113','29')
    c.adb('shell','input','text',value)
    c.adb('shell','input','keyevent','4')
    time.sleep(.3)

cli=Path(os.environ['APPDATA'])/'npm/node_modules/@cloudbase/cli/bin/tcb'
print('Reading the existing provider configuration securely...',flush=True)
raw=subprocess.check_output(['node',str(cli),'fn','detail','dailyHundredImportV1Event','-e','fh6-d5ga45c0ddae7008c','--json'],stderr=subprocess.DEVNULL,timeout=40)
settings=json.loads(raw[raw.index(b'{'):])['data']['Environment']['Variables']
key=next(v['Value'] for v in settings if v['Key']=='DEEPSEEK_API_KEY')
del raw,settings
print('Provider configuration received; populating original app settings.',flush=True)

inputs=[n for n in c.nodes() if n.get('class')=='android.widget.EditText']
replace_field(inputs[0], 'https://api.deepseek.com')
inputs=[n for n in c.nodes() if n.get('class')=='android.widget.EditText']
replace_field(inputs[1], 'deepseek-flash')
nodes=c.nodes()
password=next(n for n in nodes if n.get('class')=='android.widget.EditText' and n.get('password')=='true')
replace_field(password,key)
del key
c.adb('shell','input','swipe','500','2100','500','1250','350')
time.sleep(.3)
c.click('保存配置')
c.snap('original-settings-configured')
print('Original configured with the existing project provider; key omitted from evidence.')
