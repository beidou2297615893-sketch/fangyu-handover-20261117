'use strict';
const crypto=require('node:crypto');
function derive(master,identity){
 if(!Buffer.isBuffer(master)||master.length!==32||!identity||Object.keys(identity).sort().join(',')!=='clientRequestId,requestId,verifier')throw Error('invalid');
 const token=v=>typeof v==='string'&&/^[A-Za-z0-9_-]{43}$/.test(v)&&Buffer.from(v,'base64url').length===32&&Buffer.from(v,'base64url').toString('base64url')===v;
 if(!token(identity.requestId)||!token(identity.verifier)||typeof identity.clientRequestId!=='string'||!/^[A-Za-z0-9_-]{8,64}$/.test(identity.clientRequestId))throw Error('invalid');
 const registrationKey=crypto.createHmac('sha256',master).update('dailyhundred-payment-v1\0registration').digest('hex');
 const input=JSON.stringify([identity.requestId,identity.verifier]),owner=crypto.createHmac('sha256',Buffer.from(registrationKey,'utf8')).update('dailyhundred-installation-owner-v2\0').update(input).digest().subarray(0,16);owner[0]=0x49;
 const hash=x=>crypto.createHash('sha256').update(x,'utf8').digest('hex');
 return {BILLING_PILOT_ENABLED:'true',BILLING_PILOT_OWNER:'i'+owner.toString('hex'),BILLING_PILOT_REGISTRATION_HASH:hash(input),BILLING_PILOT_ORDER_HASH:hash(identity.clientRequestId)};
}
module.exports={derive};
