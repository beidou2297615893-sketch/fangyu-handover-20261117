from pathlib import Path
import json,unicodedata
r=Path('V:/work/original-vs-0419');roots=[Path('V:/work/tijing-bankassist/android/app/src/test'),r/'regression-stage/app/src/test']
def key(s):return ''.join(x for x in unicodedata.normalize('NFKC',s) if x.isalnum())
cloud=json.loads((r/'hidden-roman-fixed/cloud-transcript.json').read_text(encoding='utf-8'))
records=json.loads((r/'same-bank-1859.json').read_text(encoding='utf-8'))['questions']
matched=[q for q in records if key(q['question'])==key(cloud['question'])]
assert len(matched)==1,len(matched)
lines=json.loads((r/'hidden-roman-fixed/ocr-probe-result.json').read_text(encoding='utf-8'))['independent']['lines']
for root in roots:
    (root/'resources/regression/lowercase-option.json').write_text(json.dumps({'record':matched[0],'lines':lines},ensure_ascii=False,indent=2),encoding='utf-8')
    text=(root/'java/com/futureyyy/tijing/WrappedOptionRegressionTest.kt').read_text(encoding='utf-8')
    text=text[:text.index('    @Test fun centeredMarker')]+'''    @Test fun lowercaseMarkerIsTheSameChoiceWithoutChangingItsNumbers() {
        assertNotNull(OcrHostPage.optionRows(lines, options))
        val resolved=bank.verifiedOcrPage(lines,46)
        assertNotNull(resolved)
        assertEquals(answer,resolved!!.answerIndices)
    }

    @Test fun aChangedNumberCannotBeFilledFromTheBank() {
        val changed=lines.map { if(it.text.startsWith("c.")) it.copy(text="c.1000,50000,20") else it }
        assertNull(OcrHostPage.optionRows(changed,options))
        assertNull(bank.verifiedOcrPage(changed,46))
    }

    @Test fun aDifferentLetterStillCannotBecomeC() {
        val changed=lines.map { if(it.text.startsWith("c.")) it.copy(text=it.text.replaceFirst("c.","d.")) else it }
        assertNull(OcrHostPage.optionRows(changed,options))
        assertNull(bank.verifiedOcrPage(changed,46))
    }
}
'''
    text=text.replace('WrappedOptionRegressionTest','LowercaseOptionRegressionTest').replace('wrapped-option.json','lowercase-option.json')
    text=text.replace('/** A real railway screenshot whose B marker was centered on the second text line. */','/** A real railway frame with c. in an otherwise complete numeric option. */')
    (root/'java/com/futureyyy/tijing/LowercaseOptionRegressionTest.kt').write_text(text,encoding='utf-8')
print('One matching bank record; three regression tests created.')
