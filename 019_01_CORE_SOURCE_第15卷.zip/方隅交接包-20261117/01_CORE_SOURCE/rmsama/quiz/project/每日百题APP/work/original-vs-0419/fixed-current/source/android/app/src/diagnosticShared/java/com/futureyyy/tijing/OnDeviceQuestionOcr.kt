package com.futureyyy.tijing

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Handler
import android.os.Looper
import android.util.Base64
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions
import java.util.concurrent.Executors
import java.util.concurrent.RejectedExecutionException

/** One bundled recognizer per capture service. It receives only the requested screen frame. */
internal class OnDeviceQuestionOcr(context:android.content.Context) : AutoCloseable {
    private val worker = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())
    private val recognizer = lazy { TextRecognition.getClient(ChineseTextRecognizerOptions.Builder().build()) }
    private val independent = IndependentLineReader(context)
    @Volatile private var closed = false

    fun readIndependent(frame:CaptureFrame, lines:List<VisibleQuestionReader.Node>, callback:(List<VisibleQuestionReader.Node>) -> Unit) {
        try {
            worker.execute {
                val result = if(closed) emptyList() else try { independent.read(frame,lines) }
                    catch(error:Exception) { android.util.Log.w("ZhitiOCR","Independent reader unavailable: "+error.javaClass.simpleName); emptyList() }
                    catch(error:LinkageError) { android.util.Log.w("ZhitiOCR","Independent runtime unavailable"); emptyList() }
                main.post { callback(if(closed) emptyList() else result) }
            }
        } catch(_:RejectedExecutionException) { main.post { callback(emptyList()) } }
    }

    fun read(frame: CaptureFrame, questionNo: Int, callback: (QuizModelResult?) -> Unit) {
        readLines(frame) { lines -> callback(pageFromLines(lines, questionNo)) }
    }

    fun pageFromLines(lines: List<VisibleQuestionReader.Node>, questionNo: Int): QuizModelResult? =
        VisibleQuestionReader.readOcrLines(lines, questionNo)

    fun readLines(frame: CaptureFrame, callback: (List<VisibleQuestionReader.Node>) -> Unit) {
        fun deliver(lines: List<VisibleQuestionReader.Node>) {
            main.post { callback(if (closed) emptyList() else lines) }
        }
        try {
            worker.execute {
                var bitmap: Bitmap? = null
                try {
                    if (closed) { deliver(emptyList()); return@execute }
                    val data = frame.localPng ?: Base64.decode(frame.dataUrl.substringAfter(','), Base64.DEFAULT)
                    val original = BitmapFactory.decodeByteArray(data, 0, data.size)
                        ?: throw IllegalArgumentException("截图无法解码")
                    bitmap = original
                    // Small emulator and phone screenshots can have glyphs under 16 px.
                    if (original.width < 620 && original.height <= 1600) {
                        bitmap = Bitmap.createScaledBitmap(original, original.width * 2, original.height * 2, true)
                        original.recycle()
                    }
                    val image = bitmap
                    recognizer.value.process(InputImage.fromBitmap(image, 0)).addOnCompleteListener { task ->
                        val lines = try {
                            if (!task.isSuccessful) emptyList() else task.result.textBlocks.flatMap { it.lines }
                                .takeIf { it.size <= 250 }?.mapNotNull { line ->
                                    val rect = line.boundingBox ?: return@mapNotNull null
                                    val x = (100f * rect.left / image.width).coerceIn(0f, 100f)
                                    val y = (100f * rect.top / image.height).coerceIn(0f, 100f)
                                    val w = (100f * rect.width() / image.width).coerceIn(0f, 100f - x)
                                    val h = (100f * rect.height() / image.height).coerceIn(0f, 100f - y)
                                    if (w <= 0f || h <= 0f || line.text.isBlank()) null
                                    else VisibleQuestionReader.Node(line.text, NormalizedBox(x, y, w, h))
                                }.orEmpty()
                        } catch (_: Exception) { emptyList() }
                        finally { image.recycle() }
                        deliver(lines)
                    }
                } catch (_: Exception) {
                    bitmap?.recycle()
                    deliver(emptyList())
                }
            }
        } catch (_: RejectedExecutionException) { deliver(emptyList()) }
    }

    override fun close() {
        if (closed) return
        closed = true
        worker.execute { if (recognizer.isInitialized()) recognizer.value.close();independent.close() }
        worker.shutdown()
    }
}
