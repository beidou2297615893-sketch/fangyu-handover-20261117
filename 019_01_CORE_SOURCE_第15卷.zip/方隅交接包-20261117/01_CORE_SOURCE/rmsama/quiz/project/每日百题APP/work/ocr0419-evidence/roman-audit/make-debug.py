from pathlib import Path
d=Path(__file__).parent
main=Path('V:/work/tijing-bankassist/android/app/src/main/java/com/futureyyy/tijing')
s=(main/'RomanChoiceEvidence.kt').read_text('utf8')
import re
def edit(m):
 line=s[:m.start()].count(chr(10))+1
 return 'run { println("reject line '+str(line)+'"); return null }'
s=re.sub('return null',edit,s)
(d/'DebugRoman.kt').write_text(s,'utf8')
p=(d/'inspect-current.py').read_text('utf8').replace('main/"RomanChoiceEvidence.kt"','out/"DebugRoman.kt"')
(d/'debug-current.py').write_text(p,'utf8')
