from pathlib import Path
import subprocess, sys, time, re, json, xml.etree.ElementTree as ET

R=Path(__file__).resolve().parent
ADB=R.parent/'tools/android-sdk/platform-tools/adb.exe'
SERIAL='emulator-5588'
def adb(*args, timeout=30):
    return subprocess.check_output([str(ADB),'-P','15037','-s',SERIAL,*map(str,args)],timeout=timeout,stderr=subprocess.STDOUT)
def tree():
    for attempt in range(3):
        adb('shell','rm','-f','/sdcard/compare-ui.xml')
        output=adb('shell','uiautomator','dump','/sdcard/compare-ui.xml')
        if b'dumped to:' in output:
            return ET.fromstring(adb('exec-out','cat','/sdcard/compare-ui.xml'))
        if attempt<2:time.sleep(.5)
    raise RuntimeError('Fresh UI hierarchy unavailable; refusing stale UI XML.')
def nodes(): return list(tree().iter('node'))
def tap(x,y): adb('shell','input','tap',int(x),int(y))
def click(text):
    visible=[n for n in nodes() if n.get('bounds')!='[0,0][0,0]']
    exact=[n for n in visible if text in (n.get('text',''),n.get('content-desc',''))]
    found=exact or [n for n in visible if text in n.get('text','') or text in n.get('content-desc','')]
    if not found: raise RuntimeError('Missing UI label: '+text)
    buttons=[n for n in found if n.get('class','').endswith('Button') or n.get('clickable')=='true']
    n=(buttons or found)[0];a,b,c,d=map(int,re.findall(r'\d+',n.get('bounds')));tap((a+c)//2,(b+d)//2)
def ui():
    return [{k:('***' if n.get('password')=='true' and k=='text' else n.get(k)) for k in ['text','content-desc','class','resource-id','bounds','clickable','enabled','password']} for n in nodes() if n.get('text') or n.get('content-desc') or n.get('class')=='android.widget.EditText']
def snap(name):
    (R/(name+'.png')).write_bytes(adb('exec-out','screencap','-p'))
    (R/(name+'.json')).write_text(json.dumps(ui(),ensure_ascii=False,indent=2),encoding='utf-8')
def launch(pkg): return adb('shell','am','start','-n',pkg+'/com.futureyyy.tijing.MainActivity').decode(errors='replace')
if __name__=='__main__':
    sys.stdout.reconfigure(encoding='utf-8')
    cmd,*args=sys.argv[1:]
    if cmd=='ui': print(json.dumps(ui(),ensure_ascii=False))
    elif cmd=='click':click(' '.join(args))
    elif cmd=='tap':tap(*args)
    elif cmd=='snap':snap(args[0])
    elif cmd=='launch':print(launch(args[0]))
    elif cmd=='adb':print(adb(*args).decode(errors='replace'))
