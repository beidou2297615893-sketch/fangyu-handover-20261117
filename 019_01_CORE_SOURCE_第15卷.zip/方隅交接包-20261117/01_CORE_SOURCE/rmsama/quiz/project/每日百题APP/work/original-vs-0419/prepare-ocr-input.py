import control as c
import time,hashlib,json,sys
pkg='com.jimusoft.dailyhundredapp.audit419.dev'
c.adb('shell','am','force-stop',pkg)
time.sleep(1)
png=c.adb('exec-out','screencap','-p');path=c.R/(sys.argv[1] if len(sys.argv)>1 else 'hidden-current/feedback-clean.png');path.write_bytes(png)
uid=c.adb('shell','stat','-c','%u','/data/user/0/'+pkg).decode().strip()
target='/data/user/0/'+pkg+'/files/ocr-input.png'
c.adb('push',path,target)
c.adb('shell','chown',uid+':'+uid,target)
c.adb('shell','chmod','600',target)
c.adb('shell','restorecon',target)
print(json.dumps({'inputSha256':hashlib.sha256(png).hexdigest(),'bytes':len(png),'testPackageOnly':pkg}))
