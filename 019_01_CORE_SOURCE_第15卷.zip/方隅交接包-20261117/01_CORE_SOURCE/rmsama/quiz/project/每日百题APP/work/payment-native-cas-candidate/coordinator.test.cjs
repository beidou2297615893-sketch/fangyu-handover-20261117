'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const {createIdentityCoordinator}=require('./coordinator');
function nativeStore(record){
 let current={version:0,record:structuredClone(record)};
 return {
  async read(){return structuredClone(current)},
  async compareAndSet(expectedVersion,next){
   if(current.version!==expectedVersion)return false;
   current={version:current.version+1,record:structuredClone(next)};return true;
  }
 };
}
const installationId='owner-a',oldToken='A'.repeat(43),boundToken='B'.repeat(43),intent={planId:'once',clientRequestId:'request-original'};
const base=()=>({identity:{installationId,accessToken:oldToken},purchaseIntent:null,oauth:{phase:'awaitingBind',installationBearer:oldToken,state:'state',verifier:'verifier'}});
test('binding wins during a stale purchase write: retry preserves new token and purchase intent',async()=>{
 const native=nativeStore(base()),coordinator=createIdentityCoordinator(native);let release,signal;
 const paused=new Promise(r=>signal=r),resume=new Promise(r=>release=r);
 const purchase=coordinator.rememberPurchase(intent,async()=>{signal();await resume});await paused;
 await coordinator.commitBinding({installationId,accessToken:boundToken});release();await purchase;
 const {record}=await native.read();assert.equal(record.identity.accessToken,boundToken);assert.deepEqual(record.purchaseIntent,intent);
 assert.equal(record.oauth.installationBearer,oldToken);assert.equal(record.oauth.phase,'awaitingAck');
});
test('purchase wins during a stale binding write: retry preserves purchase intent and original bearer',async()=>{
 const native=nativeStore(base()),coordinator=createIdentityCoordinator(native);let release,signal;
 const paused=new Promise(r=>signal=r),resume=new Promise(r=>release=r);
 const binding=coordinator.commitBinding({installationId,accessToken:boundToken},async()=>{signal();await resume});await paused;
 await coordinator.rememberPurchase(intent);release();await binding;
 const {record}=await native.read();assert.equal(record.identity.accessToken,boundToken);assert.deepEqual(record.purchaseIntent,intent);
 assert.equal(record.oauth.installationBearer,oldToken);assert.equal(record.oauth.phase,'awaitingAck');
});
test('mismatched installation or malformed token never overwrites saved identity',async()=>{
 const native=nativeStore(base()),coordinator=createIdentityCoordinator(native),before=await native.read();
 await assert.rejects(coordinator.commitBinding({installationId:'other-owner',accessToken:boundToken}));
 await assert.rejects(coordinator.commitBinding({installationId,accessToken:'invalid'}));
 assert.deepEqual(await native.read(),before);
});
test('stale native versions cannot replace newer records',async()=>{
 const native=nativeStore(base()),snapshot=await native.read(),replacement=structuredClone(snapshot.record);
 assert.equal(await native.compareAndSet(snapshot.version,replacement),true);
 assert.equal(await native.compareAndSet(snapshot.version,snapshot.record),false);
 assert.equal((await native.read()).version,1);
});
test('repeated conflicts fail closed rather than overwrite a newer record',async()=>{
 const backing=nativeStore(base()),native={read:()=>backing.read(),compareAndSet:async()=>false};
 await assert.rejects(createIdentityCoordinator(native).rememberPurchase(intent),/concurrent identity update/);
 assert.deepEqual((await backing.read()).record,base());
});
test('existing purchase intent cannot be replaced with a different purchase',async()=>{
 const native=nativeStore({...base(),purchaseIntent:intent}),coordinator=createIdentityCoordinator(native);
 await assert.rejects(coordinator.rememberPurchase({planId:'week',clientRequestId:'different-request'}),/purchase pending/);
 assert.deepEqual((await native.read()).record.purchaseIntent,intent);
});
