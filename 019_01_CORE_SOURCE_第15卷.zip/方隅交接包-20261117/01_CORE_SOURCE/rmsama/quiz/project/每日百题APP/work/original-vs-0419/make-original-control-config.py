from pathlib import Path
import json
r=Path('V:/work/original-vs-0419')
bank=(r/'same-bank-1859.json').read_text(encoding='utf-8')
payload={'requestId':'original-common-bank','content':bank}
script='new Promise(resolve=>{const previous=window.onNativeQuestionBankResult;window.onNativeQuestionBankResult=(id,body)=>{if(id==="original-common-bank"){window.onNativeQuestionBankResult=previous;resolve(JSON.parse(body))}else previous?.(id,body)};window.AndroidBridge.questionBankImport('+json.dumps(json.dumps(payload,ensure_ascii=False))+');})'
(r/'import-original-control.js').write_text(script,encoding='utf-8')
settings={'endpoint':'http://127.0.0.1:18765/v1','model':'deepseek-flash','apiKey':'[REDACTED:assigned_secret]','mode':'auto','answerSource':'vision','targetApp':'auto','timeoutMs':30000,'retryCount':0}
script='(()=>{const s='+json.dumps(settings)+';return {accepted:window.AndroidBridge.startFloatingSession(JSON.stringify(s)),mode:s.mode,answerSource:s.answerSource};})()'
(r/'start-original-control.js').write_text(script,encoding='utf-8')
print('Prepared identical bank and controlled model transport; original native code remains unchanged.')
