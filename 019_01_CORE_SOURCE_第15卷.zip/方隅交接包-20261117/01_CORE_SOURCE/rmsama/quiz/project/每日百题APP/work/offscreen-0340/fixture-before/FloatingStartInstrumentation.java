package com.jimusoft.dailyhundrede2e;
import android.app.*;import android.content.*;import android.os.*;import android.view.*;import android.view.accessibility.*;import org.json.*;import java.util.*;import java.io.*;
/** Dedicated emulator only. Actual injected touch on the service-owned overlay. */
public final class FloatingStartInstrumentation extends Instrumentation {
 private android.database.sqlite.SQLiteDatabase fixtureDb;private String budgetBefore;private JSONArray touches=new JSONArray();private UiAutomation ui;private Object engine;private Class<?> type;private JSONArray checks=new JSONArray();private File folder;private Bundle args;private JSONArray roundIndices;private long seed=20261105L;
 public void onCreate(Bundle b){super.onCreate(b);args=b==null?new Bundle():b;start();}
 public void onStart(){Bundle result=new Bundle();try{
  if(!Build.HARDWARE.contains("ranchu"))throw new AssertionError("emulator only");folder=new File(getTargetContext().getExternalFilesDir(null),"visual-e2e");folder.mkdirs();
  ui=getUiAutomation(UiAutomation.FLAG_DONT_SUPPRESS_ACCESSIBILITY_SERVICES);check(ui!=null,"UiAutomation retained real service");android.accessibilityservice.AccessibilityServiceInfo info=ui.getServiceInfo();info.flags|=android.accessibilityservice.AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS;ui.setServiceInfo(info);type=Class.forName("expo.modules.automationbridge.NativeTaskEngine",true,getTargetContext().getClassLoader());Object c=type.getField("Companion").get(null);engine=c.getClass().getMethod("get",Context.class).invoke(c,getTargetContext());
  shell("settings put secure enabled_accessibility_services null");SystemClock.sleep(300);shell("settings put secure enabled_accessibility_services com.jimusoft.dailyhundredapp/expo.modules.automationbridge.QuizAccessibilityService");shell("settings put secure accessibility_enabled 1");long connectedUntil=SystemClock.uptimeMillis()+15000;while(!Boolean.TRUE.equals(snapshot().get("serviceConnected"))&&SystemClock.uptimeMillis()<connectedUntil)SystemClock.sleep(200);check(Boolean.TRUE.equals(snapshot().get("serviceConnected")),"real accessibility service connected");check(((Number)((Map)call("getBillingStatus")).get("freeRemaining")).intValue()>0,"fixture stays in free admission");
  Map w=mapCall("createWorkspace",map("companyLabel","Floating emulator","departmentLabel","Touch "+System.currentTimeMillis()));String id=(String)w.get("id");Map p=mapCall("prepareBankImport",map("workspaceId",id,"json",bank()));mapCall("commitBankImport",map("previewId",p.get("id"),"expectedActiveRevision",p.get("expectedActiveRevision")));call("selectWorkspace",new Class[]{String.class},id);call("prepareCurrentPage",new Class[]{String.class},id);
  boolean includeB27="true".equals(args.getString("includeB27"));
  int count=Integer.parseInt(args.getString("count","0"));
  seed=Long.parseLong(args.getString("seed","20261105"));
  if(count!=0 && count!=100)throw new AssertionError("count must be 0 or 100");
  int expected=count==100?100:(includeB27?5:4);
  Intent quizIntent=new Intent().setClassName("com.jimusoft.randomhundred","com.jimusoft.randomhundred.QuizActivity").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK).putExtra("alternate", "true".equals(args.getString("alternate"))).putExtra("includeB27",includeB27).putExtra("count",count).putExtra("seed",seed);
  check(!quizIntent.hasExtra("diagnosticIndex"),"formal run is not diagnostic");
  getTargetContext().startActivity(quizIntent);
  check(touch("开始答题",15000),"starts real-question round");
  long opaqueDeadline=SystemClock.uptimeMillis()+5000;
  while(!hasOpaqueTarget() && SystemClock.uptimeMillis()<opaqueDeadline)SystemClock.sleep(100);
  check(hasOpaqueTarget(),"target exposes only an empty root; no native option or submit control");
  copyRound(expected,count==100);
  saveTargetTree();
  save("question",allText());
  check(touch("从当前页开始",15000),"actual floating start touch");
  long end=SystemClock.uptimeMillis()+(count==100?2400000:600000);int last=-1;boolean running=false;long startTime=SystemClock.uptimeMillis();
  while(SystemClock.uptimeMillis()<end){
    Map state=snapshot();int n=((Number)state.get("answered")).intValue();String status=String.valueOf(state.get("status"));
    if(n!=last){Bundle progress=new Bundle();progress.putInt("confirmed",n);sendStatus(1,progress);last=n;copyProgress();write("running",null);}
    if(status.equals("running"))running=true;
    if(status.equals("completed")){check(n==expected,"every real question confirmed");save("completed",allText());check(allText().contains(expected+" / "+expected),"independent full score");check(touches.length()==2,"only start and floating-start were injected by harness");verifyProgress(expected,count==100);write("passed",null);result.putString("status","passed");finish(-1,result);return;}
    if(status.equals("paused")||( !running && SystemClock.uptimeMillis()-startTime>35000))throw new AssertionError("stopped at "+n+": "+state.get("reason")+" "+overlayText());
    SystemClock.sleep(160);
  }
  throw new AssertionError("round timeout"); 
 }catch(Throwable e){try{copyProgress();save("failure",overlayText());saveDiagnostic();write("failed",e.toString());readRuntimeFailure();}catch(Exception ignored){}result.putString("status","failed");result.putString("error",e.toString());finish(0,result);}}
 private void copyRound(int expected,boolean seeded)throws Exception {
   String path="/sdcard/Android/data/com.jimusoft.randomhundred/files/round.json";String data;
   try(ParcelFileDescriptor p=ui.executeShellCommand("cat "+path);FileInputStream in=new FileInputStream(p.getFileDescriptor())){data=new String(in.readAllBytes(),"UTF-8");}
   try(FileOutputStream out=new FileOutputStream(new File(folder,"round.json"))){out.write(data.getBytes("UTF-8"));}
   JSONObject round=new JSONObject(data);roundIndices=round.getJSONArray("roundIndices");
   check(round.getLong("seed")==seed && round.getBoolean("seeded")==seeded && roundIndices.length()==expected,"target recorded expected seed and complete round");
 }
 private String copyProgress()throws Exception {
   String path="/sdcard/Android/data/com.jimusoft.randomhundred/files/progress.jsonl";
   String data;
   try(ParcelFileDescriptor p=ui.executeShellCommand("cat "+path);FileInputStream in=new FileInputStream(p.getFileDescriptor())){data=new String(in.readAllBytes(),"UTF-8");}
   try(FileOutputStream out=new FileOutputStream(new File(folder,"progress.jsonl"))){out.write(data.getBytes("UTF-8"));}
   return data;
 }
 private void verifyProgress(int expected,boolean hundred)throws Exception {
   String data=copyProgress().trim();String[] lines=data.isEmpty()?new String[0]:data.split("\\r?\\n");
   check(lines.length==expected,"independent target recorded every submission");
   Set<Integer> indexes=new HashSet<>();
   for(int i=0;i<lines.length;i++){
     JSONObject e=new JSONObject(lines[i]);indexes.add(e.getInt("bankIndex"));
     check(e.getInt("bankIndex")==roundIndices.getInt(i),"submission "+(i+1)+" matches recorded round order");
     check(e.getInt("submitted")==i+1 && e.getInt("total")==expected && e.getBoolean("correct") && e.getInt("score")==i+1,"submission "+(i+1)+" independently scored correctly");
   }
   check(indexes.size()==expected,"all questions are distinct");
   if(hundred)for(int id:new int[]{8,9,204,205,1152,622,1584,358})check(indexes.contains(id),"required question "+id+" included");
 }
 private void saveTargetTree()throws Exception {
   java.lang.reflect.Field sf=type.getDeclaredField("service");sf.setAccessible(true);Object service=sf.get(engine);
   Class<?> accessor=Class.forName("expo.modules.automationbridge.screen.ForegroundRootKt",true,getTargetContext().getClassLoader());
   AccessibilityNodeInfo root=(AccessibilityNodeInfo)accessor.getMethod("foregroundRoot",android.accessibilityservice.AccessibilityService.class).invoke(null,service);
   try(PrintWriter out=new PrintWriter(new File(folder,"target-native-tree.txt"),"UTF-8")){tree(root,out,0);}finally{if(root!=null)root.recycle();}
 }
 private void tree(AccessibilityNodeInfo node,PrintWriter out,int depth){
   if(node==null)return;
   out.println("depth="+depth+" package="+node.getPackageName()+" class="+node.getClassName()+" visible="+node.isVisibleToUser()+" clickable="+node.isClickable()+" checkable="+node.isCheckable()+" text="+node.getText()+" description="+node.getContentDescription());
   for(int i=0;i<node.getChildCount();i++){AccessibilityNodeInfo child=node.getChild(i);if(child!=null){try{tree(child,out,depth+1);}finally{child.recycle();}}}
 }
 private void readRuntimeFailure() {
   try (PrintWriter out=new PrintWriter(new File(folder,"runtime-ocr.txt"),"UTF-8")) {
     try {
       java.lang.reflect.Field driverField=type.getDeclaredField("generic");driverField.setAccessible(true);
       Object driver=driverField.get(engine);if(driver==null)return;
       Class<?> dc=driver.getClass();
       java.lang.reflect.Field rf=dc.getDeclaredField("reader");rf.setAccessible(true);
       Object reader=rf.get(driver);if(reader==null)return;
       ClassLoader loader=getTargetContext().getClassLoader();
       Class<?> fn=Class.forName("kotlin.jvm.functions.Function1",true,loader);
       Object unit=Class.forName("kotlin.Unit",true,loader).getField("INSTANCE").get(null);
       java.lang.reflect.Method profile=dc.getDeclaredMethod("profile",Class.forName("expo.modules.automationbridge.screen.ScreenNode",true,loader));
       profile.setAccessible(true);Object scope=profile.invoke(driver,new Object[]{null});
       java.lang.reflect.Method read=reader.getClass().getMethod("readAttempt",scope.getClass(),String.class,fn,int.class,fn);
       Object active=java.lang.reflect.Proxy.newProxyInstance(loader,new Class[]{fn},(p,m,a)->true);
       String run=String.valueOf(snapshot().get("runId"));
       for(int i=0;i<3;i++){
         java.util.concurrent.CountDownLatch done=new java.util.concurrent.CountDownLatch(1);
         Object callback=java.lang.reflect.Proxy.newProxyInstance(loader,new Class[]{fn},(p,m,a)->{
           out.println(a[0]);out.flush();done.countDown();return unit;
         });
         final int attempt=i;
         runOnMainSync(()->{try{read.invoke(reader,scope,run,active,attempt,callback);}catch(Exception e){e.printStackTrace(out);done.countDown();}});
         if(!done.await(8,java.util.concurrent.TimeUnit.SECONDS))break;
         SystemClock.sleep(400);
       }
     }catch(Exception e){e.printStackTrace(out);}
   }catch(Exception ignored){}
 }
 private void launch(String mode){getTargetContext().startActivity(new Intent().setClassName("org.jimu.genericfixture","org.jimu.genericfixture.QuizActivity").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TASK).putExtra("layout",mode).putExtra("count",10));}
 private void saveDiagnostic() {
   try {
     java.lang.reflect.Field field=type.getDeclaredField("failureRead");field.setAccessible(true);
     Object bound=field.get(engine);if(bound==null)return;
     java.lang.reflect.Field evidence=bound.getClass().getDeclaredField("evidence");evidence.setAccessible(true);
     Object report=evidence.get(bound);java.lang.reflect.Field text=report.getClass().getDeclaredField("text");text.setAccessible(true);
     try (FileOutputStream out=new FileOutputStream(new File(folder,"ocr-diagnostic.txt"))) {
       out.write(String.valueOf(text.get(report)).getBytes("UTF-8"));
     }
   }catch(Exception ignored){}
 }
 private boolean touch(String label,long timeout){long end=SystemClock.uptimeMillis()+timeout;do{for(AccessibilityWindowInfo w:ui.getWindows()){AccessibilityNodeInfo root=w.getRoot(),node=find(root,label);if(node!=null){android.graphics.Rect r=new android.graphics.Rect();node.getBoundsInScreen(r);node.recycle();if(!r.isEmpty()){SystemClock.sleep(180);android.graphics.Rect verified=locate(label);if(verified==null||!r.equals(verified))continue;try{touches.put(new JSONObject().put("label",label).put("bounds",r.toShortString()).put("before",new JSONObject(snapshot())));}catch(Exception ignored){}long t=SystemClock.uptimeMillis();MotionEvent down=MotionEvent.obtain(t,t,MotionEvent.ACTION_DOWN,r.centerX(),r.centerY(),0),up=MotionEvent.obtain(t,t+70,MotionEvent.ACTION_UP,r.centerX(),r.centerY(),0);try{return ui.injectInputEvent(down,true)&&ui.injectInputEvent(up,true);}finally{down.recycle();up.recycle();}}}}SystemClock.sleep(100);}while(SystemClock.uptimeMillis()<end);return false;}
 private android.graphics.Rect locate(String label){for(AccessibilityWindowInfo w:ui.getWindows()){AccessibilityNodeInfo n=find(w.getRoot(),label);if(n!=null){android.graphics.Rect r=new android.graphics.Rect();n.getBoundsInScreen(r);n.recycle();return r;}}return null;}
 private boolean hasOpaqueTarget()throws Exception{
   java.lang.reflect.Field sf=type.getDeclaredField("service");sf.setAccessible(true);
   Object service=sf.get(engine);if(service==null)return false;
   Class<?> accessor=Class.forName("expo.modules.automationbridge.screen.ForegroundRootKt",true,getTargetContext().getClassLoader());
   java.lang.reflect.Method rootMethod=accessor.getMethod("foregroundRoot",android.accessibilityservice.AccessibilityService.class);
   AccessibilityNodeInfo r=(AccessibilityNodeInfo)rootMethod.invoke(null,service);
   if(r==null)return false;
   try{
     return "com.jimusoft.randomhundred".contentEquals(r.getPackageName()) &&
       visibleNodes(r)==1 && !r.isCheckable() && !r.isClickable() &&
       (r.getText()==null || r.getText().length()==0) &&
       (r.getContentDescription()==null || r.getContentDescription().length()==0);
   }finally{r.recycle();}
 }
 private int visibleNodes(AccessibilityNodeInfo n){
   int count=n.isVisibleToUser()?1:0;
   for(int i=0;i<n.getChildCount();i++){
     AccessibilityNodeInfo c=n.getChild(i);if(c==null)continue;
     try{count+=visibleNodes(c);}finally{c.recycle();}
   }
   return count;
 }
 private AccessibilityNodeInfo find(AccessibilityNodeInfo n,String text){if(n==null)return null;try{if(text.equals(String.valueOf(n.getText())))return AccessibilityNodeInfo.obtain(n);for(int i=0;i<n.getChildCount();i++){AccessibilityNodeInfo r=find(n.getChild(i),text);if(r!=null)return r;}return null;}finally{n.recycle();}}
 private String text(AccessibilityNodeInfo n){if(n==null)return "";try{StringBuilder b=new StringBuilder();if(n.getText()!=null)b.append(n.getText()).append('\n');for(int i=0;i<n.getChildCount();i++)b.append(text(n.getChild(i)));return b.toString();}finally{n.recycle();}}
 private String overlayText(){StringBuilder b=new StringBuilder();for(AccessibilityWindowInfo w:ui.getWindows())if(w.getType()==AccessibilityWindowInfo.TYPE_ACCESSIBILITY_OVERLAY)b.append(text(w.getRoot()));return b.toString();}
 private String allText(){StringBuilder b=new StringBuilder();for(AccessibilityWindowInfo w:ui.getWindows())b.append(text(w.getRoot()));return b.toString();}
 private Map snapshot()throws Exception{return (Map)call("snapshot");}private Object call(String name)throws Exception{return type.getMethod(name).invoke(engine);}private Object call(String name,Class[] t,Object...v)throws Exception{return type.getMethod(name,t).invoke(engine,v);}private Map mapCall(String n,Map v)throws Exception{return(Map)call(n,new Class[]{Map.class},v);}private Map map(Object...v){Map m=new HashMap();for(int i=0;i<v.length;i+=2)m.put(v[i],v[i+1]);return m;}
 private void check(boolean ok,String label)throws Exception{checks.put(new JSONObject().put("check",label).put("passed",ok));if(!ok)throw new AssertionError(label);}
 private String bank()throws Exception{try(InputStream f=getContext().getAssets().open("questions-real100.json")){return new String(f.readAllBytes(),java.nio.charset.StandardCharsets.UTF_8).replace("\uFEFF","");}}
 private void isolateBudget()throws Exception{java.lang.reflect.Field f=type.getDeclaredField("db");f.setAccessible(true);fixtureDb=((android.database.sqlite.SQLiteOpenHelper)f.get(engine)).getWritableDatabase();try(android.database.Cursor c=fixtureDb.rawQuery("SELECT value FROM settings WHERE key='billingUsageV1'",null)){budgetBefore=c.moveToFirst()?c.getString(0):null;}try(FileOutputStream o=new FileOutputStream(new File(folder,"budget-before.json"))){o.write((budgetBefore==null?"null":budgetBefore).getBytes("UTF-8"));}fixtureDb.execSQL("INSERT OR REPLACE INTO settings(key,value) VALUES('billingUsageV1','{}')");}
 private void restoreBudget()throws Exception{if(fixtureDb==null)return;if(budgetBefore==null)fixtureDb.execSQL("DELETE FROM settings WHERE key='billingUsageV1'");else fixtureDb.execSQL("INSERT OR REPLACE INTO settings(key,value) VALUES('billingUsageV1',?)",new Object[]{budgetBefore});fixtureDb=null;}
 private void shell(String cmd)throws Exception{try(ParcelFileDescriptor p=ui.executeShellCommand(cmd);FileInputStream f=new FileInputStream(p.getFileDescriptor())){f.readAllBytes();}}
 private void save(String name,String value)throws Exception{try(FileOutputStream f=new FileOutputStream(new File(folder,name+".txt"))){f.write(value.getBytes("UTF-8"));}android.graphics.Bitmap b=ui.takeScreenshot();if(b!=null){try(FileOutputStream f=new FileOutputStream(new File(folder,name+".png"))){b.compress(android.graphics.Bitmap.CompressFormat.PNG,100,f);}b.recycle();}}
 private void write(String status,String error)throws Exception{try(FileOutputStream f=new FileOutputStream(new File(folder,"result.json"))){f.write(new JSONObject().put("status",status).put("error",error).put("seed",seed).put("checks",checks).put("touches",touches).put("snapshot",new JSONObject(snapshot())).toString(2).getBytes("UTF-8"));}}
}

