package expo.modules.automationbridge.billing
object PaidReservationGuardTest {
  @JvmStatic fun main(args:Array<String>) {
    fun denied(body:()->Unit) { var failed=false;try { body() } catch (_:Exception) { failed=true };check(failed) }
    check(PaidReservationGuard.reconcile("reserved",null)=="reserved")
    check(PaidReservationGuard.reconcile("reserved","unknown")=="unknown")
    check(PaidReservationGuard.reconcile("confirmed","confirmed")=="confirmed")
    check(PaidReservationGuard.reconcile("confirmed","receipt_confirmed")=="confirmed")
    denied { PaidReservationGuard.reconcile("confirmed",null) }
    denied { PaidReservationGuard.reconcile("confirmed","unknown") }
    denied { PaidReservationGuard.reconcile("confirmed","reserved") }
    denied { PaidReservationGuard.reconcile("reserved","confirmed") }
    denied { PaidReservationGuard.reconcile("released","reserved") }
    check(PaidReservationGuard.reconcile("reserved","reserved")=="reserved")
    check(PaidReservationGuard.reconcile("reserved","receipt_confirmed")=="receipt_confirmed")
    check(PaidReservationGuard.reconcile("reserved","releasing")=="releasing")
    check(PaidReservationGuard.reconcile("released","releasing")=="released")
    check(PaidReservationGuard.reconcile("released","released")=="released")
    denied { PaidReservationGuard.reconcile("reserved","released") }
    denied { PaidReservationGuard.reconcile("released","unknown") }
    denied { PaidReservationGuard.reconcile("confirmed","releasing") }
    denied { PaidReservationGuard.reconcile("unexpected","reserved") }
    denied { PaidReservationGuard.reconcile("reserved","unexpected") }
    println("PASS confirmed needs persisted receipt; unknown stays readback-only; released refused")
  }
}
