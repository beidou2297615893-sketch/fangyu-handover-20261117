'use strict';
const crypto=require('node:crypto');
const FN='dailyHundredBillingV1',ENV='fh6-d5ga45c0ddae7008c',OLD='ca956e8c4c15b180c4aa1ebc0b610d131e80529b998c6f8645b0972e485cc221';
const gates=['BILLING_ENABLED','BILLING_NATIVE_ADMISSION_READY','BILLING_NATIVE_RELEASE_VERIFIED','BILLING_CLOUD_ACL_VERIFIED'];
const check=v=>{if(!v)throw Error('update unavailable')};
function request(zip){
 check(Buffer.isBuffer(zip)&&zip.length>=4&&zip.length<=20*1024*1024&&zip.readUInt32LE(0)===0x04034b50);
 return {FunctionName:FN,Namespace:ENV,InstallDependency:'FALSE',Publish:'FALSE',ZipFile:zip.toString('base64')};
}
function envFingerprint(d,key){
 const v=d?.Environment?.Variables;check(Array.isArray(v)&&v.length>=gates.length&&v.length<=100);const seen=new Map();
 for(const row of v){check(row&&typeof row.Key==='string'&&typeof row.Value==='string'&&!seen.has(row.Key));seen.set(row.Key,row.Value)}
 for(const gate of gates)check(seen.get(gate)==='false');
 return crypto.createHmac('sha256',key).update(JSON.stringify([...seen].sort(([a],[b])=>a.localeCompare(b)))).digest();
}
function detail(d){check(d&&d.FunctionName===FN&&d.Namespace===ENV&&d.Type==='Event'&&d.Runtime==='Nodejs20.19'&&d.Handler==='production-entry.main');}
function summarizeFunctions(list){check(Array.isArray(list)&&list.length<100);return JSON.stringify(list.filter(x=>x.name!==FN).map(x=>({name:x.name,functionId:x.functionId,runtime:x.runtime,modifyTime:x.modifyTime,status:x.status})).sort((a,b)=>String(a.name).localeCompare(String(b.name))))}
function summarizeRoutes(list){check(Array.isArray(list)&&list.length<100);return JSON.stringify(list.map(x=>({domain:x.domain,path:x.path,upstreamResourceName:x.upstreamResourceName,upstreamResourceType:x.upstreamResourceType,enable:x.enable,enableAuth:x.enableAuth,enablePathTransmission:x.enablePathTransmission})).sort((a,b)=>JSON.stringify(a).localeCompare(JSON.stringify(b))))}
function trigger(t){
 check(t&&t.TotalCount===1&&Array.isArray(t.Triggers)&&t.Triggers.length===1);const e=t.Triggers[0],id=e.TriggerName;
 check(e.Type==='http'&&e.Enable===1&&e.Qualifier==='$LATEST'&&typeof id==='string'&&/^[a-z0-9-]{4,100}$/.test(id));
 const v=JSON.parse(e.TriggerDesc),u=new URL(v.NetConfig.ExtranetUrl);check(v.AuthType==='NONE'&&v.NetConfig.EnableExtranet===true&&u.protocol==='https:'&&u.hostname===`1439321968-${id}.ap-shanghai.tencentscf.com`&&!u.port&&!u.username&&!u.password&&u.pathname==='/'&&!u.search&&!u.hash);
 return id;
}
async function run(a){
 check(a&&['detail','codeHash','functions','routes','triggers','status','mark','update','delay'].every(k=>typeof a[k]==='function')&&typeof a.packageHash==='string'&&/^[a-f0-9]{64}$/.test(a.packageHash)&&a.packageHash!==OLD);
 const key=crypto.randomBytes(32);
 try{
  const before=await a.detail();detail(before);check(before.Status==='Active');const env=envFingerprint(before,key);
  check(await a.codeHash()===OLD);const triggerId=trigger(await a.triggers());check(await a.status(triggerId)===true);const fs=await a.functions(),rs=await a.routes();
  check(Array.isArray(fs));const target=fs.filter(x=>x.name===FN);check(target.length===1&&typeof target[0].functionId==='string'&&target[0].functionId);
  const id=target[0].functionId,others=summarizeFunctions(fs),routes=summarizeRoutes(rs);
  await a.mark();const result=await a.update();check(result&&typeof result.RequestId==='string'&&result.RequestId.length>0);
  let ready=false;
  for(let i=0;i<8;i++){
   const d=await a.detail();detail(d);check(['Active','Updating'].includes(d.Status));const after=envFingerprint(d,key);check(crypto.timingSafeEqual(env,after));
   if(d.Status==='Active'){const h=await a.codeHash();if(h===a.packageHash){ready=true;break}check(h===OLD)}
   if(i<7)await a.delay(1500);
  }
  check(ready&&trigger(await a.triggers())===triggerId);check(await a.status(triggerId)===true);const fs2=await a.functions(),rs2=await a.routes();
  check(fs2.filter(x=>x.name===FN&&x.functionId===id).length===1&&summarizeFunctions(fs2)===others&&summarizeRoutes(rs2)===routes);
  const last=await a.detail();detail(last);check(last.Status==='Active');check(crypto.timingSafeEqual(env,envFingerprint(last,key)));check(await a.codeHash()===a.packageHash);
  return {updated:true,paymentEnabled:false,otherMetadataUnchanged:true};
 }finally{key.fill(0)}
}
module.exports={request,run};
