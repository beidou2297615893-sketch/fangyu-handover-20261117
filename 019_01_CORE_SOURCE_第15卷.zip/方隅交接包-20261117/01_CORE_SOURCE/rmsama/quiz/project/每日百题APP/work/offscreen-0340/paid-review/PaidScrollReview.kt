package expo.modules.automationbridge
import expo.modules.automationbridge.bank.*
import expo.modules.automationbridge.generic.*
import expo.modules.automationbridge.runtime.*
import expo.modules.automationbridge.screen.*
import expo.modules.automationbridge.billing.*
private val q=CanonicalQuestion("one","single","哪个数不等于零？",listOf(QuestionOption("a","0"),QuestionOption("b","1")),listOf("b"))
private val r=GenericRecognizer(listOf(q))
private fun page(vararg text:String,frame:String="v1"):PageSnapshot {
 val root=ScreenNode("0","","","","FrameLayout",Bounds(0,0,600,1000),false,false,false)
 val regions=text.mapIndexed { i,t -> OcrRegion("ocr:$i",t,Bounds(30,100+i*80,550,140+i*80),"f",1) }
 return PageSnapshot("f",100,"org.target",1,listOf(root),regions,ScreenFingerprint.of("org.target",1,600,1000,listOf(root),regions),600,1000,visualFrame=frame)
}
private fun initial()=RunFacts("run","ws","rev","__generic__",1,"hash",status="running",phase="submitting",total=2,pendingSubmit=true,pendingSubmissionId="real-submit",pendingAt=100,lastOrdinal=1,lastFingerprint=QuestionMatcher.key(q.type,q.stem,q.options.map { it.text }))
fun main() {
 var passed=0
 fun test(name:String,body:()->Unit) {body();passed++;println("PASS $name")}
 test("repeated receipt scroll and codec preserve real submission identity and count") {
  val records=mutableListOf<Pair<RunFacts,ActionIntent?>>()
  val c=GenericCoordinator(r,initial()){f,a->records.add(f to a)}
  for(i in 1..3) {val a=checkNotNull(c.onPage(page("解析",frame="v$i"),1000L*i));check(a.purpose=="scroll" && a.id!="real-submit");check(c.facts.pendingSubmissionId=="real-submit" && c.facts.submittedCount==0 && c.facts.pendingSubmit)}
  val saved=RunCodec.decode(RunCodec.encode(c.facts));check(saved==c.facts)
  val recovered=saved.recoverAfterRestart("restart");check(recovered.status=="paused" && recovered.submissionIntentId=="real-submit")
  check(records.none {it.second?.purpose=="submit"})
 }
 test("first feedback receipt remains blocked until settlement and is counted once") {
  var allowed=false
  val c=GenericCoordinator(r,initial(),{allowed}){_,_->}
  check(c.onPage(page("回答正确"),1000)==null)
  check(c.facts.submittedCount==1 && !c.facts.pendingSubmit && c.facts.pendingSubmissionId==null && c.facts.viewportSearch?.mode=="finding_next")
  repeat(3){check(c.onPage(page("下一题"),2000L+it)==null)}
  allowed=true
  val a=checkNotNull(c.onPage(page("下一题"),3000));check(a.purpose=="next" && c.facts.pendingNavigation && c.facts.submittedCount==1)
 }
 test("stopped receipt checks with retained search never issue actions") {
  val c=GenericCoordinator(r,initial()){_,_->}
  check(c.onPage(page("解析"),1000)?.purpose=="scroll");c.stop()
  val restored=RunCodec.decode(RunCodec.encode(c.facts))
  val checkOnly=GenericCoordinator(r,restored){_,a->check(a==null)}
  checkOnly.checkReceipt(2000)
  check(checkOnly.onPage(page("解析",frame="v2"),3000)==null)
  check(checkOnly.onPage(page("回答正确","下一题",frame="v3"),4000)==null)
  check(checkOnly.facts.status=="stopped" && checkOnly.facts.submittedCount==1)
  check(checkOnly.onPage(page("下一题"),5000)==null)
 }
 test("first receipt validation tolerates search state and keeps submission phase") {
  val c=GenericCoordinator(r,initial()){_,_->}
  c.onPage(page("解析"),1000)
  val before=c.facts
  check(before.phase=="submitting")
  val target=PaidTarget("org.target",1,"signer")
  val blocked=GenericCoordinator(r,before,{false}){f,_->if(f.submittedCount==1) PaidSubmissionGuard.validateReceipt(before,f,target,target)}
  check(blocked.onPage(page("回答正确"),2000)==null && blocked.facts.submittedCount==1)
 }
 test("legacy snapshot still has stable pending submission fallback across scroll") {
  val old=RunCodec.encode(initial());old.remove("pendingSubmissionId");old.remove("viewportSearch")
  val f=RunCodec.decode(old);val id=f.submissionIntentId
  val c=GenericCoordinator(r,f){_,_->};c.onPage(page("解析"),1000)
  check(c.facts.submissionIntentId==id && c.facts.pendingSubmit && c.facts.submittedCount==0)
 }
 println("Paid scroll scoped review: $passed passed")
}
