param([switch]$Apply)
$ErrorActionPreference='Stop'
if($Apply){throw '预览脚本不执行云操作；真实入口为 run.ps1，须先完成审查。'}
$envId='fh6-d5ga45c0ddae7008c'
$region='ap-shanghai'
$collections=@('daily_hundred_payment_v1','daily_hundred_installation_v1')
$steps=foreach($name in $collections){
  [ordered]@{action='tcb.CreateTable';region=$region;apiVersion='2018-06-08';body=[ordered]@{EnvId=$envId;TableName=$name;PermissionInfo=[ordered]@{AclTag='ADMINONLY';EnvId=$envId}}}
}
[ordered]@{mode='dry-run';network=$false;paymentEnabled=$false;create=$steps;policy=[ordered]@{documentId='policy';kind='policy';schema=1;enabled=$false};applyAvailable=$false;reason='function execution role and live API path not verified'} | ConvertTo-Json -Depth 8
