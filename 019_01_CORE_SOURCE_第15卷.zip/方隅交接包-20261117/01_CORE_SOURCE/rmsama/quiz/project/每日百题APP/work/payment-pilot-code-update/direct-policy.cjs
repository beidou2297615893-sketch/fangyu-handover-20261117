'use strict';
// Injectable administrative transaction only; no SDK initialization or credentials.
const names=Object.freeze(['daily_hundred_installation_v1','daily_hundred_payment_v1']);
const check=x=>{if(!x)throw Error('unavailable')};
async function readPolicies(db){
 check(db&&typeof db.runTransaction==='function');
 return db.runTransaction(async tx=>{const out=[];for(const name of names){const r=await tx.collection(name).doc('policy').get(),d=r?.data;check(r&&!r.code&&d?._id==='policy'&&d.kind==='policy'&&d.schema===1&&typeof d.enabled==='boolean');out.push(d);}return out;},0);
}
async function enablePolicies(db){
 check(db&&typeof db.runTransaction==='function');
 // Both preconditions and both exact-field writes are in the same transaction.
 await db.runTransaction(async tx=>{
  const refs=names.map(n=>tx.collection(n).doc('policy'));
  for(const ref of refs){const r=await ref.get(),d=r?.data;check(r&&!r.code&&d?._id==='policy'&&d.kind==='policy'&&d.schema===1&&d.enabled===false);}
  for(const ref of refs){const r=await ref.update({enabled:true});check(r&&!r.code&&r.updated===1);}
 },0);
 const confirmed=await readPolicies(db);check(confirmed.length===2&&confirmed.every(x=>x.enabled===true));return true;
}
module.exports={readPolicies,enablePolicies};
