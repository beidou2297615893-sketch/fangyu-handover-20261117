const nock=require('nock');nock.disableNetConnect(); const calls=[];
const token='eyJhbGciOiJub25lIn0.eyJzdWIiOiJmaXh0dXJlIiwiaXNfYW5vbnltb3VzIjpmYWxzZX0.x';
nock(/.*/).persist().post(/.*/).reply(function(uri,body){let p=uri.split('?')[0];calls.push({path:p,method:this.req.method,auth:!!this.req.headers.authorization});if(p.includes('signin'))return [200,{access_token:token,refresh_token:'fake',expires_in:3600}];if(p.includes('/user'))return [200,{id:'fixture',is_anonymous:false}];return [200,{}]});
(async()=>{try{let app=require('@cloudbase/js-sdk').init({env:'fixture-env',region:'ap-shanghai',persistence:'none',timeout:1500});let r=await app.auth.signInWithPassword({username:'fakeuser',password:'[REDACTED:assigned_secret]'});console.log(JSON.stringify({hasSession:!!r?.data?.session,uidMatches:r?.data?.session?.user?.id==='fixture',error:r?.error,calls}));}catch(e){console.log(JSON.stringify({exception:e.name,calls}))}process.exit(0)})();


