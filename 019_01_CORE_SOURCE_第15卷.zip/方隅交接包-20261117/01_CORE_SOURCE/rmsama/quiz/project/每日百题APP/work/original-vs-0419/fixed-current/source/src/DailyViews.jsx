import React, {useEffect, useRef, useState} from 'react';
import {ArrowLeft, ChevronRight, FileUp, ClipboardCheck, Wallet, ShieldCheck, Check, FolderOpen, Crown, Layers, CalendarDays} from 'lucide-react';
import {listQuestionBank, importQuestionBank, importQuestionBankFile, isQuestionBankAvailable} from './lib/nativeBridge.js';
import {getPaymentStatus, refreshPayment, purchasePlan, subscribePaymentStatus, paymentEntitlementText, paymentStatusNotice} from './lib/payment.js';

function useBankCount() {
 const [count,setCount]=useState(null);
 const refresh=()=>listQuestionBank({limit:1}).then(v=>setCount(v?.total ?? 0)).catch(()=>setCount(null));
 useEffect(()=>{refresh()},[]); return [count,refresh];
}
const countText = count => count === null ? '题库读取中' : count ? `已导入 ${count.toLocaleString()} 题` : '尚未导入题库';
function Mark({icon:Icon}) {return <span className="zt-mark"><Icon aria-hidden="true" size={31} strokeWidth={1.65}/></span>}
function Header({title,onBack}) {return <header className="zt-page-header"><button className="zt-back" onClick={onBack} aria-label="返回首页"><ArrowLeft size={25}/></button><h1>{title}</h1></header>}
function Card({icon,title,detail,onClick,primary=false}) {return <button className={`zt-card ${primary?'zt-card-primary':''}`} onClick={onClick}><Mark icon={icon}/><span className="zt-card-copy"><strong>{title}</strong><small>{detail}</small></span><ChevronRight className="zt-arrow" aria-hidden="true"/></button>}
export function DailyHomeView({onNavigate}) {
 const [count]=useBankCount();
 return <section className="zt-home"><div className="zt-brand"><h1>知题</h1><p>自动化答题助手</p></div><div className="zt-home-actions"><Card icon={FileUp} title="导入题库" detail={countText(count)} onClick={()=>onNavigate('bank')}/><Card icon={ClipboardCheck} title="一键答题" detail="查看答题状态" primary onClick={()=>onNavigate('run')}/><Card icon={Wallet} title="支付" detail="查看权益与套餐" onClick={()=>onNavigate('settings')}/></div></section>;
}
export function DailyRunView({active,busy,error,onStart,onStop,onImport,native,capabilities,onBack}) {
 const [count]=useBankCount();
 const needsImport = !active && count === 0;
 const start = () => {
   if (active) return onStop();
   if (needsImport) return onImport();
   return onStart();
 };
 const permission = !native ? '请在手机应用中使用' : capabilities?.overlay && capabilities?.gesture ? (capabilities?.gestureReady === false ? '无障碍已开启，自动点击服务连接中' : '悬浮窗与无障碍已开启') : '待检查';
 return <section className="zt-page"><Header title="一键答题" onBack={onBack}/><div className="zt-stack">
   <div className="zt-info"><Mark icon={FileUp}/><div><strong>题库</strong><small>{countText(count)}</small></div></div>
   <div className="zt-info"><Mark icon={ClipboardCheck}/><div><strong>当前状态</strong><small>{busy?'正在准备':active?'答题中':'未开始'}</small></div></div>
   <div className="zt-info"><Mark icon={ShieldCheck}/><div><strong>权限</strong><small>{permission}</small></div></div>
   {!active && <p className="zt-muted">优先使用已导入的题库，无法可靠作答时会暂停。</p>}
   {error&&<p className="zt-error" role="alert">{error}</p>}
   <button className="zt-action" disabled={busy || !native || (!active && count === null)} onClick={start}>{busy?'正在准备…':active?'结束答题':needsImport?'先导入题库':'开始答题'}<ChevronRight aria-hidden="true"/></button>
 </div></section>;
}
const readBase64=file=>new Promise((ok,fail)=>{const r=new FileReader();r.onload=()=>ok(String(r.result).split(',')[1]||'');r.onerror=()=>fail(new Error('文件读取失败'));r.readAsDataURL(file)});
export function DailyBankView({notify,onBack}) {
 const input=useRef(null); const [count,refresh]=useBankCount(); const [busy,setBusy]=useState(false),[error,setError]=useState(''),[recent,setRecent]=useState(null);
 async function load(e) {const file=e.target.files?.[0];e.target.value='';if(!file)return;if(count===null){setError('题库状态尚未读取，请稍后再试');return}if(count>0&&!window.confirm('导入会替换当前题库，确定继续吗？'))return;setBusy(true);setError('');try{const result=/\.json$/i.test(file.name)?await importQuestionBank(await file.text()):await importQuestionBankFile(file.name,await readBase64(file));if(!result?.ok)throw new Error(result?.error||'导入失败');await refresh();setRecent(result.count);notify(`已导入 ${result.count} 道题`)}catch(err){setError(err.message||'导入失败')}finally{setBusy(false)}}
 return <section className="zt-page"><Header title="导入题库" onBack={onBack}/><div className="zt-import-panel"><Mark icon={FileUp}/><h2>选择题库文件</h2><p>请选择 Excel、CSV、TXT 或 JSON 题库文件，导入会替换当前题库</p><input ref={input} hidden type="file" onChange={load}/><button className="zt-action" onClick={()=>input.current?.click()} disabled={busy||!isQuestionBankAvailable()}><FolderOpen size={22}/>{busy?'正在导入…':'选择文件'}<ChevronRight/></button><div className="zt-format-title">支持的文件格式</div><div className="zt-formats"><span>XLSX</span><span>XLS</span><span>CSV</span><span>TXT</span><span>JSON</span></div></div>{error&&<p className="zt-error" role="alert">{error}</p>}<div className="zt-info zt-recent"><Mark icon={ClipboardCheck}/><div><strong>{recent===null?'题库':'最近导入'}</strong><small>{recent===null?countText(count):`${recent.toLocaleString()} 题`}</small></div></div></section>;
}
export function DailyAccountView({onBack}) {
 const [status,setStatus]=useState(null),[error,setError]=useState(''),[busy,setBusy]=useState(false),[selected,setSelected]=useState(null),[loading,setLoading]=useState(true);
 useEffect(()=>{let live=true; const unsubscribe=subscribePaymentStatus(v=>{if(live){setStatus(v);setError('')}}); getPaymentStatus().then(v=>{if(live)setStatus(v);return refreshPayment()}).then(v=>{if(live)setStatus(v)}).catch(()=>{if(live)setError('付款服务暂时不可用')}).finally(()=>{if(live)setLoading(false)}); return()=>{live=false;unsubscribe()}},[]);
 const plans=Array.isArray(status?.plans)?status.plans:[]; const chosen=plans.find(p=>p.id===selected);
 async function invoke(fn){setBusy(true);setError('');try{setStatus(await fn())}catch(e){setError(e.message||'付款服务暂时不可用')}finally{setBusy(false)}}
 return <section className="zt-page"><Header title="支付" onBack={onBack}/><div className="zt-stack zt-payment"><div className="zt-info"><Mark icon={Crown}/><div><strong>当前权益</strong><small>{paymentEntitlementText(status)}</small></div></div>{plans.map((p,i)=><button key={p.id} className={`zt-plan ${selected===p.id?'zt-plan-selected':''}`} onClick={()=>setSelected(p.id)} disabled={busy||!status?.available}><Mark icon={i===0?Layers:CalendarDays}/><span><strong>{p.priceText}</strong><small>{p.name}</small></span><span className="zt-radio">{selected===p.id&&<Check size={17}/>}</span></button>)}{!plans.length&&(loading?<div className="zt-loading" role="status"><span className="zt-spinner"/>正在加载套餐…</div>:<p className="zt-muted">{error||'套餐暂不可用，请稍后再试'}</p>)}<button className="zt-action" disabled={busy||!chosen||!status?.available} onClick={()=>invoke(()=>purchasePlan(chosen.id))}>支付宝支付<ChevronRight/></button><button className="zt-secondary" disabled={busy||loading} onClick={()=>invoke(refreshPayment)}>{busy?'正在核对…':'核对付款状态'}</button>{paymentStatusNotice(status)&&<p className="zt-muted" role="status">{paymentStatusNotice(status)}</p>}{error&&<p className="zt-error" role="alert">{error}</p>}</div></section>;
}
