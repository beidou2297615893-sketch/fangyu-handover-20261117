'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict'),crypto=require('node:crypto');
const {createStableInstallation}=require('./stable-installation');
const random=()=>crypto.randomBytes(32).toString('base64url');
function fixture(enabled=true,key='K'.repeat(64)){
  const records=new Map(enabled?[['policy',{kind:'policy',schema:1,enabled:true}]]:[]);
  let now=1800000000000;
  const db={async runTransaction(fn){return fn({collection(name){assert.equal(name,'daily_hundred_installation_v1');return {doc(id){return {async get(){return {data:records.has(id)?{_id:id,...records.get(id)}:null};},async set(value){records.set(id,value);return {updated:1};}};}};}});}};
  return {core:createStableInstallation({db,registrationKey:key,clock:()=>now}),records,setTime:value=>{now=value;}};
}
test('installation bearer remains valid after months and retries do not change owner',async()=>{
  const f=fixture(),input={requestId:random(),verifier:random()};
  const first=await f.core.register(input),again=await f.core.register(input);
  f.setTime(1800000000000+400*86400000);assert.deepEqual(first,again);assert.equal(await f.core.authenticate(first.accessToken),first.installationId);
  assert.equal(first.accessToken.length,43);assert.equal(first.recoverySupported,false);
  assert.equal(Buffer.from(first.accessToken,'base64url')[0],0x49,'installation credentials have a distinct type');
  assert.equal([...f.records.values()].filter(x=>x.kind==='registration').length,1);
  assert.ok(!JSON.stringify([...f.records]).includes(input.verifier));assert.ok(!JSON.stringify([...f.records]).includes(first.accessToken));
});
test('a changed verifier for the same request is rejected and another request gets a different account',async()=>{
  const f=fixture(),input={requestId:random(),verifier:random()},a=await f.core.register(input);
  await assert.rejects(f.core.register({...input,verifier:random()}));const c=await f.core.register({...input,requestId:random()});
  assert.notEqual(a.installationId,c.installationId);
});
test('forged, malformed, wrong-key, and disabled credentials fail closed',async()=>{
  const f=fixture(),input={requestId:random(),verifier:random()},a=await f.core.register(input);
  const bytes=Buffer.from(a.accessToken,'base64url');bytes[0]^=1;
  await assert.rejects(f.core.authenticate(bytes.toString('base64url')));await assert.rejects(f.core.authenticate('not-a-token'));
  await assert.rejects(fixture(true,'D'.repeat(64)).core.authenticate(a.accessToken));
  f.records.set('policy',{kind:'policy',schema:1,enabled:false});await assert.rejects(f.core.authenticate(a.accessToken));await assert.rejects(f.core.register(input));
});
test('malformed inputs cannot make credentials or attach additional identities',async()=>{
  const f=fixture();for(const value of [{requestId:'bad',verifier:random()},{requestId:random(),verifier:random(),deviceDigest:'a'.repeat(64)},null])await assert.rejects(f.core.register(value));
});
test('new registration limit does not block idempotent retries and advances with time',async()=>{
  const f=fixture(),input={requestId:random(),verifier:random()},first=await f.core.register(input);
  for(let i=1;i<120;i++)await f.core.register({requestId:random(),verifier:random()});
  await assert.rejects(f.core.register({requestId:random(),verifier:random()}));
  assert.deepEqual(await f.core.register(input),first);
  f.setTime(1800000000000+60000);assert.ok((await f.core.register({requestId:random(),verifier:random()})).accessToken);
});
test('revoked installation proof cannot be authenticated or re-registered',async()=>{
  const f=fixture(),input={requestId:random(),verifier:random()},a=await f.core.register(input);
  const id='revoked-'+crypto.createHash('sha256').update(a.installationId).digest('hex');
  f.records.set(id,{kind:'revoked',owner:a.installationId});
  await assert.rejects(f.core.authenticate(a.accessToken));await assert.rejects(f.core.register(input));
});
