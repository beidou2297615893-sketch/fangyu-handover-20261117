$ErrorActionPreference='Stop'
$reviewWork=Split-Path -Parent (Split-Path -Parent $PSScriptRoot)
$reviewRoot=Split-Path -Parent $reviewWork
$reviewSource=Join-Path $reviewRoot 'outputs/daily-hundred-app/modules/automation-bridge/android/src/main/java/expo/modules/automationbridge'
$reviewJdk=(Get-ChildItem -LiteralPath (Join-Path $reviewWork 'tools/jdk') -Directory | Select-Object -First 1).FullName
$reviewLib=(Get-ChildItem -LiteralPath (Join-Path $reviewWork 'gradle-home/wrapper/dists/gradle-9.3.1-bin') -Recurse -Directory -Filter lib | Select-Object -First 1).FullName
$reviewClasses=Join-Path $PSScriptRoot 'classes'
New-Item -ItemType Directory -Path $reviewClasses -Force | Out-Null
$reviewCp=(Join-Path $reviewWork 'offscreen-0340/host-classes')+';'+(Join-Path $reviewLib 'kotlin-stdlib-2.2.21.jar')+';'+(Join-Path $reviewWork 'native-host-tests/json-20250517.jar')
$reviewFiles=@('screen/ScreenModels.kt','screen/QuestionExtractor.kt','profile/WorkflowProfile.kt','profile/WorkflowValidator.kt','bank/WorkspaceRepository.kt','bank/QuestionMatcher.kt','runtime/RunModels.kt','runtime/RunCodec.kt','billing/PaidSubmissionGuard.kt') | ForEach-Object {Join-Path $reviewSource $_}
$reviewFiles+=Get-ChildItem -LiteralPath (Join-Path $reviewSource 'generic') -Filter '*.kt' | Where-Object Name -ne 'GenericDriver.kt' | Select-Object -ExpandProperty FullName
$reviewFiles | Get-FileHash | Select-Object Path,Hash | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $PSScriptRoot 'tested-source-hashes.json')
& (Join-Path $reviewJdk 'bin/java.exe') -cp ($reviewLib+'/*') org.jetbrains.kotlin.cli.jvm.K2JVMCompiler -no-stdlib -no-reflect -classpath $reviewCp -d $reviewClasses $reviewFiles (Join-Path $PSScriptRoot 'PaidScrollReview.kt')
if($LASTEXITCODE -ne 0){throw 'Review compilation failed'}
& (Join-Path $reviewJdk 'bin/java.exe') -cp ($reviewClasses+';'+$reviewCp+';'+(Join-Path $reviewSource '../../../../resources')) expo.modules.automationbridge.PaidScrollReviewKt 2>&1 | Tee-Object -LiteralPath (Join-Path $PSScriptRoot 'result.log')
if($LASTEXITCODE -ne 0){throw 'Review failed'}


