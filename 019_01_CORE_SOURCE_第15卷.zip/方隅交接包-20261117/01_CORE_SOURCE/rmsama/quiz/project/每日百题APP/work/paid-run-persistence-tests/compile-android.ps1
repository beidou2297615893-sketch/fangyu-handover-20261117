$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path -Parent (Split-Path -Parent $PSScriptRoot)
$jdk = (Get-ChildItem (Join-Path $projectRoot 'work/tools/jdk') -Directory | Select-Object -First 1).FullName
$lib = (Get-ChildItem (Join-Path $projectRoot 'work/gradle-home/wrapper/dists/gradle-9.3.1-bin') -Directory -Recurse -Filter lib | Select-Object -First 1).FullName
$android = Join-Path $projectRoot 'work/tools/android-sdk/platforms/android-36/android.jar'
$source = Join-Path $projectRoot 'outputs/daily-hundred-app/modules/automation-bridge/android/src/main/java/expo/modules/automationbridge/billing/PaidRunStore.kt'
$classes = Join-Path $PSScriptRoot 'android-classes'; New-Item -ItemType Directory -Force $classes | Out-Null
$java = Join-Path $jdk 'bin/java.exe'; $stdlib = Join-Path $lib 'kotlin-stdlib-2.2.21.jar'
& $java '-Dfile.encoding=UTF-8' -cp "$lib/*" org.jetbrains.kotlin.cli.jvm.K2JVMCompiler -no-stdlib -no-reflect -classpath "$stdlib;$android" -d $classes $source
if ($LASTEXITCODE -ne 0) { throw 'Paid run store compilation failed' }
Write-Output 'Paid run store compiled against Android SDK; no Android runtime test.'
