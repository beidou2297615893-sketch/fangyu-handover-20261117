'use strict';
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const sha=f=>crypto.createHash('sha256').update(fs.readFileSync(f)).digest('hex');
function tree(root){const names=[];function walk(dir,prefix=''){for(const ent of fs.readdirSync(dir,{withFileTypes:true})){const f=path.join(dir,ent.name),n=prefix?prefix+'/'+ent.name:ent.name;if(ent.isSymbolicLink())throw Error('symlink');if(ent.isDirectory())walk(f,n);else if(ent.isFile())names.push(n);else throw Error('unexpected');}}walk(root);names.sort();const digest=crypto.createHash('sha256');for(const n of names)digest.update(n).update('\0').update(sha(path.join(root,n))).update('\n');return {count:names.length,digest:digest.digest('hex')};}
module.exports={sha,tree};
