import control as c
import time,json,sys
out=c.R/(sys.argv[1] if len(sys.argv)>1 else 'batch-check');out.mkdir(exist_ok=True)
last=-1;start=time.monotonic()
while time.monotonic()-start<500:
    try:
        raw=c.adb('exec-out','run-as','com.jimusoft.dailyhundredapp.audit419.dev','cat','files/batch-ocr-result.json')
        data=json.loads(raw)
    except Exception:time.sleep(1);continue
    (out/'batch-ocr-result.json').write_bytes(raw)
    rows=data['results'];pages=data.get('pageCompared',0)>0 and data.get('bankCompared',0)==0
    wrong=0 if pages else sum(bool(x.get('resolvedSource')) and not x.get('matchesExpected',False) for x in rows)
    passed=data.get('pagePassed',0) if pages else data['passed']
    p={'kind':'pages' if pages else 'batch','processed':data['processed'],'total':data['total'],'passed':passed,
       'wrong':wrong,'unmatched':data['processed']-passed-wrong,'elapsedSeconds':round(data['elapsedMs']/1000,1),'finished':data['finished']}
    (out/'current-progress.json').write_text(json.dumps(p,indent=2),encoding='utf-8')
    if data['processed']//10!=last:print(json.dumps(p),flush=True);last=data['processed']//10
    if data['finished']:
        print('Final:',json.dumps(p),flush=True);break
    time.sleep(2)
