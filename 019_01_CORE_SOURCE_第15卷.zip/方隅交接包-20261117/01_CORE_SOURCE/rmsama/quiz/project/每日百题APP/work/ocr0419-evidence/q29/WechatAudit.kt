package com.futureyyy.tijing
import com.google.gson.*
import java.io.File
fun main(){
 val bankRoot=JsonParser.parseString(File("V:/work/知题本轮验收/bank/铁路题库-保留选项变体.json").readText()).asJsonObject
 fun type(s:String)=when(s){"multiple"->QuestionType.MULTIPLE;"boolean","true_false"->QuestionType.TRUE_FALSE;"fill_blank"->QuestionType.FILL_BLANK;else->QuestionType.SINGLE}
 val records=bankRoot.getAsJsonArray("questions").map{v->val q=v.asJsonObject;LocalQuestionBankRecord(q.get("id").asString,q.get("question").asString,type(q.get("type").asString),q.getAsJsonArray("answer_indices").map{it.asInt},answerText=q.get("answer_text").asString,options=q.getAsJsonArray("options").map {val o=it.asJsonObject;QuizOption(o.get("index").asInt,o.get("text").asString,null)})}
 val bank=QuestionBankIndex.fromRecords(records, bankRoot.getAsJsonArray("conflicts").map { it.asJsonObject["normalized_question"].asString }.toSet())
 val archive=JsonParser.parseString(File("V:/work/ocr0419-evidence/q29/pages-paddle-3.json").readText()).asJsonArray
 val output=JsonArray()
 for(item in archive){ val f=item.asJsonObject;val lines=f["lines"].asJsonArray.map { el->val v=el.asJsonObject;val b=v["box"].asJsonArray;VisibleQuestionReader.Node(v["text"].asString,NormalizedBox(b[0].asFloat,b[1].asFloat,b[2].asFloat,b[3].asFloat)) }
 val host=OcrHostPage.read(lines);val box=OcrHostPage.confirmBox(lines);val maybe=VisibleQuestionReader.readOcrLines(lines,host.page.progress?.current?:1)
 val result=maybe?.let{runCatching{bank.verifiedAnswer(it)}.getOrNull()}?:bank.verifiedOcrPage(lines,host.page.progress?.current?:1)
 output.add(JsonObject().apply {add("file",f["file"]);addProperty("isResults",host.result);addProperty("hostProgress",host.page.progress?.let { it.current.toString()+"/"+it.total });addProperty("confirm",box.toString());addProperty("stem",maybe?.question);addProperty("matched",result!=null);addProperty("answer",result?.answerIndices?.joinToString("") { ('A'+it).toString() }); addProperty("options",result?.options?.joinToString(";") { it.text });addProperty("type",result?.type?.name);addProperty("centres",result?.options?.joinToString(";") { it.box?.let { b->"%.1f,%.1f".format(java.util.Locale.US,b.centerX,b.centerY) }.orEmpty() })})
 }
 File("V:/work/ocr0419-evidence/q29/paired-3-result.json").writeText(GsonBuilder().setPrettyPrinting().create().toJson(output))
}



