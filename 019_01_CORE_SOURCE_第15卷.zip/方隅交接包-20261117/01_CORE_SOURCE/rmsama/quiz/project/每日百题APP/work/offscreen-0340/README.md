# 0.3.40 离屏下一题修复与验收

用户目标：一次开始后自动读题、点选、截图核对、提交；下一题离屏时向下查找，下一题停留底部时向上恢复题干，连续完成100题。

本轮发布范围：只更新蒲公英。用户要求服务器先等；上一轮0.3.39服务器发布在收到停止前已经完成，已如实告知，后续禁止继续修改服务器。

已确认手机实际运行0.3.38。蒲公英公开短链目前是0.3.39 / Build18，build key `356d7c6501601b3bba54e13b5f4b4122`。本轮新版本已由root改为0.3.40 / Android code45，尚未构建验收及发布。

旧包红测：`baseline-red-5590/visual-e2e`。最终0.3.39 APK SHA256 `bf2706f0ffc4cfdb13bf61f41f632bde13ae63373cb3551ca0d8c04bfe2d16a9` 实际第一题提交正确，但next离屏导致回执无法确认而暂停，未注入代点/代滚。

生产修复由 `/root/screenshot_branch_review` 负责；源码baseline在 `native-before`。完成页分类、自动跳题、原生上滚profile和首次付费结算恢复状态等审查问题均已修复；付费专项Astra复核5/5通过，报告在paid-review。专用host19绿，既有generic106、receipt11、paid gate12、native persistence23通过。

设备开发探针 `visual-selection/scroll0340-probe-false-evidence` 已真实下滑并点中第1题next；新题停底部为空白时，ScreenReader OCR_NO_TEXT直接让Driver暂停，无法交Coordinator向上恢复。这是新确认阻塞，agent正局限补Driver授权恢复（不放宽初次无字/真正受保护/权限等），源码再次解冻。旧API空识字不应被伪造为题目或答案。

已完成2次Android开发构建，均非最终发布候选：probe1 SHA602f2de19ff5047f000d43dcd331beb761f875a69bf609ecb16e5ca49e3abf54（用于FREE5题探针）；build2 SHA bad1f09936d176b4f44451134df46f2e7b97f7a497632a9b1f02daf4fb445e6a（修了付费恢复但还缺空白恢复，禁止百题验收/发布）。最终须待新冻结后重新build，复制immutable APK并记录实际SHA。

用户追加：AI兜底余额始终未扣，要求核查真实链路且不要影响滚动任务。`/root/ai_fallback_audit` 正并行只读调查运行中AI（区别导入AI），暂未授权其改源码/调用API/部署。Root需用一次受控真实请求验证实际请求/回执，密钥不可输出；服务器APK发布继续暂停，不能擅自重发更新清单。

独立目标与harness由 `/root/offscreen_fixture` 实现，`work/visual-selection/run-emulator.ps1 -ScrollNext` 开启，默认关闭。题库原文件SHA256 `e7cdb49bdd3f29bb4513d0970ba0856c2cc1dced653037a26fbb4af5c3c86824` 未改。

每题独立记录：progress、navigation、feedback-initial、question-initial、scroll-events；harness只能注入开题/浮窗开始两次，禁止代点和代滚。

设备：ADB端口15039，root专用emulator-5588已启动（headless readonly，进程80316）；QA5590已完成红测并关闭，正式验收再启动。不得触碰其他设备。

计划：同一最终签名APK先短程离屏验收，再两套无障碍空root布局各完整100题；独立核对题序/100唯一题/正确率/next点击/真实上下滚动/安装包哈希；只发布这份包到蒲公英并保存公开页凭据。

浏览器：Chrome ID3，公开页tab896073763，上传页tab896073764，均已登录。CUA变量releaseTab、releaseUploadTab。尚未上传新包，CUA尚未completion_summary；最终公开页确认新版本、截图落盘和markDeliverable后，下一工具调用必须completion_summary。

真实进度配置：`work/visual-selection/acceptance-monitor.json`；窗口进程22952。
