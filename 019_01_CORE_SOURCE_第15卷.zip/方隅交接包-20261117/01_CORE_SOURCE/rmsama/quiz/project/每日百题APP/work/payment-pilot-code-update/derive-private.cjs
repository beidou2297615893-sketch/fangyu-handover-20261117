'use strict';
// Local only. Credentials never appear on stdout, argv, or in a deployment package.
const fs=require('node:fs'),path=require('node:path'),os=require('node:os'),{spawnSync}=require('node:child_process');
for(const n of ['log','info','warn','error','debug','trace'])console[n]=()=>{};
try{
 for(const k of ['NODE_OPTIONS','NODE_DEBUG','DEBUG','NODE_EXTRA_CA_CERTS','NODE_PATH'])if(process.env[k])throw Error();if(process.execArgv.length)throw Error();
 const shell=path.join(os.homedir(),'.cache','codex-runtimes','codex-primary-runtime','dependencies','native','powershell','pwsh.exe');const check=spawnSync(shell,['-NoProfile','-NonInteractive','-File',path.join(__dirname,'private-acl.ps1')],{encoding:'utf8',timeout:15000,windowsHide:true});if(check.status!==0||check.stdout!=='OK'||check.stderr)throw Error();
 const dir=path.resolve(__dirname,'../payment-pilot-private'),source=path.join(dir,'identity.json'),out=path.join(dir,'pilot-config.json');if(fs.existsSync(out))throw Error();
 // Refuse creation of new master material. This must be the existing key.
 for(const p of ['master.dpapi','master.backup.dpapi'])if(!fs.existsSync(path.resolve(__dirname,'../payment-secret-prep/master-store',p)))throw Error();
 const identity=JSON.parse(fs.readFileSync(source,'utf8')),master=require('../payment-secret-prep/master-bridge.cjs').loadMaster({fixture:false});
 try{const config=require('./derive-core.cjs').derive(master,identity);const fd=fs.openSync(out,'wx',0o600);try{fs.writeFileSync(fd,JSON.stringify(config));fs.fsyncSync(fd)}finally{fs.closeSync(fd)}}finally{master.fill(0)}
 process.stdout.write('{"prepared":true,"cloudWrite":false,"credentialsPrinted":false}\n');
}catch{process.stdout.write('{"prepared":false,"cloudWrite":false}\n');process.exitCode=2}
