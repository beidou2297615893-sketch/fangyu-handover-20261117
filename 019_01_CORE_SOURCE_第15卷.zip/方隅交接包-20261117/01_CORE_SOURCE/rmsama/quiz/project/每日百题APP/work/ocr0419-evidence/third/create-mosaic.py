from PIL import Image,ImageOps
from pathlib import Path
import json,math
root=Path(__file__).parent
assets=root.parent/'app/src/main/assets'
all_maps={}
for row in json.loads((root/'lines-production.json').read_text(encoding='utf8')):
 name=row['file']
 if name.startswith('extra-'):continue
 im=Image.open(assets/name).convert('RGB');w,h=im.size
 items=sorted(row['lines'],key=lambda v:(v['box'][1],v['box'][0]))
 # Keep all visible detected lines, including progress, button and labels. No expected content is consulted.
 scale=3.0; gap=24; pad=18; mapping=[]; y=pad
 width=math.ceil(w*scale)+2*pad
 for v in items:
  x0=math.floor(v['box'][0]*w/100); y0=math.floor(v['box'][1]*h/100)
  x1=math.ceil((v['box'][0]+v['box'][2])*w/100);y1=math.ceil((v['box'][1]+v['box'][3])*h/100)
  border=max(2,math.ceil((y1-y0)*0.18)); x0=max(0,x0-border);x1=min(w,x1+border);y0=max(0,y0-border);y1=min(h,y1+border)
  if x1<=x0 or y1<=y0:continue
  sw=round((x1-x0)*scale); sh=round((y1-y0)*scale)
  mapping.append(dict(source=[x0,y0,x1,y1],tile=[pad,y,pad+sw,y+sh]));y+=sh+gap
 canvas=Image.new('RGB',(width,y+pad),'white')
 for m in mapping:
  x0,y0,x1,y1=m['source'];l,t,r,b=m['tile']
  tile=im.crop((x0,y0,x1,y1)).resize((r-l,b-t),Image.Resampling.LANCZOS)
  canvas.paste(tile,(l,t))
 outname='mosaic-'+name;canvas.save(assets/outname)
 all_maps[outname]=dict(w=w,h=h,sw=canvas.width,sh=canvas.height,rows=mapping)
(root/'line-rois.json').write_text(json.dumps(all_maps),encoding='utf8')
print(len(all_maps))
