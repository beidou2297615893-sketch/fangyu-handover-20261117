from pathlib import Path
import subprocess,os,zipfile,shutil,json,hashlib
r=Path('V:/work/original-vs-0419/original-control');r.mkdir()
source=r/'source';up=Path('V:/work/tijing-upstream')
subprocess.run(['git','clone','--local','--no-hardlinks',str(up),str(source)],check=True)
vanilla=Path('V:/work/tijing-vanilla-compare')
for name in ['android/app/src/dev/AndroidManifest.xml','android/app/src/dev/res/xml/qa_local_transport.xml']:
    target=source/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(vanilla/name,target)
with zipfile.ZipFile('V:/outputs/题镜官方原版/TiJing-0.7.7-open.apk') as archive:
    for name in archive.namelist():
        if name.startswith('assets/web/') and not name.endswith('/'):
            target=source/'android/app/src/main'/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(archive.read(name))
(source/'android/local.properties').write_text('sdk.dir=V:/work/tools/android-sdk\n',encoding='utf-8')
props=source/'android/gradle.properties';props.write_text(props.read_text(encoding='utf-8')+'\nandroid.overridePathCheck=true\n',encoding='utf-8')
env=os.environ.copy();jdk=next(Path('V:/work/tools/jdk').glob('jdk-17*'))
env.update(JAVA_HOME=str(jdk),ANDROID_HOME='V:/work/tools/android-sdk',ANDROID_SDK_ROOT='V:/work/tools/android-sdk',GRADLE_USER_HOME='V:/work/gradle-home')
for name in ['RELEASE_STORE_FILE','RELEASE_STORE_PASSWORD','RELEASE_KEY_ALIAS','RELEASE_KEY_PASSWORD']:env.pop(name,None)
gradle='C:/Users/rmsama/DailyHundredNativeBuild/work/tijing-toolchain/gradle-8.7/bin/gradle.bat'
with (r/'build.log').open('w',encoding='utf-8') as log:
    subprocess.run([gradle,'-p',str(source/'android'),'-I','V:/work/verify-0419-device-a10-final/test-repos.gradle',':app:testDevDebugUnitTest',':app:assembleDevDebug','--offline','--no-daemon','--console=plain','--max-workers=4'],env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
native=Path('android/app/src/main/java/com/futureyyy/tijing')
checks={p.name:p.read_bytes()==(source/native/p.name).read_bytes() for p in (up/native).glob('*.kt')}
assert checks and all(checks.values())
apk=source/'android/app/build/outputs/apk/dev/debug/app-dev-debug.apk'
proof={'apk':str(apk),'sha256':hashlib.sha256(apk.read_bytes()).hexdigest(),'originalNativeFiles':checks,'nativeCodeUnchanged':True,'onlyDebugLoopbackTransportEnabled':True,'webAssetsFromOfficialApk':True}
(r/'proof.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(proof))
