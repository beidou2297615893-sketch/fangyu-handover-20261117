'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const crypto=require('node:crypto');
const {createStableInstallation}=require('./stable-installation');
const {createInternalRouter}=require('./billing-event');
const {createLedger}=require('./free-ledger');
const {createFreeApi}=require('./free-api');
function dbFixture(){
  let docs=new Map([['daily_hundred_installation_v1:policy',{kind:'policy',schema:1,enabled:true}]]),queue=Promise.resolve();
  return {runTransaction(fn){const work=queue.then(async()=>{const next=new Map([...docs].map(([k,v])=>[k,structuredClone(v)]));
    const tx={collection(name){return {doc(id){const k=name+':'+id;return {async get(){return {data:next.has(k)?{_id:id,...structuredClone(next.get(k))}:null}},async set(v){const exists=next.has(k);next.set(k,structuredClone(v));return exists?{updated:1}:{updated:0,upserted:[{_id:id}]}}}}}}};const out=await fn(tx);docs=next;return out;});queue=work.catch(()=>{});return work;}};
}
const random=()=>crypto.randomBytes(32).toString('base64url');
const digest='ab'.repeat(32),binding='cd'.repeat(32),different='ef'.repeat(32);
async function setup(){
  const db=dbFixture(),installation=createStableInstallation({db,registrationKey:'A'.repeat(40)}),ledger=createLedger({db,deviceKey:Buffer.alloc(32,7)});
  const baseRouter=createInternalRouter({installation,productionReady:false,billing:{admissionPolicy:'paid-only',reserveRun:async(owner,runId,taskBinding)=>({owner,runId,taskBinding,source:'paid'})},verifyTaskBinding:async()=>true});
  const api=createFreeApi({baseRouter,installation,ledger,verifyTaskBinding:async(_owner,_id,b)=>b===binding});
  const register=async()=>{const x=await installation.register({requestId:random(),verifier:random()});assert.equal(x.recoverySupported,false);return x};
  const call=async(token,path,body)=>{const e={httpMethod:'POST',path,headers:{'content-type':'application/json',...(token?{authorization:'Bearer '+token}:{})},body:JSON.stringify(body)};const r=await api(e);return {status:r.statusCode,body:JSON.parse(r.body)};};
  return {register,call,api};
}
test('free receipts expose verified owner and binding and use consistent native statuses',async()=>{
 const x=await setup(),user=await x.register(),body={deviceDigest:digest,runId:'receipt',taskBinding:binding};
 await x.call(user.accessToken,'/api/billing/free/migrate',{deviceDigest:digest,legacyEntries:{}});
 const expected={ownerId:user.installationId,runId:'receipt',taskBinding:binding,source:'free'};
 for(const [action,status] of [['reserve','reserved'],['confirm','confirmed'],['resume','authorized']]){
  const result=await x.call(user.accessToken,'/api/billing/free/'+action,body);assert.equal(result.status,200);assert.deepEqual(result.body,{...expected,status});
 }
});
test('cancel before delayed reserve is an immutable tombstone and consumes no free slot',async()=>{
 const x=await setup(),user=await x.register(),body={deviceDigest:digest,runId:'late',taskBinding:binding};
 await x.call(user.accessToken,'/api/billing/free/migrate',{deviceDigest:digest,legacyEntries:{}});
 const first=await x.call(user.accessToken,'/api/billing/free/cancel',body),again=await x.call(user.accessToken,'/api/billing/free/cancel',body);
 assert.equal(first.status,200);assert.equal(first.body.status,'cancelled');assert.deepEqual(first.body,again.body);
 assert.equal((await x.call(user.accessToken,'/api/billing/free/reserve',body)).status,503);
 assert.equal((await x.call(user.accessToken,'/api/billing/free/status',{deviceDigest:digest})).body.remaining,3);
});
test('cancel after reserve releases its slot and cannot cancel a confirmed run',async()=>{
 const x=await setup(),user=await x.register(),body={deviceDigest:digest,runId:'r',taskBinding:binding};
 await x.call(user.accessToken,'/api/billing/free/migrate',{deviceDigest:digest,legacyEntries:{}});
 assert.equal((await x.call(user.accessToken,'/api/billing/free/reserve',body)).status,200);
 assert.equal((await x.call(user.accessToken,'/api/billing/free/cancel',body)).body.status,'cancelled');
 assert.equal((await x.call(user.accessToken,'/api/billing/free/status',{deviceDigest:digest})).body.remaining,3);
 const paid={...body,runId:'confirmed'};await x.call(user.accessToken,'/api/billing/free/reserve',paid);await x.call(user.accessToken,'/api/billing/free/confirm',paid);
 assert.equal((await x.call(user.accessToken,'/api/billing/free/cancel',paid)).status,503);
 assert.equal((await x.call(user.accessToken,'/api/billing/free/status',{deviceDigest:digest})).body.remaining,2);
});
test('after upgrade and same-device reinstall, new installation retains free count',async()=>{
  const x=await setup(),old=await x.register(),fresh=await x.register();
  assert.notEqual(old.installationId,fresh.installationId);
  const migrated=await x.call(old.accessToken,'/api/billing/free/migrate',{deviceDigest:digest,legacyEntries:{a:'used',b:'used',c:'reserved'}});
  assert.equal(migrated.status,200);assert.equal(migrated.body.remaining,0);
  const reinstalled=await x.call(fresh.accessToken,'/api/billing/free/migrate',{deviceDigest:digest,legacyEntries:{}});
  assert.equal(reinstalled.status,200);assert.equal(reinstalled.body.remaining,0);
  assert.equal((await x.call(fresh.accessToken,'/api/billing/free/reserve',{deviceDigest:digest,runId:'new',taskBinding:binding})).status,503);
});
test('reinstall preserves exactly one remaining free run after two prior uses',async()=>{
  const x=await setup(),old=await x.register(),fresh=await x.register();
  assert.equal((await x.call(old.accessToken,'/api/billing/free/migrate',{deviceDigest:digest,legacyEntries:{a:'used',b:'used'}})).body.remaining,1);
  assert.equal((await x.call(fresh.accessToken,'/api/billing/free/migrate',{deviceDigest:digest,legacyEntries:{}})).body.remaining,1);
  assert.equal((await x.call(fresh.accessToken,'/api/billing/free/reserve',{deviceDigest:digest,runId:'third',taskBinding:binding})).status,200);
  assert.equal((await x.call(fresh.accessToken,'/api/billing/free/confirm',{deviceDigest:digest,runId:'third',taskBinding:binding})).status,200);
  assert.equal((await x.call(fresh.accessToken,'/api/billing/free/reserve',{deviceDigest:digest,runId:'fourth',taskBinding:binding})).status,503);
});
test('free API requires independent authenticated installation, and run belongs to its installing identity',async()=>{
  const x=await setup(),a=await x.register(),b=await x.register();
  assert.equal((await x.call(null,'/api/billing/free/migrate',{deviceDigest:digest,legacyEntries:{}})).status,503);
  assert.equal((await x.call(a.accessToken,'/api/billing/free/migrate',{deviceDigest:digest,legacyEntries:{}})).status,200);
  assert.equal((await x.call(a.accessToken,'/api/billing/free/reserve',{deviceDigest:digest,runId:'run',taskBinding:binding})).status,200);
  assert.equal((await x.call(b.accessToken,'/api/billing/free/confirm',{deviceDigest:digest,runId:'run',taskBinding:binding})).status,503);
  assert.equal((await x.call(a.accessToken,'/api/billing/free/confirm',{deviceDigest:digest,runId:'run',taskBinding:different})).status,503);
  assert.equal((await x.call(a.accessToken,'/api/billing/free/confirm',{deviceDigest:digest,runId:'run',taskBinding:binding})).status,200);
});
test('existing paid-only route contract remains paid-only and unchanged',async()=>{
  const x=await setup(),i=await x.register();
  const result=await x.call(i.accessToken,'/api/billing/runs/reserve',{runId:'paid',taskBinding:binding});
  assert.equal(result.status,200);assert.equal(result.body.source,'paid');assert.equal(result.body.owner,i.installationId);
});
test('different installation credentials share a single device quota under concurrency',async()=>{
  const x=await setup(),a=await x.register(),b=await x.register();
  await x.call(a.accessToken,'/api/billing/free/migrate',{deviceDigest:digest,legacyEntries:{}});
  const out=await Promise.all(['r1','r2','r3','r4','r5'].map((runId,i)=>x.call(i%2?a.accessToken:b.accessToken,'/api/billing/free/reserve',{deviceDigest:digest,runId,taskBinding:binding})));
  assert.equal(out.filter(x=>x.status===200).length,3);
});
test('ambiguous duplicate JSON or headers are rejected without changing the ledger',async()=>{
  const x=await setup(),i=await x.register();
  const headers={'content-type':'application/json',authorization:'Bearer '+i.accessToken};
  const base={httpMethod:'POST',path:'/api/billing/free/migrate',headers,body:`{"deviceDigest":"${digest}","deviceDigest":"${digest}","legacyEntries":{}}`};
  assert.equal((await x.api(base)).statusCode,503);
  const duplicate={...base,body:JSON.stringify({deviceDigest:digest,legacyEntries:{}}),headers:{...headers,Authorization:headers.authorization}};
  assert.equal((await x.api(duplicate)).statusCode,503);
  assert.equal((await x.call(i.accessToken,'/api/billing/free/status',{deviceDigest:digest})).status,503);
});

