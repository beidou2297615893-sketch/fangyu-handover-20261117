'use strict';
const {update,codeHash}=require('../payment-probe-init/update-code.cjs');void update;void codeHash;
const FN='dailyHundredPaymentProbeV1',ENV='fh6-d5ga45c0ddae7008c',REGION='ap-shanghai',ORIGINAL='22f1d70988a09c3fcdbd675ceec80ce278c60e14b87810b63fa0a8e75103f09e';
const NAMES=['daily_hundred_payment_v1','daily_hundred_installation_v1'],check=x=>{if(!x)throw Error('unavailable')},json=JSON.stringify;
function oldFunctions(list){check(Array.isArray(list)&&list.length<100);return list.filter(x=>x.name!==FN).map(x=>({functionId:x.functionId,name:x.name,runtime:x.runtime,modifyTime:x.modifyTime,status:x.status})).sort((a,b)=>String(a.name).localeCompare(String(b.name)));}
function sortedRoutes(list){check(Array.isArray(list)&&list.length<100);return list.map(x=>({domain:x.domain,path:x.path,upstreamResourceName:x.upstreamResourceName,upstreamResourceType:x.upstreamResourceType,enable:x.enable,enableAuth:x.enableAuth,enablePathTransmission:x.enablePathTransmission})).sort((a,b)=>json(a).localeCompare(json(b)));}
async function run(adapter){
 check(adapter&&['call','mark','updateCode','getCodeHash','delay'].every(k=>typeof adapter[k]==='function')&&/^[a-f0-9]{64}$/.test(adapter.packageHash));
 const call=async(...args)=>{const r=await adapter.call(args);check(r!==null&&r!==undefined);return r};
 const functions=()=>call('fn','list','-e',ENV,'--limit','100'),routes=()=>call('routes','list','-e',ENV,'--limit','100');
 const detail=()=>call('api','scf','GetFunction','-r',REGION,'--api-version','2018-04-16','--body',json({FunctionName:FN,Namespace:ENV}));
 const triggers=()=>call('api','scf','ListTriggers','-r',REGION,'--api-version','2018-04-16','--body',json({FunctionName:FN,Namespace:ENV,Limit:30,Offset:0}));
 function verifyDetail(d){check(d.FunctionName===FN&&d.Namespace===ENV&&d.Type==='Event'&&d.Runtime==='Nodejs20.19'&&d.Handler==='isolated-probe.main'&&d.Role==='TCB_QcsRole'&&d.Environment&&(!d.Environment.Variables||Array.isArray(d.Environment.Variables)&&d.Environment.Variables.length===0));}
 async function verifyOriginal(){const d=await detail();verifyDetail(d);check(d.Status==='Active'&&await adapter.getCodeHash()===ORIGINAL);}
 async function verifyNoTrigger(){check((await triggers()).TotalCount===0);}
 async function invoke(action,key){const r=await call('fn','invoke',FN,'-e',ENV,'-d',json({action}));check(r.functionType==='Event'&&r.InvokeResult===0&&typeof r.RetMsg==='string');let v;try{v=JSON.parse(r.RetMsg)}catch{check(false)};
  if(action==='verify-transaction'&&v.verified===false&&v.paymentEnabled===false&&typeof v.testId==='string'&&/^acl-test-[a-f0-9]{32}$/.test(v.testId))throw Object.assign(Error('unavailable'),{testId:v.testId});
  check(v[key]===true&&v.paymentEnabled===false&&Object.keys(v).sort().join(',')===[key,'paymentEnabled'].sort().join(','));}
 const beforeF=await functions(),beforeR=await routes(),p=beforeF.filter(x=>x.name===FN);check(p.length===1&&typeof p[0].functionId==='string'&&p[0].functionId&&!beforeR.some(x=>x.upstreamResourceName===FN));
 const id=p[0].functionId,oldF=json(oldFunctions(beforeF)),oldR=json(sortedRoutes(beforeR));
 await verifyOriginal();await verifyNoTrigger();
 for(const name of NAMES){const p=await call('permission','get','collection:'+name,'-e',ENV);check(Array.isArray(p.PermissionList));const m=p.PermissionList.filter(x=>x.Resource===name);check(m.length===1&&m[0].Permission==='ADMINONLY');}
 await invoke('verify-disabled-policy','initialized');
 // No change to any collection or function until the one-use marker exists.
 await adapter.mark();await verifyOriginal();await verifyNoTrigger();const updated=await adapter.updateCode();check(typeof updated?.RequestId==='string'&&updated.RequestId.length>0);
 let ready=false;for(let i=0;i<8;i++){const d=await detail();verifyDetail(d);check(['Active','Updating'].includes(d.Status));if(d.Status==='Active'){const h=await adapter.getCodeHash();if(h===adapter.packageHash){ready=true;break;}check(h===ORIGINAL);}if(i<7)await adapter.delay(1500);}check(ready);await verifyNoTrigger();
 const postF=await functions(),postR=await routes();check(postF.filter(x=>x.name===FN&&x.functionId===id).length===1&&json(oldFunctions(postF))===oldF&&json(sortedRoutes(postR))===oldR);
 await invoke('verify-transaction','verified');await invoke('verify-disabled-policy','initialized');
 const endF=await functions(),endR=await routes();check(endF.filter(x=>x.name===FN&&x.functionId===id).length===1&&json(oldFunctions(endF))===oldF&&json(sortedRoutes(endR))===oldR);
 return {verified:true,paymentEnabled:false,otherFunctionAndRouteMetadataUnchanged:true};
}
module.exports={run};
