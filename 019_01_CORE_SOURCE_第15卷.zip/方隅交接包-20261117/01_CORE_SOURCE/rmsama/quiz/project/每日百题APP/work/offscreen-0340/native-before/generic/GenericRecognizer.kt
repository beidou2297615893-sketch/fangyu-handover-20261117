package expo.modules.automationbridge.generic

import expo.modules.automationbridge.bank.*
import expo.modules.automationbridge.screen.*

data class GenericOption(val text:String,val node:ScreenNode)
sealed class GenericObservation {
  data class Question(val question:CanonicalQuestion,val options:List<GenericOption>,val submit:ScreenNode?,val ordinal:Int?,val total:Int?,val fingerprint:String):GenericObservation()
  data class Complete(val score:Int?=null):GenericObservation()
  data class Entry(val target:ScreenNode):GenericObservation()
  data class Feedback(val next:ScreenNode):GenericObservation()
  data class Unknown(val reason:String,val mayNeedOcr:Boolean=true,val ordinal:Int?=null,val total:Int?=null):GenericObservation()
  object Sensitive:GenericObservation()
}

/** Local answer-bank anchoring; no app names, IDs, coordinates or prepared software profiles. */
class GenericRecognizer(questions:List<CanonicalQuestion>,private val appHeadings:Set<String> = emptySet()) {
  private val entries=questions.map { it to compact(it.stem) }.filter { it.second.isNotEmpty() }
  private data class OptionRow(val row:ScreenNode,val choice:ScreenNode,val label:ScreenNode)
  private data class OpticalChoice(val node:ScreenNode,val line:ScreenNode,val ordinal:String,val text:String,val inGutter:Boolean) {
    val height get()=line.bounds.bottom-line.bounds.top
  }
  companion object {
    fun compact(s:String):String {
      val roman=ScriptFold.normalize(s).replace(Regex("[\u2160-\u217f]")) {
        java.text.Normalizer.normalize(it.value,java.text.Normalizer.Form.NFKC).uppercase()
      }
      val value=QuestionMatcher.normalize(roman)
      fun wordChar(c:Char)=c.isLetterOrDigit() && Character.UnicodeScript.of(c.code)!=Character.UnicodeScript.HAN
      return buildString { value.forEachIndexed { i,c ->
        if(!c.isWhitespace()) append(c)
        else if(i>0 && i+1<value.length && wordChar(value[i-1]) && wordChar(value[i+1])) append(' ')
      } }
    }
    fun optionText(s:String)=compact(s.replace(Regex("^\\s*[A-Ta-t][.、．:：)）]+\\s*"),""))
    private fun sameNativeLabel(native:String,ocr:String):Boolean {
      val a=optionText(native);val b=optionText(ocr)
      if(a==b)return true
      // A labeled native acronym is authoritative over a single optical O/0 or I/l
      // confusion in the same rectangle. Never erase added words or numeric answers.
      if(!Regex("^[A-Z]{3,}$").matches(a) || a.length!=b.length)return false
      val changed=a.indices.filter { a[it]!=b[it] }
      return changed.size==1 && changed.single().let { i -> (a[i]=='O' && b[i]=='0') || (a[i]=='I' && b[i] in setOf('1','l')) }
    }
    private fun controlText(s:String)=compact(s).replace(Regex("\\s+"),"").lowercase()
    private fun cleanStem(s:String):String {
      var value=compact(s)
      repeat(3) { value=value.replace(Regex("^(?:[【\\[(（]?(?:单选题|多选题|判断题|单选|多选|判断)[】\\])）:：]*|第\\d+题[:：、.]?|\\d+[、．)）])"),"") }
      return value
    }
    private fun decorative(s:String):Boolean {
      val v=compact(s)
      return v in setOf("单选题","多选题","判断题","单选","多选","判断","请选择正确答案","请选择一个选项","请选择所有正确答案") || Regex("^请选择所有正确选项[，,]再确认答案[。.]?$").matches(v) || Regex("^题型[:：]?(?:单选|多选|判断)(?:题)?$").matches(v) ||
        Regex("^(?:(?:题目进度|答题进度|进度)[:：]?)?\\d+[/／]\\d+$|^第\\d+题[/／]?共\\d+题$").matches(v)
    }
    private val submitLabels=setOf("提交","提交本题","提交答案","确认答案","确认提交","提交并继续","下一题","submit","submitanswer","next")
    private val entryLabels=setOf("开始答题","开始作答","进入答题","开始练习","开始测试","start","startquiz","beginquiz")
    private val finishLabels=setOf("答题已完成","答题完成","作答完成","练习已完成","练习完成","考试已完成","测试已完成","quizcompleted","quizcomplete","allquestionscompleted")
    private val opticalOrdinal=Regex("^\\s*([OC])?\\s*([A-Ta-t])([.、．:：)）]+)\\s*(\\S.*)$")
    private val visualOptionLabel=Regex("^\\s*[O0○]?\\s*([A-T])[.、．,，]\\s*(\\S.*)$")
    private val visualLabelWithIndicator=Regex("^\\s*(?:[O0○1IlL|)–-]\\s*)?([A-Ta-tpP])[.、．,，]?\\s*(\\S.*)$")
    private fun latinReading(region:OcrRegion,allowLigature:Boolean=true,allowCodeRepair:Boolean=true):String {
      var text=region.text
      val h=region.bounds.bottom-region.bounds.top
      val tokens=region.visualLatinTokens.filter { token ->
        token.bounds.valid && token.bounds.top<region.bounds.bottom && token.bounds.bottom>region.bounds.top &&
          token.bounds.left<region.bounds.right+h && token.bounds.right>region.bounds.left
      }.take(64)
      fun latinGlyphs(value:String)=value.map { c -> when(c) {
        '0' -> 'O'; '1','l','|' -> 'I'; else -> c.uppercaseChar()
      } }.joinToString("")
      if(allowLigature) {
        val letters=Regex("(?<![A-Za-z0-9])[A-Za-z]{2,12}(?![A-Za-z0-9])")
        fun vShape(value:String)=value.uppercase().replace(Regex("[VW]+"),"V")
        for(match in letters.findAll(text).toList().asReversed()) {
          val value=match.value
          if(value.none { it in "Ww" } || value.any { !it.isUpperCase() && it!='w' }) continue
          val independent=tokens.filter { token ->
            val b=token.bounds
            val overlap=minOf(region.bounds.bottom,b.bottom)-maxOf(region.bounds.top,b.top)
            overlap*2>=minOf(h,b.bottom-b.top) &&
              kotlin.math.abs(b.top+b.bottom-region.bounds.top-region.bounds.bottom)<=maxOf(h,b.bottom-b.top)
          }.flatMap { token -> letters.findAll(token.text.take(128)).map { it.value.uppercase() }.toList() }
            .filter { vShape(it)==vShape(value) }.distinct().singleOrNull()
          if(independent!=null) text=text.replaceRange(match.range,independent)
        }
      }
      val acronym=Regex("[A-Za-z01][A-Za-z0-9]{1,11}")
      for(match in acronym.findAll(text).toList().asReversed()) {
        val value=match.value
        if(value.count(Char::isLetter)<2 || value.none { it in "01l" }) continue
        // Keep numeric code tails and their separators intact. The verified 0CC/OCC
        // recovery is a standalone leading optical glyph followed entirely by letters.
        if(value.any(Char::isDigit) && !Regex("[01][A-Za-z]+").matches(value)) continue
        if(listOfNotNull(text.getOrNull(match.range.first-1),text.getOrNull(match.range.last+1))
            .any { it in ".:/+-_*%=<>\\^|" }) continue
        val observed=tokens.flatMap { token ->
          Regex("[A-Za-z0-9|]+").findAll(token.text.take(128)).flatMap { word ->
            word.value.windowed(value.length)
          }.filter { fragment -> latinGlyphs(fragment)==latinGlyphs(value) &&
            value.indices.any { index -> value[index] in "01l" && fragment[index].isLetter() } }.toList()
        }.map { it.uppercase() }.distinct().singleOrNull()
        if(observed!=null) text=text.replaceRange(match.range,observed)
      }
      if(allowCodeRepair) {
        val code=Regex("[A-Za-z][A-Za-z0-9]*(?:[./:+-][A-Za-z0-9]+)*")
        fun boundary(c:Char?)=c!=null && (c.code<128 && c.isLetterOrDigit() || c in "._/:+-")
        // Only a dot directly after the letter prefix is layout formatting (F.13/F13).
        // Every numeric separator, sign, suffix and digit after that remains authoritative.
        fun numericTail(tail:String)=if(tail.startsWith('.') && tail.getOrNull(1)?.isDigit()==true) tail.drop(1) else tail
        val matches=code.findAll(text).filter { m -> m.value.any(Char::isDigit) &&
          !boundary(text.getOrNull(m.range.first-1)) && !boundary(text.getOrNull(m.range.last+1)) }.toList()
        for(match in matches.asReversed()) {
          val prefix=match.value.takeWhile(Char::isLetter);val tail=match.value.drop(prefix.length)
          if(matches.count { other -> numericTail(other.value.dropWhile(Char::isLetter))==numericTail(tail) }!=1) continue
          val replacements=tokens.mapNotNull { token ->
            val value=token.text.trim()
            if(!code.matches(value) || value.none(Char::isDigit)) return@mapNotNull null
            val observedPrefix=value.takeWhile(Char::isLetter)
            if(observedPrefix.length<prefix.length || numericTail(value.drop(observedPrefix.length))!=numericTail(tail)) return@mapNotNull null
            val observed=observedPrefix.takeLast(prefix.length)
            val changes=prefix.indices.filter { prefix[it]!=observed[it] }
            if(changes.size>1 || changes.any { i ->
                prefix[i].isUpperCase()!=observed[i].isUpperCase() || setOf(prefix[i].uppercaseChar(),observed[i].uppercaseChar())!=setOf('E','F')
              }) return@mapNotNull null
            observed+tail
          }.distinct().singleOrNull()
          if(replacements!=null) text=text.replaceRange(match.range,replacements)
        }
      }
      // Chinese OCR can turn III into 三 or |. Only use a Latin token at
      // the actual right-hand suffix, keeping the Chinese prefix untouched.
      val suffix=Regex("^(.+[,，])\\s*[IVXivxIlL1|!三二一=ー–-]+\\s*$").matchEntire(text)
      if(suffix!=null) {
        val roman=region.visualRomanSuffix ?: tokens.mapNotNull { token ->
          val value=token.text.trim().replace('l','I').replace('i','I').replace('|','I').uppercase()
          value.takeIf { Regex("[IVX]{1,8}").matches(it) &&
            token.bounds.left>=region.bounds.left+h &&
            kotlin.math.abs(token.bounds.right-region.bounds.right)<=h }
        }.distinct().singleOrNull()
        if(roman!=null) text=suffix.groupValues[1]+roman
      }
      return text
    }
    private val ocrCritical="不非无未有否可应需禁必许得前后左右上下内外出入进退升降开关大小最全任仅超至少正负零一二三四五六七八九十百千万亿两〇壹贰叁肆伍陆柒捌玖拾佰仟萬億"
    private fun ocrWords(s:String)=buildString {
      s.forEachIndexed { i,c ->
        val numberMark=(c in ".-/:+" && s.getOrNull(i-1)?.isDigit()==true && s.getOrNull(i+1)?.isDigit()==true) ||
          (c in "+-" && s.getOrNull(i+1)?.isDigit()==true)
        if(c.isLetterOrDigit() || numberMark) append(c)
      }
    }
    private fun sameKnownVisualGlyph(expected:String,observed:String):Boolean {
      if(expected.length!=observed.length || expected==observed) return false
      var changes=0
      for(i in expected.indices) if(expected[i]!=observed[i]) {
        val alternatives=when(expected[i]) {
          '一' -> "-ー—–"
          '二' -> "="
          '弓' -> if(expected.length>1) "引" else ""
          else -> ""
        }
        if(observed[i] !in alternatives || ++changes>2) return false
      }
      return changes>0
    }
    private fun boundedHanOcrError(expected:String,observed:String,budgetDivisor:Int=20):Boolean =
      hanOcrDistance(expected,observed,budgetDivisor)!=null
    private fun hanOcrDistance(expected:String,observed:String,budgetDivisor:Int=20):Int? {
      val a=ocrWords(expected);val b=ocrWords(observed)
      val limit=minOf(4,maxOf(1,a.length/budgetDivisor))
      if(minOf(a.length,b.length)<10 || kotlin.math.abs(a.length-b.length)>limit) return null
      val protected=ocrCritical
      fun han(c:Char)=Character.UnicodeScript.of(c.code)==Character.UnicodeScript.HAN
      fun key(s:String)=s.filter { !han(it) || it in protected }
      if(key(a)!=key(b)) return null
      fun editable(c:Char)=han(c) && c !in protected
      val tooFar=limit+1
      var previous=IntArray(b.length+1) { i -> if(b.take(i).all(::editable)) minOf(i,tooFar) else tooFar }
      for(i in 1..a.length) {
        val current=IntArray(b.length+1) { tooFar }
        current[0]=if(editable(a[i-1])) minOf(tooFar,previous[0]+1) else tooFar
        for(j in maxOf(1,i-limit)..minOf(b.length,i+limit)) {
          val replacement=when {
            a[i-1]==b[j-1] -> previous[j-1]
            editable(a[i-1]) && editable(b[j-1]) -> previous[j-1]+1
            else -> tooFar
          }
          current[j]=minOf(replacement,
            if(editable(a[i-1])) previous[j]+1 else tooFar,
            if(editable(b[j-1])) current[j-1]+1 else tooFar,tooFar)
        }
        previous=current
      }
      return previous[b.length].takeIf { it<=limit }
    }
    private fun hanOcrRowsDistance(expected:String,parts:List<Set<String>>,budgetDivisor:Int=20):Int? {
      val a=ocrWords(expected)
      if(a.length !in 10..2000 || parts.isEmpty() || parts.size>80) return null
      val limit=minOf(4,maxOf(1,a.length/budgetDivisor));val far=limit+1
      val protected=ocrCritical
      fun editable(c:Char)=Character.UnicodeScript.of(c.code)==Character.UnicodeScript.HAN && c !in protected
      var previous=IntArray(a.length+1) { far }.also { it[0]=0 }
      for(j in 1..a.length) if(editable(a[j-1])) previous[j]=minOf(far,previous[j-1]+1)
      for(part in parts) {
        val choices=part.take(24).map(::ocrWords).distinct()
        if(choices.isEmpty() || choices.any { it.length>2000 }) return null
        val best=IntArray(a.length+1) { far }
        for(text in choices) {
          var state=previous.copyOf()
          for(c in text) {
            val next=IntArray(a.length+1) { far }
            next[0]=if(editable(c)) minOf(far,state[0]+1) else far
            for(j in 1..a.length) {
              val replace=when {
                a[j-1]==c -> state[j-1]
                editable(a[j-1]) && editable(c) -> state[j-1]+1
                else -> far
              }
              next[j]=minOf(far,replace,
                if(editable(a[j-1])) next[j-1]+1 else far,
                if(editable(c)) state[j]+1 else far)
            }
            state=next
          }
          for(j in best.indices) best[j]=minOf(best[j],state[j])
        }
        previous=best
      }
      return previous[a.length].takeIf { it<=limit }
    }
  }
  private fun labels(node:ScreenNode)=listOf(node.text,node.description).filter { it.isNotBlank() }
  private fun choiceIdentity(node:ScreenNode)=listOf(node.resourceId,ScreenFingerprint.normalize(node.text),
    ScreenFingerprint.normalize(node.description),node.role)
  private fun intersects(a:Bounds,b:Bounds)=a.top<b.bottom && a.bottom>b.top && a.left<b.right && a.right>b.left

  private data class VisualMatch(val question:GenericObservation.Question?,val hint:String?,val clearedOptions:Boolean=false)
  private data class NearVisualMatch(val question:CanonicalQuestion,val matched:List<String>,val distance:Int,val exactOptions:Boolean)

  private fun visualAnswer(page:PageSnapshot,nodes:List<ScreenNode>,progress:Pair<Int,Int>,declaredType:String?):VisualMatch? {
    val lines=nodes.filter { it.ref.startsWith("ocr:") }.sortedBy { it.bounds.top }
    val progressLine=lines.singleOrNull { compact(it.text).matches(Regex("\\d+/\\d+")) } ?: return null
    val submitLine=lines.singleOrNull { controlText(it.text.trimStart('|','｜')) in submitLabels } ?: return null
    val content=lines.filter { it.bounds.top>=progressLine.bounds.bottom && it.bounds.bottom<=submitLine.bounds.top &&
      !decorative(it.text) }
    fun label(row:ScreenNode)=visualOptionLabel.matchEntire(row.text)
      ?: visualLabelWithIndicator.matchEntire(row.text)?.takeIf { row.checkable }
    val start=content.indexOfFirst { label(it)!=null }
    if(start<=0) return null
    val rows=content.drop(start)
    if(rows.size !in 2..20 || rows.zipWithNext().any { (a,b) -> a.bounds.bottom>b.bounds.top }) return null
    val options=rows.mapIndexed { index,row ->
      val match=label(row) ?: return null
      val letter=match.groupValues[1].single().uppercaseChar()
      if(letter!='A'+index && !(index==3 && letter=='P' && row.checkable)) return null
      compact(match.groupValues[2])
    }
    // Raw OCR may collapse different grades (I/II/III) into the same glyph.
    // Resolve their independent pixel/Latin evidence before enforcing the
    // complete one-to-one bank option match below.
    val clearedOptions=page.visualFrame!=null && rows.all { it.checkable && !it.checked }
    fun unresolved(hint:String?=null)=VisualMatch(null,hint,clearedOptions)
    fun quotes(text:String)=text.replace('“','"').replace('”','"')
    val readStem=quotes(compact(content.take(start).joinToString("") { it.text }))
    val stems=mutableSetOf(readStem)
    val stemRows=content.take(start).map { node ->
      mutableListOf(page.ocrRegions.single { it.ref==node.ref })
    }
    val optionReadings=options.map { mutableSetOf(it) }
    val pixelReadings=options.map { mutableSetOf<String>() }
    fun stemWithRawPrefix(text:String,original:String?):String {
      val masked=quotes(compact(text))
      val raw=original?.let { quotes(compact(it)) } ?: return masked
      if(raw.length>=masked.length || raw.length<6 || raw.take(2)!=masked.take(2)) return masked
      // OCR sometimes splits the raw line at a blank. The shared tail of the
      // prefix anchors it to the masked line before appending the remaining text.
      val tail=raw.takeLast(4)
      val endpoint=masked.indexOf(tail)+tail.length
      if(endpoint<tail.length || endpoint>=masked.length ||
        masked.indexOf(tail)!=masked.lastIndexOf(tail) || kotlin.math.abs(endpoint-raw.length)>1) return masked
      return raw+masked.substring(endpoint)
    }
    fun addOptionReading(index:Int,text:String,pixel:Boolean=false) {
      val parsed=visualOptionLabel.matchEntire(text) ?: visualLabelWithIndicator.matchEntire(text)
      val letter=parsed?.groupValues?.get(1)?.single()?.uppercaseChar()
      if(parsed!=null && (letter=='A'+index || index==3 && letter=='P'))
        (if(pixel) pixelReadings[index] else optionReadings[index]).add(compact(parsed.groupValues[2]))
    }
    if(page.visualFrame!=null) rows.forEachIndexed { index,row ->
      page.ocrRegions.singleOrNull { it.ref==row.ref }?.let { region ->
        region.visualOriginalText?.let { addOptionReading(index,it) }
        addOptionReading(index,latinReading(region),region.visualRomanSuffix!=null)
      }
    }
    if(page.visualFrame!=null) stems.add(content.take(start).joinToString("") { line ->
      stemWithRawPrefix(line.text,page.ocrRegions.singleOrNull { it.ref==line.ref }?.visualOriginalText)
    })
    if(page.visualFrame!=null) stems.add(content.take(start).joinToString("") { line ->
      val region=page.ocrRegions.singleOrNull { it.ref==line.ref }
      if(region==null) quotes(compact(line.text)) else quotes(compact(latinReading(region)))
    })
    for(alternate in page.visualAlternates.takeIf { page.visualFrame!=null }.orEmpty()) {
      if(alternate.any { it.frameId!=page.frameId || it.windowId!=page.windowId }) continue
      val previous=alternate.sortedBy { it.bounds.top }
        .filter { it.bounds.top>=progressLine.bounds.bottom && it.bounds.bottom<=submitLine.bounds.top && !decorative(it.text) }
      val split=previous.indexOfFirst { it.bounds.top+it.bounds.bottom >=
        rows.first().bounds.top+rows.first().bounds.bottom-(rows.first().bounds.bottom-rows.first().bounds.top) }
      if(split<=0 || previous.size-split!=rows.size) continue
      val otherRows=previous.drop(split)
      if(rows.zip(otherRows).any { (row,other) ->
          kotlin.math.abs(row.bounds.top+row.bounds.bottom-other.bounds.top-other.bounds.bottom)>row.bounds.bottom-row.bounds.top
        }) continue
      val previousStem=previous.take(split)
      if(previousStem.size==stemRows.size && previousStem.zip(stemRows).all { (line,group) ->
          val anchor=group.first().bounds
          kotlin.math.abs(line.bounds.top+line.bounds.bottom-anchor.top-anchor.bottom)<=
            maxOf(line.bounds.bottom-line.bounds.top,anchor.bottom-anchor.top)
        }) previousStem.forEachIndexed { index,line -> stemRows[index].add(line) }
      stems.add(quotes(compact(previous.take(split).joinToString("") { it.text })))
      stems.add(previous.take(split).joinToString("") { stemWithRawPrefix(it.text,it.visualOriginalText) })
      stems.add(previous.take(split).joinToString("") { quotes(compact(latinReading(it))) })
      otherRows.forEachIndexed { index,region ->
        addOptionReading(index,region.text)
        addOptionReading(index,latinReading(region),region.visualRomanSuffix!=null)
        region.visualOriginalText?.let { addOptionReading(index,it) }
      }
    }
    for(index in optionReadings.indices) if(pixelReadings[index].isNotEmpty()) {
      optionReadings[index].clear()
      optionReadings[index].addAll(pixelReadings[index])
    }
    val stemParts=stemRows.map { group ->
      val tokens=group.flatMap { it.visualLatinTokens }.distinct()
      fun samePhysicalRow(a:OcrRegion,b:OcrRegion):Boolean {
        if(a.frameId!=page.frameId || b.frameId!=page.frameId || a.windowId!=page.windowId || b.windowId!=page.windowId) return false
        val x=a.bounds;val y=b.bounds
        val ah=x.bottom-x.top;val bh=y.bottom-y.top;val h=maxOf(ah,bh)
        val overlap=minOf(x.bottom,y.bottom)-maxOf(x.top,y.top)
        return x.valid && y.valid && overlap*2>=minOf(ah,bh) &&
          kotlin.math.abs(x.top+x.bottom-y.top-y.bottom)<=minOf(ah,bh)/2 &&
          kotlin.math.abs(x.left-y.left)<=h/2 && kotlin.math.abs(x.right-y.right)<=h/2
      }
      buildSet {
        for(region in group) {
          add(stemWithRawPrefix(region.text,region.visualOriginalText))
          for(text in (listOf(region.text)+region.visualRoiReadings.take(4)).distinct()) {
            val reading=region.copy(text=text)
            add(quotes(compact(text)))
            add(quotes(compact(latinReading(reading))))
            // A whole agreeing peer group can supply the same physical code to another
            // Chinese reading. Never cherry-pick one token out of a conflicting group.
            for(peer in group) if(samePhysicalRow(region,peer))
              add(quotes(compact(latinReading(reading.copy(visualLatinTokens=peer.visualLatinTokens)))))
          }
          for(token in tokens) {
            add(quotes(compact(latinReading(region.copy(visualLatinTokens=listOf(token)),false,false))))
          }
        }
      }
    }
    fun labelsFor(question:CanonicalQuestion,observed:List<String> = options):String? {
      if(!QuestionMatcher.hasUniqueAnswerTargets(question,::compact)) return null
      return question.correctOptionIds.map { id ->
        val option=question.options.singleOrNull { it.id==id } ?: return null
        val index=observed.indexOf(compact(option.text))
        if(index<0) return null
        'A'+index
      }.sorted().takeIf { it.isNotEmpty() }?.joinToString("、")
    }
    val exact=entries.mapNotNull { (question,stem) ->
      if(declaredType!=null && question.type!=declaredType) return@mapNotNull null
      if(quotes(stem) !in stems || question.options.size!=rows.size) return@mapNotNull null
      val expected=question.options.map { compact(it.text) }
      var opticalCorrections=0
      var wordCorrections=0
      val matched=optionReadings.map { readings ->
        val direct=expected.filter { it in readings }
        if(direct.isNotEmpty()) direct.singleOrNull() ?: return@mapNotNull null
        else {
          // Repair only one known glyph per row. Other characters in the row
          // must agree, and at least two options must read exactly.
          if(++opticalCorrections>rows.size-2) return@mapNotNull null
          val known=expected.singleOrNull { option ->
            readings.any { sameKnownVisualGlyph(option,it) }
          }
          known ?: run {
            if(++wordCorrections>1) return@mapNotNull null
            expected.singleOrNull { option -> option.length>=10 &&
              readings.any { boundedHanOcrError(option,it) } } ?: return@mapNotNull null
          }
        }
      }
      (question to matched).takeIf { matched.sorted()==expected.sorted() &&
        (opticalCorrections==0 || rows.size>=4) }
    }
    if(exact.isNotEmpty()) {
      val (question,matched)=exact.singleOrNull() ?: return unresolved()
      if(declaredType!=null && question.type!=declaredType) return unresolved()
      val answer=labelsFor(question,matched) ?: return unresolved()
      val observation=if(page.visualFrame!=null && question.type in setOf("single","boolean") &&
        question.correctOptionIds.size==1 && rows.count { it.checked }<=1) {
        GenericObservation.Question(question,matched.zip(rows).map { (text,row) -> GenericOption(text,row) },
          submitLine,progress.first,progress.second,QuestionMatcher.key(question.type,question.stem,question.options.map { it.text }))
      } else null
      return VisualMatch(observation,"题库答案：$answer",clearedOptions)
    }
    // Keep the strict Han distance: a candidate merely inside the allowance must not
    // erase the distinction between a one-error reading and a three-error competitor.
    val near=entries.mapNotNull { (question,stem) ->
      if(declaredType!=null && question.type!=declaredType) return@mapNotNull null
      if(question.options.size!=rows.size) return@mapNotNull null
      val expected=question.options.map { compact(it.text) }
      var wordCorrections=0
      var shapeCorrections=0
      val matched=optionReadings.map { readings ->
        expected.singleOrNull { it in readings } ?: run {
          val known=expected.singleOrNull { option -> readings.any { sameKnownVisualGlyph(option,it) } }
          if(known!=null) {
            if(++shapeCorrections>rows.size-2) return@mapNotNull null
            known
          } else {
            if(++wordCorrections>1) return@mapNotNull null
            expected.singleOrNull { option -> option.length>=10 &&
              readings.any { boundedHanOcrError(option,it) } } ?: return@mapNotNull null
          }
        }
      }
      if(matched.sorted()!=expected.sorted()) return@mapNotNull null
      // Only four completely exact options strengthen the stem evidence. Repaired
      // options keep the existing allowance; critical Han, codes and digits stay exact.
      val stemBudgetDivisor=if(rows.size==4 && shapeCorrections==0 && wordCorrections==0) 15 else 20
      val distance=(stems.mapNotNull { hanOcrDistance(quotes(stem),it,stemBudgetDivisor) }+
        listOfNotNull(hanOcrRowsDistance(quotes(stem),stemParts,stemBudgetDivisor))).minOrNull() ?: return@mapNotNull null
      NearVisualMatch(question,matched,distance,rows.size==4 && shapeCorrections==0 && wordCorrections==0)
    }
    val recovered=near.singleOrNull() ?: near.takeIf { it.size>1 && it.all { candidate -> candidate.exactOptions } }
      ?.sortedBy { it.distance }?.let { sorted -> sorted.first().takeIf { sorted[1].distance-it.distance>=2 } }
      ?: return unresolved()
    val (question,matched)=recovered
    if(declaredType!=null && question.type!=declaredType) return unresolved()
    val answer=labelsFor(question,matched) ?: return unresolved()
    if(page.visualFrame!=null && question.type in setOf("single","boolean") &&
      question.correctOptionIds.size==1 && rows.count { it.checked }<=1) {
      return VisualMatch(GenericObservation.Question(question,matched.zip(rows).map { (text,row) -> GenericOption(text,row) },
        submitLine,progress.first,progress.second,QuestionMatcher.key(question.type,question.stem,question.options.map { it.text })),
        "题库答案：$answer",clearedOptions)
    }
    return unresolved("疑似题库答案：$answer，请核对题干")
  }

  private fun opticalChoices(choices:List<ScreenNode>,nodes:List<ScreenNode>,native:List<ScreenNode>):List<OpticalChoice> {
    if(choices.size !in 3..20 || choices.distinctBy(::choiceIdentity).size!=choices.size) return emptyList()
    if(choices.any { !it.clickable || !it.enabled || it.role.substringAfterLast('.') !in setOf("RadioButton","CheckBox") }) return emptyList()
    val ordered=choices.sortedBy { it.bounds.top }
    if(ordered.zipWithNext().any { (a,b) -> a.bounds.bottom>b.bounds.top }) return emptyList()
    val lines=nodes.filter { it.ref.startsWith("ocr:") }
    val rows=ordered.mapIndexed { index,choice ->
      val bounds=choice.bounds
      val line=lines.singleOrNull { intersects(it.bounds,bounds) } ?: return emptyList()
      if(!bounds.contains(line.bounds)) return emptyList()
      val parsed=opticalOrdinal.matchEntire(line.text) ?: return emptyList()
      val (prefix,ordinal,separator,text)=parsed.destructured
      if(ordinal.single().uppercaseChar()!='A'+index) return emptyList()
      OpticalChoice(choice,line,ordinal+separator,compact(text),prefix.isNotEmpty())
    }
    val plain=rows.filterNot { it.inGutter }
    if(plain.size<2 || plain.size==rows.size) return emptyList()
    val left=plain.minOf { it.line.bounds.left }
    val right=plain.maxOf { it.line.bounds.left }
    val lineHeight=plain.minOf { it.height }
    if(right-left>lineHeight) return emptyList()
    // In a uniformly lettered list, an extra glyph well to the left of the
    // normal letter column can be the radio circle. Keep the full label body.
    if(rows.filter { it.inGutter }.any {
      val gap=left-it.line.bounds.left
      gap !in maxOf(2,lineHeight/4)..(2*lineHeight) || it.line.bounds.right<=right
    }) return emptyList()
    // OCR cannot overrule existing native text or a native ordinal in the row.
    for(row in rows) {
      val localLabels=native.filter { node ->
        node.ref.startsWith(row.node.ref+".") || intersects(node.bounds,row.node.bounds)
      }.flatMap(::labels)
      if(localLabels.any { compact(it)!=row.text && optionText(it)!=row.text && compact(it)!=compact(row.ordinal) }) return emptyList()
    }
    return rows
  }
  fun recognize(page:PageSnapshot):GenericObservation {
    if(page.capabilityIssue!=null) return GenericObservation.Unknown(page.capabilityIssue,false)
    val native=page.nodes.filter { it.bounds.valid && it.enabled }
    val screenNodes=SelectorMatcher.allNodes(page).filter { it.bounds.valid && it.enabled }
    val all=screenNodes.filter { n ->
      // OCR fills missing text; a checkbox glyph or a misread letter must not invent
      // an extra option inside a control whose complete label is already available.
      !n.ref.startsWith("ocr:") || native.none { it.checkable && (it.text.isNotBlank() || it.description.isNotBlank()) && it.bounds.contains(n.bounds) && sameNativeLabel(it.text.ifBlank { it.description },n.text.ifBlank { n.description }) }
    }
    val texts=all.flatMap { listOf(it.text,it.description) }.filter(String::isNotBlank).distinct()
    if(texts.any { Regex("^(?:请输入|请填写|输入|填写).{0,8}(?:密码|验证码|身份证)|^(?:人脸识别|短信验证|sign.in|log.in)$|^(?:enter|input).{0,12}(?:password|verification.code)",RegexOption.IGNORE_CASE).containsMatchIn(it) } ||
      native.any { it.role.contains("EditText") } && texts.any { Regex("密码|验证码|登录|password|sign.in",RegexOption.IGNORE_CASE).containsMatchIn(it) }) return GenericObservation.Sensitive
    val content=texts.joinToString("\n");val compactContent=compact(content)
    val rawOptions=page.nodes.filter { it.checkable && it.bounds.valid }
    val firstChoiceTop=rawOptions.minOfOrNull { it.bounds.top } ?: page.height
    fun isProgress(t:String)=Regex("^(?:(?:题目进度|答题进度|进度)[:：]?)?\\d+[/／]\\d+$|^第\\d+题[/／]?共\\d+题$").matches(compact(t))
    val regionTop=all.filter { it.bounds.bottom<=firstChoiceTop && listOf(it.text,it.description).any(::isProgress) }
      .maxOfOrNull { it.bounds.bottom } ?: 0
    // Keep the whole pre-choice region authoritative, including separate qualifiers.
    fun inQuestionRegion(bounds:Bounds)=bounds.top>=regionTop && bounds.bottom<=firstChoiceTop
    fun stemText(t:String)=t.isNotBlank() && !decorative(t) && compact(t) !in appHeadings
    val blocks=native.filter { !it.checkable && !it.clickable && inQuestionRegion(it.bounds) &&
      listOf(it.text,it.description).any(::stemText) }
    val leaves=blocks.filter { node -> blocks.none { it.ref.startsWith(node.ref+".") } }
    val pieces=leaves.map { it.bounds to it.text.ifBlank { it.description } }.toMutableList()
    all.filter { n -> n.ref.startsWith("ocr:") && inQuestionRegion(n.bounds) && stemText(n.text) &&
      leaves.none { it.bounds.contains(n.bounds) } }.forEach { pieces.add(it.bounds to it.text) }
    val ordered=pieces.sortedWith(compareBy<Pair<Bounds,String>> { it.first.top }.thenBy { it.first.left })
    fun sameLine(before:Bounds,after:Bounds)=kotlin.math.abs(after.top-before.top)<
      minOf(before.bottom-before.top,after.bottom-after.top)/2
    val fullStem=cleanStem(buildString {
      ordered.forEachIndexed { index,(bounds,value) ->
        if(index>0) {
          val before=ordered[index-1].first
          val gap=bounds.left-before.right
          if(!sameLine(before,bounds) || gap>minOf(bounds.bottom-bounds.top,before.bottom-before.top)/10) append(' ')
        }
        append(value)
      }
    })
    val continuous=ordered.zipWithNext().all { (previous,next) ->
      val before=previous.first
      val after=next.first
      val gap=if(sameLine(before,after)) after.left-before.right else after.top-before.bottom
      gap<=maxOf(before.bottom-before.top,after.bottom-after.top)
    }
    val geometricCandidate=fullStem.takeIf { rawOptions.isNotEmpty() && continuous && it.isNotEmpty() }
    val candidateEntries=entries.filter { (_,stem) -> compactContent.contains(stem) || stem==geometricCandidate }
    // A separate completion sentence needs result context and no editable question.
    // Never infer completion from a branded heading or words inside a bank stem.
    val resultContext=texts.any { Regex("^(?:本次)?(?:得分|成绩|score)[:：]\\d+(?:分)?[。.!！]?$",RegexOption.IGNORE_CASE).matches(compact(it)) }
    val completionSentence=texts.any { Regex("^(?:本次|本轮)(?:共)?\\d{1,5}题(?:已)?全部完成[。.!！]?$").matches(compact(it)) }
    val exactComplete=texts.any { controlText(it) in finishLabels } ||
      (completionSentence && resultContext && candidateEntries.isEmpty() && native.none { it.checkable })
    val optionControls=all.filter { it.checkable || it.role.substringAfterLast('.') in setOf("CheckBox","RadioButton") }
    val typeBefore=minOf(firstChoiceTop,optionControls.minOfOrNull { it.bounds.top } ?: firstChoiceTop)
    val declaredTypes=all.filter { n -> !n.checkable && (!n.clickable || n.ref.startsWith("ocr:")) && n.bounds.bottom<=typeBefore && rawOptions.none { o -> n.ref==o.ref || n.ref.startsWith(o.ref+".") || n.ref.startsWith("ocr:") && o.bounds.contains(n.bounds) } }
      .flatMap { listOf(it.text,it.description) }.mapNotNull { text ->
        val label=Regex("^(?:题型[:：]?)?(单选|多选|判断)(?:题)?$").matchEntire(compact(text))?.groupValues?.get(1)
        when(label) { "单选" -> "single"; "多选" -> "multiple"; "判断" -> "boolean"; else -> null }
      }.distinct()
    if(declaredTypes.size>1) return GenericObservation.Unknown("页面题型无法唯一确认，未自动作答",false)
    val declaredType=declaredTypes.singleOrNull()
    if(declaredType!=null && candidateEntries.isNotEmpty() && candidateEntries.none { it.first.type==declaredType })
      return GenericObservation.Unknown("页面题型与题库不一致，未自动作答",false)
    val progressTexts=all.filter { n -> optionControls.none { o -> n.ref==o.ref || n.ref.startsWith(o.ref+".") || n.ref.startsWith("ocr:") && o.bounds.contains(n.bounds) } }.flatMap { listOf(it.text,it.description) }.filter(String::isNotBlank).distinct()
    val progress=progressTexts.mapNotNull { t ->
      val m=Regex("(?:题目进度|答题进度|进度)\\s*[:：]?\\s*(\\d+)\\s*[/／]\\s*(\\d+)|第\\s*(\\d+)\\s*题\\s*[/／]?\\s*共\\s*(\\d+)\\s*题|^\\s*(\\d+)\\s*[/／]\\s*(\\d+)\\s*$").find(t) ?: return@mapNotNull null
      val values=m.groupValues.drop(1).filter(String::isNotEmpty).mapNotNull(String::toIntOrNull)
      values.takeIf { it.size==2 && it[0] in 1..it[1] && it[1]<=50000 }?.let { it[0] to it[1] }
    }.distinct()
    if(progress.size>1) return GenericObservation.Unknown("当前页面有多个题目进度，请进入单题页面",false)
    val explicitProgress=progress.singleOrNull()?.takeIf { progressTexts.any { t -> Regex("^(?:题目进度|答题进度|进度)[:：]?\\d+[/／]\\d+$|^第\\d+题[/／]?共\\d+题$").matches(compact(t)) } }
    fun unknown(reason:String,ocr:Boolean=true)=GenericObservation.Unknown(reason,ocr,explicitProgress?.first,explicitProgress?.second)
    fun actionable(node:ScreenNode):ScreenNode? {
      if(node.ref.startsWith("ocr:")) {
        val containing=native.filter { (it.checkable||it.clickable) && it.bounds.contains(node.bounds) }
        return containing.minByOrNull { (it.bounds.right-it.bounds.left).toLong()*(it.bounds.bottom-it.bounds.top) }
          ?: node
      }
      var current:ScreenNode?=node;val visited=mutableSetOf<String>()
      while(current!=null && visited.add(current.ref)) {
        if(current.checkable||current.clickable) return current
        current=native.firstOrNull { it.ref==current?.parentRef }
      }
      return null
    }
    fun controls(labels:Set<String>):List<ScreenNode> = all.filter { n -> listOf(n.text,n.description).any { controlText(it) in labels } }
      .mapNotNull(::actionable).distinctBy { it.ref }
    // Submitted pages can retain the entire stem and disabled choices. Resolve
    // their explicit receipt before the question fallback, but never while an
    // editable choice remains. One forward control is required for navigation.
    val feedback=texts.any { text -> candidateEntries.none { (_,stem) -> stem==compact(text) } && Regex("^(?:本题已提交|提交成功|本题作答完成|(?:本题)?回答正确|(?:本题)?回答错误)[！!。.]?$").matches(text.trim()) }
    val next=controls(setOf("下一题","继续答题","查看成绩","next","continue"))
    if(feedback && next.size==1 && native.none { it.checkable }) return GenericObservation.Feedback(next.single())
    val noNativeChoices=page.nodes.none { it.checkable || it.role.substringAfterLast('.') in setOf("RadioButton","CheckBox") }
    val visualProgress=progress.singleOrNull()
    val onlyEmptyRoot=native.singleOrNull()?.let { root ->
      root.parentRef==null && !root.clickable && labels(root).isEmpty()
    }==true
    if(!exactComplete && noNativeChoices && (page.visualFrame!=null || onlyEmptyRoot) &&
      visualProgress!=null && all.any { it.ref.startsWith("ocr:") }) {
      val match=visualAnswer(page,all,visualProgress,declaredType)
      match?.question?.let { return it }
      val reason=when {
        match==null -> "未能完整定位当前题目与选项"
        match.hint!=null -> "${match.hint}，选项位置或选中状态未能确认"
        else -> "题干或选项尚未与题库唯一匹配"
      }
      val retry=match?.hint==null || page.visualFrame!=null && page.ocrAttempt<2
      if(match?.clearedOptions==true)
        return GenericObservation.Unknown(reason,retry,visualProgress.first,visualProgress.second)
      return unknown(reason,retry)
    }
    val optionPrefix=Regex("^\\s*[A-Ta-t][.、．:：)）]")
    fun isBareOrdinal(text:String)=optionPrefix.containsMatchIn(text) && optionText(text).isEmpty()
    val optionRows by lazy {
      val identities=rawOptions.groupingBy(::choiceIdentity).eachCount()
      rawOptions.mapNotNull { choice ->
        // The executor must be able to ground the original checkable node on a fresh tree.
        if(!choice.enabled || !choice.clickable || identities[choiceIdentity(choice)]!=1 ||
          choice.role.substringAfterLast('.') !in setOf("RadioButton","CheckBox")) return@mapNotNull null
        val row=native.singleOrNull { it.ref==choice.parentRef && !it.checkable && !it.scrollable }
          ?: return@mapNotNull null
        val descendants=page.nodes.filter { it.ref.startsWith(row.ref+".") && it.bounds.valid }
        if(!row.bounds.contains(choice.bounds) || descendants.any { child ->
          child.ref!=choice.ref && (child.checkable || child.clickable || child.scrollable)
        }) return@mapNotNull null
        val texts=descendants.filter { it.ref!=choice.ref && labels(it).any { text -> !isBareOrdinal(text) } }
        val label=texts.singleOrNull()?.takeIf { it.enabled && it.parentRef==row.ref && row.bounds.contains(it.bounds) }
          ?: return@mapNotNull null
        val labelText=labels(label).map(::optionText).toSet()
        if(labelText.size!=1 || labels(row).any { optionText(it) !in labelText } ||
          labels(choice).any { !isBareOrdinal(it) && optionText(it) !in labelText }) return@mapNotNull null
        OptionRow(row,choice,label)
      }
    }
    fun optionTarget(node:ScreenNode):ScreenNode? {
      val related=optionRows.singleOrNull { row ->
        node.ref==row.label.ref || node.ref==row.row.ref || node.ref.startsWith("ocr:") &&
          row.row.bounds.contains(node.bounds) && labels(node).map(::optionText).any { text ->
            labels(row.label).any { optionText(it)==text }
          }
      }
      return related?.choice ?: actionable(node)
    }
    fun isMatchedOrdinal(node:ScreenNode,options:List<GenericOption>):Boolean {
      val ocr=node.ref.startsWith("ocr:")
      return options.count { option ->
        val choice=option.node
        choice.bounds.contains(node.bounds) && (ocr || node.ref.startsWith(choice.ref+".")) ||
          optionRows.any { row -> row.choice.ref==choice.ref && row.row.bounds.contains(node.bounds) &&
            (ocr || node.parentRef==row.row.ref) }
      }==1
    }
    val found=mutableListOf<GenericObservation.Question>();var ambiguous=false;var unsafeAnswerMatch=false
    var incompleteOptions:Pair<Int,Int>?=null;var stemMismatch=false
    val optical by lazy { opticalChoices(rawOptions,screenNodes,page.nodes.filter { it.bounds.valid }) }
    for((question,_) in candidateEntries) {
      if(declaredType!=null && question.type!=declaredType) continue
      val groups=question.options.groupBy { compact(it.text) }
      val repairedRows=if(fullStem==compact(question.stem) && optical.groupingBy { it.text }.eachCount()==groups.mapValues { it.value.size }) optical else emptyList()
      val options=groups.flatMap { (wanted,group) ->
        val ordinary=all.filter { n -> labels(n).any { compact(it)==wanted || optionText(it)==wanted } }.mapNotNull(::optionTarget)
        val matches=(ordinary+repairedRows.filter { it.text==wanted }.map { it.node }).distinctBy { it.ref }
        val reliable=matches.filter { !it.ref.startsWith("ocr:") }
        val targets=if(reliable.isNotEmpty()) reliable else matches
        if(targets.size!=group.size) {
          if(targets.size>group.size) ambiguous=true
          emptyList()
        } else {
          // These copies are all distractors. Keep every node; no positional answer inference.
          group.zip(targets).map { (option,node) -> GenericOption(option.text,node) }
        }
      }
      val matchedOptions=options.map { it.node.ref }.distinct().size
      if(incompleteOptions==null || matchedOptions>incompleteOptions!!.first) incompleteOptions=matchedOptions to question.options.size
      if(options.size==question.options.size && matchedOptions==options.size) {
        val submits=controls(submitLabels)
        if(submits.size>1) return unknown("提交按钮无法唯一确认，请进入单题页面",false)
        val optionRefs=options.map { it.node.ref }.toSet()
        if(options.any { !it.node.checkable && it.node.role.substringAfterLast('.') in setOf("CheckBox","RadioButton") }) return unknown("当前选项无法读取选中状态，请重新打开目标软件后继续",false)
        if(options.any { !it.node.checkable }) return unknown("当前软件未提供可读取的选项状态，请手动完成当前题目",false)
        if(rawOptions.map { it.ref }.toSet()!=optionRefs) return unknown("页面选项与题库不一致，请核对完整题目",false)
        val lastBottom=options.maxOf { it.node.bounds.bottom }
        val extraControls=native.filter { it.clickable && !it.scrollable && it.ref !in optionRefs && it.ref!=submits.singleOrNull()?.ref && it.bounds.top>=regionTop && it.bounds.bottom<=(submits.singleOrNull()?.bounds?.top ?: lastBottom) && options.none { o -> it.ref.startsWith(o.node.ref+".") || o.node.ref.startsWith(it.ref+".") } }
        if(extraControls.isNotEmpty()) return unknown("当前题目包含其他选项，未自动作答",false)
        val expectedOptions=question.options.map { compact(it.text) }.toSet()
        val hasExtraOption=all.any { n ->
          n.bounds.top>=regionTop && n.bounds.bottom<=(submits.singleOrNull()?.bounds?.top ?: lastBottom) &&
            labels(n).any { text -> optionPrefix.containsMatchIn(text) && optionText(text) !in expectedOptions &&
              !(isBareOrdinal(text) && isMatchedOrdinal(n,options)) }
        }
        if(hasExtraOption) return unknown("页面还有未匹配的选项，未自动作答",false)
        if(fullStem!=compact(question.stem)) { stemMismatch=true;continue }
        if(!QuestionMatcher.hasUniqueAnswerTargets(question,::compact)) { unsafeAnswerMatch=true;continue }
        found+=GenericObservation.Question(question,options,submits.singleOrNull(),progress.singleOrNull()?.first,progress.singleOrNull()?.second,QuestionMatcher.key(question.type,question.stem,question.options.map { it.text }))
      }
    }
    if(unsafeAnswerMatch || ambiguous && found.isEmpty()) return unknown("选项文字重复，无法唯一确认，请核对当前页面",false)
    if(found.size>1 || exactComplete && found.isNotEmpty()) return unknown("当前页面包含多道题或结果信息，请进入单题页面",false)
    if(found.size==1) return found.single()
    if(exactComplete) {
      val score=Regex("(?:得分|score)\\s*[:：]?\\s*(\\d+)",RegexOption.IGNORE_CASE).find(content)?.groupValues?.get(1)?.toIntOrNull()
      return GenericObservation.Complete(score)
    }
    val entries=controls(entryLabels)
    if(entries.size==1 && candidateEntries.isEmpty()) return GenericObservation.Entry(entries.single())
    if(candidateEntries.isNotEmpty() && page.ocrRegions.isNotEmpty() && native.none { it.checkable } && native.any { it.role=="android.webkit.WebView" })
      return unknown("当前软件未提供可读取的选项状态，请手动完成当前题目",false)
    val firstOptionTop=optionControls.minOfOrNull { it.bounds.top } ?: page.height
    val nativeStemVisible=native.any { n -> !n.checkable && !n.clickable && n.bounds.bottom<=firstOptionTop && listOf(n.text,n.description).any { it.isNotBlank() && !decorative(it) && compact(it) !in appHeadings } }
    return unknown(when {
      stemMismatch -> "已读到选项，但题干文字未能与题库完整对应"
      incompleteOptions!=null -> "已读到题干，但仅匹配 ${incompleteOptions!!.first}/${incompleteOptions!!.second} 个选项"
      page.ocrRegions.isNotEmpty() && !nativeStemVisible -> "图片中的题目未能准确识别，请核对页面与资料"
      else -> "当前题目未在所选题库中完整匹配，请核对资料或进入答题页面"
    })
  }
}
