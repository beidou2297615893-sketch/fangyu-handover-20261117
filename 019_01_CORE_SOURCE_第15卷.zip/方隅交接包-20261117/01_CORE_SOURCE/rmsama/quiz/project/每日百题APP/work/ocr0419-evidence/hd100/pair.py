from pathlib import Path
import json,re,hashlib,shutil,unicodedata
from PIL import Image
from difflib import SequenceMatcher
base=Path("V:/work/verify-0419-device"); second=base/"secondary";out=Path(__file__).parent
events=json.loads((second/"assisted-high/events.json").read_text(encoding="utf8"));assert events[0]["t"]==1794577232150
ids=events[0]["data"]["ids"];rest=second/"assisted-high"; assists=json.loads((rest/"assistedActions.json").read_text(encoding="utf8"));latest=json.loads((rest/"progress.json").read_text(encoding="utf8"))
assert latest["run"]==events[0]["t"]
hraw=(base/"host/app/src/main/assets/web/questions.js").read_text(encoding="utf-8-sig"); bank=json.loads(hraw[hraw.index("{"):].strip().rstrip(";"))["questions"];host={q["id"]:q for q in bank}
norm=lambda s:re.sub(r"[^a-zA-Z0-9㐀-鿿]","",unicodedata.normalize("NFKC",s))
rows=[]; seen=set(); skipped=[]
def add(path,no,evidence,gt=None):
 if no<1 or no>20:return
 q=host[ids[no-1]]; data=path.read_bytes();sha=hashlib.sha256(data).hexdigest()
 if sha in seen:return
 assert Image.open(path).size==(1080,1920)
 seen.add(sha); dest=out/"originals"/("q%03d-%s.png"%(no,sha[:16]));shutil.copyfile(path,dest)
 rows.append(dict(file=dest.name,sourcePath=str(path),questionNo=no,id=q["id"],type=q["type"],stem=q["stem"],options=q["options"],expected=q["correctOptionIds"],actualScreenOptions=gt,positions=None,provenance=evidence,sha256=sha))
for file in sorted((second/"hidden100-a5-final").glob("question-*.png")):
 n=int(file.stem.split("-")[-1]);ev=next(e for e in events if e["evt"]=="show" and e["data"]["index"]==n-1)
 assert ev["data"]["id"]==ids[n-1];add(file,n,{"kind":"recorder screenshot after latest show","event":ev})
for file in sorted(rest.glob("pause-q*.png")):
 m=re.match(r"pause-q([0-9]+)$",file.stem)
 if not m:continue
 n=int(m.group(1));a=assists.get(str(n-1))
 if not a or a["id"]!=ids[n-1]:continue
 assert a["observed"]["progress"].split()[-3:] == [str(n),"/","100"]
 add(file,n,{"kind":"same-index pause and observed DOM","id":a["id"],"observedStem":a["observed"]["stem"],"observedProgress":a["observed"]["progress"]},a["observed"].get("options"))
for file in sorted(base.glob("upstream-input-*.png")):
 if Image.open(file).size!=(1080,1920):continue
 stamp=int(file.stem.split("-")[-1])//1_000_000
 if stamp<events[0]["t"]:continue
 response=file.with_name(file.name.replace("input","response")).with_suffix(".json")
 try:r=json.loads(json.loads(response.read_text(encoding="utf8"))["response"])
 except (ValueError,KeyError):continue
 show=[v for v in events if v["evt"]=="show" and v["t"]<=stamp];n=show[-1]["data"]["index"]+1 if show else r["question_no"];q=host[ids[n-1]]
 dist=SequenceMatcher(None,norm(r["question"]),norm(q["stem"])).ratio()
 candidates=[ids[i] for i in range(len(ids)) if norm(host[ids[i]]["stem"])==norm(q["stem"])]
 if len(candidates)!=1 or dist<.83:skipped.append((file.name,n,dist));continue
 add(file,n,{"kind":"capture timestamp after run + response question number + unique matching drawn stem","run":events[0]["t"],"time":stamp,"stemSimilarity":round(dist,4)})
extra=second/"live-captures"
if extra.exists():
 for f in extra.glob("*.json"):
  try:a=json.loads(f.read_text(encoding="utf-8-sig"))
  except ValueError:continue
print("time stamp =",events[0]["t"],"paired",len(rows),"distinct numbers",sorted({r["questionNo"] for r in rows}),"others",skipped)
(out/"manifest.json").write_text(json.dumps(dict(run=events[0]["t"],rows=rows,drawIds=ids,unpaired=skipped),ensure_ascii=False,indent=2),encoding="utf8")


