(()=>{
 window.__comparisonAnimation?.cancel();
 window.__comparisonAnimation=document.body.animate([{transform:'translateY(0px)'},{transform:'translateY(1px)'}],{duration:400,iterations:4500,direction:'alternate'});
 return {diagnosticOnly:true,officialApkUnchanged:true,redraw:true,maxTranslationPixels:1,durationSeconds:1800,answersInjected:false,manualNextPage:false};
})()
