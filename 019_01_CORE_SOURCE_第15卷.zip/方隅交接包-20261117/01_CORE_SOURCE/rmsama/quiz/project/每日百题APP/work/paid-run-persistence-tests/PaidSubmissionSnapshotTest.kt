package expo.modules.automationbridge.billing

import expo.modules.automationbridge.runtime.RunCodec
import expo.modules.automationbridge.runtime.RunFacts
import org.json.JSONObject

object PaidSubmissionSnapshotTest {
  @JvmStatic fun main(args:Array<String>) {
    var passed=0
    fun test(name:String,body:()->Unit) { body();println("PASS $name");passed++ }
    fun denied(body:()->Unit) { var failed=false;try { body() } catch (_:Exception) { failed=true };check(failed) }
    fun valid()=RunCodec.encode(RunFacts("run","workspace","revision","__generic__",1,"hash",status="running"))
    test("both complete snapshots decode without changing counts or pending status") {
      val before=valid();val after=valid().put("pendingSubmit",true)
      val pair=PaidSubmissionSnapshot.decodePair(before,after)
      check(!pair.first.pendingSubmit && pair.second.pendingSubmit && pair.first.submittedCount==0)
    }
    test("missing, null or wrong types in either snapshot cannot use defaults") {
      val mutations=listOf<(JSONObject)->Unit>(
        { it.remove("pendingSubmit") }, { it.put("pendingSubmit",JSONObject.NULL) },
        { it.put("pendingSubmit","false") }, { it.put("pendingSubmit",0) },
        { it.remove("submittedCount") }, { it.put("submittedCount",JSONObject.NULL) },
        { it.put("submittedCount","0") }, { it.put("submittedCount",false) },
        { it.put("submittedCount",0.0) }, { it.put("submittedCount",-1) },
        { it.put("submittedCount",Long.MAX_VALUE) })
      for (mutate in mutations) {
        val before=valid();val after=valid();mutate(before)
        denied { PaidSubmissionSnapshot.decodePair(before,after) }
        val before2=valid();val after2=valid();mutate(after2)
        denied { PaidSubmissionSnapshot.decodePair(before2,after2) }
      }
    }
    println("RESULT: $passed strict snapshot tests passed")
  }
}
