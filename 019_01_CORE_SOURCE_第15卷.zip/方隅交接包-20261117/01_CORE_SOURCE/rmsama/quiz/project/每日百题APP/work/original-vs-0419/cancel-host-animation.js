(()=>{window.__comparisonAnimation?.cancel();return {cancelled:true};})()
