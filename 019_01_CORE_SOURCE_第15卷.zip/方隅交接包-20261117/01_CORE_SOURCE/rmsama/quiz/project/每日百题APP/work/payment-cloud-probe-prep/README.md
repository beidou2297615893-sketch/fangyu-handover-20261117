# 支付云资源隔离诊断

本目录是无密钥的基础设施探针，不是支付服务。只允许读写新集合 `daily_hundred_payment_probe_v1` 中随机生成的无业务测试文档，并只请求固定支付宝 HTTPS 地址的 HEAD；不下单、不使用模型、不读取商户密钥、客户资料或其他项目的数据。

## 只读预检

在 `每日百题APP` 项目根运行：

```powershell
& './work/payment-cloud-probe-prep/deploy-diagnostic.ps1'
```

默认没有任何云写入或函数调用。预检验证固定环境、完整函数/路由列表、新函数和集合名称冲突、当前套餐状态，建立既有资源元数据基线，并校验本地探针源码哈希与固定 SDK。预检不能证明当前账号有创建权限或事务可用。

## 需明确授权后执行的诊断

```powershell
& './work/payment-cloud-probe-prep/deploy-diagnostic.ps1' -Apply
```

脚本仅拟新建文档集合 `daily_hundred_payment_probe_v1`（请求 `ADMINONLY`，读回验证）和 Event 函数 `dailyHundredPaymentProbeV1`（Nodejs20.19、256 MiB、30 秒、无用户环境变量）。不使用 `--force`、`--all`、`--path`、HTTP 函数或 Function URL。只有在函数元数据、触发器及旧函数/路由快照检查通过后，才用平台 IAM 身份直接调用一次 `{"action":"diagnostic"}`。客户端结果仅输出 `paymentEnabled`、`database`、`alipayTls` 布尔值，不输出执行日志。

任何创建或部署失败/超时都可能已产生资源：脚本停止，不自动重试、不清除或更改任何现有资源。重新运行前须先只读核实具体资源，不能假设失败即未创建。旧资源元数据比较不等于源码校验；探针、云函数和现有业务共享计算、数据库及网络额度，不能承诺高负载下绝无影响。

## Function URL

腾讯云官方文档说明 Event 函数可单独启用 `*.tencentscf.com` Function URL，该地址与 CloudBase 网关默认域名不同；但本账号、该命名空间中的创建权限及实际浏览器/支付宝回调行为未实测。**本探针不能启用 URL，也不能当作已完成真实支付部署。**

## 验证记录

2026-10-28：只读预检和默认 dry-run 通过；本地 `node --test isolated-probe-test.js` 3 项通过；未执行 `-Apply`，未创建集合或函数。`@cloudbase/node-sdk` 版本 3.18.7 从本机缓存离线安装（忽略生命周期脚本）。
