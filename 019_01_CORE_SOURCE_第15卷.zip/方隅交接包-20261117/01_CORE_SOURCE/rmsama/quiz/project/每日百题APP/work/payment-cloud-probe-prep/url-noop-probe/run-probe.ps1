param([switch]$Apply)
$ErrorActionPreference='Stop'
# The live platform generated a different trigger name from the submitted
# function name. This earlier draft cannot safely identify the URL to remove.
if($Apply){throw '旧脚本已冻结：平台生成的触发器名称与函数名不同，请勿执行。'}
$envId='fh6-d5ga45c0ddae7008c'; $region='ap-shanghai'; $fn='dailyHundredUrlProbeV1'
$tcb=(Get-Command tcb.ps1 -ErrorAction Stop).Source
$source=Join-Path $PSScriptRoot $fn
$config=Join-Path $PSScriptRoot 'cloudbaserc.json'
$requestFile=Join-Path $PSScriptRoot 'trigger-request.json'
function CallJson([string[]]$arguments) {
  $raw=@(& $tcb @arguments --json 2>$null) -join "`n"; $code=$LASTEXITCODE
  $index=$raw.IndexOf('{'); $parsed=$null
  if($index -ge 0){try{$parsed=$raw.Substring($index)|ConvertFrom-Json}catch{}}
  if($code -ne 0 -or !$parsed -or !$parsed.data){throw '云操作结果不明确，请只读复查；不要自动重试或删除资源。'}
  return $parsed.data
}
function SnapshotFunctions() {
  $items=@(CallJson @('fn','list','-e',$envId,'--limit','100'))
  if($items.Count -ge 100){throw '函数列表可能不完整，停止。'}
  return $items
}
function ExistingFunctions($items) {
  return @($items|Where-Object {$_.name -ne $fn}|Sort-Object name|Select-Object functionId,name,runtime,modifyTime,status)
}
function SnapshotRoutes() {
  $items=@(CallJson @('routes','list','-e',$envId,'--limit','100'))
  if($items.Count -ge 100){throw '路由列表可能不完整，停止。'}
  return @($items|Sort-Object domain,path|Select-Object domain,path,upstreamResourceName,upstreamResourceType,enable,enableAuth,enablePathTransmission)
}
function AsJson($value) { return ConvertTo-Json -InputObject @($value) -Depth 8 -Compress }
function CheckUnchanged($functions,$routes) {
  if((AsJson @(ExistingFunctions @(SnapshotFunctions))) -cne $functions -or (AsJson @(SnapshotRoutes)) -cne $routes){throw '既有函数或路由发生变化，请只读核查。'}
}
function ReadTrigger() {
  $body=@{FunctionName=$fn;Namespace=$envId;Limit=30;Offset=0}|ConvertTo-Json -Compress
  return CallJson @('api','scf','ListTriggers','-r',$region,'--api-version','2018-04-16','--body',$body)
}
function CheckTrigger($result,[int]$expectedEnable) {
  $entries=@($result.Triggers|Where-Object {$null -ne $_})
  if($result.TotalCount -ne 1 -or $entries.Count -ne 1){throw 'URL 数量异常，请只读核查。'}
  $entry=$entries[0]
  if($entry.TriggerName -ne $fn -or $entry.Type -ne 'http' -or $entry.Qualifier -ne '$LATEST' -or $entry.Enable -ne $expectedEnable){throw 'URL 配置或状态不符，请只读核查。'}
  $desc=$entry.TriggerDesc|ConvertFrom-Json
  if($desc.AuthType -ne 'NONE' -or $desc.NetConfig.EnableExtranet -ne $true -or $desc.NetConfig.EnableIntranet -ne $false){throw 'URL 网络或鉴权配置不符，请只读核查。'}
  return $entry
}
if((Get-FileHash -Algorithm SHA256 -LiteralPath (Join-Path $source 'index.js')).Hash -ne 'A04D4C1C56736E6367D63F125C5AEE7243AD46467F57C3D905781424DBCA1EEC'){throw '源码与已审核的无操作探针不一致。'}
if(@(Get-ChildItem -LiteralPath $source -Force).Count -ne 1){throw '探针目录存在额外文件。'}
$configData=Get-Content -Raw -LiteralPath $config|ConvertFrom-Json
if($configData.envId -ne $envId -or @($configData.functions).Count -ne 1 -or $configData.functions[0].name -ne $fn -or $configData.functions[0].handler -ne 'index.main' -or $configData.functions[0].runtime -ne 'Nodejs20.19' -or $configData.functions[0].installDependency -ne $false){throw '本地配置不符。'}
$request=Get-Content -Raw -LiteralPath $requestFile|ConvertFrom-Json
$requestDesc=$request.TriggerDesc|ConvertFrom-Json
if($request.FunctionName -ne $fn -or $request.TriggerName -ne $fn -or $request.Namespace -ne $envId -or $request.Type -ne 'http' -or $request.Qualifier -ne '$LATEST' -or $request.Enable -ne 'OPEN' -or $requestDesc.AuthType -ne 'NONE' -or $requestDesc.NetConfig.EnableExtranet -ne $true -or $requestDesc.NetConfig.EnableIntranet -ne $false){throw 'URL 创建请求不符。'}
$initialFunctions=@(SnapshotFunctions)
if(@($initialFunctions|Where-Object {$_.name -eq $fn}).Count){throw '同名函数已存在；停止，不覆盖。'}
$beforeFunctions=AsJson @(ExistingFunctions $initialFunctions); $beforeRoutes=AsJson @(SnapshotRoutes)
if(!$Apply){Write-Output '只读预检通过；计划新建独立 503 函数和匿名 URL，验证后仅删除该 URL 触发器、保留函数。本次无云修改。';return}
Write-Output '创建独立函数；结果不明时停止。'
Push-Location $PSScriptRoot
try {
  $out=@(& $tcb fn deploy $fn -e $envId --dir $source --runtime 'Nodejs20.19' --deployMode cos --config-file $config --json 2>$null) -join "`n"
  if($LASTEXITCODE -ne 0){throw '部署结果不明确，请只读复查，禁止重试。'}
} finally {Pop-Location}
$body=@{FunctionName=$fn;Namespace=$envId}|ConvertTo-Json -Compress
$detail=$null
for($i=0;$i -lt 15;$i++){
  try {$detail=CallJson @('api','scf','GetFunction','-r',$region,'--api-version','2018-04-16','--body',$body)} catch {$detail=$null}
  if($detail -and $detail.Status -eq 'Active'){break}; Start-Sleep -Seconds 2
}
if(!$detail -or $detail.Status -ne 'Active' -or $detail.FunctionName -ne $fn -or $detail.Namespace -ne $envId -or $detail.Type -ne 'Event' -or $detail.Runtime -ne 'Nodejs20.19' -or $detail.Handler -ne 'index.main' -or $null -eq $detail.Environment -or @($detail.Environment.Variables|Where-Object {$null -ne $_}).Count -gt 0){throw '函数配置不符或状态未确认；请只读核查。'}
if((ReadTrigger).TotalCount -ne 0){throw '函数已存在触发器；请只读核查。'}
CheckUnchanged $beforeFunctions $beforeRoutes
$payload=$request|ConvertTo-Json -Depth 10 -Compress
Write-Output '创建匿名公网 URL；若创建结果不明确，停止并只读核查，不自动修改。'
$created=CallJson @('api','scf','CreateTrigger','-r',$region,'--api-version','2018-04-16','--body',$payload)
$triggers=ReadTrigger
# Require readback identity before considering deletion. Unknown results stop.
$entry=CheckTrigger $triggers 1
$testError=$null
try {
  # Accept only a unique provider-returned Shanghai host for this account; never guess it.
  $providerText=(@($created,$triggers)|ConvertTo-Json -Depth 20 -Compress).Replace('\/','/')
  $hostMatches=[regex]::Matches($providerText,'(?i)(?<![a-z0-9.-])1439321968-[a-z0-9-]+\.ap-shanghai\.tencentscf\.com(?![a-z0-9.-])')
  $hosts=@($hostMatches|ForEach-Object {$_.Value.ToLowerInvariant()}|Sort-Object -Unique)
  if($hosts.Count -ne 1){throw '平台响应未提供唯一可核验的公网地址；不猜测地址。'}
  $url='https://'+$hosts[0]+'/'
  Add-Type -AssemblyName System.Net.Http
  $handler=New-Object System.Net.Http.HttpClientHandler; $handler.AllowAutoRedirect=$false
  $client=New-Object System.Net.Http.HttpClient($handler); $client.Timeout=[TimeSpan]::FromSeconds(10)
  try {
    foreach($method in @('GET','POST')){
      $msg=New-Object System.Net.Http.HttpRequestMessage((New-Object System.Net.Http.HttpMethod($method)),$url)
      if($method -eq 'POST'){$msg.Content=New-Object System.Net.Http.StringContent('{"action":"diagnostic"}',[System.Text.Encoding]::UTF8,'application/json')}
      try {
        $response=$client.SendAsync($msg).GetAwaiter().GetResult()
        try {
          $responseBody=$response.Content.ReadAsStringAsync().GetAwaiter().GetResult()
          if([int]$response.StatusCode -ne 503 -or $responseBody -cne '{"paymentEnabled":false}'){throw 'HTTP 响应与探针预期不一致。'}
        } finally {$response.Dispose()}
      } finally {$msg.Dispose()}
    }
  } finally {$client.Dispose();$handler.Dispose()}
} catch { $testError=$_.Exception.Message }
# Only after confirmed create and exact readback: delete exactly this new HTTP
# trigger once, even when the local HTTP checks fail. Keep the function itself.
try {
  $remove=@{FunctionName=$fn;TriggerName=$fn;Type='http';Namespace=$envId;Qualifier='$LATEST'}|ConvertTo-Json -Compress
  [void](CallJson @('api','scf','DeleteTrigger','-r',$region,'--api-version','2018-04-16','--body',$remove))
} catch {throw '探针 URL 删除结果不明确，立即只读核查；不要重复修改。'}
$closed=ReadTrigger
if($closed.TotalCount -ne 0 -or @($closed.Triggers|Where-Object {$null -ne $_}).Count -ne 0){throw '删除后 URL 列表非空或状态不明，请只读核查。'}
CheckUnchanged $beforeFunctions $beforeRoutes
if($testError){throw "URL 触发器已删除；验证未通过：$testError"}
Write-Output 'HTTP GET/POST 固定 503 校验通过，专用 URL 触发器已删除、函数保留；既有函数及路由元数据未变化。'
