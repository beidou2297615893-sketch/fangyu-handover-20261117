'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict');
const {request,create,guardedTransport}=require('./tcb-create.cjs');
const zip=Buffer.from([0x50,0x4b,0x03,0x04,0x00]);
test('TCB CreateFunction payload uses the documented environment role and stamp',()=>{
 const p=request(zip);assert.deepEqual(p,{FunctionName:'dailyHundredBillingInitV1',EnvId:'fh6-d5ga45c0ddae7008c',Handler:'index.main',MemorySize:256,Timeout:30,InstallDependency:'FALSE',Stamp:'MINI_QCBASE',Role:'TCB_QcsRole',Runtime:'Nodejs20.19',Type:'Event',CodeSource:'ZipFile',Code:{ZipFile:zip.toString('base64')}});
 assert.throws(()=>request(Buffer.from('not-zip')));
});
test('transport refuses redirects, proxy and foreign hosts',async()=>{
 let options;const guard=guardedTransport(async(_url,o)=>{options=o;return 'synthetic';});
 assert.equal(await guard('https://tcb.tencentcloudapi.com/',{}),'synthetic');assert.equal(options.redirect,'error');
 assert.throws(()=>guard('https://wrong.invalid/',{}));assert.throws(()=>guard('https://tcb.tencentcloudapi.com/',{proxy:'http://proxy.invalid'}));
 assert.throws(()=>guard('https://tcb.tencentcloudapi.com/',{agent:{}}));
});
test('timeout after sending is propagated without an automatic second request',async()=>{
 const fetch=require('./sdk-tcb/node_modules/tencentcloud-sdk-nodejs-common/tencentcloud/common/http/fetch'),sdk=require('./sdk-tcb/node_modules/tencentcloud-sdk-nodejs-tcb');
 const previous=fetch.default;let calls=0;fetch.default=async()=>{calls++;throw Error('synthetic timeout');};
 try{const client=new sdk.tcb.v20180608.Client({credential:{secretId:'fake',secretKey:'fake',token:'fake'},region:'ap-shanghai'});await assert.rejects(create(client,zip));assert.equal(calls,1);}
 finally{fetch.default=previous;}
});
test('official TCB SDK sends exactly one synthetic signed request and embedded SCF failures are rejected',async()=>{
 const sdk=require('./sdk-tcb/node_modules/tencentcloud-sdk-nodejs-tcb'),fetch=require('./sdk-tcb/node_modules/tencentcloud-sdk-nodejs-common/tencentcloud/common/http/fetch');
 const original=fetch.default,calls=[];let errorCode='';
 fetch.default=async(url,options)=>{calls.push({url,action:options.headers['X-TC-Action'],payload:JSON.parse(options.body)});return {status:200,headers:{get:()=>null},json:async()=>({Response:{RequestId:'synthetic',SCFErrorCode:errorCode,SCFErrorMsg:errorCode?'error':''}})};};
 try{
  const client=new sdk.tcb.v20180608.Client({credential:{secretId:'fake-id',secretKey:'fake-key',token:'fake-token'},region:'ap-shanghai'});
  assert.deepEqual(await create(client,zip),{RequestId:'synthetic'});assert.equal(calls.length,1);
  assert.equal(calls[0].url,'https://tcb.tencentcloudapi.com/');assert.equal(calls[0].action,'CreateFunction');assert.deepEqual(calls[0].payload,request(zip));
  errorCode='ResourceInUse.Function';await assert.rejects(create(client,zip));assert.equal(calls.length,2);
 }finally{fetch.default=original;}
});
