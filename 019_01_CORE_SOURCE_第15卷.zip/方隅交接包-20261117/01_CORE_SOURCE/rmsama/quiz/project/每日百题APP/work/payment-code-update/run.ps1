param([switch]$Apply)
$ErrorActionPreference='Stop'
if(!$Apply){& node (Join-Path $PSScriptRoot 'cli.cjs');return}
foreach($name in @('NODE_OPTIONS','NODE_DEBUG','DEBUG','NODE_EXTRA_CA_CERTS','NODE_USE_SYSTEM_CA','NODE_USE_ENV_PROXY','NODE_PATH','SSL_CERT_FILE','SSL_CERT_DIR','CURL_CA_BUNDLE','REQUESTS_CA_BUNDLE','USE_INTERNAL_ENDPOINT','HTTP_PROXY','HTTPS_PROXY','ALL_PROXY','http_proxy','https_proxy','all_proxy','NODE_TLS_REJECT_UNAUTHORIZED')){if([Environment]::GetEnvironmentVariable($name)){throw '检测到自定义 Node、代理或 TLS 设置，停止。'}}
$taskTool=(Get-Command tcb.ps1 -CommandType ExternalScript -ErrorAction Stop).Source
if(!(Test-Path -LiteralPath $taskTool -PathType Leaf)){throw '无法确认云工具，停止。'}
$env:BILLING_UPDATE_TCB=$taskTool
try { & node (Join-Path $PSScriptRoot 'cli.cjs') --apply;if($LASTEXITCODE -ne 0){throw '更新未确认，禁止重试或回滚，仅做只读核查。'} }
finally { Remove-Item Env:BILLING_UPDATE_TCB -ErrorAction SilentlyContinue }
