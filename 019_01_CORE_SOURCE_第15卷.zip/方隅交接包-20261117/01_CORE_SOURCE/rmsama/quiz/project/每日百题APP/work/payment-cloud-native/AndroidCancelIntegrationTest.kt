package expo.modules.automationbridge.billing

object AndroidCancelIntegrationTest {
  @JvmStatic fun main(args:Array<String>) {
    val origin=checkNotNull(System.getenv("TEST_CANCEL_ORIGIN"))
    val owner=checkNotNull(System.getenv("TEST_CANCEL_OWNER"))
    val token=checkNotNull(System.getenv("TEST_CANCEL_TOKEN"))
    val client=AdmissionClient.forLoopbackTest(origin,object:CredentialSource {
      override fun read()=NativeCredential(owner,token)
    })
    val binding="a".repeat(64)
    fun denied(block:()->Unit) { check(runCatching(block).isFailure) }
    repeat(2) {
      val result=client.cancel("integration-run",binding)
      check(result.ownerId==owner && result.runId=="integration-run" && result.taskBinding==binding && result.status=="cancelled" && result.source=="")
    }
    denied { client.cancel("integration-run","b".repeat(64)) }
    denied { client.reserve("integration-run",binding) }
    println("PASS actual Android AdmissionClient and payment router cancellation contract")
  }
}
