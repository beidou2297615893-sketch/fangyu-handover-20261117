import java.security.KeyStore
import java.security.MessageDigest
import java.io.FileInputStream
import com.android.build.api.variant.BuildConfigField

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// Signing material is supplied only by the build process, never local.properties.
fun releaseEnv(key: String): String? = System.getenv(key)?.takeIf { it.isNotBlank() }
val officialSigningReady = listOf(
    "DAILYHUNDRED_STORE_FILE", "DAILYHUNDRED_STORE_PASSWORD", "DAILYHUNDRED_KEY_ALIAS", "DAILYHUNDRED_KEY_PASSWORD",
).all { releaseEnv(it) != null }
val expectedCertificateSha256 = "fac61745dc0903786fb9ede62a962b399f7348f0bb6f899b8332667591033b9c"
val officialCertificateMatches = if (officialSigningReady) {
    runCatching {
        val store = KeyStore.getInstance(KeyStore.getDefaultType())
        FileInputStream(checkNotNull(releaseEnv("DAILYHUNDRED_STORE_FILE"))).use {
            store.load(it, checkNotNull(releaseEnv("DAILYHUNDRED_STORE_PASSWORD")).toCharArray())
        }
        val certificate = checkNotNull(store.getCertificate(checkNotNull(releaseEnv("DAILYHUNDRED_KEY_ALIAS"))))
        MessageDigest.getInstance("SHA-256").digest(certificate.encoded)
            .joinToString("") { "%02x".format(it) } == expectedCertificateSha256
    }.getOrDefault(false)
} else false
val paymentReleaseRequested = providers.gradleProperty("paymentRelease")
    .map { it.equals("true", ignoreCase = true) }.getOrElse(false)
val freeServiceReleaseRequested = providers.gradleProperty("freeServiceRelease")
    .map { it.equals("true", ignoreCase = true) }.getOrElse(false)
if (paymentReleaseRequested && !officialCertificateMatches) { throw GradleException("Production payment requires the verified original signing certificate.") }
val originalBillingOrigin = "http://127.0.0.1:18765/diagnostic-billing-disabled"

android {
    namespace = "com.futureyyy.tijing"
    compileSdk = 35
    buildToolsVersion = "35.0.0"

    flavorDimensions += "environment"

    productFlavors {
        create("prod") {
            dimension = "environment"
        }
        create("dev") {
            dimension = "environment"
            applicationIdSuffix = ".dev"
            versionNameSuffix = "-dev"
        }
    }

    defaultConfig {
        applicationId = "com.jimusoft.dailyhundredapp.audit419"
        minSdk = 26
        targetSdk = 35
        versionCode = 86
        versionName = "0.4.19"

        buildConfigField("String", "BILLING_API_ORIGIN", "\"$originalBillingOrigin\"")
        buildConfigField("String", "BILLING_ADMISSION_ORIGIN", "\"$originalBillingOrigin\"")
        buildConfigField("boolean", "BILLING_ADMISSION_ENABLED", "false")
        buildConfigField("boolean", "BILLING_FREE_DEVICE_LEDGER_ENABLED", "false")
    }

    signingConfigs {
        create("release") {
            if (officialSigningReady) {
                storeFile = file(checkNotNull(releaseEnv("DAILYHUNDRED_STORE_FILE")))
                storePassword = releaseEnv("DAILYHUNDRED_STORE_PASSWORD")
                keyAlias = releaseEnv("DAILYHUNDRED_KEY_ALIAS")
                keyPassword = releaseEnv("DAILYHUNDRED_KEY_PASSWORD")
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = if (officialSigningReady) {
                signingConfigs.getByName("release")
            } else {
                null
            }
        }
    }

    buildFeatures {
        buildConfig = true
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

androidComponents {
    onVariants(selector().all()) { variant ->
        val isProductionRelease = variant.buildType == "release" &&
            variant.productFlavors.any { it.first == "environment" && it.second == "prod" }
        variant.buildConfigFields.put(
            "BILLING_ADMISSION_ENABLED",
            BuildConfigField(
                "boolean",
                (isProductionRelease && paymentReleaseRequested && officialSigningReady && officialCertificateMatches).toString(),
                "Enabled only by the explicit, signed production release build.",
            ),
        )
        variant.buildConfigFields.put(
            "BILLING_FREE_DEVICE_LEDGER_ENABLED",
            BuildConfigField(
                "boolean",
                (isProductionRelease && paymentReleaseRequested && freeServiceReleaseRequested && officialCertificateMatches).toString(),
                "Enabled only for the verified production service integration.",
            ),
        )
    }
}

dependencies {
    implementation("com.microsoft.onnxruntime:onnxruntime-android:1.22.0")
    implementation("com.google.mlkit:text-recognition-chinese:16.0.1")
    implementation("com.google.code.gson:gson:2.10.1")
    testImplementation("junit:junit:4.13.2")
    testImplementation("org.json:json:20180813")
}

// Diagnostic-copy-only: normal shipping tasks cannot build this fixture.
android {
    sourceSets.getByName("main").java.setSrcDirs(emptyList<String>())
    sourceSets.getByName("debug").java.setSrcDirs(listOf("src/diagnosticShared/java", "src/diagnosticDebug/java"))
}
androidComponents {
    beforeVariants(selector().all()) { variant ->
        variant.enable = variant.buildType == "debug" && variant.productFlavors.any { it.second == "dev" }
    }
}
kotlin.sourceSets.getByName("main").kotlin.setSrcDirs(emptyList<String>())
