"""Run the exact SQL declared in the Android store against disk SQLite.

This validates transaction semantics, not Android runtime or engine integration.
"""
import os
import json
import pathlib
import re
import sqlite3
import subprocess
import sys
import tempfile
import unittest

ROOT = pathlib.Path(__file__).resolve().parents[2]
SRC = ROOT / 'outputs/daily-hundred-app/modules/automation-bridge/android/src/main/java/expo/modules/automationbridge/billing/PaidRunStore.kt'

def sql(name):
    text = SRC.read_text(encoding='utf-8')
    match = re.search(r'const val ' + re.escape(name) + r'\s*=\s*"([^"\n]+)"', text)
    if not match:
        raise RuntimeError('Missing native SQL constant ' + name)
    return match.group(1)

def connect(path):
    db = sqlite3.connect(path, timeout=10)
    try:
        db.execute(sql('CREATE_SQL'))
    except Exception:
        db.close()
        raise
    return db

def reserve(db, run='run', owner='owner', binding='a' * 64, source='credit'):
    db.execute(sql('INSERT_SQL'), (run, owner, binding, source, 'reserved'))
    return db.execute(sql('READ_SQL'), (run,)).fetchone()

def change(db, run, owner, binding, before, after):
    return db.execute(sql('TRANSITION_SQL'), (after, run, owner, binding, before, after)).rowcount

def worker(argv):
    mode, path = argv
    db = connect(path)
    db.execute('BEGIN IMMEDIATE')
    if mode == 'pair-crash':
        assert change(db, 'run', 'owner', 'a' * 64, 'reserved', 'unknown') == 1
        db.execute(sql('SAVE_RUN_SQL'), ('facade', json.dumps({'runId': 'run', 'pendingSubmit': True})))
        os._exit(7)
    if mode == 'human-crash':
        assert db.execute(sql('REJECTED_SQL'),('run','owner','a'*64)).rowcount == 1
        db.execute(sql('SAVE_RUN_SQL'),('facade',json.dumps({'runId':'run','pendingSubmit':False})))
        os._exit(7)
    if mode == 'crash-before':
        assert change(db, 'run', 'owner', 'a' * 64, 'reserved', 'unknown') == 1
        os._exit(7)
    if mode == 'commit-unknown':
        assert change(db, 'run', 'owner', 'a' * 64, 'reserved', 'unknown') == 1
        db.commit()
        os._exit(0)
    assert mode in ('unknown', 'releasing')
    changed = change(db, 'race', 'owner', 'b' * 64, 'reserved', mode)
    db.commit()
    print(changed)

class PaidRunSqliteTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(dir=pathlib.Path(__file__).parent)
        self.path = str(pathlib.Path(self.tmp.name) / 'runs.sqlite')
        self.db = connect(self.path)

    def tearDown(self):
        self.db.close()
        self.tmp.cleanup()

    def child(self, mode):
        return subprocess.run([sys.executable, __file__, '--worker', mode, self.path], capture_output=True, text=True, timeout=20)

    def test_identity_and_binding_do_not_change_on_repeated_reserve(self):
        reserve(self.db)
        self.db.commit()
        self.assertEqual(reserve(self.db, owner='other', binding='b' * 64), ('owner', 'a' * 64, 'credit', 'reserved'))
        self.assertEqual(change(self.db, 'run', 'owner', 'a' * 64, 'reserved', 'unknown'), 1)
        self.assertEqual(reserve(self.db)[3], 'unknown')

    def test_existing_v4_data_and_version_remain_unchanged(self):
        self.db.execute('CREATE TABLE runs(id TEXT PRIMARY KEY, json TEXT NOT NULL)')
        self.db.execute('INSERT INTO runs VALUES(?,?)', ('legacy', 'unchanged'))
        self.db.execute('PRAGMA user_version=4')
        self.db.commit()
        reserve(self.db)
        self.db.commit()
        self.assertEqual(self.db.execute('PRAGMA user_version').fetchone()[0], 4)
        self.assertEqual(self.db.execute('SELECT json FROM runs WHERE id=?', ('legacy',)).fetchone()[0], 'unchanged')

    def test_paid_unknown_and_real_task_pending_save_together_and_survive_restart(self):
        self.db.execute('CREATE TABLE runs(id TEXT PRIMARY KEY,json TEXT NOT NULL)')
        reserve(self.db); self.db.commit()
        state = json.dumps({'runId': 'run', 'genericRun': {'runId': 'run', 'pendingSubmit': True}})
        self.db.execute('BEGIN IMMEDIATE')
        self.assertEqual(change(self.db, 'run', 'owner', 'a' * 64, 'reserved', 'unknown'), 1)
        self.db.execute(sql('SAVE_RUN_SQL'), ('facade', state))
        self.db.execute(sql('SAVE_RUN_SQL'), ('run', json.dumps({'runId': 'run', 'pendingSubmit': True})))
        self.db.commit(); self.db.close(); self.db = connect(self.path)
        self.assertEqual(self.db.execute(sql('READ_SQL'), ('run',)).fetchone()[3], 'unknown')
        self.assertTrue(json.loads(self.db.execute('SELECT json FROM runs WHERE id=?', ('facade',)).fetchone()[0])['genericRun']['pendingSubmit'])
        self.assertTrue(json.loads(self.db.execute('SELECT json FROM runs WHERE id=?', ('run',)).fetchone()[0])['pendingSubmit'])

    def test_saved_intent_before_dispatch_is_recoverable_but_dispatched_is_not(self):
        self.db.execute('CREATE TABLE runs(id TEXT PRIMARY KEY,json TEXT NOT NULL)')
        reserve(self.db)
        self.db.execute(sql('SAVE_RUN_SQL'),('facade',json.dumps({'runId':'run','pendingSubmit':True,'paidPendingIntentId':'intent'})))
        self.db.commit();self.db.close();self.db=connect(self.path)
        self.assertEqual(self.db.execute(sql('READ_SQL'),('run',)).fetchone()[3],'reserved')
        self.assertTrue(json.loads(self.db.execute('SELECT json FROM runs WHERE id=?',('facade',)).fetchone()[0])['pendingSubmit'])
        self.assertEqual(change(self.db,'run','owner','a'*64,'reserved','unknown'),1)
        self.db.commit();self.db.close();self.db=connect(self.path)
        self.assertEqual(change(self.db,'run','owner','a'*64,'unknown','releasing'),0)
        self.assertEqual(self.db.execute(sql('READ_SQL'),('run',)).fetchone()[3],'unknown')

    def test_explicit_rejection_and_user_verdict_require_same_identity(self):
        reserve(self.db);self.assertEqual(change(self.db,'run','owner','a'*64,'reserved','unknown'),1)
        self.assertEqual(self.db.execute(sql('REJECTED_SQL'),('run','wrong','a'*64)).rowcount,0)
        self.assertEqual(self.db.execute(sql('REJECTED_SQL'),('run','owner','b'*64)).rowcount,0)
        self.assertEqual(self.db.execute(sql('REJECTED_SQL'),('run','owner','a'*64)).rowcount,1)
        self.assertEqual(self.db.execute(sql('READ_SQL'),('run',)).fetchone()[3],'reserved')

    def test_human_verdict_and_pending_snapshot_commit_or_rollback_together(self):
        self.db.execute('CREATE TABLE runs(id TEXT PRIMARY KEY,json TEXT NOT NULL)');reserve(self.db)
        self.assertEqual(change(self.db,'run','owner','a'*64,'reserved','unknown'),1)
        self.db.execute(sql('SAVE_RUN_SQL'),('facade',json.dumps({'runId':'run','pendingSubmit':True})));self.db.commit()
        self.assertEqual(self.child('human-crash').returncode,7)
        self.assertEqual(self.db.execute(sql('READ_SQL'),('run',)).fetchone()[3],'unknown')
        self.assertTrue(json.loads(self.db.execute('SELECT json FROM runs WHERE id=?',('facade',)).fetchone()[0])['pendingSubmit'])
        self.db.execute('BEGIN IMMEDIATE');self.assertEqual(self.db.execute(sql('REJECTED_SQL'),('run','owner','a'*64)).rowcount,1)
        self.db.execute(sql('SAVE_RUN_SQL'),('facade',json.dumps({'runId':'run','pendingSubmit':False})));self.db.commit()
        self.assertEqual(self.db.execute(sql('READ_SQL'),('run',)).fetchone()[3],'reserved')
        self.assertFalse(json.loads(self.db.execute('SELECT json FROM runs WHERE id=?',('facade',)).fetchone()[0])['pendingSubmit'])

    def test_crash_before_atomic_commit_keeps_both_previous_states(self):
        self.db.execute('CREATE TABLE runs(id TEXT PRIMARY KEY,json TEXT NOT NULL)')
        self.db.execute('INSERT INTO runs VALUES(?,?)', ('facade', json.dumps({'runId': 'run', 'pendingSubmit': False})))
        reserve(self.db); self.db.commit()
        self.assertEqual(self.child('pair-crash').returncode, 7)
        self.assertEqual(self.db.execute(sql('READ_SQL'), ('run',)).fetchone()[3], 'reserved')
        self.assertFalse(json.loads(self.db.execute('SELECT json FROM runs WHERE id=?', ('facade',)).fetchone()[0])['pendingSubmit'])

    def test_binding_conflict_cannot_save_pending_task(self):
        self.db.execute('CREATE TABLE runs(id TEXT PRIMARY KEY,json TEXT NOT NULL)')
        self.db.execute('INSERT INTO runs VALUES(?,?)', ('facade', json.dumps({'runId': 'run', 'pendingSubmit': False})))
        reserve(self.db); self.db.commit()
        self.db.execute('BEGIN IMMEDIATE')
        self.assertEqual(change(self.db, 'run', 'owner', 'b' * 64, 'reserved', 'unknown'), 0)
        self.db.rollback()
        self.assertFalse(json.loads(self.db.execute('SELECT json FROM runs WHERE id=?', ('facade',)).fetchone()[0])['pendingSubmit'])

    def test_unknown_cannot_release_or_return_to_reserved(self):
        reserve(self.db)
        self.assertEqual(change(self.db, 'run', 'owner', 'a' * 64, 'reserved', 'unknown'), 1)
        self.assertEqual(change(self.db, 'run', 'owner', 'a' * 64, 'unknown', 'releasing'), 0)
        self.assertEqual(change(self.db, 'run', 'owner', 'a' * 64, 'unknown', 'reserved'), 0)
        self.assertEqual(change(self.db, 'run', 'owner', 'a' * 64, 'unknown', 'receipt_confirmed'), 1)
        self.assertEqual(change(self.db, 'run', 'owner', 'a' * 64, 'receipt_confirmed', 'confirmed'), 1)
        self.assertEqual(change(self.db, 'run', 'owner', 'a' * 64, 'confirmed', 'reserved'), 0)

    def test_verified_receipt_snapshot_and_paid_phase_commit_together_without_touching_free_ledger(self):
        self.db.execute('CREATE TABLE runs(id TEXT PRIMARY KEY,json TEXT NOT NULL)')
        self.db.execute('CREATE TABLE settings(key TEXT PRIMARY KEY,value TEXT NOT NULL)')
        original_free = json.dumps({'free1':'used','free2':'used','free3':'used'})
        self.db.execute('INSERT INTO settings VALUES(?,?)', ('billingUsageV1', original_free))
        reserve(self.db);self.assertEqual(change(self.db,'run','owner','a'*64,'reserved','unknown'),1)
        self.db.execute(sql('SAVE_RUN_SQL'), ('facade', json.dumps({'runId':'run','pendingSubmit':True})))
        self.db.commit()
        self.db.execute('BEGIN IMMEDIATE')
        self.assertEqual(change(self.db,'run','owner','a'*64,'unknown','receipt_confirmed'),1)
        self.db.execute(sql('SAVE_RUN_SQL'), ('facade',json.dumps({'runId':'run','pendingSubmit':False,'submittedCount':1})))
        self.db.rollback()
        self.assertEqual(self.db.execute(sql('READ_SQL'),('run',)).fetchone()[3],'unknown')
        self.assertTrue(json.loads(self.db.execute('SELECT json FROM runs WHERE id=?',('facade',)).fetchone()[0])['pendingSubmit'])
        self.db.execute('BEGIN IMMEDIATE')
        self.assertEqual(change(self.db,'run','owner','a'*64,'unknown','receipt_confirmed'),1)
        self.db.execute(sql('SAVE_RUN_SQL'), ('facade',json.dumps({'runId':'run','pendingSubmit':False,'submittedCount':1})))
        self.db.commit();self.db.close();self.db=connect(self.path)
        self.assertEqual(self.db.execute(sql('READ_SQL'),('run',)).fetchone()[3],'receipt_confirmed')
        self.assertEqual(json.loads(self.db.execute('SELECT json FROM runs WHERE id=?',('facade',)).fetchone()[0])['submittedCount'],1)
        self.assertEqual(self.db.execute('SELECT value FROM settings WHERE key=?',('billingUsageV1',)).fetchone()[0],original_free)

    def test_wrong_owner_or_binding_cannot_mutate_run(self):
        reserve(self.db)
        self.assertEqual(change(self.db, 'run', 'other', 'a' * 64, 'reserved', 'unknown'), 0)
        self.assertEqual(change(self.db, 'run', 'owner', 'b' * 64, 'reserved', 'unknown'), 0)

    def test_process_crash_before_commit_rolls_back_and_commit_survives_reopen(self):
        reserve(self.db); self.db.commit()
        self.assertEqual(self.child('crash-before').returncode, 7)
        self.assertEqual(self.db.execute(sql('READ_SQL'), ('run',)).fetchone()[3], 'reserved')
        self.assertEqual(self.child('commit-unknown').returncode, 0)
        self.db.close(); self.db = connect(self.path)
        self.assertEqual(self.db.execute(sql('READ_SQL'), ('run',)).fetchone()[3], 'unknown')
        self.assertEqual(change(self.db, 'run', 'owner', 'a' * 64, 'unknown', 'releasing'), 0)

    def test_concurrent_processes_submit_or_release_only_one_wins(self):
        reserve(self.db, run='race', binding='b' * 64); self.db.commit()
        one = subprocess.Popen([sys.executable, __file__, '--worker', 'unknown', self.path], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        two = subprocess.Popen([sys.executable, __file__, '--worker', 'releasing', self.path], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        a, ae = one.communicate(timeout=20); b, be = two.communicate(timeout=20)
        self.assertEqual((one.returncode, two.returncode), (0, 0), (ae, be))
        self.assertEqual(sorted((a.strip(), b.strip())), ['0', '1'])
        self.assertIn(self.db.execute(sql('READ_SQL'), ('race',)).fetchone()[3], ('unknown', 'releasing'))

if __name__ == '__main__':
    if len(sys.argv) == 4 and sys.argv[1] == '--worker': worker(sys.argv[2:])
    else: unittest.main()
