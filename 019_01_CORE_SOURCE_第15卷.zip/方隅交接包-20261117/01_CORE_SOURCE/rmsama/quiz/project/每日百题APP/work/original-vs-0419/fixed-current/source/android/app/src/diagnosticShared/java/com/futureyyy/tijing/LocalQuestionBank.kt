package com.futureyyy.tijing

import android.content.Context
import com.google.gson.JsonArray
import com.google.gson.JsonElement
import com.google.gson.JsonNull
import com.google.gson.JsonObject
import com.google.gson.JsonParser
import java.text.Normalizer
import java.math.BigDecimal
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max

enum class QuestionBankMatchStatus {
    EXACT,
    KEY_PHRASE,
    AMBIGUOUS,
    CONFLICT,
    NOT_FOUND,
}

data class LocalQuestionBankRecord(
    val id: String,
    val question: String,
    val type: QuestionType,
    val answerIndices: List<Int>,
    val answerText: String = "",
    val options: List<QuizOption> = emptyList(),
    val anchors: List<String> = emptyList(),
    val sources: List<String> = emptyList(),
)

data class QuestionBankMatch(
    val status: QuestionBankMatchStatus,
    val record: LocalQuestionBankRecord? = null,
    val score: Double = 0.0,
    val candidates: List<LocalQuestionBankRecord> = emptyList(),
)

internal class BankStemNotFound : IncompleteQuestionOptions("题库没有找到对应题干，本题尚未提交。")

class QuestionBankIndex private constructor(
    private val records: List<LocalQuestionBankRecord>,
    private val exact: Map<String, List<LocalQuestionBankRecord>>,
    private val conflicts: Set<String>,
) {
    private val verifiedStems by lazy {
        records.filterNot { "auto_fallback" in it.sources }.groupBy { verifiedStemKey(it.question) }
    }
    private val formattingVariants by lazy {
        verifiedStems.keys.groupBy(::alternateStemKey)
    }
    private val byPageText by lazy {
        formattingVariants.keys.groupBy { ocrProseKey(it) }
    }
    /** Reassemble wrapped rows without using any host IDs, item numbering, or hidden answer data. */
    internal fun verifiedOcrPage(raw: List<VisibleQuestionReader.Node>, questionNo: Int): QuizModelResult? {
        if (raw.size !in 3..160) return null
        val lines = raw.filter { it.box != null }.sortedWith(compareBy({ it.box!!.y }, { it.box!!.x }))
        val tokens = lines.map { Normalizer.normalize(it.text, Normalizer.Form.NFKC).trim() }
        if (tokens.any { it in setOf("回答正确", "回答错误", "答案解析", "下一题", "查看成绩") || it.startsWith("正确答案:") }) return null
        val submit = tokens.indexOfFirst { it.trim('|','丨',' ') in setOf("确认","确认答案","提交","提交答案","确定") }
        val end = if (submit >= 0) submit else tokens.indexOfFirst { OCR_FOOTER.matches(it) }.takeIf { it >= 0 } ?: lines.size
        val results = mutableListOf<QuizModelResult>()
        for (start in 0 until end - 2) {
            var stem = ""
            for (i in start until minOf(start + 12, end - 2)) {
                stem += tokens[i]
                val key = verifiedStemKey(stem)
                if (key.length < 2) continue
                val records = verifiedStems[key] ?: formattingVariants[alternateStemKey(key)].orEmpty().flatMap { verifiedStems.getValue(it) }
                for (record in records) {
                    val expected = if (record.options.isNotEmpty()) record.options.map { verifiedOptionKey(it.text, it.index) }
                        else if (record.answerText in setOf("对", "错", "正确", "错误")) listOf("对", "错") else continue
                    val remaining = expected.toMutableList()
                    val options = mutableListOf<QuizOption>()
                    var pending = ""
                    var firstBox: NormalizedBox? = null
                    for (j in i + 1 until end) {
                        val text = tokens[j].trimStart('○','◯','□','☐','●','◉','◎',' ')
                        if (text.isBlank() || OCR_INSTRUCTION.matches(text)) continue
                        if (remaining.isEmpty()) { pending = text; break }
                        val label = ('A' + options.size).toString()
                        if (pending.isEmpty() && text in setOf(label, "$label.", "$label、", "($label)", "【$label】")) continue
                        if (firstBox == null) firstBox = lines[j].box
                        pending += text
                        val option = verifiedOptionKey(pending, options.size)
                        if (option !in remaining) continue
                        options.add(QuizOption(options.size, pending, firstBox))
                        remaining.remove(option)
                        pending = ""
                        firstBox = null
                    }
                    if (remaining.isNotEmpty() || pending.isNotEmpty() || options.size < 2) continue
                    val type = when {
                        record.options.isEmpty() -> QuestionType.TRUE_FALSE
                        record.answerIndices.size > 1 -> QuestionType.MULTIPLE
                        else -> QuestionType.SINGLE
                    }
                    val page = QuizModelResult(questionNo, type, stem, options, emptyList(), lines.getOrNull(submit)?.box, null, 1.0)
                    try { results.add(verifiedAnswer(page)) } catch (_: IncompleteQuestionOptions) { /* try other visible variants */ }
                }
            }
        }
        // Repeated headers can yield the same reconstruction; reject different targets or differing answers.
        return results.distinctBy { listOf(verifiedStemKey(it.question), it.options, it.answerIndices.sorted()) }.singleOrNull()
    }

    /** An answer from imported records only. Preserve meaningful numbers, operators and negation. */
    internal fun verifiedAnswer(page: QuizModelResult): QuizModelResult {
        if (verifiedStems.isEmpty()) throw IncompleteQuestionOptions("没有可核对的题库记录，请先导入题库。")
        if (page.options.size < 2 || page.options.map { it.index }.sorted() != page.options.indices.toList()) {
            throw IncompleteQuestionOptions()
        }
        val stem = verifiedStemKey(page.question)
        if (stem.isBlank()) throw IncompleteQuestionOptions("尚未读到题干，请显示完整题目后重试。")
        val normalizedStem = alternateStemKey(stem)
        val comparable = ocrProseKey(normalizedStem)
        val direct = verifiedStems[stem] ?: formattingVariants[normalizedStem]?.flatMap { verifiedStems.getValue(it) }
        val candidates = direct ?: run {
            val matchingText = byPageText[comparable] ?: byPageText.keys.filter { candidate ->
                safeGlyphDifference(comparable, candidate)
            }.flatMap { byPageText.getValue(it) }
            matchingText.flatMap { variant -> formattingVariants.getValue(variant).flatMap { verifiedStems.getValue(it) } }
        }
        if (candidates.isEmpty()) {
            // A fragment, changed qualifier or misread limit must not be called an out-of-bank question.
            val similar = verifiedStems.keys.any { candidate ->
                (minOf(stem.length, candidate.length) >= 6 && (stem in candidate || candidate in stem)) ||
                    (minOf(stem.length, candidate.length) >= 5 && withinTwoEdits(stem, candidate))
            }
            if (similar || match(stem).status != QuestionBankMatchStatus.NOT_FOUND) {
                throw IncompleteQuestionOptions("库内有相似题干，但措辞或数值未能核对。请显示完整原题后重试。")
            }
            throw BankStemNotFound()
        }
        val opticallyVerified = page.physicalRuleIndex
        val key: (String, Int) -> String = if (opticallyVerified == null) ::verifiedOptionKey else {
            if (direct == null || page.options.singleOrNull { OcrHostPage.isRuleOption(it.text,it.index) }?.index != opticallyVerified ||
                candidates.any { rec -> rec.options.count { OcrHostPage.isRuleOption(it.text,it.index) } != 1 }) {
                throw IncompleteQuestionOptions("横线选项不能唯一核对，本题尚未提交。")
            }
            { text, index -> if (OcrHostPage.isRuleOption(text,index)) "—" else verifiedOptionKey(text,index) }
        }
        val keys = page.options.map { key(it.text, it.index) }
        if (keys.any { it.isBlank() }) throw IncompleteQuestionOptions()
        val screenSet = keys.groupingBy { it }.eachCount()
        val variants = candidates.filter { record ->
            if (record.options.isEmpty()) screenSet.keys == setOf("对", "错") && screenSet.size == page.options.size
            else record.options.map { key(it.text, it.index) }.groupingBy { it }.eachCount() == screenSet
        }
        if (variants.isEmpty()) throw IncompleteQuestionOptions("题干已在题库中找到，但屏幕选项与库内选项不一致。请显示完整选项后重试。")
        val answers = variants.map { mapBankRecordToVision(it, page, key) }
        if (answers.any { it == null } || answers.filterNotNull().map { it.answerIndices.toSet() }.distinct().size != 1 ||
            candidates.any { record ->
                val key = normalize(record.question)
                key in conflicts && exact[key].orEmpty().count { "auto_fallback" !in it.sources } < 2
            }) {
            throw IncompleteQuestionOptions("这道题没有唯一可核对的题库答案，请核对题库和选项。")
        }
        return answers.filterNotNull().first().copy(matchStatus = "exact", matchLabel = "题干和选项已核对", answerText = null, matchSource = null)
    }

    internal fun requireCompleteVisionOptions(page: QuizModelResult) {
        if (page.type == QuestionType.FILL_BLANK || page.options.isEmpty()) return
        val stem = screenStemKey(page.question)
        // Imported spreadsheets can label a multiple-choice question as SINGLE.
        // Only the exact stem and option texts establish completeness here.
        val candidates = exact[normalize(page.question)].orEmpty().filter {
            screenStemKey(it.question) == stem && it.options.isNotEmpty()
        }
        val screen = page.options.map { visionOptionKey(it.text) }.groupingBy { it }.eachCount()
        if (screen.keys.any(String::isEmpty)) return
        val known = candidates.map { record ->
            record.options.map { visionOptionKey(it.text) }.groupingBy { it }.eachCount()
        }.filter { keys -> keys.keys.none(String::isEmpty) }
        // A legitimate shorter variant must win over a longer same-stem record.
        if (known.any { it == screen }) return
        if (known.any { bank ->
                bank.values.sum() > page.options.size &&
                    screen.all { (text, count) -> count <= (bank[text] ?: 0) }
            }) throw IncompleteQuestionOptions()
    }

    /** Only the on-screen stem and complete option rows can authorize a local answer. */
    internal fun answerForScreen(page: QuizModelResult): QuizModelResult? {
        if (page.options.size < 2 || page.options.map { it.index } != page.options.indices.toList() ||
            page.options.any { it.box == null && !it.screenRow } || (page.confirmBox == null && !page.options.all { it.screenRow })
        ) return null
        val keys = page.options.map { visionOptionKey(it.text) }
        if (keys.any(String::isEmpty) || keys.distinct().size != keys.size) return null
        val exactStem = screenStemKey(page.question)
        val normalized = normalize(page.question)
        val candidates = exact[normalized].orEmpty()
        if (normalized in conflicts && candidates.size < 2) return null
        val records = candidates.filter { it.type == page.type && screenStemKey(it.question) == exactStem }
        val matches = records.mapNotNull { record -> mapBankRecordToVision(record, page) }
        if (matches.size != 1) return null
        return matches.single().copy(matchStatus = "exact", matchLabel = "屏幕题库精确匹配")
    }

    private fun screenStemKey(value: String): String =
        Normalizer.normalize(value, Normalizer.Form.NFKC).filterNot(Char::isWhitespace)

    fun match(question: String): QuestionBankMatch {
        val query = normalize(question)
        if (query.isBlank()) return QuestionBankMatch(QuestionBankMatchStatus.NOT_FOUND)
        if (query in conflicts) return QuestionBankMatch(QuestionBankMatchStatus.CONFLICT, candidates = exact[query].orEmpty())

        exact[query]?.let { candidates ->
            return if (candidates.size == 1) {
                QuestionBankMatch(QuestionBankMatchStatus.EXACT, candidates[0], 1.0, candidates)
            } else {
                QuestionBankMatch(QuestionBankMatchStatus.AMBIGUOUS, candidates = candidates)
            }
        }

        val ranked = records.mapNotNull { record ->
            val matched = record.anchors.filter(query::contains)
            val coverage = if (record.anchors.isEmpty()) 0.0 else matched.size.toDouble() / record.anchors.size
            val similarity = similarity(record.normalizedQuestion(), query)
            val ordered = orderedAnchors(query, matched)
            val score = coverage * 0.7 + similarity * 0.3
            if (ordered && coverage >= MIN_KEY_PHRASE_COVERAGE && score >= MIN_SIMILARITY) {
                RankedRecord(record, coverage, score)
            } else {
                null
            }
        }.sortedByDescending(RankedRecord::score)

        if (ranked.isEmpty()) return QuestionBankMatch(QuestionBankMatchStatus.NOT_FOUND)
        val best = ranked[0]
        val second = ranked.getOrNull(1)
        if (second != null && second.coverage >= MIN_KEY_PHRASE_COVERAGE && best.score - second.score < AMBIGUITY_SCORE_GAP) {
            return QuestionBankMatch(
                status = QuestionBankMatchStatus.AMBIGUOUS,
                candidates = ranked.take(MAX_CANDIDATES).map(RankedRecord::record),
            )
        }
        return QuestionBankMatch(
            status = QuestionBankMatchStatus.KEY_PHRASE,
            record = best.record,
            score = best.score,
            candidates = ranked.take(MAX_CANDIDATES).map(RankedRecord::record),
        )
    }

    fun toModelJson(match: QuestionBankMatch, recognizedQuestion: String, questionNo: Int): String {
        val record = match.record
        val json = JsonObject().apply {
            addProperty("question_no", questionNo)
            addProperty("question_type", record?.type?.jsonName() ?: "single")
            addProperty("question", record?.question ?: recognizedQuestion)
            add("options", JsonArray().apply {
                record?.options?.forEach { option ->
                    add(JsonObject().apply {
                        addProperty("index", option.index)
                        addProperty("text", option.text)
                    })
                }
            })
            add("answer_indices", JsonArray().apply {
                record?.answerIndices?.forEach(::add)
            })
            addProperty("answer_text", record?.answerText ?: "")
            add("confirm_box", JsonNull.INSTANCE)
            add("next_box", JsonNull.INSTANCE)
            addProperty("confidence", if (record == null) 0.0 else match.score.coerceIn(0.0, 1.0))
            addProperty("match_status", match.status.name.lowercase(Locale.ROOT))
            addProperty("match_label", match.status.label())
            addProperty("match_source", record?.sourceLabel() ?: "题库匹配")
            addProperty("answer_source", "question_bank")
        }
        return json.toString()
    }

    private data class RankedRecord(
        val record: LocalQuestionBankRecord,
        val coverage: Double,
        val score: Double,
    )

    companion object {
        private const val ANCHOR_LENGTH = 6
        private const val MAX_ANCHORS = 3
        private const val MIN_KEY_PHRASE_COVERAGE = 2.0 / 3.0
        private const val MIN_SIMILARITY = 0.46
        private const val AMBIGUITY_SCORE_GAP = 0.22
        private const val MAX_CANDIDATES = 5

        fun fromRecords(
            sourceRecords: List<LocalQuestionBankRecord>,
            conflictQuestions: Set<String> = emptySet(),
        ): QuestionBankIndex {
            val normalizedRecords = sourceRecords.map { record ->
                record.copy(anchors = record.anchors.map(::normalize).filter(String::isNotBlank))
            }
            val frequencies = mutableMapOf<String, Int>()
            normalizedRecords.forEach { record ->
                grams(normalize(record.question)).distinct().forEach { gram ->
                    frequencies[gram] = (frequencies[gram] ?: 0) + 1
                }
            }
            val enriched = normalizedRecords.map { record ->
                val anchors = if (record.anchors.isNotEmpty()) {
                    record.anchors
                } else {
                    selectAnchors(normalize(record.question), frequencies)
                }
                record.copy(anchors = anchors)
            }
            val exact = enriched.groupBy { normalize(it.question) }
            return QuestionBankIndex(
                records = enriched,
                exact = exact,
                conflicts = conflictQuestions.map(::normalize).toSet(),
            )
        }

        fun normalize(value: String): String {
            val normalized = Normalizer.normalize(value, Normalizer.Form.NFKC).lowercase(Locale.ROOT)
            return normalized.filter { char -> char.isLetterOrDigit() || char in '\u3400'..'\u9fff' }
        }

        private fun grams(value: String): List<String> {
            if (value.isBlank()) return emptyList()
            if (value.length <= ANCHOR_LENGTH) return listOf(value)
            return (0..value.length - ANCHOR_LENGTH).map { value.substring(it, it + ANCHOR_LENGTH) }.distinct()
        }

        private fun selectAnchors(value: String, frequencies: Map<String, Int>): List<String> {
            val candidates = grams(value)
            if (candidates.size <= MAX_ANCHORS) return candidates
            val last = max(0, value.length - ANCHOR_LENGTH)
            return listOf(0, (last * 0.5).toInt(), last).mapNotNull { target ->
                candidates.minByOrNull { gram ->
                    abs(value.indexOf(gram) - target) * 1_000_000 + (frequencies[gram] ?: 0)
                }
            }.distinct()
        }

        private fun orderedAnchors(query: String, anchors: List<String>): Boolean {
            var cursor = 0
            return anchors.all { anchor ->
                val position = query.indexOf(anchor, cursor)
                if (position < 0) false else {
                    cursor = position + 1
                    true
                }
            }
        }

        private fun similarity(left: String, right: String): Double {
            if (left.isBlank() || right.isBlank()) return 0.0
            val previous = IntArray(right.length + 1)
            for (i in left.indices) {
                var diagonal = 0
                for (j in right.indices) {
                    val saved = previous[j + 1]
                    previous[j + 1] = if (left[i] == right[j]) diagonal + 1 else max(previous[j + 1], previous[j])
                    diagonal = saved
                }
            }
            return previous[right.length].toDouble() / max(left.length, right.length)
        }

        private fun LocalQuestionBankRecord.normalizedQuestion(): String = normalize(question)

        private fun QuestionType.jsonName(): String = when (this) {
            QuestionType.SINGLE -> "single"
            QuestionType.MULTIPLE -> "multiple"
            QuestionType.INDEFINITE -> "indefinite"
            QuestionType.TRUE_FALSE -> "true_false"
            QuestionType.FILL_BLANK -> "fill_blank"
        }

        private fun QuestionBankMatchStatus.label(): String = when (this) {
            QuestionBankMatchStatus.EXACT -> "精确匹配"
            QuestionBankMatchStatus.KEY_PHRASE -> "关键短句匹配"
            QuestionBankMatchStatus.AMBIGUOUS -> "匹配不唯一"
            QuestionBankMatchStatus.CONFLICT -> "题库答案冲突"
            QuestionBankMatchStatus.NOT_FOUND -> "题库未命中"
        }

        private fun LocalQuestionBankRecord.sourceLabel(): String = sources.firstOrNull() ?: "题库记录"
    }
}

object QuestionStemParser {
    fun parse(raw: String): String {
        val text = raw.trim()
            .replaceFirst(Regex("^```(?:json)?\\s*", RegexOption.IGNORE_CASE), "")
            .replace(Regex("\\s*```$"), "")
            .trim()
        val json = try {
            JsonParser.parseString(text).asJsonObject
        } catch (error: Exception) {
            throw IllegalArgumentException("题干识别响应不是有效 JSON", error)
        }
        val question = json.get("question")?.takeIf(JsonElement::isJsonPrimitive)?.asString?.trim().orEmpty()
        require(question.isNotEmpty()) { "题干识别响应缺少 question" }
        return question
    }
}

class QuestionBankRepository(context: Context) {
    private val store = QuestionBankStore.get(context)

    val index: QuestionBankIndex by lazy { store.index }
}

/** 知题: reuse the original bank match after the normal vision call; map the bank answer onto the AI option boxes. Null keeps the AI answer. */
fun QuestionBankIndex.answerForVision(ai: QuizModelResult): QuizModelResult? {
    val match = match(ai.question)
    val records = when (match.status) {
        QuestionBankMatchStatus.EXACT, QuestionBankMatchStatus.KEY_PHRASE -> listOfNotNull(match.record)
        QuestionBankMatchStatus.AMBIGUOUS, QuestionBankMatchStatus.CONFLICT -> match.candidates.filter {
            QuestionBankIndex.normalize(it.question) == QuestionBankIndex.normalize(ai.question)
        }
        else -> emptyList()
    }
    val mapped = records.mapNotNull { mapBankRecordToVision(it, ai) }
    // Identical screen option sets with disagreeing answers remain unresolved.
    if (mapped.map { it.answerIndices.toSet() }.distinct().size != 1) return null
    return mapped.firstOrNull()
}

private fun mapBankRecordToVision(record: LocalQuestionBankRecord, ai: QuizModelResult,
    key: (String, Int) -> String = { text, _ -> visionOptionKey(text) }): QuizModelResult? {
    val screen = ai.options.map { key(it.text, it.index) }
    if (record.options.isEmpty()) return key(record.answerText, -1).let { want -> ai.options.firstOrNull { screen.size == 2 && screen.toSet() == setOf("对", "错") && key(it.text, it.index) == want } }?.takeIf { it.box != null || it.screenRow }?.let { ai.copy(answerIndices = listOf(it.index), answerSource = "question_bank") }
    val bank = record.options.associate { it.index to key(it.text, it.index) }
    if (screen.size != bank.size || screen.groupingBy { it }.eachCount() != bank.values.groupingBy { it }.eachCount()) return null
    // Repeated distractors are harmless, but a repeated answer cannot be located reliably.
    val answers = record.answerIndices.map { index ->
        val wanted = bank[index] ?: return null
        if (screen.count { it == wanted } != 1) return null
        ai.options[screen.indexOf(wanted)]
    }
    if (answers.isEmpty() || answers.any { it.box == null && !it.screenRow }) return null
    val multi = answers.size > 1 && ai.type != QuestionType.MULTIPLE && ai.type != QuestionType.INDEFINITE
    return ai.copy(answerIndices = answers.map { it.index }, type = if (multi) QuestionType.MULTIPLE else ai.type, answerSource = "question_bank")
}

private val VISION_OPTION_LABEL = Regex("^\\s*[A-Za-zＡ-Ｚａ-ｚ]\\s*[.．、:：)）]\\s*")
private val VISION_NUMBER = Regex("^[+-]?(?:\\d+(?:\\.\\d*)?|\\.\\d+)%?$")

// A decimal number at the start of a stem (e.g. 1.5 kV) is content, not a question number.
private val SCREEN_STEM_PREFIX = Regex("""^(?:(?:第\s*\d+\s*[题題]\s*[:.、]?|\d+\s*[、)]|\d+\.(?!\d))\s*|(?:【(?:单选题?|多选题?|判断题?|不定项选择题)】|\[(?:单选题?|多选题?|判断题?|不定项选择题)]|\((?:单选题?|多选题?|判断题?|不定项选择题)\))\s*[:、]?\s*)+""")
private val SCREEN_OPTION_PREFIX = Regex("""^(?:[（(【\[]([A-Z])[）)】\]]\s*[.、:]?|([A-Z])\s*[.、:)])\s*(.*)$""")
private val EMPTY_SLOT = Regex("""\(\s*\)|_{2,}""")
private val OCR_INSTRUCTION = Regex("""^[|丨 ]*请选择(所有|全部|正确).*选项.*(确认|提交).*""")
private val OCR_FOOTER = Regex("""^(?:\d+\s*题已作答|已答\s*\d+\s*题|每题\s*\d+\s*分|上一题|剩余时间).*""")

private fun verifiedStemKey(text: String): String {
    val unlabelled = Normalizer.normalize(text.trim(), Normalizer.Form.NFKC).replaceFirst(SCREEN_STEM_PREFIX, "")
    return unlabelled.replace(EMPTY_SLOT, "()").filterNot(Char::isWhitespace).trimEnd('。', '.', '?', '？')
}

// Limited to interchangeable wording and trailing particles, without altering conditions or amounts.
private val ocrSpelling by lazy {
    QuestionBankIndex::class.java.getResourceAsStream("/opencc/TSCharacters.txt")?.bufferedReader()?.useLines { lines ->
        lines.mapNotNull { row ->
            val pair = row.split('\t')
            val from = pair.getOrNull(0)?.singleOrNull()
            val to = pair.getOrNull(1)?.trim()?.singleOrNull()
            if (from != null && to != null) from to to else null
        }.toMap()
    }.orEmpty()
}
internal fun simpleSpelling(text: String): String = text.map { ocrSpelling[it] ?: it }.joinToString("")
private fun alternateStemKey(stem: String): String = simpleSpelling(stem).replace("按照规定", "按规定")
    .replace(Regex("""发生的(?=[,，])"""), "发生")
    .replace('，', ',').replace('。', '.').replace('；',';').replace('“','"').replace('”','"')

// Ignore Chinese prose decoration only; keep parentheses/operators when they can change arithmetic.
private fun ocrProseKey(text: String): String {
    if (text.none { it in '\u3400'..'\u9fff' } || text.any { it.isDigit() || it in "+-*/%=<>" }) return text
    return text.replace("()", "＿").filterNot { it in "(),，:；;、。？?《》\"“”‘’" }
}

// OCR-confusable glyphs only. Relationship, direction, numerical and negative qualifiers are never
// corrected with a generic similarity threshold. Distinct plausible rows still need agreeing answers.
private val OCR_GLYPH_FAMILIES = listOf("合台", "按接", "情请", "间問问", "拆折", "治洽", "项頂")
private fun safeGlyphDifference(a: String, b: String): Boolean {
    if (a.length != b.length || a.length < 15) return false
    var differences = 0
    for (i in a.indices) {
        if (a[i] == b[i]) continue
        if (++differences > 1 || OCR_GLYPH_FAMILIES.none { a[i] in it && b[i] in it }) return false
    }
    return differences == 1
}

private fun withinTwoEdits(a: String, b: String): Boolean {
    if (kotlin.math.abs(a.length - b.length) > 2) return false
    var previous = IntArray(b.length + 1) { it }
    var current = IntArray(b.length + 1)
    for (i in 1..a.length) {
        current[0] = i
        var best = i
        for (j in 1..b.length) {
            current[j] = minOf(current[j - 1] + 1, previous[j] + 1, previous[j - 1] + if (a[i - 1] == b[j - 1]) 0 else 1)
            best = minOf(best, current[j])
        }
        if (best > 2) return false
        val tmp = current; current = previous; previous = tmp
    }
    return previous[b.length] <= 2
}

private fun verifiedOptionKey(text: String, index: Int): String {
    val value = Normalizer.normalize(text.trim(), Normalizer.Form.NFKC)
    val labelled = SCREEN_OPTION_PREFIX.matchEntire(value)
    val unlabelled = if (labelled != null && (labelled.groupValues[1] + labelled.groupValues[2]).single() - 'A' == index) {
        labelled.groupValues[3]
    } else value
    val clean = simpleSpelling(unlabelled.filterNot(Char::isWhitespace).trimEnd('。'))
    return if (VISION_NUMBER.matches(clean)) visionOptionKey(clean)
        else when (clean) { "正确" -> "对"; "错误" -> "错"; else -> clean }
}

private fun visionOptionKey(text: String): String {
    val value = Normalizer.normalize(text.replaceFirst(VISION_OPTION_LABEL, ""), Normalizer.Form.NFKC)
        .lowercase(Locale.ROOT).filterNot(Char::isWhitespace)
    // Excel stores percentage cells as fractions; never erase decimal points, signs or ranges.
    if (VISION_NUMBER.matches(value)) {
        val number = BigDecimal(value.removeSuffix("%"))
        return (if (value.endsWith("%")) number.movePointLeft(2) else number).stripTrailingZeros().toPlainString()
    }
    return value.filter { it.isLetterOrDigit() || it in ".%+-−–—/<>≤≥=" }
        .let { mapOf("正确" to "对", "错误" to "错")[it] ?: it }
}
