package com.jimusoft.comparison;

import android.app.Instrumentation;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.util.Base64;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.File;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/** Isolated test APK. All OCR and bank checks are performed by the installed QA app. */
public class BatchOcrProbe extends Instrumentation {
    private static final long FRAME_TIMEOUT_MS = 15000;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final JSONObject report = new JSONObject();
    private final JSONArray results = new JSONArray();
    private ClassLoader loader;
    private Class<?> callbackType, frameType, signatureType;
    private Object unit, reader, index, signature;
    private File corpus, output;
    private JSONArray frames;
    private long batchStarted;
    private int cursor;
    private long token;
    private boolean finished;
    private Attempt active;

    private static final class Attempt {
        final long token, started;
        final JSONObject result;
        final List<Integer> expected;
        Object primaryLines, independentLines;
        JSONObject primary, independent;
        String transcriptFile;
        String expectedPageKind;
        long stageStarted;
        String stage = "primary";
        Runnable timeout;
        Attempt(long token, JSONObject result, List<Integer> expected) {
            this.token = token; this.result = result; this.expected = expected;
            started = SystemClock.elapsedRealtime(); stageStarted = started;
        }
    }

    private interface Receiver { void accept(Object value) throws Exception; }

    @Override public void onCreate(Bundle args) { super.onCreate(args); start(); }

    @Override public void onStart() {
        main.post(() -> {
            batchStarted = SystemClock.elapsedRealtime();
            try {
                corpus = new File(getTargetContext().getFilesDir(), "ocr-corpus");
                output = new File(getTargetContext().getFilesDir(), "batch-ocr-result.json");
                JSONObject manifest = new JSONObject(new String(Files.readAllBytes(
                    new File(corpus, "manifest.json").toPath()), StandardCharsets.UTF_8));
                frames = manifest.getJSONArray("frames");
                loader = getTargetContext().getClassLoader();
                callbackType = loader.loadClass("kotlin.jvm.functions.Function1");
                unit = loader.loadClass("kotlin.Unit").getField("INSTANCE").get(null);
                signatureType = loader.loadClass("com.futureyyy.tijing.FrameSignature");
                Object companion = signatureType.getField("Companion").get(null);
                signature = call(companion, "fromBits", new Class<?>[]{boolean[].class}, new boolean[1024]);
                frameType = loader.loadClass("com.futureyyy.tijing.CaptureFrame");
                reader = loader.loadClass("com.futureyyy.tijing.OnDeviceQuestionOcr")
                    .getConstructor(android.content.Context.class).newInstance(getTargetContext());
                Object storeCompanion = loader.loadClass("com.futureyyy.tijing.QuestionBankStore")
                    .getField("Companion").get(null);
                Object store = call(storeCompanion, "get", new Class<?>[]{android.content.Context.class}, getTargetContext());
                index = get(store, "getIndex");
                report.put("targetPackage", getTargetContext().getPackageName())
                    .put("frameTimeoutMs", FRAME_TIMEOUT_MS).put("total", frames.length())
                    .put("results", results);
                writeReport(false);
                next();
            } catch (Throwable error) { finishBatch(error); }
        });
    }

    private Object call(Object target, String name, Class<?>[] types, Object... args) throws Exception {
        Method method = target.getClass().getDeclaredMethod(name, types);
        method.setAccessible(true);
        return method.invoke(target, args);
    }

    private Object get(Object target, String name) throws Exception { return call(target, name, new Class<?>[]{}); }

    private Object named(Object target, String prefix, Object... args) throws Exception {
        for (Method method : target.getClass().getDeclaredMethods()) {
            if ((method.getName().equals(prefix) || method.getName().startsWith(prefix + "$"))
                && method.getParameterTypes().length == args.length) {
                method.setAccessible(true);
                return method.invoke(target, args);
            }
        }
        throw new NoSuchMethodException(prefix);
    }

    private Object callback(Attempt attempt, Receiver receiver) {
        return Proxy.newProxyInstance(loader, new Class<?>[]{callbackType}, (proxy, method, args) -> {
            if (method.getName().equals("invoke")) {
                Object value = args[0];
                main.post(() -> {
                    if (!current(attempt)) return; // A timed-out callback cannot alter the next frame.
                    try { receiver.accept(value); } catch (Throwable error) { failFrame(attempt, error); }
                });
                return unit;
            }
            if (method.getName().equals("hashCode")) return System.identityHashCode(proxy);
            if (method.getName().equals("equals")) return proxy == args[0];
            return "batch OCR callback";
        });
    }

    private boolean current(Attempt attempt) { return !finished && active == attempt && token == attempt.token; }

    private List<Integer> answers(JSONArray values) throws Exception {
        List<Integer> out = new ArrayList<>();
        for (int i = 0; i < values.length(); i++) out.add(values.getInt(i));
        Collections.sort(out);
        return out;
    }

    private void next() {
        if (finished) return;
        if (cursor >= frames.length()) { finishBatch(null); return; }
        JSONObject item = frames.optJSONObject(cursor);
        JSONObject row = new JSONObject();
        Attempt attempt = null;
        try {
            if (item == null) throw new IllegalArgumentException("Frame entry must be an object at index " + cursor);
            String name = item.getString("file");
            int questionNo = item.getInt("questionNo");
            String expectedPageKind = item.has("expectedPageKind") ? item.getString("expectedPageKind") : null;
            List<Integer> expected = item.has("answerIndices") ? answers(item.getJSONArray("answerIndices")) : Collections.emptyList();
            if (expectedPageKind == null && !item.has("answerIndices"))
                throw new IllegalArgumentException("Question frames require answerIndices");
            row.put("file", name).put("questionNo", questionNo).put("expectedAnswerIndices", new JSONArray(expected));
            attempt = new Attempt(++token, row, expected);
            active = attempt;
            attempt.expectedPageKind = expectedPageKind;
            if (expectedPageKind != null) row.put("expectedPageKind", expectedPageKind);
            if (item.has("transcriptFile") && !item.isNull("transcriptFile")) {
                attempt.transcriptFile = item.getString("transcriptFile");
                row.put("transcriptFile", attempt.transcriptFile);
            }
            Attempt currentAttempt = attempt;
            attempt.timeout = () -> {
                if (!current(currentAttempt)) return;
                try {
                    currentAttempt.result.put("timeoutStage", currentAttempt.stage);
                    failFrame(currentAttempt, new RuntimeException("Frame timeout after " + FRAME_TIMEOUT_MS + "ms"));
                } catch (Exception error) { failFrame(currentAttempt, error); }
            };
            main.postDelayed(attempt.timeout, FRAME_TIMEOUT_MS);
            File image = new File(corpus, name).getCanonicalFile();
            if (!image.getParentFile().equals(corpus.getCanonicalFile()) || !name.toLowerCase(java.util.Locale.ROOT).endsWith(".png"))
                throw new IllegalArgumentException("PNG must be directly inside ocr-corpus");
            byte[] png = Files.readAllBytes(image.toPath());
            Object frame = frameType.getConstructor(String.class, signatureType, byte[].class)
                .newInstance("data:image/png;base64," + Base64.encodeToString(png, Base64.NO_WRAP), signature, png);
            call(reader, "readLines", new Class<?>[]{frameType, callbackType}, frame, callback(attempt, lines -> {
                currentAttempt.primaryLines = lines;
                currentAttempt.primary = inspect(lines, questionNo, currentAttempt.expected,
                    SystemClock.elapsedRealtime() - currentAttempt.stageStarted, "primary");
                currentAttempt.stage = "independent";
                currentAttempt.stageStarted = SystemClock.elapsedRealtime();
                call(reader, "readIndependent", new Class<?>[]{frameType, List.class, callbackType}, frame, lines,
                    callback(currentAttempt, independent -> {
                        currentAttempt.independentLines = independent;
                        currentAttempt.independent = inspect(independent, questionNo, currentAttempt.expected,
                            SystemClock.elapsedRealtime() - currentAttempt.stageStarted, "independent");
                        completeFrame(currentAttempt);
                    }));
            }));
        } catch (Throwable error) {
            if (attempt == null) {
                attempt = new Attempt(++token, row, Collections.emptyList()); active = attempt;
            }
            failFrame(attempt, error);
        }
    }

    private JSONObject inspect(Object lines, int number, List<Integer> expected, long elapsed, String source) throws Exception {
        JSONObject out = new JSONObject().put("source", source).put("elapsedMs", elapsed)
            .put("lineCount", ((List<?>) lines).size());
        try {
            // Match the production read(lines) order. Expected answers never enter either bank call.
            Object hostCompanion = loader.loadClass("com.futureyyy.tijing.OcrHostPage").getField("Companion").get(null);
            Object host = call(hostCompanion, "read", new Class<?>[]{List.class}, lines);
            Object hostPage = get(host, "getPage");
            Object page = call(reader, "pageFromLines", new Class<?>[]{List.class, int.class}, lines, number);
            Object bank = null;
            String matchMethod = null;
            boolean graded = (Boolean) get(hostPage, "getGraded");
            boolean result = (Boolean) get(host, "getResult");
            out.put("graded", graded).put("resultPage", result);
            if (!graded && !result) {
                if (page != null) {
                    try {
                        bank = named(index, "verifiedAnswer", page);
                        if (bank != null) matchMethod = "verifiedAnswer";
                    } catch (Throwable ignored) { /* Production treats a rejected parsed page as no match. */ }
                }
                if (bank == null) {
                    bank = named(index, "verifiedOcrPage", lines, number);
                    if (bank != null) matchMethod = "verifiedOcrPage";
                }
            }
            out.put("matchMethod", matchMethod == null ? JSONObject.NULL : matchMethod);
            out.put("bankResult", bank != null);
            if (bank != null) {
                List<Integer> actual = new ArrayList<>();
                for (Object value : (List<?>) get(bank, "getAnswerIndices")) actual.add(((Number) value).intValue());
                Collections.sort(actual);
                out.put("answerIndices", new JSONArray(actual)).put("matchesExpected", actual.equals(expected));
            } else out.put("answerIndices", JSONObject.NULL).put("matchesExpected", false);
        } catch (Throwable error) {
            out.put("bankResult", false).put("matchesExpected", false).put("error", errorText(error));
        }
        if (!out.optBoolean("matchesExpected")) out.put("lines", safeSerializeLines(lines));
        return out;
    }

    private JSONArray safeSerializeLines(Object value) {
        try { return serializeLines(value); }
        catch (Throwable error) {
            JSONArray out = new JSONArray();
            try { out.put(new JSONObject().put("serializationError", errorText(error))); } catch (Exception ignored) { }
            return out;
        }
    }

    private JSONObject inspectCloud(Attempt attempt) throws Exception {
        long started = SystemClock.elapsedRealtime();
        JSONObject out = new JSONObject().put("transcriptFile", attempt.transcriptFile)
            .put("guardRowsVerified", false).put("bankResult", false)
            .put("answerIndices", JSONObject.NULL).put("matchesExpected", false);
        try {
            if (attempt.primaryLines == null || attempt.independentLines == null)
                throw new IllegalStateException("Both actual OCR callbacks must complete before cloud comparison");
            File transcriptFile = new File(corpus, attempt.transcriptFile).getCanonicalFile();
            if (!transcriptFile.getParentFile().equals(corpus.getCanonicalFile()))
                throw new IllegalArgumentException("Transcript must be directly inside ocr-corpus");
            String raw = new String(Files.readAllBytes(transcriptFile.toPath()), StandardCharsets.UTF_8);
            Object parser = loader.loadClass("com.futureyyy.tijing.QuizModelParser").getField("INSTANCE").get(null);
            // Same as current QA parse$default: its third default copies readOptionsOnly.
            // This is the untouched model response; readOptionsOnly discards any model answer.
            out.put("readOptionsOnly", true).put("tolerateModelBoxes", true);
            Object transcript = named(parser, "parse", raw, true, true);
            Object companion = loader.loadClass("com.futureyyy.tijing.OcrHostPage").getField("Companion").get(null);
            List<Object> readings = Arrays.asList(attempt.primaryLines, attempt.independentLines);
            Object rowsValue = named(companion, "verifiedRows", readings, transcript);
            if (rowsValue == null)
                throw new IllegalArgumentException("本机画面与识别题干或选项未能核对。请让本题完整显示后重试。");
            List<?> rows = (List<?>) rowsValue;
            List<?> options = (List<?>) get(transcript, "getOptions");
            List<Object> localOptions = new ArrayList<>();
            for (Object option : options) {
                int optionIndex = ((Number) get(option, "getIndex")).intValue();
                if (optionIndex < 0 || optionIndex >= rows.size())
                    throw new IllegalArgumentException("Option index is outside the independently verified local rows");
                // Kotlin data-class copy preserves original index/text/screenRow and uses only verified local boxes.
                localOptions.add(named(option, "copy", optionIndex, get(option, "getText"), rows.get(optionIndex), get(option, "getScreenRow")));
            }
            out.put("guardRowsVerified", true);
            Object physicalRuleIndex = named(companion, "observedRuleIndex", readings, transcript);
            Object localTranscript = named(transcript, "copy",
                get(transcript, "getQuestionNo"), get(transcript, "getType"), get(transcript, "getQuestion"),
                localOptions, get(transcript, "getAnswerIndices"), get(transcript, "getConfirmBox"), get(transcript, "getNextBox"),
                get(transcript, "getConfidence"), get(transcript, "getAnswerText"), get(transcript, "getMatchStatus"),
                get(transcript, "getMatchLabel"), "device_ocr", get(transcript, "getAnswerSource"), physicalRuleIndex);
            Object bank = named(index, "verifiedAnswer", localTranscript);
            if (bank == null || !"question_bank".equals(get(bank, "getAnswerSource")))
                throw new IllegalArgumentException("题库未能核对本题答案，本题尚未提交。");
            List<Integer> actual = new ArrayList<>();
            for (Object value : (List<?>) get(bank, "getAnswerIndices")) actual.add(((Number) value).intValue());
            Collections.sort(actual);
            out.put("bankResult", true).put("answerIndices", new JSONArray(actual))
                .put("matchesExpected", actual.equals(attempt.expected));
        } catch (Throwable error) { out.put("error", errorText(error)); }
        if (!out.optBoolean("matchesExpected")) {
            out.put("primaryLines", safeSerializeLines(attempt.primaryLines));
            out.put("independentLines", safeSerializeLines(attempt.independentLines));
        }
        return out.put("elapsedMs", SystemClock.elapsedRealtime() - started);
    }

    private JSONArray serializeLines(Object value) throws Exception {
        JSONArray out = new JSONArray();
        if (value == null) return out;
        for (Object node : (List<?>) value) {
            Object bounds = get(node, "getBox");
            JSONObject box = bounds == null ? null : new JSONObject().put("x", get(bounds, "getX"))
                .put("y", get(bounds, "getY")).put("width", get(bounds, "getWidth")).put("height", get(bounds, "getHeight"));
            out.put(new JSONObject().put("text", get(node, "getText")).put("box", box == null ? JSONObject.NULL : box));
        }
        return out;
    }

    private Object readHost(Object lines) throws Exception {
        Object companion = loader.loadClass("com.futureyyy.tijing.OcrHostPage").getField("Companion").get(null);
        return call(companion, "read", new Class<?>[]{List.class}, lines);
    }

    private JSONObject describeHost(Object host) throws Exception {
        Object page = get(host, "getPage");
        Object progress = get(page, "getProgress");
        JSONObject position = progress == null ? null : new JSONObject()
            .put("current", get(progress, "getCurrent")).put("total", get(progress, "getTotal"));
        return new JSONObject().put("graded", get(page, "getGraded"))
            .put("resultPage", get(host, "getResult")).put("hasNextBox", get(host, "getNextBox") != null)
            .put("progress", position == null ? JSONObject.NULL : position);
    }

    private JSONObject inspectPage(Attempt attempt) throws Exception {
        long started = SystemClock.elapsedRealtime();
        JSONObject out = new JSONObject().put("expectedPageKind", attempt.expectedPageKind)
            .put("matchesExpected", false).put("selectedSource", JSONObject.NULL);
        try {
            if (attempt.primaryLines == null || attempt.independentLines == null)
                throw new IllegalStateException("Both actual OCR callbacks must complete before page comparison");
            Object primary = readHost(attempt.primaryLines);
            Object independent = readHost(attempt.independentLines);
            JSONObject first = describeHost(primary), second = describeHost(independent);
            out.put("primary", first).put("independent", second);
            // Invoke the installed QA's real helper; absence is an explicit error, never a local imitation.
            boolean needsSecond = (Boolean) named(primary, "needsContinuationRead", true);
            Object firstProgress = get(get(primary, "getPage"), "getProgress");
            Object secondProgress = get(get(independent, "getPage"), "getProgress");
            boolean conflict = firstProgress != null && secondProgress != null && !firstProgress.equals(secondProgress);
            out.put("needsContinuationRead", needsSecond).put("progressConflict", conflict);
            JSONObject selected = first;
            String source = "primary";
            // Expected kind is deliberately absent from this routing decision.
            if (!first.getBoolean("resultPage") && !(first.getBoolean("graded") && first.getBoolean("hasNextBox")) && needsSecond && !conflict &&
                (second.getBoolean("resultPage") || second.getBoolean("graded") && second.getBoolean("hasNextBox"))) {
                selected = second;
                source = "independent";
            }
            out.put("selectedSource", source).put("selected", selected);
            boolean matches;
            if ("graded".equals(attempt.expectedPageKind))
                matches = selected.getBoolean("graded") && selected.getBoolean("hasNextBox") && !selected.getBoolean("resultPage");
            else if ("result".equals(attempt.expectedPageKind)) matches = selected.getBoolean("resultPage");
            else throw new IllegalArgumentException("Unknown expectedPageKind: " + attempt.expectedPageKind);
            out.put("matchesExpected", matches && !attempt.result.has("error"));
        } catch (Throwable error) { out.put("error", errorText(error)); }
        if (!out.optBoolean("matchesExpected")) {
            out.put("primaryLines", safeSerializeLines(attempt.primaryLines));
            out.put("independentLines", safeSerializeLines(attempt.independentLines));
        }
        return out.put("elapsedMs", SystemClock.elapsedRealtime() - started);
    }

    private String errorText(Throwable error) {
        while (error instanceof InvocationTargetException && error.getCause() != null) error = error.getCause();
        return error.toString();
    }

    private void failFrame(Attempt attempt, Throwable error) {
        if (!current(attempt)) return;
        try {
            attempt.result.put("error", errorText(error));
            attempt.result.put("primaryLines", safeSerializeLines(attempt.primaryLines));
            attempt.result.put("independentLines", safeSerializeLines(attempt.independentLines));
            completeFrame(attempt);
        } catch (Throwable failure) { finishBatch(failure); }
    }

    private void completeFrame(Attempt attempt) throws Exception {
        if (!current(attempt)) return;
        if (attempt.timeout != null) main.removeCallbacks(attempt.timeout);
        if (attempt.transcriptFile != null) attempt.result.put("cloudComparison", inspectCloud(attempt));
        if (attempt.expectedPageKind != null) attempt.result.put("pageComparison", inspectPage(attempt));
        JSONObject selected = attempt.primary != null && attempt.primary.optBoolean("bankResult") ? attempt.primary : attempt.independent;
        attempt.result.put("primary", attempt.primary == null ? JSONObject.NULL : attempt.primary)
            .put("independent", attempt.independent == null ? JSONObject.NULL : attempt.independent)
            .put("elapsedMs", SystemClock.elapsedRealtime() - attempt.started)
            .put("resolvedSource", selected == null || !selected.optBoolean("bankResult") ? JSONObject.NULL : selected.getString("source"))
            .put("matchesExpected", attempt.expectedPageKind != null ? JSONObject.NULL : selected != null && selected.optBoolean("matchesExpected") && !attempt.result.has("error"));
        results.put(attempt.result);
        cursor++;
        active = null;
        try {
            writeReport(false); // A failed/terminated run still leaves completed frames and real progress.
            Bundle progress = new Bundle();
            progress.putInt("completed", cursor); progress.putInt("total", frames.length());
            sendStatus(1, progress);
        } catch (Throwable persistenceError) { finishBatch(persistenceError); return; }
        main.post(this::next);
    }

    private void writeReport(boolean complete) throws Exception {
        int bankCompared = 0, passed = 0, cloudCompared = 0, cloudPassed = 0, pageCompared = 0, pagePassed = 0;
        for (int i = 0; i < results.length(); i++) {
            JSONObject result = results.getJSONObject(i);
            if (!result.has("expectedPageKind")) {
                bankCompared++;
                if (result.optBoolean("matchesExpected")) passed++;
            }
            JSONObject cloud = result.optJSONObject("cloudComparison");
            if (cloud != null) {
                cloudCompared++;
                if (cloud.optBoolean("matchesExpected")) cloudPassed++;
            }
            JSONObject page = result.optJSONObject("pageComparison");
            if (page != null) {
                pageCompared++;
                if (page.optBoolean("matchesExpected")) pagePassed++;
            }
        }
        report.put("results", results).put("processed", results.length()).put("completed", results.length()).put("passed", passed)
            .put("failed", bankCompared - passed).put("bankCompared", bankCompared).put("finished", complete)
            .put("cloudCompared", cloudCompared).put("cloudPassed", cloudPassed).put("cloudRejectedOrMismatched", cloudCompared - cloudPassed)
            .put("pageCompared", pageCompared).put("pagePassed", pagePassed).put("pageFailed", pageCompared - pagePassed)
            .put("elapsedMs", SystemClock.elapsedRealtime() - batchStarted);
        if (output == null) output = new File(getTargetContext().getFilesDir(), "batch-ocr-result.json");
        File temporary = new File(output.getParentFile(), output.getName() + ".tmp");
        Files.write(temporary.toPath(), report.toString(2).getBytes(StandardCharsets.UTF_8));
        Files.move(temporary.toPath(), output.toPath(), java.nio.file.StandardCopyOption.REPLACE_EXISTING);
    }

    private void finishBatch(Throwable error) {
        if (finished) return;
        finished = true;
        if (active != null && active.timeout != null) main.removeCallbacks(active.timeout);
        Bundle bundle = new Bundle();
        try {
            if (error != null) report.put("fatalError", errorText(error));
            if (reader != null) {
                try { call(reader, "close", new Class<?>[]{}); }
                catch (Throwable closeError) { report.put("closeError", errorText(closeError)); }
            }
            writeReport(error == null && frames != null && cursor == frames.length());
            bundle.putString("result", "batch-ocr-result.json");
            bundle.putInt("completed", results.length());
        } catch (Throwable writeError) { bundle.putString("error", errorText(writeError)); error = writeError; }
        finish(error == null ? 0 : 1, bundle);
    }
}
