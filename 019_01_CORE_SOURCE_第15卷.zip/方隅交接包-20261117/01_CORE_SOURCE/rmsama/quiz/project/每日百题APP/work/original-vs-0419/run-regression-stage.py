from pathlib import Path
import subprocess,os,sys
r=Path('V:/work/original-vs-0419');stage=r/'regression-stage'
jdk=next(Path('V:/work/tools/jdk').glob('jdk-17*'));env=os.environ.copy();env.update(JAVA_HOME=str(jdk),ANDROID_HOME='V:/work/tools/android-sdk',ANDROID_SDK_ROOT='V:/work/tools/android-sdk',GRADLE_USER_HOME='V:/work/gradle-home')
args=['C:/Users/rmsama/DailyHundredNativeBuild/work/tijing-toolchain/gradle-8.7/bin/gradle.bat','-p',str(stage),'-I',str(r/'fixed-current/test-repos.gradle'),':app:testDevDebugUnitTest']
if sys.argv[1] in ['red','green']:args+=['--tests',sys.argv[2] if len(sys.argv)>2 else '*WrappedOptionRegressionTest*']
else:args+=[':app:assembleDevDebug']
args+=['--offline','--no-daemon','--console=plain','--max-workers=4']
suffix='-roman' if len(sys.argv)>2 else ''
with (r/('regression-'+sys.argv[1]+suffix+'.log')).open('w',encoding='utf-8') as log:result=subprocess.run(args,env=env,stdout=log,stderr=subprocess.STDOUT)
print('Regression stage',sys.argv[1],'exit:',result.returncode)
sys.exit(result.returncode)
