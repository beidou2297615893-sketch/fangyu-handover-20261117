import control as c
import json
folder=c.R/'railway-corpus'
manifest=json.loads((folder/'manifest.json').read_text(encoding='utf-8'))
manifest['frames']=[x for x in manifest['frames'] if x.get('transcriptFile')]
assert len(manifest['frames'])==9
path=folder/'manifest-cloud-9.json';path.write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
pkg='com.jimusoft.dailyhundredapp.audit419.dev';base='/data/user/0/'+pkg+'/files/ocr-corpus'
uid=c.adb('shell','stat','-c','%u','/data/user/0/'+pkg).decode().strip()
for source in [path]+list(folder.glob('cloud-*.json')):
    target=base+'/manifest.json' if source==path else base+'/'+source.name
    c.adb('push',source,target);c.adb('shell','chown',uid+':'+uid,target);c.adb('shell','restorecon',target)
print('Prepared 9 actual cloud transcripts for same-frame guard validation, no answers injected.')
