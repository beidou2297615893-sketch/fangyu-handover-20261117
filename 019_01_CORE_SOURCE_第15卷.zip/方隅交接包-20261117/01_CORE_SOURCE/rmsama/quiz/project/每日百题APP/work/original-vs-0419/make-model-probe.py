from pathlib import Path
import base64,json
r=Path(__file__).resolve().parent
image='data:image/png;base64,'+base64.b64encode((r/'original-retry-static.png').read_bytes()).decode()
expr='''new Promise(resolve=>{
 const id='original-native-model-probe-'+Date.now(),start=Date.now();
 const previous=window.onNativeModelResponse;
 window.onNativeModelResponse=(requestId,content,error)=>{if(requestId!==id){previous?.(requestId,content,error);return}window.onNativeModelResponse=previous;resolve({elapsedMs:Date.now()-start,error:error||null,content:content||null})};
 const s=JSON.parse(localStorage.getItem('quiz-control-settings'));
 const p={...s,questionNo:1,image:IMAGE,apiKey:localStorage.getItem('quiz-control-api-key'),timeoutMs:30000,retryCount:0};
 window.AndroidBridge.analyze(JSON.stringify(p),id);
 setTimeout(()=>resolve({timeout:true,elapsedMs:Date.now()-start}),35000);
})'''.replace('IMAGE',json.dumps(image))
(r/'probe-original-model.js').write_text(expr,encoding='utf-8')
print('Prepared unchanged original native model probe with the captured railway page.')
