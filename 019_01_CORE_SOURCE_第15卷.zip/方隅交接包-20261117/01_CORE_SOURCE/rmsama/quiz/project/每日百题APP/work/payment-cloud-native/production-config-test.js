'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict'),crypto=require('node:crypto');
const {validateProductionSettings}=require('./production-config');
function settings(){
  const app=crypto.generateKeyPairSync('rsa',{modulusLength:2048,privateKeyEncoding:{type:'pkcs8',format:'pem'},publicKeyEncoding:{type:'spki',format:'pem'}});
  const provider=crypto.generateKeyPairSync('rsa',{modulusLength:2048,privateKeyEncoding:{type:'pkcs8',format:'pem'},publicKeyEncoding:{type:'spki',format:'pem'}});
  return {BILLING_ENABLED:'true',ALIPAY_APP_ID:'2021000000000000',ALIPAY_SELLER_ID:'2088000000000000',ALIPAY_PRIVATE_KEY:app.privateKey,ALIPAY_PUBLIC_KEY:provider.publicKey,
    BILLING_MASTER_KEY:crypto.randomBytes(32).toString('base64'),BILLING_NOTIFY_URL:'https://billing.example.test/api/billing/alipay/notify',BILLING_RETURN_URL:'https://billing.example.test/api/billing/alipay/return'};
}
const origin='https://billing.example.test';
test('explicitly enabled, fixed-origin, validated production settings derive separate secrets',()=>{
  const s=validateProductionSettings(settings(),origin);assert.equal(s.appId,'2021000000000000');assert.equal(s.sellerId,'2088000000000000');
  assert.notEqual(s.registrationKey,s.identityKey);assert.notEqual(s.registrationKey,s.credentialKey);assert.notEqual(s.identityKey,s.credentialKey);
  assert.equal(s.recoveryEnabled,false);assert.equal(s.admissionPolicy,'paid-only');
});
test('disabled, incomplete, malformed or unapproved endpoint settings fail closed',()=>{
  const valid=settings();
  for(const change of [{BILLING_ENABLED:'false'},{ALIPAY_APP_ID:'bad'},{ALIPAY_SELLER_ID:'1002428264'},{BILLING_MASTER_KEY:'short'},
    {BILLING_NOTIFY_URL:'http://billing.example.test/api/billing/alipay/notify'},
    {BILLING_NOTIFY_URL:'https://evil.example.test/api/billing/alipay/notify'},
    {BILLING_RETURN_URL:'https://billing.example.test/api/billing/alipay/return?redirect=bad'},
    {ALIPAY_PUBLIC_KEY:'bad'},{ALIPAY_PRIVATE_KEY:'bad'}]){
      assert.throws(()=>validateProductionSettings({...valid,...change},origin),{message:'payment configuration unavailable'});
  }
  assert.throws(()=>validateProductionSettings(valid,'https://other.example.test'),{message:'payment configuration unavailable'});
});
test('configuration errors do not echo private keys or user-controlled data',()=>{
  const valid=settings();valid.ALIPAY_PRIVATE_KEY='secret-not-a-key';
  try{validateProductionSettings(valid,origin);assert.fail('expected failure');}catch(e){assert.equal(e.message,'payment configuration unavailable');assert.ok(!String(e.stack).includes('secret-not-a-key'));}
});
test('bare Alipay public-key base64 is normalized to verified SPKI PEM in memory',()=>{
  const valid=settings();valid.ALIPAY_PUBLIC_KEY=valid.ALIPAY_PUBLIC_KEY.replace(/-----BEGIN PUBLIC KEY-----|-----END PUBLIC KEY-----|\s/g,'');
  const ready=validateProductionSettings(valid,origin);assert.match(ready.publicKey,/^-----BEGIN PUBLIC KEY-----/);
  assert.equal(crypto.createPublicKey(ready.publicKey).asymmetricKeyType,'rsa');
});
test('the app public key cannot be mistaken for Alipay verification key',()=>{
  const valid=settings();valid.ALIPAY_PUBLIC_KEY=crypto.createPublicKey(valid.ALIPAY_PRIVATE_KEY).export({type:'spki',format:'pem'}).toString();
  assert.throws(()=>validateProductionSettings(valid,origin),{message:'payment configuration unavailable'});
});

test('an explicitly approved Shanghai Function URL origin is accepted only by exact origin',()=>{
  // Synthetic hostname: the actual function address must be set after creating
  // and independently verifying that function, never taken from an HTTP event.
  const functionOrigin='https://abc123-fixture.ap-shanghai.tencentscf.com';
  const valid=settings();
  valid.BILLING_NOTIFY_URL=functionOrigin+'/api/billing/alipay/notify';
  valid.BILLING_RETURN_URL=functionOrigin+'/api/billing/alipay/return';
  const prepared=validateProductionSettings(valid,functionOrigin);
  assert.equal(prepared.notifyUrl,valid.BILLING_NOTIFY_URL);
  assert.equal(prepared.returnUrl,valid.BILLING_RETURN_URL);
  for(const bad of [functionOrigin+'.evil.example',functionOrigin+':8443','http://abc123-fixture.ap-shanghai.tencentscf.com']){
    assert.throws(()=>validateProductionSettings({...valid,BILLING_NOTIFY_URL:bad+'/api/billing/alipay/notify'},functionOrigin),{message:'payment configuration unavailable'});
  }
  assert.throws(()=>validateProductionSettings(valid,'https://another.ap-shanghai.tencentscf.com'),{message:'payment configuration unavailable'});
});
