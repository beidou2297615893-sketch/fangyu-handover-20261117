package com.jimusoft.randomhundred;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.text.Layout;
import android.text.StaticLayout;
import android.text.TextPaint;
import android.util.TypedValue;
import android.content.SharedPreferences;
import android.content.Intent;
import android.view.View;
import android.widget.*;
import org.json.*;
import java.util.*;
import java.security.SecureRandom;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.io.FileOutputStream;
import java.io.File;

/** Independent scoring: only this app's own submit button can change the score. */
public final class QuizActivity extends Activity {
  private JSONArray bank, round = new JSONArray(), optionOrder = new JSONArray();
  private int index, score;
  private LinearLayout body;
  private Button submit;
  private SharedPreferences prefs;
  private final Set<String> selected = new HashSet<>();
  private final SecureRandom random = new SecureRandom();
  private int dp(int n) { return Math.round(n * getResources().getDisplayMetrics().density); }
  @Override public void onCreate(Bundle state) {
    super.onCreate(state);
    getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
    try {
      try (InputStream input = getAssets().open("questions.json"); ByteArrayOutputStream bytes = new ByteArrayOutputStream()) {
        byte[] buffer = new byte[8192]; int count;
        while ((count = input.read(buffer)) != -1) bytes.write(buffer, 0, count);
        bank = new JSONArray(new String(bytes.toByteArray(), StandardCharsets.UTF_8));
      }
      prefs = getSharedPreferences("round", MODE_PRIVATE);
      if (getIntent().hasExtra("diagnosticIndex")) {
        showDiagnostic();return;
      }
      round = new JSONArray(prefs.getString("questions", "[]"));
      optionOrder = new JSONArray(prefs.getString("options", "[]"));
      index = prefs.getInt("index", 0); score = prefs.getInt("score", 0);
      render();
    } catch (Exception e) { throw new IllegalStateException("题库无法读取", e); }
  }
  @Override protected void onNewIntent(Intent intent) {
    super.onNewIntent(intent);
    if(!intent.hasExtra("diagnosticIndex"))throw new IllegalArgumentException("Only diagnostic retargeting is supported");
    setIntent(intent);
    try { showDiagnostic(); } catch(Exception e) { throw new IllegalStateException("只读题目无法加载",e); }
  }
  private void showDiagnostic()throws Exception {
    int diagnosticIndex=getIntent().getIntExtra("diagnosticIndex",-1);
    long seed=getIntent().getLongExtra("seed",20261105L);
    if(getIntent().getIntExtra("count",0)!=100 || diagnosticIndex<0 || diagnosticIndex>=100)
      throw new IllegalArgumentException("Invalid read-only diagnostic index");
    round=seededRound(100,seed);index=diagnosticIndex;score=0;shuffleOptions();render();
    body.post(()->{try(FileOutputStream out=new FileOutputStream(new File(getExternalFilesDir(null),"preflight-round.json"),false)) {
      out.write(new JSONObject().put("seed",seed).put("diagnosticIndex",diagnosticIndex).put("roundIndices",round).toString(2).getBytes(StandardCharsets.UTF_8));
      out.getFD().sync();
    } catch(Exception e) { throw new IllegalStateException("只读题目回执无法保存",e); }});
  }
  private void save() {
    if (!prefs.edit().putString("questions", round.toString()).putString("options", optionOrder.toString())
        .putInt("index", index).putInt("score", score).commit()) throw new IllegalStateException("答题记录未能保存");
  }
  private JSONObject question() { try { return bank.getJSONObject(round.getInt(index)); } catch (JSONException e) { throw new IllegalStateException(e); } }
  private void shuffleOptions() throws JSONException {
    if(getIntent().getIntExtra("count",0)==100) {
      optionOrder=new JSONArray(RoundRandom.options(question().getJSONArray("options").length(),getIntent().getLongExtra("seed",20261105L),index));
      return;
    }
    List<Integer> values = new ArrayList<>();
    for (int i = 0; i < question().getJSONArray("options").length(); i++) values.add(i);
    Collections.shuffle(values, random); optionOrder = new JSONArray(values);
  }
  private boolean usableSingle(JSONObject q) throws JSONException {
    if (!"single".equals(q.optString("type")) || q.getJSONArray("correctOptionIds").length()!=1 || q.getJSONArray("options").length()!=4) return false;
    Set<String> texts=new HashSet<>(), ids=new HashSet<>(); JSONArray options=q.getJSONArray("options");
    for(int i=0;i<options.length();i++) {
      JSONObject option=options.getJSONObject(i); String label=option.getString("text").trim();
      if(label.isEmpty() || !texts.add(label) || !ids.add(option.getString("id"))) return false;
    }
    return ids.contains(q.getJSONArray("correctOptionIds").getString(0));
  }
  private JSONArray seededRound(int count,long seed)throws JSONException {
    List<Integer> candidates=new ArrayList<>();
    for(int i=0;i<bank.length();i++)if(usableSingle(bank.getJSONObject(i)))candidates.add(i);
    return new JSONArray(RoundRandom.select(candidates,seed,count));
  }
  private void newRound() {
    try {
      int count = getIntent().getIntExtra("count", 0);
      if (count == 100) {
        round=seededRound(count,getIntent().getLongExtra("seed",20261105L));
      } else {
        round = new JSONArray(getIntent().getBooleanExtra("includeB27",false) ?
            java.util.Arrays.asList(8,9,204,205,1152) : java.util.Arrays.asList(8,9,204,205));
      }
      File evidence = new File(getExternalFilesDir(null), "progress.jsonl");
      try (FileOutputStream ignored = new FileOutputStream(evidence, false)) {} catch (Exception e) { throw new IllegalStateException(e); }
      try (FileOutputStream out = new FileOutputStream(new File(getExternalFilesDir(null), "round.json"), false)) {
        JSONObject record = new JSONObject().put("seed",getIntent().getLongExtra("seed",20261105L))
            .put("seeded",count==100).put("roundIndices",round);
        out.write(record.toString(2).getBytes(StandardCharsets.UTF_8));out.getFD().sync();
      } catch (java.io.IOException e) { throw new IllegalStateException(e); }
      index = 0; score = 0; shuffleOptions(); save(); render();
    } catch (JSONException e) { throw new IllegalStateException(e); }
  }
  private TextView text(String value, int size) {
    TextView t = new TextView(this); t.setText(value); t.setTextSize(size); t.setTextColor(Color.rgb(24, 35, 55));
    t.setPadding(dp(8), dp(10), dp(8), dp(10)); body.addView(t); return t;
  }
  private Button button(String value, Runnable action) {
    Button b = new Button(this); b.setText(value); b.setAllCaps(false); b.setOnClickListener(v -> action.run());
    body.addView(b, new LinearLayout.LayoutParams(-1, dp(60))); return b;
  }
  private int textHeight(String value,int sizeSp,int widthPx) {
    TextPaint paint=new TextPaint(android.graphics.Paint.ANTI_ALIAS_FLAG);
    paint.setTextSize(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP,sizeSp,getResources().getDisplayMetrics()));
    return StaticLayout.Builder.obtain(value,0,value.length(),paint,Math.max(1,widthPx)).setAlignment(Layout.Alignment.ALIGN_NORMAL)
        .setIncludePad(true).setBreakStrategy(Layout.BREAK_STRATEGY_SIMPLE).build().getHeight();
  }
  /** Size to fit all content while keeping every original question and answer visible. */
  private int[] alternateTextSizes(JSONObject q,JSONArray options)throws JSONException {
    int width=getResources().getDisplayMetrics().widthPixels;
    int availableHeight=getResources().getDisplayMetrics().heightPixels-dp(100);
    int bodyWidth=width-dp(65), stemWidth=bodyWidth-dp(16), labelWidth=bodyWidth-dp(42);
    for(int optionSize=22;optionSize>=12;optionSize--) {
      int stemSize=optionSize+2;
      int used=dp(65+32+60+20)+textHeight("100/100",22,stemWidth)
          +textHeight(q.getString("stem"),stemSize,stemWidth)+dp(20);
      for(int i=0;i<optionOrder.length();i++) {
        JSONObject option=options.getJSONObject(optionOrder.getInt(i));
        String label=(char)('A'+i)+". "+option.getString("text");
        used+=Math.max(dp(74),textHeight(label,optionSize,labelWidth)+dp(16));
      }
      if(used<=availableHeight || optionSize==12)return new int[]{stemSize,optionSize};
    }
    throw new IllegalStateException("无法计算文字布局");
  }
  private void accept() {
    if(getIntent().hasExtra("diagnosticIndex")) return;
    if (selected.isEmpty() || index >= round.length()) return;
    submit.setEnabled(false);
    try {
      Set<String> keys = new HashSet<>(); JSONArray ids = question().getJSONArray("correctOptionIds");
      for (int i = 0; i < ids.length(); i++) keys.add(ids.getString(i));
      boolean correct = selected.equals(keys);
      if (correct) score++;
      try (FileOutputStream out = new FileOutputStream(new File(getExternalFilesDir(null), "progress.jsonl"), true)) {
        JSONObject entry = new JSONObject().put("submitted", index + 1).put("total", round.length())
            .put("bankIndex", round.getInt(index)).put("optionOrder", optionOrder)
            .put("selected", new JSONArray(selected)).put("correctOptionIds", ids).put("correct", correct).put("score", score);
        out.write((entry.toString() + "\n").getBytes(StandardCharsets.UTF_8));
      } catch (java.io.IOException e) { throw new IllegalStateException(e); }
      index++; selected.clear(); if (index < round.length()) shuffleOptions(); save(); render();
    } catch (JSONException e) { throw new IllegalStateException(e); }
  }
  private void render() { try {
    selected.clear(); ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true);
    body = new LinearLayout(this); body.setOrientation(LinearLayout.VERTICAL);
    body.setPadding(dp(18), dp(36), dp(18), dp(32)); body.setBackgroundColor(Color.rgb(245, 248, 253));
    scroll.addView(body); setContentView(scroll);
    if (round.length() == 0) {
      text("随机百题", 28); text("1949 道题 · 每次随机抽取 100 道", 16);
      button("开始答题", this::newRound); return;
    }
    if (index >= round.length()) {
      text("答题已完成", 28); text("得分：" + score + " / " + round.length(), 26);
      text("已提交：" + index, 16); button("重新抽取 100 题", this::newRound); return;
    }
    final boolean alternate = getIntent().getBooleanExtra("alternate", false);
    final boolean phone = getIntent().getIntExtra("count", 0) == 100 && !alternate;
    scroll.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO_HIDE_DESCENDANTS);
    body.setBackgroundColor(alternate ? 0xff172431 : (phone ? 0xfff3f5f9 : 0xffffffff));
    if (alternate) body.setPadding(dp(40),dp(65),dp(25),dp(32));
    JSONObject q = question();
    if (phone) {
      LinearLayout card = new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL);
      card.setPadding(dp(16), dp(12), dp(16), dp(16));
      GradientDrawable background = new GradientDrawable(); background.setColor(Color.WHITE); background.setCornerRadius(dp(14));
      background.setStroke(dp(1), 0xffe1e4e9); card.setBackground(background);
      body.addView(card, new LinearLayout.LayoutParams(-1,-2)); body = card;
    }
    JSONArray options = q.getJSONArray("options");
    int[] sizes=alternate?alternateTextSizes(q,options):new int[]{24,phone?18:22};
    TextView progress = text((index + 1) + "/" + round.length(),22);
    TextView stem = text(q.getString("stem"),sizes[0]);
    if (alternate) { progress.setTextColor(0xffeeeeee); stem.setTextColor(0xffeeeeee); }
    for (int i=0;i<optionOrder.length();i++) {
      JSONObject option = options.getJSONObject(optionOrder.getInt(i)); String id = option.getString("id");
      LinearLayout row = new LinearLayout(this);
      row.setGravity(android.view.Gravity.CENTER_VERTICAL);
      LinearLayout.LayoutParams rowParams = new LinearLayout.LayoutParams(-1,(phone || alternate) ? -2 : dp(56));
      if(alternate)row.setMinimumHeight(dp(74));
      if (phone) { row.setMinimumHeight(dp(62)); rowParams.bottomMargin=dp(8); GradientDrawable border=new GradientDrawable(); border.setColor(Color.WHITE); border.setCornerRadius(dp(8)); border.setStroke(dp(1),0xffe1e4e9); row.setBackground(border); row.setPadding(dp(10),0,dp(8),0); }
      body.addView(row, rowParams);
      View indicator = new View(this) {
        final android.graphics.Paint paint = new android.graphics.Paint(3);
        @Override protected void onDraw(android.graphics.Canvas canvas) {
          float cx=getWidth()/2f,cy=getHeight()/2f;
          paint.setColor(alternate ? 0xffebeced : (phone ? 0xffdbdbdb : 0xff646464));
          paint.setStyle(android.graphics.Paint.Style.STROKE); paint.setStrokeWidth(phone ? getResources().getDisplayMetrics().density : dp(2));
          canvas.drawCircle(cx,cy,dp(phone ? 15 : 11),paint);
          if (selected.contains(id) && phone) {
            paint.setStyle(android.graphics.Paint.Style.FILL); paint.setColor(0xff2568ad); canvas.drawCircle(cx,cy,dp(15),paint);
            paint.setStyle(android.graphics.Paint.Style.STROKE); paint.setStrokeWidth(dp(2)); paint.setStrokeCap(android.graphics.Paint.Cap.ROUND); paint.setStrokeJoin(android.graphics.Paint.Join.ROUND); paint.setColor(Color.WHITE);
            android.graphics.Path tick=new android.graphics.Path(); tick.moveTo(cx-dp(7),cy); tick.lineTo(cx-dp(2),cy+dp(5)); tick.lineTo(cx+dp(8),cy-dp(6)); canvas.drawPath(tick,paint);
          } else if (selected.contains(id)) {
            paint.setStyle(android.graphics.Paint.Style.FILL);paint.setColor(alternate ? 0xffffdc73 : 0xff174f88);
            canvas.drawCircle(cx,cy,dp(4),paint);
          }
        }
      };
      row.addView(indicator,dp(phone ? 34 : 30),dp(phone ? 34 : 30));
      TextView label = new TextView(this);
      label.setText((char)('A'+i) + ". " + option.getString("text")); label.setTextSize(sizes[1]);
      label.setPadding(dp(12),(phone || alternate) ? dp(8) : 0,0,(phone || alternate) ? dp(8) : 0);label.setTextColor(alternate ? 0xffeeeeee : 0xff182337);
      if(phone || alternate) row.addView(label,new LinearLayout.LayoutParams(0,-2,1)); else row.addView(label);
      if(!getIntent().hasExtra("diagnosticIndex"))row.setOnClickListener(v -> {
        selected.clear();selected.add(id);
        for (int j=0;j<body.getChildCount();j++) {
          if(body.getChildAt(j) instanceof LinearLayout)
            ((LinearLayout)body.getChildAt(j)).getChildAt(0).invalidate();
        }
        submit.setEnabled(true);
      });
    }
    submit = button("确认答案",this::accept); submit.setEnabled(false);
  } catch (JSONException e) { throw new IllegalStateException(e); } }
}
