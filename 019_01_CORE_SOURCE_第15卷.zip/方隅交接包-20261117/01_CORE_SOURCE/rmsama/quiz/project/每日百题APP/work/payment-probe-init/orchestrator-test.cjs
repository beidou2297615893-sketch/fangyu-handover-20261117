'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict'),{run,FN,ENV,NAMES}=require('./orchestrator.cjs');
function fixture(variant='ok'){
 const calls=[],created=[],state={marked:false,updated:false,invoked:0,polls:0,delays:0};
 const old={functionId:'old',name:'translation',runtime:'Nodejs20.19',modifyTime:'1',status:'Active'},probe={functionId:'probe-id',name:FN,runtime:'Nodejs20.19',modifyTime:'2',status:'Active'};
 const route={domain:'old.invalid',path:'/translation',upstreamResourceName:'translation',upstreamResourceType:'function',enable:true,enableAuth:false,enablePathTransmission:true};
 const adapter={packageHash:'a'.repeat(64),async delay(ms){assert.equal(ms,1500);state.delays++},async getCodeHash(){if(variant==='wrong-original'&&!state.updated)return 'b'.repeat(64);if(variant==='wrong-new'&&state.updated)return 'b'.repeat(64);if(variant==='stale-forever'&&state.updated)return '242b95b3a43cc3f6ba4039f98b0b11c2f6927cb29a04407233db47c635b91485';return state.updated?'a'.repeat(64):'242b95b3a43cc3f6ba4039f98b0b11c2f6927cb29a04407233db47c635b91485'},async mark(){state.marked=true;calls.push('mark')},async updateCode(){calls.push('update');if(variant==='update-timeout')throw Error();state.updated=true;return {RequestId:'fake'}},async call(a){calls.push(a.slice(0,3).join(' '));
  if(a[0]==='fn'&&a[1]==='list')return [old,variant==='wrong-id'&&state.updated?{...probe,functionId:'different'}:probe];
  if(a[0]==='routes')return [state.updated&&variant==='old-route-changed'?{...route,path:'/changed'}:route];
  if(a.includes('DescribeTables')){const rows=(variant==='collection-conflict'?[NAMES[0]]:created).map(TableName=>({TableName}));return {Pager:{Total:variant==='incomplete'?100:rows.length},Tables:rows};}
  if(a.includes('GetFunction')){const status=state.updated&&variant==='updating'&&state.polls++<2?'Updating':'Active';return {FunctionName:FN,Namespace:ENV,Type:'Event',Runtime:'Nodejs20.19',Handler:'isolated-probe.main',Status:status,Role:variant==='wrong-role'?'wrong':'TCB_QcsRole',Environment:{Variables:[]}};}
  if(a.includes('ListTriggers'))return {TotalCount:variant==='trigger'?1:0};
  if(a.includes('CreateTable')){if(variant==='create-timeout')throw Error();const v=JSON.parse(a[a.indexOf('--body')+1]);assert.equal(v.PermissionInfo.AclTag,'ADMINONLY');created.push(v.TableName);return {RequestId:'fake'};}
  if(a[0]==='permission')return {PermissionList:[{Resource:a[2].split(':')[1],Permission:variant==='bad-acl'?'READONLY':'ADMINONLY'}]};
  if(a[0]==='fn'&&a[1]==='invoke'){state.invoked++;return {functionType:'Event',InvokeResult:0,RetMsg:JSON.stringify({initialized:true,paymentEnabled:false})};}
  throw Error('unexpected');
 }};return {adapter,calls,created,state};
}
test('only two admin collections and original probe are used',async()=>{const f=fixture();const r=await run(f.adapter);assert.deepEqual(f.created,NAMES);assert.equal(f.state.invoked,2);assert.equal(r.paymentEnabled,false);assert.equal(f.calls.filter(x=>x==='update').length,1);assert.ok(f.calls.indexOf('mark')<f.calls.indexOf('update'));});
test('conflicting target, bad metadata, role, original hash or trigger stops before any mutation',async()=>{for(const v of ['collection-conflict','incomplete','wrong-role','wrong-original','trigger']){const f=fixture(v);await assert.rejects(run(f.adapter));assert.equal(f.state.marked,false);assert.equal(f.state.updated,false);}});
test('uncertain write or bad ACL never updates function and is not retried',async()=>{for(const v of ['create-timeout','bad-acl']){const f=fixture(v);await assert.rejects(run(f.adapter));assert.equal(f.state.marked,true);assert.equal(f.state.updated,false);assert.equal(f.state.invoked,0);}});
test('uncertain code update, changed code hash, changed ID or old route never calls initializer',async()=>{for(const v of ['update-timeout','wrong-new','wrong-id','old-route-changed']){const f=fixture(v);await assert.rejects(run(f.adapter));assert.equal(f.state.marked,true);assert.equal(f.state.invoked,0);assert.equal(f.calls.filter(x=>x==='update').length,1);}});
test('asynchronous updating waits only for bounded readiness and a matching new code hash',async()=>{
 const f=fixture('updating');await run(f.adapter);assert.equal(f.state.delays,2);assert.equal(f.state.invoked,2);
 const stale=fixture('stale-forever');await assert.rejects(run(stale.adapter));assert.equal(stale.state.delays,7);assert.equal(stale.state.invoked,0);
});
