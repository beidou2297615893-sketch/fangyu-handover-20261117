import os, json, hashlib, zipfile, subprocess, re, xml.etree.ElementTree as ET
from pathlib import Path
R=Path('V:/work/original-vs-0419'); out=R/'release-checks'; project=Path('V:/work/tijing-bankassist')
mobile=R/'release-mobile/android/app/build/outputs/apk/prod/release/app-prod-release.apk'; universal=R/'release-universal/android/app/build/outputs/apk/prod/release/app-prod-release.apk'; qa=R/'regression-stage/app/build/outputs/apk/dev/debug/app-dev-debug.apk'
sha=lambda b: hashlib.sha256(b).hexdigest()
def filehash(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''): h.update(b)
 return h.hexdigest()
expected={'mobile':'e581837ab163211537c31a57c8ba84709fd917530cfe764f9cde2fd1cac91ec7','universal':'2144beeb981267ffd815d58075e608053f6e54d161c9bd6f853cc234c3ca4f42','qa':'d2d6fd6b97c4ad8222fa0b4db481e20af5b0e78ecd6ada886eb24e6613e773f6'}
result={'hashes':{k:filehash(p) for k,p in [('mobile',mobile),('universal',universal),('qa',qa)]}}
result['hashes_match']=result['hashes']==expected
audit=json.loads((R/'evidence-audit.json').read_text(encoding='utf-8'))
result['evidence_audit']={'qa_sha256':audit['fixedDiagnosticApk']['sha256'],'matches_current_qa':audit['fixedDiagnosticApk']['sha256']==result['hashes']['qa'],'fixed_unit_tests':audit['unitTests']['fixed']} 
sdk=Path('V:/work/tools/android-sdk/build-tools/35.0.0'); jdk=next(Path('V:/work/tools/jdk').glob('jdk-17*')); env=os.environ.copy(); env['JAVA_HOME']=str(jdk)
result['apk_info']={}
for name,p in [('mobile',mobile),('universal',universal)]:
 a=subprocess.run([str(sdk/'aapt.exe'),'dump','badging',str(p)],capture_output=True,text=True,encoding='utf-8',errors='replace',check=True).stdout
 v=subprocess.run([str(sdk/'apksigner.bat'),'verify','--verbose','--print-certs',str(p)],capture_output=True,text=True,encoding='utf-8',errors='replace',env=env,check=True).stdout
 pkg=next(x for x in a.splitlines() if x.startswith('package:')); native=next((x for x in a.splitlines() if x.startswith('native-code:')),'')
 dig=re.search(r'Signer #1 certificate SHA-256 digest: ([0-9a-fA-F]+)',v)
 result['apk_info'][name]={'package_line':pkg,'native_code':native,'cert_sha256':dig.group(1).lower() if dig else None,'verified':v.splitlines()[0:5]}
with zipfile.ZipFile(mobile) as m,zipfile.ZipFile(universal) as u,zipfile.ZipFile(qa) as q:
 ms=m.namelist(); us=u.namelist(); qs=q.namelist(); M=set(ms); U=set(us)
 common=M&U; changed=[]
 for n in sorted(common):
  if m.read(n)!=u.read(n): changed.append(n)
 onlym=sorted(M-U); onlyu=sorted(U-M)
 abi=lambda entries: sorted({n.split('/')[1] for n in entries if n.startswith('lib/') and len(n.split('/'))>=3})
 substantive=lambda n:not n.startswith('META-INF/')
 unexpected_missing=[n for n in onlyu if substantive(n) and not n.startswith(('lib/x86/','lib/x86_64/'))]
 result['zip']={'entries_mobile':len(ms),'entries_universal':len(us),'duplicates_mobile':sorted(n for n in M if ms.count(n)>1),'duplicates_universal':sorted(n for n in U if us.count(n)>1),'common_count':len(common),'changed_common':changed,'changed_non_meta_inf':[n for n in changed if substantive(n)],'only_mobile':onlym,'only_universal':onlyu,'unexpected_missing':unexpected_missing,'abis_mobile':abi(ms),'abis_universal':abi(us)}
 web=sorted(n for n in M if n.startswith('assets/web/') and not n.endswith('/'))
 result['web_qa']={'entries':web,'qa_missing':[n for n in web if n not in qs],'different':[n for n in web if n in qs and m.read(n)!=q.read(n)],'qa_extra':sorted(n for n in qs if n.startswith('assets/web/') and not n.endswith('/') and n not in web)}
rows=json.loads((R/'regression-source-manifest.json').read_text(encoding='utf-8')); main=project/'android/app/src/main/java'; stage=R/'regression-stage/app/src/diagnosticShared/java'; srcs={p.relative_to(main).as_posix():p for p in main.rglob('*.kt')}
manifest={x['path']:x for x in rows}; issues=[]
if set(srcs)!=set(manifest): issues.append({'main_vs_manifest':{'missing':sorted(set(manifest)-set(srcs)),'extra':sorted(set(srcs)-set(manifest))}})
for k,p in srcs.items():
 if k not in manifest: continue
 h=filehash(p)
 if h!=manifest[k]['sha256']: issues.append({'manifest_hash':k})
 for label in ('release-mobile','release-universal'):
  f=R/label/'android/app/src/main/java'/k
  if not f.exists() or f.read_bytes()!=p.read_bytes(): issues.append({label:k})
 if manifest[k]['shared']:
  f=stage/k
  if not f.exists() or f.read_bytes()!=p.read_bytes(): issues.append({'qa_shared':k})
for label in ('release-mobile','release-universal'):
 root=R/label/'android/app/src/main/java'; extra=sorted(p.relative_to(root).as_posix() for p in root.rglob('*.kt') if p.relative_to(root).as_posix() not in srcs)
 if extra: issues.append({label+'_extra':extra})
result['sources']={'main_count':len(srcs),'manifest_count':len(rows),'shared_count':sum(x['shared'] for x in rows),'excluded_replacements':[x['path'] for x in rows if not x['shared']],'issues':issues}
result['unit_tests']={}
for variant in ('ProdDebug','DevDebug'):
 folder=R/f'release-mobile/android/app/build/test-results/test{variant}UnitTest'; files=list(folder.glob('TEST-*.xml')); roots=[ET.parse(x).getroot() for x in files]; sums={k:sum(int(x.get(k,'0')) for x in roots) for k in ('tests','failures','errors','skipped')}; cases=[(x.get('classname'),x.get('name')) for root in roots for x in root.findall('testcase')]; result['unit_tests'][variant]={'files':len(files),**sums,'testcase_elements':len(cases),'unique_case_names':len(set(cases))}
result['frozen_input_sha256']={label:filehash(R/label/'build-source-input.json') for label in ('release-mobile','release-universal')}
result['pass']=(result['hashes_match'] and result['evidence_audit']['matches_current_qa'] and result['evidence_audit']['fixed_unit_tests']=={'tests':185,'failures':0,'errors':0,'skipped':0} and all("name='com.jimusoft.dailyhundredapp'" in x['package_line'] and "versionCode='87'" in x['package_line'] and "versionName='0.4.20'" in x['package_line'] and x['cert_sha256']=='fac61745dc0903786fb9ede62a962b399f7348f0bb6f899b8332667591033b9c' for x in result['apk_info'].values()) and result['zip']['abis_mobile']==['arm64-v8a','armeabi-v7a'] and result['zip']['abis_universal']==['arm64-v8a','armeabi-v7a','x86','x86_64'] and not result['zip']['duplicates_mobile'] and not result['zip']['duplicates_universal'] and not result['zip']['changed_non_meta_inf'] and not [n for n in result['zip']['only_mobile'] if not n.startswith('META-INF/')] and not result['zip']['unexpected_missing'] and len(web)==9 and not result['web_qa']['different'] and not result['web_qa']['qa_missing'] and not result['web_qa']['qa_extra'] and len(srcs)==40 and len(rows)==40 and sum(x['shared'] for x in rows)==38 and not issues and all(x['tests']==185 and x['testcase_elements']==185 and x['failures']==x['errors']==x['skipped']==0 for x in result['unit_tests'].values()) and all(x=='abda5cb0a8d952dbd88441c7241b84045b3908fb0a769edc0d2d19101d979e2e' for x in result['frozen_input_sha256'].values()))
(out/'result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(result,ensure_ascii=False,indent=2))
