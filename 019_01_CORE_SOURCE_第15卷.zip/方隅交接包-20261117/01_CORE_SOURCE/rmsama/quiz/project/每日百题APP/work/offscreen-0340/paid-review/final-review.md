# 0.3.40 付费滚动专项最终复核

结论：本次限定范围已无未解决阻塞。此前局部下一题恢复状态丢失问题已修复；本结论替代 review.md 中的修复前阻塞结论，原报告保留为历史证据。

冻结源码 GenericCoordinator.kt SHA256：15cd3692c7776bbde61d10fb23eb0b6787eb597b1d9b21d0b8de60e97efd1438。运行前与运行后均核对一致。

同文件104–112行先计算 restoreQuestion，并将 pendingNavigation、pendingAt、navigationFingerprint 与首回执 count+1 / pendingSubmit=false / pendingSubmissionId=null 放入同一次 save，关闭了结算异步返回前未保存恢复上下文的窗口。phase仍为reading，符合已有 PaidSubmissionGuard.validateReceipt。118行结算门禁之后才允许119行滚动；后续页面仍受93行门禁保护。returnStatus非空时不新建恢复导航或finding_next搜索，113–116行先结束只读核对。

原5项独立纯host组合复跑5/5通过（result.log、tested-source-hashes.json已更新）：真实提交身份与count跨滚动/Codec保持；门禁初始false的首Feedback只计一次；停止后带旧search核对全程无动作；真实PaidSubmissionGuard接收滚动后的首回执；旧快照fallback身份不变。

本次没有新增源码修改，没有设备/Android构建/服务器/真实支付操作。结论仅覆盖本次提交身份、计费回执门禁与停止后的只读边界；不替代最终APK连续100题设备验收或真实远端支付验收。
