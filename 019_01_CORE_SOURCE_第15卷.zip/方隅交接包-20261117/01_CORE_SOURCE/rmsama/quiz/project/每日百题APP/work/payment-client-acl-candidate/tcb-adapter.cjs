// Restricted TCB adapter. No credentials, SDK loading, network setup or live entry.
const ENV='fh6-d5ga45c0ddae7008c';
const isUid=u=>typeof u==='string'&&/^pa[a-f0-9]{32}$/.test(u);
const isName=n=>typeof n==='string'&&/^pa[a-f0-9]{16}$/.test(n);
const isDesc=d=>typeof d==='string'&&/^payment-acl:[a-f0-9]{32}$/.test(d);
function makeApi(client){
 if(!client||!['DescribeUserList','CreateUser','DeleteUsers'].every(k=>typeof client[k]==='function')) throw Error('unavailable');
 let confirmed=null, deletionAttempted=false;
 return Object.freeze({
  async find(uid){
   if(!isUid(uid))throw Error('invalid');
   const r=await client.DescribeUserList({EnvId:ENV,UidList:[uid],PageNo:1,PageSize:2});
   if(typeof r?.RequestId!=='string'||!r.RequestId||!Number.isInteger(r?.Data?.Total)||!Array.isArray(r?.Data?.UserList)||r.Data.Total!==r.Data.UserList.length||r.Data.Total>1||r.Data.UserList.some(u=>u.Uid!==uid))throw Error('unknown');
   return r.Data.UserList;
  },
  async create(x){
   if(!x||Object.keys(x).sort().join(',')!=='Description,Name,Password,Type,Uid,UserStatus'||!isUid(x.Uid)||!isName(x.Name)||!isDesc(x.Description)||!/^Aa1![A-Za-z0-9_-]{24}$/.test(x.Password)||x.Type!=='internalUser'||x.UserStatus!=='ACTIVE'||confirmed)throw Error('invalid');
   const r=await client.CreateUser({EnvId:ENV,Uid:x.Uid,Name:x.Name,Description:x.Description,Password:x.Password,Type:x.Type,UserStatus:x.UserStatus});
   if(typeof r?.RequestId!=='string'||!r.RequestId||r?.Data?.Uid!==x.Uid)throw Error('unknown');
   confirmed=x.Uid;return {Uid:confirmed};
  },
  async delete(ids){
   if(!confirmed||deletionAttempted||!Array.isArray(ids)||ids.length!==1||ids[0]!==confirmed)throw Error('invalid');
   deletionAttempted=true;
   const r=await client.DeleteUsers({EnvId:ENV,Uids:[confirmed]});
   if(typeof r?.RequestId!=='string'||!r.RequestId||r?.Data?.SuccessCount!==1||r?.Data?.FailedCount!==0)throw Error('unknown');
   return r.Data;
  }
 });
}
module.exports={makeApi};
