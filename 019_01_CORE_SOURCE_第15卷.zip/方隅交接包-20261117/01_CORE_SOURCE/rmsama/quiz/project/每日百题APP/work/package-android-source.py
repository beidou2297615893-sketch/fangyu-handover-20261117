"""Package reviewed project sources, never a developer machine or credentials."""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import hashlib
import json
import os
import argparse

arguments = argparse.ArgumentParser()
arguments.add_argument('--v2', action='store_true')
arguments.add_argument('--v21', action='store_true')
arguments.add_argument('--v22', action='store_true')
arguments.add_argument('--v30', action='store_true')
archive_args = arguments.parse_args()
version_two = archive_args.v2 or archive_args.v21 or archive_args.v22 or archive_args.v30
version_twenty_one = archive_args.v21 or archive_args.v22 or archive_args.v30
version_twenty_two = archive_args.v22 or archive_args.v30
version_thirty = archive_args.v30

project = Path(__file__).resolve().parent.parent
destination = project / ('outputs/手机安装包_v3.0/每日百题_直接安装版源码.zip' if version_thirty else 'outputs/手机安装包_v2.2/每日百题_直接安装版源码.zip' if version_twenty_two else 'outputs/手机安装包_v2.1/每日百题_直接安装版源码.zip' if version_twenty_one else 'outputs/手机安装包_v2/每日百题_通用版源码.zip' if version_two else 'outputs/每日百题_安卓雏形源码.zip')
destination.parent.mkdir(parents=True, exist_ok=True)
if destination.exists():
    raise SystemExit('Archive already exists; preserve or explicitly version it before repackaging.')

excluded_directories = {'.git', '.expo', '.agents', 'node_modules', 'build', 'dist',
                        '.gradle', '.cxx', '.kotlin', '.pytest_cache', '.venv', '__pycache__', 'classes', 'bank-classes',
                        'android-core-classes', 'android-syntax-classes', 'private-signing', 'private-gateway', 'private-state', 'gateway-venv', 'tools', 'gradle-home'}
excluded_files = {'local.properties', '.npmrc', 'signing.json', 'credentials.json', 'keystore.properties',
                  'source-archive-report.json', 'source-archive-inspection.json'}
binary_extensions = {'.apk', '.aab', '.class', '.jks', '.keystore', '.p12', '.pfx', '.pem', '.log', '.pyc', '.db', '.sqlite', '.sqlite3'}
selected = []

def include_file(file):
    resolved = file.resolve()
    if not resolved.is_relative_to(project) or file.is_symlink():
        raise RuntimeError(f'Unexpected source link: {file.name}')
    relative = file.relative_to(project)
    if any(part in excluded_directories or 'before-ascii-' in part or part.startswith('.cxx')
           or part.startswith('.gradle') for part in relative.parts):
        return
    if file.name in excluded_files or file.name.startswith('.env') or file.suffix.lower() in binary_extensions:
        return
    if file.suffix.lower() == '.jar' and relative.as_posix() != 'outputs/daily-hundred-app/android/gradle/wrapper/gradle-wrapper.jar':
        return
    selected.append((file, relative))

folders = ['outputs/daily-hundred-app', 'outputs/测试题库', 'outputs/界面设计',
           'work/mock-target-android', 'work/native-e2e', 'work/native-host-tests', 'work/fixtures']
if version_two:
    folders += ['work/mock-target-web-android', 'work/mock-target-native-android', 'work/implementation-v2/action-host', 'outputs/技术方案与开发计划']
if version_twenty_one:
    folders += ['work/implementation-v21']
if version_thirty:
    folders += ['work/generic-target-android']
for folder in folders:
    directory = project / folder
    for current, directories, files in os.walk(directory, followlinks=False):
        directories[:] = [name for name in directories if name not in excluded_directories
                          and 'before-ascii-' not in name and not name.startswith(('.cxx', '.gradle'))]
        for filename in files:
            include_file(Path(current) / filename)
for relative in ('work/android-build-env.ps1', 'work/build-android-release.ps1', 'work/prepare-android-build-alias.ps1',
                 'work/run-native-verification.ps1', 'work/package-android-source.py',
                 'work/finalize-android-evidence.py',
                 'work/final-android-verification.json',
                 'outputs/手机安装包/安装与人工复核说明.md', 'outputs/先看这里.md'):
    file = project / relative
    if file.exists():
        include_file(file)
if version_two:
    for relative in ('work/run-v2-verification.ps1', 'work/run-final-v2-device-suite.ps1', 'work/finalize-v2-delivery.py', 'work/run-automation-host-tests.ps1',
                     'work/implementation-v2/run-assist-host-tests.ps1', 'work/implementation-v2/run-screen-host-tests.ps1',
                     'work/implementation-v2/run-action-host-tests.ps1', 'work/implementation-v2/action-final-relocation-report.md',
                     'work/implementation-v2/NativeV2HostTest.kt', 'work/implementation-v2/ScreenHostTest.kt',
                     'work/sync-android-stage.ps1', 'work/technical-planning/2026-10-24-android-automation-implementation-plan.md',
                     'work/implementation-v2/integration-review.md', 'work/implementation-v2/native-fixture-route.md',
                     'work/implementation-v2/webview-checked-diagnosis.md', 'work/implementation-v2/provider-deadline-report.md',
                     'work/implementation-v2/dependency-audit-assessment.md', 'work/implementation-v2/automation-reuse-audit.md',
                     'outputs/手机安装包_v2/安装与人工复核说明.md', 'outputs/手机安装包_v2/测试范围与结果.md'):
        file = project / relative
        if file.exists():
            include_file(file)
    for folder in ('work/verification-v2',):
        for file in (project / folder).rglob('*.json'):
            include_file(file)
if version_twenty_one:
    for relative in ('work/technical-planning/2026-10-24-first-use-sampling-plan.md', 'work/finalize-v21-delivery.py', 'work/verify-v2-source-archive.py',
                     'outputs/手机安装包_v2.1/先看这里.md', 'outputs/手机安装包_v2.1/安装与人工复核说明.md',
                     'outputs/手机安装包_v2.1/测试范围与结果.md'):
        file = project / relative
        if file.exists():
            include_file(file)
    for file in (project / 'work/verification-v21').rglob('*.json'):
        include_file(file)
if version_twenty_two:
    for relative in ('work/UI功能衔接/LaunchReadinessTest.kt', 'work/UI功能衔接/test-launch.ps1',
                     'work/UI功能衔接/HANDOFF.md', 'work/UI功能衔接/复审结果.md',
                     'outputs/手机安装包_v2.2/先看这里.md', 'outputs/手机安装包_v2.2/测试范围与结果.md'):
        file = project / relative
        if file.exists():
            include_file(file)
    for file in (project / 'work/verification-v22').rglob('*.json'):
        include_file(file)
if version_thirty:
    for file in (project / 'work/通用答题').iterdir():
        if file.is_file() and file.suffix in ('.md', '.kt', '.ps1', '.py'):
            include_file(file)
    for file in (project / 'work/verification-v30').rglob('*.json'):
        include_file(file)
    for file in (project / 'outputs/手机安装包_v3.0').glob('*.md'):
        include_file(file)
for stage in ('workflow', 'interruptions', 'prepare-recovery', 'assert-recovery',
              'storage-failure', 'storage-abort', 'audit-failure'):
    include_file(project / 'work/android-e2e/device-evidence/native-verification' / (stage + '.json'))

manifest = []
with ZipFile(destination, 'x', ZIP_DEFLATED, compresslevel=6) as archive:
    for file, relative in sorted(selected, key=lambda item: item[1].as_posix()):
        data = file.read_bytes()
        archive.writestr('每日百题_安卓工程/' + relative.as_posix(), data)
        manifest.append({'path': relative.as_posix(), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
    archive.writestr('每日百题_安卓工程/源码说明.txt',
        '这是每日百题安卓工程的源码与测试材料，不包含SDK、JDK、依赖缓存、运行数据库或私钥。\n'
        '重新构建需准备官方Android构建环境、按锁文件安装依赖，并使用你自己的签名配置。\n'
        '主工程在outputs/daily-hundred-app；独立演练软件在work/mock-target-android；原生验证在work/native-e2e。\n'
        '原微信小程序与本轮之前的备份另行保留，没有被本压缩包覆盖。\n')
    archive.writestr('每日百题_安卓工程/源文件校验.json', json.dumps(manifest, ensure_ascii=False, indent=2))
with ZipFile(destination) as archive:
    failure = archive.testzip()
    if failure:
        raise RuntimeError('Archive CRC validation failed')
report = {'files': len(selected), 'bytes': destination.stat().st_size,
          'sha256': hashlib.sha256(destination.read_bytes()).hexdigest(), 'crcVerified': True}
(project / ('work/verification-v30/source-archive-report.json' if version_thirty else 'work/verification-v22/source-archive-report.json' if version_twenty_two else 'work/verification-v21/source-archive-report.json' if version_twenty_one else 'work/verification-v2/source-archive-report.json' if version_two else 'work/android-source-archive-report.json')).write_text(json.dumps(report, indent=2), encoding='utf-8')
print(json.dumps(report))
