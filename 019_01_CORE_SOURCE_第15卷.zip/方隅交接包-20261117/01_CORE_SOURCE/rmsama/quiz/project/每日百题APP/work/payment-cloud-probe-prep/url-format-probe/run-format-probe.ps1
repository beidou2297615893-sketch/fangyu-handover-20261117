param([switch]$Apply)
$ErrorActionPreference='Stop'
$envId='fh6-d5ga45c0ddae7008c'; $region='ap-shanghai'; $fn='dailyHundredUrlFormatProbeV1'
$tcb=(Get-Command tcb.ps1 -ErrorAction Stop).Source
$source=Join-Path $PSScriptRoot $fn; $config=Join-Path $PSScriptRoot 'cloudbaserc.json'
function CallJson([string[]]$arguments) {
  $raw=@(& $tcb @arguments --json 2>$null) -join "`n"; $code=$LASTEXITCODE
  $index=$raw.IndexOf('{'); $parsed=$null
  if($index -ge 0){try{$parsed=$raw.Substring($index)|ConvertFrom-Json}catch{}}
  if($code -ne 0 -or !$parsed -or !$parsed.data){throw '云操作结果不明确：停止并只读核查，不重试。'}
  return $parsed.data
}
function Functions() {
  $items=@(CallJson @('fn','list','-e',$envId,'--limit','100'))
  if($items.Count -ge 100){throw '函数列表可能不完整。'}
  return $items
}
function OtherFunctions($items) { return @($items|Where-Object {$_.name -ne $fn}|Sort-Object name|Select-Object functionId,name,runtime,modifyTime,status) }
function Routes() {
  $items=@(CallJson @('routes','list','-e',$envId,'--limit','100'))
  if($items.Count -ge 100){throw '路由列表可能不完整。'}
  return @($items|Sort-Object domain,path|Select-Object domain,path,upstreamResourceName,upstreamResourceType,enable,enableAuth,enablePathTransmission)
}
function AsJson($value) {return ConvertTo-Json -InputObject @($value) -Depth 8 -Compress}
function CheckUnchanged($funcs,$routes) {
  if((AsJson @(OtherFunctions @(Functions))) -cne $funcs -or (AsJson @(Routes)) -cne $routes){throw '既有函数或路由元数据发生变化，请只读核查。'}
}
function Triggers() {
  $body=@{FunctionName=$fn;Namespace=$envId;Limit=30;Offset=0}|ConvertTo-Json -Compress
  return CallJson @('api','scf','ListTriggers','-r',$region,'--api-version','2018-04-16','--body',$body)
}
$srcFile=Join-Path $source 'index.js'
if(@(Get-ChildItem -LiteralPath $source -Force).Count -ne 1){throw '探针目录含额外文件。'}
$expectedHash='5B4D3044D7A30300406EEC3973550BB7C3B105EFB02B5DC19A0BD331109BED0A'
if((Get-FileHash -Algorithm SHA256 -LiteralPath $srcFile).Hash -ne $expectedHash){throw '探针源码与已审核文件不一致。'}
$configData=Get-Content -Raw -LiteralPath $config|ConvertFrom-Json
if($configData.envId -ne $envId -or @($configData.functions).Count -ne 1 -or $configData.functions[0].name -ne $fn -or $configData.functions[0].handler -ne 'index.main' -or $configData.functions[0].runtime -ne 'Nodejs20.19' -or $configData.functions[0].installDependency -ne $false -or $configData.functions[0].memorySize -ne 128 -or $configData.functions[0].timeout -ne 5){throw '函数本地配置异常。'}
$before=@(Functions)
if(@($before|Where-Object {$_.name -eq $fn}).Count){throw '同名函数已存在；停止不覆盖。'}
$beforeFunctions=AsJson @(OtherFunctions $before); $beforeRoutes=AsJson @(Routes)
if(!$Apply){Write-Output '只读预检通过：没有同名函数。本次无云端修改。';return}
Write-Output '创建独立合成表单探针。'
Push-Location $PSScriptRoot
try {
  $out=@(& $tcb fn deploy $fn -e $envId --dir $source --runtime 'Nodejs20.19' --deployMode cos --config-file $config --json 2>$null) -join "`n"
  if($LASTEXITCODE -ne 0){throw '函数部署结果不明确：停止并只读核查。'}
} finally {Pop-Location}
$body=@{FunctionName=$fn;Namespace=$envId}|ConvertTo-Json -Compress
$detail=$null
for($i=0;$i -lt 15;$i++){
  $detail=CallJson @('api','scf','GetFunction','-r',$region,'--api-version','2018-04-16','--body',$body)
  if($detail -and $detail.Status -eq 'Active'){break};Start-Sleep -Seconds 2
}
if(!$detail -or $detail.Status -ne 'Active' -or $detail.FunctionName -ne $fn -or $detail.Namespace -ne $envId -or $detail.Type -ne 'Event' -or $detail.Runtime -ne 'Nodejs20.19' -or $detail.Handler -ne 'index.main' -or $null -eq $detail.Environment -or @($detail.Environment.Variables|Where-Object {$null -ne $_}).Count -gt 0){throw '函数状态或配置异常：停止并只读核查。'}
$empty=Triggers
if($empty.TotalCount -ne 0 -or @($empty.Triggers|Where-Object {$null -ne $_}).Count -ne 0){throw '新函数触发器列表异常。'}
CheckUnchanged $beforeFunctions $beforeRoutes
$desc=@{AuthType='NONE';NetConfig=@{EnableIntranet=$false;EnableExtranet=$true}}|ConvertTo-Json -Depth 4 -Compress
$request=@{FunctionName=$fn;TriggerName=$fn;Type='http';Namespace=$envId;Qualifier='$LATEST';Enable='OPEN';TriggerDesc=$desc}|ConvertTo-Json -Depth 5 -Compress
Write-Output '创建临时匿名公网 URL；如结果不明只读核查。'
[void](CallJson @('api','scf','CreateTrigger','-r',$region,'--api-version','2018-04-16','--body',$request))
$readback=Triggers
$entries=@($readback.Triggers|Where-Object {$null -ne $_})
if($readback.TotalCount -ne 1 -or $entries.Count -ne 1){throw '触发器数量异常：停止并只读核查。'}
$entry=$entries[0];$actualId=[string]$entry.TriggerName
if($actualId -notmatch '^[a-z0-9-]{4,100}$' -or $entry.Type -ne 'http' -or $entry.Qualifier -ne '$LATEST' -or $entry.Enable -ne 1){throw '触发器身份或状态异常：停止并只读核查。'}
try {$configUrl=$entry.TriggerDesc|ConvertFrom-Json; $uri=[Uri]$configUrl.NetConfig.ExtranetUrl}catch{throw '平台 URL 格式不明确：停止并只读核查。'}
$expectedHost='1439321968-'+$actualId+'.ap-shanghai.tencentscf.com'
if($configUrl.AuthType -ne 'NONE' -or $configUrl.NetConfig.EnableExtranet -ne $true -or $configUrl.NetConfig.EnableIntranet -ne $false -or $uri.Scheme -ne 'https' -or $uri.Host -ne $expectedHost -or !$uri.IsDefaultPort -or $uri.UserInfo -or $uri.Query -or $uri.Fragment -or $uri.AbsolutePath -ne '/') {throw 'URL 身份或配置异常：停止并只读核查。'}
$testError=$null;$testResults=$null
try {
  Add-Type -AssemblyName System.Net.Http
  $handler=New-Object System.Net.Http.HttpClientHandler; $handler.AllowAutoRedirect=$false
  $client=New-Object System.Net.Http.HttpClient($handler);$client.Timeout=[TimeSpan]::FromSeconds(10)
  try {
    $url='https://'+$uri.Host+'/__probe__/form'
    $msg=New-Object System.Net.Http.HttpRequestMessage((New-Object System.Net.Http.HttpMethod('POST')),$url)
    $msg.Content=New-Object System.Net.Http.StringContent('probe_id=fixture123&value=alpha%2Bbeta',[System.Text.Encoding]::UTF8,'application/x-www-form-urlencoded')
    [void]$msg.Headers.TryAddWithoutValidation('X-Probe-Fixture','fixture123')
    try {
      $response=$client.SendAsync($msg).GetAwaiter().GetResult()
      try {
        $resultBody=$response.Content.ReadAsStringAsync().GetAwaiter().GetResult()
        try{$result=$resultBody|ConvertFrom-Json}catch{throw 'HTTP 结果不是有效 JSON。'}
        if([int]$response.StatusCode -ne 200 -or $result.paymentEnabled -ne $false -or $result.checks.method -ne $true -or $result.checks.path -ne $true -or $result.checks.contentType -ne $true -or $result.checks.fixtureHeader -ne $true -or $result.checks.rawBody -ne $true){throw 'HTTP 请求结果未通过所有合成校验。'}
        $testResults=$result.checks
      } finally {$response.Dispose()}
    } finally {$msg.Dispose()}
  } finally {$client.Dispose();$handler.Dispose()}
} catch {$testError=$_.Exception.Message}
# Identity was read back and verified above; remove only this new trigger once.
try {
  $remove=@{FunctionName=$fn;TriggerName=$actualId;Type='http';Namespace=$envId;Qualifier='$LATEST'}|ConvertTo-Json -Compress
  [void](CallJson @('api','scf','DeleteTrigger','-r',$region,'--api-version','2018-04-16','--body',$remove))
} catch {throw '测试 URL 删除结果不明确：停止并只读核查，不重试。'}
$after=Triggers
if($after.TotalCount -ne 0 -or @($after.Triggers|Where-Object {$null -ne $_}).Count -ne 0){throw '删除后触发器未确认清空：停止并只读核查。'}
CheckUnchanged $beforeFunctions $beforeRoutes
if($testError){throw "已确认测试 URL 移除，表单验证未通过：$testError"}
[pscustomobject]@{paymentEnabled=$false;formCheck=$testResults;urlRemoved=$true;functionRetained=$true;existingFunctionsAndRoutesUnchanged=$true}|ConvertTo-Json -Depth 5 -Compress
