from pathlib import Path
p=Path('V:/work/original-vs-0419/write-comparison-report.py')
s=p.read_text(encoding='utf-8')
a=s.index("section=f'''# 2026-11-14")
b=s.index('handoff=project/',a)
replacement="""section=(r/'handoff-current-template.md').read_text(encoding='utf-8')
for key,value in {'STAMP':stamp,'NATURAL_FOLDER':folder.name,'NATURAL_STATUS':status,'QA_SHA':audit['fixedDiagnosticApk']['sha256']}.items():
    section=section.replace('$'+key+'$',value)
"""
p.write_text(s[:a]+replacement+s[b:],encoding='utf-8')
