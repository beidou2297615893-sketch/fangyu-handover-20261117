# 0.3.40 付费提交与滚动专项只读审查

结论：发现一项自动换题恢复阻塞，与独立流程审查者交叉确认；在本次审查范围内未发现新增重复扣费、提交身份被滚动覆盖或停止后只读核对执行动作的问题。源码未修改。

## 应修复

GenericCoordinator.kt:106–115：首次提交回执以 Unknown + next ordinal + incompleteLayout 表达时，先持久化 count=1/pendingSubmit=false/viewportSearch=null；mayAdvanceAfterReceipt() 因异步结算尚未完成返回 false，后面的 pendingNavigation 恢复状态尚未保存。结算完成后同一局部页面不再进入 pendingSubmit 分支，而会在 Unknown 分支暂停，无法自动滚回下一题顶部。独立流程审查者已纯host复现：首拍 count=1, pendingNavigation=false, viewportSearch=null；放行后第二拍 paused。影响自动续答，不是重复计费。

建议把局部下一题的恢复意图纳入首回执同一次事实持久化，动作仍在结算门禁之后；保留 receiptCheckReturnStatus 的只读返回及窗口绑定。

## 已核对

- GenericCoordinator.intent 仅 purpose=submit 写 pendingSubmissionId；scroll 使用新UUID且保留真实提交ID/count/pendingAt。
- NativeTaskEngine.persistPaidGeneric 仅真正submit记录 paidPendingIntentId/savePaidSubmissionIntent；scroll走普通save。
- beforePaidDispatch 对scroll不重复markPaidSubmissionDispatched；rejectedPaidDispatch比较真实pending ID，拒绝scroll不能撤销原提交dispatch。
- 首回执清pending且增count一次，TaskDatabase事务与PaidSubmissionGuard仍约束首回执转换；PaidRunGate通过同run/owner/binding及generation放行。
- 任意首回执之后的next/scroll路径均受mayAdvanceAfterReceipt限制；此次阻塞来自状态保存排序，并非门禁绕过。
- stopped/paused receiptCheckReturnStatus在回执未出现时只读；出现时返回原停止/暂停状态，未生成后续动作。
- RunCodec附加viewportSearch，旧快照仍可解码；ActionIntent未作为重启待重放动作持久化，legacy默认未形成可达的漏标付费提交路径。

## 独立纯host验证

5/5通过，使用本次实际GenericCoordinator、RunModels、RunCodec及PaidSubmissionGuard源文件编译；源hash见tested-source-hashes.json，输出见result.log：

1. 连续查回执滚动及Codec往返不改真实submission ID/count；重启保持暂停。
2. 首次Feedback回执时门禁初始关闭，count只增一次；放行前无动作，放行后next。
3. 已滚动后停止，带旧search快照重新checkReceipt，整个核对仅读，仍返回stopped。
4. 查回执滚动保留submitting phase，首回执可通过真实PaidSubmissionGuard。
5. 旧快照缺pendingSubmissionId/viewportSearch仍保持稳定fallback身份。

## 范围与局限

未测试真实支付、远端结算、SQLite运行故障或Android手势；没有设备/构建/服务器/发布操作。普通识别准确率、100题设备验收和发布渠道由主任务其他步骤覆盖。本次仅审新增滚动与付费提交、回执门禁和停止边界，不作全产品零缺陷判断。报告记录的是修复前审查结果；后续修复须单独核对源hash与验证结果。
