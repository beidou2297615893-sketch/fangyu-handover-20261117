'use strict';
const crypto=require('node:crypto');
const ENV='fh6-d5ga45c0ddae7008c',HOST=ENV+'.ap-shanghai.tcb-api.tencentcloudapi.com';
function ids(owner,requestId){if(!/^i49[a-f0-9]{30}$/.test(owner)||!/^[A-Za-z0-9_-]{8,64}$/.test(requestId))throw Error('unavailable');const sha=x=>crypto.createHash('sha256').update(x).digest('hex'),order='o'+sha(JSON.stringify([owner,requestId])).slice(0,63);return {order,requestId,doc:'order-'+order,grant:'grant-'+order,account:'account-'+sha(owner)};}
function allowed(opts,ids){try{const u=new URL(opts.url),p=opts.body;if(u.protocol!=='https:'||u.hostname!==HOST||u.port||u.username||u.password||u.pathname!=='/admin'||u.hash||u.searchParams.getAll('env').length!==1||u.searchParams.get('env')!==ENV||u.searchParams.getAll('seqId').length>1||[...u.searchParams.keys()].some(x=>!['env','seqId'].includes(x))||opts.method!=='post'||opts.proxy||opts.keepalive||opts.formData!==undefined||opts.qs!==undefined||opts.agent!==undefined||!p||p.envName!==ENV||p.action!=='database.getDocument'||p.collectionName!=='daily_hundred_payment_v1'||p.multi!==false)return false;return [ids.doc,ids.grant,ids.account].some(id=>p.query===JSON.stringify({_id:id}))}catch{return false}}
function evaluate(order,grant,owner,ids,account){
 if(order===null&&grant===null)return {status:'not-created',amountFen:null,grantCount:0};
 if(!order||order._id!==ids.doc||order.kind!=='order'||order.orderId!==ids.order||order.owner!==owner||order.requestId!==ids.requestId||order.plan!=='once'||order.amountFen!==100||!['pending','paid','cancelled','review','refunded'].includes(order.status))throw Error('unavailable');
 if(grant!==null&&(!grant||grant._id!==ids.grant||grant.kind!=='grant'||grant.orderId!==ids.order||grant.owner!==owner||grant.plan!=='once'||!['paid','review','refunded'].includes(grant.state)||grant.credits!==1||grant.days!==0||typeof grant.tradeNo!=='string'||!/^[A-Za-z0-9_-]{1,64}$/.test(grant.tradeNo)||!Number.isSafeInteger(grant.grantedAt)||grant.grantedAt<0||!Number.isSafeInteger(grant.used)||!Number.isSafeInteger(grant.reserved)||grant.used<0||grant.reserved<0||grant.used+grant.reserved>1))throw Error('unavailable');
 if(order.status==='paid'&&grant?.state!=='paid')throw Error('unavailable');
 if(['pending','cancelled'].includes(order.status)&&grant!==null)throw Error('unavailable');
 if(grant?.state==='paid'){
  if(!account||account._id!==ids.account||account.kind!=='account'||account.schema!==2||account.owner!==owner||!Number.isSafeInteger(account.creditAvailable)||!Number.isSafeInteger(account.creditReserved)||account.creditAvailable<0||account.creditReserved<0)throw Error('unavailable');
  const available=1-grant.used-grant.reserved;if(account.creditAvailable<available||account.creditReserved<grant.reserved)throw Error('unavailable');
  if(available===1&&account.creditAvailable===1&&(account.creditHead!==ids.order||account.creditTail!==ids.order))throw Error('unavailable');
  return {status:order.status,amountFen:order.amountFen,grantCount:1,available,used:grant.used,reserved:grant.reserved};
 }
 return {status:order.status,amountFen:order.amountFen,grantCount:0,available:0,used:0,reserved:0};
}
module.exports={ids,allowed,evaluate};
