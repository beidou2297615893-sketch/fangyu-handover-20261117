package com.jimusoft.paymentcastest;
import android.app.Service;
import android.content.Intent;
import android.os.*;
import org.json.JSONObject;
public final class Worker extends Service {
 private final Messenger messenger=new Messenger(new Handler(Looper.getMainLooper()){
  @Override public void handleMessage(Message message){
   Bundle out=new Bundle();try{
    Bundle in=message.getData();CandidateStore store=new CandidateStore(Worker.this,in.getString("case"));
    if(message.what==1){JSONObject r=store.read();out.putString("record",r==null?null:r.toString());out.putInt("pid",android.os.Process.myPid());}
    else if(message.what==2)out.putBoolean("accepted",store.compareAndSet(in.getLong("version"),new JSONObject(in.getString("value"))));
    else throw new IllegalArgumentException("command");
   }catch(Exception e){out.putString("error",e.toString());}
   try{Message response=Message.obtain();response.setData(out);message.replyTo.send(response);}catch(RemoteException ignored){}
  }
 });
 @Override public IBinder onBind(Intent intent){return messenger.getBinder();}
}
