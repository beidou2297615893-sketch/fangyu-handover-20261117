'use strict';
// CLI adapter for the reviewed plan. All arguments and target resources are
// produced by orchestrator.cjs. No arbitrary resource names or credentials.
const fs=require('node:fs'),path=require('node:path'),os=require('node:os'),crypto=require('node:crypto'),{spawnSync}=require('node:child_process');
const {run}=require('./orchestrator.cjs');
const {create,guardedTransport}=require('./tcb-create.cjs');
for(const name of ['log','info','warn','error','debug','trace'])console[name]=()=>{};
const root=__dirname,source=path.join(root,'dailyHundredBillingInitV1'),config=path.join(root,'cloudbaserc.json'),marker=path.join(root,'initialization-attempted.lock'),archive=path.join(root,'initializer-package.zip');
// The execution identity for a directly-created function has not yet been
// verified in the target environment. Keep every write path closed until an
// independent, scoped role audit and end-to-end dry run resolve this.
const VERIFIED_EXECUTION_ROLE=false;
const fail=()=>{throw Error('unavailable')};
function hash(file){return crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex')}
function files(dir){const out=[];function walk(folder,base){for(const e of fs.readdirSync(folder,{withFileTypes:true})){
  const f=path.join(folder,e.name),rel=path.join(base,e.name);if(e.isSymbolicLink())fail();if(e.isDirectory())walk(f,rel);else if(e.isFile())out.push(rel);else fail();
}}walk(dir,'');return out.sort()}
function audit(){
  if(!VERIFIED_EXECUTION_ROLE)fail();
  if(process.argv.length!==3||process.argv[2]!=='--apply'||!process.env.BILLING_INIT_TCB||fs.existsSync(marker))fail();
  if(['NODE_OPTIONS','NODE_DEBUG','DEBUG','NODE_EXTRA_CA_CERTS','SSL_CERT_FILE','SSL_CERT_DIR','HTTP_PROXY','HTTPS_PROXY','ALL_PROXY','http_proxy','https_proxy','all_proxy','NODE_TLS_REJECT_UNAUTHORIZED'].some(k=>process.env[k])||process.execArgv.length)fail();
  if(hash(path.join(root,'policy-init.cjs'))!==hash(path.join(source,'policy-init.cjs')))fail();
  const pack=JSON.parse(fs.readFileSync(path.join(source,'package.json'),'utf8')),cfg=JSON.parse(fs.readFileSync(config,'utf8'));
  if(pack.dependencies?.['@cloudbase/node-sdk']!=='3.18.7'||cfg.envId!=='fh6-d5ga45c0ddae7008c'||cfg.functions?.length!==1||cfg.functions[0].name!=='dailyHundredBillingInitV1'||cfg.functions[0].runtime!=='Nodejs20.19'||cfg.functions[0].handler!=='index.main'||cfg.functions[0].envVariables!==undefined)fail();
  const ref=path.resolve(root,'../payment-cloud-probe-prep/dailyHundredPaymentProbeV1/node_modules'),stage=path.join(source,'node_modules'),a=files(ref),b=files(stage);
  if(JSON.stringify(a)!==JSON.stringify(b))fail();for(const f of a)if(hash(path.join(ref,f))!==hash(path.join(stage,f)))fail();
  for(const f of files(source))if(/(?:^|[\\/])(?:\.env(?:\..*)?|credentials?\.json|[^\\/]*private[^\\/]*\.(?:pem|key))$/i.test(f))fail();
}
function pwsh(){return path.join(os.homedir(),'.cache','codex-runtimes','codex-primary-runtime','dependencies','native','powershell','pwsh.exe')}
function prepareCreateOnly(){
  // The archive contains checked public code/dependencies only, not merchant
  // credentials; no force-overwrite, and its bytes never appear on argv.
  const p=spawnSync(pwsh(),['-NoProfile','-NonInteractive','-File',path.join(root,'archive.ps1'),'-Source',source,'-Archive',archive],{encoding:'utf8',timeout:120000,windowsHide:true});
  if(p.status!==0||p.error)fail();const stat=fs.statSync(archive);if(!stat.isFile()||stat.size<1||stat.size>20*1024*1024)fail();
  const auth=JSON.parse(fs.readFileSync(path.join(os.homedir(),'.config','.cloudbase','auth.json'),'utf8')),c=auth.credential||{};
  const secretId=c.secretId||c.tmpSecretId,secretKey=c.secretKey||c.tmpSecretKey,token=c.token||c.tmpToken,expiry=c.accessTokenExpired||c.tmpExpired;
  if(typeof secretId!=='string'||typeof secretKey!=='string'||typeof token!=='string'||!Number.isFinite(Number(expiry))||Number(expiry)<=Date.now()+120000)fail();
  const sdkRoot=path.join(root,'sdk-tcb/node_modules'),http=require(path.join(sdkRoot,'tencentcloud-sdk-nodejs-common/tencentcloud/common/http/fetch'));
  http.default=guardedTransport(http.default);
  const Client=require(path.join(sdkRoot,'tencentcloud-sdk-nodejs-tcb')).tcb.v20180608.Client;
  const client=new Client({credential:{secretId,secretKey,token},region:'ap-shanghai',profile:{httpProfile:{endpoint:'tcb.tencentcloudapi.com',reqTimeout:15,protocol:'https://'}}});
  return async()=>create(client,fs.readFileSync(archive));
}
function call(args){
  const p=spawnSync(pwsh(),['-NoProfile','-NonInteractive','-File',process.env.BILLING_INIT_TCB,...args,'--json'],{cwd:root,encoding:'utf8',timeout:45000,maxBuffer:2*1024*1024,windowsHide:true});
  if(p.status!==0||p.error)fail();const at=(p.stdout||'').indexOf('{');if(at<0)fail();let obj;try{obj=JSON.parse(p.stdout.slice(at))}catch{fail()};
  if(!Object.hasOwn(obj,'data')||obj.data===null)fail();return obj.data;
}
(async()=>{try{audit();const createFunction=prepareCreateOnly();const result=await run({call,createFunction,mark:async()=>{const fd=fs.openSync(marker,'wx');try{fs.writeFileSync(fd,'attempted');fs.fsyncSync(fd)}finally{fs.closeSync(fd)}}});process.stdout.write(JSON.stringify(result)+'\n');}
catch{process.stdout.write('{"initialized":false,"paymentEnabled":false,"retryAllowed":false}\n');process.exitCode=2;}})();
