'use strict';
// Preserves the original diagnostic entry, and adds only fixed disabled-policy
// operations. Never expose this IAM-only function through an HTTP trigger.
const original=require('./diagnostic-original.js'),{createPolicyInitializer}=require('./policy-init.cjs');
function makeMain(diagnostic,dbFactory){return async event=>{
  if(event&&typeof event==='object'&&!Array.isArray(event)&&Object.keys(event).join(',')==='action'&&event.action==='diagnostic')return diagnostic(event);
  if(!event||typeof event!=='object'||Array.isArray(event)||Object.keys(event).join(',')!=='action'||!['initialize-disabled-policy','verify-disabled-policy'].includes(event.action))return {initialized:false,paymentEnabled:false};
  try{return await createPolicyInitializer(await dbFactory())(event);}catch{return {initialized:false,paymentEnabled:false};}
};}
exports.makeMain=makeMain;
exports.main=makeMain(original.main,async()=>{const sdk=require('@cloudbase/node-sdk'),app=sdk.init({env:sdk.SYMBOL_CURRENT_ENV});return app.database({throwOnCode:true,timeout:2500});});
