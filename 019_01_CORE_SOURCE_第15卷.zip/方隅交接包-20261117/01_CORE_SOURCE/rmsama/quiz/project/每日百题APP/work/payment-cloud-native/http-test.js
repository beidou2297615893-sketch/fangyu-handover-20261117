'use strict';
const {test,before,after}=require('node:test'),assert=require('node:assert/strict'),http=require('node:http');
const {createOfflineService,createProductionService}=require('./http-service');
let service,server,origin;
before(async()=>{
  service=createOfflineService();server=http.createServer(service.handler);
  await new Promise((resolve,reject)=>server.once('error',reject).listen(0,'127.0.0.1',resolve));
  origin='http://127.0.0.1:'+server.address().port;
});
after(async()=>{if(server)await new Promise(resolve=>server.close(resolve));if(service)service.close();});
async function post(path,body,token){return fetch(origin+path,{method:'POST',headers:{'content-type':'application/json',...(token?{authorization:'Bearer '+token}:{})},body:JSON.stringify(body)});}
async function get(path,token){return fetch(origin+path,{headers:{authorization:'Bearer '+token}});}
test('production stays closed even if configured',()=>assert.throws(()=>createProductionService({enabled:true})));
test('order uses authenticated owner and fixed server price, with stable idempotency',async()=>{
  const {alice,bob}=service.credentials;
  assert.equal((await post('/orders',{planId:'once',clientRequestId:'one'})).status,401);
  const first=await post('/orders',{planId:'once',clientRequestId:'one'},alice);assert.equal(first.status,201);
  const row=await first.json();assert.equal(row.amountFen,100);
  const retry=await (await post('/orders',{planId:'once',clientRequestId:'one'},alice)).json();assert.equal(retry.id,row.id);
  assert.equal((await get('/orders/'+row.id,bob)).status,404);
  assert.equal((await post('/orders',{planId:'once',clientRequestId:'forged',amountFen:1},alice)).status,400);
  assert.equal((await post('/orders',{planId:'once',clientRequestId:'forged',verified:true},alice)).status,400);
  const duplicate=await fetch(origin+'/orders',{method:'POST',headers:{'content-type':'application/json',authorization:'Bearer '+alice},body:'{"planId":"once","clientRequestId":"x","clientRequestId":"y"}'});
  assert.equal(duplicate.status,400);
});
test('signed notification and service-side query grant owner once; client cannot supply query',async()=>{
  const {alice,bob}=service.credentials;
  const order=await (await post('/orders',{planId:'once',clientRequestId:'pay'},alice)).json();
  service.prepareQuery(service.makeQuery({out_trade_no:order.id,trade_no:'trade-pay'}));
  const notice=service.makeNotice({out_trade_no:order.id,trade_no:'trade-pay'});
  const notify=()=>fetch(origin+'/alipay/notify',{method:'POST',headers:{'content-type':'application/x-www-form-urlencoded'},body:notice});
  assert.equal(await (await notify()).text(),'success');assert.equal(await (await notify()).text(),'success');
  assert.equal((await (await get('/orders/'+order.id,alice)).json()).status,'paid');
  assert.equal((await (await post('/orders',{planId:'once',clientRequestId:'pay'},alice)).json()).status,'paid');
  assert.equal((await get('/orders/'+order.id,bob)).status,404);
  assert.equal(service.snapshot().grants.filter(g=>g.orderId===order.id).length,1);
  assert.equal((await post('/alipay/notify',{verified:true},alice)).status,400);
});
test('signed but mismatched query does not open the order',async()=>{
  const {alice}=service.credentials,order=await (await post('/orders',{planId:'once',clientRequestId:'not-paid'},alice)).json();
  service.prepareQuery(service.makeQuery({out_trade_no:order.id,trade_no:'wrong'}));
  const r=await fetch(origin+'/alipay/notify',{method:'POST',headers:{'content-type':'application/x-www-form-urlencoded'},body:service.makeNotice({out_trade_no:order.id,trade_no:'expected'})});
  assert.equal(r.status,400);assert.equal((await (await get('/orders/'+order.id,alice)).json()).status,'pending');
});
