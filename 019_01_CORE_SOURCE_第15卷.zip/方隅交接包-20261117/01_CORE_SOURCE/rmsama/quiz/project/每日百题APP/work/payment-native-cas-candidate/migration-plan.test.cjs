'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const {planMigration}=require('./migration-plan');
const ident=JSON.stringify({installationId:'owner-a',accessToken:'A'.repeat(43),purchaseIntent:{planId:'once',clientRequestId:'request-1'}});
const pending=JSON.stringify([{id:'order-1',planId:'once',amountFen:100,clientRequestId:'request-1'}]);
const registration=JSON.stringify({requestId:'R'.repeat(43),verifier:'V'.repeat(43)});
test('exact old identity, pending orders and registration remain unchanged in candidate',()=>{
 const out=planMigration({identity:ident,pending,registration});
 assert.deepEqual(out.legacyRaw,{identity:ident,pending,registration});
 assert.equal(out.next.identity.purchaseIntent.clientRequestId,'request-1');
 assert.equal(out.next.pending[0].id,'order-1');assert.equal(out.next.registration.requestId,'R'.repeat(43));
});
test('brand new device with no files remains a valid empty record',()=>{
 const out=planMigration({identity:null,pending:null,registration:null});
 assert.deepEqual(out.next,{identity:null,pending:[],registration:null});
 assert.deepEqual(out.legacyRaw,{identity:null,pending:null,registration:null});
});
test('corrupted or inconsistent legacy payload is refused without modifying the input',()=>{
 for(const input of [
  {identity:'{bad',pending,registration},
  {identity:ident,pending:'{}',registration},
  {identity:'{}',pending,registration},
  {identity:ident,pending,registration:'{"requestId":"bad"}'},
  {identity:null,pending,registration},
 ]){const before=structuredClone(input);assert.throws(()=>planMigration(input));assert.deepEqual(input,before);}
});
test('additional existing identity fields are preserved, not silently truncated',()=>{
 const raw=JSON.stringify({...JSON.parse(ident),futureField:'must-preserve'});
 const out=planMigration({identity:raw,pending,registration});assert.equal(out.next.identity.futureField,'must-preserve');assert.equal(out.legacyRaw.identity,raw);
});
