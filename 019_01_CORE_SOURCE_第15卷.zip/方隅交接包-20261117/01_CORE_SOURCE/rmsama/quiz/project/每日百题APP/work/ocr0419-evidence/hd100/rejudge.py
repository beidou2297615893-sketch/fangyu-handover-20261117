from pathlib import Path
import subprocess, os
repo=Path("V:/work/tijing-bankassist"); out=Path(__file__).parent;parent=out.parent
cache=Path("V:/work/gradle-home/caches/modules-2/files-2.1")
def jar(g,a,v="*"):
    return str(next((cache/g/a).glob(v+"/*/"+a+"-*.jar")))
stdlib=jar("org.jetbrains.kotlin","kotlin-stdlib","2.0.21")
compiler=[jar("org.jetbrains.kotlin",a,v) for a,v in [("kotlin-compiler-embeddable","2.0.21"),("kotlin-script-runtime","2.0.21"),("kotlin-daemon-embeddable","2.0.21"),("kotlin-reflect","1.6.10")]]+[stdlib,jar("org.jetbrains.intellij.deps","trove4j"),jar("org.jetbrains.kotlinx","kotlinx-coroutines-core-jvm"),jar("org.jetbrains","annotations")]
cp=["V:/work/tijing-bankassist/android/app/src/main/resources",stdlib,jar("com.google.code.gson","gson","2.10.1"),jar("junit","junit","4.13.2"),jar("org.hamcrest","hamcrest-core"),jar("org.json","json","20180813"),"V:/work/tools/android-sdk/platforms/android-35/android.jar"]
java=str(next(Path("V:/work/tools/jdk").glob("*/bin/java.exe")))
main=repo/"android/app/src/main/java/com/futureyyy/tijing"
test=repo/"android/app/src/test/java/com/futureyyy/tijing"
files=[main/(s+".kt") for s in ["QuizRuntimeConfig","QuizModelParser","LocalQuestionBank","QuestionBankResponseAdapter"]]+[parent/"Context.kt",parent/"QuestionBankStore.kt",main/"QuizRunCoordinator.kt",main/"CaptureFrame.kt",main/"OcrHostPage.kt",out/"HdAudit.kt"]
files.extend([test/"LocalBankVisionTest.kt",test/"VisibleQuestionReaderTest.kt",main/"VisibleQuestionReader.kt"]);dest=str(out/"ondevice-audit.jar")
subprocess.run([java,"-Dfile.encoding=UTF-8","-cp",";".join([dest,*cp]),"com.futureyyy.tijing.HdAuditKt"],check=True)






