from pathlib import Path
import json,numpy as np
from PIL import Image
import cv2
p=Path("V:/work/ocr0419-evidence/hd100");a=json.loads((p/"replay-manifest.json").read_text());r=a["rows"][-1];s=Image.open(r["sourcePath"]).convert("L");w,h=s.size
targets=[z for q in json.loads((p/"replay-paddle.json").read_text()) if "q20-" in q["file"] for z in q["lines"] if z["box"][1]>36]
for line in targets:
 x,y,b,c=line["box"];crop=np.asarray(s.crop((int(x*w/100)-3,int(y*h/100)-3,int((x+b)*w/100)+3,int((y+c)*h/100)+3)))
 dark=(crop<140).astype("uint8");count,labels,stats,ctr=cv2.connectedComponentsWithStats(dark);parts=[]
 for i in range(1,count):
  x0,y0,bw,bh,area=stats[i]
  if area>6: parts.append((int(x0),int(bw),int(y0),int(bh),int(area),round(area/(bw*bh),2)))
 print(line["text"],parts)

