const { chromium } = require('C:/Users/rmsama/.codex/skills/xhs-note-creator/node_modules/playwright');
const path = require('node:path');
const fs = require('node:fs');
(async()=>{
const http=require('node:http');
const root=path.resolve(__dirname,'../../outputs/official-website/frontend/dist');
const server=http.createServer((req,res)=>{let pathname=new URL(req.url,'http://localhost').pathname;let target=path.join(root,pathname);if(!fs.existsSync(target)||fs.statSync(target).isDirectory())target=path.join(root,'index.html');const ext=path.extname(target);res.setHeader('Content-Type',({'.html':'text/html','.js':'application/javascript','.css':'text/css','.png':'image/png','.svg':'image/svg+xml'})[ext]||'application/octet-stream');res.end(fs.readFileSync(target));});
await new Promise(resolve=>server.listen(18832,'127.0.0.1',resolve));

const browser=await chromium.launch({headless:true,channel:'msedge',args:['--no-proxy-server']});
const page=await browser.newPage({viewport:{width:390,height:844},deviceScaleFactor:2,isMobile:true,hasTouch:true,reducedMotion:'reduce'});
const out=path.resolve(__dirname,'../../outputs/支付宝手机网站支付申请素材');
const checks=[];
for(const [route,name] of [['/','首页'],['/plans','商品套餐'],['/checkout?plan=month','订单支付确认']]) {
 await page.goto('http://127.0.0.1:18832'+route);await page.waitForTimeout(700);
 if(await page.locator('body').evaluate(el=>el.scrollWidth)>390)throw new Error('mobile overflow '+route);
 await page.screenshot({path:path.join(out,name+'.png'),fullPage:true});
 checks.push({route,title:await page.title(),width:390,overflow:false});
}
await page.getByRole('checkbox').check();
if(!(await page.getByRole('button',{name:'支付待开通 · 暂不收款'}).isDisabled()))throw new Error('payment enabled');
for(const [id,price] of [['single','1'],['week','5.9'],['month','9.9']]) {
 await page.goto('http://127.0.0.1:18832/checkout?plan='+id);
 const total=await page.locator('.order-total dd').innerText();if(total!=='¥'+price)throw new Error('price mismatch');
}
await page.goto('http://127.0.0.1:18832/plans');await page.getByRole('link',{name:'查看订单与支付说明'}).first().click();
if(!page.url().includes('plan=single'))throw new Error('navigation failed');
fs.writeFileSync(path.join(__dirname,'verification.json'),JSON.stringify({checks,plans:3,paymentDisabled:true,consentChecked:true,navigation:true},null,2));
await browser.close();server.close();console.log('PASS: 3 mobile screenshots, 3 prices, navigation, consent and disabled payment.');
})();
