import base64,json,sys
from pathlib import Path
r=Path(__file__).resolve().parent
x=r.parent/'railway-source-qa.xlsx'
p={'requestId':'same-railway-bank','fileName':x.name,'data':base64.b64encode(x.read_bytes()).decode()}
js='new Promise(resolve=>{const previous=window.onNativeQuestionBankResult;window.onNativeQuestionBankResult=(id,body)=>{if(id==="same-railway-bank"){window.onNativeQuestionBankResult=previous;resolve(JSON.parse(body))}else previous?.(id,body)};window.AndroidBridge.questionBankImport('+json.dumps(json.dumps(p,separators=(',',':')))+');setTimeout(()=>resolve({timeout:true}),120000);})'
(r/'import-same-bank.js').write_text(js,encoding='utf-8')
print('Prepared the original railway Excel input for native import.')
