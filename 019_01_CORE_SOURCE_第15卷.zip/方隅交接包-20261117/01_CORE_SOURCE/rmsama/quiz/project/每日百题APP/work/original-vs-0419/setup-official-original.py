import control as c
import subprocess,time,json,sys
sys.stdout.reconfigure(encoding='utf-8')
r=c.R
folder=r/'original-only-rounds'/sys.argv[1]
folder.mkdir(exist_ok=True)
assert not (folder/'ready.png').exists(),'Use a new round folder; preserve evidence.'
host='com.jimusoft.railwaymp.canvas419'
c.adb('shell','am','force-stop',host)
c.adb('shell','run-as',host,'rm','-f','files/events.jsonl')
c.adb('shell','am','start','-n',host+'/com.jimusoft.railwaymp.MainActivity')
time.sleep(1)
pid=c.adb('shell','pidof',host).decode().strip()
c.adb('forward','tcp:18786','localabstract:webview_devtools_remote_'+pid)
for name in ['start-hidden-host.js','cancel-host-animation.js']:
    subprocess.run(['node',str(r/'cdp.cjs'),'18786',str(r/name)],check=True)
c.adb('shell','settings','put','secure','enabled_accessibility_services','com.futureyyy.tijing/com.futureyyy.tijing.QuizAccessibilityService')
c.adb('shell','settings','put','secure','accessibility_enabled','1')
c.launch('com.futureyyy.tijing')
for attempt in range(8):
    try:
        c.click('自动刷题')
        break
    except RuntimeError:
        if attempt==7:raise
        time.sleep(.5)
nodes=c.nodes()
footers=[n.get('text','') for n in nodes if n.get('bounds','').startswith('[409,1554]')]
assert footers==['自动刷题'],f'Automatic mode not verified: {footers}'
(folder/'mode-before-start.json').write_text(json.dumps({'automaticModeVerified':True,'footer':footers,'officialPackage':'com.futureyyy.tijing','graphics':sys.argv[2] if len(sys.argv)>2 else 'unknown','host':host,'hostAnimationCancelled':True,'model':'deepseek-chat','endpoint':'https://api.deepseek.com','sourceChanged':False},ensure_ascii=False,indent=2),encoding='utf-8')
c.click('启用悬浮识题')
time.sleep(.3)
c.click('START')
time.sleep(2)
c.adb('shell','am','start','-n',host+'/com.jimusoft.railwaymp.MainActivity')
time.sleep(2)
(folder/'ready.png').write_bytes(c.adb('exec-out','screencap','-p'))
print(json.dumps({'ready':str(folder),'automaticModeVerified':True},ensure_ascii=False))
