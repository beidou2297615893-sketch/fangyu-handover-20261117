import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {buildQuestionBankIndex,matchQuestionStem} from '../tijing-upstream/src/lib/questionBank.js';
const root=path.dirname(fileURLToPath(import.meta.url));
const bank=JSON.parse(fs.readFileSync(path.join(root,'same-bank-1859.json'),'utf8'));
const result=JSON.parse(JSON.parse(fs.readFileSync(path.join(root,'provider-thinking-disabled.json'),'utf8')).content);
const expected=bank.questions.find(q=>q.question.includes('电动列车客室广播故障'));
const index=buildQuestionBankIndex(bank.questions);
const summary={count:bank.questions.length,fullStem:expected.question,recognizedStem:result.question,modelAnswer:result.answer_indices};
for(const [label,stem] of [['full',expected.question],['recognized',result.question]]){
 const match=matchQuestionStem(index,stem);
 summary[label]={status:match.status,score:match.score,question:match.record?.question,answer:match.record?.answer_indices,candidates:match.candidates?.length};
}
fs.writeFileSync(path.join(root,'original-match-comparison.json'),JSON.stringify(summary,null,2));
console.log(JSON.stringify(summary));
