import control as c
import json
out=c.R/'feedback-mid-start';out.mkdir(exist_ok=True)
manifest={'frames':[{'file':'mid-start-053.png','questionNo':1,'expectedPageKind':'graded'}],
    'diagnosticOnly':True,'naturalRound':False,'scenario':'Start the runner in the middle of a host quiz (host 53, runner 1)'}
path=out/'manifest-old.json';path.write_text(json.dumps(manifest),encoding='utf-8')
pkg='com.jimusoft.dailyhundredapp.audit419.dev';target='/data/user/0/'+pkg+'/files/ocr-corpus/manifest.json'
uid=c.adb('shell','stat','-c','%u','/data/user/0/'+pkg).decode().strip()
imageTarget='/data/user/0/'+pkg+'/files/ocr-corpus/mid-start-053.png'
c.adb('push',c.R/'hidden-final-natural/feedback53-clean.png',imageTarget)
c.adb('shell','chown',uid+':'+uid,imageTarget);c.adb('shell','restorecon',imageTarget)
c.adb('push',path,target);c.adb('shell','chown',uid+':'+uid,target);c.adb('shell','restorecon',target)
print(c.adb('shell','am','instrument','-w','com.jimusoft.comparison.batchocrprobe/com.jimusoft.comparison.BatchOcrProbe').decode())
raw=c.adb('exec-out','run-as',pkg,'cat','files/batch-ocr-result.json')
(out/'old-result.json').write_bytes(raw);result=json.loads(raw)
assert result['finished'] and result['pagePassed']==0 and result['pageFailed']==1
print('Old counter assumption reproduced: mid-start page 53 is rejected when runner ordinal is 1.')
