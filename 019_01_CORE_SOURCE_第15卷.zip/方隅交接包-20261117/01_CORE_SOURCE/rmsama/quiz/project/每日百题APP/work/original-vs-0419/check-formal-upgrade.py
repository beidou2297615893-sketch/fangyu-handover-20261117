import control as c
import json,time,re,hashlib
root=c.R;out=root/'formal-upgrade';pkg='com.jimusoft.dailyhundredapp'
naturalFolder=(root/'active-natural-folder.txt').read_text(encoding='utf-8').strip()
natural=json.loads((root/naturalFolder/'final-summary.json').read_text(encoding='utf-8'))
assert natural['last']=='result' and natural['correct']==100
fixture=json.loads((out/'fixture-prepared.json').read_text(encoding='utf-8'))
component=pkg+'/com.futureyyy.tijing.QuizAccessibilityService'
def grant():return component in c.adb('shell','settings','get','secure','enabled_accessibility_services').decode()
def bank():
    raw=c.adb('exec-out','cat','/data/user/0/'+pkg+'/files/question-bank.json')
    return {'count':len(json.loads(raw)['questions']),'sha256':hashlib.sha256(raw).hexdigest()}
def version():
    text=c.adb('shell','dumpsys','package',pkg).decode(errors='replace')
    return re.search(r'versionName=(\S+)',text).group(1)
# A test fixture grants the old install once; no grant writes occur after upgrading.
c.adb('shell','settings','put','secure','enabled_accessibility_services',component)
c.adb('shell','appops','set',pkg,'SYSTEM_ALERT_WINDOW','allow')
c.adb('shell','pm','grant',pkg,'android.permission.POST_NOTIFICATIONS')
c.launch(pkg);time.sleep(2)
before={'version':version(),'bank':bank(),'accessibilityEnabled':grant()}
assert before['version']=='0.4.19' and before['bank']['count']==1859 and before['accessibilityEnabled']
(out/'formal-home-before-upgrade.png').write_bytes(c.adb('exec-out','screencap','-p'))
apk=root/'release-universal/android/app/build/outputs/apk/prod/release/app-prod-release.apk'
proof=json.loads((root/'release-checks/result.json').read_text(encoding='utf-8'))
audit=json.loads((root/'evidence-audit.json').read_text(encoding='utf-8'))
assert proof['pass'] and proof['hashes']['qa']==audit['fixedDiagnosticApk']['sha256']
assert not proof['sources']['issues']
assert hashlib.sha256(apk.read_bytes()).hexdigest()==proof['hashes']['universal']
print(c.adb('install','-r',apk,timeout=60).decode(),flush=True)
c.launch(pkg);time.sleep(2)
after={'version':version(),'bank':bank(),'accessibilityEnabled':grant()}
(out/'formal-home-after-upgrade.png').write_bytes(c.adb('exec-out','screencap','-p'))
reopens=[]
for mode in ['background-reopen','process-stop-reopen']:
    if mode=='background-reopen':c.adb('shell','input','keyevent','KEYCODE_HOME')
    else:c.adb('shell','am','force-stop',pkg)
    time.sleep(.5);c.launch(pkg);time.sleep(2)
    reopens.append({'action':mode,'bank':bank(),'accessibilityEnabled':grant()})
(out/'formal-home-after-reopen.png').write_bytes(c.adb('exec-out','screencap','-p'))
record={'serial':c.SERIAL,'before':before,'after':after,'reopens':reopens,
    'seededFixture':True,'noGrantWritesAfterUpgrade':True,'paymentFlowTested':False,'phoneTested':False}
(out/'upgrade-result.json').write_text(json.dumps(record,indent=2),encoding='utf-8')
assert after['version']=='0.4.20' and after['bank']==before['bank'] and after['accessibilityEnabled']
assert all(x['bank']==before['bank'] and x['accessibilityEnabled'] for x in reopens)
print(json.dumps(record),flush=True)
