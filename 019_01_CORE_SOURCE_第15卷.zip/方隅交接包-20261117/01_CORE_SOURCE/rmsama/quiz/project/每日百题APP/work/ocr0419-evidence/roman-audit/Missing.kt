package com.futureyyy.tijing
import java.io.File
import javax.imageio.ImageIO
import com.google.gson.JsonParser
fun main(){
 val d=File("V:/work/ocr0419-evidence/hd100")
 val source=JsonParser.parseString(File(d,"replay-manifest.json").readText()).asJsonObject.getAsJsonArray("rows").associate{e->val r=e.asJsonObject;r["file"].asString to r["sourcePath"].asString}
 val raw=File("V:/work/ocr0419-evidence/hd100/a7-spot-paddle.json")
 val list=JsonParser.parseString(raw.readText()).asJsonArray.single().asJsonObject.getAsJsonArray("lines").toList().takeLast(4)
 val nodes=list.map{v->val n=v.asJsonObject;val b=n["box"].asJsonArray;VisibleQuestionReader.Node(n["text"].asString, NormalizedBox(b[0].asFloat,b[1].asFloat,b[2].asFloat,b[3].asFloat))}
 val img=ImageIO.read(File("V:/work/verify-0419-device/upstream-input-1794579648623975200.png"));val w=img.width;val h=img.height;val px=img.getRGB(0,0,w,h,null,0,w)
 fun compare(tag:String, got:List<VisibleQuestionReader.Node>?, expect:List<String>?){require(got?.map{it.text}==expect){tag+": "+got};println(tag+" passed")}
 val yes=listOf("管理,IV","管理,III","管理,II","管理,I")
 compare("onsite one missing",RomanChoiceEvidence.read(w,h,px,nodes),yes)
 compare("duplicate OCR strokes",RomanChoiceEvidence.read(w,h,px,nodes.mapIndexed{i,n->if(i==1)n.copy(text="管理，ⅢⅢ")else n}),yes)
 compare("two real OCR empties",RomanChoiceEvidence.read(w,h,px,nodes.mapIndexed{i,n->if(i==2)n.copy(text="管理，")else n}),null)
 compare("prefix changed",RomanChoiceEvidence.read(w,h,px,nodes.mapIndexed{i,n->if(i==3)n.copy(text="管控，")else n}),null)
 compare("delimiter missing",RomanChoiceEvidence.read(w,h,px,nodes.mapIndexed{i,n->if(i==3)n.copy(text="管理")else n}),null)
 val blank=px.copyOf()
 for(y in 1200..1252) for(x in 308..321)blank[y*w+x]=0xFFFFFFFF.toInt()
 compare("physically missing vertical",RomanChoiceEvidence.read(w,h,blank,nodes),null)
 val swap=listOf(3,1,0,2);compare("position changed",(RomanChoiceEvidence.read(w,h,px,swap.map{nodes[it]})),swap.map{yes[it]})
 val others=JsonParser.parseString(File(d,"replay-paddle.json").readText()).asJsonArray
 var negatives=0
 for (row in others){val item=row.asJsonObject;val file=item["file"].asString.removePrefix("page-");if(file.contains("-q20-"))continue;val im=ImageIO.read(File(source.getValue(file)));val arr=im.getRGB(0,0,im.width,im.height,null,0,im.width)
 val ls=item["lines"].asJsonArray.map{v->val n=v.asJsonObject;val b=n["box"].asJsonArray;VisibleQuestionReader.Node(n["text"].asString,NormalizedBox(b[0].asFloat,b[1].asFloat,b[2].asFloat,b[3].asFloat))}
 require(ls.windowed(4).all{RomanChoiceEvidence.read(im.width,im.height,arr,it)==null});negatives++}
 println("all benign historical other real images rejected "+negatives)
}
