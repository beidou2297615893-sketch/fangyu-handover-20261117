'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict');
const {run,request}=require('./core.cjs');
const OLD='ed017a2c704a93f4a05f84bd7ab065d4ce1b4556a1384f322656576fc854c295',NEW='a'.repeat(64);
function fixture(kind='ok'){
 const state={marked:0,updates:0,updated:false,polls:0},fakeSecret='synthetic-private-sentinel';
 const gates=['BILLING_ENABLED','BILLING_NATIVE_ADMISSION_READY','BILLING_NATIVE_RELEASE_VERIFIED','BILLING_CLOUD_ACL_VERIFIED'];
 const adapter={packageHash:NEW,async delay(){},async mark(){state.marked++},async update(){state.updates++;state.updated=true;if(kind==='update-unknown')throw Error();return {RequestId:'fake'}},
  async detail(){const rows=gates.map(Key=>({Key,Value:'false'}));rows.push({Key:'ALIPAY_PRIVATE_KEY',Value:state.updated&&kind==='env-changed'?'different':fakeSecret});if(kind==='gate-open'||state.updated&&kind==='gate-after')rows[0].Value='true';return {FunctionName:'dailyHundredBillingV1',Namespace:'fh6-d5ga45c0ddae7008c',Type:'Event',Runtime:'Nodejs20.19',Handler:'production-entry.main',Status:'Active',Environment:{Variables:rows}}},
  async codeHash(){return state.updated?(kind==='wrong-new'?'b'.repeat(64):NEW):(kind==='wrong-old'?'b'.repeat(64):OLD)},
  async functions(){return [{name:'dailyHundredBillingV1',functionId:kind==='wrong-id'&&state.updated?'other':'billing',status:'Active'},{name:'translation',functionId:'existing',status:state.updated&&kind==='other-changed'?'Updating':'Active'}]},
  async routes(){return [{path:'/translation',upstreamResourceName:'translation'}]},
  async status(){return kind!=='status-open'},
  async triggers(){return {TotalCount:1,Triggers:[{Type:'http',Enable:1,Qualifier:'$LATEST',TriggerName:'fixed-id',TriggerDesc:JSON.stringify({AuthType:'NONE',NetConfig:{EnableExtranet:true,ExtranetUrl:'https://1439321968-fixed-id.ap-shanghai.tencentscf.com/'}})}]}}
 };return {state,adapter,fakeSecret};
}
test('code update request contains no environment and pins the dedicated function',()=>{
 const payload=request(Buffer.from([0x50,0x4b,0x03,0x04,1]));assert.deepEqual(Object.keys(payload).sort(),['FunctionName','Namespace','InstallDependency','Publish','ZipFile'].sort());assert.equal(payload.FunctionName,'dailyHundredBillingV1');assert.equal(payload.Namespace,'fh6-d5ga45c0ddae7008c');assert.equal(payload.Publish,'FALSE');assert.equal(payload.InstallDependency,'FALSE');
});
test('four gates and environment stay unchanged across code-only update',async()=>{
 const f=fixture(),r=await run(f.adapter);assert.deepEqual(r,{updated:true,paymentEnabled:false,otherMetadataUnchanged:true});assert.equal(f.state.marked,1);assert.equal(f.state.updates,1);assert.equal(JSON.stringify(r).includes(f.fakeSecret),false);
});
test('preflight rejects a different package, open gate or active public endpoint before mutation',async()=>{for(const mode of ['wrong-old','gate-open','status-open']){const f=fixture(mode);await assert.rejects(run(f.adapter));assert.equal(f.state.updates,0);assert.equal(f.state.marked,0);}});
test('uncertain update, changed gates, environment, package or other metadata never report success',async()=>{for(const mode of ['update-unknown','env-changed','gate-after','wrong-new','wrong-id','other-changed']){const f=fixture(mode);await assert.rejects(run(f.adapter));assert.equal(f.state.marked,1);assert.equal(f.state.updates,1);}});
test('official SDK sends a code-only request without environment variables',async()=>{
 const sdk=require('../payment-secret-prep/sdk-scf/node_modules/tencentcloud-sdk-nodejs-scf'),fetch=require('../payment-secret-prep/sdk-scf/node_modules/tencentcloud-sdk-nodejs-common/tencentcloud/common/http/fetch'),old=fetch.default;let calls=0;
 fetch.default=async(url,options)=>{calls++;assert.equal(url,'https://scf.tencentcloudapi.com/');assert.equal(options.headers['X-TC-Action'],'UpdateFunctionCode');const payload=JSON.parse(options.body);assert.deepEqual(Object.keys(payload).sort(),['FunctionName','Namespace','InstallDependency','Publish','ZipFile'].sort());assert.equal(payload.FunctionName,'dailyHundredBillingV1');assert.equal(payload.InstallDependency,'FALSE');return {status:200,headers:{get:()=>null},json:async()=>({Response:{RequestId:'synthetic'}})};};
 try{const client=new sdk.scf.v20180416.Client({credential:{secretId:'fake',secretKey:'fake',token:'fake'},region:'ap-shanghai'});assert.equal((await client.UpdateFunctionCode(request(Buffer.from([0x50,0x4b,3,4,1])))).RequestId,'synthetic');assert.equal(calls,1);}finally{fetch.default=old;}
});
