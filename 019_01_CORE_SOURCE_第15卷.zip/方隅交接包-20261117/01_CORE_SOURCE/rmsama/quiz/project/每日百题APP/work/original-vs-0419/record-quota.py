from pathlib import Path
import json,sys,datetime
r=Path('V:/work/original-vs-0419')
used=float(sys.argv[1]);window=int(sys.argv[2]);reset=int(sys.argv[3])
remaining=max(0,min(100,100-used))
row={'checkedAt':datetime.datetime.now().astimezone().isoformat(timespec='seconds'),'usedPercent':used,
    'remainingPercent':remaining,'windowDurationMins':window,'resetsAt':reset,'stopThresholdPercent':2,'mustStop':remaining<=2}
with (r/'quota-checks.jsonl').open('a',encoding='utf-8') as file:file.write(json.dumps(row,ensure_ascii=False)+'\n')
(r/'quota-latest.json').write_text(json.dumps(row,indent=2),encoding='utf-8')
if row['mustStop']:(r/'STOP-WORK-QUOTA.json').write_text(json.dumps(row,indent=2),encoding='utf-8')
print(json.dumps(row))
