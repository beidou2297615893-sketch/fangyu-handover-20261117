$ErrorActionPreference='Stop'
try {
  $dir=Join-Path $PSScriptRoot '../payment-pilot-private'
  $file=Join-Path $dir 'identity.json'
  $user=[Security.Principal.WindowsIdentity]::GetCurrent().User.Value
  foreach($p in @($dir,$file)) {
    $item=Get-Item -LiteralPath $p -Force
    if($item.Attributes -band [IO.FileAttributes]::ReparsePoint){throw 'invalid'}
    $acl=Get-Acl -LiteralPath $p
    if($p -eq $dir -and !$acl.AreAccessRulesProtected){throw 'invalid'}
    $rules=@($acl.GetAccessRules($true,$true,[Security.Principal.SecurityIdentifier]))
    if(!$rules.Count -or @($rules|Where-Object {$_.AccessControlType -eq 'Allow' -and $_.IdentityReference.Value -notin @($user,'S-1-5-18')}).Count){throw 'invalid'}
  }
  [Console]::Out.Write('OK')
}catch{[Console]::Error.Write('UNAVAILABLE');exit 2}
