import control as c
import json,hashlib,shutil
folder=c.R/'railway-feedback-corpus';path=folder/'manifest.json'
manifest=json.loads(path.read_text(encoding='utf-8'))
file='mid-start-053.png';shutil.copy2(c.R/'hidden-final-natural/feedback53-clean.png',folder/file)
manifest['frames']=[x for x in manifest['frames'] if x['file']!=file]
manifest['frames'].append({'file':file,'questionNo':1,'expectedPageKind':'graded',
    'scenario':'Host is at question 53 while a newly started runner has ordinal 1.',
    'sha256':hashlib.sha256((folder/file).read_bytes()).hexdigest()})
assert len(manifest['frames'])==103
path.write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
print('Prepared 103 page-state frames including actual mid-start failure image.')
