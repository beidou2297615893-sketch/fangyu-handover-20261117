import control as c
import json,sys
sys.stdout.reconfigure(encoding='utf-8')
print(json.dumps([{'text':'***' if n.get('password')=='true' else n.get('text',''),'desc':n.get('content-desc',''),'class':n.get('class'),'bounds':n.get('bounds')}
    for n in c.nodes() if n.get('bounds')!='[0,0][0,0]' and (n.get('text') or n.get('content-desc') or n.get('class')=='android.widget.EditText')],ensure_ascii=False))
