from pathlib import Path
import hashlib, json, os, re, subprocess, sys, zipfile

ROOT = Path('V:/work/original-vs-0419/fixed-current')
ORIGIN = Path('V:/work/tijing-bankassist')
COPY = ROOT / 'source'
JDK = next(Path('V:/work/tools/jdk').glob('jdk-17*'))
SDK = Path('V:/work/tools/android-sdk')
GRADLE = Path('C:/Users/rmsama/DailyHundredNativeBuild/work/tijing-toolchain/gradle-8.7/bin/gradle.bat')

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def snapshot():
    paths = []
    for name in ('src', 'public', 'android/app/src/main/java', 'android/app/src/main/assets'):
        paths.extend(p for p in (ORIGIN / name).rglob('*') if p.is_file())
    paths.extend(ORIGIN / n for n in ('android/app/build.gradle.kts','android/gradle.properties', 'android/app/src/main/AndroidManifest.xml', 'index.html', 'package.json', 'vite.config.js'))
    return {p.relative_to(ORIGIN).as_posix(): digest(p) for p in paths}

def run(args, cwd, log=None, env=None):
    print('Running', args[0], flush=True)
    with (ROOT / log).open('w', encoding='utf-8') if log else open(os.devnull, 'w') as out:
        subprocess.run([str(x) for x in args], cwd=cwd, env=env, check=True, stdout=out, stderr=subprocess.STDOUT)

if COPY.exists():
    raise SystemExit('Refusing to overwrite the existing isolated source; use a fresh directory.')
gradle_text = (ORIGIN / 'android/app/build.gradle.kts').read_text(encoding='utf-8')
if not re.search(r'versionCode\s*=\s*86\b', gradle_text) or not re.search(r'versionName\s*=\s*"0\.4\.19"', gradle_text):
    raise SystemExit('Source is not version 0.4.19 / 86. Wait for the frozen source.')
before = snapshot()
(ROOT / 'frozen-inputs.json').write_text(json.dumps(before, ensure_ascii=False, indent=2), encoding='utf-8')
run([sys.executable, ROOT / 'prepare.py'], ROOT, 'prepare.log')
subprocess.run(['cmd', '/c', 'mklink', '/J', str(COPY / 'node_modules'), str(ORIGIN / 'node_modules')], check=True, stdout=subprocess.DEVNULL)
run(['npm.cmd', 'run', 'build'], COPY, 'web-build.log')
run(['node', 'scripts/sync-android-assets.mjs'], COPY, 'assets-sync.log')
env = os.environ.copy()
env.update(JAVA_HOME=str(JDK), ANDROID_HOME=str(SDK), ANDROID_SDK_ROOT=str(SDK), GRADLE_USER_HOME='V:/work/gradle-home', PATH=str(JDK / 'bin') + os.pathsep + env['PATH'])
for key in ('DAILYHUNDRED_STORE_FILE', 'DAILYHUNDRED_STORE_PASSWORD', 'DAILYHUNDRED_KEY_ALIAS', 'DAILYHUNDRED_KEY_PASSWORD'):
    env.pop(key, None)
run([GRADLE, '-p', COPY / 'android', '-I', ROOT / 'test-repos.gradle', ':app:testDevDebugUnitTest', ':app:assembleDevDebug', '--offline', '--no-daemon', '--console=plain', '--max-workers=4'], COPY, 'android-build.log', env)
if snapshot() != before:
    raise SystemExit('Original inputs changed during build: discard this package and retry after a fresh freeze.')
main = ORIGIN / 'android/app/src/main/java'
copy_main = COPY / 'android/app/src/main/java'
shared = COPY / 'android/app/src/diagnosticShared/java'
files = sorted(p for p in main.rglob('*.kt'))
exceptions = {'payment/AndroidPayment.kt', 'payment/GatewaySessionEntry.kt'}
checks = []
for path in files:
    rel = path.relative_to(main).as_posix()
    target = shared / rel
    is_exception = any(rel.endswith(x) for x in exceptions)
    checks.append({'path': rel, 'sha256': digest(path), 'main_copy_equal': (copy_main / rel).is_file() and digest(copy_main / rel) == digest(path), 'compiled_shared_equal': None if is_exception else target.is_file() and digest(target) == digest(path), 'diagnostic_replacement': is_exception})
if not all(x['main_copy_equal'] and (x['compiled_shared_equal'] is None or x['compiled_shared_equal']) for x in checks):
    raise SystemExit('Shared source does not match frozen product inputs.')
apk = COPY / 'android/app/build/outputs/apk/dev/debug/app-dev-debug.apk'
run([SDK / 'build-tools/35.0.0/apksigner.bat', 'verify', '--verbose', '--print-certs', apk], ROOT, 'signature.txt', env)
run([SDK / 'build-tools/35.0.0/aapt.exe', 'dump', 'badging', apk], ROOT, 'apk-identity.txt', env)
identity = (ROOT / 'apk-identity.txt').read_text(encoding='utf-8', errors='replace')
if "name='com.jimusoft.dailyhundredapp.audit419.dev'" not in identity or "versionCode='86'" not in identity or "versionName='0.4.19-dev'" not in identity:
    raise SystemExit('Unexpected isolated APK identity.')
with zipfile.ZipFile(apk) as z:
    zfiles = set(z.namelist())
    web = COPY / 'android/app/src/main/assets/web'
    files_web = [p for p in web.rglob('*') if p.is_file()]
    if not files_web or any(z.read('assets/web/' + p.relative_to(web).as_posix()) != p.read_bytes() for p in files_web):
        raise SystemExit('Embedded web assets differ from built source.')
    dex = b''.join(z.read(n) for n in zfiles if re.fullmatch(r'classes\d*\.dex', n))
    if b'127.0.0.1:18765/v1/chat/completions' not in dex or b'ISOLATED_DIAGNOSTIC_ONLY' not in dex:
        raise SystemExit('Diagnostic isolation markers missing from APK.')
    model_files = sorted(n for n in zfiles if ('hani_ctc/' in n.lower() or 'chinese' in n.lower()) and n.startswith(('assets/','lib/')))
    if not model_files or b'ChineseTextRecognizerOptions' not in dex:
        raise RuntimeError("Chinese recognizer not present in QA APK; inspect dependency resolution")
    (ROOT/'bundled-ocr.json').write_text(json.dumps({n:hashlib.sha256(z.read(n)).hexdigest() for n in model_files},indent=2),encoding='utf8')
result = {'version': '0.4.19-dev', 'versionCode': 86, 'applicationId': 'com.jimusoft.dailyhundredapp.audit419.dev', 'sha256': digest(apk), 'productInputsUnchangedDuringBuild': True, 'originalKotlinCopies': len(checks), 'sharedKotlinFiles': sum(x['compiled_shared_equal'] is True for x in checks), 'webAssetsMatch': True, 'diagnosticMarkersPresent': True, 'files': checks}
(ROOT / 'proof.json').write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps({k:v for k,v in result.items() if k != 'files'}, ensure_ascii=False, indent=2))





