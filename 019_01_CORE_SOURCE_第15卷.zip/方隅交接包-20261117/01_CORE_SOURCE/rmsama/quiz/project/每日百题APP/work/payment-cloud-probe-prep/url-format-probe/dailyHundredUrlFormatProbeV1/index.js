'use strict';

// No SDK, logging, network, credentials, database, or input reflection.
// The only accepted fixture is non-sensitive and predetermined locally.
const fixtureBody = 'probe_id=fixture123&value=alpha%2Bbeta';
function header(headers, name) {
  if (!headers || typeof headers !== 'object' || Array.isArray(headers)) return undefined;
  const keys = Object.keys(headers).filter(key => key.toLowerCase() === name);
  return keys.length === 1 ? headers[keys[0]] : undefined;
}
exports.main = async function main(event) {
  const e = event && typeof event === 'object' && !Array.isArray(event) ? event : {};
  const contentType = header(e.headers, 'content-type');
  const fixtureHeader = header(e.headers, 'x-probe-fixture');
  const checks = {
    method: e.httpMethod === 'POST',
    path: e.path === '/__probe__/form',
    contentType: typeof contentType === 'string' && /^\s*application\/x-www-form-urlencoded\s*(?:;\s*charset=utf-8\s*)?$/i.test(contentType),
    fixtureHeader: fixtureHeader === 'fixture123',
    rawBody: e.body === fixtureBody,
  };
  return {
    statusCode: Object.values(checks).every(Boolean) ? 200 : 503,
    headers: {'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'},
    body: JSON.stringify({paymentEnabled:false,checks})
  };
};
