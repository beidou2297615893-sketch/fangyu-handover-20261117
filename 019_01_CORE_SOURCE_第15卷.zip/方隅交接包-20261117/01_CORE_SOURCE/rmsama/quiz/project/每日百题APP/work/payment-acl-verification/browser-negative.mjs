// Browser-only client probe. The caller supplies an already authenticated
// CloudBase Web SDK app/session; this module never signs in or creates users.
const NAMES=Object.freeze(['daily_hundred_payment_v1','daily_hundred_installation_v1']);
export async function verifyClient(db,session,kind,randomId){
 if(!db||typeof db.collection!=='function'||!['anonymous','registered'].includes(kind)||!session||typeof session.access_token!=='string'||!session.access_token||!session.user||session.user.is_anonymous!==(kind==='anonymous'))return {verified:false,reason:'identity-unverified'};
 const token=randomId?randomId():Array.from(globalThis.crypto.getRandomValues(new Uint8Array(16)),v=>v.toString(16).padStart(2,'0')).join('');
 if(typeof token!=='string'||!/^[a-f0-9]{32}$/.test(token))return {verified:false,reason:'invalid-test-id'};
 const id='acl-test-'+token;
 for(const name of NAMES){
  const collection=db.collection(name),ops=[()=>collection.doc(id).get(),()=>collection.where({_id:id}).limit(1).get(),()=>collection.doc(id).set({kind:'temporary-acl-test',token})];
  for(const op of ops){
   try{await op();return {verified:false,reason:'unexpected-access',testId:id};}
   catch(error){if(error?.code!=='DATABASE_PERMISSION_DENIED'&&error?.errCode!=='DATABASE_PERMISSION_DENIED')return {verified:false,reason:'indeterminate'};}
  }
 }
 return {verified:true};
}
