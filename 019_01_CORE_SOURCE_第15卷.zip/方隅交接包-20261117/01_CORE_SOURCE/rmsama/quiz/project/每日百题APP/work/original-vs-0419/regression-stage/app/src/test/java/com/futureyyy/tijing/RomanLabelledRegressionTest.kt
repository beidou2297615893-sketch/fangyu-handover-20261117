package com.futureyyy.tijing

import com.google.gson.JsonParser
import java.io.DataInputStream
import java.util.zip.GZIPInputStream
import org.junit.Assert.*
import org.junit.Test

class RomanLabelledRegressionTest {
    private val input = DataInputStream(GZIPInputStream(javaClass.getResourceAsStream("/regression/roman-labelled.argb.gz")!!))
    private val width = input.readInt()
    private val height = input.readInt()
    private val pixels = IntArray(width*height) { input.readInt() }.also { input.close() }
    private val rows = JsonParser.parseString(javaClass.getResourceAsStream("/regression/roman-labelled.json")!!
        .bufferedReader(Charsets.UTF_8).use { it.readText() }).asJsonObject.getAsJsonArray("lines").map {
        val o=it.asJsonObject;val b=o.getAsJsonObject("box")
        VisibleQuestionReader.Node(o.get("text").asString,NormalizedBox(b.get("x").asFloat,b.get("y").asFloat,
            b.get("width").asFloat,b.get("height").asFloat))
    }.filter { it.text.matches(Regex("^[A-D]\\..*")) }.sortedBy { it.box!!.centerY }

    @Test fun labelledRomanLevelsUseActualStrokesInsteadOfOcrDuplicateGlyphs() {
        val result=RomanChoiceEvidence.read(width,height,pixels,rows)
        assertNotNull("All four real labelled rows have clear I/V strokes",result)
        assertEquals(listOf("A.管理,IV","B.管理,III","C.管理,II","D.管理,I"),result!!.map { it.text })
        assertEquals(rows.map { it.box },result.map { it.box })
    }

    @Test fun anUnreadableLevelCannotBeInferredFromTheOtherThree() {
        val p=pixels.clone();val b=rows[1].box!!
        for(y in (b.y*height/100).toInt()-3..((b.y+b.height)*height/100).toInt()+3)
            for(x in (b.x*width/100).toInt()-3..((b.x+b.width)*width/100).toInt()+3)
                p[y*width+x]=0xffffffff.toInt()
        assertNull(RomanChoiceEvidence.read(width,height,p,rows))
    }
}
