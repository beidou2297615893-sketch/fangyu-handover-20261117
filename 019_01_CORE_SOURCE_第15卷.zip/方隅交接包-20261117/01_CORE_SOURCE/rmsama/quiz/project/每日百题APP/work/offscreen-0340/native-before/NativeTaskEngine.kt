package expo.modules.automationbridge

import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.os.*
import android.provider.Settings
import android.view.accessibility.AccessibilityNodeInfo
import expo.modules.automationbridge.upstream.AccessibilityEnableList
import expo.modules.automationbridge.upstream.AccessibilityTreeBudget
import org.json.JSONObject
import java.util.UUID
import expo.modules.automationbridge.bank.*
import expo.modules.automationbridge.profile.*
import expo.modules.automationbridge.runtime.*
import expo.modules.automationbridge.screen.*
import expo.modules.automationbridge.ai.*
import expo.modules.automationbridge.generic.*
import expo.modules.automationbridge.billing.*

/** Finite, declared adapter only. No coordinates, shell, arbitrary commands or model tool calls. */
class NativeTaskEngine private constructor(private val context: Context) {
  companion object {
    const val TARGET = "com.jimusoft.dailyhundredtarget"
    private var instance: NativeTaskEngine? = null
    @Synchronized fun get(context: Context): NativeTaskEngine = instance ?: NativeTaskEngine(context.applicationContext).also { instance = it }
  }
  private val db = TaskDatabase(context)
  private val aiSettings = SecureAiSettings(context)
  private val gateway=GatewaySettings(context)
  private val workspaces=WorkspaceRepository(db)
  private val profiles=ProfileRepository(db,TrustedProfileKeys.keys)
  private var coordinator:ProfileRunCoordinator?=null
  private var generic:GenericDriver?=null
  private var manualDraft:Pair<String,String>?=null
  private var floatingStartAttempt:Any?=null
  private var failureRead:BoundFailureReadEvidence?=null
  private var paidHumanVerdict=false
  // Task changes invalidate in-flight paid admission before they can launch.
  // The release switch remains off until the complete engine path is tested.
  private val paidStart=PaidAsyncStart(this)
  private val paidWorker=java.util.concurrent.Executors.newSingleThreadExecutor()
  private var settlingPaidRunId:String?=null
  private val paidStore by lazy { PaidRunStore(db.writableDatabase) }
  private val paidGate by lazy {
    check(BuildConfig.BILLING_ADMISSION_ENABLED) { "付费功能尚未开放" }
    PaidRunGate(AndroidPaidRunStore(paidStore),AndroidPaidRunRemote(AdmissionClient.production(AndroidCredentialSource(context))))
  }
  private var profileReader:ScreenReader?=null
  private var profileExecutor:ActionExecutor?=null
  private var profileGeneration=0L
  private var profileReadPending=false
  private var storageFault: String? = null
  private var cachedBankSize=0
  private var cachedBankVersion="unavailable"
  private var cachedLogs: List<Map<String,Any>> = emptyList()
  private var state = try { db.read() } catch (_:Exception) {
    storageFault="手机本地记录无法读取，任务已暂停。请检查存储后重新打开应用。"
    JSONObject().put("status","paused").put("reason",storageFault).put("total",0).put("totalKnown",false).put("answered",0)
  }
  private var lastSavedState=JSONObject(state.toString())
  @Volatile var listener: ((Map<String, Any?>) -> Unit)? = null
  var service: QuizAccessibilityService? = null
  private var launchGrace = 0L
  private var nullSince = 0L
  private val aiWorker = java.util.concurrent.Executors.newSingleThreadExecutor()
  private var aiFuture: java.util.concurrent.Future<*>? = null
  private val samplerDelegate = lazy { expo.modules.automationbridge.sampling.CompatibilitySampler(context) }
  private val sampler get() = samplerDelegate.value
  init {
    if(state.optBoolean("manualDraft") && storageFault==null) {
      try { val workspace=state.getString("workspaceId");val revision=state.getString("bankRevision")
        check(!state.has("genericRun") && !state.optBoolean("pendingSubmit"))
        check(workspaces.get(workspace).activeBankRevision==revision && workspaces.questions(workspace,revision).isNotEmpty())
        manualDraft=Pair(workspace,revision);state.put("status","ready").put("phase","waiting_for_question");state.remove("reason")
      }catch(_:Exception){state.put("status","paused").put("phase","preflight").put("reason","准备资料已变化，请重新准备答题浮窗")}
    }
    if (state.optString("status") == "running") {
      state.put("status", "paused").put("reason", "进程已重新启动，请核对当前页面后继续")
      if(state.optString("stage")=="ai_pending") state.remove("stage")
      try { db.write(state); db.log("pause", "进程恢复，任务保持暂停") }
      catch (_:Exception) { latchStorageFailure() }
    }
    if(state.optJSONObject("genericRun")!=null && storageFault==null) {
      try {
        val saved=RunCodec.decode(state.getJSONObject("genericRun"))
        val recovered=saved.recoverAfterRestart("应用已重新打开，请核对答题页面后继续")
        val binding=GenericBinding.decode(state.getJSONObject("genericTarget"))
        generic=makeGeneric(binding,recovered);persistGeneric(recovered,binding,null)
        if(state.optString("billingMode")=="paid" && recovered.status=="stopped" && recovered.pendingSubmit && paidStore.read(recovered.runId)?.phase=="reserved")
          generic?.acknowledgeUnsubmitted()
      } catch(error:Exception) { state.put("status","paused").put("reason",error.message ?: "答题任务无法恢复");runCatching { writeState() } }
      if(storageFault==null && state.optJSONObject("genericRun")?.optString("status") in setOf("stopped","completed"))
        runCatching { reconcileEndedPaidRun() }
    }
    if(state.optJSONObject("profileRun")!=null && storageFault==null) {
      try {
        val f=RunCodec.decode(state.getJSONObject("profileRun"))
        val p=profiles.get(f.profileId,f.profileVersion)
        check(p.hash==f.profileHash) { "配置版本摘要不一致" }
        val recovered=f.recoverAfterRestart("进程已重新启动，请核对当前页面后继续")
        coordinator=makeCoordinator(p.profile,recovered)
        persistProfile(recovered,null)
      } catch(error:Exception) { state.put("status","paused").put("reason",error.message ?: "运行记录无法恢复");runCatching { writeState() } }
    }
  }
  private fun installed(): Boolean = context.packageManager.getLaunchIntentForPackage(TARGET) != null
  private fun granted(): Boolean = Settings.Secure.getInt(context.contentResolver,Settings.Secure.ACCESSIBILITY_ENABLED,0)==1 && AccessibilityEnableList.containsOwn(
    Settings.Secure.getString(context.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES),
    ComponentName(context, QuizAccessibilityService::class.java).flattenToString())
  private fun accessibilityUnavailableMessage():String = if(granted()) "无障碍已开启，服务正在恢复连接，无需重复授权" else "无障碍服务已关闭，请在系统设置中重新开启"
  @Synchronized fun snapshot(): Map<String, Any?> {
    if(storageFault==null) {
      try { cachedBankSize=db.count(); cachedBankVersion=db.version(); cachedLogs=db.logs() }
      catch (_:Exception) { latchStorageFailure() }
    }
    val selectedProfile=if(storageFault==null && runCatching { db.selectedWorkspace() }.getOrNull()!="__demo__") runCatching { profiles.active() }.getOrNull() else null
    val targetPackage=generic?.binding?.packageName ?: coordinator?.profile?.target?.packageName ?: selectedProfile?.profile?.target?.packageName ?: TARGET
    val profileReady=selectedProfile?.let { p -> p.approvedTargetVersion!=null && runCatching { val info=getTargetInfo(mapOf("profileId" to p.profile.id,"version" to p.profile.version));info["installed"]==true && (info["versionCode"] as? Number)?.toLong()==p.approvedTargetVersion }.getOrDefault(false) } ?: false
    val accessibilityEnabled=granted()
    return mapOf(
    "profileReady" to profileReady, "overlayVisible" to (granted() && service?.overlayVisible==true), "overlayError" to service?.overlayError,
    "platform" to "android", "status" to state.optString("status", "idle"),
    "runId" to state.optString("runId").ifEmpty { null }, "total" to state.optInt("total",0),
    "totalKnown" to state.optBoolean("totalKnown",!state.has("profileRun") && state.optInt("total")>0),
    "phase" to state.optString("phase",state.optString("status","idle")),
    "workspaceId" to state.optString("workspaceId").ifEmpty { if(storageFault==null) runCatching { db.selectedWorkspace() }.getOrNull() else null },
    "selectedWorkspaceId" to if(storageFault==null) runCatching { db.selectedWorkspace() }.getOrNull() else null,
    "bankRevision" to state.optString("bankRevision").ifEmpty { null },
    "profileId" to state.optString("profileId").ifEmpty { selectedProfile?.profile?.id },
    "profileVersion" to state.optInt("profileVersion",selectedProfile?.profile?.version ?: 0), "profileHash" to state.optString("profileHash").ifEmpty { selectedProfile?.hash },
    "httpAttempts" to state.optInt("httpAttempts"),
    "trial" to (state.optJSONObject("profileRun")?.optBoolean("trial") ?: false), "trialVerified" to (state.optJSONObject("profileRun")?.optBoolean("trialVerified") ?: false),
    "submissionUncertain" to ((state.optJSONObject("genericRun") ?: state.optJSONObject("profileRun"))?.optBoolean("pendingSubmit") ?: false),
    "submissionIntentId" to state.optJSONObject("genericRun")?.takeIf { it.optBoolean("pendingSubmit") }?.let { RunCodec.decode(it).submissionIntentId },
    "result" to state.optJSONObject("result")?.let { r -> mapOf("completed" to r.optBoolean("completed"),"submittedCount" to r.optInt("submittedCount"),"score" to if(r.has("score")) r.optInt("score") else null,"evidenceKind" to r.optString("evidenceKind")) },
    "answered" to state.optInt("answered"), "correct" to if(state.optString("mode")=="production") ResultVerifier.correctAnswerCount(coordinator?.facts?.result) else if (state.has("correct")) state.getInt("correct") else null,
    "currentQuestion" to state.optString("stem").ifEmpty { null }, "reason" to state.optString("reason").ifEmpty { null },
    "bankSize" to cachedBankSize, "bankVersion" to cachedBankVersion,
    "accessibilityEnabled" to accessibilityEnabled, "serviceConnected" to (service != null && accessibilityEnabled), "targetInstalled" to (context.packageManager.getLaunchIntentForPackage(targetPackage)!=null), "targetPackage" to if(state.optBoolean("manualDraft")) state.optString("manualTargetPackage").takeIf(String::isNotEmpty) else targetPackage,
    "cloudCalls" to state.optInt("cloudCalls"), "updatedAt" to state.optLong("updatedAt"), "logs" to cachedLogs,
    "aiCandidate" to state.optJSONObject("aiCandidate")?.let { candidate -> mapOf(
      "answerTexts" to SyntheticBank.array(candidate.optJSONArray("answerTexts")?.toString() ?: "[]"),
      "confidence" to candidate.optDouble("confidence",0.0), "reason" to candidate.optString("reason")) })
  }
  /** A storage failure is a process-local stop latch. Never try to persist the error itself. */
  private fun latchStorageFailure() {
    failureRead=null
    cancelSamplingForRun("手机存储状态异常，本次采样已取消。")
    storageFault="手机本地记录无法保存，任务已暂停。请检查存储后重新打开应用。"
    state.put("status","paused").put("reason",storageFault)
    state.remove("correct")
    aiFuture?.cancel(true); aiFuture=null
    runCatching { notification() }
    runCatching { listener?.invoke(snapshot()) }
  }
  private fun requireStorage() { check(storageFault==null) { storageFault.orEmpty() } }
  private fun writeState() {
    requireStorage()
    try { db.write(state);lastSavedState=JSONObject(state.toString()) }
    catch(error:Exception) { state=JSONObject(lastSavedState.toString());latchStorageFailure(); throw IllegalStateException(storageFault,error) }
  }
  private fun save(kind: String? = null, message: String? = null) {
    requireStorage()
    try { db.save(state,kind,message);lastSavedState=JSONObject(state.toString()) }
    catch(error:Exception) { state=JSONObject(lastSavedState.toString());latchStorageFailure();throw IllegalStateException(storageFault,error) }
    val value = snapshot()
    listener?.invoke(value)
    notification()
  }
  @Synchronized fun importBank(): Map<String, Any?> {
    requireStorage()
    if (state.optString("status") == "running") return pause("请先暂停再准备题库")
    db.ensureBank()
    clearGenericForSwitch();cancelProfileCallbacks();coordinator=null
    state=JSONObject().put("status","idle").put("total",100).put("answered",0).put("cloudCalls",0)
      .put("reason","5000 道合成测试题已准备，原任务已结束")
    save("bank", "5000 道合成测试题已在手机本地建立索引")
    return snapshot()
  }
  @Synchronized fun importBankJson(json: String): Map<String,Any?> {
    requireStorage()
    check(state.optString("status")!="running") { "请先暂停任务再导入题库" }
    val entries=BankJsonImporter.parse(json)
    val version="imported-"+System.currentTimeMillis()
    db.replaceBank(entries,version)
    clearGenericForSwitch();cancelProfileCallbacks();coordinator=null
    state=JSONObject().put("status","idle").put("total",100).put("answered",0).put("cloudCalls",0)
      .put("reason","已导入 ${entries.size} 道题，原任务已结束")
    save("bank","题库校验通过并完整导入 ${entries.size} 道题")
    return snapshot()
  }
  fun getAiConfig(): Map<String,Any?> = aiSettings.summary()
  @Synchronized fun setAiConfig(config: Map<String,Any?>): Map<String,Any?> {
    check(state.optString("status")!="running") { "请先暂停任务再修改接口设置" }
    return aiSettings.save(config)
  }
  @Synchronized fun clearAiConfig(): Map<String,Any?> {
    check(state.optString("status")!="running") { "请先暂停任务再清除接口设置" }
    return aiSettings.clear()
  }
  fun requestCandidate(question: Map<String,Any?>): Map<String,Any?> {
    val config: Map<String,String>
    synchronized(this) {
      requireStorage()
      check(state.optString("status")!="running") { "请先暂停任务，候选仅供人工复核" }
      val stem=question["stem"] as? String ?: ""
      val options=(question["options"] as? List<*>)?.map { it as? String ?: "" }.orEmpty()
      require(stem.isNotBlank() && stem.length<=8000 && options.size in 2..8 && options.all { it.isNotBlank() && it.length<=2000 } && options.toSet().size==options.size) { "题目或选项不完整" }
      check(state.optInt("cloudCalls") < 5) { "本轮已达 5 次辅助上限，请人工复核" }
      config=aiSettings.config()
      state.put("cloudCalls",state.optInt("cloudCalls")+1)
      save("ai", "按手动请求发送题目与选项，返回内容只供人工复核")
    }
    // Background Expo AsyncFunction: never blocks the service tick or holds the action lock over IO.
    return AiCandidateClient.request(config,question)
  }
  @Synchronized fun createRun(count: Int, seed: Long): Map<String, Any?> {
    requireStorage()
    require(count == 1 || count == 100) { "本测试版本仅支持 1 题或 100 题" }
    check(state.optString("status") != "running") { "请先停止当前任务" }
    clearGenericForSwitch();cancelProfileCallbacks();coordinator=null
    db.ensureBank()
    state = JSONObject().put("status", "ready").put("runId", UUID.randomUUID().toString())
      .put("total", count).put("answered", 0).put("seed", seed).put("cloudCalls",0).put("bankVersion",db.version())
    save("prepare", "已准备随机 $count 题，题目与选项均重排")
    return snapshot()
  }
  @Synchronized fun start(): Map<String, Any?> {
    check(!state.optBoolean("manualDraft")) { "请先进入题目，再点击浮窗开始；重新打开应用后需重新准备" }
    check(state.optString("billingMode")!="paid") { "请通过付费准入开始答题" }
    requireStorage()
    cancelSamplingForRun()
    generic?.let { db.requireRunAllowance(it.facts.runId);state.put("billingTracked",true);it.start();return snapshot() }
    coordinator?.let { c ->
      db.requireRunAllowance(c.facts.runId);state.put("billingTracked",true)
      if(service==null || !granted()) { c.pause(accessibilityUnavailableMessage());return snapshot() }
      verifyProfileTarget(c)
      c.start();launchProfile(c);return snapshot()
    }
    if (state.optString("status") != "ready") return pause("请先准备一轮测试")
    if (service == null || !granted()) return pause(accessibilityUnavailableMessage())
    if (!installed()) return pause("请先安装自建答题测试软件")
    state.put("status", "running").remove("reason")
    save("start", "开始在独立测试软件中答题，已知题仅查本地题库")
    launch(true)
    return snapshot()
  }
  /** Invoked off the UI and accessibility threads. Free runs keep their
   * existing synchronized path; paid admission performs HTTP without the
   * engine lock, then checks the same run before launching. */
  fun startAsync(resuming:Boolean=false,fromCurrentPage:Boolean=false,expectedRunId:String?=null,expectedDriver:GenericDriver?=null,expectedAttempt:Any?=null):Map<String,Any?> {
    val selected=synchronized(this) {
      if(!fromCurrentPage) failureRead=null
      if(fromCurrentPage) {
        val g=generic
        check(expectedAttempt!=null && floatingStartAttempt===expectedAttempt && g!=null && g===expectedDriver && g.facts.runId==expectedRunId) {
          "任务已切换，请重新点浮窗开始"
        }
        g.requirePreparedStart() // Reject a cancelled/changed grant before any paid reservation.
      }
      if(state.optBoolean("manualDraft")) { check(manualDraft!=null) { "应用已重启，请重新准备答题浮窗" };return snapshot() }
      if(generic!=null && !fromCurrentPage) {
        requireStorage();paidStart.invalidate();cancelSamplingForRun();generic!!.prepareManual();return snapshot()
      }
      if(state.optString("billingMode")!="paid") return if(resuming) resume() else start()
      requireStorage();check(BuildConfig.BILLING_ADMISSION_ENABLED) { "付费功能尚未开放" }
      check(!state.optBoolean("paidCancelled")) { "本次答题已结束，请开始新一轮" }
      val g=checkNotNull(generic)
      check(g.facts.status in setOf("ready","paused") || g.facts.status=="stopped" && g.facts.pendingSubmit) { "请先暂停本次答题" }
      check(service!=null && granted()) { accessibilityUnavailableMessage() }
      check(GenericBinding.installed(context,g.binding.packageName)==g.binding) { "目标软件已更新，请重新开始" }
      check(workspaces.get(g.facts.workspaceId).activeBankRevision==g.facts.bankRevision) { "答题资料已更新，请重新开始" }
      val owner=state.getString("paidOwner");val binding=state.getString("paidBinding");val before=g.facts
      check(PaidSubmissionGuard.binding(before,PaidTarget(g.binding.packageName,g.binding.version,g.binding.signer))==binding)
      state.put("paidAttempted",true);writeState()
      Pair(Triple(before,owner,binding),paidStart.ticket())
    }
    val (run,ticket)=selected;val (facts,owner,binding)=run
    paidStart.start(ticket,{
      try { when(paidStore.read(facts.runId)?.phase) {
        null,"reserved" -> { paidGate.reserve(facts.runId,owner,binding);true }
        "unknown" -> { check(facts.pendingSubmit);false }
        "receipt_confirmed","confirmed" -> { paidGate.settle(facts.runId,owner,binding);false }
        else -> error("本次付款记录正在处理，请稍后重试")
      } } catch (error:java.io.IOException) {
        throw IllegalStateException("暂时无法联网核对答题权益，请稍后重试",error)
      }
    },{
      floatingStartAttempt===expectedAttempt && generic===expectedDriver &&
        state.optString("billingMode")=="paid" && state.optString("paidOwner")==owner &&
        state.optString("paidBinding")==binding && generic?.facts==facts
    },{
      val runner=checkNotNull(generic)
      try { runner.start() }
      catch(error:Exception) {
        // start() can persist running before Android opens the target. Keep
        // the reservation and stop the runner while still under the lock.
        runCatching { runner.pause("无法打开答题软件，请检查后继续") }
        throw error
      }
    },{ reserved ->
      // A pause keeps the reservation for the same task, so Continue can
      // reuse it. Only a stopped/replaced task may release before submission.
      val keep=synchronized(this) {
        state.optString("billingMode")=="paid" && state.optString("runId")==facts.runId &&
          state.optString("paidOwner")==owner && state.optString("paidBinding")==binding &&
          generic?.facts?.status=="paused"
      }
      if(reserved && !keep)paidGate.release(facts.runId,owner,binding)
    })
    return snapshot()
  }
  fun resumeAsync():Map<String,Any?> = startAsync(true)
  @Synchronized fun floatingTaskState():FloatingTaskState? {
    if(storageFault!=null) return null
    val floating=if(manualDraft!=null) {
      FloatingTaskState(state.getString("runId"),"",state.optString("status"),"waiting_for_question",0,false,null)
    } else {
      val g=generic ?: return null
      val f=g.facts
      if(f.status=="completed" || f.status=="stopped" && !f.pendingSubmit) return null
      FloatingTaskState(f.runId,g.binding.packageName,f.status,f.phase,f.submittedCount,f.pendingSubmit,f.reason)
    }
    val report=failureRead?.takeIf { it.runId==floating.runId && service?.windowEpoch==it.evidence.windowEpoch }
    return floating.copy(failureReadId=report?.id,failureReadPackage=report?.evidence?.targetPackage)
  }
  @Synchronized fun copyFailureRead(runId:String,reportId:String,source:QuizAccessibilityService):Boolean {
    val report=failureRead ?: return false
    if(service!==source || !granted() || storageFault!=null || state.optString("runId")!=runId ||
      state.optString("status") !in setOf("ready","paused")) return false
    if((context.getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager).isKeyguardLocked ||
      !(context.getSystemService(Context.POWER_SERVICE) as PowerManager).isInteractive) return false
    val root=source.foregroundRoot() ?: return false
    val matches=try { report.matches(runId,reportId,root.packageName?.toString(),root.windowId,source.windowEpoch) }
      finally { root.recycle() }
    if(!matches) return false
    val clip=ClipData.newPlainText("每日百题识别信息",report.evidence.text)
    clip.description.extras=PersistableBundle().apply { putBoolean("android.content.extra.IS_SENSITIVE",true) }
    val clipboard=context.getSystemService(ClipboardManager::class.java) ?: return false
    clipboard.setPrimaryClip(clip)
    return true
  }
  @Synchronized fun startFromCurrentPage(done:(String?)->Unit):(String)->Boolean {
    val attempt=Any()
    failureRead=null
    floatingStartAttempt=attempt
    fun finish(message:String?,driver:GenericDriver?=null) {
      val report=synchronized(this) {
        if(floatingStartAttempt!==attempt) false
        else { floatingStartAttempt=null;driver==null || generic===driver }
      }
      done(message.takeIf { report })
    }
    try {
      requireStorage()
      val draftBeforeBinding=manualDraft
      val draftTargetBeforeBinding=state.optString("manualTargetPackage")
      manualDraft?.let { (workspaceId,revision) ->
        val foreground=service?.sampleForegroundWindow()
        check(canPrepareOnForeground(foreground)) { "请先打开需要答题的软件并进入题目" }
        check(draftTargetBeforeBinding.isEmpty() || foreground==draftTargetBeforeBinding) { "请回到已选择的答题软件，再点浮窗开始" }
        check(workspaces.get(workspaceId).activeBankRevision==revision) { "答题资料已更新，请重新准备" }
        createGenericRun(mapOf("workspaceId" to workspaceId,"packageName" to foreground!!))
      }
      val g=checkNotNull(generic) { "请先在每日百题准备本轮答题" }
      check(g.facts.status in setOf("ready","paused") || g.facts.status=="stopped" && g.facts.pendingSubmit) { "本轮答题已经开始或结束" }
      // Reserved proves the pending intent never reached Android dispatch. Clear it before
      // obtaining a fresh grant, so this path requires a real quiz instead of receipt-only pages.
      // Unknown is never inferred to be undispatched and retains receipt-only reconciliation.
      if(state.optString("billingMode")=="paid" && g.facts.pendingSubmit &&
        g.facts.status in setOf("paused","stopped") && paidStore.read(g.facts.runId)?.phase=="reserved") g.acknowledgeUnsubmitted()
      val expectedId=g.facts.runId
      val startedOn=service
      g.requestStart { result -> result.fold(onSuccess={
        paidWorker.execute {
          try { startAsync(true,true,expectedId,g,attempt);finish(null,g) }
          catch(error:Exception) { finish(error.message ?: "未能开始，请核对当前页面后重试",g) }
        }
      },onFailure={ failure ->
        // Defer rollback until any pause/stop that cancelled the read has finished.
        Handler(Looper.getMainLooper()).post { synchronized(this) {
          if(floatingStartAttempt!==attempt || generic!==g || g.facts.status in setOf("completed","stopped")) {
            finish(null);return@synchronized
          }
          if(draftBeforeBinding!=null && g.facts.status in setOf("ready","paused") && !g.facts.pendingSubmit && !state.optBoolean("paidAttempted")) {
            try {
              val wasPaused=g.facts.status=="paused"
              prepareDraft(draftBeforeBinding.first,targetPackage=draftTargetBeforeBinding.takeIf(String::isNotEmpty))
              if(wasPaused)pause("已暂停，进入题目后可从浮窗继续")
            } catch(error:Exception) { finish(error.message ?: "请重新准备答题浮窗");return@synchronized }
          }
          val evidence=(failure as? ManualRecognitionFailure)?.evidence
          val feedbackRunId=state.optString("runId")
          if(evidence!=null && feedbackRunId.isNotEmpty() && service===startedOn &&
            startedOn?.windowEpoch==evidence.windowEpoch && storageFault==null) {
            failureRead=BoundFailureReadEvidence(feedbackRunId,UUID.randomUUID().toString(),evidence)
          }
          finish(failure.message ?: "当前页面无法开始，请进入答题页面")
        } }
      }) }
      return { reason -> synchronized(this) {
        if(floatingStartAttempt===attempt && generic===g && g.isAwaitingStart()) { pause(reason);true }
        else false
      } }
    } catch(error:Exception) {
      finish(error.message ?: "当前无法开始，请核对后重试")
      return { false }
    }
  }
  @Synchronized fun pause(reason:String="已手动暂停",expectedRunId:String?=null):Map<String,Any?> {
    check(expectedRunId==null || state.optString("runId")==expectedRunId) { "答题任务已变化，请刷新后重试" }
    paidStart.invalidate()
    cancelSamplingForRun("任务状态已调整，本次页面采样已取消。")
    if(storageFault!=null) return snapshot()
    cancelProfileCallbacks()
    generic?.let { it.pause(reason);return snapshot() }
    coordinator?.let { it.pause(reason);return snapshot() }
    if (state.optString("status") !in listOf("completed","stopped","idle")) {
      state.put("status", "paused").put("reason", reason)
      aiFuture?.cancel(true); aiFuture=null
      if(state.optString("stage")=="ai_pending") state.remove("stage")
      save("pause", reason)
    }
    return snapshot()
  }
  @Synchronized fun resume(): Map<String, Any?> {
    check(!state.optBoolean("manualDraft")) { "请进入题目后点浮窗继续" }
    check(state.optString("billingMode")!="paid") { "请通过付费准入继续答题" }
    if(storageFault!=null) return snapshot()
    cancelSamplingForRun()
    generic?.let { db.requireRunAllowance(it.facts.runId);state.put("billingTracked",true);it.start();return snapshot() }
    coordinator?.let { c ->
      db.requireRunAllowance(c.facts.runId);state.put("billingTracked",true)
      if(service==null || !granted()) { c.pause(accessibilityUnavailableMessage());return snapshot() }
      verifyProfileTarget(c);c.resume();launchProfile(c);return snapshot()
    }
    if (state.optString("status") != "paused") return snapshot()
    if (service == null || !granted()) return pause(accessibilityUnavailableMessage())
    if (!installed()) return pause("自建测试软件尚未安装")
    // A run paused before its first launch must start a new target session exactly once.
    val firstLaunch = !state.optBoolean("launched")
    state.put("status", "running").remove("reason")
    save("resume", "已继续，先回读核对页面与上次动作")
    launch(firstLaunch)
    return snapshot()
  }
  @Synchronized fun stop(expectedRunId:String?=null):Map<String,Any?> {
    check(expectedRunId==null || state.optString("runId")==expectedRunId) { "答题任务已变化，请刷新后重试" }
    failureRead=null
    paidStart.invalidate()
    cancelSamplingForRun("任务已停止，本次页面采样已取消。")
    if(storageFault!=null) return snapshot()
    cancelProfileCallbacks()
    generic?.let {
      it.stop()
      if(state.optString("billingMode")=="paid" && state.optBoolean("paidAttempted")) {
        if(it.facts.pendingSubmit && paidStore.read(it.facts.runId)?.phase=="reserved")it.acknowledgeUnsubmitted()
        reconcileEndedPaidRun()
      }
      return snapshot()
    }
    coordinator?.let { it.stop();return snapshot() }
    aiFuture?.cancel(true); aiFuture=null
    manualDraft=null;state.remove("manualDraft");state.remove("manualTargetPackage")
    state.put("status", "stopped").put("phase","stopped").put("reason", "任务已停止，不再执行动作")
    save("stop", "任务已停止")
    return snapshot()
  }
  private fun reconcileEndedPaidRun() {
    val facts=state.optJSONObject("genericRun") ?: return
    if(state.optString("billingMode")!="paid" || !state.optBoolean("paidAttempted") ||
      state.optBoolean("paidCancelled") || facts.optBoolean("pendingSubmit")) return
    val id=facts.getString("runId");val owner=state.getString("paidOwner");val binding=state.getString("paidBinding")
    when(paidStore.read(id)?.phase) {
      "receipt_confirmed" -> schedulePaidSettlement(id,owner,binding)
      null,"reserved","releasing","released" -> if(facts.optString("status")=="stopped") schedulePaidCancellation(id,owner,binding)
    }
  }
  private fun schedulePaidCancellation(id:String,owner:String,binding:String) {
    paidWorker.execute {
      runCatching {
        val safe=synchronized(this) {
          !state.optBoolean("paidCancelled") && state.optString("runId")==id && state.optString("paidOwner")==owner && state.optString("paidBinding")==binding &&
            generic?.facts?.status=="stopped" && generic?.facts?.pendingSubmit==false &&
            paidStore.read(id)?.phase in setOf(null,"reserved","releasing","released")
        }
        if(safe) {
          paidGate.cancelUnsubmitted(id,owner,binding)
          synchronized(this) {
            if(state.optString("runId")==id && generic?.facts?.status=="stopped" && generic?.facts?.pendingSubmit==false) {
              state.put("paidCancelled",true);writeState()
            }
          }
        }
      }
    }
  }
  private fun launch(reset: Boolean) {
    launchGrace = System.currentTimeMillis() + 4000
    val intent = context.packageManager.getLaunchIntentForPackage(TARGET) ?: return
    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
    if (reset) {
      val extras=SyntheticTargetAdapter.extras(state.optInt("total",100),state.optLong("seed"))
      intent.putExtra("new_exam",extras["new_exam"] as Boolean).putExtra("count",extras["count"] as Int).putExtra("seed",extras["seed"] as Long)
    }
    state.put("launched", true); writeState()
    context.startActivity(intent)
  }
  @Synchronized fun openSettings(): Map<String, Any?> {
    pause("正在设置辅助服务")
    val component=ComponentName(context,QuizAccessibilityService::class.java)
    val list=Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
      .putExtra(":settings:fragment_args_key",component.flattenToString())
      .putExtra(":settings:show_fragment_args",android.os.Bundle().apply { putString(":settings:fragment_args_key",component.flattenToString()) })
    context.startActivity(list)
    return snapshot()
  }
  @Synchronized fun openTarget(): Map<String, Any?> {
    check(!state.optBoolean("manualDraft")) { "请自行打开需要答题的软件，进入题目后点浮窗开始" }
    generic?.let { it.open();return snapshot() }
    coordinator?.let { launchProfile(it);return snapshot() }
    if (installed()) launch(false)
    return snapshot()
  }
  @Synchronized fun connected(s: QuizAccessibilityService) { failureRead=null;profileReader?.close();service = s; profileReader=ScreenReader(s);profileExecutor=null;if(manualDraft!=null && state.optString("phase")=="waiting_for_question"){state.put("status","ready");state.remove("reason");runCatching { writeState() }.onFailure { latchStorageFailure() }};listener?.invoke(snapshot()) }
  @Synchronized fun disconnected(s:QuizAccessibilityService) { if(service!==s)return;failureRead=null;cancelSamplingForRun("辅助服务已断开，本次页面采样已取消。");cancelProfileCallbacks();profileReader?.close();service = null;profileReader=null;profileExecutor=null;pause(accessibilityUnavailableMessage()) }

  @Synchronized fun getSamplingState(): Map<String,Any?> = sampler.snapshot()
  @Synchronized fun listSamplingTargets(): List<Map<String,Any?>> = sampler.listTargets()
  @Synchronized fun selectSamplingTarget(packageName: String): Map<String,Any?> {
    requireStorage(); check(state.optString("status")!="running") { "请先暂停答题任务再选择适配软件" }
    return sampler.choose(packageName)
  }
  @Synchronized fun openSamplingTarget() { check(state.optString("status")!="running") { "请先暂停当前任务" }; sampler.openTarget() }
  @Synchronized fun startSampling(options: Map<String,Any?>): Map<String,Any?> {
    requireStorage()
    return sampler.arm(options, if(granted()) service else null, state.optString("status")=="running") { token -> captureSampling(token) }
  }
  @Synchronized private fun captureSampling(token: Long) {
    sampler.capture(token, if(storageFault==null && granted()) service else null, state.optString("status")=="running")
  }
  @Synchronized fun cancelSampling(): Map<String,Any?> = sampler.cancel()
  @Synchronized fun deleteSamplingSample(id: String): Map<String,Any?> = sampler.delete(id)
  @Synchronized fun prepareSamplingExport(): ByteArray {
    check(state.optString("status")!="running") { "请先暂停答题任务再导出资料" }
    return sampler.exportBytes()
  }
  private fun cancelSamplingForRun(reason: String="答题任务启动前，已取消页面采样。") {
    if(samplerDelegate.isInitialized()) sampler.cancelPending(reason)
  }

  /** Tick is native service-owned. UI timers and Activity lifecycle never drive execution. */
  @Synchronized fun tick() {
    if(samplerDelegate.isInitialized()) sampler.observeEnvironment(if(granted()) service else null,storageFault==null)
    if(storageFault!=null) return
    if(generic!=null) { generic!!.tick();return }
    if(coordinator!=null) { tickProfile();return }
    if (state.optString("status") != "running") return
    if (!granted()) { pause("辅助授权已撤销"); return }
    if (state.optString("bankVersion")!=db.version()) { pause("题库版本已变化，需重新准备任务"); return }
    if ((context.getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager).isKeyguardLocked ||
      !(context.getSystemService(Context.POWER_SERVICE) as PowerManager).isInteractive) { pause("手机已锁屏或熄屏"); return }
    val root = service?.rootInActiveWindow
    val now = System.currentTimeMillis()
    if (root == null) { if (nullSince == 0L) nullSince = now
      if (now > launchGrace && now-nullSince > 3500) pause("当前页面不可读取，请核对后继续")
      return
    }
    nullSince = 0
    val packageName = root.packageName?.toString()
    if (packageName != TARGET) {
      if (now > launchGrace) pause(if (packageName == context.packageName) "已返回控制台，请核对后继续" else "已离开自建测试软件，保护暂停")
      return // Never traverse another application's content.
    }
    val nodes = HashMap<String, AccessibilityNodeInfo>()
    val budget = AccessibilityTreeBudget()
    fun walk(node: AccessibilityNodeInfo, depth: Int) {
      if (!budget.enter(depth, nodes.size)) return
      node.viewIdResourceName?.substringAfter(":id/")?.let { nodes[it] = node }
      for (i in 0 until node.childCount) { if (!budget.childSlot(nodes.size)) break; node.getChild(i)?.let { walk(it,depth+1) } }
    }
    walk(root, 0)
    if (budget.exhausted()) { pause("页面结构超过读取预算"); return }
    if (nodes["exam_marker"]?.text?.toString() != "合成题独立测试 v1") { pause("测试软件版本无法确认"); return }
    nodes["exam_result"]?.text?.toString()?.let { result ->
      val m = Regex("测验完成 · 已答 (\\d+) 题 · 得分 (\\d+)").matchEntire(result)
      val total = state.optInt("total")
      if (m == null || m.groupValues[1].toInt()!=total || m.groupValues[2].toInt() !in 0..total || state.optString("stage")!="await_submit" || state.optInt("answered")!=total-1) {
        pause("结果页与任务进度不一致，请人工核对"); return
      }
      state.put("answered",total).put("correct",m.groupValues[2].toInt()).put("status","completed")
      state.remove("stage"); state.remove("stem")
      save("complete", "已回读独立测试软件的判分：${m.groupValues[2]} / $total")
      return
    }
    val stem = nodes["question_stem"]?.text?.toString()
    val progress = nodes["exam_progress"]?.text?.toString()?.let { Regex("第 (\\d+) / (\\d+) 题").matchEntire(it) }
    if (stem == null || progress == null || progress.groupValues[2].toInt()!=state.optInt("total")) {
      if (now > launchGrace) pause("题目或进度不完整，未执行动作")
      return
    }
    val ordinal = progress.groupValues[1].toInt()
    val stage = state.optString("stage")
    val lastStem = state.optString("stem")
    if (stage == "await_submit") {
      if (stem != lastStem && ordinal == state.optInt("answered")+2) {
        state.put("answered",state.optInt("answered")+1); state.remove("stage"); state.remove("awaitText")
        save("confirm", "第 ${state.optInt("answered")} 题已提交，已回读下一题")
      } else { if (now-state.optLong("actionAt")>4000) pause("提交后未确认跳转，不重复点击"); return }
    }
    if (ordinal != state.optInt("answered")+1) { pause("页面进度与已确认记录不一致"); return }
    val options = (0..3).mapNotNull { nodes["option_$it"] }
    val texts = options.map { it.text?.toString() ?: "" }
    if (stage in listOf("ai_pending","ai_ready")) {
      val oldOptions=state.optString("aiOptions")
      if(stem!=lastStem || texts!=SyntheticBank.array(oldOptions.ifEmpty { "[]" }) || nodes["question_kind"]?.text?.toString()!=state.optString("aiKind")) { pause("辅助返回前题面、题型或选项已变化，结果已隔离"); return }
      if(stage=="ai_ready") pause("辅助候选已返回并完成页面回读；题库外或近似匹配需人工复核，未自动提交")
      return
    }
    val q = db.find(stem) ?: run { beginMissingReview(stem,texts,nodes["question_kind"]?.text?.toString().orEmpty()); return }
    val observedKind=nodes["question_kind"]?.text?.toString()
    val requiredKind=mapOf("single" to "单选题","multiple" to "多选题","boolean" to "判断题")[q.type]
    if(requiredKind==null || observedKind!=requiredKind) { pause("页面题型与题库不一致或缺失，请核对题库后重新准备"); return }
    if (texts.size != q.options.size || texts.toSet()!=q.options.toSet() || texts.toSet().size!=texts.size) {
      pause("选项与题库内容不一致，未执行动作"); return
    }
    if (stage == "await_option") {
      if (lastStem!=stem) { pause("选项确认时页面已变化"); return }
      val selectedNode = options.firstOrNull { it.text?.toString()==state.optString("awaitText") }
      if (selectedNode?.isChecked != true) {
        if (now-state.optLong("actionAt")>3500) pause("选中状态未确认，不重复点击")
        return
      }
      state.remove("stage"); state.remove("awaitText"); save("confirm", "选中状态已回读确认")
    }
    if (options.any { it.isChecked && it.text.toString() !in q.answers }) { pause("存在与题库不符的选中项，请人工核对"); return }
    val next = options.firstOrNull { it.text.toString() in q.answers && !it.isChecked }
    if (state.optString("stem") != stem) state.remove("scrolls")
    state.put("stem",stem)
    if (next != null) {
      if (!next.isClickable || !next.isEnabled || !next.isVisibleToUser) { pause("答案控件当前不可操作"); return }
      state.put("stage","await_option").put("awaitText",next.text.toString()).put("actionAt",now)
      save("intent", "第 $ordinal 题：本地精确匹配，准备选择一个选项")
      if (!allowedToAct() || !next.performAction(AccessibilityNodeInfo.ACTION_CLICK)) pause("点击未被系统接受或前景已变化，保护暂停")
    } else {
      val submit = nodes["submit_question"]
      if (submit != null && !submit.isVisibleToUser && state.optInt("scrolls") < 2) {
        val scroll = nodes["exam_scroll"]
        state.put("scrolls",state.optInt("scrolls")+1)
        save("intent","提交区域在屏幕下方，正在自建测试页内滚动核对")
        if (!allowedToAct() || scroll?.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD) != true) pause("页面无法滚动到提交区域")
        return
      }
      if (submit == null || !submit.isClickable || !submit.isEnabled || !submit.isVisibleToUser) { pause("提交按钮不可确认"); return }
      state.put("stage","await_submit").put("actionAt",now)
      save("intent", "第 $ordinal 题：所有选中项已确认，准备提交")
      if (!allowedToAct() || !submit.performAction(AccessibilityNodeInfo.ACTION_CLICK)) pause("提交未被系统接受或前景已变化，保护暂停")
    }
  }

  /** Genuine missing-match fallback. AI is data only; insufficient local evidence never clicks. */
  private fun beginMissingReview(stem: String, options: List<String>, type: String) {
    if(options.size !in 2..8 || options.any { it.isBlank() } || options.toSet().size!=options.size) { pause("题目选项不完整，未发送辅助请求"); return }
    val config=try { aiSettings.config() } catch (_:Exception) { pause("本地未找到完整题目；辅助未配置，保护暂停"); return }
    if(state.optInt("cloudCalls")>=5) { pause("本轮辅助次数已达上限，需人工复核"); return }
    val canonicalType=mapOf("单选题" to "single","多选题" to "multiple","判断题" to "boolean")[type]
    if(canonicalType==null) { pause("题型无法确认，未发送辅助请求"); return }
    val candidates=db.candidates(stem,options,canonicalType)
    val question=mapOf("stem" to stem,"options" to options,"type" to canonicalType,"candidates" to candidates)
    val runId=state.optString("runId")
    state.put("stem",stem).put("stage","ai_pending").put("aiOptions",org.json.JSONArray(options).toString()).put("aiKind",type)
      .put("cloudCalls",state.optInt("cloudCalls")+1)
    save("ai","本地完整匹配缺失，已发送题面与 ${candidates.size} 条本地近似候选供辅助复核")
    aiFuture=aiWorker.submit {
      try {
        val result=AiCandidateClient.request(config,question)
        synchronized(this) {
          if(state.optString("runId")==runId && state.optString("status")=="running" && state.optString("stage")=="ai_pending") {
            state.put("aiCandidate",JSONObject(result)).put("stage","ai_ready")
            save("ai","候选已返回，等待原生回读同一题面与选项；尚未执行答案动作")
          }
        }
      } catch (_:Exception) {
        synchronized(this) {
          if(state.optString("runId")==runId && state.optString("status")=="running" && state.optString("stage")=="ai_pending")
            pause("辅助请求失败、超时或候选无法校验，保护暂停")
        }
      }
    }
  }

  private fun allowedToAct(): Boolean = storageFault==null && state.optString("status")=="running" && granted() &&
    service?.rootInActiveWindow?.packageName?.toString()==TARGET &&
    !(context.getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager).isKeyguardLocked &&
    (context.getSystemService(Context.POWER_SERVICE) as PowerManager).isInteractive

  private fun cancelProfileCallbacks() {
    generic?.cancelPending()
    profileGeneration++;profileReadPending=false;profileReader?.cancelPending();profileExecutor?.cancelPending();profileExecutor=null
    aiFuture?.cancel(true);aiFuture=null
  }
  private fun persistProfile(f:RunFacts,intent:ActionIntent?) {
    state.put("mode","production").put("profileRun",RunCodec.encode(f)).put("status",f.status).put("phase",f.phase)
      .put("runId",f.runId).put("workspaceId",f.workspaceId).put("bankRevision",f.bankRevision).put("profileId",f.profileId)
      .put("profileVersion",f.profileVersion).put("profileHash",f.profileHash).put("totalKnown",f.totalKnown).put("total",f.total ?: 0)
      .put("answered",f.submittedCount).put("reason",f.reason)
    state.remove("seed");state.remove("correct");state.remove("result")
    f.result?.let { state.put("result",JSONObject().put("completed",it.completed).put("submittedCount",it.submittedCount).put("score",it.score).put("evidenceKind",it.evidenceKind)) }
    if(intent!=null) state.put("pendingIntent",JSONObject().put("id",intent.id).put("frameId",intent.frameId).put("fingerprint",intent.fingerprint).put("operation",intent.operation).put("targetRef",intent.targetRef).put("evidence",intent.evidence))
    save(if(intent!=null) "intent" else "profile_state",intent?.evidence ?: f.reason ?: "任务阶段：${f.phase}")
  }
  private fun makeCoordinator(p:ProfileDefinition,f:RunFacts)=ProfileRunCoordinator(p,f,QuestionMatcher(workspaces),::persistProfile)
  private fun makeGeneric(binding:GenericBinding,f:RunFacts):GenericDriver {
    if(state.optString("billingMode")!="paid") return GenericDriver(context,workspaces,binding,f,{service},{storageFault==null && granted()},this,::persistGeneric)
    check(BuildConfig.BILLING_ADMISSION_ENABLED) { "付费功能尚未开放" }
    val owner=state.getString("paidOwner");val token=state.getString("paidBinding")
    check(PaidSubmissionGuard.binding(f,PaidTarget(binding.packageName,binding.version,binding.signer))==token)
    return GenericDriver(context,workspaces,binding,f,{service},{storageFault==null && granted()},this,::persistGeneric,
      { next,target,stem,intent -> persistPaidGeneric(next,target,stem,intent,owner,token) },
      { paidGate.mayAdvance(f.runId,owner,token) },
      { intent -> beforePaidDispatch(intent,owner,token) },
      { intent -> rejectedPaidDispatch(intent,owner,token) })
  }
  private fun rejectedPaidDispatch(intent:ActionIntent,owner:String,token:String) {
    if(state.optString("paidPendingIntentId")==intent.id) runCatching { db.markPaidSubmissionRejected(intent,owner,token) }
  }
  private fun beforePaidDispatch(intent:ActionIntent,owner:String,token:String):Boolean {
    if(state.optString("billingMode")!="paid" || state.optString("runId")!=intent.runId) return false
    val facts=RunCodec.decode(state.getJSONObject("genericRun"))
    if(!facts.pendingSubmit || facts.submittedCount>0) return true
    if(state.optString("paidPendingIntentId")!=intent.id) return false
    return try { db.markPaidSubmissionDispatched(intent,owner,token);true } catch(_:Exception) { false }
  }
  /** Paid snapshots enter from GenericCoordinator only; the user-facing bridge
   * cannot forge a receipt. Persist the intent/first receipt atomically. */
  private fun persistPaidGeneric(f:RunFacts,binding:GenericBinding,stem:String?,intent:ActionIntent?,owner:String,token:String) {
    check(BuildConfig.BILLING_ADMISSION_ENABLED && state.optString("billingMode")=="paid")
    check(state.optString("paidOwner")==owner && state.optString("paidBinding")==token && state.optString("runId")==f.runId)
    if(f.status!="running") { paidStart.invalidate();paidGate.pause(f.runId) }
    val before=RunCodec.decode(state.getJSONObject("genericRun"));val next=JSONObject(state.toString())
    next.remove("profileRun");next.remove("profileId");next.remove("profileVersion");next.remove("profileHash");next.remove("seed");next.remove("correct");next.remove("result")
    next.put("mode","production").put("genericRun",RunCodec.encode(f)).put("genericTarget",binding.json())
      .put("status",f.status).put("phase",f.phase).put("runId",f.runId).put("workspaceId",f.workspaceId).put("bankRevision",f.bankRevision)
      .put("totalKnown",f.totalKnown).put("total",f.total ?: 0).put("answered",f.submittedCount).put("reason",f.reason).put("cloudCalls",0)
    if(stem!=null)next.put("stem",stem)
    if(intent!=null && f.pendingSubmit && f.submittedCount==0)next.put("paidPendingIntentId",intent.id)
    else if(!f.pendingSubmit)next.remove("paidPendingIntentId")
    f.result?.let { next.put("result",JSONObject().put("completed",it.completed).put("submittedCount",it.submittedCount).put("score",it.score).put("evidenceKind",it.evidenceKind)) }
    val firstReceipt=before.pendingSubmit && !f.pendingSubmit && before.submittedCount==0 && f.submittedCount==1
    val clearPending=before.pendingSubmit && !f.pendingSubmit && before.submittedCount==0 && f.submittedCount==0
    try {
      when {
        intent!=null && f.pendingSubmit && f.submittedCount==0 -> db.savePaidSubmissionIntent(next,intent,owner,token)
        firstReceipt -> db.savePaidSubmissionReceipt(next,owner,token)
        clearPending && paidStore.read(f.runId)?.phase=="unknown" -> {
          check(paidHumanVerdict) { "请先本人核对上次提交" };db.savePaidHumanUnsubmitted(next,owner,token)
        }
        else -> db.save(next,"automatic",f.reason ?: "答题进度：${f.submittedCount}")
      }
      state=next;lastSavedState=JSONObject(next.toString())
    } catch(error:Exception) { state=JSONObject(lastSavedState.toString());latchStorageFailure();throw IllegalStateException(storageFault,error) }
    runCatching { listener?.invoke(snapshot()) };runCatching { notification() }
    if(firstReceipt) schedulePaidSettlement(f.runId,owner,token)
  }
  @Synchronized private fun schedulePaidSettlement(id:String,owner:String,binding:String) {
    if(settlingPaidRunId==id) return
    settlingPaidRunId=id
    paidWorker.execute {
      try {
        val canContinue=synchronized(this) {
          if(state.optString("runId")!=id || state.optString("paidOwner")!=owner || state.optString("paidBinding")!=binding)
            return@execute
          storageFault==null && state.optString("status")=="running" &&
            state.optJSONObject("genericRun")?.optString("receiptCheckReturnStatus").isNullOrEmpty()
        }
        if(canContinue) paidGate.settle(id,owner,binding)
        else paidGate.confirmReceipt(id,owner,binding)
      } catch(_:Exception) {
        synchronized(this) {
          if(state.optString("runId")==id && state.optString("status")=="running")
            runCatching { generic?.pause("本次提交已记录，请联网后继续") }
        }
      } finally {
        synchronized(this) { if(settlingPaidRunId==id) settlingPaidRunId=null }
      }
    }
  }
  private fun persistGeneric(f:RunFacts,binding:GenericBinding,stem:String?) {
    state.remove("profileRun");state.remove("profileId");state.remove("profileVersion");state.remove("profileHash");state.remove("seed");state.remove("correct");state.remove("result")
    state.put("mode","production").put("genericRun",RunCodec.encode(f)).put("genericTarget",binding.json())
      .put("status",f.status).put("phase",f.phase).put("runId",f.runId).put("workspaceId",f.workspaceId).put("bankRevision",f.bankRevision)
      .put("totalKnown",f.totalKnown).put("total",f.total ?: 0).put("answered",f.submittedCount).put("reason",f.reason).put("cloudCalls",0)
    if(stem!=null) state.put("stem",stem)
    f.result?.let { state.put("result",JSONObject().put("completed",it.completed).put("submittedCount",it.submittedCount).put("score",it.score).put("evidenceKind",it.evidenceKind)) }
    save("automatic",f.reason ?: "答题进度：${f.submittedCount}")
  }
  @Synchronized fun getBillingStatus():Map<String,Any?> = mapOf(
    "freeRemaining" to db.freeRemaining(),"freeTotal" to 3,"paymentAvailable" to false,
    "version" to context.packageManager.getPackageInfo(context.packageName,0).versionName)
  fun canPrepareOnForeground(packageName:String?):Boolean {
    if(packageName.isNullOrBlank() || packageName==context.packageName || packageName in setOf("android","com.android.systemui","com.android.settings") || packageName.contains("permissioncontroller") || packageName.contains("packageinstaller")) return false
    val home=context.packageManager.resolveActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME),PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo?.packageName
    return packageName!=home && context.packageManager.getLaunchIntentForPackage(packageName)!=null
  }
  @Synchronized private fun prepareDraft(workspaceId:String,requireConnected:Boolean=true,targetPackage:String?=null):Map<String,Any?> = storedMutation {
    check(state.optString("status")!="running") { "请先暂停当前答题" }
    if(requireConnected)check(service!=null && granted()) { accessibilityUnavailableMessage() }
    check(generic?.facts?.pendingSubmit!=true) { "上次提交尚未确认，请先核对" }
    val workspace=workspaces.get(workspaceId)
    val revision=workspace.activeBankRevision ?: error("请先导入答题资料")
    check(workspaces.questions(workspaceId,revision).isNotEmpty()) { "请先导入含有题目和答案的资料" }
    endRunForConfiguration();db.selectWorkspace(workspaceId)
    manualDraft=Pair(workspaceId,revision)
    state.put("manualDraft",true).put("runId",UUID.randomUUID().toString()).put("workspaceId",workspaceId).put("bankRevision",revision)
      .put("manualTargetPackage",targetPackage).put("status","ready").put("phase","waiting_for_question")
    save("prepare","请自行打开题目，再点击浮窗开始")
    snapshot()
  }
  @Synchronized fun prepareOverlayPermission(workspaceId:String):Map<String,Any?> {
    requireNoActiveTask(allowManualDraft=true)
    val existing=manualDraft
    if(existing==null || existing.first!=workspaceId || workspaces.get(workspaceId).activeBankRevision!=existing.second)prepareDraft(workspaceId,false)
    check(generic?.facts?.pendingSubmit!=true && state.optString("phase")=="waiting_for_question") { "准备记录已变化，请重新准备" }
    state.put("status","paused").put("reason","等待系统连接无障碍服务，开启后会自动显示浮窗");writeState();return snapshot()
  }
  private fun prepareNewOverlay(workspaceId:String,targetPackage:String?=null):Map<String,Any?> {
    val prepared=synchronized(this) {
      requireNoActiveTask(allowManualDraft=true)
      prepareDraft(workspaceId,targetPackage=targetPackage)
    }
    return restorePreparedOverlay(prepared["runId"] as String)
  }
  fun prepareCurrentPage(workspaceId:String):Map<String,Any?> = prepareNewOverlay(workspaceId)
  fun restorePreparedOverlay(expectedRunId:String):Map<String,Any?> {
    val prepared=synchronized(this) {
      requireStorage()
      check(state.optString("runId")==expectedRunId && state.optString("phase")=="waiting_for_question") { "准备记录已变化，请重新准备浮窗" }
      val bound=generic?.facts
      check(bound?.pendingSubmit!=true) { "上次提交尚未确认，请先核对" }
      val (workspaceId,revision)=manualDraft ?: bound?.takeIf { it.runId==expectedRunId && it.status in setOf("ready","paused") }
        ?.let { Pair(it.workspaceId,it.bankRevision) } ?: error("准备记录已变化，请重新准备浮窗")
      check(workspaces.get(workspaceId).activeBankRevision==revision && workspaces.questions(workspaceId,revision).isNotEmpty()) { "题库已变化，请重新准备浮窗" }
      check(granted() && service!=null) { accessibilityUnavailableMessage() }
      Pair(service!!,checkNotNull(floatingTaskState()))
    }
    try { prepared.first.requirePreparedOverlay(prepared.second) }
    catch(error:Exception) {
      synchronized(this) {
        if(manualDraft!=null && state.optString("runId")==expectedRunId && state.optString("phase")=="waiting_for_question")
          pause(error.message ?: "浮窗未能显示，请重试")
      }
      throw error
    }
    return synchronized(this) { check(state.optString("runId")==expectedRunId && service===prepared.first && prepared.first.overlayVisible) { "浮窗未能显示，请重试" };snapshot() }
  }
  /** Opens the selected app only; reading, allowance and execution wait for the overlay click. */
  fun prepareForTarget(workspaceId:String,packageName:String):Map<String,Any?> {
    check(canPrepareOnForeground(packageName)) { "请先选择已安装的答题软件" }
    val launch=context.packageManager.getLaunchIntentForPackage(packageName) ?: error("所选软件尚未安装")
    val prepared=prepareNewOverlay(workspaceId,packageName)
    return synchronized(this) {
      check(state.optString("runId")==prepared["runId"] && manualDraft!=null) { "准备记录已变化，请重新准备浮窗" }
      try { context.startActivity(launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
      catch(error:Exception) { pause("无法打开所选答题软件，请手动打开后点击浮窗开始");throw IllegalStateException("无法打开所选答题软件，请手动打开后点击浮窗开始",error) }
      snapshot()
    }
  }
  @Synchronized fun createGenericRun(options:Map<String,Any?>):Map<String,Any?> = storedMutation {
    check(state.optString("status")!="running") { "请先结束当前答题" }
    val workspace=workspaces.get(options["workspaceId"] as? String ?: "")
    val revision=workspace.activeBankRevision ?: error("请先导入答题资料")
    check(workspaces.questions(workspace.id,revision).isNotEmpty()) { "请先导入含有题目和答案的资料" }
    val binding=GenericBinding.installed(context,options["packageName"] as? String ?: "")
    check(!db.hasUncertainGenericSubmission(binding.packageName)) { "上次提交尚未确认，请返回本次答题核对提交结果" }
    val paid=db.freeRemaining()==0 && BuildConfig.BILLING_ADMISSION_ENABLED
    if(!paid)db.requireFreeRun()
    val paidOwner=if(paid) AndroidCredentialSource(context).read().ownerId else null
    endRunForConfiguration();db.selectWorkspace(workspace.id)
    val f=RunFacts(UUID.randomUUID().toString(),workspace.id,revision,"__generic__",1,WorkspaceRepository.sha256(binding.toString()),status="ready",startedAt=System.currentTimeMillis())
    state.put("billingTracked",!paid)
    if(paid) {
      state.put("billingMode","paid").put("paidOwner",paidOwner)
        .put("paidBinding",PaidSubmissionGuard.binding(f,PaidTarget(binding.packageName,binding.version,binding.signer))).put("paidAttempted",false).put("paidCancelled",false)
    } else { state.remove("billingMode");state.remove("paidOwner");state.remove("paidBinding");state.remove("paidAttempted");state.remove("paidCancelled") }
    generic=makeGeneric(binding,f);persistGeneric(f,binding,null);snapshot()
  }
  @Synchronized fun acknowledgeGenericSubmission(options:Map<String,Any?>):Map<String,Any?> = storedMutation {
    val g=generic ?: error("本次答题记录无法读取，请重新打开")
    val pendingId=g.facts.submissionIntentId
    check(pendingId!=null && g.facts.status in setOf("paused","stopped") &&
      options["runId"]==g.facts.runId && options["submissionIntentId"]==pendingId &&
      options["verdict"]=="not_submitted") { "待确认的提交已变化，请重新核对当前提交结果" }
    paidHumanVerdict=true
    try { g.acknowledgeUnsubmitted() } finally { paidHumanVerdict=false }
    snapshot()
  }
  private fun clearGenericForSwitch() {
    failureRead=null
    paidStart.invalidate()
    if(state.optString("billingMode")=="paid" && state.optBoolean("paidAttempted")) {
      val phase=paidStore.read(state.getString("runId"))?.phase
      val complete=state.optBoolean("paidCancelled") || phase in setOf("confirmed","released")
      if(!complete) reconcileEndedPaidRun()
      check(complete) { "上次付款记录正在联网核对，请稍后重试" }
    }
    check(generic?.facts?.pendingSubmit!=true) { "请先核对上次提交结果，再切换资料或开始新任务" }
    generic?.stop();generic=null
  }
  private fun verifyProfileTarget(c:ProfileRunCoordinator) {
    val stored=profiles.get(c.facts.profileId,c.facts.profileVersion)
    check(stored.hash==c.facts.profileHash && (stored.approvedTargetVersion!=null || c.facts.trial)) { "配置尚未确认或内容已变化" }
    val info=context.packageManager.getPackageInfo(c.profile.target.packageName,0)
    val version=if(Build.VERSION.SDK_INT>=28) info.longVersionCode else info.versionCode.toLong()
    check(version==(if(c.facts.trial) c.facts.trialTargetVersion else stored.approvedTargetVersion) && version>=(c.profile.target.minVersionCode ?: 0) && version<=(c.profile.target.maxVersionCode ?: Long.MAX_VALUE)) { "目标软件版本已变化，请重新试跑确认配置" }
    check(workspaces.questions(c.facts.workspaceId,c.facts.bankRevision).isNotEmpty()) { "本轮固定题库版本不存在" }
  }
  private var launchPageGate:StableLaunchPage?=null
  private fun launchProfile(c:ProfileRunCoordinator) {
    val intent=context.packageManager.getLaunchIntentForPackage(c.profile.target.packageName) ?: error("当前资料空间尚未安装目标软件")
    launchPageGate=StableLaunchPage()
    launchGrace=System.currentTimeMillis()+4000
    context.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP))
  }
  private fun tickProfile() {
    val c=coordinator ?: return
    if(c.facts.status!="running" || profileReadPending) return
    if(!granted() || service==null) { pause(accessibilityUnavailableMessage());return }
    val targetVersion=try { context.packageManager.getPackageInfo(c.profile.target.packageName,0).let { if(Build.VERSION.SDK_INT>=28) it.longVersionCode else it.versionCode.toLong() } } catch(_:Exception) { pause("目标软件已移除或资料空间发生变化");return }
    val boundVersion=if(c.facts.trial) c.facts.trialTargetVersion else profiles.get(c.facts.profileId,c.facts.profileVersion).approvedTargetVersion
    if(targetVersion!=boundVersion) { pause("目标软件版本已变化，请重新试跑确认配置");return }
    if((context.getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager).isKeyguardLocked || !(context.getSystemService(Context.POWER_SERVICE) as PowerManager).isInteractive) { pause("手机已锁屏或熄屏");return }
    val reader=profileReader ?: ScreenReader(service!!).also { profileReader=it }
    val generation=profileGeneration;val runId=c.facts.runId
    fun current(id:String)=synchronized(this) { storageFault==null && generation==profileGeneration && coordinator===c && c.facts.runId==id && c.facts.status=="running" }
    fun process(page:PageSnapshot) {
      if(!current(runId)) return
      try {
        val observed=QuestionExtractor.extract(c.profile,page)
        val correction=state.optString("assistStem").takeIf { it.isNotEmpty() && observed?.fingerprint==state.optString("assistQuestionFingerprint") }
        val missing=observed!=null && QuestionMatcher(workspaces).match(c.facts.workspaceId,c.facts.bankRevision,observed) is MatchResult.Missing
        val locallyKnown=SelectorMatcher.select(c.profile,c.profile.resultPolicy.completionSelector,page).isNotEmpty() ||
          c.profile.pages["login"]?.let { SelectorMatcher.select(c.profile,it,page).isNotEmpty() }==true ||
          c.profile.steps.getOrNull(c.facts.stepIndex)?.selector?.let { SelectorMatcher.select(c.profile,it,page).isNotEmpty() }==true
        if(correction==null && (missing || observed==null && !locallyKnown) && !c.facts.pendingSubmit && !c.facts.pendingNavigation && c.facts.pendingOption==null) {
          if(beginProfileAssist(c,page,observed,::current,::process)) return
        }
        val action=c.onPage(page,correction) ?: return
        if(!current(runId)) return
        val executor=profileExecutor ?: ActionExecutor(service!!,c.profile,::current,reader).also { profileExecutor=it }
        profileReadPending=true
        executor.executeAsync(action,page) { outcome -> synchronized(this) { if(current(runId)) { profileReadPending=false;runCatching { c.actionOutcome(outcome) } } } }
      } catch(error:Exception) { if(storageFault==null) pause(error.message ?: "页面处理失败，已暂停") }
    }
    val tree=try { reader.readTree(c.profile) } catch(error:Exception) {
      val code=(error as? ScreenReadException)?.code
      if(System.currentTimeMillis()>=launchGrace || code !in setOf("NO_WINDOW","WRONG_FOREGROUND")) pause(error.message ?: "当前页面无法读取")
      return
    }
    launchPageGate?.let { gate ->
      if(!gate.ready(tree,service!!.windowEpoch,SystemClock.elapsedRealtime())) {
        if(System.currentTimeMillis()>=launchGrace) pause("目标软件页面仍在变化，请稳定后再试")
        return
      }
      launchPageGate=null
    }
    val hasKnownPage=QuestionExtractor.extract(c.profile,tree)!=null || SelectorMatcher.select(c.profile,c.profile.resultPolicy.completionSelector,tree).isNotEmpty() ||
      c.profile.pages["login"]?.let { SelectorMatcher.select(c.profile,it,tree).isNotEmpty() }==true ||
      c.profile.steps.getOrNull(c.facts.stepIndex)?.selector?.let { SelectorMatcher.select(c.profile,it,tree).isNotEmpty() }==true
    if(!hasKnownPage && c.facts.pendingOption!=null) { process(tree);return }
    if(c.shouldWaitForLaunchPage(hasKnownPage,launchGrace)) return
    if(hasKnownPage) process(tree)
    else {
      profileReadPending=true
      reader.read(c.profile,runId,::current) { result -> synchronized(this) {
        if(current(runId)) { profileReadPending=false;result.fold(onSuccess=::process,onFailure={ error -> runCatching { c.onReadFailure((error as? ScreenReadException)?.code ?: "READ_FAILED",error.message ?: "图片页面无法读取，请人工核对") } }) }
      } }
    }
  }
  /** Sends only profile-scoped question/entry text; a candidate must re-match the fixed local revision. */
  private fun beginProfileAssist(c:ProfileRunCoordinator,page:PageSnapshot,observed:ObservedQuestion?,active:(String)->Boolean,onResolved:(PageSnapshot)->Unit):Boolean {
    val config=runCatching { gateway.tokenConfig() }.getOrNull() ?: return false
    if(state.optInt("cloudCalls")>=5) { pause("本轮AI增强已达5次上限，请人工核对");return true }
    val ids=listOfNotNull(c.profile.pages["questionStem"],c.profile.pages["questionType"],c.profile.pages["options"],c.profile.steps.getOrNull(c.facts.stepIndex)?.selector).distinct()
    val nodes=ids.flatMap { SelectorMatcher.select(c.profile,it,page) }.distinctBy { it.ref }.take(200)
    if(nodes.isEmpty()) return false
    val text=nodes.joinToString("\n") { it.text }.take(32768)
    if(Regex("登录|密码|验证码|手机号|身份证|人脸|短信|access.?token|password|sign.?in",RegexOption.IGNORE_CASE).containsMatchIn(text)) { pause("疑似登录或身份验证页面，请本人完成后继续");return true }
    val request=mapOf<String,Any?>("requestId" to UUID.randomUUID().toString(),"runId" to c.facts.runId,"profileId" to c.profile.id,"profileVersion" to c.profile.version,"frameId" to page.frameId,"purpose" to if(observed==null) "classify_page" else "read_question",
      "page" to mapOf("kind" to if(observed==null) "unknown" else "question","text" to text,"nodes" to nodes.map { mapOf("ref" to it.ref,"text" to it.text.take(2048)) }),"localEvidence" to "完整本地匹配缺失。仅提取题干原文；不生成或更改答案。")
    state.put("cloudCalls",state.optInt("cloudCalls")+1).put("httpAttempts",state.optInt("httpAttempts")+1)
    save("ui_assist","仅发送已批准页面规则范围内的文字，辅助候选须重新查本地题库")
    profileReadPending=true
    aiFuture=aiWorker.submit {
      try {
        val response=UiAssistClient.request(config,request)
        synchronized(this) {
          if(!active(c.facts.runId)) return@synchronized
          UiAssistValidator.validate(request,response,c.facts.runId,page.frameId,true)
          val usage=response["usage"] as? Map<*,*>;state.put("httpAttempts",state.optInt("httpAttempts")+((usage?.get("httpAttempts") as? Number)?.toInt() ?: 1)-1)
          val extracted=response["extractedText"] as? String
          if(observed==null || response["classification"]!="question" || extracted.isNullOrBlank() || extracted.length>12000 || QuestionMatcher(workspaces).matchTexts(c.facts.workspaceId,c.facts.bankRevision,observed.type,extracted,observed.options.map { it.text }) !is MatchResult.Exact) {
            profileReadPending=false;pause("辅助结果仍不能与本资料区标准答案完整匹配，请人工核对");return@synchronized
          }
          val reader=profileReader ?: return@synchronized
          fun accept(fresh:PageSnapshot) {
            synchronized(this) {
              if(!active(c.facts.runId)) return@synchronized
              if(fresh.fingerprint!=page.fingerprint || fresh.windowId!=page.windowId || QuestionExtractor.extract(c.profile,fresh)?.fingerprint!=observed.fingerprint) { profileReadPending=false;pause("辅助返回前页面已变化，候选已隔离");return@synchronized }
              state.put("assistStem",extracted).put("assistQuestionFingerprint",observed.fingerprint)
              save("ui_assist_confirm","候选题干已在新快照核对，并与固定本地题库版本完整匹配")
              profileReadPending=false;onResolved(fresh)
            }
          }
          if(page.ocrRegions.isEmpty()) accept(reader.readTree(c.profile))
          else reader.read(c.profile,c.facts.runId,active) { result -> result.fold(onSuccess=::accept,onFailure={ synchronized(this) { if(active(c.facts.runId)) { profileReadPending=false;runCatching { pause(it.message ?: "辅助回读失败，已暂停") } } } }) }
        }
      } catch(error:Exception) { synchronized(this) { if(active(c.facts.runId)) { profileReadPending=false;runCatching { pause(error.message ?: "AI增强请求失败，已暂停") } } } }
    }
    return true
  }
  fun getGatewaySettings():Map<String,Any?> = gateway.summary()
  @Synchronized fun setGatewaySettings(options:Map<String,Any?>):Map<String,Any?> { requireIdleMutation();return gateway.save(options) }
  fun exchangeGatewayGrant(options:Map<String,Any?>):Map<String,Any?> = gateway.exchangeGrant(options)
  @Synchronized fun clearGatewayAuthorization():Map<String,Any?> { requireIdleMutation();return gateway.clear() }
  fun requestUiAssist(request:Map<String,Any?>):Map<String,Any?> {
    val config:Map<String,String>;val generation:Long;val runId:String;val frameId=request["frameId"] as? String ?: error("缺少页面标识")
    synchronized(this) {
      requireStorage();check(state.optString("status")!="running") { "手动辅助请先暂停，结果仅供复核" }
      runId=state.optString("runId");check(runId.isNotEmpty() && request["runId"]==runId && coordinator!=null) { "辅助请求不属于当前正式任务" }
      check(state.optInt("cloudCalls")<5);config=gateway.tokenConfig();generation=profileGeneration
      state.put("cloudCalls",state.optInt("cloudCalls")+1).put("httpAttempts",state.optInt("httpAttempts")+1);save("ui_assist","手动请求页面辅助，返回结果仅供复核")
    }
    val response=UiAssistClient.request(config,request)
    synchronized(this) {
      UiAssistValidator.validate(request,response,state.optString("runId"),frameId,generation==profileGeneration && storageFault==null)
      val usage=response["usage"] as? Map<*,*>;state.put("httpAttempts",state.optInt("httpAttempts")+((usage?.get("httpAttempts") as? Number)?.toInt() ?: 1)-1);save("ui_assist","手动页面候选已返回，尚未执行操作")
    }
    return response
  }
  private inline fun <T> storedMutation(block:()->T):T {
    requireStorage()
    try { return block() } catch(error:android.database.SQLException) { latchStorageFailure();throw IllegalStateException(storageFault,error) }
  }
  private fun requireNoActiveTask(allowManualDraft:Boolean=false) {
    if(allowManualDraft && manualDraft!=null) return
    val active=state.optString("runId").isNotEmpty() && state.optString("status") in setOf("ready","running","paused")
    check(!active) { "已有答题任务，请先结束当前任务" }
  }
  private fun requireIdleMutation() { if(state.optString("status")=="running") pause("资料或配置正在变更，任务已暂停，请重新准备") else cancelProfileCallbacks() }
  private fun endRunForConfiguration() {
    manualDraft=null;
    requireIdleMutation();clearGenericForSwitch();coordinator?.stop();coordinator=null
    state=JSONObject().put("status","idle").put("phase","preflight").put("total",0).put("totalKnown",false).put("answered",0).put("cloudCalls",0)
    save("configuration","资料或软件配置已切换，请重新准备任务")
  }
  private fun workspaceMap(w:Workspace):Map<String,Any?> = mapOf("id" to w.id,"companyLabel" to w.companyLabel,"departmentLabel" to w.departmentLabel,"activeBankRevision" to w.activeBankRevision)
  private fun uiAppLabel(packageName:String):String = runCatching { context.packageManager.getApplicationLabel(context.packageManager.getApplicationInfo(packageName,0)).toString() }.getOrDefault("目标软件")
  @Synchronized fun getAssistantData():Map<String,Any?> = storedMutation {
    val current=snapshot();val packageName=current["targetPackage"] as? String
    mapOf("snapshot" to current,"banks" to db.materialSummaries().filter { it["revision"]!=null },"selectedWorkspaceId" to db.selectedWorkspace(),
      "target" to if((manualDraft!=null || generic!=null || current["profileId"]!=null) && packageName!=null) mapOf("name" to uiAppLabel(packageName),"packageName" to packageName) else null,
      "records" to db.completedUiRuns().map { f ->
        val w=db.workspace(f.optString("workspaceId"));val p=db.profile(f.optString("profileId"),f.optInt("profileVersion"))
        mapOf("id" to f.getString("runId"),"at" to f.optLong("startedAt"),"bank" to (w?.departmentLabel ?: "原有资料"),"target" to (f.optString("targetPackage").takeIf { it.isNotBlank() }?.let(::uiAppLabel) ?: p?.profile?.target?.packageName?.let(::uiAppLabel) ?: "目标软件"),"answered" to f.optInt("submittedCount"),"total" to f.optInt("total",0),"status" to f.optString("status"),"questions" to emptyList<String>())
      })
  }
  @Synchronized fun getMaterialQuestions(options:Map<String,Any?>):Map<String,Any?> = storedMutation { mapOf("questions" to db.materialPage(options["workspaceId"] as? String ?: "",options["revision"] as? String ?: "",(options["offset"] as? Number)?.toInt() ?: 0,(options["limit"] as? Number)?.toInt() ?: 500)) }
  fun openPermissionSettings(kind:String) {
    val intent=when(kind) {
      "notifications" -> if(Build.VERSION.SDK_INT>=26) Intent(android.provider.Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(android.provider.Settings.EXTRA_APP_PACKAGE,context.packageName) else Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS,android.net.Uri.parse("package:"+context.packageName))
      "background" -> Intent(android.provider.Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)
      else -> Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS,android.net.Uri.parse("package:"+context.packageName))
    }
    context.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
  }
  @Synchronized fun listWorkspaces():List<Map<String,Any?>> = storedMutation { workspaces.list().map(::workspaceMap) }
  @Synchronized fun createWorkspace(options:Map<String,Any?>):Map<String,Any?> = storedMutation {
    val select=options["select"]!=false
    if(select)requireNoActiveTask()
    val w=workspaces.create(options["companyLabel"] as? String ?: "",options["departmentLabel"] as? String ?: "")
    if(select) { endRunForConfiguration();db.selectWorkspace(w.id) }
    workspaceMap(w)
  }
  @Synchronized fun updateWorkspace(options:Map<String,Any?>):Map<String,Any?> = storedMutation { requireIdleMutation();workspaceMap(workspaces.update(options["id"] as? String ?: "",options["companyLabel"] as? String ?: "",options["departmentLabel"] as? String ?: "")) }
  @Synchronized fun deleteWorkspace(id:String):Map<String,Any?> = storedMutation { requireNoActiveTask();endRunForConfiguration();workspaces.delete(id);snapshot() }
  @Synchronized fun selectWorkspace(id:String):Map<String,Any?> = storedMutation {
    workspaces.get(id)
    if(db.selectedWorkspace()!=id) { requireNoActiveTask();endRunForConfiguration();db.selectWorkspace(id) }
    snapshot()
  }
  @Synchronized fun prepareBankImport(options:Map<String,Any?>):Map<String,Any?> = storedMutation {
    val p=workspaces.prepareImport(options["workspaceId"] as? String ?: "",BankJsonImporter.parseCanonical(options["json"] as? String ?: ""))
    mapOf("id" to p.id,"workspaceId" to p.workspaceId,"questionCount" to p.questionCount,"sourceDigest" to p.sourceDigest,"expectedActiveRevision" to p.expectedActiveRevision)
  }
  @Synchronized fun commitBankImport(options:Map<String,Any?>):Map<String,Any?> = storedMutation {
    requireNoActiveTask();val r=workspaces.commitImport(options["previewId"] as? String ?: "",options["expectedActiveRevision"] as? String)
    mapOf("id" to r.id,"workspaceId" to r.workspaceId,"sourceDigest" to r.sourceDigest,"questionCount" to r.questionCount,"status" to r.status)
  }
  @Synchronized fun cancelBankImport(id:String):Map<String,Any?> = storedMutation { workspaces.cancelImport(id);snapshot() }
  @Synchronized fun prepareProfile(options:Map<String,Any?>):Map<String,Any?> = storedMutation {
    requireIdleMutation();val p=profiles.prepareProfile(ProfileCodec.parse(options["json"] as? String ?: ""))
    mapOf("profileId" to p.profileId,"version" to p.version,"hash" to p.hash,"targetPackage" to p.targetPackage,"issues" to p.issues)
  }
  @Synchronized fun approveProfile(options:Map<String,Any?>):Map<String,Any?> = storedMutation {
    requireIdleMutation();val id=options["profileId"] as? String ?: "";val hash=options["hash"] as? String ?: ""
    val p=profiles.list().singleOrNull { it.profile.id==id && it.hash==hash } ?: error("配置摘要不一致")
    val version=(getTargetInfo(mapOf("profileId" to id,"version" to p.profile.version))["versionCode"] as? Number)?.toLong() ?: error("目标软件尚未安装")
    check(options["testedTargetVersion"]==null || (options["testedTargetVersion"] as? Number)?.toLong()==version) { "试跑软件版本与当前安装不一致" }
    check(db.verifiedTrial(id,hash,version)) { "尚无此配置在当前软件版本的首题试跑回执，请先试跑" }
    profiles.approveProfile(id,hash,version);snapshot()
  }
  @Synchronized fun selectProfile(options:Map<String,Any?>):Map<String,Any?> = storedMutation { endRunForConfiguration();profiles.activateProfile(options["profileId"] as? String ?: "",(options["version"] as? Number)?.toInt() ?: 0);snapshot() }
  @Synchronized fun listProfiles():List<Map<String,Any?>> = storedMutation { val active=profiles.active();profiles.list().map { p -> mapOf("id" to p.profile.id,"version" to p.profile.version,"hash" to p.hash,"targetPackage" to p.profile.target.packageName,"approvedTargetVersion" to p.approvedTargetVersion,"active" to (active?.hash==p.hash)) } }
  @Synchronized fun createProfileRun(options:Map<String,Any?>):Map<String,Any?> = storedMutation {
    require(!options.containsKey("seed")) { "正式任务不接受随机种子" }
    check(state.optString("status")!="running") { "请先暂停或停止当前任务" }
    val spec=RunSpec(options["workspaceId"] as? String ?: "",options["profileId"] as? String ?: "",(options["expectedQuestionCount"] as? Number)?.toInt())
    require(spec.expectedQuestionCount==null || spec.expectedQuestionCount in 1..50000)
    val w=workspaces.get(spec.workspaceId);check(w.id!="__demo__") { "演练题库不能用于正式任务" };val revision=w.activeBankRevision ?: error("请先导入此资料区的标准题库")
    val p=profiles.active()?.takeIf { it.profile.id==spec.profileId } ?: error("请先选择并确认此软件配置")
    db.requireFreeRun()
    check(p.approvedTargetVersion!=null);clearGenericForSwitch();cancelProfileCallbacks();db.selectWorkspace(w.id)
    val f=RunFacts(UUID.randomUUID().toString(),w.id,revision,p.profile.id,p.profile.version,p.hash,spec.expectedQuestionCount ?: p.profile.resultPolicy.expectedCount)
    state=JSONObject().put("billingTracked",true).put("cloudCalls",0).put("httpAttempts",0)
    coordinator=makeCoordinator(p.profile,f);persistProfile(f,null);snapshot()
  }
  @Synchronized fun getTargetInfo(options:Map<String,Any?>):Map<String,Any?> {
    val p=profiles.get(options["profileId"] as? String ?: "",(options["version"] as? Number)?.toInt()).profile
    val flags=if(Build.VERSION.SDK_INT>=28) PackageManager.GET_SIGNING_CERTIFICATES else PackageManager.GET_SIGNATURES
    val info=try { context.packageManager.getPackageInfo(p.target.packageName,flags) } catch(_:PackageManager.NameNotFoundException) { return mapOf("installed" to false,"packageName" to p.target.packageName) }
    val signers=(if(Build.VERSION.SDK_INT>=28) info.signingInfo?.apkContentsSigners else info.signatures).orEmpty().map { signature -> java.security.MessageDigest.getInstance("SHA-256").digest(signature.toByteArray()).joinToString("") { "%02x".format(it) } }
    return mapOf("installed" to true,"packageName" to p.target.packageName,"versionCode" to if(Build.VERSION.SDK_INT>=28) info.longVersionCode else info.versionCode.toLong(),"versionName" to info.versionName,"signerSha256" to signers.firstOrNull(),"signerSha256s" to signers)
  }
  @Synchronized fun createProfileTrial(options:Map<String,Any?>):Map<String,Any?> = storedMutation {
    require(!options.containsKey("seed"));check(state.optString("status")!="running") { "请先暂停当前任务" }
    val w=workspaces.get(options["workspaceId"] as? String ?: "");val revision=w.activeBankRevision ?: error("请先导入此资料区的标准题库")
    check(w.id!="__demo__")
    val p=profiles.get(options["profileId"] as? String ?: "",(options["version"] as? Number)?.toInt())
    val target=getTargetInfo(mapOf("profileId" to p.profile.id,"version" to p.profile.version));check(target["installed"]==true) { "请先安装目标软件" }
    db.requireFreeRun()
    val targetVersion=(target["versionCode"] as Number).toLong();clearGenericForSwitch();cancelProfileCallbacks();db.selectWorkspace(w.id)
    val f=RunFacts(UUID.randomUUID().toString(),w.id,revision,p.profile.id,p.profile.version,p.hash,p.profile.resultPolicy.expectedCount,trial=true,trialTargetVersion=targetVersion)
    state=JSONObject().put("billingTracked",true).put("cloudCalls",0).put("httpAttempts",0);coordinator=makeCoordinator(p.profile,f);persistProfile(f,null);snapshot()
  }

  private fun notification() {
    val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    manager.createNotificationChannel(NotificationChannel("quiz_task", "答题任务状态", NotificationManager.IMPORTANCE_LOW))
    if (state.optString("status") != "running") { manager.cancel(8701); return }
    if (Build.VERSION.SDK_INT >= 33 && context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED) return
    fun action(name: String, code: Int): PendingIntent = PendingIntent.getBroadcast(context,code,
      Intent(context,TaskActionReceiver::class.java).setAction(name), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    val launch = context.packageManager.getLaunchIntentForPackage(context.packageName)
    val builder = Notification.Builder(context,"quiz_task").setSmallIcon(android.R.drawable.ic_media_play)
      .setContentTitle("本地答题辅助正在运行").setContentText("已确认 ${state.optInt("answered")} / ${state.optInt("total")} 题")
      .setOngoing(true).addAction(Notification.Action.Builder(null,"暂停",action("pause",1)).build())
      .addAction(Notification.Action.Builder(null,"停止",action("stop",2)).build())
    if (launch != null) builder.setContentIntent(PendingIntent.getActivity(context,3,launch,PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE))
    manager.notify(8701,builder.build())
  }
}

class TaskActionReceiver : BroadcastReceiver() {
  override fun onReceive(context: Context, intent: Intent) {
    val engine = NativeTaskEngine.get(context)
    if (intent.action=="stop") engine.stop() else if (intent.action=="pause") engine.pause("已从任务通知暂停")
  }
}


