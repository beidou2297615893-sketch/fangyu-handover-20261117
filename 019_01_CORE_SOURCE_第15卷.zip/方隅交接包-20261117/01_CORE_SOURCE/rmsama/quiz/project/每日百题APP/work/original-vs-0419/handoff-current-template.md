# 2026-11-14 最新接续状态（$STAMP$，优先于下方历史）

用户要求：以题进/TiJing原生代码为基础，奥卡姆剃刀，尽量只改UI、名称和支付；核心必须能用，铁路1859题，题库优先，用户不选择AI，模型只兜底。用户最新明确暂不方便USB连接小米澎湃OS手机，先完成模拟器原版对照。手机实付由用户后测，不再重复问USB。

## 先接当前任务，不能重启同一自然场

- 项目 C:/Users/rmsama/Documents/ChatGPT/答题小程序/每日百题APP；V:映射它。主代码work/tijing-bankassist；官方源work/tijing-upstream；本轮全部证据work/original-vs-0419。
- 当前自然场目录：$NATURAL_FOLDER$。实际状态：$NATURAL_STATUS$。读current-progress.json，完成后final-summary.json；没有完成成绩不能报通过。原始宿主事件current-run-events.json、连续日志continuous-log.txt、最终原生截图current-final.png、实际APK指纹apk-used.json。
- 最新QA APK SHA256 $QA_SHA$，路径regression-stage/app/build/outputs/apk/dev/debug/app-dev-debug.apk，ID com.jimusoft.dailyhundredapp.audit419.dev，仅诊断，绝不能上传。当前185项单测通过（以evidence-audit.json实际数为准），40份main冻结、38份共用与QA输入逐字相同，2份替换隔离计费与本地模型转发。Web9项与正式相同。
- 当前启动脚本run-final-natural.py hidden-final-natural-v3（已启动后就别重复启动）。它先要求100题逐图及103页状态检查通过，再准备新场、自动答题、记录；真正100/100且成绩出现后，执行validate-finished-run.py、check-reopen.py、check-formal-upgrade.py和刷新说明。需要接手时先查进程/状态，不因文件更新猜运行进程已读取新代码。
- 只用ADB端口15037、serial emulator-5588。AVD dailyhundred_api35_vdrive，API35，1080x2400，4核4GB，headless Swiftshader。不要操作真机或其他模拟器。运行中不能uiautomator，会扰动无障碍；只读日志/截图。实时Pythonw面板属于本任务，进程/窗口须实际查询，别猜ID。
- 真实模型测试中继relay-real-model.py仅127.0.0.1:18765，实际DeepSeek请求，thinking disabled；不注入题库或答案，不触碰支付。key只在内存，不打印云函数环境/原版私有配置。新用户消息可能让本工具环境丢V映射或后台进程，需先查，不能假装还在跑。

## 原版对照已确定的事实

1. 作者官方v0.7.7 APK为960780字节（0.92MiB），SHA3f4988b2fe4c5eaab22c4e604468c9c99114a0ce3b522611601b2b9a0fcff20f，与作者发布sha一致。交付outputs/题镜官方原版/TiJing-0.7.7-open.apk，不含用户题库/模型配置。
2. 官方包在本次静态铁路首题截图超时，未提交。16份原生源逐字与上游一致的original-control调试对照包也复现：overlay等待期间ImageReader消耗已有帧，静态页可能没新帧。给测试页加1px重绘才进入模型，2题1对1错；这是辅助诊断，不能说自然通过，也不能据2题推断整体正确率。
3. 原版AUTO/VISION每题用模型，不查本机库；原版QUESTION_BANK用于识别题干、查库展示，强制MANUAL。仅UI+支付无法凭空得到自动查库/提交。不得假称原版就已支持全部本轮目标。
4. 原版当前模型默认思考可耗尽1200输出预算，content为空；同请求thinking disabled有内容。现知题网关早已disabled，不能把这一配置原因套作0.4.19所有故障原因。
5. 已发布0.4.19正式包146088723字节，SHA33411dbe246d73d9e4328d4d80429eaaf28afc0d78a4cfd8defd4f3cd6b0565e，code86，签名cert fac61745dc0903786fb9ede62a962b399f7348f0bb6f899b8332667591033b9c。蒲公英 https://www.pgyer.com/meiribaiti 序号38仍为旧版本，除非本轮有实际新发布回执。
6. 大包增量是OCR：ONNX运行库75206864、MLKit/Gocr42957951、模型18539174压缩字节，约130MiB。不是仅UI/支付。新手机候选只保留ARM32/64，约75.6MiB；完整4ABI候选约139MiB，答题代码/模型不减，需新构建/新核验后交付。

## 真实故障与本轮最小改动

当前只改6个已有main文件，没新模型/运行库：

- ScreenCaptureService：等待判分/续页证据不完整时，也调用已有独立读字器。first.graded可能因为“正确苔案”“下ー题”都读错而false，不能据此跳过补读。
- OcrHostPage / LocalQuestionBank：允许同一换行选项的字母标记在第二行；仅行首小写字母加明确选项标点转大写，不改数字。错字母、缺行、数字5000改50000仍拒绝。
- RomanChoiceEvidence / IndependentLineReader：原有I/V像素核验也接入带A-D标记的完整OCR四行，仍要求四级齐全及真实一致笔画。
- ShortChoiceCards：旧197灰度上限漏掉209浅灰圆框，改211仍保留bg-44和完整几何；五实图恢复完整卡片。另labelledRule仅对明确A.加横线OCR、完整卡片内恰好字母/点/单横线三个分量做实际连续笔画验证；OcrHostPage仅让单个“一”可走已有physicalRuleIndex唯一核对，不普通替换“一”、不接受一一或一—。断线和数字A.1/A.-5拒绝。
- 新增6份回归类（WrappedOption、RomanLabelled、LowercaseOption、ContrastCard、LabelledStroke、FrameContinuation），当前185项；红绿日志regression-red/green-{case,contrast,stroke,continuation}.log等。source-manifest为regression-source-manifest.json，audit-evidence.py刷新证据。

**最新helper已简化为单参数needsContinuationRead(waiting:Boolean)**，不依赖runner内部计数；它不是宿主当前题号。等待未完成判分证据时补读；完整第二结果或已核库页可采用，两个已知矛盾进度不混用，仍交Coordinator确认换页，不直接跳过或选答案。单参数实际源/QA通过最新185项，独立只读审查未发现实质回归。不要恢复旧双参数限制。

## 诊断与自然成绩必须分开

- visible-current：可读文字的真实铁路HTML页，100/100，screen_bank100，347.1秒，零人工，每题只提交一次。是同源隔离计费QA，非正式包实付验收。
- hidden-current：旧0.4.19同源核心，3题全对后下一题暂停；hidden-fixed：10题后换行B暂停；hidden-complete：22题后III误读暂停；hidden-roman-fixed：45题后小写c暂停。全部失败证据保留。
- hidden-final-natural：QA02a3ee0在53题全对后判分续页暂停（正确苔案+下ー题）；旧候选及6源码保留rejected-candidates/pre-continuation，不能发。
- hidden-final-natural-v2：QA47eb642c...的16/16后，主代理主动停下删除错误题号假设，记录STOPPED_FOR_REFINEMENT；不是新故障，也不是完整通过。原始事件/日志已保存。
- 最新自然场看上方动态状态，最终必须100正确、100唯一ID、同序、一次提交、无人干预、宿主结果页真实显示。不能把下述诊断100分图当成绩。
- railway-corpus：100张原渲染器真实截图，同题序，诊断渲染状态覆盖，naturalRound=false。batch-final完成100：96本机核库正确，4真实云抄题后本机核库正确，0错/0未读。备用抄题不等于模型给答案。旧源与新源的银行/选项核对逻辑不变，最新自然场还需重新完整验证。
- railway-feedback-corpus：103页诊断（100正确判分页、1错误、1成绩、1实际53页中途启动）。判分截图渲染过“已答正确”以测文字/按钮，成绩100图是诊断样本，绝不能冒称自然成绩。第一次102/102在feedback-pages；最新103/103在feedback-pages-v2/batch-ocr-result.json，helper真实由已装QA调用。旧双参假设用真实feedback53-clean.png+runner1复现拒绝，feedback-mid-start/old-result.json；新单参同帧补读正确。
- 当前批量探针instrumentation-batch/batch-ocr-probe.apk SHA7a0a4166285aabeb56c24a0ea277c6cbe847493087e33accde55e17452050aa5，只反射已装QA；无答案注入。主/第二真实OCR每帧运行、匹配顺序同服务；云对比parse(raw,true,true)，第三默认实际等于readOptionsOnly，已源码+javap证实。不要误改false当同源。页型expected只事后比对，不引导识字。

## 正式包、升级、发布下一步

最新重建且完成产物核验：手机SHA $MOBILE_SHA$；完整SHA $UNIVERSAL_SHA$；QA SHA同上，40/38/9项同源，517共有ZIP条目无内容差异，两配置各185全过，冻结输入摘要abda5cb0a8d952dbd88441c7241b84045b3908fb0a769edc0d2d19101d979e2e。release-checks/result.json现在是最新单参helper版本，正式升级脚本会重新比对QA/正式哈希。下文旧候选警示仅说明哪些旧哈希不能用；这两个新哈希仍要等待自然场100和覆盖升级结果才可发布。

1. 正式源已版本0.4.20/code87；work/build-android.ps1新增-PhoneOnly（只影响release的ARM筛选）。两个构建目录release-mobile和release-universal，APK后缀android/app/build/outputs/apk/prod/release/app-prod-release.apk。**53题前旧3c42/e27f、双参185项旧mobile3bf134...都不再有效，必须按最新单参源重新构建核验。** 不能套用旧release-checks/result.json；它必须hashes.qa等于当前QA，并40源匹配，才能上传/升级。
2. 构建mobile：& 'V:/work/tijing-bankassist/work/build-android.ps1' -Variant ProdRelease -PaymentRelease -FreeServiceRelease -UnitTests -SkipWebBuild -PhoneOnly -Workers 4 -StageRoot 'V:/work/original-vs-0419/release-mobile'；完成保存日志，再同命令移去PhoneOnly/UnitTests、StageRoot改release-universal。两个阶段顺序，避免同一ProdRelease日志覆盖；不要在冻结构建或自然场期间继续改main。
3. 产物核验代理release_artifact_check（Terra Ultra）可followup更新最新check.py显式预期哈希/185数/新冻结摘要并重跑。只写release-checks，不ADB。要求40源相同、38与QA输入相同、9web相同、两个APK共有所有文件字节相同，仅完整包多6项x86库；正式证书旧签名同一；ProdDebug/DevDebug各185不算370独立用例。
4. check-formal-upgrade.py只在当前自然场真正100后允许运行；读取active-natural-folder.txt及新release-checks/result.json，拒绝旧QA/正式哈希。formal-upgrade/fixture-prepared.json明确旧正式0.4.19本来0题，已在本专用模拟器显式复制同一1859题作为升级数据fixture；没动支付账本。脚本一次启用旧正式无障碍后安装新完整正式包、查1859题与授权保留、两次重开。要看真实UI截图，不仅看assert。仅模拟器，不能冒称小米。
5. 蒲公英Chrome原账号仍登录有效；已CUA只读确认，未上传新包。浏览器provider不可用，原生CUA Chrome窗口69942、变量publishApp（会话仍有效时）；只通过cua_repl操作浏览器。其他项目悬窗别点。登录检查这一段已completion_summary收尾。上传需自然场100、正式升级与新产物核验通过后，使用新手机包，沿用meiribaiti原应用，不新建。用户此前明确授权上传，无需重复问；只有实际登录失效才通知。观察成功版本/序号/下载开启后，下一个工具必须CUA completion_summary，再写回执/最终答复。
6. 正式交付放outputs/知题 0.4.20 安卓版（自然通过后再放APK）；提供手机包、完整兼容包、简短说明、真实成绩与原版对照文档。给文件时同时给完整文件及文件夹路径。不要把QA、私有题库、密钥或计费凭据塞进交付包。
7. 官方原版新装副本已在此专用模拟器pm clear清掉临时模型key，original-test-cleanup.json有回执；原始官方APK未变。小米手机/支付宝实付仍未验收，用户明确后测，不能说所有手机99%或“没有任何问题”。

用户可读报告 outputs/原版与知题铁路对照/对照结果.md。write-comparison-report.py刷新本块及报告，保留下方历史。当前实时面板进程号须实际查询，日志与进度文件始终优先于旧聊天数字。

--- 以下为旧历史，不优先于上方最新块 ---

