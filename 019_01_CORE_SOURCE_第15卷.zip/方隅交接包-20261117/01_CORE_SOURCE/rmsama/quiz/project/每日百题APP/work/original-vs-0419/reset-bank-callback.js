(()=>{window.__quizBankCallbackInstalled=false;return {callbackWillRebind:true};})()
