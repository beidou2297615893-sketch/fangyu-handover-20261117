package com.jimusoft.dailyhundrede2e;


import android.app.Instrumentation;

import android.graphics.BitmapFactory;




import java.io.InputStream;
import android.content.Context;
import android.graphics.Bitmap;
import android.os.Build;
import android.os.Bundle;
import java.io.ByteArrayOutputStream;
import java.io.Closeable;
import java.io.File;
import java.io.FileOutputStream;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.nio.ByteBuffer;
import java.security.MessageDigest;
import java.util.List;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;
import org.json.JSONArray;
import org.json.JSONObject;

/** Paused local fixture capture, adapted from the existing visual-selection diagnostic. */
public final class CapturePausedGenericPageInstrumentation extends Instrumentation {
  private static final String TARGET = "com.jimusoft.randomhundred";
  private Bundle args;

  @Override public void onCreate(Bundle arguments) {
    super.onCreate(arguments);
    args = arguments == null ? new Bundle() : arguments;
    start();
  }

  private static Object get(Object value, String name) throws Exception {
    return value.getClass().getMethod("get" + name).invoke(value);
  }

  private static Object field(Object value, String name) throws Exception {
    Field field = value.getClass().getDeclaredField(name);
    field.setAccessible(true);
    return field.get(value);
  }

  private static Object unwrap(Object value, ClassLoader loader) throws Exception {
    if (value != null && value.getClass().getName().equals("kotlin.Result")) {
      Method method = value.getClass().getDeclaredMethod("unbox-impl");
      method.setAccessible(true);
      value = method.invoke(value);
    }
    Class.forName("kotlin.ResultKt", true, loader).getMethod("throwOnFailure", Object.class).invoke(null, value);
    return value;
  }

  private static JSONObject rect(Object bounds) throws Exception {
    return new JSONObject().put("left", get(bounds, "Left")).put("top", get(bounds, "Top"))
      .put("right", get(bounds, "Right")).put("bottom", get(bounds, "Bottom"));
  }

  private static Object nullable(Object value) { return value == null ? JSONObject.NULL : value; }

  private static JSONArray regions(List<?> items) throws Exception {
    JSONArray list = new JSONArray();
    for (Object region : items) {
      JSONObject record = new JSONObject();
      for (String name : new String[]{"Ref", "Text", "FrameId", "WindowId", "VisualChecked",
          "VisualOriginalText", "VisualRomanSuffix", "VisualTextLineHeight", "VisualRoiReadings"}) {
        Object value = get(region, name);
        if (value instanceof List<?>) value = new JSONArray((List<?>) value);
        record.put(Character.toLowerCase(name.charAt(0)) + name.substring(1), nullable(value));
      }
      record.put("bounds", rect(get(region, "Bounds")));
      Object visualBounds = get(region, "VisualBounds");
      record.put("visualBounds", visualBounds == null ? JSONObject.NULL : rect(visualBounds));
      JSONArray tokens = new JSONArray();
      for (Object token : (List<?>) get(region, "VisualLatinTokens")) {
        tokens.put(new JSONObject().put("text", get(token, "Text")).put("bounds", rect(get(token, "Bounds"))));
      }
      list.put(record.put("visualLatinTokens", tokens));
    }
    return list;
  }

  private static void write(File file, byte[] bytes) throws Exception {
    if (!file.createNewFile()) throw new IllegalStateException("Evidence already exists");
    try (FileOutputStream stream = new FileOutputStream(file)) {
      stream.write(bytes);
      stream.getFD().sync();
    }
  }

  private static String sha(byte[] bytes) throws Exception {
    StringBuilder result = new StringBuilder();
    for (byte value : MessageDigest.getInstance("SHA-256").digest(bytes)) {
      result.append(String.format(Locale.ROOT, "%02x", value & 255));
    }
    return result.toString();
  }

  private static JSONObject validate(Object engine, Class<?> engineType, Object driver, String runId) throws Exception {
    synchronized (engine) {
      Map<?, ?> snapshot = (Map<?, ?>) engineType.getMethod("snapshot").invoke(engine);
      Object answered = snapshot.get("answered");
      if (!runId.equals(snapshot.get("runId")) || !"paused".equals(snapshot.get("status")) ||
          !TARGET.equals(snapshot.get("targetPackage")) || !(answered instanceof Number) ||
          ((Number) answered).intValue() != 30 || field(engine, "generic") != driver) {
        throw new IllegalStateException("Expected the same paused task at 30 answers");
      }
      Object facts = driver.getClass().getMethod("getFacts").invoke(driver);
      if (!runId.equals(get(facts, "RunId")) || !"paused".equals(get(facts, "Status")) ||
          ((Number) get(facts, "SubmittedCount")).intValue() != 30 ||
          !Integer.valueOf(31).equals(get(facts, "LastOrdinal"))) {
        throw new IllegalStateException("Expected the same paused question 31");
      }
      return new JSONObject().put("runId", runId).put("status", snapshot.get("status"))
        .put("answered", answered).put("targetPackage", snapshot.get("targetPackage"))
        .put("phase", nullable(snapshot.get("phase"))).put("lastOrdinal", get(facts, "LastOrdinal"))
        .put("pendingSubmit", get(facts, "PendingSubmit")).put("hasPendingOption", get(facts, "PendingOption") != null);
    }
  }

  private static Object offlineSnapshot(ClassLoader loader, String frameId, String imageSha, int attempt,
      int width, int height, List<?> current, List<List<?>> history) throws Exception {
    Class<?> boundsType = Class.forName("expo.modules.automationbridge.screen.Bounds", true, loader);
    Class<?> nodeType = Class.forName("expo.modules.automationbridge.screen.ScreenNode", true, loader);
    Class<?> pageType = Class.forName("expo.modules.automationbridge.screen.PageSnapshot", true, loader);
    Class<?> pixelsType = Class.forName("expo.modules.automationbridge.screen.VisualFramePixels", true, loader);
    Object area = boundsType.getConstructor(int.class, int.class, int.class, int.class).newInstance(0, 0, width, height);
    Object rootNode = nodeType.getConstructor(String.class, String.class, String.class, String.class, String.class,
      boundsType, boolean.class, boolean.class, boolean.class, String.class, boolean.class, boolean.class)
      .newInstance("offline:root", "", "", "", "android.widget.FrameLayout", area,
        false, false, false, null, true, false);
    List<?> nodes = Collections.singletonList(rootNode);
    Class<?> fingerprintType = Class.forName("expo.modules.automationbridge.screen.ScreenFingerprint", true, loader);
    Object fingerprint = fingerprintType.getMethod("of", String.class, int.class, int.class, int.class, List.class, List.class)
      .invoke(fingerprintType.getField("INSTANCE").get(null), TARGET, -1, width, height, nodes, current);
    return pageType.getConstructor(String.class, long.class, String.class, int.class, List.class, List.class,
      String.class, int.class, int.class, String.class, int.class, String.class, List.class, pixelsType, List.class, boolean.class)
      .newInstance(frameId, android.os.SystemClock.elapsedRealtime(), TARGET, -1, nodes, current, fingerprint,
        width, height, null, attempt, imageSha, new ArrayList<>(history), null, Collections.emptyList(), false);
  }

  private static JSONObject replay(Object recognizer, Object page) throws Exception {
    Object observed = recognizer.getClass().getMethod("recognize", page.getClass()).invoke(recognizer, page);
    String kind = observed.getClass().getSimpleName();
    JSONObject result = new JSONObject().put("offlineReconstruction", true).put("kind", kind);
    if ("Unknown".equals(kind)) return result.put("reason", get(observed, "Reason")).put("mayNeedOcr",get(observed,"MayNeedOcr")).put("ordinal",nullable(get(observed,"Ordinal"))).put("total",nullable(get(observed,"Total"))).put("incompleteLayout",get(observed,"IncompleteLayout"));
    if (!"Question".equals(kind)) return result;
    Object question = get(observed, "Question");result.put("questionType",get(question,"Type")).put("ordinal",nullable(get(observed,"Ordinal"))).put("total",nullable(get(observed,"Total")));
    List<?> choices = (List<?>) get(observed, "Options");
    List<?> correctIds = (List<?>) get(question, "CorrectOptionIds");result.put("correctOptionIds",new JSONArray(correctIds));JSONArray choiceDetails=new JSONArray();
    Object companion = recognizer.getClass().getField("Companion").get(null);
    Method compact = companion.getClass().getMethod("compact", String.class);
    Set<String> desired = new HashSet<>();
    for (Object option : (List<?>) get(question, "Options")) {
      if (correctIds.contains(get(option, "Id"))) desired.add((String) compact.invoke(companion, get(option, "Text")));
    }
    Set<String> selected = new HashSet<>();
    int checkableCount = 0, checkedCount = 0;
    for (Object choice : choices) {
      Object node = get(choice, "Node");choiceDetails.put(new JSONObject().put("text",get(choice,"Text")).put("checkable",get(node,"Checkable")).put("checked",get(node,"Checked")).put("bounds",rect(get(node,"Bounds"))));
      if (Boolean.TRUE.equals(get(node, "Checkable"))) checkableCount++;
      if (Boolean.TRUE.equals(get(node, "Checked"))) {
        checkedCount++;
        selected.add((String) compact.invoke(companion, get(choice, "Text")));
      }
    }
    boolean evaluable = checkableCount == choices.size() && !choices.isEmpty();
    return result.put("choices",choiceDetails).put("currentId", get(question, "Id")).put("optionCount", choices.size())
      .put("checkableCount", checkableCount).put("checkedCount", checkedCount)
      .put("expectedSelectionEvaluable", evaluable)
      .put("expectedSelectionChecked", evaluable ? desired.equals(selected) : JSONObject.NULL);
  }

  private static Object pixelRead(ClassLoader loader,Bitmap image,Object bounds,int mode,int[] box,int color)throws Exception{Class<?> v=Class.forName("expo.modules.automationbridge.screen.VisualRadioState",true,loader),b=Class.forName("expo.modules.automationbridge.screen.Bounds",true,loader),fn=Class.forName("kotlin.jvm.functions.Function2",true,loader);Object callback=Proxy.newProxyInstance(loader,new Class<?>[]{fn},(proxy,m,args)->{if("invoke".equals(m.getName())){int x=((Number)args[0]).intValue(),y=((Number)args[1]).intValue();if(mode==1&&x>=box[0]&&x<=box[2]&&y>=box[1]&&y<=box[3])return color;if(mode==2&&x>=box[4]&&x<box[6]&&y>=box[5]&&y<box[7])return color;if(mode==3&&x>=box[4]&&x<box[6]&&y>=box[5]&&y<box[7])return Math.abs(x-(box[4]+box[6])/2)<=3&&Math.abs(y-(box[5]+box[7])/2)<=3?0xff111111:0xffffffff;return image.getPixel(x,y);}if("toString".equals(m.getName()))return "ReadOnlyPixelProvider";if("hashCode".equals(m.getName()))return System.identityHashCode(proxy);if("equals".equals(m.getName()))return proxy==args[0];throw new UnsupportedOperationException(m.getName());});return v.getMethod("read",b,int.class,int.class,fn).invoke(v.getField("INSTANCE").get(null),bounds,image.getWidth(),image.getHeight(),callback);}
  private static JSONObject directOldBoundsReadback(ClassLoader loader,Bitmap current,JSONObject saved,String path)throws Exception{JSONObject page=saved.getJSONObject("visualSelection").getJSONObject("page");byte[] bytes;try(InputStream in=new java.io.FileInputStream(path)){bytes=in.readAllBytes();}Bitmap before=Bitmap.createBitmap(page.getInt("width"),page.getInt("height"),Bitmap.Config.ARGB_8888);before.copyPixelsFromBuffer(ByteBuffer.wrap(bytes));Class<?> b=Class.forName("expo.modules.automationbridge.screen.Bounds",true,loader);JSONArray rows=page.getJSONArray("ocrRegions"),results=new JSONArray();try{for(int i=0;i<rows.length();i++){JSONObject r=rows.getJSONObject(i);String text=r.getString("text");if(r.isNull("visualBounds")||!text.matches("^[A-D][.、．:：].*"))continue;JSONObject j=r.getJSONObject("visualBounds");Object bounds=jsonBounds(b,j);JSONObject out=new JSONObject().put("text",text).put("oldBounds",j).put("beforeState",nullable(pixelRead(loader,before,bounds,0,null,0))).put("currentState",nullable(pixelRead(loader,current,bounds,0,null,0)));if(text.startsWith("B.")){int[] box=new int[]{current.getWidth(),current.getHeight(),0,0,j.getInt("left"),j.getInt("top"),j.getInt("right"),j.getInt("bottom")};Map<Integer,Integer> colors=new java.util.HashMap<>();for(int y=box[5];y<box[7];y++)for(int x=box[4];x<box[6];x++){int c=current.getPixel(x,y),red=(c>>16)&255,green=(c>>8)&255,blue=c&255;if(blue>red+40&&green>red+20)colors.put(c,colors.getOrDefault(c,0)+1);}int color=colors.entrySet().stream().max(Map.Entry.comparingByValue()).orElseThrow().getKey();for(int y=box[5];y<box[7];y++)for(int x=box[4];x<box[6];x++)if(current.getPixel(x,y)==color){box[0]=Math.min(box[0],x);box[1]=Math.min(box[1],y);box[2]=Math.max(box[2],x);box[3]=Math.max(box[3],y);}JSONObject negatives=new JSONObject();negatives.put("uniformFillWithoutTick",nullable(pixelRead(loader,current,bounds,1,box,color))).put("noOuterBackground",nullable(pixelRead(loader,current,bounds,2,box,color))).put("centerDotWithoutBorder",nullable(pixelRead(loader,current,bounds,3,box,color))).put("scope","read-only test pixel-provider substitutions only, not real image/controller state mutation");if(Boolean.TRUE.equals(negatives.opt("uniformFillWithoutTick"))||Boolean.TRUE.equals(negatives.opt("noOuterBackground"))||Boolean.TRUE.equals(negatives.opt("centerDotWithoutBorder")))throw new IllegalStateException("pixel negative unexpectedly confirms selected");out.put("negativePixelProviders",negatives);}results.put(out);}}finally{before.recycle();}return new JSONObject().put("rows",results).put("beforeBytesSha256",sha(bytes)).put("usesExactPreviousRoiNotTapCoordinates",true);}

  private static Object jsonBounds(Class<?> b,JSONObject x)throws Exception{return b.getConstructor(int.class,int.class,int.class,int.class).newInstance(x.getInt("left"),x.getInt("top"),x.getInt("right"),x.getInt("bottom"));}
  private static List<?> restoreCachedRegions(ClassLoader loader,JSONArray rows,String frame,int window)throws Exception{Class<?> r=Class.forName("expo.modules.automationbridge.screen.OcrRegion",true,loader),b=Class.forName("expo.modules.automationbridge.screen.Bounds",true,loader),t=Class.forName("expo.modules.automationbridge.screen.OcrToken",true,loader);java.lang.reflect.Constructor<?> c=r.getConstructor(String.class,String.class,b,String.class,int.class,Boolean.class,b,String.class,List.class,String.class,Integer.class,List.class);List<Object> out=new ArrayList<>();for(int i=0;i<rows.length();i++){JSONObject x=rows.getJSONObject(i);List<Object> tokens=new ArrayList<>();JSONArray ts=x.optJSONArray("visualLatinTokens");if(ts!=null)for(int j=0;j<ts.length();j++){JSONObject token=ts.getJSONObject(j);tokens.add(t.getConstructor(String.class,b).newInstance(token.getString("text"),jsonBounds(b,token.getJSONObject("bounds"))));}List<String> roi=new ArrayList<>();JSONArray rs=x.optJSONArray("visualRoiReadings");if(rs!=null)for(int j=0;j<rs.length();j++)roi.add(rs.getString(j));out.add(c.newInstance(x.getString("ref"),x.getString("text"),jsonBounds(b,x.getJSONObject("bounds")),frame,window,x.isNull("visualChecked")?null:x.getBoolean("visualChecked"),x.isNull("visualBounds")?null:jsonBounds(b,x.getJSONObject("visualBounds")),x.isNull("visualOriginalText")?null:x.getString("visualOriginalText"),tokens,x.isNull("visualRomanSuffix")?null:x.getString("visualRomanSuffix"),x.isNull("visualTextLineHeight")?null:x.getInt("visualTextLineHeight"),roi));}return out;}

  private static List<?> readRaw(Class<?> type,Object reader,ClassLoader loader,Class<?> function,Object unit,Bitmap source,String frame,int attempt)throws Exception {
    CountDownLatch latch=new CountDownLatch(1);AtomicReference<Object> result=new AtomicReference<>();Object cb=Proxy.newProxyInstance(loader,new Class<?>[]{function},(proxy,m,v)->{if("invoke".equals(m.getName())){result.set(v[0]);latch.countDown();return unit;}if("toString".equals(m.getName()))return "RawBeforeMaskCallback";if("hashCode".equals(m.getName()))return System.identityHashCode(proxy);if("equals".equals(m.getName()))return proxy==v[0];throw new UnsupportedOperationException(m.getName());});
    String name=new String[]{"recognize","recognizeOriginal","recognizeAlternate"}[attempt];type.getMethod(name,Bitmap.class,String.class,int.class,function).invoke(reader,source.copy(Bitmap.Config.ARGB_8888,false),frame,-1,cb);if(!latch.await(30,TimeUnit.SECONDS))throw new IllegalStateException("raw OCR timeout");return (List<?>)unwrap(result.get(),loader);
  }
  private static List<?> negativeRegions(ClassLoader loader,List<?> rows,boolean unknown)throws Exception {
    Class<?> r=Class.forName("expo.modules.automationbridge.screen.OcrRegion",true,loader),b=Class.forName("expo.modules.automationbridge.screen.Bounds",true,loader);java.lang.reflect.Constructor<?> c=r.getConstructor(String.class,String.class,b,String.class,int.class,Boolean.class,b,String.class,List.class,String.class,Integer.class,List.class);List<Object> result=new ArrayList<>();
    for(Object row:rows){String text=(String)get(row,"Text");Object checked=get(row,"VisualChecked");if(text.contains("\u5bf9")||text.contains("\u9519"))checked=unknown?null:Boolean.valueOf(text.contains("\u9519"));result.add(c.newInstance(get(row,"Ref"),text,get(row,"Bounds"),get(row,"FrameId"),get(row,"WindowId"),checked,get(row,"VisualBounds"),get(row,"VisualOriginalText"),get(row,"VisualLatinTokens"),get(row,"VisualRomanSuffix"),get(row,"VisualTextLineHeight"),get(row,"VisualRoiReadings")));}return result;
  }

  @Override public void onStart() {
    Bundle result = new Bundle();
    JSONObject report = new JSONObject();
    JSONArray runs = new JSONArray();
    Object reader = null;
    Bitmap screenshot = null;
    File directory = null;
    String stage = "guard";
    int successes = 0; int expectedAttempts = 3;
    try {
      report.put("diagnosticMayInitializeControllerProcess", false).put("independentSelfTarget",true)
        .put("mode", "offlineLocalOcr").put("offlineReconstruction", true);
      if (!"ranchu".equals(Build.HARDWARE)) throw new IllegalStateException("Dedicated ranchu emulator required");
      String expected = args.getString("runId", "");
      if (!expected.matches("[0-9a-fA-F-]{36}")) throw new IllegalArgumentException("Explicit runId required");
      ClassLoader loader = getTargetContext().getClassLoader();
      JSONArray bank;try(InputStream input=getTargetContext().getAssets().open("canonical-bank.json")){bank=new JSONArray(new String(input.readAllBytes(),"UTF-8"));}
      Class<?> optionType=Class.forName("expo.modules.automationbridge.bank.QuestionOption",true,loader),questionType=Class.forName("expo.modules.automationbridge.bank.CanonicalQuestion",true,loader);List<Object> questions=new ArrayList<>();
      for(int n=0;n<bank.length();n++){JSONObject q=bank.getJSONObject(n);List<Object> opts=new ArrayList<>();JSONArray a=q.getJSONArray("options");for(int j=0;j<a.length();j++){JSONObject x=a.getJSONObject(j);opts.add(optionType.getConstructor(String.class,String.class).newInstance(x.getString("id"),x.getString("text")));}List<String> ids=new ArrayList<>();JSONArray c=q.getJSONArray("correctOptionIds");for(int j=0;j<c.length();j++)ids.add(c.getString(j));questions.add(questionType.getConstructor(String.class,String.class,String.class,List.class,List.class).newInstance(q.getString("id"),q.getString("type"),q.getString("stem"),opts,ids));}
      Object recognizer=Class.forName("expo.modules.automationbridge.generic.GenericRecognizer",true,loader).getConstructor(List.class,Set.class).newInstance(questions,Collections.emptySet());report.put("bankCount",questions.size()).put("hardware",Build.HARDWARE);
      Object conflictingAliasRecognizer=null;
      if(args.getString("imagePath","").endsWith("current-mixed-q18.png")){List<Object> conflicted=new ArrayList<>(questions);for(int n=0;n<bank.length();n++){if(bank.getJSONObject(n).getString("id").equals("q1282")){Object q=questions.get(n);conflicted.set(n,questionType.getConstructor(String.class,String.class,String.class,List.class,List.class).newInstance(get(q,"Id"),get(q,"Type"),get(q,"Stem"),get(q,"Options"),Collections.singletonList("A")));}}conflictingAliasRecognizer=Class.forName("expo.modules.automationbridge.generic.GenericRecognizer",true,loader).getConstructor(List.class,Set.class).newInstance(conflicted,Collections.emptySet());report.put("conflictNegativeScope","in-memory read-only copied bank only, q1282 legal answer changed to A; actual source bank/controller/DB untouched");}

      directory = new File(getTargetContext().getExternalFilesDir(null),
        "ocr-diagnostic058-offline-" + expected + "-" + System.currentTimeMillis());
      if (!directory.mkdir()) throw new IllegalStateException("Cannot create isolated evidence directory");
      stage = "saved-clean-image";
      byte[] sourceBytes;
      String imagePath = args.getString("imagePath", "");
      if (imagePath.isEmpty()) throw new IllegalArgumentException("Explicit imagePath required");
      if (!java.util.Arrays.asList("user-tf-input.jpg","current-mixed-q4.png","current-mixed-q7.png","current-mixed-q18.png","current-mixed-q33.png","current-mixed-q53.png","current-focused696.png").contains(new File(imagePath).getName())) {
        throw new IllegalArgumentException("Expected the explicit diagnostic PNG filename");
      }
      try (InputStream input = new java.io.FileInputStream(imagePath)) {
        sourceBytes = input.readNBytes(20 * 1024 * 1024 + 1);
      }
      if (sourceBytes.length == 0 || sourceBytes.length > 20 * 1024 * 1024) {
        throw new IllegalStateException("Saved image missing or exceeds 20 MiB");
      }
      BitmapFactory.Options dimensions = new BitmapFactory.Options();
      dimensions.inJustDecodeBounds = true;
      BitmapFactory.decodeByteArray(sourceBytes, 0, sourceBytes.length, dimensions);
      if (dimensions.outWidth <= 0 || dimensions.outHeight <= 0 ||
          (long) dimensions.outWidth * dimensions.outHeight > 12_000_000L) {
        throw new IllegalStateException("Invalid saved screenshot dimensions");
      }
      BitmapFactory.Options decode = new BitmapFactory.Options();
      decode.inPreferredConfig = Bitmap.Config.ARGB_8888;
      screenshot = BitmapFactory.decodeByteArray(sourceBytes, 0, sourceBytes.length, decode);
      if (screenshot == null) throw new IllegalStateException("Saved screenshot decode failed");
      report.put("captureSource", "providedSavedImage")
        .put("inputSha256", sha(sourceBytes))
        .put("imageLimit", "Offline saved image; no live window or runtime cache reconstruction.");
      ByteArrayOutputStream png = new ByteArrayOutputStream();
      if (!screenshot.compress(Bitmap.CompressFormat.PNG, 100, png)) throw new IllegalStateException("PNG encoding failed");
      byte[] image = png.toByteArray();
      write(new File(directory, "current-screen.png"), image);
      report.put("imageSha256", sha(image)).put("width", screenshot.getWidth()).put("height", screenshot.getHeight());

      Class<?> readerType = Class.forName("expo.modules.automationbridge.screen.LocalOcrReader", true, loader);
      Class<?> function = Class.forName("kotlin.jvm.functions.Function1", true, loader);
      Object unit = Class.forName("kotlin.Unit", true, loader).getField("INSTANCE").get(null);
      Method recognize = readerType.getMethod("recognizeVisual", Bitmap.class, String.class, int.class, int.class, function);
      reader = readerType.getConstructor().newInstance();
      String inputSha = sha(sourceBytes);
      String frameId = "offline-current-" + inputSha;
      List<List<?>> history = new ArrayList<>();
      String cachePath=args.getString("ocrCachePath","");if(!cachePath.isEmpty()){JSONObject saved;try(InputStream in=new java.io.FileInputStream(cachePath)){saved=new JSONObject(new String(in.readAllBytes(),"UTF-8"));}JSONArray replayed=new JSONArray();List<List<?>> prior=new ArrayList<>();for(int a=0;a<3;a++){List<?> rows=restoreCachedRegions(loader,saved.getJSONObject("visualReads").getJSONArray(String.valueOf(a)),frameId,-1);prior.add(rows);Object page=offlineSnapshot(loader,frameId,inputSha,a,screenshot.getWidth(),screenshot.getHeight(),rows,prior);replayed.put(new JSONObject().put("attempt",a).put("observation",replay(recognizer,page)).put("source","exact cached runtime OCR regions, frame/window remapped only for independent reconstruction"));}report.put("savedRuntimeCacheRecognitions",replayed).put("savedRuntimeRunId",saved.getString("runId"));String beforePath=args.getString("preselectionPath","");if(!beforePath.isEmpty())report.put("directOldBoundsReadback",directOldBoundsReadback(loader,screenshot,saved,beforePath));}

      if("true".equals(args.getString("roiProbe","false"))) {
        int[][] cases={{100,492,928,584,1},{100,492,928,584,2},{100,492,462,584,2},{100,492,462,584,4},{255,492,462,584,2},{255,492,462,584,4}};
        expectedAttempts=cases.length;report.put("scope","diagnostic only raw MLKit crops; no text substitution, no canonical matching, no engine/service/account initialization");
        for(int n=0;n<cases.length;n++) {int[] b=cases[n];JSONObject run=new JSONObject().put("attempt",n).put("name",n<2?"whole-error-line":n<4?"reference-with-prefix-context":"reference-three-character-phrase").put("sourceBounds",new JSONObject().put("left",b[0]).put("top",b[1]).put("right",b[2]).put("bottom",b[3])).put("scale",b[4]);runs.put(run);Bitmap crop=Bitmap.createBitmap(screenshot,b[0],b[1],b[2]-b[0],b[3]-b[1]);Bitmap scaled=b[4]==1?crop:Bitmap.createScaledBitmap(crop,crop.getWidth()*b[4],crop.getHeight()*b[4],true);try {List<?> raw=readRaw(readerType,reader,loader,function,unit,scaled,frameId+"-roi-"+n,1);JSONArray found=regions(raw);StringBuilder text=new StringBuilder();for(int z=0;z<found.length();z++){if(z>0)text.append("\n");text.append(found.getJSONObject(z).getString("text"));}run.put("rawOcr",found).put("rawText",text.toString()).put("containsReferenceWithoutFinancialThree",text.toString().contains("参照")&&!text.toString().contains("叁")).put("containsFinancialThree",text.toString().contains("叁")).put("inputWidth",scaled.getWidth()).put("inputHeight",scaled.getHeight()).put("status","completed");try(java.io.OutputStream os=new java.io.FileOutputStream(new File(directory,"roi-"+n+".png"))){scaled.compress(Bitmap.CompressFormat.PNG,100,os);}successes++;}catch(Throwable ex){run.put("status","failed").put("error",root(ex).toString());}finally {if(scaled!=crop)scaled.recycle();crop.recycle();}Bundle progress=new Bundle();progress.putString("stream","raw ROI "+n+": "+run.getString("status")+"\n");sendStatus(0,progress);}
      } else {
      for (int attempt = 0; attempt < 3; attempt++) {
        stage = "offline-ocr-" + attempt;


        JSONObject run = new JSONObject().put("attempt", attempt);
        runs.put(run);
        long started = android.os.SystemClock.elapsedRealtime();
        Bitmap bitmap = screenshot.copy(Bitmap.Config.ARGB_8888, false);
        CountDownLatch completed = new CountDownLatch(1);
        AtomicReference<Object> value = new AtomicReference<>();
        Object callback = Proxy.newProxyInstance(loader, new Class<?>[]{function}, (proxy, method, values) -> {
          if ("invoke".equals(method.getName())) { value.set(values[0]); completed.countDown(); return unit; }
          if ("toString".equals(method.getName())) return "ReadOnlyOcrCallback";
          if ("hashCode".equals(method.getName())) return System.identityHashCode(proxy);
          if ("equals".equals(method.getName())) return proxy == values[0];
          throw new UnsupportedOperationException(method.getName());
        });
        try {
          recognize.invoke(reader, bitmap, frameId, -1, attempt, callback);
          if (!completed.await(30, TimeUnit.SECONDS)) {
            readerType.getMethod("cancelPending").invoke(reader);
            run.put("status", "timeout");
            break;
          }
          Object decoded = unwrap(value.get(), loader);
          if (!(decoded instanceof List<?>)) throw new IllegalStateException("Unexpected OCR response");
          List<?> current = (List<?>) decoded;
          run.put("ocr", regions(current)).put("status", "completed").put("offlineReconstruction", true);
          history.add(current);
          try {
            Object page = offlineSnapshot(loader, frameId, inputSha, attempt,
              screenshot.getWidth(), screenshot.getHeight(), current, history);
            run.put("recognizer", replay(recognizer, page));
            if(conflictingAliasRecognizer!=null){JSONObject negative=replay(conflictingAliasRecognizer,page);run.put("conflictingAliasNegative",negative);if(!negative.getString("kind").equals("Unknown"))throw new IllegalStateException("Conflicting legal answer must remain Unknown");}
          } catch (Throwable replayFailure) {
            run.put("recognizerError", root(replayFailure).toString());
          }

          List<?> rawBefore=readRaw(readerType,reader,loader,function,unit,screenshot,frameId,attempt);
          run.put("rawBeforeMask",regions(rawBefore));
          if(imagePath.endsWith("user-tf-input.jpg")){Object wrongPage=offlineSnapshot(loader,frameId,inputSha,attempt,screenshot.getWidth(),screenshot.getHeight(),negativeRegions(loader,current,false),Collections.singletonList(negativeRegions(loader,current,false)));
          Object unknownPage=offlineSnapshot(loader,frameId,inputSha,attempt,screenshot.getWidth(),screenshot.getHeight(),negativeRegions(loader,current,true),Collections.singletonList(negativeRegions(loader,current,true)));
          JSONObject wrong=replay(recognizer,wrongPage),unknown=replay(recognizer,unknownPage);
          run.put("copiedObservationStateNegatives",new JSONObject().put("scope","synthetic observation fields only; no pixel edit, no controller action/state injection").put("wrongSelected",wrong).put("unknownCorrectState",unknown));
          if(Boolean.TRUE.equals(wrong.opt("expectedSelectionChecked"))||Boolean.TRUE.equals(unknown.opt("expectedSelectionChecked")))throw new IllegalStateException("Negative copied observation unexpectedly confirms expected selection");}
          successes++;
        } catch (Throwable failure) {
          run.put("status", "failed").put("error", root(failure).toString());
        }
        run.put("elapsedMs", android.os.SystemClock.elapsedRealtime() - started);

        Bundle progress = new Bundle();
        progress.putString("stream", "offline OCR " + attempt + ": " + run.getString("status") + "\n");
        sendStatus(0, progress);
      }
      }
      String status = successes == expectedAttempts ? "completed" : "partial";
      report.put("status", status)
        .put("successfulAttempts", successes);
      result.putString("status", status);
    } catch (Throwable failure) {
      try { report.put("status", "failed").put("stage", stage).put("error", root(failure).toString()); }
      catch (Exception ignored) { }
      java.io.StringWriter failureStack=new java.io.StringWriter();failure.printStackTrace(new java.io.PrintWriter(failureStack));result.putString("failureStack",failureStack.toString());
      result.putString("status", "failed");
      result.putString("stage", stage);
      result.putString("error", root(failure).toString());
    } finally {
      if (reader != null) try { ((Closeable) reader).close(); } catch (Exception ignored) { }
      if (screenshot != null) screenshot.recycle();
      try {
        report.put("runs", runs);
        if (directory != null) {
          write(new File(directory, "capture.json"), report.toString(2).getBytes("UTF-8"));
          result.putString("path", directory.getAbsolutePath());
        }
      } catch (Exception failure) { result.putString("evidenceError", failure.toString()); }
      finish("completed".equals(result.getString("status")) ? -1 : 0, result);
    }
  }

  private static Throwable root(Throwable failure) {
    while ((failure instanceof InvocationTargetException || failure instanceof ExceptionInInitializerError) && failure.getCause() != null) failure = failure.getCause();
    return failure;
  }
}
