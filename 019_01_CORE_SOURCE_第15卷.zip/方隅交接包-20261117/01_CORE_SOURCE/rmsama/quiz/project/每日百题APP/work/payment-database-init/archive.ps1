param([Parameter(Mandatory)][string]$Source,[Parameter(Mandatory)][string]$Archive)
$ErrorActionPreference='Stop'
if(Test-Path -LiteralPath $Archive){throw 'archive already exists'}
Add-Type -AssemblyName System.IO.Compression.FileSystem
[IO.Compression.ZipFile]::CreateFromDirectory($Source,$Archive,[IO.Compression.CompressionLevel]::Optimal,$false)
