'use strict';
// Candidate for a future IAM-only direct invocation. It cannot load cloud SDK,
// credentials, environment selection, or expose an HTTP route by itself.
const crypto=require('node:crypto');
const NAMES=Object.freeze(['daily_hundred_payment_v1','daily_hundred_installation_v1']);
const check=x=>{if(!x)throw Error('unavailable');};
function verifier(db,randomId=()=>crypto.randomBytes(16).toString('hex')){
 check(db&&typeof db.runTransaction==='function'&&typeof randomId==='function');
 return async event=>{
  if(!event||typeof event!=='object'||Array.isArray(event)||Object.keys(event).join(',')!=='action'||event.action!=='verify-transaction')return {verified:false,paymentEnabled:false};
  let id=null;
  try{
   const token=randomId();check(typeof token==='string'&&/^[a-f0-9]{32}$/.test(token));id='acl-test-'+token;
   const write=async ref=>{const w=await ref.set({kind:'temporary-acl-test',token});check(w&&!w.code&&(w.updated===1||w.updated===0&&Array.isArray(w.upserted)&&w.upserted.some(x=>x?._id===id)));};
   const absent=async ref=>{const r=await ref.get();check(r&&!r.code&&r.data===null);};
   const policies=async tx=>{for(const name of NAMES){const r=await tx.collection(name).doc('policy').get(),d=r?.data;check(r&&!r.code&&d?._id==='policy'&&d.kind==='policy'&&d.schema===1&&d.enabled===false);}};
   // Commit both records, then prove they are visible outside that transaction.
   await db.runTransaction(async tx=>{
    await policies(tx);const refs=NAMES.map(n=>tx.collection(n).doc(id));for(const ref of refs)await absent(ref);
    for(const ref of refs)await write(ref);
   },1);
   // Remove only records that were just read back with this random marker.
   await db.runTransaction(async tx=>{
    await policies(tx);const refs=NAMES.map(n=>tx.collection(n).doc(id));
    for(const ref of refs){const r=await ref.get();check(r&&!r.code&&r.data?._id===id&&r.data.kind==='temporary-acl-test'&&r.data.token===token);}
    for(const ref of refs){const r=await ref.remove();check(r&&!r.code&&r.deleted===1);}
   },1);
   // Deliberately abort after both writes; absence is then checked in a fresh
   // transaction. An unknown abort outcome is never automatically cleaned up.
   const sentinel=Error('local-rollback-sentinel');let afterWrites=false,expectedAbort=false;
   try{await db.runTransaction(async tx=>{const refs=NAMES.map(n=>tx.collection(n).doc(id));for(const ref of refs)await absent(ref);for(const ref of refs)await write(ref);afterWrites=true;throw sentinel;},1);}
   catch(error){expectedAbort=afterWrites&&error===sentinel;}
   check(expectedAbort);
   await db.runTransaction(async tx=>{for(const n of NAMES)await absent(tx.collection(n).doc(id));await policies(tx);},1);
   return {verified:true,paymentEnabled:false};
  }catch{return id?{verified:false,paymentEnabled:false,testId:id}:{verified:false,paymentEnabled:false};}
 };
}
module.exports={verifier};
