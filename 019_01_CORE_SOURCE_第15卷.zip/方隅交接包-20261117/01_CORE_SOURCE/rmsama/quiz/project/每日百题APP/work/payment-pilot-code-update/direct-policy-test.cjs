'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict'),{enablePolicies}=require('./direct-policy.cjs');
const {Db}=require('../payment-acl-verification/probe-stage/node_modules/@cloudbase/database/dist/commonjs/index.js');
test('real CloudBase database SDK only updates enabled in the two fixed policy documents',async()=>{
 const original=Db.reqClass,docs=new Map(),txs=new Map(),calls=[];let seq=0;
 for(const name of ['daily_hundred_payment_v1','daily_hundred_installation_v1'])docs.set(name+':policy',{kind:'policy',schema:1,enabled:false,unchanged:'fixture'});
 Db.reqClass=class{async send(action,p={}){
  calls.push(action);if(action==='database.startTransaction'){const transactionId='t'+ ++seq;txs.set(transactionId,structuredClone(docs));return {transactionId};}
  if(action==='database.abortTransaction'){txs.delete(p.transactionId);return {};}
  if(action==='database.commitTransaction'){const t=txs.get(p.transactionId);docs.clear();for(const [k,v] of t)docs.set(k,v);txs.delete(p.transactionId);return {};}
  const id=JSON.parse(p.query)._id,key=p.collectionName+':'+id,t=txs.get(p.transactionId);assert.equal(id,'policy');assert.ok(['daily_hundred_payment_v1','daily_hundred_installation_v1'].includes(p.collectionName));assert.equal(p.multi,false);
  if(action==='database.getDocument')return {data:{list:t.has(key)?[JSON.stringify({_id:id,...t.get(key)})]:[]}};
  if(action==='database.modifyDocument'){assert.equal(p.merge,true);assert.equal(p.upsert,false);assert.deepEqual(JSON.parse(p.data),{$set:{enabled:true}});t.set(key,{...t.get(key),enabled:true});return {data:{updated:1}};}
  throw Error('unexpected action');
 }};
 try{assert.equal(await enablePolicies(new Db({throwOnCode:true})),true);assert.equal(calls.filter(x=>x==='database.modifyDocument').length,2);assert.ok([...docs.values()].every(x=>x.enabled===true&&x.unchanged==='fixture'));}finally{Db.reqClass=original;}
});
test('a missing or already-open policy prevents any writes',async()=>{
 let writes=0;const db={runTransaction:async cb=>cb({collection:name=>({doc:()=>({get:async()=>({data:{_id:'policy',kind:'policy',schema:1,enabled:name==='daily_hundred_payment_v1'}}),update:async()=>{writes++;return {updated:1}}})})})};
 await assert.rejects(enablePolicies(db));assert.equal(writes,0);
});
