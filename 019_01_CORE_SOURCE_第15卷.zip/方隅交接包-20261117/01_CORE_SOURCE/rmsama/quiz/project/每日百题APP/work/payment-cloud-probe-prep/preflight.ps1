param()
$ErrorActionPreference='Stop'
$envId='fh6-d5ga45c0ddae7008c'
$functionName='dailyHundredPaymentProbeV1'
$collection='daily_hundred_payment_probe_v1'
$tcb=(Get-Command tcb.ps1 -ErrorAction Stop).Source
function JsonCall([string[]]$arguments) {
  $raw=@(& $tcb @arguments --json 2>$null) -join "`n"
  if($LASTEXITCODE -ne 0){throw "只读云查询失败（$($arguments[0]) $($arguments[1])）；无法确认资源状态，停止。"}
  $index=$raw.IndexOf('{');if($index -lt 0){throw '只读云查询格式异常；停止。'}
  try { $result=$raw.Substring($index)|ConvertFrom-Json } catch { throw '只读云查询无法解析；停止。' }
  if(!$result.data){throw '只读云查询未返回预期数据；停止。'}
  return $result.data
}
$envs=JsonCall @('env','list')
if(@($envs|Where-Object {$_.envId -eq $envId -and $_.status -eq 'NORMAL'}).Count -ne 1){throw '目标环境不可用或不唯一；停止。'}
$functions=@(JsonCall @('fn','list','-e',$envId,'--limit','100'))
if($functions.Count -ge 100){throw '函数列表可能不完整；需分页检查。'}
$functionMatches=@($functions|Where-Object {$_.name -eq $functionName})
$routes=@(JsonCall @('routes','list','-e',$envId,'--limit','100'))
if($routes.Count -ge 100){throw '路由列表可能不完整；需分页检查。'}
$routeMatches=@($routes|Where-Object {$_.upstreamResourceName -eq $functionName})
$query=@{EnvId=$envId;MgoLimit=10;MgoOffset=0;TableNames=@($collection)}|ConvertTo-Json -Compress
$tables=JsonCall @('api','tcb','DescribeTables','-r','ap-shanghai','--api-version','2018-06-08','--body',$query)
if($null -eq $tables.Pager -or $null -eq $tables.Tables){throw '数据库集合检查不完整；停止。'}
$collectionMatches=@($tables.Tables|Where-Object {$_.TableName -eq $collection})
$billingInput=@{EnvId=$envId}|ConvertTo-Json -Compress
$billing=JsonCall @('api','tcb','DescribeBillingInfo','--api-version','2018-06-08','--body',$billingInput)
$plan=@($billing.EnvBillingInfoList|Where-Object {$_.EnvId -eq $envId})
if($plan.Count -ne 1){throw '无法确认环境计费状态；停止。'}
$result=[ordered]@{
  environmentStatus='NORMAL';functionCount=$functions.Count;routeCount=$routes.Count
  probeFunctionExists=($functionMatches.Count -gt 0);probeCollectionExists=($collectionMatches.Count -gt 0)
  probePublicRouteExists=($routeMatches.Count -gt 0);plan=$plan[0].PackageName;planExpiry=$plan[0].ExpireTime
  autoRenew=$plan[0].IsAutoRenew;overrunEnabled=$plan[0].EnableOverrun;environmentQps=$plan[0].EnvQps.QpsQuota
  deploymentPermission='not verified';collectionCreatePermission='not verified';realTransaction='not tested';functionUrl='not created or tested'
}
$result|ConvertTo-Json -Depth 5
if($functionMatches.Count -or $collectionMatches.Count -or $routeMatches.Count){throw '探针目标已有同名资源；拒绝覆盖或复用。'}
Write-Output '只读预检完成；没有创建、部署、调用函数或修改云资源。'
