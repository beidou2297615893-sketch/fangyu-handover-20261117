'use strict';
// Event-function entry is intentionally and unconditionally disabled. It does
// not initialize CloudBase, read env vars/keys, or mount injected components.
const {createProductionMain,createInternalRouter}=require('./billing-event');
const {createInternalCore}=require('./payment-core');
const {createInternalOAuthCore}=require('./oauth-core');
const {createInternalBindingCore}=require('./oauth-bindings');
const {createStableInstallation}=require('./stable-installation');
const main=createProductionMain();

// Offline/internal composition only. No HTTP request may supply these values.
// A real runtime must separately review and construct all dependencies before
// replacing the hard-disabled entry; this function is not a deployment gate.
function createInternalRuntime({db,settings,authenticateInstallation,verifyTaskBinding,now=Date.now,recoveryEnabledForOfflineTest=false,productionReady=false}){
  const billing=createInternalCore({db,appId:settings.appId,sellerId:settings.sellerId,privateKey:settings.privateKey,publicKey:settings.publicKey,notifyUrl:settings.notifyUrl,returnUrl:settings.returnUrl});
  const installation=createStableInstallation({db,registrationKey:settings.registrationKey,clock:now});
  const oauth=recoveryEnabledForOfflineTest?createInternalOAuthCore({db,appId:settings.appId,privateKey:settings.privateKey,publicKey:settings.publicKey,identityKey:settings.identityKey,redirectUrl:settings.oauthRedirectUrl,now}):undefined;
  const bindings=recoveryEnabledForOfflineTest?createInternalBindingCore({db,oauth,authenticateInstallation:authenticateInstallation||installation.authenticate,credentialKey:settings.credentialKey,now}):undefined;
  return createInternalRouter({billing,oauth,bindings,installation,verifyTaskBinding,recoveryEnabledForOfflineTest,productionReady});
}
module.exports={main,createInternalRuntime};
