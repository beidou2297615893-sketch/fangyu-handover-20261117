from pathlib import Path
from PIL import Image
import gzip,struct
r=Path('V:/work/original-vs-0419');roots=[Path('V:/work/tijing-bankassist/android/app/src/test'),r/'regression-stage/app/src/test']
for root in roots:
    for number in [48,58,63,70,81]:
        image=Image.open(r/f'railway-corpus/{number-1:03d}.png').convert('RGBA')
        with gzip.open(root/f'resources/regression/contrast-{number:03d}.argb.gz','wb') as file:
            file.write(struct.pack('>ii',*image.size))
            for red,green,blue,alpha in image.get_flattened_data():file.write(struct.pack('>I',alpha<<24|red<<16|green<<8|blue))
    source='''package com.futureyyy.tijing
import java.io.DataInputStream
import java.util.zip.GZIPInputStream
import org.junit.Test
import org.junit.Assert.*

class ContrastCardRegressionTest {
    @Test fun paleRadioControlsRemainPhysicalEvidenceForCompleteOutlinedChoices() {
        for(number in listOf(48,58,63,70,81)) {
            val input=DataInputStream(GZIPInputStream(javaClass.getResourceAsStream("/regression/contrast-%03d.argb.gz".format(number))!!))
            val width=input.readInt();val height=input.readInt()
            val pixels=IntArray(width*height){input.readInt()};input.close()
            val cards=ShortChoiceCards.locate(width,height,pixels)
            assertEquals("Real frame $number has four visible full radio choices",4,cards.size)
            assertTrue(cards.zipWithNext().all{(a,b)->a.card.bottom<b.card.top})
        }
    }
}
'''
    (root/'java/com/futureyyy/tijing/ContrastCardRegressionTest.kt').write_text(source,encoding='utf-8')
print('Five actual contrast frames staged for one physical-layout regression.')
