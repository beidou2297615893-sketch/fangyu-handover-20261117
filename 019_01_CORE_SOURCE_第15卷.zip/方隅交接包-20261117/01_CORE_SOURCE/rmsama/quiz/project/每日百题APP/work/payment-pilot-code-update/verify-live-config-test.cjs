'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict'),{verify}=require('./verify-live-config.cjs');
test('accepts only the exact expected live config, without returning its contents',async()=>{
 const keys=['BILLING_ENABLED','BILLING_NATIVE_ADMISSION_READY','BILLING_NATIVE_RELEASE_VERIFIED','BILLING_CLOUD_ACL_VERIFIED','BILLING_PILOT_ENABLED'],Variables=[...keys.map(Key=>({Key,Value:'true'})),{Key:'merchant-key',Value:'synthetic-secret'}],expected={FunctionName:'dailyHundredBillingV1',Namespace:'fh6-d5ga45c0ddae7008c',Environment:{Variables}};
 const make=v=>({GetFunction:async()=>({...expected,Type:'Event',Runtime:'Nodejs20.19',Handler:'production-entry.main',Status:'Active',Environment:{Variables:v}})});
 assert.equal(await verify(make(Variables),expected,{attempts:1}),true);assert.equal(await verify(make(Variables.map(x=>x.Key==='merchant-key'?{...x,Value:'other'}:x)),expected,{attempts:1}),false);assert.equal(await verify(make(Variables.slice(1)),expected,{attempts:1}),false);
});
