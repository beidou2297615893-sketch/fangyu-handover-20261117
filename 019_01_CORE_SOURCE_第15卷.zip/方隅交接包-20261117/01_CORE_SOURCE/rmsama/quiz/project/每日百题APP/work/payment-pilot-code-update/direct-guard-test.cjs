'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict'),{allowed}=require('./direct-guard.cjs');
function req(){return {url:'https://fh6-d5ga45c0ddae7008c.ap-shanghai.tcb-api.tencentcloudapi.com/admin?env=fh6-d5ga45c0ddae7008c&seqId=fixture',method:'post',keepalive:false,body:{envName:'fh6-d5ga45c0ddae7008c',action:'database.getDocument',collectionName:'daily_hundred_payment_v1',query:'{"_id":"policy"}',multi:false}};}
test('only fixed policy reads are allowed in read-only mode',()=>{let x=req();assert.equal(allowed(x),true);for(const mutate of [r=>r.body.collectionName='other',r=>r.body.query='{"_id":"other"}',r=>r.body.query='{"_id":"other","_id":"policy"}',r=>r.url='https://evil.invalid/admin?env=fh6-d5ga45c0ddae7008c',r=>r.url+='&env=other',r=>r.url+='&seqId=other',r=>r.proxy='fake',r=>r.formData={bad:true},r=>r.qs={bad:true},r=>r.body.action='database.modifyDocument']){x=req();mutate(x);assert.equal(allowed(x),false)}});
test('write mode allows only exact enabled field and fixed transaction operations',()=>{let x=req();Object.assign(x.body,{action:'database.modifyDocument',merge:true,upsert:false,data:'{"$set":{"enabled":true}}'});assert.equal(allowed(x,true),true);assert.equal(allowed(x,false),false);for(const data of ['{"$set":{"enabled":false}}','{"$set":{"enabled":true,"other":1}}','{"$set":{"enabled":false,"enabled":true}}']){x.body.data=data;assert.equal(allowed(x,true),false)}});
test('real node SDK uses the guarded target for the actual policy read request',async()=>{
 const path=require('node:path'),home=path.resolve(__dirname,'dailyHundredBillingV1/node_modules/@cloudbase/node-sdk'),platform=require(path.join(home,'dist/utils/cloudplatform.js')),core=require(path.join(home,'dist/utils/request-core.js'));
 const oldPre=platform.preflightRuntimeCloudPlatform,oldInternal=platform.checkIsInternalAsync,oldRequest=core.request;let calls=0;
 platform.preflightRuntimeCloudPlatform=async()=>{};platform.checkIsInternalAsync=async()=>false;
 core.request=(opts,cb)=>{assert.equal(allowed(opts,false),true);calls++;queueMicrotask(()=>cb(null,{statusCode:200,headers:{}},{data:{list:[JSON.stringify({_id:'policy',kind:'policy',schema:1,enabled:false})]}}));};
 try{const app=require(home).init({env:'fh6-d5ga45c0ddae7008c',secretId:'fixture',secretKey:'fixture',sessionToken:'fixture',region:'ap-shanghai',protocol:'https',keepalive:false,retries:0});const r=await app.database({throwOnCode:true}).collection('daily_hundred_payment_v1').doc('policy').get();assert.equal(r.data[0].enabled,false);assert.equal(calls,1);}finally{platform.preflightRuntimeCloudPlatform=oldPre;platform.checkIsInternalAsync=oldInternal;core.request=oldRequest;}
});
async function transactionFixture(mode){
 const path=require('node:path'),home=path.resolve(__dirname,'dailyHundredBillingV1/node_modules/@cloudbase/node-sdk'),platform=require(path.join(home,'dist/utils/cloudplatform.js')),core=require(path.join(home,'dist/utils/request-core.js'));
 const oldPre=platform.preflightRuntimeCloudPlatform,oldInternal=platform.checkIsInternalAsync,oldRequest=core.request;let calls=[],docs=new Map();for(const n of ['daily_hundred_payment_v1','daily_hundred_installation_v1'])docs.set(n,{_id:'policy',kind:'policy',schema:1,enabled:false});let current;
 platform.preflightRuntimeCloudPlatform=async()=>{};platform.checkIsInternalAsync=async()=>false;
 core.request=(opts,cb)=>{assert.equal(allowed(opts,true),true);const p=opts.body;calls.push(p.action);let response={};
  if(p.action==='database.startTransaction'){current=structuredClone(docs);response={transactionId:'synthetic'};}
  else if(p.action==='database.getDocument')response={data:{list:[JSON.stringify(current.get(p.collectionName))]}};
  else if(p.action==='database.modifyDocument'){if(mode==='modify-failure'&&calls.filter(x=>x==='database.modifyDocument').length===2){queueMicrotask(()=>cb(Error('synthetic'),null,null));return;}current.set(p.collectionName,{...current.get(p.collectionName),enabled:true});response={data:{updated:1}};}
  else if(p.action==='database.commitTransaction'){docs=structuredClone(current);if(mode==='lost-commit'){queueMicrotask(()=>cb(Error('synthetic'),null,null));return;}}
  else if(p.action!=='database.abortTransaction')throw Error('unexpected action');
  queueMicrotask(()=>cb(null,{statusCode:200,headers:{}},response));
 };
 try{const app=require(home).init({env:'fh6-d5ga45c0ddae7008c',secretId:'fixture',secretKey:'fixture',sessionToken:'fixture',region:'ap-shanghai',protocol:'https',keepalive:false,retries:0});const operation=require('./direct-policy.cjs').enablePolicies(app.database({throwOnCode:true}));if(mode)await assert.rejects(operation);else assert.equal(await operation,true);assert.equal(calls.filter(x=>x==='database.modifyDocument').length,2);assert.ok([...docs.values()].every(x=>x.enabled===(mode!=='modify-failure')));return calls;}finally{platform.preflightRuntimeCloudPlatform=oldPre;platform.checkIsInternalAsync=oldInternal;core.request=oldRequest;}
}
test('actual node SDK transaction crosses the network guard and only edits the two policies',async()=>{const calls=await transactionFixture(null);assert.equal(calls.filter(x=>x==='database.commitTransaction').length,2)});
test('lost commit response is left uncertain with no write retry',async()=>{const calls=await transactionFixture('lost-commit');assert.equal(calls.filter(x=>x==='database.commitTransaction').length,1)});
test('mid-transaction write failure never commits or retries',async()=>{const calls=await transactionFixture('modify-failure');assert.equal(calls.filter(x=>x==='database.commitTransaction').length,0);assert.equal(calls.filter(x=>x==='database.abortTransaction').length,1)});
