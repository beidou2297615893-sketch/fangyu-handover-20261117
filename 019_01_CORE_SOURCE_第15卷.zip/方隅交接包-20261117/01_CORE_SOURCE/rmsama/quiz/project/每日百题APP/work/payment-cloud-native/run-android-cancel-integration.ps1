$ErrorActionPreference='Stop'
$root=Split-Path -Parent (Split-Path -Parent $PSScriptRoot)
$jdk=(Get-ChildItem (Join-Path $root 'work/tools/jdk') -Directory | Select-Object -First 1).FullName
$lib=(Get-ChildItem (Join-Path $root 'work/gradle-home/wrapper/dists/gradle-9.3.1-bin') -Directory -Recurse -Filter lib | Select-Object -First 1).FullName
$java=Join-Path $jdk 'bin/java.exe';$stdlib=Join-Path $lib 'kotlin-stdlib-2.2.21.jar';$json=Join-Path $root 'work/native-host-tests/json-20250517.jar'
$classes=Join-Path $PSScriptRoot 'android-cancel-integration-classes';New-Item -ItemType Directory -Force $classes | Out-Null
$native=Join-Path $root 'outputs/daily-hundred-app/modules/automation-bridge/android/src/main/java/expo/modules/automationbridge/billing/NativeAdmissionClient.kt'
$build=Join-Path $root 'work/native-admission-client-candidate/TestBuildConfig.kt'
& $java '-Dfile.encoding=UTF-8' -cp "$lib/*" org.jetbrains.kotlin.cli.jvm.K2JVMCompiler -no-stdlib -no-reflect -classpath "$stdlib;$json" -d $classes $native $build (Join-Path $PSScriptRoot 'AndroidCancelIntegrationTest.kt')
if($LASTEXITCODE -ne 0){throw 'Android cancellation test compilation failed'}
$env:TEST_JAVA=$java;$env:TEST_CLASSPATH="$classes;$stdlib;$json"
try { & node (Join-Path $PSScriptRoot 'android-cancel-integration.js');if($LASTEXITCODE -ne 0){throw 'Android cancellation integration failed'} }
finally { Remove-Item Env:TEST_JAVA,Env:TEST_CLASSPATH -ErrorAction SilentlyContinue }
