'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict'),{verifier}=require('./role-transaction.cjs'),{verifyClient}=require('./client-negative.cjs');
const names=['daily_hundred_payment_v1','daily_hundred_installation_v1'];
function serverFixture(fault=''){
 const docs=new Map(names.map(n=>[n+':policy',{kind:'policy',schema:1,enabled:false}])),touched=[];
 const db={async runTransaction(fn){const shadow=structuredClone(docs);const tx={collection(name){assert.ok(names.includes(name));touched.push(name);return {doc(id){return {
  async get(){const key=name+':'+id;return {data:shadow.has(key)?{_id:id,...shadow.get(key)}:null}},
  async set(v){if(fault==='write')throw Error();shadow.set(name+':'+id,v);return {updated:1}},
  async remove(){shadow.delete(name+':'+id);return {deleted:1}}
 }}}}};const result=await fn(tx);docs.clear();for(const [k,v] of shadow)docs.set(k,v);return result;}};
 return {docs,touched,run:verifier(db,()=> 'a'.repeat(32))};
}
test('role tests cross-collection commit and rollback while preserving disabled policies',async()=>{
 const f=serverFixture();assert.deepEqual(await f.run({action:'verify-transaction'}),{verified:true,paymentEnabled:false});
 assert.equal(f.docs.size,2);for(const v of f.docs.values())assert.equal(v.enabled,false);assert.deepEqual([...new Set(f.touched)],names);
});
test('role rejects enabled policy, failed write and invalid request without claiming success',async()=>{
 const f=serverFixture();f.docs.get(names[0]+':policy').enabled=true;assert.equal((await f.run({action:'verify-transaction'})).verified,false);
 assert.equal((await serverFixture('write').run({action:'verify-transaction'})).verified,false);assert.equal((await f.run({action:'wrong'})).verified,false);
});
const session={access_token:'synthetic',user:{is_anonymous:true}},denied=()=>Promise.reject({code:'DATABASE_PERMISSION_DENIED'});
function clientFixture(behavior='deny'){
 let calls=0;const op=()=>{calls++;return behavior==='deny'?denied():behavior==='timeout'?Promise.reject({code:'DATABASE_TIMEOUT'}):Promise.resolve({data:[]});};
 return {db:{collection(name){assert.ok(names.includes(name));return {doc(id){assert.match(id,/^acl-test-[a-f0-9]{32}$/);return {get:op,set:op}},where(){return {limit(){return {get:op}}}}}}},get calls(){return calls}};
}
test('negative tests require the actual database denial for read, query and write',async()=>{
 const f=clientFixture();assert.deepEqual(await verifyClient(f.db,session,'anonymous',()=> 'a'.repeat(32)),{verified:true});assert.equal(f.calls,6);
});
test('authentication, timeout or unexpected access are never mistaken for an ACL pass',async()=>{
 const f=clientFixture();assert.equal((await verifyClient(f.db,session,'registered')).reason,'identity-unverified');assert.equal(f.calls,0);
 assert.equal((await verifyClient(clientFixture('timeout').db,session,'anonymous')).reason,'indeterminate');
 const exposed=await verifyClient(clientFixture('allowed').db,session,'anonymous',()=> 'a'.repeat(32));assert.equal(exposed.reason,'unexpected-access');assert.match(exposed.testId,/^acl-test-/);
});
test('browser module uses existing session and never confuses missing authorization with ACL denial',async()=>{
 const {verifyClient:browser}=await import('./browser-negative.mjs');const f=clientFixture();
 assert.deepEqual(await browser(f.db,session,'anonymous',()=> 'a'.repeat(32)),{verified:true});
 assert.equal((await browser(clientFixture('timeout').db,session,'anonymous')).reason,'indeterminate');
 assert.equal((await browser(f.db,{...session,user:{is_anonymous:false}},'anonymous')).reason,'identity-unverified');
});
test('updated probe still routes diagnostic and policy checks as before',async()=>{
 const {makeMain}=require('./probe-stage/isolated-probe.js');let dbCalls=0;
 const expected={paymentEnabled:false,database:true,alipayTls:true},main=makeMain(async()=>expected,async()=>{dbCalls++;throw Error()});
 assert.deepEqual(await main({action:'diagnostic'}),expected);assert.equal(dbCalls,0);
 assert.deepEqual(await main({action:'verify-transaction'}),{verified:false,paymentEnabled:false});assert.equal(dbCalls,1);
});
test('existing-session adapter checks identity without initiating any login',async()=>{
 const {verifyExistingSession}=await import('./existing-session-verifier.mjs');const f=clientFixture();let logins=0;
 const app={auth:{getSession:async()=>({data:{session},error:null}),signInAnonymously:async()=>{logins++;throw Error()}},database:()=>f.db};
 assert.deepEqual(await verifyExistingSession(app,'anonymous'),{verified:true});assert.equal(logins,0);
 assert.equal((await verifyExistingSession({auth:{getSession:async()=>({data:{session:null}})},database:()=>f.db},'registered')).reason,'identity-unverified');
});
