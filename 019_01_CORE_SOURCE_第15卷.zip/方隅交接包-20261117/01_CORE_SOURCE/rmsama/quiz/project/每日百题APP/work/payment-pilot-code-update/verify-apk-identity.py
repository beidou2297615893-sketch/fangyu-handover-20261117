import hashlib, json, pathlib, zipfile
root=pathlib.Path(__file__).resolve().parent.parent/'payment-pilot-private'
try:
    ident=json.loads((root/'identity.json').read_text(encoding='utf-8'))
    apk=root/'pilot-acceptance-0.3.18.apk'
    digest=hashlib.sha256(apk.read_bytes()).hexdigest()
    expected='3b8377b5204bcfcefa9606bea3d029ec43ae508bdca9871ecc39783b33f748d6'
    found={k:False for k in ('requestId','verifier','clientRequestId')}
    with zipfile.ZipFile(apk) as z:
        dex=[x for x in z.infolist() if x.filename.startswith('classes') and x.filename.endswith('.dex')]
        if not dex or any(x.file_size>80_000_000 for x in dex): raise ValueError()
        for item in dex:
            raw=z.read(item)
            for key in found:
                value=ident.get(key)
                if not isinstance(value,str) or len(value)!=43 or not value.isascii(): raise ValueError()
                found[key] |= value.encode('ascii') in raw
    print(json.dumps({'apkHashMatches':digest==expected,'allIdentityFieldsPresent':all(found.values()),'cloudWrite':False}))
    if digest!=expected or not all(found.values()): raise SystemExit(2)
except Exception:
    print('{"verified":false,"cloudWrite":false}')
    raise SystemExit(2)
