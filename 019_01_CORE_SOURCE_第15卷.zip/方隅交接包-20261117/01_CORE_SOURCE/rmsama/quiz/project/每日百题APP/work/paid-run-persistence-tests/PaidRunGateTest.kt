package expo.modules.automationbridge.billing

private fun denied(f:()->Unit){var bad=false;try{f()}catch(_:Exception){bad=true};check(bad)}
private class Store:PaidRunGateStore {
  val rows=mutableMapOf<String,GateRecord>()
  override fun read(id:String)=rows[id]
  override fun saveReserved(record:GateRecord):GateRecord {val old=rows[record.runId];if(old==null)rows[record.runId]=record;return rows.getValue(record.runId)}
  override fun move(id:String,owner:String,binding:String,from:String,to:String):Boolean {
    val r=rows[id]?:return false;if(r.owner!=owner||r.binding!=binding||r.phase!=from)return false;rows[id]=r.copy(phase=to);return true
  }
}
private class Remote:PaidRunGateRemote {
  var state="none";var transitions=0;var confirmations=0;var releases=0;var eligible=true;var loseReserve=false;var loseConfirm=false;var loseRelease=false;var loseCancel=false;var responseOwner="owner";var responseBinding:String?=null
  override fun reserve(id:String,binding:String):GateReceipt {
    check(eligible);if(state=="none"){state="reserved";transitions++};if(loseReserve){loseReserve=false;error("lost")};return GateReceipt(id,state,"credit",responseOwner,responseBinding?:binding)
  }
  override fun confirm(id:String,binding:String):GateReceipt {
    check(state in setOf("reserved","confirmed"));if(state=="reserved"){confirmations++;state="confirmed"};if(loseConfirm){loseConfirm=false;error("lost")};return GateReceipt(id,state,"credit",responseOwner,responseBinding?:binding)
  }
  override fun release(id:String,binding:String):GateReceipt {
    check(state in setOf("reserved","released"));if(state=="reserved"){releases++;state="released"};if(loseRelease){loseRelease=false;error("lost")};return GateReceipt(id,state,"credit",responseOwner,responseBinding?:binding)
  }
  override fun authorizeContinue(id:String,binding:String):GateReceipt {check(eligible&&state=="confirmed");return GateReceipt(id,"authorized","credit",responseOwner,responseBinding?:binding)}
  override fun cancel(id:String,binding:String):GateReceipt {check(state!="confirmed");state="cancelled";if(loseCancel){loseCancel=false;error("lost")};return GateReceipt(id,"cancelled","",responseOwner,responseBinding?:binding)}
}
object PaidRunGateTest {
  @JvmStatic fun main(args:Array<String>){var n=0;fun test(name:String,f:()->Unit){f();n++;println("PASS $name")}
    val binding="a".repeat(64)
    test("lost reserve response retries same paid run once") {
      val s=Store();val r=Remote();val g=PaidRunGate(s,r);r.loseReserve=true;denied{g.reserve("run","owner",binding)}
      check(s.read("run")==null);g.reserve("run","owner",binding);check(r.transitions==1&&s.read("run")?.phase=="reserved")
    }
    test("server cannot authorize absent or uncertain local receipt") {
      val s=Store();val r=Remote();r.state="confirmed";val g=PaidRunGate(s,r)
      denied{g.reserve("run","owner",binding)};s.rows["run"]=GateRecord("run","owner",binding,"credit","unknown")
      denied{g.reserve("run","owner",binding)};denied{g.settle("run","owner",binding)};check(!g.mayAdvance("run","owner",binding))
    }
    test("reserved remote state does not allow start while local submission or release is unresolved") {
      val s=Store();val r=Remote();val g=PaidRunGate(s,r);g.reserve("run","owner",binding)
      for(phase in listOf("unknown","receipt_confirmed","releasing")) {
        s.rows["run"]=s.rows.getValue("run").copy(phase=phase)
        denied{g.reserve("run","owner",binding)};check(!g.mayAdvance("run","owner",binding))
      }
    }
    test("lost confirm response retries without a second charge and gates next actions") {
      val s=Store();val r=Remote();val g=PaidRunGate(s,r);g.reserve("run","owner",binding)
      s.rows["run"]=s.rows.getValue("run").copy(phase="receipt_confirmed");r.loseConfirm=true
      denied{g.settle("run","owner",binding)};check(!g.mayAdvance("run","owner",binding))
      g.settle("run","owner",binding);check(g.mayAdvance("run","owner",binding)&&r.confirmations==1)
      g.pause("run");check(!g.mayAdvance("run","owner",binding));g.resume("run","owner",binding);check(g.mayAdvance("run","owner",binding))
      r.eligible=false;g.pause("run");denied{g.resume("run","owner",binding)};check(!g.mayAdvance("run","owner",binding))
    }
    test("release is retryable only before uncertain submission") {
      val s=Store();val r=Remote();val g=PaidRunGate(s,r);g.reserve("run","owner",binding)
      s.rows["run"]=s.rows.getValue("run").copy(phase="unknown");denied{g.release("run","owner",binding)};check(r.releases==0)
      s.rows["run"]=s.rows.getValue("run").copy(phase="reserved");r.loseRelease=true;denied{g.release("run","owner",binding)}
      check(s.read("run")?.phase=="releasing");g.release("run","owner",binding);check(s.read("run")?.phase=="released"&&r.releases==1)
    }
    test("owner binding and source must remain fixed") {
      val s=Store();val r=Remote();val g=PaidRunGate(s,r);g.reserve("run","owner",binding)
      denied{g.reserve("run","other",binding)};denied{g.reserve("run","owner","b".repeat(64))}
    }
    test("credential switched to another valid account cannot authorize an old paid run") {
      val s=Store();val r=Remote();val g=PaidRunGate(s,r);r.responseOwner="other";denied{g.reserve("run","owner",binding)}
      check(s.read("run")==null);r.responseOwner="owner";r.responseBinding="b".repeat(64);denied{g.reserve("run","owner",binding)}
    }
    test("cancel no reservation and prevent late reserve; unknown cannot cancel") {
      val s=Store();val r=Remote();val g=PaidRunGate(s,r)
      g.cancelUnsubmitted("run","owner",binding);check(r.state=="cancelled");denied{g.reserve("run","owner",binding)}
      val s2=Store();val r2=Remote();val g2=PaidRunGate(s2,r2);g2.reserve("run","owner",binding)
      s2.rows["run"]=s2.rows.getValue("run").copy(phase="unknown");denied{g2.cancelUnsubmitted("run","owner",binding)};check(r2.state=="reserved")
      val s3=Store();val r3=Remote();val g3=PaidRunGate(s3,r3);g3.reserve("run","owner",binding);r3.loseCancel=true
      denied{g3.cancelUnsubmitted("run","owner",binding)};check(s3.read("run")?.phase=="releasing")
      g3.cancelUnsubmitted("run","owner",binding);check(s3.read("run")?.phase=="released")
    }
    test("pause and action check never wait for network and late confirmation cannot resume") {
      val s=Store();val entered=java.util.concurrent.CountDownLatch(1);val unblock=java.util.concurrent.CountDownLatch(1)
      val r=object:PaidRunGateRemote {
        override fun reserve(id:String,b:String)=GateReceipt(id,"reserved","credit","owner",b)
        override fun confirm(id:String,b:String):GateReceipt { entered.countDown();check(unblock.await(2,java.util.concurrent.TimeUnit.SECONDS));return GateReceipt(id,"confirmed","credit","owner",b) }
        override fun release(id:String,b:String)=GateReceipt(id,"released","credit","owner",b)
        override fun authorizeContinue(id:String,b:String)=GateReceipt(id,"authorized","credit","owner",b)
        override fun cancel(id:String,b:String)=GateReceipt(id,"cancelled","","owner",b)
      }
      val g=PaidRunGate(s,r);g.reserve("run","owner",binding);s.rows["run"]=s.rows.getValue("run").copy(phase="receipt_confirmed")
      val worker=Thread{g.settle("run","owner",binding)};worker.start();check(entered.await(1,java.util.concurrent.TimeUnit.SECONDS))
      val checksDone=java.util.concurrent.CountDownLatch(1)
      val pauser=Thread{g.pause("run");check(!g.mayAdvance("run","owner",binding));checksDone.countDown()};pauser.start()
      val prompt=checksDone.await(250,java.util.concurrent.TimeUnit.MILLISECONDS);unblock.countDown();worker.join();pauser.join()
      check(prompt){"pause or action check blocked on payment network"};check(!g.mayAdvance("run","owner",binding)){"late payment response resumed a paused task"}
    }
    println("RESULT: $n isolated paid gate tests passed")
  }
}
