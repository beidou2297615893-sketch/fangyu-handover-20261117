// Offline-only candidate. Injected adapters; no SDK credentials or network code.
const crypto = require('node:crypto');
function identity() {
 const uid='pa'+crypto.randomBytes(16).toString('hex');
 const name='pa'+crypto.randomBytes(8).toString('hex');
 const description='payment-acl:'+crypto.randomBytes(16).toString('hex');
 const password='Aa1!'+crypto.randomBytes(18).toString('base64url');
 return {uid,name,description,password};
}
function exact(data, x) {
 return Array.isArray(data) && data.length===1 && data[0].Uid===x.uid && data[0].Name===x.name && data[0].Description===x.description && data[0].Type==='internalUser';
}
async function run({api, browser, record, makeIdentity=identity}) {
 if (!api || !browser || typeof browser.verify !== 'function' || typeof record !== 'function') return {verified:false,reason:'adapters-unavailable',cleanup:'not-attempted'};
 const x=makeIdentity();
 if (!/^pa[a-f0-9]{32}$/.test(x.uid) || !/^pa[a-f0-9]{16}$/.test(x.name) || !/^payment-acl:[a-f0-9]{32}$/.test(x.description) || !/^Aa1![A-Za-z0-9_-]{24}$/.test(x.password)) return {verified:false,reason:'invalid-identity',cleanup:'not-attempted'};
 try { const existing=await api.find(x.uid); if (!Array.isArray(existing)||existing.length!==0) return {verified:false,reason:'identity-conflict-or-unknown',cleanup:'not-attempted'}; }
 catch { return {verified:false,reason:'preflight-unknown',cleanup:'not-attempted'}; }
 // Marker contains no password, and is required before create for manual recovery.
 try { await record({uid:x.uid,name:x.name,description:x.description}); } catch {return {verified:false,reason:'marker-failed',cleanup:'not-attempted'};}
 let created;
 try { created=await api.create({Uid:x.uid,Name:x.name,Description:x.description,Password:x.password,Type:'internalUser',UserStatus:'ACTIVE'}); }
 catch { return {verified:false,reason:'create-unknown',cleanup:'not-attempted'}; }
 if (created?.Uid!==x.uid) return {verified:false,reason:'create-unconfirmed',cleanup:'not-attempted'};
 let result={verified:false,reason:'identity-unconfirmed'};
 try {
  if (exact(await api.find(x.uid),x)) {
   const r=await browser.verify({username:x.name,password:x.password,uid:x.uid});
   // Only explicit all-denied result from independently verified registered identity counts.
   result=r?.verified===true && r?.uidVerified===true && r?.registered===true ? {verified:true} : {verified:false,reason:'client-check-incomplete'};
   if(r?.reason==='unexpected-access' && /^acl-test-[a-f0-9]{32}$/.test(r.testId||'')) result={verified:false,reason:'unexpected-access',testId:r.testId};
  }
 } catch { result={verified:false,reason:'client-check-unknown'}; }
 try {
  if (!exact(await api.find(x.uid),x)) return {...result,verified:false,cleanup:'identity-mismatch'};
  const deleted=await api.delete([x.uid]);
  if (deleted?.SuccessCount!==1 || deleted?.FailedCount!==0) return {...result,verified:false,cleanup:'unknown'};
  const remaining=await api.find(x.uid);
  if (!Array.isArray(remaining)||remaining.length!==0) return {...result,verified:false,cleanup:'unknown'};
  return {...result,cleanup:'verified'};
 } catch { return {...result,verified:false,cleanup:'unknown'}; }
}
module.exports={run,identity};
