'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict'),{verifier}=require('./role-transaction.cjs');
const {Db}=require('./probe-stage/node_modules/@cloudbase/database/dist/commonjs/index.js');
const {EJSON}=require('../../outputs/managed-import-cloudbase/node_modules/bson');
test('actual CloudBase database SDK runs cross-collection write/delete and abort with synthetic transport',async()=>{
 const original=Db.reqClass,docs=new Map(),txs=new Map(),calls=[];let id=0;
 for(const name of ['daily_hundred_payment_v1','daily_hundred_installation_v1'])docs.set(name+':policy',{kind:'policy',schema:1,enabled:false});
 Db.reqClass=class{async send(action,p={}){
  calls.push(action);
  if(action==='database.startTransaction'){const transactionId='t'+ ++id;txs.set(transactionId,structuredClone(docs));return {transactionId};}
  if(action==='database.abortTransaction'){txs.delete(p.transactionId);return {};}
  if(action==='database.commitTransaction'){const t=txs.get(p.transactionId);docs.clear();for(const [k,v] of t)docs.set(k,v);txs.delete(p.transactionId);return {};}
  const t=txs.get(p.transactionId),key=p.collectionName+':'+JSON.parse(p.query)._id;
  if(action==='database.getDocument')return {data:{list:t.has(key)?[JSON.stringify({_id:JSON.parse(p.query)._id,...t.get(key)})]:[]}};
  if(action==='database.modifyDocument'){t.set(key,EJSON.parse(p.data));return {data:{updated:1}};}
  if(action==='database.removeDocument'){t.delete(key);return {data:{deleted:1}};}
  throw Error('unexpected fake action');
 }};
 try{
  const result=await verifier(new Db({throwOnCode:true}),()=> 'a'.repeat(32))({action:'verify-transaction'});
  assert.deepEqual(result,{verified:true,paymentEnabled:false},calls.join(','));assert.equal(docs.size,2);assert.equal(calls.filter(x=>x==='database.abortTransaction').length,1);
 }finally{Db.reqClass=original;}
});
