package com.futureyyy.tijing
import com.google.gson.*
import java.io.File
fun main(){
 val bankRoot=JsonParser.parseString(File("V:/work/知题本轮验收/bank/铁路题库-保留选项变体.json").readText()).asJsonObject
 fun type(s:String)=when(s){"multiple"->QuestionType.MULTIPLE;"boolean","true_false"->QuestionType.TRUE_FALSE;"fill_blank"->QuestionType.FILL_BLANK;else->QuestionType.SINGLE}
 val records=bankRoot.getAsJsonArray("questions").map{v->val q=v.asJsonObject;LocalQuestionBankRecord(q.get("id").asString,q.get("question").asString,type(q.get("type").asString),q.getAsJsonArray("answer_indices").map{it.asInt},answerText=q.get("answer_text").asString,options=q.getAsJsonArray("options").map {val o=it.asJsonObject;QuizOption(o.get("index").asInt,o.get("text").asString,null)})}
 val bank=QuestionBankIndex.fromRecords(records, bankRoot.getAsJsonArray("conflicts").map { it.asJsonObject["normalized_question"].asString }.toSet())
 val d=File("V:/work/ocr0419-evidence/third")
 val refs=JsonParser.parseString(File("V:/work/ocr0419-evidence/ocr-fixtures.json").readText()).asJsonArray
 val source=refs.associate { val r=it.asJsonObject;r["file"].asString.replace("upstream-response","upstream-input").replace(".json",".png") to r["expected"].asJsonArray.map{e->e.asString.single()-'A'}.toSet() }
 val selected=source+mapOf("sample-h2.png" to setOf(0),"sample-h4.png" to setOf(0),"sample-h5.png" to setOf(0,1,2))
 for(mode in listOf("production","native","scale150","grayContrast","scale280Pad","lineMosaic")){
 val file=File(d,"lines-"+mode+".json"); if(!file.exists())continue
 val output=JsonArray()
 for(el in JsonParser.parseString(file.readText()).asJsonArray) {
  val r=el.asJsonObject;val name=r["file"].asString;val expected=selected[name]?:continue
  val lines=r["lines"].asJsonArray.map { v->val l=v.asJsonObject; val b=l["box"].asJsonArray;VisibleQuestionReader.Node(l["text"].asString,NormalizedBox(b[0].asFloat,b[1].asFloat,b[2].asFloat,b[3].asFloat)) }
  val layout=VisibleQuestionReader.readOcrLines(lines,1)
  val verified=layout?.let { runCatching { bank.verifiedAnswer(it) }.getOrNull() }?:bank.verifiedOcrPage(lines,1)
  output.add(JsonObject().apply { addProperty("file",name);addProperty("outcome",when{verified==null->"reject";verified.answerIndices.toSet()==expected->"correct";else->"wrong"});addProperty("local",layout?.question);addProperty("groups",layout?.options?.joinToString("|"){it.text}); addProperty("answer",verified?.answerIndices?.joinToString()) })
 };File(d,"result-"+mode+".json").writeText(GsonBuilder().setPrettyPrinting().create().toJson(output));println(mode+" "+output.map{it.asJsonObject["outcome"].asString}.groupingBy{it}.eachCount())
 }
}

