// Candidate only. CLI gate is always closed; no side effects until invoked.
const fs=require('node:fs'),path=require('node:path'),os=require('node:os');
const ENV='fh6-d5ga45c0ddae7008c';
const FORBIDDEN=['NODE_OPTIONS','NODE_DEBUG','DEBUG','NODE_EXTRA_CA_CERTS','NODE_USE_SYSTEM_CA','NODE_USE_ENV_PROXY','NODE_PATH','SSL_CERT_FILE','SSL_CERT_DIR','CURL_CA_BUNDLE','REQUESTS_CA_BUNDLE','USE_INTERNAL_ENDPOINT','HTTP_PROXY','HTTPS_PROXY','ALL_PROXY','http_proxy','https_proxy','all_proxy','NODE_TLS_REJECT_UNAUTHORIZED','TENCENTCLOUD_SECRETID','TENCENTCLOUD_SECRETKEY','TENCENTCLOUD_SESSIONTOKEN','CLOUDBASE_APIKEY'];
function auditEnvironment(env,execArgv){if(!Array.isArray(execArgv)||execArgv.length||FORBIDDEN.some(k=>env[k]))throw Error('unsafe environment');}
function restrictedFetch(fetchImpl){let testId=null;return async (input,options={})=>{
 const u=new URL(typeof input==='string'?input:input.url),m=String(options.method||'GET').toUpperCase();
 if(u.protocol!=='https:'||u.hostname!==`${ENV}.api.tcloudbasegateway.com`||u.port||u.username||u.password||u.hash||u.searchParams.has('access_token'))throw Error('disallowed');
 const auth=u.pathname==='/auth/v1/signin'&&m==='POST'||u.pathname==='/auth/v1/user/me'&&m==='GET';
 const match=/^\/v1\/database\/instances\/\(default\)\/databases\/\(default\)\/collections\/(daily_hundred_payment_v1|daily_hundred_installation_v1)\/documents(?:\/(acl-test-[a-f0-9]{32}))?$/.exec(u.pathname);
 const db=!!match&&((m==='GET'&&!!match[2]&&[...u.searchParams.keys()].length===0)||(m==='PATCH'&&!match[2]&&[...u.searchParams.keys()].length===0));
 if(db&&m==='GET'){if(testId&&match[2]!==testId)throw Error('disallowed');testId=match[2];}
 if(!auth&&!db)throw Error('disallowed');
 if(db&&m==='PATCH'){let b;try{b=JSON.parse(options.body)}catch{throw Error('disallowed')};const id=b?.query?._id;if(typeof id!=='string'||!testId||id!==testId||b?.data?.kind!=='temporary-acl-test'||b?.data?.token!==id.slice(9)||Object.keys(b.query).join(',')!=='_id'||Object.keys(b.data).sort().join(',')!=='kind,token'||b.multi!==false||b.upsert!==true||b.replaceMode!==true)throw Error('disallowed');}
 if(db&&!/^Bearer \S+$/.test(new Headers(options.headers||{}).get('authorization')||''))throw Error('unverified client identity');
 const signal=options.signal?AbortSignal.any([options.signal,AbortSignal.timeout(15000)]):AbortSignal.timeout(15000);
 return fetchImpl(input,{...options,redirect:'error',signal});
}}
function memoryBrowser(fetchImpl){
 global.window=global;global.location={protocol:'https:',hostname:'localhost',origin:'https://localhost',href:'https://localhost/'};global.navigator={userAgent:'payment-acl-verifier'};
 const values=new Map();const storage={getItem:k=>values.get(k)||null,setItem:(k,v)=>values.set(k,String(v)),removeItem:k=>values.delete(k)};
 global.localStorage=storage;global.sessionStorage=storage;global.fetch=restrictedFetch(fetchImpl);
 return ()=>values.clear();
}
function markerAt(marker){return async value=>{const fd=fs.openSync(marker,'wx',0o600);try{fs.writeFileSync(fd,JSON.stringify(value));fs.fsyncSync(fd)}finally{fs.closeSync(fd)}};}
async function prepare(){
 auditEnvironment(process.env,process.execArgv);
 const marker=path.join(__dirname,'temporary-account-attempted.json');if(fs.existsSync(marker))throw Error('already attempted');
 const auth=JSON.parse(fs.readFileSync(path.join(os.homedir(),'.config','.cloudbase','auth.json'),'utf8')),c=auth.credential||{};
 const secretId=c.secretId||c.tmpSecretId,secretKey=c.secretKey||c.tmpSecretKey,token=c.token||c.tmpToken,expiry=c.accessTokenExpired||c.tmpExpired;
 if(typeof secretId!=='string'||!secretId||typeof secretKey!=='string'||!secretKey||typeof token!=='string'||!token||!Number.isFinite(Number(expiry))||Number(expiry)<=Date.now()+120000)throw Error('unavailable');
 const sdkRoot=path.resolve(__dirname,'../payment-database-init/sdk-tcb/node_modules');
 const http=require(path.join(sdkRoot,'tencentcloud-sdk-nodejs-common/tencentcloud/common/http/fetch')),original=http.default;
 http.default=(url,options)=>{if(url!=='https://tcb.tencentcloudapi.com/'||options?.proxy||options?.agent)throw Error('disallowed');return original(url,{...options,redirect:'error'});};
 const Client=require(path.join(sdkRoot,'tencentcloud-sdk-nodejs-tcb')).tcb.v20180608.Client;
 const client=new Client({credential:{secretId,secretKey,token},region:'ap-shanghai',profile:{httpProfile:{endpoint:'tcb.tencentcloudapi.com',reqTimeout:15,protocol:'https://'}}});
 const clear=memoryBrowser(global.fetch.bind(global));
 const sdk=require('./node_modules/@cloudbase/js-sdk/dist/index.cjs.js');
 const app=sdk.init({env:ENV,region:'ap-shanghai',persistence:'none',timeout:15000});
 const {verifyTemporaryUser}=await import('../payment-acl-verification/temporary-user-verifier.mjs');
 const {makeApi}=require('./tcb-adapter.cjs');
 return {api:makeApi(client),browser:{verify:x=>verifyTemporaryUser(app,x)},record:markerAt(marker),clear};
}
module.exports={auditEnvironment,restrictedFetch,memoryBrowser,markerAt,prepare};
