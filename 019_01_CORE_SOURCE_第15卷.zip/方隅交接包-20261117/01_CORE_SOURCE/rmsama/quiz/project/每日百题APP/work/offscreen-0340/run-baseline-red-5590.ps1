$ErrorActionPreference='Stop'
$root='C:/Users/rmsama/Documents/ChatGPT/答题小程序/每日百题APP/work'
$adb=Join-Path $root 'tools/android-sdk/platform-tools/adb.exe'
$serial='emulator-5590'
$artifact='C:/Users/rmsama/DailyHundredNativeBuild/work/daily-hundred-0.3.39-numeric.apk'
$target=Join-Path $root 'visual-selection/target/app/build/outputs/apk/release/app-release.apk'
$harness=Join-Path $root 'visual-selection/harness/app/build/outputs/apk/release/app-release.apk'
$evidence=Join-Path $root 'offscreen-0340/baseline-red-5590'
New-Item -ItemType Directory -Path $evidence -ErrorAction Stop | Out-Null
if((& $adb -P 15039 -s $serial shell getprop ro.kernel.qemu | Out-String).Trim() -ne '1'){throw 'Not emulator'}
foreach($apk in @($artifact,$target,$harness)){ & $adb -P 15039 -s $serial install -r $apk; if($LASTEXITCODE -ne 0){throw "install failed $apk"}}
foreach($app in @('com.jimusoft.dailyhundredapp','com.jimusoft.randomhundred')) { & $adb -P 15039 -s $serial shell pm clear $app }
$installed=(& $adb -P 15039 -s $serial shell pm path com.jimusoft.dailyhundredapp | Out-String).Trim().Substring(8)
& $adb -P 15039 -s $serial shell sha256sum $installed | Out-File (Join-Path $evidence 'installed-sha256.txt')
& $adb -P 15039 -s $serial shell am instrument -w -r -e alternate false -e includeB27 true -e scrollNext true -e count 0 -e seed 20261105 com.jimusoft.dailyhundrede2e/.FloatingStartInstrumentation 2>&1 | Tee-Object -FilePath (Join-Path $evidence 'instrumentation.log')
& $adb -P 15039 -s $serial pull /sdcard/Android/data/com.jimusoft.dailyhundredapp/files/visual-e2e 'V:/work/offscreen-0340/baseline-red-5590'
if($LASTEXITCODE -ne 0){throw 'Evidence pull failed; device data preserved'}
