$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent (Split-Path -Parent $PSScriptRoot)
$jdk = (Get-ChildItem (Join-Path $root 'work/tools/jdk') -Directory | Select-Object -First 1).FullName
$lib = (Get-ChildItem (Join-Path $root 'work/gradle-home/wrapper/dists/gradle-9.3.1-bin') -Directory -Recurse -Filter lib | Select-Object -First 1).FullName
$source = Join-Path $root 'outputs/daily-hundred-app/modules/automation-bridge/android/src/main/java/expo/modules/automationbridge/billing/PaidReservationGuard.kt'
$classes=Join-Path $PSScriptRoot 'reservation-guard-classes';New-Item -ItemType Directory -Force $classes | Out-Null
$java=Join-Path $jdk 'bin/java.exe';$stdlib=Join-Path $lib 'kotlin-stdlib-2.2.21.jar'
& $java '-Dfile.encoding=UTF-8' -cp "$lib/*" org.jetbrains.kotlin.cli.jvm.K2JVMCompiler -no-stdlib -no-reflect -classpath $stdlib -d $classes $source (Join-Path $PSScriptRoot 'PaidReservationGuardTest.kt')
if($LASTEXITCODE -ne 0){throw 'Reservation guard compile failed'}
& $java -cp "$classes;$stdlib" expo.modules.automationbridge.billing.PaidReservationGuardTest
if($LASTEXITCODE -ne 0){throw 'Reservation guard tests failed'}
