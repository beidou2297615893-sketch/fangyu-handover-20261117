'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),crypto=require('node:crypto');
const {Db}=require('../../outputs/managed-import-cloudbase/node_modules/@cloudbase/database/dist/commonjs/index.js');
const {EJSON}=require('../../outputs/managed-import-cloudbase/node_modules/bson');
const urllib=require('urllib').default;
const {createInternalCore,createProductionService}=require('./payment-core');
let active=false;
function fixture(options={}){
  if(active)throw Error('fixture in use');active=true;
  const keys=crypto.generateKeyPairSync('rsa',{modulusLength:2048,privateKeyEncoding:{type:'pkcs8',format:'pem'},publicKeyEncoding:{type:'spki',format:'pem'}});
  const state={docs:new Map(),txs:new Map(),version:0,next:0,conflicts:0,unknown:false,queries:0,query:null,queryByOrder:new Map()};
  const original=Db.reqClass,originalRequest=urllib.request;
  Db.reqClass=class {async send(action,p={}){
    if(action==='database.startTransaction'){const transactionId='x'+(++state.next);state.txs.set(transactionId,{docs:structuredClone(state.docs),version:state.version});return {transactionId};}
    if(action==='database.abortTransaction'){state.txs.delete(p.transactionId);return {};}
    if(action==='database.commitTransaction'){
      const tx=state.txs.get(p.transactionId);
      if(state.conflicts){state.conflicts--;return {code:'DATABASE_TRANSACTION_CONFLICT'};}
      if(tx.version!==state.version)return {code:'DATABASE_TRANSACTION_CONFLICT'};
      state.docs=tx.docs;state.version++;state.txs.delete(p.transactionId);
      if(state.unknown){state.unknown=false;throw Error('lost reply');}return {};
    }
    assert.equal(p.collectionName,'daily_hundred_payment_v1');
    const tx=state.txs.get(p.transactionId),id=JSON.parse(p.query)._id;
    if(action==='database.getDocument')return {data:{list:tx.docs.has(id)?[JSON.stringify({_id:id,...tx.docs.get(id)})]:[]}};
    if(action==='database.modifyDocument'){tx.docs.set(id,EJSON.parse(p.data));return {data:{updated:1,upsert_id:id}};}
    throw Error('unexpected operation');
  }};
  urllib.request=async(url,options)=>{
    state.queries++;const u=new URL(url);
    assert.equal(u.hostname,'openapi.alipay.com');assert.ok(['alipay.trade.query','alipay.trade.fastpay.refund.query'].includes(u.searchParams.get('method')));
    const payload=JSON.parse(options.data.biz_content);assert.ok(payload.out_trade_no);
    return {status:200,headers:{},data:state.queryByOrder.get(payload.out_trade_no)||state.query};
  };
  const highRates={orderOwnerMinute:1000,orderGlobalMinute:10000,queryOwnerMinute:1000,queryGlobalMinute:10000};
  const core=createInternalCore({db:new Db({throwOnCode:true}),appId:'test-app',sellerId:'test-seller',privateKey:keys.privateKey,publicKey:keys.publicKey,notifyUrl:'https://example.invalid/notify',returnUrl:'https://example.invalid/return',rateLimits:highRates,...options});
  function notice(id,overrides={}){
    const f={app_id:'test-app',seller_id:'test-seller',out_trade_no:id,trade_no:'trade-A',total_amount:'1.00',trade_status:'TRADE_SUCCESS',sign_type:'RSA2',...overrides};
    const body=Object.keys(f).filter(k=>k!=='sign_type').sort().map(k=>k+'='+f[k]).join('&');
    f.sign=crypto.sign('RSA-SHA256',Buffer.from(body),keys.privateKey).toString('base64');return new URLSearchParams(f).toString();
  }
  function query(id,overrides={}){
    const body=JSON.stringify({code:'10000',out_trade_no:id,trade_no:'trade-A',total_amount:'1.00',trade_status:'TRADE_SUCCESS',...overrides});
    const sign=crypto.sign('RSA-SHA256',Buffer.from(body),keys.privateKey).toString('base64');state.query='{"alipay_trade_query_response":'+body+',"sign":"'+sign+'"}';state.queryByOrder.set(id,state.query);
  }
  function refundQuery(id,requestId,overrides={}){
    const body=JSON.stringify({code:'10000',out_trade_no:id,out_request_no:requestId,trade_no:'trade-A',refund_amount:'5.90',refund_status:'REFUND_SUCCESS',...overrides});
    const sign=crypto.sign('RSA-SHA256',Buffer.from(body),keys.privateKey).toString('base64');state.query='{"alipay_trade_fastpay_refund_query_response":'+body+',"sign":"'+sign+'"}';state.queryByOrder.set(id,state.query);
  }
  function close(){Db.reqClass=original;urllib.request=originalRequest;active=false;}
  return {core,state,notice,query,refundQuery,close,keys};
}
test('production service cannot be enabled with config',()=>assert.throws(()=>createProductionService({enabled:true})));
test('new orders are limited per owner and globally; signed callback is never throttled',async()=>{
  let now=1800000000000;const f=fixture({clock:()=>now,rateLimits:{orderOwnerMinute:2,orderGlobalMinute:3,queryOwnerMinute:2,queryGlobalMinute:3}});
  try{
    const first=await f.core.createOrder('ownerA','one','once');await f.core.createOrder('ownerA','two','once');
    await assert.rejects(f.core.createOrder('ownerA','three','once'));await f.core.createOrder('ownerB','one','once');
    await assert.rejects(f.core.createOrder('ownerC','one','once'));
    f.query(first.id);assert.equal((await f.core.notify(f.notice(first.id))).status,'paid');
    now+=60000;assert.equal((await f.core.createOrder('ownerA','three','once')).status,'pending');
  }finally{f.close();}
});
test('repeated pending reconciliation bounds provider queries without throttling valid notifications',async()=>{
  const f=fixture({clock:()=>1800000000000,rateLimits:{orderOwnerMinute:10,orderGlobalMinute:100,queryOwnerMinute:2,queryGlobalMinute:3}});
  try{
    const first=await f.core.createOrder('ownerA','reconcile-a','once'),second=await f.core.createOrder('ownerB','reconcile-b','once');
    f.query(first.id,{seller_id:'test-seller',trade_status:'WAIT_BUYER_PAY'});f.query(second.id,{seller_id:'test-seller',trade_status:'WAIT_BUYER_PAY'});
    await f.core.reconcileOrder('ownerA',first.id);await f.core.reconcileOrder('ownerA',first.id);await f.core.reconcileOrder('ownerA',first.id);
    assert.equal(f.state.queries,2);await f.core.reconcileOrder('ownerB',second.id);assert.equal(f.state.queries,3);
    await f.core.reconcileOrder('ownerB',second.id);assert.equal(f.state.queries,3);
    f.query(first.id,{seller_id:'test-seller'});assert.equal((await f.core.notify(f.notice(first.id))).status,'paid');assert.equal(f.state.queries,4);
  }finally{f.close();}
});
test('idempotent retries keep one order and daily quota resets only in the next window',async()=>{
  let now=1800000000000;const f=fixture({clock:()=>now,rateLimits:{orderOwnerMinute:10,orderGlobalMinute:10,orderOwnerDay:2,orderGlobalDay:2}});
  try{
    const a=await f.core.createOrder('ownerA','same','once');await f.core.createOrder('ownerA','other','once');
    now+=60000;await assert.rejects(f.core.createOrder('ownerA','third','once'));
    const b=await f.core.createOrder('ownerA','same','once');assert.equal(a.id,b.id);
    assert.equal([...f.state.docs.values()].filter(x=>x.kind==='order').length,2);
    now=(Math.floor(now/86400000)+1)*86400000;assert.equal((await f.core.createOrder('ownerA','third','once')).status,'pending');
  }finally{f.close();}
});
test('concurrent new orders cannot exceed the shared transaction quota',async()=>{
  const f=fixture({clock:()=>1800000000000,rateLimits:{orderOwnerMinute:20,orderGlobalMinute:3}});
  try{
    const results=await Promise.allSettled(Array.from({length:8},(_,i)=>f.core.createOrder('owner'+i,'one','once')));
    assert.ok(results.filter(x=>x.status==='fulfilled').length<=3);
    assert.ok([...f.state.docs.values()].filter(x=>x.kind==='order').length<=3);
  }finally{f.close();}
});
test('simultaneous retries of the same request preserve one order after new-order quota fills',async()=>{
  const f=fixture({clock:()=>1800000000000,rateLimits:{orderOwnerMinute:1,orderGlobalMinute:1}});
  try{
    const [a,b]=await Promise.all([f.core.createOrder('ownerA','same','once'),f.core.createOrder('ownerA','same','once')]);
    assert.equal(a.id,b.id);assert.equal([...f.state.docs.values()].filter(x=>x.kind==='order').length,1);
  }finally{f.close();}
});
test('actual SDK produces deterministic single order, fixed merchant and owner isolation',async()=>{
  const f=fixture();try{
    const a=await f.core.createOrder('ownerA','request1','once'),b=await f.core.createOrder('ownerA','request1','once');
    assert.equal(a.id,b.id);const url=new URL(a.checkoutUrl);assert.equal(url.hostname,'openapi.alipay.com');assert.equal(url.searchParams.get('method'),'alipay.trade.wap.pay');
    assert.equal(JSON.parse(url.searchParams.get('biz_content')).total_amount,'1.00');
    assert.equal((await f.core.readOrder('ownerA',a.id)).status,'pending');await assert.rejects(f.core.readOrder('ownerB',a.id));
    await assert.rejects(f.core.createOrder('ownerA','request1','month'));
  }finally{f.close();}
});
test('signed callback and actual SDK query bind trade and grant exactly once',async()=>{
  const f=fixture();try{
    const order=await f.core.createOrder('ownerA','request1','once');f.query(order.id);
    assert.equal((await f.core.notify(f.notice(order.id))).status,'paid');
    assert.equal((await f.core.notify(f.notice(order.id))).status,'paid');
    assert.equal((await f.core.readOrder('ownerA',order.id)).status,'paid');
    const docs=[...f.state.docs.values()];assert.equal(docs.filter(x=>x.kind==='trade').length,1);assert.equal(docs.filter(x=>x.kind==='grant').length,1);
  }finally{f.close();}
});
test('forged notification, query mismatch and invalid signature cannot grant',async()=>{
  const f=fixture();try{
    const order=await f.core.createOrder('ownerA','request1','once');f.query(order.id,{trade_no:'other'});
    await assert.rejects(f.core.notify(f.notice(order.id)));
    f.query(order.id);await assert.rejects(f.core.notify(f.notice(order.id,{seller_id:'other'})));
    await assert.rejects(f.core.notify('verified=true'));f.state.query=f.state.query.replace('1.00','9.00');f.state.queryByOrder.set(order.id,f.state.query);await assert.rejects(f.core.notify(f.notice(order.id)));
    assert.equal([...f.state.docs.values()].filter(x=>x.kind==='grant').length,0);
  }finally{f.close();}
});
test('DB conflict retries transaction only; unknown commit is not blindly retried',async()=>{
  const f=fixture();try{
    const order=await f.core.createOrder('ownerA','request1','once');f.query(order.id);f.state.conflicts=2;
    await f.core.notify(f.notice(order.id));assert.equal(f.state.queries,1);
    const second=await f.core.createOrder('ownerA','request2','once');f.query(second.id,{trade_no:'trade-B'});f.state.unknown=true;
    await assert.rejects(f.core.notify(f.notice(second.id,{trade_no:'trade-B'})));
    await f.core.notify(f.notice(second.id,{trade_no:'trade-B'}));
    assert.equal([...f.state.docs.values()].filter(x=>x.kind==='grant').length,2);
  }finally{f.close();}
});
test('a verified trade cannot grant two different orders',async()=>{
  const f=fixture();try{
    const first=await f.core.createOrder('ownerA','request1','once'),second=await f.core.createOrder('ownerB','request2','once');
    f.query(first.id);await f.core.notify(f.notice(first.id));
    f.query(second.id);await assert.rejects(f.core.notify(f.notice(second.id)));
    assert.equal((await f.core.readOrder('ownerB',second.id)).status,'pending');
    assert.equal([...f.state.docs.values()].filter(x=>x.kind==='grant').length,1);
  }finally{f.close();}
});
test('weekly and monthly purchases use fixed prices and create account subscription grants atomically',async()=>{
  const f=fixture();try{
    for(const [plan,price,trade] of [['week','5.90','trade-week'],['month','9.90','trade-month']]){
      const order=await f.core.createOrder('ownerA','request-'+plan,plan);
      assert.equal(order.amountFen,plan==='week'?590:990);
      assert.equal(JSON.parse(new URL(order.checkoutUrl).searchParams.get('biz_content')).total_amount,price);
      f.query(order.id,{total_amount:price,trade_no:trade});
      assert.equal((await f.core.notify(f.notice(order.id,{total_amount:price,trade_no:trade}))).status,'paid');
    }
    const accounts=[...f.state.docs.values()].filter(x=>x.kind==='account');
    assert.equal(accounts.length,1);
    const grants=[...f.state.docs.values()].filter(x=>x.kind==='grant');
    assert.deepEqual(grants.map(x=>x.plan).sort(),['month','week']);
    assert.ok(grants.every(x=>x.state==='paid'&&Number.isSafeInteger(x.grantedAt)));
    assert.ok(accounts[0].memberUntil>=grants[0].grantedAt+37*86400000);
  }finally{f.close();}
});
test('verified adverse close freezes paid grant and a later success cannot reopen it',async()=>{
  const f=fixture();try{
    const order=await f.core.createOrder('ownerA','weekly','week');
    f.query(order.id,{total_amount:'5.90'});await f.core.notify(f.notice(order.id,{total_amount:'5.90'}));
    const queryCount=f.state.queries;
    assert.equal((await f.core.notify(f.notice(order.id,{total_amount:'5.90',trade_status:'TRADE_CLOSED'}))).status,'review');
    assert.equal(f.state.queries,queryCount);
    const account=[...f.state.docs.values()].find(x=>x.kind==='account');assert.equal(account.memberFrozen,true);
    assert.equal(f.state.docs.get('grant-'+order.id).state,'review');
    await assert.rejects(f.core.notify(f.notice(order.id,{total_amount:'5.90'})));
    assert.equal((await f.core.readOrder('ownerA',order.id)).status,'review');
  }finally{f.close();}
});
test('verified pending close is confirmed by provider query, cancels once, and never grants',async()=>{
  const f=fixture();try{
    const order=await f.core.createOrder('ownerA','closed-unpaid','once');
    f.query(order.id,{trade_status:'TRADE_CLOSED'});
    assert.equal((await f.core.notify(f.notice(order.id,{trade_status:'TRADE_CLOSED'}))).status,'cancelled');
    assert.equal((await f.core.notify(f.notice(order.id,{trade_status:'TRADE_CLOSED'}))).status,'cancelled');
    assert.equal((await f.core.reconcileOrder('ownerA',order.id)).status,'cancelled');
    assert.equal((await f.core.entitlements('ownerA')).runCredits,0);
    await assert.rejects(f.core.notify(f.notice(order.id,{trade_status:'TRADE_SUCCESS'})));
    assert.equal([...f.state.docs.values()].filter(x=>x.kind==='grant').length,0);
  }finally{f.close();}
});
test('pending close with mismatched or unverifiable query remains pending',async()=>{
  const f=fixture();try{
    const order=await f.core.createOrder('ownerA','closed-query-fails','once');
    for(const extra of [{trade_status:'TRADE_SUCCESS'},{trade_status:'TRADE_CLOSED',total_amount:'9.00'},{trade_status:'TRADE_CLOSED',trade_no:'other'}]){
      f.query(order.id,extra);await assert.rejects(f.core.notify(f.notice(order.id,{trade_status:'TRADE_CLOSED'})));
      assert.equal((await f.core.readOrder('ownerA',order.id)).status,'pending');
    }
  }finally{f.close();}
});
test('finished trade notification grants once after independently verified finished query',async()=>{
  const f=fixture();try{
    const order=await f.core.createOrder('ownerA','finished-notice','once');f.query(order.id,{trade_status:'TRADE_FINISHED'});
    assert.equal((await f.core.notify(f.notice(order.id,{trade_status:'TRADE_FINISHED'}))).status,'paid');
    assert.equal((await f.core.notify(f.notice(order.id,{trade_status:'TRADE_FINISHED'}))).status,'paid');
    assert.equal((await f.core.entitlements('ownerA')).runCredits,1);
  }finally{f.close();}
});
test('SDK payment grant is consumed through paid-only bound run core',async()=>{
  const f=fixture();try{
    const order=await f.core.createOrder('ownerA','single','once');f.query(order.id);await f.core.notify(f.notice(order.id));
    const binding='a'.repeat(64);
    assert.equal((await f.core.reserveRun('ownerA','paid',binding)).source,'credit');
    await assert.rejects(f.core.confirmRun('ownerA','paid','b'.repeat(64)));
    await f.core.confirmRun('ownerA','paid',binding);
    await assert.rejects(f.core.reserveRun('ownerA','next',binding));
  }finally{f.close();}
});
test('verified adverse close blocks an already reserved member run',async()=>{
  const f=fixture();try{
    const order=await f.core.createOrder('ownerA','week','week');f.query(order.id,{total_amount:'5.90'});await f.core.notify(f.notice(order.id,{total_amount:'5.90'}));
    const binding='a'.repeat(64);assert.equal((await f.core.reserveRun('ownerA','run',binding)).source,'subscription');
    await f.core.notify(f.notice(order.id,{total_amount:'5.90',trade_status:'TRADE_CLOSED'}));
    await assert.rejects(f.core.confirmRun('ownerA','run',binding));
    assert.equal((await f.core.releaseRun('ownerA','run',binding)).status,'released');
  }finally{f.close();}
});
test('verified full refund freezes membership and idempotently records refund evidence',async()=>{
  const f=fixture();try{
    const order=await f.core.createOrder('ownerA','week','week');f.query(order.id,{total_amount:'5.90'});await f.core.notify(f.notice(order.id,{total_amount:'5.90'}));
    const binding='a'.repeat(64);await f.core.reserveRun('ownerA','run',binding);
    f.refundQuery(order.id,'refund-1');
    assert.equal((await f.core.reviewRefund('ownerA',order.id,'refund-1')).status,'refunded');
    assert.equal((await f.core.reviewRefund('ownerA',order.id,'refund-1')).status,'refunded');
    await assert.rejects(f.core.confirmRun('ownerA','run',binding));
    assert.equal((await f.core.releaseRun('ownerA','run',binding)).status,'released');
  }finally{f.close();}
});
test('refund query mismatch freezes but cannot falsely mark refunded',async()=>{
  const f=fixture();try{
    const order=await f.core.createOrder('ownerA','week','week');f.query(order.id,{total_amount:'5.90'});await f.core.notify(f.notice(order.id,{total_amount:'5.90'}));
    f.refundQuery(order.id,'refund-1',{trade_no:'unrelated'});
    await assert.rejects(f.core.reviewRefund('ownerA',order.id,'refund-1'));
    assert.equal((await f.core.readOrder('ownerA',order.id)).status,'review');
    const account=[...f.state.docs.values()].find(x=>x.kind==='account');assert.equal(account.memberFrozen,true);
    assert.equal(f.state.docs.get('grant-'+order.id).state,'review');
  }finally{f.close();}
});
test('partial refunds stay frozen, repeated request does not double count, full sum finalizes',async()=>{
  const f=fixture();try{
    const order=await f.core.createOrder('ownerA','week','week');f.query(order.id,{total_amount:'5.90'});await f.core.notify(f.notice(order.id,{total_amount:'5.90'}));
    f.refundQuery(order.id,'refund-1',{refund_amount:'2.90'});
    assert.equal((await f.core.reviewRefund('ownerA',order.id,'refund-1')).status,'review');
    const queries=f.state.queries;
    assert.equal((await f.core.reviewRefund('ownerA',order.id,'refund-1')).status,'review');assert.equal(f.state.queries,queries);
    f.refundQuery(order.id,'refund-2',{refund_amount:'3.00'});
    assert.equal((await f.core.reviewRefund('ownerA',order.id,'refund-2')).status,'refunded');
    await assert.rejects(f.core.reviewRefund('ownerB',order.id,'refund-2'));
  }finally{f.close();}
});
test('more than 64 purchases remain independently usable and middle-order refund is traced',async()=>{
  const f=fixture();try{
    const orders=[];
    for(let i=0;i<70;i++){
      const order=await f.core.createOrder('ownerA','purchase-'+i,'once');orders.push(order);
      f.query(order.id,{trade_no:'trade-'+i});await f.core.notify(f.notice(order.id,{trade_no:'trade-'+i}));
    }
    f.query(orders[69].id,{trade_no:'trade-69'});await f.core.notify(f.notice(orders[69].id,{trade_no:'trade-69'}));
    assert.equal([...f.state.docs.values()].filter(x=>x.kind==='grant').length,70);
    await f.core.notify(f.notice(orders[35].id,{trade_no:'trade-35',trade_status:'TRADE_CLOSED'}));
    assert.equal(f.state.docs.get('grant-'+orders[35].id).state,'review');
    const binding='a'.repeat(64);
    const parallel=await Promise.allSettled(Array.from({length:8},(_,i)=>f.core.reserveRun('ownerA','parallel-'+i,binding)));
    for(const [i,result] of parallel.entries())if(result.status==='fulfilled')await f.core.confirmRun('ownerA','parallel-'+i,binding);
    let used=parallel.filter(x=>x.status==='fulfilled').length;
    while(used<69){const run='sequential-'+used;assert.equal((await f.core.reserveRun('ownerA',run,binding)).source,'credit');await f.core.confirmRun('ownerA',run,binding);used++;}
    await assert.rejects(f.core.reserveRun('ownerA','out-of-credits',binding));
    assert.equal([...f.state.docs.values()].filter(x=>x.kind==='grant'&&x.used===1).length,69);
  }finally{f.close();}
});
test('more than 64 membership grants stack; refund freezes membership but preserves single credit',async()=>{
  const f=fixture();try{
    const orders=[];
    for(let i=0;i<65;i++){
      const order=await f.core.createOrder('ownerA','week-'+i,'week');orders.push(order);
      f.query(order.id,{trade_no:'week-'+i,total_amount:'5.90'});await f.core.notify(f.notice(order.id,{trade_no:'week-'+i,total_amount:'5.90'}));
    }
    const firstGrant=f.state.docs.get('grant-'+orders[0].id),account=[...f.state.docs.values()].find(x=>x.kind==='account');
    assert.ok(account.memberUntil>=firstGrant.grantedAt+65*7*86400000);
    const single=await f.core.createOrder('ownerA','single-extra','once');f.query(single.id,{trade_no:'single'});await f.core.notify(f.notice(single.id,{trade_no:'single'}));
    await f.core.notify(f.notice(orders[0].id,{trade_no:'week-0',total_amount:'5.90',trade_status:'TRADE_CLOSED'}));
    assert.equal([...f.state.docs.values()].find(x=>x.kind==='account').memberFrozen,true);
    const binding='a'.repeat(64);
    assert.equal((await f.core.reserveRun('ownerA','single',binding)).source,'credit');
  }finally{f.close();}
});
test('concurrent distinct purchases retry safely without losing or duplicating grants',async()=>{
  const f=fixture();try{
    const orders=[];
    for(let i=0;i<8;i++){
      const order=await f.core.createOrder('ownerA','concurrent-'+i,'once');orders.push(order);
      f.query(order.id,{trade_no:'trade-c'+i});
    }
    const results=await Promise.allSettled(orders.map((order,i)=>f.core.notify(f.notice(order.id,{trade_no:'trade-c'+i}))));
    for(let i=0;i<results.length;i++)if(results[i].status==='rejected')await f.core.notify(f.notice(orders[i].id,{trade_no:'trade-c'+i}));
    assert.equal([...f.state.docs.values()].filter(x=>x.kind==='grant').length,8);
    const binding='a'.repeat(64);
    for(let i=0;i<8;i++){assert.equal((await f.core.reserveRun('ownerA','paid-'+i,binding)).source,'credit');await f.core.confirmRun('ownerA','paid-'+i,binding);}
    await assert.rejects(f.core.reserveRun('ownerA','no-credit',binding));
  }finally{f.close();}
});
test('new paid membership starts fresh after freeze without reviving an old run',async()=>{
  const f=fixture();try{
    const old=await f.core.createOrder('ownerA','old-week','week');f.query(old.id,{total_amount:'5.90'});await f.core.notify(f.notice(old.id,{total_amount:'5.90'}));
    const binding='a'.repeat(64);await f.core.reserveRun('ownerA','old-run',binding);
    await f.core.notify(f.notice(old.id,{total_amount:'5.90',trade_status:'TRADE_CLOSED'}));
    const fresh=await f.core.createOrder('ownerA','new-week','week');f.query(fresh.id,{total_amount:'5.90',trade_no:'new-trade'});await f.core.notify(f.notice(fresh.id,{total_amount:'5.90',trade_no:'new-trade'}));
    await assert.rejects(f.core.confirmRun('ownerA','old-run',binding));
    assert.equal((await f.core.reserveRun('ownerA','new-run',binding)).source,'subscription');
    const a=[...f.state.docs.values()].find(x=>x.kind==='account');const grant=f.state.docs.get('grant-'+fresh.id);
    assert.equal(a.memberFrozen,false);assert.equal(a.memberNeedsReview,true);assert.equal(a.memberUntil,grant.grantedAt+7*86400000);
  }finally{f.close();}
});
test('signed close with wrong trade cannot freeze a paid order',async()=>{
  const f=fixture();try{
    const order=await f.core.createOrder('ownerA','week','week');f.query(order.id,{total_amount:'5.90'});await f.core.notify(f.notice(order.id,{total_amount:'5.90'}));
    await assert.rejects(f.core.notify(f.notice(order.id,{total_amount:'5.90',trade_status:'TRADE_CLOSED',trade_no:'unrelated'})));
    assert.equal((await f.core.readOrder('ownerA',order.id)).status,'paid');
    assert.equal(f.state.docs.get('grant-'+order.id).state,'paid');
  }finally{f.close();}
});
test('same refund request number on different orders is isolated',async()=>{
  const f=fixture();try{
    for(const [n,trade] of [['a','trade-A'],['b','trade-B']]){
      const order=await f.core.createOrder('ownerA','order-'+n,'week');f.query(order.id,{total_amount:'5.90',trade_no:trade});await f.core.notify(f.notice(order.id,{total_amount:'5.90',trade_no:trade}));
      f.refundQuery(order.id,'same-refund',{trade_no:trade});
      assert.equal((await f.core.reviewRefund('ownerA',order.id,'same-refund')).status,'refunded');
      assert.equal((await f.core.reviewRefund('ownerA',order.id,'same-refund')).status,'refunded');
    }
    assert.equal([...f.state.docs.values()].filter(x=>x.kind==='refund'&&x.status==='confirmed').length,2);
  }finally{f.close();}
});
test('entitlements reflect valid credits through reservation, use and frozen review',async()=>{
  const f=fixture();try{
    const order=await f.core.createOrder('ownerA','single','once');f.query(order.id);await f.core.notify(f.notice(order.id));
    assert.equal((await f.core.entitlements('ownerA')).runCredits,1);
    const bind='a'.repeat(64);await f.core.reserveRun('ownerA','run',bind);
    assert.equal((await f.core.entitlements('ownerA')).runCredits,1);
    await f.core.notify(f.notice(order.id,{trade_status:'TRADE_CLOSED'}));
    const frozen=await f.core.entitlements('ownerA');assert.equal(frozen.runCredits,0);assert.equal(frozen.requiresReview,true);
    await f.core.releaseRun('ownerA','run',bind);assert.equal((await f.core.entitlements('ownerA')).runCredits,0);
    assert.equal((await f.core.entitlements('ownerB')).runCredits,0);
  }finally{f.close();}
});
test('reconcile without a valid notification or verified query never grants',async()=>{
  const f=fixture();try{
    const order=await f.core.createOrder('ownerA','pending','once');f.query(order.id);
    // A success-shaped query with an altered signed body is not payment evidence.
    f.state.query=f.state.query.replace('1.00','9.00');f.state.queryByOrder.set(order.id,f.state.query);
    const value=await f.core.reconcileOrder('ownerA',order.id);assert.equal(value.status,'pending');
    assert.equal((await f.core.entitlements('ownerA')).runCredits,0);
    await assert.rejects(f.core.reconcileOrder('ownerB',order.id));
    f.state.query=null;f.state.queryByOrder.delete(order.id);
    assert.equal((await f.core.reconcileOrder('ownerA',order.id)).status,'pending');
  }finally{f.close();}
});
test('a missed notice is recovered only by a verified provider query bound to owner, merchant, amount and successful trade',async()=>{
  const f=fixture();try{
    const order=await f.core.createOrder('ownerA','missing-notice','once');
    f.query(order.id,{seller_id:'test-seller'});
    await assert.rejects(f.core.reconcileOrder('ownerB',order.id));
    const result=await f.core.reconcileOrder('ownerA',order.id);
    assert.equal(result.status,'paid');
    assert.equal((await f.core.entitlements('ownerA')).runCredits,1);
    assert.equal((await f.core.reconcileOrder('ownerA',order.id)).status,'paid');
    assert.equal([...f.state.docs.values()].filter(x=>x.kind==='grant').length,1);
  }finally{f.close();}
});
test('missed-notice query rejects explicitly mismatched seller, amount, status, trade and forged signature',async()=>{
  const f=fixture();try{
    const order=await f.core.createOrder('ownerA','missing-notice-rejections','once');
    for(const input of [{seller_id:'wrong'},{seller_id:'test-seller',total_amount:'2.00'},{seller_id:'test-seller',trade_status:'WAIT_BUYER_PAY'},{seller_id:'test-seller',trade_no:''},{seller_id:'test-seller',out_trade_no:'wrong-order'}]){
      f.query(order.id,input);assert.equal((await f.core.reconcileOrder('ownerA',order.id)).status,'pending');
    }
    f.query(order.id,{seller_id:'test-seller'});const forged=f.state.query.replace('1.00','2.00');f.state.queryByOrder.set(order.id,forged);
    assert.equal((await f.core.reconcileOrder('ownerA',order.id)).status,'pending');
    assert.equal((await f.core.entitlements('ownerA')).runCredits,0);
  }finally{f.close();}
});
test('concurrent verified queries without a notice grant exactly once',async()=>{
  const f=fixture();try{
    const order=await f.core.createOrder('ownerA','missing-notice-concurrent','once');f.query(order.id,{seller_id:'test-seller'});
    const results=await Promise.allSettled([f.core.reconcileOrder('ownerA',order.id),f.core.reconcileOrder('ownerA',order.id)]);
    assert.ok(results.some(r=>r.status==='fulfilled'&&r.value.status==='paid'));
    assert.equal((await f.core.reconcileOrder('ownerA',order.id)).status,'paid');
    assert.equal((await f.core.entitlements('ownerA')).runCredits,1);
    assert.equal([...f.state.docs.values()].filter(x=>x.kind==='grant').length,1);
  }finally{f.close();}
});
test('a lost close notice is recovered through a verified same-seller query and never grants',async()=>{
  const f=fixture();try{
    const order=await f.core.createOrder('ownerA','missing-close','once');f.query(order.id,{seller_id:'test-seller',trade_status:'TRADE_CLOSED'});
    await assert.rejects(f.core.reconcileOrder('ownerB',order.id));
    assert.equal((await f.core.reconcileOrder('ownerA',order.id)).status,'cancelled');
    assert.equal((await f.core.reconcileOrder('ownerA',order.id)).status,'cancelled');
    assert.equal((await f.core.entitlements('ownerA')).runCredits,0);
  }finally{f.close();}
});
test('a lost close notice with wrong seller or invalid signature cannot cancel an order',async()=>{
  const f=fixture();try{
    const order=await f.core.createOrder('ownerA','bad-missing-close','once');
    f.query(order.id,{seller_id:'wrong',trade_status:'TRADE_CLOSED'});
    assert.equal((await f.core.reconcileOrder('ownerA',order.id)).status,'pending');
    f.query(order.id,{seller_id:'test-seller',trade_status:'TRADE_CLOSED'});
    f.state.queryByOrder.set(order.id,f.state.query.replace('1.00','2.00'));
    assert.equal((await f.core.reconcileOrder('ownerA',order.id)).status,'pending');
  }finally{f.close();}
});
test('authenticated notice survives temporary query failure and reconciles exactly once',async()=>{
  const f=fixture();try{
    const order=await f.core.createOrder('ownerA','late-query','once');
    // Signed notice is valid, but the provider query is temporarily unavailable.
    await assert.rejects(f.core.notify(f.notice(order.id)));
    assert.equal((await f.core.readOrder('ownerA',order.id)).status,'pending');
    assert.equal((await f.core.entitlements('ownerA')).runCredits,0);
    f.query(order.id);
    await assert.rejects(f.core.reconcileOrder('ownerB',order.id));
    assert.equal((await f.core.reconcileOrder('ownerA',order.id)).status,'paid');
    assert.equal((await f.core.reconcileOrder('ownerA',order.id)).status,'paid');
    assert.equal((await f.core.entitlements('ownerA')).runCredits,1);
    assert.equal([...f.state.docs.values()].filter(x=>x.kind==='grant').length,1);
  }finally{f.close();}
});
test('conflicting notices and mismatched signed query never create a grant',async()=>{
  const f=fixture();try{
    const order=await f.core.createOrder('ownerA','conflicting-notice','once');
    await assert.rejects(f.core.notify(f.notice(order.id)));
    await assert.rejects(f.core.notify(f.notice(order.id,{trade_no:'other-trade'})));
    f.query(order.id,{trade_no:'other-trade'});
    assert.equal((await f.core.reconcileOrder('ownerA',order.id)).status,'pending');
    assert.equal((await f.core.entitlements('ownerA')).runCredits,0);
    f.query(order.id);
    assert.equal((await f.core.reconcileOrder('ownerA',order.id)).status,'paid');
  }finally{f.close();}
});
test('notice commit response loss can recover safely; invalid notice leaves no evidence',async()=>{
  const f=fixture();try{
    const order=await f.core.createOrder('ownerA','lost-notice-response','once');f.query(order.id);
    await assert.rejects(f.core.notify(f.notice(order.id,{seller_id:'wrong'})));
    assert.equal(f.state.docs.has('notice-'+order.id),false);
    // No valid query is available yet; the rejected callback cannot grant.
    f.state.query=null;f.state.queryByOrder.delete(order.id);
    assert.equal((await f.core.reconcileOrder('ownerA',order.id)).status,'pending');
    assert.equal((await f.core.entitlements('ownerA')).runCredits,0);
    f.query(order.id);f.state.unknown=true;await assert.rejects(f.core.notify(f.notice(order.id)));
    assert.equal((await f.core.reconcileOrder('ownerA',order.id)).status,'paid');
    assert.equal((await f.core.entitlements('ownerA')).runCredits,1);
  }finally{f.close();}
});
test('simultaneous same-notice reconciliation creates a single grant',async()=>{
  const f=fixture();try{
    const order=await f.core.createOrder('ownerA','parallel-reconcile','once');
    await assert.rejects(f.core.notify(f.notice(order.id)));f.query(order.id);
    const results=await Promise.allSettled([f.core.reconcileOrder('ownerA',order.id),f.core.reconcileOrder('ownerA',order.id)]);
    assert.ok(results.some(r=>r.status==='fulfilled'&&r.value.status==='paid'));
    assert.equal((await f.core.reconcileOrder('ownerA',order.id)).status,'paid');
    assert.equal((await f.core.entitlements('ownerA')).runCredits,1);
    assert.equal([...f.state.docs.values()].filter(x=>x.kind==='grant').length,1);
  }finally{f.close();}
});
test('verified paid-trade close is discovered by server query and freezes once',async()=>{
  const f=fixture();try{
    const order=await f.core.createOrder('ownerA','audit-week','week');f.query(order.id,{total_amount:'5.90'});await f.core.notify(f.notice(order.id,{total_amount:'5.90'}));
    const binding='a'.repeat(64);await f.core.reserveRun('ownerA','run',binding);
    f.query(order.id,{total_amount:'5.90',trade_status:'TRADE_CLOSED'});
    assert.deepEqual(await f.core.auditPaidTrade('ownerA',order.id),{status:'review',partialRefundVisibility:'unknown'});
    assert.deepEqual(await f.core.auditPaidTrade('ownerA',order.id),{status:'review',partialRefundVisibility:'unknown'});
    assert.equal(f.state.docs.get('grant-'+order.id).state,'review');
    await assert.rejects(f.core.confirmRun('ownerA','run',binding));
    await assert.rejects(f.core.auditPaidTrade('ownerB',order.id));
  }finally{f.close();}
});
test('query success never claims to exclude partial refunds; bad query cannot freeze',async()=>{
  const f=fixture();try{
    const order=await f.core.createOrder('ownerA','audit-single','once');f.query(order.id);await f.core.notify(f.notice(order.id));
    assert.deepEqual(await f.core.auditPaidTrade('ownerA',order.id),{status:'paid',partialRefundVisibility:'unknown'});
    f.query(order.id,{trade_status:'TRADE_CLOSED',trade_no:'wrong'});
    await assert.rejects(f.core.auditPaidTrade('ownerA',order.id));
    assert.equal((await f.core.readOrder('ownerA',order.id)).status,'paid');
    assert.equal((await f.core.entitlements('ownerA')).runCredits,1);
    f.query(order.id,{trade_status:'TRADE_CLOSED',total_amount:'0.01'});
    await assert.rejects(f.core.auditPaidTrade('ownerA',order.id));
    assert.equal((await f.core.readOrder('ownerA',order.id)).status,'paid');
    f.query(order.id);f.state.query=f.state.query.replace('TRADE_SUCCESS','TRADE_CLOSED');f.state.queryByOrder.set(order.id,f.state.query);
    await assert.rejects(f.core.auditPaidTrade('ownerA',order.id));
    assert.equal((await f.core.readOrder('ownerA',order.id)).status,'paid');
  }finally{f.close();}
});
