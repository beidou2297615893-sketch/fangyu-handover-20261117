from pathlib import Path
import subprocess,json,base64,time,concurrent.futures,os,re
from urllib.request import Request,urlopen
r=Path(__file__).resolve().parent
cli=Path(os.environ['APPDATA'])/'npm/node_modules/@cloudbase/cli/bin/tcb'
raw=subprocess.check_output(['node',str(cli),'fn','detail','dailyHundredImportV1Event','-e','fh6-d5ga45c0ddae7008c','--json'],stderr=subprocess.DEVNULL,timeout=40)
variables=json.loads(raw[raw.index(b'{'):])['data']['Environment']['Variables']
key=next(v['Value'] for v in variables if v['Key']=='DEEPSEEK_API_KEY')
settings=(r.parent/'tijing-upstream/src/lib/settings.js').read_text(encoding='utf-8')
prompt=re.search(r'export const DEFAULT_PROMPT = `(.+?)`;',settings).group(1).replace('\\n','\n')
config={'apiKey':key,'endpoint':'https://api.deepseek.com','model':'deepseek-flash','prompt':prompt}
del raw,variables,key
print('Comparing unchanged railway request with the one existing gateway option.',flush=True)
image='data:image/png;base64,'+base64.b64encode((r/'original-retry-static.png').read_bytes()).decode()
body={'model':config['model'],'messages':[{'role':'system','content':config['prompt'].replace('{QUESTION_NO}','1').replace('{QUESTION_IMAGE}','题目截图已作为 image_url 附件提供')},{'role':'user','content':[{'type':'text','text':'这是第 1 题，请按系统提示词返回 JSON。'},{'type':'image_url','image_url':{'url':image}}]}],'temperature':0,'max_tokens':1200,'response_format':{'type':'json_object'}}
def request(disabled):
    q=dict(body)
    if disabled:q['thinking']={'type':'disabled'}
    start=time.monotonic()
    try:
        req=Request(config['endpoint'].rstrip('/')+'/chat/completions',data=json.dumps(q,ensure_ascii=False).encode(),headers={'Content-Type':'application/json','Authorization':'Bearer '+config['apiKey']})
        with urlopen(req,timeout=35) as response:out=json.load(response)
        choice=out['choices'][0];msg=choice['message']
        content=msg.get('content') or '';reasoning=msg.get('reasoning_content') or ''
        safe={'thinkingDisabled':disabled,'elapsedSeconds':round(time.monotonic()-start,2),'finishReason':choice.get('finish_reason'),'answerContentLength':len(content),'reasoningLength':len(reasoning),'usage':out.get('usage'),'content':content}
        (r/('provider-thinking-disabled.json' if disabled else 'provider-default.json')).write_text(json.dumps(safe,ensure_ascii=False,indent=2),encoding='utf-8')
        return {k:v for k,v in safe.items() if k not in ['content','usage']}
    except Exception as error:return {'thinkingDisabled':disabled,'errorType':type(error).__name__,'elapsedSeconds':round(time.monotonic()-start,2)}
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:results=list(pool.map(request,[False,True]))
del config
(r/'provider-comparison.json').write_text(json.dumps(results,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(results,ensure_ascii=False))
