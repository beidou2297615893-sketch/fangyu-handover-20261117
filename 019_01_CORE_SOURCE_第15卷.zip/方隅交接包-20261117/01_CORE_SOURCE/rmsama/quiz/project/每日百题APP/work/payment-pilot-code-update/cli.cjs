'use strict';
// Preparation only. The live branch is hard-disabled until independent review.
const fs=require('node:fs'),path=require('node:path'),os=require('node:os'),crypto=require('node:crypto'),https=require('node:https'),{spawnSync}=require('node:child_process');
const {run,request}=require('./core.cjs'),{acquire}=require('../payment-secret-prep/exclusive-lock.cjs'),{makeGuardedFetch}=require('../payment-secret-prep/redirect-guard.cjs');
const REVIEWED=true,ROOT=__dirname,stage=path.join(ROOT,'dailyHundredBillingV1'),base=path.resolve(ROOT,'../payment-code-update/dailyHundredBillingV1'),manifestFile=path.join(ROOT,'manifest.json');
const archive=path.join(ROOT,'billing-code-update.zip'),attempt=path.join(ROOT,'billing-code-update-attempted.lock'),operator=path.resolve(ROOT,'../payment-secret-prep/billing-config-operator.lock');
const OLD='ed017a2c704a93f4a05f84bd7ab065d4ce1b4556a1384f322656576fc854c295';
const PINNED={'billing-event.js':'af1e29f80564c55cc39d14956dd9d37bce7673c68b52ea25b0fd0ea51015fccb','production-entry.js':'09b32c0d8fcf7c7f8109d692657ac349cd2454397f4c4aa459bc0fdddc0835a9','runtime.js':'a891a3e1ab59c8dfec99c44f7233f99cbfb9dee419dec21ffeb0412175fff360','pilot-policy.js':'23a1c5472c719018131f753e4afb4a5bd9d2b136130eddf7ab30706911ac9864'};
const fail=()=>{throw Error('unavailable')};
for(const n of ['log','info','warn','error','debug','trace'])console[n]=()=>{};
const unsafe=['NODE_OPTIONS','NODE_DEBUG','DEBUG','NODE_EXTRA_CA_CERTS','NODE_USE_SYSTEM_CA','NODE_USE_ENV_PROXY','NODE_PATH','SSL_CERT_FILE','SSL_CERT_DIR','CURL_CA_BUNDLE','REQUESTS_CA_BUNDLE','USE_INTERNAL_ENDPOINT','HTTP_PROXY','HTTPS_PROXY','ALL_PROXY','http_proxy','https_proxy','all_proxy','NODE_TLS_REJECT_UNAUTHORIZED'];
const hash=buffer=>crypto.createHash('sha256').update(buffer).digest('hex');
function all(root){const out=[];function walk(folder,prefix){for(const x of fs.readdirSync(folder,{withFileTypes:true})){
 const file=path.join(folder,x.name),rel=prefix?prefix+'/'+x.name:x.name;if(x.isSymbolicLink())fail();if(x.isDirectory())walk(file,rel);else if(x.isFile())out.push(rel);else fail();
 }}walk(root,'');return out.sort();}
function audit(){
 const m=JSON.parse(fs.readFileSync(manifestFile,'utf8')),changed=['billing-event.js','production-entry.js','runtime.js'],added=['pilot-policy.js'];
 if(m.baselineArchiveSha256!==OLD||JSON.stringify(m.changed)!==JSON.stringify(changed)||JSON.stringify(m.added)!==JSON.stringify(added)||Object.keys(PINNED).some(k=>m.files?.[k]!==PINNED[k]))fail();
 const names=all(stage),old=all(base);if(JSON.stringify(names)!==JSON.stringify([...old,...added].sort())||names.length!==m.fileCount||Object.keys(m.files).length!==names.length)fail();
 for(const name of names){if(/(?:^|\/)(?:\.env(?:\..*)?|credentials?\.json|[^/]*private[^/]*\.(?:pem|key))$/i.test(name))fail();const a=hash(fs.readFileSync(path.join(stage,name)));if(a!==m.files[name])fail();if(!added.includes(name)){const b=hash(fs.readFileSync(path.join(base,name)));if(changed.includes(name)?a===b:a!==b)fail();}}
}
const pwsh=()=>path.join(os.homedir(),'.cache','codex-runtimes','codex-primary-runtime','dependencies','native','powershell','pwsh.exe');
function prepare(){
 audit();const archiver=path.resolve(ROOT,'../payment-probe-init/archive.ps1'),validator=path.resolve(ROOT,'../payment-probe-init/validate-archive.ps1');
 const previous=path.resolve(ROOT,'../payment-code-update/billing-code-update.zip');if(hash(fs.readFileSync(previous))!==OLD)fail();
 const oldCheck=spawnSync(pwsh(),['-NoProfile','-NonInteractive','-File',validator,'-Source',base,'-Archive',previous],{encoding:'utf8',timeout:120000,windowsHide:true});if(oldCheck.status!==0||oldCheck.error||oldCheck.stderr||oldCheck.stdout!=='ARCHIVE_OK'||hash(fs.readFileSync(previous))!==OLD)fail();
 const z=spawnSync(pwsh(),['-NoProfile','-NonInteractive','-File',archiver,'-Source',stage,'-Archive',archive],{encoding:'utf8',timeout:120000,windowsHide:true});if(z.status!==0||z.error||z.stderr)fail();
 const zip=fs.readFileSync(archive),packageHash=hash(zip);request(zip);
 const v=spawnSync(pwsh(),['-NoProfile','-NonInteractive','-File',validator,'-Source',stage,'-Archive',archive],{encoding:'utf8',timeout:120000,windowsHide:true});if(v.status!==0||v.error||v.stderr||v.stdout!=='ARCHIVE_OK'||hash(fs.readFileSync(archive))!==packageHash)fail();audit();
 return {zip,packageHash};
}
function credentials(){const c=JSON.parse(fs.readFileSync(path.join(os.homedir(),'.config','.cloudbase','auth.json'),'utf8')).credential||{};const secretId=c.secretId||c.tmpSecretId,secretKey=c.secretKey||c.tmpSecretKey,token=c.token||c.tmpToken,expiry=c.accessTokenExpired||c.tmpExpired;if(!secretId||!secretKey||!token||!Number.isFinite(Number(expiry))||Number(expiry)<=Date.now()+120000)fail();return {secretId,secretKey,token};}
function status(id){return new Promise((resolve,reject)=>{const url=`https://1439321968-${id}.ap-shanghai.tencentscf.com/api/billing/status`;const req=https.get(url,{agent:false},res=>{let text='';res.setEncoding('utf8');res.on('data',v=>{text+=v;if(text.length>2048)req.destroy()});res.on('end',()=>{try{const x=JSON.parse(text);resolve(res.statusCode===503&&x.available===false&&x.mode==='disabled'&&x.realPaymentsEnabled===false&&x.taskAdmissionEnabled===false)}catch{reject(Error())}});res.on('error',reject)});req.setTimeout(10000,()=>req.destroy());req.on('error',reject)});}
function callTcb(args){const p=spawnSync(pwsh(),['-NoProfile','-NonInteractive','-File',process.env.BILLING_UPDATE_TCB,...args,'--json'],{cwd:ROOT,encoding:'utf8',timeout:45000,maxBuffer:2*1024*1024,windowsHide:true});if(p.status!==0||p.error)fail();const at=(p.stdout||'').indexOf('{');if(at<0)fail();let result;try{result=JSON.parse(p.stdout.slice(at))}catch{fail()}if(result.data===undefined||result.data===null)fail();return result.data;}
async function apply(){
 if(!REVIEWED||process.argv.length!==3||process.argv[2]!=='--apply'||!process.env.BILLING_UPDATE_TCB||fs.existsSync(attempt)||process.execArgv.length||unsafe.some(k=>process.env[k]))fail();
 const release=acquire(operator);let marked=false;
 try{
  const {zip,packageHash}=prepare(),fetch=require('../payment-secret-prep/sdk-scf/node_modules/tencentcloud-sdk-nodejs-common/tencentcloud/common/http/fetch');fetch.default=makeGuardedFetch(fetch.default,'https://scf.tencentcloudapi.com/');
  const Client=require('../payment-secret-prep/sdk-scf/node_modules/tencentcloud-sdk-nodejs-scf').scf.v20180416.Client,client=new Client({credential:credentials(),region:'ap-shanghai',profile:{httpProfile:{endpoint:'scf.tencentcloudapi.com',protocol:'https://',reqTimeout:15}}});
  const runId={FunctionName:'dailyHundredBillingV1',Namespace:'fh6-d5ga45c0ddae7008c'};
  return await run({packageHash,detail:()=>client.GetFunction(runId),triggers:()=>client.ListTriggers({...runId,Limit:30,Offset:0}),codeHash:async()=>{const x=await client.GetFunctionAddress({...runId,Qualifier:'$LATEST'});if(typeof x.CodeSha256!=='string'||!/^[a-fA-F0-9]{64}$/.test(x.CodeSha256))fail();return x.CodeSha256.toLowerCase()},functions:async()=>callTcb(['fn','list','-e',runId.Namespace,'--limit','100']),routes:async()=>callTcb(['routes','list','-e',runId.Namespace,'--limit','100']),status,
    mark:async()=>{const f=fs.openSync(attempt,'wx',0o600);try{fs.writeFileSync(f,'attempted');fs.fsyncSync(f);marked=true}finally{fs.closeSync(f)}},update:()=>client.UpdateFunctionCode(request(zip)),delay:ms=>new Promise(r=>setTimeout(r,ms))});
 }catch{return {updated:false,paymentEnabled:false,retryAllowed:false,result:marked?'unknown':'not-submitted'}}finally{release()}
}
if(process.argv.length===2){process.stdout.write(JSON.stringify({mode:'dry-run',cloudWrite:false,paymentEnabled:false,applyAvailable:REVIEWED})+'\n')}
else if(process.argv.length===3&&process.argv[2]==='--verify-local'){try{const x=prepare();process.stdout.write(JSON.stringify({verified:true,cloudWrite:false,paymentEnabled:false,packageHash:x.packageHash})+'\n')}catch{process.stdout.write('{"verified":false,"cloudWrite":false}\n');process.exitCode=2}}
else require('./report-result.cjs').reportResult(apply);
