import expo.modules.automationbridge.billing.FreeDeviceDigest;

public final class DeviceDigestTest {
  private static void check(boolean ok) { if (!ok) throw new AssertionError(); }
  private static void rejects(String raw) { try { FreeDeviceDigest.derive(raw); throw new AssertionError("accepted invalid input"); } catch (IllegalArgumentException expected) {} }
  public static void main(String[] args) {
    check(FreeDeviceDigest.derive("0123456789abcdef").equals("17cedf1dfc6ae35b35bc6d69b41ee7a058039fe48474fad5e1f9c2d3a52dbcd7"));
    check(FreeDeviceDigest.derive("0123456789ABCDEF").equals(FreeDeviceDigest.derive("123456789abcdef")));
    check(!FreeDeviceDigest.derive("123456789abcdef").equals(FreeDeviceDigest.derive("223456789abcdef")));
    rejects(null); rejects(""); rejects("0000000000000000"); rejects("not-a-device-id"); rejects("001122334455667788");
    System.out.println("device digest policy: 8 checks passed");
  }
}
