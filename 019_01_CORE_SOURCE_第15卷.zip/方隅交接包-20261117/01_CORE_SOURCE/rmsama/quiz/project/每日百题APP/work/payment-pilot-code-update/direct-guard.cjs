'use strict';
const ENV='fh6-d5ga45c0ddae7008c',HOST=ENV+'.ap-shanghai.tcb-api.tencentcloudapi.com';
function allowed(opts,write=false){
 try{const u=new URL(opts.url),p=opts.body;if(u.protocol!=='https:'||u.hostname!==HOST||u.port||u.username||u.password||u.pathname!=='/admin'||u.hash||u.searchParams.getAll('env').length!==1||u.searchParams.get('env')!==ENV||u.searchParams.getAll('seqId').length>1||[...u.searchParams.keys()].some(x=>!['env','seqId'].includes(x))||opts.method!=='post'||opts.proxy||opts.keepalive||opts.formData!==undefined||opts.qs!==undefined||opts.agent!==undefined||!p||p.envName!==ENV)return false;
 const action=p.action;if(['database.startTransaction','database.commitTransaction','database.abortTransaction'].includes(action))return write===true;
 if(!['database.getDocument','database.modifyDocument'].includes(action)||!['daily_hundred_installation_v1','daily_hundred_payment_v1'].includes(p.collectionName)||p.multi!==false)return false;
 if(p.query!==JSON.stringify({_id:'policy'}))return false;
 if(action==='database.getDocument')return true;
 if(!write||p.merge!==true||p.upsert!==false)return false;return p.data==='{"$set":{"enabled":true}}';
 }catch{return false;}
}
module.exports={allowed};
