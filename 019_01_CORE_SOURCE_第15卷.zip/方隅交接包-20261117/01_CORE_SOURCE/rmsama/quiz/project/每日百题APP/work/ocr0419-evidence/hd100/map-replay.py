from pathlib import Path
import json,hashlib,shutil
from PIL import Image
out=Path(__file__).parent;base=Path('V:/work/verify-0419-device/secondary');src=base/'hd-replay-original-20'
ids=json.loads((base/'assisted-high/events.json').read_text(encoding='utf8'))[0]['data']['ids']
hostPath=base.parent/'host/app/src/main/assets/web/questions.js'
raw=hostPath.read_text(encoding='utf-8-sig');host={x['id']:x for x in json.loads(raw[raw.index('{'):].strip().rstrip(';'))['questions']}
rows=[];assets=out.parent/'app/src/main/assets'
for r in json.loads((src/'manifest.json').read_text(encoding='utf8')):
 n=r['question'];file=src/r['path'];sha=hashlib.sha256(file.read_bytes()).hexdigest();q=host[ids[n-1]]
 assert r['index']==n-1 and r['id']==q['id'] and sha==r['sha256'] and Image.open(file).size==(1080,1920)
 name='replay-'+r['path']
 shutil.copyfile(file,assets/('page-'+name))
 rows.append(dict(file=name,sourcePath=str(file),sha256=sha,id=q['id'],questionNo=n,stem=q['stem'],type=q['type'],options=q['options'],expected=q['correctOptionIds'],positions=None,capture='same host same draw; product stopped for capture'))
assert [r['questionNo'] for r in rows]==list(range(1,21))
(out/'replay-manifest.json').write_text(json.dumps(dict(run=1794577232150,rows=rows),ensure_ascii=False,indent=2),encoding='utf8')
print(len(rows))
