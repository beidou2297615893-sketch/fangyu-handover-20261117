package com.futureyyy.tijing

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Base64
import java.nio.FloatBuffer

/** A line recognizer: no network, no answer generation. Source rectangles all belong to one frame. */
internal class IndependentLineReader(context:Context) : AutoCloseable {
    private val app=context.applicationContext
    private val env by lazy { OrtEnvironment.getEnvironment() }
    private val sessionDelegate=lazy {
        OrtSession.SessionOptions().use { o ->
            o.setIntraOpNumThreads(2)
            o.setInterOpNumThreads(1)
            app.assets.open("local-reader/rail-text.onnx").use { env.createSession(it.readBytes(),o) }
        }
    }
    private val session:OrtSession get() = sessionDelegate.value
    private val alphabet by lazy {
        listOf("") + requireNotNull(session.metadata.customMetadata["character"]).trimEnd('\n','\r').lines() + listOf(" ")
    }
    fun read(frame:CaptureFrame, lines:List<VisibleQuestionReader.Node>):List<VisibleQuestionReader.Node> {
        if(lines.isEmpty() || lines.size>90) return emptyList()
        val data=frame.localPng ?: Base64.decode(frame.dataUrl.substringAfter(','),Base64.DEFAULT)
        val image=BitmapFactory.decodeByteArray(data,0,data.size) ?: return emptyList()
        try {
            fun reRead(box:NormalizedBox): VisibleQuestionReader.Node? {
            val w=image.width;val h=image.height
            val x=(box.x*w/100f).toInt().minus(3).coerceIn(0,w-1)
            val y=(box.y*h/100f).toInt().minus(2).coerceIn(0,h-1)
            val r=((box.x+box.width)*w/100f).toInt().plus(4).coerceIn(x+1,w)
            val b=((box.y+box.height)*h/100f).toInt().plus(3).coerceIn(y+1,h)
            val roi=Bitmap.createBitmap(image,x,y,r-x,b-y)
            val scaledW=(48.0*(r-x)/(b-y)+0.5).toInt().coerceIn(1,1280)
            val small=Bitmap.createScaledBitmap(roi,scaledW,48,true)
            return try {
                val text=recognize(small)
                if(text.isBlank()) null else VisibleQuestionReader.Node(text,box)
            } finally {if (small!==roi && small!==image) small.recycle();if(roi!==image) roi.recycle()}
            }
            val regular=lines.mapNotNull { it.box?.let(::reRead) }
            val w=image.width;val h=image.height
            if (w.toLong()*h>5_000_000) return regular
            val pixels=IntArray(w*h)
            image.getPixels(pixels,0,w,0,0,w,h)
            val choices=ShortChoiceCards.locate(w,h,pixels)
            if(choices.isEmpty()) {
                // Full-frame OCR can already locate labelled rows even when a card outline
                // is too faint to isolate. Keep those proven rectangles for the stroke check.
                val labelled = regular.filter { it.text.trim().matches(Regex("^[A-D][.、:].*")) }.sortedBy { it.box!!.centerY }
                val recovered = RomanChoiceEvidence.read(w,h,pixels,labelled) ?: return regular
                return regular.map { node -> labelled.indexOf(node).takeIf { it >= 0 }?.let { recovered[it] } ?: node }
            }
            fun inside(box:NormalizedBox, r:ShortChoiceCards.Rect):Boolean =
                box.centerX*w/100f in r.left.toFloat()..r.right.toFloat() &&
                box.centerY*h/100f in r.top.toFloat()..r.bottom.toFloat()
            val replacement=choices.map { choice ->
                fun box(b:ShortChoiceCards.Rect)=NormalizedBox(100f*b.left/w,100f*b.top/h,100f*b.w/w,100f*b.h/h)
                val firstLine=box(choice.lines.first())
                if (choice.continuousRule) VisibleQuestionReader.Node("—",firstLine,continuousRule = true)
                else {
                    val words=choice.lines.map { line -> reRead(box(line))?.text?.takeIf{it.length in 1..64} ?:return regular }
                    val text=words.joinToString("")
                    val rule=ShortChoiceCards.labelledRule(w,h,pixels,choice,text)
                    if(rule!=null) VisibleQuestionReader.Node("—",box(rule),continuousRule=true)
                    else VisibleQuestionReader.Node(text,firstLine)
                }
            }
            val verifiedRows = RomanChoiceEvidence.read(w, h, pixels, replacement) ?: replacement
            if (verifiedRows.map { it.text.trim() }.distinct().size != verifiedRows.size)return regular
            // Replace every line inside every proven card as one unit. This prevents an old
            // radio read as 0 or a duplicate digit from remaining beside the recovered text.
            return regular.filter { n->choices.none{c->n.box?.let{inside(it,c.card)}==true} } + verifiedRows
        } finally {image.recycle()}
    }
    private fun recognize(bmp:Bitmap):String {
        val width=bmp.width;val total=width.coerceAtLeast(320)
        val argb=IntArray(width*48);bmp.getPixels(argb,0,width,0,0,width,48)
        val n=48*total;val input=FloatArray(n*3)
        for(y in 0 until 48) for(x in 0 until width){
            val c=argb[y*width+x];val k=y*total+x
            input[k]=(c and 255)/127.5f-1f
            input[k+n]=((c ushr 8) and 255)/127.5f-1f
            input[k+2*n]=((c ushr 16) and 255)/127.5f-1f
        }
        return OnnxTensor.createTensor(env,FloatBuffer.wrap(input),longArrayOf(1,3,48,total.toLong())).use { t ->
            session.run(mapOf("x" to t)).use { out ->
                val ids=(out[0] as OnnxTensor).longBuffer
                val chars=alphabet
                buildString {
                    var prev=-1
                    while(ids.hasRemaining()){val v=ids.get().toInt();if(v!=0 && v!=prev) append(chars.getOrNull(v).orEmpty());prev=v}
                }
            }
        }
    }
    override fun close(){ if(sessionDelegate.isInitialized()) session.close() }
}
