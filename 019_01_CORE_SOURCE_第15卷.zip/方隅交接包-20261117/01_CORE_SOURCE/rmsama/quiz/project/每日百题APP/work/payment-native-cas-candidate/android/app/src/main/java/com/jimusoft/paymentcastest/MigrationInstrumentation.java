package com.jimusoft.paymentcastest;

import android.app.Instrumentation;
import android.content.Context;
import android.os.Bundle;
import android.util.AtomicFile;
import java.io.File;
import java.io.FileOutputStream;
import java.nio.file.Files;
import java.util.Arrays;
import java.util.UUID;
import org.json.JSONObject;

/** Independent emulator-only test; legacy values below are synthetic, never real payment data. */
public final class MigrationInstrumentation extends Instrumentation {
 private int checks=0;
 private void check(boolean ok,String name){checks++;if(!ok)throw new AssertionError(name);}
 @Override public void onCreate(Bundle b){super.onCreate(b);start();}
 @Override public void onStart(){Bundle result=new Bundle();try{
  check(android.os.Build.HARDWARE.contains("ranchu"),"emulator only");
  Context ctx=getTargetContext();String id="case-"+UUID.randomUUID();CandidateStore s=new CandidateStore(ctx,id);
  String identity="{\"installationId\":\"synthetic-owner\",\"accessToken\":\"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\",\"future\":\"keep\"}";
  String pending="[{\"id\":\"synthetic-order\",\"planId\":\"once\",\"amountFen\":100,\"clientRequestId\":\"abcdefgh\"}]";
  String registration="{\"requestId\":\"rrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr\",\"verifier\":\"vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv\"}";
  s.writeSyntheticLegacy("identity",identity);s.writeSyntheticLegacy("pending",pending);s.writeSyntheticLegacy("registration",registration);
  try{s.migrateSyntheticLegacy(true);throw new AssertionError("injected interruption must throw");}catch(CandidateStore.SimulatedInterrupt expected){}
  check(s.read()==null,"interruption before commit leaves no new record");
  check(s.readSyntheticLegacy("identity").equals(identity)&&s.readSyntheticLegacy("pending").equals(pending)&&s.readSyntheticLegacy("registration").equals(registration),"interruption retains legacy records");
  JSONObject migrated=s.migrateSyntheticLegacy(false);check(migrated.getLong("version")==0,"successful migration creates version zero");
  JSONObject v=migrated.getJSONObject("value");check(v.getJSONObject("identity").getString("future").equals("keep"),"unknown legacy identity fields preserved");
  check(v.getJSONArray("pending").getJSONObject(0).getString("id").equals("synthetic-order"),"pending order preserved");
  check(v.getJSONObject("registration").getString("requestId").equals("r".repeat(43)),"registration proof preserved");
  v.getJSONObject("identity").put("accessToken","b".repeat(43));check(s.compareAndSet(0,v),"new record can advance");
  check(s.migrateSyntheticLegacy(false).getLong("version")==1,"retry never replaces newer record with legacy snapshot");
  check(s.read().getJSONObject("value").getJSONObject("identity").getString("accessToken").equals("b".repeat(43)),"new token survives retry");
  check(s.readSyntheticLegacy("identity").equals(identity)&&s.readSyntheticLegacy("pending").equals(pending)&&s.readSyntheticLegacy("registration").equals(registration),"legacy ciphertext remains readable");
  CandidateStore bad=new CandidateStore(ctx,"case-"+UUID.randomUUID());bad.writeSyntheticLegacy("pending",pending);
  try{bad.migrateSyntheticLegacy(false);throw new AssertionError("orphan pending must throw");}catch(IllegalStateException expected){}
  check(bad.read()==null&&bad.readSyntheticLegacy("pending").equals(pending),"invalid legacy state is preserved without new record");
  String crashId="case-"+UUID.randomUUID();CandidateStore interrupted=new CandidateStore(ctx,crashId);
  check(interrupted.compareAndSet(-1,new JSONObject().put("safe","committed")),"fixture commits before interrupted write");
  AtomicFile atomic=new AtomicFile(new File(new File(ctx.getNoBackupFilesDir(),crashId),"record.enc"));
  FileOutputStream unfinished=atomic.startWrite();unfinished.write("incomplete synthetic write".getBytes(java.nio.charset.StandardCharsets.UTF_8));unfinished.getFD().sync();unfinished.close();
  CandidateStore afterInterrupt=new CandidateStore(ctx,crashId);
  check(afterInterrupt.read().getJSONObject("value").getString("safe").equals("committed"),"unfinished AtomicFile write retains last committed record");
  check(afterInterrupt.compareAndSet(0,new JSONObject().put("safe","updated")),"new write recovers after interrupted write");
  String corruptId="case-"+UUID.randomUUID();CandidateStore corrupt=new CandidateStore(ctx,corruptId);corrupt.writeSyntheticLegacy("identity",identity);
  File cipherFile=new File(new File(ctx.getNoBackupFilesDir(),corruptId),"synthetic-legacy-identity.enc");
  byte[] cipher=Files.readAllBytes(cipherFile.toPath());cipher[cipher.length-2]=(byte)(cipher[cipher.length-2]=='A'?'B':'A');Files.write(cipherFile.toPath(),cipher);
  try{corrupt.migrateSyntheticLegacy(false);throw new AssertionError("corrupt ciphertext must throw");}catch(java.security.GeneralSecurityException|IllegalArgumentException expected){}
  check(corrupt.read()==null&&Arrays.equals(cipher,Files.readAllBytes(cipherFile.toPath())),"corrupt legacy ciphertext is never replaced");
  String[] badIdentities={"{\"installationId\":42,\"accessToken\":\""+"a".repeat(43)+"\"}","{\"installationId\":\"ok\",\"accessToken\":\""+"a".repeat(43)+"\",\"purchaseIntent\":{\"planId\":\"once\",\"clientRequestId\":\"bad!\"}}"};
  for(String raw:badIdentities){CandidateStore c=new CandidateStore(ctx,"case-"+UUID.randomUUID());c.writeSyntheticLegacy("identity",raw);
    try{c.migrateSyntheticLegacy(false);throw new AssertionError("bad identity must fail");}catch(IllegalStateException expected){}
    check(c.read()==null&&c.readSyntheticLegacy("identity").equals(raw),"bad identity retained without migration");}
  String[] badPending={"[{\"id\":\"x\",\"planId\":\"once\",\"amountFen\":1.1,\"clientRequestId\":\"abcdefgh\"}]","[{\"id\":\"x\",\"planId\":\"once\",\"amountFen\":100,\"clientRequestId\":\"abcdefgh\"},{\"id\":\"x\",\"planId\":\"week\",\"amountFen\":590,\"clientRequestId\":\"ijklmnop\"}]"};
  for(String raw:badPending){CandidateStore c=new CandidateStore(ctx,"case-"+UUID.randomUUID());c.writeSyntheticLegacy("identity",identity);c.writeSyntheticLegacy("pending",raw);
    try{c.migrateSyntheticLegacy(false);throw new AssertionError("bad pending must fail");}catch(IllegalStateException expected){}
    check(c.read()==null&&c.readSyntheticLegacy("pending").equals(raw),"bad pending retained without migration");}
  result.putString("status","passed");
 }catch(Throwable e){result.putString("status","failed");result.putString("error",String.valueOf(e));}
 finally{result.putInt("checks",checks);finish("passed".equals(result.getString("status"))?-1:0,result);}}
}
