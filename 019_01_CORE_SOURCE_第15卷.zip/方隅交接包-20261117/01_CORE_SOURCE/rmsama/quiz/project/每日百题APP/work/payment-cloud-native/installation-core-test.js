'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict'),crypto=require('node:crypto');
const {Db}=require('../../outputs/managed-import-cloudbase/node_modules/@cloudbase/database/dist/commonjs/index.js');
const {EJSON}=require('../../outputs/managed-import-cloudbase/node_modules/bson');
const {createInternalInstallationCore,createProductionInstallation}=require('./installation-core');
const random=()=>crypto.randomBytes(32).toString('base64url');
function fixture(enabled=true){
  let now=1800000000000;const state={docs:new Map(),txs:new Map(),n:0,version:0,unknown:false};const old=Db.reqClass;
  if(enabled)state.docs.set('policy',{kind:'policy',schema:1,enabled:true});
  Db.reqClass=class{async send(action,p={}){
    if(action==='database.startTransaction'){const transactionId='t'+(++state.n);state.txs.set(transactionId,{docs:structuredClone(state.docs),version:state.version});return {transactionId};}
    if(action==='database.abortTransaction'){state.txs.delete(p.transactionId);return {};}
    if(action==='database.commitTransaction'){const t=state.txs.get(p.transactionId);if(t.version!==state.version)return {code:'DATABASE_TRANSACTION_CONFLICT'};state.docs=t.docs;state.version++;state.txs.delete(p.transactionId);if(state.unknown){state.unknown=false;throw Error('lost reply');}return {};}
    assert.equal(p.collectionName,'daily_hundred_installation_v1');const tx=state.txs.get(p.transactionId),id=JSON.parse(p.query)._id;
    if(action==='database.getDocument')return {data:{list:tx.docs.has(id)?[JSON.stringify({_id:id,...tx.docs.get(id)})]:[]}};
    if(action==='database.modifyDocument'){tx.docs.set(id,EJSON.parse(p.data));return {data:{updated:1,upsert_id:id}};}
    if(action==='database.removeDocument'){tx.docs.delete(id);return {data:{deleted:1}};}
    throw Error('unexpected');
  }};
  const core=createInternalInstallationCore({db:new Db({throwOnCode:true}),registrationKey:'R'.repeat(64),clock:()=>now});
  return {core,state,setTime:v=>{now=v},close:()=>{Db.reqClass=old;}};
}
test('production registration cannot be enabled',()=>assert.throws(()=>createProductionInstallation({enabled:true})));
test('missing policy fails closed without writing registration records',async()=>{const f=fixture(false);try{await assert.rejects(f.core.register({requestId:random(),verifier:random()}));assert.equal(f.state.docs.size,0);}finally{f.close();}});
test('same request proof returns stable credential; different verifier is rejected',async()=>{const f=fixture();try{
  const input={requestId:random(),verifier:random()},first=await f.core.register(input),again=await f.core.register(input);
  assert.deepEqual(first,again);assert.equal(await f.core.authenticate(first.accessToken),first.installationId);
  await assert.rejects(f.core.register({requestId:input.requestId,verifier:random()}));
  assert.ok(!JSON.stringify([...f.state.docs]).includes(first.accessToken));assert.ok(!JSON.stringify([...f.state.docs]).includes(input.verifier));
}finally{f.close();}});
test('commit response loss recovers same identity from same proof',async()=>{const f=fixture();try{
  const input={requestId:random(),verifier:random()};f.state.unknown=true;await assert.rejects(f.core.register(input));
  const one=await f.core.register(input),two=await f.core.register(input);assert.deepEqual(one,two);assert.equal(await f.core.authenticate(one.accessToken),one.installationId);
}finally{f.close();}});
test('bounded registration window, expiration and safe cleanup',async()=>{const f=fixture();try{
  const saved=[];for(let i=0;i<10;i++)saved.push(await f.core.register({requestId:random(),verifier:random()}));
  await assert.rejects(f.core.register({requestId:random(),verifier:random()}));
  const slot=Buffer.from(saved[0].accessToken,'base64url').readUInt16BE(0);
  assert.equal((await f.core.cleanupExpired(slot)).removed,false);
  f.setTime(1800000000000+86400000);await assert.rejects(f.core.authenticate(saved[0].accessToken));
  assert.equal((await f.core.cleanupExpired(slot)).removed,true);
  assert.ok((await f.core.register({requestId:random(),verifier:random()})).accessToken);
}finally{f.close();}});
test('retry finds an existing later collision slot even when earlier slot expired',async()=>{const f=fixture();try{
  const slot=requestId=>crypto.createHash('sha256').update(requestId).digest().readUInt32BE(0)%32768;
  const first={requestId:random(),verifier:random()},target=slot(first.requestId);let candidate;
  for(let n=0;n<250000;n++){const id=random();if(slot(id)===target&&id!==first.requestId){candidate=id;break;}}
  assert.ok(candidate);const second={requestId:candidate,verifier:random()};
  await f.core.register(first);f.setTime(1800000000000+60000);
  const original=await f.core.register(second);f.setTime(1800000000000+86400000);
  await assert.rejects(f.core.register({requestId:second.requestId,verifier:random()}));
  assert.deepEqual(await f.core.register(second),original);
  assert.equal(await f.core.authenticate(original.accessToken),original.installationId);
}finally{f.close();}});

test('concurrent retries use one slot and one rate-window count',async()=>{const f=fixture();try{
  const input={requestId:random(),verifier:random()};
  const attempts=await Promise.allSettled([f.core.register(input),f.core.register(input)]);
  assert.equal(attempts.filter(x=>x.status==='fulfilled').length,2);
  assert.deepEqual(attempts[0].value,attempts[1].value);
  assert.equal([...f.state.docs.values()].filter(x=>x.kind==='slot').length,1);
  assert.equal(f.state.docs.get('window').count,1);
}finally{f.close();}});
