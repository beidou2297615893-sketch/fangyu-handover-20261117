(()=>{const s=JSON.parse(localStorage.getItem('quiz-control-settings')||'{}');return {endpoint:s.endpoint,model:s.model,prompt:s.prompt,apiKey:localStorage.getItem('quiz-control-api-key')};})()
