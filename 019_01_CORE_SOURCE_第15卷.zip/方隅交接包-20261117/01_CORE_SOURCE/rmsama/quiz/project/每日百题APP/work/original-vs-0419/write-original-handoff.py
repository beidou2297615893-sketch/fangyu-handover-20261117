from pathlib import Path
import datetime,json
r=Path('V:/work/original-vs-0419');project=r.parent.parent
now=datetime.datetime.now().astimezone().isoformat(timespec='seconds')
content=f'''# 知题交接：先验证题进原版，再逐项增加功能

更新时间：{now}。本文件优先于此前所有“继续验收/上传0.4.20”的记录。

## 用户最新决定（必须保持）

先把GitHub原版在模拟器多跑几轮，弄清它真实的识别、查库、点击、确认和换页逻辑，看看能否做到每轮100题无错误。原版基线确认后，才一点点加UI、名称、支付。不能继续向改造版叠补丁，不能继续发布0.4.20，也不能把环境/配置失败说成“原项目做得差”。

用户另要求先写好交接，并每几分钟检查额度，剩2%时立即停工、更新交接。已发现真实工具mcp__codex_app__get_usage_limits，可直接只读调用{{}}；最近实查usedPercent=94，剩余6%，是账号共享的10080分钟窗口。每约120秒检查，remaining=100-usedPercent；任一适用可读窗口<=2%立即停止本任务自己的测试/模型调用/子代理，保存现场并交接，不能假装能监控或只靠估计。不要新建周期自动化，不购买额度，不重置额度，不干扰其他聊天。最新轮询另写work/original-vs-0419/quota-checks.jsonl。

## 当前已停止和已保留的东西

- 项目：C:/Users/rmsama/Documents/ChatGPT/答题小程序/每日百题APP，V:映射它。
- 改造源work/tijing-bankassist及0.4.20候选完整保留，暂不再编辑、安装验收或上传。
- 改造版自然场hidden-final-natural-v3在86题全部正确、0错后，按用户新顺序主动中止；final-summary.json阶段STOPPED_FOR_ORIGINAL_BASELINE。不是程序失败，也不是100/100。其wrapper、monitor和日志记录器已停，自动正式升级/发布流程未执行。
- 其他历史场：hidden-current3题后暂停；hidden-fixed10题；hidden-complete22题；hidden-roman-fixed45题；hidden-final-natural53题判分后暂停；v2为16/16后主动去掉内部序号假设。不要抹掉或套用成绩。
- 改造版185项单测、100题逐图96本机+4真实云抄题查库、103页状态诊断通过。这些是旧路线证据，不能冒充原版成绩或真机验收。
- 改造QA SHA d2d6fd6b97c4ad8222fa0b4db481e20af5b0e78ecd6ada886eb24e6613e773f6，com.jimusoft.dailyhundredapp.audit419.dev，只诊断。
- 0.4.20/code87手机候选SHA e581837ab163211537c31a57c8ba84709fd917530cfe764f9cde2fd1cac91ec7；完整候选SHA2144beeb981267ffd815d58075e608053f6e54d161c9bd6f853cc234c3ca4f42。目录release-mobile/release-universal，APK后缀android/app/build/outputs/apk/prod/release/app-prod-release.apk。结构同源核验release-checks/result.json真实通过，但不允许据此继续发布。
- 已发布仍0.4.19/code86，蒲公英https://www.pgyer.com/meiribaiti，序号38，SHA33411dbe246d73d9e4328d4d80429eaaf28afc0d78a4cfd8defd4f3cd6b0565e。账号已确认仍登录Chrome，未上传新版。
- 手机不方便USB；小米澎湃OS/支付宝实付尚未验收，用户明确手机实付后测。不要重复问USB。

## 原版与源码身份

- 作者仓库https://github.com/futureYYY/TiJing；work/tijing-upstream，HEAD2d2da07868fe9ada3ce734df42af8495263661ea；与v0.7.7的16份Android核心文件无差异，仅README不同。
- 官方APK outputs/题镜官方原版/TiJing-0.7.7-open.apk，960780字节（约0.92MiB），SHA3f4988b2fe4c5eaab22c4e604468c9c99114a0ce3b522611601b2b9a0fcff20f，已对作者sha核验。
- 官方安装ID com.futureyyy.tijing。之前做过测试，后来为清除临时APIkey执行pm clear（original-test-cleanup.json），因此新轮需重新导入1859题和配置原有API，不能以空配置开始后怪原版。
- original-control是同原生16文件的调试对照包com.futureyyy.tijing.dev，仅DEBUG开放本机http，web来自官方；不是作者原APK。不能把此包标签改成官方原版。
- work/tijing-vanilla-compare不是纯原版（有2行变化）；work/tijing-minimal只是未验收原版+旧UI/支付试验，不能当原版/成品。

## 原版已核实的逻辑（原文件行号）

1. AUTO/VISION每题直接截图请求视觉模型，答案来自模型，不初始化/查本机库。Service391–399/519–534，Coordinator264–274。模型给选项坐标，选中后截图更新基线，再确认；确认优先无障碍“确认”，失败才用模型confirm_box。Service660–709，Coordinator375–446。
2. 换页仅截图签名差>=18且两次候选稳定<=8判定，非宿主进度/判分/下一题语义。Coordinator586–640。最多12轮询、确认3次后暂停。没有专门100题/结果页自动结束状态。测试应记录宿主完成与原版是否自行停，不能混为一谈。
3. QUESTION_BANK强制MANUAL（Service763）。模型只提取题干后本机匹配，命中用库内答案展示，无点击坐标、不自动选确认。未命中/冲突/无效再同图视觉解题，并异步写回库。用户自己答题和换页，再点识别。该模式不能当原生全自动100题跑。
4. 原配置可自由填API地址/模型名/两套prompt/timeout/retry。ModelClient固定temperature0、正式max_tokens1200、连接测试8；没有thinking/reasoning或任意body参数透传。baseURL自动补/chat/completions，完整该地址原样用。替代模型名可填，但必须真实验证服务支持图片和返回内容。
5. 原生gateway接口存在，但没有后加answerResolver/frameReader hook。本轮只读审查代理compare_fix_review已完成上述核对，未改源/未ADB。不能把后加能力说成原版自带。

## 旧原版对照做过什么、不能得出什么

- 官方原APK在静态铁路页首题截图超时；16源完全相同调试包也复现。capture-fresh日志显示overlay等待期间旧ImageReader取走已有帧，之后静态页不一定有新帧。这里只证明本次环境的问题，不证明原项目普遍差。
- 原模型deepseek-flash默认思考耗尽1200输出预算，content可为空；同请求disabled有内容。原设置没有禁思考参数，下一步应优先找现有API支持的非思考/兼容视觉模型配置，不改APK，不擅自部署新网关。
- 给宿主页1px持续重绘、外部代理关闭思考的辅助对照只跑2题：1对1错；旧monitor遇wrong即停。它不是自然100，也不能把2题推成50%准确率；该结果不足以完成用户最新“原版多轮”。
- 接下来要重新跑多轮，记录原版本身不改源码、环境配置、静态/刷新条件是否改变、宿主100题答对/答错/未提交/重复/人工。错误时不要为了凑满分人工选答案或推进后仍说自然通过。

## 下一步具体执行

1. 每约2分钟调用get_usage_limits，<=2立即收工更新本文件。先做好当前文件，避免额度耗尽来不及。
2. 仅专用ADB端口15037、serial emulator-5588，API35，1080x2400。别碰真机/其他模拟器。运行中不用uiautomator，会扰动无障碍；只读日志/截图。
3. 原版官方APK安装仍在，配置已清空。可复用configure-original.py（安全在内存读取本项目现有DEEPSEEK_API_KEY、UI填密码字段、不打印key），但它固定deepseek-flash；先用实际API只读/models及最小图片请求验证可用兼容模型，不能拿“连接测试成功”当视觉解题成功。不读取/输出其他项目密钥。
4. 原版浮窗准备脚本已有start-original.js、stop-original.js、status-original.js；读取前先看文件长度/取前几百字符，避免带入私有配置。get-model-config-private.js绝不能打印。import-original-control.js是内嵌1859题的一整行巨文件，不能Get-Content整行输出；只执行/本地解析。
5. 脚本可复用control.py（固定15037/5588）、cdp.cjs、原宿主railway-mp-replica。当前宿主com.jimusoft.railwaymp.canvas419，原HTML/CSS/逻辑、确认→判分→下一题，固定同100题；不是手机微信。普通可读宿主com.jimusoft.railwaymp也在。清楚分别标识自然条件和辅助刷新诊断，不偷偷加动画。
6. 多轮监控必须修改为“错题计数但不因首错强行停”（仅原版测试脚本，不改软件）；遇原版暂停/宿主完成/真实超时才结束。旧monitor-current.py遇status.wrong即停，不适合直接宣称原版100题完整评估。外部停止测试与软件自然完成分开。
7. 如静态场景反复首题超时，先保留3次证据并查配置/运行环境，别一遍遍盲跑，别改源码后仍说原版。用户想基线稳定后再加。若需兼容修正，明确单独变更并独立验收，不能混进纯原版成绩。
8. 原版QUESTION_BANK为手动展示，若测查库准确率，只算逐题识别/查库展示，不算全自动提交。必须讲清原版实际功能范围，不以模式设计差异评价好坏。

## 持续现场与安全

- 本轮work/original-vs-0419；所有新中间文件继续放此处或original-only-rounds子目录。对人交付放outputs/开发交接和原版与知题铁路对照。
- 当前唯一还运行的本项目python后台为relay-real-model.py（PID15468上次观察），仅本机18765，真实外部模型代理，关闭思考且不注答案；它是诊断服务，不是纯原版。用不用需注明，不要部署新服务替代后假称未改环境。
- Chrome原账号登录已确认，窗口69942、Cua变量publishApp，但现在不操作上传。其他项目“抖音采集已停止”悬窗不碰。CUA登录检查段已completion_summary，不代表有发布。
- 不把1859题、密钥、令牌、日志打入APK或上传。key只内存安全读取，用完清理本次原版测试副本配置（仅专用模拟器），不删用户真机数据。

当前额度最后已查6%，原版新三轮尚未开始。继续时先查最新quota-checks和原版轮次记录，不能把本文件初次写入当“多轮测试已完成”。
'''
out=project/'outputs/开发交接/知题-原版多轮验证-AI交接.md'
out.write_text(content,encoding='utf-8')
canonical=project/'outputs/开发交接/知题-AI接手续办.md'
old=canonical.read_text(encoding='utf-8')
notice='# 最新方向已改：先测纯原版，多轮后才逐项增加功能\n\n用户最新要求与额度2%停工规则，以同目录《知题-原版多轮验证-AI交接.md》为最高优先级。改造版v3在86/86后已按新顺序主动停止，未发布0.4.20；下面的旧“继续v3/正式升级/上传”操作已暂停，不得自动执行。\n\n'
if not old.startswith('# 最新方向已改：先测纯原版'):
    canonical.write_text(notice+old,encoding='utf-8')
state={'updatedAt':now,'phase':'original_only_baseline','integrationTestingStopped':True,'publishingAllowedNow':False,
    'modifiedRoundStoppedAt':86,'modifiedRoundCorrect':86,'originalNewRoundsStarted':False,
    'quotaRemainingLastSeen':6,'quotaStopAtPercent':2,'quotaPollSeconds':120,'handoff':str(out)}
(r/'original-phase.json').write_text(json.dumps(state,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'file':str(out),'folder':str(out.parent),'bytes':out.stat().st_size},ensure_ascii=False))
