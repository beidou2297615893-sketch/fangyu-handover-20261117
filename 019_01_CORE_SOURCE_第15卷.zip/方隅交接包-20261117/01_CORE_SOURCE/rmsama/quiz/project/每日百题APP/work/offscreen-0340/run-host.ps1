param([string]$Log='host.log')
$ErrorActionPreference='Stop'
$taskWork=Split-Path -Parent $PSScriptRoot
$taskRoot=Split-Path -Parent $taskWork
$taskJdk=(Get-ChildItem -LiteralPath (Join-Path $taskWork 'tools/jdk') -Directory | Select-Object -First 1).FullName
$taskLib=(Get-ChildItem -LiteralPath (Join-Path $taskWork 'gradle-home/wrapper/dists/gradle-9.3.1-bin') -Recurse -Directory -Filter lib | Select-Object -First 1).FullName
$taskClasses=Join-Path $PSScriptRoot 'host-classes'
New-Item -ItemType Directory -Path $taskClasses -Force | Out-Null
$taskSource=Join-Path $taskRoot 'outputs/daily-hundred-app/modules/automation-bridge/android/src/main/java/expo/modules/automationbridge'
$taskFiles=@('screen/ScreenModels.kt','screen/QuestionExtractor.kt','profile/WorkflowProfile.kt','profile/WorkflowValidator.kt','bank/WorkspaceRepository.kt','bank/QuestionMatcher.kt','runtime/RunModels.kt','runtime/RunCodec.kt','billing/PaidSubmissionGuard.kt') | ForEach-Object { Join-Path $taskSource $_ }
$taskFiles+=Get-ChildItem -LiteralPath (Join-Path $taskSource 'generic') -Filter '*.kt' | Where-Object Name -ne 'GenericDriver.kt' | Select-Object -ExpandProperty FullName
$taskFiles+=Join-Path $PSScriptRoot 'OffscreenNavigationTest.kt'
$taskStdlib=Join-Path $taskLib 'kotlin-stdlib-2.2.21.jar'
$taskClasspath=$taskStdlib+';'+(Join-Path $taskWork 'native-host-tests/json-20250517.jar')
& (Join-Path $taskJdk 'bin/java.exe') -cp ($taskLib+'/*') org.jetbrains.kotlin.cli.jvm.K2JVMCompiler -no-stdlib -no-reflect -classpath $taskClasspath -d $taskClasses $taskFiles
if($LASTEXITCODE -ne 0){throw 'Host compilation failed'}
& (Join-Path $taskJdk 'bin/java.exe') -cp ($taskClasses+';'+$taskClasspath+';'+(Join-Path $taskSource '../../../../resources')) expo.modules.automationbridge.OffscreenNavigationTestKt 2>&1 | Tee-Object -LiteralPath (Join-Path $PSScriptRoot $Log)
if($LASTEXITCODE -ne 0){throw 'Offscreen behavior failed'}
