"""Regression checks against the production action and persistence boundary."""
import pathlib, unittest
ROOT=pathlib.Path(__file__).resolve().parents[2]/'outputs/daily-hundred-app/modules/automation-bridge/android/src/main/java/expo/modules/automationbridge'
class BoundaryTest(unittest.TestCase):
    def test_intent_is_not_yet_marked_as_dispatched(self):
        text=(ROOT/'TaskDatabase.kt').read_text(encoding='utf-8')
        intent=text.split('internal fun savePaidSubmissionIntent',1)[1].split('internal fun ',1)[0]
        dispatch=text.split('internal fun markPaidSubmissionDispatched',1)[1].split('internal fun ',1)[0]
        self.assertNotIn('markUnknownInTransaction',intent)
        self.assertIn('markUnknownInTransaction',dispatch)
        self.assertIn('paidPendingIntentId',dispatch)
    def test_every_actual_dispatch_is_preceded_by_native_marker(self):
        text=(ROOT/'runtime/ActionExecutor.kt').read_text(encoding='utf-8')
        native=text.index('node.performAction')
        gesture=text.index('service.dispatchGesture')
        self.assertIn('dispatchGate(intent)',text[max(0,native-150):native])
        self.assertIn('dispatchGate(intent)',text[max(0,gesture-150):gesture])
    def test_explicit_system_rejection_is_recorded_inside_action_lock(self):
        driver=(ROOT/'generic/GenericDriver.kt').read_text(encoding='utf-8')
        self.assertIn('if(!accepted)paidRejectedDispatch?.invoke(candidate)',driver)
        database=(ROOT/'TaskDatabase.kt').read_text(encoding='utf-8')
        self.assertIn('markRejectedInTransaction',database)
if __name__=='__main__': unittest.main()
