import control as c
import subprocess,time,json,sys
root=c.R;folder=sys.argv[1] if len(sys.argv)>1 else 'hidden-final-natural-v3';target=root/folder
target.mkdir(exist_ok=True)
assert not (target/'final-summary.json').exists(),'Preserve an existing natural run; use a new folder instead.'
batch=json.loads((root/'batch-final/batch-ocr-result.json').read_text(encoding='utf-8'))
assert batch['finished'] and batch['processed']==100
assert all(x['matchesExpected'] or x.get('cloudComparison',{}).get('matchesExpected') for x in batch['results'])
pages=json.loads((root/'feedback-pages-v2/batch-ocr-result.json').read_text(encoding='utf-8'))
assert pages['finished'] and pages['pageCompared']==103 and pages['pagePassed']==103
apk=root/'regression-stage/app/build/outputs/apk/dev/debug/app-dev-debug.apk'
audit=json.loads((root/'evidence-audit.json').read_text(encoding='utf-8'))
import hashlib
assert hashlib.sha256(apk.read_bytes()).hexdigest()==audit['fixedDiagnosticApk']['sha256']
(target/'apk-used.json').write_text(json.dumps(audit['fixedDiagnosticApk'],indent=2),encoding='utf-8')
def run(file,*args):subprocess.run([sys.executable,str(root/file),*map(str,args)],check=True)
run('setup-fixed-current.py',apk)
c.tap(988,1204);time.sleep(.5);c.adb('logcat','-c');c.tap(730,1230)
(root/'active-natural-folder.txt').write_text(folder,encoding='utf-8')
run('start-log-recorder.py',folder)
run('monitor-current.py',folder,'com.jimusoft.railwaymp.canvas419','1600','com.jimusoft.dailyhundredapp.audit419.dev')
result=json.loads((target/'final-summary.json').read_text(encoding='utf-8'))
if result['last']=='result' and result['confirmed']==100 and result['wrong']==0:
    run('validate-finished-run.py',folder)
    run('check-reopen.py',folder)
    run('check-formal-upgrade.py')
run('write-comparison-report.py')
print('Natural comparison completed; see the actual saved result.',flush=True)
