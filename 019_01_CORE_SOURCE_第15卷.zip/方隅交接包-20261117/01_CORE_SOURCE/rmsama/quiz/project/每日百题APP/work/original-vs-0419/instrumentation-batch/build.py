from pathlib import Path
import os
import subprocess
import zipfile

root = Path(__file__).resolve().parent
sdk = Path('V:/work/tools/android-sdk')
tools = sdk / 'build-tools/35.0.0'
platform = sdk / 'platforms/android-35/android.jar'
jdk = next(Path('V:/work/tools/jdk').glob('jdk-17*'))
env = os.environ.copy()
env['JAVA_HOME'] = str(jdk)
classes = root / 'classes'
dex = root / 'dex'
classes.mkdir(exist_ok=True)
dex.mkdir(exist_ok=True)


def run(args):
    subprocess.run(list(map(str, args)), check=True, env=env)


run([jdk / 'bin/javac.exe', '-encoding', 'UTF-8', '-source', '8', '-target', '8',
     '-cp', platform, '-d', classes, root / 'BatchOcrProbe.java'])
jar = root / 'classes.jar'
with zipfile.ZipFile(jar, 'w') as archive:
    for file in classes.rglob('*.class'):
        archive.write(file, file.relative_to(classes).as_posix())
run([tools / 'd8.bat', '--lib', platform, '--min-api', '26', '--output', dex, jar])
unsigned = root / 'probe-unsigned.apk'
aligned = root / 'probe-aligned.apk'
signed = root / 'batch-ocr-probe.apk'
run([tools / 'aapt.exe', 'package', '-f', '-M', root / 'AndroidManifest.xml',
     '-I', platform, '-F', unsigned])
with zipfile.ZipFile(unsigned, 'a') as archive:
    archive.write(dex / 'classes.dex', 'classes.dex')
run([tools / 'zipalign.exe', '-f', '4', unsigned, aligned])
run([tools / 'apksigner.bat', 'sign', '--ks', Path.home() / '.android/debug.keystore',
     '--ks-key-alias', 'androiddebugkey', '--ks-pass', 'pass:android',
     '--key-pass', 'pass:android', '--out', signed, aligned])
run([tools / 'apksigner.bat', 'verify', signed])
print('Built isolated batch OCR probe APK:', signed)
