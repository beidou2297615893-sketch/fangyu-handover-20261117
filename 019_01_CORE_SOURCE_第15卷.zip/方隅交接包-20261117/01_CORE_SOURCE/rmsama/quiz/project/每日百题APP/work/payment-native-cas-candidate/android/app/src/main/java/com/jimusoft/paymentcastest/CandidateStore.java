package com.jimusoft.paymentcastest;

import android.content.Context;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.AtomicFile;
import android.util.Base64;
import java.io.File;
import java.io.FileOutputStream;
import java.io.RandomAccessFile;
import java.nio.channels.FileLock;
import java.security.KeyStore;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import org.json.JSONObject;

/** Isolated test package only. This is a candidate, not the production wallet. */
final class CandidateStore {
  private static final Object localLock=new Object();
  private static final String ALIAS="daily-hundred-payment-cas-test-only-v1";
  private final File folder, lockFile;
  private final AtomicFile data;
  CandidateStore(Context ctx,String name){
    if(!name.matches("case-[0-9a-f-]{36}"))throw new IllegalArgumentException("case name");
    folder=new File(ctx.getNoBackupFilesDir(),name);
    if(!folder.exists()&&!folder.mkdirs())throw new IllegalStateException("mkdir");
    lockFile=new File(folder,"record.lock");data=new AtomicFile(new File(folder,"record.enc"));
  }
  private SecretKey key(boolean create) throws Exception{
    KeyStore ks=KeyStore.getInstance("AndroidKeyStore");ks.load(null);
    SecretKey existing=(SecretKey)ks.getKey(ALIAS,null);if(existing!=null)return existing;
    if(!create)throw new IllegalStateException("test key unavailable");
    KeyGenerator gen=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore");
    gen.init(new KeyGenParameterSpec.Builder(ALIAS,KeyProperties.PURPOSE_ENCRYPT|KeyProperties.PURPOSE_DECRYPT).setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build());return gen.generateKey();
  }
  private interface Locked<T>{T run()throws Exception;}
  private <T>T locked(Locked<T> work)throws Exception{
    synchronized(localLock){try(RandomAccessFile f=new RandomAccessFile(lockFile,"rw");FileLock ignored=f.getChannel().lock()){return work.run();}}
  }
  private JSONObject readUnlocked()throws Exception{
    if(!data.getBaseFile().exists()&&!new File(data.getBaseFile().getPath()+".bak").exists())return null;
    String[] parts=new String(data.readFully(),java.nio.charset.StandardCharsets.UTF_8).split(":",-1);if(parts.length!=2)throw new IllegalStateException("bad envelope");
    Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");cipher.init(Cipher.DECRYPT_MODE,key(false),new GCMParameterSpec(128,Base64.decode(parts[0],Base64.NO_WRAP)));cipher.updateAAD("identity-cas-test".getBytes(java.nio.charset.StandardCharsets.UTF_8));
    JSONObject result=new JSONObject(new String(cipher.doFinal(Base64.decode(parts[1],Base64.NO_WRAP)),java.nio.charset.StandardCharsets.UTF_8));
    if(result.length()!=2||result.getLong("version")<0||!(result.get("value") instanceof JSONObject))throw new IllegalStateException("bad record");return result;
  }
  JSONObject read()throws Exception{return locked(this::readUnlocked);}
  private boolean writeUnlocked(long expected,JSONObject value)throws Exception{
      JSONObject old=readUnlocked();long current=old==null?-1:old.getLong("version");if(current!=expected)return false;
      if(expected==Long.MAX_VALUE)throw new IllegalStateException("version exhausted");
      String plaintext=new JSONObject().put("version",expected+1).put("value",value).toString();
      if(plaintext.getBytes(java.nio.charset.StandardCharsets.UTF_8).length>65536)throw new IllegalArgumentException("too large");
      Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");cipher.init(Cipher.ENCRYPT_MODE,key(true));cipher.updateAAD("identity-cas-test".getBytes(java.nio.charset.StandardCharsets.UTF_8));
      String payload=Base64.encodeToString(cipher.getIV(),Base64.NO_WRAP)+":"+Base64.encodeToString(cipher.doFinal(plaintext.getBytes(java.nio.charset.StandardCharsets.UTF_8)),Base64.NO_WRAP);
      FileOutputStream stream=data.startWrite();try{stream.write(payload.getBytes(java.nio.charset.StandardCharsets.UTF_8));stream.getFD().sync();data.finishWrite(stream);}catch(Exception e){data.failWrite(stream);throw e;}
      JSONObject verified=readUnlocked();if(verified==null||verified.getLong("version")!=expected+1||!verified.getJSONObject("value").toString().equals(value.toString()))throw new IllegalStateException("verification failed");
      return true;
  }
  boolean compareAndSet(long expected,JSONObject value)throws Exception{
    return locked(()->writeUnlocked(expected,value));
  }
  static final class SimulatedInterrupt extends Exception {}
  private AtomicFile syntheticLegacy(String slot){
    if(!slot.matches("identity|pending|registration"))throw new IllegalArgumentException("legacy slot");
    return new AtomicFile(new File(folder,"synthetic-legacy-"+slot+".enc"));
  }
  // Fixture writer runs only inside this separate test package, never against the real wallet.
  void writeSyntheticLegacy(String slot,String raw)throws Exception{
    locked(()->{AtomicFile file=syntheticLegacy(slot);Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.ENCRYPT_MODE,key(true));c.updateAAD(slot.getBytes(java.nio.charset.StandardCharsets.UTF_8));
      String out=Base64.encodeToString(c.getIV(),Base64.NO_WRAP)+":"+Base64.encodeToString(c.doFinal(raw.getBytes(java.nio.charset.StandardCharsets.UTF_8)),Base64.NO_WRAP);
      FileOutputStream stream=file.startWrite();try{stream.write(out.getBytes(java.nio.charset.StandardCharsets.UTF_8));stream.getFD().sync();file.finishWrite(stream);}catch(Exception e){file.failWrite(stream);throw e;}return null;});
  }
  private String readLegacyUnlocked(String slot)throws Exception{
    AtomicFile file=syntheticLegacy(slot);if(!file.getBaseFile().exists()&&!new File(file.getBaseFile().getPath()+".bak").exists())return null;
    String[] parts=new String(file.readFully(),java.nio.charset.StandardCharsets.UTF_8).split(":",-1);if(parts.length!=2)throw new IllegalStateException("legacy envelope");
    Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.DECRYPT_MODE,key(false),new GCMParameterSpec(128,Base64.decode(parts[0],Base64.NO_WRAP)));c.updateAAD(slot.getBytes(java.nio.charset.StandardCharsets.UTF_8));
    return new String(c.doFinal(Base64.decode(parts[1],Base64.NO_WRAP)),java.nio.charset.StandardCharsets.UTF_8);
  }
  String readSyntheticLegacy(String slot)throws Exception{return locked(()->readLegacyUnlocked(slot));}
  JSONObject migrateSyntheticLegacy(boolean interruptBeforeCommit)throws Exception{
    return locked(()->{
      JSONObject current=readUnlocked();if(current!=null)return current;
      String i=readLegacyUnlocked("identity"),p=readLegacyUnlocked("pending"),r=readLegacyUnlocked("registration");
      JSONObject identity=i==null?null:new JSONObject(i), registration=r==null?null:new JSONObject(r);
      org.json.JSONArray pending=p==null?new org.json.JSONArray():new org.json.JSONArray(p);
      if(identity!=null){
        Object installation=identity.opt("installationId"),token=identity.opt("accessToken");
        if(!(installation instanceof String)||((String)installation).isEmpty()||!(token instanceof String)||((String)token).length()<32)throw new IllegalStateException("bad identity");
        if(identity.has("purchaseIntent")){Object intentValue=identity.opt("purchaseIntent");if(!(intentValue instanceof JSONObject))throw new IllegalStateException("bad intent");
          JSONObject intent=(JSONObject)intentValue;Object plan=intent.opt("planId"),request=intent.opt("clientRequestId");
          if(!(plan instanceof String)||!((String)plan).matches("[A-Za-z0-9_-]{1,40}")||!(request instanceof String)||!((String)request).matches("[A-Za-z0-9_-]{8,100}"))throw new IllegalStateException("bad intent");}
      }
      if(identity==null&&pending.length()>0)throw new IllegalStateException("orphan pending");
      java.util.Set<String> orderIds=new java.util.HashSet<>();
      for(int x=0;x<pending.length();x++){JSONObject q=pending.getJSONObject(x);Object id=q.opt("id"),plan=q.opt("planId"),request=q.opt("clientRequestId"),amount=q.opt("amountFen");
        if(!(id instanceof String)||((String)id).isEmpty()||!orderIds.add((String)id)||!(plan instanceof String)||((String)plan).isEmpty()||!(request instanceof String)||((String)request).isEmpty()||!(amount instanceof Number))throw new IllegalStateException("bad pending");
        double fen=((Number)amount).doubleValue();if(!Double.isFinite(fen)||fen<0||fen>9007199254740991d||Math.floor(fen)!=fen)throw new IllegalStateException("bad amount");}
      if(registration!=null&&(registration.length()!=2||!registration.optString("requestId").matches("[A-Za-z0-9_-]{43}")||!registration.optString("verifier").matches("[A-Za-z0-9_-]{43}")))throw new IllegalStateException("bad registration");
      JSONObject value=new JSONObject().put("identity",identity==null?JSONObject.NULL:identity).put("pending",pending).put("registration",registration==null?JSONObject.NULL:registration);
      if(interruptBeforeCommit)throw new SimulatedInterrupt();
      if(!writeUnlocked(-1,value))throw new IllegalStateException("unexpected migration conflict");
      return readUnlocked();
    });
  }
}
