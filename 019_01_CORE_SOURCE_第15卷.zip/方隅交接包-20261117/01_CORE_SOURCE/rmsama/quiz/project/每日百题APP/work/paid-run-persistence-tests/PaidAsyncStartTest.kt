package expo.modules.automationbridge.billing

import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

object PaidAsyncStartTest {
  @JvmStatic fun main(args:Array<String>) {
    val lock=Any();val gate=PaidAsyncStart(lock);var launches=0;var releases=0
    val entered=CountDownLatch(1);val unblock=CountDownLatch(1)
    val ticket=gate.ticket();val first=Thread { gate.start(ticket,{entered.countDown();check(unblock.await(2,TimeUnit.SECONDS));"reserved"}, {true}, {launches++}, {releases++}) }
    first.start();check(entered.await(1,TimeUnit.SECONDS))
    var secondDenied=false;var secondRequested=false;try { gate.start(gate.ticket(),{secondRequested=true;"reserved"},{true},{launches++},{releases++}) } catch(_:IllegalStateException) { secondDenied=true };check(secondDenied && !secondRequested)
    synchronized(lock) { gate.invalidate() }
    unblock.countDown();first.join();check(launches==0 && releases==1) { "stale reservation started instead of being released" }
    gate.start(gate.ticket(),{"reserved"},{true},{launches++},{releases++});check(launches==1 && releases==1)
    gate.start(gate.ticket(),{"reserved"},{false},{launches++},{releases++});check(launches==1 && releases==2)
    val old=gate.ticket();gate.invalidate();var called=false
    try { gate.start(old,{called=true;"reserved"},{true},{launches++},{releases++}) } catch(_:IllegalStateException) {}
    check(!called){"an invalidated selection must not begin a server request"}
    val gate2=PaidAsyncStart(lock);val pending=CountDownLatch(1);val done=CountDownLatch(1);var paused=false;var retained=false;var accidentalRelease=false
    val ticket2=gate2.ticket();val pauseWorker=Thread { gate2.start(ticket2,{pending.countDown();check(done.await(2,TimeUnit.SECONDS));"reserved"},{!paused},{error("must not start paused task")},{if(paused)retained=true else accidentalRelease=true}) }
    pauseWorker.start();check(pending.await(1,TimeUnit.SECONDS));synchronized(lock){paused=true;gate2.invalidate()};done.countDown();pauseWorker.join()
    check(retained && !accidentalRelease){"a paused task must retain its reservation for continuation"}
    val gate3=PaidAsyncStart(lock);var afterFailure=false
    try { gate3.start(gate3.ticket(),{"reserved"},{true},{error("target launch failed")},{}) } catch(_:IllegalStateException) {}
    gate3.start(gate3.ticket(),{"reserved"},{true},{afterFailure=true},{})
    check(afterFailure){"a launch failure must not leave the asynchronous gate permanently busy"}
    println("PASS native async admission rejects stale or changed task before launch")
  }
}
