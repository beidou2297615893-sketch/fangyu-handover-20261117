import pathlib,json
d=pathlib.Path(__file__).parent
for f in d.glob("lines-*.json"):
 records=json.loads(f.read_text())
 for rec in records:
  if rec["file"]!="sample-h4.png":continue
  stem="".join(l["text"] for l in sorted(rec["lines"],key=lambda l:l["box"][1]) if ("crop300" in f.name or 17<l["box"][1]<42))
  print(f.stem, stem)
