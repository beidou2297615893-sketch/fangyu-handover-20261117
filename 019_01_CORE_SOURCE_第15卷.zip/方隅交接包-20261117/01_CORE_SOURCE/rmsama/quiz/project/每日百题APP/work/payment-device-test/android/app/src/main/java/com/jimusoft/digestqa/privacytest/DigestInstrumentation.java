package com.jimusoft.digestqa.privacytest;

import android.app.Instrumentation;
import android.os.Bundle;
import android.provider.Settings;
import expo.modules.automationbridge.billing.FreeDeviceDigest;

public final class DigestInstrumentation extends Instrumentation {
  @Override public void onCreate(Bundle args) { super.onCreate(args); start(); }
  @Override public void onStart() {
    Bundle out = new Bundle();
    try { String id=Settings.Secure.getString(getTargetContext().getContentResolver(),Settings.Secure.ANDROID_ID);out.putString("digest",FreeDeviceDigest.derive(id));out.putString("status","passed"); }
    catch (Exception e) { out.putString("status","failed"); }
    finish(0,out);
  }
}
