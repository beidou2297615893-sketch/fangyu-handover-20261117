'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict'),crypto=require('node:crypto');const {derive}=require('./derive-core.cjs');
test('derived owner agrees with the actual registration implementation and proof gates',async()=>{
 const master=crypto.randomBytes(32),identity={requestId:crypto.randomBytes(32).toString('base64url'),verifier:crypto.randomBytes(32).toString('base64url'),clientRequestId:crypto.randomBytes(32).toString('base64url')};
 const cfg=derive(master,identity),registrationKey=crypto.createHmac('sha256',master).update('dailyhundred-payment-v1\0registration').digest('hex');
 const rows=new Map([['policy',{kind:'policy',schema:1,enabled:true}]]),db={runTransaction:async fn=>fn({collection:()=>({doc:id=>({get:async()=>({data:rows.has(id)?{_id:id,...rows.get(id)}:null}),set:async value=>{rows.set(id,value);return {updated:1}}})})})};
 const installation=require('../payment-cloud-native/stable-installation').createStableInstallation({db,registrationKey});const registered=await installation.register({requestId:identity.requestId,verifier:identity.verifier});
 assert.equal(cfg.BILLING_PILOT_OWNER,registered.installationId);const policy=require('../payment-cloud-native/pilot-policy').pilotPolicy(cfg,registrationKey);
 assert.equal(policy.registration(identity),true);assert.equal(policy.order({planId:'once',clientRequestId:identity.clientRequestId}),true);assert.equal(policy.order({planId:'week',clientRequestId:identity.clientRequestId}),false);assert.equal(policy.registration({...identity,verifier:crypto.randomBytes(32).toString('base64url')}),false);
});
test('malformed material fails closed',()=>{assert.throws(()=>derive(Buffer.alloc(31),{}));assert.throws(()=>derive(Buffer.alloc(32),{requestId:'x',verifier:'x',clientRequestId:'x'}));});
