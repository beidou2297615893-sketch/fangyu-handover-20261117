'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),crypto=require('node:crypto');
const {verifySignedQuery,runOfflineFixture}=require('./query-verifier');
const keys=crypto.generateKeyPairSync('rsa',{modulusLength:2048,privateKeyEncoding:{type:'pkcs8',format:'pem'},publicKeyEncoding:{type:'spki',format:'pem'}});
const base='{"code":"10000","out_trade_no":"test-order","trade_no":"test-trade","total_amount":"1.00","trade_status":"TRADE_SUCCESS"}';
function wrap(body=base,{method='alipay_trade_query_response',algorithm='RSA-SHA256'}={}){
  const sig=crypto.sign(algorithm,Buffer.from(body),keys.privateKey).toString('base64');return `{"${method}":${body},"sign":"${sig}"}`;
}
test('actual SDK processes only after strict verification of the query raw response',async()=>{
  const result=await runOfflineFixture({raw:wrap(),privateKey:keys.privateKey,publicKey:keys.publicKey});
  assert.equal(result.trade_no,'test-trade');
});
test('requires a nonempty RSA key of sufficient size',()=>{
  assert.throws(()=>verifySignedQuery(wrap(),''));
  const weak=crypto.generateKeyPairSync('rsa',{modulusLength:1024,publicKeyEncoding:{type:'spki',format:'pem'},privateKeyEncoding:{type:'pkcs8',format:'pem'}});
  assert.throws(()=>verifySignedQuery(wrap(),weak.publicKey));
});
test('detects altered body, sha1, invalid, missing and multiple signatures',()=>{
  for(const raw of [wrap().replace('1.00','9.00'),wrap(base,{algorithm:'RSA-SHA1'}),'{"alipay_trade_query_response":'+base+'}',wrap().replace('"sign":','"sign":"fake","sign":')])
    assert.throws(()=>verifySignedQuery(raw,keys.publicKey));
});
test('detects duplicates including escaped, nested, and wrong method',()=>{
  const cases=[
    wrap(base.replace('"total_amount":"1.00"','"total_amount":"1.00","total_amount":"9.00"')),
    wrap(base.replace('"code":"10000"','"code":"10000","co\\u0064e":"10000"')),
    wrap(base.replace('"code":"10000"','"code":"10000","nested":{"x":1,"x":2}')),
    wrap(base,{method:'alipay_trade_other_response'})
  ];for(const raw of cases)assert.throws(()=>verifySignedQuery(raw,keys.publicKey));
});
test('verifies exact signed slice with unicode, escapes, nested arrays and braces in strings',()=>{
  const payload=JSON.stringify({code:'10000',out_trade_no:'test-order',trade_no:'test-trade',note:'中文😀 } " \\',nested:[{content:'},"sign":"fake"'}]});
  assert.deepEqual(verifySignedQuery(' \n'+wrap(payload)+' \t',keys.publicKey),JSON.parse(payload));
});
test('rejects malformed, comments, trailing comma, oversized and extra envelope fields',()=>{
  for(const raw of [wrap()+'{}',wrap().replace('{"code"','{/*x*/"code"'),wrap().replace('"10000",','"10000",,'),wrap().replace(/}$/,',"extra":1}'),wrap()+' '.repeat(262145)]){
    assert.throws(()=>verifySignedQuery(raw,keys.publicKey));
  }
});
test('SDK seam refuses tampered, duplicate, missing-key and wrong-method results before returning data',async()=>{
  for(const [raw,publicKey] of [
    [wrap().replace('1.00','9.00'),keys.publicKey],
    [wrap(base.replace('"total_amount":"1.00"','"total_amount":"1.00","total_amount":"9.00"')),keys.publicKey],
    [wrap(),''],[wrap(base,{method:'alipay_trade_other_response'}),keys.publicKey]
  ])await assert.rejects(runOfflineFixture({raw,privateKey:keys.privateKey,publicKey}));
});
