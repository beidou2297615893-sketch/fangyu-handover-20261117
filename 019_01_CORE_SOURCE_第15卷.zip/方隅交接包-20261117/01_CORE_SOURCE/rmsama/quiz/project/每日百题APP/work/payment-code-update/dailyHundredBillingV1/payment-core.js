'use strict';
// Internal SDK-backed building block only. No public server mounts this file.
// Production service factory remains unconditionally disabled until account,
// refunds and trusted native admission are actually implemented and reviewed.
const crypto=require('node:crypto');
const {AlipaySdk}=require('alipay-sdk');
const {verifySignedResponse}=require('./query-verifier');
const {createInternalRunCore}=require('./payment-runs');
const {createWalletIO}=require('./payment-wallet');
const COLLECTION='daily_hundred_payment_v1',GATEWAY='https://openapi.alipay.com/gateway.do';
const PLANS=Object.freeze({once:{fen:100,amount:'1.00',credits:1,days:0},week:{fen:590,amount:'5.90',credits:0,days:7},month:{fen:990,amount:'9.90',credits:0,days:30}});
const RATE_DEFAULTS=Object.freeze({orderOwnerMinute:10,orderGlobalMinute:300,orderOwnerDay:100,orderGlobalDay:5000,replayOwnerMinute:60,replayGlobalMinute:1200,replayOwnerDay:1000,replayGlobalDay:50000,queryOwnerMinute:30,queryGlobalMinute:600,queryOwnerDay:500,queryGlobalDay:20000});
const sha=value=>crypto.createHash('sha256').update(value,'utf8').digest('hex');
const check=v=>{if(!v)throw Error('payment operation unavailable');};
function secureUrl(value){const u=new URL(value);return u.protocol==='https:'&&!u.username&&!u.password&&!u.hash&&!u.search;}
function createProductionService(){throw Error('production payment service is disabled');}

// Not exported as an HTTP handler. Its caller must already be trusted. Supplying
// verified owners/merchant config from client input would make this unsafe.
function createInternalCore({db,appId,sellerId,privateKey,publicKey,notifyUrl,returnUrl,clock=Date.now,rateLimits={}}){
  check(db&&typeof db.runTransaction==='function');
  check(typeof clock==='function'&&rateLimits&&typeof rateLimits==='object'&&!Array.isArray(rateLimits)&&Object.keys(rateLimits).every(k=>Object.hasOwn(RATE_DEFAULTS,k)));
  const limits={...RATE_DEFAULTS,...rateLimits};check(Object.values(limits).every(v=>Number.isSafeInteger(v)&&v>0));
  check(typeof appId==='string'&&/^[A-Za-z0-9_-]{1,64}$/.test(appId)&&typeof sellerId==='string'&&/^[A-Za-z0-9_-]{1,64}$/.test(sellerId));
  check(typeof privateKey==='string'&&typeof publicKey==='string'&&publicKey.includes('-----BEGIN PUBLIC KEY-----'));
  const publicKeyObject=crypto.createPublicKey(publicKey);
  check(publicKeyObject.asymmetricKeyType==='rsa'&&publicKeyObject.asymmetricKeyDetails?.modulusLength>=2048&&secureUrl(notifyUrl)&&secureUrl(returnUrl));
  const sdk=new AlipaySdk({appId,privateKey,alipayPublicKey:publicKey,keyType:'PKCS8',signType:'RSA2',camelcase:false,gateway:GATEWAY});
  sdk.checkResponseSign=(raw,key)=>{check(['alipay_trade_query_response','alipay_trade_fastpay_refund_query_response'].includes(key));verifySignedResponse(raw,publicKey,key);};
  // Use a separate SDK instance for each query. Its verifier flag is local to
  // the call, so concurrent requests cannot lend each other a verified result.
  async function verifiedTradeQuery(orderId){
    let verified=false;
    const querySdk=new AlipaySdk({appId,privateKey,alipayPublicKey:publicKey,keyType:'PKCS8',signType:'RSA2',camelcase:false,gateway:GATEWAY});
    querySdk.checkResponseSign=(raw,key)=>{check(key==='alipay_trade_query_response');verifySignedResponse(raw,publicKey,key);verified=true;};
    const result=await querySdk.exec('alipay.trade.query',{bizContent:{outTradeNo:orderId}},{validateSign:true});
    check(verified&&result&&result.code==='10000'&&result.out_trade_no===orderId);
    if(Object.hasOwn(result,'app_id'))check(result.app_id===appId);
    if(Object.hasOwn(result,'seller_id'))check(result.seller_id===sellerId);
    return result;
  }
  function codeResponse(r){if(r?.code==='DATABASE_TRANSACTION_CONFLICT')throw Object.assign(Error('conflict'),{code:r.code});check(r&&!r.code);return r;}
  async function read(ref,id){const r=codeResponse(await ref.get());check(Object.hasOwn(r,'data'));if(r.data===null)return null;check(r.data&&typeof r.data==='object'&&!Array.isArray(r.data)&&r.data._id===id);const {_id,...row}=r.data;return row;}
  async function write(ref,id,row){const r=codeResponse(await ref.set(row));check(r.updated===1||(r.updated===0&&Array.isArray(r.upserted)&&r.upserted.some(v=>v?._id===id)));}
  // Transactional, fixed-size per-owner and shared counters. Callback-driven
  // settlement never calls this guard: a valid provider notification must not
  // be blocked by user-initiated traffic. Expired windows reuse the same docs.
  async function limit(c,kind,owner,now){
    check(['order','replay','query'].includes(kind)&&Number.isSafeInteger(now)&&now>=0);
    const minute=Math.floor(now/60000),day=Math.floor(now/86400000);
    for(const scope of ['global','owner']){
      const id='traffic-'+kind+'-'+(scope==='global'?'global':sha(owner)),ref=c.doc(id),old=await read(ref,id);
      if(old)check(old.kind==='traffic'&&old.action===kind&&old.scope===scope&&Number.isSafeInteger(old.minute)&&Number.isSafeInteger(old.day)&&Number.isSafeInteger(old.minuteCount)&&Number.isSafeInteger(old.dayCount)&&old.minuteCount>=0&&old.dayCount>=0&&old.minute<=minute&&old.day<=day);
      const minuteCount=old&&old.minute===minute?old.minuteCount:0,dayCount=old&&old.day===day?old.dayCount:0;
      const prefix=kind+(scope==='global'?'Global':'Owner');check(minuteCount<limits[prefix+'Minute']&&dayCount<limits[prefix+'Day']);
      await write(ref,id,{kind:'traffic',action:kind,scope,minute,day,minuteCount:minuteCount+1,dayCount:dayCount+1});
    }
  }
  const wallet=createWalletIO({read,write});
  async function createOrder(owner,requestId,plan){
    try{
      check(typeof owner==='string'&&/^[A-Za-z0-9_-]{1,128}$/.test(owner)&&typeof requestId==='string'&&/^[A-Za-z0-9_-]{1,64}$/.test(requestId)&&Object.hasOwn(PLANS,plan));
      const now=clock();check(Number.isSafeInteger(now)&&now>=0);
      const orderId='o'+sha(JSON.stringify([owner,requestId])).slice(0,63),docId='order-'+orderId;
      const row=await db.runTransaction(async tx=>{
        const c=tx.collection(COLLECTION),ref=c.doc(docId),previous=await read(ref,docId);
        if(previous){check(previous.owner===owner&&previous.plan===plan&&previous.amountFen===PLANS[plan].fen);await limit(c,'replay',owner,now);return previous;}
        await limit(c,'order',owner,now);
        const created={kind:'order',orderId,owner,requestId,plan,amountFen:PLANS[plan].fen,status:'pending'};
        await write(ref,docId,created);return created;
      },3);
      // Do not recreate a checkout URL for a settled/review order.
      if(row.status!=='pending')return {id:orderId,status:row.status,amountFen:row.amountFen};
      const checkoutUrl=sdk.pageExec('alipay.trade.wap.pay','GET',{notifyUrl,returnUrl,bizContent:{outTradeNo:orderId,subject:'答题服务',totalAmount:PLANS[plan].amount,productCode:'QUICK_WAP_WAY'}});
      return {id:orderId,status:row.status,amountFen:row.amountFen,checkoutUrl};
    }catch{throw Error('payment operation unavailable');}
  }
  async function readOrder(owner,orderId){
    try{
      check(typeof owner==='string'&&typeof orderId==='string'&&/^o[a-f0-9]{63}$/.test(orderId));
      const id='order-'+orderId,row=await db.runTransaction(tx=>read(tx.collection(COLLECTION).doc(id),id),3);
      check(row&&row.owner===owner);return {id:row.orderId,planId:row.plan,status:row.status,amountFen:row.amountFen};
    }catch{throw Error('payment operation unavailable');}
  }
  async function entitlements(owner){
    try{
      check(typeof owner==='string'&&/^[A-Za-z0-9_-]{1,128}$/.test(owner));
      return await db.runTransaction(async tx=>{
        const account=await wallet.load(tx.collection(COLLECTION),owner),credits=account.creditAvailable+account.creditReserved;
        check(Number.isSafeInteger(credits));
        return {runCredits:credits,validUntil:account.memberFrozen||!account.memberUntil?null:Math.floor(account.memberUntil/1000),revision:account.revision,recoverySupported:false,requiresReview:account.reviewCount>0||account.memberNeedsReview};
      },3);
    }catch{throw Error('payment operation unavailable');}
  }
  async function reconcileOrder(owner,orderId){
    const current=await readOrder(owner,orderId);
    if(current.status!=='pending')return current;
    try{
      const now=clock();check(Number.isSafeInteger(now)&&now>=0);
      await db.runTransaction(async tx=>limit(tx.collection(COLLECTION),'query',owner,now),3);
      // Prefer a previously verified callback. If it was lost, an independently
      // verified provider query can recover the exact merchant-owned order.
      const oid='order-'+orderId,nid='notice-'+orderId;
      const notice=await db.runTransaction(async tx=>{
        const c=tx.collection(COLLECTION),order=await read(c.doc(oid),oid),record=await read(c.doc(nid),nid);
        check(order&&order.owner===owner&&order.status==='pending');
        return record;
      },3);
      if(notice){
        check(notice.kind==='verified-success-notice'&&notice.orderId===orderId&&notice.owner===owner);
        await settleVerifiedNotice(notice);
      }else{
        const q=await verifiedTradeQuery(orderId);
        check(q.seller_id===sellerId&&typeof q.trade_no==='string'&&/^[A-Za-z0-9_-]{1,64}$/.test(q.trade_no));
        check(q.total_amount===PLANS[current.planId].amount&&['TRADE_SUCCESS','TRADE_FINISHED','TRADE_CLOSED'].includes(q.trade_status));
        if(q.trade_status==='TRADE_CLOSED')await markVerifiedClosed({orderId,tradeNo:q.trade_no,totalAmount:q.total_amount});
        else await grantVerifiedTrade({orderId,owner,tradeNo:q.trade_no,totalAmount:q.total_amount},false);
      }
    }catch{/* Retain the authenticated stored state; do not invent payment. */}
    return readOrder(owner,orderId);
  }
  async function storeVerifiedNotice(fields){
    const oid='order-'+fields.out_trade_no,nid='notice-'+fields.out_trade_no;
    return db.runTransaction(async tx=>{
      const c=tx.collection(COLLECTION),order=await read(c.doc(oid),oid),ref=c.doc(nid),existing=await read(ref,nid);
      check(order&&order.orderId===fields.out_trade_no&&Object.hasOwn(PLANS,order.plan)&&order.amountFen===PLANS[order.plan].fen&&fields.total_amount===PLANS[order.plan].amount);
      check(['pending','paid'].includes(order.status));
      const notice={kind:'verified-success-notice',orderId:order.orderId,owner:order.owner,tradeNo:fields.trade_no,totalAmount:fields.total_amount};
      if(existing){check(existing.kind===notice.kind&&existing.orderId===notice.orderId&&existing.owner===notice.owner&&existing.tradeNo===notice.tradeNo&&existing.totalAmount===notice.totalAmount);return existing;}
      await write(ref,nid,notice);return notice;
    },3);
  }
  async function settleVerifiedNotice(notice){
    const {orderId,owner,tradeNo,totalAmount}=notice;
    // Network query remains outside the retryable database transaction.
    const query=await verifiedTradeQuery(orderId);
    check(query.trade_no===tradeNo&&query.total_amount===totalAmount&&['TRADE_SUCCESS','TRADE_FINISHED'].includes(query.trade_status));
    return grantVerifiedTrade(notice,true);
  }
  // Private closure: evidence can only reach here after verifiedTradeQuery.
  async function grantVerifiedTrade({orderId,owner,tradeNo,totalAmount},requireNotice){
    const oid='order-'+orderId,tid='trade-'+sha(tradeNo),gid='grant-'+orderId,nid='notice-'+orderId;
    const grantedAt=Date.now();
    return db.runTransaction(async tx=>{
      const c=tx.collection(COLLECTION),orderRef=c.doc(oid),tradeRef=c.doc(tid),grantRef=c.doc(gid);
      const order=await read(orderRef,oid),trade=await read(tradeRef,tid),grant=await read(grantRef,gid),stored=await read(c.doc(nid),nid);
      if(requireNotice)check(stored);
      if(stored)check(stored.kind==='verified-success-notice'&&stored.orderId===orderId&&stored.owner===owner&&stored.tradeNo===tradeNo&&stored.totalAmount===totalAmount);
      check(order&&order.owner===owner&&order.orderId===orderId&&Object.hasOwn(PLANS,order.plan)&&order.amountFen===PLANS[order.plan].fen&&totalAmount===PLANS[order.plan].amount);
      const account=await wallet.load(c,order.owner);
      check(!trade||trade.orderId===order.orderId);
      if(order.status==='paid'){check(trade&&grant&&grant.owner===order.owner&&grant.tradeNo===tradeNo&&grant.state==='paid');return {status:'paid'};}
      check(order.status==='pending'&&!trade&&!grant);
      const newGrant={kind:'grant',orderId:order.orderId,owner:order.owner,tradeNo,plan:order.plan,state:'paid',credits:PLANS[order.plan].credits,days:PLANS[order.plan].days,grantedAt,used:0,reserved:0,prev:null,next:null};
      if(order.plan==='once')await wallet.appendCredit(c,account,newGrant);
      else {
        if(account.memberFrozen){account.memberUntil=grantedAt;account.memberFrozen=false;}
        account.memberUntil=Math.max(account.memberUntil,grantedAt)+PLANS[order.plan].days*86400000;check(Number.isSafeInteger(account.memberUntil));
      }
      await write(orderRef,oid,{...order,status:'paid'});
      await write(tradeRef,tid,{kind:'trade',orderId:order.orderId,tradeNo});
      await wallet.saveGrant(c,newGrant);await wallet.save(c,account);
      return {status:'paid'};
    },3);
  }
  // Offline/internal candidate for detecting a closed paid trade after a missed
  // callback. A successful trade query does not prove absence of partial refunds.
  async function auditPaidTrade(owner,orderId){
    try{
      check(typeof owner==='string'&&/^[A-Za-z0-9_-]{1,128}$/.test(owner)&&typeof orderId==='string'&&/^o[a-f0-9]{63}$/.test(orderId));
      const oid='order-'+orderId;
      const original=await db.runTransaction(async tx=>{
        const c=tx.collection(COLLECTION),order=await read(c.doc(oid),oid);
        check(order&&order.owner===owner&&order.orderId===orderId&&Object.hasOwn(PLANS,order.plan)&&order.amountFen===PLANS[order.plan].fen&&['paid','review','refunded'].includes(order.status));
        const grant=await wallet.loadGrant(c,owner,orderId);
        check(typeof grant.tradeNo==='string'&&/^[A-Za-z0-9_-]{1,64}$/.test(grant.tradeNo));
        return {status:order.status,plan:order.plan,tradeNo:grant.tradeNo};
      },3);
      if(original.status!=='paid')return {status:original.status,partialRefundVisibility:'unknown'};
      const query=await sdk.exec('alipay.trade.query',{bizContent:{outTradeNo:orderId}},{validateSign:true});
      check(query&&query.code==='10000'&&query.out_trade_no===orderId&&query.trade_no===original.tradeNo&&query.total_amount===PLANS[original.plan].amount&&['TRADE_SUCCESS','TRADE_FINISHED','TRADE_CLOSED'].includes(query.trade_status));
      if(query.trade_status==='TRADE_CLOSED'){
        return await db.runTransaction(async tx=>{
          const c=tx.collection(COLLECTION),ref=c.doc(oid),order=await read(ref,oid),grant=await wallet.loadGrant(c,owner,orderId);
          check(order&&order.owner===owner&&order.orderId===orderId&&order.plan===original.plan&&order.amountFen===PLANS[original.plan].fen&&grant.tradeNo===original.tradeNo);
          check(['paid','review','refunded'].includes(order.status));
          if(order.status!=='paid')return {status:order.status,partialRefundVisibility:'unknown'};
          check(grant.state==='paid');
          const account=await wallet.load(c,owner);await wallet.freeze(c,account,grant);
          await wallet.saveGrant(c,grant);await wallet.save(c,account);await write(ref,oid,{...order,status:'review'});
          return {status:'review',partialRefundVisibility:'unknown'};
        },3);
      }
      return {status:(await readOrder(owner,orderId)).status,partialRefundVisibility:'unknown'};
    }catch{throw Error('payment operation unavailable');}
  }
  // Called only after an authenticated notification or a signed provider query.
  // The transaction keeps a concurrent payment from being silently discarded.
  async function markVerifiedClosed({orderId,tradeNo,totalAmount}){
    const oid='order-'+orderId,gid='grant-'+orderId;
    return db.runTransaction(async tx=>{
      const c=tx.collection(COLLECTION),orderRef=c.doc(oid),order=await read(orderRef,oid);
      check(order&&order.orderId===orderId&&Object.hasOwn(PLANS,order.plan)&&order.amountFen===PLANS[order.plan].fen&&totalAmount===PLANS[order.plan].amount);
      if(order.status==='pending'){
        const tid='trade-'+sha(tradeNo),trade=await read(c.doc(tid),tid),grant=await read(c.doc(gid),gid);check(!trade&&!grant);
        await write(orderRef,oid,{...order,status:'cancelled',closedTradeNo:tradeNo});return {status:'cancelled'};
      }
      if(order.status==='cancelled'){check(order.closedTradeNo===tradeNo);return {status:'cancelled'};}
      check(['paid','review','refunded'].includes(order.status));const grant=await wallet.loadGrant(c,order.owner,order.orderId);
      check(grant.tradeNo===tradeNo);if(order.status==='refunded')return {status:'refunded'};if(order.status==='review')return {status:'review'};
      const account=await wallet.load(c,order.owner);await wallet.freeze(c,account,grant);await wallet.saveGrant(c,grant);await wallet.save(c,account);
      await write(orderRef,oid,{...order,status:'review'});return {status:'review'};
    },3);
  }
  async function notify(form){
    try{
      check(typeof form==='string'&&Buffer.byteLength(form)<=32768);
      const fields=Object.create(null);let n=0;
      for(const [k,v] of new URLSearchParams(form)){check(++n<=100&&!Object.hasOwn(fields,k)&&v.length<=8192);fields[k]=v;}
      check(fields.sign_type==='RSA2'&&fields.app_id===appId&&fields.seller_id===sellerId&&['TRADE_SUCCESS','TRADE_FINISHED','TRADE_CLOSED'].includes(fields.trade_status));
      check(typeof fields.out_trade_no==='string'&&/^o[a-f0-9]{63}$/.test(fields.out_trade_no)&&typeof fields.trade_no==='string'&&/^[A-Za-z0-9_-]{1,64}$/.test(fields.trade_no));
      check(typeof fields.total_amount==='string'&&/^(?:0|[1-9][0-9]{0,6})\.[0-9]{2}$/.test(fields.total_amount)&&sdk.checkNotifySignV2(fields));
      if(fields.trade_status==='TRADE_CLOSED'){
        const oid='order-'+fields.out_trade_no;
        const before=await db.runTransaction(async tx=>read(tx.collection(COLLECTION).doc(oid),oid),3);
        check(before&&before.orderId===fields.out_trade_no&&Object.hasOwn(PLANS,before.plan)&&before.amountFen===PLANS[before.plan].fen&&fields.total_amount===PLANS[before.plan].amount);
        if(before.status==='pending'){
          const q=await verifiedTradeQuery(fields.out_trade_no);
          check(q.trade_status==='TRADE_CLOSED'&&q.trade_no===fields.trade_no&&q.total_amount===fields.total_amount);
        }
        return await markVerifiedClosed({orderId:fields.out_trade_no,tradeNo:fields.trade_no,totalAmount:fields.total_amount});
      }
      // Persist only minimal authenticated fields, not the full callback or PII.
      return await settleVerifiedNotice(await storeVerifiedNotice(fields));
    }catch{throw Error('payment operation unavailable');}
  }
  // Trusted internal caller only: this records and queries a known refund; it
  // does not create a refund or discover refunds made outside this service.
  async function reviewRefund(owner,orderId,requestId){
    try{
      check(typeof owner==='string'&&/^[A-Za-z0-9_-]{1,128}$/.test(owner)&&typeof orderId==='string'&&/^o[a-f0-9]{63}$/.test(orderId)&&typeof requestId==='string'&&/^[A-Za-z0-9_-]{1,64}$/.test(requestId));
      const oid='order-'+orderId,gid='grant-'+orderId,rid='refund-'+sha(JSON.stringify([orderId,requestId])),accountId='account-'+sha(owner);
      const held=await db.runTransaction(async tx=>{
        const c=tx.collection(COLLECTION),oref=c.doc(oid),rref=c.doc(rid);
        const order=await read(oref,oid),grant=await wallet.loadGrant(c,owner,orderId),existing=await read(rref,rid),account=await wallet.load(c,owner);
        check(order&&order.owner===owner);
        if(existing){check(existing.orderId===orderId&&existing.requestId===requestId);if(existing.status==='confirmed')return {done:true,status:order.status};check(existing.status==='pending');}
        check(['paid','review'].includes(order.status));
        await wallet.freeze(c,account,grant);
        await write(oref,oid,{...order,status:'review'});await wallet.saveGrant(c,grant);await wallet.save(c,account);
        if(!existing)await write(rref,rid,{kind:'refund',orderId,requestId,status:'pending'});
        return {done:false,tradeNo:grant.tradeNo,amountFen:order.amountFen};
      },3);
      if(held.done)return {status:held.status};
      const result=await sdk.exec('alipay.trade.fastpay.refund.query',{bizContent:{outTradeNo:orderId,outRequestNo:requestId}},{validateSign:true});
      check(result&&result.code==='10000'&&result.out_trade_no===orderId&&result.out_request_no===requestId&&result.trade_no===held.tradeNo&&result.refund_status==='REFUND_SUCCESS');
      check(typeof result.refund_amount==='string'&&/^(?:0|[1-9][0-9]{0,6})\.[0-9]{2}$/.test(result.refund_amount));
      const [yuan,cents]=result.refund_amount.split('.'),amountFen=Number(yuan)*100+Number(cents);
      check(Number.isSafeInteger(amountFen)&&amountFen>0&&amountFen<=held.amountFen);
      return await db.runTransaction(async tx=>{
        const c=tx.collection(COLLECTION),oref=c.doc(oid),rref=c.doc(rid);
        const order=await read(oref,oid),grant=await wallet.loadGrant(c,owner,orderId),refund=await read(rref,rid),account=await wallet.load(c,owner);
        check(order&&order.owner===owner&&grant.tradeNo===held.tradeNo&&refund&&refund.orderId===orderId&&refund.requestId===requestId);
        if(refund.status==='confirmed')return {status:order.status};
        check(refund.status==='pending'&&order.status==='review'&&grant.state==='review');
        const total=(order.refundedFen||0)+amountFen;check(Number.isSafeInteger(total)&&total<=order.amountFen);
        const status=total===order.amountFen?'refunded':'review';
        grant.state=status;
        await write(oref,oid,{...order,status,refundedFen:total});await wallet.saveGrant(c,grant);
        await wallet.save(c,account);await write(rref,rid,{...refund,status:'confirmed',amountFen});
        return {status};
      },3);
    }catch{throw Error('payment operation unavailable');}
  }
  const runs=createInternalRunCore({db});
  return Object.freeze({admissionPolicy:'paid-only',createOrder,readOrder,entitlements,reconcileOrder,notify,reviewRefund,auditPaidTrade,reserveRun:runs.reserve,cancelRun:runs.cancel,confirmRun:runs.confirm,releaseRun:runs.release,confirmStoredRun:runs.confirmStored,releaseStoredRun:runs.releaseStored,listActiveRuns:runs.listActive,authorizeContinueRun:runs.authorizeContinue});
}
module.exports={createProductionService,createInternalCore};
