from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
root=Path(__file__).resolve().parents[2]/'outputs/official-website/frontend/dist'
class Handler(SimpleHTTPRequestHandler):
    def __init__(self,*a,**kw): super().__init__(*a,directory=str(root),**kw)
    def do_GET(self):
        if self.path.split('?')[0] in ['/plans','/checkout','/guide','/privacy','/download']: self.path='/index.html'
        return super().do_GET()
ThreadingHTTPServer(('127.0.0.1',18831),Handler).serve_forever()
