'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const {main} = require('./dailyHundredUrlFormatProbeV1/index.js');
const fixture = () => ({httpMethod:'POST',path:'/__probe__/form',headers:{'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Probe-Fixture':'fixture123'},body:'probe_id=fixture123&value=alpha%2Bbeta'});
test('synthetic raw form, path, method and headers are individually verified', async () => {
  const result = await main(fixture());
  assert.equal(result.statusCode,200);
  assert.deepEqual(JSON.parse(result.body),{paymentEnabled:false,checks:{method:true,path:true,contentType:true,fixtureHeader:true,rawBody:true}});
});
test('bad body or missing method/path/header never passes, and input is never reflected', async () => {
  for (const patch of [{body:'probe_id=fixture123&value=alpha+beta'}, {body:'PRIVATE-TEST-SECRET'}, {path:'/other'}, {httpMethod:'GET'}, {headers:{}}, {headers:{'Content-Type':'application/x-www-form-urlencoded','content-type':'text/plain','x-probe-fixture':'fixture123'}}]) {
    const result = await main({...fixture(),...patch});
    assert.equal(result.statusCode,503);
    assert.equal(result.body.includes('PRIVATE-TEST-SECRET'),false);
    assert.equal(Object.values(JSON.parse(result.body).checks).includes(false),true);
  }
});
