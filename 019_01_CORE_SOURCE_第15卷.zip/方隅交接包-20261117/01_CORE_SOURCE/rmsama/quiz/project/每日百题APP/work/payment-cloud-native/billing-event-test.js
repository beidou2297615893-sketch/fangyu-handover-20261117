'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict'),crypto=require('node:crypto');
const {Db}=require('../../outputs/managed-import-cloudbase/node_modules/@cloudbase/database/dist/commonjs/index.js');
const {EJSON}=require('../../outputs/managed-import-cloudbase/node_modules/bson');
const urllib=require('urllib').default;
const {main,createInternalRuntime}=require('./runtime');
const PATH='/api/billing',A='A'.repeat(43),B='B'.repeat(43),binding='a'.repeat(64);
function fixture(migration=true,legacyOverride=true,recovery=true){
  const key=crypto.generateKeyPairSync('rsa',{modulusLength:2048,privateKeyEncoding:{type:'pkcs8',format:'pem'},publicKeyEncoding:{type:'spki',format:'pem'}});
  const state={docs:new Map(),txs:new Map(),version:0,n:0,response:null,paymentResponse:null};const previous=Db.reqClass,oldRequest=urllib.request;
  state.docs.set('daily_hundred_installation_v1:policy',{kind:'policy',schema:1,enabled:true});
  Db.reqClass=class{async send(action,p={}){
    if(action==='database.startTransaction'){const transactionId='t'+(++state.n);state.txs.set(transactionId,{docs:structuredClone(state.docs),version:state.version});return {transactionId};}
    if(action==='database.abortTransaction'){state.txs.delete(p.transactionId);return {};}
    if(action==='database.commitTransaction'){const tx=state.txs.get(p.transactionId);if(tx.version!==state.version)return {code:'DATABASE_TRANSACTION_CONFLICT'};state.docs=tx.docs;state.version++;state.txs.delete(p.transactionId);return {};}
    assert.ok(['daily_hundred_oauth_v1','daily_hundred_oauth_binding_v1','daily_hundred_payment_v1','daily_hundred_installation_v1'].includes(p.collectionName));
    const tx=state.txs.get(p.transactionId),id=JSON.parse(p.query)._id,k=p.collectionName+':'+id;
    if(action==='database.getDocument')return {data:{list:tx.docs.has(k)?[JSON.stringify({_id:id,...tx.docs.get(k)})]:[]}};
    if(action==='database.modifyDocument'){tx.docs.set(k,EJSON.parse(p.data));return {data:{updated:1,upsert_id:id}};}
    throw Error('unexpected');
  }};
  urllib.request=async(url)=>{const u=new URL(url);assert.equal(u.hostname,'openapi.alipay.com');return {status:200,headers:{},data:u.searchParams.get('method')==='alipay.trade.query'?state.paymentResponse:state.response};};
  const settings={appId:'test-app',sellerId:'test-seller',privateKey:key.privateKey,publicKey:key.publicKey,notifyUrl:'https://example.invalid/notify',returnUrl:'https://example.invalid/return',identityKey:'I'.repeat(64),credentialKey:'C'.repeat(64),registrationKey:'R'.repeat(64),oauthRedirectUrl:'https://example.invalid/oauth/callback'};
  const runtime=createInternalRuntime({db:new Db({throwOnCode:true}),settings,recoveryEnabledForOfflineTest:recovery,...(legacyOverride?{authenticateInstallation:async token=>{if(token===A)return 'ownerA';if(token===B)return 'ownerB';throw Error('unavailable');}}:{}),verifyTaskBinding:migration?async(owner,runId,b)=>owner==='ownerA'&&b===binding:undefined});
  function event(path,method='GET',value,token){return {path:PATH+path,httpMethod:method,headers:{...(value!==undefined?{'content-type':'application/json'}:{}),...(token?{authorization:'Bearer '+token}:{})},body:value===undefined?'':JSON.stringify(value)};}
  async function call(path,method,value,token){return runtime(event(path,method,value,token));}
  function signIdentity(openId){const payload=JSON.stringify({open_id:openId,access_token:'[REDACTED:assigned_secret]'}),signature=crypto.sign('RSA-SHA256',Buffer.from(payload),key.privateKey).toString('base64');state.response=`{"alipay_system_oauth_token_response":${payload},"sign":"${signature}"}`;}
  async function authorize(openId,code){
    const verifier=crypto.randomBytes(32).toString('base64url'),requestId=crypto.randomBytes(32).toString('base64url'),verifierHash=crypto.createHash('sha256').update(verifier).digest('hex');
    const start=await call('/oauth/start','POST',{requestId,verifierHash});assert.equal(start.statusCode,200);const s=JSON.parse(start.body);signIdentity(openId);
    const callback=event('/oauth/callback');callback.rawQueryString=new URLSearchParams({state:s.state,auth_code:code}).toString();assert.equal((await runtime(callback)).statusCode,200);
    return {state:s.state,verifier};
  }
  async function pay(token){
    const r=await call('/orders','POST',{planId:'once',clientRequestId:'paid-test'},token);assert.equal(r.statusCode,201);const order=JSON.parse(r.body);
    const fields={app_id:'test-app',seller_id:'test-seller',out_trade_no:order.id,trade_no:'trade-local',total_amount:'1.00',trade_status:'TRADE_SUCCESS',sign_type:'RSA2'};
    const signed=Object.keys(fields).filter(k=>k!=='sign_type').sort().map(k=>k+'='+fields[k]).join('&');fields.sign=crypto.sign('RSA-SHA256',Buffer.from(signed),key.privateKey).toString('base64');
    const payload=JSON.stringify({code:'10000',out_trade_no:order.id,trade_no:'trade-local',total_amount:'1.00',trade_status:'TRADE_SUCCESS'}),signature=crypto.sign('RSA-SHA256',Buffer.from(payload),key.privateKey).toString('base64');
    state.paymentResponse=`{"alipay_trade_query_response":${payload},"sign":"${signature}"}`;
    const result=await runtime({path:PATH+'/alipay/notify',httpMethod:'POST',headers:{'content-type':'application/x-www-form-urlencoded'},body:new URLSearchParams(fields).toString()});assert.equal(result.statusCode,200);
  }
  function querySuccess(orderId,overrides={}){const payload=JSON.stringify({code:'10000',out_trade_no:orderId,trade_no:'trade-local',total_amount:'1.00',trade_status:'TRADE_SUCCESS',...overrides}),signature=crypto.sign('RSA-SHA256',Buffer.from(payload),key.privateKey).toString('base64');state.paymentResponse=`{"alipay_trade_query_response":${payload},"sign":"${signature}"}`;}
  return {call,authorize,pay,querySuccess,state,close(){Db.reqClass=previous;urllib.request=oldRequest;}};
}
test('production entry is closed without CloudBase or secret access',async()=>{
  const result=await main({path:PATH+'/status',httpMethod:'GET'});assert.equal(result.statusCode,503);assert.equal(JSON.parse(result.body).realPaymentsEnabled,false);
});
test('browser return page is static and never trusts or echoes payment results',async()=>{
  const f=fixture(true,false,false);try{
    const returned=await f.call('/alipay/return','GET');assert.equal(returned.statusCode,200);
    assert.match(returned.headers['content-type'],/^text\/html/);assert.match(returned.body,/dailyhundredapp:\/\/\/payment-return/);
    assert.ok(!returned.body.includes('TRADE_SUCCESS'));
  }finally{f.close();}
});
test('recovery routes remain closed unless explicitly enabled for offline tests',async()=>{
  const f=fixture(true,false,false);try{
    const requestId=crypto.randomBytes(32).toString('base64url'),verifierHash=crypto.randomBytes(32).toString('hex');
    assert.equal((await f.call('/oauth/start','POST',{requestId,verifierHash})).statusCode,503);
    assert.equal((await f.call('/oauth/restore','POST',{state:requestId,verifier:requestId})).statusCode,503);
  }finally{f.close();}
});
test('direct payment without recovery never initializes or reads OAuth configuration',async()=>{
  const keys=crypto.generateKeyPairSync('rsa',{modulusLength:2048,privateKeyEncoding:{type:'pkcs8',format:'pem'},publicKeyEncoding:{type:'spki',format:'pem'}});
  const settings={appId:'test-app',sellerId:'test-seller',privateKey:keys.privateKey,publicKey:keys.publicKey,notifyUrl:'https://example.invalid/notify',returnUrl:'https://example.invalid/return',registrationKey:'R'.repeat(64)};
  for(const key of ['identityKey','credentialKey','oauthRedirectUrl'])Object.defineProperty(settings,key,{get(){throw Error('disabled OAuth config was accessed');}});
  const runtime=createInternalRuntime({db:{runTransaction:async()=>{}},settings});
  const result=await runtime({path:PATH+'/oauth/start',httpMethod:'POST',headers:{'content-type':'application/json'},body:'{}'});assert.equal(result.statusCode,503);
});
test('OAuth binding and restore gate owner; accounts and orders remain isolated',async()=>{
  const f=fixture();try{
    assert.equal((await f.call('/orders','POST',{planId:'once',clientRequestId:'r1'},A)).statusCode,503);
    const first=await f.authorize('user-A','code-A');assert.equal((await f.call('/oauth/restore','POST',first)).statusCode,503);
    assert.equal((await f.call('/oauth/bind','POST',first,'X'.repeat(43))).statusCode,503);
    const bound=JSON.parse((await f.call('/oauth/bind','POST',first,A)).body);assert.equal(bound.installationId,'ownerA');
    const created=await f.call('/orders','POST',{planId:'once',clientRequestId:'r1'},bound.accessToken);assert.equal(created.statusCode,201);const order=JSON.parse(created.body);assert.equal(order.amountFen,100);
    f.querySuccess(order.id);
    // A verified provider query recovers a missed callback for this owner only.
    assert.equal(JSON.parse((await f.call('/orders/'+order.id+'/reconcile','POST',{},bound.accessToken)).body).status,'paid');
    assert.equal(JSON.parse((await f.call('/orders/'+order.id+'/reconcile','POST',{},bound.accessToken)).body).status,'paid');
    assert.equal(JSON.parse((await f.call('/entitlements','GET',undefined,bound.accessToken)).body).runCredits,1);
    const again=await f.authorize('user-A','code-A2'),restored=JSON.parse((await f.call('/oauth/restore','POST',again)).body);
    assert.equal(restored.installationId,'ownerA');assert.equal((await f.call('/orders/'+order.id,'GET',undefined,restored.accessToken)).statusCode,200);
    const other=await f.authorize('user-B','code-B'),otherBound=JSON.parse((await f.call('/oauth/bind','POST',other,B)).body);
    assert.equal(otherBound.installationId,'ownerB');assert.equal((await f.call('/orders/'+order.id,'GET',undefined,otherBound.accessToken)).statusCode,503);
  }finally{f.close();}
});
test('authenticated paid-only receipts use stored owner/binding and verifier is mandatory',async()=>{
  const f=fixture();try{
    const auth=await f.authorize('user-A','code-A'),bound=JSON.parse((await f.call('/oauth/bind','POST',auth,A)).body);
    const bad=await f.call('/runs/reserve','POST',{runId:'run',taskBinding:binding,ownerId:'ownerB'},bound.accessToken);assert.equal(bad.statusCode,503);
    assert.equal((await f.call('/runs/reserve','POST',{runId:'run',taskBinding:binding},bound.accessToken)).statusCode,503);
    await f.pay(bound.accessToken);
    assert.equal(JSON.parse((await f.call('/entitlements','GET',undefined,bound.accessToken)).body).runCredits,1);
    const reserve=await f.call('/runs/reserve','POST',{runId:'run',taskBinding:binding},bound.accessToken);assert.equal(reserve.statusCode,200);
    assert.deepEqual(JSON.parse(reserve.body),{ownerId:'ownerA',runId:'run',taskBinding:binding,status:'reserved',source:'credit'});
    const active=await f.call('/runs/active','GET',undefined,bound.accessToken);assert.equal(JSON.parse(active.body).runs.length,1);
    const finish=await f.call('/runs/run/confirm','POST',{},bound.accessToken);assert.equal(finish.statusCode,200);assert.equal(JSON.parse(finish.body).taskBinding,binding);
    assert.equal(JSON.parse((await f.call('/entitlements','GET',undefined,bound.accessToken)).body).runCredits,0);
  }finally{f.close();}
  const blocked=fixture(false);try{
    const auth=await blocked.authorize('user-A','code-A'),bound=JSON.parse((await blocked.call('/oauth/bind','POST',auth,A)).body);
    await blocked.pay(bound.accessToken);
    assert.equal((await blocked.call('/runs/reserve','POST',{runId:'run',taskBinding:binding},bound.accessToken)).statusCode,503);
  }finally{blocked.close();}
});
test('first install may order before optional OAuth; binding and restore preserve the same owner',async()=>{
  const f=fixture(true,false);try{
    const requestId=crypto.randomBytes(32).toString('base64url'),verifier=crypto.randomBytes(32).toString('base64url');
    const initial=await f.call('/installations','POST',{requestId,verifier});assert.equal(initial.statusCode,201);const installed=JSON.parse(initial.body);
    const retry=await f.call('/installations','POST',{requestId,verifier});assert.deepEqual(JSON.parse(retry.body),installed);
    assert.equal((await f.call('/installations','POST',{requestId,verifier:crypto.randomBytes(32).toString('base64url')})).statusCode,503);
    const direct=await f.call('/orders','POST',{planId:'once',clientRequestId:'r1'},installed.accessToken);assert.equal(direct.statusCode,201);
    const auth=await f.authorize('user-A','code-A'),bound=JSON.parse((await f.call('/oauth/bind','POST',auth,installed.accessToken)).body);
    assert.equal(bound.installationId,installed.installationId);
    const retryOrder=await f.call('/orders','POST',{planId:'once',clientRequestId:'r1'},bound.accessToken);assert.equal(retryOrder.statusCode,201);assert.equal(JSON.parse(retryOrder.body).id,JSON.parse(direct.body).id);
    const fresh=await f.authorize('user-A','code-B'),restored=JSON.parse((await f.call('/oauth/restore','POST',fresh)).body);
    assert.equal(restored.installationId,installed.installationId);
    assert.ok(!JSON.stringify([...f.state.docs]).includes(verifier));assert.ok(!JSON.stringify([...f.state.docs]).includes(installed.accessToken));
  }finally{f.close();}
});
test('concurrent retries for the same installation preserve one owner and registration',async()=>{
  const f=fixture(true,false);try{
    const requestId=crypto.randomBytes(32).toString('base64url'),verifier=crypto.randomBytes(32).toString('base64url');
    const results=await Promise.all([f.call('/installations','POST',{requestId,verifier}),f.call('/installations','POST',{requestId,verifier})]);
    assert.ok(results.every(r=>r.statusCode===201));assert.deepEqual(JSON.parse(results[0].body),JSON.parse(results[1].body));
    assert.equal([...f.state.docs.values()].filter(x=>x.kind==='registration').length,1);
    assert.equal(f.state.docs.get('daily_hundred_installation_v1:window-v2').count,1);
  }finally{f.close();}
});

test('offline: only the bound Alipay identity can recover a paid account after reinstall',async()=>{
  const f=fixture(true,false);
  try{
    const registration=()=>({requestId:crypto.randomBytes(32).toString('base64url'),verifier:crypto.randomBytes(32).toString('base64url')});
    const originalRegistration=registration(),oldInstallation=JSON.parse((await f.call('/installations','POST',originalRegistration)).body);
    const first=await f.authorize('user-paid','code-paid-1');
    const oldBound=JSON.parse((await f.call('/oauth/bind','POST',first,oldInstallation.accessToken)).body);
    assert.equal(oldBound.installationId,oldInstallation.installationId);
    await f.pay(oldBound.accessToken); // Synthetic RSA keys, fake SDK transport and in-memory transactions.
    assert.equal(JSON.parse((await f.call('/entitlements','GET',undefined,oldBound.accessToken)).body).runCredits,1);
    const reinstall=JSON.parse((await f.call('/installations','POST',registration())).body);
    assert.notEqual(reinstall.installationId,oldInstallation.installationId);
    assert.equal(JSON.parse((await f.call('/entitlements','GET',undefined,reinstall.accessToken)).body).runCredits,0);
    const wrongAlipay=await f.authorize('user-other','code-other-1');
    assert.equal((await f.call('/oauth/restore','POST',wrongAlipay)).statusCode,503);
    assert.equal((await f.call('/oauth/bind','POST',wrongAlipay,oldInstallation.accessToken)).statusCode,503);
    const otherBound=JSON.parse((await f.call('/oauth/bind','POST',wrongAlipay,reinstall.accessToken)).body);
    assert.equal(otherBound.installationId,reinstall.installationId);
    assert.equal(JSON.parse((await f.call('/entitlements','GET',undefined,otherBound.accessToken)).body).runCredits,0);
    const correct=await f.authorize('user-paid','code-paid-2');
    const recovered=JSON.parse((await f.call('/oauth/restore','POST',correct)).body);
    assert.equal(recovered.installationId,oldInstallation.installationId);
    assert.equal(JSON.parse((await f.call('/entitlements','GET',undefined,recovered.accessToken)).body).runCredits,1);
    const replay=JSON.parse((await f.call('/oauth/restore','POST',correct)).body);assert.deepEqual(replay,recovered);
    assert.equal((await f.call('/entitlements','GET',undefined,oldInstallation.accessToken)).statusCode,503);
    assert.equal((await f.call('/orders','POST',{planId:'once',clientRequestId:'after-restore'},oldBound.accessToken)).statusCode,503);
    assert.equal((await f.call('/installations','POST',originalRegistration)).statusCode,503);
    assert.equal(JSON.parse((await f.call('/entitlements','GET',undefined,otherBound.accessToken)).body).runCredits,0);
    assert.equal((await f.call('/oauth/bind','POST',correct,reinstall.accessToken)).statusCode,503);
  }finally{f.close();}
});

test('offline actual Android client can open checkout before optional OAuth binding',async()=>{
  const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
  const ts=require('../../outputs/daily-hundred-app/node_modules/typescript');
  const source=fs.readFileSync(path.join(__dirname,'../../outputs/daily-hundred-app/src/billing/client.ts'),'utf8');
  const js=ts.transpileModule(source,{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText;
  const mod={exports:{}};vm.runInNewContext(`(function(exports,module){${js}\n})`,{URL,AbortController,setTimeout,clearTimeout})(mod.exports,mod);
  const f=fixture(true,false);let saved=null,pending=[],opens=0,orders=0;
  try{
    const registration={requestId:crypto.randomBytes(32).toString('base64url'),verifier:crypto.randomBytes(32).toString('base64url')};
    const store={readIdentity:async()=>saved,writeIdentity:async v=>{saved=v},getOrCreateRegistration:async()=>registration,readPending:async()=>pending,writePending:async v=>{pending=v}};
    const fetch=async(url,init)=>{
      const route=new URL(url).pathname.slice(PATH.length),method=init.method,body=init.body===undefined?undefined:JSON.parse(init.body);
      if(route==='/status')return new Response(JSON.stringify({available:true,mode:'mock'}),{status:200}); // Production status remains 503.
      if(route==='/orders')orders++;
      const token=init.headers.Authorization?.slice('Bearer '.length);
      const response=await f.call(route,method,body,token);
      return new Response(response.body,{status:response.statusCode,headers:response.headers});
    };
    const client=mod.exports.createPayClient({enabled:true,allowMock:true,baseUrl:'https://example.invalid/api/billing',allowedCheckoutOrigins:['https://openapi.alipay.com'],store,fetch,openCheckout:async()=>{opens++}});
    const order=await client.purchase('once','request-first-attempt');
    assert.equal(order.status,'pending');assert.equal(order.amountFen,100);
    assert.equal(orders,1);assert.equal(opens,1);assert.equal(pending.length,1);
    assert.ok(saved?.accessToken);assert.equal(saved.purchaseIntent.clientRequestId,'request-first-attempt');
    const installationId=saved.installationId,auth=await f.authorize('offline-identity','code-bind-client');
    const boundResponse=await f.call('/oauth/bind','POST',auth,saved.accessToken);assert.equal(boundResponse.statusCode,200);
    const bound=JSON.parse(boundResponse.body);assert.equal(bound.installationId,installationId);
    // This assignment represents a separately verified, durably stored binding;
    // the shipped client does not yet implement this step.
    await store.writeIdentity({...saved,accessToken:bound.accessToken});
    assert.equal(saved.purchaseIntent.clientRequestId,'request-first-attempt');assert.equal(pending.length,1);
    assert.equal(pending[0].clientRequestId,'request-first-attempt');
    assert.equal((await f.call('/orders/'+order.id,'GET',undefined,bound.accessToken)).statusCode,200);
  }finally{f.close();}
});

test('offline real JS client starts WAP and reconciles a signed query after foreground return without OAuth or notification',async()=>{
  const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),ts=require('../../outputs/daily-hundred-app/node_modules/typescript');
  const source=fs.readFileSync(path.join(__dirname,'../../outputs/daily-hundred-app/src/billing/client.ts'),'utf8');
  const js=ts.transpileModule(source,{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText;
  const mod={exports:{}};vm.runInNewContext(`(function(exports,module){${js}\n})`,{URL,AbortController,setTimeout,clearTimeout})(mod.exports,mod);
  const f=fixture(true,false);let saved=null,pending=[],opens=0;
  try{
    const registration={requestId:crypto.randomBytes(32).toString('base64url'),verifier:crypto.randomBytes(32).toString('base64url')};
    const store={readIdentity:async()=>saved,writeIdentity:async v=>{saved=v},getOrCreateRegistration:async()=>registration,readPending:async()=>pending,writePending:async v=>{pending=v}};
    const fetch=async(url,init)=>{const route=new URL(url).pathname.slice(PATH.length),body=init.body===undefined?undefined:JSON.parse(init.body);
      if(route==='/status')return new Response(JSON.stringify({available:true,mode:'mock'}),{status:200});
      const response=await f.call(route,init.method,body,init.headers.Authorization?.slice(7));return new Response(response.body,{status:response.statusCode,headers:response.headers});};
    const client=mod.exports.createPayClient({enabled:true,allowMock:true,baseUrl:'https://example.invalid/api/billing',allowedCheckoutOrigins:['https://openapi.alipay.com'],store,fetch,openCheckout:async()=>{opens++}});
    const order=await client.purchase('once','real-flow-test-1');assert.equal(opens,1);assert.equal(order.status,'pending');
    // In-memory fake provider emits an RSA2-signed query; no real network or payment occurs.
    f.querySuccess(order.id,{seller_id:'test-seller'});
    const result=await client.refreshPending();assert.equal(result.errors.length,0);assert.equal(result.orders[0].status,'paid');
    assert.equal(result.entitlements.runCredits,1);assert.equal(pending.length,0);
    assert.equal((await client.refreshPending()).entitlements.runCredits,1);
  }finally{f.close();}
});

test('offline evidence: stale purchase write can overwrite freshly bound identity',async()=>{
  const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
  const ts=require('../../outputs/daily-hundred-app/node_modules/typescript');
  const source=fs.readFileSync(path.join(__dirname,'../../outputs/daily-hundred-app/src/billing/client.ts'),'utf8');
  const js=ts.transpileModule(source,{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText;
  const mod={exports:{}};vm.runInNewContext(`(function(exports,module){${js}\n})`,{URL,AbortController,setTimeout,clearTimeout})(mod.exports,mod);
  const f=fixture(true,false);let saved=null,opens=0,releasePending,signalPending;
  const waiting=new Promise(resolve=>{signalPending=resolve}),resume=new Promise(resolve=>{releasePending=resolve});
  try{
    const registration={requestId:crypto.randomBytes(32).toString('base64url'),verifier:crypto.randomBytes(32).toString('base64url')};
    const store={readIdentity:async()=>saved,writeIdentity:async v=>{saved=v},getOrCreateRegistration:async()=>registration,readPending:async()=>{signalPending();await resume;return [];},writePending:async()=>{}};
    const fetch=async(url,init)=>{
      const route=new URL(url).pathname.slice(PATH.length),body=init.body===undefined?undefined:JSON.parse(init.body);
      if(route==='/status')return new Response(JSON.stringify({available:true,mode:'mock'}),{status:200});
      const response=await f.call(route,init.method,body,init.headers.Authorization?.slice(7));
      return new Response(response.body,{status:response.statusCode,headers:response.headers});
    };
    const client=mod.exports.createPayClient({enabled:true,allowMock:true,baseUrl:'https://example.invalid/api/billing',allowedCheckoutOrigins:['https://openapi.alipay.com'],store,fetch,openCheckout:async()=>{opens++}});
    const purchase=client.purchase('once','race-attempt-123');await waiting;
    const registrationToken=saved.accessToken,auth=await f.authorize('concurrency-user','code-race');
    const boundResponse=await f.call('/oauth/bind','POST',auth,registrationToken);assert.equal(boundResponse.statusCode,200);
    const bound=JSON.parse(boundResponse.body);await store.writeIdentity({...saved,accessToken:bound.accessToken});
    assert.equal(saved.accessToken,bound.accessToken);releasePending();
    const pendingOrder=await purchase;assert.equal(pendingOrder.status,'pending');
    // This documents the present unsafe race, not desired final behaviour.
    assert.equal(saved.accessToken,registrationToken);assert.notEqual(saved.accessToken,bound.accessToken);assert.equal(opens,1);
  }finally{releasePending?.();f.close();}
});
