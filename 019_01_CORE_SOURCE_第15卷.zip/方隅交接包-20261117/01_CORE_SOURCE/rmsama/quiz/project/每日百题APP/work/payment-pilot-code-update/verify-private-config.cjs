'use strict';
const fs=require('node:fs'),path=require('node:path');
for(const n of ['log','info','warn','error','debug','trace'])console[n]=()=>{};
try{
 const dir=path.resolve(__dirname,'../payment-pilot-private'),identity=JSON.parse(fs.readFileSync(path.join(dir,'identity.json'),'utf8')),expected=JSON.parse(fs.readFileSync(path.join(dir,'pilot-config.json'),'utf8'));
 const master=require('../payment-secret-prep/master-bridge.cjs').loadMaster({fixture:false});let matches;
 try{matches=JSON.stringify(require('./derive-core.cjs').derive(master,identity))===JSON.stringify(expected)}finally{master.fill(0)}
 process.stdout.write(JSON.stringify({privateConfigMatches:matches,cloudWrite:false})+'\n');if(!matches)process.exitCode=2;
}catch{process.stdout.write('{"verified":false,"cloudWrite":false}\n');process.exitCode=2}
