// Execute in an isolated browser context using an existing CloudBase Web SDK
// app. Never invokes sign-in, creates users, changes config or prints session.
import {verifyClient} from './browser-negative.mjs';
export async function verifyExistingSession(app,kind){
 try{
  if(!app||!app.auth||typeof app.auth.getSession!=='function'||typeof app.database!=='function')return {verified:false,reason:'client-unavailable'};
  const {data,error}=await app.auth.getSession();if(error||!data?.session)return {verified:false,reason:'identity-unverified'};
  return await verifyClient(app.database(),data.session,kind);
 }catch{return {verified:false,reason:'indeterminate'};}
}
