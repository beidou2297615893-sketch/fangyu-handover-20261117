'use strict';
// Fixed, create-only CloudBase request. Credentials stay in the calling process.
const ENV='fh6-d5ga45c0ddae7008c',NAME='dailyHundredBillingInitV1';
function request(zip){
 if(!Buffer.isBuffer(zip)||zip.length<4||zip.length>20*1024*1024||zip.readUInt32LE(0)!==0x04034b50)throw Error('unavailable');
 return {FunctionName:NAME,EnvId:ENV,Handler:'index.main',MemorySize:256,Timeout:30,InstallDependency:'FALSE',
   Stamp:'MINI_QCBASE',Role:'TCB_QcsRole',Runtime:'Nodejs20.19',Type:'Event',CodeSource:'ZipFile',Code:{ZipFile:zip.toString('base64')}};
}
async function create(client,zip){
 if(!client||typeof client.CreateFunction!=='function')throw Error('unavailable');
 const r=await client.CreateFunction(request(zip));
 if(!r||typeof r.RequestId!=='string'||!r.RequestId||r.SCFErrorCode!==undefined&&r.SCFErrorCode!==''||r.SCFErrorMsg!==undefined&&r.SCFErrorMsg!=='')throw Error('unavailable');
 return {RequestId:r.RequestId};
}
function guardedTransport(original){
 if(typeof original!=='function')throw Error('unavailable');
 return (url,options)=>{if(url!=='https://tcb.tencentcloudapi.com/'||options?.proxy||options?.agent)throw Error('unavailable');return original(url,{...options,redirect:'error'});};
}
module.exports={request,create,guardedTransport};
