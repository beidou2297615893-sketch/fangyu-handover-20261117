'use strict';
// Read only two fixed policy docs using Tencent's existing Node SDK.
const fs=require('node:fs'),os=require('node:os'),path=require('node:path');for(const n of ['log','info','warn','error','debug','trace'])console[n]=()=>{};
const blocked=['NODE_OPTIONS','NODE_DEBUG','DEBUG','NODE_EXTRA_CA_CERTS','NODE_USE_SYSTEM_CA','NODE_USE_ENV_PROXY','NODE_PATH','SSL_CERT_FILE','SSL_CERT_DIR','CURL_CA_BUNDLE','REQUESTS_CA_BUNDLE','USE_INTERNAL_ENDPOINT','HTTP_PROXY','HTTPS_PROXY','ALL_PROXY','http_proxy','https_proxy','all_proxy','NODE_TLS_REJECT_UNAUTHORIZED'];
(async()=>{try{
 if(process.execArgv.length||blocked.some(k=>process.env[k]))throw Error('unsafe');
 const home=path.resolve(__dirname,'dailyHundredBillingV1/node_modules/@cloudbase/node-sdk'),platform=require(path.join(home,'dist/utils/cloudplatform.js'));platform.preflightRuntimeCloudPlatform=async()=>{};platform.checkIsInternalAsync=async()=>false;
 const transport=require(path.join(home,'dist/utils/request-core.js')),original=transport.request,{allowed}=require('./direct-guard.cjs');let sent=0;transport.request=(opts,cb)=>{if(!allowed(opts,false))throw Error('blocked');sent++;return original(opts,cb)};
 const c=JSON.parse(fs.readFileSync(path.join(os.homedir(),'.config','.cloudbase','auth.json'),'utf8')).credential||{},secretId=c.secretId||c.tmpSecretId,secretKey=c.secretKey||c.tmpSecretKey,sessionToken=c.token||c.tmpToken,expiry=Number(c.accessTokenExpired||c.tmpExpired);
 if(!secretId||!secretKey||!sessionToken||!Number.isFinite(expiry)||expiry<=Date.now()+120000)throw Error('credentials');
 const app=require(home).init({env:'fh6-d5ga45c0ddae7008c',secretId,secretKey,sessionToken,region:'ap-shanghai',protocol:'https',keepalive:false,retries:0,timeout:10000});const db=app.database({throwOnCode:true});
 const states=[];for(const name of ['daily_hundred_installation_v1','daily_hundred_payment_v1']){const r=await db.collection(name).doc('policy').get();if(!Array.isArray(r?.data)||r.data.length!==1)throw Error('policy');const d=r.data[0];if(r?.code||d?._id!=='policy'||d?.kind!=='policy'||d?.schema!==1||typeof d?.enabled!=='boolean')throw Error('policy');states.push(d.enabled)}
 process.stdout.write(JSON.stringify({verified:true,bothPoliciesClosed:states.every(x=>x===false),bothPoliciesEnabled:states.every(x=>x===true),fixedDocumentReads:sent,cloudWrite:false})+'\n');
}catch(e){const code=typeof e?.code==='string'&&/^[A-Z0-9_]{1,50}$/.test(e.code)?e.code:'unavailable';process.stdout.write(JSON.stringify({verified:false,code,cloudWrite:false})+'\n');process.exitCode=2}})();
