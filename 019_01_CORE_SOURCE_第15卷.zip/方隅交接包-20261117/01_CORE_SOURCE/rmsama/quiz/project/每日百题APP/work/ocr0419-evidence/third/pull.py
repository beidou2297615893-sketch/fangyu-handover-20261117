from pathlib import Path
import subprocess,json
root=Path(__file__).parent
adb=["V:/work/tools/android-sdk/platform-tools/adb.exe","-P","15057","-s","127.0.0.1:5741","exec-out","run-as","com.jimusoft.ocrreplay"]
for mode in ["production","native","scale150","grayContrast","scale280Pad","crop300"]:
 f="lines-"+mode+".json";dest=root/f
 if dest.exists():continue
 result=subprocess.run(adb+["cat","files/"+f],capture_output=True)
 if result.returncode==0:
  try:records=json.loads(result.stdout)
  except ValueError:continue
  dest.write_bytes(result.stdout);print(mode,len(records))
