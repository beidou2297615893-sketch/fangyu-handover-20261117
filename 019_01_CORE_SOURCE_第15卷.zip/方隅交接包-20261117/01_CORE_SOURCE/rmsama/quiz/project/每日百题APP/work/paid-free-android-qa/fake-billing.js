'use strict';
// Synthetic ledger bound to loopback only. No payment SDK, merchant key or cloud.
const http=require('node:http');const owner='i'+'1'.repeat(32),token='I'+'x'.repeat(42),runs=new Map();let reserveCount=0,confirmCount=0,continueCount=0,cancelCount=0;
const send=(r,code,obj)=>{r.writeHead(code,{'content-type':'application/json'});r.end(JSON.stringify(obj));};
http.createServer((q,r)=>{
  if(q.method==='GET'&&q.url==='/__test/state')return send(r,200,{reserveCount,confirmCount,continueCount,cancelCount,runs:[...runs.values()]});
  if(q.method!=='POST'||q.headers.authorization!=='Bearer '+token)return send(r,403,{error:'denied'});
  let body='';q.on('data',x=>{body+=x;if(body.length>8192)q.destroy();});q.on('end',()=>{try{
    const v=JSON.parse(body),match=/^\/api\/billing\/runs\/([A-Za-z0-9_-]+)\/(confirm|continue|release|cancel)$/.exec(q.url);
    if(q.url==='/api/billing/runs/reserve'){
      const id=v.runId,binding=v.taskBinding;if(!/^[A-Za-z0-9_-]+$/.test(id)||!/^[a-f0-9]{64}$/.test(binding))throw Error();
      let row=runs.get(id);if(!row){row={ownerId:owner,runId:id,taskBinding:binding,status:'reserved',source:'credit'};runs.set(id,row);reserveCount++;}
      if(row.taskBinding!==binding||!['reserved','confirmed'].includes(row.status))throw Error();return send(r,200,row);
    }
    if(!match)throw Error();const [_,id,op]=match;let row=runs.get(id);
    if(op==='cancel'&&!row){row={ownerId:owner,runId:id,taskBinding:v.taskBinding,status:'cancelled',source:'credit'};runs.set(id,row);cancelCount++;return send(r,200,{ownerId:owner,runId:id,taskBinding:v.taskBinding,status:'cancelled'});}
    if(!row)throw Error();
    if(op==='confirm'){if(row.status==='reserved'){row.status='confirmed';confirmCount++;}if(row.status!=='confirmed')throw Error();return send(r,200,row);}
    if(op==='continue'){if(row.status!=='confirmed'||row.taskBinding!==v.taskBinding)throw Error();continueCount++;return send(r,200,{...row,status:'authorized'});}
    if(op==='release'){if(row.status==='reserved')row.status='released';if(row.status!=='released')throw Error();return send(r,200,row);}
    if(op==='cancel'){if(row.taskBinding!==v.taskBinding||!['reserved','released','cancelled'].includes(row.status))throw Error();row.status='cancelled';cancelCount++;return send(r,200,{ownerId:owner,runId:id,taskBinding:v.taskBinding,status:'cancelled'});}
    throw Error();
  }catch{return send(r,503,{error:'unavailable'});}});
}).listen(18765,'127.0.0.1');
