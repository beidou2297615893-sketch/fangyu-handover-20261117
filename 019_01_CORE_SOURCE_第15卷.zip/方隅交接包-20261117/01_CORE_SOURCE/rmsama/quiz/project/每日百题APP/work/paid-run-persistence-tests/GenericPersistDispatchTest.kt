package expo.modules.automationbridge.generic

import expo.modules.automationbridge.runtime.ActionIntent
import expo.modules.automationbridge.runtime.RunFacts

object GenericPersistDispatchTest {
  @JvmStatic fun main(args:Array<String>) {
    val f=RunFacts("run","workspace","revision","__generic__",1,"hash",status="running")
    val action=ActionIntent("id","run","frame","fingerprint","click","ref")
    var free=0;var paid=0;var seen:ActionIntent?=null
    val normal:(RunFacts,String,String?)->Unit={ _,_,_ -> free++ }
    val paidPersist:(RunFacts,String,String?,ActionIntent?)->Unit={ _,_,_,a -> paid++;seen=a }
    GenericPersistDispatch.save(false,f,"binding","stem",action,normal,null)
    check(free==1 && paid==0)
    var rejected=false
    try { GenericPersistDispatch.save(false,f,"binding","stem",action,normal,paidPersist) } catch (_:Exception) { rejected=true }
    check(rejected && free==1 && paid==0)
    GenericPersistDispatch.save(true,f,"binding","stem",action,normal,paidPersist)
    check(free==1 && paid==1 && seen===action)
    rejected=false
    try { GenericPersistDispatch.save(true,f,"binding","stem",action,normal) { _,_,_,_ -> error("storage failure") } } catch (_:Exception) { rejected=true }
    check(rejected && free==1)
    println("PASS free callback preserved, closed paid path rejected, native action forwarded")
  }
}
