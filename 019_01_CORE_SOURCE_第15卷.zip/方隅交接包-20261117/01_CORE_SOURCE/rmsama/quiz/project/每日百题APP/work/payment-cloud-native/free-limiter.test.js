'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const {createFreeLimiter}=require('./free-limiter');
function dbFixture(){let docs=new Map(),queue=Promise.resolve();return{runTransaction(fn){const p=queue.then(async()=>{const next=new Map([...docs].map(([k,v])=>[k,structuredClone(v)]));const tx={collection(n){return{doc(id){const k=n+':'+id;return{async get(){return{data:next.has(k)?{_id:id,...structuredClone(next.get(k))}:null}},async set(v){const exists=next.has(k);next.set(k,structuredClone(v));return exists?{updated:1}:{updated:0,upserted:[{_id:id}]}}}}}}};const result=await fn(tx);docs=next;return result});queue=p.catch(()=>{});return p}}}
test('new free operations are bounded per owner and globally; retries remain idempotent',async()=>{
 const db=dbFixture(),limiter=createFreeLimiter({db,clock:()=>1700000000000,ownerLimit:2,globalLimit:3});
 await limiter('owner1','migrate',{deviceDigest:'a'.repeat(64)});
 for(let i=0;i<10;i++)await limiter('owner1','migrate',{deviceDigest:'a'.repeat(64)});
 await limiter('owner1','reserve',{deviceDigest:'a'.repeat(64),runId:'r1'});
 await assert.rejects(limiter('owner1','reserve',{deviceDigest:'a'.repeat(64),runId:'r2'}));
 await limiter('owner2','migrate',{deviceDigest:'b'.repeat(64)});
 await assert.rejects(limiter('owner3','migrate',{deviceDigest:'c'.repeat(64)}));
 await limiter('owner1','reserve',{deviceDigest:'a'.repeat(64),runId:'r1'});
});
test('safe completion and continuation never consume the new-operation budget',async()=>{
 const limiter=createFreeLimiter({db:dbFixture(),clock:()=>1700000000000,ownerLimit:1,globalLimit:1});
 await limiter('owner1','migrate',{deviceDigest:'a'.repeat(64)});
 for(const action of ['status','confirm','release','resume'])await limiter('owner1',action,{});
});
test('cancellation of an already budgeted reserve remains possible at the limit',async()=>{
 const limiter=createFreeLimiter({db:dbFixture(),clock:()=>1700000000000,ownerLimit:1,globalLimit:1});
 const p={deviceDigest:'a'.repeat(64),runId:'r1'};
 await limiter('owner1','reserve',p);await limiter('owner1','cancel',p);
});
