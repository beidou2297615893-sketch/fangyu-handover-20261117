from pathlib import Path
import json,shutil
r=Path('V:/work/original-vs-0419');prod=Path('V:/work/tijing-bankassist')
observed=json.loads((r/'hidden-fixed/ocr-question11.json').read_text(encoding='utf-8'))
bank=json.loads((r/'same-bank-1859.json').read_text(encoding='utf-8'))
question=observed['reconciliation']['canonicalQuestion']
record=next(q for q in bank['questions'] if q['question']==question)
fixture={'record':record,'lines':observed['independent']['lines']}
target=prod/'android/app/src/test/resources/regression/wrapped-option.json';target.parent.mkdir(parents=True,exist_ok=True);target.write_text(json.dumps(fixture,ensure_ascii=False,indent=2),encoding='utf-8')
stage=r/'regression-stage';shutil.copytree(r/'fixed-current/source/android',stage,ignore=shutil.ignore_patterns('build','.gradle','local.properties'))
(stage/'local.properties').write_text('sdk.dir=V:/work/tools/android-sdk\n',encoding='utf-8')
for rel in ['app/src/test/java/com/futureyyy/tijing/WrappedOptionRegressionTest.kt','app/src/test/resources/regression/wrapped-option.json']:
    dest=stage/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(prod/'android'/rel,dest)
print('Prepared regression from the exact failed frame; no solver or answer data injected into runtime.')
