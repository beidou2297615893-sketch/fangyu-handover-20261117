package com.futureyyy.tijing

import java.text.Normalizer

/** Read controls from their visible text in the current capture, never from a guessed coordinate. */
internal data class OcrHostPage(val page: HostQuestionPage, val result: Boolean, val stem: String?, val nextBox: NormalizedBox?) {
    companion object {
        internal val submitLabels = setOf("确认", "确认答案", "确认提交", "提交", "提交答案", "确定", "確定", "確認", "確認答案")
        private val nextLabels = setOf("下一题", "下一題", "查看成绩", "查看成績")
        private val progress = Regex("(?:第)?(\\d{1,4})(?:题|題)?/(?:共)?(\\d{1,4})(?:题|題)?")
        private val option = Regex("^[A-H][.、:：)）]\\s*\\S*")
        private val score = Regex("(?:本次)?(?:得分|成绩|總分|总得分)[:：]?\\d{1,4}(?:分)?")
        private val roleSuffix = Regex("[,，、]?(?:按钮|按鈕)$")
        private val optionPrefix = Regex("""^(?:[（(\[【]([A-Z])[）)\]】]\s*[.、:]?|([A-Z])\s*[.、:)])\s*(.*)$""")

        internal fun compact(value: String): String = Normalizer.normalize(value, Normalizer.Form.NFKC)
            .filterNot { it.isWhitespace() || it == '\u200b' || it == '\u200e' || it == '\ufeff' }

        internal fun optionMarker(value: String): String = if (value.length > 1 &&
            value[0] in 'a'..'z' && value[1] in ".、:)") value[0].uppercaseChar() + value.drop(1) else value

        internal fun label(value: String): String = compact(value).trim('|', '丨', '│', '┃', '╭', '╮', '╰', '╯').replace(roleSuffix, "")

        fun read(lines: List<VisibleQuestionReader.Node>): OcrHostPage {
            val visible = lines.filter { it.box != null }.sortedBy { it.box!!.centerY }
            val texts = visible.map { compact(it.text) }
            val hasFeedback = texts.any { it in setOf("回答正确", "回答错误", "答对了", "答错了", "答题正确", "答题错误") }
            val hasAnswer = texts.any { it.startsWith("正确答案:") || it.startsWith("正确答案是") }
            val next = control(visible, nextLabels)
            val scoreShown = texts.any(score::matches)
            val result = scoreShown && texts.any { it in setOf("再来100题", "重新抽取", "重新答题", "答题完成", "练习完成", "查看解析", "重新练习") ||
                it.matches(Regex("满分\\d+分")) || it.matches(Regex("答[对错]\\d+题(?:[,，、]?答[对错]\\d+题)?")) }
            val progressValue = texts.mapNotNull { text ->
                val counter = text.replaceFirst(Regex("^(单选题?|多选题?|判断题?|不定项选择题?)"), "")
                progress.matchEntire(counter)?.let {
                    val n = it.groupValues[1].toInt()
                    val total = it.groupValues[2].toInt()
                    if (n in 1..total) HostQuestionProgress(n, total) else null
                }
            }.distinct().singleOrNull()
            val stem = VisibleQuestionReader.readOcrLines(visible, progressValue?.current ?: 1)?.question
            return OcrHostPage(HostQuestionPage(progressValue, hasFeedback && (hasAnswer || next != null), next != null), result, stem, next)
        }

        fun confirmBox(lines: List<VisibleQuestionReader.Node>): NormalizedBox? {
            val button = control(lines, submitLabels) ?: return null
            val lastOption = lines.filter { option.containsMatchIn(compact(it.text)) }.mapNotNull { it.box }.maxOfOrNull { it.centerY }
            return button.takeIf { lastOption == null || button.centerY > lastOption }
        }

        fun containsStem(lines: List<VisibleQuestionReader.Node>, expected: String): Boolean {
            val target = stemText(expected)
            if (target.isEmpty()) return false
            val current = read(lines).stem
            if (current != null) return stemText(current) == target
            val beforeOptions = lines.filter { it.box != null }.sortedBy { it.box!!.centerY }
                .takeWhile { !option.containsMatchIn(compact(it.text)) }.map { compact(it.text) }
            for (start in beforeOptions.indices) {
                val candidate = StringBuilder()
                for (end in start until beforeOptions.size) {
                    candidate.append(beforeOptions[end])
                    val value = stemText(candidate.toString())
                    if (value == target) return true
                    if (value.length > target.length) break
                }
            }
            return false
        }

        private fun stemText(text: String) = compact(text).trimEnd('。', '.', '?', '？').replace(Regex("_{2,}"), "()")

        private val numbering = Regex("""^(?:第\d+[题題][:、.]?|\d+[、)]|\d+\.(?!\d))""")
        private val protectedText = Regex("""\d+(?:\.\d+)?|[a-zA-Z+−/%=<>≤≥-]+|允许|禁止|关闭|开启|牵引|制动|停车|启动|应当|可以|必须|[不未非无有禁否勿增减高低上下左右前后内外大多少小单双正负先后开关启闭停升降推拉进退]""")
        private fun contentKey(raw: String, stem: Boolean): String {
            val source = compact(raw)
            val body = if (stem) numbering.replaceFirst(source, "") else source
            return body.filter { it.isLetterOrDigit() || it in ".+−/%=<>≤≥-" }.trimEnd('.')
        }
        private fun sameReading(actual: String, expected: String): Boolean {
            if (actual == expected) return actual.isNotEmpty()
            if (minOf(actual.length, expected.length) < 16) return false
            if (protectedText.findAll(actual).map { it.value }.toList() != protectedText.findAll(expected).map { it.value }.toList()) return false
            val limit = (expected.length / 10).coerceIn(1, 4)
            if (kotlin.math.abs(actual.length - expected.length) > limit) return false
            // Require independent ordered fragments near both ends as well as bounded full-text distance.
            if (actual.take(9).windowed(3).none { it in expected.take(9) } ||
                actual.takeLast(9).windowed(3).none { it in expected.takeLast(9) }) return false
            var prev = IntArray(expected.length + 1) { it }
            var row = IntArray(expected.length + 1)
            for (i in 1..actual.length) {
                row[0] = i
                for (j in 1..expected.length) row[j] = minOf(row[j - 1] + 1, prev[j] + 1,
                    prev[j - 1] + if (actual[i - 1] == expected[j - 1]) 0 else 1)
                val temp = prev; prev = row; row = temp
            }
            return prev[expected.length] <= limit
        }

        /** Corroborate the cloud stem using whole visible lines strictly above the first option. */
        fun matchesCloudStem(lines: List<VisibleQuestionReader.Node>, stem: String, firstOption: NormalizedBox): Boolean {
            val expected = contentKey(stem, true)
            val above = lines.filter { it.box != null && it.box.centerY < firstOption.y }.sortedBy { it.box!!.centerY }
            for (i in above.indices) {
                val text = StringBuilder()
                for (j in i until minOf(above.size, i + 12)) {
                    text.append(above[j].text)
                    val candidate = contentKey(text.toString(), true)
                    if (sameReading(candidate, expected)) return true
                    if (candidate.length > expected.length + 4) break
                }
            }
            return false
        }

        private fun optionText(option: QuizOption): String {
            val text = compact(option.text)
            val m = optionPrefix.matchEntire(text) ?: return text
            val letter = (m.groupValues[1] + m.groupValues[2]).singleOrNull()
            return if (letter == 'A' + option.index) m.groupValues[3] else text
        }

        internal fun isRuleText(value:String):Boolean = value == "一" || value.isNotEmpty() && value.all { it in "—–─━―" }

        internal fun isRuleOption(text:String, index:Int):Boolean {
            val t=Normalizer.normalize(text,Normalizer.Form.NFKC).trim()
            val prefix=optionPrefix.matchEntire(t)
            val body=if (prefix!=null && (prefix.groupValues[1]+prefix.groupValues[2]).single()=='A'+index) prefix.groupValues[3].trim() else t
            return isRuleText(body)
        }

        internal fun freshOption(expected: QuizModelResult, option: QuizOption, current: QuizModelResult?): NormalizedBox? {
            if (current == null || stemText(current.question) != stemText(expected.question)) return null
            val before = expected.options.sortedBy { it.index }
            val now = current.options.sortedBy { it.index }
            if (before.size != now.size || before.indices.any { before[it].index != now[it].index || optionText(before[it]) != optionText(now[it]) }) return null
            return now.singleOrNull { it.index == option.index && optionText(it) == optionText(option) }?.box
        }

        /** Locate all expected labels in their on-screen order. Never trust a remote y-coordinate. */
        internal fun optionRows(lines: List<VisibleQuestionReader.Node>, options: List<QuizOption>): List<NormalizedBox>? {
            val sorted = options.sortedBy { it.index }
            if (sorted.size !in 2..26 || sorted.indices.any { sorted[it].index != it }) return null
            val words = sorted.map(::optionText)
            if (words.any { it.isEmpty() } || words.distinct().size != words.size) return null
            val nodes = lines.filter { it.box != null }.sortedWith(compareBy({ it.box!!.centerY }, { it.box!!.x }))
            val grouped by lazy { VisibleQuestionReader.readOcrLines(lines, 1)?.options?.sortedBy { it.index }?.takeIf { it.size == sorted.size } }
            val rows = words.mapIndexed { index, word ->
                val label = 'A' + index
                val choices = mutableListOf<NormalizedBox>()
                for (start in nodes.indices) {
                    val line = nodes[start]
                    if (line.continuousRule) {
                        if (isRuleOption(sorted[index].text,index) && sorted.count{isRuleOption(it.text,it.index)}==1 && nodes.count{it.continuousRule}==1) choices += line.box!!
                        continue
                    }
                    var text = optionMarker(compact(line.text).trimStart('◯', '○', '●', '□', '☐', '◉', '◎', '✓', '✔'))
                    // A drawn radio can be read together with the following letter as "0A".
                    if (text.startsWith("0$label")) text = text.drop(1)
                    val raw = text
                    val secondLabel = if (text.startsWith("$label$label")) optionPrefix.matchEntire(text.drop(1)) else null
                    if (secondLabel != null && (secondLabel.groupValues[1] + secondLabel.groupValues[2]).single() == label)
                        text = text.drop(1)
                    val match = optionPrefix.matchEntire(text)
                    if (match != null) {
                        if ((match.groupValues[1] + match.groupValues[2]).single() != label) continue
                        text = match.groupValues[3]
                    } else if (text.startsWith(label) && text.drop(1).isNotEmpty()) text = text.drop(1)
                    if (text.isEmpty()) continue
                    if (raw == word) text = raw
                    for (j in start until minOf(nodes.size, start + 6)) {
                        if (j != start) {
                            val prev = nodes[j - 1].box!!
                            val next = nodes[j].box!!
                            if (next.y - prev.y - prev.height > maxOf(next.height, prev.height)) break
                            var continuation = optionMarker(compact(nodes[j].text))
                            // A vertically centered marker can be merged into the
                            // second line of the same wrapped option by OCR.
                            val marker = optionPrefix.matchEntire(continuation)
                            if (marker != null) {
                                if ((marker.groupValues[1] + marker.groupValues[2]).single() != label) break
                                continuation = marker.groupValues[3]
                            }
                            text += continuation
                        }
                        if (text.trimEnd('。') == word.trimEnd('。')) {
                            choices += line.box!!
                            break
                        }
                        if (!word.startsWith(text)) break
                    }
                }
                val exact = choices.distinct()
                if (exact.size > 1) return null
                exact.singleOrNull() ?: grouped?.get(index)?.takeIf { it.index == index &&
                    sameReading(contentKey(optionText(it), false), contentKey(word, false)) }?.box ?: return null
            }
            if (rows.zipWithNext().any { (a,b) -> b.y < a.y + a.height * 0.5f }) return null
            return rows
        }

        internal fun verifiedRows(readings: List<List<VisibleQuestionReader.Node>>, transcript: QuizModelResult): List<NormalizedBox>? {
            val candidates = readings.mapNotNull { lines ->
                optionRows(lines, transcript.options)?.takeIf { matchesCloudStem(lines, transcript.question, it.first()) }
            }
            val first = candidates.firstOrNull() ?: return null
            // Both engines read the very same frame. Two independently proven positions
            // for an option must fall in the same row before the position can be used.
            return first.takeIf { candidates.all { other -> first.zip(other).all { (a, b) ->
                kotlin.math.abs(a.centerY - b.centerY) <= maxOf(a.height, b.height)
            } } }
        }

        internal fun observedRuleIndex(readings: List<List<VisibleQuestionReader.Node>>, transcript: QuizModelResult): Int? {
            val entry = transcript.options.singleOrNull { isRuleOption(it.text,it.index) } ?: return null
            for (lines in readings) {
                val stroke = lines.singleOrNull { it.continuousRule }?.box ?: continue
                val rows = optionRows(lines, transcript.options) ?: continue
                if (rows.getOrNull(entry.index) == stroke && matchesCloudStem(lines,transcript.question,rows.first())) return entry.index
            }
            return null
        }

        private fun control(lines: List<VisibleQuestionReader.Node>, labels: Set<String>): NormalizedBox? {
            val tokens = lines.filter { it.box != null }.sortedWith(compareBy({ it.box!!.centerY }, { it.box!!.x }))
            val matches = mutableListOf<NormalizedBox>()
            var i = 0
            while (i < tokens.size) {
                val head = tokens[i++]
                val box = head.box!!
                val word = label(head.text)
                val next = tokens.getOrNull(i)
                if (next != null && word + label(next.text) in labels) {
                    val b = next.box!!
                    val adjacentX = b.x - (box.x + box.width)
                    val adjacentY = b.y - (box.y + box.height)
                    val height = maxOf(box.height, b.height)
                    val oneLine = kotlin.math.abs(box.centerY - b.centerY) <= height * 0.45f && adjacentX in -0.5f..height
                    val wrapped = kotlin.math.abs(box.centerX - b.centerX) <= maxOf(box.width, b.width) * 0.4f && adjacentY in -0.5f..(height * 0.7f)
                    if (oneLine || wrapped) {
                        matches += box
                        i++
                        continue
                    }
                }
                if (word in labels) matches += box
            }
            return matches.distinct().singleOrNull()
        }
    }
}
