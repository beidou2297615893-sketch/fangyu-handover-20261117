import control as c
import json,sys
out=c.R/sys.argv[1]
response=json.loads((c.R/sys.argv[2]).read_text(encoding='utf-8'))
raw=response['choices'][0]['message']['content']
(out/'cloud-transcript.json').write_text(raw,encoding='utf-8')
pkg='com.jimusoft.dailyhundredapp.audit419.dev'
target='/data/user/0/'+pkg+'/files/ocr-transcript.json'
uid=c.adb('shell','stat','-c','%u','/data/user/0/'+pkg).decode().strip()
c.adb('push',out/'cloud-transcript.json',target)
c.adb('shell','chown',uid+':'+uid,target)
c.adb('shell','chmod','600',target)
c.adb('shell','restorecon',target)
print(c.adb('shell','am','instrument','-w','com.jimusoft.comparison.ocrprobe/com.jimusoft.comparison.OcrProbe').decode())
data=c.adb('exec-out','run-as',pkg,'cat','files/ocr-probe-result.json')
(out/'ocr-probe-result.json').write_bytes(data)
result=json.loads(data)
print(json.dumps(result,ensure_ascii=False,indent=2))
