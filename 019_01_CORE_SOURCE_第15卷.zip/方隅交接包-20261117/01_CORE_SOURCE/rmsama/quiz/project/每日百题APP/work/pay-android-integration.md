# 安卓付款集成准备与边界

2026-10-28。保留0.3.14版本与现有APK，未打包、未安装、未发布。

已实现：
- 复用现有原生AndroidKeyStore AES-GCM方案，付款身份、购买意图、待确认订单单独加密；AtomicFile原子落盘、同步及回读核验；放noBackupFilesDir避免恢复到其他设备后丢失密钥。
- native-store适配现有billing client；无原生模块或数据损坏时失败关闭，不降级localStorage。
- PaymentSession可测试状态控制器，返回前台入口只查服务端，并发合并；未真实配置或原生可信任务准入未就绪时拒绝创建订单。
- requiresReview从服务端完整透传；复核状态不呈现已确认。

仍关闭：套餐页购买按钮；已接入APP全局前后台监听，但发布runtime关闭且不发送付款请求；未配置实际后台域名/收银白名单；原生任务准入仍是前三次免费，没有付费准入。不能把这些准备描述为已上线支付或付款后自动开通。

接口契约（沿用client.ts，后端适配时需明确版本）：
- GET /status -> available、mode（正式环境不允许mock）。
- POST /installations -> installationId、accessToken；安装令牌只进加密存储。
- POST /orders -> planId、clientRequestId；金额由服务端决定，持久化意图后才请求。套餐ID现有UI为once/week/month，服务端必须对齐。
- POST /orders/{id}/reconcile -> 服务端主动查询支付宝并校验订单、金额、归属。
- GET /entitlements -> runCredits、validUntil、revision、recoverySupported:false、可选requiresReview。
- 客户端网页跳转只能打开明确HTTPS origin白名单。支付宝同步返回、深链和JS余额均不授予使用权限。

上线前必需补齐（不能以布尔配置代替实现）：
1. 后端支付宝验签异步通知、主动查单、金额/商户/订单归属校验及幂等权益事务。
2. 原生可信准入/服务端runId幂等消费、短租期或在线准入，服务端退款撤权与周期复核；暂停继续不重复扣次。
3. 明确设备丢失/重装恢复机制；当前recoverySupported:false不能承诺恢复。
4. 正式域名、支付宝appId及服务端私钥配置、notify/return白名单（APK不含私钥）。
5. 使用隔离测试订单验证杀进程、重复通知、迟到通知、退款、待复核、网络断开后再连接。
6. 已接入RootLayout全局AppState/Linking监听及返回导航；控制器checked仅说明订单核对完成，不等于原生开通。正式后端与原生可信准入、账户恢复协议验收后，才允许连接真实client；不能只翻开布尔配置。

支付宝渠道30天试用不等于赠送APP30天会员；本次没有添加免费会员。

本次验证：
- npm test：275/275通过（含21项付款客户端/安全适配/会话状态测试）。
- npm run typecheck：通过。
- 原生Debug离线编译：缺react-android/hermes调试AAR缓存；未能验证新Kotlin模块。
- 原生Release离线编译：既有react-native-worklets因中文源路径转义及incremental cache错误失败，尚未到新增Kotlin模块。未清理共享缓存或停止其他进程。日志：pay-native-compile.log。
- 未做真机Keystore落盘/杀进程验收，未使用真实订单或密钥。

补充验证：已建立纯ASCII隔离工程与独立Gradle依赖缓存。新增SecurePaymentStore.kt使用真实Android 36 API、Kotlin标准库独立编译成功（exit 0），生成SecurePaymentStore.class；不等于AndroidKeyStore运行时验收。隔离工程路径：C:/Users/rmsama/.codex/visualizations/2026/10/22/01a1625a-c763-7041-a77c-5a7cbdf2acd9/pay-android-check。仅编译验证，不生成APK。

最终补充：隔离ASCII工程的完整 :automation-bridge:compileReleaseKotlin 已成功，BUILD SUCCESSFUL in 2m 47s，59 tasks（39 executed）。新增SecurePaymentStore.class与更新的AutomationBridgeModule.class均已生成。日志release-kotlin.log；无需联网。只编译库模块，没有执行assemble、签名、安装、发布，不影响原APK。前文原目录失败记录是初始验证历史，最终原生release编译状态以本条为准。


2026-10-28 前后台恢复接线补充：
- 新增billing/lifecycle.ts：冷启动active、由后台回到active、匹配本App的付款返回URL才请求会话核对；重复active不重查；后台无轮询。卸载清理AppState/URL监听，晚到初始URL不再触发；初始URL失败无未处理异常。
- 新增billing/react.tsx与runtime.ts：RootLayout挂一个生命周期组件，套餐页订阅会话状态。运行时configured=false、nativeAdmissionReady=false，且没有可用付款client；不读生产环境变量，不允许通过深链打开闸门。
- 新增payment-return路由：只导航回plans，不解析支付状态或开通参数。URL中paid、余额、套餐等参数完全不进入授权决策。
- 新增4项生命周期/发布关闭闸门测试。npm test最新279/279通过；npm run typecheck通过。只有TypeScript/React接线变化，未重新编译原生或生成APK。
- 尚未验证安卓真实浏览器返回/杀进程运行时效果；生产无真实补查请求，因为可信支付服务、原生付费准入、退款撤权、账户恢复闭环仍未完成。这是已接线但关闭的准备状态，不是支付已上线。

2026-10-28 服务端合同复核与准入边界：
- 已实际读取official-website/backend/app/billing/api.py、store.py与test_billing_usage.py。现有/runs/reserve仅返回runId/source/status，confirm/release也是普通JSON；server_usage_enabled默认false。没有受原生验证的短租期/签名证据/原生提交证明合同，不能据此放行付费任务。
- 没有擅自新增或启用reserve、confirm、release调用，更没有把这些未闭环接口当成原生可信准入。现有native前三次免费检查保持。
- 会话已分离只读核对与购买准入：可在正式核对后台配置完成后查看既有订单，原生准入关闭时仍拒绝新收款。生产runtime目前configured=false，所有真实付款请求仍关闭。
- 新增跨模块测试：实际lifecycle→session→client组合使用服务端现有响应合同，验证pending→paid、认证头、伪造paid深链无效、前台/深链并发合并；请求白名单仅status、reconcile、entitlements，没有reserve/confirm/new-order/checkout或本地开通。
- 最新npm test：281/281通过；typecheck通过。测试使用纯合成服务返回，无真实密钥、网络或交易。未改APK、未重编原生。
- 真正剩余：服务端可供原生验证的准入协议与撤权机制、Android任务start/resume/提交与服务端幂等事务集成、安装身份恢复、正式支付宝配置/通知及真实端到端验收。当前只能称已完成安全关闭的查询/会话接线，不能称付款后自动开通已完成。
