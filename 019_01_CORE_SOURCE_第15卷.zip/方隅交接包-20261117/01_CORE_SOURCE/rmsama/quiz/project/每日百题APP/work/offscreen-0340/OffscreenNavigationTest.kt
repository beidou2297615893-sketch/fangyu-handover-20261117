package expo.modules.automationbridge

import expo.modules.automationbridge.bank.*
import expo.modules.automationbridge.generic.*
import expo.modules.automationbridge.runtime.*
import expo.modules.automationbridge.screen.*
import expo.modules.automationbridge.profile.*
import expo.modules.automationbridge.billing.PaidSubmissionGuard
import expo.modules.automationbridge.billing.PaidTarget

private val q=CanonicalQuestion("one","single","哪个数不等于零？",listOf(QuestionOption("a","0"),QuestionOption("b","1")),listOf("b"))
private val other=q.copy(id="two",stem="哪个数大于零？")
private val recognizer=GenericRecognizer(listOf(q,other))
private fun n(ref:String,text:String,y:Int,click:Boolean=false)=ScreenNode(ref,text,"","","TextView",Bounds(10,y,500,y+40),false,false,click)
private fun snap(vararg text:String,visual:String="pixels"):PageSnapshot {
  val root=n("0","",0).copy(role="FrameLayout",bounds=Bounds(0,0,600,1000))
  val regions=text.mapIndexed { i,t -> OcrRegion("ocr:$i",t,Bounds(30,100+i*80,550,140+i*80),"frame",1) }
  return PageSnapshot("frame",100,"org.target",1,listOf(root),regions,ScreenFingerprint.of("org.target",1,600,1000,listOf(root),regions),600,1000,visualFrame=visual)
}
private fun question(ordinal:Int,second:Boolean=false)=snap("$ordinal/2",if(second)other.stem else q.stem,"A. 0","B. 1","确认答案")
private fun pending()=RunFacts("run","ws","rev","__generic__",1,"hash",status="running",phase="submitting",total=2,
  pendingSubmit=true,pendingSubmissionId="actual-submit",pendingAt=100,lastOrdinal=1,
  lastFingerprint=QuestionMatcher.key(q.type,q.stem,q.options.map { it.text }))

fun main() {
  var failures=0;var passed=0
  fun test(name:String,body:()->Unit) { try { body();passed++;println("PASS $name") } catch(e:Throwable) { failures++;println("FAIL $name: ${e.message}") } }
  test("receipt does not require the offscreen next button") {
    check(recognizer.recognize(snap("回答正确")) is GenericObservation.Feedback)
  }
  test("completion and score remain authoritative when final navigation buttons are visible") {
    for(label in listOf("查看成绩","继续答题")) {
      val p=snap("答题已完成","得分：100",label)
      check(recognizer.recognize(p) is GenericObservation.Complete)
      val c=GenericCoordinator(recognizer,pending().copy(total=2,submittedCount=1,lastOrdinal=2)){_,_->}
      check(c.onPage(p,1000)==null && c.facts.status=="completed" && c.facts.submittedCount==2)
    }
  }
  test("pending submission scrolls down without inventing receipt or replacing submission identity") {
    val c=GenericCoordinator(recognizer,pending()){_,_->}
    val a=checkNotNull(c.onPage(snap("本题解析在页面下方"),1000))
    check(a.operation=="scroll_forward")
    check(c.facts.submittedCount==0 && c.facts.pendingSubmit && c.facts.submissionIntentId=="actual-submit")
  }
  test("receipt counts once then searches for next and never resubmits") {
    val c=GenericCoordinator(recognizer,pending()){_,_->}
    check(c.onPage(snap("回答正确"),1000)?.operation=="scroll_forward")
    check(c.facts.submittedCount==1 && !c.facts.pendingSubmit)
    c.onPage(snap("回答正确",visual="pixels-2"),2000)
    check(c.facts.submittedCount==1 && !c.facts.pendingSubmit)
  }
  test("automatic next question after a receipt cancels the obsolete next search") {
    val c=GenericCoordinator(recognizer,pending()){_,_->}
    check(c.onPage(snap("回答正确"),1000)?.operation=="scroll_forward")
    val action=checkNotNull(c.onPage(question(2),2000))
    check(action.operation=="click" && action.targetRef=="ocr:3" && c.facts.lastOrdinal==2 && c.facts.submittedCount==1)
  }
  test("explicit next progress with a partial screenshot restores the question top") {
    val c=GenericCoordinator(recognizer,pending()){_,_->}
    check(c.onPage(snap("题目进度：2/2","解析"),1000)?.operation=="scroll_backward")
    check(c.facts.pendingNavigation && !c.facts.pendingSubmit && c.facts.submittedCount==1)
    check(c.onPage(question(2,true),2000)?.operation=="click" && !c.facts.pendingNavigation)
  }
  test("receipt verification for paused or stopped runs never scrolls") {
    for(status in listOf("paused","stopped")) {
      val c=GenericCoordinator(recognizer,pending().copy(status=status)){_,_->}
      c.checkReceipt(500)
      check(c.onPage(snap("解析"),1000)==null && c.facts.pendingSubmit)
      check(c.onPage(snap("回答正确"),1500)==null)
      check(c.facts.status==status && c.facts.submittedCount==1)
    }
  }
  test("click next once and recover the top of the next question") {
    val c=GenericCoordinator(recognizer,pending()){_,_->}
    check(c.onPage(snap("回答正确","下一题"),1000)?.operation=="click")
    check(c.facts.pendingNavigation)
    check(c.onPage(snap("下一题"),2000)?.operation=="scroll_backward")
    check(c.onPage(snap("下一题",visual="different"),3000)?.operation!="click")
    check(c.facts.submittedCount==1)
    c.onPage(question(2,true),4000)
    check(!c.facts.pendingNavigation && c.facts.lastOrdinal==2)
  }
  test("scrolling or different OCR on the same ordinal cannot satisfy navigation") {
    val c=GenericCoordinator(recognizer,pending()){_,_->}
    c.onPage(snap("回答正确","下一题"),1000)
    val action=c.onPage(question(1,true),2000)
    check(action==null || action.operation=="scroll_backward")
    check(c.facts.pendingNavigation && c.facts.submittedCount==1)
  }
  test("search ends after no motion and preserves uncertainty") {
    val c=GenericCoordinator(recognizer,pending()){_,_->}
    repeat(8) { c.onPage(snap("解析"),1000L+it*1000) }
    check(c.facts.status=="paused" && c.facts.pendingSubmit && c.facts.submissionIntentId=="actual-submit" && c.facts.submittedCount==0)
  }
  test("sensitive and ambiguous next pages never authorize scrolling or tapping") {
    for(p in listOf(snap("请输入密码"),snap("回答正确","下一题","下一题"))) {
      val c=GenericCoordinator(recognizer,pending()){_,_->}
      check(c.onPage(p,1000)==null && c.facts.status=="paused")
    }
  }
  test("first receipt settlement blocks scrolling and navigation") {
    var allowed=true
    val c=GenericCoordinator(recognizer,pending(),{allowed}){_,_->}
    c.onPage(snap("回答正确"),1000)
    allowed=false
    check(c.onPage(snap("下一题"),2000)==null && c.facts.submittedCount==1)
  }
  test("partial question recovery is durable before the first paid receipt settlement gate closes") {
    var allowed=true
    val partial=snap("题目进度：2/2","解析")
    var before=pending()
    val target=PaidTarget("org.target",1,"signer")
    val c=GenericCoordinator(recognizer,pending(),{allowed}){ facts,_ ->
      if(before.pendingSubmit && facts.submittedCount==1 && !facts.pendingSubmit) {
        PaidSubmissionGuard.validateReceipt(before,facts,target,target)
        allowed=false
      }
      before=facts
    }
    check(c.onPage(partial,1000)==null)
    check(c.facts.submittedCount==1 && !c.facts.pendingSubmit && c.facts.pendingNavigation)
    check(c.onPage(partial,1500)==null)
    val persisted=RunCodec.decode(RunCodec.encode(c.facts))
    allowed=true
    val continued=GenericCoordinator(recognizer,persisted,{allowed}){_,_->}
    check(continued.onPage(partial,2000)?.operation=="scroll_backward")
    check(continued.facts.submittedCount==1 && !continued.facts.pendingSubmit)
  }
  test("a read-only partial receipt never creates navigation recovery authority") {
    val c=GenericCoordinator(recognizer,pending().copy(status="stopped")){_,_->}
    c.checkReceipt(500)
    check(c.onPage(snap("题目进度：2/2","解析"),1000)==null)
    check(c.facts.status=="stopped" && c.facts.submittedCount==1 && !c.facts.pendingNavigation && c.facts.viewportSearch==null)
  }
  test("stop rejects late pages without additional commands") {
    val c=GenericCoordinator(recognizer,pending()){_,_->}
    c.onPage(snap("解析"),1000);c.stop()
    check(c.onPage(snap("回答正确","下一题"),2000)==null && c.facts.status=="stopped" && c.facts.submittedCount==0)
  }
  test("scroll search persists through restart but only explicit resume can continue") {
    val c=GenericCoordinator(recognizer,pending()){_,_->}
    c.onPage(snap("回答正确"),1000)
    val restored=RunCodec.decode(RunCodec.encode(c.facts)).recoverAfterRestart("restarted")
    val resumed=GenericCoordinator(recognizer,restored){_,_->}
    check(resumed.onPage(snap("下一题"),2000)==null)
    resumed.resume(3000)
    check(resumed.onPage(snap("下一题"),4000)?.operation=="click" && resumed.facts.pendingNavigation && resumed.facts.submittedCount==1)
  }
  test("a changed window does not inherit a scroll grant") {
    val c=GenericCoordinator(recognizer,pending()){_,_->}
    c.onPage(snap("解析"),1000)
    check(c.onPage(snap("解析").copy(windowId=2),2000)==null && c.facts.status=="paused" && c.facts.pendingSubmit)
  }
  test("native scroll container is used before viewport gestures") {
    val p=snap("解析").let { it.copy(nodes=it.nodes.map { node->node.copy(scrollable=true) }) }
    val c=GenericCoordinator(recognizer,pending()){_,_->}
    val action=checkNotNull(c.onPage(p,1000))
    check(action.targetRef=="0" && action.operation=="scroll_forward" && action.purpose=="scroll")
  }
  test("only the internal generic profile grants native backward scrolling") {
    val p=ProfileDefinition("__generic__",version=1,target=TargetPolicy("org.target"),pages=emptyMap(),
      steps=listOf(WorkflowStep("action","scroll_backward","action")),selectors=mapOf("action" to NodeSelector(role="ScrollView")),resultPolicy=ResultPolicy("action"))
    check(WorkflowValidator.validate(p).valid)
    check(!WorkflowValidator.validate(p.copy(id="external")).valid)
  }
  test("empty OCR can reacquire pixels only for this running submission or confirmed navigation search") {
    val empty=ScreenReadException("OCR_NO_TEXT","empty")
    check(BlankReadRecovery.allows(empty,pending()))
    check(BlankReadRecovery.allows(empty,pending().copy(pendingSubmit=false,pendingNavigation=true,submittedCount=1)))
    check(BlankReadRecovery.allows(empty,pending().copy(pendingSubmit=false,submittedCount=1,
      viewportSearch=ViewportSearch("finding_next",1,"frame",1,0,100))))
  }
  test("unstarted read-only and protected pages never gain blank screenshot recovery") {
    val empty=ScreenReadException("OCR_NO_TEXT","empty")
    for(f in listOf(pending().copy(status="ready"),pending().copy(status="stopped"),pending().copy(receiptCheckReturnStatus="paused"),
      pending().copy(pendingSubmit=false,submittedCount=0),pending().copy(pendingSubmit=false,pendingNavigation=true,submittedCount=0))) {
      check(!BlankReadRecovery.allows(empty,f))
    }
    for(code in listOf("SCREENSHOT_PROTECTED","WRONG_FOREGROUND","SENSITIVE_PAGE","FRAME_CHANGED","NO_WINDOW"))
      check(!BlankReadRecovery.allows(ScreenReadException(code,"blocked"),pending()))
    check(!BlankReadRecovery.allows(IllegalStateException("OCR_NO_TEXT"),pending()))
  }
  test("observed result-button OCR glyphs navigate only after the receipt and retain original grounding") {
    for(word in listOf("查看戌绩","查看戍绩","査看戍绩","査看戌绩","査看成绩")) {
      val p=snap(word)
      val c=GenericCoordinator(recognizer,pending()){_,_->}
      c.onPage(snap("回答正确"),1000)
      val action=checkNotNull(c.onPage(p,2000))
      check(action.operation=="click" && action.purpose=="next" && action.targetRef=="ocr:0")
      check(action.targetText==word && SelectorMatcher.allNodes(p).single { it.ref==action.targetRef }.bounds==Bounds(30,100,550,140))
      check(c.facts.pendingNavigation && c.facts.submittedCount==1)
    }
  }
  test("result-button glyph repairs never turn question content or unconfirmed text into navigation") {
    val word="查看戌绩"
    val contentQuestion=q.copy(stem=word)
    val contentRecognizer=GenericRecognizer(listOf(contentQuestion))
    val stemPage=snap("1/2",word,"A. 0","B. 1","确认答案")
    val optionPage=snap("1/2","哪个词是正确的？","A. 查看戌绩","B. 其他","确认答案")
    for(p in listOf(stemPage,optionPage,snap(word))) {
      val noReceipt=GenericCoordinator(contentRecognizer,pending().copy(pendingSubmit=false,status="running",submittedCount=0)){_,_->}
      val action=noReceipt.onPage(p,1000)
      check(action?.purpose!="next")
      if(action!=null) check(action.targetRef!="ocr:1" || action.targetText!=word)
    }
    val c=GenericCoordinator(contentRecognizer,pending().copy(pendingSubmit=false,submittedCount=1,
      viewportSearch=ViewportSearch("finding_next",1,"frame",0,0,100))){_,_->}
    check(c.onPage(snap("回答正确",word,"A. 0","B. 1"),1000)?.purpose!="next")
    for(near in listOf("查看戌级","查看成积","查看戌绩说明","立即查看戌绩")) {
      val search=GenericCoordinator(recognizer,pending().copy(pendingSubmit=false,submittedCount=1,
        viewportSearch=ViewportSearch("finding_next",1,"frame",0,0,100))){_,_->}
      check(search.onPage(snap(near),1000)?.purpose!="next")
    }
  }
  println("Offscreen navigation: $passed passed, $failures failed")
  check(failures==0)
}
