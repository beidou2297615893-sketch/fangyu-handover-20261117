from pathlib import Path
import json
d=Path(__file__).parent
rules=json.loads((d/'line-rois.json').read_text(encoding='utf8'))
out=[]
for r in json.loads((d/'raw-mosaic.json').read_text(encoding='utf8')):
 rule=rules[r['file']];recovered=[]
 for line in r['lines']:
  x,y,w,h=line['box'];sw=rule['sw']; sh=rule['sh']; left=x*sw/100;right=(x+w)*sw/100;top=y*sh/100;bot=(y+h)*sh/100;xc=(left+right)/2;yc=(top+bot)/2
  tile=next((v for v in rule['rows'] if v['tile'][0]<=xc<=v['tile'][2] and v['tile'][1]<=yc<=v['tile'][3]),None)
  if not tile:continue
  tx,ty,rx,by=tile['tile'];sx,sy,sr,sb=tile['source'];ow=rule['w'];oh=rule['h']
  px=lambda x:max(0,min(100,100*(sx+(x-tx)*(sr-sx)/(rx-tx))/ow))
  py=lambda y:max(0,min(100,100*(sy+(y-ty)*(sb-sy)/(by-ty))/oh))
  l=px(left);t=py(top);rr=px(right);bb=py(bot)
  if l<rr and t<bb:recovered.append(dict(text=line['text'],box=[l,t,min(rr-l,100-l-0.0001),min(bb-t,100-t-0.0001)]))
 out.append(dict(file=r['file'].removeprefix('mosaic-'),lines=recovered))
(d/'lines-lineMosaic.json').write_text(json.dumps(out,ensure_ascii=False),encoding='utf8')
