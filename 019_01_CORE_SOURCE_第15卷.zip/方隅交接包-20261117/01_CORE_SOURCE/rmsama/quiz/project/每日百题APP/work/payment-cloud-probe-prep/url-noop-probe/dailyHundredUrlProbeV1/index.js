'use strict';

// Intentionally ignores every input. No database, credentials or network calls.
exports.main = async function main() {
  return {
    statusCode: 503,
    headers: { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' },
    body: '{"paymentEnabled":false}'
  };
};
