'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict');
const {createProbe}=require('./isolated-probe');
function fakeDb(){
  const rows=new Map(),collections=[];
  const db={async runTransaction(fn){const snapshot=new Map(rows);try{return await fn({collection(name){collections.push(name);return {doc(id){return {
    async get(){return {data:rows.has(id)?{_id:id,...rows.get(id)}:null};},
    async set(value){rows.set(id,value);return {updated:1};},
    async remove(){const existed=rows.delete(id);return {deleted:existed?1:0};}
  };}};}});}catch(e){rows.clear();for(const [k,v] of snapshot)rows.set(k,v);throw e;}}};
  return {db,rows,collections};
}
test('only authenticated direct invocation performs isolated rollback-free transaction and fixed provider TLS probe',async()=>{
  const f=fakeDb();let calls=0;
  const probe=createProbe({db:f.db,httpsHead:async()=>{calls++;return true;},randomId:()=> '1234567890abcdef1234567890abcdef'});
  const result=await probe({action:'diagnostic'});
  assert.deepEqual(result,{paymentEnabled:false,database:true,alipayTls:true});assert.equal(calls,1);assert.equal(f.rows.size,0);
  assert.ok(f.collections.every(v=>v==='daily_hundred_payment_probe_v1'));
});
test('HTTP-shaped, unknown and malformed events cannot trigger writes or egress',async()=>{
  const f=fakeDb();let calls=0;const probe=createProbe({db:f.db,httpsHead:async()=>{calls++;return true;}});
  for(const event of [{action:'diagnostic',httpMethod:'POST'},{action:'diagnostic',path:'/api/billing/status'},{action:'payment'},null,{action:'diagnostic',other:true}])assert.deepEqual(await probe(event),{paymentEnabled:false});
  assert.equal(calls,0);assert.equal(f.rows.size,0);assert.equal(f.collections.length,0);
});
test('failed TLS or database probes remain disabled and do not leak exception details',async()=>{
  const f=fakeDb(),probe=createProbe({db:f.db,httpsHead:async()=>{throw Error('private diagnostic error');}});
  assert.deepEqual(await probe({action:'diagnostic'}),{paymentEnabled:false,database:true,alipayTls:false});
  const failed=createProbe({db:{runTransaction:async()=>{throw Error('private db error')}},httpsHead:async()=>true});
  assert.deepEqual(await failed({action:'diagnostic'}),{paymentEnabled:false,database:false,alipayTls:true});
});
