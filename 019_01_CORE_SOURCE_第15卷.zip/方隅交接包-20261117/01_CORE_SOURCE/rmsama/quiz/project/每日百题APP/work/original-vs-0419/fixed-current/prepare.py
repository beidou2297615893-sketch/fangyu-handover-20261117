from pathlib import Path
import shutil, re, hashlib, json

origin = Path('V:/work/tijing-bankassist')
root = Path(__file__).resolve().parent
copy = root / 'source'
copy.mkdir(parents=True, exist_ok=True)
for name in ['src', 'public', 'scripts', 'tests', 'android']:
    shutil.copytree(origin/name, copy/name, dirs_exist_ok=True,
        ignore=shutil.ignore_patterns('build', '.gradle', 'node_modules', 'local.properties', '*.jks', '*.keystore'))
for name in ['package.json','package-lock.json','index.html','vite.config.js','LICENSE','.gitignore']:
    shutil.copy2(origin/name, copy/name)

gradle = copy/'android/app/build.gradle.kts'
text = gradle.read_text(encoding='utf-8')
text = text.replace('applicationId = "com.jimusoft.dailyhundredapp"', 'applicationId = "com.jimusoft.dailyhundredapp.audit419"')
text = text.replace('val originalBillingOrigin = "https://1439321968-1w2zycn1o6.ap-shanghai.tencentscf.com"', 'val originalBillingOrigin = "http://127.0.0.1:18765/diagnostic-billing-disabled"')
text += '''
// Diagnostic-copy-only: normal shipping tasks cannot build this fixture.
android {
    sourceSets.getByName("main").java.setSrcDirs(emptyList<String>())
    sourceSets.getByName("debug").java.setSrcDirs(listOf("src/diagnosticShared/java", "src/diagnosticDebug/java"))
}
androidComponents {
    beforeVariants(selector().all()) { variant ->
        variant.enable = variant.buildType == "debug" && variant.productFlavors.any { it.second == "dev" }
    }
}
kotlin.sourceSets.getByName("main").kotlin.setSrcDirs(emptyList<String>())
'''
gradle.write_text(text,encoding='utf-8')
props=copy/'android/gradle.properties'
props.write_text(props.read_text(encoding='utf-8')+'\nandroid.overridePathCheck=true\n', encoding='utf-8')
debug = copy/'android/app/src/diagnosticDebug/java/com/futureyyy/tijing/payment'
debug.mkdir(parents=True,exist_ok=True)
shared = copy/'android/app/src/diagnosticShared/java'
for file in (origin/'android/app/src/main/java').rglob('*.kt'):
    if file.name in {'AndroidPayment.kt','GatewaySessionEntry.kt'}: continue
    target=shared/file.relative_to(origin/'android/app/src/main/java')
    target.parent.mkdir(parents=True,exist_ok=True)
    shutil.copy2(file,target)
gatewaypolicy=(origin/'android/app/src/main/java/com/futureyyy/tijing/payment/GatewaySessionEntry.kt').read_text(encoding='utf-8')
policy_at=gatewaypolicy.find('internal fun gatewayEndAction(')
if policy_at>=0:
    policyfile=shared/'com/futureyyy/tijing/payment/GatewayRecoveryPolicy.kt'
    policyfile.write_text('package com.futureyyy.tijing.payment\n\nimport org.json.JSONObject\n\n'+gatewaypolicy[policy_at:],encoding='utf-8')
payment = (origin/'android/app/src/main/java/com/futureyyy/tijing/payment/AndroidPayment.kt').read_text(encoding='utf-8')
start=payment.index('class AndroidBillingTransport:BillingTransport {')
end=payment.index('class AndroidPaymentRecords',start)
fixture='''class AndroidBillingTransport:BillingTransport {
    override fun request(path:String,method:String,body:JSONObject?,identity:BillingIdentity?):JSONObject {
        check(com.futureyyy.tijing.BuildConfig.DEBUG && com.futureyyy.tijing.BuildConfig.APPLICATION_ID == "com.jimusoft.dailyhundredapp.audit419.dev")
        if(path == "/status") return JSONObject().put("available",false).put("testing",true).put("synthetic",true).put("realPaymentsEnabled",false).put("taskAdmissionEnabled",false)
        throw PaymentFailure("ISOLATED_DIAGNOSTIC_ONLY", "隔离验收：真实付款和正式账本不可访问。")
    }
}

'''
debugpayment=payment[:start]+fixture+payment[end:]
needle='    fun request(operation:String,payload:JSONObject,done:(Result<JSONObject>)->Unit) {'
debugpayment=debugpayment.replace(needle,needle+'''
        check(com.futureyyy.tijing.BuildConfig.DEBUG && app.packageName == "com.jimusoft.dailyhundredapp.audit419.dev")
        if(operation == "status" || operation == "refresh") {
            val view=JSONObject().put("available",false).put("paymentAvailable",false).put("paidAdmissionAvailable",false)
                .put("testing",true).put("synthetic",true).put("plans",org.json.JSONArray())
                .put("entitlement",JSONObject().put("runCredits",1).put("validUntil",JSONObject.NULL).put("revision",0).put("recoverySupported",false))
                .put("freeRemaining",0).put("pendingPayment",JSONObject.NULL)
                .put("remainingText","隔离验收：本地模拟权益，不计正式额度")
                .put("message","仅用于专用铁路宿主验收，真实付款已禁用")
            main.post { done(Result.success(view)) };return
        }
''')
(debug/'AndroidPayment.kt').write_text(debugpayment,encoding='utf-8')
(debug/'GatewaySessionEntry.kt').write_text('''package com.futureyyy.tijing.payment

import android.content.Context
import android.os.Handler
import android.os.Looper
import java.util.UUID

/** Isolated debug fixture only. No production account, token, ledger or HTTP session. */
class GatewaySession internal constructor(val runId:String,val endpoint:String,val model:String,val apiKey:String,val expiresAt:Long) {
    override fun toString()="GatewaySession(isolated-debug-fixture)"
}
object GatewaySessionEntry {
    private val main=Handler(Looper.getMainLooper())
    private fun isolated(context:Context) {
        check(com.futureyyy.tijing.BuildConfig.DEBUG && context.packageName == "com.jimusoft.dailyhundredapp.audit419.dev")
    }
    private fun prefs(context:Context)=context.getSharedPreferences("isolated-diagnostic-only",Context.MODE_PRIVATE)
    fun getOrCreateRunId(context:Context,targetPackage:String):String {
        isolated(context)
        require(targetPackage in setOf("com.jimusoft.railwaymp.canvas419","com.jimusoft.railwaymp")) { "隔离验收只允许专用铁路宿主。" }
        val p=prefs(context)
        return p.getString("runId",null) ?: ("diag-"+UUID.randomUUID()).also { check(p.edit().putString("runId",it).commit()) }
    }
    fun begin(context:Context,runId:String,targetPackage:String,done:(Result<GatewaySession>)->Unit) {
        val result=runCatching {
            isolated(context)
            require(targetPackage in setOf("com.jimusoft.railwaymp.canvas419","com.jimusoft.railwaymp") && prefs(context).getString("runId",null)==runId)
            android.util.Log.i("ZhitiDiagnostic","LOCAL_FIXTURE_ADMISSION no production ledger; visual endpoint is loopback only")
            GatewaySession(runId,"http://127.0.0.1:18765/v1/chat/completions","deepseek-flash","isolated-diagnostic-no-authority",System.currentTimeMillis()+12*60*60*1000)
        }
        main.post { done(result) }
    }
    internal fun hasPendingEnd(context:Context):Boolean { isolated(context);return false }
    internal fun retryPendingEndOnWorker(context:Context) { isolated(context) }
    fun close(context:Context,session:GatewaySession,done:(Result<Unit>)->Unit) = closePending(context,done)
    fun closePending(context:Context,done:(Result<Unit>)->Unit) {
        val result=runCatching { isolated(context); check(prefs(context).edit().remove("runId").commit()); Unit }
        main.post { done(result) }
    }
}
''',encoding='utf-8')
debugsrc=copy/'android/app/src/debug'
(debugsrc/'res/values').mkdir(parents=True,exist_ok=True)
(debugsrc/'res/values/diagnostic.xml').write_text('<resources><string name="app_name">知题·隔离验收</string></resources>',encoding='utf-8')
(debugsrc/'AndroidManifest.xml').write_text('''<manifest xmlns:android="http://schemas.android.com/apk/res/android" xmlns:tools="http://schemas.android.com/tools"><application android:networkSecurityConfig="@xml/diagnostic_network_security" android:usesCleartextTraffic="true" tools:replace="android:networkSecurityConfig,android:usesCleartextTraffic" /></manifest>''',encoding='utf-8')
(debugsrc/'res/xml').mkdir(parents=True,exist_ok=True)
(debugsrc/'res/xml/diagnostic_network_security.xml').write_text('''<network-security-config><base-config cleartextTrafficPermitted="false"/><domain-config cleartextTrafficPermitted="true"><domain>127.0.0.1</domain><domain>localhost</domain></domain-config></network-security-config>''',encoding='utf-8')
(debugsrc/'assets').mkdir(parents=True,exist_ok=True)
shutil.copy2(origin/'android/app/src/main/assets/question-bank.json',debugsrc/'assets/question-bank.json')

proof=[]
for file in (origin/'android/app/src/main/java').rglob('*.kt'):
    relative=file.relative_to(origin)
    proof.append({'path':str(relative),'sha256':hashlib.sha256(file.read_bytes()).hexdigest(),'mainCopyUnchanged':file.read_bytes()==(copy/relative).read_bytes()})
(root/'source-copy-proof.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2),encoding='utf-8')
print('Copied current product main Kotlin unchanged:',all(x['mainCopyUnchanged'] for x in proof),len(proof))
print('Source:',copy)



