param([switch]$Apply)
$ErrorActionPreference='Stop'
$envId='fh6-d5ga45c0ddae7008c';$region='ap-shanghai'
$fn='dailyHundredPaymentProbeV1';$collection='daily_hundred_payment_probe_v1'
$tcb=(Get-Command tcb.ps1 -ErrorAction Stop).Source
$source=Join-Path $PSScriptRoot $fn
$config=Join-Path $PSScriptRoot 'cloudbaserc.json'
$upstream=Join-Path (Split-Path $PSScriptRoot -Parent) 'payment-cloud-native/isolated-probe.js'
& (Join-Path $PSScriptRoot 'preflight.ps1')
if((Get-FileHash -Algorithm SHA256 -LiteralPath $upstream).Hash -ne (Get-FileHash -Algorithm SHA256 -LiteralPath (Join-Path $source 'isolated-probe.js')).Hash){throw '探针源码与已审核版本不同，停止。'}
$package=Get-Content -LiteralPath (Join-Path $source 'package.json') -Raw -Encoding UTF8 | ConvertFrom-Json
$sdk=Get-Content -LiteralPath (Join-Path $source 'node_modules/@cloudbase/node-sdk/package.json') -Raw -Encoding UTF8 | ConvertFrom-Json
if($package.dependencies.'@cloudbase/node-sdk' -ne '3.18.7' -or $sdk.version -ne '3.18.7'){throw '隔离探针依赖版本异常，停止。'}
if(@(Get-ChildItem -LiteralPath $source -Recurse -Force -File | Where-Object {$_.Name -match '(?i)^\.env($|\.)|private.*\.(pem|key)$|credentials?\.json$'}).Count){throw '探针目录包含不允许的凭据文件，停止。'}
function CallJson([string[]]$arguments) {
  $raw=@(& $tcb @arguments --json 2>$null) -join "`n";$exitCode=$LASTEXITCODE
  $i=$raw.IndexOf('{');$parsed=$null
  if($i -ge 0){try{$parsed=$raw.Substring($i)|ConvertFrom-Json}catch{}}
  if($exitCode -ne 0 -or !$parsed -or !$parsed.data){throw '云操作未确认成功，禁止自动重试或清理；必须只读复查对应资源。'}
  return $parsed.data
}
function FunctionSnapshot() {
  $all=@(CallJson @('fn','list','-e',$envId,'--limit','100'))
  if($all.Count -ge 100){throw '函数列表可能不完整，停止。'}
  return @($all|Where-Object {$_.name -ne $fn}|Sort-Object name|Select-Object functionId,name,runtime,modifyTime,status)
}
function RouteSnapshot() {
  $all=@(CallJson @('routes','list','-e',$envId,'--limit','100'))
  if($all.Count -ge 100){throw '路由列表可能不完整，停止。'}
  return @($all|Sort-Object domain,path|Select-Object domain,path,upstreamResourceName,upstreamResourceType,enable,enableAuth,enablePathTransmission)
}
$beforeFunctions=ConvertTo-Json -InputObject @(FunctionSnapshot) -Depth 5 -Compress
$beforeRoutes=ConvertTo-Json -InputObject @(RouteSnapshot) -Depth 5 -Compress
if(!$Apply){
  Write-Output "已建立既有函数和路由的本地只读比对基线。仅计划：新建集合 $collection（ADMINONLY）、新建函数 $fn（Event），仅 IAM 调用一次；不创建 HTTP 路由或 Function URL。"
  Write-Output '再次调用并显式指定 -Apply 才会执行以上云端操作；本次未执行。'
  return
}
Write-Output '创建专用空集合；如响应不明确，将停止并只读复查。'
$create=@{EnvId=$envId;TableName=$collection;PermissionInfo=@{AclTag='ADMINONLY';EnvId=$envId}}|ConvertTo-Json -Depth 3 -Compress
try { [void](CallJson @('api','tcb','CreateTable','-r',$region,'--api-version','2018-06-08','--body',$create)) }
catch { Write-Output '集合创建结果不明；请执行只读预检确认，禁止重复创建。';throw }
try {
  $permission=CallJson @('permission','get',("collection:"+$collection),'-e',$envId)
  $entry=@($permission.PermissionList|Where-Object {$_.Resource -eq $collection})
  if($entry.Count -ne 1 -or $entry[0].Permission -ne 'ADMINONLY'){throw '集合权限不是明确的 ADMINONLY，停止部署。'}
} catch { Write-Output '集合已建立但权限未获确认，尚未部署函数；不自动修改或删除。';throw }
Write-Output '创建专用 Event 函数；不配置密钥，不设置任何 HTTP 入口。'
Push-Location $PSScriptRoot
try {
  $response=@(& $tcb fn deploy $fn -e $envId --dir $source --runtime 'Nodejs20.19' --deployMode cos --config-file $config --json 2>$null) -join "`n"
  if($LASTEXITCODE -ne 0){Write-Output '部署命令未确认成功；可能已创建函数。禁止自动重试，请只读查询后再处理。';throw '部署结果不明'}
} finally { Pop-Location }
$functionBody=@{FunctionName=$fn;Namespace=$envId}|ConvertTo-Json -Compress
$detail=$null
for($attempt=0;$attempt -lt 15;$attempt++){
  try {$detail=CallJson @('api','scf','GetFunction','-r',$region,'--api-version','2018-04-16','--body',$functionBody)} catch {$detail=$null}
  if($detail -and $detail.Status -eq 'Active'){break}
  Start-Sleep -Seconds 2
}
if(!$detail){throw '函数状态未能读取；请先只读核对，禁止重试部署。'}
if($null -eq $detail.Environment){throw '无法检查函数环境变量，未调用。'}
$variables=@($detail.Environment.Variables | Where-Object {$null -ne $_})
if($detail.FunctionName -ne $fn -or $detail.Namespace -ne $envId -or $detail.Type -ne 'Event' -or $detail.Runtime -ne 'Nodejs20.19' -or $detail.Handler -ne 'isolated-probe.main' -or $detail.Status -ne 'Active' -or $variables.Count -gt 0){throw '函数配置与隔离要求不一致或尚未就绪，未调用；请人工只读核对。'}
$triggerBody=@{FunctionName=$fn;Namespace=$envId;Limit=30;Offset=0}|ConvertTo-Json -Compress
$triggers=CallJson @('api','scf','ListTriggers','-r',$region,'--api-version','2018-04-16','--body',$triggerBody)
if($triggers.TotalCount -ne 0){throw '发现函数触发器，未调用；请人工只读核对。'}
$afterFunctions=ConvertTo-Json -InputObject @(FunctionSnapshot) -Depth 5 -Compress
$afterRoutes=ConvertTo-Json -InputObject @(RouteSnapshot) -Depth 5 -Compress
if($beforeFunctions -cne $afterFunctions -or $beforeRoutes -cne $afterRoutes){throw '既有函数或路由元数据发生变化，未调用探针；请先只读核对。'}
Write-Output '既有函数与路由的受检元数据未变化。'
$data=@{action='diagnostic'}|ConvertTo-Json -Compress
$result=CallJson @('fn','invoke',$fn,'-e',$envId,'-d',$data)
if($result.functionType -ne 'Event' -or $result.InvokeResult -ne 0 -or !($result.RetMsg -is [string])){throw '探针调用失败或返回格式异常；不打印日志或重试。'}
try {$probe=$result.RetMsg|ConvertFrom-Json} catch {throw '探针响应无法解析；不打印原始日志或重试。'}
if($probe.paymentEnabled -ne $false -or $probe.database -isnot [bool] -or $probe.alipayTls -isnot [bool]){throw '探针响应不符合预期；不打印原始响应或重试。'}
[pscustomobject]@{paymentEnabled=$false;database=$probe.database;alipayTls=$probe.alipayTls}|ConvertTo-Json -Compress
