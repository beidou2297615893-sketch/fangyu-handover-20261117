package review
import expo.modules.automationbridge.bank.*
import expo.modules.automationbridge.generic.*
import expo.modules.automationbridge.runtime.*
import expo.modules.automationbridge.screen.*
private val q=CanonicalQuestion("one","single","哪个数不等于零？",listOf(QuestionOption("a","0"),QuestionOption("b","1")),listOf("b"))
private val r=GenericRecognizer(listOf(q))
private fun snap(vararg texts:String):PageSnapshot {
 val root=ScreenNode("0","","","","FrameLayout",Bounds(0,0,600,1000),false,false,false)
 val o=texts.mapIndexed {i,t->OcrRegion("ocr:$i",t,Bounds(30,100+i*80,550,140+i*80),"frame",1)}
 return PageSnapshot("frame",100,"org.target",1,listOf(root),o,ScreenFingerprint.of("org.target",1,600,1000,listOf(root),o),600,1000,visualFrame="pixels")
}
private fun facts()=RunFacts("run","ws","rev","__generic__",1,"hash",status="running",phase="submitting",total=2,pendingSubmit=true,pendingSubmissionId="submit",pendingAt=100,lastOrdinal=1,lastFingerprint=QuestionMatcher.key(q.type,q.stem,q.options.map {it.text}))
fun main(){
 println("completion-with-score-button: "+r.recognize(snap("答题完成","查看成绩")))
 val c=GenericCoordinator(r,facts()){_,_->}
 c.onPage(snap("回答正确"),1000)
 println("after receipt: "+c.facts.phase)
 val newQuestion=snap("2/2",q.stem,"A. 0","B. 1","确认答案")
 println("recognized new question: "+r.recognize(newQuestion))
 println("next action after auto advance: "+c.onPage(newQuestion,2000))
 println("after automatic next question: "+c.facts.phase+", pendingNavigation="+c.facts.pendingNavigation)
}
