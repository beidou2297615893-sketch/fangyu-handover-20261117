from pathlib import Path
import json,re,itertools,unicodedata as u
from PIL import Image
import cv2,numpy as np
root=Path(__file__).parent; h=root.parent/"hd100";m=json.loads((h/"replay-manifest.json").read_text())["rows"];q=m[-1]; raws=json.loads((h/"replay-paddle.json").read_text());lines=[s for row in raws if row["file"].endswith(q["file"]) for s in row["lines"] if s["box"][1]>36]
def text_options(options):
 p=[]; values=[]
 for word in options:
  match=re.fullmatch(r"(.+?)[,，、:： ]+(IV|III|II|I)",u.normalize("NFKC",word))
  if not match:return None
  p.append(match[1]);values.append(match[2])
 return (p[0],set(values)) if len(set(p))==1 and len(values)==len(set(values)) and set(values)==set(["I","II","III","IV"]) else None
def read(im,lines,options):
 bank=text_options(options)
 if bank is None or len(lines)!=4:return None
 prefix,expected=bank; entries=[];w,h=im.size
 for line in lines:
  raw=u.normalize("NFKC",line["text"])
  if not re.fullmatch(re.escape(prefix)+r"[,，、:： ]+[IV1丨|]+",raw):return None
  x,y,b,c=line["box"];left=max(0,int(x*w/100)-3); top=max(0,int(y*h/100)-3);crop=np.asarray(im.crop((left,top,int((x+b)*w/100)+3,int((y+c)*h/100)+3)).convert("L")); dark=(crop<140).astype("uint8"); count,labels,stats,ctr=cv2.connectedComponentsWithStats(dark)
  parts=sorted((tuple(map(int,stats[i])) for i in range(1,count) if stats[i,4]>=7), key=lambda v:v[0])
  # Rightmost cluster separated by a material blank from a confirmed, identical prefix.
  largest=crop.shape[0];right=max(p[0]+p[2] for p in parts);delim=None
  for i in range(1,len(parts)):
   gap=parts[i][0]-max(p[0]+p[2] for p in parts[:i])
   if gap>largest*.40 and parts[i][0]>crop.shape[1]*.55:delim=i
  if delim is None:return None
  suffix=parts[delim:];word=[]
  prefixInk=np.asarray(dark[:,:max(p[0]+p[2] for p in parts[:delim])])
  conf=[]
  for x0,y0,bw,bh,area in suffix:
   if bh<16:return None
   patch=dark[y0:y0+bh,x0:x0+bw]
   if bw/bh<=.19 and area/(bw*bh)>.88:
    word.append("I");conf.append([bw,bh]);continue
   topLeft=np.flatnonzero(patch[int(bh*.1)]) ;bottom=np.flatnonzero(patch[int(bh*.88)]);mid=np.flatnonzero(patch[bh//2])
   if len(topLeft)<2 or len(bottom)<2 or not len(mid):return None
   if (max(topLeft)-min(topLeft))>bw*.70 and (max(bottom)-min(bottom))<bw*.50 and (max(bottom)-min(bottom))<(max(mid)-min(mid))<(max(topLeft)-min(topLeft)) and abs(np.mean(bottom)-(bw-1)/2)<bw*.2:
    word.append("V");conf.append([bw,bh]);continue
   return None
  entries.append(("".join(word),conf,line["box"],prefixInk))
 if set(x[0] for x in entries)!=expected:return None
 # Same font, size, and baseline; identical prefix raster after position adjustment.
 p=entries[0][3]
 if any(t[3].shape !=p.shape or np.mean(t[3]!=p)>.045 for t in entries):return None
 strokes=[wh for s,ws,_,_ in entries for ch,wh in zip(s,ws) if ch=="I"]
 if max(w for w,h in strokes)-min(w for w,h in strokes)>1 or max(h for w,h in strokes)-min(h for w,h in strokes)>1:return None
 return [x[0] for x in entries]
opts=[v["text"] for v in q["options"]];im=Image.open(q["sourcePath"])
out=read(im,lines,opts); assert out==["IV","III","II","I"],out
for perm in itertools.permutations(range(4)):
 assert read(im,[lines[i] for i in perm],opts)==[out[i] for i in perm]
assert read(im,[lines[0],lines[1],lines[1],lines[3]],opts) is None
assert read(im,lines,["管理，IV","管理，III","管理，II","管理，1"]) is None
assert read(im,lines,["管理，III","管理，III","管理，II","管理，I"]) is None
low=[z for q in json.loads((h.parent/"third/lines-production.json").read_text()) if "535170619" in q["file"] for z in q["lines"] if 39<z["box"][1]<70]
li=Image.open(h.parent/"app/src/main/assets/upstream-input-1794565351706194700.png")
assert read(li,low,["作业，IV","作业，III","作业，II","作业，I"]) is None
print("Q20 actual suffixes:",out,"24 coordinate permutations passed, incomplete/duplicate/digit-bank negatives abstained, low-resolution historical frame abstained.")
# Replace the single Roman stripe with a genuine digit 1 from the same 1080 host and font.
q4=m[3];d4=next(v for one in raws if one["file"].endswith(q4["file"]) for v in one["lines"] if v["text"]=="1")
di=Image.open(q4["sourcePath"]).convert("RGB"); deg=d4["box"]; x0,y0=int(deg[0]*di.width/100)-4,int(deg[1]*di.height/100)-4
piece=di.crop((x0,y0,round((deg[0]+deg[2])*di.width/100)+4,round((deg[1]+deg[3])*di.height/100)+4))
occupied=np.asarray(piece.convert("L"))<125;ys,xs=np.where(occupied);piece=piece.crop((xs.min(),ys.min(),xs.max()+1,ys.max()+1))
from PIL import ImageDraw
mod=im.copy().convert("RGB"); x,y,b,c=lines[3]["box"]; bx=int(x*im.width/100)-3; by=int(y*im.height/100)-3
ImageDraw.Draw(mod).rectangle((bx+133,by+3,bx+151,by+42),fill="white")
piece=piece.resize((max(1,round(piece.width*33/piece.height)),33)); mod.paste(piece,(bx+136,by+7))
assert read(mod,lines,opts) is None
print("Replacing I with an actual digit 1 from Q4 rejected.")
