package expo.modules.automationbridge.generic

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.PowerManager
import android.os.SystemClock
import android.app.KeyguardManager
import expo.modules.automationbridge.BuildConfig
import expo.modules.automationbridge.QuizAccessibilityService
import expo.modules.automationbridge.bank.*
import expo.modules.automationbridge.profile.*
import expo.modules.automationbridge.runtime.*
import expo.modules.automationbridge.screen.*
import java.security.MessageDigest
import org.json.JSONObject

data class GenericBinding(val packageName:String,val version:Long,val signer:String) {
  fun json()=JSONObject().put("packageName",packageName).put("version",version).put("signer",signer)
  companion object {
    fun decode(j:JSONObject)=GenericBinding(j.getString("packageName"),j.getLong("version"),j.getString("signer"))
    fun installed(context:Context,pkg:String):GenericBinding {
      require(pkg!=context.packageName && !pkg.startsWith("com.android.") && pkg!="android") { "请选择需要答题的软件" }
      check(context.packageManager.getLaunchIntentForPackage(pkg)!=null) { "目标软件尚未安装，请重新选择" }
      val info=context.packageManager.getPackageInfo(pkg,if(Build.VERSION.SDK_INT>=28) PackageManager.GET_SIGNING_CERTIFICATES else PackageManager.GET_SIGNATURES)
      val sigs=if(Build.VERSION.SDK_INT>=28) info.signingInfo?.apkContentsSigners else info.signatures
      val signer=sigs.orEmpty().map { MessageDigest.getInstance("SHA-256").digest(it.toByteArray()).joinToString(""){b->"%02x".format(b)} }.sorted().joinToString(",")
      check(signer.isNotEmpty()) { "无法核实目标软件，请重新选择" }
      return GenericBinding(pkg,if(Build.VERSION.SDK_INT>=28)info.longVersionCode else info.versionCode.toLong(),signer)
    }
  }
}

/** Device-owned generic reader; it reuses the existing guarded executor with a per-action scope. */
class GenericDriver(private val context:Context,private val repository:WorkspaceRepository,val binding:GenericBinding,
  initial:RunFacts,private val service:()->QuizAccessibilityService?,private val authorized:()->Boolean,
  private val lock:Any,private val persist:(RunFacts,GenericBinding,String?)->Unit,
  private val paidPersist:((RunFacts,GenericBinding,String?,ActionIntent?)->Unit)?=null,
  private val paidCanAdvance:(()->Boolean)?=null,
  private val paidBeforeDispatch:((ActionIntent)->Boolean)?=null,
  private val paidRejectedDispatch:((ActionIntent)->Unit)?=null) {
  private val recognizer=GenericRecognizer(repository.questions(initial.workspaceId,initial.bankRevision),setOf(GenericRecognizer.compact(context.packageManager.getApplicationLabel(context.packageManager.getApplicationInfo(binding.packageName,0)).toString())))
  private val coordinator:GenericCoordinator=GenericCoordinator(recognizer,initial,{ if(paidPersist==null) true else checkNotNull(paidCanAdvance){"paid settlement guard unavailable"}() }){ f,intent ->
    GenericPersistDispatch.save(BuildConfig.BILLING_ADMISSION_ENABLED,f,binding,coordinatorStem(),intent,persist,paidPersist)
  }
  val facts get()=coordinator.facts
  private fun coordinatorStem():String?=runCatching { coordinator.currentStem }.getOrNull()
  private var reader:ScreenReader?=null
  private var readerService:QuizAccessibilityService?=null
  private var generation=0L
  private var reading=false
  private var readingStartedAt=0L
  private var gate=StableLaunchPage()
  private var unstableSince=0L
  private var launchUntil=0L
  private val recovery=SystemUiRecovery()
  private var foregroundCursor=0L
  private var stableTargetObserved=false
  private var preparedPage:PageSnapshot?=null
  private var preparedEpoch=0L
  private var preparedService:QuizAccessibilityService?=null
  private var startCompletion:((Result<Unit>)->Unit)?=null
  private fun recoveryIdentity(s:QuizAccessibilityService)=RecoveryIdentity(facts.runId,binding.json().toString(),facts.bankRevision,System.identityHashCode(s))
  private fun foreground(s:QuizAccessibilityService,now:Long):String? {
    val pkg=s.sampleForegroundWindow()
    val records=s.foregroundWindows.since(foregroundCursor)
    foregroundCursor=s.foregroundWindows.sequence
    if(stableTargetObserved && records==null) { pause("前景窗口变化无法完整核对，请回到答题软件后继续");return null }
    if(stableTargetObserved && records.orEmpty().any { it.packageName!=null && it.packageName!=binding.packageName && it.packageName!="com.android.systemui" }) {
      pause("已离开答题软件，请返回后手动继续");return null
    }
    val systemUi=records.orEmpty().any { it.packageName=="com.android.systemui" }
    if(systemUi && stableTargetObserved && recovery.token==null) {
      if(!recovery.hold(recoveryIdentity(s),records.orEmpty().first { it.packageName=="com.android.systemui" }.elapsedMs,facts.phase)) { pause("系统遮挡次数较多，请回到答题软件后手动继续");return null }
      cancelPending();gate=StableLaunchPage();unstableSince=0
      coordinator.waitForSystemUi()
    }
    if(recovery.token!=null && !recovery.valid(recoveryIdentity(s),SystemClock.elapsedRealtime())) { pause("系统窗口遮挡较久，请回到答题软件后手动继续");return null }
    return pkg
  }
  private fun callbackForeground(token:Long,id:String,s:QuizAccessibilityService):Boolean {
    if(generation!=token || facts.runId!=id || facts.status!="running") return false
    if(!authorized() || service()!==s) { pause("无障碍服务已变化，请重新开启后继续");return false }
    if((context.getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager).isKeyguardLocked || !(context.getSystemService(Context.POWER_SERVICE) as PowerManager).isInteractive) { pause("请解锁手机并回到答题软件");return false }
    try { verify() } catch(e:Exception) { pause(e.message ?: "目标软件或资料已变化");return false }
    foreground(s,SystemClock.elapsedRealtime())
    return current(token,id)
  }
  private fun profile(target:ScreenNode?=null):ProfileDefinition {
    val selector=if(target==null) NodeSelector(textEquals="__automatic_page_scope__") else NodeSelector(
      resourceId=target.resourceId.takeIf(String::isNotEmpty),textEquals=target.text.takeIf(String::isNotEmpty),
      descriptionEquals=target.description.takeIf(String::isNotEmpty),role=target.role)
    return ProfileDefinition("__generic__",version=1,target=TargetPolicy(binding.packageName,binding.signer.substringBefore(','),binding.version,binding.version),
      pages=emptyMap(),steps=listOf(WorkflowStep("action",if(target==null)"wait" else "click","action")),selectors=mapOf("action" to selector),resultPolicy=ResultPolicy("action"))
  }
  private fun verify() {
    check(GenericBinding.installed(context,binding.packageName)==binding) { "目标软件已更新，请结束本次任务后重新开始" }
    check(repository.get(facts.workspaceId).activeBankRevision==facts.bankRevision) { "答题资料已更新，请重新开始" }
  }
  fun prepareManual() {
    check(authorized() && service()!=null) { "请先开启每日百题的无障碍服务" };verify()
    val openInitially=facts.status=="ready" && facts.phase!="waiting_for_question"
    cancelPending();preparedPage=null;coordinator.prepareManual()
    // Only initial preparation opens the app. Continue leaves the existing activity and quiz intact.
    if(openInitially && service()?.sampleForegroundWindow()!=binding.packageName) open()
  }
  /** Read only after the person presses Start in the target app; no allowance/admission or intent here. */
  fun requestStart(callback:(Result<Unit>)->Unit) {
    cancelPending();preparedPage=null
    val s=service() ?: return callback(Result.failure(IllegalStateException("请先开启每日百题的无障碍服务")))
    val token=generation;val id=facts.runId;val waitingStatus=facts.status
    var startForegroundCursor=s.foregroundWindows.sequence
    val readiness=ManualReadReadiness(SystemClock.elapsedRealtime())
    val handler=android.os.Handler(s.mainLooper)
    startCompletion=callback
    fun finish(result:Result<Unit>) { val done=startCompletion;startCompletion=null;done?.invoke(result) }
    fun active()=generation==token && startCompletion!=null && facts.runId==id && facts.status==waitingStatus && authorized() && service()===s
    fun guard() {
      check(active()) { "任务已变化，请重新核对当前页面" };verify()
      check(!(context.getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager).isKeyguardLocked && (context.getSystemService(Context.POWER_SERVICE) as PowerManager).isInteractive) { "请解锁手机并回到答题软件" }
      val foreground=s.sampleForegroundWindow()
      val changes=s.foregroundWindows.since(startForegroundCursor)
      readiness.requireForeground(binding.packageName,foreground,changes?.map { it.packageName })
      // Already checked samples must not fill the bounded journal during three OCR passes.
      changes?.lastOrNull()?.let { startForegroundCursor=it.sequence }
    }
    if(readerService!==s) { reader?.close();reader=ScreenReader(s);readerService=s }
    val r=reader!!;val scope=profile()
    lateinit var read:()->Unit
    fun retryOrFinish(error:Throwable) {
      if(readiness.retry(error,SystemClock.elapsedRealtime(),active())) handler.postDelayed({ synchronized(lock) { if(active())read() } },400)
      else finish(Result.failure(error))
    }
    read={
      if(active()) try {
        guard()
        val now=SystemClock.elapsedRealtime()
        check(readiness.withinDeadline(now)) { "页面仍在变化，请停留在题目页后再点开始" }
        val tree=r.readTree(scope)
        if(!readiness.ready(tree,s.windowEpoch,now)) {
          handler.postDelayed({ synchronized(lock) { if(active())read() } },400)
        } else {
          val epoch=s.windowEpoch
          fun verifyFrame(page:PageSnapshot) {
            guard()
            readiness.requireSameOcrFrame(tree,epoch,page,s.windowEpoch)
          }
          val observed=recognizer.recognize(tree)
          val capture=if(observed is GenericObservation.Unknown && !facts.pendingSubmit) runCatching {
            verifyFrame(r.readTreeForSampling(scope))
            val version=context.packageManager.getPackageInfo(context.packageName,0).versionName.orEmpty()
            FailureReadEvidence.Capture(tree,epoch,version,System.currentTimeMillis())
          }.getOrNull() else null
          fun accept(page:PageSnapshot,observation:GenericObservation) {
            try { ManualStartCheck.requirePage(binding.packageName,page,observation,facts) }
            catch(error:IllegalStateException) {
              if(observation is GenericObservation.Unknown && capture!=null) {
                val evidence=runCatching {
                  verifyFrame(r.readTreeForSampling(scope))
                  capture.finish(observation)
                }.getOrNull()
                if(evidence!=null) throw ManualRecognitionFailure(observation.reason,evidence)
              }
              throw error
            }
            preparedPage=tree;preparedEpoch=epoch;preparedService=s;finish(Result.success(Unit))
          }
          fun readOcr(attempt:Int) {
            if(!active()) return
            fun fail(error:Throwable) {
              if(attempt==0) retryOrFinish(error) else finish(Result.failure(error))
            }
            fun scheduleFallback(result:Result<GenericObservation>):Boolean {
              // The 2.8 s budget only settles the initial tree. The floating control's
              // existing 30 s cancellation covers the same request across all three passes.
              val next=readiness.nextOcrAttempt(attempt,result,active(),!facts.pendingSubmit) ?: return false
              return handler.postDelayed({ synchronized(lock) { readOcr(next) } },400)
            }
            try {
              if(attempt>0) verifyFrame(r.readTree(scope))
              r.readAttempt(scope,id,{ active() },attempt) { result -> synchronized(lock) {
                if(active()) try {
                  result.fold(onSuccess={ page ->
                    verifyFrame(page)
                    val observation=recognizer.recognize(page)
                    if(observation is GenericObservation.Unknown) capture?.record(attempt,observation.reason,page)
                    if(!scheduleFallback(Result.success(observation))) accept(page,observation)
                  },onFailure={ error ->
                    capture?.record(attempt,(error as? ScreenReadException)?.code ?: "本档读取失败")
                    if(!scheduleFallback(Result.failure(error))) fail(error)
                  })
                } catch(error:Exception) { fail(error) }
              } }
            } catch(error:Exception) { fail(error) }
          }
          if(observed is GenericObservation.Unknown && observed.mayNeedOcr) readOcr(0)
          else { verifyFrame(tree);accept(tree,observed) }
        }
      } catch(error:Exception) { retryOrFinish(error) }
    }
    read()
  }

  fun isAwaitingStart()=startCompletion!=null || preparedPage!=null

  fun requirePreparedStart() {
    check(authorized() && service()!=null) { "请先开启每日百题的无障碍服务" };verify()
    val s=service()!!;val prepared=checkNotNull(preparedPage) { "请在答题软件的浮窗中从当前页开始" }
    check(s===preparedService && s.sampleForegroundWindow()==binding.packageName && s.windowEpoch==preparedEpoch) { "核对期间页面已变化，请重新点浮窗开始" }
    check(!(context.getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager).isKeyguardLocked && (context.getSystemService(Context.POWER_SERVICE) as PowerManager).isInteractive) { "请解锁手机并回到答题软件" }
    val fresh=checkNotNull(reader).readTree(profile())
    check(fresh.windowId==prepared.windowId && fresh.fingerprint==prepared.fingerprint && ScreenGrounding.unchangedSelection(prepared.nodes.filter { it.checkable },fresh.nodes.filter { it.checkable })) { "核对期间题目或选项已变化，请重新点浮窗开始" }
  }
  fun start() {
    requirePreparedStart();val s=service()!!
    preparedPage=null;recovery.reset();stableTargetObserved=false;foregroundCursor=s.foregroundWindows.sequence
    gate=StableLaunchPage();unstableSince=0;launchUntil=0
    if(facts.pendingSubmit)coordinator.checkReceipt(SystemClock.elapsedRealtime()) else coordinator.resume(SystemClock.elapsedRealtime())
  }
  fun acknowledgeUnsubmitted() { cancelPending();coordinator.acknowledgeUnsubmitted(true) }
  fun open() {
    verify();gate=StableLaunchPage();unstableSince=0;launchUntil=SystemClock.elapsedRealtime()+5000
    if(service()?.sampleForegroundWindow()==binding.packageName) return
    context.startActivity(requireNotNull(context.packageManager.getLaunchIntentForPackage(binding.packageName)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP))
  }
  fun cancelPending() { generation++;preparedPage=null;reading=false;readingStartedAt=0;reader?.cancelPending();val done=startCompletion;startCompletion=null;done?.invoke(Result.failure(IllegalStateException("任务已调整，请重新点浮窗开始"))) }
  fun pause(reason:String) { recovery.cancel();stableTargetObserved=false;cancelPending();coordinator.pause(reason) }
  fun stop() { recovery.cancel();stableTargetObserved=false;cancelPending();coordinator.stop();reader?.close();reader=null;readerService=null }
  private fun current(token:Long,runId:String)=generation==token && facts.runId==runId && facts.status=="running" && recovery.token==null && authorized()
  fun tick() {
    if(facts.status!="running") return
    if(!authorized() || service()==null) { pause("无障碍服务已断开，请重新开启后继续");return }
    try { verify() } catch(e:Exception) { pause(e.message ?: "目标软件或资料已变化");return }
    if((context.getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager).isKeyguardLocked || !(context.getSystemService(Context.POWER_SERVICE) as PowerManager).isInteractive) { pause("请解锁手机并回到答题软件");return }
    val s=service()!!
    if(readerService!==s && readerService!=null && (stableTargetObserved || recovery.token!=null)) { pause("无障碍服务已变化，请核对答题页面后继续");return }
    if(readerService!==s) { reader?.close();reader=ScreenReader(s);readerService=s;gate=StableLaunchPage() }
    val r=reader!!;val scope=profile();val now=SystemClock.elapsedRealtime()
    val pkg=foreground(s,now)
    if(facts.status!="running") return
    if(recovery.token!=null && pkg!=binding.packageName) return
    if(reading) { if(now-readingStartedAt>=30000) pause("页面读取或动作回执超时，请核对后继续");return }
    val tree=try { r.readTree(scope) } catch(e:Exception) {
      if((e as? ScreenReadException)?.code in setOf("NO_WINDOW","WRONG_FOREGROUND")) {
        // The foreground can change between the first sample and this guarded tree read.
        val retryNow=SystemClock.elapsedRealtime();foreground(s,retryNow)
        if(facts.status!="running" || recovery.valid(recoveryIdentity(s),SystemClock.elapsedRealtime())) return
      }
      if(now>=launchUntil || (e as? ScreenReadException)?.code !in setOf("NO_WINDOW","WRONG_FOREGROUND")) pause(e.message ?: "无法读取当前答题页面")
      return
    }
    if(!gate.ready(tree,s.windowEpoch,now)) {
      if(unstableSince==0L) unstableSince=now
      if(now-unstableSince>10000) pause("当前页面持续变化，请稳定后继续")
      return
    }
    unstableSince=0
    if(recovery.token!=null) {
      if(!recovery.release(recoveryIdentity(s),now)) { pause("本次系统遮挡无法安全恢复，请核对后继续");return }
      coordinator.reconcileAfterSystemUi(now)
    }
    stableTargetObserved=true;recovery.markStable(recoveryIdentity(s))
    val token=generation;val id=facts.runId
    fun process(page:PageSnapshot) {
      if(!current(token,id)) return
      val action=coordinator.onPage(page,SystemClock.elapsedRealtime()) ?: return
      if(!current(token,id)) return
      val target=SelectorMatcher.allNodes(page).singleOrNull { it.ref==action.targetRef } ?: run { pause("当前操作目标已变化，请核对页面");return }
      reading=true;readingStartedAt=SystemClock.elapsedRealtime()
      ActionExecutor(s,profile(target),{ run -> current(token,run) },r,true,{ candidate,perform -> synchronized(lock) {
        if(!current(token,id) || paidBeforeDispatch?.invoke(candidate)==false) false else {
          val accepted=perform();if(!accepted)paidRejectedDispatch?.invoke(candidate);accepted
        }
      } }).executeAsync(action,page){ outcome -> synchronized(lock) {
        if(callbackForeground(token,id,s)) { reading=false;runCatching { coordinator.actionOutcome(outcome,SystemClock.elapsedRealtime()) } }
      } }
    }
    val observed=recognizer.recognize(tree)
    if(observed is GenericObservation.Unknown && observed.mayNeedOcr) {
      reading=true;readingStartedAt=SystemClock.elapsedRealtime()
      fun readAttempt(attempt:Int) {
        r.readAttempt(scope,id,{ run -> current(token,run) },attempt) { result -> synchronized(lock) {
          if(callbackForeground(token,id,s)) runCatching {
            result.fold(onSuccess={ page ->
              val observation=recognizer.recognize(page)
              val incomplete=observation is GenericObservation.Unknown && observation.mayNeedOcr ||
                page.visualFrame!=null && observation is GenericObservation.Question && observation.options.any { !it.node.checkable }
              if(incomplete && attempt<2) android.os.Handler(s.mainLooper).postDelayed({ synchronized(lock) { if(current(token,id)) readAttempt(attempt+1) } },400)
              else { reading=false;process(page) }
            },onFailure={ e -> reading=false;pause(e.message ?: "当前页面未能读取，请核对后继续") })
          }.onFailure { e -> reading=false;runCatching { pause(e.message ?: "答题状态未能保存，请检查手机存储") } }
        } }
      }
      readAttempt(0)
    } else process(tree)
  }
}
