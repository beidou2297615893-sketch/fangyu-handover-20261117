from pathlib import Path
import json,re,sys,hashlib,collections
r=Path('V:/work/original-vs-0419');folder=r/sys.argv[1]
summary=json.loads((folder/'final-summary.json').read_text(encoding='utf-8'))
events=json.loads((folder/'current-run-events.json').read_text(encoding='utf-8'))
proof=json.loads((r/'hidden-host-proof.json').read_text(encoding='utf-8'))
confirms=[e['data'] for e in events if e['evt']=='confirm']
assert events[0]['evt']=='start' and events[0]['data']['ids']==proof['questionOrder']
assert len(confirms)==100 and len({c['id'] for c in confirms})==100
assert [c['id'] for c in confirms]==proof['questionOrder']
assert [c['index'] for c in confirms]==list(range(100))
assert all(c['correct'] and sorted(c['selected'])==sorted(c['answer']) and c['answeredCount']==i+1
    for i,c in enumerate(confirms))
assert events[-1]['evt']=='result' and events[-1]['data']['score']==100
assert summary['confirmed']==100 and summary['correct']==100 and summary['wrong']==0
logs=(folder/'continuous-log.txt').read_text(encoding='utf-8',errors='replace')
sources={}
for number,source in re.findall(r'ZhitiBank:\s+no=(\d+).*?source=(\w+)',logs):
    number=int(number)
    if number in sources:assert sources[number]==source,(number,sources[number],source)
    sources[number]=source
assert set(sources)==set(range(1,101)),sorted(set(range(1,101))-set(sources))
assert all(source in {'local_ocr_bank','visual_then_bank','screen_bank','question_bank'} for source in sources.values())
summary.update(allSubmittedOnce=True,scored=True,sameQuestionOrder=True,
    sources=dict(collections.Counter(sources.values())),manualAnswerClicks=0,
    humanInterventionEvidence='Setup taps precede the round; only read-only logs and screenshots during the round.',
    finalScreenshotSha256=hashlib.sha256((folder/'current-final.png').read_bytes()).hexdigest())
(folder/'final-summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(summary,ensure_ascii=False))
