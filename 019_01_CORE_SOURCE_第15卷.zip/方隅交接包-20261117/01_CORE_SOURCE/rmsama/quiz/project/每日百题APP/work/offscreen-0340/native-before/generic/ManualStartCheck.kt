package expo.modules.automationbridge.generic

import expo.modules.automationbridge.runtime.RunFacts
import expo.modules.automationbridge.screen.PageSnapshot

/** A click on the floating control authorizes only this foreground quiz, never app navigation. */
object ManualStartCheck {
  fun requirePage(targetPackage:String,page:PageSnapshot,observation:GenericObservation,facts:RunFacts) {
    check(page.packageName==targetPackage) { "请回到已选择的答题软件，再点浮窗开始" }
    check(page.capabilityIssue==null) { page.capabilityIssue ?: "当前页面无法读取" }
    check(observation !is GenericObservation.Sensitive) { "请本人完成登录或身份验证，再进入答题页面" }
    if(facts.pendingSubmit) {
      check(observation !is GenericObservation.Entry) { "请回到上次提交的题目或结果页面核对" }
      return // Receipt-only reconciliation retains uncertainty; it cannot replay the submission.
    }
    // A paused run may already have durably confirmed its receipt before settlement or
    // next-page navigation paused. Let the existing coordinator finish that same run.
    if(facts.status=="paused" && facts.submittedCount>0 &&
      (observation is GenericObservation.Feedback || observation is GenericObservation.Complete)) return
    check(observation is GenericObservation.Question) {
      if(observation is GenericObservation.Unknown) observation.reason else "请先手动进入单题答题页面，再点浮窗开始"
    }
  }
}
