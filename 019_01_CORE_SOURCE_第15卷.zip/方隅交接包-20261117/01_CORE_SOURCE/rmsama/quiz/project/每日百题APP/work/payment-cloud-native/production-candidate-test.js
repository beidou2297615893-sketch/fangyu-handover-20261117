'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict'),crypto=require('node:crypto');
const {prepareCandidate}=require('./production-candidate');
function setup(){
 const a=crypto.generateKeyPairSync('rsa',{modulusLength:2048,privateKeyEncoding:{type:'pkcs8',format:'pem'}}),b=crypto.generateKeyPairSync('rsa',{modulusLength:2048,publicKeyEncoding:{type:'spki',format:'pem'}});
 const env={BILLING_ENABLED:'true',ALIPAY_APP_ID:'2021000000000000',ALIPAY_SELLER_ID:'2088000000000000',ALIPAY_PRIVATE_KEY:a.privateKey,ALIPAY_PUBLIC_KEY:b.publicKey,BILLING_MASTER_KEY:crypto.randomBytes(32).toString('base64'),BILLING_NOTIFY_URL:'https://billing.example.test/api/billing/alipay/notify',BILLING_RETURN_URL:'https://billing.example.test/api/billing/alipay/return'};
 const rows=new Map([['daily_hundred_installation_v1:policy',{kind:'policy',schema:1,enabled:true}]]);
 const db={async runTransaction(fn){return fn({collection(collection){return {doc(id){const key=collection+':'+id;return {async get(){return {data:rows.has(key)?{_id:id,...rows.get(key)}:null};},async set(v){rows.set(key,v);return {updated:1};}};}};}});}};
 return {env,db,rows};
}
const event=(path,method,body,token)=>({path:'/api/billing'+path,httpMethod:method,headers:{...(body?{'content-type':'application/json'}:{}),...(token?{authorization:'Bearer '+token}:{})},body:body?JSON.stringify(body):''});
test('validated isolated candidate generates an official signed checkout but remains unavailable as production status',async()=>{
 const f=setup(),candidate=prepareCandidate({db:f.db,env:f.env,approvedOrigin:'https://billing.example.test',verifyTaskBinding:async()=>true});
 assert.equal((await candidate.handleForOffline(event('/status','GET'))).statusCode,200);
 assert.equal(JSON.parse((await candidate.handleForOffline(event('/status','GET'))).body).realPaymentsEnabled,false);
 const requestId=crypto.randomBytes(32).toString('base64url'),verifier=crypto.randomBytes(32).toString('base64url');
 const reg=await candidate.handleForOffline(event('/installations','POST',{requestId,verifier}));assert.equal(reg.statusCode,201);
 const order=await candidate.handleForOffline(event('/orders','POST',{planId:'once',clientRequestId:'req-1'},JSON.parse(reg.body).accessToken));assert.equal(order.statusCode,201);
 const u=new URL(JSON.parse(order.body).checkoutUrl);assert.equal(u.hostname,'openapi.alipay.com');assert.equal(u.searchParams.get('method'),'alipay.trade.wap.pay');
 assert.equal(u.searchParams.get('notify_url'),'https://billing.example.test/api/billing/alipay/notify');assert.equal(u.searchParams.get('return_url'),'https://billing.example.test/api/billing/alipay/return');
 assert.equal((await candidate.handleForOffline(event('/oauth/start','POST',{}))).statusCode,503);
});
test('disabled or incomplete production config cannot instantiate the isolated candidate',()=>{
 const f=setup();assert.throws(()=>prepareCandidate({db:f.db,env:{...f.env,BILLING_ENABLED:'false'},approvedOrigin:'https://billing.example.test',verifyTaskBinding:async()=>true}),{message:'payment configuration unavailable'});
 assert.throws(()=>prepareCandidate({db:f.db,env:f.env,approvedOrigin:'https://billing.example.test'}),{message:'payment configuration unavailable'});
});
