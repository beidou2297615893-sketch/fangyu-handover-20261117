package expo.modules.automationbridge.generic

import expo.modules.automationbridge.runtime.*
import expo.modules.automationbridge.screen.*
import java.util.UUID

/** Receipts, not accepted click calls, advance the count. State is durable before each intent. */
class GenericCoordinator(private val recognizer:GenericRecognizer,initial:RunFacts,
  private val mayAdvanceAfterReceipt:()->Boolean={true},private val persist:(RunFacts,ActionIntent?)->Unit) {
  var facts:RunFacts=initial;private set
  var currentStem:String?=null;private set
  private var resumeOptionReconcile=false
  private fun save(next:RunFacts,intent:ActionIntent?=null) { persist(next,intent);facts=next }
  fun pause(reason:String) {
    resumeOptionReconcile=false
    if(facts.status in setOf("completed","stopped")) return
    val status=if(facts.receiptCheckReturnStatus=="stopped") "stopped" else "paused"
    save(facts.copy(status=status,phase=status,reason=reason,receiptCheckReturnStatus=null))
  }
  fun stop() { resumeOptionReconcile=false;if(facts.status!="completed") save(facts.copy(status="stopped",phase="stopped",reason="本次答题已结束",receiptCheckReturnStatus=null)) }
  fun prepareManual() {
    check(facts.status in setOf("ready","paused") || facts.status=="stopped" && facts.pendingSubmit) { "请先暂停本次答题" }
    resumeOptionReconcile=false
    save(facts.copy(phase="waiting_for_question",reason="请手动进入答题页面，再点浮窗从当前页开始"))
  }
  fun resume(now:Long=0) { resumeOptionReconcile=false;check(!facts.pendingSubmit) { "上次提交结果尚未确认，请先在目标软件核对，本次任务不能重复提交" };check(facts.status=="paused" || facts.status=="ready");save(facts.copy(status="running",phase="reading",reason=null,pendingAt=if(facts.pendingOption!=null||facts.pendingNavigation)now else facts.pendingAt));resumeOptionReconcile=facts.pendingOption!=null && !facts.pendingSubmit && !facts.pendingNavigation }
  fun waitForSystemUi() {
    check(facts.status=="running")
    resumeOptionReconcile=false
    save(facts.copy(phase="waiting_system_ui",reason="通知栏等系统窗口暂时遮挡，收起后将核对并继续"))
  }
  fun reconcileAfterSystemUi(now:Long) {
    check(facts.status=="running" && facts.phase=="waiting_system_ui")
    save(facts.copy(phase=if(facts.pendingSubmit)"verifying_submission" else "reading",reason=null,pendingAt=if(facts.pendingOption!=null||facts.pendingSubmit||facts.pendingNavigation)now else facts.pendingAt))
    // Automatic interruption recovery permits the same bounded same-question reconciliation as v33.
    resumeOptionReconcile=facts.pendingOption!=null && !facts.pendingSubmit && !facts.pendingNavigation
  }
  fun checkReceipt(now:Long) {
    check(facts.pendingSubmit && facts.status in setOf("paused","stopped"))
    save(facts.copy(status="running",phase="verifying_submission",reason=null,pendingAt=now,receiptCheckReturnStatus=facts.status))
  }
  fun acknowledgeUnsubmitted(confirmed:Boolean) { check(confirmed && facts.pendingSubmit && facts.status in setOf("paused","stopped")) { "请先核对本题确实尚未提交" };save(facts.copy(pendingSubmit=false,pendingAt=0,pendingSubmissionId=null,reason="已按本人核对结果保留题目，请重新读取后继续")) }
  fun actionOutcome(outcome:ActionOutcome,now:Long) { if(facts.status=="running" && !outcome.accepted) pause(outcome.reason ?: "目标软件未接受操作，请核对后继续") }
  private fun intent(page:PageSnapshot,target:ScreenNode,updated:RunFacts,evidence:String):ActionIntent {
    val action=ActionIntent(UUID.randomUUID().toString(),facts.runId,page.frameId,page.fingerprint,"click",target.ref,evidence,target.text)
    save(if(updated.pendingSubmit) updated.copy(pendingSubmissionId=action.id) else updated,action)
    return action
  }
  private fun complete(observed:GenericObservation.Complete) {
    if(facts.submittedCount<1) { pause("当前已是结果页面，请重新开始一轮答题");return }
    if(facts.total!=null && facts.submittedCount!=facts.total) { pause("结果页面与已确认题量不一致，请核对本次答题记录");return }
    save(facts.copy(status="completed",phase="completed",pendingNavigation=false,pendingOption=null,reason=null,
      receiptCheckReturnStatus=null,result=RunResult(true,facts.submittedCount,observed.score,"target_completion")))
  }
  fun onPage(page:PageSnapshot,now:Long):ActionIntent? {
    if(facts.status!="running" || facts.phase in setOf("waiting_system_ui","waiting_for_question")) return null
    if(facts.receiptCheckReturnStatus!=null && !facts.pendingSubmit) {
      pause("上次提交结果已确认")
      return null
    }
    // Free runs use the default true predicate. Paid runs may continue only
    // after the first observed receipt has been durably settled remotely.
    if(facts.submittedCount>0 && !mayAdvanceAfterReceipt()) return null
    val observed=recognizer.recognize(page)
    if(observed is GenericObservation.Sensitive) { pause("请本人完成登录或身份验证，再回到答题页面");return null }
    if(observed is GenericObservation.Unknown && !observed.mayNeedOcr && !facts.pendingSubmit) { pause(observed.reason);return null }
    if(facts.pendingSubmit) {
      val advanced=observed is GenericObservation.Question && (observed.fingerprint!=facts.lastFingerprint || facts.lastOrdinal!=null && observed.ordinal==facts.lastOrdinal!!+1)
      val unknownAdvance=observed is GenericObservation.Unknown && facts.lastOrdinal!=null && observed.ordinal==facts.lastOrdinal!!+1 && observed.total!=null && observed.total==(facts.visits["targetTotal"] ?: facts.total)
      val receipt=observed is GenericObservation.Complete || observed is GenericObservation.Feedback
      if(advanced||unknownAdvance||receipt) {
        if(advanced && facts.lastOrdinal!=null && (observed as GenericObservation.Question).ordinal!=null && observed.ordinal!=facts.lastOrdinal!!+1) { pause("题目进度发生跳转，请核对已提交结果");return null }
        val returnStatus=facts.receiptCheckReturnStatus
        save(facts.copy(submittedCount=facts.submittedCount+1,pendingSubmit=false,pendingAt=0,phase="reading",pendingSubmissionId=null))
        if(returnStatus!=null) {
          if(observed is GenericObservation.Complete) complete(observed)
          else pause("上次提交结果已确认")
          return null
        }
        if(!mayAdvanceAfterReceipt()) return null
      } else {
        if(now-facts.pendingAt>15000) pause("上次提交结果尚未确认，请先在目标软件核对")
        return null
      }
    }
    if(observed is GenericObservation.Complete) { complete(observed);return null }
    if(facts.pendingNavigation) {
      if(page.fingerprint==facts.navigationFingerprint || observed !is GenericObservation.Question) {
        if(now-facts.pendingAt>10000) pause("页面尚未进入下一步，请核对后继续")
        return null
      }
      save(facts.copy(pendingNavigation=false,navigationFingerprint=null,pendingAt=0))
    }
    when(observed) {
      is GenericObservation.Entry -> {
        pause("请手动进入答题页面，再点浮窗从当前页继续");return null
      }
      is GenericObservation.Feedback -> return intent(page,observed.next,facts.copy(pendingNavigation=true,navigationFingerprint=page.fingerprint,pendingAt=now,phase="next"),"已读取本题提交回执，进入下一题")
      is GenericObservation.Unknown -> { pause(observed.reason);return null }
      is GenericObservation.Question -> {
        currentStem=observed.question.stem
        val answers=observed.question.correctOptionIds.map { id -> observed.question.options.single { it.id==id }.text }
        if(observed.options.groupBy { GenericRecognizer.compact(it.text) }.values.any { group -> group.size>1 && group.any { it.node.checked } }) {
          pause("重复选项已有勾选，无法唯一核对，请人工处理当前题目");return null
        }
        val targetTotal=facts.visits["targetTotal"]
        if(targetTotal!=null && observed.total!=null && targetTotal!=observed.total) { pause("本次题量发生变化，请核对当前任务");return null }
        if(targetTotal==null && observed.total!=null) {
          val firstOrdinal=((observed.ordinal ?: (facts.submittedCount+1))-facts.submittedCount).coerceAtLeast(1)
          save(facts.copy(total=observed.total-firstOrdinal+1,visits=facts.visits+("targetTotal" to observed.total)+("firstOrdinal" to firstOrdinal)))
        }
        if(facts.pendingOption!=null) {
          val reconcile=resumeOptionReconcile;resumeOptionReconcile=false
          if(observed.fingerprint!=facts.lastFingerprint ||
            (observed.options.any { it.node.ref.startsWith("ocr:") } && observed.ordinal!=facts.lastOrdinal)) {
            pause("选项操作后题目已变化，请核对是否已提交");return null
          }
          val target=observed.options.singleOrNull { GenericRecognizer.compact(it.text)==facts.pendingOption }
          val wanted=facts.expectedAnswerTexts.any { GenericRecognizer.compact(it)==facts.pendingOption }
          if(target!=null && target.node.checkable && target.node.checked==wanted) save(facts.copy(pendingOption=null,pendingAt=0))
          else if(reconcile && !facts.pendingSubmit && !facts.pendingNavigation &&
            facts.lastOrdinal!=null && observed.ordinal==facts.lastOrdinal && target!=null &&
            observed.options.size==observed.question.options.size && observed.options.all { it.node.checkable } &&
            observed.options.map { it.node.ref }.distinct().size==observed.options.size &&
            expo.modules.automationbridge.bank.QuestionMatcher.hasUniqueAnswerTargets(observed.question,GenericRecognizer::compact) &&
            answers.map(GenericRecognizer::compact).toSet()==facts.expectedAnswerTexts.map(GenericRecognizer::compact).toSet()) {
            // An explicit resume permits one fresh plan only after this same question is fully read back.
            // Clear the unconfirmed selection durably before the existing planner proposes another action.
            save(facts.copy(pendingOption=null,pendingAt=0))
          }
          else { if(now-facts.pendingAt>2500) pause("无法确认选中状态，未继续提交，请核对当前页面");return null }
        }
        val desired=answers.map(GenericRecognizer::compact).toSet()
        if(observed.options.any { !it.node.checkable }) {
          val target=observed.options.singleOrNull {
            GenericRecognizer.compact(it.text) in desired && (!it.node.checkable || !it.node.checked)
          }
          if(page.visualFrame!=null && observed.question.type in setOf("single","boolean") &&
            answers.size==1 && observed.options.all { it.node.ref.startsWith("ocr:") } && target!=null) {
            return intent(page,target.node,facts.copy(lastFingerprint=observed.fingerprint,lastOrdinal=observed.ordinal,
              expectedAnswerTexts=answers,pendingOption=GenericRecognizer.compact(target.text),pendingAt=now,phase="selecting"),
              "已匹配题库，点选正确选项并用新截图核对；尚不提交")
          }
          pause("当前选项的选中状态未能全部核对，未继续提交");return null
        }
        val incorrect=observed.options.firstOrNull { it.node.checked && GenericRecognizer.compact(it.text) !in desired }
        val missing=observed.options.firstOrNull { !it.node.checked && GenericRecognizer.compact(it.text) in desired }
        val choose=if(observed.question.type=="multiple") incorrect ?: missing else missing ?: incorrect
        if(choose!=null) return intent(page,choose.node,facts.copy(lastFingerprint=observed.fingerprint,lastOrdinal=observed.ordinal,expectedAnswerTexts=answers,pendingOption=GenericRecognizer.compact(choose.text),pendingAt=now,phase="selecting"),"按题库答案选择选项，并等待回读确认")
        val submit=observed.submit ?: run { pause("未能唯一识别提交或下一题按钮，请核对页面");return null }
        return intent(page,submit,facts.copy(lastFingerprint=observed.fingerprint,lastOrdinal=observed.ordinal,expectedAnswerTexts=answers,pendingSubmit=true,pendingAt=now,phase="submitting"),"已核对选中答案，提交本题并等待结果")
      }
      else -> return null
    }
  }
}
