package com.jimusoft.comparison;

import android.app.Instrumentation;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Base64;
import org.json.JSONArray;
import org.json.JSONObject;
import java.lang.reflect.*;
import java.nio.file.Files;
import java.io.File;
import java.util.List;
import java.util.Arrays;

/** Test APK only: reads the installed answering APK's own OCR, without replacing it. */
public class OcrProbe extends Instrumentation {
    private ClassLoader loader;
    private Object unit, reader, frame;
    private Class<?> callbackType;
    private final JSONObject result = new JSONObject();
    private boolean finished;
    @Override public void onCreate(Bundle args) { super.onCreate(args);start(); }
    private interface Receiver { void accept(Object value) throws Exception; }
    private Object callback(Receiver receiver) {
        return Proxy.newProxyInstance(loader,new Class<?>[]{callbackType},(proxy,method,args)->{
            if (method.getName().equals("invoke")) {
                try { receiver.accept(args[0]); } catch(Throwable error) { fail(error); }
                return unit;
            }
            if(method.getName().equals("hashCode"))return System.identityHashCode(proxy);
            if(method.getName().equals("equals"))return proxy==args[0];
            return "comparison callback";
        });
    }
    private Object call(Object target,String name,Class<?>[] types,Object... args) throws Exception {
        Method method=target.getClass().getDeclaredMethod(name,types);method.setAccessible(true);return method.invoke(target,args);
    }
    private Object get(Object target,String method) throws Exception {return call(target,method,new Class<?>[]{});}
    private Object named(Object target,String prefix,Object... args) throws Exception {
        for(Method method:target.getClass().getDeclaredMethods())if((method.getName().equals(prefix)||method.getName().startsWith(prefix+"$"))&&method.getParameterTypes().length==args.length){method.setAccessible(true);return method.invoke(target,args);}
        throw new NoSuchMethodException(prefix);
    }
    private JSONObject reconcile(Object first,Object second) throws Exception {
        File file=new File(getTargetContext().getFilesDir(),"ocr-transcript.json");
        if(!file.isFile())return new JSONObject().put("transcriptProvided",false);
        String raw=new String(Files.readAllBytes(file.toPath()),"UTF-8");
        Object parser=loader.loadClass("com.futureyyy.tijing.QuizModelParser").getField("INSTANCE").get(null);
        Object cloud=named(parser,"parse",raw,false,true);
        Object storeCompanion=loader.loadClass("com.futureyyy.tijing.QuestionBankStore").getField("Companion").get(null);
        Object store=call(storeCompanion,"get",new Class<?>[]{android.content.Context.class},getTargetContext());
        Object index=get(store,"getIndex");
        Object match=call(index,"match",new Class<?>[]{String.class},get(cloud,"getQuestion"));
        Object record=get(match,"getRecord");
        JSONObject out=new JSONObject().put("match",String.valueOf(get(match,"getStatus")));
        if(record==null)return out;
        String question=(String)get(record,"getQuestion");
        Object canonical=named(parser,"parse",new JSONObject(raw).put("question",question).toString(),false,true);
        Object companion=loader.loadClass("com.futureyyy.tijing.OcrHostPage").getField("Companion").get(null);
        List<Object> readings=Arrays.asList(first,second);
        out.put("canonicalQuestion",question).put("cloudFrameRows",named(companion,"verifiedRows",readings,cloud)!=null)
            .put("canonicalFrameRows",named(companion,"verifiedRows",readings,canonical)!=null);
        try{out.put("canonicalAnswer",new JSONArray((List<?>)get(named(index,"verifiedAnswer",canonical),"getAnswerIndices")));}
        catch(Throwable error){out.put("bankError",String.valueOf(error.getCause()));}
        return out;
    }
    private JSONObject box(Object value) throws Exception {
        if(value==null)return null;
        return new JSONObject().put("x",get(value,"getX")).put("y",get(value,"getY")).put("width",get(value,"getWidth")).put("height",get(value,"getHeight"));
    }
    private JSONObject inspect(Object value) throws Exception {
        JSONArray lines=new JSONArray();
        for(Object node:(List<?>)value)lines.put(new JSONObject().put("text",get(node,"getText")).put("box",box(get(node,"getBox"))));
        Object companion=loader.loadClass("com.futureyyy.tijing.OcrHostPage").getField("Companion").get(null);
        Object page=call(companion,"read",new Class<?>[]{List.class},value);
        Object host=get(page,"getPage");
        return new JSONObject().put("lines",lines).put("graded",get(host,"getGraded")).put("nextBox",box(get(page,"getNextBox")));
    }
    @Override public void onStart() {
        new Handler(Looper.getMainLooper()).post(()->{
            try {
                loader=getTargetContext().getClassLoader();
                callbackType=loader.loadClass("kotlin.jvm.functions.Function1");
                unit=loader.loadClass("kotlin.Unit").getField("INSTANCE").get(null);
                Class<?> signatures=loader.loadClass("com.futureyyy.tijing.FrameSignature");
                Object companion=signatures.getField("Companion").get(null);
                Object signature=call(companion,"fromBits",new Class<?>[]{boolean[].class},new boolean[1024]);
                byte[] png=Files.readAllBytes(new File(getTargetContext().getFilesDir(),"ocr-input.png").toPath());
                Class<?> frames=loader.loadClass("com.futureyyy.tijing.CaptureFrame");
                frame=frames.getConstructor(String.class,signatures,byte[].class).newInstance("data:image/png;base64,"+Base64.encodeToString(png,Base64.NO_WRAP),signature,png);
                Class<?> readers=loader.loadClass("com.futureyyy.tijing.OnDeviceQuestionOcr");
                reader=readers.getConstructor(android.content.Context.class).newInstance(getTargetContext());
                call(reader,"readLines",new Class<?>[]{frames,callbackType},frame,callback(lines->{
                    result.put("primary",inspect(lines));
                    call(reader,"readIndependent",new Class<?>[]{frames,List.class,callbackType},frame,lines,callback(other->{
                        result.put("independent",inspect(other));result.put("reconciliation",reconcile(lines,other));complete();
                    }));
                }));
                new Handler(Looper.getMainLooper()).postDelayed(()->{if(!finished)fail(new RuntimeException("probe timeout"));},25000);
            } catch(Throwable error) {fail(error);}
        });
    }
    private void fail(Throwable error) {try{result.put("error",error.toString());complete();}catch(Exception ignored){finish(0,new Bundle());}}
    private void complete() throws Exception {
        if(finished)return;finished=true;
        Files.write(new File(getTargetContext().getFilesDir(),"ocr-probe-result.json").toPath(),result.toString(2).getBytes("UTF-8"));
        if(reader!=null)call(reader,"close",new Class<?>[]{});
        Bundle bundle=new Bundle();bundle.putString("result","ocr-probe-result.json");finish(0,bundle);
    }
}
