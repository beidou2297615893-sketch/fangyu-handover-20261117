package expo.modules.automationbridge.billing

import expo.modules.automationbridge.runtime.ActionIntent
import expo.modules.automationbridge.runtime.RunFacts

object PaidSubmissionGuardTest {
  @JvmStatic fun main(args: Array<String>) {
    var passed=0
    fun test(name:String, block:()->Unit) { block();println("PASS $name");passed++ }
    fun denied(block:()->Unit) { var failed=false;try { block() } catch (_:Exception) { failed=true };check(failed) }
    val old=RunFacts("run-a","workspace","revision","__generic__",1,"profile-hash",status="running")
    val next=old.copy(pendingSubmit=true,phase="submitting",lastFingerprint="question-fingerprint")
    val action=ActionIntent("intent","run-a","frame","page-fingerprint","click","node")
    val target=PaidTarget("example.app",1,"signer")
    test("native submit intent matches persisted run and immutable target") {
      PaidSubmissionGuard.validate(old,next,action,target,target)
      check(PaidSubmissionGuard.binding(old,target)==PaidSubmissionGuard.binding(next,target))
    }
    test("changed run, bank or target cannot reuse a paid task") {
      denied { PaidSubmissionGuard.validate(old,next.copy(runId="other"),action,target,target) }
      denied { PaidSubmissionGuard.validate(old,next.copy(bankRevision="other"),action,target,target) }
      denied { PaidSubmissionGuard.validate(old,next,action,target,target.copy(version=2)) }
      check(PaidSubmissionGuard.binding(old,target)!=PaidSubmissionGuard.binding(old.copy(bankRevision="other"),target))
    }
    test("no action, non-submit state or already uncertain evidence is refused") {
      denied { PaidSubmissionGuard.validate(old,next,action.copy(runId="other"),target,target) }
      denied { PaidSubmissionGuard.validate(old,next.copy(pendingSubmit=false),action,target,target) }
      denied { PaidSubmissionGuard.validate(old.copy(pendingSubmit=true),next,action,target,target) }
      denied { PaidSubmissionGuard.validate(old,next,action.copy(operation="scroll"),target,target) }
    }
    test("only first submission may consume a new paid reservation") {
      denied { PaidSubmissionGuard.validate(old.copy(submittedCount=1),next.copy(submittedCount=1),action,target,target) }
      denied { PaidSubmissionGuard.validate(old.copy(trial=true),next.copy(trial=true),action,target,target) }
    }
    test("first confirmed readback can transition the same paid run to receipt-confirmed") {
      val receipt=next.copy(pendingSubmit=false,submittedCount=1,phase="reading")
      PaidSubmissionGuard.validateReceipt(next,receipt,target,target)
    }
    test("unconfirmed, missing, forged or cross-target receipt cannot settle a paid run") {
      val receipt=next.copy(pendingSubmit=false,submittedCount=1,phase="reading")
      denied { PaidSubmissionGuard.validateReceipt(next.copy(pendingSubmit=false),receipt,target,target) }
      denied { PaidSubmissionGuard.validateReceipt(next,receipt.copy(submittedCount=0),target,target) }
      denied { PaidSubmissionGuard.validateReceipt(next,receipt.copy(submittedCount=2),target,target) }
      denied { PaidSubmissionGuard.validateReceipt(next,receipt.copy(pendingSubmit=true),target,target) }
      denied { PaidSubmissionGuard.validateReceipt(next,receipt.copy(bankRevision="other"),target,target) }
      denied { PaidSubmissionGuard.validateReceipt(next,receipt,target,target.copy(version=2)) }
      denied { PaidSubmissionGuard.validateReceipt(next.copy(trial=true),receipt.copy(trial=true),target,target) }
    }
    test("paid actions cannot consume or reclassify the existing free ledger") {
      PaidSubmissionGuard.validateAccounting(false,false)
      denied { PaidSubmissionGuard.validateAccounting(true,false) }
      denied { PaidSubmissionGuard.validateAccounting(false,true) }
      denied { PaidSubmissionGuard.validateAccounting(true,true) }
      denied { PaidSubmissionGuard.validateAccounting(null,false) }
      denied { PaidSubmissionGuard.validateAccounting(false,null) }
    }
    test("explicit human verdict only clears an uncertain paused same task") {
      val paused=next.copy(status="paused",phase="paused");val cleared=paused.copy(pendingSubmit=false)
      PaidSubmissionGuard.validateHumanUnsubmitted(paused,cleared,target,target)
      denied{PaidSubmissionGuard.validateHumanUnsubmitted(next,next.copy(pendingSubmit=false),target,target)}
      denied{PaidSubmissionGuard.validateHumanUnsubmitted(paused,cleared.copy(submittedCount=1),target,target)}
      denied{PaidSubmissionGuard.validateHumanUnsubmitted(paused,cleared.copy(bankRevision="other"),target,target)}
      denied{PaidSubmissionGuard.validateHumanUnsubmitted(paused,cleared,target,target.copy(version=2))}
    }
    println("RESULT: $passed native submission guard tests passed")
  }
}
