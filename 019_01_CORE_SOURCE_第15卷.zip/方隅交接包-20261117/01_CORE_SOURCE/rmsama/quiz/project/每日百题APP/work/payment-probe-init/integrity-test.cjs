'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),{spawnSync}=require('node:child_process');
const {auditPackage,EXPECTED}=require('./integrity.cjs');
const sha=x=>crypto.createHash('sha256').update(x).digest('hex');
function fixture(){
 const parent=path.join(__dirname,'test-fixtures');fs.mkdirSync(parent,{recursive:true});const tmp=fs.mkdtempSync(path.join(parent,'case-'));
 const source=path.join(tmp,'source'),base=path.join(tmp,'base');fs.mkdirSync(path.join(source,'node_modules'),{recursive:true});fs.mkdirSync(path.join(base,'node_modules'),{recursive:true});
 const expected={};for(const name of ['isolated-probe.js','package.json','diagnostic-original.js','policy-init.cjs']){const v='synthetic-'+name;fs.writeFileSync(path.join(source,name),v);expected[name]=sha(v);}
 fs.writeFileSync(path.join(source,'node_modules','dependency.js'),'synthetic-dep');fs.writeFileSync(path.join(base,'node_modules','dependency.js'),'synthetic-dep');
 fs.copyFileSync(path.join(source,'diagnostic-original.js'),path.join(base,'original.js'));fs.copyFileSync(path.join(source,'policy-init.cjs'),path.join(base,'policy.cjs'));
 return {tmp,source,base,expected,run:()=>auditPackage(source,path.join(base,'original.js'),path.join(base,'policy.cjs'),path.join(base,'node_modules'),expected)};
}
test('frozen real manifest pins wrapper, package, original and policy',()=>{
 assert.equal(Object.keys(EXPECTED).sort().join(','),'diagnostic-original.js,isolated-probe.js,package.json,policy-init.cjs');
 for(const [name,digest] of Object.entries(EXPECTED))assert.equal(sha(fs.readFileSync(path.join(__dirname,'dailyHundredPaymentProbeV1',name))),digest);
});
test('tampered wrapper, package, unexpected file and changed dependency all fail closed',()=>{
 for(const mutation of ['isolated-probe.js','package.json','extra','dependency']){
  const f=fixture();try{f.run();if(mutation==='extra')fs.writeFileSync(path.join(f.source,'extra.js'),'bad');else if(mutation==='dependency')fs.writeFileSync(path.join(f.source,'node_modules','dependency.js'),'bad');else fs.writeFileSync(path.join(f.source,mutation),'bad');assert.throws(f.run);}
  finally{fs.rmSync(f.tmp,{recursive:true,force:true});}
 }
});
test('real ZIP validator rejects archive content diverging from audited source',()=>{
 const f=fixture(),zip=path.join(f.tmp,'test.zip');
 try{
  const archive=spawnSync('pwsh',['-NoProfile','-File',path.join(__dirname,'archive.ps1'),'-Source',f.source,'-Archive',zip],{encoding:'utf8'});assert.equal(archive.status,0);
  const validate=()=>spawnSync('pwsh',['-NoProfile','-File',path.join(__dirname,'validate-archive.ps1'),'-Source',f.source,'-Archive',zip],{encoding:'utf8'});
  const good=validate();assert.equal(good.status,0);assert.equal(good.stdout,'ARCHIVE_OK');
  fs.writeFileSync(path.join(f.source,'isolated-probe.js'),'tampered');assert.notEqual(validate().status,0);
  fs.writeFileSync(path.join(f.source,'isolated-probe.js'),'synthetic-isolated-probe.js');
  const mutationScript=path.join(f.tmp,'mutate.ps1');fs.writeFileSync(mutationScript,'param([string]$Archive)\n$ErrorActionPreference="Stop"\nAdd-Type -AssemblyName System.IO.Compression.FileSystem\n$z=[IO.Compression.ZipFile]::Open($Archive,[IO.Compression.ZipArchiveMode]::Update)\ntry { [void]$z.CreateEntry("unexpected.js") } finally { $z.Dispose() }');
  const mutate=spawnSync('pwsh',['-NoProfile','-File',mutationScript,'-Archive',zip],{encoding:'utf8'});
  assert.equal(mutate.status,0);assert.notEqual(validate().status,0);
 }finally{fs.rmSync(f.tmp,{recursive:true,force:true});}
});
