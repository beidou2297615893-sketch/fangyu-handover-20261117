'use strict';
// Offline contract example only: `native` MUST provide a genuinely atomic,
// durable compare-and-set on one encrypted record. This module does not supply
// Android storage, authenticate the server response, or enable production.
function createIdentityCoordinator(native){
 if(!native||typeof native.read!=='function'||typeof native.compareAndSet!=='function')throw Error('atomic store required');
 async function update(transform,afterFirstRead){
  for(let attempts=0;attempts<8;attempts++){
   const snapshot=await native.read();
   if(!snapshot||!Number.isSafeInteger(snapshot.version)||snapshot.version<0||!snapshot.record||typeof snapshot.record!=='object')throw Error('invalid record');
   if(attempts===0&&afterFirstRead)await afterFirstRead();
   const next=transform(structuredClone(snapshot.record));
   if(await native.compareAndSet(snapshot.version,next))return;
  }
  throw Error('concurrent identity update');
 }
 return Object.freeze({
  async rememberPurchase(intent,afterFirstRead){
   if(!intent||typeof intent.planId!=='string'||typeof intent.clientRequestId!=='string')throw Error('invalid purchase intent');
   await update(record=>{
    if(record.purchaseIntent&&(record.purchaseIntent.planId!==intent.planId||record.purchaseIntent.clientRequestId!==intent.clientRequestId))throw Error('purchase pending');
    record.purchaseIntent=structuredClone(intent);return record;
   },afterFirstRead);
  },
  async commitBinding(response,afterFirstRead){
   if(!response||typeof response.installationId!=='string'||typeof response.accessToken!=='string'||!/^[A-Za-z0-9_-]{43}$/.test(response.accessToken))throw Error('invalid binding');
   await update(record=>{
    if(!record.identity||record.identity.installationId!==response.installationId||!record.oauth||!['awaitingBind','awaitingAck'].includes(record.oauth.phase))throw Error('binding mismatch');
    if(record.oauth.phase==='awaitingBind'&&record.identity.accessToken!==record.oauth.installationBearer)throw Error('stale binding');
    if(record.oauth.phase==='awaitingAck'&&record.identity.accessToken!==response.accessToken)throw Error('inconsistent binding');
    record.identity.accessToken=response.accessToken;record.oauth.phase='awaitingAck';return record;
   },afterFirstRead);
  }
 });
}
module.exports={createIdentityCoordinator};
