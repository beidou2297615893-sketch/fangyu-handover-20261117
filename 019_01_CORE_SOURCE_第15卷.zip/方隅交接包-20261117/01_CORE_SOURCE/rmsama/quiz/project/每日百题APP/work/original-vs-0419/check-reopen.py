import control as c
import subprocess,time,json,hashlib,sys
folder=c.R/sys.argv[1]
final=json.loads((folder/'final-summary.json').read_text(encoding='utf-8'))
assert final['last']=='result' and final['confirmed']==100
pkg='com.jimusoft.dailyhundredapp.audit419.dev'
def js(name):
    pid=c.adb('shell','pidof',pkg).decode().strip()
    c.adb('forward','tcp:18785','localabstract:webview_devtools_remote_'+pid)
    return json.loads(subprocess.check_output(['node',str(c.R/'cdp.cjs'),'18785',str(c.R/name)],timeout=15))
def bank():return c.adb('exec-out','run-as',pkg,'cat','files/question-bank.json')
before=bank()
grant=c.adb('shell','settings','get','secure','enabled_accessibility_services').decode().strip()
assert pkg in grant
results=[{'action':'before','capabilities':js('read-capabilities.js')}]
js('stop-test-session.js');time.sleep(1)
for mode in ['background-reopen','process-stop-reopen']:
    if mode=='background-reopen':c.adb('shell','input','keyevent','KEYCODE_HOME')
    else:c.adb('shell','am','force-stop',pkg)
    time.sleep(1)
    c.launch(pkg);time.sleep(2)
    capabilities=js('read-capabilities.js')
    grantNow=c.adb('shell','settings','get','secure','enabled_accessibility_services').decode().strip()
    results.append({'action':mode,'capabilities':capabilities,'grantRetained':pkg in grantNow,
        'bankUnchanged':bank()==before})
out={'testOnlyPackage':pkg,'results':results,'bankSha256':hashlib.sha256(before).hexdigest(),
    'noPermissionWasReenabledDuringCheck':True,'phoneValidated':False}
(folder/'reopen-check.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
print(json.dumps(out))
