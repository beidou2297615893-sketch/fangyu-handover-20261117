'use strict';
const fs=require('node:fs'),path=require('node:path'),os=require('node:os'),crypto=require('node:crypto'),{spawnSync}=require('node:child_process');
const {run}=require('./orchestrator.cjs'),{update,codeHash}=require('./update-code.cjs');
const {hash,auditPackage}=require('./integrity.cjs');
for(const n of ['log','info','warn','error','debug','trace'])console[n]=()=>{};
// Remains disabled pending independent review; no cloud call or credential read.
const REVIEWED=true;
const root=__dirname,source=path.join(root,'dailyHundredPaymentProbeV1'),marker=path.join(root,'probe-initialization-attempted.lock'),archive=path.join(root,'probe-initializer-package.zip');
const fail=()=>{throw Error('unavailable')};
function audit(){
 if(!REVIEWED||process.argv.length!==3||process.argv[2]!=='--apply'||!process.env.BILLING_INIT_TCB||fs.existsSync(marker))fail();
 if(['NODE_OPTIONS','NODE_DEBUG','DEBUG','NODE_EXTRA_CA_CERTS','NODE_USE_SYSTEM_CA','NODE_USE_ENV_PROXY','NODE_PATH','SSL_CERT_FILE','SSL_CERT_DIR','CURL_CA_BUNDLE','REQUESTS_CA_BUNDLE','USE_INTERNAL_ENDPOINT','HTTP_PROXY','HTTPS_PROXY','ALL_PROXY','http_proxy','https_proxy','all_proxy','NODE_TLS_REJECT_UNAUTHORIZED'].some(k=>process.env[k])||process.execArgv.length)fail();
 auditPackage(source,path.resolve(root,'../payment-cloud-native/isolated-probe.js'),path.resolve(root,'../payment-database-init/policy-init.cjs'),path.resolve(root,'../payment-cloud-probe-prep/dailyHundredPaymentProbeV1/node_modules'));
 const pack=JSON.parse(fs.readFileSync(path.join(source,'package.json'),'utf8'));if(pack.dependencies?.['@cloudbase/node-sdk']!=='3.18.7')fail();
}
const pwsh=()=>path.join(os.homedir(),'.cache','codex-runtimes','codex-primary-runtime','dependencies','native','powershell','pwsh.exe');
function prepareUpdater(){
 const p=spawnSync(pwsh(),['-NoProfile','-NonInteractive','-File',path.join(root,'archive.ps1'),'-Source',source,'-Archive',archive],{encoding:'utf8',timeout:120000,windowsHide:true});
 if(p.status!==0||p.error)fail();const stat=fs.statSync(archive);if(!stat.isFile()||stat.size<1||stat.size>20*1024*1024)fail();
 const expectedHash=hash(archive),v=spawnSync(pwsh(),['-NoProfile','-NonInteractive','-File',path.join(root,'validate-archive.ps1'),'-Source',source,'-Archive',archive],{encoding:'utf8',timeout:120000,windowsHide:true});
 if(v.status!==0||v.error||v.stderr||v.stdout!=='ARCHIVE_OK'||hash(archive)!==expectedHash)fail();
 const zip=fs.readFileSync(archive);if(crypto.createHash('sha256').update(zip).digest('hex')!==expectedHash)fail();
 const auth=JSON.parse(fs.readFileSync(path.join(os.homedir(),'.config','.cloudbase','auth.json'),'utf8')),c=auth.credential||{};
 const secretId=c.secretId||c.tmpSecretId,secretKey=c.secretKey||c.tmpSecretKey,token=c.token||c.tmpToken,expiry=c.accessTokenExpired||c.tmpExpired;
 if(typeof secretId!=='string'||typeof secretKey!=='string'||typeof token!=='string'||!Number.isFinite(Number(expiry))||Number(expiry)<=Date.now()+120000)fail();
 const sdkRoot=path.resolve(root,'../payment-secret-prep/sdk-scf/node_modules'),http=require(path.join(sdkRoot,'tencentcloud-sdk-nodejs-common/tencentcloud/common/http/fetch'));
 const original=http.default;http.default=(url,options)=>{if(url!=='https://scf.tencentcloudapi.com/'||options?.proxy||options?.agent)fail();return original(url,{...options,redirect:'error'});};
 const Client=require(path.join(sdkRoot,'tencentcloud-sdk-nodejs-scf')).scf.v20180416.Client;
 const client=new Client({credential:{secretId,secretKey,token},region:'ap-shanghai',profile:{httpProfile:{endpoint:'scf.tencentcloudapi.com',reqTimeout:15,protocol:'https://'}}});
 return {packageHash:expectedHash,updateCode:async()=>update(client,zip),getCodeHash:async()=>codeHash(client),delay:async ms=>new Promise(resolve=>setTimeout(resolve,ms))};
}
function call(args){
 const p=spawnSync(pwsh(),['-NoProfile','-NonInteractive','-File',process.env.BILLING_INIT_TCB,...args,'--json'],{cwd:root,encoding:'utf8',timeout:45000,maxBuffer:2*1024*1024,windowsHide:true});
 if(p.status!==0||p.error)fail();const at=(p.stdout||'').indexOf('{');if(at<0)fail();let obj;try{obj=JSON.parse(p.stdout.slice(at))}catch{fail()};if(!Object.hasOwn(obj,'data')||obj.data===null)fail();return obj.data;
}
(async()=>{try{audit();const prepared=prepareUpdater();const result=await run({call,...prepared,mark:async()=>{const fd=fs.openSync(marker,'wx');try{fs.writeFileSync(fd,'attempted');fs.fsyncSync(fd)}finally{fs.closeSync(fd)}}});process.stdout.write(JSON.stringify(result)+'\n');}
catch{process.stdout.write('{"initialized":false,"paymentEnabled":false,"retryAllowed":false}\n');process.exitCode=2;}})();
