from pathlib import Path
import os, shutil
cache=Path("V:/work/gradle-home/caches/modules-2/files-2.1"); out=Path("V:/work/ocr0419-evidence/local-maven")
count=0
for group in cache.iterdir():
 if not group.is_dir():continue
 for artifact in group.iterdir():
  if not artifact.is_dir():continue
  for version in artifact.iterdir():
   if not version.is_dir():continue
   for src in version.glob("*/*"):
    if src.suffix not in (".pom",".aar",".jar",".module") or not src.is_file():continue
    dest=out.joinpath(*group.name.split("."),artifact.name,version.name,src.name)
    if dest.exists(): continue
    dest.parent.mkdir(parents=True,exist_ok=True)
    try:os.link(src,dest)
    except OSError:shutil.copyfile(src,dest)
    count+=1
print(count)
