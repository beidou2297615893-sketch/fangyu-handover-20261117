import control as c
import json,hashlib,time,re
out=c.R/'formal-upgrade';out.mkdir(exist_ok=True)
assert not (out/'fixture-prepared.json').exists(),'Do not reset an existing upgrade fixture.'
pkg='com.jimusoft.dailyhundredapp';qa=pkg+'.audit419.dev'
version=c.adb('shell','dumpsys','package',pkg).decode(errors='replace')
versionName=re.search(r'versionName=(\S+)',version).group(1)
assert versionName=='0.4.19',versionName
c.adb('shell','am','force-stop',pkg)
path='/data/user/0/'+pkg+'/files/question-bank.json'
before=c.adb('exec-out','cat',path);(out/'bank-before-fixture.json').write_bytes(before)
fixture=c.adb('exec-out','cat','/data/user/0/'+qa+'/files/question-bank.json')
assert len(json.loads(fixture)['questions'])==1859
file=out/'bank-1859-before-upgrade.json';file.write_bytes(fixture)
uid=c.adb('shell','stat','-c','%u','/data/user/0/'+pkg).decode().strip()
c.adb('push',file,path);c.adb('shell','chown',uid+':'+uid,path);c.adb('shell','restorecon',path)
assert c.adb('exec-out','cat',path)==fixture
record={'serial':c.SERIAL,'oldVersion':versionName,'bankWasExplicitlySeededForUpgradeTest':True,
    'bankBeforeFixture':len(json.loads(before)['questions']),'bankBeforeUpgrade':1859,
    'sha256':hashlib.sha256(fixture).hexdigest(),'physicalPhoneTouched':False,'ledgerChanged':False,'preparedAt':time.time()}
(out/'fixture-prepared.json').write_text(json.dumps(record,indent=2),encoding='utf-8')
print(json.dumps(record))
