from pathlib import Path
import hashlib,json,zipfile,xml.etree.ElementTree as E
r=Path(__file__).resolve().parent;project=r.parent.parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
original=project/'outputs/题镜官方原版/TiJing-0.7.7-open.apk'
shipping=project/'outputs/知题 0.4.19 安卓版/知题-0.4.19.apk'
candidate=r/'regression-stage/app/build/outputs/apk/dev/debug/app-dev-debug.apk'
assert sha(original)=='3f4988b2fe4c5eaab22c4e604468c9c99114a0ce3b522611601b2b9a0fcff20f'
proof=json.loads((r/'original-control/proof.json').read_text(encoding='utf-8'))
assert proof['nativeCodeUnchanged'] and len(proof['originalNativeFiles'])==16 and all(proof['originalNativeFiles'].values())
inputs=json.loads((r/'regression-source-manifest.json').read_text(encoding='utf-8'))
main=project/'work/tijing-bankassist/android/app/src/main/java'
stage=r/'regression-stage/app/src/diagnosticShared/java'
for row in inputs:
    assert sha(main/row['path'])==row['sha256'],row['path']
    if row['equal']:assert sha(stage/row['path'])==row['sha256'],row['path']
with zipfile.ZipFile(shipping) as prod,zipfile.ZipFile(candidate) as qa:
    web=[n for n in prod.namelist() if n.startswith('assets/web/') and not n.endswith('/')]
    assert all(prod.read(n)==qa.read(n) for n in web)
    groups={'onnxRuntime':0,'mlkit':0,'readerModel':0,'other':0}
    for info in prod.infolist():
        n=info.filename
        group='onnxRuntime' if 'libonnxruntime' in n else 'mlkit' if ('gocr' in n or 'mlkit' in n) else 'readerModel' if n.endswith('.onnx') else 'other'
        groups[group]+=info.compress_size
tests={}
for label,folder in [('original',r/'original-control/source/android/app/build/test-results/testDevDebugUnitTest'),('fixed',r/'regression-stage/app/build/test-results/testDevDebugUnitTest')]:
    rows=[E.parse(f).getroot().attrib for f in folder.glob('TEST-*.xml')]
    tests[label]={k:sum(int(x[k]) for x in rows) for k in ['tests','failures','errors','skipped']}
    assert tests[label]['tests']>0 and all(tests[label][k]==0 for k in ['failures','errors','skipped'])
report={'officialApk':{'bytes':original.stat().st_size,'sha256':sha(original)},'shippingApk':{'bytes':shipping.stat().st_size,'sha256':sha(shipping)},'fixedDiagnosticApk':{'bytes':candidate.stat().st_size,'sha256':sha(candidate),'shippingWebEntriesUnchanged':len(web),'productionKotlinFilesUnchangedDuringBuild':len(inputs),'sharedKotlinExactlyMatchesProduction':sum(x['equal'] for x in inputs)},'compressedSizeGroups':groups,'unitTests':tests,'originalControlNativeFilesUnchanged':16,'phoneTested':False,'paymentTestedInThisComparison':False,'published':False}
(r/'evidence-audit.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(report,ensure_ascii=False))
