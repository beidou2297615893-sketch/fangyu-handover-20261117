import control as c
from pathlib import Path
import subprocess,time,json,sys
r=Path('V:/work/original-vs-0419');pkg='com.jimusoft.dailyhundredapp.audit419.dev';host='com.jimusoft.railwaymp.canvas419'
def js(port,name):
    out=subprocess.check_output(['node',str(r/'cdp.cjs'),str(port),str(r/name)],timeout=15)
    print(out.decode(),flush=True)
apk=Path(sys.argv[1]) if len(sys.argv)>1 else r/'fixed-current/source/android/app/build/outputs/apk/dev/debug/app-dev-debug.apk'
c.adb('install','-r',apk,timeout=60)
c.adb('reverse','tcp:18765','tcp:18765')
hostPid=c.adb('shell','pidof',host).decode().strip();c.adb('forward','tcp:18786','localabstract:webview_devtools_remote_'+hostPid)
js(18786,'cancel-host-animation.js')
c.adb('shell','run-as',host,'truncate','-s','0','files/events.jsonl')
js(18786,'start-hidden-host.js')
c.adb('shell','settings','put','secure','enabled_accessibility_services',pkg+'/com.futureyyy.tijing.QuizAccessibilityService')
c.adb('shell','appops','set',pkg,'SYSTEM_ALERT_WINDOW','allow')
c.adb('shell','pm','grant',pkg,'android.permission.POST_NOTIFICATIONS')
c.adb('shell','am','start','-n',pkg+'/com.futureyyy.tijing.MainActivity')
time.sleep(1)
pid=c.adb('shell','pidof',pkg).decode().strip();c.adb('forward','tcp:18785','localabstract:webview_devtools_remote_'+pid)
js(18785,'start-qa-ui.js')
time.sleep(.5);c.click('START');time.sleep(2)
c.adb('shell','am','start','-n',host+'/com.jimusoft.railwaymp.MainActivity');time.sleep(1)
(r/'fixed-current-ready.png').write_bytes(c.adb('exec-out','screencap','-p'))
print('Patched answering core ready on the same railway page and order.',flush=True)
