import control as c
import json,sys
folder=c.R/sys.argv[1]
rows=[json.loads(x) for x in c.adb('exec-out','run-as','com.jimusoft.railwaymp.canvas419','cat','files/events.jsonl').splitlines()]
at=max(i for i,x in enumerate(rows) if x['evt']=='start');rows=rows[at:]
done=[x['data'] for x in rows if x['evt']=='confirm']
p=json.loads((folder/'current-progress.json').read_text(encoding='utf-8'))
original_only=len(sys.argv)>2 and sys.argv[2]=='original_baseline'
p.update(confirmed=len(done),correct=sum(x['correct'] for x in done),wrong=sum(not x['correct'] for x in done),
    last=rows[-1]['evt'],phase='STOPPED_FOR_ORIGINAL_BASELINE' if original_only else 'STOPPED_FOR_REFINEMENT',
    reason='User prioritized repeated original-only runs before adding any integration; this controlled interruption is not a pass or a failure.' if original_only else 'Removed an invalid assumption that runner ordinal equals host question counter; this controlled interruption is not a pass or a failure.')
(folder/'final-summary.json').write_text(json.dumps(p,indent=2),encoding='utf-8')
(folder/'current-progress.json').write_text(json.dumps(p,indent=2),encoding='utf-8')
(folder/'current-run-events.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf-8')
(folder/'current-run-log.txt').write_bytes(c.adb('logcat','-d','-v','brief','TiJingRunner:I','ZhitiBank:I','*:S'))
(folder/'current-final.png').write_bytes(c.adb('exec-out','screencap','-p'))
print(json.dumps(p))
