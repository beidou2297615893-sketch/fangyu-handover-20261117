import control as c
import subprocess,sys,json
folder=c.R/sys.argv[1];folder.mkdir(exist_ok=True)
with (folder/'continuous-log.txt').open('wb') as output:
    child=subprocess.Popen([str(c.ADB),'-P','15037','-s',c.SERIAL,'logcat','-v','threadtime',
        'TiJingRunner:I','ZhitiBank:I','ZhitiDiagnostic:I','*:S'],stdout=output,stderr=subprocess.STDOUT,
        creationflags=subprocess.CREATE_NO_WINDOW)
(folder/'log-recorder-pid.json').write_text(json.dumps({'pid':child.pid,'serial':c.SERIAL,'adbPort':15037}),encoding='utf-8')
print('Continuous test-only log recorder started:',child.pid)
