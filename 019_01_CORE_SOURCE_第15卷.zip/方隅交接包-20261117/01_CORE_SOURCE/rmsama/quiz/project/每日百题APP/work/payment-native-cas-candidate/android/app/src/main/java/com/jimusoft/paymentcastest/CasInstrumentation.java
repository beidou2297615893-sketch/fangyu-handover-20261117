package com.jimusoft.paymentcastest;
import android.app.Instrumentation;
import android.content.*;
import android.os.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.*;
import java.util.concurrent.*;
import org.json.*;
public final class CasInstrumentation extends Instrumentation {
 private final JSONArray checks=new JSONArray();
 private void check(boolean ok,String name)throws Exception{checks.put(name+": "+ok);if(!ok)throw new AssertionError(name);}
 @Override public void onCreate(Bundle b){super.onCreate(b);start();}
 private JSONObject value(String token,String intent)throws Exception{return new JSONObject().put("installationId","synthetic-owner").put("accessToken",token).put("purchaseIntent",intent).put("oauth",new JSONObject().put("phase","awaitingAck").put("installationBearer","synthetic-original"));}
 @Override public void onStart(){Bundle result=new Bundle();HandlerThread replyThread=null;ServiceConnection connection=null;try{
  check(android.os.Build.HARDWARE.contains("ranchu"),"emulator only");
  Context ctx=getTargetContext();String id="case-"+UUID.randomUUID();CandidateStore store=new CandidateStore(ctx,id);
  check(store.read()==null,"new independent record");check(store.compareAndSet(-1,value("synthetic-original","none")),"first encrypted write");
  JSONObject first=store.read();check(first.getLong("version")==0,"initial version");
  byte[] encrypted=Files.readAllBytes(new java.io.File(new java.io.File(ctx.getNoBackupFilesDir(),id),"record.enc").toPath());
  check(!new String(encrypted,StandardCharsets.UTF_8).contains("synthetic-original"),"plaintext absent from record file");
  check(!store.compareAndSet(-1,value("stale","none")),"stale version rejected");
  int threads=12;ExecutorService pool=Executors.newFixedThreadPool(threads);CountDownLatch readAll=new CountDownLatch(threads),go=new CountDownLatch(1);List<Future<Boolean>> futures=new ArrayList<>();
  for(int i=0;i<threads;i++){final int n=i;futures.add(pool.submit(()->{CandidateStore peer=new CandidateStore(ctx,id);long version=peer.read().getLong("version");readAll.countDown();if(!go.await(10,TimeUnit.SECONDS))throw new IllegalStateException("barrier");return peer.compareAndSet(version,value("thread-"+n,"none"));}));}
  check(readAll.await(20,TimeUnit.SECONDS),"all threads read the same version");go.countDown();int winners=0;for(Future<Boolean> f:futures)if(f.get(30,TimeUnit.SECONDS))winners++;pool.shutdownNow();check(winners==1,"exactly one concurrent thread committed");check(store.read().getLong("version")==1,"thread race increments once");
  CountDownLatch connected=new CountDownLatch(1);final Messenger[] remote=new Messenger[1];connection=new ServiceConnection(){public void onServiceConnected(ComponentName name,IBinder binder){remote[0]=new Messenger(binder);connected.countDown();}public void onServiceDisconnected(ComponentName name){}};
  check(ctx.bindService(new Intent(ctx,Worker.class),connection,Context.BIND_AUTO_CREATE),"bind independent worker process");check(connected.await(15,TimeUnit.SECONDS),"worker connected");
  replyThread=new HandlerThread("cas-replies");replyThread.start();BlockingQueue<Bundle> queue=new LinkedBlockingQueue<>();Messenger receiver=new Messenger(new Handler(replyThread.getLooper()){public void handleMessage(Message msg){queue.offer(msg.getData());}});
  Message read=Message.obtain(null,1);Bundle readData=new Bundle();readData.putString("case",id);read.setData(readData);read.replyTo=receiver;remote[0].send(read);Bundle remoteSnapshot=queue.poll(15,TimeUnit.SECONDS);check(remoteSnapshot!=null&&!remoteSnapshot.containsKey("error"),"worker read");check(remoteSnapshot.getInt("pid")!=android.os.Process.myPid(),"worker is a distinct Android process");
  long version=new JSONObject(remoteSnapshot.getString("record")).getLong("version");check(version==store.read().getLong("version"),"processes observed same version");
  Message commit=Message.obtain(null,2);Bundle commitData=new Bundle();commitData.putString("case",id);commitData.putLong("version",version);commitData.putString("value",value("bound-token","none").toString());commit.setData(commitData);commit.replyTo=receiver;remote[0].send(commit);Bundle committed=queue.poll(15,TimeUnit.SECONDS);check(committed!=null&&!committed.containsKey("error")&&committed.getBoolean("accepted"),"worker commits binding");
  check(!store.compareAndSet(version,value("stale-token","once")),"stale purchase rejected across processes");
  JSONObject latest=store.read(),merged=latest.getJSONObject("value");merged.put("purchaseIntent","once");check(store.compareAndSet(latest.getLong("version"),merged),"purchase rereads and merges");
  JSONObject finalValue=new CandidateStore(ctx,id).read().getJSONObject("value");check(finalValue.getString("accessToken").equals("bound-token")&&finalValue.getString("purchaseIntent").equals("once")&&finalValue.getJSONObject("oauth").getString("installationBearer").equals("synthetic-original"),"bound token, purchase and old bearer preserved");
  result.putString("status","passed");
 }catch(Throwable error){result.putString("status","failed");result.putString("failure",String.valueOf(error));}
 finally{if(connection!=null)try{getTargetContext().unbindService(connection);}catch(Exception ignored){}if(replyThread!=null)replyThread.quitSafely();result.putString("checks",checks.toString());finish("passed".equals(result.getString("status"))?-1:0,result);}}
}
