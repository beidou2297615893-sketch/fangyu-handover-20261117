package com.futureyyy.tijing.payment

import org.json.JSONObject

internal fun gatewayEndAction(runId:String,savedRun:String?,savedState:String?):String = when {
    savedRun==runId && savedState=="closed" -> "clear"
    savedRun==runId -> "close"
    savedRun==null || savedState=="closed" -> "abandon"
    else -> "blocked"
}

internal fun gatewayFreshStartAllowed(phase:String?,submissionState:String?,savedState:String?):Boolean =
    phase=="released" && submissionState=="none" && savedState=="closed"

internal fun finishGatewayEnd(runId:String,token:String,persist:(String)->Unit,requestClose:()->Boolean,clearRun:()->Unit) {
    persist(JSONObject().put("runId",runId).put("token",token).put("state","ending").toString())
    check(requestClose()) { "本轮已结束，结束状态待核对，请在支付页点核对付款状态。" }
    persist(JSONObject().put("runId",runId).put("state","closed").toString())
    clearRun()
}
