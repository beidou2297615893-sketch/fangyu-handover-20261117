'use strict';
// Local candidate only. It cannot initialize a CloudBase client itself and is
// not an exported cloud function. A future independently reviewed, IAM-only
// wrapper must supply the DB after collection/ACL verification.
const COLLECTIONS=Object.freeze(['daily_hundred_payment_v1','daily_hundred_installation_v1']);
function createPolicyInitializer(db){
  if(!db||typeof db.runTransaction!=='function')throw Error('unavailable');
  return async function initialize(event){
    if(!event||typeof event!=='object'||Array.isArray(event)||Object.keys(event).join(',')!=='action'||!['initialize-disabled-policy','verify-disabled-policy'].includes(event.action))return {initialized:false,paymentEnabled:false};
    try{
      await db.runTransaction(async tx=>{
        const refs=COLLECTIONS.map(name=>tx.collection(name).doc('policy'));
        if(event.action==='verify-disabled-policy'){
          for(const ref of refs){const r=await ref.get(),v=r?.data;
            if(!r||r.code||!v||v._id!=='policy'||v.kind!=='policy'||v.schema!==1||v.enabled!==false||Object.keys(v).sort().join(',')!=='_id,enabled,kind,schema')throw Error('invalid');}
          return;
        }
        // Check every document before writing either; never overwrite an
        // existing record, including an enabled one.
        for(const ref of refs){const r=await ref.get();if(!r||r.code||r.data!==null)throw Error('conflict');}
        for(const ref of refs){const w=await ref.set({kind:'policy',schema:1,enabled:false});
          if(!w||w.code||!(w.updated===1||w.updated===0&&Array.isArray(w.upserted)&&w.upserted.some(x=>x?._id==='policy')))throw Error('unavailable');}
      },1);
      return {initialized:true,paymentEnabled:false};
    }catch{return {initialized:false,paymentEnabled:false};}
  };
}
module.exports={createPolicyInitializer};
