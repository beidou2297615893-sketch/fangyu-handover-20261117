(()=>{window.AndroidBridge.stopFloatingSession();return {stopped:true};})()
