from pathlib import Path
root=Path('C:/Users/rmsama/DailyHundredNativeBuild/work/app')
changes=[
 (root/'modules/automation-bridge/android/build.gradle',"buildConfigField 'boolean', 'BILLING_ADMISSION_ENABLED', 'false'","buildConfigField 'boolean', 'BILLING_ADMISSION_ENABLED', 'true'"),
 (root/'modules/automation-bridge/android/src/main/java/expo/modules/automationbridge/billing/NativeAdmissionClient.kt','return AdmissionClient(validateOrigin(BuildConfig.BILLING_ADMISSION_ORIGIN,false),source)','return AdmissionClient(validateOrigin("http://127.0.0.1:18765",true),source)'),
 (root/'android/app/src/main/AndroidManifest.xml','<application android:name=".MainApplication"','<application android:usesCleartextTraffic="true" android:name=".MainApplication"'),
]
for path,old,new in changes:
    value=path.read_text(encoding='utf-8')
    if value.count(old)!=1: raise SystemExit(f'unexpected isolated stage: {path.name}')
    path.write_text(value.replace(old,new),encoding='utf-8')
print('Isolated stage patched for loopback-only synthetic billing; project source unchanged.')
