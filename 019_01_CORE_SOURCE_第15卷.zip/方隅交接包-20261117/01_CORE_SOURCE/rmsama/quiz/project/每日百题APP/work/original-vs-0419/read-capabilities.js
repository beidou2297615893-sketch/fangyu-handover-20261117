JSON.parse(AndroidBridge.floatingCapabilities())
