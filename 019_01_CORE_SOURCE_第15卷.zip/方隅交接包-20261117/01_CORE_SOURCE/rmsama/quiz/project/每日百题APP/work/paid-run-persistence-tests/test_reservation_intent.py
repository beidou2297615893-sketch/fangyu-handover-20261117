"""Exercises the Android SQL on real SQLite files and isolated child processes."""
import os, pathlib, re, sqlite3, subprocess, sys, tempfile, unittest
ROOT=pathlib.Path(__file__).resolve().parents[2]
BASE=ROOT/'outputs/daily-hundred-app/modules/automation-bridge/android/src/main/java/expo/modules/automationbridge/billing'
def sql(file,name):
    text=(BASE/file).read_text(encoding='utf-8')
    found=re.search(r'const val '+name+r'\s*=\s*"([^"\n]+)"',text)
    if not found: raise RuntimeError('missing SQL: '+name)
    return found.group(1)
def dbopen(path):
    db=sqlite3.connect(path,timeout=10)
    try:
        db.execute(sql('PaidReservationStore.kt','CREATE_INTENT_SQL'))
        db.execute(sql('PaidRunStore.kt','CREATE_SQL'))
    except Exception: db.close();raise
    return db
def worker(mode, local, server):
    if mode=='server-commit-lost-response':
        db=sqlite3.connect(server);db.execute('CREATE TABLE IF NOT EXISTS reservations(run_id TEXT PRIMARY KEY,binding TEXT NOT NULL)')
        db.execute('INSERT OR IGNORE INTO reservations VALUES(?,?)',('run','a'*64));db.commit();os._exit(7)
    db=dbopen(local);db.execute('BEGIN IMMEDIATE')
    db.execute(sql('PaidRunStore.kt','INSERT_SQL'),('run','owner','a'*64,'credit','reserved'))
    db.execute(sql('PaidReservationStore.kt','SETTLE_INTENT_SQL'),('reserved','run','owner','a'*64,'reserved'))
    os._exit(7)
class ReservationIntentTest(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(dir=pathlib.Path(__file__).parent)
        self.local=str(pathlib.Path(self.tmp.name)/'local.sqlite');self.server=str(pathlib.Path(self.tmp.name)/'server.sqlite');self.db=dbopen(self.local)
    def tearDown(self): self.db.close();self.tmp.cleanup()
    def prepare(self):
        self.db.execute(sql('PaidReservationStore.kt','INSERT_INTENT_SQL'),('run','owner','a'*64,'preparing'))
        self.db.commit()
    def intent(self): return self.db.execute(sql('PaidReservationStore.kt','READ_INTENT_SQL'),('run',)).fetchone()
    def child(self,mode): return subprocess.run([sys.executable,__file__,'--worker',mode,self.local,self.server],timeout=20,capture_output=True)
    def test_preparing_survives_lost_response_and_retries_same_run(self):
        self.prepare();self.assertEqual(self.child('server-commit-lost-response').returncode,7)
        self.db.close();self.db=dbopen(self.local)
        self.assertEqual(self.intent(),('owner','a'*64,'preparing',None))
        with sqlite3.connect(self.server) as server:
            server.execute('INSERT OR IGNORE INTO reservations VALUES(?,?)',('run','a'*64))
            self.assertEqual(server.execute('SELECT count(*) FROM reservations').fetchone()[0],1)
    def test_conflicting_owner_or_binding_does_not_replace_intent(self):
        self.prepare();self.db.execute(sql('PaidReservationStore.kt','INSERT_INTENT_SQL'),('run','other','b'*64,'preparing'))
        self.assertEqual(self.intent(),('owner','a'*64,'preparing',None))
    def test_crash_rolls_back_paid_record_and_settled_marker(self):
        self.prepare();self.assertEqual(self.child('local-crash').returncode,7)
        self.assertEqual(self.intent(),('owner','a'*64,'preparing',None))
        self.assertIsNone(self.db.execute(sql('PaidRunStore.kt','READ_SQL'),('run',)).fetchone())
    def test_confirmed_status_cannot_regress_to_reserved(self):
        self.prepare()
        self.assertEqual(self.db.execute(sql('PaidReservationStore.kt','SETTLE_INTENT_SQL'),('confirmed','run','owner','a'*64,'confirmed')).rowcount,1)
        self.assertEqual(self.db.execute(sql('PaidReservationStore.kt','SETTLE_INTENT_SQL'),('reserved','run','owner','a'*64,'reserved')).rowcount,0)
if __name__=='__main__':
    if len(sys.argv)==5 and sys.argv[1]=='--worker': worker(*sys.argv[2:])
    else: unittest.main()
