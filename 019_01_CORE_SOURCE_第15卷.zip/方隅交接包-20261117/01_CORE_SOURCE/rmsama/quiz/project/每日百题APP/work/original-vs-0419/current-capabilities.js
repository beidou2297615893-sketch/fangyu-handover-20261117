(()=>({capabilities:JSON.parse(window.AndroidBridge.floatingCapabilities()),text:document.body.innerText.slice(0,1100)}))()
