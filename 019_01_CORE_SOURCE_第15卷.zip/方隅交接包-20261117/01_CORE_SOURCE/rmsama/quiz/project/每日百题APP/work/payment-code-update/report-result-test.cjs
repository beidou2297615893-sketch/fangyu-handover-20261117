'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict'),{spawnSync}=require('node:child_process');
const reporter=require.resolve('./report-result.cjs');
test('the real command result reporter exits nonzero for failures or unknown outcomes',()=>{
 for(const expression of ['Promise.resolve({updated:false,result:"not-submitted"})','Promise.resolve({updated:false,result:"unknown"})','Promise.reject(Error("synthetic"))']){
  const child=spawnSync(process.execPath,['-e',`require(${JSON.stringify(reporter)}).reportResult(()=>${expression})`],{encoding:'utf8'});
  assert.equal(child.status,2);assert.equal(JSON.parse(child.stdout).updated,false);
 }
});
test('verified success alone exits zero',()=>{
 const child=spawnSync(process.execPath,['-e',`require(${JSON.stringify(reporter)}).reportResult(()=>Promise.resolve({updated:true}))`],{encoding:'utf8'});
 assert.equal(child.status,0);assert.equal(JSON.parse(child.stdout).updated,true);
});
