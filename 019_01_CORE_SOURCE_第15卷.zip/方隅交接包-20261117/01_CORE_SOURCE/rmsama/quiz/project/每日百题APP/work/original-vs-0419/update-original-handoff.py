from pathlib import Path
import json,datetime
r=Path(__file__).resolve().parent
project=r.parent.parent
out=project/'outputs/开发交接/知题-原版多轮验证-AI交接.md'
now=datetime.datetime.now().astimezone().isoformat(timespec='seconds')
quota=json.loads((r/'quota-latest.json').read_text(encoding='utf-8'))
state=json.loads((r/'original-phase.json').read_text(encoding='utf-8'))
state.update(updatedAt=now,originalNewRoundsStarted=True,originalFullRoundsCompleted=0,
    quotaRemainingLastSeen=quota['remainingPercent'],originalModel='deepseek-chat',originalEndpoint='https://api.deepseek.com',
    originalBankImportedThroughUI=1859,originalApiKeyPresentInDedicatedEmulator=True,
    testHelperClickFixed=True,unverifiedModeAttemptsExcluded=True)
state['originalCurrentGraphics']='host (NVIDIA RTX 5070 Ti)'
state['testSummaries']={}
for name in ['host-auto-01','host-assisted-01','host-assisted-02','host-assisted-03']:
    p=r/'original-only-rounds'/name/'final-summary.json'
    if p.exists():state['testSummaries'][name]=json.loads(p.read_text(encoding='utf-8'))
cleanupPath=r/'original-only-rounds/test-cleanup.json'
cleanup=json.loads(cleanupPath.read_text(encoding='utf-8')) if cleanupPath.exists() else {}
if cleanup.get('temporaryApiKeyCleared'):
    state.update(originalApiKeyPresentInDedicatedEmulator=False,originalBankCurrentlyOnDevice=0,
        testCleanup=cleanup,activeOriginalModelCalls=False,originalRoundAssessmentFinished=True)
(r/'original-phase.json').write_text(json.dumps(state,ensure_ascii=False,indent=2),encoding='utf-8')
body=out.read_text(encoding='utf-8')
marker='<!-- latest-original-progress -->'
if marker in body:
    head,tail=body.split(marker,1)
    body=head+tail.split('<!-- /latest-original-progress -->',1)[1]
note=f'''{marker}
## 最新现场覆盖以下旧记录（{now}）

- 最新真实额度剩{quota['remainingPercent']}%，见quota-latest.json；<=2%立即停止自己的运行并交接。
- 原版官方APK未改代码，已通过正常UI配置https://api.deepseek.com、deepseek-chat；模型别名虽然不在/models列表，真实铁路题图、原始prompt、temperature0/max_tokens1200/response_format请求HTTP200，有有效JSON并答对首题C。不经代理，不改thinking参数。证据original-only-rounds/provider-config-check.json及两份unchanged-request-result.json。此处单张API成功不等于APP整轮成功。
- 已通过原版“导入”与Android文件选择器导入1859道真实铁路题，UI确认1859条。原版无障碍、悬浮、截图授权均已准备。测试专用模拟器目前保存本项目临时API key；结束后仅清理此副本，不能输出key、上传配置或清理真机。
- 发现并修正测试控制脚本control.py的文字匹配缺陷：旧click('自动刷题')可能选中下面包含该词的示例题干，而非按钮；现在精确文字优先、可点击控件优先。仅改测试脚本，未改软件。round01/round02及retry02/03等早期文件模式未确认，不可当自动100题证据。其中round01-after12确为截图超时，round02-after20为“页面似乎未进入下一题”，两者均0提交，不能臆称已三次自动截图超时。
- 已重新通过按钮坐标选择自动模式，核对运行台底部变为“自动刷题”，重新创建悬浮会话。auto-confirmed-round01.png明确第一题“截图超时”；宿主0提交。之后auto-confirmed-retry开头文件记录同场重试，须逐张核实，不能凭文件名推断通过/失败。新原版完整100题轮数仍为0。
- 宿主com.jimusoft.railwaymp.canvas419使用铁路100题，启动后调用cancel-host-animation.js，未添加1px动画。直接原模型配置；旧本地relay即使仍监听也未用于当前原版。
- 下一步先核实后续重试，再对截图环境做可逆对照（例如仅专用模拟器Swiftshader与host图形模式差别、可访问文字宿主差别）；不改原版源码。若改宿主持续重绘，只能标为辅助诊断，不算自然原版通过。旧monitor-current.py仍遇首错即停，不能用于新完整轮次，需独立监控错题但继续。不要调用旧write-comparison-report.py或write-original-handoff.py覆盖本最新交接。
- 后续新增实证：专用模拟器已从Swiftshader切到host图形，SurfaceFlinger确认NVIDIA RTX 5070 Ti；不改APK。host-auto-01记录了自动模式、首题及两次重试共3次“截图超时”、0提交，final-summary.json已存。GPU模式切换本身没有消除问题。
- 辅助诊断host-assisted-01：仅宿主页1px持续重绘，原APK未改、直连原有模型；首题C确实提交且判分正确，随后停在这道题的判分页，画面有“下一题”，原版报“点击确认失败”。1对/0错/1提交，完整场0，不能说100%正确率。源码全局搜索nextBox/next_box仅在结果解析与prompt出现，QuizActionPlan只有answerOptions/confirmBox，自动执行没有消费nextBox。它会把判分反馈的画面变化当成进入新题；原版未适配我们这种独立“下一题”按钮流程。
- 辅助诊断host-assisted-02同样首题正确，保存截图时原版显示“第2题识别中”，实际仍是首题判分页；随后外部停止，final-summary为STOPPED_AFTER_OBSERVATION，不能说该场已自然暂停。host-assisted-03若已有final-summary则以其为准，未存在不能猜测成绩。
- 测试工具另修了control.py的旧XML风险：uiautomator可能失败却退出0，旧脚本仍读上次compare-ui.xml；现在先删除这个专用测试XML，再核对dumped to输出后读取。软件未改。setup-official-original.py增加等待宿主事件绑定、精确选择自动模式、核对底部模式、授权后等待。运行中不调用uiautomator。Android force-stop会关闭本模拟器无障碍服务，这是测试自己的强停影响，不得误说成原版正常退出重开就丢权限；下一轮脚本会在此专用模拟器恢复原服务。
- 用户最新允许扩展到非GitHub和收费APK，已完成公开资料初筛，同目录《现成软件与替代底座初筛.md》；小包搜题/试题通/刷刷题只有导库/搜题的已核实资料，没有铁路自动100题实测；AutoJs6与按键精灵是候选底座而非即用铁路成品。未付款、未联系卖家、未安装这些候选、未上传用户题库、未更换工程。不能把“用户愿意比较收费软件”当作任意金额购买或付费部署授权。
- 最终清理记录（若空则未清理）：{json.dumps(cleanup,ensure_ascii=False)}。若temporaryApiKeyCleared=true，则上面“本机有key/1859条”的描述指测试时状态；现在专用原版副本已pm clear，题库为0、配置为空，下模型需重新导入same-bank-1859.json并配置。APK仍安装、全部题库源文件与证据保留，未动用户手机。此时不要跑空配置并误算原版失败。原版自然完整场0；辅助刷新01/03均1题正确后自然暂停，02为1题正确后外部停止，不可合并成3/100或声称100%准确率。

最新已存轮次摘要（不是100题完成场）：

```json
{json.dumps(state['testSummaries'],ensure_ascii=False,indent=2)}
```

<!-- /latest-original-progress -->
'''
first,rest=body.split('\n',1)
out.write_text(first+'\n\n'+note+'\n'+rest.lstrip(),encoding='utf-8')
print(json.dumps({'handoff':str(out),'remainingPercent':quota['remainingPercent'],'bytes':out.stat().st_size},ensure_ascii=False))
