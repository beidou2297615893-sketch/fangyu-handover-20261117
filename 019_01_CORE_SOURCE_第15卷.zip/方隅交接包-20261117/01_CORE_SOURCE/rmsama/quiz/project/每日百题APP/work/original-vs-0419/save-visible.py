import control as c
from pathlib import Path
import shutil,re,json
out=c.R/'visible-current';out.mkdir(exist_ok=True)
for name in ['current-final.json','current-run-events.json','current-final.png','current-progress.json']:
    shutil.copy2(c.R/name,out/name)
logs=c.adb('logcat','-d','-v','brief','TiJingRunner:I','ZhitiBank:I','ZhitiDiagnostic:I','*:S').decode(errors='replace')
(out/'current-run-log.txt').write_text(logs,encoding='utf-8')
rows=re.findall(r'no=(\d+) source=(\w+)',logs)
sources={}
for number,source in rows:sources[int(number)]=source
counts={s:list(sources.values()).count(s) for s in set(sources.values())}
(out/'sources.json').write_text(json.dumps({'questionCount':len(sources),'sources':counts},indent=2),encoding='utf-8')
print(json.dumps({'questionCount':len(sources),'sources':counts}))
events=json.loads((out/'current-run-events.json').read_text(encoding='utf-8'))
done=[r['data'] for r in events if r['evt']=='confirm']
summary=json.loads((out/'current-progress.json').read_text(encoding='utf-8'))
summary.update(allSubmittedOnce=len(done)==100 and [q['index'] for q in done]==list(range(100)) and [q['id'] for q in done]==events[0]['data']['ids'],scored=events[-1]['evt']=='result',sources=counts,manualAnswerClicks=0)
(out/'final-summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
