'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict'),{run,NAMES,FN,ENV}=require('./orchestrator.cjs');
function fixture(variant='ok'){
 const calls=[],created=[],state={marked:false,deployed:false,invoked:0};
 const existing={functionId:'old-id',name:'translation',runtime:'Nodejs20.19',modifyTime:'old-time',status:'Active'};
 const route={domain:'existing.invalid',path:'/translate',upstreamResourceName:'translation',upstreamResourceType:'function',enable:true,enableAuth:false,enablePathTransmission:true};
 const adapter={async mark(){state.marked=true;calls.push('mark');},async createFunction(){calls.push('create-only');if(variant==='function-race')throw Error('already exists');state.deployed=true;return {RequestId:'synthetic'};},async call(args){
  calls.push(args.slice(0,3).join(' '));
  if(args[0]==='fn'&&args[1]==='list')return variant==='function-conflict'?[existing,{name:FN}]:[existing,...(state.deployed?[{name:FN}]:[])];
  if(args[0]==='routes')return [state.deployed&&variant==='route-changed'?{...route,path:'/modified'}:route];
  if(args.includes('DescribeTables')){const rows=variant==='collection-conflict'?[{TableName:NAMES[0]}]:created.map(TableName=>({TableName}));return {Pager:{Total:variant==='incomplete'?100:rows.length},Tables:rows};}
  if(args.includes('CreateTable')){if(variant==='uncertain-create')throw Error('timeout');const body=JSON.parse(args[args.indexOf('--body')+1]);assert.equal(body.PermissionInfo.AclTag,'ADMINONLY');created.push(body.TableName);return {RequestId:'synthetic'};}
  if(args[0]==='permission')return {PermissionList:[{Resource:args[2].split(':')[1],Permission:variant==='bad-acl'?'READONLY':'ADMINONLY'}]};
  if(args.includes('GetFunction'))return {FunctionName:FN,Namespace:ENV,Type:'Event',Runtime:'Nodejs20.19',Handler:'index.main',Status:'Active',Role:variant==='wrong-role'?'OtherRole':'TCB_QcsRole',Environment:{Variables:[]}};
  if(args.includes('ListTriggers'))return {TotalCount:variant==='trigger'?1:0};
  if(args[0]==='fn'&&args[1]==='invoke'){state.invoked++;return {functionType:'Event',InvokeResult:0,RetMsg:JSON.stringify({initialized:true,paymentEnabled:false})};}
  throw Error('unexpected call');
 }};return {adapter,calls,created,state};
}
test('runs only named creations, validates no public trigger and IAM-invokes disabled policy twice',async()=>{
 const f=fixture(),r=await run(f.adapter);assert.deepEqual(f.created,NAMES);assert.equal(f.state.invoked,2);assert.equal(r.paymentEnabled,false);assert.equal(r.oldFunctionAndRouteMetadataUnchanged,true);
 assert.equal(f.calls.filter(x=>x==='mark').length,1);assert.ok(f.calls.indexOf('mark')<f.calls.indexOf('api tcb CreateTable'));
});
test('existing name or incomplete metadata fails before any write',async()=>{
 for(const scenario of ['function-conflict','collection-conflict','incomplete']){const f=fixture(scenario);await assert.rejects(run(f.adapter));assert.equal(f.state.marked,false);assert.equal(f.created.length,0);}
});
test('unknown creation result or wrong ACL stops with a durable marker and never deploys or invokes',async()=>{
 for(const scenario of ['uncertain-create','bad-acl']){const f=fixture(scenario);await assert.rejects(run(f.adapter));assert.equal(f.state.marked,true);assert.equal(f.state.deployed,false);assert.equal(f.state.invoked,0);}
});
test('existing route change or unexpected trigger stops before any policy write',async()=>{
 for(const scenario of ['route-changed','trigger','wrong-role']){const f=fixture(scenario);await assert.rejects(run(f.adapter));assert.equal(f.state.deployed,true);assert.equal(f.state.invoked,0);}
});
test('a function-name race causes create-only rejection and no policy invocation',async()=>{
 const f=fixture('function-race');await assert.rejects(run(f.adapter));assert.equal(f.state.marked,true);assert.equal(f.state.deployed,false);assert.equal(f.state.invoked,0);
});
