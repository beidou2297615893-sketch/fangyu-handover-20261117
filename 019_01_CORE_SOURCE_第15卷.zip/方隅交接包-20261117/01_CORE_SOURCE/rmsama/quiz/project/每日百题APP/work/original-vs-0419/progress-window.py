from pathlib import Path
import tkinter as tk
from tkinter import ttk
import json,time,sys
r=Path(__file__).resolve().parent/(sys.argv[1] if len(sys.argv)>1 else 'hidden-complete')
window=tk.Tk();window.title('知题 · 铁路截图对照测试');window.geometry('470x300');window.resizable(False,False)
window.configure(bg='#f6f2e9')
heading=tk.Label(window,text='正在验证铁路百题',font=('Microsoft YaHei UI',17,'bold'),bg='#f6f2e9',fg='#14221f');heading.pack(pady=(20,8))
numbers=tk.StringVar(value='正在读取实际进度…')
tk.Label(window,textvariable=numbers,font=('Microsoft YaHei UI',12),bg='#f6f2e9',justify='left').pack(pady=6)
bar=ttk.Progressbar(window,maximum=100,length=400);bar.pack(pady=10)
state=tk.StringVar(value='准备中')
tk.Label(window,textvariable=state,font=('Microsoft YaHei UI',10),bg='#f6f2e9',fg='#5c655f').pack()
tk.Label(window,text='关闭窗口不会中止测试。需要停止时请在聊天中告知。\n本轮只验证模拟器，手机尚未验收。',font=('Microsoft YaHei UI',9),bg='#f6f2e9',fg='#70766e').pack(pady=16)
phases={'READY':'准备下一题','CAPTURING':'截取当前题目','RECOGNIZING':'识字并核对题库','SHOWING_ANSWER':'显示答案','EXECUTING':'选择并提交','WAITING_PAGE_CHANGE':'确认提交和进入下一题','PAUSED_ERROR':'测试已暂停，正在核对原因','STOPPED':'本轮已结束'}
def update():
    try:
        p=json.loads((r/'current-progress.json').read_text(encoding='utf-8'))
        if p.get('kind') in ['batch','pages']:
            heading.configure(text='正在逐图核对铁路百题' if not p['finished'] else '逐图核对已结束')
            numbers.set(f"已检查 {p['processed']} / {p['total']} 张\n核对正确 {p['passed']} 张　未匹配 {p['unmatched']} 张\n错误答案 {p['wrong']} 张")
            if p['kind']=='pages':
                heading.configure(text='正在验证判分与换题' if not p['finished'] else '判分与换题逐图验证结束')
                numbers.set(f"已检查 {p['processed']} / {p['total']} 页\n页面识别通过 {p['passed']} 页\n未通过 {p['unmatched']} 页")
            bar['value']=100*p['processed']/p['total']
            state.set(f"这是识字查库诊断，不是自动提交成绩。耗时 {int(p['elapsedSeconds'])} 秒")
            window.after(1000,update)
            return
        n=p['confirmed'];correct=p['correct'];wrong=p['wrong'];seconds=p['elapsedSeconds']
        numbers.set(f'已提交 {n} / 100 题\n答对 {correct} 题　答错 {wrong} 题　未提交 {100-n} 题')
        bar['value']=n
        fresh=time.time()-(r/'current-progress.json').stat().st_mtime<20
        status=phases.get(p['phase'],'正在运行') if fresh or (r/'final-summary.json').exists() else '进度暂未更新，状态待核对'
        state.set(f'{status}　耗时 {int(seconds)//60} 分 {int(seconds)%60} 秒')
        if n==100 and wrong==0 and p['last']=='result':heading.configure(text='铁路百题已全部答对')
        elif p['phase']=='PAUSED_ERROR':heading.configure(text='测试暂停，尚未通过验收')
    except (OSError,ValueError,KeyError):pass
    window.after(1000,update)
update();window.mainloop()
