'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict');
const {makeMain}=require('./dailyHundredPaymentProbeV1/isolated-probe.js');
const {request,update,codeHash}=require('./update-code.cjs');
test('existing diagnostic is passed through unchanged, without opening the new DB',async()=>{
 const event={action:'diagnostic'},expected={paymentEnabled:false,database:true,alipayTls:true};let calls=0;
 const main=makeMain(async actual=>{assert.equal(actual,event);return expected;},async()=>{calls++;throw Error()});
 assert.deepEqual(await main(event),expected);assert.equal(calls,0);
 assert.deepEqual(await main({action:'diagnostic',extra:true}),{initialized:false,paymentEnabled:false});assert.equal(calls,0);
});
test('real SDK GetFunctionAddress reads CodeSha256 while never returning the signed URL',async()=>{
 const sdk=require('../payment-secret-prep/sdk-scf/node_modules/tencentcloud-sdk-nodejs-scf'),fetch=require('../payment-secret-prep/sdk-scf/node_modules/tencentcloud-sdk-nodejs-common/tencentcloud/common/http/fetch'),old=fetch.default;
 let calls=0;fetch.default=async(url,o)=>{calls++;assert.equal(url,'https://scf.tencentcloudapi.com/');assert.equal(o.headers['X-TC-Action'],'GetFunctionAddress');
  assert.deepEqual(JSON.parse(o.body),{FunctionName:'dailyHundredPaymentProbeV1',Namespace:'fh6-d5ga45c0ddae7008c',Qualifier:'$LATEST'});
  return {status:200,headers:{get:()=>null},json:async()=>({Response:{Url:'https://example.invalid/?signed-secret=synthetic',CodeSha256:'A'.repeat(64),RequestId:'fake'}})};};
 try{const client=new sdk.scf.v20180416.Client({credential:{secretId:'fake',secretKey:'fake',token:'fake'},region:'ap-shanghai'});const result=await codeHash(client);assert.equal(result,'a'.repeat(64));assert.equal(calls,1);assert.equal(result.includes('synthetic'),false);}
 finally{fetch.default=old;}
});
test('policy initializer can access only two fixed collections',async()=>{
 const data=new Map(),touched=[];const db={async runTransaction(fn){await fn({collection(name){touched.push(name);return {doc(id){assert.equal(id,'policy');return {async get(){return {data:data.has(name)?{_id:id,...data.get(name)}:null}},async set(v){data.set(name,v);return {updated:1}}}}}}});}};
 const main=makeMain(async()=>{},async()=>db);
 assert.deepEqual(await main({action:'initialize-disabled-policy'}),{initialized:true,paymentEnabled:false});
 assert.deepEqual([...new Set(touched)],['daily_hundred_payment_v1','daily_hundred_installation_v1']);
 assert.deepEqual(await main({action:'verify-disabled-policy'}),{initialized:true,paymentEnabled:false});
 assert.deepEqual(await main({action:'initialize-disabled-policy'}),{initialized:false,paymentEnabled:false});
});
test('UpdateFunctionCode request is pinned to existing probe; synthetic SDK call is once and timeout fails',async()=>{
 const zip=Buffer.from([0x50,0x4b,0x03,0x04,0]),req=request(zip);
 assert.equal(req.FunctionName,'dailyHundredPaymentProbeV1');assert.equal(req.Namespace,'fh6-d5ga45c0ddae7008c');assert.equal(req.Handler,'isolated-probe.main');assert.equal(req.Publish,'FALSE');
 const sdk=require('../payment-secret-prep/sdk-scf/node_modules/tencentcloud-sdk-nodejs-scf'),fetch=require('../payment-secret-prep/sdk-scf/node_modules/tencentcloud-sdk-nodejs-common/tencentcloud/common/http/fetch'),old=fetch.default;
 let calls=0,fail=false;fetch.default=async(url,o)=>{calls++;assert.equal(url,'https://scf.tencentcloudapi.com/');assert.equal(o.headers['X-TC-Action'],'UpdateFunctionCode');assert.deepEqual(JSON.parse(o.body),req);if(fail)throw Error('synthetic timeout');return {status:200,headers:{get:()=>null},json:async()=>({Response:{RequestId:'fake'}})};};
 try {const client=new sdk.scf.v20180416.Client({credential:{secretId:'fake',secretKey:'fake',token:'fake'},region:'ap-shanghai'});
  assert.deepEqual(await update(client,zip),{RequestId:'fake'});fail=true;await assert.rejects(update(client,zip));assert.equal(calls,2);
 }finally{fetch.default=old;}
});
