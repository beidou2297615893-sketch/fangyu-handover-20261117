'use strict';
// IAM direct invocation only; never attach an HTTP trigger or function URL.
const {createPolicyInitializer}=require('./policy-init.cjs');
exports.main=async event=>{
  if(!event||typeof event!=='object'||Array.isArray(event)||Object.keys(event).join(',')!=='action'||!['initialize-disabled-policy','verify-disabled-policy'].includes(event.action))return {initialized:false,paymentEnabled:false};
  try {const sdk=require('@cloudbase/node-sdk'),app=sdk.init({env:sdk.SYMBOL_CURRENT_ENV});return await createPolicyInitializer(app.database({throwOnCode:true,timeout:2500}))(event);}
  catch{return {initialized:false,paymentEnabled:false};}
};
