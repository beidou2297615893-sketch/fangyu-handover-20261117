'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),crypto=require('node:crypto');
const {Db}=require('../../outputs/managed-import-cloudbase/node_modules/@cloudbase/database/dist/commonjs/index.js');
const {EJSON}=require('../../outputs/managed-import-cloudbase/node_modules/bson');
const {createInternalRunCore}=require('./payment-runs');
const H=s=>crypto.createHash('sha256').update(s,'utf8').digest('hex');
const binding='a'.repeat(64),otherBinding='b'.repeat(64);
const credit=()=>({plan:'once',state:'paid',grantedAt:1,used:0,reserved:0});
function fixture(cancelLimits){
  let now=1800000000000;
  const state={docs:new Map(),txs:new Map(),version:0,n:0,unknown:false};const previous=Db.reqClass;
  Db.reqClass=class{async send(action,p={}){
    if(action==='database.startTransaction'){const transactionId='t'+(++state.n);state.txs.set(transactionId,{docs:structuredClone(state.docs),version:state.version});return {transactionId};}
    if(action==='database.abortTransaction'){state.txs.delete(p.transactionId);return {};}
    if(action==='database.commitTransaction'){const tx=state.txs.get(p.transactionId);if(tx.version!==state.version)return {code:'DATABASE_TRANSACTION_CONFLICT'};state.docs=tx.docs;state.version++;state.txs.delete(p.transactionId);if(state.unknown){state.unknown=false;throw Error('lost commit');}return {};}
    assert.equal(p.collectionName,'daily_hundred_payment_v1');const tx=state.txs.get(p.transactionId),id=JSON.parse(p.query)._id;
    if(action==='database.getDocument')return {data:{list:tx.docs.has(id)?[JSON.stringify({_id:id,...tx.docs.get(id)})]:[]}};
    if(action==='database.modifyDocument'){tx.docs.set(id,EJSON.parse(p.data));return {data:{updated:1,upsert_id:id}};}
    throw Error('unexpected call');
  }};
  const core=createInternalRunCore({db:new Db({throwOnCode:true}),clock:()=>now,cancelLimits});
  const account=owner=>state.docs.get('account-'+H(owner));
  const order=name=>'o'+H(name).slice(0,63),grant=name=>state.docs.get('grant-'+order(name));
  function setAccount(owner,fields={}){
    const {grants={},...rest}=fields,a={kind:'account',schema:2,owner,freeUsed:0,freeReserved:0,creditHead:null,creditTail:null,creditAvailable:0,creditReserved:0,memberUntil:0,memberFrozen:false,memberNeedsReview:false,memberRevision:0,reviewCount:0,revision:0,activeRuns:[],...rest};
    for(const [name,g] of Object.entries(grants)){
      const id=order(name),row={kind:'grant',orderId:id,owner,prev:null,next:null,...g};
      if(g.plan==='once'&&g.state==='paid'&&!g.used&&!g.reserved){if(a.creditTail){state.docs.get('grant-'+a.creditTail).next=id;row.prev=a.creditTail;}else a.creditHead=id;a.creditTail=id;a.creditAvailable++;}
      if(g.plan!=='once'&&g.state==='paid')a.memberUntil=Math.max(a.memberUntil,g.grantedAt)+(g.plan==='week'?7:30)*86400000;
      state.docs.set('grant-'+id,row);
    }
    state.docs.set('account-'+H(owner),a);state.version++;
  }
  const close=()=>{Db.reqClass=previous;};
  return {core,state,account,grant,setAccount,setTime:v=>{now=v;},close};
}
test('cloud admission does not create a new free allowance',async()=>{
  const f=fixture();try{
    await assert.rejects(f.core.reserve('alice','run',binding));
    assert.equal(f.account('alice'),undefined);
  }finally{f.close();}
});
test('cancel without balance writes a binding-specific tombstone that blocks late reserve',async()=>{
 const f=fixture();try{
   const expected={ownerId:'alice',runId:'late',taskBinding:binding,status:'cancelled'};
   assert.deepEqual(await f.core.cancel('alice','late',binding),expected);
   assert.deepEqual(await f.core.cancel('alice','late',binding),expected);
   await assert.rejects(f.core.cancel('alice','late',otherBinding));
   f.setAccount('alice',{grants:{order1:credit()}});
   await assert.rejects(f.core.reserve('alice','late',binding));
   assert.equal(f.grant('order1').reserved,0);assert.equal(f.account('alice').creditAvailable,1);
   await f.core.reserve('alice','other',binding);
 }finally{f.close();}
});
test('cancel releases an existing reserve exactly once and forbids confirmed cancellation',async()=>{
 const f=fixture();try{
   f.setAccount('alice',{grants:{order1:credit(),order2:credit()}});
   await f.core.reserve('alice','r',binding);
   const expected={ownerId:'alice',runId:'r',taskBinding:binding,status:'cancelled'};
   assert.deepEqual(await f.core.cancel('alice','r',binding),expected);
   assert.deepEqual(await f.core.cancel('alice','r',binding),expected);
   assert.equal(f.account('alice').creditAvailable,2);assert.equal(f.account('alice').creditReserved,0);
   await assert.rejects(f.core.reserve('alice','r',binding));
   await f.core.reserve('alice','done',binding);await f.core.confirm('alice','done',binding);
   await assert.rejects(f.core.cancel('alice','done',binding));
 }finally{f.close();}
});
test('cancel retries a lost commit and reserve races leave no active or spent credit',async()=>{
 const f=fixture();try{
   f.setAccount('alice',{grants:{order1:credit()}});
   f.state.unknown=true;await assert.rejects(f.core.cancel('alice','lost',binding));
   assert.equal((await f.core.cancel('alice','lost',binding)).status,'cancelled');
   await assert.rejects(f.core.reserve('alice','lost',binding));
   const raced=await Promise.allSettled([f.core.reserve('alice','race-cancel',binding),f.core.cancel('alice','race-cancel',binding)]);
   assert.ok(raced.some(x=>x.status==='fulfilled'));
   // A conflict or unknown commit is retried by the caller with the same binding.
   assert.equal((await f.core.cancel('alice','race-cancel',binding)).status,'cancelled');
   await assert.rejects(f.core.reserve('alice','race-cancel',binding));
   assert.equal(f.account('alice').creditAvailable,1);assert.equal(f.account('alice').creditReserved,0);assert.equal(f.grant('order1').used,0);
 }finally{f.close();}
});
test('cancel versus confirm has one terminal result and remains owner and binding isolated',async()=>{
 const f=fixture();try{
   f.setAccount('alice',{grants:{order1:credit()}});f.setAccount('bob',{});
   await f.core.reserve('alice','one',binding);
   await f.core.cancel('bob','one',otherBinding);
   await assert.rejects(f.core.cancel('alice','one',otherBinding));
   const outcomes=await Promise.allSettled([f.core.confirm('alice','one',binding),f.core.cancel('alice','one',binding)]);
   assert.equal(outcomes.filter(x=>x.status==='fulfilled').length,1);
   if(outcomes[0].status==='fulfilled'){
     assert.equal(f.grant('order1').used,1);await assert.rejects(f.core.cancel('alice','one',binding));
   }else{
     assert.equal(f.grant('order1').used,0);assert.equal(f.account('alice').creditAvailable,1);
     await assert.rejects(f.core.confirm('alice','one',binding));
   }
   assert.equal(f.account('alice').creditReserved,0);
 }finally{f.close();}
});
test('cancel never returns a frozen or refunded credit to the spendable wallet',async()=>{
 const f=fixture();try{
   f.setAccount('alice',{grants:{order1:credit()}});await f.core.reserve('alice','frozen',binding);
   f.grant('order1').state='review';f.account('alice').creditReserved--;f.account('alice').reviewCount++;f.state.version++;
   assert.equal((await f.core.cancel('alice','frozen',binding)).status,'cancelled');
   assert.equal(f.account('alice').creditAvailable,0);assert.equal(f.grant('order1').used,0);assert.equal(f.grant('order1').reserved,0);
 }finally{f.close();}
});
test('new cancellation tombstones have per-owner and global daily limits; retries never consume quota',async()=>{
 const f=fixture({ownerPerDay:2,globalPerDay:3,total:10});try{
   const expected=await f.core.cancel('alice','a',binding);
   await f.core.cancel('alice','b',binding);
   await assert.rejects(f.core.cancel('alice','c',binding));
   assert.deepEqual(await f.core.cancel('alice','a',binding),expected);
   await f.core.cancel('bob','b',binding);
   await assert.rejects(f.core.cancel('charlie','c',binding));
   assert.deepEqual(await f.core.cancel('alice','a',binding),expected);
   f.setTime(1800000000000+86400000);
   assert.equal((await f.core.cancel('alice','c',binding)).status,'cancelled');
 }finally{f.close();}
});
test('global tombstone capacity remains bounded across days while existing runs can still be released',async()=>{
 const f=fixture({ownerPerDay:2,globalPerDay:2,total:2});try{
   f.setAccount('alice',{grants:{order1:credit()}});await f.core.reserve('alice','reserved',binding);
   await f.core.cancel('alice','a',binding);await f.core.cancel('alice','b',binding);
   f.setTime(1800000000000+86400000);
   await assert.rejects(f.core.cancel('bob','c',binding));
   assert.equal((await f.core.cancel('alice','a',binding)).status,'cancelled');
   assert.equal((await f.core.cancel('alice','reserved',binding)).status,'cancelled');
   assert.equal(f.account('alice').creditAvailable,1);
 }finally{f.close();}
});
test('parallel new tombstones cannot exceed the global limit and same-id retry is stable',async()=>{
 const f=fixture({ownerPerDay:1,globalPerDay:1,total:1});try{
   const result=await Promise.allSettled([f.core.cancel('alice','a',binding),f.core.cancel('bob','b',binding)]);
   assert.equal(result.filter(x=>x.status==='fulfilled').length,1);
   const winner=result[0].status==='fulfilled'?'alice':'bob',runId=winner==='alice'?'a':'b';
   const loser=winner==='alice'?'bob':'alice';
   assert.equal((await f.core.cancel(winner,runId,binding)).status,'cancelled');
   await assert.rejects(f.core.cancel(loser,'different',binding));
   assert.equal([...f.state.docs.values()].filter(v=>v.kind==='run_cancelled').length,1);
 }finally{f.close();}
});
test('binding is immutable, cancellation does not spend, and owners are isolated',async()=>{
  const f=fixture();try{
    f.setAccount('alice',{grants:{order1:credit()}});
    await f.core.reserve('alice','run',binding);
    await assert.rejects(f.core.reserve('alice','run',otherBinding));await assert.rejects(f.core.confirm('alice','run',otherBinding));
    await assert.rejects(f.core.confirm('bob','run',binding));
    assert.equal((await f.core.release('alice','run',binding)).status,'released');
    assert.equal(f.account('alice').freeUsed,0);assert.equal(f.account('alice').freeReserved,0);
    await assert.rejects(f.core.confirm('alice','run',binding));await assert.rejects(f.core.reserve('alice','run',binding));
  }finally{f.close();}
});
test('single credit is reserved once, refund freezes it, and release cannot spend it',async()=>{
  const f=fixture();try{
    f.setAccount('alice',{freeUsed:3,grants:{order1:{plan:'once',state:'paid',grantedAt:1,used:0,reserved:0}}});
    assert.equal((await f.core.reserve('alice','credit',binding)).source,'credit');
    await assert.rejects(f.core.reserve('alice','oversell',binding));
    f.grant('order1').state='review';f.account('alice').creditReserved--;f.account('alice').reviewCount++;f.state.version++;
    await assert.rejects(f.core.confirm('alice','credit',binding));
    assert.equal((await f.core.release('alice','credit',binding)).status,'released');
    assert.equal(f.grant('order1').used,0);
  }finally{f.close();}
});
test('week and month stack, supporting refund freezes in-flight reservation',async()=>{
  const f=fixture();try{
    const start=1800000000000;
    f.setAccount('alice',{grants:{week:{plan:'week',state:'paid',grantedAt:start,used:0,reserved:0},month:{plan:'month',state:'paid',grantedAt:start+1000,used:0,reserved:0}}});
    f.setTime(start+31*86400000);
    assert.equal((await f.core.reserve('alice','member',binding)).source,'subscription');
    f.account('alice').memberFrozen=true;f.account('alice').memberRevision++;f.grant('week').state='review';f.state.version++;
    await assert.rejects(f.core.confirm('alice','member',binding));
    assert.equal((await f.core.release('alice','member',binding)).status,'released');
  }finally{f.close();}
});
test('concurrent last-credit reservation cannot exceed allowance',async()=>{
  const f=fixture();try{
    f.setAccount('alice',{grants:{order1:credit()}});
    const results=await Promise.allSettled(Array.from({length:8},(_,n)=>f.core.reserve('alice','r'+n,binding)));
    assert.equal(results.filter(x=>x.status==='fulfilled').length,1);assert.equal(f.grant('order1').reserved,1);
  }finally{f.close();}
});
test('unknown commit is not retried internally and same run can safely resume',async()=>{
  const f=fixture();try{
    f.setAccount('alice',{grants:{order1:credit()}});
    f.state.unknown=true;await assert.rejects(f.core.reserve('alice','unknown',binding));
    assert.equal((await f.core.reserve('alice','unknown',binding)).status,'reserved');
    assert.equal(f.grant('order1').reserved,1);
  }finally{f.close();}
});
test('bad account or malformed binding fails closed',async()=>{
  const f=fixture();try{
    await assert.rejects(f.core.reserve('alice','bad','not-a-digest'));
    f.setAccount('alice',{freeUsed:4});await assert.rejects(f.core.reserve('alice','bad',binding));
  }finally{f.close();}
});
test('confirmation and cancellation race has exactly one terminal state',async()=>{
  const f=fixture();try{
    f.setAccount('alice',{grants:{order1:credit()}});
    await f.core.reserve('alice','race',binding);
    const results=await Promise.allSettled([f.core.confirm('alice','race',binding),f.core.release('alice','race',binding)]);
    assert.equal(results.filter(r=>r.status==='fulfilled').length,1);
    assert.ok(f.grant('order1').used===0||f.grant('order1').used===1);
    assert.equal(f.grant('order1').reserved,0);
  }finally{f.close();}
});
test('any membership refund conservatively freezes current membership until reconciliation',async()=>{
  const f=fixture();try{
    const start=1800000000000;
    f.setAccount('alice',{grants:{old:{plan:'week',state:'paid',grantedAt:start,used:0,reserved:0},fresh:{plan:'month',state:'paid',grantedAt:start+8*86400000,used:0,reserved:0}}});
    f.setTime(start+9*86400000);await f.core.reserve('alice','separate',binding);
    f.account('alice').memberFrozen=true;f.account('alice').memberRevision++;f.grant('old').state='review';f.state.version++;
    await assert.rejects(f.core.confirm('alice','separate',binding));
  }finally{f.close();}
});
test('stored-binding confirm and release return the immutable server record',async()=>{
  const f=fixture();try{
    f.setAccount('alice',{grants:{order1:credit(),order2:credit()}});
    await f.core.reserve('alice','run',binding);
    await assert.rejects(f.core.confirmStored('bob','run'));
    assert.deepEqual(await f.core.confirmStored('alice','run'),{ownerId:'alice',runId:'run',taskBinding:binding,status:'confirmed',source:'credit'});
    await f.core.reserve('alice','cancel',otherBinding);
    assert.equal((await f.core.releaseStored('alice','cancel')).taskBinding,otherBinding);
  }finally{f.close();}
});
test('authenticated owner can recover unfinished task records without automatic expiry',async()=>{
  const f=fixture();try{
    f.setAccount('alice',{grants:{order1:credit(),order2:credit()}});
    await f.core.reserve('alice','unfinished',binding);
    await f.core.reserve('alice','finished',otherBinding);await f.core.confirm('alice','finished',otherBinding);
    f.setTime(1800000000000+365*86400000);
    const rows=await f.core.listActive('alice');
    assert.deepEqual(rows,[{ownerId:'alice',runId:'unfinished',taskBinding:binding,status:'reserved',source:'credit'}]);
    assert.deepEqual(await f.core.listActive('bob'),[]);
    await f.core.releaseStored('alice','unfinished');assert.deepEqual(await f.core.listActive('alice'),[]);
  }finally{f.close();}
});
test('expired membership cannot resume a reserved task but can finalize prior submission',async()=>{
  const f=fixture();try{
    const start=1800000000000;
    f.setAccount('alice',{grants:{week:{plan:'week',state:'paid',grantedAt:start,used:0,reserved:0}}});
    await f.core.reserve('alice','member',binding);f.setTime(start+7*86400000);
    await assert.rejects(f.core.reserve('alice','member',binding));
    assert.equal((await f.core.confirmStored('alice','member')).status,'confirmed');
    assert.equal((await f.core.reserve('alice','member',binding)).status,'confirmed');
  }finally{f.close();}
});
test('confirmed paid run reserve retry returns original receipt without spending twice',async()=>{
  const f=fixture();try{
    f.setAccount('alice',{grants:{order1:credit()}});
    await f.core.reserve('alice','run',binding);await f.core.confirm('alice','run',binding);
    assert.equal((await f.core.reserve('alice','run',binding)).status,'confirmed');
    assert.equal(f.grant('order1').used,1);await assert.rejects(f.core.reserve('alice','other',binding));
  }finally{f.close();}
});
test('confirmed receipt alone is not continued-task permission after membership expires',async()=>{
  const f=fixture();try{
    const start=1800000000000;f.setAccount('alice',{grants:{week:{plan:'week',state:'paid',grantedAt:start,used:0,reserved:0}}});
    await f.core.reserve('alice','run',binding);await f.core.confirmStored('alice','run');
    assert.equal((await f.core.authorizeContinue('alice','run',binding)).status,'authorized');
    f.setTime(start+7*86400000);
    assert.equal((await f.core.reserve('alice','run',binding)).status,'confirmed');
    await assert.rejects(f.core.authorizeContinue('alice','run',binding));
  }finally{f.close();}
});
test('single-use confirmed task continuation checks same binding and does not spend twice',async()=>{
  const f=fixture();try{
    f.setAccount('alice',{grants:{order1:credit()}});
    await f.core.reserve('alice','run',binding);await f.core.confirmStored('alice','run');
    assert.equal((await f.core.authorizeContinue('alice','run',binding)).status,'authorized');
    await assert.rejects(f.core.authorizeContinue('alice','run',otherBinding));
    assert.equal(f.grant('order1').used,1);
  }finally{f.close();}
});
