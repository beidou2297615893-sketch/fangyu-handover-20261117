from pathlib import Path
import os,subprocess,json,base64,re,time
from urllib.request import Request,urlopen
from urllib.error import HTTPError
r=Path('V:/work/original-vs-0419');out=r/'original-only-rounds';out.mkdir(exist_ok=True)
cli=Path(os.environ['APPDATA'])/'npm/node_modules/@cloudbase/cli/bin/tcb'
raw=subprocess.check_output(['node',str(cli),'fn','detail','dailyHundredImportV1Event','-e','fh6-d5ga45c0ddae7008c','--json'],stderr=subprocess.DEVNULL,timeout=40)
env=json.loads(raw[raw.index(b'{'):])['data']['Environment']['Variables']
key=next(x['Value'] for x in env if x['Key']=='DEEPSEEK_API_KEY');del raw,env
headers={'Content-Type':'application/json','Authorization':'Bearer '+key}
with urlopen(Request('https://api.deepseek.com/models',headers=headers),timeout=20) as response:models=json.load(response)
ids=[x['id'] for x in models['data']]
(out/'available-provider-models.json').write_text(json.dumps({'ids':ids,'retrievedAt':time.time()},indent=2),encoding='utf-8')
print(json.dumps({'availableModels':ids}),flush=True)
settings=Path('V:/work/tijing-upstream/src/lib/settings.js').read_text(encoding='utf-8')
prompt=re.search(r'export const DEFAULT_PROMPT = `(.+?)`;',settings).group(1).replace('\\n','\n')
image='data:image/png;base64,'+base64.b64encode((r/'railway-corpus/000.png').read_bytes()).decode()
reports=[]
for model in ['deepseek-chat','deepseek-flash']:
    body={'model':model,'messages':[{'role':'system','content':prompt.replace('{QUESTION_NO}','1').replace('{QUESTION_IMAGE}','题目截图已作为 image_url 附件提供')},
        {'role':'user','content':[{'type':'text','text':'这是第 1 题，请按系统提示词返回 JSON。'}, {'type':'image_url','image_url':{'url':image}}]}],
        'temperature':0,'max_tokens':1200,'response_format':{'type':'json_object'}}
    started=time.monotonic()
    try:
        with urlopen(Request('https://api.deepseek.com/chat/completions',data=json.dumps(body,ensure_ascii=False).encode(),headers=headers),timeout=35) as response:data=json.load(response)
        message=data['choices'][0]['message'];content=message.get('content') or ''
        parsed=json.loads(content) if content else None
        (out/(model+'-unchanged-request-result.json')).write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
        summary={'model':model,'status':200,'seconds':round(time.monotonic()-started,2),'finishReason':data['choices'][0]['finish_reason'],
            'contentLength':len(content),'reasoningLength':len(message.get('reasoning_content') or ''),'jsonValid':parsed is not None,
            'answerIndices':parsed.get('answer_indices') if parsed else None,'bodyThinkingParameterAdded':False,'bankInjected':False}
    except HTTPError as error:summary={'model':model,'status':error.code,'seconds':round(time.monotonic()-started,2),'bodyThinkingParameterAdded':False}
    except Exception as error:summary={'model':model,'errorType':type(error).__name__,'seconds':round(time.monotonic()-started,2),'bodyThinkingParameterAdded':False}
    reports.append(summary);print(json.dumps(summary),flush=True)
(out/'provider-config-check.json').write_text(json.dumps(reports,indent=2),encoding='utf-8')
del key,headers
