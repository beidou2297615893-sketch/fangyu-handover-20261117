package com.futureyyy.tijing.payment

import android.content.Context
import android.os.Handler
import android.os.Looper
import java.util.UUID

/** Isolated debug fixture only. No production account, token, ledger or HTTP session. */
class GatewaySession internal constructor(val runId:String,val endpoint:String,val model:String,val apiKey:String,val expiresAt:Long) {
    override fun toString()="GatewaySession(isolated-debug-fixture)"
}
object GatewaySessionEntry {
    private val main=Handler(Looper.getMainLooper())
    private fun isolated(context:Context) {
        check(com.futureyyy.tijing.BuildConfig.DEBUG && context.packageName == "com.jimusoft.dailyhundredapp.audit419.dev")
    }
    private fun prefs(context:Context)=context.getSharedPreferences("isolated-diagnostic-only",Context.MODE_PRIVATE)
    fun getOrCreateRunId(context:Context,targetPackage:String):String {
        isolated(context)
        require(targetPackage in setOf("com.jimusoft.railwaymp.canvas419","com.jimusoft.railwaymp")) { "隔离验收只允许专用铁路宿主。" }
        val p=prefs(context)
        return p.getString("runId",null) ?: ("diag-"+UUID.randomUUID()).also { check(p.edit().putString("runId",it).commit()) }
    }
    fun begin(context:Context,runId:String,targetPackage:String,done:(Result<GatewaySession>)->Unit) {
        val result=runCatching {
            isolated(context)
            require(targetPackage in setOf("com.jimusoft.railwaymp.canvas419","com.jimusoft.railwaymp") && prefs(context).getString("runId",null)==runId)
            android.util.Log.i("ZhitiDiagnostic","LOCAL_FIXTURE_ADMISSION no production ledger; visual endpoint is loopback only")
            GatewaySession(runId,"http://127.0.0.1:18765/v1/chat/completions","deepseek-flash","isolated-diagnostic-no-authority",System.currentTimeMillis()+12*60*60*1000)
        }
        main.post { done(result) }
    }
    internal fun hasPendingEnd(context:Context):Boolean { isolated(context);return false }
    internal fun retryPendingEndOnWorker(context:Context) { isolated(context) }
    fun close(context:Context,session:GatewaySession,done:(Result<Unit>)->Unit) = closePending(context,done)
    fun closePending(context:Context,done:(Result<Unit>)->Unit) {
        val result=runCatching { isolated(context); check(prefs(context).edit().remove("runId").commit()); Unit }
        main.post { done(result) }
    }
}
