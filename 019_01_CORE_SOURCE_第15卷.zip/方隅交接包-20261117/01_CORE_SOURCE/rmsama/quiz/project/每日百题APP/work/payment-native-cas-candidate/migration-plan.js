'use strict';
// Pure, offline migration proposal. Does not open, create, alter or decrypt files.
// Production must quiesce all legacy writers before reading any real records.
function planMigration(raw){
 if(!raw||Object.keys(raw).sort().join(',')!=='identity,pending,registration')throw Error('invalid legacy snapshot');
 for(const key of ['identity','pending','registration'])if(raw[key]!==null&&typeof raw[key]!=='string')throw Error('invalid legacy snapshot');
 function parse(text){if(text===null)return null;try{return JSON.parse(text)}catch{throw Error('invalid legacy record');}}
 const identity=parse(raw.identity),pending=parse(raw.pending),registration=parse(raw.registration);
 if(identity!==null&&(!identity||typeof identity!=='object'||Array.isArray(identity)||typeof identity.installationId!=='string'||!identity.installationId||typeof identity.accessToken!=='string'||identity.accessToken.length<32))throw Error('invalid legacy identity');
 if(pending!==null&&(!Array.isArray(pending)||pending.some(v=>!v||typeof v!=='object'||Array.isArray(v)||typeof v.id!=='string'||typeof v.planId!=='string'||!Number.isSafeInteger(v.amountFen)||v.amountFen<0||typeof v.clientRequestId!=='string')))throw Error('invalid legacy pending');
 if(!identity&&pending&&pending.length)throw Error('pending orders without identity');
 if(registration!==null&&(!registration||typeof registration!=='object'||Array.isArray(registration)||Object.keys(registration).sort().join(',')!=='requestId,verifier'||!['requestId','verifier'].every(k=>typeof registration[k]==='string'&&/^[A-Za-z0-9_-]{43}$/.test(registration[k]))))throw Error('invalid legacy registration');
 return {legacyRaw:{...raw},next:{identity,pending:pending===null?[]:pending,registration}};
}
module.exports={planMigration};
