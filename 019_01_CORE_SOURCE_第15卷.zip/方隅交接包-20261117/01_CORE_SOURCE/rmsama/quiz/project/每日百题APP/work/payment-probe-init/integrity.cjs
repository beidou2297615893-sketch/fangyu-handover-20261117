'use strict';
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const EXPECTED=Object.freeze({
 'isolated-probe.js':'44e1eb106c44acdebcdad42886cd5d1ffb8906cc8e0522384fa0e6d87330e82a',
 'package.json':'c65a8e0dccb2205b707ab6c38387c63f6ed242e7fe84aacafc29b48f26acca44',
 'diagnostic-original.js':'b3880d1779a01a13cbe1e4adefe79bd04e79942eea3948ec2d896efdab4b9895',
 'policy-init.cjs':'c60a74262794ab8910ba344d1a1fa29e99e2146c02e54cace1b51c493cff1128'
});
function hash(file){return crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex')}
function files(dir){const out=[];function walk(folder,base){for(const e of fs.readdirSync(folder,{withFileTypes:true})){
 const f=path.join(folder,e.name),rel=path.join(base,e.name);if(e.isSymbolicLink())throw Error('unavailable');if(e.isDirectory())walk(f,rel);else if(e.isFile())out.push(rel);else throw Error('unavailable');
}}walk(dir,'');return out.sort();}
function auditPackage(source,baselineDiagnostic,baselinePolicy,baselineDeps,expected=EXPECTED){
 const root=fs.readdirSync(source,{withFileTypes:true});
 if(root.some(e=>e.isSymbolicLink()||!(e.isDirectory()&&e.name==='node_modules'||e.isFile()&&Object.hasOwn(expected,e.name)))||root.length!==Object.keys(expected).length+1)throw Error('unavailable');
 for(const [name,digest] of Object.entries(expected))if(hash(path.join(source,name))!==digest)throw Error('unavailable');
 if(hash(path.join(source,'diagnostic-original.js'))!==hash(baselineDiagnostic)||hash(path.join(source,'policy-init.cjs'))!==hash(baselinePolicy))throw Error('unavailable');
 const staged=path.join(source,'node_modules'),a=files(baselineDeps),b=files(staged);if(JSON.stringify(a)!==JSON.stringify(b))throw Error('unavailable');
 for(const f of a)if(hash(path.join(baselineDeps,f))!==hash(path.join(staged,f)))throw Error('unavailable');
 for(const f of files(source))if(/(?:^|[\\/])(?:\.env(?:\..*)?|credentials?\.json|[^\\/]*private[^\\/]*\.(?:pem|key))$/i.test(f))throw Error('unavailable');
}
module.exports={EXPECTED,hash,files,auditPackage};
