'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict'),path=require('node:path'),{spawnSync}=require('node:child_process');
test('real policy entry remains hard-disabled before any cloud access',()=>{
 const x=spawnSync(process.execPath,[path.join(__dirname,'policy-live-candidate.cjs'),'--apply'],{encoding:'utf8'});assert.equal(x.status,2);const result=JSON.parse(x.stdout);assert.equal(result.updated,false);assert.equal(result.paymentEnabled,false);
});
test('official TCB SDK sends only fixed ACL requests through the guarded endpoint',async()=>{
 const sdkRoot=path.resolve(__dirname,'../payment-database-init/sdk-tcb/node_modules'),http=require(path.join(sdkRoot,'tencentcloud-sdk-nodejs-common/tencentcloud/common/http/fetch')),old=http.default;let calls=0;
 http.default=async(url,opts)=>{assert.equal(url,'https://tcb.tencentcloudapi.com/');assert.equal(opts.headers['X-TC-Action'],'DescribeDatabaseACL');const b=JSON.parse(opts.body);assert.equal(b.EnvId,'fh6-d5ga45c0ddae7008c');assert.ok(['daily_hundred_installation_v1','daily_hundred_payment_v1'].includes(b.CollectionName));calls++;return {status:200,headers:{get:()=>null},json:async()=>({Response:{AclTag:'ADMINONLY',RequestId:'fixture'}})};};
 try{http.default=require('../payment-secret-prep/redirect-guard.cjs').makeGuardedFetch(http.default,'https://tcb.tencentcloudapi.com/');const C=require(path.join(sdkRoot,'tencentcloud-sdk-nodejs-tcb')).tcb.v20180608.Client,client=new C({credential:{secretId:'fixture',secretKey:'fixture',token:'fixture'},region:'ap-shanghai',profile:{httpProfile:{endpoint:'tcb.tencentcloudapi.com',protocol:'https://'}}});for(const CollectionName of ['daily_hundred_installation_v1','daily_hundred_payment_v1'])assert.equal((await client.DescribeDatabaseACL({EnvId:'fh6-d5ga45c0ddae7008c',CollectionName})).AclTag,'ADMINONLY');assert.equal(calls,2)}finally{http.default=old}
});
