# 0.3.40 viewport scroll reobservation

Source frozen after host validation. Four files listed in source-manifest.json; reobservation.patch is against the pre-change backup in before/ (new helper from /dev/null).

Only the exact singleton VISUAL_HASH_CHANGED rejection from the viewport executor, before dispatchGate or perform, receives a typed outcome. All pixel equality, target, age, geometry, foreground and active-run guards remain unchanged. Other failures and select/submit/native-scroll actions retain the existing pause behavior.

The driver discards the old intent and OCR cache and waits for the existing engine tick to read the tree, capture/recognize fresh pixels and call the coordinator again. It never replays an intent, substitutes its hash, rolls facts back or directly dispatches a retry. Same generation/run/target/window/root/dimensions and full search/facts identity are checked. Search frame/hash/attempt/still fields alone are normalized for identity, so new hashes or intent IDs cannot renew the refresh budget. Maximum two reobservations per continuous logical search, six-second deadline, minimum 350 ms delay. A successful action or distinct search ends the chain.

No-dispatch scrolls STILL consume the coordinator-reserved attempt. Original four attempts / thirty seconds remain. No CAS refund is needed or implemented. This can conservatively pause earlier when a search was already near its limit.

The new helper does not write RunFacts. The fresh coordinator plan still checks settlement and pending-submit/receipt-only rules. Stop/pause/system-UI cancellation invalidates the generation and clears pending reobservation. Fresh receipt can count once; reobservation cannot create or replace a submission identity.

## Validation

- red.log: stubbed no-recovery helper produced 5 pass / 9 fail, then actual helper restored and implemented.
- green-final.log: 16 pass / 0 fail (typed singleton; A-B-B new intent; count/identity; budget/deadline; generation/target/window/root; stop/readonly; stale facts; settlement withdrawal; receipt once; sensitive page; original limits; actual backward bottom search; native-only fresh read rejected).
- generic-regression.log: 106 behavior checks passed.
- ../reobservation-existing.log: 23 offscreen cases passed.
- ../paid-review/result.log: 5 scoped paid identity/receipt checks passed.

Pure host tests compile the actual helper/coordinator/models, not Android driver/executor classes. Parent owns the Android compile and device BOTH100 revalidation. No fixture, emulator, server, payment flow or AI integration changed here.

## Thread and callback limits

No new worker, timer, sleep or recursive action callback was introduced. Deferral clears reading state and relies on the existing tick. Driver callback mutations remain inside the existing synchronized(lock); tick is invoked under NativeTaskEngine synchronization. Existing callbackForeground/current generation and authorization guards run before consuming outcomes; cancelPending clears the helper and invalidates reader callbacks. Existing delayed OCR reads / scroll-settle callbacks still use their original generation checks. A full platform callback/interleaving proof is outside pure-host coverage; Android compile and device replay are required before release. Native tree recognition without a fresh visual frame while reobservation is pending fails closed, rather than allowing a prior screenshot to authorize action.
