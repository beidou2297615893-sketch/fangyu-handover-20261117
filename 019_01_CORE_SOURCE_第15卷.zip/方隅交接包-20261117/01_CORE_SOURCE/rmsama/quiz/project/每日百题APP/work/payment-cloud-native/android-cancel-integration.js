'use strict';
// Loopback only. No cloud, merchant keys, real customer identities or payments.
const http=require('node:http'),crypto=require('node:crypto'),assert=require('node:assert/strict'),{spawn}=require('node:child_process');
const {createInternalRouter}=require('./billing-event'),{createInternalRunCore}=require('./payment-runs');
const owner='i'+'a'.repeat(32),binding='a'.repeat(64),bytes=crypto.randomBytes(32);bytes[0]=0x49;
const token=bytes.toString('base64url'),docs=new Map();let seen=0;
const db={async runTransaction(fn){return fn({collection(){return {doc(id){return {
  async get(){return {data:docs.has(id)?{_id:id,...docs.get(id)}:null};},
  async set(value){docs.set(id,structuredClone(value));return {updated:1};}
};}};}});}};
const core=createInternalRunCore({db});
const router=createInternalRouter({installation:{authenticate:async actual=>{assert.equal(actual,token);return owner;}},
 billing:{admissionPolicy:'paid-only',cancelRun:core.cancel,reserveRun:core.reserve},
 verifyTaskBinding:async(actual,id,b)=>actual===owner&&id==='integration-run'&&/^[a-f0-9]{64}$/.test(b)});
const server=http.createServer(async(req,res)=>{
 let body='';for await(const chunk of req)body+=chunk;
 if(req.url.endsWith('/cancel')){
   assert.equal(req.method,'POST');assert.equal(req.headers.authorization,'Bearer '+token);
   assert.equal(req.headers['content-type'],'application/json');
   assert.deepEqual(Object.keys(JSON.parse(body)),['taskBinding']);seen++;
 }
 const reply=await router({path:req.url,httpMethod:req.method,headers:req.headers,body});
 res.writeHead(reply.statusCode,reply.headers);res.end(reply.body);
});
server.listen(0,'127.0.0.1',()=>{
 const child=spawn(process.env.TEST_JAVA,['-cp',process.env.TEST_CLASSPATH,'expo.modules.automationbridge.billing.AndroidCancelIntegrationTest'],{
   env:{...process.env,TEST_CANCEL_ORIGIN:`http://127.0.0.1:${server.address().port}`,TEST_CANCEL_OWNER:owner,TEST_CANCEL_TOKEN:token},stdio:'inherit'});
 child.on('error',()=>{server.close();process.exitCode=1;});
 child.on('exit',code=>{try{assert.equal(code,0);assert.equal(seen,3);assert.equal(docs.size,3);assert.equal([...docs.values()].filter(x=>x.kind==='run_cancelled').length,1);}
 catch(e){console.error(e.message);process.exitCode=1;}finally{server.close();}});
});
