'use strict';
const fs = require('node:fs'), path = require('node:path'), crypto = require('node:crypto'), cp = require('node:child_process');
const project = path.resolve(__dirname, '../..'), source = path.join(project, 'outputs/daily-hundred-app');
const stage = 'C:/Users/rmsama/DailyHundredNativeBuild/work/app';
const { unzipSync } = require(path.join(source, 'node_modules/fflate'));
const hash = bytes => crypto.createHash('sha256').update(bytes).digest('hex');
const apk = path.join(stage, 'android/app/build/outputs/apk/release/app-release.apk');
const metadata = JSON.parse(fs.readFileSync(path.join(path.dirname(apk), 'output-metadata.json')));
if (metadata.applicationId !== 'com.jimusoft.dailyhundredapp' || metadata.elements.length !== 1
  || metadata.elements[0].versionCode !== 35 || metadata.elements[0].versionName !== '0.3.30') throw Error('Release version mismatch');
const bundle = fs.readFileSync(path.join(stage, 'android/app/build/generated/assets/react/release/index.android.bundle'));
const bytes = fs.readFileSync(apk), entries = unzipSync(bytes, { filter: entry => entry.name === 'assets/index.android.bundle' });
if (!entries['assets/index.android.bundle'] || hash(entries['assets/index.android.bundle']) !== hash(bundle)) throw Error('APK bundle mismatch');
const map = JSON.parse(fs.readFileSync(path.join(stage, 'android/app/build/intermediates/sourcemaps/react/release/index.android.bundle.packager.map')));
const sources = [];
for (let index = 0; index < map.sources.length; index++) {
  const name = map.sources[index].replaceAll('\\', '/');
  const relative = name.startsWith('/src/') ? name.slice(1) : name.includes('/modules/automation-bridge/') ? name.slice(name.indexOf('/modules/automation-bridge/') + 1) : null;
  if (!relative || !fs.existsSync(path.join(source, relative))) continue;
  const actual = fs.readFileSync(path.join(source, relative), 'utf8');
  if (map.sourcesContent[index] !== actual || fs.readFileSync(path.join(stage, relative), 'utf8') !== actual) throw Error('Bundled source differs: ' + relative);
  sources.push(relative);
}
for (const required of ['src/billing/client.ts', 'src/billing/session.ts', 'src/screens/assistant-home.tsx', 'src/screens/assistant-run.tsx', 'src/screens/assistant-import.tsx', 'src/screens/assistant-plans.tsx']) {
  if (!sources.includes(required)) throw Error('Source map missing changed module: ' + required);
}
const nativeSources = [];
function walk(directory, relative = '') {
  for (const entry of fs.readdirSync(directory, { withFileTypes: true })) {
    const name = relative ? relative + '/' + entry.name : entry.name;
    if (entry.isDirectory()) walk(path.join(directory, entry.name), name);
    else {
      const file = 'modules/automation-bridge/android/src/' + name;
      if (hash(fs.readFileSync(path.join(source, file))) !== hash(fs.readFileSync(path.join(stage, file)))) throw Error('Native staged source differs: ' + file);
      nativeSources.push(file);
    }
  }
}
walk(path.join(source, 'modules/automation-bridge/android/src'));
const env = { ...process.env, JAVA_HOME: path.join(project, 'work/tools/jdk/jdk-17.0.20.1+1') };
const signer = cp.spawnSync(path.join(env.JAVA_HOME, 'bin/java.exe'), ['-jar', path.join(project, 'work/tools/android-sdk/build-tools/36.0.0/lib/apksigner.jar'), 'verify', '--print-certs', apk], { env, encoding: 'utf8', windowsHide: true });
const expectedCertificate = '6dd2aaff7a40b840d5efdafcf8e15d608aab2fb9c649845cbe7b7e8a9bddb8a7';
if (signer.status !== 0 || !signer.stdout.toLowerCase().includes('signer #1 certificate sha-256 digest: ' + expectedCertificate)) throw Error('Release signature mismatch');
const gate = JSON.parse(fs.readFileSync(path.join(project, 'work/android-build-logs/payment-release-verification.json')));
if (gate.apkSha256 !== hash(bytes) || gate.compiledApkVerified !== true || gate.paymentAdmissionEnabled !== true) throw Error('APK payment verification not bound to this artifact');
const report = { versionName: '0.3.30', versionCode: 35, apk, bytes: bytes.length, sha256: hash(bytes), bundleSha256: hash(bundle), sameSignature: true,
  sourcemapSourceFilesMatched: sources.length, sources, nativeStagedSourceFilesMatched: nativeSources.length, payment: gate, realOrderCreated: false, realPaymentPerformed: false };
fs.writeFileSync(path.join(__dirname, 'final-build-verification.json'), JSON.stringify(report, null, 2) + '\n');
console.log(JSON.stringify({ versionName: report.versionName, versionCode: report.versionCode, sha256: report.sha256, sameSignature: true, sourcemapSourceFilesMatched: sources.length, nativeStagedSourceFilesMatched: nativeSources.length }));
