$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path -Parent (Split-Path -Parent $PSScriptRoot)
$jdk = (Get-ChildItem (Join-Path $projectRoot 'work/tools/jdk') -Directory | Select-Object -First 1).FullName
$lib = (Get-ChildItem (Join-Path $projectRoot 'work/gradle-home/wrapper/dists/gradle-9.3.1-bin') -Directory -Recurse -Filter lib | Select-Object -First 1).FullName
$src = Join-Path $projectRoot 'outputs/daily-hundred-app/modules/automation-bridge/android/src/main/java/expo/modules/automationbridge'
$classes = Join-Path $PSScriptRoot 'dispatch-classes'; New-Item -ItemType Directory -Force $classes | Out-Null
$java = Join-Path $jdk 'bin/java.exe'; $stdlib = Join-Path $lib 'kotlin-stdlib-2.2.21.jar'
$files = @((Join-Path $src 'runtime/RunModels.kt'), (Join-Path $PSScriptRoot 'GenericPersistDispatchTest.kt'))
if (Test-Path (Join-Path $src 'generic/GenericPersistDispatch.kt')) { $files += (Join-Path $src 'generic/GenericPersistDispatch.kt') }
& $java '-Dfile.encoding=UTF-8' -cp "$lib/*" org.jetbrains.kotlin.cli.jvm.K2JVMCompiler -no-stdlib -no-reflect -classpath $stdlib -d $classes $files
if ($LASTEXITCODE -ne 0) { throw 'Generic dispatch test failed to compile' }
& $java -cp "$classes;$stdlib" expo.modules.automationbridge.generic.GenericPersistDispatchTest
if ($LASTEXITCODE -ne 0) { throw 'Generic dispatch test failed' }
