package com.futureyyy.tijing
import java.io.File
import javax.imageio.ImageIO
import com.google.gson.JsonParser
fun main(){
 val d=File("V:/work/ocr0419-evidence/hd100")
 val source=JsonParser.parseString(File(d,"replay-manifest.json").readText()).asJsonObject.getAsJsonArray("rows").associate{e->val r=e.asJsonObject;r["file"].asString to r["sourcePath"].asString}
 val raw=File("V:/work/ocr0419-evidence/hd100/replay-paddle.json")
 val list=JsonParser.parseString(raw.readText()).asJsonArray.single{it.asJsonObject["file"].asString.contains("-q20-")}.asJsonObject.getAsJsonArray("lines").toList().takeLast(4)
 val nodes=list.map{v->val n=v.asJsonObject;val b=n["box"].asJsonArray;VisibleQuestionReader.Node(n["text"].asString, NormalizedBox(b[0].asFloat,b[1].asFloat,b[2].asFloat,b[3].asFloat))}
 for(f in listOf("V:/work/verify-0419-device/upstream-input-1794579648623975200.png","V:/work/verify-0419-device/upstream-input-1794578798968197800.png",source.getValue("replay-q20-real-01610.png"))){
  val im=ImageIO.read(File(f));val pix=im.getRGB(0,0,im.width,im.height,null,0,im.width)
  println(f+" cardRects="+ShortChoiceCards.locate(im.width,im.height,pix).map{it.text}+" levels="+RomanChoiceEvidence.read(im.width,im.height,pix,nodes)?.map{it.text})
 }
}
