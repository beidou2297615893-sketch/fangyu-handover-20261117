const test=require('node:test'),assert=require('node:assert/strict');
const {run,identity}=require('./core.cjs');
function setup() {
 let user=null, events=[], marker=null;
 const api={find:async id=>{events.push(['find',id]);return user?[user]:[]},create:async x=>{events.push(['create']);user={Uid:x.Uid,Name:x.Name,Description:x.Description,Type:x.Type};return {Uid:x.Uid}},delete:async ids=>{events.push(['delete',ids]);user=null;return {SuccessCount:1,FailedCount:0}}};
 const browser={verify:async()=>({verified:true,uidVerified:true,registered:true})};
 const record=async x=>{events.push(['marker']);marker=x};
 return {api,browser,record,events,get marker(){return marker},setUser(v){user=v}};
}
test('identity is unique, valid and password not in output marker',async()=>{let s=setup(),r=await run(s);assert.deepEqual(r,{verified:true,cleanup:'verified'});assert.equal(Object.keys(s.marker).sort().join(','),'description,name,uid');assert.deepEqual(s.events.map(e=>e[0]),['find','marker','create','find','find','delete','find']);assert.deepEqual(s.events.find(e=>e[0]==='delete')[1],[s.marker.uid]);assert.notEqual(identity().uid,identity().uid)});
test('unavailable browser blocks creation',async()=>{let s=setup();delete s.browser;assert.equal((await run(s)).reason,'adapters-unavailable');assert.equal(s.events.length,0)});
test('collision and preflight error block creation',async()=>{for(const fail of [false,true]){let s=setup();s.api.find=async()=>{if(fail)throw Error('sensitive');return [{}]};const r=await run(s);assert.equal(r.cleanup,'not-attempted');assert.equal(s.events.length,0)}});
test('marker failure prevents create',async()=>{let s=setup();s.record=async()=>{throw Error()};assert.equal((await run(s)).reason,'marker-failed');assert.equal(s.events.some(e=>e[0]==='create'),false)});
test('uncertain or mismatched creation is never deleted',async()=>{for(const fail of [false,true]){let s=setup();s.api.create=async()=>{if(fail)throw Error('secret');return {Uid:'unexpected'}};let r=await run(s);assert.equal(r.cleanup,'not-attempted');assert.equal(s.events.some(e=>e[0]==='delete'),false)}});
test('identity mismatch at cleanup never deletes',async()=>{let s=setup();s.browser.verify=async()=>{s.setUser({Uid:s.marker.uid,Name:'another',Description:s.marker.description,Type:'internalUser'});return {verified:true,uidVerified:true,registered:true}};let r=await run(s);assert.equal(r.cleanup,'identity-mismatch');assert.equal(s.events.some(e=>e[0]==='delete'),false)});
test('unexpected access remains failure with test id, cleanup is exact',async()=>{let s=setup();s.browser.verify=async()=>({reason:'unexpected-access',testId:'acl-test-'+ 'b'.repeat(32)});let r=await run(s);assert.equal(r.reason,'unexpected-access');assert.equal(r.cleanup,'verified');assert.equal(r.verified,false)});
test('login failure is not a permission denial',async()=>{let s=setup();s.browser.verify=async()=>{throw Error('secret')};let r=await run(s);assert.equal(r.verified,false);assert.equal(r.cleanup,'verified');assert.equal(JSON.stringify(r).includes('secret'),false)});
test('delete ambiguity is not retried',async()=>{let s=setup(),n=0;s.api.delete=async()=>{n++;throw Error('sensitive')};let r=await run(s);assert.equal(r.cleanup,'unknown');assert.equal(r.verified,false);assert.equal(n,1)});
test('must independently confirm identity and all denials',async()=>{for(const v of [{verified:true,registered:true},{verified:true,uidVerified:true},{verified:false,uidVerified:true,registered:true}]){let s=setup();s.browser.verify=async()=>v;let r=await run(s);assert.equal(r.verified,false)}});
