'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const {createOfflineSettlement,createProductionSettlement}=require('./settlement-offline');
test('production factory remains closed',()=>{assert.throws(()=>createProductionSettlement({enabled:true}));});
test('signed matched notification and query atomically bind order, trade and one grant',async()=>{
  const h=createOfflineSettlement();try{
    const notice=h.makeNotice();h.prepareQuery(h.makeQuery());
    assert.equal((await h.settle(notice)).status,'paid');
    assert.equal((await h.settle(notice)).status,'paid');
    const docs=h.snapshot();assert.equal(docs.orders[0].owner,'owner-A');assert.equal(docs.trades.length,1);assert.equal(docs.grants.length,1);
  }finally{h.close();}
});
test('client verified boolean, forged signature, mismatched merchant, amount, trade, order or status never grants',async()=>{
  const h=createOfflineSettlement();try{
    const n=h.makeNotice(),q=h.makeQuery();
    for(const [notice,query] of [
      [{verified:true},q], [n.replace('1.00','9.00'),q], [h.makeNotice({seller_id:'other'}),q],
      [h.makeNotice({app_id:'other'}),q], [h.makeNotice({total_amount:'2.00'}),q],
      [n,h.makeQuery({trade_no:'other'})], [n,h.makeQuery({out_trade_no:'other'})], [n,h.makeQuery({total_amount:'2.00'})],
      [n,h.makeQuery({trade_status:'WAIT_BUYER_PAY'})], [n,q.replace('1.00','9.00')]
    ]){h.prepareQuery(query);await assert.rejects(h.settle(notice));}
    assert.equal(h.snapshot().grants.length,0);
  }finally{h.close();}
});
test('duplicate trade across orders is refused without changing the second order',async()=>{
  const h=createOfflineSettlement();try{
    h.prepareQuery(h.makeQuery());await h.settle(h.makeNotice());
    h.addOrder('order-B','owner-B');
    h.prepareQuery(h.makeQuery({out_trade_no:'order-B'}));await assert.rejects(h.settle(h.makeNotice({out_trade_no:'order-B'})));
    const result=h.snapshot();assert.equal(result.grants.length,1);assert.equal(result.orders.find(x=>x.orderId==='order-B').status,'pending');
  }finally{h.close();}
});
test('conflict retry redoes transaction only, and unknown commit remains safely replayable',async()=>{
  const h=createOfflineSettlement();try{
    h.conflicts(2);h.prepareQuery(h.makeQuery());await h.settle(h.makeNotice());
    assert.equal(h.queryCount(),1);assert.equal(h.snapshot().grants.length,1);
  }finally{h.close();}
  const second=createOfflineSettlement();try{
    second.prepareQuery(second.makeQuery());second.unknownCommit();await assert.rejects(second.settle(second.makeNotice()));
    assert.equal(second.snapshot().grants.length,1);
    await second.settle(second.makeNotice());
    assert.equal(second.snapshot().grants.length,1);
  }finally{second.close();}
});
test('concurrent identical notifications produce one order binding and grant',async()=>{
  const h=createOfflineSettlement();try{
    h.prepareQuery(h.makeQuery());const notice=h.makeNotice();
    const results=await Promise.all([h.settle(notice),h.settle(notice)]);
    assert.equal(results.length,2);assert.equal(h.snapshot().trades.length,1);assert.equal(h.snapshot().grants.length,1);
  }finally{h.close();}
});
