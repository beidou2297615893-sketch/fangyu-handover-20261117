'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict'),{createPolicyInitializer}=require('./policy-init.cjs');
function fixture(initial=[],failWrite=false){
 const docs=new Map(initial),calls=[];
 const db={async runTransaction(fn){const copy=new Map(docs);await fn({collection(name){calls.push(name);return {doc(id){assert.equal(id,'policy');return {
   async get(){return {data:copy.has(name)?{_id:'policy',...copy.get(name)}:null};},
   async set(row){if(failWrite&&name==='daily_hundred_installation_v1')throw Error();copy.set(name,row);return {updated:1};}
 };}};}});docs.clear();for(const [k,v] of copy)docs.set(k,v);}};
 return {docs,calls,run:createPolicyInitializer(db)};
}
test('writes exactly two disabled policies atomically',async()=>{
 const f=fixture(),r=await f.run({action:'initialize-disabled-policy'});assert.deepEqual(r,{initialized:true,paymentEnabled:false});
 assert.equal(f.docs.size,2);for(const value of f.docs.values())assert.deepEqual(value,{kind:'policy',schema:1,enabled:false});
 assert.deepEqual([...new Set(f.calls)],['daily_hundred_payment_v1','daily_hundred_installation_v1']);
});
test('an existing policy stops without overwriting either collection',async()=>{
 const f=fixture([['daily_hundred_installation_v1',{kind:'policy',schema:1,enabled:true}]]);
 assert.equal((await f.run({action:'initialize-disabled-policy'})).initialized,false);assert.equal(f.docs.size,1);assert.equal(f.docs.get('daily_hundred_installation_v1').enabled,true);
});
test('bad event and failed second write cannot create a partial policy',async()=>{
 const f=fixture([],true);assert.equal((await f.run({action:'other'})).initialized,false);assert.equal(f.calls.length,0);
 assert.equal((await f.run({action:'initialize-disabled-policy',extra:true})).initialized,false);
 assert.equal((await f.run({action:'initialize-disabled-policy'})).initialized,false);assert.equal(f.docs.size,0);
});
test('repeat initialization is rejected, not overwritten',async()=>{
 const f=fixture();assert.equal((await f.run({action:'initialize-disabled-policy'})).initialized,true);
 assert.equal((await f.run({action:'verify-disabled-policy'})).initialized,true);
 f.docs.get('daily_hundred_payment_v1').enabled=true;
 assert.equal((await f.run({action:'verify-disabled-policy'})).initialized,false);
 assert.equal((await f.run({action:'initialize-disabled-policy'})).initialized,false);assert.equal(f.docs.size,2);
});
