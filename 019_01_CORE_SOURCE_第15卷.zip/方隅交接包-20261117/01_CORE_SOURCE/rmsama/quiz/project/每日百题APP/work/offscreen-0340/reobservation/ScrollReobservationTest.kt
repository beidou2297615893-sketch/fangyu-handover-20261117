package expo.modules.automationbridge
import expo.modules.automationbridge.bank.*
import expo.modules.automationbridge.generic.*
import expo.modules.automationbridge.runtime.*
import expo.modules.automationbridge.screen.*
private val q=CanonicalQuestion("one","single","哪个数不等于零？",listOf(QuestionOption("a","0"),QuestionOption("b","1")),listOf("b"))
private val recognizer=GenericRecognizer(listOf(q))
private fun page(text:String="解析",pixels:String="A",window:Int=1):PageSnapshot {
 val root=ScreenNode("0","","","","FrameLayout",Bounds(0,0,600,1000),false,false,false)
 val regions=listOf(OcrRegion("ocr:0",text,Bounds(30,100,550,140),"f-$pixels",window))
 return PageSnapshot("f-$pixels",100,"org.target",window,listOf(root),regions,ScreenFingerprint.of("org.target",window,600,1000,listOf(root),regions),600,1000,visualFrame=pixels)
}
private fun initial()=RunFacts("run","ws","rev","__generic__",1,"hash",status="running",phase="submitting",total=2,pendingSubmit=true,pendingSubmissionId="actual-submit",pendingAt=100,lastOrdinal=1,lastFingerprint=QuestionMatcher.key(q.type,q.stem,q.options.map { it.text }))
private val changed=ActionOutcome.scrollPreDispatchRejected("changed",listOf("VISUAL_HASH_CHANGED"))
private fun facts()=initial().copy(viewportSearch=ViewportSearch("finding_receipt",1,"A",1,0,1000))
private fun action(p:PageSnapshot=page(),id:String="scroll-1")=ActionIntent(id,"run",p.frameId,p.fingerprint,"scroll_forward","viewport",purpose="scroll")
fun main(){var passed=0;var failed=0
 fun test(name:String,block:()->Unit){try{block();passed++;println("PASS $name")}catch(e:Throwable){failed++;println("FAIL $name: ${e.message}")}}
 test("only sole hash mismatch carries the no-dispatch kind") {
  check(changed.rejectionKind==ActionRejectionKind.SCROLL_FRAME_CHANGED_BEFORE_DISPATCH)
  for(codes in listOf(emptyList(),listOf("WINDOW_CHANGED"),listOf("VISUAL_HASH_CHANGED","WINDOW_CHANGED"),listOf("VISUAL_HASH_CHANGED","OLD_FRAME_AGE")))check(ActionOutcome.scrollPreDispatchRejected("no",codes).rejectionKind==null)
 }
 test("A to B to B rereads and replans a fresh scroll instead of pausing or replaying") {
  val c=GenericCoordinator(recognizer,initial()){_,_->};val p=page();val first=checkNotNull(c.onPage(p,1000));val gate=ScrollReobservation()
  check(gate.defer(first,p,c.facts,c.facts,7,1100,changed));check(c.facts.status=="running")
  check(gate.inspect(page(pixels="B"),c.facts,7,1200)==ScrollObservationDecision.WAIT)
  check(gate.consume(page(pixels="B"),c.facts,7,1500)==ScrollObservationDecision.READY)
  val second=checkNotNull(c.onPage(page(pixels="B"),1500));check(second.id!=first.id&&second.frameId=="f-B"&&second.purpose=="scroll")
  check(c.facts.viewportSearch!!.attempts==2) // Known no-dispatch still consumes the existing four-attempt search quota.
  check(c.facts.pendingSubmissionId=="actual-submit"&&c.facts.submittedCount==0)
 }
 test("only two refreshes per same search even with new hash and intent IDs") {
  val g=ScrollReobservation();var f=facts()
  check(g.defer(action(),page(),f,f,7,1100,changed));check(g.consume(page(pixels="B"),f,7,1500)==ScrollObservationDecision.READY)
  f=f.copy(viewportSearch=f.viewportSearch!!.copy(frame="B",attempts=2))
  check(g.defer(action(page(pixels="B"),"scroll-2"),page(pixels="B"),f,f,7,1600,changed));check(g.consume(page(pixels="C"),f,7,2000)==ScrollObservationDecision.READY)
  f=f.copy(viewportSearch=f.viewportSearch!!.copy(frame="C",attempts=3))
  check(!g.defer(action(page(pixels="C"),"scroll-3"),page(pixels="C"),f,f,7,2100,changed))
 }
 test("deadline is not restarted by new hashes or intents") {
  val g=ScrollReobservation();val f=facts();check(g.defer(action(),page(),f,f,7,1100,changed));g.consume(page(pixels="B"),f,7,1500)
  check(!g.defer(action(page(pixels="C"),"new"),page(pixels="C"),f,f,7,7101,changed))
 }
 test("same window package root geometry and generation required before fresh page") {
  for(p in listOf(page(window=2),page().copy(packageName="other.app"),page().copy(width=601),page().copy(nodes=page().nodes.map{it.copy(bounds=Bounds(0,0,600,999))}))){val g=ScrollReobservation();val f=facts();check(g.defer(action(),page(),f,f,7,1100,changed));check(g.inspect(p,f,7,1500)==ScrollObservationDecision.REJECT)}
  val g=ScrollReobservation();val f=facts();check(g.defer(action(),page(),f,f,7,1100,changed));check(g.inspect(page(),f,8,1500)==ScrollObservationDecision.REJECT)
 }
 test("stop changed submission identity and readonly reconciliation invalidate refresh") {
  for(f in listOf(facts().copy(status="stopped"),facts().copy(pendingSubmissionId="other"),facts().copy(receiptCheckReturnStatus="stopped"),facts().copy(submittedCount=1),facts().copy(bankRevision="new"))){val g=ScrollReobservation();check(g.defer(action(),page(),facts(),facts(),7,1100,changed));check(g.inspect(page(),f,7,1500)==ScrollObservationDecision.REJECT)}
 }
 test("no select submit native scroll or ambiguous failure can opt in") {
  for(a in listOf(action().copy(purpose="submit",operation="click"),action().copy(purpose="select",operation="click"),action().copy(targetRef="0"),action().copy(operation="scroll_backward"))){check(!ScrollReobservation().defer(a,page(),facts(),facts(),7,1100,changed))}
  for(o in listOf(ActionOutcome(false,"changed"),ActionOutcome(true,"changed",changed.rejectionKind))){check(!ScrollReobservation().defer(action(),page(),facts(),facts(),7,1100,o))}
 }
 test("late callback cannot restore facts modified since its intent") {
  check(!ScrollReobservation().defer(action(),page(),facts(),facts().copy(status="paused"),7,1100,changed))
 }
 test("restart cancel and pending deadline do not authorize a late replan") {
  val f=facts();val g=ScrollReobservation();check(g.defer(action(),page(),f,f,7,1100,changed));check(g.inspect(page(),f,7,7101)==ScrollObservationDecision.REJECT);g.clear();check(g.inspect(page(),f,7,7200)==ScrollObservationDecision.NONE)
 }
 test("settlement withdrawn during refresh blocks all navigation") {
  var allowed=true;val c=GenericCoordinator(recognizer,initial().copy(pendingSubmit=false,pendingSubmissionId=null,submittedCount=1,phase="finding_next",viewportSearch=ViewportSearch("finding_next",1,"A",0,0,1000)),{allowed}){_,_->}
  val p=page("回答正确");val a=checkNotNull(c.onPage(p,1100));val g=ScrollReobservation();check(g.defer(a,p,c.facts,c.facts,7,1200,changed));allowed=false
  check(g.consume(page("下一题",pixels="B"),c.facts,7,1700)==ScrollObservationDecision.READY);check(c.onPage(page("下一题",pixels="B"),1700)==null&&c.facts.submittedCount==1)
 }
 test("fresh receipt counts once and does not create a second submission") {
  val intents=mutableListOf<ActionIntent>();val c=GenericCoordinator(recognizer,initial(),{false}){_,a->if(a!=null)intents.add(a)}
  val p=page();val a=checkNotNull(c.onPage(p,1000));val g=ScrollReobservation();check(g.defer(a,p,c.facts,c.facts,7,1100,changed));val receipt=page("回答正确",pixels="B")
  check(g.consume(receipt,c.facts,7,1500)==ScrollObservationDecision.READY);check(c.onPage(receipt,1500)==null);check(c.facts.submittedCount==1&&!c.facts.pendingSubmit);check(c.onPage(receipt,2000)==null);check(intents.all{it.purpose=="scroll"})
 }
 test("stopped explicit receipt check never scrolls and cannot acquire refresh") {
  val c=GenericCoordinator(recognizer,initial().copy(status="stopped")){_,a->check(a==null)};c.checkReceipt(1000);check(c.onPage(page(),1800)==null)
  check(!ScrollReobservation().defer(action(),page(),c.facts,c.facts,7,1800,changed));check(c.onPage(page("回答正确"),2200)==null&&c.facts.status=="stopped"&&c.facts.submittedCount==1)
 }
 test("original four attempts and thirty second coordinator bounds remain") {
  val c=GenericCoordinator(recognizer,facts().copy(viewportSearch=facts().viewportSearch!!.copy(attempts=4))){_,_->};check(c.onPage(page(pixels="Z"),2000)==null&&c.facts.status=="paused")
  val old=GenericCoordinator(recognizer,facts()){_,_->};check(old.onPage(page(pixels="Z"),32000)==null&&old.facts.status=="paused")
 }
 test("fresh sensitive page still pauses without any retry gesture") {
  val c=GenericCoordinator(recognizer,initial()){_,_->};val a=checkNotNull(c.onPage(page(),1000));val g=ScrollReobservation();check(g.defer(a,page(),c.facts,c.facts,7,1100,changed));val sensitive=page("请输入密码",pixels="B")
  check(g.consume(sensitive,c.facts,7,1500)==ScrollObservationDecision.READY);check(c.onPage(sensitive,1500)==null&&c.facts.status=="paused")
 }
 test("blank next-question bottom is reread and replans backward scroll only") {
  val c=GenericCoordinator(recognizer,initial().copy(pendingSubmit=false,pendingSubmissionId=null,submittedCount=4,total=100,lastOrdinal=4,pendingNavigation=true,phase="next",navigationFingerprint="previous")){_,_->}
  val aPage=page().copy(ocrRegions=emptyList());val first=checkNotNull(c.onPage(aPage,1000));check(first.operation=="scroll_backward")
  val g=ScrollReobservation();check(g.defer(first,aPage,c.facts,c.facts,7,1100,changed));val bPage=page(pixels="B").copy(ocrRegions=emptyList())
  check(g.consume(bPage,c.facts,7,1500)==ScrollObservationDecision.READY);val second=checkNotNull(c.onPage(bPage,1500))
  check(second.operation=="scroll_backward"&&second.id!=first.id&&c.facts.submittedCount==4&&c.facts.pendingNavigation)
 }
 test("a native tree alone cannot satisfy the required new image observation") {
  val g=ScrollReobservation();val f=facts();check(g.defer(action(),page(),f,f,7,1100,changed))
  check(g.consume(page().copy(visualFrame=null),f,7,1500)==ScrollObservationDecision.REJECT)
 }
 println("Scroll reobservation: $passed passed, $failed failed");check(failed==0)
}

