from pathlib import Path
import subprocess,json,sys
d=Path(__file__).parent
adb=["V:/work/tools/android-sdk/platform-tools/adb.exe","-P","15057","-s","127.0.0.1:5741","exec-out","run-as","com.jimusoft.ocrreplay"]
for n,tag in [("lines-pages","mlkit"),("pages-paddle","paddle")]:
 raw=subprocess.run(adb+["cat","files/"+n+".json"],capture_output=True)
 try:a=json.loads(raw.stdout)
 except ValueError:continue
 if any(row["file"].startswith("page-") for row in a):
  (d/(sys.argv[1]+"-"+tag+".json")).write_bytes(raw.stdout);print(tag,len(a))
