from pathlib import Path
import zipfile,json,subprocess,os,hashlib
r=Path(__file__).resolve().parent
source=r.parent/'verify-0419-device/host/app/build/outputs/apk/debug/app-debug.apk'
pages=r.parent/'railway-mp-replica/app/src/main/assets/web'
events=json.loads((r/'original-run-events.json').read_text(encoding='utf-8'))
ids=events[0]['data']['ids']
assert len(ids)==100 and len(set(ids))==100
wrapper='''\n(()=>{const ids=IDS;const original=window.__ENGINE__.createQuiz;window.__ENGINE__.createQuiz=(bank,options)=>{const byId=new Map(bank.map(q=>[q.id,q]));const order=ids.map(id=>byId.get(id));if(order.some(q=>!q))throw Error('comparison bank mismatch');return original(order.concat(bank.filter(q=>!ids.includes(q.id))),{random:()=>0})};})();\n'''.replace('IDS',json.dumps(ids))
unsigned=r/'hidden-pages-unsigned.apk';aligned=r/'hidden-pages-aligned.apk';signed=r/'hidden-original-pages.apk'
with zipfile.ZipFile(source) as before,zipfile.ZipFile(unsigned,'w') as after:
    for entry in before.infolist():
        if entry.filename.startswith(('assets/web/','META-INF/')):continue
        after.writestr(entry,before.read(entry.filename))
    for f in pages.iterdir():
        data=f.read_bytes()
        if f.name=='quiz-engine.js':data+=wrapper.encode()
        after.writestr('assets/web/'+f.name,data,compress_type=zipfile.ZIP_DEFLATED)
sdk=r.parent/'tools/android-sdk/build-tools/35.0.0'
subprocess.run([str(sdk/'zipalign.exe'),'-f','4',str(unsigned),str(aligned)],check=True)
env=os.environ.copy();env['JAVA_HOME']=str(next((r.parent/'tools/jdk').glob('jdk-17*')))
subprocess.run([str(sdk/'apksigner.bat'),'sign','--ks','V:/work/android-user/debug.keystore','--ks-key-alias','androiddebugkey','--ks-pass','pass:android','--key-pass','pass:android','--out',str(signed),str(aligned)],check=True,env=env)
proof={'apk':str(signed),'sha256':hashlib.sha256(signed.read_bytes()).hexdigest(),'baseHostSha256':hashlib.sha256(source.read_bytes()).hexdigest(),'appCodeUnchanged':True,'originalRailwayHtmlAndCss':True,'accessibilityTextHidden':True,'questionOrder':ids,'answerInjection':False}
(r/'hidden-host-proof.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in proof.items() if k!='questionOrder'}))
