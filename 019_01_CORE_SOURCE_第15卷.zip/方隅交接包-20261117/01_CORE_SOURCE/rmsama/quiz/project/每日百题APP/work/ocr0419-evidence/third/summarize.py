from pathlib import Path
import json
d=Path(__file__).parent
all_modes={f.stem[7:]:{r["file"]:r["outcome"] for r in json.loads(f.read_text(encoding="utf8"))} for f in d.glob("result-*.json")};base=all_modes["production"];report={}
for m,r in all_modes.items():
 report[m]={"legacyCorrect":sum(v=="correct" for k,v in r.items() if k.startswith("upstream-")),"hardCorrect":[k for k,v in r.items() if k.startswith("sample-") and v=="correct"],"newlyRecovered":[k for k,v in r.items() if v=="correct" and base[k]!="correct"],"wrong":[k for k,v in r.items() if v=="wrong"]}
(d/"comparison.json").write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding="utf-8")
print(json.dumps(report,ensure_ascii=False))
