from pathlib import Path
import json,re,base64,io,time,concurrent.futures
from urllib.request import Request,urlopen
from PIL import Image
r=Path('V:/work/original-vs-0419');corpus=r/'railway-corpus'
batch=json.loads((r/'batch-check/batch-ocr-result.json').read_text(encoding='utf-8'))
manifest=json.loads((corpus/'manifest.json').read_text(encoding='utf-8'))
failures={row['questionNo'] for row in batch['results'] if not row['matchesExpected']}
text=Path('V:/work/tijing-bankassist/android/app/src/main/java/com/futureyyy/tijing/QuizRuntimeConfig.kt').read_text(encoding='utf-8')
prompt=re.search(r'BANK_SCREEN_PROMPT = """(.*?)"""',text,re.S).group(1)
prompt='\n'.join(line.strip() for line in prompt.strip().splitlines())
def one(frame):
    no=frame['questionNo'];start=time.monotonic()
    output=io.BytesIO();Image.open(corpus/frame['file']).convert('RGB').save(output,format='JPEG',quality=78)
    image='data:image/jpeg;base64,'+base64.b64encode(output.getvalue()).decode()
    body={'model':'deepseek-flash','messages':[{'role':'system','content':prompt.replace('{QUESTION_NO}',str(no))},
        {'role':'user','content':[{'type':'text','text':f'这是第 {no} 题，请按系统提示词返回 JSON。'},
        {'type':'image_url','image_url':{'url':image}}]}],'temperature':0,'max_tokens':1200,'response_format':{'type':'json_object'}}
    req=Request('http://127.0.0.1:18765/v1/chat/completions',data=json.dumps(body,ensure_ascii=False).encode(),headers={'Content-Type':'application/json','Authorization':'Bearer isolated-diagnostic-no-authority'})
    try:
        with urlopen(req,timeout=40) as response:result=json.load(response)
        raw=result['choices'][0]['message']['content'];json.loads(raw)
        file=f'cloud-{no:03d}.json';(corpus/file).write_text(raw,encoding='utf-8')
        (corpus/f'cloud-{no:03d}-receipt.json').write_text(json.dumps({'usage':result.get('usage'),
            'model':result.get('model'),'elapsedSeconds':round(time.monotonic()-start,2),'bankOrAnswerInjected':False}),encoding='utf-8')
        return no,file
    except Exception as error:return no,{'error':type(error).__name__}
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
    results=list(pool.map(one,[f for f in manifest['frames'] if f['questionNo'] in failures]))
for no,file in results:
    if isinstance(file,str):manifest['frames'][no-1]['transcriptFile']=file
(corpus/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'requests':len(results),'results':results,'actualCloudTranscripts':True,'answersInjected':False}))
