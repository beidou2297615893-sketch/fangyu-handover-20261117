'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { main } = require('./dailyHundredUrlProbeV1/index');

test('all inputs return only the constant disabled HTTP response', async () => {
  const expected = {statusCode:503,headers:{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'},body:'{"paymentEnabled":false}'};
  for (const input of [undefined, null, {}, {action:'diagnostic'}, {httpMethod:'POST',body:'{"action":"diagnostic"}',headers:{authorization:'arbitrary'},path:'/api/billing/orders'}, {queryString:{action:'diagnostic'}}]) {
    assert.deepEqual(await main(input), expected);
  }
});
