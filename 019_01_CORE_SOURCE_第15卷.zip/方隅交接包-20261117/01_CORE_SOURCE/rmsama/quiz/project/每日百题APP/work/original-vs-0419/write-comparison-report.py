from pathlib import Path
import json,datetime
r=Path('V:/work/original-vs-0419');project=r.parent.parent
stamp=datetime.datetime.now().strftime('%Y-%m-%d %H:%M')
audit=json.loads((r/'evidence-audit.json').read_text(encoding='utf-8'))
pointer=r/'active-natural-folder.txt'
folder=r/(pointer.read_text(encoding='utf-8').strip() if pointer.exists() else 'hidden-roman-fixed')
p=json.loads((folder/'current-progress.json').read_text(encoding='utf-8'))
complete=p['confirmed']==100 and p['correct']==100 and p['last']=='result'
status='100题全部正确且已显示成绩' if complete else f"已提交{p['confirmed']}题，正确{p['correct']}题，错误{p['wrong']}题；尚未通过全程验收"
batchPointer=r/'active-batch-folder.txt'
batchFolder=r/(batchPointer.read_text(encoding='utf-8').strip() if batchPointer.exists() else 'batch-contrast')
batch=json.loads((batchFolder/'batch-ocr-result.json').read_text(encoding='utf-8'))
local=sum(x['matchesExpected'] for x in batch['results'])
cloud=sum(not x['matchesExpected'] and x.get('cloudComparison',{}).get('matchesExpected',False) for x in batch['results'])
unmatched=len(batch['results'])-local-cloud
batchStatus=f"已检查{len(batch['results'])}张：{local}张本机查库正确，{cloud}张备用读题后查库正确，{unmatched}张未通过。仅诊断，不是自动提交成绩"
mobileFile=r/'release-mobile/android/app/build/outputs/apk/prod/release/app-prod-release.apk'
mobileBytes=mobileFile.stat().st_size
releaseProof=json.loads((r/'release-checks/result.json').read_text(encoding='utf-8'))
destination=project/'outputs/原版与知题铁路对照';destination.mkdir(parents=True,exist_ok=True)
report=f'''# 原版与知题铁路答题对照

更新：{stamp}。本次只测模拟器，不包含用户的小米手机和支付宝实付，也没有发布新版本。

## 结论

不能再说“已经没有问题”。现有版本在能直接读取文字的铁路页面完成了100题，全部正确；在只能截图识字、并保留真实判分和下一题步骤的页面上，确实复现了暂停。原版也没有在本次条件下直接跑通，不能把回退原版等同于已经解决问题。

## 实际对照

| 测试 | 实际结果 | 范围 |
| --- | --- | --- |
| 作者发布的原版安装包 | 第一题截图超时，未提交 | 原版实际安装运行 |
| 与原版16份原生代码一致的诊断对照包 | 静态页同样截图超时 | 为记录日志使用调试包 |
| 原版对照包，额外给测试页面持续微小重绘 | 提交2题，1对1错 | 辅助诊断，不能视为自然运行通过，也不能据2题推算整体准确率 |
| 知题现有答题核心，能直接读取文字的页面 | 100题全部正确，逐题只提交一次，无人工代答 | 支付被隔离的同源测试包 |
| 知题现有答题核心，只能截图识字的真实流程 | 答对3题后暂停在下一题步骤 | 没有人工继续，保留失败现场 |
| 当前小幅修正后的截图流程 | {status} | 同一题库、同一100题顺序，仍是测试包 |
| 真实画面逐图核验 | {batchStatus} | 保留完整截图，使用已安装包自身的识字和查库代码 |

## 问题出在哪里

1. **原版的功能被理解错了。** 本次核对的原版自动视觉答题每题调用模型，并不先查本机题库；原版题库入口用于识别题干、查库展示，采用手动答题。仅更名、换界面、接支付，无法直接得到“自动查库、自动提交、模型只兜底”的全部行为。这不代表所有原版配置都不可用。
2. **原版截图存在静态页面时序问题。** 它在隐藏浮窗的等待期间把可用帧取走，静态画面可能不再产生新帧。日志和测试页面增加重绘的对照支持这个原因。
3. **模型配置也能造成空结果。** 在本次模型配置下，默认思考占满原版输出预算，正式内容为空；关闭思考后相同请求有正常输出。现有知题网关已经关闭思考，所以不能把它当作现版本所有故障的解释。
4. **新增识字与核对流程不够通用。** 本次复现了“下一题”被读成“下ー题”却未触发另一识字器；长选项字母位于第二行导致整项无法核对；罗马数字III被读出多余笔画导致暂停；选项C被读成小写c而不被接受；浅灰圆框被旧阈值排除，导致完整选项定位失败。数字、选项或按钮没核对成功就应停止，不能为了继续运行放松成猜答案。
5. **此前测试页面覆盖不足。** 旧截图测试在提交后直接换题，省略了真实的判分页和“下一题”操作。因此旧测试通过，不能证明用户真实页面也通过。这是之前交付判断过早的重要原因。

## 为什么安装包变大

作者原版为960,780字节，约0.92 MiB；已发布知题为146,088,723字节，约139.3 MiB。按安装包压缩后内容核算，新增识字运行库约112.7 MiB，识字模型约17.7 MiB。主要增量来自多架构的本机识字库和模型，不能归因于改标题、换界面或接支付本身。

新手机候选包已剔除模拟器的两套运行库，实测{mobileBytes:,}字节，约{mobileBytes/1048576:.1f} MiB。手机包与完整兼容包共有的517个文件内容逐字节相同，缩小体积没有删去识字模型或改变答题代码。候选需完成本文件所列全程验收后才可作为新版交付。

作者原版已单独放在“题镜官方原版”交付文件夹，文件名TiJing-0.7.7-open.apk，并核对作者发布的SHA-256一致。原版不内置用户题库和模型配置，需要自行导入、设置。

## 本轮改动和验收边界

本轮只复用已有识字、像素核验和查库流程，修正分支与排版处理，没有增加运行依赖或模型。实际失败画面已加入回归测试；当前{audit['unitTests']['fixed']['tests']}项单元测试全部通过。完整截图场仍以本文件上方实际进度为准。另已采集同序100张原页面截图批量排查；逐图核对属于诊断，不能算自动提交成绩。

原版测试没有证明99%的准确率，普通页面100题也不能证明所有手机100%正确。用户暂不方便连接小米手机，按要求先完成模拟器对照。支付继续由用户稍后在手机实付验收。当前修改没有作为新版上传蒲公英；旧下载地址仍是0.4.19。
'''
(destination/'对照结果.md').write_text(report,encoding='utf-8')
section=(r/'handoff-current-template.md').read_text(encoding='utf-8')
for key,value in {'STAMP':stamp,'NATURAL_FOLDER':folder.name,'NATURAL_STATUS':status,'QA_SHA':audit['fixedDiagnosticApk']['sha256'],
    'MOBILE_SHA':releaseProof['hashes']['mobile'],'UNIVERSAL_SHA':releaseProof['hashes']['universal']}.items():
    section=section.replace('$'+key+'$',value)
handoff=project/'outputs/开发交接/知题-AI接手续办.md'
old=handoff.read_text(encoding='utf-8')
separator='--- 以下为旧历史，不优先于上方最新块 ---\n\n'
if old.startswith('# 2026-11-14 最新接续状态') and separator in old:old=old.split(separator,1)[1]
handoff.write_text(section+old,encoding='utf-8')
print(json.dumps({'report':str(destination/'对照结果.md'),'status':status,'handoffUpdated':True},ensure_ascii=False))
