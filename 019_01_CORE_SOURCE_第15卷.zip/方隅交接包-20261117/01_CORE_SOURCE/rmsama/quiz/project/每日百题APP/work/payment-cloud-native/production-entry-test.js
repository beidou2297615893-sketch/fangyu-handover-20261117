'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict'),crypto=require('node:crypto'),urllib=require('urllib').default;
const {createProductionEntry}=require('./production-entry');
const b64=()=>crypto.randomBytes(32).toString('base64url');
function fixture(){
 const app=crypto.generateKeyPairSync('rsa',{modulusLength:2048,privateKeyEncoding:{type:'pkcs8',format:'pem'}}),provider=crypto.generateKeyPairSync('rsa',{modulusLength:2048,privateKeyEncoding:{type:'pkcs8',format:'pem'},publicKeyEncoding:{type:'spki',format:'pem'}});
 const env={BILLING_ENABLED:'true',BILLING_NATIVE_ADMISSION_READY:'true',BILLING_NATIVE_RELEASE_VERIFIED:'true',BILLING_CLOUD_ACL_VERIFIED:'true',BILLING_APPROVED_ORIGIN:'https://billing.example.test',ALIPAY_APP_ID:'2021000000000000',ALIPAY_SELLER_ID:'2088000000000000',ALIPAY_PRIVATE_KEY:app.privateKey,ALIPAY_PUBLIC_KEY:provider.publicKey,BILLING_MASTER_KEY:crypto.randomBytes(32).toString('base64'),BILLING_NOTIFY_URL:'https://billing.example.test/api/billing/alipay/notify',BILLING_RETURN_URL:'https://billing.example.test/api/billing/alipay/return'};
 const registration={requestId:b64(),verifier:b64()},orderRequestId='candidate-1';const digest=x=>crypto.createHash('sha256').update(x).digest('hex');
 const key=require('./production-config').validateProductionSettings(env,env.BILLING_APPROVED_ORIGIN).registrationKey;
 const owner=crypto.createHmac('sha256',Buffer.from(key,'utf8')).update('dailyhundred-installation-owner-v2\0').update(JSON.stringify([registration.requestId,registration.verifier])).digest().subarray(0,16);owner[0]=0x49;
 Object.assign(env,{BILLING_PILOT_ENABLED:'true',BILLING_PILOT_OWNER:'i'+owner.toString('hex'),BILLING_PILOT_REGISTRATION_HASH:digest(JSON.stringify([registration.requestId,registration.verifier])),BILLING_PILOT_ORDER_HASH:digest(orderRequestId)});
 const rows=new Map([['daily_hundred_installation_v1:policy',{kind:'policy',schema:1,enabled:true}],['daily_hundred_payment_v1:policy',{kind:'policy',schema:1,enabled:true}]]);
 const db={async runTransaction(fn){return fn({collection(collection){return {doc(id){const key=collection+':'+id;return {async get(){return {data:rows.has(key)?{_id:id,...rows.get(key)}:null};},async set(v){rows.set(key,v);return {updated:1};}};}};}});}};
 const entry=createProductionEntry({environment:env,databaseFactory:async()=>db});
 const event=(path,method='GET',body,token)=>({path:'/api/billing'+path,httpMethod:method,headers:{...(body?{'content-type':'application/json'}:{}),...(token?{authorization:'Bearer '+token}:{})},body:body?JSON.stringify(body):''});
 return {env,rows,db,entry,event,provider,registration,orderRequestId};
}
test('disabled entry reads no secret and never initializes database',async()=>{
 let calls=0;const env=new Proxy({BILLING_ENABLED:'false'},{get(target,key){if(key!=='BILLING_ENABLED')throw Error('secret read');return target[key];}});
 const entry=createProductionEntry({environment:env,databaseFactory:async()=>{calls++;throw Error('db opened');}});
 assert.equal((await entry({path:'/api/billing/status',httpMethod:'GET'})).statusCode,503);assert.equal(calls,0);
});
test('validated isolated HTTP composition uses official SDK; signed query alone grants exactly once',async()=>{
 const f=fixture(),original=urllib.request;let response;
 urllib.request=async(url)=>{assert.equal(new URL(url).hostname,'openapi.alipay.com');return {status:200,headers:{},data:response};};
 try{
  const status=await f.entry(f.event('/status'));assert.equal(status.statusCode,200);assert.deepEqual(JSON.parse(status.body),{available:true,mode:'alipay-official',realPaymentsEnabled:true,taskAdmissionEnabled:true,recoverySupported:false,synthetic:false,testing:false});
  const registration=await f.entry(f.event('/installations','POST',f.registration));assert.equal(registration.statusCode,201);const token=JSON.parse(registration.body).accessToken;
  const first=await f.entry(f.event('/orders','POST',{planId:'once',clientRequestId:'candidate-1'},token));assert.equal(first.statusCode,201);const order=JSON.parse(first.body);assert.equal(order.amountFen,100);assert.equal(new URL(order.checkoutUrl).hostname,'openapi.alipay.com');
  const payload=JSON.stringify({code:'10000',out_trade_no:order.id,trade_no:'trade-local',seller_id:'2088000000000000',total_amount:'1.00',trade_status:'TRADE_SUCCESS'});
  response=`{"alipay_trade_query_response":${payload},"sign":"${crypto.sign('RSA-SHA256',Buffer.from(payload),f.provider.privateKey).toString('base64')}"}`;
  const r=await f.entry(f.event('/orders/'+order.id+'/reconcile','POST',{},token));assert.equal(JSON.parse(r.body).status,'paid');
  assert.equal(JSON.parse((await f.entry(f.event('/entitlements','GET',undefined,token))).body).runCredits,1);
  assert.equal((await f.entry(f.event('/oauth/start','POST',{}))).statusCode,503);
 }finally{urllib.request=original;}
});
test('missing config, native readiness or either collection policy leaves entry closed',async()=>{
 for(const kind of ['native','nativeRelease','cloudAcl','config','installPolicy','paymentPolicy','pilotMissing','pilotInvalid']){
  const f=fixture();if(kind==='native')f.env.BILLING_NATIVE_ADMISSION_READY='false';if(kind==='config')f.env.ALIPAY_PUBLIC_KEY='invalid';
  if(kind==='nativeRelease')delete f.env.BILLING_NATIVE_RELEASE_VERIFIED;if(kind==='cloudAcl')delete f.env.BILLING_CLOUD_ACL_VERIFIED;
  if(kind==='installPolicy')f.rows.delete('daily_hundred_installation_v1:policy');if(kind==='paymentPolicy')f.rows.delete('daily_hundred_payment_v1:policy');
  if(kind==='pilotMissing')delete f.env.BILLING_PILOT_ENABLED;if(kind==='pilotInvalid')f.env.BILLING_PILOT_ORDER_HASH='invalid';
  assert.equal((await f.entry(f.event('/status'))).statusCode,503,kind);
 }
});
test('pilot admits one registration and one idempotent one-yuan order, rejecting other identities and orders',async()=>{
 const f=fixture();
 assert.equal((await f.entry(f.event('/installations','POST',{requestId:b64(),verifier:b64()}))).statusCode,503);
 const originalOwner=f.env.BILLING_PILOT_OWNER;f.env.BILLING_PILOT_OWNER='i49'+'0'.repeat(30);
 assert.equal((await f.entry(f.event('/installations','POST',f.registration))).statusCode,503);assert.equal([...f.rows.keys()].some(k=>k.includes(':registration-')),false);f.env.BILLING_PILOT_OWNER=originalOwner;
 const first=await f.entry(f.event('/installations','POST',f.registration)),replay=await f.entry(f.event('/installations','POST',f.registration));
 assert.equal(first.statusCode,201);assert.deepEqual(JSON.parse(first.body),JSON.parse(replay.body));const identity=JSON.parse(first.body);
 const settings=require('./production-config').validateProductionSettings(f.env,f.env.BILLING_APPROVED_ORIGIN);
 const other=await require('./stable-installation').createStableInstallation({db:f.db,registrationKey:settings.registrationKey}).register({requestId:b64(),verifier:b64()});
 assert.equal((await f.entry(f.event('/entitlements','GET',undefined,other.accessToken))).statusCode,503);
 const order={planId:'once',clientRequestId:f.orderRequestId};
 assert.equal((await f.entry(f.event('/orders','POST',{...order,clientRequestId:'different-1'},identity.accessToken))).statusCode,503);
 assert.equal((await f.entry(f.event('/orders','POST',{...order,planId:'month'},identity.accessToken))).statusCode,503);
 const a=await f.entry(f.event('/orders','POST',order,identity.accessToken)),b=await f.entry(f.event('/orders','POST',order,identity.accessToken));
 assert.equal(a.statusCode,201);assert.equal(b.statusCode,201);assert.equal(JSON.parse(a.body).id,JSON.parse(b.body).id);assert.equal(JSON.parse(a.body).amountFen,100);
});
test('pilot signed notification and signed query grant the single paid order once',async()=>{
 const f=fixture(),original=urllib.request;let response;urllib.request=async()=>({status:200,headers:{},data:response});
 try{
  const registration=await f.entry(f.event('/installations','POST',f.registration)),token=JSON.parse(registration.body).accessToken;
  const order=JSON.parse((await f.entry(f.event('/orders','POST',{planId:'once',clientRequestId:f.orderRequestId},token))).body);
  const payload=JSON.stringify({code:'10000',out_trade_no:order.id,trade_no:'trade-pilot',seller_id:'2088000000000000',total_amount:'1.00',trade_status:'TRADE_SUCCESS'});
  response=`{"alipay_trade_query_response":${payload},"sign":"${crypto.sign('RSA-SHA256',Buffer.from(payload),f.provider.privateKey).toString('base64')}"}`;
  const fields={app_id:'2021000000000000',seller_id:'2088000000000000',out_trade_no:order.id,trade_no:'trade-pilot',total_amount:'1.00',trade_status:'TRADE_SUCCESS',sign_type:'RSA2'};
  const canonical=Object.keys(fields).filter(k=>k!=='sign_type').sort().map(k=>k+'='+fields[k]).join('&');fields.sign=crypto.sign('RSA-SHA256',Buffer.from(canonical),f.provider.privateKey).toString('base64');
  const notify=values=>({path:'/api/billing/alipay/notify',httpMethod:'POST',headers:{'content-type':'application/x-www-form-urlencoded'},body:new URLSearchParams(values).toString()});
  assert.equal((await f.entry(notify({...fields,total_amount:'2.00'}))).statusCode,400);
  assert.equal(JSON.parse((await f.entry(f.event('/entitlements','GET',undefined,token))).body).runCredits,0);
  const a=await f.entry(notify(fields)),b=await f.entry(notify(fields));assert.equal(a.statusCode,200);assert.equal(b.statusCode,200);
  assert.equal(JSON.parse((await f.entry(f.event('/entitlements','GET',undefined,token))).body).runCredits,1);
  assert.equal([...f.rows.keys()].filter(k=>k.includes(':grant-')).length,1);
 }finally{urllib.request=original;}
});
test('explicit public mode supports multiple users and all plans while preserving pilot identity',async()=>{
 const f=fixture();
 const prior=JSON.parse((await f.entry(f.event('/installations','POST',f.registration))).body);
 f.env.BILLING_PILOT_ENABLED='false';f.env.BILLING_PUBLIC_ENABLED='true';f.env.BILLING_FREE_DEVICE_LEDGER_ENABLED='true';f.rows.set('daily_hundred_free_device_v1:policy',{kind:'policy',schema:1,enabled:true});
 const same=JSON.parse((await f.entry(f.event('/installations','POST',f.registration))).body);
 assert.equal(same.installationId,prior.installationId);assert.equal(same.accessToken,prior.accessToken);
 const second=await f.entry(f.event('/installations','POST',{requestId:b64(),verifier:b64()}));
 assert.equal(second.statusCode,201);const token=JSON.parse(second.body).accessToken;
 for(const [planId,amountFen] of [['once',100],['week',590],['month',990]]){
  const data={planId,clientRequestId:'public-'+planId};
  const first=await f.entry(f.event('/orders','POST',data,token)),repeat=await f.entry(f.event('/orders','POST',data,token));
  assert.equal(first.statusCode,201,planId);assert.equal(JSON.parse(first.body).amountFen,amountFen);
  assert.equal(JSON.parse(first.body).id,JSON.parse(repeat.body).id);
 }
});
test('pilot paid credit remains available after explicit public-mode switch',async()=>{
 const f=fixture(),original=urllib.request;let response;urllib.request=async()=>({status:200,headers:{},data:response});
 try{
  const old=JSON.parse((await f.entry(f.event('/installations','POST',f.registration))).body);
  const order=JSON.parse((await f.entry(f.event('/orders','POST',{planId:'once',clientRequestId:f.orderRequestId},old.accessToken))).body);
  const payload=JSON.stringify({code:'10000',out_trade_no:order.id,trade_no:'trade-transition',seller_id:'2088000000000000',total_amount:'1.00',trade_status:'TRADE_SUCCESS'});
  response=`{"alipay_trade_query_response":${payload},"sign":"${crypto.sign('RSA-SHA256',Buffer.from(payload),f.provider.privateKey).toString('base64')}"}`;
  assert.equal(JSON.parse((await f.entry(f.event('/orders/'+order.id+'/reconcile','POST',{},old.accessToken))).body).status,'paid');
  f.env.BILLING_PILOT_ENABLED='false';f.env.BILLING_PUBLIC_ENABLED='true';f.env.BILLING_FREE_DEVICE_LEDGER_ENABLED='true';f.rows.set('daily_hundred_free_device_v1:policy',{kind:'policy',schema:1,enabled:true});
  const account=await f.entry(f.event('/entitlements','GET',undefined,old.accessToken));
  assert.equal(account.statusCode,200);assert.equal(JSON.parse(account.body).runCredits,1);
  assert.equal([...f.rows.keys()].filter(k=>k.includes(':grant-')).length,1);
 }finally{urllib.request=original;}
});
test('ambiguous or absent public switch remains closed',async()=>{
 for(const [pilot,publicMode] of [['true','true'],['false',undefined],['false','yes'],[undefined,'true']]){
  const f=fixture();if(pilot===undefined)delete f.env.BILLING_PILOT_ENABLED;else f.env.BILLING_PILOT_ENABLED=pilot;
  if(publicMode===undefined)delete f.env.BILLING_PUBLIC_ENABLED;else f.env.BILLING_PUBLIC_ENABLED=publicMode;
  assert.equal((await f.entry(f.event('/status'))).statusCode,503);
 }
});
test('public free-device ledger needs explicit gate and its own enabled policy',async()=>{
 const f=fixture();f.env.BILLING_PILOT_ENABLED='false';f.env.BILLING_PUBLIC_ENABLED='true';f.env.BILLING_FREE_DEVICE_LEDGER_ENABLED='true';
 assert.equal((await f.entry(f.event('/status'))).statusCode,200);
 const identity=JSON.parse((await f.entry(f.event('/installations','POST',f.registration))).body);
 assert.equal((await f.entry(f.event('/free/migrate','POST',{deviceDigest:'a'.repeat(64),legacyEntries:{}},identity.accessToken))).statusCode,503);
 assert.equal((await f.entry(f.event('/entitlements','GET',undefined,identity.accessToken))).statusCode,200);
 f.rows.set('daily_hundred_free_device_v1:policy',{kind:'policy',schema:1,enabled:true});
 const a=JSON.parse((await f.entry(f.event('/installations','POST',f.registration))).body);
 const migrate=await f.entry(f.event('/free/migrate','POST',{deviceDigest:'a'.repeat(64),legacyEntries:{old:'used'}},a.accessToken));
 assert.equal(migrate.statusCode,200);assert.equal(JSON.parse(migrate.body).remaining,2);
 const reserve=await f.entry(f.event('/free/reserve','POST',{deviceDigest:'a'.repeat(64),runId:'next',taskBinding:'b'.repeat(64)},a.accessToken));
 assert.equal(reserve.statusCode,200);assert.equal(JSON.parse(reserve.body).status,'reserved');
 const paidStatus=await f.entry(f.event('/entitlements','GET',undefined,a.accessToken));assert.equal(paidStatus.statusCode,200);
});
test('paid entitlements remain accessible if free-device quota is disabled',async()=>{
 const f=fixture();f.env.BILLING_PILOT_ENABLED='false';f.env.BILLING_PUBLIC_ENABLED='true';
 assert.equal((await f.entry(f.event('/status'))).statusCode,200);
 const identity=JSON.parse((await f.entry(f.event('/installations','POST',f.registration))).body);
 assert.equal((await f.entry(f.event('/entitlements','GET',undefined,identity.accessToken))).statusCode,200);
 assert.notEqual((await f.entry(f.event('/free/status','POST',{deviceDigest:'a'.repeat(64)},identity.accessToken))).statusCode,200);
});
test('free-device flag cannot relax pilot owner restriction',async()=>{
 const f=fixture();f.env.BILLING_FREE_DEVICE_LEDGER_ENABLED='true';f.rows.set('daily_hundred_free_device_v1:policy',{kind:'policy',schema:1,enabled:true});
 assert.equal((await f.entry(f.event('/status'))).statusCode,503);
});
test('event validation works on runtimes without String.isWellFormed and rejects unpaired surrogates',async()=>{
 const old=String.prototype.isWellFormed;try{
  String.prototype.isWellFormed=undefined;const f=fixture();
  assert.equal((await f.entry(f.event('/status'))).statusCode,200);
  const malformed=f.event('/installations','POST',{requestId:'\ud800',verifier:b64()});assert.equal((await f.entry(malformed)).statusCode,503);
 }finally{String.prototype.isWellFormed=old;}
});

test('observed Function URL form fields retain exact bytes through the payment router',async()=>{
 // These are precisely the fields checked true by the isolated online probe;
 // no claim is made about unrecorded gateway fields or a real Alipay callback.
 const {createInternalRouter}=require('./billing-event');
 const fixtureBody='probe_id=fixture123&value=alpha%2Bbeta';
 const observed={httpMethod:'POST',path:'/__probe__/form',headers:{'Content-Type':'application/x-www-form-urlencoded','X-Probe-Fixture':'fixture123'},body:fixtureBody};
 const probe=require('../payment-cloud-probe-prep/url-format-probe/dailyHundredUrlFormatProbeV1/index.js');
 const proof=JSON.parse((await probe.main(observed)).body);
 assert.deepEqual(proof.checks,{method:true,path:true,contentType:true,fixtureHeader:true,rawBody:true});
 let received;
 const router=createInternalRouter({billing:{notify:async raw=>{received=raw;}}});
 // The Function URL passes the requested path: only the route differs here.
 const adapted={...observed,path:'/api/billing/alipay/notify'};
 const reply=await router(adapted);
 assert.equal(reply.statusCode,200);assert.equal(reply.body,'success');assert.equal(received,fixtureBody);
 const failing=createInternalRouter({billing:{notify:async()=>{throw Error('invalid signature');}}});
 const rejection=await failing(adapted);assert.equal(rejection.statusCode,400);assert.equal(rejection.body,'failure');
});

test('Function URL origin composes into the protected entry without enabling production by default',async()=>{
 const f=fixture(),origin='https://abc123-fixture.ap-shanghai.tencentscf.com';
 f.env.BILLING_APPROVED_ORIGIN=origin;f.env.BILLING_NOTIFY_URL=origin+'/api/billing/alipay/notify';f.env.BILLING_RETURN_URL=origin+'/api/billing/alipay/return';
 const status=await f.entry({httpMethod:'GET',path:'/api/billing/status',headers:{},body:''});
 assert.equal(status.statusCode,200);assert.equal(JSON.parse(status.body).realPaymentsEnabled,true);
 const disabled=createProductionEntry({environment:{BILLING_ENABLED:'false'},databaseFactory:async()=>{throw Error('must not be opened');}});
 assert.equal((await disabled({httpMethod:'GET',path:'/api/billing/status',headers:{},body:''})).statusCode,503);
});

test('authenticated cancellation writes an immutable no-balance tombstone through the production router',async()=>{
 const f=fixture(),a=JSON.parse((await f.entry(f.event('/installations','POST',f.registration))).body);
 const request=f.event('/runs/late/cancel','POST',{taskBinding:'a'.repeat(64)},a.accessToken);
 const result=await f.entry(request);assert.equal(result.statusCode,200);
 assert.deepEqual(JSON.parse(result.body),{ownerId:a.installationId,runId:'late',taskBinding:'a'.repeat(64),status:'cancelled'});
 assert.deepEqual(JSON.parse((await f.entry(request)).body),JSON.parse(result.body));
 assert.equal((await f.entry(f.event('/runs/late/cancel','POST',{taskBinding:'b'.repeat(64)},a.accessToken))).statusCode,503);
 assert.equal((await f.entry(f.event('/runs/reserve','POST',{runId:'late',taskBinding:'a'.repeat(64)},a.accessToken))).statusCode,503);
 assert.equal((await f.entry(f.event('/runs/late/cancel','POST',{taskBinding:'a'.repeat(64)}))).statusCode,503);
});
