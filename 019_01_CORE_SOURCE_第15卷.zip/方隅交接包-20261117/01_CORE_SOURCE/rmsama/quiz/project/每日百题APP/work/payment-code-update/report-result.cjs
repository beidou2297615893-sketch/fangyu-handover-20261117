'use strict';
// Shared by the real command and the isolated subprocess checks.
async function reportResult(operation) {
 try {
  const result = await operation();
  process.stdout.write(JSON.stringify(result) + '\n');
  if (result?.updated !== true) process.exitCode = 2;
 } catch {
  process.stdout.write('{"updated":false,"paymentEnabled":false,"retryAllowed":false}\n');
  process.exitCode = 2;
 }
}
module.exports = {reportResult};
