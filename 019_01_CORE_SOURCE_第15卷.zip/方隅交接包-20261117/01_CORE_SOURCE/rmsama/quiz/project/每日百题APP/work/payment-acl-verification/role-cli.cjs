'use strict';
const fs=require('node:fs'),path=require('node:path'),os=require('node:os'),crypto=require('node:crypto'),{spawnSync}=require('node:child_process');
const {run}=require('./role-orchestrator.cjs'),{update,codeHash}=require('../payment-probe-init/update-code.cjs'),{hash,auditPackage}=require('../payment-probe-init/integrity.cjs');
for(const n of ['log','info','warn','error','debug','trace'])console[n]=()=>{};
const REVIEWED=true,root=__dirname,source=path.join(root,'probe-stage'),marker=path.join(root,'role-verification-attempted.lock'),archive=path.join(root,'role-verification-package.zip');
const EXPECTED=Object.freeze({'isolated-probe.js':'51d8ef53457c4eb521846298db4e92dd4fd09fb87111def8f4960edd4002f6f5','package.json':'c65a8e0dccb2205b707ab6c38387c63f6ed242e7fe84aacafc29b48f26acca44','diagnostic-original.js':'b3880d1779a01a13cbe1e4adefe79bd04e79942eea3948ec2d896efdab4b9895','policy-init.cjs':'c60a74262794ab8910ba344d1a1fa29e99e2146c02e54cace1b51c493cff1128','role-transaction.cjs':'65f303db8fcc51e9a44b819d64b614af887ee3eb5529a5991db28846efe9c048'});
const fail=()=>{throw Error('unavailable')},pwsh=()=>path.join(os.homedir(),'.cache','codex-runtimes','codex-primary-runtime','dependencies','native','powershell','pwsh.exe');
function audit(){if(!REVIEWED||process.argv.length!==3||process.argv[2]!=='--apply'||!process.env.BILLING_INIT_TCB||fs.existsSync(marker)||process.execArgv.length)fail();
 if(['NODE_OPTIONS','NODE_DEBUG','DEBUG','NODE_EXTRA_CA_CERTS','NODE_USE_SYSTEM_CA','NODE_USE_ENV_PROXY','NODE_PATH','SSL_CERT_FILE','SSL_CERT_DIR','CURL_CA_BUNDLE','REQUESTS_CA_BUNDLE','USE_INTERNAL_ENDPOINT','HTTP_PROXY','HTTPS_PROXY','ALL_PROXY','http_proxy','https_proxy','all_proxy','NODE_TLS_REJECT_UNAUTHORIZED'].some(k=>process.env[k]))fail();
 auditPackage(source,path.resolve(root,'../payment-cloud-native/isolated-probe.js'),path.resolve(root,'../payment-database-init/policy-init.cjs'),path.resolve(root,'../payment-cloud-probe-prep/dailyHundredPaymentProbeV1/node_modules'),EXPECTED);
 if(hash(path.join(root,'role-transaction.cjs'))!==EXPECTED['role-transaction.cjs'])fail();}
function prepare(){
 const script=path.resolve(root,'../payment-probe-init/archive.ps1'),validator=path.resolve(root,'../payment-probe-init/validate-archive.ps1');
 const p=spawnSync(pwsh(),['-NoProfile','-NonInteractive','-File',script,'-Source',source,'-Archive',archive],{encoding:'utf8',timeout:120000,windowsHide:true});if(p.status!==0||p.error)fail();
 const stat=fs.statSync(archive);if(!stat.isFile()||stat.size<1||stat.size>20*1024*1024)fail();const expectedHash=hash(archive);
 const v=spawnSync(pwsh(),['-NoProfile','-NonInteractive','-File',validator,'-Source',source,'-Archive',archive],{encoding:'utf8',timeout:120000,windowsHide:true});
 if(v.status!==0||v.error||v.stderr||v.stdout!=='ARCHIVE_OK'||hash(archive)!==expectedHash)fail();const zip=fs.readFileSync(archive);if(crypto.createHash('sha256').update(zip).digest('hex')!==expectedHash)fail();
 const auth=JSON.parse(fs.readFileSync(path.join(os.homedir(),'.config','.cloudbase','auth.json'),'utf8')),c=auth.credential||{},secretId=c.secretId||c.tmpSecretId,secretKey=c.secretKey||c.tmpSecretKey,token=c.token||c.tmpToken,expiry=c.accessTokenExpired||c.tmpExpired;
 if(typeof secretId!=='string'||typeof secretKey!=='string'||typeof token!=='string'||!Number.isFinite(Number(expiry))||Number(expiry)<=Date.now()+120000)fail();
 const sdkRoot=path.resolve(root,'../payment-secret-prep/sdk-scf/node_modules'),http=require(path.join(sdkRoot,'tencentcloud-sdk-nodejs-common/tencentcloud/common/http/fetch'));
 const orig=http.default;http.default=(url,options)=>{if(url!=='https://scf.tencentcloudapi.com/'||options?.proxy||options?.agent)fail();return orig(url,{...options,redirect:'error'});};
 const Client=require(path.join(sdkRoot,'tencentcloud-sdk-nodejs-scf')).scf.v20180416.Client,client=new Client({credential:{secretId,secretKey,token},region:'ap-shanghai',profile:{httpProfile:{endpoint:'scf.tencentcloudapi.com',reqTimeout:15,protocol:'https://'}}});
 return {packageHash:expectedHash,updateCode:async()=>update(client,zip),getCodeHash:async()=>codeHash(client),delay:async ms=>new Promise(r=>setTimeout(r,ms))};
}
function call(args){const p=spawnSync(pwsh(),['-NoProfile','-NonInteractive','-File',process.env.BILLING_INIT_TCB,...args,'--json'],{cwd:root,encoding:'utf8',timeout:45000,maxBuffer:2*1024*1024,windowsHide:true});if(p.status!==0||p.error)fail();const at=(p.stdout||'').indexOf('{');if(at<0)fail();let x;try{x=JSON.parse(p.stdout.slice(at))}catch{fail()}if(!Object.hasOwn(x,'data')||x.data===null)fail();return x.data;}
(async()=>{try{audit();const prepared=prepare();const result=await run({call,...prepared,mark:async()=>{const fd=fs.openSync(marker,'wx');try{fs.writeFileSync(fd,'attempted');fs.fsyncSync(fd)}finally{fs.closeSync(fd)}}});process.stdout.write(JSON.stringify(result)+'\n');}catch(e){const out={verified:false,paymentEnabled:false,retryAllowed:false};if(typeof e?.testId==='string'&&/^acl-test-[a-f0-9]{32}$/.test(e.testId))out.testId=e.testId;process.stdout.write(JSON.stringify(out)+'\n');process.exitCode=2;}})();
