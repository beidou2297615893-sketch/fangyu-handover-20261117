$ErrorActionPreference='Stop'
$root=Split-Path -Parent (Split-Path -Parent $PSScriptRoot)
$jdk=(Get-ChildItem (Join-Path $root 'work/tools/jdk') -Directory | Select-Object -First 1).FullName
$lib=(Get-ChildItem (Join-Path $root 'work/gradle-home/wrapper/dists/gradle-9.3.1-bin') -Directory -Recurse -Filter lib | Select-Object -First 1).FullName
$src=Join-Path $root 'outputs/daily-hundred-app/modules/automation-bridge/android/src/main/java/expo/modules/automationbridge/billing'
$out=Join-Path $PSScriptRoot 'gate-classes';New-Item -ItemType Directory -Force $out|Out-Null
$java=Join-Path $jdk 'bin/java.exe';$stdlib=Join-Path $lib 'kotlin-stdlib-2.2.21.jar'
$files=@((Join-Path $PSScriptRoot 'PaidRunGateTest.kt'),(Join-Path $src 'PaidReservationGuard.kt'))
if(Test-Path (Join-Path $src 'PaidRunGate.kt')){$files+=(Join-Path $src 'PaidRunGate.kt')}
& $java '-Dfile.encoding=UTF-8' -cp "$lib/*" org.jetbrains.kotlin.cli.jvm.K2JVMCompiler -no-stdlib -no-reflect -classpath $stdlib -d $out $files
if($LASTEXITCODE -ne 0){throw 'Paid gate compilation failed'}
& $java -cp "$out;$stdlib" expo.modules.automationbridge.billing.PaidRunGateTest
if($LASTEXITCODE -ne 0){throw 'Paid gate tests failed'}
