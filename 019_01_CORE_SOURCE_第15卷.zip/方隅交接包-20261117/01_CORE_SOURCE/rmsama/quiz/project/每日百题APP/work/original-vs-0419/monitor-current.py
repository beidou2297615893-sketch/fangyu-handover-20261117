import control as c
import time,json,sys,re
sys.stdout.reconfigure(encoding='utf-8')
host=sys.argv[2] if len(sys.argv)>2 else 'com.jimusoft.railwaymp'
if len(sys.argv)>1:
    c.R=c.R/sys.argv[1];c.R.mkdir(parents=True,exist_ok=True)
limit=float(sys.argv[3]) if len(sys.argv)>3 else 480
start=time.monotonic();last=-1
while time.monotonic()-start<limit:
    rows=[json.loads(x) for x in c.adb('exec-out','run-as',host,'cat','files/events.jsonl').splitlines()]
    at=max(i for i,r in enumerate(rows) if r['evt']=='start');rows=rows[at:]
    done=[r['data'] for r in rows if r['evt']=='confirm']
    logs=c.adb('logcat','-d','-v','brief','-t','1000','TiJingRunner:I','ZhitiBank:I','ZhitiDiagnostic:I','*:S').decode(errors='replace')
    phases=re.findall(r'gesture-snapshot phase=(\w+)',logs)
    phase=phases[-1] if phases else ''
    status={'confirmed':len(done),'correct':sum(q['correct'] for q in done),'wrong':sum(not q['correct'] for q in done),'last':rows[-1]['evt'],'phase':phase,'elapsedSeconds':round(time.monotonic()-start,1)}
    (c.R/'current-progress.json').write_text(json.dumps(status,ensure_ascii=False,indent=2),encoding='utf-8')
    if len(done)!=last: print(json.dumps(status,ensure_ascii=False),flush=True);last=len(done)
    if rows[-1]['evt']=='result' or status['wrong'] or (phase=='PAUSED_ERROR' and time.monotonic()-start>4):break
    time.sleep(3)
logs=c.adb('logcat','-d','-v','brief','TiJingRunner:I','ZhitiBank:I','ZhitiDiagnostic:I','*:S').decode(errors='replace')
(c.R/'current-run-events.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf-8')
(c.R/'current-run-log.txt').write_text(logs,encoding='utf-8')
(c.R/'final-summary.json').write_text(json.dumps(status,ensure_ascii=False,indent=2),encoding='utf-8')
(c.R/'current-final.png').write_bytes(c.adb('exec-out','screencap','-p'))
if len(sys.argv)>4 and rows[-1]['evt']!='result':
    assert sys.argv[4] in ['com.futureyyy.tijing.dev','com.jimusoft.dailyhundredapp.audit419.dev']
    c.adb('shell','am','force-stop',sys.argv[4])
print('Final:',json.dumps(status,ensure_ascii=False),flush=True)
