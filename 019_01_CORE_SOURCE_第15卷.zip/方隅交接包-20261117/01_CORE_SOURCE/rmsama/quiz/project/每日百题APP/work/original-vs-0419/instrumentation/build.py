from pathlib import Path
import os,subprocess,zipfile
r=Path('V:/work/original-vs-0419/instrumentation');sdk=Path('V:/work/tools/android-sdk');tools=sdk/'build-tools/35.0.0';platform=sdk/'platforms/android-35/android.jar'
jdk=next(Path('V:/work/tools/jdk').glob('jdk-17*'));env=os.environ.copy();env['JAVA_HOME']=str(jdk)
classes=r/'classes';classes.mkdir(exist_ok=True);dex=r/'dex';dex.mkdir(exist_ok=True)
def run(args):subprocess.run(list(map(str,args)),check=True,env=env)
run([jdk/'bin/javac.exe','-encoding','UTF-8','-source','8','-target','8','-cp',platform,'-d',classes,r/'OcrProbe.java'])
jar=r/'classes.jar'
with zipfile.ZipFile(jar,'w') as z:
 for f in classes.rglob('*.class'):z.write(f,f.relative_to(classes).as_posix())
run([tools/'d8.bat','--lib',platform,'--min-api','26','--output',dex,jar])
apk=r/'probe-unsigned.apk';aligned=r/'probe-aligned.apk';signed=r/'ocr-probe.apk'
run([tools/'aapt.exe','package','-f','-M',r/'AndroidManifest.xml','-I',platform,'-F',apk])
with zipfile.ZipFile(apk,'a') as z:z.write(dex/'classes.dex','classes.dex')
run([tools/'zipalign.exe','-f','4',apk,aligned])
run([tools/'apksigner.bat','sign','--ks',Path.home()/'.android/debug.keystore','--ks-key-alias','androiddebugkey','--ks-pass','pass:android','--key-pass','pass:android','--out',signed,aligned])
print('Built isolated OCR probe APK:',signed)
