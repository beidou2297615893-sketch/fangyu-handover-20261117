package com.futureyyy.tijing.payment

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Handler
import android.os.Looper
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors
import android.provider.Settings

class ModelAuthorization internal constructor(val owner:String,val token:String,val binding:String,val source:String,val deviceDigest:String?,val state:String) {
    override fun toString()="ModelAuthorization(redacted)"
}

/** Original fixed-origin HTTP contract, with no redirects or caller-supplied URLs. */
class AndroidBillingTransport:BillingTransport {
    override fun request(path:String,method:String,body:JSONObject?,identity:BillingIdentity?):JSONObject {
        check(com.futureyyy.tijing.BuildConfig.DEBUG && com.futureyyy.tijing.BuildConfig.APPLICATION_ID == "com.jimusoft.dailyhundredapp.audit419.dev")
        if(path == "/status") return JSONObject().put("available",false).put("testing",true).put("synthetic",true).put("realPaymentsEnabled",false).put("taskAdmissionEnabled",false)
        throw PaymentFailure("ISOLATED_DIAGNOSTIC_ONLY", "隔离验收：真实付款和正式账本不可访问。")
    }
}

class AndroidPaymentRecords(context:Context):PaymentRecords {
    private val store=SecurePaymentStore(context)
    override fun read(slot:String)=store.read(slot)
    override fun write(slot:String,value:String)=store.write(slot,value)
    override fun registration()=store.getOrCreateRegistration()
}

/** A single native owner serializes purchase/recovery. Bearer credentials never enter JavaScript. */
class PaymentRuntime private constructor(context:Context) {
    private val app=context.applicationContext
    private val main=Handler(Looper.getMainLooper())
    private val executor=Executors.newSingleThreadExecutor { r -> Thread(r,"DailyHundredPayment").apply { isDaemon=true } }
    private val config:PaymentConfig=run {
        val type=Class.forName("com.futureyyy.tijing.BuildConfig")
        fun field(name:String):Any?=runCatching { type.getField(name).get(null) }.getOrNull()
        PaymentConfig(field("BILLING_API_ORIGIN") as? String ?: "",field("BILLING_ADMISSION_ORIGIN") as? String ?: "",field("BILLING_ADMISSION_ENABLED")==true)
    }
    internal val transport:BillingTransport=AndroidBillingTransport()
    internal val ledger=AndroidRunLedger(app)
    internal val core=PaymentCore(config,AndroidPaymentRecords(app),transport) { url ->
        if(!PaymentCore.trustedCheckout(url))reject("UNTRUSTED_CHECKOUT","收银台地址未获确认。")
        app.startActivity(Intent(Intent.ACTION_VIEW,Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
    internal val runBilling=RunBilling(config,ledger,transport,{core.credential()},{pkg->AndroidRunLedger.targetIdentity(app,pkg)})
    @Volatile private var reconciledListener:(()->Unit)?=null
    fun setReconciledListener(listener:(()->Unit)?) { reconciledListener=listener }
    internal fun enqueue(action:()->Unit) { executor.execute(action) }
    private fun freeDigest():String {
        val androidId=Settings.Secure.getString(app.contentResolver,Settings.Secure.ANDROID_ID)
        return FreeDeviceDigest.derive(androidId)
    }
    internal fun cancelFreeOnWorker(row:BillingRun) {
        if(!ledger.freeServerInitialized())return
        val owner=core.credential()
        FreeService(transport,owner,freeDigest()).action("cancel",row.id,row.binding)
    }
    internal fun confirmFreeOnWorker(id:String) {
        if(ledger.read(id)?.source=="free" && ledger.freeServerInitialized())transcriptionAuthorizationOnWorker(id)
    }
    /** Native worker only; never expose this result through JavascriptInterface or logs. */
    fun transcriptionAuthorization(runId:String):ModelAuthorization {
        require(ID.matches(runId))
        return executor.submit<ModelAuthorization> { transcriptionAuthorizationOnWorker(runId) }.get()
    }
    internal fun transcriptionAuthorizationOnWorker(runId:String):ModelAuthorization {
            val row=ledger.read(runId) ?: reject("RUN_MISSING","答题任务尚未授权。")
            if(row.phase !in setOf("reserved","unknown","receipt_confirmed","confirmed"))reject("RUN_UNAVAILABLE","答题任务尚未授权。")
            return if(row.source=="free") {
                val enabled=runCatching { Class.forName("com.futureyyy.tijing.BuildConfig").getField("BILLING_FREE_DEVICE_LEDGER_ENABLED").get(null)==true }.getOrDefault(false)
                if(!enabled)reject("FREE_SERVICE_DISABLED","免费服务暂不可用。")
                val identity=core.ensureCredential()
                val digest=freeDigest()
                val free=FreeService(transport,identity,digest)
                if(!ledger.freeServerInitialized()) { free.migrate(ledger.legacyFreeEntries(runId));ledger.markFreeServerInitialized() }
                val operation=if(row.phase=="confirmed") "confirm" else "reserve"
                free.action(operation,runId,row.binding)
                ModelAuthorization(identity.owner,identity.token,row.binding,"free",digest,if(row.phase=="confirmed") "confirmed" else "reserved")
            } else {
                if(row.source !in setOf("credit","subscription"))reject("RUN_UNAVAILABLE","答题权限尚未确认。")
                if(row.phase=="receipt_confirmed")reject("SETTLEMENT_UNCONFIRMED","本次使用结算尚未确认，请先核对。")
                val identity=core.credential()
                ModelAuthorization(identity.owner,identity.token,row.binding,"paid",null,if(row.phase=="confirmed") "confirmed" else "reserved")
            }
    }
    internal fun gatewayAuthorizationOnWorker(runId:String,targetPackage:String):ModelAuthorization {
        runBilling.start(runId,targetPackage,"original-tijing-v1")
        val row=ledger.read(runId) ?: reject("RUN_MISSING","答题任务尚未授权。")
        if(row.phase=="reserved") transcriptionAuthorizationOnWorker(runId)
        runBilling.confirmForGateway(runId) { freeRun ->
            val identity=core.ensureCredential()
            val free=FreeService(transport,identity,freeDigest())
            free.action("confirm",freeRun.id,freeRun.binding)
        }
        return transcriptionAuthorizationOnWorker(runId)
    }
    fun request(operation:String,payload:JSONObject,done:(Result<JSONObject>)->Unit) {
        check(com.futureyyy.tijing.BuildConfig.DEBUG && app.packageName == "com.jimusoft.dailyhundredapp.audit419.dev")
        if(operation == "status" || operation == "refresh") {
            val view=JSONObject().put("available",false).put("paymentAvailable",false).put("paidAdmissionAvailable",false)
                .put("testing",true).put("synthetic",true).put("plans",org.json.JSONArray())
                .put("entitlement",JSONObject().put("runCredits",1).put("validUntil",JSONObject.NULL).put("revision",0).put("recoverySupported",false))
                .put("freeRemaining",0).put("pendingPayment",JSONObject.NULL)
                .put("remainingText","隔离验收：本地模拟权益，不计正式额度")
                .put("message","仅用于专用铁路宿主验收，真实付款已禁用")
            main.post { done(Result.success(view)) };return
        }

        if(operation !in setOf("status","refresh","purchase","continue","recover")) { main.post { done(Result.failure(PaymentFailure("INVALID_OPERATION","不支持的付款操作。"))) };return }
        enqueue {
            val result=runCatching {
                when(operation) {
                    "status" -> core.status(ledger.freeRemaining())
                    "refresh" -> { runCatching { GatewaySessionEntry.retryPendingEndOnWorker(app) };runBilling.recoverReleases(::cancelFreeOnWorker);val verified=core.refresh();if(verified)main.post { reconciledListener?.invoke() };core.view(ledger.freeRemaining()) }
                    "purchase" -> { core.purchase(payload.optString("planId"));core.view(ledger.freeRemaining()) }
                    "continue" -> { core.continuePending();core.view(ledger.freeRemaining()) }
                    else -> { core.recover();core.view(ledger.freeRemaining()) }
                }
            }
            val visible=result.mapCatching { it.put("pendingRunEnd",GatewaySessionEntry.hasPendingEnd(app)) }
            main.post { done(visible) }
        }
    }
    companion object {
        @Volatile private var instance:PaymentRuntime?=null
        fun get(context:Context):PaymentRuntime=instance ?: synchronized(this) { instance ?: PaymentRuntime(context).also { instance=it } }
        fun onForegroundIfInitialized(done:(Result<JSONObject>)->Unit = {}) { instance?.request("refresh",JSONObject(),done) }
    }
}
