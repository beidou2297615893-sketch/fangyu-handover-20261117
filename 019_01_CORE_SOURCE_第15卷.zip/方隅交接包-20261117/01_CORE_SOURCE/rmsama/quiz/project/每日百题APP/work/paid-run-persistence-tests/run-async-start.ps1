$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path -Parent (Split-Path -Parent $PSScriptRoot)
$jdk = (Get-ChildItem (Join-Path $projectRoot 'work/tools/jdk') -Directory | Select-Object -First 1).FullName
$lib = (Get-ChildItem (Join-Path $projectRoot 'work/gradle-home/wrapper/dists/gradle-9.3.1-bin') -Directory -Recurse -Filter lib | Select-Object -First 1).FullName
$source = Join-Path $projectRoot 'outputs/daily-hundred-app/modules/automation-bridge/android/src/main/java/expo/modules/automationbridge/billing/PaidAsyncStart.kt'
$classes = Join-Path $PSScriptRoot 'async-start-classes'; New-Item -ItemType Directory -Force $classes | Out-Null
$java = Join-Path $jdk 'bin/java.exe'; $stdlib = Join-Path $lib 'kotlin-stdlib-2.2.21.jar'
& $java '-Dfile.encoding=UTF-8' -cp "$lib/*" org.jetbrains.kotlin.cli.jvm.K2JVMCompiler -no-stdlib -no-reflect -classpath $stdlib -d $classes $source (Join-Path $PSScriptRoot 'PaidAsyncStartTest.kt')
if ($LASTEXITCODE -ne 0) { throw 'Async paid start failed to compile' }
& $java -cp "$classes;$stdlib" expo.modules.automationbridge.billing.PaidAsyncStartTest
if ($LASTEXITCODE -ne 0) { throw 'Async paid start test failed' }
