(()=>{AndroidBridge.stopFloatingSession();return {stopped:true};})()
