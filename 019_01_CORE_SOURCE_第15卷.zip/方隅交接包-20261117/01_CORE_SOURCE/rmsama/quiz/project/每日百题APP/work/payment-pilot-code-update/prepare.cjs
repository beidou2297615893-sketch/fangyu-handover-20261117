'use strict';
// Local preparation only. No credentials, SDK, HTTP or cloud operations.
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const root=__dirname,base=path.resolve(root,'../payment-code-update/dailyHundredBillingV1'),sources=path.resolve(root,'../payment-cloud-native'),stage=path.join(root,'dailyHundredBillingV1'),oldArchive=path.resolve(root,'../payment-code-update/billing-code-update.zip'),manifest=path.join(root,'manifest.json');
const changed=['billing-event.js','production-entry.js','runtime.js'],added=['pilot-policy.js'];
const sha=f=>crypto.createHash('sha256').update(fs.readFileSync(f)).digest('hex');
function files(dir){const out=[];function walk(p,prefix=''){for(const ent of fs.readdirSync(p,{withFileTypes:true})){const rel=prefix?prefix+'/'+ent.name:ent.name,full=path.join(p,ent.name);if(ent.isSymbolicLink())throw Error('symlink');if(ent.isDirectory())walk(full,rel);else if(ent.isFile())out.push(rel);else throw Error('unsupported');}}walk(dir);return out.sort();}
if(fs.existsSync(stage)||fs.existsSync(manifest))throw Error('already prepared');
if(!fs.existsSync(oldArchive)||!fs.existsSync(base))throw Error('missing baseline');
fs.cpSync(base,stage,{recursive:true,errorOnExist:true,force:false});
for(const name of [...changed,...added]){const dest=path.join(stage,name),src=path.join(sources,name);if(!fs.existsSync(src)||added.includes(name)&&fs.existsSync(dest)||changed.includes(name)&&!fs.existsSync(dest))throw Error('source mismatch');fs.copyFileSync(src,dest);}
const old=files(base),all=files(stage),expected=[...old,...added].sort();if(JSON.stringify(all)!==JSON.stringify(expected))throw Error('file mismatch');
const hashes={};for(const name of all){const hash=sha(path.join(stage,name));hashes[name]=hash;if(changed.includes(name)){if(hash===sha(path.join(base,name)))throw Error('no change')}else if(!added.includes(name)&&hash!==sha(path.join(base,name)))throw Error('unexpected change');}
fs.writeFileSync(manifest,JSON.stringify({baselineArchiveSha256:sha(oldArchive),changed,added,fileCount:all.length,files:hashes},null,2));
process.stdout.write(JSON.stringify({prepared:true,cloudWrite:false,changed,added,fileCount:all.length,baselineArchiveSha256:sha(oldArchive)})+'\n');
