// Uses an isolated, already initialized Web SDK app; no configuration changes.
import {verifyClient} from './browser-negative.mjs';
export async function verifyTemporaryUser(app,{username,password,uid}) {
 try {
  if(!app?.auth || typeof app.auth.signInWithPassword!=='function' || typeof app.auth.getSession!=='function' || typeof app.database!=='function') return {verified:false,reason:'client-unavailable'};
  const login=await app.auth.signInWithPassword({username,password});
  if(login?.error || !login?.data?.session) return {verified:false,reason:'login-failed'};
  const current=await app.auth.getSession();
  const session=current?.data?.session;
  if(current?.error || !session?.access_token || session?.user?.id!==uid || session?.user?.is_anonymous!==false || login.data.session?.user?.id!==uid) return {verified:false,reason:'identity-unverified'};
  const result=await verifyClient(app.database(),session,'registered');
  return {...result,uidVerified:true,registered:true};
 } catch {return {verified:false,reason:'indeterminate'};}
}
