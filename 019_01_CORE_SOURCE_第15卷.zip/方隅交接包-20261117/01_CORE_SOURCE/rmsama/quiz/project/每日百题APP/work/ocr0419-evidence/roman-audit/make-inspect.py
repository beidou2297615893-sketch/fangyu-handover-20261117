from pathlib import Path
d=Path(__file__).parent
m=d/'Missing.kt'
text=m.read_text('utf8')
pos=text.index(' val yes=')
extra=r'''
 val im75=ImageIO.read(File("V:/work/verify-0419-device/third-host-replay/frames/q075-real-01510.png"))
 val bb=listOf(listOf(177,637,346,679),listOf(177,778,342,820),listOf(177,920,329,962),listOf(177,1061,316,1103))
 val r75=bb.mapIndexed{i,b->VisibleQuestionReader.Node(listOf("作业，IV","作业，ⅢⅢ","作业，ⅡI","作业，1")[i],NormalizedBox(100f*b[0]/1080,100f*b[1]/1920,100f*(b[2]-b[0])/1080,100f*(b[3]-b[1])/1920))}
 println("seventy-five "+RomanChoiceEvidence.read(1080,1920,im75.getRGB(0,0,1080,1920,null,0,1080),r75))
'''
text=text[:pos]+extra+text[pos:]
(d/'Inspect.kt').write_text(text,'utf8')
p=(d/'current.py').read_text('utf8').replace('out/"Missing.kt"','out/"Inspect.kt"').replace('MissingKt','InspectKt')
(d/'inspect-current.py').write_text(p,'utf8')
