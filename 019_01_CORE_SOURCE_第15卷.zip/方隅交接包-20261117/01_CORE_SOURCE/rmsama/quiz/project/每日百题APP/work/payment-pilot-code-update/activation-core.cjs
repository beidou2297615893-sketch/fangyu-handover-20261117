'use strict';
// Offline orchestration candidate. All side effects are injected; no SDK or network.
const FN='dailyHundredBillingV1',NS='fh6-d5ga45c0ddae7008c';
const gates=['BILLING_ENABLED','BILLING_NATIVE_ADMISSION_READY','BILLING_NATIVE_RELEASE_VERIFIED','BILLING_CLOUD_ACL_VERIFIED'];
const pilotKeys=['BILLING_PILOT_ENABLED','BILLING_PILOT_OWNER','BILLING_PILOT_REGISTRATION_HASH','BILLING_PILOT_ORDER_HASH'];
const check=x=>{if(!x)throw Error('unavailable')};
function plan(rows,pilot){
 check(Array.isArray(rows)&&rows.length>4&&rows.length<=96&&pilot&&typeof pilot==='object'&&!Array.isArray(pilot)&&Object.keys(pilot).sort().join(',')===[...pilotKeys].sort().join(','));
 check(pilot.BILLING_PILOT_ENABLED==='true'&&/^i49[a-f0-9]{30}$/.test(pilot.BILLING_PILOT_OWNER)&&/^[a-f0-9]{64}$/.test(pilot.BILLING_PILOT_REGISTRATION_HASH)&&/^[a-f0-9]{64}$/.test(pilot.BILLING_PILOT_ORDER_HASH));
 const seen=new Set();for(const row of rows){check(row&&typeof row.Key==='string'&&typeof row.Value==='string'&&!seen.has(row.Key)&&!pilotKeys.includes(row.Key));seen.add(row.Key);}
 for(const g of gates)check(rows.some(x=>x.Key===g&&x.Value==='false'));
 return {FunctionName:FN,Namespace:NS,Environment:{Variables:[...rows.map(x=>({Key:x.Key,Value:gates.includes(x.Key)?'true':x.Value})),...pilotKeys.map(Key=>({Key,Value:pilot[Key]}))]}};
}
async function activate(a){
 let stage='not-submitted';try{
  check(a&&['preflight','mark','enablePolicies','verifyPolicies','updateEnvironment','verifyEnvironment'].every(k=>typeof a[k]==='function'));
  const p=await a.preflight();check(p&&p.expectedFunction===true&&p.pilotCodeVerified===true&&p.fourGatesClosed===true&&p.bothPoliciesClosed===true&&p.registeredAclDenied===true&&p.adminOnlyAcl===true&&p.transactionVerified===true&&p.apkIdentityVerified===true&&p.apkFlowVerified===true&&p.nativeAdmissionVerified===true&&p.noOpenOrder===true&&p.masterMatches===true);
  const request=plan(p.environment,p.pilot);
  await a.mark('policies');stage='policies-unknown';await a.enablePolicies();check(await a.verifyPolicies()===true);
  stage='policies-enabled-gates-closed';await a.mark('environment');stage='environment-unknown';const result=await a.updateEnvironment(request);check(typeof result?.RequestId==='string'&&result.RequestId.length>0);check(await a.verifyEnvironment(request)===true);
  return {result:'verified',oneIdentityOnly:true,paymentEnabled:true};
 }catch{return {result:stage,paymentEnabled:'unknown',retryAllowed:false};}
}
function mayClose(p){return !!p&&p.orderCreated===false&&p.definitive===true||!!p&&p.orderCreated===true&&p.orderPaidVerified===true&&p.grantVerified===true&&p.pendingOrders===0;}
module.exports={plan,activate,mayClose};
