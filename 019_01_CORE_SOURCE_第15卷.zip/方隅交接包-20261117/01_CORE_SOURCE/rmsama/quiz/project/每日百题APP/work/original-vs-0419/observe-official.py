import control as c
import sys,time,json,datetime
sys.stdout.reconfigure(encoding='utf-8')
r=c.R/'original-only-rounds'/sys.argv[1]
label=sys.argv[2]
delay=float(sys.argv[3]) if len(sys.argv)>3 else 0
time.sleep(min(delay,45))
raw=c.adb('exec-out','run-as','com.jimusoft.railwaymp.canvas419','cat','files/events.jsonl')
(r/(label+'-events.jsonl')).write_bytes(raw)
rows=[json.loads(s) for s in raw.splitlines()]
at=max((i for i,row in enumerate(rows) if row['evt']=='start'),default=0)
rows=rows[at:]
done=[row['data'] for row in rows if row['evt']=='confirm']
status={'observedAt':datetime.datetime.now().astimezone().isoformat(timespec='seconds'),'confirmed':len(done),
    'correct':sum(q['correct'] for q in done),'wrong':sum(not q['correct'] for q in done),
    'lastEvent':rows[-1]['evt'] if rows else None,'hostResultPresent':any(x['evt']=='result' for x in rows),
    'softwareStatus':'See screenshot; release APK has no debug phase log','manualAnswersInjected':False}
(r/(label+'.png')).write_bytes(c.adb('exec-out','screencap','-p'))
(r/(label+'.json')).write_text(json.dumps(status,ensure_ascii=False,indent=2),encoding='utf-8')
(r/'current-progress.json').write_text(json.dumps(status,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(status,ensure_ascii=False))
