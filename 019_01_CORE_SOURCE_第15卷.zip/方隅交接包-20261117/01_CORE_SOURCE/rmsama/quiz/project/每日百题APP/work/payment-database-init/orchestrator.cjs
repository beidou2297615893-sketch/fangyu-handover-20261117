'use strict';
const FN='dailyHundredBillingInitV1',ENV='fh6-d5ga45c0ddae7008c',REGION='ap-shanghai';
const NAMES=Object.freeze(['daily_hundred_payment_v1','daily_hundred_installation_v1']);
const fail=()=>{throw Error('initialization stopped; inspect resources read-only; do not retry or delete');};
const check=x=>{if(!x)fail()};
const compact=x=>JSON.stringify(x);
function normalizeFunctions(list){check(Array.isArray(list)&&list.length<100);return list.filter(x=>x.name!==FN).map(x=>({functionId:x.functionId,name:x.name,runtime:x.runtime,modifyTime:x.modifyTime,status:x.status})).sort((a,b)=>String(a.name).localeCompare(String(b.name)));}
function normalizeRoutes(list){check(Array.isArray(list)&&list.length<100);return list.map(x=>({domain:x.domain,path:x.path,upstreamResourceName:x.upstreamResourceName,upstreamResourceType:x.upstreamResourceType,enable:x.enable,enableAuth:x.enableAuth,enablePathTransmission:x.enablePathTransmission})).sort((a,b)=>compact(a).localeCompare(compact(b)));}
async function run(adapter){
  check(adapter&&['call','mark','createFunction'].every(k=>typeof adapter[k]==='function'));
  const call=async(...args)=>{const v=await adapter.call(args);check(v!==undefined&&v!==null);return v};
  const tableQuery=()=>({EnvId:ENV,MgoLimit:10,MgoOffset:0,TableNames:NAMES});
  const tables=async()=>{const t=await call('api','tcb','DescribeTables','-r',REGION,'--api-version','2018-06-08','--body',compact(tableQuery()));
    check(t.Pager&&Number.isSafeInteger(t.Pager.Total)&&t.Pager.Total>=0&&Array.isArray(t.Tables)&&t.Tables.length===t.Pager.Total&&t.Tables.length<10);
    check(t.Tables.every(x=>typeof x.TableName==='string'));return t.Tables;};
  const functions=async()=>await call('fn','list','-e',ENV,'--limit','100');
  const routes=async()=>await call('routes','list','-e',ENV,'--limit','100');
  const beforeF=await functions(),beforeR=await routes(),beforeTables=await tables();
  check(Array.isArray(beforeF)&&!beforeF.some(x=>x.name===FN));
  check(Array.isArray(beforeR)&&!beforeR.some(x=>x.upstreamResourceName===FN));
  check(!beforeTables.some(x=>NAMES.includes(x.TableName)));
  const oldF=compact(normalizeFunctions(beforeF)),oldR=compact(normalizeRoutes(beforeR));
  // One durable marker before any write. Unknown outcome must never auto-retry.
  await adapter.mark();
  for(const name of NAMES){
    const payload={EnvId:ENV,TableName:name,PermissionInfo:{AclTag:'ADMINONLY',EnvId:ENV}};
    const created=await call('api','tcb','CreateTable','-r',REGION,'--api-version','2018-06-08','--body',compact(payload));
    check(typeof created.RequestId==='string'&&created.RequestId.length>0);
    const p=await call('permission','get','collection:'+name,'-e',ENV);
    check(Array.isArray(p.PermissionList));const matches=p.PermissionList.filter(x=>x.Resource===name);check(matches.length===1&&matches[0].Permission==='ADMINONLY');
  }
  const current=await tables();check(NAMES.every(name=>current.filter(x=>x.TableName===name).length===1));
  // CreateFunction is create-only: unlike a general deploy command it cannot
  // update a function created by another operator after the name check.
  const deployed=await adapter.createFunction();check(deployed&&typeof deployed.RequestId==='string'&&deployed.RequestId.length>0);
  const body=compact({FunctionName:FN,Namespace:ENV}),trig=compact({FunctionName:FN,Namespace:ENV,Limit:30,Offset:0});
  const detail=await call('api','scf','GetFunction','-r',REGION,'--api-version','2018-04-16','--body',body);
  check(detail.FunctionName===FN&&detail.Namespace===ENV&&detail.Type==='Event'&&detail.Runtime==='Nodejs20.19'&&detail.Handler==='index.main'&&detail.Status==='Active'&&detail.Role==='TCB_QcsRole');
  check(detail.Environment&&(!detail.Environment.Variables||Array.isArray(detail.Environment.Variables)&&detail.Environment.Variables.length===0));
  const triggers=await call('api','scf','ListTriggers','-r',REGION,'--api-version','2018-04-16','--body',trig);check(triggers.TotalCount===0);
  check(compact(normalizeFunctions(await functions()))===oldF&&compact(normalizeRoutes(await routes()))===oldR);
  const invoke=async action=>{
    const r=await call('fn','invoke',FN,'-e',ENV,'-d',compact({action}));check(r.functionType==='Event'&&r.InvokeResult===0&&typeof r.RetMsg==='string');
    let result;try{result=JSON.parse(r.RetMsg)}catch{fail()};check(result.initialized===true&&result.paymentEnabled===false&&Object.keys(result).sort().join(',')==='initialized,paymentEnabled');
  };
  await invoke('initialize-disabled-policy');await invoke('verify-disabled-policy');
  check(compact(normalizeFunctions(await functions()))===oldF&&compact(normalizeRoutes(await routes()))===oldR);
  return {initialized:true,paymentEnabled:false,collections:NAMES,oldFunctionAndRouteMetadataUnchanged:true};
}
module.exports={run,FN,ENV,NAMES};
