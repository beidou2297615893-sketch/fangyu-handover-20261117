import control as c
import subprocess,json,time,hashlib
from pathlib import Path
sysout=__import__('sys');sysout.stdout.reconfigure(encoding='utf-8')
feedback=len(sysout.argv)>1 and sysout.argv[1]=='feedback'
host='com.jimusoft.railwaymp.canvas419';pkg='com.jimusoft.dailyhundredapp.audit419.dev'
out=c.R/('railway-feedback-corpus' if feedback else 'railway-corpus');out.mkdir(exist_ok=True)
c.adb('shell','am','force-stop',pkg)
c.adb('shell','am','start','-n',host+'/com.jimusoft.railwaymp.MainActivity');time.sleep(1)
pid=c.adb('shell','pidof',host).decode().strip();c.adb('forward','tcp:18786','localabstract:webview_devtools_remote_'+pid)
def js(source):
    file=out/'render-command.js';file.write_text(source,encoding='utf-8')
    return json.loads(subprocess.check_output(['node',str(c.R/'cdp.cjs'),'18786',str(file)],timeout=15))
app=c.R.parent/'railway-mp-replica/app/src/main/assets/web/app.js'
source=app.read_text(encoding='utf-8');needle='\nshow();\n})();'
assert source.count(needle)==1
exposed=source.replace(needle,'\nwindow.__comparisonPage=()=>quizPage;\nshow();\n})();')
metadata=js('(()=>{eval('+json.dumps(exposed)+');document.querySelector(\'[data-tab="my"]\').click();document.getElementById("random-quiz-entry").click();document.getElementById("start-button").click();window.__comparisonState=__comparisonPage()._quiz.snapshot();return __comparisonState.questions.map(q=>({id:q.id,answerIndices:q.correctOptionIds.map(id=>q.options.findIndex(o=>o.id===id))}));})()')
proof=json.loads((c.R/'hidden-host-proof.json').read_text(encoding='utf-8'))
assert [m['id'] for m in metadata]==proof['questionOrder']
frames=[];started=time.monotonic()
for i,meta in enumerate(metadata):
    grading="s.answered=true;s.correct=true;s.answerIds=s.questions[INDEX].correctOptionIds;s.selectedIds=s.answerIds;s.answeredCount=INDEX+1;s.score=INDEX+1;" if feedback else ''
    scroll="window.scrollTo(0,document.documentElement.scrollHeight);" if feedback else ''
    result=js('''(async()=>{const s=__comparisonState;s.index=INDEX;s.answered=false;s.correct=false;s.selectedIds=[];s.answerIds=[];s.answeredCount=INDEX;s.phase='question';GRADING const p=__comparisonPage();p._quiz.snapshot=()=>s;p.render();window.scrollTo(0,0);SCROLL await new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r)));await new Promise(r=>setTimeout(r,120));return {progress:document.getElementById('question-progress').innerText,scrollHeight:document.documentElement.scrollHeight,viewport:innerHeight};})()'''.replace('GRADING',grading).replace('SCROLL',scroll).replace('INDEX',str(i)))
    file=f'{i:03d}.png';png=c.adb('exec-out','screencap','-p');(out/file).write_bytes(png)
    frames.append(dict(file=file,questionNo=i+1,**meta,**result,sha256=hashlib.sha256(png).hexdigest(),**({'expectedPageKind':'graded'} if feedback else {})))
    if (i+1)%10==0:print(json.dumps({'captured':i+1,'total':100,'elapsedSeconds':round(time.monotonic()-started,1)}),flush=True)
if feedback:
    for name,no,kind,setup in [('wrong-053',53,'graded',"s.phase='question';s.answered=true;s.correct=false;s.answerIds=q.correctOptionIds;s.selectedIds=[q.options.find(o=>!s.answerIds.includes(o.id)).id];s.score=52;s.wrong=1;s.answeredCount=53;"),
        ('result-100',100,'result',"s.phase='result';s.answered=true;s.correct=true;s.score=100;s.wrong=0;s.answeredCount=100;")]:
        js("(async()=>{const s=__comparisonState;s.index="+str(no-1)+";const q=s.questions[s.index];"+setup+"__comparisonPage().render();window.scrollTo(0,0);await new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r)));return true;})()")
        png=c.adb('exec-out','screencap','-p');file=name+'.png';(out/file).write_bytes(png)
        frames.append({'file':file,'questionNo':no,'expectedPageKind':kind,'sha256':hashlib.sha256(png).hexdigest()})
(out/'manifest.json').write_text(json.dumps({'frames':frames,'diagnosticOnly':True,'naturalRound':False,
    'originalRendererUsed':True,'questionOrderUnchanged':True,'renderOnlyStateOverride':True,
    'appSourceSha256':hashlib.sha256(source.encode()).hexdigest()},ensure_ascii=False,indent=2),encoding='utf-8')
js('(()=>{location.reload();return {restoredOriginalPage:true};})()')
print('Captured 100 original-renderer screenshots; this is diagnosis, not an answering score.',flush=True)
