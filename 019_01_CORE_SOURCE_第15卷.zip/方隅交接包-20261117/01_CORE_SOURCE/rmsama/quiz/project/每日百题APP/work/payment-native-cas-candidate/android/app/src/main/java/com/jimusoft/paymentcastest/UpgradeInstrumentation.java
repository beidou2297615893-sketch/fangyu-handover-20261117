package com.jimusoft.paymentcastest;
import android.app.Instrumentation;
import android.content.Context;
import android.os.Bundle;
import org.json.JSONObject;

/** Dedicated debug-package-only upgrade fixture. Values are synthetic, never a real wallet. */
public final class UpgradeInstrumentation extends Instrumentation {
 private Bundle args;private int checks=0;
 private void check(boolean ok,String what){checks++;if(!ok)throw new AssertionError(what);}
 @Override public void onCreate(Bundle b){super.onCreate(b);args=b;start();}
 @Override public void onStart(){Bundle result=new Bundle();try{
  Context ctx=getTargetContext();check(android.os.Build.HARDWARE.contains("ranchu"),"emulator only");
  check(ctx.getPackageName().equals("com.jimusoft.paymentcastest.migrationdebug"),"dedicated debug test package only");
  String name=args.getString("case"),mode=args.getString("mode");check(name!=null&&name.matches("case-[0-9a-f-]{36}"),"unique test case");
  CandidateStore store=new CandidateStore(ctx,name);
  String identity="{\"installationId\":\"synthetic-owner\",\"accessToken\":\""+"a".repeat(43)+"\",\"purchaseIntent\":{\"planId\":\"once\",\"clientRequestId\":\"request-123\"},\"future\":\"keep\"}";
  String pending="[{\"id\":\"synthetic-order\",\"planId\":\"once\",\"amountFen\":100,\"clientRequestId\":\"request-123\"}]";
  String registration="{\"requestId\":\""+"r".repeat(43)+"\",\"verifier\":\""+"v".repeat(43)+"\"}";
  long version=ctx.getPackageManager().getPackageInfo(ctx.getPackageName(),0).getLongVersionCode();
  if("seed".equals(mode)){
    check(version==1,"seed is test version 1");check(store.read()==null&&store.readSyntheticLegacy("identity")==null&&store.readSyntheticLegacy("pending")==null&&store.readSyntheticLegacy("registration")==null,"fixture never overwrites old records");
    store.writeSyntheticLegacy("identity",identity);store.writeSyntheticLegacy("pending",pending);store.writeSyntheticLegacy("registration",registration);
    check(store.readSyntheticLegacy("identity").equals(identity)&&store.readSyntheticLegacy("pending").equals(pending),"old encrypted values verified before upgrade");
  } else if("verify".equals(mode)){
    check(version==2,"verify is updated test version 2");check(store.read()==null,"old installation had no migrated record");
    check(store.readSyntheticLegacy("identity").equals(identity)&&store.readSyntheticLegacy("pending").equals(pending)&&store.readSyntheticLegacy("registration").equals(registration),"same key decrypts old test records after replacement");
    JSONObject record=store.migrateSyntheticLegacy(false),v=record.getJSONObject("value"),i=v.getJSONObject("identity");
    check(record.getLong("version")==0&&i.getString("future").equals("keep")&&i.getJSONObject("purchaseIntent").getString("clientRequestId").equals("request-123"),"identity and pending intent preserved");
    check(v.getJSONArray("pending").getJSONObject(0).getInt("amountFen")==100&&v.getJSONObject("registration").getString("requestId").equals("r".repeat(43)),"order and registration preserved");
    check(store.readSyntheticLegacy("identity").equals(identity)&&store.readSyntheticLegacy("pending").equals(pending),"legacy values remain readable");
  } else throw new IllegalArgumentException("unknown mode");
  result.putString("status","passed");
 }catch(Throwable e){result.putString("status","failed");result.putString("error",String.valueOf(e));}
 finally{result.putInt("checks",checks);finish("passed".equals(result.getString("status"))?-1:0,result);}}
}
