# Phase23 公司原准备登记入口独立 UI 审查

结论：当前新增四组独立代表全部通过，未发现需阻断本轮归档的 UI 缺陷。原准备页默认仅新增显式入口；进入后先读原登记状态，本人未勾选时零登记，明确确认才按原 origin/revision 单次调用。已有 unknown 或 recorded 只核对原号，不能再次登记。历史公司草稿与当前授权、资源部交付、平台送达及财务证据分别显示。

本次只新增本报告、新 test、新日志和哈希清单，未编辑生产源码、原 27 组测试或旧冻结证据；未读取原 DATA、凭证、Cookie，未执行真实网络、公司提交、平台、模型或 GUI。

## 实际对象与验证范围

- 生产 `upgrade-operations-ui.mjs` 的真实导出 checker 与 `createUpgradeOperations` controller，在 VM 中装载；注册相关控制逻辑未镜像重写。其余独立子 UI 的初始化使用 idle adapter。DOM 为轻量模型，不是完整浏览器环境。
- 生产 `app.mjs` 的 `PRODUCT_ACTIONS` 与 `execute` 实际函数片段，核本机 `product_action` 路由和 cloud-only 前置阻断；通用 submit 设为禁止，不能以 stub 替代路由判断。
- B 的 `company-handoff-registration-actual-fixture.json` 原样用于六个 public DTO 及各 case 对应的真实准备 GET。生成来源为实际临时 Core 和 createService/createStore 的 SDK 接口内存 callback adapter；这里没有重跑后端，也不把该 adapter 当成部署后的 SDK 事务引擎。`attempt_unknown` 的超时为夹具明确标注的受控 transport；UI 错误及晚返回时间亦由本独测控制。

## 新增四组及结果

1. 六个实际 36 字段 DTO 接受；原 channel/origin 不符、当前可用版本不符、私有正文/hash 额外字段、伪造平台/来源/财务/后续提交资格、矛盾 dispatch 标记均拒绝。丢响应后 `state=recorded` 配 `attempt.state=unknown` 与 `registration_source_verified=false` 合法，不能补造完整来源证明。
2. 打开仅读准备 GET，显式“登记或核对公司草稿”再读登记 GET。复选框默认未勾选、确认按钮禁用且零 write；勾选后双击仅一次 `company_handoff_register`，数据精确为 `handoff_id/expected_origin_id/expected_handoff_revision`。成功仅显示公司草稿和登记来源摘要对应，后续资源部交付未执行。
3. 即使 transport 错误带 `mutation_committed=false`，当前 UI 也保守持有，只显示原号核对。新鲜 GET 返回 not_attempted 后只是重新出现未勾选的确认，不自动写入。实际 unknown、提交丢响应后 recorded/source=false、历史登记但当前撤回，重开和再次核对均无 register；原准备与旧 unknown 浏览器槽不删除、不改写。
4. 读取晚回、点击前变化、写入晚回三个边界中，actor、role、actor.company_id、配置 company/environment、device/generation、外部 accept、reset 变化均不产生新登记或晚成功显示。已开始的 write 不假称取消，计数仍最多一次。实际 app 两新动作在 localWorkspace=true 走 product_action；false/undefined 均在网络/command submit 前拒绝。

运行命令：`node --test work/product-upgrade-20261009/audits/phase23-company-registration-ui-independent.test.cjs`。

首次运行 **4/4，0 failed，122.9327ms**。没有本独测产品 RED；准备 GET 缺失时先请 B 补实际投影，没有改 read_only 标记伪造 GET，也没有在缺夹具时运行 controller 测试。哈希读取与清单整理遇到两次 PowerShell 元数据命令错误，修正后仅重新读取哈希、整理新清单，未触及源码或测试；不作为产品失败证据。

## 本次已执行源码

|对象|SHA256，前后相同|
|---|---|
|`work/app/src/web/workspace/upgrade-operations-ui.mjs`|`139374E9095481B77E073ECCF0DC8CEB62A9E6C04A13DBE3797D717942228CB9`|
|`work/app/src/web/workspace/app.mjs`|`F47F89CA34284C8AC10FD8568A8ED31580BE9912B6BF727F9F3EE825744F9115`|
|`audits/company-handoff-registration-actual-fixture.json`|`BDEAC6F0B9261AD2C16E9B1DD2D0EE19D6C170C7867084090F05638438114807`|
|新增独测|`8188D295BDD6148738F1B6925B0951783E2CDFFC428C9F3505BF4D8A80FB1205`|

关键生产定位：`checkedCompanyRegistration` 78–104，准备页完整范围门禁 454–457，登记确认 543–575，原号 GET 602–608；app 新动作注册 386、local-only 前置阻断 394–395、本机路由 397–402。字段和边界以后如变更，须按新源另记验证，不能借本报告覆盖。

本证据只证明上述独立代表；root 的旧矩阵、后端与实际 GUI 单独归属其报告。没有证明真实公司写入、跨机送达、资源部独立接收、联系方式交付、平台事实、成交或收款。未新增测试去替代这些未验事项。

报告：`C:/积木软件工坊/项目/方隅公寓客户版/work/product-upgrade-20261009/audits/phase23-company-registration-ui-independent-review.md`

文件夹：`C:/积木软件工坊/项目/方隅公寓客户版/work/product-upgrade-20261009/audits`
