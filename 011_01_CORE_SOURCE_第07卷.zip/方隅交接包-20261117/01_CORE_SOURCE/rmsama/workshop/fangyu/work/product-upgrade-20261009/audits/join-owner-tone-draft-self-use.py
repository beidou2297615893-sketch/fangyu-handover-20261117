"""Root: back up and join the independently reviewed Source42 frontend slice."""
import hashlib
import json
from pathlib import Path
import stat
import uuid

PROJECT = Path('C:/积木软件工坊/项目/方隅公寓客户版')
STAGE = PROJECT / 'work/product-upgrade-20261009'
SOURCE = PROJECT / 'work/app/src'
CANDIDATE = STAGE / 'owner-tone-draft-self-use-candidate'
REVIEW = STAGE / 'owner-tone-draft-self-use-review/REVIEW.md'
RECEIPT = STAGE / 'audits/owner-tone-draft-self-use-joined.json'
FROZEN_SHA = 'C16A9BB95F23BDA3B65FC43FC22CB1FA544BB6EABDAD9C7276C132E5BE677B79'
REVIEW_SHA = '66FD2C5B6360EAC5E63BE86E501BECD48715B38F4D00D8DF8A0355842BF51890'

def blob(path):
    path.relative_to(PROJECT)
    current = PROJECT
    for part in path.relative_to(PROJECT).parts:
        current = current / part
        info = current.lstat()
        if current.is_symlink() or getattr(info, 'st_file_attributes', 0) & 0x400:
            raise ValueError('reparse path changed')
    if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1:
        raise ValueError('file kind changed')
    return path.read_bytes()

def pin(value):
    return {'bytes': len(value), 'sha256': hashlib.sha256(value).hexdigest().upper()}

def expected(path, digest, size=None):
    value = blob(path)
    proof = pin(value)
    if proof['sha256'] != digest or size is not None and proof['bytes'] != size:
        raise ValueError('pinned file changed: ' + str(path))
    return value

if RECEIPT.exists():
    raise ValueError('existing join receipt preserved')
manifest_bytes = expected(CANDIDATE / 'FROZEN.json', FROZEN_SHA, 3433)
manifest = json.loads(manifest_bytes)
for item in manifest['items']:
    relative = Path(item['path'])
    if relative.is_absolute() or '..' in relative.parts:
        raise ValueError('manifest path changed')
    expected(CANDIDATE / relative, item['sha256'], item['bytes'])
expected(REVIEW, REVIEW_SHA, 3983)

previous = json.loads(blob(STAGE / 'audits/normal-self-use-clarity-joined.json'))
protected = dict(previous['protected_unchanged'])
protected['web/workspace/upgrade-model.mjs'] = {
    'bytes': 12266, 'sha256': '4CAE160CFDF1E5F8D9B84B990B8A4D1199332123871D9EFADCEBB75791585E68'}
for relative, proof in protected.items():
    expected(SOURCE / relative, proof['sha256'], proof.get('bytes'))

specs = [
    ('web/workspace/self-operating-read.mjs', SOURCE / 'web/workspace/self-operating-read.mjs',
     '00E7865951866B35F2D0585B468B87AE281294F85D7938C73C10905FE3ACF19E', 320644,
     '1236C1240F6CB0060CD092874C778EFF087B88279DD38C56797B2D427AAA2197', 326997),
    ('web/workspace/upgrade-ui.css', SOURCE / 'web/workspace/upgrade-ui.css',
     '2C0B912C0E8B2C3ED48E30DDC5363F0F875AC6ED4CBB8A793EB0143B1CE14162', 92220,
     '9EB963CF2067885906FEF60B05ED7857C3E31537AE58246EFC04078661E01F0B', 92986),
    ('web/workspace/upgrade-ui.css', PROJECT / 'work/cloud/workspace/site/upgrade-ui.css',
     '2C0B912C0E8B2C3ED48E30DDC5363F0F875AC6ED4CBB8A793EB0143B1CE14162', 92220,
     '9EB963CF2067885906FEF60B05ED7857C3E31537AE58246EFC04078661E01F0B', 92986),
]
rows = []
for name, target, parent_sha, parent_size, final_sha, final_size in specs:
    before = expected(target, parent_sha, parent_size)
    after = expected(CANDIDATE / 'src' / name, final_sha, final_size)
    rows.append({'name': name, 'target': target, 'before': before, 'after': after})
backup = PROJECT / 'backups/owner-tone-draft-self-use' / uuid.uuid4().hex
backup.mkdir(parents=True)
for index, row in enumerate(rows):
    row['backup'] = backup / (str(index) + '.bin')
    row['backup'].write_bytes(row['before'])
    if blob(row['target']) != row['before']:
        raise ValueError('target changed before join')
written = []
try:
    for row in rows:
        if blob(row['target']) != row['before']:
            raise ValueError('target changed during join')
        written.append(row)
        row['target'].write_bytes(row['after'])
        if blob(row['target']) != row['after']:
            raise ValueError('joined target readback mismatch')
    for relative, proof in protected.items():
        expected(SOURCE / relative, proof['sha256'], proof.get('bytes'))
except Exception:
    for row in reversed(written):
        row['target'].write_bytes(row['before'])
    raise
receipt = {
    'schema': 'owner_manual_tone_draft_join', 'source_batch': 42,
    'frozen_sha256': FROZEN_SHA, 'review_sha256': REVIEW_SHA,
    'targets': [{
        'name': row['name'], 'target': str(row['target']), 'backup': str(row['backup']),
        'parent': pin(row['before']), 'candidate': pin(row['after'])} for row in rows],
    'logical_targets': 2, 'protected_unchanged': protected,
    'draft_persistence': False, 'new_backend_action': False,
    'actual_App_verified': False, 'actual_Clipboard_verified': False,
    'old_main_interrupted': False, 'customer_database_opened': False,
    'platform_or_model_called': False,
}
RECEIPT.write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'source_batch': 42, 'physical_targets': len(rows),
                  'protected_unchanged': len(protected), 'actual_App_verified': False}))
