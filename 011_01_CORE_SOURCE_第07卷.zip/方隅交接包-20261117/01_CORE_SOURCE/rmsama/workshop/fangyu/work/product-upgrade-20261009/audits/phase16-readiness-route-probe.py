"""One synthetic actual-Core route-selection probe; no production changes.

This is not a live account test or a new preflight implementation.
"""
from contextlib import contextmanager
import hashlib
import json
from pathlib import Path
import sys
import tempfile
import time
from unittest import mock

PROJECT = Path(__file__).resolve().parents[3]
APP = PROJECT / 'work' / 'app'
sys.path.insert(0, str(APP / 'src'))
from core import Core
from core.account_safety import summarize_activity
from core.adapters import AdapterSafetyRequired
from core.platform_reads import PlatformReadService
from assistant.acquisition_strategy import AcquisitionStrategy


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    temp_root = PROJECT / 'work' / 'product-upgrade-20261009' / 'tmp' / 'phase16-route-probe'
    temp_root.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(dir=temp_root) as folder:
        base = Path(folder)
        resources = base / 'resources'
        (resources / 'adapters').mkdir(parents=True)
        manifest = {'id': 'xiaohongshu', 'executable': sys.executable,
                    'mapper': 'xhs_v1', 'isolation_guard': True,
                    'search_verified': True, 'capabilities': ['search', 'comments'],
                    'search_args': ['search', '{keyword}', '--json'],
                    'license_reviewed': True, 'real_verified': False}
        (resources / 'adapters' / 'xiaohongshu.json').write_text(
            json.dumps(manifest), encoding='utf-8')
        core = Core(base / 'db', resources)
        try:
            user = core.handle('bootstrap', {'username': 'phase16-owner',
                                             'password': '[REDACTED:assigned_secret]'})['user']
            tenant = user['tenant_id']
            account = {'id': 'phase16-account', 'tenant_id': tenant,
                       'cloud_owner': user['username'], 'name': '合成账号',
                       'platform': 'xiaohongshu', 'status': 'ready',
                       'platform_uid': 'synthetic-platform-uid'}
            core.store.put('accounts', account)
            account_dir = core.store.directory / 'accounts' / tenant / account['id']
            account_dir.mkdir(parents=True)
            marker = account_dir / 'synthetic-preserve-marker.txt'
            marker.write_text('synthetic only; never an actual cookie', encoding='utf-8')
            before_marker = digest(marker)
            epoch = time.time()
            activity = account_dir / 'platform-activity.jsonl'
            events = [
                {'at': epoch - 2, 'stage': 'started', 'kind': 'search', 'request_id': 'fixture-read'},
                {'at': epoch - 1, 'stage': 'finished', 'kind': 'search',
                 'request_id': 'fixture-read', 'status': 461},
            ]
            activity.write_text(''.join(json.dumps(row) + '\n' for row in events), encoding='utf-8')
            before_activity = digest(activity)
            with core.store.connect() as db:
                before_dump = '\n'.join(db.iterdump())
            statements = []
            original_connect = core.store.connect

            @contextmanager
            def trace_connect():
                with original_connect() as db:
                    db.set_trace_callback(statements.append)
                    yield db

            service = PlatformReadService(core, tenant, user['username'],
                                          license_policy={'xiaohongshu': True})
            strategy = AcquisitionStrategy(core, tenant, user['username'], core.deployment_config)
            with mock.patch.object(core.store, 'connect', trace_connect), \
                 mock.patch('core.adapters.subprocess.Popen', side_effect=AssertionError('no process')) as spawn, \
                 mock.patch('socket.socket.connect', side_effect=AssertionError('no network')) as connect:
                status = service.execute('platform_read_status', {'account_id': account['id']}, user)
                catalogue = strategy.execute('capability_catalog', {}, user)
                strategy_summary = strategy.execute('strategy_get', {}, user)
                safety = summarize_activity(activity)
                try:
                    core.adapters.require_account_safe('xiaohongshu', account_dir)
                except AdapterSafetyRequired:
                    actual_adapter_guard_blocked = True
                else:
                    actual_adapter_guard_blocked = False
                mode = core.account_mode_status(account['id'], tenant)
                spawn.assert_not_called()
                connect.assert_not_called()

            with core.store.connect() as db:
                after_dump = '\n'.join(db.iterdump())
            writes = [sql for sql in statements if sql.lstrip().split(' ', 1)[0].upper()
                      in {'INSERT', 'UPDATE', 'DELETE', 'REPLACE', 'CREATE', 'DROP', 'ALTER'}]
            assert status['read_availability']['search'] == 'ready_for_guarded_read'
            assert status['live_checked'] is False and status['real_platform_verified'] is False
            assert safety['state'] == 'review_required' and actual_adapter_guard_blocked
            assert safety['suggested_trial_gap_seconds'] is None
            assert mode['status'] == 'idle'
            assert not writes and before_dump == after_dump
            assert before_marker == digest(marker) and before_activity == digest(activity)
            xhs = next(row for row in catalogue['items'] if row['id'] == 'xiaohongshu')
            result = {
                'evidence': 'actual_Core_and_existing_methods_synthetic_local_only',
                'representative_passed': True,
                'stored_search_availability': status['read_availability']['search'],
                'actual_account_risk_state': safety['state'],
                'actual_adapter_guard_blocked': actual_adapter_guard_blocked,
                'safe_interval_seconds': None,
                'catalogue_operational': xhs['operational'],
                'catalogue_real_verified': xhs['real_verified'],
                'strategy_unit': strategy_summary['quota_unit'],
                'strategy_scheduler_only': strategy_summary['scheduler_only'],
                'sqlite_mutation_statements': len(writes),
                'sqlite_dump_unchanged': before_dump == after_dump,
                'synthetic_activity_and_marker_unchanged': True,
                'platform_requests': 0, 'provider_requests': 0, 'cloud_requests': 0,
                'actual_cookie_reads': 0, 'process_spawns': 0,
                'production_source_sha256': {name: digest(APP / 'src' / name) for name in (
                    'core/platform_reads.py', 'core/account_safety.py', 'core/adapters.py',
                    'core/platform_capabilities.py', 'assistant/acquisition_strategy.py')},
            }
            print(json.dumps(result, ensure_ascii=False, indent=2))
        finally:
            core.close_continuous_scheduler(wait=True)
            core.adapters.close()


if __name__ == '__main__':
    main()
