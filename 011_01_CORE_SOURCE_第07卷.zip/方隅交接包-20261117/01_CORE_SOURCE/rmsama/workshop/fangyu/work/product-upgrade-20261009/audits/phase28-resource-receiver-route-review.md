# Phase28 资源部接收端：只读路线审查

## 结论与范围

最高收益下一切片是“真实获授权资源主体的公司收件箱 → 当前详情 → 一次明确接单 → 丢回执按该接收主体原号核对”。公司 list/detail/receipt 和本机接收表单已存在，缺的是公司接收端客户端桥；不要再建 CRM、加密算法或许可审批层。先复用平台引用交接闭环，跨机器手机号/微信安全交付作为独立后续工程，不能混为已完成。

本轮仅阅读当前源码、需求台账和既有 Phase27 事实；没有运行测试、Core/Service、原 DATA、账号/网络、外发或部署，没有修改生产或历史冻结材料。依用户规则匹配并实际读取 RevOps skill，仅采用阶段定义、明确负责人及每次交接可核对原则；其通用 SLA/行业转化基准不作为本项目事实或新增强制门槛。未发现现有 product-marketing context 文件；既有用户目标足够，不阻断研究。

## 已有成熟能力与实际断点

| 现能力 | 实际文件/函数 | 可复用与边界 |
|---|---|---|
| 公司按接收部门列渠道 | `work/cloud/workspace/handoff-ledger.cjs:233` read；received 分支 238；索引 244–250 | trusted acquisitionPolicy.receivers[actor.username] 校验，recipient 索引读取；每页 1–25。索引包含注册起所有状态，total 是渠道条数，不是待接单人数或高意向客户数。 |
| 当前公司详情 | 同文件 detailRead 252–262 / readBoundItem 389 | 当前 item/latest event selfhash 与同意 tombstone，双读和末 session/policy/visible 核对；可以跨 source owner 读取，但必须当前接收/管理权限。 |
| 接收决策与 CAS | 同文件 mutate 185–196、handle 334–371 | accept/reject/needs_information/duplicate/existing_customer；expected_revision、原 actor/action/key/payload hash；source owner 禁自 ACK。receipt 记录 authenticated=true、evidence_independently_verified=false。 |
| 原公司操作回执 | 同文件 operationStatus 264–332 | 原 session actor + 原 action/key，recorded/unknown；缺失不是未执行。历史 revision/selfhash 与当前状态分离，full_historical_chain_verified=false；过期商业权益不应阻止原记录核对。 |
| 本机 receiver 权限和表单 | `assistant/acquisition_operations.py:145/184/443/500`；`upgrade-operations-ui.mjs:510–516` | 本机 tenant 记录支持 receiver/manager 跨 source owner 授权，来源人禁自接收；按钮明确“登记本机接收决定”，动作 handoff_receipt 写本机 ledger。它不是公司 acquisition_handoff_receipt，更不是另一机器接单。 |
| 公司提交方客户端 | `company_handoff_submission.py:46/243`；`app.mjs:382–395`、`product_workspace.py:34/182/211` | 本人 owned 本机 handoff/origin → 公司 submit；GET 已显示历史接收，但没有公司 received-list/detail/明确 ACK 新桥。接收主体没有提交方本机 lead/origin，不可强行套该 helper 或要求持有提交方 task。 |

成熟云授权是 session 找到的当前 admin/operator 加 trusted receivers 映射，不需要发明“resource”新 role。admin/manager 可查看、处理审查，不因管理员身份自动有接收权限；即使来源账号也被配置为 receiver，owner 禁自 ACK 仍必须保留。客户端 owner/role/recipient 声称不能赋权，不能拷贝 source 本机库来满足接收方权限。

## 进入客户端前必须代表性核对的现存窄风险

1. **list 尚不是同一纯读等级。** `service.cjs:57–82/178` 当前 readonlyPureQuery 只包含 operation_status/source_binding/detail，list 会走一般 session/attempt housekeeping 的 state 回写；空公司也没有 list 的明确只读缺库分支。不能把现 list 直接包装为零写 GET。最小修沿现 pureQuery/stored 返回方式扩 list，实际 createService/store 用 expired-session/missing-company 代表证明不初始化、不清理。
2. **list 末权限核对不等同 detail。** `handoff-ledger.cjs:233–250/357` 列表只用入口 actor/receives，没有 detailRead 的双读与末 session/receivers/policy fence。新增桥首尾本机 guard 不能弥补服务端异步读取期间 mapping/session 变化；在实际 SDK 接口 fixture 最后 await 修改 mapping/禁用，先证真风险再窄补。
3. **receipt 末权限窗口待实证。** `mutate:185–196` 在 authorization await 后仍用入口 actor/mapping；`handle:368–370` 仅 submit 有新增最终 submissionCurrentFence。下一最难代表应在最后同意/current item await 与 staged writes 后撤 receiver、禁用/过期 session或撤回同意，检查0 committed变化。静态证据说明该路径尚无等效末 fence，不宣称本轮已运行 RED；不可只引用旧 CAS 就说当前权限全部重核。
4. **安全投影不能 raw spread。** 云 publicItem:62–75 返回原 item clone，含来源UID/contact reference。新客户端应严格最小投影，默认不显示裸UID、正文或凭证；自由 purpose/name/证据标签若显示须使用已验证的隐私清洗，避免电话号码藏在昵称/零宽字符。不可把 cloud 原 item 原样写第二本本机CRM。

## 最小完整接口候选与产品主流程

建议新接收 helper（暂定 `CompanyHandoffReceiver`）以当前 resource actor/tenant/company/device 为主，不依赖 source owner 的本机 lead/preparation。复用现有 bearer HTTP与 fixed action transports；不自动 refresh/claim/login/verify，不用新密码学。

- `company_handoff_received_list{recipient_id?,offset?,limit?}`：只读公司收件列表；首读需要服务端当前 receivers 派生可选接收范围，不暴露完整 acquisitionPolicy。优先窄扩现 received-list 返回 authorized recipient metadata，或由可信 host 配置预选且云再验证；客户端传 recipient 只是选择，永非授予权限。多部门必须让用户明确选择，不猜默认资源部。默认10，上限应由实际操作预算确定。
- `company_handoff_received_detail{channel_id}`：当前有权公司 item 的安全投影、current revision/consent/permissions 与历史接收事实；没有本机 handoff UUID↔hc_ 的假映射。不暴露源客户手机号/微信，来源核验仍 device_report 非平台权威。
- `company_handoff_receipt{channel_id,expected_revision,decision,reason_code?,evidence_reference}`：详情 fresh 后，默认未勾选确认；服务端派生并持久本次稳定原 key，再单 CAS claim、一次现 acquisition_handoff_receipt。不接 actor/time/verified 等前端字段。证据引用格式不证明有真实附件或独立验真；未有有效证据的情形保持不能确认，不替用户造 UUID 证据。
- `company_handoff_receipt_get{channel_id}`：有 attempt 仅原 actor/key 的 acquisition_handoff_operation_status；unknown/重启/丢响应保持原号，只读不写、不重发。GET 缺本机 attempt 或云 operation doc均不能解释成过去未执行。查看/撤回/原回执核对不因套餐到期阻断；既有实际身份/接收授权仍重验。

页面只加一个清晰“公司收件箱”入口，复用已认可表格/详情/同五种决定组件，不重做导航审美。原“本机交接”仍明确本机状态，原 Phase27 source 只能提交和核对自己的历史；公司 inbox 不使用本机 handoff_receipt。每行状态区分 draft/submitted/accepted/withdrawn 等；总数标“公司渠道”，不能客户端只过滤当前页就声称全公司待接单总量。当前权限不可读、无配置/未映射、没有对应公司源分别为空态/错误，不伪0全部成功。

接收摘要的最小安全字段可含：company-scope binding、authenticated actor、recipient safe label、channel opaque ID、customer opaque cu_ ID（去重依据）、平台、来源员工安全标签/哈希、当前 revision/status/consent/permissions、历史 receipt actor/time/decision、evidence_independently_verified=false、contact_delivery=platform_reference_only、read_only/mutation_committed/observed_at。不要把接收字段作为成交或回款字段；cash/paid仍 null。当前 list/detail 原框架足够，精确 schema 应在实施前锁定，本报告不假称已新增 API。

## 最小工程接入清单（候选，未编辑）

1. `work/cloud/workspace/handoff-ledger.cjs`：复用现 received 索引/detail/mutate/status，只补 list 的安全 scope metadata/末 fence 和实证所需 receipt 最后当前范围复核；不迁移/注册新索引、客户或订单。
2. `work/cloud/workspace/service.cjs`：现 list 纯读例外，保留所有原写动作与固定公司鉴权。
3. 新 `assistant/company_handoff_receiver.py` + 窄 query/receipt transport：严格投影、原号专属 metadata/CAS、一请求与丢失后只读恢复；不覆盖原提交方尝试或 source actor 的 key。
4. `assistant/product_workspace.py`：resource actor 的真实 saved user/device/vault/company 首尾门禁；不要求 source 本机 lead；公司 receipt 不误路由到本机 handoff_receipt 或泛型 receipt。没有当前公司接收映射不能自授 role。
5. `web/workspace/upgrade-operations-ui.mjs` / `app.mjs` 与必要可见入口：复用现组件，加公司 inbox/list/detail/明确接收及原号核对；unknown没有可重复 ACK 按钮，不自动云读取或派发写。

SDK 成本只按实际事务读数证明：现 list 每行至少 item/latest event/consent 三读，25行约75读另加公司/索引与页，若加双核/末 scope 不能继续假定25安全。候选首版10，上限15先测最坏跨索引页和所有 consent，CloudBase每事务100操作/30秒边界沿既有官方核验，内存回放耗时不当真实30秒或吞吐验收。列表顺序/筛选不先引入新全表扫描或迁移。

## 最难代表与商业验收矩阵

| 链路 / 场景 | 技术验收 | 业务解释 |
|---|---|---|
| source 明确 submit；另一已映射 resource 的第二隔离Core（无 source leads/tasks/origin）list/detail | 只有本部门有权公司渠道；纯GET无 committed DML/目录/会话写；读取不用复制原库 | 资源部可从自己的主体发现线索，区别本机待送达 |
| fresh submitted detail → 未勾选 → checked accept | 未勾选0 ACK；明确一次；实际API当前 consent/mapping/revision授权 | “该授权资源账号已登记接受处理这条平台线索” |
| ACK commit 丢响应 → 重启接收 helper → GET | 同 actor 原 key recorded；0第二 receipt；attempt unknown历史不消除 | 可核对本人接单事实，不因网络丢失重复占归属 |
| source/admin source自ACK、未映射operator、跨company/channel、禁用/晚撤 mapping | 403/401或安全拒绝，0 committed事件；staged rollback不能称0尝试DML | 提交人不能自己证明资源部接单，管理员也不自动冒接收方 |
| accept后客户当前withdrawn；同意最后await撤回 | 已有历史接收保留；当前权限false；晚变写回滚，原key保留 | 历史接单不表示现在还能联系或交付 |
| reject / information / duplicate / existing customer | 严格决定/原因/实际证据引用，唯一原key；重复/既有进入核对，非自动分成裁定 | 防截流用来源与接单责任留痕，不保证所有客户都算本人 |
| current item/原event损坏、无operation doc/expired session | 错误或unknown；不猜未执行、不自动新号/续期 | 不用缺证据包装成功或全历史未执行 |

代表测试计划仅3组：①真正 service/store/SDK接口内存adapter 两主体+两隔离Core、ACK commitlost→restart只读；②最迟await mapping/session/consent与跨身份、自ACK边界；③strict DTO/两客户端CAS+当前撤回保历史/最坏读数。先最难一组通过再扩；轻量UI必要3组围绕未勾选、unknown不重发、迟到scope。真实GUI新owned fixture使用最新 Python/cloud启动SHA与served UI，启动0 ACK→显式1→丢回执→reload只读；截图、动作计数、前后SQL/dump和读取预算分证。它仍不是真实云引擎、真实第二实体机或真实公司运营验收。

## 平台UID-only的商业价值与限制

当前公司 register 明确 `handoff-ledger:106–108` 只接受原 `platform:<platform>:<UID>`，联系方式不是 cloud contact vault。它能建立不可变来源关系、公司渠道/客户去重、提交到接收责任人和接收时间、拒收原因、归属争议以及后续同客户订单link核对。授权资源主体可以决定是否接手并在自己的平台账户能力范围人工跟进，但不能从 UID 推断能私信、能联系、客户已回应或能电话成交。

`acquisition_contacts.py:1–4/46–75/150–195` 的现联系方式是本人 owner/lead/recipient/purpose/consent 约束的 Windows CurrentUser DPAPI，本机引用/掩码可读，reveal会审计；`integrations.py:41–54` 用当前Windows数据保护。另一个账号/机器既无这份本机record权限，也不能靠复制加密blob获得公司可用电话/微信。本轮绝不能解密后塞现 register/receipt payload、共用Cookie、复制原DB或写“联系方式已交付”。

所以 inbox/ACK 可先作为本人中介路径的合作操作演示与漏单责任台账，但未完成用户“把微信/手机号推给资源部、真正可跟进”的完整目标。下一独立切片应研究公司服务端受同意目的/接收方授权、密钥治理、撤回、最小访问与审计约束的联系方式交付，并优先复用成熟基础设施；本轮不设计自造密码学、不借UI接单给它开绿。无权威成交/支付回执、合作政策版本时，已核成交/回款/分成字段仍 null。

## 本轮读取来源 SHA（静态依据，非新验收）
- `work/cloud/workspace/handoff-ledger.cjs`：`F1237B200EC04EEFF8C1FFCBEB3BDFD609805F94F5416526543E033F1BCCE65E`
- `work/cloud/workspace/service.cjs`：`32E550BCB4E7CF320EDF1A1534D7E23C9F6EE109843630C0F49B598654C08B2C`
- `work/app/src/assistant/acquisition_operations.py`：`B212C0620D110921BEFBD20B048B54B71DDE1ED87888DD77866BAB7E58C6A97F`
- `work/app/src/assistant/acquisition_contacts.py`：`073D4816D292A8AD2821C22CCCC5FE7BF1FC45BD3C10745908C0704D3D3C222C`
- `work/app/src/assistant/product_workspace.py`：`41A495B8C5A2EF08BCC75450AF4E1B45B2D6452BBEF57E08C704C2562982AADD`
- `work/app/src/assistant/company_handoff_submission.py`：`F305884CC7D128211D9318C19AF96CD27B80EBAD97A03E5A625CAD4206A3F71A`
- `work/app/src/web/workspace/upgrade-operations-ui.mjs`：`F5E05C2006B76F58F06DD9D47FBF3234A42606A620E5F8F1A96DE234C4852A95`
- `work/app/src/web/workspace/app.mjs`：`50DD120BA79785B9101BEF54F015A7359D5B4D23893865BD8583FC7C3E837844`
- `work/app/src/integrations.py`：`A3243435D59567F7BDD8A1886C9455E9276DBB1E71B38033651DDEACC75B36C6`
- `work/cloud/workspace/contact_ledger.cjs`：`16041C470D45E560670C8F1804AA96C5E03169CF91D2F06D67CF6DA18B2C7607`
- `outputs/产品升级/需求交付与证据台账.md`：`2746D588280C87AB578209AA7778FE6C58DB4EB6FDFC07FDBAFF280F87928D99`
- `outputs/产品升级/功能优先阶段进度.md`：`0AFE996889C9A1A2176A2C6C98575DF701CDFCB7803134F3C117DE9FD8066068`
