"""Freeze Phase30 candidate evidence; no environment, secret, network or original DATA access."""
import difflib
import hashlib
import json
from pathlib import Path

PROJECT = Path(__file__).resolve().parents[3]
AUDITS = PROJECT / 'work/product-upgrade-20261009/audits'
BACKUP = PROJECT / 'work/product-upgrade-20261009/backups/phase30-kms-config/1'

def digest(relative):
    return hashlib.sha256((PROJECT / relative).read_bytes()).hexdigest().upper()

protected = {
    'work/cloud/workspace/contact_delivery.cjs': '956E223CDB73BFC191902EC0854C1D521D82CB92820FFFB63A22F9768D60BD71',
    'work/cloud/workspace/kms_contact_provider.cjs': '30A82FF1B4FD02AB33F1E7E91786CB38EF181F1C55BFACF5E8E9F3468828CDF2',
    'work/cloud/workspace/service.cjs': 'FE6E303DB9FA8DBAB07F548B016040438B49799CEAA2E72113D3DAF5770612B0',
}
for relative, expected in protected.items():
    assert digest(relative) == expected, 'Protected Phase29 producer changed'

differences = []
for name in ('index.js', 'package.json', 'package-lock.json', 'contact_delivery_config.cjs'):
    before = (BACKUP / name).read_text(encoding='utf-8').splitlines(keepends=True) if (BACKUP / name).exists() else []
    after = (PROJECT / 'work/cloud/workspace' / name).read_text(encoding='utf-8').splitlines(keepends=True)
    differences.extend(difflib.unified_diff(before, after, fromfile='before/' + name, tofile='after/' + name))
(AUDITS / 'phase30-kms-config-source-diff.patch').write_text(''.join(differences), encoding='utf-8')

names = [
    'work/cloud/workspace/index.js', 'work/cloud/workspace/contact_delivery_config.cjs',
    'work/cloud/workspace/package.json', 'work/cloud/workspace/package-lock.json',
    *protected,
    'work/cloud/workspace/node_modules/tencentcloud-sdk-nodejs-kms/package.json',
    'work/cloud/workspace/node_modules/tencentcloud-sdk-nodejs-kms/LICENSE',
    'work/cloud/workspace/node_modules/tencentcloud-sdk-nodejs-kms/tencentcloud/services/kms/v20190118/kms_client.js',
    'work/cloud/workspace/node_modules/tencentcloud-sdk-nodejs-common/package.json',
    'work/cloud/workspace/node_modules/tencentcloud-sdk-nodejs-common/tencentcloud/common/abstract_client.js',
    'work/cloud/workspace/node_modules/tencentcloud-sdk-nodejs-common/tencentcloud/common/http/http_connection.js',
    'work/cloud/workspace/node_modules/@cloudbase/node-sdk/package.json',
]
names += ['work/product-upgrade-20261009/audits/' + name for name in (
    'phase30-kms-config.test.cjs', 'phase30-kms-config-first-red.txt',
    'phase30-kms-config-first-candidate.txt', 'phase30-kms-config-first-green.txt',
    'phase30-kms-existing-bootstrap-green.txt', 'phase30-kms-dependency-install.txt',
    'phase30-kms-dependency-verify.cjs', 'phase30-kms-dependency-verification.json',
    'phase30-kms-config-emit.cjs', 'phase30-kms-config-actual-fixture.json',
    'phase30-kms-config-source-diff.patch', 'phase30-kms-config-review.md',
    'phase30-kms-config-freeze.py',
)]
names += ['work/product-upgrade-20261009/backups/phase30-kms-config/1/' + name for name in (
    'index.js', 'package.json', 'package-lock.json', 'manifest.json',
)]
names += ['work/product-upgrade-20261009/backups/phase30-kms-config/2/' + name for name in (
    'index.js', 'contact_delivery_config.cjs', 'phase30-kms-config.test.cjs', 'manifest.json',
)]
result = {
    'contract': 'phase30_kms_configuration_candidate_freeze_v1',
    'own_tests': {'methods': 3, 'passed': 3, 'duration_ms': 1132.1653},
    'existing_targeted_tests': {'methods': 2, 'passed': 2, 'duration_ms': 347.9365},
    'syntax_checks': 2, 'deployment_performed': False, 'live_kms_verified': False,
    'independent_review': 'pending',
    'protected_phase29_producers_unchanged': True,
    'files': [{'path': name, 'sha256': digest(name)} for name in names],
}
destination = AUDITS / 'phase30-kms-config-final-hashes.json'
assert not destination.exists(), 'Do not overwrite a frozen manifest'
destination.write_text(json.dumps(result, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
print(json.dumps({'files': len(names), 'manifest_sha256': hashlib.sha256(destination.read_bytes()).hexdigest().upper()}))
