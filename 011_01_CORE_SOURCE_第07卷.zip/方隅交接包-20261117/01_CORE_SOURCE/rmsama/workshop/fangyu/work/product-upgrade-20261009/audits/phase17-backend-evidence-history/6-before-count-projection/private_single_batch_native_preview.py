"""Phase17 isolated GUI candidate; importing this file never bootstraps data.

Only the mature native_preview.Handler class is compiled, via AST. The old
module's imports, global database/bootstrap and server launch are not executed.
The parent explicitly starts this separate preview after reviewing the source.
"""
import ast
from contextlib import ExitStack
import hashlib
from http.server import ThreadingHTTPServer
import importlib.util
import io
import json
import logging
from pathlib import Path
import re
import sys
import threading
import time
from types import SimpleNamespace
from unittest.mock import patch

HERE = Path(__file__).resolve().parent
PROJECT = HERE.parents[1]
SOURCE = PROJECT / 'work/app/src'
DATA = HERE / 'private-single-batch-native-data'
STATE_FILE = HERE / 'private-single-batch-native-preview-state.json'
ASSET_LOG = HERE / 'private-single-batch-loaded-ui-source-hashes.jsonl'
COMMAND_LOG = HERE / 'private-single-batch-command-receipts.jsonl'
sys.path.insert(0, str(SOURCE))

READ_ACTIONS = frozenset({'workspace_state', 'leads_list', 'customer_list',
    'customer_detail', 'reply_status', 'contact_receipt_status', 'task_progress',
    'keyword_state'})
PRODUCT_READS = frozenset({'strategy_get', 'strategy_task_get',
    'acquisition_run_preflight', 'acquisition_overview', 'handoff_list',
    'self_worklist_get', 'self_daily_evidence_summary', 'entitlement_summary'})


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load_fixture_class():
    path = PROJECT / 'work/app/tests/test_private_strategy_single_batch_entry.py'
    spec = importlib.util.spec_from_file_location('phase17_single_batch_fixture', path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module.SingleBatchEntryFixture


def reuse_handler(namespace):
    original = HERE / 'native_preview.py'
    module = ast.parse(original.read_text(encoding='utf-8'), filename=str(original))
    matches = [item for item in module.body
               if isinstance(item, ast.ClassDef) and item.name == 'Handler']
    if len(matches) != 1:
        raise RuntimeError('native Handler source does not match reviewed shape')

    class PreviewNames(ast.NodeTransformer):
        log_checks = 0

        def visit_Compare(self, node):
            if (isinstance(node.left, ast.Name) and node.left.id == 'requested_asset'
                    and len(node.ops) == 1 and isinstance(node.ops[0], ast.In)
                    and len(node.comparators) == 1
                    and isinstance(node.comparators[0], ast.Name)
                    and node.comparators[0].id == 'tracked'):
                self.log_checks += 1
                return ast.copy_location(ast.Constant(value=True), node)
            return self.generic_visit(node)

        def visit_Constant(self, node):
            replacements = {
                'loaded-ui-source-hashes.jsonl': ASSET_LOG.name,
                'isolated_native_ui_fixture': 'phase17_private_single_batch_gui_fixture',
                '验收样例 · 人工编写数据 · 未连接真实平台 / 企业云 / 支付':
                    'Phase17 合成单批验收 · 隔离搜索/评论样例 · 非真实账号、平台、企业云或业绩 · 原租约120秒',
            }
            if isinstance(node.value, str):
                value = node.value
                for old, new in replacements.items():
                    value = value.replace(old, new)
                return ast.copy_location(ast.Constant(value=value), node)
            return node

    names = PreviewNames()
    tree = ast.fix_missing_locations(ast.Module(
        body=[names.visit(matches[0])], type_ignores=[]))
    if names.log_checks != 1:
        raise RuntimeError('native asset logging guard does not match reviewed shape')
    exec(compile(tree, str(original) + ':Handler-only', 'exec'), namespace)
    return namespace['Handler'], sha(original)


def build_preview():
    """Explicit bootstrap of a new synthetic database; no HTTP server yet."""
    if DATA.exists():
        raise RuntimeError('独立样例目录已存在；不会重建快照或延长原租约。请先核对原样例。')
    from http.server import BaseHTTPRequestHandler
    from urllib.parse import parse_qs, urlsplit
    from assistant.employee_workspace import asset, identity, WorkspaceError
    from assistant.product_workspace import dispatch

    fixture = load_fixture_class()(DATA)
    core, executor, host = fixture.core, fixture.executor, fixture.server
    host.development_workspace = False
    host.company['name'] = '方隅 · Phase17合成单批验收'
    host.company['managedWorkspace'] = {'environment_id': 'phase17-fixture-env'}
    host.company['runtime']['public_send_hold'] = True
    user = core.store.get('users', executor.user_id)
    user['can_reply'] = False
    core.store.put('users', user)
    # This synthetic bearer-free owner/device is confined to the new fixture.
    # The standard gateway still performs its trusted actor/scope rechecks.
    device = {'id': 'phase17-fixture-device', 'owner': executor.owner,
        'tenant_id': executor.tenant, 'name': 'Phase17隔离样例电脑',
        'status': 'online', 'online': True, 'revoked': False,
        'last_seen': time.time(), 'platform_access': {'xiaohongshu': True},
        'platform_qa': True, 'continuous_qa': False, 'version': '1.1.7-qa.1'}
    vault = SimpleNamespace(read=lambda: {'state': 'bound',
        'environment_id': 'phase17-fixture-env', 'company_id': host.company['id'],
        'device': dict(device)})
    host.assistant_service = SimpleNamespace(lock=threading.RLock(),
        state='online', device=device, executor=executor, vault=vault)
    executor.principal = lambda command, **kwargs: core._public(
        core.store.get('users', executor.user_id))

    def forbid_external(*args, **kwargs):
        raise AssertionError('Phase17 preview forbids network, CLI and model/cloud calls')

    executor._ai_cloud = forbid_external
    # Lifetime patches are installed before accepting any request. Incoming
    # loopback HTTP uses accept(), not socket.connect().
    protections = ExitStack()
    protections.enter_context(patch('socket.socket.connect', side_effect=forbid_external))
    protections.enter_context(patch('core.adapters.subprocess.Popen', side_effect=forbid_external))
    jobs, job_lock = {}, threading.RLock()

    def record_command(ident, payload, phase, job, *, duplicate=False):
        # Synthetic GUI evidence only. This is not the production broker's
        # command journal, and contains no raw keyword, adapter body or path.
        result = job.get('result') if isinstance(job.get('result'), dict) else {}
        record = {'synthetic_only': True, 'occurred_at': time.time(),
            'phase': phase, 'action': 'task_run', 'request_id': ident,
            'task_id': payload['task_id'], 'max_batches': payload['max_batches'],
            'command_status': job['status'],
            'result_status': result.get('status'),
            'batches': result.get('batches'), 'imported': result.get('imported'),
            'duplicate_key_return': duplicate}
        with COMMAND_LOG.open('a', encoding='utf-8') as evidence:
            evidence.write(json.dumps(record, ensure_ascii=False, allow_nan=False) + '\n')

    def invoke(operation, data):
        if operation == 'me':
            return {'user': core._public(core.store.get('users', executor.user_id))}
        if operation == 'local_device':
            return {'bound': True, 'device_id': device['id'], 'owner': executor.owner}
        if operation == 'devices':
            device['last_seen'] = time.time()
            return {'devices': [dict(device)]}
        if operation == 'ai_profile':
            return {'config': {'provider': 'deepseek', 'model': 'deepseek-flash',
                               'enabled': False, 'configured': False}}
        if operation == 'product_action':
            if data.get('action') not in PRODUCT_READS:
                raise WorkspaceError('此单批样例仅开放必要只读产品动作', 403, mutation_committed=False)
            return dispatch(host, core.store.get('users', executor.user_id),
                            data['action'], data.get('data', {}))
        if operation == 'local_read' and data.get('action') in READ_ACTIONS:
            return {'result': fixture.command(data['action'], data.get('data', {}))}
        if operation == 'command_get':
            with job_lock:
                job = jobs.get(data.get('command_id'))
                public = {key: value for key, value in job.items() if key != 'fixture_payload'} if job else None
            return {'command': public}
        if operation == 'command_submit':
            action, payload = data.get('action'), data.get('data', {})
            if action not in READ_ACTIONS | {'task_run'}:
                raise WorkspaceError('隔离样例禁止新建任务、持续运行、平台账号操作、发送或云操作',
                                     403, mutation_committed=False)
            if (action == 'task_run' and (not isinstance(payload, dict)
                    or set(payload) != {'task_id', 'max_batches'}
                    or payload.get('task_id') != fixture.task_id
                    or type(payload.get('max_batches')) is not int or payload['max_batches'] != 1)):
                raise WorkspaceError('样例只允许原任务明确 max_batches=1', 403, mutation_committed=False)
            ident = data.get('request_id')
            if (data.get('device_id') != device['id'] or not isinstance(ident, str)
                    or re.fullmatch(r'[A-Za-z0-9_-]{1,160}', ident) is None):
                raise WorkspaceError('样例原请求编号或电脑不匹配', 403, mutation_committed=False)
            original = {'action': action, 'data': payload}
            with job_lock:
                if ident in jobs:
                    if jobs[ident]['fixture_payload'] != original:
                        raise WorkspaceError('同一原请求编号不能改变操作', 409, mutation_committed=False)
                    if action == 'task_run':
                        record_command(ident, payload, 'same_key_readback', jobs[ident], duplicate=True)
                    return {'command_id': ident}
                jobs[ident] = {'id': ident, 'status': 'running', 'fixture_payload': original}
                if action == 'task_run':
                    record_command(ident, payload, 'dispatch_started', jobs[ident])
            try:
                result = executor({'id': ident, 'owner': executor.owner,
                    'principal': {'username': executor.owner, 'role': 'operator'},
                    'action': action, 'data': payload})
            except Exception:
                with job_lock:
                    jobs[ident].update(status='uncertain', error='隔离样例原操作未完成，请只核对原任务和原编号')
                    if action == 'task_run':
                        record_command(ident, payload, 'dispatch_unknown', jobs[ident])
                raise WorkspaceError('隔离样例执行结果待核对；未自动重试或换号', 503) from None
            with job_lock:
                jobs[ident].update(status='succeeded', result=result)
                if action == 'task_run':
                    record_command(ident, payload, 'dispatch_result', jobs[ident])
            return {'command_id': ident}
        raise WorkspaceError('此独立样例未开放该动作', 403, mutation_committed=False)

    namespace = {'__name__': 'phase17_reused_native_handler',
        'BaseHTTPRequestHandler': BaseHTTPRequestHandler, 'parse_qs': parse_qs,
        'urlsplit': urlsplit, 'json': json, 'hashlib': hashlib, 'logging': logging,
        'time': time, 'HERE': HERE, 'host': host, 'asset': asset, 'identity': identity,
        'WorkspaceError': WorkspaceError, 'executor': executor, 'user': user,
        'device': device, 'account': fixture.account, 'invoke': invoke}
    BaseHandler, handler_source_sha = reuse_handler(namespace)

    class Handler(BaseHandler):
        def do_POST(self):
            # Keep the mature envelope/response handler. Only the synthetic
            # assistant state branch differs; it conveys no live verification.
            if self.path == '/api':
                length = int(self.headers.get('Content-Length', 0))
                if 0 < length <= 1000500:
                    raw = self.rfile.read(length)
                    try:
                        envelope = json.loads(raw)
                    except ValueError:
                        self.rfile = io.BytesIO(raw)
                        return super().do_POST()
                    if envelope.get('action') == 'assistant_status':
                        return self.respond({'state': 'online', 'safety_hold': False,
                            'account_safety_available': False, 'login_method': 'browser',
                            'message': '隔离合成适配器样例；未连接或核验真实平台账号。'})
                    self.rfile = io.BytesIO(raw)
            return super().do_POST()

    source_files = [SOURCE / 'assistant' / name for name in (
        'business.py', 'strategy_tasks.py', 'acquisition_run_preflight.py', 'product_workspace.py')]
    source_files += [SOURCE / 'core' / name for name in ('engine.py', 'pipeline.py')]
    from assistant.acquisition_strategy import ENTITY
    policy = core.store.get(ENTITY, fixture.strategy.ident)
    state = {'synthetic_only': True, 'data_dir': str(DATA),
        'original_task_id': fixture.task_id, 'lease_expires_at': policy['lease']['expires_at'],
        'original_lease_seconds': 120, 'lease_extended': False, 'task_recreated': False,
        'real_platform_requests': 0, 'real_cloud_or_model_requests': 0,
        'public_send_hold': True, 'continuous_allowed': False,
        'handler_source_sha256': handler_source_sha,
        'startup_python_source_sha256': {str(path.relative_to(SOURCE)): sha(path) for path in source_files},
        'command_receipts_scope': 'preview_process_memory_only_with_synthetic_jsonl_evidence',
        'command_receipts_log': str(COMMAND_LOG), 'production_command_ledger': False,
        'binding_evidence': 'synthetic_host_fixture_only',
        'loaded_assets_log': str(ASSET_LOG)}
    return SimpleNamespace(fixture=fixture, core=core, host=host, handler=Handler,
        protections=protections, invoke=invoke, state=state)


def main():
    logging.basicConfig(filename=HERE / 'private-single-batch-native-preview.log',
                        level=logging.INFO, encoding='utf-8')
    preview = build_preview()
    server = ThreadingHTTPServer(('127.0.0.1', 0), preview.handler)
    server.company, server.closing = preview.host.company, False
    server.close_owned_jobs = lambda: preview.core.close_continuous_scheduler(wait=True)
    preview.state.update(pid=__import__('os').getpid(), port=server.server_port)
    STATE_FILE.write_text(json.dumps(preview.state, ensure_ascii=False, indent=2), encoding='utf-8')
    try:
        if '--headless' in sys.argv:
            server.serve_forever()
        else:
            from desktop import run_desktop
            run_desktop(server, 'http://127.0.0.1:' + str(server.server_port) + '/', DATA,
                        '方隅 · Phase17隔离合成单批验收')
    finally:
        server.server_close()
        preview.fixture.close()
        preview.protections.close()


if __name__ == '__main__':
    main()
