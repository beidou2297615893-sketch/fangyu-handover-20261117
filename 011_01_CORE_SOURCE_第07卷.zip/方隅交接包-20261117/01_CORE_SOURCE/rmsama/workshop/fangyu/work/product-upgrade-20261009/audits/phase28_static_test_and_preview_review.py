"""Read-only static preview preflight; freeze the one repaired legacy UI test."""
import ast
import hashlib
import json
from pathlib import Path
import re

project = Path('C:/积木软件工坊/项目/方隅公寓客户版')
work = project / 'work/product-upgrade-20261009'
audit = work / 'audits'
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest().upper()
pins_path = audit / 'phase28-company-receiver-gui-pins.json'
pins = json.loads(pins_path.read_text(encoding='utf-8'))['sources']
assert len(pins) == 56
assert all(digest(project / name) == expected for name, expected in pins.items()), 'Preview source pin drift'
asset_file = project / 'work/app/src/assistant/employee_workspace.py'
tree = ast.parse(asset_file.read_text(encoding='utf-8'))
assets = next(ast.literal_eval(node.value) for node in tree.body if isinstance(node, ast.Assign)
              and any(isinstance(target, ast.Name) and target.id == 'ASSETS' for target in node.targets))
assert assets['company-handoff-receiver-ui.mjs'][0] == 'company-handoff-receiver-ui.mjs'
missing = []
for path in (project / 'work/app/src/web/workspace').glob('*.mjs'):
    for name in re.findall(r'\?asset=([a-z0-9-]+\.mjs)', path.read_text(encoding='utf-8')):
        if name != 'config.mjs' and name not in assets:
            missing.append([path.name, name])
assert not missing, missing
helper = work / 'company_receiver_gui_preview.py'
helper_text = helper.read_text(encoding='utf-8')
compile(ast.parse(helper_text), str(helper), 'exec')  # Compile only; no project imports or build_preview/main invocation.
worker = audit / 'phase28-company-receiver-gui-sdk-worker.cjs'
worker_text = worker.read_text(encoding='utf-8')
assert "if(input.kind==='source_hashes')" in worker_text
assert "lose_response=True" in helper_text
assert "ThreadingHTTPServer(('127.0.0.1',0)" in helper_text
assert "patch('socket.socket.connect', side_effect=forbidden)" in helper_text
assert "patch('subprocess.Popen', side_effect=only_owned_worker)" in helper_text
assert "patch('core.adapters.Adapters.execute', side_effect=forbidden)" in helper_text
assert "patch('integrations.request_json', side_effect=local_request)" in helper_text
assert "'company_handoff_receipt_get'" in helper_text
assert "if any(path.exists() for path in (DATA, STATE, ASSETS, EVIDENCE))" in helper_text
root_state_present = (work / 'company-receiver-gui-state.json').exists()

baseline = json.loads((audit / 'phase28-receiver-ui-source-freeze.json').read_text(encoding='utf-8'))
for item in baseline['source']:
    assert digest(project / item['path']) == item['sha256'], 'Frozen receiver UI changed'
enterprise = project / 'work/app/src/web/workspace/enterprise-ui.mjs'
assert digest(enterprise) == '47833728080C10904E300104228B61BA740476090C8F61AC55726218ED05964A'
before_dir = work / 'backups/phase28-static-test-drift-before'
original = before_dir / 'workspace-refinement-ui.test.cjs'
red = before_dir / 'first-saved-red.log'
assert digest(original) == 'BE8C2A3448442C6F480D1E10F20945559A2D417C76CE02B89520441866CA1CFD'
assert digest(red) == '15717087D326B30AE2E6FB4A5CB5CC990A33A892BA229C233A51767AFD1DFFAA'
green = work / 'logs/phase28-receiver-ui/static-test-drift-green.log'
assert re.search(r'pass 10\s', green.read_text(encoding='utf-8'))
assert re.search(r'fail 0\s', green.read_text(encoding='utf-8'))
test = project / 'work/app/tests/workspace-refinement-ui.test.cjs'
copy = work / 'backups/phase28-static-test-drift-freeze/1/work/app/tests/workspace-refinement-ui.test.cjs'
copy.parent.mkdir(parents=True, exist_ok=True)
copy.write_bytes(test.read_bytes())
assert digest(copy) == digest(test)
latest_fixture = audit / 'phase28-company-receiver-actual-fixture.json'
assert digest(latest_fixture) == '34B182D677DBA73668DC0DB014D227E369935C8D60D7CB63B37A5ACE8E17F2A9'
record = {
    'kind': 'legacy_static_test_only_repair_and_preview_static_preflight',
    'product_source_modified_by_this_task': False,
    'test': {'path': str(test.relative_to(project)), 'sha256': digest(test), 'snapshot': str(copy.relative_to(project)),
             'before_sha256': digest(original), 'green_log_sha256': digest(green), 'first_saved_red_sha256': digest(red)},
    'verification': {'one_same_group_run': True, 'tests': 10, 'passed': 10, 'failed': 0, 'not_new_tests': True},
    'historical_runs_preserved': {'new_receiver_ui': '3/3 at historical CA12 fixture', 'old_core_targeted': '21/21',
                                'old_workspace_before_repair': '9/10; original RED retained'},
    'preview_static': {'pins': 56, 'pins_sha256': digest(pins_path), 'helper_sha256': digest(helper), 'worker_sha256': digest(worker),
                       'production_asset_mapping_sha256': digest(asset_file), 'module_asset_graph_missing': missing,
                       'python_syntax_compiled_only': True, 'gui_started_by_reviewer': False,
                       'real_account_cloud_browser_native_used': False, 'unresolved_p2_found': False,
                       'root_gui_state_present_at_review_completion': root_state_present},
    'latest_fixture': {'sha256': digest(latest_fixture), 'reran_new_ui_tests_against_latest_fixture': False},
}
(audit / 'phase28-static-test-drift-freeze.json').write_text(json.dumps(record, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
report = f'''# Phase28 旧 UI 静态断言漂移修复与 GUI 静态预检

本次只修改 `work/app/tests/workspace-refinement-ui.test.cjs` 中原相邻函数正则。真实 enterprise 最终 return 仍保留 loadWorklist、openPending、openLead、closeDetail、exportCurrent，且包含已存在的 openTaskComments；redraw 与 profile 仍返回。测试提取实际最终 return 对象、在只含函数替身的隔离 VM 中创建该对象，逐项核对返回能力，不调用方法体、不启动 app/DOM，不再依赖五函数相邻。enterprise SHA 仍为 478337…，receiver 三个产品 UI 源及原 3 项测试均与原冻结相同。

原测试字节及首个已保存 RED 日志完整备份在 `work/product-upgrade-20261009/backups/phase28-static-test-drift-before`，SHA 分别为 {digest(original)} / {digest(red)}。仅同 10 项定向执行一次，GREEN 10/10，未增加新测试数；日志 `logs/phase28-receiver-ui/static-test-drift-green.log`，SHA {digest(green)}。原新 UI 3/3、旧核心 21/21、旧 workspace 修复前 9/10 是独立历史记录，不累加或覆盖为新的整组结果。

## GUI 静态预检（本审阅未启动或访问 GUI）

发现 P2：原 production employee_workspace.ASSETS 缺 company-handoff-receiver-ui.mjs，顶层 import 会 404。已先反馈 root，由 root 在自己的 ownership 下仅添加映射并重 pin。该修正是静态 prelaunch 发现，未冒充实际 GUI RED。本次复核新 employee SHA {digest(asset_file)}，56 个 frozen source 全匹配；直接 MJS asset import 图无缺映射；helper AST 编译成功。固定 GUI worker 已存在，含 source_hashes，并沿原 synthetic fixture 的两 Core / actual service/createStore SDK 接口内存 adapter；检查未运行 worker。

脚本仅在 main/build_preview 中建自有 DATA、固定 worker 与 127.0.0.1 服务；首尾 source pins、固定 argv、阻止 Python outgoing socket 与 platform adapters、云 request_json 仅指向受控本地 SDK fixture、允许四个 company receiver 动作、generic begin/status 禁止、既有 GUI 证据存在即拒绝重跑、首个 ACK 指定丢回执、GET 不重写。原 native_preview 只 AST 提取 Handler 类，不执行其顶层 Core 或 native 启动。源注册/submit 是独立合成准备计数，startup receipt 必须 0；不复制来源 leads/tasks/handoffs/preparation 至接收 Core。

此次静态复核未发现其它未解决 P2；这不证明实际 served UI 能运行、GUI 行为或读写预算已验收。归档时 root 自有 GUI 状态文件已出现：{root_state_present}，本审阅只读取源码/文件元信息，没有启动或访问该实例。GUI、真实公司网络、真实账号、第二实体机均未由本审阅执行。

最新 backend 标签窄修后 actual fixture 为 {digest(latest_fixture)}（34B1），仅作为最新来源指向；本次没有重跑原新 UI 3 项，不能把历史 CA12 的 3/3 冒称已用最新 fixture 重测。

修复后 test SHA：{digest(test)}。副本 `backups/phase28-static-test-drift-freeze/1/work/app/tests/workspace-refinement-ui.test.cjs`；manifest `audits/phase28-static-test-drift-freeze.json`。
'''
(audit / 'phase28-static-test-drift-review.md').write_text(report, encoding='utf-8')
print(json.dumps({'pins': len(pins), 'test_sha256': digest(test), 'helper_sha256': digest(helper), 'worker_sha256': digest(worker),
                  'pins_sha256': digest(pins_path), 'unresolved_p2_found': False, 'gui_not_started_by_reviewer': True,
                  'root_state_present': root_state_present}, ensure_ascii=False))
