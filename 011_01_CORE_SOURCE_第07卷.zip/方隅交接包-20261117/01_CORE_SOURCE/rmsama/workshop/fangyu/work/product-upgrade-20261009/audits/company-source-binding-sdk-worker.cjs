/* Fixed local synthetic worker; actual service/repos, not a cloud transport. */
'use strict';
const readline=require('node:readline');
const assert=require('node:assert/strict');
const {fixture}=require('../../cloud/workspace/channel-candidates-fixture.cjs');
let engine=null;
async function command(input){
 if(!engine)engine=await fixture();
 if(input.kind==='sync'){
  const out=await engine.call('contact_events_sync',{events:[input.event]},'fixture-source-device-token');
  assert.equal(out.status,200);return {result:out};
 }
 if(input.kind==='source_read'){
  engine.data.resetOperations();const before=engine.data.snapshot();
  const result=await engine.call('acquisition_source_binding_read',input.data,engine.tokens.source);
  assert.equal(result.status,200);assert.equal(before,engine.data.snapshot());
  const operations=engine.data.operations();for(const callbacks of operations)for(const count of callbacks)assert.equal(count.writes,0);
  return {result,operations,stored_documents_unchanged:true};
 }
 throw Error('unknown synthetic fixture command');
}
const lines=readline.createInterface({input:process.stdin,crlfDelay:Infinity});
(async()=>{for await(const line of lines){try{process.stdout.write(JSON.stringify(await command(JSON.parse(line)))+'\n');}
 catch(error){process.stdout.write(JSON.stringify({fixture_error:error.message})+'\n');}}})().catch(()=>{process.exitCode=1;});
