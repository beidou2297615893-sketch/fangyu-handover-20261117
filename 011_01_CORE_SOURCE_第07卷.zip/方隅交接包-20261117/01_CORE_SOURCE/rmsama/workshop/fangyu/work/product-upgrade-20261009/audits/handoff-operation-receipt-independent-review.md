# 公司交接原动作回执：独立验收

2026-10-10，本项目离线候选。独占新增测试与报告；未修改生产源码、旧测试、真实业务数据、角色或外部账号，未部署、调用云端或发起平台动作。

## 结论

当前冻结候选的独立 **6/6** 代表测试通过。主窗口提出的登记key误指另一有效channel问题经实际服务路径复现为真RED，D修复确定性绑定后GREEN。原失败日志保留，未放松断言。当前未发现这些代表链路中的权限绕过、历史事实抹除或查询写入问题。

调用实际`createService → createStore → handoff-ledger/repo`，合成文档持久于隔离内存fixture，事务adapter兼容SDK文档接口并手工回放两次callback。不是假status handler；也不是node-sdk内部事务引擎、真实云事务或在线性能验收。

## 契约与权限

`acquisition_handoff_operation_status`仅接受标准envelope及`operation_action/idempotency_key`。原动作只可为既有7个写动作；当前session用户名与固定company派生原operation文档，客户端不能传owner、actor、channel、原payload或角色。管理员传相同key也不能读取另一操作人的原回执。

成功响应固定`data.operation_receipt`。`state:recorded`对应`original_execution_confirmed:true`；缺原文档对应`unknown/null`。查询`mutation_committed:false`只描述本次纯读，不证明原写未执行，不能解除原unknown或换key重试。成功外层没有另一处原confirmed真值；内层是原事实的唯一投影。

原operation严格5字段，原audit核actor/action/revision/channel及事件自hash；register额外核`channel_id === 'hc_'+hash([companyId,currentActor,action,key])`。当前item/最新audit/同意账本复读，并在最后await之后复核当前session、公司、员工主体与resourceReceiver可见性。商业过期不阻止有权历史查询；当前部门权限撤回仍拒绝。

原revision与当前状态分别返回。真实合成resource账号历史accept保持recorded，当前withdrawn/consent=false不允许继续交付。`full_historical_chain_verified:false`明确没有核完整中间历史链。`receipt_evidence_independently_verified:false`、`platform_delivery_verified:false`、`financial_receipt_verified:false`、`cooperation_policy_verified:false`不把服务端记录当独立来源/平台/财务证明；cash/paid金额均null。

## 六组实际代表

1. 实际register事务提交后，adapter丢响应；新服务实例重启只按原key读。商业权益过期及过期sessions/devices/attempts存在，查询仍返回原记录，所有合成文档前后相同。
2. 原source登记、提交与独立resource账号accept回执，客户随后撤同意。原revision1/2/3仍draft/submitted/accepted，当前revision4为withdrawn、当前授权false、历史接收事实true。
3. 不存在原key、其他actor/admin同key保持unknown/null；伪造actor/owner/channel/payload、非写动作拒400，换company拒403。
4. 损坏原op actor/额外私密字段、原audit或当前source_owner安全拒绝；不重算、不修补、不返回私密值。来源变更使当前不可见时404与409都是拒绝结果。
5. 最后一次当前同意文档await期间撤resourceReceiver映射、删除当前session或换company，完整原回执均不返回；两个回放callback都零写。
6. 两条同actor真实register。仅将第一opdoc的channel/revision改指第二有效channel，保留第一payload_hash/actor/action，修前错误200 recorded；修后409。原RED在`handoff-operation-receipt-register-binding-red.log`。

每组对纯读路径断言全部callback `writes=0`、`reads<=100`，完整合成文档map不变，公开响应不含原评论、裸UID、联系方式或证据引用。角色/race变更仅作用于fixture callback状态，未写真实角色。

## 操作预算与错误边界

独立`handoff-operation-receipt-budget-independent.cjs`直接调最终status，保存JSON：有当前授权时首dispatch每callback **1读0写**，ledger **9读0写**；历史accept且当前withdrawn为 **1+7**；缺原key为 **1+2**，每事务手工双callback结果相同。两事务分列，不相加成单事务；这些是隔离adapter路径操作数，不能代替真实SDK引擎重试、100操作限制执行效果、30秒或线上吞吐。

typed/generic ledger错误不声明原执行false。共享service通用catch或index最外层故障可能只返普通error，未附原状态字段；接入者必须将它维持unknown，不能凭HTTP4xx、缺文档或本次查询false推断原未提交。当前尚未实现本机公司写原动作originrow；任意填key入口及自动重放不在验收范围。

## 冻结与计数

最终必要命令：`node --test --test-reporter=tap work/product-upgrade-20261009/audits/handoff-operation-receipt-independent.test.cjs`，退出0、6/6，原binding RED5/6另留历史日志。budget脚本退出0，3个读取探针不计为额外单元用例。D实施11例独立报告，不与本报告6反复加总或重复加入阶段总数；旧phase10四例没有重算为本阶段新增。

生产来源：

| 文件 | SHA256 |
| --- | --- |
| handoff-ledger.cjs | 7CA948D72A8C93763BFD00E2303BAFA35B6B12AC7450114F414DA301A5195128 |
| service.cjs | 6F6BDA5283DE833BEF1A3A49A9D37BA8DF2FAD3F714042D0FAEEBB1D358EC796 |
| index.js | 223A150519F3BCACE360D35BBDAF876DEEAB74AF426D415A3DF3B259DA2AFF1B |
| handoff-operation-status-fixture.cjs | 5D8720530768905158DBC1F5BA063F237B9AB7046984507887BC10CEBC9F85FD |

完整测试/日志/报告hash另存`handoff-operation-receipt-independent-manifest.json`。旧选型报告的16A544…/17D21…仅是历史来源，不是本API终验。技术夹具成功与真实云上线、实际接收、用户认可和财务证明明确分开。
