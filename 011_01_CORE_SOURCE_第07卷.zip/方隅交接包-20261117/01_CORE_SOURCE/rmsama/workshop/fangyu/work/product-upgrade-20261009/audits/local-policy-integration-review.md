# 本地意向规则集成独立审查与恢复护栏

2026-10-10。本轮先只读 root 的 `ai_workflow.py`、`BusinessExecutor`、规则管理与纯校验模块，再执行独立实际函数夹具。root 随后明确授权补最小 AIWorker 产品错误暂停、未追踪额度核对保护。未调用真实模型/平台/云，未读写生产 522 条历史记录，未改 UI、原数据、部署、账号或其他任务。

## 已核对结果

实际 BusinessExecutor 将 `company=lambda:self.server.company` 注入 LocalAIWorkflow，重置可信企业对象后，最终验证能够看到新配置。分析前在 `core.lock` 内验证当前员工、任务和来源；本地规则 snapshot 固定可信主体、版本、digest 与 normalized policy。回写前在同一 `core.lock` 内复验身份、任务、权益和规则 snapshot，复验通过才保存新缓存/结果。本地规则变化、权益撤销/过期期间返回的旧模型结果均未缓存或写入 lead。

本轮先复现了云规则变化缺口：模型返回前安全 profile 已从 v1 变 v2，但只核对启动版本与 v1 回执会接受旧结果。root 已在 transport 后、进入 core.lock 前重新读取安全 `ai_profile`，核对 revision、rules_version、provider、model、reasoning_effort；变化或读失败时不落本地缓存/结果。独立反例保持原断言，随后通过。

该复读是一个真实的后置版本观察点，网络不持有本地锁；不宣称它构成跨云、本地的分布式原子事务，也不抹去已发生模型资源处理。其后本地身份/规则/权益仍在锁内再判。

缓存带有 model、policy_validation、property_match、本地 digest 等元数据。新代码在每次套本地 guard 前抽取固定七个业务字段，避免把内部 metadata 当 result_shape 错误而让所有已评级客户变成 uncertain。独立测试把附加内部字段放入真实 SQLite 缓存，再调用实际 analyze，原 high 仍是 high，命中未发生新的分析。规则版本变化则生成新的本地 cache key。

模型期间发生人工纠正时，`manual_intent` 保持优先，新 AI 不覆盖人工结果。地域意向和匹配分别保留：合成“我想在北京租房，预算3500”在上海资料下仍是 high/other，其 property_match 为待核对，不能获得交付/归属/库存证明。合成公寓资料的候选匹配不表示有空房。

实际模型请求只传 city、area、post、comments、expected_revision、expected_rules_version。local criteria 未发送给 provider；保存结果明示 `provider_criteria_source: trusted_cloud_company_policy`、`local_criteria_applied_to_provider: false`。本地规则面板改动与云端企业模型提示词不是同一个发布行为，不能宣传成自动更新了云模型 criteria。

历史保护测试使用项目内临时 SQLite 中的 **522 条合成旧评级**：保存新规则后，普通 analyze 对其中已评级项不发模型请求、不生成新缓存，全部合成旧记录完全相同。这证明代表性代码路径不自动改旧结果；本轮未触碰真实 522 条，未将合成测试当生产数据验收。

## 新发现与定向护栏

AIWorker 原固定枚举不认识新 PRODUCT 错误，会把 unknown、额度不足和周期未配降为 AI_UNAVAILABLE，并尝试后台恢复；403 还会被误称需要管理员。新增真实 worker 反例先失败，随后仅扩固定安全白名单及暂停处理：

- `PRODUCT_REQUEST_UNKNOWN` 明确原分析待核对、原额度保留，不自动重试。
- `PRODUCT_ANALYSIS_LIMIT` 明确服务槽额度不足，不猜明天重置。
- `PRODUCT_PERIOD_REQUIRED / PERIOD_INACTIVE` 明确周期未配置/未开始/已结束，等待可信管理员核对。
- 到期、功能未开及请求/账本冲突仍保留原安全代码，原评论保留，原始异常/客户正文不进入状态文本。
- 已记录的 PRODUCT 暂停在重启、AI profile revision 变化后仍不自动解除。配置版本变化不能证明未知请求已结束，也不能证明套餐周期已续费。人工核对/恢复另走已有授权入口，本轮未新增随机编号或自动恢复动作。

`product_quota_status` 不是通用模型回执。pilot 或 `analysis_quota:null` 的旧调用没有写槽账本：原接口会把不存在的编号写取消墓碑并说 execution_confirmed:false，即使实际分析已成功。本轮真实 createService 的先分析200→核对反例已关闭：没有记录且当前没有配置分析槽时返回 `state:not_tracked / execution_confirmed:null / reservation_retained:null / units:null`，不新增取消记录；已有 tracked 请求在额度降为 null 后仍可核对原状态。

这不会把未追踪的旧请求迁移成已确认，也不把旧缓存当收费成功。配置了槽的当前新请求仍保留原取消晚到机制。历史未追踪调用后来改成有 quota 的迁移覆盖边界，需要下面的通用生命周期方案明确处理；不能仅依据当前配置或不存在的文档证明旧调用没有执行。

## 稳定请求编号的下一步设计（尚未实施）

当前实际 Python 调用仍无显式 `request_id`。相同归一化输入可沿原云缓存合并；明确 unbilled 的旧路径有服务端兼容重试；unknown 必须保留原键。临时每次生成 UUID 会把未知分析变成新的可收费请求，因此本轮没有这样改。

如下一轮接真正的核对入口，最小完整链路应满足：

1. 在任何模型 dispatch 前创建持久本机 attempt，只生成一次随机 UUID，绑定 tenant/owner、实际来源/批次摘要、输入 digest、云 model/rules、本地规则 snapshot。保存引用与摘要，不存密钥/联系方式，不只用内存或 UI 锁。
2. 同一未决 attempt 跨客户端超时、重启、账号代际和配置变化继续使用原 UUID。配置改变不能自动替换 unknown 编号；需先核对原请求。
3. 服务端为 **所有 AI 调用** 建 request ID → 原 AI ledger 的事务索引，与 quota 是否配置无关；身份来自当前持久化 session，编号改 payload 必须冲突。复用原模型 reserve/settle，不另造计价。
4. status 需在同事务中与执行竞争；不存在的全新编号可取消未来 dispatch，但 legacy/not_tracked 返回 unknown/null 及明确 coverage。不能把历史未追踪缺记录解释为未执行。
5. 已明确 unbilled/未执行才能由有权操作人决定下一次 attempt；成功可按原绑定读回；结果未知或账本异常继续停止。读回旧规则结果也必须通过当前本地/云版本栅栏才能成为当前结果，旧消费记录不删除。
6. 本机恢复 UI 严格核对 tenant/owner/device/generation/lead/request_id/digest，真实状态才能解锁；取消、冲突、旧账号、旧页面或回执缺字段不得乐观更新。

当前 quota status 足以核对槽账本，不能直接替代上述通用 attempt 协议。没有支付/云部署授权，不建立充值或扣款成功记录。

## 验证与固定源码

独立 LocalAIWorkflow 9/9，其中云 profile 变更先 RED → root 修复后 GREEN；AIWorker 新专项 5/5（原 5 个 test 的 9 个失败/subcase 保留断言后通过）；额度专项新增未追踪反例，19/19。

必要回归分别执行：旧本地 AI 52/52、纯 policy 21/21、规则管理 18/18、维护发现 62/62（该文件导入上述 AI 52，只有另 10 个维护用例，不重复累加）；11 份必要云联合 192/192，已含额度19与交接10。Python 新源/独立测试 py_compile 与权益源 node --check 通过。未合并数字夸大测试覆盖，也未把夹具调用当真实外部验证。

| 文件 | SHA256 |
|---|---|
| ai_workflow.py（root 修复后只读审核） | 01DE4D767CB0251F9A7BC0F849BA47BB1D6AAEF064A2542CF87811302052DD49 |
| business.py（root 构造接线） | 6442851406A4A36C1822AE0E062B42122A9FFCC1FF68E53829C84E0C953E6577 |
| intent_rule_management.py（C） | C066BBDC3583A2D88AF9398CDE762A61952E7B0E994F2517BB097357C01F48BE |
| intent_policy.py（C） | 257D522A3554DEBBF7B586C50A7308AD363F217268A3EE4FEE6D9F67E99515BA |
| ai_worker.py（本轮定向改动） | 251C8F86FAA754A3D84210D7CA6ADE3E28D3BEA4C736DDE71C6F2E3FC0852FD4 |
| product_entitlements.cjs（未追踪保护增补） | 8097559A9309C98738AB9FD30D3264969FE3E79039312981B0295C12ACD864EA |
| product_entitlements.test.cjs | 24AD612B4623727CE89ACD6A0177B02BB70764F55D7D27984929EDF4B711BAC7 |
| test_ai_worker_product_safety.py | A916873BAF779EDB9D5836A579844E85757DBF3BED5442B7C53E311D8A32941A |
| test_local_policy_integration_independent.py | E713A32D91AA0EB7406354AEB667B1F52309E74EE662D1846DBE03AE71EDA25F |

Worker 改动前 SHA 为 `C428A0AC38BCD290D74B1909FE2891B12908B827C46E6DD7E86BB759DDBD4F7C`。备份位于 `work/product-upgrade-20261009/backups/local-policy-worker-r1`，同时保存了 status 保护前额度源/测试。其余云模块继续上一轮冻结，不扩云业务。

昵称隐藏字符的单独隐私修复由 C 获 root 授权维护 acquisition_operations，root 修 exports；本轮未编辑这两文件，相关结果由各自审查报告负责。
