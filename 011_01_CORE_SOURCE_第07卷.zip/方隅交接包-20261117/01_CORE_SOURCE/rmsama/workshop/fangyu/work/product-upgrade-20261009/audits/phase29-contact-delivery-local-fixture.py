"""Actual two local Cores, synthetic CurrentUser DPAPI contact only.

The explicit_contact mode is an in-memory fixture transport, not public evidence.
No original DATA/profile/cloud/session/CLI is used. Both Cores use this Windows SID.
"""
from pathlib import Path
from tempfile import TemporaryDirectory
from copy import deepcopy
from unittest.mock import patch
import importlib.util
import json
import socket
import sys

PROJECT=Path(__file__).resolve().parents[3]
sys.path[:0]=[str(PROJECT/'work/app/src'),str(PROJECT/'work/app/tests')]
from core import Core
from assistant.acquisition_contacts import AcquisitionContacts

def create(mode):
    if mode not in ('metadata','explicit_contact'):
        raise ValueError('fixed synthetic mode only')
    temp=PROJECT/'work/product-upgrade-20261009/tmp/phase29-contact-delivery'
    temp.mkdir(parents=True,exist_ok=True)
    spec=importlib.util.spec_from_file_location('phase29_actual_local_source',PROJECT/'work/product-upgrade-20261009/audits/emit-company-handoff-original-status-fixture.py')
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    with TemporaryDirectory(dir=temp) as directory, patch.object(socket.socket,'connect',side_effect=AssertionError('network forbidden')), patch('core.adapters.Adapters.execute',side_effect=AssertionError('platform forbidden')):
        source=module.local_fixture(Path(directory)/'source')
        other=Core(Path(directory)/'resource-db',Path(directory)/'resource-resources')
        try:
            other.store.put('users',dict(id='phase29-resource',tenant_id=source.tenant,username='resource',role='operator',cloud_bound=True))
            service=AcquisitionContacts(source.core,source.tenant,'source',source.company)
            consent={key:source.handoff['consent'][key] for key in ('status','evidence_reference','notice_version')}
            contact=service.execute('contact_create',dict(lead_id=source.lead['id'],recipient_id=source.handoff['recipient_id'],
                purpose=source.handoff['purpose'],consent=consent,phone='[REDACTED:phone_cn]',wechat='phase29Customer',
                idempotency_key='phase29-synthetic-local-contact'),deepcopy(source.actor))
            decrypts=0
            values=None
            if mode=='explicit_contact':
                values=service.execute('contact_read',{'contact_reference':contact['contact_reference'],'reveal':True},deepcopy(source.actor))['contact']
                decrypts=1
            result=dict(synthetic_only=True,actual_two_local_cores=True,same_windows_sid=True,
                local_decrypts=decrypts,local_reveal_audits=len([e for e in source.core.store.list('acquisition_contact_events',source.tenant) if e['kind']=='revealed']),
                resource_contact_rows=len(other.store.list('acquisition_contacts',source.tenant)),event=source.event,
                consent=consent,recipient_id=source.handoff['recipient_id'],purpose=source.handoff['purpose'],
                contact_version=contact['id']+'_'+str(contact['revision']))
            if values is not None:result['values']={key:values.get(key,'') for key in ('phone','wechat')}
            return result
        finally:
            source.core.close_continuous_scheduler(wait=True);source.core.adapters.close()
            other.close_continuous_scheduler(wait=True);other.adapters.close()

if __name__=='__main__':
    print(json.dumps(create(sys.argv[1] if len(sys.argv)==2 else 'metadata'),ensure_ascii=False))
