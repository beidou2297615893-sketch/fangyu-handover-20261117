# 来源对应的公司账本：本机实现与独立核验冻结

结论：新增只读 LocalBusinessReconciliation 已实现，最终本机 **13/13** 通过；另独立公司实际 service/SDK replay 边界 **3/3** 通过。同一公司服务生成的归一 start/sent 事件及标准回执，经另一隔离真实 Core/Store/ContactJournal/本机交接记录，再进入实际本机模块，完整事件摘要确实一致。最后公司冻结回执重新生成后，单独复核该实际桥 1 项通过。这个 1 项是原13项之一的复核，不另加成功覆盖数。

测试全为当前项目内合成数据，没有原库、真实账号、平台、真实云、付费、消息、部署或正式包。它证明软件合同与来源绑定可运行，不证明真实回信、客户同意真实性、资源部业务认可、银行实收、分成实付、第二实体机或商用验收。前端/HTTP网关由根代理负责；其验证请看根代理独立报告，本报告不冒充完成了真实GUI。

## 新增及冻结范围

仅本人新增生产模块 work/app/src/assistant/business_reconciliation.py、独占本机测试 work/app/tests/test_business_reconciliation.py、独占公司测试 work/cloud/workspace/business_reconciliation_independent.test.cjs 及本项目 audits 报告/合成回执。没有修改旧公司 contact_ledger、其他代理云源、旧数据、AI/规则模块、前端或根网关。本轮后端/测试/最终fixture已冻结。

现有意向抽检冻结仍一致：intent_quality_review.py SHA 1ED5E027E8CD5A4B8C859C8CAB9506941AA3F98B8ED485B9483F9EE6CB0D2445；test_intent_quality_review.py SHA 6DB4C03B1458A27BB1AFA4F457BD0432101E740E28029803F47FCCB3864D2FB2。

## 实际最终入口

```python
LocalBusinessReconciliation(core, tenant, owner, company,
    *, device_id, scope_guard, lead_access, cloud_read)
execute('business_reconciliation_detail', {
    'handoff_id': '<existing local 32 lowercase hex>',
    'channel_id': 'hc_<64 lowercase hex>',
    'offset': 0, 'limit': 10  # offset整数>=0；limit整数1..15，可省略
}, saved_actor)
```

cloud_read(saved_actor, 'acquisition_reconciliation_detail', {channel_id,offset,limit}) 是可信进程回调，仅经既有认证成员网关。环境/公司/服务外层三字段由根网关核对后剥离，本模块仍检查 business_reconciliation_v1、authenticated_actor=本人、只读与所有内层字段。本次纯读无idempotency_key，不进入通用操作收据，不自动同步/注册/重试，不调用AI或平台。

首前置门核当前正式saved actor/cloud_bound、tenant/owner/company/device/scope、本人交接及既有审计链、本人当前原评论权限、冻结原评论身份/版本。云channel_id仅寻址，不能携带可信owner或客户身份。本机按云返回source_event_id定位同tenant/owner不可变事件，实际ContactJournal.receipt核完整该reply历史与链，再严格比payload、lead、原文、作者、评论摘要、设备、来源员工及派生cu_客户。归一差异/缺事件/空UID拒绝，不退回昵称/手机号猜配。

云读取在SQLite事务和core.lock之外；最后一轮事件存储读取之后，在core.lock内再次读取saved actor、本机来源、交接与企业快照并核scope，旧scope的结果不返回。商业权益到期允许本人历史读，disabled/解绑/权限或来源变化拒绝。没有本机→公司交接确认mapping，因此 local_cloud_handoff_correspondence_verified 始终false；cross_machine_verified也false。

返回合同 local_business_reconciliation_v1 / storage_scope=local_bridge_company_server_ledger；只公开本机/公司交接编号、版本状态、来源对应状态、订单登记/审核/历史计算摘要以及缺项。原文、裸UID/评论ID、hash、联系人、consent/evidence引用、凭据均不投影。订单分页最大15，由公司端最坏事务读预算收紧；默认10；不跨页累计金额。

## 金额与未知值

reported_amount_cents/refund/net只表示既有订单报告，net严格amount-refund且0<=refund<=amount，不用Math.max遮蔽负退款。只有matched或同customer旧关联版本变化且两版历史完整，才显示登记额；其它冲突值全部null。三字段 link_revision_current、distinct_review_actor_recorded、calculation_policy_current 是bool|null，null保留未知。

recorded_calculated_commission_cents只有原记录confirmed/calculated、原policy_revision存在、原政策快照可读才可显示；0仍为保存计算值，不是实付。distinct review为true时不能是reporter或latest editor，仍不宣称独立财务。verified_cash_cents/verified_paid_commission_cents所有层级固定null，financial_receipt_verified/cooperation_policy_verified固定false。旧字段没有币种，本批currency=null/amount_unit=legacy_cents，不补人民币符号或支付结论。

固定缺项代码白名单13项，且前三项必需：financial_cash_authority_not_integrated、commission_payment_authority_not_integrated、cooperation_policy_not_verified；source_missing、source_conflict、link_revision_changed、customer_conflict、order_missing、reverse_link_conflict、history_missing、history_conflict、record_invalid、commission_policy_history_missing。未知代码或缺合同字段整体拒绝。

BusinessReconciliationError 固定safe code/status/message，mutation_committed=false（本动作纯读）；safe code前缀BUSINESS_RECONCILIATION_；参数400、权限403、scope/source/audit/receipt冲突409、云不可读503。原云/SQLite私有异常不回显。

## 真实红绿及代表证据

初始7项绿色后，加入“第二次journal receipt读取刚完成就停用saved actor”的最难返回边界：原实现未抛异常、错误投影成功，真实1红日志 business-reconciliation-local-final-actor-red.txt。把最终actor/source snapshot放到该最后存储读之后且core.lock内；原8项绿色日志 final-actor-green.txt。最后扩到13项，包含同ID换UID、同event摘要/设备/owner/cuid冲突、读中权限/来源变化、到期历史、不能借接收人读源、ACK仅uploaded、非选中历史链损坏、合法零计算/缺原政策、审核人是last editor、额外客户端身份字段与无明文输出/无写操作。

公司端只读源独审发现 linked_revision_changed 最初只核current history，没有核链接时old history。已反馈代理B；B保留其实际红日志 business-reconciliation-linked-history-red.txt并修正。本人新增独占实际service/createStore SDK replay三项验证：entry之后disable/撤receiver映射拒绝；跨客户/缺源不泄漏金额且财务证据null；old linked history换customer或缺失拒金额。生产云源由B修，本人未改。公司端B另证最坏15条各不同政策且修订历史85reads/0writes；不将其测试计入本人3项。

本机13项最终日志：business-reconciliation-local-final.txt。公司独立3项：business-reconciliation-cloud-independent.txt。B最终源重新生成envelope后，仅原actual bridge1项复核：business-reconciliation-actual-final-cloud-freeze.txt。

## 合成回执来源及SHA

最终 business-reconciliation-local-actual-fixture.json 顶层request/result来自实际两端软件；cloud_response_source=actual_createService_createStore_sdk_callback_replay，含公司源SHA元数据。pending/order_missing/calculated_zero与injected_contract_projection保留为 **注入合成读合同** 的实际本机投影，不能冒充公司端SDK；实际两端另标actual_cloud_bridge。文件synthetic_only=true/no原库/no网络；公司端是在独立memory SDK重试store生成回执，然后以JSON边界供本机读层核对，未声称本机实时请求了真实云。

最终完整manifest：business-reconciliation-local-final-hashes.json。

|冻结文件|SHA256|
|---|---|
|business_reconciliation.py|6A8B24EB351CF658F104F42D43D6299796CA6D0ABC93DAB5C663E47886864E5D|
|test_business_reconciliation.py|4106B613702A58DFD3B80AE1CD01027F802910C628E8C49325473E4F588C742A|
|business_reconciliation_independent.test.cjs|134BFFCA288EBA04BED3F268F754A9616ABF08981059377AE5AFFFB297CE2E0A|
|local actual fixture JSON|B93B71AF80415C1703703EC98A20442E2964736A257C68AD4CF7390506ED46E7|
|cloud actual fixture JSON|225ECF29756E3127BC60B686FF2FFDEA55F213F5C49C182509EFF8875A421DD6|
|被审公司 business_reconciliation.cjs|D89314D59E8AACD7BBCD6B72FE0FBDB15F8E1088C4623A6B5D85E0787FF609AC|
|被审 handoff-ledger.cjs|16A544D72C9DB6E0597E3016C4433216D3B7824E4980FB5638A45166BC04A305|
|被审 service.cjs|1D800277C4142A4FB94EE1FD7FF03B27E730DD97E9A7C0CE529A8BFF425F7E17|

报告完整路径：C:\积木软件工坊\项目\方隅公寓客户版\work\product-upgrade-20261009\audits\business-reconciliation-local-independent-final.md

所在文件夹：C:\积木软件工坊\项目\方隅公寓客户版\work\product-upgrade-20261009\audits
