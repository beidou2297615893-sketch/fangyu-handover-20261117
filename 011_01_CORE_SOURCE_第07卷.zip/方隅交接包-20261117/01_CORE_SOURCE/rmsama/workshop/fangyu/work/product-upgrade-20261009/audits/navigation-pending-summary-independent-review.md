# Phase21 导航待处理数量独立审查

当前三个独立代表均通过：换主体或设备后立即显示“—”；任务评论与全局待处理数量分别核实；旧请求晚回和本轮读取失败均不能保留旧数字。另两个兼容副本共六项通过，只替换综合名单中的旧模块，不新增六项覆盖计数。没有未闭合的产品阻断。

## 实际产品问题与证据

旧 enterprise-ui.mjs 的任务范围汇总不刷新导航；reset 在已为全局范围时未使已有数量失效。原独立日志记录 0/3（87.9707ms）：实际 reset 后旧 7 仍可见；任务待处理 2、独立全局 7 时导航仍是旧 0；本轮全局读取失败仍保留旧 0。旧请求的既有晚返回门禁原本有效，不把它列为新发现。

RED 原测试 SHA 为 84F31BB5B12910E418A75FCEEA475A5F69394F808646F5BA12BC2DFD6A1D74AE。后来同三组加严了无效总量投影及精确请求数量；按已记录 SHA 恢复了字节一致的原测试快照 navigation-pending-summary-independent-red-test-source.txt，没有重跑旧源码或覆盖红日志。最初薄 VM 缺少 setInterval 的夹具启动错误另存 navigation-pending-summary-independent-fixture-error.txt，不算产品失败。

## 最终三个代表

- 使用实际 controller 的 reset 方法：全局已知 7 后改变本人 principal、company、device 或 deviceGeneration，立即显示“—”，reset 本身不新增请求。
- 任务标签仍显示任务范围待处理 2，同时导航使用独立无 task_id 的全局 pending limit1/group_by intent 读取显示 7；真实 0 显示 0。null、bool、字符串、负数、小数、超安全整数及读取失败均显示“—”。
- 暂停旧全局读取后切换公司或设备并读到新范围 0，再释放旧 99，不能覆盖新范围；当前读取失败不能显示以前的 0。

navigation-pending-summary-independent-green.txt：3/3，111.5578ms。测试读取实际 enterprise-ui/controller 方法和实际 enterprise-model principal 函数，配合成熟 Node VM/轻 DOM 夹具；投影数据为合成值。没有真实 GUI、后端 HTTP、业务数据库、账号或平台调用。action 仅允许 leads_list，不能据此声称实际 SQL 全路径已经验证零写。

## 原测试的兼容替换

根的 27 文件首跑保留在 navigation-pending-current-frontend-first-failure.txt。该轮三个范围测试失败是新合法全局读取使旧数量断言 3→4 或 4→5，不是产品故障。

新副本 task-comments-modern-entry-navigation-compatible.test.mjs 和 private-batch-results-route-ui-navigation-compatible.test.cjs 引入真实 navigationPending 声明，精确断言三个原任务汇总和唯一无 task_id 全局 pending 读取；任务列表仍使用原 task_id。原 late actor/company/device/generation/page/accept 拒绝、返回全部评论和未决原操作槽保护均保留。阅读全局时仍复用原 pending 汇总，不多一项调用。六项 6/6（182.3678ms），日志 navigation-pending-compatible-frontend.txt；综合名单只替换对应两个原文件。

原冻结 task-comments-modern-entry.test.mjs、private-batch-results-route-ui-independent.test.cjs，两个生产文件以及新独三测试的 before/after SHA 一致。兼容副本的 diff 只包括实际新声明和这一读取合同的数量/范围断言。

## 生产方案的只读核对

enterprise-ui.mjs:527–529 将导航状态单独绑定 actual principal/device/generation，安全非负整数才显示数值，未知时隐藏提示点。refreshWorklistSummary 继续使用现有读取范围/accept/pageVersion/serial 门禁，任务范围增加唯一全局 pending 读。实际 reset/dispose 强制失效。app.mjs:758 仅 currentCollection(taskId) 仍匹配时使导航失效，无新增请求；这个 app 调用条件本报告按源码核对，未将其计入独三的动态覆盖。

Skill 按产品阶段选择并实际读取 RevOps，以“本人可理解的待处理下一步、未知与真实零分开、技术证据不等于获客结果”核验本次改动；无外部营销或费用动作。

## 验证边界

本次导航数字是全部当前有权评论的待处理条数，不是去重客户人数、获客成果、联系已送达、资源部接收、成交或到账。真实平台、真实账号状态、商业许可审核及真实客户质量不由本测试证明。Phase20 的旧 source/hash 作为历史冻结记录保留，不能与 Phase21 当前源码混用。真实 GUI和全量前端名单由根独立归档；本报告不预先声称它们已经完成。
