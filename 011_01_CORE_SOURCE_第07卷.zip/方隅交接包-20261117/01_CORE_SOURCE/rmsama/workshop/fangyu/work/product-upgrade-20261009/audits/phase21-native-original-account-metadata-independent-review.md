# Phase21 原账号元数据候选独立审查

2026-10-10。结论：**未见执行阻塞，可由 root 在既定原账号范围内执行一次候选**。本审仅读取代码、候选报告、manifest 和已有合成证据，未执行 Scheduler、原生 helper、CLI 或网络，未读取原 DATA、实际数据库、Cookie、vault 或密钥。未改候选及既有 Phase21 证据，未重复原三组测试，也不新增测试覆盖计数。

候选 manifest 的七份文件当前 SHA 全部匹配。关键源码为：

| 文件 | SHA256 |
| --- | --- |
| `work/product-upgrade-20261009/phase21_native_original_account_metadata.py` | `318DEFE33F3D999F6E7DA4B8E57595E80E4CB95EC462712E2A270B736583517A` |
| `work/product-upgrade-20261009/phase21_run_native_metadata_once.ps1` | `4D53364A061F8E51D3E1B0247C71937E3BCA296A29F29975E8D50BB4CC065C05` |
| `work/app/src/core/account_safety.py` | `93C989A33F07031F7A728E1847B7EFBD075699F7C5B8EBDB165680657FB646CC` |

## 已核代码边界

- Python 第50–73行要求 Windows 原生无 package identity，并从 KnownFolder 获得精确 `C:/Users/rmsama/AppData/Local`。第101–118行固定 DATA 名称，拒影子目录、重解析路径，以及非空 WAL/rollback journal。CLI 只接收32位 run-id，没有客户端 DATA/账号/owner 参数。
- 第119–124行用 `mode=ro&immutable=1`、query_only、只读 authorizer 与 BEGIN；`closing` 在成功、异常或早返回后都关闭连接。没有 checkpoint、修复、备份或原目录写操作。SQL 取固定 JSON 字段，未 SELECT body 或任意客户正文；固定账号缺失只返回未找到。
- 第83–90行直接加载成熟 account_safety 模块，不经过 core/__init__、Core、AssistantService、AppServer 或适配器。该模块顶层只有定义和本机线程锁对象；实际调用 summarize_activity 只读取活动文件，没有启动线程、云/AI请求或人工复核写入。
- 输出严格投影：owner/UID 只有 presence 和 SHA，账号/任务状态枚举及规范 opaque ID；device.dpapi 仅检查文件存在，内容核验恒 false。活动只保留状态、固定 reason 和非负计数/字节数，不输出自由错误、昵称、手机号、评论、Cookie、password/key 或原始日志。未知、损坏、无活动不会被 cached ready 覆盖。
- PS1 第10–24行每次生成 GUID 唯一任务，当前 Windows 用户 Interactive/Limited，固定项目 Python/script，无 trigger、Force、密码、Highest 或旧任务覆盖。确实会注册 Scheduler 并启动一个短命 Python 进程；这不是 Scheduler 零写。不会启动/停止助手、修改桌面、运行平台 CLI 或更改账号权限。返回 execution_finished=false，不把登记当完成。
- 结果第197–214行仅写项目 audits 下本次 run-id 文件，存在即拒，不覆盖旧结果。异常统一成固定 rejected/unavailable code，不输出异常正文；失败/缺输出不自动重发。

## 既有合成证据与实际限制

已读取 B 的三组合成源码和日志：3/3、0.249s，包含实际合成 SQLite 的0DML/文件字节不变、凭据文件打开守卫、禁止 Core/assistant 导入与网络/进程、影子/其他公司/WAL拒绝、cached ready 与损坏/缺活动分开。这些是 B 执行的证据，C 没有重跑，不能算 C 新三组，也不是原生 Scheduler 或原库结果。

唯一需要保持的执行先决事实是原实例保持未运行。immutable 不提供跨进程写锁，预先检查 WAL/journal 也不排除另一进程随后开始写；helper 明确 instance_absence_verified_by_helper=false，不能自证停机或自动关闭实例。此边界已在候选文档公开，不要求另造启动/恢复机制。

保存 cloud_bound/disabled、owner/UID 哈希、device 文件存在和 cached ready 都不是当前云会话、原设备绑定内容或平台登录证明。summarize_activity 的请求/风险计数为最近30天且保留最多5000条的诊断摘要，不是完整历史或可采集许可；无活动的0也不能当已核实安全。root 应只接收本次 run-id 的 read/rejected/unavailable 输出并继续区分这些事实，不据此自动清风险、运行采集或调用公司/model。

报告文件：`C:/积木软件工坊/项目/方隅公寓客户版/work/product-upgrade-20261009/audits/phase21-native-original-account-metadata-independent-review.md`。

所在文件夹：`C:/积木软件工坊/项目/方隅公寓客户版/work/product-upgrade-20261009/audits`。
