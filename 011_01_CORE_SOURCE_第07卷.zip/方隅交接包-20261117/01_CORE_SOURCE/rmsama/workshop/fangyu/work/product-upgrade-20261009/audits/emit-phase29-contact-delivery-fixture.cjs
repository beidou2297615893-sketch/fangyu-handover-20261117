/* Safe actual-entry evidence; never serialize released phone/WeChat/ciphertext,
 * credentials, KMS request material or low-entropy plaintext hashes. */
'use strict';
const path=require('node:path'),fs=require('node:fs'),crypto=require('node:crypto'),assert=require('node:assert/strict');
const PROJECT=path.resolve(__dirname,'../../..');
const {fixture,PUBLISH,REVEAL,WITHDRAW}=require(path.join(PROJECT,'work/cloud/workspace/contact-delivery-fixture.cjs'));
const paths=['work/cloud/workspace/contact_delivery.cjs','work/cloud/workspace/kms_contact_provider.cjs','work/cloud/workspace/service.cjs',
 'work/cloud/workspace/contact-delivery-fixture.cjs','work/cloud/workspace/contact_delivery.test.cjs',
 'work/product-upgrade-20261009/audits/phase29-contact-delivery-local-fixture.py'];
const sha=raw=>crypto.createHash('sha256').update(raw).digest('hex');
const budgets={};
function budget(label,f){const calls=f.data.operations(),counts=calls.flat();for(const n of counts)assert.ok(n.reads+n.writes<=100);
 budgets[label]={transaction_invocations:calls.length,callback_invocations:counts.length,max_callback_operations:Math.max(0,...counts.map(n=>n.reads+n.writes)),
  max_callback_reads:Math.max(0,...counts.map(n=>n.reads)),max_callback_writes:Math.max(0,...counts.map(n=>n.writes))};}
async function emit(){
 const f=await fixture(),cases={};f.data.resetOperations();
 cases.ready_to_publish=await f.status(PUBLISH,f.publishBody.idempotency_key);
 cases.published=await f.call(PUBLISH,f.publishBody);assert.equal(cases.published.status,200);
 cases.receiver_ready=await f.status(REVEAL,f.revealBody.idempotency_key,'resource');
 f.loseNextFinish();cases.reveal_response_lost=await f.call(REVEAL,f.revealBody,'resource');assert.equal(cases.reveal_response_lost.status,503);
 f.restart();const before=f.data.snapshot();cases.release_original_metadata=await f.status(REVEAL,f.revealBody.idempotency_key,'resource');
 assert.equal(before,f.data.snapshot());
 cases.source_revoked=await f.call(WITHDRAW,{...f.revealBody,idempotency_key:'phase29-source-revoke-fixture'});
 cases.historical_release_current_revoked=await f.status(REVEAL,f.revealBody.idempotency_key,'resource');budget('published_released_revoked',f);
 const missing=await fixture({configured:false,mode:'metadata'});missing.data.resetOperations();
 cases.provider_unconfigured=await missing.status(PUBLISH,missing.publishBody.idempotency_key);budget('provider_unconfigured_read',missing);
 const noRetention=await fixture({retentionSeconds:null,mode:'metadata'});noRetention.data.resetOperations();
 cases.retention_unconfigured=await noRetention.status(PUBLISH,noRetention.publishBody.idempotency_key);budget('retention_unconfigured_read',noRetention);
 const pending=await fixture();let enter,release;const entered=new Promise(resolve=>{enter=resolve;}),held=new Promise(resolve=>{release=resolve;});
 pending.setKmsHook(async()=>{enter();await held;});pending.data.resetOperations();const started=pending.call(PUBLISH,pending.publishBody);await entered;
 cases.new_key_original_claim_unknown=await pending.status(PUBLISH,'phase29-other-key-only-read');
 assert.equal((await pending.change('acquisition_handoff_withdraw',pending.item,{reason_code:'customer_withdrew'},pending.tokens.source)).status,200);
 release();cases.publish_after_customer_withdrawal=await started;
 cases.original_publish_unknown_current_withdrawn=await pending.status(PUBLISH,pending.publishBody.idempotency_key);budget('publish_await_customer_withdrawal',pending);
 const result={synthetic_only:true,contract:'phase29_contact_delivery_actual_fixture_v1',environment_id:'fixture-env',company_id:'fixture-company',
  evidence_scope:'actual local Cores and current service/createStore with SDK-interface memory callback replay; official KMS Client methods use opaque request stub',
  real_kms:false,real_crypto_verified:false,real_cloud:false,two_physical_machines_verified:false,same_windows_sid:true,
  local_metadata_unconfigured:{decrypts:missing.source.local_decrypts,reveal_audits:missing.source.local_reveal_audits},
  kms_calls:{main:f.counts(),unconfigured:missing.counts(),without_retention:noRetention.counts(),withdrawn_while_encrypting:pending.counts()},
  cases,budgets,source_metadata:paths.map(p=>({path:p,sha256:sha(fs.readFileSync(path.join(PROJECT,p)))}))};
 const text=JSON.stringify(result,null,2);for(const value of Object.values(f.source.values)){assert.ok(!text.includes(value));assert.ok(!text.includes(sha(value)));}
 for(const out of Object.values(cases))if(out.data.delivery)assert.equal(out.data.delivery.contact_values,null);
 return result;
}
if(require.main===module)emit().then(result=>{const output=JSON.stringify(result,null,2)+'\n';
 if(process.argv.length===3&&process.argv[2]==='--save')fs.writeFileSync(path.join(__dirname,'phase29-contact-delivery-actual-fixture.json'),output,'utf8');
 else if(process.argv.length===2)process.stdout.write(output);else throw Error('only fixed --save output is supported');
}).catch(error=>{process.stderr.write(String(error.stack)+'\n');process.exitCode=1;});
module.exports={emit};
