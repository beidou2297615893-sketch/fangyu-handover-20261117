# 运行许可 provider 的具体接点（只读）

本轮只读取本项目源码、既有产品审计与第三方许可静态材料，没有读取公司实配/业务库/DPAPI/Cookie/凭据，没有导入构建器、运行 CLI、访问网络或修改生产。前一短选型报告仍冻结，不改其历史证据。

## 接点与实际契约

- `assistant/product_workspace.py:234/320/321` 从 Server 的 `platform_read_license_policy` 取值，现 `work/app/src` 无生产赋值。它不是新 API，也不应接受前端 payload。
- 该属性必须返回 **dict 或 None**。现 preflight 用 `lambda: getattr(...)` 动态取值；R22 同时把属性传给 `license_policy` 和动态 provider，`core/platform_reads.py:250` 有 `dict(license_policy or {})`。因此直接把 callable 塞进现属性会不兼容。
- 最小后续实现可让 `AppServer` 暴露由可信本地 resolver 计算的只读属性，保持这两消费者不变。缺审核来源返回 `None`，明确否决返回 `{xiaohongshu:false,revision:...}`；只有当前精确路线与证据均匹配才返回 `{xiaohongshu:true,revision:...}`。这只是候选接线，不是本轮写入或授权。
- `core/platform_reads.py:265–276` 的许可摘要**只覆盖各平台 bool 和 revision**。revision 必须绑定所选 transport、精确 package/source/runtime 摘要与审核证据版本，不能在变更证据/路线后仍用常量1或无 revision；否则同为 true 的新旧许可难以令原 owned receipt 失效。preflight 的许可快照也应保持动态复核。

## 可复用的成熟本地材料（不等于整体审核通过）

1. `work/licenses/Apache-2.0.txt` 当前文件 SHA256 为 `CFC7749B96F63BD31C3C42B5C471BF756814053E847C10F3EB003417BC523D30`。与 `work/packaging/build_release.py:27–28/73–86` 的既有正文哈希校验、第三方许可复制及 `小红书CLI来源说明.txt` 一致。仅静态读函数，没有调用构建/预检/复制。
2. `outputs/产品审计/小红书CLI许可与上游评论兼容性_20260926.md`、`第三方CLI依赖许可原件核对_20260926.md` 已有精确来源调查；说明主 CLI 0.6.4 元数据声明 Apache-2.0、wheel 无独立正文，主正文已补，QA 安装目录清单不替代最终冻结分发清单。
3. `work/app/src/resources/licenses/xiaohongshu-cli-upstream-metadata.toml` 与当前 guarded runtime 内 `xiaohongshu_cli-0.6.4.dist-info/METADATA` 一致声明0.6.4/Apache-2.0。本项目 `resources/licenses/DEPENDENCIES.json` 的实际 xiaohongshu 行为 `declared_license_files:[]/copied_license_files:[]/status:missing_license_file_in_distribution_record`。这是该记录中的材料缺口；不能据此推导没有商业权利，也不能用元数据声明推出完整冻结分发已审核。
4. 当前 `app.py:117–156` 的 `guarded_cli_runtime_valid` 复核 exe/tree/source 摘要与 internal QA/release 条件。它证明程序与既定路线相符，**不核验第三方版权/NOTICE**。现 `resources/adapters/xiaohongshu.json` 的 license 字符串、`verified:true` 亦不补这一事实。

后续应先复用现有主正文、来源说明与材料清单，做当前实际选中运行对象的窄核对，不重新下载另一套 CLI 或重做全平台调查；本轮不联网，不提出法律有效性的结论。完整冻结分发的缺项与自营读取的程序入口缺项应分别解释，不把许可文件盘点遗漏自动写成平台账号被禁止。

## 三类许可/门禁绝不能相互映射

| 类别 | 当前成熟来源 | 能说明什么 | 不能代替什么 |
| --- | --- | --- | --- |
| 软件套餐权益 | `core/service_plans.py:67`；`assistant/business.py:142–145`；`product_workspace.py:162–176` | 当前公司功能/期限是否开放 acquisition、strategy 等 | 精确第三方材料、账号登录、平台风控 |
| 开源组件/分发材料审核 | 上述精确材料与未来可信审核版本 | 当前具体路线/分发对象的材料与使用范围核对 | 套餐权益、平台允许批量采集或保证不会461 |
| 账号/平台执行门禁 | `core._platform_execution_guard`、账号活动/UID/占用；`app.py:276–305`、现指定设备流程 | 当前主体/设备/运行库及平台风险是否允许尝试 | 开源权属、完整发行验收、真实稳定性能 |

特别注意：`assistant/private_evaluation.py` 的“私下安装许可”是 CurrentUser DPAPI、EXE/目录/有效期与设备 QA 的运行许可，源码声明不是 production approval。不可将它接为 `xiaohongshu:true` 的商业使用许可。`capability_catalog.license_reviewed` 是说明性目录，也不是可信 provider；不能用前端 checkbox、账户 ready 或孤立测试 bool 开放任何操作。

## 后续最小实施/验收界线

可信 resolver 从**固定服务端位置与当前所选运行对象**读取已核材料/审核记录，拒客户端路线、路径、hash、owner 或许可 true。目前没发现已有完整审核 receipt 可以直接接；不能虚构它。当前 Server 字节/路线守卫仍按原算法独立执行，不放宽 QA 窗口、不自动续期或切换 transport。

只需少量实际组合代表：默认 Server 无依据仍 unknown；缺/改正文或审核与选中 route/runtime 不符不授权；同为 true 但审核版本/路线变化使原摘要不同、原读取不可归档；许可可用时套餐过期、hold、HTTP461、重复 UID、忙账号仍阻断。此阶段无真实平台和目录写。当前主流程“采集结果查看”的路由/task范围修复先由根完成，不与其抢源。

以上闭合后再让用户在原账号界面选账号/设备并确认手机验证和最后未知操作，明确批准少量搜索/主评论/后续页真实样例。软件功能与许可材料由我们尽量独立补齐；真实登录/风险事实和平台执行结果必须来自该授权账号，不能离线造成功或清旧 unknown。
