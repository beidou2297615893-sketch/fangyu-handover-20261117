"""Emit actual local Phase17 safe DTOs with an isolated synthetic adapter seam."""
import hashlib
import importlib.util
import json
from pathlib import Path
import tempfile

HERE = Path(__file__).resolve().parent
PROJECT = HERE.parents[2]
APP = PROJECT / 'work/app'
TEST = APP / 'tests/test_private_strategy_single_batch_entry.py'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    spec = importlib.util.spec_from_file_location('phase17_actual_fixture', TEST)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    paths = [APP / 'src/assistant' / name for name in (
        'business.py', 'strategy_tasks.py', 'acquisition_run_preflight.py', 'product_workspace.py')]
    paths += [APP / 'src/core' / name for name in ('engine.py', 'pipeline.py')]
    paths += [TEST]
    before = {str(path.relative_to(PROJECT)): sha(path) for path in paths}
    base = PROJECT / 'work/product-upgrade-20261009/tmp/phase17-single-batch-json'
    base.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(dir=base) as temp:
        fixture = module.SingleBatchEntryFixture(temp)
        try:
            with fixture.forbid_real():
                task, before_read = fixture.projection_read_evidence()
                preflight = fixture.check()
                request = {'action': 'task_run', 'data': {'task_id': fixture.task_id, 'max_batches': 1}}
                result = fixture.command(request['action'], request['data'])
                after, after_read = fixture.projection_read_evidence()
                workspace = fixture.command('workspace_state')
            value = {'synthetic_only': True,
                'evidence': 'actual_BusinessExecutor_Core_StrategyTasks_isolated_adapter_seam',
                'stage': 'independent_boundary_tests_passed_isolated_adapter_positive_projection',
                'original_task_get': task, 'preflight': preflight, 'run_request': request,
                'business_result': result, 'post_task_get': after, 'workspace_state': workspace,
                'task_count': len(fixture.core.store.list('tasks', fixture.executor.tenant)),
                'fixture_search_count': sum(call[0] == 'search' for call in fixture.adapter_calls),
                'fixture_comment_count': sum(call[0] == 'comments' for call in fixture.adapter_calls),
                'real_platform_requests': 0, 'real_network_requests': 0,
                'real_cloud_or_model_requests': 0, 'real_platform_allowance_verified': False,
                'response_key_recovery_verified_here': False,
                'commercial_outcome_verified_here': False, 'source_metadata': before}
            value['task_projection_evidence'] = {'before_run': before_read, 'after_run': after_read}
            assert before_read['database_dump_unchanged'] is True and before_read['sqlite_mutation_statements'] == 0
            assert after_read['database_dump_unchanged'] is True and after_read['sqlite_mutation_statements'] == 0
            assert task['task']['accumulated'] == before_read['task_persisted_count'] == 0
            assert after['task']['accumulated'] == after_read['task_persisted_count'] == 1
            assert value['task_count'] == 1 and value['fixture_search_count'] == 1
            assert value['fixture_comment_count'] == 1 and result['batches'] == 1
            assert result['imported'] == 1 and result['strategy_completion']['finished'] is False
            serialized = json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False)
            assert 'PHASE17_PRIVATE_' not in serialized and 'FORGED_PRIVATE_WORD' not in serialized
            assert before == {str(path.relative_to(PROJECT)): sha(path) for path in paths}
            path = HERE / 'private-strategy-single-batch-entry-actual-fixture.json'
            path.write_text(serialized + '\n', encoding='utf-8')
            print(json.dumps({'path': str(path), 'sha256': sha(path), 'synthetic_only': True,
                              'task_count': 1, 'fixture_search_count': 1, 'fixture_comment_count': 1},
                             ensure_ascii=False))
        finally:
            fixture.close()


if __name__ == '__main__':
    main()
