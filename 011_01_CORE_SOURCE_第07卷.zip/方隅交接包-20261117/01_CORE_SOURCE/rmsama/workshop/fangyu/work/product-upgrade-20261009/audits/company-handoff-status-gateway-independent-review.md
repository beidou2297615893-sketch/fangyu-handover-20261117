# Phase13 原公司操作状态：独立后端与网关审核

结论：5 项独立代表测试通过。没有发现新的生产阻断；本审核只增加独立测试、日志和报告，没有修改生产或旧测试。测试执行实际临时 Core、SQLite、BusinessExecutor、员工网关、原状态 helper、传输层和 `integrations.request_json`，只将最底层 HTTP opener 隔离。没有真实联网、续期、凭证写入、公司注册/提交、平台联系、模型或部署。

## 主流程与边界

客户端仅传本人 `handoff_id`，原 register action/key/hash/channel 从可信持久 origin 派生。缺 origin 不读会话、不发请求、不建 key、墓碑或记录。有 origin 时，已有 bearer 必须符合格式、员工用户名绑定、有限数值有效期超过当前 60 秒，且没有 pending refresh。临近到期必须由用户另行明确连接，本次核对不会自动续期。

正常查询仅执行一次固定 `acquisition_handoff_operation_status`，发送环境、原 register action 与原 key；没有 refresh/status、me、login、模型或业务重试。返回末再读取配置、完整 session、SQL 员工及本机绑定，变化后拒绝成功投影。外层 exact 7 字段验证后只剥 3 个身份字段，内层原状态 helper 校验 exact receipt 与原 action/key/hash/channel/revision=1/draft。

`mutation_committed:false` 和 `no_dispatch_scope:this_status_query_only` 只描述本次查询。公司 missing 为 unknown，不能证明以前未执行，不消除原准备或另发 key。recorded 仅表示原公司登记与本机冻结摘要对应，不证明本机历史 dispatch、平台送达或资源部实际收件。当前本机可用性及公司撤回状态另列，历史 register 不改成已提交或已接收。来源云绑定、平台、财务与合作权威仍 false，实收/实付仍 null。

## 5 项代表证据

| 代表组 | 实际验证 |
| --- | --- |
| 缺 origin | 构造与 GET 完成期间会话 `_read` 被禁止，结果 no_origin；0 HTTP、0 SQLite 写、0 key/墓碑。 |
| 有效原查询与未知 | full gateway 只一次 status HTTP，原 key 从 origin 派生，timeout=25；正常记录及 unknown 均不写表、不解原 origin。商业套餐到期仍允许本人有权核对。 |
| 到期、缺凭证与错误 | 已过期/近到期/布尔或 NaN 有效期、空或换行 token、错 session 用户、pending_refresh 均 0 HTTP。401、503、URLError、TimeoutError 均只有一次请求，0 retry、0 refresh、0 credential 写，公共错误不带原始错误或凭证。 |
| 格式与历史绑定冲突 | 环境、公司、actor、原 key、payload hash、channel、原 revision/status、实收金额或 extra 字段不匹配时拒绝，不宽容切片或把缺证据包装成功；原 SQLite 行不变。 |
| 返回后晚变化 | HTTP 后 token、有效期、endpoint、环境、vault、company 或 SQL 员工禁用变化时拒绝返回成功；仅测试显式模拟的外部变化保留，不产生查询写入，原 origin 不变。 |

所有测试禁止 `_ai_cloud`、`_cloud`、`_refresh_session`、`verify_identity`、`_write`、网络 socket、平台进程及泛型产品 receipt。有效请求通过真实 `request_json`，底层 opener 收集内存请求，不保存 bearer 或原错误。

第 2 组另使用 D 的 `company-handoff-original-status-actual-fixture.json` 中 recorded 标准 envelope，原封不动经过真实 transport/request_json。该 JSON 由实际项目服务、createStore/repos、SDK 接口兼容内存事务 adapter 产生；本兼容小样设置单独的临时可信 actor/config，只验证 flat 7 字段传输兼容，**没有把另一 fixture 的 origin 伪装为本组 full gateway 的同源成功**。D 的实际 Core→同源服务账本测试另行承担来源与原云 payload 的跨层验证；不是 node-sdk 内部事务引擎或真实云运行。

子审查仅只读复核 transport 调用路径，确认构造不读配置，调用不进入 `_cloud`/续期/me/凭证写路径；其源码审查不额外计为运行测试。

## 日志、计数与冻结

命令：

```text
C:/Users/rmsama/miniconda3/python.exe -m unittest discover -s work/product-upgrade-20261009/audits -p test_company_handoff_status_gateway_independent.py -v
```

独立计数固定 5 项，不重复计入旧阶段或根窗口总矩阵。首跑日志保留：合成 session 漏 `username`，实际成熟门禁正确提前 SESSION_REQUIRED；补正确合成配置后通过。这是 fixture 修正，未修改生产，不记录为产品 RED→GREEN。

最终通过日志 `company-handoff-status-gateway-independent-final-green.log`，5/5、1.752 秒；它只是离线回归耗时，不作真实云延迟、吞吐、业务能力或资源部接收验收。`company-handoff-status-gateway-independent-final-source-check.json` 保存测试前后 7 文件摘要，全部相同。逐文件 SHA 见同目录 `company-handoff-status-gateway-independent-manifest.json`。

| 冻结文件 | SHA256 |
| --- | --- |
| `assistant/company_handoff_original_status.py` | `E18FA2A6F5BAEC170446B680231A3C72C37244F4D3C0752F025ABE1F2E1C4AFD` |
| `assistant/company_handoff_status_transport.py` | `2957FF519B3D7B03908C79CF476ACAEFE9120C95811C3C8DD87D94AF66E3CDFD` |
| `assistant/product_workspace.py` | `75CA1BCFF91573072BBC62927E3FAAEF2CCC7D2A9FE886D5364575767046CC02` |
| `integrations.py` | `A3243435D59567F7BDD8A1886C9455E9276DBB1E71B38033651DDEACC75B36C6` |
| 原准备层 `assistant/company_handoff_preparation.py` | `1C1EB336669D8CE39B5E16DC54501F397CEF30C8E606993CA961D6A977C3359F` |
| D 最终实际合成 fixture | `B8C6748C1F23715710D43A718E535068993A1DB12CB0EDBCC7776D9CED411568` |
| 本轮独立测试 | `17B914A5E8619EE55FC835C398A8D917AAF9741CBCBC36517E51A5DC1509A290` |

前阶段旧源码摘要作为阶段历史保留，不能拿旧摘要冒充当前网关全局终验。该后端报告没有执行新 UI 或 GUI 验收；独立 UI 审查及根窗口实屏证据另行归档。
