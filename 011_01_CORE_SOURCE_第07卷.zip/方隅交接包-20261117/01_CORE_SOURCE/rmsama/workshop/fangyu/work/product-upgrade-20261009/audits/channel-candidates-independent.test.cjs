/* Independent actual createService/createStore SDK replay; synthetic only.
 * No production replacement, external requests or existing database access. */
'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),crypto=require('node:crypto');
const path=require('node:path');
const cloud=path.resolve(__dirname,'../../cloud/workspace');
const {fixture,source,discover,draft,hash}=require(path.join(cloud,'channel-candidates-fixture.cjs'));
const ownedIndex=f=>f.doc('handoff_','index:source:'+hash('source'));

test('independent actual archived copied/external_reported sources remain legitimate candidates without sent or ACK requirements',async()=>{
  for(const kind of ['copied','external_reported']){
    const f=await fixture(),seed=await f.source();
    const event={...structuredClone(seed.event),event_id:crypto.randomUUID(),kind};
    assert.equal((await f.call('contact_events_sync',{events:[event]},'fixture-source-device-token')).status,200);
    const item=await draft(f,event),before=f.data.snapshot();
    const out=await discover(f,[source(f,event)]);
    assert.equal(out.status,200,`${kind} is one of the mature seven immutable journal kinds`);
    assert.equal(out.data.discovery.candidates[0].channel.channel_id,item.channel_id);
    assert.equal(out.data.discovery.local_cloud_handoff_correspondence_verified,false);
    assert.equal(f.data.snapshot(),before);
  }
});

test('independent continuation anchor detects owned-index append and a current-count cursor never authorizes another actor',async()=>{
  const f=await fixture(),p=await f.source();for(let i=0;i<6;i++)await draft(f,p.event);
  const sources=[source(f,p.event)],first=await discover(f,sources);assert.equal(first.status,200);
  assert.equal(first.data.discovery.scan.next_offset,5);await draft(f,p.event);
  const before=f.data.snapshot(),stale=await discover(f,sources,{scan_offset:5,expected_owned_index_count:6});
  assert.equal(stale.status,409);assert.equal(stale.data.code,'CHANNEL_DISCOVERY_INDEX_CHANGED');assert.ok(!stale.data.discovery);
  const foreign=await discover(f,sources,{scan_offset:5,expected_owned_index_count:7},f.tokens.resource);
  assert.equal(foreign.status,403);assert.ok(!foreign.data.discovery);assert.equal(f.data.snapshot(),before);
  for(const extra of [{actor:'source'},{owner:'source'},{company_id:'fixture-company'}]){
    const forged=await discover(f,sources,extra,f.tokens.resource);assert.equal(forged.status,400);assert.ok(!forged.data.discovery);
  }
});

test('independent missing old owned-index metadata is explicitly unavailable despite an existing same-source channel',async()=>{
  const f=await fixture(),p=await f.accepted(),sources=[source(f,p.event)];f.data.remove(ownedIndex(f));
  const before=f.data.snapshot(),out=await discover(f,sources);assert.equal(out.status,200);
  const value=out.data.discovery;assert.equal(value.source_results[0].status,'recorded');
  assert.deepEqual(value.candidates,[]);assert.equal(value.scan.status,'index_unavailable');
  assert.equal(value.scan.complete,false);assert.equal(value.scan.owned_index_count,null);assert.equal(value.scan.next_offset,null);
  assert.equal(value.verified_cash_cents,null);assert.equal(value.verified_paid_commission_cents,null);assert.equal(f.data.snapshot(),before);
});

test('independent archived-source fingerprint mismatch rejects the whole result without exposing raw comment or stale candidate',async()=>{
  const f=await fixture(),p=await f.accepted(),sources=[source(f,p.event)];
  f.data.mutateDoc(f.doc('contact_','event:'+p.event.event_id),record=>({...record,fingerprint:'0'.repeat(64)}));
  const before=f.data.snapshot(),out=await discover(f,sources);assert.equal(out.status,409);
  assert.equal(out.data.code,'CHANNEL_DISCOVERY_SOURCE_CONFLICT');assert.ok(!out.data.discovery);
  const publicText=JSON.stringify(out.data);assert.ok(!publicText.includes(p.item.channel_id));
  for(const text of ['PRIVATE-','[REDACTED:phone_cn]','platform:xiaohongshu','consent:'])assert.ok(!publicText.includes(text));
  assert.equal(f.data.snapshot(),before);
});

test('independent five verified sources, ten audited mixed rows and five final candidate rechecks remain inside actual SDK read cap with zero writes',async t=>{
  const f=await fixture(),sources=[],targets=[];
  for(let i=0;i<5;i++){const target=await f.source('independent-target-'+i);targets.push(target);sources.push(source(f,target.event));}
  const other=await f.source('independent-other');
  // Reverse creation order visits unrelated, match, unrelated, match... so the
  // fifth matching candidate is found on the tenth scanned row.
  for(const target of targets){await draft(f,target.event);await draft(f,other.event);}
  const before=f.data.snapshot();f.data.resetOperations();const out=await discover(f,sources);assert.equal(out.status,200);
  assert.equal(out.data.discovery.source_results.length,5);assert.equal(out.data.discovery.scan.scanned_count,10);
  assert.equal(out.data.discovery.candidates.length,5);
  const operations=f.data.operations();assert.ok(operations.length>=2,'actual service entry and discovery transactions ran');
  for(const transaction of operations)for(const replay of transaction){assert.ok(replay.reads<=100);assert.equal(replay.writes,0);}
  t.diagnostic('Actual SDK callback replay counts: '+JSON.stringify(operations));
  assert.equal(f.data.snapshot(),before);
});
