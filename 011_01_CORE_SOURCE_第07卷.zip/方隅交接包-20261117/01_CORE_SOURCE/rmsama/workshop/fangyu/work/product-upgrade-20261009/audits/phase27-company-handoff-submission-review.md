# Phase27 本机原公司草稿提交：B 实施与阶段审核

本切片把已有本机准备与公司草稿接到现成 `acquisition_handoff_submit`，只交付平台身份引用。公司账本记录 submitted 不等于平台送达、资源部独立接收、成交或现金回款。总体 R01–R25 目标仍未完成；本报告没有真实公司、原账号或 GUI 验收结论。

## 实施范围与成熟复用

新增 `assistant/company_handoff_submission.py`、`assistant/company_handoff_submission_transport.py`，在 `assistant/product_workspace.py` 窄接两个动作。复用已有 preparation / registration / current-channel / source-binding / original-status 的完整来源、当前本人授权、当前公司权限、固定 HTTP 连接检查，不改这些旧模块，也不修改云 API、旧注册历史或本机交接记录。

公开 helper 为 `CompanyHandoffSubmission(core, tenant, owner, company, *, device_id, scope_guard, lead_access, cloud_read, cloud_submit, clock=None).execute(action, data, user)`。新 transport 复用 `CompanyHandoffStatusTransport` 的构造期可信绑定和现有 bearer 检查，没有刷新会话、续权限、登录或自动重试。

- `company_handoff_submission_get` 仅接受 `{handoff_id}`，零 SQL 写；无行不建墓碑，不生成新编号。
- `company_handoff_submit` 仅接受 `{handoff_id, expected_origin_id, expected_handoff_revision, expected_cloud_revision}`，不接受客户端公司、主体、来源、联系人或新云 key。
- 原提交 key 从已持久 origin 和可信 tenant / company / owner 派生；固定云提交体只含 environment / operation / channel / expected revision / key。
- 专属 `company_handoff_submission_attempts` 先在 SQLite `BEGIN IMMEDIATE` 中保存一次 unknown，再调用一次公司提交。并发另一实例只能读取原号。网络不在 SQLite 写事务内执行。
- 已有任何 attempt 后，GET 与再次显式调用提交动作都只按原号恢复，不重新 dispatch，不转新 key，不自动更新 unknown 元数据。
- 写后恢复核对原动作、key、完整 canonical payload hash、固定 channel、原 revision+1 / submitted、历史事件自哈希，并复读当前注册回执、完整来源及详情。`full_historical_chain_verified` 仍 false，不升级为全公司历史链核验。
- 请求首尾及每段 await 复核原来源、同意、本人 / 设备 / vault / environment / 公司；网关对两个新动作额外固定并比较完整可信 company 配置，避免同公司 ID 下旧权限结果返还。

## 固定 DTO 与证据语义

`contract=company_handoff_submission_v1`，36 个公开字段见实际 JSON 和 helper `_result`，前台应按白名单读取，不拼旧 DTO。

`state` 只有 `no_origin | not_attempted | unknown | recorded`。not_attempted 仅表示本机没有提交 attempt，不能推导公司过去从未提交。`attempt.state` 保存本机元数据状态，可能为 unknown，而本次可信原号查询得到 `state=recorded`；这个区别用于重启 / 丢回执恢复。任意 attempt 后 `eligible_for_company_submit=false`。

`original_operation` 表示固定原提交历史，`current_company` 单列当前 revision / status / current consent / historical resource receipt。历史 submitted 可以和当前 withdrawn 并存。历史注册回显 `registration_source_verified=false` 不被改写；首次提交资格由服务端当前精确 register-status + source-binding + detail + 本机授权共同核对。

GET：`read_only=true`、`mutation_committed=false`、`cloud_submit_requested=false`、`no_dispatch=true`、`no_dispatch_scope=this_submission_get_only`。首次确认成功写：`read_only=false`、`mutation_committed=true`、`cloud_submit_requested=true`、`no_dispatch=false`。提交动作遇到已保存 attempt 后只读恢复：`read_only=false`、`mutation_committed=false`、`no_dispatch=true`、`no_dispatch_scope=this_submission_call_only`。这些 false 只描述本次调用，不能清除同号过去或并发实例的未知事实。

`submission_execution_confirmed` 只为 true 或 null，绝不 false。提交前拒绝错误的 `mutation_committed=false`；持久 claim 后的提交错误、失去 scope 或回执不明都为 null；GET 错误只描述查询自身未写。

`storage_scope=local_bridge_company_server_ledger`；`local_only` 为本次未请求公司读的情况。`cross_machine_verified`、旧 `source_cloud_binding_verified`、平台送达、独立财务、合作政策验证、结算、自动重试、平台 / provider 开始、联系人 / 本机交接 / 评级修改字段均 false；两个核验金额均 null。没有解密或透传 DPAPI 手机 / 微信。

## 代表验证与保留的失败证据

独占新增 **3 个有意义方法，最终 3/3 GREEN，5.971 秒**。最终前后 7 个执行源 SHA 一致，云账本为父窗口冻结 `F1237B20…`。重复运行没有增加覆盖计数，没有重复旧全量 511 / 283。

1. 实际 Core 与两个本机 helper 实例竞争一次持久 claim；公司提交 commit 后丢响应，重启按原 key GET 恢复，完整 SQLite dump 相同、零 SQL 写、提交计数保持 1。随后合成独立资源账号接收 / 撤回，历史 submitted 与当前 withdrawn 分离；旧 registration / preparation 行不改。
2. 缺准备、伪造字段 / 版本、晚同意或设备变化、损坏元数据、原回执 hash / revision / historical status 错误保持拒绝或 unknown，不能新 key 重发，也不能传受保护联系方式。
3. 实际 transport 使用服务真实 JSON envelope，经固定隔离 request_json 一次调用；禁止 refresh / verify / config 写，过期无 HTTP、超时和晚绑定保持安全未知；实际 Business / product 网关 GET 包装、无写、晚 vault 和完整公司替换均拒旧结果。

第三方法新增的真实缺陷证据：`phase27-company-submission-company-replacement-red.txt` 中公司同 ID / environment 的可信配置在执行后变化，旧网关仍返回成功，1 fail（1.069 秒）。窄修后原断言通过，日志 `…-company-replacement-green.txt`（1.050 秒），最终同 3 方法全绿。它没有扩大权限模型或新增审批。

首候选 3/3（5.322 秒）与网关候选 3/3（6.220 秒）日志保留，均为阶段历史；最终以 `phase27-company-submission-own-final.txt` 和 `phase27-company-submission-test-source-hashes.json` 为准。

## 实际夹具、冻结与未验事项

`emit-phase27-company-submission-fixture.py` 产生 `phase27-company-submission-actual-fixture.json`：8 个独立实际 Core / createService / createStore 合成场景，36 字段，附真实公司标准 envelope、提交 / 注册 / channel 计数及 12 个来源 SHA。已核每个 source SHA 与当前磁盘一致，无需为封存再次执行。

事务底层是 SDK 接口兼容的内存双回调适配器，**并非 node-sdk 内部事务引擎或真实云数据库**。网络、CLI、真实浏览器、云部署、消息、模型和原 DATA 均未执行。8 场景不是额外 8 个测试方法。原测试、旧 worker、旧 phase evidence 不覆盖。

父窗口云端新增 3 / 旧账本 15 属于其独立证据，不并入 B 新增 3；云晚验证失败可能尝试暂存写后整体回滚，不能笼统声称该写路径零 DML。本机 GET 的实际 SQL 写禁止与 dump 相等是单独证明。

生产源码、test / worker / emitter / JSON 与报告的完整 SHA 在 `phase27-company-handoff-submission-final-hashes.json`。网关两次源码前备份在 `backups/phase27-company-submission/1` 与 `/2`，没有更改原客户库。封存后只允许继续写独审报告；真实问题修改前须通知父窗口并重新锁当前证据。

下一验收是 D 后端独审、C 合同 / 实际 UI 集成及父窗口隔离 GUI。当前尚未开放真实公司提交或资源部接收入口，不将本阶段技术成功写成用户整体认可。
