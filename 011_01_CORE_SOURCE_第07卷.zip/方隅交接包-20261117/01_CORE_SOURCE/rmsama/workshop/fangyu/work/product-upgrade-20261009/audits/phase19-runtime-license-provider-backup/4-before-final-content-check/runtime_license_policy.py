"""Read-only component-review binding for the currently selected guarded CLI.

The host supplies a fixed review at construction.  This module does not create
reviews, authorize accounts, execute tools, or interpret an HTTP request body.
No review means unknown; a component declaration is not an approval receipt.
"""
from copy import deepcopy
from datetime import datetime
import hashlib
import json
from pathlib import Path
import re
import stat
import time


_SHA = re.compile(r'[0-9a-f]{64}')
_MATERIALS = {'license_text', 'component_notice', 'actual_dependency_inventory',
              'review_evidence'}
_ARTIFACTS = {'wrapper_sha256', 'exe_sha256', 'runtime_tree_sha256',
              'guard_manifest_sha256'}


def _hash(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False,
                                    separators=(',', ':'), allow_nan=False).encode()).hexdigest()


def _plain(path, root):
    path, root = Path(path), Path(root)
    relative = path.relative_to(root)
    current = root
    for part in ('', *relative.parts):
        if part:
            current = current / part
        attrs = current.lstat()
        if (current.is_symlink() or getattr(attrs, 'st_file_attributes', 0)
                & getattr(stat, 'FILE_ATTRIBUTE_REPARSE_POINT', 0)):
            raise ValueError('linked artifact')
    if not path.is_file() or not path.resolve().is_relative_to(root.resolve()):
        raise ValueError('missing artifact')
    return path


def _file_hash(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def _tree_stamp(root):
    """Within-call race detection, never a cached substitute for content hashes."""
    root = Path(root)
    attrs = root.lstat()
    if root.is_symlink() or getattr(attrs, 'st_file_attributes', 0) & getattr(stat, 'FILE_ATTRIBUTE_REPARSE_POINT', 0):
        raise ValueError('linked runtime')
    entries = []
    for path in sorted(root.rglob('*')):
        attrs = path.lstat()
        if path.is_symlink() or getattr(attrs, 'st_file_attributes', 0) & getattr(stat, 'FILE_ATTRIBUTE_REPARSE_POINT', 0):
            raise ValueError('linked runtime')
        if path.is_file() and path != root / 'guard-manifest.json':
            entries.append([path.relative_to(root).as_posix(), attrs.st_size,
                            attrs.st_mtime_ns, attrs.st_ctime_ns, attrs.st_ino])
    return _hash(entries)


class RuntimeLicensePolicy:
    """Resolve only the review's exact company, usage scope and artifact route."""
    def __init__(self, review, *, server, source_wrapper, material_root,
                 usage_scope, runtime_validator, usage_scope_provider=None, clock=time.time):
        self._server = server
        self._wrapper = Path(source_wrapper)
        self._materials = Path(material_root)
        self._scope = usage_scope
        self._scope_provider = usage_scope_provider
        self._validator, self._clock = runtime_validator, clock
        try:
            # Never retain the caller's mutable review dictionary.
            candidate = deepcopy(review)
            self._review = candidate if self._valid(candidate) else None
        except Exception:
            self._review = None

    def _valid(self, review):
        if not isinstance(review, dict) or set(review) != {
                'schema_version', 'kind', 'company_id', 'route', 'usage_scope',
                'artifact', 'materials', 'review'}:
            return False
        if (type(review['schema_version']) is not int or review['schema_version'] != 1
                or review['kind'] != 'runtime_component_use_review'
                or review['route'] != 'guarded_cli_v1'
                or review['usage_scope'] not in ('internal_self_use_read', 'customer_distribution_read')
                or not isinstance(review['company_id'], str)
                or not re.fullmatch(r'[a-z][a-z0-9_-]{1,80}', review['company_id'])):
            return False
        artifact, materials, decision = review['artifact'], review['materials'], review['review']
        if (not isinstance(artifact, dict) or set(artifact) != _ARTIFACTS
                or any(not isinstance(v, str) or not _SHA.fullmatch(v) for v in artifact.values())
                or not isinstance(materials, dict) or set(materials) != _MATERIALS
                or not isinstance(decision, dict)
                or set(decision) != {'decision', 'revision', 'reviewed_at', 'reviewer_ref'}
                or decision['decision'] not in ('pending', 'approved', 'denied')
                or not isinstance(decision['revision'], str)
                or not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.:-]{0,159}', decision['revision'])):
            return False
        for entry in materials.values():
            if entry is None and decision['decision'] != 'approved':
                continue
            if (not isinstance(entry, dict) or set(entry) != {'path', 'sha256'}
                    or not isinstance(entry['path'], str) or len(entry['path']) > 500
                    or '\\' in entry['path'] or ':' in entry['path']
                    or Path(entry['path']).is_absolute()
                    or any(p in ('', '.', '..') for p in entry['path'].split('/'))
                    or not isinstance(entry['sha256'], str) or not _SHA.fullmatch(entry['sha256'])):
                return False
        if decision['decision'] == 'approved':
            try:
                reviewed = datetime.fromisoformat(decision['reviewed_at'].replace('Z', '+00:00'))
                if reviewed.tzinfo is None or reviewed.timestamp() > self._clock():
                    return False
            except (ValueError, TypeError, AttributeError, OverflowError):
                return False
            if (not isinstance(decision['reviewer_ref'], str)
                    or not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.:-]{0,159}', decision['reviewer_ref'])):
                return False
        return True

    def _snapshot(self):
        server = self._server
        company = server.company
        manifests = server.core.adapters.manifests()
        selected = next((m for m in manifests if m.get('id') == 'xiaohongshu'), None)
        if not isinstance(company, dict) or not isinstance(selected, dict):
            raise ValueError('route unavailable')
        executable = Path(server.guarded_cli_executable)
        guard_path = Path(server.guarded_cli_manifest)
        if (not executable.is_absolute() or not guard_path.is_absolute()
                or guard_path != executable.parent / 'guard-manifest.json'
                or getattr(server, 'xhs_page_runtime', None) is not None
                or getattr(server.core.adapters, 'xhs_page_runtime', None) is not None
                or selected.get('available') is not True
                or selected.get('prefix_args') != ['xiaohongshu']
                or selected.get('mapper') != 'xhs_v1'
                or selected.get('isolation_guard') is not True
                or Path(selected.get('executable', '')).resolve() != executable.resolve()):
            raise ValueError('different route')
        runtime = company.get('runtime')
        runtime = runtime if isinstance(runtime, dict) else {}
        return deepcopy({'company_id': company.get('id'), 'manifest': selected,
                         'exe': str(executable), 'guard': str(guard_path),
                         'usage_scope': (self._scope_provider() if self._scope_provider is not None else self._scope),
                         'company_runtime': {k: runtime.get(k) for k in (
                             'cli_source_sha256', 'release_approved', 'portable_employee_release',
                             'private_evaluation', 'platform_qa_device_id', 'xiaohongshu_automation')},
                         'release_version': company.get('releaseVersion'),
                         'edition': company.get('edition'), 'auth_mode': company.get('authMode')})

    def _proof(self, snapshot):
        executable, guard_path = Path(snapshot['exe']), Path(snapshot['guard'])
        _plain(executable, executable.parent)
        _plain(guard_path, executable.parent)
        _plain(self._wrapper, self._wrapper.parent)
        guard_hash = _file_hash(guard_path)
        guard = json.loads(guard_path.read_text('utf-8'))
        materials = {name: _file_hash(_plain(self._materials / entry['path'], self._materials))
                     for name, entry in self._review['materials'].items()}
        return {'guard_sha256': guard_hash, 'wrapper_sha256': _file_hash(self._wrapper),
                'guard': guard, 'materials': materials,
                'tree_stamp': _tree_stamp(executable.parent)}

    def resolve(self):
        review = self._review
        if review is None or review['review']['decision'] == 'pending':
            return None
        snapshot, proof = None, None
        allowed = False
        try:
            snapshot = self._snapshot()
            if (snapshot['company_id'] != review['company_id']
                    or snapshot['usage_scope'] != review['usage_scope']):
                raise ValueError('review scope changed')
            if review['review']['decision'] == 'approved':
                proof = self._proof(snapshot)
                expected, guard = review['artifact'], proof['guard']
                if (proof['wrapper_sha256'] != expected['wrapper_sha256']
                        or proof['guard_sha256'] != expected['guard_manifest_sha256']
                        or guard.get('exe_sha256') != expected['exe_sha256']
                        or guard.get('runtime_tree_sha256') != expected['runtime_tree_sha256']
                        or guard.get('source_sha256') != expected['wrapper_sha256']
                        or any(proof['materials'][k] != v['sha256'] for k, v in review['materials'].items())):
                    raise ValueError('review artifact changed')
                # The mature validator reads actual exe bytes and the whole tree
                # once; pinned guard hashes tie those values to this review.
                allowed = self._validator(Path(snapshot['exe']), Path(snapshot['guard']),
                                          self._server.company,
                                          getattr(self._server, 'private_evaluation_capability', None)) is True
                if snapshot != self._snapshot() or proof != self._proof(snapshot):
                    allowed = False
        except Exception:
            allowed = False
        try:
            revision = _hash(['runtime-license-policy-v1', review, snapshot, proof, allowed])
        except (TypeError, ValueError):
            return None
        return {'xiaohongshu': allowed, 'revision': revision}
