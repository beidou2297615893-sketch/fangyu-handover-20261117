# Phase21 原账号真实链路准备：只读核对

核对时间：2026-10-10 12:53–12:56，Asia/Shanghai；随后只读源码复核更正。初版保留于同目录 `phase21-real-account-readiness-before-online-side-effects.md`，SHA `51D2FC70C4903162C1CAB4A7A115EB9FBC3EB8586E70C4606D33491A83C58A38`。本次只读文档、当前 CIM 进程元数据、桌面快捷方式元数据和指定程序 SHA；没有打开真实数据库、Cookie、API key、密码，没有复制原库、启动程序、CLI、平台请求、续期、登录、改源码或改账号状态。

**更正：初版将在线 `assistant_account_safety` 整条调用链称为零写，遗漏了身份解析的副作用，结论不成立。** 下文按实际在线/离线路径分别说明。`account_safety_status` 的最后一次 activity 汇总为读取，不代表其前置身份解析或正常启动也零写。

上述缺陷定位对应修复前 `assistant/service.py` SHA `8648CD1587376437A6571033C1E03F22CEF24BE570F7E7E8C9D95AC0D6E59D35`。随后 root 授权了本机查询的最小源码修复，已另行合成测试：修复后 SHA `4C70366969D75EE801D0121F3ACAC66DA994A70F1F4F281C7C3F412C4EFEE075`，`account_safety_status` 向身份链传 `read_only=True`。下列在线副作用分析保留为缺陷原貌；不能用新源的合成验证证明旧冻结 EXE 已加载修复，也不能因此宣称正常启动变成零副作用。详见同目录 `phase21-account-safety-readonly-review.md`。

## 结论

用户本轮已明确：沿用现有账号，手机端正常。采用这次最新事实，不再沿用 10 月 9 日的手机异常作为“当前仍异常”结论。

桌面原入口仍存在，指向 10 月 9 日的独立网页只读演示程序和原账号 DATA。当前 CIM 范围没有核实到该真实工作台的运行进程，因而不能证明当前电脑会话有效或核实当前原库状态；这也不表示账号异常。原账号可以按成熟入口继续核对，不需要新建账号、换默认浏览器或新增许可审批层。是否启动该命名实例及进行后续一次真实只读代表，由 root 继续执行。

## 当前入口与原数据目录

当前 Shell 读取的桌面快捷方式：`C:/Users/rmsama/Desktop/方隅工作台.lnk`。

目标程序：`C:/积木软件工坊/项目/方隅公寓客户版/work/collection-resume-20261009/web-demo-managed/方隅助手启动器.exe`。

工作目录：`C:/积木软件工坊/项目/方隅公寓客户版/work/collection-resume-20261009/web-demo-managed`。

快捷方式参数精确只含以下两项；剔除这两项后无其他参数，未含 `--assistant`：

```text
--data-dir "C:/Users/rmsama/AppData/Local/fangyu-apartment-clientAssistant" --xhs-browser-readonly-demo
```

此 DATA 是已有交接确认的原生用户原库根目录，本次没有打开其中的 SQLite、账号目录或会话文件。程序入口所在文件夹与 DATA 所在文件夹不同，不能以演示程序目录当原库。

`active.json` 为 release 5 / previous null，实际指定文件 SHA 与历史冻结证明一致：

| 工件 | SHA256（2026-10-10 本次读取） |
| --- | --- |
| 方隅助手启动器.exe | `30E55E5785AEE0A08433CAB4B96D50A7141A480DFB7710F6E143C36F8D5DEFD7` |
| releases/5/方隅公寓本地助手.exe | `34196E9DB6FFB7BB24A1DA23E4E9D461604437CB35D25977B5E10DCA055C93A0` |

冻结构建记录版本 `1.1.8-pilot.1`、序号 5、默认 `guarded_cli_v1`；显式 `--xhs-browser-readonly-demo` 才选择 natural WebView2 页面只读路线，不自动退回 CLI。这是旧冻结包，不是 Phase20 最新源码，也没有据此把最新单批、自然续批功能写成已进入真实安装版。

快捷方式本次来自调用者 Shell 视图，不独立证明原生运行时 DATA。只有实际进程的 EXE、命令参数、有效 running/健康标记和原生文件视图对应后，才能使用该实例的记录；本次没有据快捷方式去猜测打开数据库。

## 当前进程核对与虚拟化边界

12:53 当前 CIM 中与本项目匹配的非预览进程为管理后台 `owner_admin.py`（PID 27404 / 51348），不属于员工工作台。其余匹配的 `native_preview.py`、`private_single_batch_native_preview.py`、`private_natural_continuation_native_preview.py` 属于合成验收窗口；例如 PID 49020 为 Phase20 合成自然续批预览，不能采用其 `phase20-owner`、账号、DATA 或成功记录证明原账号可用。

未匹配到原工作台 EXE、固定 Local 安装程序或原 DATA 的真实命名实例；这是本次进程观察的范围结论，不是永久不存在的判断。不关闭、不调整上述管理或预览进程，不影响其他任务。

历史原生证据曾核实：标准程序目录 `C:/Users/rmsama/AppData/Local/fangyu-apartment-clientWorkspaceApp`，标准 DATA 为上述 `fangyu-apartment-clientAssistant`；MSIX `Packages/OpenAI.Codex_2p2nqsd0c76g0/LocalCache/...` 的 running/空库/影子文件不等于真实原库。10 月 9 日 PID 32100 / 57798 也仅是历史网页演示快照，本次不复用旧 PID/端口。没有找到可依赖的 `--instance` 命名参数；实例应按实际 EXE + 绝对 DATA + 进程/标记对应确认。

## 原账号绑定与最近真实平台证据

以下绑定来自 10 月 9 日原生诊断历史文件，不是本次读取原库所得：原小红书账号本机 ID `a8050d3052c747fa99502b404c25cdba`，原采集任务绑定该账号；当时账号需复核，任务 `blocked`、`inflight=false`。同一诊断记录账号总数 2、业务评论 527、已分析 522、缺正文 5。没有输出裸平台 UID、Cookie 或凭证，也没有把历史计数当成本次重新核验结果。

最近真实平台观察见 `work/collection-resume-20261009/RESULT.md`：

| 北京时间 | 原记录事实 |
| --- | --- |
| 2026-10-09 首次只读搜索 | HTTP200 / completed，产生 search_verified=true |
| 2026-10-09 13:50:50 | comments HTTP200 / completed |
| 2026-10-09 13:51:32 | 下一个 comments HTTP461 |
| 2026-10-09 13:51:37 | verification_required，任务停止并保留断点 |
| 2026-10-09 14:06–14:10 | 原生网页只读演示实例加载、原记录/会话保留；未进行新的平台采集 |

原 500/511 条主要来自受控 CLI；10 月 5 日自然网页实验只完成首批 20 条，随后翻页超时。当前网页路线被选中，不等于自然网页持续分页已验收。手机最新正常也不能倒写旧 461 或推导电脑会话已经恢复。

## 修复前成熟入口与实际副作用边界

1. 核实实际命名实例及原生 DATA 对应仍是第一步。本审查没有启动或发健康请求。正常启动原桌面入口不能称为“零平台纯诊断”：`app.py:1214–1215` 启动 AssistantService 和条件自动更新，`assistant/service.py:456–495` 创建执行 journal、启动 AIWorker 和 AssistantRunner 轮询；在现有条件满足时可能接收/执行已排队命令、联系云端或分析。root 后续若启动，应把这些成熟后台行为纳入本轮边界，不能仅因用户未点采集按钮就宣称无副作用。不要在 MSIX 影子目录、其他客户实例或合成预览里核对原账号。
2. 现有 `assistant_account_safety`，参数只有本人现有 `account_id`，路由 `app.py:737` → `AssistantService.account_safety_status`（`assistant/service.py:610`）→ `_account_activity_path` → `_safety_user`。在线/有 executor 时，`_safety_user` 调用 `_local_user()`，其默认 `read_only=False`；`BusinessExecutor.principal`（`assistant/business.py:225–260`）会保存用户，可能创建 tenant 或升级默认意向规则。**这条现有在线路径不是零 SQL 写读取**，即使最后 `summarize_activity` 只读活动文件。
3. 没有 executor 且满足既有离线绑定条件时，`_offline_safety_user` 读取 vault 绑定和已有 users，验证 owner/tenant/cloud_bound/disabled，不写 principal；此离线路径才是已有的读取逻辑。不能为套用该路径手工改服务状态或禁用后台。现有 `_local_user(read_only=True)` → `BusinessExecutor.principal(read_only=True)` 可复用为最小修复候选：缺用户或已禁用必须拒绝，不能自动创建或复活；此报告更正时未修改生产源码或宣称候选已集成。
4. 现成“人工复核”使用真实当前 activity revision，由成熟 `assistant_account_signal` / `review_completed` 路径处理；它属于显式本机记录动作，本次未执行。成熟路径会检查在途操作和账号互斥，不能删除旧 461、借修改日志清除 unknown，不能用程序伪造用户已经完成复核。
5. 后续原账号一次真实平台只读代表沿既有自然页面演示路线，不切换新账号、不自动回退 CLI，不以旧连续采集按钮代替受控单次确认。应由实际当前本人账号/来源/任务与 fresh guard 决定具体读取；本次未核实到活实例，未提供伪造的当前 task/来源参数。先辨别此旧包支持的成熟单次动作与 Phase20 新源码单批入口，再使用准确现有任务；不能把新源码 private task 格式强加到旧普通持续任务。用户沿现号一次只读样例的授权已由 root 确认，不需新增许可要求。

`account_status` 并非上述零副作用诊断：`assistant/business.py:511` 会 claim 账号并调用 Core `account_check`，后者执行平台 status 动作及更新账号本地状态。若 root 后续选择此平台只读检查，应明确它会产生真实平台读取和本地状态回执，不能列为“无平台请求、0写”。

## 现成门禁与当前缺口

保留既有账号归属、UID 绑定、账号活动复核、采集/回复互斥、原会话、异常停止和已有云权限；不再发明许可层。源代码的 `require_account_safe` 在真实 activity 仍 `review_required` 时会拒绝；最新手机正常是人工恢复事实，不能未经当前记录核验就说门禁已解除。本次尚缺活实例/当前本人账号与 activity 的 fresh 结果，而不是用户再次扫码或新建账号。

已知 CLI 工件/source/guard/tree 曾精确匹配，且历史公司设备曾 ALLOWED，属于历史可信事实，不等于今天已新核对租约或当前自然路线连续可读。Phase19 的依赖库存确有缺少实际发行版本/许可材料的项目，不能宣称已具完整商业分发审核；已有可信用途与材料缺项分别保留，不能仅为测试自授 review、借 CLI review 覆盖 natural transport，亦不要求本轮新增审批流程。

本报告只完成真实链路准备定位。账号当前可读、单次平台成功、连续采集、真实高意向新增及联系交接仍应凭后续真实结果分别验收；未把合成 Phase20、最新源码通过或桌面文件存在写成原账号运行成功。

## 证据入口

- `outputs/交接/新窗口接续.md`：原库/新阶段边界与历史真实入口。
- `memory/sessions/2026-10-09-员工入口与公网自动更新完成.md:15`：原生/影子视图差异、固定 Local 程序和 DATA。
- `work/collection-resume-20261009/RESULT.md:24`：最近 461 与 natural 演示加载事实。
- `work/collection-resume-20261009/native-resume-state.json`：历史原账号任务绑定与安全状态（本次只投影账号 ID/风险/任务状态等固定元数据）。
- `work/collection-resume-20261009/web-demo-build-result.json`、`web-demo-native-proof.json`：冻结程序/源 SHA、精确自然路线历史加载证据。
- `work/app/src/assistant/service.py:534`、`:576`、`:600`、`:610`，`work/app/src/assistant/business.py:225`：在线 principal 写入与现成 read_only/离线路径；当前源码证据，不冒称旧冻结 EXE 已加载当前源。
- `work/app/src/app.py:1214`、`work/app/src/assistant/service.py:456`：正常启动与后台服务副作用，不能包装成纯读诊断。

事实定位阶段只新增/更正本报告及其历史副本。随后获授权的最小修复只改 `assistant/service.py`，新增独立测试/报告；未修改 Phase20 冻结源与 manifest、原 DATA、桌面入口、旧测试或其他实例。新源码证据、原程序事实与尚未运行的原账号平台结果分别记录。
