# 经营核对云来源独立只读审查

审查日期：2026-10-10。范围为 `work/cloud/workspace/business_reconciliation.cjs`、`handoff-ledger.cjs` 的窄 `readBoundItem` API，必要核对 `service.cjs` 接线与已有 contact repository。未改生产源码或测试，未执行云部署、网络、provider、付款或原数据库读取。

## 结论

当前源码未发现新的阻断；原关联订单旧 revision 的历史核验已落盘。该切片返回公司账本中的来源对应、报录、登记审核和历史计算；平台真实性、exact 本机交接送达、客户实收和分成实际付款均没有因此得到证明。

这是独立静态审查结论。B 报告的云新增 12/12、必要 6 组 64/64 和最坏 15 条 revised link /不同政策场景 85 reads / 0 writes，由其实际 service SDK 测试提供；本人未重复运行、未将其计入独立测试数。

早先 `reconciliation-commission-read-review.md` 的页合计/CNY 接口建议是历史提议，未被当前切片采用。现实现不持久假定币种，不提供页金额合计；当前口径以 `currency:null`、`amount_unit:'legacy_cents'` 及本报告为准。

## 来源与私有字段

- `business_reconciliation.cjs:30` 从公司 contact 仓库读取原 `event:<id>` 及 `customer:<id>`，核 device_report、event/employee/device、platform/author/comment、原 lead/text 哈希、双 customer_id、稳定客户编号和非 provisional customer。
- `business_reconciliation.cjs:37` 构造完整原事件字段（有 intent_snapshot 时包含）；`:46` 核已有成熟 contact fingerprint，`:47` 为公开源证据另算递归键排序的 canonical `payload_hash`。
- public source 只保留 ID/hash/owner/device/platform 与 `platform_provenance_verified:false`，不返原评论、reply、sender、来源链接或 intent 私有正文。source missing/conflict 在 `:58` 先结束订单投影，4 类金额均 null。
- 原 fingerprint 仍沿用 contact 账本的 `JSON.stringify` 口径，不是新发明 canonical ledger，也不是外部平台签名。若原记录格式无法满足该口径，结果 fail closed；摘要 hash 对应记录内容，不证明平台原始内容真实。

## 订单与政策历史

- `business_reconciliation.cjs:59` 同时读取 latest deal 与 handoff reverse link；订单缺失、客户不符、reverse channel/customer 不符、金额/退款/status 不合法均走 emptyOrder。
- `business_reconciliation.cjs:65` 核 latest deal 与其历史 revision 全记录一致（仅排除 storage/meta 字段）。
- `business_reconciliation.cjs:68` 最新修复：原 link revision 不同于 latest 时另读对应 `deal_revision:<order>:<linked_revision>`；必需同 order、customer、revision、status_at_link 和 report/review 类型。旧历史缺失或冲突直接返回 `history_missing/history_conflict`，金额全 null。这关闭了只核 latest 后将无原关联版本证据的订单金额展示出来的缺口。
- 原关联版本证据满足、latest 已变更时只标 `link_revision_changed`，展示的是最新报录/历史计算字段，不是把旧 link 声称当前，也不累加多个 revision。
- `business_reconciliation.cjs:77` 读取存量 `policy_history:<revision>`；`:88` 仅在存储计算状态为 calculated、金额有效、原政策快照及两个配置存在时投影原计算分成，不重新计算、不回填旧账。当前政策匹配仅核 revision/rate/window，相应缺证据为 null。
- `business_reconciliation.cjs:75` 的管理员审核是已登记审核；`:87` reviewer 与报录/最后编辑人不同只证明不同用户名被记录，允许 false/null，不能推出独立财务核验。
- `business_reconciliation.cjs:120`、`:126` 保留 currency:null、legacy_cents、verified_cash_cents:null、verified_paid_commission_cents:null 和两财务/合作核验 false；即使数额为 0、空页或管理员已确认也不改为 verified finance。

## 授权、持久范围与只读边界

- `service.cjs:161` 仅把真实 session 中的 username/sessionDigest 交给新 helper；不会把客户端 role/actor 作为可信参数。
- `business_reconciliation.cjs:23` 在自己事务内核 company、同 username 的 session digest、有效期、未禁用且 role 为 admin/operator；`:114` 再核 actor 和 principal。
- `handoff-ledger.cjs:55` 仍按公司 ID + owner/admin/configured manager/指定 receiver 授权；窄 `readBoundItem` 是 server-only 内部 API，依赖 caller 已核真实 actor，不应以后直接暴露原 item 或作为独立客户端 action。
- `handoff-ledger.cjs:72` 核 latest channel event 的 snapshot_hash/chain_hash；`:240` 再核 company 与 current consent/withdrawal。它是当前账本一致性与最新授权检查，不是全历史链外部签名或平台 delivered 证明。
- `business_reconciliation.cjs:116` 结束前再读 bound item，核 revision、last_event_hash 和 current consent；未知/权限变化不返回部分订单金额。
- contacts/handoffs 使用既有公司隔离仓库。helper 仅 `.get`、不 `.set`、不另造资金账，不开启 provider/platform/payment；limit 1..15，读取结果没有跨页金额合计。

上述是既有同事务 SDK/state 快照内的保护；不将代码存在本身宣称为部署已验或跨机器实测。对未来 `readBoundItem` 的新 caller，真实 actor 复核及 public/private 投影仍是必需约束。

## 本次核对的 SHA256

| 文件 | SHA256 |
| --- | --- |
| business_reconciliation.cjs | D89314D59E8AACD7BBCD6B72FE0FBDB15F8E1088C4623A6B5D85E0787FF609AC |
| handoff-ledger.cjs | 16A544D72C9DB6E0597E3016C4433216D3B7824E4980FB5638A45166BC04A305 |

文件：`C:/积木软件工坊/项目/方隅公寓客户版/work/product-upgrade-20261009/audits/business-reconciliation-source-independent-review.md`

文件夹：`C:/积木软件工坊/项目/方隅公寓客户版/work/product-upgrade-20261009/audits`
