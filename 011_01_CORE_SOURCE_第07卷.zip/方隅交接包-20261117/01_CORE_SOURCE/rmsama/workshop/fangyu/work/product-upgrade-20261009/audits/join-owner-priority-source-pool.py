from pathlib import Path
import hashlib,json,re,stat,sys,uuid
project=Path('C:/积木软件工坊/项目/方隅公寓客户版');stage=project/'work/product-upgrade-20261009';source=project/'work/app/src';candidate=stage/'owner-priority-source-pool-candidate'
review=stage/'owner-priority-source-pool-review-risk/REVIEW.md';receipt_path=stage/'audits/owner-priority-source-pool-joined.json'
if len(sys.argv)!=2 or not re.fullmatch(r'[A-F0-9]{64}',sys.argv[1]):raise ValueError('Require exact independently read review pin')
if receipt_path.exists():raise ValueError('Join already recorded')
def read(path,expected=None):
    attrs=path.lstat()
    if not path.resolve(strict=True).is_relative_to(project.resolve()) or path.is_symlink() or getattr(attrs,'st_file_attributes',0)&0x400 or not stat.S_ISREG(attrs.st_mode) or attrs.st_nlink!=1:raise ValueError('Non-plain project file')
    raw=path.read_bytes()
    if expected and hashlib.sha256(raw).hexdigest().upper()!=expected:raise ValueError('Pin changed: '+str(path))
    return raw
review_raw=read(review,sys.argv[1])
if b'PASS_LIMITED' not in review_raw:raise ValueError('No independent limited code pass')
frozen_raw=read(candidate/'FROZEN.json','88E16873B681654A14141F36ECBAA8C7656E59BD20D0A655A279AD3BFF2D48C0');frozen=json.loads(frozen_raw)
for item in frozen['artifacts']:
    path=candidate/item['path']
    if not path.resolve(strict=True).is_relative_to(candidate.resolve()):raise ValueError('Freeze path outside candidate')
    if len(read(path,item['sha256']))!=item['bytes']:raise ValueError('Frozen bytes changed')
specs=[('assistant/self_operating_read.py','F0344278B270B71455D4A4B9B5EA1CB2F76C221B32DC8114CD0F918803AE539E','8308A306AB6EB16A492AAD1F20089372F908B27A49354AE3A24EA768CEF18182'),('web/workspace/self-operating-read.mjs','2B47E4E04AD096EC8DAA4A2395409B45475331FA4B82BE4646FEF5C390B3440C','898F99763DF41A47C8F374DCFCA5E600322F370330CFAB150833355CAEEC2E59')]
protected=json.loads(read(stage/'audits/ui-approved-owner-four-pages-v3-joined.json'))['backend_protected']
protected.pop('assistant/self_operating_read.py')
protected['web/workspace/upgrade-ui.css']='38A3ED20F6C7A6B0E53F23634E2D0F0F9A32C16522869D27168FC2966DFDF7F1'
for name,pin in protected.items():read(source/name,pin)
changes=[]
for name,parent_pin,new_pin in specs:changes.append((source/name,read(source/name,parent_pin),read(candidate/'src'/name,new_pin),parent_pin,new_pin))
backup=project/'backups/owner-priority-source-pool'/uuid.uuid4().hex;backup.mkdir(parents=True);records=[]
for i,(target,old,new,parent_pin,new_pin) in enumerate(changes):
    if target.read_bytes()!=old:raise ValueError('Parent changed before write')
    saved=backup/(str(i)+'.bin');saved.write_bytes(old);target.write_bytes(new);read(target,new_pin)
    records.append({'target':str(target),'backup':str(saved),'parent_sha256':parent_pin,'applied_sha256':new_pin,'bytes':len(new)})
for name,pin in protected.items():read(source/name,pin)
receipt={'schema':'owner_priority_source_pool_join','source_batch':36,'targets':records,'protected_unchanged':protected,'review_sha256':sys.argv[1],'frozen_sha256':hashlib.sha256(frozen_raw).hexdigest().upper(),'scope':'CODE_AND_SYNTHETIC_DURABLE_INPUT_PREDICATE_VERIFICATION_ONLY','real_platform_verified':False,'production_AI_or_archive_submission_chain_executed':False,'original_App_restarted':False,'current_main_hotpatched':False,'customer_data_modified':False,'old_running_backend_priority_enabled':False,'Computer_Use_or_browser_QA':False}
receipt_path.write_text(json.dumps(receipt,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'source_batch':36,'joined_files':len(records),'protected_unchanged':len(protected),'running_App_unchanged':True,'real_verification_deferred':True}))
