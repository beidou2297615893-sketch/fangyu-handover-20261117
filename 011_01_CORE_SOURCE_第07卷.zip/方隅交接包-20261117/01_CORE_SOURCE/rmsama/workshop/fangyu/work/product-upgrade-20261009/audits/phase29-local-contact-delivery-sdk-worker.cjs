'use strict';
/* Actual current service/store and SDK-interface RAM double callback, not SDK engine. */
const assert=require('node:assert/strict'),readline=require('node:readline');
const {fixture}=require('../../cloud/workspace/contact-delivery-fixture.cjs');
let f=null,calls={publish:0,reveal:0,withdraw:0,status:0,detail:0};
async function command(x){
 if(x.kind==='init'){assert.equal(f,null);f=await fixture({source:x.source,configured:x.configured!==false,
   retentionSeconds:Object.hasOwn(x,'retentionSeconds')?x.retentionSeconds:3600});return {item:f.item,tokens:f.tokens};}
 assert.ok(f);
 if(x.kind==='call'){
  const action=x.operation,actor=x.actor||'source';f.data.resetOperations();const before=f.data.snapshot();
  const contact=action.startsWith('acquisition_contact_');
  if(action==='acquisition_contact_publish')calls.publish++;
  else if(action==='acquisition_contact_reveal')calls.reveal++;
  else if(action==='acquisition_handoff_withdraw')calls.withdraw++;
  else if(action==='acquisition_handoff_detail')calls.detail++;else calls.status++;
  const result=contact?await f.call(action,x.data,actor):await f.cloudCall(action,x.data,f.tokens[actor]);
  const pure=action.endsWith('operation_status')||action==='acquisition_handoff_detail';
  const operations=f.data.operations();if(pure){assert.equal(before,f.data.snapshot());
   for(const pair of operations)for(const n of pair)assert.equal(n.writes,0);}
  return {result,operations,stored_documents_unchanged:pure?before===f.data.snapshot():null};
 }
 if(x.kind==='counts')return {...calls,...f.counts()};
 if(x.kind==='lose'){f.loseNextFinish();return {ready:true};}
 if(x.kind==='restart'){f.restart();return {restarted:true};}
 if(x.kind==='kms_fail'){f.setKmsHook(()=>{throw Error('synthetic KMS result missing');});return {ready:true};}
 if(x.kind==='permissions'){await f.mutate(s=>{s.acquisitionPolicy.receivers.resource=x.enabled?['resources']:[];});return {changed:true};}
 throw Error('unsupported fixed synthetic command');
}
const lines=readline.createInterface({input:process.stdin,crlfDelay:Infinity});
(async()=>{for await(const line of lines){try{process.stdout.write(JSON.stringify(await command(JSON.parse(line)))+'\n');}
 catch(e){process.stdout.write(JSON.stringify({fixture_error:e.message})+'\n');}}})().catch(()=>{process.exitCode=1;});
