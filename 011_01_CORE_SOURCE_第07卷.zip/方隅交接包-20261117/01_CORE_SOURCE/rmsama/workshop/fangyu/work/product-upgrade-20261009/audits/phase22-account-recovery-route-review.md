# Phase22 原账号恢复路径只读筛选

2026-10-10。结论：**不要用正常 `--xhs-browser-readonly-demo` 启动来实现零后台的恢复核对。现有独立 owned login helper 可复用作本人浏览器登录的候选诊断；没有满足“无 Runner/AI/云队列、旧风险不清、原账号完整恢复”全部约束的现成完整入口。**

root 已报告原生一次元数据结果为 stored login_required、activity review_required/not_authenticated；用户说手机正常。C 接受这两个来源各自的事实，未另读原 DATA。本文仅查当前客户版源、已有测试及脚本，没有启动、联网、执行 CLI、读取真实库或凭据、修改生产、打包或部署。未执行/重复测试，不新增测试覆盖计数。

## 最小成熟复用点

`C:/积木软件工坊/项目/方隅公寓客户版/work/app/src/app.py:1074–1079` 先分发 owned helper，成功后在正常 AppServer/AssistantService 初始化之前返回。`assistant/owned_helper_dispatch.py:24–34` 的 `--owned-xhs-login-helper` 固定 live/staging/cancel/profile 形状；`assistant/owned_helper_process.py:69–88` 同时有源码 Python 和冻结 exe 的成熟 argv 构造。不需要重新包装部署来复用这个组件。

其实际窗口是 `assistant/browser_login_window.py:397` 的 run_login_window，已有原账号专属 `xhs-browser-profile`、24hex job staging/cancel、自然身份模式、取消与超时机制。`login_natural_proof.py:create_spec` 绑定已保存 UID（若有）、job 与私有 proof key；`native_login_observer.py` 只观察页面自身 getMe；`login_natural_identity.py` 要求同当前文档/frame、确切 GETME、请求 cookie 与候选 cookie 一致，返回 UID 必须匹配原绑定。`verified_status:150–170` 只验证本机 proof 的 scope/MAC/digest，不再发 CLI status 请求。

推荐的最小下一步是只复用这个 **候选诊断段**：由原本人显式打开原账号窗口，必要时本人手机扫码/完成平台提示；取得原 UID 对应的 natural proof 后，仅输出固定身份核对状态。没有有效 proof、错误 UID 或验证提示就停，不自动重试、改账号、清风险、claim 或 commit。原浏览器 profile 也可能已有有效会话；不能凭 stored login_required 预断它必需重扫，更不能宣称扫码已经发生。

这不是可直接绕过父层门禁的命令建议。owned helper 的授权仍归原私有 job 调用者；直接给 guard=None 或伪造在线 service 不能当已成熟的安全恢复路线。若要新增一回恢复诊断宿主，应复用既有 saved 本人/原账号归属、原 profile/job 路径、取消与账号执行锁，不另扩账号/客户范围；当前源未提供这个独立可信宿主。此报告没有实施它。

## 当前完整路线为何不适用

- `app.py:252–266` 的 browser-readonly-demo 仅启用自然页面 transport；`main:1212–1215` 仍调用 AssistantService.start 和自动更新。绑定助手会轮询云命令、启动 AIWorker/Journal/contact sync，不能承诺零后台云或模型行为。
- `assistant/browser_login_service.py:start_browser_account_login:314–333` 要求 online、非 remote hold、现有平台门禁及 require_account_safe。`core/adapters.py:271–275` 对任何 review_required 拒绝重新登录；`_snapshot:263–298` 在执行中又复核同一风险。现 root 报告的 not_authenticated 风险会阻断此流程，不可为了扫码自动调用 review_completed。
- 成熟 service 成功路径先 status，再 `_claim_xhs_account`（browser_login_service.py:487–493 的云身份 claim），再 commit_browser_session。自然模式可免 CLI status，却不会免云 claim。`browser_session_commit.py:299–312` 会替换原 Cookie 并更新原 accounts 为 ready；这是真实凭据/数据库写入，不是纯读诊断。
- `Core.handle('account_check')` 也不是纯读入口：engine.py:503–543 会执行 status、核 UID 并写 account/必要时暂停相关 task。账号安全摘要 `assistant_account_safety` 现在可只读，但仅看本机历史，不能证明当前平台会话。
- `account_browser.py` 的独立 Chrome/Edge 入口目前不支持小红书。旧 `native_login_diagnostic.py` 是历史日志/库诊断脚本，既不提供扫码，又遍历 accounts body 和原目录；不优于 Phase21 精确元数据 probe，不能当恢复入口。

## 副作用与证明边界

独立 live helper 会打开平台网站，页面自身会发网络请求；本人登录会写原账号 WebView2 profile，并在 job staging 写候选 Cookie、proof 与固定 outcome。它不会启动 Core/Service/Runner/AI，也不会由自己调用公司云 claim、改原 CLI Cookie 或写业务库。**候选不是原账号会话已提交，网站网络也不能称零请求。**

自然身份组件只观察精确 getMe，但 `MAX_IDENTITY_REQUESTS=32`；单次诊断动作不等于恰好一次 HTTP，页面仍有其他自身资源/登录请求。现有 coordinator 的 one-status 指单次 status 回调；自然模式回调是本机 proof 检查。不能把这些合成测试解释为真实请求数上限或平台放行。

登录成功与旧风险的处理必须分开。独立候选 proof 不清 review_required、不登记人工复核、不赋予采集许可；原登录状态、原会话提交、企业绑定、一次只读样例应分别核对。当前完整 service 在此风险下会拒登录；若最终目标必须写回原账号并运行样例，尚需另行明确的窄恢复实现，不能伪称已有闭环。

已查的成熟合成测试包括 `test_browser_login_service.py:test_one_status_then_claim_then_commit_and_cleanup`、`test_natural_proof_uses_existing_claim_commit_without_cli_probe`、`test_natural_missing_proof_never_claims_or_uses_cli`、`test_cloud_hold_blocks_helper_before_spawn`；`test_browser_login_window.py` 的原 profile、一次候选捕获、scope/cancel/自然证据撤回；`test_login_natural_proof.py` 的 MAC/digest/UID mismatch。C 只读了这些证据源码，没有重跑或据此宣称原账号实测成功。

报告：`C:/积木软件工坊/项目/方隅公寓客户版/work/product-upgrade-20261009/audits/phase22-account-recovery-route-review.md`。

文件夹：`C:/积木软件工坊/项目/方隅公寓客户版/work/product-upgrade-20261009/audits`。
