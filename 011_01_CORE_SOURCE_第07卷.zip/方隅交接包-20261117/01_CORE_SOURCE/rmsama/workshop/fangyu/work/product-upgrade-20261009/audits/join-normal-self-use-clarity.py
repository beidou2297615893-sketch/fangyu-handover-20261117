from pathlib import Path
import hashlib,json,stat,uuid

project=Path('C:/积木软件工坊/项目/方隅公寓客户版')
stage=project/'work/product-upgrade-20261009';source=project/'work/app/src'
candidate=stage/'normal-use-workspace-clarity-candidate'
receipt_path=stage/'audits/normal-self-use-clarity-joined.json'
if receipt_path.exists():raise ValueError('Already joined')
def read(path,pin=None,size=None):
    attrs=path.lstat()
    if (not path.resolve(strict=True).is_relative_to(project.resolve()) or path.is_symlink()
            or getattr(attrs,'st_file_attributes',0)&0x400 or not stat.S_ISREG(attrs.st_mode)
            or attrs.st_nlink!=1):raise ValueError('Require plain project file')
    raw=path.read_bytes()
    if pin and hashlib.sha256(raw).hexdigest().upper()!=pin:raise ValueError('Pin changed: '+str(path))
    if size is not None and len(raw)!=size:raise ValueError('Size changed: '+str(path))
    return raw
frozen_pin='DCE8096C5A2E15AF49FA694CABDE1E4795E9FFBA1E365924D853222C9D53FBEB'
review_pin='05AC8DA94D2444B4AE8BF88F63828FDCBA0D92D76A447709F598AEB951EBB220'
review=read(stage/'normal-use-workspace-clarity-review/REVIEW.md',review_pin,4148)
if b'PASS_LIMITED' not in review:raise ValueError('Require independent review')
frozen=json.loads(read(candidate/'FROZEN.json',frozen_pin,3015))
if frozen['parent']!='Source40' or frozen['actual_visual_verified'] is not False:
    raise ValueError('Unexpected scope')
for item in frozen['items']:read(candidate/item['path'],item['sha256'],item['bytes'])
manifest=json.loads(read(candidate/'SOURCE_HASHES.json',
    'F0FAF0532F543902ACCDCC0BBDD9661DC2BFCA171102756EE626CA444D9E9D0D',1161))
targets={
 'web/workspace/self-operating-read.mjs':('859B46CF9590C4A403BAC355E521B2ABD0B49AB62A45F319B882EE27FC0454EF',318980,
    '00E7865951866B35F2D0585B468B87AE281294F85D7938C73C10905FE3ACF19E',320644),
 'web/workspace/upgrade-ui.css':('38A3ED20F6C7A6B0E53F23634E2D0F0F9A32C16522869D27168FC2966DFDF7F1',86769,
    '2C0B912C0E8B2C3ED48E30DDC5363F0F875AC6ED4CBB8A793EB0143B1CE14162',92220)}
if len(manifest['targets'])!=2 or {x['target'] for x in manifest['targets']}!=set(targets):
    raise ValueError('Require exact two logical targets')
changes=[]
for item in manifest['targets']:
    name=item['target'];parent,old_size,new_pin,new_size=targets[name]
    if item['parent']!={'sha256':parent,'bytes':old_size} or item['candidate']!={'sha256':new_pin,'bytes':new_size}:
        raise ValueError('Manifest differs from reviewed target')
    changes.append((source/name,read(source/name,parent,old_size),read(candidate/'src'/name,new_pin,new_size),name))
css='web/workspace/upgrade-ui.css';parent,old_size,new_pin,new_size=targets[css]
mirror=project/'work/cloud/workspace/site/upgrade-ui.css'
changes.append((mirror,read(mirror,parent,old_size),read(candidate/'src'/css,new_pin,new_size),'existing_local_css_mirror'))
previous=json.loads(read(stage/'audits/owner-xhs-source-locator-joined.json'))
if previous['source_batch']!=40:raise ValueError('Require Source40')
protected=dict(previous['protected_unchanged']);protected.pop(css)
for record in previous['targets']:
    path=Path(record['target']);name=path.relative_to(source).as_posix()
    if name not in targets:protected[name]=record['candidate']
for name,item in protected.items():read(source/name,item['sha256'],item.get('bytes'))
backup=project/'backups/normal-self-use-clarity'/uuid.uuid4().hex;backup.mkdir(parents=True)
records=[]
for i,(target,old,new,name) in enumerate(changes):
    saved=backup/(str(i)+'.bin');saved.write_bytes(old)
    records.append({'target':str(target),'name':name,'backup':str(saved),
        'parent':{'bytes':len(old),'sha256':hashlib.sha256(old).hexdigest().upper()},
        'candidate':{'bytes':len(new),'sha256':hashlib.sha256(new).hexdigest().upper()}})
(backup/'MANIFEST.json').write_text(json.dumps(records,ensure_ascii=False,indent=2),encoding='utf-8')
for target,old,new,name in changes:
    if read(target)!=old:raise ValueError('Parent changed before write')
for target,old,new,name in changes:
    target.write_bytes(new);read(target,hashlib.sha256(new).hexdigest().upper(),len(new))
for name,item in protected.items():read(source/name,item['sha256'],item.get('bytes'))
receipt=dict(schema='normal_self_use_clarity_join',source_batch=41,targets=records,
    logical_targets=2,protected_unchanged=protected,frozen_sha256=frozen_pin,review_sha256=review_pin,
    scope='CODE_AND_RECORDED_COMPOSITION_ONLY',actual_visual_verified=False,
    actual_App_verified=False,current_main_hotpatched=False,original_App_restarted=False,
    customer_data_modified=False,Computer_Use_or_browser_QA=False,cloud_deployed=False,
    legacy_and_recent_code_retained=True)
receipt_path.write_text(json.dumps(receipt,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'source_batch':41,'physical_targets':len(records),'logical_targets':2,
    'protected_unchanged':len(protected),'actual_App_verified':False}))
