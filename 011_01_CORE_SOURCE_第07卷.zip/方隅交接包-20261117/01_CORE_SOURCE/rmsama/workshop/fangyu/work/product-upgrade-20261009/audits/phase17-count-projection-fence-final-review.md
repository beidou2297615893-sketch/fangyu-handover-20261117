# Phase17：公开计数末授权窄修复

根代理在独立只读反例后明确批准本修改。仅改生产 `work/app/src/assistant/strategy_tasks.py::project_task`；没有修改 UI、既有权限规则、数据口径、数据库表、HTTP路由、云或旧恢复槽。

最终源码 SHA256：`C7AFF5AA455ABAA942F9E15C2D530AAFBA2DC7F92C9A860D550A11DD62393CD8`。UI保持 `B0E7043F6099CD539BBF14CD29E77164C85B2AC5F25CFDD9E287D3DB8B6CECB8`。

计数后，在既有 Core 可重入锁内复用 `_task(task.id,user)`，再次核验真实 saved actor、任务归属及账号权限；全部原任务与 fresh task 内部 `_hash` 不同则抛成熟 `StrategyBusy`，不返回旧版本/旧账号的公开快照。内部摘要没有进入公共字段。`Store.list` 读取连接在这次授权前已关闭，未增加嵌套写事务。

最终源码实际合成 Core 小样：同 task/tenant 两条、其他 task/tenant 排除、stale stored9999不采用；读取返回2，SQL数据变更0、DB dump相等，正文/私有词不投影；原 count后禁用 actor 真反例现拒绝为 `StrategyPermissionError`。两条单独故障注入：计数后换原策略版本或账号绑定，均拒绝为 `StrategyBusy`、不返回旧投影。故障注入自己的准备写入不混进API正常读取的0写证明。

原红结果 `phase17-count-projection-readonly-probe-result.json` 保持；闭合结果见 `phase17-count-projection-readonly-probe-green.json`、`phase17-count-projection-binding-probe-green.json`，来源manifest见 `phase17-count-projection-final-hashes.json`。旧只读报告记录原 `DAEE4C88…` 与原末权限窗口，保留为历史，不能据旧hash宣称当前未修复。

规模仍是整个 tenant leads 的 O(N) 读取，没有性能/真实账号/客户/商业结果验收。原工厂“回调已开始”不能证明已派发指令，因此建议的条件式异常文案已发根代理；本次没有编辑 UI。没有运行旧大矩阵或重复B/C的独立测试。
