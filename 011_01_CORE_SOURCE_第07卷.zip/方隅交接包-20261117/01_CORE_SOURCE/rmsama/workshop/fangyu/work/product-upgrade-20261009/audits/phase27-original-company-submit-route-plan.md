# Phase27：原公司草稿 → 资源部待接单的最小路线

本文件仅为静态方案，2026-10-10。未修改生产源码、未新增或执行测试、未向公司提交、未访问真实账号或 DATA。Phase25 的两个 UI 源、3 个新测试及最终证据保持冻结。按本轮 RevOps 工作流先定义交接阶段和承接动作，再复用现有账本；不是新增 CRM、套餐或许可审批流程。

## 1. 唯一推荐与实际断点

优先补齐 **本人明确确认原公司草稿，进入资源部待接单账本**。这直接连接“自营获客 → 人工沟通 → 授权交接 → 资源部处理”，比继续增加只读核对页更接近用户证明合作价值的目标。

已有本机准备、公司原号草稿登记、丢回执后原号核对、不可变事件精确匹配以及公司当前来源核对。缺的是本机受控提交桥和重启后的提交恢复入口。需求台账 R07/R21 仍明确“所有 submit=false，正式提交及独立接收待完成”。本切片先交付 **平台引用**；手机号、微信 DPAPI 载荷绝不解密或透传。

“提交”只表示公司账本有一条待接单记录；不代表资源部已接收、平台消息已送达、客户已成交或分成已到账。独立接收复用公司已有另一可信主体的 receipt 动作，另行验证；现金与分成核验仍为 false/null。

## 2. 已有成熟实现与证据定位

|位置|现有行为|本轮取舍|
|---|---|---|
|`outputs/产品升级/需求交付与证据台账.md`：R07、R21|原号登记与来源核对完成；资源部正式提交/独立接收未验|明确真实缺口，不重造已完成功能|
|`assistant/company_handoff_registration.py:220–295`|专属本机 attempt，BEGIN IMMEDIATE 单行 CAS；未知/重开仅恢复原 register key|复用生命周期原则，不用通用 receipt 包住非原子网络调用|
|`assistant/company_handoff_channel_check.py:71–112,139–150`|当前详情与原事件/客户/device/接收方/用途/原授权重建 payload digest；各 await 后本机范围复核|复用严格原始证据校验，不接收前端姓名/UID/同意/公司/owner|
|同文件 `:125–127`；registration `:189`|历史登记回显与当前来源对应分列，`eligible_for_company_submit=False`|不改旧字段语义；新 helper 独立判断本次资格|
|`cloud/workspace/handoff-ledger.cjs:130–141`|现有 `acquisition_handoff_submit`：expected_revision CAS、来源本人、draft/当前同意、同企业活跃客户去重、handoff 权益门禁，随后追加审计|直接复用现云动作，不新增公司交接 API 或索引|
|同文件 `:291–329`|动作/原 key/完整 payload 绑定；公司事务内可信会话和 actor；同 key 改 payload 拒绝|新本机 submit key 与 register key 分开，固定保存且不能漂移|
|同文件 `:225–288`|原动作+原 key 的 operation status，历史操作与当前交接分列；不存在返回 unknown/null；历史事件 self-hash 验证，`full_historical_chain_verified=false`|提交丢响应按这个纯读合同恢复；不声称完整云历史链已验证|
|`assistant/product_workspace.py:32–37,219,433`|当前公司动作只有准备/登记/状态/来源核对，尚无本机 company submit 分支|只增窄分支，保留已有入口|

本次读取云 ledger SHA：`BD40CA08F07E2F050E5176D98891045B86014F7D27BBA1E78B929C2F30E21F6C`。这是方案基线，后续改动必须新留源证据，不能沿用 Phase25/旧阶段作为当前验收。

## 3. 登记回显 false 的判断

`registration_source_verified=false` 表示原 write echo 没有被本机保存；它本身不证明公司登记不存在，也不应永久阻断提交。新桥可依据 **可信原 register operation status + 原 origin/payload/key/channel 精确绑定 + 当前公司详情与不可变事件完整对应**，建立独立的本次前置证据，同时保留历史 false。

但前端 `current_channel_source_matched=true`、缓存 DTO 或一次旧 GET 不能授权写操作。新 helper 必须自行读取并核对：

1. 当前本机 saved actor、tenant/company/environment/device、原 origin、原交接版本和访问权；首尾均一致，handoff 权益只影响新提交，不阻断历史只读恢复。
2. 本机完整不可变来源链及原事件 hash/UID/comment/body/device；当前本机授权、用途、接收方、来源与原准备一致，撤回或风险条件保持 hold。
3. 原 register status 为 recorded，action/key/actor/channel/完整 payload hash/历史 rev1 draft 与 origin 一致。仅“同来源”不能当作该原交接。
4. 当前 company source binding 精确 matched；当前公司 detail 重新核同源、客户、接收方、用途、原授权/引用及 revision。当前状态须 draft、当前同意有效且服务端 `can_submit` 真实成立。
5. 即将提交的完整云 payload 与已保存原 submit key/hash 一致，当前期望 revision 未变。公司服务仍独立执行自己的 CAS、actor/同意/权益/重复客户门禁。

各 HTTP await 都需 fresh 本机 fence；复用有效原 token 的成熟 transport，不能隐式 refresh、重新登录、verify、同步来源或领取云队列。需要明确连接时只给可操作诊断，不自动扩大权限。

## 4. 最小候选接口与持久边界（待主窗口锁定）

新增一个专属 `CompanyHandoffSubmission` helper 与固定目的 write transport；构造参照 registration 的可信 `core/tenant/owner/company/device_id/scope_guard/lead_access/cloud_read/cloud_submit`。不改旧 preparation/source/status DTO，也不改 Phase25 checker。

- `company_handoff_submission_get {handoff_id}`：纯读本机原 submit attempt；不存在不建 row/key/墓碑。有 attempt 只查 `acquisition_handoff_operation_status` 的原 **submit** key，复核历史及当前详情。`read_only=true`、本次 `mutation_committed=false`，不能由此推断原提交未执行。
- `company_handoff_submit {handoff_id, expected_origin_id, expected_handoff_revision, expected_cloud_revision}`：客户端仅表达用户当前确认的原范围。company/channel/source/recipient/purpose/consent/owner/云 key 均由服务器派生；不接受任意新 idempotency key。
- 云写保持既有 exact payload：`{environment_id, operation:'acquisition_handoff_submit', channel_id, expected_revision, idempotency_key}`。

专属本机 metadata row 绑定 actor/tenant/company/env/device/handoff/origin、原 submit action/key/payload hash/期望公司 revision；不存正文、裸 UID、DPAPI 密文副本、密钥或手机号。单 SQLite BEGIN IMMEDIATE 内复核原绑定并 claim，commit 后仅该获胜调用有一次 dispatch 资格，其他实例进入原号只读恢复。网络调用不得处于 SQLite writer 事务中。

初次 preflight 在 claim 前失败，不产生 attempt。claim 后默认 `unknown`；通信超时、响应丢失、写后本机更新失败、晚来源/授权/身份变化均保留原 attempt，不随机换 key、不自动重发。同 origin 的新版本/新页面/重启不能绕开未知。收到明确拒绝也不能仅凭 operation status 缺失宣称历史未提交；本轮错误证明与历史事实分列，先保持原号核对，是否允许后续显式新操作由独立已知终态合同决定，不能在该切片隐式解锁。

公开最小状态可沿用 `not_attempted | unknown | recorded`，并分列：原 submit 历史是否 confirmed、原 revision/status、当前 revision/status/同意、独立接收历史、当前可交付性。original status unknown 必须是 null，不是 false；若当前已撤回仍保留历史 submitted。`platform_delivery_verified=false`，`receipt_evidence_independently_verified=false`，`verified_cash_cents=null`、`verified_paid_commission_cents=null`。

## 5. 先过的唯一最难代表，再必要边界

使用实际 Core、成熟本机 origin、真实 createService/createStore/repos 的 SDK 接口隔离 adapter；只用项目 work 合成数据，不调用真实 SDK 内部事务引擎或网络。

**主代表**：register 真 commit 但丢 write echo → 重启后原 register status/current exact detail 能核对，历史 echo 仍 false → 本人明确确认一次 submit → 云已 commit 但响应丢失 → 双 Core/重启通过原 submit key GET 恢复历史 submitted → register 次数仍 1、submit 次数仍 1、GET 0 SQL 写 → 另一可信资源部主体另做既有 receipt，随后撤回，历史原 submitted 与当前 withdrawn/原独立接收记录分列。

随后只补相关边界：claim 并发只一次 dispatch；晚 local scope/同意/原来源或公司 revision 变化不返回虚假 success；错误 key/原 payload/channel 或审计冲突拒确认；同公司已有活跃客户拒重复；DPAPI contact 不传。缺失/损坏/无权/过期 GET 保 unknown 或安全拒绝，不能重新提交。

需用代表确认现云 write 的实际信任范围：`mutate` 当前没有重新读取来源事件，普通写事务的末 actor/接收方政策核对也不能由此前 detail GET 代替。若隔离 late-change 真反例表明新 helper 的前后 fence 只能发现写后 unknown，则如实保留该边界，提出必要的最窄云事务补强；不为方案想当然改云，也不把 separately matched 当长期 grant。部署/真实资源部送达仍另验。

## 6. 用户路径与本切片完成条件

原准备页明确“提交资源部待接单”；打开先读原 attempt。只有未尝试且 fresh 资格可证时，显示未勾选确认，说明本次仅平台引用。用户勾选后一次提交；unknown/recorded 仅“核对原提交”，重开不能再次出现新提交按钮。资源部独立接收、成交和分成证明继续分列，不用提交计数冒充成交率。

本地代表与原 guards 必要回归、实际合成 GUI 一次提交/原号恢复和加载源 SHA 都完成后，才可说“本机→公司待接单候选链路通过”。不能说真实公司已接单或真实账号业务跑通。当前只是路线方案；后续源文件责任、exact DTO 与最小实施由主窗口锁定。

本轮另有子代理只读核相同路线，结论一致；它未新增测试或修改文件，不纳入测试覆盖计数。
