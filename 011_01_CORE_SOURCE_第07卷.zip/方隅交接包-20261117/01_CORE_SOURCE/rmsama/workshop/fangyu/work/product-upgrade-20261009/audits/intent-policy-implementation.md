# R15/R16 意向规则与公寓资料约束：独立模块交接

2026-10-10。第九版 UI 冻结。本次仅新增两份 Python 模块、两份专项测试与本目录审计证据；没有修改旧评级、原客户数据、会话、云部署或真实平台。

## 当前结论与边界

已完成本机可信规则管理、版本历史、离线预览、本人依据护栏以及公寓资料匹配状态。复用既有五级模型标准与 SQLite 事务，不新造语义分类模型。**本模块没有调用模型；管理员保存的 `criteria` 尚不能单凭本机保存就宣称已影响模型评级。** 共享 Python/云入口由主窗口接入并验证。

明确本人租房需求可以保持 `high/super_high`，即使公寓资料为空、过期或地域/预算与资料不匹配。匹配是请求条件比较，不是租客身份或经济资格排除。`super_high` 仍沿既有“明确约看/索取租赁联系方式/近期入住并提出具体租赁行动”定义，没有新增“必须已有房源”的要求。

旧 AI 与人工评级使用 `legacy=True` 只读投影：保留等级、规则版本，不自动重算、不写历史。既有人工更正优先。当前历史数量 522 属交接证据，本轮没有读取或核验真实业务库的数量。

## 文件与入口

- `C:/积木软件工坊/项目/方隅公寓客户版/work/app/src/core/intent_policy.py`：`normalize_policy` 第 77 行，`facts_summary` 第 119 行，`apply_intent_policy` 第 302 行。
- `C:/积木软件工坊/项目/方隅公寓客户版/work/app/src/assistant/intent_rule_management.py`：`IntentRuleManagement` 第 47 行，可信授权第 74 行，`snapshot` 第 121 行，`assert_snapshot` 第 129 行，`execute` 第 185 行。
- 专项测试：`work/app/tests/test_intent_policy.py` 21 项，`work/app/tests/test_intent_rule_management.py` 18 项。
- 最终哈希：本目录 `intent-policy-source-hashes.json`。源模块 SHA256 前缀分别 `257d522a3554debb`、`c066bbdc3583a2d8`。

模块所在文件夹：`C:/积木软件工坊/项目/方隅公寓客户版/work/app/src/core` 与 `C:/积木软件工坊/项目/方隅公寓客户版/work/app/src/assistant`。审计所在文件夹：`C:/积木软件工坊/项目/方隅公寓客户版/work/product-upgrade-20261009/audits`。

## 动作与数据契约

构造：`IntentRuleManagement(core, tenant, owner, trusted_company)`。公司配置在构造时深复制，请求不能覆盖。管理权限复用可信 `acquisitionStrategy.operatorOwners` 或已持久核对的 admin；operator 仍需绑定。每次执行重新核对持久身份、disabled、tenant、username、role、cloud_bound。

| 动作 | 精确请求字段 | 结果与权限 |
| --- | --- | --- |
| `intent_rules_get` | `{}` | `{summary, policy?}`；普通员工只有摘要，管理员才有私有 criteria/facts |
| `intent_rules_save` | `{policy, expected_revision, idempotency_key}` | `{revision,digest,updated_at,mutation_committed:true,historical_grades_rewritten:false}`；仅管理员 |
| `intent_rules_history` | `{offset?:0,limit?:20}` | `{items,total,offset,limit}`；limit 1–50，仅管理员，当前 owner/tenant |
| `intent_rules_preview` | `{lead_id}` | 已保存且有权 lead + 来源 task 的离线预览；不接受客户端正文，不改原评级、不调用模型 |

`policy` 精确字段：

```json
{
  "name": "租房意向与资料匹配规则",
  "enabled": true,
  "criteria": {"super_high":"既有超高标准", "high":"既有高标准", "medium":"既有中标准", "low":"既有低标准", "very_low":"既有很低标准"},
  "facts": [{
    "id":"apartment-a", "name":"操作员提供的真实资料名称", "city":"", "areas":[], "room_types":[],
    "rent_min":null, "rent_max":null,
    "effective_from":"", "effective_until":"", "evidence_reference":""
  }]
}
```

未提供 policy 内字段使用保守默认；自定义 criteria 必须完整五级，每级 8–240 字。资料最多 200 份，编号唯一，月租为人民币整数或 null；有效期必须含明确时区，结束晚于开始。身份、民族、国籍、年龄、性别、收入资格等资料/排除字段不在 schema 中。填写 `evidence_reference` 只表示操作员登记引用，没有独立验证，更不能证明可租库存。

save 的幂等键 8–128 ASCII 字母数字/下划线/连字符；相同操作返回原回执，相同 key 改 payload/身份拒绝。policy/current、不可覆盖的版本历史和操作回执同事务写入。确定验证/冲突/回滚拒绝标 `mutation_committed=false`；未知数据库或提交异常没有伪造 false，仍由网关未知恢复协议处理。

## 分析与缓存接线

1. 分析开始先 `frozen = rules.snapshot(user)`，冻结 tenant/owner/持久身份指纹、规则 revision/digest/policy。该方法是服务器内部方法，不能向员工公开私有 policy。
2. 既有 `_key` 增加 `POLICY_VERSION`、本地 `frozen.revision` 与 `frozen.digest`。单靠云 profile revision 不足；禁止新规则复用旧版本评级缓存。现有 profile/provider/model/rules_version/源文本校验继续保留。
3. provider 的别名 ID 完整映射回原评论后，对新结果调用 `apply_intent_policy(comment, result, frozen.policy, context={post:...})`。如结果带 id，须与 comment.id 同属映射后的命名空间；不要把 c001 与真实 lead-id 混比。
4. 返回本人 `evidence/key_info` 必须逐字来自本人正文；父帖/上级评论只作上下文。明显第三人、转述、否定、已完成找房、历史经历、源文本指令、泛反应与不明确超高行动进入待人工核对。看房时间不作入住日、工资不作租房预算、IP 不作本人需求城市。
5. 帖子地区误作个人地区时仅清理个人 `content_region/region_status`，不降低有真实本人依据的询盘强度。字段来源错误、关键依据失败则新结果保守 `uncertain`，不伪造 `unrelated` 或低等级。
6. 最终 `core.lock` 内调用 `rules.assert_snapshot(frozen,user)`，**保持同一把锁直到 cache/history/lead 的全部写入结束**，避免规则改变后仍回填旧结果。来源任务/评论与 provider profile 的既有快照检查仍必须执行。
7. 把 `policy_validation` 与 `property_match` 随新结果持久化；不要由匹配未知去覆盖等级。旧缓存只读投影不可回写。人工更正后的有效等级优先，匹配仍待独立核对。

当前 `criteria` 只被保存/校验，不由本机 regex 重新评语义等级。要真实改变 provider 评级，主窗口需在云合同与 prompt 明确绑定受信 policy criteria + revision/digest，并纳入云 AI 请求 hash/缓存/计价回执；仅前端添加字段或收到模型自报“已用规则”不构成证明。员工不能通过公开分析 payload 自赋私有管理权限。未完成该绑定时，页面应说“规则已保存，模型标准接入待核验”。

只读发现既有云 prompt 仍将“外地明确需求”归 unrelated。地域必须改为独立请求匹配，不能以地域拒掉真实本人租房意向；本机护栏不会擅猜被 provider 输出为 unrelated 的等级。

## 匹配结果的准确含义

`property_match.state`：`unknown / needs_facts / needs_review / candidate`。

- 无完整有效资料、过期、未来或无资料引用：`needs_facts`。
- 个人地点及预算/房型不完整、月租含义不明、条件不同：`needs_review`，原意向强度保持。
- 本人地点与可解析预算/房型符合当前操作员资料：`candidate`，仅候选比较；不返回私有房源名称/引用给普通员工。
- 历史投影或 enabled=false：`unknown`。停业务匹配不关闭基本本人来源护栏。

所有状态固定 `inventory_verified=false`、`independently_verified=false`、`eligible_for_delivery=false`、`eligible_for_attribution=false`、`tenant_qualification_used=false`。真实库存、客户同意、联系方式当前授权、资源部独立接收继续沿原业务核验，不能由本模块替代。

## 已执行验证与尚未验收

已实际读取 Superpowers systematic-debugging、verification-before-completion、test-driven-development 的最小本地流程；代表要求先红后绿。新增 39 项检查覆盖来源/身份/注入/等级兼容/资料有效期/请求预算/权限/幂等/快照版本/事务失败；没有外部模型或平台请求。

最终必要回归精确 7 文件合计 **176/176 通过**，耗时约 29 秒。既有策略 benchmark 输出 `platform_requests=0`。4 份新 Python AST 校验通过。完整输出保留 `intent-policy-verification.txt`，哈希保留 `intent-policy-source-hashes.json`。

```powershell
python -c "import unittest,sys; patterns=['test_intent_policy.py','test_intent_rule_management.py','test_ai_workflow.py','test_intent_rules_refresh.py','test_company_defaults.py','test_contact_intent_snapshot.py','test_acquisition_strategy.py']; suite=unittest.TestSuite(unittest.defaultTestLoader.discover('tests',pattern=p) for p in patterns); r=unittest.TextTestRunner(verbosity=1).run(suite); sys.exit(not r.wasSuccessful())"
```

这是独立模块与现有离线夹具的技术证据，**不是**共享网关接入完成、provider 已执行新 criteria、真实数据分级准确率、房源库存核验或客户运营验收。仍待主窗口完成入口/缓存/云 schema/前端规则表单接线并做相关代表回归；真实公寓资料及有效期未给，必须显示待补。没有承诺 100% 精准，没有真实重分析、历史迁移、对外发送或安装包。
