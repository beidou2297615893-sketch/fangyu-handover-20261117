# Phase13 原公司登记只读入口独立前端审查

当前独立新套件 8/8 通过；一个真实用户可见矛盾已按原样实际投影复现并关闭。仅新增本测试、报告和日志，未修改生产、既有测试、冻结阶段文件或实际用户数据。没有联网、平台动作、真实云调用、部署或付费。

## 实际证据与红绿

`company-handoff-original-status-ui-independent.test.cjs` 从真实 `upgrade-operations-ui.mjs` 加载完整 `createUpgradeOperations` 与 `checkedCompanyOriginalStatus`。只删除顶层动态 imports，未替换新准备/查询实现；不相关组件初始化为无动作测试边界。DOM 为轻量实现，execute 的传输边界只返实际归档投影或可控错误；不能当 GUI 验收。

使用 D 冻结 `company-handoff-original-status-actual-fixture.json` 原样 `preparation_get_result` 和 no_origin/unknown/recorded/stale_uid/withdrawn 五 case，没有改读写 flag、原 key、来源或金额。fixture 标注 actual_local_core_and_actual_project_service_repositories + SDK 接口兼容内存双 callback adapter；不是真实 SDK 引擎，也没有云网络。

首轮：`company-handoff-original-status-ui-independent-first.txt`，8 组 7 绿 1 红。先 actual 本机准备 GET 显示可用，随后 actual stale_uid 的 `current_local` 已不可用，页面上方仍显示“当前来源与授权可用于本次准备”，下方却显示“本机当前交付保持暂停”。失败包含完整 DOM 与断言。旧 UI 源 SHA `0C3449019F7F158F2FD44F2C24D83AD9B8337D9EC76EB7C934F96FBCE5DEC4A3`。

root 最小修复仅在成功校验查询回执后，将可信 `companyStatus.current_local` 同步到准备页的 `answer.current`，原 origin/key/slot 不变。修后同例同时遍历 stale_uid 与 withdrawn，顶部旧可用声明不再出现，历史登记仍可读。最终 `company-handoff-original-status-ui-independent-final-green.txt` 8/8；本独审未重跑或重复统计 root/B/D 后端套件及旧阶段覆盖。

## 覆盖与口径

1. 五个实际 29 字段投影通过真实 checker；public original_operation 八字段已去 payload_hash，不索取原正文或重建 hash。no_origin 合法空态只在没有期望 origin 时接受。
2. 初始准备页只本机 GET，不自动查询公司。明确点击“核对原公司操作”后只有 `company_handoff_original_status {handoff_id}`，没有客户端 opkey/body/owner、dispatch、prepare、generic recover、自动重试。
3. actual unknown 只显示未知，保留原准备与旧 pending，不表示原操作未执行/已取消/可重发。已知保存 origin 的页面收到 no_origin 不能降级成未提交，严格拒绝矛盾回执。
4. actual recorded 与当前本机来源变化、撤回分开展示。原公司登记可保持历史对应；最新本机暂停取代旧准备可用声明。withdrawn 仍可显示历史接收登记，但注明证据待独立核对，不能推导当前授权、送达、付款或结算。
5. 后续查询遇到现有会话错误时，查询开始已清上一条公司结果 DOM；失败不挂旧成功，没有自动连接/续期/重试，不清本机存储。本例为传输错误边界，未执行真实会话续期。
6. accept、role、device、reset 在查询等待期间变化，迟到结果不能补旧公司状态 DOM。status 路径无 session 写/删除；原槽内容保持逐字相同。既有准备页为显示 pending 可读取 session，本报告不把它写成“整个页面从不访问 sessionStorage”。
7. 原 payload_hash/私有客户字段额外注入、非法 origin hash、不同渠道、verified_cash=0、source_cloud_verified=true、原 execution_confirmed=false 均拒绝，实际组件不渲染被拒绝的私有内容或成功声明。
8. 从真实 app 提取 PRODUCT_ACTIONS 与完整 execute 单元：本机模式仅 product_action；非本机模式 false/undefined typed preexec mutationfalse，0 cloud call / 0 generic submit。fake cloud/submit 为观测边界，不是外部平台调用。

`mutation_committed:false` 和 `no_dispatch_scope:this_status_query_only` 只描述本次读取，不能解释成原 register 未执行。`recorded` 的 execution_confirmed 描述公司原 register 记录；来源对应、平台送达、独立接收、合作分成和实际回款仍未核验。cash/paid 两字段始终 null，不以零值替代未知。

## 最终快照

- upgrade-operations-ui.mjs：`C0171EDDDB8B5FB77471AFFFC8B796C88B52856E65AF285EAC6555D29DABC5A3`
- app.mjs：`07D3619B173670F098C5C32E2402A41DC71B13768749B327BC2C5A50DECF966E`
- 独立 test：`C5EFBC2C77B99ECAF7C6ED79CFF45C4DC3096BD1686862FC958E344E8B5C61E8`
- D actual JSON：`B8C6748C1F23715710D43A718E535068993A1DB12CB0EDBCC7776D9CED411568`

当前快照未发现剩余 UI 阻断，可冻结。本轮结论限于真实源码 factory、精确合同、合成实际本机/服务仓库投影及轻量 DOM，未宣称真实 HTTP/GUI、真实云 SDK、跨机送达或业务验收。
