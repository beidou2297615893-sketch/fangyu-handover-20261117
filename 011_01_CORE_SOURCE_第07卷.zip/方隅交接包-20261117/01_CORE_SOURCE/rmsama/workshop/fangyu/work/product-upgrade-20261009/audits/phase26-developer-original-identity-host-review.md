# Phase26 原账号开发诊断 host：候选冻结审核

本切片完成独立开发诊断 host 的实现与三组必要合成代表，尚未运行原账号。Phase24 公开入口仍恒拒绝；既有 Core、Service、Runner、风险、账号和公司交付源均未因此改动。此 host 的用途固定为 `developer_original_identity_observation`，不是商业 natural/CLI 运行许可，也不改变已有 `login_required` 或历史 `review_required`。

唯一新增执行源位于 `work/product-upgrade-20261009/diagnostics/developer-original-identity/`：`bootstrap.py`、`runtime_identity.py`、`profile_occupancy.py`、`profile_process_probe.ps1`、`owned_job.py`、`host.py`、`native_runner.py`。构造函数不读原生 DATA。公开输入只允许固定 purpose 与原 account_id；路径、环境、owner、guard 和许可不由调用者指定。

## 已闭合的必要边界

- `bootstrap.py` 复用固定原生 knownfolder、固定项目公司文件及成熟 DeviceVault，但不构造 Core/Service/Runner。SQLite 使用 readonly immutable、query_only 与只读 authorizer，前后非空 WAL/journal 拒绝。actor、原账号 UID、device、公司环境、任务原值、profile identity 和活动原字节摘要进入 fingerprint。paused / inflight=null 保留为历史未知，不转换为 false，不启动或恢复采集。
- account_execution_lock 全生命周期持有，并独立读 OS profile 占用。Windows CommandLineToArgvW 解析完整路径，按 canonical 目录边界核原 profile 及子目录；邻近同名路径不误配。正常 Chrome/Edge 未提供 user-data-dir 时，只按当前 SID、明确安装 executable 路线及可解析当前 UserDataDir policy/default profile 排除。portable、冲突策略、相对路径、不可核 owner/创建时间/argv 仍 unknown。可辨认其他应用 WebView2 绝对 profile 可排除，无法对应时保持 unknown。没有 substring 排除或全局进程 kill。
- Python 仅允许本项目 Scripts/python.exe 或 pythonw.exe 的当前进程路线；pyvenv.cfg home 对应的实际 base 必须匹配相同窗口/控制台 executable。两个 shim 和两个 base 各自内容 SHA，不把 venv shim 当 base，也不把 python.exe SHA 套给 pythonw。uv home alias 与实际 canonical base 同时绑定；原 profile/data 路径仍拒 reparse。
- runtime capture 绑定具体已安装 WebView2 版本、关键 executable/DLL/loader、解释器和当前关键源。环境固定 WEBVIEW2_BROWSER_EXECUTABLE_FOLDER 并移除 profile/附加参数/调试覆盖；对本 job WebView2 实际 executable 另核所选路径。此材料不是完整依赖代码签名、来源审核或商业许可审核。
- child 以 CREATE_SUSPENDED 创建，先加入本次不继承 handle 的 KILL_ON_JOB_CLOSE Job Object，再 resume。membership 同时核 PID、创建时间与真实 Job Object；不能仅靠 PID/父子关系豁免占用。正常退出或取消均等待 owned descendants 为零，再清理本 job staging、释放账户锁。退出不确认时保留 job/锁并阻止重入，固定 runner 等待确认；没有靠短超时宣称清理成功。实际异常导致长期无法确认时会继续保留锁，这是明确的 failclosed 限制。
- observation 窗口为 300 秒；轻 poll 0.2 秒，全 metadata/runtime/CIM 检查每 2 秒，启动、退出、最终 proof 前后另作完整检查。单次 CIM 最多 15 秒且受剩余 observation 时间约束。关闭/终态核对还可能超过 observation 窗口，不把 300 秒当所有清理的性能 SLA。
- 复用成熟 natural proof、绑定原 UID 的 spec、owned argv、candidate MAC/当前文档证明；候选不提交原 CLI Cookie/session，不调用 cloud claim，不清风险。结束删除仅本 job staging；成熟固定 outcome 只保留代码级结果。输出无原 UID、Cookie、raw argv、其他进程资料或真实 contact。

## 必要代表与证据范围

`audits/test_phase26_developer_identity_host.py` 共三方法。最终日志 `phase26-developer-identity-own-three-final.txt` 是当前源的唯一必要最终运行，前后 SHA 在 final manifest 记录。

1. Windows 实际 argv API 对合成进程资料：完整/子目录/邻近 profile、owner/时间/参数缺失、Job membership、所选 browser 不符、正常 browser 的精确默认路线与策略未知。
2. 真实 readonly SQLite 合成 actor/account/任务与成熟 proof，legacy null 原值保留；机制成功不提交会话/风险/任务。实际静态读取固定 python 与 pythonw 的 shim/base，坏配对拒绝。占用与未知均零额外 spawn，旧公开入口保持拒绝。
3. scope/runtime/任务值/晚 owner 改变取消仅本 job，外部变化保留；坏 candidate MAC 拒绝；重复/伪造参数拒绝。实际 ctypes orchestration 接 recording kernel，证明 suspended→assign→resume 和失败不 resume，并核 creation-time membership；不是真实 Job Object/进程创建或 parent crash 试验。

合成测试禁止 socket.connect、subprocess.Popen、Service.start 和 Adapters.execute。比较本项目临时合成 DATA 中除 owned work 与 platform-command.lock 外原文件字节；不是读取或前后 hash 原账号 DATA，也不是完整实际 OS 原生诊断证明。PowerShell 文件只静态 ParseFile，0 语法错误，未执行 CIM/注册表探针。新 Python 仅 compile 源文本，不生成 pyc。

初轮材料路径错误保存在 `phase26-developer-identity-hardest-first.txt`：项目固定 uv base alias 是 reparse 路线，原候选把 alias 当严格实体拒绝；修正为固定 cfg 对应 alias/真实 base 绑定后原两方法通过。该初失败是候选运行材料问题，不是原平台失败。三方法施工前绿日志及最终前一版日志均单独保留，不叠加计数。

## 实际执行前仍需的核对

root 与 C 应审核冻结源，然后 root 先做仅实际 runtime/profile preflight，再决定既有授权下的一次原生用户上下文诊断。当前 D 没有原 DATA/DPAPI、OS process scan、native runner、browser、CLI、cloud、provider 或网络执行。真实 installed WebView2 selection 与真实 Job 生命周期尚未试验；这里的 static interpreter/material inventory 不冒充 actual runtime.capture 完整成功。

pythonw 可能没有 stdout；root 固定原生 probe 应捕获 sanitized host result 到独占证据文件，而非给 runner 添加任意 output/path。自然浏览器会有网页自身网络与原 profile 写入；输出 started 后 `platform_requests_started=null`，保留 `platform_browser_network_possible=true` / `profile_may_be_modified=true`，不能宣称实际平台零请求。只有本次匹配原 UID 观察成功才写 original_identity_observed，也不证明真实采集、current company/cloud membership、461 风险解除或总目标完成。未部署、未打包。

技术路线参考 root 已核的 Microsoft 文档：[WebView2 CreateAsync](https://learn.microsoft.com/en-us/dotnet/api/microsoft.web.webview2.core.corewebview2environment.createasync?view=webview2-dotnet-1.0.3405.78)、[Job Objects](https://learn.microsoft.com/en-us/windows/win32/procthread/job-objects)、[AssignProcessToJobObject](https://learn.microsoft.com/en-us/windows/win32/api/jobapi2/nf-jobapi2-assignprocesstojobobject)。文档支持机制，不代替实际 OS 生命周期证据。
