# 团队云端交接底座：复用、实现与接线审查

日期：2026-10-09。限定：本项目本地源码和fixture。已接实际 `work/cloud/workspace/service.cjs` 入口；未部署、未外发客户资料、未赋予真实接收角色、未迁移原contact/order。新增模块 `handoff-ledger.cjs`、模块测试 `handoff-ledger.test.cjs` 和实际服务登录集成测试 `handoff-service-integration.test.cjs`。

## 最难链路和路线选择

现有 `service.cjs` 会先从Bearer/session导出身份，再将contact请求交给独立账本；`contact_ledger.cjs` 在同事务重新确认session、user、disabled、company。`index.js.createStore` 已提供真正的CloudBase runTransaction，旧contact事件、customer和deal分别存储于公司隔离的private collection。可以直接复用它们，不需要换云平台、迁移旧库或再做一套认证。

最难要求是“另一位资源部员工，在另一执行上下文确认来源员工提交的客户，同时不能自己抢归属或伪造ACK”。新增模块从云中已经归档的contact event派生来源owner/customer UID/comment/hash；提交和ACK由不同有效session完成；recipient授权从持久服务器state配置查找；公司级重复占位和状态/版本在同事务更新。这条代表链路已在独立会话fixtures验证。

这里有三个必须保留的边界：

- 旧contact event的 `device_report` 证明已绑定设备/员工上传了这个事件，不独立证明真实平台原始事实。新模块明确 `platform_provenance_verified=false`，不能把客户端声明包装成平台公证。
- 本机CurrentUser DPAPI的contact:<uuid>只能由保存它的Windows账户解密，不能直接变成云联系方式。云首版仅接受由真实已归档UID派生的platform引用。手机号微信跨机器传递需要正式企业CRM或另一套获授权云vault及最小访问/撤回/留存规则；本轮未实现、未上传。
- 旧deal已有管理员审核/金额/commission逻辑。新模块只读取客户和revision并关联订单，不修改原金额、不自动改归属或计算分成，也不以一个link当结算到账。

## 已实现契约

创建 `createHandoffLedger({store,companyId,clock})`，调用 `handle(payload,{username,sessionDigest})`。identity必须由服务器入口认证结果派生；客户端不能在payload提交owner/actor/role/receiver/time/fee等信任字段。每次交易重新检查company、session有效期、用户disabled、真实存量role及可信recipient/manager配置。

可信服务器state配置候选如下；它不是API请求，也不会由模块自动创建真实权限：

```js
state.acquisitionPolicy = {
  recipients: [{id: 'resource_department', name: '资源部'}],
  receivers: {resource_employee: ['resource_department']},
  managers: ['authorized_reviewer']
};
```

admin可查看和独立review，不因role自动获得resource ACK权限；receiver仍需明确department映射且不得是source_owner。操作者只能提交/撤回/登记争议自己的渠道；manager/receiver读取来源快照时不会冒充来源员工或获得其本机vault reveal权限。普通人列表默认仅owned；received必须指定已授权recipient；managed必须是trusted manager。没有前端任意owner或全租户无条件list。

|operation|必要内容|结果/约束|
|---|---|---|
|acquisition_channel_register|source_event_id、recipient_id、purpose、consent三字段、qualification=qualified、idempotency_key|归档事件须属于本人；固定channel hc_<sha256>；来源/时间由服务器派生；初始draft|
|acquisition_handoff_submit|channel_id、expected_revision、idempotency_key|本人且draft/同意有效；同企业customer占位查重复；submitted为服务器待接收记录|
|acquisition_handoff_receipt|以上CAS字段、decision、evidence_reference；非accept另reason_code|独立可信receiver；accept/reject/needs_information/duplicate/existing_customer分别记录，不能自己确认|
|acquisition_handoff_review|以上CAS字段、reason_code、evidence_reference|另一位有权manager；reviewed_unique仅回到unconfirmed draft；不裁定最终渠道或金额|
|acquisition_handoff_withdraw|以上CAS字段、真实reason_code|本人撤回；customer_withdrew写永久同意tombstone；释放本人active slot|
|acquisition_handoff_dispute|以上CAS字段、真实reason_code和evidence_reference|本人登记争议；保留重复占位，避免争议期间被自动抢占|
|acquisition_handoff_order_link|以上CAS字段、order_no、order_revision、evidence_reference|另一位有权主体；已有accepted/current consent；旧deal同customer和当前revision；只link，原order不改|
|acquisition_handoff_list|view=owned/received/managed；received另recipient_id；offset/limit|授权index分页，limit最多25；不裸读全企业|
|acquisition_handoff_detail|channel_id|重新授权并校验服务器最新事件/快照；不输出旧contact原文或联系方式|

`consent` 输入仅 `{status:'granted',evidence_reference:'consent:<32hex>',notice_version}`。元数据额外标记operator_recorded、independently_verified=false。同company已经withdrawn的reference不能换owner/客户/接收方/key复用。新同意需新ref。证据文件实际留存和签署真实性不由一个UUID自动证明。

输出 `server_recorded=true`、`storage_scope=company_server_ledger` 只说明服务端持久化契约。`resource_receipt_auth_verified` 在accepted+另一个已认证主体登记时为true；`platform_delivery_verified=false`、`contact_delivery=platform_reference_only`、`attribution_confirmed=false`、`settlement_active=false`、amount_cents=null。源记录仍标明device_report，订单状态只作为link时快照。

## 存储、并发和原数据保护

继续使用已有 `fangyu_workspace_private` collection，但新增document ID全部 `handoff_<hash(companyId,key)>` 前缀，与旧contact_、企业state和shared文档分开。不覆盖旧docs。读取旧event/customer/deal使用现contact_ledger.repoFor；新module没有对这些旧records的set调用。

每次mutation在同事务完成operation幂等hash、source验证、expected_revision CAS、公司customer active claim、记录、事件、索引和操作回执。相同actor/op/key不同payload拒绝；同payload重放返回当前重新授权视图，不重复event/index。多来源同UID同时submit仅一方获得active claim。

事件包含来源owner、actor/op、服务器时间、revision、状态、previous_hash、snapshot_hash和chain_hash。普通API没有改历史事件入口；最新记录会校验最新事件和快照。此版本未在每次请求重新计算整条历史链，也没有WORM存储、可信时间戳或私钥签名，不能声称数据库管理员无法改库。

CloudBase官方事务文档给出单事务最多100操作、30秒及仅doc操作。本模块不在事务中调用外部API；分页最多25条，最坏约79次单文档读含企业state/index，避免50条产生超过100操作。该预算是契约/fixture静态核对，部署前仍须与现SDK、环境配额及延迟验证。[CloudBase官方事务文档](https://docs.cloudbase.net/en/database/transaction)

## 已完成本地入口接线

1. `service.cjs` 已像contactLedger一样import createHandoffLedger/OPERATIONS，初始化时用同store/companyId/clock创建。
2. 当前企业认证事务确认有效user/session后，对HANDOFF_OPERATIONS仅返回内部 `{_handoffRequest:true,identity:{username:user.username,sessionDigest:session.digest}}`。payload里的role/identity不能成为信任对象，额外信任字段由helper严格拒绝。
3. 事务外调用 `handoffLedger.handle(payload,result.identity)` 并用既有reply包固定environment/contract/companyId。helper内部事务重新认证；夹具在入口检查后插入禁用、过期及撤回接收映射，均不能访问。
4. 现service对device bearer的特殊许可仍仅用于contact sync；云handoff只接受员工session。若后续允许device mutation，要扩展同事务device digest/revoked/owner认证，不把device username直当session。
5. 客户端须保存原key，丢响应时用同key同payload核对/重试已幂等action；expected_revision变化先refresh。不得把本机product_operation_receipts的cancelled墓碑当服务器不存在证明。
6. 本机local UUID channel与云hc_ channel需显式映射/服务器返回ACK，不根据本机状态自行标已云同步。local撤同意向cloud传播需要新增受认证设备/本人session的一致性任务；没有cloud回执前不声称撤回已跨机器完成。

入口只新增import、初始化及认证后分发/回包分支，未改HTTP index.js、原会员角色API、共享发布或设备发布限制。资源部映射仍仅从服务器可信state读取，member_save不能写acquisitionPolicy/resourceReceiver。生产没有默认授予任何员工此权限。客户端提交不同环境被入口拒绝，提交company/tenant/owner/actor/role/time/session等字段由helper拒绝。未配置可信接收方时仍显示相应明确错误，不制造真实接收成功。

源码备份：`work/product-upgrade-20261009/backups/cloud-service-handoff-r1/service.cjs`。原SHA256 `6AB5C8734FC6D1F6790CCA9FEB6BB309514442F1F5B8DD32475DDFBD550F7937`，当前入口SHA256 `9C6AFB01D80D87309E993172AAC8B3CD1283D1629CECCD0324DD39F52FC5E892`。集成测试SHA256 `F1C704E9B76843F45F9D4C68C90BC37D2157CEF9065D9BAA8F5831FA25252E7A`。

## 测试与后续条件

15项新增node:test全部通过：独立源/receiver session链路、无明文/金额、来源伪造与actor/owner字段拒绝、本机DPAPI ref拒绝、幂等冲突/重放、公司级并发只一方submit、CAS、禁用/过期/权限撤销/跨company、重复/旧客独立review、客户撤回不能复用、争议、同客户同revision订单link且原contact/order完全不改、审计快照篡改及事务写失败整体回滚、分页预算限制、兼容含日期和长数字的真实订单ID。随后与既有contact_ledger.test.cjs、isolation.test.cjs联合运行，34/34通过；这证明本地旧账本契约未因新增模块回归，不代表生产已部署。

新增8项实际createService登录集成测试：初始管理员登录→member_save创建fixture员工→各自密码登录→受权fixture设备contact_events_sync来源事件→渠道登记/提交→独立资源部session清单/详情/ACK→contact_deal_report现有同客户订单→order link，验证旧contact/order文档完全未改、金额/归属未被新link自动确认。此外覆盖争议/撤回重复请求、永久撤同意、重复/既有客户独立复核、自ACK/无映射admin/外人拒绝、client receiver policy伪造、入口后撤权二次验证、事务写失败、CAS与回执重放、跨公司/共享功能关闭/方隅小红书发布限制。首轮测试有一项把外人无权响应误期待为403，实际为不枚举记录的404；修正该fixture预期后通过，不改变服务权限逻辑。

最后联跑 `node --test handoff-service-integration.test.cjs handoff-ledger.test.cjs contact_ledger.test.cjs isolation.test.cjs service.test.cjs shared-feature-disabled.test.cjs remember-device.test.cjs`，55/55通过：新入口8、模块15、既有contact18、隔离1、service8、共享关闭1、记住设备4。测试仅使用本地原子staged store，不调用云SDK或HTTP网络，不代表生产账号、CloudBase真实事务、多机器传递和资源部业务认可已验收。

仍需：SDK事务代表验证、正式受权receiver配置、资源部业务试点、云授权contact vault或CRM接入、撤同意跨端一致性、门店/组织域模型、历史事件分页、真实订单/到账及部署批准。没有执行真实账号登录、批量消息、平台采集、费用消耗或云部署。
