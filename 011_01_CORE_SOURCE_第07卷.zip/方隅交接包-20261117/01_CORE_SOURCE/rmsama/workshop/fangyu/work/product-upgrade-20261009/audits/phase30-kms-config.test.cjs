'use strict';
// Offline actual bootstrap and official SDK construction. No KMS/CloudBase requests.
const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');
const {createRequire}=require('node:module');
const CLOUD=path.resolve(__dirname,'../../cloud/workspace');
const requireCloud=createRequire(path.join(CLOUD,'package.json'));
const sdk=requireCloud('tencentcloud-sdk-nodejs-kms');
const packageInfo=requireCloud('tencentcloud-sdk-nodejs-kms/package.json');
const config=()=>requireCloud('./contact_delivery_config.cjs');
const valid=()=>({TCB_ENV:'phase30-fixture-env',COMPANY_ID:'fangyu-apartment-client',
 CONTACT_KMS_REGION:'ap-shanghai',CONTACT_KMS_KEY_ID:'phase30-fixture-key-id',
 CONTACT_KMS_SECRET_ID:'phase30-synthetic-secret-id-only',CONTACT_KMS_SECRET_KEY:'phase30-synthetic-secret-key-only',
 CONTACT_KMS_TOKEN:'phase30-synthetic-sts-token-only',CONTACT_RETENTION_SECONDS:'86400'});
function bootstrap(environment){
 let init=0,created=0,options=null;const logs=[];
 const context={exports:{},Buffer,process:{env:{...environment}},console:{error:(...args)=>logs.push(args.join(' '))}};
 context.require=name=>{
  if(name==='@cloudbase/node-sdk')return {init(){init++;return {database:()=>({})};}};
  if(name==='./service.cjs')return {createService(value){created++;options=value;return async()=>({status:200,data:{safe_fixture:true}});}};
  if(name==='./site.cjs')return {serveSite:()=>({statusCode:200,body:'fixture'})};
  if(name==='./release.cjs')return {releaseState:()=>({})};
  if(name==='./shared_leads_v2.cjs')return {listPage:()=>{throw Error('must not list');}};
  if(name==='./shared_feature.cjs')return {SHARED_FEATURE_ENABLED:false};
  return requireCloud(name);
 };
 vm.runInNewContext(fs.readFileSync(path.join(CLOUD,'index.js'),'utf8'),context,{filename:'actual-phase30-index.js'});
 return {context,logs,get options(){return options;},get init(){return init;},get created(){return created;},
  async call(body={operation:'fixture_no_write',environment_id:'phase30-fixture-env'}){
   const out=await context.exports.main({httpMethod:'POST',body:JSON.stringify(body),headers:{}});
   return {status:out.statusCode,data:JSON.parse(out.body)};
  }};
}
function noRequests(run){
 const Client=sdk.kms.v20190118.Client,original=Client.prototype.request;let calls=0;
 Client.prototype.request=function(){calls++;throw Error('OFFLINE_ONLY');};
 return Promise.resolve().then(run).finally(()=>{Client.prototype.request=original;assert.equal(calls,0,'SDK construction/selfcheck must never request KMS');});
}
test('actual index binds only fixed server settings, with no browser override and no warm-instance reconfiguration',()=>noRequests(async()=>{
 const f=bootstrap(valid());assert.equal((await f.call()).status,200);
 assert.equal(f.options.contactDeliveryProvider?.configured,true,'actual bootstrap must pass the official KMS provider');
 assert.equal(f.options.contactRetentionSeconds,86400);assert.equal(f.created,1);
 const signature=f.options.contactDeliveryProvider.signature;
 f.context.process.env.CONTACT_KMS_KEY_ID='changed-fixture-key-id';f.context.process.env.CONTACT_RETENTION_SECONDS='1';
 await f.call({operation:'fixture_no_write',environment_id:'phase30-fixture-env',CONTACT_KMS_KEY_ID:'browser-key',
  CONTACT_KMS_SECRET_KEY:'browser-secret',contactRetentionSeconds:1,endpoint:'https://invalid.example'});
 assert.equal(f.created,1);assert.equal(f.options.contactRetentionSeconds,86400);assert.equal(f.options.contactDeliveryProvider.signature,signature);
 const absent=bootstrap({TCB_ENV:'phase30-fixture-env',COMPANY_ID:'fangyu-apartment-client'});
 await absent.call({operation:'fixture_no_write',CONTACT_KMS_KEY_ID:'browser-key',CONTACT_KMS_SECRET_KEY:'browser-secret',CONTACT_RETENTION_SECONDS:'86400'});
 assert.equal(absent.options.contactDeliveryProvider,null);assert.equal(absent.options.contactRetentionSeconds,null);
}));
test('malformed configuration rejects contact creation before SDK loading while ordinary reads, history and withdrawal remain available',()=>noRequests(async()=>{
 const c=config();let loads=0;
 const absent=c.contactDeliveryOptionsFromEnvironment({}, {loadSdk:()=>{loads++;throw Error('must not load');}});
 assert.deepEqual(absent,{contactDeliveryProvider:null,contactRetentionSeconds:null});assert.equal(loads,0);
 const bad=[{CONTACT_RETENTION_SECONDS:'86400'}, {...valid(),CONTACT_KMS_KEY_ID:''}, {...valid(),CONTACT_RETENTION_SECONDS:'0'},
  {...valid(),CONTACT_RETENTION_SECONDS:'31536001'}, {...valid(),CONTACT_RETENTION_SECONDS:'01'},
  {...valid(),CONTACT_KMS_SECRET_KEY:'bad\nsecret'}, {...valid(),CONTACT_KMS_ENDPOINT:'https://invalid.example'},
  {...valid(),CONTACT_KMS_PURPOSE:'browser-controlled'}, {...valid(),CONTACT_KMS_TOKEN:''}];
 for(const value of bad){
  const checked=c.checkContactDeliveryConfiguration(value,{loadSdk:()=>{loads++;throw Error('must not load');}});
  assert.equal(checked.state,'invalid');assert.equal(checked.live_kms_verified,false);assert.equal(checked.network_requested,false);
  assert.throws(()=>c.contactDeliveryOptionsFromEnvironment(value,{loadSdk:()=>{loads++;throw Error('must not load');}}),
   error=>error.code==='CONTACT_KMS_CONFIG_INVALID'&&!error.message.includes('secret'));
  const f=bootstrap({TCB_ENV:'phase30-fixture-env',COMPANY_ID:'fangyu-apartment-client',...value});
  assert.equal((await f.call()).status,200);assert.equal(f.init,1);assert.equal(f.created,1);
  assert.equal(f.options.contactDeliveryProvider,null);assert.equal(f.options.contactRetentionSeconds,null);
  assert.ok(f.logs.every(line=>line==='FANGYU_CONTACT_CONFIGURATION_ERROR CONTACT_KMS_CONFIG_INVALID'));
 }
 assert.equal(loads,0);
 const missing=c.checkContactDeliveryConfiguration(valid(),{loadSdk:()=>{throw Error('raw secret must not escape');}});
 assert.equal(missing.state,'dependency_unavailable');assert.ok(!JSON.stringify(missing).includes('raw secret'));
 const wrong=c.checkContactDeliveryConfiguration(valid(),{loadSdk:()=>({sdk,version:'0.0.0'})});
 assert.equal(wrong.state,'dependency_unavailable');
 // Actual current service/store/ledger with a previously saved opaque vault.
 // The fixture uses an SDK-interface memory adapter and stubbed crypto request boundary.
 const {fixture,PUBLISH,REVEAL,WITHDRAW,STATUS}=requireCloud('./contact-delivery-fixture.cjs');
 const f=await fixture({mode:'metadata'});
 const original={...f.publishBody,phone:'[REDACTED:phone_cn]',wechat:'phase30SyntheticCustomer'};
 assert.equal((await f.call(PUBLISH,original)).status,200);const counts=f.counts();
 const {createService}=requireCloud('./service.cjs');
 const disabled=bootstrap({...valid(),CONTACT_RETENTION_SECONDS:'0'});await disabled.call();
 const service=createService({store:f.store,companyId:'fixture-company',environmentId:'fixture-env',clock:f.clock,
  contactDeliveryProvider:disabled.options.contactDeliveryProvider,contactRetentionSeconds:disabled.options.contactRetentionSeconds});
 const call=(operation,body,actor='source')=>service({operation,environment_id:'fixture-env',
  expected_device_id:f.identity(actor).deviceId,channel_id:f.item.channel_id,...body},f.tokens[actor]);
 f.data.resetOperations();const before=f.data.snapshot();
 const history=await call(STATUS,{operation_action:PUBLISH,idempotency_key:original.idempotency_key});
 assert.equal(history.status,200);assert.equal(history.data.delivery.original_execution_confirmed,true);
 assert.equal(history.data.delivery.provider_configured,false);assert.equal(history.data.delivery.retention_configured,false);
 assert.equal(history.data.delivery.contact_values,null);
 const denied=await call(REVEAL,{...f.revealBody,idempotency_key:'phase30-disabled-reveal'},'resource');assert.equal(denied.status,503);
 const newPublish=await call(PUBLISH,{...original,idempotency_key:'phase30-disabled-publish'});assert.equal(newPublish.status,503);
 assert.equal(newPublish.data.mutation_committed,false);assert.equal(denied.data.mutation_committed,false);
 assert.equal(before,f.data.snapshot());for(const callback of f.data.operations())for(const op of callback)assert.equal(op.writes,0);
 const withdrawn=await call(WITHDRAW,{...f.revealBody,idempotency_key:'phase30-disabled-config-withdraw'});
 assert.equal(withdrawn.status,200);assert.equal(withdrawn.data.delivery.current_consent_valid,false);
 const after=await call(STATUS,{operation_action:PUBLISH,idempotency_key:original.idempotency_key});
 assert.equal(after.status,200);assert.equal(after.data.delivery.original_execution_confirmed,true);assert.equal(after.data.delivery.contact_available,false);
 assert.deepEqual(f.counts(),counts,'invalid config cannot encrypt/decrypt while processing withdrawal/history');
}));
test('pinned official product SDK uses fixed credentials/endpoint profile, with safe selfcheck and no crypto calls',()=>noRequests(async()=>{
 const c=config();let captured=null,constructed=0;const OfficialClient=sdk.kms.v20190118.Client;
 class ObservedClient extends OfficialClient{constructor(value){super(value);captured=this;constructed++;}}
 const loadSdk=()=>({sdk:{kms:{v20190118:{Client:ObservedClient}}},version:packageInfo.version});
 const env=valid(),options=c.contactDeliveryOptionsFromEnvironment(env,{loadSdk});
 assert.equal(options.contactDeliveryProvider.configured,true);assert.equal(constructed,1);
 assert.equal(captured.endpoint,'kms.tencentcloudapi.com');assert.equal(captured.profile.httpProfile.protocol,'https://');
 assert.equal(captured.profile.httpProfile.reqMethod,'POST');assert.equal(captured.profile.httpProfile.reqTimeout,10);
 assert.equal(captured.credential.secretId,env.CONTACT_KMS_SECRET_ID);assert.equal(captured.credential.secretKey,env.CONTACT_KMS_SECRET_KEY);
 assert.equal(captured.credential.token,env.CONTACT_KMS_TOKEN);assert.equal(captured.region,'ap-shanghai');
 const firstSignature=options.contactDeliveryProvider.signature;env.CONTACT_KMS_SECRET_KEY='later-mutated-synthetic-secret-key';
 assert.notEqual(captured.credential.secretKey,env.CONTACT_KMS_SECRET_KEY);assert.equal(options.contactDeliveryProvider.signature,firstSignature);
 const checked=c.checkContactDeliveryConfiguration(valid());
 assert.equal(checked.state,'configured');assert.equal(checked.provider_configured,true);assert.equal(checked.retention_configured,true);
 assert.equal(checked.sdk_version,'4.1.302');assert.equal(checked.live_kms_verified,false);assert.equal(checked.network_requested,false);
 assert.equal(checked.iam_permissions_verified,false);
 for(const text of Object.values(valid()))assert.ok(!JSON.stringify(checked).includes(text),'safe selfcheck must omit exact config values');
 const permanent=valid();delete permanent.CONTACT_KMS_TOKEN;
 const permanentOptions=c.contactDeliveryOptionsFromEnvironment(permanent,{loadSdk});assert.equal(permanentOptions.contactDeliveryProvider.configured,true);
 assert.equal(captured.credential.token,null);
 const absent=c.checkContactDeliveryConfiguration({});assert.equal(absent.state,'not_configured');assert.equal(absent.provider_configured,false);
}));
