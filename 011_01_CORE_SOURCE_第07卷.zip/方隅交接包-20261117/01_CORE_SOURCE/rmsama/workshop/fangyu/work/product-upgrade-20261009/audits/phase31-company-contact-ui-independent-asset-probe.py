"""Actual Handler.do_GET -> employee_workspace.asset, RAM request/response only.

No Core, listener, DB, browser, real account or network transport is created.
"""
import hashlib
import io
import json
from pathlib import Path
import socket
import sys
from types import SimpleNamespace

sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parents[2] / 'app' / 'src'))


def forbidden(*args, **kwargs):
    raise AssertionError('PHASE31_NETWORK_OR_PRIVATE_STATE_FORBIDDEN')


socket.socket.connect = forbidden
socket.create_connection = forbidden

from app import Handler
from assistant import employee_workspace


class UnusedPrivateCore:
    session = handle = forbidden


def request(query):
    handler = object.__new__(Handler)
    handler.path = '/workspace?' + query
    handler.command = 'GET'
    handler.headers = {'Host': '127.0.0.1:0'}
    handler.server = SimpleNamespace(
        server_port=0, employee_workspace_mode=True,
        private_evaluation_capability=None, update_startup_pending=False,
        development_workspace=False, core=UnusedPrivateCore(),
        company={'id': 'fangyu-apartment-client',
                 'managedWorkspace': {'environment_id': 'phase31-synthetic-env'}})
    handler.wfile = io.BytesIO()
    status = []
    headers = {}
    handler.send_response = lambda code, *args: status.append(code)
    handler.send_header = lambda key, value: headers.__setitem__(key, value)
    handler.end_headers = lambda: None
    Handler.do_GET(handler)
    body = handler.wfile.getvalue()
    return {'query': query, 'status': status[-1], 'headers': headers,
            'byte_length': len(body), 'body_sha256': hashlib.sha256(body).hexdigest()}


def main():
    module = 'company-contact-delivery-ui.mjs'
    direct, mime = employee_workspace.asset(
        SimpleNamespace(development_workspace=False), module)
    queries = ['asset=' + module, 'asset=phase31-not-allowed.mjs',
               'asset=' + module + '&asset=' + module,
               'asset=../' + module, 'asset=' + module + '&other=1']
    result = {'contract': 'phase31_contact_ui_actual_asset_probe_v1',
              'actual_handler_do_get': True, 'actual_asset_function': True,
              'http_listener_started': False, 'core_constructed': False,
              'real_network_called': False, 'real_account_used': False,
              'module': module, 'direct_content_type': mime,
              'direct_sha256': hashlib.sha256(direct).hexdigest(),
              'queries': [request(query) for query in queries]}
    sys.stdout.write(json.dumps(result, ensure_ascii=False, separators=(',', ':')) + '\n')


if __name__ == '__main__':
    main()
