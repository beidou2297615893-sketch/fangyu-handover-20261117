"""Export only artificial actual-backend response contracts for independent UI tests."""
from pathlib import Path
import json
import hashlib
import sys

PROJECT=Path(__file__).resolve().parents[3]
APP=PROJECT/'work/app'
sys.path[:0]=[str(APP/'src'),str(APP/'tests')]
from test_intent_quality_review import IntentQualityReviewTests

fixture=IntentQualityReviewTests(methodName='test_real_batch_is_blinded_atomic_idempotent_and_does_not_rewrite_production')
fixture.setUp()
try:
    empty=fixture.create()
    values={'empty_receipt':empty,'empty_batch':fixture.get(empty),'empty_summary':fixture.summary(empty),
            'empty_list':fixture.call('intent_quality_batch_list',{'offset':0,'limit':20})}
    original=fixture.lead()
    batch=fixture.create('independent-ui-nonempty')
    blind=fixture.get(batch)
    fixture.label(batch,blind['samples'][0])
    values.update(current_receipt=batch,current_batch=fixture.get(batch),current_summary=fixture.summary(batch))
    original['text']='改变后的合成原评论'
    fixture.core.store.put('leads',original)
    values.update(stale_batch=fixture.get(batch),stale_summary=fixture.summary(batch))
    values['cancelled_receipt']=fixture.status(key='independent-ui-absent')
    values['metadata']={'synthetic_only':True,'real_database_access':False,'network':False,
        'backend_sha256':hashlib.sha256((APP/'src/assistant/intent_quality_review.py').read_bytes()).hexdigest()}
    (Path(__file__).parent/'intent-quality-ui-actual-contract-fixtures.json').write_text(
        json.dumps(values,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
finally:
    fixture.tearDown()
