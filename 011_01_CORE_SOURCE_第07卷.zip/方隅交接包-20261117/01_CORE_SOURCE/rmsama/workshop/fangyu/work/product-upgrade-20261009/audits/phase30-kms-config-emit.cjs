'use strict';
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const project=path.resolve(__dirname,'../../..'),cloud=path.join(project,'work/cloud/workspace');
const {checkContactDeliveryConfiguration}=require(path.join(cloud,'contact_delivery_config.cjs'));
const sha=name=>crypto.createHash('sha256').update(fs.readFileSync(path.join(project,name))).digest('hex').toUpperCase();
const synthetic={CONTACT_KMS_REGION:'ap-shanghai',CONTACT_KMS_KEY_ID:'phase30-fixture-key-id',
 CONTACT_KMS_SECRET_ID:'phase30-synthetic-secret-id-only',CONTACT_KMS_SECRET_KEY:'phase30-synthetic-secret-key-only',
 CONTACT_KMS_TOKEN:'phase30-synthetic-sts-token-only',CONTACT_RETENTION_SECONDS:'86400'};
const sources=['work/cloud/workspace/index.js','work/cloud/workspace/contact_delivery_config.cjs','work/cloud/workspace/package.json',
 'work/cloud/workspace/package-lock.json','work/cloud/workspace/kms_contact_provider.cjs','work/cloud/workspace/service.cjs','work/cloud/workspace/contact_delivery.cjs'];
const output={synthetic_only:true,actual_module_projection:true,network_requested:false,live_kms_verified:false,
 source_metadata:sources.map(name=>({path:name,sha256:sha(name)})),
 cases:{not_configured:checkContactDeliveryConfiguration({}),configured:checkContactDeliveryConfiguration(synthetic),
 partial:checkContactDeliveryConfiguration({CONTACT_RETENTION_SECONDS:'86400'}),
 unsupported_endpoint:checkContactDeliveryConfiguration({...synthetic,CONTACT_KMS_ENDPOINT:'https://invalid.example'}),
 dependency_unavailable:checkContactDeliveryConfiguration(synthetic,{loadSdk:()=>{throw Error('synthetic dependency unavailable');}})}};
for(const value of Object.values(synthetic))if(JSON.stringify(output).includes(value))throw Error('Fixture projection exposed settings');
fs.writeFileSync(path.join(__dirname,'phase30-kms-config-actual-fixture.json'),JSON.stringify(output,null,2)+'\n');
process.stdout.write(JSON.stringify({cases:Object.keys(output.cases),network_requested:false})+'\n');
