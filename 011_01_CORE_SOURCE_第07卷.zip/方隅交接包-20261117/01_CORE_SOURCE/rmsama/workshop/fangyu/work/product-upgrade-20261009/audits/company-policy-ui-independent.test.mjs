/* Actual production functions with synthetic transport and a small DOM.
 * Offline logic audit only: no browser, CloudBase, model or GUI acceptance. */
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import {webcrypto} from 'node:crypto';
import {createCompanyPolicyUI,checkedCompanyPolicyReceipt,checkedCompanyPolicySummary} from '../../app/src/web/workspace/company-policy-ui.mjs';
import {createIntentRuleUI} from '../../app/src/web/workspace/intent-rule-ui.mjs';
import {createPlatformReadUI,checkedArchive} from '../../app/src/web/workspace/platform-read-ui.mjs';
import {createIntentQualityUI,checkedQualityReceipt} from '../../app/src/web/workspace/intent-quality-ui.mjs';
import {handoffExportFile} from '../../app/src/web/workspace/handoff-export-file.mjs';
import {createBusinessReconciliationUI} from '../../app/src/web/workspace/business-reconciliation-ui.mjs';
import {createSelfWorklistUI} from '../../app/src/web/workspace/self-worklist-ui.mjs';
import {createSelfDailyEvidenceUI} from '../../app/src/web/workspace/self-daily-evidence-ui.mjs';

const action='intent_policy_publish',target='company-intent-policy';
const expected={expected_local_revision:7,expected_local_digest:'a'.repeat(64),expected_policy_revision:0};
const summary=(key='fixture-publication-key',revision=1)=>({contract:'company_intent_policy_v1',scope:'company',policy_revision:revision,
  policy_digest:'b'.repeat(64),effective_facts_digest:'c'.repeat(64),enabled:true,facts_as_of:'2026-10-10T02:00:00.000Z',facts_valid_until:null,
  usable_fact_count:0,incomplete_fact_count:0,expired_fact_count:0,future_fact_count:0,source:'operator_recorded',independently_verified:false,
  inventory_verified:false,publication_id:'publication-fixture',publication_key:key,source_local_revision:7,source_local_digest:'a'.repeat(64)});
const receipt=(key,{verified=true}={})=>({state:'succeeded',mutation_committed:true,operation_action:action,idempotency_key:key,
  publication_id:'publication-fixture',summary:summary(key),local_source_matches:true,current_cloud_verified:verified,
  cloud_current_state:verified?'succeeded':'unknown',requires_revalidation:!verified,read_only:true});
const deferred=()=>{let resolve;const promise=new Promise(r=>resolve=r);return {promise,resolve};};
const tick=()=>new Promise(resolve=>setImmediate(resolve));
async function waitFor(predicate){const end=Date.now()+2000;while(!predicate()){if(Date.now()>end)assert.fail('synthetic source callback did not settle');await tick();}}
class Node{
  constructor(tag='div'){this.tagName=tag.toUpperCase();this.children=[];this._text='';this.dataset={};this.disabled=false;this.attrs={};}
  set textContent(value){this._text=String(value);this.children=[];}get textContent(){return this._text+this.children.map(n=>n.textContent).join('');}
  append(...nodes){for(const n of nodes){n.parent=this;this.children.push(n);}}
  replaceChildren(...nodes){this.children=[];this._text='';this.append(...nodes);}
  remove(){if(this.parent)this.parent.children=this.parent.children.filter(n=>n!==this);}
  setAttribute(key,value){this.attrs[key]=String(value);}addEventListener(){}showModal(){this.open=true;}close(){this.open=false;}
  querySelectorAll(selector){const tags=selector.split(',').map(s=>s.toUpperCase());return this.children.flatMap(n=>[...(tags.includes(n.tagName)?[n]:[]),...n.querySelectorAll(selector)]);}
  click(){if(!this.disabled)this.onclick?.();}
}
function dom(){const body=new Node('body');return {body,createElement:tag=>new Node(tag),dispatchEvent(){}};}
function store(){const values=new Map();return {getItem:key=>values.get(key)??null,setItem:(key,value)=>values.set(key,String(value)),removeItem:key=>values.delete(key)};}
const principal=()=>({user:{id:'fixture-admin',username:'fixture-owner',tenant_id:'fixture-tenant',role:'admin'},deviceId:'fixture-device',deviceGeneration:1});
function operations(execute){
  const document=dom(),storage=store(),context=principal();globalThis.document=document;
  // Only the server's query-asset import routing and export syntax are adapted.
  // All six dependency implementations and the complete production factory run unchanged.
  const text=fs.readFileSync(new URL('../../app/src/web/workspace/upgrade-operations-ui.mjs',import.meta.url),'utf8');
  const lines=text.split(/\r?\n/),imports=lines.filter(line=>/^const \{.*\}=await import\(new URL\('\?asset=/.test(line));
  assert.equal(imports.length,8,'source import adapter needs review after asset routing changes');
  const source=lines.filter(line=>!imports.includes(line)).join('\n').replace(/^export /gm,'');
  const sandbox={document,crypto:webcrypto,TextEncoder,URL,window:{sessionStorage:storage},createIntentRuleUI,createPlatformReadUI,checkedArchive,
    createIntentQualityUI,checkedQualityReceipt,createCompanyPolicyUI,checkedCompanyPolicyReceipt,createBusinessReconciliationUI,createSelfWorklistUI,createSelfDailyEvidenceUI,handoffExportFile,console};
  vm.createContext(sandbox);vm.runInContext(source+'\nglobalThis.audit={createUpgradeOperations,operationLockSlot};',sandbox);
  const shell={hooks:{setAction(){}},refresh:async()=>{}};
  const api=sandbox.audit.createUpgradeOperations({execute,getContext:()=>context,shell,storage});
  return {api,document,storage,context,slot:()=>sandbox.audit.operationLockSlot(context,action,target)};
}
function seed(h,key='fixture-original-key'){h.storage.setItem(h.slot(),JSON.stringify({action,idempotency_key:key,payload_digest:'d'.repeat(64),state:'submitted'}));return key;}

test('actual company receipt validators preserve historical/current distinction and enforce source bindings',()=>{
  const old=receipt('fixture-original-key',{verified:false});assert.equal(checkedCompanyPolicyReceipt(old,'fixture-original-key',{expected,readOnly:true}),old);
  assert.throws(()=>checkedCompanyPolicyReceipt({...old,current_cloud_verified:true},'fixture-original-key'));
  assert.throws(()=>checkedCompanyPolicySummary({...summary(),policy_revision:0}));
  assert.throws(()=>checkedCompanyPolicyReceipt({...receipt('fixture-original-key'),summary:{...summary('fixture-original-key'),source_local_digest:'e'.repeat(64)}},'fixture-original-key',{expected}));
});

test('actual common write validates a source receipt before clearing the pending slot',async()=>{
  let calls=0;
  const h=operations(async(op,data)=>{calls++;const value=receipt(data.idempotency_key);value.summary.source_local_digest='e'.repeat(64);return {status:'succeeded',result:value};});
  await assert.rejects(h.api.write(action,expected,target));
  const retained=JSON.parse(h.storage.getItem(h.slot()));assert.equal(retained.state,'submitted');assert.equal(calls,1);
});

test('actual common recovery keeps pending historical success whose current cloud proof is unknown',async()=>{
  const h=operations(async(op,data)=>{assert.equal(op,'intent_policy_publish_status');return {status:'succeeded',result:receipt(data.idempotency_key,{verified:false})};});
  const key=seed(h),answer=await h.api.recover(action,target);assert.equal(answer.resolved,false);assert.equal(answer.current_cloud_verified,false);
  assert.equal(JSON.parse(h.storage.getItem(h.slot())).idempotency_key,key);
});

test('actual company recovery rereads the current company summary rather than displaying its historical receipt as current',async()=>{
  const calls=[];let companyReads=0;
  const h=operations(async(op,data)=>{calls.push(op);
    if(op==='intent_rules_get')return {status:'succeeded',result:{summary:{revision:7,digest:'a'.repeat(64),can_manage:true}}};
    if(op==='intent_policy_read')return {status:'succeeded',result:{summary:summary('fixture-current-company-key',++companyReads+1),can_publish:true}};
    if(op==='intent_policy_publish_status')return {status:'succeeded',result:receipt(data.idempotency_key)};
    assert.fail('unexpected write '+op);
  });seed(h);await h.api.openCompanyPolicy();
  h.document.body.querySelectorAll('button').find(n=>n.textContent==='只核对原发布编号').click();
  await waitFor(()=>companyReads===2&&h.document.body.textContent.includes('公司当前版本 3'));
  assert.equal(calls.filter(op=>op==='intent_policy_publish').length,0);assert.equal(h.storage.getItem(h.slot()),null);
  assert.ok(!h.document.body.textContent.includes('公司当前版本 1'));
});

test('a late original status callback must not clear a newer pending key and payload digest',async()=>{
  const first=deferred(),late=deferred(),newPublish=deferred();let reads=0,newKey;
  const h=operations(async(op,data)=>{
    if(op==='intent_policy_publish_status')return (++reads===1?first:late).promise;
    assert.equal(op,action);newKey=data.idempotency_key;return newPublish.promise;
  });const oldKey=seed(h),a=h.api.recover(action,target),b=h.api.recover(action,target);
  first.resolve({status:'succeeded',result:receipt(oldKey)});await a;
  const writing=h.api.write(action,expected,target);await waitFor(()=>newKey);
  const current=h.storage.getItem(h.slot());late.resolve({status:'succeeded',result:receipt(oldKey)});
  try{
    try{await b;}catch(error){assert.match(error.message,/原操作编号已变化|继续保留当前编号/);}
    assert.equal(h.storage.getItem(h.slot()),current,'late old key must retain the newer original key/digest');
  }
  finally{newPublish.resolve({status:'succeeded',result:receipt(newKey)});await writing;}
});

test('overlapping source reads must keep the newest source/company summary after the old initial read arrives',async()=>{
  const document=dom();globalThis.document=document;const first=deferred();let localReads=0,companyReads=0;
  const view={root:new Node('dialog'),status:new Node('p'),current:()=>true};
  const ui=createCompanyPolicyUI({createDialog:()=>view,scope:()=> 'fixture-stable-principal',
    read:async action=>action==='intent_rules_get'?(++localReads===1?first.promise:{summary:{revision:2,digest:'a'.repeat(64),can_manage:true}}):
      {summary:summary('fixture-current-company-key',++companyReads===1?2:1),can_publish:true},
    write:async()=>assert.fail('must not publish'),perform:async(view,control,fn)=>fn(),pending:()=>null,recover:async()=>assert.fail('must not recover')});
  const opening=ui.open();view.root.querySelectorAll('button').find(n=>n.textContent==='重新读取当前版本').click();
  await waitFor(()=>view.root.textContent.includes('公司当前版本 2'));
  first.resolve({summary:{revision:1,digest:'e'.repeat(64),can_manage:true}});await opening;
  assert.ok(view.root.textContent.includes('公司当前版本 2'),'old initial read must not overwrite company version 2');
  assert.ok(view.root.textContent.includes('本机已保存规则版本 2'),'old initial source must not overwrite source version 2');
});
