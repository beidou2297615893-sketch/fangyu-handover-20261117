/* Read existing repo facts over the existing actual SDK replay fixture.
 * This is not a production status API or router. All setup records are synthetic.
 */
'use strict';
const assert=require('node:assert/strict');
const crypto=require('node:crypto');
const {fixture}=require('../../cloud/workspace/business-reconciliation-fixture.cjs');
const {createStore}=require('../../cloud/workspace/index.js');
const {createHandoffLedger,repoFor}=require('../../cloud/workspace/handoff-ledger.cjs');
const {hash,canonical}=require('../../cloud/workspace/channel-candidates-fixture.cjs');
const tokenHash=value=>crypto.createHash('sha256').update(value).digest('hex');

async function main(){
  const f=await fixture(),source=await f.source(),keys={register:'synthetic-original-register',
    submit:'synthetic-original-submit',receipt:'synthetic-original-receipt',withdraw:'synthetic-original-withdraw'};
  const created=await f.call('acquisition_channel_register',{source_event_id:source.event.event_id,
    recipient_id:'resources',purpose:'租房咨询承接',qualification:'qualified',
    consent:{status:'granted',evidence_reference:'consent:'+'f'.repeat(32),notice_version:'v1'},
    idempotency_key:keys.register},f.tokens.source);
  assert.equal(created.status,200);
  const submitted=await f.call('acquisition_handoff_submit',{channel_id:created.data.item.channel_id,
    expected_revision:created.data.item.revision,idempotency_key:keys.submit},f.tokens.source);
  assert.equal(submitted.status,200);
  const accepted=await f.call('acquisition_handoff_receipt',{channel_id:submitted.data.item.channel_id,
    expected_revision:submitted.data.item.revision,idempotency_key:keys.receipt,decision:'accept',
    evidence_reference:'evidence:'+'e'.repeat(32)},f.tokens.resource);
  assert.equal(accepted.status,200);
  const store=createStore(f.data.db,'fixture-company'),ledger=createHandoffLedger({store,companyId:'fixture-company',clock:f.clock});
  const results=[];
  async function inspect(who,action,key){
    const before=f.data.snapshot();
    f.data.resetOperations();
    const result=await store.transaction(async(state,tx)=>{
      const session=state.sessions.find(row=>row.digest===tokenHash(f.tokens[who])&&row.username===who&&row.expires>f.clock()/1000);
      const actor=session&&state.users.find(row=>row.username===session.username&&!row.disabled&&['admin','operator'].includes(row.role));
      assert.ok(actor);
      const repo=repoFor(tx,'fixture-company'),row=await repo.get('operation:'+hash(['fixture-company',actor.username,action,key]));
      if(!row)return {state,result:{actor:who,action,record_found:false,original_execution_confirmed:null}};
      assert.equal(row.actor,who);assert.equal(row.operation,action);
      const historical=await repo.get(`event:${row.channel_id}:${row.revision}`);
      assert.equal(historical.actor,who);assert.equal(historical.operation,action);assert.equal(historical.revision,row.revision);
      assert.equal(historical.chain_hash,hash(Object.fromEntries(Object.entries(historical).filter(([key])=>!['companyId','chain_hash'].includes(key)))));
      const current=await ledger.readBoundItem(tx,state,actor,row.channel_id);
      const final=await ledger.readBoundItem(tx,state,actor,row.channel_id);
      assert.equal(final.item.revision,current.item.revision);assert.equal(final.item.last_event_hash,current.item.last_event_hash);
      return {state,result:{actor:who,action,record_found:true,original_execution_confirmed:true,
        historical_revision:row.revision,historical_status:historical.status,
        current_revision:final.item.revision,current_status:final.item.status,
        current_consent_valid:final.current_consent_valid,
        historical_resource_receipt_recorded:final.item.receipt?.authenticated===true}};
    });
    const counts=f.data.operations().flat();
    assert.ok(counts.every(row=>row.reads<=100&&row.writes===0));
    assert.equal(before,f.data.snapshot());
    results.push({...result,callback_operations:counts});
  }
  await inspect('source','acquisition_channel_register',keys.register);
  await inspect('resource','acquisition_handoff_receipt',keys.receipt);
  const withdrawn=await f.call('acquisition_handoff_withdraw',{channel_id:accepted.data.item.channel_id,
    expected_revision:accepted.data.item.revision,idempotency_key:keys.withdraw,reason_code:'customer_withdrew'},f.tokens.source);
  assert.equal(withdrawn.status,200);
  await inspect('source','acquisition_channel_register',keys.register);
  await inspect('source','acquisition_handoff_submit',keys.submit);
  await inspect('resource','acquisition_handoff_receipt',keys.receipt);
  await inspect('source','acquisition_channel_register','synthetic-missing-key');
  await inspect('source','acquisition_handoff_receipt',keys.receipt);
  for(const row of results.filter(row=>row.record_found&&row.current_revision===4)){
    assert.equal(row.current_status,'withdrawn');assert.equal(row.current_consent_valid,false);
    assert.equal(row.historical_resource_receipt_recorded,true);
  }
  assert.equal(results[4].historical_status,'accepted');
  console.log(JSON.stringify({synthetic_only:true,existing_repos_only:true,production_status_api_implemented:false,
    service_dispatch_budget_not_measured:true,results},null,2));
}
main().catch(()=>{console.error('SYNTHETIC_ORIGINAL_KEY_READ_PROBE_FAILED');process.exitCode=1;});
