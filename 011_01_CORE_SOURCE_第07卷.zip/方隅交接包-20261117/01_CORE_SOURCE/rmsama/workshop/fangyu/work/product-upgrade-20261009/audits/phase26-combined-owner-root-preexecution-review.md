# 组合 owner 良性代表：root 执行前审阅

Root 已逐字读取最终 parent、PowerShell wrapper 和 sleep child，并读取 adapter 与 C 独审。最终三源及四份候选证据逐 SHA 与冻结清单一致；C 独审冻结清单保持一致。本核对无 Native/CIM/账号操作。

仅允许唯一 GUID 的固定本项目 Pythonw、当前用户 Interactive/Limited、无 trigger/IgnoreNew/两分钟 Task。父创建原子受控 Job 中的 sleep90 子进程和独立合成 profile；两个固定 CIM 读取保留原 WMI 来源，并以实际 current TokenUser、原创建时间/parent、canonical exe/完整 argv、runtime 和 held Job admission 核对。只对该唯一子进程在 RAM 置 owner=None，调用默认 Native resolver 与实际冻结 classify。其他缺口阻断，首阻断不得被第二快照放宽。

证据只允许安全字段、计数和摘要；原 PID/SID/argv/path/句柄不落盘。每次 resolver 内同 HANDLE，跨快照比较真实创建时间/用户摘要；不得称一个 HANDLE 连续持有两次查询。父 finally 保持自有句柄直到退出确认；材料与当前 SID 再核。新脚本首验和注册后复验已审四 SHA，root 调度前另验 PS 自身 SHA。

这是刻意缺字段的良性代表，不是实际 WMI 故障复现、原 profile 空闲、Host 接线、账号恢复或平台采集批准。Root 只启动一次，完成后核对唯一 Task action/principal/结果来源并删除本 Task；不能停止或修改其他任务。候选原冻结资料继续保留，不借本阶段重复计数旧测试。
