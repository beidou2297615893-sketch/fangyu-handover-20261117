# Phase21 原生原账号元数据一次核对候选

候选已经准备，**尚未读取实际原库、执行 Scheduler 或启动助手**。仅新的合成 SQLite/账号活动文件三组代表验证通过，3/3，0.249s。生产源码、桌面入口、真实账号目录与其他任务均未修改。本轮不是新增权限审批，用户沿原账号小样授权由 root 保持；这里先提交可审看的诊断实现。

## 选型与明确边界

旧 `work/employee-update-20261009/run_native.ps1` 有成熟固定项目/Python、当前用户 Interactive/Limited 做法，但会覆盖通用同名任务并立即执行，不原样复用。旧 `native_web_demo_proof.py` 在同一目录，需要活实例及 loopback 健康读取，且硬编码旧版本，不适合当前原助手未运行的元数据核对。旧 `native_profile_probe.py` 包含整段 records body 遍历、下载包哈希及全目录枚举，本候选不使用这些操作。

新候选仅在当前用户原生视图读取必要本机记录，不构造 Core、AssistantService、AppServer、适配器或任何后台线程。以独立模块加载成熟 `core/account_safety.py` 的 `summarize_activity`，不通过 `core/__init__`。不安装组件、不调整许可、cloud bound 或账号状态，不清 requires_review，不读取或解密 device.dpapi、Cookie、密码、密钥、手机号和评论正文，不复制 SQLite。

原生执行检查 GetCurrentPackageFullName 必须返回 15700，并使用 SHGetKnownFolderPath 取得 LocalAppData，精确匹配 `C:/Users/rmsama/AppData/Local`。只允许 `fangyu-apartment-clientAssistant` 这一固定 DATA；拒其他客户、Packages/LocalCache 影子目录、符号链接/重解析路径和不匹配公司范围。该检查只界定诊断文件来源，不新增运行许可或修改 service 的授权模型。

固定现有历史账号 ID `a8050d3052c747fa99502b404c25cdba`。不存在时返回 account_found=false，不全库猜账号、不扫码、不创造账号。只读取 SQLite 的固定 JSON 字段，不 SELECT body、不读取整个账号/用户/任务原文，不输出裸 UID、owner、昵称或自由错误。UID/owner 只 present + SHA；task 只规范的 opaque ID、cached status/inflight/sequence_status、归属匹配标志，最多每实体 10 条并明确 truncated。

设备绑定仅检测 `assistant/device.dpapi` 文件是否存在，**contents_verified=false**，不冒称实际 bound 内容已经核验。users.cloud_bound/disabled 是另一个保存记录的元数据，不能替代当前云会话、设备权限、平台登录或实际读取许可。cached ready 与 activity 的 461/unknown/no_data 分别返回，不能以 ready 覆盖未复核风险。

SQLite 连接为 `mode=ro&immutable=1`，同时 PRAGMA query_only=ON 和禁止 SQL 写操作的 authorizer。immutable 用来避免创建/更新 WAL 的共享内存文件；发现非空 WAL 或 rollback journal 就拒读 DATABASE_PENDING_JOURNAL，不忽略待合并内容、不 checkpoint、不修库。正常连接在读取或拒绝后关闭。这不是跨进程的数据库锁；root 在运行前仍应核对真实原实例保持未运行。本 helper 明确 `instance_absence_verified_by_helper=false`，不依靠旧 running.json 自证这一先决事实。

## 候选文件与结果

1. `C:/积木软件工坊/项目/方隅公寓客户版/work/product-upgrade-20261009/phase21_native_original_account_metadata.py`
2. `C:/积木软件工坊/项目/方隅公寓客户版/work/product-upgrade-20261009/phase21_run_native_metadata_once.ps1`

所在文件夹：`C:/积木软件工坊/项目/方隅公寓客户版/work/product-upgrade-20261009`。

runner 使用已有 `work/desktop-python/Scripts/pythonw.exe`，避免控制台 UI。只注册一个当前用户 Interactive/Limited 的本任务 GUID 名称，无 trigger、Force、密码、Highest、新权限、助手启动或自动重发。不覆盖、删除或启停旧任务。执行 runner 会写 Scheduler 并启动这个短命诊断进程，不能称 Scheduler 本身零写；本次只做 PowerShell AST 解析，0 error，没有执行它。

每次显式 runner 生成一个 UUID，传 `--run-id`，只允许 32 位小写十六进制。结果只写本项目：

```text
C:/积木软件工坊/项目/方隅公寓客户版/work/product-upgrade-20261009/audits/phase21-native-original-account-metadata-<run_id>.json
```

同 run_id 的结果已存在就拒再次读原库，不覆盖旧证明。runner 输出 `execution_finished=false` 和预期结果路径，不把任务登记或两秒后的 LastTaskResult 当完成。root 应核对本次 run_id、输出状态 read/rejected/unavailable 和观察时间；结果不存在或失败不自动重发。只有 `state=read` 是本次本机元数据读完成，仍 `platform_session_verified=false`、`cloud_binding_verified=false`、`application_bootstrapped=false`。

## 合成验收及限制

新测试 `work/app/tests/test_phase21_native_original_account_metadata.py` 3/3：

- 新实际 SQLite 0 DML、query_only + immutable，读取连接已关闭；所有合成库/账号目录文件字节前后一致。敏感值放入其他字段和 Cookie/vault 文件，禁止读这些文件，公共 JSON 没有原 owner/UID/phone/正文/key/password/Cookie。SQL 只取 owner/UID 做内部匹配与哈希，不投影 phone/正文/key/password/Cookie 字段。禁止 Core/assistant 包导入、socket connect、Popen。
- 影子/其他 DATA 路径、不匹配客户、非空 WAL 和 package identity 拒绝，不修复或改字节。
- stored ready 同时出现旧 461、损坏活动和缺活动，正确输出 review_required/unknown/no_data，不生成平台成功或人为复核。

首运行有两个合成 fixture cleanup Error，原因是测试准备连接未显式关闭；已只修测试准备连接，日志保为 `phase21-native-original-account-metadata-first-fixture-cleanup-error.txt`。候选实际读连接原本即明确 closing；错误不算真实原库或平台 RED。最终同三组通过，不重跑整个 511 矩阵。

上述不是原生 Scheduler 运行、原库读取、当前账号绑定证明或真实平台成功。Windows KnownFolder 的实际原生执行和原库状态仍待 root 执行本次候选后按结果核验；本报告没有虚构实际结果 JSON。

源码/测试/日志 SHA 见 `phase21-native-original-account-metadata-candidate-hashes.json`。当前候选只新文件，无生产文件变更；已冻结的 Phase20 和 Phase21 safety-readonly 源/测试/manifest保持。
