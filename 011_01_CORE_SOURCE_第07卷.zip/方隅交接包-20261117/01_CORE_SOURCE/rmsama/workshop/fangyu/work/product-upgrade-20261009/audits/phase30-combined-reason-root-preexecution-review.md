# Phase30 组合原因观察：root 执行前核对

Root 已实际读取新 parent 全文、新 PowerShell wrapper 全文及两项合成方法源码；并读取旧 b796 parent、固定 classifier 与 adapter 的对应入口。新 `FixedSnapshotRehearsal` 维持完整 CIM 快照、当前 SID、创建时间/parent、固定运行材料、完整 argv 与 held Job 的门禁。仅 caller 在原 adapter 的一次 classify 前后接已冻结观察器，classification 原样保留，reason_trace 单独返回；观察器失败不替换原 verdict、不允许第二快照放宽首阻断。

新 parent SHA `CF766DF4C6D60AFA47D7CB99380650917281D4D4C1645D2B2F2A83E3984F84F3`；新 wrapper SHA `2D4FE5C418835AF48752F28A0409432E41790ABBC088B60C8BDA16AF67C7C768`。Root 另以 PowerShell AST 实际解析 wrapper，0 errors；旧 wrapper 实际 SHA 仍 `B44176F81EFD929C55BA911411C13F5D50C29BE5559DA5A4DD8AABF462D5E47F`。调度前还需核 agent 最终 manifest 与全套显式 pins，不能仅凭本文件声称已运行。

本轮允许一次全新 GUID 良性代表：固定本项目 Pythonw、当前用户 Interactive/Limited、0 trigger、IgnoreNew、两分钟唯一 Task；仅创建原子受控 Job 中的固定 sleep child 和独立合成 profile，按实际 CIM/TokenUser 读取，并只在 RAM 对该自有 child 演练一个 owner 缺字段。安全结果只保存摘要与白名单原因标签，不保存原进程路径、PID、SID、argv、令牌、异常正文或 frame locals。

没有原账号、原 profile、业务库、DPAPI、浏览器、CLI、云或平台请求。本代表不能恢复账号、授权原 profile 空闲或证明平台吞吐。完成后必须核对本次唯一 Task 的 actual action/principal/结果来源与自有退出，再只清理该 Task；失败不重复调度或放宽门禁。旧 b796 blocked/0/null 与首失败证据保留。

本核对仅审阅和解析，尚未运行 Native。公司 KMS 配置接线在独立云代码范围并行，不改变该良性代表的固定材料。
