# 真实小红书采集的最小下一步：既有主流程的可信运行配置

本轮仅本客户版规则、已存调查、生产源码和公开运行库元数据的只读选型。未运行 CLI、构造账号运行目录、读取业务库/Cookie/凭据、访问网络或调用模型/平台/云。使用已读取的 RevOps 规则判断入口、阶段与可验证事实；现有软件已完成的阶段不重做。不是商用、真实账号或吞吐验收。

## 推荐一个增量

先补**实际 Server 对可信小红书运行/许可策略的组合接线**，落在既有账号设置与私有快照单批入口，不再建只读审核页；随后才由用户选定账号进行最小明确授权读取。

确定的工程断点：`work/app/src` 全域检索 `platform_read_license_policy` 只有 `assistant/product_workspace.py:234/320/321` 三处消费，没有生产赋值入口。`AcquisitionRunPreflight` 的 provider 因此默认得到 `None`，在 `assistant/acquisition_run_preflight.py:202–205` 记为 `license_unavailable`。R22 的 `core/platform_reads.py:386–391` 也要求可信 policy 真值。合成夹具注入可证明门禁分支，不能证明实际 Server 已具備此策略。

`core/platform_capabilities.py:119–120` 的许可声明/`license_reviewed` 只是能力目录信息，其输出固定 `grants_access:false/operational:false`，不构成上述 provider。不能静默转成许可授权，也不能把一个前端勾选框或硬编码 `True` 当许可审核。下一实现应明确可信策略来源、精确运行库版本/摘要与审核依据；缺依据仍 unknown，否决仍 blocked。不要通过改 hold、伪造审核或写原账号来让预检变绿。当前源码只能确认这一组合缺口，未读取实际部署配置，不能断言它是实际机器唯一阻断原因。

## 已成熟的复用路径与限制

| 复用点 | 精确源码 | 本次能确认的边界 |
| --- | --- | --- |
| 账号人工恢复、再核对 | `web/workspace/platform-account.mjs:282–300` | 先本人确认手机正常、限制解除、上次结果已核实，再走既有恢复/检查；不能自动清风险或只改 ready |
| 指定路线和运行库一致性 | `app.py:80–89/235–265/276–305/343–371` | guarded CLI 为缺省；自然页面需明确既有授权入口；当前平台 guard、指定设备与已验证运行库仍有效 |
| 预检→任务复读→明确原任务单批 | `web/workspace/upgrade-operations-ui.mjs:238–297`、`web/workspace/app.mjs` 的 `runPrivateStrategyBatch/startSavedTask` | Phase17 入口已接，旧 unknown/pending、scope、原任务摘要与单批限制不能绕开；不把旧台账“入口待补”当新缺口 |
| 每次实际读取前复核与断点 | `core/pipeline.py:42–118/167`，`assistant/business.py:256` | 搜索、主评论、楼中楼是不同读取；原关键词/帖子/游标断点继续复用 |
| 单次传输与异常暂停 | `platform_cli.py:169–203`、`assistant/xhs_page_runtime.py:319` | 复用现有未知/风险阻断和账号隔离；不能因只读搜索就忽略已记录 HTTP461 |
| 精准客户的证明 | 软件意向抽检、来源归档与经营阶段已有模块 | 唯一评论、人工确认高意向、实际回应、同意转交是不同指标；采集成功不能直接计精准客户/成交 |

不调用 `core/adapters.py:335` 的 `account_spec` 来做纯预览：它会建立隔离目录。`core/adapters.py:400` 会按所选 page runtime 改实际运输；`manifest.search_verified/available` 仍只是静态/既往状态，不是本次实际读取证明。楼中楼含 xsec context 时需保留 `core/adapters.py:720–735` 的 guard manifest `upstream_pr81` 约定，不能将 stock CLI 与项目补丁视为同一能力。

已存 `audits/cli-route-audit.md:7/22/47–48` 记载旧 CLI 首搜索/首评论 HTTP200、后续 HTTP461 且手机异常，新自然页面连续链路未实测。它的“当前500词上限”是旧阶段历史，已被私有5万词库/最大100词快照替代，不据此重复限制当前词库。运行库 `work/app/work/runtime/platform-cli-guarded/guard-manifest.json` 的公开字段为 `purpose=internal_qa_only/sub_comments_query=upstream_pr81/source_sha256=2580bd579de76191a5bfd33109c612287f19c94bc55dc10fb64873a31676bb31`。本轮没运行或重验该运行库；内部 QA 标记不能改称正式发布许可。该目录根部未见 LICENSE 文件，不推断整个分发树无许可，也不以旧 GitHub license=null 判无授权。

## 必须由用户提供/在原界面确认的事实

1. 本次小样允许使用哪一个**本人拥有的账号和设备**；在现有账号页面选择，勿发送 Cookie、密码、token 或其他账号凭据。
2. HTTP461/手机异常之后，手机当前是否正常、是否仍有验证码/限制、最后未知操作是否已核清。我们无本轮真实状态证据，不代替人工确认，也不擅自恢复原账号。
3. 该精确 CLI/补丁分发的许可审核依据、当前托管公司与指定设备的平台执行批准/有效权益。软件套餐权益、开源分发许可、平台账号是否允许执行三者独立，任一缺失不可把其它真值当替代。
4. 真实公寓业务匹配资料：地区、租期、预算/入住期、本人找房与中介/泛聊区别。没有这些资料和人工样本，不能用“高分”证明每条均是精准客户。

## 我们可以独立补齐，以及下一代表

可独立补齐的是实际应用组合的可信策略读取/快照与既有入口缺项说明；精确包许可材料若现有项目资产可证明则复用，不能自行创造审批。保持原数据与会话，非原配置上做隔离代表：provider 缺失→unknown，否决→blocked，可信许可存在但 HTTP461/UID 重复/占用/hold→仍阻断；策略或 actor/device/原任务/租约变化后拒用旧预检。测试不调用 `account_spec`、CLI 或网络；只验证真实组合路径而非直接手工给 helper 注入 true。

在用户明确允许且既有门禁全部满足后，真实代表才是：**一个指定账号、一个指定词→一个合法来源帖的主评论页→一个后续游标或楼中楼页→归一化/来源归档→人工抽检**。这是旧200后461的最难小样，首搜索成功不足以关单。由根窗口选合法既有 QA/运行许可入口，不修改 release/hold 标记来绕过。

`max_batches=1` 不等于一个 HTTP 请求：`pipeline.collect_batch` 可能先搜索再读评论，所选 CLI/comment-depth 又可能内部多请求。现预检 `platform_http_limit/request_upper_bound/duration` 仍 null。因此运行前应把实际运输请求预算/异常停止条件定清，不能用关键词槽或单批按钮承诺速率安全。若现有运输不能严格约束这个代表，就先做离线预算/停止能力增量，不能开始真实探测后再讨论上限。

验收只记真实发生的请求/异常、可归一化的唯一来源、断点与原号恢复、人工确认高意向；任一验证码/461/未知结果立即停，保留原状态，零自动重放。成功后仍不代表每日500/1000/10000客户、自然页稳定、回复目标已可信、公司独立接收或到账。暂不接新平台、不装另一套爬虫、不发送/部署/打包。
