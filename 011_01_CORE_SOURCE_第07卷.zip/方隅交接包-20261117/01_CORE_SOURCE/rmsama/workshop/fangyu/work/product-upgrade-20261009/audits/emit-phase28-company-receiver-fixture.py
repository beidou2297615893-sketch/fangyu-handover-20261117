"""Emit actual two-Core receiver DTOs; all identities/company data synthetic."""
from copy import deepcopy
import hashlib
import importlib.util
import json
from pathlib import Path
import socket
from tempfile import TemporaryDirectory
from unittest.mock import patch

AUDITS=Path(__file__).parent
PROJECT=AUDITS.parents[2]
spec=importlib.util.spec_from_file_location('phase28_actual_receiver_fixture',AUDITS/'test_phase28_company_handoff_receiver.py')
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)


def generate():
    folder=PROJECT/'work/product-upgrade-20261009/tmp/phase28-company-receiver-emitter'
    folder.mkdir(parents=True,exist_ok=True)
    with TemporaryDirectory(dir=folder) as base, patch.object(socket.socket,'connect',side_effect=AssertionError('no network')):
        f=module.ReceiverFixture(Path(base)/'loss')
        cases={};counts={};envelopes={}
        def collect(name,action,data=None):
            before=f.dump();value=f.call(action,data)
            assert before==f.dump()
            body={} if action==module.LIST and data is None else {'channel_id':f.channel} if data is None else deepcopy(data)
            cases[name]={'action':action,'request':body,'result':value,'local_database_unchanged':True}
            counts[name]=f.command({'kind':'counts'})
            envelopes[name]=deepcopy(f.envelopes[-1]) if f.envelopes else None
            return value
        try:
            collect('choose_authorized_recipient',module.LIST)
            collect('received_list',module.LIST,{'recipient_id':'resources'})
            collect('ready',module.DETAIL)
            def during_claim():collect('unknown_inflight',module.GET)
            f.before_receipt=during_claim;f.lose_response=True
            try:f.call()
            except module.CompanyHandoffReceiverError as error:
                assert error.mutation_committed is None
                failure={'code':error.code,'mutation_committed':None}
            else:raise AssertionError('commit-lost fixture must lose response')
            f.command({'kind':'restart'})
            restarted=module.Core(f.core.store.directory,f.core.resources_dir)
            try:
                f.service=f.make_service(restarted)
                collect('recorded_after_response_loss',module.GET)
                replay=collect('same_original_write_is_read_only',module.RECEIPT,f.request)
                assert replay['read_only'] and not replay['cloud_receipt_requested']
                f.command(dict(kind='withdraw',channel_id=f.channel))
                collect('withdrawn_preserving_historical_accept',module.GET)
            finally:restarted.close_continuous_scheduler(wait=True);restarted.adapters.close()
            finalcounts=f.command({'kind':'counts'})
            assert finalcounts==dict(register_calls=1,submit_calls=1,receipt_calls=1,channels=1)
            resource_empty={entity:f.core.store.list(entity,f.tenant)==[] for entity in
                ('leads','tasks','acquisition_handoffs','company_handoff_preparations')}
        finally:f.close()
        g=module.ReceiverFixture(Path(base)/'success')
        try:
            result=g.call();assert result['state']=='recorded' and result['mutation_committed']
            cases['recorded_success']={'action':module.RECEIPT,'request':deepcopy(g.request),'result':result,'local_database_unchanged':False}
            counts['recorded_success']=g.command({'kind':'counts'});envelopes['recorded_success']=deepcopy(g.envelopes[-1])
        finally:g.close()
    paths=['work/app/src/assistant/company_handoff_receiver.py','work/app/src/assistant/company_handoff_receiver_transport.py',
        'work/app/src/assistant/product_workspace.py','work/app/src/assistant/company_handoff_status_transport.py',
        'work/app/src/assistant/company_handoff_submission.py','work/app/src/assistant/company_handoff_registration.py',
        'work/cloud/workspace/handoff-ledger.cjs','work/cloud/workspace/service.cjs','work/cloud/workspace/index.js',
        'work/cloud/workspace/handoff-operation-status-fixture.cjs',
        'work/product-upgrade-20261009/audits/phase28-company-receiver-sdk-worker.cjs',
        'work/product-upgrade-20261009/audits/test_phase28_company_handoff_receiver.py',
        'work/product-upgrade-20261009/audits/emit-phase28-company-receiver-fixture.py']
    return {'synthetic_only':True,'real_company_network_called':False,'real_platform_called':False,
        'fixture_execution':'two_actual_local_cores_and_actual_project_service_createStore_repositories',
        'transaction_engine':'SDK_interface_memory_double_callback_adapter_not_node_sdk_engine',
        'contract':'company_handoff_receiver_v1','scope':{'environment_id':'fixture-env','company_id':'fixture-company',
            'source_actor':'source','receiver_actor':'resource','receiver_device':'fixture-resource-device'},
        'receiver_source_local_records_empty':resource_empty,'cases':cases,'request_counts':counts,
        'actual_company_envelopes':envelopes,'loss_error':failure,'final_loss_case_counts':finalcounts,
        'source_sha256':{path:hashlib.sha256((PROJECT/path).read_bytes()).hexdigest().upper() for path in paths}}


if __name__=='__main__':
    output=AUDITS/'phase28-company-receiver-actual-fixture.json'
    output.write_text(json.dumps(generate(),ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(str(output));print(hashlib.sha256(output.read_bytes()).hexdigest().upper())
