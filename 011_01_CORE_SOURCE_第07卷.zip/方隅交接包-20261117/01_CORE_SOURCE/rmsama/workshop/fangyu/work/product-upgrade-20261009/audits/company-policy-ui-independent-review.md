# 公司规则发布 UI 独立审查

2026-10-10。本切片当前可冻结，新增代表测试 6/6 通过。没有修改生产源码或原测试，没有联网、真实账号、原数据库或 provider 调用。此结果是离线代码验证，不是浏览器 GUI、真人操作、云部署或完整软件验收；原有 154 + 36 项不计入本报告。

审查源：

- `work/app/src/web/workspace/company-policy-ui.mjs`
- `work/app/src/web/workspace/upgrade-operations-ui.mjs`
- `work/app/src/assistant/company_intent_policy.py` 的返回契约

代表测试执行完整实际 `createUpgradeOperations` factory、真实 `createCompanyPolicyUI` 和另外四个实际依赖 helper。仅适配服务器的 `?asset=` 模块路由与 ESM 导出语法，使其在 Node VM 运行；没有复制、替代或模拟生产函数实现。DOM、存储和传输是合成 fixture，不代表原生浏览器。

## 已核对的契约

- 本机 `safe_projection` 的 19 个 metadata 字段与前端摘要校验对应；发布版本须至少 1，来源本机版本可为 0。
- 本机成功、未知及“历史成功 / 当前云核验未知”分开表达。后者保留原成功 `state`、`mutation_committed:true`、原 `summary`，同时 `current_cloud_verified:false`、`cloud_current_state:'unknown'`、`requires_revalidation:true`。前端 recovery 只在当前云核验明确成功时解锁。
- 前端写入在校验原键、来源版本 / digest 和预期公司版本后才清待核对槽。原状态恢复后另读本机来源和公司当前摘要，不将旧发布回执直接显示为当前版本。
- `operationScope` 包含员工 id、username、tenant、role 和设备 id / generation；读取结果和视图回调复核当前 scope。此项另作源码核对，没有宣称真人身份切换 GUI 已验。

## 红例与修复复核

同一窗口的初始读取未返回时，点击“重新读取当前版本”，第二次读取先显示公司版本 2；随后第一次读取返回版本 1，旧实现把当前公司版本及本机来源覆盖回版本 1。真实源码代表测试先失败，断言为 `old initial read must not overwrite company version 2`。root 增加每次 `load()` 的 `readGeneration`，每个 await 后只允许最新代次写入；同一代表测试现通过。

静审也指出原状态回调在等待期间可能遇到新待核对槽，需要对 action / 原键 / payload digest 作 CAS。首轮测试运行时 root 已增加 `clearOriginal(slot, original)`，旧回调正确拒绝，测试最初因未允许这次安全拒绝而报错。随后仅调整独测，使其允许 CAS 拒绝并严格断言新槽原文字节未改变；此项现在通过，不将该 harness 报错冒充生产缺口。

## 六个代表测试

1. 真实摘要 / 回执校验拒绝版本 0、相互矛盾的当前核验标记和错误来源 digest。
2. 真实写入收到错误来源回执时保留待核对槽。
3. 历史成功但当前云核验未知时保留原编号，`resolved:false`。
4. 原状态成功恢复后重新读取当前摘要；显示新版本 3，未重新 publish。
5. 迟到的原状态回调不能清掉新键及新 payload digest 的待核对槽。
6. 重叠读取保持最新公司摘要和本机来源。

运行命令：

```text
node --test --test-reporter=tap work/product-upgrade-20261009/audits/company-policy-ui-independent.test.mjs
```

最终执行：6 项、6 通过、0 失败。

复核时 SHA256：

```text
company-policy-ui.mjs
3522B65AC47DCA997178772EF9A3BA1D8F3FFD7B41A5967FF8397F1AEA402BBD

upgrade-operations-ui.mjs
1BDD465B4ABA8E70F47BA53EE63CDF9C19613692E2B2C9D4E66BC377225C4DDD

company-policy-ui-independent.test.mjs
DF70A139921DBCE8A3B958A2034DA501CBCCA0B37F3B890A094FF0FB7D8B42DC
```

当前未发现本切片尚未关闭的阻断项；其他集成链路及 GUI 验收由主任务继续核验。
