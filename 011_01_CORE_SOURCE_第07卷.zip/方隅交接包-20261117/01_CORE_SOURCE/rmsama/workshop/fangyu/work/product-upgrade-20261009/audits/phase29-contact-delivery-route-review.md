# Phase29：跨员工联系方式交付路线审查（只读候选）

日期：2026-10-10。目标：本人获客后，将客户主动同意用于该公司租房对接的电话或微信，交给当前获权资源部员工在另一台电脑使用。本轮只读取源码、需求台账与官方资料，新增本报告；未读真实凭证/原库，未运行测试、安装依赖、调用客户账号/KMS、提交云数据、部署或修改 Phase28 冻结源。

## 结论与商业取舍

推荐下一最小完整切片为“当前有效联系方式明确交付 → 公司密文保存 → 指定接收人显式查看 → 撤回阻止再次查看”，复用现公司交接、receiver 映射、来源精确核对、同意墓碑和原操作编号恢复。它直接补 R07/R21 的资源部实际承接能力，比增加套餐或另建 CRM 更有价值。当前 UID-only 公司提交能证明原来源/提交/授权接收事件，却仍不能让资源部直接拨号或加微信；不得把现接收回执当联系方式已送达。

采用腾讯云 KMS 的小数据直接 Encrypt/Decrypt 与 CloudBase 私有文档持久化，优先官方 SDK。当前项目**没有已接好的 KMS provider**，不能直接宣称复用现服务器托管密钥；可先实现并验证隔离候选，再分别验实际 KMS 和两台真实电脑。服务器在受控请求中会短暂接触明文，因此这是服务器托管加密方案，不是服务器不可见的端到端加密。若未来要求公司/服务器也不能看明文，需要另行评估员工设备公钥、丢机恢复和换钥成本，不能混入本切片。

## 当前源码真正已有的能力

| 位置 | 已有能力与不能代替的能力 |
|---|---|
| `work/app/src/assistant/acquisition_contacts.py:37–116` | `AcquisitionContacts` 按当前持久员工、tenant、owner、lead、recipient/purpose/consent 约束；`contact:<32hex>` 指向 CurrentUser DPAPI 密文。`_view` 默认掩码，同意来源是操作人登记、未独立核验。第二电脑/另一 Windows 主体不能据此解密。 |
| 同文件 `execute:185–195、211` | `contact_read(reveal:true)` 解密并追加 `revealed` 审计，是有本地写入的显式操作。`contact_revoke` 写永久 consent withdrawal、清同授权密文；不能把它称为零写读取，也没有公司云撤回同步。 |
| `work/app/src/integrations.py:41–58`；`assistant/service.py:31` | Windows DPAPI 与 `DeviceVault` 保护本机配置/设备凭证；不是企业跨机联系人密钥服务。不得同步 DPAPI 文件、Cookie、Windows 主密钥或把共享静态主密钥放客户端。 |
| `work/cloud/workspace/handoff-ledger.cjs:61–68、173、313、320、441` | 同意墓碑、可信 session/actor/company、资源部门映射、当前授权与历史原动作回执、`readBoundItem` 已可复用。公共交接仍明确 `contact_delivery:'platform_reference_only'`；source 自 ACK 禁止，manager 可看交接不等于可看电话。 |
| `cloud/contact_ledger.cjs`、`source_binding.cjs` | 来源事件/客户关联和精确事件核对，名称中的 contact 不代表已有电话/微信密文库。不得将联系方式塞进原来源正文、同步事件或订单公共结果。 |
| `assistant/company_handoff_receiver*.py` | Phase28 跨员工公司收件 list/detail/显式 ACK 与原号只读恢复；无资源员工联系方式解密接口。可复用鉴权与不续期传输，不能将其 metadata-only 回执 raw spread 成明文通道。 |
| `cloud/index.js:61–75`、`package.json` | `TCB_ENV/COMPANY_ID` 固定服务器范围、CloudBase 初始化；现唯一依赖 `@cloudbase/node-sdk:3.18.3`，Node 要求 `>=20`。无 KMS Region/KeyId/客户端或可信服务角色接线。 |

需求依据：`outputs/产品升级/需求交付与证据台账.md` 的 R03/R07/R18/R21/R25，以及 `功能优先阶段进度.md`。R03 的软件可记录来源与交付过程，不能独自证明外部成交归属；R18 的未知结果必须保留原号；R25 的保留数据/不打包/不外发仍适用。本切片不改旧电话、不迁移旧库、不提高旧同意证明等级，不把接收/查看变成客户已联系、成交、回款或佣金已付。

## 已核成熟技术路线、环境和真实配置边界

腾讯云官方直接加解密接口用于不超过 4 KB 的敏感小数据。电话/微信的严格小 JSON 可落在此范围：按 UTF-8 原始字节限制而非 Base64 字符数，拒绝正文/附件/超限，不在第一版设计 DEK、本地 AES、nonce 或自制密码学。[官方加解密说明](https://intl.cloud.tencent.com/document/product/1030/32788)、[官方 Encrypt API](https://cloud.tencent.com/document/api/573/34420)。

官方 Node SDK 有 KMS 产品，产品表记录 2026-08-25 更新；仓库 package 声明 Node `>=10`、Apache-2.0，和本项目 `>=20` 要求没有声明级冲突。候选优先按产品包 `tencentcloud-sdk-nodejs-kms`，实施时锁定实际包/依赖版本、保留 LICENSE/NOTICE 并做必要装载代表；本轮没有安装，仓库维护状态、许可声明和环境声明不等于集成已验。[官方仓库](https://github.com/TencentCloud/tencentcloud-sdk-nodejs)、[产品表](https://github.com/TencentCloud/tencentcloud-sdk-nodejs/blob/master/products.md)、[package](https://github.com/TencentCloud/tencentcloud-sdk-nodejs/blob/master/package.json)、[LICENSE](https://github.com/TencentCloud/tencentcloud-sdk-nodejs/blob/master/LICENSE)。

EncryptionContext 的加解密值须对应；建议仅服务器派生 company/environment/channel/contact-version/consent/recipient/purpose 的规范上下文，不能包含电话、微信或密钥，也不能由客户端提供 KeyId、region、算法或 endpoint。实际地域/KeyId/密钥状态由可信部署输入固定，旧密文保留原 KeyId/context，后续轮换不能只改配置后强行用新 KeyId 解旧密文。[官方 Decrypt API](https://intl.cloud.tencent.com/zh/document/api/1030/32198)。

CloudBase HTTP 函数文档说明它不会自动注入腾讯云 SecretId/SecretKey；现 `CLOUDBASE_APIKEY` 初始化成功也不能证明 KMS IAM 权限。优先采用实际运行环境支持的受限服务角色/短期凭证，KMS 只在服务器使用，限制指定密钥的 Encrypt/Decrypt，客户端不能取得腾讯云凭证。若该运行环境不支持所选角色链，应明确缺项，不能把数据库 API key 当 KMS credential。[CloudBase 鉴权说明](https://docs.cloudbase.net/cloud-function/resource-integration/cloudbase)、[云函数角色](https://cloud.tencent.com/document/product/583/47933)。

本轮只审源配置接口，**没有读取真实环境变量、DPAPI config/session 或 IAM**。不能据此证明现真实云已配置/未配置 KMS、当前登录有效或受信角色可调用。用户已授权此项目开发；本地候选可继续，无需重复开发授权。实际配置、KMS 调用费用/保留期限、真实上传和部署仍是独立运行条件，本报告未执行，不制定价格/购买方案。

## 最小协议候选与可信边界

第一版只关联已有公司 channel，不更改原 register 的 platform_reference payload/hash 和历史 ACK。新增独立 private contact-vault 文档与专属 metadata 操作回执，复用现 store/company namespace/单文档事务。一般 list/detail 只返回 opaque contact-version、`has_phone/has_wechat`、当前可用性/原因、授权范围与历史 access 元数据；不返回正文、裸 UID、联系电话、凭证引用、KMS 明细或 ciphertext。私有集合须只有服务端访问路径，不能因 CloudBase 客户端规则开放而旁路读取。

建议先锁四类动作，具体名字/字段须在实施前和网关/前端共同定稿：

| 动作 | 输入和行为 |
|---|---|
| 明确交付 `company_contact_publish` | 本机输入仅 handoff/origin ID、当前 handoff/cloud/contact revision、既有 `contact_reference`。local server 按本人/当前 lead/source/recipient/purpose/notice/consent、设备/env/company 和永久墓碑重新核对，再在内存解密一次，固定云 action/body；不接受前端提供 owner、policy、phone 或 KeyId。云端只允许原来源主体给该当前 channel/recipient/purpose 上传，保持当前云同意与 exact source gate。 |
| 专属 metadata status/get | 根据已持久 original action/key 查结果；不上传、不解密、不换号，缺记录仅 unknown，不能由 absence 推出未提交。当前 handoff 七写动作 status 不支持新 contact 操作，必须扩专属窄合同，不能伪借旧 register 回执。 |
| 明确查看 `company_contact_reveal` | 当前 mapped receiver、明确选定部门、有效 purpose/consent/contact-version 与已提交/已接受 channel 才可申请。admin/manager 的一般交接可见权不能自动授予解密权。权限校验后 KMS Decrypt，返回前再核 actor/session/device/company、recipient/同意墓碑、vault revision 与当前 channel；将受控 access 元数据登记后，只在本次专属响应内返回 phone/wechat。不是普通 pure-read GET。 |
| 明确撤回 `company_contact_withdraw` | 原授权的公司墓碑优先、停止后续 reveal 并清有效密文，保留历史 access/ACK。不自动恢复、旧 consent ref 不复用；本机撤回与公司收到撤回分别显示，离线/未知时不能称公司已生效。 |

本机原授权必须真实覆盖“向该公司指定资源部门提供联系方式用于租房对接”；当前操作人勾选证据仍是 `operator_recorded`，不能升级为客户独立核验或平台证明。已有电话号码/微信存量默认不批量上传。若手机号用途/接收方/告知版本变化，需要新明确同意证据；不根据昵称、手机号相似或历史 ACK 合并客户。

各写动作采用专属一次 CAS 与稳定原 key：先验证可信 provider 已配置及输入权限，再事务绑定原 key/channel/contact-version/consent/context 并持久单 attempt；KMS 只在事务外调用一次；随后事务重新检查全部当前权限/原范围与 CAS，保存 ciphertext 和 metadata 终态。SDK 事务 callback 重放不能再次触发 KMS。[CloudBase 事务限制](https://docs.cloudbase.net/database/transaction)为最多 100 操作/30 秒/单 doc；最难代表必须实数每个事务操作，外部 KMS 不能塞进事务，本地 adapter 耗时不能冒称真实云性能。

同 key 已有 attempt 后不得接受替换内容或第二次 Encrypt；只允许专属 status，不缓存/重播明文响应。公开元数据不存电话/微信的裸 SHA256（低熵号码可猜），只记录原范围/版本和 ciphertext 完整性摘要。改变联系方式必须显式新版本，且原 unknown 不因换版本/KeyId/主体被绕过。已知提交前校验拒绝可明确该次未提交；一旦 attempt 已占用或请求可能执行，丢响应/重启保持 unknown，直到原回执可核。若 Encrypt 成功但后续持久化未确认，不能自动再 Encrypt 或冒称未执行，需保原号停住核对；不为了可用性偷偷更换 key。

reveal 的 access 回执只证明服务器登记过该次释放，不证明用户已看到、拨号、添加微信或客户接听。明文不入本机 records/sessionStorage/clipboard 自动复制/日志/错误正文、普通导出/静态站，响应设置不缓存，UI 关窗或身份变化清空显示；高级语言内存/已经看到的截图无法保证立即抹除或召回。撤回能阻止未来读取，不能收回对方已看到或另行保存的号码。现 historical resource receipt、`platform_delivery_verified:false`、`verified_cash/paid:null` 保持各自意义。

## 实施文件范围与最难代表性验收

候选增量文件：云 `contact_delivery.cjs`（权限/密文文档/专属 attempt/status）+ `kms_contact_provider.cjs`（官方 SDK 适配）；窄改 `index.js/service.cjs` 注入可信 provider/路由。本机新 `company_contact_delivery.py`/专属 transport，product gateway 和现 receiver UI 加一个明确交付/查看入口。现 `AcquisitionContacts` 的授权/墓碑/解密语义优先复用；若需提取内部安全调用，先锁责任范围，不改变 DPAPI 算法或一般 contact_read 的审计含义。不启动 Service worker、队列、云 claim、AI 或平台联系。

先做以下三个有意义方法，第一条最难通过后再扩；只实际 Core + 当前 createService/createStore + SDK 接口隔离 adapter + 官方 KMS 客户端 stub transport，不做真实云/KMS：

1. 来源本人真实合成 DPAPI contact + 公司 exact channel/consent → 唯一 publish → 另一 resource Core（空原 lead/contact 库）显式 reveal；本人/未映射员工/同企业无该部门 admin 均不能自授，DPAPI 原文/文件不被复制。KMS stub 仅返回 opaque ciphertext 及合成结果，不自写“加密算法”；观察 request count、DB/log/公共 JSON 无明文。它证明协议和边界，不证明 KMS 加密或两台真实 Windows 已验。
2. 两 Core/重复 callback 与 publish commit 丢响应 → 重启原 status recorded，零第二 publish/Encrypt；缺回执 unknown hold。KMS await 后撤权、换 actor/device/company/purpose/原 source 或 consent tombstone，拒绝明文/终态误成功；reveal 丢响应不缓存再播放电话。
3. 当前撤回/过期/坏 ciphertext/错误 KeyId/context/服务不可读 fail closed，旧同意不能重用，历史接收/access 保留；本地撤回未获公司回执保持“公司撤回待核”，不隐瞒传播延迟。provider missing 时不解密本机联系方式、不上传、不自动申请权限。

隔离 GUI 验收只显示同公司合成两主体链路：来源交付、资源部明确查看、未知原号核对、撤回后历史与当前并列；不得用合成截图宣称真实数据已跨机。真实上线另需当前目标公司/env/session/device 的有效性、CMK/IAM/地域和真实 SDK roundtrip、实际两 Windows 身份/两电脑、日志与缓存配置验证；这些是环境验收，不另造许可审批或用户重新批准开发的页面。

## 本轮证据与未实现边界

阅读时 SHA256：

- `acquisition_contacts.py`：`073D4816D292A8AD2821C22CCCC5FE7BF1FC45BD3C10745908C0704D3D3C222C`
- `cloud/index.js`：`223A150519F3BCACE360D35BBDAF876DEEAB74AF426D415A3DF3B259DA2AFF1B`
- `cloud/handoff-ledger.cjs`：`70CE35EA77F66D752A5F94461EAEF449CDD6AD722F40848E5AA5CC855A769611`
- `cloud/service.cjs`：`EF59DD56EED438727C0C844A011BCB240AA78A5E607D01D96DCC407153FD1FFF`

实际读取 `consent-registry/SKILL.md`，仅应用其最小证据、当前撤回优先与不按相似合并原则；引用的独立 registry runtime/protocol 在该 Skill 相对路径未找到，本项目现 records/公司墓碑仍为真实实现，本轮没有声称调用 registry-runtime 或建立新总账。官方 Encrypt 文档直页部分打开超时，4KB/context 结论来自官方搜索可读结果与官方加解密/Decrypt/SDK 源；未为获取文档执行安装或模型/账号调用。

本报告是路线候选，**跨机联系方式交付、实际 KMS、真实接收员工查看、电话/微信联系、成交或分成支付均未在本轮实现或验收**。Phase28 冻结源码/旧证据保持原样。
