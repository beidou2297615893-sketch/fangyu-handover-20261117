/* New actual SDK/service replay only. No production transport, account or DB. */
const fs=require('node:fs');
const path=require('node:path');
const assert=require('node:assert/strict');
const crypto=require('node:crypto');
const root=path.resolve(__dirname,'../../cloud/workspace');
const {fixture,source,discover,draft}=require(path.join(root,'channel-candidates-fixture.cjs'));
const digest=filename=>crypto.createHash('sha256').update(fs.readFileSync(filename)).digest('hex').toUpperCase();
(async()=>{
 const f=await fixture(),prepared=await f.source();let item;
 for(let i=0;i<6;i++)item=await draft(f,prepared.event);
 const events=[...f.data.docs().values()].map(value=>value?.record).filter(value=>
   value?.event_id&&value.employee==='source'&&value.lead?.id===prepared.event.lead.id)
   .sort((a,b)=>a.occurred_at-b.occurred_at)
   .map(record=>{const raw=Object.fromEntries(['event_id','kind','occurred_at','lead','reply','sender'].map(key=>[key,record[key]]));
     if(Object.hasOwn(record,'intent_snapshot'))raw.intent_snapshot=record.intent_snapshot;return raw;});
 assert.equal(events.length,2);
 const sources=events.map(event=>source(f,event)).sort((a,b)=>a.event_id.localeCompare(b.event_id));
 const before=f.data.snapshot();f.data.resetOperations();
 const first=await discover(f,sources);assert.equal(first.status,200);
 const second=await discover(f,sources,{scan_offset:5,expected_owned_index_count:6});assert.equal(second.status,200);
 assert.equal(first.data.discovery.candidates.length,5);assert.equal(second.data.discovery.candidates.length,1);
 const envelope=await f.summary({item});assert.equal(envelope.status,200);assert.equal(f.data.snapshot(),before);
 const files=['channel_candidates.cjs','service.cjs','handoff-ledger.cjs','contact_ledger.cjs','index.js'];
 const source_hashes=Object.fromEntries(files.filter(filename=>fs.existsSync(path.join(root,filename))).map(filename=>[filename,digest(path.join(root,filename))]));
 const out={synthetic_only:true,evidence_type:'actual_createService_createStore_sdk_double_callback_replay',
   company_id:'fixture-company',environment_id:'fixture-env',owner:'source',device_id:'fixture-source-device',
   source_hashes,events,event:events.find(value=>value.kind==='sent'),envelope:envelope.data,
   sources,first_envelope:first.data,second_envelope:second.data,operation_counts:f.data.operations()};
 fs.writeFileSync(path.join(__dirname,'business-channel-candidates-cloud-actual-fixture.json'),JSON.stringify(out,null,2)+'\n');
 console.log(JSON.stringify({events:events.length,first:5,next:1,read_only:true,source_hashes}));
})().catch(error=>{console.error(error);process.exitCode=1;});
