from pathlib import Path
import hashlib, json, re, stat, sys, uuid

project = Path('C:/积木软件工坊/项目/方隅公寓客户版')
stage = project/'work/product-upgrade-20261009'
source = project/'work/app/src'
candidate = stage/'owner-douyin-saved-history-candidate'
receipt_path = stage/'audits/owner-douyin-saved-history-joined.json'
if len(sys.argv) != 5 or any(not re.fullmatch(r'[A-F0-9]{64}', x) for x in sys.argv[1:]):
    raise ValueError('Require reviewed freeze, source pins, backend and frontend review hashes')
freeze_pin, pins_pin, backend_pin, frontend_pin = sys.argv[1:]
if receipt_path.exists():
    raise ValueError('Already joined')

def read(path, pin=None, size=None):
    attrs = path.lstat()
    if (not path.resolve(strict=True).is_relative_to(project.resolve())
            or path.is_symlink() or getattr(attrs, 'st_file_attributes', 0)&0x400
            or not stat.S_ISREG(attrs.st_mode) or attrs.st_nlink != 1):
        raise ValueError('Require plain project file: '+str(path))
    raw = path.read_bytes()
    if pin and hashlib.sha256(raw).hexdigest().upper() != pin:
        raise ValueError('Pin changed: '+str(path))
    if size is not None and len(raw) != size:
        raise ValueError('Size changed: '+str(path))
    return raw

backend = stage/'owner-douyin-saved-history-review-risk/REVIEW.md'
frontend = stage/'owner-douyin-saved-history-ui-review/REVIEW.md'
for path, pin in ((backend, backend_pin), (frontend, frontend_pin)):
    if b'PASS_LIMITED' not in read(path, pin):
        raise ValueError('Require independent limited code review')
freeze_raw = read(candidate/'FROZEN.json', freeze_pin)
frozen = json.loads(freeze_raw)
for name, item in (frozen['targets'] | frozen['evidence']).items():
    path = candidate/name
    if not path.resolve(strict=True).is_relative_to(candidate.resolve()):
        raise ValueError('Frozen path outside candidate')
    read(path, item['sha256'], item['bytes'])
pins_raw = read(candidate/'SOURCE_HASHES.json', pins_pin)
pins = json.loads(pins_raw)
parents = {
    'assistant/owner_douyin_source_archive.py': '583CE880766C57D1024EE043CD865A9C348ABC417BED95A671C1D0B98BD85B0C',
    'assistant/self_operating_read.py': '89AC709646AA000498363FBDA4FB063921C0B239C0F55F4B83FBEB1C27AB1D57',
    'web/workspace/self-operating-read.mjs': '6FB812AA5DD64198F9C051A06936E11F84AF8C0C4A38707D9462A0B7E36CCFE3',
}
if len(pins['targets']) != 3 or {x['path'] for x in pins['targets']} != set(parents):
    raise ValueError('Require exact three reviewed targets')
changes = []
for item in pins['targets']:
    name = item['path']; target = source/name; parent = parents[name]
    if parent is None:
        if item['parent'] != {'state':'ABSENT'} or target.exists() or target.is_symlink():
            raise ValueError('New module must remain absent')
        old = None
    else:
        if item['parent']['sha256'] != parent:
            raise ValueError('Unexpected formal parent')
        old = read(target, parent, item['parent']['bytes'])
    new = read(candidate/name, item['candidate']['sha256'], item['candidate']['bytes'])
    if name == 'web/workspace/self-operating-read.mjs' and item['candidate']['sha256'] != '4EEAF0D27C0D3EB96C56C04D1C3BEC2D7836BD0D72A509B57EF2BF78214A7AAF':
        raise ValueError('Require exact independently reviewed frontend JS')
    changes.append((target, old, new, item))
protected = dict(pins['protected'])
protected.update({
    'assistant/owner_qr_login.py': {'sha256':'6D178E26F7E8C83D596FDDFA818225496C88A9818197F5414D4F1C16D6261387'},
    'assistant/company_handoff_receiver.py': {'sha256':'468501750EF2E3DDFC49B4AAF688162A2D0DEA47D7E014777153A88D7AEDA11F'},
    'assistant/employee_workspace.py': {'sha256':'793ED246D0393F7C5A666B159E146501518328B3451D40EC8AAF75725F9D5C34'},
    'assistant/product_workspace.py': {'sha256':'8AE5EED225EA98355CE99317DDBC19D963B8723D927D4EEA8E36E4A345712E0C'},
})
for name, item in protected.items():
    read(source/name, item['sha256'], item.get('bytes'))
backup = project/'backups/owner-douyin-saved-history'/uuid.uuid4().hex
backup.mkdir(parents=True)
records = []
for i, (target, old, new, item) in enumerate(changes):
    saved = backup/(str(i)+'.bin')
    if old is not None:
        saved.write_bytes(old)
    records.append({'target':str(target), 'backup':str(saved) if old is not None else None,
        'parent':item['parent'], 'candidate':item['candidate']})
(backup/'MANIFEST.json').write_text(json.dumps(records, ensure_ascii=False, indent=2), encoding='utf-8')
for target, old, new, item in changes:
    if (old is None and target.exists()) or (old is not None and read(target) != old):
        raise ValueError('Formal parent changed before write')
for target, old, new, item in changes:
    target.write_bytes(new)
    read(target, item['candidate']['sha256'], item['candidate']['bytes'])
for name, item in protected.items():
    read(source/name, item['sha256'], item.get('bytes'))
receipt = dict(schema='owner_douyin_saved_history_join', source_batch=39,
    targets=records, protected_unchanged=protected, frozen_sha256=freeze_pin,
    source_hashes_sha256=pins_pin, backend_review_sha256=backend_pin,
    frontend_review_sha256=frontend_pin, frontend_review_reused_unchanged_JS=False,
    scope='CODE_AND_RECORDED_DY_PERSISTENT_METADATA_HISTORY_ONLY',
    real_platform_verified=False, production_AI_executed=False,
    original_App_restarted=False, current_main_hotpatched=False,
    customer_data_modified=False, Computer_Use_or_browser_QA=False,
    old_running_backend_douyin_archive_enabled=False)
receipt_path.write_text(json.dumps(receipt, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps({'source_batch':39, 'joined_files':len(records),
    'protected_unchanged':len(protected), 'real_verification_deferred':True}))
