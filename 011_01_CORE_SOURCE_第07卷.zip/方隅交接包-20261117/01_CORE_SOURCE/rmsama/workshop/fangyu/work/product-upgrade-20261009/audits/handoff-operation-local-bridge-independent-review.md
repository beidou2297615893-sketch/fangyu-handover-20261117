# 公司交接原操作：下一步本机桥与入口独审

2026-10-10。只读方案，未实现或接入本机公司发送/outbox、按钮、新路由或外部发送。phase 10 冻结源与测试未改；不重复 B/D 的新云 API 审查。新云契约依据双方锁定方案，最终真实路由验证由 B/D 另交付。

## 当前真实缺口

- 本机 `AcquisitionOperations` 的 handoff_create/submit/receipt 只写本机账本。`ProductOperationReceipts` 的键仅绑定 tenant、owner、本机 action、key；它没有公司原请求的环境、设备、来源快照或云完整 payload 摘要。现有 local submit 成功、同 key 或同 ContactJournal source 都不能自动对应某次公司提交。
- `product_receipts.py:199` 的 status 缺行会写 cancelled 墓碑，并返回 mutation_committed=false。实际临时 Core 代表验证：回执行 **0→1、cancelled、false**。这是成熟本机取消机制，不能借作新云 pure-read missing/unknown。
- `upgrade-operations-ui.mjs:54` 的 recover 读取本机 acquisition_operation_status，确认 not_committed 等状态会清原 session slot；write 的异常路径见 mutation_committed=false 也清 slot。新云 status 的 false 仅表示**本次查询零写**，原操作仍是 original_execution_confirmed=true|null，必须保持这两层语义独立。实际成熟 helper 的定向错误适配探针中，将只读 false 异常交给原写 fail，会得到 rejected；这证明误接的风险，**不代表当前未实现的桥已经有产品缺陷**。
- 现有 UI 的 payload_digest 用 JSON.stringify(本机 body)；云 handoff-ledger 的 payload_hash 用服务端 canonical(完整云 payload)，含 operation/environment_id。二者不能直接比较，也不能拿当前修改后的表单重算原摘要。

## 最小进入方式

当前没有本机可信公司提交记录时，原交接 UI 继续提供已有“查找对应公司交接 → 人工选条 → 原经营 detail 重核”。它表示同来源对应，保持 local_cloud_handoff_correspondence_verified=false。不能增加任意 opkey 输入后把 recorded 当作本机 exact delivery，也不能从 hc_、候选或本机 local key 推导云原编号。

未来真正接公司提交时，先在本机可信事务保存最小不含正文的提交元数据，再调云；不用重建公司交接账或资金账。元数据至少绑定环境/公司/tenant、saved actor、设备、原本机 handoff 与 revision/fingerprint、不可变 source event_id/payload_hash、原云 action/key、当时完整云 payload 的服务端等价 canonical SHA。仅用户明确选择的固定公司动作可建立它；旧无记录历史不得反补成“已经有本机原提交”。

originrow 继续复用现有 records 存储，不要求 schema 迁移。以下是本机内部最小字段建议，**尚非已实现的对外契约**：

| 字段组 | 必要内容 |
|---|---|
| 固定身份 | id/version/tenant_id/environment_id/company_id/cloud_owner/actor_id/device_id；当前 role/权限另重新核验 |
| 原请求 | operation_action/idempotency_key/cloud_payload_hash；hash 对当时完整云 payload canonical，不能用 UI/local digest |
| 本机来源 | local_handoff_id/local_revision/local_fingerprint；source_event_id/source_payload_hash；至多5个不可变 source 窗口的 event_id/hash、window_digest、anchor/latest_sequence |
| 预期结果约束 | 非 register 的原 channel_id 与 expected_revision；register 的 expected channel 可按成熟 hash(company,actor,action,key) 推导，原结果 revision 应为1，其他变更应核对原 expected_revision+1 |
| 生命周期 | state、row_revision/CAS、prepared_at、submitted_at；原历史 receipt 的安全投影与当前核对状态分别保存，禁止正文/联系人/凭据 |

**prepared 边界**：同鉴权事务固定原请求与来源后保存；只能表示本次准备完成，不能表示已发送，更不能证明之前任何同源/同key历史未执行。实际 dispatch 前重新核验 saved actor/company/device/source，再 CAS prepared→submitted 并持久成功，随后才发唯一固定原请求。竞争实例只有一个 CAS 胜者可 dispatch；崩溃、超时或返回丢失后 submitted/unknown 不因新 key、新本机 revision 或新 source 窗口而解锁。明确的本轮准备阶段 no-dispatch 证据只覆盖该 preparation，不覆盖原 unknown 或旧历史。准备期间的拒绝不能覆盖已持久的旧 submitted/unknown。

首批本机桥沿来源本人范围接 register/submit 及其原状态读取即可。云 API 的7个可读原动作不等于本机已有7种可信 origin；独立 receiver/reviewer/order-link 的权限入口尚未接时不能借来源本人 helper 扮演另一主体。

只读桥的客户端只传已有本机 handoff_id 与 opaque 原记录 ID。桥从记录取原 action/key，通过当前 authenticated integration 的固定环境调用 `acquisition_handoff_operation_status`；客户端不能传 actor/company/env/body 或替换 opkey。无原记录不外呼、不生成 key；损坏、未知、缺记录不自动发 register/submit，也不解除原 hold。

复用 `LocalBusinessReconciliation._snapshot`、`_owned_event` 的本人交接/当前 lead/source hash/完整 ContactJournal 检查；复用 product_workspace 的 saved actor、当前 executor/company/device 门禁和 integrations 的真实 envelope 环境检查。云读取期间不持 SQLite 事务；返回后重读原元数据、完整来源链与 fresh scope，并做同记录版本/CAS 比较。标准 envelope 由 integration 核验后，只剥 contract/environment_id/company_id 三个外层字段，再严格校 operation_receipt 白名单；不能整包交给窄 helper，也不能白名单过滤后默默接受私有 extra。

## 返回与 UI 口径

严格校 `handoff_operation_receipt_v1`、当前 authenticated_actor、原 action/key、read_only、auto_retry=false，以及本次 mutation_committed=false。unknown 必须 original_execution_confirmed=null、original_operation/current_handoff=null；recorded 才可为 true，并须与**本机当时保存的完整云请求摘要**、原 channel/revision 对齐。摘要一致仍仅证明原公司操作登记；register 原结果是草稿，submit 原结果是提交，不是平台交付、资源部外部送达或 exact 本机映射。

历史 original_operation 与当前 current_handoff 分开显示。原操作登记后 current 已撤回、授权失效或版本变化，不抹成从未提交，也不允许使用历史记录继续交付。历史单事件自 hash=true、full_historical_chain_verified=false 不升级为全链验证。财务/合作验证保持 false，实收/已付分成保持 null。

公司登记提交、跨机实际送达、另一可信主体留存历史 ACK、客户证据独立核验与付款是不同证据。原 status 不自动补后三项；historical_resource_receipt_recorded 也不能被写成独立 ACK 或实际送达证明。

入口建议只在该本机交接已有可信原公司记录时显示“核对公司原提交”。点击仅一次原 key 状态读取；页面、主体、设备或交接变更使 accept/epoch 失效，迟到结果不补 DOM。unknown 文案：“原公司操作尚未确认，保留原编号；本次未重复提交。”recorded 文案：“原公司操作已登记；当前交接状态仍需核对。”成功后只刷新当前 detail，不自动发送、不改本机 handoff status、不清本机 local 操作槽；云 original 与本机 local 的槽必须分开。

## 最难的下一步代表验收

1. 真正 prepare→云 commit→响应丢失→本机重启，读取原元数据并固定原 action/key/hash：status recorded 只恢复历史证据；当前已撤回仍保持原历史，0 新 register/submit。
2. cloud missing unknown、传输失败或状态查询 false：原 unknown 与 key 保留；换 key/换本机 revision/无原记录不触发云写；不能经过本机 cancelled/rejected 解锁机制。
3. 同 source 的两个云 channel/另一 actor 相同 key/错误 payload hash/原事件或权限在最后读取改变：拒绝结果，0 exact 映射、0 来源身份或金额泄漏。
4. 实际 integration envelope→实际本机 helper→实际 UI，包括角色/设备/page reset 及晚返；不以独立 stub 合同替代真实序列化边界。

这四组是下一本机实施的验收要求，**本轮未实现或跑通**。本轮只实际验证了上述成熟本机 status 墓碑和错误 false 分类行为，使用项目 tmp 内新建合成 Core，socket/Popen 禁用，临时数据清理；没有真实云/原库/角色/发送动作。
