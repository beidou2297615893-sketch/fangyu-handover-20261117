/* Actual production checker/factory + intact actual synthetic Core/service fixture.
 * Lightweight DOM and controlled transport timing; not GUI or a deployed SDK engine.
 */
'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),crypto=require('node:crypto');
const folder=path.resolve(__dirname,'../../app/src/web/workspace'),source=fs.readFileSync(path.join(folder,'upgrade-operations-ui.mjs'),'utf8');
const fixture=JSON.parse(fs.readFileSync(path.join(__dirname,'company-source-binding-actual-fixture.json'),'utf8'));
const old=JSON.parse(fs.readFileSync(path.join(__dirname,'company-handoff-original-status-actual-fixture.json'),'utf8'));
class Element{
  constructor(tag){this.tagName=tag.toLowerCase();this.children=[];this.parentNode=null;this._text='';this.dataset={};this.attrs={};this.events=new Map();this.disabled=false;this.hidden=false;this.value='';this.className='';this.classList={add(){},remove(){},toggle(){}};}
  set textContent(value){this.replaceChildren();this._text=String(value);}get textContent(){return this._text+this.children.map(n=>n.textContent).join('');}
  append(...nodes){for(const n of nodes){n.remove();n.parentNode=this;this.children.push(n);}}replaceChildren(...nodes){for(const n of this.children)n.parentNode=null;this.children=[];this._text='';this.append(...nodes);}
  remove(){if(this.parentNode)this.parentNode.children=this.parentNode.children.filter(n=>n!==this);this.parentNode=null;}setAttribute(key,value){this.attrs[key]=String(value);}removeAttribute(key){delete this.attrs[key];}
  addEventListener(key,fn){this.events.set(key,[...(this.events.get(key)||[]),fn]);}querySelectorAll(selector){const choices=selector.split(',').map(s=>s.trim()),match=n=>choices.some(s=>s.startsWith('#')?n.id===s.slice(1):s.startsWith('.')?(n.className||'').split(' ').includes(s.slice(1)):n.tagName===s);return this.children.flatMap(n=>[...(match(n)?[n]:[]),...n.querySelectorAll(selector)]);}querySelector(selector){return this.querySelectorAll(selector)[0]||null;}
  focus(){}close(){this.open=false;}showModal(){this.open=true;}click(){if(!this.disabled)this.onclick?.();}
}
const deferred=()=>{let resolve;const promise=new Promise(yes=>{resolve=yes;});return {promise,resolve};},tick=()=>new Promise(resolve=>setImmediate(resolve));
async function waitFor(fn){const end=Date.now()+2500;while(!fn()){if(Date.now()>end)assert.fail('actual factory callbacks did not settle');await tick();}}
function context(){return {user:{id:'synthetic-source-actor',username:fixture.scope.owner,tenant_id:'synthetic-source-tenant',role:'operator'},deviceId:fixture.scope.device_id,deviceGeneration:1};}
function actual(doc){const idle=()=>({open(){},reset(){},dispose(){}});return vm.runInNewContext(source.replace(/^const \{[^\n]+\}=await import\([^\n]+\);\r?\n/gm,'').replace(/export /g,'')+'\n({createUpgradeOperations,checkedCompanySourceBinding,companyPreparationSlot,operationLockSlot});',{
  document:doc,window:{},console,Date,crypto:crypto.webcrypto,TextEncoder,createIntentRuleUI:idle,createPlatformReadUI:idle,createIntentQualityUI:idle,createCompanyPolicyUI:idle,createBusinessReconciliationUI:idle,createSelfDailyEvidenceUI:idle,createSelfWorklistUI:idle});}
const envelope=result=>({status:'succeeded',result:structuredClone(result)});
function harness(sourceRead,companyRead){const doc={createElement:tag=>new Element(tag),body:new Element('body')},factory=actual(doc),id=fixture.preparation_get_result.current.handoff_id,record={id},calls=[],values=new Map();let principal=context();
  values.set(factory.operationLockSlot(principal,'handoff_submit',id),JSON.stringify({action:'handoff_submit',idempotency_key:'synthetic-old-unknown',payload_digest:'a'.repeat(64),state:'unknown'}));
  values.set(factory.companyPreparationSlot(principal,id),JSON.stringify({handoff_id:id,expected_revision:fixture.preparation_get_result.origin.local_handoff_revision,idempotency_key:'synthetic-other-unknown-preparation'}));
  const initial=JSON.stringify([...values]);
  const operations=factory.createUpgradeOperations({execute:async(action,data)=>{calls.push({action,data:structuredClone(data)});assert.deepEqual(structuredClone(data),{handoff_id:id},'no arbitrary source key, hash, actor, owner, or body');
    if(action==='company_handoff_preparation_get')return envelope(fixture.preparation_get_result);
    if(action==='company_handoff_source_binding_get')return sourceRead();
    if(action==='company_handoff_original_status'&&companyRead)return companyRead();
    assert.fail('no write, sync, preparation, generic recovery, or dispatch');},getContext:()=>principal,shell:{hooks:{setAction(){}},refresh:async()=>{}},
    storage:{getItem:key=>values.get(key)||null,setItem(){assert.fail('source query must not persist');},removeItem(){assert.fail('source query must not clear original or pending');}}});
  return {doc,factory,operations,record,calls,context:value=>{principal=value;},button:label=>doc.body.querySelectorAll('button').find(n=>n.textContent===(label||'核对原来源公司记录')),status:()=>doc.body.querySelector('.upgrade-status'),unchanged:()=>assert.equal(JSON.stringify([...values]),initial)};
}
test('all five actual Core/service public cases pass strict thirty-field projection without exposing source hash/body',()=>{
  assert.equal(fixture.synthetic_only,true);assert.equal(fixture.cloud_network_called,false);assert.equal(fixture.real_cloud_called,false);
  assert.equal(fixture.transaction_engine,'sdk_interface_compatible_memory_double_callback_adapter');
  assert.deepEqual(Object.keys(fixture.cases).sort(),['matched','no_origin','not_recorded','stale_uid','withdrawn']);
  const check=actual({createElement:tag=>new Element(tag),body:new Element('body')}).checkedCompanySourceBinding;
  for(const entry of Object.values(fixture.cases)){assert.equal(Object.keys(entry.result).length,30);assert.equal(entry.local_database_unchanged,true);
    check(entry.result,{handoffId:entry.request.handoff_id,origin:entry.result.state==='no_origin'?null:fixture.preparation_get_result.origin});
    assert.equal(entry.result.source_cloud_binding_verified,false);assert.equal(entry.result.verified_cash_cents,null);
    if(entry.result.source_event)assert.deepEqual(Object.keys(entry.result.source_event).sort(),['kind','server_received_at']);}
});
test('opening performs only preparation GET; explicit exact source query uses handoff alone and claims only company report retention',async()=>{
  const h=harness(()=>envelope(fixture.cases.matched.result));await h.operations.openCompanyPreparation(h.record);
  assert.deepEqual(h.calls.map(r=>r.action),['company_handoff_preparation_get']);assert.doesNotMatch(h.doc.body.textContent,/公司已留存对应原事件/);
  h.button().click();await waitFor(()=>h.doc.body.textContent.includes('公司已留存对应原事件'));
  assert.equal(h.calls.length,2);assert.equal(h.calls[1].action,'company_handoff_source_binding_get');
  assert.match(h.doc.body.textContent,/公司账本留存的原设备上报事件/);assert.match(h.doc.body.textContent,/平台事实、客户同意、独立接收与实际回款仍需各自证据/);
  assert.doesNotMatch(h.doc.body.textContent,/payload_hash|公司来源绑定已验证|付款成功|平台已送达/);h.unchanged();h.operations.dispose();
});
test('missing source retains unknown slots and no-origin cannot erase an existing prepared origin',async()=>{
  for(const name of ['not_recorded','no_origin']){const h=harness(()=>envelope(fixture.cases[name].result));await h.operations.openCompanyPreparation(h.record);h.button().click();
    await waitFor(()=>name==='not_recorded'?h.doc.body.textContent.includes('原来源公司记录仍待核对'):h.status().dataset.state==='error');
    if(name==='not_recorded')assert.match(h.doc.body.textContent,/不能据此判断以前没有上传或发送/);
    assert.doesNotMatch(h.doc.body.textContent,/公司已留存对应原事件|未执行|可以重发|已取消/);assert.equal(h.doc.body.querySelectorAll('button').some(n=>n.textContent==='保存本次准备'),false);
    h.unchanged();assert.equal(h.calls.length,2);h.operations.dispose();}
});
test('actual stale UID and withdrawn source matches keep current preparation paused throughout the page',async()=>{
  for(const name of ['stale_uid','withdrawn']){const h=harness(()=>envelope(fixture.cases[name].result));await h.operations.openCompanyPreparation(h.record);h.button().click();
    await waitFor(()=>h.doc.body.textContent.includes('公司已留存对应原事件'));assert.match(h.doc.body.textContent,/本机当前交付保持暂停/);
    assert.doesNotMatch(h.doc.body.textContent,/当前来源与授权可用于本次准备/);h.unchanged();h.operations.dispose();}
});
test('query error, the other company query and fresh preparation GET clear prior company displays without storage changes',async()=>{
  let n=0;const company=structuredClone(old.cases.unknown.result);company.origin={origin_id:fixture.preparation_get_result.origin.origin_id,local_handoff_revision:fixture.preparation_get_result.origin.local_handoff_revision};company.current_local=structuredClone(fixture.preparation_get_result.current);
  const h=harness(()=>{n++;if(n===2)throw Object.assign(Error('明确重新连接现有会话'),{mutation_committed:false});return envelope(n===4?fixture.cases.not_recorded.result:fixture.cases.matched.result);},()=>envelope(company));
  await h.operations.openCompanyPreparation(h.record);h.button().click();await waitFor(()=>h.doc.body.textContent.includes('公司已留存对应原事件'));
  h.button().click();await waitFor(()=>h.status().dataset.state==='error');assert.doesNotMatch(h.doc.body.textContent,/公司已留存对应原事件/);
  h.button().click();await waitFor(()=>h.doc.body.textContent.includes('公司已留存对应原事件'));h.button('核对原公司操作').click();await waitFor(()=>h.doc.body.textContent.includes('原公司登记仍未知'));assert.doesNotMatch(h.doc.body.textContent,/公司已留存对应原事件/);
  h.button().click();await waitFor(()=>h.doc.body.textContent.includes('原来源公司记录仍待核对'));assert.doesNotMatch(h.doc.body.textContent,/原公司登记仍未知|公司已留存对应原事件/);
  h.button('读取原准备记录').click();await waitFor(()=>h.calls.length===7);await tick();assert.doesNotMatch(h.doc.body.textContent,/原来源公司记录仍待核对|原公司登记仍未知|公司已留存对应原事件/);
  h.unchanged();h.operations.dispose();
});
test('late exact-source callbacks are discarded after accept, role, device, generation or dialog reset',async()=>{
  for(const change of ['accept','role','device','generation','reset']){const gate=deferred(),h=harness(()=>gate.promise);let accepted=true;
    await h.operations.openCompanyPreparation(h.record,{accept:()=>accepted});h.button().click();await waitFor(()=>h.calls.length===2);
    if(change==='accept')accepted=false;if(change==='role'){const c=context();c.user.role='admin';h.context(c);}if(change==='device'){const c=context();c.deviceId='changed-device';h.context(c);}if(change==='generation'){const c=context();c.deviceGeneration++;h.context(c);}if(change==='reset')h.operations.reset();
    gate.resolve(envelope(fixture.cases.matched.result));await tick();await tick();assert.doesNotMatch(h.doc.body.textContent,/公司已留存对应原事件/);h.unchanged();assert.equal(h.calls.length,2);h.operations.dispose();}
});
test('private payload additions, wrong origin/kind/version and platform or finance claims fail closed before rendering',async()=>{
  for(const mutate of [r=>{r.source_event.payload_hash='PRIVATE-HASH';},r=>{r.source_event.kind='sent';},r=>{r.source_event.server_received_at=r.observed_at+1;},r=>{r.source_event.server_received_at=1577836799;},r=>{r.observed_at=1577836799;r.source_event.server_received_at=1577836799;},r=>{r.origin.origin_id='a'.repeat(64);},r=>{r.current_local.revision++;},r=>{r.platform_provenance_verified=true;},r=>{r.source_cloud_binding_verified=true;},r=>{r.verified_cash_cents=0;}]){
    const result=structuredClone(fixture.cases.matched.result);mutate(result);const h=harness(()=>envelope(result));
    assert.throws(()=>h.factory.checkedCompanySourceBinding(result,{handoffId:h.record.id,origin:fixture.preparation_get_result.origin}),/未通过核对/);
    await h.operations.openCompanyPreparation(h.record);h.button().click();await waitFor(()=>h.status().dataset.state==='error');assert.doesNotMatch(h.doc.body.textContent,/PRIVATE-|公司已留存对应原事件/);h.unchanged();h.operations.dispose();}
});
test('actual app execute registers source read locally and rejects cloud-only before cloud/command submission',async()=>{
  const app=fs.readFileSync(path.join(folder,'app.mjs'),'utf8'),start=app.indexOf('const PRODUCT_ACTIONS=new Set('),end=app.indexOf('\nasync function requestTaskStop(',start);assert.ok(start>=0&&end>start);
  for(const localWorkspace of [true,false,undefined]){const calls=[],state={selected:'synthetic-device',deviceGeneration:1},cloud={user:context().user,call:async(action,data)=>{calls.push({action,data:structuredClone(data)});return {result:fixture.cases.matched.result};}},execute=vm.runInNewContext(app.slice(start,end)+'\nexecute;',{config:{localWorkspace},cloud,state,customerPrincipalSignature:user=>JSON.stringify(user),submit:async()=>assert.fail('no generic command submit')});
    const request=fixture.cases.matched.request;if(localWorkspace===true){assert.equal((await execute('company_handoff_source_binding_get',request)).status,'succeeded');assert.deepEqual(calls,[{action:'product_action',data:{action:'company_handoff_source_binding_get',data:request}}]);}
    else{await assert.rejects(()=>execute('company_handoff_source_binding_get',request),error=>error.mutation_committed===false);assert.equal(calls.length,0);}}
});
