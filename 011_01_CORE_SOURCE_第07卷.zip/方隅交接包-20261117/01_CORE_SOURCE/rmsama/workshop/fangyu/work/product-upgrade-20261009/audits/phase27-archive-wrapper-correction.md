# Phase27 归档脚本路径修正

首轮静态文件预检发现归档脚本使用了并不存在的 phase27-cloud-workspace-static-copy.json。该 shell 没有在预检非零后停止，随后运行同一归档脚本也在读取该路径时 FileNotFoundError；均发生在五份文档、报告、阶段manifest及任何源码快照写入之前，没有生产变更，也没有重跑测试。

实际B候选同步回执为 cloud-workspace-static-copy.json；其143文件、backup28、未打包/未部署已核。Root将原始字节复制到唯一阶段文件 phase27-company-submission-cloud-static-copy.json（SHA F0D4C08B4935010949DEBC4C964564104103D813C2F09573E37EA12C1E638D18），再仅修正归档脚本两处名称。初稿保留在 backups/phase27-archive-wrapper-correction/1/persist_phase27_submission_and_native_diagnostic.py。后续先通过静态预检，再执行实际归档；这不是产品测试RED或新增测试通过。
