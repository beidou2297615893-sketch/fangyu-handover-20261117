# 公司交接候选网关独立复核

2026-10-10。本轮结论：未发现新的实际阻断。只读审核主窗口生产接线，新增独占测试，未修改生产、原测试、真实数据、账号、权限或部署。

## 已核对的当前源码

- `product_workspace.py:25–29` 将 `business_reconciliation_candidates` 和既有详情归于 `BUSINESS_READ_ACTIONS`。两者不属于 `RECEIPT_ACTIONS`，也没有新业务执行权益门禁阻断过期后的历史核对。
- `:44–79` 先查已绑定、非开发员工、SQL保存主体、租户、设备、当前executor与online/held。`:344–358` 在公开返回前再次查原executor对象、设备/vault绑定、公司ID、SQL主体的id/tenant/username/role/cloud_bound/disabled。
- `:163–183` 仅候选动作导入新候选helper；构造参数由服务端当前主体/设备派生。共用云callback只剥标准envelope外层3字段，候选helper继续严格核对内部actor/source/schema；它没有放过私有字段。
- `BusinessExecutor._ai_cloud` 实际调用 `employee_workspace._cloud`，再到 `Integrations._cloud:417–447`。服务地址、environment与session来自可信配置；真实传输函数验证contract、environment、deployment company后才给callback剥外层。本轮测试以受控HTTP答复调用这些真实函数，没有调用网络或provider。
- `product_receipts.py:98–102` 的构造只保存内存引用，不建表、不写记录；候选纯读分支不调用begin/finish/status。`product_workspace.py:283–295` 保留类型化helper安全403/409，构造失败安全403，非类型化cloud/storage异常安全503。错误不会改成空候选，不含原始异常或令牌，`mutation_committed=False`只表达该读取没有修改经营记录。
- 最终返回scope是`local_bridge_company_server_ledger`，`cross_machine_verified=False`；未把查到同来源渠道当成本机精确交接映射、已送达、财务核验。

## 实际验证与计数

执行：在`work/app`中设置`PYTHONPATH=src;tests;../product-upgrade-20261009/audits`，运行：

```text
C:/Users/rmsama/miniconda3/python.exe -m unittest -q test_business_channel_candidates_gateway test_channel_discovery_gateway_independent
Ran 12 tests / OK
```

12为主窗口原9项与本轮新3项，不是12项全新覆盖。新3项分别验证：

1. 实际gateway→BusinessExecutor→employee cloud→Integrations→受控request_json链正确返回5候选，整个临时SQL库不变；不返回令牌或外层environment。
2. 真实传输函数对错误contract/environment/company逐一拒绝，网关安全503、明确只读，数据库不变；没有“查不到”的假空态。
3. 实际helper完成后、网关投影前注入executor替换、offline、vault解绑、executor owner/tenant变化、SQL角色变化六种边界：全部409并拒绝旧结果。恢复测试注入的用户记录后，所有逻辑SQL行与原值相同，无业务回执写入。

基础fixture已禁socket.connect、平台Popen及通用receipt begin/finish/status。传输答复是受控协议fixture，不能称为真实HTTP服务部署或真实云验证。新测试早期失败均是适配错误：基础helper fixture没有deployment company、SQL REPLACE改变行顺序、误把本地contract视为云外层contract。修正独占测试后通过，未将这些失败记作产品RED。

## 固定审核源码SHA256

|文件|SHA256|
|---|---|
|assistant/product_workspace.py|0E363043FF2B1D89CF706FEF7D203C522AEF8F79EF4DB50095DCEA1B5640FF54|
|assistant/employee_workspace.py|0E639B4EE3D1A56DBE09EB1E0C5C373EC9EF7032EF0707B6B7696301EC2748A4|
|assistant/business.py|088FE555428366C01BB43DB00275357AFF52B55E0722F1BAC6A44C004F8773E8|
|assistant/business_channel_candidates.py|9BAD50C34576374ADF7A64DF3BD543B8B499A90FC0F9D36ED8CA2400F69833EA|
|assistant/product_receipts.py|AF421957BAB074CB0B3F877E1059901387C8548E88813DF095FACD951AAB6257|
|integrations.py|A3243435D59567F7BDD8A1886C9455E9276DBB1E71B38033651DDEACC75B36C6|
|test_business_channel_candidates_gateway.py（原9）|FD7A114EBCE356A4F6EB16B2A8BB287646CE19A61C267E7B06B00D985E4B8597|
|test_channel_discovery_gateway_independent.py（新3）|61F6F8CF21A8ABBD38DACED3C5DC96DC1E92E4FFFA3C8C81D4BCFA234B09B6F3|

目录均在本项目`work/app/src`、`work/app/tests`或`work/product-upgrade-20261009/audits`。本轮没有复跑云75、原本机16、子agent UI7或历史295全组，不能将本轮12与这些计数相加当完整唯一回归。实际云SDK/GUI/资源部/平台/财务边界仍以各自报告为准。最新额度实读Codex周剩余15%，secondary不可读，未到严格<5%的停工阈值。
