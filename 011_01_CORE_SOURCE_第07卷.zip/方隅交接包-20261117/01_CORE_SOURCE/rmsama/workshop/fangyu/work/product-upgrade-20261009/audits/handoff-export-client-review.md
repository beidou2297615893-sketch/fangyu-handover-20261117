# 交接核对清单：当前客户端独立审核

本轮结论：发现的四项 P2 已由主窗口修复；对当前冻结源码执行的 20 项独立离线测试全部通过，耗时 2309.2747 ms。审核未修改共享业务或客户端源码，没有访问原库、真实账号、平台、Cookie，没有对外下载或发送。真实 IAB/原生窗口操作另由主窗口核验，不能由这 20 项离线测试替代。

## 1. 方法与证据

- 最小 Skill：实际读取 Spreadsheets 及其 read_only_qna 规则，采用来源可追溯、真实零与缺失区分、公式检查和不改源记录的要求。本轮没有制作业务工作簿交付物，因此没有引入表格创作运行时或额外依赖。
- 三个模块通过 Node 直接导入当前 `work/app/src/web/workspace/` 的真实文件，`?asset=` 使用与浏览器相同的本项目同目录解析；没有复制旧 site、重写被测模块或模拟其算法。
- UI 使用有限的离线 DOM 夹具，解析当前 index.html 后执行真实 shell/hook/openExport。它验证回调和生命周期，不模拟浏览器布局、原生保存对话框或操作系统下载成功。
- 实际 app.mjs 有完整窗口启动副作用。本轮取其 `PRODUCT_ACTIONS` 至 `execute` 的原始词法区，不修改字节，在隔离 VM 中以禁止 command_submit/轮询的运输夹具验证真实动作分流。完整 app 启动证据归主窗口 IAB 联调。
- Python 使用已安装项目运行时与当前 AcquisitionExports，仅在 TemporaryDirectory 的合成 SQLite 创建两条手工样例，构造真实 CSV 和 XLSX 二进制；导出前后全部 records 字段逐值一致。二进制仅在进程内存中传入真实浏览器 Blob 构造函数，测试不保存业务表格、不调用账号。
- 实际 employee_workspace.asset 函数提供两个新增模块，返回字节与当前本地源文件逐 SHA 相同，MIME 为 `text/javascript; charset=utf-8`；测试没有构造真实服务器。

证据位于同目录：`handoff-export-client-evidence.json`（SHA/二进制/方法边界）与 `handoff-export-client-verification.txt`（20 项原始执行结果）。测试位于 `work/app/tests/handoff-export-independent.cjs`。

复验命令，在 `work/app` 执行：

```powershell
& 'C:/Program Files/nodejs/node.exe' --test tests/handoff-export-independent.cjs
```

## 2. 四项发现与当前关闭证据

| 项目 | 修前最小反例 | 当前修复与复验 | 状态 |
|---|---|---|---|
| P2：返回条数不约束请求批量 | 明确请求历史 CSV limit=1；服务端真实两行文件的 SHA、MIME、模式均正确，旧 helper 仍接受 rows=2 | helper 第 3–10 行校验 limit 是 1–1000 安全整数且 rows≤limit；原反例拒绝 | 已关闭 |
| P2：合法大小 base64 校验栈溢出 | 旧重复分组正则在 Node 24.15.0/V8 对合法 4MiB、8MiB 字节的编码触发 RangeError；这些仍在声明门限内。64KiB/256KiB/1MiB 当时正常 | helper 第 14–22 行改为长度、字符、尾部 padding 的线性检查；4MiB 合法数据完整 SHA/Blob 通过；超 8MiB、空串、非法编码拒绝 | 已关闭 |
| P2：忙碌表单状态不一致 | 旧生成按钮禁用，但格式/范围/条数仍可编辑，关闭仍显示可点却被静默忽略 | openExport 第 59、66 行保存并禁用全部控件，在当前操作归属下恢复原状态；服务器故障后原本禁用的控件不会被顺手授权 | 已关闭 |
| P2：旧响应解除新表单忙碌 | A 请求待处理→reset→开启 B 并提交→A 先结束；旧 finally 清全局 busy，Escape 能关闭尚忙的 B。A 数据本身仍被丢弃，不能说它已造成跨账号下载 | 第 10、59、66、181 行使用 activeOperation，reset/dispose 作失效标记，只有自身 operation 可清 busy；原链路现在 B 保持打开与忙碌，完成后正常恢复 | 已关闭 |

修前第一次 14 项为 10 绿/4 红；合法 4MiB 反例随后单独确认。最终 20 项使用修复后当前源码，起止 SHA 一致，不用历史失败声称当前仍存在缺陷。

## 3. 当前通过的范围

| 代表链路 | 实际结果 |
|---|---|
| CSV/XLSX 真二进制 | 当前后端生成 delivery 1 行、audit 2 行，SHA 与实际字节一致；CSV 16 列；XLSX 两页为“交接核对清单”“范围与核验说明”，工作表 XML 公式节点=0、外部关系=0；合成 `=2+2` 在历史导出作为文本 |
| 文件协议 | 固定中文文件名、准确 MIME、base64、format/mode、local_only=true、contains_contact_plaintext=false、cross_machine_verified=false、delivery_confirmed=false、rows/total/has_more 与批量界限；篡改摘要或字节拒绝 |
| 实际表单选择 | 默认待送达 Excel 与手选历史 CSV/limit=2 都将原选择交给 handoff_export，下载 spy 接收真实验证后 Blob，字节 SHA 未变 |
| 账号与窗口变化 | 用户 ID、租户、角色、deviceId、deviceGeneration 在响应前变化均不创建下载；摘要计算进行中改变 generation 同样不下载 |
| 生命周期 | 同表单重复点击只有一个执行；reset/dispose 丢弃旧文件；旧 finally 不解锁新表单；闲置关闭清字段并移除；SHA 与服务器故障可明确重试且恢复原控件状态 |
| 动作/资产 | 当前 index.html 第 8 行入口→shell 第 98、105 行 hook→operations 第 180 行真实表单；app.mjs 第 379–389 行将 handoff_export 经 product_action 发送，禁止错误进入 command_submit；employee_workspace 第 45–46 行允许新增模块；helper 用同源 `new URL('?asset=…',import.meta.url)` 导入 |
| 状态语义 | 生成文本始终保留“本机核对”“未登记送达或接收”；没有因导出写 receipt、ACK、成交、结算或跨机已核验状态 |

后端敏感文本/Unicode 旁路的完整结论应引用 C 的独审：`acquisition-exports-independent-review.md`、对应 verification/source-hashes。C 报告当前导出 23 项及关联必要模块合计 105 项通过，后端 SHA 与本轮真实二进制夹具一致。本轮四份安全文件不能单独代替后端隐私全量审核，也不混计两组测试。

## 4. 当前源码指纹

最终记录时间见 evidence 的 recorded_at；下列 5 个客户端源在本轮测试前后完全一致：

| 当前文件 | SHA256 |
|---|---|
| handoff-export-file.mjs | `70ca09f83b1840b08f2cc56aab7b19c272fee2ebd5cbf87db66afc1eb0f03e7b` |
| upgrade-operations-ui.mjs | `dc403595df76d2ccf9bf04dc04e8401e7a1b903036490fc23dd2417932e4557c` |
| upgrade-shell.mjs | `c72e650cefc199ee1ba725cd6177ef9409739faba8efbfc180fcfdf6d6e6e867` |
| index.html | `d90ececbcd045166b2d22d7bb663421738d29d26c83a765ef172ae687e777218` |
| app.mjs | `7354df0dfe3fad09313f67e21d05384af548ffa40849f127176670c52f632f44` |
| acquisition_exports.py（真实后端夹具） | `b41bb719972020ed790ed937185201e1130c260ce8dcdf9e5d9fdb2287a21731` |
| employee_workspace.py（辅助资产读取） | `0508d05368c7ae7a944fdfbe18b8da5015611ee9257e01f60e531a44c1244b1d` |
| handoff-export-independent.cjs | `15165ce807293a992f00fe91a5fe81bed25d99cceaaae42b54e5a76b51437ed4` |
| 原始验证日志 | `d3d4a8ab1c66e1adf54109f8b5d21aa410338d2ef20a738d92a2170f3624e37d` |

## 5. 不扩大结论的边界

这次客户端独审范围内没有尚未关闭的已复现 P1/P2。它仍不等于员工已上线、商用全流程通过、真实资源部已接收或成交。账号/平台/来源状态必须继续真实保留。

前端核对摘要与受信服务端元数据，不自行解析每个 CSV 行或 XLSX XML；真实格式、公式和来源门禁由本轮真实 builder 检查与 C 后端独审共同覆盖。4MiB 用于 helper 门限契约的合成字节不能冒充真实业务 CSV，原生窗口/V8 上限的全尺寸性能也未在本轮测量。

主窗口已经另行记录真实隔离 IAB 的 Excel/CSV 下载，但本代理没有控制该浏览器，没有自行把来源未知的下载样本与这里临时 Store 的四份二进制混为同一文件。再次修改这五个源文件或 asset 路由后，应按改动范围重新执行本测试并以新 SHA 记录，不沿用本结论。
