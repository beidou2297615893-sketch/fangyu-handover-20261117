# 本人来源发现公司渠道：云候选实施证据

2026-10-10，仅方隅客户版候选源码及隔离合成数据库。继root批准最小路线后完成cloud `acquisition_channel_candidates`，实际createService/createStore与SDK transaction callback双replay验证。没有云部署、真实客户/账号/平台/模型/支付、授权扩大或其他任务改动。phase-8经营核对原helper/handoff/contact/index未修改；service增加一条独立已认证路由。原phase-8 269/181与GUI为历史成果，不充作本新增发现功能的测试。

## 最终合同

严格cloud字段：environment_id/operation/sources/source_window_digest/scan_offset/scan_limit/expected_owned_index_count。sources为1—5个唯一event_id+payload_hash，由本机trustedserver从有权原handoff和完整ContactJournal派生。digest=canonical SHA256（sources按event_id排序）。offset默认0，limit默认10/max10；后续offset>0必须有原ownedindexcount且与当前一致。owner、company、role、名字、联系方式、裸UID、任意rawbody或可信布尔不可从此payload取得权限。

标准fangyu-workspace-v1 body里 `discovery.contract=business_channel_discovery_v1`、read_only true、storage_scope company_server_ledger、observed_at、authenticated_actor、source_window_digest。source_results精确覆盖本请求event/hash，状态recorded/not_recorded；recorded的source复用phase8 exact_SOURCE_FIELDS，missing为null。stored source必须同当前会话本人、device_report、canonical六字段+可选intent_snapshot/fingerprint、当前固定位customer；wrongowner/company/hash/customer/历史格式拒整批。missing不会挡其他旧已归档来源，更不会证明从未发送或未处理。

scan精确字段：direction newest_first、status partial/complete/index_unavailable/no_cloud_sources、owned_index_count、offset、scanned_count、limit、next_offset、complete。partial有当前count、next=offset+actualscanned<count、completefalse；complete有count、nextnull、offset+scanned=count、completetrue；索引不可读或所有cloud source缺失时countnull/scanned0/nextnull/completefalse。

**complete仅到当前索引末页**。cursor是可重算一致性约束，不是服务端签名的扫描履历，所以不能证明前面每一页已经执行，更不能说整个sourcewindow不存在渠道。root UI采用“已到当前索引末页/当前末页未找到”，另分本机旧来源窗口尚多、本页未找到、cloud缺来源、index不可核对。此纠正没有改协议字段，只明确其准确含义。

倒序扫描当前actor owned索引最多10条（index每页50），输出最多5候选，第5个即停，next_offset按实际扫描行数，不吞第6个。使用原readBoundItem复核可见性、最新审计快照/chain hash和withdrawal ledger；当前sourceowner必须本人，manager/admin不能借ownedindex数据读取他人来源。候选item与已核原event的customer/owner/device/platform/UID/comment/lead/text摘要逐项对应。

候选精确字段：channel（phase8 exact_CHANNEL_FIELDS，包括同源摘要）、recipient_name（数据库派生且隐私过滤）、created_at/updated_at。不返回裸平台UID/commentID、评论正文、reply/sender、联系人、consent/evidence引用、账号/密钥或私有规则。接收方名含零宽/全角联系方式或凭证标签时仅显示通用“已登记接收方”。withdrawn/disputed仍可读取历史；current_consent_valid/eligible_for_delivery与historical_resource_receipt_recorded分开。

local_cloud_handoff_correspondence_verified=false、financial_receipt_verified=false、cooperation_policy_verified=false、verified_cash_cents/verified_paid_commission_cents=null。发现同源不是exact本机handoff对应回执、跨机送达、平台真实性或财务核验；不自动选择/建立映射/发送/注册/补同步/改index。用户明确选择后原business_reconciliation_detail再次完整核对。

本机由D负责的新action `business_reconciliation_candidates` 最终只收handoff_id/cursor，cursor的version/anchor/digest/count/offset/scope重新核验，不把client事件当真实来源。root负责gateway/UI。实际跨层fixture/本机13及UI由各自独审报告，本云报告不会将它们未完成时先记为通过。

## 授权、预算与未知

helper开始/末尾都复核真正persisted session、username、role、disabled、company、期限；await之后还重核索引count、每个输出candidate的revision/latest hash/currentconsent，再核完整principal。readOnly不受商业套餐到期阻挡，但当前身份权限/原数据变动仍拒。原role或source变不能因先看到合法记录就继续返回。

新增真实SDK最难窗口：5个source event+customer，55个实际register draft按owner索引，最后10条跨50页，5个无关后5个匹配，5个输出最终再readBound。实际摘要每callback **60read/0write**，前置service派生认证marker另 **1read/0write**；两个事务均双callback replay，总4次每次<=100。全库snapshot前后相同，不改旧记录。此夹具计数不是部署后的30秒性能/吞吐保证；root核腾讯云官方100操作/30秒/事务只doc/no外部调用的规则，本helper无where或外部网络。

错误固定 CHANNEL_DISCOVERY_INVALID_INPUT400/TENANT_MISMATCH403/AUTH_REQUIRED401/SOURCE_FORBIDDEN403/SOURCE_CONFLICT409/INDEX_CONFLICT409/INDEX_CHANGED409/SOURCE_CHANGED409/STORAGE_UNAVAILABLE503；原LedgerError/HandoffError返回既有安全typedcode。一般存储异常仅503安全中文提示，不返回原错误/正文/secret，也不改成空成功。只读错误不假造mutation_committedfalse或资金no_dispatch证明。

## 代表性执行与失败证据

新增11/11 actual service/createStore测试：来源本人成果只读/不含raw；第6候选后页不漏；目标在第11行前页空仍partial；5source/10scan/5output跨50页最大预算；旧reviewed注册/latest无渠道+missing源仍能找到；成熟7kind均可读；最后candidate await权限变化拒旧结果；no source/index不声称complete；withdraw保历史/currentfalse；跨actor/伪scope/digest/count/duplicate参数与late disabled/session；indexappend/孔洞/源hash/customer冲突；外租户/存储secret安全失败。

首3例尚无route实际400!=200的RED保留 `channel-discovery-first-red.txt`。后两真实RED保留 `channel-discovery-kinds-final-actor-red.txt`：实际copied409!=200；finalread角色变化200!=401。修改前R2备份后按原ContactJournal/contact ledger 7kind修正，最后一次授权后再次比较principal，两红转绿。这个角色测试是合成SDK callback内trustedstate变更注入，证明该真实函数的终审守卫，不宣称线上并发角色变更全场景已验。child独立copied实际RED另存其独占测试，不改其测试放松断言。

必要7唯一组 **75/75=新11+原64**：channel_candidates、business_reconciliation、handoff-service-integration、handoff-ledger、contact_ledger、service、isolation。不重复计11+75，也未重跑AI/政策发布全矩阵。新helper/fixture/service 3syntax过。

## 文件与冻结范围

新channel_candidates.cjs、channel_candidates.test.cjs、无node:test副作用channel-candidates-fixture.cjs。fixture复用phase8合成fixture及真正SDK adapter，只增加新路由race/当前callbackstate注入，不修改phase8 fixture或其标准JSON。service编辑前R1完整备份；新helper修两红前R2备份。最终 `channel-discovery-final-hashes.json`。

helper **759670533DD394A86718B56A20B2D261A41F39941EF6D2E047CA66E71FDF6924**；service **17D21D918D3E17559AA48E3F6DB342FC86DE112172B4DB8D9043E016AA0412A7**；fixture **48B66A737AA7C9EDCEB0866E1B28DC193E6164731EBFB9379E71207E772613FA**。旧service1D800…为phase8历史SHA而不是当前全局最终值，已存R1；原业务helperD89314…/handoff16A544…/contact16041…/index223A15…不变。源码已停改，后续独审/actual双端/实屏由对应新增报告补充，不能将此本地候选当商用或客户真实收益证明。
