"""Export actual LocalBusinessReconciliation projection over disposable Core.

Company response is a synthetic injected read contract here. A separate actual
cloud service/SDK replay test verifies that layer; this is not a live cloud run.
"""
from pathlib import Path
from copy import deepcopy
from tempfile import TemporaryDirectory
import hashlib
import json
import sys

PROJECT = Path(__file__).resolve().parents[3]
APP = PROJECT/'work/app'
sys.path[:0] = [str(APP/'src'), str(APP/'tests')]
import test_business_reconciliation as fixture_module

fixture = fixture_module.BusinessReconciliationTests()
fixture.setUp()
try:
    fixture.add_order(distinct_review_actor_recorded=None, calculation_policy_current=None)
    request = {**fixture.data, 'offset': 0, 'limit': 10}
    result = fixture.call(request)
    document = {'synthetic_only': True, 'original_db_opened': False, 'network_used': False,
        'cloud_response_source': 'injected_synthetic_read_contract',
        'backend_sha256': hashlib.sha256((APP/'src/assistant/business_reconciliation.py').read_bytes()).hexdigest(),
        'request': request, 'result': result}
    pending = deepcopy(result)
    document['pending'] = {'request': request, 'result': pending}
    row = fixture.order(binding_state='order_missing', current_revision=None, status='unknown',
        link_revision_current=None, reported_amount_cents=None, reported_refund_cents=None,
        reported_net_cents=None, reported_by=None, last_edited_by=None, reviewed_by=None,
        distinct_review_actor_recorded=None, calculation_status='unknown', calculation_policy_current=None)
    row['missing_evidence'].append('order_missing')
    fixture.answer['summary']['orders']['items'] = [row]
    document['order_missing'] = {'request': request, 'result': fixture.call(request)}
    fixture.answer['summary']['orders']['items'] = [fixture.order(status='confirmed',
        admin_review_recorded=True, reviewed_by='synthetic-admin', distinct_review_actor_recorded=True,
        recorded_calculated_commission_cents=0, calculation_status='calculated',
        calculation_policy_revision=1, calculation_policy_snapshot_available=True, calculation_policy_current=True)]
    document['calculated_zero'] = {'request': request, 'result': fixture.call(request)}
    cloud_path = Path(__file__).with_name('business-reconciliation-cloud-actual-fixture.json')
    cloud_document = json.loads(cloud_path.read_text(encoding='utf-8'))
    with TemporaryDirectory(dir=fixture_module.FIXTURES) as temp:
        actual = fixture_module.actual_cloud_bridge(cloud_document, temp)
        try:
            actual_result = actual['service'].execute('business_reconciliation_detail', actual['request'], actual['actor'])
            document['injected_contract_projection'] = {'request': document['request'], 'result': document['result']}
            document['request'], document['result'] = actual['request'], actual_result
            document['cloud_response_source'] = 'actual_createService_createStore_sdk_callback_replay'
            document['cloud_source_sha256'] = cloud_document['source_sha256']
            document['actual_cloud_bridge'] = {'request': actual['request'], 'result': actual_result}
        finally:
            actual['core'].close_continuous_scheduler(wait=True)
            actual['core'].adapters.close()
    target = Path(__file__).with_name('business-reconciliation-local-actual-fixture.json')
    target.write_text(json.dumps(document, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps({'path': str(target), 'sha256': hashlib.sha256(target.read_bytes()).hexdigest(),
                      'cases': ['actual_cloud_bridge', 'pending', 'order_missing', 'calculated_zero'],
                      'synthetic_only': True}, ensure_ascii=False))
finally:
    fixture.tearDown()
