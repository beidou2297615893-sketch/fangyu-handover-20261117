/* Real service/createStore/repos with a synthetic SDK-interface replay adapter.
 * No real node-sdk transaction engine, cloud transport or business data.
 */
const assert=require('node:assert/strict');
const crypto=require('node:crypto');
const fs=require('node:fs');
const path=require('node:path');
const project=path.resolve(__dirname,'../../..');
const workspace=path.join(project,'work/cloud/workspace');
const {fixture,ACTION}=require(path.join(workspace,'handoff-operation-status-fixture.cjs'));
const sha=file=>crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex').toUpperCase();
async function run(){
 const f=await fixture(),source=await f.source('fixture-operation-receipt-customer'),key=crypto.randomUUID();
 const body={source_event_id:source.event.event_id,recipient_id:'resources',purpose:'租房咨询承接',qualification:'qualified',
  consent:{status:'granted',evidence_reference:'consent:'+crypto.randomUUID().replaceAll('-',''),notice_version:'v1'},idempotency_key:key};
 f.loseNextResponse();await assert.rejects(f.call('acquisition_channel_register',body),/response lost/);f.restart();
 async function read(action,originalKey,token=f.tokens.source){
  const before=f.data.snapshot();f.data.resetOperations();const result=await f.status(action,originalKey,token);
  assert.equal(result.status,200);assert.equal(f.data.snapshot(),before);
  const transaction_replay_counts=f.data.operations();assert.ok(transaction_replay_counts.every(pair=>pair.every(row=>row.writes===0)));
  return {request:{environment_id:'fixture-env',operation:ACTION,operation_action:action,idempotency_key:originalKey},
          result,transaction_replay_counts};
 }
 const main=await read('acquisition_channel_register',key),channel=main.result.data.operation_receipt.current_handoff;
 const submittedKey=crypto.randomUUID(),submitted=await f.change('acquisition_handoff_submit',channel,{},f.tokens.source,submittedKey);assert.equal(submitted.status,200);
 const receiptKey=crypto.randomUUID(),ack=await f.change('acquisition_handoff_receipt',submitted.data.item,
  {decision:'accept',evidence_reference:'evidence:'+crypto.randomUUID().replaceAll('-','')},f.tokens.resource,receiptKey);assert.equal(ack.status,200);
 const withdrawal=await f.change('acquisition_handoff_withdraw',ack.data.item,{reason_code:'customer_withdrew'});assert.equal(withdrawal.status,200);
 const cases={registered_response_lost:main,
  submitted_after_withdrawal:await read('acquisition_handoff_submit',submittedKey),
  resource_acceptance_after_withdrawal:await read('acquisition_handoff_receipt',receiptKey,f.tokens.resource),
  unknown_original_key:await read('acquisition_channel_register','fixture-never-recorded-key'),
  other_actor_same_original_key:await read('acquisition_channel_register',key,f.tokens.outsider)};
 const names=['handoff-ledger.cjs','service.cjs','handoff-operation-status-fixture.cjs','handoff-operation-status.test.cjs'];
 const document={synthetic_only:true,request:main.request,result:main.result,cases,source_metadata:{
  fixture_type:'actual_createService_createStore_repositories_with_SDK_interface_memory_callback_replay',
  sdk_transaction_engine_exercised:false,real_cloud_platform_model_requests:0,original_database_used:false,
  exact_local_handoff_mapping_tested:false,external_delivery_financial_authority_tested:false,
  company_id:'fixture-company',environment_id:'fixture-env',authenticated_actor:'source',
  SDK_package_version:JSON.parse(fs.readFileSync(path.join(workspace,'node_modules/@cloudbase/node-sdk/package.json'),'utf8')).version,
  readonly_document_snapshot_unchanged:true,transaction_callbacks_replayed:2,
  sources_sha256:Object.fromEntries(names.map(name=>['work/cloud/workspace/'+name,sha(path.join(workspace,name))]))}};
 const destination=path.join(__dirname,'handoff-operation-status-actual-fixture.json');
 fs.writeFileSync(destination,JSON.stringify(document,null,2)+'\n','utf8');
 process.stdout.write(JSON.stringify({path:destination,sha256:sha(destination),cases:Object.keys(cases),
  normal:main.transaction_replay_counts,withdrawn:cases.submitted_after_withdrawal.transaction_replay_counts})+'\n');
}
run().catch(error=>{process.stderr.write('Synthetic fixture generation failed\n');process.exitCode=1;});
