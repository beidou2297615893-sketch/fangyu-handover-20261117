# Phase26：实际良性 TokenUser 代表独立只读核对

结论：run `02677a1f4fcf437e8d06adf400f56703` 的实际回执、原 attempt、Scheduler 身份/动作回执、owned cleanup 和冻结源码一致。本次真实 Windows 固定 sleep 子进程的 TokenUser 查询及原创建时间绑定代表通过；没有核得原小红书 UID，没有授予原 profile 空闲或账号恢复。D 本轮只读证据和哈希，未执行 Native/CIM/browser，也未重跑合成 3 方法。

## 已核事实及界限

实际结果为 `representative_passed`，`execution_finished=true`、`auto_retry=false`；结果文件 SHA256 为 `96B64B0527B0018BB482B1F0CE861520CACD6D47AB1C8B0D154ADA9E5A13B51B`。

两次成熟固定 CIM 读取各有 52 行，属于该脚本选择的浏览器/Python/方隅相关进程清单，并非全部 Windows 进程或网络活动清单。候选代码分别要求 `complete=true`、结构有效、同一当前 SID。两次选定 sleep-child 都通过实际原创建时间、Job membership、parent、fixed exe/argv/runtime 验证；`child_binding_hash` 和 TokenUser 证据摘要相同。TokenUser 两次均 `verified`，`owner_current/wmi_owner_agrees/creation_verified/running_before/running_after/token_user_verified/handles_closed` 均为 true。

整份快照摘要在这次执行恰好相同，代码没有把它作为通过门槛；无关正常进程的变化不等于选定 child 改变。`other_metadata_unknown=0` 仅表示该次相关清单按候选基本字段检查没有缺项，不证明所有 profile 路径、默认政策或其他用户 profile 可读，也不授予整体 occupancy `vacant`。

WMI owner 在本次实际代表中**也可用且与 TokenUser 一致**。所以这次证明真实 TokenUser 查询/创建时间/当前用户绑定路线可运行；真正 WMI 缺失后的 occupancy 补证组合仍未真实运行。既有合成机制覆盖缺 WMI，但本轮没有新增测试数或将其当成真实缺失复现。

`owned_job_created/owned_exit_confirmed/materials_unchanged=true`。源码显示父进程在完成前重新核 runtime 与源内容，保留 setup-pending 对象，等待 Job/进程退出确认，未用一次 timeout 假称退出。结果 `original_data_read/dpapi_read/account_used/browser_started/cli_started=false`、`sqlite_connections=0`、`original_profile_vacancy_authorized=false`；公共文件无 SID、PID、原命令行、句柄、令牌。网络字段表达候选代码未请求应用/平台网络，不是抓包或全机器网络零活动证明。

原 attempt 和 dispatch 的 `execution_finished=false` 是启动前不可变记录；实际 result 的 true 是最终阶段，含回同一原 attempt，二者没有语义冲突。root task-receipt 记录 READY、LastTaskResult 0、fixed action/current user alias/Interactive Limited 验证 true、trigger_count 0，结果 SHA 和实际父 F31D90C3 完整 SHA 对应。owned-cleanup 记录仅本 GUID 任务已移除、结果保留、其他任务未变。D 没有重新查询 Scheduler 或复执行，以上属于保存的一次真实执行回执核对。

## 冻结一致性

候选 freeze `phase26-native-owner-resolver-candidate-final-hashes.json` SHA `EF88BC9C21961B5A76DB1C47FACB8B18A557ADCF5FF229991FF436D003029E43` 未变。其中 5 个候选源码/测试、10 个候选证据和旧 13 个冻结源 + 成熟 private_evaluation 共 14 个引用均与当前磁盘 SHA 相符。原候选阶段未执行的 bounds 仍是历史事实，不覆盖为本次实际运行事实。

原 attempt 的 6 个源摘要与实际父、resolver、sleep child、Scheduler 脚本、867B guard、private_evaluation 当前内容逐项一致；实际 result 含同一 attempt。runtime identity hash 在回执内是该次执行首尾材料核验摘要；本轮没有再次扫描安装库或原账号数据，不冒称重新独立采集了全部 runtime 材料。

旧 7 个诊断源、4 个 benign WebView 源、867B probe、safe_trace_v2 保持原冻结值，没有借这次代表修改。8070 原账号阻断和 0464 benign WebView owner 缺口仍是历史未知；本次 sleep-child 通过不能证明两者同因、已修复或可安全重试。

## 后续最小 occupancy 接法（仅设计，未实施）

可行的首选是新建独立本机 occupancy adapter，继续调用成熟 `profile_occupancy.classify`，只补 `owner_sid is None` 的 owner 证据，保留原 7 源历史。不能把 TokenUser bool 作为 `vacant` 结论，也不能按 family/PID blanket 忽略行。

准确复用点是 `profile_occupancy.py:175–179` 的 owner/parent/创建时间综合门禁之前，而不是 `:203–204` 捕获 unknown 后跳过；其余 `:180–185` exe/argv、`:142–169` profile/default policy/父链、`:194–200` 原创建时间 Job 回调与固定 WebView runtime 门禁必须继续执行。`WindowsProfileOccupancy.__call__` 的固定 CIM 路径是数据来源，不能由 HTTP body、旧缓存或调用方传任意 owner 授权。`Host._vacant` 只接受最后实际 `vacant`，其 scope/runtime 首尾核对、账号锁与 owned 生命周期保持。

适合第一切片的范围与行为为：

1. 每次完整相关进程 snapshot 先验证结构、唯一 PID、当前原生 token SID；`parent_pid` 与原 `created` 缺失或非法时仍 unknown，不能查询新 PID 时间补填。有效 WMI owner 继续沿旧路径，不能覆盖矛盾值。仅真实缺 owner 的行调用冻结 `NativeOwnerResolver`，使用该 snapshot 的原 PID/created 与本轮当前 SID。
2. 仅 `verified + owner_current=true + creation_verified + running_before/after + handles_closed` 的当前用户补证可以用于本轮 RAM 内的派生 snapshot；原 WMI snapshot 不覆盖、不落盘，独立 RAM companion 记录 `token_user` 来源、原 PID/created、native evidence hash，不能标成 WMI verified。因为现公共 resolver 不返回真实其他用户 SID，`owner_current=false` 首切片保留未知，不伪填当前 SID或编造他人 SID。
3. 派生 owner 只是继续执行旧 classify 的条件。匹配目标 profile 而没有当前 Job membership true 仍是 occupied；Job 回调 None/错误仍 unknown；owner 当前也不能豁免外部浏览器。继承 profile 的父链缺失/创建时间倒序/owner 不一致，或 exe/argv/runtime/profile 路径不符仍阻断。TokenUser 是令牌用户，**不是对象/DACL owner 或平台账号**。
4. 使用本轮新证据而非跨调用缓存。完整末 snapshot 仍须收集和分类；对实际补证的原 `(PID,created)`、相关父关系、native TokenUser/current SID、runtime 内容与目标 profile 约束重核。进程退出、PID 复用、父链或 owner 变化时拒绝本轮，不把消失行自动当成无占用。无关行数/整机摘要变化不用一律拒绝，但最后任何未知相关行仍不得变成 vacant。

最小下一代表可以只做该新 adapter 的合成完整 snapshot→frozen resolver 结果→实际 frozen classify 组合：WMI 缺 owner/当前 TokenUser 精确补证仍经过 exe/profile/Job；parent/created 缺口、Job unknown、native owner/创建时间晚变仍 unknown；有效 WMI owner 与 TokenUser 矛盾不能修成可用。最多沿一个独立良性 profile 场景验证组合，仍不打开原账号；只有经审阅后才讨论 Native 验证是否必要。

本轮没有实际创建 adapter、修改 frozen classify 或重试原账号。未来原账号 developer observation 仍需新的 fresh profile/metadata/runtime/账号范围前置核对，保留原风险 review_required 与历史任务 NULL unknown；不得把本回执当作沿用旧 ready 的许可。

报告所在文件夹：`C:/积木软件工坊/项目/方隅公寓客户版/work/product-upgrade-20261009/audits`。
