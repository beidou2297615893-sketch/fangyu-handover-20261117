# Phase14 原来源公司纯读独立审查

2026-10-10。本轮代表检查可冻结，未发现仍需修改生产代码的缺口。独立新增 cloud 6 组和 UI 8 组均通过，共 14 个测试；首跑/最终重跑不重复计数。旧 Phase13 和更早源码、测试、报告均未修改。

## 可复核证据

| 独占文件 | 最终结果 | SHA256 |
|---|---|---|
| source-binding-cloud-independent.test.cjs | 6/6 | 9B4EFDB052461534FD0F372CA7C5C95CFBF4F71C849B1A95BD1DACA61E21FD7F |
| company-source-binding-ui-independent.test.cjs | 8/8 | 05222CCC493B59C83D9B1F7A1F0B7DFA20668D2BC072A10B049DEC0A9009B59C |

日志：`source-binding-cloud-independent-first.txt`、`source-binding-cloud-independent-final.txt`、`company-source-binding-ui-independent-first.txt`、`company-source-binding-ui-independent-final.txt`。均在本报告所在 audits 目录。

执行命令：

```text
node --test work/product-upgrade-20261009/audits/source-binding-cloud-independent.test.cjs
node --test work/product-upgrade-20261009/audits/company-source-binding-ui-independent.test.cjs
```

读取的冻结版本：

| 文件 | SHA256 |
|---|---|
| work/cloud/workspace/source_binding.cjs | 07472B0E844A51845414294206FF1638000BCFA525BA072DAB00CA1DD18357C5 |
| work/cloud/workspace/service.cjs | 03ABDAF27E87CC459BCE5CC6C1E7764C8D87CE576845454F22B84AB406A22C95 |
| work/app/src/web/workspace/upgrade-operations-ui.mjs | 436FDFF36A15CB8C5F84D376F169741EBA55EB5E096D717EC3060B3B3639F92E |
| work/app/src/web/workspace/app.mjs | 8F04B656C96D9CA728085423E2B5EFA4E99AC8A71AE410DE69B219EBAD334E1E |
| audits/company-source-binding-actual-fixture.json | 9D1DB0948D6AE7A557905913A2BC47AEBC89AAB0DA091390F6A18151F9262D72 |

## 云端关键核验

`source_binding.cjs:17` 使用当前有效会话、当前 admin/operator 员工和本人未撤销原设备授权；`:27` 验原事件归属、设备、规范完整 payload/hash、成熟上报 fingerprint 和对应非 provisional 客户；`:52–54` 严格字段与三个字符串类型；`:56` 原来源/客户读两遍并在末尾重核完整 principal 和记录摘要。

独立测试覆盖全部七种不可变上报事件；无渠道仍可匹配；同 UID 的另一 event/hash 不替代原事件；原 URL 经服务端规范化后的摘要漂移拒绝；事件 fingerprint、客户关联、公司隔离异常均保守失败；管理员和其他员工不能代读原 source actor。第二次 SDK 返回来源元数据或客户字段改变，以及末次读取期间角色/设备 digest 改变，均返回 409 且不显示匹配。

`service.cjs:58–81` 对此路由保留原 stored，缺公司状态直接 503。独立验证缺 event、公司不可用、重启及已有过期 sessions/rememberedDevices/attempts 时均不初始化、不 housekeeping 写入。SDK `.set` 独立计数覆盖成功和失败路径，所有代表每个回调最多 5 次读取、0 次写入；成功完整路由的两个事务各回放两次，最多合计 12 次读取。测试中的来源/客户迟变通过返回值代理注入，避免错误地将旧 fixture 的快照外 docs 修改误认为同事务内变化。

原 event 缺失返回 `not_recorded`，仅描述当前固定约束读取结果；不能证明以前未上传、未发送、原注册未提交或全局不存在。匹配只说明公司留存对应设备上报，`local_chain_authority_verified`、`platform_provenance_verified` 仍 false。

## UI 关键核验

`upgrade-operations-ui.mjs:56` 的真实 `checkedCompanySourceBinding` 接受最终 actual fixture 五个 30 字段投影；公开 `source_event` 仅 kind/server_received_at，不要求或泄露 payload hash、原评论、联系人等。已保存 origin 场景拒绝 `no_origin` 下降为未准备。非法私有字段、原 kind/身份/版本、不合法时间上下界、平台验真或金额 0 注入均先校验后拒绝显示。

`:322–332` 专属按钮显式调用 `company_handoff_source_binding_get {handoff_id}`。真实 factory 打开只做本机准备 GET，未自动查询公司；查询无 sessionStorage 写入/删除，不走 generic recovery/write/dispatch。not_recorded 保留旧未知槽；stale UID 和撤回仍可看公司历史匹配，但顶部本机可用性同步为暂停。查询开始清旧公司结果，失败、另一个公司查询及重新 GET 后无旧成功显示；accept、角色、设备、deviceGeneration 和 reset 后的迟到响应丢弃。

`app.mjs:383–393` 的实际 execute 提取验证：本机动作进入 product_action；localWorkspace false/undefined 在任何 cloud.call 或 command submit 前拒绝，mutation_committed false 只描述本次未调用。

## 证据限制

云检查实际调用项目 createService/createStore 和成熟仓库，数据全部合成。底层为 SDK 接口兼容内存双回调适配器；没有运行真实部署或真实 SDK 事务引擎。UI 检查执行生产 checker/factory 和完整 actual JSON，配轻量 DOM/受控传输时序；不是 GUI 人工验收。交错公司操作的 unknown 仅用同 origin 绑定的受控运输输出验证互清显示，不冒充该新 fixture 的真实云操作回执。

本轮无 C 复现的产品 RED。D 单独报告并修正过字符串类型合同差异；此处最终类型代表已通过，不重复归属其 RED。Root 编辑工具截断已恢复后才执行 UI 测试，也不计产品 RED。未调用真实网络、真实用户数据库、真实 vault、provider、平台、发送、支付或部署。

来源对应不能替代平台事实、客户授权、公司原注册执行、资源部独立接收或财务证明。`no_dispatch_scope=this_source_query_only` 不覆盖任何先前操作，不清 origin 或旧 unknown，不触发重试。
