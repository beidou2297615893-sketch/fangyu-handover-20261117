"""Static v2 evidence freeze only; never launch the diagnostic/benign harness."""
import hashlib
import json
from pathlib import Path

PROJECT = Path(__file__).resolve().parents[3]
PHASE = PROJECT/'work/product-upgrade-20261009'
AUDITS = PHASE/'audits'
DIAG = PHASE/'diagnostics/developer-original-identity'
NAMES = ('bootstrap.py', 'profile_occupancy.py', 'profile_process_probe.ps1',
    'runtime_identity.py', 'owned_job.py', 'host.py', 'native_runner.py')
PREPARED = ('benign_job_child.py', 'benign_job_probe.py')


def record(path):
    value = path.read_bytes()
    return {'path': str(path.resolve()), 'bytes': len(value),
        'sha256': hashlib.sha256(value).hexdigest().upper()}


def main():
    for name in NAMES+PREPARED:
        if name.endswith('.py'):
            compile((DIAG/name).read_text(encoding='utf-8'), str(DIAG/name), 'exec')
    backup = PHASE/'backups/phase26-owned-job-v2/1'
    evidence = ('test_phase26_developer_identity_host.py',
        'phase26-developer-identity-own-three-v2-first.txt',
        'phase26-developer-original-identity-host-v2-review.md', Path(__file__).name)
    manifest = {
        'contract': 'phase26_developer_host_atomic_v2_freeze_v1', 'sources_frozen': True,
        'source': [record(DIAG/name) for name in NAMES],
        'prepared_only_benign_harness': [record(DIAG/name) for name in PREPARED],
        'evidence': [record(AUDITS/name) for name in evidence],
        'v1_backup_manifest': record(backup/'backup-manifest.json'),
        'v1_frozen_manifest': record(backup/'phase26-developer-original-identity-host-final-hashes.json'),
        'verification': {'unique_methods': 3, 'passed': 3, 'seconds': 1.086,
            'mechanism_only': True, 'benign_harness_executed': False,
            'real_job_lifecycle_verified': False, 'original_account_observed': False,
            'original_data_read_by_d': False, 'dpapi_read_by_d': False,
            'os_process_scan_by_d': False, 'commercial_natural_authorized': False,
            'collection_authorized': False, 'total_goal_complete': False}}
    (AUDITS/'phase26-developer-original-identity-host-v2-final-hashes.json').write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    print(json.dumps({'source_count': len(NAMES), 'prepared_harness_count': len(PREPARED),
        'unique_methods': 3, 'static_compile_only': True}))


if __name__ == '__main__':
    main()
