"""Emit isolated mechanism evidence only; never selects original native DATA."""
from pathlib import Path
from tempfile import TemporaryDirectory
from unittest.mock import patch
import hashlib
import json
import socket
import sys

PROJECT = Path(__file__).resolve().parents[3]
sys.path[:0] = [str(PROJECT / 'work/app/src'), str(PROJECT / 'work/app/tests')]
from test_original_browser_identity_maintenance import MaintenanceFixture, TEMP
from assistant.original_browser_identity_maintenance import PURPOSE


def main():
    TEMP.mkdir(parents=True, exist_ok=True)
    with TemporaryDirectory(dir=TEMP) as folder, \
            patch('assistant.service.protect', side_effect=lambda value, **_: value), \
            patch.object(socket.socket, 'connect', side_effect=AssertionError('network forbidden')), \
            patch('assistant.service.AssistantService.start', side_effect=AssertionError('Service forbidden')), \
            patch('core.adapters.Adapters.execute', side_effect=AssertionError('CLI forbidden')):
        fixture = MaintenanceFixture(folder)
        before = fixture.original_bytes()
        fixture.host._launch_owned = fixture.launch
        public = fixture.host.execute(dict(purpose=PURPOSE, account_id=fixture.account_id))
        mechanism = fixture.host._run_owned_candidate(fixture.account_id)
        assert before == fixture.original_bytes()
        assert len(fixture.launches) == 1
        assert public['state'] == 'blocked' and not public['job_created']
        assert mechanism['mechanism_only'] and not mechanism['public_entry_authorized']
        evidence = dict(synthetic_only=True, real_account_accessed=False,
            real_browser_or_platform_executed=False, service_free_live_route_available=False,
            public_result=public, private_mechanism_result=mechanism,
            original_metadata_cookie_activity_bytes_unchanged=True,
            local_mechanism_writes=['account_lock_file', 'one_staging_job', 'candidate_proof', 'outcome_marker'],
            staging_job_removed=True, mechanism_process='in_memory_fake_process',
            source_metadata={name: hashlib.sha256((PROJECT / name).read_bytes()).hexdigest().upper()
                for name in ('work/app/src/assistant/original_browser_identity_maintenance.py',
                    'work/app/tests/test_original_browser_identity_maintenance.py',
                    'work/product-upgrade-20261009/audits/emit-phase24-maintenance-fixture.py')})
    output = Path(__file__).with_name('phase24-maintenance-actual-fixture.json')
    output.write_text(json.dumps(evidence, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')


if __name__ == '__main__':
    main()
