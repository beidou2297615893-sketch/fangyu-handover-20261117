# Phase20：私有单批完成后，明确继续原任务

2026-10-10，只读选型结论；本阶段实施由根窗口随后明确授权。沿用 R01–R25，总体尚未完成，不把 Phase19 的 503 后端/270 前端验证等同真实平台、成交或部署验收。采用 RevOps 最小流程判断：优先修用户正常获客路径的断点，复用已有记录与入口。

## 选这一项的理由

保存策略、原快照确认、单批执行、任务评论、人工判断/回复、授权交接、本人待办与每日记录已具备。下一项应让用户自然完成一批后，看到本次实际结果，并再次明确确认同一原任务的下一批；无需补一套新任务、许可审批或只读看板。

现真实断点：`assistant/business.py:561–568` 私有 `task_run` 分支仅返回 status/batches/imported/duplicates/task/strategy_completion，丢掉 `core/engine.py:1253–1260` 已形成的原 `summary`。`collection-progress.mjs:331–347` 只有同原 run_id、实际计数完整的摘要才显示继续；`app.mjs:639–648` 已把私有继续接回既有 `openPrivateSingleBatch`，但自然结果没有摘要，入口不可达。旧 actual fixture `private-strategy-single-batch-entry-actual-fixture.json:113–160` 已显示实际首批 1 新增、未 exhausted、两个私有词槽、`snapshot_not_exhausted`，而没有 summary，不能用人工塞摘要的 UI 样例证明此链完成。

另一个实际问题是私有进度隐藏 `continuous-panel`，也隐藏唯一分析恢复按钮。但 `AIWorker.step:69–88` 已自动排队，暂停保护也已具备；它是异常恢复路径，优先级低于正常首批完成后的直接继续。

## 最小范围与可信口径

- 仅补 `business.py` 私有结果白名单与 `strategy_tasks.py` 必要可信投影，保留普通任务和现有 Core/Pipeline。沿用当前 UI 的继续→原任务预检→再次勾选→`task_run {task_id,max_batches:1}`。
- 摘要只取本次真实 Core run_id、读取/过滤/重复/新增/延期计数、停止原因和评论收录余量。`remaining` 是评论收录容量，不能称剩余关键词、HTTP 配额或预计高意向客户数。
- 原任务/账号/source 必须与执行前绑定一致。继续是当前可进入确认的建议，必须在结尾复核原政策、租约、活动风险和实际权限；失效只禁止继续，保留已完成结果。范围已完成、额度耗尽、HTTP461、撤权、过期、未知结果都不能被包装为可继续。
- 只提供数字型私有快照进展时，必须从有效原 snapshot/pipeline 推导，不能暴露词、URL、原错误、检查点或私有正文。绝不续期、重建租约、创建替代任务、自动第二批。

## 最难代表验收

复用成熟 `SingleBatchEntryFixture` 和实际 Business/Core：两个私有词的原快照，首批自然完成但未 exhausted，原计数与 run_id 原样绑定且摘要可让现有入口出现；随后用户再次确认，仍同 task/account/source、明确 max_batches=1，从已持久断点读第二词，范围完成后禁止继续。并插入结尾租约/政策/活动/权限变化，验证真实已保存新增仍可解释而不授权继续；未知/丢回执保持原操作编号，仅核对，不能自动再执行。所有平台适配器只返回合成数据，联网/CLI/云/模型调用禁止，原数据不访问。

本建议只定位实际源代码和既有证据，未运行新测试或修改生产；之后的 RED→GREEN、当前源码哈希与实际 fixture 另记实施报告。旧 Phase17/19 证据保留为历史，不冒称新链已过。
