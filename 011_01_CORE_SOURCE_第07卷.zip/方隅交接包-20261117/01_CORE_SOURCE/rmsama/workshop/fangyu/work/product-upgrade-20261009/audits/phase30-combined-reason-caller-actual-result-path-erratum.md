# Phase30 实际结果 manifest 路径勘误（v2）

这是我生成实际结果 manifest 时的路径映射错误，不是 Native 运行材料发生变化。原 manifest `phase30-combined-reason-caller-actual-result-final-hashes.json`（SHA `FA4A77ACD7617AA05C61F4FC934B0DA2060551FF63261C34DE7218706B2CBEDF`）与原报告（SHA `9716EE620F7CEC6AF29052682E89B038EBD44A50A7DD25AA7C9F058188261AF3`）完整保留，不覆盖。

对原 manifest 所有 35 个 path/hash 引用逐项只读核对：33 项路径存在、SHA 匹配，原列 bytes 匹配；2 项误写到 `diagnostics/native-owner-resolver` 而不存在。原报告“17 项精确文件均已匹配”作为原 manifest 全路径核验声明不成立，现明确撤回；不能通过不存在的路径证明原声明。root 归档断言在 snapshot/docs/注销写入前拒绝是正确行为，不略过或弱化断言。

## 两项实定位更正

1. `verified_source_snapshot[3]`：`phase26_native_combined_owner_occupancy_probe.py`。正确文件：`C:\积木软件工坊\项目\方隅公寓客户版\work\product-upgrade-20261009\phase26_native_combined_owner_occupancy_probe.py`；SHA `7B5CA2F7B3583C0383F518CA4E4B882BE647157DDC9644FBBAFBC75801930B01`；20602 bytes。
2. `verified_source_snapshot[6]`：`phase26_native_owned_python_probe.py`。正确文件：`C:\积木软件工坊\项目\方隅公寓客户版\work\product-upgrade-20261009\phase26_native_owned_python_probe.py`；SHA `867BA28D13976CE1B3FD6637B40BF6DD19CB65BE716219D83F92B29BC5354157`；12294 bytes。

两项由限定 STAGE 的 rg 实际定位，并与已冻结新 parent 的 HERE/PROBE/_PINNED 静态定义相符（HERE 为 STAGE 根）。两项正确文件内容 SHA 与实际 result/attempt 的原声明一致。更正没有改 source/hash/Native 结果，也没有从备份或影子目录取代实际材料。

新 v2 对 35 项完整引用检查存在性、SHA、bytes，17 项源码补上实际 bytes，并将原 `actual_sha_verified_before_report` 改为本次 v2 路径复核标记。核对范围不含重新扫描运行 exe/tree 或原数据。原报告关于 blocked、严格标签、已确认自有退出、任务清理与账号未恢复的事实结论保持；所有“旧版全路径已核”声明以本勘误和 v2 为准。

本次只新增本勘误与 corrected manifest，测试/Native/CIM/Scheduler/产品源码变更均为 0。原 manifest、报告、结果、attempt、首清理历史和候选材料 SHA 保持。新 v2 不是新的运行回执。
