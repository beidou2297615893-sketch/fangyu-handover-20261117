# Phase25 既有公司准确详情的纯读验收

结论：新增 3 个云侧代表全部通过（2893.7029ms），成熟 handoff-ledger 的必要 15 项定向回归通过（107.7467ms，历史覆盖不计新增）。本轮只改既有 acquisition_handoff_detail 路由，不增加云 API、不扩大 list、不实现 submit/receipt。Phase23 本机登记 helper / transport / 36字段合同 / 历史attempt flag未改。代表使用隔离合成资料，不向真实公司或平台操作。

## 两份生产源与保存范围

修改前 service.cjs 为 03ABDAF27E87CC459BCE5CC6C1E7764C8D87CE576845454F22B84AB406A22C95，handoff-ledger.cjs 为 7CA948D72A8C93763BFD00E2303BAFA35B6B12AC7450114F414DA301A5195128；两份逐字备份并SHA校验于 backups/company-channel-detail-pure/1，清单先于生产改动。旧阶段报告/JSON/hash不改写，旧SHA仍代表其当时来源。

service仅把准确detail加入readonlyPureQuery：missing公司返回固定503不初始化管理员；有效/无效会话、权限或错误返回保留原stored，dispatch不保存清理后的state；本次读故障只返固定安全错误。旧status/source-binding合同保持，list仍原路由。

ledger新增detailRead，复用statusActor与readBoundItem。先读绑定快照，再做既有publicItem投影，最后重新读完整item/当前consent并核当前actor+trusted acquisitionPolicy+visibility；发生变化401/409，无旧item投影。只是当前channel最新snapshot/audit自hash，不能说全历史链。

成功 flat envelope 精确11字段：contract, environment_id, company_id, item, server_recorded, platform_delivery_verified, attribution_confirmed, settlement_active, read_only, mutation_committed, auto_retry。contract=fangyu-workspace-v1；server_recorded/read_only=true；平台/归因/结算/mutation/auto_retry=false。item保留既有publicItem的阶段性字段，不加replayed、authenticated_actor或outer original_execution_confirmed。私有UID/引用仍应由本机专属投影剥离，不能把原item整体给新UI。query mutation=false只表示本次纯读，不说明过去register或submit未执行。

## 实际代表与原RED

新增 tests：audits/phase25-company-channel-detail-pure.test.cjs；复用成熟fixture的独有 wrapper：phase25-company-channel-detail-sdk-fixture.cjs。调用实际 createService/createStore 与成熟repos，通过SDK接口兼容内存adapter手工双callback回放。网络入口禁止；不是 node-sdk内部事务引擎、线上延迟/吞吐、真实云或第二机器证明。

1. 最难链：实际合成register提交后整条响应丢失，按原key/status核原hc/revision1/draft，再准确detail，source完整8字段与固定原event一致。加入expired session/rememberedDevice/attempt后，本次detail仍整个document snapshot相等、0writes；移除公司文档后503、0writes，不新账号。首次原源执行真实RED（825.0776ms）是detail保存了housekeeping，不是夹具错误；first-red日志保留，原首test备份也保留。修正后原单代表1/1，721.3207ms，随后只添加两必要方法。
2. 来源本人、当前mapped receiver和admin/manager可读draft，但draft can_receipt=false；outsider/错误session/已disabled主体拒绝且0writes。没有新增授权或让admin自签receiver。
3. 在最后withdrawal await处注入主体disabled或receiver映射撤销；在实际SDK get结果处控制当前consent改变，或具有合法新snapshot/audit自hash的同UID换comment当前item。每个场景确实命中末读，401/409，无item输出、0writes。前两项是transaction当前state注入，后两项是受控document返回变化，未假称真实并发云事务。wrapper另计所有被尝试的callback，包括抛错callback；不能只数成功事务漏掉错误写。

所有被包围的准确detail，实际SDK doc接口set计数0、合成全存储snapshot前后相等、每callback读取<=100。这是detail调用的证据，不把fixture初始化、来源归档、register写或人为资料准备算零写；本组三组纯Node，没有冒领本机SQLite tracing，root的新本机模块有其独立Core证据。首失败日志输出过合成文档，后续仅比snapshot内容hash，原错误证据未删改。

最终3方法日志为 phase25-company-channel-detail-final-green.txt；单代表green和最终复跑不额外计方法。成熟15项日志 phase25-company-channel-detail-ledger-regression.txt，只验证受改ledger的兼容性，未跑旧全矩阵/511/原账号元数据/CLI。

## 仍保留的产品边界

详情读证实本次current channel.source可核，不补造Phase23丢失的write echo；原 registration_source_verified=false仍false。新本机current_channel_source_matched应独立表示当前对应并freshscope重核，来源匹配不等平台权威/历史全链/资源部独立接收/现金。公司草稿、明确submit、独立receipt与撤回仍不同阶段，本轮没有新submit写入口、自动重发、自动续期、收费、模型或联系方式交付。

root并行新增本机check/transport/gateway属于另一独占源，不由本cloud3报告冒领；其最难actualCore/readHTTP代表另记。下一独审若发现该接线缺口，另加最多2必要本机代表，不修改本轮旧证据。没有原DATA/账号/Cookie/真实云访问，无部署、打包或完整商业验收。

冻结SHA和完整产物清单见 phase25-company-channel-detail-final-hashes.json。
