# Phase14：原准备来源的公司事件精确核对

本轮已实现本机 `company_handoff_source_binding_get{handoff_id}` 与公司 `acquisition_source_binding_read{event_id,payload_hash,expected_device_id}`。前台只能给本机交接编号，事件、摘要与固定设备从已持久本机原准备派生。功能是主动纯读核对，不上传、不登记、不续期、不标送达，也不写missing墓碑或清原unknown。

新本机 `CompanyHandoffSourceBinding` 复用冻结 phase13 原本人来源完整链快照及 phase12 准备GET，未修改旧helper。无origin直接no_origin且不调用cloud_read。原来源/完整链/ACK及actor/device/env/company当前范围首尾不一致拒绝；已有当前UID改动或授权withdrawn允许原历史读取，current_local.preparation_usable仍false。公共结果严格30字段，不返原事件ID、hash、UID或正文；matched时只投影事件kind/server_received_at。

新公司 `source_binding.cjs` 复用成熟 contact repo、normalizeEvent 与候选来源校验算法。它核实际当前session actor、当前owned active设备、原record、canonical payload hash、设备上报fingerprint、同customer身份；两遍读取event/customer及首尾principal检查，不需要已有渠道或索引。管理员和资源部角色不能提升为他人来源读取。server/company由当前部署及可信绑定决定；历史ACK或客户端expected_device_id只是约束，不能提供身份权限。

service.cjs已先逐文件1号备份并核哈希，再仅为新action加入纯读路由：缺公司文档不初始化，成功/失败不保存session清理等housekeeping变化。原phase11 status路线继续保留原语义；其它既有路由未借本轮扩大权限。备份为 `backups/company-source-binding/1/service.cjs` 及 manifest，原SHA `6F6BDA5283DE833BEF1A3A49A9D37BA8DF2FAD3F714042D0FAEEBB1D358EC796`。当前service新SHA只能属于phase14，不能冒称phase13冻结值。

## 验证与证据

- 新Python必要测试唯一模块8/8，其中1组实际双端合成链路，另7组actualCore + 明确标注controlled cloud合同。覆盖无origin0调用/0SQL写、事件/hash/员工/设备/权威字段拒绝、not_recorded不清ACK或原准备、当前UID/撤回保持暂停、损坏原链阻云读、响应晚到来源/actor变化、严格输入与会话错误。
- 新公司必要测试唯一模块6/6。覆盖指纹/设备/owner拒绝、全部7种source kind、缺源/缺公司/expired housekeeping0写、URL规范化摘要不同不猜配、晚actor/device/customer变化、跨company/坏customer/存储错误固定安全回执。重复代表及修复复跑不新增测试总数。
- 独立审查 C 的新cloud模块6/6已收到；独立测试不包含在上述6项中，单独记录。Root的gateway/transport/request_json隔离opener4项首绿，不能代替实际公司repo证据；root最终UI/GUI/旧回归由根窗口独立归档。
- 实际双端JSON采用 actual Core/Store/ContactJournal/AcquisitionOperations + 实际项目 createService/createStore/contact repos，经 SDK接口兼容内存事务适配器手工双callback；不是node-sdk内部事务引擎、真实CloudBase、真实帐号/客户或在线性能实测。没有真实网络、平台或模型调用。
- JSON五case原样来自实际执行：no_origin / not_recorded / matched / stale_uid / withdrawn，含真实preparation_get_result。特意先有本机ACK+原准备而公司未同步→not_recorded，再通过实际合成contact_events_sync→matched，证明旧ACK不等于公司存在证据。
- 每个status callback 0写、公司docs及本机SQLdump不变；入口每callback1读，matched/stale_uid/withdrawn读层5读，not_recorded读层3读（两遍精确event读取），无origin0公司事务。计数仅该SDK接口文档路径，不证明实际SDK内部重试、云30秒预算或在线吞吐。

## 初次运行与修正

实际双端测试初次被同一class的全局subprocess mock挡住固定本地Node夹具；改为独立actual test class后通过。模拟历史链损坏时初次触发成熟append-only trigger，后仅在新测试临时数据库中显式drop该trigger再注入损坏。两者均为夹具配置错误，不是生产缺陷，不改原库保护。

最终严格类型审得到真实红例：expected_device_id=true经JavaScript regex隐式转字符串，原返回403设备拒而不是400非法请求；未发生越权或写入。已明确三个来源参数必须string，原红日志 `company-source-binding-string-types-red.txt` 保留；最终cloud6/6和local8/8通过。新helper/public合同没有新增字段。

## 证据含义与未接入事项

只有精确matched才 `company_event_payload_matched:true`，表示当前指定企业账本保存了此固定设备上报事件。`source_cloud_binding_verified:false`、`local_chain_authority_verified:false`、`platform_provenance_verified:false`、平台送达/财务/合作政策false以及实收实付null均保持。云没有本机previous_hash/chain_hash或平台权威ACK；本机ACK也没有原上传env/company/device证明。公司事件存在不等于平台send、独立客户授权、资源部接收、成交或佣金到账。

本次 `mutation_committed:false` 只指此查询无写；not_recorded不能推出原动作未执行，不能解除原unknown。`no_dispatch_scope=this_source_query_only` 只限本次。已读匹配是观测时点，不是后续永久登记许可证：后续真正dispatch/register必须在其写事务再次核冻结来源期望，现写route尚无这个新承诺。本轮不实现提交/自动重试、任意key输入、跨机来源核验、平台自动联系或打包发布。

最终完整源码、测试、JSON与旧freeze对照哈希见 `company-source-binding-final-hashes.json`。根窗口所有新增transport/gateway/UI不由此子任务改动或冻结。
