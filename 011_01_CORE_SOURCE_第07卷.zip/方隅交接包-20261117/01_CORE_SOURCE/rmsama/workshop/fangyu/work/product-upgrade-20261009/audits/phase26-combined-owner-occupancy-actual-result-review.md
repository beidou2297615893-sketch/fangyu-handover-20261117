# Phase26 组合 Owner 良性代表：实际结果独立核对

结论：GUID `b7965084cace417e8af01e7f74b68986` 唯一实际执行已完成并保持 **blocked / classifier_not_vacant**。first frozen classify 为 **unknown / process_metadata_unavailable**，没有第二页稳定性结果，不能将组合路线、profile 空闲或账号恢复标为通过。本次 root 已确认自有 Job 退出、当前 SID/材料不变，并精确清理唯一 Task。D 本轮仅读取安全回执及冻结源、计算内容 SHA；没有 Native、CIM、Scheduler 查询/执行、测试重跑、原库/DPAPI/账号操作或源码修改。

## 证据相互对应

- actual result SHA：`0DAAF7BA871AA9F14692F063747B4059F11257A015362B3B8B54A95AA160E8CF`；root Task receipt 的 result SHA 与实际文件匹配。
- candidate manifest **5EB857D5…** 中 3 个来源、4 份候选证据均与当前内容匹配；实际 result/attempt 中全部 **14 个运行来源 SHA** 与当前实际文件匹配，旧 **26 项**冻结来源/证据也保持一致。
- 原 parent **7B5CA2F7…**、child **8F3AC080…**、PS **B44176F8…**、adapter **CD1A8C1F…**、resolver **9770E572…**、classifier **FF750FDF…**、固定 probe **867BA28D…**、TokenUser getter 来源 **C7081FCF…** 全部保留。没有更改这些来源来掩盖本次阻断。
- result、immutable attempt、dispatch、Task receipt、owned cleanup 的 run GUID 完全相同。dispatch/attempt 的 `execution_finished=false` 是派发/创建时历史字段，final result 的 `true` 才是本次结束记录；二者不矛盾。
- Task receipt：Ready、`last_task_result=1`、exact action=True、XML principal SID matches=True、trigger_count=0。父程序 blocked 时返回 1，符合该结果，而非通过。
- cleanup receipt：removed_only_owned_task=True、absent_verified=True、other_tasks_modified=False。本独审没有重新查询 Task，也没有把提供的清理回执扩大成独立全机器操作审计。root 以 XML SID/trigger 核对修正友好别名和 `@($null)` 误判，未因此再执行代表。

资料均在 `C:/积木软件工坊/项目/方隅公寓客户版/work/product-upgrade-20261009/audits`，相关 6 份实际文件的精确 SHA 和路径列于本报告最终 manifest。

## 实际可见与缺失事实

唯一首轮完整固定-CIM snapshot **54 行**；这是固定脚本定义范围内的相关进程行，不是 Windows 全部进程。其它 owner 缺失 **0**。原子进程原 WMI owner=current=True、原 creation/parent/Job admission=True、固定 runtime/完整 argv=True、RAM redaction_count=1、WMI provenance preserved=True、sample error_code=null。因而这次演练保留了原 WMI 事实，仅刻意删了已准入子进程的 owner 字段。没有证明实际 WMI outage，也没有在本轮代修其它进程 owner。

随后 adapter 公开结果为 unknown/process_metadata_unavailable、source=incomplete、token_user_rows_verified=0、complete_snapshots_checked=1、token_user_evidence_stable=null。两个 snapshot 相等、child binding 跨页不变和 final child 三项均为 null；没有第二页是首阻断安全短路的结果。最终 owned_exit_confirmed/current_sid_unchanged/materials_unchanged 全 True。退出完成与占用分类通过是不同事实。

仅安全 counts/hash/布尔/有限 reason 保存，没有 raw PID/SID/命令行/进程路径/handle。原账号/profile 未用、browser/CLI 未启动、原库/DPAPI/平台/云/provider API 未调用是候选限制及回执字段；没有 packet capture，不能将此扩大为整台电脑或其它窗口绝对没有网络活动。也没有读取原业务文件另做 before/after hash，不能据本报告声称原 DATA 独立全字节证明。

## 冻结源码能推断到哪里

`occupancy_adapter.py:84–96` 的 `_resolve` 必须拿到完整 verified/current/creation/running/TokenUser/handles_closed=True 和有效 evidence hash 后才返回。`:128–133` 对唯一 None-owner 行先调用 `_resolve`、RAM 填当前 SID，再执行真实 `FROZEN.classify`。`:137–139` 首非vacant仅公开 state/reason并立即返回，不进入第二页。

**源码控制流推断**：在本轮唯一 deliberate-None row 和相应输出路径下，首 classifier 在 `_resolve` 条件通过后执行；若 `_resolve` 验证失败，公开原因应为 owner_evidence_unavailable。不能把公开计数 0 读成“Native resolver 未调用/零次原生 API”。但本次未另行保存 Native API 调用次数或首 `_resolve` 原始安全回执，不将这一控制流推断包装为独立 API trace，更不生成完整两页可用证据。`:169–172` 仅在两页完成以后赋值 `token_user_rows_verified`，当前 0 是未完成投影，且不是用户 SID、owner 或实际调用次数。

### 已纠正的一项沟通推断

D 最初短消息把公开 `fingerprint=null` 当成 frozen classifier 外层异常指示。复核 `adapter.py:137–139` 后发现，首非vacant投影没有拷贝 `initial.fingerprint`，保留初始化 null；因此这个推断不成立，已立即告知 root，root 已确认接受纠正。公开 null **不能区分** classifier 外层异常与某 row 的 uncertain。原沟通和实际 blocked 不覆盖/重写，本最终结论不再采用该误推。

## 可能门禁与证据边界

冻结 `profile_occupancy.py:113–212` 对外把很多不同异常统一成 process_metadata_unavailable：

| 真实门禁 | 本次可缩窄之处 | 本次不能确定之处 |
|---|---|---|
| target profile canonical、snapshot shape/unique PID、trusted Python 前后核验 | provider 已核基本 shape/完整行类型、唯一 PID；父/子固定 binding 与材料回执为 True | 未保存 classifier 内 profile 或 trusted validate 实时阶段值，不能排除调用时瞬态变化或外层异常 |
| 每 row owner/parent/created、canonical exe、basename、argv0 | provider 已核这些字段基本存在；其它 owner None 为 0，目标 child 原来源准入为 True | “字段存在”不等于每个 exe/profile 都过 no-reparse/canonical/default-policy/parent-chain 门禁；没有安全逐行失败 stage |
| explicit/default/inherited profile、Job 与选定 WebView runtime | 完整 frozen classify 未被 family/PID 豁免，synthetic target 和 owned callback 原样传入 | 未观测是哪一行、哪一个 profile/default/Job/runtime 门禁导致 uncertain；不能指定 Chrome/Python/WebView2 为失败主体 |
| 后末 trusted validate、fingerprint 生成或其它外层异常 | adapter 首阻断短路被保留 | 首 classifier 原 fingerprint 被投影省略，无法凭当前 null 定位内外层 |

当前证据不足以把本次归为先前原观察 **8070** 的同一原因，也不能归为先前 benign WebView **0464** 的 Chrome owner 缺口：本轮其它 owner missing=0，且本轮没有同等安全 trace。过去独立 sleep-child Native TokenUser 代表成功、RAM/recording APIs 组合通过，是各自证据，不覆盖本次 complete classify 失败。

## 唯一建议的下一小步（尚未实施/批准再次执行）

先复用已冻结 `diagnostics/benign-webview-metadata/safe_trace_v2.py` **C5245762…** 的临时 `sys.settrace` 机制，准备一个**新独立 reason-only 观察器**围绕真实 adapter/FROZEN 调用：只导出 outer/row 计数、固定 family/stage/code、owner_current/canonical binding/profile_matches/owned-membership 的 True/False/null，不存 PID/SID/argv/path、frame locals 或异常全文，不改变 classifier/adapter verdict或补 owner 范围。现 trace 已通过合成代表解决 owner 与 owned 子串误标签、正常 profile_missing 控制分支和 stale-local 投影问题；无必要再开展大矩阵。

这一步只定位分类失败类别，不新增 Native API 调用统计或改最终 public 计数。观察器应按冻结 SHA 和语义精确 AST 定位真实 outer/row 分支及实际函数 filename，聚合本轮 RAM 事件；trace 不可用则诊断 unknown，不运行替代算法，不用 trace 解冻 profile、授权下一页或移除旧风险。

在任何 OS 代表之前，最多验证“outer 异常”和“单 row uncertain”两个合成 trace 标签/不改变 frozen verdict 的小样即可；不运行 CIM/TokenUser/Host/原账号。只有 root 单独批准、新源固定并独立审阅后才考虑一次相同良性 sleeping-child 代表，不盲试第二次，不打开原浏览器。若 root 选择暂不继续，这次 blocked 与已清理记录已经完整可复用。

本轮没有实施该观察器、没有增加许可/批准 schema、没有改原计数或 source flags；组合 route 和原 account/profile authorization 均仍未通过。
