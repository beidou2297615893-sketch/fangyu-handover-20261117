# Phase28 资源部公司收件箱实际隔离 UI 核验

用当前生产 asset/gateway/receiver/Core 和实际 service/createStore 的本地 SDK 接口适配器，在本人 resource operator 的空客户库中实际打开收件箱。源码先固定、实际加载/取资产后再次核 SHA；未启动正式 AppServer/AssistantService，没有原账号、原库、平台或真实公司网络。

共 7 次动作：明确选择部门前摘要、所选列表、详情、一次接单、同原号 GET、固定合成撤回、再次原号 GET。源端 fixture 准备单独为登记 1 / 提交 1，接收 UI 启动时接单 0；最终接单总数 1。默认未勾选，补证据并人工勾选后才点提交。实际 SDK 已提交后丢回执，页面只能原号核对；两次 GET 均本机零 DML/DDL、SDK 回调零写。第一次 GET 找到历史 accepted；撤回后当前 withdrawn/current consent false，而同原接单历史仍保留。

这里只证明隔离操作链路。SDK 接口内存双回调不是在线事务引擎或第二实体机；平台引用不等于电话/微信跨机交付，格式化证据引用不等于独立核验。客户实收与分成始终未核实/null。

实际加载/取资产证据共 48 个固定来源：Python 15、云 8（含两个 SDK fixture）、页面取资产 25。启动前共固定 56 文件。资产原日志含 42 个有效 JSON 行和 1 个第4行时间尾片段，原字节完整保留；片段不修补、不作为来源证据。config.mjs 是实际 identity 生成的运行配置，只有本次资产 hash，不计源码文件或 snapshot。归档首跑在解析片段时停止，第二次在把 runtime config 当文件时停止，两次均尚未写最终 snapshot/proof；窄改归档后只处理有效实际记录，没有重跑GUI。副本按原项目相对路径保存，不把未加载文件算加载证据。

截图共 6 张，曾请求 1586×992 viewport，结束已恢复默认；每张真实像素尺寸/格式在 proof 中，不重绘截图，不声称新 UI 视觉已获认可。外层页面少数启动/本机交接读取被本 narrow synthetic host 拒绝，背景出现隔离 host 提示；这是本预览限制，收件链路本身通过。正式演示需完整 host 与真实账号/公司能力验收。

生产资产白名单遗漏在启动前由静态审核发现并窄补；旧源/pins 保留，非伪造 GUI 首 RED。主流程中 privacy 标签 P2 由独立真实 RED 找出、receiver 窄修后同 2 项 GREEN，另有历史静态测试漂移修复。

实际证据：phase28-company-receiver-gui-actions.jsonl、phase28-company-receiver-gui-proof.json、company-receiver-gui-state.json 和 source snapshot。全过程没有打包或部署。
