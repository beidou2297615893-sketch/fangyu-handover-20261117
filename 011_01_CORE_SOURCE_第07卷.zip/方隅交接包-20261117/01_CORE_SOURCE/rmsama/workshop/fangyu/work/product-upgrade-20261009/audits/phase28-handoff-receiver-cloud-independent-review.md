# Phase28 公司收件与原接收回执独立代表

当前同三方法 GREEN：3/3，5255.026ms。只新增独立测试、日志、源哈希记录及本报告；没有修改产品云源、Python、UI、旧测试或冻结证据，没有真实账号、原 DATA、Native、平台、网络、部署或付费调用。实际路径为 createService → createStore → 成熟 SDK 接口兼容内存适配器；不是实际 CloudBase SDK 事务引擎验收。

首次仅运行 received-list 方法，在旧 ledger `F1237B20…` / service `32E550BC…` 上得到真实 RED：最后一次客户同意 tombstone 读取时，将实际事务中的 resource 账号 disabled 设为 true，仍返回 200，未按当前账号失效拒绝。注入 reached 断言通过，随后状态断言失败。首方法耗时344.0621ms、该次 Node 总耗时587.8941ms，0/1；其余子例、receipt 和 status 当时没有执行，不能追认也已 RED。

首日志为 [first-red](C:/积木软件工坊/项目/方隅公寓客户版/work/product-upgrade-20261009/audits/phase28-handoff-receiver-cloud-independent-first-red.txt)，SHA `B8C0E85716C2B4290FE6516C28296253CAD5CD4DE5BD6B9E2ED23DEC76BBAF56`。Root 首产品字节保存在 `backups/phase28-resource-receiver-cloud/1/`，两源 SHA 与首读取相同。最初测试的预运行 SHA `EF4AB44A…` 已保存；最终测试仅新增同第一方法中的授权选择/预算子例。旧测试快照通过删除这一新增块重建并精确匹配预运行 SHA，不冒称该副本在首运行前另行保存。

Root 窄修后的产品为 ledger `70CE35EA77F66D752A5F94461EAEF449CDD6AD722F40848E5AA5CC855A769611`、service `EF59DD56EED438727C0C844A011BCB240AA78A5E607D01D96DCC407153FD1FFF`。本次 GREEN 前后七项源码/夹具/测试 SHA 全部相同；没有重复旧 Phase27 或全矩阵。

| 独立方法 | 实际代表与断言 |
| --- | --- |
| received-list 当前权限与纯读 | 最后客户同意读取时禁 resource、移除其 trusted receivers 映射或让当前 session 到期，全部拒绝且不返 items；原 session 已过期/缺公司文档时不清 housekeeping、不初始化公司。全部 SDK 回调 set=0，文档快照前后相同。 |
| 非来源接收当前授权与回滚 | 用原可信 source/resource 两主体及 resources 映射执行 accept。最后读取时禁 actor/撤映射/使 session 到期，或已 staged 写后撤映射/session、返回当前同意撤回 tombstone，六子例均拒绝、mutation_committed=false、无公开 item。每例有尝试 set，最终文档快照不变，证明适配器回滚而不是声称零尝试写。 |
| 丢回显后的本人原 key 核对 | 实际接收提交后故意丢回显，重建服务，用同 resource actor、原 receipt operation/key 只读 status。历史 rev3/accepted 保留；来源本人撤回后当前 withdrawn/同意无效，历史资源接收记录仍 true，独立验真 false。原 operation 元数据不变，存储中 receipt operation 只有一条，没有第二接收写。 |

首例现在没有任意补发授权：客户来源用成熟 contact_events_sync 流程进入公司，可信设备/账号绑定及 source/resource 映射均复用原 fixture；没有从前台注入 role 或自称 receiver。缺 recipient 的新接口明确返回受信 `authorized_recipients=[{id:'resources',name:'资源部'}]`、`selected_recipient_id:null`、`selection_required:true`、`items:[]`、`total:null`，不是旧协议的参数失败，也不能理解为全公司没有收件。

最坏分页并入第一方法，没有增加方法数。通过实际 contact_events_sync → acquisition_channel_register 逐一生成64个不同 customer 的原来源和公司草稿；没有直接写或伪造 recipient 索引。received `offset:49, limit:15` 跨越50条索引页边界，返回15行/total64；这64是存储草稿，不是64名高意向、已提交或已接收客户。四次 SDK 回调计数为外层 `(reads=1,writes=0)` 两次、内层 `(reads=94,writes=0)` 两次，各回调读次数≤100；前后文档快照相同。

94 次读只证明该受控 SDK 接口适配器中15行跨页路径的操作预算。实际 CloudBase 引擎限制、事务 read-after-staged-write 规则、真实并发时序和生产延迟没有因此通过；不能将 replay 回调合计成单次事务，也不能把回滚代表改写为零尝试 DML。查询零 set 是该内存 SDK 文档层的记录，不是实际 SQL trace。

原 key 回执继续区分接收动作完成与独立送达：历史 accepted/当前 withdrawn 可同时存在，独立资源验真 false，现金及已付提成 null，auto_retry=false。仅证明映射的另一合成主体记录了接收，不证明真实跨机器资源部接收、联系方式交付、平台送达或财务。当前三方法可冻结；本次未验证本机 receiver 桥或新 UI，未标总体产品完成。
