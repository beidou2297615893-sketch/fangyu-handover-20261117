# 原公司登记只读核对：phase13 业务模块冻结

新增 `CompanyHandoffOriginalStatus` 只实现 `company_handoff_original_status {handoff_id}`。从已保存且本人有权的可信 origin 派生原 register action/key/environment/company/actor/device；没有客户端原 key、同来源猜 channel、云写、dispatch、refresh、墓碑、通用 ProductOperationReceipts、本机交接更新或模型/平台调用。本阶段沿 RevOps 的交接阶段与证据边界，复用原成熟准备和账本，不另建 CRM。

## 实现和 public 合同

构造 `CompanyHandoffOriginalStatus(core, tenant, owner, company, *, device_id, scope_guard, lead_access, cloud_read)`。环境、tenant和云成员格式复用已冻结准备构造；`CompanyHandoffOriginalStatusError` 固定安全 code 前缀，400/403/409/503，所有 mutation_committed=false 仅说明本次查询不写，不能代表原公司操作未执行。

复用 prep.GET 和记录自摘要/原 key/channel 域、当前本人权限/原评论权限/交接审计/授权。无 origin 返回 no_origin（cloud_read_requested=false/local_only=true），不读取公司 session或发公司请求，不生成 key/墓碑。旧 unknown/坏 origin 和设备主体变化拒绝，不用另一 key 重建。

cloud_read 只一次固定 `acquisition_handoff_operation_status`，body 仅原服务端云动作和 key。Root transport 负责有效现有 session、可信环境/公司/endpoint、HTTP envelope校验，无自动 refresh；模块只接受剥完3个外身份字段的 exact4：operation_receipt/read_only/mutation_committed/auto_retry。只对 root 安全 SESSION_REQUIRED码给明确连接提示，其它 callback原私有错误使用安全503，不能回显token/联系人。

公共 exact29 keys与方案一致：contract/read_only/mutation_committed/local_only/storage_scope/cross_machine_verified/cloud_read_requested/observed_at/state/origin/current_local/original_operation/current_company/origin_binding_verified/source_cloud_binding_verified/platform_delivery_verified/financial_receipt_verified/cooperation_policy_verified/verified_cash_cents/verified_paid_commission_cents/settlement_active/auto_retry/no_dispatch/no_dispatch_scope/provider_requests_started/platform_requests_started/contacts_modified/handoffs_modified/ratings_modified。

- 三态 no_origin/unknown/recorded。仅 no_origin local_only=true、observed_at=null、origin=null；unknown仍持有原 origin，但原/当前公司对象为空，不证明未提交或未登记。
- recorded必须 actual authenticated_actor/原action/key、原请求冻结完整 canonical SHA、预期 hc_、原revision严格整数1/status=draft全部相等，原事件自hash=true、fullchain=false。未知字段、假财务/平台权威或矛盾nullableproof拒绝整包。
- 原操作投影exact8：channel_id/revision/historical_status/occurred_at/historical_event_self_hash_verified/full_historical_chain_verified/operation_action/execution_confirmed。不返 raw payload hash、云 key、event ID、正文、UID或同意引用。
- 公司当前对象exact6，允许历史接收仍留存而当前withdrawn/consentfalse。本机 current_local 原样保留冻结 prep.GET 的8字段，稳定stale/撤回仍可读取历史；本机 preparation_usable只表示本机原准备当前一致，不能当公司可交付。查到历史原登记不会解冻本机准备或生成可送达旗标。
- no_dispatch仅本次查询范围 `this_status_query_only`。source云权威/跨机器/平台/财务/合作验证false，实收实付null；未证明本机曾dispatch、资源部外部实际送达或付款。

## 来源历史与权限

原事件按 origin 固定 event_id/payload_hash/sequence/chain_hash/kind/ACK值核对原 owned immutable行及成熟 ContactJournal.receipt 的完整 reply链。当前同ID换UID/改正文不能替换原来源，也不能用当前表单重算原云摘要；当前暂停状态保持。原ACK仍只有本机记录，没有历史环境/设备绑定，因此source_cloud_binding_verified保持false。局部hash诊断不是签名或任意全局历史的独立核验。

公司等待期间不持 SQLite写事务。查询前后新连接重读 origin、source链、saved actor/current授权/window/device/company/env；任何变化拒绝晚结果。稳定变化后用户可重新只读历史，但不会创建新origin、更换原key、自动下一步或清槽。

## 必要验证

独占11组 Python通过：actual Core/Store/Journal/AcquisitionOperations+冻结prep；先 controlled receipt4组明确只验证本机边界，然后实际两端代表成功后补必要权限、源、格式和错误边界。包含无origin0cloud/SQL dump完全不变；unknown保原行、不取消；原digest/channel/rev/draft严格匹配和当前撤回分列；稳定正文/UID变化历史读取但当前hold；云await后的actor/device/company/environment/source/撤回晚结果拒绝；disabled/unbound/权限撤销/原ACK缺失；私有请求字段/旧未知origin；错误 SESSION_REQUIRED和私有异常不回显；各种原actor/key/hash/channel/revision/financial/unknown矛盾/extra字段拒绝。socket、平台业务进程和通用receipt在本机组禁用。

实际双端一组采用实际项目 createService/createStore/repos，经已存在 **SDK接口兼容内存双callback adapter**，不是SDK内部事务引擎或真云。源sync实际accepted_event_ids后才本机ACK/prepare；按固定完整云body实际register commit后丢响应，restart后原status recorded；随后实际独立resource合成ACK以及公司/本机撤回。原公司status每次固定一查询；所有callback writes=0、document snapshot不变，不能代替CloudBase在线网络/性能证明。no_origin根本未启动公司fixture事务。该组生成5状态，不虚增为5个独立测试，重复callback和重跑也不增加覆盖。

`company-handoff-original-status-actual-fixture.json` 有 actual helper public5 cases（no_origin/unknown/recorded/stale_uid/withdrawn），相应实际公司flat envelope、事务callback计数和source SHA。`preparation_get_result`是真实冻结prep.GET，可用于实际UI初始加载；prepared_result原写回执没有人为改flag。所有資料、账号、session和token只属于临时合成夹具，token不进入JSON。生成器首遍错写accepted_ids而实际为accepted_event_ids，属于夹具适配错误，修正后成功，未记成产品RED。

Root负责 no-refresh transport/gateway/实际UI与综合回归；B的实际网关/HTTP底层隔离独5与child实际UI审查另行记录，不重复合并成此11组或把stub HTTP当真实云。源、测试、fixture已冻结；旧phase12准备/phase8商业对账/phase11两云源SHA不变。无真实数据/账号/外部发送/云部署/支付/打包；仍未商用或真实获客验收。后续受控dispatch/outbox、另一机器资源部接收和权威回款均未实现或未核验。
