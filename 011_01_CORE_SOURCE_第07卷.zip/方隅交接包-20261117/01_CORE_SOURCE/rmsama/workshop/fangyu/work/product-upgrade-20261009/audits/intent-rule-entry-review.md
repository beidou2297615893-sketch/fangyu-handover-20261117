# 意向规则双入口与生命周期独立审查

结论：本轮发现的提交前作用域竞态已由根窗口修复，同一红例保持原断言复验通过。11项当前入口专项与冻结规则模块17项合跑28/28通过，shared operations语法检查通过。当前限定范围内没有未关闭的实质接线发现。C 只新增独立测试和审查证据，没有修改任何前台/后台生产文件、原数据或冻结模块。

报告文件：`C:/积木软件工坊/项目/方隅公寓客户版/work/product-upgrade-20261009/audits/intent-rule-entry-review.md`。
所在文件夹：`C:/积木软件工坊/项目/方隅公寓客户版/work/product-upgrade-20261009/audits`。

## 实际核对的接线

- `index.html:9` 管理中心的 `upgrade-intent-rule-edit`；当前 `upgrade-shell.mjs:108,118` 按已登记 action/管理记录展示并调用 `intent-rule-edit`。这不是管理员授权推断，员工打开后仍由真实 rules_get summary 决定，仅能看摘要与有权线索预览。
- `upgrade-shell.mjs:142` 客户详情更多菜单中的“核对本条意向规则”。详情不可见或没有真实 leadId 时不调用；有 leadId 时传给实际 `intent-rule-preview` hook，不改回复文本、不保存评级、不创建交接。
- `upgrade-operations-ui.mjs:3,183–187` 从精确 asset URL 导入冻结模块，将现有 createDialog/read/write/scope/perform/pending/recover 注入，注册两个 hooks 和公开 openIntentRules；reset/dispose 同步清 rulesUI、关闭并移除弹窗，失效 activeOperation。
- `app.mjs:183,1111` 的设备清理与会话清理调用 operations.reset，顺序在 deviceGeneration 递增之前。当前 app 实际 PRODUCT_ACTIONS/execute 词法片段把四个 rules 动作经 product_action 路由，专项禁止落入 command_submit/任务轮询支路。

## 初始红例与根窗口最小修复

初始当前 operations `5F26B96C…` 只在 execute 返回后检查 scope，计算 SHA 的 await 之后尚无提交前检查。真实模块离线序列为：打开管理者规则表单→点击保存→暂停 crypto.subtle.digest→换租户并 operations.reset→释放 digest。实际 intent_rules_save execute 调用1次，要求0次的断言失败。初审10项9绿1红，原始证据保存在 `intent-rule-entry-initial-red.txt`，不是实际跨租户写入或真实账号操作。

根窗口在 common write 捕获 activeOperation，digest 后存元数据前和 execute 前检查 scope/disposed/operation。尚未提交时明确 `mutation_committed=false`；已存元数据但未提交的第二次检查失败沿原 catch 删除本次原 slot。实际发出后未知结果仍保留原编号，不把变化或浏览器清理当作业务回滚。

修后同一0次 dispatch断言未改变，转绿；另加同 scope reset、dispose、角色变化的代表变体，直接执行实际 write，要求明确未提交、没有新 pending key、没有 execute，均通过。没有扩大到新的业务接口或更改冻结 rules module。

## 定向证据

独占测试：`work/app/tests/intent-rule-entry-independent.cjs`。精确 sibling asset resolver 直接导入当前 shell/operations/rules；当前 index 结构供轻量 DOM 模型运行。app 启动有浏览器副作用，故执行它当前未改写的 PRODUCT_ACTIONS/execute 词法片段并检查 reset 调用位置，不宣称完整 app boot 已由此测试覆盖。

11项入口专项覆盖实际管理入口版本保存、客户入口真实预选与原草稿保留、普通员工忽略意外私有 policy、隐藏/空详情无调用、关闭/重开单窗口、reset/dispose 迟到私有读回、租户/角色/设备变化、unknown 关闭重开后原编号恢复且只存 opaque 元数据、digest pre-dispatch 原红例及同 scope 变体、四个实际动作路由。

```powershell
# 执行目录：C:/积木软件工坊/项目/方隅公寓客户版/work/app
node --check src/web/workspace/upgrade-operations-ui.mjs
node --test tests/intent-rule-entry-independent.cjs tests/intent-rule-ui.test.mjs
```

28/28通过（11新入口+17冻结模块），355.8094ms。验证输出 `intent-rule-entry-verification.txt`。不重复扩跑已关闭的导出矩阵或全后台，也不把root合组47/47与本轮28/28叠加为新总数。

## 源码版本

本轮结束验证起止5文件 SHA 相同，完整记录在 `intent-rule-entry-source-hashes.json`：

| 文件 | 最终 SHA256 |
| --- | --- |
| intent-rule-ui.mjs | 36a71d6076872b92ba365255d2cb18159fb830b1e766e439e3d0ca379f9b0154 |
| upgrade-operations-ui.mjs | 2b872340ad51e0cc40f59ed71f6fb3d2f9520b62c73e4153265e733f9f0cdfac |
| upgrade-shell.mjs | 14591b3076f6c90e3d7ee5d279498a4ea39e959ae053a535a7959ee29b3f4f96 |
| index.html | 9e5bcdae5688ca0788d1b1ecb8802dd4211d8ca37bb6b441ea304bc7f2375247 |
| app.mjs | 7354df0dfe3fad09313f67e21d05384af548ffa40849f127176670c52f632f44 |

独立测试 SHA256 `D42E74BB024284DB7F28DDC652D0FE7A53D0EBB5B1E1A5913A2AA3A42E37B0FC`。初审shell C97D7129 与最终14591B30不同，根窗口并行加入用量展示；本报告记录两轮真实版本，不把初审版本冒充最终冻结版本。冻结规则模块始终36A71D60。

## 证据边界

全部数据为合成资料、合成租户、内存应答和存储。DOM为轻量模型，执行实际磁盘模块和处理器，未操作IAB/原生窗口、读取原库、请求真实云/provider/平台、打包或发布。清理核验表示当前可见DOM移除且字段清空，不声称所有堆内存被安全擦除。主窗口另行负责隔离GUI及交付验收；不能据本审查声称用户认可、库存有效、模型100%准确、已发送、真实平台已可运营或跨机器资源部送达。
