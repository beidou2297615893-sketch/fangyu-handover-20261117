const cloudbase = require('@cloudbase/node-sdk');
const {createService} = require('./service.cjs');
const {serveSite} = require('./site.cjs');
const {releaseState} = require('./release.cjs');
const {listPage} = require('./shared_leads_v2.cjs');
const {SHARED_FEATURE_ENABLED} = require('./shared_feature.cjs');
const {productOptionsFromEnvironment} = require('./product_entitlements.cjs');
const {contactDeliveryOptionsFromEnvironment,ContactKmsConfigurationError} = require('./contact_delivery_config.cjs');
let service;
function createStore(db, companyId) {
  return {
    transaction: async callback => db.runTransaction(async transaction => {
      const ref = transaction.collection('fangyu_workspace_private').doc(companyId);
      const snapshot = await ref.get();
      const value = Array.isArray(snapshot.data) ? snapshot.data[0] : snapshot.data;
      const before = value?.state || null;
      const output = await callback(before, transaction);
      // Read-only requests should not rewrite the entire company document.
      // The service state is JSON-only, so this also detects housekeeping edits.
      if (JSON.stringify(output.state) !== JSON.stringify(before)) {
        await ref.set({state: output.state});
      }
      return output.result;
    }),
    listContactSummaries: async ({type, cursor, limit, query, employee, dateFrom, dateTo, status}) => {
      const documentType = type === 'customers' ? 'contact_customer' : 'contact_deal';
      const filters = {companyId, doc_type: documentType};
      if (cursor !== null) filters.sequence = db.command.lt(cursor);
      if (query) filters.search_text = db.RegExp({regexp: query.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), options: 'i'});
      if (type === 'customers') {
        if (employee) filters.last_employee = employee;
        if (dateFrom !== null || dateTo !== null) {
          if (dateFrom !== null && dateTo !== null) filters.last_contact_at = db.command.gte(dateFrom).and(db.command.lte(dateTo));
          else filters.last_contact_at = dateFrom !== null ? db.command.gte(dateFrom) : db.command.lte(dateTo);
        }
      } else if (status) filters.status = status;
      const collection = db.collection('fangyu_workspace_private');
      const countFilters = {...filters};
      delete countFilters.sequence;
      const [countResult, pageResult] = await Promise.all([
        collection.where(countFilters).count(),
        collection.where(filters).orderBy('sequence', 'desc').limit(limit + 1).get()
      ]);
      if (!Number.isSafeInteger(countResult?.total) || !Array.isArray(pageResult?.data)) throw new Error('联系账本查询结果无效');
      if (pageResult.data.some(row => row.companyId !== companyId || row.doc_type !== documentType ||
          !Number.isSafeInteger(row.sequence) || row.sequence < 0)) throw new Error('联系账本隔离检查失败');
      const rows = pageResult.data.slice(0, limit).map(({_id, companyId: _companyId, doc_type, search_text, sequence, ...row}) => ({...row, sequence}));
      return {rows, total: countResult.total, hasMore: pageResult.data.length > limit};
    },
    listSharedPage: async (cursor, revision, username, sessionDigest) => {
      const page = await listPage(db, companyId, cursor);
      const snapshot = await db.collection('fangyu_workspace_private').doc(companyId).get();
      const value = Array.isArray(snapshot.data) ? snapshot.data[0] : snapshot.data;
      const state = value?.state;
      if (state?.revision !== revision || state?.sharedLeadsMode !== 'v2' ||
          !state.users?.some(user => user.username === username && !user.disabled) ||
          !state.sessions?.some(session => session.username === username && session.digest === sessionDigest && session.expires > Math.floor(Date.now() / 1000))) return null;
      return page;
    }
  };
}
function getService() {
  if (service) return service;
  const environmentId = process.env.TCB_ENV;
  const companyId = process.env.COMPANY_ID;
  if (!environmentId || companyId !== 'fangyu-apartment-client') throw new Error('Deployment identity missing');
  // Read only deployment-owned configuration. Invalid explicit config never
  // falls back to the unconfigured pilot, and is checked before SDK activity.
  const productOptions=productOptionsFromEnvironment(process.env);
  let contactOptions;
  try { contactOptions=contactDeliveryOptionsFromEnvironment(process.env); }
  catch (error) {
    // Disable only new contact publish/reveal. Historical reads and withdrawal
    // must stay available when contact configuration needs repair.
    if (!(error instanceof ContactKmsConfigurationError) || !['CONTACT_KMS_CONFIG_INVALID','CONTACT_KMS_DEPENDENCY_UNAVAILABLE','CONTACT_KMS_CLIENT_UNAVAILABLE'].includes(error.code)) throw error;
    console.error('FANGYU_CONTACT_CONFIGURATION_ERROR',error.code);
    contactOptions={contactDeliveryProvider:null,contactRetentionSeconds:null};
  }
  const options = {env: environmentId};
  if (process.env.CLOUDBASE_APIKEY) options.accessKey = process.env.CLOUDBASE_APIKEY;
  const db = cloudbase.init(options).database();
  // Use the installed package entry (dist/commonjs), not stale SDK source files.
  const store = createStore(db, companyId);
  const release=releaseState();
  service = createService({store, environmentId, companyId,...productOptions,...contactOptions, initialAdmin: process.env.INITIAL_ADMIN_USERNAME, initialPassword: process.env.INITIAL_ADMIN_PASSWORD,
    releaseApproved: release.active, releaseVersion: release.version,
    pairingApproved: release.pairingAllowed, pairingVersion: release.pairingVersion,
    employeeReleaseEnabled:release.employeeReleaseEnabled,employeeReleaseVersion:release.employeeReleaseVersion,
    platformQaDeviceId: release.platformQaDeviceId,qaContinuousUntil:release.qaContinuousUntil,
    continuousReadonlyDeviceId:release.continuousReadonlyDeviceId,
    sharedFeatureEnabled: SHARED_FEATURE_ENABLED});
  return service;
}
exports.main = async event => {
  const headers = {'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff'};
  const reply = (statusCode, body) => ({statusCode, headers, body: JSON.stringify(body)});
  try {
    if (event.httpMethod === 'GET') return serveSite(event);
    if (event.httpMethod !== 'POST') return reply(405, {error: 'POST only'});
    const raw = event.isBase64Encoded ? Buffer.from(event.body || '', 'base64').toString('utf8') : event.body || '';
    if (typeof raw !== 'string' || Buffer.byteLength(raw) > 400000) return reply(413, {error: 'Request too large'});
    let payload;
    try { payload = JSON.parse(raw); } catch { return reply(400, {error: 'Invalid JSON'}); }
    const requestHeaders = Object.fromEntries(Object.entries(event.headers || {}).map(([k, v]) => [k.toLowerCase(), v]));
    const token = String(requestHeaders.authorization || '').replace(/^Bearer\s+/i, '');
    const result = await getService()(payload, token);
    return reply(result.status, result.data);
  } catch (error) {
    // SDK error messages can embed a failed private-document write, including an API key.
    // Keep fixed diagnostics only; never log raw payloads, state, or exception messages.
    console.error('FANGYU_SERVICE_ERROR', /^[A-Za-z0-9_.-]{1,80}$/.test(String(error.code || error.name || 'unknown')) ? String(error.code || error.name || 'unknown') : 'unknown');
    // Never return credentials or SDK connection details to the caller.
    return reply(503, {error: 'Workspace is not configured or temporarily unavailable'});
  }
};
exports.createStore = createStore;
