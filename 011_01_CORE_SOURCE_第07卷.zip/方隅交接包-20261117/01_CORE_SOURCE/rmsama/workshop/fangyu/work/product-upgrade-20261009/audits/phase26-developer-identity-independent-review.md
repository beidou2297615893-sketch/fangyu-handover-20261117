# Phase26 开发诊断 host 与原生纯预检独审

范围：只静读本项目候选代码及已保存材料；新增三方法只在项目临时合成数据库、成熟 proof、FakeProcess/recording kernel 中运行。未读取原 DATA、原 Cookie、DPAPI、OS 进程资料，未启动 Scheduler、真实子进程、浏览器、CLI、平台、公司或模型。本报告不声称实际原账号恢复完成。

## 当前候选结论

结论：诊断 host 的 setup-failure 退出确认缺口已由 D 窄修闭合，同三方法最终 3/3，通过时间 0.399 秒；纯预检和原因诊断脚本静读未见超出其固定只读用途的阻碍。这里不授予商业 natural 能力、采集权限或未来自动启动权，也不冒领 root 的原生执行证据。

初次独审的 D host finalmanifest SHA `129E6EDA0F97BDBCF334B4F50A97A95DEF2F61E096C0215299D1A6E7CBD29B07`，7 source 与 13 evidence 共 20/20 SHA 相符。原 `owned_job.py` SHA `52EFB424EEEC8D5CB58BEA560AF9512009F8E9BEAD2EC13B6415B58DBBA1B33E`，host `1DBFF39AAABB9106EDB5D56EDC2288A7A5055ACEB302D584B88B821E484D70D7`。这些是修复前候选证据，不预先验证后续变更。

## 源码边界

- `bootstrap.py:17` 只沿固定 native knownfolder、公司文件和 DeviceVault.read 读取。`service.py:32–46` 的 DeviceVault 构造不建目录，read 只解密读取，没有调用 write。导入 Service/Runner 类定义不等于构造或启动它们。
- `bootstrap.py:49–84` 使用 ro+immutable/query_only/只读 authorizer，首尾非空 WAL/journal 拒绝；actor/account 表身份及 body.id/tenant 一致，任务原值与 vault/activity/profile identity 纳入 fingerprint。paused/inflight=null 仅记历史未知，没有改为 false 或用它授予采集权限。
- `host.py:100–141` 在账号锁内独立核 profile 占用，启动前后重复 scope/runtime；poll 期间每两秒全核对，结果前再核 proof 和原 UID。scope/runtime/占用不确定只取消本 job，默认外部进程不被 kill。
- `host.py:154–180,184–209` 的正常已返回 process 退出未确认时保留账号锁、单 job 锁和 staging，直到 owned shutdown 确认。独立代表实际覆盖这一生命周期，未将 timeout 当成功清理。
- `profile_occupancy.py:72–159` 按可识别 browser/Python/fangyu 名称及完整 metadata/argv/profile 路径分类；current SID、创建时间、真实 job membership 和固定 WebView2 executable 分别核对。vacant 是该受支持进程集合在观察时点的结果，不是所有任意重命名程序的永久排他证明；账号锁只约束同一成熟锁协议的调用方。
- `runtime_identity.py:72–129` 区分 shim、实际 base 与 windowed/console 配对，捕获当前 WebView2 和关键源 SHA，并清掉 profile/调试覆盖。材料 hash 表明实际内容对应，不等于完整供应链签名、正式商业 natural 许可或当前云成员资格。
- `owned_job.py:90–119` 使用不继承 handle 的 kill-on-close job，先 suspended 创建、assign 成功后才 resume。输出只保留 opaque hash/固定 code；真实 browser 启动后平台请求未知、profile 可能写入，候选没有声称整个 DATA 零写或把 legacy risk 清除。

## 两份 root 纯预检脚本

`phase26_native_developer_preflight.py` 当前 SHA `8A595CBF565EDB940EDCCB3D818F4CC64412D19E0641026AF557963B7283232C`；`phase26_run_native_preflight_once.ps1` SHA `AA200AD7A93928A32ED2743C48734CD84138B7F3511160DD9B203800D2A6B862`。

Python 固定原 opaque account、native rmsama KnownFolder、无 browser/Core/Service 构造；只允许固定 CIM PowerShell Popen、禁止 socket.connect，DB mode=ro&immutable 加 query_only/authorizer。输出不含 token/UID/原命令行或客户正文，只在项目 audits 独占新结果文件记录。SQL trace 是附加观察；真正阻止写入的是 SQLite 只读连接与 authorizer，不能只靠 trace callback 异常当强制边界。

首静读发现三份 tracked 文件前后不等仍可 state=ready/exit0。root 已修：`tracked_original_files_unchanged is not True` 即 blocked/original_files_changed，不归因谁改动，不新增授权材料。当前代码静读确认该条件；未实际运行原生脚本或读取三文件。

PowerShell 只注册本次 GUID 新 task，以当前用户 Interactive/Limited，无 trigger，不覆盖旧 task；显式 start 的唯一副作用是这次原生预检以及其固定进程 metadata probe。不是无 OS 动作脚本。没有实际执行此候选。预检 ready 仅为本次 metadata/runtime/profile 快照可读且三 tracked 字节未变；不是未来 host 启动、商业许可、采集、风险解除或总目标完成证明。

## 三方法首轮证据

新增 `test_phase26_developer_identity_independent.py`，首日志 `phase26-developer-identity-independent-first.txt`：3 方法，2 通过、1 失败，0.346 s。

1. **真实机制 RED**：recording kernel 返回 assignment=false，子进程始终 suspended，第一次 WaitForSingleObject=WAIT_TIMEOUT；原 constructor 仍 CloseHandle(process=2/job=1)，没有核对退出。第二次 wait 若实施会返回已退出。断言记录 `[(close,2,false),(close,1,false)]`。这证明未确认清理即丢弃拥有记录，不证明浏览器已经执行。
2. 已返回 process 连续两次 close 未确认：结果 blocked/owned_exit_unconfirmed、锁与 staging 保留、重复 execute 拒 operation_busy；complete_owned_shutdown 确认后才释放并清理，原合成文件字节不变、旧风险不清。
3. 合成非空 WAL 直接拒且零 process；占用 callback 后改合成 vault owner，后续 fresh scope 拒且零 process，不还原外部修改、不泄漏原 UID。

修复由 D 独占源处理。本独审不改生产源、不修改 D 测试、旧 frozen 测试或 Phase25 证据。

## v2 关闭与同三组最终验证

当前 `owned_job.py` SHA `02E3938BA997AFF32DC08A99D7CB7CB32176E5BB738FE38428B22CC1903E3BDD`；host `2B591D60EAF3DAA5CAF055FF9494E50F79A717048BF48F5EE499DAAA6FC876F8`。

v2 使用 Windows10+ STARTUPINFOEX/JOB_LIST 在 CreateProcess 时原子加入本次 job，保持 suspended，核 membership 后才 resume；无旧 Create→Assign fallback。属性建立失败发生于创建前，零 child。创建后 setup 失败若清理未确认，异常携带实际拥有对象，host 不再把它当 process=None；账号锁和重入锁保留，job_created 与 browser 是否 resumed 分开。close 同时核 job descendants=0 和 process handle exit 后才丢弃句柄。

第 1 方法仅按实际新 kernel 入口适配：核 JOB_LIST 值、STARTUPINFOEX、suspended/extended flags 与 membership 顺序，原 unsafe_close 断言保留。属性失败零 child；resume 失败 + WAIT_TIMEOUT 时实际 owned object 保留 process/job，再实接 actual host，持锁与拒重入且 job_created=true/browser_possible=false/platform_requests_started=false；确认后才收束。第 2、3 方法维持原风险与边界，不增加方法数。实际 final log `phase26-developer-identity-independent-final.txt` 为 3/3、0.399 s，仅合成机制。

首版完整测试保存在 `backups/phase26-developer-identity-independent/1/test_phase26_developer_identity_independent.py`，SHA `B8E605FA7EC8D83FD5E4C66BEB51724D57C52916903043F46BAFD9339E87C462`；首 RED 日志与 first-source JSON 不覆盖。最终 source JSON 记录本次测试后七源实际 SHA，封存时再次相符；未虚构测试前未单独采集的 byte-hash 记录。首次旧 D manifest 和旧源码 SHA 保持历史身份，不声称其验证 v2。

实际 Windows Job/父进程崩溃/原生 Scheduler 上 job 嵌套及真实 installed runtime 生命周期仍不是这三方法的已验事项。根的 benign Job harness 或实际浏览器执行须另存本次原生证据，不沿用 recording kernel 声称 OS 成功。

## 追加 metadata-only 原因探针静审

`phase26_native_profile_reason.py` SHA `5307E03626CE0CF54F34842ED3C0A451262F181A1656EDDA50A4A5CE2DAF944B`；`phase26_run_native_profile_reason_once.ps1` SHA `D5F38639B5B3F708D6DFFBE08F931268163111ED5DAB73D2A27627E9D8A9963E`。

Python 唯一 Popen 为同一个固定 CIM 脚本，sqlite.connect/socket.connect 禁用；只 import 现有分类函数，不读账号表、vault 或 profile 内容。raw command/PID/路径/SID 留在内存，输出仅已限定 family、current/other_or_unknown、固定错误 code 的计数及两个 source SHA。PowerShell 沿相同 GUID/current-user Interactive Limited/no-trigger 路线，新增自己的唯一任务而不覆盖旧任务。

state=observed/exit0 仅说明诊断统计产生；不完整 snapshot 可能体现 snapshot_unavailable 计数，occupancy_authorized 始终 false。不能从可读分类或这一退出码推出 vacant，不能先猜原因便放宽现有 executable/owner/profile fence。C 只静读这两个脚本，没有新增测试或执行 CIM。

root 另报告其一次实际原生纯预检为 blocked/profile_unknown，三 tracked 字节未变、read_connections=2/write=0、无 browser；这些属于 root 单独保存的执行证据，本独审不重读原 DATA、不将其计为自己的三个方法，也不把预检 ready 或 blocked 等同原账号恢复成功。
