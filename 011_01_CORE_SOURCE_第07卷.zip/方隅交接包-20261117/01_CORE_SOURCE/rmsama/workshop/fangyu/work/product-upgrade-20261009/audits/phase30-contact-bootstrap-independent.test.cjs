'use strict';
const {test,after}=require('node:test'),assert=require('node:assert/strict');
const {
 fixture,boot,memory,readOnly,note,assertNoStoredValues,flushEvidence,withoutContact,
 config,sdkLoads,COMPANY,ENVIRONMENT,CLOUD,PUBLISH,REVEAL,WITHDRAW,STATUS
}=require('./phase30-contact-bootstrap-independent-fixture.cjs');
after(flushEvidence);
const metadata=out=>{
 assert.equal(out.status,200);const value=out.data.delivery;
 assert.equal(value.contract,'company_contact_delivery_v1');assert.equal(value.read_only,true);
 assert.equal(value.contact_values,null);assert.equal(value.plaintext_replayed,false);
 assert.equal(value.live_kms_verified,false);assert.equal(value.verified_cash_cents,null);assert.equal(value.verified_paid_cents,null);
 return value;
};
const rejectBeforeClaim=out=>{
 assert.equal(out.status,503);assert.equal(out.data.code,'CONTACT_DELIVERY_PROVIDER_NOT_CONFIGURED');
 assert.equal(out.data.mutation_committed,false);assert.equal(out.data.auto_retry,false);
 assert.ok(!Object.hasOwn(out.data,'delivery'));
};

test('independent real fixed-company bootstrap isolates invalid contact configuration and preserves authorized history/withdrawal/workspace',async()=>{
 const f=await fixture();assert.equal(f.running.init,1);
 assert.equal((await f.call(PUBLISH,f.publishBody)).status,200);assert.deepEqual(f.counts(),{Encrypt:1,Decrypt:0});
 const configured=metadata((await readOnly(f,()=>f.status(PUBLISH,f.publishBody.idempotency_key))).result);
 assert.equal(configured.provider_configured,true);assert.equal(configured.retention_configured,true);
 assert.equal(configured.original_execution_confirmed,true);assert.equal(configured.contact.expires_at-configured.contact.created_at,86400);
 const base=withoutContact(f.environment),variants=[
  {label:'partial_region_only',env:{...base,CONTACT_KMS_REGION:'ap-shanghai'},invalid:true},
  {label:'noncanonical_retention',env:{...f.environment,CONTACT_RETENTION_SECONDS:' 86400'},invalid:true},
  {label:'missing_contact_configuration',env:base,invalid:false}
 ];
 for(const variant of variants){
  let parserLoads=0;
  const options={loadSdk:()=>{parserLoads++;throw Error('parser must not construct/load SDK');}};
  const checked=config().checkContactDeliveryConfiguration(variant.env,options);
  assert.equal(checked.state,variant.invalid?'invalid':'not_configured');
  assert.equal(checked.live_kms_verified,false);assert.equal(checked.network_requested,false);
  if(variant.invalid)assert.throws(()=>config().contactDeliveryOptionsFromEnvironment(variant.env,options),
   error=>error instanceof config().ContactKmsConfigurationError&&error.code==='CONTACT_KMS_CONFIG_INVALID');
  else assert.deepEqual(config().contactDeliveryOptionsFromEnvironment(variant.env,options),{contactDeliveryProvider:null,contactRetentionSeconds:null});
  assert.equal(parserLoads,0);
  const loads=sdkLoads();f.restart(variant.env);
  const observation=await readOnly(f,async()=>{
   const status=await f.status(PUBLISH,f.publishBody.idempotency_key),old=metadata(status);
   assert.equal(old.original_execution_confirmed,true);assert.equal(old.provider_configured,false);assert.equal(old.retention_configured,false);
   assert.equal(old.permissions.can_publish,false);assert.equal(old.permissions.can_reveal,false);
   const me=await f.call('me',{},'resource');assert.equal(me.status,200);assert.equal(me.data.user.username,f.usernames.resource);
   rejectBeforeClaim(await f.call(PUBLISH,{...f.publishBody,idempotency_key:'phase30-disabled-new-publish'}));
   rejectBeforeClaim(await f.call(REVEAL,{...f.revealBody,idempotency_key:'phase30-disabled-new-reveal'},'resource'));
   const unauthorized=await f.call(WITHDRAW,{...f.revealBody,idempotency_key:'phase30-receiver-cannot-withdraw'},'resource');
   assert.equal(unauthorized.status,403);assert.equal(unauthorized.data.code,'CONTACT_DELIVERY_SOURCE_ONLY');
   return status;
  });
  assert.equal(f.running.init,1,'contact configuration failure must not block ordinary company DB access');
  assert.equal(sdkLoads(),loads,'invalid/missing actual bootstrap must not even load the official KMS package');
  assert.deepEqual(f.running.logs,variant.invalid?['FANGYU_CONTACT_CONFIGURATION_ERROR CONTACT_KMS_CONFIG_INVALID']:[]);
  note('configuration_'+variant.label,{...observation,result:undefined,configuration_state:checked.state,
   historical_original_confirmed:true,contact_writes_disabled:true,ordinary_me_available:true,receiver_withdraw_denied:true,official_sdk_load_delta:0});
 }
 // Explicitly invalid configuration must also preserve the authenticated
 // withdrawal, rather than proving that only the absent-configuration pilot can.
 const withdrawalLoads=sdkLoads();f.restart(variants[1].env);
 const count=f.counts(),withdrawn=await f.call(WITHDRAW,{...f.revealBody,idempotency_key:'phase30-source-authorized-withdraw'});
 assert.equal(withdrawn.status,200);assert.equal(withdrawn.data.delivery.provider_configured,false);
 assert.equal(withdrawn.data.delivery.current_consent_valid,false);assert.equal(withdrawn.data.delivery.contact_available,false);
 assert.equal(withdrawn.data.delivery.contact.revision,2);assert.deepEqual(f.counts(),count);
 assert.equal(sdkLoads(),withdrawalLoads);assert.deepEqual(f.running.logs,['FANGYU_CONTACT_CONFIGURATION_ERROR CONTACT_KMS_CONFIG_INVALID']);
 const after=await readOnly(f,()=>f.status(PUBLISH,f.publishBody.idempotency_key));
 assert.equal(metadata(after.result).original_execution_confirmed,true);assert.equal(after.result.data.delivery.contact.revoked_at!==null,true);
 note('provider_invalid_authorized_withdraw',{...after,result:undefined,current_consent_valid:false,original_publish_confirmed:true,
  official_sdk_load_delta:0,kms_delta:{Encrypt:0,Decrypt:0}});
 assertNoStoredValues(f,after.result,withdrawn);
 // Only the module's explicitly categorized class may be localized. A spoofed
 // code and an unsupported own error must fail the full bootstrap without DB init.
 for(const kind of ['foreign_error_same_code','own_error_unsupported_code']){
  const data=memory(),g=boot(f.environment,data,{configurationOverride:()=>{
   if(kind==='foreign_error_same_code'){const error=new Error('PHASE30_RAW_UNKNOWN_SECRET');error.code='CONTACT_KMS_CONFIG_INVALID';throw error;}
   throw new (config().ContactKmsConfigurationError)('UNEXPECTED');
  }});
  const before=data.snapshot(),out=await g.raw({environment_id:ENVIRONMENT,operation:'me'},f.tokens.source);
  assert.equal(out.status,503);assert.equal(g.init,0);assert.equal(data.snapshot(),before);
  assert.ok(g.logs.every(line=>line.startsWith('FANGYU_SERVICE_ERROR ')));
  assert.ok(!JSON.stringify({out,logs:g.logs}).includes('PHASE30_RAW_UNKNOWN_SECRET'));
  note(kind,{status:out.status,db_init:0,all_documents_unchanged:true,raw_error_redacted:true});
 }
});

test('independent true index and project official SDK enforce fixed scope and recheck consent after decrypt await',async()=>{
 const f=await fixture();
 const clean=await readOnly(f,async()=>{
  const wrongEnvironment=await f.raw({environment_id:'different-synthetic-env',operation:PUBLISH,...f.publishBody,
   expected_device_id:f.devices.source,channel_id:f.item.channel_id},f.tokens.source);
  assert.equal(wrongEnvironment.status,400);
  const browserKey=await f.call(PUBLISH,{...f.publishBody,company_id:'other-company',CONTACT_KMS_KEY_ID:'browser-override-key'});
  assert.equal(browserKey.status,400);assert.equal(browserKey.data.code,'CONTACT_DELIVERY_INVALID_INPUT');
  return {wrong_environment_status:wrongEnvironment.status,browser_override_status:browserKey.status};
 });note('before_claim_browser_scope_rejected',{...clean,result:undefined,...clean.result});
 assert.equal((await f.call(PUBLISH,f.publishBody)).status,200);
 // Once instantiated, the provider keeps the construction snapshot. Browser
 // actions and warm environment mutations cannot redirect this saved ciphertext.
 f.running.context.process.env.CONTACT_KMS_KEY_ID='later-synthetic-key';
 f.running.context.process.env.CONTACT_KMS_SECRET_KEY='later-synthetic-secret';
 f.running.context.process.env.CONTACT_RETENTION_SECONDS='1';
 const isolated=await readOnly(f,async()=>{
  for(const actor of ['source','outsider','admin']){
   const denied=await f.call(REVEAL,{...f.revealBody,idempotency_key:'phase30-'+actor+'-cannot-reveal'},actor);
   assert.equal(denied.status,403,'source/admin/non-recipient cannot authorize their own disclosure');
  }
  const wrongDevice=await f.call(REVEAL,{...f.revealBody,expected_device_id:f.devices.source},'resource');
  assert.equal(wrongDevice.status,403);assert.equal(wrongDevice.data.code,'CONTACT_DELIVERY_DEVICE_REQUIRED');
  const vault=[...f.data.docs()].find(([,row])=>row.ciphertext&&row.contact_version===f.publishBody.contact_version);
  assert.ok(vault);f.data.mutateDoc(vault[0],row=>({...row,companyId:'other-synthetic-company'}));
  const foreign=await f.call(REVEAL,f.revealBody,'resource');
  assert.equal(foreign.status,403);assert.equal(foreign.data.code,'CONTACT_DELIVERY_COMPANY_CONFLICT');
  f.data.mutateDoc(vault[0],()=>vault[1]);
  return {company_isolation_rejected:true,receiver_device_isolation_rejected:true,unauthorized_actors:3};
 });note('saved_company_actor_device_isolation',{...isolated,result:undefined,...isolated.result});
 const first=await f.call(REVEAL,f.revealBody,'resource');assert.equal(first.status,200);
 assert.deepEqual(first.data.delivery.contact_values,f.values);assert.equal(first.data.delivery.server_release_recorded,true);
 assert.equal(first.data.delivery.live_kms_verified,false);assert.equal(first.data.delivery.customer_contacted_verified,false);
 assert.deepEqual(f.counts(),{Encrypt:1,Decrypt:1});
 const expected=f.controller.requests[0].context;
 assert.equal(expected.company,COMPANY);assert.equal(expected.environment,ENVIRONMENT);
 assert.equal(expected.consent,f.publishBody.consent_reference);assert.equal(expected.recipient,'phase30-resources');
 assert.deepEqual(f.controller.requests[1].context,expected);
 const original=await readOnly(f,()=>f.status(REVEAL,f.revealBody.idempotency_key,'resource'));
 assert.equal(metadata(original.result).server_release_recorded,true);assertNoStoredValues(f,original.result);
 note('actual_bootstrap_one_publish_one_reveal',{...original,result:undefined,official_project_dependency:true,
  sdk_outside_all_transaction_callbacks:true,server_release_recorded:true,plaintext_recovery:false,warm_configuration_redirected:false});
 const g=await fixture();assert.equal((await g.call(PUBLISH,g.publishBody)).status,200);
 g.hook(async action=>{assert.equal(action,'Decrypt');const withdrawn=await g.handoffWithdraw();assert.equal(withdrawn.status,200);});
 const late=await g.call(REVEAL,g.revealBody,'resource');
 assert.equal(late.status,503);assert.equal(late.data.code,'CONTACT_DELIVERY_RESULT_UNKNOWN');assert.equal(late.data.mutation_committed,null);
 assert.ok(!Object.hasOwn(late.data,'delivery'),'withdrawn consent must prevent plaintext from reaching the caller');
 assert.deepEqual(g.counts(),{Encrypt:1,Decrypt:1});g.hook(null);g.restart();
 const stopped=await readOnly(g,()=>g.status(REVEAL,g.revealBody.idempotency_key,'resource'));
 const current=metadata(stopped.result);assert.equal(current.state,'unknown');assert.equal(current.server_release_recorded,false);
 assert.equal(current.current_consent_valid,false);assert.equal(current.current_channel_status,'withdrawn');assert.equal(current.permissions.can_reveal,false);
 assertNoStoredValues(g,late,stopped.result);
 note('real_index_withdraw_during_decrypt',{...stopped,result:undefined,state:'unknown',current_consent_valid:false,
  current_channel_status:'withdrawn',server_release_recorded:false,contact_values_returned:false,automatic_retry:false});
});

test('independent real bootstrap preserves unknown or recorded originals across KMS failure and post-commit reply loss without DML/plaintext recovery',async()=>{
 for(const action of [PUBLISH,REVEAL]){
  const f=await fixture();if(action===REVEAL)assert.equal((await f.call(PUBLISH,f.publishBody)).status,200);
  f.hook(()=>{throw Error('PHASE30_RAW_KMS_ERROR '+f.environment.CONTACT_KMS_SECRET_KEY);});
  const body=action===PUBLISH?f.publishBody:f.revealBody,actor=action===PUBLISH?'source':'resource';
  const failed=await f.call(action,body,actor);
  assert.equal(failed.status,503);assert.equal(failed.data.code,'CONTACT_DELIVERY_RESULT_UNKNOWN');
  assert.equal(failed.data.mutation_committed,null);assert.equal(failed.data.auto_retry,false);assert.ok(!Object.hasOwn(failed.data,'delivery'));
  assert.deepEqual(f.counts(),action===PUBLISH?{Encrypt:1,Decrypt:0}:{Encrypt:1,Decrypt:1});
  f.hook(null);f.restart();
  const recovered=await readOnly(f,async()=>{
   const read=await f.status(action,body.idempotency_key,actor),old=metadata(read);
   assert.equal(old.state,'unknown');assert.equal(old.original_execution_confirmed,null);assert.equal(old.server_release_recorded,false);
   const originalWrite=await f.call(action,body,actor);assert.equal(originalWrite.status,200);
   assert.equal(originalWrite.data.delivery.state,'unknown');assert.equal(originalWrite.data.delivery.contact_values,null);
   if(action===PUBLISH){
    assert.equal(old.channel_binding_state,'unknown');assert.equal(old.permissions.can_publish,false);
    const replacement=await f.call(PUBLISH,{...f.publishBody,idempotency_key:'phase30-no-new-key-to-repair-unknown'});
    assert.equal(replacement.status,409);assert.equal(replacement.data.code,'CONTACT_DELIVERY_CONTACT_ALREADY_BOUND');
   }else assert.equal(old.permissions.can_reveal,false);
   return read;
  });
  assertNoStoredValues(f,failed,recovered.result);
  assert.ok(!JSON.stringify({failed,logs:f.running.logs,recovered:recovered.result}).includes(f.environment.CONTACT_KMS_SECRET_KEY));
  note('kms_failure_'+(action===PUBLISH?'encrypt':'decrypt'),{...recovered,result:undefined,state:'unknown',
   original_execution_confirmed:null,raw_kms_error_redacted:true,automatic_retry:false,plaintext_recovery:false});
 }
 const f=await fixture();assert.equal((await f.call(PUBLISH,f.publishBody)).status,200);f.loseNextFinish();
 const lost=await f.call(REVEAL,f.revealBody,'resource');assert.equal(lost.status,503);
 assert.equal(lost.data.code,'CONTACT_DELIVERY_RESULT_UNKNOWN');assert.equal(lost.data.mutation_committed,null);
 assert.ok(!Object.hasOwn(lost.data,'delivery'));assert.deepEqual(f.counts(),{Encrypt:1,Decrypt:1});
 f.restart();
 const history=await readOnly(f,async()=>{
  const read=await f.status(REVEAL,f.revealBody.idempotency_key,'resource'),old=metadata(read);
  assert.equal(old.state,'recorded');assert.equal(old.original_execution_confirmed,true);assert.equal(old.server_release_recorded,true);
  const duplicate=await f.call(REVEAL,f.revealBody,'resource');assert.equal(duplicate.status,200);
  assert.equal(duplicate.data.delivery.contact_values,null);assert.equal(duplicate.data.delivery.plaintext_replayed,false);
  return read;
 });
 assertNoStoredValues(f,lost,history.result);
 assert.ok([...f.data.docs().values()].every(row=>row.companyId===COMPANY||row.state?.companyId===COMPANY));
 note('post_commit_reveal_reply_lost',{...history,result:undefined,state:'recorded',original_execution_confirmed:true,
  server_release_recorded:true,plaintext_recovery:false,official_sdk_encrypts:1,official_sdk_decrypts:1,automatic_retry:false});
 assert.ok(CLOUD.endsWith('cloud'+require('node:path').sep+'workspace'));
});
