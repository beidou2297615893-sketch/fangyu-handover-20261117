# Phase26 开发诊断 host v2：原子 Job 与清理确认

v2 沿同一开发诊断目标关闭独审发现的 suspended 子进程清理缺口。实际 Windows/原账号诊断仍未由 D 执行；旧公开恒拒、Core/Service/Runner、公司交付与风险逻辑不改。首版报告/manifest/七源已经逐文件 SHA 备份到 `work/product-upgrade-20261009/backups/phase26-owned-job-v2/1`，不抹掉首次独审 RED 或首版候选事实。

独审首次合成 recording kernel 使 assignment 失败，TerminateProcess 返回 True 而 WaitForSingleObject 返回 WAIT_TIMEOUT。v1 仍关闭 process/job 句柄，是实际的拥有边界缺口；并不表示原浏览器已执行。C 原 RED 与首测试/首来源快照各保留于它的独占证据。

## 最小完整修正

`owned_job.py` 在 Windows 10+ 使用 STARTUPINFOEX、InitializeProcThreadAttributeList、UpdateProcThreadAttribute(PROC_THREAD_ATTRIBUTE_JOB_LIST) 和 EXTENDED_STARTUPINFO_PRESENT：子进程创建时已经属于专属 KILL_ON_JOB_CLOSE Job，仍保持 CREATE_SUSPENDED。确认 IsProcessInJob 后才 ResumeThread；没有旧 Create→Assign 路线或 unsafe fallback。属性准备失败或 CreateProcess 失败不创建可运行 child。

Create 成功后的 membership/Resume 失败，close 同时要求 Job ActiveProcesses 为零和 process handle 已明确退出；单次 WAIT_TIMEOUT、已请求 terminate 或句柄还在都不作清理成功。若无法确认，OwnedSetupPending 携带真实 owned object，保留 process/job handles。host 因而不会把 process 当 None；它保留账户锁和非重入锁，并在 complete_owned_shutdown 确认后释放。线程句柄关闭不代表进程退出。实际父进程突然死亡时，原子创建已保证子树归属本次非继承 Job，避免旧的无 Job 创建窗口。

公开 key 不新增。job_created 与是否实际 resumed 分开：未恢复执行的 pending child 会显示 job_created=true，platform_browser_network_possible=false、platform_requests_started=false。真正 resume 后仍平台请求未知/null，不声称浏览器零网络或原账号恢复。

D 原三方法 v2 必要运行 **3/3，1.086s**，日志 `phase26-developer-identity-own-three-v2-first.txt`；没有重复计旧 1.054s/1.158s。第三方法在原生命周期代表中补了属性失败零 child、Resume 失败不丢 handles、实际 host pending 持锁/拒重入、确认后安全收束。仍是合成 metadata/真实 readonly SQLite 夹具、成熟 proof 和 recording kernel，不是真实 Job engine/OS/浏览器运行。

C 原独三方法 v2 **3/3，0.399s**，unsafe_close 原断言保留，只按新 atomic API 适配 kernel 入口。它独立核原失败的 pending 句柄与 host 续持锁，以及此前 WAL/晚 binding 零 spawn。C 管理自己的 test/log/review/manifest，本报告不冒领其源码或实际 OS 覆盖。

## 良性真实 Windows 代表：仅已准备

新 `diagnostics/developer-original-identity/benign_job_child.py` 只打印固定文本与睡眠 30 秒。`benign_job_probe.py --run` 仅允许当前项目固定 python/pythonw，使用隔离 -I -S child/parent，不导入 app、DATA、DPAPI、browser、CLI、网络或账号配置。它会在项目 tmp 下写 owned handover/握手，并把固定 sanitized receipt 写到本项目 audits；不把零账号数据操作说成全文件零写。

准备的两个 OS 事实：正常 child 真实 membership +关闭确认；固定 benign parent 写 creation-time handover，observer 打开同一 child handle 后握手，parent os._exit，observer 验该原 child handle 退出。无任意 PID kill，observer 只持本次 benign handles；失败清理仅终止本次 parent handle。D **只 compile 脚本，没有执行 --run、没有 Job 原生创建、OS scan 或原号读取**。root 审核后才运行一次并保存真实 receipt；当前不存在此成功 receipt，也不将脚本存在当通过。

固定入口文件：`C:/积木软件工坊/项目/方隅公寓客户版/work/product-upgrade-20261009/diagnostics/developer-original-identity/benign_job_probe.py`。文件夹：`C:/积木软件工坊/项目/方隅公寓客户版/work/product-upgrade-20261009/diagnostics/developer-original-identity`。运行由 root 负责，当前 D 不执行。

Microsoft 官方原子路线由 root 已只读核对：[创建时加入 Job](https://devblogs.microsoft.com/oldnewthing/20230209-00/?p=107812)、[UpdateProcThreadAttribute](https://learn.microsoft.com/en-us/windows/win32/api/processthreadsapi/nf-processthreadsapi-updateprocthreadattribute)。官方支持不代替本轮 native parent-death 代表。

root 已另运行一次原生纯预检，报告 metadata/runtime 读取成功且 profile_unknown；那次绑定的是首版源材料，不是此 v2 OS 生命周期或原号恢复证据。风险 review_required/历史 null 仍保留。这个 v2 不解决具体 OS metadata 缺项、不替 root 重试 native，不修改 profile/旧 Cookie/许可证，不发布、部署或打包。两秒 metadata/runtime/CIM 定频与始末 fences、300 秒观察窗口、未知清理继续持锁等首版边界保持。
