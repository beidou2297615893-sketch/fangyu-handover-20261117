"""Serialize actual disposable Core projections of the actual SDK replay."""
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import socket
import sys
from tempfile import TemporaryDirectory
from unittest.mock import patch

PROJECT = Path(__file__).resolve().parents[3]
sys.path[:0] = [str(PROJECT/'work/app/src'), str(PROJECT/'work/app/tests')]
from test_business_channel_candidates import candidate_bridge
from assistant.business_channel_candidates import ACTION
from assistant.business_reconciliation import LocalBusinessReconciliation
from assistant.product_receipts import ProductOperationReceipts

AUDITS = Path(__file__).resolve().parent
TEMP = PROJECT/'work/product-upgrade-20261009/tmp/business-channel-candidates'
TEMP.mkdir(parents=True, exist_ok=True)
document = json.loads((AUDITS/'business-channel-candidates-cloud-actual-fixture.json').read_text(encoding='utf-8'))
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest().upper()
patches = [patch.object(socket.socket, 'connect', side_effect=AssertionError('no transport')),
           patch('core.adapters.subprocess.Popen', side_effect=AssertionError('no platform')),
           patch.object(ProductOperationReceipts, 'begin', side_effect=AssertionError('no generic receipt'))]
for item in patches: item.start()
try:
    with TemporaryDirectory(dir=TEMP) as base:
        local = candidate_bridge(document, Path(base)/'source', document['first_envelope']['discovery'])
        service, actor, core = (local[key] for key in ('service', 'actor', 'core'))
        def cloud(user, action, body):
            assert action == 'acquisition_channel_candidates' and body['sources'] == document['sources']
            envelope = document['first_envelope'] if body['scan_offset'] == 0 else document['second_envelope']
            assert envelope['contract'] == 'fangyu-workspace-v1'
            assert envelope['company_id'] == document['company_id'] and envelope['environment_id'] == document['environment_id']
            return {'discovery': deepcopy(envelope['discovery'])}
        service.cloud_read = cloud
        try:
            first = service.execute(ACTION, local['request'], deepcopy(actor))
            next_request = {**local['request'], 'cursor': first['next_cursor']}
            second = service.execute(ACTION, next_request, deepcopy(actor))
            selected = {'handoff_id': local['request']['handoff_id'],
                        'channel_id': first['items'][0]['channel_id'], 'offset': 0, 'limit': 10}
            # This summary was read by the actual cloud fixture from the same
            # repository state as discovery. Do not substitute a phase8 ID.
            assert selected['channel_id'] == document['envelope']['summary']['channel']['channel_id']
            def detail_cloud(user, action, body):
                assert action == 'acquisition_reconciliation_detail'
                assert body == {key: selected[key] for key in ('channel_id', 'offset', 'limit')}
                return {'summary': deepcopy(document['envelope']['summary'])}
            detail = LocalBusinessReconciliation(core, service.tenant, service.owner, service.company,
                device_id=service.device_id, scope_guard=service.scope_guard,
                lead_access=service.lead_access, cloud_read=detail_cloud)
            selected_result = detail.execute('business_reconciliation_detail', selected, deepcopy(actor))
            output = {'request': local['request'], 'result': first,
                'next': {'request': next_request, 'result': second}, 'source_metadata': {
                    'synthetic_only': True, 'evidence_type': 'actual_core_journal_handoff_and_actual_sdk_service_serialized_bridge',
                    'live_cloud_or_platform_accessed': False,
                    'cloud_fixture_sha256': sha(AUDITS/'business-channel-candidates-cloud-actual-fixture.json'),
                    'local_module_sha256': sha(PROJECT/'work/app/src/assistant/business_channel_candidates.py'),
                    'frozen_detail_module_sha256': sha(PROJECT/'work/app/src/assistant/business_reconciliation.py'),
                    'cloud_source_hashes': document['source_hashes']},
                'selected_detail': {'request': selected, 'result': selected_result}}
        finally:
            core.close_continuous_scheduler(wait=True); core.adapters.close()
        empty = deepcopy(document); empty['events'] = []
        local = candidate_bridge(empty, Path(base)/'empty', {})
        try:
            output['no_local_sources'] = {'request': local['request'],
                'result': local['service'].execute(ACTION, local['request'], deepcopy(local['actor']))}
        finally:
            local['core'].close_continuous_scheduler(wait=True); local['core'].adapters.close()
    (AUDITS/'business-channel-candidates-local-actual-fixture.json').write_text(
        json.dumps(output, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    print(json.dumps({'first': len(first['items']), 'next': len(second['items']),
                      'no_local_sources': output['no_local_sources']['result']['cloud_read_requested']}))
finally:
    for item in reversed(patches): item.stop()
