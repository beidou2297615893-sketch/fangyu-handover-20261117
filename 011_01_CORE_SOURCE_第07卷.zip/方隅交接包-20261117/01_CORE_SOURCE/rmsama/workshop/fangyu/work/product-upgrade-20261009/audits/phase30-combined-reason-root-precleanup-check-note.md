# Root 清理前核对纠正

首次核对错误地要求 Task XML 必须显式包含 RunLevel=LeastPrivilege，因不满足而在写 receipt 或注销任务之前拒绝；没有二次 Native，也没有清理或修改任务。

实际逐项读取显示：唯一 Task Ready/lastResult=1，XML current SID/InteractiveToken、完整 action/argv/working directory、0 trigger、PT2M/IgnoreNew 全部一致；实际 CIM Principal.RunLevel 为 Limited，而 XML 的默认 RunLevel 字段被调度器省略。原代码将“字段缺失”误当“非 Limited”。

新清理脚本仍核实际 current SID、CIM Limited，并拒绝任何显式不同的 XML RunLevel；仅使用该唯一 GUID 的确切 TaskPath/TaskName，必须有 owned_exit/material/currentSID 证据才可删除。不是放宽原 runtime/classifier、重复运行 Native 或修改其他任务。
