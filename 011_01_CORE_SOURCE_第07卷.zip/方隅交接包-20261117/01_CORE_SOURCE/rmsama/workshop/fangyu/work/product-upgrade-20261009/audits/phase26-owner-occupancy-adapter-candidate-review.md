# Phase26：RAM owner 补证与冻结占用判定组合候选

候选已完成，仅新增 `diagnostics/native-owner-resolver/occupancy_adapter.py`、独占测试与本审核材料。3 个实际冻结组件组合方法首跑 **3/3，0.097s**；2 个新 Python 文件 AST 通过。未执行 Native/CIM/browser/原账号，未修改 Host 或旧 7/4/867B/resolver 候选 5 源。此结果不是账号恢复、profile 当前空闲或真实缺 WMI 场景已经跑通。

本阶段按目标评估可用 Skill/插件；直接复用已审 Windows TokenUser 查询与项目成熟 classify，比新增外部依赖或登录工具更适合。没有新登录、费用、网络调用或第三方安全算法。

## 精确内部接口

`NativeOwnerOccupancyAdapter(resolver=None).classify(profile, *, snapshot_provider, current_sid_provider, owned=None, expected_browser=None, trusted_python=None)`。

默认 resolver 是固定冻结 `NativeOwnerResolver`。两个 provider 都必须来自后续可信诊断程序的固定 CIM 与实际当前 TokenUser getter，不能由 HTTP body 或旧 receipt 提供。构造不调用 Native；模块只读并编译固定两源，按完整 SHA 锁定实际 frozen classify 与 resolver；调用前后再次核内容。当前仍是独立候选，没有任何服务端/Host 接线。

公共返回精确为 `contract/state/reason/fingerprint/owner_evidence`，contract 是 `native_owner_occupancy_evidence_v1`。state 沿用 `vacant/occupied/unknown`；它是本次两个输入快照的分类结果，不是账号授权。`owner_evidence` 只有 `source/token_user_rows_verified/complete_snapshots_checked/token_user_evidence_stable/raw_metadata_saved`；source 为 `wmi_only/wmi_and_token_user/incomplete`。没有原 PID、created、SID、命令行、路径、句柄、令牌或 raw snapshot。

未走完两次补证核对时 source 是 incomplete、稳定值 null；first classification 已 occupied/unknown 时直接保留阻断，不允许第二页放宽。只有首末核对完成才统计全部已补证行；即使 owner 证据稳定，末次 profile/Job 分类仍可 unknown，不能用 owner 摘要解除其阻断。

## 唯一补证范围与保留门禁

每次快照必须完整、结构白名单有效、PID 唯一，原 parent/created 字段类型与范围正确，owner 必须是有效 SID 或 None。第一快照复制后，只对 **owner_sid 是 None** 的行调用固定 resolver。只有 native `verified/current/creation/running_before/running_after/handles_closed` 全真、正确合同与 64hex 摘要才能在本轮 RAM 派生副本补为实际当前 SID。

原 WMI snapshot 不覆盖、不写文件。owner 来源通过独立 owner_evidence 表示 TokenUser；不能把派生值宣称 WMI 查询成功。有效 WMI 不会调用补证、不覆盖；resolver 验证到其他用户时保留 unknown，不伪填当前或其他 SID。TokenUser 是令牌关联用户，不是对象/DACL owner、平台 UID 或账号登录证明。

派生副本交给**实际冻结 classify**继续执行 exe basename/argv0、profile 参数、默认 profile 政策、父链、原创建时间 Job membership 和选定 WebView runtime 门禁。没有 PID/family 豁免；同当前 SID 的外部匹配浏览器仍 occupied；Job 回调 None 仍 unknown；缺用于 profile 继承的 parent 不猜 profile。

最后再次取完整快照并复读真实当前 SID，核对首批实际补证的原 PID-created/parent/name/exe/argv。行消失、PID 复用/创建时间变、父关系或命令变、owner 变、最后 native 查询失败、释放未确认或 native 摘要不一致，均 unknown，不能把消失行当成 vacant。末次新出现 owner 缺口不临时单次补成 ready，要求新完整调用再评估。

末次有相同当前 SID 的有效 WMI 时，也继续对首批补证原行复查 native TokenUser。所有 RAM 证据只在本调用内，finally 不留共享表或跨调用 cache。最后源内容与当前 SID 再核；公开 fingerprint 合入末次 classify 摘要及本轮补证摘要，不作为下次授权令牌。

整机行数、所有行的 fingerprint 不要求完全不变；最后已知无关 profile 行增加可以正常分类。但末次完整清单仍全部交给 classify，任何相关行未知都不得成为 vacant。

## 三个有意义的组合方法

`audits/test_phase26_owner_occupancy_adapter.py` 使用真实冻结 classify/NativeOwnerResolver、复用既有 recording native API。Windows argv 是预定义 RAM fixture；真实 canonical/profile 检查运行在项目 tmp 下唯一合成目录。Popen、run/CIM、socket connect、SQLite connect、真实 native DLL/argv API 均被禁止。没有真实 DPAPI 或账号来源。

1. None owner 补证得到 vacant 仍保留原 WMI snapshot 和 TokenUser provenance；最后 WMI 恢复可读仍要复查同原 native 行；有效 WMI 零补证；其他 native SID 不变当前用户。
2. 原 parent/created 缺口与重复 PID 零 native 查询；Job unknown、外部匹配 browser、继承 parent 缺失、argv0 错配、selected WebView runtime 错配与 default-profile policy unknown 都保持原阻断。
3. 补证行消失/创建时间/parent/argv 变化、新 owner 缺口、最后 token 查询失败、当前 SID 晚变保持 unknown；已知无关 profile 新增不被误判成选定 child 身份变化。

首次3/3日志保留，源码随后只做静态核验和归档，无施工 RED，不虚构 RED→GREEN。此3是新组合方法，旧 resolver3没有重跑，不重复计入。合成 recording APIs 不等于 Windows 内部 token 故障或真实 WMI 缺失已经重现。

## 冻结与未验证事项

adapter SHA256：`CD1A8C1F2E96D9C3668CCC702A1226562369E5596CCAE8FEAF444BEACD9424DE`。

测试 SHA256：`EEBF5A747A668645EF215FE94CB3F98EF92ED23C0667830973729D3A95CF19BA`。

原候选 5 源、10 证据和旧 13 源 + private_evaluation 均按原 freeze 核对一致；本次不重复扫描 runtime、许可、原业务库或账号。实际02677 TokenUser 代表仍只证明固定良性 child 路线，其 WMI 当时可用，不补成本轮真实故障测试。

下一步先由 root/C 独立审阅候选与最多必要反例，再决定是否用全新独立良性场景验证组合。没有 Host 接线、Native dispatch 或原账号重试。未来 provider 必须严格使用当前已审 fixed CIM/current TokenUser 与原 scope/runtime/账号锁门禁，不能把调用方构造的 snapshot 当真实 OS 来源。

候选源码目录：`C:/积木软件工坊/项目/方隅公寓客户版/work/product-upgrade-20261009/diagnostics/native-owner-resolver`。

审核文件目录：`C:/积木软件工坊/项目/方隅公寓客户版/work/product-upgrade-20261009/audits`。
