# Phase26 组合 owner 补证良性代表候选

结论：仅新增三个固定执行源，已准备、静态解析并冻结，尚未执行 Native、CIM 或睡眠子进程。可以交 root/C 做执行前源审；本报告不是实际组合路径通过、真实 WMI 故障、原 profile 空闲或原账号恢复证明。

## 固定来源与范围

项目：`C:/积木软件工坊/项目/方隅公寓客户版`。本轮最小能力判断是复用既有固定 CIM、原生 TokenUser、atomic Job、RAM adapter 和 frozen classify；继续新建启动框架、浏览器或测试矩阵没有增益，未调用与此工程机制无关的营销/设计技能。

仅三个新执行源：

| 文件 | SHA256 |
|---|---|
| `phase26_native_combined_owner_occupancy_probe.py` | `7B5CA2F7B3583C0383F518CA4E4B882BE647157DDC9644FBBAFBC75801930B01` |
| `diagnostics/native-owner-resolver/combined_sleep_child.py` | `8F3AC080D06FA41D82589AE0C4D176C709BCBA6D4A7ECC9C8FFB0EC0411D3E1C` |
| `phase26_run_native_combined_owner_once.ps1` | `B44176F81EFD929C55BA911411C13F5D50C29BE5559DA5A4DD8AABF462D5E47F` |

精确 pin 已独审候选 `occupancy_adapter.py` **CD1A8C1F…**、`owner_resolver.py` **9770E572…**、实际 frozen `profile_occupancy.py` **FF750FDF…**、固定 CIM wrapper **867BA28D…**、现 TokenUser getter 来源 **C7081FCF…**，以及旧七个诊断组件。父程序导入前核这些内容 SHA，执行内首尾重核；默认 `NativeOwnerOccupancyAdapter()` 使用真实 native resolver，未注入 recording APIs。`TrustedCurrentPython` 特意取自 adapter 的 `FROZEN` 模块，保留实际 class identity 门禁。

旧十三来源、resolver 五来源/测试、adapter 和旧实测/独审资料合计 26 项 SHA 均匹配冻结值，见 `phase26-combined-owner-occupancy-preserved-hashes.json`。没有修改旧 7/4/867B、resolver/adapter、Host 接线、原账号或任何生产业务源。C 独审 2 组合方法 GREEN 0.048s（报告 **634EE3B7…**、manifest **7CE57E27…**）是既有 RAM/recording APIs 证据；本轮没有将它算成默认真实 CIM/TokenUser/Job 的执行成功，也没有重跑它或 adapter 原 3 方法。

## 单一路线

调度父程序只接受一个 32 位小写 hex run GUID；结果或 immutable attempt 任一已存在即拒绝重复。父程序固定本项目 `pythonw.exe` shim 与真实 base/cfg/current runtime materials；捕获的完整 runtime material 仅留 RAM，对外记录 fingerprint。child 固定 `-I -S -B`、固定源码及本项目唯一 synthetic profile 标记，仅 `import time; time.sleep(90)`，不读取 profile，隔离 user/site startup。子进程经已审 atomic JOB_LIST 创建、核 membership 后 Resume；不得改用 Popen 或无 Job fallback。

两个 provider 都运行同一固定 System32 PowerShell + 同一已冻 CIM 脚本，完整收集其定义范围内的 Python/browser/fangyu 相关行和默认 profile 事实。它不是全 Windows 进程清单。所有 row 保留，唯一 PID、原 parent/creation、非空 exe/argv/name、current SID、source/runtime 都要有效。子进程必须恰好一行、当前仍运行、parent 精确为本次父进程、原 WMI owner 是本次实际 primary TokenUser SID，且 held Job membership/原创建时间核对为 True。父行也必须存在，owner/current、创建顺序、固定 exe/argv 和本次 run 参数均严格核对。任何缺 parent、创建时间、SID、Job 或固定 runtime/argv，不以 name/PID 白名单放过。

只有此已准入子进程的一份 deep-copy row 的 `owner_sid` 被刻意设为 `None`。原 WMI snapshot 不修改，原 snapshot hash、原 owner=current 布尔、derived hash 和 redaction_count=1 分别记录，原 SID/PID/路径/命令行/handle 不保存。对其它 row 已有 owner 缺口，返回 `unredacted_owner_gap` 及安全计数；不借此演练查询或补齐其它进程 owner。其它有效 WMI owner 不覆盖。由此结果必须标 `deliberate_owner_missing_field_rehearsal=true` / `real_wmi_outage_proven=false`。

实际 frozen classify 在补证后首尾各执行。首轮 occupied/unknown 不读取第二页，也不被后续空页改成 vacant。要通过必须 `wmi_and_token_user`、恰好一行 native 补证、两次完整 snapshot、native evidence stable=True、最终 synthetic-profile classify=vacant。每次 resolver 内是同一个 HANDLE 的创建/运行/TokenUser/关闭核验；跨 poll 是新 HANDLE + 同 PID/native creation/SID evidence hash，而非连续持有同一 resolver HANDLE。

原 child/parent/canonical exe/argv/SID 绑定 hash 须两页精确相同，最后再查 actual current SID、held child 的运行/Job/creation 和 runtime/source。首页没有前页比较，`child_binding_unchanged=null`；第二页才给比较布尔。无关 row 数量或整个 snapshot hash 变化只留观察值，不单独否决或授权；若新 row 的真实元数据/权限仍 unknown，完整 frozen classify 会保持 blocked。父程序最终还须确认 owned Job/process 退出，并复核来源材料和 SID，才保存 `representative_passed`。关闭不确认时保留对象并继续 owned shutdown，Scheduler 截止只可能留下未完 attempt，不编造完成回执。

## 调度及回执合同

准备的 PowerShell 源带 UTF-8 BOM，固定本项目 Pythonw/父程序，执行前和注册后立即再验父程序/child/adapter/resolver 的 literal SHA。只注册一个新 GUID 的 current Interactive/Limited、IgnoreNew、无 trigger、2 分钟上限任务，然后显式 Start 一次，不循环、不重试、不清理其它任务。若注册后来源改变，停止启动，仅该唯一任务留 root 审核/精确清理。root 仍须读取最后三个源码、静态回执及 manifest 后选择一次实际执行；D 没有调度、查询或清理任何任务。

任务：`\方隅工作台\` + `客户版Phase26组合Owner补证-<run_id>`。

固定回执名（目录均为本项目 `work/product-upgrade-20261009/audits`）：

- immutable attempt：`phase26-native-combined-owner-occupancy-attempt-<run_id>.json`；`execution_finished=false` 是创建时历史事实，不事后改写。
- final result：`phase26-native-combined-owner-occupancy-<run_id>.json`；root 应分别保存单次 dispatch / scheduled task receipt / exact owned cleanup，不能用 attempt 的旧 false 覆盖 final completion。
- result 仅安全 state/reason、布尔、counts、hashes 和 frozen classify 最小结果；无 raw PID/SID/argv/path/handles。

明确阻断原因包括 `snapshot_unavailable`、`child_unavailable`、`child_parent_unavailable`、`original_child_owner_unavailable`、`unredacted_owner_gap`、`owned_membership_unavailable`、`child_runtime_binding_changed`、`child_binding_changed`、`redaction_scope_unavailable`、`current_owner_changed`、`materials_changed/unconfirmed`、`classifier_not_vacant` 及 default adapter 的有限 owner evidence reason。samples 保存可观测安全 counts 和出错 stage code；失败不构成再次执行授权。

## 本轮验收与剩余事实

已实际执行的是新 parent/child 的 AST 解析、child 精确 sleep90 源检查、PowerShell Parser 的 0 errors 解析和 26 个旧资料内容 SHA 校验。没有 import/执行候选父/子程序，没有 CIM、Native、Scheduler、browser、原 DB/DPAPI 或平台请求，也没有新增测试方法镜像既有矩阵。三个源码此刻冻结，交 root 审核后不得未通知再改动。

未来一次实际代表还必须证实 default resolver + fixed providers + native Job 组合，而非只依靠独立组件各自通过。即使代表通过，也仅是故意删字段的同一良性睡眠 child 补证成立，不是实际 WMI outage、现存 Chrome owner 缺口解决、原 WebView startup 通过、原 profile vacant、账户 authentication、商业许可、真实获客或公司交付。Windows process TokenUser 也不等于进程对象/DACL owner。

`browser_started=false` / 原数据及业务 API 未调用是本候选代码范围的限制；`network_packet_capture_performed=false` 明确未测整个机器网络。此处没有小红书 URL、WebView2 创建设备、原 profile 或原账号，更不把其它正在运行窗口的网络归为本代表请求。
