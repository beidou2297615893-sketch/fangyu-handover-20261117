# Phase27 公司原号提交 UI 窄静审

结论：限定的新 checker、prepared 页提交区及 app action 路由未发现新增阻断。仅静读源码和实际合成 DTO，没有新增前端方法、复跑矩阵或执行 GUI。B 的前端测试与 root 后续 GUI 均需单独标注，不能算成本静审执行。

静审源为 upgrade-operations-ui.mjs **F5E05C2006B76F58F06DD9D47FBF3234A42606A620E5F8F1A96DE234C4852A95**、app.mjs **50DD120BA79785B9101BEF54F015A7359D5B4D23893865BD8583FC7C3E837844**；对应实际 fixture **6009EAD7AA50B6808BFAE9F3A6B3216640D4E916AB0BDF1146156A575D5C64A0**。这是新 source 的静审，不冒称旧 Phase25 或 C backend 独二已执行该前端。

- `checkedCompanySubmission`（107 行）精确限定 36 顶层字段、origin/current/attempt/operation 子结构、null 金额和全部未验证 false flag。result recorded 可保留 attempt unknown，后者代表本机原回执未保存；不会将其当第二次提交资格。history register draft 与原 submit submitted、公司当前 withdrawn/授权、历史 ACK 和独立接收 false 分开。GET/read_only 对应 mutation false 与本次 no_dispatch scope，不从缺回执推未执行。
- prepared 新入口（706 行）只显式调用 GET，首次打开原准备仍仅原 GET；没有自动 submit。只有 DTO not_attempted+服务端 eligible 为真且本 view 无 unknown hold 才显示未勾选 checkbox。确认后传四个固定原 handoff/origin/版本字段（724 行），没有客户端 arbitrary key、body 或联系人；云原 key 仍由后端派生。全局 perform busy 加 read generation 防重复触发，发送前清勾选并置 unknown hold。
- unknown 异常保留 `submissionUnconfirmed`。`loadSubmission`（749 行）仅在合法 DTO 含 attempt 时清此 view 标记；GET 又返回 not_attempted 不会解除已未知的 view 写锁。任何既有 attempt 的 DTO eligible=false，不显示第二 write；查询只能原 handoff。明确本次 pre mutation=false 的拒绝可撤销本次 view 标记，但不修改后台 attempt 或先前原号。新的准备/登记查询也不清 submit unknown 标记，不调用 generic recover、通用 slot 或墓碑。
- 当前 read/write 结果均先核 view、companyReadGeneration、原 origin/revision 再 paint；view.current（523–524 行）绑定外部 accept、epoch、actor/company/env/device generation 与原 handoff/id/revision。晚返回会丢弃，不补旧 DOM。reset/dispose 关闭旧 view并改变 operation epoch。成功 recorded 区位于历史登记/来源状态之后，最终顶部明确原提交已核对/当前撤回/独立接收待核对，history echo false 只作为仍保留的警示，不压盖已核对的提交事实。
- app 的 PRODUCT_ACTIONS 注册和 execute early preflight（386、394 行）涵盖两个新 action；cloud-only 明确拒绝后才进入本机 product_action，避免掉入通用 command_submit。最终身份/device generation fence 延续成熟路由；后台本次独二另已证明当前 matched/history true 不能替代 cloud receipt/权限 gate。

“本机尚未记录提交尝试”文案明确不证明公司过去未执行；提交平台身份引用也不等于手机/微信传递、平台送达、独立接收、成交或回款。不能把页面 eligible/matched 当永续授权：确认调用后端仍须 fresh scope、原来源、授权、权益和 cloud revision gate。

本次 0 新测试、0 GUI、0 原 DATA/网络/账号动作；没有修改生产或旧冻结材料，也不宣称整个产品完成。
