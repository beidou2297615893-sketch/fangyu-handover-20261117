# Phase22 原生元数据证据独立核对

结论：本次指定 run-id 的原生本机元数据读取完成，证据一致；当前平台、云绑定、许可及恢复成功仍未验证。只读取本项目已落盘 JSON、冻结代码与候选/独审文档，未读取原 DATA、数据库、活动原文件、设备绑定内容、Cookie 或凭据，未启动程序、重复诊断、执行 CLI/网络或测试。唯一新增文件为本报告。

## 本次唯一执行的对应关系

- 运行前预检于 2026-10-10 13:18:35.1828051+08:00 记录原助手匹配进程 0、候选文件已验 7、预检未打开原 DATA/更改进程。该时点的 CIM 范围结论不能证明之后绝无并发进程；helper 自身明确 instance_absence_verified_by_helper=false。
- GUID **9382ea0a483a4acb85e5bf110b0c7c14** 在 Scheduler 于 13:18:36 执行，LastTaskResult=0、清理前 Ready、Interactive/Limited、trigger_count=0。实际结果 observed_at 为 **2026-10-10 13:18:36.962986+08:00**，run-id 相同、state=read。
- Scheduler receipt 的 result_sha256 与实际 JSON 字节 SHA 一致。owned_task_removed=true，仅该 GUID 被清理，other_tasks_modified=false、read_retry_performed=false。初次 null trigger 数组 guard 拒绝在 mutation 之前；根只修精确清理 guard 后完成该任务 Unregister，没有重跑读取。
- 文件名、contract 和任务前缀沿用候选 Phase21，不把候选历史改写为已执行。实际执行属于 Phase22，phase22 scheduler receipt 与 process preflight 明确分列。candidate manifest 的 scheduler_executed/actual_original_database_read=false 是冻结前状态，不能用它覆盖本次执行事实，也不能修改 Phase21 冻结记录来补写结果。

## 结果只支持以下本机保存事实

| 项目 | 精确结果及边界 |
| --- | --- |
| 原账号 | account_found=true、platform=xiaohongshu、saved status=login_required；不是本次平台登录请求的返回状态 |
| 已保存员工 | saved_user_found=true、saved_user_cloud_bound=true、saved_user_disabled=false；仅保存记录，不能代替当前云会话/设备授权 |
| 来源身份字段 | cloud_owner_present/platform_uid_present=true；存在标志与本机摘要不是当前平台身份核验，不展示原 owner/UID |
| 原任务 | 同 ID **94884df9a02b462287f76a28dc6a7d2c** 的 tasks.status=paused、tasks.inflight=null、sequence_status=unknown、owner_matches_account=true；null 不能补成 false |
| 持续任务 | 同 ID continuous_tasks.status=blocked、inflight=false、sequence_status=unknown、owner_matches_account=null；与上行保存任务分开，未自动解除受阻或持续运行 |
| 活动摘要 | file_present=true、review_required、review_reason=not_authenticated、requests=12、risk_signals=2、activity_revision_bytes=4702 |
| 设备文件 | device_binding_file_present=true、device_binding_contents_verified=false；没有解密或核验设备绑定内容 |

成熟 summarize_activity 的诊断窗口为近30日、最多5000条，包含保存的历史风险；12 次请求不是本次新增平台请求数，2 个信号不是本轮平台异常次数，4702 是活动文件字节 revision，不是“风险清除后版本”。review_required/not_authenticated 不应被写成“今天又发生平台失败”或具体本次 HTTP461。用户最新“沿用现有账号、手机正常”仍保留，与本机保存 login_required/历史风险摘要无矛盾，且不能推导电脑会话已经恢复。

本次没有重新刷新历史 522 已分析/527 评论计数，也不把未查询的客户数量填成 0。application_bootstrapped=false、platform_session_verified=false、cloud_binding_verified=false，均与结果合同一致。没有采集、发送、人工清风险、云续期、许可批准或 recovery 成功证明。

## 只读机制与实际证明的界线

候选 7 文件当前 SHA 全部匹配，C 的独审保持原冻结结论。冻结 helper 只取固定 SQLite JSON 字段，mode=ro&immutable=1、query_only 与 SQL authorizer；非空 WAL/rollback journal 拒读，不经 Core/AssistantService/AppServer，也不启动后台。成熟 account_safety 文件读取仅做活动摘要；原生 KnownFolder/package/path 范围检查已由本次 read 结果走到完成。

但本次没有对实际原库/所有文件独立收集字节前后 SHA，也没有原生执行的 SQL trace/0DML 日志。实际“只读”证据由冻结代码机制与唯一执行回执构成，不能泛称“所有真实文件已独立核对前后完全未变”。合成3项曾做0DML/目录字节对照，仍只是合成证据。Scheduler 注册/启动/本次精确清理以及项目结果写入是明确副作用，不称整个动作0写。

本核对没有重跑三组合成测试，未更改 Phase21 的10项后端、276项前端或历史511计数。Phase21 总 manifest 的15份证据和3份源码当前 SHA 仍全部匹配。本阶段只增加一次元数据执行事实，不代表新正式 Server liveboot、旧安装版更新、真实平台跑通、获客、联系送达、公司接收或成交回款。

## 冻结输入 SHA

| 证据 | SHA256 |
| --- | --- |
| phase22-native-metadata-process-preflight.json | B12B95E4E60705DDCCD8F6E0BF2A00666BA1A3C2FC82CC5578088AAFAFB97D38 |
| phase21-native-original-account-metadata-9382ea0a483a4acb85e5bf110b0c7c14.json | 8EB2916CBB808E8922898A39A0CE09646E20E571C281D219188083C3B2D9ED85 |
| phase22-native-metadata-scheduler-receipt.json | 9C002FFEB36B396DF211D32C649D44873278C2AB51F7A51E456F5EECE466540E |
| phase21-native-original-account-metadata-candidate-hashes.json | E54C7A9762B49E9F33B17AF3F30A21BF20426EA3D5552116B81667C617CC8A52 |
| phase21-native-original-account-metadata-independent-review.md | 108A0371F47BD2FEA997E6F94E3768035BA003F9553838CE72C7AC9C170EA19C |

本次延用已实际读取的 RevOps 证据归属规则，只做最小本地元数据核验；没有新增工具、许可材料扫描或外部业务动作。
