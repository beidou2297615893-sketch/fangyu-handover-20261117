/* Executes disk controllers with actual Core/service DTOs, lightweight DOM, not GUI. */
'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),crypto=require('node:crypto'),cp=require('node:child_process');
const project=path.resolve(__dirname,'../../..'),folder=path.join(project,'work/app/src/web/workspace'),fixture=JSON.parse(fs.readFileSync(path.join(__dirname,'phase31-contact-delivery-ui-actual-fixture.json'),'utf8'));
const clone=v=>structuredClone(v),ok=result=>({status:'succeeded',result:clone(result)}),tick=()=>new Promise(r=>setImmediate(r));
class Element{
  constructor(tag){this.tagName=tag.toLowerCase();this.children=[];this.parentNode=null;this._text='';this.dataset={};this.attrs={};this.events=new Map();this.disabled=false;this.hidden=false;this.checked=false;this.value='';this.className='';this.classList={add(){},remove(){},toggle(){}};}
  set textContent(v){this.replaceChildren();this._text=String(v);}get textContent(){return this._text+this.children.map(n=>n.textContent).join('');}
  append(...nodes){for(const n of nodes){n.remove();n.parentNode=this;this.children.push(n);}}
  replaceChildren(...nodes){for(const n of this.children)n.parentNode=null;this.children=[];this._text='';this.append(...nodes);}
  remove(){if(this.parentNode)this.parentNode.children=this.parentNode.children.filter(n=>n!==this);this.parentNode=null;}
  setAttribute(k,v){this.attrs[k]=String(v);}removeAttribute(k){delete this.attrs[k];}
  addEventListener(k,fn){this.events.set(k,[...(this.events.get(k)||[]),fn]);}
  querySelectorAll(s){const choices=s.split(',').map(x=>x.trim()),match=n=>choices.some(c=>c.startsWith('.')?n.className.split(' ').includes(c.slice(1)):n.tagName===c);return this.children.flatMap(n=>[...(match(n)?[n]:[]),...n.querySelectorAll(s)]);}
  querySelector(s){return this.querySelectorAll(s)[0]||null;}focus(){}close(){this.open=false;}showModal(){this.open=true;}
  click(){if(!this.disabled)this.onclick?.();}change(){for(const fn of this.events.get('change')||[])fn();}
}
const deferred=()=>{let resolve,reject;const promise=new Promise((yes,no)=>{resolve=yes;reject=no;});return {promise,resolve,reject};};
async function wait(fn){for(let n=0;n<1000;n++){if(fn())return;await tick();}assert.fail('actual controller did not settle');}
const source=()=>({user:{id:'source-id',username:'source',tenant_id:'fixture-tenant',role:'operator',company_id:'fixture-company'},deviceId:'fixture-source-device',deviceGeneration:1,cloudEpoch:1,companyId:'fixture-company',environmentId:'fixture-env',cloudCompanyId:'fixture-company',cloudEnvironmentId:'fixture-env',endpoint:'https://fixture.example.invalid/workspace',localWorkspace:true});
const receiver=()=>({...source(),user:{...source().user,id:'resource-id',username:'resource'},deviceId:'fixture-resource-device'});
function moduleFor(doc){return vm.runInNewContext(fs.readFileSync(path.join(folder,'company-contact-delivery-ui.mjs'),'utf8').replace(/export /g,'')+'\n({createCompanyContactDeliveryUI,checkedCompanyContact,companyContactScope});',{document:doc,setInterval:(fn,ms)=>{const timer=setInterval(fn,ms);timer.unref();return timer;},clearInterval});}
function harness({mode='source',get,publish,reveal,withdraw}={}){
  const doc={createElement:tag=>new Element(tag),body:new Element('body')},api=moduleFor(doc),calls=[],dialogs=[];let ctx=mode==='source'?source():receiver(),latest=null;
  const createDialog=(title,{onClose}={})=>{latest?.close();const root=new Element('dialog'),status=new Element('p');status.className='upgrade-status';root.append(new Element('h2'),status);root.children[0].textContent=title;doc.body.append(root);const view={root,status,current:()=>latest===view};view.close=()=>{if(latest===view){latest=null;onClose?.();root.remove();}};latest=view;dialogs.push(view);return view;};
  const ui=api.createCompanyContactDeliveryUI({createDialog,getContext:()=>ctx,execute:async(action,data)=>{calls.push({action,data:clone(data)});
    if(action==='contact_read'){assert.equal(data.reveal,false);return ok(fixture.contact_metadata);}
    if(action==='company_contact_operation_get')return get?get(data):ok(fixture.cases[data.operation_action==='company_contact_withdraw'?'withdraw_ready':mode==='source'?'source_ready':'receiver_ready']);
    if(action==='company_contact_publish')return publish?publish(data):ok(fixture.cases.published);
    if(action==='company_contact_reveal')return reveal?reveal(data):ok(fixture.cases.released);
    if(action==='company_contact_withdraw')return withdraw?withdraw(data):ok(fixture.cases.withdrawn);
    assert.fail('no auto send/queue/model action '+action);
  }});
  return {doc,ui,api,calls,dialogs,options:clone(fixture[mode]),context:next=>ctx=next,close:()=>latest?.close(),button:text=>doc.body.querySelectorAll('button').find(n=>n.textContent===text),checkbox:()=>doc.body.querySelectorAll('input').find(n=>n.type==='checkbox'),text:()=>doc.body.textContent};
}
function confirm(h,label){const check=h.checkbox();assert.equal(check.checked,false);assert.equal(h.button(label).disabled,true);h.button(label).click();check.checked=true;check.change();h.button(label).click();}

test('actual publish/reveal/withdraw contracts require unchecked confirmation; unknown original and missing configuration never replay',async()=>{
  const h=harness();await h.ui.open(h.options);assert.deepEqual(h.calls.map(x=>x.action),['company_contact_operation_get','contact_read']);confirm(h,'确认发布联系方式');await wait(()=>h.text().includes('公司已登记联系方式发布'));
  assert.deepEqual(h.calls.find(x=>x.action==='company_contact_publish').data,fixture.requests.publish);assert.equal(h.button('确认发布联系方式'),undefined);h.ui.dispose();
  const w=harness();await w.ui.open(w.options);w.button('撤回公司交接客户授权').click();await wait(()=>w.button('确认撤回公司交接授权'));
  assert.match(w.text(),/阻断后续交付和查看，历史记录保留/);assert.match(w.text(),/过去缺回执仍不能证明未执行/);confirm(w,'确认撤回公司交接授权');await wait(()=>w.text().includes('公司已登记撤回客户交接授权'));
  assert.deepEqual(w.calls.find(x=>x.action==='company_contact_withdraw').data,fixture.requests.withdraw);w.ui.dispose();
  const gate=deferred(),u=harness({mode:'receiver',reveal:()=>gate.promise,get:()=>ok(fixture.cases.receiver_ready)});await u.ui.open(u.options);confirm(u,'确认一次查看');await wait(()=>u.calls.some(x=>x.action==='company_contact_reveal'));gate.reject(Error('synthetic lost'));
  await wait(()=>u.text().includes('原操作结果未确认'));assert.equal(u.button('核对原联系方式操作').disabled,false);u.button('核对原联系方式操作').click();await wait(()=>u.calls.filter(x=>x.action==='company_contact_operation_get').length===2);await tick();assert.equal(u.button('确认一次查看'),undefined);assert.equal(u.calls.filter(x=>x.action==='company_contact_reveal').length,1);u.ui.dispose();
  const n=harness({get:()=>ok(fixture.cases.provider_missing)});n.options.channelId=fixture.cases.provider_missing.channel_id;await n.ui.open(n.options);assert.equal(n.calls.length,1);assert.equal(n.button('确认发布联系方式'),undefined);assert.match(n.text(),/提供者未就绪/);n.ui.dispose();
  const api=harness().api;
  for(const [name,value]of Object.entries(fixture.cases)){const op=value.attempt?.operation_action||(value.withdrawal_receipt?'company_contact_withdraw':name.startsWith('receiver')||name.startsWith('release')?'company_contact_reveal':'company_contact_publish');api.checkedCompanyContact(clone(value),{action:value.action,operationAction:op,channelId:value.channel_id,actor:value.delivery?.authenticated_actor||value.withdrawal_receipt.authenticated_actor});}
  for(const mutate of [v=>v.extra='private',v=>v.delivery.live_kms_verified=true,v=>v.delivery.customer_contacted_verified=true,v=>v.current.channel_id='hc_'+'b'.repeat(64),v=>v.delivery.original_key='b'.repeat(64),v=>v.delivery.contact_values={phone:'[REDACTED:phone_cn]',wechat:'FixtureOnlyWx'}]){const v=clone(fixture.cases.release_recorded);mutate(v);assert.throws(()=>api.checkedCompanyContact(v,{action:'company_contact_operation_get',operationAction:'company_contact_reveal',channelId:fixture.receiver.channelId,actor:'resource'}));}
  for(const name of ['released','published'])for(const mutate of [v=>v.delivery.replayed=true,v=>v.delivery.cloud_kms_requested=false]){const v=clone(fixture.cases[name]);mutate(v);assert.throws(()=>api.checkedCompanyContact(v,{action:v.action,channelId:v.channel_id,actor:v.delivery.authenticated_actor}));}
});

test('actual first RAM release clears on close/mutual open/hidden scope and discards late epoch/device/company/channel/accept responses',async()=>{
  const h=harness({mode:'receiver'});await h.ui.open(h.options);confirm(h,'确认一次查看');await wait(()=>h.text().includes('电话：[REDACTED:phone_cn]'));assert.match(h.text(),/本次本人查看/);
  h.close();assert.doesNotMatch(h.text(),/13812345678|FixtureOnlyWx/);await h.ui.open(h.options);assert.doesNotMatch(h.text(),/13812345678/);h.ui.clearSensitive();h.ui.dispose();
  const m=harness({mode:'receiver'});await m.ui.open(m.options);confirm(m,'确认一次查看');await wait(()=>m.text().includes('[REDACTED:phone_cn]'));await m.ui.open(m.options);assert.doesNotMatch(m.text(),/13812345678/);m.ui.dispose();
  for(const kind of ['epoch','device','deviceGeneration','company','endpoint','actor','close','accept']){
    const gate=deferred(),x=harness({mode:'receiver',reveal:()=>gate.promise});let accept=true;await x.ui.open(x.options,{accept:()=>accept});confirm(x,'确认一次查看');await wait(()=>x.calls.some(c=>c.action==='company_contact_reveal'));
    const c=receiver();if(kind==='epoch')c.cloudEpoch++;if(kind==='device')c.deviceId='changed';if(kind==='deviceGeneration')c.deviceGeneration++;if(kind==='company')c.companyId='changed';if(kind==='endpoint')c.endpoint='changed';if(kind==='actor')c.user.username='other';if(kind==='close')x.close();else if(kind==='accept')accept=false;else x.context(c);
    const response=ok(fixture.cases.released);gate.resolve(response);await tick();await tick();assert.doesNotMatch(x.text(),/13812345678|FixtureOnlyWx/,kind);assert.equal(response.result.delivery.contact_values,null);assert.equal(x.calls.filter(c=>c.action==='company_contact_reveal').length,1);x.ui.dispose();
  }
  const r=harness({mode:'receiver',get:()=>ok(fixture.cases.release_lost_recorded)});r.options.channelId=fixture.cases.release_lost_recorded.channel_id;await r.ui.open(r.options);assert.match(r.text(),/原号核对不会再次返回明文/);assert.equal(r.button('确认一次查看'),undefined);assert.doesNotMatch(r.text(),/13812345678/);r.ui.dispose();
});

test('actual parent source and receiver routes close parent without inheriting invalid dialog current; no generic key or persistence',async()=>{
  const prepared=JSON.parse(fs.readFileSync(path.join(__dirname,'phase27-company-submission-actual-fixture.json'),'utf8')).cases.ready_lost_register_echo.preparation_get_result;
  const doc={createElement:tag=>new Element(tag),body:new Element('body')},idle=()=>({open(){},reset(){},dispose(){}}),entries=[];
  const contactFactory=({createDialog})=>({open:async(options,controls)=>{entries.push({options,controls});createDialog('合成联系人');assert.equal(controls.accept(),true);},clearSensitive(){},reset(){},dispose(){}});
  const operationsSource=fs.readFileSync(path.join(folder,'upgrade-operations-ui.mjs'),'utf8').replace(/^const \{[^\n]+\}=await import\([^\n]+\);\r?\n/gm,'').replace(/export /g,'');
  const api=vm.runInNewContext(operationsSource+'\n({createUpgradeOperations});',{document:doc,window:{},console,Date,crypto:crypto.webcrypto,TextEncoder,createIntentRuleUI:idle,createPlatformReadUI:idle,createIntentQualityUI:idle,createCompanyPolicyUI:idle,createBusinessReconciliationUI:idle,createSelfWorklistUI:idle,createSelfDailyEvidenceUI:idle,createCompanyHandoffReceiverUI:idle,createCompanyContactDeliveryUI:contactFactory,companyContactScope:moduleFor(doc).companyContactScope});
  const ctx=source(),record={id:prepared.current.handoff_id,revision:prepared.current.revision,contact_reference:fixture.source.contactReference,lead_id:fixture.source.leadId,recipient_id:fixture.source.recipientId,purpose:fixture.source.purpose};
  const operations=api.createUpgradeOperations({execute:async(action)=>{assert.equal(action,'company_handoff_preparation_get');return ok(prepared);},getContext:()=>ctx,shell:{hooks:{setAction(){}}},storage:{getItem(){return null;},setItem(){assert.fail('no generic writes');},removeItem(){assert.fail('no generic recovery');}}});
  await operations.openCompanyPreparation(record);doc.body.querySelectorAll('button').find(b=>b.textContent==='联系方式交付与授权撤回').click();await tick();assert.equal(entries.length,1);assert.equal(entries[0].options.channelId,prepared.origin.expected_cloud_channel_id);assert.equal(entries[0].options.contactReference,record.contact_reference);assert.equal(entries[0].options.mode,'source');assert.equal(doc.body.querySelectorAll('dialog').length,1);operations.dispose();
  // Execute the actual shared factory through the actual parent createDialog: its
  // clearSensitive call must not invalidate the newly opened dialog generation.
  const liveApi=vm.runInNewContext(operationsSource+'\n({createUpgradeOperations});',{document:doc,window:{},console,Date,crypto:crypto.webcrypto,TextEncoder,createIntentRuleUI:idle,createPlatformReadUI:idle,createIntentQualityUI:idle,createCompanyPolicyUI:idle,createBusinessReconciliationUI:idle,createSelfWorklistUI:idle,createSelfDailyEvidenceUI:idle,createCompanyHandoffReceiverUI:idle,...moduleFor(doc)}),liveCalls=[];
  const live=liveApi.createUpgradeOperations({execute:async(action,data)=>{liveCalls.push({action,data:clone(data)});if(action==='company_handoff_preparation_get')return ok(prepared);throw Error('isolated original channel is intentionally unreadable');},getContext:()=>ctx,shell:{hooks:{setAction(){}}},storage:{getItem(){return null;}}});
  await live.openCompanyPreparation(record);doc.body.querySelectorAll('button').find(b=>b.textContent==='联系方式交付与授权撤回').click();await wait(()=>doc.body.textContent.includes('原联系方式摘要暂不可读'));
  assert.deepEqual(liveCalls[1],{action:'company_contact_operation_get',data:{channel_id:prepared.origin.expected_cloud_channel_id,operation_action:'company_contact_publish'}});assert.equal(doc.body.querySelectorAll('dialog').length,1);live.dispose();
  const receiverCases=JSON.parse(fs.readFileSync(path.join(__dirname,'phase28-company-receiver-actual-fixture.json'),'utf8')).cases,receiverSource=fs.readFileSync(path.join(folder,'company-handoff-receiver-ui.mjs'),'utf8'),views=[],received=[],receiverContext=receiver();let parent=null;
  const receiverFactory=vm.runInNewContext(receiverSource.replace(/export /g,'')+'\ncreateCompanyHandoffReceiverUI;',{document:doc,Option:class extends Element{constructor(text,value){super('option');this.textContent=text;this.value=value;}}});
  const createDialog=(title,{onClose}={})=>{parent?.close();const root=new Element('dialog'),status=new Element('p');root.append(status);doc.body.append(root);const view={root,status,current:()=>parent===view,close(){if(parent===view){parent=null;onClose?.();root.remove();}}};parent=view;views.push(view);return view;};
  const inbox=receiverFactory({createDialog,getContext:()=>receiverContext,execute:async(action,data)=>ok(receiverCases[action==='company_handoff_received_list'?data.recipient_id?'received_list':'choose_authorized_recipient':'ready'].result),openContacts:async(options,controls)=>{received.push(options);createDialog('新的本人查看');assert.equal(controls.accept(),true,'must remain scoped after parent closes');}});
  await inbox.open();const choice=doc.body.querySelector('select');choice.value='resources';doc.body.querySelectorAll('button').find(b=>b.textContent==='读取所选部门').click();await wait(()=>doc.body.querySelectorAll('button').some(b=>b.textContent==='查看公司详情'));doc.body.querySelectorAll('button').find(b=>b.textContent==='查看公司详情').click();await wait(()=>doc.body.querySelectorAll('button').some(b=>b.textContent==='核对本人联系方式查看'));doc.body.querySelectorAll('button').find(b=>b.textContent==='核对本人联系方式查看').click();await tick();
  assert.equal(received.length,1);assert.deepEqual({...received[0]},{channelId:receiverCases.ready.result.item.channel_id,mode:'receiver',recipientId:'resources',purpose:receiverCases.ready.result.item.purpose});assert.equal(doc.body.querySelectorAll('dialog').length,1);inbox.dispose();parent?.close();
});

test('actual app routes all four actions to local product only and fences same-user epoch/config/device; actual asset entry serves new module',async()=>{
  const app=fs.readFileSync(path.join(folder,'app.mjs'),'utf8'),start=app.indexOf('const PRODUCT_ACTIONS=new Set('),end=app.indexOf('\nasync function requestTaskStop(',start);assert.ok(start>=0&&end>start);
  const actions=['company_contact_publish','company_contact_reveal','company_contact_withdraw','company_contact_operation_get'];
  for(const action of actions)for(const local of [true,false]){
    const calls=[],state={selected:'fixture-device',deviceGeneration:1},config={localWorkspace:local,companyId:'fixture-company',environmentId:'fixture-env'},cloud={user:source().user,epoch:1,companyId:'fixture-company',environmentId:'fixture-env',call:async(op,data)=>{calls.push({op,data});return {result:clone(fixture.cases.release_recorded)};}};
    const execute=vm.runInNewContext(app.slice(start,end)+'\nexecute;',{state,config,cloud,customerPrincipalSignature:JSON.stringify,submit(){assert.fail('must not queue contacts');}});
    if(local){assert.equal((await execute(action,{channel_id:fixture.source.channelId})).status,'succeeded');assert.equal(calls[0].op,'product_action');assert.equal(calls.length,1);}else{await assert.rejects(()=>execute(action,{}),e=>e.mutation_committed===false);assert.equal(calls.length,0);}
  }
  for(const kind of ['epoch','selected','config','transport']){
    const gate=deferred(),state={selected:'fixture-device',deviceGeneration:1},config={localWorkspace:true,companyId:'fixture-company',environmentId:'fixture-env'},cloud={user:source().user,epoch:1,companyId:'fixture-company',environmentId:'fixture-env',call:()=>gate.promise};
    const execute=vm.runInNewContext(app.slice(start,end)+'\nexecute;',{state,config,cloud,customerPrincipalSignature:JSON.stringify,submit(){assert.fail('must not queue');}}),pending=execute('company_contact_reveal',{});
    if(kind==='epoch')cloud.epoch++;if(kind==='selected')state.selected='other';if(kind==='config')config.environmentId='other';if(kind==='transport')cloud.environmentId='other';
    const result={result:clone(fixture.cases.released)};gate.resolve(result);await assert.rejects(()=>pending,e=>e.mutation_committed===null);assert.equal(result.result.delivery.contact_values,null);
  }
  assert.match(app,/cloudEpoch:cloud.epoch/);assert.match(app,/pageGeneration\+\+;upgradeOperations\?\.clearSensitiveContacts\(\)/);assert.match(app,/if\(document.hidden\)\{upgradeOperations\?\.clearSensitiveContacts\(\)/);
  const script="from assistant.employee_workspace import asset,WorkspaceError\nfrom types import SimpleNamespace\nfrom pathlib import Path\nb,t=asset(SimpleNamespace(),'company-contact-delivery-ui.mjs')\nassert b==Path('work/app/src/web/workspace/company-contact-delivery-ui.mjs').read_bytes()\nassert t.startswith('text/javascript')\ntry: asset(SimpleNamespace(),'../company-contact-delivery-ui.mjs')\nexcept WorkspaceError as e: assert e.status==404\nelse: raise AssertionError('path traversal')\nprint('actual asset exact bytes / traversal rejected')";
  const result=cp.spawnSync(path.join(project,'work/desktop-python/Scripts/python.exe'),['-B','-c',script],{cwd:project,encoding:'utf8',env:{...process.env,PYTHONIOENCODING:'utf-8',PYTHONPATH:'work/app/src;work/app/tests'}});assert.equal(result.status,0,result.stderr||result.stdout);assert.match(result.stdout,/actual asset exact bytes/);
});
