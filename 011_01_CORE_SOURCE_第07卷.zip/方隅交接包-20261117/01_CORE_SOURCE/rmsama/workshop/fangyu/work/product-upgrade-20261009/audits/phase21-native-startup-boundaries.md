# Phase21 原生入口只读边界

2026-10-10；仅查客户版项目的文档、代码与脚本。未启动程序、执行平台 CLI、访问网络，未读取真实数据库、Cookie、设备凭据或密钥。以下源码行为不等于已核验冻结 1.1.8-pilot.1 二进制的全部运行行为。

- **成熟 Limited 执行器**：`C:/积木软件工坊/项目/方隅公寓客户版/work/employee-update-20261009/run_native.ps1` 只接受该目录直属 `.py`，固定本项目 Python；使用当前用户 Interactive/Limited 的命名计划任务。第25–26行会注册并启动任务，存在调度器写入与脚本执行副作用，脚本是否纯读必须另查。
- **最小已有健康诊断**：同目录 `native_web_demo_proof.py` 只读取 `running.json` 元数据，通过 CIM 对齐实际 exe/启动标记，再 GET 本机 loopback `/health`，输出 `work/collection-resume-20261009/web-demo-native-proof.json`。它需要本实例已运行，不能作为启动器；不读取数据库/Cookie，不做账号登录或平台验证。健康响应只证明进程版本/标记，不能证明许可、平台登录或风险已解除。
- **旧真实重开脚本不能当纯读诊断**：同目录 `native_open_web_resume_demo.py` 会正常关闭旧进程、备份并核真实数据库、读取 Cookie 文件哈希、启动 demo，并备份/改写桌面快捷方式和报告。还要求原 running 标记/旧实例。当前无人运行的情况不能原样套用。
- **命名实例规则**：`work/product-upgrade-20261009/restart_synthetic_preview.ps1`、`restart_company_preparation_preview.ps1` 只允许 synthetic 标记、精确 dataDir/script，并停止/新建合成进程；不得移用真实账号。实际客户端用 `--data-dir` 与其中 `instance.lock`/`running.json` 区分实例。未查到成熟 `--instance` 参数；合成 owner 或文件夹名称不能证明真实账号归属。

当前仓库 `work/app/src/app.py:1208` 起会创建并启动 AssistantService、自动更新和运行标记。Core 初始化会把旧 sending 回复改 unknown；`assistant/service.py:333` 与 `:438` 会启动绑定会话轮询、Journal、AIWorker 和联系同步。runner 能回传旧结果、读取云命令并执行允许动作，AIWorker 也可能处理合格待分析记录。未见启动从保存 ready 任务自行调用 task_run，但启动不能宣称零云请求、零本机写或零模型调用。构造期 stale QR 清理只删除特定临时二维码文件，不是清风险日志或 Cookie。

原账号合法查询为 `app.py:705–737` 本人工作台门禁 → `assistant_account_safety` → `assistant/service.py` 已保存本人 user/tenant/account 与 cloud_owner 门禁 → `core/account_safety.py:summarize_activity`。前端 `web/workspace/platform-account.mjs:278` 的 `loadSafety` 只传已选原账号 ID；不调用 CLI/verify_identity。`assistant_account_signal`/`completeReview` 是另一条人工写动作。在线 safety 读取原先经可写 principal 产生 users/tenant 更新，B 已在本阶段单独修为已有 read_only principal；不因此自动清风险。离线缓存读取仍需此前可信绑定 owner。

历史真实 HTTP461 定位：`work/collection-resume-20261009/RESULT.md:24–30` 记载 2026-10-09 13:50:50 评论200、13:51:32 评论461、13:51:37 verification_required；`outputs/产品审计/持续采集真实验收_20260930.md:5–20` 为另一轮 2026-09-30 事件。用户最新“账号/手机正常”事实保留，这些历史材料不能判定当前手机异常，也不能证明当前电脑端已登录或可采集。当前无真实助手进程是 B/root 本阶段检查结果，C 未另行查询实际进程。
