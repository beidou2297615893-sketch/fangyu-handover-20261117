# Phase29 LOCAL 独立边界审核

当前结论：窄修后的重新冻结候选，经**原两个独立方法、原全部断言**最终一次复验，结果是 **2/2 通过**。首轮 2 个失败子场景已按原反例验证关闭，原 RED 日志、证据、旧候选和新测试快照全部保留。唯一新方法数仍为 2；本次局部边界通过不等于产品完成。

## 首轮两个反例

1. 本地私有 attempt 损坏：真实公司 REVEAL 已完成，但提交回执丢失，本机保持 `unknown`。将该 attempt 的 `contact_version` 与 `expected_contact_revision` 一起替换，并独立重算 `input_hash` 和 `record_hash`，纯 GET 仍接受并投影该伪原版本。原服务器联系版本可独立对应；自洽的未加密校验和不能证明原输入合法。这是本地私有 SQLite 记录损坏/篡改的恢复边界问题，**未证明普通用户能经公共 API 伪造数据库**，亦未出现第二次解密。相同方法的异 actor 输入已严格拒绝。
2. 最终 HTTP 投影前会话失效：真实 gateway 调用真实服务，服务已返回首次 REVEAL 的 RAM 联系值、尚未做 gateway 最终投影时，撤除当前 integrations session。gateway 没有拒绝，值被返回浏览器。相同方法中公司配置变化和当前设备变化已拒绝。服务器首次执行事实仍保留，本地行已 `recorded`；不能将它改写为未执行，也不应自动重发。

两方法还验证了恢复：所有纯 GET 前后，两 Core 的完整 SQLite dump SHA256 相等，SQL trace 无 DML/schema 写入，本机解密、opaque SDK-interface Encrypt/Decrypt 的增量均为 0。清洁原号在重建 helper/重启云 service 后仅返回 metadata，`unknown` 本地行保持原样；晚变后的已记录行也保持原样。`ProductOperationReceipts` 无新行，接收端完整 SQLite 未保存 phone/WeChat 值。

## 最终复验与窄修对应

- 真实公司 vault 的锚定联系版本与本地原号版本重新对应，REVEAL 原修订按被冻结的 vault 生命周期核对；自洽替换原版本/修订的 GET 现在严格拒绝，`mutation_committed=False`，不修本地行。
- 仅 LOCAL 联系网关使用 RAM 内完整当前会话/连接与 saved actor 快照，贯穿请求和最终 HTTP 投影；公司、会话、设备三种迟到变化都拒绝，浏览器均未收到联系值。已执行事实按原号保留。
- 原测试 SHA256 仍为 `BD8E51A68B61B90B17E19BC4510F4348423167A6703BC65CE4D0DB7ABB27C0A9`，未删改断言。未扩旧全套或新增第三方法。
- 最终日志：`Ran 2 tests in 4.326s`；`OK`；process exit 0；wrapper 耗时 4.599 秒。
- 最终六次纯 GET 的两 Core 完整 dump SHA256 均相等、trace 均 0 DML，本机/SDK-interface KMS 解密和加密均 0 增量；原 `unknown` 行仍 `unknown`，首个成功 release 后的已确认行仍 `recorded`。均为 metadata-only 原号恢复。
- 最终全日志 `phase29-local-contact-delivery-independent-final.txt` SHA256：`F8DF655A0724EE83EABB80E0C7D1F677739F7EDF10F665E56B17C64C189408D0`。
- 最终前后来源 `phase29-local-contact-delivery-independent-final-sources.json` SHA256：`D6863D4EA4CF3BF0D5D9BCAFBEA061664C84F745FAC89A5F1D38298222B2FE8E`，全部来源字节相等。
- 最终 bounded evidence `phase29-local-contact-delivery-independent-final-evidence.json` SHA256：`2216ABA82B7006BC219B6D0EF6A92E996C9C1B551CE59EFC2595BC7AD9136232`。
- 新候选三源及同一测试完整快照在 `phase29-local-contact-delivery-independent-before/2/`。最终实际依赖 13 项与 C 冻结清单分别核对，见本独立 `phase29-local-contact-delivery-independent-final-hashes.json`。

新三生产源 SHA256：

| 文件 | SHA256 |
| --- | --- |
| `company_contact_delivery.py` | `25AA9C861C60F913EFBB78020E8CF882C5AE6ECE5ABC42955F40A98FB9D667E9` |
| `company_contact_delivery_transport.py` | `9E12E545E383A2FC7C4CFEB06EA7AACCDA736DEBD1661CAAFF5B0CB202D82757` |
| `product_workspace.py` | `E5F1B94F52EE461E051AFC57F9D6324F7730B388F3AB38D535A92BE55C1B31EA` |

## 不变的执行证据

- 命令：`work/desktop-python/Scripts/python.exe -B audits/run-phase29-local-contact-delivery-independent.py first`
- unittest：`Ran 2 tests in 3.812s`；`FAILED (failures=2)`；process exit 1。
- `test_phase29_local_contact_delivery_independent.py` SHA256：`BD8E51A68B61B90B17E19BC4510F4348423167A6703BC65CE4D0DB7ABB27C0A9`。
- 首轮全日志：`phase29-local-contact-delivery-independent-first.txt`，SHA256 `E853004AAED763B1D389D422B98D20E33DE0C72359C5814D061626E3264D6F47`。
- 首轮来源前后 SHA：`phase29-local-contact-delivery-independent-first-sources.json`，SHA256 `D99464EC0D0050FDA972AFA44CABD358882FC80F05E437BE13B58447EAEA3383`，所有来源字节不变。
- 首轮 bounded evidence：`phase29-local-contact-delivery-independent-first-evidence.json`，SHA256 `6C2BB13CBE4F2529A19136F89202332AFDED8AF704CD08AAB462B90D4AA48214`。
- 原候选三生产源及新测试完整快照：`phase29-local-contact-delivery-independent-before/1/`，附 manifest。

## 范围与限制

仅本项目 LOCAL 候选和两个新独立方法。真实两 Core、真实 gateway/helper/transports、现有固定云 service/store 与官方 SDK 接口的 opaque RAM 请求替身参与执行；没有真实网络、真实 KMS、DPAPI 或第二实体机验证。旧 DB、账号、旧测试、其他任务、UI、打包及云 producer 均未改。此审核不代表真实联系已发送、商业效果、现金/分成或用户验收。

审计文件夹完整路径：`C:/积木软件工坊/项目/方隅公寓客户版/work/product-upgrade-20261009/audits`。

本报告完整路径：`C:/积木软件工坊/项目/方隅公寓客户版/work/product-upgrade-20261009/audits/phase29-local-contact-delivery-independent-review.md`。
