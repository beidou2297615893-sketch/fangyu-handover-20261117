"""Emit real-Core, synthetic-only read projections; never touch product DATA."""
from copy import deepcopy
import hashlib
import json
from pathlib import Path
from tempfile import TemporaryDirectory
from unittest.mock import patch
import socket

from test_self_worklist import actual_worklist, AUDITS, TEMP, PROJECT
from assistant.self_worklist import ACTION, LANES


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest().upper()


TEMP.mkdir(parents=True, exist_ok=True)
with TemporaryDirectory(dir=TEMP) as base:
    local = actual_worklist(base)
    core, actor, service = (local[key] for key in ('core','actor','service'))
    try:
        with (patch.object(socket.socket, 'connect', side_effect=AssertionError('network forbidden')),
              patch('core.adapters.subprocess.Popen', side_effect=AssertionError('platform forbidden')),
              patch.object(core.store, 'put', side_effect=AssertionError('pure read wrote data'))):
            with core.store.connect() as db: before = '\n'.join(db.iterdump())
            request = dict(lane='all', offset=0, limit=20)
            result = service.execute(ACTION, request, deepcopy(actor))
            cases = {}
            for lane in ('all', *LANES):
                body = dict(lane=lane, offset=0, limit=10)
                cases[lane] = dict(request=body, result=service.execute(ACTION, body, deepcopy(actor)))
            next_page = dict(lane='all', offset=10, limit=10)
            cases['all_next'] = dict(request=next_page, result=service.execute(ACTION, next_page, deepcopy(actor)))
            local['access_valid']['value'] = False
            cases['empty_current_scope'] = dict(request=request, result=service.execute(ACTION, request, deepcopy(actor)))
            with core.store.connect() as db: assert before == '\n'.join(db.iterdump())
        document = dict(request=request, result=result, cases=cases, source_metadata=dict(
            synthetic_only=True, fixture_type='actual_Core_Store_ContactJournal_AcquisitionOperations',
            real_platform_model_cloud_requests=0, original_database_used=False,
            fixture_people=12, fixture_comments=16, readonly_database_unchanged=True,
            labels_and_contact_outcomes='synthetic_saved_records_not_live_model_or_platform_success',
            actor=dict(id=actor['id'], username=actor['username'], tenant_id=actor['tenant_id'], role=actor['role']),
            company_id=local['company']['id'], device_id=local['device'],
            source_sha256={name: sha(PROJECT/'work/app'/name) for name in (
                'src/assistant/self_worklist.py','src/assistant/customer_list.py',
                'src/assistant/acquisition_operations.py','src/core/contact_journal.py',
                'src/core/review_queue.py','tests/test_self_worklist.py')}))
        path = AUDITS/'self-worklist-actual-fixture.json'
        path.write_text(json.dumps(document, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
        print(json.dumps({'path':str(path), 'sha256':sha(path), 'items':len(result['items']),
                          'counts':result['counts']}, ensure_ascii=False))
    finally:
        core.close_continuous_scheduler(wait=True); core.adapters.close()
