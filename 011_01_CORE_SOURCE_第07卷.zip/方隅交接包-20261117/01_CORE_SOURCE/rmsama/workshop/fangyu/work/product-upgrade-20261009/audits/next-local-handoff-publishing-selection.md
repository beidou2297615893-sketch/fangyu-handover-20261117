# 下一经营功能只读选型：本人授权交接显式送达公司

2026-10-10。此文只有一项候选，未实施。复用已实际读取的RevOps技能关于统一记录源、明确阶段与每次交接可追踪的规则；不套其示例时限和统计。目标仍是本人自营获客证明，再推进员工/门店模式。

## 选择及商业理由

下一最高收益缺口是R03/R07/R21：**把本人已经核验的本机交接显式提交现有公司账本，并按原操作编号恢复、读取独立资源部确认**。当前“查找对应公司交接”减少填hc编号，经营对账也已可读；它们都只读取公司已有渠道，不能创建交接、证明送达或证明资源部接收。本人可以继续人工转交，但软件中的待送达尚不足以形成逐条可核对的商业交接链。

这优先于新增价格档、CRM或全平台批量按钮。产品主流程应是来源/人工沟通→真实客户同意→本机核验→本人明确提交公司→公司待接收→另一位可信资源部主体决定→本人核对；公司ACK、订单、收款、分成支付仍分别保留证据，不能串成一个“成交成功”。另一agent独立研究“本人下一步待办清单”，与本方案不重叠。

## 当前真实路线与缺口证据

- 本机`acquisition_operations.py:648–665`核验后仅`status=ready_to_deliver`、`delivery_status=local_only`。公开投影明确`local_only=true/cross_machine_verified=false`；本机历史接收不能变成公司ACK。
- 云`handoff-ledger.cjs`已有9动作，使用成熟createStore事务/repos/session授权、CAS、payload哈希与审计链。register要求本人已归档不可变`device_report`事件、实际平台UID/comment与三字段同意；submit核当前同意/来源owner/重复；receipt要求不同来源人及可信接收部门映射。源码扫描未发现本机assistant/integrations调用这三写动作。
- 新候选helper明确`exact_local_handoff_mapping_not_integrated`。同source查出的多个channel只适合作为待核对候选，不能用第一个候选自动绑定本机handoff。
- 云已保存`operation:<hash(company,actor,action,key)>`与payload_hash/channel_id，正常同key重放会读回；目前只有handoff_list/detail两类读，没有按**原动作+原key**读取操作回执的窄动作。本机丢register响应时没有channel_id可安全读detail，不能通过随机换key/按名字重新register解决。
- 既有ContactJournal及联系归档路径、公司政策发布的本机opaque元数据生命周期可以参考；不要另建CRM、资金账本或复制旧AI未知账本。原AI恢复、平台候选归档本阶段已实施，不再把旧提案中的它们当新缺口。

## 最小候选契约（待root决定）

建议本机显式动作`company_handoff_submit {handoff_id,expected_revision,idempotency_key}`，及只读`company_handoff_sync_status {idempotency_key}`。名称仅提案。

前端不能提供source_event、owner、recipient真实性、contact、公司channel或已送达字段。服务端从本人当前可访问handoff、lead、当前同意、可信接收方/用途、不可变来源事件与完整Journal链派生。一次显式提交持久安全outbox：本机revision/源payload摘要/公司与actor/device/原register key/原submit key/当前stage/云channel与revision/收据摘要。不持久正文、UID明文副本、手机号、DPAPI明文或秘钥。

先核云已保存的来源事件完整绑定；没有归档就显示“来源未保存到公司”，不伪造sent，不把copied/external_reported当平台已发送。复用已有归档能力，不在此按钮内隐式平台访问。现有cloud register接受真实已保存7类事件的device_report，其事件类型证明范围仍单独显示。

最小云增量候选只读`acquisition_handoff_operation_status {operation_action,idempotency_key}`，原actor/company由session固定；复用已有operation文档，不造新资金账本。存在时返回原动作/key/payload摘要/原channel及安全当前投影，完整权限/当前同意/audit核对；原payload不公开。不存在、旧历史无回执、损坏或无权都不得宣称“未提交”。如日后要取消迟到请求，需同事务墓碑及写动作契约共改，不能靠只读absence推出安全重试。本切片可以先保守unknown hold而不引入新的取消体系。

本机stage建议prepared→register_submitted→registered→submit_submitted→company_submitted；任何未知保留原stage/key，重启只status，不自动重发。register确认但submit未开始时，由本人确认继续；已调用但响应丢失的submit只核原key。原actor/设备/本机revision或客户同意变化必须暂停结果应用，原已提交事实保留；客户撤回需要显式云撤回/传播并优先阻止再次交付。现有withdraw/dispute模块可复用，但不同stage跨事务竞争必须代表验证。

云第一版只传`platform:平台:UID`，本机DPAPI `contact:<uuid>`不跨机发送。按钮应说“提交平台线索到公司资源部”，不能声称“手机号已交付”。实际资源部receiver登录入口后复用receipt与已有详情；来源本人不能自ACK或把operatorOwners升admin。真实电话/微信跨机交付留待获授权CRM/vault或明确人工流程。

新关键结果须明确：`exact_local_handoff_mapping_verified`仅来自原register回执及完整本机来源绑定；`company_submission_confirmed`仅来自原submit回执；`historical_resource_receipt_recorded`、`current_consent_valid`分别取可信当前账本，不能互相替代。客户实收、独立财务核验、分成实付仍null，source与receipt操作人登记范围不能包装成外部独立证据。

## 最难小样与批准后退出条件

先用临时真实Core/ContactJournal→实际createService/createStore SDK→另一有权资源部session→原本机回读。一条路线必须先过：register或submit事务已commit但响应丢失，进程重启原key核对，provider/平台调用0、无重复channel/提交；随后客户撤回与资源部迟到ACK竞争，历史真实ACK保留但当前授权与再次交付false。

代表反例同时核源UID/正文hash/事件类型不匹配、同source多channel不自动映射、同名不同UID、跨tenant/actor/device、资源部映射撤权、换本机revision/同意、原key改body、缺云操作回执的旧历史、提交时权益过期。原记录不覆盖，订单仅同customer现存绑定，不造订单、不计算款项。

新增status单事务读取应只用doc/repos，先复用现有SDK3.18.3 MIT；不开展无收益新CRM检索/安装。当前云register/submit多阶段分别事务，需实际SDK统计每callback操作数≤100，外部调用不得进事务；离线耗时不能证明真实云30秒和大批吞吐。必要UI可只在现有交接详情增加1个显式提交入口与原号核对入口，opaque编号仍折叠，不扩一套页面。

## 实施与真实业务边界

root需决定是否批准新本机安全outbox/云status窄动作/接收入口，并协调原gateway、UI及cloud handoff共有文件。云上线、source归档实际许可、公司接收部门与独立员工、真实客户同意、第二实体电脑、CRM与财务材料均另需真实事实/授权；本提案不执行这些动作。无法观测软件外私下交易，防截流证据必须与合作政策/资源部制度一起使用。

读取快照：台账`69F6C85D65A6C2933850EFEC9BB39A2C903CAA623340165CA9C87D9014C2B1AA`；本机operations`AD9123D3373C484679A3CE34580149E25DCF8045DC1332CF6D166A6BCAAC0C2D`；云handoff`16A544D72C9DB6E0597E3016C4433216D3B7824E4980FB5638A45166BC04A305`；当前service`17D21D918D3E17559AA48E3F6DB342FC86DE112172B4DB8D9043E016AA0412A7`。这些只是本次选型来源，无新实施/测试完成含义。
