# Phase26 原账号本机开发诊断：最小静态路线

结论：用户已授权的原账号只读小样，可以复用当前固定 owned browser 与自然身份观察组件，实施一个独立本机开发诊断 host。它不构造 Core/Service/Runner，不需要伪造 online、商业 natural 许可或 QA grant。Phase24 public 恒 blocked 只是机制候选当前状态，不应成为长期占位；本计划没有执行原 DATA 读取、DPAPI、进程扫描、浏览器、扫码、网络或测试。

本次目的固定为 `developer_original_identity_observation`，公开输入仅 opaque account_id，不接受 data/profile/owner/company/path/license/guard。输出仅本次身份观察结果、是否匹配原 UID、原风险记录、锁与 profile 占用事实；不授予商业 natural 能力、采集能力或 current cloud membership，不修改账号 ready、任务状态、旧风险、CLI 会话或历史未知回执。

## 成熟最小接续

1. 在当前 Windows 本人 Limited 进程内，沿 Phase24 `NativeOriginalBrowserBootstrap.snapshot` 的 fixed knownfolder、固定公司候选文件、DPAPI saved binding、readonly SQLite actor/account/body/tenant/原 UID、固定原 profile 解析。固定公司文件只是本机诊断材料，不冒充运行中的商业 deployment。保留非空 WAL/journal 拒绝，避免 immutable 读取漏掉未落盘 metadata。
2. 为此诊断 purpose 单独读取 tasks/continuous_tasks 原值：paused 与 legacy inflight=null 可记录为历史未核实，不重写成 false、不恢复任务、不启动 Runner。明确 running/queued 或持有中的账户锁拒绝。所有原值进入 fingerprint，诊断中发生改变即取消，不通过诊断清历史 unknown。不得放宽原 Phase24 公开契约或平台执行 guard。
3. 持有 host 单 job 非重入锁及成熟 `account_execution_lock` 全生命周期，再取一次 metadata 与 OS profile 占用快照。固定 `login_helper_argv(..., natural_identity=True)`、`create_spec(bound_uid=原 UID)`，只调用 owned helper；app.py 的 helper dispatch 在 AppServer 构造前返回。使用当前源，不启动旧 launcher 的普通应用模式。
4. 自然观察复用 `NativeLoginObserver`、`LoginNaturalIdentity`、`verified_status`：owned WebView2 先 about:blank 绑定 CDP，随后页面自己产生 getMe；必须 job、当前文档、请求世代、candidate digest/MAC 与原 UID 一致。只读诊断不进入 BrowserLoginCoordinator 的会话提交、cloud claim、verify_identity 或风险清理。候选临时凭据仅留 owned staging，结束清理。
5. 循环检查 saved scope、代码/runtime/argv identity 与 profile 所有权；scope、UID、profile、风险/活动、任务或材料改变，写本 job 固定 cancel、等待/终止本 job，并在子进程真正退出后释放锁。不得杀无关进程或调用 begin_login 自动停止别人的任务。父进程突然退出的子进程生命周期要有 owned 退出机制，不能仅依赖父端文件锁。

## 账户锁与 profile 占用：两个独立事实

`core/adapters.py:206` 的锁跨进程排除同 account_dir 的参与者，但 `Adapters.execute:397` 仅包一次命令。`assistant/xhs_page_runtime.py:340–355` 成功后保留 transport 与 browser；`close_account:389 / begin_login:401` 才实际停止该 helper。直接 login 子入口本身也没有账户锁。因此锁可证明“此刻没有另一个遵守该锁的命令执行”，不能证明原 profile 没有空闲持久 helper、孤儿子进程或直接浏览器拥有者。

最小 OS 只读占用检查路线（当前还没有此完整 checker，需窄实现并代表验证）：

- 只取当前用户 SID、进程 PID/创建时间、父子关系、真实 executable 路径及必要 profile 参数。在内存解析固定 owned argv 的 `--profile-dir`，及 WebView2/Chromium 的 `--user-data-dir`；按 Windows 大小写规范和真实路径边界对应原 profile 及其内部 WebView2 数据目录。不能用账号文件夹短字符串 contains 判断。
- 遇到同原 profile 的任何已有拥有者，输出 `occupied`，不启动、不 kill、不删除 profile。相关浏览器/owned 进程 metadata 拒绝访问、参数不完整、路径重定向或 PID 创建时间无法核对时，输出 `unknown`，不能把扫描漏项当 vacant。其他账号的可辨认 profile 不作为本账号占用，不输出其材料。
- `vacant` 是本次 OS 快照事实，不能消除 legacy task unknown。持锁后、spawn 前再查；spawn 后只能容许本 job 的真实 process handle/创建时间和 WebView2 子树。owned native WebView2 的当前 `UserDataFolder`/browser PID 可以辅助核对所属 profile，具体绑定方式需在实际组件中验证；不把未核实的属性当已有保证。晚出现另一个 owner 只取消本 job。
- 进程命令行可能含私人字段，绝不落盘或返回原字符串；只输出 fixed occupancy 状态/理由与必要当前 job opaque 摘要。占用探针不打开 Cookie/凭据/浏览器正文。

现成 `xhs_page_window.py:659 diagnose_account` 已在独立 source 进程内持账户锁并用原 profile；但 `:590` 仅检查 bridge.ready 组件能力，不核原 UID，不能代替上述自然身份观察。它也会写组件诊断文件并加载真实网页，不是原 DATA 全零写/零网络入口。

## 当前材料 identity（实际静态读盘，非部署许可）

以下路径均位于本客户项目。实现时应固定实际选中的 executable/source/cwd/argv，不用 PATH、任意 Python 或调用方传入脚本。source/argv 摘要绑定这次诊断材料，不能凭摘要生成商业许可。

| 文件 | SHA256 |
|---|---|
| `work/desktop-python/Scripts/python.exe`（当前已用于合成验证的 venv shim，262144 bytes） | `DE13D8017F63CB63B0B5BFD2F25E69245C9196433A224856CA1ABDE1E24D0CB7` |
| `work/desktop-python/pyvenv.cfg` | `61A4476E74DEED2C0B8A5C0947944A2F2CF2A48C8C73D8E284B00500C4092F05` |
| `work/app/src/assistant/original_browser_identity_maintenance.py` | `ACD7DE84CF2432B9F48A2D5EE934E0D2F76BF956031ED38BD489026E880B640A` |
| `work/app/src/assistant/owned_helper_process.py` | `3C92C41E4DBF2908633AAEA73B14495CAA04009BFC47A6481209342F8D768A97` |
| `work/app/src/assistant/owned_helper_dispatch.py` | `8D6C32E0C9DA51D42AEF3A25820AA22FE21D1E8C82EABF3B60E5AC3DA9ADC119` |
| `work/app/src/assistant/browser_login_window.py` | `519D4F77BFEA03D1DCAE9B1F11340D210AEBB32DD4F79C61AE7808FDF73489D0` |
| `work/app/src/assistant/native_login_observer.py` | `8FDE85296E8B8427DA84FF80574565685AC7B4CEBCCCAEC4D9E8C049ADAF75D0` |
| `work/app/src/assistant/login_natural_proof.py` | `79DC95AF7A7646CDDE285DB4E721A166A9C782E31111CAFAA64F4C57E188A7BD` |
| `work/app/src/assistant/login_natural_identity.py` | `51EA19E6D96256B2FFAA18E142A1E89E6CD8173C3CC65B7F064542F548B60B54` |
| `work/app/src/owned_natural_reader.py` | `FC715994E8B242E7F5E7DF1F206695C92CD97F795929C8360D93D19DDEDA6FBF` |
| `work/app/src/core/adapters.py` | `EA25244AB52937E0CC7A5D8E694E1A14C36495D99192CB62C296907ABCD45E1E` |
| `work/app/src/assistant/xhs_page_runtime.py` | `126E27B98BF85762DBF47DDAF97789E9A332C5A9F40B308EF172E0477174A9EE` |
| `work/app/src/app.py` | `BF7979D1ADE0D5E6733ACE49347A81342D1971B8F4B3D3C6E060F2031FCB5741` |

当前仅静态哈希项目 shim 与 venv 配置，没有读取项目外 base interpreter、WebView2 runtime 或真实 native exe。shim hash 不等于完整解释器/runtime identity。实现准备实际启动前，应明确当前选中的真实 executable 及这些依赖版本/路径/摘要；若用 frozen exe，先核该 exe 确实包含对应 owned helper，不能把当前 Python source hash套到旧 seq5 exe。这是实际运行材料核对，不是新增许可 schema。

## 最少必要代表与诚实输出

先做三个合成代表，不扩大矩阵：①实际 readonly bootstrap 材料/body id+tenant 和 legacy null原值保留，零数据库/风险/任务写；②账户锁可取得但 profile owner 已存在或探针未知，仍0spawn，不 kill；③真实成熟 proof/argv配合 FakeProcess，晚 scope/profile owner/代码变化执行本 job cancel、等待退出、保留外部变更与旧 risk。合成 True callback、fake vacancy或 FakeProcess success不能冒充原账号可用；OS 探针本身的解析必须进入代表。

真实诊断若执行，会有网页自身网络、profile/临时 job/锁/outcome 的局部写入。不能照抄 Phase24 FakeProcess 的 `platform_requests_started:false`，不能说整个 DATA 零写。若需扫码，必须本人明确在该窗口完成；只证明这次观察到的原 UID，不清 461/review_required、不承诺平台已恢复采集。当前本计划仅静态路线，没有原账号读样、扫码、实屏或平台成功证据。
