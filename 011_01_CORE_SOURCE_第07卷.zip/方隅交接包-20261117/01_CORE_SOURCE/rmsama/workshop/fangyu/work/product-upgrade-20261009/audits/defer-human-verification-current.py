from pathlib import Path
import hashlib,json,re,uuid
project=Path('C:/积木软件工坊/项目/方隅公寓客户版');stage=project/'work/product-upgrade-20261009'
docs=[project/'outputs/产品升级/当前执行事实.md',project/'outputs/产品升级/本轮进度核查-来源恢复与人工交接.md',stage/'owner-package-independent-receipt-root-review/CURRENT.md']
changes=[]
for path in docs:
    raw=path.read_bytes();text=raw.decode('utf-8')
    replacements=[
        ('当前主线恢复：','当前主线恢复：小红书本人账号→搜索/评论来源→保存→明确意向分析→人工联系→客户自愿留资/撤回→可信资源部交接及独立接收。用户进一步明确真人验证晚些再进行，本轮不再要求扫码、找回原任务、人工身份或平台小样；前一找回登录状态请求已后置、不再待答。本轮完成代码和项目内隔离本地代表性验证，不启动真实平台/模型、变更现main/job或清risk/NULL。真账号阶段恢复后再按原机制核同原job物理收尾/UID/会话/风险；已有未知保留。单关键词用途仍pending，不在本轮授予或实际派发。'),
        ('三所属agent并行：','三所属agent并行：作者增量实现跨页高/超高已验证评级优先来源工作池（原全部来源兼容、最多50返回/200扫描、人工续页），独立核当前归档/attempt/cache/actor/account证明与稀疏分页不漏行，另窄审关键词→原搜索选择→评论保存出处。意向评级不代表当前联系/留资/交接授权，原业务权限/未知号与memo保持。成熟源复用、各自候选、Root独占Source和中心文档，代表性行为RED→GREEN后非作者必要审/备份合入；不重扫旧矩阵/库存/历史或为开工造bug。V10有限工程链不重跑。抖音/视频号随后、知乎历史、快手明示演示、B站微博不扩；暂不打包/部署/真实发送/发布/付费、5%暂停取消。')]
    for prefix,value in replacements:
        text,n=re.subn(re.escape(prefix)+r'[^\r\n]*',value,text,count=1)
        if n!=1:raise ValueError('Missing current paragraph')
    changes.append((path,raw,text.encode('utf-8')))
path=project/'outputs/产品升级/需求交付与证据台账.md';raw=path.read_bytes();text=raw.decode('utf-8')
rows={
'02':'|R02 自营先行/未来员工|本人XHS搜索/评论保存/分析/人工联系留资交接代码保持，Dy/Wx原功能保持|功能第一；真人验证后置，本轮不要求扫码/找回/身份/平台小样，先补跨页优先来源与本地行为验证；原未知job/风险保留，真实获客链仍未验。|',
'06':'|R06 进单/多账号|原UID/risk门禁与自有job收尾保持，旧操作占用及客户端进入/显示已由用户确认|真人验证延期，前一桌面找回状态请求不再待答/催问；未新发QR/清risk/NULL/复制Cookie，Computer Use停用。待真人阶段恢复再核本次job物理结束和UID。|'}
for number,value in rows.items():
    text,n=re.subn(r'(?m)^\|R'+number+r' [^\r\n]*',value,text,count=1)
    if n!=1:raise ValueError('Missing row')
changes.append((path,raw,text.encode('utf-8')))
backup=project/'backups/defer-human-verification-current'/uuid.uuid4().hex;backup.mkdir(parents=True);records=[]
for i,(path,old,new) in enumerate(changes):
    if path.read_bytes()!=old:raise ValueError('Central doc changed')
    saved=backup/(str(i)+'.bin');saved.write_bytes(old);path.write_bytes(new)
    records.append({'path':str(path),'backup':str(saved),'before':hashlib.sha256(old).hexdigest(),'after':hashlib.sha256(new).hexdigest()})
(stage/'audits/defer-human-verification-current.json').write_text(json.dumps(records,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'updated':len(records),'real_verification_deferred':True,'prior_human_request_pending':False}))
