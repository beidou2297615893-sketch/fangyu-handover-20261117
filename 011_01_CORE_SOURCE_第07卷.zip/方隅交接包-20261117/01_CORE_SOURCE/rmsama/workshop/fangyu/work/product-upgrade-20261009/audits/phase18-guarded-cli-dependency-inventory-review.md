# Phase18 固定 guarded CLI 实际依赖与版权材料盘点

结论：已取得固定运行产物的可追溯库存，可供正式许可审核和运行产物绑定使用；尚未形成许可批准。实际文件存在、版本线索、许可声明、许可材料齐备与商业使用批准分别记录，不能互相替代。

## 固定范围与证据

仅盘点 `work/app/work/runtime/platform-cli-guarded` 的物理树、其真实 EXE 的 CArchive/PYZ 内容及 `base_library.zip`。既有 `work/app/src/resources/licenses/DEPENDENCIES.json` 仅用于寻找外部材料候选，不当作该运行树库存。未执行或导入目标 CLI，未读取原业务库、Cookies、凭据，未联网、安装依赖或改运行库。

| 绑定对象 | SHA256 |
| --- | --- |
| 当前包装器 `work/app/src/platform_cli.py` | `2580bd579de76191a5bfd33109c612287f19c94bc55dc10fb64873a31676bb31` |
| 当前 `platform-cli.exe` | `5697bfbbeee13e4572f4fa47d4f5bec829bea278403c2da323cb9ffa7b3c648b` |
| 固定整树 | `c7da4bb61f8c95e38490def1a0078d81d4dcc16630060bcb671a53f1a05ee621` |
| 当前 `guard-manifest.json` | `eb007b5d293e2a880ae479207c18edcc2aa85398fada01d2f57040fb09c716f5` |

包装器、EXE、树与 guard 在本轮盘点前后均相同。整树算法复用 `core/runtime_guards.py` 的纯 `cli_runtime_tree_sha256` 定义；提取该函数，不导入实际 Core/适配器。许可状态没有因为 guard 自身声明而提升。

## 实际包含情况

- 155 个物理文件，32,749,885 字节；全部记录相对路径、大小与 SHA256。
- 12 项 EXE CArchive 目录记录；实际 PYZ 内 1,218 个模块记录，各含原字节摘要；`base_library.zip` 内 155 项；107 个原生 DLL/PYD，记录 PE 版本资源和文件摘要。
- 23 个第三方顶层命名空间、8 个 setuptools 内嵌命名空间，共 31 项组件观察。命名空间不能直接当成 31 个独立发行包；`Crypto` 等模块到发行包名的常见映射只是关联候选。
- 只有 `click 8.5.0` 和 `xiaohongshu-cli 0.6.4` 两份物理 dist-info 元数据。29 项组件观察没有独立运行树发行包元数据；其中 18 项有静态版本字面量，11 项连这种版本线索也缺少。
- 固定树内按文件名识别到的独立许可正文仅 Click 的 `licenses/LICENSE.txt`，SHA256 `9a8ad106a394e853bfe21f42f4e72d592819a22805d991b5f3275029292b658d`。小红书包元数据声明 Apache-2.0，但其当前 dist-info 没有对应正文文件。
- 内嵌代码对象中有 346 项含版权或条款关键字的字符串记录，仅记录模块、常量位置、字符串摘要和标记位置。这些记录包含标准库，不等于 346 份完整许可或完整版权告知。

实际 PE 资源显示 Python 3.11.15、OpenSSL 3.5.6、Microsoft VC Runtime 14.44.35211.0。资源里的版权与版本文字不证明分发授权；不能用另一 Python/打包环境的材料替代这些具体二进制的审核。

## 必须保留的缺项与误判边界

1. `setuptools.version` 的 `0.dev0+unknown`、`xhs_cli` 的 `0.0.0` 是可出现于条件分支的字面量。未运行目标代码，不能据此证明执行版本；小红书发行包版本记录仍是物理 METADATA 的 0.6.4。`idna` 组件取 `package_data` 版本线索，不把 Unicode 数据版本 18.0.0 当包版本。
2. 外部旧材料目录找到 24 行候选、39 个去重后的许可材料文件，并逐文件记录 SHA256。其中仅 2 行匹配物理元数据版本、9 行仅匹配未执行的静态版本字面量、13 行未建立版本绑定。即使同名同版本，也不把外部文件写成已包含在本树或已经批准。
3. 缺少多数组件的发行包精确版本、与原生库对应的完整许可/告知材料、完整组件来源与用途审核。嵌入代码的版权标记只能辅助定位，不能替代正文完整性检查。既有 41 文件源码备份证明源文件字节，未覆盖全部 EXE 嵌入依赖或原生库。
4. 本轮未作许可证义务、内部分发范围或商业使用合法性的判断；材料缺项不自动等于内部使用被禁止。JSON 固定保留 `materials_complete_verified:false`、`commercial_use_review_decision:"not_reviewed"`、`distribution_approved:false`、`missing_files_implies_internal_use_prohibited:false`。

## 最小接线用途

正式 Server 可以把本 JSON 的原始文件 SHA256 作为可信审核材料引用之一，并同时冻结 wrapper/exe/tree/guard 的四个实际摘要及 selected route。批准只能来自明确的受信审核 receipt；请求 body、公司配置开关、依赖声明和该库存自己的状态均不能自授批准。运行 artifact、外部材料或审核版本变更须改变许可 policy revision 并重新核对。当前没有真实 approved 输入，缺项仍留给明确审核，技术可读取与商业许可审核继续分开。

## 复现与交付

新生成器：`audits/phase18_inventory_guarded_cli.py`；新完整库存：`audits/phase18-guarded-cli-dependency-inventory.json`（570,089 字节）。工具 Python 使用禁写 bytecode 设置；已安装 PyInstaller 6.22.0 与 pefile 2024.8.26 仅作静态解析器。`marshal`/`dis` 仅读取代码对象与常量，不执行目标 code。正常运行 1.85 秒仅是本地盘点耗时，不能证明平台运行性能。

数据一致性复核通过：物理条目数量/总字节、1,218 模块唯一性、逐文件摘要格式、元数据依据、外部候选不提升许可、固定树前后相同。一次摘要查询误取字段 `candidate_state`（实际是 `status`）曾退出，随后只修正只读查询；库存生成器、目标树与许可结论不受影响。

已实际读取 context-mode 的 SKILL，但当前工具目录没有可调用的 context-mode MCP。完整 570 KB 原证据保存在本项目，只用本地脚本筛选小摘要；没有声称 hooks、自动捕获、自动恢复或安装能力已启用。全部新增文件仅在本项目 `work/product-upgrade-20261009/audits`。
