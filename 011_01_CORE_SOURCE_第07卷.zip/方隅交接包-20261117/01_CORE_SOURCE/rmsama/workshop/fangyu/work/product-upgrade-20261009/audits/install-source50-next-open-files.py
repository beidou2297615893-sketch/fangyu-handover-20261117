"""Install only two new reviewed normal-open files. Never invoke them here."""
from pathlib import Path
import ast,hashlib,json,os,stat,sys,tempfile
PROJECT=Path('C:/积木软件工坊/项目/方隅公寓客户版');WORK=PROJECT/'work';AUDITS=WORK/'product-upgrade-20261009/audits'
OWN=WORK/'source50-next-open-root';APPROVAL=OWN/'INSTALL-APPROVAL.json';RECEIPT=AUDITS/'source50-next-open-installed.json';FAILED=AUDITS/'source50-next-open-install-failed.json'
HELPER=AUDITS/'join-source44-reviewed.py'
raw=HELPER.read_bytes()
assert len(raw)==9601 and hashlib.sha256(raw).hexdigest().upper()=='5F5E3EA22AF7C1FA0FEA71CFEFDA12A9D669C190D5470960901029BF8F4750FB'
names={'blob','pin','expected','no_link_parent','prepared_temp'}
nodes=[x for x in ast.parse(raw).body if isinstance(x,ast.FunctionDef) and x.name in names]
assert {x.name for x in nodes}==names and len(nodes)==5
exec(compile(ast.Module(body=nodes,type_ignores=[]),str(HELPER),'exec'),globals())
if os.name!='nt' or len(sys.argv)!=3 or sys.argv[1]!='--apply':raise ValueError('exact Root install approval required')
authority_raw=blob(APPROVAL)
if pin(authority_raw)['sha256']!=sys.argv[2].upper():raise ValueError('Root install authority changed')
authority=json.loads(authority_raw)
assert authority['schema']=='source50_normal_open_install_approval_v1' and authority['install_authorized'] is True
assert authority['final_non_author_literal_review_passed'] is True and authority['normal_open_only'] is True
assert authority['source50_apply_authorized_here'] is False and authority['App_launch_authorized_here'] is False
assert authority['shortcut_changes_authorized_here'] is False
ready=json.loads(expected(OWN/'READY.json',authority['ready_pin']));expected(Path(authority['review_path']),authority['review_pin'])
expected(AUDITS/'source50-final-root-read.json',ready['approval_pin']);expected(AUDITS/'source50-manifest.json',ready['manifest_pin'])
expected(AUDITS/'join-source50-reviewed.py',ready['join_script_pin'])
if RECEIPT.exists() or FAILED.exists():raise ValueError('prior installation evidence preserved')
items=[]
for name,key in [('next_open_source.py','helper_pin'),('source_next_open_launcher.py','wrapper_pin')]:
 target=WORK/'desktop-self-use-entry'/name;candidate=OWN/'candidates'/name
 if target.exists() or target.is_symlink():raise ValueError('existing normal-open file preserved')
 items.append((target,expected(candidate,ready[key]),ready[key]))
temporaries=[];applied=[];attempted=[]
try:
 for target,after,proof in items:temporaries.append((target,prepared_temp(target,after),after,proof))
 for target,temp,after,proof in temporaries:
  no_link_parent(target)
  if target.exists() or target.is_symlink():raise ValueError('new target appeared')
  expected(temp,proof);attempted.append((target,after,proof));os.rename(temp,target);applied.append((target,after,proof));expected(target,proof)
 result={'schema':'source50_next_open_installed_v1','install_approval_pin':pin(authority_raw),'ready_pin':pin(blob(OWN/'READY.json')),
  'files':[{'path':str(target),'pin':proof} for target,after,proof in applied],
  'Source50_actual_apply_calls':0,'App_launches':0,'shortcut_changes':0,'old_App_stopped_or_refreshed':False,'customer_database_opened':False}
 with RECEIPT.open('x',encoding='utf-8') as stream:stream.write(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
 print(json.dumps(result,ensure_ascii=False))
except BaseException as failure:
 rollback=[]
 for target,after,proof in reversed(attempted):
  try:
   no_link_parent(target)
   if not target.exists() and not target.is_symlink():rollback.append({'path':str(target),'unchanged_absent':True});continue
   expected(target,proof);target.unlink();rollback.append({'path':str(target),'removed_own_candidate':True})
  except BaseException as error:rollback.append({'path':str(target),'held_foreign_or_unknown':True,'error_type':type(error).__name__})
 with FAILED.open('x',encoding='utf-8') as stream:stream.write(json.dumps({'failed':True,'error_type':type(failure).__name__,'rollback':rollback},ensure_ascii=False,indent=2)+'\n')
 raise
finally:
 for target,temp,after,proof in temporaries:temp.unlink(missing_ok=True)
