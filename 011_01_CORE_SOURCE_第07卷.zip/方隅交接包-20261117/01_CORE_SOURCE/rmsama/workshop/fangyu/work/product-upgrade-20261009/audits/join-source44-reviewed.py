"""Root-only backup/CAS join. Requires final read and independently checked QA."""
import hashlib
import json
import os
from pathlib import Path
import stat
import sys
import tempfile
import uuid

PROJECT=Path('C:/积木软件工坊/项目/方隅公寓客户版')
STAGE=PROJECT/'work/product-upgrade-20261009'
PREPARED=STAGE/'audits/source44-parent-join-prepared.json'
APPROVAL=STAGE/'audits/source44-final-root-read.json'
RECEIPT=STAGE/'audits/owner-business-reconciliation-joined.json'

def blob(path):
    current=PROJECT
    for part in path.relative_to(PROJECT).parts:
        current=current/part
        info=current.lstat()
        if current.is_symlink() or getattr(info,'st_file_attributes',0)&0x400:
            raise ValueError('reparse path changed')
    if not stat.S_ISREG(info.st_mode) or info.st_nlink!=1:
        raise ValueError('file kind changed')
    return path.read_bytes()

def pin(value):
    return {'bytes':len(value),'sha256':hashlib.sha256(value).hexdigest().upper()}

def expected(path,proof):
    value=blob(path)
    if pin(value)!=proof:
        raise ValueError('pinned file changed: '+str(path))
    return value

def no_link_parent(path):
    current=PROJECT
    for part in path.parent.relative_to(PROJECT).parts:
        current=current/part
        info=current.lstat()
        if (not stat.S_ISDIR(info.st_mode) or current.is_symlink()
                or getattr(info,'st_file_attributes',0)&0x400):
            raise ValueError('new-source parent changed')

def prepared_temp(target,value):
    no_link_parent(target)
    descriptor,name=tempfile.mkstemp(prefix='.source44-',suffix='.tmp',dir=target.parent)
    temporary=Path(name)
    try:
        with os.fdopen(descriptor,'wb') as stream:
            stream.write(value)
            stream.flush()
            os.fsync(stream.fileno())
        if blob(temporary)!=value:
            raise ValueError('complete temporary write mismatch')
        return temporary
    except BaseException:
        # This explicit temporary file is new and private to this join.
        temporary.unlink(missing_ok=True)
        raise

if os.name!='nt' or len(sys.argv)!=3 or sys.argv[1]!='--apply' or not len(sys.argv[2])==64:
    raise ValueError('requires --apply and Root-read approval SHA')
if RECEIPT.exists():
    raise ValueError('existing join receipt preserved')
approval_raw=blob(APPROVAL)
if pin(approval_raw)['sha256']!=sys.argv[2].upper():
    raise ValueError('Root approval changed')
approval=json.loads(approval_raw)
if (approval.get('schema')!='source44_final_root_read' or approval.get('source_batch')!=44
        or approval.get('join_authorized') is not True
        or approval.get('independent_code_review_passed') is not True
        or approval.get('independent_actual_qa_review_passed') is not True
        or approval.get('real_platform_verified') is not False
        or approval.get('real_company_sdk_verified') is not False
        or approval.get('commercial_complete') is not False):
    raise ValueError('final scoped evidence not approved')
prepared=json.loads(expected(PREPARED,approval['parent_preparation_pin']))
if prepared.get('join_authorized') is not False or prepared.get('source_mutations')!=0:
    raise ValueError('parent-only preparation changed')
for evidence in approval['evidence_pins']:
    path=Path(evidence['path'])
    path.relative_to(STAGE)
    expected(path,evidence['pin'])
backend_dir=STAGE/'owner-business-reconciliation-candidate'
backend=json.loads(expected(backend_dir/'BACKEND-FROZEN.json',approval['backend_frozen_pin']))
if backend.get('formal_parent')!='Source43' or len(backend['targets'])!=12:
    raise ValueError('reviewed backend set changed')
backend_targets={item['target']:item for item in backend['targets']}
all_targets=[]
for item in prepared['targets']:
    target=Path(item['target']);candidate=Path(item['candidate_path'])
    target.relative_to(PROJECT/'work');candidate.relative_to(STAGE)
    parent=item['parent']
    if item['logical_name'] in backend_targets:
        frozen=backend_targets[item['logical_name']]
        if candidate!=backend_dir/frozen['candidate'] or frozen['parent']!=parent:
            raise ValueError('backend freeze and prepared target mismatch')
        candidate_pin={'bytes':frozen['bytes'],'sha256':frozen['sha256']}
        if frozen['expected_absent'] is not (parent is None):
            raise ValueError('new-source expectation changed')
    else:
        candidate_pin=item['final_candidate_pin']
    after=expected(candidate,candidate_pin)
    no_link_parent(target)
    if parent is None:
        if target.exists() or target.is_symlink():
            raise ValueError('new source target no longer absent')
        before=None
    else:
        before=expected(target,parent)
    all_targets.append((item,target,before,after))
if len(all_targets)!=17 or len({str(x[1]) for x in all_targets})!=17:
    raise ValueError('expected 15 logical and 17 physical reviewed targets')
for path,proof in prepared['protected_unchanged'].items():
    expected(Path(path),proof)
backup=PROJECT/'backups/owner-business-reconciliation'/uuid.uuid4().hex
backup.mkdir(parents=True)
records=[]
for index,(item,target,before,after) in enumerate(all_targets):
    backup_file=backup/(str(index)+'-'+target.name)
    if before is not None:
        backup_file.write_bytes(before)
    records.append({'name':item['logical_name'],'target':str(target),
                    'backup':str(backup_file) if before is not None else None,
                    'parent':pin(before) if before is not None else None,'candidate':pin(after)})
prepared_receipt={'schema':'source44_join_prepared','source_batch':44,'targets':records,
                  'approval_sha256':sys.argv[2].upper(),'source_mutations':0}
(backup/'PREPARED.json').write_text(json.dumps(prepared_receipt,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
# Recheck every old parent immediately before any source mutation.
for item,target,before,after in all_targets:
    if before is None:
        if target.exists() or target.is_symlink():
            raise ValueError('new source appeared before join')
    elif blob(target)!=before:
        raise ValueError('formal parent changed before join')
attempted=[]
temporaries=[]
try:
    # Stage complete files before changing any formal target.
    for item,target,before,after in all_targets:
        temporary=prepared_temp(target,after)
        temporaries.append(temporary)
    for (item,target,before,after),temporary in zip(all_targets,temporaries):
        no_link_parent(target)
        if before is None:
            if target.exists() or target.is_symlink():
                raise ValueError('new target appeared before atomic rename')
        else:
            if blob(target)!=before:
                raise ValueError('parent changed before atomic replace')
        attempted.append((target,before,after))
        if before is None:
            # Windows rename fails rather than overwriting an existing target.
            os.rename(temporary,target)
        else:
            os.replace(temporary,target)
        if blob(target)!=after:
            raise ValueError('joined readback mismatch')
    for path,proof in prepared['protected_unchanged'].items():
        expected(Path(path),proof)
    receipt={'schema':'owner_business_reconciliation_join','source_batch':44,
         'targets':records,'logical_targets':15,'physical_targets':17,
         'approval_sha256':sys.argv[2].upper(),'protected_unchanged':prepared['protected_unchanged'],
         'evidence_pins':approval['evidence_pins'],'backup':str(backup),
         'new_customer_created':False,'company_report_independently_verifies_renter':False,
         'financial_receipt_verified':False,'cooperation_policy_verified':False,
         'actual_original_App_verified':False,'native_1_to_1_visual_verified':False,
         'real_company_sdk_verified':False,'real_platform_verified':False,
         'old_main_stopped':False,'customer_database_opened':False,'session_copied':False,
         'deployment_or_packaging_performed':False,'commercial_complete':False}
    receipt_temp=prepared_temp(RECEIPT,(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n').encode('utf-8'))
    temporaries.append(receipt_temp)
    os.rename(receipt_temp,RECEIPT)
except BaseException as original:
    manual=[]
    for target,before,after in reversed(attempted):
        try:
            current=blob(target) if target.exists() else None
            if current==before:
                continue
            if current!=after:
                manual.append(str(target))
                continue
            if before is None:
                target.unlink()
            else:
                restore=prepared_temp(target,before)
                temporaries.append(restore)
                if blob(target)!=after:
                    manual.append(str(target))
                    continue
                os.replace(restore,target)
                if blob(target)!=before:
                    manual.append(str(target))
        except (OSError,ValueError):
            manual.append(str(target))
    if manual:
        raise RuntimeError('join failed; unrelated drift/rollback needs review: '+', '.join(manual)) from original
    raise
finally:
    for temporary in temporaries:
        temporary.unlink(missing_ok=True)
print(json.dumps({'source_batch':44,'logical_targets':15,'physical_targets':17,
                  'protected_unchanged':len(prepared['protected_unchanged']),
                  'actual_original_App_verified':False,'real_platform_verified':False}))
