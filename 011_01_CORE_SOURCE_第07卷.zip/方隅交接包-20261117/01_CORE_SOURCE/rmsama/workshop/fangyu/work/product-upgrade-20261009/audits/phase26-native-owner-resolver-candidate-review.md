# Phase26：独立进程 TokenUser 补证候选冻结

本切片已完成候选源码、3 个合成机制方法和静态核验，尚未执行 Native/Scheduler/CIM/真实令牌查询。它只准备核对固定良性 sleep 子进程的令牌用户，不接入原账号占用判定，不改变 frozen classify 的 unknown，不授予 profile 空闲或账号登录状态。

## 成熟路线与最小接口

复用 `work/app/src/assistant/private_evaluation.py::current_windows_sid` 已有 `OpenProcessToken → GetTokenInformation(TokenUser) → ConvertSidToStringSidW → LocalFree/CloseHandle` 路线，并沿用冻结的固定 Python runtime、atomic Job、固定完整 CIM 读取器。没有引入第三方权限算法或新的账号授权入口。Skill/插件目录已按当前工程机制验证目标评估；本切片直接复用上述成熟组件，不新增工具登录、联网或费用。

新内部接口为 `NativeOwnerResolver(*, apis=None).resolve(pid, created, *, current_sid, wmi_sid=None)`。`apis` 仅供内部 recording API 合成测试，不是 HTTP 参数。构造不读 OS；缺 PID、原创建时间或当前 SID 的输入直接返回未知，不能拿新打开 PID 的时间补填原证据。

公共结果严格为 11 个字段：`contract/state/reason/owner_current/wmi_owner_agrees/creation_verified/running_before/running_after/token_user_verified/handles_closed/evidence_hash`。`state` 只有 `verified/unknown`；`verified` 仅说明本次查询取得并绑定了进程令牌用户事实，也可以是 `owner_current=false`。公共结果不包含 PID、SID、路径、原命令行、令牌、句柄。原值只在调用 RAM 内用于比较和摘要计算。

此处 TokenUser 是进程令牌关联的用户，**不是进程对象/DACL 的 owner，也不是客户身份、平台 UID 或登录成功证明**。[TOKEN_USER 官方定义](https://learn.microsoft.com/en-us/windows/win32/api/winnt/ns-winnt-token_user)和 [OpenProcessToken 官方接口](https://learn.microsoft.com/en-us/windows/win32/api/processthreadsapi/nf-processthreadsapi-openprocesstoken)分别支持该语义与查询路线；文档不等于本候选真实 Windows 已执行。

## 同句柄绑定、失败与释放

只申请 `PROCESS_QUERY_LIMITED_INFORMATION | SYNCHRONIZE`，令牌只申请 `TOKEN_QUERY`。不开 Debug privilege、不提权，不凭 family、PID、路径推断 owner。

在同一个查询进程 HANDLE 上先读创建时间和零超时运行状态，再读 TokenUser，最后重读同一 HANDLE 的创建时间和运行状态。原 CIM 日期只有微秒精度，因此允许原创建时间到 native FILETIME 的 0–9 个 100ns tick 精度差；后一次 native 创建时间必须与首次精确相等。原创建时间冲突、进程已退出、WAIT_FAILED、权限失败、WMI 有效 SID 与 TokenUser 冲突都保持 unknown。不会把可能退出或 PID 复用当成无关进程。

TokenUser 使用有界 16–65536 字节缓冲、返回长度与 SID 指针范围检查；只有成功取得的 token 和成功分配的 SID 字符串才释放。`LocalFree` 和 `CloseHandle` 在 finally 中逐项核返回值；释放未确认时 `close_unconfirmed/unknown`，清空可验证摘要。原函数异常不回显，采用调用前固定阶段码；相同原始异常字符串发生于创建时间读与 token 打开时，分别显示 `creation_unavailable/token_open_unavailable`。

Native 父代表另外验证选定行的 `parent_pid` 必须等于自身、Job membership 与原创建时间必须真实匹配、实际 exe 和 argv0 必须对应 trusted fixed pythonw shim/base alias/base canonical 路线，参数尾部必须精确是固定 `-I -B sleep_child.py`。这些条件不会因 WMI owner 缺失而跳过。

## 必要验证证据

最终 `phase26-native-owner-resolver-synthetic-final.txt` 为 **3/3，0.002s**：

1. WMI owner 缺失时由合成 TokenUser 补证；其他 SID 明确返回 `owner_current=false`；同原始异常码在不同调用阶段仍准确区分。
2. 创建时间、运行状态、权限、缓冲与 WMI 冲突保持未知；缺原创建时间零 API 调用。
3. 已获取资源逐项关闭；释放失败不得 verified；失败 API 输出的非零垃圾句柄不作为已获取资源关闭；结果无原 SID、PID 或句柄字段。

测试加载实际新 resolver，用 recording native API；禁止 Popen/run、socket connect、SQLite connect 与真实 native API。它不证明 Windows 实际 TokenUser、真实 CIM 或 Job 当前代表已通过。此前 first 和 pre-final 日志均保留，都是施工期合成绿；本切片没有伪造首 RED，也不把多次执行算成额外方法。

当前 4 个 Python 文件 AST 通过；PowerShell ParseFile 0 errors。解析未导入或执行 Native 父、sleep 子脚本或 Scheduler。初版 Python static 文件保留为历史，最终以 `phase26-native-owner-resolver-python-static-final.json` 对应 SHA 为准。

冻结核对 13 个旧源（7 个原诊断源、4 个 benign WebView 源、867B Python probe、safe_trace_v2）全部与各自原冻结 SHA 一致；成熟 `private_evaluation.py` 也字节一致。仅新增本切片文件。

## 一次 Native 代表的通过条件

候选父脚本仅允许固定项目 pythonw，固定 sleep 子脚本只 `time.sleep(90)`。Scheduler 候选使用唯一 GUID、当前 Interactive/Limited 主体、无 trigger、IgnoreNew、2 分钟上限；仅主任务审阅冻结 SHA 后可单次启动，D 没有执行。GUID attempt/result 使用 `x` 防覆盖，不自动重试。原账号、原 DB、DPAPI、browser、CLI、平台 URL 均不进入此代表。

收集两次**完整 CIM 快照**与核对**选定 child 稳定性**是两个不同要求：每次快照完整且结构合法；整机摘要相等只记录观察值，允许无关 Chrome、其他开发进程和行数变化。真正通过门槛是同一个 owned sleep child 的原创建时间、parent、实际 TokenUser/current SID、fixed exe/argv/runtime、Job membership 和末核均相符。其他行的 owner 缺口只保存无原值的计数，不拿其变化判断子进程 owner，也不由此推出原 profile 空闲。

两次真实 TokenUser 均验证、选定 child 摘要与令牌证据摘要相同、父当前 SID 未变、runtime 和源材料首尾不变、owned exit 确认后才能 `representative_passed`。setup pending 保留 owned 对象；退出未确认不得丢句柄并假称完成。若清理始终无法确认，Scheduler 上限可能只留下 unfinished attempt，不能用超时当安全退出证明。

固定完整 CIM 读取器和网络/SQLite/DPAPI guard 是代码机制；未来回执仍应准确区分本次请求范围、真实 OS 观察和独立验证。`application_network_calls_requested=false` 不是网络抓包证明。即使这个良性代表实际通过，也只证明其固定子进程 TokenUser 查询路线，不证明原 WebView startup、8070 阻断根因、小红书 UID、原账号恢复或正式许可。

## 当前候选 SHA256

| 文件 | SHA256 |
| --- | --- |
| diagnostics/native-owner-resolver/owner_resolver.py | 9770E5721A705F5B53ED0DCF859E192B15DE21A9235A6F6049D0868A26B0055F |
| phase26_native_owner_resolver_probe.py | F31D90C3BA5EED92AB936EC36435F1D25E4FCBAC36E336E1D30C06E1338F7ED9 |
| diagnostics/native-owner-resolver/sleep_child.py | 6B88F3B6F682650E2AC711CA6310B36A28076A7AA4FED17AB559159042C15834 |
| phase26_run_native_owner_resolver_once.ps1 | 8E089C5DC8F7AD77B7A6C2FCF44A2F39BDE8201FECFFE01F6E6196695A20FE25 |
| audits/test_phase26_native_owner_resolver.py | 635DD72088C9AFAF207F38540F45284413BC0250827C9EB8CAC6EDF8BE573EBC |

后续 owner fallback 如何接入整体 occupancy，需要单独审查；本候选没有进程豁免、没有改变 profile/DATA reparse 门禁，没有用真实 SID 补证绕过缺 parent/创建时间的行。

文件目录：`C:/积木软件工坊/项目/方隅公寓客户版/work/product-upgrade-20261009/audits`。候选源码目录：`C:/积木软件工坊/项目/方隅公寓客户版/work/product-upgrade-20261009/diagnostics/native-owner-resolver`。
