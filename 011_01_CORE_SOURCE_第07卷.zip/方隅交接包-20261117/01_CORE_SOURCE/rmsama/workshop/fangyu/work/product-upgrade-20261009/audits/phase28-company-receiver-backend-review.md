# Phase28 公司接收端 backend 最小实现审查

候选已完成来源账号→独立公司映射接收账号链路。新 helper、固定 transport、产品网关四动作接入实际本机身份/设备/vault/公司前后门禁；不要求接收端拥有来源员工的本机客户库。公司接收角色只来自服务端映射，管理员不自动获接收权，来源账号不能自 ACK。实施沿 RevOps 的来源→承接→回执主流程复用既有成熟模块，没有新增 CRM、加密体系、业务许可审批或依赖。

## 结果与范围

- `company_handoff_received_list` 未选择部门只读返回当前获权选项和 `items:[]/total:null`；明确选择后才读该部门，默认10、最大15。名单、详情、原接收 GET 本地全零 DML，不创建取消墓碑或操作号。
- `company_handoff_received_detail` 和 `company_handoff_receipt_get` 使用本人当前授权与原云号；明文评论、裸 UID、源员工名字、联系方式/凭证引用不进入公开 DTO。只保公司范围客户/来源 hash、渠道号、平台、部门/用途安全标签及必要状态。
- `company_handoff_receipt` 只收实际版本、固定决定和 opaque 证据引用。本人+租户+公司+渠道固定派生原 key，持久一行 self-hash 元数据 CAS 后最多一个公司 receipt 请求。另一实例和重复请求只能按原号查询；未知不重发、不换号、不修改决定，也不使用泛型 product receipts。
- 正常回执只在写回显和原号历史证明均一致后标 recorded。本次回显丢失后，原 GET 可以返回 `state:recorded, attempt.state:unknown, original_execution_confirmed:true`，这两个事实分开；GET 不写本机 attempt。当前 withdrawn/current_consent_valid=false 不抹除真实历史 accepted。证据独验/平台真实性/现金/分成支付均未证；verified 金额 null。
- 传输复用成熟现有有效 session 的 `_capture`/身份与 endpoint 核验，零 refresh、verify、配置写和自动 retry。写请求后超时、范围变化或格式异常保持 mutation_committed=null。读异常为 false；写前验证拒绝为 false，不能据此推论同行另一实例或过去公司操作未执行。
- 网关四动作不进入 generic receipt 目录；接收安全处理、历史读未附加套餐到期门禁。真实云权限/当前客户同意决定是否能接收。最终 HTTP 投影再次核对 saved actor、executor/device/vault/env/company 全配置。

## 代表与实际证据

新独占测试只有三个方法，`phase28-company-receiver-own-final.txt`：**3/3，3.470s**。原方法重复执行不计新增覆盖。

1. 实际来源 Core 成熟 preparation/registration/submission → 另一个空 source lead/task/origin 的实际接收 Core，读取部门和详情；两个接收 Core 实例并发原 CAS 时另一实例 GET/同请求只读未知；实际公司 service/createStore/repo accept commit 后丢响应，重启同原 key 恢复 accepted/rev3，原写重放只读；客户撤回仍保留历史接收与当前授权 false。源本机完整 dump 未变，云 register1/submit1/receipt1/channel1。
2. 伪参数、旧版本、混入拒收原因明确拒绝；受保护标签（零宽电话号码）拒公共投影；晚 scope 变更拒读，写后 scope 变化保未知；坏历史 payload_hash 拒确认、变原决定不允许新尝试。纯读 SQL trace 无 INSERT/UPDATE/DELETE/REPLACE/CREATE/DROP/ALTER，dump 精确相等。
3. 实际 BusinessExecutor→employee gateway→product gateway→固定新 transport→公司服务隔离 worker，真实成功接收回显与原回执读；成熟 productAccessPolicy 实际到期后原 GET 仍可读；HTTP 投影后 vault/company 变化拒旧结果；泛型异常不泄漏原始密钥错误、不变成确定未提交。传输 timeout 只一次，过期 session 零请求，禁 refresh/write/cloud/verify。

旧相邻 Phase23 网关三方法定向影响验证：`phase28-company-receiver-existing-gateway-impact.txt` **3/3，0.555s**。单列旧覆盖，不算新测试，没有重复全511或 UI 矩阵。

最难单方法首跑 `phase28-company-receiver-hardest-first.txt` 1/1，0.991s。首次新三方法真实集成错误保留 `phase28-company-receiver-own-first.txt`：接收 transport 核实完整外层后误把四个 envelope 事实字段也返 helper，导致真实已 commit 回执被窄 helper 拒绝，原 attempt 保未知。新 transport 只窄修成功写投影 `{item,replayed}`，其余 strict envelope 检查保留；第二轮3/3、最终同3已关闭该 RED。初首日志不是工具或夹具错误。

测试期间曾把未生效 `productPlan` 当到期配置；只修改 own 测试为成熟 `productAccessPolicy` 并额外 assert `access_policy.expired`。生产未因该测试变化修改；旧测试与实际 DTO 的97C5版本保备份/4，最终 actual DTO CA12C843…含当前测试与 emitter 源 SHA。不要把原不生效配置当实际到期证明。

实际合成 JSON `phase28-company-receiver-actual-fixture.json` 原 CA12C843A9B2A787D741276FBDB9D90C3C37840BDE24CC89E3629A9E54755B80 保备份/6；标签窄修后一次真实重产当前 **34B182D677DBA73668DC0DB014D227E369935C8D60D7CB63B37A5ACE8E17F2A9**。八 case 对应选部门、选择后名单、可接收详情、CAS 在途未知、丢回显后原号确认、同原写纯读、撤回保历史、正常成功。每个 result exact36、item16，数据从实际调用生成。含原 HTTP 公司 envelope 和 13 源 SHA；未存 synthetic session token。非双方独立 stub 拼造通过，也不是只手改源 SHA。DTO 重生成不是新的测试方法数。

公司服务 fixture 是实际 createService/createStore/repository，DB `runTransaction` 为 SDK 接口兼容内存 adapter 双 callback 回放，**没有调用 node-sdk 内部 transaction engine、真实云事务或网络**。这部分与根/C云独审三方法、94读/0写预算证据分别计数。

## 源、备份与限制

生产源固定：

- `assistant/company_handoff_receiver.py` 当前标签修后 FD11349D3B9EBAB724B7807DD68790FEB5FEE87A6CDF2B9F466313C4AD1DC568；own3测试时 D23B9E7B89DD5122CBBB67D1F615C18FC098B3E23B3F55160D75656363B68184 保备份/5。
- `assistant/company_handoff_receiver_transport.py` D5466C65B58EC04078EB713E6F37AA35033D7BE67AA4A64EF64C79C60D632275。
- `assistant/product_workspace.py` C68E0EEA7DCB6283F0E8F0A8A352107E4F919EAD29D1789799BABDA587F5E155。
- 本轮已测试 root 当前云 ledger70CE35EA…/serviceEF59DD56…；本代理没有修改这两个文件。

旧网关修改前唯一 SHA41A495B8…副本在 `backups/phase28-receiver-backend/1/product_workspace.py`；新候选修改前副本2、transport RED副本3、测试/DTO前版本副本4保留。新 gateway delta 单独保存，Phase27 冻结成果/报告/数据未覆盖。

本机只写新元数据实体 `company_handoff_receiver_attempts` 的 hash、版本、原决定/原证据号等必要信息，不写来源 lead/account/本机 handoff/contacts/原 registration/submission。无 DPAPI 联系方式解密或输送。接收人目前只能登记平台线索在公司责任链中的接收决定，不能据此宣称客户已经可拨打联系；跨电脑手机号/微信承接、合作分成政策与财务权威回执仍未完成。

每人每渠道只支持一份原接收尝试；原 needs_information 等后续多轮重新决定或换接收人的历史恢复不在本切片。部门/用途只保安全标签，没有原裸客户名/UID，使用公司客户范围码区分对象。不能以软件记录完整性替代平台证明或公司履约。真实资源成员映射、登录、云部署与总部真实接单尚未执行；UI 与 GUI 等根独立验收，不在本报告声称完成。

## 独立实际标签缺口与当前验证

C 独审实际 `recipient_name='微\u200b信号：abc123'` 经旧成熟 label 检查后进入公开 DTO，保真 P2 RED；secret 用途拒绝没有问题。根授权仅新 receiver `_label` 追加规范化后号/id/号码+分隔符组合拒绝，未改 acquisition_exports 或独审测试断言。修复记录 `phase28-company-receiver-label-privacy-fix.md`。own3/旧相邻3保历史结果不重复运行；修后源由 C 原两方法负责实际复验，当前验证与原 own3 源阶段严格分开。

C 同原两方法最终 **2/2 GREEN，2.087s**，`phase28-company-receiver-independent-green.txt`；独test20B095CE字节/断言未改，FD113/transportD546/gatewayC68E/acquisition_exportsB41B前后相同。独报告 `phase28-company-receiver-independent-review.md` SHA2BE64475F34E05F0E349231620CEF1FD20893F44CFA40906F5A99FE56616B89D；独manifest `phase28-company-receiver-independent-final-hashes.json` SHAB78DD7E7CBCDC95FFFCA224CA14A788663A8EA2B04E666971F4194B506D5942A。两方法与原 B3/相邻旧3分别计数，不把重产、GUI或旧矩阵算新覆盖。
