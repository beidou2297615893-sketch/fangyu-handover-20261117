# Phase28 旧 UI 静态断言漂移修复与 GUI 静态预检

本次只修改 `work/app/tests/workspace-refinement-ui.test.cjs` 中原相邻函数正则。真实 enterprise 最终 return 仍保留 loadWorklist、openPending、openLead、closeDetail、exportCurrent，且包含已存在的 openTaskComments；redraw 与 profile 仍返回。测试提取实际最终 return 对象、在只含函数替身的隔离 VM 中创建该对象，逐项核对返回能力，不调用方法体、不启动 app/DOM，不再依赖五函数相邻。enterprise SHA 仍为 478337…，receiver 三个产品 UI 源及原 3 项测试均与原冻结相同。

原测试字节及首个已保存 RED 日志完整备份在 `work/product-upgrade-20261009/backups/phase28-static-test-drift-before`，SHA 分别为 BE8C2A3448442C6F480D1E10F20945559A2D417C76CE02B89520441866CA1CFD / 15717087D326B30AE2E6FB4A5CB5CC990A33A892BA229C233A51767AFD1DFFAA。仅同 10 项定向执行一次，GREEN 10/10，未增加新测试数；日志 `logs/phase28-receiver-ui/static-test-drift-green.log`，SHA 495A12646C25E066FA520288A13791AD88BAAB64F85A01475F79F4A9C55643AC。原新 UI 3/3、旧核心 21/21、旧 workspace 修复前 9/10 是独立历史记录，不累加或覆盖为新的整组结果。

## GUI 静态预检（本审阅未启动或访问 GUI）

发现 P2：原 production employee_workspace.ASSETS 缺 company-handoff-receiver-ui.mjs，顶层 import 会 404。已先反馈 root，由 root 在自己的 ownership 下仅添加映射并重 pin。该修正是静态 prelaunch 发现，未冒充实际 GUI RED。本次复核新 employee SHA 8D1217AC0CBC441859FC7BD2A7E73471A35F2ACB877212114651E1076FE0C040，56 个 frozen source 全匹配；直接 MJS asset import 图无缺映射；helper AST 编译成功。固定 GUI worker 已存在，含 source_hashes，并沿原 synthetic fixture 的两 Core / actual service/createStore SDK 接口内存 adapter；检查未运行 worker。

脚本仅在 main/build_preview 中建自有 DATA、固定 worker 与 127.0.0.1 服务；首尾 source pins、固定 argv、阻止 Python outgoing socket 与 platform adapters、云 request_json 仅指向受控本地 SDK fixture、允许四个 company receiver 动作、generic begin/status 禁止、既有 GUI 证据存在即拒绝重跑、首个 ACK 指定丢回执、GET 不重写。原 native_preview 只 AST 提取 Handler 类，不执行其顶层 Core 或 native 启动。源注册/submit 是独立合成准备计数，startup receipt 必须 0；不复制来源 leads/tasks/handoffs/preparation 至接收 Core。

此次静态复核未发现其它未解决 P2；这不证明实际 served UI 能运行、GUI 行为或读写预算已验收。归档时 root 自有 GUI 状态文件已出现：True，本审阅只读取源码/文件元信息，没有启动或访问该实例。GUI、真实公司网络、真实账号、第二实体机均未由本审阅执行。

最新 backend 标签窄修后 actual fixture 为 34B182D677DBA73668DC0DB014D227E369935C8D60D7CB63B37A5ACE8E17F2A9（34B1），仅作为最新来源指向；本次没有重跑原新 UI 3 项，不能把历史 CA12 的 3/3 冒称已用最新 fixture 重测。

修复后 test SHA：590B7F71B1E9D9857A0270C8FC478E1C60BD0C6EE2F2AF30641DD0B81C5E1785。副本 `backups/phase28-static-test-drift-freeze/1/work/app/tests/workspace-refinement-ui.test.cjs`；manifest `audits/phase28-static-test-drift-freeze.json`。
