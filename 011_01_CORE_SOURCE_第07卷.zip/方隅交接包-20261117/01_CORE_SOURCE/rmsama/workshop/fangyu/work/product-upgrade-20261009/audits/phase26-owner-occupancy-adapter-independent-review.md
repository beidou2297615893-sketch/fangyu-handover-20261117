# RAM owner occupancy adapter: independent candidate review

No repair-blocking defect was found in the reviewed candidate. Two new adversarial composition methods passed on their first execution: **2/2, 0.048s**, zero failures/errors. There is no RED-to-GREEN claim. Candidate adapter SHA256 remains `CD1A8C1F2E96D9C3668CCC702A1226562369E5596CCAE8FEAF444BEACD9424DE`.

The new test uses actual frozen `classify` and `NativeOwnerResolver`, the existing recording Native API and RAM argv fixture, and real canonical-path checks over isolated project tmp files. It loads only its two independent methods, not the existing three-method suites. Popen, subprocess.run/CIM, sockets, SQLite, real native DLL/argv loading are explicitly forbidden by the reused fixture. No Host, original DATA, DPAPI, account, browser or platform was invoked.

## Source findings

- `occupancy_adapter.py:17-36,47-48,115-116,165-166` pins and checks the actual frozen classifier (`FF750FDF...`) and resolver (`9770E572...`) before and after a vacant result. Its constructor does no Native IO. The adapter does read fixed source files for hash checks; this is not a claim of zero filesystem IO.
- `:62-82,117-125,140-145,163-164` requires complete exact snapshots, valid current SID, unique valid rows and a copied first snapshot. A vacant result requires two fresh provider reads and repeated current-SID comparisons. Current providers remain trusted internal inputs; an arbitrary callback/synthetic SID is not production authority.
- `:128-139,148-162` derives only missing `owner_sid` in RAM. Existing valid WMI owners are never replaced. Every repaired first row must persist with the same PID, parent, created, name, executable and argv; a newly missing-owner row, disappearance or changed evidence is unknown. A first occupied/unknown classification returns immediately without a later poll relaxing it. Those early returns remain incomplete with no fingerprint, not a vacant authorization.
- Frozen `owner_resolver.py:75-142,149-165` reads creation before/after and running state around TokenUser using the same process HANDLE within each resolve, then requires confirmed resource closure. Across the two polls it opens new HANDLEs and compares the PID/actual-creation/SID hash. This does not claim the same HANDLE is held across polls, object/DACL ownership, platform UID, or continuous occupancy after return.
- Frozen `profile_occupancy.py:145-210` still enforces argv0/executable, exact profile/default-policy/inheritance, parent chronology, actual Job callback, expected WebView runtime and current owner. The adapter performs full classification twice. TokenUser owner evidence does not bypass any of these fences.

## New independent evidence

1. An unchanged WMI row receives two individually verified resolver results, but the actual creation timestamp differs by five ticks inside the existing WMI tolerance. The differing hashes cause `owner_evidence_changed/unknown`. A separately simulated last CloseHandle failure causes `owner_evidence_unavailable/unknown`; both keep no fingerprint. The checks use recording functions and observe actual frozen resolver results rather than forging receipt fields.
2. Stable Native owner evidence combined with a last Job result of False or None retains occupied or unknown. A current-SID change inside final classification becomes `owner_principal_changed/unknown`. A first external/occupied result reads only one snapshot and cannot use the later clean snapshot to become vacant.

All eight recorded candidate/source/test/evidence hashes match before and after the run. The candidate manifest's referenced hashes were also checked without rerunning its prior suites or actual Native probes. No existing freeze, report, source or test was changed. New files are this report, final hashes, independent two-method test, first source record and first log.

## Limits for the next route

This remains an unintegrated RAM adapter candidate. The existing fixed-CIM/current-TokenUser providers and default real resolver must be bound by a separately reviewed parent route; the callback arguments and injectable recording API are internal mechanisms, not an HTTP grant or a security sandbox. The default Native resolver was not executed here. There is no real WMI-outage reproduction, current original-profile vacancy, Host launch, original-account recovery, login/collection permission or deployment claim. Opaque fingerprints are observation digests, not reusable authorization tokens. Future fresh scope/runtime/Job/account checks remain necessary. No raw PID/SID/path/argv is returned or persisted by this adapter; dropping references in finally is not secure memory erasure.
