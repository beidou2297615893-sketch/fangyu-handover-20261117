# Phase17：任务公开计数与提交前异常，只读独审

仅审查本项目生产源；实际小样使用现有 `SingleBatchEntryFixture` 建立项目内独立合成 Core。没有访问原业务库、真实账号或 Cookie，没有网络、平台、模型或云请求；没有修改生产源。这里不是新矩阵或商用验收。

审查源：`work/app/src/assistant/strategy_tasks.py`，SHA `DAEE4C880AA3410FAB86F5E1B85B3261FABBDEA535957F5C3C03D807C3373A5A`；界面 `work/app/src/web/workspace/upgrade-operations-ui.mjs`，SHA `B0E7043F6099CD539BBF14CD29E77164C85B2AC5F25CFDD9E287D3DB8B6CECB8`。

## 计数结论

`StrategyTasks.project_task` 在 `_task` 原身份、任务归属及账号权限核验后，使用 `Store.list('leads', tenant)`，按相等 `task_id` 计数。它与 `core/engine.py::_run_inner` 的累计数量口径一致：本机当前企业下该任务保存的线索行数。不是按 UID 去重的客户人数，不代表高意向、回应、成交或整批完成。

实际一个代表：当前 task/tenant 两行，另一 task 一行、另一 tenant 同 task 一行，原任务 stale `accumulated=9999`。真实公开结果为 2；另外两行不计入；私有词和合成线索正文 canary 未进入结果。API 读取 SQL trace 的数据变更语句为 0，前后数据库 dump 相等。明确覆盖了旧任务缺计数/存有过时计数的风险，而不是给缺字段补假 0。

新增扫描持有 Core 的可重入锁。旧授权 `BEGIN IMMEDIATE` 事务已结束才进行这个扫描，没有新增嵌套写事务或本次发现的确定性死锁。读取会加载整个 tenant 的 leads body，复杂度与内存是 O(该企业全部线索)，其间占 Core 锁；未验证大数据规模的响应时间，不能写成在线规模/吞吐验收。旧授权本身已有短暂 SQLite writer lock，因此 0 数据写入不能表述为所有读取全程不取 writer lock。

## 实际末权限窗口

在同一个合成 Core 的 `Store.list` 返回本 tenant 的 leads 后，单独故障注入 `saved_actor.disabled=True`，`project_task` 仍返回 count=2。该注入写入严格不计入正常读取的 0 写证明。当前方法只在计数前 `_task` 鉴权；当前 `product_workspace` 的末 HTTP 范围核验名单没有 `strategy_task_get`。

这是只读任务投影的权限末窗口，不是实测已绕过运行门禁；实际 Core 执行另有 disabled actor 检查。建议最小复用 `_task`/现有授权于 count 后再次核验，必要时比较任务原归属/版本，再返回公开投影。不要因此扩大角色、任务、lead 权限或改计数口径。反例已报告根代理，由根代理决定窄修复。

## GUI 提交前错误的文案

独立 C 的真实 `createCollectionProgress.start` 负例证明：缺 `accumulated` 会在 `startSavedTask` 提交前抛 `TypeError`，command_submit=0。计数补齐后真实连通样例已通过。

工厂在调用回调前就把 `dispatched` 置 true，这个变量实际上只能证明“回调已开始”，不能证明 `command_submit` 已发生；任何回调异常因此统一写成“请在原任务查看原指令”。保守保留未知并阻止重复提交是安全的，但文案预设有原指令，应最小修改为：

> 本次运行未能确认结果。请查看原任务状态；如已有原指令，先按原号核对，暂勿重复提交。

不能把全部回调异常改成“未提交”，因为回调也可能已提交而丢失响应。若未来要区分确定提交前错误，必须由实际提交边界给可信证明；本次不增加该协议或解除旧 unknown 槽。变量改名为 `callbackStarted` 有助于避免日后误用，但不是关闭此次文案问题的前提。

证据：本目录 `phase17-count-projection-readonly-probe.py` 与 `phase17-count-projection-readonly-probe-result.json`；C 原真实进度红日志 `private-single-batch-entry-ui-independent-real-progress-red.txt`。只读源码和本报告均没有重写旧阶段红证据或生产数据。
