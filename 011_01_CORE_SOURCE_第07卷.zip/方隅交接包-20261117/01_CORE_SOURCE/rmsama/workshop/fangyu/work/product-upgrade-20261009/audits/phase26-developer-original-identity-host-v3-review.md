# Phase26 v3：固定 Python executable 别名对应

v3 仅修复实际原生 metadata-only 诊断已经证明的具体路径阻断，不扩大浏览器、profile 或数据权限。root 原生原因回执 `phase26-native-profile-reasons-77b6a9f5444142d89310a255a56a62b1.json` 指出唯一失败为 ORIGINAL_BROWSER_IDENTITY_PATH_UNAVAILABLE，且该行是本次 probe、executable/argv0 均精确为固定 base alias、解析对应已固定真实 base。旧失败与原风险保留；这不是凭猜测排除一个 PID。

首 v2 七源、报告、manifest、D 三组日志/测试已逐 SHA 备份到 `work/product-upgrade-20261009/backups/phase26-profile-python-v3/1`。此次七个执行源中 **仅 profile_occupancy.py 改变**；owned_job、host、bootstrap、runtime_identity、PS probe、native_runner 不改。旧 C v2 独审与真实良性 Job 回执仍单列为旧事实。

`TrustedCurrentPython` 是 WindowsProfileOccupancy 内部从实际 fixed_interpreter / 固定 pyvenv.cfg 生成的私有对应。它记录当前固定 shim、base alias、canonical base 的精确 Windows spelling→实际实体映射，以及 cfg/shim/base 内容摘要。classify 首尾重核；alias 重定向或材料变化变 unknown。没有传入 HTTP body、账号配置、自授 true、PID 白名单或字符串 substring 许可。

只在通常 executable canonical 检查因路径重定向失败时使用此窄对应，并要求是 Python executable、当前 Windows SID、精确记录的三条路线，以及 executable/argv0 对应同一真实实体。其它 alias、owner 未核/不同 SID、错配 argv0、malformed 路径均拒。正常没有 profile/helper 参数且已可核的此 Python 行才可按原逻辑认作无关进程。真实 helper 若传入目标 profile，依旧要核完整 profile、当前 Job membership、创建时间与所有权，不能因固定 Python 就豁免目标占用。

**profile / DATA 的 canonical_path 与不接受 reparse 规则完全保留**。`--profile-dir` / `--user-data-dir` 不使用 executable 别名对应。classify 默认 trusted_python=None，无法核 alias 时仍 unknown；传 dict / malformed 对应不能自授。窗口探针当前 runtime 对应首尾内容检查不替代宿主的 metadata/runtime 全量 fences。

D 原三方法 v3 **3/3，1.236s**，日志 `phase26-developer-identity-own-three-v3-first.txt`。Windows argv 方法加入实际当前 UV alias 文件路线的合成进程资料：默认 unknown、私有对应 vacant，错误 owner/argv0、模拟 alias retarget、把 alias 作 profile 参数均 unknown。没有修改真实 alias、扫描 OS、执行 CLI 或原账号，未新增方法或重复旧大矩阵。其余两组 legacy null / 成熟 proof / atomic Job 与持锁代表保持原断言。

root 已实际运行一次仅项目临时 benign Job 代表，`phase26-atomic-job-benign-receipt.json` 的 normal membership/close、parent os._exit 后原 child handle exit 均 true。这是该固定良性组件的真实 Windows 证据，不是原账号恢复；D 只读核该回执，没有执行它。root 原 metadata/runtime 首预检与原因诊断都属于 prior source 快照，此 v3 之后的新原号预检/浏览器观察仍由 root 单独决定并保存。

当前未由 D 读取原 DATA、DPAPI、账号 Cookie 或真实 CIM/registry，没有原生/浏览器/网络调用。不能将 source 改完或三组通过等同 vacancy、原账号身份已观察、review_required 解除、商业 natural 许可、采集可用、公司 binding、收费或总目标完成。下一步先核冻结 v3 source，再按已有授权做一次新原生只读预检，不对同一旧源盲重试。未部署、未打包。
