# 经营对账只读层：本机来源事件到公司账本的可信桥

本轮结论：最小能证明的桥是 **同一服务端已存来源事件**，不是本机交接编号直接映射公司渠道，也不是按手机号/昵称找客户。本机限定当前本人有权的不可变 ContactJournal 事件；公司端限定当前认证成员有权的已存在 hc_ 渠道；两端在事件 ID、事件正文摘要、员工、设备、平台、原评论/作者/线索摘要上完全一致后，仅显示“来源已对应的公司账本”。目前没有本机 UUID → 云 hc_ 的确认映射，不能称本机交接已经送达公司服务器。

本报告初稿为旧生产源只读审查与接口建议。其后根代理批准独占新增 business_reconciliation.py 与测试，已实施并冻结；最终13项本机、3项独立公司验证与确切源SHA见同目录 business-reconciliation-local-independent-final.md。初稿代表路线不冒充执行结果，最终仍不等于用户认可或商用验收。未触碰原库、真实客户、平台、账号、真实云、收费、其他代理文件；R23 intent_quality_review.py 与既有23测试保持冻结。

## 最小适用能力

评估现有 RevOps、归因、转化QA、数据验证与工程工具目录。沿用上一阶段已实际读取的 RevOps SKILL.md 的来源、阶段、承接角色及缺项不能自动推进原则。再次实际读取 conversion-signal-qa/SKILL.md 后确认其主范围是付费广告事件预检，不用于本轮订单/金额对账，不叠加付费广告流程或基准。增量复用项目已有 ContactJournal、公司 contact_ledger / handoff-ledger、成员网关和本机范围门禁；没有新增CRM、安装依赖或声称新开源候选已验收。

## 已核对的实际入口

以下路径均在本项目，行号是审查时位置。

|实际入口|事实与边界|
|---|---|
|work/app/src/core/contact_journal.py:92 ContactJournal|事件追加不可变，event_id 唯一；tenant/cloud_owner/payload_hash/previous_hash/chain_hash 入本机一次SQLite事务；acks仅保存 event_id 与 acked_at|
|同文件:217 receipt|按 tenant、owner、reply_id、lead_id 核对原事件/链摘要；无原文投影；即使全部 ACK，cloud_verified 恒 false|
|work/app/src/assistant/runner.py:223 _sync_contacts|既有 device token 上传本人 pending events；只接受本批 event_id 子集后 acknowledge；返回ACK不足以证明云端摘要相同或平台送达|
|work/cloud/workspace/contact_ledger.cjs:59 normalizeEvent、231 syncOne|云端归一事件后按认证设备派生 employee/device_id；同event_id改内容/员工/设备被fingerprint拒绝；保存 source=device_report，不是平台凭证|
|同文件:440 contact_receipts_verify|实际复用算法：原event_id/kind/occurred_at/lead/reply/sender，加原有intent_snapshot，canonical排序后SHA256；配对发送条件独立于事件摘要相同|
|work/app/src/assistant/acquisition_operations.py:532 _create|本机id是UUID32hex；保存自己的lead_id/源platform/author_id/comment_id/task_id/正文摘要，没有cloud channel_id或source_event_id映射|
|work/app/src/assistant/customer_list.py:57 _person|本机customer_key是platform+uid tuple摘要；不能直接当cloud cu_ customer_id|
|work/cloud/workspace/handoff-ledger.cjs:92 register|只从公司已存本人source_event_id派生cloud customer_id；cloud ID hc_+服务器operation hash；source正文hash是raw string SHA|
|同文件:72 itemFor、185 read、203 handle|事务内当前session/disabled/role/company、来源/管理/指定receiver权限以及最新审计快照核验；历史读取不需新handoff权益|
|work/app/src/assistant/product_workspace.py:71 local_scope_guard|已有本机employee/device/executor/tenant/company一致门禁，可作为新只读包装器的scope_guard；返回前仍需再核一次|
|work/app/src/assistant/business.py:149 _ai_cloud|已有窄成员cloud回调，经employee_workspace/integrations校验实际服务envelope，不应让新读层接受客户端endpoint/token|

本机 acquisition._digest 对字符串进行 canonical JSON 后哈希，云 handoff.hash 对字符串直接哈希；即使文本相同，两个旧字段也不应直接比较。桥必须分别重算正确算法。whole event hash为云端 **normalized stored event**；本机昵称/URL等归一差异可能造成摘要不等，这种情况保持“不匹配/需核对”，不能自动降级到UID/昵称猜配。空author_id（例如R22保存来源仍未取得可信发送目标）不能产生稳定客户桥。

## 推荐精确本机接口

```python
LocalBusinessReconciliation(
    core, tenant, owner, company,
    *, device_id, scope_guard, lead_access, cloud_read
)
# cloud_read(saved_actor, 'acquisition_reconciliation_detail', body)
# 只读取已有成员网关；不启动平台、AI、同步、交接注册、订单或收费。
execute('business_reconciliation_detail', {
    'handoff_id': 'existing-local-32hex-id',
    'channel_id': 'hc_' + '64-lowercase-hex',
    'offset': 0,         # 可省略，int，不接受bool
    'limit': 10          # 可省略，最终1..15（最坏事务读预算）
}, saved_actor)
```

初稿建议的包装器名称和签名已在后续批准下实施，最终合同见独立冻结报告。客户端严格仅以上字段，不接受owner/actor/company/tenant/device/customer_id/order_no、原文、手机号、verified、金额、endpoint、token或来源事件列表。channel_id只是用户指定查询引用，并不在校验前成为可信关联。

构造器必须验证 tenant 与已绑定 environment/company 推导一致；company.id保存快照；owner只能当前已存cloud_bound正式主体，device_id只能本机绑定记录，不能从data取。scope_guard是无网络当前门禁；cloud_read是进程注入可信回调，不能是客户端API地址；lead_access必须直接检查当前本人，不借原作者身份、管理员角色或资源部接收权限访问他人的本机原文。

前置步骤：重新读取saved user并核disabled/role/id/username/tenant/cloud_bound；scope_guard===True；本机handoff为tenant/company/cloud_owner本人且其审计快照完整；找到原lead并直接lead_access；源UID/comment_id存在且源字段与handoff冻结版本对应。将需用的本机事件及来源摘要冻结，离开SQLite事务后只发一次上述cloud read（不在SQL锁内联网）。

结果取得后：验证既有外层服务contract/environment/company，及窄summary合同、read_only和无写副作用字段；用云source_event_id检索本机同tenant/owner事件，按该事件reply/lead调用实际ContactJournal.receipt并选同event检查完整性。校验event payload_hash及cloud摘要一致，再校验当前device_id、source_owner、platform、author/comment/raw text/lead hash、cu_派生与云customer一致。复核原saved actor/company/device/本机来源版本与lead_access后才公开响应。读期间同ID换UID、企业/员工/设备变化，应拒绝这次投影；不能把旧结果回填新scope。

“既有本机历史可查”不等于借历史访问另一员工数据。商业权益过期可合法历史读；disabled、失效session、已撤receiver映射或设备/企业变化不可绕过。正文/评级变更可单独标source_stale，UID身份冲突不得继续展示为同客户。若限制本批为完全同版本桥，应明确“当前来源版本不匹配，待核对”，不捏造history对应。

## 公司候选读合同及必要来源字段

代理B当前准备 createBusinessReconciliation({store,companyId,clock,...}) → 实际createService的认证session路由，仅操作 `acquisition_reconciliation_detail`：data={channel_id,offset?,limit?}。以最终落盘合同为准。本机云body只由前置白名单派生，不把本机handoff_id传到云假作mapping。

summary应固定 business_reconciliation_v1、read_only=true，channel包含已有id/revision/status/customer_id/source_event_id/source_owner/current_consent_valid/historical_resource_receipt_recorded/source_evidence_status；订单只按该渠道已有order_links分页，不按客户的所有订单补造链接。B已同意返回来源证据最小摘要：source_event_payload_hash、device_id、platform、source_lead_hash、original_text_hash、author_id_hash、comment_id_hash。裸UID、昵称、评论正文、联系人和凭据不需要新返回。不存在来源doc、与handoff固定源冲突时摘要null+冲突状态，不能默认过桥。

云端完整事务必须核当前认证session/users/company、channel可见性/审计链、event归属/source=device_report/固定客户、channel customer与cu_派生一致、每个现有order客户一致、order reverse唯一渠道索引、链接时revision/history。不接受caller声称owner或verified；错customer/order应fail closed或返回不含金额的冲突项，不暴露另一客户款项。来源注册可能来自reviewed/copied/external_reported等，event摘要相同不能升级成发送、回信或独立客户同意；资源部 authenticated ACK也不升级成财务事实。

## 经营口径与界面语义

- `reported_amount/refund/net_cents`：既有成员报告的订单数字，不是已核实银行实收。
- `admin_reviewed`：当前实现管理员审核可能是登记人自己，不能标独立财务确认。
- `order_linked`：同客户已有渠道/订单关联，不是最终归属或成交率。
- `recorded_calculated_commission_cents`：保存政策计算值，可为历史版本；不是协议真实生效或分成实付。
- `verified_cash_cents`、`verified_paid_commission_cents`：无权威款项源，本批所有层级恒null；不得把null渲染0元或100%回款。
- 旧订单amount_cents没有币种字段，不额外证明CNY、支付币种或做换算。
- `local_cloud_handoff_correspondence_verified=false`：仅same-source不证明特定本机交接送云。若要claim同一业务交接，另需recipient/purpose/consent-reference/notice-version相同或真实服务器确认mapping；本批不写mapping。

界面使用“来源对应的公司账本”“订单登记额”“已保存计算分成”“实收凭证未接入”“分成支付凭证未接入”。联系、回应、同意、资源部独立接收、订单与款项六层分别显示已有/缺失/冲突。缺模型/平台/真实经营记录保持待验证，不借本次软件测试填转化率。

## 最小代表验证路线

先一条隔离实际Core/Store ContactJournal事件+认证公司createService source/channel/已存在同customer订单，不连真实云或平台。用实际原模块形成事件/摘要，不自己生成“可信verified”替身。

1. 同event+exact来源成功；本机UUID/customer_key与云ID不等不自动映射；ACK后仍只uploaded；同一事件归一摘要差异失败且不回退粗配。
2. 同event_ID或lead_ID替换UID、正文/评论/员工/设备/公司，拒绝；仅receiver能看云channel但不能借source本人读本机原事件。
3. 云跨customer订单/反向order另一channel/修订缺历史，金额不泄露；缺付款即使admin confirmed、link成功及commission calculated，verified cash/paid仍null。
4. 权益过期仍有权历史读；disabled/失效session/撤receiver映射拒绝。读层前后换scope或服务await期间source变化，旧结果不返回。
5. 比较调用前后所有隔离state/docs：此读层不得创建事件/订单、同步原文、修改评级/联系人/交接/权益，不能触发外部请求、自动重试或收费。输出不带客户原文/裸UID/联系人/secret。

代表通过后才扩多订单分页、历史退款/政策修订/真实0与缺失null；第二实体机、真实资源部、权威财务系统及用户经营认可另立门。

报告完整路径：C:\积木软件工坊\项目\方隅公寓客户版\work\product-upgrade-20261009\audits\business-reconciliation-source-bridge-review.md

所在文件夹：C:\积木软件工坊\项目\方隅公寓客户版\work\product-upgrade-20261009\audits
