# Phase27 公司原号提交独立边界审查

结论：本次限定范围未发现新的实际阻塞。新增两个独立方法首跑 **2/2 GREEN，1.852 秒**；没有修改生产源、B/D 测试或既有冻结证据。测试只覆盖下述信任边界，不重复并发、丢回执、晚撤回等其他人的代表，也没有重跑整体后端或前端矩阵。

## 两项独立证据

1. `test_company_read_proofs_not_history_or_current_match_authorize_submission`：实际 Core、ContactJournal、原准备、成功登记及固定 SDK 内存适配器先给出可提交基线。只在响应合同边界改变原登记 receipt 为 unknown，或把公司详情 `can_submit` 改为 false、缺失、整数 1。即使本机历史登记来源 flag 为 true，原 receipt 未知仍不查后续来源/详情、不允许提交；即使当前完整来源匹配，后三种权限值仍不允许提交。所有 GET 与拒绝调用整库 dump 不变、SQL DML 为零，原登记行不变，原提交 attempt 不创建，实际 worker submit 次数为零。修改投影是明确的合同边界注入，不声称真实公司曾返回这些数据。

2. `test_self_consistent_hash_does_not_rebind_or_repair_original_unknown_attempt`：实际事务先持久化原 unknown attempt，随后合成 transport 在调用固定 worker 前中断；该未知结果不是云已提交或未提交的证明。针对这个既有行分别更换 device、actor、云原 key并重算合法 `record_hash`，或仅更换 SQL tenant 列。GET 均在任何云调用前以 `ATTEMPT_CONFLICT` 拒绝，SQL DML 为零、全库 dump 不变，原行保留，不修复、不重建、不产生新 key 或新 submit。GET 错误的 `mutation_committed:false` 仅说明本次查询不写，不取消先前 unknown。

测试使用真实 Core/SQLite 及现有固定 Node worker，它调用实际 createService/createStore/repo，通过 SDK 接口兼容的内存双 callback 适配器重演。禁止真实 socket、平台 adapter、通用 ProductOperationReceipts begin/status，只有固定项目 worker 可启动。不是实际云 SDK 事务引擎、真实网络、正式应用初始化、浏览器 GUI、原 DATA、DPAPI 或真实账号执行证据。

## 源码与契约核对

- `assistant/company_handoff_submission.py:83` 将 SQL tenant、actor/device、原准备、原 key、固定 body hash 与行 hash 一并核验；自洽 hash 不替代作用域。`:133` 依次核原 register receipt、exact event binding、原 channel 详情，每步重读本机 scope。`:198` 额外要求没有既有 submit 行、当前准备可用、公司 draft/consent 且权限严格为 true。
- `:243` 接口仅接受 GET 的 handoff_id，或提交的原 handoff/origin/本机版本/公司版本四字段；没有客户端 arbitrary key、客户正文或联系人。`:271` 的 BEGIN IMMEDIATE 先固化 unknown，再于 `:297` 调用一次原号 submit。`:232` 的既有 attempt 路径只读核原号；GET 不将 cloud recorded 回写为本机 recorded，不解除重发锁。真正提交后的错误为 unknown，不能凭业务错误 code 推断未提交。
- `company_handoff_submission_transport.py:32/61` 分别固定一次 submit/status request_json，复用 `company_handoff_status_transport.py:59` 的现有有效会话和首尾 actor/config/token scope 校验；没有 refresh、verify_identity、保存会话或自动重试。该项为源码核对，本独二没有增加 HTTP driver 测试。
- `product_workspace.py:210` 固定公司桥 action 和三个只读证明入口，`:607` 在最终公开投影前复核本人、公司、电脑 scope。不是通用 receipt/取消墓碑恢复。
- `cloud/handoff-ledger.cjs:130/173` 仍在服务器核来源本人、当前角色/政策/接收方/权益、draft、版本、授权撤回、原事件/客户对应与客户占用；`:370` 在本次事务最终返回前再次执行当前 fence。UI 当前 matched 或历史登记 flag 都不是这些 gate 的替代。本次没有重复 root 的云 lateactor 代表；内存 callback 通过不证明真实 SDK 读写顺序已部署验证。

实际 fixture `phase27-company-submission-actual-fixture.json` 的八个投影均为 36 字段。丢 register echo 的 ready 样例是 history_source=false、current_source=true、eligible=true；其依据为新鲜原 receipt/source/detail/权限，不改变历史 echo。丢 submit 回执只读恢复可 result recorded、attempt unknown，eligible 始终 false。历史 submitted 与当前 withdrawn 分列；八项现金/已付提成均 null，平台/跨机/财务/独立接收验真没有被赋予 true。fixture 是他人已生成的实际合成结果，本独审读取并核对，不冒领其八组执行数量。

## 冻结范围

七个直接源/夹具依赖记录了运行前后 SHA，7/7 一致；fixture 的十二项 source_sha256 再作当前盘面核对，12/12 一致，但未把后者冒充独立运行前字节快照。helper F305884C…、transport 0B50DB8D…、gateway 41A495B8…、cloud ledger F1237B20…、actual fixture 6009EAD7…；完整值见独立 manifest。

本次没有新增产品 RED，首跑日志即最终必要运行证据；两个方法不与 B/D/root 已有测试叠计。公司正式提交 UI、实际公司/SDK/账号、GUI、原 DATA、对外部署或整个任务完成均不在本证据范围内。
