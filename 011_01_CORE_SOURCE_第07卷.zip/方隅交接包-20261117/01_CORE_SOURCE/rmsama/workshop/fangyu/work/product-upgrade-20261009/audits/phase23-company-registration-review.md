# Phase23 原准备登记公司草稿：后端交付记录

本切片补齐“本机准备已经保存，但尚不能把原准备登记到公司草稿”的操作断点。新增两个专属入口；第一次明确登记只使用原准备派生的公司编号与完整内容摘要，结果不明时保留原记录，后续只读核对。登记草稿不代表资源部接收、平台送达、成交归属或回款。

## 范围与合同

- 新增 `assistant/company_handoff_registration.py`，类 `CompanyHandoffRegistration`。`company_handoff_register` 仅接收 `handoff_id / expected_origin_id / expected_handoff_revision`；`company_handoff_registration_get` 仅接收 `handoff_id`。公司、环境、主体、设备、原来源、云编号、平台客户引用和登记内容均由可信本机已有记录派生。
- 新增 `assistant/company_handoff_registration_transport.py`，类 `CompanyHandoffRegistrationTransport`。复用成熟只读传输的会话与身份核查，发送一次明确的登记 HTTP 调用；不自动续期、登录、重试或调用云业务包装器。仅允许原平台身份引用，不解密或传输 DPAPI 联系方式。
- 新增专属 `company_handoff_registration_attempts` 记录，存储主体范围、原编号和摘要元数据。先在 SQLite `BEGIN IMMEDIATE` 内复读当前准备与来源、插入原尝试，再调用登记；不同 Core 实例共同使用持久 CAS。原 preparation、handoff、lead、reply、联系方式及云模块未被本模块修改。
- GET 缺行不建记录、不生成编号、不查询公司；有原尝试时只读查询现有的原操作回执与精确来源接口，不再次登记，也不把恢复结果回写尝试元数据。

公开投影为严格 36 字段。`state=recorded` 表示按原号读到了公司原登记事实；`attempt.state` 保留本机尝试状态。整条登记响应丢失后，即使恢复原公司草稿，仍可能是 `state=recorded / attempt.state=unknown / registration_source_verified=false`。只有原成功写回执中的完整来源符合原准备，才保存来源回显证据。所有返回的 `eligible_for_company_submit` 都为 false；本切片没有公司 submit、资源部接收或私人联系方式交付入口。

`mutation_committed=false` 只表达该次读取或明确提交前拒绝的边界，不能推出另一实例、过去原号或公司操作从未执行。持久尝试后任何异常都保持 unknown，不能靠错误类型自动换号。`no_dispatch_scope` 分别为 `this_registration_get_only` 与 `this_registration_call_only`，均不清除过去未知。

## 必要验证与原始证据

`work/app/tests/test_company_handoff_registration.py` 最终 **4/4，8.414 秒**，日志 `phase23-registration-own-final-green.txt`：

1. 实际 Core 准备与原来源进入实际公司 createService/createStore；公司登记已提交但返回丢失，重启服务及 Core 后仅按原号 GET 找回，实际登记调用仍为一次。本机 GET 数据库 dump 不变，历史草稿与当前撤回分列。
2. 自然成功回执来源逐字段符合原准备；重复登记动作退化为原号只读恢复。缺来源、已撤回、错误准备在提交前拒绝；晚主体变更、公司来源 comment 被改后保持 unknown，不假装登记来源已核验。
3. 两个独立 Core 同时操作同一准备，持久元数据仅一行、实际登记仅一次。损坏元数据不能查询新号、重试或越过原绑定。
4. 新传输仅一次 HTTP；到期会话在调用前拒绝，调用后的超时、身份变化或错误包装保持 unknown，公开错误不包含原始异常或令牌。

D 独立三组最终 **3/3，5.179 秒**，报告 `phase23-company-registration-independent-review.md` 与独立 final-hashes 清单记录最终日志，使用相同生产源码：正在提交的原尝试不能由第二 Core 重发；公司来源同 UID 换 comment 及提交后撤回/范围变化保持未知；实际公司 submit、独立 ACK、撤回后，原 register 的 rev1/draft 与当前 withdrawn/历史 ACK 分列。丢响应并重启后的 GET 实际两 Core SQL trace 为 0 DML、完整 dump 不变。D 首次执行是其 SQL trace contextmanager 夹具错误，已只修其独有测试，不计新增产品 RED。B 四组与 D 三组为七个独立方法，重复执行和 JSON case 不重复计覆盖。

真实合成样例为 `company-handoff-registration-actual-fixture.json`，六个 registration case 均来自实际 helper；顶层及每个 case 的 `preparation_get_result` 是同一条相应记录的实际只读 GET，不通过手改标志或拼接旧 origin 制造输入。旧 JSON 和 emitter 已分别保存到 `backups/phase23-registration/4`、`5`。

## 候选问题及更正

- 首次命令未设置 Python 导入路径属于验证环境错误，保留 `phase23-registration-own-first-run.txt`，不计产品缺陷。
- 首次实际自然登记发现成熟公司返回九个固定字段，本候选传输原先按五字段判断。仅修新传输的严格包装匹配，保留 `phase23-registration-own-first-actual-run.txt`。成熟公司云模块未改。
- 并发候选曾出现 SQLite 忙等，旧四组 40.686 秒、诊断单组 33.842 秒保留。读取到既有尝试后显式 rollback，无写连接不再等待 writer commit；新写连接采用 500ms 局部 busy timeout。`phase23-registration-cas-timing-diagnostic.txt` 的实际线程栈与第二候选日志保留。这些耗时不代表真实云吞吐或性能验收。

## 验证边界

Node worker 执行的是实际 createService/createStore 和现有 repos，通过 SDK 接口形状兼容的隔离内存 adapter 双 callback 重放；没有执行 node-sdk 内部事务引擎，没有真实云或网络请求。专属传输的 HTTP 边界另以隔离函数验证。六个 JSON 样例是样例组，不额外算六个测试方法。

原公司 status 只验证原事件自哈希，`full_historical_chain_verified=false` 保持原合同。公司来源精确匹配与登记回显仍是 device_report，不等于平台权威证据。客户同意仍标操作人登记、未独立核验。当前撤回不会抹去历史原登记，但停止当前交付资格。

本报告只交付新增后端与样例。根窗口的网关、UI、实际隔离 GUI及整合回归分别引用其独立证据，不借旧阶段 511 或其它任务结果当本切片已验。未向真实公司登记、未部署、未处理原 DATA、未发送平台消息、未调用模型、未打包。
