/* Same-origin static workspace served by the company function. */
const fs = require('node:fs');
const path = require('node:path');
const {releaseState} = require('./release.cjs');
const assetFolder = path.join(__dirname, 'site', 'assets');
const imageNames = new Set(fs.readdirSync(assetFolder).filter(name => /^fy-[a-z0-9-]+\.(?:png|webp)$/.test(name)));
const svgNames = new Set(['tabler-home.svg','tabler-home-filled.svg','tabler-message.svg','tabler-message-dots.svg','tabler-user-scan.svg',
  'tabler-external-link.svg','tabler-chevron-down.svg','tabler-x.svg',
  'tabler-upgrade-phone.svg','tabler-upgrade-message.svg','tabler-upgrade-check.svg',
  'tabler-upgrade-users.svg','tabler-upgrade-file.svg','tabler-upgrade-user.svg',
  'tabler-upgrade-stack.svg','tabler-upgrade-settings.svg','tabler-upgrade-list.svg',
  'tabler-upgrade-pin.svg','tabler-upgrade-calendar.svg',
  'tabler-upgrade-warning.svg','tabler-upgrade-export.svg',
  'tabler-upgrade-dots.svg','tabler-upgrade-budget.svg',
  'bootstrap-upgrade-card-list.svg','tabler-upgrade-quote.svg']);
const assets = Object.freeze({
  '': ['index.html', 'text/html; charset=utf-8'],
  'app.mjs': ['app.mjs', 'text/javascript; charset=utf-8'],
  'enterprise-ui.mjs': ['enterprise-ui.mjs', 'text/javascript; charset=utf-8'],
  'enterprise-model.mjs': ['enterprise-model.mjs', 'text/javascript; charset=utf-8'],
  'contact-verification.mjs': ['contact-verification.mjs', 'text/javascript; charset=utf-8'],
  'customer-ui.mjs': ['customer-ui.mjs', 'text/javascript; charset=utf-8'],
  'customer-ui.css': ['customer-ui.css', 'text/css; charset=utf-8'],
  'upgrade-shell.mjs': ['upgrade-shell.mjs', 'text/javascript; charset=utf-8'],
  'upgrade-model.mjs': ['upgrade-model.mjs', 'text/javascript; charset=utf-8'],
  'upgrade-operations-ui.mjs': ['upgrade-operations-ui.mjs', 'text/javascript; charset=utf-8'],
  'company-handoff-receiver-ui.mjs': ['company-handoff-receiver-ui.mjs', 'text/javascript; charset=utf-8'],
  'handoff-export-file.mjs': ['handoff-export-file.mjs', 'text/javascript; charset=utf-8'],
  'intent-rule-ui.mjs': ['intent-rule-ui.mjs', 'text/javascript; charset=utf-8'],
  'intent-quality-ui.mjs': ['intent-quality-ui.mjs', 'text/javascript; charset=utf-8'],
  'company-policy-ui.mjs': ['company-policy-ui.mjs', 'text/javascript; charset=utf-8'],
  'business-reconciliation-ui.mjs': ['business-reconciliation-ui.mjs', 'text/javascript; charset=utf-8'],
  'self-worklist-ui.mjs': ['self-worklist-ui.mjs', 'text/javascript; charset=utf-8'],
  'self-daily-evidence-ui.mjs': ['self-daily-evidence-ui.mjs', 'text/javascript; charset=utf-8'],
  'platform-read-ui.mjs': ['platform-read-ui.mjs', 'text/javascript; charset=utf-8'],
  'upgrade-ui.css': ['upgrade-ui.css', 'text/css; charset=utf-8'],
  'upgrade-sidebar-apartment-v1.png': ['assets/upgrade-sidebar-apartment-v1.png', 'image/png'],
  'upgrade-building-logo-v1.png': ['assets/upgrade-building-logo-v1.png', 'image/png'],
  'upgrade-approved-brand-mark.png': ['assets/upgrade-approved-brand-mark.png', 'image/png'],
  'upgrade-approved-apartment-poster.png': ['assets/upgrade-approved-apartment-poster.png', 'image/png'],
  'platform-account.mjs': ['platform-account.mjs', 'text/javascript; charset=utf-8'],
  'transport.mjs': ['transport.mjs', 'text/javascript; charset=utf-8'],
  'collection-progress.mjs': ['collection-progress.mjs', 'text/javascript; charset=utf-8'],
  'collection-progress.css': ['collection-progress.css', 'text/css; charset=utf-8'],
  'site.css': ['site.css', 'text/css; charset=utf-8'],
  'platform-account.css': ['platform-account.css', 'text/css; charset=utf-8'],
  'gsap.min.js': ['gsap.min.js', 'text/javascript; charset=utf-8']
});
function serveSite(event) {
  const raw = event.queryStringParameters?.asset || '';
  if (typeof raw === 'string' && (imageNames.has(raw) || svgNames.has(raw))) return {
    statusCode: 200, isBase64Encoded: true, headers: {
      'Content-Type': raw.endsWith('.svg') ? 'image/svg+xml' : raw.endsWith('.webp') ? 'image/webp' : 'image/png', 'Cache-Control': 'public, max-age=86400',
      'X-Content-Type-Options': 'nosniff', 'Referrer-Policy': 'no-referrer'
    }, body: fs.readFileSync(path.join(assetFolder, raw)).toString('base64')
  };
  if (raw === 'config.mjs') return {statusCode: 200, headers: {
    'Content-Type': 'text/javascript; charset=utf-8', 'Cache-Control': 'no-store',
    'X-Content-Type-Options': 'nosniff'
  }, body: 'export const config=' + JSON.stringify({environmentId: process.env.TCB_ENV,
    companyId: process.env.COMPANY_ID,
    safetyHold: process.env.COMPANY_ID === 'fangyu-apartment-client' && !releaseState().active,
    releaseVersion: releaseState().version,
    pairingAllowed: releaseState().pairingAllowed || releaseState().employeeReleaseEnabled,
    pairingVersion: releaseState().employeeReleaseEnabled ? releaseState().employeeReleaseVersion : releaseState().pairingVersion,
    employeeReleaseEnabled:releaseState().employeeReleaseEnabled,
    employeeReleaseVersion:releaseState().employeeReleaseVersion}) + ';'};
  if (typeof raw !== 'string' || !Object.hasOwn(assets, raw)) return {
    statusCode: 404, headers: {'Content-Type': 'text/plain; charset=utf-8'}, body: 'Not found'
  };
  const [name, contentType] = assets[raw];
  const binary = contentType.startsWith('image/');
  const content = fs.readFileSync(path.join(__dirname, 'site', name));
  return {statusCode: 200, ...(binary ? {isBase64Encoded: true} : {}), headers: {
    'Content-Type': contentType,
    'Cache-Control': 'no-store',
    'X-Content-Type-Options': 'nosniff',
    'Referrer-Policy': 'no-referrer',
    'Content-Security-Policy': "default-src 'none'; script-src 'self'; style-src 'self'; connect-src 'self'; img-src 'self' data: https://*.xhscdn.com https://*.xiaohongshu.com; base-uri 'none'; form-action 'self'; frame-ancestors 'none'"
  }, body: binary ? content.toString('base64') : content.toString('utf8')};
}
module.exports = {serveSite};
