# Phase29 LOCAL 原版本与末会话绑定窄修

根授权修复独立 LOCAL 两个实际 RED，仅修改新 CompanyContactDelivery、其新 transport 及 ProductWorkspace 四联系方式动作接线；旧 contacts/receiver/source/StatusTransport、云 producer 956E/30A8/FE6E 和 UI 未改。

旧候选三生产源、原自有三方法、worker/emitter、6.355 秒日志、安全 DTO、报告及 manifest 共10文件，改前逐字节保存于 `backups/phase29-contact-delivery-local/3/<原完整项目相对路径>`，`before-hashes.json` SHA256 `0202E38460949178623EE9AC8B138AFB6378A8E0E5D21579162A9AECC2B56D62`。因此原 29B1/D26B/AD57 候选、DTO 3F1C 与旧 C manifest 6D7F 是历史，不能当作本次新源证据。

## 修复与范围

独审首例：REVEAL 提交丢回执后，私有 attempt 的 contact_version/expected_contact_revision 与两个未加密 checksum 自洽替换，GET 仍投影伪原版本。现 existing row 的 REVEAL（及已 recorded PUBLISH）必须与服务端已 anchored vault 的 contact_version 相同，否则明确只读拒绝，0修补/0再次解密。PUBLISH expected_contact_revision 是本机联系人修订，不与云 vault revision 混用。

REVEAL 原 vault 修订按当前冻结 producer 生命周期核对：publish 建 vault revision1；REVEAL 不改变它；一次显式 vault WITHDRAW 将 revision 加1并设置 revoked_at；成熟 handoff WITHDRAW 不改 vault 修订。因此未 vault 撤回时核原修订等于当前修订，已 vault 撤回时核原修订等于当前修订减1。不是任意 `<=`，也不要求当前可写/available 或可变 full item hash 不变。本次同第三方法补了合法 vault 撤回后 revision2/原 REVEAL revision1 的纯 metadata GET，保留 local unknown 与公司 recorded、0DML/0第二次解密；未来如果 producer 增加新的 vault 修订能力，须同步审该生命周期而不能沿用此次证据。

独审次例：真实 service 已完成首次 RAM REVEAL 返回后删当前 integrations session，gateway 末投影仍将值交浏览器。现新 transport 提供 `fixed_session_guard(actor)`，从 base host scope guard 的独立 transport 捕获本次完整当前连接与完整 saved actor。该 closure 只在 RAM 保存 endpoint/session/token/expiry/身份，并通过成熟 `_capture` 读取当前配置核对有效期和相等；不更新 session、不 refresh、不打印或持久化这些材料。四联系方式动作把该 guard 用于服务/各 transport 的每 await fence，并在 gateway 最终 HTTP 投影再调用。base guard 与 scoped guard 分开创建避免递归；其他成熟产品动作的门禁未扩展。

末会话或身份失效只拒绝本次返回，不删除 already recorded local row、不改服务器原执行事实、不给联系人值、不再次提交。GET 原号在合法原 session 恢复后仍可只读返回元数据。

## 必要验证

自有同3方法最终 GREEN 3/3，6.531 秒，`phase29-local-contact-delivery-binding-final-green.txt`；未增加方法数，旧矩阵未跑。安全三 DTO 再由实际两个 Core/helper/gateway/fixed transports/service/store 生成：`phase29-local-contact-delivery-actual-fixture.json` SHA256 `8E57F9BBBE5C0C7D114745682D041735423DEFC8C793D0FD2F621A0C94A3728C`，全部 delivery.contact_values=null，13依赖当前SHA核对。

独审 test `test_phase29_local_contact_delivery_independent.py` SHA256 仍为 `BD8E51A68B61B90B17E19BC4510F4348423167A6703BC65CE4D0DB7ABB27C0A9`，其所有断言及首轮 frozen evidence 未改。独立原2最终执行由 `/root/contact_boundary_review` 承担，本报告不冒领其结果；当前窄修候选交该审核。

执行仍是 actual service/store 的 SDK 接口兼容内存 double-callback adapter，官方 KMS request 采用 opaque RAM stub，本机 crypt 也是 synthetic opaque RAM 适配器。无真实 DPAPI、KMS、SDK 引擎、网络、账号、UI/浏览器、Native 原数据或部署证明。阶段目标未声明完成。

项目审核文件夹：`C:/积木软件工坊/项目/方隅公寓客户版/work/product-upgrade-20261009/audits`。当前 source/证据完整SHA见独立新 `phase29-local-contact-delivery-binding-final-hashes.json`。
