# Phase25 公司当前草稿来源核对入口

完成两处窄 UI 候选：在已保存本机准备页增加明确的“核对公司当前来源”按钮；app 将 `company_handoff_channel_check_get` 加入本机产品纯读路由。打开准备页只读原准备，不自动调用新接口，不触发登记、提交、同步、平台、模型或后台刷新；请求只含原 `handoff_id`。

`checkedCompanyChannelCheck` 验证现有后端实际 34 字段、原 origin/公司渠道/历史 revision1 draft、当前授权与原范围关系，禁止额外私有字段、无依据的全历史链/送达/支付/分成证明。当前来源对应与 `registration_source_verified=false` 可以并存。标题和文案单列“公司当前草稿来源已对应”“原登记回显未保存”，实际非 draft 当前状态用“公司当前交接来源已对应”。当前本机条件或公司授权不满足时保留历史对应、显示当前交付暂停。

`not_attempted` 仅描述本机未记录登记尝试，不能推出公司从未记录或执行；原号未知不被新核对解除。资源部独立接收、成交与回款仍未核验，`eligible_for_company_submit` 始终 false。未保存本机 origin 的旧流程保持原入口，未新增提交能力。

新读沿成熟 dialog/generation、actor/device/role、公司/env 私有范围和 caller accept 核对；请求前清除旧当前来源成功，失败不悬挂旧结果；晚返回或原 origin 变化丢弃。本机旧 unknown sessionStorage 槽不写、不释放。云独立界面直接拒绝新动作，不进入普通 command_submit 队列。

## 证据与计数

输入仅使用 `company-channel-check-actual-fixture.json`（E0B48BA9165A9EDD606AF9866DB11C40A1970D57809438D3FADE7FAFBDF8A874）的六条实际 Core / createService-createStore 合成 DTO及各自真实 preparation GET，没有拼造原 DTO 或修改模型 flags。

- 新 `phase25-company-channel-check-ui.test.cjs` 共三个唯一方法：最难 lost echo 正反例、完整范围迟到及失败后旧成功移除、实际 app 本机纯读路由/云界面阻断。
- 首候选与旧 Phase23 登记独立四方法联合 7/7，155.4102 毫秒，`phase25-channel-check-ui-seven-green.txt`；新增覆盖只计三方法。当前状态文案窄修后原三个方法 3/3，94.4711 毫秒，`phase25-channel-check-status-copy-green.txt`；重复执行不增加覆盖。
- 首最难 RED `phase25-channel-check-hardest-first-red.txt` 证实原页面缺少可见公司当前来源核对入口，当前同一代表通过。两处正式 ESM 源 `node --check` 通过。
- 测试执行真实磁盘控制器/路由，使用轻量 DOM、受控传输时间与合成数据；不是 native GUI或真实云部署。主窗口后续负责整体相关矩阵、隔离实屏和加载 SHA。

主窗口首实际隔离 GUI 证实一次 register 丢回显后，当前来源可以匹配且历史回显仍 false；原 unknown 保护保留。随后发现原登记未知提示覆盖顶部当前读取成功，已只在 render 末尾新增状态文案优先：显示“公司当前来源已对应；原登记回显仍待核对。”，hold 另加当前交付暂停。未清旧 warning/unknown、未改动作或提交权限；实际刷新验收由主窗口完成。

最终集成证据：主窗口当前 29 文件、283/283，2920.1355 毫秒，完整日志与 SHA 见 `phase25-company-channel-check-current-frontend-final.txt`、`-final-hashes.json`。283 已包含新三个方法及旧 Phase23 四个，不能再叠加成新增覆盖。C 对原范围与最后四行 copy delta 只做静审，新测试0/GUI0，见 `phase25-company-channel-check-ui-static-independent-review.md`。

主窗口在同 PID17416/port64789 合成实例刷新最终 F36，原单次 register/单渠道保留；两次显式 channel GET 都为 matched/current source true/history echo false，并保持原 unknown 保护，读取没有 SQL 或云业务写。最终截图为 `outputs/产品升级/公司当前来源核对-原登记回显独立提示.png`、`公司当前来源核对-原号匹配未提交.png`；最初 P2 图另行历史保存。此实屏由主窗口执行，B 未另开 GUI、未重跑旧全量或新 register。

两处源码与新测试现冻结：ops F36A8275FA6767DCFDE7BDDCC5459DC1E7C50025D07CE03A9E0163A0C73FCEEE；app 1834C3A13999FCB94FC0E1C1E0530DD82618C16AA160BB45B6D8BC85D328A1B0；新 test CDC4A8625EA93AD21A02AA1A2F732D046F9FB2B45B51263C2D8F533A390CCBDD。旧 139B 与报告保留于 backup3、4；之前备份 1、2 也保留。未重做 UI 审美，未改成熟云/本机业务模块或旧测试、真实账号及原 DATA。完整已服务/静态候选/全局归档证明由主窗口另行封存；不把本源 manifest 当真实云或全部 R01–R25完成证明。
