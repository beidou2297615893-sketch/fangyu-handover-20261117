/* Phase12 independent actual production factory, lightweight DOM and synthetic
 * transport only. No real GUI, user data, company request, provider or platform. */
'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),crypto=require('node:crypto');
const sourcePath=path.resolve(__dirname,'../../app/src/web/workspace/upgrade-operations-ui.mjs');
const source=fs.readFileSync(sourcePath,'utf8');
class Element{
  constructor(tag){this.tagName=tag.toLowerCase();this.children=[];this.parentNode=null;this._text='';this.dataset={};this.attrs={};this.events=new Map();this.disabled=false;this.hidden=false;this.value='';this.className='';this.classList={add(){},remove(){},toggle(){}};}
  set textContent(value){this._text=String(value);this.replaceChildren();this._text=String(value);}get textContent(){return this._text+this.children.map(n=>n.textContent).join('');}
  append(...nodes){for(const n of nodes){n.remove();n.parentNode=this;this.children.push(n);}}
  replaceChildren(...nodes){for(const n of this.children)n.parentNode=null;this.children=[];this._text='';this.append(...nodes);}
  remove(){if(this.parentNode)this.parentNode.children=this.parentNode.children.filter(n=>n!==this);this.parentNode=null;}
  setAttribute(key,value){this.attrs[key]=String(value);}removeAttribute(key){delete this.attrs[key];}
  addEventListener(key,fn){this.events.set(key,[...(this.events.get(key)||[]),fn]);}
  querySelectorAll(selector){const choices=selector.split(',').map(s=>s.trim()),match=n=>choices.some(s=>s.startsWith('#')?n.id===s.slice(1):s.startsWith('.')?(n.className||'').split(' ').includes(s.slice(1)):n.tagName===s);return this.children.flatMap(n=>[...(match(n)?[n]:[]),...n.querySelectorAll(selector)]);}
  querySelector(selector){return this.querySelectorAll(selector)[0]||null;}focus(){}close(){this.open=false;}showModal(){this.open=true;}click(){if(!this.disabled)this.onclick?.();}
}
const deferred=()=>{let resolve;const promise=new Promise(yes=>{resolve=yes;});return {promise,resolve};};
const tick=()=>new Promise(resolve=>setImmediate(resolve));
async function waitFor(fn){const end=Date.now()+2500;while(!fn()){if(Date.now()>end)assert.fail('actual source callbacks did not settle');await tick();}}
const id='a'.repeat(32),revision=3,otherKey='synthetic-other-prepare-key';
const context=()=>({user:{id:'synthetic-actor',username:'synthetic-owner',tenant_id:'synthetic-tenant',role:'operator'},deviceId:'synthetic-device',deviceGeneration:1});
function projection({prepared=false,key='synthetic-original-prepare-key',readOnly=true,originRevision=revision,currentRevision=revision,usable=true}={}){
  return {contract:'company_handoff_preparation_v1',local_only:true,storage_scope:'this_device',cross_machine_verified:false,operation_action:'company_handoff_prepare',idempotency_key:prepared?key:null,operation_id:prepared?'b'.repeat(64):null,state:prepared?'prepared':'not_prepared',origin:prepared?{origin_id:'c'.repeat(64),local_handoff_revision:originRevision,cloud_operation_action:'acquisition_channel_register',cloud_idempotency_key:'d'.repeat(64),expected_cloud_channel_id:'hc_'+'e'.repeat(64),cloud_payload_hash:'f'.repeat(64),source_event_kind:'reviewed',source_ack_recorded:true,source_cloud_binding_verified:false,created_at:1791525600}:null,current:{handoff_id:id,revision:currentRevision,status:'ready_to_deliver',qualification:'qualified',consent_state:'granted',source_state:'matched',preparation_usable:prepared&&usable,blocked_reason:prepared?(usable?null:'source_changed'):'not_prepared'},read_only:readOnly,mutation_committed:!readOnly,replayed:false,refresh_required:true,no_dispatch:true,no_dispatch_scope:'this_preparation_only',previous_company_dispatch_status:'unknown',cloud_requests_started:false,platform_requests_started:false,provider_requests_started:false,contacts_modified:false,handoffs_modified:false,ratings_modified:false,auto_retry:false};
}
function actualFactory(doc){const idle=()=>({open(){},reset(){},dispose(){}});return vm.runInNewContext(source.replace(/^const \{[^\n]+\}=await import\([^\n]+\);\r?\n/gm,'').replace(/export /g,'')+'\n({createUpgradeOperations,checkedCompanyPreparation,companyPreparationSlot,operationLockSlot});',{
  document:doc,window:{},console,Date,crypto:crypto.webcrypto,TextEncoder,createIntentRuleUI:idle,createPlatformReadUI:idle,createIntentQualityUI:idle,createCompanyPolicyUI:idle,createBusinessReconciliationUI:idle,createSelfDailyEvidenceUI:idle,createSelfWorklistUI:idle});}
function harness(handler){const doc={createElement:tag=>new Element(tag),body:new Element('body')},factory=actualFactory(doc),calls=[],storageCalls=[],values=new Map();let current=context();
  const genericSlot=factory.operationLockSlot(current,'handoff_submit',id),generic=JSON.stringify({action:'handoff_submit',idempotency_key:'synthetic-prior-unknown',payload_digest:'0'.repeat(64),state:'unknown'});values.set(genericSlot,generic);
  const storage={getItem(key){storageCalls.push({kind:'get',key});return values.get(key)||null;},setItem(key,value){storageCalls.push({kind:'set',key,value});values.set(key,value);},removeItem(key){storageCalls.push({kind:'remove',key});values.delete(key);}};
  const operations=factory.createUpgradeOperations({execute:async(action,data)=>{calls.push({action,data:structuredClone(data)});assert.ok(['handoff_detail','company_handoff_preparation_get','company_handoff_prepare'].includes(action),'company/cloud/generic recovery/platform actions forbidden');return handler(action,structuredClone(data));},getContext:()=>current,shell:{hooks:{setAction(){}},refresh:async()=>{}},storage});
  return {operations,factory,doc,calls,storageCalls,values,slot:factory.companyPreparationSlot(current,id),genericSlot,generic,context:value=>{current=value;},button:text=>doc.body.querySelectorAll('button').find(n=>n.textContent===text),status:()=>doc.body.querySelector('.upgrade-status'),record:{id,revision}};
}
const envelope=result=>({status:'succeeded',result});
test('actual checker rejects private extras, broad no-dispatch claims, key mismatch and independent-source claims',()=>{
  const doc={createElement:tag=>new Element(tag),body:new Element('body')},check=actualFactory(doc).checkedCompanyPreparation;
  check(projection(),{handoffId:id});check(projection({prepared:true}),{handoffId:id});
  for(const mutate of [r=>{r.contact='PRIVATE-CONTACT';},r=>{r.origin.private_source='PRIVATE-SOURCE';},r=>{r.previous_company_dispatch_status='not_dispatched';},r=>{r.no_dispatch_scope='all_history';},r=>{r.origin.source_cloud_binding_verified=true;},r=>{r.cloud_requests_started=true;},r=>{r.origin.source_ack_recorded=false;},r=>{r.current.preparation_usable=true;r.current.status='withdrawn';}]){const r=projection({prepared:true});mutate(r);assert.throws(()=>check(r,{handoffId:id}),/未通过核对/);}
  assert.throws(()=>check(projection({prepared:true}),{handoffId:id,key:otherKey}),/未通过核对/);
});
test('current revision cannot claim usable for an origin prepared at a different immutable handoff revision',async()=>{
  const inconsistent=projection({prepared:true,originRevision:revision,currentRevision:revision+1,usable:true});
  const h=harness(()=>envelope(inconsistent));
  assert.throws(()=>h.factory.checkedCompanyPreparation(inconsistent,{handoffId:id}),/未通过核对/);
  await h.operations.openCompanyPreparation(h.record);
  assert.equal(h.status().dataset.state,'error');assert.doesNotMatch(h.doc.body.textContent,/当前来源与授权可用于本次准备|准备已保存，尚未送达/);assert.equal(h.calls.length,1);h.operations.dispose();
});
test('actual handoff-detail entry waits for explicit entry then reads only local GET without clearing old unknown',async()=>{
  const h=harness(action=>envelope(action==='handoff_detail'?{item:{id,revision,status:'ready_to_deliver',purpose:'合成交接',qualification:'qualified',source:{platform:'xiaohongshu'},current_authorization:{state:'granted'},permissions:{}},events:[]}:projection()));
  await h.operations.openDetail(h.record);assert.deepEqual(h.calls.map(c=>c.action),['handoff_detail']);h.button('准备公司平台线索').click();await waitFor(()=>h.button('保存本次准备'));
  assert.deepEqual(h.calls.map(c=>c.action),['handoff_detail','company_handoff_preparation_get']);assert.deepEqual(h.calls[1].data,{handoff_id:id});assert.equal(h.values.get(h.genericSlot),h.generic);assert.equal(h.storageCalls.some(c=>c.kind!=='get'),false);h.operations.dispose();
});
test('manual preparation sends exact three opaque fields, stores no source text, and shows no delivery proof',async()=>{
  const h=harness((action,data)=>envelope(projection({prepared:action==='company_handoff_prepare',readOnly:action!=='company_handoff_prepare',key:data.idempotency_key})));
  await h.operations.openCompanyPreparation(h.record);assert.equal(h.calls.length,1);assert.equal(h.storageCalls.some(c=>c.kind!=='get'),false);h.button('保存本次准备').click();h.button('保存本次准备').click();await waitFor(()=>h.status().textContent==='准备已保存，尚未送达。');
  const call=h.calls.find(c=>c.action==='company_handoff_prepare');assert.deepEqual(Object.keys(call.data).sort(),['expected_revision','handoff_id','idempotency_key']);assert.equal(call.data.handoff_id,id);assert.equal(call.data.expected_revision,revision);assert.match(call.data.idempotency_key,/^[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$/);assert.equal(h.calls.filter(c=>c.action==='company_handoff_prepare').length,1);
  const saved=h.storageCalls.find(c=>c.kind==='set');assert.deepEqual(JSON.parse(saved.value),call.data);assert.equal(h.values.has(h.slot),false);assert.equal(h.values.get(h.genericSlot),h.generic);assert.match(h.doc.body.textContent,/本次准备没有向公司发送/);assert.match(h.doc.body.textContent,/更早的公司操作状态仍待核对/);assert.match(h.doc.body.textContent,/公司来源绑定尚未验证/);assert.doesNotMatch(h.doc.body.textContent,/已送达|发送成功|公司已确认|收款成功/);h.operations.dispose();
});
test('lost preparation response recovers only by original GET; missing and another key retain original slot',async()=>{
  let returned=projection();const h=harness(action=>{if(action==='company_handoff_prepare')throw Error('synthetic response lost');return envelope(returned);});await h.operations.openCompanyPreparation(h.record);h.button('保存本次准备').click();await waitFor(()=>h.status().dataset.state==='error');const original=JSON.parse(h.values.get(h.slot));assert.equal(h.button('保存本次准备'),undefined);
  h.button('读取原准备记录').click();await waitFor(()=>h.calls.length===3);await tick();assert.deepEqual(JSON.parse(h.values.get(h.slot)),original);assert.equal(h.button('保存本次准备'),undefined);
  returned=projection({prepared:true,key:otherKey});h.button('读取原准备记录').click();await waitFor(()=>h.calls.length===4);await tick();assert.deepEqual(JSON.parse(h.values.get(h.slot)),original);
  returned=projection({prepared:true,key:original.idempotency_key});h.button('读取原准备记录').click();await waitFor(()=>!h.values.has(h.slot));assert.equal(h.calls.filter(c=>c.action==='company_handoff_prepare').length,1);assert.equal(h.values.get(h.genericSlot),h.generic);assert.ok(h.calls.filter(c=>c.action==='company_handoff_preparation_get').every(c=>Object.keys(c.data).length===1&&c.data.handoff_id===id));h.operations.dispose();
});
test('known prevalidation false clears only this preparation slot; unknown errors retain it',async()=>{
  for(const known of [false,true]){const h=harness(action=>action==='company_handoff_prepare'?{status:'failed',error:'synthetic-prevalidation',...(known?{mutation_committed:false}:{})}:envelope(projection()));await h.operations.openCompanyPreparation(h.record);h.button('保存本次准备').click();await waitFor(()=>h.status().dataset.state==='error');assert.equal(h.values.has(h.slot),!known);assert.equal(h.values.get(h.genericSlot),h.generic);assert.equal(h.calls.length,2);h.operations.dispose();}
});
test('late local GET is dropped after external acceptance, role, device or reset invalidation',async()=>{
  for(const change of ['accept','role','device','reset']){const gate=deferred(),h=harness(()=>gate.promise);let accepted=true;const opening=h.operations.openCompanyPreparation(h.record,{accept:()=>accepted});if(change==='accept')accepted=false;if(change==='role'){const c=context();c.user.role='admin';h.context(c);}if(change==='device'){const c=context();c.deviceId='synthetic-other-device';h.context(c);}if(change==='reset')h.operations.reset();gate.resolve(envelope(projection({prepared:true})));await opening;assert.doesNotMatch(h.doc.body.textContent,/已保存本次准备|预期公司渠道编号/);assert.equal(h.storageCalls.some(c=>c.kind!=='get'),false);assert.equal(h.values.get(h.genericSlot),h.generic);h.operations.dispose();}
});
test('late preparation success preserves the submitted original slot and does not render into invalid continuation',async()=>{
  for(const change of ['accept','role','device','reset']){const gate=deferred(),h=harness(action=>action==='company_handoff_prepare'?gate.promise:envelope(projection()));let accepted=true;await h.operations.openCompanyPreparation(h.record,{accept:()=>accepted});h.button('保存本次准备').click();await waitFor(()=>h.calls.length===2);const original=JSON.parse(h.values.get(h.slot));if(change==='accept')accepted=false;if(change==='role'){const c=context();c.user.role='admin';h.context(c);}if(change==='device'){const c=context();c.deviceGeneration=2;h.context(c);}if(change==='reset')h.operations.reset();gate.resolve(envelope(projection({prepared:true,key:original.idempotency_key,readOnly:false})));await tick();await tick();assert.deepEqual(JSON.parse(h.values.get(h.slot)),original);assert.doesNotMatch(h.doc.body.textContent,/已保存本次准备|预期公司渠道编号/);assert.equal(h.calls.length,2);assert.equal(h.values.get(h.genericSlot),h.generic);h.operations.dispose();}
});
test('concurrent same-slot replacement survives older prepare success and later GET for the older origin',async()=>{
  const gate=deferred();let getResult=projection();const h=harness(action=>action==='company_handoff_prepare'?gate.promise:envelope(getResult));await h.operations.openCompanyPreparation(h.record);h.button('保存本次准备').click();await waitFor(()=>h.calls.length===2);const old=JSON.parse(h.values.get(h.slot)),fresh={...old,idempotency_key:otherKey};h.values.set(h.slot,JSON.stringify(fresh));gate.resolve(envelope(projection({prepared:true,key:old.idempotency_key,readOnly:false})));await waitFor(()=>h.status().dataset.state==='error');assert.deepEqual(JSON.parse(h.values.get(h.slot)),fresh);getResult=projection({prepared:true,key:old.idempotency_key});h.button('读取原准备记录').click();await waitFor(()=>h.calls.length===3);await tick();assert.deepEqual(JSON.parse(h.values.get(h.slot)),fresh);assert.equal(h.button('保存本次准备'),undefined);assert.equal(h.values.get(h.genericSlot),h.generic);h.operations.dispose();
});
test('actual app registry routes both local preparation actions through product_action and blocks cloud-only generic submission',async()=>{
  const app=fs.readFileSync(path.join(path.dirname(sourcePath),'app.mjs'),'utf8');
  const start=app.indexOf('const PRODUCT_ACTIONS=new Set('),end=app.indexOf('\nasync function requestTaskStop(',start);assert.ok(start>=0&&end>start,'actual registry and complete execute unit must be present');
  const unit=app.slice(start,end);
  for(const localWorkspace of [true,false,undefined]){
    const calls=[],submitted=[],state={selected:'synthetic-device',deviceGeneration:1},cloud={user:context().user,call:async(action,data)=>{calls.push({action,data:structuredClone(data)});return {result:projection()};}};
    const execute=vm.runInNewContext(unit+'\nexecute;',{config:{localWorkspace},cloud,state,customerPrincipalSignature:user=>JSON.stringify(user),submit:async(...args)=>{submitted.push(args);assert.fail('generic submission forbidden for preparation');}});
    for(const action of ['company_handoff_prepare','company_handoff_preparation_get']){
      const data=action==='company_handoff_prepare'?{handoff_id:id,expected_revision:revision,idempotency_key:'synthetic-ui-preparation-key'}:{handoff_id:id};
      if(localWorkspace===true){const answer=await execute(action,data);assert.equal(answer.status,'succeeded');assert.deepEqual(calls.at(-1),{action:'product_action',data:{action,data}});}
      else await assert.rejects(()=>execute(action,data),error=>error.mutation_committed===false&&/已绑定的本机工作台/.test(error.message));
    }
    assert.equal(submitted.length,0);assert.equal(calls.length,localWorkspace===true?2:0);
  }
});
test('actual local Core Store ContactJournal projections validate intact and render original preparation separately from current holds',async()=>{
  const fixture=JSON.parse(fs.readFileSync(path.join(__dirname,'company-handoff-preparation-actual-fixture.json'),'utf8'));
  assert.equal(fixture.synthetic_only,true);assert.equal(fixture.fixture_execution,'actual_local_core_store_contact_journal');assert.equal(fixture.real_cloud_or_platform_called,false);assert.equal(fixture.sdk_engine_claimed,false);
  assert.deepEqual(Object.keys(fixture.cases).sort(),['get_prepared','missing','prepared','replayed','source_ack_missing','source_changed','withdrawn']);
  for(const [name,entry] of Object.entries(fixture.cases)){
    const h=harness((action,data)=>{assert.equal(action,entry.action);assert.deepEqual(data,entry.request);return envelope(structuredClone(entry.result));});
    h.factory.checkedCompanyPreparation(entry.result,{handoffId:entry.request.handoff_id,key:entry.action==='company_handoff_prepare'?entry.request.idempotency_key:null,expectedRevision:entry.action==='company_handoff_prepare'?entry.request.expected_revision:null,readOnly:entry.action==='company_handoff_preparation_get'});
    if(entry.action==='company_handoff_preparation_get'){
      const actualSlot=h.factory.companyPreparationSlot(context(),entry.request.handoff_id);
      if(name==='get_prepared')h.values.set(actualSlot,JSON.stringify({handoff_id:entry.request.handoff_id,expected_revision:entry.result.origin.local_handoff_revision,idempotency_key:entry.result.idempotency_key}));
      await h.operations.openCompanyPreparation({id:entry.request.handoff_id});assert.equal(h.calls.length,1);assert.equal(h.values.get(h.genericSlot),h.generic);
      if(name==='missing'){assert.equal(h.button('保存本次准备').disabled,false);assert.equal(h.storageCalls.some(c=>c.kind!=='get'),false);}
      else {assert.match(h.doc.body.textContent,/本次准备没有向公司发送/);assert.equal(h.button('保存本次准备'),undefined);if(name==='get_prepared'){assert.equal(h.values.has(actualSlot),false);assert.match(h.status().textContent,/尚未送达/);}else assert.equal(h.status().textContent,'准备已保存，当前交付保持暂停。');}
    }
    h.operations.dispose();
  }
  const withdrawn=fixture.cases.withdrawn.result;assert.ok(withdrawn.current.revision>withdrawn.origin.local_handoff_revision);assert.equal(withdrawn.current.preparation_usable,false);assert.equal(withdrawn.origin.source_ack_recorded,true);assert.equal(withdrawn.origin.source_cloud_binding_verified,false);
});
