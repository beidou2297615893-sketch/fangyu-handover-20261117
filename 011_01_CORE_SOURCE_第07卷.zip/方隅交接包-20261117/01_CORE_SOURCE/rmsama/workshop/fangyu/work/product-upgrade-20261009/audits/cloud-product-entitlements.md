# 云服务权益与额度执行审查（R19 / R20 / R21）

本轮实现日期：2026-10-10。当前优先完成可用功能；不改 UI、原业务库、真实部署环境、真实角色、账号或其他任务，不打包。

## 结论与证据范围

此前 Python 服务权益能够验证功能与到期时间，但席位、门店、分析额度仅是配置；原云分析仅有企业每日模型预算，不能执行套餐分析槽。已在既有 CloudBase 公司事务与 AI reserve → attempt → settle 链路中补上云端可信权益、席位和门店分组限制、服务周期分析槽预留及核对，不另建支付或模型计价系统。

实际 `index.js.main` 已从服务端配置接入这两项权益。隔离 VM 执行实际入口、实际 `createService`、实际 `createStore`，模型与云 SDK 边界为夹具。新建交接/提交也在云交接事务内执行功能 gate。所有测试均无网络、付费模型、真实资源部或真实客户操作。源代码与夹具成功不等于生产配置生效、跨机器验收、真实平台发出、真实成交或到账。

最小必要 skill：实际读取 `C:/Users/rmsama/.codex/skills/pricing-packaging-planner/SKILL.md`，按其候选权益与发布范围规则复用既有套餐和 AI 账本。本轮未确定任何金额、季度/月度价格，未创建虚构 offer registry，未接支付。

## 文件范围与复用路径

- 新模块：`work/cloud/workspace/product_entitlements.cjs`。
- 新专项：`work/cloud/workspace/product_entitlements.test.cjs`。
- 增量接线：`service.cjs`、`ai_enterprise.cjs`、`index.js`。
- 最小交接 gate：`handoff-ledger.cjs` 与 `handoff-service-integration.test.cjs`。
- 原有模型价格、每日预算、用量回执、事务存储、认证、资源部映射、交接审计和发布限制继续复用。
- `ai_contract.cjs` 的 v14 由 root 独立维护，本轮联跑使用其当前版本，未编辑该文件或其原测试。

已有源改动前分别备份到 `work/product-upgrade-20261009/backups/cloud-product-entitlements-r1` 至 `r5`，其中 `r3` 包含入口接线前 `index.js`，SHA256 为 `70AB231CC710F098455578958E59E69A2D800907B322BBF4B151834B7CF0DE2D`；`r4` 包含交接 gate 前 `handoff-ledger.cjs`，SHA256 为 `3F5CA78345C3E32B9A82FAF5AB65B79872049AB05CA5F352FBCB80A0048A8CCA`。

## 可信配置

`PRODUCT_ACCESS_POLICY` 是服务端环境 JSON，沿用现有字段：`package / name / features / expires_at / seat_limit / store_limit / analysis_quota / billing_period`。只有明确配置的权益生效；请求 payload 里的角色、门店、quota、units、period 等不能改变额度分配。没有该配置继续现有 pilot 行为。

`PRODUCT_SERVICE_PERIOD` 是服务端 JSON：`{id, start_at, end_at}`。起止时间使用 Unix 秒，开始时刻包含、结束时刻不包含。周期必须由可信经营配置明确给出，不能从客户端月份或套餐名推断。显式配置分析额度但没有有效周期时，新分析明确拒绝，不能退回不限额。周期 ID 一旦已有用量账本，其边界不能改写；新的可信周期不会移走或释放旧周期未知占用。

实际入口在 SDK 初始化前解析并校验显式配置；空值、坏 JSON、`null`、非法字段/类型会固定 503。日志只包含固定错误代码，不打印配置内容、凭证或原始异常。缺失配置与无效配置有不同语义。配置为启动期可信配置，生产更改需受控重启/部署，本轮没有执行。

## 额度单位与状态

分析额度单位为 `comment_analysis_slots`：实际归一化后提交分析的评论数。它表示消耗的分析资源槽；无关或不确定结果也发生过资源处理，不能伪称准确客户数。重复缓存命中额外消耗为 0。原模型实际用量和每日预算保留原账本，套餐槽不替代模型费用或订单分成。

额度实体是两个新增独立集合：`fangyu_product_quota_periods`、`fangyu_product_quota_requests`，公司与请求文档使用服务端派生哈希 ID。请求由企业、当前持久化用户名、操作、稳定编号和归一化输入摘要绑定；不保存评论正文、联系方式、模型密钥或原 payload。原操作编号仍属于请求元数据，应使用随机业务 UUID，不能填客户资料。

| 状态 | 可信含义 | 占用处理 |
|---|---|---|
| reserved | 已提交预留事务，结果未完成核对 | 保留，占用分析槽 |
| confirmed | 原 AI 账本用量能够核对、确认处理 | 从预留转为已用 |
| released | 原模型明确未收费、未消耗的拒绝 | 释放一次；原显式编号不能再执行 |
| unknown | 原调用/回执/写库结果未知 | 保留，禁止自动退款或按旧编号重放 |
| cached | 有效缓存，无额外模型调用 | 本次新增槽为 0 |
| cancelled | 核对时原编号尚不存在，原子取消墓碑 | 不开始；迟到同编号拒绝 |

预留、确认、释放或未知登记均与原模型预算/请求账本在同一个原 SDK 事务中发生，事务回放只会回放本地数据库逻辑，模型调用始终在事务外。预留后权限会在每次实际模型调用前重新核对。调用期间员工被停用或会话撤销时，原处理仍按真实用量结算，但旧身份得不到结果。

明确成功的同编号使用有效缓存读回；同编号改输入拒绝。缓存过期后不能把已确认请求偷偷当新工作重复执行。需核对后人工确认新的请求编号。

## 旧客户端兼容与未知恢复

现有 Python 旧路径没有传显式 `request_id`，以前模型明确未收费后按相同输入可重试。本轮保留该行为，仅原缓存绑定的服务器 AI ledger 已明确 `unbilled` 且不保留预留时，派生 `contextHash:旧 provider UUID` 的下一次自动槽编号并写回缓存。原已释放账本仍保留；后来未知结果仍使用该键，重启、缓存到期或跨周期不能自动换键。显式编号始终保持严格幂等。

新调用方应传稳定随机 `request_id`，保存该编号用于状态核对。只有确认原请求已明确未执行/未消耗，且人工决定开始新工作时，才使用新编号；不能因超时自动生成新编号。root 负责 Python 接入，本轮未修改其入口。

## 新的公开核对契约

认证路径沿用 `environment_id` 和当前会话。服务端固定公司、持久化角色及用户名，不接受客户端主体覆盖。

- `product_entitlement_summary`：除了原 `environment_id / operation` 不接受额外参数。返回 `current`、`period`、`period_configured`、`period_active`、`usage`、`allocation`。`usage` 含确认、预留、未知及剩余分析槽；`allocation` 明示计数口径。
- `product_quota_status`：参数严格为 `request_id` 与 `operation_kind: 'intent_analyze'`。只核对当前可信主体的编号。返回原编号、状态、周期、单位、`execution_confirmed` 与 `reservation_retained`。reserved 投影为 unknown；不存在时同事务写取消墓碑，阻止晚到执行。

两者在过期后仍能核对；身份失效仍拒绝。summary 是企业额度聚合，不披露其他员工的请求详情。结果明确 `payment_enabled: false / payment_provider: not_configured / price: null / billing_verified: false`。产品资源执行成功不表示扣款成功、充值已到账或客户转化。

## 席位、门店及功能边界

`member_save` 仍只允许既有管理员；其成员启用及分组变化在原公司事务中验证。席位口径为全部 enabled 登录成员，包含管理员；门店口径为 enabled 成员可信 `store_id` 的不同值。恢复/新增成员或增加分组受 `team`、席位与门店上限约束。减少、停用和安全收尾在过期/降级后仍可执行。不停用既有超额用户、不赋予真实角色、不伪造门店组织架构。原部署最多 100 成员容量限制仍保留。

该门店计数是可信成员分组绑定，并不是完整门店目录、跨店客户访问控制或按店独立支付。下一阶段不能把它宣传成这些能力已完成。

云本轮执行的功能 gate：`intent_analysis`（实际分析）、`strategy`（关键词联想）、`team`（启用席位/增加分组）、`handoff`（新渠道登记/交接提交）。`acquisition` 的平台执行依旧受原设备、发布及登录约束；本机产品入口已有对应权益 gate。`export` 实际导出由 root 的本机受保护导出模块接线，本轮未增加云导出动作。

交接仅 `acquisition_channel_register`、`acquisition_handoff_submit` 的新写入验证权益，事务内幂等读回后再判，写前再判。成功同编号过期后仍可恢复；详情 `can_submit` 会同步关闭。查看、历史授权资源部 ACK、独立审核/订单关联、撤回、争议仍受原主体/当前同意验证，不被商业到期阻止。历史 ACK 事实保留，不把本机登记或夹具 ACK 当成真实资源部已经收到资料。云交接仍只支持平台来源引用，未新增云联系方式保险库。

## 代表性 RED → GREEN 与最终验证

真实源代表性失败已先复现并保留断言：

1. 配额为 1，两名员工并发分析仍调用两次模型（预期第二个 429，原源返回 200）。
2. 预留后权益撤销，首个模型调用仍发生（预期 403，旧实现返回 200）。
3. 旧无编号请求明确未收费后无法重试（预期下一次调用，旧实现 409）。
4. 实际 main 忽略可信配置/坏配置退回 pilot（预期 configured true 或 503，原源分别 false / 200）。
5. 云交接过期或已撤权仍可新增登记（预期 403，原源 200）。

首次收束额度专项 18/18；交接实际服务集成 10/10（含新增 2 条）通过。在 root 当前 v14 contract 下 11 份必要云测试首次联合191/191、5份生产源语法检查通过。随后 root 明确授权补未追踪核对保护：pilot/analysis_quota:null 的不存在记录返回 not_tracked/null，未创建取消墓碑，已有记录仍可读取。新增1条真实先分析后核对 RED→GREEN，额度当前 **19/19**，同一11份必要云联合当前 **192/192**；已包含额度19与交接10，不重复相加。覆盖原 AI70、服务、联系账本、交接账本、公司隔离、设备、员工发布、QA与记住设备。root 另一个本人地域专项不计入这192。未追踪历史覆盖边界与稳定UUID的下一步设计见 `local-policy-integration-review.md`。

新增覆盖：额度超额、两主体并发/重复、callback 回放、同编号改入参、重启、取消晚到、未知跨周期、原周期结算、失败全回滚、调用后结算写失败、撤销员工/功能、跨公司/主体、服务入口配置 fail closed、假角色/额度/周期、席位/分组限额、过期安全减员、交接权益撤销竞态、历史 ACK 与同意撤回保留。

## 当前固定 SHA256

| 文件 | SHA256 |
|---|---|
| product_entitlements.cjs | 8097559A9309C98738AB9FD30D3264969FE3E79039312981B0295C12ACD864EA |
| product_entitlements.test.cjs | 24AD612B4623727CE89ACD6A0177B02BB70764F55D7D27984929EDF4B711BAC7 |
| service.cjs | 344F1892C7533A55EEEAA5B8C0F947B86E557EF8A7B9F1C0143F3D6D6BAE2B4D |
| ai_enterprise.cjs | B0E6121BADE8BE4870EDA810B106EBB627E8555DF0DB0950B6603E9F9AEA4B9D |
| index.js | 223A150519F3BCACE360D35BBDAF876DEEAB74AF426D415A3DF3B259DA2AFF1B |
| handoff-ledger.cjs | FD6A6C942C76DB5BEB5B06BDAA18CE9E6E7CBC0C4C2682DF9899D457BE51856B |
| handoff-service-integration.test.cjs | 0C0BB03FC29104808DB4F22B9344F12DE512296824D1D75C3EDFC19C811EB118 |
| ai_contract.cjs（root 当前依赖） | ED12DC00A61F0839B7F16DD6B0B30FD25EE5E9CA781C87364C77A7BF8F654FA9 |

实际生产可信周期/套餐尚未配置或验收；充值、支付、订单佣金、商业归属、跨机联系方式与生产云部署仍未实现/验证。本轮不在这些空白处返回假成功。
