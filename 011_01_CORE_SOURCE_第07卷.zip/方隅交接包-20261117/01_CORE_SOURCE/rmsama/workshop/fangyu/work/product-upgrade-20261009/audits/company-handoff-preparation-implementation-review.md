# 公司交接本机准备：候选实现与证据范围

本阶段仅实现明确人工触发的本机准备和原准备读取。没有公司提交、公司回执查询、平台发送、AI 调用、支付、上传、部署、原库迁移或跨机器证明。准备记录可以供后续受控提交链路接续；当前工作台不能把它标成“已送达资源部”。

## 已实现接口

- `CompanyHandoffPreparation(core, tenant, owner, company, *, device_id, scope_guard, lead_access)`；环境只能取可信 `company.managedWorkspace.environment_id`，格式沿既有集成的 ASCII 3–100 位；tenant 必须等于 `cloud-` 加 `SHA256(environment + '\n' + company)[:24]`。owner 沿既有公司成员 ASCII 3–80 位，设备和公司标识沿既有 1–160 位。网关负责核对可信 vault、员工、企业和设备，模块在读、写前后复核同一 scope。
- `company_handoff_prepare` 输入仅 `handoff_id`、`expected_revision`、`idempotency_key`。本机操作编号沿既有 ASCII 8–128 位域，界面生成当前 UUID。公司编号由服务端 origin 派生，输入不能指定环境、owner、平台来源、云操作编号或预期公司交接编号。
- `company_handoff_preparation_get` 输入仅 `handoff_id`。缺记录返回 `not_prepared`，不写任何行，不生成编号，不建立墓碑，不取消、重放或重新准备。不存在或不属于当前本人有权的交接使用安全 403，不能通过本接口探测他人记录。
- `CompanyHandoffPreparationError` 提供固定 `COMPANY_HANDOFF_PREPARATION_` code、安全文案和 400/403/409/503。本机保存之前已知失败 `mutation_committed=false`；尝试 commit 以后不能确定结果或发生后置变化为 `null`，不回显原异常。GET 为本次纯读，其 `false` 不代表原准备或旧公司操作没有保存。

## 公共合同

顶层固定字段：`contract, local_only, storage_scope, cross_machine_verified, operation_action, idempotency_key, operation_id, state, origin, current, read_only, mutation_committed, replayed, refresh_required, no_dispatch, no_dispatch_scope, previous_company_dispatch_status, cloud_requests_started, platform_requests_started, provider_requests_started, contacts_modified, handoffs_modified, ratings_modified, auto_retry`。

- 合同 `company_handoff_preparation_v1`；`storage_scope=this_device`、`local_only=true`、`cross_machine_verified=false`、`refresh_required=true`。GET 也返回固定原动作域 `company_handoff_prepare`。
- `state=prepared|not_prepared`。缺记录时 origin、操作编号和 key 均为空。prepare 成功本机保存确认 true；重放 true 表示已确认原本机准备，不代表再次新建或云执行。GET 的本次写入标志为 false。
- `origin` 精确字段：`origin_id, local_handoff_revision, cloud_operation_action, cloud_idempotency_key, expected_cloud_channel_id, cloud_payload_hash, source_event_kind, source_ack_recorded, source_cloud_binding_verified, created_at`。公司动作仅 `acquisition_channel_register`。预期 `hc_` 编号只是确定性 reservation，没有查询或证明该公司记录存在。
- `current` 精确字段：`handoff_id, revision, status, qualification, consent_state, source_state, preparation_usable, blocked_reason`。当前状态接受原模块完整 9 状态和 6 资格。当前授权 `granted|withdrawn|unavailable`；来源 `matched|changed|unavailable`。
- `blocked_reason` 为 null 或 `not_prepared, handoff_not_ready, not_qualified, consent_unavailable, source_changed, source_unavailable, source_ack_missing, origin_state_unknown`。未知或损坏 origin 实际返回拒绝错误，不降级成不存在。缺记录固定 `not_prepared`。可使用要求原准备 revision、当前本机交接、当前原评论全文/UID/comment/task、来源窗口和完整云 payload 摘要精确匹配。
- `no_dispatch=true` 仅限 `no_dispatch_scope=this_preparation_only`。`previous_company_dispatch_status=unknown`，没有本机旧公司发送 outbox，因此不能推断此前所有操作未执行。cloud/platform/provider 开始、联系方式/交接/评级修改、自动重试全部 false。

## 来源与原记录边界

复用已冻结 `LocalBusinessReconciliation._snapshot/_owned_event`，不是调用其公司 read 接口。使用成熟 `AcquisitionOperations` 当前身份、本人原评论权限、交接审计链和授权撤回规则。写锁内用同一 SQLite 连接再次检查 ContactJournal 的原始 JSON 摘要、canonical 摘要、全 reply 历史、相邻全局 hash 和链摘要；这是既有本机诊断算法，不是签名、独立平台证据或任意全局历史的外部证明。

服务端从本人该原评论的全部已保存事件中选最新一条，无客户端 items 或事件编号。7 kind 为 `reviewed/send_started/sent/failed/unknown/copied/external_reported`，均不自动升级成发送证明。最新事件必须与当前原评论全文、真实 UID、comment/task 精确匹配且已有本机 ACK；最新未 ACK 不回退旧 ACK，不主动上传。当前切片沿已验证来源桥只接受小红书有 UID/comment 的原平台身份，本机加密联系方式不能进入公司准备。

`contact_event_acks` 只有事件编号和本机 ACK 时间，没有原 ACK 的 environment/device。故 `source_ack_recorded=true` 仅表示本机留存记录；`source_cloud_binding_verified=false`、跨机 false。新准备冻结当前可信企业环境和设备，不声称旧 ACK 已证明来源在该设备或公司独立落库。

专属 records entity `company_handoff_preparations`，无建表或旧数据迁移；每交接稳定唯一记录，`BEGIN IMMEDIATE` 控制跨 Core 实例竞争。单行包括最小来源、原输入、员工/企业/环境/设备、原交接 revision、来源窗口与 canonical 云 body 摘要，附本机自摘要；没有复制正文、裸 UID、联系方式、同意引用、secret 或完整云请求 body。body hash 包括 environment_id、operation 与服务端 cloud key。它可在原上下文仍精确一致时重建；发生变化就暂停，不能重算或覆盖原来准备。

stable row id 域 `company-handoff-preparation-v1`；origin id 域 `company-handoff-prepare-v1`；cloud key 域 `company-handoff-cloud-register-v1`。预期公司编号按现有公司账本 `hash([company, authenticated owner, acquisition_channel_register, cloud key])`。同本机 key 绑定原输入；换 key、换设备、旧 unknown/坏 hash、换原 revision 都不能创建第二条准备或解除旧未知操作。

## 验证与限制

独占必要 Python 12 组通过：实际 Core、Store、ContactJournal 和 AcquisitionOperations 合成夹具，阻断 socket、平台进程和通用 ProductOperationReceipts。先四个最难代表通过后增加必要边界：完整云 payload/hash、GET 缺记录/已保存与同 key 重放 dump 不变；两个独立 Core 指向同 SQLite、不同 key 竞争只有一条 origin；不可变来源核查后撤回、写事务前失败没有 origin；实际 `db.commit()` 后模拟响应丢失保留 None 并可按原交接 GET；全七 kind；最新未 ACK；当前正文/UID/评论/窗口变化；授权撤回保留历史；保存前 scope 回滚和保存后主体/设备/环境/来源变化保留未知；100 位合法 env；私有字段拒绝；旧 unknown/损坏 origin 不覆盖；权限撤销/坏 journal 拒绝。

命令：`PYTHONPATH=src;tests`，本项目 desktop-python 执行 `-X utf8 -m unittest test_company_handoff_preparation -v`。测试中同 key 并发和实际 gateway/完整 BusinessExecutor 的独立 4 组由 B 负责，另行保留报告，不把重复跑或 callback 次数加进新用例数量。根跨语言 canonical 比较仅本地算法，不是云执行；前端独审另行保留实际模块 fixture 的证据。

`company-handoff-preparation-actual-fixture.json` 由本项目实际模块执行生成，同一合成 Core 七个状态：missing、prepared、replayed、get_prepared、source_changed、source_ack_missing、withdrawn。每项记录实际 action/request/result。没有真实客户、账号、token、SDK 引擎或公司网络调用。可复现生成器为 `emit-company-handoff-preparation-fixture.py`。

本阶段没有正式商用验收。尚缺受控公司 dispatch、可信本机 outbox 及完整原 key 公司恢复桥、独立接收和权威到账链路。原 phase10/phase11、业务对账、来源候选、意向抽检与真实 DATA 完全不改。
