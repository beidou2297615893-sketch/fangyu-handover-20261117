# 经营对账最小只读契约候选

仅本项目候选源及隔离夹具，未部署、无真实订单/财务/客户调用。复用现有 contact_ledger repo、handoff itemFor 审计及可见范围；没有创建新 CRM 或资金账。按实际已读 RevOps 的阶段与证据原则设计，不套用通用行业转化率或定价。

实际候选 action：`acquisition_reconciliation_detail`，严格参数只有 `environment_id/operation/channel_id/offset/limit`。channel_id 必须已有服务器 `hc_`；offset 默认0，limit默认10、最大15。company/actor/session/时间从实际服务端派生；返回 `authenticated_actor` 供本机同当前主体核对。不接受 owner、customer、订单、金额、可信布尔值、联系方式或任意来源引用。

标准 Fangyu envelope 内 `data.summary.contract = business_reconciliation_v1`，`read_only:true`。channel 当前版本、阶段、customer `cu_`、来源事件 UUID、来源主体、设备与源内容摘要、当前同意状态、历史接收事件及当前授权分别投影；平台来源和证据独立核验始终 false。来源原事件匹配才能对应本机 immutable event，不拿本机 handoff UUID/昵称猜服务器渠道。

source payload hash 采用现有 contact_receipts_verify 的 normalized stored event 六字段及可选 intent_snapshot 的 canonical SHA256。返回事件/设备/主体、平台、lead/text/author/comment 各摘要；不返回正文、号码、昵称、裸平台 UID、证据参考、备注或凭据。

orders 仅分页读取该渠道原 `order_links`；不搜索同名客户或自动附加其他订单。依次核对来源、客户、反向唯一订单关联、当前 deal/customer、最新 deal_revision、链接时旧版本。错客户/反向关联冲突/历史不完整时金额为 null，并给固定缺项/冲突码。订单修订仍可显示经过核对的当前已登记金额，但单列 `link_revision_current:false`，不假装旧链接已经确认新版本。

每条订单分别返回 reported_amount_cents/refund/net、当前管理员审核阶段、登记/编辑/审核主体是否有别、已登记 calculated 佣金及其原 policy_revision/history 状态。自审可识别但不能冒充独立财务审核；commission 是旧存值，不以当前政策自动重算。既有 amount_cents 未持久 currency 字段，所以 `currency:null`、`amount_unit:'legacy_cents'`，不声称已核验人民币流水。

每条与整个 summary 的 `verified_cash_cents:null`、`verified_paid_commission_cents:null`、`financial_receipt_verified:false`、`cooperation_policy_verified:false` 保持。缺项不是0；旧计算确为0可显示其 recorded_calculated 0。首批不提供跨页金额合计、全公司转化率或支付动作。

合法历史查看不受商业套餐过期阻断；实际 session 到期、disabled、角色非法、接收映射撤销或公司变化仍拒绝。外层服务身份确认后，helper 在实际公司仓库事务内复核，返回前再次复核时间/身份/可见性。只读不会改订单、事件、政策或已存交接快照。

云实现候选路径：`work/cloud/workspace/business_reconciliation.cjs`；实际 service 新窄路由。handoff factory 仅增加 server-only `readBoundItem(transaction,state,actor,channel_id)` 以复用原 audit/visibility/currentconsent，不扩旧公开写操作。原关联修订的历史也必须存在并同 order/customer/revision/status at link；缺失或冲突时金额为空，不把当前订单回写成新的关联。具体字段及最终冻结 SHA/测试见 `business-reconciliation-implementation-review.md`，不把本设计文档当成真实云已部署证据。
