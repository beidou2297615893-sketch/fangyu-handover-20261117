'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const crypto=require('node:crypto');
const {fixture,hash,DETAIL,pureDetail}=require('./phase25-company-channel-detail-sdk-fixture.cjs');
const OUTER=['contract','environment_id','company_id','item','server_recorded','platform_delivery_verified',
  'attribution_confirmed','settlement_active','read_only','mutation_committed','auto_retry'].sort();
function pure(probe){
  assert.equal(hash(probe.after),hash(probe.before),'detail may not rewrite company housekeeping');
  for(const callbacks of probe.operations)for(const count of callbacks){
    assert.equal(count.writes,0,'detail callback must be a pure read');assert.ok(count.reads<=100);
  }
  for(const count of probe.attempted_callbacks){assert.equal(count.writes,0);assert.ok(count.reads<=100);}
}
function safe(result){
  assert.equal(result.status,200);assert.deepEqual(Object.keys(result.data).sort(),OUTER);
  assert.equal(result.data.contract,'fangyu-workspace-v1');
  assert.equal(result.data.environment_id,'fixture-env');assert.equal(result.data.company_id,'fixture-company');
  assert.equal(result.data.server_recorded,true);assert.equal(result.data.read_only,true);
  for(const name of ['platform_delivery_verified','attribution_confirmed','settlement_active','mutation_committed','auto_retry'])assert.equal(result.data[name],false);
}
test('lost register echo exact channel detail matches frozen source; housekeeping and missing company stay zero-write',async()=>{
  const f=await fixture(),src=await f.source('phase25-fixed-customer'),key=crypto.randomUUID();
  const body={source_event_id:src.event.event_id,recipient_id:'resources',purpose:'租房咨询承接',
    qualification:'qualified',consent:{status:'granted',evidence_reference:'consent:'+crypto.randomUUID().replaceAll('-',''),notice_version:'v1'},idempotency_key:key};
  f.loseNextResponse();await assert.rejects(f.call('acquisition_channel_register',body),/response lost after service committed/);
  const original=await f.status('acquisition_channel_register',key);assert.equal(original.status,200);
  assert.equal(original.data.operation_receipt.state,'recorded');
  const channelId='hc_'+f.operationId('acquisition_channel_register',key);
  assert.equal(original.data.operation_receipt.original_operation.channel_id,channelId);
  assert.equal(original.data.operation_receipt.original_operation.revision,1);
  assert.equal(original.data.operation_receipt.original_operation.historical_status,'draft');
  await f.mutate(state=>{state.sessions.push({username:'expired',digest:'expired',expires:1});
    state.rememberedDevices.push({username:'expired',deviceId:'expired',idleExpires:1,absoluteExpires:1});
    state.attempts.expired={count:1,until:1};});
  const probe=await pureDetail(f,channelId);assert.equal(probe.result.status,200);pure(probe);safe(probe.result);
  const item=probe.result.data.item,lead=src.event.lead;
  assert.equal(item.channel_id,channelId);assert.equal(item.source_event_id,src.event.event_id);
  assert.deepEqual(item.source,{platform:lead.platform,author_id:lead.author_id,comment_id:lead.comment_id,
    source_lead_hash:hash(lead.id),device_id:'fixture-source-device',original_text_hash:hash(lead.text),
    evidence_source:'device_report',platform_provenance_verified:false});
  assert.equal(item.status,'draft');assert.equal(item.revision,1);assert.equal(item.contact_delivery,'platform_reference_only');
  f.data.remove('fangyu_workspace_private/fixture-company');
  const missing=await pureDetail(f,channelId);pure(missing);assert.equal(missing.result.status,503);
  assert.equal(missing.result.data.read_only,true);assert.equal(missing.result.data.mutation_committed,false);
  assert.equal(missing.result.data.auto_retry,false);assert.equal(f.data.state(),undefined);
});
test('current source, mapped receiver and manager visibility remain bounded; foreign or disabled actors get no writes',async()=>{
  const f=await fixture(),registered=await f.registered('phase25-role-customer'),channelId=registered.item.channel_id;
  for(const token of [f.tokens.source,f.tokens.resource,f.tokens.admin]){
    const probe=await pureDetail(f,channelId,token);pure(probe);safe(probe.result);
    assert.equal(probe.result.data.item.permissions.can_receipt,false,'a draft is not an independent receipt');
  }
  for(const token of [f.tokens.outsider,'invalid-session-token']){
    const probe=await pureDetail(f,channelId,token);pure(probe);assert.ok([401,404].includes(probe.result.status));
    assert.equal(probe.result.data.read_only,true);assert.equal(probe.result.data.mutation_committed,false);
    assert.equal(probe.result.data.auto_retry,false);
  }
  await f.mutate(state=>{state.users.find(u=>u.username==='resource').disabled=true;});
  const disabled=await pureDetail(f,channelId,f.tokens.resource);pure(disabled);assert.equal(disabled.result.status,401);
  assert.equal(disabled.result.data.read_only,true);
});
test('last awaited principal, recipient, consent and valid channel snapshot changes fail closed without a write',async()=>{
  for(const mode of ['actor_disabled','receiver_revoked','consent_changed','channel_changed']){
    const f=await fixture(),registered=await f.registered('phase25-late-'+mode),channelId=registered.item.channel_id;
    const withdrawal=f.doc('handoff_','withdrawal:'+registered.item.consent.evidence_reference);
    const channel=f.doc('handoff_','channel:'+channelId),audit=f.doc('handoff_',`event:${channelId}:1`);
    let observed=false;
    if(['actor_disabled','receiver_revoked'].includes(mode)){
      f.duringRead((key,state)=>{
        if(key!==withdrawal)return;
        state._phase25WithdrawalReads=(state._phase25WithdrawalReads||0)+1;
        if(state._phase25WithdrawalReads===3){observed=true;
          if(mode==='actor_disabled')state.users.find(u=>u.username==='resource').disabled=true;
          else state.acquisitionPolicy.receivers.resource=[];
        }
      });
    }
    const transform=(key,snapshot,context)=>{
      if(mode==='consent_changed'&&key===withdrawal){context.withdrawals=(context.withdrawals||0)+1;
        if(context.withdrawals===3){observed=true;return {data:{companyId:'fixture-company',consent_reference:registered.item.consent.evidence_reference}};}}
      if(mode==='channel_changed'){
        if(key===channel){context.channels=(context.channels||0)+1;
          if(context.channels===2){observed=true;const item=structuredClone(snapshot.data);
            item.source.comment_id='same-uid-other-comment';const snapshotItem={...item};delete snapshotItem.companyId;delete snapshotItem.last_event_hash;
            const historical=structuredClone(f.data.docs().get(audit));delete historical.companyId;
            historical.snapshot_hash=hash(snapshotItem);delete historical.chain_hash;historical.chain_hash=hash(historical);
            item.last_event_hash=historical.chain_hash;context.newAudit=historical;return {data:item};}}
        if(key===audit&&context.newAudit)return {data:{...context.newAudit,companyId:'fixture-company'}};
      }
      return snapshot;
    };
    const probe=await pureDetail(f,channelId,f.tokens.resource,transform);f.duringRead(null);
    assert.ok(observed,mode+' must reach the last-read injection');pure(probe);
    assert.ok([401,409].includes(probe.result.status),mode+' must not return an old source/permission');
    assert.equal(probe.result.data.read_only,true);assert.equal(probe.result.data.mutation_committed,false);
    assert.equal(probe.result.data.auto_retry,false);assert.equal(probe.result.data.item,undefined);
  }
});
