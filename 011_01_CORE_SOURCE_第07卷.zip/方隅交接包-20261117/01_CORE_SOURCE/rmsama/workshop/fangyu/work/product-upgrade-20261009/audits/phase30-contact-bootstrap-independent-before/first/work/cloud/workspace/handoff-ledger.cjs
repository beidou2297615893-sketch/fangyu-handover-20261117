/* Server-authored handoffs over the existing atomic company store.
 * No platform sends, cloud contact vault, role grants, money or attribution.
 * Entry must derive identity from its authenticated session, never payload.
 */
const crypto = require('node:crypto');
const {repoFor: contactRepoFor} = require('./contact_ledger.cjs');
const {createProductEntitlements,ProductEntitlementError} = require('./product_entitlements.cjs');
const COLLECTION = 'fangyu_workspace_private';
const OPERATIONS = new Set(['acquisition_channel_register', 'acquisition_handoff_submit',
  'acquisition_handoff_receipt', 'acquisition_handoff_review', 'acquisition_handoff_withdraw',
  'acquisition_handoff_dispute', 'acquisition_handoff_order_link',
  'acquisition_handoff_list', 'acquisition_handoff_detail', 'acquisition_handoff_operation_status']);
const STATUS_OPERATION='acquisition_handoff_operation_status';
const READ = new Set(['acquisition_handoff_list', 'acquisition_handoff_detail', STATUS_OPERATION]);
const WRITE = new Set([...OPERATIONS].filter(operation=>!READ.has(operation)));
const ID = /^[A-Za-z0-9_-]{1,160}$/;
const KEY = /^[A-Za-z0-9_-]{8,128}$/;
const UUID = /^[a-f0-9]{8}-[a-f0-9]{4}-[1-8][a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$/;
const REF = /^(?:evidence|document):[a-f0-9]{32}$/;
const CHANNEL = /^hc_[a-f0-9]{64}$/;
const HEX=/^[a-f0-9]{64}$/;
const STATUSES=new Set(['draft','submitted','accepted','rejected','needs_information',
  'duplicate_pending_review','existing_customer_pending_review','withdrawn','disputed']);
const canonical = value => Array.isArray(value) ? '[' + value.map(canonical).join(',') + ']'
  : value && typeof value === 'object' ? '{' + Object.keys(value).sort().map(key => JSON.stringify(key)+':'+canonical(value[key])).join(',') + '}' : JSON.stringify(value);
const hash = value => crypto.createHash('sha256').update(typeof value === 'string' ? value : canonical(value)).digest('hex');
class HandoffError extends Error {
  constructor(code, message, status=400) { super(message); this.code='HANDOFF_'+code; this.status=status; this.mutation_committed=false; }
}
const fail = (code,message,status) => { throw new HandoffError(code,message,status); };
const exact = (object,keys) => {
  if (!object || typeof object!=='object' || Array.isArray(object) || Object.keys(object).some(key=>!keys.includes(key)))
    fail('INVALID_INPUT','交接字段无效，身份与时间由服务器确认');
};
const ident = (value,label) => { if(typeof value!=='string'||!ID.test(value))fail('INVALID_INPUT',label+'无效');return value; };
function text(value,label,maximum=100) {
  if(typeof value!=='string'||!value.trim()||value.length>maximum||/[\x00-\x1f]/.test(value)||
      /\d{7,}|(?:微信|wechat|phone|电话|手机号|cookie|password|secret|Bearer|api[_-]?key)\s*[:=：]/i.test(value.replace(/[\s()+.-]/g,'')))
    fail('PRIVATE_INPUT',label+'请使用业务说明或受保护引用，不得填写联系方式或凭证');
  return value.trim();
}
const reference = value => { if(typeof value!=='string'||!REF.test(value))fail('EVIDENCE_REQUIRED','请使用实际证据的受限引用');return value; };
function repoFor(transaction, companyId) {
  if(!transaction?.collection)fail('STORAGE_UNAVAILABLE','交接事务存储未配置',503);
  const ref=key=>transaction.collection(COLLECTION).doc('handoff_'+hash([companyId,key]));
  return {
    async get(key) { const snapshot=await ref(key).get(),value=Array.isArray(snapshot.data)?snapshot.data[0]:snapshot.data;
      if(value&&value.companyId!==companyId)fail('TENANT_MISMATCH','企业隔离检查失败',403);
      if(!value)return null;const {_id,companyId:_companyId,...record}=value;return record; },
    async set(key,value) { await ref(key).set({...value,companyId}); }
  };
}
function createHandoffLedger({store,companyId,clock=Date.now,productEntitlements=createProductEntitlements({companyId,clock})}) {
  if(!companyId||!store?.transaction)throw Error('交接企业存储未配置');
  const policy=state=>state.acquisitionPolicy&&typeof state.acquisitionPolicy==='object'?state.acquisitionPolicy:{};
  const recipient=(state,id)=>{ident(id,'接收方');const row=policy(state).recipients?.find(row=>row.id===id);
    if(!row)fail('RECIPIENT_REQUIRED','资源部接收方尚未配置');return {id,name:text(row.name,'接收方名称')};};
  const receives=(state,actor,id)=>{const values=policy(state).receivers?.[actor.username];return Array.isArray(values)&&values.includes(id);};
  const manages=(state,actor)=>actor.role==='admin'||(Array.isArray(policy(state).managers)&&policy(state).managers.includes(actor.username));
  const visible=(state,actor,item)=>item.company_id===companyId&&(item.source_owner===actor.username||manages(state,actor)||receives(state,actor,item.recipient_id));
  async function authorization(repo,item) { return item.consent.status==='granted'&&!(await repo.get('withdrawal:'+item.consent.evidence_reference)); }
  async function publicItem(repo,state,actor,item) {
    const consentValid=await authorization(repo,item);
    let canStart=true;
    try{productEntitlements.requireFeature('handoff');}catch(error){if(!(error instanceof ProductEntitlementError))throw error;canStart=false;}
    return {...structuredClone(item),current_consent_valid:consentValid,
      resource_receipt_auth_verified:item.status==='accepted'&&item.receipt?.authenticated===true,
      platform_delivery_verified:false,contact_delivery:'platform_reference_only',
      settlement:{status:'not_configured',amount_cents:null,attribution_confirmed:false},
      permissions:{can_submit:canStart&&item.source_owner===actor.username&&item.status==='draft'&&consentValid,
        can_withdraw:item.source_owner===actor.username&&item.status!=='withdrawn',
        can_dispute:item.source_owner===actor.username&&item.status!=='withdrawn',
        can_receipt:item.status==='submitted'&&consentValid&&actor.username!==item.source_owner&&receives(state,actor,item.recipient_id),
        can_review:manages(state,actor)&&actor.username!==item.source_owner&&['duplicate_pending_review','existing_customer_pending_review','disputed'].includes(item.status)},
      storage_scope:'company_server_ledger'};
  }
  async function itemFor(repo,state,actor,id) {
    if(typeof id!=='string'||!CHANNEL.test(id))fail('INVALID_INPUT','渠道编号无效');
    const item=await repo.get('channel:'+id);
    if(!item||!visible(state,actor,item))fail('NOT_FOUND','交接不存在或无权访问',404);
    const last=await repo.get(`event:${id}:${item.revision}`),snapshot={...item};delete snapshot.last_event_hash;
    if(!last||last.chain_hash!==item.last_event_hash||last.snapshot_hash!==hash(snapshot)||
        last.chain_hash!==hash(Object.fromEntries(Object.entries(last).filter(([key])=>!['companyId','chain_hash'].includes(key)))))
      fail('AUDIT_CONFLICT','交接与服务器审计快照不一致',409);
    return item;
  }
  async function append(repo,item,actor,operation,now) {
    item.updated_at=now;const snapshot={...item};delete snapshot.last_event_hash;
    const event={channel_id:item.channel_id,revision:item.revision,actor:actor.username,operation,
      occurred_at:now,status:item.status,source_owner:item.source_owner,previous_hash:item.last_event_hash||'',snapshot_hash:hash(snapshot)};
    event.chain_hash=hash(event);await repo.set(`event:${item.channel_id}:${item.revision}`,event);item.last_event_hash=event.chain_hash;
  }
  async function addIndex(repo,key,id) {
    const meta=await repo.get('index:'+key)||{count:0};const page=Math.floor(meta.count/50),row=await repo.get(`index:${key}:${page}`)||{items:[]};
    row.items.push(id);await repo.set(`index:${key}:${page}`,row);await repo.set('index:'+key,{count:meta.count+1});
  }
  async function register(repo,contacts,state,actor,payload,now,operationId) {
    productEntitlements.requireFeature('handoff');
    if(!UUID.test(payload.source_event_id||''))fail('SOURCE_REQUIRED','请先同步有来源证据的联系事件');
    const source=(await contacts.get('event:'+payload.source_event_id))?.record;
    if(!source||source.employee!==actor.username||source.source!=='device_report'||!source.lead?.author_id||!source.lead?.comment_id)
      fail('SOURCE_FORBIDDEN','来源须是本人已归档的固定客户事件',403);
    const lead=source.lead,customerId='cu_'+hash(`${lead.platform}:author:${lead.author_id}`);
    if(source.customer_id!==customerId||!(await contacts.get('customer:'+customerId)))fail('SOURCE_CONFLICT','来源客户身份不一致',409);
    for(const [label,value] of [['平台',lead.platform],['客户UID',lead.author_id],['评论ID',lead.comment_id]])ident(value,label);
    const contact=`platform:${lead.platform}:${lead.author_id}`;
    if(payload.contact_reference!==undefined&&payload.contact_reference!==contact)
      fail('CONTACT_UNSUPPORTED','云交接目前只接受原平台身份；本机加密联系方式不能跨电脑传递');
    exact(payload.consent,['status','evidence_reference','notice_version']);
    if(payload.consent.status!=='granted'||!/^consent:[a-f0-9]{32}$/.test(payload.consent.evidence_reference||''))fail('CONSENT_REQUIRED','请留存对实际接收方及用途的客户明确同意');
    const consent={status:'granted',evidence_reference:payload.consent.evidence_reference,
      notice_version:text(payload.consent.notice_version,'告知版本',80),evidence_source:'operator_recorded',independently_verified:false};
    if(await repo.get('withdrawal:'+consent.evidence_reference))fail('CONSENT_WITHDRAWN','此客户授权已撤回，不能换编号复用');
    const receiver=recipient(state,payload.recipient_id),purpose=text(payload.purpose,'交接用途');
    if(payload.qualification!=='qualified')fail('QUALIFICATION_REQUIRED','请先完成人工来源、授权与资料核对');
    const id='hc_'+operationId,item={channel_id:id,company_id:companyId,source_owner:actor.username,
      source_event_id:source.event_id,customer_id:customerId,source:{platform:lead.platform,author_id:lead.author_id,
        comment_id:lead.comment_id,source_lead_hash:hash(lead.id||''),device_id:source.device_id,
        original_text_hash:hash(lead.text||''),evidence_source:'device_report',platform_provenance_verified:false},
      recipient_id:receiver.id,recipient_name:receiver.name,purpose,consent,contact_reference:contact,
      qualification:'qualified',status:'draft',attribution_status:'unconfirmed',revision:1,
      created_at:now,updated_at:now,order_links:[]};
    // Recheck immediately before saving; earlier awaited evidence reads do not
    // authorize a new handoff after a trusted feature change.
    productEntitlements.requireFeature('handoff');
    await append(repo,item,actor,'acquisition_channel_register',now);await repo.set('channel:'+id,item);
    for(const index of ['all','source:'+hash(actor.username),'recipient:'+receiver.id])await addIndex(repo,index,id);
    return item;
  }
  async function submissionCurrentFence(repo,contacts,state,identity,item,scope,committed=false) {
    const checkPrincipal=()=>{
      const current=statusActor(state,identity);
      if(hash(current)!==scope.actor||current.username!==item.source_owner)
        fail('AUTH_REQUIRED','当前来源员工权限已变化，请核对原提交编号',401);
      if(hash(policy(state))!==scope.policy)
        fail('SUBMISSION_SCOPE_CHANGED','当前资源部配置已变化，请重新核对',409);
      const receiver=recipient(state,item.recipient_id);
      if(receiver.name!==item.recipient_name)
        fail('SUBMISSION_SCOPE_CHANGED','当前接收方已变化，请重新核对',409);
      productEntitlements.requireFeature('handoff');
      return current;
    };
    const actor=checkPrincipal(),first=await itemFor(repo,state,actor,item.channel_id);
    if(hash(first)!==hash(item))fail('REVISION_CONFLICT','公司草稿已变化，请核对原编号',409);
    let previousSource=null;
    for(let pass=0;pass<2;pass++) {
      const source=(await contacts.get('event:'+item.source_event_id))?.record;
      const lead=source?.lead;
      if(!source||source.event_id!==item.source_event_id||source.employee!==item.source_owner||
          source.source!=='device_report'||source.customer_id!==item.customer_id||!lead||
          item.customer_id!=='cu_'+hash(`${lead.platform}:author:${lead.author_id}`))
        fail('SOURCE_CONFLICT','原客户来源已变化，请保留原提交编号',409);
      const expected={platform:lead.platform,author_id:lead.author_id,comment_id:lead.comment_id,
        source_lead_hash:hash(lead.id||''),device_id:source.device_id,
        original_text_hash:hash(lead.text||''),evidence_source:'device_report',platform_provenance_verified:false};
      if(hash(item.source)!==hash(expected)||item.contact_reference!==`platform:${lead.platform}:${lead.author_id}`||
          (previousSource!==null&&previousSource!==hash(source))||!(await contacts.get('customer:'+item.customer_id)))
        fail('SOURCE_CONFLICT','原客户事件或公司草稿来源不一致，请保留原编号',409);
      previousSource=hash(source);
      if(!(await authorization(repo,item)))fail('CONSENT_WITHDRAWN','客户授权已撤回，不能提交');
      checkPrincipal();
    }
    const active=await repo.get('active:'+item.customer_id);
    if(active?.channel_id&&active.channel_id!==item.channel_id)
      fail('DUPLICATE_REVIEW','同企业已有此客户交接，请独立核对',409);
    if(committed&&active?.channel_id!==item.channel_id)
      fail('SUBMISSION_SCOPE_CHANGED','原提交的客户占用记录需核对',409);
    const second=await itemFor(repo,state,checkPrincipal(),item.channel_id);
    if(hash(second)!==hash(item))fail('REVISION_CONFLICT','当前交接已变化，请核对原编号',409);
    if(!(await authorization(repo,item)))fail('CONSENT_WITHDRAWN','客户授权已撤回，不能提交');
    checkPrincipal();
  }
  async function receiptCurrentFence(repo,state,identity,item,scope) {
    const checkPrincipal=()=>{
      const current=statusActor(state,identity);
      if(hash(current)!==scope.actor)
        fail('AUTH_REQUIRED','当前接收员工权限已变化，请核对原接收编号',401);
      if(hash(policy(state))!==scope.policy)
        fail('RECEIPT_SCOPE_CHANGED','当前资源部配置已变化，请重新核对',409);
      if(current.username===item.source_owner||!receives(state,current,item.recipient_id))
        fail('RECEIVER_REQUIRED','需另一位可信授权资源部主体确认',403);
      if(recipient(state,item.recipient_id).name!==item.recipient_name)
        fail('RECEIPT_SCOPE_CHANGED','当前接收部门已变化，请重新核对',409);
      return current;
    };
    const first=await itemFor(repo,state,checkPrincipal(),item.channel_id);
    if(hash(first)!==hash(item))fail('REVISION_CONFLICT','当前公司交接已变化，请核对原编号',409);
    if(!(await authorization(repo,item)))fail('CONSENT_WITHDRAWN','客户授权已撤回，不能接收');
    const second=await itemFor(repo,state,checkPrincipal(),item.channel_id);
    if(hash(second)!==hash(item))fail('REVISION_CONFLICT','当前公司交接已变化，请核对原编号',409);
    if(!(await authorization(repo,item)))fail('CONSENT_WITHDRAWN','客户授权已撤回，不能接收');
    checkPrincipal();
  }
  async function mutate(repo,contacts,state,actor,item,payload,now,identity,submitScope) {
    const op=payload.operation,owner=item.source_owner===actor.username;
    if(!Number.isSafeInteger(payload.expected_revision)||payload.expected_revision!==item.revision)fail('REVISION_CONFLICT','交接已更新，请刷新再核对',409);
    const valid=await authorization(repo,item),claimKey='active:'+item.customer_id;
    if(op==='acquisition_handoff_submit') {
      productEntitlements.requireFeature('handoff');
      if(!owner)fail('FORBIDDEN','只有来源本人可以提交',403);
      if(item.status!=='draft'||!valid)fail('INVALID_STATE','交接未核实或客户授权已撤回');
      const active=await repo.get(claimKey);
      if(active?.channel_id&&active.channel_id!==item.channel_id)fail('DUPLICATE_REVIEW','同企业已有此客户交接，请独立核对',409);
      await submissionCurrentFence(repo,contacts,state,identity,item,submitScope);
      await repo.set(claimKey,{channel_id:item.channel_id});item.status='submitted';item.submitted_at=now;
    } else if(op==='acquisition_handoff_receipt') {
      if(owner||!receives(state,actor,item.recipient_id))fail('RECEIVER_REQUIRED','需另一位可信授权资源部主体确认',403);
      if(item.status!=='submitted'||!valid)fail('INVALID_STATE','交接不在待接收状态或授权已撤回');
      const states={accept:'accepted',reject:'rejected',needs_information:'needs_information',duplicate:'duplicate_pending_review',existing_customer:'existing_customer_pending_review'};
      if(!states[payload.decision])fail('INVALID_INPUT','接收决定无效');
      const reasons={reject:['not_qualified','outside_service_area'],needs_information:['needs_information'],duplicate:['duplicate'],existing_customer:['existing_customer']};
      if(payload.decision!=='accept'&&!reasons[payload.decision].includes(payload.reason_code))fail('REASON_REQUIRED','拒收或待核对必须记录真实原因');
      if(payload.decision==='accept'&&payload.reason_code!==undefined)fail('INVALID_INPUT','接收决定不能混入拒收原因');
      await receiptCurrentFence(repo,state,identity,item,submitScope);
      item.status=states[payload.decision];item.receipt={actor:actor.username,recipient_id:item.recipient_id,
        decision:payload.decision,evidence_reference:reference(payload.evidence_reference),recorded_at:now,
        reason_code:payload.reason_code||null,authenticated:true,evidence_independently_verified:false};
      if(['duplicate','existing_customer'].includes(payload.decision))item.attribution_status=item.status;
    } else if(op==='acquisition_handoff_review') {
      if(owner||!manages(state,actor))fail('REVIEWER_REQUIRED','需另一位有权审核人独立核对',403);
      if(!['duplicate_pending_review','existing_customer_pending_review','disputed'].includes(item.status))fail('INVALID_STATE','此交接没有待审核争议');
      if(!['reviewed_unique','not_qualified','needs_information'].includes(payload.reason_code))fail('REASON_REQUIRED','独立核对结论无效');
      item.review={actor:actor.username,reason_code:payload.reason_code,evidence_reference:reference(payload.evidence_reference),recorded_at:now};
      item.status=payload.reason_code==='reviewed_unique'?'draft':payload.reason_code==='not_qualified'?'rejected':'needs_information';item.attribution_status='unconfirmed';
    } else if(op==='acquisition_handoff_withdraw'||op==='acquisition_handoff_dispute') {
      if(!owner)fail('FORBIDDEN','只有来源本人可以撤回或登记争议',403);
      if(item.status==='withdrawn')fail('INVALID_STATE','交接已撤回');
      if(!['customer_withdrew','incorrect_information','duplicate','existing_customer','ownership_conflict'].includes(payload.reason_code))fail('REASON_REQUIRED','请记录实际撤回或争议原因');
      if(op==='acquisition_handoff_dispute') { item.status='disputed';item.attribution_status='disputed';
        item.dispute={reason_code:payload.reason_code,evidence_reference:reference(payload.evidence_reference),recorded_at:now}; }
      else { item.status='withdrawn';item.withdrawal_reason=payload.reason_code;item.attribution_status='withdrawn_pending_review';
        if(payload.reason_code==='customer_withdrew') { item.consent.status='withdrawn';await repo.set('withdrawal:'+item.consent.evidence_reference,
          {consent_reference:item.consent.evidence_reference,actor:actor.username,channel_id:item.channel_id,occurred_at:now}); } }
    } else if(op==='acquisition_handoff_order_link') {
      if(owner||!(manages(state,actor)||receives(state,actor,item.recipient_id)))fail('FORBIDDEN','订单关联需独立有权主体登记',403);
      if(item.status!=='accepted'||!valid)fail('INVALID_STATE','需已有授权接收记录及有效同意');
      // An existing order's identifier can legitimately contain a date or a
      // long numeric sequence. It is not a free-form contact input; the actual
      // archived order and customer binding must exist below before any write.
      const order=payload.order_no;if(typeof order!=='string'||!/^[A-Za-z0-9_.-]{1,120}$/.test(order))fail('INVALID_INPUT','订单号无效');
      const deal=await contacts.get('deal:'+order),linked=await repo.get('order:'+order);
      if(!deal||deal.customer_id!==item.customer_id)fail('ORDER_MISMATCH','订单不存在或客户不一致',409);
      if(!Number.isSafeInteger(payload.order_revision)||payload.order_revision!==deal.revision)fail('ORDER_REVISION_CONFLICT','订单已变化，请重新读取',409);
      if(linked&&linked.channel_id!==item.channel_id)fail('ORDER_CONFLICT','该订单已关联另一渠道，请核对争议',409);
      if(item.order_links.some(row=>row.order_no===order))fail('ORDER_CONFLICT','此订单已关联，请核对原记录',409);
      const link={order_no:order,order_revision:deal.revision,order_status_at_link:deal.status,
        evidence_reference:reference(payload.evidence_reference),linked_by:actor.username,linked_at:now};
      item.order_links.push(link);await repo.set('order:'+order,{channel_id:item.channel_id,customer_id:item.customer_id});
    }
    if(['withdrawn','draft','rejected','needs_information'].includes(item.status)) {
      const active=await repo.get(claimKey);if(active?.channel_id===item.channel_id)await repo.set(claimKey,{channel_id:null});
    }
    item.revision++;await append(repo,item,actor,op,now);await repo.set('channel:'+item.channel_id,item);return item;
  }
  async function read(repo,state,actor,payload,transaction,identity) {
    const scope=()=>hash({actor:statusActor(state,identity),policy:policy(state)}),before=scope();
    const view=payload.view||'owned';let index;
    const offset=payload.offset??0,limit=payload.limit??(view==='received'?10:20),maximum=view==='received'?15:25;
    // A received row has an additional bound reread below: six reads per row.
    // Fifteen rows plus the company/index/page reads stay within 100 operations.
    if(!Number.isSafeInteger(offset)||offset<0||!Number.isSafeInteger(limit)||limit<1||limit>maximum)
      fail('INVALID_INPUT',`交接每页最多${maximum}条，请按分页读取`);
    let authorizedRecipients=null;
    if(view==='owned')index='source:'+hash(actor.username);
    else if(view==='received') {
      const assigned=policy(state).receivers?.[actor.username];
      authorizedRecipients=(Array.isArray(policy(state).recipients)?policy(state).recipients:[])
        .filter(row=>Array.isArray(assigned)&&assigned.includes(row.id)).map(row=>recipient(state,row.id));
      if(!authorizedRecipients.length)fail('FORBIDDEN','当前账号没有公司资源部接收范围',403);
      if(payload.recipient_id===undefined) {
        if(scope()!==before)fail('LIST_SCOPE_CHANGED','当前成员或接收权限已变化，请重新读取',409);
        return {items:[],total:null,offset,has_more:false,authorized_recipients:authorizedRecipients,
          selected_recipient_id:null,selection_required:true};
      }
      recipient(state,payload.recipient_id);
      if(!receives(state,actor,payload.recipient_id))fail('FORBIDDEN','没有此部门接收权限',403);
      index='recipient:'+payload.recipient_id;
    }
    else if(view==='managed'&&manages(state,actor))index='all';else fail('FORBIDDEN','交接清单范围无权限',403);
    const total=(await repo.get('index:'+index))?.count??0,items=[],rawItems=[],pages=new Map();
    if(!Number.isSafeInteger(total)||total<0)fail('INDEX_CONFLICT','交接索引总数需核对',409);
    for(let cursor=offset;cursor<Math.min(total,offset+limit);cursor++) {
      const pageNo=Math.floor(cursor/50);if(!pages.has(pageNo))pages.set(pageNo,(await repo.get(`index:${index}:${pageNo}`))?.items||[]);
      const id=pages.get(pageNo)[cursor%50];if(!id)fail('INDEX_CONFLICT','交接索引需核对',409);
      const item=await itemFor(repo,state,actor,id);rawItems.push(item);items.push(await publicItem(repo,state,actor,item));
    }
    if(view==='received') {
      for(let position=0;position<rawItems.length;position++) {
        const bound=await readBoundItem(transaction,state,statusActor(state,identity),rawItems[position].channel_id);
        if(hash(bound.item)!==hash(rawItems[position])||bound.current_consent_valid!==items[position].current_consent_valid)
          fail('LIST_CHANGED','公司交接或客户授权已变化，请重新读取',409);
      }
    }
    const finalActor=statusActor(state,identity);
    if(scope()!==before||rawItems.some(item=>!visible(state,finalActor,item))||
        (view==='received'&&!receives(state,finalActor,payload.recipient_id)))
      fail('LIST_SCOPE_CHANGED','当前成员或接收权限已变化，请重新读取',409);
    return {items,total,offset,has_more:offset+items.length<total,...(view==='received'?{
      authorized_recipients:authorizedRecipients,selected_recipient_id:payload.recipient_id,selection_required:false}:{})};
  }
  async function detailRead(repo,state,actor,payload,transaction,identity) {
    const scope=()=>hash({actor:statusActor(state,identity),policy:policy(state)}),before=scope();
    const first=await readBoundItem(transaction,state,actor,payload.channel_id);
    const projected=await publicItem(repo,state,actor,first.item);
    const second=await readBoundItem(transaction,state,statusActor(state,identity),payload.channel_id);
    if(hash(first)!==hash(second)||projected.current_consent_valid!==second.current_consent_valid)
      fail('DETAIL_CHANGED','当前公司交接或授权已变化，请核对原编号',409);
    const finalActor=statusActor(state,identity);
    if(scope()!==before||!visible(state,finalActor,second.item))
      fail('DETAIL_SCOPE_CHANGED','当前公司成员或接收权限已变化，请核对原编号',409);
    return {item:projected};
  }
  function statusActor(state,identity) {
    if(!state||state.companyId!==companyId)fail('TENANT_MISMATCH','企业隔离检查失败',403);
    const now=Math.floor(clock()/1000),session=state.sessions?.find(row=>row.digest===identity?.sessionDigest&&row.username===identity?.username&&row.expires>now);
    const actor=session&&state.users?.find(row=>row.username===session.username&&!row.disabled&&['admin','operator'].includes(row.role));
    if(!actor)fail('AUTH_REQUIRED','账号或当前会话已失效，请重新核对',401);
    return actor;
  }
  async function operationStatus(repo,state,actor,payload,transaction,identity) {
    const action=payload.operation_action,key=payload.idempotency_key,principal=hash(actor);
    const operationId=hash([companyId,actor.username,action,key]),stored=await repo.get('operation:'+operationId);
    let original=null,current=null;
    if(stored) {
      const fields=['actor','operation','payload_hash','channel_id','revision'];
      if(Object.keys(stored).length!==fields.length||Object.keys(stored).some(field=>!fields.includes(field))||
          stored.actor!==actor.username||stored.operation!==action||typeof stored.payload_hash!=='string'||!HEX.test(stored.payload_hash)||
          typeof stored.channel_id!=='string'||!CHANNEL.test(stored.channel_id)||!Number.isSafeInteger(stored.revision)||stored.revision<1||
          (action==='acquisition_channel_register'&&stored.channel_id!=='hc_'+operationId))
        fail('OPERATION_CONFLICT','原操作回执字段需核对，请保留原编号',409);
      const historical=await repo.get(`event:${stored.channel_id}:${stored.revision}`);
      const auditFields=['channel_id','revision','actor','operation','occurred_at','status','source_owner','previous_hash','snapshot_hash','chain_hash'];
      const allowedStatuses={acquisition_channel_register:['draft'],acquisition_handoff_submit:['submitted'],
        acquisition_handoff_receipt:['accepted','rejected','needs_information','duplicate_pending_review','existing_customer_pending_review'],
        acquisition_handoff_review:['draft','rejected','needs_information'],acquisition_handoff_withdraw:['withdrawn'],
        acquisition_handoff_dispute:['disputed'],acquisition_handoff_order_link:['accepted']};
      if(!historical||Object.keys(historical).length!==auditFields.length||Object.keys(historical).some(field=>!auditFields.includes(field))||
          historical.channel_id!==stored.channel_id||historical.revision!==stored.revision||historical.actor!==actor.username||
          historical.operation!==action||!Number.isSafeInteger(historical.occurred_at)||historical.occurred_at<0||
          historical.occurred_at>Math.floor(clock()/1000)||!allowedStatuses[action].includes(historical.status)||
          typeof historical.source_owner!=='string'||!historical.source_owner||
          typeof historical.snapshot_hash!=='string'||!HEX.test(historical.snapshot_hash)||
          typeof historical.chain_hash!=='string'||!HEX.test(historical.chain_hash)||typeof historical.previous_hash!=='string'||
          (historical.revision===1?historical.previous_hash!=='':!HEX.test(historical.previous_hash))||
          historical.chain_hash!==hash(Object.fromEntries(Object.entries(historical).filter(([field])=>field!=='chain_hash'))))
        fail('OPERATION_AUDIT_CONFLICT','原操作历史审计需核对，请保留原编号',409);
      // Current visibility/consent and original execution are separate facts.
      // Check both before and after the awaited current ledger reads.
      const first=await readBoundItem(transaction,state,statusActor(state,identity),stored.channel_id);
      const second=await readBoundItem(transaction,state,statusActor(state,identity),stored.channel_id);
      if(hash(first)!==hash(second)||second.item.revision<stored.revision||
          second.item.source_owner!==historical.source_owner||!STATUSES.has(second.item.status)||
          !Number.isSafeInteger(second.item.updated_at)||second.item.updated_at<historical.occurred_at||
          typeof second.current_consent_valid!=='boolean')
        fail('OPERATION_CURRENT_CONFLICT','当前交接或授权已变化，请重新核对原编号',409);
      const item=second.item;
      const receipt=item.receipt;
      if(receipt?.decision==='accept'&&(receipt.authenticated!==true||typeof receipt.actor!=='string'||!receipt.actor||
          receipt.actor===item.source_owner||receipt.recipient_id!==item.recipient_id||
          !Number.isSafeInteger(receipt.recorded_at)||receipt.recorded_at<0||receipt.recorded_at>Math.floor(clock()/1000)||
          typeof receipt.evidence_reference!=='string'||!REF.test(receipt.evidence_reference)||
          receipt.evidence_independently_verified!==false||receipt.reason_code!==null))
        fail('OPERATION_CURRENT_CONFLICT','当前接收记录需核对，请保留原编号',409);
      const finalActor=statusActor(state,identity);
      if(hash(finalActor)!==principal)fail('AUTH_REQUIRED','当前员工权限已变化，请重新核对',401);
      if(!visible(state,finalActor,item))fail('FORBIDDEN','当前已无权读取此交接，请核对公司权限',403);
      original={payload_hash:stored.payload_hash,channel_id:stored.channel_id,revision:stored.revision,
        historical_status:historical.status,occurred_at:historical.occurred_at,
        historical_event_self_hash_verified:true,full_historical_chain_verified:false};
      current={channel_id:item.channel_id,revision:item.revision,status:item.status,current_consent_valid:second.current_consent_valid,
        historical_resource_receipt_recorded:receipt?.authenticated===true&&receipt.decision==='accept'&&
          receipt.actor!==item.source_owner&&receipt.recipient_id===item.recipient_id,
        receipt_evidence_independently_verified:false};
    }
    const finalActor=statusActor(state,identity);
    if(hash(finalActor)!==principal)fail('AUTH_REQUIRED','当前员工权限已变化，请重新核对',401);
    return {contract:'handoff_operation_receipt_v1',read_only:true,mutation_committed:false,
      storage_scope:'company_server_ledger',authenticated_actor:finalActor.username,observed_at:Math.floor(clock()/1000),
      operation_action:action,idempotency_key:key,state:stored?'recorded':'unknown',original_execution_confirmed:stored?true:null,
      original_operation:original,current_handoff:current,auto_retry:false,platform_delivery_verified:false,settlement_active:false,
      financial_receipt_verified:false,cooperation_policy_verified:false,verified_cash_cents:null,verified_paid_commission_cents:null};
  }
  async function handle(payload,identity) {
    const operation=payload?.operation;if(!OPERATIONS.has(operation))return null;
    try {
      const base=['environment_id','operation'],common=['channel_id','expected_revision','idempotency_key'];
      const fields={acquisition_channel_register:['source_event_id','recipient_id','purpose','consent','contact_reference','qualification','idempotency_key'],
        acquisition_handoff_submit:common,acquisition_handoff_receipt:[...common,'decision','reason_code','evidence_reference'],
        acquisition_handoff_review:[...common,'reason_code','evidence_reference'],acquisition_handoff_withdraw:[...common,'reason_code'],
        acquisition_handoff_dispute:[...common,'reason_code','evidence_reference'],acquisition_handoff_order_link:[...common,'order_no','order_revision','evidence_reference'],
        acquisition_handoff_list:['view','recipient_id','offset','limit'],acquisition_handoff_detail:['channel_id'],
        acquisition_handoff_operation_status:['operation_action','idempotency_key']};
      exact(payload,[...base,...fields[operation]]);
      if(operation===STATUS_OPERATION&&(!WRITE.has(payload.operation_action)||typeof payload.idempotency_key!=='string'||!KEY.test(payload.idempotency_key)))
        fail('INVALID_INPUT','请按原交接动作和原操作编号核对，不能创建新请求');
      if(Buffer.byteLength(JSON.stringify(payload))>50000)fail('PAYLOAD_TOO_LARGE','交接请求过大');
      const result=await store.transaction(async(state,transaction)=>{
        if(!state||state.companyId!==companyId)fail('TENANT_MISMATCH','企业隔离检查失败',403);
        const now=Math.floor(clock()/1000),session=state.sessions?.find(row=>row.digest===identity?.sessionDigest&&row.username===identity?.username&&row.expires>now);
        const actor=session&&state.users?.find(row=>row.username===session.username&&!row.disabled&&['admin','operator'].includes(row.role));
        if(!actor)fail('AUTH_REQUIRED','账号已失效，请重新登录',401);
        const submitScope=['acquisition_handoff_submit','acquisition_handoff_receipt'].includes(operation)?{actor:hash(actor),policy:hash(policy(state))}:null;
        const repo=repoFor(transaction,companyId),contacts=contactRepoFor(transaction,companyId);
        if(operation===STATUS_OPERATION)return {state,result:await operationStatus(repo,state,actor,payload,transaction,identity)};
        if(operation==='acquisition_handoff_detail')return {state,result:await detailRead(repo,state,actor,payload,transaction,identity)};
        if(READ.has(operation))return {state,result:await read(repo,state,actor,payload,transaction,identity)};
        if(!KEY.test(payload.idempotency_key||''))fail('IDEMPOTENCY_REQUIRED','请保留稳定操作编号');
        const operationId=hash([companyId,actor.username,operation,payload.idempotency_key]),fingerprint=hash(payload);
        const existing=await repo.get('operation:'+operationId);
        if(existing) {if(existing.payload_hash!==fingerprint)fail('KEY_CONFLICT','原编号已用于不同请求',409);
          const item=await itemFor(repo,state,actor,existing.channel_id);return {state,result:{item:await publicItem(repo,state,actor,item),replayed:true}};}
        // A completed identical operation remains recoverable after expiry.
        // Only new acquisition execution is subject to the commercial gate.
        if(['acquisition_channel_register','acquisition_handoff_submit'].includes(operation))productEntitlements.requireFeature('handoff');
        const item=operation==='acquisition_channel_register'?await register(repo,contacts,state,actor,payload,now,operationId)
          :await mutate(repo,contacts,state,actor,await itemFor(repo,state,actor,payload.channel_id),payload,now,identity,submitScope);
        await repo.set('operation:'+operationId,{actor:actor.username,operation,payload_hash:fingerprint,channel_id:item.channel_id,revision:item.revision});
        const projected=await publicItem(repo,state,actor,item);
        if(operation==='acquisition_handoff_submit')await submissionCurrentFence(repo,contacts,state,identity,item,submitScope,true);
        if(operation==='acquisition_handoff_receipt')await receiptCurrentFence(repo,state,identity,item,submitScope);
        return {state,result:{item:projected,replayed:false}};
      });
      if(operation===STATUS_OPERATION)return {status:200,data:{operation_receipt:result,read_only:true,mutation_committed:false,auto_retry:false}};
      return {status:200,data:{...result,server_recorded:true,platform_delivery_verified:false,attribution_confirmed:false,settlement_active:false,
        ...(['acquisition_handoff_detail','acquisition_handoff_list'].includes(operation)?{read_only:true,mutation_committed:false,auto_retry:false}:{})}};
    } catch(error) {
      if(error instanceof HandoffError||error instanceof ProductEntitlementError)return {status:error.status,data:{error:error.message,code:error.code,mutation_committed:false,
        ...(operation===STATUS_OPERATION?{read_only:true,original_execution_confirmed:null,auto_retry:false}:
          ['acquisition_handoff_detail','acquisition_handoff_list'].includes(operation)?{read_only:true,auto_retry:false}:{})}};
      if(operation===STATUS_OPERATION)return {status:503,data:{error:'公司原操作回执暂不可核对，请保留原编号',code:'HANDOFF_OPERATION_UNAVAILABLE',
        mutation_committed:false,read_only:true,original_execution_confirmed:null,auto_retry:false}};
      if(operation==='acquisition_handoff_detail')return {status:503,data:{error:'公司原渠道详情暂不可读，请保留原交接编号',code:'HANDOFF_DETAIL_UNAVAILABLE',
        mutation_committed:false,read_only:true,auto_retry:false}};
      if(operation==='acquisition_handoff_list')return {status:503,data:{error:'公司收件清单暂不可读，请保留原渠道编号',code:'HANDOFF_LIST_UNAVAILABLE',
        mutation_committed:false,read_only:true,auto_retry:false}};
      throw error;
    }
  }
  // Server-only repository access. The caller supplies its re-authenticated
  // transaction actor; raw item must be projected before any public response.
  async function readBoundItem(transaction,state,actor,channelId) {
    if(!state||state.companyId!==companyId)fail('TENANT_MISMATCH','企业隔离检查失败',403);
    const repo=repoFor(transaction,companyId),item=await itemFor(repo,state,actor,channelId);
    return {item,current_consent_valid:await authorization(repo,item)};
  }
  return {handle,readBoundItem};
}
module.exports={createHandoffLedger,OPERATIONS,HandoffError,repoFor};
