"""Phase17 actual Business/Core seam; no live account, CLI, provider or network.

This checks the executor used by the proposed original-task entry. UI command
key recovery remains a separate actual app/local-transport responsibility.
"""
from contextlib import ExitStack
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import sys
import tempfile
import time
from types import SimpleNamespace
import unittest
from unittest import mock

APP=Path(__file__).resolve().parents[1]
PROJECT=APP.parents[1]
sys.path.insert(0,str(APP/'src'))
from core import Core, CoreError
from assistant.business import BusinessExecutor
from assistant.acquisition_strategy import AcquisitionStrategy, ENTITY
from assistant.strategy_tasks import StrategyTasks
from assistant.acquisition_run_preflight import AcquisitionRunPreflight


class SingleBatchEntryFixture:
    def __init__(self,base):
        self.base=Path(base);resources=self.base/'resources';(resources/'adapters').mkdir(parents=True)
        manifest={'id':'xiaohongshu','executable':sys.executable,'mapper':'xhs_v1','isolation_guard':True,
                  'search_verified':True,'search_args':['search','{keyword}','--json'],
                  'comments_args':['comments','{note_url}','--json']}
        (resources/'adapters'/'xiaohongshu.json').write_text(json.dumps(manifest),encoding='utf-8')
        self.core=Core(self.base/'db',resources);self.core.continuous.autostart=False
        self.company={'id':'fangyu-apartment-client','name':'Phase17 synthetic company',
            'platforms':['xiaohongshu'],'runtime':{'xiaohongshu_automation':'enabled'},
            'acquisitionStrategy':{'operatorOwners':['phase17-owner']}}
        self.core.deployment_config=deepcopy(self.company)
        self.server=SimpleNamespace(core=self.core,company=self.company,
            platform_read_license_policy={'xiaohongshu':True})
        self.executor=BusinessExecutor(self.server,'phase17-fixture-env',self.company['id'],'phase17-owner')
        self.executor.account_claim=lambda account:None
        self.command('workspace_state');self.user=self.core.store.get('users',self.executor.user_id)
        self.account=self.core.handle('save',{'entity':'accounts','record':{
            'name':'合成本人账号','platform':'xiaohongshu','status':'ready','cloud_owner':self.executor.owner,
            'platform_uid':'phase17-synthetic-platform-uid'}},self.user)
        self.strategy=AcquisitionStrategy(self.core,self.executor.tenant,self.executor.owner,self.company)
        self.strategy.execute('strategy_import',{'expected_revision':0,'idempotency_key':'phase17-import',
            'mode':'replace','keywords':['PHASE17_PRIVATE_A','PHASE17_PRIVATE_B']},self.user)
        self.strategy.execute('strategy_save',{'expected_revision':1,'idempotency_key':'phase17-enable',
            'enabled':True,'active_batch_size':2,'total_query_quota':20},self.user)
        self.tasks=StrategyTasks(self.core,self.executor.tenant,self.executor.owner,self.company)
        result=self.tasks.execute('strategy_task_create',{'expected_revision':2,'idempotency_key':'phase17-original-create',
            'platform':'xiaohongshu','account_id':self.account['id'],'batch_size':2,'name':'本人已保存私有快照'},self.user)
        self.task_id=result['task']['id'];self.claims=[];self.adapter_calls=[];self.safe_attempts=0
        self.activity=self.core.store.directory/'accounts'/self.executor.tenant/self.account['id']/'platform-activity.jsonl'
        self.activity.parent.mkdir(parents=True)
        (self.activity.parent/'synthetic-only-marker').write_text('not a cookie',encoding='utf-8')
        self.activity_signal(200)
        self.core.adapters.search=self.search;self.core.adapters.comments=self.comments
        self.core.adapters.verify=lambda *a,**k:(_ for _ in ()).throw(AssertionError('no login/real search verification'))
        self.preflight=AcquisitionRunPreflight(self.core,self.executor.tenant,self.executor.owner,self.company,
            device_id='phase17-fixture-device',scope_guard=lambda:True,
            license_policy_provider=lambda:self.server.platform_read_license_policy)

    def activity_signal(self,status):
        now=time.time();rows=[{'at':now-2,'stage':'started','kind':'search','request_id':'phase17-fixture'},
             {'at':now-1,'stage':'finished','kind':'search','request_id':'phase17-fixture','status':status}]
        self.activity.write_text(''.join(json.dumps(row)+'\n' for row in rows),encoding='utf-8')

    def command(self,action,data=None):
        return self.executor({'id':'phase17-original-run-command','owner':self.executor.owner,
            'principal':{'username':self.executor.owner,'role':'operator'},'action':action,'data':data or {}})

    def read(self):return self.tasks.execute('strategy_task_get',{'task_id':self.task_id},self.user)
    def check(self):return self.preflight.execute('acquisition_run_preflight',{'task_id':self.task_id},self.user)

    def search(self,platform,query):
        # Keep the mature activity risk check before our synthetic successful
        # read; overriding the external adapter must not silently bypass it.
        self.safe_attempts+=1
        self.core.adapters.require_account_safe(platform,query['_account_dir'])
        self.adapter_calls.append(('search',tuple(query['keywords'])))
        query['_page_info']={'has_more':False}
        return [{'url':'https://www.xiaohongshu.com/explore/650000000000000000000001',
                 'title':'合成公寓来源','author':'合成房源账号','author_id':'phase17-source-author'}]

    def comments(self,platform,query):
        self.core.adapters.require_account_safe(platform,query['_account_dir'])
        self.adapter_calls.append(('comments',()))
        query['_page_info']={'has_more':False}
        return [{'source_id':'comment:phase17-synthetic-comment','comment_id':'phase17-synthetic-comment',
                 'author':'合成租客','author_id':'phase17-synthetic-customer','text':'想在上海看一居室，预算3500，十月底入住。',
                 'region':'上海','published_at':'2026-10-10T08:00:00+08:00'}]

    def forbid_real(self):
        stack=ExitStack()
        for target in ('socket.socket.connect','core.adapters.subprocess.Popen'):
            stack.enter_context(mock.patch(target,side_effect=AssertionError('no real external request')))
        stack.enter_context(mock.patch.object(self.executor,'_ai_cloud',side_effect=AssertionError('no paid model/cloud')))
        return stack

    def close(self):self.core.close_continuous_scheduler(wait=True);self.core.adapters.close()


class PrivateSingleBatchEntryTests(unittest.TestCase):
    def setUp(self):
        root=PROJECT/'work/product-upgrade-20261009/tmp/phase17-single-batch';root.mkdir(parents=True,exist_ok=True)
        self.temp=tempfile.TemporaryDirectory(dir=root);self.fixtures=[];self.f=self.make('default')
    def make(self,name):
        f=SingleBatchEntryFixture(Path(self.temp.name)/name);self.fixtures.append(f);return f
    def tearDown(self):
        for f in self.fixtures:f.close()
        self.temp.cleanup()

    def test_original_snapshot_runs_one_batch_without_new_task_or_continuous_route(self):
        f=self.f;self.assertEqual(f.check()['state'],'eligible_for_explicit_run')
        original=f.core.store.get('tasks',f.task_id);calls=[];handle=f.core.handle
        def traced(action,data=None,user=None,**kwargs):calls.append(action);return handle(action,data,user,**kwargs)
        with f.forbid_real(),mock.patch.object(f.core,'handle',traced):
            result=f.command('task_run',{'task_id':f.task_id,'max_batches':1})
        self.assertEqual(result['task']['id'],f.task_id)
        self.assertEqual(result['batches'],1);self.assertEqual(result['imported'],1)
        self.assertEqual(len([c for c in f.adapter_calls if c[0]=='search']),1)
        self.assertEqual(len(f.core.store.list('tasks',f.executor.tenant)),1)
        for forbidden in ('save','continuous_start','continuous_resume','resume_task'):
            self.assertNotIn(forbidden,calls)
        saved=f.core.store.get('tasks',f.task_id)
        self.assertEqual(saved['strategy_source'],original['strategy_source'])
        self.assertEqual(saved['keywords'],original['keywords'])
        self.assertFalse(result['strategy_completion']['finished'])
        self.assertNotIn('PHASE17_PRIVATE_',json.dumps(result))

    def test_late_http461_rejects_fixture_platform_read_and_retains_original_task(self):
        f=self.f;self.assertEqual(f.check()['state'],'eligible_for_explicit_run')
        f.executor.account_claim=lambda account:f.activity_signal(461)
        try:
            with f.forbid_real():result=f.command('task_run',{'task_id':f.task_id,'max_batches':1})
        except (CoreError,ValueError):result=None
        if result is not None:self.assertEqual(result['status'],'failed')
        self.assertEqual(f.adapter_calls,[])
        self.assertEqual(len(f.core.store.list('tasks',f.executor.tenant)),1)
        self.assertIsNotNone(f.core.store.get(ENTITY,f.strategy.ident)['lease'])

    def test_claim_gap_cannot_execute_changed_private_snapshot_or_lease(self):
        for kind in ('snapshot','lease','management','disabled_strategy','expired_lease','disabled_actor'):
            with self.subTest(kind=kind):
                f=self.f if kind=='snapshot' else self.make(kind)
                self.assertEqual(f.check()['state'],'eligible_for_explicit_run')
                def mutate(account):
                    if kind=='snapshot':
                        task=f.core.store.get('tasks',f.task_id);task['keywords'][0]='FORGED_PRIVATE_WORD';f.core.store.put('tasks',task)
                    elif kind=='lease':
                        policy=f.core.store.get(ENTITY,f.strategy.ident);policy['lease']['id']='forged-lease';f.core.store.put(ENTITY,policy)
                    elif kind=='management':f.company['acquisitionStrategy']['operatorOwners']=[]
                    elif kind in ('disabled_strategy','expired_lease'):
                        policy=f.core.store.get(ENTITY,f.strategy.ident)
                        if kind=='disabled_strategy':policy['enabled']=False
                        else:policy['lease']['expires_at']=time.time()-1
                        f.core.store.put(ENTITY,policy)
                    else:
                        user=f.core.store.get('users',f.executor.user_id);user['disabled']=True;f.core.store.put('users',user)
                f.executor.account_claim=mutate
                try:
                    with f.forbid_real():f.command('task_run',{'task_id':f.task_id,'max_batches':1})
                except (CoreError,ValueError):pass
                self.assertEqual(f.adapter_calls,[],f'late {kind} changed after initial private guard must refuse before fixture dispatch')

    def test_management_revocation_after_search_blocks_next_comment_read(self):
        f=self.f;self.assertEqual(f.check()['state'],'eligible_for_explicit_run')
        search=f.search
        def revoke_after_search(platform,query):
            result=search(platform,query)
            f.company['acquisitionStrategy']['operatorOwners']=[]
            return result
        f.core.adapters.search=revoke_after_search
        try:
            with f.forbid_real():result=f.command('task_run',{'task_id':f.task_id,'max_batches':1})
        except (CoreError,ValueError):result=None
        self.assertEqual([c[0] for c in f.adapter_calls],['search'],
            'the one completed search remains historical; revoked management must prevent the following comment request')
        if result is not None:self.assertEqual(result['imported'],0)
        self.assertEqual(f.core.store.list('leads',f.executor.tenant),[])

    def test_response_loss_keeps_original_snapshot_readable_without_test_replay(self):
        f=self.f;key='phase17-original-request-key';responses={}
        # Emulate response delivery loss AFTER the actual executor succeeded.
        # The executor itself is not a request-key idempotency API; the UI/broker
        # must keep the original key/command and perform read-only recovery.
        with f.forbid_real():
            def deliver_and_lose():
                responses[key]=f.command('task_run',{'task_id':f.task_id,'max_batches':1})
                raise ConnectionError('synthetic response lost after completed executor')
            with self.assertRaises(ConnectionError):deliver_and_lose()
            before=list(f.adapter_calls)
            projected=f.read();snapshot=f.command('workspace_state')
        self.assertEqual(projected['task']['id'],f.task_id)
        self.assertEqual(snapshot['tasks'][0]['id'],f.task_id)
        self.assertEqual(f.adapter_calls,before)
        self.assertEqual(len([c for c in before if c[0]=='search']),1)
        self.assertFalse(responses[key]['strategy_completion']['finished'])
        self.assertNotIn('PHASE17_PRIVATE_',json.dumps(projected))


if __name__=='__main__':unittest.main()
