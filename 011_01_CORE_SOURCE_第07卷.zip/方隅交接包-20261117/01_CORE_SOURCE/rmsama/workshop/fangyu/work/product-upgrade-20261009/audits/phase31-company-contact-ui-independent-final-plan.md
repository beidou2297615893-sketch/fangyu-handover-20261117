# Phase31 原四方法最终复验准备

Root 已授权仅修独审 fixture 的一处默认语义，并已授权 B 窄修生产 checker；本文件只安排最终复验，不表示 B 新源已冻结或已通过。

项目完整路径：`C:/积木软件工坊/项目/方隅公寓客户版`。新审核文件所在文件夹完整路径：`C:/积木软件工坊/项目/方隅公寓客户版/work/product-upgrade-20261009/audits`。

唯一独审修正：appExecute 从解构 local=true 改为对 options 是否拥有 local 属性做显式判断；未传该属性继续默认 true，显式 undefined 则保持 undefined。旧 fixture 原样另备份为 phase31-company-contact-ui-independent-fixture-before-explicit-undefined.cjs，与首快照 SHA 一致。所有四 test 方法、每条断言和 fresh REVEAL replayed 反例的 test source 完全不改。

首跑保史：phase31-company-contact-ui-independent-first.txt / first-sources.json / first-evidence.json / first-review.md / first-hashes.json，candidate-hashes.json 以及 before/first 快照均不修改或覆盖。首 2 GREEN / 2 RED 仍是首结果，不能以修后结果倒写首通过。

等待 root 明确确认 B 新 source SHA 后才执行：

1. 逐 SHA 核 root 新 manifest；旧 B test 和十 actual fixture、冻结 local 三源、历史 actual fixture、所有独审断言必须与首 source 记录一致。生产允许差异仅限 root 批准的新 shared checker；若还出现其他生产差异，停止执行并报告 root。
2. 新建 phase31-company-contact-ui-independent-final-candidate-hashes.json，不覆盖首 candidate。包含全部实际读取的源、B 新 manifest、独审当前 fixture/test/asset probe/runner；每条 SHA 在 final 开始前核对，保存 before/final 快照。
3. 只运行 `node run-phase31-company-contact-ui-independent.cjs final phase31-company-contact-ui-independent-final-candidate-hashes.json` 一次，不重复旧矩阵、B 四方法、GUI、Native 或其他测试。runner 拒绝覆盖 final log/evidence/sources/snapshot，完整保留 stdout/stderr 和前后 SHA。
4. 四方法 GREEN 后直接封 final report/manifest，不再重跑。RED 则完整保留 final，向 root 定位，不能删除断言或增加未经批准的 source 修改。最终统计唯一方法数仍为四，变体不另计。

边界不变：actual UI / app 执行片段与 actual Handler / asset 内存请求；无 listener/Core 初始化、原库/账号、真实网络/KMS/DPAPI/Native或打包。轻量 DOM 成功不证明 GUI/用户认可、实体双机、真实 KMS 或物理 RAM 清零。
