"""Actual new DTOs; no flags are fabricated from another contract."""
from copy import deepcopy
import hashlib
import importlib.util
import json
from pathlib import Path
from assistant.company_handoff_preparation import GET as PREPARATION_GET
from assistant.company_handoff_registration import CompanyHandoffRegistrationError

HERE = Path(__file__).resolve().parent
PROJECT = HERE.parents[2]
spec = importlib.util.spec_from_file_location('phase25_actual_dto_helper', HERE / 'test_phase25_company_channel_check.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
helper = module.CompanyChannelCheckTests()
helper.setUp()
cases = {}
try:
    for name in ('no_origin', 'not_attempted', 'registration_unknown', 'matched_lost_echo', 'matched_verified', 'hold_local_withdrawn'):
        fixture = helper.fixture(prepare=name != 'no_origin')
        if name == 'registration_unknown':
            fixture.before_write = lambda: (_ for _ in ()).throw(RuntimeError('synthetic pre-transport uncertainty'))
        fixture.lose_response = name == 'matched_lost_echo'
        if name not in ('no_origin', 'not_attempted'):
            try:
                fixture.call()
            except CompanyHandoffRegistrationError:
                if name not in ('registration_unknown', 'matched_lost_echo'):
                    raise
        if name == 'hold_local_withdrawn':
            fixture.withdraw()
        before = fixture.dump()
        result = helper.check(fixture)
        assert before == fixture.dump()
        cases[name] = dict(result=result, preparation_get_result=fixture.f.preparation.execute(PREPARATION_GET,
            dict(handoff_id=fixture.f.handoff['id']), deepcopy(fixture.f.actor)),
            cloud_counts=fixture.command(dict(kind='counts')), sqlite_dump_unchanged=True,
            cloud_read_transaction_counts=deepcopy(fixture.operations),
            actual_company_read_envelopes=[deepcopy(body) for body in fixture.envelopes
                if body.get('read_only') is True])
    sources = ['work/app/src/assistant/company_handoff_channel_check.py',
        'work/app/src/assistant/company_handoff_channel_transport.py', 'work/app/src/assistant/product_workspace.py',
        'work/cloud/workspace/service.cjs', 'work/cloud/workspace/handoff-ledger.cjs']
    output = dict(cases=cases, source_sha256={path: hashlib.sha256((PROJECT / path).read_bytes()).hexdigest().upper()
        for path in sources}, note='Actual Core and company service with SDK-interface memory callback adapter; no real cloud engine.')
    destination = HERE / 'company-channel-check-actual-fixture.json'
    destination.write_text(json.dumps(output, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    print(json.dumps(dict(file=str(destination), cases=len(cases), fields=len(cases['matched_lost_echo']['result']),
        sha256=hashlib.sha256(destination.read_bytes()).hexdigest().upper()), ensure_ascii=False))
finally:
    helper.tearDown()
