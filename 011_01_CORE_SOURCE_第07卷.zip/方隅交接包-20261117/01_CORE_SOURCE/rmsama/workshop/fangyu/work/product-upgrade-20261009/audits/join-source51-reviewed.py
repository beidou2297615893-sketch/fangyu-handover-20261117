"""Uninstalled fixed Source51 successor CAS draft; no authority is present.

Root fills the exact PREPARED/gate/authority graph only after independent review.
Called once in the same process under the original normal-open byte OS lock.
"""
import ast,ctypes,hashlib,json,os,stat,subprocess,sys,tempfile,uuid
from ctypes import wintypes
from pathlib import Path
PROJECT=Path('C:/积木软件工坊/项目/方隅公寓客户版')
WORK=PROJECT/'work'
AUDITS=WORK/'product-upgrade-20261009/audits'
OWN=WORK/'source51-root-integration'
PREPARED=OWN/'PREPARED.json'
APPROVAL=AUDITS/'source51-final-root-read.json'
AUTHORITY=AUDITS/'source51-manifest.json'
STARTED=AUDITS/'source51-next-open-started.json'
RECEIPT=AUDITS/'source51-joined.json'
FAILED=AUDITS/'source51-join-failed.json'
BASE_AUTHORITY=AUDITS/'source50-manifest.json'
BASE_APPROVAL=AUDITS/'source50-final-root-read.json'
BASE_PREPARED=WORK/'overnight-commercial-20261014/source50-preparation/PREPARED.json'
BASE_RECEIPT=AUDITS/'source50-joined.json'
BASE_FAILED=AUDITS/'source50-join-failed.json'
BASE_MANIFEST_PIN={'bytes':17143,'sha256':'FA18DE22A451370BD49417A6315ED317134B261D615BED0622031379BEF57267'}
PILOT=WORK/'self-operating-pilot'
ENTRY=WORK/'desktop-self-use-entry/desktop_entry.py'
INSTANCE_ID='d075ac9c039e44038ddbc6f3e753d73c'
NEW_SOURCE=WORK/'cloud/workspace/shared_store_scope.cjs'
TARGET_RELATIVE=(
    'app/src/assistant/self_operating_read.py',
    'app/src/assistant/self_operating_source_intent.py',
    'app/src/assistant/owner_douyin_source_archive.py',
    'app/src/web/workspace/self-operating-read.mjs',
    'app/src/assistant/source_intent_analysis.py',
    'app/src/assistant/self_operating_acquisition.py',
    'cloud/workspace/service.cjs',
    'cloud/workspace/shared_leads_v2.cjs',
    'cloud/workspace/index.js',
    'cloud/workspace/shared_store_scope.cjs',
    'desktop-self-use-entry/desktop_entry.py',
)
ALLOWED=frozenset(TARGET_RELATIVE)
# This draft rejects before reading the real approval/instance or writing anything.
JOIN_AUTHORIZED=True

HELPER=AUDITS/'join-source44-reviewed.py'
helper_raw=HELPER.read_bytes()
if len(helper_raw)!=9601 or hashlib.sha256(helper_raw).hexdigest().upper()!='5F5E3EA22AF7C1FA0FEA71CFEFDA12A9D669C190D5470960901029BF8F4750FB':
    raise ValueError('reviewed helper changed')
names={'blob','pin','expected','no_link_parent','prepared_temp'}
definitions=[x for x in ast.parse(helper_raw).body if isinstance(x,ast.FunctionDef) and x.name in names]
if len(definitions)!=5 or {x.name for x in definitions}!=names:raise ValueError('helper definitions changed')
exec(compile(ast.Module(body=definitions,type_ignores=[]),str(HELPER),'exec'),globals())

def existing_lock_is_held():
    # Read only metadata and probe the same existing byte range from a child.
    # A free/unknown range cannot stand in for the caller's normal-open lock.
    path=PILOT/'data/instance.lock'
    no_link_parent(path);info=path.lstat()
    if path.is_symlink() or getattr(info,'st_file_attributes',0)&0x400 or not stat.S_ISREG(info.st_mode) or info.st_nlink!=1 or info.st_size<1:
        raise ValueError('existing lock identity unknown')
    code="import errno,msvcrt,os,sys; f=open(sys.argv[1],'r+b'); f.seek(0)\ntry:\n msvcrt.locking(f.fileno(),msvcrt.LK_NBLCK,1)\nexcept OSError as e:\n if e.errno not in (errno.EACCES,errno.EDEADLK): raise\n print('held')\nelse:\n f.seek(0); msvcrt.locking(f.fileno(),msvcrt.LK_UNLCK,1); print('free')\nfinally:\n f.close()"
    probe=subprocess.run([sys.executable,'-B','-c',code,str(path)],capture_output=True,text=True,timeout=15,
        creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
    after=path.lstat()
    if probe.returncode or probe.stderr.strip() or probe.stdout.strip()!='held' or (info.st_dev,info.st_ino)!=(after.st_dev,after.st_ino):
        raise ValueError('original normal-open OS lock is free or unknown')

def original_main_dead():
    raw=blob(PILOT/'data/running.json')
    if len(raw)>4096:raise ValueError('main metadata unknown')
    value=json.loads(raw)
    if (type(value) is not dict or set(value)!={'pid','url','mode'} or type(value['pid']) is not int
        or not 0<value['pid']<=0xffffffff or value['mode'] not in ('headless-test','assistant','browser')):
        raise ValueError('main identity unknown')
    if pid_state(value['pid'])!='dead':raise ValueError('original main alive or unknown')
    return value['pid']

def proof(value):
    return (type(value) is dict and set(value)=={'bytes','sha256'} and type(value['bytes']) is int
        and value['bytes']>=0 and type(value['sha256']) is str and len(value['sha256'])==64
        and all(c in '0123456789ABCDEF' for c in value['sha256']))

def fixed_target(path):
    if type(path) is not str:raise ValueError('target path type changed')
    value=Path(path)
    if value.relative_to(WORK).as_posix() not in ALLOWED:raise ValueError('fixed 11 target whitelist changed')
    return value

def source50_predecessor():
    # Use the fixed original authority; a plausible receipt alone is insufficient.
    if os.path.lexists(BASE_FAILED):raise ValueError('original Source50 failure evidence preserved')
    base=json.loads(expected(BASE_AUTHORITY,BASE_MANIFEST_PIN))
    if (base.get('schema')!='source50_next_open_manifest_v1' or base.get('source_batch')!=50
        or base.get('join_authorized') is not True or base.get('instance_id')!=INSTANCE_ID
        or not proof(base.get('approval_pin'))):raise ValueError('fixed Source50 authority changed')
    rows=base['targets']
    if (type(rows) is not list or len(rows)!=55 or any(type(row) is not dict
        or type(row.get('path')) is not str or not proof(row.get('final_pin')) for row in rows)):
        raise ValueError('fixed Source50 final set changed')
    finals={Path(row['path']):row['final_pin'] for row in rows}
    if len(finals)!=55:raise ValueError('Source50 duplicate target')
    gate=json.loads(expected(BASE_APPROVAL,base['approval_pin']))
    prepared_raw=expected(BASE_PREPARED,gate['prepared_manifest_pin']);prepared=json.loads(prepared_raw)
    if (prepared.get('schema')!='source50_owner_prepared_v1' or prepared.get('source_batch')!=50
        or prepared.get('join_authorized') is not False or prepared.get('instance_id')!=INSTANCE_ID):
        raise ValueError('fixed Source50 original protection manifest changed')
    raw=blob(BASE_RECEIPT);receipt=json.loads(raw)
    if (receipt.get('schema')!='source50_owner_joined_v1' or receipt.get('source_batch')!=50
        or receipt.get('approval_sha256')!=base['approval_pin']['sha256']
        or receipt.get('authority_manifest_pin')!=BASE_MANIFEST_PIN
        or receipt.get('prepared_manifest_pin')!=pin(prepared_raw)
        or receipt.get('protected')!=prepared['protected']
        or any(receipt.get(key) is not False for key in ('App_restarted','marker_changed',
            'customer_database_opened','session_copied','deployed','commercial_complete'))):
        raise ValueError('actual Source50 success receipt changed')
    records=receipt.get('targets')
    if (type(records) is not list or len(records)!=55 or any(type(row) is not dict
        or type(row.get('target')) is not str for row in records)
        or len({row['target'] for row in records})!=55
        or {Path(row['target']) for row in records}!=set(finals)):
        raise ValueError('actual Source50 receipt 55 target set changed')
    for row in records:
        if row.get('candidate')!=finals[Path(row['target'])]:raise ValueError('Source50 original candidate proof changed')
    return raw,finals,prepared['protected']

def base_readback(finals,overlays=None):
    overlays={} if overlays is None else overlays
    for target,value in finals.items():expected(target,overlays.get(target,value))

def protection_set(original,base_finals,dependencies):
    values={}
    for row in original+dependencies:
        if type(row) is not dict or set(row)!={'path','pin'} or not proof(row['pin']):
            raise ValueError('protection/dependency row changed')
        path=Path(row['path']);path.relative_to(WORK)
        if path.relative_to(WORK).as_posix() in ALLOWED:continue
        if path in values and values[path]!=row['pin']:raise ValueError('protection dependency parent disagrees')
        values[path]=row['pin']
    for target,value in base_finals.items():
        if target.relative_to(WORK).as_posix() in ALLOWED:continue
        if target in values and values[target]!=value:raise ValueError('Source50 final protection disagrees')
        values[target]=value
    return values

def main():
    if JOIN_AUTHORIZED is not True:raise ValueError('uninstalled Source51 draft cannot authorize apply')
    if os.name!='nt' or len(sys.argv)!=3 or sys.argv[1]!='--apply' or len(sys.argv[2])!=64:
        raise ValueError('exact Root approval SHA required; prepared is not approved')
    if os.path.lexists(RECEIPT) or os.path.lexists(FAILED):raise ValueError('original execution evidence preserved')
    approval_raw=blob(APPROVAL)
    if pin(approval_raw)['sha256']!=sys.argv[2].upper():raise ValueError('Root approval changed')
    gate=json.loads(approval_raw)
    if (gate.get('schema')!='source51_final_root_read' or gate.get('source_batch')!=51
        or gate.get('join_authorized') is not True or gate.get('independent_code_review_passed') is not True
        or gate.get('independent_actual_qa_review_passed') is not True or gate.get('join_script_review_passed') is not True
        or gate.get('next_normal_open_only') is not True or gate.get('base_manifest_pin')!=BASE_MANIFEST_PIN
        or gate.get('customer_database_opened') is not False or gate.get('session_copied') is not False
        or gate.get('deployment_or_packaging_performed') is not False):
        raise ValueError('Root fixed deferred scope not approved')
    expected(Path(__file__).absolute(),gate['join_script_pin'])
    prepared_raw=expected(PREPARED,gate['prepared_manifest_pin']);manifest=json.loads(prepared_raw)
    if (manifest.get('schema')!='source51_owner_prepared_v1' or manifest.get('source_batch')!=51
        or manifest.get('join_authorized') is not False or manifest.get('instance_id')!=INSTANCE_ID
        or manifest.get('base_manifest_pin')!=BASE_MANIFEST_PIN or manifest.get('new_directories')!=[]):
        raise ValueError('fixed prepared Source51 set changed')
    targets=manifest['targets']
    if (type(targets) is not list or len(targets)!=11 or any(type(row) is not dict
        or set(row)!={'target','candidate','parent','candidate_pin'} or not proof(row['candidate_pin'])
        or (row['parent'] is not None and not proof(row['parent'])) for row in targets)):
        raise ValueError('exact Source51 target shape changed')
    paths=[fixed_target(row['target']) for row in targets]
    if len(set(paths))!=11 or {path.relative_to(WORK).as_posix() for path in paths}!=ALLOWED or paths[-1]!=ENTRY:
        raise ValueError('fixed 11 unique targets/entry-last changed')
    for item in manifest['evidence']+gate['additional_evidence']:
        path=Path(item['path']);path.relative_to(WORK);expected(path,item['pin'])
    authority_raw=blob(AUTHORITY);authority=json.loads(authority_raw);started=json.loads(blob(STARTED))
    if (authority.get('schema')!='source51_next_open_manifest_v1' or authority.get('source_batch')!=51
        or authority.get('join_authorized') is not True or authority.get('instance_id')!=INSTANCE_ID
        or authority.get('base_manifest_pin')!=BASE_MANIFEST_PIN
        or authority.get('approval_pin')!=pin(approval_raw) or authority.get('join_script_pin')!=gate['join_script_pin']
        or started.get('schema')!='source51_next_open_started_v1' or started.get('source_batch')!=51
        or started.get('instance_id')!=INSTANCE_ID or started.get('pid')!=os.getpid()
        or started.get('approval_sha256')!=pin(approval_raw)['sha256'] or started.get('manifest_pin')!=pin(authority_raw)
        or started.get('auto_retry') is not False):raise ValueError('actual fixed normal-open caller not bound')
    rows=authority['targets']
    if (type(rows) is not list or len(rows)!=11 or any(type(row) is not dict
        or set(row)!={'path','parent_pin','final_pin'} for row in rows)):
        raise ValueError('fixed Source51 authority target shape changed')
    finals={fixed_target(row['path']):(row['parent_pin'],row['final_pin']) for row in rows}
    if len(finals)!=11 or finals!={Path(row['target']):(row['parent'],row['candidate_pin']) for row in targets}:
        raise ValueError('fixed Source51 parent/final target set changed')
    base_raw,base_finals,original_protected=source50_predecessor();base_pin=pin(base_raw)
    if started.get('base_receipt_pin')!=base_pin:raise ValueError('actual Source50 predecessor receipt not bound')
    old_protection={Path(row['path']):row['pin'] for row in original_protected}
    if len(old_protection)!=len(original_protected):raise ValueError('Source50 original protection set duplicated')
    for row in targets:
        target=Path(row['target'])
        if target in base_finals and row['parent']!=base_finals[target]:
            raise ValueError('Source51 overlap is not the actual Source50 final parent')
        if target in old_protection and row['parent']!=old_protection[target]:
            raise ValueError('Source51 overlap is not the original Source50 protected parent')
    protected=manifest['protected']
    if authority.get('protected')!=protected:raise ValueError('Source51 authority/prepared protection set changed')
    actual_protection=protection_set([],{},protected)
    required_protection=protection_set(original_protected,base_finals,manifest['candidate_dependencies'])
    if len(actual_protection)!=len(protected) or actual_protection!=required_protection:
        raise ValueError('fixed Source50-minus-targets plus candidate dependency protection changed')
    backup=None;saved=[];temporaries=[];attempted=[]
    try:
        base_readback(base_finals)
        for item in protected:expected(Path(item['path']),item['pin'])
        changes=[]
        for item,target in zip(targets,paths):
            candidate=Path(item['candidate']);candidate.relative_to(OWN/'candidates')
            if '..' in candidate.parts:raise ValueError('candidate parent alias refused')
            after=expected(candidate,item['candidate_pin']);no_link_parent(target)
            if item['parent'] is None:
                if target!=NEW_SOURCE or os.path.lexists(target):raise ValueError('only fixed new scope file may be absent')
                before=None
            else:before=expected(target,item['parent'])
            changes.append((item,target,before,after))
        if sum(row[2] is None for row in changes)!=1:raise ValueError('only one fixed new scope source may be created')
        entry_before=next(before for item,target,before,after in changes if target==ENTRY)
        definitions=[x for x in ast.parse(entry_before).body if isinstance(x,ast.FunctionDef) and x.name=='pid_state']
        if len(definitions)!=1:raise ValueError('original process-state interface changed')
        exec(compile(ast.Module(body=definitions,type_ignores=[]),str(ENTRY),'exec'),globals())
        original_pid=original_main_dead();existing_lock_is_held()
        backup_base=PROJECT/'backups/source51-owner';no_link_parent(backup_base);backup_base.mkdir(exist_ok=True)
        backup=backup_base/uuid.uuid4().hex;no_link_parent(backup);backup.mkdir()
        for item,target,before,after in changes:
            path=backup/target.relative_to(WORK)
            if before is not None:
                path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(before);expected(path,item['parent'])
            saved.append({'target':str(target),'parent':item['parent'],'candidate':item['candidate_pin'],
                'backup':str(path) if before is not None else None})
            temporaries.append(prepared_temp(target,after))
        (backup/'PREPARED.json').write_text(json.dumps(saved,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
        if original_main_dead()!=original_pid:raise ValueError('original main metadata changed')
        existing_lock_is_held();expected(BASE_RECEIPT,base_pin);base_readback(base_finals)
        for item in protected:expected(Path(item['path']),item['pin'])
        for (item,target,before,after),temporary in zip(changes,temporaries):
            no_link_parent(target);expected(temporary,item['candidate_pin'])
            if before is None:
                if os.path.lexists(target):raise ValueError('new scope source appeared before rename')
            else:expected(target,item['parent'])
            attempted.append((item,target,before,after))
            if before is None:os.rename(temporary,target)
            else:os.replace(temporary,target)
            expected(target,item['candidate_pin'])
        for item in protected:expected(Path(item['path']),item['pin'])
        expected(BASE_RECEIPT,base_pin);base_readback(base_finals,{target:row[1] for target,row in finals.items()})
        if original_main_dead()!=original_pid:raise ValueError('original main restarted during join')
        existing_lock_is_held()
        result={'schema':'source51_owner_joined_v1','source_batch':51,'approval_sha256':pin(approval_raw)['sha256'],
            'prepared_manifest_pin':pin(prepared_raw),'authority_manifest_pin':pin(authority_raw),'base_receipt_pin':base_pin,
            'backup':str(backup),'targets':saved,'protected':protected,'new_directories':[],
            'App_restarted':False,'marker_changed':False,'customer_database_opened':False,'session_copied':False,
            'deployed':False,'real_GUI_verified':False,'commercial_complete':False}
        receipt_temp=prepared_temp(RECEIPT,(json.dumps(result,ensure_ascii=False,indent=2)+'\n').encode('utf-8'))
        temporaries.append(receipt_temp);os.rename(receipt_temp,RECEIPT)
        print(json.dumps({'source_batch':51,'joined':True,'targets':11,'backup':str(backup)},ensure_ascii=False))
    except BaseException as error:
        rollback=[]
        for item,target,before,after in reversed(attempted):
            try:
                no_link_parent(target);current=blob(target) if target.exists() else None
                if current==before:rollback.append({'target':str(target),'restored':True,'no_change':True});continue
                if current!=after:raise ValueError('foreign target drift; refuse rollback')
                if before is None:target.unlink()
                else:
                    restore=prepared_temp(target,before);temporaries.append(restore)
                    expected(target,item['candidate_pin']);no_link_parent(target);os.replace(restore,target);expected(target,item['parent'])
                rollback.append({'target':str(target),'restored':True})
            except BaseException:rollback.append({'target':str(target),'restored':False})
        failure={'schema':'source51_owner_join_failed_v1','failed':True,'source_batch':51,
            'approval_sha256':pin(approval_raw)['sha256'],'authority_manifest_pin':pin(authority_raw),
            'base_receipt_pin':base_pin,'error_type':type(error).__name__,'backup':str(backup) if backup is not None else None,
            'rollback':rollback,'automatic_retry':False}
        with FAILED.open('x',encoding='utf-8') as stream:stream.write(json.dumps(failure,ensure_ascii=False,indent=2)+'\n')
        raise
    finally:
        for temporary in temporaries:temporary.unlink(missing_ok=True)

if __name__=='__main__':main()
