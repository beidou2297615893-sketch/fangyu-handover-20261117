"""Freeze local evidence only; never starts collection or accesses real data."""
import hashlib
import json
from pathlib import Path

PROJECT = Path(__file__).resolve().parents[3]
AUDITS = Path(__file__).resolve().parent
EXPECTED = {
    'work/app/src/assistant/business.py': 'A55DEA6591E73F1579FE51EB3BA06744FBF95DA4E76C59FF4699E69BB43CE443',
    'work/app/src/assistant/strategy_tasks.py': '28DAF6B5314DAC97C134E0A86F80185784CD75A3A301791288E5247BD488AF8F',
    'work/app/src/core/engine.py': '2F1BC5D9465105DA0A3DA9B104EF7E7A375DA5E4C2DF4D2B390575821458A6DF',
    'work/app/tests/test_private_strategy_completion_summary.py': '740F0BE055225CA19397608F2E0C8346C651603891E3B30D65E2C99060B5BC6C',
}


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest().upper()


def main():
    for name, expected in EXPECTED.items():
        assert sha(PROJECT / name) == expected, name + ' changed after final verification'
    fixture = AUDITS / 'private-strategy-natural-continuation-actual-fixture.json'
    data = json.loads(fixture.read_text(encoding='utf-8'))
    for name, expected in data['source_metadata'].items():
        assert sha(PROJECT / name) == expected, 'actual fixture source changed: ' + name
    assert data['continuation_preflight']['state'] == 'eligible_for_explicit_run'
    source_names = list(data['source_metadata']) + [
        'work/app/src/app.py', 'work/app/src/core/runtime_license_policy.py']
    evidence_names = [
        'phase20-next-functional-slice-plan.md', 'private-strategy-completion-summary-review.md',
        'private-strategy-natural-continuation-actual-fixture.json',
        'emit-private-strategy-natural-continuation-fixture.py',
        'freeze-private-strategy-completion-summary.py',
        'private-strategy-completion-summary-own-first-red.txt',
        'private-strategy-completion-summary-actual-import-preflight-red.txt',
        'private-strategy-completion-summary-own-final-green.txt',
        'private-strategy-completion-summary-existing-single-batch-green.txt',
        'private-strategy-completion-summary-existing-strategy-green.txt',
        'private-completion-summary-independent-review.md',
        'private-completion-summary-independent-final-hashes.json',
        'private-strategy-natural-continuation-ui-independent-review.md',
        'private-strategy-natural-continuation-ui-independent-final-hashes.json']
    manifest = {
        'phase': 20, 'synthetic_only': True, 'production_source_frozen': True,
        'changed_sources_owned_by_b': list(EXPECTED)[:2],
        'root_owned_time_producer_change': 'work/app/src/core/engine.py',
        'source_files': {name: sha(PROJECT / name) for name in source_names},
        'new_test': {'path': 'work/app/tests/test_private_strategy_completion_summary.py',
                     'sha256': EXPECTED['work/app/tests/test_private_strategy_completion_summary.py'],
                     'methods': 3, 'passed': 3, 'elapsed_seconds': 5.422},
        'independent_backend': {'methods': 3, 'passed': 3, 'elapsed_seconds': 4.842},
        'independent_ui_model': {'methods': 3, 'passed': 3, 'elapsed_ms': 190.8454,
                                 'real_gui': False},
        'existing_supporting_checks': {'single_batch': 5, 'strategy_tasks': 23,
            'new_coverage': False, 'executed_before_root_time_producer_patch': True},
        'gui_evidence_owned_by_root': ['private-natural-continuation-gui-evidence.json',
            'private-natural-continuation-loaded-ui-final-verification.json'],
        'root_full_matrix': 'running_at_b_evidence_freeze',
        'real_platform_verified': False, 'real_cloud_verified': False,
        'evidence_files': {name: sha(AUDITS / name) for name in evidence_names},
    }
    target = AUDITS / 'private-strategy-completion-summary-final-hashes.json'
    target.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'report_sha256': sha(AUDITS / 'private-strategy-completion-summary-review.md'),
                      'manifest_sha256': sha(target), 'fixture_sha256': sha(fixture)}, ensure_ascii=False))


if __name__ == '__main__':
    main()
