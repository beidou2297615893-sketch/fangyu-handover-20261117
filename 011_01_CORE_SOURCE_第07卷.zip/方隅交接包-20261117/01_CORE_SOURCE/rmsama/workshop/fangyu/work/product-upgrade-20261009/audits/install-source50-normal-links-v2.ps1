﻿param([Parameter(Mandatory=$true)][string]$ApprovalSha)
$ErrorActionPreference='Stop'
$entryProject='C:\积木软件工坊\项目\方隅公寓客户版'
$entryWork=Join-Path $entryProject 'work'
$entryRoot=Join-Path $entryWork 'source50-next-open-root'
$entryAudits=Join-Path $entryWork 'product-upgrade-20261009/audits'
$entryApprovalPath=Join-Path $entryRoot 'LINK-APPROVAL-V2.json'
$entryReceiptPath=Join-Path $entryAudits 'source50-normal-links-installed-v2.json'
$entryFailurePath=Join-Path $entryAudits 'source50-normal-links-install-failed-v2.json'
function RequireParents([string]$Path){
 $parent=[IO.Path]::GetDirectoryName([IO.Path]::GetFullPath($Path))
 while($parent){
  if(Test-Path -LiteralPath $parent){
   $parentItem=Get-Item -LiteralPath $parent -Force
   if(-not $parentItem.PSIsContainer -or ($parentItem.Attributes -band [IO.FileAttributes]::ReparsePoint)){throw 'parent path identity unknown'}
  }
  $next=[IO.Path]::GetDirectoryName($parent)
  if($next -eq $parent){break};$parent=$next
 }
}
function FilePin([string]$Path){
 RequireParents $Path
 $item=Get-Item -LiteralPath $Path -Force
 if($item.PSIsContainer -or ($item.Attributes -band [IO.FileAttributes]::ReparsePoint)){throw 'ordinary owned file required'}
 return @{bytes=[long]$item.Length;sha256=(Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash}
}
function RequirePin([string]$Path,$Proof){
 $value=FilePin $Path
 if($value.bytes -ne [long]$Proof.bytes -or $value.sha256 -cne [string]$Proof.sha256){throw ('fixed file drift: '+$Path)}
}
function ReadPinnedBytes([string]$Path,$Proof){
 RequireParents $Path
 $item=Get-Item -LiteralPath $Path -Force
 if($item.PSIsContainer -or ($item.Attributes -band [IO.FileAttributes]::ReparsePoint)){throw 'ordinary pinned document required'}
 $raw=[IO.File]::ReadAllBytes($Path)
 $hash=[Security.Cryptography.SHA256]::Create()
 try{$sha=[BitConverter]::ToString($hash.ComputeHash($raw)).Replace('-','')}finally{$hash.Dispose()}
 if($sha -cne [string]$Proof.sha256 -or ($null -ne $Proof.bytes -and $raw.Length -ne [long]$Proof.bytes)){throw 'fixed document bytes changed'}
 return ,$raw
}
function Configuration($Link){return [ordered]@{TargetPath=$Link.TargetPath;Arguments=$Link.Arguments;WorkingDirectory=$Link.WorkingDirectory;WindowStyle=$Link.WindowStyle;IconLocation=$Link.IconLocation;Description=$Link.Description;Hotkey=$Link.Hotkey}}
function RequireConfiguration($Actual,$Expected){
 foreach($name in @('TargetPath','Arguments','WorkingDirectory','WindowStyle','IconLocation','Description','Hotkey')){
  if([string]$Actual[$name] -cne [string]$Expected.$name){throw ('shortcut configuration drift: '+$name)}
 }
}
if($ApprovalSha -cnotmatch '^[0-9A-F]{64}$'){throw 'exact Root link approval required'}
$entryApprovalRaw=ReadPinnedBytes $entryApprovalPath @{sha256=$ApprovalSha;bytes=$null}
$entryApproval=[Text.Encoding]::UTF8.GetString($entryApprovalRaw)|ConvertFrom-Json
if($entryApproval.schema -cne 'source50_normal_links_approval_v2' -or $entryApproval.shortcut_changes_authorized -ne $true -or $entryApproval.App_launches_authorized -ne $false){throw 'links only authority absent'}
if($entryApproval.known_rejected_no_target_effects -ne $true){throw 'no-effect recovery authority required'}
$entryPreviousFailureRaw=ReadPinnedBytes $entryApproval.previous_failure_path $entryApproval.previous_failure_pin
$entryPreviousFailure=[Text.Encoding]::UTF8.GetString($entryPreviousFailureRaw)|ConvertFrom-Json
if($entryPreviousFailure.schema -cne 'source50_link_install_failed_v1' -or $entryPreviousFailure.automatic_retry -ne $false -or @($entryPreviousFailure.rollback|Where-Object{$_.unchanged_parent -ne $true}).Count){throw 'original rejected result not confirmed'}
$entryPreparedRaw=ReadPinnedBytes $entryApproval.prepared_path $entryApproval.prepared_pin
RequirePin $entryApproval.install_receipt_path $entryApproval.install_receipt_pin
RequirePin $entryApproval.review_path $entryApproval.review_pin
RequirePin $entryApproval.launcher_path $entryApproval.launcher_pin
$entryPrepared=[Text.Encoding]::UTF8.GetString($entryPreparedRaw)|ConvertFrom-Json
if($entryPrepared.target_count -ne 2 -or $entryPrepared.targets.Count -ne 2 -or $entryPrepared.launcher -cne $entryApproval.launcher_path){throw 'fixed two link scope changed'}
$entryDesktop=[Environment]::GetFolderPath('Desktop')
$entryAllowed=@((Join-Path $entryDesktop '方隅工作台.lnk'),(Join-Path $entryDesktop '方隅工作台·自用模板.lnk'))
if(@($entryPrepared.targets|Where-Object{$entryAllowed -cnotcontains $_.target}).Count -ne 0 -or @($entryPrepared.targets.target|Select-Object -Unique).Count -ne 2){throw 'desktop link target scope changed'}
if((Test-Path -LiteralPath $entryReceiptPath) -or (Test-Path -LiteralPath $entryFailurePath)){throw 'prior link evidence preserved'}
$entryWsh=New-Object -ComObject WScript.Shell
RequirePin $entryPrepared.untouched_admin_shortcut.path $entryPrepared.untouched_admin_shortcut.parent
$entryStaged=@();$entryApplied=@();$entryAttempted=@();$entryRestores=@()
try{
 foreach($row in $entryPrepared.targets){
  RequirePin $row.target $row.parent
  RequireConfiguration (Configuration ($entryWsh.CreateShortcut($row.target))) $row.expected_configuration
  $backup=[IO.Path]::GetFullPath([string]$row.proposed_binary_backup)
  $backupBase=[IO.Path]::GetFullPath((Join-Path $entryAudits '..\backups\source50-desktop-shortcuts'))
  if(-not $backup.StartsWith($backupBase+[IO.Path]::DirectorySeparatorChar,[StringComparison]::OrdinalIgnoreCase)){throw 'backup outside owned project scope'}
  RequireParents $backup
  if(Test-Path -LiteralPath $backup){RequirePin $backup $row.parent}
  else{
   New-Item -ItemType Directory -Path ([IO.Path]::GetDirectoryName($backup)) -Force | Out-Null
   RequireParents $backup;RequirePin $row.target $row.parent
   Copy-Item -LiteralPath $row.target -Destination $backup
   RequirePin $backup $row.parent
  }
  $temporary=Join-Path $entryDesktop ('.fangyu-next-open-'+[guid]::NewGuid().ToString('N')+'.lnk')
  if(Test-Path -LiteralPath $temporary){throw 'unexpected staging shortcut'}
  $entryStaged+=@{row=$row;temp=$temporary;backup=$backup;pin=$null}
  $link=$entryWsh.CreateShortcut($temporary)
  foreach($name in @('TargetPath','Arguments','WorkingDirectory','WindowStyle','IconLocation','Description','Hotkey')){$link.$name=$row.proposed_configuration.$name}
  $link.Save()
  RequireConfiguration (Configuration ($entryWsh.CreateShortcut($temporary))) $row.proposed_configuration
  $entryStaged[-1].pin=FilePin $temporary
 }
 foreach($stage in $entryStaged){
  RequirePin $stage.row.target $stage.row.parent
  RequireConfiguration (Configuration ($entryWsh.CreateShortcut($stage.row.target))) $stage.row.expected_configuration
  RequirePin $stage.temp $stage.pin
  $forwardBackup=$stage.backup+'.replace-v2-original.lnk'
  RequireParents $forwardBackup
  if(Test-Path -LiteralPath $forwardBackup){throw 'prior Replace backup preserved'}
  $stage.forward_backup=$forwardBackup
  $entryAttempted+=,$stage
  [IO.File]::Replace([string]$stage.temp,[string]$stage.row.target,[string]$forwardBackup)
  $entryApplied+=,$stage
  RequirePin $stage.row.target $stage.pin
  RequirePin $forwardBackup $stage.row.parent
  RequireConfiguration (Configuration ($entryWsh.CreateShortcut($stage.row.target))) $stage.row.proposed_configuration
 }
 RequirePin $entryPrepared.untouched_admin_shortcut.path $entryPrepared.untouched_admin_shortcut.parent
 $entryResult=[ordered]@{schema='source50_normal_links_installed_v2';approval_sha256=$ApprovalSha;targets=@($entryApplied|ForEach-Object{[ordered]@{path=$_.row.target;pin=$_.pin;backup=$_.backup;replace_backup=$_.forward_backup;parent=$_.row.parent;configuration=$_.row.proposed_configuration}});untouched_admin_pin=$entryPrepared.untouched_admin_shortcut.parent;App_launches=0;Source50_apply_calls=0;old_App_stopped_or_refreshed=$false;original_code_and_data_removed=$false}
 $entryResultRaw=($entryResult|ConvertTo-Json -Depth 9)+[Environment]::NewLine
 $entryReceiptStream=[IO.File]::Open($entryReceiptPath,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write)
 try{$entryReceiptBytes=[Text.Encoding]::UTF8.GetBytes($entryResultRaw);$entryReceiptStream.Write($entryReceiptBytes,0,$entryReceiptBytes.Length);$entryReceiptStream.Flush()}finally{$entryReceiptStream.Dispose()}
 $entryResult|ConvertTo-Json -Depth 9
}catch{
 $entryOriginalFailure=$_;$entryRollback=@()
 for($entryIndex=$entryAttempted.Count-1;$entryIndex -ge 0;$entryIndex--){
  $stage=$entryAttempted[$entryIndex]
  try{
   $now=FilePin $stage.row.target
   if($now.bytes -eq [long]$stage.row.parent.bytes -and $now.sha256 -ceq [string]$stage.row.parent.sha256){$entryRollback+=@{path=$stage.row.target;unchanged_parent=$true};continue}
   RequirePin $stage.row.target $stage.pin
   $restore=Join-Path $entryDesktop ('.fangyu-next-open-restore-'+[guid]::NewGuid().ToString('N')+'.lnk')
   $entryRestores+=,$restore
   Copy-Item -LiteralPath $stage.backup -Destination $restore
   RequirePin $restore $stage.row.parent
   RequirePin $stage.row.target $stage.pin
   $rollbackBackup=$stage.backup+'.replace-v2-rollback-candidate.lnk'
   RequireParents $rollbackBackup
   if(Test-Path -LiteralPath $rollbackBackup){throw 'prior rollback backup preserved'}
   [IO.File]::Replace([string]$restore,[string]$stage.row.target,[string]$rollbackBackup)
   RequirePin $stage.row.target $stage.row.parent
   RequirePin $rollbackBackup $stage.pin
   $entryRollback+=@{path=$stage.row.target;restored=$true}
  }catch{$entryRollback+=@{path=$stage.row.target;held_foreign_or_unknown=$true;error_type=$_.Exception.GetType().Name}}
 }
 $entryFailure=[ordered]@{schema='source50_link_install_failed_v2';error_type=$entryOriginalFailure.Exception.GetType().Name;rollback=$entryRollback;automatic_retry=$false}
 $entryFailureStream=[IO.File]::Open($entryFailurePath,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write)
 try{$entryFailureBytes=[Text.Encoding]::UTF8.GetBytes(($entryFailure|ConvertTo-Json -Depth 6)+[Environment]::NewLine);$entryFailureStream.Write($entryFailureBytes,0,$entryFailureBytes.Length);$entryFailureStream.Flush()}finally{$entryFailureStream.Dispose()}
 throw $entryOriginalFailure
}finally{
 foreach($stage in $entryStaged){if(Test-Path -LiteralPath $stage.temp){Remove-Item -LiteralPath $stage.temp -Force}}
 foreach($restore in $entryRestores){if(Test-Path -LiteralPath $restore){Remove-Item -LiteralPath $restore -Force}}
}
