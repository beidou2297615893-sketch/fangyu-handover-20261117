# Phase24 原浏览器身份维护路线验证

结论：成熟自然身份 proof/spec、固定子进程参数、固定取消和账号锁可在本项目合成数据上组合使用；目前没有已证明的无 Service 可信部署 validator，公开入口保持 `deployment_confirmation_unavailable`、零启动。因此本阶段是机制研究候选，不是原账号恢复功能完成，也没有证明原账号可用。

## 最小实现和公开边界

新增 `work/app/src/assistant/original_browser_identity_maintenance.py`，不修改 AppServer/main/Service/CLI/UI、既有采集/策略/许可模块。构造 `OriginalBrowserIdentityMaintenance(NativeOriginalBrowserBootstrap())`，公开 `execute({purpose:'inspect_original_browser_identity',account_id:<opaque32hex>})` 只允许这两个字段。固定 bootstrap 从原生路径和现有公司/设备/本人元数据派生范围；不能用 body、true callback、CLI review 或临时 QA 开通公开路径。

公开读取只投影 present/hash/state；原 Cookie、password、key、手机号、正文不进入 SQL 或响应。SQLite 使用 `mode=ro&immutable=1`、`query_only` 和只读 authorizer；不创建 Core/Service/Store，不调用云认领、会话提交、续期或平台。普通/持续任务 inflight 缺失或 null 如实拒为 unknown，不补写 false。未证明部署用途时，即使其它元数据成立也不会创建 job。

私有 `_run_owned_candidate` 默认 launcher 同样拒绝。本轮合成测试仅替换该低层为内存 FakeProcess，实际执行成熟 natural proof/spec、`login_helper_argv`、`read_login_outcome`、`verified_status`，验证账号锁覆盖清理、非重入、前中后范围核对和固定 cancel。它不能当公开能力或恢复授权。

## 验证结果

- 自有 3 方法通过，最终日志 `phase24-maintenance-own-after-body-consistency.txt`：3/3，0.659 秒。先行 hardest 的 1/1 属于同一方法先验，不另计新增覆盖。
- C 独立 3 方法通过，0.877 秒。其真实 RED 是索引列合法但 user/account 正文 id 或 tenant 不一致仍被当作已有原范围；原 0B0C 源与首日志保留，当前 ACD7DE84 源在同一反例通过。新候选现同时校验正文与索引身份，全部身份字段进入前后 fingerprint；没有修改旧数据或原 schema。
- 正向实际 proof 匹配原 UID，但响应只返回 hash；risk 保持 review_required，未提交原会话。默认公开路径零 job/零 process。
- 额外 body 字段不能自授，缺成员或普通/持续任务 unknown/在途拒绝；迟到设备 owner 变化触发固定取消；同实例嵌套启动拒绝；候选文件改字节后 proof 拒绝。
- 合成原 DB、账号任务元数据、风险日志及原 CLI Cookie bytes 前后相同。浏览器 profile（若真正开窗）、账号 lock、job/staging/proof/outcome 属于必要局部写；不能宣称整个 DATA 零写。本轮未实际开浏览器，因此只列 profile 可能写。
- 实际合成结果 `phase24-maintenance-actual-fixture.json` 同源生成；`mechanism_process=in_memory_fake_process`，明确未访问真实账号、未执行真实浏览器/平台。

首轮三个方法的 teardown 文件占用错误保留于 `phase24-maintenance-own-first-three.txt`：测试 SQLite writer 使用连接 context manager 后未显式 close，Windows 清理失败。修正只在新测试夹具，原断言通过，没有把环境/夹具 Error 算作产品 RED。

hardest 首次临时数据路径曾漏 `work` 层，数据已由 TemporaryDirectory 正常清理，仅空父目录保留；后续全部改为项目 `work/product-upgrade-20261009/work/phase24-maintenance-tests`。一次空目录清理被自动审核拦截，未执行、未重试、未影响原 DATA。该记录不属于功能失败或新增审批流程。

## 交付界限与下一步

公开维护入口当前不可用，无 UI 接线。没有运行原账号/Cookie/profile/DPAPI、网络、CLI、Service.start、AI、云队列、Scheduler 或真实登录；未新建部署许可审核流程。下一步应先由主窗口评估能够服务用户的可信既有部署路线，避免继续扩展永远阻断的占位功能。

独立审查结果与最终 SHA 见同目录最终 manifest；当前完成仅指本候选机制验证，不等于整个 R01–R25 或原账号恢复完成。
