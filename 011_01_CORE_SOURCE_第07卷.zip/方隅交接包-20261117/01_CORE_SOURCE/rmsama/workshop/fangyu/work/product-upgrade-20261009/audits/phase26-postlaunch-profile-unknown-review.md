# Phase26 启动后 profile unknown：静态定位与良性代表

本轮 D 仅读取已存回执和固定源码、准备两个独立良性候选。D 未执行 Scheduler、CIM、原 DATA/DPAPI、浏览器、CLI 或网络；七份 v3 host 源保持冻结。原生执行均由 root 完成，不计新增单元测试或原账号恢复。

## 实际原账号观察的边界

`phase26-native-developer-observation-8070bed51201458ebe31105b6e434906.json` 显示 finished / blocked / profile_occupancy_unknown，18.650926s。job_created、owned_exit_confirmed、owned_lock_released 为 true；platform_requests_started 为 null、profile_may_be_modified / platform_browser_network_possible 为 true。原 DB、binding、activity 三项前后相同；5 readonly connections、0 trace write statements。helper_outcome 和 identity hash 为 null，原 risk review_required 未清。

host.py 的启动前检查有两次 vacancy，启动后首轮又重新核 scope/runtime/CIM。wrapper 一次 bootstrap、host 初次 bootstrap、两次启动前 fresh、一次启动后 fresh，与 5 connections 相符；因此“预检 vacant，启动后 unknown”没有逻辑矛盾。回执没有阶段或具体 row 原因，计数不能证明某个 WebView2/Python 子进程就是原因。classify 每行任意异常都会置 uncertain，而 host 只保留总 unknown，现证据无法确定失败行。

`owned_job.contains` 已加 .NET / FILETIME epoch 差值 504911232000000000，要求 CIM 创建时间与 native 时间仅差 0..9 个 100ns 单位，并真正核 IsProcessInJob。不能按 PID/parent PID 豁免，也不能假定未知创建时间属于本 job。

## 解释器疑点核实

owned_helper_process.py 的 `_entry` 使用当前 sys.executable；login_helper_argv 使用同一 executable。固定 Scheduler 指向本项目 pythonw.exe。runtime_identity.fixed_interpreter 允许当前固定 python.exe 或 pythonw.exe，按当前 shim 同名核 pyvenv.cfg / base；TrustedCurrentPython._capture 同样绑定当前 shim/alias/base，并非硬编码只 python.exe。

因此现源码不支持“父进程固定 python.exe，却任意切换子进程 pythonw”这一推断。不同 CIM spelling、argv0、base alias 或 WebView2 runtime 仍须实际核对；不能先扩大 alias 白名单。profile/DATA 的严格 reparse 拒绝继续保持。

## 唯一良性 Native 代表

新 `phase26_native_owned_python_probe.py` 复用现 atomic WindowsOwnedJobProcess、WindowsProfileOccupancy、benign_job_child.py。子脚本仅打印固定文字并 sleep，附 `--profile-dir` 到项目下唯一 synthetic profile；没有浏览器、账号、DB、DPAPI、socket 代码。父 socket.connect / sqlite3.connect 禁止，Popen 仅允许固定 CIM probe。真实 classifier 返回照用；另仅针对本次持有 process handle 的 child row 输出固定 stage/code、family、route/resolve/argv/profile 对应 bool、创建时间类别和 Job bool。所有 raw PID/path/argv/SID 留在内存。

候选的最后调整为固定 Popen 路径容忍合法 Windows 大小写差异（相较全字串相等并不更严，后续 args 仍须 exact）、synthetic temp 更严拒 reparse、setup pending 保存已创建 Job 事实。root 首静审读 B225 前候选；实际 attempt 捕获最终 **867BA28D13976CE1B3FD6637B40BF6DD19CB65BE716219D83F92B29BC5354157**，materials_unchanged=true。root 已再增量读 867B 三处差异并接受，首静审 B225→实际执行 867B 的时序保留；两版本不能混称。本轮候选停止修改，PS 固定 **21F7D31F23EB4DA1B511ABBB6491AC226150474FFEA46439A8E0F4B858FA0E28**；原 host 七源未改。此后任何源修改先冻结并通知 root，不能交审核/dispatch 后继续施工。

root 单次 run `935775a2ab9041df8750b3b7c8f45d06` 回执为 representative_passed：actual classifier vacant，metadata_rows=52、owned_child_rows=1；当前 owner、已知 pythonw route、exe name、argv0、explicit synthetic profile、job membership 都 true；creation_delta=native_submicrosecond_floor；owned_exit_confirmed 与 materials_unchanged true。sqlite_connections=0，原账号/浏览器/网络均未调用。executable_resolves_to_fixed_base=false 合法：当前可验证的是固定 shim route；shim 本来就是独立 launcher，不要求 shim 文件 resolve 成 base 文件。

这关闭了本机同 SID、固定 Pythonw、CIM 创建时间截断与真实 Job 归属组合的小样。不能证明实际 WebView2 子树、原 profile 或原账号通过，也不能反推 8070 的 unknown 是 Python 误判。

## 下一最小诊断路线

先保留原观察 blocked 和唯一良性通过，不重开原浏览器只为猜测。下一候选按 root 要求仅设计独立 wrapper 的 safe tracing，限定冻结 classifier 真正置 uncertain 的 catch 行或 probe 外层失败；不修改七源，不修改原 state 决策、不改 unknown、不给 PID/parent/alias 豁免、不保存 raw metadata、不自动重试。固定 stage/code、已知 family 和当前 row 的对应 bool 是另列诊断，不替代原观察回执。具体仅在新 `phase26-first-occupancy-safe-tracing-plan.md` 记录，尚未实施或执行。

旧 phase26_native_profile_reason.py v2 的 summarizer 直接 canonical_path 所有 exe，没有当前 TrustedCurrentPython 例外；不能把它对固定 UV alias 的预期拒绝当作 v3 新故障证据，更不能用它直接授予 vacancy。

原观察 unique task 的清理 JSON 绑定 8070...，良性 task 的清理 JSON 绑定 935775...，两者 exact_owned_task_removed=true、other_tasks_changed=false、browser_retry_started=false。D 只核 root 已存记录，未查询或清理 Scheduler。任何缺最终结果都保持未知，不换号或重放。
