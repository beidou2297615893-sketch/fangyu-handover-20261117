"""Emit synthetic results from actual local Core; no network or cloud engine."""
from pathlib import Path
from tempfile import TemporaryDirectory
import hashlib
import json
import socket
import sys
from unittest.mock import patch

PROJECT = Path(__file__).resolve().parents[3]
sys.path[:0] = [str(PROJECT/'work/app/src'), str(PROJECT/'work/app/tests')]
from test_company_handoff_preparation import PreparationFixture, FIXTURES
from assistant.company_handoff_preparation import PREPARE, GET


def generate():
    FIXTURES.mkdir(parents=True, exist_ok=True)
    with TemporaryDirectory(dir=FIXTURES) as base, \
            patch.object(socket.socket, 'connect', side_effect=AssertionError('network forbidden')), \
            patch('core.adapters.subprocess.Popen', side_effect=AssertionError('platform forbidden')):
        fixture = PreparationFixture(base)
        try:
            cases = {}
            get_request = {'handoff_id': fixture.handoff['id']}
            def collect(name, action, request):
                cases[name] = {'action': action, 'request': request, 'result': fixture.service.execute(action, request, fixture.actor)}
            collect('missing', GET, get_request)
            collect('prepared', PREPARE, fixture.data)
            collect('replayed', PREPARE, fixture.data)
            collect('get_prepared', GET, get_request)
            fixture.core.store.put('leads', {**fixture.lead, 'text': '合成来源正文已变化'})
            collect('source_changed', GET, get_request)
            fixture.core.store.put('leads', fixture.lead)
            fixture.append_event('unknown', ack=False)
            collect('source_ack_missing', GET, get_request)
            fixture.withdraw()
            collect('withdrawn', GET, get_request)
            sources = ['work/app/src/assistant/company_handoff_preparation.py',
                       'work/app/tests/test_company_handoff_preparation.py']
            return {'synthetic_only': True, 'fixture_execution': 'actual_local_core_store_contact_journal',
                'real_cloud_or_platform_called': False, 'sdk_engine_claimed': False,
                'scope': {'tenant_id': fixture.tenant, 'owner': fixture.owner, 'company_id': fixture.company['id'],
                    'environment_id': fixture.environment, 'device_id': fixture.device},
                'source_sha256': {source: hashlib.sha256((PROJECT/source).read_bytes()).hexdigest().upper() for source in sources},
                'cases': cases}
        finally:
            fixture.close()


if __name__ == '__main__':
    target = Path(__file__).with_name('company-handoff-preparation-actual-fixture.json')
    target.write_text(json.dumps(generate(), ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    print(str(target))
