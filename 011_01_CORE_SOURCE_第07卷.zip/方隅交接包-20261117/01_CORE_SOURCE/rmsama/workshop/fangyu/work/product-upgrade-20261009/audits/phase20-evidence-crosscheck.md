# Phase20 证据一致性增量核对

结论：未发现实质不一致。总 manifest 的 **15 份证据、13 个源码/测试引用、4 张截图**逐一与实际文件 SHA 对上；两 GUI proof 的 **16 个 UI、6 个 Python**引用也与当前磁盘一致。本核对只读取已有本项目证据及生产源码、查看两张既有合成截图；没有重跑测试、读取业务库/Cookie、调用 CLI/网络或重新盘点许可材料。唯一新增文件为本报告。

## 当前总证据

- `audits/private-natural-continuation-current-phase.json` SHA256：`E016A3301D289F959C0D25232C9B2F2A77938F494642FFAF4B54B5EACC77D866`。
- 后端日志确为 **47 模块、511/511，156.690 秒**，当前源码/测试的 13 个引用全部匹配。相对 Phase19 的 503，新增 B3/D3/根 import2 已包含其中，不能再次加到 511。
- 前端日志确为 **26 文件、273/273，2910.3766 毫秒**；C 新独 3 已包含其中，不能再次加到 273。
- 根新 import2 日志 **2/2，0.847 秒**；新 Core 写入使用实际主机的明确时区，丢弃适配器伪时间；旧 naive 资料仍为未知、预检不补写。这里仅核其日志和已冻结源，不冒充本报告执行了该组。
- B 的最终源/测试引用 9 个、C 的引用 9 个、D 的引用 14 个全部与现文件匹配。B manifest 的 `root_full_matrix:running_at_b_evidence_freeze` 是较早冻结时刻的历史状态；当前根总 manifest 和最终日志已记录通过，不构成矛盾。
- UI 本阶段未改；当前冻结 UI 清单 SHA `BCEF8CB8ED4B0BBD782EBE1319F1616672993E20C44F7EFD48ABB0E460E9EFD2`。静态 copy 证据绑定同一清单、backup23、143 项候选，验收记录 16 项冻结 UI/19 资源/5 未知路径；本核对没有重新执行该扫描。`source-freeze-history/phase-21.json` 是历史冻结存档，不充当当前 GUI 的加载证据。

## 实际 GUI 的正确范围

- `private-natural-continuation-loaded-ui-final-verification.json` SHA `E32B60CA59C893114484A372039D45B1C57AFE1A8990C5D3438149C21F533E4B`。
- `private-natural-continuation-gui-evidence.json` SHA `A72525AB78A489565E58E4022D35CAECE936251FF3C5A64B875EB1F810A8FD04`。
- 对应同一合成 preview **PID49020 / port64288**。已保存 command receipt 中两个不同 request 为 `d23c7568-97b7-4d8f-946f-2b6a9f5d5650` 与 `e4da6331-191f-4a6c-b49f-4d86d2425850`，均指定原 task `628905ba43374870b92d8ecf15694d9b`、`max_batches:1`。同号的派发/完成记录不能误计为四批。
- 首批实际自然摘要：读取/新增各 1，未耗尽、`can_continue:true`；原 task/account/source 的 binding hash 未变，租约 expiry 首前后完全相等，策略 revision3、spent0。GUI 首图可见“继续采集”。
- 只打开下一批确认窗口时，数据库 dump 与首批后相同、dispatch 与 completed 都仍为 1。这证明打开窗口本身没有派发下一批。
- 再次明确确认后，第二个 run_id 不同但仍是原 task 单批；最终 tasks1/leads2、keyword_index2、spent2/revision4、lease null，摘要 `exhausted:true/can_continue:false/range_exhausted`，正常完成消耗两个词槽并释放原租约。末图没有“继续采集”按钮。
- 两次摘要的 `batches` 与 snapshot `sequence_batches` 都为 1，表示各次调用的一批，不是全任务累计两批；两次派发由不同 request 和前后次数另证。`remaining999/998` 是评论收录余量，不能当成剩余关键词或可派发次数。
- 界面显著注明 Phase20 合成验收、非真实账号/平台/企业云，并仍显示采集许可待确认；截图中的 `phase20-owner` 不能当成用户现有小红书账号。

GUI 加载的六个 Python 为 Business、StrategyTasks、AcquisitionRunPreflight、ProductWorkspace、Core engine/pipeline；**没有正式 AppServer 或 RuntimeLicensePolicy**。正式 Server 新 getter 的既有构造测试不等于这次 GUI 实际启动过正式 Server。总 manifest 的 `new_formal_server_live_boot_verified:false` 与此一致。

## 四张截图绑定

| `outputs/产品升级` 下文件 | SHA256 |
|---|---|
| 自然原任务续批-首批完成与继续入口.png | `68CD4211D63597D4DB2EB194493D5382730B0A30A2662702998E088698EFFBFF` |
| 自然原任务续批-下一批重新确认.png | `08387CAC5A97B91495D57EBFB8EB2F5A47EEB54A513BAC86AAF36A93D96E4D02` |
| 自然原任务续批-原范围完成停止.png | `79FB4CED65A9489C3C3F8F81B71343321FB2E70A72F7353020F4FEEAB5048F32` |
| 自然原任务续批-两批评论同任务范围.png | `0EFC67168052FD1415B0169EB980271D057E6D9F22156BE8F1B3F604FFF8F325` |

用户阶段报告 `outputs/产品升级/原任务自然续批-阶段验收.md` SHA `D3EC5674335C0E6AEE4ABF0CC7D34C177863A204A87EA6D603C3FD7DD16EA791`：正确区分两批合成自然链路和后续真实电脑会话验证，未称长期总目标完成、正式打包或真实获客。

## 仍需真实输入/验证的事项

用户已确认**沿用现有账号、手机端正常**；不再把这些事实列为缺少手机号或要求重建账号。现有电脑会话是否有效、实际 selected CLI 的运行材料审核、真实平台只读调用及风险信号仍需各自核验。手机正常不证明桌面会话、接口、审核许可或真实高意向准确率；合成 owner、合成允许条件也不能替代原账号绑定。

总 manifest 保持 `real_computer_session_verified/new_formal_server_live_boot_verified/runtime_materials_approved/real_platform_verified/cross_machine_verified/real_accuracy_verified/goal_complete/packaged/deployed` 均为 false；`automatic_next_batch/lease_extended/task_recreated` 为 false。自然继续和两个明确单批的合成验证为 true，未将它们推广为真实获客、送达、佣金或商业结果。额度暂停条件已按用户新指令取消，自动监控仍 ACTIVE；这里不重新增加暂停门槛。
