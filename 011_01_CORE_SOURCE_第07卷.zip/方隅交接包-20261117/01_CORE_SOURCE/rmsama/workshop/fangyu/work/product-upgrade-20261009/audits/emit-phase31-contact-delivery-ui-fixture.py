"""Synthetic actual Core/gateway DTOs. Explicit values are fixture-only, not customers."""
import importlib.util,json,hashlib,socket
from pathlib import Path
from tempfile import TemporaryDirectory
from unittest.mock import patch
HERE=Path(__file__).parent
PROJECT=HERE.parents[2]
spec=importlib.util.spec_from_file_location('phase31_delivery_fixture',HERE/'test_phase29_local_contact_delivery.py')
mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
cases={}
tmp_root=PROJECT/'work/product-upgrade-20261009/tmp/phase31-ui-fixture';tmp_root.mkdir(parents=True,exist_ok=True)
with TemporaryDirectory(dir=tmp_root) as tmp,patch.object(socket.socket,'connect',side_effect=AssertionError('network forbidden')):
    f=mod.DeliveryFixture(Path(tmp)/'normal')
    try:
        get=lambda action,receiver=False:f.call(mod.GET,{'channel_id':f.channel,'operation_action':action},receiver=receiver,use_gateway=True)
        cases['source_ready']=get(mod.PUBLISH)
        cases['withdraw_ready']=get(mod.WITHDRAW)
        cases['published']=f.call(mod.PUBLISH,use_gateway=True)
        cases['receiver_ready']=get(mod.REVEAL,True)
        cases['released']=f.call(mod.REVEAL,receiver=True,use_gateway=True)
        cases['release_recorded']=get(mod.REVEAL,True)
        cases['withdrawn']=f.call(mod.WITHDRAW,use_gateway=True)
        cases['withdraw_recorded']=get(mod.WITHDRAW)
        contact=f.contact
        source={'channelId':f.channel,'mode':'source','contactReference':contact['contact_reference'],'leadId':contact['lead_id'],'recipientId':contact['recipient_id'],'purpose':contact['purpose']}
        receiver={'channelId':f.channel,'mode':'receiver','recipientId':contact['recipient_id'],'purpose':contact['purpose']}
        requests={'publish':f.publish,'reveal':f.reveal,'withdraw':{'channel_id':f.channel,'expected_revision':2}}
    finally:f.close()
    f=mod.DeliveryFixture(Path(tmp)/'lost')
    try:
        f.call(mod.PUBLISH);f.command({'kind':'lose'})
        try:f.call(mod.REVEAL,receiver=True)
        except mod.CompanyContactDeliveryError:pass
        cases['release_lost_recorded']=f.call(mod.GET,{'channel_id':f.channel,'operation_action':mod.REVEAL},receiver=True,use_gateway=True)
    finally:f.close()
    f=mod.DeliveryFixture(Path(tmp)/'missing',configured=False)
    try:cases['provider_missing']=f.call(mod.GET,{'channel_id':f.channel,'operation_action':mod.PUBLISH},use_gateway=True)
    finally:f.close()
paths=['work/app/src/assistant/company_contact_delivery.py','work/app/src/assistant/company_contact_delivery_transport.py','work/cloud/workspace/contact_delivery.cjs','work/cloud/workspace/service.cjs','work/product-upgrade-20261009/audits/test_phase29_local_contact_delivery.py','work/product-upgrade-20261009/audits/phase29-local-contact-delivery-sdk-worker.cjs']
value={'synthetic_only':True,'execution_boundary':'actual two Core/gateway/service/createStore SDK-interface memory adapter; official KMS request opaque stub, no real cryptography/network/physical machines','source':source,'receiver':receiver,'contact_metadata':contact,'requests':requests,'cases':cases,'source_metadata':[{'path':p,'sha256':hashlib.sha256((PROJECT/p).read_bytes()).hexdigest().upper()} for p in paths]}
(HERE/'phase31-contact-delivery-ui-actual-fixture.json').write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('actual fixture cases',len(cases))
