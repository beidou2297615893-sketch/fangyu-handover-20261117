# Phase26 独立 v2 追踪标签代表验收

独立新增 `diagnostics/benign-webview-metadata/safe_trace_v2.py` 已通过 3 个合成代表（0.012s）。冻结 v1 trace、4 个良性候选、7 个诊断源与复用 867B probe 未改；0464 实际阻断回执和此前审核不改写。v2 尚未接到 Native 候选，也没有新浏览器/运行账户结果。

## 最小改动与证据

v2 从冻结 trace `C2A047…` 复制，只修改文件说明及 If 阶段识别：AST `Name` 的精确标识符用于识别 `own`、`expected_browser`、`argv`、`executable`；AST 的 `row['owner_sid']` 字段用于基础身份门禁 `owner_metadata` 标签。原 `own` 赋值/真正 Job 检查仍标 `creation_job`。`owner_metadata` 对应原 parent/created/owner 综合门禁，不表示该门禁仅检查 owner。代码白名单、安全投影、冻结分类器 SHA、trace 安装/恢复方式与分类授权均未改变。

旧事实逐字节备份在 `C:/积木软件工坊/项目/方隅公寓客户版/work/product-upgrade-20261009/backups/phase26-safe-trace-v2/1`：12 个旧源、旧候选 manifest、0464 actual result、原 actual review/manifest 共 16 文件，复制前后 SHA 一致，backup manifest SHA `975B9F86926FE01467706E8E1FC451E23E95D19074A0D6A7E02B347AEFCB3E8F`。

唯一新 test 为 [test_phase26_safe_trace_v2.py](C:/积木软件工坊/项目/方隅公寓客户版/work/product-upgrade-20261009/audits/test_phase26_safe_trace_v2.py)。同一测试可在 test-only `PHASE26_TRACE_TEST_VERSION=legacy` 选择冻结 v1；此参数不授予产品或运行账户权限。

| 代表 | 旧 v1 | 新 v2 | 核验边界 |
| --- | --- | --- | --- |
| owner 缺失、owned 回调异常同为 process_metadata_unavailable | owner 标签真 RED | GREEN | owner 缺口在回调前为 owner_metadata；有效元数据后回调抛错为 creation_job，两者都保留 unknown |
| 无显式 profile，通过本人可信默认 route 解析无关 profile | GREEN | GREEN | 正常 fallback 不生成 uncertain，不调用 owned 回调；分类为 vacant，仅合成输入 |
| 上一行 own=true，下一行缺 owner | owner 标签真 RED | GREEN | 下一行 owner_current 与所有派生值为 null；不继承上一行 own/profile/argv |

旧源运行同 3 方法：1 通过、2 断言失败，0.011s，日志 `phase26-safe-trace-v2-legacy-red.txt`。新源同 3 方法：3/3 通过，0.012s，日志 `phase26-safe-trace-v2-green.txt`。旧 RED 的失败均为 `creation_job != owner_metadata`，不是另一个 Native/平台失败。完整 SHA 在 `phase26-safe-trace-v2-final-hashes.json`。

## 真实复用与限制

测试直接导入并执行真实冻结 `profile_occupancy.classify`，没有复制或替换其 owner/profile/回调/unknown 分支。只将 canonical_path/Windows argv 两个 native IO 边界替换为合成词法解析；同输入有 trace/无 trace 的分类结果与 fingerprint 必须完全一致。此边界替换不能证明真实 Windows 路径、argv、CIM、生命周期或 Job。

每个代表禁止 subprocess.Popen/run、socket.connect 与 SQLite connect；没有构造 WindowsProfileOccupancy、真实 Job、runtime capture、Bootstrap 或账号对象。输出检查拒绝 SID、原字段 PID/parent_pid/owner_sid/command_line 与合成路径；trace 必须恢复进入前状态。本轮没有 CIM、Native、浏览器、原 DATA/Cookie/DPAPI、CLI、平台/云/模型调用，没有 dispatch、family/PID/profile 豁免，也未核账号 UID。

v2 的成功只确认安全标签机制。0464 的 owner 元数据为何缺失仍未知，不能自动称退出竞态；原 8070 同因、页面 loaded、原账号恢复仍未证。下一步若 parent 认为实际定位有增益，须先独审并固定新的运行候选源码，再由 root 决定一次 benign 观察；本轮不授权或建议未经证实重复开原号。处理退出 race 仍须此前报告的同句柄/创建时间/signaled 与最终完整快照证明。
