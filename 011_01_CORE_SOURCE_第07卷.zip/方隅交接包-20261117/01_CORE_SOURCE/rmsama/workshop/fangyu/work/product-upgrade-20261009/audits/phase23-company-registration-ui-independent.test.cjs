/* Production checker/controller and app execute, with actual synthetic Core/SDK DTOs.
 * Lightweight DOM and controlled transport timing; not browser GUI or a deployed SDK engine.
 */
'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),crypto=require('node:crypto');
const folder=path.resolve(__dirname,'../../app/src/web/workspace');
const source=fs.readFileSync(path.join(folder,'upgrade-operations-ui.mjs'),'utf8');
const fixture=JSON.parse(fs.readFileSync(path.join(__dirname,'company-handoff-registration-actual-fixture.json'),'utf8'));
class Element {
  constructor(tag){this.tagName=tag.toLowerCase();this.children=[];this.parentNode=null;this._text='';this.dataset={};this.attrs={};this.events=new Map();this.disabled=false;this.hidden=false;this.checked=false;this.value='';this.className='';this.classList={add(){},remove(){},toggle(){}};}
  set textContent(value){this.replaceChildren();this._text=String(value);}get textContent(){return this._text+this.children.map(node=>node.textContent).join('');}
  append(...nodes){for(const node of nodes){node.remove();node.parentNode=this;this.children.push(node);}}
  replaceChildren(...nodes){for(const node of this.children)node.parentNode=null;this.children=[];this._text='';this.append(...nodes);}
  remove(){if(this.parentNode)this.parentNode.children=this.parentNode.children.filter(node=>node!==this);this.parentNode=null;}
  setAttribute(key,value){this.attrs[key]=String(value);}removeAttribute(key){delete this.attrs[key];}
  addEventListener(key,fn){this.events.set(key,[...(this.events.get(key)||[]),fn]);}
  querySelectorAll(selector){const choices=selector.split(',').map(value=>value.trim()),match=node=>choices.some(value=>value.startsWith('#')?node.id===value.slice(1):value.startsWith('.')?(node.className||'').split(' ').includes(value.slice(1)):node.tagName===value);return this.children.flatMap(node=>[...(match(node)?[node]:[]),...node.querySelectorAll(selector)]);}
  querySelector(selector){return this.querySelectorAll(selector)[0]||null;}
  focus(){}close(){this.open=false;}showModal(){this.open=true;}
  click(){if(!this.disabled)this.onclick?.();}
  change(checked){this.checked=checked;for(const callback of this.events.get('change')||[])callback({target:this});}
}
const clone=value=>structuredClone(value),envelope=result=>({status:'succeeded',result:clone(result)});
const tick=()=>new Promise(resolve=>setImmediate(resolve));
function deferred(){let resolve;const promise=new Promise(yes=>{resolve=yes;});return {promise,resolve};}
async function waitFor(fn){const until=Date.now()+2500;while(!fn()){if(Date.now()>until)assert.fail('production controller callback did not settle');await tick();}}
function context(){return {user:{id:'phase23-synthetic-actor',username:'phase23-owner',tenant_id:'phase23-synthetic-tenant',role:'operator',company_id:'phase23-company'},deviceId:'phase23-device',deviceGeneration:1,companyId:'phase23-company',environmentId:'phase23-environment',localWorkspace:true};}
function actual(doc){const idle=()=>({open(){},reset(){},dispose(){}});return vm.runInNewContext(source.replace(/^const \{[^\n]+\}=await import\([^\n]+\);\r?\n/gm,'').replace(/export /g,'')+'\n({createUpgradeOperations,checkedCompanyRegistration,checkedCompanyPreparation,operationLockSlot});',{
  document:doc,window:{},console,Date,crypto:crypto.webcrypto,TextEncoder,createIntentRuleUI:idle,createPlatformReadUI:idle,createIntentQualityUI:idle,createCompanyPolicyUI:idle,createBusinessReconciliationUI:idle,createSelfWorklistUI:idle,createSelfDailyEvidenceUI:idle});}
function preparationFor(name){const entry=fixture.cases[name],result=entry.preparation_get_result||fixture.preparation_get_results?.[name]||(entry.request.handoff_id===fixture.cases.not_attempted.request.handoff_id?fixture.preparation_get_result:null);assert.ok(result,'fixture must include the actual preparation GET for '+name);assert.equal(result.read_only,true,'do not fake write receipt as GET');assert.equal(result.mutation_committed,false);assert.equal(result.current.handoff_id,entry.request.handoff_id);return result;}
function harness({name='not_attempted',registrationGet,register}={}){
  const doc={createElement:tag=>new Element(tag),body:new Element('body')},factory=actual(doc),prepared=preparationFor(name),id=prepared.current.handoff_id,calls=[],values=new Map(),errors=[];let principal=context();
  values.set(factory.operationLockSlot(principal,'handoff_submit',id),JSON.stringify({action:'handoff_submit',idempotency_key:'phase23-old-unknown',payload_digest:'a'.repeat(64),state:'unknown'}));
  values.set('phase23-unrelated-opaque-original',JSON.stringify({idempotency_key:'phase23-other-original',state:'unknown'}));
  const storageBefore=JSON.stringify([...values]);
  const operations=factory.createUpgradeOperations({execute:async(action,data)=>{calls.push({action,data:clone(data)});
    if(action==='company_handoff_preparation_get'){assert.deepEqual(clone(data),{handoff_id:id});return envelope(prepared);}
    if(action==='company_handoff_registration_get'){assert.deepEqual(clone(data),{handoff_id:id});return registrationGet?registrationGet():envelope(fixture.cases[name].result);}
    if(action==='company_handoff_register'){assert.deepEqual(clone(data),{handoff_id:id,expected_origin_id:prepared.origin.origin_id,expected_handoff_revision:prepared.origin.local_handoff_revision},'only original origin and revision; no client cloud key/body');return register?register():envelope(fixture.cases.first_recorded.result);}
    assert.fail('no generic write, recover, source sync, second dispatch, or status auto-query: '+action);},getContext:()=>principal,shell:{hooks:{setAction(){}},refresh:async()=>assert.fail('registration must not refresh background operations')},onError:error=>errors.push(error),
    storage:{getItem:key=>values.get(key)||null,setItem(){assert.fail('registration must not persist browser metadata');},removeItem(){assert.fail('registration must not clear original unknown slots');}}});
  const record={id,recipient_name:'合成资源部',purpose:'合成交接用途'};
  return {doc,factory,operations,record,calls,errors,prepared,context:change=>{principal=change;},button:label=>doc.body.querySelectorAll('button').find(node=>node.textContent===label),checkbox:()=>doc.body.querySelectorAll('input').find(node=>node.type==='checkbox'),status:()=>doc.body.querySelector('.upgrade-status'),writeCount:()=>calls.filter(call=>call.action==='company_handoff_register').length,unchanged:()=>assert.equal(JSON.stringify([...values]),storageBefore)};
}
async function openConfirmation(h){await h.operations.openCompanyPreparation(h.record);assert.deepEqual(h.calls.map(call=>call.action),['company_handoff_preparation_get']);h.button('登记或核对公司草稿').click();await waitFor(()=>h.checkbox());}
test('six actual Core/SDK DTOs pass exact projection; contradictory origin, private fields and unsupported verification fail closed',()=>{
  assert.equal(fixture.synthetic_only,true);assert.equal(fixture.fixture_execution,'actual_Core_and_createService_createStore');assert.equal(fixture.real_cloud_called,false);assert.equal(fixture.cloud_network_called,false);
  const check=actual({createElement:tag=>new Element(tag),body:new Element('body')}).checkedCompanyRegistration;
  assert.deepEqual(Object.keys(fixture.cases).sort(),['attempt_unknown','first_recorded','not_attempted','recorded_get','response_lost_recorded','withdrawn_historical']);
  for(const entry of Object.values(fixture.cases)){assert.equal(Object.keys(entry.result).length,36);assert.equal(check(entry.result,{handoffId:entry.request.handoff_id,origin:fixture.prepared_result.origin,readOnly:entry.result.read_only}),entry.result);assert.equal(entry.result.eligible_for_company_submit,false);assert.equal(entry.result.verified_cash_cents,null);assert.equal(entry.result.verified_paid_commission_cents,null);}
  const lost=fixture.cases.response_lost_recorded.result;assert.equal(lost.state,'recorded');assert.equal(lost.attempt.state,'unknown');assert.equal(lost.registration_source_verified,false);assert.equal(lost.can_register,false);
  for(const mutate of [r=>{r.private_body='PRIVATE-TEXT';},r=>{r.origin.cloud_payload_hash='PRIVATE-HASH';},r=>{r.original_operation.payload_hash='PRIVATE-HASH';},r=>{r.original_operation.channel_id='hc_'+'a'.repeat(64);},r=>{r.origin.origin_id='a'.repeat(64);},r=>{r.current_local.revision++;},r=>{r.source_cloud_binding_verified=true;},r=>{r.eligible_for_company_submit=true;},r=>{r.platform_delivery_verified=true;},r=>{r.verified_cash_cents=0;},r=>{r.can_register=true;},r=>{r.no_dispatch=true;}]){const r=clone(fixture.cases.first_recorded.result);mutate(r);assert.throws(()=>check(r,{handoffId:fixture.request.handoff_id,origin:fixture.prepared_result.origin,readOnly:false}),/未通过核对/);}
  const invented=clone(lost);invented.registration_source_verified=true;assert.throws(()=>check(invented,{handoffId:lost.current_local.handoff_id,origin:fixture.prepared_result.origin}),/未通过核对/);
});
test('opening is GET only; unchecked confirmation dispatches zero; explicit confirmation and double-click submit only the original three fields once',async()=>{
  const gate=deferred(),h=harness({register:()=>gate.promise});await openConfirmation(h);
  const checkbox=h.checkbox(),button=h.button('确认登记公司草稿');assert.equal(checkbox.checked,false);assert.equal(button.disabled,true);button.click();await tick();assert.equal(h.writeCount(),0);
  checkbox.change(true);assert.equal(button.disabled,false);button.click();button.click();await waitFor(()=>h.writeCount()===1);assert.equal(h.calls.length,3);gate.resolve(envelope(fixture.cases.first_recorded.result));await waitFor(()=>h.doc.body.textContent.includes('公司原编号草稿登记已核对，登记来源摘要一致。'));
  assert.equal(h.checkbox(),undefined);assert.equal(h.writeCount(),1);assert.match(h.doc.body.textContent,/尚未执行资源部交付/);assert.match(h.doc.body.textContent,/此次不确认资源部独立接收、平台送达、成交、分成或回款/);assert.equal(h.button('确认登记公司草稿'),undefined);h.unchanged();h.operations.dispose();
});
test('transport error holds even a false mutation flag; fresh GET unlocks only explicit confirmation; actual unknown and recovered history reopen without re-dispatch',async()=>{
  const h=harness({register:()=>{throw Object.assign(Error('合成丢回执'),{mutation_committed:false});}});await openConfirmation(h);h.checkbox().change(true);h.button('确认登记公司草稿').click();await waitFor(()=>h.status().dataset.state==='error');assert.equal(h.writeCount(),1);assert.equal(h.checkbox(),undefined);assert.match(h.doc.body.textContent,/仅提供原号核对，不再次提交/);h.button('核对原公司草稿').click();await waitFor(()=>h.checkbox());assert.equal(h.checkbox().checked,false);assert.equal(h.button('确认登记公司草稿').disabled,true);assert.equal(h.writeCount(),1);h.unchanged();h.operations.dispose();
  for(const name of ['attempt_unknown','response_lost_recorded','withdrawn_historical']){const h=harness({name});await h.operations.openCompanyPreparation(h.record);h.button('登记或核对公司草稿').click();await waitFor(()=>h.button('核对原公司草稿'));assert.equal(h.checkbox(),undefined);assert.equal(h.writeCount(),0);
    if(name==='attempt_unknown')assert.match(h.doc.body.textContent,/原编号登记结果仍未知/);
    if(name==='response_lost_recorded'){assert.match(h.doc.body.textContent,/登记来源证据仍待核对/);assert.doesNotMatch(h.doc.body.textContent,/登记来源摘要一致/);}
    if(name==='withdrawn_historical'){assert.match(h.doc.body.textContent,/本机当前交付保持暂停/);assert.doesNotMatch(h.doc.body.textContent,/当前来源与授权可用于本次准备/);}
    await h.operations.openCompanyPreparation(h.record);h.button('登记或核对公司草稿').click();await waitFor(()=>h.button('核对原公司草稿'));assert.equal(h.writeCount(),0);assert.equal(h.calls.filter(call=>call.action==='company_handoff_registration_get').length,2);h.unchanged();h.operations.dispose();}
});
test('actor/company/environment/device/reset fences discard late reads and writes; actual app local-only registration cannot fall through to generic command submit',async()=>{
  const changes={actor:c=>{c.user.id='changed-actor';},role:c=>{c.user.role='admin';},actorCompany:c=>{c.user.company_id='changed-actor-company';},company:c=>{c.companyId='changed-company';},environment:c=>{c.environmentId='changed-environment';},device:c=>{c.deviceId='changed-device';},generation:c=>{c.deviceGeneration++;},accept:null,reset:null};
  for(const stage of ['read','beforeWrite','write'])for(const [name,change]of Object.entries(changes)){const gate=deferred(),h=harness({registrationGet:stage==='read'?()=>gate.promise:undefined,register:()=>gate.promise});let accepted=true;await h.operations.openCompanyPreparation(h.record,{accept:()=>accepted});h.button('登记或核对公司草稿').click();
    if(stage==='read')await waitFor(()=>h.calls.length===2);else{await waitFor(()=>h.checkbox());h.checkbox().change(true);if(stage==='write'){h.button('确认登记公司草稿').click();await waitFor(()=>h.writeCount()===1);}}
    if(change){const c=context();change(c);h.context(c);}if(name==='accept')accepted=false;if(name==='reset')h.operations.reset();
    if(stage==='read')gate.resolve(envelope(fixture.cases.not_attempted.result));if(stage==='beforeWrite')h.button('确认登记公司草稿')?.click();if(stage==='write')gate.resolve(envelope(fixture.cases.first_recorded.result));await tick();await tick();
    assert.doesNotMatch(h.doc.body.textContent,/公司原编号草稿登记已核对，登记来源摘要一致/);if(stage==='read')assert.equal(h.checkbox(),undefined);assert.equal(h.writeCount(),stage==='write'?1:0);h.unchanged();h.operations.dispose();}
  const app=fs.readFileSync(path.join(folder,'app.mjs'),'utf8'),start=app.indexOf('const PRODUCT_ACTIONS=new Set('),end=app.indexOf('\nasync function requestTaskStop(',start);assert.ok(start>=0&&end>start);
  for(const localWorkspace of [true,false,undefined])for(const action of ['company_handoff_register','company_handoff_registration_get']){const calls=[],data=action.endsWith('_get')?fixture.cases.not_attempted.request:fixture.request,state={selected:'phase23-device',deviceGeneration:1},cloud={user:context().user,call:async(operation,request)=>{calls.push({operation,request:clone(request)});return {result:action.endsWith('_get')?fixture.cases.not_attempted.result:fixture.cases.first_recorded.result};}};
    const execute=vm.runInNewContext(app.slice(start,end)+'\nexecute;',{config:{localWorkspace},cloud,state,customerPrincipalSignature:user=>JSON.stringify(user),submit:async()=>assert.fail('registration must never use command_submit')});
    if(localWorkspace===true){assert.equal((await execute(action,data)).status,'succeeded');assert.deepEqual(calls,[{operation:'product_action',request:{action,data}}]);}else{await assert.rejects(()=>execute(action,data),error=>error.mutation_committed===false);assert.equal(calls.length,0);}}
});
