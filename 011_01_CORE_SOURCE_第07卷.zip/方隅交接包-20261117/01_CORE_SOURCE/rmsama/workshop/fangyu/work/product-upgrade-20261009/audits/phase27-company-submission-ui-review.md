# Phase27 公司资源部提交：前台与隔离实屏验收

本切片把本人已有公司草稿推进到一次明确资源部提交，保留认可布局；提交后的未知、原号历史记录、独立接收登记和当前撤回分层呈现。现有云 API 未部署，所有运行与截图来自本项目隔离合成数据，没有真实账号、公司业务库、平台、模型、消息或打包。

## 真实操作与边界

打开原准备页仍只调用原 preparation GET。用户点击“核对或提交资源部”后才执行纯读 `company_handoff_submission_get{handoff_id}`。只有服务端当前资格为 true 才显示默认未勾选的确认框；勾选并点击“确认提交资源部”只发 `handoff_id / expected_origin_id / expected_handoff_revision / expected_cloud_revision` 四字段。前端不造 UUID、key、手机号或微信载荷，不用通用 receipt。

任何已有 attempt、unknown 或 recorded 均只提供原号 GET，不再提交或换号。丢回执后 GET 返回历史 recorded，而持久 attempt 仍为 unknown，是保留原不明历史的正常恢复，不由读取重写 metadata。原登记回显丢失的 `registration_source_verified=false` 单列保留；当前提交资格由服务端本次精确来源及当前权限决定。历史 submitted、当前 withdrawn、当前授权与历史资源部接收分别显示，GET 成功事实不被旧登记警告覆盖。

原主体、role、company、environment、device、device generation、handoff/revision、origin、dialog/read generation 的迟到响应均有 fence。`checkedCompanySubmission` 严格验证实际 36 字段回执，不接受额外私有字段、伪历史、错误版本、自动重试或平台/现金成功。cloud-only 路由不派发本机动作。全状态说明仅提交平台线索引用；没有评论/私信自动发送，也不写本机联系人已联系或本机交接已交付。

## 代表测试与当前回归

B 新轻量 DOM/实际 controller 3 个唯一方法使用实际 Core/createService/createStore 产出的八状态 DTO。覆盖迟到身份/客户/版本变化；未勾选拒提交、double click 只派发一次、unknown/recorded 不重发；历史与当前分层、严格合同及真实 app 网关入口。首跑 2/3 的真实 P2 是成功重绘后平台引用说明消失，已移为全状态说明，原日志保留；同三方法 3/3，107.4436ms。

必要六文件影响组 37/37，145.5684ms，其中旧 34 与新 3，不另算新覆盖。主窗口当前完整前端 30 文件 286/286，2543.1339ms；B 没有重跑。原 runner 写出 GREEN 日志、通过源码稳定断言后，GBK stdout 打印 U+2714 报错。旧 wrapper 留档，新 wrapper 仅改 UTF-8 stdout；恢复脚本核原日志和当前 33 份源码/测试 SHA 后补收据，未再次执行 Node。详见 `phase27-company-submission-frontend-wrapper-correction.md`，此事是工具收据修正，不是产品 RED。

C 独立静审使用当前 F5E/50DD 和实际 DTO，无新阻断，未新增测试或 GUI 执行。B 新增测试仍仅三方法；同一方法重复执行不累加覆盖。

## 新隔离实屏与证据

主窗口在 PID 46364 / 端口 64695 完成真实浏览器操作。启动时登记/提交/渠道均 0；一次明确登记整回显丢失后，原 submission GET 当前资格为 true、历史登记来源 flag 仍 false。唯一勾选提交整回显丢失；随后原号 GET、reload/reopen 仅读取，不发生第二次登记或提交。合成资源部映射中不同于 source 的账号登记接收事件，再合成客户撤回；历史 submitted revision 2 与历史接收保留，当前公司状态依次 submitted 2 / accepted 3 / withdrawn 4。

新的动作 verifier 逐项核 12 条日志、8 次 GET 库 dump 前后 SHA 相同、最终 1 register / 1 submit / 1 channel。四次 recovered GET 的 attempt（unknown 与原时间）和历史提交完整结构相同。GET dump 不变不冒称这份日志本身提供 SQL trace 量化 0DML；fixture 撤回会修改本机数据，整个 GUI 并非零写。资源主体鉴权和映射经过实际服务/createStore 的 SDK 接口兼容内存 adapter，未运行 node-sdk 内部事务引擎或真实云。接收证据 `independently_verified=false`，现金及已付分成仍 null。

新 loaded verifier 核 16 个最新实际 served UI 与盘及 freeze 一致，13 个 Python 与 8 个云候选启动 SHA 与盘一致；认可目标图字节保持。五张状态 JPG 与动作日志相符。首张首次确认上部截屏仅历史材料，不能替代完整状态证据；图为窄视口上下滚动分屏，不冒充 1586 宽桌面整体认可。

证据：`phase27-company-submission-gui-proof.json`、`phase27-company-submission-loaded-ui-verification.json`，以及主窗口原 actions/assets 日志和五张 `outputs/产品升级/公司资源部提交-*.jpg`。

## 源码与未发布候选封存

- ops：`F5E05C2006B76F58F06DD9D47FBF3234A42606A620E5F8F1A96DE234C4852A95`
- app：`50DD120BA79785B9101BEF54F015A7359D5B4D23893865BD8583FC7C3E837844`
- 新 test：`DE0ED7A78455DAEF182A240AF89CC97026D3E84152A3B53677A7332ADB93DCC9`

当前 16 UI freeze 已另存 `phase27-company-submission-source-freeze.json`；替换前 generic manifest 保存在 `source-freeze-history/phase-26.json`，旧 Phase25 命名证据与源 snapshot 未修改。143 文件只同步本地未发布 cloud site 候选，原候选字节存 backup 28；同步前 generic copy 另存 `backups/phase27-artifact-seal/1`。新静态 verifier 直接调用 actual serveSite，一次通过 19 二进制资源 / 16 源码 / 5 未知路径拒绝，不是 HTTP、部署或性能测试。

阶段源码没有因证据封存再改。测试/实屏技术通过不等于用户视觉认可、真实云上线、真实资源部独立验真、平台允许、成交、回款或分成支付。后端 B 原 final manifest、Phase25 历史材料和原 DATA 保持独立；主窗口负责统一阶段文档。

C 新 GUI 证据独审已封存：`phase27-company-submission-gui-independent-review.md` SHA `F0C310A7CAEDCA7B3BEB23D05C04D95BFFDB98DA545F883FC126A7CF08CD6BBD`；manifest SHA `AE9CA83F7D9A9C0C61150E21F42FDF67BA38FAAC8390ABCE2E625F474903A466`。直接核对日志、37份加载源码、19份静态二进制哈希和五张状态图，没有新增缺口；C 未执行新测试、GUI 或重跑 serveSite。
