# Phase29 本机公司联系方式桥候选

已实现四个固定本机动作及窄 ProductWorkspace 接线，新增独立 opaque 尝试记录。当前只完成合成后端代表；未接 UI、未调用真实云/KMS/DPAPI、未用真实账号或两台机器，未部署打包。资金与平台独立核验仍 false/null，阶段目标不声明完成。

## 实际接口

`CompanyContactDelivery(core, tenant, owner, company, *, device_id, scope_guard, cloud_contact, cloud_read, cloud_withdraw, lead_access, contact_crypt=None, clock=None)`。

| 本机动作 | 精确请求字段 | 实际云动作 |
|---|---|---|
| company_contact_publish | channel_id, expected_revision, contact_reference, expected_contact_revision | acquisition_contact_publish |
| company_contact_reveal | channel_id, expected_revision, contact_version, expected_contact_revision | acquisition_contact_reveal |
| company_contact_withdraw | channel_id, expected_revision | acquisition_handoff_withdraw，reason_code 固定 customer_withdrew |
| company_contact_operation_get | channel_id, operation_action（上述三个本机写动作之一） | 对应原联系方式 STATUS 或成熟 handoff operation status |

客户端不能传联系人值、员工、设备、接收方、用途、云 key、许可或恢复判定。新的固定 transport 使用现有当前未过期 session，无 refresh/config-write/verify_identity。云联系方式响应严格 outer7、inner31；`retention_configured`、`channel_binding_state` 与三项权限来自本次受信响应。撤回独立使用成熟公司撤回/原操作状态，不以本机 contact_revoke 冒充公司停止使用。

本机 DTO 合同 `local_company_contact_delivery_v1`，主要字段：action/read_only/mutation_committed、channel_id/state、attempt（原动作/key/version/revision/time/state 元数据）、delivery（云 exact31 或 null）、current（已有 receiver 安全渠道投影）、withdrawal_receipt（移除原 payload_hash 的窄纯读回执）。恢复 `state=recorded` 可与 `attempt.state=unknown` 同时存在；前者是公司原号已记录，后者保留本机原写丢回执。GET 不修复历史。

## 持久化与先后次序

新 entity `company_contact_delivery_attempts`，固定 version1。ID 与云 key 由 tenant/environment/company/owner/action/channel 派生；设备不进入 ID/key，但 row 严格绑定设备，换设备不能另起绕过未知记录。row 仅保存 scope、原动作/key、渠道/联系人 opaque 引用与版本、hash、时间和 unknown/recorded；不存 phone/wechat/ciphertext、正文或结果缓存。

新发布先只读 STATUS，确认为当前 provider+retention 可用、渠道 unbound、原号 not_recorded 且 can_publish；再核公司 DETAIL 与本机 contact 的 owner/device/platform UID/comment/lead 与正文 hash/完整 immutable journal/接收方/用途/同意/版本相符。BEGIN IMMEDIATE 提交 unknown 后，才调用现有 AcquisitionContacts 的明确 revealed 审计与解密。解密前、解密后及最后远端读取后复核本机来源/联系人/撤回/原 row，并复核 actor/company/device、公司当前版本与权限；任何提交后异常保留 unknown。

REVEAL 是一次明确、受当前映射权限限制的公司写操作。首次合法响应的值只在 RAM 返回；它们不进入 local row、generic ProductOperationReceipts 或安全 fixture。未知或重复请求只按原 key 读 STATUS，无法第二次 decrypt。公司 admin 角色本身不替代服务端接收映射（源码边界，未另加 admin 代表）。

WITHDRAW 不依赖 vault/provider；未知发布已占用但无密文时仍可按成熟公司源撤回写入同意 tombstone。该动作不自动更改本机联系方式同意，更不以本机撤回宣称跨设备已经停止。历史发布 unknown 与当前公司 withdrawn 分列。

首次写调用确实登记了本机 intent/确认时，顶层 read_only=false/mutation_committed=true；如服务器曾回放原结果，inner delivery 的 replayed/read_only 仍独立保留。只有纯 GET/已有 attempt 的 STATUS 路径顶层 read_only=true/mutation=false，实际 0 DML。

## 验证与首次失败

最终同三个方法：3/3 GREEN，6.355 秒，日志 `phase29-local-contact-delivery-final-green.txt`。这些方法不是新增更多测试组，未重跑已冻旧矩阵。

1. 实际两个 Core、现 gateway/transport/service/store：provider 未配置或 retention=null 时 0 attempt/0 DPAPI 解密/0 revealed audit/0 publish/KMS。合法 source publish 后，独立空 receiver Core 首次 REVEAL commit-lost，restart 后原 GET 恢复 recorded、attempt unknown、values null；重复请求只有 STATUS，Decrypt 总计1。另同组实际 gateway 新 REVEAL 成功仅 RAM 有值，之后只读重查无值，持久 row 无这些值。
2. 当前本机 lead 换 UID 时完整 immutable 来源校验拒绝，0 decrypt/0 attempt；解密后本人被禁用时 0 cloud publish，尝试留 unknown；原 GET/重复不再解密。self-consistent 改 row 的设备/key/environment 也在云读前拒绝且不修补。
3. 未知 publish 无 vault 后成熟公司撤回成功、当前同意无效、原 publish unknown 保留；资金 null。恶意 release actor 回执被拒，原 GET 仅元数据，未暴露值/UID/正文。

首次 local RED 是既有 `_owned_event` 明确拒绝错 UID 后，新 helper 未转为自己的 typed prevalidation false，测试抛出了 BusinessReconciliationError（0 发送/0 解密）。已只在新 helper 包该来源校验，preclaim 转自身明确 false；postclaim 仍统一 unknown。首日志与当时新 module/test 字节保留于 `backups/phase29-contact-delivery-local/2`，不是把合法拒绝宣称越权。根的 producer anchor 独2由根执行，不计入本机这3组。

安全 actual DTO 文件 `phase29-local-contact-delivery-actual-fixture.json` 含三种真实投影：未配置 STATUS、source publish、receiver release 丢回执原 GET 恢复。各 inner delivery exact31，contact_values 均 null；artifact 不存 contact 明文。源 hash 与当前 13 个依赖对应。

## 证据边界

Node 实际调用当前 createService/createStore、成熟 sync/register/submit/withdraw 与 contact handler；事务是 SDK 接口兼容的内存 double-callback adapter，不能称真实 CloudBase SDK 引擎。官方 KMS Client.request 在边界被 opaque RAM stub 替代，不是已验证真实 KMS 加密。本机 AcquisitionContacts 使用 RAM opaque crypt 测试适配器，不是真 DPAPI。合成账号/授权映射不等于原用户账号已恢复或正式可用。

当前限制为每本人/渠道/动作仅一个首次 release intent。以后再次明确授权新的 release 需要另设计独立审计 intent；本轮不悄悄换 key。UI、真实两机通信、生产 KMS 配置/密钥/retention、真实 SDK 引擎和商业交付未验证。

原 Phase28 gateway before C68E…及原 root transport candidate 3EFC…保存于 `backups/phase29-contact-delivery-local/1`，未改旧 contacts/receiver/source。当前源精确 SHA 以本阶段 final-hashes 为准；后续独审若必要修改应另保历史，不将此候选自动作为新版本证据。
