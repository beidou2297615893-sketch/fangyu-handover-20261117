# Phase30 根归档路径检查纠正

根阶段封存脚本首次在遍历 D 的 `phase30-combined-reason-caller-actual-result-final-hashes.json` 时拒绝：清单把 `phase26_native_combined_owner_occupancy_probe.py` 写在 diagnostics/native-owner-resolver，但 `rg --files` 实际定位于阶段根目录。封存尚未写源码快照、进度文档、报告或阶段清单；没有执行产品、Native、CIM 或注销动作。

D 后续逐项只读核查还发现 `phase26_native_owned_python_probe.py` 同样被归档到错误目录。这是独立审查清单的路径映射错误，不能依靠原清单的“已核对”声明忽略失败。原冻结清单和报告保持；更正清单另存 v2，并须按全部路径逐 SHA/已有 bytes 重新核对。实际 Native 结果和源码 hash 没有因此变化，也没有重跑 Native。

所在文件夹：C:/积木软件工坊/项目/方隅公寓客户版/work/product-upgrade-20261009/audits。
