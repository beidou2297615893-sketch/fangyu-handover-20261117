# 经营对账只读云候选实施与验证

仅方隅公寓客户版本地源码与隔离合成夹具。已实现实际 createService/createStore 路由及双 SDK callback replay；未部署、未调用真实云/平台/模型/客户/订单/财务，没有扩大真实角色。使用本轮实际读取的 RevOps 阶段与证据原则，复用现有 contact_ledger/handoff ledger，不新建 CRM 或资金账。

## 范围与数据保护

新增 `work/cloud/workspace/business_reconciliation.cjs`、新专项及无 node:test 副作用的 `business-reconciliation-fixture.cjs`。修改 service 仅 require/初始化/已认证窄路由/标准 reply 包装；handoff 仅新增 server-only `readBoundItem` 复用原 itemFor 的 company、可见性、最新审计快照/chain_hash 与撤回 ledger。contact_ledger、index、AI/政策发布/本机/UI 没有在此任务中改动。

源改前备份及 SHA 在 `backups/business-reconciliation-r1/r2/r3`。R1 保存旧 service/handoff；R2 保存初版新 helper 后加旧关联历史门禁；R3 仅更正事务预算注释，行为不变。读取不修补、迁移、重算或改写旧订单/政策/交接/事件。

## 已固定请求与响应

动作 `acquisition_reconciliation_detail`；严格请求只有 `environment_id,operation,channel_id,offset,limit`。channel_id 要求已存 `hc_<64hex>`，offset 默认0，limit默认10、上限15。client owner、company、actor、customer、订单、金额、可信布尔、裸联系字段或任意引用均拒绝。

标准 `fangyu-workspace-v1` 外层 `contract/environment_id/company_id` 内，`summary.contract='business_reconciliation_v1'`、`read_only=true`、`storage_scope='company_server_ledger'`、`authenticated_actor=当前真实会话用户名`、`observed_at=服务器秒时间`。`currency=null`、`amount_unit='legacy_cents'`：旧订单未存币种，不能编造银行验证币种。

channel 返回已有编号、revision/status/customer_id/source_event_id/source_owner/current_consent_valid/eligible_for_delivery/historical_resource_receipt_recorded/receipt_evidence_independently_verified/attribution_status/source。历史独立角色接收事件不会因客户后来撤回被抹除；当前 eligible 仅 accepted 且当前数据库同意有效。接收方登录确认与证据真实性分开，`receipt_evidence_independently_verified=false`。

source 返回 evidence_status（matched/missing/conflict）、event_id、payload_hash、owner、device_id、platform、source_lead_hash/original_text_hash/author_id_hash/comment_id_hash 和恒 false 的 platform_provenance_verified。事件及当前客户必须同 source owner/device/platform/UID/comment/lead/text/customer，并核既有 event fingerprint。payload_hash 取规范存储事件六字段 `event_id/kind/occurred_at/lead/reply/sender` 及可选 intent_snapshot 的 canonical SHA256；其余 hash 是对应 raw UTF-8 字符串 SHA256。没有返回原正文、昵称、裸平台UID、评论ID、手机号、reply/sender、证据ref、审核备注或凭证。

orders 仅该渠道既有 order_links 分页，不搜索其他客户订单。每行核同 customer、反向订单索引、当前 deal 字段、最新 deal_revision 的一致性，以及关联时原 revision 同 order/customer/revision/status_at_link。旧 link 对应新版订单时明确 link_revision_changed；经过核对的当前登记金额可以显示，但原链接不自动更新。缺失/冲突时金额为 null。

每行已登记字段包括 order_no/linked_revision/current_revision/status/binding_state/link_revision_current、reported_amount/refund/net、reported_by/last_edited_by/admin_review_recorded/reviewed_by/distinct_review_actor_recorded、recorded_calculated_commission/calculation_status/calculation_policy_revision/calculation_policy_snapshot_available/calculation_policy_current。仅原 calculation_status=calculated、非负安全整数、原 policy_history 存在且费率/窗口非null，才返回历史计算值；0 保留。自审明确 false，缺审核或历史为 null。后改当前政策不会重算旧佣金，policy_current=false 可识别。

每行及整个摘要的 verified_cash_cents、verified_paid_commission_cents 恒 null，financial_receipt_verified/cooperation_policy_verified 恒 false；即使旧原始订单被夹具注入 true/金额也忽略。登记、管理员审核、来源关联、旧公式计算分别保留，均不是客户实收、独立财务核验或实际分成支付。未提供跨页汇总、业绩百分比或支付动作。

## 枚举与错误

binding_state：matched/link_revision_changed/source_missing/source_conflict/customer_conflict/order_missing/reverse_link_conflict/history_missing/history_conflict/record_invalid。订单 status：pending/confirmed/rejected/unknown。

calculation_status：pending_review/review_rejected/attribution_unconfirmed/identity_unverified/policy_unconfigured/no_confirmed_contact/outside_window/calculated/unknown。

missing_evidence 首三项固定 financial_cash_authority_not_integrated/commission_payment_authority_not_integrated/cooperation_policy_not_verified；摘要另外 source_missing 或 source_conflict；行另外其非matched binding_state；calculated 缺政策历史另外 commission_policy_history_missing。link_revision_current/distinct_review_actor_recorded/calculation_policy_current 均合法 bool|null，null 不能当作 false 或整页成功财务证明。

helper 固定错误：RECONCILIATION_INVALID_INPUT(400)、TENANT_MISMATCH(403)、AUTH_REQUIRED(401)、STORAGE_CONFLICT(409)、SOURCE_CHANGED(409)、STORAGE_UNAVAILABLE(503)。同作用域既有 HANDOFF_/CONTACT_ typed安全错误也可返回；外层environment/session验证仍有原400/401/403。unknown storage error只安全503中文提示，没有原异常/密钥。只读不假造未commit写回执。开始及结果返回前重复授权与来源版本/当前同意核对，商业到期不阻挡合法历史查看；实际失效身份/撤销映射/会话期限仍拒绝。

## 验证与失败证据

新增 12/12 实际服务+createStore 合成测试通过：

- 来源配对事件→独立资源主体ACK→原同customer订单→登记90,000/历史计算9,000；finance仍null，源记录和整库快照不写。
- 错customer金额隔离；关联时旧revision历史缺失真实RED→GREEN；原政策缺失不返回calculated。
- 历史计算0、管理员自审 false、政策更新不重算；新版订单pending与旧link区分。
- source missing/fingerprint conflict/reverse missing/current history missing or conflict/order missing/非法退款均null金额。
- 已接受后争议及客户撤回、商业到期合法只读：历史ACK留存，当前delivery=false。
- 来源/可信receiver/admin范围可读，outsider/device bearer/伪造请求拒绝；dispatch后receiver映射/disabled/session变化拒绝。
- 空订单/分页/重启/人为伪财务字段不升级证明；跨company数据与缺审计拒绝。
- SDK 15条均修订旧link+15独立原计算政策，摘要每次 callback 85 read/0 write；service dispatch另1 read/0 write；callback双replay共四次，每次<=100。上限15保留余量，页16拒绝。
- storage原异常/模拟密钥不返；证据读取期间会话到期拒旧结果，数据不写。

必要六唯一模块共64/64：new12+原52（business_reconciliation、handoff-service-integration、handoff-ledger、contact_ledger、service、isolation）。不是把新增12与64叠加成76；未重跑冻结AI全矩阵。四文件 syntax通过。

旧关联历史实际失败日志 `business-reconciliation-linked-history-red.txt`：期望history_missing，旧 helper 实际link_revision_changed；新增门禁后通过。初始 fixture 曾有两处工具适配错误（in-place state相等导致不持久；借用非本模块的全局read-before-write mock断言）；分别保留 fixture-initial-error/fixture-read-guard-error，没有算作生产RED。有效初版缺route400 RED保留 `business-reconciliation-first-red.txt`。

## 跨层夹具与冻结

`business-reconciliation-cloud-actual-fixture.json` 是实际 createService/createStore SDK replay生成的标准envelope、实际 normalized start/sent、source actor/device/company/environment及来源SHA，纯synthetic，不含login token/password。`emit-business-reconciliation-fixture.cjs` 可离线重复生成，生成器会产生新的事件UUID；最终JSON已经停止改动供D基于同一次事件建立实际Core ContactJournal/handoff验证。该跨层后续证据由D/root另报，不将各自stub通过当作已连接真实云。

最终哈希见 `business-reconciliation-final-hashes.json`。helper D89314D59E8AACD7BBCD6B72FE0FBDB15F8E1088C4623A6B5D85E0787FF609AC；handoff 16A544D72C9DB6E0597E3016C4433216D3B7824E4980FB5638A45166BC04A305；service 1D800277C4142A4FB94EE1FD7FF03B27E730DD97E9A7C0CE529A8BFF425F7E17。R3语义不变，仅注释从保守估计修正为实测85，syntax及最后生成器真实服务链通过。真实云SDK服务执行/真实角色/业务财务证据/用户内容认可均未验，本任务不部署、不打包。
