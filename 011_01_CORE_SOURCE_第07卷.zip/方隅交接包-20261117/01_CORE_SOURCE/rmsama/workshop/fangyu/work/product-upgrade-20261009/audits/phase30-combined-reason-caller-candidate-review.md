# Phase30 良性组合原因观察 caller：候选冻结

候选已准备，尚未运行 Native。两个新 caller 合成组合首次 2/2 通过（0.029s），Python AST 两份通过、PowerShell 仅语法解析 0 错误。旧 b796 实际结果仍 `blocked/classifier_not_vacant`；公开计数 0/null 不定位具体 gate，本候选不倒推旧结果。

## 范围与成熟复用

本轮实际重读当前 Phase29 权威说明、项目/工坊规则及相关冻结源码；已读取 context-mode Skill，MCP 工具未暴露，使用本地脚本筛选摘要，没有安装、hooks 或自动恢复宣称。复用已审核的 b796 parent、固定 sleep90 child、atomic Job、固定 RuntimeIdentity/CIM、冻结 adapter/resolver/classify 与 reason-only 观察器，不新增平台能力、许可算法或 launcher 系统。

只新增两份可运行候选源，均在实际项目目录：

- `C:/积木软件工坊/项目/方隅公寓客户版/work/product-upgrade-20261009/diagnostics/native-owner-resolver/phase30_combined_reason_probe.py`
  SHA `CF766DF4C6D60AFA47D7CB99380650917281D4D4C1645D2B2F2A83E3984F84F3`。
- 同目录 `phase30_run_combined_reason_once.ps1`
  SHA `2D4FE5C418835AF48752F28A0409432E41790ABBC088B60C8BDA16AF67C7C768`。

没有项目根 diagnostics 影子目录。旧 parent/wrapper/Task、7 源、867B、adapter/resolver/观察器、风险与原数据均不改；50 个去重旧源/证据/引用 hash 保持。

## 唯一 caller 改动

新 parent 复制成熟流程，`FixedSnapshotRehearsal` 类的完整 AST 与旧 parent 一致；首尾材料/current SID、唯一 child PID+原创建时间+parent、固定 runtime/argv、Job membership、唯一 RAM owner redaction、原 WMI provenance、第二页稳定与末 child 检查均保留。Python 路径由固定项目 runtime 派生，不由 HTTP/body 或 PID/family 授权。

`classify_with_reason_trace` 只调用实际 adapter 一次，将实际冻结 `CombinedReasonTrace` 放在该调用周围。返回 `(原完整 observed, 独立 diagnostics)`；前者原样存 `classification`，后者单列 `reason_trace`。观察器准备/退出/public 失败返回固定不可用诊断，不能替换分类结果、绕过门禁、启动第二页或重试；实际策略异常仍传播。诊断结果是已冻观察器的严格八字段，不保存 PID/SID/exe/argv/path/locals/异常文本/句柄，也不新增 TokenUser API 调用次数。

原非 vacant/原 counts 证据门禁保持，首 blocked 不读第二页。若分类满足原代表条件但观察器不可用，新代表额外保持 blocked/`diagnostic_trace_unavailable`；诊断不能因此放宽准入。此只是良性代表诊断成功条件，不授原 profile 空闲或账号身份。

## 本轮必要验证，未执行原生路径

新测试 `audits/test_phase30_combined_reason_caller.py` 从新 parent AST 精确抽取 caller 函数，接实际冻结 adapter/classifier/observer；没有导入或运行 Native parent。

1. 实际 adapter 首失败投影丢 fingerprint 的 outer 与单 row unknown 两类，trace on/off 的完整 observed 与读取次数相同；首失败只有一页。安全标签能分别显示 outer metadata 和 chrome executable 路径失败，不依赖公开 null 猜分支，原始身份/异常标记不外泄。
2. 真实观察器材料不可用及构造异常时，原结果/页数不变，固定不可用投影不泄异常。并核成熟 Snapshot 类 AST、原代表双页门禁、唯一 GUID/Interactive Limited/2min/无 trigger/一次 start/排他 attempt 保存等新入口静态关系。

两方法第一次均 GREEN，日志 `phase30-combined-reason-caller-first.txt`；本切片没有产品 RED，未重跑旧机制、UI、联系方式或大矩阵。Popen/subprocess/CIM、socket、SQLite、native owner API、WinDLL 在合成测试中拦截。最初生成 PS pin 清单时，显式项目 private_evaluation 路径位于 stage 外导致制作脚本 relative_to 错误；发生在 wrapper 写入前，用经项目根限制核对的固定相对路径完成生成，不是产品 RED 或原生执行失败。

## 根窗口下一步精确入口与审点

根已实际读完整新 parent/PS/两方法源码并接受窄范围，仍须根独立核冻结 SHA 与 PS 解析后决定一次执行。本代理没有 dispatch。唯一入口为上述 `phase30_run_combined_reason_once.ps1`；它只派生一次 GUID 和 `\方隅工作台\客户版Phase30组合原因观察-<GUID>`，使用固定项目 `work/desktop-python/Scripts/pythonw.exe`，动作指向新 parent `--run --run-id <GUID>`，工作目录固定本客户项目，Interactive/Limited、0 trigger、IgnoreNew、2min。复用固定 sleep90 子进程、原 atomic Job 与确认退出收束，不使用原账号/浏览器/DB/DPAPI/CLI/云/平台 URL。

结果/attempt 为：

- `work/product-upgrade-20261009/audits/phase30-native-combined-reason-<GUID>.json`
- 同目录 `phase30-native-combined-reason-attempt-<GUID>.json`

两路径存在即拒再跑，attempt/结果使用排他创建；旧结果不覆盖。PS 16 项固定来源在注册前和 start 前验证；parent 冻结来源、actual runtime capture 和本轮 source hash 首尾复核。wrapper 自身实际 SHA 也属于 root 预执行核对与 parent 本轮材料快照，不能仅凭 wrapper 自声明授予执行。Task/receipt/清理由根独立核 exact action/current SID/0 trigger/Ready/result 与拥有边界，不自动触发、重复或清其他任务。

必要独审点：实际固定 runtime/material 当前仍对应、observer 失败不替换 verdict、trace 输出严格白名单、一次 GUID/排他保存、无真实原账号操作与明确 owned 退出。两次完整 CIM 只要求选定 child 原 PID/创建时间/parent/current SID/runtime/Job 证据稳定，正常全机器无关行变化不当该 child 失败或原 profile 授权。其它未知仍 fail closed。

## 未验证与冻结

真实 Native caller、实际 Windows 启动期标签、真实 CIM/TokenUser 组合与 owned cleanup 在本轮尚未执行验证。假设未来结果 blocked，只保存实际原因与材料，不自动再试。良性代表即使通过，也不证明实际 WMI outage、原 WebView2/原账号恢复、跨机、平台采集或商用。没有全机器抓包，不能宣称 Windows 所有网络流量为 0。

本候选源/测试停止修改，待独立审核；源、日志、静态、保留证明及本报告完整 SHA 见 `phase30-combined-reason-caller-candidate-final-hashes.json`。新测试仅本候选两方法，不混入联系方式业务方法统计。
