# R15/R16 发布规则进入可信云提示词：本地源码实施证据

2026-10-10。授权范围内的云发布模块和独立本机发布状态层已完成，当前必要云八文件 **154/154**，本机新模块与原规则管理 **36/36** 通过。两组不重叠，共 190 项当前本地验证；不与此前 203 云恢复、108 网关审查或 9 项选型夹具重复相加。没有真实云发布、provider 调用、收费、真实资料上传、角色修改或旧客户数据重算。

本轮只修改云 `ai_contract.cjs`、`ai_enterprise.cjs`，新增云 policy helper/两份测试及本机 `company_intent_policy.py`/测试。`service.cjs` 现有 AI_OPERATIONS 路由直接复用，文件未变；主窗口负责旧 workflow/attempts/integrations/gateway/UI 接入。本报告不把这些待主窗口联验的跨层入口写成整项产品已验收。

## 实施行为

- `intent_policy_read`、`intent_policy_publish`、`intent_policy_publish_status` 通过真实 createService 会话，云事务重新授权当前持久用户。发布/status 仅真实 cloud admin；本机 operatorOwners 不能授予云管理权。新发布还执行服务端 strategy 权益；历史查看/原发布状态不被商业到期阻断。
- 公司当前规则存原 private state 的 enterpriseIntentPolicy；不可覆盖的版本在 fangyu_intent_policy_versions，原 actor+幂等键发布收据在 fangyu_intent_policy_publications。请求摘要、CAS、历史与收据同事务，SDK 回调重放不产生第二个版本或模型调用。不新增资金账本。
- policy 仅 name/enabled/五级 criteria/最多 200 个白名单事实。事实字段复用本机规则，日期规范 UTC 毫秒且需时区，拒绝非法日期/失真亚毫秒；数值限整数，拒绝控制字符、重复 ID、私有词库、资格排除和其他字段。服务端重算规范化 digest，客户端 source_local_* 只作为来源绑定元数据，不是授权。
- source revision/digest、publication ID/原发布 key 进入安全回执，员工只读 metadata，不读取 criteria、事实或引用正文。本机模块只从服务端规则 snapshot 取正文发送发布，不接受前台附带 policy；本机元数据记录不存正文、资料引用或密钥。
- 发布后 intent_analyze 必须携带合法原 request_id 以及匹配的 expected_policy_revision、expected_policy_digest、expected_effective_facts_digest。缺失/不匹配 failclosed；附 local_policy/身份等未授权字段也拒绝。未发布公司保留原 v14 行为，不凭普通分析 payload 创建发布。
- 实际 prompt 使用可信已发布 criteria，并将本次有效事实放在结构化用户数据中，固定 system 边界仍优先。八字段模型输出合同保持；真实外地需求不因公寓适配抹成 unrelated，资料不是本人预算/条件证据，也不是库存、同意、资源部 ACK、成交或归属证明。
- effectiveRulesVersion 加公司 policy revision/digest 和有效 facts digest，contextHash 随之改变。原恢复 inputHash 仍由稳定来源内容组成，未知跨新编号、换 policy 和换员工仍被原公司 input anchor 阻断，原资金预留不变。
- 有效事实采用 from ≤ server_now < until，未来生效起点也形成下一边界。in-flight/ready 缓存截止不超过该边界，缓存命中及调用前重新核对。provider 已执行后规则变更或过期，旧 ledger 正常结算并保留真实历史；响应 policy_revalidation_required:true，status 不把旧结果当当前可用，不自动补跑、不伪造未计费。
- 启用发布版本后，旧 ai_config_save.intent_policy 明确拒绝，防止平行标准；模型、密钥、预算配置仍走原管理接口。cloud profile 的 published_policy 是当前安全 metadata，facts_as_of 动态时间不属于稳定版本，不能用于每次 cache key 或终审相等比较。

## 冻结接口

云发布输入：

```json
{
  "operation": "intent_policy_publish",
  "environment_id": "fixture-env",
  "policy": {
    "name":"合成示例规则","enabled":true,
    "criteria": {
      "super_high":"本人明确预约看房或索取租赁联系方式。",
      "high":"本人明确求租并询问具体房源价格。",
      "medium":"本人主动了解租房但暂无具体行动。",
      "low":"本人明确以后可能租房尚未行动。",
      "very_low":"本人条件式提到未来可能租房。"
    },
    "facts":[]
  },
  "expected_policy_revision": 0,
  "idempotency_key": "fixture-publish-01",
  "source_local_revision": 7,
  "source_local_digest": "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
}
```

该 JSON 为合成协议示例，不是真实发布资料；实际环境由服务端固定。source_local_revision/digest 可选，缺省 null；company/actor/角色不接受客户端提供。云 read 只允许环境/动作，status 只加原 idempotency_key。

metadata 精确 19 字段：contract/company_intent_policy_v1、scope/company、policy_revision、policy_digest、effective_facts_digest、enabled、facts_as_of、facts_valid_until（null 或 UTC 毫秒 ISO）、usable_fact_count、incomplete_fact_count、expired_fact_count、future_fact_count、source/operator_recorded、independently_verified:false、inventory_verified:false、publication_id、publication_key、source_local_revision、source_local_digest。

read 返回 `{summary:null|metadata, can_publish:boolean, policy?:仅云admin正文}`。publish/已有 status 返回 `{state:'succeeded', mutation_committed:true, idempotency_key, publication_id, summary:metadata}`，原收据不可变。status 缺记录返回 `{state:'unknown', mutation_committed:null, read_only:true, idempotency_key}`；缺失不证明没执行，也不允许自动换键。分析成功返回 applied_policy（19 字段加 original_request_id）和 policy_revalidation_required:boolean；profile.config.published_policy 为当前 19 字段。

云 status 成功证明原发布收据存在，并不证明该版本仍是公司当前版本或资料仍有效。当前应用必须再比 read/profile 当前 revision/digest/effective facts 和本次 applied_policy，不把历史收据当当前交付授权。

本机接口：

```python
LocalCompanyIntentPolicy(core, tenant, owner, company, *,
    cloud, device_id, scope_guard)
execute(action, data, user)
snapshot(user)  # 同 read shape
safe_projection(value, *, applied=False,
    expected_source_revision=None, expected_source_digest=None,
    expected_publication_key=None, expected_publication_id=None,
    expected_original_request_id=None)
```

本机 publish 仅 `{expected_local_revision,expected_local_digest,expected_policy_revision,idempotency_key}`，仅绑定的持久 admin 且云 can_publish:true。先在同 SQLite BEGIN IMMEDIATE 内复核来源/actor/device、跨 key 未知锁，登记 opaque original key+submission nonce，再一次发送；异常后仅原 status，不自动 publish。两个独立实例不能并发重复提交。

本机状态记录位于 company_intent_policy_attempts；成功不覆盖原政策正文或旧 522。新发布前若可信云 read 已表明 revision 不符，预提交明确拒绝、零 attempt 行/零 publish 调用；read 后才变更则保原 unknown，不能凭缺云收据消除历史。

本机返回增加 local_source_matches、requires_revalidation、current_cloud_verified、cloud_current_state；所有 status 返回 read_only:true。原 succeeded 后云 status 未知/传输失败，保原成功 state/summary 与历史元数据，但 current_cloud_verified:false、cloud_current_state:'unknown'、requires_revalidation:true，并禁止原键重发/新键发布，直到原 status 恢复可信回执。正常源码更新/损坏只使来源待重验，不能抹掉已确认云成功。current_cloud_verified 核验的是原发布收据，不代表仍为当前公司规则。

## 红绿与独立审查

新云 service 七项最初在旧源码全部红：缺发布/status、员工权限、三期望值门禁及资料/缓存协议；实现后转绿。随后加入并发 CAS、服务权益到期、模型后撤权与中途新发布，最终 **11/11**。策略权益夹具起初缺既有 team 席位能力导致 setup 拒绝，修正 fixture 为真实许可组合；没有放松服务门禁。

新纯 helper 在缺模块时红，最终 **15/15**，覆盖规范化、时间边界、canonical digest、未来边界、源字段、原对象不变。

本机最初 source/身份/未知锁主链通过；独立审查再关闭三类边界：原成功被未知 status 降级、未绑定 admin 继承普通规则管理能力、已知陈旧云 revision 先记 submitted 导致无法必要恢复。另验证外部异常携 mutation_committed:false 在 dispatch 后不能继承“云未写”证明。最终新 **18/18**，原 IntentRuleManagement **18/18**。

所有 Node 证据使用实际 createService/createStore 和 SDK callback replay，本地 provider stub；所有 Python 使用本项目临时 SQLite。合成 522 与选型九项证据单独留在 cloud-policy-binding-route-review.md，不冒充原客户数据或已上线闭环。

## 验证与固定 SHA256

云必要八文件：

```powershell
node --test --test-reporter=tap work/cloud/workspace/intent_policy_service.test.cjs work/cloud/workspace/intent_policy_publication.test.cjs work/cloud/workspace/ai_enterprise.test.cjs work/cloud/workspace/product_entitlements.test.cjs work/cloud/workspace/ai_request_recovery.test.cjs work/cloud/workspace/service.test.cjs work/cloud/workspace/isolation.test.cjs work/cloud/workspace/intent-personal-contract.test.cjs
```

154/154、零失败/跳过。本机 test_company_intent_policy.py 与 test_intent_rule_management.py 实际联合 36/36。四文件 Node syntax 通过。生产编辑前原 SHA/源码备份位于 work/product-upgrade-20261009/backups/cloud-policy-binding-r1；旧云冻结报告保留为阶段历史。

| 文件（相对项目） | SHA256 |
| --- | --- |
| work/cloud/workspace/ai_contract.cjs | 45B20DBD2C14421CEDBAC7CAA3AD55394DDF561B36F55448CCEA0C8FC06A8606 |
| work/cloud/workspace/ai_enterprise.cjs | C00940ADA804759E335267EC1FEFBAAB9F7A2F9D7123ACA174EC5CEF4206EF6C |
| work/cloud/workspace/service.cjs（未变） | 76D412CBF6C659B3506563ADB0E2C9DC11EF88B3D10F57BCB173DD2BEC74DF43 |
| work/cloud/workspace/intent_policy_publication.cjs | 501A1805692C128B62FABCE1D002EA71D980D35928F14A33BE95EFADE36EC8EE |
| work/cloud/workspace/intent_policy_service.test.cjs | 8D4085A0D3A970F78838A2B828315248DC7546314DC53725666A0F562FA93DC6 |
| work/cloud/workspace/intent_policy_publication.test.cjs | B9A187BCE80BBE6E8475D506E8BB8780B7DCED232BCDBE733BC2721E942D36DC |
| work/app/src/assistant/company_intent_policy.py | 5DF83D9E15E587E73462889CEF5D13AA976B59F1B092247FD6725CFC65863C8C |
| work/app/tests/test_company_intent_policy.py | 0E869C2EDDFDAD2E711B93417F8E2B25EC07A4484330D350D1AEF60BB422AD55 |

截至本轮可读 Codex 周窗剩余 21%，secondary 不可读；未使用重置或购买。下一步是独立复核主窗口本机旧入口与 UI 的完整接线，仍只本项目、无真实云发布。
