# Phase26 良性 WebView 实际结果只读核对

本次 `04646f4eb2d84e32b6563ca1cf47c283` 已完成并安全收束，结果为 `blocked / classifier_not_vacant`。首次分类中，2 条受管且运行组件匹配的 WebView2 记录、1 条本次 Python 子进程身份/创建时间/Job 记录已核得；整体阻断来自另一条 Chrome 的基础元数据缺失。保存的 `creation_job` 阶段标签有静态误标，不能据此归因于 Job 或 OpenProcess。原账号 `8070…` 没有同级追踪证据，不能认定同因。

## 回执、源码与清理

实际结果 SHA256 为 `3C9F7EAC7FB7AF59EC2C7473A24DA09B324C603A3824406D028B8B68310F947E`。结果、初始 attempt、dispatch、Scheduler receipt、owned cleanup 的 run_id 一致；初始 attempt/dispatch 的 `execution_finished=false` 是启动记录，结果的 `true` 是完成记录，不构成冲突。Scheduler `Ready / LastTaskResult=1` 与程序在阻断时返回 1 一致；不是成功加载证明。

本轮对磁盘重新计算 4 个良性候选源、7 个冻结诊断源、复用 Python probe 共 12 个 SHA，全部与 prepared manifest 一致。实际 attempt 中父脚本 `5EE2…`、child `10DD…`、trace `C2A0…`、复用 probe `867B…` 也一致。当前 hash 核验与保存回执的 `materials_unchanged=true` 分别列证，不冒称本轮重新执行了 runtime 或 OS 核验。完整路径与 SHA 在同目录的 `phase26-benign-webview-actual-result-final-hashes.json`。

保存回执确认 `owned_job_created=true`、`owned_exit_confirmed=true`、唯一 Scheduler 任务已移除，合成 profile 保留，其他/原账号任务未改。程序在首次 `inspect` 得到 unknown 后立即进入 Job 清理，因此没有继续等待 loaded 信号、没有第二次检查：`child_status=null`、`browser_started=null` 必须保留。两条 WebView2 进程匹配证明本次启动产生了相符进程，不证明页面/window loaded、原账号 UID 核验或账号恢复。

## 唯一 uncertain 的准确解释

保存的首次快照有 54 条相关进程行；trace 计数为 resolved Chrome 11、Python 2、WebView2 33、uncertain Chrome 1，其中 owned_selected_webview2 2。计数是分类分支结果，不是全部行逐项成功率；完整且无相关参数的普通 Python 会提前跳过。

唯一 uncertain 为 `chrome / process_metadata_unavailable`，`owner_current=null`，executable/argv/profile/owned membership/runtime 派生值全为 null，trace 未截断。冻结分类器先验证 current SID，再在每条相关记录的 parent/created/owner 门禁中拒绝缺失元数据；`safe_trace._safe_row` 只有 owner 与 current SID 都有效才生成布尔 `owner_current`。据冻结源码与该投影，可以定位到 **Job 检查前的基础 owner 元数据门禁**，但没有保存原行或 GetOwnerSid 返回码，不能进一步认定具体 OS 失败原因；parent/created 是否也缺失亦未知。

准确源码锚点：

- [profile_occupancy.py:119](C:/积木软件工坊/项目/方隅公寓客户版/work/product-upgrade-20261009/diagnostics/developer-original-identity/profile_occupancy.py:119)：快照 current SID/complete 白名单。
- [profile_occupancy.py:176](C:/积木软件工坊/项目/方隅公寓客户版/work/product-upgrade-20261009/diagnostics/developer-original-identity/profile_occupancy.py:176)：parent/created/owner 元数据门禁先于 executable/argv/profile/Job；行 204 设置 uncertain，行 207 令整体 unknown。
- [safe_trace.py:72](C:/积木软件工坊/项目/方隅公寓客户版/work/product-upgrade-20261009/diagnostics/benign-webview-metadata/safe_trace.py:72)：使用 AST 文本子串 `'own'` 选择 `creation_job`；`row['owner_sid']` 也命中。此为观测标签缺陷，不改变冻结分类器判定。
- [profile_process_probe.ps1:38](C:/积木软件工坊/项目/方隅公寓客户版/work/product-upgrade-20261009/diagnostics/developer-original-identity/profile_process_probe.ps1:38)：GetOwnerSid 非零/异常保留 owner null；`complete=true` 表示枚举完成，不表示每行身份均取得。
- [owned_job.py:200](C:/积木软件工坊/项目/方隅公寓客户版/work/product-upgrade-20261009/diagnostics/developer-original-identity/owned_job.py:200)：真实 Job 检查需要 OpenProcess、原创建时间及 IsProcessInJob；其不确定代码是 `job_membership_unavailable`。本 uncertain 没有这一证据。

GetOwnerSid 非零可包括权限不足、未知失败等，当前记录未保留返回类别。进程在枚举后退出是一个候选解释，尚未被证明。[Microsoft GetOwnerSid 文档](https://learn.microsoft.com/en-us/windows/win32/cimwin32prov/getownersid-method-in-class-win32-process)

## 下一条最小代表路线

首选先批准一个独立 v2 **追踪器标签修正**，不改分类权限：用 AST 的准确 `Name` 引用判断 `own`，不按整个表达式子串。最多两组合成静态/分类代表：owner 缺失必须归 metadata；前一行 own=true 后下一行缺 owner，不得带入上行 Job 布尔。真实 unknown 仍阻断，先不重开原号或良性 WebView。此项尚未实施/测试。

若随后选择处理“已退出行使 unknown”的机制，当前 0464 回执不足以直接授权忽略该 Chrome 行。先做隔离的固定良性子进程生命周期代表：采集时取得并保留 `SYNCHRONIZE | PROCESS_QUERY_LIMITED_INFORMATION` 句柄，核 GetProcessTimes 创建时间与同一枚举行相符，owner 失败后对**同一句柄**零等待核明 signaled；不能用 family、PID、OpenProcess 失败或一次新列表中消失作为退出证明。微软分别规定 OpenProcess 失败返回 null、GetProcessTimes 提供创建时间、process 在退出后 signaled；这些支持机制设计，不是本机 0464 退出实测。[OpenProcess](https://learn.microsoft.com/en-us/windows/win32/api/processthreadsapi/nf-processthreadsapi-openprocess)、[GetProcessTimes](https://learn.microsoft.com/en-us/windows/win32/api/processthreadsapi/nf-processthreadsapi-getprocesstimes)、[进程同步对象](https://learn.microsoft.com/en-us/windows/win32/sync/synchronization-objects)

最小反例须同时包含：相同 PID 但创建时间换代；句柄未 signaled/拒绝访问/时间不可核；原行退出后出现新活跃 profile owner。三者都不能获得 vacancy。若要据确证退出行继续判断，还须最终完整新快照覆盖新进程，并保持 profile/当前 SID/runtime/Job 范围检查；句柄必须可靠关闭。WAIT_TIMEOUT 不是退出，IsProcessInJob 仅回答指定 Job 身份，不证明无其他 profile 使用者。[WaitForSingleObject](https://learn.microsoft.com/en-us/windows/win32/api/synchapi/nf-synchapi-waitforsingleobject)、[IsProcessInJob](https://learn.microsoft.com/en-us/windows/win32/api/jobapi/nf-jobapi-isprocessinjob)

## 未验边界

本轮只读取上述已保存证据与冻结源码、计算 hash、查 Microsoft 官方文档，新增本报告/manifest；没有测试、Scheduler/CIM/Native/browser 重试，没有读取原 DATA、Cookie、凭据或 DPAPI，没有 CLI、云、模型或发送。实际 probe 只配置本地 HTML/合成 profile，保存回执为原账号未用、SQLite 0 连接；这些是回执与机制证据，本轮没有独立抓包或原账号文件字节前后实测。WebView2 厂商后台网络仍可能发生，`network_requests_started=null` 不能改为 0。原号风险、当前平台登录、来源 UID、账号恢复与总目标仍未验证。
