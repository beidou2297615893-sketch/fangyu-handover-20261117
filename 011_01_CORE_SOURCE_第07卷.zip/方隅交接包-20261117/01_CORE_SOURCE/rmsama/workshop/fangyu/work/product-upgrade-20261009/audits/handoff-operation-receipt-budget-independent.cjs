/* Real service/store/repos; SDK-interface-compatible memory adapter only. */
'use strict';
const assert=require('node:assert/strict');
const {fixture}=require('../../cloud/workspace/handoff-operation-status-fixture.cjs');
const REGISTER='acquisition_channel_register',RECEIPT='acquisition_handoff_receipt';
async function measured(f,label,action,key,token){
  const before=f.data.snapshot();f.data.resetOperations();
  const response=await f.status(action,key,token);assert.equal(response.status,200);
  const callbacks=f.data.operations().map(pair=>pair.map(({reads,writes})=>({reads,writes})));
  for(const pair of callbacks)for(const {reads,writes} of pair){assert.equal(writes,0);assert.ok(reads<=100);}
  assert.equal(f.data.snapshot(),before);
  return {label,callbacks,map_unchanged:true};
}
(async()=>{
  const f=await fixture(),recorded=await f.registered('independent-budget-customer','independent-budget-register');
  const results=[await measured(f,'current-granted',REGISTER,recorded.key,f.tokens.source)];
  const submit=await f.change('acquisition_handoff_submit',recorded.item,{},f.tokens.source,'independent-budget-submit');assert.equal(submit.status,200);
  const ack=await f.change(RECEIPT,submit.data.item,{decision:'accept',evidence_reference:'evidence:'+'f'.repeat(32)},
    f.tokens.resource,'independent-budget-resource-ack');assert.equal(ack.status,200);
  const withdraw=await f.change('acquisition_handoff_withdraw',ack.data.item,{reason_code:'customer_withdrew'},
    f.tokens.source,'independent-budget-withdraw');assert.equal(withdraw.status,200);
  results.push(await measured(f,'historical-ack-current-withdrawn',RECEIPT,'independent-budget-resource-ack',f.tokens.resource));
  results.push(await measured(f,'missing-original',REGISTER,'independent-budget-never-written',f.tokens.source));
  process.stdout.write(JSON.stringify({synthetic_only:true,real_sdk_engine:false,real_cloud:false,results},null,2)+'\n');
})().catch(error=>{process.stderr.write(error.name+'\n');process.exitCode=1;});
