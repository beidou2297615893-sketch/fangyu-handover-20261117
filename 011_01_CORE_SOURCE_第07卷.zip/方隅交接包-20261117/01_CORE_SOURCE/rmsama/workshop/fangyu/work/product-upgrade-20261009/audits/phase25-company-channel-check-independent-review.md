# Phase25 本机精确公司来源核对独立审查

结论：未发现阻断项。独立新增 2 组代表首跑 2/2，3.935s；不重复 root 原 3 组、不重跑旧矩阵、不将耗时当在线性能证明。此阶段尚未正式交付资源部，也没有用户商用验收。

## 静态合同与信任边界

- `company_handoff_channel_check.py:43` 从本人有权原交接、持久 origin、原 immutable event 完整 owned 链派生身份与来源；事务内另核原 payload raw/canonical hash。当前 lead 变化不能替代已冻结来源。
- `:71` 比较当前 exact channel 的完整 source、公司、owner、event、customer 与原事件；不是按昵称或仅 UID 找相似渠道。`:105` 将历史 grant 与原 recipient/purpose/contact reference/environment/action/key 组成原 register 完整 canonical digest；当前 withdrawal/status/revision/consent 另外与原号 status 的 current 核对。历史 grant 的恢复用于验证原写入，不能解除当前撤回。
- `:141/:144/:147/:150` 每次 status/source/detail 后及最终返回前重取本人、原准备、当前授权、原事件与 attempt；attempt 必须完全不变。`_no_write` 没有登记 transport，业务文件没有持久 mutation 路径。
- `company_handoff_channel_transport.py:18/:25/:36` 复用成熟当前 session 60s/响应末时效、当前 host company/environment/user/scope fences；11 字段 envelope 严格验证再剥 3 个可信外层字段，不 login/refresh/retry。
- `product_workspace.py:197/:550` 专属 dispatcher 与最终 HTTP public fence 已包含本 action；当前 vault/company/environment/device 与 saved actor 返回前复核。未进入泛型 mutation receipt 或取消墓碑流程。

## 两组独立代表及证据

1. 实际 Core、原登记 commit 丢 echo、当前 lead UID/正文替换。当前 exact company detail 仍必须匹配不可变旧事件，结果 `hold`、当前准备不可用、`current_channel_source_matched=true` 与原 `registration_source_verified=false` 分开；不修未知 attempt。另在真实公司读取结果上分别注入同 source 但 purpose/contact_reference/consent_reference 不同，完整原 payload digest 均拒绝。原编号、origin/attempt、SQL dump 不变；公共结果无正文、裸 UID、event ID、payload hash 或云 key。
2. 实际 status 后禁用 saved actor，仅发起 status；实际 source 后撤回本机授权或改变有效 unknown attempt，仅发起 status+source。每次在下一 detail 前拒绝，mutation=false 只表示本次查询。原 attempt 仍 unknown/sourcefalse，不查询新号、不重放、不修复。测试注入写入单独标识并排除 SQL 只读计数，注入后的完整 dump 与查询结束完全相同。

直接 SQLite trace 未见业务 INSERT/UPDATE/DELETE/REPLACE/DDL；所有公司纯读 transaction callback 的 writes=0。只允许既有 registration SDK-interface worker subprocess，socket 与 platform adapter 执行被阻断，泛型 ProductOperationReceipts begin/finish/status 被阻断。所有数据均为本项目 temp 下的合成夹具，没有原 DATA/Cookie/凭据、真实网络/CLI/模型/平台/公司操作。

SDK 证据为实际 createService/createStore/repos + SDK 接口兼容内存 adapter 的手工双 callback 回放，不是 CloudBase SDK 内部事务引擎、真实云部署、真实多机并发或在线性能证明。晚变更为明确受控负例；本次没有独立实际公司 withdraw 写链测试，历史 grant/current withdrawn 分列通过静态核对，root 既有本机撤回代表另计。

## 公共解释必须保持

`current_channel_source_matched` 只确认本次读到的当前详情来源对应；不抬升旧 lost-echo 登记的 `registration_source_verified`。`company_event_payload_matched`、原 revision1/draft 自 hash 记录、当前渠道状态三者各自陈述。`source_cloud_binding_verified/platform_delivery_verified/financial_receipt_verified` 保持 false，cash/payment 为 null，`eligible_for_company_submit=false`。查询 mutation=false 不证明原登记未提交。尚未实施明确 submit、独立资源角色 ACK、保护电话/微信交付、佣金或到账证明。

## 冻结

源、独立测试和首绿日志准确 SHA 见 `phase25-company-channel-check-independent-final-hashes.json`。D 未修改 root 本机生产、transport、gateway、既有测试/DTO 或旧阶段记录。
