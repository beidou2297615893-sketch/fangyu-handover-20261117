"""Freeze only the receiver UI's owned source and current local verification evidence."""
from pathlib import Path
import hashlib
import json

project = Path('C:/积木软件工坊/项目/方隅公寓客户版')
audit = project / 'work/product-upgrade-20261009/audits'
snapshot = project / 'work/product-upgrade-20261009/backups/phase28-receiver-ui-source-freeze/1'
paths = [
    'work/app/src/web/workspace/company-handoff-receiver-ui.mjs',
    'work/app/src/web/workspace/upgrade-operations-ui.mjs',
    'work/app/src/web/workspace/app.mjs',
    'work/app/tests/company-handoff-receiver-ui.test.cjs',
]
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest().upper()
before = {}
for name, expected in [
    ('upgrade-operations-ui.mjs', 'F5E05C2006B76F58F06DD9D47FBF3234A42606A620E5F8F1A96DE234C4852A95'),
    ('app.mjs', '50DD120BA79785B9101BEF54F015A7359D5B4D23893865BD8583FC7C3E837844'),
]:
    path = project / 'work/product-upgrade-20261009/backups/phase28-ui-before' / name
    assert digest(path) == expected, name
    before[name] = expected
entries = []
for relative in paths:
    path = project / relative
    copy = snapshot / relative
    copy.parent.mkdir(parents=True, exist_ok=True)
    copy.write_bytes(path.read_bytes())
    assert digest(copy) == digest(path)
    entries.append(dict(path=relative, sha256=digest(path), snapshot_path=str(copy.relative_to(project)).replace('\\', '/')))
fixture = audit / 'phase28-company-receiver-actual-fixture.json'
assert digest(fixture) == 'CA12C843A9B2A787D741276FBDB9D90C3C37840BDE24CC89E3629A9E54755B80'
enterprise = project / 'work/app/src/web/workspace/enterprise-ui.mjs'
assert digest(enterprise) == '47833728080C10904E300104228B61BA740476090C8F61AC55726218ED05964A'
log_dir = project / 'work/product-upgrade-20261009/logs/phase28-receiver-ui'
logs = [dict(path=str(path.relative_to(project)).replace('\\', '/'), sha256=digest(path)) for path in sorted(log_dir.glob('*.log'))]
record = dict(stage='phase28_receiver_ui_candidate_frozen_for_root_review', source=entries, before=before,
    actual_fixture=dict(path=str(fixture.relative_to(project)).replace('\\', '/'), sha256=digest(fixture), synthetic_only=True, real_company_network_called=False),
    verification=dict(new_ui_tests=3, new_ui_pass=3, targeted_old_ui_tests=21, targeted_old_ui_pass=21,
        additional_workspace_tests=10, additional_workspace_pass=9, additional_workspace_fail=1,
        syntax_exit_code=0, gui_verified=False, deployed=False),
    preexisting_static_test_drift=dict(test='workspace-refinement-ui.test.cjs:108', unchanged_enterprise_sha256=digest(enterprise),
        cause='Existing openTaskComments between loadWorklist and openPending is absent from the old regular expression.',
        baseline='phase27-final-loaded-source-snapshot.json and phase27-final-evidence-source-snapshot.json'), logs=logs)
(audit / 'phase28-receiver-ui-source-freeze.json').write_text(json.dumps(record, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
lines = [
    '# Phase28 公司收件箱 UI 接线（候选冻结，待主任务预览）', '',
    '仅修改本项目的既有功能接线，不采用待选择的三张视觉候选。入口追加在“资源部交接”的既有操作区，沿用现有表单、列表与按钮样式，无 CSS 改动。未打开公司收件箱时不调用四个接收动作。', '',
    '首开 company_handoff_received_list 不含 recipient_id，只读本人当前获权的部门选项；明确选择后才读列表。列表 can_receipt 不产生接收按钮；必须读取详情并通过 eligible_for_receipt 才展示表单，默认未勾选。五类决定均需实际 evidence/document:32hex，拒绝原因受限定，其余原因与决定同名；任何决定/原因/证据变化会取消勾选。', '',
    'company_handoff_receipt 直接走当前 execute，不用 generic write/recover、随机 key 或本机 handoff_receipt。前端设置一次提交门槛；未知结果只进入同 channel 的 company_handoff_receipt_get。已有 attempt 只读，保留同 key/版本/决定连续性；缺回执不推断未执行。明确写前拒绝才允许重新读取当前详情，仍不会自动重派。', '',
    'exact36/16/7/6 checker 拒绝额外私有字段、伪造零收入/证据独验/完整历史链证明、错渠道/部门/actor hash、矛盾状态和原操作版本/决定。UI 把当前同意、当前公司状态、历史接收、证据尚未独验、客户实收/分成未知分别显示。平台引用不等于跨电脑电话或微信交付。', '',
    '请求首尾及提交前核对 principal、company、environment、device、deviceGeneration、dialog generation 和请求 epoch；迟到结果不回填。关闭、重开、reset/dispose 清除表单、勾选、已展示内容和当前 DTO；跳回列表/重新加载前也清除输入。权限仍由后端现时检查，来源人员没有接收权限时不显示确认按钮。', '',
    '## 本地验证', '',
    '- 新 UI 必要 3 组全部通过：真实 8-case DTO 和伪状态拒绝；未勾选/缺证据零 ACK、丢回执仅原 GET 无第二 ACK；principal/company/env/device/gen 迟到读、close/reset/dispose 迟到写、重开窗口及表单清除。',
    '- 旧 shared receipt、company policy、business reconciliation 定向 21/21 通过；三个 UI 源文件 node --check 返回 0。',
    '- 追加 workspace-refinement 10 项中 9 通过，1 项既存 static regex 漂移失败：其 :108 断言仍期待 loadWorklist,openPending 连续，Phase27 原 enterprise 已插入 openTaskComments。当前 enterprise SHA 与 Phase27 两份源冻结完全相同，本切片未修改该文件或旧断言。故全部运行合计 33/34，通过声明不包括该失败。', '',
    '真实 fixture 来自 B 实际项目两隔离 Core + actual service/createStore 的 SDK 接口内存 adapter；synthetic_only=true，未调用真实公司网络、平台或云引擎。它不是实际第二实体机、真实部署或运营验收。GUI 尚待 root 自有隔离 preview 核验，本报告不声称已验收或打包。', '',
    '## 冻结文件与 SHA256', '',
]
for row in entries:
    lines += [f"- `{row['path']}`：`{row['sha256']}`"]
lines += ['', f'actual fixture：`{digest(fixture)}`。',
    '修改前备份：`work/product-upgrade-20261009/backups/phase28-ui-before`；分别已核对 F5E05… / 50DD… Phase27 基线。',
    '候选源副本：`work/product-upgrade-20261009/backups/phase28-receiver-ui-source-freeze/1`；完整 manifest：`audits/phase28-receiver-ui-source-freeze.json`。',
    '测试日志文件夹：`work/product-upgrade-20261009/logs/phase28-receiver-ui`。', '']
(audit / 'phase28-receiver-ui-review.md').write_text('\n'.join(lines), encoding='utf-8')
print(json.dumps(dict(source=entries, report=str(audit / 'phase28-receiver-ui-review.md'), manifest=str(audit / 'phase28-receiver-ui-source-freeze.json')), ensure_ascii=False, indent=2))
