# Phase23 归档证据交叉核对

结论：未发现需要纠正的实质不一致。仅只读核对现有报告、日志、合成 GUI 回执、源码与候选哈希，并查看三张已生成截图；没有重跑测试、GUI、原账号诊断或外部请求。只新增本报告，未修改生产、旧证据、五份进度文档或总清单。

总清单 `phase23-company-registration-current-phase.json` SHA256：`9CABFBBCA50322DD6A176A553D24F22C9C309168FDB2902766177904D619704F`。其 17 项 evidence、6 项 sources、3 张截图及 1 份用户报告，共 27 条文件哈希均与磁盘匹配。B / D 最终清单、C 历史 artifact、最终前端 source/test 清单的嵌套引用也匹配；未以总清单自身的声明代替逐文件哈希。

## 当前与历史版本

- B 最终 4/4，8.414 秒；D 最终独 3/3，5.179 秒；root gateway 3/3，0.680 秒。新增后端共 10 个唯一方法；不将子场景、重复绿色执行、6 个 DTO case 或旧阶段 511 累计进去。B 报告 `68F79563…` / 清单 `B272EB80…` 已正确更新 D 最终时长。
- C 独 4 首绿 122.9327ms 对应 ops `139374E9…`，其原报告与哈希保持历史。root 后来只改 prepared 提示块，旧源码专属备份 SHA 仍为 `139374E9…`，C copy-review 接受当前 `4A0CE6A8…`。当前前端日志是 28 文件 / 280 tests / 280 pass / 0 fail / 2789.4003ms；当前清单 31 个 source/test 哈希全部匹配。初次 280 与最终复验不是两份新增覆盖。
- 当前 6 项源码为登记 helper `55E89EAC…`、transport `49E85A4B…`、gateway `AD43664A…`、ops `4A0CE6A8…`、app `F47F89CA…`、service `4C703669…`。B actual DTO `BDEAC6F0…` 的 11 项来源、B 独占清单 9 项与 D 独占清单 20 项均匹配。
- 最新 UI 冻结清单 `ui-final-source-hashes.json` 为 `C7BFBFD6…`，其 16 项与当前源码、最终 loaded 16 项完全一致；9 项启动 Python 与当前文件一致。`source-freeze-history/phase-23.json` 与 `phase-24.json` 是改变前的历史存档，后者 ops 为 `139374E9…`，不能当成当前 `4A0CE6A8…` 的来源。历史 23/候选备份25保留，最新历史编号24/候选备份26不表示历史文件被改写。
- 未发布静态候选 143 项 source/candidate 全部一致，备份26的 143 项逐项符合 before_sha256；19 项二进制资源实际哈希符合静态验证记录。5 种未知路径拒绝是已存静态验证结果，本核查未重新请求服务。
- docsbackup21 五文件均存在；当前五份进度文档的本阶段同一时间戳头部各只出现一次。用户报告 `B14B2298…` 与总清单一致。

## 实屏与合成动作

最终 GUI 的独立 data-2 metadata 与 loaded 记录均为 PID20820 / port55634；v2 harness `21049506…` 与纠正记录一致。v1 缺 tenant 属于 root 合成夹具错误，有历史保留，不是产品失败或另一次真实登记。没有从原 DATA 读取来验证上述结论。

六条已存动作是 2 次准备 GET、3 次登记 GET、1 次 REGISTER。唯一 REGISTER 的本机 dump 改变，符合持久 attempt 保存；它之后实际隔离公司 SDK adapter 的 register_calls=1 / channels=1，回执丢失错误 mutation_committed=null。其余 5 个 GET 的各自 database_before_sha256 / after_sha256 相等，database_unchanged=true。最后两次原号读取保持 `state=recorded / attempt.state=unknown / registration_source_verified=false`，原 register revision=1 / draft，can_register=false、eligible_for_company_submit=false；刷新重开没有第二次登记。这些是已存合成 GUI 动作回执的独立核对，不冒充本次重新启动 GUI 或原库字节前后验证。

三张截图 SHA 与总清单、GUI proof 均一致，实际图面也符合阶段记录：未确认图显示未勾选，丢回执图保留“结果待核对、原号核对、不再次提交”，最终找回图显示“原编号已有公司草稿记录，登记来源证据仍待核对”。第二张的 prepared 区仍是修改前“本次准备没有向公司发送”历史提示；第三张已改为“保存准备这一步没有向公司发送，公司登记结果以本页草稿核对记录为准”。历史截图不得据此宣称原公司登记没有执行，也不替换最终 screenshot。

## 保持未验的边界

实际 Core / gateway / transport / company service/store 使用项目隔离合成资料和 SDK 接口兼容内存 callback adapter。不是 SDK 内部事务引擎、真实公司部署或真实网络登记。原 register 历史自哈希与精确 origin 匹配不等于全历史链、平台权威来源、资源部独立接收、跨机交付、成交归属或现金到账。GET 本次 mutation=false 不能解除过去 unknown，当前来源 false 不被补为 true，所有 eligible_for_company_submit=false；受保护电话/微信未交付。

总清单和用户报告均保留 overall_goal_complete=false、company_submit_enabled=false、real_cloud/real_platform/resource_receipt/cross_machine=false、original_data_accessed=false、formal_app_or_service_booted=false、ui_user_approved=false、packaged=false、deployed=false。手机正常与电脑保存状态需登录是两件事，本阶段没有读取或清理 Cookie 来改变原账号结论；用户已撤销自设5%暂停，归档记录仍为 automation ACTIVE。阶段技术验收不当作原图视觉认可或完整商用完成。

文件：C:/积木软件工坊/项目/方隅公寓客户版/work/product-upgrade-20261009/audits/phase23-evidence-crosscheck.md

文件夹：C:/积木软件工坊/项目/方隅公寓客户版/work/product-upgrade-20261009/audits
