# Phase26 良性隐藏 WebView2 元数据代表：冻结候选

状态：已准备并冻结，3 Python AST/内存 compile、1 PowerShell ParseFile 通过；未 import/run 新候选、未 Scheduler/CIM/browser/原 DATA/DPAPI/CLI/network 执行。0 新单元测试，不重复旧机制/前端矩阵。root 先审核下面最终源，随后才可单次 Native；审核/dispatch 后不得继续改源。

## 成熟路线与实际限制

当前已安装 pywebview 的 util.is_local_url 会把字面 about:blank 当本地路径，__init__.start 可能起 global server 并重写 real_url。采用已允许的固定 inline HTML：create_window(html=固定文本/CSP, hidden=True)，original_url=None；start(gui=edgechromium, private_mode=False, storage_path=唯一 synthetic profile, http_server=False)，实际 edgechromium 走 NavigateToString。HTML 没有任何平台 URL、链接、脚本、iframe 或外部资源；CSP 禁止资源、connect、frame、form、base。无 js_api、HTTP server、账号或平台接口。

winforms 的 hidden 路径先 Opacity=0 Show 后 Hide 再恢复 Opacity，符合该当前包的隐藏启动机制；不声称底层窗口从未创建。该路线尚未被本轮实际 Native 验证。WebView2/微软背景网络可能发生，启动后 network_requests_started 为 null / runtime_background_network_possible=true；“没有配置或请求平台页面/API”不能偷换成全部网络零请求。

复用当前 RuntimeIdentity.capture/environment 的 concrete WebView2 文件夹、native EXE/DLL 和 35 项材料，另将实际 pywebview __init__/util/window/winforms/edgechromium 及 4 个新/复用 Python 源按内容 hash 首尾绑定。只本机材料核查，不做运行许可批准。现 atomic WindowsOwnedJobProcess 创建本次独立 child/job，setup pending 保持拥有对象；不会构造旧 Core/Service/Runner 或原账号 bootstrap。

## 唯一小样与结果

新 Scheduler 固定项目 pythonw、当前 Interactive/Limited、零 trigger、IgnoreNew、2 分钟、一次 Start、唯一 GUID。不接 caller profile/account/URL/runtime。attempt/result 用 x 模式，已有原号拒绝覆盖；fixed tmp `<GUID>/synthetic-profile` 经成熟 _checked_path 拒 reparse，无原账号/原 profile。WebView 可能写合成 profile，留在该项目 tmp，不递归删除原/其他目录。

最多 2 次实际 CIM：resume 后首轮、hidden inline HTML loaded 后一轮。任一次原 classifier unknown/occupied 立即保持 blocked 并收束 owned Job；不会为了继续观测豁免或改状态。通过须 child loaded + renderer edgechromium、两轮真实 classifier vacant、trace 可用、loaded 后至少 1 个 actual owned WebView2 row 与 selected runtime 对应、原材料未变及 owned exit 确认。仅 Python 行通过不算该代表通过。

真实原账号 8070... 的 profile unknown 仍保留，935775... 良性 Python 通过仅是另一证据；本候选无原账号恢复/获客/许可/交付/收费或商业验收声明。

## 安全原因追踪

safe_trace.py 仅接受冻结 v3 classifier SHA FF750...，由 AST 定位逐 row 开始、真 uncertain catch、最终 private.append 和最外 probe unknown 行。当前线程 sys.settrace 临时观察，finally 恢复，无 classifier/Job 方法 monkeypatch，无输出状态篡改。遇 observer 自身错误只 trace_available=false，不改变原 unknown。

每 row 重置 assigned/pending context。assignment 只有未异常且完成后才进入 assigned；因此上一行 own/executable/argv 不会投影到下一行失败。只输出固定 family/stage/code、当前 owner/known Pythonw/base/argv/profile/runtime/Job 的 bool/null、固定 counts。只有真正进入 uncertain 时采集异常，正常内部 profile_argument_missing 控制流不单独当失败。最多 20 条安全原因；raw PID/parent PID/path/argv/SID/UID/token/异常文本均不保存。

trace 有额外时序成本；它能定位该次观察边界，不能证明无竞态/在线吞吐。当前只 AST/源码静核，尚未运行 trace 小样；Native 若 blocked 应先读固定原因，不盲改 alias/profile/创建时间或再打开原小红书。

## 最终源与交审

- `phase26_native_benign_webview_probe.py`：5EE2BEC0A4B93817E516233134D8A9FF595FD5B972FC7887824FA4B1234BD609。
- `diagnostics/benign-webview-metadata/child.py`：10DDC8C710DAFC806C8F72E3903A01D09CBF85E7067DA3F2009FE02305D5FCF4。
- `diagnostics/benign-webview-metadata/safe_trace.py`：C2A047D90012BF236AE20898F957CDF3BF844367F4DDAA9505FBA66AE3B9489F。
- `phase26_run_native_benign_webview_once.ps1`：F3AD09E02E41EB9AC6D5F08B3F4F5C70DCCBA23898B621A4A60579E16FFDA3A8。

现 host 七源 7/7 与 v3 manifest 一致、复用的 Python probe 867B 一致。首 AST 候选 0C0C... 后补实际 pywebview 包 hash 绑定/严格 signal 后形成最终 5EE2...；两者都是尚未执行的源码阶段，不拿首 AST 当最终源证明。最终 AST/PSparse 与 final manifest 精确绑定上列 SHA。等待 root 审核，D 不执行 Native。
