'use strict';
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const project=path.resolve(__dirname,'../../..');
const file=value=>path.join(project,value);
const read=value=>JSON.parse(fs.readFileSync(file(value),'utf8').replace(/^\uFEFF/,''));
const sha=value=>crypto.createHash('sha256').update(fs.readFileSync(file(value))).digest('hex').toUpperCase();
const previous=read('work/product-upgrade-20261009/backups/phase30-kms-config/1/package-lock.json');
const current=read('work/cloud/workspace/package-lock.json');
const oldPackages=Object.keys(previous.packages).filter(key=>key!=='');
const changed=oldPackages.filter(key=>JSON.stringify(previous.packages[key])!==JSON.stringify(current.packages[key]));
if(changed.length)throw Error('Existing dependency lock changed: '+changed.join(','));
const newPackages=Object.keys(current.packages).filter(key=>!Object.hasOwn(previous.packages,key));
const checks=['package.json','LICENSE','tencentcloud/services/kms/v20190118/kms_client.js'].map(name=>{
 const installed='work/cloud/workspace/node_modules/tencentcloud-sdk-nodejs-kms/'+name;
 const isolated='work/product-upgrade-20261009/phase29-kms-runtime/node_modules/tencentcloud-sdk-nodejs-kms/'+name;
 const installed_sha256=sha(installed),previously_reviewed_sha256=sha(isolated);
 if(installed_sha256!==previously_reviewed_sha256)throw Error('Official KMS artifact mismatch');
 return {path:installed,sha256:installed_sha256,previously_reviewed_sha256};
});
const kms=current.packages['node_modules/tencentcloud-sdk-nodejs-kms'];
if(kms.version!=='4.1.302'||kms.integrity!=='sha512-zq44TX7uq1ADkAF80e1kKmKdlEf3OsKd2ogj1B9/IbgBymfAoax96e0qzP521SVVnJ+g5aUHlMUe07vTUtHahQ==')throw Error('Pinned KMS package integrity changed');
if(current.packages['node_modules/@cloudbase/node-sdk'].version!=='3.18.3')throw Error('CloudBase version changed');
const sdkPackage=read('work/cloud/workspace/node_modules/tencentcloud-sdk-nodejs-kms/package.json');
const sdkCommon=read('work/cloud/workspace/node_modules/tencentcloud-sdk-nodejs-common/package.json');
const result={contract:'phase30_kms_dependency_verification_v1',network_install_only:true,ignore_scripts:true,no_audit:true,no_fund:true,
 existing_dependency_entries:oldPackages.length,existing_entries_unchanged:true,added_lock_entries:newPackages,
 cloudbase_version:'3.18.3',kms_version:kms.version,kms_integrity:kms.integrity,kms_license:sdkPackage.license,
 sdk_common_version:sdkCommon.version,official_artifacts:checks,
 no_global_install:true,no_deployment:true,no_live_kms_call:true,known_install_warning:'uuid@9.0.1 deprecated; no automatic dependency upgrade'};
fs.writeFileSync(file('work/product-upgrade-20261009/audits/phase30-kms-dependency-verification.json'),JSON.stringify(result,null,2)+'\n');
process.stdout.write(JSON.stringify({existing_entries_unchanged:true,added_lock_entries:newPackages.length,
 cloudbase_version:result.cloudbase_version,kms_version:result.kms_version,sdk_common_version:result.sdk_common_version,kms_license:result.kms_license})+'\n');
