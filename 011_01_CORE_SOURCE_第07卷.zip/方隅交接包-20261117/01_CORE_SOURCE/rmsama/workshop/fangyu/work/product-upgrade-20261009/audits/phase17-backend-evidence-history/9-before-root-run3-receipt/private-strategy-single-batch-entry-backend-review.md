# Phase17 私有原快照单批入口：独立后端代表审查

本报告只冻结本代理的后端代表、实际本机 DTO 样例与隔离 GUI 候选；不代替主窗口的前端、GUI、全项目或真实平台验收。最终五个唯一测试方法全部通过，夹具测试耗时 4.439 秒不是平台吞吐或运行性能证明。生产改动由 root 实施；本代理只编辑新增测试、样例、候选预览脚本和本报告，没有改生产或旧测试，也没有触碰真实账号、Cookie、现存业务数据库、网络、CLI、企业云、收费模型、支付或对外发送。

实际使用 RevOps 的阶段定义与成熟流程连接规则：本阶段让已有私有策略快照走已有 BusinessExecutor → Core → pipeline 单批执行，避免另建任务和重复的只读层。Phase16 的394/255是历史基线，不能用于宣称这个新入口已验。

## 最终必要代表

五个唯一方法；同组子例和重复执行不叠加测试数。

1. 原 task ID 明确 `task_run{task_id,max_batches:1}`，实际保存一条合成评论；只有一条 task，没有新 task_save/save、continuous_start/resume、副本；原 strategy_source 与关键词不变，公共投影不露私词。两词快照仍未耗尽，一批不冒充完成整个快照。
2. 原资格检查后，账号活动出现 HTTP461：适配器隔离 seam 保留成熟 require_account_safe，零成功合成平台读取，保留原 task/lease，不自动释放或另建。
3. 原 guard 后 account_claim 间隙改变关键词、lease、管理资格、enabled、expiry、持久员工状态或执行账号，必须阻止读取；其中换账号使用另一合法同本人 ready 账号，保证不是无效 ID 自然报错。此方法另覆盖真实首次验证分支的隔离 callback 完成后 lease 过期，后续 search/comments 都不调用；直接 Core run_task/run_task_sequence 无可信 Python callback，且请求正文伪装 execution_guard:true，两条公共绕过路径均拒，原 task仍ready、零读取。
4. 已完成一个合成 search 后撤回当前 operatorOwners：已完成的搜索保留为历史，下一条 comments 请求被拒，零合成客户写入。
5. 实际执行完成后的响应交付丢失模拟：只读取原 strategy_task_get/workspace_state，仍同一 task、读取次数不增加。此测试没有再次发送 task_run。

第五项不是 BusinessExecutor 的 request-key 幂等证明；执行器没有承担运输恢复接口职责。前台的原 requestId/commandId 保留、未取到 commandId 的未知锁与重启保护由 root/C 独立审查，不以本测试字典键替代真实客户端逻辑。尚未取得 commandId 时成熟客户端没有 requestId 反查能力，应保持未知，不称已恢复、自动换号或重发。

## 首轮真实缺陷与关闭证据

旧 Business 初始 guard 之后的 claim/首次验证间隙允许状态改变；随后 Core 用新 task 执行，但没有再次核私有快照或管理资格。实际反例中，关键词被改为与 snapshot_hash 不符的值、lease ID变更、operatorOwners撤回、策略disabled、lease过期，仍进入隔离 search/comments。持久员工disabled早已被成熟 Core拒绝，不能列为新缺陷。额外实际反例在 search 返回后撤回管理资格，旧 pipeline仍继续 comments。

原4方法阶段完整 RED `private-single-batch-entry-complete-red.txt` 保留五个 claim-gap 子例失败；随后5方法阶段 `private-single-batch-entry-between-requests-red.txt` 保留这五例及请求间撤权失败。首轮输出编码工具错误另保留于 first.txt，后续 UTF-8 readable日志完整，不计产品缺陷。源历史 SHA `private-single-batch-entry-red-hashes.json` 不冒充最终版本。

Root 窄修复在 claim与首次验证后重新读取可信 task/当前公司资格，冻结原任务 id/account/platform/scope/关键词/continuous/source 绑定，允许合法checkpoint/counter变化；StrategyTasks重新核enabled、revision、有限expiry；Core私有任务必须提供可信函数参数；pipeline在每次 search/comments/subcomments 前调用该函数。函数重建 StrategyTasks取得最新 server.company，避免旧服务对象深拷贝公司配置后失去撤权作用。原五例与请求间撤权实测关闭；绑定账号、首次验证后失效和直接Core拒绝为同风险分组必要补强，没有扩大为无关矩阵。

最终日志 `private-single-batch-entry-final-green.txt`：5/5。完整生产、测试和证据 SHA 见 `private-strategy-single-batch-entry-backend-final-hashes.json`。旧测试正例曾只在 Core调用前 guard一次，与新的必须可信callback契约不兼容；已明确交给root调整夹具，不降低生产门禁，本代理没有修改旧测试。

## 实屏发现后的真实计数补强

Root第三次实际GUI发现，未运行的原task由Core保存时没有accumulated，旧project_task因此不公开该字段；实际collection-progress.start要求运行前完整数量，产生TypeError。之前的后端与轻量前端替身只验证执行桥，没有执行该真实progress要求，不能用旧绿断言实屏已过。旧4D60888A样例、SHA/report/日志在phase17-backend-evidence-history/6-before-count-projection保留，本报告不改写旧证据。

Root只修成熟StrategyTasks.project_task，在锁内读取当前有权原task，并从本人tenant的真实存储leads按task_id计数公开accumulated，和Core._run_inner计数口径一致，不写缺省零到原task。本代理在原5方法的正例加入实际SQLite trace与整库dump比对：初始空存储为0；另存两条该task本人tenant线索、同task其它tenant线索以及本tenant其它task线索，只公开2，读0DML且dump不变；随后运行一批新增合成评论，当前原task公开3。没有mock查询结果或新增测试方法。

最终实际JSON另保留空库→单批的0/1样例：original_task_get.task.accumulated=0、post_task_get.task.accumulated=1，task_projection_evidence.before_run/after_run明确各次SQL0DML/dump不变及完整持久计数。这个证据是纯读投影，不把整个执行过程说成0SQL写。C已收到新JSON，用真正progress.start接入原6组前台代表复验；root第二个独立样例已核对1dispatch/1result、同原request/task、1batch/1import，但其Python来源DAEE是末授权复核前的历史版本，不冒充最终来源验收；该次GUI另发现进度区不可见，root修前台后使用固定新run3另验。

D独立只读probe补证：计数连接返回后员工被停用或原task账号/版本变化，旧投影仍可能返回旧DTO。经root授权D只窄修StrategyTasks.project_task，在现有锁内关闭计数连接后复用_task核当前权限，并比内部原task完整hash；变化即拒。本代理没有重抄D反例或扩大矩阵，只在D最终C7AFF5AA455ABAA942F9E15C2D530AAFBA2DC7F92C9A860D550A11DD62393CD8上复跑原5方法5/5，并重新生成实际0/1、0DML/dump不变及采集前后源SHA一致的样例。D自身RED/绿probe是另份独立证据，不能计入我的5方法。DAEE/93695AA1阶段的本报告、样例、manifest和日志另保留history/7-before-final-projection-fence。

## 实际本机协议样例

`private-strategy-single-batch-entry-actual-fixture.json` 由新增 emit脚本使用实际 Core、BusinessExecutor、成熟 StrategyTasks 与隔离搜索/评论 seam生成：original_task_get、同一task的preflight、精确run_request、Business结果、post_task_get和workspace_state。task1、search1、comments1、import1；私词没有进入JSON；快照finished=false。样例SHA为AB847034968609BFEF221E3963EEBC38B3437EDAC85DBAE3A400B9F430FDF2A5。

源metadata采集前后相同。该JSON是实际本机链路加合成适配器，不是实际小红书请求、CLI可用性、模型意向准确率、客户同意、资源部接收、现金业绩或用户认可。明确 real_platform_allowance_verified、response_key_recovery_verified_here、commercial_outcome_verified_here=false。执行测试必要数据库/活动写入都只发生于项目内新临时夹具，不能说本阶段运行测试0SQL写。

## 隔离 GUI 候选与边界

新增 private_single_batch_native_preview.py 只通过AST提取旧native_preview.py的Handler类复用，不执行其imports/global bootstrap/数据库/server代码。语法、import和Handler-only复用检查通过，独立DATA未创建、旧native SQLite字节不变、未启动HTTP/native；本代理未执行GUI。

Root可显式启动候选：默认run-id1使用 private-single-batch-native-data，固定原成熟120秒lease，不延长、自动重建或另建快照；目录已有则拒绝重建。只开放必要纯读产品动作与原ID/max1 task_run，拒task_save/持续/账号登录/真实发送/云调用，终身阻止socket.connect和Popen。明确合成QA设备和页面banner，只让隔离样例入口可达，不扩大任何真实账号权限；公开发送及持续运行仍保持暂停。

第一次样例目录已由root启动，120秒原租约到期，未延长或重建。候选新增严格choices仅1/2/3的--run-id；2固定使用private-single-batch-native-data2以及state/loaded-source/command-receipts/preview日志名字带2，主体environment/owner/device2也独立，避免原浏览器pending槽被新样例覆盖或冒作原未知恢复。任意路径和run-id4均拒。新run2目录未由本代理创建，候选syntax/import/Handler-only核验期间first与legacy SQLite字节不变。root完成run2已保存其账本/截图；最终显式--run-id3固定data/state/asset/command/log名字带3、environment/owner/device3独立，在验证期间first/run2 SQLite和receipts字节保持相同，run3目录未由本代理创建或启动。新固定3支持没有重启原1/2、替换其回执或延长其lease。新样例只有自己从成熟创建流程获得的原120秒lease，不将新样例称旧任务继续运行。

专属statefile记录Business/Strategy/Core/Pipeline/Preflight/Product启动SHA；所有实际asset GET入专属loaded-source日志。专属synthetic command receipts仅保存原request/task/max1、阶段/状态/batches/imported/duplicate-key-return，区分dispatch-started、实际结果、未知及同key读回，不保存私词/正文/凭据/目录。命令去重仅当前预览进程内存，JSONL是合成证据而非生产broker；未知保留原号，不能宣称跨进程命令恢复。此候选的真实启动与GUI由root独立验收，不能用本报告的compile成功当GUI成功。

用户2026-10-10明确撤销自设5%停止规则，本阶段继续授权取代旧暂停门槛；不购买、不重置额度，不改其他任务。最新图片创作动漫审美规则不适用于当前已认可工作台UI，未重新生图或改视觉路线。
