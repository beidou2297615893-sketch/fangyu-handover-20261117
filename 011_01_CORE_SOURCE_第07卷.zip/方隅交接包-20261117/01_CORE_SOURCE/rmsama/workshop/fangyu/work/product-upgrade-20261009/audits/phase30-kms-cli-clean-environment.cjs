'use strict';
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const crypto=require('node:crypto');
const {execFileSync}=require('node:child_process');
const script=path.resolve(__dirname,'../../cloud/workspace/contact_delivery_config.cjs');
const sourceHash=()=>crypto.createHash('sha256').update(fs.readFileSync(script)).digest('hex').toUpperCase();
const before=sourceHash();
// Empty child environment: do not inspect or report the host's actual credentials.
const raw=execFileSync(process.execPath,[script],{env:{},windowsHide:true,timeout:5000,encoding:'utf8'});
const value=JSON.parse(raw);
assert.equal(value.contract,'company_contact_kms_configuration_v1');
assert.equal(value.state,'not_configured');
assert.equal(value.provider_configured,false);
assert.equal(value.network_requested,false);
assert.equal(value.live_kms_verified,false);
assert.equal(value.iam_permissions_verified,false);
assert.equal(sourceHash(),before);
const evidence={actual_cli_invocations:1,child_environment:'empty_synthetic_environment',
 host_configuration_inspected:false,current_source_sha256:before,source_unchanged:true,
 deployment_performed:false,reported_configuration:value};
fs.writeFileSync(path.join(__dirname,'phase30-kms-cli-clean-environment.json'),JSON.stringify(evidence,null,2)+'\n',{flag:'wx'});
process.stdout.write(JSON.stringify(evidence)+'\n');
