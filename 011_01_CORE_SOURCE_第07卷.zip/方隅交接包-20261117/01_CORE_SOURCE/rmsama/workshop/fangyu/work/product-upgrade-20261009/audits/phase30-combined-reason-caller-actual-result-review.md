# Phase30 一次良性组合原因观察：实际结果独立核对

核对对象仅为 GUID `6d34dbbf0a02437385c270507474612f`。结论：本次实际观察仍是 **blocked / classifier_not_vacant**；新增安全标签将本次的一条 Python 不确定行定位到 **executable / executable_binding_unavailable**。没有修改门禁，没有重跑 Native，也没有证明原账号或原 profile 恢复。

## 实际事实及其限度

实际结果 `phase30-native-combined-reason-6d34dbbf0a02437385c270507474612f.json` 为 finished=true，classification 为 unknown / process_metadata_unavailable。reason_trace.available=true；唯一 uncertainty 为 family=python、stage=executable、code=executable_binding_unavailable、owner_current=true、known_pythonw_route=false。executable_resolves_fixed_base、argv0_matches、profile_matches、owned_membership、selected_webview_runtime_matches 均为 null。

首完整 CIM 快照报告 54 行、other_owner_missing_rows=0；自有 sleeping child 的原 WMI current owner、Job membership、固定 runtime/argv 核对为 true，并仅对该 child 在 RAM 内刻意清空一个 owner 字段，WMI provenance 保留。此为缺字段演练，不是实际 WMI outage。首分类未通过，末快照/child 稳定性结果仍为 null，不能称两次快照或完整 adapter 路线通过。

trace 的 resolved/chrome=12、resolved/python=2、resolved/webview2=31 是固定跟踪分支的计数；不把这些数字当作全部 54 行的完整分类，也不当 API 调用次数。公开 fingerprint=null 与 token_user_rows_verified=0 是投影/收束证据，不能推断底层 resolver 是否调用。此前 b796 的 0/null 定位误推已纠正并保留历史；本次的新标签也不能倒推 b796 或 8070 的同一原因。

本次 owned_job_created、owned_exit_confirmed、current_sid_unchanged、materials_unchanged 为 true。原 DATA、DPAPI、SQLite 连接、原账号、browser、CLI、cloud/provider/platform 调用均没有发生于该良性代表的声明范围；没有抓包，不将 application_network_calls_requested=false 泛称全机器网络零流量。此结果不授权原 profile vacancy 或真实账号观察。

## 精确源码解释

冻结 `diagnostics/developer-original-identity/profile_occupancy.py:40–57` 的 TrustedCurrentPython._capture/executable，仅从本项目 fixed_interpreter 的 shim、alias、base、cfg 构造固定 routes；owner 必须等于 current SID。classify 的 executable_for（约 135–141 行）先走成熟 canonical_path，失败后仅 Python 使用该精确固定映射；expected 不存在或 canonical base 不一致会抛 executable_binding_unavailable。在这一行失败时，后续 argv、profile、Job 核验还没有形成公共结论。

冻结 `diagnostics/benign-webview-metadata/safe_trace_v2.py:113–118` 的 known_pythonw_route 是本轮 RAM row.executable 是否位于这一组 routes 的布尔值。字段名字不构成二进制类型证明，也不表示该行不属于任何其他合法 Python。结果没有保存该行原 PID、路径、argv 或 SID，因此不能识别哪一个进程、是不是自有 child、另一开发任务，或是否携带 profile 参数。不能据 family、当前 owner、该布尔值就忽略它或扩大信任范围。

## 材料及清理核对

候选 manifest D06BC8C0… 引用的 7 个候选文件实际 SHA 全部相符；result 与 attempt 的 17 个显式源码 SHA 完全一致，并逐项与当前精确文件匹配。runtime_identity_hash 在 result/attempt 中一致；本次独审未重新扫描 35 个 runtime 材料，不能冒称新的独立 runtime 全树验证。候选的两项合成机制方法及 .029 秒首 GREEN 是已有证据，本次没有再运行或新增 business 方法。

dispatch 与 attempt 的 execution_finished=false 是执行前不可变回执，实际 result finished=true 单列，未覆盖历史。root task receipt 核 Ready、LastTaskResult=1、实际 CIM RunLevel=Limited、XML 默认 RunLevel 缺省、current SID/InteractiveToken、精确 action/cwd、0 triggers、PT2M/IgnoreNew、result/attempt/parent SHA 及 owned exit/materials。Native exit=1 与 blocked 一致；后续 cleanup script exit=0 只说明自有任务清理成功。

首 cleanup guard 错误要求 XML 显式 LeastPrivilege，因 Scheduler 省略默认值而在写回执和注销前拒绝。`phase30-combined-reason-root-precleanup-check-note.md` 保留此时序；后续代码只接受实际 CIM Limited，并对 XML 若显式出现则仍要求 LeastPrivilege，其余精确身份/action/状态/材料校验保留。最终 cleanup 只注销本 GUID，absent=true、other_tasks_modified=false，没有重复 Native。

## 下一条最小路线（尚未实施）

建议先准备独立、RAM 内的 native executable/固定 runtime 补证，而不是忽略“正常 Python”或再开原号。对完整快照中的目标行，在同一个 PROCESS_QUERY_LIMITED_INFORMATION | SYNCHRONIZE 句柄上核原创建时间、前后运行状态、TokenUser/current SID、实际 native image 与关闭结果；仅在 RAM 内比较 CIM executable spelling、canonical 解析及已审 RuntimeIdentity shim/alias/base/cfg 内容摘要，输出固定布尔/摘要/原因。不保存 PID、SID、路径或 argv 原值。

必须继续绑定该行原 pid-created-parent，保留 argv/profile/父链/Job 既有核验；权限失败、alias retarget、创建时间或 native/CIM image 不一致、句柄关闭未确认都维持 unknown。先验证固定合法 route 与错配代表不会改变 classify verdict；任何新的良性 Native 都须另行审受冻结源与一次执行边界。本轮只交设计，不实现补证，不动 frozen classifier/adapter/trace，不杀其他进程、不清风险、不重复原账号观察。

本次独审只读取显式安全证据和冻结源码，写入本报告及对应 manifest。新增测试、Native、CIM、Scheduler、原数据读取、产品源码修改均为 0。
