# 本机原 AI 请求生命周期独立审查

日期：2026-10-10。范围仅本项目 `assistant/ai_attempts.py` 的实际磁盘源码、成熟 SQLite Store、已冻结云端 `ai_attempt_status` 契约；没有修改主窗口源码、接业务入口、访问真实账号/数据库、发出网络请求或调用真实模型。

## 本轮结论

本机模块当前必要边界可通过：独立 17/17，主窗口已有 14/14，共 31 个当前源码测试项（独立测试并非 17 个新增功能，不与历史云端 196 项重复累计）。这是模块及临时 SQLite 夹具的技术验证；尚未验证 LocalAIWorkflow 接线、实际客户端/云部署或真实收费。

最初源码的跨实例重叠扫描位于注册事务外，存在两个不同输入批次包含相同评论时同时扫空的窗口；主窗口在本轮读审期间已补同一 `BEGIN IMMEDIATE` 下的重扫、可信员工/设备复查及 validated 的原子提交。本轮首次独立执行已经使用修复后的源码，不能写成此夹具先红后绿。

审核源码 SHA256：

- `work/app/src/assistant/ai_attempts.py`：`B8C86031C9DEB2ECC9C02B06D9538D29CFB50ED3E48EC60F2B22E2C1BF3868D2`。
- 主窗口 `work/app/tests/test_local_ai_attempts.py`：`FA96713A780CEBE83541E86280C1E9CA133C687959436C5055154931938231F4`。
- 本轮独立 `work/product-upgrade-20261009/audits/test_local_ai_attempts_independent.py`：`D7B0D5B1C29F0479B2CC33AA70885D4816A9F1EFB34BBDE4DCA58229CA8CCA7A`。

## 已核对的实际行为

| 边界 | 当前证据与结果 |
| --- | --- |
| 先保存后提交 | cloud stub 进入时 SQLite 已有 submitted 原 UUID；持久元数据没有评论正文、原 lead ID、结果正文或原始错误字符串 |
| 重启与未知 | 新 Store/新 manager 读取原记录，未知仅发 `ai_attempt_status`，保持原 key，未知/旧无索引均不能自动新分析 |
| 同输入跨实例 | 两个独立 Store、独立 core.lock 同时读取不存在，事务只注册一个原编号并只调用一次 stub |
| 重叠批次跨实例 | 两个不同 input ident，包含同 lead 哈希，各自事务前同时扫空；事务内再次扫描只允许一个操作调用 stub |
| 配置/批次变化 | 未确定的原评论重叠或原配置变化都不能生成新 key 绕过；已 validated 的配置变更须 explicit_new，并将旧 key 元数据归档 |
| 真正可恢复成功 | 先核对同 operation/key 的安全 status，且 succeeded/true/result_available/无需重新核验，之后只用同原 key 取结果；此本机测试不单独宣称无额外费用，后者依赖已冻结服务端索引/资金证据 |
| 已知未计费 | known_unbilled + execution_confirmed 为严格 False，仍须 explicit_new 才产生新 key，并保留旧 key 历史；未主动确认保持原编号 |
| 不可信状态回执 | key/operation 不符、read_only 非 True、retry_allowed 非 False、billing_verified 非 False、整数 1 冒充布尔 True 均不能解锁 |
| 身份/设备变化 | status 后身份范围变化不再 dispatch；模型返回后员工 disabled 或 host 变化不返回结果，只将已 dispatch 的原请求保守记为 unknown 元数据 |
| 验证事务内变化 | validated 在原子事务末再次复查 host；测试中此时切换设备，整笔 UPDATE 回滚，原 response_received 记录保持原样 |
| 隔离与调用方 | 伪造 tenant/actor 或前端塞 request_id 在 cloud 前拒绝，不改原请求 |

“身份变化不落盘”在本模块按主窗口明确语义指 **模型正文/意向结果不写入业务数据**。保留已发出请求的 unknown 元数据是必要的保守状态，不释放预留、不证明未执行、不允许新 key；本轮没有发现它打开重复收费入口。哈希只用于缩减持久原始内容和稳定关联，不宣称已匿名化或构成操作系统隔离。

调用方仍须使用当前可信员工、host callable、服务端 profile/本机 policy snapshot，而非接收前端自称 context/lead_ids/explicit_new。本模块没有独立公开路由，不验证业务 lead 权限或应用意向结果，最终业务 CAS/手工结果优先及权益核验仍由主窗口工作流负责。

## 明确待接通：首次预提交拒绝的安全恢复

当前冻结云源码中，`AI_NOT_CONFIGURED`、`AI_DAILY_BUDGET`、`PRODUCT_ANALYSIS_LIMIT` 确实可在本轮 provider 调用/新增预留前拒绝，但实际错误响应只有 code/error/pending，没有绑定原 key 的执行阶段/历史核验凭据。单独错误码不能否定同原编号此前已经执行。

`PRODUCT_EXPIRED/FEATURE_DENIED` 还可能在已预留后的 markAttempt 拒绝；认证可能在模型执行后的结果复验失败；timeout 不能区分调用前与已发送后的未知。`mutation_committed=false` 若仅针对当前失败事务，也不证明前一预留/模型请求未执行。

因此当前安全接法必须保持：

1. 本机在发送前保存原 key；结果不明只核对该 key，不随机换编号、不按错误码推定无费用。
2. `unknown/legacy_untracked` 继续 hold；legacy 无索引不是未执行。保持本机模型/批次/配置变更不能跨过这一状态。
3. 只有已冻结云契约的 `known_unbilled` 且严格 execution_confirmed=False，或本机能证明 **网络根本尚未发出** 的 prepared 记录，才有确定未提交/未计费的依据。当前代码在提交前直接持久 submitted，不提供 prepared 未发送恢复路径，不能把所有 submitted 反推成 prepared。
4. 真正要让首次预算/配置拒绝可恢复，应由服务端在同一可信鉴权事务中核对原编号索引/输入 anchor/历史资金与缓存证据，登记或返回原 key 绑定的 terminal no-dispatch 回执；可沿用 known_unbilled 语义或明确命名本次 never_dispatched 事实。只能在确定没有原执行时成立，不覆盖 unknown，不给旧无索引历史伪造证明；本机收到后仍由用户显式重新确认新操作。
5. 本机 context 变化时当前 call 会在 status 前拒绝，能安全 hold 但不能在新配置下直接核对旧状态。接线应提供独立 **只读原编号核对** 的内部方法：从当前授权本机 row 派生原 operation/key，只请求 status，不接受正文、不应用结果、不新分析；配置不符仍不允许取旧结果/缓存/写业务意向。此项属于后续接线建议，本轮没有擅自新增入口。

第 4 项是可用性缺口，不能把源码准备就绪写成已经解除“首次确定拒绝但云无索引”的锁定。本轮只给出候选接法，不修改已冻结云源。

## 复现与验证命令

在项目 `C:/积木软件工坊/项目/方隅公寓客户版`，分别执行：

```powershell
& 'C:/Users/rmsama/miniconda3/python.exe' -m unittest discover -s work/product-upgrade-20261009/audits -p test_local_ai_attempts_independent.py -v
& 'C:/Users/rmsama/miniconda3/python.exe' -m unittest discover -s work/app/tests -p test_local_ai_attempts.py -v
```

本轮执行结果为 17/17 和 14/14；每个 fixture 使用 TemporaryDirectory，双实例指两个独立对象/连接共用临时 SQLite，不等于真实双机器或 OS 进程网络测试。provider 计数是 stub 调用计数，不是实际云付款/模型账单。

本轮能力目录重新匹配后沿用已验证 Store、Python unittest 和现有服务端账本；定价营销 Skill 不承担纯源码并发审查，没有为此任务新建定价/registry 或开启付费服务。可读周窗剩余 24%，另一窗不可读，未触发 <5% 停止阈值。
