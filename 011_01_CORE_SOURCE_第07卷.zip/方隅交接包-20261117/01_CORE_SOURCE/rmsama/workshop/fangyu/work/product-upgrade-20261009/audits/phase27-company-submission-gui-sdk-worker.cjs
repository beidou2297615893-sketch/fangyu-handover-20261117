/* Actual createService/createStore/repos, isolated SDK-interface adapter replay.
 * No network, real company/account, or node-sdk transaction-engine claim. */
'use strict';
const readline=require('node:readline');
const assert=require('node:assert/strict');
for(const mod of ['node:http','node:https'])require(mod).request=()=>{throw Error('network forbidden');};
require('node:net').Socket.prototype.connect=()=>{throw Error('network forbidden');};
global.fetch=()=>{throw Error('network forbidden');};
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const project=path.resolve(__dirname,'../../..');
const sourcePaths=['work/cloud/workspace/index.js','work/cloud/workspace/service.cjs',
 'work/cloud/workspace/contact_ledger.cjs','work/cloud/workspace/handoff-ledger.cjs',
 'work/cloud/workspace/source_binding.cjs','work/cloud/workspace/product_entitlements.cjs',
 'work/cloud/workspace/handoff-operation-status-fixture.cjs','work/cloud/workspace/business-reconciliation-fixture.cjs'];
const sourceHashes=()=>Object.fromEntries(sourcePaths.map(name=>[name,
 crypto.createHash('sha256').update(fs.readFileSync(path.join(project,name))).digest('hex').toUpperCase()]));
const loadedHashes=sourceHashes();
const {fixture}=require('../../cloud/workspace/handoff-operation-status-fixture.cjs');
assert.deepEqual(sourceHashes(),loadedHashes,'worker sources changed across require');
let engine=null,registerCalls=0,submitCalls=0;
async function command(input){
 if(input.kind==='source_hashes')return {startup_cloud_source_sha256:loadedHashes};
 if(!engine)engine=await fixture();
 if(input.kind==='sync'){
  const result=await engine.call('contact_events_sync',{events:[input.event]},'fixture-source-device-token');
  assert.equal(result.status,200);return {result};
 }
 if(input.kind==='register'||input.kind==='submit'){
  if(input.kind==='register')registerCalls++;else submitCalls++;
  if(input.lose_response)engine.loseNextResponse();
  const result=await engine.call(input.kind==='register'?'acquisition_channel_register':'acquisition_handoff_submit',input.data);
  return {result};
 }
 if(input.kind==='read'){
  assert.ok(['acquisition_source_binding_read','acquisition_handoff_operation_status','acquisition_handoff_detail'].includes(input.operation));
  engine.data.resetOperations();const before=engine.data.snapshot();
  const result=await engine.call(input.operation,input.data);assert.equal(before,engine.data.snapshot());
  const operations=engine.data.operations();
  for(const callbacks of operations)for(const count of callbacks)assert.equal(count.writes,0);
  return {result,operations,stored_documents_unchanged:true};
 }
 if(input.kind==='accept_withdraw'){
  let out=await engine.call('acquisition_handoff_detail',{channel_id:input.channel_id});assert.equal(out.status,200);
  assert.equal(out.data.item.status,'submitted');
  out=await engine.change('acquisition_handoff_receipt',out.data.item,
   {decision:'accept',evidence_reference:'evidence:'+'e'.repeat(32)},engine.tokens.resource);assert.equal(out.status,200);
  out=await engine.change('acquisition_handoff_withdraw',out.data.item,{reason_code:'customer_withdrew'});
  assert.equal(out.status,200);return {changed:true};
 }
 if(input.kind==='receipt_accept'||input.kind==='customer_withdraw'){
  let out=await engine.call('acquisition_handoff_detail',{channel_id:input.channel_id});assert.equal(out.status,200);
  if(input.kind==='receipt_accept'){
   assert.equal(out.data.item.status,'submitted');
   out=await engine.change('acquisition_handoff_receipt',out.data.item,
    {decision:'accept',evidence_reference:'evidence:'+'e'.repeat(32)},engine.tokens.resource);
  }else{
   assert.equal(out.data.item.status,'accepted');
   out=await engine.change('acquisition_handoff_withdraw',out.data.item,{reason_code:'customer_withdrew'});
  }
  assert.equal(out.status,200);return {changed:true,item:out.data.item};
 }
 if(input.kind==='restart'){engine.restart();return {restarted:true};}
 if(input.kind==='counts')return {register_calls:registerCalls,submit_calls:submitCalls,
  channels:[...engine.data.docs().values()].filter(doc=>doc?.channel_id&&doc?.source_event_id).length};
 throw Error('unknown synthetic command');
}
const lines=readline.createInterface({input:process.stdin,crlfDelay:Infinity});
(async()=>{for await(const line of lines){try{process.stdout.write(JSON.stringify(await command(JSON.parse(line)))+'\n');}
 catch(error){process.stdout.write(JSON.stringify({fixture_error:error.message})+'\n');}}})()
 .catch(()=>{process.exitCode=1;});
