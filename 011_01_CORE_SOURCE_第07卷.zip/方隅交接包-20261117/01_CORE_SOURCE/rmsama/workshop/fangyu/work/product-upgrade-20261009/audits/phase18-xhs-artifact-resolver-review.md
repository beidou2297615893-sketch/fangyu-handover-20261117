# 固定小红书 CLI 与许可 resolver：精确接线证据

本轮为本客户版只读选型；没有导入/调用 CLI、EXE、账号服务、原库、Cookie、DPAPI 或网络，也没有改生产。只执行了现成源码备份核验，以及从 `runtime_guards.py` 的 AST 提取纯整树哈希函数对固定静态运行库计算摘要。没有实例化 Server 或读取真实配置，故不推测当前运行进程选用了哪一路。

## 当前已有充分的 artifact 身份证据

固定备份 `work/product-upgrade-20261009/cli-backup/source-backup-manifest.json` SHA `23623AA2D301027B81F3FF666447BAB1B063AE23F183539C4E601DDB82B463C1`，kind=source_only_backup，41文件/353685字节。既有 `outputs/产品升级/验证CLI源码备份.py` 本轮 exit0、41/41；41条对应**当前来源文件**亦无摘要差异。该备份没有 EXE，不充当二进制恢复包。

| 当前固定对象 | 本轮实际摘要 | 核对 |
| --- | --- | --- |
| `work/app/src/platform_cli.py` | `2580bd579de76191a5bfd33109c612287f19c94bc55dc10fb64873a31676bb31` | 与 guard source 一致 |
| `work/app/work/runtime/platform-cli-guarded/guard-manifest.json` | `eb007b5d293e2a880ae479207c18edcc2aa85398fada01d2f57040fb09c716f5` | 与41备份一致，读取前后未变 |
| 同目录 `platform-cli.exe` | `5697bfbbeee13e4572f4fa47d4f5bec829bea278403c2da323cb9ffa7b3c648b` | 与 guard exe 一致 |
| 同目录完整静态 runtime tree | `c7da4bb61f8c95e38490def1a0078d81d4dcc16630060bcb671a53f1a05ee621` | 成熟整树算法复算一致 |
| `work/qa-cli-source-20260926/xiaohongshu_cli-0.6.4-py3-none-any.whl` | `7168c427e3b06ea069c505ab387da8b647fd7d292bcbb12474c00fc687fcb5bb` | 与既有候选构建固定输入一致 |

27个备份覆盖的当前 `runtime/_internal/xhs_cli/*.py` 与该 wheel 同名源码逐项一致；这27文件按“sorted包内路径+NUL+单文件SHA+LF”聚合为 `7c821a2728faff56ff6589c27699691552e3f09f5e3b399b974214bff6283e3d`。此摘要**仅覆盖这27个.py**，不是含 py.typed、所有依赖和EXE的完整源码发行树摘要。楼中楼 PR81 兼容修补实际在包装入口 `platform_cli.py:287–321/334`，并没有要求这27个上游文件与旧候选 vendor 相同；必须将包装入口摘要一起绑定。v2/v3候选的输入/EXE与当前值不同，不能拿旧 stage 的验证替代当前对象。

实际整树结果在 `audits/phase18-selected-cli-artifact-readonly-probe.json`。以上证明当前**guarded CLI** 的可追溯身份和字节一致，未证明真实采集、商业审核或正式 release；purpose 仍 `internal_qa_only`。

## 许可证据目前只足以定位材料，尚不能自行给 true

可复用：`work/licenses/Apache-2.0.txt` 实际 SHA `cfc7749b96f63bd31c3c42b5c471bf756814053e847c10f3eb003417bc523d30`；`work/packaging/build_release.py:73–86` 已核正文并准备来源/包装改动说明；0.6.4 METADATA、上游配置快照、20260926两份许可审计与依赖材料都存在。

仍未找到：**把当前 route、上述当前 source/exe/tree、实际包含的依赖/版权告知和适用使用范围绑定的可信审核记录**。`resources/licenses/DEPENDENCIES.json` 是更宽的应用依赖材料表，xhs行仍记录独立分发正文缺口；它不能直接代表此当前 CLI 的完整依赖盘点。QA52包清单也不等于当前冻结树。应补精确对象的材料核对/审核结果，不以 metadata 的自声明、源码备份完整或内网 QA 安装许可作为审批。

内部自营读取与正式商业分发是不同范围；不能要求两者假装共用一个“全部许可已完成”真值，也不能把分发文件缺项自动解释为平台登录被禁止。本轮不提供法律结论或新增批准。

## 正式 Server 的最小只读 resolver 草图

保持既有三处 getattr 消费，Server 只读属性 `platform_read_license_policy` 调用 `resolve_xhs_runtime_license(server) -> dict | None`；不接受前端参数，不设新操作/审核页，不写业务数据或自动生成审核。

1. 从可信 Server 与 adapter 的实际选择派生 route。仅在 `server.xhs_page_runtime` 和 `core.adapters.xhs_page_runtime` 均为空、selected executable 等于 server.guarded_cli_executable、prefix为 `['xiaohongshu']`、mapper为xhs_v1且隔离守卫成立时，使用本 guarded CLI 证据。`adapters.py:400` 的 page runtime 会接管读取，因此仅查看 manifest.exe 不够。自然页无本轮适用审核，返回 unknown，不能借41CLI证据授权。
2. 复用 `guarded_cli_runtime_valid`/`cli_runtime_tree_sha256` 的字节验证，以及固定备份/许可材料的摘要。不要导入构建器，不构造 `account_spec`、账号目录或会话，不自动更新/切换运行库。缓存若使用必须绑定当前不可变 artifact 及审核修订，变更即失效；别每页另跑全量无关扫描。
3. 从固定服务端来源读取与此 route/artifact/使用范围**精确匹配**的真实审核结果。未找到/异常/不匹配返回 `None`；明确否决返回 `{xiaohongshu:false,revision:<bound revision>}`；明确通过才返回 true。当前缺该结果，不能用硬编码 true 补洞。
4. revision 以 route、source/exe/tree、材料摘要、审核版本/范围的 canonical 摘要派生。`platform_reads.py:265–276` 仅摘要平台bool+revision，所以审核换版、true→true也必须改变revision。当前 R22 ctor 会 `dict(license_policy or {})`，故属性应返回值而非 callable。
5. 软件套餐继续走 service_plans；设备QA/登录与活动风险继续走原门禁。该 resolver 只解决组件使用审核，不延长 QA 窗口、不清461/旧unknown、不授予acquisition权益、不自动续会话。

下一软件增量应复用这些精确材料生成可核对、范围清楚的服务端审核输入和 resolver 接线；若材料不能关单，现成预检仍保守 unknown，并在原设置/单批入口说明缺项。不新增只读页，也不因该接线运行真实采集。

## 缺失审核记录的最小候选格式

以下是**尚未写入的 pending schema 草图**，不是通过回执。固定服务端启动来源提供 deep copy/不可变副本，不接运行时 body 的路径、decision、hash 或 route；它本身的可信来源应由当前安装/源码批准输入绑定。结构验证不等于审核。

```json
{
  "schema_version": 1,
  "kind": "runtime_component_use_review",
  "component": {
    "name": "xiaohongshu-cli",
    "version": "0.6.4",
    "wheel_sha256": "7168c427e3b06ea069c505ab387da8b647fd7d292bcbb12474c00fc687fcb5bb"
  },
  "route": "guarded_cli_v1",
  "usage_scope": "internal_self_use_read",
  "artifact": {
    "wrapper_sha256": "2580bd579de76191a5bfd33109c612287f19c94bc55dc10fb64873a31676bb31",
    "exe_sha256": "5697bfbbeee13e4572f4fa47d4f5bec829bea278403c2da323cb9ffa7b3c648b",
    "runtime_tree_sha256": "c7da4bb61f8c95e38490def1a0078d81d4dcc16630060bcb671a53f1a05ee621",
    "guard_manifest_sha256": "eb007b5d293e2a880ae479207c18edcc2aa85398fada01d2f57040fb09c716f5"
  },
  "materials": {
    "license_text_sha256": "cfc7749b96f63bd31c3c42b5c471bf756814053e847c10f3eb003417bc523d30",
    "component_notice_sha256": null,
    "actual_dependency_inventory_sha256": null
  },
  "review": {
    "decision": "pending",
    "revision": "phase18-pending-v1",
    "reviewed_at": null,
    "reviewer_ref": null,
    "evidence_sha256": null
  }
}
```

decision 仅 pending/approved/denied。approved 需要实际范围对应的审核报告、审核主体/时间与材料哈希可追溯，不能由“所有声明都是Apache”自动生成；内部使用范围的审核应说明哪些实际分发/运行依赖被核过、剩余项为何不影响该范围。正式分发另设 usage_scope/审核记录，不复用内部 QA 决定。上列 null 是本轮未形成该精确绑定证据，而不是认定项目没有任何版权或告知文件。

**静态 trusted dict 方案可行**：静态的是审过的材料/决定与预期 artifact，不是永远有效的最终 true。Server 属性在每次消费时由此副本核当前实际 route/摘要，然后返回 dict/None；不得由前台 self-upgrade。现 `AppServer._platform_execution_guard` 会重新验 tree 与 guard 自声明，但它没有和本审核记录的 expected exe/tree 固定值比较；同步换成另一套 guard+exe+tree 且 wrapper 不变时，旧审核不能继续授权。因此 resolver 必须另外比较审核绑定值。现 provider 的 bool+revision 摘要让旧 owned receipt 在审核/路线变化后失效。

可复用同一次实际读取门禁已经算出的**同范围/同快照**完整摘要，避免在读、归档与 SQLite 事务里重复整树计算；仅 size/mtime、启动时一次核验或旧缓存不构成每次读取验证。确需独立重算时保持纯文件读并评估成本，本轮整树探针耗时不是正式性能验收。R22 provider 是读取许可/预检依据，不能借此新增发送能力、延长当前设备许可或解除旧 unknown。
