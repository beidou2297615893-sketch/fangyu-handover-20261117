# Phase25 公司平台身份草稿到独立接收：首选路线设计

这是只读路线设计，不是新增功能验收、测试数或真实公司操作。本轮没有执行测试、Node worker、平台、云、网络、账号登录、发送、部署、导出或打包；未读原 DATA、Cookie、凭证。只新增本报告。按已读取的 RevOps 规则区分来源、明确提交、接收回执与现金事件；工程优先复用项目现有成熟 company ledger，不另造一套云 API。

## 首选结论与唯一主要缺口

已有准确读接口 `acquisition_handoff_detail {channel_id}`。已存 preparation origin 给出确定 `expected_cloud_channel_id`，原 register status 给出其原 action/key/hash/revision1/draft；因此丢整条 write 回执后可以按原 hc 直接读取公司 **当前** channel.source，逐字段与本机固定原 event 核对，无须扫描清单。再用成熟 `acquisition_handoff_submit` 进行一次人工确认提交，提交结果不明只查其原 action/key；接收必须由另一位当前公司授权的资源部主体操作。

下一最小切片应补 **现有 detail 的纯读接线 + 独立的当前来源对应投影**。Phase23 `registration_source_verified` 代表被保存的原成功 write 来源回显（registration.py:156–177、188）；丢回执后该历史值 false 保持不动，不能以原 event matched、当前详情或同 UID 补成 true。新 `current_channel_source_matched` 仅表示本次详情与原来源对应。它也不是平台权威或历史全链证据。公司 submit 目前尚未接入本机，Phase23 所有 `eligible_for_company_submit=false` 仍真实。

## 已有准确接口与角色

所有请求均有 `environment_id`、`operation`；环境、公司与身份由可信托管配置及当前 authenticated session 派生，Bearer 不进正文。以下是现有云接口，非新建议 API：

|动作|其余精确允许字段与约束|当前服务器权限 / 结果|
|---|---|---|
|`acquisition_handoff_detail`|`channel_id` 为 `hc_` + 64小写hex|来源本人、当前有权 manager/admin、或该 recipient 的 receiver 可读。返回 `item`；读当前 channel + 最新 audit/snapshot 自hash + 撤回标记。|
|`acquisition_handoff_list`|`view` 默认 owned；可选 `recipient_id, offset, limit`，limit1..25 / 默认20|owned按 authenticated username source index；received须 receiver 映射；managed须 manager/admin。返回 `items,total,offset,has_more`。**没有 channel/event/UID 精确筛选字段**，不能当 exact list。|
|`acquisition_handoff_submit`|`channel_id, expected_revision, idempotency_key`|仅来源本人、当前 draft / 同意有效、handoff 权益有效。同 customer 的 active claim 若另 channel 占用则409重复待核。成功 status submitted，revision+1；不是 accepted。|
|`acquisition_handoff_receipt`|同3字段，加 `decision,evidence_reference`；非accept另必需 `reason_code`|另一位 receiver 且 recipient 在 trusted acquisitionPolicy.receivers[username] 映射中，status submitted / 同意有效。admin身份本身不等于 receiver，source即使配置receiver也不能自签。|
|`acquisition_handoff_withdraw`|同3字段，加 `reason_code`|来源本人可撤回非withdrawn。原因 customer_withdrew / incorrect_information / duplicate / existing_customer / ownership_conflict；customer_withdrew另落 consent 撤回标记；原历史不抹掉。|
|`acquisition_handoff_operation_status`|`operation_action,idempotency_key`，原7种写动作之一，key ASCII8..128|从公司+当前actor+action+key定位原 operation；缺行 unknown / original_execution_confirmed=null，不创建墓碑、不取消、不证明未执行。存在则验证原 audit 自hash、原 actor/action/revision/status，并分列当前权限/授权/状态。|

参数门禁：handoff-ledger.cjs:282–291；角色/public投影:55–85；submit/receipt/withdraw:130–168；list/detail:190–207；原操作读取:216–277。

receipt 的 decision 为 accept / reject / needs_information / duplicate / existing_customer；后四项对应原因分别 not_qualified或outside_service_area / needs_information / duplicate / existing_customer。accept不允许混入拒绝原因。evidence_reference必须 `evidence:`或`document:`+32小写hex，不能伪造为手机号或单纯点击确认（ledger:19、42、145–152）。返回 receipt 的 actor、recipient_id、decision、证据引用、recorded_at 是公司已认证主体登记，`authenticated=true`，但 `evidence_independently_verified=false`。source与resource可以同为operator角色，必须不同 **主体username**，不能让同一个账号切role充当独立接收。

同意引用仍是 operator_recorded / independently_verified=false。`publicItem`当前accepted时 resource_receipt_auth_verified=true，只表示角色认证记录；settlement.amount_cents=null、attribution_confirmed=false、platform_delivery_verified=false。当前撤回后历史accept可能仍存在；须复用 operation_status 的 historical_resource_receipt_recorded 分列，不只用当前accepted布尔表示全历史。

## detail 能否做到真正零写

静态控制流证明 **ledger detail handler本身** 没有写：read:190–192 → itemFor:77–85 只读取 channel/最新audit → publicItem:62–75 → authorization:61只读取 withdrawal。requireFeature（product_entitlements.cjs:60–61）仅读取当前policy，无reserve/settle；devices.cjs:68在设备字段初始化前对detail返回null。没有append、addIndex、repo.set或预算写。

现有 service 仍有入口副作用：service.cjs:57–81只把 status/source_binding 纳入 readonlyPureQuery，detail在 HANDOFF 分发175返回清理过的state；index.js:19–20因此可能保存expired session/rememberedDevice/attempt housekeeping。missing company还会走初始管理员创建（service:67–73）。**现在不能说 exact detail 整条链0write。**

最小复用修正建议（待实施授权，不改本轮源）：

1. 仅把现有 `acquisition_handoff_detail` 纳入成熟 readonlyPureQuery；missing company像status/source_binding返回固定503、保持stored，不初始化账号。入口dispatch也返回stored，错误分支保持stored；不扩到全部动作、不改读业务含义。
2. 对该既有成功/错误详情响应追加本次 `read_only:true / mutation_committed:false / auto_retry:false`，保留既有envelope。不要新增同名 original_execution_confirmed outer假值；原写事实只由operation_status提供。
3. 详情handler沿用readBoundItem/statusActor成熟门禁，在同一事务末重新核当前actor/session/role、visibility、recipient映射与current_consent；两次绑定快照/最新revision/hash若改变则拒绝。现detail的单次初始auth与latest selfhash不是新的末await fence。无须新云查询或新索引。

此处只有静态“handler无set”证据；真正 service/createStore 零写要由下一最难合成代表直接检查每事务set计数和document snapshot，不能借原status/sourcebinding的0write证据代替。SDK内存callback重放也不能称在线引擎实测。

## 本机最小只读合同与来源核对

建议独立入口 `company_handoff_channel_check_get {handoff_id}`，复用phase12 origin、phase13历史原event、phase14绑定读、phase23 durable attempt；不修改原36字段合同或历史attempt flag。构造沿用 trusted Core/tenant/owner/company/device_id/scope_guard/lead_access + 专属现有session无refresh的 cloud_read。前端不收 hc、云key、owner、env、source或任何联系方式输入；没有origin / 没有已存登记attempt时0公司调用、0SQL写、不生成key/墓碑。

有原登记attempt时，先复用原 `operation_status(register, origin.cloud_idempotency_key)` 严格验证固定 canonical payload hash、expected hc、原revision1/draft、原actor/company；unknown只保留原号，不允许重新register或submit。再按origin的event_id / fullpayload hash / original device读成熟source_binding（完整7 kinds并不是送达状态），最后 exact detail(expected hc)，不按昵称或同UID猜另一channel。

必须核对 detail 当前 item 的 company_id / source_owner / source_event_id / customer_id / channel_id，以及 source完整8字段：platform、author_id、comment_id、source_lead_hash、device_id、original_text_hash、evidence_source=device_report、platform_provenance_verified=false，均从固定 **原event** 取得，不能拿今天变更的lead代替历史来源。同时核 recipient_id、purpose、platform contact_reference、qualification、consent status/reference/notice/evidence_source/independently_verified；来源匹配与当前withdrawn分开。只信最新真实公司revision和当前同意，不能伪造replayed=true调用原write校验器假装收到write回执。

最小公开投影建议：

- `contract:company_handoff_channel_check_v1`, `state:no_origin|not_attempted|registration_unknown|matched|hold`, `read_only:true`, `mutation_committed:false`, `cloud_read_requested`, `observed_at`（未调用null）。
- `origin:{origin_id,local_handoff_revision}`，`original_registration:{execution_confirmed,revision,historical_status}`或null；不返原云key/fullpayload hash/正文。
- `current_local:{revision,status,consent_state,source_state,preparation_usable,blocked_reason}`；`current_company:{channel_id,revision,status,current_consent_valid,recipient_name,historical_resource_receipt_recorded}`或null。编号只折叠核对信息，不裸露UID、consent/evidence/contact引用。
- `current_channel_source_matched`、`company_event_payload_matched`分别表达两份本次证据；原 `registration_source_verified` 只按phase23历史值引用，失回执仍false，GET不回写attempt。
- `source_cloud_binding_verified:false / platform_delivery_verified:false / financial_receipt_verified:false / cross_machine_verified:false / verified_cash_cents:null / verified_paid_commission_cents:null / auto_retry:false`。本read切片不开放submit；以后writer必须独立fresh复核，不拿旧matched截图当授权。

读取每await及HTTP公共投影前重核本机saved actor、device、company/env/vault/session、原origin和immutable event、当前lead权限/本机授权状态。原来源/当前local变更仍可有权读取历史，但当前条件不成立必须hold。详情快照匹配是公司记录对应，不能提高source_cloud_binding权威false。

## 沿这一条路线继续明确submit与独立ACK

下一单条submit由本机已存origin/匹配结果派生准确channel，点击明确确认后重读上述3份证据和当前本机ready/qualified/授权。固定新的 **submit原动作** 与它自己的服务端key、完整canonical payload、expected当前draft revision，另存持久CAS attempt；不能沿用register key或generic cancelled receipt。单origin/action未知attempt不因换revision/key解除。公司是actualcurrent session source本人；不可代资源部登录。

成熟cloud submit原号ID为 SHA256(companyId, authenticatedActor, action, key)，同号同payload回读existing，不增审计；同号改payload409。客户端结果不明仍 **只GET原action/key**，不自动重放POST。若baseline是draft1，则submit原操作历史rev2/submitted；即使当前已经accepted或withdrawn，原操作历史仍单列，不因为当前状态改写为未提交。

资源部使用自己当前有效且有recipient映射的session读received清单/准确detail，按新鲜revision明确receipt。source不能自签，admin未映射也不能签。source可读自己channel当前receipt，但不能用source自己的session查询另一resource actor的原receipt key并期待有结果；operation_status严格按本次actor派生。该阶段只能证明已认证另主体登记接收，现实证据独立核验仍false。receipt不是订单、分成或cash，不直接更新本机local receipt为“跨机已送达”。

## 仅一个最难合成代表计划

复用Phase23 RegistrationFixture实际Core + SDK接口兼容内存store/成熟service与repos，使用独立合成source和resource session。仅扩单条完整链，先代表通过再决定范围；本报告不执行、不计通过：

1. 原register已commit但整个write回执丢失；同origin GET找回原regrev1/draft，旧attemptunknown/sourcefalse保持。准确detail current.source与原event逐字段匹配，public新current_channel_source_matched=true。放入expired housekeeping合成行/missing company子场景，断言只读全path0set/SQLite0DML，不新register。
2. 只人工点击一次submit，实际提交后再丢响应；重建本机helper和公司service，只按已存 **submit原key** 查询。证明register1/channel1/submit1、原submit历史rev2/submitted、没有换key/自动POST、原lease/原source不被补造。detail/source错comment而同UID或current同意撤回时，明确提交前0submit。
3. 同source账号即使映射receiver仍拒；另一个未映射admin也拒。真实合成resource actor独立accept后再由source withdraw。source原submit status依然历史submitted，当前withdrawn、currentconsentfalse、历史receiver认证记录true、independently_verifiedfalse、现金null。最后await主体/recipient权限变化应拒旧数据或新submit，不当成取消已经开始的公司写。

真实公司成员/接收方策略配置、原session、customer授权证据、protected电话微信交付、第二机器、线上性能与账务都不由此合成代表解决，不要求用户重复开发授权来实施可逆切片。受限真实操作仍需当前明确事实与动作授权。

## 本机联系与Excel不能代替交付

ContactJournal的7kind reviewed / send_started / sent / failed / unknown / copied / external_reported仅保存联系证据；ack表由本机归档回执登记（contact_journal.py:187–197），不证明公司channel、平台送达或资源部接收。

本机 AcquisitionOperations._submit:648–665只写ready_to_deliver / delivery_status=local_only；_receipt:667–692只写authorized_local_principal / acknowledged_locally，不能冒充公司资源部ACK。现 `handoff_export {format:xlsx|csv,mode:delivery|audit,limit1..1000,ids?}` 在当前本机有权范围、有效同意/来源下生成，导出字段16列不含phone/WeChat/platformcontact/原文，`delivery_confirmed:false / cross_machine_verified:false`（acquisition_exports.py:24–32、146–211）。它是核对清单，不能作为联系方式交付或上传公司附件后的自动ACK；本路线继续平台UID引用，电话/微信DPAPI安全跨机交付必须单列后续方案。

## 读取时源码绑定

以下是本报告只读时点，不改Phase23冻结材料；不是运行或审核批准：

- `work/cloud/workspace/handoff-ledger.cjs`：`7CA948D72A8C93763BFD00E2303BAFA35B6B12AC7450114F414DA301A5195128`
- `work/cloud/workspace/service.cjs`：`03ABDAF27E87CC459BCE5CC6C1E7764C8D87CE576845454F22B84AB406A22C95`
- `work/cloud/workspace/index.js`：`223A150519F3BCACE360D35BBDAF876DEEAB74AF426D415A3DF3B259DA2AFF1B`
- `work/cloud/workspace/channel_candidates.cjs`：`759670533DD394A86718B56A20B2D261A41F39941EF6D2E047CA66E71FDF6924`
- `work/cloud/workspace/product_entitlements.cjs`：`8097559A9309C98738AB9FD30D3264969FE3E79039312981B0295C12ACD864EA`
- `work/app/src/assistant/company_handoff_registration.py`：`55E89EAC7E609F5C0FCAB3AA13A3C9007514D64E8C99C7BBCF00E144865D39BB`
- `work/app/src/assistant/company_handoff_original_status.py`：`E18FA2A6F5BAEC170446B680231A3C72C37244F4D3C0752F025ABE1F2E1C4AFD`
- `work/app/src/assistant/company_handoff_source_binding.py`：`6B545194AB048A240F0B66D80DFD887E55535612214C33DD021434CD07B42AB3`
- `work/app/src/assistant/acquisition_operations.py`：`B212C0620D110921BEFBD20B048B54B71DDE1ED87888DD77866BAB7E58C6A97F`
- `work/app/src/assistant/acquisition_exports.py`：`B41BB719972020ED790ED937185201E1130C260CE8DCDF9E5D9FDB2287A21731`
- `work/app/src/core/contact_journal.py`：`00A256186ED155039D214E9D55FA05D8A45C81DA16027A46F7D23DD88CF79DFF`

文件：C:/积木软件工坊/项目/方隅公寓客户版/work/product-upgrade-20261009/audits/phase25-company-delivery-route-candidate.md

文件夹：C:/积木软件工坊/项目/方隅公寓客户版/work/product-upgrade-20261009/audits
