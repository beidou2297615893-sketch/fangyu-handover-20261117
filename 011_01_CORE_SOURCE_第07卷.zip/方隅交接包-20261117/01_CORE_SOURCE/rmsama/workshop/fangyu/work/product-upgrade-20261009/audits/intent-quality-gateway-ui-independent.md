# R23 实际网关与抽检界面独立复核

范围为根代理新 product_workspace.py 与 intent-quality-ui.mjs/shared operations 的只读审查；独占新增 tests/test_intent_quality_gateway_independent.py、tests/intent-quality-ui-independent.test.cjs 与本报告。未改生产源、原数据库、账号或真实云。所有客户、员工、设备和企业均为人工夹具。

网关实际通过 employee_workspace.gateway → product_workspace.dispatch → IntentQualityReview → 同一个实际 Core/SQLite Store。复用后端测试的合成 setup，未继承/重复执行原23项测试；generic ProductOperationReceipts.begin/finish/status、socket.connect、平台 Popen 都被禁止。实际业务网关 owner/vault 门禁仍运行，只有本地合成 vault 的已绑定信息。

界面使用真实后台服务导出的响应合同：audits/generate-intent-quality-ui-fixtures.py → intent-quality-ui-actual-contract-fixtures.json。夹具记录来源后端 SHA、synthetic_only=true、real_database_access=false、network=false。轻 DOM 运行实际 createUpgradeOperations 与 createIntentQualityUI；没有原生/IAB GUI、真实浏览器或平台账户。这不能代替根代理的隔离实际 GUI 验收。

## 已查明并修复的差异

初次源审发现空批次合法 sample_count=0 却被前台 min1 拒绝；stale 本文被安全隐藏却被 UI 要求 text；batch/sample 编号先前只是宽泛 opaque。根代理修复。上述发现来自真实源读取，当时未运行成失败测试，不能冒称已保存旧源码红例。修复后的实际合同测试均通过。

界面独立6项初测试有一条“stale 应完全没有 textarea”的断言过严：生产源已经禁用标注，不是缺陷。该断言修为所有 textarea/保存控件 disabled 后，真正红例为2项：refresh_required=false 仍被 shared write 接受并清原号；conversion_rate=1 仍通过 summary。后续矩阵红例是单批 sample_count=labeled_count=1，但 current 的 labeled_pair/decisive/agreement 及矩阵合计=2 仍被接受。根代理收紧真实 proof、业务边界和指标上界后，原独立6项全部通过。

保留日志：intent-quality-ui-independent-initial.txt（含测试自身过严断言）；intent-quality-ui-independent-red.txt（4过2真实红）；intent-quality-ui-independent-matrix-red.txt（5过1真实红）；intent-quality-ui-independent-final.txt（6/6通过）。不把未运行到的循环后继反例声称初次已失败；最终全循环均实际执行。

UI 验证涵盖：实际空批成功/shared清号/历史读/nullable统计；stale无正文仍显示历史且禁标注；64hex编号、操作回执refresh/cancel/real-platform矛盾拒绝且保留原opaque元数据；只能按原action/key恢复且不重发写；未知create在当前弹窗立即出现恢复；缺记录status取消墓碑文案明确阻迟到；reset/换scope晚读取或恢复不回填，原未知key保留；summary虚假裸模型、输入绑定、独立人标、转化/结算与夸大分母拒绝。

## 网关复核

最初独立8/8通过：可信 constructor 注入同 Core/tenant/owner/company/current device、本机 scope_guard 与严格 lead_access；六action实际路由，原成功与重放回执不入 generic receipts；generic CoreError 发生于成功commit后保持409/None/execution_started、不回显raw并可原status恢复；显式未知proof；末尾设备变化回滚；过期允许历史与已有批次本机标注但拒新create、disabled主体拒；同ID role变化/换设备旧batch拒；缺记录原action墓碑阻迟到；资源角色不能借另一owner的原评论，客户端items拒。

追加最难边界：service.execute 已提交后、网关 public 投影前，server.company 被替换。真实初红显示旧结果仍返回；需要最后核验本机当前企业/actor/device，且已进入服务的结果未知不能被外层重分类为 mutation_committed=false。原create红实际跑到；初红时后续get子场景因首个断言停止，修复后再验证。日志 intent-quality-gateway-independent-final-scope-red.txt。

最终网关重跑与源码冻结结果见本报告末尾及 intent-quality-independent-source-hashes.json；若生产源随后变化，只有哈希匹配的状态可宣称对应验证。后端原23/23是独立本机实现验收，本报告网关和UI计数另记，不重叠相加成更多真实经营成果。

## 最终确认

根代理在 QUALITY/COMPANY 的 execute 返回后、HTTP public 投影前增加当前本机scope/company及当前保存actor的复核。第9原红测试已通过，实际执行 create成功提交后变更企业→网关409/None→回原企业status恢复成功，以及 get返回前企业变更→不返回旧原文两个子场景。最终网关9/9通过（intent-quality-gateway-independent-final.txt）；界面6/6通过；新后端23/23通过且原冻结SHA保持不变。

独立网关测试与界面测试到此冻结，生产源仍只由根代理修改。准确源码 SHA256 已保存 intent-quality-independent-source-hashes.json；表述只限本次合成、无外部动作的验证，尚未证明真实AI标注准确率、客户转化、资源到达、订单或到账。
