# 公司交接按原动作与原编号核对：窄切片选型

2026-10-10。先只读选型，随后主窗口明确授权D实施云候选，本agent继续独审。本文保留选型与旧repo探针的阶段来源；新API独审结论见`handoff-operation-receipt-independent-review.md`。没有实施显式发送、自动恢复或任何真实云动作。

## 范围与既有事实

只增加公司交接**只读原回执核对**，不同时展开本机outbox、register/submit按钮、资源部入口、联系方式跨机或财务体系。复用当前`handoff-ledger.cjs`与`service.cjs`的可信session、company和成熟repos；不引入新库、迁移或第二回执账本。

原写事务已经同时保存`operation:<hash([companyId,actor.username,originalAction,key])>`，记录仅有`{actor,operation,payload_hash,channel_id,revision}`。原payload、原快照、original key明文、时间与结果正文不在此文档。`event:channel:revision`包含actor/operation/occurred_at/status/previous_hash/snapshot_hash/chain_hash。current channel有最新状态、当前同意及留存历史receipt。

现有同key写重放读取**current item**，丢register响应时客户端尚无channel_id，无法只读detail；随机换key可能重复创建。新接口填这个窄缺口。原动作7项：channel_register、handoff_submit、handoff_receipt、handoff_review、handoff_withdraw、handoff_dispute、handoff_order_link（均带`acquisition_`前缀）。

## 窄契约，已与D最终schema对齐

`acquisition_handoff_operation_status`仅允许标准`environment_id/operation`与`operation_action/idempotency_key`。original action限定上述7写动作，key沿现8–128字符规则；禁止payload/owner/actor/channel/公司角色/时间/金额。opdoc key必须由当前重新鉴权session actor及固定company派生，admin不能靠payload查询另一员工原key。

标准envelope内建议`operation_receipt`：

```text
contract = handoff_operation_receipt_v1
read_only = true; storage_scope = company_server_ledger
authenticated_actor; observed_at; operation_action; idempotency_key
state = recorded | unknown
original_execution_confirmed = true | null
original_operation = null | {
  payload_hash, channel_id, revision, historical_status, occurred_at,
  historical_event_self_hash_verified:true,
  full_historical_chain_verified:false
}
current_handoff = null | {
  channel_id, revision, status, current_consent_valid,
  historical_resource_receipt_recorded,
  receipt_evidence_independently_verified:false
}
mutation_committed:false // 仅指本次只读查询，绝不指原写动作
auto_retry:false; platform_delivery_verified:false; settlement_active:false
financial_receipt_verified:false; cooperation_policy_verified:false
verified_cash_cents:null; verified_paid_commission_cents:null
```

key/action顶层供本机严格绑定，payload_hash仅一致性摘要，不授权。返回白名单必须固定；不原样输出`publicItem`（它包含source UID/contact/consent refs等原记录），不返回source正文、号码、凭据或private规则。该窄接口未校完整来源→本机交接映射，不能声称exact correspondence。

opdoc缺失200 `unknown/null`，包括旧历史无索引、另一actor相同key、记录丢失；**不等于原写未提交**。不能登记取消墓碑、释放预留、换key或自动重放。typed/generic查询错误仅表示当前只读未完成；不得输出`original_execution_confirmed:false`，也不要把`mutation_committed:false`错当原写未commit。旧key无法追溯维持hold。

## 历史与当前分别核对

存在opdoc必须严格校actor/op/64hex payload_hash/合法channel/revision；register可额外校确定性channel_id。读取原revision audit，校channel/revision/actor/op及事件自hash，再用server-only`readBoundItem`读取当前channel/最新audit/同意撤回账本与当前可见性。

历史原revision3的accept可以仍为recorded；current revision4已withdrawn、current consent=false。不能把历史ACK抹成从未接收，也不能用它继续交付。当前receiver映射撤回/停用/会话过期或公司变更仍拒绝读，旧回执不是永久权限。商业套餐到期不阻止有权成员核对历史。

现有event只留原snapshot_hash，没有全部原快照；直接读取原event自hash与当前最新audit，不代表完整中间历史chain均已核验。即使单event可校，也必须`full_historical_chain_verified:false`，不包装为独立证据、平台送达或现金/分成支付。损坏op/audit/current数据应安全409/503，不降为空或未提交。

最终全部await之后重新验证session/user角色、company、当前receiving/managing可见性，再次readBoundItem核revision/last_event_hash/current同意一致；callback重放只能重复读取，不能新建audit/index或repair旧账。

## SDK预算与已做的最小代表

独占`audits/handoff-original-key-read-probe.cjs`使用**既有实际createService/createStore与SDK接口兼容隔离adapter手工双callback夹具**，setup只造合成source→register→submit→另一主体accept→customer_withdrew；随后只调用既有repo.get/readBoundItem，不是假status返回，也不是生产新API已接；未执行node-sdk内部事务引擎或真实云事务。

`node work/product-upgrade-20261009/audits/handoff-original-key-read-probe.cjs`退出0。7个读取探针：有当前授权2个，各callback **9读0写**；撤回后3个，各 **7读0写**（同意false短路）；不存在原key/错误actor同key2个，各 **2读0写**。每探针前后全合成map不变，历史revision1/2/3仍可读，revision3 accepted与current revision4 withdrawn/consent false并存。

9包括company1+op1+原audit1+前后currentBound各3。本旧probe未实测新API的首dispatch；最终独审新API实测独立dispatch为1读0写，详见新报告及budget JSON。不得将不同事务的操作数加成单回调或把双重callback执行次数当独立用例。SDK100操作/30秒/doc-only限制沿主窗口既有官方核对；隔离adapter不能证明实际SDK引擎行为、真实云延迟、线上30秒或吞吐。

特别注意`createService`共有dispatch会过滤过期sessions/devices/attempts，`createStore`会在JSON变化时写公司doc。新只读status可以仅此dispatch返回`state:stored`，保留auth检查但不借查询触发housekeeping回写；不要为此改其它现有动作。新helper不set任何doc或修复缺失记录。

## 新API实施后的必要独审

独审需直接用最终createService/createStore路由与真实SDK fixture：原写commit后响应丢失/重启仅status、zero business writes；7个写动作白名单；missing/旧历史/跨actor/company；篡改op/audit/currentchannel；最后doc await时撤session/receiver/company；商业过期不封历史；SDKcallback重放/权限终审及最坏读计数。不能把本probe当新API绿，不能用双方各自stub合同代替实际路由。

当前方案来源SHA：handoff-ledger `16A544D72C9DB6E0597E3016C4433216D3B7824E4980FB5638A45166BC04A305`；service `17D21D918D3E17559AA48E3F6DB342FC86DE112172B4DB8D9043E016AA0412A7`；index `223A150519F3BCACE360D35BBDAF876DEEAB74AF426D415A3DF3B259DA2AFF1B`。D新源落盘后它们转为历史来源快照，不能沿用为新API最终验证。无部署、网络、平台或真实数据/角色动作。
