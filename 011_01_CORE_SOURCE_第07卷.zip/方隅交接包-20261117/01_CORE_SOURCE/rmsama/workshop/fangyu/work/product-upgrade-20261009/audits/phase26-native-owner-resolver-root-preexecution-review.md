# Root 单次良性 TokenUser 代表：执行前审核

已读四个最终候选源、D 候选报告、既有 current_windows_sid 和 frozen benign probe 的实际 guard。选用成熟 Windows TokenUser 查询，只查询固定项目 pythonw 的良性 sleep 子进程；同一个 HANDLE 的原创建时间、运行状态、两个完整 CIM 快照、Job membership、固定 runtime/argv 和末核必须相符。整机行数与摘要只作观察，不凭无关进程变化授权原 profile。

原数据、账号、DPAPI、SQLite、浏览器、CLI、平台和云均不进入本代表。SID/PID/命令行/令牌原值不落盘。失败保留 unknown；verified 只证明固定良性进程的 token user，不证明原浏览器启动、小红书 UID、账号恢复或 profile 空闲。

本次执行前再次核对 resolver 9770E572、父 F31D90C3、sleep 6B88F3B6、PS 8E089C5D 四个完整冻结 SHA。仅允许此唯一 GUID 的 Interactive/Limited、无 trigger 任务启动一次；结果保留后只清理本次 owned scheduler 任务。旧 7/4/867B/v2 trace 不修改，不重复运行原账号诊断。
