# 下一经营缺口：按来源客户核对订单、实收与分成

结论：下一项优先功能应是“经营结果对账”。把现有来源客户及交接编号连接到公司权威订单、客户实收/退款、应付分成和实际分成支付的各自凭证，并显示缺失、冲突与核验层级。它是现有交接链末端的一处功能补齐，不是另造完整CRM，也不是把高意向、资源部ACK或计算出来的佣金当成到账。

本轮只读项目需求台账、主链路代码和既有审计。仅新建本报告；R23 intent_quality_review.py/23测试的冻结未动。没有读取原库、真实客户、账号、Cookie、凭据或云，未运行真实平台、付款、发消息或部署。这里的代表路线是下一批验证建议，尚未实现、未运行其测试，也不构成商用验收。

## 适用能力及经营判断

先评估当前可用的 RevOps、归因/转化QA、数据验证等目录，本轮最小主能力选 RevOps，实际读取 C:/Users/rmsama/.codex/skills/revops/SKILL.md。采用其阶段先定义、逐次交接要可追溯、必需字段不足不能自动推进的原则；不借用其中一般行业转化率、速度倍数或价格基准作为公寓试点承诺。三个产品营销上下文入口均不存在，未为缺文件阻塞工作。并行只读子审使用 conversion-signal-qa 检查本机四模块，结论独立一致；不把Skill目录评估说成全目录执行。

目标用户当前是本人中介/顾问，合作方是资源部及有权业务/财务人员。流量入口为许可允许的评论来源；承接动作为实际联系、客户回应与用途/接收方明确的同意；交付成功是资源部独立接受，而商业结果还需独立订单、收款及分成事实。先按小批和结算期核对，缺基线不订每日客户量或成交比例；身份/权限/订单客户冲突、来源未知或未核实款项出现时暂停把该条当成功，不扩大外部动作。

## 现状与准确证据

当前《需求交付与证据台账》R03/R07/R12/R21明确公司CRM、第二机器及真实资源部接收待接入，R23仍列逐词空模板与待真实经营记录。本轮新增软件意向抽检已独立完成23项后端、9项网关与6项轻DOM实际模块验证，不能因台账尚在收尾就把抽检错误列为下一项未实现功能；根代理需在最终文档同步本轮状态。抽检也不能代替任何一个成交事件。

准确源码入口，均相对当前项目：

|链段|现有实现|实际可以证明与限制|
|---|---|---|
|高意向与人审|work/app/src/assistant/intent_quality_review.py|固定评论的保存软件输出与独立人标；当前source/AI版本及context stale；不是本人会成交|
|联系/回应|work/app/src/assistant/customer_list.py 的 _build；customer_response_monitor.py 的 _queue_matched_responses（342）|有精确评论目标/发送记录/作者/时间的回应匹配，unobserved不是确实没有回应；真实回流仍待验|
|客户同意|work/app/src/assistant/acquisition_contacts.py 的 _view（86）|operator_recorded/independently_verified=false；本机加密归属核对不独立证实本人同意真实性|
|本机资源部登记|work/app/src/assistant/acquisition_operations.py 的 _receipt（667）、_read（696）|另一授权主体可登记，但source=authorized_local_principal、delivery=acknowledged_locally、cross_machine_verified=false；revenue/settlement=null|
|公司服务器独立ACK候选|work/cloud/workspace/handoff-ledger.cjs 的 mutate（125），receipt分支（137）|可信不同session、指定receiver、版本、同意与事件链；resource_receipt_auth_verified只证明另一认证主体登记，evidence_independently_verified=false；未部署/未真实试点|
|已有订单及审核|work/cloud/workspace/contact_ledger.cjs 的 contact_deal_report（537）、contact_deal_review（581）|可保存订单/金额/退款及管理员审核、修订历史；订单登记是账号报告。该review分支没有在本处分离“登记人不能自审”的门禁；不能直接标独立财务核验|
|来源到订单候选|work/cloud/workspace/handoff-ledger.cjs 的 acquisition_handoff_order_link分支（164）|需独立有权actor、accepted+有效授权、相同customer、当前order_revision，并防同订单关联另一渠道；只关联，不读取支付凭证或改变旧订单|
|应付佣金计算|work/cloud/workspace/contact_ledger.cjs 的 commission（165）|按审核状态、配置政策、first_sent_at与归属窗口计算amount-refund的公式；calculated是计算结果，缺actual receipt/payment proof，不能当实收或实付|
|现有导出|work/app/src/assistant/acquisition_exports.py 的 _row（78）|现成脱敏XLSX/CSV和来源核对码可复用；成交/结算列明确“未接入公司订单核验/真实结算”。导出不是送达或独立ACK|

此外，对 work/app/src 的当前 Python/ESM 搜索未发现 contact_deal_report/review 或 acquisition_handoff_order_link 的工作台调用接线。已存在的服务器候选与本机六页经营流程之间还有桥接，不能声称该完整链已经开放给使用者。

## 为什么选这一处

“筛出了多少高意向”最多证明软件筛选有用；“资源部收到多少”能证明交付有用；双方继续合作、确认分成及防止换渠道抢单，需要回答哪位客户、哪张订单、收了多少、按哪版协议应付、是否已付。当前代码已经有安全来源与独立接收/订单关联的底座，最缺的是末端权威事实和可查看的逐条对账。只添更多菜单或手工成交按钮会令记录更丰富，却仍不能支撑这几个问题。

真实许可、账号恢复、实际回应和跨机器资源部业务试点仍是外部门，不因该功能被写出来而自动满足。若公司尚不使用完整软件，可先从其现有有权订单/财务系统的脱敏只读导出验证一条；回来的Excel由来源本人导入，只能先记“合作方报告待核对”，不能自动升为独立资源部/财务确认。独立有权主体的认证、可核验权威来源及审批仍需真实合作约定。

## 增量路线与最小字段

优先复用 contact_ledger.repoFor/交易入口、deal修订历史、handoff事件与order唯一关联、本机scope/owner门禁、成熟一次事务+原号未知核查、acquisition_exports 的XlsxWriter 3.2.9/CSV字面量及隐私投影。现有能力足以做代表性端到端适配，不增一套通用CRM、工作流平台或新数据库。

只查阅项目现有开源核查报告（2026-09-22快照）；其中CLI、客服和通用工作流候选不直接解决企业订单/银行回款真实性。此次没有重新联网核对仓库维护或许可，也未安装候选，不能据旧快照声称某新CRM已合适或已集成。完成代表链后若现有模块确实不足，再按真实系统选官方适配或成熟组件；不要把整套CRM迁移放在小批证明之前。

一条核对记录至少固定以下来源绑定，服务端按已存记录派生actor/公司/时间/范围，不信任前台填写“已核验/已到账”布尔值：

|组|最小内容|不能替代|
|---|---|---|
|链身份|company、source/customer UID的可信绑定、handoff/channel ID、原确认版本|昵称相似、手机号猜配、另店客户或客户端自报owner|
|订单事实|external_system+order_no、customer映射依据、order_revision、签约/取消状态、受限证据引用及版本摘要|订单号格式符合、随手粘贴reference、仅link成功|
|客户收款|来源系统/账户范围、稳定收款流水编号、发生时间、币种、金额、当前处理状态、原凭证摘要|订单金额或管理员点确认|
|退款|稳定退款编号、关联原流水、金额/币种/时间、版本与冲销依据|简单覆盖旧成交金额；不同币种硬相减|
|应付分成|双方核对的合作政策版本、计算基数/窗口、可追溯订单与净实收、政策状态|自行预设单价/比例，或旧通用commission公式直接当合同|
|实际分成支付|稳定支付流水、应付分成关联、收款主体范围、币种/金额/时间及凭证|应付数字、客户给公寓付钱、付款申请或待处理交易|

先仅一种明确币种、一个订单、一个收款和一个退款、一次分成支付；不作汇率换算。一个客户可有多张订单，不能按评论重复计算成交。一个流水分配多订单时需总分配不超过流水金额，不因关联行数重复计算现金。合作政策缺失、支付来源未接入或事实缺项保持null/待核验；确有经核验退款后净额为0时才显示真实0，不能用缺数据凑0。

界面只有一个“经营结果对账”入口，从现有交接详情打开：左边来源/发送/回应/同意/ACK时间线，右边订单、客户收款、应付分成、实际分成支付四个独立证据块。每块显示“未接入/已登记待核对/有权独立核对/权威系统回执”及当前版本、冲突/撤销；平台来源未独立验证、同意operator_recorded也继续显示，不能由末端有钱倒填前段证据。由谁核对与证据源层级必须可见。

最小API以有权现存来源引用开始，避免客户端传原文、联系人、余额、任意文件路径或可信actor：

1. 只读 detail：handoff/channel ID，返回当前有权摘要、证据层级和缺失项；商业权益过期不阻合法历史核查。
2. 导入/适配 preview：服务端可读取的有权来源引用+预期版本，返回owned preview_id、归一字段摘要、匹配/冲突/缺失。签名/issuer/文档权限未校验时只能reported，禁止verified。
3. 独立有权确认：preview_id+expected_revision+稳定key，只接受原服务端预览，并在同事务重新检查主体/企业/来源/订单/流水/政策版本、去重、审计与成功回执。作者本人不是“另一人核验”；没有合适财务角色时停在reported。
4. 原操作status：原action+key。未知保存保留原key，查成功或取消墓碑；缺记录的取消副作用明确，绝不自动重放或发起付款。

这四项是建议收紧的接口方向，不是本轮已落盘的契约。外部接口读取发生在SQL/云事务之外；可信读取结果先冻结owned receipt，再在事务内核验引用，沿用已验证的未知结果机制。

## 最难代表验证与推进门

先在项目隔离合成fixture验证实际入口，不触碰原数据：来源本人A、独立receiver B、独立财务核对人C，一条可信comment/customer→发送/回应证据→明确同意→独立ACK→已存在同customer的订单→公司账款/退款→政策版本→分成实付。断在任一阶段，下一格都不能被连带标通过。

第一组最难红绿：同企业相同订单/流水号却换customer或渠道，必须拒绝；只有order link/commission calculated但无实收/支付，金额核验保持null；最后回执写入失败全回滚，commit后返回失败保持unknown，原status恢复；来源本人或登记人自审不得标独立；事务及返回前换企业/角色/设备均拒，已commit不能误标未提交。

通过后才扩到重复点击/跨设备双人相同事件幂等、退款及政策变更、部分实收、部分分成支付、一个流水多订单防重计、撤销与修订保留历史、已撤联系方式授权不解锁联系信息、旧单财务历史是否可看由独立权限决定、同币种真实0与缺失null、导出公式注入/受限引用不泄露、只读聚合分母按客户而非评论。第二机器实测、权威系统接入和真实业务认可另立门。

真实小批需要公司给出有权的脱敏订单/回款/分成样本、receiver及财务核对人/用途范围、合作规则版本。没有这些输入，不伪造验收，不代公司赋权，不上传或发送客户资料。一次真实链经双方认可后再谈批量吞吐、员工开放与定价；这比“所有账户跑通”或显示更高的模型分数更接近当前合作目标。

## 本轮来源快照

检查时SHA256：需求台账 FBBE1F9CF9BC515989349612DD1F0AD908C4F42926EE0CC658CA5DDF6839945A；acquisition_operations.py AD9123D3373C484679A3CE34580149E25DCF8045DC1332CF6D166A6BCAAC0C2D；acquisition_contacts.py 073D4816D292A8AD2821C22CCCC5FE7BF1FC45BD3C10745908C0704D3D3C222C；acquisition_exports.py B41BB719972020ED790ED937185201E1130C260CE8DCDF9E5D9FDB2287A21731；customer_list.py 72428ECAC3A6414F5F661BE583DA47D965B205A2284CE74D7A75902C9FD8EB36；contact_ledger.cjs 16041C470D45E560670C8F1804AA96C5E03169CF91D2F06D67CF6DA18B2C7607；handoff-ledger.cjs FD6A6C942C76DB5BEB5B06BDAA18CE9E6E7CBC0C4C2682DF9899D457BE51856B。台账由根代理收尾更新时可能变化，本报告记录的是检查时状态。

报告路径：C:\积木软件工坊\项目\方隅公寓客户版\work\product-upgrade-20261009\audits\next-business-gap-reconciliation.md

所在文件夹：C:\积木软件工坊\项目\方隅公寓客户版\work\product-upgrade-20261009\audits
