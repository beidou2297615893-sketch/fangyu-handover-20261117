"""Inventory the fixed guarded CLI as data, never load its modules or execute it.

Uses the installed PyInstaller archive readers and pefile only as static parsers.
Writes one new audit JSON outside the frozen runtime; does not accept paths.
"""
import sys
sys.dont_write_bytecode = True

import ast
import dis
from email.parser import Parser
import hashlib
import importlib.metadata
import json
import marshal
from pathlib import Path
import re
import stat
from types import CodeType
import zipfile

from PyInstaller.archive.readers import CArchiveReader
import pefile

PROJECT = Path(__file__).resolve().parents[3]
AUDITS = Path(__file__).resolve().parent
RUNTIME = PROJECT / 'work/app/work/runtime/platform-cli-guarded'
MATERIALS = PROJECT / 'work/app/src/resources/licenses'
OUTPUT = AUDITS / 'phase18-guarded-cli-dependency-inventory.json'
PINNED = {
    'wrapper': '2580bd579de76191a5bfd33109c612287f19c94bc55dc10fb64873a31676bb31',
    'exe': '5697bfbbeee13e4572f4fa47d4f5bec829bea278403c2da323cb9ffa7b3c648b',
    'tree': 'c7da4bb61f8c95e38490def1a0078d81d4dcc16630060bcb671a53f1a05ee621',
    'guard': 'eb007b5d293e2a880ae479207c18edcc2aa85398fada01d2f57040fb09c716f5',
}
NOTICE_NAME = re.compile(r'license|licence|copying|notice|copyright', re.I)
NOTICE_MARKERS = {
    'copyright': re.compile(r'\bcopyright\b', re.I),
    'spdx_identifier': re.compile(r'SPDX-License-Identifier\s*:', re.I),
    'permission_grant': re.compile(r'Permission is hereby granted', re.I),
    'redistribution_terms': re.compile(r'Redistribution and use', re.I),
}
MODULE_TO_DISTRIBUTION = {
    'Crypto': 'pycryptodome', 'yaml': 'PyYAML', 'markdown_it': 'markdown-it-py',
    'xhs_cli': 'xiaohongshu-cli', 'pygments': 'Pygments',
    '_distutils_hack': 'setuptools', 'distutils': 'setuptools',
}


def sha(path):
    digest = hashlib.sha256()
    with path.open('rb') as source:
        for chunk in iter(lambda: source.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()


def rel(path, root=PROJECT):
    resolved = path.resolve()
    if not resolved.is_relative_to(root.resolve()):
        raise ValueError('Audit input/output escaped the fixed project root')
    return path.relative_to(root).as_posix()


def normalize(name):
    return re.sub(r'[-_.]+', '-', name).lower()


def load_tree_hasher():
    source = PROJECT / 'work/app/src/core/runtime_guards.py'
    parsed = ast.parse(source.read_text(encoding='utf-8'))
    function = next(item for item in parsed.body if isinstance(item, ast.FunctionDef)
                    and item.name == 'cli_runtime_tree_sha256')
    namespace = {'Path': Path, 'hashlib': hashlib, 'stat': stat}
    exec(compile(ast.Module(body=[function], type_ignores=[]), str(source), 'exec'), namespace)
    return namespace['cli_runtime_tree_sha256'], sha(source)


def notice_signals(text):
    return {name: [index + 1 for index, line in enumerate(text.splitlines())
                   if expression.search(line)][:20]
            for name, expression in NOTICE_MARKERS.items()
            if expression.search(text)}


def module_versions(code):
    """Inspect simple version assignments without executing any code object."""
    instructions = list(dis.get_instructions(code))
    result = []
    for previous, current in zip(instructions, instructions[1:]):
        if (previous.opname == 'LOAD_CONST' and current.opname in ('STORE_NAME', 'STORE_GLOBAL')
                and current.argval in ('__version__', '__version_info__')
                and isinstance(previous.argval, (str, tuple))):
            value = previous.argval
            if isinstance(value, tuple) and all(type(item) is int for item in value):
                value = '.'.join(map(str, value))
            if isinstance(value, str) and len(value) < 100:
                result.append({'value': value, 'assignment': current.argval,
                               'instruction_offset': current.offset,
                               'literal_does_not_prove_executed_value': True,
                               'conditional_or_fallback_not_excluded': True})
    return result


def metadata_record(info):
    metadata = info / 'METADATA'
    value = Parser().parsestr(metadata.read_text(encoding='utf-8'))
    declared = value.get('License-Expression') or value.get('License')
    return {
        'name': value.get('Name'), 'version': value.get('Version'),
        'metadata_path': rel(metadata, RUNTIME), 'metadata_sha256': sha(metadata),
        'declared_license': declared[:2048] if declared else None,
        'license_declaration_truncated': bool(declared and len(declared) > 2048),
        'declared_license_files': value.get_all('License-File', []),
        'requires_dist_declarations': value.get_all('Requires-Dist', []),
        'requires_dist_proves_containment': False,
        'actual_notice_files': [rel(item, RUNTIME) for item in info.rglob('*')
                                if item.is_file() and NOTICE_NAME.search(item.name)],
        'version_evidence': 'runtime_dist_info_metadata',
    }


def native_record(path):
    fields = {}
    try:
        binary = pefile.PE(str(path), fast_load=True)
        binary.parse_data_directories(directories=[pefile.DIRECTORY_ENTRY['IMAGE_DIRECTORY_ENTRY_RESOURCE']])
        for group in getattr(binary, 'FileInfo', []):
            for entry in group:
                for table in getattr(entry, 'StringTable', []):
                    for key, value in table.entries.items():
                        key = key.decode('utf-8', 'replace') if isinstance(key, bytes) else key
                        if key in ('CompanyName', 'ProductName', 'ProductVersion', 'FileVersion', 'LegalCopyright'):
                            fields[key] = value.decode('utf-8', 'replace') if isinstance(value, bytes) else value
        binary.close()
        error = None
    except (OSError, pefile.PEFormatError, AttributeError, TypeError):
        error = 'version_resource_unavailable'
    return {'path': rel(path, RUNTIME), 'sha256': sha(path),
            'pe_version_resource': fields, 'resource_error': error,
            'copyright_resource_is_license_approval': False}


def existing_materials(distribution, metadata_versions, literal_versions):
    entries = json.loads((MATERIALS / 'DEPENDENCIES.json').read_text(encoding='utf-8'))
    result = []
    for row in entries:
        if normalize(row.get('name', '')) != normalize(distribution):
            continue
        files = []
        for relative in row.get('copied_license_files', []):
            path = MATERIALS / relative
            if not path.resolve().is_relative_to(MATERIALS.resolve()):
                raise ValueError('External material candidate escaped its fixed root')
            if path.is_file():
                files.append({'path': rel(path), 'sha256': sha(path)})
        result.append({'name': row.get('name'), 'version': row.get('version'),
                       'declared_license': row.get('license_expression'),
                       'inventory_record_status': row.get('status'), 'files': files,
                       'runtime_metadata_version_matches': row.get('version') in metadata_versions,
                       'static_literal_version_matches': row.get('version') in literal_versions,
                       'contained_in_runtime': False,
                       'status': 'external_runtime_metadata_matched_candidate'
                                 if row.get('version') in metadata_versions else
                                 'external_static_literal_matched_unverified_candidate'
                                 if row.get('version') in literal_versions else
                                 'external_version_unbound_candidate',
                       'license_approved': False})
    return result


def main():
    if len(sys.argv) != 1:
        raise ValueError('This audit accepts no paths, account IDs or execution parameters')
    rel(RUNTIME); rel(OUTPUT)
    tree_hasher, tree_helper_sha = load_tree_hasher()
    actual = {'wrapper': sha(PROJECT / 'work/app/src/platform_cli.py'),
              'exe': sha(RUNTIME / 'platform-cli.exe'), 'tree': tree_hasher(RUNTIME),
              'guard': sha(RUNTIME / 'guard-manifest.json')}
    if actual != PINNED:
        raise ValueError('The fixed runtime changed; do not inventory another build silently')

    physical = []
    named_notices = []
    source_notices = []
    native = []
    for path in sorted(item for item in RUNTIME.rglob('*') if item.is_file()):
        row = {'path': rel(path, RUNTIME), 'bytes': path.stat().st_size, 'sha256': sha(path)}
        physical.append(row)
        if NOTICE_NAME.search(path.name):
            named_notices.append(dict(row, signal='named_notice_file'))
        if path.suffix in ('.py', '.pyi', '.txt', '.md', '.toml') and path.stat().st_size <= 512*1024:
            signals = notice_signals(path.read_text(encoding='utf-8', errors='replace'))
            if signals:
                source_notices.append(dict(row, signals=signals, completeness_verified=False))
        if path.suffix.lower() in ('.dll', '.pyd'):
            native.append(native_record(path))

    metadata = [metadata_record(info) for info in sorted(RUNTIME.rglob('*.dist-info'))
                if info.is_dir() and (info/'METADATA').is_file()]
    archive = CArchiveReader(str(RUNTIME/'platform-cli.exe'))
    carchive = [{'name': name, 'typecode': entry[-1], 'stored_bytes': entry[1],
                 'uncompressed_bytes': entry[2]}
                for name, entry in sorted(archive.toc.items())]
    modules = []
    versions = []
    embedded_notices = []
    for archive_name, entry in archive.toc.items():
        if entry[-1] != 'z':
            continue
        pyz = archive.open_embedded_archive(archive_name)
        for name, descriptor in sorted(pyz.toc.items()):
            raw = pyz.extract(name, raw=True)
            row = {'name': name, 'archive': archive_name, 'typecode': descriptor[0],
                   'raw_bytecode_sha256': hashlib.sha256(raw).hexdigest() if raw is not None else None}
            modules.append(row)
            if raw is None:
                continue
            code = marshal.loads(raw)
            if not isinstance(code, CodeType):
                raise ValueError('Expected a code object in the fixed PYZ archive')
            for literal in module_versions(code):
                versions.append(dict(literal, module=name, evidence='embedded_static_assignment',
                                     bytecode_sha256=row['raw_bytecode_sha256']))
            for index, value in enumerate(code.co_consts):
                if not isinstance(value, str):
                    continue
                signals = notice_signals(value)
                if signals:
                    embedded_notices.append({'module': name, 'constant_index': index,
                                             'literal_sha256': hashlib.sha256(value.encode('utf-8')).hexdigest(),
                                             'signals': signals, 'completeness_verified': False})

    base_zip = RUNTIME/'_internal/base_library.zip'
    with zipfile.ZipFile(base_zip) as bundle:
        base_entries = [{'name': name, 'bytes': bundle.getinfo(name).file_size,
                         'sha256': hashlib.sha256(bundle.read(name)).hexdigest()}
                        for name in sorted(bundle.namelist())]

    roots = sorted({row['name'].split('.')[0] for row in modules})
    third_party_roots = [name for name in roots if name not in sys.stdlib_module_names
                         or name == 'distutils']
    component_names = list(third_party_roots)
    # Vendored namespaces are still contained components, not standalone distributions.
    vendor_prefixes = set()
    for row in modules:
        name = row['name']
        if name.startswith('setuptools._vendor.'):
            parts = name.split('.')
            if parts[2] in ('jaraco', 'backports') and len(parts) < 4:
                continue  # Namespace containers do not create additional distribution rows.
            prefix = '.'.join(parts[:4] if parts[2] in ('jaraco', 'backports') else parts[:3])
            vendor_prefixes.add(prefix)
    component_names.extend(sorted(vendor_prefixes))
    components = []
    for namespace in component_names:
        root = namespace if namespace not in vendor_prefixes else namespace.removeprefix('setuptools._vendor.')
        distribution = MODULE_TO_DISTRIBUTION.get(root, root.replace('_', '-'))
        observed_versions = [row for row in versions if row['module'] == namespace
                             or (row['module'].startswith(namespace+'.')
                                 and row['module'][len(namespace)+1:].split('.')[0]
                                 in ('_version', '__version__', '__about__', 'version', 'package_data'))]
        actual_meta = [row for row in metadata if normalize(row.get('name') or '') == normalize(distribution)]
        metadata_versions = sorted({row['version'] for row in actual_meta if row['version']})
        literal_versions = sorted({row['value'] for row in observed_versions})
        version_values = metadata_versions or literal_versions
        component_modules = [row['name'] for row in modules if row['name']==namespace
                             or row['name'].startswith(namespace+'.')]
        components.append({'namespace': namespace, 'distribution_name_candidate': distribution,
                           'association_basis': 'explicit_common_module_mapping_or_normalized_namespace',
                           'version_values': version_values,
                           'runtime_metadata_version_values': metadata_versions,
                           'static_literal_version_values': literal_versions,
                           'version_state': 'runtime_metadata' if actual_meta else
                                            'embedded_static_literal_unverified' if observed_versions else 'unavailable',
                           'static_literal_can_be_conditional_fallback': True,
                           'version_evidence': observed_versions,
                           'runtime_metadata_paths': [row['metadata_path'] for row in actual_meta],
                           'module_count': len(component_modules), 'modules': component_modules,
                           'vendored': namespace in vendor_prefixes,
                           'runtime_named_notices': [path for row in actual_meta for path in row['actual_notice_files']],
                           'external_material_candidates': existing_materials(distribution, metadata_versions, literal_versions),
                           'license_approved': False})

    if any(name=='xhs_cli' or name.startswith('xhs_cli.') for name in sys.modules):
        raise ValueError('Target CLI was imported; refuse this audit')
    after = {'wrapper': sha(PROJECT/'work/app/src/platform_cli.py'),
             'exe': sha(RUNTIME/'platform-cli.exe'), 'tree': tree_hasher(RUNTIME),
             'guard': sha(RUNTIME/'guard-manifest.json')}
    if after != actual:
        raise ValueError('Runtime changed during the static inventory; output withheld')
    value = {
        'schema_version': 1, 'kind': 'actual_frozen_guarded_cli_dependency_inventory',
        'runtime_path': rel(RUNTIME), 'artifact': actual, 'runtime_unchanged': True,
        'purpose': 'internal_qa_only', 'tree_hash_helper_sha256': tree_helper_sha,
        'generator_sha256': sha(Path(__file__)),
        'reader_provenance': {
            'PyInstaller_version': importlib.metadata.version('PyInstaller'),
            'pefile_version': importlib.metadata.version('pefile'),
            'PyInstaller_reader_sha256': sha(PROJECT/'work/desktop-python/Lib/site-packages/PyInstaller/archive/readers.py'),
            'external_dependency_material_manifest_sha256': sha(MATERIALS/'DEPENDENCIES.json'),
            'external_dependency_material_manifest_is_runtime_inventory': False,
        },
        'scope': 'fixed physical payload plus actual EXE CArchive/PYZ and base_library.zip',
        'method': {'parser': 'installed PyInstaller CArchiveReader/ZlibArchiveReader; static TOC/data only',
                   'target_code_executed': False, 'target_modules_imported': False,
                   'marshal_used_for_static_const_inspection': True,
                   'original_account_cookie_database_read': False, 'network_called': False,
                   'runtime_modified': False,
                   'external_materials_are_containment_proof': False},
        'summary': {'physical_files': len(physical), 'physical_bytes': sum(row['bytes'] for row in physical),
                    'runtime_dist_info_records': len(metadata), 'named_notice_files': len(named_notices),
                    'source_files_with_notice_markers': len(source_notices),
                    'embedded_modules': len(modules), 'embedded_notice_literals': len(embedded_notices),
                    'third_party_roots': len(third_party_roots), 'vendored_namespaces': len(vendor_prefixes),
                    'base_library_entries': len(base_entries), 'native_binaries': len(native),
                    'components_without_version_literal_or_metadata': sum(not row['version_values'] for row in components),
                    'components_without_runtime_distribution_metadata': sum(not row['runtime_metadata_paths'] for row in components)},
        'physical_files': physical, 'runtime_metadata': metadata,
        'named_notice_files': named_notices, 'source_notice_markers': source_notices,
        'carchive_entries': carchive, 'embedded_modules': modules,
        'embedded_version_literals': versions, 'embedded_notice_literals': embedded_notices,
        'python_stdlib_reference_version': sys.version.split()[0],
        'python_stdlib_classification': 'name comparison only; not license/byte identity approval',
        'stdlib_namespaces': [name for name in roots if name not in third_party_roots],
        'components': components, 'base_library_entries': base_entries, 'native_binaries': native,
        'materials_complete_verified': False, 'commercial_use_review_decision': 'not_reviewed',
        'distribution_approved': False,
        'missing_files_implies_internal_use_prohibited': False,
    }
    OUTPUT.write_text(json.dumps(value, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    print(json.dumps({'output': rel(OUTPUT), 'artifact': actual, 'summary': value['summary'],
                      'version_gaps': [row['namespace'] for row in components if not row['version_values']],
                      'runtime_unchanged': True}, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
