"""Root-only Source45 UI join; reuses the reviewed Source44 file helpers."""
from pathlib import Path
import ast
import hashlib
import json
import os
import stat
import sys
import tempfile
import uuid

PROJECT = Path('C:/积木软件工坊/项目/方隅公寓客户版')
STAGE = PROJECT / 'work/product-upgrade-20261009'
UI = PROJECT / 'work/v3-ui-approved-source44-candidate'
RECEIPT = STAGE / 'audits/ui-approved-source45-joined.json'
if os.name != 'nt' or sys.argv[1:] != ['--apply-reviewed'] or RECEIPT.exists():
    raise ValueError('Windows reviewed one-time join required')
base = STAGE / 'audits/join-source44-reviewed.py'
base_raw = base.read_bytes()
if hashlib.sha256(base_raw).hexdigest().upper() != '5F5E3EA22AF7C1FA0FEA71CFEFDA12A9D669C190D5470960901029BF8F4750FB':
    raise ValueError('reviewed file helpers changed')
# Execute only these five previously reviewed file functions, never the Source44 main.
names = {'blob', 'pin', 'expected', 'no_link_parent', 'prepared_temp'}
definitions = [n for n in ast.parse(base_raw).body if isinstance(n, ast.FunctionDef) and n.name in names]
if len(definitions) != len(names):
    raise ValueError('reviewed helpers incomplete')
exec(compile(ast.Module(body=definitions, type_ignores=[]), str(base), 'exec'), globals())
frozen = json.loads(expected(UI / 'FROZEN.json', {
    'bytes': 4341, 'sha256': '7B3E1245ECAE81EF2C02275D43F96C1BFC45B05CF8B13332F2255DFFC2DEF752'}))
review_path = STAGE / 'owner-business-reconciliation-review/V3-UI-CODE-REVIEW.md'
review = expected(review_path, {'bytes': 4364,
    'sha256': 'FFF03AA7B6CA92C8FA759E4F83F34FCFEE3EBCFB82D234307E940FBCFFFDA2D0'})
if b'PASS_LIMITED_CODE' not in review or frozen.get('formal_parent') != 'Source44':
    raise ValueError('reviewed Source44 UI input required')
if frozen.get('native_visual_comparison') is not False or len(frozen['artifacts']) != 16:
    raise ValueError('visual scope or frozen set changed')
for item in frozen['artifacts']:
    path = Path(item['path']); path.relative_to(UI)
    expected(path, {'bytes': item['bytes'], 'sha256': item['sha256']})
manifest = json.loads(blob(UI / 'SOURCE_HASHES.json'))
source = PROJECT / 'work/app/src'
pins = {
    'web/workspace/self-operating-read.mjs': (
        {'bytes': 346275, 'sha256': '7A5A84CBC059E38D7B18902467EABCE416099C2564E009A4B2D637799298133C'},
        {'bytes': 349447, 'sha256': 'C83C44CE87E4EFB4C89DFBBD2D6A0DCEFC38327FC8F3277796AE0C8FAE5A03C6'}),
    'web/workspace/upgrade-ui.css': (
        {'bytes': 92986, 'sha256': '9EB963CF2067885906FEF60B05ED7857C3E31537AE58246EFC04078661E01F0B'},
        {'bytes': 99327, 'sha256': '34A1BB3F5C5C5AED375B72FD9E573ADFCFDB10911A03E6CB7EE384489BF2296A'})}
if len(manifest['targets']) != 2 or {t['target'] for t in manifest['targets']} != set(pins):
    raise ValueError('exact two logical UI targets required')
changes = []
for item in manifest['targets']:
    name = item['target']; old_pin, new_pin = pins[name]
    target = source / name; candidate = UI / name
    if Path(item['formal']['path']) != target or Path(item['candidate']['path']) != candidate:
        raise ValueError('target path changed')
    for kind, proof in [('formal', old_pin), ('parent', old_pin), ('candidate', new_pin)]:
        if {k: item[kind][k] for k in ('bytes', 'sha256')} != proof:
            raise ValueError('reviewed target pin changed')
    before = expected(target, old_pin); after = expected(candidate, new_pin)
    changes.append((name, target, before, after))
css_old, css_new = pins['web/workspace/upgrade-ui.css']
mirror = PROJECT / 'work/cloud/workspace/site/upgrade-ui.css'
if manifest['existing_css_mirror'] != {'path': mirror.as_posix(), **css_old}:
    raise ValueError('existing CSS mirror declaration changed')
changes.append(('existing_local_css_mirror', mirror, expected(mirror, css_old),
                expected(UI / 'web/workspace/upgrade-ui.css', css_new)))
previous = json.loads(expected(STAGE / 'audits/owner-business-reconciliation-joined.json', {
    'bytes': 22611, 'sha256': '408382C42C3F8D927A6ED1C605CB8F31FC7902562C13A45C76C604F88034873D'}))
changing = {t for _, t, _, _ in changes}
protected = {Path(p): proof for p, proof in previous['protected_unchanged'].items() if Path(p) not in changing}
for record in previous['targets']:
    path = Path(record['target'])
    if path not in changing:
        protected[path] = record['candidate']
author_protected = json.loads(blob(UI / 'PROTECTED-SOURCES.json'))
for record in author_protected['unchanged_current_Source44'] + [author_protected['selected_reference']]:
    path = Path(record['path'])
    if path in changing:
        raise ValueError('protected target conflicts with change')
    protected[path] = {k: record[k] for k in ('bytes', 'sha256')}
for path, proof in protected.items():
    expected(path, proof)
backup = PROJECT / 'backups/ui-approved-source45' / uuid.uuid4().hex
backup.mkdir(parents=True)
records = []
for i, (name, target, before, after) in enumerate(changes):
    saved = backup / (str(i) + '-' + target.name)
    saved.write_bytes(before)
    if blob(saved) != before:
        raise ValueError('parent backup readback differs')
    records.append({'name': name, 'target': str(target), 'backup': str(saved),
                    'parent': pin(before), 'candidate': pin(after)})
(backup / 'PREPARED.json').write_text(json.dumps(records, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
for _, target, before, _ in changes:
    if blob(target) != before:
        raise ValueError('parent drift before staging')
temporaries = []
attempted = []
try:
    for _, target, _, after in changes:
        temporaries.append(prepared_temp(target, after))
    for (_, target, before, after), temporary in zip(changes, temporaries):
        no_link_parent(target)
        if blob(target) != before:
            raise ValueError('parent drift before replace')
        attempted.append((target, before, after))
        os.replace(temporary, target)
        if blob(target) != after:
            raise ValueError('UI target readback differs')
    for path, proof in protected.items():
        expected(path, proof)
    receipt = {'schema': 'ui_approved_source45_join', 'source_batch': 45,
        'logical_targets': 2, 'physical_targets': 3, 'targets': records,
        'protected_unchanged': {str(p): proof for p, proof in protected.items()},
        'frozen': pin(blob(UI / 'FROZEN.json')), 'review': pin(review),
        'backup': str(backup), 'file_helpers_source': pin(base_raw),
        'scope': 'CODE_AND_RECORDED_COMPOSITION_ONLY',
        'actual_original_App_verified': False, 'native_1_to_1_visual_verified': False,
        'real_platform_verified': False, 'commercial_complete': False,
        'original_App_restarted': False, 'customer_database_opened': False,
        'session_copied': False, 'Computer_Use_or_browser_QA': False,
        'deployment_or_packaging_performed': False, 'legacy_and_recent_code_retained': True}
    temporary = prepared_temp(RECEIPT, (json.dumps(receipt, ensure_ascii=False, indent=2) + '\n').encode('utf-8'))
    temporaries.append(temporary); os.rename(temporary, RECEIPT)
except BaseException as error:
    manual = []
    for target, before, after in reversed(attempted):
        try:
            current = blob(target)
            if current == before:
                continue
            if current != after:
                manual.append(str(target)); continue
            restore = prepared_temp(target, before); temporaries.append(restore)
            if blob(target) != after:
                manual.append(str(target)); continue
            os.replace(restore, target)
            if blob(target) != before:
                manual.append(str(target))
        except (OSError, ValueError):
            manual.append(str(target))
    if manual:
        raise RuntimeError('UI rollback needs explicit review: ' + ', '.join(manual)) from error
    raise
finally:
    for temporary in temporaries:
        temporary.unlink(missing_ok=True)
print(json.dumps({'source_batch': 45, 'physical_targets': 3, 'protected_unchanged': len(protected),
                  'actual_visual_verified': False, 'real_platform_verified': False}))
