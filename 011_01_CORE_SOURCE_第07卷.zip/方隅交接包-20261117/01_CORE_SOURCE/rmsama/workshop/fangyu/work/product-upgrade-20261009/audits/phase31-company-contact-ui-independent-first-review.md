# Phase31 公司联系方式 UI 独立首跑（保留 RED）

结论：原四个独立方法首跑 2 GREEN / 2 RED，330.8166 ms。29 个 source/test/evidence 输入的 before/after SHA 全部一致。首日志、首源清单、首观察和运行前快照保持原样；尚未完成独立验收，不把 B 自有四通过计为本独审通过。

项目完整路径：`C:/积木软件工坊/项目/方隅公寓客户版`。文件夹完整路径：`C:/积木软件工坊/项目/方隅公寓客户版/work/product-upgrade-20261009/audits`。根批准的 B 最终 manifest 为 phase31-contact-delivery-ui-final-hashes.json，SHA 5325FBAA5A678901F8E7DDDBEB42B6C18BD499F159540A99D370107EA405316C；独审执行前逐文件核其 16 条，另加实际 app.py、冻结 local 三源、三个历史 actual fixture 和本独审五文件，共 29 条冻结。

| 独立方法 | 首结果与边界 |
| --- | --- |
| 1 严格 DTO、不可变历史、replay 反例 | RED。旧 Phase29 三 DTO 和 B Phase31 十 actual 合成 DTO 校验先通过；在 fresh REVEAL 反例组首个 delivery.replayed:true 变体未抛出预期异常。不能据此称整个方法通过。 |
| 2 手动授权、unknown 原号恢复、合法撤回 | GREEN。普通打开只读；发布确认后一次；丢失 REVEAL 仅原 action/channel GET、之后 recorded 无重发；新 REVEAL 值仅当次显示且原 response scrub；可信 source、当前同意 true、无 attempt/本 UI 未 dispatch 的实际撤回 unknown DTO 可明确确认，已有 attempt 或已 dispatch unknown 仅 GET。无 UI key、generic receipt 或 storage DML。 |
| 3 迟到与范围/窗口清理 | GREEN。14 组 held REVEAL 和 14 组已显示值的 epoch/actor/role/company/env/连接公司环境/endpoint/device/generation/local/close/reset/dispose 检查，channel 切换和实际 receiver 部门迟到详情均通过。无晚回调 DOM 回填或二次 dispatch。 |
| 4 actual Handler asset、app 路由、宿主入口 | RED，属于独审 fixture 默认值错误。实际 Handler / asset 的新 module 200、非法请求 404 已在此前步骤通过；true 和 false 的四本机动作路由通过，显式 undefined 分支被 fixture 默认成 true，触发缺少拒绝。后续 app 迟到与实际两宿主步骤尚未运行，不能冒称通过。 |

生产缺口：`work/app/src/web/workspace/company-contact-delivery-ui.mjs:45` 的新 REVEAL 判断核 values、release/version/revision，但没核 `replayed===false`。本独审 `phase31-company-contact-ui-independent.test.cjs:34` 只把合法 fresh DTO 的 replay boolean 改为 true，真实生产 checker 仍接受 value-bearing 回执。建议窄加 replay 排除。边界分类为浏览器收到矛盾 DTO 的防御和事实声明缺口；冻结后端 Phase29 的 replay 已仅 metadata，本反例不证明实际重复 KMS 解密或公开伪造私有数据库。

独审设施错误：`phase31-company-contact-ui-independent-fixture.cjs:90` 的 `appExecute({local=true,call}={})` 会把 test 显式传入的 local:undefined 恢复为 true。应保留 omitted 参数的默认本机方便项，但保留显式 undefined，维持原 `test.cjs:81` 的四动作拒绝断言。此处无需改生产 app，首 test 源和首快照保持不变；是否窄修 fixture 后 final 复验由 root 决定。

首文件完整路径：

- `C:/积木软件工坊/项目/方隅公寓客户版/work/product-upgrade-20261009/audits/phase31-company-contact-ui-independent-first.txt`，SHA 73971623276B007AFA0E370608D5B9583145E389107A0148141F8049E556B90F。
- `C:/积木软件工坊/项目/方隅公寓客户版/work/product-upgrade-20261009/audits/phase31-company-contact-ui-independent-first-sources.json`，SHA 57D73B3FF48FF779DBAB6190D0254625C16BB5A7F568DFB7B674F71E15664015。
- `C:/积木软件工坊/项目/方隅公寓客户版/work/product-upgrade-20261009/audits/phase31-company-contact-ui-independent-first-evidence.json`，SHA 99246A8F9A8EE3701BC2C8CF85C0369B2D9E9287B17188A0F410397B0795E0C1。
- `C:/积木软件工坊/项目/方隅公寓客户版/work/product-upgrade-20261009/audits/phase31-company-contact-ui-independent-candidate-hashes.json`，SHA 26F70B83D456B5BB950083A903A048352C699568A98A2AC24D76A7A8AD0DF91F。
- 快照文件夹：`C:/积木软件工坊/项目/方隅公寓客户版/work/product-upgrade-20261009/audits/phase31-company-contact-ui-independent-before/first`。

test source SHA C9B30391BE12A4AFD1F497C0649D3A04746D4905715CB4C954A9EAE5B2C8939D，首 fixture SHA E43CD27FC8DD498607133297DA3F207DA101D76A838595BC730163C890AA8F8F。B 已修宿主 createDialog reentry ticket 时序；本首结果的后半宿主步骤未到达，需待 final 验证，不能用静态阅读补作成功。

所有状态、DOM 和 transport 均隔离合成；实际共享/receiver/operations/app 执行片段和实际 Python Handler / asset 被调用。没有服务器监听、原库/账号、真实网络/KMS/DPAPI/Native或打包。轻量 DOM 功能事件成功不等于浏览器 GUI/视觉人工认可或物理 RAM 擦除；真实 KMS 和两实体电脑交付继续未验证。
