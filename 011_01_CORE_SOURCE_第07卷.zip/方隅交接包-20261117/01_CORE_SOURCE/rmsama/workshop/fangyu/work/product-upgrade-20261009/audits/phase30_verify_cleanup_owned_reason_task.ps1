$ErrorActionPreference = 'Stop'
$auditPath = 'C:\积木软件工坊\项目\方隅公寓客户版\work\product-upgrade-20261009\audits'
$dispatch = Get-Content -LiteralPath (Join-Path $auditPath 'phase30-combined-reason-root-dispatch.json') -Raw -Encoding UTF8 | ConvertFrom-Json
if ($dispatch.run_id -cne '6d34dbbf0a02437385c270507474612f' -or
    $dispatch.task_name -cne ('客户版Phase30组合原因观察-' + $dispatch.run_id) -or
    $dispatch.task_path -cne '\方隅工作台\') { throw 'Owned dispatch mismatch' }
$expectedParent = 'C:\积木软件工坊\项目\方隅公寓客户版\work\product-upgrade-20261009\diagnostics\native-owner-resolver\phase30_combined_reason_probe.py'
$expectedPython = 'C:\积木软件工坊\项目\方隅公寓客户版\work\desktop-python\Scripts\pythonw.exe'
$result = Get-Content -LiteralPath $dispatch.expected_result -Raw -Encoding UTF8 | ConvertFrom-Json
if ($result.run_id -cne $dispatch.run_id -or $result.execution_finished -ne $true -or
    $result.owned_exit_confirmed -ne $true -or $result.current_sid_unchanged -ne $true -or
    $result.materials_unchanged -ne $true -or
    (Get-FileHash -LiteralPath $expectedParent -Algorithm SHA256).Hash -cne 'CF766DF4C6D60AFA47D7CB99380650917281D4D4C1645D2B2F2A83E3984F84F3') {
    throw 'Owned cleanup evidence incomplete'
}
$task = Get-ScheduledTask -TaskPath $dispatch.task_path -TaskName $dispatch.task_name -ErrorAction Stop
$info = $task | Get-ScheduledTaskInfo
$taskXml = [xml](Export-ScheduledTask -TaskPath $dispatch.task_path -TaskName $dispatch.task_name -ErrorAction Stop)
$currentSid = [Security.Principal.WindowsIdentity]::GetCurrent().User.Value
$principal = @($taskXml.Task.Principals.Principal)
$actions = @($task.Actions)
$triggers = @($task.Triggers | Where-Object { $null -ne $_ })
# The scheduler omits the default LeastPrivilege XML field. Require the actual
# CIM principal to be Limited and reject any explicitly different XML value.
if ($principal.Count -ne 1 -or $principal[0].UserId -cne $currentSid -or
    $principal[0].LogonType -cne 'InteractiveToken' -or
    [string]$task.Principal.RunLevel -cne 'Limited' -or
    ($null -ne $principal[0].RunLevel -and [string]$principal[0].RunLevel -cne 'LeastPrivilege') -or
    $actions.Count -ne 1 -or $actions[0].Execute -ine $expectedPython -or
    $actions[0].Arguments -cne ('"' + $expectedParent + '" --run --run-id ' + $dispatch.run_id) -or
    $actions[0].WorkingDirectory -ine 'C:\积木软件工坊\项目\方隅公寓客户版' -or
    $triggers.Count -ne 0 -or $taskXml.Task.Settings.ExecutionTimeLimit -cne 'PT2M' -or
    $taskXml.Task.Settings.MultipleInstancesPolicy -cne 'IgnoreNew' -or
    [string]$task.State -cne 'Ready' -or $info.LastTaskResult -ne 1) {
    throw 'Exact owned task verification failed; no cleanup'
}
function Write-NewEvidence($fileName, $value) {
    $evidencePath = Join-Path $auditPath $fileName
    $stream = [IO.File]::Open($evidencePath, [IO.FileMode]::CreateNew, [IO.FileAccess]::Write)
    $writer = [IO.StreamWriter]::new($stream, [Text.UTF8Encoding]::new($false))
    try { $writer.Write(($value | ConvertTo-Json -Depth 8)) } finally { $writer.Dispose() }
}
$receipt = [ordered]@{
    run_id=$dispatch.run_id; task_name=$dispatch.task_name; task_path=$dispatch.task_path
    state=[string]$task.State; last_task_result=$info.LastTaskResult
    current_sid_principal_verified=$true; exact_action_verified=$true; working_directory_verified=$true
    interactive_limited_verified=$true; actual_cim_run_level='Limited'; default_run_level_xml_omitted=($null -eq $principal[0].RunLevel)
    triggers=0; execution_limit_seconds=120
    result_sha256=(Get-FileHash -LiteralPath $dispatch.expected_result -Algorithm SHA256).Hash
    attempt_sha256=(Get-FileHash -LiteralPath $dispatch.expected_attempt -Algorithm SHA256).Hash
    parent_sha256=(Get-FileHash -LiteralPath $expectedParent -Algorithm SHA256).Hash
    owned_exit_confirmed=$true; source_materials_unchanged=$true; original_account_used=$false
}
Write-NewEvidence 'phase30-combined-reason-root-task-receipt.json' $receipt
Unregister-ScheduledTask -TaskPath $dispatch.task_path -TaskName $dispatch.task_name -Confirm:$false -ErrorAction Stop
$remaining = Get-ScheduledTask -TaskPath $dispatch.task_path -TaskName $dispatch.task_name -ErrorAction SilentlyContinue -ErrorVariable taskAbsenceErrors
if ($remaining -or @($taskAbsenceErrors | Where-Object { $_.CategoryInfo.Category -ne 'ObjectNotFound' }).Count -gt 0) {
    throw 'Owned task absence not verified'
}
$cleanup = [ordered]@{run_id=$dispatch.run_id; task_name=$dispatch.task_name; task_path=$dispatch.task_path
    removed_only_owned_task=$true; absent_verified=$true; other_tasks_modified=$false}
Write-NewEvidence 'phase30-combined-reason-root-task-cleanup.json' $cleanup
$receipt | ConvertTo-Json
$cleanup | ConvertTo-Json
