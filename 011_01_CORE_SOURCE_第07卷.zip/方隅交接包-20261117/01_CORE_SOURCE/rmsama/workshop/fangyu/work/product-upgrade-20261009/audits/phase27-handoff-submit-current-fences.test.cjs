'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const {fixture} = require('./phase25-company-channel-detail-sdk-fixture.cjs');
const crypto = require('node:crypto');

async function observed(f, run, transform=null) {
  const before=f.data.snapshot(), original=f.data.db.runTransaction, callbacks=[];
  f.data.db.runTransaction=function(callback) {
    return original.call(this,tx=>{
      const count={reads:0,writes:0}, context={};callbacks.push(count);
      return callback({...tx,collection:name=>({doc:id=>{
        const ref=tx.collection(name).doc(id);
        return {get:async()=>{count.reads++;const value=await ref.get();
          return transform?transform(name+'/'+id,value,context,count):value;},
        set:async value=>{count.writes++;return ref.set(value);}};
      }})});
    });
  };
  try{return {result:await run(),before,after:f.data.snapshot(),callbacks};}
  finally{f.data.db.runTransaction=original;}
}

test('submit rejects source disabled during the last awaited active-customer read', async () => {
  const f = await fixture();
  const registered = await f.registered('phase27-late-current-source');
  const active = f.doc('handoff_', 'active:' + registered.item.customer_id);
  let reached = false;
  f.duringRead((key, state) => {
    if (key !== active || !state) return;
    reached = true;
    state.users.find(row => row.username === 'source').disabled = true;
  });
  const out = await f.change('acquisition_handoff_submit', registered.item);
  f.duringRead(null);
  assert.ok(reached, 'last awaited read injection must be exercised');
  assert.equal(out.status, 401, 'old source principal cannot authorize a new submit');
  assert.equal(out.data.mutation_committed, false);
  assert.equal(out.data.item, undefined);
});

test('late recipient-policy change and final consent tombstone roll back staged submit writes', async () => {
  for(const boundary of ['recipient_policy','final_consent']) {
    const f=await fixture(), registered=await f.registered('phase27-'+boundary);
    const withdrawal=f.doc('handoff_','withdrawal:'+registered.item.consent.evidence_reference);
    let reached=false,policyReads=0;
    if(boundary==='recipient_policy')f.duringRead((key,state)=>{
      if(key===withdrawal&&state&&++policyReads===5) {
        reached=true;state.acquisitionPolicy.receivers.resource=[];
      }
    });
    const proof=await observed(f,()=>f.change('acquisition_handoff_submit',registered.item),
      boundary==='final_consent'?(key,snapshot,context)=>{
        if(key===withdrawal&&((context.withdrawals=(context.withdrawals||0)+1)===8)) {
          reached=true;return {data:{companyId:'fixture-company',actor:'source',channel_id:registered.item.channel_id}};
        }return snapshot;
      }:null);
    f.duringRead(null);
    assert.ok(reached,boundary+' must exercise the final boundary');
    assert.notEqual(proof.result.status,200);
    assert.equal(proof.result.data.mutation_committed,false);
    assert.equal(proof.result.data.item,undefined);
    assert.equal(proof.after,proof.before,'rejected staged writes must not commit');
    assert.ok(proof.callbacks.some(row=>row.writes>=4),'this is rollback after attempted writes, not zero attempted writes');
  }
});

test('lost submit response is recovered by original read-only status across independent receipt and withdrawal', async () => {
  const f=await fixture(), registered=await f.registered('phase27-original-submit-status');
  const key=crypto.randomUUID();
  f.loseNextResponse();
  await assert.rejects(()=>f.change('acquisition_handoff_submit',registered.item,{},f.tokens.source,key),/response lost/);
  const stored=f.data.docs().get(f.operationDoc('acquisition_handoff_submit',key));
  assert.equal(stored.revision,2);
  f.restart();
  const check=async(expectedStatus,consent,receiptRecorded)=>{
    const proof=await observed(f,()=>f.status('acquisition_handoff_submit',key));
    assert.equal(proof.result.status,200);
    assert.equal(proof.after,proof.before);
    assert.ok(proof.callbacks.every(row=>row.writes===0));
    const receipt=proof.result.data.operation_receipt;
    assert.equal(receipt.original_execution_confirmed,true);
    assert.equal(receipt.original_operation.historical_status,'submitted');
    assert.equal(receipt.original_operation.revision,2);
    assert.equal(receipt.current_handoff.status,expectedStatus);
    assert.equal(receipt.current_handoff.current_consent_valid,consent);
    assert.equal(receipt.current_handoff.historical_resource_receipt_recorded,receiptRecorded);
    assert.equal(receipt.auto_retry,false);
    assert.equal(receipt.platform_delivery_verified,false);
    assert.equal(receipt.financial_receipt_verified,false);
    assert.equal(receipt.verified_cash_cents,null);
    return receipt;
  };
  await check('submitted',true,false);
  const submitted=(await f.call('acquisition_handoff_detail',{channel_id:registered.item.channel_id})).data.item;
  const ack=await f.change('acquisition_handoff_receipt',submitted,
    {decision:'accept',evidence_reference:'evidence:'+crypto.randomUUID().replaceAll('-','')},f.tokens.resource);
  assert.equal(ack.status,200);assert.equal(ack.data.item.receipt.actor,'resource');
  await check('accepted',true,true);
  const withdrawn=await f.change('acquisition_handoff_withdraw',ack.data.item,{reason_code:'customer_withdrew'});
  assert.equal(withdrawn.status,200);
  await check('withdrawn',false,true);
  assert.deepEqual(f.data.docs().get(f.operationDoc('acquisition_handoff_submit',key)),stored,'original submit receipt is immutable');
  assert.equal([...f.data.docs().values()].filter(row=>row.operation==='acquisition_handoff_submit'&&row.payload_hash).length,1);
});
