"""Freeze v3 exact executable mapping; no runtime/host/native invocation."""
import hashlib
import json
from pathlib import Path

PROJECT = Path(__file__).resolve().parents[3]
PHASE = PROJECT/'work/product-upgrade-20261009'
AUDITS = PHASE/'audits'
DIAG = PHASE/'diagnostics/developer-original-identity'
NAMES = ('bootstrap.py', 'profile_occupancy.py', 'profile_process_probe.ps1',
    'runtime_identity.py', 'owned_job.py', 'host.py', 'native_runner.py')


def record(path):
    value = path.read_bytes()
    return {'path': str(path.resolve()), 'bytes': len(value),
        'sha256': hashlib.sha256(value).hexdigest().upper()}


def main():
    backup = PHASE/'backups/phase26-profile-python-v3/1'
    changed = []
    for name in NAMES:
        if name.endswith('.py'):
            compile((DIAG/name).read_text(encoding='utf-8'), str(DIAG/name), 'exec')
        if record(DIAG/name)['sha256'] != record(backup/name)['sha256']:
            changed.append(name)
    assert changed == ['profile_occupancy.py']
    benign = json.loads((AUDITS/'phase26-atomic-job-benign-receipt.json').read_text(encoding='utf-8'))
    assert benign['contract'] == 'phase26_atomic_job_benign_receipt_v1'
    assert all(benign[name] is True for name in ('executed', 'normal_member_verified',
        'normal_owned_exit_confirmed', 'parent_abrupt_exit_confirmed', 'child_exit_after_parent_death_confirmed'))
    evidence = ('test_phase26_developer_identity_host.py',
        'phase26-developer-identity-own-three-v3-first.txt',
        'phase26-developer-original-identity-host-v3-review.md',
        'phase26-atomic-job-benign-receipt.json', Path(__file__).name)
    manifest = {'contract': 'phase26_developer_host_exact_python_v3_freeze_v1',
        'sources_frozen': True, 'source': [record(DIAG/name) for name in NAMES],
        'changed_source': changed, 'evidence': [record(AUDITS/name) for name in evidence],
        'v2_backup_manifest': record(backup/'backup-manifest.json'),
        'v2_frozen_manifest': record(backup/'phase26-developer-original-identity-host-v2-final-hashes.json'),
        'verification': {'unique_methods': 3, 'passed': 3, 'seconds': 1.236,
            'mechanism_only_tests': True, 'root_benign_job_os_sample_verified': True,
            'original_account_observed': False, 'original_data_read_by_d': False,
            'dpapi_read_by_d': False, 'os_process_scan_by_d': False,
            'commercial_natural_authorized': False, 'collection_authorized': False,
            'total_goal_complete': False}}
    (AUDITS/'phase26-developer-original-identity-host-v3-final-hashes.json').write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    print(json.dumps({'source_count': len(NAMES), 'changed_source': changed,
        'unique_methods': 3, 'static_only': True}))


if __name__ == '__main__':
    main()
