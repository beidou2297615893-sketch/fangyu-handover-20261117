# Phase30 联系方式 KMS 启动接线独立审核

结论：B 冻结候选通过本次 **3 个独立方法，首跑 3/3 GREEN，2192.7393 ms**。只执行一次；没有失败，没有产品窄修，没有重复测试或扩展旧矩阵。新配置已由真正 `index.main` 传入实际 `createService/createStore/contact_delivery/provider`，可以跨越原先“仅 fixture 手动注入 provider、正式启动一直为空”的工程断点。

本次允许认定的是离线启动接线与合成持久状态边界通过；`live_kms_verified` 始终为 false。没有部署、真实网络、IAM 或 KMS 访问、原库或原账号访问、Native/DPAPI 操作、物理双机测试、UI 修改或打包。CloudBase 事务引擎和真实加密成功仍未验证。

文件夹完整路径：`C:/积木软件工坊/项目/方隅公寓客户版/work/product-upgrade-20261009/audits`。

## 冻结、执行和证据

B 冻结清单是 [phase30-kms-config-final-hashes.json](C:/积木软件工坊/项目/方隅公寓客户版/work/product-upgrade-20261009/audits/phase30-kms-config-final-hashes.json)，SHA256 `13B564FE57D9C9CC06ACBB2087FB809AF90476E07D3B2C051533C9B0FAE360C6`。35 项在执行前逐一匹配。关键候选：

| 文件 | SHA256 |
| --- | --- |
| work/cloud/workspace/index.js | 4C2FA5BA62DD306ABD183D8CA90236CF93D5FCCF3E2AEE7227E1340EC8709839 |
| work/cloud/workspace/contact_delivery_config.cjs | 7885DC26D1A25C3810A8040AA9D9AA5012184DD64D899BFE46E3C94E555D3CC8 |
| work/cloud/workspace/package.json | B61ADC1072F3A7335A79FECCEFCD356CA7C7CAB8B0C9B722CB167BF3B277355F |
| work/cloud/workspace/package-lock.json | 156DCECD21F3B5152D177A80E394CA762FF10D9A1AA3E37EAB6C4181B0D8DE39 |

冻结 Phase29 云 producer `956E223C… / 30A82FF1… / FE6E303D…` 保持原 SHA。运行前复制并核验了 55 项生产模块、正式 SDK 关键源、候选证据和审核源，运行后全部 SHA 相等；快照完整路径为 `C:/积木软件工坊/项目/方隅公寓客户版/work/product-upgrade-20261009/audits/phase30-contact-bootstrap-independent-before/first`。

执行文件完整路径为 [run-phase30-contact-bootstrap-independent.cjs](C:/积木软件工坊/项目/方隅公寓客户版/work/product-upgrade-20261009/audits/run-phase30-contact-bootstrap-independent.cjs)。它只允许新的 `first/final` 名称，拒绝覆盖已有证据；本次仅 `first` 实际执行。Node `v24.15.0`，`--test --test-concurrency=1`，退出码 0。报告和最终清单直接引用该次 GREEN，不额外跑一次制造第二份成功记录。

| 原始证据完整路径（均为上列 audits 文件夹） | SHA256 |
| --- | --- |
| [phase30-contact-bootstrap-independent-first.txt](C:/积木软件工坊/项目/方隅公寓客户版/work/product-upgrade-20261009/audits/phase30-contact-bootstrap-independent-first.txt) | D8F6E7CC3436E64B713F9A13B06DB6463296865E6B1F1C90B89945217A4BCAA3 |
| [phase30-contact-bootstrap-independent-first-sources.json](C:/积木软件工坊/项目/方隅公寓客户版/work/product-upgrade-20261009/audits/phase30-contact-bootstrap-independent-first-sources.json) | DD5F6FD0F6CA71A646E9846E7EBE85386A64CA6B98B3DAE39A7141B50786DF05 |
| [phase30-contact-bootstrap-independent-first-evidence.json](C:/积木软件工坊/项目/方隅公寓客户版/work/product-upgrade-20261009/audits/phase30-contact-bootstrap-independent-first-evidence.json) | 32DCC5E52D4427CD5CEFC4F1C4355262E9D540B8475BB2047E7637EDCB18C429 |
| [phase30-contact-bootstrap-independent-candidate-hashes.json](C:/积木软件工坊/项目/方隅公寓客户版/work/product-upgrade-20261009/audits/phase30-contact-bootstrap-independent-candidate-hashes.json) | 77983D9EF1E16C27501870CA15E5CC45CDA6AD3335CBAA343A7BCBB4F6D49777 |

独审方法源：[phase30-contact-bootstrap-independent.test.cjs](C:/积木软件工坊/项目/方隅公寓客户版/work/product-upgrade-20261009/audits/phase30-contact-bootstrap-independent.test.cjs)，SHA `4DFC76A73A753FBDC7719801541728D56AC2467AE5972DCA67D9DD4929D9B74F`。首跑前在同一第 1 方法内补强“非法保留期配置下实际授权撤回”，没有删除断言或增加方法；首跑后保持冻结。独立 fixture SHA `4C8F71CFFA6616C5D4CF89C15B5C3E65EFCBEDBDCC1AEF9F6FCB43C2CCACFD74`，runner SHA `023FE08FA01BEC2A39499F4534F798236BA629A952E164B66B90415795CD10C3`。

## 三个必要方法及实际结论

| 独立方法 | 实际耗时 | 核心证据 |
| --- | --- | --- |
| 固定公司真实启动、非法配置故障局部化与合法撤回 | 379.1941 ms | 部分 region、非规范 retention 与完全缺失配置均不加载 SDK。严格 parser 对非法配置明确 invalid。真实 index 仍允许已登录资源员工 `me` 和原发布历史；新 publish/reveal 统一 PROVIDER_NOT_CONFIGURED，完整公司文档相等、所有回调 0 DML、0 KMS。接收方无撤回权；原来源在非法 retention 冷启动下成功撤回已存 vault，版本增加、同意变 false、0 KMS。伪装同 code 的非自家异常和自家不支持分类均保持全局 503、DB init 0，错误原文不泄漏。 |
| 真实 index 与正式项目 SDK 的范围隔离和 decrypt await 同意变化 | 678.3881 ms | 浏览器注入 company/KeyId、错误环境拒绝；原来源、管理员、非接收方、错设备及实际保存的异公司 vault 均在解密前拒绝，状态无持久写。正确映射接收方第一次明确查看获得 RAM 值，只有 1 Encrypt + 1 Decrypt；原号状态无明文。实例构造后改环境 key/secret/retention 不重定向旧 provider。另一个隔离合成实例在 Decrypt await 中通过真实 index 执行成熟 handoff withdrawal，最终不返回联系方式，原 REVEAL 保持 unknown，重启读回当前同意 false、渠道 withdrawn。 |
| KMS 失败与提交后回执丢失的原号恢复 | 1018.5435 ms | Encrypt/Decrypt 各自失败后原操作 unknown，错误及 credentials 不回显。重启原状态和同号操作不再次请求 KMS，不修 unknown；未知发布无法换新号覆盖。另一 REVEAL 已实际提交后由事务 RAM adapter 丢弃回执，首次 503/结果未知；重启原号只确认 recorded/server_release_recorded，重复原操作也不回放明文。 |

共 13 条安全观察证据，其中 11 组记录完整合成公司文档 before/after hash 相等、每个成功或失败回调的实际读写数，以及 KMS 增量 0；另外两组是启动未知错误的 503/DB init 0。变体和观察条数不增加独立方法计数。此处“原号只读 GET”指产品逻辑只读动作，真实云端 HTTP 信封仍是 POST `acquisition_contact_operation_status`；没有把 index 的静态网页 HTTP GET 当作状态接口测试。

所有用户、登录与 remembered-device session 都是新建合成资料；合法 register/submit 来源通过实际 contact ledger 持久保存。固定 company 是 `fangyu-apartment-client`。只替换 CloudBase `init().database()` 存储 I/O 和正式 SDK `Client.request` 网络 I/O；成功主链不替换 service、createStore、config 或 provider。事务 adapter 对每个 callback 运行两次，仅第二份成功状态提交，并记录失败回调的 DML；这证明本实现跨 replay 边界没有把 KMS 调用放进 callback，不冒称真实 CloudBase 引擎验证。

正式 KMS SDK 路径为 `C:/积木软件工坊/项目/方隅公寓客户版/work/cloud/workspace/node_modules/tencentcloud-sdk-nodejs-kms/tencentcloud/index.js`，版本 `4.1.302`。本次没有使用 Phase29 私有 runtime 路径。request double 保存的 opaque handle/base64 明文仅在审核进程 RAM；公司持久文档、日志及元数据回执没有联系方式明文或其原值 hash。它不是加密实现，没有真实 KMS 请求，也不证明 KeyId 存在、IAM 权限、网络可达、账单、安全托管或双机成功。

## 非法 KMS 配置的产品取舍

旧只读计划 [phase30-contact-bootstrap-independent-plan.md](C:/积木软件工坊/项目/方隅公寓客户版/work/product-upgrade-20261009/audits/phase30-contact-bootstrap-independent-plan.md) 原“非法配置导致整个 index 503、DB init 0”期待保留为历史。Root 明确选择后，本次修正为：严格 parser 仍明确 invalid 且 0 SDK；index 仅接住自家三种固定配置故障，记录固定日志并传 provider/null + retention/null，允许授权历史、撤回、普通业务；新 publish/reveal 在 claim 前拒绝。身份/产品配置等其他启动错误仍按原整体失败处理。

选择有实际服务证据：[contact_delivery.cjs:80](C:/积木软件工坊/项目/方隅公寓客户版/work/cloud/workspace/contact_delivery.cjs:80) 撤回先校验原来源主体并返回，[:196](C:/积木软件工坊/项目/方隅公寓客户版/work/cloud/workspace/contact_delivery.cjs:196) provider gate 排除撤回，[:183](C:/积木软件工坊/项目/方隅公寓客户版/work/cloud/workspace/contact_delivery.cjs:183) 原状态查询没有 provider 前置，[:249](C:/积木软件工坊/项目/方隅公寓客户版/work/cloud/workspace/contact_delivery.cjs:249) 撤回清除密文、提高版本并留同意撤回证据。整个 index 全局 503 会禁止这些无需 KMS 的隐私控制。[index.js:75](C:/积木软件工坊/项目/方隅公寓客户版/work/cloud/workspace/index.js:75) 当前窄 class+code 检查与本次真实独审结果一致。没有改旧 service、DTO 或云 producer。

## 下一步产品入口与验收边界

启动接线完成后的最高收益缺口是用户入口：当前 [app.mjs:382](C:/积木软件工坊/项目/方隅公寓客户版/work/app/src/web/workspace/app.mjs:382) 的 PRODUCT_ACTIONS 未纳入四个 `company_contact_*` 动作，接收 UI [:74](C:/积木软件工坊/项目/方隅公寓客户版/work/app/src/web/workspace/company-handoff-receiver-ui.mjs:74) 仍提示电话/微信尚未跨电脑交付，并保持旧平台引用 DTO。建议下一功能切片沿原已认可布局增加控制，不把云启动 GREEN 当作客户端已可用或新视觉候选已被批准。本次没有改 UI。

该切片应一次验收三个相连结果：

1. 来源渠道详情提供明确交付/撤回；获权接收详情提供明确查看/原号查询，统一经本地 product_action。采用独立严格 `local_company_contact_delivery_v1` DTO，不放宽旧收件 DTO，不接受浏览器指定 phone、actor、device、owner、KeyId。用户先看到当前同意、部门、用途、版本及 provider/retention 状态，再确认操作。
2. 展示 configured 与真实 KMS 未核验、local unknown 与服务器 recorded、历史 release 与当前 consent 的区别，金额保持 null。错误或超时保原 key/版本，原号查询只给 metadata，不能自动刷新会话、解密、换号或重发。第一次 REVEAL 值只属当次 RAM；关闭后解释需核对原操作，不秘密另造 key 恢复值。
3. 对话框关闭、列表/部门/渠道切换、账号/公司/设备变化、reset/dispose 后立刻清空值、DOM 与待处理结果；迟到成功回调不得重新显示。禁止 local/sessionStorage、日志、导出、通用 ProductOperationReceipts、自动复制保存 plaintext。真实 KMS/IAM/双机和真实客户同意证据仍应单列后续人工验收。

适用最小流程是完成前验证和 consent-registry 的当前同意/撤回优先原则，context-mode 没有可调用 MCP 时只进行本地定向筛选并保留原始证据。consent-registry 所引用的 runtime/protocol 文件缺失，不冒称建立或调用外部 registry；此次没有任何真实同意记录或真实个人资料。
