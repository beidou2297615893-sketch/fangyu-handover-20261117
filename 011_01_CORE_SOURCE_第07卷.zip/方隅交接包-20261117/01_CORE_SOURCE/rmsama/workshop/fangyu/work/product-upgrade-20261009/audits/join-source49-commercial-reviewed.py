"""Root-only scoped commercial source join, using reviewed Source44 CAS helpers."""
import ast, ctypes, hashlib, json, os, stat, subprocess, sys, tempfile, uuid
from pathlib import Path
PROJECT=Path('C:/积木软件工坊/项目/方隅公寓客户版')
WORK=PROJECT/'work'
STAGE=WORK/'product-upgrade-20261009'
OWN=WORK/'source49-commercial-root'
MANIFEST=OWN/'MANIFEST.json'
APPROVAL=STAGE/'audits/source49-commercial-final-root-read.json'
RECEIPT=STAGE/'audits/source49-commercial-joined.json'
FAILED=STAGE/'audits/source49-commercial-join-failed.json'
ALLOWED=frozenset({
 'app/src/assistant/employee_workspace.py','app/src/web/workspace/app.mjs',
 'app/src/web/workspace/index.html','app/src/web/workspace/member-admin-ui.mjs',
 'cloud/workspace/service.cjs','cloud/workspace/site.cjs','cloud/workspace/site/app.mjs',
 'cloud/workspace/site/index.html','cloud/workspace/site/member-admin-ui.mjs',
 'owner-admin-20261004/owner_admin.py','owner-admin-20261004/site/index.html',
 'owner-admin-20261004/site/owner-admin.mjs','owner-admin-20261004/site/member-admin-ui.mjs'})
HELPER=STAGE/'audits/join-source44-reviewed.py'
helper_raw=HELPER.read_bytes()
if len(helper_raw)!=9601 or hashlib.sha256(helper_raw).hexdigest().upper()!='5F5E3EA22AF7C1FA0FEA71CFEFDA12A9D669C190D5470960901029BF8F4750FB':
    raise ValueError('reviewed helper changed')
names={'blob','pin','expected','no_link_parent','prepared_temp'}
definitions=[x for x in ast.parse(helper_raw).body if isinstance(x,ast.FunctionDef) and x.name in names]
if len(definitions)!=5 or {x.name for x in definitions}!=names:raise ValueError('helper definitions changed')
exec(compile(ast.Module(body=definitions,type_ignores=[]),str(HELPER),'exec'),globals())

def ensure_portal_absent():
    # This source group never changes the active XHS host/source guard. Only
    # an existing original portal or local formal cloud service can conflict.
    command="$ErrorActionPreference='Stop'; Get-CimInstance Win32_Process | Where-Object { $_.Name -in @('python.exe','pythonw.exe','node.exe') } | ForEach-Object { if ([string]::IsNullOrWhiteSpace($_.CommandLine)) { 'unknown-process-identity' } elseif ($_.CommandLine -like '*方隅公寓客户版*work*owner-admin-20261004*' -or $_.CommandLine -like '*方隅公寓客户版*work*cloud*workspace*') { 'owned-process-live' } } | ConvertTo-Json -Compress"
    result=subprocess.run(['powershell.exe','-NoProfile','-NonInteractive','-Command',command],capture_output=True,encoding='utf-8',errors='replace',timeout=15)
    if result.returncode or result.stderr.strip():raise ValueError('portal occupancy unknown')
    if result.stdout.strip():raise ValueError('original portal/local cloud process still live')

if os.name!='nt' or len(sys.argv)!=3 or sys.argv[1]!='--apply' or len(sys.argv[2])!=64:
    raise ValueError('exact Root approval SHA required')
if RECEIPT.exists() or FAILED.exists():raise ValueError('existing execution evidence preserved')
approval_raw=blob(APPROVAL)
if pin(approval_raw)['sha256']!=sys.argv[2].upper():raise ValueError('Root gate changed')
approval=json.loads(approval_raw)
if (approval.get('schema')!='source49_commercial_final_root_read' or approval.get('join_authorized') is not True
    or approval.get('non_author_code_passed') is not True or approval.get('limited_actual_QA_passed') is not True
    or approval.get('join_script_review_passed') is not True or approval.get('commercial_complete') is not False):
    raise ValueError('scoped gate not approved')
expected(Path(__file__).absolute(),approval['join_script_pin'])
manifest=json.loads(expected(MANIFEST,approval['manifest_pin']))
if manifest.get('schema')!='source49_commercial_increment_v1' or manifest.get('join_authorized') is not False:
    raise ValueError('manifest changed')
targets=manifest['targets']
if len(targets)!=13 or {Path(x['target']).relative_to(WORK).as_posix() for x in targets}!=ALLOWED:
    raise ValueError('target set changed')
for item in manifest['evidence']+approval['additional_evidence']:
    path=Path(item['path']);path.relative_to(WORK);expected(path,item['pin'])
for item in manifest['protected']:expected(Path(item['path']),item['pin'])
changes=[]
for item in targets:
    target=Path(item['target']);candidate=Path(item['candidate']);candidate.relative_to(OWN/'candidates')
    after=expected(candidate,item['candidate_pin'])
    if item['parent'] is None:
        no_link_parent(target)
        if target.exists() or target.is_symlink():raise ValueError('new target appeared')
        before=None
    else:before=expected(target,item['parent'])
    changes.append((item,target,before,after))
ensure_portal_absent()
backup=PROJECT/'backups/source49-commercial'/uuid.uuid4().hex
backup.mkdir(parents=True)
saved=[];temporaries=[];applied=[]
try:
    for item,target,before,after in changes:
        path=backup/target.relative_to(WORK)
        if before is not None:
            path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(before)
            expected(path,item['parent'])
        saved.append({'target':str(target),'backup':str(path) if before is not None else None,'parent':item['parent'],'candidate_pin':item['candidate_pin']})
        temporaries.append((target,prepared_temp(target,after)))
    (backup/'PREPARED.json').write_text(json.dumps(saved,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    ensure_portal_absent()
    for item,target,before,after in changes:
        if before is None:
            if target.exists() or target.is_symlink():raise ValueError('new target appeared during backup')
        else:expected(target,item['parent'])
    for item in manifest['protected']:expected(Path(item['path']),item['pin'])
    for (item,target,before,after),(same,temporary) in zip(changes,temporaries):
        if target!=same:raise ValueError('target order changed')
        # Match the mature writer's final per-target parent check. Windows
        # rename refuses to replace an unexpected newly-created target.
        no_link_parent(target)
        expected(temporary,item['candidate_pin'])
        if before is None:
            if target.exists() or target.is_symlink():raise ValueError('new target appeared before rename')
            os.rename(temporary,target)
        else:
            expected(target,item['parent'])
            os.replace(temporary,target)
        applied.append((item,target,before));expected(target,item['candidate_pin'])
    for item in manifest['protected']:expected(Path(item['path']),item['pin'])
    result={'schema':'source49_commercial_joined_v1','source_batch':'Source49-commercial','backup':str(backup),
        'targets':saved,'manifest_pin':pin(blob(MANIFEST)),'approval_pin':pin(approval_raw),
        'active_XHS_source_guard_changed':False,'App_restarted':False,'pilot_marker_changed':False,
        'DB_or_cookie_read_copied':False,'cloud_deployed':False,'real_GUI_verified':False,'commercial_complete':False}
    RECEIPT.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'joined':True,'targets':len(saved),'receipt':str(RECEIPT),'backup':str(backup)},ensure_ascii=False))
except BaseException as error:
    rollback=[]
    for item,target,before in reversed(applied):
        try:
            no_link_parent(target)
            expected(target,item['candidate_pin'])
            if before is None:
                target.unlink()
            else:
                restore=prepared_temp(target,before)
                temporaries.append((target,restore))
                expected(target,item['candidate_pin'])
                no_link_parent(target)
                os.replace(restore,target);expected(target,item['parent'])
            rollback.append({'target':str(target),'restored':True})
        except BaseException:rollback.append({'target':str(target),'restored':False})
    FAILED.write_text(json.dumps({'failed':True,'error_type':type(error).__name__,'backup':str(backup),'rollback':rollback},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    raise
finally:
    for target,temporary in temporaries:
        if temporary.exists():temporary.unlink()
