# Phase30 联系方式 bootstrap：只读产品判断与独审计划

当前结论：最高收益缺口是**把 Phase29 已有联系方式能力接进真实服务器启动入口**。B 的候选完成后，应直接独审 `index.main → getService → createStore/createService → 官方 SDK provider`，不能再用手工注入 provider 的旧 fixture 代替 bootstrap 接线证明。本报告只读源码和设计验收，没有执行 Phase30 测试、部署、真实 KMS 或读取真实配置/账号。

## 已读到的实际断点

- `work/cloud/workspace/index.js:61–83` 只从部署环境派生 productOptions，再初始化 CloudBase 并创建 service；没有传 `contactDeliveryProvider/contactRetentionSeconds`。
- `service.cjs:46–58` 两配置默认 `null`，创建真实 `createContactDelivery` 时直接使用它们。
- `contact_delivery.cjs:38–39、196–197` 在写前要求 provider configured、固定 signature 和有效保留期限（1–31536000 整秒）。`company_contact_delivery.py:236–251、332–335` 会先读权限，在创建本机 attempt/解密前停住。因此仅接后端动作无法让真实入口完成联系交付。
- `kms_contact_provider.cjs:11–42` 已有官方 SDK factory/Encrypt/Decrypt 边界，但它接收可信服务器构造参数。现 `package.json` 仅声明 `@cloudbase/node-sdk:3.18.3`；Phase29 fixture 从 stage 私有 runtime 载入官方 `tencentcloud-sdk-nodejs-kms@4.1.302` 并手工注入 provider。这个代表通过不能证明部署根能标准 `require` KMS 包。
- `app.mjs:382–401` 的 PRODUCT_ACTIONS 及仅本机动作 guard 不含四个 `company_contact_*` 动作。`company-handoff-receiver-ui.mjs:24、74、113` 仍坚持 `platform_reference_only` 与“电话微信尚未跨电脑交付”，没有新联系操作入口。这是 bootstrap 后的下一功能切片；三张新视觉候选待选不应阻止在原认可布局增加必要功能控制。

需求对应：R07（资源部实际承接）、R21（多机协作）、R03（来源/原号与接收/外部归属分离）、R25（原库/证据保留、不打包部署）。R18 的原号/未知经验可复用，但不能把 AI 费用证明移作 KMS 费用或成交证明。实际台账段落在 `outputs/产品升级/需求交付与证据台账.md:191、195、206、209、213`。

只读时 `index.js` SHA256 为 `223A150519F3BCACE360D35BBDAF876DEEAB74AF426D415A3DF3B259DA2AFF1B`，package.json 为 `EA12A14AF2BDD2F4E80643BFFA7AD012A5BE467AD89255875D9720CCF1DDF545`。这不是 B 后续候选的冻结 SHA。

## B 候选的接线验收条件

部署环境是唯一配置来源：固定 company/environment、KeyId、region、保留期限和可信 server credential/client 构造。公共请求不能选密钥、区域、endpoint、module path、角色或凭证。数据库 `CLOUDBASE_APIKEY` 不等于 KMS credential/IAM 能力。部署依赖需锁定官方包和许可证，正常模块解析不能依赖 stage 的个人路径。

无 KMS 配置保持旧默认：不装载/构造 KMS client、不调用 KMS，metadata status 与成熟隐私撤回路径仍能工作；写与本机解密仍 fail closed。明确但无效的配置不得静默回退，必须在 SDK 构造/数据库初始化之前有固定诊断。有效完整配置只证明已构造 provider，不得把 `provider_configured:true` 显示成真实 KMS 健康或权限已核验，`live_kms_verified` 继续 false。实际 credential source/启用开关/缺项语义以 B 完成的窄合同为准，独审不自行发明环境变量。

日志、返回 body、公开 DTO、公司文档、本机记录及测试证据不得包含凭证、KeyId、region、endpoint 的私有配置明细、ciphertext 或释放 phone/WeChat。SDK 原异常可能带配置细节，应保持固定错误。允许首次明确 REVEAL 的值仅在该专属 RAM 响应存在。

## 三个代表性独立方法（候选冻结后执行）

1. **实际冷启动配置门禁与纯 status。** 在独立子进程装载真实 index；以已知合成环境替换本次 process.env，不读取/打印主机真实环境。无配置、部分/错型/越界配置、完整合法配置作为一个方法的子场景。通过 loader/constructor/CloudBase init 和 API 计数核实顺序：无配置 0 KMS load/client/API；坏显式配置 0 client/API/DB 初始化且固定错误无敏感 marker；合法配置构造一次 provider、status 0 Encrypt/Decrypt/文档写，configured 不升级 live verified。观察实际 createService 入参和公开返回，而非只测配置 parser。
2. **实际入口的最小完整交付及权限/同意/隔离。** 独立合成数据库明确使用 index 固定允许的 `fangyu-apartment-client` company 文档，源端与接收端使用各自空 Core/当前员工设备；不能用 `fixture-company` 跳过 index 公司门禁。由真实 POST `index.main`、真实 createStore/service/provider 执行一次明确 publish 与获权 receiver 的首次 reveal；官方 SDK Client.request 边界仅用 opaque RAM 替身，数 Encrypt/Decrypt 各一次、证明事务 callback 内 API 数 0。同方法选择未映射接收人/来源自 reveal、foreign company 文档或错误 session/device，以及 SDK await 后新增同意墓碑/撤权，均拒绝值或完成确认；拒绝前未调用 KMS，已 claim 的迟到变化按未知原号处理。公开 metadata/普通 status/receipt 不能带值，receiver 原 contact/lead 库不能因交付被复制。
3. **配置正确但执行失败/提交回显丢失的原号恢复与撤回。** 用真实入口实际拥有的 SDK 接口 opaque 替身，分别令 Encrypt/Decrypt 抛固定失败和提交后丢回显；不改实现，不模拟第二次自动成功。重建 bootstrap/service 后按同 action/key/channel status，允许服务器 recorded 与本机 unknown 并列，缺回执继续 unknown，GET 两 Core 完整 dump/云文档快照相等、trace 0 DML/0 KMS。重复 write 不再 Encrypt/Decrypt、不回放明文；删除/停用 provider 配置后成熟公司撤回/墓碑仍能停止原未知操作或未来 reveal，保留历史 access。此方法需使用可观察实际 commit 的原 fixture 能力，不能把“丢响应”仅做成调用前拒绝。

各方法只是一条独立方法，子变体与重复运行不另计新增。首轮两/三个实际结果只执行一次并保全日志；若 RED 先给 root/B 定位窄修，原断言保留，候选重新冻结后才复验。三项都必须包含来源前后 SHA、候选快照、实际冻结加载证明及无 plaintext 的 bounded 证据。Phase29 原全部旧矩阵和成熟生产模块不扩大重跑。

## 下一步 UI 切片建议（本轮不实施）

- 在现公司来源详情加入“交付联系方式”，在本人已选获权部门的公司收件详情加入“明确查看联系方式”，保留“核对原操作”和“撤回授权”；继续使用原认可布局，不新建重复导航、CRM 或员工技术配置表单。前端白名单与 non-local guard 同时补齐四个动作，真实本机 `product_action` 为唯一路由。
- 新专属联系 DTO 校验器核对 `local_company_contact_delivery_v1` 的 action/channel/attempt 原 action/key/联系版本/修订、当前 company/session/device scope、permissions、provider/retention 和 current consent。旧 receiver DTO 仍是平台引用/接单历史，不能 raw spread 成联系值 DTO，也不能修改旧严格白名单使其接收裸值。
- 源端只提交既有 `contact_reference` 与准确的 handoff/contact revision，不由浏览器提交 phone/KeyId/owner；匹配接收部门、用途、告知版本与当前同意后，默认未勾选、明确确认才发布。已有本机存量不能自动批量上传。
- 单独显示公司是否已登记发布、当前联系方式可用性/撤回/过期、原尝试 unknown/recorded、服务器历史释放事实。`provider_configured` 不等于健康，`server_release_recorded` 不等于员工确实看到/已联系客户，当前同意仍是 operator recorded、非独立核验，现金/佣金保持 null。
- 一旦 dispatch 后未知，只给原 GET，不允许重试 reveal、换 key、换主体或新联系人版本绕过 unknown。GET 即使 recorded 也没有号码。现契约只有该主体/渠道第一次成功 REVEAL 返回 RAM 值；关闭后的原号不能恢复号码，界面必须明确说明。将来是否允许全新显式查看意图是独立产品取舍，不能在本轮自动换 key。
- RAM 值仅置于当前受控详情：close、返回列表、切部门/渠道、logout、公司/员工/设备变更、reset/dispose 与晚旧 generation 回调都必须同步清 DOM/内存并拒绝再显示。不得进入 storage、日志、普通导出、历史记录、generic receipts 或自动 clipboard。验收须真实组件操作与晚回调反例，不仅检查某个 `clear()` 函数存在。

## 证明层级与边界

合成 bootstrap + SDK-interface opaque 请求替身能证明配置顺序、标准 loader 接线、权限/同意/隔离、原号恢复和无明文持久化。它不能证明腾讯 KMS 实际 CMK/IAM/凭证/网络/地域/计费或真实加解密，也不能证明 SCF 实际 credential 注入、真实 CloudBase 事务引擎、两台 Windows/两主体 DPAPI、真人资源员工可用、客户接听或成交回款。真实环境信息只需负责人确认已有条件，不要求用户向对话发送密钥。

最小技能：沿用 verification-before-completion 的证据前置，并实际读取 consent-registry 的最小证据/当前撤回优先原则。它的相对 registry runtime/protocol 不存在于本安装，本轮不声称已建立/执行独立 consent registry；工程现有公司墓碑才是实际约束。context-mode 工具未载入，长材料使用本地精确筛选；不声称有 hooks/自动恢复。

报告完整路径：`C:/积木软件工坊/项目/方隅公寓客户版/work/product-upgrade-20261009/audits/phase30-contact-bootstrap-independent-plan.md`。

文件夹完整路径：`C:/积木软件工坊/项目/方隅公寓客户版/work/product-upgrade-20261009/audits`。
