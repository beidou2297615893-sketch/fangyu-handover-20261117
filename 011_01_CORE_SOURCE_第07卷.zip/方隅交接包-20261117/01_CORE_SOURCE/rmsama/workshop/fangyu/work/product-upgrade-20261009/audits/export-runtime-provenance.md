# Excel导出依赖来源与边界

本轮选择官方维护的 [XlsxWriter](https://github.com/jmcnamara/XlsxWriter) 实现 Excel 文件，采用固定 3.2.9 官方 PyPI wheel。安装参数 `--only-binary :all: --no-deps --require-hashes --target` 仅写本客户源码目录，不修改系统或其他工程依赖；未执行正式打包。

- 官方包页：[PyPI](https://pypi.org/project/xlsxwriter/)。wheel SHA256：`9a5db42bc5dff014806c58a20b9eae7322a134abb6fce3c92c181bfb275ec5b3`，requirements 保留版本与哈希。
- 本客户运行库：`work/app/src/xlsxwriter`；metadata：`work/app/src/xlsxwriter-3.2.9.dist-info`。原目标 `_vendor_export` 的 namespace 导入不能处理库中的绝对 import，已在验证路径边界后移动包至客户源码顶层；没有全局安装或动态别名。
- 桌面 Python 3.11 实际导入及两工作表生成已通过；初次全局路径保护在任何安装前拒绝，shim 环境没有 pip 的尝试未写全局。最终用既有 Python 的 pip 将包写本客户指定 target。
- BSD 2-Clause 原许可证保留于 `work/app/src/resources/licenses/XlsxWriter-3.2.9-LICENSE.txt`，SHA256：`CF08B60A4DED986B58A617CB8304373BDA5C4EFF42FB4E30D7597B616E116E87`。正式交付时仍需一并带上许可证。

所有可识别自由文本经本地隐私门禁，Excel 用 [`write_string`](https://xlsxwriter.readthedocs.io/worksheet.html) 字面值写入，不将用户字段作为公式或超链接。CSV 对公式前缀转义。联系方式字段和受保护联系引用不导出；来源改变、当前撤回、权限变化不能伪称可交付。内容 SHA 仅核对文件，不证明独立接收、订单、结算或防止所有软件外截流。

真实 IAB 下载的两个人工样例文件已逐表验证（1条待送达/2条历史、撤回不可交付、0公式/外部关系），证据 `actual-handoff-downloads.json`。这是本机导出验收，不是资源部实际接收。
