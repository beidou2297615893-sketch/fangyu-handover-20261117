# 良性隐藏 WebView2：root 执行前核对

root 实际读取四份冻结源与候选报告，四 SHA 在 dispatch 前匹配 D final manifest。仅合成 profile 和隐藏固定 inline HTML/CSP，复用精确 runtime 与 atomic owned Job。无原 DATA/DPAPI/账号/CLI/公司/平台 URL；WebView2 厂商背景网络启动后未知且可能，不能报告全部网络零请求。

最多两次真实 CIM，原 classifier 非 vacant 即 blocked，trace 仅观察真实 uncertainty 不授权。通过要求实际 loaded renderer、至少一个 owned selected WebView2 行、首尾材料相同和 owned exit confirmed。此代表不等于原账号恢复。root 授权单次固定当前 Interactive/Limited、零触发器、唯一 GUID 的 Native 运行；保留未知阻断，不自动再试原账号或删合成浏览器 profile。

这是源码审查和执行前边界核对，尚不是 Native 通过证据。root 未新增或运行单元测试，也未修改 D 七源、既有 867B probe 或已归档功能源码。