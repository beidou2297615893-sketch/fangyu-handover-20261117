# Phase12 公司平台线索准备入口独立前端审查

本文件只记录本轮独立证据。Phase10/11 已冻结代码、测试与报告未修改。生产代码归 root；本审查仅新增本文件、独立测试与日志，没有发送、云回读、部署或真实用户数据访问。

## 已执行证据

`company-handoff-origin-ui-independent.test.cjs` 加载真实 `upgrade-operations-ui.mjs` 的完整 `createUpgradeOperations`、真实 `checkedCompanyPreparation`，只删除原顶层动态 imports 并替换不相关子组件初始化。DOM 为轻量测试边界，传输响应为合成合同；未替代新准备功能的实现。

另从真实 `app.mjs` 提取完整 `PRODUCT_ACTIONS` 注册与 `execute` 单元。fake cloud/submit 是传输观察边界，不能当实际云服务验证。

首轮 8/8：`company-handoff-origin-ui-independent-first.txt`。root 加本机专属 app 路由门禁与既有状态枚举后，新注册/传输代表例并复跑原例，9/9：`company-handoff-origin-ui-independent-registry-green.txt`。

D 锁定精确原版本合同后，实际 checker 代表 RED 为 10 组 9 绿 1 红：`company-handoff-origin-ui-independent-revision-red.txt`，原版本 3 / 当前版本 4 / `preparation_usable:true` 未抛出预期错误。此为消费者在合成矛盾返回下的真实校验缺口，不宣称 D 实际后端曾产生该错误响应。root 仅在 usable 条件增加版本相等检查。本独测随后加实际本机投影核对，新 11/11 通过：`company-handoff-origin-ui-independent-actual-green.txt`，不计 root、B、D 或旧阶段覆盖。

1. 真实交接详情先只读 `handoff_detail`，明确点击“准备公司平台线索”后才进入专属对话框；进入只发本机 GET，data 仅 `handoff_id`，没有自动准备、云状态读或通用恢复调用。
2. “保存本次准备”明确点击后仅发 `handoff_id`、`expected_revision` 与本次 UUID。双击只发一次。session 存储只有这三个 opaque 字段，不存联系人、客户原文或来源正文。云 key 由后端派生。
3. 成功显示“准备已保存，尚未送达”“本次准备没有向公司发送”；同时保留更早公司操作未知及本机归档不等于公司来源确认的说明。
4. 模拟丢回执后只 GET 恢复。GET `not_prepared` 或另一准备 key 保留原槽，不生成新 key/重提。只有原 key 与原交接版本对应的有效 prepared 投影才清本次槽。
5. 明确本次前置拒绝 `mutation_committed:false` 仅清本次准备槽；未知异常保留。已有 `handoff_submit` 通用未知槽在两种路径都原样保留。
6. 外部 accept、role、device、reset 在 GET/prepare 等待中变化，迟到结果不能渲染准备成功；已提交的本次 key 保留，不能借晚返清除。
7. 两窗口同槽编号替换后，老 prepare success 以及老 origin GET 都不能清新编号，仍无再次准备入口。
8. 精确字段 checker 拒绝私有字段、广义 no-dispatch、更早历史非未知、独立来源验证与 key 不匹配；这类响应不能伪造当前成功证据。
9. 实际 app 注册把两动作送到本机 `product_action`。`localWorkspace=false/undefined` 时 typed preexec `mutation_committed:false`，0 cloud call、0 generic submit，不掉进 command_submit。
10. `preparation_usable:true` 必须当前版本等于原版本；版本错配实际 checker 和完整组件均拒绝可用声明。合法历史记录 `usable:false` 仍可读，不自动重准备。
11. D 归档的实际 Core/Store/ContactJournal 七 case 原样通过真实 checker。五个 GET case 进入完整组件，缺记录仍只读；原 key GET 可清本次槽；来源变化、当前 ACK 缺失和撤回均显示历史准备但当前交付暂停。两个 prepare/replayed 写投影按原 action/key/revision/readOnly=false 校验，未为显示而篡改回执，也没有在本轮通过真实后端执行写操作。

## 源码与口径

`upgrade-operations-ui.mjs:16` 严格验证 `company_handoff_preparation_v1`，`no_dispatch_scope=this_preparation_only`、`previous_company_dispatch_status=unknown`。`source_ack_recorded=true` 为本机归档记录，`source_cloud_binding_verified=false`。

`:229` 专属 `openCompanyPreparation` 不复用 `write/recover`，专属 slot 与旧 `fangyu:product-operation` 分开；`:291` GET 缺记录不造编号或取消墓碑。`:194` 原详情显式入口沿用 accept；专属窗口额外绑定初始 scope。

`app.mjs:383` 两动作注册，`:385` 非本机工作台窄门禁，之后的实际 `product_action` 分支保留原 principal/deviceGeneration 返回检查。

源码快照（11/11 时，非宣称 root 最终冻结）：

- upgrade-operations-ui.mjs：`3BD89799810D93B3F5F24F1D0A981231D4DC6EFEB2F1E9489920E5EC956A5737`
- app.mjs：`0429924181B8D2E1CEB503468F9F39D66DDD4B35E5FB747315EA6B595B6DBCD2`
- 独立 test：`CBD9E3A5409CC3DDA9D19E0316B450D3945B9B8F9A7AB0159F0051F092FD11D2`
- D actual fixture：`495FC1FCF1D9ADDD9DADB3668082B5C572D4043A2BAAA150B0F0D1CCAF8BBD65`

RED 对应旧 UI 源：`8C52C4117B0BA500BE7BBF49DF3B455881367BD9C5B5335E92273FF4D42EA5B4`。原 9/9 test 源：`90B7DA36749426D7BA67C262A18D1E6D3C80DF78F9E70796C9AECFE61CFB6C8B`；初始日志保持原证据不覆盖。

## 证据边界

`company-handoff-preparation-actual-fixture.json` 顶层明确 `synthetic_only:true`、`fixture_execution:actual_local_core_store_contact_journal`、`real_cloud_or_platform_called:false`、`sdk_engine_claimed:false`。实际 JSON 是 D 同一本机 Core/Store 输出归档；本轮 UI 独审使用原样输出，未独跑 D 后端套件，不把归档读取写成自己已验数据库并发、真实 HTTP/GUI 或跨电脑送达。

最终已核当前版本高于 origin 版本仅允许历史 `prepared/usable:false`；本轮必要消费者缺口已闭合，没有发现剩余阻断。原 source ACK 只证明本机登记，缺失时不能继续使用历史准备；不构成公司来源绑定或独立接收证明。

初次打开真实交接详情读取本机业务记录；整个既有详情链不能据本轮准备组件测试宣称所有动作零写。新准备行为只保存原准备证据，不改变 contacts/handoffs/ratings，不验证独立 ACK、实收、支付或结算。
