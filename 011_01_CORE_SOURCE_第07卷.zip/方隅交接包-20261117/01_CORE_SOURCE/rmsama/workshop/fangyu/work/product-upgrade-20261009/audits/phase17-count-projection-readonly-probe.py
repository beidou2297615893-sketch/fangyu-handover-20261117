"""Independent one-fixture read audit; synthetic Core only, no production writes."""
from contextlib import contextmanager
from copy import deepcopy
import importlib.util
import json
from pathlib import Path
import tempfile
from unittest import mock

HERE = Path(__file__).resolve().parent
PROJECT = HERE.parents[2]
TEST = PROJECT / 'work/app/tests/test_private_strategy_single_batch_entry.py'
spec = importlib.util.spec_from_file_location('count_projection_fixture', TEST)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)


def main():
    base = PROJECT / 'work/product-upgrade-20261009/tmp/count-projection-readonly-probe'
    base.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(dir=base) as directory:
        assert Path(directory).resolve().is_relative_to(base.resolve())
        fixture = module.SingleBatchEntryFixture(directory)
        try:
            store, tenant, task_id = fixture.core.store, fixture.executor.tenant, fixture.task_id
            for ident, lead_tenant, lead_task in (
                ('probe-target-1', tenant, task_id), ('probe-target-2', tenant, task_id),
                ('probe-other-task', tenant, 'other-task'), ('probe-other-tenant', 'other-tenant', task_id)
            ):
                store.put('leads', {'id': ident, 'tenant_id': lead_tenant,
                    'task_id': lead_task, 'text': 'PRIVATE_SYNTHETIC_LEAD_CANARY'})
            task = store.get('tasks', task_id)
            task['accumulated'] = 9999
            store.put('tasks', task)
            connect = store.connect
            with connect() as db:
                before = '\n'.join(db.iterdump())
            statements = []

            @contextmanager
            def traced_connect():
                with connect() as db:
                    db.set_trace_callback(statements.append)
                    yield db

            with fixture.forbid_real(), mock.patch.object(store, 'connect', traced_connect):
                projected = fixture.read()
            with connect() as db:
                after = '\n'.join(db.iterdump())
            mutations = [sql for sql in statements if sql.strip().split(' ', 1)[0].upper()
                in {'INSERT', 'UPDATE', 'DELETE', 'REPLACE', 'CREATE', 'ALTER', 'DROP', 'VACUUM', 'REINDEX'}]
            assert projected['task']['accumulated'] == 2 and not mutations and before == after
            serialized = json.dumps(projected, ensure_ascii=False)
            assert 'PRIVATE_SYNTHETIC_LEAD_CANARY' not in serialized and 'PHASE17_PRIVATE_' not in serialized
            result = {'synthetic_only': True, 'count': 2, 'stored_stale_count': 9999,
                'different_task_and_tenant_excluded': True, 'sqlite_mutation_count': len(mutations),
                'database_dump_unchanged': before == after, 'lead_text_and_keywords_not_projected': True}
            original_list = store.list
            original_user = store.get('users', fixture.user['id'])
            fired = False

            def revoke_on_count(entity, requested_tenant=None):
                nonlocal fired
                rows = original_list(entity, requested_tenant)
                if entity == 'leads' and requested_tenant == tenant and not fired:
                    fired = True
                    revoked = deepcopy(original_user)
                    revoked['disabled'] = True
                    store.put('users', revoked)  # Explicit isolated fault injection, outside zero-write assertion.
                return rows

            with fixture.forbid_real(), mock.patch.object(store, 'list', revoke_on_count):
                try:
                    late = fixture.read()
                    result['late_disabled_actor_projection_returned'] = True
                    result['late_projection_count'] = late['task']['accumulated']
                except Exception as error:
                    result['late_disabled_actor_projection_returned'] = False
                    result['late_error_type'] = type(error).__name__
            assert fired
            print(json.dumps(result, ensure_ascii=False, indent=2))
        finally:
            fixture.close()


if __name__ == '__main__':
    main()
