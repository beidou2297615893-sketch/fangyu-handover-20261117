/* Independent actual enterprise controller snippets and actual session reset.
 * Reuses the mature modern-task VM/DOM approach; isolated projected inputs.
 * No GUI, original database, platform, provider, cloud or account access.
 */
'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const workspace=path.resolve(__dirname,'../../app/src/web/workspace');
const source=fs.readFileSync(path.join(workspace,'enterprise-ui.mjs'),'utf8');
const copy=value=>JSON.parse(JSON.stringify(value));
const settle=async()=>{for(let n=0;n<16;n++)await Promise.resolve();};
const deferred=()=>{let resolve;const promise=new Promise(yes=>resolve=yes);return {promise,resolve};};
function slice(start,end){const a=source.indexOf(start),b=source.indexOf(end,a);assert.ok(a>=0&&b>a,`actual source region ${start}`);return source.slice(a,b);}
function actualReset(){
 const start=source.indexOf('reset(){');assert.ok(start>=0);const body=start+'reset()'.length;let depth=0,quote='',escaped=false;
 for(let i=body;i<source.length;i++){
  const c=source[i];if(quote){if(escaped)escaped=false;else if(c==='\\')escaped=true;else if(c===quote)quote='';continue;}
  if(c==='"'||c==="'"||c==='`'){quote=c;continue;}if(c==='{')depth++;else if(c==='}'&&--depth===0)return source.slice(start,i+1);
 }
 assert.fail('actual reset method end');
}
class Node{
 constructor(registry){this.registry=registry;this.hidden=false;this.value='';this.textContent='';this.dataset={};this.children=[];this.listeners=new Map();this.classList={add(){},remove(){},toggle(){}};}
 set id(value){this._id=value;this.registry?.set(value,this);}get id(){return this._id;}
 append(...values){this.children.push(...values);}after(){}close(){}setAttribute(k,v){this[k]=String(v);}removeAttribute(k){delete this[k];}
 addEventListener(name,callback){this.listeners.set(name,callback);}
}
function result(total){return {items:[],total,groups:[],groups_total:0,analysis_pending_total:0,analysis_analyzed_total:0,analysis_missing_text_total:0};}
function harness(handler){
 const nodes=new Map(),field=id=>{if(!nodes.has(id))nodes.set(id,new Node());return nodes.get(id);};
 const current={user:{id:'synthetic-person',username:'synthetic-owner',tenant_id:'synthetic-tenant',company_id:'synthetic-company',role:'operator'},device:'synthetic-device',generation:1,page:1};
 const requests=[];field('workspace').dataset.page='leads';
 const model=fs.readFileSync(path.join(workspace,'enterprise-model.mjs'),'utf8');
 const signature=vm.runInNewContext(model.replace(/export /g,'')+'\ncustomerPrincipalSignature;',{Date,URL});
 const noop=()=>{};
 const context={JSON,Date,Promise,Object,Number,Map,Set,console,setInterval:()=>1,clearInterval:noop,$:field,el:()=>new Node(nodes),compactToolbar:new Node(),
  getUser:()=>current.user,getState:()=>({selected:current.device,deviceGeneration:current.generation,tasks:[{id:'synthetic-task',name:'合成原任务'}]}),customerPrincipalSignature:signature,pageVersion:()=>current.page,
  onPage:name=>{current.page++;field('workspace').dataset.page=name;},guard:fn=>fn,onError:error=>{throw error;},latest:async()=>{},document:{querySelector:()=>null},
  worklistTaskId:'',worklistTaskScopeToken:0,worklistTaskBinding:'',worklistSummaryScope:'',worklistSummaryAt:0,worklistSummaryRead:null,worklistSummarySerial:0,
  worklistSummary:{pending:null,priority:null,analysis:null,sent:null,all:null,analyzed:null,missing:null},worklistScope:'pending',groupBy:'note',groupKey:'',groupOffset:0,offset:0,total:0,groupsTotal:0,groupRows:[],rows:[],
  readGeneration:0,disposed:false,replyReadStatus:'ready',selectionId:'',externalSelectionId:'',selectedLead:null,worklistTimer:0,taskId:'',worklistRefreshing:false,
  settingsReturnFocus:null,poolRegionTimer:0,poolInputGeneration:0,keywordPool:null,poolReadPending:false,hydratedTaskId:'',savedForStart:null,savedForStartDevice:'',pendingSave:null,collectionUncertain:null,
  snapshotUnconfirmed:false,collectionBusy:'',aiProfileStatus:'unknown',aiProfile:{},aiConfig:null,keywordBusy:false,analysisBusy:false,updateState:null,updateBusy:false,updateUnknown:false,updateError:'',task:null,
  detailGeneration:0,leadOpenGeneration:0,handoffRecords:[],reply:null,replyNeedsCheck:false,queue:null,confirmedReplies:new Set(),confirmedAccount:'',keywords:[],selected:new Set(),libraryId:'',keywordApproval:null,keywordAttemptSignature:'',profileGeneration:0,
  startHeaderDate:noop,cancelPoll:noop,clearTimeout:noop,closeCollectionDialog:noop,syncKeywordAdjustment:noop,closeDetail:noop,renderContinuous:noop,renderKeywords:noop,
  action:async(action,data)=>{assert.equal(action,'leads_list','navigation must never dispatch writes/platform/tasks');requests.push(copy(data));return handler(data,context,current);},
  renderWorklist(){context.renderTaskCommentsScope();context.renderWorklistSummary();}
 };
 vm.createContext(context);
 const scopeNodes=source.split(/\r?\n/).find(line=>line.includes('const taskCommentScope=el('));assert.ok(scopeNodes);
 const navigationDeclaration=source.split(/\r?\n/).filter(line=>/^\s*let navigationPending\b/.test(line)).join('\n');
 const helpers=slice('  function worklistReadScope(',' function scheduleDetailViewport(');
 const load=slice(' async function loadWorklist(','\n  function renderWorklist(');
 vm.runInContext(navigationDeclaration+'\n'+scopeNodes+'\n'+helpers+'\n'+load+'\nglobalThis.api={onPage:onWorklistPage,openTaskComments,summary:refreshWorklistSummary,'+actualReset()+'};',context);
 return {context,current,field,requests,api:context.api};
}

test('actual reset removes old navigation numbers before another principal or device can read',async()=>{
 for(const change of ['principal','company','device','generation']){
  const h=harness(()=>result(7));await h.api.onPage('leads');await settle();assert.equal(h.field('pending-nav-count').textContent,'7');
  if(change==='principal')h.current.user={...h.current.user,id:'other-person',username:'other-owner'};
  if(change==='company')h.current.user={...h.current.user,company_id:'other-company'};
  if(change==='device')h.current.device='other-device';if(change==='generation')h.current.generation++;
  const before=h.requests.length;h.api.reset();
  assert.equal(h.field('pending-nav-count').textContent,'—',change+' must not retain another scope\'s number');
  assert.equal(h.requests.length,before,'reset cannot trigger a read or dispatch');
 }
});

test('task summary stays task scoped while the navigation is freshly global; zero and unknown are distinct',async()=>{
 let global=0;const h=harness(data=>result(data.task_id?2:global));await h.api.onPage('leads');await settle();assert.equal(h.field('pending-nav-count').textContent,'0');
 const beforeTask=h.requests.length;global=7;await h.api.openTaskComments('synthetic-task');await settle();
 assert.equal(h.field('pending-count').textContent,'2','task tab is the original task count');
 assert.equal(h.field('pending-nav-count').textContent,'7','original task total must not replace or freeze global total');
 assert.equal(h.requests.slice(beforeTask).filter(data=>data.limit===1&&data.worklist==='pending'&&!Object.hasOwn(data,'task_id')).length,1,'exactly one mature global read supplies the task navigation');
 const unknown=harness(data=>{if(data.limit===1&&!data.task_id&&data.worklist==='pending')throw Error('synthetic unavailable');return result(data.task_id?2:0);});
 await unknown.api.openTaskComments('synthetic-task');await settle();
 assert.equal(unknown.field('pending-count').textContent,'2');assert.equal(unknown.field('pending-nav-count').textContent,'—','unavailable global total is not zero or the task count');
 for(const invalid of [null,false,'0',-1,1.5,Number.MAX_SAFE_INTEGER+1]){
  const malformed=harness(data=>result(data.task_id?2:invalid));await malformed.api.openTaskComments('synthetic-task');await settle();
  assert.equal(malformed.field('pending-count').textContent,'2');
  assert.equal(malformed.field('pending-nav-count').textContent,'—',`non-safe global total ${String(invalid)} must stay unknown`);
 }
});

test('late old global replies and failed current reads cannot repaint another scope or preserve a stale number',async()=>{
 const late=[];let mode='old';const h=harness(data=>{
  if(data.limit===1&&mode==='old'){const gate=deferred();late.push(gate);return gate.promise;}
  if(data.limit===1&&data.worklist==='pending'&&mode==='failed')throw Error('synthetic current read failed');
  return result(0);
 });
 await h.api.onPage('leads');await settle();assert.equal(late.length,3);
 h.current.user={...h.current.user,company_id:'new-company'};h.current.device='new-device';h.current.generation++;h.api.reset();mode='new';
 await h.api.onPage('leads');await settle();assert.equal(h.field('pending-nav-count').textContent,'0');
 late.forEach(gate=>gate.resolve(result(99)));await settle();assert.equal(h.field('pending-nav-count').textContent,'0','late previous company total must not paint');
 mode='failed';await h.api.summary(h.context.readGeneration,h.current.device);await settle();
 assert.equal(h.field('pending-nav-count').textContent,'—','failed current total must replace stale numeric zero with unknown');
});
