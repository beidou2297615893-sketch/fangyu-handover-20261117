# Phase12 公司交接本机准备层：独立网关审核

结论：当前冻结源码上的 4 项独立代表测试通过。实际使用临时 SQLite、Core、BusinessExecutor、员工网关及 CompanyHandoffPreparation；未发现新的生产阻断。没有执行云查询、注册、平台联系、模型、财务或部署。本轮只增加独立测试与证据，没有修改生产源码或旧测试。

## 验证范围与结果

| 代表链路 | 真实执行与结论 |
| --- | --- |
| 缺记录 GET、最新来源未 ACK、合法准备 | 缺记录 GET 不写表、不发行 key；最新来源未 ACK 时拒绝，不能回退旧 ACK。准备成功仅新增专属 origin 元数据，原业务实体不变；完整云 register 候选体的本地摘要和预期 channel 派生吻合。原文、裸 UID、联系方式及凭证不进入持久 origin 或公共投影。 |
| 首端身份及构造拒绝、提交后异常、历史 unknown | 伪造请求身份、设备和 vault 绑定在实际执行前拒绝；构造错误安全返回 403/false。GET 通用异常为纯读 503/false。真实准备提交后注入异常返回 409/null，保留单 origin；既有 unknown 不因 GET 或换 key 解锁。 |
| 提交后的身份/设备/环境变化 | 实际提交后再改变 vault 环境、公司、状态、设备、managed 环境、执行器及 SQL 角色/禁用/绑定，最终网关拒绝公共成功返回，保留原记录。恢复原可信上下文后仅 GET 可找回同 origin。 |
| 两个独立 Core/BusinessExecutor 同 key 并发 | 只有一个 origin；至少一个请求真实完成首次准备。另一个可幂等成功，也可在两次快照变化时 409/false，或在提交边界不明时 409/null。随后 GET 找回原 key，明确顺序使用同 key 得到 replay；当前来源变更后，旧 key 与新 key 都不能创建新 origin。 |

查询响应的 `mutation_committed:false` 只说明本次查询未写入；并发请求的明确拒绝同样只限定这次请求，不能证明另一实例或历史公司操作未执行。`no_dispatch:true` 的范围始终是 `this_preparation_only`，`previous_company_dispatch_status` 仍为 `unknown`。本机 `source_ack_recorded:true` 保留旧 ACK 的事实，但 `source_cloud_binding_verified:false`，不能显示为公司归档、资源部接收或财务成功。

准备记录仍在客户撤回或来源变化后保存历史事实；当前 `preparation_usable` 和 `blocked_reason` 决定是否可以继续。客户 UID 冲突可先被成熟同意检查判为 `consent_unavailable`，无需强迫降为较弱的 `source_changed` 文案。

## 执行证据与准确计数

命令（在项目目录执行）：

```text
C:/Users/rmsama/miniconda3/python.exe -m unittest discover -s work/product-upgrade-20261009/audits -p test_company_handoff_preparation_gateway_independent.py -v
```

最终日志：`company-handoff-preparation-gateway-independent-final-green.log`，4/4，33.958 秒。耗时包含 SQLite 提交争用和保守未知分支；不是性能、真实云 30 秒事务、吞吐或商业规模的验收。未重复运行未变化的旧矩阵，独立 4 项不擅自并入根窗口 335 项总数。

保留三类首次日志以便审计：来源阻断文案断言过窄；要求两个并发同 key 都成功；把可能已提交的异常强制要求为 false。这些均是独立测试预期收紧，生产契约原已允许保守拒绝/未知，没有因此修改生产，也不登记为产品缺陷由修改关闭。

原来源全链、本机 ACK 与专属事务由实际 helper 执行。测试显式阻断 socket、平台进程、BusinessExecutor 云调用及泛型产品 receipt，避免把 mock 的公司成功当实际结果。根窗口另做跨语言 canonical 算法比较和隔离 GUI；本报告不将其重复计为本轮 4 项，也不把离线算法核对视为云注册或权威归档。

## 冻结 SHA256

| 文件 | SHA256 |
| --- | --- |
| `work/app/src/assistant/company_handoff_preparation.py` | `1C1EB336669D8CE39B5E16DC54501F397CEF30C8E606993CA961D6A977C3359F` |
| `work/app/src/assistant/product_workspace.py` | `853D37736A039A7E160413FA277622DEE1C277FB136253112547AF88D1539012` |
| 独立测试 `test_company_handoff_preparation_gateway_independent.py` | `23A5733436C3E2F6D416CA7EDF593462A3546AD8545A54960123948D60255F7D` |
| D 的实际合成 fixture `company-handoff-preparation-actual-fixture.json` | `CE2CAF45DCC8E8AA307E001CD3899F83D5267E3EBBC37C2002FB9C484D5595A2` |

上述生产两源在本轮最终测试前后哈希相同。独立报告、日志及逐文件摘要见同目录 `company-handoff-preparation-gateway-independent-manifest.json`。

## 下一窄切片边界

下一步只读核对必须从持久 origin 派生原公司动作/key/channel/hash，不能由前端另填、自动换号或重放注册。现有 `_ai_cloud` 会进入会话刷新路径；不能把它直接作为“只有一次状态查询、零副写入”的证明。有效现有会话的只读 status 桥需要独立排除 refresh、凭证写入和身份校验副请求；过期会话应要求用户显式连接续期。该层尚不属于本轮完成项。
