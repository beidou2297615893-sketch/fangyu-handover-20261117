# Phase26 owner 元数据补证路线只读审查

结论：**有条件可行，值得先做最小机制代表。** 在同一个经过创建时间核对的 Windows process HANDLE 上读取 `OpenProcessToken(TOKEN_QUERY) → GetTokenInformation(TokenUser)`，能取得该进程关联令牌的用户 SID，避开 WMI provider 的 GetOwnerSid 路径；是新的 OS 身份事实，不是按 Chrome/Python family、路径或 PID 推断 owner。它不能保证这台机器所有相关进程都可读，也尚未证明能关闭 0464/原 8070 的阻断。当前不开发、不调用 API、不扫描进程或重开浏览器。

## 成熟复用点与语义

- [private_evaluation.py:139](C:/积木软件工坊/项目/方隅公寓客户版/work/app/src/assistant/private_evaluation.py:139) 的 `current_windows_sid()` 已用本机 ctypes/Advapi32 读取当前进程 token，限定 TOKEN_QUERY，二次 TokenUser buffer、ConvertSidToStringSidW、LocalFree 与 token CloseHandle。可复用这条成熟 API/释放模式；函数当前固定 GetCurrentProcess、没有目标进程创建时间绑定，**不能原封不动作为另一个 PID 的 SID 查询器**，本轮不改它。
- [owned_job.py:200](C:/积木软件工坊/项目/方隅公寓客户版/work/product-upgrade-20261009/diagnostics/developer-original-identity/owned_job.py:200) 已复用 GetProcessTimes 核 native FILETIME 与 CIM 创建时间（同 epoch、原 0..9 个 100ns rounding 容差），再核指定 Job。这是目标身份绑定成熟点，不是按 PID 白名单。
- [profile_process_probe.ps1:38](C:/积木软件工坊/项目/方隅公寓客户版/work/product-upgrade-20261009/diagnostics/developer-original-identity/profile_process_probe.ps1:38) 当前 GetOwnerSid 非零/异常留下 owner null，未保存错误类别。备选 token 查询应补此缺字段，不覆盖一个有效且冲突的 WMI SID，也不能补 parent/created 缺口。
- [runtime_identity.py:98](C:/积木软件工坊/项目/方隅公寓客户版/work/product-upgrade-20261009/diagnostics/developer-original-identity/runtime_identity.py:98) 只核实际 shim/base/cfg/WebView/source 文件，不读 SID。继续用于首尾运行材料固定；路径与文件 hash 均不能代替 token owner 事实。

官方明确 OpenProcessToken 对关联进程 token 的读取要求 PROCESS_QUERY_LIMITED_INFORMATION，而 TokenUser 信息要求 TOKEN_QUERY；TokenUser 表示关联用户，不是 `TOKEN_OWNER` 默认安全描述符 owner，也不是任意对象 DACL 的所有者。该路线的字段应解释为 **process token user SID / 执行用户身份**，不能扩大成 profile 文件拥有权或平台登录证明。[OpenProcessToken](https://learn.microsoft.com/en-us/windows/win32/api/processthreadsapi/nf-processthreadsapi-openprocesstoken)、[GetTokenInformation](https://learn.microsoft.com/en-us/windows/win32/api/securitybaseapi/nf-securitybaseapi-gettokeninformation)、[TOKEN_USER](https://learn.microsoft.com/en-us/windows/win32/api/winnt/ns-winnt-token_user)

## 最小安全边界

1. 只对当前完整枚举行中的有效 PID、有效原创建时间查询；同一原 process HANDLE 持有期间完成创建时间、token、状态核验，不在中间仅凭 PID 重新打开后继进程。请求最小 `PROCESS_QUERY_LIMITED_INFORMATION | SYNCHRONIZE`，不请求 ALL_ACCESS/VM_READ，不启 SeDebug，不提权/杀进程/改令牌。**只有 0x1000 的旧查询句柄可读 token，但不能承担等待状态核验**；SYNCHRONIZE 是 process 权限，token 不支持此权限。[进程访问权限](https://learn.microsoft.com/en-us/windows/win32/procthread/process-security-and-access-rights)、[令牌访问权限](https://learn.microsoft.com/en-us/windows/win32/secauthz/access-rights-for-access-token-objects)
2. 先 GetProcessTimes 与原 CIM 创建时间匹配，并对同句柄 `WaitForSingleObject(handle, 0)` 确认未 signaled；读 token 后再次核同句柄创建时间/状态。WAIT_TIMEOUT 仅表示该次检查仍运行；WAIT_OBJECT_0/FAILED/创建时间不符都不能把新 SID 加入可用 owner。若已经退出，本路线只报未知，不顺手排除该行或授权 vacancy。FILETIME 比较复用原 epoch/rounding，不重新发明时间规则。[GetProcessTimes](https://learn.microsoft.com/en-us/windows/win32/api/processthreadsapi/nf-processthreadsapi-getprocesstimes)、[WaitForSingleObject](https://learn.microsoft.com/en-us/windows/win32/api/synchapi/nf-synchapi-waitforsingleobject)
3. TokenUser 查询严格核调用结果、返回长度与上限，再以 native SID API转换有效 SID；借用成熟 buffer 模式但不把目标句柄当 current process。ConvertSidToStringSidW 返回分配需 LocalFree，token/process HANDLE 都在 finally 关闭，所有中途失败也核释放；关闭失败不假报补证完整。[ConvertSidToStringSidW](https://learn.microsoft.com/en-us/windows/win32/api/sddl/nf-sddl-convertsidtostringsidw)
4. SID 可以不等于当前 SID：这是“其他执行用户”的真实事实，应继续原分类/profile/Job门禁，不拒绝事实本身也不冒充本人。当前 native 主体的 process TokenUser 与既有 current SID 若不一致须未知；有效 WMI SID 与同创建时间 token SID 冲突须未知，不由哪个来源看起来有利就覆盖。不能仅凭 SID 相同豁免其 profile 占用。
5. 补证后仍走成熟完整 executable/argv/profile/runtime/真实 Job 校验。结束前取完整新 snapshot，当前范围的新行或原行创建时间/身份变化必须重核，旧补证不得移植到复用 PID；权限拒绝、TokenUser失败、长度/转换错误、source/runtime变更均保留 unknown。没有“OpenProcess 失败所以进程已退出”的捷径。raw SID、PID、路径、argv/token buffer 仅内存，保存有限 reason/owner_current/创建时间相符与状态布尔；不序列化 token、SID 或客户端参数授予。

此补证比反复同样 WMI 重试更有独立证据价值，但最后完整 snapshot 只是边界采样，不能保证所有进程此后永不变化。不得把一次补证变成缓存许可或永久 vacancy。当前 global unknown 阻断政策不因本报告改变。

## 最小代表与继续条件（计划，未执行）

首选最多 3 组合成 recording-native 代表，复用实际 ctypes SID/创建时间模式，不启动 Chrome/WebView：

- 同一固定句柄/原创建时间且前后仍活跃、WMI owner null、真实 TokenUser 查询成功，补证为独立 `token_user` 事实；profile 不属于当前目标才可按原分类排除，不靠 family。成功路径及每一资源获取失败后的关闭均核。
- 相同 PID 不同创建时间、token query拒绝/坏长度/转换失败、同句柄退出、WMI/token SID冲突，补证不可用且仍 unknown；旧 SID 不得传到后继行。
- 最后完整 snapshot 出现新相关进程或绑定变化，拒旧事实；当前用户之外的 SID 不伪装本人，不能自授 Job 或 profile 豁免。

这些机制绿后，再由 root 审固定候选并决定一次 **无账号、固定 sleep 子进程** Native代表：同创建时间的 WMI SID 与 TokenUser 对照，仅保存 agree/owner_current/state/hash，0原库/DPAPI/browser/platform URL。若 WMI/token 对照不同或权限不可取得，则路线应停止作为该环境 owner 补证，不改未知为成功。该代表仍不能证明 0464 历史行能读 token，更不能证明原账号恢复；无需为了候选先重复打开原小红书。

## 本轮证据固定与未验

静读源码 SHA256：private_evaluation `C7081FCF1B7AE8EFE2CB3615CBA2495C5CCBE410854E80956A2C6A0DBEE66621`；profile_process_probe `73E1D2D4FB0CFF45A03C979995E50B6FBEBC3F4B04B72F003F69E00CDDE56241`；profile_occupancy `FF750FDF9C8D6B343101B286F0169508E12E31E1B2964A668141865D1D6A4C2B`；owned_job `02E3938BA997AFF32DC08A99D7CB7CB32176E5BB738FE38428B22CC1903E3BDD`；runtime_identity `944A33C1DF301AE97425AF17C7D7769033808D76DA02BF39F0B0E330FE805B15`。

本轮仅新建本报告、读取上述源码与官方 primary 文档；0测试、CIM/API/Native/browser执行，0原数据、DPAPI、CLI、平台/云/模型调用，未改任何冻结源。官方文档支持 API 与权限可行性，不是实际 SID 查询成功证据。0464 WMI 缺失原因、8070 是否同因、原账号 UID/恢复仍未知，总目标未完成。
