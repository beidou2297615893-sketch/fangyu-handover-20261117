/* Synthetic actual createService/createStore; SDK-interface memory callbacks.
 * No network, provider, real account or node-sdk transaction-engine claim. */
'use strict';
const readline=require('node:readline');
const assert=require('node:assert/strict');
const {fixture}=require('../../cloud/workspace/handoff-operation-status-fixture.cjs');
let engine=null,registerCalls=0;
async function command(input){
 if(!engine)engine=await fixture();
 if(input.kind==='sync'){
  const result=await engine.call('contact_events_sync',{events:[input.event]},'fixture-source-device-token');
  assert.equal(result.status,200);return {result,register_calls:registerCalls};
 }
 if(input.kind==='register'){
  registerCalls++;
  if(input.corrupt_source){engine.data.mutateDoc(engine.doc('contact_','event:'+input.data.source_event_id),doc=>{
   doc.record.lead.comment_id='fixture-changed-comment-after-source-read';return doc;
  });}
  if(input.lose_response)engine.loseNextResponse();
  const result=await engine.call('acquisition_channel_register',input.data);
  return {result,register_calls:registerCalls};
 }
 if(input.kind==='read'){
  engine.data.resetOperations();const before=engine.data.snapshot();
  const result=await engine.call(input.operation,input.data);
  assert.equal(before,engine.data.snapshot());
  const operations=engine.data.operations();for(const callbacks of operations)for(const counts of callbacks)assert.equal(counts.writes,0);
  return {result,operations,stored_documents_unchanged:true,register_calls:registerCalls};
 }
 if(input.kind==='restart'){engine.restart();return {register_calls:registerCalls};}
 if(input.kind==='counts')return {register_calls:registerCalls,channels:[...engine.data.docs().values()].filter(doc=>doc?.channel_id&&doc?.source_event_id).length};
 throw Error('unknown synthetic fixture command');
}
const lines=readline.createInterface({input:process.stdin,crlfDelay:Infinity});
(async()=>{for await(const line of lines){try{process.stdout.write(JSON.stringify(await command(JSON.parse(line)))+'\n');}
 catch(error){process.stdout.write(JSON.stringify({fixture_error:error.message,register_calls:registerCalls})+'\n');}}})()
 .catch(()=>{process.exitCode=1;});
