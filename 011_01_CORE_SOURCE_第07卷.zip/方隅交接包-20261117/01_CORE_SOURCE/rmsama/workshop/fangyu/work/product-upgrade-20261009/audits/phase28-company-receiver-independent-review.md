# Phase28 本机资源部接收独立审查

结论：必要两组独测最终 **2/2 GREEN，2.087s**，可以冻结本轮独立证据。首跑真实 P2 已闭：接收标签中的 `微\u200b信号：abc123` 原会经成熟规范化后作为 `[REDACTED:wechat_id]` 返回；B 仅在新 receiver 的 `_label` 补组合标签检测，未修改成熟导出器、transport、gateway 或本独测断言。本轮不代表真实资源部接收、原账号恢复、平台送达或正式部署验收。

## 两个独立方法

1. `test_rehashed_unknown_metadata_cannot_rebind_read_repair_or_repeat_ack`：使用真实临时 Core，原接收本机准备已持久化后、固定 SDK worker 前注入中断。原行 `unknown`。逐项改 actor、device、owner、environment、company、key、payload hash、SQL tenant；重算 `record_hash`，改 key 时同时重算 payload hash。GET 和原 ACK 均拒绝，零 cloud callback、SQL trace 无 DML，原损坏行没有被修补、删除或新建。仅在测试夹具恢复原行后，原号 GET 返回 unknown/null，原 ACK 只读核对，同一固定 key，实际公司 receipt 调用仍为 0。
2. `test_malformed_write_echo_and_status_never_prove_success_or_leak_private_labels`：实际固定 worker 先提交一条 ACK，边界上将回显 actor 改为另一接收人，helper 保守报结果未知。本机原行保留 unknown；真实原 status 可读 recorded，GET 不更新该历史元数据。六种坏 status（actor、unknown 带历史、历史状态、当前状态与 detail 冲突、现金 0、私有额外字段）均拒绝。用途与接收部门隐藏联系方式/secret 均拒绝。真实 no-refresh transport 对已获得的实际 fixture envelope 的错 company、额外 token 字段拒绝，写回执错误为 mutation unknown，错误文本不泄漏注入值。最后 GET/原 ACK 仍只核对同原号，公司计数 **register1/submit1/receipt1/channel1**，没有第二次 ACK；现金与已付提成始终 null。

## 首 RED 与当前源

- 首跑 `phase28-company-receiver-independent-first.txt`：2 方法，1 通过、1 失败，2.052s。失败仅为 recipient_name 隐私子例；不能把包含该失败的方法计为绿色。首测试 SHA `20B095CEE4F70EDED827D557D5AE5891AD9B344C3504F89E8141482E4DFBEAE1`，修后未改断言/文件。
- 首 receiver SHA `D23B9E7B89DD5122CBBB67D1F615C18FC098B3E23B3F55160D75656363B68184`；最终 receiver SHA `FD11349D3B9EBAB724B7807DD68790FEB5FEE87A6CDF2B9F466313C4AD1DC568`。当前 `_label` 先复用成熟规范化，再检测“号/id/号码 + 分隔符”，普通 `[REDACTED:wechat_id]` 的漏项路径也由静态规则覆盖；只对零宽代表做了运行断言。
- transport `D5466C65B58EC04078EB713E6F37AA35033D7BE67AA4A64EF64C79C60D632275`、product_workspace `C68E0EEA7DCB6283F0E8F0A8A352107E4F919EAD29D1789799BABDA587F5E155`、acquisition_exports `B41BB719972020ED790ED937185201E1130C260CE8DCDF9E5D9FDB2287A21731` 字节保持。
- 首跑源与测试的字节副本在 `work/product-upgrade-20261009/backups/phase28-company-receiver-independent/1`，复制时再次核 SHA。首前 sources 与 first-snapshot 指明对应版本；最终 green-before/green-after sources 八项完全相同。

## 验证边界与计数

只复用 B 的 `ReceiverFixture` 和生命周期，不继承/发现其测试方法；本轮唯一新增运行计数为 **2 方法**，不叠计 B3、旧相邻3、C云3或 GUI。真实临时 Core/SQLite/helper/transport 方法执行，纯读用实际 SQL trace 和 dump 对照。公司服务由固定本地 Node worker 调用实际 createService/createStore，底层为内存 SDK 兼容 adapter；不是实际 CloudBase SDK 事务引擎、真实网络、并发时序或部署的证明。

最终两组运行时 tracked JSON 仍为 CA12，该 JSON 没有作为独测输入；独测直接调用实际夹具生成器。B 随后将同路径八 DTO 重产为 `34B182D677DBA73668DC0DB014D227E369935C8D60D7CB63B37A5ACE8E17F2A9`，绑定新 receiver，旧 CA12 已保存在 `backups/phase28-receiver-backend/6`。最终 manifest 分列该次合法证据更新，不把 CA12 metadata 冒称为新 `_label` 执行证据，也不把重产计为 C 的额外测试。没有重跑 B3、旧矩阵或 GUI，没有读取真实 DATA、DPAPI、Cookie、账户、CLI、浏览器或凭据。本独审只新增自有测试、日志、备份和报告；产品修复由 B 完成。

工作目录：`C:/积木软件工坊/项目/方隅公寓客户版/work/product-upgrade-20261009/audits`。报告、测试、首/最终日志和对应源 SHA 由同目录 `phase28-company-receiver-independent-final-hashes.json` 绑定；最终冻结源与后续合法新阶段源码应分别核验。
