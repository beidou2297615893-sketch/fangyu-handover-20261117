"""Fix isolated QA inputs and future desktop CODE pins; do not approve a Run."""
from pathlib import Path
import hashlib
import json
import ast
import difflib

PROJECT = Path('C:/积木软件工坊/项目/方隅公寓客户版')
WORK = PROJECT / 'work'
ASSEMBLY = WORK / 'owner-upgrade-normal-root-assembly/joint-v1'
QA = WORK / 'owner-upgrade-normal-joint-candidate'
ENTRY = WORK / 'owner-primary-entry-integration-candidate/history/code-v1/desktop/desktop_entry.py'


def sha(raw):
    return hashlib.sha256(raw).hexdigest().upper()


def pin(path, expected=None):
    raw = path.read_bytes()
    actual = sha(raw)
    if expected is not None and actual != expected:
        raise RuntimeError('Fixed input changed: ' + str(path))
    return {'path': str(path), 'bytes': len(raw), 'sha256': actual}


def save_once(path, raw):
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        if path.read_bytes() != raw:
            raise RuntimeError('Prepared inputs already differ')
    else:
        with path.open('xb') as stream:
            stream.write(raw)
    if path.read_bytes() != raw:
        raise RuntimeError('Prepared input readback differs')


def main():
    assembly_file = ASSEMBLY / 'ASSEMBLY-INPUTS.json'
    assembly_pin = pin(assembly_file, '3A66E2BFC289FDE1FEB31F6B5C51DE53802629E5C30DB26B2DF738CDB2C5A23A')
    assembly = json.loads(assembly_file.read_bytes())
    for item in assembly['files'] + assembly['formal_protected']:
        if pin(Path(item['path'])) != item:
            raise RuntimeError('Actual assembly or formal parent changed')
    v2_file = QA / 'CARRIER-FROZEN-V2.json'
    v2_pin = pin(v2_file, '32B21005BA72F2E47D559D908FCCFC5DC0D4BEED7F3038594C125327D97706BD')
    v2 = json.loads(v2_file.read_bytes())
    prepared = []
    for item in v2['artifacts']:
        actual = pin(QA / item['path'])
        if actual['bytes'] != item['bytes'] or actual['sha256'] != item['sha256']:
            raise RuntimeError('Carrier V2 input changed')
        prepared.append(actual)
    source = Path(assembly['source_root'])
    source_paths = ('app.py', 'desktop.py', 'platform_cli.py',
        'assistant/self_operating_read.py', 'assistant/owner_normal_close.py',
        'assistant/owner_primary_entry.py', 'assistant/owner_instance_platform_upgrade.py',
        'assistant/owner_instance_platform_upgrade_writer.py')
    pins = {relative: pin(source / relative)['sha256'] for relative in source_paths}
    original = ENTRY.read_bytes()
    if len(original) != 15022 or sha(original) != 'B657C07DD8A84B3A15D2AC5C8F6185F2D91C093C3F66AB41F8092743FC3DEE3B':
        raise RuntimeError('Original reviewed desktop candidate changed')
    before = 'HOST_PINS={}'
    after = 'HOST_PINS={\n' + ''.join("    SOURCE/" + repr(relative) + ':' + repr(pins[relative]) + ',\n'
        for relative in source_paths) + '}'
    text = original.decode('utf-8')
    if text.count(before) != 1:
        raise RuntimeError('Expected empty HOST_PINS is not unique')
    configured = text.replace(before, after, 1)
    if configured.replace(after, before, 1) != text:
        raise RuntimeError('HOST pin fill is not the sole delta')
    ast.parse(configured)
    configured_bytes = configured.encode('utf-8')
    desktop_file = ASSEMBLY / 'desktop/desktop_entry.py'
    save_once(desktop_file, configured_bytes)
    delta = ''.join(difflib.unified_diff(text.splitlines(True), configured.splitlines(True),
        fromfile='reviewed-entry-v1/desktop_entry.py', tofile='root-fixed-host-pins/desktop_entry.py')).encode()
    save_once(ASSEMBLY / 'desktop/HOST-PINS-DELTA.patch', delta)
    event = WORK / 'desktop-python/Lib/site-packages/webview/event.py'
    event_pin = pin(event)
    formal = list(assembly['formal_protected'])
    for path in (WORK / 'self-operating-pilot/self-operating-instance.json',
                 WORK / 'self-operating-pilot/data/owner-data-instance.json',
                 WORK / 'self-operating-pilot/component-review.json',
                 WORK / 'desktop-self-use-entry/desktop_entry.py'):
        formal.append(pin(path))  # Only existing identity/CODE metadata; no real DB/cookies.
    absent = [str(WORK / 'app/src' / relative) for relative in (
        'assistant/owner_normal_close.py', 'assistant/owner_primary_entry.py',
        'assistant/owner_instance_platform_upgrade.py',
        'assistant/owner_instance_platform_upgrade_writer.py',
        'assistant/owner_channels_preview_archive.py')]
    if any(Path(path).exists() for path in absent):
        raise RuntimeError('Expected new formal modules are no longer absent')
    inputs = {'schema': 'owner_normal_joint_inputs_v1',
        'scope': 'owned_normal_Factory_AppServer_Core_SQLite_close_writer_same_key_recovery',
        'qa_directory': str(QA / 'qa-normal-joint-v2'), 'configuration_complete': True,
        'source_root': str(source), 'guarded_runtime': assembly['guarded_runtime'],
        'event_file': str(event), 'writer_sha256': pins['assistant/owner_instance_platform_upgrade_writer.py'],
        'files': assembly['files'] + prepared + [assembly_pin, v2_pin, event_pin, pin(desktop_file)],
        'formal_protected': formal, 'formal_absent': absent,
        'guarded_runtime_tree_sha256': assembly['guarded_runtime_tree_sha256'],
        'Root_exact_gate_required': True, 'QA_executed': False,
        'desktop_host_pin_delta_only': True}
    raw = (json.dumps(inputs, ensure_ascii=False, sort_keys=True, indent=2) + '\n').encode()
    save_once(QA / 'QA-INPUTS.json', raw)
    receipt = {'schema': 'source48_root_normal_inputs_prepared_v1',
        'inputs_path': str(QA / 'QA-INPUTS.json'), 'inputs_sha256': sha(raw),
        'files_count': len(inputs['files']), 'formal_protected_count': len(formal),
        'formal_absent_count': len(absent), 'event': event_pin,
        'configured_desktop': pin(desktop_file), 'desktop_parent_sha256': sha(original),
        'HOST_PINS': pins, 'host_pin_delta_sha256': sha(delta),
        'Root_Run_approval_created': False, 'business_or_Native_or_QA_executed': False,
        'formal_or_current_app_modified': False}
    receipt_raw = (json.dumps(receipt, ensure_ascii=False, sort_keys=True, indent=2) + '\n').encode()
    save_once(ASSEMBLY / 'NORMAL-INPUTS-PREPARED.json', receipt_raw)
    print(json.dumps({key: receipt[key] for key in ('inputs_path', 'inputs_sha256',
        'files_count', 'formal_protected_count', 'formal_absent_count',
        'Root_Run_approval_created', 'formal_or_current_app_modified')}, ensure_ascii=False))


if __name__ == '__main__':
    main()
