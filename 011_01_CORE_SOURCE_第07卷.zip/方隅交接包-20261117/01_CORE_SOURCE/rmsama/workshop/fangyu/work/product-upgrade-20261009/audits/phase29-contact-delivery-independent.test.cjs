'use strict';
// Two independent privacy/scope methods over the actual service/store entry.
// Synthetic private-document corruption recomputes its checksum deliberately;
// checksums alone must not substitute for an immutable operation/context anchor.
const test=require('node:test'),assert=require('node:assert/strict'),crypto=require('node:crypto');
const {fixture,PUBLISH,REVEAL}=require('../../cloud/workspace/contact-delivery-fixture.cjs');
const canonical=v=>Array.isArray(v)?'['+v.map(canonical).join(',')+']':v&&typeof v==='object'
 ?'{'+Object.keys(v).sort().map(k=>JSON.stringify(k)+':'+canonical(v[k])).join(',')+'}':JSON.stringify(v);
const hash=v=>crypto.createHash('sha256').update(typeof v==='string'?v:canonical(v)).digest('hex');
const body=row=>{const {_id,companyId,record_hash,...value}=row;return value;};
const seal=row=>({...row,record_hash:hash(body(row))});
const privateKey=key=>'fangyu_workspace_private/contact_vault_'+hash(['fixture-company',key]);
const rejected=response=>[403,409].includes(response.status)&&response.data.mutation_committed===false;
const noWrites=f=>{for(const batch of f.data.operations())for(const callback of batch){assert.equal(callback.writes,0);assert.ok(callback.reads<=100);}};

test('self-consistent original operation/audit corruption cannot claim a different actor, device or derived id',async()=>{
 const f=await fixture();assert.equal((await f.call(PUBLISH,f.publishBody)).status,200);
 const docs=f.data.docs(),op=[...docs].find(([,row])=>row.action===PUBLISH&&row.state==='recorded'),
  event=[...docs].find(([,row])=>row.operation_id===op[1].id&&row.action===PUBLISH),
  vault=[...docs].find(([,row])=>Object.hasOwn(row,'ciphertext'));
 assert.ok(op&&event&&vault);const offenders=[];
 for(const variant of ['actor_other','device_other','derived_id_other']){
  let alteredOp=structuredClone(op[1]),alteredEvent=structuredClone(event[1]),alteredVault=structuredClone(vault[1]),extra=null;
  if(variant==='actor_other'){alteredOp.actor='resource';alteredEvent.actor='resource';}
  if(variant==='device_other')alteredOp.device_id='fixture-resource-device';
  if(variant==='derived_id_other'){
   const foreignId=hash(['fixture-company','fixture-env','resource',PUBLISH,f.publishBody.idempotency_key]);
   alteredOp.id=foreignId;alteredEvent.operation_id=foreignId;alteredVault.publish_operation_id=foreignId;extra=privateKey('event:'+foreignId);
  }
  alteredOp.audit_hash=hash(body(alteredEvent));
  f.data.mutateDoc(op[0],()=>seal(alteredOp));f.data.mutateDoc(event[0],()=>seal(alteredEvent));
  f.data.mutateDoc(vault[0],()=>seal(alteredVault));if(extra)f.data.mutateDoc(extra,()=>seal(alteredEvent));
  f.data.resetOperations();const before=f.data.snapshot(),read=await f.status(PUBLISH,f.publishBody.idempotency_key);
  assert.equal(f.data.snapshot(),before);noWrites(f);
  if(!rejected(read))offenders.push({variant,status:read.status,confirmed:read.data.delivery?.original_execution_confirmed});
  f.data.mutateDoc(op[0],()=>structuredClone(op[1]));f.data.mutateDoc(event[0],()=>structuredClone(event[1]));
  f.data.mutateDoc(vault[0],()=>structuredClone(vault[1]));if(extra)f.data.remove(extra);
 }
 assert.deepEqual(f.counts(),{encrypts:1,decrypts:0});
 assert.deepEqual(offenders,[],'a recomputed checksum must not grant a different original operation');
});

test('foreign vault channel, owner or encryption context is rejected before receiver Decrypt or attempt commit',async()=>{
 const f=await fixture();assert.equal((await f.call(PUBLISH,f.publishBody)).status,200);
 const vault=[...f.data.docs()].find(([,row])=>Object.hasOwn(row,'ciphertext'));assert.ok(vault);
 const offenders=[];
 for(const [index,variant]of ['channel_other','source_other','context_other'].entries()){
  const altered=structuredClone(vault[1]);
  if(variant==='channel_other')altered.channel_id='hc_'+'b'.repeat(64);
  if(variant==='source_other')altered.source_owner='resource';
  if(variant==='context_other')altered.encryption_context={...altered.encryption_context,channel:'hc_'+'b'.repeat(64)};
  f.data.mutateDoc(vault[0],()=>seal(altered));f.data.resetOperations();
  const before=f.data.snapshot(),beforeCounts=f.counts();
  const result=await f.call(REVEAL,{...f.revealBody,idempotency_key:'phase29-independent-vault-'+index},'resource');
  if(!rejected(result)||f.data.snapshot()!==before||f.counts().decrypts!==beforeCounts.decrypts)
   offenders.push({variant,status:result.status,plaintext_returned:!!result.data.delivery?.contact_values,
    decrypts:f.counts().decrypts-beforeCounts.decrypts,private_snapshot_changed:f.data.snapshot()!==before});
  f.data.mutateDoc(vault[0],()=>structuredClone(vault[1]));
 }
 assert.deepEqual(offenders,[],'stored vault/context must remain bound to the current authorized channel before KMS');
 assert.deepEqual(f.counts(),{encrypts:1,decrypts:0});
});
