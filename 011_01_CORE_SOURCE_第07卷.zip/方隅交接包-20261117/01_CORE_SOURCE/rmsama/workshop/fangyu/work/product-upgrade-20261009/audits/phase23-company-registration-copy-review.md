# Phase23 原准备提示文案差异独审

结论：这处文案差异可接受。它将“未向公司发送”的范围明确限定为保存本机准备这一步；当前登记尚待确认、unknown 或 recorded 时，改为引用本页公司草稿核对记录。不会把这些状态描述为公司从未登记，也没有把 unknown 补成未执行、把历史 recorded 补成当前可交付。

本次仅阅读生产源码及 root 专属备份的差异，并新增本报告；未修改生产、原独 4 test/report/manifest，未运行测试、完整矩阵或 GUI，未读原 DATA 或访问真实公司。root 报告的实际 GUI 丢响应及原号读回问题属于其独立证据，不由本报告冒领验证。

## 精确差异与当前源码

`work/app/src/web/workspace/upgrade-operations-ui.mjs` 当前 SHA256：

`4A0CE6A8EE9A587E0A9959E91658B4370658C61FCC7DBB2006586A63E8E6B075`

备份 `work/product-upgrade-20261009/backups/company-registration-copy/1/upgrade-operations-ui.mjs` SHA256：

`139374E9095481B77E073ECCF0DC8CEB62A9E6C04A13DBE3797D717942228CB9`

`git diff --no-index` 确认只有原 prepared 展示区一个差异块：原 480 行提示被本地展示变量和条件文案替代，当前位于 480–481 行。

- `registrationUnconfirmed` 或 `registration.state !== 'not_attempted'` 时，展示“保存准备这一步没有向公司发送。公司登记结果以本页草稿核对记录为准”，并保留本机来源归档不等于公司确认的限制。
- 尚未读登记状态或 not_attempted 时，展示“本次准备没有向公司发送（仅指保存准备这一步）”，更早公司操作仍未知；这里不据未读或本机准备推定历史公司请求未执行。
- 新变量仅用于段落文本。原登记状态、checkbox、busy、scope、GET/write 数据、校验器、原请求键与 storage 路径没有变化。

当前 source 对 unknown/recorded 的详细区域仍明确：原号核对、登记来源证据可能待核、历史记录与当前交付分列；本片没有新增提交/重放路径。

## 历史证据边界

原独立 4/4 只验证旧 ops `139374E9…`；本报告不将其 SHA 清单改写成当前 `4A0CE6A8…`，不新增或重复矩阵计数。核对原独产物仍保持：

|产物|SHA256|
|---|---|
|`phase23-company-registration-ui-independent.test.cjs`|`8188D295BDD6148738F1B6925B0951783E2CDFFC428C9F3505BF4D8A80FB1205`|
|`phase23-company-registration-ui-independent-review.md`|`000212DC5A8D085BD5DEBC63E556DD6CAEA6378BE129F28408A86475949E157A`|
|`phase23-company-registration-ui-independent-final-hashes.json`|`436263DB5FAF4A2BB0626AA8F4782997F82BB4A79718F68A79C788207653E956`|

root 的当前 28 文件矩阵和实际 GUI 复验应另以当前源码记载，不能借本次只读差异审查替代。

报告：`C:/积木软件工坊/项目/方隅公寓客户版/work/product-upgrade-20261009/audits/phase23-company-registration-copy-review.md`

文件夹：`C:/积木软件工坊/项目/方隅公寓客户版/work/product-upgrade-20261009/audits`
