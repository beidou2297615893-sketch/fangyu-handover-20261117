"""Root-only join of the pinned, independently reviewed Source43 slice."""
import hashlib
import json
from pathlib import Path
import stat
import sys
import uuid

PROJECT = Path('C:/积木软件工坊/项目/方隅公寓客户版')
STAGE = PROJECT / 'work/product-upgrade-20261009'
SOURCE = PROJECT / 'work/app/src'
CANDIDATE = STAGE / 'owner-consent-invite-self-use-candidate'
REVIEW = STAGE / 'owner-consent-invite-self-use-review/REVIEW.md'
RECEIPT = STAGE / 'audits/owner-consent-invite-self-use-joined.json'
TARGET = 'web/workspace/self-operating-read.mjs'
PARENT = '1236C1240F6CB0060CD092874C778EFF087B88279DD38C56797B2D427AAA2197'


def blob(path):
    parts = path.relative_to(PROJECT).parts
    current = PROJECT
    for part in parts:
        current = current / part
        info = current.lstat()
        if current.is_symlink() or getattr(info, 'st_file_attributes', 0) & 0x400:
            raise ValueError('reparse path changed')
    if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1:
        raise ValueError('file kind changed')
    return path.read_bytes()


def pin(value):
    return {'bytes': len(value), 'sha256': hashlib.sha256(value).hexdigest().upper()}


def expected(path, digest, size=None):
    value = blob(path)
    proof = pin(value)
    if proof['sha256'] != digest.upper() or size is not None and proof['bytes'] != size:
        raise ValueError('pinned file changed: ' + str(path))
    return value


if len(sys.argv) != 4 or any(len(value) != 64 or any(c not in '0123456789abcdefABCDEF' for c in value) for value in sys.argv[1:]):
    raise ValueError('require Root-read frozen, nonauthor review and candidate hashes')
frozen_sha, review_sha, final_sha = sys.argv[1:]
if RECEIPT.exists():
    raise ValueError('existing receipt preserved')
manifest = json.loads(expected(CANDIDATE / 'FROZEN.json', frozen_sha))
for item in manifest['items']:
    relative = Path(item['path'])
    if relative.is_absolute() or '..' in relative.parts:
        raise ValueError('manifest path changed')
    expected(CANDIDATE / relative, item['sha256'], item['bytes'])
review_text = expected(REVIEW, review_sha).decode('utf-8-sig')
if 'PASS_LIMITED' not in review_text or final_sha.upper() not in review_text.upper():
    raise ValueError('review does not identify the independently approved slice')
previous = json.loads(blob(STAGE / 'audits/owner-tone-draft-self-use-joined.json'))
protected = dict(previous['protected_unchanged'])
protected['web/workspace/upgrade-ui.css'] = {
    'bytes': 92986, 'sha256': '9EB963CF2067885906FEF60B05ED7857C3E31537AE58246EFC04078661E01F0B'}
for relative, proof in protected.items():
    expected(SOURCE / relative, proof['sha256'], proof.get('bytes'))
expected(PROJECT / 'work/cloud/workspace/site/upgrade-ui.css', protected['web/workspace/upgrade-ui.css']['sha256'], 92986)
target = SOURCE / TARGET
before = expected(target, PARENT, 326997)
after = expected(CANDIDATE / 'src' / TARGET, final_sha)
backup = PROJECT / 'backups/owner-consent-invite-self-use' / uuid.uuid4().hex
backup.mkdir(parents=True)
backup_path = backup / 'self-operating-read.mjs'
backup_path.write_bytes(before)
if blob(target) != before:
    raise ValueError('target changed before join')
try:
    target.write_bytes(after)
    if blob(target) != after:
        raise ValueError('joined readback mismatch')
    for relative, proof in protected.items():
        expected(SOURCE / relative, proof['sha256'], proof.get('bytes'))
except Exception:
    target.write_bytes(before)
    raise
receipt = {
    'schema': 'owner_voluntary_contact_invite_join', 'source_batch': 43,
    'frozen_sha256': frozen_sha.upper(), 'review_sha256': review_sha.upper(),
    'targets': [{'name': TARGET, 'target': str(target), 'backup': str(backup_path),
                 'parent': pin(before), 'candidate': pin(after)}],
    'logical_targets': 1, 'protected_unchanged': protected,
    'mature_template_changed': False, 'draft_persistence': False,
    'new_backend_action': False, 'customer_consent_automatically_recorded': False,
    'actual_App_verified': False, 'actual_Clipboard_verified': False,
    'old_main_interrupted': False, 'customer_database_opened': False,
    'platform_or_model_called': False,
}
RECEIPT.write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'source_batch': 43, 'physical_targets': 1,
                  'protected_unchanged': len(protected), 'actual_App_verified': False}))
