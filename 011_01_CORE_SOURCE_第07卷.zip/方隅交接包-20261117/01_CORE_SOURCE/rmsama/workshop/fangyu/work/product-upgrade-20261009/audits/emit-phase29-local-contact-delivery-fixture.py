"""Three safe actual local DTOs; no plaintext/contact body fixture persistence."""
from copy import deepcopy
import hashlib
import json
from pathlib import Path
from tempfile import TemporaryDirectory
import sys
import socket
from unittest.mock import patch

sys.path.insert(0,str(Path(__file__).parent))
from test_phase29_local_contact_delivery import (DeliveryFixture, CompanyContactDeliveryError,
    PROJECT, TEMP, PUBLISH, REVEAL, GET)


def generate():
    TEMP.mkdir(parents=True,exist_ok=True)
    with TemporaryDirectory(dir=TEMP) as base, patch.object(socket.socket,'connect',side_effect=AssertionError('network forbidden')):
        none=DeliveryFixture(Path(base)/'unconfigured',configured=False)
        ready=DeliveryFixture(Path(base)/'ready')
        try:
            missing_request={'channel_id':none.channel,'operation_action':PUBLISH}
            before=none.dump();missing=none.call(GET,missing_request)
            assert before==none.dump() and none.local_decrypts==0 and none.revealed()==[]
            published=ready.call(PUBLISH,use_gateway=True)
            ready.command({'kind':'lose'})
            try:ready.call(REVEAL,receiver=True)
            except CompanyContactDeliveryError as error:assert error.mutation_committed is None
            else:raise AssertionError('expected isolated committed response loss')
            ready.command({'kind':'restart'})
            recovery_request={'channel_id':ready.channel,'operation_action':REVEAL}
            before=ready.dump(ready.core);recovered=ready.call(GET,recovery_request,receiver=True,use_gateway=True)
            assert before==ready.dump(ready.core)
            assert recovered['state']=='recorded' and recovered['attempt']['state']=='unknown'
            assert all(result['delivery']['contact_values'] is None for result in (missing,published,recovered))
            files=['work/app/src/assistant/company_contact_delivery.py',
                'work/app/src/assistant/company_contact_delivery_transport.py','work/app/src/assistant/product_workspace.py',
                'work/app/src/assistant/company_handoff_receiver.py','work/app/src/assistant/acquisition_contacts.py',
                'work/app/src/assistant/business_reconciliation.py','work/app/src/assistant/company_handoff_status_transport.py',
                'work/cloud/workspace/contact_delivery.cjs','work/cloud/workspace/kms_contact_provider.cjs',
                'work/cloud/workspace/service.cjs','work/cloud/workspace/contact-delivery-fixture.cjs',
                'work/product-upgrade-20261009/audits/test_phase29_local_contact_delivery.py',
                'work/product-upgrade-20261009/audits/phase29-local-contact-delivery-sdk-worker.cjs']
            return {'synthetic_only':True,'fixture_execution':'actual_two_local_cores_helper_gateway_fixed_transports_actual_service_store',
                'transaction_engine':'sdk_interface_compatible_memory_double_callback_adapter',
                'kms_boundary':'official_sdk_request_opaque_ram_stub_no_real_encryption',
                'real_network_called':False,'real_dpapi_called':False,'real_account_used':False,
                'contact_plaintext_persisted_in_fixture':False,
                'source_sha256':{p:hashlib.sha256((PROJECT/p).read_bytes()).hexdigest().upper() for p in files},
                'cases':{'no_provider_status':{'action':GET,'request':missing_request,'result':missing,'local_database_unchanged':True},
                    'source_publish':{'action':PUBLISH,'request':deepcopy(ready.publish),'result':published},
                    'receiver_release_lost_recovered':{'action':GET,'request':recovery_request,'result':recovered,
                        'local_database_unchanged':True,'original_release_response_lost':True}},
                'counts':{'no_provider':none.command({'kind':'counts'}),'ready':ready.command({'kind':'counts'}),
                    'no_provider_local_decrypts':none.local_decrypts,'ready_local_decrypts':ready.local_decrypts,
                    'ready_local_revealed_audits':len(ready.revealed())},
                'actual_company_metadata_envelopes':{'no_provider':none.safe_envelopes,'ready':ready.safe_envelopes}}
        finally:ready.close();none.close()


if __name__=='__main__':
    target=Path(__file__).with_name('phase29-local-contact-delivery-actual-fixture.json')
    target.write_text(json.dumps(generate(),ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'path':str(target),'sha256':hashlib.sha256(target.read_bytes()).hexdigest().upper()}))
