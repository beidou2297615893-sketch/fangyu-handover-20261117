/* Company receiver actions use the backend's original attempt; never a new generic key. */
const exact=(value,keys)=>value&&typeof value==='object'&&!Array.isArray(value)&&Object.keys(value).length===keys.length&&keys.every(key=>Object.hasOwn(value,key));
const hex=value=>typeof value==='string'&&/^[a-f0-9]{64}$/.test(value);
const channel=value=>typeof value==='string'&&/^hc_[a-f0-9]{64}$/.test(value);
const identifier=value=>typeof value==='string'&&/^[A-Za-z0-9_-]{1,160}$/.test(value);
const integer=value=>Number.isSafeInteger(value)&&value>=0;
const stamp=value=>integer(value)&&value>=1577836800&&value<=253402300799;
const bool=value=>typeof value==='boolean';
const safeLabel=value=>{
  if(typeof value!=='string'||!value.trim()||value.length>160||value!==value.normalize('NFKC')||/[\p{Cc}\p{Cf}\p{Cs}]/u.test(value))return false;
  const compact=value.replace(/[\p{P}\p{Z}]/gu,'');
  return !/\d{7,}/.test(compact)&&!/(?:contact|platform|consent|evidence|notice|document)\s*:|(?:微信|wechat|weixin|wxid|手机号|电话)\s*[:：_号]?\s*[A-Za-z0-9]{3,}|(?<![A-Za-z0-9_])wx\s*[:：_号]\s*[A-Za-z0-9_-]{3,}|(?<![A-Za-z0-9_])Bearer\s+|sk-[\w-]{12}|(?:cookie|password|secret|api[_-]?key)\s*[:=]/i.test(value);
};
const actions=['company_handoff_received_list','company_handoff_received_detail','company_handoff_receipt','company_handoff_receipt_get'];
const decisions=['accept','reject','needs_information','duplicate','existing_customer'];
const decisionStates={accept:'accepted',reject:'rejected',needs_information:'needs_information',duplicate:'duplicate_pending_review',existing_customer:'existing_customer_pending_review'};
const labels={draft:'待提交',submitted:'公司已登记提交',accepted:'公司登记已接收',rejected:'公司登记未接收',needs_information:'待补资料',duplicate_pending_review:'重复线索待核对',existing_customer_pending_review:'已有客户待核对',withdrawn:'当前授权已撤回',disputed:'归属有争议'};
const falseFlags=['cross_machine_verified','auto_retry','platform_delivery_verified','receipt_evidence_independently_verified','financial_receipt_verified','cooperation_policy_verified','settlement_active','contacts_modified','local_handoffs_modified','platform_requests_started','provider_requests_started'];
const topFields=['contract','operation_action','read_only','mutation_committed','storage_scope','local_only','actor_scope_hash','observed_at','state','item','items','authorized_recipients','selected_recipient_id','selection_required','total','offset','has_more','attempt','original_operation','original_execution_confirmed','eligible_for_receipt','cloud_receipt_requested','contact_delivery','verified_cash_cents','verified_paid_commission_cents',...falseFlags];
const itemFields=['channel_id','customer_scope_hash','source_actor_scope_hash','platform','recipient_id','recipient_name','purpose','revision','status','current_consent_valid','can_receipt','historical_resource_receipt_recorded','receipt_evidence_independently_verified','contact_delivery','created_at','updated_at'];

export function checkedCompanyReceiver(value,action,request={},expected={}){
  const fail=()=>{throw Error('公司收件记录的范围或证据状态未通过核对；请核对原操作，暂勿再次提交。');};
  if(!exact(value,topFields)||!actions.includes(action)||value.operation_action!==action||value.contract!=='company_handoff_receiver_v1'||value.storage_scope!=='local_bridge_company_server_ledger'||value.local_only!==false||falseFlags.some(key=>value[key]!==false)||value.contact_delivery!=='platform_reference_only'||value.verified_cash_cents!==null||value.verified_paid_commission_cents!==null||!hex(value.actor_scope_hash)||expected.actorHash&&value.actor_scope_hash!==expected.actorHash||!stamp(value.observed_at)||!bool(value.read_only)||!bool(value.mutation_committed)||!bool(value.cloud_receipt_requested)||!bool(value.eligible_for_receipt)||!bool(value.selection_required)||!bool(value.has_more)||!Array.isArray(value.items)||!Array.isArray(value.authorized_recipients)||value.authorized_recipients.length>100)fail();
  if(value.read_only?value.mutation_committed!==false||value.cloud_receipt_requested!==false:action!=='company_handoff_receipt'||value.mutation_committed!==true||value.cloud_receipt_requested!==true||value.state!=='recorded')fail();
  const validItem=item=>{
    if(!exact(item,itemFields)||!channel(item.channel_id)||!hex(item.customer_scope_hash)||!hex(item.source_actor_scope_hash)||!['xiaohongshu','douyin','zhihu','wechat_channels','weixin','bilibili','bili','kuaishou'].includes(item.platform)||!identifier(item.recipient_id)||!safeLabel(item.recipient_name)||!safeLabel(item.purpose)||!integer(item.revision)||item.revision<1||!Object.hasOwn(labels,item.status)||!bool(item.current_consent_valid)||!bool(item.can_receipt)||!bool(item.historical_resource_receipt_recorded)||item.receipt_evidence_independently_verified!==false||item.contact_delivery!=='platform_reference_only'||!stamp(item.created_at)||!stamp(item.updated_at)||item.updated_at<item.created_at||item.status==='withdrawn'&&item.current_consent_valid||item.can_receipt&&(!item.current_consent_valid||item.status!=='submitted'))fail();
    if(expected.recipientId&&item.recipient_id!==expected.recipientId)fail();
  };
  const seenRecipients=new Set();
  for(const recipient of value.authorized_recipients){if(!exact(recipient,['id','name'])||!identifier(recipient.id)||!safeLabel(recipient.name)||seenRecipients.has(recipient.id))fail();seenRecipients.add(recipient.id);}
  if(action==='company_handoff_received_list'){
    if(value.read_only!==true||value.state!=='list'||value.item!==null||value.attempt!==null||value.original_operation!==null||value.original_execution_confirmed!==null||value.eligible_for_receipt!==false||!integer(value.offset)||value.offset!==(request.offset??0)||value.items.length>(request.limit??10)||value.items.length>15)fail();
    if(!request.recipient_id){if(value.selection_required!==true||value.selected_recipient_id!==null||value.total!==null||value.items.length||value.has_more||value.offset!==0)fail();}
    else if(value.selection_required!==false||value.selected_recipient_id!==request.recipient_id||!seenRecipients.has(request.recipient_id)||!integer(value.total)||value.items.length>Math.max(0,value.total-value.offset)||value.has_more!==(value.offset+value.items.length<value.total))fail();
    const seen=new Set();for(const item of value.items){validItem(item);if(item.recipient_id!==request.recipient_id||seen.has(item.channel_id))fail();seen.add(item.channel_id);}
    return value;
  }
  if(!channel(request.channel_id)||value.items.length||value.authorized_recipients.length||value.selected_recipient_id!==null||value.selection_required!==false||value.total!==null||value.offset!==null||value.has_more!==false)fail();
  validItem(value.item);if(value.item.channel_id!==request.channel_id)fail();
  const attempt=value.attempt,original=value.original_operation;
  if(attempt!==null){
    if(!exact(attempt,['state','expected_revision','decision','created_at','updated_at','operation_action','idempotency_key'])||!['unknown','recorded'].includes(attempt.state)||!integer(attempt.expected_revision)||attempt.expected_revision<1||!decisions.includes(attempt.decision)||!stamp(attempt.created_at)||!stamp(attempt.updated_at)||attempt.updated_at<attempt.created_at||attempt.operation_action!=='acquisition_handoff_receipt'||!hex(attempt.idempotency_key)||value.item.revision<attempt.expected_revision)fail();
    if(action==='company_handoff_receipt'&&(attempt.expected_revision!==request.expected_revision||attempt.decision!==request.decision))fail();
    if(expected.attempt&&(attempt.idempotency_key!==expected.attempt.idempotency_key||attempt.expected_revision!==expected.attempt.expected_revision||attempt.decision!==expected.attempt.decision))fail();
  }else if(expected.attempt)fail();
  if(value.state==='not_attempted'){
    if(attempt!==null||original!==null||value.original_execution_confirmed!==null||value.eligible_for_receipt!==value.item.can_receipt||value.read_only!==true||action==='company_handoff_receipt')fail();
  }else if(value.state==='unknown'){
    if(!attempt||attempt.state!=='unknown'||original!==null||value.original_execution_confirmed!==null||value.eligible_for_receipt!==false||value.read_only!==true)fail();
  }else if(value.state==='recorded'){
    if(!attempt||!exact(original,['channel_id','revision','historical_status','occurred_at','historical_event_self_hash_verified','full_historical_chain_verified'])||original.channel_id!==request.channel_id||original.revision!==attempt.expected_revision+1||original.revision>value.item.revision||original.historical_status!==decisionStates[attempt.decision]||!stamp(original.occurred_at)||original.historical_event_self_hash_verified!==true||original.full_historical_chain_verified!==false||value.original_execution_confirmed!==true||value.eligible_for_receipt!==false||!value.read_only&&attempt.state!=='recorded'||attempt.decision==='accept'&&value.item.historical_resource_receipt_recorded!==true)fail();
  }else fail();
  return value;
}

export function companyReceiverScope(context={}){
  const user=context.user||{};
  return JSON.stringify([user.id,user.username,user.tenant_id,user.role,user.company_id,context.companyId,context.environmentId,context.deviceId,context.deviceGeneration,context.localWorkspace]);
}
const node=(tag,text='',className='')=>{const result=document.createElement(tag);result.textContent=String(text);if(className)result.className=className;return result;};

export function createCompanyHandoffReceiverUI({createDialog,execute,getContext,openContacts=null,clearSensitiveContacts=()=>{}}){
  let generation=0,active=null,disposed=false;
  // Opaque scope/channel metadata only. A lost response never enables another ACK in this UI instance.
  const blocked=new Set(),scope=()=>companyReceiverScope(getContext()||{});
  const clear=(remove=true)=>{generation++;blocked.clear();const previous=active;active=null;if(previous){previous.release();for(const field of previous.root.querySelectorAll('input,textarea')){field.value='';field.checked=false;}previous.root.replaceChildren();if(remove){previous.root.close?.();previous.root.remove();}}};
  async function open(){
    if(disposed)return;clearSensitiveContacts();clear();const owner=scope(),own=++generation;
    const view=createDialog('公司收件箱',{onClose:()=>{if(active?.root===view.root)clear(false);}});let epoch=0,actorHash=null,recipientId='',detail=null,writing=false;const originalByChannel=new Map();
    active={root:view.root,release(){epoch++;detail=null;actorHash=null;recipientId='';writing=false;originalByChannel.clear();}};
    const current=()=>{if(active?.root===view.root&&scope()!==owner){clear();return false;}return !disposed&&generation===own&&active?.root===view.root&&view.current();};
    const report=(text,error=false)=>{if(current()){view.status.textContent=text;view.status.dataset.state=error?'error':'ready';}};
    const host=node('section','','upgrade-record-list');view.root.append(node('p','先选择本人获权的接收部门。交接记录保留平台引用；联系方式通过独立授权的一次查看核对。','upgrade-muted'),host);
    const clearHost=()=>{for(const field of host.querySelectorAll('input,textarea')){field.value='';field.checked=false;}host.replaceChildren();};
    const button=(parent,text,fn)=>{const control=node('button',text,'secondary');control.type='button';control.onclick=()=>void fn(control);parent.append(control);return control;};
    const call=async(action,request,expected={},fresh=current)=>{
      if(!fresh())return null;
      const answer=await execute(action,request);
      if(!fresh())return null;
      if(answer?.status!=='succeeded'||!answer.result||typeof answer.result!=='object'){const error=Error('公司记录暂不可读，请核对权限和原操作。');error.mutation_committed=answer?.mutation_committed??answer?.error?.mutation_committed;throw error;}
      const value=checkedCompanyReceiver(answer.result,action,request,{...expected,actorHash});
      if(!fresh())return null;if(actorHash===null)actorHash=value.actor_scope_hash;return value;
    };
    async function list(id='',offset=0){
      if(!current()||writing)return;const ticket=++epoch,fresh=()=>current()&&ticket===epoch;detail=null;recipientId=id;clearHost();report('正在读取当前账号获权的公司接收范围…');
      try{
        const request=id?{recipient_id:id,offset,limit:10}:{};
        const value=await call('company_handoff_received_list',request,{},fresh);if(!value)return;
        const form=node('form','','upgrade-operation-form'),label=node('label','接收部门'),choice=node('select');choice.setAttribute('aria-label','接收部门');
        choice.append(new Option('请选择本人获权的部门',''));for(const row of value.authorized_recipients)choice.append(new Option(row.name,row.id));choice.value=id;label.append(choice);form.append(label);host.append(form);
        const choose=button(form,'读取所选部门',()=>{if(!current()||writing)return;if(!value.authorized_recipients.some(row=>row.id===choice.value)){report('请明确选择本人获权的接收部门。',true);return;}void list(choice.value);});
        form.addEventListener('submit',event=>{event.preventDefault();choose.onclick();});
        choice.addEventListener('change',()=>{if(!current())return;clearSensitiveContacts();epoch++;detail=null;for(const child of [...host.children])if(child!==form)child.remove();report('部门已变化，请点击读取所选部门。');});
        if(value.selection_required){report(value.authorized_recipients.length?'请选择接收部门，选择前未读取收件列表。':'当前账号没有获权的接收部门。');return;}
        report(`公司交接记录共 ${value.total} 条，包含当前状态与历史记录。`);
        if(!value.items.length)host.append(node('p','该范围当前没有公司交接记录。','upgrade-muted'));
        for(const item of value.items){const row=node('section','','upgrade-operation-form');row.append(node('h3',item.purpose),node('p',`${item.recipient_name} · ${labels[item.status]}`),node('p',`公司交接编号：${item.channel_id}`,'upgrade-muted'));button(row,'查看公司详情',()=>load(item.channel_id));host.append(row);}
        if(offset>0)button(host,'上一页',()=>list(id,Math.max(0,offset-10)));
        if(value.has_more)button(host,'下一页',()=>list(id,offset+value.items.length));
      }catch{if(fresh()){clearHost();report('公司收件范围暂不可读，请检查权限后重新读取。',true);button(host,'重新读取本人范围',()=>list());}}
    }
    async function load(id,originalOnly=false){
      if(!current()||writing||!channel(id))return;const ticket=++epoch,fresh=()=>current()&&ticket===epoch,previous=detail?.item.channel_id===id?detail:null;
      clearSensitiveContacts();detail=null;clearHost();report(originalOnly?'正在按本人原操作核对公司回执…':'正在核对公司当前授权、版本和接收权限…');
      const action=originalOnly?'company_handoff_receipt_get':'company_handoff_received_detail';
      try{const value=await call(action,{channel_id:id},{recipientId,attempt:previous?.attempt||originalByChannel.get(id)},fresh);if(!value)return;detail=value;render(value);}
      catch{if(fresh()){report('当前记录尚未核实，请按原操作重新核对，暂勿再次提交。',true);button(host,'核对本人原操作',()=>load(id,true));button(host,'返回部门列表',()=>list(recipientId));}}
    }
    function render(value){
      if(!current())return;const item=value.item,id=item.channel_id,lock=id;clearHost();if(value.attempt)originalByChannel.set(id,value.attempt);
      const summary=node('section','','upgrade-operation-form');summary.append(node('h3',item.purpose));
      for(const [title,text]of [['接收部门',item.recipient_name],['公司交接编号',id],['当前公司状态',labels[item.status]],['当前客户同意',item.current_consent_valid?'公司记录有效':'当前无有效同意'],['历史资源接收',item.historical_resource_receipt_recorded?'公司曾登记接收':'当前投影未见接受登记'],['证据独立核验','尚未独立核验'],['客户实收 / 分成到账','未核实 / 未核实'],['联系方式交付','平台交接历史仍是引用；联系方式需单独核对授权']]){const row=node('p');row.append(node('strong',title+'：'),node('span',text));summary.append(row);}
      host.append(summary);button(host,'返回部门列表',()=>list(recipientId));
      if(typeof openContacts==='function')button(host,'核对本人联系方式查看',()=>{
        if(!current()||detail?.item!==item)return;
        const original=JSON.stringify(getContext()||{}),selected=recipientId;
        // Opening the shared dialog closes this parent. Do not retain its current() fence.
        return openContacts({channelId:id,mode:'receiver',recipientId:item.recipient_id,purpose:item.purpose},{accept:()=>JSON.stringify(getContext()||{})===original&&selected===item.recipient_id});
      });
      if(value.attempt||blocked.has(lock)){
        blocked.add(lock);
        if(value.original_operation){const original=value.original_operation;host.append(node('p',`本人原操作已核对：${labels[original.historical_status]} · 原记录版本 ${original.revision}。该历史记录与当前授权分开保留。`,'upgrade-muted'));report('已核对本人原操作；不会再次提交接收决定。');}
        else report('本人原操作结果仍待核对。缺少回执不能判断尚未执行；暂勿再次提交。',true);
        if(value.attempt)host.append(node('p',`本人原操作编号：${value.attempt.idempotency_key}`,'upgrade-muted'));
        button(host,'核对本人原操作',()=>load(id,true));return;
      }
      if(!value.eligible_for_receipt){report('当前账号或当前授权不允许登记接收。');return;}
      const form=node('form','','upgrade-operation-form');form.addEventListener('submit',event=>event.preventDefault());host.append(form);
      const decisionLabel=node('label','处理决定'),decision=node('select');decision.setAttribute('aria-label','处理决定');for(const [key,text]of [['accept','接受处理'],['reject','拒绝接收'],['needs_information','需要补充资料'],['duplicate','疑似重复线索'],['existing_customer','疑似已有客户']])decision.append(new Option(text,key));decision.value='accept';decisionLabel.append(decision);form.append(decisionLabel);
      const reasonLabel=node('label','拒收原因'),reason=node('select');reason.setAttribute('aria-label','拒收原因');for(const [key,text]of [['not_qualified','线索不符合条件'],['outside_service_area','超出服务区域']])reason.append(new Option(text,key));reason.value='not_qualified';reasonLabel.append(reason);reasonLabel.hidden=true;form.append(reasonLabel);
      const evidenceLabel=node('label','实际证据引用'),evidence=node('input');evidence.type='text';evidence.autocomplete='off';evidence.maxLength=41;evidence.placeholder='evidence: 或 document: 后接32位编号';evidence.setAttribute('aria-label','实际证据引用');evidenceLabel.append(evidence);form.append(evidenceLabel);
      const confirmationLabel=node('label','','upgrade-check'),confirmation=node('input');confirmation.type='checkbox';confirmation.checked=false;confirmation.setAttribute('aria-label','确认本次接收决定');confirmationLabel.append(confirmation,node('span','我已核对当前客户同意、接收部门、处理决定与实际证据。'));form.append(confirmationLabel);
      const validEvidence=()=>/^(?:evidence|document):[a-f0-9]{32}$/.test(evidence.value.trim());
      const submit=button(form,'确认登记本次决定',()=>ack());
      const update=()=>{confirmation.checked=false;reasonLabel.hidden=decision.value!=='reject';submit.disabled=true;};
      decision.addEventListener('change',update);reason.addEventListener('change',update);evidence.addEventListener('input',update);confirmation.addEventListener('change',()=>{submit.disabled=!current()||writing||!confirmation.checked||!validEvidence();});submit.disabled=true;
      report('当前可由本人登记处理决定；填写证据并手动确认后才会提交。');
      async function ack(){
        if(!current()||writing||detail!==value||blocked.has(lock)||!value.eligible_for_receipt||!confirmation.checked||!validEvidence()||!decisions.includes(decision.value))return;
        const request={channel_id:id,expected_revision:item.revision,decision:decision.value,evidence_reference:evidence.value.trim()};
        if(request.decision==='reject'){if(!['not_qualified','outside_service_area'].includes(reason.value))return;request.reason_code=reason.value;}else if(request.decision!=='accept')request.reason_code=request.decision;
        const ticket=++epoch,fresh=()=>current()&&ticket===epoch;writing=true;blocked.add(lock);for(const control of host.querySelectorAll('button,input,select'))control.disabled=true;report('正在登记本次决定；结果未知时只核对原操作。');
        try{const answer=await call('company_handoff_receipt',request,{recipientId},fresh);if(!answer)return;detail=answer;render(answer);}
        catch(error){if(fresh()){detail=null;clearHost();if(error.mutation_committed===false){blocked.delete(lock);report('后台明确拒绝本次提交。请重新读取当前详情并核对条件。',true);button(host,'重新读取当前详情',()=>load(id));}else{report('本次结果尚未确认。请按本人原操作核对，暂勿再次提交。',true);button(host,'核对本人原操作',()=>load(id,true));}button(host,'返回部门列表',()=>list(recipientId));}}
        finally{if(fresh())writing=false;}
      }
    }
    await list();
  }
  return {open,reset(){clear();},dispose(){disposed=true;clear();blocked.clear();}};
}
