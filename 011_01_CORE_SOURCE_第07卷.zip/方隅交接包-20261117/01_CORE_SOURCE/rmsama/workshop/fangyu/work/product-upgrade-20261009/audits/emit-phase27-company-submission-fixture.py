"""Actual local/company adapter DTOs, all synthetic and no network/model."""
from copy import deepcopy
from pathlib import Path
from tempfile import TemporaryDirectory
import hashlib
import importlib.util
import json
import socket
from unittest.mock import patch

HERE=Path(__file__).parent
spec=importlib.util.spec_from_file_location('phase27_submission_fixture',HERE/'test_phase27_company_handoff_submission.py')
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)


def generate():
    module.TEMP.mkdir(parents=True,exist_ok=True)
    cases={};envelopes={};counts={}
    with TemporaryDirectory(dir=module.TEMP) as base,patch.object(socket.socket,'connect',side_effect=AssertionError('network forbidden')):
        fixtures=[]
        def fixture(name,**options):
            f=module.SubmissionFixture(Path(base)/name,**options);fixtures.append(f);return f
        def collect(name,f,*,result=None,write=False):
            before=f.dump()
            result=f.call(module.GET) if result is None else result
            if not write:assert f.dump()==before
            cases[name]=dict(request=deepcopy(f.data) if write else {'handoff_id':f.f.handoff['id']},result=result,
                local_database_unchanged=not write,preparation_get_result=f.f.preparation.execute('company_handoff_preparation_get',
                    {'handoff_id':f.f.handoff['id']},deepcopy(f.f.actor)))
            envelopes[name]=deepcopy(f.registration.envelopes);counts[name]=f.command({'kind':'counts'})
        try:
            cold=fixture('cold',register=False,prepare=False);collect('no_origin',cold)
            prepared=fixture('prepared',register=False);collect('registration_not_attempted',prepared)
            normal=fixture('normal');collect('ready_lost_register_echo',normal)
            collect('first_recorded',normal,result=normal.call(),write=True);collect('recorded_get',normal)
            lost=fixture('lost');lost.lose_response=True
            try:lost.call()
            except module.CompanyHandoffSubmissionError as error:assert error.mutation_committed is None
            else:raise AssertionError('actual committed response must be lost')
            lost.command({'kind':'restart'});lost.service=lost.make_service();collect('submit_response_lost_recorded',lost)
            unknown=fixture('unknown')
            unknown.service.cloud_submit=lambda *_:(_ for _ in ()).throw(TimeoutError('controlled no result'))
            try:unknown.call()
            except module.CompanyHandoffSubmissionError as error:assert error.mutation_committed is None
            collect('submit_unknown',unknown)
            normal.command(dict(kind='accept_withdraw',channel_id=normal.origin['expected_cloud_channel_id']))
            normal.registration.withdraw();collect('withdrawn_historical',normal)
            sources=['work/app/src/assistant/company_handoff_submission.py','work/app/src/assistant/company_handoff_submission_transport.py',
                'work/app/src/assistant/product_workspace.py','work/app/src/assistant/company_handoff_registration.py',
                'work/app/src/assistant/company_handoff_channel_check.py','work/app/src/assistant/company_handoff_preparation.py',
                'work/cloud/workspace/handoff-ledger.cjs','work/cloud/workspace/service.cjs','work/cloud/workspace/source_binding.cjs',
                'work/product-upgrade-20261009/audits/test_phase27_company_handoff_submission.py',
                'work/product-upgrade-20261009/audits/phase27-company-submission-sdk-worker.cjs',
                'work/product-upgrade-20261009/audits/emit-phase27-company-submission-fixture.py']
            return dict(synthetic_only=True,fixture_execution='actual_Core_and_createService_createStore',
                transaction_engine='sdk_interface_compatible_memory_double_callback_adapter',real_cloud_called=False,
                cloud_network_called=False,platform_called=False,provider_called=False,
                cases=cases,actual_company_envelopes=envelopes,counts=counts,
                source_sha256={name:hashlib.sha256((module.PROJECT/name).read_bytes()).hexdigest().upper() for name in sources})
        finally:
            for f in reversed(fixtures):f.close()


if __name__=='__main__':
    target=HERE/'phase27-company-submission-actual-fixture.json'
    result=generate();target.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(dict(path=str(target),cases=len(result['cases']),public_fields=len(result['cases']['first_recorded']['result'])),ensure_ascii=False))
