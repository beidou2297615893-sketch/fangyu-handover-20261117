"""Internal QA employee workspace: same-origin assets and a narrow cloud gateway."""
import json
import mimetypes
import re
import time
from pathlib import Path

from integrations import IntegrationError


class WorkspaceError(ValueError):
    def __init__(self, message, status=400, *, mutation_committed=None):
        super().__init__(message)
        self.status = status
        self.mutation_committed = mutation_committed


# These are the member operations already supported by the cloud workspace.
# Device enrollment and device worker operations must never enter this gateway.
MEMBER_OPERATIONS = frozenset({
    'devices', 'device_revoke', 'device_claims_release', 'command_submit',
    'command_get', 'list', 'members', 'member_save', 'publish',
    'ai_config_read', 'ai_config_save', 'ai_profile', 'contact_receipts_verify',
})
LOCAL_READ_FIELDS = frozenset({'offset', 'limit', 'snapshot', 'query', 'platform',
                               'grade', 'task_id', 'region', 'date_from', 'date_to','sort','reply_state',
                               'group_by','group_key','group_offset','intent_level','worklist'})
ASSETS = {
    '': ('index.html', 'text/html; charset=utf-8'),
    'app.mjs': ('app.mjs', 'text/javascript; charset=utf-8'),
    'enterprise-ui.mjs': ('enterprise-ui.mjs', 'text/javascript; charset=utf-8'),
    'enterprise-model.mjs': ('enterprise-model.mjs', 'text/javascript; charset=utf-8'),
    'contact-verification.mjs': ('contact-verification.mjs', 'text/javascript; charset=utf-8'),
    'customer-ui.mjs': ('customer-ui.mjs', 'text/javascript; charset=utf-8'),
    'customer-ui.css': ('customer-ui.css', 'text/css; charset=utf-8'),
    'platform-account.mjs': ('platform-account.mjs', 'text/javascript; charset=utf-8'),
    'transport.mjs': ('transport.mjs', 'text/javascript; charset=utf-8'),
    'local-transport.mjs': ('local-transport.mjs', 'text/javascript; charset=utf-8'),
    'collection-progress.mjs': ('collection-progress.mjs', 'text/javascript; charset=utf-8'),
    'collection-progress.css': ('collection-progress.css', 'text/css; charset=utf-8'),
    'site.css': ('site.css', 'text/css; charset=utf-8'),
    'platform-account.css': ('platform-account.css', 'text/css; charset=utf-8'),
    'upgrade-shell.mjs': ('upgrade-shell.mjs', 'text/javascript; charset=utf-8'),
    'upgrade-model.mjs': ('upgrade-model.mjs', 'text/javascript; charset=utf-8'),
    'upgrade-operations-ui.mjs': ('upgrade-operations-ui.mjs', 'text/javascript; charset=utf-8'),
    'company-handoff-receiver-ui.mjs': ('company-handoff-receiver-ui.mjs', 'text/javascript; charset=utf-8'),
    'company-contact-delivery-ui.mjs': ('company-contact-delivery-ui.mjs', 'text/javascript; charset=utf-8'),
    'handoff-export-file.mjs': ('handoff-export-file.mjs', 'text/javascript; charset=utf-8'),
    'intent-rule-ui.mjs': ('intent-rule-ui.mjs', 'text/javascript; charset=utf-8'),
    'intent-quality-ui.mjs': ('intent-quality-ui.mjs', 'text/javascript; charset=utf-8'),
    'company-policy-ui.mjs': ('company-policy-ui.mjs', 'text/javascript; charset=utf-8'),
    'business-reconciliation-ui.mjs': ('business-reconciliation-ui.mjs', 'text/javascript; charset=utf-8'),
    'self-worklist-ui.mjs': ('self-worklist-ui.mjs', 'text/javascript; charset=utf-8'),
    'self-daily-evidence-ui.mjs': ('self-daily-evidence-ui.mjs', 'text/javascript; charset=utf-8'),
    'platform-read-ui.mjs': ('platform-read-ui.mjs', 'text/javascript; charset=utf-8'),
    'upgrade-ui.css': ('upgrade-ui.css', 'text/css; charset=utf-8'),
    'upgrade-sidebar-apartment-v1.png': ('assets/upgrade-sidebar-apartment-v1.png', 'image/png'),
    'upgrade-building-logo-v1.png': ('assets/upgrade-building-logo-v1.png', 'image/png'),
    'upgrade-approved-brand-mark.png': ('assets/upgrade-approved-brand-mark.png', 'image/png'),
    'upgrade-approved-apartment-poster.png': ('assets/upgrade-approved-apartment-poster.png', 'image/png'),
    'gsap.min.js': ('gsap.min.js', 'text/javascript; charset=utf-8'),
}
IMAGE_NAME = re.compile(r'fy-[a-z0-9-]+\.(?:png|webp)\Z')
SVG_NAMES = frozenset({'tabler-home.svg','tabler-home-filled.svg','tabler-message.svg','tabler-message-dots.svg','tabler-user-scan.svg',
                       'tabler-external-link.svg','tabler-chevron-down.svg','tabler-x.svg',
                       'tabler-upgrade-phone.svg','tabler-upgrade-message.svg','tabler-upgrade-check.svg',
                       'tabler-upgrade-users.svg','tabler-upgrade-file.svg','tabler-upgrade-user.svg',
                       'tabler-upgrade-stack.svg','tabler-upgrade-settings.svg','tabler-upgrade-list.svg',
                       'tabler-upgrade-pin.svg','tabler-upgrade-calendar.svg',
                       'tabler-upgrade-warning.svg','tabler-upgrade-export.svg',
                       'tabler-upgrade-dots.svg','tabler-upgrade-budget.svg',
                       'bootstrap-upgrade-card-list.svg','tabler-upgrade-quote.svg'})
SECRET_KEYS = frozenset({'token', 'device_token', 'pair_code', 'password',
                         'authorization', 'cookie', 'api_key', 'secret'})


def public(value):
    """Remove credentials even if a future cloud response adds a secret field."""
    if isinstance(value, dict):
        return {key: public(item) for key, item in value.items()
                if isinstance(key, str) and key.lower() not in SECRET_KEYS}
    if isinstance(value, list):
        return [public(item) for item in value]
    return value


def identity(server):
    managed = server.company.get('managedWorkspace') or {}
    return {'contract': 'fangyu-workspace-v1',
            'environment_id': managed.get('environment_id'),
            'company_id': server.company.get('id')}


def config(server):
    # QA and hold are presentation hints. Cloud/device guards remain authoritative.
    runtime = server.company.get('runtime') or {}
    from .employee_distribution import runtime_config_valid
    return {'environmentId': identity(server)['environment_id'],
            'companyId': server.company['id'], 'localWorkspace': True,
            'developmentWorkspace': bool(getattr(server, 'development_workspace', False)),
            'safetyHold': (server.company.get('id') == 'fangyu-apartment-client'
                           and runtime.get('release_approved') is not True),
            'employeeReleaseEnabled': runtime_config_valid(server.company),
            'employeeReleaseVersion': server.company.get('releaseVersion','')
                                     if runtime_config_valid(server.company) else '',
            'releaseVersion': server.company.get('releaseVersion', ''),
            'pairingAllowed': True,
            'pairingVersion': server.company.get('releaseVersion', '')}


def asset(server, name):
    """Return only named workspace files; never resolve a client supplied path."""
    from app import ROOT
    folder = ROOT / 'web' / 'workspace'
    if name == 'config.mjs':
        return ('export const config=' + json.dumps(config(server), ensure_ascii=False,
                  separators=(',', ':')) + ';').encode(), 'text/javascript; charset=utf-8'
    if name in ASSETS:
        filename, content_type = ASSETS[name]
        target = folder / filename
    elif name in SVG_NAMES:
        target = folder / 'assets' / name
        content_type = 'image/svg+xml'
    elif IMAGE_NAME.fullmatch(name):
        target = folder / 'assets' / name
        content_type = 'image/webp' if name.endswith('.webp') else 'image/png'
    else:
        raise WorkspaceError('页面资源不存在', 404)
    if not target.is_file():
        raise WorkspaceError('页面资源不存在', 404)
    body=target.read_bytes()
    if name=='' and getattr(server,'development_workspace',False):
        body=body.replace(b'<section id="login-panel"',b'<section id="login-panel" hidden',1)
    return body, content_type


def local_device(server, user):
    assistant = getattr(server, 'assistant_service', None)
    if not assistant:
        raise WorkspaceError('本地助手未启动', 503)
    saved = assistant.vault.read()
    device = assistant.device or (saved or {}).get('device') or {}
    owner = device.get('owner')
    if owner and owner != user['username']:
        raise WorkspaceError('这台电脑已绑定另一位员工，请联系管理员处理', 409)
    return {'bound': bool(saved and saved.get('state') == 'bound' and device.get('id')),
            'device_id': device.get('id') or None, 'owner': owner or None,
            'state': assistant.state, 'name': device.get('name') or None,
            'version': device.get('version') or None}


def require_owner(server, user):
    summary = local_device(server, user)
    if not summary['bound']:
        raise WorkspaceError('请先连接这台电脑', 409)
    return summary


def local_read(server, user, action, data, *, record_view=False, response_check=False):
    """Read through the current assistant executor with its owner principal."""
    allowed=(('customer_response_check_start','customer_response_check_status',
              'customer_response_check_cancel') if response_check else
             ('customer_seen',) if record_view else
             ('workspace_state', 'leads_list', 'reply_status', 'task_progress',
              'contact_receipt_status','customer_list','customer_detail'))
    if action not in allowed or not isinstance(data, dict):
        raise WorkspaceError('不支持此本机读取', 403)
    if response_check:
        if (user.get('role')!='operator' or user.get('cloud_bound') is not True or
                user.get('development_local_only') is True):
            raise WorkspaceError('回信检查仅限已绑定的正式员工',403)
        if action=='customer_response_check_start':
            if (set(data)!={'author_key','reply_id'} or
                    not isinstance(data['author_key'],str) or
                    re.fullmatch('[0-9a-f]{64}',data['author_key']) is None or
                    not isinstance(data['reply_id'],str) or
                    re.fullmatch('[A-Za-z0-9_-]{1,200}',data['reply_id']) is None):
                raise WorkspaceError('回信检查参数无效',403)
        elif (set(data)!={'job_id'} or not isinstance(data['job_id'],str) or
              re.fullmatch('[0-9a-f]{32}',data['job_id']) is None):
            raise WorkspaceError('回信检查任务标识无效',403)
    if (action == 'workspace_state' and data) or (action == 'leads_list' and
            set(data) - LOCAL_READ_FIELDS):
        raise WorkspaceError('本机读取参数无效', 403)
    if action=='leads_list' and (data.get('sort','newest') not in ('intent','newest')
                                or data.get('reply_state','') not in ('','unreplied','sent')):
        raise WorkspaceError('评论排序或回复筛选参数无效',403)
    if action=='leads_list':
        from .lead_groups import validate_grouping
        try:validate_grouping(data)
        except ValueError as exc:raise WorkspaceError(str(exc),403) from None
    if action=='task_progress' and (set(data)!={'task_id'} or not isinstance(data['task_id'],str)):
        raise WorkspaceError('任务进度参数无效',403)
    if action=='reply_status' and (set(data)!={'lead_id'} or type(data['lead_id']) is not str
                                    or not 1<=len(data['lead_id'])<=200):
        raise WorkspaceError('回复状态参数无效',403)
    if action=='contact_receipt_status' and (set(data)!={'reply_id'} or not isinstance(data['reply_id'],str) or not 1<=len(data['reply_id'])<=200):
        raise WorkspaceError('联系回执参数无效',403)
    if action=='customer_list':
        from .customer_list import FILTERS, GROUP_BY, LEVELS
        group_by=data.get('group_by','post')
        group_key=data.get('group_key','')
        if (set(data)-{'query','filter','offset','limit','group_by','group_key'} or
                not isinstance(data.get('query',''),str) or len(data.get('query',''))>100 or
                data.get('filter','all') not in FILTERS or
                type(data.get('offset',0)) is not int or not 0<=data.get('offset',0)<=1000000 or
                type(data.get('limit',20)) is not int or not 1<=data.get('limit',20)<=100 or
                not isinstance(group_by,str) or group_by not in GROUP_BY or
                not isinstance(group_key,str) or len(group_key)>64 or
                group_key and (re.fullmatch('[0-9a-f]{64}',group_key) is None if group_by=='post' else group_key not in LEVELS)):
            raise WorkspaceError('客户列表参数无效',403)
    if action in ('customer_detail','customer_seen'):
        fields={'author_key','post_key'} if action=='customer_seen' else {'author_key'}
        if (set(data)-fields or 'author_key' not in data or
                any(not isinstance(value,str) or re.fullmatch('[0-9a-f]{64}',value) is None for value in data.values())):
            raise WorkspaceError('客户查询参数无效',403)
    own = require_owner(server, user)
    assistant = server.assistant_service
    with assistant.lock:
        executor = assistant.executor
        state = assistant.state
        device = assistant.device or {}
    offline_dev=(getattr(server,'development_workspace',False)
                 and user.get('development_local_only') is True
                 and state in ('offline','held','error','stopped') and executor is None)
    if (not offline_dev and (state not in ('online', 'held') or executor is None)
            or device.get('id') != own['device_id']
            or device.get('owner') != user['username']
            or executor is not None and getattr(executor, 'owner', None) != user['username']
            or executor is not None and getattr(executor, 'tenant', None) != user['tenant_id']):
        raise WorkspaceError('本机助手未确认在线，请从工作台刷新设备状态', 409)
    if offline_dev:
        from .business import BusinessExecutor
        managed=server.company['managedWorkspace']
        executor=BusinessExecutor(server,managed['environment_id'],server.company['id'],user['username'])
        if executor.tenant!=user['tenant_id']:
            raise WorkspaceError('本机员工归属不匹配',403)
        # Reuse the established read projections without its normal cloud
        # principal upsert. The cached operator has already been checked.
        executor.principal=lambda command:user
    if action=='task_progress':
        # Store reads and the progress lock never wait for the task's import
        # lock. Reuse the core's existing task/account ownership checks.
        task=server.core._get('tasks',data['task_id'],user['tenant_id'])
        server.core._task_access(user,task,user['tenant_id'])
        progress=server.core.task_progress(task['id'])
        from .strategy_tasks import is_strategy_task, project_strategy_progress
        if is_strategy_task(task):
            progress=project_strategy_progress(progress)
        return {'result':{'task_id':task['id'],'progress':progress,
                          'status':task.get('status'),'sequence_status':task.get('sequence_status')}}
    # The operator principal is deliberate. Admin users reading their own
    # device do not gain cross-employee review access through this local path.
    command = {'owner': user['username'],
               'principal': {'username': user['username'], 'role': 'operator'},
               'action': action, 'data': data}
    return {'result': public(executor(command))}


def local_intent_refresh(server,user,data):
    """One-time local developer maintenance, not a customer/cloud command."""
    if (not getattr(server,'development_workspace',False) or
            user.get('role')!='operator' or user.get('cloud_bound') is not True or
            user.get('development_local_only') is True):
        raise WorkspaceError('本机意向维护未开放',403)
    own=require_owner(server,user)
    assistant=server.assistant_service
    with assistant.lock:
        executor=assistant.executor;state=assistant.state;device=assistant.device or {}
    from .business import BusinessExecutor
    if (state not in ('online','held') or not isinstance(executor,BusinessExecutor) or
            device.get('id')!=own['device_id'] or device.get('owner')!=user['username'] or
            executor.owner!=user['username'] or executor.tenant!=user['tenant_id']):
        raise WorkspaceError('本机员工归属未确认',403)
    actor=executor.principal({'owner':user['username'],
                             'principal':{'username':user['username'],'role':'operator'}},read_only=True)
    return public(executor.reanalyze_existing(actor,data))


def local_keyword_state(server,user,data):
    """Durable local keyword pool through the bound operator's trusted executor."""
    if user.get('role')!='operator' or user.get('cloud_bound') is not True:
        raise WorkspaceError('关键词库仅限已绑定员工',403)
    own=require_owner(server,user)
    assistant=server.assistant_service
    with assistant.lock:
        executor=assistant.executor
        state=assistant.state
        device=assistant.device or {}
    offline_dev=(getattr(server,'development_workspace',False)
                 and user.get('development_local_only') is True
                 and state in ('offline','held','error','stopped') and executor is None)
    if (not offline_dev and (state not in ('online','held') or executor is None)
            or device.get('id')!=own['device_id'] or device.get('owner')!=user['username']
            or executor is not None and (getattr(executor,'owner',None)!=user['username']
                                         or getattr(executor,'tenant',None)!=user['tenant_id'])):
        raise WorkspaceError('本机助手未确认在线，请从工作台刷新设备状态',409)
    from .business import BusinessExecutor
    if offline_dev:
        managed=server.company['managedWorkspace']
        executor=BusinessExecutor(server,managed['environment_id'],server.company['id'],user['username'])
    if not isinstance(executor,BusinessExecutor) or executor.tenant!=user['tenant_id']:
        raise WorkspaceError('本机员工归属不匹配',403)
    command={'owner':user['username'],'principal':{'username':user['username'],'role':'operator'},
             'action':'keyword_state','data':data}
    from .ai_workflow import KeywordRevisionConflict
    try:return public(executor(command))
    except KeywordRevisionConflict as exc:raise WorkspaceError(str(exc),409) from None


def _cloud(server, user, operation, data):
    integrations = server.integrations
    with integrations.lock:
        config_value = integrations._read(user['tenant_id'])
    # The decrypted configuration is a request-local snapshot. Do not hold
    # the config lock during a potentially 25-second cloud response wait.
    return integrations._cloud(config_value, user, operation, **data)


def pair(server, user):
    with server.employee_pair_lock:
        return _pair_locked(server, user)


def _pair_locked(server, user):
    assistant = getattr(server, 'assistant_service', None)
    if not assistant:
        raise WorkspaceError('本地助手未启动', 503)
    summary = local_device(server, user)
    if summary['bound']:
        return {**summary, 'paired': False}
    if assistant.vault.read():
        # A pending code could have been issued to a different employee. Never
        # silently reuse or replace it from another browser login.
        raise WorkspaceError('这台电脑有待确认的旧配对，请联系管理员核对', 409)
    name = str(server.company.get('name') or '方隅公寓')[:48] + ' 本机助手'
    result = _cloud(server, user, 'pair_create', {'name': name[:60]})
    code = result.get('pair_code')
    if not isinstance(code, str):
        raise WorkspaceError('企业服务未返回有效配对材料', 502)
    assistant.bind(code)
    summary = require_owner(server, user)
    return {**summary, 'paired': True}


def logout(server, user, token):
    # Remote logout failure cannot leave a usable local cookie/session.
    remote_revoked = False
    try:
        _cloud(server, user, 'logout', {})
        remote_revoked = True
    except IntegrationError:
        pass
    finally:
        integrations = server.integrations
        with integrations.lock:
            config_value = integrations._read(user['tenant_id'])
            config_value.setdefault('sessions', {}).pop(user['id'], None)
            integrations._write(user['tenant_id'], config_value)
            integrations.identity_cache.pop(user['id'], None)
        import hashlib
        with server.core.store.connect() as db:
            db.execute('DELETE FROM sessions WHERE token=?',
                       (hashlib.sha256(token.encode()).hexdigest(),))
    return {'ok': True, 'remote_revoked': remote_revoked}


def gateway(server, user, operation, data, token=''):
    if not isinstance(operation, str) or not isinstance(data, dict):
        raise WorkspaceError('请求格式错误')
    if operation == 'me':
        if not user:
            raise WorkspaceError('请重新登录', 401)
        return {'user': public(user)}
    if operation == 'logout':
        if not user:
            raise WorkspaceError('请重新登录', 401)
        if getattr(server,'development_workspace',False):
            server.development_signed_out=True
            return {'ok':True}
        return logout(server, user, token)
    if not user:
        raise WorkspaceError('请重新登录', 401)
    if operation in ('list', 'publish'):
        raise WorkspaceError('feature_disabled', 423)
    if operation == 'local_device':
        return local_device(server, user)
    if operation == 'local_pair':
        return pair(server, user)
    if operation == 'local_read':
        if set(data) != {'action', 'data'}:
            raise WorkspaceError('本机读取参数无效', 403)
        return local_read(server, user, data.get('action'), data.get('data'))
    if operation == 'product_action':
        if set(data) != {'action', 'data'}:
            raise WorkspaceError('产品操作参数无效', 403)
        from .product_workspace import dispatch
        return dispatch(server, user, data.get('action'), data.get('data'))
    if operation == 'keyword_state':
        return local_keyword_state(server,user,data)
    if operation == 'intent_rules_refresh':
        return local_intent_refresh(server,user,data)
    if operation == 'customer_seen':
        # A view marker is a separate local mutation, never a cloud command
        # or a contact/confirmation event.
        return local_read(server,user,'customer_seen',data,record_view=True)
    if operation in ('customer_response_check_start','customer_response_check_status',
                     'customer_response_check_cancel'):
        return local_read(server,user,operation,data,response_check=True)
    if operation == 'devices' and user.get('development_local_only') is True:
        own=require_owner(server,user)
        return {'devices':[{'id':own['device_id'],'owner':user['username'],
                            'name':own.get('name') or '本机助手','version':own.get('version'),
                            'last_seen':None,'revoked':False,'platform_qa':False,
                            'continuous_qa':False}]}
    if operation not in MEMBER_OPERATIONS:
        raise WorkspaceError('不支持此工作台操作', 403)
    if getattr(server,'development_workspace',False):
        from .development_workspace import verified_after_pending
        user=verified_after_pending(server,user)
        if user is None:
            raise WorkspaceError('企业服务暂不可用；本机资料仍可查看，云端操作请等待连接恢复',503)
    elif user.get('development_local_only') is True:
        raise WorkspaceError('企业服务暂不可用；本机资料仍可查看，云端操作请等待连接恢复',503)
    if operation == 'command_submit':
        own = require_owner(server, user)
        if data.get('device_id') != own['device_id']:
            raise WorkspaceError('只能向本机已绑定的员工设备下达任务', 403)
    # The fixed endpoint and bearer come exclusively from DPAPI. Browser data
    # cannot override either, including through duplicate JSON keys.
    if any(key in data for key in ('operation', 'environment_id', 'endpoint',
                                   'token', 'authorization', 'cookie')):
        raise WorkspaceError('请求包含不允许的字段', 403)
    return public(_cloud(server, user, operation, data))
