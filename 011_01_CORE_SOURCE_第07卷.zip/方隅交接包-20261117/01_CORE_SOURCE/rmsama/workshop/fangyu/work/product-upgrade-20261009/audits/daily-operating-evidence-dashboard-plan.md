# 自营获客证明：每日经营证据看板最小方案

结论：现有工作总览、本人待办和交接导出均是当前有权快照；公司经营对账是单渠道的分页核对。它们已有可靠的流程组件，但尚没有带日期、时区、历史口径和证据覆盖率的严格每日看板。建议下一项是**本人每日记录进展**，先复用本机证据做纯读，不引入新 CRM、包、支付或自动云调用。获取日队列的真正转化漏斗应等历史日期和评定覆盖足够后开放，不能把六个当天活动数画成天然递减的漏斗。

本轮只读源码与已冻结证据、写方案。未读取原业务库、真实客户或凭证，未计算实际业绩、运行旧矩阵、联网或改生产。实际采用 Data Analytics 的 `analyze-data-quality` 窄质量检查，再用 `design-kpis` 定义前瞻指标；现有本地代码是本次结构与语义的权威来源，不是实际经营数据的测量结果。没有基线，不设虚构成交率、数量或增长目标。

## 现有能力及证据范围

| 层级 | 可复用来源与实际字段 | 当前可证明与限制 |
| --- | --- | --- |
| 找到 | `CustomerHistory._visible/_person`；lead `id/platform/author_id/created_at/published_at` | 当前本人有权保存的评论及平台 UID 客户；不是曝光或全平台潜客。缺 UID 的临时身份不能冒充唯一客户；不同平台不能按昵称/手机合并。 |
| 核对/评定 | `effective_intent`、manual `by/updated_at`、AI `analyzed_at`，R23 抽检 | 人工或模型作过评定；看过详情 `viewed_at` 不算核验。人工优先，未知、无关、业务地域匹配分别处理。当前评定会覆盖旧值，不能重建历史首次核对或模型裸准确率。 |
| 联系 | ContactJournal `event_id/kind/occurred_at`、reply/sender 绑定、平台 reply ID | 已记录的审核/发送事实；copied、external_reported、legacy 和 unknown 分列。`send_started` 不算完成，reviewed 不算发送。无完整链或同 UID 另有未知不能显示成纯成功。 |
| 客户回应 | 精确同 UID/帖子、明确 target 原平台 reply ID、晚于发送；观察体 `published_at/observed_at` | 本机观察到明确回应证据；未观察不等于平台没有回应。不能把同帖其他评论或人工说“已回应”混入。 |
| 同意交接 | 当前授权投影、撤回 ledger、handoff `submitted_at`；append-only `acquisition_events` | 操作人记录了客户同意，当前可准备交付；`operator_recorded`/独立核验 false。`ready_to_deliver` 是本机待送达，不是公司收到。事件有 action/status/time/hash，旧事件仅 snapshot_hash，没有旧 consent/qualification 完整历史值。 |
| 资源部确认 | 合法非提交本人 `handoff_receipt` accepted；`receipt.recorded_at`/历史事件 | 本机由授权接收账号确认；与当前同意有效性分别显示。不是跨机器送达、客户身份独立验真或财务权威。公司原 register 核对即便 recorded，也只是 1/draft 的原登记，不升级为 submit/accept。 |
| 成交/现金/分成 | business_reconciliation 单渠道/同客户订单、旧 policy snapshot | reported、admin_reviewed、link、recorded calculated 分开；当前 `verified_cash_cents`/`verified_paid_commission_cents` 是 null，不能称实收、支付或收益。 |

现 `acquisition_overview`（`acquisition_operations.py:715–744`）按全当前权限汇总，`recent` 只是最多 12 条最近交接，没有日期/时区。`self_worklist` 是全有权 UID 一人一项、未知优先的互斥待办 lane，lane 数不是漏斗阶段数。现导出最多 1000 条当前交接，更新时间明确 UTC，有权限/当前授权复核、隐私和公式防护，但没有每日过滤，不能拿导出本批条数当总业绩。

已定位一个现有概览风险：CustomerHistory 可同时给同 UID `contact_state=sent` 和 `uncertain_contact=true`；overview 的待回应只检查 sent/未 observed，未知只检查主 state，旧 sent 可能遮住另一条 unknown。这个快照不能直接成为可信每日证明。每日读层必须采用全 UID 的未知优先和完整 Journal 校验；该问题的代表复现/修复由根另行授权后执行，不在此方案伪称已关闭。

## 最小产品切片与指标

一个入口“本人经营进展”，默认今天，可选有限日期。上部三项主指标：**当天观察到明确回应的客户数、当天准备待交付的客户数、当天由非本人授权接收账号确认的客户数（本机）**。来源、评定和联系作为流程诊断，旁边显示证据等级与覆盖，不对缺失层强造数字。

当天活动的客户可来自以前获取：今天回应数可以大于今天发送数。首版使用“今日记录进展”横向活动卡，不画转化漏斗、不算这些活动数之间的比例。库存另列“截至当前”的高意向、待联系、待交付、已回应，避免与当天活动混合。点击数字回到现有本人待办/客户详情/交接证据；不重新发送或分析。

两项护栏：待核对/未知客户数及证据覆盖率。任何 stage 未配置或不可核，值为 null 并给 reason；有完整可读范围且确实没有符合记录才为 0。抽检只报告软件规则、样本范围与盲标一致性，不能以高意向命中率替代回应率、成交率或回款。

## 日期、主体与去重合同

- 服务端锁定 `Asia/Shanghai`，日期半开区间 `[00:00, 次日00:00)` 转为 epoch；客户端只传 day，不传 owner、设备、时区、任意 source 或可信数值。
- ContactJournal `occurred_at`、handoff `server_recorded_at/submitted_at/receipt.recorded_at` 是 epoch 秒；AI 评定和 response `observed_at` 是带 UTC 的 ISO。lead `created_at` 与平台适配时间可能是本机 **naive ISO**（`engine.now:77`、`adapters.timestamp:820`），旧机器时区未记录，不可默认 UTC 或用当前机器时区倒填。未可核日期单列，不迁移或重算旧 522 条。
- 联系用记录发生日；回应首版用观察日，标题为“当天观察到”，不是客户真实发出日。平台 `published_at` 另展示；旧 published_at 无可核时区则未知。重复检查同一回应不能再次增加发现数，后补 target 导致首次达到证据门槛的日期若未持久记录，不能据最早 observed_at 伪造当时已核对。
- 主体限定当前 saved actor + tenant + current device + 有权 lead。分母按当前有权稳定 `(platform, author_id)`，每客户每阶段每日报 1 人，同时可另报事件条数。缺 UID、来源变更、损坏或未知未解除单列；多个门店/员工/机器的本机人数不能直接相加为总部唯一人数。
- “首次获取日队列漏斗”后续须有可信 first_saved_at、历史评定和阶段事件。一旦开放，分母固定获取队列、截止时间固定，逐层使用该队列的证据；unknown 剔出纯成功并列覆盖，不能拿今天联系的人除今天新入库的人。

## 候选只读接口（未实现）

`self_daily_evidence_summary {day: "YYYY-MM-DD"}`，仅当前本人/当前设备，复用现 trusted saved user、lead access、SelfWorklist/CustomerHistory、ContactJournal.receipt、回应精确匹配和 AcquisitionOperations 的完整事件/当前授权投影。一次 SQLite 读快照，必要的最终身份/设备/公司 fence；不调用模型、平台、云摘要、receipt 写入或缺行 tombstone。

建议返回 `self_daily_evidence_v1`：`read_only:true/mutation_committed:false/storage_scope:this_device/cross_machine_verified:false`，`period{day,timezone,start_epoch,end_epoch_exclusive,basis:recorded_activity}`，`observed_at`、`scope`、`metrics[]`、`coverage`、`limitations`。每项 metric 包含 key/value(nullable)/unit/clock_basis/evidence_level/unsupported_reason 和现有明细入口；公共结果不含原文、裸 UID、联系方式、证据引用或私有规则。

首版不做后台轮询公司所有渠道或跨人聚合，不以候选查找末页代表全公司已扫描。公司经营对账及原操作核对继续手动读既有详情；当可信云范围摘要真正具备稳定去重及时间口径后，才加公司层指标。

无法由旧记录复原的“首次获取”“首次评定”“同意实际发生日”，首版显示不可核/覆盖，不塞默认今天。若总部需要六层完整日报，下一次须在成熟实际写入点增量记录未来安全 UTC 时间及最小阶段元数据；复用现 Journal/事件模式，不另造 CRM，也不扩历史。时间字段/版本与写入点选型应先做最难小样，再由根确认窄实现。

## 下一实现的必要代表小样（本轮未执行）

1. 上海 23:59:59/次日 00:00，UTC 正确跨日；naive/缺时间/future/bool 时间不误计入。
2. 同 UID 不同 lead：旧 sent + 新 unknown，只进待核对，不混纯待回应；同一回复后续确证解除 unknown 时才重新进入可核类别，不凭另一个客户/回复成功解除。
3. 同客户多评论/多次 retry/replay 与重复回应检查，人数不翻倍；无 UID 单列，跨平台不猜同人。
4. 当天观察到昨日回应、后补 target；观察日与平台发生日正确区分，无法核准首次匹配日时标覆盖不足。
5. 先非本人 ACK 后撤回，历史确认留存、当前授权暂停，当前可交付不可增加；经营 calculated 不变成 cash/paid。
6. 快照期间禁用员工/换设备/来源、数据链损坏或读取失败，拒返回成功/未知，不丢掉坏行后声称完整范围为 0。

## 源码收据与取舍

主要证据：`assistant/acquisition_operations.py:416/458/715`，`assistant/customer_list.py:56/99/263/323/359`，`assistant/self_worklist.py:285/354`，`core/contact_journal.py:17/67/212`，`core/response_journal.py:26/95`，`assistant/customer_response_monitor.py:340/410`，`assistant/acquisition_exports.py:29/146/201`，`assistant/business_reconciliation.py:41/263/304`，`web/workspace/upgrade-model.mjs:17`，`upgrade-shell.mjs:44`。范围为当前项目源码/阶段证据；无真实日业绩数据，数量、转化、公司接收或现金均未测量。

收益是让用户知道今天真正完成了什么、哪里缺证据，并给总部一个可追到原记录的演示。代价是初期缺日期的指标会显示未知；这是比用漂亮漏斗伪造确定性更可维护的方案。暂不加预测、排行榜或定价，先解决本人决策与证据表达。
