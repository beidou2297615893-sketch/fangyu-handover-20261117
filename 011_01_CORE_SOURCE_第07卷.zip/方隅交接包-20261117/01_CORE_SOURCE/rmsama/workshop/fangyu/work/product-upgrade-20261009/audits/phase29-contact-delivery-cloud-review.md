# Phase29 公司联系方式交付候选审核

本阶段实现公司范围内的联系方式保管、独立接收人明确查看、原号状态核对及安全撤回候选。新增代码通过当前认证的 `createService`、实际 `createStore` 与既有来源/同意/资源部门权限链；尚未部署、未连接真实 KMS、未传输真实客户资料、未验证第二实体电脑或不同 Windows SID。

## 范围与成熟能力复用

- 新增 `work/cloud/workspace/contact_delivery.cjs`：专属持久操作、渠道占用与密文保管记录；旧交接实体和旧 `platform_reference_only` 证明等级不改。
- 新增 `kms_contact_provider.cjs`：使用腾讯云官方产品包 `tencentcloud-sdk-nodejs-kms@4.1.302` 的 `Client.Encrypt/Decrypt`，不自编加密。
- `service.cjs` 只增加构造期可信注入和四个固定动作的认证分派；`index.js`、默认启动、真实云配置、旧本机 DPAPI 存储与前端未改。
- 服务端配置和会话实际派生公司/环境/员工/设备。请求中的 `expected_device_id` 只用于一致性约束，不能创建身份或授予部门权限。
- 独立依赖位于 `work/product-upgrade-20261009/phase29-kms-runtime`，不安装到其他任务、全局 Python 或旧云运行目录。锁定产品包实际 `package.json`、lockfile 和 Apache-2.0 原 LICENSE。安装使用 `--ignore-scripts --no-audit --no-fund`；上游 `uuid@9` 的弃用提示保留为依赖维护边界，没有盲目升级。

## 固定接口

成功外层精确七字段：`contract:'fangyu-workspace-v1'`、`environment_id`、`company_id`、`delivery`、`read_only`、`mutation_committed`、`auto_retry`。身份不来自 action data。

四个动作均接受 `operation/environment_id/expected_device_id/channel_id/idempotency_key`。其余字段：

| 动作 | 附加精确字段 | 语义 |
| --- | --- | --- |
| `acquisition_contact_publish` | `expected_revision/contact_version/consent_reference/notice_version/phone/wechat` | 来源本人原设备明确交付；同意范围必须与公司渠道一致 |
| `acquisition_contact_reveal` | `expected_revision/contact_version/expected_contact_revision` | 当前映射到原资源部门的另一主体明确查看，有审计，属于写动作 |
| `acquisition_contact_withdraw` | `expected_revision/contact_version/expected_contact_revision` | 原来源主体撤回已存在保管版本并清密文；不要求服务付费继续有效 |
| `acquisition_contact_operation_status` | `operation_action`（前三个写动作之一） | 按本人原动作和原号核对，只读、无墓碑、无 KMS |

`delivery` 精确 31 字段以 `contact_delivery.cjs::publicResult` 和 `phase29-contact-delivery-actual-fixture.json` 为准。新增配置/权限字段为 `retention_configured`、`channel_binding_state:unbound|unknown|recorded`、`permissions:{can_publish,can_reveal,can_withdraw}`。`state:not_recorded` 只表示这个原 key 没有操作记录；渠道可能已有另一原号的未知占用，此时 `channel_binding_state:unknown/can_publish:false`，不能换号或先解密。

`contact` 如有，只含版本、修订、phone/wechat 是否存在和保留/撤回时间。唯一首个成功 `REVEAL` 答复可短暂含 `contact_values:{phone,wechat}`；重复写、status、丢回执恢复和公开证据 JSON 均不返回明文。`original_execution_confirmed` 只取 `true|null`，不存在记录不等于未执行。

## 权限、一次执行与撤回

1. publish 必须同时满足 provider 配置、明确保留期限、当前 handoff 权益、实际员工会话/原来源设备、来源事件完整对应、当前同意、可交接状态和未被占用的渠道。缺配置先拒绝，不创建 attempt、调用 KMS 或触发本机解密。
2. 服务器先在事务中留原操作和渠道占用；KMS 在事务外仅一次。当前 fixture 重放每个事务回调两次，KMS 仍不在 callback 内。
3. 密钥调用后重新核验员工、设备、公司、资源部门、来源、同意、交接修订、服务政策及保管 CAS。失效或 commit 答复丢失保留原操作为 unknown，只能 status 核对，不能重放明文或换号。
4. Encrypt await 期间尚无 vault 时，客户撤回复用已有 `acquisition_handoff_withdraw{channel_id,expected_revision,idempotency_key,reason_code:'customer_withdrew'}`。此动作即时写交接撤回及同意 tombstone，不等待联系方式落库；原发布最终拒绝、无密文 vault。`contact_revoke` 本机动作不能冒充公司撤回。
5. 已记录 release 是服务器保管访问事实，不证明客户接听、联系成功、客户回应、独立 consent 核验、平台来源、成交或回款。历史 release 和当前撤回分列；`verified_cash_cents/verified_paid_cents` 一直 `null`。无法撤回已被获权用户截图的资料。

## 已执行代表与证据分类

- `contact_delivery.test.cjs` 固定三项有意义方法：原 publish 提交完成后丢回应、重启原 status、另一真实映射资源主体明确 release；渠道单 claim/重复与替换 key、Encrypt await 客户撤回、Decrypt await 资源撤权；缺配置/缺保留期限、release 丢回执不重放、明确撤回、审计损坏和无公司状态不初始化。
- `phase29-contact-delivery-hardest-first.txt` 是新 Python 夹具误把投影 consent 的额外字段传入成熟严格 contact API；改为原三字段后 `...hardest-second.txt` 1/1 通过。当时仅直接新 helper，不能算最终 production route 已接。
- `phase29-contact-delivery-entry-first.txt` 与 `...entry-second.txt` 保留阶段原日志：三方法中一个失配为撤权后的 HTTP 安全拒绝状态映射（503/409 与指定403），均无明文放行或二次 KMS。最终将成熟不可见/无权类型映射固定安全403；不称这两个运行各新增测试。
- `phase29-contact-delivery-entry-green.txt`：同三方法 3/3，5765.0115ms。后续只因新增当前政策签名和独立不可变 anchor 核查而按最终源码一次必要复验；最终结果和 SHA 将写固定 final manifest，不能把阶段 green 当后续源已验。
- 安全 emitter 产生 12 个实际服务答复，刻意不持久化首个 release 的明文。当前代表每个 callback 最大21项操作（读取最大19、写入最大5），状态/缺配置样例0写。此为 SDK **接口**隔离内存 adapter 双 callback，不是腾讯 node-sdk 内部事务引擎、真实云 30秒性能或可商用吞吐验收。

根独立两项实际入口反例另有真正生产候选缺陷：把私有 operation/audit 的 actor、device、派生 id 自洽改写并重算摘要，原 STATUS 仍确认；把 vault 的渠道或来源自洽替换，原 REVEAL 可解密，替换 encryption context 也会先调用 KMS。这是隔离私有文档损坏场景，不是公共远程接口取得修改私有库权限。首 RED 和11个源前后不变的证据保留在 `phase29-contact-delivery-independent-first.txt` 等根独立文件。

新 helper 已补固定 opId/actor、原设备 owner/digest、原来源、部门/用途/同意、内容元数据摘要和事件审计的对应；vault 必须对应渠道占用和已记录原发布、完整服务器派生 encryption context 与 provider signature。在创建尝试和调用 KMS 前核对。历史 STATUS 可以由同 actor 的新当前设备读取旧设备记录，但旧设备仍须保留相同 owner/digest 的历史元数据；旧写不能以新设备重放。未扩大来源或资源部角色权限。修后本组三方法按最终956E223C源码通过3/3，4973.42ms；包含同方法中的真实旧设备历史读取/拒写代表，不额外计为测试方法。

两 Core fixture 使用合成隔离库和真实 CurrentUser DPAPI；二者属于同一 Windows SID。官方 KMS Client 的 `request` 边界使用 opaque map，没有加密算法或真实 KMS 请求。所有 HTTP/HTTPS/net/fetch 禁止；本地 source 事件和联系人都是合成数据。

## 官方依据与未验事项

直接 KMS 小数据 API 的 4KB 限制、KeyId 与相同 EncryptionContext 使用方式来自[腾讯云 Encrypt API](https://intl.cloud.tencent.com/document/product/1030/32788)、[腾讯云 Decrypt API](https://intl.cloud.tencent.com/zh/document/api/1030/32198)；采用[官方 Node SDK](https://github.com/TencentCloud/tencentcloud-sdk-nodejs)。事务外部请求和100操作上限依据[CloudBase 事务文档](https://docs.cloudbase.net/database/transaction)。云函数登录或 API key 不证明 KMS IAM 权限；[CloudBase 资源整合说明](https://docs.cloudbase.net/cloud-function/resource-integration/cloudbase)指出 HTTP 云函数不会自动注入 SecretId/SecretKey。

本轮没有注入真实 KeyId/region/credentials、创建 KMS Key、付费或部署。Server 能短暂处理明文，因此不称端到端加密；JavaScript 字符串也不能保证全部内存清零。现有包装默认 provider/retention 为 `null`，默认状态不能发布，不假称真实 KMS 可用。完整双实体机、真实角色/IAM、SDK 内部事务、网络超时和真实公司验收留待实际授权环境。

consent-registry skill 只用于审核原则；它引用的两个 registry references 在本机缺失，本轮没有构造或调用不存在的外部 consent registry。最终用户整体认可、真实平台、真实公司交付与商业结果仍未验证。

## 收尾状态

956E223C/30A82FF1/FE6E303D 三源最终冻结，不再改 producer。根原独立两方法已2/2通过，1843.5787ms，11个源 before/after 相等；原 actor/device/派生 id 和 foreign vault/context 反例保持原断言，调用前拒绝、0明文/0额外Decrypt/0私有写。日志为 `phase29-contact-delivery-independent-final.txt`，根独审另出报告；不把重复复跑计成新增覆盖。

最终源、唯一三方法、实际 JSON、emitter、官方包/lock/LICENSE、旧 service 与候选原字节备份冻结于 `phase29-contact-delivery-cloud-final-hashes.json`。实际安全 JSON SHA42CFB5C8，最大 callback22项操作、读取最大21、写入最大5，之前21项数字只属于补 anchor 前的历史运行。未重跑旧阶段全部矩阵，尚不能称整个产品或本机 UI 已完成。

本切片一个渠道只保留一个受保护联系方式发布版本；未知占用不能透明覆盖，即使新 key 没有操作行也不解锁。没有新增“换号码后自动再发布”或已丢明文自动再次查看机制，后续需要明确的新操作及同意/用途规则，不能借重启绕过未知。
