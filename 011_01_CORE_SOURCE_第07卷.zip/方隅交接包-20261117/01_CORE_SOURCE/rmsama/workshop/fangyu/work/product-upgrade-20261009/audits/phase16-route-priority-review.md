# Phase16 只读路线优先级审查

日期：2026-10-10。范围仅方隅公寓客户版，生产源、旧测试、原业务库、账号会话及 Cookie 均不改动。尚未获准实施新功能；本报告和合成代表脚本是路线证据，不是账号跑通或商业验收。

## 推荐

优先做 **“已有采集任务运行前预检”**，先支持现有私有策略快照的明确单批任务。它能把“为什么现在不能采集、词库大不等于请求吞吐、下一步该核对什么”集中呈现，直接减少本人在策略、账号和采集任务之间反复查找。预检只读，人工选择后才进入原有运行入口；实际运行仍重新执行现有门禁。

本轮不优先解锁归档客户的自动回复目标。R22 来源保存只证明服务器拥有该次读取证据；归档的 `author_id/comment_id/target_*` 发送字段留空，`reply_target_status=not_verified`。`source_uid`、昵称、URL 或适配器报告的 UID 不能自行升级为可信发送目标。只凭离线资料可做缺项诊断，却不能完成“当前可向本人准确发送”闭环；若为此绕过实际 `Core._reply_context`，会破坏已验收防误发边界。后续须独立获得受许可、同账号、同原评论和同目标的实际平台协议证据，当前不具备。

## 已有成熟路线与精确复用点

|已有实现|可以复用|不能推导|
|---|---|---|
|`core/platform_capabilities.py:74 capability_catalog()`|可信 manifest 的安装、动作、许可复核和企业策略元数据；主动保持 `operational=false`|CLI 已登录、真实平台已验、账号可采集|
|`core/platform_reads.py:392 _availability()`；`platform_read_status`|账号当前存储状态、固定读取 route、CLI/隔离/连接及 search contract 检查|账户 activity 风险已复核、账号未被占用、真实协议当前可用|
|`assistant/acquisition_strategy.py:173 _summary()` / `strategy_get`|策略版本、启用词数、批次、保留词槽/剩余词槽；不用向员工投影私有词|词槽是 HTTP 请求额度或安全 QPS；账户收费已核验|
|`assistant/strategy_tasks.py:210 project_task()` / `strategy_task_get`|本人有权的已存任务和策略摘要，不返冻结词/断点/原错误|查询缺号就是原创建未执行|
|同文件`:231 _validate_snapshot()`、`:242 guard_task_action()`|冻结词摘要、租约、原任务归属、`max_batches=1`、暂停/耗尽检查逻辑|预检结果代替运行时再核或授权运行|
|`core/account_safety.py:403 account_review_view()`，`:245 summarize_activity()`|明确路径内的本机 activity 风险小投影，损坏/未结束记录保守阻断|没有异常记录就是安全；建议间隔就是平台允许频率|
|`core/engine.py:159 account_mode_status()` → `AccountModeLeases.get()`|已有模式记录只读；占用/未知进程状态提示|纯读取得独占执行权或自动释放旧租约|
|`core/engine.py:1159 _collection_summary()`|目标/日限/耗尽、既有资格检查思路|可直接作为完整预检；它需先有运行停止状态，还不是独立产品入口|

当前 UI 策略快照只有创建/查看以及转到采集任务的提示。未见独立预检 action、所有检查结果的统一投影，或预检版本与确认运行的闭环。并行静态审查只看三份相关代码，未运行旧矩阵。

**副作用排除：** 不调用 `strategy_task_status` 作预检——缺号分支会写 `cancelled` 墓碑；不调用 `reserve_batch()`/`complete_batch()`；不调用 `Adapters.account_spec()`——它创建账号目录，并会写 OpenCLI 配置；不调用 `_require_customer_xhs_identity()`——缺 UID/重复 UID 会写账号/任务状态；不调用 `acquire_account_mode()`/命令文件锁、`verify()`、`search()` 或 `collect_batch()`。预检需要复用其纯校验条件，不能复用这些有副作用的执行函数。

## 实际代码代表：存储 ready 与未复核风险同时存在

新脚本 `audits/phase16-readiness-route-probe.py` 构造本项目专属临时 Core、合成 manifest/账号及一条完整 started→HTTP461 finished activity；运行现有实际 `PlatformReadService`、`AcquisitionStrategy`、安全总结及适配器门禁，不替换这些业务实现。禁用网络连接和进程启动，直接跟踪 SQLite 查询并比较读前后 dump；仅写新临时夹具及新证据文件。

结果：

- `platform_read_status.read_availability.search = ready_for_guarded_read`，同时 `live_checked=false / real_platform_verified=false`。
- 同账号实际 activity `state=review_required`；实际 `Adapters.require_account_safe()` 拒绝继续，未触发 CLI。
- `suggested_trial_gap_seconds=null`。单次异常记录不能构造数值安全间隔。
- 目录仍 `operational=false / real_verified=false`；策略单位仍 `keyword_query_slots`。
- SQLite mutation 语句 0，dump 不变；合成 activity 与保留标记 hash 不变；平台/模型/云、实际 Cookie 读取与进程启动均 0。

这是 **1 个代表路线 probe**，不是新安全预检实现的完整测试。它证明只显示绿色 stored-ready 会遗漏重要阻断层；不意味着现有 R22 真正执行会绕过安全门禁。现有真实执行仍会调用后续门禁。完整结果和所用五份生产源 SHA 在 `phase16-readiness-route-probe-result.json`，尚未进行真实账号/平台验证。

## 规模与速度口径必须修正

旧 `cli-route-audit.md` 中“500 个词”的上限属于旧关键词池。当前后台策略 `MAX_KEYWORDS=50000`，单个私有快照冻结 **1–100 个词，默认20**；不因此把几万个词提交平台并发执行。

`keyword_query_slots`、平台请求数、采集单批是三种单位。`pipeline._discover()` 只取当前一个词；一个词可返回多个帖子，评论及楼中楼又可分页；一轮 `collect_batch()` 不等于全部冻结词完成。策略快照设置 `search_pages=1`，但自然网页 `range_state`、视频号游标可控制继续；它不是所有 route 的严格总请求上限。私有策略词槽在完整快照耗尽后结算，也不能用来计实际 HTTP/页面请求。

因此首版显示计划词数、范围、断点阶段和限额单位，但 **实际请求上界/运行时长/安全速率维持 null**，不报虚假的“预计几分钟获客多少”“每秒1次安全”或“已配置10000目标即可得到10000精准客户”。日限和目标是本机线索计数约束，不是平台授权速率。真实 yield、精准度、回应及资源部接受仍由独立经营证据验证。

## 最小拟实现合同（待根批准；本轮未实施）

新增独占后端 `assistant/collection_task_preflight.py`，构造可信 `core/tenant/owner/company/device_id/scope_guard/license_policy_provider`；只读 action `collection_task_preflight_get`，客户端只 `{task_id}`，不能传平台、账号、UID、连接、可用标志、许可、速率或词数。先支持现成策略快照，避免首版扩至所有持续采集/外部工具。

结果最小字段建议：`contract/read_only/local_only/storage_scope/cross_machine_verified`；`task_id/platform/account_id/task_revision_or_digest`（内部固定摘要，不返私有词）；`state=blocked|eligible_for_explicit_run|unknown`；固定枚举 `blocking_reasons`；`planned_keyword_count/quota_unit`；`live_checked=false/real_platform_verified=false/rate_safety_verified=false/request_upper_bound=null/platform_requests_started=false/provider_requests_started=false/cloud_requests_started=false/mutation_committed=false/auto_retry=false`。`eligible_for_explicit_run` 仅表示当前本机静态检查未见阻断，文案“可进入单批运行确认”，不称已登录验证或平台可用。无需新增持久化表、幂等 key、收据、恢复墓碑或本机计费。

服务端合并检查必须包含：fresh saved actor/company/device 与 task_access；当前任务/快照/租约版本；企业运行 hold/许可/CLI真实入口文件/隔离与 route；本人账号平台/状态/UID/同 UID 重复记录/必要 conn；已有活动异常/损坏/未结束；运行模式占用和未知；时间窗/暂停/耗尽及现有本机目标范围。只投影当前有权任务/账号的小摘要，activity 原行、UID、Cookie、连接详情、CLI命令/路径、私有关键词不返回前端。

无 activity 只能“尚无足够记录”，速率仍未知；它不是已复核证明，也不擅自清 hold。其它平台没有成熟风险记录协议时显式缺项，不使用小红书规则推断安全。所有读前后复核 actor/device/company/task/account/manifest/许可/租约及 activity 版本；变化则拒绝旧结果。跨实例真实运行仍使用现有原子账号租约，预检不保证它随后仍空闲。

UI 在已有快照详情增加明确“运行前检查”，按问题给出固定操作指引，纠正后可再查；保持原明确单批运行入口，不启动、不登录、不续期、不修复 Cookie、不消费词槽，不因打开详情自动预检/自动恢复/自动跑下一账号。原未知任务/创建/发送槽位保持，预检不清除它们。

## 下一步仅必要代表验收

1. 本轮已过的 hardest：ready + 未复核461必须 `blocked`，同时风险日志/原会话/SQL/词槽零修改。再加坏 JSON 或未结束 activity，不能当“无异常”。
2. actual Core 两账号相同 UID 或原账号被另模式占用：返回固定阻断，无写状态/无释放租约；不同本人账号可分别预检，不读他人凭据。
3. 原冻结快照被改、原租约未知、任务已耗尽：不得提示可运行，不调用带墓碑的 status，不换 key 绕过旧状态。
4. 最后一次本机读后换 actor/device/company/account UID/许可/activity：拒旧结果，不返私有词，也不触发运行。运行入口另做 fresh 门禁，不接受前端“预检通过”布尔值。
5. actual UI 显式检查→安全展示阻断→进入已有详情纠正路径；切范围后的晚结果不回填。只衡量路径成本：从已有任务可一次看到阻断、无需手填账号或搜索CLI错误；不以离线 fixture 的0/100%声明获客、转化或商业可用。

不需要新 GitHub 包或迁移：现有成熟能力/任务/安全模块已足够验证此窄路线。已评估当前可见 skills：`agent-reach` 本轮实际阅读，用其“仅互联网获取、不是已有内容加工”的适用边界排除外部 doctor/search；不访问任何平台或版本源。代码与合成证据量很小，直接本地筛选即可；不强行叠加营销、UI或付费诊断 skill。若以后要更新 CLI 来源/许可或真实平台能力，才启用该路由及 primary 官方/GitHub 验证。

冻结时额度实读94%使用/6%剩余；严格剩余<5%保存并通知根暂停，本报告不自行解锁任何长任务或授权新实施。
