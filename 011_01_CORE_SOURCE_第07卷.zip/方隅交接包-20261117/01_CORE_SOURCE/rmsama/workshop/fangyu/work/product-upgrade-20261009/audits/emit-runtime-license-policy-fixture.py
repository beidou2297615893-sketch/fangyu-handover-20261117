"""Emit isolated real-getter/real-guard results; never install an approval."""
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import sys
from tempfile import TemporaryDirectory

PROJECT = Path(__file__).resolve().parents[3]
sys.path[:0] = [str(PROJECT / 'work/app/tests'), str(PROJECT / 'work/app/src')]
sys.dont_write_bytecode = True
from test_runtime_license_policy import PolicyFixture
from app import AppServer


def main():
    folder = PROJECT / 'work/product-upgrade-20261009/tmp/runtime-license-policy-fixture'
    folder.mkdir(parents=True, exist_ok=True)
    with TemporaryDirectory(dir=folder) as tmp:
        f = PolicyFixture(tmp)
        cases = {'default_unknown': f.server.platform_read_license_policy}
        pending = deepcopy(f.review)
        pending['review']['decision'] = 'pending'
        f.install(pending)
        cases['pending_unknown'] = f.server.platform_read_license_policy
        f.install()
        before = f.file_snapshot()
        cases['synthetic_approved_exact_route'] = f.server.platform_read_license_policy
        cases['same_route_second_read'] = f.server.platform_read_license_policy
        f.server.core.adapters.xhs_page_runtime = object()
        cases['other_actual_transport_denied'] = f.server.platform_read_license_policy
        f.server.core.adapters.xhs_page_runtime = None
        denied = deepcopy(f.review)
        denied['review']['decision'] = 'denied'
        f.install(denied)
        cases['explicit_synthetic_denial'] = f.server.platform_read_license_policy
        unchanged = before == f.file_snapshot()
        document = {
            'synthetic_only': True,
            'evidence': 'actual_AppServer_property_Adapters_manifest_and_mature_guard_over_temporary_files',
            'real_component_approval': False,
            'real_platform_login_or_read': False,
            'CLI_executed': False,
            'SQL_accessed': False,
            'resolver_files_unchanged': unchanged,
            'synthetic_review': f.review,
            'cases': cases,
            'approved_content_tree_checks_per_getter': 2,
            'unknown_content_tree_checks_per_getter': 0,
            'source_metadata': {
                str(path): hashlib.sha256((PROJECT / path).read_bytes()).hexdigest()
                for path in ('work/app/src/app.py', 'work/app/src/core/runtime_license_policy.py',
                             'work/app/tests/test_runtime_license_policy.py')},
        }
    target = PROJECT / 'work/product-upgrade-20261009/audits/runtime-license-policy-actual-fixture.json'
    target.write_text(json.dumps(document, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'output': str(target), 'synthetic_only': True, 'cases': len(cases),
                      'sha256': hashlib.sha256(target.read_bytes()).hexdigest()}))


if __name__ == '__main__':
    main()
