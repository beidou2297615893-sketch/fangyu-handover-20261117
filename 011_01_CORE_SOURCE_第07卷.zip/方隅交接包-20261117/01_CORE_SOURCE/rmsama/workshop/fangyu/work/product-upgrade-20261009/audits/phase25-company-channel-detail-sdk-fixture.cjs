/* Actual existing service/store through synthetic SDK-interface callback replay. */
'use strict';
for (const name of ['node:http','node:https']) require(name).request=()=>{throw Error('network forbidden');};
require('node:net').Socket.prototype.connect=()=>{throw Error('network forbidden');};
global.fetch=()=>{throw Error('network forbidden');};
const {fixture,hash}=require('../../cloud/workspace/handoff-operation-status-fixture.cjs');
const DETAIL='acquisition_handoff_detail';
async function pureDetail(f,channelId,token=f.tokens.source,transform=null){
  const before=f.data.snapshot();f.data.resetOperations();
  const run=f.data.db.runTransaction,callbacks=[];
  f.data.db.runTransaction=function(callback){return run.call(this,tx=>{
    const count={reads:0,writes:0},context={};callbacks.push(count);
    return callback({...tx,collection:name=>({doc:id=>{
      const ref=tx.collection(name).doc(id);return {
        get:async()=>{count.reads++;const snapshot=await ref.get();
          return transform?transform(name+'/'+id,snapshot,context):snapshot;},
        set:async value=>{count.writes++;return ref.set(value);}
      };}})});
  });};
  try{
    const result=await f.call(DETAIL,{channel_id:channelId},token);
    return {result,before,after:f.data.snapshot(),operations:f.data.operations(),attempted_callbacks:callbacks};
  }finally{f.data.db.runTransaction=run;}
}
module.exports={fixture,hash,DETAIL,pureDetail};
