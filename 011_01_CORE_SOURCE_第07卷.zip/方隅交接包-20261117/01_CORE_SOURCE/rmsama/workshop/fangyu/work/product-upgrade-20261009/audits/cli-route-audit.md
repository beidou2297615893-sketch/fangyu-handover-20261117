# 方隅大改：CLI、平台接入、关键词吞吐与动作回流审查

审查日期：2026-10-09（Asia/Shanghai）。性质：只读源码审查与公开一级资料研究。没有登录、安装、构建、请求获客平台、采集、发送、付费或变更业务数据库。唯一写入为本文件。不是完整产品验收。

## 结论

1. 当前已有大量可复用代码，但“界面改好就能商用”“核心组件没有问题”尚无证据。最新交接明确：CLI 首次搜索和首批评论 HTTP200，后续评论 HTTP461，手机异常后停机；新自然网页连续采集、分页、验证恢复未通过。UI、数据与平台稳定性必须分别验收。
2. 我们可以掌握调度、账号隔离、数据契约、平台适配、审核和事件账本，也能维护冻结的 CLI 分支；无法通过自研令第三方平台无限开放、消除验证、保证手机号/微信可得。CLI 是操作接口，第三方网页/API 是真正外部依赖。
3. 用户本次重新要求知乎、快手、视频号、B站等，覆盖历史“知乎移出”的范围限制；应按平台和能力增量接入。不能把“所有 GitHub CLI”作为可验收交付：同名工具常是无关实现、下载器或空脚手架，许可证、账号和维护成本不同。推荐每个平台保留一个主适配器和一个经过核验的候选。
4. 万词可以成为后台策略库目标，不能等于万词并发或一次搜索。目前硬上限500；逐词、逐页、逐帖、逐评论页运行，瓶颈通常是平台请求和去重后的有效线索收益，而非词库容量。没有真实负载证据支持每天500/1000/10000条有效客户。
5. 外部网页手工回复回流可做“受控窗口中观测到的事件”或“官方授权 webhook”，无法覆盖任意浏览器、手机、员工私人账号及线下沟通；小红书私信当前无已验证契约，不能在界面上标成可用或已监控。
6. 先交付小红书最难链路、真实线索可追溯、可审核交接和高级 UI，再逐平台扩展；演示中各入口明确显示“已验证／待连接／只读／待验收”，全功能可见与全平台已跑通是两件事。

## 已实际使用的能力与边界

- 已读取 `agent-reach/SKILL.md` 与 `references/dev.md`，尝试官方 `gh search repos` GitHub 路由；本环境 gh 未认证，不登录、不配置凭据，改用 GitHub 无鉴权公开 API 和浏览工具一级仓库页面。`agent-reach` 命令本身不在 PATH，未假称 doctor/check-update 成功。
- 已读取 `context-mode/SKILL.md`。本会话未发现可调用 context-mode MCP；对超大 STATUS 和源码采用本地 rg/定向筛选，仅返回命中段。未声称已有 hooks、自动捕获或 OS 安全沙箱。
- 读取根 AGENTS、HOT、共享规则、项目 AGENTS/PROJECT、最新交接与 STATUS 相关证据；本任务最新用户要求优先，保留暂不打包、账号待复核和历史数据。

## CLI 原理、可控制部分与版本备份

当前小红书上游是 `jackwener/xiaohongshu-cli`，本地包元数据固定0.6.4，Python >=3.10。核心流程是：登录会话 → 签名 HTTP 请求 → 搜索笔记 → 评论及楼中楼分页 → JSON 归一化；不是“看到所有网页操作就会自动同步”的通用爬虫。其源码包含 client、cookies、signing、reading 与 interactions。上游 README 的架构说明可复核于 [官方仓库](https://github.com/jackwener/xiaohongshu-cli)。

现有应用已经在外部工具前增加实际控制层：

| 控制点 | 当前证据 | 可继续开发 |
|---|---|---|
| 命令限制 | `work/app/src/platform_cli.py:343` 仅放行 login/status/whoami/search/read/comments/sub-comments/reply | 版本化 capability registry；收费权限仍由服务器决定 |
| 账号目录及独立执行 | `core/adapters.py:335`；`core/adapters.py:384`；`core/continuous.py:152` | 平台UID绑定、设备占用租约、可见账号切换状态 |
| 风险前置停机 | `platform_cli.py:169-203` 每次请求前后检查活动记录，不自动重放不明请求 | 保留账号复核；不能因演示隐藏真实失败 |
| 搜索与分页 | `core/pipeline.py:166` 一次一个关键词，保存 keyword_index/search_page/note_index/cursor | 独立策略库、任务队列、优先级与预算 |
| 结果契约 | `core/adapters.py:767` 评论归一化；`core/adapters.py:814-817` 回复结果 | 统一平台事件、证据等级与回流时间 |
| CLI/自然网页选择 | `core/adapters.py:400` 与 `assistant/xhs_page_runtime.py:319` | 可替换 transport，但必须逐路线验证 |

现运行库 `work/app/work/runtime/platform-cli-guarded/guard-manifest.json` 记录：purpose=`internal_qa_only`，source SHA256 `2580bd579de76191a5bfd33109c612287f19c94bc55dc10fb64873a31676bb31`，exe SHA256 `5697bfbbeee13e4572f4fa47d4f5bec829bea278403c2da323cb9ffa7b3c648b`，runtime tree SHA256 `c7da4bb61f8c95e38490def1a0078d81d4dcc16630060bcb671a53f1a05ee621`。这是读取清单，未在本轮重算整树；不能凭这份记录称正式发布合格。

后续轻量备份应保存：精确上游 commit/源码与补丁、exe、依赖锁、许可证/NOTICE、契约夹具、guard manifest、版本切换说明和回滚验证。账号凭据及业务库与通用组件分开，业务备份由主任务按现有权限单独处理；禁止把 Cookie 放入审计报告或公共仓库。

自研建议：先把 `PlatformAdapter` 的 account_status/search/comment_page/reply/observe_events 五类接口掌握在应用内；复用当前 CLI/受控网页 transport，单独测试替换。不要重写已经稳定的存储、UI 和全部平台；不得为了“自研”加入反爬绕过、账号规避或验证绕过。

## 平台、开源候选与许可/维护证据

维护快照来自 2026-10-09 GitHub REST 公共 metadata；pushed_at 代表最近推送，不证明平台今天可用。表中“本地”指当前源码能力，非真人验收。

| 平台/候选 | 当前本地或候选能力 | 许可/维护快照 | 接入判断与代表验收 |
|---|---|---|---|
| 小红书固定CLI：[jackwener/xiaohongshu-cli](https://github.com/jackwener/xiaohongshu-cli) | 本地搜索、主/子评论、评论回复；当前企业仅开放此平台且 automation hold | 本地0.6.4元数据声明Apache-2.0；公开仓库API license=null、未归档、pushed 2026-03-21。需核对该精确包的授权文本/NOTICE，null不能单独判无授权 | 继续复用；验证一词跨页、跨帖、去重、保存断点、异常停止、一次人工审核新回复及平台回执 |
| 小红书自然网页 | status/search/comments/sub_comments四类只读入口；DOM搜索与网页产生的评论响应 | 本项目 transport，沿已有许可文件；真实连续链路未验收 | 单独代表样例验收，不能用历史CLI的511/527条证明新路线稳定 |
| 抖音：[Yht20927/douyin-cli](https://github.com/Yht20927/douyin-cli) | 已有Bridge源码与清单：search/comments/reply；私信发送分支有条件门禁 | MIT；未归档；pushed 2026-09-27 | `search_verified=false`，`verification_level=isolated_local_help_verified_prior_project_used`。先固定独立conn_id→搜索→一评论页→归一化→真实回复回执，不能把help视为搜索通过 |
| 抖音备选：[Youhai020616/douyin](https://github.com/Youhai020616/douyin) | Python dy-cli，搜索/详情/评论等结构化接口候选；登录互动依赖浏览器 | MIT；未归档；pushed 2026-09-12 | 本地有dy-cli许可资料，但当前主清单已走Bridge；先对比最难真实链路与依赖重量，不同时引入两套账号系统 |
| 知乎：[OpenCLI](https://github.com/jackwener/OpenCLI) | 本地1.8.8清单 search/comments（回答评论），local_help_only | Apache-2.0；未归档；pushed 2026-09-24 | 本次重新纳入；已有mapper优先增量复用，独立浏览器会话、搜索和一页回答评论逐项实测；回复/私信不能默认开放 |
| B站：[public-clis/bilibili-cli](https://github.com/public-clis/bilibili-cli) / OpenCLI | 官方仓库自述浏览/搜索/用户/feed；当前OpenCLI索引列搜索等，但没有B站评论命令 | 前者Apache-2.0，未归档，pushed 2026-03-14；OpenCLI同上 | 当前方隅无B站适配清单。先验证能否采到相关评论；只有视频搜索不满足评论获客。不可把存在CLI写成已接入 |
| 视频号：[nobiyou/wx_channel](https://github.com/nobiyou/wx_channel) | 本地wx_channel_http search/comments；single local_wechat_session；不支持账号隔离、回复、私信 | 上游根MIT，依赖复核未齐；未归档，pushed 2026-10-06 | `verified=false/search_verified=false`，真实微信待验。先本机服务身份与版本→一次搜索→评论页；跨机/多账号不得复用单会话假装实现 |
| 快手现有自有Bridge | 指定作品公开评论只读，无关键词搜索/发送 | 本地来源private=true/license=UNLICENSED；需所有人确认商业分发权属；详本地授权范围文档 | 先保留用户已有代码最小链路。连接隔离/作品ID/游标/重复/清单回流验收；“自用”也不是许可证豁免 |
| 快手备选：[tamnd/kuaishou-cli](https://github.com/tamnd/kuaishou-cli) | README明确fresh scaffold，仅page/links示例 | Apache-2.0；未归档；pushed 2026-06-29；仅2 commits | 不满足完整评论获客，不能替换现有Bridge，也不能因名字含CLI就纳入商用路线 |
| 多平台：[NanmiCoder/MediaCrawler](https://github.com/NanmiCoder/MediaCrawler/blob/main/LICENSE) | 多平台采集候选 | 非商业学习许可证1.1，商业用途需著作权人书面同意；活跃不等于可商用 | 当前公司的获客目标不能直接采用该默认许可；本地也已列REVIEW-ONLY，避免重新安装后误接 |
| 视频号下载器：[qiye45/wechatVideoDownload](https://github.com/qiye45/wechatVideoDownload) | 下载视频/直播等，未证明评论获客与消息回流 | 公共API license=null，pushed 2026-10-05 | 不作为本任务主候选；下载器不等于搜索评论和客服 |
| 发布器：[social-auto-upload](https://github.com/dreammis/social-auto-upload) | 多平台作品上传 | MIT，pushed 2026-09-02 | 目标是获客与客户消息，不是作品发布，不纳入最小组合 |

OpenCLI平台命令以其 [当前官方适配器索引](https://github.com/jackwener/OpenCLI/blob/main/docs/adapters/index.md) 为准。版本1.8.8的本地清单不能自动继承最新上游的全部能力；更新要锁 commit/许可、执行契约测试并保留旧版。开源软件许可与平台的账号/接口许可是不同层次。

公开API证据入口：[小红书metadata](https://api.github.com/repos/jackwener/xiaohongshu-cli)、[OpenCLI metadata](https://api.github.com/repos/jackwener/OpenCLI)、[抖音Bridge metadata](https://api.github.com/repos/Yht20927/douyin-cli)、[dy-cli metadata](https://api.github.com/repos/Youhai020616/douyin)、[视频号metadata](https://api.github.com/repos/nobiyou/wx_channel)、[B站metadata](https://api.github.com/repos/public-clis/bilibili-cli)、[快手metadata](https://api.github.com/repos/tamnd/kuaishou-cli)。这些链接是动态快照，后续可变。

## 关键词不是提示词：千/万规模的正确方案

当前 `assistant/ai_workflow.py:13` 的 KEYWORD_POOL_LIMIT=500；:64/:81候选和已选都受限；:237合并后再拒绝。AI联想、客户端任务、云命令、服务端校验、缓存/版本都须一致改造，不能只把UI的150改成10000。

`core/pipeline.py:166` 只把 `keywords[keyword_index]` 传入一次搜索，`core/adapters.py:597` 拼接当前任务词；并不是让CLI理解成千上万个提示词。关键词用于平台检索，提示词用于语义分类，知识库用于楼盘/区域/预算/入住时段规则，应分开存储并版本化。

推荐后台词库能扩展至1万级，但本轮先保留既有500池不破坏当前状态，在新表引入 strategy_id、地域、场景、优先级、去重词簇、最近执行、实际产出、淘汰原因和版本。员工只填区域与需求及开始/暂停，后台负责词库。以后资料入库后生成候选、合并同义词、检查歧义和排除规则，按收益选择有效工作队列；未知与缺正文继续待核实。

有效吞吐的近似模型是：搜索页请求＋去重后的帖子评论页＋必要楼中楼＋会话检查＋人工处理与恢复；同一账号还有采集/发送互斥。固定CLI本地 `client.py:54` 默认request_delay=1.0只是实现参数，不是平台官方安全频率。`Adapters.execute:384` 默认35秒超时，子命令可另设；长关键词不是把超时加大就能更快。

**纯示例、不是承诺**：1000词每词3页搜索已至少3000次搜索；若平均每词命中去重后20帖、每帖2页评论，再增加40000次评论读取。每请求若仅按1秒算，合计43000秒约11.9小时，尚未计网络/运行开销/验证/回复/重复楼中楼。10000词相同假设约119小时。实际需按去重后的帖子数重算，不用该示例定每日额度。

验收顺序：离线100/1000/10000词调度和断点恢复→授权恢复后的少量真实词与一帖两页→证明稳定再扩大。记录请求次数、完成时长、唯一评论、新线索、人工确认高意向、回复/留资/资源部确认、异常率、token与实际成本。选择单词/词簇按“每小时有效留资”排序；低增量、高重复或高异常词降权。不得承诺100%分类精度；采用人工标注样本精确率/召回率与高意向拒识，必要时把不确定项送审核。

## 手工网页回复、私信与防截流的技术边界

当前 `xhs_page_transport.py:24` 和 `assistant/xhs_page_runtime.py:23` 只允许status/search/comments/sub_comments。`xhs_natural_window.py:324-346` 处理限定读取响应，不是后台持续监听所有发送行为。`core/adapters.py:792-800` 私信分支仅在抖音且dm_contract_verified成立时执行；小红书只走:814评论reply，不能宣称支持私信。

要做网页手工回复回流，先验证一个受控账号和受控页面：取得真实平台评论ID、目标评论ID、账号UID、正文、时间、成功回执→新建observed event→与已采集source_comment关联→只读回查确认。仅点击“打开原帖”不是回复成功，发起请求也不是送达；观察到成功仍不证明客户阅读或留资。未识别的动作标“待核实”，不得直接改为已回复。

外部Chrome/手机操作无法由本地CLI普遍观察；员工还可在别的账号、线下或微信接触。可靠归因需要首次来源证据、客户自愿留资、手机号/微信规范化去重、带唯一交接号的资源部受理回执和双方认可的成交通知/结算规则。账号登录不应把该账号全部原有客户强行算给软件；技术无法独自解决全部隐瞒。

抖音企业私信有官方open_api和webhook路径，可作为后期可靠同步候选；官方明确需要用户授权，权限面向审核通过的企业号，存在频控。参见 [抖音企业私信接入方案](https://open.douyin.com/platform/resource/docs/ability/enterprise-account-open-ability/message-solution/)。本轮未申请权限；普通号不自动享有该能力。小红书本轮未获得同等普通账号私信事件官方证明，保留待核实。

回复口吻可以做官方／顾问／亲切自然的模板预设和审核，不伪装成真实顾客、不编造体验。每条留资要保存用户授权转交的用途与证据；客户愿意提供联系方式是独立转化事件，不能由超高意向评分替代。

## 优先实施的最小模块与审核门禁

1. **能力注册表与诚实状态**：平台×搜索/评论/回复/私信/回流/多账号，分别展示code_ready、contract_verified、real_verified、license_reviewed、account_connected、last_evidence_at。导入现有manifest，不把verified一个布尔误读成全平台通过。
2. **统一线索＋活动账本**：评论是来源证据，客户是去重身份，活动是采集/分类/联系/回复/留资/交接/成交。保留旧527评论和历史记录，只做可逆迁移；同一对象不同视图解决“意向评论/客户清单”重复。
3. **关键词策略管理**：前台只显示目标、地区、进度和产出；后台管理大型词库/企业资料/分类提示词和版本。先离线容量测试，真实平台保持现有复核/互斥。
4. **可追溯交接**：意向→人工确认→客户自愿留资→唯一交接号→资源部受理→成交对账；缺回执不能自动视为成交。账号、员工和门店权限由服务器执行；UI开关不能充当收费权限。
5. **动作回流代表样例**：受控网页新回复关联一次；成功、失败、超时不明三类都测，未知不重发。私信与手机回流单独标能力，不混同评论发送。
6. **逐平台横向扩展**：抖音→知乎→B站评论候选→快手指定作品→视频号本机只读；只是一项推荐顺序，主任务按用户演示/真实需求调整。每平台先许可/环境检查、离线契约、授权真人链路再开放。

每项审核必须有需求编号、代表样例、预期与实际、证据路径、账号/平台/版本、失败停止条件、数据保留检查和回滚方式。分开记录：源码/测试通过、真实平台通过、UI人工认可、商用部署/第二实体机通过。演示可展示未来能力，但显式“待验收”；真实数量和失败状态不能用美化UI掩盖。暂不打包保持。

## 本轮未验证

- 未在真实账号上采集/发送/登录或验证任何新平台；未恢复当前异常小红书任务。
- 未重算CLI整树SHA、未生成新CLI备份；仅查明现有版本记录与备份方案。
- 未验证关键词超过500的现行代码可用；未测任何真人吞吐/安全上限。
- 未验证小红书私信、外部浏览器事件监听、任意手机动作回流。
- 未做商业许可证完整法律审核、官方平台权限申请、真实跨机/跨门店共享、计费部署和实体异机验证。
- 没有“全部GitHub工具已接入”或“所有员工所有线上客户都可归因”的结果。
