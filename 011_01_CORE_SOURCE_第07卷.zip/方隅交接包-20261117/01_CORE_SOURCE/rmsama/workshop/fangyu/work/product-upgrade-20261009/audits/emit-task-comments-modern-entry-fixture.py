"""Actual local read projections in a fresh, synthetic-only fixture."""
import hashlib
import json
import sys
import tempfile
from pathlib import Path

PROJECT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(PROJECT / 'work/app/tests'))
from test_private_strategy_single_batch_entry import SingleBatchEntryFixture


def main():
    base = Path(tempfile.mkdtemp(prefix='task-comments-entry-', dir=PROJECT / 'work/product-upgrade-20261009/tmp'))
    fixture = SingleBatchEntryFixture(base)
    try:
        with fixture.forbid_real():
            task = fixture.read()['task']
            run = fixture.command('task_run', {'task_id': fixture.task_id, 'max_batches': 1})
            common = {'task_id': fixture.task_id, 'sort': 'intent', 'offset': 0}
            listing = fixture.command('leads_list', {**common, 'worklist': 'all', 'group_by': 'note', 'limit': 25})
            summary = {
                name: fixture.command('leads_list', {**common, 'worklist': kind, 'group_by': 'intent', 'limit': 1, **extra})
                for name, kind, extra in [('pending', 'pending', {}), ('all', 'all', {}), ('sent', 'all', {'reply_state': 'sent'})]
            }
        assert listing['total'] == 1 and len(listing['items']) == 1
        assert summary['all']['total'] == summary['pending']['total'] == 1
        assert summary['sent']['total'] == 0
        paths = ['work/app/src/web/workspace/enterprise-ui.mjs', 'work/app/src/assistant/business.py',
                 'work/app/src/assistant/strategy_tasks.py', 'work/app/src/core/engine.py']
        output = {'synthetic_only': True, 'evidence': 'actual_Core_Business_leads_list_with_isolated_adapter',
                  'task_id': fixture.task_id, 'task': task, 'run_result': run,
                  'list': listing, 'summary': summary,
                  'real_platform_requests': 0, 'real_cloud_or_model_requests': 0,
                  'source_metadata': {name: hashlib.sha256((PROJECT / name).read_bytes()).hexdigest() for name in paths}}
        destination = PROJECT / 'work/product-upgrade-20261009/audits/task-comments-modern-entry-actual-fixture.json'
        destination.write_text(json.dumps(output, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
        print(destination.name + ' ' + hashlib.sha256(destination.read_bytes()).hexdigest().upper())
    finally:
        fixture.close()


if __name__ == '__main__':
    main()
