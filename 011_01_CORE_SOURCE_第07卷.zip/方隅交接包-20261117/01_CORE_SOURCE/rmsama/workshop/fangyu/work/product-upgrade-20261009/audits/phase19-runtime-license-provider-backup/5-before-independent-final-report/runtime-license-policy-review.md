# Phase19：正式服务运行许可 provider

正式 `work/app/src/app.py::AppServer` 现已接只读 `platform_read_license_policy`。缺审核来源仍为 `None`，不会把公司配置、请求正文、QA 许可、manifest 的 license 字符串或套餐权益变成组件使用审核通过。本轮没有给真实组件或账号批准，也没有执行 CLI、接外网、修改数据库、Cookie、CLI 树或延长 QA 期限。

## 最小实现与成熟接点

新增 `core/runtime_license_policy.py::RuntimeLicensePolicy`；仅 AppServer 的 Python 构造期参数 `runtime_license_review=None` / `runtime_license_usage_scope=None` 可提供固定可信输入。未新增 HTTP 操作、命令行开关、持久审核账本或收费页面。review 先 deepcopy，getter 每次复核当前状态并返回新字典；无 setter。正常启动没有注入该 review，默认仍未知。

首版只支持实际 `guarded_cli_v1`：Server 与 Adapter 两个 page runtime 都必须为空；当前实际 Adapters manifest 的 executable、prefix、mapper=xhs_v1、available 和 isolation_guard 都需对应所选 guarded CLI。将 CLI 的审核拿去批准 natural-page 路线会被拒绝。

AppServer 用既有部署语义每次派生实际用途。源码运行默认内部自用，不能凭 release_approved 单字段认作客户分发；完整 frozen private_evaluation 公司与当前未过期 Capability（包含合法绑定 QA 激活）仍为内部自用；完整 portable employee 或 production 工作台是客户分发；未识别的 frozen 形态未知。显式构造 scope 与此实际形态不符则拒绝。这里复用了 private_evaluation 的纯配置/时间核对与 employee_distribution 的已有固定配置核对，不读 DPAPI、不续期、不把 QA 本身当组件审核。

明确 approved 的输入需绑定公司、用途、route、wrapper/executable/runtime-tree/guard 四摘要，以及许可正文、组件告知、实际依赖材料、审核证据四份材料的摘要。路径只能来自构造期副本、落在固定材料 root 内的相对路径，拒绝越界、绝对路径、链接和 junction。审核时间/主体/修订也需符合约定。pending、缺失或结构不明返回 `None`；明确 denied 或当前对象不匹配返回 false；只有完整匹配才返回 true。

返回仍严格为 `None` 或 `{xiaohongshu: bool, revision: <64位SHA>}`，不暴露原始材料、目录、审核主体或自由错误。revision 规范摘要绑定审核与实际路线/内容，所以新旧都 true 的审核换版也会使成熟 `PlatformReadService` 的 license digest 不同。

## 真实反例与修复

旧正式 AppServer 没有该属性，最小代表实跑抛 AttributeError：`runtime-license-policy-formal-server-first-red.txt`。新正式 constructor 的受控执行与默认 getter 已通过；HTTP、Integrations、bridge 初始化副作用在 fixture 隔离，不能当真实服务启动/账号接通。

初候选复用成熟 `guarded_cli_runtime_valid` 一次内容校验，再用前后目录 stat 检测变化。D 独审在合成 Windows 文件中保持相同长度、恢复 mtime 后改正文，stat 相同却得到旧批准，随后实际成熟 guard 为 false。此 P1 的独 RED 与 own RED 都保留：`runtime-license-policy-independent-same-stat-red.txt`、`runtime-license-policy-restored-mtime-red.txt`。

修复已删除弱 stat 判断。approved 路径先将 guard 声明绑定到审核，再运行原成熟 validator，随后再次用成熟 `cli_runtime_tree_sha256` 对最终真实内容核对冻结 tree，并末核当前 route/公司/用途/guard/wrapper/材料。D 原同-stat断言不放松已转绿；own 原 late 组也加入等长恢复 mtime 代表。不把本轮文件读取等同操作系统不可变快照或长期安全沙箱。

成本明确：匹配 approved 的正常 getter 要两次完整树内容校验，而不是原候选的一次；默认、pending、无效审核为零次，初验失败不新增第二次。D 已盘点本项目当前固定树155文件/32,749,885字节；重复消费者仍会重复 getter。没有跨调用 size/mtime 缓存，不把测试耗时当真实性能；后续若复用同窗口可信摘要，须成熟 guard 提供明确的快照契约再优化，不先删掉最终内容核对。

## 必要验收与边界

- own `work/app/tests/test_runtime_license_policy.py` **5/5**，最终0.777秒，仅 fixture 时间：实际 AppServer 构造流程隔离、body/赋值拒绝、review deepcopy、实际 Adapters/mature guard 与文件、用途/当前 private Capability/portable、实际 route、exe/tree/wrapper/材料替换、晚变化与规范 revision。fixture 的文件写入仅构建合成材料；resolver 对文件只读、前后文件 SHA 清单相同。
- 原 `test_platform_reads.py` 必要5个许可/动态 guard 用例 **5/5**，1.697秒；原生产消费者与断言没改。沿用计数，不作为5个新功能用例，也没有重复旧495矩阵。
- D 独3 **3/3**，0.566秒：原同-stat P1、两个真实 page route/自更新合法 guard 拒旧审核、actual Core→PlatformReadService→PlatformReceiptArchive 的 true→true review 变化与末 getter 变化。旧回执保留但不可归档，cache scope_hold、0新增 adapter comments，SQLite dump 不变。独3与 own5分列，不把子case、重复执行或六份 JSON结果重复计为新测试。
- `runtime-license-policy-actual-fixture.json` 6种结果来自实际 AppServer property/Adapters/mature guard 与新临时文件。里面的 approved 是明确标记的合成输入，不是本项目真实批准；不包含真实平台、云、账户或财务验收。

新增正式许可接线只解决原软件中的组件审核读取入口。套餐权益、公司平台 hold、当前登录、HTTP461、重复UID、租约、真实速率与吞吐仍由原门禁决定，本轮没有开放或改变这些执行权限。

## 冻结范围

仅两份生产源：`work/app/src/app.py`（BF7979D1ADE0D5E6733ACE49347A81342D1971B8F4B3D3C6E060F2031FCB5741）、`work/app/src/core/runtime_license_policy.py`（013C4BB952E8650F9C30DE9A9F73FD03D4C20712C8D1D8C60569432F69F6DA4A）。原执行六源未编辑；当前 source 不替代 Phase18 既有服务/GUI 历史 SHA。

源代码逐步备份位于 `audits/phase19-runtime-license-provider-backup/1` 至 `4-before-final-content-check`，原正式 app.py 为44A0CCC51C812FC59592BB29F09E049D04AD5D8C955B0E3123D277ED9006942D。构造器薄 fixture 首次遗漏 Integrations.stub 的失败另存 `runtime-license-policy-constructor-fixture-first.txt`，是隔离 adapter 问题，不算第二产品缺陷。

本报告只为本切片技术验收；没有打包、真实审核发布或整体产品完成结论。完整路径与 SHA 在 `runtime-license-policy-final-hashes.json`。
