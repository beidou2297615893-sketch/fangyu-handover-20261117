# Phase27 最终归档独立核对

结论：在本次只读核对时点，归档引用、保存字节、运行计数及未验边界自洽，未发现阻塞归档的问题。仅新增本报告与配套 final-hashes；没有修改产品、既有报告、文档或冻结清单，没有重跑测试、GUI、原生诊断、网络或读取原账号 DATA。

入口为 [current-phase](C:/积木软件工坊/项目/方隅公寓客户版/work/product-upgrade-20261009/audits/phase27-company-submission-current-phase.json)，SHA256 `FF70396FCD2D4B9A1680155913AD0B0137A15B9B9E1E302C592702D412539FB3`。这是一项证据核对，新增产品测试数、GUI 动作数和原生执行数均为 0。

| 核对组 | 本次结果 | 证明范围 |
| --- | --- | --- |
| current-phase 的 evidence | 44/44 当前文件 SHA 匹配 | 绑定当前归档证据字节，不把历史报告升级为新执行 |
| loaded 快照 | 37/37 SHA、唯一原路径、唯一快照路径、原路径后缀匹配 | 16 UI + 13 Python + 8 云加载来源；与 loaded-verification 逐项同 SHA |
| Native 快照 | 13/13 同上 | 保存的诊断源码组；不是全部 35 项运行材料或原账号恢复证明 |
| B evidence/source 快照 | 95/95 同上 | 与 B UI final manifest 的 95 项逐项同路径、同 SHA，无额外或缺失项 |
| 阶段文档、用户报告、当前截图 | 5 + 1 + 5 全部 SHA 匹配 | 五文档最新阶段段落一致；五张 JPG 均为 305×970 |

三份快照清单分别为 [loaded](C:/积木软件工坊/项目/方隅公寓客户版/work/product-upgrade-20261009/audits/phase27-final-loaded-source-snapshot.json)（`7E610BB9…`）、[Native](C:/积木软件工坊/项目/方隅公寓客户版/work/product-upgrade-20261009/audits/phase26-final-native-diagnostic-snapshot.json)（`B4D1E2BC…`）和 [B evidence/source](C:/积木软件工坊/项目/方隅公寓客户版/work/product-upgrade-20261009/audits/phase27-final-evidence-source-snapshot.json)（`BBF09CA8…`）。逐项读取保存文件并计算 SHA；全部路径限定本客户项目，未访问真实 DATA。当前对应 live 文件在本次时点也与快照相同。以后阶段合法修改 live 文件，应使用这里保存的字节核验 Phase27；不能用未来 live SHA 代替历史 SHA，或据其变化指控旧证据失效。37 与 95 两组存在重复引用，不相加为独立生产来源数。

37 项中，`handoff-operation-status-fixture.cjs` 与 `business-reconciliation-fixture.cjs` 是 SDK 接口测试夹具。可称 35 项产品源码加 2 项夹具加载来源，不能称 37 项均为 production。页面链路使用实际 Core、service/store 和 SDK 接口兼容内存双回调适配器；真实 SDK 事务引擎、真实公司网络、跨机器交付和真实资源接收未因此得到验证。

运行计数依据原日志与冻结清单：公司 cloud 新 3 + 本机 helper 新 3 + C 独审新 2 = 新后端 8；UI 新 3 已包含在最终 30 文件 286/286、2543.1339ms 内。既有 ledger 15 和定向前端 37（含 34 旧项）只作为相关回归，不另计新增。当前 frontend-hashes 的 33 个源码/测试 SHA 均匹配（3 源码 + 30 测试文件）。旧 511 没有重跑；本次读取成功日志不算再次执行或增加通过数。

原始 GUI actions 12 行可直接复核为 8 GET、1 register、1 submit、2 合成控制；最终 cloud_counts 为 1/1/1（登记/提交/渠道）。全部 8 GET 的完整 SQLite dump 前后 SHA 相同。四次 recorded GET 的原 attempt 完整元数据仍相同且为 unknown，历史 original_operation 始终 rev2/submitted；公司当前修订为 2、2、3、4，最终 withdrawn、当前同意无效，历史资源接收记录保留。历史登记回显仍 false，已有尝试不再允许提交；现金及已付提成均 null，独立接收、财务、平台、跨机核验均 false。完整 dump 相同不自行推出 SQL trace 为零写。

接收是不同已映射资源主体的合成事件，不能改称真实独立接收。五张当前截图与 [GUI proof](C:/积木软件工坊/项目/方隅公寓客户版/work/product-upgrade-20261009/audits/phase27-company-submission-gui-proof.json) 的引用相同，并与先前已冻结的 C 图片审查同 SHA。本轮读取图片元数据及哈希，没有再操作浏览器。305 宽滚动视图片证明相应交互和文案；不证明 1586 完整桌面像素验收或用户视觉认可。额外“首次确认”裁切图只保留为历史，不替代这五张。

原生证据保持分层：7d7c 只读预检 ready，不授权后续观察；8070 单次观察实际 blocked/profile_occupancy_unknown，original_identity_matches=false、身份引用 null、platform_requests_started=null，profile 可能改变。旧风险 review_required、legacy 任务未知、未提交原 CLI 会话均保留；三项原文件未变只限 DB/设备绑定/活动。原回执载明 5 只读连接、0 SQL 写及自有退出/锁释放；独立审查没有重读原文件。8070 wrapper_source_sha256 与 Native 保存源码 `55C5E09F…` 匹配。935775 良性 Pythonw/合成 profile 和 atomic Job 代表证据不使用原账号、DB、浏览器或网络，不能升级为原 WebView 或原号恢复。三个唯一任务回执和 cleanup 的 run_id/结果 SHA 对应，均只移除各自 owned task，不改其他任务。

文档 backup23 的五份原字节文件存在，另在本次清单记录其当前 SHA/长度；这不是独立捕获归档前哈希。最新五文档和用户报告均保持“总目标未完成”、未打包/未部署/未真实发送及视频支线未完成的分类，没有把本阶段技术证据替代总体完成。

首归档脚本的 FileNotFoundError 属包装路径错误：保存的首脚本第 51 行读取不存在的 candidate 文件，早于第 86 行快照写和后面的文档/报告/阶段清单写。原错误与修正说明已保留；它不是产品测试 RED，也没有新增成功测试。前端包装器 GBK stdout 错误发生在原 286 项已通过、成功日志已保存及源码稳定断言之后；后续只补存原回执，不重跑。两个包装问题不可混算产品回归结果。

本次对候选 143 文件/backup28、19binary/16source/5reject 的数量核对引用已封存 copy/static 清单；没有再次执行 serveSite，也没有扩大候选目录全量审计。未完成项仍包括真实连续采集/回应回流、资源部安全联系方式跨机交付与独立接收、实际成交/分成/回款、多平台和用户完整软件认可。可封存本阶段证据，不可宣称总任务完成。
