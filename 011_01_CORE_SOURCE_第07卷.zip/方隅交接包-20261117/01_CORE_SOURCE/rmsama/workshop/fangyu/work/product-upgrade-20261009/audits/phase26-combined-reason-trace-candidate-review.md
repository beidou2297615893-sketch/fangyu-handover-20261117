# Phase26 组合诊断原因观察器候选冻结

本切片只增加被动 RAM 观察器，复用已冻结 `safe_trace_v2.py` 对实际 `FROZEN.classify` 的精确 AST/filename 追踪。两个合成机制方法首次运行 2/2 通过（0.029s）；源码与测试 AST 解析通过。没有 Native、CIM、Scheduler、浏览器、Host 或原账号操作。此前 GUID `b7965084cace417e8af01e7f74b68986` 的实际结果继续为 `blocked/classifier_not_vacant`，本候选不改变该结果或授予 profile 空闲、账号恢复。

## 最小接法与信任边界

新增 `diagnostics/native-owner-resolver/combined_reason_trace.py`，类 `CombinedReasonTrace(frozen_module, material)` 接受调用方已经持有的实际冻结 classifier 模块；绑定模块文件、`classify` globals/code filename、冻结内容 SHA。调用方可在上下文内照常执行实际 classifier，然后读取 `public()`。观察器不调用另一个分类算法、不修改模块函数、不替换决策。

精确复用冻结 `SafeClassifierTrace` 的语义 AST 行号与 filename 限定。已有 debugger/tracer 时保持原 tracer，并返回观察不可用。准备、追踪或投影失败只令观察结果不可用；上下文不吞掉、替换实际策略异常。退出时清理 RAM 上下文，仅恢复本观察器拥有的 trace；其他 trace 若已接管，保留并标明上下文变化。

`public()` 固定八字段：`contract`、`trace_only`、`trace_available`、`reason`、`raw_metadata_saved`、`counts`、`uncertainties`、`entries_truncated`。固定 contract 为 `combined_classifier_reason_trace_v1`，`trace_only=true`、`raw_metadata_saved=false`。reason 只允许固定观察器代码；计数为固定类别的非负整数，最多 20 条不确定项只包含固定 family/stage/code 与允许的 bool/null 衍生字段。非法键、类型或未知投影整体转为安全不可用结果。没有 PID、SID、路径、exe、argv、异常文本、原 locals、句柄或 TokenUser API 调用统计。

## 两个实际代码合成代表

1. 真实冻结 classifier 的外层路径异常：trace 开关前后的完整 verdict 相等；正确投影为 outer/metadata 的固定异常代码。另用带私人文本的合成异常、观察材料不可用和已有 tracer 核验：文本不外泄，原判定保持，已有 tracer 保持。
2. 真实冻结 classifier 的单行缺 owner：trace 开关前后的完整 verdict 相等，正确标注 `chrome/owner_metadata/process_metadata_unavailable`，区别于 outer 异常。向 public 投影注入 raw PID/异常字段时安全拒绝，不输出原值。

测试使用实际冻结 `occupancy_adapter.FROZEN`，非假 classifier；只在项目临时目录使用合成 RAM 输入。Popen/subprocess、socket、SQLite、native owner API、WinDLL 被拦截。方法数为 2，未重跑既有 adapter、resolver、生命周期、UI 或联系方式后端矩阵；本轮不并入公司联系方式 10 方法计数。

## 证据与保留

- 新源码 SHA256：`09E26D2B0C66EE70BEC9783CCEF351C56CA48A744DB0725EAF3D361D627F800A`。
- 新测试 SHA256：`4E414B6FA5FFD02EFD559A40A29240DCBE19D13033476FB1DB362790D68A908E`。
- 首次绿色日志：`phase26-combined-reason-trace-first.txt`；不存在本切片产品 RED，未虚构红转绿。
- `phase26-combined-reason-trace-static-check.json` 记录两份 AST 和两个方法名。
- `phase26-combined-reason-trace-preserved-hashes.json` 核 44 个去重既有源/证据/引用全部与原冻结 SHA 相符；旧 7 诊断源、旧 4 WebView 候选、867B 良性 Python、resolver、adapter、旧 trace、组合 3 源及实际阻断证据未修改。
- 最终本候选源、测试、报告、日志、静态及保留证明的实际 SHA 见 `phase26-combined-reason-trace-candidate-final-hashes.json`。

此前实际报告的推断纠正继续有效：adapter 公开首失败 fingerprint=null 是投影初始化，不能定位 outer/row gate；公开 token 计数 0 不是 native API 调用计数。本次两个合成机制代表只证明观察标签与实际冻结分类一致，不能倒推 b796 的具体失败分支或真实 WMI outage。

## 未验证与冻结结论

根窗口已实际读新源、两方法与首次日志，接受当前窄边界。当前源/测试停止修改，不新增 Native parent/wrapper/Scheduler，不进行新诊断重试。真实 Windows 启动期 metadata 标签、CIM/TokenUser 组合路线与原 profile/账号仍未由本候选验证。是否另准备受审良性 wrapper 留后续独立授权；本轮没有该执行授权或执行事实。
