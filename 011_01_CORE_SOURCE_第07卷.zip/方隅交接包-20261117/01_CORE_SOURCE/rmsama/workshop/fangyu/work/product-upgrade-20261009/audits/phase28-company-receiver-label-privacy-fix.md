# Phase28 收件标签隐私窄修

C 独立实际 receiver 反例：`recipient_name='微\u200b信号：abc123'` 经成熟 `_public_label` 删除 Cf 后成为 `[REDACTED:wechat_id]`，旧单个可选分隔符检测没有覆盖「号+冒号」组合，导致本机公司收件 DTO 暴露微信号。原失败保留 `phase28-company-receiver-independent-first.txt`；断言和 C 独测试不修改，也没有把它当夹具错误。

仅修改新 `assistant/company_handoff_receiver.py::_label`：沿用原成熟 NFKC/Cf/号码与 secret 检查，再对规范化后的微信/WeChat/weixin/wxid/wx/手机号/电话标签及可选号/号码/id+分隔符组合追加窄拒绝。合法部门与用途标签继续返回；错误返回固定安全文案，不回显私值。未修改 acquisition_exports、原 DB、角色或既有 Phase27 源。

原 receiver D23B9E7B89DD5122CBBB67D1F615C18FC098B3E23B3F55160D75656363B68184 副本：`backups/phase28-receiver-backend/5/company_handoff_receiver.py`。

修后 receiver FD11349D3B9EBAB724B7807DD68790FEB5FEE87A6CDF2B9F466313C4AD1DC568。transport D5466C65…、gateway C68E0EEA…不变。原 own 三方法与旧 gateway 三方法不重复运行；本次关闭与当前源验证由 C 原两方法复跑证明，不虚增加测试方法数。原 CA12 DTO/报告/manifest 保备份/6，后续 actual DTO 以一次当前源码生成绑定，不只手改 source_sha。

C 同原两方法最终 **2/2 GREEN，2.087s**，独测试字节/断言未改，源 FD113/transportD546/gatewayC68E/acquisition_exportsB41B 前后一致。`phase28-company-receiver-independent-green.txt` SHA6AAD948B572FBF14209CAF3085461020408185CD4D5914333F6A60A0553C5425；独报告2BE64475…/独manifestB78DD7E7…分别保留首1green1RED与闭合证据。这里不叠计原B3、旧相邻3、C云3或GUI。

当前8DTO已一次重产，SHA34B182D677DBA73668DC0DB014D227E369935C8D60D7CB63B37A5ACE8E17F2A9，13源SHA包含FD113。旧CA12与旧报告/manifest在备份/6，原D23B源在备份/5；每个后续截图/GUI应固定当前 FD113，不借旧CA12 metadata 当修复执行证据。
