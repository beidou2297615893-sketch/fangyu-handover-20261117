# Phase24 原账号自然身份恢复：最小路线候选

2026-10-10。本轮仅阅读本客户版源码、Phase22 路线报告和已存在测试，没有运行新测试、访问原 DATA、启动浏览器或网络、登录、修改生产。Phase23 两个生产模块保持冻结。

**推荐只增加一个隔离维护父宿主，复用已有 owned 登录窗口及 natural 身份 proof，取得“原账号窗口中观察到原身份”的候选事实后停止。** 不复用正常工作台启动，也不复用完整 BrowserLoginService。候选身份与旧风险、原会话写回、企业在线确认、采集许可分别显示；这一小步不能声称原采集已恢复。

## 已有组件及精确断点

| 复用点 | 成熟边界 |
| --- | --- |
| `assistant/owned_helper_dispatch.py:14`；`app.py:1075` | 固定 owned helper 参数在正常 Server/Service 初始化之前分发。这里只负责启动固定子组件，不自行授权账号。 |
| `assistant/owned_helper_process.py:69` 的 `login_helper_argv` | 原账号 profile、单次 job/cancel 路径、natural flag；源码 Python 与冻结 exe 的 argv 已有成熟实现，不能允许客户端任意路径或命令。 |
| `assistant/browser_login_window.py:135,397` | 仅该账号 `xhs-browser-profile`、job staging；WebView2 会复用已有会话，页面需要登录时由本人扫码或完成平台提示。窗口自身会产生网页网络请求和 profile 写入，不能称零网络/零文件写。 |
| `assistant/native_login_observer.py:24`；`assistant/login_natural_identity.py:145` | 被动观察页面自身 getMe；核当前 document/frame、请求 cookie 与候选一致、非 guest、原 UID。`MAX_IDENTITY_REQUESTS=32` 是身份观察限额，不是窗口全部 HTTP 请求上限。 |
| `assistant/login_natural_proof.py:77,150` | 复用 job-bound spec/MAC、候选摘要与原 UID 核对。只读取本次候选 proof，不再执行 CLI status。proof 是本机观察证据，不是公司云授权。 |
| `core/adapters.py:211,271`；`core/account_safety.py:245` | 成熟账号跨进程锁与风险摘要可复用。锁会创建/使用该账号固定 lock 文件；风险摘要只读。不要调用 account_spec、模式 acquire、身份修复或 review_completed。 |

完整 `browser_login_service.py:314` 在当前风险下会拒绝开始；其 `_snapshot:263` 依赖真实 Service 在线状态，成功段 `487` 会 cloud claim，`495` 会 commit 原会话。正常 App `main` 随后会 start Service/AI/云轮询。以上都超出隔离候选诊断范围。

**缺少的是可信、持续复核的父宿主，不是另一个浏览器。** 窗口 `_guard_current:179` 在 `guard=None` 时返回 true，CLI `main` 也未自行校验原成员；不能直接把 owned 参数当授权。`Core._require_customer_xhs_identity` 会修账号/任务，不能作为纯读身份守卫。维护父宿主必须在启动前、子进程存活期间、返回前读取并核对原范围，失效后使用既有 cancel/stop 路径结束，不能把 `guard=None` 或伪造 `online` 作为门禁。

## 最小实施范围建议

新增一份项目内维护 host 和必要合成测试，不改原 Core、Service、Runner、风险处理或 CLI 树。它只接受固定 `inspect_original_browser_identity` 目的与原账号 opaque ID；DATA、company/environment、tenant、owner、device、profile、helper 路径由可信 native bootstrap 固定，客户端不得传入。拒 MSIX 影子库和其它客户路径，复用 Phase21 原生路径判定与只读 SQLite 原则；不构造 Core、Store 或 Service，不迁移数据库、不修 tenant/user。

从当前 DPAPI 绑定只读取得原 device/owner/company/env，与保存 user、账号 tenant/归属、原 UID 和 disabled 状态核对；仅输出 present/hash 或固定状态，绝不输出 token、cookie、密码、正文、号码或原 UID。检查占用和任务 inflight，原账号执行锁成功后才创建一次 job。原账号 profile 不拷贝到另一账号，缺失则如实标缺失，不从系统 Chrome/Edge 或另一实例取 Cookie。

父宿主只创建原 `work/browser-login/<job24hex>`，复用 `create_spec`、`login_helper_argv(...natural_identity=True)`、固定 outcome、`verified_status`。主流程不接 BrowserLoginCoordinator 的 claim/commit；成功输出 `original_identity_observed` 后清理本次私有候选，取消/超时/错 UID/验证提示同样清理候选，保持原会话和原风险字节。成功候选不触发账户 ready、清 requires_review、创建新任务或请求采集。

**许可与部署边界保持原值。** `RuntimeLicensePolicy.resolve` 可纯读核当前 guarded CLI artifact/review，缺 review 返回 None；它明确不覆盖 natural page，不能把 CLI 的 true 套到自然身份窗口。Server `_platform_execution_guard:321` 在 portable/QA 场景依赖真实在线 device 与当前 capability，不能构造假 Service 满足它。后续 host 应复用现部署用途和已有明确登录功能门禁；不能新建“批准=true”或延期 QA。若该用途的现有门禁必须有在线确认而当前无法纯读证明，应返回具体 `deployment_confirmation_unavailable`，不自动连云、不制造新许可审批流程。诊断窗口也不授予采集或回复许可。

保留 review_required 是本候选的业务要求：它说明后续采集仍暂停，不能通过“先 require_account_safe 判安全”形成永远不能观察身份的循环。应只把本次目的限制为原本人可见的身份候选，保留风险事实和所有执行暂停；这不是把成熟采集门禁取消或把登录成功当人工安全复核。

## 一个最难代表，先通过再扩

在合成 native DATA 中建立原 bound device、本人 user、原账号 UID、login_required、review_required 及原会话/profile；用现自然观察器与 proof 实际函数接受合成同 document getMe，不打开网站。父宿主只读快照和 private job，模拟 helper 返回同原 UID proof。验收必须同时满足：

1. 输出只说原身份候选已观察；原 account/users/tasks、原 CLI Cookie、activity 原字节不变，SQL 0 DML；Core/Service/start/claim/commit/CLI/模型/云调用 spies 为零。
2. 保存的 actor/device/env、账号 revision/UID 或 profile 路径在候选形成后变化，最后返回拒绝并撤销候选；错 UID、guest、wrong frame、过期 proof 不能变成成功，更不能换账号。
3. lock busy/inflight、缺绑定、disabled、原部署许可未知时不启动 helper；旧 review 仍可见且不解除采集暂停。一次操作仅一个 job，不自动刷新、重试或再开窗口。profile 与 lock 的必要局部写入单列，不假称全文件系统纯读。

上述仅为下一实施验收计划，没有执行或新增测试计数。既有 `test_owned_helper_dispatch/process`、`test_browser_login_window`、`test_login_natural_identity/proof` 已覆盖 argv、profile、取消与 proof 的部分组件边界；后续只补父宿主实际授权和副作用隔离缺口，避免复制完整浏览器测试矩阵。

## 当前交付状态

本候选能低成本回答“这个原账号的 owned 网页会话是否观察到原身份”，为本人恢复采集提供下一条可信事实。它不承担原会话写回、公司 claim、人工风险解除或采集。未来真实窗口仍可能需要用户手机扫码/验证；本轮没有发生这些动作。当前正式冻结入口未增加维护 host，不能宣称该候选已在原账号可用。

文件：`C:/积木软件工坊/项目/方隅公寓客户版/work/product-upgrade-20261009/audits/phase24-recovery-route-candidate.md`

文件夹：`C:/积木软件工坊/项目/方隅公寓客户版/work/product-upgrade-20261009/audits`
