# Phase28 公司资源部收件与接单：云端切片核对

已复用现有公司 handoff ledger/service 实现资源部收件选区与权限变化保护，不部署、不迁移或初始化真实公司数据。客户端接线与真实公司接单验收仍待完成。

received-list 未选择部门时，仅从当前已认证账号的可信 receivers 映射返回 authorized_recipients；items为空、total=null、selection_required=true，不猜资源部。明确选择后默认10条、最多15条；渠道总数不等于待接单人数。云 GET 返回 read_only=true / mutation_committed=false / auto_retry=false，缺公司不创建公司，过期会话不清理持久状态。

清单在最后读取后复核当前会话、成员、可信接收映射和每行 item/event/consent。接单仍要求另一位获权主体、当前 submitted 与有效同意；在第一写前及已暂存写后的末异步边界再核上述范围。晚权限或同意变化拒绝并回滚，不能说零尝试 DML。原接收 key 的历史核对保持只读，不将历史 accepted 当当前仍有联系授权。

C 独立新增3组代表全部通过（5255.026ms）：末清单读取禁用/撤映射/过期拒绝；接单晚读及已暂存写后撤权限/同意回滚；接单 commitlost、同主体原 key status 恢复、后续客户撤回保历史。真实首 RED 是旧清单末读取禁 resource 后仍返回200，日志保留；未把静态风险或测试脚本错误冒称产品 RED。

最坏预算实际走64条成熟 contact-sync→register 草稿索引，received offset49/limit15跨50条索引页：两次SDK接口内回调各94读，外回调各1读，全部0 set。64为合成公司草稿渠道，不是64个真实精准客户、已提交/接单量。回调重放与延迟注入是内存SDK接口代表，不证明真实CloudBase引擎、线上竞态或吞吐。

root 在同一最终源码上执行旧 ledger15与 Phase27 submit3，共18项定向回归，18/18（1566.3388ms），首尾7文件 SHA 相同。它们都是原有测试，不和新增3组重复累计。首 root wrapper 因不存在 store.cjs 在 hash preflight 停止，实际 createStore 位于 index.js；修脚本和路径标准化后才首度执行测试，错误与初稿另存，不计为产品失败或重复测试。

最终两云源已按原相对路径复制到 backups/phase28-final-receiver-cloud-snapshot/1，旧 Phase27 两源和95项证据历史快照保留。没有平台发送、手机号/微信跨机传输、真实第二台电脑、公司部署、成交/分成/收款或原账号恢复证明。当前回款和已付分成仍null。
