# 本机原准备对应公司登记：只读下一切片方案

本报告仅只读设计。没有实施新 helper、transport、gateway、UI 或测试，没有外部请求或修改原库。阶段变化重新评估最小 Skill 组合，实际读取 RevOps，用其阶段定义和交接证据边界梳理“本机准备 → 公司原登记 → 当前状态”；已有私有来源桥与公司账本比新建 CRM 更适配，故直接增量复用，不另引框架或联网选型。

## 交付目标与入口

入口建议“核对准备对应的公司登记”，仅人工点击查询。客户端只传 `company_handoff_original_status {handoff_id}`。已有来源候选/同 source/company channel 不构成此原操作绑定；前端不能填 key、环境、actor、device、payload、channel 或 source，也不能让 GET missing 创建新准备。

仅从 phase12 可信原准备取 actor、tenant、company、environment、device、原 register key、完整 canonical payload hash 和预期 channel。缺 origin：本机纯读结果 `no_origin`，公司请求0、写0、key/墓碑0。准备状态损坏、未知或与当前主体/设备/环境不符时拒绝，不把它当不存在后重建。

原准备仍然只是 prepared。公司 status recorded 说明原公司 register 记录与该本机保存的准备摘要对应，不能证明本机曾 dispatch、平台曾收到消息或资源部实际送达。register 原记录 revision=1/status=draft，不可显示成 submit/accepted。当前来源变更、授权撤回或本机 revision 变化可在本人仍有权、原 immutable 事件仍完整的条件下读取历史；它们持续阻止当前交付，历史读取不回填或解除本机准备暂停状态。

## 拟业务 helper 与 trusted transport

- D 拟新增 `assistant/company_handoff_original_status.py`：`CompanyHandoffOriginalStatus(core, tenant, owner, company, *, device_id, scope_guard, lead_access, cloud_read)`，execute 仅上述 action/精确一个参数。错误前缀可固定 `COMPANY_HANDOFF_ORIGINAL_STATUS_`、safe status 400/403/409/503，所有错误的 mutation_committed=false 只说明本次查询没有写。
- 复用已冻结 `CompanyHandoffPreparation` 的 ctor、GET、`_row` 与当前本人授权读取。读取时取得原持久行和 public current；原行自摘要、deterministic origin/cloud key/channel、当前 saved actor/vault/env/company/device 一致。原 cloud action 仅 register，不因为云支持7写动作而扩本机主体权限。
- 查询历史不能拿当前原评论正文重算原云 payload hash，也不能对已撤回的交接套新准备 ready 门禁。phase12 原行已保存当时完整请求摘要；核原 immutable 事件时按原 event_id/payload_hash/sequence/chain_hash 和 owned reply-chain 验证，允许当前正文/UID变更所产生的暂停。现有 `_owned_event` 对当前 source 精确绑定不能直接作为历史读取的否决门禁，需新 helper 的窄只读历史核查，原冻结模块不修改。
- B/SKILL 既有成熟账本证据只证明本机 hash 诊断，不是签名或独立来源权威。原 source window 的完整 ACK 历史不能由当前 ACK 时间反推；phase12 ACK 没有环境/设备原绑定。因此不增加“历史全部窗口已独立核验”或 `source_cloud_binding_verified=true`。
- Root 拟新增 `assistant/company_handoff_status_transport.py` 与窄 gateway 分支。公司接口仍是已冻结 `acquisition_handoff_operation_status`，请求 body 只 `{operation_action: acquisition_channel_register, idempotency_key: origin.cloud_idempotency_key}`。环境和 endpoint、bearer 只能由可信集成配置取，不能来自 action payload。返回先严格验证 `fangyu-workspace-v1/environment/company`；剥且只剥三个可信 envelope 身份字段后，业务 helper 校完整 narrow business keys。

**实际成熟入口的副作用边界**：`BusinessExecutor._ai_cloud` → employee `_cloud` → integrations `_cloud` 无条件调用 `_refresh_session`。会话接近60秒或已过期时可能本机 DPAPI 写 pending_refresh，调用 refresh_status/refresh 并接受新 secret。简单一次 preflight 有 TOCTOU，不能保证它没有后续续期写入。因此本切片已选择有效既有 session 的无自动 refresh 路线，直接复用 `integrations.request_json` 和同 envelope 校验；不调用 `_ai_cloud/_refresh_session/verify_identity/_write`。过期或近到期给固定 `SESSION_REQUIRED` 并请用户走现有明确连接/续期流程，本次保留原编号和历史未知。

建议 transport 首次 bearer 有效期 `> now + 60s`（覆盖既有约25秒请求预算和余量），返回时仍未过期且 bearer/config/env/company/device snapshot 未变化。session remembered-device 的 id 与本机助手配对 device 不是同一字段，不凭命名猜相等；本机设备靠可信 vault/assistant scope，云 bearer 主体靠服务实际 authenticated_actor 核验。无 token 时不 me/login/refresh，不保存字段或 secret。HTTP 401/403/超时/格式错误不清旧 slot、不改原 prepared/unknown，不把 query false 当原写未发生。

在云网络期间不持 SQLite/Core 写事务。前后各取新连接原 origin、本人当前 source/权限/scope，核对原行字节或 record_hash、当前 actor/device/company/source 摘要；云回来后及最终 HTTP 投影前再核当前范围。用户在云请求期间撤回/换UID/换设备，晚结果拒绝并可人工重读；随后稳定的 withdrawn/stale 允许按原存档历史读取，不用旧结果打开旧页面或解锁交付。

## 拟公共 schema（待 root 最终锁）

顶层 exact 29 keys：

`contract, read_only, mutation_committed, local_only, storage_scope, cross_machine_verified, cloud_read_requested, observed_at, state, origin, current_local, original_operation, current_company, origin_binding_verified, source_cloud_binding_verified, platform_delivery_verified, financial_receipt_verified, cooperation_policy_verified, verified_cash_cents, verified_paid_commission_cents, settlement_active, auto_retry, no_dispatch, no_dispatch_scope, provider_requests_started, platform_requests_started, contacts_modified, handoffs_modified, ratings_modified`。

- `contract=company_handoff_original_status_v1`。read_only=true、mutation_committed=false、local_only=false、storage_scope=local_bridge_company_server_ledger、cross_machine_verified=false；即使 no_origin 没发公司读，也保持固定潜在桥合同，并以 cloud_read_requested=false明确该次调用没有请求。
- `state=no_origin|unknown|recorded`。no_origin 时 origin=null、observed_at=null、公司 original/current=null。unknown 时已存在 origin，公司 read_requested=true、observed_at为真实 status 时间，但 original/current=null，origin_binding_verified=false。
- `origin=null` 或 `{origin_id,local_handoff_revision}`；不再返公司原 key、payload hash、event id、原正文、裸 UID 或同意引用。编号需要显示时沿已有准备折叠高级信息，不进入临时存储。
- `current_local` 为 phase12 精确8字段：handoff_id/revision/status/qualification/consent_state/source_state/preparation_usable/blocked_reason。原9状态/6资格沿用。当前 source/window/revision 不符继续 false；不能因查到公司记录升格当前可交付。
- `original_operation=null` 或 phase11原7字段去 payload_hash，加固定 operation_action 和 execution_confirmed：`channel_id,revision,historical_status,occurred_at,historical_event_self_hash_verified,full_historical_chain_verified,operation_action,execution_confirmed`。recorded固定 register、1、draft、true、selfhash=true、fullchain=false。
- `current_company=null` 或 phase11 exact6字段：`channel_id,revision,status,current_consent_valid,historical_resource_receipt_recorded,receipt_evidence_independently_verified`。公司当前 channel须同原channel，revision>=1，状态9枚举。历史接收与当前授权分列，withdrawn + 历史接收 true 仍不是独立资源部/财务权威。
- recorded 的 origin_binding_verified=true 只表示同原准备 action/key/body hash/预期channel/原结果revision/status严格匹配。raw receipt 的 original.payload_hash 必须等于原冻结摘要，不能重算 current 或用 UI digest。任何 hash/channel/key/actor/environment/extra字段/状态关系不匹配拒绝整包，不做降级或截字段宽容。
- source_cloud_binding_verified、平台/财务/合作 verified 固定false；实收/实付null，settlement_active=false。no_dispatch=true 仅 `no_dispatch_scope=this_status_query_only`；自动重试、provider/platform开始、联系方式/交接/评级修改全false。

## 代表性最难验收路线（未执行）

1. actual Core/preparer 的真实 origin 完整 payload，接已冻结 actual createService/createStore/repos、SDK接口兼容内存事务 adapter（不是内部SDK引擎）。合成 source归档→原固定 register commit→丢响应→服务/本机重启→新 pure-read transport→原status matched。原 register 1/draft，当前在另一合成有权actor ACK后 withdrawn，原 record和 current撤回同时保留；status读取0 writes、1固定HTTP、无refresh/模型/平台。
2. 缺 origin与GET missing0公司请求/0 SQLite或DPAPI写；云 missing unknown/401/超时/expired bearer仍保持原准备key和其它旧 unknown slot，绝不本机 cancelled tombstone或另发 register。第一次无会话时只明确阻断，不进行其它身份网络请求。
3. 返回同 source但另 channel、wrong原payloadhash、同actor另key、wrongactor/env/company、原registerrevision>1/非draft、nullable execution矛盾、私有extra或错误cash/paid真值全部拒绝。不是过滤未知字段后显示合法部分。
4. 初始最后来源/actor读取、status请求 await、返回后最后本机read和HTTP public边界，分别制造disabled/unbound/role/device/env/company/source/withdrawal变化；不得回填旧source/current，查询失败false不得清旧写槽。当前稳定withdrawn/stale仍允许历史读，但不生成新origins或自动下一操作。
5. transport独立有效token、near-expiry、配置/secret在返回期间改变；阻断 socket以外的业务请求、_refresh_session/_write/verify_identity、平台Popen/provider与通用receipt。先最难代表通过再必要组合，不按重复callback/重跑次数虚增覆盖。

计划新增 D module/独占测试/actualCore+actual service合成 fixture；Root新transport/网关/必要UI；B业务权限独审、child实际UI独审。当前所有这些仅设计。phase12本机源1C1EB336…、gateway853D3773…、phase11云7CA948D7…/6F6BDA52…已只读核SHA，与冻结一致；原15UI和旧fixtures无变动。

公司云仍未正式部署，当前准备没有 submitted/outbox/dispatch；无真实账户/公司回执/多机器资源部接收/平台送达/实收实付验收。新查询即使取得可信合成 recorded，也不能冒充真实获客或商用完成。
