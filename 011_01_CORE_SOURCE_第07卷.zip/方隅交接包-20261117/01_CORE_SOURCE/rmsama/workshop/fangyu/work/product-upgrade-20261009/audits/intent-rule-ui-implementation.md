# 意向规则前台独立模块（功能阶段）

本轮只新增前台模块与专项测试，旧第9版布局、路由、后台、原库与平台账号均未修改。17项专项通过，`node --check` 通过；这是轻量 DOM 模型执行实际磁盘模块的离线证据，不是客户端 GUI 或真实模型/平台验证。根窗口负责注册资产、接入口及隔离 GUI 验收。

## 文件与冻结版本

- `work/app/src/web/workspace/intent-rule-ui.mjs`：SHA256 `36A71D6076872B92BA365255D2CB18159FB830B1E766E439E3D0CA379F9B0154`。
- `work/app/tests/intent-rule-ui.test.mjs`：SHA256 `790F8A1D7CA44BBABB69DABAE345F88D8989794C22DE54F8F15B779E8C45FF94`。
- 原始验证输出：`audits/intent-rule-ui-verification.txt`。
- 文件夹：`C:/积木软件工坊/项目/方隅公寓客户版/work/product-upgrade-20261009/audits`。

新文件无覆盖旧源码，不需要旧文件备份。前一阶段的规则后台与导出/昵称隐私模块继续保持冻结，不把前后台不同矩阵的计数相加。

## 接线契约

```js
const rulesUI = createIntentRuleUI({
  createDialog, read, write, scope, perform, pending, recover,
  onSaved: async () => { /* 刷新真实管理概况 */ }
});
await rulesUI.open({leadId: ''});
rulesUI.reset();
rulesUI.dispose();
```

`createDialog(title)`、未拆包的 `read(action,data)`、`write(action,data,target)`、`perform(view,button,fn)`、`scope()`、`pending(action,target)`、`recover(action,target)` 直接注入现有 operations 闭包。保存 target 固定为 `intent-rules`；原 helper 保留不含表单正文的原操作编号和摘要。每次写入由原 helper 生成幂等键，未知结果使用原编号核对。不能用删除浏览器元数据来解除业务未知状态。

operations 的 reset/dispose 必须同步调用新模块的 reset/dispose；它会清字段、关闭并移除自身弹窗。所有处理器与异步回填另外检查弹窗生命周期、模块 generation 和身份/角色/设备作用域。打开新弹窗、关旧弹窗或角色设备变化不会把旧私有结果写入新窗口。

实际动作只有 `intent_rules_get`、`intent_rules_save`、`intent_rules_history`、`intent_rules_preview`；线索选择复用已有 `leads_list`，未知恢复仍沿已有 `acquisition_operation_status`。没有新增 API、后台命令、模型调用、平台发送或自动交接。资产白名单与两个入口由根窗口接入：管理中心入口、现有详情传真实 `leadId` 的核对入口。

## 产品行为与边界

- 普通员工只显示 summary 和有权已保存评论的离线预览。即使意外收到 private policy 字段也忽略它，不生成公寓资料、分级标准或历史管理控件。
- 管理者可录入规则名称、匹配启停、公寓名称、城市、区域、房型、人民币月租上下限、有效期与资料参考。最多200份完整资料，以真实表单和折叠卡管理；没有 JSON 编辑器。
- 未知月租保留 null，不生成伪0。上下限、整数与最大值校验在请求前执行。日期按本机时间填写并传明确时区；未改动的日期保留原始秒数和时区，不因打开再保存而截断。
- 五级 criteria 只读展示，保存时保留当前可信返回值。模型分级继续由可信云配置决定，不把本机资料保存说成云模型标准已生效。
- 公寓资料是操作人登记，不是独立证据、实时库存、直接承接或精准交接资格；区域与预算用于请求匹配，不配置租客资格排除。
- 离线预览分开显示保留的人工/历史评级、本人的新依据校验和公寓匹配状态。缺资料不降低本人租房意向，历史评级不重算。候选资料不能宣称可交付/已归因。
- 保存必须返回真实 commit 与精确下一版本，再读回版本才显示完成。明确拒绝可修正；未知保留锁和原编号；服务端明确已提交则读回，明确未提交才允许重试。已经提交但读回失败，仅提供重新读取入口，避免再次提交。
- 历史分页与评论分页读取实际 total/offset，历史快照不会覆盖正在编辑的当前资料。仅用 textContent，不解析昵称、参考或公寓名称中的 HTML。

## 代表验证

初始4项表单测试先因缺少 module/exports 失败，实施后转绿；本轮新增完整 module DOM 模型代表例覆盖：员工私有数据隔离、版本保存/criteria不可编辑/未知租金、无效范围无 mutation、unknown→仍 unknown→明确 false、浏览器锁消失不解锁、commit 后读回失败只读恢复、版本拒绝与概况失败、迟到身份/设备结果、旧选择预览丢弃、真实历史分页、已提交原操作恢复、HTML 字符纯文本显示。

验证命令（目录 `C:/积木软件工坊/项目/方隅公寓客户版/work/app`）：

```powershell
node --check src/web/workspace/intent-rule-ui.mjs
node --test tests/intent-rule-ui.test.mjs
```

17/17通过。夹具使用合成公寓、合成客户、注入只读/写入应答，不读取原数据，也不证明模型语义100%精准或真实库存有效。原 helpers/gateway 注册后的真实合同、原生/IAB页面、键盘与管理员/员工角色切换留给根窗口定向验收。
