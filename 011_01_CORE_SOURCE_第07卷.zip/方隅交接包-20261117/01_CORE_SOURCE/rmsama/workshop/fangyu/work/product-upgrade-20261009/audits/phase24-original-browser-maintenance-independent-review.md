# Phase24 隔离维护父 host 独立代表审查

结论：当前候选的三项独立代表通过，可以冻结机制研究证据。公开 `execute` 仍返回 `blocked / deployment_confirmation_unavailable`，没有启动浏览器；默认私有 launcher 也拒绝。这不是原账号恢复功能已经可用、真实账号已经可用，或正式 natural 商业部署已经验收。

## 范围与实际证据

仅审查本项目新 `original_browser_identity_maintenance.py`，独立测试复用 B 的 `MaintenanceFixture / observed_proof / FakeOwnedProcess`。测试实际调用候选的只读 SQLite metadata 解析、成熟 owned argv/proof 校验、账户锁、循环 scope、固定 cancel 和 cleanup。native 根目录、公司文件与 DPAPI 解密边界替换为项目临时目录内合成材料；launcher 仅在私有机制段替换为 FakeProcess。

没有构造 Core/Integrations、启动 Service、调用平台 CLI、浏览器、网络或模型，没有读取真实 native DATA、DPAPI 凭证、原账户或真实 profile。socket/Popen/Core/Service/CLI 等入口在测试中禁止。SQL trace 验证受测只读连接为 `mode=ro&immutable=1`，没有 DML；测试有意制造的 metadata 变更与受测读取分开。

最终运行 `test_phase24_original_browser_maintenance_independent.py -v`：**3 个唯一方法，3/3，通过，0.877s**。没有新增全量矩阵计数，没有 GUI、原生进程或跨进程引擎验收；账户锁的竞争代表为另一线程，使用成熟跨进程锁函数。

## 原始 RED 与关闭证据

初始源码 `0B0CDDD7315F68A8930A1FA559607D9F890317AD84DB3B421071F694548C4DDA` 下，三项方法中两项通过、一项失败，四个子例均复现：records 列 id/tenant 保持原值，但 users/accounts JSON body 的 id 或 tenant 改为另一主体，公开 metadata 解析仍认作存在的原主体并返回部署不可用，而没有报主体材料不一致。公开入口仍然 0spawn；此 RED 不是公开权限绕过或真实原账号异常。

原始 source snapshot 和完整失败日志保存在 `phase24-maintenance-independent-first-source.json`、`phase24-maintenance-independent-first.txt`。B 修改原 tuple，校验 body.id/body.tenant 与 records 列对应且将其纳入 fingerprint；C 未改生产源码。当前 source `ACD7DE84CF2432B9F48A2D5EE934E0D2F76BF956031ED38BD489026E880B640A` 上，四个原子例以 MEMBER/ACCOUNT_UNAVAILABLE 拒绝；同风险新增晚改 account body.tenant 子例也执行固定 cancel、停止 FakeProcess 并清理 owned staging。

## 三项必要代表

1. 公开只接受 purpose 与 opaque account_id；额外 guard/license/path/company/approved 字段拒绝，bootstrap 子类型拒绝。给 host 添加 True guard/CLI policy 属性不会改变公开 blocked、0spawn。原始 id/tenant 不一致拒绝，读取不修改原合成材料。
2. 非空 WAL 拒绝启动。私有机制期间 binding owner、原 UID、body tenant 或活动记录变化，循环 fresh scope 拒绝并取消固定 job；保留外部已发生的新 metadata，不倒写旧材料。
3. 默认私有 launcher 拒绝；仅替换低层 FakeProcess 的机制成功使用真实成熟 proof/argv，原 UID 对应，risk 保持 `review_required`，同 host 重入和竞争线程受账户锁阻止。返回 `mechanism_only:true / public_entry_authorized:false`，不提交会话、不改账户/任务、不清风险、不启动 CLI/cloud/provider/platform。

## 路径与写入边界

生产 `snapshot` 固定 native knownfolder、固定项目公司候选文件和 DeviceVault 读取，不允许调用方传 data/profile/owner。路径逐级拒绝 symlink/reparse，非空 WAL/journal 拒绝，保存的 actor/account/body/tenant/UID/任务材料进入 fresh scope。任务普通/continuous inflight 的 null 或缺字段当前仍拒绝，不改成 false。

私有机制不是整个 DATA 零写：owned staging、固定 cancel、账户锁、work 父目录可能写入；合法机制成功保留安全 sibling outcome 与锁文件，staging 删除。真实 browser profile 也可能被 owned browser 修改，DTO明确标记该可能性。测试逐字节保持原合成数据库、vault、profile 标记、活动记录和 CLI Cookie；这不能推广为真实浏览器的所有 profile 字节不变。

## 冻结引用

- 受测源码：`work/app/src/assistant/original_browser_identity_maintenance.py`，SHA256 `ACD7DE84CF2432B9F48A2D5EE934E0D2F76BF956031ED38BD489026E880B640A`。
- 复用 fixture 源码：`work/app/tests/test_original_browser_identity_maintenance.py`，SHA256 `CEFAB4742EDD0BF4528555DB6EF0F0028CB1640DF8C8F07B8BB7301621596722`。
- 独立测试：SHA256 `319BAF3420743E2717358458EACAD73909210AF12E73FCF73C4125B6C47CDB9C`。
- 最终 source snapshot 和 green 日志：`phase24-maintenance-independent-current-source.json`、`phase24-maintenance-independent-green.txt`。
- 明细以同目录 `phase24-original-browser-maintenance-independent-final-hashes.json` 为准；测试前后两个受测 source hash 相同。

原账号只读开发诊断路线的后续静态评估与本冻结证据分开，不能把当前公开 blocked 候选当作用户原账号恢复完成。
