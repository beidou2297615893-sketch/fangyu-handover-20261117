# Phase30：服务端腾讯 KMS 配置接线候选

本阶段把已验收候选的官方 KMS 适配器接到实际 `work/cloud/workspace/index.js`。新增 `contact_delivery_config.cjs`，正式项目固定安装 `tencentcloud-sdk-nodejs-kms@4.1.302`；没有引入自写加密、测试 runtime 路径、客户端配置入口或真实密钥。`service.cjs`、`contact_delivery.cjs`、`kms_contact_provider.cjs`、本机桥与 UI 均未修改。

## 产品取舍与实际差异

原入口只传企业权益配置，没有传 `contactDeliveryProvider` 或 `contactRetentionSeconds`。新增测试通过实际入口 VM 执行，首次真实失败为 provider `undefined`，保存在 `phase30-kms-config-first-red.txt`。正式接线新增固定配置模块 import、初始化时读取配置，以及向原 `createService` 传递两项构造参数。

最初候选沿用企业权益配置的全入口拒绝模式。产品审查指出：部分/非法 KMS 配置不能同时阻断客户撤回与历史核对。最终 parser 仍严格抛固定配置错误，自检明确 `invalid`；入口仅捕获本模块的三种固定错误，打印不含值的固定诊断，然后禁用联系方式 provider/retention。成熟服务在创建 attempt 前拒新 publish/reveal，已授权 status/withdraw 与其他工作台功能保留。未知非本模块异常仍进入既有 503 总错误分支，不能吞下后继续。未配置全部字段时默认 `null/null`，没有隐式授权或替代凭据。

`phase30-kms-config-source-diff.patch` 是相对修改前精确备份的差异。旧入口/包/锁文件在 `backups/phase30-kms-config/1`；产品取舍前候选在 `/2`。一次 apply_patch 行格式不匹配未写文件，属于工具匹配问题。首候选 2/3 的失败为合成测试部分配置遗漏合法 TCB_ENV/COMPANY_ID，修复的是测试上下文，原日志 `phase30-kms-config-first-candidate.txt` 保留，不算第二产品缺陷。

## 服务端配置合同

只读取构造期服务端固定环境变量：

| 名称 | 要求 |
| --- | --- |
| CONTACT_KMS_REGION | 与当前适配器一致的 `ap-` 地域格式；实际地域可用性未验证 |
| CONTACT_KMS_KEY_ID | 已存在 CMK 的固定 KeyId，8–200 个 ASCII 字母/数字/下划线/连字符 |
| CONTACT_KMS_SECRET_ID | 服务端 SecretId，16–256 个非空白 ASCII 字符 |
| CONTACT_KMS_SECRET_KEY | 服务端 SecretKey，16–4096 个非空白 ASCII 字符 |
| CONTACT_KMS_TOKEN | 可选，使用 STS 时提供非空 token，16–8192 个非空白 ASCII 字符 |
| CONTACT_RETENTION_SECONDS | 显式正整数字符串，1–31536000 秒；没有默认保留期 |

出现任一该前缀配置但缺必要字段、空值、非字符串、非法格式或未知 CONTACT_KMS_/CONTACT_RETENTION_字段时，自检明确拒绝。`CLOUDBASE_APIKEY` 仍仅是既有 CloudBase 接线，不能当作 KMS 凭据。没有 endpoint、路径、purpose、profile、角色或保留期的请求体入口。固定官方 `kms.tencentcloudapi.com`、HTTPS、POST、TC3-HMAC-SHA256 和 10 秒 reqTimeout；没有加入该 SDK 不存在的 retryStrategy/maxRetries 参数。

可信内部 loader 注入仅是服务器/离线测试构造 API，不是浏览器能力。正式入口只使用固定产品包 `require('tencentcloud-sdk-nodejs-kms')`，并核版本 4.1.302。配置字符串先复制，当前 warm 实例不接受后续 env/request 修改；配置或 STS 更新需要运营人员按既有部署流程重新创建服务实例。本阶段没有实现凭据自动续期、角色获取或密钥轮换。更换 CMK/地域会改变现有 provider scope，不能借此解锁旧未知请求或宣称旧 ciphertext 已可解密。

## 无网络自检

技术负责人在已配置的服务端环境运行：`node contact_delivery_config.cjs`（工作目录为正式云工程）。它只解析环境与构造官方 SDK；不建 DB、不 Encrypt/Decrypt、不取角色凭据、不调用云平台。返回固定 `company_contact_kms_configuration_v1` 投影，含 state/reason、provider/retention/凭据配置布尔、包版本与 provider scope 指纹；不返回 KeyId、地域、凭据、保留期值或原异常。

状态为 `not_configured / invalid / dependency_unavailable / client_unavailable / configured`。`configured` 只表示格式、固定依赖和构造成立；`live_kms_verified=false`、`iam_permissions_verified=false`、`network_requested=false` 始终明确。正式 CLI 自检在本阶段未读取真实环境；实际 JSON 样例全部是合成设置，由 emitter 执行当前模块生成。

## 代表验证与运行边界

- 新 3/3：实际 index VM 构造接线与 warm-instance/browser 参数隔离；严格配置/安全错误及实际服务旧 vault 在禁用配置后历史可读、withdraw 成功、新 publish/reveal 拒绝；固定官方 SDK 构造/端点/凭据快照/自检脱敏。`phase30-kms-config-first-green.txt`：1132.1653ms。
- 原 actual-main 2/2 定向回归保留企业权益/服务周期和非法企业配置拒绝：`phase30-kms-existing-bootstrap-green.txt`，347.9365ms。不是重跑所有旧 cloud tests。
- 两生产 JavaScript `node --check` 通过。未重跑旧 Phase29 3+2 或整个矩阵。
- 实际已安装官方 KMS 4.1.302 / common 4.1.220，Apache-2.0；CloudBase 保持 3.18.3，所有原 lock dependency entries 相同，仅新增 13 entries。官方包 package.json、LICENSE、kms_client.js 与 Phase29 已核验文件 SHA 一致。安装仅本云工程 `--save-exact --ignore-scripts --no-audit --no-fund`，有 npm 下载网络，没有部署或 KMS 网络。uuid@9.0.1 弃用警告已保留，没有自动升级。
- 构造测试执行实际官方类；旧业务撤回代表复用实际 createService/createStore/ledger 与 SDK 接口内存 adapter，opaque provider request stub。不是 node-sdk 内部事务引擎、真实 KMS 加密、不同 Windows SID 或实体电脑验证。
- 官方 HTTP 内部仍会读取服务端 `http_proxy` 环境；本模块不提供网页 proxy/endpoint 配置。应用层一次方法调用不能等价为真实网络只传输一次，真实代理、网络失败、IAM/地域/CMK 状态均未验证。

## 技术负责人实施前检查

1. 在可信服务端保留正式 `package.json/package-lock.json` 对应固定依赖；不要引用 phase29 测试 runtime 或动态路径。本阶段只是本地依赖接入，未发布云函数。
2. 由现有公司权限负责人选择实际 KeyId、地域、必要 Encrypt/Decrypt 权限及显式保留期，使用服务端安全环境注入；不要填写网页、请求体、客户端文件或本报告。当前是否存在这些真实配置仍未获证实。
3. 执行离线自检并检查 `state`；`configured` 后仍须在另行授权的真实环境验证 KMS/IAM 和撤回场景。失效/未配置不会恢复 publish/reveal，历史核对与撤回继续按原权限可用。
4. 不因配置成功更新旧 handoff 证明等级、联系/回应/成交/回款状态。现有同意、接收映射、来源、撤回、CAS、原 key 和未知不重放均继续由 Phase29 原 helper 决定。

最终源与证据以 `phase30-kms-config-final-hashes.json` 为准；独立审查另计，未在此报告冒称通过。

一级资料依据：已实际读取固定官方 SDK `kms_client.js` / `AbstractClient`，以及此前核过的 [腾讯官方 Node SDK 仓库](https://github.com/TencentCloud/tencentcloud-sdk-nodejs)、[KMS Encrypt 文档](https://intl.cloud.tencent.com/document/product/1030/32788)、[CloudBase HTTP 函数资源集成说明](https://docs.cloudbase.net/cloud-function/resource-integration/cloudbase)。本次优先复用本地已冻结资料，没有为已确定 API 重复联网查找；包安装联网单独记录。
