'use strict';
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const PROJECT=path.resolve(__dirname,'../../..'),sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const files=[
 'work/cloud/workspace/contact_delivery.cjs','work/cloud/workspace/kms_contact_provider.cjs','work/cloud/workspace/service.cjs',
 'work/cloud/workspace/contact_delivery.test.cjs','work/cloud/workspace/contact-delivery-fixture.cjs',
 'work/product-upgrade-20261009/audits/phase29-contact-delivery-local-fixture.py',
 'work/product-upgrade-20261009/audits/emit-phase29-contact-delivery-fixture.cjs',
 'work/product-upgrade-20261009/audits/phase29-contact-delivery-actual-fixture.json',
 'work/product-upgrade-20261009/audits/phase29-contact-delivery-cloud-review.md',
 'work/product-upgrade-20261009/audits/phase29-contact-delivery-final-green.txt',
 'work/product-upgrade-20261009/audits/phase29-contact-delivery-hardest-first.txt',
 'work/product-upgrade-20261009/audits/phase29-contact-delivery-hardest-second.txt',
 'work/product-upgrade-20261009/audits/phase29-contact-delivery-entry-first.txt',
 'work/product-upgrade-20261009/audits/phase29-contact-delivery-entry-second.txt',
 'work/product-upgrade-20261009/audits/phase29-contact-delivery-entry-green.txt',
 'work/product-upgrade-20261009/audits/phase29-contact-delivery-anchor-candidate.txt',
 'work/product-upgrade-20261009/phase29-kms-runtime/package.json',
 'work/product-upgrade-20261009/phase29-kms-runtime/package-lock.json',
 'work/product-upgrade-20261009/phase29-kms-runtime/node_modules/tencentcloud-sdk-nodejs-kms/package.json',
 'work/product-upgrade-20261009/phase29-kms-runtime/node_modules/tencentcloud-sdk-nodejs-kms/LICENSE',
 'work/product-upgrade-20261009/phase29-kms-runtime/node_modules/tencentcloud-sdk-nodejs-kms/tencentcloud/services/kms/v20190118/kms_client.js',
 'work/product-upgrade-20261009/phase29-kms-runtime/node_modules/tencentcloud-sdk-nodejs-common/tencentcloud/common/abstract_client.js',
 'work/product-upgrade-20261009/phase29-kms-runtime/node_modules/tencentcloud-sdk-nodejs-common/tencentcloud/common/http/http_connection.js',
 'work/product-upgrade-20261009/backups/phase29-contact-delivery/1/service.cjs',
 'work/product-upgrade-20261009/backups/phase29-contact-delivery/1/manifest.json',
 'work/product-upgrade-20261009/backups/phase29-contact-delivery/2/service.cjs',
 'work/product-upgrade-20261009/backups/phase29-contact-delivery/3/phase29-contact-delivery-actual-fixture-bom-first.json',
 'work/product-upgrade-20261009/backups/phase29-contact-delivery/4/contact_delivery.cjs',
 'work/product-upgrade-20261009/backups/phase29-contact-delivery/5/phase29-contact-delivery-actual-fixture-before-anchor.json',
 'work/product-upgrade-20261009/audits/freeze-phase29-contact-delivery-cloud.cjs'
];
const entries=files.map(relative=>{const full=path.join(PROJECT,relative);return {path:full.replaceAll('\\','/'),sha256:sha(fs.readFileSync(full)).toUpperCase()};});
const lookup=relative=>entries.find(row=>row.path.endsWith(relative)).sha256;
const expected={
 'work/cloud/workspace/contact_delivery.cjs':'956E223CDB73BFC191902EC0854C1D521D82CB92820FFFB63A22F9768D60BD71',
 'work/cloud/workspace/kms_contact_provider.cjs':'30A82FF1B4FD02AB33F1E7E91786CB38EF181F1C55BFACF5E8E9F3468828CDF2',
 'work/cloud/workspace/service.cjs':'FE6E303DB9FA8DBAB07F548B016040438B49799CEAA2E72113D3DAF5770612B0',
 'work/cloud/workspace/contact_delivery.test.cjs':'AC39ACE89A8EC043973190206ACB6B10CC6C404FB2A9A9708E462B1398FFC770',
 'work/product-upgrade-20261009/audits/phase29-contact-delivery-actual-fixture.json':'42CFB5C80C209BCC4101008BC3C89F224FA877BC380ACF9FF28E340F5E6540A8'
};
for(const [file,hash]of Object.entries(expected))if(lookup(file)!==hash)throw Error('frozen source changed: '+file);
const source=JSON.parse(fs.readFileSync(path.join(PROJECT,'work/product-upgrade-20261009/audits/phase29-contact-delivery-actual-fixture.json'),'utf8'));
for(const row of source.source_metadata)if(lookup(row.path)!==row.sha256.toUpperCase())throw Error('actual fixture metadata differs: '+row.path);
const result={phase:'phase29_contact_delivery_cloud_candidate',frozen:true,files:entries,
 own_unique_tests:3,own_final_passed:3,own_final_duration_ms:4973.42,
 root_independent_unique_tests:2,root_independent_passed:2,root_independent_duration_ms:1843.5787,
 public_delivery_fields:31,actual_cases:12,real_kms:false,real_crypto_verified:false,real_cloud:false,
 transaction_evidence:'actual createService/createStore with SDK-interface memory callback replay; not SDK internal transaction engine',
 max_callback_operations:22,max_callback_reads:21,max_callback_writes:5,
 no_default_provider:true,no_real_credentials:true,no_deployment:true,other_stage_evidence_unchanged:true};
const destination=path.join(__dirname,'phase29-contact-delivery-cloud-final-hashes.json');
if(fs.existsSync(destination))throw Error('final manifest already exists; do not overwrite phase evidence');
fs.writeFileSync(destination,JSON.stringify(result,null,2)+'\n','utf8');
process.stdout.write(JSON.stringify({path:destination,sha256:sha(fs.readFileSync(destination)).toUpperCase(),files:entries.length,report_sha256:lookup('work/product-upgrade-20261009/audits/phase29-contact-delivery-cloud-review.md')})+'\n');
