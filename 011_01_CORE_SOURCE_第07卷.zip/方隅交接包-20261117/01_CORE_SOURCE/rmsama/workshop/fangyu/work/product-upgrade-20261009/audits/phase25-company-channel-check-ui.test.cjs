/* Actual disk controller/app and actual Core/company-service DTOs.
 * Lightweight DOM / controlled HTTP boundary; not native browser GUI. */
'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),crypto=require('node:crypto');
const folder=path.resolve(__dirname,'../../app/src/web/workspace');
const source=fs.readFileSync(path.join(folder,'upgrade-operations-ui.mjs'),'utf8');
const fixture=JSON.parse(fs.readFileSync(path.join(__dirname,'company-channel-check-actual-fixture.json'),'utf8'));
const clone=value=>structuredClone(value),envelope=result=>({status:'succeeded',result:clone(result)}),tick=()=>new Promise(resolve=>setImmediate(resolve));
class Element {
  constructor(tag){this.tagName=tag.toLowerCase();this.children=[];this.parentNode=null;this._text='';this.dataset={};this.attrs={};this.events=new Map();this.disabled=false;this.hidden=false;this.checked=false;this.value='';this.className='';this.classList={add(){},remove(){},toggle(){}};}
  set textContent(value){this.replaceChildren();this._text=String(value);}get textContent(){return this._text+this.children.map(node=>node.textContent).join('');}
  append(...nodes){for(const node of nodes){node.remove();node.parentNode=this;this.children.push(node);}}
  replaceChildren(...nodes){for(const node of this.children)node.parentNode=null;this.children=[];this._text='';this.append(...nodes);}
  remove(){if(this.parentNode)this.parentNode.children=this.parentNode.children.filter(node=>node!==this);this.parentNode=null;}
  setAttribute(key,value){this.attrs[key]=String(value);}removeAttribute(key){delete this.attrs[key];}
  addEventListener(key,fn){this.events.set(key,[...(this.events.get(key)||[]),fn]);}
  querySelectorAll(selector){const choices=selector.split(',').map(value=>value.trim()),match=node=>choices.some(value=>value.startsWith('#')?node.id===value.slice(1):value.startsWith('.')?(node.className||'').split(' ').includes(value.slice(1)):node.tagName===value);return this.children.flatMap(node=>[...(match(node)?[node]:[]),...node.querySelectorAll(selector)]);}
  querySelector(selector){return this.querySelectorAll(selector)[0]||null;}
  focus(){}close(){this.open=false;}showModal(){this.open=true;}
  click(){if(!this.disabled)this.onclick?.();}
}
function deferred(){let resolve,reject;const promise=new Promise((yes,no)=>{resolve=yes;reject=no;});return {promise,resolve,reject};}
async function waitFor(fn){const until=Date.now()+2500;while(!fn()){if(Date.now()>until)assert.fail('actual controller did not settle');await tick();}}
function context(){return {user:{id:'phase25-synthetic-actor',username:'phase25-owner',tenant_id:'phase25-tenant',role:'operator',company_id:'phase25-company'},deviceId:'phase25-device',deviceGeneration:1,companyId:'phase25-company',environmentId:'phase25-environment',localWorkspace:true};}
function actual(doc){const idle=()=>({open(){},reset(){},dispose(){}});return vm.runInNewContext(source.replace(/^const \{[^\n]+\}=await import\([^\n]+\);\r?\n/gm,'').replace(/export /g,'')+'\n({createUpgradeOperations,checkedCompanyChannelCheck:typeof checkedCompanyChannelCheck===\'function\'?checkedCompanyChannelCheck:null});',{
  document:doc,window:{},console,Date,crypto:crypto.webcrypto,TextEncoder,createIntentRuleUI:idle,createPlatformReadUI:idle,createIntentQualityUI:idle,createCompanyPolicyUI:idle,createBusinessReconciliationUI:idle,createSelfWorklistUI:idle,createSelfDailyEvidenceUI:idle});}
function harness({name='matched_lost_echo',readCheck}={}){
  const doc={createElement:tag=>new Element(tag),body:new Element('body')},factory=actual(doc),entry=fixture.cases[name],prepared=entry.preparation_get_result,id=prepared.current.handoff_id,calls=[],errors=[];let principal=context();
  assert.equal(prepared.read_only,true);assert.equal(prepared.mutation_committed,false);
  const values=new Map([['old-operation-original',JSON.stringify({idempotency_key:'phase25-old-unknown',state:'unknown'})]]),before=JSON.stringify([...values]);
  const operations=factory.createUpgradeOperations({execute:async(action,data)=>{calls.push({action,data:clone(data)});assert.deepEqual(clone(data),{handoff_id:id});
    if(action==='company_handoff_preparation_get')return envelope(prepared);
    if(action==='company_handoff_channel_check_get')return readCheck?readCheck():envelope(entry.result);
    assert.fail('no register/submit/sync/status/background action: '+action);},getContext:()=>principal,shell:{hooks:{setAction(){}},refresh:async()=>assert.fail('no background refresh')},onError:error=>errors.push(error),
    storage:{getItem:key=>values.get(key)||null,setItem(){assert.fail('pure check must not persist');},removeItem(){assert.fail('pure check must not release old unknown');}}});
  return {doc,factory,operations,calls,errors,prepared,record:{id},context:next=>{principal=next;},button:label=>doc.body.querySelectorAll('button').find(node=>node.textContent===label),status:()=>doc.body.querySelector('.upgrade-status'),unchanged:()=>assert.equal(JSON.stringify([...values]),before)};
}

test('actual lost-echo company draft is checked only by explicit read and remains distinct from registration echo and delivery',async()=>{
  const h=harness();await h.operations.openCompanyPreparation(h.record);
  assert.deepEqual(h.calls.map(call=>call.action),['company_handoff_preparation_get']);
  const button=h.button('核对公司当前来源');assert.ok(button,'saved preparation needs a visible exact-current-channel check');button.click();button.click();
  await waitFor(()=>h.doc.body.textContent.includes('公司当前草稿来源已对应'));
  assert.deepEqual(h.calls.map(call=>call.action),['company_handoff_preparation_get','company_handoff_channel_check_get']);
  assert.match(h.doc.body.textContent,/原登记回显未保存/);assert.doesNotMatch(h.doc.body.textContent,/登记来源摘要一致/);
  assert.match(h.status().textContent,/^公司当前来源已对应；原登记回显仍待核对/);
  assert.match(h.doc.body.textContent,/资源部独立接收、成交与回款仍未核验/);assert.equal(h.button('确认登记公司草稿'),undefined);h.unchanged();h.operations.dispose();
  const check=actual({createElement:tag=>new Element(tag),body:new Element('body')}).checkedCompanyChannelCheck;assert.equal(typeof check,'function');
  for(const entry of Object.values(fixture.cases)){assert.equal(Object.keys(entry.result).length,34);assert.equal(check(entry.result,{handoffId:entry.preparation_get_result.current.handoff_id,origin:entry.preparation_get_result.origin}),entry.result);}
  for(const mutate of [r=>{r.private_source='PRIVATE';},r=>{r.origin.origin_id='a'.repeat(64);},r=>{r.current_company.channel_id='hc_'+'a'.repeat(64);},r=>{r.original_operation.full_historical_chain_verified=true;},r=>{r.current_channel_source_matched=false;},r=>{r.eligible_for_company_submit=true;},r=>{r.platform_delivery_verified=true;},r=>{r.source_cloud_binding_verified=true;},r=>{r.verified_cash_cents=0;},r=>{r.mutation_committed=true;},r=>{r.no_dispatch_scope='this_registration_call_only';}]){const r=clone(fixture.cases.matched_lost_echo.result);mutate(r);assert.throws(()=>check(r,{handoffId:h.record.id,origin:h.prepared.origin}),/未通过核对/);}
  for(const name of ['registration_unknown','hold_local_withdrawn']){const h=harness({name});await h.operations.openCompanyPreparation(h.record);h.button('核对公司当前来源').click();await waitFor(()=>h.calls.length===2&&h.doc.body.textContent.includes(name==='registration_unknown'?'原公司登记仍未知':'本机当前交付保持暂停'));
    assert.equal(h.button('确认登记公司草稿'),undefined);if(name==='hold_local_withdrawn'){assert.doesNotMatch(h.doc.body.textContent,/当前来源与授权可用于本次准备/);assert.match(h.status().textContent,/^公司当前来源已对应，当前交付保持暂停/);}h.unchanged();h.operations.dispose();}
});

test('late full identity/scope and generation reads are discarded, while a failed recheck clears previous current-source success',async()=>{
  const changes={actor:c=>{c.user.id='changed-actor';},role:c=>{c.user.role='admin';},actorCompany:c=>{c.user.company_id='changed-actor-company';},company:c=>{c.companyId='changed-company';},environment:c=>{c.environmentId='changed-environment';},device:c=>{c.deviceId='changed-device';},generation:c=>{c.deviceGeneration++;},accept:null,reset:null};
  for(const [name,change]of Object.entries(changes)){const gate=deferred(),h=harness({readCheck:()=>gate.promise});let accept=true;await h.operations.openCompanyPreparation(h.record,{accept:()=>accept});h.button('核对公司当前来源').click();await waitFor(()=>h.calls.length===2);
    if(change){const c=context();change(c);h.context(c);}if(name==='accept')accept=false;if(name==='reset')h.operations.reset();gate.resolve(envelope(fixture.cases.matched_lost_echo.result));await tick();await tick();
    assert.doesNotMatch(h.doc.body.textContent,/公司当前草稿来源已对应/);assert.equal(h.calls.length,2);h.unchanged();h.operations.dispose();}
  const failed=deferred();let reads=0;const h=harness({readCheck:()=>++reads===1?envelope(fixture.cases.matched_lost_echo.result):failed.promise});await h.operations.openCompanyPreparation(h.record);h.button('核对公司当前来源').click();await waitFor(()=>h.doc.body.textContent.includes('公司当前草稿来源已对应'));await tick();h.button('核对公司当前来源').click();await waitFor(()=>reads===2);assert.doesNotMatch(h.doc.body.textContent,/公司当前草稿来源已对应/);failed.reject(Error('合成会话已过期，请明确连接原公司'));await waitFor(()=>h.status().dataset.state==='error');assert.doesNotMatch(h.doc.body.textContent,/公司当前草稿来源已对应/);assert.equal(h.calls.length,3);h.unchanged();h.operations.dispose();
});

test('actual app routes exact local channel check to product_action, never generic queued commands or cloud-only workspace',async()=>{
  const app=fs.readFileSync(path.join(folder,'app.mjs'),'utf8'),start=app.indexOf('const PRODUCT_ACTIONS=new Set('),end=app.indexOf('\nasync function requestTaskStop(',start);assert.ok(start>=0&&end>start);
  const entry=fixture.cases.matched_lost_echo,data={handoff_id:entry.preparation_get_result.current.handoff_id};
  for(const localWorkspace of [true,false,undefined]){const calls=[],state={selected:'phase25-device',deviceGeneration:1},cloud={user:context().user,call:async(operation,request)=>{calls.push({operation,request:clone(request)});return {result:entry.result};}};
    const execute=vm.runInNewContext(app.slice(start,end)+'\nexecute;',{config:{localWorkspace},cloud,state,customerPrincipalSignature:user=>JSON.stringify(user),submit:async()=>assert.fail('pure channel check must never call command_submit')});
    if(localWorkspace===true){assert.equal((await execute('company_handoff_channel_check_get',data)).status,'succeeded');assert.deepEqual(calls,[{operation:'product_action',request:{action:'company_handoff_channel_check_get',data}}]);}else{await assert.rejects(()=>execute('company_handoff_channel_check_get',data),error=>error.mutation_committed===false);assert.equal(calls.length,0);}}
});
