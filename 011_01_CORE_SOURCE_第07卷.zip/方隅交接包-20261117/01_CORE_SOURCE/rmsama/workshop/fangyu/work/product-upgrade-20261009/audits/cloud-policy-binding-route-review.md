# R15/R16 公司意向规则与公寓资料进入云提示词：只读选型

2026-10-10。本阶段只写方案和两个离线候选测试；没有修改生产源码、云部署、真实规则、旧客户数据或账号权限。代表性选择已验证 **Node 5/5 + Python 4/4**，但其中两个 Node 用例明确验证“当前缺口”，不能把 9 项通过表述为云资料发布已经完成。

## 结论与成熟路线

复用现有云 `transact` 的同公司会话授权、管理员 CAS、`validateIntentPolicy`、`prompt`、`effectiveRulesVersion`、reserve/contextHash、原请求索引、资金 ledger 和 SDK read-before-write。当前源码没有名为 compilePrompt 的函数，实际编译入口为 `ai_contract.cjs:prompt`；不能宣称调用了不存在的成熟组件。

本机 `IntentRuleManagement` 已有安全 owner 规则、规范化资料、版本/历史、私有读权限及 snapshot/assert_snapshot。云已有公司共用五级 criteria，可以由云 admin 配置后真正进入 provider 提示词。缺的是“本机管理规则显式发布到公司”的协议，以及可信云事实与有效时间进入提示词/缓存的接线。直接加一个随分析上传的 local_policy 参数不成立：它不能证明云权限，也会混淆 owner 草稿和全公司标准。当前该参数实际上被忽略。

本机 `operatorOwners` 只授予本机管理能力，不等于云 admin。用户日常只需分析；发布是少量、显式的管理操作，不应让每条评论都携带数百份资料或所有员工词库。这能控制 token、资料暴露、版本冲突和支持成本，并允许演示明确展示“本机草稿 / 云已发布 / 待核对”，而不是虚构技术确定性。

## 已验证的最难代表链

候选 Node 使用实际 createService、createStore 和事务内存 SDK，模拟 callback replay；只以 provider stub 取代真实模型：

1. 云管理员以 expected_revision 保存自定义 criteria 后，实际 provider 收到的 system prompt 含该标准；员工不能保存，员工 profile 不包含标准正文，过期 CAS 被拒。
2. **基线缺口**：分析 payload 中的 local_policy/事实不会进入实际 prompt。请求成功不代表资料应用。
3. **基线缺口**：向当前 ai_config_save 的 config 加 facts 字段返回 400，provider 零调用，公司状态不变；尚无公寓事实发布接口。
4. 首次 provider stub 未知 → 管理员改分级标准 → 重建 service → 原 key 和新 key 在新配置期望值下都返回 PRODUCT_REQUEST_UNKNOWN。provider 仍 1 次，原金额预留不变，原 status 为 unknown；SDK replay 不执行第二次模型。这是以后加事实版本时必须保持的成熟屏障。
5. 模型等待期间管理员改 criteria，旧调用仍按旧 snapshot 完成真实账本结算。原 status 为已执行、result_available:false、requires_revalidation:true；不能把结算成功当作新版本可应用结果。当前成功响应带旧 rules_version，已有本机 workflow 最终 profile/policy 复核负责阻止写成当前评级。

候选 Python 使用实际本机 IntentRuleManagement/Store/intent_policy：

1. 本机可信 operator 管理者可 snapshot，但其 role 仍为 operator；去掉可信管理配置后，规则读只返回 summary，不返回资料正文。
2. 事实采用 from ≤ now < until。截止前可为 candidate，恰好截止变 needs_facts；本人 high 不被降成无意向，且两个时刻均不是库存/交付/归属证明。
3. 新建 **522 条合成旧记录**（不是原客户库），其中一条有人工评级；保存规则后 522 条全量摘要、人工结果均不变。没有重新分级或隐式 provider 请求。
4. snapshot 后改版，assert_snapshot 拒绝旧版本；新 snapshot 可通过。

两个测试文件只执行当前成熟能力，没有镜像实现未来发布模块。Node 五项采用真实云函数逻辑与本地 SDK 夹具，Python 四项采用真实本机规则逻辑；没有真实 HTTP、AI API、收费或多机部署。

## 推荐最小完整协议（尚待实施）

三个固定云动作：`intent_policy_read`、`intent_policy_publish`、`intent_policy_publish_status`。环境和公司由 createService 固定，actor 从有效 session 及事务中的持久 user 取得。初版 publish 只允许当前云 admin；若以后有 policy_manager，必须是服务端持久权限，不读客户端 role、owner 或本机 operatorOwners。

`intent_policy_publish` 严格允许：environment_id、operation、idempotency_key、expected_policy_revision、policy，以及可选 source_local_revision/source_local_digest。policy 沿本机现有结构，仅 name/enabled、既有五级 criteria、至多 200 个白名单事实；禁止任意 system prompt、model、价格、公司/员工身份、私有关键词/选词/排除词、租客资格排除、原文件内容或联系方式。source_local_* 仅标记来源，不是授权或可信云 digest。主体范围始终为固定公司。

事实沿用 id/name/city/areas/room_types/rent_min/rent_max/effective_from/effective_until/evidence_reference，使用现有整数范围、明确时区及长度/控制字符验证；来源引用使用稳定资料 ID，不上传真实磁盘路径、租客信息或完整文件。自由字段始终是资料数据，不是可执行指令。缺期限/来源的资料可以留在管理草稿，但不能成为 effective_facts。

服务端规范化 policy，重新生成单调 policy_revision 和 cloud_policy_digest；不信任客户端提交的云摘要。现有 Python policy_digest 与 Node JSON.stringify 没有相同日期、排序合同，不直接等同。最小方案把云 digest 视为服务端签发的 opaque 摘要，客户端使用原提交键 + 当前云管理员身份 + 同范围读取的规范化 policy 内容核对发布结果，并记录本机来源 revision/digest 到云 revision/digest 的映射。若要两端自行重算，实施前必须固定统一 canonical DTO、日期毫秒 UTC、整数/空值、字段顺序/Unicode及数组语义，并给互通向量测试；本轮没有假设已具备该能力。

建议持久化位置：现有公司 private document 中新增 `enterpriseIntentPolicy` 当前值；版本正文/来源和发布幂等回执采用独立、带 companyId 的规则版本/发布记录（例如 fangyu_intent_policy_versions / fangyu_intent_policy_publications），复用现存 ledger 的事务与 read-before-write 写法，**不新增资金账本**。同事务读 actor/session、当前 revision、幂等键/请求摘要、目标版本后再写当前值、历史与 receipt。相同 key + 相同主体/内容回同一 receipt；不同内容冲突。未知发布不能自动换 key，先 status 按原键核对；无记录不能声称未提交，需要保留未知或采用已有取消墓碑语义原子阻断晚到提交。

publish 安全回执最少：contract、固定 environment_id/company_id、publication_id/idempotency_key、policy_revision/cloud_policy_digest、published_at、enabled、usable/incomplete/expired/future_fact_count、operator_recorded/independently_verified:false/inventory_verified:false。read/status 只读，禁止触发模型。admin 可读取同公司规范化正文和版本；员工仅取 opaque 版本、digest、有效资料统计与应用状态，不返回 criteria、事实正文、来源引用或任何员工词库。已发布 disabled 或有效资料 0 不能文案声称资料可用。

管理员 AI 密钥配置与规则发布保持独立入口，但只有一个 active criteria 真值：启用新公司版本后，prompt 从已发布 snapshot 取 criteria。旧 ai_config_save 的 intent_policy 应明确拒绝并指引发布，或内部复用同一发布事务/receipt，不能继续维护另一个看似有效的平行标准；旧没有发布记录的公司保留原 v14 配置路线。

## 提示词、事实时间与未知兼容

分析侧只引用可信 ai_profile 返回的 policy_revision/digest、effective_fact_digest 和有效时间边界；不接受任意分析 payload 附带 policy 正文作为应用来源。

reserve 同鉴权事务选择有效事实，生成不可变 snapshot。字段包含公司范围、policy_revision/digest、有效 fact IDs/digest、server_as_of、下一次事实有效性变化时间，以及 operator_recorded/未核库存声明。effectiveRulesVersion/contextHash 加上公司发布版本及有效事实集摘要；未启用新发布协议时保持原版本/索引语义。事实原文作为结构化资料 JSON 放在用户数据消息中，固定安全/本人意向/证据规则仍由 system prompt 保持优先；资料中的文字不能覆盖固定规则。继续保留现有八字段输出 schema，地域/公寓可承接性不能把真实外地 high 降成 unrelated。

关键：原恢复 inputHash 仍由来源 city/post/comments 等稳定内容组成，不把 policy 正文、expected_policy_*、server_as_of 或有效事实集加入该 inputHash。这些属于 context；否则换规则/换员工/新 key 会绕过既有公司 input anchor。原 unknown、缺 money、anchor 缺目标继续 hold；收费/释放只能按旧资金账本真实证明，不因规则变更自动取消、新编号或再次 provider。

缓存 expires_at 不得超过有效事实的下一次开始/结束边界；即使 policy_revision 没变，事实过期/未来事实开始仍改变 effective_fact_digest。ai_profile → reserve 时间跨过边界必须明确版本冲突，不调用模型。缓存命中和返回前复核同样检查当前快照。模型已经调用后资料过期/规则变更仍完成旧账结算与原索引留痕，标注结果需重验；不能改为 known_unbilled，也不能把当前过期资料匹配写入业务记录。状态核对与历史回执不因套餐/资料期限阻断。

provider 返回仅添加安全顶层元数据：applied_policy_revision/digest、applied_effective_fact_digest、facts_as_of、facts_valid_until/下一边界、criteria_source:trusted_cloud_published_policy、facts_source:operator_recorded。不把私有标准/事实内容混进员工回执或原请求元数据。评级仍是意向；事实匹配候选仍不是库存、交付同意、资源部 ACK 或分成判定。

本机 property_match 当前使用本机 owner 的资料。第一阶段即使云 prompt 已引用公司资料，也必须继续标它为 local operator_recorded，不能把该投影冒称公司资料匹配。要让员工获得公司资料匹配，下一步应在可信云端对结构化本人条件做白名单事实后处理，返回仅安全 candidate/needs_facts/count 和摘要，避免为本机匹配把公司私有资料下载给普通员工。该后处理不需要改八字段模型 schema，不是本轮已实现内容。

旧 522 条和人工评级不自动修改。规则发布仅改变将来明确分析的 context；现有重评路径需要暂停采集、明确选择、预算/权限核验、历史备份、人工优先和最终 CAS。云成功只能说明已调用该次 snapshot；本机应用还必须通过 profile/policy/事实期限、actor/host/source、人工更正和原 key/nonce 复验。

## 必须与主窗口共同确定的接线

| 文件/接口 | 必要增量，尚未编辑 |
| --- | --- |
| 云 ai_enterprise.cjs / service.cjs | 新管理动作、严格 payload、可信同事务 publish/read/status；reserve/mark/cache/return 的有效快照复验；复用旧 ledger 和原请求索引 |
| 云 ai_contract.cjs（root 共同文件） | published snapshot 的 prompt 与 effectiveRulesVersion/事实 JSON；八字段/本人/地域边界不变；旧配置入口真值策略 |
| 云 ai_request_recovery.cjs | snapshot metadata 的版本/有效事实兼容；status 需反映时间过期，不只比较 config revision；不改变原 input anchor、不释放 unknown |
| 本机 IntentRuleManagement / product_workspace / business | 管理发布入口与映射、安全幂等/未知 status、trusted cloud admin 核验；本机保存不能称云已应用 |
| 本机 integrations.py | 新只读/管理动作固定白名单、安全回执 projection、当前公司/actor/device 返回 fence；不接受原始云错误 |
| 本机 ai_workflow.py | analysis expectations 与 profile/cache/最终期限复核、公司应用元数据；provider 仍读可信云版本，人工优先与旧记录不改 |
| 本机 ai_attempts.py | 如新增 expected_policy_revision/digest/effective_fact_digest，必须与 expected_revision/rules 一样从稳定 normalized 输入身份剔除，仅进入 context；原未知原 key/status-only/CAS保持 |

最小下一轮先实现完整发布→原键核对→profile→真实 prompt 的一家公司路径，再加入事实到期/中途改版/员工隐藏/未知不重放的代表红绿测试。不要先批量上传真实文件、开放所有员工管理或扩大供应商调用。root 接共享入口，本阶段云原冻结证据继续保留。

## 可复跑证据与 SHA256

```powershell
node --test --test-reporter=spec work/product-upgrade-20261009/audits/test_cloud_policy_binding_candidate.cjs
& 'C:/Users/rmsama/miniconda3/python.exe' -m unittest discover -s work/product-upgrade-20261009/audits -p test_local_policy_binding_candidate.py -v
```

| 核读文件 | SHA256 |
| --- | --- |
| assistant/intent_rule_management.py | C066BBDC3583A2D88AF9398CDE762A61952E7B0E994F2517BB097357C01F48BE |
| core/intent_policy.py | 257D522A3554DEBBF7B586C50A7308AD363F217268A3EE4FEE6D9F67E99515BA |
| assistant/ai_workflow.py | 674452FE23643249E3AB5D2B2797744D8E9760BD2F900F8F1D93BDC266921FFF |
| assistant/ai_attempts.py | EA7585CDBD5384ACC434B8CE1E2361A85256073029744B41D209CC98E4B63970 |
| cloud ai_enterprise.cjs | 6F6768EEECC65AD3162D2BD6C57FD352FC876DDB834841EA6B52DBDA31A0F2C3 |
| cloud ai_contract.cjs | ED12DC00A61F0839B7F16DD6B0B30FD25EE5E9CA781C87364C77A7BF8F654FA9 |
| cloud service.cjs | 76D412CBF6C659B3506563ADB0E2C9DC11EF88B3D10F57BCB173DD2BEC74DF43 |
| cloud ai_request_recovery.cjs | C8A0CDFBB0D83BD863468ED30BD9AEE4A593DDC5677631F9A8A6B90C69FEBE2B |
| test_cloud_policy_binding_candidate.cjs | D8825FE5FE047C50D30A5876D46C683AB0B6F288209E17B4F4AAF98F392D7196 |
| test_local_policy_binding_candidate.py | 7069C1839099CE79FA74C9F42D53CDF4E0FF2E83CE99A250E274A81490E1CE3F |

本机文件相对于 work/app/src，云文件相对于 work/cloud/workspace，候选文件位于本报告所在 audits。当前可读 Codex 周窗剩余 22%，secondary 不可读；未达用户停止线，未使用重置或购买。
