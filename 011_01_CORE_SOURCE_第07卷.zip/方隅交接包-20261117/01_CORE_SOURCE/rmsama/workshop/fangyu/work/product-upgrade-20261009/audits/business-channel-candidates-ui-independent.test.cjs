/* Actual frontend and shared operations with archived actual Core/SDK fixture.
 * Lightweight DOM/transport only; no browser GUI or live account verification. */
'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const {pathToFileURL}=require('node:url'),{registerHooks}=require('node:module');
const client=path.resolve(__dirname,'../../app/src/web/workspace');
registerHooks({resolve(specifier,context,next){if(specifier.startsWith('file:')){
  const asset=new URL(specifier).searchParams.get('asset');if(asset){assert.match(asset,/^[a-z0-9-]+\.mjs$/);return next(pathToFileURL(path.join(client,asset)).href,context);}}
  return next(specifier,context);}});
const modules=Promise.all(['business-reconciliation-ui.mjs','upgrade-operations-ui.mjs'].map(name=>import(pathToFileURL(path.join(client,name)).href)));
function fixture(){const f=JSON.parse(fs.readFileSync(path.join(__dirname,'business-channel-candidates-local-actual-fixture.json'),'utf8'));
  assert.equal(f.source_metadata.synthetic_only,true);assert.equal(f.source_metadata.live_cloud_or_platform_accessed,false);
  assert.equal(f.source_metadata.evidence_type,'actual_core_journal_handoff_and_actual_sdk_service_serialized_bridge');return f;}
class Element{
  constructor(tag){this.tagName=tag.toLowerCase();this.children=[];this._text='';this.parent=null;this.events=new Map();this.dataset={};this.attrs={};this.value='';this.disabled=false;}
  set textContent(value){this._text=String(value);this.children=[];}get textContent(){return this._text+this.children.map(n=>n.textContent).join('');}
  append(...nodes){for(const node of nodes){node.remove();node.parent=this;this.children.push(node);}}
  replaceChildren(...nodes){for(const n of this.children)n.parent=null;this.children=[];this._text='';this.append(...nodes);}
  remove(){if(this.parent)this.parent.children=this.parent.children.filter(n=>n!==this);this.parent=null;}
  setAttribute(key,value){this.attrs[key]=String(value);}addEventListener(name,callback){const list=this.events.get(name)||[];list.push(callback);this.events.set(name,list);}
  dispatch(name){for(const fn of this.events.get(name)||[])fn({type:name,preventDefault(){}});}
  querySelectorAll(selector){const match=n=>selector.split(',').some(s=>s.startsWith('.')?(n.className||'').split(' ').includes(s.slice(1)):n.tagName===s.toLowerCase());
    return this.children.flatMap(n=>[...(match(n)?[n]:[]),...n.querySelectorAll(selector)]);}
  showModal(){this.open=true;}close(){this.open=false;}click(){if(!this.disabled)this.onclick?.();}
}
const tick=()=>new Promise(resolve=>setImmediate(resolve));
async function waitFor(predicate){const end=Date.now()+2000;while(!predicate()){if(Date.now()>end)assert.fail('actual frontend callbacks did not settle');await tick();}}
const answer=result=>({status:'succeeded',result:structuredClone(result)});
const button=(view,text)=>view.querySelectorAll('button').find(n=>n.textContent===text);
const hasCandidates=view=>view.querySelectorAll('button').some(n=>n.textContent==='选择并核对公司账本');
async function harness(execute){const [ui,{createUpgradeOperations}]=await modules,body=new Element('body'),calls=[],storageCalls={read:0,write:0,remove:0};
  global.document={body,createElement:tag=>new Element(tag),dispatchEvent(){}};
  const storage={getItem(){storageCalls.read++;return null;},setItem(){storageCalls.write++;throw Error('readonly storage write');},removeItem(){storageCalls.remove++;throw Error('readonly mutation-slot removal');}};
  const context={user:{id:'synthetic-source',username:'source',tenant_id:'synthetic-tenant',role:'operator'},deviceId:'synthetic-device',deviceGeneration:1};
  const operations=createUpgradeOperations({execute:async(action,data)=>{calls.push({action,data:structuredClone(data)});return execute(action,data);},getContext:()=>context,
    shell:{hooks:{setAction(){}},refresh:async()=>{throw Error('readonly mutation refresh');}},storage});
  return {operations,ui,context,calls,storageCalls,body,view:()=>body.querySelectorAll('dialog')[0]};}

test('actual partial and next projections validate; opening is silent and candidate selection performs one fresh original-detail query',async()=>{
  const f=fixture(),h=await harness((action,data)=>{
    if(action==='business_reconciliation_candidates'){assert.deepEqual(data,f.request);return answer(f.result);}
    assert.equal(action,'business_reconciliation_detail');assert.deepEqual(data,f.selected_detail.request);
    assert.equal(data.channel_id,f.result.items[0].channel_id);return answer(f.selected_detail.result);
  });try{
    h.ui.checkedBusinessChannelCandidates(f.result,f.request);h.ui.checkedBusinessChannelCandidates(f.next.result,f.next.request);
    await h.operations.openBusinessReconciliation({handoffId:f.request.handoff_id});assert.equal(h.calls.length,0);
    button(h.view(),'查找对应公司交接').click();await waitFor(()=>hasCandidates(h.view()));
    assert.equal(h.calls.length,1);assert.equal(h.view().querySelectorAll('button').filter(n=>n.textContent==='选择并核对公司账本').length,5);
    assert.match(h.view().textContent,/尚无本机交接的权威对应回执/);assert.doesNotMatch(h.view().textContent,/已送达本机交接|已收款|已付款|人民币/);
    for(const detail of h.view().querySelectorAll('details').filter(n=>n.querySelectorAll('summary').some(s=>s.textContent==='查看公司交接编号')))assert.notEqual(detail.open,true);
    button(h.view(),'选择并核对公司账本').click();await waitFor(()=>h.calls.length===2&&h.view().textContent.includes('来源与交接证据'));
    assert.match(h.view().textContent,/尚无本机与公司交接的权威对应回执/);
    assert.equal(f.selected_detail.result.verified_cash_cents,null);assert.equal(f.selected_detail.result.verified_paid_commission_cents,null);
    assert.equal(h.storageCalls.write,0);assert.equal(h.storageCalls.remove,0);
  }finally{h.operations.dispose();}
});

test('actual next cursor is forwarded byte-for-byte and a controlled empty end page is not worded as a completed global search',async()=>{
  const f=fixture();let continuation=0;const h=await harness((action,data)=>{assert.equal(action,'business_reconciliation_candidates');
    if(!data.cursor){assert.deepEqual(data,f.request);return answer(f.result);}
    assert.deepEqual(data,{handoff_id:f.request.handoff_id,cursor:f.result.next_cursor});
    const next=structuredClone(f.next.result);if(continuation++)next.items=[];return answer(next);
  });try{
    await h.operations.openBusinessReconciliation({handoffId:f.request.handoff_id});button(h.view(),'查找对应公司交接').click();await waitFor(()=>hasCandidates(h.view()));
    button(h.view(),'继续扫描公司交接').click();await waitFor(()=>h.view().textContent.includes('已到当前索引末页'));
    assert.equal(h.view().querySelectorAll('button').filter(n=>n.textContent==='选择并核对公司账本').length,1);
    assert.equal(h.calls.length,2);assert.equal(h.calls[1].data.cursor,f.result.next_cursor);
    assert.doesNotMatch(h.view().textContent,/已扫描全部|所有交接均已|公司没有对应交接/);
    // This explicitly controlled no-match page exercises wording; it is not a
    // claim that the archived actual service fixture had an empty last page.
    button(h.view(),'查找对应公司交接').click();await waitFor(()=>h.view().querySelectorAll('button').filter(n=>n.textContent==='选择并核对公司账本').length===5);
    button(h.view(),'继续扫描公司交接').click();await waitFor(()=>h.view().textContent.includes('此结果不排除其他页或更早本机来源'));
    assert.ok(!hasCandidates(h.view()));assert.doesNotMatch(h.view().textContent,/公司没有对应交接|全局不存在/);
    assert.equal(h.storageCalls.read,0);assert.equal(h.storageCalls.write,0);assert.equal(h.storageCalls.remove,0);
  }finally{h.operations.dispose();}
});

test('actual empty local journal is readable without pretending a cloud scan or proving company absence',async()=>{
  const f=fixture().no_local_sources,h=await harness((action,data)=>{assert.equal(action,'business_reconciliation_candidates');assert.deepEqual(data,f.request);return answer(f.result);});try{
    h.ui.checkedBusinessChannelCandidates(f.result,f.request);await h.operations.openBusinessReconciliation({handoffId:f.request.handoff_id});assert.equal(h.calls.length,0);
    button(h.view(),'查找对应公司交接').click();await waitFor(()=>h.view().textContent.includes('本次没有读取公司记录'));
    assert.equal(h.calls.length,1,'one explicit local action is not a cloud request');assert.equal(f.result.cloud_read_requested,false);
    assert.ok(!hasCandidates(h.view()));assert.doesNotMatch(h.view().textContent,/公司没有交接|尚未发送|尚未成交/);
    assert.equal(h.storageCalls.read,0);assert.equal(h.storageCalls.write,0);assert.equal(h.storageCalls.remove,0);
  }finally{h.operations.dispose();}
});

test('a late actual candidate answer cannot overwrite a newer explicit numbered query after input epoch changes',async()=>{
  const f=fixture();let resolveCandidate;const late=new Promise(resolve=>{resolveCandidate=resolve;});
  const h=await harness(action=>action==='business_reconciliation_candidates'?late:{status:'failed',error:'Synthetic newer numbered query held'});try{
    await h.operations.openBusinessReconciliation({handoffId:f.request.handoff_id});button(h.view(),'查找对应公司交接').click();await waitFor(()=>h.calls.length===1);
    const input=h.view().querySelectorAll('input')[0];input.value=f.result.items[0].channel_id;input.dispatch('input');h.view().querySelectorAll('form')[0].dispatch('submit');
    await waitFor(()=>h.view().textContent.includes('Synthetic newer numbered query held'));resolveCandidate(answer(f.result));await tick();await tick();
    assert.ok(!hasCandidates(h.view()));assert.match(h.view().textContent,/Synthetic newer numbered query held/);
    assert.equal(h.calls.length,2);assert.equal(h.calls[1].action,'business_reconciliation_detail');
    assert.equal(h.storageCalls.write,0);assert.equal(h.storageCalls.remove,0);
  }finally{h.operations.dispose();}
});

test('a late selected original-detail answer cannot replace a newer explicit candidate lookup',async()=>{
  const f=fixture();let resolveDetail;const late=new Promise(resolve=>{resolveDetail=resolve;});
  const h=await harness(action=>action==='business_reconciliation_detail'?late:answer(f.result));try{
    await h.operations.openBusinessReconciliation({handoffId:f.request.handoff_id});button(h.view(),'查找对应公司交接').click();await waitFor(()=>hasCandidates(h.view()));
    button(h.view(),'选择并核对公司账本').click();await waitFor(()=>h.calls.length===2);
    const input=h.view().querySelectorAll('input')[0];input.value='';input.dispatch('input');button(h.view(),'查找对应公司交接').click();
    await waitFor(()=>h.calls.length===3&&hasCandidates(h.view()));resolveDetail(answer(f.selected_detail.result));await tick();await tick();
    assert.ok(hasCandidates(h.view()));assert.ok(!h.view().textContent.includes('来源与交接证据'));
    assert.equal(h.calls[1].action,'business_reconciliation_detail');assert.equal(h.calls[2].action,'business_reconciliation_candidates');
    assert.equal(h.storageCalls.write,0);assert.equal(h.storageCalls.remove,0);
  }finally{h.operations.dispose();}
});

test('role/device reset removes candidate DOM and rejects a late archived answer without storage cleanup or another request',async()=>{
  for(const change of ['role','device']){const f=fixture();let resolveCandidate;const late=new Promise(resolve=>{resolveCandidate=resolve;});const h=await harness(()=>late);try{
    await h.operations.openBusinessReconciliation({handoffId:f.request.handoff_id});const old=h.view();button(old,'查找对应公司交接').click();await waitFor(()=>h.calls.length===1);
    if(change==='role')h.context.user.role='admin';else h.context.deviceGeneration++;
    h.operations.reset();resolveCandidate(answer(f.result));await tick();await tick();
    assert.equal(old.textContent,'');assert.equal(h.body.querySelectorAll('dialog').length,0);assert.equal(h.calls.length,1);
    assert.equal(h.storageCalls.write,0);assert.equal(h.storageCalls.remove,0);
  }finally{h.operations.dispose();}}
});

test('controlled private extra field or mutation flag clears earlier actual candidates before exposing an error',async()=>{
  const f=fixture(),extra=structuredClone(f.result),mutation=structuredClone(f.result);extra.items[0].contact_reference='PRIVATE-CUSTOMER-REFERENCE';mutation.handoffs_modified=true;
  const queue=[f.result,extra,mutation],h=await harness(()=>answer(queue.shift()));try{
    await h.operations.openBusinessReconciliation({handoffId:f.request.handoff_id});button(h.view(),'查找对应公司交接').click();await waitFor(()=>hasCandidates(h.view()));
    for(let i=0;i<2;i++){button(h.view(),'查找对应公司交接').click();await waitFor(()=>h.view().querySelectorAll('p').some(n=>n.dataset.state==='error'));
      assert.ok(!hasCandidates(h.view()));assert.doesNotMatch(h.view().textContent,/PRIVATE-CUSTOMER-REFERENCE/);}
    assert.ok(h.calls.every(c=>c.action==='business_reconciliation_candidates'));assert.equal(h.storageCalls.write,0);assert.equal(h.storageCalls.remove,0);
  }finally{h.operations.dispose();}
});
