# Phase27 公司提交当前校验：云端阶段审核

本阶段只完善已有 `acquisition_handoff_submit`，不创建新的云端操作、收费配置、发送渠道或角色授权。R01–R25 整体目标未完成。

## 改动与验证结果

原代码在最后一次异步客户占用读取时来源员工被禁用，仍可能提交。真实服务 / store SDK 接口内存适配器测试首先复现 200（应为 401）：首 RED 总耗时 4781.6558ms；修复后原最难方法单独通过，总耗时 558.5645ms。首失败与首次修复日志保留，均不计为新增方法。

现有提交在写入前与返回前核对当前会话和来源员工、资源部配置、原渠道审计快照、原客户事件、平台身份引用、客户授权撤回记录与当前客户占用。提交前页面上的核对不会替代实际提交时的校验。任何晚期变化拒绝提交；写后校验失败由事务回滚，不能描述为“零次尝试写入”。

最终新增 **3 个独立方法全部通过，总耗时 1618.4477ms**：

1. 最后异步读取期间来源员工被禁用，401，未提交。
2. 已尝试暂存提交写入后资源部配置变化、最终授权撤回记录出现，返回失败，整份持久化快照不变。
3. 提交成功后回执丢失，服务重启后仅按原提交编号 GET 核对；随后独立资源部接收、客户撤回，原历史提交事实仍为 submitted，当前状态分别显示 submitted / accepted / withdrawn。GET 零写入、没有第二次提交、平台送达未证实、现金金额为 null。

已有云端交接账本针对回归 **15/15，通过，总耗时 96.8992ms**。旧全量 511 项未重新执行；不将 15 项旧回归计为新增方法。

## 证据与边界

- `phase27-handoff-submit-current-fences-first-red.txt`
- `phase27-handoff-submit-current-fences-hardest-green.txt`
- `phase27-handoff-submit-current-fences-final.txt`
- `phase27-existing-handoff-ledger-targeted-regression.txt`
- `phase27-handoff-submit-current-fences.test.cjs`
- `phase27-handoff-submit-cloud-final-hashes.json`

测试使用真实现有 `createService` / `createStore`，底层为 SDK 接口的内存事务回调重放适配器，不能等同真实云数据库事务引擎验收。测试账号、客户、授权、资源部回执全部为合成数据，网络入口禁用。未部署、未使用原账号数据、未发送评论或私信。联系方式仍仅平台 UID 引用，不代表手机、微信跨电脑交付。

修复前账本保存在 `backups/company-submit-current-fences/1/handoff-ledger.cjs`，其 SHA256 为 `BD40CA08F07E2F050E5176D98891045B86014F7D27BBA1E78B929C2F30E21F6C`。Phase25 已固定七份生产源码快照，不会用后续合法修改后的云端文件冒充旧阶段证据。
