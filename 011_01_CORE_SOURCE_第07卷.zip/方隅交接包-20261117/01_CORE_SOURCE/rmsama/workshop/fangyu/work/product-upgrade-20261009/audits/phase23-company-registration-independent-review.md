# Phase23 公司登记独立后端核验

结论：独立 3 个测试方法最终全部通过（5.179 秒）。本轮没有发现新的产品失败；首次日志中的 4 个错误全部来自独审夹具把 Store.connect() 的上下文管理器当作 SQLite 连接，已仅修正新测试的 tracing wrapper，保留原日志，不计作产品 RED。生产登记 helper 和 transport 在独审前后分别维持 55E89EAC… / 49E85A4B…，未由 D 修改。

## 实际链路与证据范围

使用项目现有 RegistrationFixture 的真实 Core、Store、ContactJournal、可信准备 origin，以及实际公司 createService/createStore/成熟 repository。公司存储通过 SDK 接口兼容的内存 adapter 手工双事务 callback 回放；这不是 CloudBase / node-sdk 内部事务引擎或真实网络、云、账号验证。D 新 worker 只增强合成资源部接收后撤回的成熟操作路径；Python 与 Node 网络入口被禁止，Python Popen 只允许这个确定的本地 Node 合成夹具，旧 ProductOperationReceipts 的 begin/finish/status 被禁止调用。未运行平台 CLI、模型、原账号元数据或旧 511 回归。

## 三组代表

1. 持久 claim 与丢响应恢复：第一个 Core 已保存单一 unknown attempt、实际公司登记尚未执行时阻塞；同 SQLite 的第二个 Core 执行同原登记只能读回 unknown，不能再发起登记。释放第一请求后实际公司 register 成功提交，再人为丢响应，得到 mutation_committed=null。公司服务重建后，由第二个 Core / 新 helper 按原 origin 纯读回原 channel、原 key 与完整 canonical payload hash；原历史 revision=1 / draft 保持，登记调用与渠道都仅 1 个。attempt 仍 unknown，registration_source_verified=false，不能提交资源部。查询回执 mutation_committed=false 只说明本次读没有写，不解除原写未知。

2. 精确来源及晚边界：同 UID 但原评论被替换，发生在精确来源读与公司 register 之间，实际 register 回应不得确认安全来源；本机同意在实际公司写后撤回、或本机设备 scope 在写后失效，同样保留单一 unknown attempt 和 mutation_committed=null。设备 scope 失效后的 GET 在任何公司读之前拒绝；合成测试恢复 trusted guard 后，只读取历史。仅本机撤回时，公司当前记录仍 draft，不能将本机撤回伪装成已同步公司撤回。登记正文严格为固定 9 字段，contact_reference 仅 platform:xiaohongshu:原UID，不传 DPAPI 或手机字段。

3. 缺 origin / 旧历史 / 异常投影：缺 origin 的 GET 不建 attempt、不生成 key、不写墓碑、不调用公司。客户端额外 DPAPI 联系字段在调用公司前被拒。成熟公司 register → submit → 不同合成资源部主体 accept → withdraw 后，本机 GET 将历史登记 revision=1 / draft 与当前 withdrawn 分列；历史接收记录仍 true、当前同意 false、独立权威 false。再次登记只恢复同号历史，无第二次 register。对实际生成的原操作回执定向注入错误 revision、payload hash 或全历史链 true，均安全拒绝，不写记录。

## 纯读与身份结论

纯读包围器同时追踪原 Core 与第二个 Core 的真实 Store 连接，断言无 INSERT/UPDATE/DELETE/REPLACE/CREATE/DROP/ALTER，并比较整份合成 SQLite iterdump 前后相等；公司 read callback 逐项断言 0 writes、合成 document snapshot 不变。该证据仅覆盖受包围的 GET / 已有 attempt 恢复，不能把真正 REGISTER、准备夹具写或 Core 初始化说成零写；也不是原业务库文件字节哈希验证。

所有历史投影检查 full_historical_chain_verified=false、source_cloud_binding_verified=false、platform_delivery_verified=false、financial_receipt_verified=false、实收 / 实付 null、eligible_for_company_submit=false。资源部合成 actor 与 source 分离证明现有角色路径，未证明现实资源部独立接收、平台送达、佣金归属、现金到账或第二台机器。D 这 3 组直接调用业务 helper 与 SDK 兼容夹具；不冒充独立验证 HTTP / DPAPI session transport，B 与 root 的专属 transport / gateway 代表须另外保留。

## 证据版本与计数

- first.txt：3 方法 / 4 夹具错误，4.174 秒；原 tracing wrapper 对 _GeneratorContextManager 调 set_trace_callback，保留。
- second.txt：修正真实 contextmanager 后，同 3 方法通过，4.875 秒。
- final.txt：进一步把同库第二 Core 的授权回调所用原 Core 一并 tracing，同 3 方法最终通过，5.179 秒。重复执行不增加独立覆盖数量。
- source-before.json 与 source-after.json 是各自时点快照；后者为第二次运行后的中间版测试，不替代最终测试哈希。
- B 的 actual JSON 在测试期间增加真实 GET 投影后重新生成，当前 BDEAC6F0…；before 文件忠实保留当时 6833607D…，中间文件记录现版。D 3 方法不读取这个 DTO，而是实际调用 fixture；没有用改 JSON 旗标伪造读回执。当前 JSON 内 11 个 source_sha256 与磁盘全部匹配。

最终冻结文件、完整 SHA256 与上述历史日志清单见 phase23-company-registration-independent-final-hashes.json。只计算本独审 3 方法；B 原 4 方法分开，不能把本次两次绿色复跑或子场景再计入阶段总数。没有修改生产或旧阶段证据，不扩大真实授权范围。
