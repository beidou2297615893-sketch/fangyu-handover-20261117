"""Freeze only new diagnostic sources and static material; never execute host."""
import hashlib
import json
from pathlib import Path

PROJECT = Path(__file__).resolve().parents[3]
PHASE = PROJECT/'work/product-upgrade-20261009'
AUDITS = PHASE/'audits'
DIAG = PHASE/'diagnostics/developer-original-identity'
NAMES = ('bootstrap.py', 'profile_occupancy.py', 'profile_process_probe.ps1',
    'runtime_identity.py', 'owned_job.py', 'host.py', 'native_runner.py')
MATURE = ('app.py', 'assistant/original_browser_identity_maintenance.py',
    'assistant/browser_login_service.py', 'assistant/service.py', 'core/account_safety.py',
    'assistant/auth_candidate.py', 'assistant/cli_staging.py', 'assistant/owned_webview2_cookies.py',
    'assistant/owned_helper_process.py', 'assistant/owned_helper_dispatch.py',
    'assistant/browser_login_window.py', 'assistant/native_login_observer.py',
    'assistant/login_natural_proof.py', 'assistant/login_natural_identity.py',
    'owned_natural_reader.py', 'core/adapters.py')


def record(path):
    value = path.read_bytes()
    return {'path': str(path.resolve()), 'bytes': len(value),
        'sha256': hashlib.sha256(value).hexdigest().upper()}


def save(name, value):
    (AUDITS/name).write_text(json.dumps(value, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')


def main():
    for name in NAMES:
        if name.endswith('.py'):
            compile((DIAG/name).read_text(encoding='utf-8'), str(DIAG/name), 'exec')
    cfg = PROJECT/'work/desktop-python/pyvenv.cfg'
    homes = [line.partition('=')[2].strip() for line in cfg.read_text(encoding='utf-8').splitlines()
        if line.partition('=')[0].strip().casefold() == 'home']
    assert len(homes) == 1
    materials = []
    for name in ('python.exe', 'pythonw.exe'):
        shim = PROJECT/'work/desktop-python/Scripts'/name
        base_alias = Path(homes[0])/name
        materials.append({'route': name, 'shim': record(shim), 'base_alias': str(base_alias),
            'actual_base': record(base_alias.resolve(strict=True))})
    save('phase26-developer-identity-static-materials.json', {
        'contract': 'phase26_developer_static_materials_v1',
        'purpose': 'developer_original_identity_observation',
        'stage': 'static_material_identity_only', 'interpreter_routes': materials,
        'pyvenv_configuration': record(cfg),
        'mature_source': [record(PROJECT/'work/app/src'/name) for name in MATURE] +
            [record(PHASE/'phase21_native_original_account_metadata.py')],
        'webview2_selection_executed': False, 'actual_runtime_capture_verified': False,
        'original_data_read': False, 'dpapi_read': False, 'os_process_scan_executed': False,
        'browser_started': False, 'commercial_runtime_authorized': False})
    evidence = ('test_phase26_developer_identity_host.py',
        'phase26-developer-identity-hardest-first.txt', 'phase26-developer-identity-hardest-green.txt',
        'phase26-developer-identity-own-three-first.txt', 'phase26-developer-identity-own-three-pre-freeze.txt',
        'phase26-developer-identity-own-three-final.txt', 'phase26-profile-probe-static-parse.json',
        'phase26-developer-identity-source-before-after.json',
        'phase26-developer-identity-static-materials.json',
        'phase26-developer-original-identity-host-review.md',
        'phase26-developer-original-identity-observation-plan.md',
        'phase26-official-runtime-route-review.md', Path(__file__).name)
    save('phase26-developer-original-identity-host-final-hashes.json', {
        'contract': 'phase26_developer_host_freeze_v1', 'sources_frozen': True,
        'source': [record(DIAG/name) for name in NAMES],
        'evidence': [record(AUDITS/name) for name in evidence],
        'verification': {'unique_methods': 3, 'passed': 3, 'ps_static_parse_errors': 0,
            'mechanism_only': True, 'real_job_lifecycle_verified': False,
            'original_account_observed': False, 'original_data_read': False,
            'actual_runtime_capture_verified': False, 'commercial_natural_authorized': False,
            'collection_authorized': False, 'total_goal_complete': False}})
    print(json.dumps({'source_count': len(NAMES), 'unique_methods': 3, 'static_only': True}))


if __name__ == '__main__':
    main()
