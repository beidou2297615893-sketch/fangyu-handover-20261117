/* Read only existing channel/order records. No finance proof or new calculation. */
'use strict';
const crypto=require('node:crypto');
const {repoFor:contactRepoFor,LedgerError}=require('./contact_ledger.cjs');
const {repoFor:handoffRepoFor,HandoffError}=require('./handoff-ledger.cjs');
const OPERATIONS=new Set(['acquisition_reconciliation_detail']);
const CHANNEL=/^hc_[a-f0-9]{64}$/,HEX=/^[a-f0-9]{64}$/;
const USER=/^[A-Za-z0-9_.@-]{3,80}$/,ORDER=/^[A-Za-z0-9_.-]{1,120}$/;
const CALCULATIONS=new Set(['pending_review','review_rejected','attribution_unconfirmed','identity_unverified',
  'policy_unconfigured','no_confirmed_contact','outside_window','calculated']);
const MISSING=['financial_cash_authority_not_integrated','commission_payment_authority_not_integrated','cooperation_policy_not_verified'];
const canonical=value=>Array.isArray(value)?'['+value.map(canonical).join(',')+']':value&&typeof value==='object'
  ?'{'+Object.keys(value).sort().map(key=>JSON.stringify(key)+':'+canonical(value[key])).join(',')+'}':JSON.stringify(value);
const hash=value=>crypto.createHash('sha256').update(typeof value==='string'?value:canonical(value)).digest('hex');
const integer=(value,min=0,max=Number.MAX_SAFE_INTEGER)=>Number.isSafeInteger(value)&&value>=min&&value<=max;
const money=value=>integer(value,0,100000000000);
const username=value=>typeof value==='string'&&USER.test(value)?value:null;
const strip=value=>Object.fromEntries(Object.entries(value||{}).filter(([key])=>!['_id','companyId','change_kind'].includes(key)));
class ReconciliationError extends Error{constructor(code,message,status=400){super(message);this.code='RECONCILIATION_'+code;this.status=status;}}
const fail=(code,message,status)=>{throw new ReconciliationError(code,message,status);};
function createBusinessReconciliation({store,companyId,clock=Date.now,handoffLedger}){
  if(!companyId||!store?.transaction||typeof handoffLedger?.readBoundItem!=='function')throw Error('经营对账只读仓库未配置');
  function authorize(state,identity){
    if(!state||state.companyId!==companyId)fail('TENANT_MISMATCH','企业隔离检查失败',403);
    const now=Math.floor(clock()/1000),session=state.sessions?.find(row=>row.digest===identity?.sessionDigest&&row.username===identity?.username&&row.expires>now);
    const actor=session&&state.users?.find(row=>row.username===session.username&&!row.disabled&&['admin','operator'].includes(row.role));
    if(!actor)fail('AUTH_REQUIRED','账号或当前会话已失效，请重新核对',401);
    return actor;
  }
  async function sourceFor(contacts,item){
    const stored=await contacts.get('event:'+item.source_event_id),record=stored?.record;
    const customer=await contacts.get('customer:'+item.customer_id);
    const base={evidence_status:record?'conflict':'missing',event_id:item.source_event_id,payload_hash:null,
      owner:item.source_owner,device_id:null,platform:item.source?.platform||null,
      source_lead_hash:null,original_text_hash:null,author_id_hash:null,comment_id_hash:null,platform_provenance_verified:false};
    if(!record)return base;
    const lead=record.lead,raw=Object.fromEntries(['event_id','kind','occurred_at','lead','reply','sender'].map(key=>[key,record[key]]));
    if(Object.hasOwn(record,'intent_snapshot'))raw.intent_snapshot=record.intent_snapshot;
    if(!lead||record.source!=='device_report'||record.event_id!==item.source_event_id||record.employee!==item.source_owner||
      record.device_id!==item.source?.device_id||lead.platform!==item.source?.platform||lead.author_id!==item.source?.author_id||
      lead.comment_id!==item.source?.comment_id||typeof lead.id!=='string'||typeof lead.text!=='string'||
      hash(lead.id)!==item.source?.source_lead_hash||hash(lead.text)!==item.source?.original_text_hash||
      record.customer_id!==item.customer_id||stored.customer_id!==item.customer_id||
      item.customer_id!=='cu_'+hash(lead.platform+':author:'+lead.author_id)||
      !customer||customer.customer_id!==item.customer_id||customer.platform!==lead.platform||customer.author_id!==lead.author_id||customer.provisional!==false||
      stored.fingerprint!==hash(JSON.stringify({event:raw,employee:record.employee,device_id:record.device_id})))return base;
    return {...base,evidence_status:'matched',payload_hash:hash(raw),device_id:record.device_id,
      source_lead_hash:hash(lead.id),original_text_hash:hash(lead.text),author_id_hash:hash(lead.author_id),comment_id_hash:hash(lead.comment_id)};
  }
  function emptyOrder(link,state){return {order_no:link.order_no,linked_revision:link.order_revision,current_revision:null,status:'unknown',
    binding_state:state,link_revision_current:null,reported_amount_cents:null,reported_refund_cents:null,reported_net_cents:null,
    reported_by:null,last_edited_by:null,admin_review_recorded:false,reviewed_by:null,distinct_review_actor_recorded:null,
    recorded_calculated_commission_cents:null,calculation_status:'unknown',calculation_policy_revision:null,
    calculation_policy_snapshot_available:false,calculation_policy_current:null,verified_cash_cents:null,verified_paid_commission_cents:null,
    financial_receipt_verified:false,cooperation_policy_verified:false,missing_evidence:[...MISSING,...(state==='matched'?[]:[state])]};}
  async function orderFor(contacts,handoffs,item,link,source,currentPolicy,policies){
    if(!link||typeof link.order_no!=='string'||!ORDER.test(link.order_no)||!integer(link.order_revision,1))fail('STORAGE_CONFLICT','已存订单关联字段需核对',409);
    if(source.evidence_status!=='matched')return emptyOrder(link,'source_'+source.evidence_status);
    const deal=await contacts.get('deal:'+link.order_no),reverse=await handoffs.get('order:'+link.order_no);
    if(!deal)return emptyOrder(link,'order_missing');
    if(deal.customer_id!==item.customer_id)return emptyOrder(link,'customer_conflict');
    if(!reverse||reverse.channel_id!==item.channel_id||reverse.customer_id!==item.customer_id)return emptyOrder(link,'reverse_link_conflict');
    if(deal.order_no!==link.order_no||!integer(deal.revision,1)||!money(deal.amount_cents)||!money(deal.refund_cents)||deal.refund_cents>deal.amount_cents||
      !['pending','confirmed','rejected'].includes(deal.status))return emptyOrder(link,'record_invalid');
    const history=await contacts.get(`deal_revision:${link.order_no}:${deal.revision}`);
    if(!history)return emptyOrder(link,'history_missing');
    if(!['report','review'].includes(history.change_kind)||canonical(strip(history))!==canonical(strip(deal)))return emptyOrder(link,'history_conflict');
    const linkedHistory=link.order_revision===deal.revision?history:await contacts.get(`deal_revision:${link.order_no}:${link.order_revision}`);
    if(!linkedHistory)return emptyOrder(link,'history_missing');
    if(linkedHistory.order_no!==link.order_no||linkedHistory.customer_id!==item.customer_id||
      linkedHistory.revision!==link.order_revision||linkedHistory.status!==link.order_status_at_link||
      !['report','review'].includes(linkedHistory.change_kind))return emptyOrder(link,'history_conflict');
    const current=link.order_revision===deal.revision,state=current?'matched':'link_revision_changed';
    const result=emptyOrder(link,state),reportedBy=username(deal.reported_by),editedBy=username(deal.last_edited_by),reviewedBy=username(deal.reviewed_by);
    const reviewed=deal.status!=='pending'&&reviewedBy!==null&&integer(deal.reviewed_at,1577836800);
    let policy=null;
    if(integer(deal.policy_revision)){
      if(!policies.has(deal.policy_revision))policies.set(deal.policy_revision,await contacts.get('policy_history:'+deal.policy_revision));
      const candidate=policies.get(deal.policy_revision);
      if(candidate?.revision===deal.policy_revision&&(candidate.commission_rate_bps===null||integer(candidate.commission_rate_bps,0,10000))&&
        (candidate.attribution_days===null||integer(candidate.attribution_days,1,365)))policy=candidate;
    }
    const calculation=CALCULATIONS.has(deal.calculation_status)?deal.calculation_status:'unknown';
    Object.assign(result,{current_revision:deal.revision,status:deal.status,link_revision_current:current,
      reported_amount_cents:deal.amount_cents,reported_refund_cents:deal.refund_cents,reported_net_cents:deal.amount_cents-deal.refund_cents,
      reported_by:reportedBy,last_edited_by:editedBy,admin_review_recorded:reviewed,reviewed_by:reviewed?reviewedBy:null,
      distinct_review_actor_recorded:reviewed&&reportedBy&&editedBy?reviewedBy!==reportedBy&&reviewedBy!==editedBy:null,
      recorded_calculated_commission_cents:calculation==='calculated'&&money(deal.commission_cents)&&policy&&
        policy.commission_rate_bps!==null&&policy.attribution_days!==null?deal.commission_cents:null,
      calculation_status:calculation,calculation_policy_revision:integer(deal.policy_revision)?deal.policy_revision:null,
      calculation_policy_snapshot_available:policy!==null,
      calculation_policy_current:policy&&currentPolicy?currentPolicy.revision===policy.revision&&
        currentPolicy.commission_rate_bps===policy.commission_rate_bps&&currentPolicy.attribution_days===policy.attribution_days:null});
    if(calculation==='calculated'&&!policy)result.missing_evidence.push('commission_policy_history_missing');
    return result;
  }
  async function handle(payload,identity){
    if(!OPERATIONS.has(payload?.operation))return null;
    try{
      if(!payload||typeof payload!=='object'||Array.isArray(payload)||Object.keys(payload).some(key=>!['environment_id','operation','channel_id','offset','limit'].includes(key))||
        typeof payload.channel_id!=='string'||!CHANNEL.test(payload.channel_id))fail('INVALID_INPUT','经营对账只接受已存服务器渠道编号');
      const offset=payload.offset??0,limit=payload.limit??10;
      // A revised order costs four bound-record reads plus one archived policy;
      // fifteen rows leave room for source/authority rechecks (85 reads total).
      if(!integer(offset)||!integer(limit,1,15))fail('INVALID_INPUT','每页允许1至15条已关联订单');
      const summary=await store.transaction(async(state,transaction)=>{
        const actor=authorize(state,identity),principal=hash({username:actor.username,role:actor.role,disabled:!!actor.disabled});
        const bound=await handoffLedger.readBoundItem(transaction,state,actor,payload.channel_id),item=bound.item;
        if(!Array.isArray(item.order_links))fail('STORAGE_CONFLICT','已存订单关联清单需核对',409);
        if(offset>item.order_links.length)fail('INVALID_INPUT','订单分页范围需重新核对');
        const contacts=contactRepoFor(transaction,companyId),handoffs=handoffRepoFor(transaction,companyId),source=await sourceFor(contacts,item);
        const currentPolicy=await contacts.get('policy'),policies=new Map(),items=[];
        for(const link of item.order_links.slice(offset,offset+limit))items.push(await orderFor(contacts,handoffs,item,link,source,currentPolicy,policies));
        const finalActor=authorize(state,identity);
        if(hash({username:finalActor.username,role:finalActor.role,disabled:!!finalActor.disabled})!==principal)fail('AUTH_REQUIRED','当前员工权限已变化，请重新核对',401);
        const finalBound=await handoffLedger.readBoundItem(transaction,state,finalActor,payload.channel_id);
        if(finalBound.item.revision!==item.revision||finalBound.item.last_event_hash!==item.last_event_hash||finalBound.current_consent_valid!==bound.current_consent_valid)
          fail('SOURCE_CHANGED','交接授权或版本已变化，请重新读取',409);
        const value={contract:'business_reconciliation_v1',read_only:true,storage_scope:'company_server_ledger',observed_at:Math.floor(clock()/1000),authenticated_actor:finalActor.username,
          currency:null,amount_unit:'legacy_cents',channel:{channel_id:item.channel_id,revision:item.revision,status:item.status,customer_id:item.customer_id,
            source_event_id:item.source_event_id,source_owner:item.source_owner,current_consent_valid:bound.current_consent_valid,
            eligible_for_delivery:item.status==='accepted'&&bound.current_consent_valid,
            historical_resource_receipt_recorded:item.receipt?.authenticated===true&&item.receipt.decision==='accept'&&item.receipt.actor!==item.source_owner&&item.receipt.recipient_id===item.recipient_id,
            receipt_evidence_independently_verified:false,attribution_status:item.attribution_status,source},
          orders:{items,total_linked:item.order_links.length,offset,limit,has_more:offset+items.length<item.order_links.length},
          verified_cash_cents:null,verified_paid_commission_cents:null,financial_receipt_verified:false,cooperation_policy_verified:false,
          missing_evidence:[...MISSING,...(source.evidence_status==='matched'?[]:['source_'+source.evidence_status])]};
        return {state,result:value};
      });
      return {status:200,data:{summary}};
    }catch(error){
      if(error instanceof ReconciliationError||error instanceof HandoffError||error instanceof LedgerError)return {status:error.status,data:{error:error.message,code:error.code,read_only:true}};
      return {status:503,data:{error:'经营对账摘要暂不可读，请稍后按原渠道核对',code:'RECONCILIATION_STORAGE_UNAVAILABLE',read_only:true}};
    }
  }
  return {handle};
}
module.exports={createBusinessReconciliation,OPERATIONS,ReconciliationError};
