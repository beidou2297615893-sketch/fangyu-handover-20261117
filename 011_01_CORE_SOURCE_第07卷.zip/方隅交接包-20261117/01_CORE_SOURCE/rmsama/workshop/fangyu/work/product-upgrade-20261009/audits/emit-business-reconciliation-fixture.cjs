const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const {fixture}=require('../../cloud/workspace/business-reconciliation-fixture.cjs');
(async()=>{
 const f=await fixture(),p=await f.accepted();await f.order(p);const response=await f.summary(p);
 if(response.status!==200)throw Error('Synthetic service response failed');
 const fields=['event_id','kind','occurred_at','lead','reply','sender'];
 const normalized=[...f.data.docs().values()].filter(row=>row.record?.reply?.id===p.event.reply.id).map(row=>row.record)
  .map(record=>{const raw=Object.fromEntries(fields.map(key=>[key,record[key]]));if(Object.hasOwn(record,'intent_snapshot'))raw.intent_snapshot=record.intent_snapshot;return raw;})
  .sort((a,b)=>a.occurred_at-b.occurred_at);
 const manifest=Object.fromEntries(['business_reconciliation.cjs','handoff-ledger.cjs','service.cjs','contact_ledger.cjs','index.js','business-reconciliation-fixture.cjs']
  .map(name=>[name,crypto.createHash('sha256').update(fs.readFileSync(path.join(__dirname,'../../cloud/workspace',name))).digest('hex')]));
 const value={synthetic_only:true,company_id:'fixture-company',environment_id:'fixture-env',owner:'source',device_id:'fixture-source-device',
  event:normalized.find(row=>row.kind==='sent'),events:normalized,envelope:response.data,source_sha256:manifest};
 fs.writeFileSync(path.join(__dirname,'business-reconciliation-cloud-actual-fixture.json'),JSON.stringify(value,null,2)+'\n');
 process.stdout.write('Synthetic actual service envelope exported, events='+normalized.length+'\n');
})().catch(error=>{process.stderr.write('Synthetic fixture generation failed\n');process.exitCode=1;});
