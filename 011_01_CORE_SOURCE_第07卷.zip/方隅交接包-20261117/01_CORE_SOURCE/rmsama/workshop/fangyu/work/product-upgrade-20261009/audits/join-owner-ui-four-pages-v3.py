from pathlib import Path
import hashlib, json, stat, uuid

project = Path('C:/积木软件工坊/项目/方隅公寓客户版')
stage = project / 'work/product-upgrade-20261009'
source = project / 'work/app/src'
candidate = stage / 'ui-approved-rebuild-candidate-v3/web/workspace'
review = stage / 'ui-approved-rebuild-review-v3/REVIEW.md'
review_sha = '06BE3F4C956B7E333D0FCA5CFF4838F2E64CCE888D656BCCE68406FF28B7EF5E'
receipt_path = stage / 'audits/ui-approved-owner-four-pages-v3-joined.json'
if receipt_path.exists():
    raise ValueError('Join already recorded; retain evidence')

def read(path, expected):
    resolved = path.resolve(strict=True)
    if not resolved.is_relative_to(project.resolve()):
        raise ValueError('File outside intended project')
    attrs = path.lstat()
    if path.is_symlink() or getattr(attrs, 'st_file_attributes', 0) & 0x400 or not stat.S_ISREG(attrs.st_mode) or attrs.st_nlink != 1:
        raise ValueError('File is not plain and unshared')
    raw = path.read_bytes()
    if hashlib.sha256(raw).hexdigest().upper() != expected:
        raise ValueError('Pin changed: ' + str(path))
    return raw

read(review, review_sha)
protected = json.loads((stage / 'audits/ui-approved-owner-workbench-v2-joined.json').read_text('utf-8'))['backend_protected']
for name, expected in protected.items():
    read(source / name, expected)
specs = [
 ('self-operating-read.mjs', '5D4900BCD1407DA790C92FAAA9B03ED2B43ED2ED23464E4F0292B537D03F964A', '2B47E4E04AD096EC8DAA4A2395409B45475331FA4B82BE4646FEF5C390B3440C'),
 ('upgrade-ui.css', '555F7BC3698CC0169B3CD48692241986F2F99EF6DCA44DCDD899C66005B7FE43', '38A3ED20F6C7A6B0E53F23634E2D0F0F9A32C16522869D27168FC2966DFDF7F1')]
changes = []
for name, parent_sha, new_sha in specs:
    target = source / 'web/workspace' / name
    changes.append((target, read(target, parent_sha), read(candidate / name, new_sha), parent_sha, new_sha))
mirror = project / 'work/cloud/workspace/site/upgrade-ui.css'
changes.append((mirror, read(mirror, specs[1][1]), changes[1][2], specs[1][1], specs[1][2]))
backup = project / 'backups/ui-approved-owner-four-pages-v3' / uuid.uuid4().hex
backup.mkdir(parents=True)
records = []
for i, (target, parent, new, parent_sha, new_sha) in enumerate(changes):
    if target.read_bytes() != parent:
        raise ValueError('Target changed during join')
    saved = backup / (str(i) + '.bin')
    saved.write_bytes(parent)
    target.write_bytes(new)
    read(target, new_sha)
    records.append({'target': str(target), 'backup': str(saved), 'parent_sha256': parent_sha, 'applied_sha256': new_sha, 'bytes': len(new)})
for name, expected in protected.items():
    read(source / name, expected)
receipt = {'schema': 'owner_approved_visual_four_pages_v3_join', 'source_batch': 35, 'scope': 'UI_ONLY_CODE_REVIEWED_NATIVE_VISUAL_PENDING', 'targets': records, 'backend_protected': protected, 'review_sha256': review_sha, 'original_App_restarted': False, 'pilot_Core_restarted': False, 'customer_data_modified': False, 'visual_QA_passed': False, 'Computer_Use_stopped_by_latest_user_instruction': True}
receipt_path.write_text(json.dumps(receipt, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps({'joined_physical_files': len(records), 'source_batch': 35, 'backend_unchanged': len(protected), 'native_visual_pending': True}, ensure_ascii=False))
