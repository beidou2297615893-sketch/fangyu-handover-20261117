"""Preserve the previous short handoff and link the actual next work item."""
import hashlib
from pathlib import Path
from uuid import uuid4

PROJECT = Path('C:/积木软件工坊/项目/方隅公寓客户版')
STAGE = PROJECT/'work/product-upgrade-20261009'
checks = {
    PROJECT/'work/owner-instance-platform-upgrade-candidate/qa-readonly-prepare-v1/RESULT.json': 'EFB4E51DADA915D57AC370663401405DC308E83241EEE58B69F056F370173C16',
    PROJECT/'work/owner-instance-platform-upgrade-review/SOURCE48-PREPARE-ACTUAL-REVIEW.md': '6B792C3FEA34B269BAA869398E3352F2CD1A992E484B795D20E3DEB501E472B2',
}
for path, expected in checks.items():
    if hashlib.sha256(path.read_bytes()).hexdigest().upper() != expected:
        raise SystemExit('actual evidence changed')
next_file = STAGE/'audits/source48-current.md'
if not next_file.is_file():
    raise SystemExit('next factual handoff missing')
path = STAGE/'audits/source47-current.md'
original = path.read_bytes()
header = (
    '# 最新后继：Source48只读prepare已实际通过，原47仍待闲时合入\r\n\r\n'
    '准确后继只读 [Source48当前接续](source48-current.md)：40ea58唯一normal Factory代表exit0，'
    'RESULT EFB4E51D已Root全文读，actual peer6B792C3F已Root463610全文读。'
    '关闭屏障及durable writer在独立候选并行，未正式实施升级；当前用户占用答复仍待，47不apply。'
    '84ff50确认原main43256/51916仍活，0Root刷新/启停/平台/模型，额度不查询。'
    '原47 CODE/Node/Core与合入准备原事实见下方，不重已过验证。\r\n\r\n'
).encode('utf-8')
backup = STAGE/'context-history'/('source47-before-source48-pointer-' + uuid4().hex + '.md')
with backup.open('xb') as stream:
    stream.write(original)
if backup.read_bytes() != original or path.read_bytes() != original:
    raise SystemExit('backup or current pointer drift')
path.write_bytes(header + original)
if path.read_bytes() != header + original:
    raise SystemExit('pointer readback failed')
print('Linked Source48 actual evidence; preserved previous handoff at ' + str(backup))
print('No SOURCE, pilot, database, session, App or platform writes.')
