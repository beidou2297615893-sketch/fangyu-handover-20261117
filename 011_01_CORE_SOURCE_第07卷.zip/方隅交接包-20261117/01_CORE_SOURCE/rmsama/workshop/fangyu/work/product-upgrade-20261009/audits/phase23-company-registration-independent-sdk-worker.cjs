/* Actual project service/repos, synthetic SDK-interface memory replay only. */
'use strict';
const readline=require('node:readline');
const assert=require('node:assert/strict');
for(const mod of ['node:http','node:https'])require(mod).request=()=>{throw Error('network forbidden');};
require('node:net').Socket.prototype.connect=()=>{throw Error('network forbidden');};
global.fetch=()=>{throw Error('network forbidden');};
const {fixture}=require('../../cloud/workspace/handoff-operation-status-fixture.cjs');
let engine=null,registerCalls=0;
async function command(input){
 if(!engine)engine=await fixture();
 if(input.kind==='sync'){
  const result=await engine.call('contact_events_sync',{events:[input.event]},'fixture-source-device-token');
  assert.equal(result.status,200);return {result};
 }
 if(input.kind==='register'){
  registerCalls++;
  if(input.corrupt_source)engine.data.mutateDoc(engine.doc('contact_','event:'+input.data.source_event_id),doc=>{
   doc.record.lead.comment_id='independent-other-comment-same-uid';return doc;
  });
  if(input.lose_response)engine.loseNextResponse();
  return {result:await engine.call('acquisition_channel_register',input.data),register_calls:registerCalls};
 }
 if(input.kind==='read'){
  assert.ok(['acquisition_source_binding_read','acquisition_handoff_operation_status'].includes(input.operation));
  engine.data.resetOperations();const before=engine.data.snapshot();
  const result=await engine.call(input.operation,input.data);assert.equal(before,engine.data.snapshot());
  const operations=engine.data.operations();
  for(const callbacks of operations)for(const count of callbacks)assert.equal(count.writes,0);
  return {result,operations,stored_documents_unchanged:true,register_calls:registerCalls};
 }
 if(input.kind==='accept_withdraw'){
  let result=await engine.call('acquisition_handoff_detail',{channel_id:input.channel_id});assert.equal(result.status,200);
  result=await engine.change('acquisition_handoff_submit',result.data.item);assert.equal(result.status,200);
  result=await engine.change('acquisition_handoff_receipt',result.data.item,
   {decision:'accept',evidence_reference:'evidence:'+'f'.repeat(32)},engine.tokens.resource);assert.equal(result.status,200);
  result=await engine.change('acquisition_handoff_withdraw',result.data.item,{reason_code:'customer_withdrew'});
  assert.equal(result.status,200);return {changed:true};
 }
 if(input.kind==='restart'){engine.restart();return {register_calls:registerCalls};}
 if(input.kind==='counts')return {register_calls:registerCalls,
  channels:[...engine.data.docs().values()].filter(doc=>doc?.channel_id&&doc?.source_event_id).length};
 throw Error('unknown independent fixture command');
}
const lines=readline.createInterface({input:process.stdin,crlfDelay:Infinity});
(async()=>{for await(const line of lines){try{process.stdout.write(JSON.stringify(await command(JSON.parse(line)))+'\n');}
 catch(error){process.stdout.write(JSON.stringify({fixture_error:error.message,register_calls:registerCalls})+'\n');}}})()
 .catch(()=>{process.exitCode=1;});
