/* Actual createService/createStore/repos with an SDK-interface-compatible
 * in-memory adapter manually replaying callbacks, synthetic records only.
 * No mock status handler or real SDK transaction engine/network/cloud action.
 */
'use strict';
const {test}=require('node:test');
const assert=require('node:assert/strict');
const {fixture,hash}=require('../../cloud/workspace/handoff-operation-status-fixture.cjs');
const OP='acquisition_handoff_operation_status',REGISTER='acquisition_channel_register',
  SUBMIT='acquisition_handoff_submit',RECEIPT='acquisition_handoff_receipt';

async function setup(policy,lostResponse=false){
  const f=await fixture(policy),source=await f.source(),key='independent-original-register';
  const body={source_event_id:source.event.event_id,recipient_id:'resources',purpose:'租房咨询承接',qualification:'qualified',
    consent:{status:'granted',evidence_reference:'consent:'+'d'.repeat(32),notice_version:'v1'},idempotency_key:key};
  let item;
  if(lostResponse){
    f.loseNextResponse();
    await assert.rejects(f.call(REGISTER,body,f.tokens.source),/response lost after service committed/);
  }else{
    const answer=await f.call(REGISTER,body,f.tokens.source);assert.equal(answer.status,200);item=answer.data.item;
  }
  return {f,key,body,item,operationDoc:f.doc('handoff_','operation:'+hash(['fixture-company','source',REGISTER,key]))};
}
const read=(f,action,key,who='source',extra={})=>f.call(OP,{operation_action:action,idempotency_key:key,...extra},f.tokens[who]);
function value(answer){assert.equal(answer.status,200);return answer.data.operation_receipt;}
function noWrites(f){for(const pair of f.data.operations())for(const row of pair){assert.equal(row.writes,0);assert.ok(row.reads<=100);}}
function noPrivate(result){const text=JSON.stringify(result);
  for(const token of ['PRIVATE-', '[REDACTED:phone_cn]','contact_reference','evidence_reference','"author_id"','"comment_id"','"lead"','"sender"'])
    assert.ok(!text.includes(token),token);
}

test('actual lost-result/restart receipt lookup has zero writes even with expired housekeeping rows and commercial rights',async()=>{
  const policy={package:'team',features:['handoff','team'],seat_limit:null,store_limit:null,analysis_quota:null,billing_period:'pilot'};
  const {f,key}=await setup(policy,true);
  // The actual service committed; the adapter then dropped its response.
  // Only the original key survives restart; no channel ID or write replay
  // is sent to status.
  f.restart();policy.features=[];policy.expires_at=f.clock()/1000-1;
  await f.mutate(state=>{state.sessions.push({username:'outsider',digest:'expired-housekeeping-session',expires:1});
    state.attempts.stale={count:1,until:1};state.rememberedDevices.push({idleExpires:1,absoluteExpires:1});});
  const before=f.data.snapshot();f.data.resetOperations();
  const result=value(await read(f,REGISTER,key));
  assert.equal(result.state,'recorded');assert.equal(result.original_execution_confirmed,true);
  assert.equal(result.operation_action,REGISTER);assert.equal(result.idempotency_key,key);
  assert.equal(result.authenticated_actor,'source');assert.equal(result.mutation_committed,false);
  assert.equal(result.original_operation.revision,1);assert.equal(result.original_operation.historical_status,'draft');
  assert.equal(result.original_operation.full_historical_chain_verified,false);
  assert.equal(result.financial_receipt_verified,false);assert.equal(result.cooperation_policy_verified,false);
  assert.equal(result.verified_cash_cents,null);assert.equal(result.verified_paid_commission_cents,null);
  assert.equal(result.auto_retry,false);noPrivate(result);noWrites(f);assert.equal(f.data.snapshot(),before);
});

test('original receiver ACK and source submit remain historical recorded after current consent withdrawal',async()=>{
  const {f,item,key}=await setup();
  const submitKey='independent-original-submit',ackKey='independent-original-ack';
  const submitted=await f.call(SUBMIT,{channel_id:item.channel_id,expected_revision:1,idempotency_key:submitKey},f.tokens.source);
  assert.equal(submitted.status,200);
  const accepted=await f.call(RECEIPT,{channel_id:item.channel_id,expected_revision:2,idempotency_key:ackKey,
    decision:'accept',evidence_reference:'evidence:'+'c'.repeat(32)},f.tokens.resource);assert.equal(accepted.status,200);
  const withdrawn=await f.call('acquisition_handoff_withdraw',{channel_id:item.channel_id,expected_revision:3,
    idempotency_key:'independent-withdraw-original',reason_code:'customer_withdrew'},f.tokens.source);assert.equal(withdrawn.status,200);
  const before=f.data.snapshot();f.data.resetOperations();
  for(const [action,originalKey,who,revision,status] of [[REGISTER,key,'source',1,'draft'],
      [SUBMIT,submitKey,'source',2,'submitted'],[RECEIPT,ackKey,'resource',3,'accepted']]){
    const result=value(await read(f,action,originalKey,who));
    assert.equal(result.original_execution_confirmed,true);assert.equal(result.original_operation.revision,revision);
    assert.equal(result.original_operation.historical_status,status);
    assert.equal(result.current_handoff.revision,4);assert.equal(result.current_handoff.status,'withdrawn');
    assert.equal(result.current_handoff.current_consent_valid,false);
    assert.equal(result.current_handoff.historical_resource_receipt_recorded,true);
    assert.equal(result.current_handoff.receipt_evidence_independently_verified,false);
    noPrivate(result);
  }
  noWrites(f);assert.equal(f.data.snapshot(),before);
});

test('missing/foreign-actor original key stays unknown/null and cannot grant cross-company or payload authority',async()=>{
  const {f,key}=await setup(),before=f.data.snapshot();f.data.resetOperations();
  for(const [originalKey,who] of [['independent-never-recorded','source'],[key,'outsider'],[key,'admin']]){
    const result=value(await read(f,REGISTER,originalKey,who));
    assert.equal(result.state,'unknown');assert.equal(result.original_execution_confirmed,null);
    assert.equal(result.original_operation,null);assert.equal(result.current_handoff,null);assert.equal(result.auto_retry,false);
  }
  for(const extra of [{actor:'source'},{owner:'source'},{channel_id:'hc_'+'a'.repeat(64)},
      {payload:{purpose:'fake'}},{operation_action:'acquisition_handoff_detail'}]){
    const result=await read(f,REGISTER,key,'source',extra);assert.equal(result.status,400);
  }
  noWrites(f);assert.equal(f.data.snapshot(),before);
  await f.mutate(state=>{state.companyId='another-company';});
  const isolated=await read(f,REGISTER,key);assert.equal(isolated.status,403);assert.equal(isolated.data.operation_receipt,undefined);
});

test('corrupt persisted original operation/audit/current item is refused rather than recomputed or leaked',async()=>{
  const {f,key,item,operationDoc}=await setup();
  const auditDoc=f.doc('handoff_',`event:${item.channel_id}:1`),channelDoc=f.doc('handoff_','channel:'+item.channel_id);
  for(const [doc,change] of [[operationDoc,row=>({...row,actor:'outsider'})],
      [operationDoc,row=>({...row,private_contact:'PRIVATE-CONTACT-13812345678'})],
      [auditDoc,row=>({...row,status:'PRIVATE-AUDIT-13812345678'})],
      [channelDoc,row=>({...row,source_owner:'outsider'})]]){
    const original=f.data.docs().get(doc);f.data.mutateDoc(doc,change);
    const before=f.data.snapshot();f.data.resetOperations();
    const denied=await read(f,REGISTER,key);
    assert.ok((doc===channelDoc?[404,409]:[409]).includes(denied.status));
    assert.equal(denied.data.operation_receipt,undefined);
    noPrivate(denied.data);noWrites(f);assert.equal(f.data.snapshot(),before);
    f.data.mutateDoc(doc,()=>original);
  }
});

test('last awaited document cannot return a recorded receipt after receiver mapping/session/company changes',async()=>{
  const {f,item}=await setup(),ackKey='independent-last-await-ack';
  const submitted=await f.call(SUBMIT,{channel_id:item.channel_id,expected_revision:1,idempotency_key:'independent-late-submit'},f.tokens.source);
  assert.equal(submitted.status,200);
  const accepted=await f.call(RECEIPT,{channel_id:item.channel_id,expected_revision:2,idempotency_key:ackKey,decision:'accept',
    evidence_reference:'evidence:'+'b'.repeat(32)},f.tokens.resource);assert.equal(accepted.status,200);
  const withdrawalDoc=f.doc('handoff_','withdrawal:consent:'+'d'.repeat(32));
  for(const kind of ['receiver','session','company']){
    let matched=0,changed=false;
    f.duringRead((doc,state)=>{if(doc!==withdrawalDoc)return;matched++;
      if(matched%2!==0)return;changed=true;
      if(kind==='receiver')state.acquisitionPolicy.receivers.resource=[];
      else if(kind==='session')state.sessions=state.sessions.filter(row=>row.username!=='resource');
      else state.companyId='another-company';});
    const before=f.data.snapshot();f.data.resetOperations();
    const denied=await read(f,RECEIPT,ackKey,'resource');f.duringRead(null);
    assert.equal(changed,true,kind);assert.ok([401,403,404,409].includes(denied.status),kind);
    assert.equal(denied.data.operation_receipt,undefined);assert.notEqual(denied.data.original_execution_confirmed,false);
    noWrites(f);assert.equal(f.data.snapshot(),before);
  }
});

test('original register key cannot be rebound to a second valid channel by corrupting only its operation document',async()=>{
  const {f,key,body,item,operationDoc}=await setup();
  const anotherSource=await f.source('independent-second-valid-customer');
  const another=await f.call(REGISTER,{...body,source_event_id:anotherSource.event.event_id,
    consent:{...body.consent,evidence_reference:'consent:'+'e'.repeat(32)},
    idempotency_key:'independent-second-valid-register'},f.tokens.source);
  assert.equal(another.status,200);assert.notEqual(another.data.item.channel_id,item.channel_id);
  // Keep the first input hash/actor/action. The second channel and revision
  // have a genuine matching historical audit and current snapshot.
  f.data.mutateDoc(operationDoc,row=>({...row,channel_id:another.data.item.channel_id,revision:1}));
  const before=f.data.snapshot();f.data.resetOperations();
  const denied=await read(f,REGISTER,key);
  assert.equal(denied.status,409,'the original register key must retain its deterministic channel binding');
  assert.equal(denied.data.operation_receipt,undefined);noPrivate(denied.data);
  noWrites(f);assert.equal(f.data.snapshot(),before);
});
