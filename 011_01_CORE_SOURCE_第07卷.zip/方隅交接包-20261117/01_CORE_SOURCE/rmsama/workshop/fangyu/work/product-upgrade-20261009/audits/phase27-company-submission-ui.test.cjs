/* Actual controller/app source with actual Core/service submission DTOs.
 * Lightweight DOM execution; not native browser GUI or company deployment. */
'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),crypto=require('node:crypto');
const folder=path.resolve(__dirname,'../../app/src/web/workspace'),source=fs.readFileSync(path.join(folder,'upgrade-operations-ui.mjs'),'utf8');
const fixture=JSON.parse(fs.readFileSync(path.join(__dirname,'phase27-company-submission-actual-fixture.json'),'utf8'));
const clone=value=>structuredClone(value),envelope=result=>({status:'succeeded',result:clone(result)}),tick=()=>new Promise(resolve=>setImmediate(resolve));
class Element{
  constructor(tag){this.tagName=tag.toLowerCase();this.children=[];this.parentNode=null;this._text='';this.dataset={};this.attrs={};this.events=new Map();this.disabled=false;this.hidden=false;this.checked=false;this.value='';this.className='';this.classList={add(){},remove(){},toggle(){}};}
  set textContent(value){this.replaceChildren();this._text=String(value);}get textContent(){return this._text+this.children.map(node=>node.textContent).join('');}
  append(...nodes){for(const node of nodes){node.remove();node.parentNode=this;this.children.push(node);}}
  replaceChildren(...nodes){for(const node of this.children)node.parentNode=null;this.children=[];this._text='';this.append(...nodes);}
  remove(){if(this.parentNode)this.parentNode.children=this.parentNode.children.filter(node=>node!==this);this.parentNode=null;}
  setAttribute(key,value){this.attrs[key]=String(value);}removeAttribute(key){delete this.attrs[key];}
  addEventListener(key,fn){this.events.set(key,[...(this.events.get(key)||[]),fn]);}
  querySelectorAll(selector){const choices=selector.split(',').map(value=>value.trim()),match=node=>choices.some(value=>value.startsWith('#')?node.id===value.slice(1):value.startsWith('.')?(node.className||'').split(' ').includes(value.slice(1)):node.tagName===value);return this.children.flatMap(node=>[...(match(node)?[node]:[]),...node.querySelectorAll(selector)]);}
  querySelector(selector){return this.querySelectorAll(selector)[0]||null;}
  focus(){}close(){this.open=false;}showModal(){this.open=true;}
  click(){if(!this.disabled)this.onclick?.();}change(){for(const fn of this.events.get('change')||[])fn();}
}
function deferred(){let resolve,reject;const promise=new Promise((yes,no)=>{resolve=yes;reject=no;});return {promise,resolve,reject};}
async function waitFor(fn){const until=Date.now()+2500;while(!fn()){if(Date.now()>until)assert.fail('actual controller did not settle');await tick();}}
function context(){return {user:{id:'phase27-actor',username:'source',tenant_id:'phase27-tenant',role:'operator',company_id:'fixture-company'},deviceId:'fixture-source-device',deviceGeneration:1,companyId:'fixture-company',environmentId:'fixture-env',localWorkspace:true};}
function actual(doc){const idle=()=>({open(){},reset(){},dispose(){}});return vm.runInNewContext(source.replace(/^const \{[^\n]+\}=await import\([^\n]+\);\r?\n/gm,'').replace(/export /g,'')+'\n({createUpgradeOperations,checkedCompanySubmission});',{
  document:doc,window:{},console,Date,crypto:crypto.webcrypto,TextEncoder,createIntentRuleUI:idle,createPlatformReadUI:idle,createIntentQualityUI:idle,createCompanyPolicyUI:idle,createBusinessReconciliationUI:idle,createSelfWorklistUI:idle,createSelfDailyEvidenceUI:idle});}
function harness({name='ready_lost_register_echo',get,submit}={}){
  const doc={createElement:tag=>new Element(tag),body:new Element('body')},factory=actual(doc),entry=fixture.cases[name],prepared=entry.preparation_get_result,calls=[],errors=[];let principal=context();
  const values=new Map([['existing-unknown',JSON.stringify({idempotency_key:'old-operation',state:'unknown'})]]),before=JSON.stringify([...values]);
  const operations=factory.createUpgradeOperations({execute:async(action,data)=>{calls.push({action,data:clone(data)});
    if(action==='company_handoff_preparation_get')return envelope(prepared);
    if(action==='company_handoff_submission_get')return get?get():envelope(entry.result);
    if(action==='company_handoff_submit')return submit?submit():envelope(fixture.cases.first_recorded.result);
    assert.fail('no registration/sync/automatic follow-up command: '+action);},getContext:()=>principal,
    shell:{hooks:{setAction(){}},refresh:async()=>assert.fail('company submission must not mark local leads contacted/delivered')},onError:error=>errors.push(error),
    storage:{getItem:key=>values.get(key)||null,setItem(){assert.fail('no client key generation/persisted generic receipt');},removeItem(){assert.fail('no release of other unknown operation');}}});
  const record={id:prepared.current.handoff_id,revision:prepared.current.revision,recipient_name:'合成资源部',purpose:'合成找房交接'};
  return {doc,factory,operations,entry,prepared,calls,errors,record,context:next=>{principal=next;},button:label=>doc.body.querySelectorAll('button').find(node=>node.textContent===label),status:()=>doc.body.querySelector('.upgrade-status'),checkbox:()=>doc.body.querySelectorAll('input').find(node=>node.type==='checkbox'),unchanged:()=>assert.equal(JSON.stringify([...values]),before)};
}
async function ready(h){await h.operations.openCompanyPreparation(h.record);assert.deepEqual(h.calls.map(c=>c.action),['company_handoff_preparation_get']);h.button('核对或提交资源部').click();await waitFor(()=>h.button('确认提交资源部'));}

test('late full scope, original handoff/version and dialog generation cannot render eligibility or an old submitted response',async()=>{
  const changes={actor:c=>{c.user.id='changed';},role:c=>{c.user.role='admin';},company:c=>{c.companyId='changed';},actorCompany:c=>{c.user.company_id='changed';},environment:c=>{c.environmentId='changed';},device:c=>{c.deviceId='changed';},deviceGeneration:c=>{c.deviceGeneration++;},handoff:null,revision:null,accept:null,reset:null};
  for(const stage of ['get','submit'])for(const [name,change]of Object.entries(changes)){
    const gate=deferred(),h=harness({get:stage==='get'?()=>gate.promise:undefined,submit:stage==='submit'?()=>gate.promise:undefined});let accept=true;
    await h.operations.openCompanyPreparation(h.record,{accept:()=>accept});h.button('核对或提交资源部').click();
    if(stage==='submit'){await waitFor(()=>h.button('确认提交资源部'));const check=h.checkbox();check.checked=true;check.change();h.button('确认提交资源部').click();await waitFor(()=>h.calls.some(c=>c.action==='company_handoff_submit'));}
    else await waitFor(()=>h.calls.length===2);
    if(change){const c=context();change(c);h.context(c);}if(name==='handoff')h.record.id='a'.repeat(32);if(name==='revision')h.record.revision++;if(name==='accept')accept=false;if(name==='reset')h.operations.reset();
    gate.resolve(envelope(fixture.cases[stage==='get'?'ready_lost_register_echo':'first_recorded'].result));await tick();await tick();
    assert.equal(h.button('确认提交资源部'),undefined,`${stage}/${name} must not keep old eligibility`);assert.doesNotMatch(h.doc.body.textContent,/原公司提交已核对/);assert.equal(h.calls.filter(c=>c.action==='company_handoff_submit').length,stage==='submit'?1:0);h.unchanged();h.operations.dispose();
  }
});

test('actual lost register echo can qualify only by explicit GET then unchecked confirmation; unknown/recorded remain status-only',async()=>{
  const h=harness();await ready(h);assert.equal(h.button('确认提交资源部').disabled,true);h.button('确认提交资源部').click();assert.equal(h.calls.length,2);
  const checkbox=h.checkbox();assert.equal(checkbox.checked,false);checkbox.checked=true;checkbox.change();const button=h.button('确认提交资源部');button.click();button.click();
  await waitFor(()=>h.doc.body.textContent.includes('原公司提交已核对'));
  assert.deepEqual(h.calls.filter(c=>c.action==='company_handoff_submit'),[{action:'company_handoff_submit',data:clone(fixture.cases.first_recorded.request)}]);
  assert.match(h.status().textContent,/^原公司提交已核对/);assert.match(h.doc.body.textContent,/原登记回显未保存/);assert.match(h.doc.body.textContent,/仅提交平台身份引用/);assert.equal(h.button('确认提交资源部'),undefined);h.unchanged();h.operations.dispose();
  for(const name of ['submit_unknown','recorded_get','submit_response_lost_recorded','withdrawn_historical','registration_not_attempted']){
    const x=harness({name});await x.operations.openCompanyPreparation(x.record);x.button('核对或提交资源部').click();await waitFor(()=>x.calls.length===2&&x.status().textContent!=='正在读取原公司提交与当前条件…');
    assert.equal(x.button('确认提交资源部'),undefined,name);assert.equal(x.calls.filter(c=>c.action==='company_handoff_submit').length,0);x.unchanged();x.operations.dispose();
  }
  const failed=deferred();let reads=0;const u=harness({get:()=>envelope(fixture.cases.ready_lost_register_echo.result),submit:()=>failed.promise});await ready(u);u.checkbox().checked=true;u.checkbox().change();u.button('确认提交资源部').click();await waitFor(()=>u.calls.length===3);failed.reject(Error('合成响应丢失'));await waitFor(()=>u.status().dataset.state==='error');assert.ok(u.button('核对原公司提交'));u.button('核对原公司提交').click();await waitFor(()=>u.calls.length===4&&u.status().textContent.includes('原公司提交仍待核对'));assert.equal(u.button('确认提交资源部'),undefined,'GET absence must not release this still-unknown write');assert.equal(u.calls.filter(c=>c.action==='company_handoff_submit').length,1);u.unchanged();u.operations.dispose();
});

test('actual historical submitted/current withdrawn/receipt DTOs stay separate; strict proof and actual app route never imply delivery or queue writes',async()=>{
  const checker=actual({createElement:tag=>new Element(tag),body:new Element('body')}).checkedCompanySubmission;
  for(const entry of Object.values(fixture.cases)){assert.equal(Object.keys(entry.result).length,36);assert.equal(checker(entry.result,{handoffId:entry.preparation_get_result.current.handoff_id,origin:entry.preparation_get_result.origin,readOnly:entry.result.read_only}),entry.result);}
  const x=harness({name:'withdrawn_historical'});await x.operations.openCompanyPreparation(x.record);x.button('核对或提交资源部').click();await waitFor(()=>x.doc.body.textContent.includes('原公司提交已核对'));
  assert.match(x.status().textContent,/原公司提交已核对；当前已撤回/);assert.match(x.doc.body.textContent,/已记录；接收证据待独立核对/);assert.match(x.doc.body.textContent,/历史来源回显仍待核对/);assert.match(x.doc.body.textContent,/当前无有效授权/);assert.doesNotMatch(x.doc.body.textContent,/已成交|已到账|已完成分成支付/);assert.equal(x.calls.length,2);x.unchanged();x.operations.dispose();
  const entry=fixture.cases.submit_response_lost_recorded;
  for(const mutate of [r=>{r.extra_private='PRIVATE';},r=>{r.origin.origin_id='a'.repeat(64);},r=>{r.current_local.handoff_id='a'.repeat(32);},r=>{r.current_company.channel_id='hc_'+'a'.repeat(64);},r=>{r.original_operation.revision=1;},r=>{r.original_operation.historical_status='accepted';},r=>{r.original_operation.full_historical_chain_verified=true;},r=>{r.eligible_for_company_submit=true;},r=>{r.submission_execution_confirmed=false;},r=>{r.platform_delivery_verified=true;},r=>{r.verified_cash_cents=0;},r=>{r.local_handoffs_modified=true;},r=>{r.no_dispatch_scope='this_registration_get_only';}]){
    const result=clone(entry.result);mutate(result);assert.throws(()=>checker(result,{handoffId:entry.preparation_get_result.current.handoff_id,origin:entry.preparation_get_result.origin}),/未通过核对/);
  }
  const app=fs.readFileSync(path.join(folder,'app.mjs'),'utf8'),start=app.indexOf('const PRODUCT_ACTIONS=new Set('),end=app.indexOf('\nasync function requestTaskStop(',start);assert.ok(start>=0&&end>start);
  for(const localWorkspace of [true,false,undefined])for(const action of ['company_handoff_submission_get','company_handoff_submit']){
    const calls=[],state={selected:'fixture-source-device',deviceGeneration:1},cloud={user:context().user,call:async(operation,request)=>{calls.push({operation,request:clone(request)});return {result:fixture.cases[action.endsWith('_get')?'recorded_get':'first_recorded'].result};}};
    const execute=vm.runInNewContext(app.slice(start,end)+'\nexecute;',{config:{localWorkspace},cloud,state,customerPrincipalSignature:user=>JSON.stringify(user),submit:async()=>assert.fail('company submission must not enter queued command_submit')});
    const data=action.endsWith('_get')?{handoff_id:entry.preparation_get_result.current.handoff_id}:fixture.cases.first_recorded.request;
    if(localWorkspace===true){assert.equal((await execute(action,data)).status,'succeeded');assert.deepEqual(calls,[{operation:'product_action',request:{action,data:clone(data)}}]);}
    else{await assert.rejects(()=>execute(action,data),error=>error.mutation_committed===false);assert.equal(calls.length,0);}
  }
});
