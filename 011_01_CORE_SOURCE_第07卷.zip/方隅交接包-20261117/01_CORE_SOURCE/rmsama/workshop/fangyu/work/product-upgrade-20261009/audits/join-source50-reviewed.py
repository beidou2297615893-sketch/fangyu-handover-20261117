"""Fixed Source50 CAS, called once under the normal-open original OS lock."""
import ast,ctypes,hashlib,json,os,stat,subprocess,sys,tempfile,uuid
from ctypes import wintypes
from pathlib import Path
PROJECT=Path('C:/积木软件工坊/项目/方隅公寓客户版')
WORK=PROJECT/'work'
AUDITS=WORK/'product-upgrade-20261009/audits'
OWN=WORK/'overnight-commercial-20261014/source50-preparation'
PREPARED=OWN/'PREPARED.json'
APPROVAL=AUDITS/'source50-final-root-read.json'
AUTHORITY=AUDITS/'source50-manifest.json'
STARTED=AUDITS/'source50-next-open-started.json'
RECEIPT=AUDITS/'source50-joined.json'
FAILED=AUDITS/'source50-join-failed.json'
PILOT=WORK/'self-operating-pilot'
ENTRY=WORK/'desktop-self-use-entry/desktop_entry.py'
INSTANCE_ID='d075ac9c039e44038ddbc6f3e753d73c'
NEW_RUNTIME=WORK/'app/work/runtime/dy/douyin-bridge-source-cid-v1'
TARGET_RELATIVE=('app/src/assistant/owner_company_receipt_bridge.py', 'app/src/web/workspace/self-operating-read.mjs', 'app/src/app.py', 'app/src/assistant/owner_douyin_read.py', 'app/work/runtime/dy/douyin-bridge-source-cid-v1/node.exe', 'app/work/runtime/dy/douyin-bridge-source-cid-v1/NODE-LICENSE.txt', 'app/work/runtime/dy/douyin-bridge-source-cid-v1/LICENSE', 'app/work/runtime/dy/douyin-bridge-source-cid-v1/package.json', 'app/work/runtime/dy/douyin-bridge-source-cid-v1/package-lock.json', 'app/work/runtime/dy/douyin-bridge-source-cid-v1/cli.js', 'app/work/runtime/dy/douyin-bridge-source-cid-v1/server.js', 'app/work/runtime/dy/douyin-bridge-source-cid-v1/scripts/douyin.user.js', 'app/work/runtime/dy/douyin-bridge-source-cid-v1/lib/audit.js', 'app/work/runtime/dy/douyin-bridge-source-cid-v1/lib/client/bridge-client.js', 'app/work/runtime/dy/douyin-bridge-source-cid-v1/lib/commands/comment-page.js', 'app/work/runtime/dy/douyin-bridge-source-cid-v1/lib/commands/dm.js', 'app/work/runtime/dy/douyin-bridge-source-cid-v1/lib/commands/get.js', 'app/work/runtime/dy/douyin-bridge-source-cid-v1/lib/commands/helpers.js', 'app/work/runtime/dy/douyin-bridge-source-cid-v1/lib/commands/index.js', 'app/work/runtime/dy/douyin-bridge-source-cid-v1/lib/commands/post.js', 'app/work/runtime/dy/douyin-bridge-source-cid-v1/lib/commands/replies.js', 'app/work/runtime/dy/douyin-bridge-source-cid-v1/lib/commands/search.js', 'app/work/runtime/dy/douyin-bridge-source-cid-v1/lib/memory/comments.js', 'app/work/runtime/dy/douyin-bridge-source-cid-v1/lib/memory/corpus.js', 'app/work/runtime/dy/douyin-bridge-source-cid-v1/lib/memory/db.js', 'app/work/runtime/dy/douyin-bridge-source-cid-v1/lib/memory/events.js', 'app/work/runtime/dy/douyin-bridge-source-cid-v1/lib/memory/failures.js', 'app/work/runtime/dy/douyin-bridge-source-cid-v1/lib/memory/users.js', 'app/work/runtime/dy/douyin-bridge-source-cid-v1/lib/memory/videos.js', 'app/work/runtime/dy/douyin-bridge-source-cid-v1/lib/miniapp-delivery-state.js', 'app/work/runtime/dy/douyin-bridge-source-cid-v1/lib/risk-control.js', 'app/work/runtime/dy/douyin-bridge-source-cid-v1/lib/server/registry.js', 'app/work/runtime/dy/douyin-bridge-source-cid-v1/lib/server/router.js', 'app/work/runtime/dy/douyin-bridge-source-cid-v1/lib/server/ws-hub.js', 'app/work/runtime/dy/douyin-bridge-source-cid-v1/lib/shared/protocol.js', 'app/work/runtime/dy/douyin-bridge-source-cid-v1/lib/shared/serialize.js', 'app/work/runtime/dy/douyin-bridge-source-cid-v1/node_modules/ws/package.json', 'app/work/runtime/dy/douyin-bridge-source-cid-v1/node_modules/ws/LICENSE', 'app/work/runtime/dy/douyin-bridge-source-cid-v1/node_modules/ws/index.js', 'app/work/runtime/dy/douyin-bridge-source-cid-v1/node_modules/ws/browser.js', 'app/work/runtime/dy/douyin-bridge-source-cid-v1/node_modules/ws/wrapper.mjs', 'app/work/runtime/dy/douyin-bridge-source-cid-v1/node_modules/ws/lib/buffer-util.js', 'app/work/runtime/dy/douyin-bridge-source-cid-v1/node_modules/ws/lib/constants.js', 'app/work/runtime/dy/douyin-bridge-source-cid-v1/node_modules/ws/lib/event-target.js', 'app/work/runtime/dy/douyin-bridge-source-cid-v1/node_modules/ws/lib/extension.js', 'app/work/runtime/dy/douyin-bridge-source-cid-v1/node_modules/ws/lib/limiter.js', 'app/work/runtime/dy/douyin-bridge-source-cid-v1/node_modules/ws/lib/permessage-deflate.js', 'app/work/runtime/dy/douyin-bridge-source-cid-v1/node_modules/ws/lib/receiver.js', 'app/work/runtime/dy/douyin-bridge-source-cid-v1/node_modules/ws/lib/sender.js', 'app/work/runtime/dy/douyin-bridge-source-cid-v1/node_modules/ws/lib/stream.js', 'app/work/runtime/dy/douyin-bridge-source-cid-v1/node_modules/ws/lib/subprotocol.js', 'app/work/runtime/dy/douyin-bridge-source-cid-v1/node_modules/ws/lib/validation.js', 'app/work/runtime/dy/douyin-bridge-source-cid-v1/node_modules/ws/lib/websocket-server.js', 'app/work/runtime/dy/douyin-bridge-source-cid-v1/node_modules/ws/lib/websocket.js', 'desktop-self-use-entry/desktop_entry.py')
ALLOWED=frozenset(TARGET_RELATIVE)
HELPER=AUDITS/'join-source44-reviewed.py'
helper_raw=HELPER.read_bytes()
if len(helper_raw)!=9601 or hashlib.sha256(helper_raw).hexdigest().upper()!='5F5E3EA22AF7C1FA0FEA71CFEFDA12A9D669C190D5470960901029BF8F4750FB':
    raise ValueError('reviewed helper changed')
names={'blob','pin','expected','no_link_parent','prepared_temp'}
definitions=[x for x in ast.parse(helper_raw).body if isinstance(x,ast.FunctionDef) and x.name in names]
if len(definitions)!=5 or {x.name for x in definitions}!=names:raise ValueError('helper definitions changed')
exec(compile(ast.Module(body=definitions,type_ignores=[]),str(HELPER),'exec'),globals())

def existing_lock_is_held():
    # Read only metadata and probe the same existing byte range from a child.
    # A free/unknown range cannot stand in for the caller's normal-open lock.
    path=PILOT/'data/instance.lock'
    no_link_parent(path);info=path.lstat()
    if path.is_symlink() or getattr(info,'st_file_attributes',0)&0x400 or not stat.S_ISREG(info.st_mode) or info.st_nlink!=1 or info.st_size<1:
        raise ValueError('existing lock identity unknown')
    code="import errno,msvcrt,os,sys; f=open(sys.argv[1],'r+b'); f.seek(0)\ntry:\n msvcrt.locking(f.fileno(),msvcrt.LK_NBLCK,1)\nexcept OSError as e:\n if e.errno not in (errno.EACCES,errno.EDEADLK): raise\n print('held')\nelse:\n f.seek(0); msvcrt.locking(f.fileno(),msvcrt.LK_UNLCK,1); print('free')\nfinally:\n f.close()"
    probe=subprocess.run([sys.executable,'-B','-c',code,str(path)],capture_output=True,text=True,timeout=15,
        creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
    after=path.lstat()
    if probe.returncode or probe.stderr.strip() or probe.stdout.strip()!='held' or (info.st_dev,info.st_ino)!=(after.st_dev,after.st_ino):
        raise ValueError('original normal-open OS lock is free or unknown')

def original_main_dead():
    raw=blob(PILOT/'data/running.json')
    if len(raw)>4096:raise ValueError('main metadata unknown')
    value=json.loads(raw)
    if (type(value) is not dict or set(value)!={'pid','url','mode'} or type(value['pid']) is not int
        or not 0<value['pid']<=0xffffffff or value['mode'] not in ('headless-test','assistant','browser')):
        raise ValueError('main identity unknown')
    if pid_state(value['pid'])!='dead':raise ValueError('original main alive or unknown')
    return value['pid']

def main():
    if os.name!='nt' or len(sys.argv)!=3 or sys.argv[1]!='--apply' or len(sys.argv[2])!=64:
        raise ValueError('exact Root approval SHA required; prepared is not approved')
    if RECEIPT.exists() or FAILED.exists():raise ValueError('original execution evidence preserved')
    approval_raw=blob(APPROVAL)
    if pin(approval_raw)['sha256']!=sys.argv[2].upper():raise ValueError('Root approval changed')
    gate=json.loads(approval_raw)
    if (gate.get('schema')!='source50_final_root_read' or gate.get('source_batch')!=50
        or gate.get('join_authorized') is not True or gate.get('independent_code_review_passed') is not True
        or gate.get('independent_actual_qa_review_passed') is not True or gate.get('join_script_review_passed') is not True
        or gate.get('next_normal_open_only') is not True or gate.get('customer_database_opened') is not False
        or gate.get('session_copied') is not False or gate.get('deployment_or_packaging_performed') is not False):
        raise ValueError('Root fixed deferred scope not approved')
    expected(Path(__file__).absolute(),gate['join_script_pin'])
    manifest=json.loads(expected(PREPARED,gate['prepared_manifest_pin']))
    if (manifest.get('schema')!='source50_owner_prepared_v1' or manifest.get('source_batch')!=50
        or manifest.get('join_authorized') is not False or manifest.get('instance_id')!=INSTANCE_ID):
        raise ValueError('fixed prepared source set changed')
    targets=manifest['targets']
    if len(targets)!=55 or {Path(x['target']).relative_to(WORK).as_posix() for x in targets}!=ALLOWED:
        raise ValueError('exact 55 target whitelist changed')
    if len({x['target'] for x in targets})!=55:raise ValueError('duplicate target')
    for item in manifest['evidence']+gate['additional_evidence']:
        path=Path(item['path']);path.relative_to(WORK);expected(path,item['pin'])
    authority_raw=blob(AUTHORITY);authority=json.loads(authority_raw);started=json.loads(blob(STARTED))
    if (authority.get('schema')!='source50_next_open_manifest_v1' or authority.get('source_batch')!=50
        or authority.get('join_authorized') is not True or authority.get('instance_id')!=INSTANCE_ID
        or authority.get('approval_pin')!=pin(approval_raw) or authority.get('join_script_pin')!=gate['join_script_pin']
        or started.get('schema')!='source50_next_open_started_v1' or started.get('source_batch')!=50
        or started.get('instance_id')!=INSTANCE_ID or started.get('pid')!=os.getpid()
        or started.get('approval_sha256')!=pin(approval_raw)['sha256'] or started.get('manifest_pin')!=pin(authority_raw)
        or started.get('auto_retry') is not False):
        raise ValueError('actual fixed normal-open caller not bound')
    finals={Path(row['path']):row['final_pin'] for row in authority['targets']}
    if len(authority['targets'])!=55 or len(finals)!=55 or finals!={Path(x['target']):x['candidate_pin'] for x in targets}:
        raise ValueError('next-opening final target set changed')
    protected=manifest['protected']
    for item in protected:expected(Path(item['path']),item['pin'])
    changes=[]
    for item in targets:
        target=Path(item['target']);candidate=Path(item['candidate']);candidate.relative_to(OWN/'candidates')
        after=expected(candidate,item['candidate_pin'])
        if item['parent'] is None:
            if not target.is_relative_to(NEW_RUNTIME) or target.exists() or target.is_symlink():raise ValueError('new runtime target no longer absent')
            before=None
        else:before=expected(target,item['parent'])
        changes.append((item,target,before,after))
    if sum(row[2] is None for row in changes)!=50:raise ValueError('only fixed 50 new runtime files may be created')
    # The current original entry is the fifth existing source parent. Reuse
    # its mature process-state function without loading source/business code.
    entry_before=next(before for item,target,before,after in changes if target==ENTRY)
    definitions=[x for x in ast.parse(entry_before).body if isinstance(x,ast.FunctionDef) and x.name=='pid_state']
    if len(definitions)!=1:raise ValueError('original process-state interface changed')
    exec(compile(ast.Module(body=definitions,type_ignores=[]),str(ENTRY),'exec'),globals())
    original_pid=original_main_dead();existing_lock_is_held()
    if NEW_RUNTIME.exists() or NEW_RUNTIME.is_symlink():raise ValueError('independent new runtime root exists')
    directories={path for item,target,before,after in changes if before is None for path in target.parents if path.is_relative_to(NEW_RUNTIME)}
    directories.add(NEW_RUNTIME.parent)
    if directories!={Path(x) for x in manifest['new_runtime_directories']}:raise ValueError('new directory whitelist changed')
    backup_base=PROJECT/'backups/source50-owner';no_link_parent(backup_base);backup_base.mkdir(exist_ok=True)
    backup=backup_base/uuid.uuid4().hex;no_link_parent(backup);backup.mkdir()
    saved=[];temporaries=[];attempted=[];created_dirs=[]
    try:
        for directory in sorted(directories,key=lambda path:(len(path.parts),str(path))):
            no_link_parent(directory)
            if directory.exists() or directory.is_symlink():
                if directory!=NEW_RUNTIME.parent or not directory.is_dir() or directory.is_symlink():raise ValueError('new runtime directory appeared')
                continue
            directory.mkdir();info=directory.lstat();created_dirs.append((directory,info.st_dev,info.st_ino))
        for item,target,before,after in changes:
            path=backup/target.relative_to(WORK)
            if before is not None:
                path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(before);expected(path,item['parent'])
            saved.append({'target':str(target),'backup':str(path) if before is not None else None,'parent':item['parent'],'candidate':item['candidate_pin']})
            temporaries.append(prepared_temp(target,after))
        (backup/'PREPARED.json').write_text(json.dumps(saved,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
        if original_main_dead()!=original_pid:raise ValueError('original main metadata changed')
        existing_lock_is_held()
        for item in protected:expected(Path(item['path']),item['pin'])
        for (item,target,before,after),temporary in zip(changes,temporaries):
            no_link_parent(target);expected(temporary,item['candidate_pin'])
            if before is None:
                if target.exists() or target.is_symlink():raise ValueError('new runtime file appeared before rename')
            else:expected(target,item['parent'])
            attempted.append((item,target,before,after))
            if before is None:os.rename(temporary,target)
            else:os.replace(temporary,target)
            expected(target,item['candidate_pin'])
        for item in protected:expected(Path(item['path']),item['pin'])
        if original_main_dead()!=original_pid:raise ValueError('original main restarted during join')
        existing_lock_is_held()
        result={'schema':'source50_owner_joined_v1','source_batch':50,'approval_sha256':pin(approval_raw)['sha256'],
            'prepared_manifest_pin':pin(blob(PREPARED)),'authority_manifest_pin':pin(authority_raw),'backup':str(backup),'targets':saved,
            'protected':protected,'new_directories':[str(row[0]) for row in created_dirs],
            'App_restarted':False,'marker_changed':False,'customer_database_opened':False,'session_copied':False,
            'deployed':False,'real_GUI_verified':False,'commercial_complete':False}
        receipt_temp=prepared_temp(RECEIPT,(json.dumps(result,ensure_ascii=False,indent=2)+'\n').encode())
        temporaries.append(receipt_temp);os.rename(receipt_temp,RECEIPT)
        print(json.dumps({'source_batch':50,'joined':True,'targets':55,'backup':str(backup)},ensure_ascii=False))
    except BaseException as error:
        rollback=[]
        for item,target,before,after in reversed(attempted):
            try:
                no_link_parent(target);current=blob(target) if target.exists() else None
                if current==before:rollback.append({'target':str(target),'restored':True,'no_change':True});continue
                if current!=after:raise ValueError('foreign target drift; refuse rollback')
                if before is None:target.unlink()
                else:
                    restore=prepared_temp(target,before);temporaries.append(restore)
                    expected(target,item['candidate_pin']);no_link_parent(target);os.replace(restore,target);expected(target,item['parent'])
                rollback.append({'target':str(target),'restored':True})
            except BaseException:rollback.append({'target':str(target),'restored':False})
        # Uncommitted staging files belong to this invocation. Remove them
        # before testing whether this invocation's new directories are empty.
        for temporary in temporaries:temporary.unlink(missing_ok=True)
        cleaned=[]
        for directory,device,inode in reversed(created_dirs):
            try:
                no_link_parent(directory);info=directory.lstat()
                if (info.st_dev,info.st_ino)!=(device,inode) or directory.is_symlink() or getattr(info,'st_file_attributes',0)&0x400:raise ValueError('created directory identity drift')
                # Nonrecursive removal only of this join's same empty directory.
                directory.rmdir();cleaned.append({'path':str(directory),'removed':True})
            except BaseException:cleaned.append({'path':str(directory),'removed':False})
        failure={'failed':True,'source_batch':50,'error_type':type(error).__name__,'backup':str(backup),'rollback':rollback,'new_directory_cleanup':cleaned}
        with FAILED.open('x',encoding='utf-8') as stream:stream.write(json.dumps(failure,ensure_ascii=False,indent=2)+'\n')
        raise
    finally:
        for temporary in temporaries:temporary.unlink(missing_ok=True)

if __name__=='__main__':main()
