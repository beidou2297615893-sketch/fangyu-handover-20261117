# Phase26 唯一原生身份观察 wrapper：独立静审

本次仅静态读 root 自有两个候选及已审 pure guard/host，未导入执行 wrapper、未访问原 DATA/DPAPI、CIM、browser 或网络，未加测试，七份冻结诊断源不改。

首候选 SHA：`phase26_native_developer_observation.py` E150F256C08173F92194F9628F061F7F6A231BFCC0ECF7948A5C7A36DD528A5F。当前修正源已独立读盘核为 **55C5E09F5B3D9672BA2821D2F8A35D1353A484301A9FC6DCCDD916A03B656546**；`phase26_run_native_observation_once.ps1` 24BB60EBF3F2DDD69A941BEA33D2C3D38F0CD0BB49F46F795421CE72D45F12FE、pure guard `phase26_native_developer_preflight.py` 8A595CBF565EDB940EDCCB3D818F4CC64412D19E0641026AF557963B7283232C 均保持。首静审完整副本保存在 `backups/phase26-native-observation-static-review/1`，SHA 48756C92258E607BFD0254D5016A8A748EB0394F9E7D1607776A62FB0A9FF75A；以下首发现保留，不把首版当作修正后的源码。

## 当前静态支持

- 原 account 只由 pure 固定常量派生，不接受前端 owner、路径、账户或旧 ready token。run_id 严格 32 小写 hex；初始 attempt 与最终 target 采用 x 模式，原号不能静默覆盖/重放。一个 scheduler definition 无 trigger，只 Start 一次；current Interactive / Limited、IgnoreNew、7 分钟、固定项目 pythonw / source /工作目录，无自动 retry。
- 导入 pure 只安装父进程 socket.connect 禁止、固定 CIM Popen、readonly immutable SQLite 限制/trace。没有调用 pure.main、Core、Service、Runner 或 CLI。owned native helper 走已审 CreateProcess atomic Job；父 Python 网络 guard 不等于浏览器网页自身网络被禁，也不等于原 profile 零写。
- host.execute 重新 fresh 本人 actor/company/device/UID/任务/runtime/OS profile，并在实际账户锁下核 vacancy；不会把上一预检 ready 当本次授权。Job 清理未确认保留拥有对象和账户锁，正常/异常都没有提交原 CLI 会话、清风险或写任务的链路。
- helper outcome 返回固定安全 code，UID/account 只返回 hash；没有 raw Cookie/凭据/原 process argv。实际开始后的 host 平台请求保持 unknown/null，浏览器/profile may-write 独立。
- 正常回执会比较原 workspace DB、encrypted binding、activity 三项前后 SHA。SQL trace 写计数与 readonly authorizer 是另外证据，不把三文件相同宣称所有 DATA 完整零写。owned work/lock/profile 写不在该三项范围。

## 首候选需收敛的一项结果边界

`observation.py` 首候选 line58–60 初始 result 写 browser_started=false / platform_requests_started=false。若进入 host.execute 后出现未返回可信 host result 的异常（例如 finally lock release），或 complete_owned_shutdown 异常，line83–84 只改 state/reason；可能保留初始 false，无法排除 child 曾恢复执行。同时 tracked 三项只在正常 try 路径投影，错误路径没有完整 true/false/null 状态。

已向 root 提出最小修正：记录 host_entered；进入后缺可信 result 的异常将 browser/platform 设 unknown/null，未进入时才可保留 false；finally 尽可能比较已采集 tracked 文件，未知写 null，owned shutdown 未确认不宣称锁已释放。只改 root wrapper，不触七源或平台授权。无需增加测试或真实执行来定位此静态分支。

## 当前最小修正复核

当前 `observation.py` line77–81 在 execute 调用前设置 host_entered，并立即将 browser_started / platform_requests_started 设为 null。只有 host 返回的可信结果能重新给出确定值；未返回可信结果的异常不会残留初始 false。line86–91 仅在已进入 host 时收束 owned Job，清理失败明确 blocked / owned_shutdown_unconfirmed，不声称未启动。该首发现已静态闭合。

line92–110 在 finally 比较已成功记录的 DB、binding 和 activity。任何已知差异使总状态 false；只有两部分都 true 才 true；缺失或读取失败为 null，且进入 host 后不允许 null 被当作通过。owned_lock_released 直接依据 host._held_lock 当前状态，不用浏览器退出推导。未进入 host 的固定环境/快照失败仍可表明本次未启动；结果保存用 x 模式，不覆盖旧 attempt。

本次仅源码与哈希检查，没有导入 wrapper、运行测试、启动程序、读原 DATA/DPAPI、CIM 或清理任务。V3 manifest 所列七份诊断源 7/7 当前 SHA 相符，均未修改。host 的未确认清理可继续持锁等待，若 Scheduler 达到 7 分钟限制结束父进程，则原 attempt 可能没有最终结果；这种情况必须保留未知，不重用旧 ready 或自动重试。父 Job 机制已有独立 benign OS 样例，但本静审没有运行该样例，也不能把它换成原账号恢复证据。

## 既有 V3 预检任务的清理界限

root 所述 V3 run_id 为 `7d7c268a73454dd48d5c14df100d33d5`。D 未读取实时 Scheduler 状态。root 清理前需精确核 `\\方隅工作台\\` 下 `客户版Phase26开发诊断预检-<该GUID>` 的固定 pythonw、preflight 脚本、--run-id、项目工作目录、当前 Interactive / Limited 主体、零 trigger、Ready 及本次 LastTaskResult=0，随后仅注销该 GUID 并保存回执。无需 Start/Stop、重跑诊断或操作其他任务。旧 `phase26-native-developer-preflight-owned-task-cleanup.json` 属于 ccb0cb... 首预检，不能用于证明 V3 清理完成。

未见当前 Scheduler/固定身份/旧 ready 复用上的新阻断。总目标、原账号观察、会话恢复和真实采集仍未由这次静审证明；单次原生执行及安全收尾继续由 root 执行，浏览器自然 profile 写和平台请求未知必须如实保留。
