# 来源发现公司渠道：最小增量选型

2026-10-10，仅本项目。先只读最新R01—R25台账、phase-8真实经营核对云/本机/界面，以及ContactJournal、contact/handoff/index源码；再由root明确批准小样实现。phase-8 269后台/181前端/14源GUI是root归档的旧阶段证据，不能计算为本发现功能的测试。冻结规则/原库/平台/云部署/付款/真实角色不在此切片。

本轮目录判断后使用已读取的RevOps“先定义生命周期、量化交接证据、复用系统记录”原则。付费广告 attribution-reconciler 的GA4订单去重不适合这里的自然评论来源发现，未套用它的付费模型或请求用户补广告导出。实际复用项目成熟 repo/SDK；已安装 CloudBase node-sdk 3.18.3 package 指定MIT、dist入口，项目Node>=20，无新第三方包或CRM。

## 选择与商业作用

当前经营核对要填67字符hc_编号，会让本人把时间用在搬编号而不是跟进客户，也影响总部演示。推荐一个按钮“查找对应公司交接”，服务端派生有权不可变来源，显示可识别的接收方/公司阶段/登记时间/授权状态；用户明确选择一条再用原detail完整核验。即使唯一候选也不自动绑定、创建、发送或确认到账。完整编号留高级折叠入口，不从手机号、昵称、相近时间或金额猜配。

现cloud注册只写 all/source:SHA(username)/recipient 索引（50项一页），没有 source_event_id 专属索引。active:customer是当前占用，不覆盖历史或同源多渠道。原list能分页，但publicItem包含裸平台UID/联系引用且一次只能按owner列，不应直接交给新UI或把普通接收人当source。root批准新独立 channel_candidates helper，使用现repo与server-only readBoundItem，有界扫描本人的owned索引；不会注册、新写索引或读时迁移。

默认倒序，从owned索引尾部找近期渠道；scan_offset表示已检查行数，scan<=10、output<=5。第5候选即停止，next_offset按实际读过行数计算，不吞掉第6匹配。初期少量自用可少点少填；大量历史最坏仍O(本人渠道数)，不声称万级即时索引。将来新source索引/有权历史迁移另审批，不能在本只读切片静默加入。

## 本机来源与权限

本机只有当前cloud_bound来源本人能发现，不是所有可读handoff（admin/receiver本身能看他人的handoff）。复用经营bridge _snapshot/_owned_event 的tenant/owner/current lead/source hash/审计/ContactJournal链/当前设备和首尾身份检查。demo/错owner/缺UID/comment/当前原文改变/坏链先拒，不能发送任意前端event、owner或trusted bool。

从当前原lead完整事件派生降序最多5条，不限定latest sent或仅有ACK的记录：旧reviewed/unknown等事件可能先用于register；ACK丢失也可能云已保存。同事件记录存量metadata核验，没有正文/密钥进新元数据。首来源窗省略source_before_sequence；返回稳定exclusive anchor=窗首sequence+1，下一窗before=窗末sequence；同窗翻云页带anchor+expected窗口digest+expectedownedcount，新追加事件不漂移旧窗，另提示has_newer_local_events。更多旧事件有has_more，不因首5个空声称全无渠道。真正本机事件检索/运行时能力由D实现并单独证明，不把本设计当完成。

本机最初draft列独立参数，随后root/D锁定更小客户端合同：action `business_reconciliation_candidates` 只接受 `{handoff_id,cursor?}`。cursor严格含version/稳定exclusive anchor/digest/index_count/scan_offset/scope_fingerprint，由server重算校验，扫描大小固定<=10；上述scope字段不从client当作授权。它是可重算约束，不是签名或服务端扫描履历。来源窗口/actor/device/company/lead/handoff或原记录变动，拒旧结果；不在SQL锁/事务内等待HTTP。

## 已锁云协议候选

严格cloud action `acquisition_channel_candidates`，只有 environment_id/operation/sources/source_window_digest/scan_offset/scan_limit/expected_owned_index_count。sources为1—5个唯一 `{event_id,payload_hash}`，来自本机server核验；source_window_digest是按event_id排序的上述数组canonical SHA256。offset默认0，limit默认10上限10；offset>0必须带上次owned_index_count且与当前一致。源缺、角色或环境不读时不当作无限或空成功。

先逐一检查已存event同当前session actor、device_report、stored fingerprint、canonical六字段+可选intent_snapshot的payload_hash、真实customer平台/UID对应。missing record单列not_recorded，继续其他旧已记录源；wrongowner/hash/company/格式冲突整批拒，不泄漏他人事件。ACK不是此证明依据。缓存本次<=5个event/customer后，候选item必须同source_event/owner/customer/device/platform/UID/comment/lead/text hash；currentconsent核withdrawal ledger。撤回/争议候选仍可历史只读，不能为“当前不同意”假造无记录。

标准fangyu-workspace-v1 envelope里 `data.discovery`：

```text
contract = business_channel_discovery_v1
read_only = true; storage_scope = company_server_ledger
observed_at; authenticated_actor; source_window_digest
source_results = [{event_id,payload_hash,status:recorded|not_recorded,
                   source:phase8_SOURCE_FIELDS|null}]
scan = {direction:newest_first,
        status:partial|complete|index_unavailable|no_cloud_sources,
        owned_index_count:int|null, offset,scanned_count,limit,
        next_offset:int|null,complete:bool}
candidates = [{channel:phase8_exact_CHANNEL_FIELDS,
               recipient_name:safe_string,created_at:int,updated_at:int}]
local_cloud_handoff_correspondence_verified = false
financial_receipt_verified = false; cooperation_policy_verified = false
verified_cash_cents = null; verified_paid_commission_cents = null
```

source/channel复用phase8字段约束，不返回裸UID、原文、reply/sender、联系方式、consent/evidence refs、私有规则或凭据；接收方展示名来自真实已存snapshot并经隐私过滤，不接受client名字。cloud source_owner与authenticated_actor都须本人；本机再核当前device/owned原event/hash，投影出供UI的短编号/日期/阶段/接收方。发现相符始终不是exact本机handoff对应回执或送达。用户选择后原detail从选中channel/source再验，不能保存成已认证映射。

首尾实际actor/session/disabled/company可见性与源/索引count都要复核。初始SDK估算44+末尾复核5候选15=59；实际实现另外重读ownedmeta1，最坏已测60read/0write（前置service另1read），是5source/10scan/5output/跨50页双callback replay的本地SDK夹具计数。它不是实际云30秒性能证明；源/角色最末await后还要复核principal，不因读到5条就提前返回。

## 空态、错误与验收小样

缺本机完整证据：“当前本机证据不足，无法查找”；云缺来源：“本轮来源尚无可读取公司归档”；index缺失：“公司渠道索引尚不可核对”；bounded还未到末页：“本页范围未找到，可继续查找”；到末页：“已到当前索引末页”或“当前末页未找到”；仍有旧本机来源另提示“仍有更早来源可查”。`scan.complete/status=complete`仅表示offset+scanned_count到了当前索引末页：因为cursor不是签名扫描履历，不能据此宣称前面的所有页已经实际查询或整个来源窗口无候选。不用“未发送/未交接/未成交”，不诱导再注册或补发。无法连接、权限变或历史坏链显示安全错误，不能转空清单。

候选显示本人同源公司阶段/创建时间/当前授权/历史接收，撤回留历史；多个同源渠道必须供人选择，不能自动最新。高级编号入口可继续严格原detail，不能绕过新候选权限。

代表性小样先验证：旧reviewed建channel而新sent不对应；无ACK但云存源；新localevent不漂移稳定anchor；目标在第11扫描行；6匹配第6不漏；owned索引append改变count拒旧页；当前角色/disabled/device/company/source变化；跨owner/错hash/index孔洞/审计缺失；撤回仍可历史、0候选分层；actualSDK最大5sources/10scan/5output/跨50页双replay及全库不写；实际cloud标准envelope→实际Core同event→本机发现→用户选→原detail。都是拟验收项，须新增执行证据后才能写通过。

实施范围：B新增cloud/channel_candidates.cjs及专项/候选夹具，service窄route（编辑前备份）。D新增本机发现纯读模块及专项，root做gateway/UI入口；不修改phase8业务helper/handoff/contact/index或冻结AI/政策/原库。本计划与parent批准仅授权本地源码/夹具，不授权真实云/模型/平台/账户或部署。
