'use strict';
// Independent actual index.main / createService / createStore boundary.
// Only CloudBase storage and official KMS request I/O are RAM doubles.
const assert=require('node:assert/strict'),crypto=require('node:crypto');
const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const {createRequire}=require('node:module');
const Module=require('node:module');
const CLOUD=path.resolve(__dirname,'../../cloud/workspace');
const requireCloud=createRequire(path.join(CLOUD,'package.json'));
const sdk=requireCloud('tencentcloud-sdk-nodejs-kms');
const sdkPackage=requireCloud('tencentcloud-sdk-nodejs-kms/package.json');
const SDK_PATH=requireCloud.resolve('tencentcloud-sdk-nodejs-kms');
const COMPANY='fangyu-apartment-client',ENVIRONMENT='phase30-independent-synthetic-env';
const PASSWORD='[REDACTED:assigned_secret]';
const PUBLISH='acquisition_contact_publish',REVEAL='acquisition_contact_reveal';
const WITHDRAW='acquisition_contact_withdraw',STATUS='acquisition_contact_operation_status';
const sha=value=>crypto.createHash('sha256').update(typeof value==='string'?value:JSON.stringify(value)).digest('hex');
const evidence=[];
let serial=0,sdkLoads=0;
const controllers=new Map(),originalLoad=Module._load;
Module._load=function(name,...args){
 if(name==='tencentcloud-sdk-nodejs-kms'||name==='tencentcloud-sdk-nodejs-kms/package.json')sdkLoads++;
 return originalLoad.call(this,name,...args);
};
// No network transport can be used, including an accidental fallback around request().
for(const name of ['node:http','node:https'])require(name).request=()=>{throw Error('PHASE30_NETWORK_FORBIDDEN');};
require('node:net').Socket.prototype.connect=()=>{throw Error('PHASE30_NETWORK_FORBIDDEN');};
global.fetch=()=>{throw Error('PHASE30_NETWORK_FORBIDDEN');};
const Client=sdk.kms.v20190118.Client,originalRequest=Client.prototype.request;
Client.prototype.request=async function(action,params){
 const controller=controllers.get(this.credential.secretId);
 assert.ok(controller,'only isolated synthetic credentials may enter KMS request double');
 assert.equal(controller.data.depth(),0,'KMS must run outside every replayed transaction callback');
 assert.ok(['Encrypt','Decrypt'].includes(action));
 assert.equal(this.endpoint,'kms.tencentcloudapi.com');
 assert.equal(this.profile.httpProfile.protocol,'https://');
 assert.equal(this.profile.httpProfile.reqMethod,'POST');
 assert.equal(this.profile.httpProfile.reqTimeout,10);
 const context=JSON.parse(params.EncryptionContext);
 assert.equal(context.company,COMPANY);assert.equal(context.environment,ENVIRONMENT);
 controller.counts[action]++;
 controller.requests.push({action,key_id_hash:sha(params.KeyId||''),context:structuredClone(context)});
 if(controller.hook)await controller.hook(action);
 if(action==='Encrypt'){
  assert.equal(params.KeyId,controller.environment.CONTACT_KMS_KEY_ID);
  const handle='phase30-opaque-'+crypto.randomUUID();
  controller.opaque.set(handle,{plaintext:params.Plaintext,context:params.EncryptionContext});
  return {KeyId:controller.environment.CONTACT_KMS_KEY_ID,CiphertextBlob:handle};
 }
 const saved=controller.opaque.get(params.CiphertextBlob);assert.ok(saved,'opaque RAM handle must exist');
 assert.equal(params.EncryptionContext,saved.context);
 return {KeyId:controller.environment.CONTACT_KMS_KEY_ID,Plaintext:saved.plaintext};
};
function validEnvironment(){
 return {TCB_ENV:ENVIRONMENT,COMPANY_ID:COMPANY,INITIAL_ADMIN_USERNAME:'phase30-admin',INITIAL_ADMIN_PASSWORD:PASSWORD,
  CONTACT_KMS_REGION:'ap-shanghai',CONTACT_KMS_KEY_ID:'phase30-independent-key-only',
  CONTACT_KMS_SECRET_ID:'phase30-independent-secret-id-'+(++serial),
  CONTACT_KMS_SECRET_KEY:'phase30-independent-secret-key-only',
  CONTACT_KMS_TOKEN:'phase30-independent-sts-token-only',CONTACT_RETENTION_SECONDS:'86400'};
}
function withoutContact(environment){
 return Object.fromEntries(Object.entries(environment).filter(([key])=>!key.startsWith('CONTACT_KMS_')&&!key.startsWith('CONTACT_RETENTION_')));
}
function memory(){
 let documents=new Map(),queue=Promise.resolve(),depth=0,operations=[],loseFinish=false;
 const copy=map=>new Map([...map].map(([key,value])=>[key,structuredClone(value)]));
 const transaction=(map,count)=>({collection:name=>({doc:id=>({
  async get(){count.reads++;return {data:map.has(name+'/'+id)?structuredClone(map.get(name+'/'+id)):[]};},
  async set(value){count.writes++;map.set(name+'/'+id,structuredClone(value));}
 })})});
 const invoke=async(callback,map,count)=>{depth++;try{return await callback(transaction(map,count));}finally{depth--;}};
 const db={runTransaction(callback){
  const pending=queue.then(async()=>{
   const first={reads:0,writes:0},second={reads:0,writes:0};
   try{
    // Deliberately replay each callback; only the second successful stage commits.
    await invoke(callback,copy(documents),first);
    const stage=copy(documents),result=await invoke(callback,stage,second);
    documents=stage;
    if(loseFinish&&result?.delivery?.original_execution_confirmed===true&&result?.read_only===false){
     loseFinish=false;throw Error('PHASE30_SYNTHETIC_COMMITTED_REPLY_LOST');
    }
    return result;
   }finally{operations.push([first,second]);}
  });queue=pending.catch(()=>{});return pending;
 }};
 return {db,depth:()=>depth,snapshot:()=>JSON.stringify([...documents]),docs:()=>copy(documents),
  reset:()=>{operations=[];},operations:()=>structuredClone(operations),
  state:()=>structuredClone(documents.get('fangyu_workspace_private/'+COMPANY)?.state),
  mutateState(fn){const key='fangyu_workspace_private/'+COMPANY,value=structuredClone(documents.get(key));fn(value.state);documents.set(key,value);},
  mutateDoc(key,fn){documents.set(key,fn(structuredClone(documents.get(key))));},
  loseNextFinish:()=>{loseFinish=true;}};
}
function boot(environment,data,{configurationOverride=null}={}){
 const logs=[];let init=0;
 const context={exports:{},Buffer,Date,process:{env:{...environment}},console:{error:(...items)=>logs.push(items.join(' '))}};
 context.require=name=>{
  if(name==='@cloudbase/node-sdk')return {init(options){
   assert.equal(options.env,ENVIRONMENT);assert.ok(!Object.hasOwn(options,'accessKey'));
   init++;return {database:()=>data.db};
  }};
  if(name==='./release.cjs')return {releaseState:()=>requireCloud(name).releaseState(context.process.env)};
  if(name==='./contact_delivery_config.cjs'&&configurationOverride)return {...requireCloud(name),contactDeliveryOptionsFromEnvironment:configurationOverride};
  return requireCloud(name);
 };
 vm.runInNewContext(fs.readFileSync(path.join(CLOUD,'index.js'),'utf8'),context,{filename:path.join(CLOUD,'index.js')});
 return {context,logs,get init(){return init;},async raw(payload,token=''){
  const output=await context.exports.main({httpMethod:'POST',body:JSON.stringify(payload),headers:{Authorization:'Bearer '+token}});
  assert.equal(output.headers['Cache-Control'],'no-store');
  return {status:output.statusCode,data:JSON.parse(output.body)};
 }};
}
async function fixture(){
 const environment=validEnvironment(),data=memory();
 const controller={environment:{...environment},data,counts:{Encrypt:0,Decrypt:0},requests:[],opaque:new Map(),hook:null};
 controllers.set(environment.CONTACT_KMS_SECRET_ID,controller);
 let running=boot(environment,data),item=null;
 const tokens={},devices={admin:'phase30-admin-device',source:'phase30-source-device',resource:'phase30-resource-device',outsider:'phase30-outsider-device'};
 const usernames={admin:'phase30-admin',source:'phase30-source',resource:'phase30-resource',outsider:'phase30-outsider'};
 const raw=(payload,token)=>running.raw(payload,token);
 const call=(operation,body={},actor='source')=>raw({environment_id:ENVIRONMENT,operation,
  ...(operation.startsWith('acquisition_contact_')?{expected_device_id:devices[actor],channel_id:item?.channel_id}:{}),...body},tokens[actor]||'');
 const login=async actor=>{
  const result=await call('login',{username:usernames[actor],password:PASSWORD,remember_device:true,device_id:devices[actor]});
  assert.equal(result.status,200,'synthetic login through real index.main must succeed');tokens[actor]=result.data.token;
 };
 await login('admin');
 for(const actor of ['source','resource','outsider']){
  assert.equal((await call('member_save',{username:usernames[actor],password:PASSWORD,role:'operator'},'admin')).status,200);
  await login(actor);
 }
 data.mutateState(state=>{
  state.acquisitionPolicy={recipients:[{id:'phase30-resources',name:'合成资源部'}],receivers:{[usernames.resource]:['phase30-resources']},managers:[]};
  state.devices=Object.entries(devices).map(([actor,id])=>({id,owner:usernames[actor],digest:sha('phase30-device-token-'+actor),revoked:false}));
  state.xhs_claims=[{device_id:devices.source,account_id:'phase30-synthetic-xhs-account',uid_hash:sha('phase30-synthetic-sender')}];
 });
 const stamp=Math.floor(Date.now()/1000),uid='phase30-customer-'+crypto.randomUUID();
 const start={event_id:crypto.randomUUID(),kind:'send_started',occurred_at:stamp-20,
  lead:{id:'phase30-lead-'+uid,platform:'xiaohongshu',author_id:uid,author:'合成客户',text:'合成公寓咨询原评论',
   note_url:'https://www.xiaohongshu.com/explore/phase30-synthetic-post',author_avatar_url:'',task_id:'phase30-task',
   comment_id:'phase30-comment-'+uid,parent_id:'',source_keyword:'公寓'},
  reply:{id:'phase30-reply-'+uid,text:'合成咨询回复'},sender:{account_id:'phase30-synthetic-xhs-account',nickname:'合成来源'}};
 const sent={...structuredClone(start),event_id:crypto.randomUUID(),kind:'sent',occurred_at:stamp-10};
 const sync=await raw({environment_id:ENVIRONMENT,operation:'contact_events_sync',events:[start,sent]},'phase30-device-token-source');
 assert.equal(sync.status,200,'actual contact ledger must persist synthetic original event');
 const consent={status:'granted',evidence_reference:'consent:'+crypto.randomUUID().replaceAll('-',''),notice_version:'phase30-v1'};
 const registered=await call('acquisition_channel_register',{source_event_id:sent.event_id,recipient_id:'phase30-resources',purpose:'合成租房咨询承接',
  qualification:'qualified',consent,idempotency_key:'phase30-register-'+crypto.randomUUID()});
 assert.equal(registered.status,200,'actual handoff ledger must register persisted original source');
 const submitted=await call('acquisition_handoff_submit',{channel_id:registered.data.item.channel_id,expected_revision:registered.data.item.revision,idempotency_key:'phase30-submit-'+crypto.randomUUID()});
 assert.equal(submitted.status,200);item=submitted.data.item;
 const values={phone:'[REDACTED:phone_cn]',wechat:'phase30SyntheticCustomer'};
 const version=crypto.randomBytes(16).toString('hex')+'_1';
 const publishBody={expected_revision:item.revision,contact_version:version,consent_reference:consent.evidence_reference,
  notice_version:consent.notice_version,idempotency_key:'phase30-original-publish',...values};
 const revealBody={expected_revision:item.revision,contact_version:version,expected_contact_revision:1,idempotency_key:'phase30-original-reveal'};
 return {data,environment,controller,values,item,tokens,devices,usernames,publishBody,revealBody,raw,call,
  get running(){return running;},counts:()=>structuredClone(controller.counts),
  restart(next=environment,options){running=boot(next,data,options);return running;},
  hook:fn=>{controller.hook=fn;},
  status:(action,key,actor='source')=>call(STATUS,{operation_action:action,idempotency_key:key},actor),
  handoffWithdraw:()=>call('acquisition_handoff_withdraw',{channel_id:item.channel_id,expected_revision:item.revision,
   idempotency_key:'phase30-explicit-handoff-withdraw',reason_code:'customer_withdrew'}),
  loseNextFinish:data.loseNextFinish};
}
function readOnly(f,run){
 const before=f.data.snapshot(),counts=f.counts();f.data.reset();
 return Promise.resolve().then(run).then(result=>{
  assert.equal(f.data.snapshot(),before,'all synthetic company documents must stay byte-equivalent');
  for(const pair of f.data.operations())for(const callback of pair)assert.equal(callback.writes,0,'every SDK-interface replay must have zero DML');
  assert.deepEqual(f.counts(),counts,'metadata/fail-closed operation must not call KMS');
  return {result,before_hash:sha(before),after_hash:sha(f.data.snapshot()),operations:f.data.operations(),kms_delta:{Encrypt:0,Decrypt:0}};
 });
}
function note(label,observation){evidence.push({label,...observation});}
function assertNoStoredValues(f,...receipts){
 const encoded=JSON.stringify({documents:[...f.data.docs()],receipts,logs:f.running.logs});
 for(const value of Object.values(f.values)){
  assert.ok(!encoded.includes(value),'plaintext must not enter persistent documents or metadata receipts');
  assert.ok(!encoded.includes(sha(value)),'plaintext hashes must not be persistent contact metadata');
 }
 assert.ok(!encoded.includes('PHASE30_RAW_KMS_ERROR'));
}
function flushEvidence(){
 Module._load=originalLoad;Client.prototype.request=originalRequest;
 const target=process.env.PHASE30_INDEPENDENT_EVIDENCE;
 if(target)fs.writeFileSync(target,JSON.stringify({contract:'phase30_contact_bootstrap_independent_evidence_v1',
  synthetic_only:true,actual_index_main:true,actual_service_store:true,company_id:COMPANY,environment_id:ENVIRONMENT,
  official_project_sdk_path:SDK_PATH,official_project_sdk_version:sdkPackage.version,
  live_kms_verified:false,iam_permissions_verified:false,physical_two_machine_verified:false,cloudbase_engine_verified:false,
  crypto_boundary:'official Client.request opaque RAM double',observations:evidence},null,2)+'\n',{flag:'wx'});
}
module.exports={fixture,boot,memory,readOnly,note,assertNoStoredValues,flushEvidence,validEnvironment,withoutContact,
 config:()=>requireCloud('./contact_delivery_config.cjs'),sdkLoads:()=>sdkLoads,COMPANY,ENVIRONMENT,CLOUD,requireCloud,PUBLISH,REVEAL,WITHDRAW,STATUS};
