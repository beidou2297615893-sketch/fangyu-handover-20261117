# 交接客户名称：只读投影与边界验证

日期：2026-10-10。实施与独审：commercial_product_audit。只改独占本机 backend acquisition_operations.py、测试和报告；前端由 readonly_baseline 仅接显示字段。没有写真实数据、调整真实角色、调用平台、联网或部署云服务，暂不打包。

## 结果与业务意义

交接列表现在可显示 `customer_display_name`，使本人和授权资源接收人能识别大量记录对应的客户。它是当前可授权读取的公开昵称，不是新的身份凭证、客户同意、资源送达或成交事实。同名客户仍由既有来源 ID / 交接编号及详情区分。

字段可缺省。`_public` 先清除副本中的同名字段，再从可信数据库读取；不会信任请求名或历史快照中的同名字段。原 lead、handoff、revision、consent、receipt、事件/hashchain、权限和授权状态均不改。当前联系方式撤回不抹除历史 ACK，也不因仍有显示名称恢复交付权限。

## 可信条件

1. 当前 actor 必须重新匹配持久 user 的租户、username、role、cloud_bound 和启用状态，且 `_can_view` 允许访问该企业、owner 或可信接收部门的交接。
2. 来源本人继续通过原 `_lead` / `lead_access`；接收人只按持久接收权限读取来源元数据，不冒充来源员工或获得 vault reveal。
3. 以 item.lead_id 查询原 lead。其 id、tenant_id、cloud_owner 必须严格与交接绑定一致；platform、author_id 必须非空字符串并与持久 source 完全一致。legacy 空 owner、来源变化、demo、不存在均不给名称。
4. 仅使用原 lead.author 的短字符串；不以正文、联系方式、前端输入或 UID 代替昵称。空、非字符串、超160字、NUL、联系方式/密钥标记或规范化后7位以上连续数字不提供字段。此为保守显示规则，默认名称承接无名状态。

所有姓名处理仅在现有 SQLite 读事务中完成，不写记录或日志；通用 product receipts 的既有保护投影不纳入自由文本名称，核对后仍需读当前详情。

## 验证

新增恰好4个运营边界测试（使用 subTest 覆盖变体）：

|用例|代表证据|
|---|---|
|当前可信昵称|本人和独立接收人 list/detail 显示当前原 lead.author；同一稳定来源改昵称后读到新名；全部 records 前后逐行相同，handoff/events 未持久名称，正文和手机不输出|
|权限|无 actor、无收件权限、伪造 admin、异租户、伪造 username、失效接收人及来源 lead_access 拒绝时不给名称|
|来源|tenant、owner（含空owner）、platform、UID、demo、缺失lead、错误绑定id/企业/租户不给名称|
|输入与隐私|请求伪造 author/customer_display_name 被拒；空/非字符串/长/NUL/电话式数字/微信标记/密钥式昵称不给名称；副本中的伪造旧名被清除|

既有真实双 gateway 用例补充：独立资源接收 executor 的 list/detail 得到可信昵称，仍不返回来源正文或电话号码，接收权限与其他2项越权用例保持。

最终必要后台联合 **94/94 通过**（9.249秒）：ops50 + product receipts16 + 双gateway3 + root DPAPI contacts12 + root product gateway13。全部写只在临时 fixture。复跑命令（项目目录内；Python路径仅本次子进程）：

```powershell
$env:PYTHONPATH = 'C:\积木软件工坊\项目\方隅公寓客户版\work\app\src;C:\积木软件工坊\项目\方隅公寓客户版\work\app\tests'
python -m unittest test_acquisition_operations test_product_receipts test_operations_gateway test_acquisition_contacts test_product_workspace
```

前端只在 shell 实际 renderHandoffs 的 identity strong 读取此字段并使用原 textContent helper。独立执行磁盘源码的轻量 DOM 单项通过：昵称优先、无名“已保存客户”、无来源“客户身份待核对”、HTML式昵称为纯文字而不创建 img、来源UID不出现在行文字、不发读写请求、不跳标签。定向复跑：

```powershell
node --test --test-name-pattern=customer_display_name work/product-upgrade-20261009/audits/ui-flow-independent.test.mjs
```

此前第7冻结的97项（48+49）和实际IAB完整重开场景留证仍独立保留。本轮只定向执行新增1项，文件现有50个定义；**没有重跑98全量，也不宣称98全量通过**。新增昵称在实际浏览器的第8验收由 root 执行；本子任务没有替代真实GUI、用户审美或真实获客验收。

## 固定版本

源码前备份：`C:\积木软件工坊\项目\方隅公寓客户版\work\product-upgrade-20261009\backups\acquisition-display-name-r1`。原ops SHA BC314393E896CB50A70F1A246C6B0DE1433F3EAEB81B8287C3F4A3467DA28A4A。

|文件|最终SHA256|
|---|---|
|acquisition_operations.py|BAD9D108620E11EEFF55AEBAB03D583ED50B84B85561090F68F33D62C7B0EF2D|
|test_acquisition_operations.py|730A81849C7CC63DBB852DBC688E8C985C940E46A880BDFCD92BCF9E9BB2C4C3|
|test_operations_gateway.py|2FC11EDD7784A2E0C6F7230CB7F9DF0E9A41B732B65F67604E2F304A6C6F7EAE|
|upgrade-shell.mjs（实施者生产源，本子任务只读）|298AC5F2B7A6B3CD3873C93397B81732D5ED58B3901BC19AB723F85C5B875F6E|
|ui-flow-independent.test.mjs|A586AD4C26C46502E258CD5CED0D9A0EDCCB00EE57DF22546C8F5C900D12B785|

文件：[customer-display-name-projection.md](C:/积木软件工坊/项目/方隅公寓客户版/work/product-upgrade-20261009/audits/customer-display-name-projection.md)。所在文件夹：`C:\积木软件工坊\项目\方隅公寓客户版\work\product-upgrade-20261009\audits`。
