"""Narrow local product operations; reuses authenticated employee/device ownership.

These operations do not invoke a platform adapter, send to an external recipient,
grant a cloud role, change a release policy or claim cross-machine delivery.
"""
import json

from core import CoreError


OPERATION_ACTIONS = frozenset({'acquisition_overview', 'handoff_list', 'handoff_detail',
    'handoff_create', 'handoff_update', 'handoff_submit', 'handoff_receipt', 'attribution_case_list'})
STRATEGY_ACTIONS = frozenset({'strategy_get', 'strategy_save', 'strategy_import',
    'strategy_preview_batch', 'capability_catalog', 'strategy_task_create', 'strategy_task_get', 'strategy_task_status'})
CONTACT_ACTIONS = frozenset({'contact_create', 'contact_read', 'contact_revoke'})
EXPORT_ACTIONS = frozenset({'handoff_export'})
RULE_ACTIONS = frozenset({'intent_rules_get', 'intent_rules_save', 'intent_rules_history', 'intent_rules_preview'})
PLATFORM_READ_ACTIONS = frozenset({'platform_read_search', 'platform_read_comments', 'platform_read_content',
                                  'platform_read_status', 'platform_read_cancel'})
PLATFORM_ARCHIVE_ACTIONS = frozenset({'platform_read_archive', 'platform_read_archive_status'})
AI_READ_ACTIONS = frozenset({'ai_attempt_list', 'ai_attempt_status'})
QUALITY_ACTIONS = frozenset({'intent_quality_batch_create', 'intent_quality_batch_list',
    'intent_quality_batch_get', 'intent_quality_label', 'intent_quality_summary', 'intent_quality_operation_status'})
COMPANY_POLICY_ACTIONS = frozenset({'intent_policy_read', 'intent_policy_publish', 'intent_policy_publish_status'})
BUSINESS_READ_ACTIONS = frozenset({'business_reconciliation_detail', 'business_reconciliation_candidates'})
SELF_WORKLIST_ACTIONS = frozenset({'self_worklist_get'})
SELF_DAILY_EVIDENCE_ACTIONS = frozenset({'self_daily_evidence_summary'})
ACQUISITION_PREFLIGHT_ACTIONS = frozenset({'acquisition_run_preflight'})
COMPANY_PREPARATION_ACTIONS = frozenset({'company_handoff_prepare', 'company_handoff_preparation_get'})
COMPANY_ORIGINAL_STATUS_ACTIONS = frozenset({'company_handoff_original_status'})
COMPANY_SOURCE_BINDING_ACTIONS = frozenset({'company_handoff_source_binding_get'})
COMPANY_REGISTRATION_ACTIONS = frozenset({'company_handoff_register', 'company_handoff_registration_get'})
COMPANY_CHANNEL_CHECK_ACTIONS = frozenset({'company_handoff_channel_check_get'})
COMPANY_SUBMISSION_ACTIONS = frozenset({'company_handoff_submit', 'company_handoff_submission_get'})
COMPANY_RECEIVER_ACTIONS = frozenset({'company_handoff_received_list', 'company_handoff_received_detail',
    'company_handoff_receipt', 'company_handoff_receipt_get'})
COMPANY_CONTACT_DELIVERY_ACTIONS = frozenset({'company_contact_publish', 'company_contact_reveal',
    'company_contact_withdraw', 'company_contact_operation_get'})
PRODUCT_ACTIONS = (OPERATION_ACTIONS | STRATEGY_ACTIONS | CONTACT_ACTIONS | EXPORT_ACTIONS
                   | RULE_ACTIONS | PLATFORM_READ_ACTIONS | PLATFORM_ARCHIVE_ACTIONS | AI_READ_ACTIONS
                   | QUALITY_ACTIONS | COMPANY_POLICY_ACTIONS | BUSINESS_READ_ACTIONS | SELF_WORKLIST_ACTIONS | SELF_DAILY_EVIDENCE_ACTIONS | ACQUISITION_PREFLIGHT_ACTIONS
                   | COMPANY_PREPARATION_ACTIONS | COMPANY_ORIGINAL_STATUS_ACTIONS | COMPANY_SOURCE_BINDING_ACTIONS | COMPANY_REGISTRATION_ACTIONS | COMPANY_CHANNEL_CHECK_ACTIONS | COMPANY_SUBMISSION_ACTIONS | COMPANY_RECEIVER_ACTIONS | COMPANY_CONTACT_DELIVERY_ACTIONS
                   | {'entitlement_summary', 'acquisition_operation_status'})
RECEIPT_ACTIONS = frozenset({'handoff_create', 'handoff_update', 'handoff_submit',
    'handoff_receipt', 'contact_create', 'strategy_save', 'strategy_import', 'intent_rules_save'})


def dispatch(server, user, action, data):
    from .employee_workspace import WorkspaceError
    try:
        return _dispatch(server, user, action, data)
    except WorkspaceError as exc:
        # Validation/authorization failures occur before service execution. A
        # possibly committed service error explicitly marks its outcome unknown.
        if not getattr(exc, '_product_execution_started', False):
            exc.mutation_committed = False
        raise


def _dispatch(server, user, action, data):
    from .employee_workspace import WorkspaceError, require_owner, public
    if action not in PRODUCT_ACTIONS or not isinstance(data, dict):
        raise WorkspaceError('不支持此产品操作', 403)
    if (not isinstance(user, dict) or user.get('role') not in ('operator', 'admin')
            or user.get('cloud_bound') is not True or user.get('development_local_only') is True):
        raise WorkspaceError('产品操作需要有效的已绑定员工身份', 403)
    try:
        encoded = json.dumps(data, ensure_ascii=False, allow_nan=False).encode('utf-8')
    except (ValueError, TypeError):
        raise WorkspaceError('产品操作参数无效', 403) from None
    if len(encoded) > 1000000:
        raise WorkspaceError('本批数据过大，请分批导入', 413)
    own = require_owner(server, user)
    assistant = server.assistant_service
    with assistant.lock:
        executor, state, device = assistant.executor, assistant.state, dict(assistant.device or {})
    if (state not in ('online', 'held') or executor is None
            or device.get('id') != own['device_id'] or device.get('owner') != user['username']
            or executor.owner != user['username'] or executor.tenant != user['tenant_id']):
        raise WorkspaceError('当前电脑或员工归属尚未确认，请刷新连接状态', 409)
    saved = server.core.store.get('users', user.get('id'))
    if (not saved or saved.get('disabled') or saved.get('cloud_bound') is not True
            or any(saved.get(key) != user.get(key) for key in ('id', 'tenant_id', 'username', 'role'))):
        raise WorkspaceError('本机员工身份已变化，请重新核对', 403)
    source_company_id = server.company.get('id')
    submission_company_snapshot = None
    if action in COMPANY_SUBMISSION_ACTIONS | COMPANY_RECEIVER_ACTIONS | COMPANY_CONTACT_DELIVERY_ACTIONS:
        try:
            submission_company_snapshot = json.dumps(server.company, ensure_ascii=False,
                allow_nan=False, sort_keys=True, separators=(',', ':'))
        except (ValueError, TypeError):
            raise WorkspaceError('公司提交的可信配置尚未核对，请回到原交接',
                                 409, mutation_committed=False) from None
    def local_scope_guard():
        # Local identity/device checks only; safe inside a SQLite transaction.
        fresh_own = require_owner(server, saved)
        with assistant.lock:
            return (assistant.executor is executor and assistant.state in ('online', 'held')
                    and server.company.get('id') == source_company_id
                    and fresh_own.get('device_id') == own['device_id']
                    and (assistant.device or {}).get('id') == own['device_id']
                    and (assistant.device or {}).get('owner') == saved['username']
                    and executor.owner == saved['username'] and executor.tenant == saved['tenant_id'])
    preparation_scope_guard = None
    contact_delivery_scope_guard = None
    if action in COMPANY_PREPARATION_ACTIONS | COMPANY_ORIGINAL_STATUS_ACTIONS | COMPANY_SOURCE_BINDING_ACTIONS | COMPANY_REGISTRATION_ACTIONS | COMPANY_CHANNEL_CHECK_ACTIONS | COMPANY_SUBMISSION_ACTIONS | COMPANY_RECEIVER_ACTIONS | COMPANY_CONTACT_DELIVERY_ACTIONS:
        # Current managed configuration and DPAPI binding are both trusted host
        # inputs. A local device binding alone does not establish this scope.
        preparation_environment = (server.company.get('managedWorkspace') or {}).get('environment_id')
        def preparation_scope_guard():
            if local_scope_guard() is not True:
                return False
            if (action in COMPANY_SUBMISSION_ACTIONS | COMPANY_RECEIVER_ACTIONS | COMPANY_CONTACT_DELIVERY_ACTIONS and json.dumps(server.company,
                    ensure_ascii=False, allow_nan=False, sort_keys=True, separators=(',', ':'))
                    != submission_company_snapshot):
                return False
            vault = getattr(assistant, 'vault', None)
            binding = vault.read() if vault and callable(getattr(vault, 'read', None)) else {}
            bound_device = (binding or {}).get('device') or {}
            current_environment = (server.company.get('managedWorkspace') or {}).get('environment_id')
            return (bool(preparation_environment) and current_environment == preparation_environment
                    and (binding or {}).get('state') == 'bound'
                    and (binding or {}).get('environment_id') == preparation_environment
                    and (binding or {}).get('company_id') == source_company_id
                    and bound_device.get('id') == own['device_id']
                    and bound_device.get('owner') == saved['username'])
        try:
            preparation_scope_valid = preparation_scope_guard() is True
        except Exception:
            preparation_scope_valid = False
        if not preparation_scope_valid:
            raise WorkspaceError('本机公司、环境或员工绑定尚未核对，请先重新连接当前公司',
                                 409, mutation_committed=False)
    try:
        from core.service_plans import require_feature, package_summary, ProductAccessError
        from .product_receipts import ProductOperationReceipts
        receipts = ProductOperationReceipts(server.core, executor.tenant, executor.owner)
        if action == 'acquisition_operation_status':
            if set(data) != {'operation_action', 'idempotency_key'} or data['operation_action'] not in RECEIPT_ACTIONS:
                raise WorkspaceError('操作核对参数无效', 400)
            result = receipts.status(data['operation_action'], data['idempotency_key'])
            result['operation_action'] = result.pop('original_action')
            if result['state'] == 'cancelled':
                result['state'] = 'not_committed'
            if result['state'] == 'started':
                result['state'] = 'unknown'
            return {'result': public(result), 'storage_scope': 'this_device', 'cross_machine_verified': False}
        if action == 'entitlement_summary':
            if data:
                raise WorkspaceError('版本读取参数无效', 403)
            from .product_cloud_usage import read_product_usage
            summary = package_summary(server.company)
            summary['cloud_usage'] = read_product_usage(server, executor, saved)
            return {'result': public(summary), 'storage_scope': 'this_device',
                    'cross_machine_verified': False}
        if action in AI_READ_ACTIONS:
            from .ai_attempts import AIRequestReview
            from integrations import IntegrationError
            attempts = getattr(getattr(executor, 'ai', None), 'attempts', None)
            if attempts is None:
                raise WorkspaceError('原分析核对入口尚未连接，请保留原记录', 503)
            try:
                result = attempts.list(saved, data) if action == 'ai_attempt_list' else attempts.status(saved, data)
            except AIRequestReview as exc:
                raise WorkspaceError(str(exc), 409) from None
            except IntegrationError:
                raise WorkspaceError('原分析核对暂不可用，请保留原编号；未重复请求', 503) from None
            fresh_owner = require_owner(server, user)
            with assistant.lock:
                fresh_executor = assistant.executor
                fresh_device = dict(assistant.device or {})
                fresh_state = assistant.state
            fresh_user = server.core.store.get('users', user['id'])
            if (fresh_owner.get('device_id') != own.get('device_id') or
                    fresh_executor is not executor or fresh_state not in ('online','held') or
                    fresh_device.get('id') != device.get('id') or fresh_device.get('owner') != user['username'] or
                    executor.owner != user['username'] or executor.tenant != user['tenant_id'] or
                    not fresh_user or fresh_user.get('disabled') or fresh_user.get('cloud_bound') is not True or
                    any(fresh_user.get(key) != saved.get(key) for key in ('id','tenant_id','username','role'))):
                raise WorkspaceError('原分析返回时员工或电脑绑定已变化，请回到原范围核对', 409)
            return {'result': public(result), 'storage_scope': 'this_device', 'cross_machine_verified': False}
        feature = ('export' if action in EXPORT_ACTIONS else
                   'intent_analysis' if action == 'intent_quality_batch_create' else
                   'strategy' if action == 'intent_policy_publish' else
                   'acquisition' if action in ('platform_read_search', 'platform_read_comments', 'platform_read_content', 'platform_read_archive') else
                   'strategy' if action in ('strategy_save', 'strategy_import', 'intent_rules_save') else
                   'handoff' if action in ('handoff_create', 'handoff_update', 'handoff_submit', 'contact_create', 'company_handoff_prepare', 'company_handoff_register', 'company_handoff_submit', 'company_contact_publish') else None)
        if action == 'handoff_update' and data.get('operation') in ('withdraw', 'dispute'):
            # Expired commercial rights never prevent withdrawal or dispute.
            # The service still validates identity, ownership and the exact data.
            feature = None
        if feature:
            require_feature(server.company, feature)
        if action == 'strategy_task_create':
            require_feature(server.company, 'strategy')
            require_feature(server.company, 'acquisition')
        from .acquisition_strategy import (AcquisitionStrategy, StrategyError,
            StrategyPermissionError, StrategyRevisionConflict, StrategyBusy)
        from core.intent_policy import IntentPolicyError
        from .intent_rule_management import IntentRuleManagement, IntentRulePermissionError, IntentRuleConflict
        if action in OPERATION_ACTIONS:
            from .acquisition_operations import AcquisitionOperations
            service = AcquisitionOperations(server.core, executor.tenant, executor.owner,
                server.company, lead_access=executor._lead_access)
        elif action in EXPORT_ACTIONS:
            from .acquisition_exports import AcquisitionExports
            service = AcquisitionExports(server.core, executor.tenant, executor.owner,
                server.company, lead_access=executor._lead_access)
        elif action in RULE_ACTIONS:
            service = IntentRuleManagement(server.core, executor.tenant, executor.owner, server.company)
        elif action in QUALITY_ACTIONS:
            from .intent_quality_review import IntentQualityReview
            service = IntentQualityReview(server.core, executor.tenant, executor.owner, server.company,
                device_id=own['device_id'], scope_guard=local_scope_guard, lead_access=executor._lead_access)
        elif action in COMPANY_CONTACT_DELIVERY_ACTIONS:
            from .company_contact_delivery import CompanyContactDelivery
            from .company_contact_delivery_transport import CompanyContactDeliveryTransport, CompanyContactWithdrawalTransport
            from .company_handoff_receiver_transport import CompanyHandoffReceiverTransport
            try:
                transport_args = dict(environment_id=preparation_environment, company_id=source_company_id,
                    scope_guard=preparation_scope_guard)
                # Current endpoint/session/expiry and complete saved identity
                # stay RAM-bound until the final HTTP projection. No refresh.
                capture = CompanyContactDeliveryTransport(server, saved, device_id=own['device_id'], **transport_args)
                contact_delivery_scope_guard = capture.fixed_session_guard(saved)
                transport_args['scope_guard'] = contact_delivery_scope_guard
                service = CompanyContactDelivery(server.core, executor.tenant, executor.owner, server.company,
                    device_id=own['device_id'], scope_guard=contact_delivery_scope_guard,
                    cloud_contact=CompanyContactDeliveryTransport(server, saved, device_id=own['device_id'], **transport_args),
                    cloud_read=CompanyHandoffReceiverTransport(server, saved, **transport_args),
                    cloud_withdraw=CompanyContactWithdrawalTransport(server, saved, **transport_args),
                    lead_access=executor._lead_access)
            except ValueError:
                raise WorkspaceError('公司联系方式范围尚未确认，请核对本人、公司与电脑绑定',
                                     403, mutation_committed=False) from None
        elif action in COMPANY_RECEIVER_ACTIONS:
            from .company_handoff_receiver import CompanyHandoffReceiver
            from .company_handoff_receiver_transport import CompanyHandoffReceiverTransport
            try:
                receiver_transport = CompanyHandoffReceiverTransport(server, saved,
                    environment_id=preparation_environment, company_id=source_company_id,
                    scope_guard=preparation_scope_guard)
                service = CompanyHandoffReceiver(server.core, executor.tenant, executor.owner, server.company,
                    device_id=own['device_id'], scope_guard=preparation_scope_guard,
                    cloud_read=receiver_transport, cloud_receipt=receiver_transport)
            except ValueError:
                raise WorkspaceError('公司接收范围尚未核对，请确认当前本人、公司与电脑绑定',
                                     403, mutation_committed=False) from None
        elif action in COMPANY_SUBMISSION_ACTIONS:
            from .company_handoff_submission import CompanyHandoffSubmission
            from .company_handoff_submission_transport import CompanyHandoffSubmissionTransport
            from .company_handoff_channel_transport import CompanyHandoffChannelTransport
            from .company_handoff_status_transport import CompanyHandoffStatusTransport
            from .company_source_binding_transport import CompanySourceBindingReadTransport
            try:
                transport_args = dict(environment_id=preparation_environment,
                    company_id=source_company_id, scope_guard=preparation_scope_guard)
                submit_transport = CompanyHandoffSubmissionTransport(server, saved, **transport_args)
                register_status = CompanyHandoffStatusTransport(server, saved, **transport_args)
                detail_read = CompanyHandoffChannelTransport(server, saved, **transport_args)
                source_read = CompanySourceBindingReadTransport(server, saved, **transport_args)
                def submission_cloud_read(actor, operation, body):
                    if operation == 'acquisition_handoff_operation_status':
                        if body.get('operation_action') == 'acquisition_handoff_submit':
                            return submit_transport.read_status(actor, operation, body)
                        return register_status(actor, operation, body)
                    if operation == 'acquisition_source_binding_read':
                        return source_read(actor, operation, body)
                    if operation == 'acquisition_handoff_detail':
                        return detail_read(actor, operation, body)
                    raise ValueError('公司提交只能核对原来源、原详情与原操作编号')
                service = CompanyHandoffSubmission(server.core, executor.tenant, executor.owner, server.company,
                    device_id=own['device_id'], scope_guard=preparation_scope_guard,
                    lead_access=executor._lead_access, cloud_read=submission_cloud_read,
                    cloud_submit=submit_transport)
            except ValueError:
                raise WorkspaceError('公司待接单提交范围尚未确认，请核对本人、公司与电脑绑定',
                                     403, mutation_committed=False) from None
        elif action in COMPANY_CHANNEL_CHECK_ACTIONS:
            from .company_handoff_channel_check import CompanyHandoffChannelCheck
            from .company_handoff_channel_transport import CompanyHandoffChannelTransport
            from .company_handoff_status_transport import CompanyHandoffStatusTransport
            from .company_source_binding_transport import CompanySourceBindingReadTransport
            try:
                transport_args = dict(environment_id=preparation_environment,
                    company_id=source_company_id, scope_guard=preparation_scope_guard)
                channel_reads = {
                    'acquisition_handoff_detail': CompanyHandoffChannelTransport(server, saved, **transport_args),
                    'acquisition_handoff_operation_status': CompanyHandoffStatusTransport(server, saved, **transport_args),
                    'acquisition_source_binding_read': CompanySourceBindingReadTransport(server, saved, **transport_args)}
                def channel_cloud_read(actor, operation, body):
                    if operation not in channel_reads:
                        raise ValueError('公司详情只能核对原编号和原来源')
                    return channel_reads[operation](actor, operation, body)
                service = CompanyHandoffChannelCheck(server.core, executor.tenant, executor.owner, server.company,
                    device_id=own['device_id'], scope_guard=preparation_scope_guard,
                    lead_access=executor._lead_access, cloud_read=channel_cloud_read)
            except ValueError:
                raise WorkspaceError('公司当前来源核对范围尚未确认，请核对本人、公司与电脑绑定',
                                     403, mutation_committed=False) from None
        elif action in COMPANY_REGISTRATION_ACTIONS:
            from .company_handoff_registration import CompanyHandoffRegistration
            from .company_handoff_registration_transport import CompanyHandoffRegistrationTransport
            from .company_handoff_status_transport import CompanyHandoffStatusTransport
            from .company_source_binding_transport import CompanySourceBindingReadTransport
            try:
                transport_args = dict(environment_id=preparation_environment,
                    company_id=source_company_id, scope_guard=preparation_scope_guard)
                status_read = CompanyHandoffStatusTransport(server, saved, **transport_args)
                source_read = CompanySourceBindingReadTransport(server, saved, **transport_args)
                cloud_register = CompanyHandoffRegistrationTransport(server, saved, **transport_args)
                def registration_cloud_read(actor, operation, body):
                    if operation == 'acquisition_source_binding_read':
                        return source_read(actor, operation, body)
                    if operation == 'acquisition_handoff_operation_status':
                        return status_read(actor, operation, body)
                    raise ValueError('公司草稿只能按原来源和原编号核对')
                service = CompanyHandoffRegistration(server.core, executor.tenant, executor.owner, server.company,
                    device_id=own['device_id'], scope_guard=preparation_scope_guard,
                    lead_access=executor._lead_access, cloud_read=registration_cloud_read,
                    cloud_register=cloud_register)
            except ValueError:
                raise WorkspaceError('公司线索草稿登记范围尚未核对，请确认本人、公司与电脑绑定',
                                     403, mutation_committed=False) from None
        elif action in COMPANY_ORIGINAL_STATUS_ACTIONS:
            from .company_handoff_original_status import CompanyHandoffOriginalStatus
            from .company_handoff_status_transport import CompanyHandoffStatusTransport
            try:
                cloud_read = CompanyHandoffStatusTransport(server, saved,
                    environment_id=preparation_environment, company_id=source_company_id,
                    scope_guard=preparation_scope_guard)
                service = CompanyHandoffOriginalStatus(server.core, executor.tenant, executor.owner, server.company,
                    device_id=own['device_id'], scope_guard=preparation_scope_guard,
                    lead_access=executor._lead_access, cloud_read=cloud_read)
            except ValueError:
                raise WorkspaceError('当前本人原公司操作查询范围尚未核对，请确认公司成员与电脑绑定',
                                     403, mutation_committed=False) from None
        elif action in COMPANY_SOURCE_BINDING_ACTIONS:
            from .company_handoff_source_binding import CompanyHandoffSourceBinding
            from .company_source_binding_transport import CompanySourceBindingReadTransport
            try:
                cloud_read = CompanySourceBindingReadTransport(server, saved,
                    environment_id=preparation_environment, company_id=source_company_id,
                    scope_guard=preparation_scope_guard)
                service = CompanyHandoffSourceBinding(server.core, executor.tenant, executor.owner, server.company,
                    device_id=own['device_id'], scope_guard=preparation_scope_guard,
                    lead_access=executor._lead_access, cloud_read=cloud_read)
            except ValueError:
                raise WorkspaceError('原来源公司核对范围尚未确认，请核对本人、公司与设备绑定',
                                     403, mutation_committed=False) from None
        elif action in COMPANY_PREPARATION_ACTIONS:
            from .company_handoff_preparation import CompanyHandoffPreparation
            try:
                service = CompanyHandoffPreparation(server.core, executor.tenant, executor.owner, server.company,
                    device_id=own['device_id'], scope_guard=preparation_scope_guard, lead_access=executor._lead_access)
            except ValueError:
                raise WorkspaceError('公司平台线索准备范围尚未核对，请重新确认公司成员与电脑绑定',
                                     403, mutation_committed=False) from None
        elif action in ACQUISITION_PREFLIGHT_ACTIONS:
            from .acquisition_run_preflight import AcquisitionRunPreflight
            try:
                service = AcquisitionRunPreflight(server.core, executor.tenant, executor.owner, server.company,
                    device_id=own['device_id'], scope_guard=local_scope_guard,
                    license_policy_provider=lambda: getattr(server, 'platform_read_license_policy', None))
            except ValueError:
                raise WorkspaceError('采集检查范围尚未确认，请核对本人、公司与电脑连接',
                                     403, mutation_committed=False) from None
        elif action in SELF_DAILY_EVIDENCE_ACTIONS:
            from .self_daily_evidence import SelfDailyEvidence
            try:
                service = SelfDailyEvidence(server.core, executor.tenant, executor.owner, server.company,
                    device_id=own['device_id'], scope_guard=local_scope_guard, lead_access=executor._lead_access)
            except ValueError:
                raise WorkspaceError('本人每日记录范围尚未核对，请确认员工与电脑连接',
                                     403, mutation_committed=False) from None
        elif action in SELF_WORKLIST_ACTIONS:
            from .self_worklist import SelfWorklist
            try:
                service = SelfWorklist(server.core, executor.tenant, executor.owner, server.company,
                    device_id=own['device_id'], scope_guard=local_scope_guard, lead_access=executor._lead_access)
            except ValueError:
                raise WorkspaceError('当前本人工作范围尚未核对，请重新确认员工与电脑连接',
                                     403, mutation_committed=False) from None
        elif action in BUSINESS_READ_ACTIONS:
            from .business_reconciliation import LocalBusinessReconciliation
            if action == 'business_reconciliation_candidates':
                from .business_channel_candidates import LocalBusinessChannelCandidates
                helper = LocalBusinessChannelCandidates
            else:
                helper = LocalBusinessReconciliation
            def business_cloud(actor, operation, body):
                # The authenticated integration checks environment/company before
                # this pure read's narrow helper validates its business summary.
                answer = executor._ai_cloud(actor, operation, body)
                if not isinstance(answer, dict):
                    raise ValueError('公司账本回执格式无效')
                return {key: value for key, value in answer.items()
                        if key not in ('contract', 'environment_id', 'company_id')}
            try:
                service = helper(server.core, executor.tenant, executor.owner, server.company,
                    cloud_read=business_cloud, device_id=own['device_id'],
                    scope_guard=local_scope_guard, lead_access=executor._lead_access)
            except ValueError:
                raise WorkspaceError('当前绑定员工尚未完成公司账本身份核对，请确认公司成员账号后再查询',
                                     403, mutation_committed=False) from None
        elif action in COMPANY_POLICY_ACTIONS:
            from .company_intent_policy import LocalCompanyIntentPolicy
            def policy_cloud(actor, operation, body):
                # Integration already verifies the HTTP contract and binding.
                # The policy helper accepts only its narrow business receipt.
                answer = executor._ai_cloud(actor, operation, body)
                if not isinstance(answer, dict):
                    raise ValueError('公司规则云回执格式无效')
                return {key: value for key, value in answer.items()
                        if key not in ('contract', 'environment_id', 'company_id')}
            service = LocalCompanyIntentPolicy(server.core, executor.tenant, executor.owner, server.company,
                cloud=policy_cloud,
                device_id=own['device_id'], scope_guard=local_scope_guard)
        elif action in PLATFORM_READ_ACTIONS | PLATFORM_ARCHIVE_ACTIONS:
            from core.platform_reads import PlatformReadService
            def host_read_guard(platform):
                require_feature(server.company, 'acquisition')
                guard = getattr(server, '_platform_execution_guard', None)
                if not callable(guard):
                    raise CoreError('当前主机运行门禁尚未接入，读取保持暂停')
                guard(platform)
            def archive_scope_guard():
                # Local binding checks only. Never run a platform/lease probe
                # while the archive holds its SQLite transaction.
                current_own = require_owner(server, saved)
                with assistant.lock:
                    current_device = dict(assistant.device or {})
                    return (assistant.executor is executor and assistant.state in ('online', 'held')
                            and current_own.get('device_id') == own['device_id']
                            and current_device.get('id') == own['device_id']
                            and current_device.get('owner') == executor.owner)
            # Keep the exact same instance for status/cancel and in-flight results.
            # Licenses are trusted server configuration, never request data.
            identity = (executor.tenant, executor.owner, own['device_id'])
            with server.core.lock:
                services = getattr(server, '_product_platform_read_services', None)
                if services is None:
                    services = {}
                    server._product_platform_read_services = services
                service = services.get(identity)
                if service is None:
                    if len(services) >= 32:
                        raise WorkspaceError('本机读取会话已满，请核对现有操作后重新连接', 409)
                    service = PlatformReadService(server.core, executor.tenant, executor.owner,
                        license_policy=getattr(server, 'platform_read_license_policy', None),
                        license_policy_provider=lambda: getattr(server, 'platform_read_license_policy', None),
                        execution_guard=host_read_guard, device_id=own['device_id'],
                        archive_scope_guard=archive_scope_guard)
                    services[identity] = service
            if action in PLATFORM_ARCHIVE_ACTIONS:
                from .platform_receipt_archive import PlatformReceiptArchive
                service = PlatformReceiptArchive(server.core, executor.tenant, executor.owner,
                    server.company, read_service=service, device_id=own['device_id'], scope_guard=archive_scope_guard)
        elif action in STRATEGY_ACTIONS:
            if action in ('strategy_task_create', 'strategy_task_get', 'strategy_task_status'):
                from .strategy_tasks import StrategyTasks
                service = StrategyTasks(server.core, executor.tenant, executor.owner, server.company)
            else:
                service = AcquisitionStrategy(server.core, executor.tenant, executor.owner, server.company)
        else:
            from .acquisition_contacts import AcquisitionContacts
            service = AcquisitionContacts(server.core, executor.tenant, executor.owner,
                server.company, lead_access=executor._lead_access)
        if action in RECEIPT_ACTIONS:
            with server.core.lock:
                begun = receipts.begin(action, data.get('idempotency_key'), data)
                if not begun['should_execute']:
                    if begun['state'] == 'succeeded':
                        return {'result': public(begun['result']), 'refresh_required': True,
                                'storage_scope': 'this_device', 'cross_machine_verified': False}
                    error = WorkspaceError('原操作未提交，请先核对后使用新编号'
                        if begun['mutation_committed'] is False else '原操作结果仍未知，请按原编号核对，暂勿重复提交', 409,
                        mutation_committed=begun['mutation_committed'])
                    error._product_execution_started = True
                    raise error
                try:
                    result = service.execute(action, data, saved)
                except (CoreError, StrategyError, IntentPolicyError) as exc:
                    outcome=receipts.fail(exc)
                    rejected=outcome['mutation_committed'] is False
                    error = WorkspaceError(str(exc) if rejected else '本机操作结果未确认，请按原编号核对，暂勿重复提交',
                        (403 if isinstance(exc, (StrategyPermissionError, IntentRulePermissionError)) else
                         409 if isinstance(exc, (StrategyRevisionConflict, StrategyBusy, IntentRuleConflict)) else 400) if rejected else 409,
                        mutation_committed=False if rejected else None)
                    error._product_execution_started = True
                    raise error from None
                except Exception as exc:
                    receipts.fail(exc)
                    error = WorkspaceError('本机操作结果未确认，请按原编号核对，暂勿重复提交', 409)
                    error._product_execution_started = True
                    raise error from None
                try:
                    receipts.finish(result)
                except Exception:
                    error = WorkspaceError('操作回执保存未确认，请按原编号核对，暂勿重复提交', 409)
                    error._product_execution_started = True
                    raise error from None
        else:
            try:
                result = service.execute(action, data, saved)
            except Exception as exc:
                if action in COMPANY_CONTACT_DELIVERY_ACTIONS:
                    from .company_contact_delivery import CompanyContactDeliveryError
                    explicit = isinstance(exc, CompanyContactDeliveryError)
                    read_only = action == 'company_contact_operation_get'
                    outcome = False if read_only else getattr(exc, 'mutation_committed', None) if explicit else None
                    error = WorkspaceError(str(exc) if explicit else
                        '公司联系方式原操作待核对，请保留原编号；未自动重发或解密',
                        exc.status if explicit else 503 if read_only else 409, mutation_committed=outcome)
                    error._product_execution_started = True
                    raise error from None
                if action in COMPANY_RECEIVER_ACTIONS:
                    from .company_handoff_receiver import CompanyHandoffReceiverError
                    explicit = isinstance(exc, CompanyHandoffReceiverError)
                    read_only = action != 'company_handoff_receipt'
                    outcome = False if read_only else getattr(exc, 'mutation_committed', None) if explicit else None
                    error = WorkspaceError(str(exc) if explicit else
                        '公司原接收结果待核对，请保留原编号；未自动重发',
                        exc.status if explicit else 503 if read_only else 409, mutation_committed=outcome)
                    error._product_execution_started = True
                    raise error from None
                if action in COMPANY_SUBMISSION_ACTIONS:
                    from .company_handoff_submission import CompanyHandoffSubmissionError
                    explicit = isinstance(exc, CompanyHandoffSubmissionError)
                    read_only = action == 'company_handoff_submission_get'
                    outcome = False if read_only else getattr(exc, 'mutation_committed', None) if explicit else None
                    error = WorkspaceError(str(exc) if explicit else
                        '公司原提交结果待核对，请保留原编号；暂勿再次提交',
                        exc.status if explicit else 503 if read_only else 409, mutation_committed=outcome)
                    error._product_execution_started = True
                    raise error from None
                if action in COMPANY_CHANNEL_CHECK_ACTIONS:
                    from .company_handoff_channel_check import CompanyHandoffChannelCheckError
                    explicit = isinstance(exc, CompanyHandoffChannelCheckError)
                    error = WorkspaceError(str(exc) if explicit else
                        '公司原草稿来源暂不可核对，请保留原编号',
                        exc.status if explicit else 503, mutation_committed=False)
                    error._product_execution_started = True
                    raise error from None
                if action in COMPANY_REGISTRATION_ACTIONS:
                    from .company_handoff_registration import CompanyHandoffRegistrationError
                    explicit = isinstance(exc, CompanyHandoffRegistrationError)
                    read_only = action == 'company_handoff_registration_get'
                    outcome = False if read_only else getattr(exc, 'mutation_committed', None) if explicit else None
                    error = WorkspaceError(str(exc) if explicit else
                        '公司草稿登记结果待核对，原编号继续保留；暂勿再次提交',
                        exc.status if explicit else 503 if read_only else 409,
                        mutation_committed=outcome)
                    error._product_execution_started = True
                    raise error from None
                if action in COMPANY_ORIGINAL_STATUS_ACTIONS:
                    from .company_handoff_original_status import CompanyHandoffOriginalStatusError
                    explicit = isinstance(exc, CompanyHandoffOriginalStatusError)
                    error = WorkspaceError(str(exc) if explicit else
                        '原公司操作暂不可核对，原准备编号继续保留；请稍后重新读取',
                        exc.status if explicit else 503, mutation_committed=False)
                    error._product_execution_started = True
                    raise error from None
                if action in COMPANY_SOURCE_BINDING_ACTIONS:
                    from .company_handoff_source_binding import CompanyHandoffSourceBindingError
                    explicit = isinstance(exc, CompanyHandoffSourceBindingError)
                    error = WorkspaceError(str(exc) if explicit else
                        '原来源公司记录暂不可核对，原准备继续保留；请稍后重新读取',
                        exc.status if explicit else 503, mutation_committed=False)
                    error._product_execution_started = True
                    raise error from None

                if action in COMPANY_PREPARATION_ACTIONS:
                    from .company_handoff_preparation import CompanyHandoffPreparationError
                    explicit = isinstance(exc, CompanyHandoffPreparationError)
                    read_only = action == 'company_handoff_preparation_get'
                    outcome = False if read_only else getattr(exc, 'mutation_committed', None) if explicit else None
                    error = WorkspaceError(str(exc) if explicit else
                        '公司平台线索本机准备结果尚未核对，请读取原准备记录；暂勿重复保存',
                        exc.status if explicit else 503 if read_only else 409,
                        mutation_committed=outcome)
                    # A generic failure may occur after a local commit. Never
                    # let the outer pre-execution handler turn it into False.
                    error._product_execution_started = True
                    raise error from None
                if action in ACQUISITION_PREFLIGHT_ACTIONS:
                    from .acquisition_run_preflight import AcquisitionRunPreflightError
                    if isinstance(exc, AcquisitionRunPreflightError):
                        raise WorkspaceError(str(exc), exc.status, mutation_committed=False) from None
                    raise WorkspaceError('采集条件暂不可核对，请重新读取原任务；未启动或修改任务',
                                         503, mutation_committed=False) from None
                if action in SELF_DAILY_EVIDENCE_ACTIONS:
                    from .self_daily_evidence import SelfDailyEvidenceError
                    if isinstance(exc, SelfDailyEvidenceError):
                        raise WorkspaceError(str(exc), exc.status, mutation_committed=False) from None
                    raise WorkspaceError('本人每日记录暂不可核对，请重新读取当前范围；未修改客户记录',
                                         503, mutation_committed=False) from None
                if action in SELF_WORKLIST_ACTIONS:
                    from .self_worklist import SelfWorklistError
                    if isinstance(exc, SelfWorklistError):
                        raise WorkspaceError(str(exc), exc.status, mutation_committed=False) from None
                    raise WorkspaceError('本人处理清单暂不可读，请重新核对当前范围；未修改客户记录',
                                         503, mutation_committed=False) from None
                if action in BUSINESS_READ_ACTIONS:
                    # This route never reserves or writes a business operation.
                    # Raw cloud/storage errors may include private evidence.
                    from .business_reconciliation import BusinessReconciliationError
                    if isinstance(exc, BusinessReconciliationError):
                        raise WorkspaceError(str(exc), exc.status, mutation_committed=False) from None
                    error = WorkspaceError('公司账本暂不可读，请核对当前授权、交接编号和云连接；未修改经营记录',
                                           503, mutation_committed=False)
                    raise error from None
                if action in QUALITY_ACTIONS | COMPANY_POLICY_ACTIONS:
                    from .intent_quality_review import IntentQualityReviewError
                    from .company_intent_policy import CompanyIntentPolicyError
                    explicit = isinstance(exc, (IntentQualityReviewError, CompanyIntentPolicyError))
                    outcome = getattr(exc, 'mutation_committed', None) if explicit else None
                    if action == 'intent_policy_read':
                        error = WorkspaceError('公司规则摘要暂不可读，请检查云连接；发布保持暂停', 503,
                                               mutation_committed=False)
                        error._product_execution_started = True
                        raise error from None
                    error = WorkspaceError(str(exc) if explicit else '原操作结果未确认，请保留原编号核对；暂勿重复提交',
                                           400 if outcome is False else 409, mutation_committed=outcome)
                    error._product_execution_started = True
                    raise error from None
                if action in PLATFORM_ARCHIVE_ACTIONS:
                    from .platform_receipt_archive import ReceiptArchiveError
                    if isinstance(exc, ReceiptArchiveError):
                        error = WorkspaceError(str(exc), 400 if exc.mutation_committed is False else 409,
                                               mutation_committed=exc.mutation_committed)
                        error._product_execution_started = True
                        raise error from None
                    # Storage can commit before a later projection or return
                    # raises a generic error. Only the archive's explicit proof
                    # may classify this original operation as not committed.
                    error = WorkspaceError('来源保存结果未确认，请保留原编号核对；暂勿重复保存', 409,
                                           mutation_committed=None)
                    error._product_execution_started = True
                    raise error from None
                if action in ('strategy_task_create', 'strategy_task_status'):
                    # Snapshot reservation and Core task creation have separate
                    # commits. Even a CoreError can follow a committed task.
                    error = WorkspaceError('策略快照结果需核对，请保留原编号；平台尚未由本动作启动', 409)
                    error._product_execution_started = True
                    raise error from None
                if isinstance(exc, (StrategyPermissionError, IntentRulePermissionError)):
                    raise WorkspaceError(str(exc), 403) from None
                if isinstance(exc, (StrategyRevisionConflict, StrategyBusy, IntentRuleConflict)):
                    raise WorkspaceError(str(exc), 409) from None
                if isinstance(exc, (StrategyError, IntentPolicyError)):
                    raise WorkspaceError(str(exc), 400) from None
                if action in PLATFORM_READ_ACTIONS:
                    from core.platform_reads import ReadAccessError
                    if isinstance(exc, ReadAccessError):
                        raise WorkspaceError('读取账号或当前员工权限需重新核对', 403) from None
                raise
    except CoreError as exc:
        raise WorkspaceError(str(exc), 400) from None
    except ProductAccessError as exc:
        raise WorkspaceError(str(exc), 403) from None
    if action in QUALITY_ACTIONS | COMPANY_POLICY_ACTIONS | BUSINESS_READ_ACTIONS | SELF_WORKLIST_ACTIONS | SELF_DAILY_EVIDENCE_ACTIONS | ACQUISITION_PREFLIGHT_ACTIONS | COMPANY_PREPARATION_ACTIONS | COMPANY_ORIGINAL_STATUS_ACTIONS | COMPANY_SOURCE_BINDING_ACTIONS | COMPANY_REGISTRATION_ACTIONS | COMPANY_CHANNEL_CHECK_ACTIONS | COMPANY_SUBMISSION_ACTIONS | COMPANY_RECEIVER_ACTIONS | COMPANY_CONTACT_DELIVERY_ACTIONS:
        # Services verify inside their transaction. Recheck the HTTP projection
        # boundary too: a committed operation can outlive a host/user switch.
        try:
            fresh_user = server.core.store.get('users', saved['id'])
            valid = (local_scope_guard() is True and fresh_user and not fresh_user.get('disabled')
                     and fresh_user.get('cloud_bound') is True
                     and all(fresh_user.get(key) == saved.get(key) for key in ('id','tenant_id','username','role'))
                     and (action not in COMPANY_CONTACT_DELIVERY_ACTIONS or contact_delivery_scope_guard() is True)
                     and (action not in COMPANY_PREPARATION_ACTIONS | COMPANY_ORIGINAL_STATUS_ACTIONS | COMPANY_SOURCE_BINDING_ACTIONS | COMPANY_REGISTRATION_ACTIONS | COMPANY_CHANNEL_CHECK_ACTIONS | COMPANY_SUBMISSION_ACTIONS | COMPANY_RECEIVER_ACTIONS | COMPANY_CONTACT_DELIVERY_ACTIONS or preparation_scope_guard() is True))
        except Exception:
            valid = False
        if not valid:
            error = WorkspaceError('结果返回时员工、企业或电脑已变化，请回到原范围核对原编号', 409,
                                   mutation_committed=False if action in BUSINESS_READ_ACTIONS | SELF_WORKLIST_ACTIONS | SELF_DAILY_EVIDENCE_ACTIONS | ACQUISITION_PREFLIGHT_ACTIONS | COMPANY_ORIGINAL_STATUS_ACTIONS | COMPANY_SOURCE_BINDING_ACTIONS | COMPANY_CHANNEL_CHECK_ACTIONS or action in COMPANY_RECEIVER_ACTIONS - {'company_handoff_receipt'} or action in ('company_handoff_preparation_get', 'company_handoff_registration_get', 'company_handoff_submission_get', 'company_contact_operation_get') else None)
            error._product_execution_started = True
            raise error
    if action in PLATFORM_ARCHIVE_ACTIONS:
        result = {**result, 'operation_action': 'platform_read_archive', 'idempotency_key': data['idempotency_key']}
    if action in ('intent_policy_publish', 'intent_policy_publish_status'):
        result = {**result, 'operation_action': 'intent_policy_publish'}
    return {'result': public(result), 'storage_scope': ('local_bridge_company_server_contact_vault'
            if action in COMPANY_CONTACT_DELIVERY_ACTIONS else 'local_bridge_company_server_ledger'
            if action in BUSINESS_READ_ACTIONS | COMPANY_SOURCE_BINDING_ACTIONS | COMPANY_REGISTRATION_ACTIONS | COMPANY_CHANNEL_CHECK_ACTIONS | COMPANY_SUBMISSION_ACTIONS | COMPANY_RECEIVER_ACTIONS else 'this_device'),
            'cross_machine_verified': False}
