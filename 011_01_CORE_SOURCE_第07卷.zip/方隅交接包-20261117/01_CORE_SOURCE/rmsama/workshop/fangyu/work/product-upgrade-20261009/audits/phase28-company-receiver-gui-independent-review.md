# Phase28 公司收件箱 GUI 归档独立只读核对

结论：现有证据自洽，未发现本次归档的 material 阻塞。只读取日志、代码、固定快照与六张原 JPEG；没有运行 GUI、前后台测试、SDK 操作或数据库查询。新增测试计数为 0。本结论只覆盖隔离的合成资源部接收链路，不表示真实账号恢复、真实公司接收、联系方式交付、资金到账、部署或总任务完成。

## 动作与未知恢复

原动作日志恰为七条，时间非递减：部门选择摘要、所选部门列表、当前详情、接单 ACK、原号 GET、固定合成撤回、同原号 GET。源端 fixture 登记1/提交1/channel1；接收 UI 启动 ACK0，第4条后 ACK1，并保持到第7条，没有第二次 ACK。

第1条不带 recipient：selection_required、items 空、total null；第2条明确选择 resources，列表1条。第3条是 not_attempted/current submitted rev2/eligible true，仅表明此接收人尚无本机接收尝试；不证明公司此前没有其它操作。第4条只出现 detail 与 receipt 两个直接操作，receipt 标记 lost_response，错误 mutation 为 null，本机有一条 INSERT；不能把这次写说成零 DML。

第5、7条 GET 均为 read_only true/mutation false/cloud_receipt_requested false。两条各自 dump 前后 SHA 相等，彼此的 dump 也相等；SQL trace 的 DML/DDL 数组为空。四个 SDK 只读操作共16个回调计数记录，全部 writes0，stored_documents_unchanged true。原 attempt 的 key、expected_revision、decision、created_at、updated_at、state 均相同，state 保持 unknown，没有 status repair。两个 original_operation 完全相同：历史 rev3 accepted、自事件 hash 已核、完整历史链未核。第一次 current rev3 accepted/consent true；固定合成来源撤回后 current rev4 withdrawn/consent false，历史资源接收仍 true。两次都不可再次接单；现金和已付提成 null，财务、平台送达、跨实体机器和证据独立核验均 false。

这不是只依靠 dump 的零写结论：同时存在实际临时 SQLite trace 和 SDK adapter 回调计数。该 SDK 为实际 service/createStore 的内存兼容双回调接口，不能推成真实 CloudBase 引擎、线上事务或第二实体机验收。日志最外层 mutation 字段仅记录 error 属性，成功读为 null；成功 DTO 内明确 false，两者语义不冲突。

## 来源、SHA 与资产日志

- 原最终 manifest 的12份 evidence 当前 SHA 全部匹配，proof `BCEE15F9FF2C411D5C7023820FCBF06366FEC707BA058C5D1120049C2BB3F292`，review `4A6D9861950A44D59E588F188FCF146FB765BEC2074AC6160BE2915BF11F0254`，manifest `5C0CEB4D2162AE1B81FF0B8B52B2F7F2E67E31900B8DD73643E95639CC3C8E0A`。
- 启动固定56文件当前 SHA 全匹配。实际加载/取资产的48项恰等于 Python15、cloud8、页面源25的并集；proof 与 final manifest 的映射相同。固定 snapshot 的48文件没有缺项或额外文件，路径、字节 SHA 和当前源均匹配。未来合法修改应引用这份历史 snapshot，不能把后续 live 漂移直接说成旧验收被篡改。
- 48项并非48个生产产品文件：Python15包含本次 preview 和一个 Python 测试 fixture，cloud8包含两个 SDK fixture；其余44项位于 app/src 或生产 cloud 模块。固定56不等于实际加载56，也不追加为运行测试数。
- 原 asset log43行：42行有效 JSON，原第4行13字符尾片段仍存在，不补写、不计来源。所有有效行 PID 对应同一 preview。去重页面文件25项；config.mjs 仅本次运行配置资产，hash `74E39C0304743F3E1B2EC66E73DF3C271EB3DD4A59F2BBDB6FADD0EB2CAD1B3B`，没有被计入源文件或 snapshot。index.html 记录的是插入合成水印前的基础资产 SHA，这个范围在 preview 代码与 proof 中明示。

## 原图与预览边界

六张原 JPEG 的 SHA、格式和实际尺寸均吻合，均为1571×982。已逐张查看：明确选择部门、详情/证据表单、证据与勾选确认、未知只核对原号、历史接收成功、撤回后历史保留。未知页没有第二次提交按钮；后两图分别显示当前/历史状态，并保留实收/分成与独立核验未知。原图含合成验收水印；外层背景出现 narrow host 拒绝其它本机操作的提示，与现有预览限制一致。

“接单前默认未确认”截图的下部 checkbox 不在可见范围，不能单凭该图证明未勾选。已加载的真实 receiver UI 源明确 checked=false/submit disabled，前三条实际记录 ACK0；另一图可见补证据后勾选，再发生唯一 ACK，三者分开支持行为证据。无需补图或重跑。请求 viewport1586×992与最终 JPEG 实际像素不是同一数值；结束 reset 是 root GUI 记录，本轮未操作或读取浏览器状态。approved_visual_target_acceptance 仍 false，不表示用户已认可像素或整体视觉。

隔离 host 没有正式启动 AppServer/AssistantService；用 fixture 保存的 resource actor 与 actual gateway/receiver/transport，底层公司端为合成映射，不包含原客户、原账号或真实公司接收。外层启动/本机交接读取未全部开放，不能据本次收件成功宣称完整工作台所有入口正常。

## 归档过程与冻结

两个归档旧脚本已保留在 `backups/phase28-receiver-gui-archive-correction/1`。静读首版在43行全量 JSON 解析处会停；第二版把 config.mjs 当固定源查找时会停，两处均位于 snapshot/proof 写入前。最终版仅解析有效行并单列 runtime 配置，七条动作与 ACK1计数支持没有重放 GUI。不存在本独审新增的 parser 执行验证；先前归档预检停止应记作归档脚本问题，不作产品或 GUI RED。

本独审新增文件仅本报告和同目录 `phase28-company-receiver-gui-independent-final-hashes.json`。目录：`C:/积木软件工坊/项目/方隅公寓客户版/work/product-upgrade-20261009/audits`。未修改生产、旧 manifest/report、原日志、截图或固定快照，未访问原 DATA、Native/DPAPI、网络、CLI、浏览器或真实平台。
