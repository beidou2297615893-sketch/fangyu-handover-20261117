"""Actual Core -> actual project service/store/repos using local SDK adapter.

Node is a fixed local fixture worker. No HTTP, CloudBase engine or real data.
"""
from copy import deepcopy
from pathlib import Path
from tempfile import TemporaryDirectory
from types import SimpleNamespace
import hashlib
import json
import socket
import subprocess
import sys
from unittest.mock import patch
from uuid import uuid4

PROJECT = Path(__file__).resolve().parents[3]
sys.path[:0] = [str(PROJECT/'work/app/src'), str(PROJECT/'work/app/tests')]
from core import Core
from core.contact_journal import contact_event
from assistant.acquisition_operations import AcquisitionOperations
from assistant.company_handoff_preparation import CompanyHandoffPreparation, PREPARE, GET
from assistant.company_handoff_original_status import CompanyHandoffOriginalStatus, ACTION

TEMP = PROJECT/'work/product-upgrade-20261009/tmp/company-handoff-original-status-actual'
NODE = Path('C:/Program Files/nodejs/node.exe')


def local_fixture(base):
    core = Core(Path(base)/'db', Path(base)/'resources')
    company = {'id': 'fixture-company', 'managedWorkspace': {'environment_id': 'fixture-env'},
        'acquisitionPolicy': {'recipients': [{'id': 'resources', 'name': '资源部'}]}}
    tenant = 'cloud-'+hashlib.sha256(b'fixture-env\nfixture-company').hexdigest()[:24]
    actor = dict(id='actual-status-source', tenant_id=tenant, username='source', role='operator', cloud_bound=True)
    task = dict(id='actual-status-task', tenant_id=tenant, cloud_owner='source')
    lead = dict(id='actual-status-lead', tenant_id=tenant, cloud_owner='source', task_id=task['id'],
        platform='xiaohongshu', author_id='actual-status-synthetic-uid', comment_id='actual-status-synthetic-comment',
        text='纯合成本人找房评论', author='合成租房人')
    for entity, item in [('users', actor), ('tasks', task), ('leads', lead)]: core.store.put(entity, item)
    def access(user, source): core._task_access(user, core.store.get('tasks', source['task_id']), tenant)
    options = dict(device_id='fixture-source-device', scope_guard=lambda: True, lead_access=access)
    acquisition = AcquisitionOperations(core, tenant, 'source', company, lead_access=access)
    handoff = acquisition.execute('handoff_create', dict(lead_id=lead['id'], recipient_id='resources',
        purpose='纯合成租房承接', consent={'status': 'granted', 'evidence_reference': 'consent:'+'a'*32, 'notice_version': 'fixture-v1'},
        idempotency_key='actual-local-status-create'), deepcopy(actor))['item']
    handoff = acquisition.execute('handoff_update', dict(id=handoff['id'], expected_revision=handoff['revision'],
        qualification='qualified', idempotency_key='actual-local-status-qualify'), deepcopy(actor))['item']
    handoff = acquisition.execute('handoff_submit', dict(id=handoff['id'], expected_revision=handoff['revision'],
        idempotency_key='actual-local-status-submit'), deepcopy(actor))['item']
    event = contact_event('reviewed', lead, {'id': 'actual-status-reply', 'text': ''},
        {'id': 'fixture-xhs-account'}, event_id=str(uuid4()), occurred_at=1791611980)
    core.contact_journal.append(event, tenant, 'source')
    return SimpleNamespace(core=core, actor=actor, company=company, tenant=tenant, options=options,
        lead=lead, handoff=handoff, event=event, acquisition=acquisition,
        preparation=CompanyHandoffPreparation(core, tenant, 'source', company, **options))


def generate():
    TEMP.mkdir(parents=True, exist_ok=True)
    with TemporaryDirectory(dir=TEMP) as base, patch.object(socket.socket, 'connect', side_effect=AssertionError('network forbidden')):
        fixture = local_fixture(base)
        worker = subprocess.Popen([str(NODE), str(Path(__file__).with_name('company-handoff-original-status-sdk-worker.cjs'))],
            stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, encoding='utf-8')
        def command(value):
            worker.stdin.write(json.dumps(value, ensure_ascii=False)+'\n'); worker.stdin.flush()
            result = json.loads(worker.stdout.readline())
            if 'fixture_error' in result: raise AssertionError(result['fixture_error'])
            return result
        envelopes, counters = {}, {}
        active_case = [None]
        def cloud_read(actor, operation, data):
            assert actor['username'] == 'source' and operation == 'acquisition_handoff_operation_status'
            result = command({'kind': 'status', 'data': data})
            envelope = result['result']['data']
            assert envelope['contract'] == 'fangyu-workspace-v1'
            assert envelope['environment_id'] == 'fixture-env' and envelope['company_id'] == 'fixture-company'
            envelopes[active_case[0]] = envelope
            counters[active_case[0]] = result['operations']
            return {key: value for key, value in envelope.items() if key not in ('contract', 'environment_id', 'company_id')}
        service = CompanyHandoffOriginalStatus(fixture.core, fixture.tenant, 'source', fixture.company,
            cloud_read=cloud_read, **fixture.options)
        cases, request = {}, {'handoff_id': fixture.handoff['id']}
        def collect(name):
            active_case[0] = name
            with fixture.core.store.connect() as db: before = '\n'.join(db.iterdump())
            result = service.execute(ACTION, request, deepcopy(fixture.actor))
            with fixture.core.store.connect() as db: assert before == '\n'.join(db.iterdump())
            cases[name] = {'request': deepcopy(request), 'result': result, 'local_database_unchanged': True}
        try:
            collect('no_origin')
            synced = command({'kind': 'sync', 'event': fixture.event})['result']['data']
            assert fixture.event['event_id'] in synced['accepted_event_ids']
            fixture.core.contact_journal.acknowledge(fixture.tenant, 'source', [fixture.event['event_id']])
            prepared = fixture.preparation.execute(PREPARE, {'handoff_id': fixture.handoff['id'],
                'expected_revision': fixture.handoff['revision'], 'idempotency_key': 'actual-original-status-preparation'}, deepcopy(fixture.actor))
            preparation_get = fixture.preparation.execute(GET, {'handoff_id': fixture.handoff['id']}, deepcopy(fixture.actor))
            with fixture.core.store.connect() as db:
                origin = fixture.preparation._row(db, fixture.handoff['id'])
                snapshot = fixture.preparation._read_state(db, fixture.handoff['id'], fixture.actor)
            payload = fixture.preparation._cloud_payload(snapshot, fixture.event['event_id'], origin['cloud_idempotency_key'])
            collect('unknown')
            assert command({'kind': 'register_lost', 'payload': payload})['response_lost'] is True
            collect('recorded')
            fixture.core.store.put('leads', {**fixture.lead, 'author_id': 'synthetic-current-replaced-uid'})
            collect('stale_uid')
            fixture.core.store.put('leads', fixture.lead)
            command({'kind': 'accept_withdraw', 'channel_id': origin['expected_cloud_channel_id']})
            fixture.acquisition.execute('handoff_update', {'id': fixture.handoff['id'], 'expected_revision': fixture.handoff['revision'],
                'operation': 'withdraw', 'reason_code': 'customer_withdrew', 'evidence_reference': 'evidence:'+'b'*32,
                'idempotency_key': 'actual-local-status-withdraw'}, deepcopy(fixture.actor))
            collect('withdrawn')
            files = ['work/app/src/assistant/company_handoff_original_status.py',
                'work/cloud/workspace/handoff-ledger.cjs', 'work/cloud/workspace/service.cjs',
                'work/cloud/workspace/handoff-operation-status-fixture.cjs']
            return {'synthetic_only': True, 'fixture_execution': 'actual_local_core_and_actual_project_service_repositories',
                'transaction_engine': 'sdk_interface_compatible_memory_double_callback_adapter', 'real_cloud_called': False,
                'cloud_network_called': False, 'scope': {'environment_id': 'fixture-env', 'company_id': 'fixture-company',
                    'owner': 'source', 'device_id': 'fixture-source-device'}, 'prepared_result': prepared,
                'preparation_get_result': preparation_get,
                'source_sha256': {name: hashlib.sha256((PROJECT/name).read_bytes()).hexdigest().upper() for name in files},
                'cases': cases, 'actual_company_envelopes': envelopes, 'status_transaction_counts': counters,
                'original_register_response_lost_after_commit': True}
        finally:
            worker.stdin.close(); worker.wait(timeout=10)
            if worker.returncode: raise AssertionError(worker.stderr.read())
            worker.stdout.close(); worker.stderr.close()
            fixture.core.close_continuous_scheduler(wait=True); fixture.core.adapters.close()


if __name__ == '__main__':
    target = Path(__file__).with_name('company-handoff-original-status-actual-fixture.json')
    target.write_text(json.dumps(generate(), ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    print(str(target))
