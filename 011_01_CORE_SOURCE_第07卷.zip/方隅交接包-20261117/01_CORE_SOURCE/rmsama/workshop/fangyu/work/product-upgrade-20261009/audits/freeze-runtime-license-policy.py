"""Hash this slice's owned evidence without touching production data."""
import hashlib
import json
from pathlib import Path

PROJECT = Path(__file__).resolve().parents[3]
AUDITS = Path(__file__).resolve().parent
FILES = [
    'work/app/src/app.py', 'work/app/src/core/runtime_license_policy.py',
    'work/app/tests/test_runtime_license_policy.py',
    *['work/product-upgrade-20261009/audits/' + name for name in (
        'runtime-license-policy-review.md', 'runtime-license-policy-actual-fixture.json',
        'emit-runtime-license-policy-fixture.py', 'runtime-license-policy-final-green.txt',
        'runtime-license-policy-consumer-impact-green.txt',
        'runtime-license-policy-formal-server-first-red.txt',
        'runtime-license-policy-restored-mtime-red.txt',
        'runtime-license-policy-constructor-fixture-first.txt')],
]
document = {
    'phase': 'phase19_runtime_license_policy', 'owned_new_tests': 5,
    'unchanged_consumer_tests_reused': 5, 'independent_tests_separate': 3,
    'real_component_approval': False, 'real_platform_or_cloud': False,
    'default_policy': None, 'unknown_tree_checks': 0, 'approved_tree_checks': 2,
    'production_scope': ['work/app/src/app.py', 'work/app/src/core/runtime_license_policy.py'],
    'files': {name: hashlib.sha256((PROJECT / name).read_bytes()).hexdigest().upper() for name in FILES},
}
target = AUDITS / 'runtime-license-policy-final-hashes.json'
target.write_text(json.dumps(document, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'file': str(target), 'sha256': hashlib.sha256(target.read_bytes()).hexdigest().upper(),
                  'report_sha256': document['files']['work/product-upgrade-20261009/audits/runtime-license-policy-review.md']}))
