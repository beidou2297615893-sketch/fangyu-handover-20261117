# Phase26 首轮 occupancy 失败：不改七源的最小观察方案

状态：路线设计，未实现、未原生执行，不授予新 browser/平台/账号动作。8070... 的 child 已退出，现有回执只显示总 unknown；935775... 良性固定 Python/CIM/Job 小样通过，不能从事后元数据还原已经消失的 WebView2 行。

## 首选机制

未来只在 root 明确指定的一次观察 wrapper 中临时设置当前线程 sys.settrace；原七源不加 hook、不 monkeypatch classifier 结果或成员函数。trace 只接受当前 v3 SHA 对应的 `profile_occupancy.py` 代码文件和 `classify` / `WindowsProfileOccupancy.__call__` frame。通过 AST 定位 catch 后实际执行 `uncertain = True` 与最外 unknown return 行；只观察真正失败边界，不把 `_profile_argument` 内部正常捕获的 missing 当失败。

每次 __call__ 只保存 call 序号、owned callback 是否存在。每轮 row 重置私有 row context；exception event 只暂存固定 error code，真正 uncertain 行才输出一个安全诊断项。probe 序号不自动等于“已启动”；owned callback 是否存在才是独立事实。原 host 的安全检查、超时、创建/清理、unknown 都照常执行。finally 恢复旧 trace，不吞掉原异常或改变任何返回值。

## 固定最小投影

- `probe_sequence`：正整数；`owned_callback_present`：bool。
- `family`：python / webview2 / chrome / edge / chromium / other_relevant / unknown。
- `stage`：metadata / executable / argv / profile / default_route / parent_chain / creation_job / selected_runtime / python_binding / probe / unknown。
- `code`：只映射现有固定 ValueError/维护错误 code；TimeoutExpired 单列 probe_timeout；不存 str(error)、traceback 或 exception args。
- `owner_current`、`known_pythonw_route`、`executable_resolves_fixed_base`、`argv0_matches`、`owned_membership`、`selected_webview_runtime_matches`：bool 或 null。仅从本行已经产生且与本 row 对应的局部值派生，无法证明为 null，不继续另查原 DATA/账号。

禁止 PID、parent PID、raw path、command line、SID、UID、Cookie、token、staging 名称、原文字段。记录原本已有的材料/源码摘要仅用于范围核对，不当登录、vacancy、平台或许可证明。

## 最难实现边界

Python frame 局部变量会跨循环保留：旧行的 `own` / executable / argv 不能当新失败行的对应值。trace 在每行开始重置 context，只在该行相关赋值真正完成后标记对应 bool；否则 null。nested `path_for` 捕获正常控制流异常不直接输出，只有外层确实进入 uncertain 后采信最后已传播的固定 code。observer 自己失败只置 `trace_available=false`，原安全判定继续 unknown；诊断丢失不得解锁、重放或改请求数量。

trace 前后核固定 classifier/runtime/source SHA，代码行不匹配就不安装观察器。trace 对时序有影响，因此只能帮助定位，不单凭它证明无竞态或性能。若实施，先用合成 frame/AST 代表验证“前一行 own=true，后一行在 membership 前失败”不会沿用 true，不启动真实 OS；再由 root 决定是否有必要授权下一次原观察。本轮不写实现、不运行新 browser/Native/原 DB/平台请求。

## 当前结论

不需要修改 TrustedCurrentPython、profile 路径或 Job 归属规则。保留真实原观察阻断、良性 Python 小样通过以及原 risk review_required。待 root 指定下一步；不能为了得到更详细原因自行再开原账号。
