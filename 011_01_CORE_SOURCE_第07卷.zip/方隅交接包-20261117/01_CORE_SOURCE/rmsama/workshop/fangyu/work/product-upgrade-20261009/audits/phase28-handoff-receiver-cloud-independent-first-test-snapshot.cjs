'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const crypto=require('node:crypto');
const {fixture}=require('./phase25-company-channel-detail-sdk-fixture.cjs');

// Actual service/createStore plus the established SDK-interface memory adapter.
// No platform/network/real CloudBase transaction engine is exercised.
async function observed(f,run,transform=null,afterSet=null) {
  const before=f.data.snapshot(),original=f.data.db.runTransaction,callbacks=[];
  f.data.db.runTransaction=function(callback) {
    return original.call(this,tx=>{
      const count={reads:0,writes:0},context={};callbacks.push(count);
      return callback({...tx,collection:name=>({doc:id=>{
        const ref=tx.collection(name).doc(id),key=name+'/'+id;
        return {get:async()=>{count.reads++;const value=await ref.get();
          return transform?transform(key,value,context,count):value;},
        set:async value=>{count.writes++;const out=await ref.set(value);
          if(afterSet)await afterSet(key,value,context,count);return out;}};
      }})});
    });
  };
  try{return {result:await run(),before,after:f.data.snapshot(),callbacks};}
  finally{f.data.db.runTransaction=original;}
}
async function submitted(f,suffix) {
  const original=await f.registered('phase28-independent-'+suffix);
  const out=await f.change('acquisition_handoff_submit',original.item);
  assert.equal(out.status,200);return out.data.item;
}
const list=f=>f.call('acquisition_handoff_list',
  {view:'received',recipient_id:'resources',offset:0,limit:1},f.tokens.resource);
const noWrites=proof=>assert.ok(proof.callbacks.every(row=>row.writes===0),
  'a received-list query must not write housekeeping or create a company');
const consentDoc=(f,item)=>f.doc('handoff_','withdrawal:'+item.consent.evidence_reference);

test('received-list rechecks the last-read receiver principal and remains pure for stale or absent sessions/company',async()=>{
  for(const boundary of ['disabled','mapping','session']) {
    const f=await fixture(),item=await submitted(f,'read-'+boundary);
    let reached=false;
    f.duringRead((key,state)=>{
      if(key!==consentDoc(f,item)||!state)return;
      reached=true;
      if(boundary==='disabled')state.users.find(row=>row.username==='resource').disabled=true;
      if(boundary==='mapping')state.acquisitionPolicy.receivers.resource=[];
      if(boundary==='session')state.sessions.find(row=>row.username==='resource').expires=Math.floor(f.clock()/1000);
    });
    const proof=await observed(f,()=>list(f));f.duringRead(null);
    assert.ok(reached,boundary+' must reach the final row/consent await');
    assert.notEqual(proof.result.status,200,boundary+' changed at the final await must not return received customer data');
    assert.equal(proof.result.data.items,undefined);noWrites(proof);
    assert.equal(proof.after,proof.before,'rejected read must not persist the synthetic race or housekeeping');
  }
  for(const boundary of ['expired','missing_company']) {
    const f=await fixture();await submitted(f,'storage-'+boundary);
    if(boundary==='expired')await f.mutate(state=>{
      state.sessions.find(row=>row.username==='resource').expires=Math.floor(f.clock()/1000)-1;
      state.attempts.expired={count:1,until:Math.floor(f.clock()/1000)-1};
    });
    else f.data.remove('fangyu_workspace_private/fixture-company');
    const proof=await observed(f,()=>list(f));
    assert.notEqual(proof.result.status,200);noWrites(proof);
    assert.equal(proof.after,proof.before,'failed pure read must not repair/bootstrap company state');
  }
});

test('non-source accept rolls back when mapping/session/consent changes at the last await or after staged writes',async()=>{
  for(const boundary of ['late_disabled','late_mapping','late_session','staged_mapping','staged_session','staged_consent']) {
    const f=await fixture(),item=await submitted(f,'receipt-'+boundary);
    let currentState=null,reached=false;
    f.duringRead((key,state)=>{if(key===consentDoc(f,item)&&state)currentState=state;});
    const mutate=()=>{
      assert.ok(currentState,'must capture the real ledger transaction state');reached=true;
      if(boundary.endsWith('disabled'))currentState.users.find(row=>row.username==='resource').disabled=true;
      if(boundary.endsWith('mapping'))currentState.acquisitionPolicy.receivers.resource=[];
      if(boundary.endsWith('session'))currentState.sessions.find(row=>row.username==='resource').expires=Math.floor(f.clock()/1000);
    };
    const proof=await observed(f,()=>f.change('acquisition_handoff_receipt',item,
      {decision:'accept',evidence_reference:'evidence:'+crypto.randomUUID().replaceAll('-','')},f.tokens.resource),
      (key,value,context,count)=>{
        if(key!==consentDoc(f,item))return value;
        if(count.writes>=3&&boundary.startsWith('late_'))mutate();
        if(count.writes>0&&boundary==='staged_consent') {
          reached=true;return {data:{companyId:'fixture-company',actor:'source',channel_id:item.channel_id}};
        }
        return value;
      },(key,value,context,count)=>{
        if(count.writes===1&&['staged_mapping','staged_session'].includes(boundary))mutate();
      });f.duringRead(null);
    assert.ok(reached,boundary+' injection must be exercised');
    assert.notEqual(proof.result.status,200,boundary+' must reject stale receiver execution');
    assert.equal(proof.result.data.mutation_committed,false);
    assert.equal(proof.result.data.item,undefined);
    assert.ok(proof.callbacks.some(row=>row.writes>0),'must test attempted writes followed by rollback');
    assert.equal(proof.after,proof.before,'no accepted channel/event/operation may commit after revocation');
  }
});

test('ACK commit-lost is recovered by the same receiver original key after withdrawal without a second receipt write',async()=>{
  const f=await fixture(),item=await submitted(f,'ack-original'),key=crypto.randomUUID();
  f.loseNextResponse();
  await assert.rejects(()=>f.change('acquisition_handoff_receipt',item,
    {decision:'accept',evidence_reference:'evidence:'+crypto.randomUUID().replaceAll('-','')},f.tokens.resource,key),/response lost/);
  const doc=f.operationDoc('acquisition_handoff_receipt',key,'resource');
  const stored=structuredClone(f.data.docs().get(doc));assert.equal(stored.revision,3);
  f.restart();
  async function check(status,consent) {
    const proof=await observed(f,()=>f.status('acquisition_handoff_receipt',key,f.tokens.resource));
    assert.equal(proof.result.status,200);noWrites(proof);assert.equal(proof.before,proof.after);
    const receipt=proof.result.data.operation_receipt;
    assert.equal(receipt.original_execution_confirmed,true);
    assert.equal(receipt.original_operation.historical_status,'accepted');assert.equal(receipt.original_operation.revision,3);
    assert.equal(receipt.current_handoff.status,status);assert.equal(receipt.current_handoff.current_consent_valid,consent);
    assert.equal(receipt.current_handoff.historical_resource_receipt_recorded,true);
    assert.equal(receipt.current_handoff.receipt_evidence_independently_verified,false);
    assert.equal(receipt.verified_cash_cents,null);assert.equal(receipt.verified_paid_commission_cents,null);
    assert.equal(receipt.auto_retry,false);return receipt;
  }
  await check('accepted',true);
  const accepted=(await f.call('acquisition_handoff_detail',{channel_id:item.channel_id},f.tokens.resource)).data.item;
  const withdrawn=await f.change('acquisition_handoff_withdraw',accepted,{reason_code:'customer_withdrew'});
  assert.equal(withdrawn.status,200);await check('withdrawn',false);
  assert.deepEqual(f.data.docs().get(doc),stored,'historical ACK operation metadata stays immutable');
  assert.equal([...f.data.docs().values()].filter(row=>row.operation==='acquisition_handoff_receipt'&&row.payload_hash).length,1);
});
