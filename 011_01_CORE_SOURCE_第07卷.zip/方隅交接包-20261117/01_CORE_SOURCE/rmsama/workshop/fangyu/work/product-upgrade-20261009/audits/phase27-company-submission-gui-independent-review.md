# Phase27 新 GUI 证据独立交叉核对

本次仅读 root 新 Phase27 动作/loaded/state 记录、固定 synthetic GUI helper/worker 与五张截图，未打开 GUI、重跑产品/API测试、读取合成或原数据库、执行网络/账号动作，未修改生产。动作日志与截图在下述范围自洽；不以 Phase25 旧 GUI 替代本次证明。

## 动作与原号事实

actions 共 12 行，均 synthetic_only=true：2 次 preparation GET、1 次 registration GET、5 次 submission GET，共 8 次 GET；1 次 register、1 次 submit；另两行是固定合成接收/撤回控制。所有 GET 的实际本机 SQLite iterdump 前后 hash 相等，database_unchanged=true。日志本身没有 SQL trace 计数，不能将 dump 相等改写成此日志独立量化了所有 SQL 零写；云 worker 的 read 分支另有完整内存 docs 不变及双 callback writes=0 断言。

register 与 submit 首次均为提交后丢响应的合成错误，mutation_committed=null；worker 计数依次 0/0/0→1/0/1→1/1/1，此后一直 1 register、1 submit、1 channel。提交请求是原 handoff/origin/本机 revision 3/company revision 1 四字段，没有新 key、联系人或正文。后续五次 submission GET 中，首项为 not_attempted+current source matched+eligible，history registration_source_verified=false；另外四项为 recorded+execution_confirmed=true且 eligible=false。

四次 recorded GET 的原 attempt 整结构各相同：同 attempt id、state=unknown、expected_company_revision=1、created_at=updated_at=1791619187。原 submit operation 整结构也不变：同 channel、revision=2、historical_status=submitted、self hash verified=true/full historical chain=false。GET 没有修复 unknown 行或再次提交。这里 recorded 是按原号查到历史事实，不能把本机 unknown 改写成已保存回执；查询 mutation=false/no_dispatch 只证明本次查询范围。

公司当前状态按 revision 2 submitted→3 accepted→4 withdrawn；原 submit history revision 2 保留。撤回后 current consent=false，本机也为 withdrawn/revision 4/preparation_usable=false；historical_resource_receipt_recorded=true 保留，receipt_evidence_independently_verified=false 始终不变。现金、已付提成均 null；平台、财务、跨机验真均 false。

接收由固定 worker 使用 engine.tokens.resource 调用实际 service receipt action，成熟 synthetic fixture 的 receivers.resource=['resources']，resource 与来源 source 不同，返回 authenticated=true。它证明合成不同 mapped 账号路径及后续历史保留，不证明真实资源部本人操作、跨机送达、独立接收证据、成交或付款。fixture 接收不写本机 dump；fixture 撤回同时改变本机 handoff，所以该行 dump_changed 正常，不能混进 GET 零变更统计。

gateway 成功外层是 result/storage_scope/cross_machine_verified 三字段，公开 DTO 在 log.result.result。五次 submission GET 均为 company_handoff_submission_v1 的 36 字段；直接取 log.result.state 会误报 null。company clock 是合成夹具固定 clock，不能把固定 occurred_at 当生产墙钟或真实送达时刻。

## Loaded 与可见截图

state 绑定 pid=46364、port=64695；assets 32 行为 16 种 UI 资产各加载两次，均同 pid、同 SHA。16 UI、启动记录的 13 Python 与 8 cloud source 共 37 项均与本次读取的盘面一致。helper、B fixture 与专用 GUI worker 的内容 SHA 也和 state 记录相同。源码对应 app 50DD120B…、ops F5E05C20…、submission F305884C…、cloud ledger F1237B20…。state 明示 formal_app_or_service_booted=false、original_data_accessed=false，real platform/cloud/model requests=0；这是实际浏览器操作下的本机合成服务/SDK 接口内存适配器，不是实际云 SDK 事务引擎或正式生产部署。

已逐张查看 outputs/产品升级 中五张 root 新 JPG：勾选确认、结果未知原号核对、原号已提交分层状态、合成接收证据待核对、撤回后保留历史。画面中分别可见已勾选的确认框/按钮、只读原号且不重复提交、历史来源 echo 未保存但不抹去原提交、接收已登记但证据待核对、当前撤回且历史提交/ACK仍保留。截图是约 305 像素宽的窄屏对话和不同滚动位置；本审只读原生截屏文件，不把它说成目标 1586 桌面完整布局、整屏像素认可或用户内容认可。未使用另外的“首次确认”上部历史截图作为五项替代。

本核对没有发现这些直接证据的新语义缺口；它没有新增测试数量，也不证明整个任务完成、原账号恢复或实际资源部交付。

## 新 proof 引用核对

B 新 `phase27-company-submission-gui-proof.json` SHA 0E11F9209ACBCBDAEAC54F0BB01ADB6055E31E8583B468C54DF88EDDD873A61D，与本次直接日志核对一致：12/8/1/1/1、unknown 原 attempt、历史 submitted 保留、不同 mapped synthetic receiver、独立验真 false/null 金额以及真实云/SDK 引擎未验分类均准确。其动作日志 SHA 368A2FDC…与当前文件相同，五项当前代表加一项另列的历史上部截图引用 SHA 6/6 匹配；历史上部截图仅核 hash，不替代已查看的五图。

B 新 loaded verification 的 16 UI/13 Python/8 cloud source，与直接 assets/state、当前 disk 及当前 16 项 UI freeze 一致；helper/fixture/worker、asset log 与 freeze 的嵌套 SHA 引用也一致。static verification 列出的 19 个 binary 资产 SHA 与当前 source asset 文件一致，16 frozen UI 数量准确；其 5 unknown-path reject 是 B 本次 verifier 执行证据，本审仅核报告与引用，没有重复调用 serveSite。当前 UI freeze B35B8FCE…与 history/phase-26.json 中旧 EFB8DE39…分开，不用旧冻源替新 source。candidate143/backup28由B封存，未在本窄 GUI 核对中扩大为全量历史/candidate 重验。

本报告和独立 manifest 封存后停止修改。C 本轮新增产品/API测试数为零；之前 Phase27 C backend 独二保持原冻结计数，不与此日志核对叠计。
