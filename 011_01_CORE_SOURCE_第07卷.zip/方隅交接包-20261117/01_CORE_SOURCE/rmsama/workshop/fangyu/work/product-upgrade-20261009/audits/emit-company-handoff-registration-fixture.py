"""Actual local Core/origin -> actual service/store SDK-interface fixture.

Synthetic only. No HTTP, real cloud, platform, provider or SDK engine call.
"""
from copy import deepcopy
from pathlib import Path
from tempfile import TemporaryDirectory
import hashlib
import json
import socket
import sys
from unittest.mock import patch

PROJECT=Path(__file__).resolve().parents[3]
sys.path[:0]=[str(PROJECT/'work/app/src'),str(PROJECT/'work/app/tests')]
from test_company_handoff_registration import RegistrationFixture,TEMP
from assistant.company_handoff_registration import GET,REGISTER,CompanyHandoffRegistrationError
from assistant.company_handoff_preparation import GET as PREPARATION_GET


def generate():
    TEMP.mkdir(parents=True,exist_ok=True)
    cases={};envelopes={};operations={}
    with TemporaryDirectory(dir=TEMP) as base,patch.object(socket.socket,'connect',side_effect=AssertionError('network forbidden')):
        fixture=RegistrationFixture(Path(base)/'normal')
        lost=RegistrationFixture(Path(base)/'lost')
        unknown=RegistrationFixture(Path(base)/'unknown')
        try:
            preparation_before=fixture.dump()
            preparation_get=fixture.f.preparation.execute(PREPARATION_GET,
                {'handoff_id':fixture.f.handoff['id']},deepcopy(fixture.f.actor))
            assert preparation_before==fixture.dump()
            def collect(name,f):
                before=f.dump();result=f.call(GET)
                assert before==f.dump()
                preparation=f.f.preparation.execute(PREPARATION_GET,
                    {'handoff_id':f.f.handoff['id']},deepcopy(f.f.actor))
                assert before==f.dump()
                cases[name]=dict(request={'handoff_id':f.f.handoff['id']},result=result,
                    preparation_get_result=preparation,local_database_unchanged=True)
                envelopes[name]=deepcopy(f.envelopes);operations[name]=deepcopy(f.operations)
            collect('not_attempted',fixture)
            result=fixture.call(REGISTER)
            recorded_preparation=fixture.f.preparation.execute(PREPARATION_GET,
                {'handoff_id':fixture.f.handoff['id']},deepcopy(fixture.f.actor))
            cases['first_recorded']=dict(request=deepcopy(fixture.data),result=result,
                preparation_get_result=recorded_preparation,
                cloud_register_calls=fixture.command({'kind':'counts'})['register_calls'])
            envelopes['first_recorded']=deepcopy(fixture.envelopes);operations['first_recorded']=deepcopy(fixture.operations)
            collect('recorded_get',fixture)
            lost.lose_response=True
            try:lost.call(REGISTER)
            except CompanyHandoffRegistrationError as error:
                assert error.mutation_committed is None
            else:raise AssertionError('response must be synthetically lost')
            lost.command({'kind':'restart'});lost.service=lost.make_service()
            collect('response_lost_recorded',lost)
            assert lost.command({'kind':'counts'})['register_calls']==1
            fixture.withdraw();collect('withdrawn_historical',fixture)
            # Deliberately controlled transport timeout: actual server status
            # remains unknown; it is not a second server commit-loss example.
            unknown.service.cloud_register=lambda *_:(_ for _ in ()).throw(TimeoutError('synthetic result unavailable'))
            try:unknown.call(REGISTER)
            except CompanyHandoffRegistrationError as error:assert error.mutation_committed is None
            collect('attempt_unknown',unknown)
            names=['work/app/src/assistant/company_handoff_registration.py',
                'work/app/src/assistant/company_handoff_registration_transport.py',
                'work/app/src/assistant/company_handoff_preparation.py','work/app/src/assistant/company_handoff_original_status.py',
                'work/app/src/assistant/company_handoff_source_binding.py','work/cloud/workspace/service.cjs',
                'work/cloud/workspace/handoff-ledger.cjs','work/cloud/workspace/source_binding.cjs',
                'work/cloud/workspace/contact_ledger.cjs','work/app/tests/test_company_handoff_registration.py',
                'work/product-upgrade-20261009/audits/company-handoff-registration-sdk-worker.cjs']
            return dict(synthetic_only=True,fixture_execution='actual_Core_and_createService_createStore',
                transaction_engine='sdk_interface_compatible_memory_double_callback_adapter',
                real_cloud_called=False,cloud_network_called=False,platform_called=False,provider_called=False,
                prepared_result=fixture.prepared,preparation_get_result=preparation_get,
                request=deepcopy(fixture.data),cases=cases,
                actual_company_envelopes=envelopes,cloud_read_transaction_counts=operations,
                response_loss_recovery_register_calls=1,unknown_case_uses_controlled_transport_timeout=True,
                source_sha256={name:hashlib.sha256((PROJECT/name).read_bytes()).hexdigest().upper() for name in names})
        finally:
            for item in (fixture,lost,unknown):item.close()


if __name__=='__main__':
    target=Path(__file__).with_name('company-handoff-registration-actual-fixture.json')
    target.write_text(json.dumps(generate(),ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(str(target))
