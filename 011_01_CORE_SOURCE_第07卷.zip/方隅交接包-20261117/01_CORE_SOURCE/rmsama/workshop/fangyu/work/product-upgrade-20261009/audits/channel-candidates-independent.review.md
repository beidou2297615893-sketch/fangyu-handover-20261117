# 公司交接候选：云与本机独立审查

日期：2026-10-10。当前切片仅新增审查文件、独立测试及本项目 tmp 合成数据；未改 root/B/D 的生产源码、旧测试、旧 phase8 报告或 fixture。未访问原数据库、真实客户、网络、provider、平台、付款、部署；不把计划、离线 SDK replay 或代码存在写成线上已验。

## 结论与计数

两个独立实际反例已经修复；当前未发现新的阻断，可按本次源码 SHA 冻结本切片。本人独立云测试 5/5、本机测试 1/1 通过。前端另见 `business-channel-candidates-ui-independent.review.md`，7/7。复跑不累计；root 的 backend 295 已包含此本机独 1，不能再次加入。B/D 的必要组、root UI 组没有由本人重跑或重复计数。

## 实际 RED → GREEN

1. 云事件类型不兼容。初读 `channel_candidates.cjs:31` 错误加入 `draft_saved/prepared`，漏成熟 contact/journal 的 `copied/external_reported`。本人测试真实 `contact_events_sync` 成功归档 copied，再真实 register 成功创建候选；新发现查询返回 409。

```text
copied is one of the mature seven immutable journal kinds
409 !== 200
tests 5 / pass 4 / fail 1
```

当时 cloud helper SHA：`8FA646A5AFEF5645BA84E9BD759A494690E97A9D195F801DD6305FC0112CF119`。B 将白名单对齐真实七类后，本人原测试覆盖 copied、external_reported 两类并通过，最终云 5/5。

2. 本机旧 cursor 没有绑定设备。>5 个真实本机事件、云全部 not_recorded 时获得 older cursor。同 actor/company 的另一当前合法 device helper 可以复用旧 cursor；没有 recorded source 触发后续 device 校验，已出一次云请求并返回元数据。

```text
AssertionError: BusinessReconciliationError not raised
Ran 1 test ... FAILED (failures=1)
```

当时本机 helper SHA：`F557C5C8B8C8784ADAE5EF3219909E5966DC12246311F61FF3EF95B04CADD1F1`。D 在新 helper 中用 canonical hash(snapshot fingerprint, device_id) 绑定 cursor、云前、最终范围；旧 phase8 helper 未改。本人原 actual Core/new helper 测试重跑 1/1，通过，且旧 cursor 在云调用前拒绝。

本机代表使用真实可丢弃 Core/journal/handoff 与真实新 helper；云回执是明确注入的合成合同。它不冒充真实 SDK 云链路。云 5 例使用 actual createService/createStore 的合成 SDK 回放，不替换生产业务函数。

## 独立代表与读取预算

| 本人实际运行的测试 | 证据 |
| --- | --- |
| copied / external_reported | 真实成熟归档、register、发现路径；不依赖 sent 或本机 ACK；不升级为 exact 交接对应 |
| 索引追加与跨主体游标 | 原 count=6 的续页在新增第7个记录后 409；改成当前 count 也不能给另一 actor 授权；伪 actor/owner/company payload 拒绝 |
| 旧缺 owned index | 即使真实同源 channel 存在也明确 index_unavailable、complete=false、count=null，零写入且不声称没有渠道 |
| 源 fingerprint 冲突 | 整体 409，不返回旧候选或原评论/联系方式 |
| 5 个完整来源 + 10 条混合 audited rows + 5 个最终候选复核 | 第5个匹配在第10条扫描出现；实际入口事务 replay 各1读/0写；发现事务 replay 各59读/0写；低于100次上限 |
| 新设备旧 no-cloud-source cursor | 本人实际 Core/new helper；pre-cloud SCOPE_CHANGED，云调用数不增加 |

最终云 5 例运行：2775.2556 ms。本机独 1 最终源码再复跑：1/1，0.294 s。

```text
node --test --test-reporter=tap work/product-upgrade-20261009/audits/channel-candidates-independent.test.cjs
python work/product-upgrade-20261009/audits/test_channel_candidates_independent.py -v
Actual SDK callback replay counts:
[[{"reads":1,"writes":0},{"reads":1,"writes":0}],
 [{"reads":59,"writes":0},{"reads":59,"writes":0}]]
```

59 是本次实测最难代表，不宣称所有未来 schema 或 caller 均为相同次数。

## 当前源码与必要边界

- 复用 mature handoff owned index：`handoff-ledger.cjs:89` 按注册顺序 append，50 条/页；`:122` 注册写入 `index:source:<hash(actor.username)>`。新 helper 内部从 saved session actor 推导路径，客户端 event/hash/count/offset 都不是权限凭据。
- 云 `channel_candidates.cjs:21`、`:70`、`:91`、`:97` 核 company、未禁用 admin/operator、当前真实 session/有效期和完整 principal；最终所有候选 readBoundItem 后再做完整 principal 比较。只读 source_results 保留完整 canonical hash；source owner、customer/device/platform/author/comment/lead/text hash、已有 contact fingerprint 均须吻合。内部窄 readBoundItem 校验最新审计 snapshot/chain 和当前 withdrawal/consent。
- 索引倒序扫描≤10、输出≤5；达到5候选时立即停在实际 scanned offset，下一页从 next_offset 继续，不吞第6项。count 前后复核，真实 append 改变后旧 continuation 要重开。
- 本机从本人合法 handoff + 当前 lead 权限和不可变 journal 取≤5个源摘要；全成熟七种 kind 可进入，不根据 ACK 决定云记录存在。SQL 窗口 LIMIT6 用第6项判断 older；未新增 event→lead 索引，不能宣称大 journal 检索为常量时间。当前 scoped invalid JSON 明确 AUDIT_CONFLICT，不能变成假 no_local_sources。
- 本机每个源都走已有 `_owned_event` 的 raw/canonical payload hash、reply/lead 与完整 journal chain 验证；云前再读 saved actor/源/交接 fingerprint，最终重读全部窗口和 fresh actor/device范围。本机 source 结果对 device/owner/full hash 再核；public items 过滤原事件、客户 UID、原文本、哈希明细和受保护引用。
- opaque cursor 是一致性约束，不是签名授权；即使客户端改 offset/anchor，也必须经过同 actor/company/device/sourcewindow 核验。`scan.complete` 只表示当前扫描到 owned index 末尾，不证明之前所有页都扫描过，更不证明全公司无渠道。
- source 相同仅证明完整事件对应。多个同源渠道不自动选择或绑定；撤回/无当前同意的历史候选保留只读核对能力，不能再送达。用户选中后必须原经营 detail 再核，不使用候选替代 detail。
- 财务 proof 保持 false/null，无币种推断、金额、支付、资金账或合计；no-local/no-cloud/index-unavailable/partial/complete 各自独立，0匹配不等于全局不存在。

## 冻结 SHA256

| 文件 | SHA256 |
| --- | --- |
| channel_candidates.cjs | 759670533DD394A86718B56A20B2D261A41F39941EF6D2E047CA66E71FDF6924 |
| service.cjs | 17D21D918D3E17559AA48E3F6DB342FC86DE112172B4DB8D9043E016AA0412A7 |
| channel-candidates-fixture.cjs | 48B66A737AA7C9EDCEB0866E1B28DC193E6164731EBFB9379E71207E772613FA |
| business_channel_candidates.py | 9BAD50C34576374ADF7A64DF3BD543B8B499A90FC0F9D36ED8CA2400F69833EA |
| channel-candidates-independent.test.cjs | 2D1820197EE07F3B4DBE6971846F4C3F7A7A9DA38E297362FC5BCD37FE5D0318 |
| test_channel_candidates_independent.py | 1831CF330AD495D4523B53232760A6B6B30CFCE8ECA4C4B7502D49A7C789F3D2 |

文件：`C:/积木软件工坊/项目/方隅公寓客户版/work/product-upgrade-20261009/audits/channel-candidates-independent.review.md`

文件夹：`C:/积木软件工坊/项目/方隅公寓客户版/work/product-upgrade-20261009/audits`
