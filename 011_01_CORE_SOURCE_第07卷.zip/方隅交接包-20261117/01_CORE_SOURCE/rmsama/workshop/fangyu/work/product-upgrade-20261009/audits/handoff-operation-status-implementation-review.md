# 公司交接按原动作与原编号核对：云候选窄读层冻结

## 完成内容与边界

新增云 read action `acquisition_handoff_operation_status`，复用已有 `handoff-ledger.cjs` operation 文档、公司事务、repos 和 session 主体；触达生产源仅 `work/cloud/workspace/handoff-ledger.cjs` 与 `service.cjs`。新增独占 `handoff-operation-status.test.cjs` 与无测试注册副作用 `handoff-operation-status-fixture.cjs`；actual API JSON/生成器/报告/日志均留本项目 audits。

先实际读取 B 的 `next-local-handoff-publishing-selection.md` 和 `handoff-original-key-receipt-selection.md`，与 B/root 锁接口后执行。重新评估可发现技能，实际读取 RevOps，取“明确阶段、统一记录源、交接逐次追踪”的最小规则；不采用营销时限/广告量作商业证明，不追加 UI/营销素材技能。成熟现有 createService/createStore/repos 适配比引入新 CRM、另一资金账本或新云组件更符合范围，因此只补缺失的只读状态路由；无新安装、公网研究或 SDK 升级。

未部署、登录真实员工、调用真实云/平台/模型、发送消息、收费支付或操作原数据库。phase10 本人清单和已冻结客户端、phase9/8 本机模块与原 fixture 保持不动；本切片不能让本机交接自动送达公司，也没有建立 exact local handoff mapping。

## 修改前可回退备份

`backups/company-handoff-operation-status/1/manifest.json` 记录两个文件完整相对路径和逐文件复制后 SHA 一致，不覆盖既有备份、不复制业务数据。

* 原 handoff-ledger.cjs：`16A544D72C9DB6E0597E3016C4433216D3B7824E4980FB5638A45166BC04A305`
* 原 service.cjs：`17D21D918D3E17559AA48E3F6DB342FC86DE112172B4DB8D9043E016AA0412A7`

## 固定请求与成功投影

请求仅标准 `environment_id/operation` 与 `operation_action/idempotency_key`。原动作只能现有7写动作：register、submit、receipt、review、withdraw、dispute、order_link 对应的完整 `acquisition_*` 名称。原 key 沿用既有 ASCII 8..128 格式。客户端 owner、company、channel、payload、原 body、时间、verified 或角色字段均拒；查询的 actor/company 只来自当前公司和有效 session。

仓库 key 为 `operation:` + SHA256 canonical `[companyId,currentActor.username,operation_action,idempotency_key]`，不搜索其它员工或全公司。查询管理员自己的 key 不能读到资源部用同 key 的原操作；这种情况下返回未知，不能用管理角色猜原归属。原资源部 receipt 操作可在该员工当前仍有渠道可见性时恢复，原 actor 不必等于 source_owner，但不会因此提升其权限。

标准 fangyu envelope 的成功 data 有 `operation_receipt` 和仅本次查询的 `read_only:true/mutation_committed:false/auto_retry:false`。成功外层不再复制原执行字段。nested receipt 精确为：

* `contract:handoff_operation_receipt_v1`、`read_only:true/mutation_committed:false`、`storage_scope:company_server_ledger`、authenticated_actor、observed_at、原 operation_action/idempotency_key。
* `state:recorded|unknown`、`original_execution_confirmed:true|null`，绝不 false。
* `original_operation:null` 或 `{payload_hash,channel_id,revision,historical_status,occurred_at,historical_event_self_hash_verified:true,full_historical_chain_verified:false}`。
* `current_handoff:null` 或 `{channel_id,revision,status,current_consent_valid,historical_resource_receipt_recorded,receipt_evidence_independently_verified:false}`。
* `auto_retry/platform_delivery_verified/settlement_active/financial_receipt_verified/cooperation_policy_verified` 固定 false；`verified_cash_cents/verified_paid_commission_cents` 固定 null。

顶层本次 query 的 mutation false 只证明查询不写，不能当原 mutation 未提交。原执行确认唯一位于 nested 原字段；缺 doc、同 key 不同 actor、旧历史无 operation doc 均200 unknown/null，不说未执行、未提交或安全重试。查询不创建取消墓碑，不取消迟到原写，不调用原 mutation，不重放、不启动后续请求。

常规 ledger typed/generic 拒绝及新 service 常规拒绝支路会返回本次只读与 `original_execution_confirmed:null`，保留原 key；最外 `index.js` 固定503或既有 service try 外异常仍可能只有安全 error 而没有这些字段，不能泛称所有外层失败都有完整 receipt。缺字段/非法 envelope 的未来客户端必须保持 unknown，不推断原未执行。

没有 publicItem 整拷贝，输出不含正文、平台 UID、原评论号、联系方式、source_event_id、contact_reference、consent/evidence_reference、原请求 body、会话令牌、其它操作人身份或金额。原 key/hash/channel 仅是当前有权主体持有的核对引用，不是单独的权限凭证。

## 完整性与当前范围

原 operation doc 严格5字段 actor/action/payload_hash/channel_id/revision，原 actor/action 与当前请求绑定、64摘要/渠道号/正整数版本逐项核验。register 的渠道号必须确定性等于 `hc_` + 原 operationId，不能指到同一人的另一合法注册记录。

读取原 revision 对应 event，严格 channel/revision/actor/action/occurred_at/status、previous/snapshot/chain 字段格式及 event 自 hash。原 action 的合法历史状态单独枚举。当前渠道用已有 readBoundItem 两遍核最新快照、末 audit、当前查看权限和同意，前后内容/授权一致；旧 revision 不得超过当前版本、旧 source_owner 与当前一致。最后 await 后重新检查 company/session/saved actor/principal 与当前 receiver/manager/source 可见性。

原历史 event 自 hash 与当前末快照核对不是整个历史链、原 body 的重新构建、第三方独立权威或真实平台送达证明。非 register 动作依赖既有可信 operation 文档与历史 event 原 metadata 的绑定；不声称旧 event 存有原 key/body 或可以重新算全部原 payload。

原 register/submit 历史版本/状态/时间与 current_handoff 当前版本/状态/授权分别返回。例如原 submit revision2/submitted，资源部接受后客户撤回到 revision4/withdrawn：原提交仍 recorded/current consent=false，当前保留的完整不同主体 accept receipt 仍 `historical_resource_receipt_recorded=true`；independently_verified=false。完整性不足的 accept 记录拒绝核对，不能靠 authenticated 字面值升级事实。

该历史接收字段只表示当前账本保留的合法 accept 登记，不穷举所有历史接收决定。公司登记、独立部门主体登记、外部内容独立核验、客户实际接收、成交/财务实收和分成实付仍分别区分。

## 只读事务与权益

仅新 status 路由绕过 service 既有 housekeeping 写回：保留 stored，不清过期 session/remembered-device/attempt rows；未初始化的公司也不 bootstrap/迁移。其它既有路由行为保持。权益到期可读原历史，不再要求 handoff 新操作功能；session/主体禁用/当前渠道可见性仍严格核验。

本次验证实际调用项目 createService、createStore、真实 repos/handlers；底层使用兼容 SDK doc/runTransaction 接口的隔离内存 adapter，手工将事务 callback 回放两次验证。真实安装的 node SDK 被既有入口载入，但这些测试**没有执行 node-sdk 内部事务引擎或真实云事务**。不能把 require SDK 当引擎验证，也不能把接口兼容重放称真实线上吞吐/30秒/第二机验收。此限定已与 B/root 同步；无成熟真实引擎离线夹具可复用，本切片不另架云传输或引入付费网络。

正常存在原操作：入口每 callback1读0写，ledger每 callback9读0写；当前已撤回且同意短路时 ledger7读0写。每事务两次回放均相同；document snapshot 查询前后完全不变，均远低于 SDK 100 doc operations 配置界限。该数量是实际仓库调用经隔离接口 adapter 的计数，不是在线 SDK 内部时限/性能结论。

## 代表验证、真实反例与最终数量

先3条代表再扩大必要矩阵：register 已 commit 后模拟响应丢失，重建 service 后只按原 action/key 找回，不新建渠道；原 submit/资源部独立 accept/客户 withdrawal 后正确分列历史与当前；foreign actor 同 key unknown、wrong company拒绝，查询0写。

最终独占新测试 **11/11**：原10必要组覆盖全部7动作、资源部与管理员各自原 actor、missing 不墓碑及之后 fixture 显式原写、权益到期含脏 housekeeping 0写、严格字段/隐私/安全 storage error、op/history corruption、最后 awaited authorization 期间 role/session/company/receiver 变化、空公司不初始化；第11项为 register 确定性错绑回归。

实现前3项400是路由缺失的代表 RED，日志 `handoff-operation-status-representative-red.txt`。真实施工缺陷 RED：原 register doc 指到同一人的另一合法 register channel，API返回200 recorded，应409；root/B发现后，本代理新11项运行 **10绿1红** 保存在 `handoff-operation-status-register-binding-red.txt`，B第6独审原RED另保存在 `handoff-operation-receipt-register-binding-red.log`。修正 register operationId→hc 固定绑定后原反例关闭，最终11/11，日志 `handoff-operation-status-final-green.txt`。

B 独占6项在最终冻结源上 **6/6绿**，原5代表与第6错绑反例均闭合；独立报告/日志由 B 保存，source 不由 B 修改。11+6是不同模块的执行数量，其中错绑是同一事实回归，不因双 callback/重复跑或两个 regression 再扩充唯一场景覆盖。主窗口负责原7云模块75项及新组的一次必要聚合，本代理不重复其回归或修改旧测试。

## actual API fixture 与冻结

`handoff-operation-status-actual-fixture.json` 顶层 `{synthetic_only,request,result,cases,source_metadata}`，result 是实际 createService 返回的 `{status,data}` 标准 fangyu envelope。cases：registered_response_lost、submitted_after_withdrawal、resource_acceptance_after_withdrawal、unknown_original_key、other_actor_same_original_key；各带原 request/result 和每事务每 callback 的真实接口计数。

source_metadata 标明 actual service/createStore/repos + SDK interface memory adapter、sdk_transaction_engine_exercised=false、synthetic_only、无真实 cloud/platform/model、未用原库、未验 exact 本机映射或外部财务。JSON 不包含 token/原源正文/UID/同意引用或订单金额。生成器已冻结；重建会更换合成 key/UUID，不会自动重建已冻结 fixture。

最终 SHA256：

* handoff-ledger.cjs：`7CA948D72A8C93763BFD00E2303BAFA35B6B12AC7450114F414DA301A5195128`
* service.cjs：`6F6BDA5283DE833BEF1A3A49A9D37BA8DF2FAD3F714042D0FAEEBB1D358EC796`
* handoff-operation-status.test.cjs：`9237FCE60E042EB91E8F99CBD43DAB3674EA7FB7CF24B32F4AFDA6D1FD1C9ED3`
* handoff-operation-status-fixture.cjs：`5D8720530768905158DBC1F5BA063F237B9AB7046984507887BC10CEBC9F85FD`
* handoff-operation-status-actual-fixture.json：`850B9E2B0F6B93E55FEB1DA442712A02F20EBE6F6F4C58A9055B8012028CE820`

生产源、新测试/fixture与 API JSON 已冻结。后续仅 manifest/报告整理；没有关闭整个长期任务，也没有声称跨机/真实云/客户经营或商用已经验收。本机 outbox、可信原 attempt 生命周期与前端恢复接口是下一独立阶段，不能把本机缺失会写 cancelled 的 ProductOperationReceipts.status 直接用于此处 unknown，也不能依据本次 query mutation false 清掉原未知写编号。
