# Source37 后的功能接续（2026-10-12）

最新人类要求：暂不改UI、继续功能；真人验证晚些再进行，不再催扫码/原任务找回/人工身份。Computer Use停用，只在桌面客户端操作；当前main/UI不重启、不热patch，不开网页。保留客户数据/会话/未知/失败，暂不打包/部署/发送/付费。原占用结束与新版桌面显示已由用户确认，不重复问。

长目标本轮 get_goal 实际核为 active、无budget；未调用pause/blocked/complete。R01–R25整体未完成。

## 已闭合 Source37

Root实际独审后备份CAS合7目标，9保护源保持，回执 audits/owner-keyword-source-trace-joined.json。备份目录 C:/积木软件工坊/项目/方隅公寓客户版/backups/owner-keyword-source-trace/b5162d243bea4be8ab1dbfece71d366f。中心四文档已实际更新，回执 audits/source37-current-update.json。

新增原搜索成员→一次原评论→原归档同事务安全出处。两不同locator仍1原lead/source、2合法trace；来源身份用原成熟私有helper，trace事件批/回执独立核，原完整联系/交接source proof保留。前端72A32A7E未变可复用先前非作者审。最后动态只PROOF三新因果；旧16/221合成paging仅history分版，不能说最终全16联合通过。Source36优先来源保留。不重测这一闭合链。

最终候选 owner-keyword-source-trace-candidate：FROZEN E0DDA71033DCECF0FCFA48529AA7C2BDDDD8324539BA77D81BE83F4E3BB39A7E；SOURCE_HASHES 49919007ACED95B8A9FFDEABDA88AD33BE37DED07442CD5D0A9214768AEA31E8。后端独审2A3B0E64DCDF1B80B478013C968731D8C46B1AC6EFDC5EB9FDCAE0DD818079A7，前端独审A85B012615E3F94FF193699E76E53F5F9F60C0876E3DD673007A37A37761B1BE。正式父/候选精确pins取实际join回执，不回滚36/37。

automation-14已工具实际更新ACTIVE、原5分钟、同本线程；功能/真人后置规则保留，指向下一Dy切片。不查额度，不购买或重置。

## 当前并行下一切片

已窄读事实：原OwnerDouyinRead五actions只有连接/首20指定视频评论预览/status/cancel，没有保存。当前Dy原purpose archive=False/AI=False必须保持。Wx无权威UID仍preview，不顺带提升ready。

后端作者 /root/v9_status_review：独立 owner-douyin-source-archive-candidate，正式父Source37；先计划已出，正在收敛实现。前端作者 /root/ui_approved_rebuild：独立 owner-douyin-source-archive-frontend-candidate，只必要mjs，先待v9精确contract；v9非作者窄审其JS后纳总候选，ui不能审自己的Dy前端。后端非作者 /root/xhs_real_entry_next：方案审已完成，编码冻结后用followup_task触发最终窄审，不把send_message当重启idle。

首方案 PLAN.md 当时5211B/BDC6B4A4687C26B121178F00F264B13E0A175828694D0DC2AFB543F3C88E07F3；非作者 owner-douyin-source-archive-review-risk/PLAN-REVIEW.md 5573B/6F372C5D5478ADBB3C8052C712818CC0ABFE10B341D37C6395D1EBAED64FAA55。此为初版方案及审查证据，PLAN后续已由作者按三限制收紧，最终pins待freeze。当前CONTRACT.md4211B/8F69180B5772FAA433631F56A32504744CC85A2712D1E778C292FC4201FB465D已发前端；正式代码尚待完成。短reads锁SQL期间public cancel排队，不能称实时抢占；可保存completed必须非空exact _OwnerDouyinOrigin且current真；PRA未知key status会写tombstone，pending不许该新写，既有同key回执metadata恢复继续。

采用独立sealed Dy snapshot/scope、原PRA事务/去重/隐私/同key恢复；不放宽XHS guard，不改原Dy预览archive false，不接genericcallback。新save精确account_id/read_request_id/idempotency_key，status精确account_id/idempotency_key。独立本机写permit默认pending，不签实际平台用途。cap八字段和成功响应的local_source_archive_available由v9定contract，不要猜。前端保存前先存并读回最小memo，unknown只查原key，不自动重存或换号；无新服务端‘确认结束’动作。Source37没有dyFinish；不要按不存在的旧方法开发。必要终态只处理自己的archive marker并弃用dy预览items/context，原dy.memo/outcome保持，不推断物理收尾。普通按钮‘保存至本机’/‘核对保存结果’，不让用户手填技术编号。

最难合法录制单链→原SQL写入/安全同key恢复；只代表pending新写拒绝、先取消/错UID拒绝、终检来源变化回滚、同key不再读及脱敏/旧cap微样。外部window/purpose/provider明确录制，0平台/真人/模型。后端/前端各自候选，非作者必要审后Root备份合；共同池/AI留后继。当前尚无Dy最终freeze/代码测试/正式合入，不将PLAN当成果完成。
