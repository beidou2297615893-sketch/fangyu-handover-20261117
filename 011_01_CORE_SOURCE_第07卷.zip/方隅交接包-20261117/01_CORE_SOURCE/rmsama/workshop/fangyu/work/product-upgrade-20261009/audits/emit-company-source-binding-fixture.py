"""Actual Core/origin -> actual company service/repos via local SDK adapter."""
from copy import deepcopy
from pathlib import Path
from tempfile import TemporaryDirectory
import hashlib
import importlib.util
import json
import socket
import subprocess
import sys
from unittest.mock import patch

PROJECT = Path(__file__).resolve().parents[3]
sys.path[:0] = [str(PROJECT/'work/app/src'), str(PROJECT/'work/app/tests')]
from assistant.company_handoff_preparation import PREPARE, GET
from assistant.company_handoff_source_binding import CompanyHandoffSourceBinding, ACTION

TEMP = PROJECT/'work/product-upgrade-20261009/tmp/company-source-binding-actual'
NODE = Path('C:/Program Files/nodejs/node.exe')


def generate():
    prior = Path(__file__).with_name('emit-company-handoff-original-status-fixture.py')
    spec = importlib.util.spec_from_file_location('original_owned_fixture', prior)
    module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
    TEMP.mkdir(parents=True, exist_ok=True)
    with TemporaryDirectory(dir=TEMP) as base, patch.object(socket.socket, 'connect', side_effect=AssertionError('network forbidden')):
        f = module.local_fixture(base)
        worker = subprocess.Popen([str(NODE), str(Path(__file__).with_name('company-source-binding-sdk-worker.cjs'))],
            stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, encoding='utf-8')
        def command(value):
            worker.stdin.write(json.dumps(value, ensure_ascii=False)+'\n'); worker.stdin.flush()
            answer = json.loads(worker.stdout.readline())
            if 'fixture_error' in answer: raise AssertionError(answer['fixture_error'])
            return answer
        envelopes, counters, active = {}, {}, [None]
        def cloud_read(actor, operation, data):
            assert actor['username'] == 'source' and operation == 'acquisition_source_binding_read'
            value = command({'kind': 'source_read', 'data': data})
            body = value['result']['data']
            assert body['contract'] == 'fangyu-workspace-v1' and body['environment_id'] == 'fixture-env' and body['company_id'] == 'fixture-company'
            envelopes[active[0]], counters[active[0]] = body, value['operations']
            return {key: val for key, val in body.items() if key not in ('contract', 'environment_id', 'company_id')}
        service = CompanyHandoffSourceBinding(f.core, f.tenant, 'source', f.company, cloud_read=cloud_read, **f.options)
        cases, request = {}, {'handoff_id': f.handoff['id']}
        def collect(name):
            active[0] = name
            with f.core.store.connect() as db: before = '\n'.join(db.iterdump())
            result = service.execute(ACTION, request, deepcopy(f.actor))
            with f.core.store.connect() as db: assert before == '\n'.join(db.iterdump())
            cases[name] = {'request': deepcopy(request), 'result': result, 'local_database_unchanged': True}
        try:
            collect('no_origin')
            # A local ACK alone does not prove company presence: deliberately
            # freeze the local original before the independent company fixture sync.
            f.core.contact_journal.acknowledge(f.tenant, 'source', [f.event['event_id']])
            prepared = f.preparation.execute(PREPARE, dict(handoff_id=f.handoff['id'], expected_revision=f.handoff['revision'],
                idempotency_key='actual-source-binding-preparation'), deepcopy(f.actor))
            preparation_get = f.preparation.execute(GET, request, deepcopy(f.actor))
            collect('not_recorded')
            synced = command({'kind': 'sync', 'event': f.event})['result']['data']
            assert f.event['event_id'] in synced['accepted_event_ids']
            collect('matched')
            f.core.store.put('leads', {**f.lead, 'author_id': 'synthetic-replaced-current-uid'})
            collect('stale_uid')
            f.core.store.put('leads', f.lead)
            f.acquisition.execute('handoff_update', dict(id=f.handoff['id'], expected_revision=f.handoff['revision'],
                operation='withdraw', reason_code='customer_withdrew', evidence_reference='evidence:'+'b'*32,
                idempotency_key='actual-source-binding-withdraw'), deepcopy(f.actor))
            collect('withdrawn')
            names = ['work/app/src/assistant/company_handoff_source_binding.py', 'work/cloud/workspace/source_binding.cjs',
                'work/cloud/workspace/service.cjs', 'work/cloud/workspace/contact_ledger.cjs',
                'work/app/src/assistant/company_handoff_preparation.py', 'work/app/src/assistant/company_handoff_original_status.py']
            return dict(synthetic_only=True, fixture_execution='actual_local_core_origin_and_actual_company_service_repositories',
                transaction_engine='sdk_interface_compatible_memory_double_callback_adapter', real_cloud_called=False,
                cloud_network_called=False, scope=dict(environment_id='fixture-env', company_id='fixture-company', owner='source', device_id='fixture-source-device'),
                prepared_result=prepared, preparation_get_result=preparation_get, cases=cases,
                actual_company_envelopes=envelopes, source_transaction_counts=counters,
                source_sha256={name: hashlib.sha256((PROJECT/name).read_bytes()).hexdigest().upper() for name in names},
                local_ack_alone_did_not_prove_company_presence=True)
        finally:
            worker.stdin.close(); worker.wait(timeout=10)
            if worker.returncode: raise AssertionError(worker.stderr.read())
            worker.stdout.close(); worker.stderr.close()
            f.core.close_continuous_scheduler(wait=True); f.core.adapters.close()


if __name__ == '__main__':
    target = Path(__file__).with_name('company-source-binding-actual-fixture.json')
    target.write_text(json.dumps(generate(), ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    print(str(target))
