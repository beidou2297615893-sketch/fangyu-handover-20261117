# Phase17 私有原快照单批入口：独立后端代表审查

当前为修复前阶段记录，尚未整体冻结。新独占测试 `work/app/tests/test_private_strategy_single_batch_entry.py` 执行实际 BusinessExecutor → Core → 成熟私有快照保护和 pipeline，使用临时数据库与合成搜索/评论适配器；没有访问真实账号、Cookie、网络、云、收费模型或 CLI。没有修改生产或旧测试。

本阶段使用 RevOps 的“阶段定义后连接现有流程”原则，复用已有执行器/原快照/原任务，不再新增只读审计层。既有 Phase16 后端394、前台255为历史基线，不表示当前阶段的新入口已经验收。

## 代表范围与首轮结果

四个唯一测试分组；同组子例与重复执行不叠加为新测试数。

1. 原 task ID 明确 `task_run{task_id,max_batches:1}`：实际保存一条合成评论，只有一条 task，没有新 task_save、save、continuous_start/resume 或副本，原 strategy_source 与私有词不变，公共返回不露私词。本快照两词尚未耗尽，不冒充一次执行已完成整个快照。
2. 账号核对后出现 HTTP461：合成外部读取前仍执行成熟 `require_account_safe`，结果失败且零成功合成读取；保留原 task 和 lease，不自动释放或另建。
3. 入口 private guard 后 account_claim 隔离 callback 改变可信状态：已保存的具体 RED 见下。
4. 实际执行成功但交付回执丢失的局部模拟：后续只读 strategy_task_get/workspace_state 能找到同一原 task 与进度，不增加读取次数。该测试没有发送第二条命令。

第四项不证明 BusinessExecutor 自己有 request-key 幂等；它不是此接口的职责。实际 app/local-transport 的原 requestId/commandId 保留和恢复由 root/C 独立验证，不能用本测试中字典键代替成熟运输账本。commandId 尚未取得时，当前成熟客户端没有 requestId 反查接口，只能保留未知并核对原操作，不能称已恢复、自动换号或重发。

## 已保留的真实 RED

入口 `StrategyTasks.guard_task_action` 在 BusinessExecutor 中完成后，`_claim_xhs_account`/首次核对阶段可与存储或公司权限变化交错。旧 Business 随后调用 Core，重新取 task 并执行，却没有在这个间隙之后再次核私有快照与管理资格。

实际合成反例：

| 回调后改变 | 旧结果 |
|---|---|
| task 私有关键词改为与原 snapshot_hash 不符的值 | 适配器实际收到改后的关键词，读取并保存合成评论 |
| 原 lease ID 改变 | 仍进入合成读取 |
| 当前 operatorOwners 撤掉本人 | 仍进入合成读取 |
| 当前策略 enabled=false | 仍进入合成读取 |
| 原 lease expires_at 已过期 | 仍进入合成读取 |
| 当前持久员工 disabled=true | 已由成熟 Core 拒绝，零读取；不列为缺陷 |

前五种是同一必要分组下的风险投影：post-claim 缺少最新私有范围核对；另外原 guard 本身不核 enabled/expiry，所以只重复调用旧 guard 不足以关闭后两例。root 负责窄生产修复，本代理只保留断言和复验。

`private-single-batch-entry-complete-red.txt` 是完整可读首轮日志；4组中3组成功，边界组5个子例失败。`private-single-batch-entry-first-readable.txt` 是前3子例初轮观察。`private-single-batch-entry-first.txt` 保留最早输出，但外层日志打印曾遇 GBK UnicodeEncodeError，属于验证工具输出编码问题，不计产品缺陷；后续显式 UTF-8 完整记录并保留原日志。

RED 源快照见 `private-single-batch-entry-red-hashes.json`：Business `088FE555…`，StrategyTasks `8718BF20…`，Core `ACBD74B1…`。这些是缺陷阶段的历史源，不冒充最终 SHA。

## 当前合成协议样例

`private-strategy-single-batch-entry-actual-fixture.json` 包含实际 `original_task_get`、同一 task 的 preflight、精确 run_request、Business 运行结果、后续 task_get/workspace_state；任务1条，合成 search1/comments1/import1，私词没有进入 JSON。阶段标记 `positive_projection_before_final_boundary_fixes`，明确尚未整体冻结。它用于让新前台测试沿实际字段构造样例，而不是前后台各手写一份成功 DTO。

该 JSON 是实际本机模块和合成适配器链路，不是实际小红书平台、模型意向正确性、用户同意、资源部接收或真实商业结果。本阶段所有数据库和活动记录写入都在项目内新临时 fixture 中，不能把执行测试说成纯读0SQL写。

## 后续验收条件

等 root 生产源稳定后，只复跑这四个必要代表并生成最终 JSON/源 SHA；期间变化必须阻止旧状态进入外部适配器，完整正常样例仍执行同一原 task 单批，未知仍仅读原操作。真实入口/交互/原号运输恢复由 root/C 独证据与真实隔离 GUI 分开统计，不重跑无关旧矩阵。

用户最新已取消自设5%额度停止规则，当前继续授权取代旧暂停阈值；不购买、不重置、不改其他任务。
