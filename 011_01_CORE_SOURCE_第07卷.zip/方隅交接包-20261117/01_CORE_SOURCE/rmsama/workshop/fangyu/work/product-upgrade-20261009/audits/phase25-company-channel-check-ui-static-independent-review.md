# Phase25 公司当前来源核对：独立源码静审

结论：当前仅文案优先级 delta 可保留。未发现需要再改源码的阻塞；C 没有新增或执行 UI 测试矩阵，没有浏览器 GUI 验证。历史静审与当前 delta 分开记录，不把旧源码测试 SHA 宣称为当前源码已执行证据。

## 历史静审范围

此前读盘静审 ops `139BBEDCA105588CDD000A5DB950EF4B525F4773293EACE3A0EC65C66BB43EF7`、app `1834C3A13999FCB94FC0E1C1E0530DD82618C16AA160BB45B6D8BC85D328A1B0`：

- `checkedCompanyChannelCheck` 107–136 严格34字段，绑定原 origin、原渠道与 current local；cash/paid 必须 null，独立来源/平台/资金/submit 能力必须 false。当前来源对应与历史登记回显分别保留。
- prepared 页 547–555 仅明确点击调用 `company_handoff_channel_check_get {handoff_id}`；privateScope、accept、generation、原 origin/revision 排除晚返回。查询不走 generic write/recover，不清原未知操作槽；重查先清旧结果展示。
- 文案 585–601 对 hold 保留来源对应并显示本机暂停；not_attempted 只说本机没有记录，不能断言公司以前没有执行。app 386、394–402 注册 local-only PRODUCT action，cloud-only 先拒，不能落 queued command_submit。
- 六 case actual fixture `company-channel-check-actual-fixture.json` SHA `E0B48BA9165A9EDD606AF9866DB11C40A1970D57809438D3FADE7FAFBDF8A874` 仅作静态字段对应，没有调用 checker 或执行 fixture。

该范围没有证明整个渲染顺序的实际 GUI 效果。Root 后续实屏发现新来源已对应面板与旧 registrationUnconfirmed 顶部提示同时存在，旧提示覆盖顶部当前来源结果；这是 Root 的真实 GUI 证据，非 C 新运行结果。

## 当前唯一 delta

当前 ops SHA `F36A8275FA6767DCFDE7BDDCC5459DC1E7C50025D07CE03A9E0163A0C73FCEEE`；app SHA 保持 `1834C3A13999FCB94FC0E1C1E0530DD82618C16AA160BB45B6D8BC85D328A1B0`。

实际对比 `backups/phase25-channel-check/3/upgrade-operations-ui.mjs`（139B）与当前源码，差异仅 render 末尾 662–665 的四行：当 `channelCheck.current_channel_source_matched` 为 true，最后重设顶部 textContent；hold 明说“当前交付保持暂停”，没有保存原登记回显时明说“原登记回显仍待核对”。

这四行不赋值 registration、registrationUnconfirmed、origin、attempt、unknown 或任何许可字段；不删除旧登记 warning；不触发 register、submit、GET、storage 写入或清槽，不修改原 checklist/作用域门禁。原 609 行 registrationUnconfirmed 的完整警示仍在，公司当前来源核对段的“独立接收、成交与回款仍未核验”仍在。

因此顶部不会再把已取得的“当前来源对应”简化为笼统草稿登记待核对，历史登记回显未知和本机暂停仍如实显示。对 source 无匹配的 unknown/not_attempted/no_origin，此 block 不执行。C 只读 diff 与当前源，不冒领 B 新3或 Root 实屏/总矩阵计数；当前源码的动态验证由其独立证据负责。

## 冻结

当前读后 ops/app hash 与读前一致；C 未改生产、旧测试、旧冻结报告。新静审 manifest 为同目录 `phase25-company-channel-check-ui-static-independent-final-hashes.json`。Phase24 C独3及Phase26诊断计划不因本次展示 delta 改写。
