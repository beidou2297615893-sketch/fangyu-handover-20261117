# 开发诊断原生生命周期：官方能力核对

2026-10-10 主窗口只读查询 Microsoft 官方文档。仅核技术方案，未运行原账号、扫描原DATA或启动浏览器，不等于实际原生生命周期已验。

WebView2 可在创建环境时选择具体 browserExecutableFolder，环境变量也可覆盖选择。当前新host准备固定并核对实际选用版本；仅有本机目录与内容hash不证明平台可用，实际子进程的已选browser exe仍应核对。来源：[CoreWebView2Environment.CreateAsync](https://learn.microsoft.com/en-us/dotnet/api/microsoft.web.webview2.core.corewebview2environment.createasync?view=webview2-dotnet-1.0.3405.78)。

Windows Job Object 可对所关联的进程树管理生命周期；KILL_ON_JOB_CLOSE在最后一个job handle关闭后终止所属树。新host计划先创建挂起子进程，加入本次专属job后才恢复执行；不把旧进程加入job，不终止无关进程。文档支持机制，不证明本轮具体handle未继承、membership与关闭后零活动进程，后者要实际代表验证。来源：[Job Objects](https://learn.microsoft.com/en-us/windows/win32/procthread/job-objects)、[AssignProcessToJobObject](https://learn.microsoft.com/en-us/windows/win32/api/jobapi2/nf-jobapi2-assignprocesstojobobject)。

原账号只读授权与真实开发诊断目的已存在，不借商业运行授权、设备QA或CLI材料制造生产批准。原浏览器天然可能发网络并改其profile；SQLite/账号与任务数据库不写、CLI Cookie不提交是另外的边界。后续执行报告必须分清纯元数据读取、候选机制与实际平台身份观察。
