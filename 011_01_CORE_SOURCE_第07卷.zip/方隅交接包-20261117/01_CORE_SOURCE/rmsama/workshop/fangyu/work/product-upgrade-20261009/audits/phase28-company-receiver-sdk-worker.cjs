/* Actual service/createStore and isolated SDK-interface memory callback replay.
 * No real SDK transaction engine, network, deployment or account. */
'use strict';
const assert=require('node:assert/strict'),readline=require('node:readline');
for(const mod of ['node:http','node:https'])require(mod).request=()=>{throw Error('network forbidden');};
require('node:net').Socket.prototype.connect=()=>{throw Error('network forbidden');};
global.fetch=()=>{throw Error('network forbidden');};
const {fixture}=require('../../cloud/workspace/handoff-operation-status-fixture.cjs');
let engine=null,registerCalls=0,submitCalls=0,receiptCalls=0;
async function command(input){
 if(!engine)engine=await fixture();
 if(input.kind==='tokens')return {tokens:engine.tokens}; // Ephemeral synthetic fixture only, never emitted in DTO/evidence.
 if(input.kind==='sync')return {result:await engine.call('contact_events_sync',{events:[input.event]},'fixture-source-device-token')};
 if(['register','submit','receipt'].includes(input.kind)){
  const operation={register:'acquisition_channel_register',submit:'acquisition_handoff_submit',receipt:'acquisition_handoff_receipt'}[input.kind];
  if(input.kind==='register')registerCalls++;else if(input.kind==='submit')submitCalls++;else receiptCalls++;
  if(input.lose_response)engine.loseNextResponse();
  return {result:await engine.call(operation,input.data,engine.tokens[input.actor|| (input.kind==='receipt'?'resource':'source')])};
 }
 if(input.kind==='read'){
  assert.ok(['acquisition_source_binding_read','acquisition_handoff_operation_status','acquisition_handoff_detail','acquisition_handoff_list'].includes(input.operation));
  engine.data.resetOperations();const before=engine.data.snapshot();
  const result=await engine.call(input.operation,input.data,engine.tokens[input.actor||'source']);
  assert.equal(before,engine.data.snapshot());const operations=engine.data.operations();
  for(const callback of operations)for(const count of callback)assert.equal(count.writes,0);
  return {result,operations,stored_documents_unchanged:true};
 }
 if(input.kind==='withdraw'){
  const detail=await engine.call('acquisition_handoff_detail',{channel_id:input.channel_id},engine.tokens.source);assert.equal(detail.status,200);
  const out=await engine.change('acquisition_handoff_withdraw',detail.data.item,{reason_code:'customer_withdrew'},engine.tokens.source);
  assert.equal(out.status,200);return {changed:true};
 }
 if(input.kind==='restart'){engine.restart();return {restarted:true};}
 if(input.kind==='counts')return {register_calls:registerCalls,submit_calls:submitCalls,receipt_calls:receiptCalls,
  channels:[...engine.data.docs().values()].filter(doc=>doc?.channel_id&&doc?.source_event_id).length};
 throw Error('unknown synthetic command');
}
const lines=readline.createInterface({input:process.stdin,crlfDelay:Infinity});
(async()=>{for await(const line of lines){try{process.stdout.write(JSON.stringify(await command(JSON.parse(line)))+'\n');}
 catch(error){process.stdout.write(JSON.stringify({fixture_error:error.message})+'\n');}}})().catch(()=>{process.exitCode=1;});
