# Phase28 公司接收端最小合同（候选，未部署）

构造：`CompanyHandoffReceiver(core, tenant, owner, company, *, device_id, scope_guard, cloud_read, cloud_receipt, clock=None)`；调用 `execute(action, data, saved_user)`。传输类 `CompanyHandoffReceiverTransport(server, saved_user, *, environment_id, company_id, scope_guard, clock=None)`。来源本机 lead/origin 不是接收端门槛；本机必须有实际有效绑定本人/设备/公司环境。真实公司接收角色来自当前云 `acquisitionPolicy.receivers`，管理员角色本身不授予接收权，来源本人不能自接收。

四个本机动作，参数严格且不接受 actor/owner/key/客户联系方式：

- `company_handoff_received_list {recipient_id?, offset?, limit?}`：默认 0/10，上限15。未选部门先只读本人获权选项，`selection_required:true, selected_recipient_id:null, items:[], total:null, has_more:false`；必须明确选其中一个 id 才读该范围。
- `company_handoff_received_detail {channel_id}`：公司详情和已有本人接收尝试（如存在）原号核对；零本地写。
- `company_handoff_receipt {channel_id, expected_revision, decision, evidence_reference, reason_code?}`：decision 为 accept/reject/needs_information/duplicate/existing_customer；accept 无 reason_code，reject 仅 not_qualified/outside_service_area，其余 reason_code 必须同 decision。证据仅 evidence/document:32hex。原 key 服务端稳定派生，一次 CAS 后最多一个公司写请求；不接受随机新 key。
- `company_handoff_receipt_get {channel_id}`：纯读，本人同原 key 的状态核对；零本地写。重复原写动作不会重发，转原 GET；变决定/证据/版本直接拒绝。

公开 exact36 字段：`contract,operation_action,read_only,mutation_committed,storage_scope,local_only,cross_machine_verified,actor_scope_hash,observed_at,state,item,items,authorized_recipients,selected_recipient_id,selection_required,total,offset,has_more,attempt,original_operation,original_execution_confirmed,eligible_for_receipt,cloud_receipt_requested,auto_retry,contact_delivery,platform_delivery_verified,receipt_evidence_independently_verified,financial_receipt_verified,cooperation_policy_verified,settlement_active,verified_cash_cents,verified_paid_commission_cents,contacts_modified,local_handoffs_modified,platform_requests_started,provider_requests_started`。

固定值：contract=`company_handoff_receiver_v1`，storage_scope=`local_bridge_company_server_ledger`，local_only=false，cross_machine_verified=false；contact_delivery=`platform_reference_only`；auto_retry、平台送达/证据独验/财务/合作政策/结算/contacts_modified/local_handoffs_modified/platform_requests_started/provider_requests_started 均 false；两个 verified 金额 null。observed_at 为可信本机 epoch 整数（>=2020），不是接收发生日。仅获完整公司原号回执时 original_execution_confirmed=true，否则 null，绝不 false。

item exact16：`channel_id,customer_scope_hash,source_actor_scope_hash,platform,recipient_id,recipient_name,purpose,revision,status,current_consent_valid,can_receipt,historical_resource_receipt_recorded,receipt_evidence_independently_verified,contact_delivery,created_at,updated_at`。身份两字段仅公司范围 SHA256；不返回裸 UID/评论/正文/DPAPI/联系方式引用或原始用户名。recipient_name/purpose 通过成熟隐私标签检查。`can_receipt` 仅公司当前权限；真正按钮只能在 detail/get 的 `eligible_for_receipt=true` 后确认，不能从列表这一字段自行发请求。

attempt=null 或 exact7：`state,expected_revision,decision,created_at,updated_at,operation_action,idempotency_key`。state unknown/recorded；operation_action 固定 `acquisition_handoff_receipt`，key64hex。original_operation=null 或 exact6：`channel_id,revision,historical_status,occurred_at,historical_event_self_hash_verified,full_historical_chain_verified`（后者 false，不升级完整历史链证明）。authorized_recipients exact `{id,name}`[]，名字通过成熟隐私检查。

状态/关系：

|场景|state|item/items|attempt|原执行确认|eligible|读/本次修改/本次云写|
|---|---|---|---|---|---|---|
|选部门摘要|list|null/[]|null|null|false|true/false/false|
|已选部门列表|list|null/安全items|未读取|null|false|true/false/false|
|详情无本机attempt|not_attempted|当前item/[]|null|null|当前can_receipt|true/false/false|
|本机attempt原公司号缺失|unknown|当前item/[]|原unknown|null|false|true/false/false|
|写丢回执后GET确认|recorded|当前item/[]|原unknown|true|false|true/false/false|
|本次真实写+原状态确认|recorded|当前item/[]|recorded|true|false|false/true/true|
|当前客户已撤回而原接收存在|recorded|withdrawn/consentfalse|不改|true|false|true/false/false|

非列表 authorized_recipients=[], selected_recipient_id=null, selection_required=false,total/offset=null,has_more=false。列表 `offset` 实际整数；选择后 total 非负整数，has_more 对本页实际长度计算。`not_attempted` 仅本机没有该尝试元数据，不能说公司从未处理；缺公司原号未知不能说未执行。历史真实资源接收登记与当前同意/撤回独立；authenticated 公司人员登记不等于证据独立核验/平台真实性/现金。

错误 `CompanyHandoffReceiverError` 固定前缀 COMPANY_HANDOFF_RECEIVER_：403 身份/当前接收权限，400 参数，409 当前范围/版本/原attempt冲突，503 不可读。明确写前拒绝 mutation_committed=false；CAS提交边界或任何发请求后的未知为 null。read 错误始终 false，且不创建/释放/修补账本。未新增商用许可审批；当前商业权益到期不阻断有权读取或客户安全处理。

本切片只接现有公司资源部接收，不输送 Windows CurrentUser DPAPI 手机号/微信；每人每渠道只保一个原接收尝试，不承诺后续多轮接收决定或其它接收人恢复同人的私有原号。云代码与隔离 SDK接口回放不等于真实部署/服务送达。
