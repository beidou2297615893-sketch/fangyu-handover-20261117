# Phase21 安全记录查询只读身份修复

结论：仅新源码中的 `AssistantService.account_safety_status` 使用成熟只读 principal。在线查询不再创建、重写或复活 users，不再创建 tenant 或升级业务规则。API 参数与返回安全摘要不变。人工记录事件的默认写路径、扫码、账号状态、后台启动和其他身份处理保持原行为。

这不是原账号平台验收，也不是整个正常工作台启动零副作用。未打开、复制或改真实数据库，未读取 Cookie/密钥/密码，未启动真实服务、CLI、云、模型或平台请求，未修改旧冻结 EXE、桌面入口、UI、Phase20 manifest 或其他项目。

## 缺陷与最小修改

此前报告遗漏了在线前置身份写入，原报告 SHA `51D2FC70C4903162C1CAB4A7A115EB9FBC3EB8586E70C4606D33491A83C58A38` 已保为 `phase21-real-account-readiness-before-online-side-effects.md`，当前 readiness 报告已经更正并区分修复前后源码。

修复前链路 `account_safety_status` → `_account_activity_path` → `_safety_user` → `_local_user()` → `BusinessExecutor.principal(read_only=False)`。实际合成 Core/Business 数据库 trace 记录：online 首次查询 INSERT tenants + users；held 和 executor 尚存的 offline 查询 INSERT users。活动摘要本身的纯读不能盖过这些前置 SQL 写入。

只改 `work/app/src/assistant/service.py`：两内部方法增加 `read_only` keyword，默认 `False`；`account_safety_status` 唯独传 `True`，复用 `_local_user(read_only=True)` / `BusinessExecutor.principal(read_only=True)`。现成只读 principal 要求已有保存的 user、同 tenant/owner、cloud_bound、未 disabled；不自动创建用户、不把已禁用用户改回启用。本机返回仍采用 operator 角色，缓存 admin 不被重写或提权。继续复用原 `_get` 和 `_account_access` 约束账号归属。

没有增设 tenant/company 材料门禁。当前成熟模型只凭合法已保存 user 与同 tenant 的本人 account 授权此查询；tenant 文档缺失不会被此查询自动补建，亦未把缺失自动改成新增拒绝条件。该边界在独审合成代表中核实并明确记录。

默认 `False` 保持原 `_safety_user()` / `_account_activity_path()` 和 `record_account_signal` 语义，明确的人工复核仍写事件，仍拒在途操作和 stale revision。离线没有 executor 的既有 bound 路径继续读取保存身份和 activity，不新增写入。

## 真实代表验证及计数

全部数据均为新 tempfile 内实际 Core/SQLite/BusinessExecutor + 实际 AssistantService 方法，无真实账号。未用 stub 的 principal 成功代替数据库证据。查询窗口 trace SQL、比较完整 iterdump、比较账号活动目录文件 SHA；禁止平台 execute、网络 connect、云 callback 和 Popen。Core 初始化与合成 fixture 创建发生于测量窗口之前，不宣称这些初始化本身零写。

- B 新 `test_phase21_account_safety_read_only.py` **3/3，0.682s**：online/held/有 executor 的 offline 查询 0 DML 且 dump/活动文件不变；缺/禁用 user、他人账号、错 tenant 拒且不创建/复活；既有离线读取 0 DML，明确默认身份写路径仍写 users。
- 原 `test_assistant_service.py` 必要 **4/4，1.720s**：held 本人安全记录/信号、恢复 worker 前离线安全记录、在途操作阻止人工复核、stale revision 不能清新警告。旧测试文件未改；这是相关回归，不能计为四个新覆盖。
- C 新独审 **3/3，1.027s**：实际在线安全读取无 DML/文件变动；cached admin 不重写且本机 operator、fresh can_reply；missing/disabled user 拒；missing tenant 沿既有授权读但不重建；三类原人工复核拒绝与明确合法追加。由 C 独立记录，不把 B 的旧 RED 称为 C 自己复现。

三组共 10 个必要测试方法，其中 6 个新增、4 个旧回归；不重复扩展完整 511 后端或 UI 矩阵。

旧实际产品反例日志 `phase21-account-safety-readonly-first-red.txt`：1 个测试方法的三个状态子例均因真实 INSERT 失败。新 3/3 日志 `phase21-account-safety-readonly-own-first-green.txt`、旧 4/4 `phase21-account-safety-readonly-related-regressions.txt` 保留。

最初 miniconda 运行仅发生 `httpx` 缺失 ImportError，独立保为 `phase21-account-safety-readonly-first-run-environment-error.txt`，不是产品 RED；没有安装包，改用项目已成熟 `work/desktop-python/Scripts/python.exe` 后执行原断言。

## 源码冻结

| 文件 | SHA256 |
| --- | --- |
| 修复前 assistant/service.py | `8648CD1587376437A6571033C1E03F22CEF24BE570F7E7E8C9D95AC0D6E59D35` |
| 修复后 assistant/service.py | `4C70366969D75EE801D0121F3ACAC66DA994A70F1F4F281C7C3F412C4EFEE075` |

原文件与对应 hash 在 `work/product-upgrade-20261009/backups/phase21-account-safety-readonly/1/service.py` 和 `manifest.json` 保留。最终新测试、报告与日志 SHA 另见 `phase21-account-safety-readonly-final-hashes.json`。

正常启动仍可能启动 AIWorker、AssistantRunner 云轮询/已排队命令和条件自动更新；本次未改这些路径。原账号手机已正常采用用户最新事实，活实例和电脑会话/平台读取仍由后续真正结果核验。新源通过不等于昨天的冻结 web-demo/原安装程序已包含修复，也不代表新增高意向客户、真实联系或交接已成功。
