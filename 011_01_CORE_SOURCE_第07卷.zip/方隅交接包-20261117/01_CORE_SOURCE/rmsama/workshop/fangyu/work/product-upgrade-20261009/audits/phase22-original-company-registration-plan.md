# 下一切片：本人明确将原准备登记为公司平台线索草稿

结论：优先补“已保存本机原准备 → 本人明确登记到公司”这一处主流程断点。本人现在能够采集、筛选、人工联系和保存交接准备，却还不能从工作台沿原编号完成公司登记。此项直接推进 R03/R07/R21 的资源部协作前段，复用既有云账本；不再造 CRM、套餐、许可审批或新的只读看板。

2026-10-10 本轮仅阅读当前需求台账、功能优先进度、PROGRESS 与实际源码；按此前已读取的 RevOps 生命周期原则判断。没有改生产源码、运行测试、读取真实 DATA、访问账号、执行 Scheduler、调用云/平台/模型或对外发送。子审仅核同一断点，未写文件。本文是下一实施范围建议，不是功能通过或商业验收证明。

## 目标与已存在的成熟路线

目标用户是本人自营获客者：找到有真实来源的高意向客户，经人工核验和客户同意后，把固定对象交给指定资源部，并逐步取得独立接收、订单与回款证据。高意向评级不是成交；公司草稿登记也不是资源部已收到。

|实际文件与位置|现有能力|缺口或必须保留的边界|
|---|---|---|
|`outputs/产品升级/需求交付与证据台账.md` R07/R21（123/137）|本机准备、原公司记录和来源精确只读核对|真实送达、独立接收和第二机器仍未验|
|`work/app/src/assistant/company_handoff_preparation.py` `_cloud_payload`（226）、原准备保存（361–374）|后端构造完整 register 请求；持久原 origin、固定 cloud key、预期 channel、完整 payload hash、源事件/链/窗口|仅保存准备；`no_dispatch_scope=this_preparation_only`，更早公司操作仍 unknown|
|`work/app/src/assistant/product_workspace.py`（29–35、195–225）|prepare/get、original-status、source-binding 专属入口与可信身份/设备/公司首尾门禁|没有公司 register 写动作|
|`work/app/src/web/workspace/upgrade-operations-ui.mjs`（425–546）|保存准备与“核对原公司操作”“核对原来源公司记录”|没有明确登记按钮；不应把本机“登记为待送达”（397）冒称公司提交|
|`work/cloud/workspace/handoff-ledger.cjs` `register`（97–128）、执行（301–311）|固定 actor/action/key 的 operation ledger；全 payload hash 冲突检查；公司 draft/revision 1；来源、接收方、同意、资格、权益核验|直接复用，不改云写语义或造第二账本|
|同云模块 `mutate`（134–152）|后续 submit 才成为 submitted；另一可信资源部主体才可 receipt|这两个阶段继续独立，下一切片不合并执行|
|`work/app/src/assistant/runner.py` `_sync_contacts`（223）及云 `contact_events_sync`|既有来源归档能力|本机 ACK 不证明当前公司原事件存在；缺源时提示按现流程归档，不由本按钮启动 worker 或偷偷同步|

原采集单批/自然续批、任务评论入口、本人处理清单、每日进展、经营结果核对和脱敏导出均已有成熟实现，不列为缺失。当前台账的真实平台/第二机器/财务待验不通过合成样例消除。

## 最小实施接口链（供根确定文件责任）

建议新增本机专属 `company_handoff_register`，客户端只传 `{handoff_id, expected_origin_id, expected_handoff_revision}`。这些预期字段仅防旧页面误操作，不能授予权限；不接受 owner、company、device、source、consent、contact、正文或 cloud key。后端从原持久准备与当前可信范围重算实际请求，UI只作一次明确确认。

候选独立 helper：`CompanyHandoffRegistration(core, tenant, owner, company, *, device_id, scope_guard, lead_access, cloud_read, cloud_register)`；新 helper/tests 为主要增量。根负责 `product_workspace.py` 窄分支和既有准备页确认入口。独立传输层若有必要，由根确定责任；只复用现鉴权/HTTP校验，不能让新入口通过副调用自动续期、补登录、启动后台或改变绑定。所有开发验证使用本地实际 Core/Business 与实际 createService/createStore 的 SDK 接口内存 adapter，无真实公司提交。

调用顺序：

1. 从本人原 handoff 找原准备，核 origin 完整性、原环境/公司/主体/设备；当前有权 lead、UID/comment、原本文 hash、完整 Journal 链、源窗口、客户授权、资格与 handoff revision 均须仍可交付。客户授权已撤回、来源变更或原准备不适用，不创建新的 cloud key。
2. 用现来源精确核对能力检查 **同原 event + payload hash + 当前公司 actor/device** 的公司记录。`not_recorded`、不可读或错主体不登记，也不自动同步；旧 ACK 和 `source_cloud_binding_verified=false` 的事实不能被覆盖。
3. 从原准备重建完整 register body，完整 canonical hash 必须等于持久原值；cloud key/channel 必须原样。由当前云 session/公司的成熟接口再核权限、来源、接收方、未撤回同意、资格和 handoff 权益。
4. 新专属本机 dispatch 元数据先以 SQL 原子 CAS 保存原 origin/key/hash 与可信范围，再执行 **本次一次** register。只存安全元数据/摘要，不重复正文、裸 UID、手机号、微信或凭证。不得复用通用 receipt 的随机前台键，不改原准备实体的历史事实。
5. 实际云 register 当前只返回 `{item, replayed}`，item 可能是重放后的当前状态，不能要求它伪造不存在的原 hash 字段。严格校验这次响应后，复用成熟原 operation-status 读取得到原 key、预期 channel、原 payload hash及历史 register revision 1/draft；核对公司/环境/actor与完整历史链，然后首尾再核当前可信范围。该核对读丢失仍保持未知，不以外层 HTTP 200 补证据。只展示“公司平台线索已登记为草稿”。后续 submit 与资源部 receipt 分别保留原动作与证据层级。

未知边界：新桥开始提交后，无论超时、丢响应、重启或晚身份变化，保留原号及提交未知；后续只用成熟 `company_handoff_original_status` 查询，不换 key、不自动重发。原 status 缺记录只表示 unknown，不能证明旧请求未执行，也不能凭 absence 清槽。原准备的“本次未 dispatch”不证明更早公司操作未执行。已有确认原 register 的原准备应返回/核对原记录，不再发写请求；已有提交未知按原只读恢复。来源或授权变更后，即使历史登记存在，也不能继续交付。

## 当前承接范围的硬限制

现云 `register` 只接受 `platform:<platform>:<stable UID>`，并明确拒绝本机 DPAPI contact 引用。下一切片不解密或向公司透传手机号/微信；页面必须明确这是原平台线索草稿。若资源部合作只接手机号/微信，跨机受保护联系方式交付仍是后续独立需求，不能拿本次 register 成功证明该合作模式已跑通。

该桥不增加许可审批/付款页面，不扩大角色或为本人赋 receiver/admin。云端成熟授权是实际执行门禁，明示确认不等于授权。未部署/未连接时显示当前不可执行，不模拟公司成功。

## 最难代表与业务验收

首先用同一个实际 Core 准备、完整 Journal、当前公司源记录和实际云服务仓库完成：本人明确首次 register → 云 commit 后合成丢响应 → 重启本机 helper → 沿原 origin/key 查询真实历史 register。断言仅一 channel/operation、原 payload/channel/revision 相符；当前撤回后保留历史 register，但交付暂停；恢复期间零额外 register。SDK 接口 adapter 不等于真实云事务引擎或网络。

随后只加必要边界：公司缺/错 event、同 UID 错 comment/device/actor、原 key/body 冲突、同意撤回、晚 actor/device/company 改变及双实例 CAS；任何一项都不能写第二原请求、变成 resource accepted 或泄漏受保护联系方式。普通路径不动，未变 511 模块不为本计划重跑；实施后按实际受影响组验证，由根最终归档。

业务验收用三件可观察事实：本人知道此按钮登记哪一位原客户、哪一个接收方与用途；成功页只多出“公司草稿”事实；丢回执仍能从原交接恢复历史证据并清楚说明当下能否交付。真实独立资源部接收、同客户订单、客户实收和分成实付分别需要真实对方/权威来源，保持原未知/null，不以点击次数或草稿数当成交率。

文件：`C:/积木软件工坊/项目/方隅公寓客户版/work/product-upgrade-20261009/audits/phase22-original-company-registration-plan.md`

文件夹：`C:/积木软件工坊/项目/方隅公寓客户版/work/product-upgrade-20261009/audits`
