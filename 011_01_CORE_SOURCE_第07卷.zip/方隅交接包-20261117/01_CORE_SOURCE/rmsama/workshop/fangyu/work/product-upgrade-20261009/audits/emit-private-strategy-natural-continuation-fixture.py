"""Emit actual offline Core/Business results, never fabricate a UI summary."""
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import sys
import tempfile

PROJECT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(PROJECT / 'work/app/tests'))
from test_private_strategy_completion_summary import CompletionFixture
from assistant.acquisition_strategy import ENTITY

AUDITS = Path(__file__).resolve().parent
SOURCE_FILES = (
    'work/app/src/assistant/business.py', 'work/app/src/assistant/strategy_tasks.py',
    'work/app/src/core/engine.py', 'work/app/src/core/pipeline.py',
    'work/app/src/assistant/acquisition_run_preflight.py', 'work/app/src/assistant/product_workspace.py')


def main():
    parent = PROJECT / 'work/product-upgrade-20261009/tmp/phase20-private-completion'
    parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(dir=parent) as base:
        f = CompletionFixture(base)
        try:
            before = f.core.store.get(ENTITY, f.strategy.ident)
            data = {'synthetic_only': True, 'fixture_kind': 'actual_core_business_no_external_dispatch',
                    'original_task_get': f.read(), 'preflight': f.check(),
                    'run_request': {'action': 'task_run', 'data': {'task_id': f.task_id, 'max_batches': 1}},
                    'lease_before': {'id': before['lease']['id'], 'expires_at': before['lease']['expires_at']}}
            with f.forbid_real():
                data['business_result'] = f.run_batch(1)
                data['post_task_get'] = f.read()
                data['workspace_state'] = f.command('workspace_state')
                data['continuation_task_get'] = f.read()
                data['continuation_preflight'] = f.check()
                assert data['continuation_preflight']['state'] == 'eligible_for_explicit_run', \
                    'actual new import must remain eligible for the second explicit confirmation'
                data['core_summary_after_first'] = deepcopy(f.core.store.get('tasks', f.task_id)['last_result']['summary'])
                lease = f.core.store.get(ENTITY, f.strategy.ident)['lease']
                data['lease_after_first'] = {'id': lease['id'], 'expires_at': lease['expires_at']}
                data['exhausted'] = {'run_request': {'action': 'task_run',
                    'data': {'task_id': f.task_id, 'max_batches': 1}},
                    'business_result': f.run_batch(2), 'post_task_get': f.read(),
                    'workspace_state': f.command('workspace_state')}
            data['evidence'] = {'explicit_business_run_commands': 2,
                'adapter_read_calls': len(f.adapter_calls),
                'tasks_count': len(f.core.store.list('tasks', f.executor.tenant)),
                'leads_count': len(f.core.store.list('leads', f.executor.tenant)),
                'lease_after_exhausted': f.core.store.get(ENTITY, f.strategy.ident)['lease'],
                'auto_dispatch': False, 'lease_extended': False,
                'real_platform_verified': False, 'platform_throughput_verified': False}
            data['source_metadata'] = {name: hashlib.sha256((PROJECT / name).read_bytes()).hexdigest().upper()
                                       for name in SOURCE_FILES}
            target = AUDITS / 'private-strategy-natural-continuation-actual-fixture.json'
            target.write_text(json.dumps(data, ensure_ascii=False, allow_nan=False, indent=2) + '\n', encoding='utf-8')
            print(json.dumps({'path': str(target), 'sha256': hashlib.sha256(target.read_bytes()).hexdigest().upper(),
                              'evidence': data['evidence']}, ensure_ascii=False))
        finally:
            f.close()


if __name__ == '__main__':
    main()
