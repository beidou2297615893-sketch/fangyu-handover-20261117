﻿$ErrorActionPreference='Continue'
[Console]::OutputEncoding=[Text.Encoding]::UTF8
$env:ANDROID_ADB_SERVER_PORT=5047; $adb="V:\work\tools\android-sdk\platform-tools\adb.exe"; $d="emulator-5680"
$e="C:\Users\rmsama\Documents\ChatGPT\答题小程序\每日百题APP\outputs\zhiti-evidence"
$log="$e\p-pay2b-log.txt"; "start $(Get-Date -Format HH:mm:ss)" | Set-Content $log -Encoding UTF8
function L($m){ "$(Get-Date -Format HH:mm:ss) $m" | Add-Content $log -Encoding UTF8 }
function Shot($n){ & $adb -s $d shell screencap -p /sdcard/zt-shot.png; & $adb -s $d pull /sdcard/zt-shot.png "$e\$n.png" | Out-Null; L "shot $n" }
function Dump(){ & $adb -s $d shell uiautomator dump /sdcard/ui.xml | Out-Null; return (& $adb -s $d shell cat /sdcard/ui.xml) -join '' }
function Tap($label){ for($i=0;$i -lt 8;$i++){ $x=Dump; $m=[regex]::Match($x,'<node[^>]*?(?:text|content-desc)="[^"]*'+[regex]::Escape($label)+'[^"]*"[^>]*?bounds="\[(\d+),(\d+)\]\[(\d+),(\d+)\]"'); if($m.Success){ $cx=([int]$m.Groups[1].Value+[int]$m.Groups[3].Value)/2; $cy=([int]$m.Groups[2].Value+[int]$m.Groups[4].Value)/2; & $adb -s $d shell input tap $cx $cy; L "tap '$label' $cx,$cy"; return $true }; Start-Sleep 1 }; L "NOT FOUND '$label'"; return $false }
function Texts(){ $x=Dump; ([regex]::Matches($x,'text="([^"]+)"') | %{ $_.Groups[1].Value }) -join ' | ' }
& $adb -s $d shell am start -n com.jimusoft.dailyhundredapp/com.futureyyy.tijing.MainActivity | Out-Null; Start-Sleep 3
L ("screen: " + (Texts))
for($round=1;$round -le 2;$round++){
  # go home -> pay page
  Tap '查看权益与套餐' | Out-Null
  Start-Sleep 1; Shot "p-5${round}0-pay$round-page-loading"
  Start-Sleep 6; L ("pay page: " + (Texts))
  Tap '单次答题' | Out-Null; Start-Sleep 1
  Tap '支付宝支付' | Out-Null; Start-Sleep 6
  Shot "p-5${round}1-pay$round-after-tap"
  $top=(& $adb -s $d shell dumpsys activity activities | Select-String 'topResumedActivity') -join ''
  L "round $round top: $top"
  L ("round $round texts: " + (Texts))
  # return without paying
  if($top -notmatch 'dailyhundredapp'){ & $adb -s $d shell am start -n com.jimusoft.dailyhundredapp/com.futureyyy.tijing.MainActivity | Out-Null } else { }
  Start-Sleep 4; Shot "p-5${round}2-pay$round-back"; L ("round $round back texts: " + (Texts))
  Tap '返回首页' | Out-Null; Start-Sleep 2
}
"done $(Get-Date -Format HH:mm:ss)" | Set-Content "$e\p-pay2b-done.txt"
