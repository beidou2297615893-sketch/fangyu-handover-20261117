package com.futureyyy.tijing

import com.google.gson.JsonArray
import com.google.gson.JsonObject
import org.xml.sax.Attributes
import org.xml.sax.helpers.DefaultHandler
import java.io.ByteArrayInputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.charset.Charset
import java.nio.charset.CodingErrorAction
import java.text.Normalizer
import java.util.Locale
import java.util.zip.ZipInputStream
import javax.xml.parsers.SAXParserFactory

/** 知题: Excel/CSV/TXT -> the same bank JSON the existing importer reads (port of scripts/import_question_bank.py). */
object TableBankImport {
    class Sheet(val name: String, val rows: List<Map<Int, String>>)

    fun toBankJson(fileName: String, bytes: ByteArray): String {
        val sheets = readSheets(fileName, bytes)
        val records = ArrayList<JsonObject>()
        for (sheet in sheets) records += sheetRecords(fileName, sheet)
        if (records.isEmpty()) throw IllegalArgumentException("未找到题目：表格需要有“题目/题干”和“答案”列")
        val groups = LinkedHashMap<String, MutableList<JsonObject>>()
        records.forEach { groups.getOrPut(QuestionBankIndex.normalize(it.get("question").asString)) { ArrayList() }.add(it) }
        val questions = JsonArray(); val conflicts = JsonArray()
        for ((key, variants) in groups) {
            val signatures = variants.map { listOf(it.get("type"), it.get("answer"), it.get("answer_text"), it.get("options")).toString() }.toSet()
            if (signatures.size > 1) { conflicts.add(JsonObject().apply { addProperty("normalized_question", key); addProperty("question", variants[0].get("question").asString) }); continue }
            val canonical = variants[0].deepCopy()
            canonical.add("sources", JsonArray().apply { variants.forEach { v -> v.getAsJsonArray("sources").forEach(::add) } })
            questions.add(canonical)
        }
        return JsonObject().apply { addProperty("schema_version", 1); add("questions", questions); add("conflicts", conflicts) }.toString()
    }

    fun readSheets(fileName: String, bytes: ByteArray): List<Sheet> = when {
        bytes.size >= 4 && bytes[0] == 'P'.code.toByte() && bytes[1] == 'K'.code.toByte() -> readXlsx(bytes)
        bytes.size >= 8 && (bytes[0].toInt() and 0xFF) == 0xD0 && (bytes[1].toInt() and 0xFF) == 0xCF -> readXls(bytes)
        else -> decodeText(bytes).let { text -> if (Regex("<table", RegexOption.IGNORE_CASE).containsMatchIn(text)) readHtmlTable(text) else listOf(Sheet(fileName.substringAfterLast('.'), readDelimited(text))) }
    }

    // ---- header roles / record building (same rules as import_question_bank.py, plus 选项1-6) ----
    private fun normalizeHeader(value: String) = Normalizer.normalize(value, Normalizer.Form.NFKC).lowercase(Locale.ROOT)
        .replace(Regex("[\\s\\u3000()（）\\[\\]【】,，。．、:：;；.!！?？“”\"'\\-_]+"), "")

    private fun headerRole(value: String): String? {
        val h = normalizeHeader(value)
        if (h in setOf("题干", "问题", "题目", "试题", "题目内容", "题干内容", "试题内容")) return "question"
        if (h in setOf("答案", "正确答案", "正确选项", "参考答案", "标准答案")) return "answer"
        if (h in setOf("题型", "类型", "试题类型", "题目类型")) return "type"
        Regex("(?:选项)?([a-f])").matchEntire(h)?.let { return "option_" + it.groupValues[1].uppercase(Locale.ROOT) }
        Regex("选项([1-6一二三四五六])").matchEntire(h)?.let { m -> val d = m.groupValues[1][0]; val n = if (d in '1'..'6') d - '1' else "一二三四五六".indexOf(d); return "option_" + ('A' + n) }
        return null
    }

    private fun canonicalType(raw: String, hasOptions: Boolean): String {
        val t = normalizeHeader(raw)
        return when {
            "多选" in t -> "multiple"; "不定项" in t -> "indefinite"; "判断" in t || "是非" in t -> "true_false"
            "填空" in t || "简答" in t -> "fill_blank"; "单选" in t -> "single"
            else -> if (hasOptions) "single" else "fill_blank"
        }
    }

    private val TRUE_WORDS = setOf("对", "正确", "√", "✓", "✔", "是", "true", "t", "yes", "y")
    private val FALSE_WORDS = setOf("错", "错误", "×", "✗", "✘", "否", "false", "f", "no", "n")

    private fun sheetRecords(fileName: String, sheet: Sheet): List<JsonObject> {
        val rows = sheet.rows
        val headerAt = rows.indexOfFirst { row -> row.values.mapNotNull(::headerRole).toSet().containsAll(setOf("question", "answer")) }
        if (headerAt < 0) return emptyList()
        val roles = HashMap<String, Int>()
        rows[headerAt].entries.sortedBy { it.key }.forEach { (col, v) -> headerRole(v)?.let { roles.putIfAbsent(it, col) } }
        val out = ArrayList<JsonObject>()
        for (r in headerAt + 1 until rows.size) {
            val row = rows[r]
            val question = row[roles["question"]]?.trim().orEmpty()
            val answerRaw = row[roles["answer"]]?.trim().orEmpty()
            if (question.isEmpty() || answerRaw.isEmpty()) continue
            val options = "ABCDEF".mapNotNull { l -> roles["option_$l"]?.let { row[it]?.trim() }?.takeIf { it.isNotEmpty() }?.let { (l - 'A') to it } }
            val type = canonicalType(roles["type"]?.let { row[it] }.orEmpty(), options.isNotEmpty())
            var answer = ""; var indices = emptyList<Int>(); var answerText = answerRaw
            val a = Normalizer.normalize(answerRaw, Normalizer.Form.NFKC)
            val letters = a.filter { it in 'A'..'F' || it in 'a'..'f' }.uppercase(Locale.ROOT)
            val tf = a.trim().lowercase(Locale.ROOT).let { if (it in TRUE_WORDS) "对" else if (it in FALSE_WORDS) "错" else null }
            if (letters.isNotEmpty() && letters.length == a.replace(" ", "").length) {
                answer = letters.toList().distinct().joinToString(""); indices = answer.map { it - 'A' }; answerText = ""
            } else if (tf != null) {
                answerText = if (answerRaw in setOf("对", "错", "正确", "错误")) answerRaw else tf
                options.firstOrNull { (_, text) -> text.trim().lowercase(Locale.ROOT).let { if (it in TRUE_WORDS) "对" else if (it in FALSE_WORDS) "错" else null } == tf }
                    ?.let { indices = listOf(it.first); answer = ('A' + it.first).toString() }
            } else if (type != "fill_blank" && letters.isNotEmpty()) {
                answer = letters.toList().distinct().joinToString(""); indices = answer.map { it - 'A' }
            }
            out += JsonObject().apply {
                addProperty("id", "$fileName:${sheet.name}:${r + 1}"); addProperty("question", question); addProperty("type", type)
                addProperty("answer", answer); add("answer_indices", JsonArray().apply { indices.forEach { add(it) } }); addProperty("answer_text", answerText)
                add("options", JsonArray().apply { options.forEach { (i, t) -> add(JsonObject().apply { addProperty("index", i); addProperty("text", t) }) } })
                add("sources", JsonArray().apply { add(JsonObject().apply { addProperty("file", fileName); addProperty("sheet", sheet.name); addProperty("row", r + 1) }) })
            }
        }
        return out
    }

    // ---- text: CSV / TSV / TXT ----
    fun decodeText(bytes: ByteArray): String {
        if (bytes.size >= 2 && (bytes[0].toInt() and 0xFF) == 0xFF && (bytes[1].toInt() and 0xFF) == 0xFE) return String(bytes, 2, bytes.size - 2, Charsets.UTF_16LE)
        if (bytes.size >= 2 && (bytes[0].toInt() and 0xFF) == 0xFE && (bytes[1].toInt() and 0xFF) == 0xFF) return String(bytes, 2, bytes.size - 2, Charsets.UTF_16BE)
        val utf8 = runCatching { Charsets.UTF_8.newDecoder().onMalformedInput(CodingErrorAction.REPORT).decode(ByteBuffer.wrap(bytes)).toString() }.getOrNull()
        return (utf8 ?: String(bytes, Charset.forName("GB18030"))).removePrefix("\uFEFF")
    }

    fun readDelimited(text: String): List<Map<Int, String>> {
        val first = text.lineSequence().firstOrNull { it.isNotBlank() }.orEmpty()
        val sep = listOf('\t', ',', ';', '，').maxByOrNull { c -> first.count { it == c } } ?: ','
        val rows = ArrayList<Map<Int, String>>(); var row = HashMap<Int, String>(); val cell = StringBuilder(); var col = 0; var quoted = false; var i = 0
        fun endCell() { if (cell.isNotEmpty()) row[col + 1] = cell.toString().trim(); cell.setLength(0); col++ }
        fun endRow() { endCell(); if (row.isNotEmpty()) rows += row; row = HashMap(); col = 0 }
        while (i < text.length) {
            val c = text[i]
            when {
                quoted && c == '"' && i + 1 < text.length && text[i + 1] == '"' -> { cell.append('"'); i++ }
                c == '"' && (quoted || cell.isBlank()) -> { quoted = !quoted; if (quoted) cell.setLength(0) }
                quoted -> cell.append(c)
                c == sep -> endCell()
                c == '\n' -> endRow()
                c != '\r' -> cell.append(c)
            }
            i++
        }
        endRow(); return rows
    }

    private fun readHtmlTable(html: String): List<Sheet> {
        fun clean(s: String) = s.replace(Regex("<br\\s*/?>", RegexOption.IGNORE_CASE), "\n").replace(Regex("<[^>]+>"), "").let(::unescape).trim()
        val rows = Regex("<tr[^>]*>(.*?)</tr>", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL)).findAll(html).map { tr ->
            Regex("<t[dh][^>]*>(.*?)</t[dh]>", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL)).findAll(tr.groupValues[1])
                .mapIndexed { i, td -> i + 1 to clean(td.groupValues[1]) }.filter { it.second.isNotEmpty() }.toMap()
        }.filter { it.isNotEmpty() }.toList()
        return listOf(Sheet("html", rows))
    }

    private fun unescape(s: String) = Regex("&(#x[0-9a-fA-F]+|#\\d+|amp|lt|gt|quot|apos|nbsp);").replace(s) { m ->
        val e = m.groupValues[1]
        when { e.startsWith("#x") -> String(Character.toChars(e.drop(2).toInt(16))); e.startsWith("#") -> String(Character.toChars(e.drop(1).toInt()))
            else -> mapOf("amp" to "&", "lt" to "<", "gt" to ">", "quot" to "\"", "apos" to "'", "nbsp" to " ")[e]!! }
    }

    // ---- xlsx: java.util.zip + SAX ----
    private fun sax(bytes: ByteArray, onStart: (String, Attributes) -> Unit, onEnd: (String, String) -> Unit) {
        val text = StringBuilder()
        SAXParserFactory.newInstance().newSAXParser().parse(ByteArrayInputStream(bytes), object : DefaultHandler() {
            override fun startElement(uri: String?, localName: String?, qName: String, attributes: Attributes) { text.setLength(0); onStart(qName.substringAfter(':'), attributes) }
            override fun characters(ch: CharArray, start: Int, length: Int) { text.append(ch, start, length) }
            override fun endElement(uri: String?, localName: String?, qName: String) { onEnd(qName.substringAfter(':'), text.toString()); text.setLength(0) }
        })
    }

    private fun Attributes.attr(name: String): String? = (0 until length).firstOrNull { getQName(it) == name || getQName(it).endsWith(":$name") }?.let(::getValue)

    fun readXlsx(bytes: ByteArray): List<Sheet> {
        val entries = HashMap<String, ByteArray>()
        ZipInputStream(ByteArrayInputStream(bytes)).use { zip -> while (true) { val e = zip.nextEntry ?: break; if (!e.isDirectory && e.name.endsWith(".xml") || e.name.endsWith(".rels")) entries[e.name.trimStart('/')] = zip.readBytes() } }
        val shared = ArrayList<String>()
        entries["xl/sharedStrings.xml"]?.let { data ->
            val si = StringBuilder(); var inPhonetic = false
            sax(data, { n, _ -> if (n == "si") si.setLength(0); if (n == "rPh") inPhonetic = true }, { n, t -> when (n) { "t" -> if (!inPhonetic) si.append(t); "rPh" -> inPhonetic = false; "si" -> shared += si.toString() } })
        }
        val rels = HashMap<String, String>()
        entries["xl/_rels/workbook.xml.rels"]?.let { data -> sax(data, { n, a -> if (n == "Relationship") rels[a.attr("Id").orEmpty()] = a.attr("Target").orEmpty().trimStart('/').let { if (it.startsWith("xl/")) it else "xl/$it" } }, { _, _ -> }) }
        val sheetTargets = ArrayList<Pair<String, String>>()
        entries["xl/workbook.xml"]?.let { data -> sax(data, { n, a -> if (n == "sheet") sheetTargets += a.attr("name").orEmpty() to rels[a.attr("id").orEmpty()].orEmpty() }, { _, _ -> }) }
        if (sheetTargets.isEmpty()) entries.keys.filter { it.startsWith("xl/worksheets/") && it.endsWith(".xml") }.sorted().forEach { sheetTargets += it.substringAfterLast('/').removeSuffix(".xml") to it }
        return sheetTargets.mapNotNull { (name, target) ->
            val data = entries[target.replace("/./", "/")] ?: return@mapNotNull null
            val rows = ArrayList<Map<Int, String>>(); var row = HashMap<Int, String>(); var col = 0; var type = ""; var value = ""; val inline = StringBuilder()
            sax(data, { n, a -> when (n) { "row" -> { row = HashMap(); col = 0 }; "c" -> { col = a.attr("r")?.let(::columnIndex) ?: (col + 1); type = a.attr("t").orEmpty(); value = ""; inline.setLength(0) } } }, { n, t ->
                when (n) {
                    "v" -> value = t; "t" -> inline.append(t)
                    "c" -> { val v = when (type) { "s" -> value.trim().toIntOrNull()?.let(shared::getOrNull).orEmpty(); "inlineStr" -> inline.toString(); "b" -> if (value == "1") "TRUE" else "FALSE"; "e" -> ""; else -> value }; if (v.isNotBlank()) row[col] = v.trim() }
                    "row" -> if (row.isNotEmpty()) rows += row
                }
            })
            Sheet(name, rows)
        }
    }

    private fun columnIndex(ref: String): Int = ref.takeWhile { it.isLetter() }.fold(0) { acc, c -> acc * 26 + (c.uppercaseChar() - 'A' + 1) }

    // ---- xls: minimal OLE2 + BIFF8 reader (strings, numbers, RK, formulas' cached values) ----
    fun readXls(bytes: ByteArray): List<Sheet> {
        val workbook = Cfb(bytes).stream("Workbook") ?: Cfb(bytes).stream("Book") ?: throw IllegalArgumentException("无法读取 xls 文件")
        val buf = ByteBuffer.wrap(workbook).order(ByteOrder.LITTLE_ENDIAN)
        val sst = ArrayList<String>(); val sheetNames = HashMap<Int, String>(); val sheets = ArrayList<Sheet>()
        var rows: java.util.TreeMap<Int, HashMap<Int, String>>? = null; var sheetName = ""; var pendingFormula: Pair<Int, Int>? = null
        var pos = 0
        fun put(r: Int, c: Int, v: String) { if (v.isNotBlank()) rows?.getOrPut(r) { HashMap() }?.put(c + 1, v.trim()) }
        while (pos + 4 <= workbook.size) {
            val id = buf.getShort(pos).toInt() and 0xFFFF; val len = buf.getShort(pos + 2).toInt() and 0xFFFF; val d = pos + 4
            if (d + len > workbook.size) break
            when (id) {
                0x0809 -> { val kind = buf.getShort(d + 2).toInt() and 0xFFFF; if (kind == 0x0010) { rows = java.util.TreeMap(); sheetName = sheetNames[pos] ?: "Sheet${sheets.size + 1}" } else rows = null }
                0x000A -> { rows?.let { sheets += Sheet(sheetName, it.values.filter { r -> r.isNotEmpty() }) }; rows = null }
                0x0085 -> { val off = buf.getInt(d); val n = workbook[d + 6].toInt() and 0xFF; val hi = workbook[d + 7].toInt() and 1; sheetNames[off] = if (hi == 1) String(workbook, d + 8, n * 2, Charsets.UTF_16LE) else String(workbook, d + 8, n, Charsets.ISO_8859_1) }
                0x00FC -> { val chunks = arrayListOf(workbook.copyOfRange(d, d + len)); var p = d + len
                    while (p + 4 <= workbook.size && (buf.getShort(p).toInt() and 0xFFFF) == 0x003C) { val l = buf.getShort(p + 2).toInt() and 0xFFFF; chunks += workbook.copyOfRange(p + 4, minOf(workbook.size, p + 4 + l)); p += 4 + l }
                    sst += readSst(chunks) }
                0x00FD -> put(buf.getShort(d).toInt() and 0xFFFF, buf.getShort(d + 2).toInt() and 0xFFFF, sst.getOrNull(buf.getInt(d + 6)).orEmpty())
                0x0204, 0x00D6 -> put(buf.getShort(d).toInt() and 0xFFFF, buf.getShort(d + 2).toInt() and 0xFFFF, biffString(workbook, d + 6))
                0x0203 -> put(buf.getShort(d).toInt() and 0xFFFF, buf.getShort(d + 2).toInt() and 0xFFFF, number(buf.getDouble(d + 6)))
                0x027E -> put(buf.getShort(d).toInt() and 0xFFFF, buf.getShort(d + 2).toInt() and 0xFFFF, number(rk(buf.getInt(d + 6))))
                0x00BD -> { val r = buf.getShort(d).toInt() and 0xFFFF; val first = buf.getShort(d + 2).toInt() and 0xFFFF; val count = (len - 6) / 6
                    for (k in 0 until count) put(r, first + k, number(rk(buf.getInt(d + 4 + k * 6 + 2)))) }
                0x0205 -> if (workbook[d + 7].toInt() == 0) put(buf.getShort(d).toInt() and 0xFFFF, buf.getShort(d + 2).toInt() and 0xFFFF, if (workbook[d + 6].toInt() != 0) "TRUE" else "FALSE")
                0x0006 -> { val r = buf.getShort(d).toInt() and 0xFFFF; val c = buf.getShort(d + 2).toInt() and 0xFFFF
                    if ((buf.getShort(d + 12).toInt() and 0xFFFF) != 0xFFFF) put(r, c, number(buf.getDouble(d + 6)))
                    else when (workbook[d + 6].toInt()) { 0 -> pendingFormula = r to c; 1 -> put(r, c, if (workbook[d + 8].toInt() != 0) "TRUE" else "FALSE") } }
                0x0207 -> pendingFormula?.let { (r, c) -> put(r, c, biffString(workbook, d)); pendingFormula = null }
            }
            pos = d + len
        }
        return sheets
    }

    private fun biffString(b: ByteArray, at: Int): String {
        val n = (b[at].toInt() and 0xFF) or ((b[at + 1].toInt() and 0xFF) shl 8); val flags = b[at + 2].toInt()
        var p = at + 3; if (flags and 0x08 != 0) p += 2; if (flags and 0x04 != 0) p += 4
        return if (flags and 1 != 0) String(b, p, minOf(n * 2, b.size - p), Charsets.UTF_16LE) else String(b, p, minOf(n, b.size - p), Charsets.ISO_8859_1)
    }

    private fun readSst(chunks: List<ByteArray>): List<String> {
        var ci = 0; var p = 0
        fun u8(): Int { while (p >= chunks[ci].size) { ci++; p = 0 }; return chunks[ci][p++].toInt() and 0xFF }
        fun u16() = u8() or (u8() shl 8)
        fun u32() = u16() or (u16() shl 16)
        fun skip(n: Int) { repeat(n) { u8() } }
        val out = ArrayList<String>()
        try {
            u32(); val unique = u32()
            repeat(unique) {
                val cch = u16(); val flags = u8(); var high = flags and 1 != 0
                val runs = if (flags and 0x08 != 0) u16() else 0; val ext = if (flags and 0x04 != 0) u32() else 0
                val sb = StringBuilder(cch)
                while (sb.length < cch) {
                    if (p >= chunks[ci].size) { ci++; p = 0; high = u8() and 1 != 0 }
                    sb.append(if (high) (u8() or (u8() shl 8)).toChar() else u8().toChar())
                }
                skip(runs * 4 + ext); out += sb.toString()
            }
        } catch (_: IndexOutOfBoundsException) { }
        return out
    }

    private fun rk(v: Int): Double { val x = if (v and 2 != 0) (v shr 2).toDouble() else java.lang.Double.longBitsToDouble((v.toLong() and 0xFFFFFFFCL) shl 32); return if (v and 1 != 0) x / 100 else x }
    private fun number(d: Double): String = if (d == Math.floor(d) && Math.abs(d) < 1e15) d.toLong().toString() else d.toString()

    private class Cfb(private val b: ByteArray) {
        private val buf = ByteBuffer.wrap(b).order(ByteOrder.LITTLE_ENDIAN)
        private val shift = buf.getShort(0x1E).toInt(); private val size = 1 shl shift
        private val fat: IntArray
        init {
            val fatSectors = ArrayList<Int>(); for (i in 0 until 109) buf.getInt(0x4C + i * 4).takeIf { it >= 0 }?.let(fatSectors::add)
            var difat = buf.getInt(0x44); var guard = 0
            while (difat >= 0 && guard++ < 10000) { val o = off(difat); for (i in 0 until size / 4 - 1) buf.getInt(o + i * 4).takeIf { it >= 0 }?.let(fatSectors::add); difat = buf.getInt(o + size - 4) }
            fat = IntArray(fatSectors.size * size / 4); var k = 0
            for (s in fatSectors) { val o = off(s); for (i in 0 until size / 4) fat[k++] = if (o + i * 4 + 4 <= b.size) buf.getInt(o + i * 4) else -2 }
        }
        private fun off(sector: Int) = (sector + 1) * size
        private fun chain(start: Int, table: IntArray): List<Int> { val out = ArrayList<Int>(); var s = start; while (s >= 0 && s < table.size && out.size <= table.size) { out += s; s = table[s] }; return out }
        private fun read(start: Int): ByteArray { val out = java.io.ByteArrayOutputStream(); chain(start, fat).forEach { s -> val o = off(s); if (o < b.size) out.write(b, o, minOf(size, b.size - o)) }; return out.toByteArray() }
        fun stream(name: String): ByteArray? {
            val dir = read(buf.getInt(0x30)); val d = ByteBuffer.wrap(dir).order(ByteOrder.LITTLE_ENDIAN)
            var rootStart = -2
            for (e in 0 until dir.size / 128) {
                val o = e * 128; val nameLen = (d.getShort(o + 0x40).toInt() and 0xFFFF).coerceIn(0, 64)
                val entryName = String(dir, o, maxOf(0, nameLen - 2), Charsets.UTF_16LE); val type = dir[o + 0x42].toInt()
                val start = d.getInt(o + 0x74); val length = d.getInt(o + 0x78).toLong() and 0xFFFFFFFFL
                if (type == 5) rootStart = start
                if (type == 2 && entryName.equals(name, ignoreCase = true)) {
                    if (length >= (buf.getInt(0x38).toLong() and 0xFFFFFFFFL)) return read(start).copyOf(length.toInt())
                    val mini = read(rootStart); val miniFatBytes = read(buf.getInt(0x3C)); val mb = ByteBuffer.wrap(miniFatBytes).order(ByteOrder.LITTLE_ENDIAN)
                    val miniFat = IntArray(miniFatBytes.size / 4) { mb.getInt(it * 4) }; val ms = 1 shl buf.getShort(0x20).toInt()
                    val out = java.io.ByteArrayOutputStream(); chain(start, miniFat).forEach { s -> if (s * ms < mini.size) out.write(mini, s * ms, minOf(ms, mini.size - s * ms)) }
                    return out.toByteArray().copyOf(length.toInt())
                }
            }
            return null
        }
    }
}
