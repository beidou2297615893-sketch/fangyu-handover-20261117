﻿$ErrorActionPreference='Continue'
$out="C:\Users\rmsama\Documents\ChatGPT\答题小程序\每日百题APP\outputs\知题-0.4.2-code69"
$jdk=(Get-ChildItem -LiteralPath "V:/work/tools/jdk" -Directory | Where-Object Name -like 'jdk-17*' | Select-Object -First 1).FullName
$env:JAVA_HOME=$jdk; $env:ANDROID_HOME="V:/work/tools/android-sdk"; $env:ANDROID_SDK_ROOT=$env:ANDROID_HOME; $env:GRADLE_USER_HOME="V:/work/gradle-home"
$gradle="$env:USERPROFILE/DailyHundredNativeBuild/work/tijing-toolchain/gradle-8.7/bin/gradle.bat"
$stage="$env:USERPROFILE/DailyHundredNativeBuild/work/tijing-bankassist-build"
$init="C:\Users\rmsama\Documents\ChatGPT\答题小程序\每日百题APP\work\tijing-bankassist\work\network-repositories.init.gradle"
"start $(Get-Date -Format HH:mm:ss)" | Set-Content "$out\unit-tests-start.txt"
& $gradle -p "$stage/android" ':app:testProdDebugUnitTest' --no-daemon --max-workers=2 --console=plain --init-script $init > "$out\unit-tests.log" 2>&1
"exit=$LASTEXITCODE $(Get-Date -Format HH:mm:ss)" | Set-Content "$out\unit-tests-done.txt"
