package com.futureyyy.tijing.payment

import org.junit.Assert.*
import org.junit.Test
import org.json.JSONObject

class GatewayStartBillingTest {
    private class Records:RunLedger {
        val rows=mutableMapOf<String,BillingRun>()
        override fun read(id:String)=rows[id]
        override fun save(run:BillingRun) { rows[run.id]=run }
        override fun freeRemaining()=3
        override fun hasUnknownSubmission()=false
        override fun hasOtherUnresolvedReservation(id:String)=false
        override fun releasingIds()=emptyList<String>()
    }
    @Test fun unknownConfirmationResumesSameRunWithoutNewReservation() {
        val records=Records()
        val transport=object:BillingTransport { override fun request(path:String,method:String,body:JSONObject?,identity:BillingIdentity?):JSONObject = error("unexpected network") }
        val billing=RunBilling(PaymentConfig("","",false),records,transport,{BillingIdentity("owner","token")},{"stable-signature"})
        billing.start("run1","target.pkg","original-tijing-v1")
        try { billing.confirmForGateway("run1") { throw IllegalStateException("network unknown") };fail("expected unknown") } catch (_:IllegalStateException) {}
        assertEquals("gateway_confirming",records.read("run1")?.phase)
        billing.start("run1","target.pkg","original-tijing-v1")
        var confirms=0
        billing.confirmForGateway("run1") { confirms++ }
        billing.confirmForGateway("run1") { confirms++ }
        assertEquals(1,confirms)
        assertEquals("confirmed",records.read("run1")?.phase)
        assertEquals(1,records.rows.size)
    }
}
