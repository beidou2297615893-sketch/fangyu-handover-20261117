package com.futureyyy.tijing.payment

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Handler
import android.os.Looper
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors
import android.provider.Settings

class ModelAuthorization internal constructor(val owner:String,val token:String,val binding:String,val source:String,val deviceDigest:String?,val state:String) {
    override fun toString()="ModelAuthorization(redacted)"
}

/** Original fixed-origin HTTP contract, with no redirects or caller-supplied URLs. */
class AndroidBillingTransport:BillingTransport {
    override fun request(path:String,method:String,body:JSONObject?,identity:BillingIdentity?):JSONObject {
        require(path.matches(Regex("/(?:status|installations|entitlements|free/(?:migrate|reserve|confirm|resume|cancel)|orders(?:/[A-Za-z0-9_-]{1,128}(?:/reconcile)?)?|runs/(?:reserve|[A-Za-z0-9_-]{1,128}/(?:confirm|continue|release|cancel)))")))
        require(method in setOf("GET","POST"))
        val connection=URL(PaymentConfig.ORIGIN+"/api/billing"+path).openConnection() as HttpURLConnection
        try {
            connection.instanceFollowRedirects=false;connection.connectTimeout=15000;connection.readTimeout=15000
            connection.useCaches=false;connection.requestMethod=method;connection.setRequestProperty("Accept","application/json");connection.setRequestProperty("Cache-Control","no-store")
            identity?.let { connection.setRequestProperty("Authorization","Bearer "+it.token) }
            if(body!=null) { val bytes=body.toString().toByteArray(Charsets.UTF_8);connection.doOutput=true;connection.setRequestProperty("Content-Type","application/json");connection.setFixedLengthStreamingMode(bytes.size);connection.outputStream.use { it.write(bytes) } }
            val code=connection.responseCode
            if(code !in 200..299)reject(when(code){401->"AUTH_REQUIRED";402->"PAYMENT_REQUIRED";410->"SERVICE_SUSPENDED";else->"SERVICE_UNCONFIRMED"},when(code){402->"免费次数已用完，请选择套餐；已付款请核对订单。";410->"收款服务暂不可用，已有记录已保留，请勿重复购买。";else->"付款状态尚未确认，请稍后核对，暂勿重复购买。"})
            if(connection.contentType?.substringBefore(';')?.trim()?.lowercase()!="application/json")reject("INVALID_RESPONSE","付款服务返回内容无法确认。")
            val out=java.io.ByteArrayOutputStream()
            connection.inputStream.use { input -> val buffer=ByteArray(2048);while(true) { val n=input.read(buffer);if(n<0)break;if(out.size()+n>65536)reject("INVALID_RESPONSE","付款服务返回内容过大。");out.write(buffer,0,n) } }
            return try { JSONObject(out.toString("UTF-8")) } catch(_:Exception) { reject("INVALID_RESPONSE","付款服务返回内容无法确认。") }
        } catch(e:PaymentFailure) { throw e } catch(_:Exception) { reject("NETWORK_UNCONFIRMED","网络暂时不可用，已有付款记录已保留，请勿重复购买。") }
        finally { connection.disconnect() }
    }
}

class AndroidPaymentRecords(context:Context):PaymentRecords {
    private val store=SecurePaymentStore(context)
    override fun read(slot:String)=store.read(slot)
    override fun write(slot:String,value:String)=store.write(slot,value)
    override fun registration()=store.getOrCreateRegistration()
}

/** A single native owner serializes purchase/recovery. Bearer credentials never enter JavaScript. */
class PaymentRuntime private constructor(context:Context) {
    private val app=context.applicationContext
    private val main=Handler(Looper.getMainLooper())
    private val executor=Executors.newSingleThreadExecutor { r -> Thread(r,"DailyHundredPayment").apply { isDaemon=true } }
    private val config:PaymentConfig=run {
        val type=Class.forName("com.futureyyy.tijing.BuildConfig")
        fun field(name:String):Any?=runCatching { type.getField(name).get(null) }.getOrNull()
        PaymentConfig(field("BILLING_API_ORIGIN") as? String ?: "",field("BILLING_ADMISSION_ORIGIN") as? String ?: "",field("BILLING_ADMISSION_ENABLED")==true)
    }
    internal val transport:BillingTransport=AndroidBillingTransport()
    internal val ledger=AndroidRunLedger(app)
    internal val core=PaymentCore(config,AndroidPaymentRecords(app),transport) { url ->
        if(!PaymentCore.trustedCheckout(url))reject("UNTRUSTED_CHECKOUT","收银台地址未获确认。")
        app.startActivity(Intent(Intent.ACTION_VIEW,Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
    internal val runBilling=RunBilling(config,ledger,transport,{core.credential()},{pkg->AndroidRunLedger.targetIdentity(app,pkg)})
    @Volatile private var reconciledListener:(()->Unit)?=null
    fun setReconciledListener(listener:(()->Unit)?) { reconciledListener=listener }
    internal fun enqueue(action:()->Unit) { executor.execute(action) }
    private fun freeDigest():String {
        val androidId=Settings.Secure.getString(app.contentResolver,Settings.Secure.ANDROID_ID)
        return FreeDeviceDigest.derive(androidId)
    }
    internal fun cancelFreeOnWorker(row:BillingRun) {
        if(!ledger.freeServerInitialized())return
        val owner=core.credential()
        FreeService(transport,owner,freeDigest()).action("cancel",row.id,row.binding)
    }
    internal fun confirmFreeOnWorker(id:String) {
        if(ledger.read(id)?.source=="free" && ledger.freeServerInitialized())transcriptionAuthorizationOnWorker(id)
    }
    /** Native worker only; never expose this result through JavascriptInterface or logs. */
    fun transcriptionAuthorization(runId:String):ModelAuthorization {
        require(ID.matches(runId))
        return executor.submit<ModelAuthorization> { transcriptionAuthorizationOnWorker(runId) }.get()
    }
    internal fun transcriptionAuthorizationOnWorker(runId:String):ModelAuthorization {
            val row=ledger.read(runId) ?: reject("RUN_MISSING","答题任务尚未授权。")
            if(row.phase !in setOf("reserved","unknown","receipt_confirmed","confirmed"))reject("RUN_UNAVAILABLE","答题任务尚未授权。")
            return if(row.source=="free") {
                val enabled=runCatching { Class.forName("com.futureyyy.tijing.BuildConfig").getField("BILLING_FREE_DEVICE_LEDGER_ENABLED").get(null)==true }.getOrDefault(false)
                if(!enabled)reject("FREE_SERVICE_DISABLED","免费服务暂不可用。")
                val identity=core.ensureCredential()
                val digest=freeDigest()
                val free=FreeService(transport,identity,digest)
                if(!ledger.freeServerInitialized()) { free.migrate(ledger.legacyFreeEntries(runId));ledger.markFreeServerInitialized() }
                val operation=if(row.phase=="confirmed") "confirm" else "reserve"
                free.action(operation,runId,row.binding)
                ModelAuthorization(identity.owner,identity.token,row.binding,"free",digest,if(row.phase=="confirmed") "confirmed" else "reserved")
            } else {
                if(row.source !in setOf("credit","subscription"))reject("RUN_UNAVAILABLE","答题权限尚未确认。")
                if(row.phase=="receipt_confirmed")reject("SETTLEMENT_UNCONFIRMED","本次使用结算尚未确认，请先核对。")
                val identity=core.credential()
                ModelAuthorization(identity.owner,identity.token,row.binding,"paid",null,if(row.phase=="confirmed") "confirmed" else "reserved")
            }
    }
    internal fun gatewayAuthorizationOnWorker(runId:String,targetPackage:String):ModelAuthorization {
        runBilling.start(runId,targetPackage,"original-tijing-v1")
        val row=ledger.read(runId) ?: reject("RUN_MISSING","答题任务尚未授权。")
        if(row.phase=="reserved") transcriptionAuthorizationOnWorker(runId)
        runBilling.confirmForGateway(runId) { freeRun ->
            val identity=core.ensureCredential()
            val free=FreeService(transport,identity,freeDigest())
            free.action("confirm",freeRun.id,freeRun.binding)
        }
        return transcriptionAuthorizationOnWorker(runId)
    }
    fun request(operation:String,payload:JSONObject,done:(Result<JSONObject>)->Unit) {
        if(operation !in setOf("status","refresh","purchase","continue","recover")) { main.post { done(Result.failure(PaymentFailure("INVALID_OPERATION","不支持的付款操作。"))) };return }
        enqueue {
            val result=runCatching {
                when(operation) {
                    "status" -> core.status(ledger.freeRemaining())
                    "refresh" -> { runBilling.recoverReleases(::cancelFreeOnWorker);val verified=core.refresh();if(verified)main.post { reconciledListener?.invoke() };core.view(ledger.freeRemaining()) }
                    "purchase" -> { core.purchase(payload.optString("planId"));core.view(ledger.freeRemaining()) }
                    "continue" -> { core.continuePending();core.view(ledger.freeRemaining()) }
                    else -> { core.recover();core.view(ledger.freeRemaining()) }
                }
            }
            main.post { done(result) }
        }
    }
    companion object {
        @Volatile private var instance:PaymentRuntime?=null
        fun get(context:Context):PaymentRuntime=instance ?: synchronized(this) { instance ?: PaymentRuntime(context).also { instance=it } }
        fun onForegroundIfInitialized() { instance?.request("refresh",JSONObject()) { /* Native checked receipt is only a reauthorization hint. */ } }
    }
}
