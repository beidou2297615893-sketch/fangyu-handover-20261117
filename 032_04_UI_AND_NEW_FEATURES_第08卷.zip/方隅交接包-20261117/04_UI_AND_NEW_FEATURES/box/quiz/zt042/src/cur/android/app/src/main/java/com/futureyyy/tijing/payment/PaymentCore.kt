package com.futureyyy.tijing.payment

import org.json.JSONArray
import org.json.JSONObject
import java.net.URI
import java.security.SecureRandom
import java.util.Base64

/** Adapted from the existing PayClient contracts. No Activity, WebView or answer engine. */
class PaymentFailure(val code:String, message:String):IllegalStateException(message)
internal fun reject(code:String,message:String):Nothing = throw PaymentFailure(code,message)
interface PaymentRecords { fun read(slot:String):String?; fun write(slot:String,value:String); fun registration():String }
class BillingIdentity(val owner:String,val token:String) { override fun toString()="BillingIdentity(redacted)" }
interface BillingTransport { fun request(path:String,method:String="GET",body:JSONObject?=null,identity:BillingIdentity?=null):JSONObject }
data class PaymentConfig(val origin:String,val admissionOrigin:String,val enabled:Boolean) {
    val ready:Boolean get()=enabled && origin==ORIGIN && admissionOrigin==ORIGIN
    companion object { const val ORIGIN="https://1439321968-1w2zycn1o6.ap-shanghai.tencentscf.com" }
}
internal fun JSONObject.requiredText(name:String,pattern:Regex):String {
    val value=opt(name); if(value !is String || !pattern.matches(value)) reject("INVALID_RESPONSE","付款记录无法确认，请勿重复购买。")
    return value
}
internal val ID=Regex("[A-Za-z0-9_-]{1,128}")
internal val PROOF=Regex("[A-Za-z0-9_-]{43}")
internal fun nonnegative(j:JSONObject,k:String):Long {
    val v=j.opt(k)
    if(v !is Int && v !is Long || (v as Number).toLong()<0) reject("INVALID_RESPONSE","付款权益无法确认。")
    return (v as Number).toLong()
}
internal fun nativeRequestId():String=ByteArray(32).also { SecureRandom().nextBytes(it) }.let { Base64.getUrlEncoder().withoutPadding().encodeToString(it) }

class PaymentCore(private val config:PaymentConfig,private val records:PaymentRecords,
    private val transport:BillingTransport,private val openCheckout:(String)->Unit) {
    companion object {
        val amounts=mapOf("once" to 100L,"week" to 590L,"month" to 990L)
        fun trustedCheckout(raw:String):Boolean=runCatching { val u=URI(raw);u.scheme=="https" && u.host=="openapi.alipay.com" &&
            u.port in setOf(-1,443) && u.userInfo==null && u.fragment==null }.getOrDefault(false)
    }
    private var lastStatus:JSONObject?=null
    private var entitlement:JSONObject?=null
    private fun identity(register:Boolean):JSONObject? {
        records.read("identity")?.let { raw ->
            val j=JSONObject(raw);j.requiredText("installationId",ID);j.requiredText("accessToken",PROOF)
            j.optJSONObject("purchaseIntent")?.let { it.requiredText("planId",Regex("once|week|month"));it.requiredText("clientRequestId",Regex("[A-Za-z0-9_-]{8,100}")) }
            return j
        }
        if(!register)return null
        val proof=JSONObject(records.registration());proof.requiredText("requestId",PROOF);proof.requiredText("verifier",PROOF)
        val response=transport.request("/installations","POST",proof)
        if(response.optString("requestId")!=proof.getString("requestId"))reject("IDENTITY_MISMATCH","付款身份无法确认。")
        response.requiredText("installationId",ID);response.requiredText("accessToken",PROOF)
        val saved=JSONObject().put("installationId",response.getString("installationId")).put("accessToken",response.getString("accessToken"))
        records.write("identity",saved.toString());return saved
    }
    fun credential():BillingIdentity {
        val j=identity(false) ?: reject("PAYMENT_REQUIRED","免费次数已用完，请先选择套餐；已付款请核对订单。")
        return BillingIdentity(j.getString("installationId"),j.getString("accessToken"))
    }
    internal fun ensureCredential():BillingIdentity {
        val j=identity(true) ?: reject("IDENTITY_REQUIRED","付款身份无法确认。")
        return BillingIdentity(j.getString("installationId"),j.getString("accessToken"))
    }
    private fun pending():JSONArray=JSONArray(records.read("pending") ?: "[]").also { a ->
        for(i in 0 until a.length()) { val p=a.getJSONObject(i);p.requiredText("id",ID);p.requiredText("planId",Regex("once|week|month"));p.requiredText("clientRequestId",Regex("[A-Za-z0-9_-]{8,100}"));nonnegative(p,"amountFen") }
    }
    private fun live(j:JSONObject)=j.opt("available")==true && j.optString("mode") in setOf("live","production","alipay-official") &&
        j.opt("realPaymentsEnabled")==true && j.opt("taskAdmissionEnabled")==true && j.opt("synthetic")==false && j.opt("testing")==false
    fun status(freeRemaining:Int=0):JSONObject {
        lastStatus=runCatching { transport.request("/status") }.getOrNull()
        return view(freeRemaining)
    }
    private fun available() {
        if(!config.ready) reject("PAYMENT_DISABLED","真实付款尚未开放。")
        val s=transport.request("/status");lastStatus=s
        if(!live(s))reject("PAYMENT_UNAVAILABLE","收款服务暂不可用，请勿重复购买。")
    }
    private fun checkedOrder(j:JSONObject,plan:String,amount:Long?=null,id:String?=null):JSONObject {
        j.requiredText("id",ID)
        val actual=nonnegative(j,"amountFen")
        if(j.optString("planId")!=plan || actual!=amounts[plan] || amount!=null && actual!=amount || id!=null && j.getString("id")!=id)
            reject("ORDER_MISMATCH","付款套餐或金额不一致，订单已保留，请先核对。")
        if(j.optString("status") !in setOf("pending","paid","cancelled","expired","review","refunded"))reject("INVALID_ORDER","付款订单无法确认。")
        return j
    }
    private fun createFromIntent(owner:JSONObject,intent:JSONObject):JSONObject {
        val plan=intent.getString("planId")
        val raw=transport.request("/orders","POST",intent,BillingIdentity(owner.getString("installationId"),owner.getString("accessToken")))
        // Preserve the idempotency key even if the response cannot safely open a checkout.
        val id=raw.requiredText("id",ID)
        val entry=JSONObject().put("id",id).put("planId",plan).put("amountFen",nonnegative(raw,"amountFen")).put("clientRequestId",intent.getString("clientRequestId"))
        val old=pending();val next=JSONArray();for(i in 0 until old.length())if(old.getJSONObject(i).getString("id")!=id)next.put(old.getJSONObject(i))
        next.put(entry);records.write("pending",next.toString())
        return checkedOrder(raw,plan)
    }
    private fun checkout(order:JSONObject) {
        if(order.getString("status")!="pending")reject("ORDER_NOT_PENDING","该订单无需再次付款，请返回核对。")
        val url=order.opt("checkoutUrl") as? String ?: reject("UNTRUSTED_CHECKOUT","收银台地址未获确认。")
        if(!trustedCheckout(url))reject("UNTRUSTED_CHECKOUT","收银台地址未获确认，订单已保留。")
        try { openCheckout(url) } catch(_:Exception) { reject("CHECKOUT_OPEN_FAILED","收银台未能打开，订单已保留，请勿重复购买。") }
    }
    fun purchase(plan:String) {
        if(!amounts.containsKey(plan))reject("INVALID_PLAN","请选择有效套餐。")
        available()
        val owner=identity(true)!!
        if(owner.has("purchaseIntent") || pending().length()!=0)reject("PAYMENT_PENDING","上次付款尚未确认，请先核对订单。")
        val intent=JSONObject().put("planId",plan).put("clientRequestId",nativeRequestId())
        owner.put("purchaseIntent",intent);records.write("identity",owner.toString())
        checkout(createFromIntent(owner,intent))
    }
    /** Explicit user retry only. A lost response reuses the original durable key. */
    fun recover() {
        available();val owner=identity(false) ?: reject("IDENTITY_REQUIRED","付款身份需要恢复，请勿重复购买。")
        val intent=owner.optJSONObject("purchaseIntent") ?: reject("NO_PENDING_PURCHASE","没有待恢复的购买记录。")
        if(pending().length()!=0)reject("PAYMENT_PENDING","已有订单，请先核对或继续上次付款。")
        checkout(createFromIntent(owner,intent))
    }
    fun continuePending() {
        available();val owner=identity(false) ?: reject("IDENTITY_REQUIRED","付款身份无法确认。")
        val a=pending();if(a.length()!=1)reject("PAYMENT_PENDING","请先核对付款记录。")
        val p=a.getJSONObject(0);val intent=owner.optJSONObject("purchaseIntent") ?: reject("PAYMENT_PENDING","购买记录不完整，请勿重复付款。")
        if(intent.getString("planId")!=p.getString("planId") || intent.getString("clientRequestId")!=p.getString("clientRequestId"))reject("PAYMENT_PENDING","购买记录不一致。")
        val credential=BillingIdentity(owner.getString("installationId"),owner.getString("accessToken"))
        val current=checkedOrder(transport.request("/orders/${p.getString("id")}",identity=credential),p.getString("planId"),p.getLong("amountFen"),p.getString("id"))
        if(current.getString("status")!="pending")reject("ORDER_NOT_PENDING","该订单无需再次付款，请核对状态。")
        val order=checkedOrder(transport.request("/orders","POST",intent,credential),p.getString("planId"),p.getLong("amountFen"),p.getString("id"))
        checkout(order)
    }
    /** Reconcile does not create orders, identities or local entitlements. */
    fun refresh():Boolean {
        entitlement=null
        lastStatus=runCatching { transport.request("/status") }.getOrNull()
        val owner=identity(false)
        if(owner==null) { if(pending().length()!=0)reject("IDENTITY_REQUIRED","付款身份需要恢复，请勿重复购买。");return false }
        val credential=BillingIdentity(owner.getString("installationId"),owner.getString("accessToken"))
        val a=pending();val remaining=JSONArray();var resolvedIntent=false;var failed=false
        for(i in 0 until a.length()) {
            val p=a.getJSONObject(i)
            try {
                val order=checkedOrder(transport.request("/orders/${p.getString("id")}/reconcile","POST",JSONObject(),credential),p.getString("planId"),p.getLong("amountFen"),p.getString("id"))
                if(order.getString("status") in setOf("paid","cancelled","refunded")) {
                    val intent=owner.optJSONObject("purchaseIntent")
                    if(intent!=null && intent.getString("planId")==p.getString("planId") && intent.getString("clientRequestId")==p.getString("clientRequestId"))resolvedIntent=true
                } else remaining.put(p)
            } catch(_:Exception) { failed=true;remaining.put(p) }
        }
        val e=transport.request("/entitlements",identity=credential)
        nonnegative(e,"runCredits");nonnegative(e,"revision")
        if(!e.has("validUntil") || !e.isNull("validUntil") && nonnegative(e,"validUntil")<0 || e.opt("recoverySupported") !is Boolean || e.has("requiresReview") && e.opt("requiresReview") !is Boolean)reject("INVALID_ENTITLEMENT","权益尚未确认。")
        entitlement=JSONObject().put("runCredits",e.getLong("runCredits")).put("validUntil",e.opt("validUntil"))
            .put("revision",e.getLong("revision")).put("recoverySupported",e.getBoolean("recoverySupported"))
            .put("requiresReview",e.opt("requiresReview")==true)
        if(resolvedIntent) { owner.remove("purchaseIntent");records.write("identity",owner.toString()) }
        records.write("pending",remaining.toString())
        return !failed && remaining.length()==0 && !owner.has("purchaseIntent") && e.opt("requiresReview")!=true
    }
    fun view(freeRemaining:Int=0):JSONObject {
        val ready=config.ready && lastStatus?.let(::live)==true
        val plans=JSONArray()
        if(ready)for((id,fen) in amounts)plans.put(JSONObject().put("id",id).put("name",when(id){"once"->"单次答题";"week"->"周套餐";else->"月套餐"}).put("amountFen",fen).put("priceText",String.format(java.util.Locale.ROOT,"¥%.2f",fen/100.0)))
        val owner=identity(false);val p=pending();val intent=owner?.optJSONObject("purchaseIntent")
        val outstanding=if(p.length()>0 || intent!=null) JSONObject().put("planId",intent?.optString("planId") ?: p.optJSONObject(0)?.optString("planId")).put("requiresRecovery",p.length()==0).put("canContinue",p.length()==1 && intent!=null).put("status","unconfirmed") else null
        val verified=entitlement?.takeIf { it.opt("requiresReview")!=true }
        return JSONObject().put("available",ready).put("paymentAvailable",ready).put("paidAdmissionAvailable",ready).put("plans",plans)
            .put("entitlement",verified ?: JSONObject.NULL).put("freeRemaining",freeRemaining.coerceAtLeast(0))
            .put("remainingText",verified?.let { "剩余 ${it.getLong("runCredits")} 次" } ?: "剩余免费 ${freeRemaining.coerceAtLeast(0)} 次")
            .put("pendingPayment",outstanding ?: JSONObject.NULL).put("message",if(ready) "支付宝支付可用" else "付款服务暂未开放")
    }
}
