package com.futureyyy.tijing.payment

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import java.security.SecureRandom
import org.json.JSONObject

/** Installation bearer + purchase intent. Never exposed in task snapshots or exports.
 * Uses the existing app's AndroidKeyStore AES-GCM pattern, with checked synchronous commit.
 * noBackupFilesDir prevents backup/restore of ciphertext without its device-bound key.
 */
class SecurePaymentStore(context: Context) {
  private companion object {
    // The bridge and native admission share these files. AtomicFile reads can
    // remove an in-progress write unless all instances use the same lock.
    val storageLock = Any()
  }
  private val directory = synchronized(storageLock) {
    java.io.File(context.noBackupFilesDir,"billing-v1").apply { check(isDirectory || mkdirs()) }
  }
  private val alias = "daily-hundred-payment-v1"
  private fun file(slot:String): android.util.AtomicFile {
    require(slot in listOf("identity","pending","registration","gateway")) { "付款记录类型无效" }
    return android.util.AtomicFile(java.io.File(directory,"$slot.enc"))
  }
  private fun key():SecretKey {
    val store=KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
    (store.getKey(alias,null) as? SecretKey)?.let { return it }
    return KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore").apply {
      init(KeyGenParameterSpec.Builder(alias,KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
        .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build())
    }.generateKey()
  }
  fun read(slot:String):String? = synchronized(storageLock) {
    val source=file(slot)
    if(!source.baseFile.exists() && !java.io.File(source.baseFile.path+".bak").exists()) return@synchronized null
    try {
      val pieces=source.readFully().toString(Charsets.UTF_8).split(":")
      check(pieces.size==2)
      val cipher=Cipher.getInstance("AES/GCM/NoPadding")
      cipher.init(Cipher.DECRYPT_MODE,key(),GCMParameterSpec(128,Base64.decode(pieces[0],Base64.NO_WRAP)))
      cipher.updateAAD(slot.toByteArray(Charsets.UTF_8))
      String(cipher.doFinal(Base64.decode(pieces[1],Base64.NO_WRAP)),Charsets.UTF_8)
    } catch (_:Exception) { throw IllegalStateException("付款记录无法安全读取，请勿重复购买") }
  }
  fun write(slot:String,value:String) = synchronized(storageLock) {
    val destination=file(slot)
    require(value.toByteArray(Charsets.UTF_8).size<=65536) { "付款记录过大" }
    val cipher=Cipher.getInstance("AES/GCM/NoPadding");cipher.init(Cipher.ENCRYPT_MODE,key())
    cipher.updateAAD(slot.toByteArray(Charsets.UTF_8))
    val encoded=Base64.encodeToString(cipher.iv,Base64.NO_WRAP)+":"+Base64.encodeToString(cipher.doFinal(value.toByteArray(Charsets.UTF_8)),Base64.NO_WRAP)
    val stream=destination.startWrite()
    try {
      stream.write(encoded.toByteArray(Charsets.UTF_8));stream.fd.sync();destination.finishWrite(stream)
      check(destination.readFully().toString(Charsets.UTF_8)==encoded) { "付款记录提交失败" }
    }
    catch(error:Exception) { destination.failWrite(stream);throw IllegalStateException("付款记录未能安全保存",error) }
  }

  /** Create a registration proof once, before network access; never regenerate on retry. */
  fun getOrCreateRegistration():String = synchronized(storageLock) {
    fun checked(raw:String):String {
      val value=JSONObject(raw)
      check(value.length()==2)
      check(value.getString("requestId").matches(Regex("[A-Za-z0-9_-]{43}")))
      check(value.getString("verifier").matches(Regex("[A-Za-z0-9_-]{43}")))
      return raw
    }
    read("registration")?.let { return@synchronized checked(it) }
    val random=SecureRandom()
    fun secret():String {
      val bytes=ByteArray(32);random.nextBytes(bytes)
      return Base64.encodeToString(bytes,Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING)
    }
    val raw=JSONObject().put("requestId",secret()).put("verifier",secret()).toString()
    write("registration",raw)
    val saved=checked(checkNotNull(read("registration")))
    check(saved==raw) { "付款身份未能安全保存" }
    saved
  }
}

