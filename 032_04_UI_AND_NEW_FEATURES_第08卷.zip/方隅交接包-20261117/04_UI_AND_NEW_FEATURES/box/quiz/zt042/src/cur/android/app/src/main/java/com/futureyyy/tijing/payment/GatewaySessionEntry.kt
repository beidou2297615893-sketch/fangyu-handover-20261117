package com.futureyyy.tijing.payment

import android.content.Context
import android.os.Handler
import android.os.Looper
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID

/** Native-only access to the already authorized original TiJing model client. */
class GatewaySession internal constructor(val runId:String,val endpoint:String,val model:String,val apiKey:String,val expiresAt:Long) {
    override fun toString()="GatewaySession(redacted)"
}
object GatewaySessionEntry {
    private const val ORIGIN="https://fh6-d5ga45c0ddae7008c-1439321968.ap-shanghai.app.tcloudbase.com/api/import-ai/v1/openai"
    private val lock=Any()
    private val main=Handler(Looper.getMainLooper())
    private fun prefs(context:Context)=context.applicationContext.getSharedPreferences("gateway-run-v1",Context.MODE_PRIVATE)
    fun getOrCreateRunId(context:Context,targetPackage:String):String = synchronized(lock) {
        require(targetPackage.isNotBlank() && targetPackage!=context.packageName)
        val p=prefs(context);val existing=p.getString("runId",null);val target=p.getString("target",null)
        if(existing!=null) { check(target==targetPackage) { "上次答题任务尚未结束，请先核对。" };return@synchronized existing }
        val id=UUID.randomUUID().toString();check(p.edit().putString("runId",id).putString("target",targetPackage).commit()) { "答题记录未能保存。" };id
    }
    private fun call(path:String,token:String,body:JSONObject?):JSONObject {
        val c=URL(ORIGIN+path).openConnection() as HttpURLConnection
        try {
            c.instanceFollowRedirects=false;c.connectTimeout=15000;c.readTimeout=30000;c.useCaches=false;c.requestMethod="POST"
            c.setRequestProperty("Authorization","Bearer $token");c.setRequestProperty("Content-Type","application/json")
            if(body!=null) { val b=body.toString().toByteArray(Charsets.UTF_8);c.doOutput=true;c.setFixedLengthStreamingMode(b.size);c.outputStream.use { it.write(b) } }
            if(c.responseCode !in 200..299)throw IllegalStateException("答题服务暂不可用，请保留本次任务后重试。")
            val out=java.io.ByteArrayOutputStream();c.inputStream.use { input->val buf=ByteArray(2048);while(true) { val n=input.read(buf);if(n<0)break;if(out.size()+n>8192)throw IllegalStateException("答题授权结果无法确认。") ;out.write(buf,0,n) } }
            return JSONObject(out.toString("UTF-8"))
        } finally { c.disconnect() }
    }
    fun begin(context:Context,runId:String,targetPackage:String,done:(Result<GatewaySession>)->Unit) {
        val app=context.applicationContext;val runtime=PaymentRuntime.get(app)
        runtime.enqueue { val result=runCatching {
            synchronized(lock) { val p=prefs(app);check(p.getString("runId",null)==runId && p.getString("target",null)==targetPackage) { "答题任务信息不一致。" } }
            val auth=runtime.gatewayAuthorizationOnWorker(runId,targetPackage)
            val payload=JSONObject().put("runId",runId).put("taskBinding",auth.binding).put("source",auth.source)
            auth.deviceDigest?.let { payload.put("deviceDigest",it) }
            val response=call("/session",auth.token,payload);val token=response.getString("token");val expires=response.getLong("expiresAt")
            check(token.matches(Regex("[A-Za-z0-9_-]{43}"))&&response.getInt("limit")==160&&expires>System.currentTimeMillis()) { "答题授权结果无法确认。" }
            SecurePaymentStore(app).write("gateway",JSONObject().put("runId",runId).put("token",token).put("expiresAt",expires).toString())
            GatewaySession(runId,ORIGIN,"deepseek-flash",token,expires)
        };main.post { done(result) } }
    }
    fun close(context:Context,session:GatewaySession,done:(Result<Unit>)->Unit) {
        val app=context.applicationContext;PaymentRuntime.get(app).enqueue { val result=runCatching {
            val response=call("/session/close",session.apiKey,null);check(response.optBoolean("closed")) { "答题任务结束状态无法确认。" }
            SecurePaymentStore(app).write("gateway",JSONObject().put("runId",session.runId).put("state","closed").toString())
            synchronized(lock) { val p=prefs(app);if(p.getString("runId",null)==session.runId)check(p.edit().remove("runId").remove("target").commit()) { "答题结束记录未能保存。" } }
            Unit
        };main.post { done(result) } }
    }
    /** Safe recovery after process death or an uncertain close; never creates another run. */
    fun closePending(context:Context,done:(Result<Unit>)->Unit) {
        val app=context.applicationContext;val runtime=PaymentRuntime.get(app)
        runtime.enqueue { val result=runCatching {
            val p=prefs(app);val id=p.getString("runId",null) ?: return@runCatching Unit
            val saved=SecurePaymentStore(app).read("gateway") ?: throw IllegalStateException("本次授权尚未确认，请继续同一任务后结束。")
            val j=JSONObject(saved);check(j.optString("runId")==id) { "答题记录需要核对。" }
            if(j.optString("state")!="closed") { val token=j.getString("token");check(call("/session/close",token,null).optBoolean("closed"));SecurePaymentStore(app).write("gateway",JSONObject().put("runId",id).put("state","closed").toString()) }
            synchronized(lock) { check(p.edit().remove("runId").remove("target").commit()) }
            Unit
        };main.post { done(result) } }
    }
}
