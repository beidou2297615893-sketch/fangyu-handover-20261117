package com.futureyyy.tijing

interface PaidRunEvents {
    fun beforeStart(runId: String, targetPackage: String, bankRevision: String, done: (Result<Unit>) -> Unit)
    fun beforeSubmit(runId: String, intentId: String, questionId: String, done: (Result<Unit>) -> Unit)
    fun onReceipt(runId: String, intentId: String, receiptId: String, done: (Result<Unit>) -> Unit)
    fun onAbandon(runId: String) { onStop(runId) }
    fun onStop(runId: String)
}
