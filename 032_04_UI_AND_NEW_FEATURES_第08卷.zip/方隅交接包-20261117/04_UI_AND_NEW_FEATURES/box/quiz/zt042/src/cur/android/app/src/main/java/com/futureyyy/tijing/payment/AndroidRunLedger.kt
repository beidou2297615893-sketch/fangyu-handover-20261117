package com.futureyyy.tijing.payment

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import org.json.JSONObject
import android.content.pm.PackageManager
import android.os.Build
import java.security.MessageDigest

/** Separate table owner. The old answer database is only read for its existing free-use count. */
class AndroidRunLedger(context:Context):SQLiteOpenHelper(context.applicationContext,"dailyhundred-payment.db",null,1),RunLedger {
    private val app=context.applicationContext
    override fun onCreate(db:SQLiteDatabase) {
        db.execSQL("CREATE TABLE billing_runs(id TEXT PRIMARY KEY,json TEXT NOT NULL)")
        db.execSQL("CREATE TABLE billing_meta(key TEXT PRIMARY KEY,value TEXT NOT NULL)")
    }
    override fun onUpgrade(db:SQLiteDatabase,old:Int,new:Int) { error("不支持的付款记录版本") }
    private fun encode(r:BillingRun)=JSONObject().put("id",r.id).put("binding",r.binding).put("target",r.target).put("revision",r.revision).put("targetIdentity",r.targetIdentity).put("source",r.source).put("phase",r.phase).put("intent",r.intent ?: JSONObject.NULL).put("question",r.question ?: JSONObject.NULL).put("receipt",r.receipt ?: JSONObject.NULL).put("submissionState",r.submissionState).toString()
    private fun decode(s:String):BillingRun { val j=JSONObject(s);fun text(k:String)=if(j.isNull(k))null else j.getString(k)
        return BillingRun(j.getString("id"),j.getString("binding"),j.getString("target"),j.getString("revision"),j.getString("targetIdentity"),j.getString("source"),j.getString("phase"),text("intent"),text("question"),text("receipt"),j.getString("submissionState")) }
    @Synchronized override fun read(id:String):BillingRun?=readableDatabase.rawQuery("SELECT json FROM billing_runs WHERE id=?",arrayOf(id)).use { if(it.moveToFirst())decode(it.getString(0)) else null }
    @Synchronized override fun save(run:BillingRun) {
        val db=writableDatabase;db.beginTransaction()
        try { db.execSQL("INSERT OR REPLACE INTO billing_runs(id,json) VALUES(?,?)",arrayOf(run.id,encode(run)));db.setTransactionSuccessful() } finally { db.endTransaction() }
    }
    private fun legacyCount():Int {
        val db=writableDatabase
        db.rawQuery("SELECT value FROM billing_meta WHERE key='legacyFreeCount'",null).use { if(it.moveToFirst())return it.getString(0).toInt() }
        val path=app.getDatabasePath("native-automation.db")
        val count=if(path.exists())SQLiteDatabase.openDatabase(path.path,null,SQLiteDatabase.OPEN_READONLY).use { old->
            old.rawQuery("SELECT value FROM settings WHERE key='billingUsageV1'",null).use { if(it.moveToFirst())JSONObject(it.getString(0)).length() else 0 }
        } else 0
        db.execSQL("INSERT OR IGNORE INTO billing_meta(key,value) VALUES('legacyFreeCount',?)",arrayOf(count.coerceIn(0,3).toString()))
        return count.coerceIn(0,3)
    }
    @Synchronized override fun freeRemaining():Int {
        val legacy=legacyCount();var current=0
        readableDatabase.rawQuery("SELECT json FROM billing_runs",null).use { c->while(c.moveToNext()) { val row=decode(c.getString(0));if(row.source=="free" && row.phase!="released")current++ } }
        return (3-legacy-current).coerceAtLeast(0)
    }
    @Synchronized fun hasPriorFreeUsage(id:String):Boolean {
        if(legacyCount()>0)return true
        return readableDatabase.rawQuery("SELECT json FROM billing_runs",null).use { c ->
            var found=false
            while(c.moveToNext()) { val r=decode(c.getString(0));if(r.id!=id && r.source=="free" && r.phase!="released") { found=true;break } }
            found
        }
    }
    @Synchronized fun freeServerInitialized():Boolean = readableDatabase.rawQuery("SELECT value FROM billing_meta WHERE key='freeServerInitialized'",null).use { it.moveToFirst() && it.getString(0)=="1" }
    @Synchronized fun markFreeServerInitialized() { writableDatabase.execSQL("INSERT OR REPLACE INTO billing_meta(key,value) VALUES('freeServerInitialized','1')") }
    @Synchronized fun legacyFreeEntries(excludeId:String):Map<String,String> {
        val entries=linkedMapOf<String,String>()
        val path=app.getDatabasePath("native-automation.db")
        if(path.exists()) SQLiteDatabase.openDatabase(path.path,null,SQLiteDatabase.OPEN_READONLY).use { old ->
            old.rawQuery("SELECT value FROM settings WHERE key='billingUsageV1'",null).use { c ->
                if(c.moveToFirst()) { val j=JSONObject(c.getString(0));val keys=j.keys();while(keys.hasNext()) { val id=keys.next();entries[id]=j.getString(id) } }
            }
        }
        readableDatabase.rawQuery("SELECT json FROM billing_runs",null).use { c ->
            while(c.moveToNext()) { val r=decode(c.getString(0));if(r.id!=excludeId && r.source=="free" && r.phase!="released")entries[r.id]=if(r.submissionState=="receipt") "used" else "reserved" }
        }
        return entries
    }
    @Synchronized override fun hasUnknownSubmission():Boolean =
        readableDatabase.rawQuery("SELECT json FROM billing_runs",null).use { c ->
            var pending=false
            while(c.moveToNext()) if(decode(c.getString(0)).submissionState=="unknown") { pending=true;break }
            pending
        }
    @Synchronized override fun hasOtherUnresolvedReservation(id:String):Boolean =
        readableDatabase.rawQuery("SELECT json FROM billing_runs",null).use { c ->
            var pending=false
            while(c.moveToNext()) { val row=decode(c.getString(0));if(row.id!=id && row.phase in setOf("reserving","releasing")) { pending=true;break } }
            pending
        }
    @Synchronized override fun releasingIds():List<String> =
        readableDatabase.rawQuery("SELECT json FROM billing_runs",null).use { c ->
            val ids=mutableListOf<String>()
            while(c.moveToNext()) { val row=decode(c.getString(0));if(row.phase in setOf("reserving","releasing") && row.submissionState=="none")ids.add(row.id) }
            ids
        }
    companion object {
        fun targetIdentity(context:Context,pkg:String):String {
            require(pkg.isNotBlank() && pkg!=context.packageName)
            val p=context.packageManager.getPackageInfo(pkg,if(Build.VERSION.SDK_INT>=28)PackageManager.GET_SIGNING_CERTIFICATES else PackageManager.GET_SIGNATURES)
            val signatures=if(Build.VERSION.SDK_INT>=28)p.signingInfo?.apkContentsSigners else p.signatures
            val hashes=signatures.orEmpty().map { s->MessageDigest.getInstance("SHA-256").digest(s.toByteArray()).joinToString(""){"%02x".format(it)} }.sorted().joinToString(",")
            check(hashes.isNotEmpty()) { "无法核实目标软件身份" }
            return "$pkg:${if(Build.VERSION.SDK_INT>=28)p.longVersionCode else p.versionCode.toLong()}:$hashes"
        }
    }
}
