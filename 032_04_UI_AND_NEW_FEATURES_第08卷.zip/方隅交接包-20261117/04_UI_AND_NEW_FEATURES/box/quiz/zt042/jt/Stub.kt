package com.futureyyy.tijing
import java.text.Normalizer
import java.util.Locale
class QuestionBankIndex { companion object { fun normalize(value: String): String { val n = Normalizer.normalize(value, Normalizer.Form.NFKC).lowercase(Locale.ROOT); return n.filter { it.isLetterOrDigit() || it in '\u3400'..'\u9fff' } } } }
fun main(args: Array<String>) {
  for (f in args) { val b = java.io.File(f).readBytes(); val j = com.google.gson.JsonParser.parseString(TableBankImport.toBankJson(java.io.File(f).name, b)).asJsonObject
    val q = j.getAsJsonArray("questions"); println("$f questions=${q.size()} conflicts=${j.getAsJsonArray("conflicts").size()}"); if (q.size() < 10) q.forEach { println(it) } else println(q[0]); }
}
