# 生成 HTML 源并截图。运行: /workspace/.pwvenv/bin/python build.py
import os
from playwright.sync_api import sync_playwright
D=os.path.dirname(os.path.abspath(__file__))
def sb(dark=True):
    c='#F3EEE4' if dark else '#111'
    return f'''<div class="status"><span>21:08</span><span class="r">
<svg width="16" height="12" viewBox="0 0 16 12"><path d="M8 11.5 0.6 3.6a10.5 10.5 0 0 1 14.8 0z" fill="{c}"/></svg>
<svg width="14" height="12" viewBox="0 0 14 12"><path d="M13.5 0.5v11h-13z" fill="{c}"/></svg>
<svg width="9" height="14" viewBox="0 0 9 14"><rect x="2.5" y="0" width="4" height="2" fill="{c}"/><rect x="0.5" y="1.5" width="8" height="12" rx="1.5" fill="none" stroke="{c}"/><rect x="2" y="5" width="5" height="7" fill="{c}"/></svg></span></div>'''
GEST='<div class="gesture"><i></i></div>'
BACK='<div class="back"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#F3EEE4" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M15 5l-7 7 7 7"/></svg></div>'
def tabbar(on):
    icons={'答题':'<path d="M4 10.5 12 4l8 6.5V20H4z"/><path d="M10 20v-5h4v5"/>',
           '题库':'<path d="M4 5.5c3-1.5 5.5-1.5 8 0v14c-2.5-1.5-5-1.5-8 0z"/><path d="M20 5.5c-3-1.5-5.5-1.5-8 0v14c2.5-1.5 5-1.5 8 0z"/>',
           '记录':'<rect x="5" y="3.5" width="14" height="17" rx="2"/><path d="M9 9h6M9 13h6M9 17h3"/>',
           '我的':'<circle cx="12" cy="8.5" r="4"/><path d="M4.5 20.5c1.2-4 4-6 7.5-6s6.3 2 7.5 6"/>'}
    t=''.join(f'<div class="tab{" on" if k==on else ""}"><svg viewBox="0 0 24 24" fill="none" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round">{v}</svg>{k}</div>' for k,v in icons.items())
    return f'<div class="tabbar">{t}</div><div class="tabbar-pad"></div>'
def page(body,title,solo=False):
    return f'<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=360"><title>{title}</title><link rel="stylesheet" href="yejin.css"></head><body{" class=solo" if solo else ""}>{body}</body></html>'

home=f'''<div class="screen"><div class="bg"></div><div class="layer">{sb()}
<div style="position:absolute;left:28px;top:60px"><div style="font-size:26px;font-weight:300;letter-spacing:6px;color:var(--gold-hi)">每日百题</div><div style="width:44px;height:1px;background:var(--gold);margin-top:12px"></div></div>
<div style="position:absolute;left:64px;top:184px;width:232px;height:232px">
 <svg width="232" height="232" viewBox="0 0 232 232"><circle cx="116" cy="116" r="114" fill="rgba(7,11,22,.35)" stroke="rgba(201,168,106,.22)" stroke-width="1.5"/><circle cx="116" cy="2" r="3.5" fill="#D6B87E"/></svg>
 <div style="position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center">
  <div style="font-size:13px;letter-spacing:4px;color:var(--text-2)">今日</div>
  <div style="display:flex;align-items:baseline;margin-top:2px"><span class="num" style="font-size:84px;line-height:92px;color:var(--gold-hi)">0</span><span class="num" style="font-size:22px;color:var(--text-2);margin-left:4px">/100</span></div>
  <div style="font-size:12px;letter-spacing:3px;color:var(--text-3);margin-top:2px">未开始</div>
 </div></div>
<div style="position:absolute;left:0;right:0;top:448px;display:flex;justify-content:center"><div style="display:flex;align-items:center;gap:10px;height:36px;padding:0 16px;border:1px solid var(--line);border-radius:18px;background:rgba(7,11,22,.4)">
 <span style="font-size:12px;color:var(--text-3);letter-spacing:2px">题库</span><span style="font-size:15px;letter-spacing:1px">铁路题库</span>
 <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#D6B87E" stroke-width="2" stroke-linecap="round"><path d="M9 5l7 7-7 7"/></svg></div></div>
<div class="btn" style="position:absolute;left:32px;right:32px;top:560px">开启答题浮窗</div>
{tabbar('答题')}{GEST}</div></div>'''

doc_icon='<svg width="44" height="44" viewBox="0 0 48 48" fill="none" stroke="#D6B87E" stroke-width="1.3" stroke-linejoin="round" stroke-linecap="round"><path d="M12 5h17l9 9v29H12z"/><path d="M29 5v9h9"/><path d="M24 36V22M18.5 27.5 24 22l5.5 5.5"/></svg>'
imp=f'''<div class="screen"><div class="bg"></div><div class="layer">{sb()}
<div class="appbar" style="padding-left:24px"><h1 style="margin-left:0">上传题库</h1></div>
<div style="position:absolute;left:20px;right:20px;top:132px;height:336px;border-radius:24px;background:var(--surface);border:1px solid var(--line);display:flex;flex-direction:column;align-items:center;padding:40px 24px 28px">
 <div style="width:88px;height:88px;border-radius:44px;border:1px solid var(--line);display:flex;align-items:center;justify-content:center">{doc_icon}</div>
 <div style="font-size:19px;letter-spacing:2px;margin-top:24px">还没有题库</div>
 <div style="font-size:13px;color:var(--text-2);margin-top:10px;letter-spacing:.5px">从手机里选择你自己的题库文件</div>
 <div class="btn" style="width:100%;margin-top:auto">选择文件</div>
</div>
<div style="position:absolute;left:0;right:0;top:496px;display:flex;justify-content:center;gap:14px;align-items:center"><span class="link">粘贴文本导入</span><span style="width:1px;height:12px;background:var(--line)"></span><span class="link">格式说明</span></div>
{tabbar('题库')}{GEST}</div></div>'''

def plan(name,desc,price,sel=False):
    ck=('<svg width="22" height="22" viewBox="0 0 24 24"><circle cx="12" cy="12" r="11" fill="#D6B87E"/><path d="M7 12.3l3.2 3.2L17 8.8" fill="none" stroke="#1B150C" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>' if sel else
        '<svg width="22" height="22" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10.5" fill="none" stroke="rgba(243,238,228,.3)" stroke-width="1.2"/></svg>')
    st=('background:var(--surface-sel);border:1.2px solid var(--line-strong)' if sel else 'background:var(--surface);border:1px solid var(--line)')
    return f'''<div style="height:84px;border-radius:20px;{st};display:flex;align-items:center;padding:0 20px;margin-bottom:12px">
 <div style="flex:1"><div style="font-size:17px;letter-spacing:2px{";color:var(--gold-hi)" if sel else ""}">{name}</div><div style="font-size:12px;color:var(--text-2);margin-top:6px;letter-spacing:.5px">{desc}</div></div>
 <div style="display:flex;align-items:baseline;margin-right:16px"><span style="font-size:15px;color:var(--text-2);margin-right:2px">¥</span><span class="num" style="font-size:34px;color:{"var(--gold-hi)" if sel else "var(--text-1)"}">{price}</span></div>{ck}</div>'''
plans=f'''<div class="screen"><div class="bg"></div><div class="layer">{sb()}
<div class="appbar">{BACK}<h1>套餐</h1></div>
<div style="position:absolute;left:24px;right:24px;top:100px;display:flex;justify-content:space-between;align-items:baseline"><span style="font-size:13px;color:var(--text-2);letter-spacing:.5px">前 3 次免费，第 4 次起 ¥1 / 次</span><span style="font-size:13px;color:var(--text-2)">已用 <span style="color:var(--gold-hi)">0/3</span></span></div>
<div style="position:absolute;left:20px;right:20px;top:136px">
{plan("单次","一次答题任务","1")}{plan("包周","7 天套餐","5.9")}{plan("包月","30 天套餐","9.9",True)}
</div>
<div style="position:absolute;left:24px;right:24px;top:448px;font-size:12px;color:var(--text-3);letter-spacing:2px">付款方式</div>
<div style="position:absolute;left:20px;right:20px;top:476px;height:60px;border-radius:18px;background:var(--surface);border:1px solid var(--line);display:flex;align-items:center;padding:0 20px">
 <div style="width:28px;height:28px;border-radius:8px;border:1px solid var(--gold);display:flex;align-items:center;justify-content:center;font-size:14px;color:var(--gold)">支</div>
 <div style="flex:1;margin-left:12px;font-size:16px;letter-spacing:1px">支付宝</div>
 <svg width="22" height="22" viewBox="0 0 24 24"><circle cx="12" cy="12" r="11" fill="#D6B87E"/><path d="M7 12.3l3.2 3.2L17 8.8" fill="none" stroke="#1B150C" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg></div>
<div class="btn" style="position:absolute;left:20px;right:20px;top:688px">前往支付宝支付</div>
<div style="position:absolute;left:0;right:0;top:752px;text-align:center"><span class="link" style="font-size:12px;color:var(--text-3)">计次说明</span></div>
{GEST}</div></div>'''

def wx(no):
    opts=['A. 继续运行','B. 减速通过','C. 立即停车','D. 鸣笛通过']
    o=''.join(f'<div class="wxopt"><i></i>{x}</div>' for x in opts)
    return f'''<div class="wx">{sb(False)}<div class="wxnav">铁路题库练习<div class="wxcap"><span><svg width="20" height="6" viewBox="0 0 20 6"><circle cx="3" cy="3" r="2.2" fill="#111"/><circle cx="10" cy="3" r="2.2" fill="#111"/><circle cx="17" cy="3" r="2.2" fill="#111"/></svg></span><span class="sep"></span><span><svg width="18" height="18" viewBox="0 0 18 18"><circle cx="9" cy="9" r="7.5" fill="none" stroke="#111" stroke-width="1.6"/><circle cx="9" cy="9" r="2.8" fill="#111"/></svg></span></div></div>
<div class="wxcard"><div class="wxno">{no}/100</div><div class="wxstem">信号灯显示红灯时，列车应如何处理？</div>{o}<div class="wxsubmit">确认答案</div></div>{GEST}</div>'''
X='<span class="x"><svg width="12" height="12" viewBox="0 0 12 12" stroke="rgba(243,238,228,.5)" stroke-width="1.3" stroke-linecap="round"><path d="M2 2l8 8M10 2l-8 8"/></svg></span>'
DRAG='<svg width="16" height="16" viewBox="0 0 16 16" fill="rgba(243,238,228,.35)"><circle cx="5" cy="4" r="1.2"/><circle cx="11" cy="4" r="1.2"/><circle cx="5" cy="8" r="1.2"/><circle cx="11" cy="8" r="1.2"/><circle cx="5" cy="12" r="1.2"/><circle cx="11" cy="12" r="1.2"/></svg>'
POS='left:128px;top:516px'   # 卡片位置：题目卡(底边498dp)下方18dp、右侧距屏幕16dp
ovs={
 'overlay-01-ready':('1',f'''<div class="ov" style="{POS}"><div class="hd"><span>每日百题</span>{X}</div>
  <div style="font-size:16px;margin-top:12px;letter-spacing:1px">铁路题库</div><div class="sub">今日 <b>0/100</b></div>
  <div class="btn">从当前页开始</div></div>'''),
 'overlay-02-running':('37','''<div class="cap" style="top:540px"><span class="p"><svg width="10" height="10" viewBox="0 0 10 10" fill="#D6B87E"><rect x="1.5" y="1" width="2.2" height="8" rx=".6"/><rect x="6.3" y="1" width="2.2" height="8" rx=".6"/></svg></span><span class="n num">37<small>/100</small></span></div>'''),
 'overlay-03-expanded':('37',f'''<div class="ov" style="{POS}"><div class="hd"><span>答题中</span>{DRAG}</div>
  <div class="big num">37<small>/100</small></div><div class="sub">正确率 <b>92%</b></div><div class="bar"><i style="width:37%"></i></div>
  <div class="btn">暂停</div><div class="end">结束</div></div>'''),
 'overlay-04-paused':('37',f'''<div class="ov paused" style="{POS}"><div class="hd"><span class="tag"><svg width="8" height="8" viewBox="0 0 8 8" fill="#E7A15C"><rect x="0.5" y="0" width="2.2" height="8" rx=".5"/><rect x="5.3" y="0" width="2.2" height="8" rx=".5"/></svg>已暂停</span>{DRAG}</div>
  <div class="big num">37<small>/100</small></div><div class="sub">正确率 <b>92%</b></div><div class="bar"><i style="width:37%"></i></div>
  <div class="btn">继续</div><div class="end">结束</div></div>'''),
 'overlay-05-retry':('38',f'''<div class="ov" style="{POS}"><div class="hd"><span>每日百题</span>{X}</div>
  <div style="display:flex;align-items:center;gap:10px;margin-top:14px"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#D6B87E" stroke-width="1.4" stroke-linecap="round"><circle cx="11" cy="11" r="7"/><path d="M16.2 16.2 21 21M11 8v3.5M11 14.2v.1"/></svg><span style="font-size:15px;letter-spacing:1px">没有识别到题目</span></div>
  <div class="btn">重试</div></div>'''),
 'overlay-06-complete':('100',f'''<div class="ov" style="{POS}"><div class="hd"><span style="color:var(--gold)">今日完成</span>{X}</div>
  <div class="big num">100<small>/100</small></div><div class="sub">正确率 <b>96%</b></div><div class="bar"><i style="width:100%"></i></div>
  <div class="btn">完成</div></div>'''),
}
files={'screen-home':page(home,'首页'),'screen-import':page(imp,'上传题库'),'screen-plans':page(plans,'套餐')}
for k,(no,ov) in ovs.items():
    files[k]=page(f'<div class="screen">{wx(no)}{ov}</div>',k)
    files[k+'-solo']=page(ov,k+' 透明底',solo=True)
for k,v in files.items(): open(os.path.join(D,k+'.html'),'w').write(v)
with sync_playwright() as p:
    b=p.chromium.launch(executable_path='/usr/bin/google-chrome',args=['--no-sandbox'])
    pg=b.new_page(viewport={'width':360,'height':800},device_scale_factor=3)
    for k in files:
        pg.goto('file://'+os.path.join(D,k+'.html')); pg.wait_for_timeout(300)
        if k.endswith('-solo'):
            pg.locator('.ov,.cap').first.screenshot(path=os.path.join(D,k.replace('-solo','-float')+'.png'),omit_background=True)
        else:
            pg.screenshot(path=os.path.join(D,k+'.png'))
    b.close()
print('done')
