import pathlib,sys
asar = pathlib.Path(r"C:\Program Files\WindowsApps\OpenAI.Codex_26.1103.7773.0_x64__2p2nqsd0c76g0\app\resources\app.asar")
outp = pathlib.Path(r"C:\Users\rmsama\Documents\ChatGPT\codex-briefs-20261110\ui-yejin\_asar-H.txt")
# extract around offset of threads/new handler
off = 7098954
before = 200
after = 6000
with asar.open("rb") as f:
    start = max(0, off-before)
    f.seek(start)
    data = f.read(before+after)
text = data.decode("utf-8", "replace")
outp.write_text(text, encoding="utf-8")
print("WROTE", outp, "chars", len(text))
