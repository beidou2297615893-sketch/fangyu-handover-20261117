import pathlib
asar = pathlib.Path(r"C:\Program Files\WindowsApps\OpenAI.Codex_26.1103.7773.0_x64__2p2nqsd0c76g0\app\resources\app.asar")
outp = pathlib.Path(r"C:\Users\rmsama\Documents\ChatGPT\codex-briefs-20261110\ui-yejin\_asar-newthread-case.txt")
off = 12795880
before, after = 200, 8000
with asar.open("rb") as f:
    start = max(0, off - before)
    f.seek(start)
    data = f.read(before + after)
outp.write_text(data.decode("utf-8", "replace"), encoding="utf-8")
print("WROTE", outp, "chars", len(data))
