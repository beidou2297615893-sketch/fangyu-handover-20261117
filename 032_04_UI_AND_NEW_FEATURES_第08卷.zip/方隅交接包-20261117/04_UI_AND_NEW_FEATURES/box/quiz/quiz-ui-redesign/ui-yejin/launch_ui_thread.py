# -*- coding: utf-8 -*-
import json, os, sqlite3, subprocess, time, urllib.parse
from datetime import datetime, timezone, timedelta
from pathlib import Path

EXE = r"C:\Program Files\WindowsApps\OpenAI.Codex_26.1103.7773.0_x64__2p2nqsd0c76g0\app\resources\codex.exe"
BRIEF = Path(r"C:\Users\rmsama\Documents\ChatGPT\codex-briefs-20261110\ui-yejin\UI-BRIEF.md")
DB = Path(r"C:\Users\rmsama\.codex\state_5.sqlite")
SESS_DIR = Path(r"C:\Users\rmsama\.codex\sessions\2026\11\10")
CWD = r"C:\Users\rmsama\Documents\ChatGPT\答题小程序"
PROJECT_ID = "01a1625a-c32a-7c02-9734-b4e2d62ff219"
LOG = Path(r"C:\Users\rmsama\Documents\ChatGPT\codex-briefs-20261110\ui-yejin\_launch-log.txt")

FORBIDDEN = {
    "01a19c5d-8bd3-7891-aef8-c92e537af5c9",  # 代码
    "01a177b8-998d-7382-b8ef-8d6267580186",  # 检查答题小程序问题
    "01a17731-b4c4-7812-afc6-f7c4757da892",  # 每日百题与小程序支付桥接 (if present)
}

def log(msg):
    line = f"{datetime.now().strftime('%H:%M:%S')} {msg}"
    print(line, flush=True)
    with LOG.open("a", encoding="utf-8") as f:
        f.write(line + "\n")

def list_threads(conn):
    rows = conn.execute(
        """
        SELECT id, IFNULL(name,''), IFNULL(title,''), cwd, IFNULL(project_id,''),
               source, IFNULL(originator,''), IFNULL(thread_source,''), created_at_ms
        FROM threads
        """
    ).fetchall()
    return {r[0]: r for r in rows}

def is_target_new(row, before_ids, t0_ms):
    tid, name, title, cwd, project_id, source, originator, thread_source, created = row
    if tid in before_ids or tid in FORBIDDEN:
        return False
    if created is not None and created < t0_ms - 2000:
        return False
    cwd_s = (cwd or "").replace("\\\\?\\", "").replace("\\", "/").lower()
    if "答题小程序" not in (cwd or "") and "答题小程序" not in cwd_s:
        return False
    src = (source or "")
    if "subagent" in src.lower():
        return False
    # desktop official threads are typically vscode + Codex Desktop
    return True

def find_session_file(tid):
    # today first, then walk recent session dirs
    hits = list(SESS_DIR.glob(f"rollout-*-{tid}.jsonl")) if SESS_DIR.exists() else []
    if hits:
        return str(max(hits, key=lambda p: p.stat().st_mtime))
    root = Path(r"C:\Users\rmsama\.codex\sessions\2026\11")
    if root.exists():
        hits = list(root.glob(f"*/rollout-*-{tid}.jsonl"))
        if hits:
            return str(max(hits, key=lambda p: p.stat().st_mtime))
    return ""

def first_assistant_points(path, limit=8):
    if not path or not os.path.isfile(path):
        return []
    points = []
    with open(path, "r", encoding="utf-8", errors="replace") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                obj = json.loads(line)
            except Exception:
                continue
            typ = obj.get("type") or ""
            payload = obj.get("payload") or {}
            # common shapes: event_msg, item, agent_message
            texts = []
            if typ in ("event_msg", "response_item", "item"):
                ptype = payload.get("type") or typ
                if ptype in ("agent_message", "message", "assistant_message"):
                    c = payload.get("content") or payload.get("text") or ""
                    if isinstance(c, str):
                        texts.append(c)
                    elif isinstance(c, list):
                        for part in c:
                            if isinstance(part, dict):
                                t = part.get("text") or part.get("content") or ""
                                if t:
                                    texts.append(t)
                            elif isinstance(part, str):
                                texts.append(part)
            # also top-level
            if typ in ("agent_message",):
                texts.append(str(payload))
            for t in texts:
                t = t.strip()
                if t and t not in points:
                    points.append(t)
            if len(points) >= limit:
                break
    return points

def main():
    if LOG.exists():
        LOG.unlink()
    if not BRIEF.is_file():
        raise SystemExit("missing brief")
    if not Path(EXE).is_file():
        raise SystemExit("missing official exe")
    message = BRIEF.read_text(encoding="utf-8")
    log(f"brief_bytes={len(message.encode('utf-8'))} chars={len(message)}")

    t0_ms = int(time.time() * 1000)
    conn = sqlite3.connect(str(DB))
    before = list_threads(conn)
    log(f"snapshot_threads={len(before)} t0_ms={t0_ms}")

    params = {
        "path": "C:/Users/rmsama/Documents/ChatGPT/答题小程序",
        "projectId": PROJECT_ID,
    }
    url = "codex://threads/new?" + urllib.parse.urlencode(params, quote_via=urllib.parse.quote)
    log(f"url={url}")

    # Official desktop protocol handler
    launched = subprocess.run(
        ["powershell", "-NoProfile", "-Command",
         f"Start-Process -FilePath '{url}'"],
        capture_output=True, text=True, encoding="utf-8", errors="replace"
    )
    log(f"start-process exit={launched.returncode} out={ (launched.stdout or '').strip() } err={ (launched.stderr or '').strip() }")

    new_id = None
    row = None
    for i in range(30):
        time.sleep(2)
        conn = sqlite3.connect(str(DB))
        now = list_threads(conn)
        candidates = [r for r in now.values() if is_target_new(r, before, t0_ms)]
        # prefer official desktop originator
        official = [r for r in candidates if r[6] == "Codex Desktop" or r[5] == "vscode"]
        pick = official or candidates
        if pick:
            # newest created
            row = max(pick, key=lambda r: r[8] or 0)
            new_id = row[0]
            log(f"found new thread id={new_id} name={row[1]!r} source={row[5]} originator={row[6]} thread_source={row[7]} created_ms={row[8]}")
            break
        log(f"wait {i+1}/30 no new thread yet; total={len(now)}")

    if not new_id:
        log("FAIL no new official desktop thread appeared")
        return 2

    if new_id in FORBIDDEN:
        log("FAIL matched a forbidden existing window")
        return 3

    sess = find_session_file(new_id)
    log(f"session_file={sess or 'NOT_YET'}")

    cmd = [
        EXE, "queue",
        "--thread", new_id,
        "--message", message,
        "--resume",
        "-C", CWD,
    ]
    log("queue official cli starting")
    q = subprocess.run(cmd, capture_output=True, timeout=120)
    qout = ((q.stdout or b"") + (q.stderr or b"")).decode("utf-8", errors="replace")
    log(f"queue exit={q.returncode}")
    log("queue output begin")
    log(qout[:4000])
    log("queue output end")

    # wait for session file and some activity
    running = False
    points = []
    for i in range(20):
        time.sleep(3)
        if not sess:
            sess = find_session_file(new_id)
        if sess:
            st = os.stat(sess)
            running = st.st_mtime * 1000 >= t0_ms or st.st_size > 0
            points = first_assistant_points(sess)
            log(f"poll session exists size={st.st_size} mtime={datetime.fromtimestamp(st.st_mtime)} points={len(points)}")
            if points:
                break
        else:
            log(f"poll {i+1}/20 session file still missing")

    log(f"RESULT id={new_id}")
    log(f"RESULT session={sess}")
    log(f"RESULT running={running}")
    if points:
        for i, p in enumerate(points[:3], 1):
            snippet = p.replace("\n", " / ")
            if len(snippet) > 800:
                snippet = snippet[:800] + "..."
            log(f"RESULT reply{i}={snippet}")
    else:
        log("RESULT reply=NONE_YET")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
