import pathlib
asar = pathlib.Path(r"C:\Program Files\WindowsApps\OpenAI.Codex_26.1103.7773.0_x64__2p2nqsd0c76g0\app\resources\app.asar")
outp = pathlib.Path(r"C:\Users\rmsama\Documents\ChatGPT\codex-briefs-20261110\ui-yejin\_asar-newthread.txt")
needles = [
    b'kind:"newThread"',
    b"kind:'newThread'",
    b'==="newThread"',
    b"==='newThread'",
    b'autoSubmit',
    b'auto_submit',
    b'autosubmit',
    b'trigger_turn',
    b'K82',  # too short, skip maybe
]
# more specific
needles = [
    b'kind:"newThread"',
    b"kind:'newThread'",
    b'==="newThread"',
    b"==='newThread'",
    b'case"newThread"',
    b"case 'newThread'",
    b'autoSubmit',
    b'auto_submit',
    b'triggerTurn',
    b'prefillPrompt',
    b'createAndStartThread',
    b'startNewConversation',
    b'openNewConversation',
]
chunk = 8 * 1024 * 1024
overlap = 8000
found = {n: [] for n in needles}
max_hits = 8
with asar.open("rb") as f:
    buf = b""
    offset = 0
    while True:
        data = f.read(chunk)
        if not data and not buf:
            break
        window = buf + data
        for n in needles:
            if len(found[n]) >= max_hits:
                continue
            start = 0
            while len(found[n]) < max_hits:
                i = window.find(n, start)
                if i < 0:
                    break
                abs_i = offset + i
                a = max(0, i - 250)
                b = min(len(window), i + 700)
                found[n].append((abs_i, window[a:b]))
                start = i + len(n)
        if not data:
            break
        buf = window[-overlap:]
        offset += len(window) - overlap

def dec(b):
    return b.decode("utf-8", "replace").replace("\n", " ").replace("\r", " ")

lines = []
for n, hits in found.items():
    lines.append(f"===== {n.decode()} hits={len(hits)} =====")
    for abs_i, snip in hits:
        lines.append(f"OFF={abs_i}: {dec(snip)}")
        lines.append("")
outp.write_text("\n".join(lines), encoding="utf-8")
print("WROTE", outp, "bytes", outp.stat().st_size)
