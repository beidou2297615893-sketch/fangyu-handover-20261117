# 界面改版「夜金」— 以 final\ 为准

- 本目录里旧的 `style-a-*.jpg` 和 `overlay-*.jpg` 是**带手机外壳的概念稿，已作废**，不要按它们定间距、字号、圆角、按钮大小，也不要拿它们验收。
- 开发以 `final\` 为准，**1:1 还原**：
  - 整屏稿（1080×2400，即手机屏幕本身，无外壳）：`screen-home.png`、`screen-import.png`、`screen-plans.png`、`overlay-01-ready.png` … `overlay-06-complete.png`
  - 透明底单独浮窗（@3x 原尺寸）：`overlay-0x-*-float.png`
  - 规范：`design-spec.md`（颜色、字号、间距、圆角、位置，单位 dp，画布 360×800dp）
  - HTML 源：`*.html` + `yejin.css`（数值以此为准），`build.py` 可重新出图
  - 素材：`assets\bg-night.jpg`（夜景纯背景）
- 悬浮窗整屏图背后的白底页面是模拟的微信小程序答题页，只用于展示浮窗尺寸和不挡题的位置，不需要做。
- 不做单独的“运行中”页面。
