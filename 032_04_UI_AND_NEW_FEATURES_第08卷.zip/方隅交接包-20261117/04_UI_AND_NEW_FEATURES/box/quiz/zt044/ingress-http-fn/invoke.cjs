'use strict';
/**
 * Sync-invoke a CloudBase/SCF Event function using the runtime role.
 * Prefers an injected invokeImpl in tests; production uses official SCF JSON API
 * with temporary role credentials from the function environment (never logged).
 */
const https = require('node:https');
const crypto = require('node:crypto');

function envCreds() {
  const secretId = process.env.TENCENTCLOUD_SECRETID;
  const secretKey = process.env.TENCENTCLOUD_SECRETKEY;
  const token = process.env.TENCENTCLOUD_SESSIONTOKEN;
  if (typeof secretId !== 'string' || typeof secretKey !== 'string' || !secretId || !secretKey) {
    throw new Error('invoke_role_unavailable');
  }
  return { secretId, secretKey, token };
}

function sha256Hex(s) {
  return crypto.createHash('sha256').update(s).digest('hex');
}
function hmac(key, data) {
  return crypto.createHmac('sha256', key).update(data).digest();
}

function signV3({ secretId, secretKey, token, region, payload, timestamp, service, host, action }) {
  const algorithm = 'TC3-HMAC-SHA256';
  const date = new Date(timestamp * 1000).toISOString().slice(0, 10);
  const canonical = ['POST', '/', '', 'content-type:application/json; charset=utf-8', 'host:' + host, '', 'content-type;host', sha256Hex(payload)].join('\n');
  const credentialScope = `${date}/${service}/tc3_request`;
  const stringToSign = [algorithm, String(timestamp), credentialScope, sha256Hex(canonical)].join('\n');
  const secretDate = hmac('TC3' + secretKey, date);
  const secretService = hmac(secretDate, service);
  const secretSigning = hmac(secretService, 'tc3_request');
  const signature = crypto.createHmac('sha256', secretSigning).update(stringToSign).digest('hex');
  const auth = `${algorithm} Credential=${secretId}/${credentialScope}, SignedHeaders=content-type;host, Signature=${signature}`;
  const headers = {
    authorization: auth,
    'content-type': 'application/json; charset=utf-8',
    host,
    'x-tc-action': action,
    'x-tc-timestamp': String(timestamp),
    'x-tc-version': '2018-04-16',
    'x-tc-region': region,
  };
  if (token) headers['x-tc-token'] = token;
  return headers;
}

function postHttps(host, headers, payload) {
  return new Promise((resolve, reject) => {
    const req = https.request({ method: 'POST', protocol: 'https:', hostname: host, path: '/', headers: { ...headers, 'content-length': Buffer.byteLength(payload) } }, (res) => {
      const chunks = [];
      res.on('data', (c) => chunks.push(c));
      res.on('end', () => resolve(Buffer.concat(chunks).toString('utf8')));
      res.on('error', reject);
    });
    req.on('error', reject);
    req.setTimeout(55000, () => { req.destroy(); reject(new Error('invoke_timeout')); });
    req.end(payload);
  });
}

async function invokeViaSdk({ functionName, namespace, region, event }) {
  const creds = envCreds();
  const payload = JSON.stringify({
    FunctionName: functionName,
    Namespace: namespace,
    InvocationType: 'RequestResponse',
    Qualifier: '$LATEST',
    LogType: 'None',
    ClientContext: JSON.stringify(event),
  });
  const host = 'scf.tencentcloudapi.com';
  const timestamp = Math.floor(Date.now() / 1000);
  const headers = signV3({ ...creds, region, payload, timestamp, service: 'scf', host, action: 'Invoke' });
  const raw = await postHttps(host, headers, payload);
  let parsed;
  try { parsed = JSON.parse(raw); } catch { throw new Error('invoke_invalid_response'); }
  if (parsed.Response && parsed.Response.Error) throw new Error('invoke_rejected');
  const result = parsed.Response && parsed.Response.Result;
  const text = result && (result.RetMsg || result.FunctionRequestId != null ? result.RetMsg : null);
  if (typeof text !== 'string') throw new Error('invoke_empty_result');
  let envelope;
  try { envelope = JSON.parse(text); } catch { throw new Error('invoke_invalid_envelope'); }
  if (!envelope || typeof envelope !== 'object') throw new Error('invoke_invalid_envelope');
  return envelope;
}

async function invokeEventFunction({ functionName, namespace, region, event, invokeImpl }) {
  if (typeof invokeImpl === 'function') return invokeImpl({ functionName, namespace, region, event });
  return invokeViaSdk({ functionName, namespace, region, event });
}

module.exports = { invokeEventFunction, toInvokePayload: (event) => event };
