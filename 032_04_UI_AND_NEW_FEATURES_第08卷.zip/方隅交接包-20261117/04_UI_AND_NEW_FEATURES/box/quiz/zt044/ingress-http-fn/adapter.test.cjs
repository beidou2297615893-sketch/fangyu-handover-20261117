'use strict';
const assert = require('node:assert/strict');
const { toEvent, fromEnvelope } = require('./adapter.cjs');
const { invokeEventFunction } = require('./invoke.cjs');

const body = Buffer.from('{"hello":"world"}');
const event = toEvent({
  method: 'POST',
  url: '/api/import-ai/v1/openai/chat/completions',
  headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + 'A'.repeat(43) },
}, body);
assert.equal(event.path, '/api/import-ai/v1/openai/chat/completions');
assert.equal(event.httpMethod, 'POST');
assert.equal(event.isBase64Encoded, true);
assert.equal(Buffer.from(event.body, 'base64').toString(), body.toString());
assert.equal(event.headers['content-type'], 'application/json');
assert.deepEqual(event.multiValueHeaders['content-type'], ['application/json']);
assert.equal(event.headers.authorization.startsWith('Bearer '), true);
assert.equal(Object.keys(event.headers).sort().join(','), 'authorization,content-type');
const ev3 = toEvent({
  method: 'POST',
  url: '/api/import-ai/v1/openai/chat/completions',
  headers: {
    'content-type': 'application/json',
    authorization: 'Bearer tok',
    'x-forwarded-for': '1.2.3.4',
    host: 'example',
    'x-scf-request-id': 'abc',
    'user-agent': 'probe',
  },
}, body);
assert.equal(Object.keys(ev3.headers).sort().join(','), 'authorization,content-type');
assert.deepEqual(ev3.multiValueHeaders.authorization, ['Bearer tok']);


const large = Buffer.alloc(300000, 120);
const ev2 = toEvent({ method: 'POST', url: '/api/import-ai/v1/openai/chat/completions', headers: { 'content-type': 'application/json' } }, large);
assert.equal(Buffer.from(ev2.body, 'base64').length, 300000);

(async () => {
  const envelope = await invokeEventFunction({
    functionName: 'dailyHundredImportV1Event',
    namespace: 'fh6-d5ga45c0ddae7008c',
    region: 'ap-shanghai',
    event: ev2,
    invokeImpl: async ({ event }) => {
      assert.equal(event.isBase64Encoded, true);
      assert.equal(Buffer.from(event.body, 'base64').length, 300000);
      return { statusCode: 401, headers: { 'content-type': 'application/json' }, body: '{"error":"unauthorized"}', isBase64Encoded: false };
    },
  });
  assert.equal(envelope.statusCode, 401);
  const out = fromEnvelope(envelope);
  assert.equal(out.status, 401);
  console.log('adapter tests ok');
})().catch((e) => { console.error(e); process.exit(1); });
