'use strict';
/**
 * HTTP 云函数入口：接收网关原始 HTTP（含大于 100KiB 的 JSON），
 * 转成现网 Event 函数已经认识的 envelope，再同步 Invoke dailyHundredImportV1Event。
 * 不读取、不打印、不落地任何密钥；调用凭据只用运行角色临时证书。
 */
const http = require('node:http');
const { invokeEventFunction } = require('./invoke.cjs');
const { toEvent, fromEnvelope } = require('./adapter.cjs');

const MAX_BODY = 6 * 1024 * 1024;
const TARGET = process.env.INGRESS_TARGET_FUNCTION || 'dailyHundredImportV1Event';
const NAMESPACE = process.env.INGRESS_TARGET_NAMESPACE || process.env.SCF_NAMESPACE || 'fh6-d5ga45c0ddae7008c';
const REGION = process.env.INGRESS_TARGET_REGION || process.env.TENCENTCLOUD_REGION || 'ap-shanghai';

function collect(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let bytes = 0;
    req.on('data', (c) => {
      bytes += c.length;
      if (bytes > MAX_BODY) {
        req.destroy();
        const err = new Error('request_too_large');
        err.statusCode = 413;
        reject(err);
        return;
      }
      chunks.push(Buffer.from(c));
    });
    req.on('error', reject);
    req.on('end', () => resolve(Buffer.concat(chunks, bytes)));
  });
}

function send(res, status, headers, body, isBase64) {
  const out = isBase64 ? Buffer.from(String(body || ''), 'base64') : Buffer.from(String(body || ''), 'utf8');
  const h = { 'cache-control': 'no-store' };
  if (headers && typeof headers === 'object') {
    for (const [k, v] of Object.entries(headers)) {
      if (typeof v === 'string' && !/[\r\n\0]/.test(v)) h[k] = v;
    }
  }
  if (!h['content-type']) h['content-type'] = 'application/json; charset=utf-8';
  res.writeHead(status, h);
  res.end(out);
}

const server = http.createServer(async (req, res) => {
  try {
    if (req.method === 'OPTIONS') {
      res.writeHead(204);
      res.end();
      return;
    }
    const raw = await collect(req);
    const event = toEvent(req, raw);
    const envelope = await invokeEventFunction({
      functionName: TARGET,
      namespace: NAMESPACE,
      region: REGION,
      event,
    });
    send(res, envelope.statusCode || 502, envelope.headers, envelope.body, envelope.isBase64Encoded === true);
  } catch (error) {
    const status = error && error.statusCode === 413 ? 413 : 502;
    const code = status === 413 ? 'request_too_large' : 'gateway_unavailable';
    send(res, status, { 'content-type': 'application/json; charset=utf-8' }, JSON.stringify({ error: code }), false);
  }
});

server.listen(9000);
module.exports = { server, MAX_BODY };
