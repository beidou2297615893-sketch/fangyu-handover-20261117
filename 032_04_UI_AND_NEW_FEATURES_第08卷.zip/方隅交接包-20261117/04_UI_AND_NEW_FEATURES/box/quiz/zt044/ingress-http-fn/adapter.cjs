'use strict';
/** Convert a Node HTTP request into the Event envelope dailyHundredImportV1Event already accepts. */
const HEADER_NAME = /^[!#$%&'*+.^_`|~0-9a-z-]+$/;
// The live Event function rejects >50 headers, mismatched multiValueHeaders, or hop-by-hop/gateway
// headers that fail its strict checks. It only reads Authorization and Content-Type, so only those
// client headers are forwarded. Body is still passed through unchanged.
const FORWARDED = new Set(['authorization', 'content-type']);

function toEvent(req, rawBody) {
  const url = new URL(req.url || '/', 'http://127.0.0.1');
  const headers = Object.create(null);
  const multi = Object.create(null);
  const input = req.headers || {};
  for (const [name, value] of Object.entries(input)) {
    if (typeof name !== 'string' || value == null) continue;
    const lower = name.toLowerCase();
    if (!FORWARDED.has(lower) || !HEADER_NAME.test(lower) || Object.hasOwn(headers, lower)) continue;
    const single = Array.isArray(value) ? value[0] : value;
    if (typeof single !== 'string' || /[\r\n\0]/.test(single)) continue;
    headers[lower] = single;
    multi[lower] = [single];
  }
  const body = Buffer.isBuffer(rawBody) ? rawBody : Buffer.from(rawBody || '');
  return {
    path: url.pathname,
    httpMethod: String(req.method || 'GET').toUpperCase(),
    headers,
    multiValueHeaders: multi,
    body: body.toString('base64'),
    isBase64Encoded: true,
    queryStringParameters: Object.fromEntries(url.searchParams.entries()),
  };
}

function fromEnvelope(envelope) {
  const status = Number(envelope && envelope.statusCode) || 502;
  const headers = (envelope && envelope.headers) || {};
  const isBase64 = envelope && envelope.isBase64Encoded === true;
  const body = envelope && envelope.body != null ? String(envelope.body) : '';
  return { status, headers, body, isBase64 };
}

module.exports = { toEvent, fromEnvelope };
