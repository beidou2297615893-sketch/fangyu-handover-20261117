# 现网状态（2026-11-12 15:37，Asia/Shanghai）

**现网已经改好。** 同一条看图 URL 不变，已装的 0.4.3 现在可以直接重试，不必出新包、不必重装。

`/api/import-ai/v1` 已改到 HTTP 云函数 `dailyHundredImportV1Ingress`，再原样转给原来的事件函数。现网实测：102401、300000、600000 字节的 JSON 都不再返回 `413 EXCEED_MAX_PAYLOAD_SIZE`；小请求仍能进入原函数（假 token 时与改之前一样返回 `gateway_unavailable`）。付款和其他接口未动。

详情见 `STATUS.md`，步骤和回滚见 `INGRESS-FIX.md`，探测记录见 `ingress-prod-test.json`。

---

# 知题 0.4.3「模型返回 413 EXCEED_MAX_PAYLOAD_SIZE」根因（先查清，未改提进发图逻辑）

时间：2026-11-12（Asia/Shanghai）
结论先行：这不是提进原有看图/发图/点击逻辑坏了，是我们后来加的 CloudBase 透明网关入口把提进原来能发出去的截图请求挡住了。按约束，没有改 APK 里的截图压缩、缩放、模型、提示词、返回格式或自动点击，也没有打 0.4.4，也没有上传蒲公英。

## 用户看到的现象

覆盖安装 0.4.3（Build 33）后，付款关已过（已付 9.9），一点击答题，悬浮窗：

识别暂停
模型返回 413:
{"code":"EXCEED_MAX_PAYLOAD_SIZE","message":"Exceed max request payload size. For more information, please ref…
按钮：重试/继续/停止。0 题。

报错全文与 CloudBase 官方错误页一致：
https://docs.cloudbase.net/error-code/EXCEED_MAX_PAYLOAD_SIZE
https://docs.cloudbase.net/error-code/service/EXCEED_MAX_PAYLOAD_SIZE

## 提进原来怎么做（未被我们改过）

对照 `tijing-upstream` 与当前 0.4.3 工程，截图发送链路相同：

1. `ScreenCaptureService` 按手机物理分辨率截全屏（`getRealMetrics` 的 widthPixels × heightPixels），不缩放。
2. JPEG 质量固定 78，再 Base64，做成 `data:image/jpeg;base64,...`。
3. `ModelClient` 按 OpenAI Chat Completions 发 `Content-Type: application/json`，图片放在 `image_url`。
4. 坐标是截图宽高的 0–100 百分比（原提示词第 7 条），点选逻辑吃这个格式。

常量位置：`ScreenCaptureService.kt` 的 `JPEG_QUALITY = 78`。上游与现网这段编码一致，不是后来新写的压缩方案，也没有被关掉。

## 我们后来加了什么

付费开始后，`GatewaySessionEntry` 把提进原来可用的用户 endpoint/apiKey，改成我们的统一代理：

- 地址：`https://fh6-d5ga45c0ddae7008c-1439321968.ap-shanghai.app.tcloudbase.com/api/import-ai/v1/openai`（客户端再拼 `/chat/completions`）
- 模型：`deepseek-flash`
- 函数：CloudBase Event 云函数 `dailyHundredImportV1Event`（环境 `fh6-d5ga45c0ddae7008c`）
- 现网代码：2026-11-11 12:10（Asia/Shanghai）code-only 发布的 thinkoff 版（在 transparent 透传网关之后）。函数里 `standard-gateway.cjs` 自己的上限是 **请求 3MB、响应 2MB**，并且已经按透传设计，不改题目、模型、坐标或 body 内容。

也就是说：函数本身是按「把提进原请求转给 DeepSeek 官方」写的，内部 3MB 够用；挡住请求的是函数前面的 CloudBase HTTP 访问服务。

## 实测到的真实上限（不要猜）

2026-11-12 对现网该 URL 做了不带真实会话、不扣费、不用真 token 的体量探测（假 Bearer、填充 JSON）：

| 请求体 | Content-Type | 结果 |
|---|---|---|
| 102400 字节（正好 100×1024）及以下 | application/json | 能进我们的函数（返回函数自己的 `gateway_unavailable`，因为请求是假的） |
| 102401 字节及以上 | application/json | **HTTP 413，body 就是用户看到的 `EXCEED_MAX_PAYLOAD_SIZE`** |
| 200000 字节 | application/octet-stream | 能进函数（400 `invalid_request`，不是 413）。说明非文本类型走的是文档里的 6MB 档，函数解析还没按这种类型接好 |

官方说明：云函数「文本类型请求体 100KB，其他类型 6MB」。`application/json` 属于文本类型。实测卡点就是 **100 KiB = 102400 字节**，多 1 字节即 413。

用户发来的手机截图本身约 405KB。提进原逻辑用质量 78 的全屏 JPEG，再 Base64（约 ×4/3），整段 JSON 通常是几十万字节，远超 100KiB。所以第一题就会停，0 题是必然的。

此前云端探针能通过，是因为用了约 26–30KB 的小图（`probe-q1-submitlabel.png` 等），整包不到 100KiB。透明网关交接里也写过：真实网络受网关和函数限制，不能声称任意大小都已验证。

DeepSeek 官方接口本身不是这个错误码；bank-assist 自己的超限返回是 `{error:"request_too_large"}`，也对不上。请求在进 `dailyHundredImportV1Event` 之前就被 CloudBase 网关拒了。只改函数代码（UpdateFunctionCode）**抬不了** 这个 100KiB 文本上限。

## 正确修法（只修我们加的这一层）

不要改提进的截图质量、分辨率、提示词、返回格式或点击逻辑，也不要新写一套客户端压缩来绕开。

要让已经装在用户手机上的 0.4.3 立刻可用（不必出新包、不必上传蒲公英），必须让**同一个 URL** 接受大于 100KiB 的 `application/json`。可选方向：

1. 推荐：把 HTTP 访问服务这条路径的后端，从 Event 云函数改到能收大 JSON 的入口（例如云托管，文档中「其他请求」上限 100MB；或 HTTP 云函数 / 与支付类似的 SCF HTTP，通常 6MB），由它把原样 JSON 转给现有网关逻辑或直接转 DeepSeek。URL 不变，0.4.3 不用改。函数内部 3MB 上限对常见全屏 JPEG 78 够用；若遇到极端分辨率，再单独评估是否把函数自己的 3MB 再放宽，那是后话。
2. 不推荐作为主方案（需要新 APK）：仅对我们的代理改 `Content-Type` 为非文本类型以走 6MB 档。现网对 `application/octet-stream` 还返回 400，函数解析也要改。这会动客户端发送头，且用户手上的 0.4.3 不会立刻好。

未实施以上任何生产变更：这是现网入口/路由调整，不是改账本、不下单、不上传蒲公英。需要你确认后才能改现网路由。

## 本回合没有做的事

- 没有改 `ScreenCaptureService` / `ModelClient` / 提示词 / 点击逻辑
- 没有做 0.4.4 出包，也没有上传蒲公英
- 没有动用户手机、没有清数据、没有改服务端账本、没有真实扣费、没有用真实会话打模型

## 证据

- `ingress-probe.json`：现网入口体量探测（含 102400/102401 分界和 octet-stream 对照）
- `pc-gateway-search.txt`：电脑上网关源码与 3MB 函数上限、历次 code-only 发布检索
