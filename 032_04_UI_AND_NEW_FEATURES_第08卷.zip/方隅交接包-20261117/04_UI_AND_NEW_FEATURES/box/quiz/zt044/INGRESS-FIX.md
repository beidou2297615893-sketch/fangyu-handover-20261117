# 现网入口改造：步骤、回滚、实测（2026-11-12，Asia/Shanghai）

授权：用户 15:02 同意改现网，授权卡 t206s753。目标是同一条 URL 能收下大于 100KiB 的 JSON，手机上已装的 0.4.3 不用重装。

## 当前结论（先看这里）

**现网已经改好。** 更新时间：2026-11-12 15:37（Asia/Shanghai）。用户现在可以在 0.4.3 上直接重试。完整说明见 `STATUS.md`。

已实施：

- 命令行身份有效后，只读回读 `/api/import-ai/v1`，仍指向 `SCF / dailyHundredImportV1Event`（`enableAuth=false`，`enablePathTransmission=true`）。
- 部署 HTTP 云函数 `dailyHundredImportV1Ingress`（不写环境密钥）。
- 2026-11-12 15:33:28（Asia/Shanghai）只把这一条路由改成 `WEB_SCF / dailyHundredImportV1Ingress`。付款和其他路径未改。
- 第一次探测大包已不再 413，但因网关附加头触发了事件函数的 `invalid_request`。随后只更新入口函数，改为只转发 `Authorization` 和 `Content-Type`。
- 复测：88、102400、102401、300000、600000 字节的 JSON 都进到原事件函数，假 token 返回 `gateway_unavailable`，**都不再出现 EXCEED_MAX_PAYLOAD_SIZE**；`/openai/session` 小请求返回 `session_unavailable`。记录在 `ingress-prod-test.json`。

## 准备怎么改
（登录后执行，尚未实施）

现网路由（2026-10-27 权威回读，之后函数多次 code-only 更新，路径未报变更）：

- 域名：`fh6-d5ga45c0ddae7008c-1439321968.ap-shanghai.app.tcloudbase.com`
- 路径：`/api/import-ai/v1`（前缀匹配，`enablePathTransmission=true`）
- 上游：SCF 事件函数 `dailyHundredImportV1Event`
- 限频：总 QPS 100，单 IP 5（改上游时不碰这些）

同一条路径还承担旧导入（`/status` `/chunks` 等）和 `/openai/session`。所以新入口必须把**整段路径**原样转给现有事件函数，不能另写一套业务。

方案：新增一个 HTTP 云函数（WEB_SCF）`dailyHundredImportV1Ingress`，在网关后面收原始 HTTP（文档中非 Event 包装时常见上限 6MB），把请求转换成现网 Event 已经认识的 envelope（`path/httpMethod/headers/multiValueHeaders/body/isBase64Encoded`），再用运行角色临时证书同步 Invoke `dailyHundredImportV1Event`。现有事件函数的代码、环境变量、密钥都不读、不改。源码在 `ingress-http-fn/`，本地适配测试已通过。

然后只把这一条路由的上游从 `SCF / dailyHundredImportV1Event` 改成 `WEB_SCF / dailyHundredImportV1Ingress`。URL 不变。支付、其他业务路径不动。

若 WEB_SCF 经默认域名仍对 `application/json` 执行 100KiB 限制（实测后才知道），则回滚路由，改走云托管（文档“其他请求”100MB），仍做同样的原样转发。

## 回滚方法

把路由改回原来的上游即可，事件函数一直保持原样：

```
tcb routes edit -e fh6-d5ga45c0ddae7008c -r ap-shanghai --yes --data '{"domain":"fh6-d5ga45c0ddae7008c-1439321968.ap-shanghai.app.tcloudbase.com","routes":[{"path":"/api/import-ai/v1","upstreamResourceType":"SCF","upstreamResourceName":"dailyHundredImportV1Event"}]}'
```

回滚后行为应回到今天的 413（102401 字节起）。新 HTTP 函数可以先留着不用，不必立刻删除。

## 登录后的实施顺序

1. 只读回读现网路由，确认 `/api/import-ai/v1` 仍指向 `dailyHundredImportV1Event`，记下完整字段备回滚。
2. 部署 `dailyHundredImportV1Ingress`（HTTP 云函数，不写环境密钥）。
3. 如有需要，先用临时路径或函数调用做一次小请求，确认 Invoke 权限和 envelope 格式。
4. 只修改上述一条路由的上游类型和名称。
5. 现网实测（假 token，不扣费、不打真实模型）：
   - 102400 字节 JSON：应能进后端（不是 413 EXCEED_MAX_PAYLOAD_SIZE）
   - 102401、300000+ 字节 JSON（模拟全屏 JPEG Base64）：不应再返回 `EXCEED_MAX_PAYLOAD_SIZE`
   - `/api/import-ai/v1/openai/session` 小请求仍应进函数（格式错误或未授权由现有逻辑处理，而不是入口 413）
6. 如允许，用一张接近真实尺寸的截图、极短提示做一次完整通路烟测（会消耗很少量模型额度）。若 Invoke 权限或入口上限不符合预期，立刻按上面回滚。

## 本回合已做 / 未做

已做：根因和上限实测、方案和回滚写清、HTTP 适配器及本地测试、确认管理登录不可用。

未做：没有改现网路由或函数、没有出 0.4.4、没有上传蒲公英、没有扣费、没有碰用户手机、没有读取函数环境变量或密钥。
