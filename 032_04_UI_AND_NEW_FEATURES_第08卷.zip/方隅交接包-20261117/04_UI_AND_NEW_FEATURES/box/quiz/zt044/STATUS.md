# 现网改入口结果（2026-11-12 15:37，Asia/Shanghai）

## 结论先行

**现网已经改好。** 同一条看图地址不变，用户现在可以直接在已装的 0.4.3 上重试，不必出新包、不必重装、不必上传蒲公英。

改动只发生在 `/api/import-ai/v1` 这一条路由：上游从事件函数 `dailyHundredImportV1Event` 改成 HTTP 云函数 `dailyHundredImportV1Ingress`，由它收下大 JSON，再原样转给原来的事件函数。付款和其他接口没有动。没有改提进客户端，没有扣费，没有碰手机。

## 大包 / 小包现网实测（假 token，不打真实模型、不扣费）

地址仍是：

`https://fh6-d5ga45c0ddae7008c-1439321968.ap-shanghai.app.tcloudbase.com/api/import-ai/v1/openai/chat/completions`

改之前：`application/json` 正好 102400 字节能进函数，102401 字节起就是 `413 EXCEED_MAX_PAYLOAD_SIZE`。

改之后（15:36 左右把入口请求头收敛后再测）：

| 请求 | 大小 | 结果 |
|---|---|---|
| 小包 chat/completions | 88 字节 | HTTP 502，`{"error":"gateway_unavailable"}`（假 token，和改之前小包进函数后的表现一致），**不是 413** |
| 正好 100KiB | 102400 字节 | 同样 502 `gateway_unavailable`，不是 413 |
| 100KiB + 1 字节 | 102401 字节 | 同样 502，**不再返回 EXCEED_MAX_PAYLOAD_SIZE** |
| 30 万字节 | 300000 字节 | 同样 502，不是 413 |
| 模拟全屏 JPEG Base64 | 600000 字节 | 同样 502，不是 413 |
| 小请求 `/openai/session` | 17 字节 | HTTP 503，`{"error":"session_unavailable"}`（假会话），说明小请求仍能进原函数 |

完整记录见 `ingress-prod-test.json`。路由回读见 `route-import-ai-v1-before.json` / `route-import-ai-v1-after.json`。

说明：假 token 不会走到 DeepSeek，所以返回的是函数自己的 `gateway_unavailable`，这正是改之前小包探测的同样结果，说明透传已经进到原来的事件函数。用户手机上是真会话，重试时应走正常看图，而不是这个假 token 错误。

## 实施过程（简要）

1. 命令行登录已有效：`tcb env list` 能看到环境 `fh6-d5ga45c0ddae7008c`，状态 Normal。没有翻、没有打印密钥。
2. 只读回读路由：目标路径仍是 SCF / `dailyHundredImportV1Event`，`enableAuth=false`，`enablePathTransmission=true`。付款等相关路径未列入本次修改。
3. 部署 HTTP 云函数 `dailyHundredImportV1Ingress`（不写环境密钥）。
4. 只改这一条路由，时间 **2026-11-12 15:33:28（Asia/Shanghai）**。其他 5 条路由未变。
5. 第一次探测时，大包已经不再 413，但事件函数返回了 `invalid_request`。原因是 HTTP 网关塞进来的头太多/对不上现网函数的严格校验。已只转发函数真正要用的 `Authorization` 和 `Content-Type`，并在 15:36 左右只更新了入口函数代码（路由不用再改）。复测后大包/小包均达到上面的结果。

## 若要回滚

事件函数一直保持原样，把路由改回去即可：

```
tcb routes edit -e fh6-d5ga45c0ddae7008c --yes --data '{"domain":"fh6-d5ga45c0ddae7008c-1439321968.ap-shanghai.app.tcloudbase.com","routes":[{"path":"/api/import-ai/v1","upstreamResourceType":"SCF","upstreamResourceName":"dailyHundredImportV1Event"}]}'
```

注意：在 PowerShell 里直接传 `--data` 容易把 JSON 引号吃掉，应用官方 `tcb` 的 node 入口按参数数组传，或先确保 `--yes` 生效。回滚后，大于 100KiB 的 JSON 会再次 413。

## 本回合没有做的事

- 没有改提进截图、发图、提示词、点击逻辑，没有出 0.4.4
- 没有上传蒲公英，没有动用户手机，没有改账本，没有真实扣费
- 没有读取事件函数环境变量或密钥
