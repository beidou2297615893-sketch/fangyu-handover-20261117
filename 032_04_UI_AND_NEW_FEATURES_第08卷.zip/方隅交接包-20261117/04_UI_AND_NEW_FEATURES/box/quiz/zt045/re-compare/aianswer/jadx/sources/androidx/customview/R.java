package androidx.customview;

/* JADX INFO: loaded from: classes.dex */
public final class R {

    public static final class attr {
        public static int alpha = 0x7f010000;
        public static int font = 0x7f010005;
        public static int fontProviderAuthority = 0x7f010006;
        public static int fontProviderCerts = 0x7f010007;
        public static int fontProviderFetchStrategy = 0x7f010008;
        public static int fontProviderFetchTimeout = 0x7f010009;
        public static int fontProviderPackage = 0x7f01000a;
        public static int fontProviderQuery = 0x7f01000b;
        public static int fontStyle = 0x7f01000c;
        public static int fontVariationSettings = 0x7f01000d;
        public static int fontWeight = 0x7f01000e;
        public static int ttcIndex = 0x7f01001a;

        private attr() {
        }
    }

    public static final class color {
        public static int notification_action_color_filter = 0x7f020017;
        public static int notification_icon_bg_color = 0x7f020018;
        public static int ripple_material_light = 0x7f02001e;
        public static int secondary_text_default_material_light = 0x7f02001f;

        private color() {
        }
    }

    public static final class dimen {
        public static int compat_button_inset_horizontal_material = 0x7f030000;
        public static int compat_button_inset_vertical_material = 0x7f030001;
        public static int compat_button_padding_horizontal_material = 0x7f030002;
        public static int compat_button_padding_vertical_material = 0x7f030003;
        public static int compat_control_corner_material = 0x7f030004;
        public static int compat_notification_large_icon_max_height = 0x7f030005;
        public static int compat_notification_large_icon_max_width = 0x7f030006;
        public static int notification_action_icon_size = 0x7f030007;
        public static int notification_action_text_size = 0x7f030008;
        public static int notification_big_circle_margin = 0x7f030009;
        public static int notification_content_margin_start = 0x7f03000a;
        public static int notification_large_icon_height = 0x7f03000b;
        public static int notification_large_icon_width = 0x7f03000c;
        public static int notification_main_column_padding_top = 0x7f03000d;
        public static int notification_media_narrow_margin = 0x7f03000e;
        public static int notification_right_icon_size = 0x7f03000f;
        public static int notification_right_side_padding_top = 0x7f030010;
        public static int notification_small_icon_background_padding = 0x7f030011;
        public static int notification_small_icon_size_as_large = 0x7f030012;
        public static int notification_subtext_size = 0x7f030013;
        public static int notification_top_pad = 0x7f030014;
        public static int notification_top_pad_large_text = 0x7f030015;

        private dimen() {
        }
    }

    public static final class drawable {
        public static int notification_action_background = 0x7f040029;
        public static int notification_bg = 0x7f04002a;
        public static int notification_bg_low = 0x7f04002b;
        public static int notification_bg_low_normal = 0x7f04002c;
        public static int notification_bg_low_pressed = 0x7f04002d;
        public static int notification_bg_normal = 0x7f04002e;
        public static int notification_bg_normal_pressed = 0x7f04002f;
        public static int notification_icon_background = 0x7f040030;
        public static int notification_template_icon_bg = 0x7f040031;
        public static int notification_template_icon_low_bg = 0x7f040032;
        public static int notification_tile_bg = 0x7f040033;
        public static int notify_panel_notification_icon_bg = 0x7f040034;

        private drawable() {
        }
    }

    public static final class id {
        public static int action_container = 0x7f050021;
        public static int action_divider = 0x7f050022;
        public static int action_image = 0x7f050023;
        public static int action_text = 0x7f050024;
        public static int actions = 0x7f050025;
        public static int async = 0x7f050029;
        public static int blocking = 0x7f05002b;
        public static int chronometer = 0x7f05005f;
        public static int forever = 0x7f05006c;
        public static int icon = 0x7f05006d;
        public static int icon_group = 0x7f05006e;
        public static int info = 0x7f050070;
        public static int italic = 0x7f050071;
        public static int line1 = 0x7f050074;
        public static int line3 = 0x7f050075;
        public static int normal = 0x7f050077;
        public static int notification_background = 0x7f050078;
        public static int notification_main_column = 0x7f050079;
        public static int notification_main_column_container = 0x7f05007a;
        public static int right_icon = 0x7f05007d;
        public static int right_side = 0x7f05007e;
        public static int tag_transition_group = 0x7f05009c;
        public static int tag_unhandled_key_event_manager = 0x7f05009d;
        public static int tag_unhandled_key_listeners = 0x7f05009e;
        public static int text = 0x7f05009f;
        public static int text2 = 0x7f0500a0;
        public static int time = 0x7f0500a1;
        public static int title = 0x7f0500a2;

        private id() {
        }
    }

    public static final class integer {
        public static int status_bar_notification_info_maxnum = 0x7f060001;

        private integer() {
        }
    }

    public static final class layout {
        public static int notification_action = 0x7f07000f;
        public static int notification_action_tombstone = 0x7f070010;
        public static int notification_template_custom_big = 0x7f070011;
        public static int notification_template_icon_group = 0x7f070012;
        public static int notification_template_part_chronometer = 0x7f070013;
        public static int notification_template_part_time = 0x7f070014;

        private layout() {
        }
    }

    public static final class string {
        public static int status_bar_notification_info_overflow = 0x7f090014;

        private string() {
        }
    }

    public static final class style {
        public static int TextAppearance_Compat_Notification = 0x7f0a000c;
        public static int TextAppearance_Compat_Notification_Info = 0x7f0a000d;
        public static int TextAppearance_Compat_Notification_Line2 = 0x7f0a000e;
        public static int TextAppearance_Compat_Notification_Time = 0x7f0a000f;
        public static int TextAppearance_Compat_Notification_Title = 0x7f0a0010;
        public static int Widget_Compat_NotificationActionContainer = 0x7f0a0013;
        public static int Widget_Compat_NotificationActionText = 0x7f0a0014;

        private style() {
        }
    }

    public static final class styleable {
        public static int ColorStateListItem_alpha = 0x00000002;
        public static int ColorStateListItem_android_alpha = 0x00000001;
        public static int ColorStateListItem_android_color = 0x00000000;
        public static int FontFamilyFont_android_font = 0x00000000;
        public static int FontFamilyFont_android_fontStyle = 0x00000002;
        public static int FontFamilyFont_android_fontVariationSettings = 0x00000004;
        public static int FontFamilyFont_android_fontWeight = 0x00000001;
        public static int FontFamilyFont_android_ttcIndex = 0x00000003;
        public static int FontFamilyFont_font = 0x00000005;
        public static int FontFamilyFont_fontStyle = 0x00000006;
        public static int FontFamilyFont_fontVariationSettings = 0x00000007;
        public static int FontFamilyFont_fontWeight = 0x00000008;
        public static int FontFamilyFont_ttcIndex = 0x00000009;
        public static int FontFamily_fontProviderAuthority = 0x00000000;
        public static int FontFamily_fontProviderCerts = 0x00000001;
        public static int FontFamily_fontProviderFetchStrategy = 0x00000002;
        public static int FontFamily_fontProviderFetchTimeout = 0x00000003;
        public static int FontFamily_fontProviderPackage = 0x00000004;
        public static int FontFamily_fontProviderQuery = 0x00000005;
        public static int GradientColorItem_android_color = 0x00000000;
        public static int GradientColorItem_android_offset = 0x00000001;
        public static int GradientColor_android_centerColor = 0x00000007;
        public static int GradientColor_android_centerX = 0x00000003;
        public static int GradientColor_android_centerY = 0x00000004;
        public static int GradientColor_android_endColor = 0x00000001;
        public static int GradientColor_android_endX = 0x0000000a;
        public static int GradientColor_android_endY = 0x0000000b;
        public static int GradientColor_android_gradientRadius = 0x00000005;
        public static int GradientColor_android_startColor = 0x00000000;
        public static int GradientColor_android_startX = 0x00000008;
        public static int GradientColor_android_startY = 0x00000009;
        public static int GradientColor_android_tileMode = 0x00000006;
        public static int GradientColor_android_type = 0x00000002;
        public static int[] ColorStateListItem = {android.R.attr.color, android.R.attr.alpha, com.dsh.aianswer.R.attr.alpha};
        public static int[] FontFamily = {com.dsh.aianswer.R.attr.fontProviderAuthority, com.dsh.aianswer.R.attr.fontProviderCerts, com.dsh.aianswer.R.attr.fontProviderFetchStrategy, com.dsh.aianswer.R.attr.fontProviderFetchTimeout, com.dsh.aianswer.R.attr.fontProviderPackage, com.dsh.aianswer.R.attr.fontProviderQuery};
        public static int[] FontFamilyFont = {android.R.attr.font, android.R.attr.fontWeight, android.R.attr.fontStyle, android.R.attr.ttcIndex, android.R.attr.fontVariationSettings, com.dsh.aianswer.R.attr.font, com.dsh.aianswer.R.attr.fontStyle, com.dsh.aianswer.R.attr.fontVariationSettings, com.dsh.aianswer.R.attr.fontWeight, com.dsh.aianswer.R.attr.ttcIndex};
        public static int[] GradientColor = {android.R.attr.startColor, android.R.attr.endColor, android.R.attr.type, android.R.attr.centerX, android.R.attr.centerY, android.R.attr.gradientRadius, android.R.attr.tileMode, android.R.attr.centerColor, android.R.attr.startX, android.R.attr.startY, android.R.attr.endX, android.R.attr.endY};
        public static int[] GradientColorItem = {android.R.attr.color, android.R.attr.offset};

        private styleable() {
        }
    }

    private R() {
    }
}
