#!/usr/bin/env python3
import json, time, subprocess
from pathlib import Path

KEY_PATH = Path("/workspace/zt045/pgyer-upload/api_key.txt")
APK_PATH = Path("/workspace/zt045/pgyer-upload/zhiti-0.4.22.apk")
OUT_PATH = Path("/workspace/zt045/pgyer-upload/pgyer-upload-0422.json")
DESC = (
    "修复两点：点「一键答题」后不再立刻识别，需先点左侧「知」展开悬浮窗，再点「开始答题」；"
    "识别失败后「重试」「继续」会立即有反馈。"
    "请覆盖安装，不要卸载，保留题库和记录。"
)

def main():
    if not KEY_PATH.is_file():
        raise SystemExit("missing api key file")
    key = KEY_PATH.read_text(encoding="utf-8").strip()
    if len(key) != 32 or any(c not in "0123456789abcdefABCDEF" for c in key):
        raise SystemExit("api key file looks invalid")
    if not APK_PATH.is_file():
        raise SystemExit("missing apk")
    started = time.time()
    cmd = [
        "curl", "-sS", "-X", "POST", "https://www.pgyer.com/apiv2/app/upload",
        "-F", f"_api_key={key}",
        "-F", f"file=@{APK_PATH}",
        "-F", "buildInstallType=1",
        "-F", f"buildUpdateDescription={DESC}",
    ]
    proc = subprocess.run(cmd, capture_output=True, text=True)
    elapsed = time.time() - started
    key = ""
    if proc.returncode != 0:
        OUT_PATH.write_text(json.dumps({"ok": False, "elapsed": elapsed, "stderr": proc.stderr[-2000:]}, ensure_ascii=False, indent=2), encoding="utf-8")
        raise SystemExit(f"curl failed: {proc.returncode}")
    try:
        data = json.loads(proc.stdout)
    except Exception:
        OUT_PATH.write_text(json.dumps({"ok": False, "elapsed": elapsed, "raw": proc.stdout[-2000:]}, ensure_ascii=False, indent=2), encoding="utf-8")
        raise SystemExit("non-json response")
    slim = {"elapsed": elapsed, "http_transport": "curl", "response": data}
    OUT_PATH.write_text(json.dumps(slim, ensure_ascii=False, indent=2), encoding="utf-8")
    code = data.get("code")
    print("upload_code", code)
    d = data.get("data") or {}
    print("buildVersion", d.get("buildVersion"))
    print("buildVersionNo", d.get("buildVersionNo"))
    print("buildBuildVersion", d.get("buildBuildVersion"))
    print("buildShortcutUrl", d.get("buildShortcutUrl"))
    print("buildFileSize", d.get("buildFileSize"))
    print("buildKey", d.get("buildKey"))
    if code != 0:
        raise SystemExit("pgyer returned error")

if __name__ == "__main__":
    main()
