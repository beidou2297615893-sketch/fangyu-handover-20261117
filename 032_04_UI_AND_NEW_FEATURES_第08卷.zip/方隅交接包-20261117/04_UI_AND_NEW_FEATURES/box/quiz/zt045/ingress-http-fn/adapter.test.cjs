'use strict';
const assert = require('node:assert/strict');
const { toEvent, fromEnvelope } = require('./adapter.cjs');
const { invokeEventFunction } = require('./invoke.cjs');
const { createSessionEvent } = require('./session-event-compat.cjs');

const body = Buffer.from('{"hello":"world"}');
const event = toEvent({
  method: 'POST',
  url: '/api/import-ai/v1/openai/chat/completions',
  headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + 'A'.repeat(43) },
}, body);
assert.equal(event.path, '/api/import-ai/v1/openai/chat/completions');
assert.equal(event.httpMethod, 'POST');
assert.equal(event.isBase64Encoded, false);
assert.equal(event.body, body.toString('utf8'));
assert.equal(event.headers['content-type'], 'application/json');
assert.deepEqual(event.multiValueHeaders['content-type'], ['application/json']);
assert.equal(event.headers.authorization.startsWith('Bearer '), true);
assert.equal(Object.keys(event.headers).sort().join(','), 'authorization,content-type');
const ev3 = toEvent({
  method: 'POST',
  url: '/api/import-ai/v1/openai/chat/completions',
  headers: {
    'content-type': 'application/json',
    authorization: 'Bearer tok',
    'x-forwarded-for': '1.2.3.4',
    host: 'example',
    'x-scf-request-id': 'abc',
    'user-agent': 'probe',
  },
}, body);
assert.equal(Object.keys(ev3.headers).sort().join(','), 'authorization,content-type');
assert.deepEqual(ev3.multiValueHeaders.authorization, ['Bearer tok']);

const large = Buffer.alloc(300000, 120);
const ev2 = toEvent({ method: 'POST', url: '/api/import-ai/v1/openai/chat/completions', headers: { 'content-type': 'application/json' } }, large);
assert.equal(Buffer.byteLength(ev2.body, 'utf8'), 300000);
assert.equal(ev2.isBase64Encoded, false);

// Mirror of the live session handler rule: isBase64Encoded===true is rejected.
const sessionBody = Buffer.from(JSON.stringify({
  runId: 'r1',
  source: 'paid',
  taskBinding: 'a'.repeat(64),
}));
const sessionReq = {
  method: 'POST',
  url: '/api/import-ai/v1/openai/session',
  headers: { 'content-type': 'application/json', authorization: 'Bearer ' + 'B'.repeat(43) },
};
const sessionEvent = toEvent(sessionReq, sessionBody);
assert.equal(sessionEvent.path, '/api/import-ai/v1/openai/session');
assert.equal(sessionEvent.isBase64Encoded, false);
assert.equal(sessionEvent.body, sessionBody.toString('utf8'));

const oldStyle = {
  ...sessionEvent,
  body: sessionBody.toString('base64'),
  isBase64Encoded: true,
};

(async () => {
  const envelope = await invokeEventFunction({
    functionName: 'dailyHundredImportV1Event',
    namespace: 'fh6-d5ga45c0ddae7008c',
    region: 'ap-shanghai',
    event: ev2,
    invokeImpl: async ({ event }) => {
      assert.equal(event.isBase64Encoded, false);
      assert.equal(Buffer.byteLength(event.body, 'utf8'), 300000);
      return { statusCode: 401, headers: { 'content-type': 'application/json' }, body: '{"error":"unauthorized"}', isBase64Encoded: false };
    },
  });
  assert.equal(envelope.statusCode, 401);
  const out = fromEnvelope(envelope);
  assert.equal(out.status, 401);

  const handler = createSessionEvent({
    async exchange(input) {
      assert.equal(input.credential, 'B'.repeat(43));
      assert.equal(input.runId, 'r1');
      assert.equal(input.source, 'paid');
      assert.equal(input.taskBinding, 'a'.repeat(64));
      return { token: 'C'.repeat(43), expiresAt: Date.now() + 3600000, limit: 160, used: 0 };
    },
    async close() { return true; },
  });
  const rejected = await handler(oldStyle);
  assert.equal(rejected.statusCode, 503);
  assert.equal(JSON.parse(rejected.body).error, 'session_unavailable');
  const accepted = await handler(sessionEvent);
  assert.equal(accepted.statusCode, 200);
  assert.equal(JSON.parse(accepted.body).limit, 160);
  console.log('adapter tests ok');
})().catch((e) => { console.error(e); process.exit(1); });
