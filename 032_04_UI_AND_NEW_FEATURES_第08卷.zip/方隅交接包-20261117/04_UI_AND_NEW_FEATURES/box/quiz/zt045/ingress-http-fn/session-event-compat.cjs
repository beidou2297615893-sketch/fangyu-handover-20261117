'use strict';
const EXCHANGE='/api/import-ai/v1/openai/session',CLOSE=EXCHANGE+'/close';
const out=(status,value)=>({statusCode:status,headers:{'content-type':'application/json; charset=utf-8','cache-control':'no-store','x-content-type-options':'nosniff'},body:JSON.stringify(value),isBase64Encoded:false});
function bearer(e){const h=e.headers;if(!h||typeof h!=='object'||Array.isArray(h)||Object.keys(h).length>50)throw Error();const x=Object.create(null);for(const [k,v] of Object.entries(h)){const n=k.toLowerCase();if(Object.hasOwn(x,n)||typeof v!=='string'||/[\r\n\0]/.test(v))throw Error();x[n]=v}if(e.multiValueHeaders!==undefined){const m=e.multiValueHeaders,y=Object.create(null);if(!m||typeof m!=='object'||Array.isArray(m)||Object.keys(m).length>50)throw Error();for(const [k,v] of Object.entries(m)){const n=k.toLowerCase();if(Object.hasOwn(y,n)||!Array.isArray(v)||v.length!==1||v[0]!==x[n])throw Error();y[n]=true}if(Object.keys(y).length!==Object.keys(x).length)throw Error()}const z=/^Bearer ([A-Za-z0-9_-]{43})$/.exec(x.authorization||'');if(!z)throw Error();return z[1]}
function createSessionEvent(sessions){return async event=>{try{
 if(event?.httpMethod!=='POST'||![EXCHANGE,CLOSE].includes(event.path))return out(404,{error:'not_found'});const token=bearer(event);
 if(event.path===CLOSE){await sessions.close(token);return out(200,{closed:true})}
 if(event.isBase64Encoded===true||typeof event.body!=='string'||Buffer.byteLength(event.body)>8192)throw Error();const v=JSON.parse(event.body),keys=Object.keys(v||{}).sort().join(',');if(keys!=='runId,source,taskBinding'&&keys!=='deviceDigest,runId,source,taskBinding')throw Error();
 if((v.source==='free')!==Object.hasOwn(v,'deviceDigest'))throw Error();const r=await sessions.exchange({credential:token,...v});return out(200,r);
 }catch{return out(503,{error:'session_unavailable'})}}}
module.exports={EXCHANGE,CLOSE,createSessionEvent};
