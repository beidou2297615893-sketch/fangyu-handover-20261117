# 知题 0.4.22（versionCode 89）模拟器实测报告

- 测试时间：2026-11-14 20:50–21:06（亚洲/上海，UTC+8）
- 测试机：用户本机 RMSAMA（machineId `f79a5338-7ab9-41e1-bad0-3f5c3b1dd392`）
- 模拟器：`adb -P 5037 -s emulator-5556`（知题专机）。未碰 emulator-5554（提镜原版）、emulator-5588（AI答题），也未新开 tijing_independent。
- 安装包：`C:\Users\rmsama\AppData\Local\Temp\zt0422-gpt-pack\zhiti-0.4.22.apk`，6,599,055 字节，SHA-256 `0DD2AC8F793F77C83697453034A9942185EF58D6DA23AD77D058EE9A1FDA3A45`
- 安装方式：`adb install -r` 覆盖安装，未卸载、未 `pm clear`、未改铁路宿主 `com.jimusoft.railwaymp`
- 版本核对：`dumpsys package com.jimusoft.dailyhundredapp` → **versionName=0.4.22，versionCode=89**。`firstInstallTime` 仍为模拟器时区 2026-11-14 06:15:40（即亚洲/上海 14:15:40），说明数据保留；`lastUpdateTime` 为模拟器 12:50:35（亚洲/上海 20:50:35）
- 模拟器时区为 GMT，截图状态栏是 GMT 时刻；下文凡未另行标注的，一律换算成亚洲/上海。
- 截图本机目录：`C:\Users\rmsama\AppData\Local\Temp\zt0422-gpt-pack\emu-test-0422\`
- 截图与日志副本：`/workspace/zt045/fix-until-clean/emu-test/`
- 本次只实测，未改代码、未上传蒲公英、未动付款、未改 tijing-upstream 与铁路题目应用。

## 各步结论

### 1）打开知题后点「一键答题」——通过（流程上多一页，没有立刻开跑）

- 打开知题首页（已导入 1,859 题）后，点「一键答题」**没有立刻开始识别**，而是进入「一键答题」状态页：当前状态「未开始」，权限「悬浮窗与无障碍已开启」，底部有「开始答题」。
- 再点状态页「开始答题」，系统弹出录屏授权（Start recording or casting with 知题？ Entire screen）。同意后出现左侧「知」图标，状态先是「正在准备」，随后切到铁路宿主「随机百题」，悬浮球仍在，**没有自动开跑**。
- 与「一点首页一键答题就直接出左侧知图标」的字面描述相比，中间多了状态页和系统录屏授权，但这是预期权限流程，且没有立刻识别。

证据：

- `/workspace/zt045/fix-until-clean/emu-test/01b-zhiti-after-wait.png` 首页
- `/workspace/zt045/fix-until-clean/emu-test/02-after-onekey.png` 状态页，未开始
- `/workspace/zt045/fix-until-clean/emu-test/03-after-start-quiz-0.6s.png` 系统录屏授权
- `/workspace/zt045/fix-until-clean/emu-test/04-after-grant-capture-0.8s.png` 左侧「知」+「正在准备」
- `/workspace/zt045/fix-until-clean/emu-test/04b-after-grant-capture-3s.png` 已在「随机百题」，仅「知」图标，选项未选

### 2）点「知」展开悬浮窗，「开始答题」在窗内，点图标本身不开跑——通过

- 点左侧「知」后展开悬浮窗，标题「知题」，状态「待开始」，右侧有「开始答题」。
- 点图标后至少 2 秒内仍为「待开始」，选项未选，「确认答案」仍灰。图标本身不会立刻开跑。

证据：

- `/workspace/zt045/fix-until-clean/emu-test/05-before-tap-zhi.png` 收起态
- `/workspace/zt045/fix-until-clean/emu-test/06-after-tap-zhi-0.6s.png` 展开态（2 秒后画面相同）

### 3）在「随机百题」页点悬浮窗「开始答题」，识别/点选——失败（卡在权限核对）

- 点窗内「开始答题」后，悬浮窗收起，顶部出现「第 1 题 · 识别中 / 正在核对本轮答题权限，请保持题目页打开。」
- 约十几秒后变为「答题已暂停 / 答题授权暂未确认，请保留本次任务重试；如需新一轮，请明确结束本轮后重新开始。」出现「重试」「继续」「停止」。
- 全程停留在 53/100 同一题（「急停车手信号的显示地点为（）。」），选项从未被点选，「确认答案」一直是灰的。识别没有进入作答，点选未发生。

证据：

- `/workspace/zt045/fix-until-clean/emu-test/07-after-start-0.7s.png` 识别中、核对权限
- `/workspace/zt045/fix-until-clean/emu-test/08-after-start-plus10s.png` 答题已暂停、授权未确认
- 日志（模拟器 GMT 12:57:41.934 = 亚洲/上海 20:57:41）：`I ZhitiSession: http=503 error=session_unavailable`  
  文件：`/workspace/zt045/fix-until-clean/emu-test/logcat-key.txt`

### 4）实际点「重试」和「继续」——通过（按钮能点中且立即有反馈）

- **重试**：暂停框仍在时点「重试」（坐标约 232,450）。**0.4 秒内**暂停框消失，回到「第 1 题 · 识别中 / 正在核对本轮答题权限」。按钮可点中，反馈立即可见。
- 重试之后再次暂停，文案变成英文技术错误「Connection reset」，随后又变成英文 DNS 错误（见剩余问题）。
- **继续**：第一次误点到英文报错文字（坐标 546,377），界面无变化。按当帧按钮中心 546,475 再点，**0.4 秒内**回到「第 1 题 · 识别中 / 正在核对本轮答题权限」。按钮可点中，反馈立即可见。
- 继续后约 5 秒再次出现 `ZhitiSession: http=503 error=session_unavailable`（模拟器 13:04:51.933 = 亚洲/上海 21:04:51），随后又回到「答题已暂停 / 答题授权暂未确认」。

证据：

- 重试前 `/workspace/zt045/fix-until-clean/emu-test/09-before-retry.png`
- 重试后 0.4 秒 `/workspace/zt045/fix-until-clean/emu-test/10-after-retry-0.4s.png`
- 继续前（DNS 英文报错）`/workspace/zt045/fix-until-clean/emu-test/12-before-continue.png`
- 继续后 0.4 秒 `/workspace/zt045/fix-until-clean/emu-test/14-after-continue-0.4s.png`
- 继续后再次暂停 `/workspace/zt045/fix-until-clean/emu-test/15-after-continue-current.png`

### 5）短跑几道题，看点选、换题、暂停——受阻，未能实测

因为第 3、4 步始终停在「核对本轮答题权限」失败，软件从未选出选项、从未换题。无法验证点选是否点准、换题是否跟上、暂停是否在作答过程中可恢复。不是「跑完一百道」的问题，而是第一题都没有进入作答。

## 剩余问题清单

1. **开始答题后本轮授权校验失败，无法进入识别作答（阻塞主流程）**  
   两次实际发起会话都返回 `ZhitiSession: http=503 error=session_unavailable`（亚洲/上海 20:57:41、21:04:51）。界面表现为「正在核对本轮答题权限」→「答题已暂停 / 答题授权暂未确认」。覆盖安装未清数据，不能断定是客户端会话丢失、云函数 503，还是账号/会话未就绪，但这是本次测不下去的直接原因。  
   截图：`08-after-start-plus10s.png`、`15-after-continue-current.png`  
   日志：`emu-test/logcat-key.txt`

2. **暂停原因直接把英文技术异常铺到用户界面（体验缺陷）**  
   点「重试」后的暂停文案出现过：  
   - `Connection reset`（`11-after-retry-current.png`）  
   - `Unable to resolve host "fh6-d5ga45c0ddae7008c-1439321968.ap-shanghai.app.tcloudbase.com": No address associated with hostname`（`12-before-continue.png`）  
   这是原始异常字符串，未本地化，也过长，会把暂停条撑高、把「重试/继续」按钮挤下去。后来模拟器上对该域名 `ping` 可以通（CNAME 到 `prod.ap-shanghai.service.tencentcloudbase.com` / `110.40.162.120`，rtt 约 12.5 ms），说明 DNS 是间歇性的；但即便 DNS 恢复，下一次仍是 503 `session_unavailable`。

3. **收起态「知」图标默认压在题干预部**  
   在铁路「随机百题」页，图标约在 (23,482)-(186,645)，正好挡住题干首字「急」。通用软件不能改宿主页面来让位，图标默认位置应避开题干。  
   截图：`04b-after-grant-capture-3s.png`、`05-before-tap-zhi.png`、`07-after-start-0.7s.png`

4. **展开的悬浮窗大面积挡住题干和选项 A**  
   展开后窗口约 (21,385) 起、宽 945、高 359，把题干几乎全部盖住，选项 A 只露出半截。要看题或核对识别结果时必须先收起。  
   截图：`06-after-tap-zhi-0.6s.png`

5. **暂停条同样挡住题干，并与「知」图标重叠**  
   「答题已暂停」条盖住题干，「知」图标从条下露出，短文案时更容易贴近「重试」左下。本次点「重试/继续」中心是能点中的，但误点到英文报错文字时没有任何反馈（见步骤 4）。  
   截图：`08-after-start-plus10s.png`、`11-after-retry-current.png`、`12-before-continue.png`

6. **系统把不可点击悬浮窗透明度压到 0.80（潜在点击/观感问题）**  
   logcat：`WindowManager: App com.jimusoft.dailyhundredapp has a system alert window (type = 2038) with FLAG_NOT_TOUCHABLE and LayoutParams.alpha = 1.00 > 0.80, setting alpha to 0.80 to let touches pass through`。出现在点「知」、点「开始答题」前后。如果某些浮层既要全不透明又声明不可点，系统会强制半透明，可能造成观感发虚或点击命中与视觉不一致。

7. **Toast 很快被系统杀掉，用户可能看不到瞬时提示**  
   每次会话失败后约 4–5 秒出现 `NotificationService: Toast already killed. pkg=com.jimusoft.dailyhundredapp`（亚洲/上海 20:57:46、21:02:15、21:03:49、21:04:56）。暂停框本身还在，但若还有 Toast 补充说明，用户很可能来不及看到。

## 测试受阻点

主流程卡在「本轮答题权限/会话校验」：`ZhitiSession http=503 error=session_unavailable`，并夹杂间歇性 DNS/`Connection reset`。因此：

- 未能验证识别是否找对题、点选是否点准、换题是否跟上；
- 未能在「正在作答」过程中再测暂停/恢复；
- 不是模拟器连不上或安装失败。模拟器 `emulator-5556` 全程 device，安装与版本已确认，广告宿主「随机百题」页可打开，「重试/继续」按钮本身可用。

下一步若要继续改到「手机上完全没问题」，应先查清 503 `session_unavailable` 是会话未建立、云函数异常，还是客户端请求问题；同时不要把 `Connection reset`、Unable to resolve host 这类原始英文异常直接展示给用户；并处理「知」图标与展开窗挡住题干的问题。本次未改代码。

## 关键日志摘录

模拟器时间为 GMT，对应亚洲/上海 +8 小时。完整摘录见 `emu-test/logcat-key.txt`。

```
11-14 12:55:46.236  ScreenCaptureService 已启动（授权录屏后）
11-14 12:56:44.227  WindowManager 将 FLAG_NOT_TOUCHABLE 浮层 alpha 压到 0.80
11-14 12:57:33.246  TrafficStats tagSocket（开始答题后的网络请求）
11-14 12:57:41.934  I ZhitiSession: http=503 error=session_unavailable
11-14 12:57:46.279  Toast already killed. pkg=com.jimusoft.dailyhundredapp
11-14 13:02:15.037  Toast already killed（重试后的 Connection reset 阶段）
11-14 13:04:46.679  TrafficStats tagSocket（点「继续」后立刻发起请求）
11-14 13:04:51.933  I ZhitiSession: http=503 error=session_unavailable
11-14 13:04:56.114  Toast already killed
```
