# 知题 0.4.22 会话 503 根因（emulator-5556）

时间：2026-11-14 21:21（亚洲/上海，UTC+8）  
范围：只查因，未改代码、未上传蒲公英、未真扣费、未卸载或清理知题数据、未改铁路宿主。  
未把 token、apiKey、付款号、deviceDigest、Authorization 头或完整请求体写入本文件或其他日志。

## 结论

**无法区分：现有证据不能判定是「这台测试机没有可用的本轮权益/会话」，还是「线上入口对合法会话也会失败」。**

可以排除的是：线上 `/session` 入口此刻并没有整体宕掉。用明显无效的占位凭据探测时，入口仍在、会进入原来的会话处理，并对无效凭据返回 503 `session_unavailable`（这是历史上的预期表现，不能用来证明真会话也会失败）。  
正式包不是 debuggable，`run-as` 失败；随后在用户本机对 `emulator-5556` 提权读账本时本机断线，**当前模拟器里的免费/付费、phase、是否 closed/ending、是否过期，未能读到**。没有这份本轮状态，就不能把 503 坐实到其中一侧。

## 已能证实

1. **测试包就是 0.4.22，数据还在。**  
   `adb -P 5037 -s emulator-5556`：`versionName=0.4.22`，`versionCode=89`。`firstInstallTime` 为模拟器 GMT 2026-11-14 06:15:40（亚洲/上海 14:15:40），`lastUpdateTime` 为 12:50:35（亚洲/上海 20:50:35）。覆盖安装，不是重装清空。`run-as com.jimusoft.dailyhundredapp` 失败，原因是 `package not debuggable`。

2. **客户端当时已经拿到某种授权，并且请求已经打到会话接口。**  
   源码里只有 `GatewaySessionEntry.call()` 会打 `ZhitiSession: http=…`；要走到这里，必须先过 `gatewayAuthorizationOnWorker()`（本地账本核对并 confirm），再 POST `/session`。  
   日志：亚洲/上海 20:57:33、20:57:37 有 `TrafficStats tagSocket`，20:57:41 出现 `I ZhitiSession: http=503 error=session_unavailable`；21:04:46 再次 tagSocket，21:04:51 再次同一条 503。界面「答题授权暂未确认…」对应的是非 200/402/403 的统一文案，不是 402「权益不足」或 403「授权被拒绝」，也不是本地抛出的「本次答题授权已结束 / 上轮结束状态已核对」。  
   因此：不是「请求没发出」，也不是「客户端在发 `/session` 之前就判定本轮不可用」。

3. **线上入口现在是活的，对格式正确的假凭据仍返回 503，且不是入口编码把请求挡死。**  
   2026-11-14 21:18:56（亚洲/上海）用明显无效的 43 位占位凭据探测同一入口，结果与 2026-11-12 修复后的探针一致：
   - `POST /session`（付费形态、免费形态的占位正文）→ HTTP 503，`{"error":"session_unavailable"}`，约 0.8–1.3 秒
   - `POST /session/close` → 同样 503
   - 错误路径 `/session/nope` → HTTP 404，`请求地址无效，请重新开始`（说明请求仍打到原事件函数，而不是入口自己吞掉）
   - 小包 `/chat/completions` → HTTP 502，`{"error":"gateway_unavailable"}`（假凭据的预期，说明事件函数可到达）
   - `/session` 响应带 `x-content-type-options: nosniff` 和 `content-type: application/json; charset=utf-8`，与 `session-event-compat` 的统一输出头相符，说明会话处理函数本身在跑。  
   2026-11-12 已把入口转发改为 UTF-8 原文、`isBase64Encoded:false`；若旧的 base64 编码问题仍在，会话处理会在解析阶段抛错并同样给出 503。本次错误路径能返回事件函数自己的 404 文案，说明「请求进不去事件函数」不是当前主因。但假凭据探测**不能**证明真月卡/合法会话会返回 200（历史上也从未用假凭据证实过 200）。

4. **503 在服务端是「校验失败或任何异常」的笼统返回，单凭这一句无法分流。**  
   `session-event-compat`：Bearer 格式不对、正文编码/字段不符、`source=free` 与 `deviceDigest` 不匹配、或 `sessions.exchange()` 失败，一律 `503 session_unavailable`。客户端把除 402/403 外的 HTTP 错误都显示成「答题授权暂未确认」。所以这次日志里的 503，既可能是「这台机器的凭据/本轮会话在服务端不可用」，也可能是「exchange 自身异常」，从这一行看不出来。

5. **历史上同一台测试机出现过「本地计费已通过，再开会话仍 503」。**  
   2026-11-13 交接：随机百题上已有 3 条 `source=free`、`phase=confirmed` 的任务，按规则免费次数计为 0；对应云端看图会话当时已是 `closed`（且会到期）。客户端再调 `/session` 就会是 503。当时数据未清。本次 0.4.22 仍是覆盖安装、未清数据，测试过程也没有点「停止」。**这只能说明「测试机沿用已关闭/已过期会话」是一种合理可能，不能当作今天已经核实的本轮状态。**

## 未能证实（因本机账本未读到）

以下在本次未能核实，不能猜死：

- 模拟器当前 `gateway-run-v1` 指向哪一条任务，以及该条的 `source`（free / credit / subscription / pending）、`phase`（reserved / confirmed / released / …）、`submissionState`。
- 本地加密的 gateway 记录是否存在，`state` 是否为 closed / ending，本地会话是否已过期。只能从行为反推：若本地已是「同 run 且 closed」或「ending」，客户端不会去打 `/session`，而这次打了，所以**当时**不像是「本地已标记本轮结束」；但读不到文件，不能写出当前字段。
- 服务端对该 run 的会话是 active、closed 还是已过期；也没有用真实凭据做探测（按要求不能这么做）。
- 因此不能在「测试机没有可用本轮权益/会话」和「线上入口对合法会话也会 503」之间做最终取舍。

## 证据路径

- 实测报告与两次 503 时间：`/workspace/zt045/fix-until-clean/REPORT.md`
- 关键日志：`/workspace/zt045/fix-until-clean/emu-test/logcat-key.txt`（模拟器 GMT 12:57:41、13:04:51，即亚洲/上海 20:57:41、21:04:51）
- 客户端会话入口源码：`/workspace/zt045/fix-until-clean/GatewaySessionEntry.kt`（非 200/402/403 →「答题授权暂未确认」）
- 云函数笼统 503：`/workspace/zt045/ingress-http-fn/session-event-compat.cjs`
- 本次假凭据探针（无真实密钥）：`/workspace/zt045/fix-until-clean/session-probe-fake-token.json`
- 2026-11-12 入口修复与「假 token 预期 503、真月卡 200 未证实」：`/workspace/zt045/STATUS.md`、`/workspace/zt045/evidence/ingress-session-fix-probe.json`
- 2026-11-13 同机「计费已过、云端会话已 closed，再开仍 503」：`/workspace/zt045/STATUS-044-watch.md`、`/workspace/zt045/evidence/044-100watch-handoff.txt`

## 下一步建议（不要在本轮改代码）

1. 等用户本机 RMSAMA 稳定后，只用 `adb -P 5037 -s emulator-5556`（不要碰 5554、5588）。正式包 `run-as` 会失败，可在模拟器上对 5556 单独提权后**只读**拷出账本，抽取非敏感字段：`source`、`phase`、`submissionState`、目标包名、gateway 是否存在及 state/是否过期（不要输出 token、binding 原文、deviceDigest、完整 prefs 或收据）。写进本文件的补录即可。
2. 若本轮仍是旧的已确认免费任务、且本地/云端会话已 closed 或已过期：优先按「这台测试机没有可重开的本轮会话」处理，不要把它解释成入口整体故障；也不要为了测而新开付费预占或真扣费。由负责人决定是否换一条未关闭的测试会话，或在不改铁路宿主、不清数据的前提下用受控测试权益验证 `/session` 能否 200。
3. 若读到的是一条新的、本地已 confirm、按理应可开场的任务，而 `/session` 仍 503：再把重点转到服务端 `sessions.exchange`（合法会话是否被笼统打成 503），而不是继续改客户端文案。真会话 200 必须用受控合法凭据在受控环境验证，不要把用户真 token 的探测结果写出来。
4. 与本次 503 无关、但实测里已看到的问题（英文 `Connection reset` / DNS 原文铺到暂停条、「知」图标挡题干）可另记，不应当成这次授权失败的根因。
