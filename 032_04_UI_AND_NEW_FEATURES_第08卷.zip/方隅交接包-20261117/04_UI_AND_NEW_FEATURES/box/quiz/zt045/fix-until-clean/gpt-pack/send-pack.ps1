﻿# UTF-8
param(
  [switch]$Send
)
$ErrorActionPreference = 'Stop'
$outDir = 'C:\Users\rmsama\AppData\Local\Temp\zt0423-gpt-pack'
$log = Join-Path $outDir 'send-pack-log.txt'
New-Item -ItemType Directory -Force -Path $outDir | Out-Null
function Log([string]$m) {
  $line = ('{0} {1}' -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $m)
  Add-Content -Path $log -Value $line -Encoding UTF8
  Write-Output $line
}
if (Test-Path $log) { Remove-Item $log -Force }

Add-Type -AssemblyName UIAutomationClient
Add-Type -AssemblyName UIAutomationTypes
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
Add-Type -TypeDefinition @"
using System;
using System.Text;
using System.Runtime.InteropServices;
public class Win32Chat {
  public delegate bool EnumWindowsProc(IntPtr hWnd, IntPtr lParam);
  [DllImport("user32.dll")] public static extern bool EnumWindows(EnumWindowsProc lpEnumFunc, IntPtr lParam);
  [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr hWnd);
  [DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern int GetWindowText(IntPtr hWnd, StringBuilder sb, int max);
  [DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern int GetClassName(IntPtr hWnd, StringBuilder sb, int max);
  [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint pid);
  [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
  [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr hWnd);
  [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);
  [DllImport("user32.dll")] public static extern bool IsIconic(IntPtr hWnd);
  [DllImport("user32.dll")] public static extern bool BringWindowToTop(IntPtr hWnd);
  [DllImport("user32.dll")] public static extern bool AttachThreadInput(uint idAttach, uint idAttachTo, bool fAttach);
  [DllImport("kernel32.dll")] public static extern uint GetCurrentThreadId();
  [DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr hWnd, out RECT r);
  [DllImport("user32.dll")] public static extern bool SetCursorPos(int x, int y);
  [DllImport("user32.dll")] public static extern void mouse_event(uint dwFlags, uint dx, uint dy, uint dwData, UIntPtr dwExtraInfo);
  [DllImport("user32.dll")] public static extern bool PrintWindow(IntPtr hWnd, IntPtr hdcBlt, uint nFlags);
  public const uint MOUSEEVENTF_LEFTDOWN = 0x0002;
  public const uint MOUSEEVENTF_LEFTUP = 0x0004;
  public struct RECT { public int Left; public int Top; public int Right; public int Bottom; }
}
"@

function Copy-IfMissing([string]$src, [string]$dest) {
  if (Test-Path $dest) { Log ("HAVE " + $dest); return $true }
  if (Test-Path $src) { Copy-Item $src $dest -Force; Log ("COPIED " + $src + " -> " + $dest); return $true }
  Log ("MISS " + $src)
  return $false
}

$pngNames = @('06-after-tap-zhi-0.6s.png','08-after-start-plus10s.png','12-before-continue.png')
$srcRoots = @(
  'C:\Users\rmsama\AppData\Local\Temp\zt0422-gpt-pack\emu-test-0422',
  'C:\Users\rmsama\AppData\Local\Temp\zt0422-gpt-pack',
  'C:\Users\rmsama\AppData\Local\Temp\zt0423-gpt-pack'
)
foreach ($n in $pngNames) {
  $dest = Join-Path $outDir $n
  $ok = $false
  foreach ($root in $srcRoots) {
    if (Copy-IfMissing (Join-Path $root $n) $dest) { $ok = $true; break }
  }
  if (-not $ok) { Log ("PNG_MISSING " + $n) }
}
$ktDest = Join-Path $outDir 'GatewaySessionEntry.kt'
$ktSrcs = @(
  'V:\work\original-vs-0419\release-mobile\android\app\src\main\java\com\futureyyy\tijing\GatewaySessionEntry.kt',
  'C:\Users\rmsama\Documents\ChatGPT\答题小程序\每日百题APP\work\original-vs-0419\release-mobile\android\app\src\main\java\com\futureyyy\tijing\GatewaySessionEntry.kt',
  'C:\Users\rmsama\AppData\Local\Temp\zt0423-gpt-pack\GatewaySessionEntry.kt'
)
$ktOk = $false
foreach ($s in $ktSrcs) { if (Copy-IfMissing $s $ktDest) { $ktOk = $true; break } }

$brief = Join-Path $outDir '00-任务说明.md'
if (-not (Test-Path $brief)) { throw 'brief missing: 00-任务说明.md' }
Log ("BRIEF_OK len=" + (Get-Item $brief).Length)

$windows = New-Object System.Collections.Generic.List[object]
$enum = [Win32Chat+EnumWindowsProc]{
  param([IntPtr]$h,[IntPtr]$l)
  if (-not ([Win32Chat]::IsWindowVisible($h))) { return $true }
  $cls = New-Object System.Text.StringBuilder 256
  [void][Win32Chat]::GetClassName($h, $cls, 256)
  if ($cls.ToString() -ne 'Chrome_WidgetWin_1') { return $true }
  $pidOut = [uint32]0
  [void][Win32Chat]::GetWindowThreadProcessId($h, [ref]$pidOut)
  $proc = Get-Process -Id $pidOut -ErrorAction SilentlyContinue
  if ($null -eq $proc) { return $true }
  if ($proc.ProcessName -notmatch 'ChatGPT|chatgpt') { return $true }
  $sb = New-Object System.Text.StringBuilder 512
  [void][Win32Chat]::GetWindowText($h, $sb, 512)
  $r = New-Object Win32Chat+RECT
  [void][Win32Chat]::GetWindowRect($h, [ref]$r)
  $w = $r.Right - $r.Left; $hh = $r.Bottom - $r.Top
  if ($w -lt 400 -or $hh -lt 400) { return $true }
  $windows.Add([pscustomobject]@{ hwnd=$h; procId=$pidOut; title=$sb.ToString(); left=$r.Left; top=$r.Top; width=$w; height=$hh })
  return $true
}
[void][Win32Chat]::EnumWindows($enum, [IntPtr]::Zero)
$fg = [Win32Chat]::GetForegroundWindow()
$fgPid = [uint32]0
[void][Win32Chat]::GetWindowThreadProcessId($fg, [ref]$fgPid)
$fgSb = New-Object System.Text.StringBuilder 512
[void][Win32Chat]::GetWindowText($fg, $fgSb, 512)
$fgProc = Get-Process -Id $fgPid -ErrorAction SilentlyContinue
Log ("FG hwnd=" + $fg + " pid=" + $fgPid + " name=" + $fgProc.ProcessName + " title=" + $fgSb.ToString())
if ($windows.Count -eq 0) { Log 'NO_CHATGPT_WINDOW'; throw 'NO_CHATGPT_WINDOW' }
$win = $windows | Sort-Object width,height -Descending | Select-Object -First 1
foreach ($w in $windows) { Log ("WIN hwnd=" + $w.hwnd + " pid=" + $w.procId + " title=" + $w.title + " rect=" + $w.left + "," + $w.top + " " + $w.width + "x" + $w.height) }
Log ("PICK hwnd=" + $win.hwnd + " title=" + $win.title)

function Force-Foreground([IntPtr]$h) {
  if ([Win32Chat]::IsIconic($h)) { [void][Win32Chat]::ShowWindow($h, 9) } else { [void][Win32Chat]::ShowWindow($h, 5) }
  $cur = [Win32Chat]::GetForegroundWindow()
  $curPid = [uint32]0
  $curTid = [Win32Chat]::GetWindowThreadProcessId($cur, [ref]$curPid)
  $myTid = [Win32Chat]::GetCurrentThreadId()
  if ($curTid -ne 0 -and $curTid -ne $myTid) { [void][Win32Chat]::AttachThreadInput($myTid, $curTid, $true) }
  [void][Win32Chat]::BringWindowToTop($h)
  [void][Win32Chat]::SetForegroundWindow($h)
  if ($curTid -ne 0 -and $curTid -ne $myTid) { [void][Win32Chat]::AttachThreadInput($myTid, $curTid, $false) }
  Start-Sleep -Milliseconds 400
  $now = [Win32Chat]::GetForegroundWindow()
  Log ("FOREGROUND_NOW=" + $now + " ok=" + ($now -eq $h))
  return ($now -eq $h)
}

function Get-UiaEl([IntPtr]$h) {
  return [System.Windows.Automation.AutomationElement]::FromHandle($h)
}
function Walk-Named($root, $max=80) {
  $cond = New-Object System.Windows.Automation.PropertyCondition([System.Windows.Automation.AutomationElement]::IsControlElementProperty, $true)
  $all = $root.FindAll([System.Windows.Automation.TreeScope]::Descendants, $cond)
  $n = 0
  foreach ($el in $all) {
    $name = $el.Current.Name
    $ct = $el.Current.ControlType.ProgrammaticName
    if ([string]::IsNullOrWhiteSpace($name) -and $ct -notmatch 'Edit|Document|Button|Tab') { continue }
    $r = $el.Current.BoundingRectangle
    if ($r.Width -le 0 -or $r.Height -le 0) { continue }
    if ($name -match '聊天|工作|发送|Send|停止|新聊天|New chat|Ask|提问' -or $ct -match 'Edit|Document|Button|TabItem|Tab') {
      Log ("UIA " + $ct + " name=[" + $name + "] rect=" + [int]$r.X + "," + [int]$r.Y + " " + [int]$r.Width + "x" + [int]$r.Height + " enabled=" + $el.Current.IsEnabled)
      $n++
      if ($n -ge $max) { break }
    }
  }
}

function Find-Composer($root) {
  $editCt = [System.Windows.Automation.ControlType]::Edit
  $docCt = [System.Windows.Automation.ControlType]::Document
  $c1 = New-Object System.Windows.Automation.PropertyCondition([System.Windows.Automation.AutomationElement]::ControlTypeProperty, $editCt)
  $c2 = New-Object System.Windows.Automation.PropertyCondition([System.Windows.Automation.AutomationElement]::ControlTypeProperty, $docCt)
  $cond = New-Object System.Windows.Automation.OrCondition($c1, $c2)
  $all = $root.FindAll([System.Windows.Automation.TreeScope]::Descendants, $cond)
  $best = $null
  $bestScore = -1
  foreach ($el in $all) {
    $r = $el.Current.BoundingRectangle
    if ($r.Width -lt 120 -or $r.Height -lt 20) { continue }
    if (-not $el.Current.IsEnabled) { continue }
    # prefer lower, wider input
    $score = ($r.Y * 10) + $r.Width + ($r.Height * 2)
    if ($score -gt $bestScore) { $bestScore = $score; $best = $el }
  }
  return $best
}

function Find-ChatTab($root) {
  $cond = New-Object System.Windows.Automation.PropertyCondition([System.Windows.Automation.AutomationElement]::ControlTypeProperty, [System.Windows.Automation.ControlType]::TabItem)
  $all = $root.FindAll([System.Windows.Automation.TreeScope]::Descendants, $cond)
  foreach ($el in $all) {
    if ($el.Current.Name -eq '聊天') { return $el }
  }
  $cond2 = New-Object System.Windows.Automation.PropertyCondition([System.Windows.Automation.AutomationElement]::NameProperty, '聊天')
  return $root.FindFirst([System.Windows.Automation.TreeScope]::Descendants, $cond2)
}

function Invoke-El($el) {
  try {
    $p = $el.GetCurrentPattern([System.Windows.Automation.InvokePattern]::Pattern)
    $p.Invoke()
    return $true
  } catch {
    $r = $el.Current.BoundingRectangle
    if ($r.Width -le 0) { return $false }
    $x = [int]($r.X + $r.Width/2)
    $y = [int]($r.Y + $r.Height/2)
    [void][Win32Chat]::SetCursorPos($x, $y)
    Start-Sleep -Milliseconds 80
    [Win32Chat]::mouse_event([Win32Chat]::MOUSEEVENTF_LEFTDOWN, 0, 0, 0, [UIntPtr]::Zero)
    [Win32Chat]::mouse_event([Win32Chat]::MOUSEEVENTF_LEFTUP, 0, 0, 0, [UIntPtr]::Zero)
    return $true
  }
}

function Find-Send($root, $composer) {
  $cr = $composer.Current.BoundingRectangle
  $cond = New-Object System.Windows.Automation.PropertyCondition([System.Windows.Automation.AutomationElement]::ControlTypeProperty, [System.Windows.Automation.ControlType]::Button)
  $all = $root.FindAll([System.Windows.Automation.TreeScope]::Descendants, $cond)
  $cands = @()
  foreach ($el in $all) {
    $name = [string]$el.Current.Name
    $r = $el.Current.BoundingRectangle
    if ($r.Width -le 0 -or $r.Height -le 0) { continue }
    $near = ($r.Y + $r.Height -ge $cr.Y - 40) -and ($r.Y -le $cr.Y + $cr.Height + 40) -and ($r.X + $r.Width -ge $cr.X)
    $named = ($name -match '发送|Send message|Send')
    if ($named -or $near) {
      $cands += ,[pscustomobject]@{ el=$el; name=$name; x=$r.X; y=$r.Y; w=$r.Width; h=$r.Height; enabled=$el.Current.IsEnabled; named=$named; dist=[math]::Abs(($r.X+$r.Width/2)-($cr.X+$cr.Width)) + [math]::Abs(($r.Y+$r.Height/2)-($cr.Y+$cr.Height/2)) }
    }
  }
  foreach ($c in ($cands | Sort-Object @{Expression='named';Descending=$true}, @{Expression='dist'})) {
    Log ("SENDCAND name=[" + $c.name + "] rect=" + [int]$c.x + "," + [int]$c.y + " " + [int]$c.w + "x" + [int]$c.h + " enabled=" + $c.enabled + " named=" + $c.named + " dist=" + [int]$c.dist)
  }
  $pick = $cands | Where-Object { $_.enabled -and $_.named } | Sort-Object dist | Select-Object -First 1
  if (-not $pick) {
    $pick = $cands | Where-Object { $_.enabled -and ($_.name -notmatch 'Pro|语音|麦克风|添加|附件|Attach|模式|麦克风') -and $_.w -ge 24 -and $_.w -le 90 -and $_.h -ge 24 -and $_.h -le 90 } | Sort-Object x -Descending | Select-Object -First 1
  }
  if ($pick) { return $pick.el }
  return $null
}

function Get-Value($el) {
  try {
    $vp = $el.GetCurrentPattern([System.Windows.Automation.ValuePattern]::Pattern)
    return [string]$vp.Current.Value
  } catch { return '' }
}

function Save-WindowShot([IntPtr]$h, [string]$path) {
  $r = New-Object Win32Chat+RECT
  [void][Win32Chat]::GetWindowRect($h, [ref]$r)
  $w = $r.Right - $r.Left; $hh = $r.Bottom - $r.Top
  if ($w -le 0 -or $hh -le 0) { return }
  $bmp = New-Object System.Drawing.Bitmap $w, $hh
  $g = [System.Drawing.Graphics]::FromImage($bmp)
  $hdc = $g.GetHdc()
  [void][Win32Chat]::PrintWindow($h, $hdc, 2)
  $g.ReleaseHdc($hdc)
  $g.Dispose()
  $bmp.Save($path, [System.Drawing.Imaging.ImageFormat]::Png)
  $bmp.Dispose()
  Log ("SHOT " + $path)
}

if (-not $Send) {
  $null = Force-Foreground ([IntPtr]$win.hwnd)
  $root = Get-UiaEl ([IntPtr]$win.hwnd)
  Walk-Named $root
  $tab = Find-ChatTab $root
  if ($tab) { Log ("CHAT_TAB name=" + $tab.Current.Name) }
  $comp = Find-Composer $root
  if ($comp) {
    $r = $comp.Current.BoundingRectangle
    Log ("COMPOSER name=[" + $comp.Current.Name + "] rect=" + [int]$r.X + "," + [int]$r.Y + " " + [int]$r.Width + "x" + [int]$r.Height + " valueLen=" + (Get-Value $comp).Length)
  } else { Log 'NO_COMPOSER' }
  Save-WindowShot ([IntPtr]$win.hwnd) (Join-Path $outDir 'chatgpt-inspect.png')
  Log 'INSPECT_DONE'
  exit 0
}

# ---- SEND ----
$fgOk = Force-Foreground ([IntPtr]$win.hwnd)
Start-Sleep -Milliseconds 300
$fgNow = [Win32Chat]::GetForegroundWindow()
if ((-not $fgOk) -or ($fgNow -ne [IntPtr]$win.hwnd)) {
  Log 'ABORT_NOT_FOREGROUND'
  throw 'ABORT_NOT_FOREGROUND'
}
$root = Get-UiaEl ([IntPtr]$win.hwnd)
$tab = Find-ChatTab $root
if ($tab) {
  Log ("CLICK_CHAT_TAB name=" + $tab.Current.Name)
  [void](Invoke-El $tab)
  Start-Sleep -Milliseconds 400
  $root = Get-UiaEl ([IntPtr]$win.hwnd)
}
$comp = Find-Composer $root
if (-not $comp) { throw 'NO_COMPOSER' }
$existing = Get-Value $comp
Log ("COMPOSER_EXISTING_LEN=" + $existing.Length)
if ($existing.Length -gt 20 -and $existing -notmatch '0\.4\.22|授权暂未确认|知题') {
  Log 'COMPOSER_HAS_FOREIGN_TEXT'
  throw 'COMPOSER_HAS_FOREIGN_TEXT'
}

$briefText = [System.IO.File]::ReadAllText($brief, [System.Text.Encoding]::UTF8)
if ($briefText.StartsWith([char]0xFEFF)) { $briefText = $briefText.Substring(1) }
$attachNote = "`r`n`r`n以下三张实测截图会随本消息一起附上：06 点开知图标后的开始键、08 开始后授权未确认、12 英文报错。源码 GatewaySessionEntry.kt 也在本机目录 C:\Users\rmsama\AppData\Local\Temp\zt0423-gpt-pack\ 里，如能读取请一并参考。"
$briefText = $briefText + $attachNote
[System.Windows.Forms.Clipboard]::SetText($briefText)
[void](Invoke-El $comp)
Start-Sleep -Milliseconds 200
$comp.SetFocus()
Start-Sleep -Milliseconds 150
[System.Windows.Forms.SendKeys]::SendWait('^a')
Start-Sleep -Milliseconds 80
[System.Windows.Forms.SendKeys]::SendWait('^v')
Start-Sleep -Milliseconds 800
$after = Get-Value (Find-Composer $root)
Log ("PASTED_VALUE_LEN=" + $after.Length)

# paste images
foreach ($n in $pngNames) {
  $imgPath = Join-Path $outDir $n
  if (-not (Test-Path $imgPath)) { Log ("SKIP_IMG " + $n); continue }
  $img = [System.Drawing.Image]::FromFile($imgPath)
  [System.Windows.Forms.Clipboard]::SetImage($img)
  $img.Dispose()
  Start-Sleep -Milliseconds 150
  $comp2 = Find-Composer $root
  if ($comp2) { $comp2.SetFocus() }
  [System.Windows.Forms.SendKeys]::SendWait('^v')
  Start-Sleep -Milliseconds 700
  Log ("PASTED_IMG " + $n)
}

Start-Sleep -Milliseconds 500
$root = Get-UiaEl ([IntPtr]$win.hwnd)
$comp = Find-Composer $root
$sendBtn = Find-Send $root $comp
if ($sendBtn) {
  Log ("CLICK_SEND name=[" + $sendBtn.Current.Name + "] enabled=" + $sendBtn.Current.IsEnabled)
  if ($sendBtn.Current.IsEnabled) {
    [void](Invoke-El $sendBtn)
  } else {
    Log 'SEND_DISABLED_TRY_ENTER'
    $comp.SetFocus()
    [System.Windows.Forms.SendKeys]::SendWait('{ENTER}')
  }
} else {
  Log 'NO_SEND_BTN_TRY_ENTER'
  $comp.SetFocus()
  [System.Windows.Forms.SendKeys]::SendWait('{ENTER}')
}
Start-Sleep -Milliseconds 1800
Save-WindowShot ([IntPtr]$win.hwnd) (Join-Path $outDir 'chatgpt-after-send.png')
$root = Get-UiaEl ([IntPtr]$win.hwnd)
$comp = Find-Composer $root
$afterSend = Get-Value $comp
Log ("AFTER_SEND_COMPOSER_LEN=" + $afterSend.Length)
Walk-Named $root 40
if ($afterSend.Length -gt 200) { Log 'SEND_MAYBE_FAILED_COMPOSER_STILL_FULL' } else { Log 'SEND_APPEARS_OK' }
Log 'SEND_DONE'
