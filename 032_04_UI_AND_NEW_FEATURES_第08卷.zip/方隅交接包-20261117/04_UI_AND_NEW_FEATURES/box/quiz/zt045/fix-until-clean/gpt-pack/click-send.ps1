﻿# UTF-8
$ErrorActionPreference = 'Stop'
$outDir = 'C:\Users\rmsama\AppData\Local\Temp\zt0423-gpt-pack'
$log = Join-Path $outDir 'click-send-log.txt'
if (Test-Path $log) { Remove-Item $log -Force }
function Log([string]$m) {
  $line = ('{0} {1}' -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $m)
  Add-Content -Path $log -Value $line -Encoding UTF8
  Write-Output $line
}
Add-Type -AssemblyName UIAutomationClient
Add-Type -AssemblyName UIAutomationTypes
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
Add-Type -TypeDefinition @"
using System;
using System.Text;
using System.Runtime.InteropServices;
public class Win32Send {
  [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
  [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr hWnd);
  [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);
  [DllImport("user32.dll")] public static extern bool IsIconic(IntPtr hWnd);
  [DllImport("user32.dll")] public static extern bool BringWindowToTop(IntPtr hWnd);
  [DllImport("user32.dll")] public static extern bool AttachThreadInput(uint idAttach, uint idAttachTo, bool fAttach);
  [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint pid);
  [DllImport("kernel32.dll")] public static extern uint GetCurrentThreadId();
  [DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr hWnd, out RECT r);
  [DllImport("user32.dll")] public static extern bool SetCursorPos(int x, int y);
  [DllImport("user32.dll")] public static extern void mouse_event(uint dwFlags, uint dx, uint dy, uint dwData, UIntPtr dwExtraInfo);
  [DllImport("user32.dll")] public static extern bool PrintWindow(IntPtr hWnd, IntPtr hdcBlt, uint nFlags);
  [DllImport("user32.dll")] public static extern bool EnumWindows(EnumWindowsProc lpEnumFunc, IntPtr lParam);
  [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr hWnd);
  [DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern int GetWindowText(IntPtr hWnd, StringBuilder sb, int max);
  [DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern int GetClassName(IntPtr hWnd, StringBuilder sb, int max);
  public delegate bool EnumWindowsProc(IntPtr hWnd, IntPtr lParam);
  public const uint MOUSEEVENTF_LEFTDOWN = 0x0002;
  public const uint MOUSEEVENTF_LEFTUP = 0x0004;
  public struct RECT { public int Left; public int Top; public int Right; public int Bottom; }
}
"@

$hwnd = [IntPtr]::Zero
$enum = [Win32Send+EnumWindowsProc]{
  param([IntPtr]$h,[IntPtr]$l)
  if (-not ([Win32Send]::IsWindowVisible($h))) { return $true }
  $cls = New-Object System.Text.StringBuilder 256
  [void][Win32Send]::GetClassName($h, $cls, 256)
  if ($cls.ToString() -ne 'Chrome_WidgetWin_1') { return $true }
  $pidOut = [uint32]0
  [void][Win32Send]::GetWindowThreadProcessId($h, [ref]$pidOut)
  $proc = Get-Process -Id $pidOut -ErrorAction SilentlyContinue
  if ($null -eq $proc -or $proc.ProcessName -notmatch 'ChatGPT|chatgpt') { return $true }
  $r = New-Object Win32Send+RECT
  [void][Win32Send]::GetWindowRect($h, [ref]$r)
  if (($r.Right-$r.Left) -lt 400 -or ($r.Bottom-$r.Top) -lt 400) { return $true }
  $script:hwnd = $h
  return $false
}
[void][Win32Send]::EnumWindows($enum, [IntPtr]::Zero)
if ($hwnd -eq [IntPtr]::Zero) { throw 'NO_CHATGPT_WINDOW' }
Log ("HWND=" + $hwnd)

function Force-Foreground([IntPtr]$h) {
  if ([Win32Send]::IsIconic($h)) { [void][Win32Send]::ShowWindow($h, 9) } else { [void][Win32Send]::ShowWindow($h, 5) }
  $cur = [Win32Send]::GetForegroundWindow()
  $curPid = [uint32]0
  $curTid = [Win32Send]::GetWindowThreadProcessId($cur, [ref]$curPid)
  $myTid = [Win32Send]::GetCurrentThreadId()
  if ($curTid -ne 0 -and $curTid -ne $myTid) { [void][Win32Send]::AttachThreadInput($myTid, $curTid, $true) }
  [void][Win32Send]::BringWindowToTop($h)
  [void][Win32Send]::SetForegroundWindow($h)
  if ($curTid -ne 0 -and $curTid -ne $myTid) { [void][Win32Send]::AttachThreadInput($myTid, $curTid, $false) }
  Start-Sleep -Milliseconds 300
  return ([Win32Send]::GetForegroundWindow() -eq $h)
}
function Save-Shot([IntPtr]$h, [string]$path) {
  $r = New-Object Win32Send+RECT
  [void][Win32Send]::GetWindowRect($h, [ref]$r)
  $w = $r.Right - $r.Left; $hh = $r.Bottom - $r.Top
  if ($w -le 200) { $w = 1280; $hh = 1050 }
  # Prefer UIA document size if GetWindowRect is logical
  $bmp = New-Object System.Drawing.Bitmap ([int]$w), ([int]$hh)
  $g = [System.Drawing.Graphics]::FromImage($bmp)
  $hdc = $g.GetHdc()
  [void][Win32Send]::PrintWindow($h, $hdc, 2)
  $g.ReleaseHdc($hdc)
  $g.Dispose()
  $bmp.Save($path, [System.Drawing.Imaging.ImageFormat]::Png)
  $bmp.Dispose()
  Log ("SHOT " + $path + " " + $w + "x" + $hh)
}
function Click-At([int]$x, [int]$y) {
  Log ("CLICK " + $x + "," + $y)
  [void][Win32Send]::SetCursorPos($x, $y)
  Start-Sleep -Milliseconds 120
  [Win32Send]::mouse_event([Win32Send]::MOUSEEVENTF_LEFTDOWN, 0, 0, 0, [UIntPtr]::Zero)
  Start-Sleep -Milliseconds 40
  [Win32Send]::mouse_event([Win32Send]::MOUSEEVENTF_LEFTUP, 0, 0, 0, [UIntPtr]::Zero)
}

if (-not (Force-Foreground $hwnd)) { throw 'ABORT_NOT_FOREGROUND' }
# Wait for image upload spinners to finish
Start-Sleep -Milliseconds 2500
$root = [System.Windows.Automation.AutomationElement]::FromHandle($hwnd)
$cond = New-Object System.Windows.Automation.PropertyCondition([System.Windows.Automation.AutomationElement]::ControlTypeProperty, [System.Windows.Automation.ControlType]::Button)
$all = $root.FindAll([System.Windows.Automation.TreeScope]::Descendants, $cond)
$send = $null
foreach ($el in $all) {
  $name = [string]$el.Current.Name
  $r = $el.Current.BoundingRectangle
  Log ("BTN name=[" + $name + "] rect=" + [int]$r.X + "," + [int]$r.Y + " " + [int]$r.Width + "x" + [int]$r.Height + " enabled=" + $el.Current.IsEnabled)
  # The visible send arrow sits at the far right of the composer row, same Y as 听写 / 选择模型
  if ($name -eq '发送' -or $name -eq '发送消息' -or $name -eq 'Send message') { $send = $el }
}
# If no properly named send, pick the button immediately right of 听写
$dict = $null
$model = $null
$right = $null
foreach ($el in $all) {
  $name = [string]$el.Current.Name
  $r = $el.Current.BoundingRectangle
  if ($r.Width -le 0) { continue }
  if ($name -eq '听写') { $dict = $el }
  if ($name -match '选择 ChatGPT 模型') { $model = $el }
}
$anchor = $dict
if (-not $anchor) { $anchor = $model }
if ($anchor) {
  $ar = $anchor.Current.BoundingRectangle
  $bestX = 99999
  foreach ($el in $all) {
    $name = [string]$el.Current.Name
    $r = $el.Current.BoundingRectangle
    if (-not $el.Current.IsEnabled) { continue }
    if ($r.Width -lt 24 -or $r.Width -gt 90 -or $r.Height -lt 24 -or $r.Height -gt 90) { continue }
    if ([math]::Abs(($r.Y + $r.Height/2) - ($ar.Y + $ar.Height/2)) -gt 20) { continue }
    if ($r.X -le ($ar.X + 10)) { continue }
    if ($name -match '听写|语音|麦克风|停止|Pro|模型|添加') { continue }
    if ($r.X -lt $bestX) { $bestX = $r.X; $right = $el }
  }
  # If the only button to the right is named 停止 but visually is the send arrow, still use the rightmost small button on this row except 听写
  if (-not $right) {
    $bestX = -1
    foreach ($el in $all) {
      $name = [string]$el.Current.Name
      $r = $el.Current.BoundingRectangle
      if (-not $el.Current.IsEnabled) { continue }
      if ($r.Width -lt 24 -or $r.Width -gt 90 -or $r.Height -lt 24 -or $r.Height -gt 90) { continue }
      if ([math]::Abs(($r.Y + $r.Height/2) - ($ar.Y + $ar.Height/2)) -gt 20) { continue }
      if ($name -eq '听写') { continue }
      if ($r.X -gt $ar.X -and $r.X -gt $bestX) { $bestX = $r.X; $right = $el }
    }
  }
}
if ($send) { $target = $send } else { $target = $right }
if (-not $target) { throw 'NO_SEND_TARGET' }
$tr = $target.Current.BoundingRectangle
Log ("TARGET name=[" + $target.Current.Name + "] rect=" + [int]$tr.X + "," + [int]$tr.Y + " " + [int]$tr.Width + "x" + [int]$tr.Height)
$cx = [int]($tr.X + $tr.Width/2)
$cy = [int]($tr.Y + $tr.Height/2)
Click-At $cx $cy
Start-Sleep -Milliseconds 2000
Save-Shot $hwnd (Join-Path $outDir 'chatgpt-after-clicksend.png')
# If composer still obviously full, try Enter
$editCt = [System.Windows.Automation.ControlType]::Edit
$c1 = New-Object System.Windows.Automation.PropertyCondition([System.Windows.Automation.AutomationElement]::ControlTypeProperty, $editCt)
$comp = $root.FindFirst([System.Windows.Automation.TreeScope]::Descendants, (New-Object System.Windows.Automation.PropertyCondition([System.Windows.Automation.AutomationElement]::NameProperty, '询问 ChatGPT')))
if ($comp) {
  $vr = $comp.Current.BoundingRectangle
  Log ("COMPOSER_STILL name=[" + $comp.Current.Name + "] rect=" + [int]$vr.X + "," + [int]$vr.Y + " " + [int]$vr.Width + "x" + [int]$vr.Height)
}
Log 'CLICK_DONE'
