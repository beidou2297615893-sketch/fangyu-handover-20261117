Write-Host ("V_exists=" + (Test-Path -LiteralPath "V:/work/tools/jdk"))
function Present([string]$n) {
    -not [string]::IsNullOrWhiteSpace([Environment]::GetEnvironmentVariable($n, "User"))
}
Write-Host ("store_file_user_set=" + (Present "DAILYHUNDRED_STORE_FILE"))
Write-Host ("store_pw_user_set=" + (Present "DAILYHUNDRED_STORE_PASSWORD"))
Write-Host ("key_alias_user_set=" + (Present "DAILYHUNDRED_KEY_ALIAS"))
Write-Host ("key_pw_user_set=" + (Present "DAILYHUNDRED_KEY_PASSWORD"))
