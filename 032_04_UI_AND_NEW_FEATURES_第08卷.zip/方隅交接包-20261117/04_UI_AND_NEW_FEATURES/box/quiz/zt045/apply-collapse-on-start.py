import sys
from pathlib import Path
sys.stdout.reconfigure(encoding="utf-8", errors="replace")

ov = Path(r"V:\work\tijing-bankassist\android\app\src\main\java\com\futureyyy\tijing\OverlayController.kt")
scs = Path(r"V:\work\tijing-bankassist\android\app\src\main\java\com\futureyyy\tijing\ScreenCaptureService.kt")
text = ov.read_text(encoding="utf-8")

old_start = '        val start = hotspot("开始答题") { runCatching { callbacks.onPrimaryAction() } }'
new_start = '''        val start = hotspot("开始答题") {
            collapseKnowledgePanel()
            runCatching { callbacks.onPrimaryAction() }
        }'''
if old_start not in text:
    raise SystemExit("start hotspot pattern not found")
text = text.replace(old_start, new_start, 1)

needle = "    private fun expandKnowledgePanel() {"
insert = """    fun collapseToBubble() = onMain {
        collapseKnowledgePanel()
    }

"""
if "fun collapseToBubble(" in text:
    print("collapseToBubble already present")
else:
    if needle not in text:
        raise SystemExit("expandKnowledgePanel not found")
    text = text.replace(needle, insert + needle, 1)

ov.write_text(text, encoding="utf-8")
print("OverlayController patched")

st = scs.read_text(encoding="utf-8")
old = """            override fun onPrimaryAction() {
                if (runtimeConfig?.mode == QuizMode.CAPTURE) {
                    startSweep(generation)
                } else {
                    startAuthorizedRunner(generation)
                }
            }"""
new = """            override fun onPrimaryAction() {
                overlayController?.collapseToBubble()
                if (runtimeConfig?.mode == QuizMode.CAPTURE) {
                    startSweep(generation)
                } else {
                    startAuthorizedRunner(generation)
                }
            }"""
if old not in st:
    raise SystemExit("onPrimaryAction block not found")
st = st.replace(old, new, 1)
old2 = """            gatewayRunnerStarted = true
            withRunner(generation) { it.onPrimaryAction() }
            return"""
new2 = """            gatewayRunnerStarted = true
            overlayController?.collapseToBubble()
            withRunner(generation) { it.onPrimaryAction() }
            return"""
if old2 not in st:
    raise SystemExit("existing-session start path not found")
st = st.replace(old2, new2, 1)
old3 = """                gatewayRunnerStarted = true
                withRunner(generation) { it.onPrimaryAction() }"""
new3 = """                gatewayRunnerStarted = true
                overlayController?.collapseToBubble()
                withRunner(generation) { it.onPrimaryAction() }"""
if old3 not in st:
    raise SystemExit("fresh-session start path not found")
st = st.replace(old3, new3, 1)
scs.write_text(st, encoding="utf-8")
print("ScreenCaptureService patched")
print("collapseToBubble", "fun collapseToBubble(" in ov.read_text(encoding="utf-8"))
print("service collapse count", st.count("collapseToBubble()"))
