from pathlib import Path

p = Path(r"C:\Users\rmsama\Documents\ChatGPT\答题小程序\每日百题APP\work\tijing-bankassist\android\app\src\main\java\com\futureyyy\tijing\ScreenCaptureService.kt")
t = p.read_text(encoding="utf-8")
needle = "        return { ai -> store.index.answerForVision(ai).also { Log.i("
idx = t.find(needle)
if idx < 0:
    raise SystemExit("hook site not found")
line_end = t.find("\n", idx)
new = """        return { ai ->
            val bank = store.index.answerForVision(ai)
            val resolved = bank ?: LocalArithmeticAssist.answerForVision(ai)
            Log.i("ZhitiBank", "no=${ai.questionNo} hit=${resolved != null} source=${resolved?.answerSource} ai=${ai.answerIndices} final=${resolved?.answerIndices}")
            resolved ?: ai
        }"""
p.write_text(t[:idx] + new + t[line_end:], encoding="utf-8")
print("hooked")

g = Path(r"C:\Users\rmsama\Documents\ChatGPT\答题小程序\每日百题APP\work\tijing-bankassist\android\app\build.gradle.kts")
gt = g.read_text(encoding="utf-8")
gt2 = gt.replace("versionCode = 71", "versionCode = 72").replace('versionName = "0.4.4"', 'versionName = "0.4.5"')
if gt == gt2:
    raise SystemExit("version not bumped")
g.write_text(gt2, encoding="utf-8")
print("bumped")
