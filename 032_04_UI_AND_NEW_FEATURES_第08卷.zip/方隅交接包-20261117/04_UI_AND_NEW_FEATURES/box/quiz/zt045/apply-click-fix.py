import sys, shutil
from pathlib import Path
from datetime import datetime
sys.stdout.reconfigure(encoding="utf-8", errors="replace")

stamp = datetime.now().strftime("%H%M%S")
backup_dir = Path(r"C:\Users\rmsama\AppData\Local\Temp\paydb-inspect") / f"patch-bak-{stamp}"
backup_dir.mkdir(parents=True, exist_ok=True)

def patch(path: Path, replacements):
    original = path.read_text(encoding="utf-8")
    shutil.copy2(path, backup_dir / path.name)
    text = original
    for i, (old, new) in enumerate(replacements, 1):
        count = text.count(old)
        if count != 1:
            print(f"FAIL {path.name} repl {i}: count={count}")
            print("---OLD START---")
            print(old[:800])
            print("---OLD END---")
            raise SystemExit(2)
        text = text.replace(old, new)
        print(f"OK {path.name} repl {i} ({len(old)} -> {len(new)} chars)")
    path.write_text(text, encoding="utf-8")
    print("WROTE", path, "delta", len(text) - len(original))

root = Path(r"V:\work\tijing-bankassist\android\app\src\main\java\com\futureyyy\tijing")

acc = root / "QuizAccessibilityService.kt"
old_filter = """                val label = nodeLabel(node)
                val confirmLabel = forConfirm && label.length <= 6 && CONFIRM_TEXT_CANDIDATES.any(label::startsWith)
                if (!node.isVisibleToUser || !(node.isClickable || confirmLabel) || !node.isEnabled) continue"""
new_filter = """                val label = nodeLabel(node)
                val confirmLabel = forConfirm && label.length <= 6 && CONFIRM_TEXT_CANDIDATES.any(label::startsWith)
                // Many quiz pages (including WebView hosts) expose option and confirm
                // text but do not mark the row clickable. Still snap to that visible
                // node so the gesture lands on the answer row.
                val selectable = node.isClickable || confirmLabel || !forConfirm
                if (!node.isVisibleToUser || !selectable || !node.isEnabled) continue"""
old_tap = """        val snapped = try {
            nearestClickableCenter(px, py, targetPackage, metrics.widthPixels, metrics.heightPixels, forConfirm = false)
        } catch (_: Exception) {
            null
        }
        debugGesture("option-near raw=$px,$py snapped=${snapped?.first},${snapped?.second}")
        return enqueueTap(snapped?.first ?: px, snapped?.second ?: py, targetPackage, finish)"""
new_tap = """        val snapped = try {
            nearestClickableCenter(px, py, targetPackage, metrics.widthPixels, metrics.heightPixels, forConfirm = false)
        } catch (_: Exception) {
            null
        }
        debugGesture("option-near raw=$px,$py snapped=${snapped?.first},${snapped?.second}")
        Log.i("ZhitiTap", "option raw=$px,$py snapped=${snapped?.first},${snapped?.second}")
        return enqueueTap(snapped?.first ?: px, snapped?.second ?: py, targetPackage, finish)"""
patch(acc, [(old_filter, new_filter), (old_tap, new_tap)])

ov = root / "OverlayController.kt"
old_bind = """        try {
            windowManager.updateViewLayout(panel, params)
        } catch (_: Exception) {
            // The service may be tearing the overlay down at the same time.
        }"""
new_bind = """        if (hiddenForCapture) return
        try {
            windowManager.updateViewLayout(panel, params)
        } catch (_: Exception) {
            // The service may be tearing the overlay down at the same time.
        }"""
patch(ov, [(old_bind, new_bind)])

coord = root / "QuizRunCoordinator.kt"
old_fields = """    private var confirmTapAttempts = 0
    private var stableCandidate: FrameSignature? = null"""
new_fields = """    private var confirmTapAttempts = 0
    private var unchangedPageRetries = 0
    private var stableCandidate: FrameSignature? = null"""
old_retry = """    private fun retryConfirmAfterUnchangedPage(runGeneration: Long): Boolean {
        if (mode != QuizMode.AUTO) return false
        val plan = pendingActionPlan ?: return false

        // The accessibility callback confirms that Android dispatched the gesture, not that
        // the target accepted it. Keep the selected answers and retry only the confirmation.
        confirmTapCompleted = false
        autoCheckpointStage = AutoCheckpointStage.CONFIRM
        stableCandidate = null
        pollAttempts = 0
        if (confirmTapAttempts >= MAX_CONFIRM_TAP_ATTEMPTS) return false
        transition(RunnerPhase.EXECUTING)
        if (!isCurrent(runGeneration, RunnerPhase.EXECUTING)) return true
        retryConfirm(runGeneration, plan)
        return true
    }"""
new_retry = """    private fun retryConfirmAfterUnchangedPage(runGeneration: Long): Boolean {
        if (mode != QuizMode.AUTO) return false
        val plan = pendingActionPlan ?: return false

        // dispatchGesture completing only means the stroke was delivered, not that a
        // WebView option row (often not marked clickable) actually became selected.
        // Re-tap the answers, then confirm again, instead of poking a disabled button.
        if (unchangedPageRetries >= MAX_UNCHANGED_PAGE_RETRIES) return false
        unchangedPageRetries += 1
        nextAnswerPosition = 0
        confirmTapCompleted = false
        confirmTapAttempts = 0
        autoCheckpointStage = AutoCheckpointStage.ANSWERS
        stableCandidate = null
        pollAttempts = 0
        transition(RunnerPhase.EXECUTING)
        if (!isCurrent(runGeneration, RunnerPhase.EXECUTING)) return true
        retryAnswers(runGeneration, plan)
        return true
    }

    private fun retryAnswers(runGeneration: Long, plan: QuizActionPlan) {
        if (!isCurrent(runGeneration, RunnerPhase.EXECUTING)) return
        val task = try {
            scheduler.schedule(CONFIRM_RETRY_DELAY_MS) {
                executeAnswer(runGeneration, plan)
            }
        } catch (error: Exception) {
            fail(runGeneration, errorMessage(error, "答案重试调度失败"))
            return
        }
        if (isCurrent(runGeneration, RunnerPhase.EXECUTING)) {
            scheduledTasks += task
        } else {
            task.cancel()
        }
    }"""
old_replace = """        nextAnswerPosition = 0
        confirmTapCompleted = false
        confirmTapAttempts = 0
    }

    private fun clearAutoCheckpoint() {
        pendingActionPlan = null
        autoCheckpointStage = null
        nextAnswerPosition = 0
        confirmTapCompleted = false
        confirmTapAttempts = 0
    }"""
new_replace = """        nextAnswerPosition = 0
        confirmTapCompleted = false
        confirmTapAttempts = 0
        unchangedPageRetries = 0
    }

    private fun clearAutoCheckpoint() {
        pendingActionPlan = null
        autoCheckpointStage = null
        nextAnswerPosition = 0
        confirmTapCompleted = false
        confirmTapAttempts = 0
        unchangedPageRetries = 0
    }"""
old_resume_auto = """            AutoCheckpointStage.ANSWERS,
            AutoCheckpointStage.CONFIRM_BASELINE,
            AutoCheckpointStage.CONFIRM,
            -> {
                transition(RunnerPhase.EXECUTING)
                if (isCurrent(runGeneration, RunnerPhase.EXECUTING)) {
                    resumePendingActions(runGeneration)
                }
            }

            AutoCheckpointStage.PAGE_POLL -> restartPagePolling(runGeneration)"""
new_resume_auto = """            AutoCheckpointStage.ANSWERS,
            AutoCheckpointStage.CONFIRM_BASELINE,
            AutoCheckpointStage.CONFIRM,
            AutoCheckpointStage.PAGE_POLL,
            -> {
                if (autoCheckpointStage == AutoCheckpointStage.PAGE_POLL) {
                    nextAnswerPosition = 0
                    confirmTapCompleted = false
                    confirmTapAttempts = 0
                    unchangedPageRetries = 0
                    autoCheckpointStage = AutoCheckpointStage.ANSWERS
                }
                transition(RunnerPhase.EXECUTING)
                if (isCurrent(runGeneration, RunnerPhase.EXECUTING)) {
                    resumePendingActions(runGeneration)
                }
            }"""
old_resume_pending = """            AutoCheckpointStage.PAGE_POLL -> restartPagePolling(runGeneration)
            null -> fail(runGeneration, "缺少执行检查点")"""
new_resume_pending = """            AutoCheckpointStage.PAGE_POLL -> {
                nextAnswerPosition = 0
                confirmTapCompleted = false
                confirmTapAttempts = 0
                autoCheckpointStage = AutoCheckpointStage.ANSWERS
                executeAnswer(runGeneration, plan)
            }
            null -> fail(runGeneration, "缺少执行检查点")"""
old_const = """        const val MAX_CONFIRM_TAP_ATTEMPTS = 3"""
new_const = """        const val MAX_CONFIRM_TAP_ATTEMPTS = 3
        const val MAX_UNCHANGED_PAGE_RETRIES = 2"""

patch(coord, [
    (old_fields, new_fields),
    (old_retry, new_retry),
    (old_replace, new_replace),
    (old_resume_auto, new_resume_auto),
    (old_resume_pending, new_resume_pending),
    (old_const, new_const),
])
print("BACKUP", backup_dir)
