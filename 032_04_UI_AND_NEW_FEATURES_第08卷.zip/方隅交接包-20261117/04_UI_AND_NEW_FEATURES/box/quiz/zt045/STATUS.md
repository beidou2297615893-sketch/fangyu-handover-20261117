# 随机百题 0.4.4 / 答题服务 修复状态

时间：2026-11-12 17:37 Asia/Shanghai  
范围：只在云电脑打包、只在云端模拟器实测，未再操作用户电脑，未拷签名库。

## 结论先看

1. **「答题服务暂不可用」根因已在云端入口修好，线上 0.4.3 不用换包也能吃到这修。**  
   入口函数 `dailyHundredImportV1Ingress` 以前把 body 设成 `isBase64Encoded:true`，会话接口会直接 503。现已改为 UTF-8 原文、`isBase64Encoded:false`。413 大包问题此前已切走，复测仍无 413。
2. **云端已打出 0.4.4 / versionCode 71 的可安装包，并已装上 emulator-5556。**  
   图标已在模拟器上亲眼确认（启动页 + 系统 App info 都是用户给的棕色金字「知」+书本）。
3. **悬浮窗「先展开再开始」的代码和资源已打进这个包，但这次在云端模拟器上没能点测完成。**  
   悬浮窗要等录屏服务/MediaProjection 在 WebView 流程里拉起。应用进主界面后 WebView 长时间白屏，此前还发生过两次 WebView 相关 native SIGTRAP 闪退。这台模拟器是 `-accel off` + swiftshader，guest 负载经常到 17–32，SystemUI 也 ANR 过。不能把这次点测算作通过。
4. **这个包是 ProdDebug、调试签名，不能覆盖安装官方 0.4.3。**  
   未从用户电脑取正式证书。因此 **没有上传** 蒲公英官方短链 https://www.pgyer.com/meiribaiti，以免把正式用户的覆盖安装搞坏。包留在云电脑，等正式签名后再发官方渠道。

## 服务端（已上线）

- 入口：CloudBase HTTP/WEB_SCF `dailyHundredImportV1Ingress`（路由未改，仍是原来的 `/api/import-ai/v1`）。
- 修改：向事件函数转发时使用原始 UTF-8 JSON，`isBase64Encoded:false`。会话处理会拒绝 `isBase64Encoded:true`，这是上次 413 改造后「又用不了」的直接原因。
- 部署：2026-11-12 约 16:05 Asia/Shanghai，`tcb fn code update`（只更代码）。
- 探针：`/workspace/zt045/evidence/ingress-session-fix-probe.json`  
  - 小包和 102401 字节的 completions：502 `gateway_unavailable`（不是 413，也不是 invalid_request）  
  - 格式正确的假 token 会话：503 `session_unavailable`（预期，假 token 不能证明真实付费会话 200）  
  - 错误路径：404「请求地址无效」（说明请求仍打到原事件函数）
- 已安装的官方 0.4.3 应能越过这次编码导致的「答题服务暂不可用」。真月卡会话 200 未在这次用假 token 证实。

## 客户端 0.4.4

- 工程：`/workspace/zt045/proj`（由云端已有工程 + `/workspace/zt045/payload` 图标/悬浮窗资源与 OverlayController）
- 版本：`versionName=0.4.4`，`versionCode=71`，应用 id `com.jimusoft.dailyhundredapp`，名称「知题」
- 行为（代码层，未改题镜识别/点击/坐标逻辑）：
  - 收起的圆形「知」只负责展开/收起，不开始答题
  - 展开空闲：待开始 + 开始答题
  - 答题中：答题中 + 已完成题数 + 暂停 + 结束
- APK（调试签名，仅云端可测）：
  - `/workspace/zt045/zhiti-0.4.4-code71-prod-debug-CLOUD-TEST-NOT-OFFICIAL-SIGN.apk`
  - `/workspace/tmp/zhiti-0.4.4-code71-prod-debug-CLOUD-TEST-NOT-OFFICIAL-SIGN.apk`
  - SHA-256：`079e2b1846baf7c058232a628ef179519361a9d55606409b65f7e423ef71773e`
  - 约 6.9MB，debuggable，不能当正式覆盖包

## 云端模拟器实测（emulator-5556，google_apis x86_64 / Android 14）

装包成功：`dumpsys` 为 71 / 0.4.4。未动用户手机，未卸用户真机应用。

已通过：

- 新图标：启动页 `/workspace/zt045/evidence/35-app-launch.png`；系统设置 App info（名称「知题」）`/workspace/zt045/evidence/42-settings.png`
- 包内含各密度 `ic_launcher` 以及 `overlay_bubble` / `card_idle` / `card_running`

未通过 / 没测完：

- 未在桌面应用列表里点到图标（主屏没有自动放快捷方式；滑抽屉手势在 SystemUI ANR/高负载时没拉开）
- 悬浮窗先展开再点「开始答题」：没能把录屏悬浮窗拉起来，故没有点击证据
- 应用内是否还报「答题服务暂不可用」、是否还 413：这次没走到可答题会话。服务端探针表明 413 和会话编码问题已在入口侧修掉
- 应用曾两次 native 崩溃（`Fatal signal 5 / SIGTRAP`，与 WebView 启动同期）；后来再打开会长时间白屏（`43-open1.png` / `44-open2.png` 连续截图完全一样，进程还在）

模拟器限制（不要当成应用必现问题）：无 KVM 加速（`-accel off`）、swiftshader、两核、guest 负载很高；中途 system_server 重启过、SystemUI 弹出过 “isn't responding”。ATD 的 5554 因 WebView 不可用已关掉，把内存让给 5556。

## 云电脑桌面（让用户能看见）

5556 是 `-no-window` 无界面跑的，所以之前桌面上只有进度文档。已在 `DISPLAY=:3` 打开自动刷新窗口「知题 0.4.4 云端模拟器实测 (emulator-5556)」，用截图刷新而不是一直挂 scrcpy（scrcpy 在这台无加速模拟器上会加重负载）。

## 蒲公英

按用户要求本应在测通后从云电脑上传 https://www.pgyer.com/meiribaiti。本次 **未上传**：

- 悬浮窗点击和应用内会话没有测通，不够「测通再发」
- 这是调试签名包，发到正式短链会让已安装官方 0.4.3 的用户无法覆盖安装
- 工作区没有现成的蒲公英 API 密钥；历史上传是登录后的浏览器上传

需要正式 0.4.4 时，请在能用正式证书的环境签名后再发该短链。云端调试包路径见上，不要把它当成官方包。

## 明确没做的事

- 没有从用户电脑拷签名库，没有对 RMSAMA 再做任何远程命令或传文件
- 没有改题镜截图/视觉/提示词/点击/坐标逻辑
- 没有卸载或清理用户真机应用和本地月卡数据
- 没有向用户收费
