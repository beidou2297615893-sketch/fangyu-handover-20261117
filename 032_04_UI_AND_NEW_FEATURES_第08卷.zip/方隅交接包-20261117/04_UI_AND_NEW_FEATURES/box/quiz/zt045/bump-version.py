from pathlib import Path
p = Path(r'C:\Users\rmsama\Documents\ChatGPT\答题小程序\每日百题APP\work\tijing-bankassist\android\app\build.gradle.kts')
t = p.read_text(encoding='utf-8')
t2 = t.replace('versionCode = 70', 'versionCode = 71').replace('versionName = "0.4.3"', 'versionName = "0.4.4"')
if 'versionCode = 71' not in t2 or '0.4.4' not in t2:
    raise SystemExit('version bump failed, current snippet:\n' + '\n'.join([ln for ln in t.splitlines() if 'version' in ln]))
p.write_text(t2, encoding='utf-8')
print('version bumped to 0.4.4 / 71')
