# -*- coding: utf-8 -*-
from pathlib import Path

ROOT = Path(r"C:\Users\rmsama\Documents\ChatGPT\答题小程序\每日百题APP\work\tijing-bankassist")
SRC = ROOT / "android" / "app" / "src" / "main" / "java" / "com" / "futureyyy" / "tijing"
TEST = ROOT / "android" / "app" / "src" / "test" / "java" / "com" / "futureyyy" / "tijing"


def must_replace(path: Path, old: str, new: str, count: int = 1) -> None:
    text = path.read_text(encoding="utf-8")
    found = text.count(old)
    if found != count:
        raise SystemExit(f"{path.name}: expected {count} occurrence(s) of marker, found {found}: {old[:80]!r}")
    path.write_text(text.replace(old, new), encoding="utf-8")
    print(f"patched {path.name}")


# --- new helper ---
(SRC / "QuizFinishedPage.kt").write_text(
    """package com.futureyyy.tijing

object QuizFinishedPage {
    fun matches(text: String): Boolean {
        val compact = text.replace("\\\\s".toRegex(), "")
        return compact.contains("重新抽取") ||
            compact.contains("已提交：") ||
            compact.contains("已提交:") ||
            compact.contains("得分：") ||
            compact.contains("得分:")
    }
}
""".replace("\\\\s", "\\s"),
    encoding="utf-8",
)
print("wrote QuizFinishedPage.kt")

(TEST / "QuizFinishedPageTest.kt").write_text(
    """package com.futureyyy.tijing

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class QuizFinishedPageTest {
    @Test
    fun detectsSubmittedAndRedrawButtons() {
        assertTrue(QuizFinishedPage.matches("已提交：100\\n重新抽取 100 题"))
        assertTrue(QuizFinishedPage.matches("得分：77 / 100"))
        assertTrue(QuizFinishedPage.matches("得分: 77 / 100"))
        assertTrue(QuizFinishedPage.matches("已提交: 100"))
    }

    @Test
    fun ignoresOrdinaryQuestionText() {
        assertFalse(QuizFinishedPage.matches("第70题 / 共100题\\n18 乘以 5 的结果是多少？"))
        assertFalse(QuizFinishedPage.matches("提交答案"))
        assertFalse(QuizFinishedPage.matches(""))
    }
}
""",
    encoding="utf-8",
)
print("wrote QuizFinishedPageTest.kt")

# GestureGateway
must_replace(
    SRC / "QuizRunCoordinator.kt",
    """interface GestureGateway {
    fun isTargetForeground(): Boolean
    fun targetUnavailableMessage(): String = "请打开题目页"
""",
    """interface GestureGateway {
    fun isTargetForeground(): Boolean
    fun isFinishedPage(): Boolean = false
    fun targetUnavailableMessage(): String = "请打开题目页"
""",
)

must_replace(
    SRC / "QuizRunCoordinator.kt",
    """        val frame = result.getOrElse { error ->
            fail(runGeneration, errorMessage(error, "截图失败"))
            return
        }
        if (mode == QuizMode.MANUAL && !prepareManualFrame(runGeneration, frame.signature)) return
""",
    """        val frame = result.getOrElse { error ->
            fail(runGeneration, errorMessage(error, "截图失败"))
            return
        }
        if (finishIfResultPage(runGeneration)) return
        if (mode == QuizMode.MANUAL && !prepareManualFrame(runGeneration, frame.signature)) return
""",
)

must_replace(
    SRC / "QuizRunCoordinator.kt",
    """        val parsed = try {
            QuizModelParser.parse(raw).let { ai -> runCatching { answerResolver(ai) }.getOrDefault(ai) }
        } catch (error: Exception) {
            fail(runGeneration, errorMessage(error, "模型响应解析失败"))
            return
        }
""",
    """        val parsed = try {
            QuizModelParser.parse(raw).let { ai -> runCatching { answerResolver(ai) }.getOrDefault(ai) }
        } catch (error: Exception) {
            val message = errorMessage(error, "模型响应解析失败")
            if (message.contains("options 缺少或为空") && finishIfResultPage(runGeneration)) return
            fail(runGeneration, message)
            return
        }
""",
)

must_replace(
    SRC / "QuizRunCoordinator.kt",
    """        if (
            mode == QuizMode.AUTO && automaticRunStarted &&
            isCurrent(runGeneration, RunnerPhase.READY)
        ) {
            beginQuestion()
        }
""",
    """        if (
            mode == QuizMode.AUTO && automaticRunStarted &&
            isCurrent(runGeneration, RunnerPhase.READY)
        ) {
            if (finishIfResultPage(runGeneration)) return
            beginQuestion()
        }
""",
)

must_replace(
    SRC / "QuizRunCoordinator.kt",
    """    private fun fail(runGeneration: Long, message: String) {
""",
    """    private fun finishIfResultPage(runGeneration: Long): Boolean {
        if (mode != QuizMode.AUTO) return false
        if (generation != runGeneration || phase == RunnerPhase.STOPPED) return false
        val finished = try {
            gestureGateway.isFinishedPage()
        } catch (_: Exception) {
            false
        }
        if (!finished) return false
        finishSuccessfully(runGeneration)
        return true
    }

    private fun finishSuccessfully(runGeneration: Long) {
        if (generation != runGeneration || phase == RunnerPhase.STOPPED) return
        invalidateCurrentWork()
        automaticRunStarted = false
        clearAutoCheckpoint()
        cancelGestures()
        errorMessage = null
        if (phase != RunnerPhase.STOPPED) transition(RunnerPhase.STOPPED)
    }

    private fun fail(runGeneration: Long, message: String) {
""",
)

# Accessibility
acc = SRC / "QuizAccessibilityService.kt"
must_replace(
    acc,
    """    fun isTargetForeground(targetPackage: String): Boolean {
""",
    """    fun isFinishedPage(targetPackage: String): Boolean {
        val root = findTargetRoot(targetPackage) ?: return false
        val visited = ArrayList<AccessibilityNodeInfo>()
        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.add(root)
        val parts = StringBuilder()
        try {
            while (queue.isNotEmpty() && visited.size < 200) {
                val node = queue.removeFirst()
                visited.add(node)
                for (i in 0 until node.childCount) node.getChild(i)?.let(queue::add)
                if (!node.isVisibleToUser) continue
                val label = (node.text ?: node.contentDescription)?.toString()?.trim().orEmpty()
                if (label.isNotEmpty()) {
                    if (parts.isNotEmpty()) parts.append(' ')
                    parts.append(label)
                    if (QuizFinishedPage.matches(parts.toString())) return true
                }
            }
            return QuizFinishedPage.matches(parts.toString())
        } catch (_: Exception) {
            return false
        } finally {
            recycleNodes(visited + queue)
        }
    }

    fun isTargetForeground(targetPackage: String): Boolean {
""",
)

# ScreenCaptureService
must_replace(
    SRC / "ScreenCaptureService.kt",
    """            override fun isTargetForeground(): Boolean {
                val service = QuizAccessibilityService.instance ?: return false
                return resolveTargetPackage(service) != null
            }
""",
    """            override fun isTargetForeground(): Boolean {
                val service = QuizAccessibilityService.instance ?: return false
                return resolveTargetPackage(service) != null
            }

            override fun isFinishedPage(): Boolean {
                val service = QuizAccessibilityService.instance ?: return false
                val targetPackage = resolveTargetPackage(service) ?: return false
                return service.isFinishedPage(targetPackage)
            }
""",
)

# Overlay
must_replace(
    SRC / "OverlayController.kt",
    """        if (running) {
            startHotspot?.visibility = View.GONE
            pauseHotspot?.visibility = View.VISIBLE
            stopHotspot?.visibility = View.VISIBLE
            layoutHotspot(pauseHotspot, width, height, 0.54f, 0.42f, 0.76f, 0.74f)
            layoutHotspot(stopHotspot, width, height, 0.77f, 0.42f, 0.95f, 0.74f)
""",
    """        if (running) {
            val finished = latestSnapshot?.phase == RunnerPhase.STOPPED
            startHotspot?.visibility = View.GONE
            pauseHotspot?.visibility = if (finished) View.GONE else View.VISIBLE
            stopHotspot?.visibility = View.VISIBLE
            if (!finished) {
                layoutHotspot(pauseHotspot, width, height, 0.54f, 0.42f, 0.76f, 0.74f)
            }
            layoutHotspot(stopHotspot, width, height, 0.77f, 0.42f, 0.95f, 0.74f)
""",
)

must_replace(
    SRC / "OverlayController.kt",
    """            RunnerPhase.WAITING_PAGE_CHANGE,
            RunnerPhase.PAUSED_ERROR,
            -> true
""",
    """            RunnerPhase.WAITING_PAGE_CHANGE,
            RunnerPhase.PAUSED_ERROR,
            RunnerPhase.STOPPED,
            -> true
""",
)

# Tests
test = TEST / "QuizRunCoordinatorTest.kt"
must_replace(
    test,
    """    private fun coordinator(
""",
    """    @Test
    fun automaticPageChangeStopsCleanlyOnFinishedPage() {
        val baseline = signature()
        val changed = signature(*(0 until QuizRunCoordinator.PAGE_CHANGE_DISTANCE).toList().toIntArray())
        val stable = signature(*(0 until (QuizRunCoordinator.PAGE_CHANGE_DISTANCE + 1)).toList().toIntArray())
        val capture = FakeCaptureGateway(autoComplete = false)
        val gestures = FakeGestureGateway()
        val scheduler = FakeRunnerScheduler()
        val listener = RecordingListener()
        val model = FakeModelGateway(singleQuestionJson(), singleQuestionJson())
        val coordinator = coordinator(
            mode = QuizMode.AUTO,
            capture = capture,
            model = model,
            gestures = gestures,
            listener = listener,
            scheduler = scheduler,
        )

        coordinator.onPrimaryAction()
        capture.completeActive(Result.success(frame(baseline)))
        capture.completeActive(Result.success(frame(baseline)))

        gestures.finishedPage = true
        scheduler.runNext()
        capture.completeActive(Result.success(frame(changed)))
        scheduler.runNext()
        capture.completeActive(Result.success(frame(stable)))

        assertEquals(RunnerPhase.STOPPED, coordinator.snapshot().phase)
        assertEquals(2, coordinator.snapshot().questionNo)
        assertEquals(null, coordinator.snapshot().errorMessage)
        assertTrue(listener.errors.isEmpty())
        assertEquals(listOf(1), model.questionNumbers)
    }

    @Test
    fun emptyOptionsOnFinishedPageStopsCleanly() {
        val capture = FakeCaptureGateway(autoComplete = false)
        val gestures = FakeGestureGateway().apply { finishedPage = true }
        val listener = RecordingListener()
        val model = FakeModelGateway(emptyOptionsJson())
        val coordinator = coordinator(
            mode = QuizMode.AUTO,
            capture = capture,
            model = model,
            gestures = gestures,
            listener = listener,
        )

        coordinator.onPrimaryAction()
        capture.completeActive(Result.success(frame(signature())))

        assertEquals(RunnerPhase.STOPPED, coordinator.snapshot().phase)
        assertEquals(null, coordinator.snapshot().errorMessage)
        assertTrue(listener.errors.isEmpty())
    }

    @Test
    fun emptyOptionsWithoutFinishedPageStillPauses() {
        val capture = FakeCaptureGateway(autoComplete = false)
        val gestures = FakeGestureGateway()
        val listener = RecordingListener()
        val coordinator = coordinator(
            mode = QuizMode.AUTO,
            capture = capture,
            model = FakeModelGateway(emptyOptionsJson()),
            gestures = gestures,
            listener = listener,
        )

        coordinator.onPrimaryAction()
        capture.completeActive(Result.success(frame(signature())))

        assertEquals(RunnerPhase.PAUSED_ERROR, coordinator.snapshot().phase)
        assertTrue(coordinator.snapshot().errorMessage?.contains("options 缺少或为空") == true)
        assertEquals(1, listener.errors.size)
    }

    private fun coordinator(
""",
)

must_replace(
    test,
    """    private fun singleQuestionJson() = \"\"\"
""",
    """    private fun emptyOptionsJson() = \"\"\"
        {
          "question_no": 2,
          "question_type": "single",
          "question": "结果页",
          "options": [],
          "answer_indices": [],
          "confirm_box": null,
          "next_box": null,
          "confidence": 0.2
        }
    \"\"\".trimIndent()

    private fun singleQuestionJson() = \"\"\"
""".replace('\\"\\"\\"', '"""'),
)

must_replace(
    test,
    """        var foreground = true
        var foregroundChecks = 0
        var cancelCount = 0
""",
    """        var foreground = true
        var foregroundChecks = 0
        var finishedPage = false
        var cancelCount = 0

        override fun isFinishedPage(): Boolean = finishedPage
""",
)

print("ALL_OK")
