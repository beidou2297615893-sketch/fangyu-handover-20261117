﻿param(
 [ValidateSet('ProdDebug','DevDebug','ProdRelease','DevRelease')][string]$Variant='ProdDebug',
 [switch]$UnitTests,[switch]$PaymentRelease,[switch]$FreeServiceRelease,[switch]$SkipWebBuild,
 [ValidateRange(1,8)][int]$Workers=2,
 [string]$StageRoot="$env:USERPROFILE/DailyHundredNativeBuild/work/tijing-bankassist-build"
)
$ErrorActionPreference='Stop'
$projectRoot=Split-Path -Parent $PSScriptRoot
$sharedWork='V:/work'
$jdk=(Get-ChildItem -LiteralPath "$sharedWork/tools/jdk" -Directory | Where-Object Name -like 'jdk-17*' | Select-Object -First 1).FullName
$gradle="$env:USERPROFILE/DailyHundredNativeBuild/work/tijing-toolchain/gradle-8.7/bin/gradle.bat"
if(!(Test-Path -LiteralPath "$jdk/bin/java.exe") -or !(Test-Path -LiteralPath $gradle)){throw 'Verified JDK17 and Gradle8.7 toolchain required'}
if($PaymentRelease -and $Variant -ne 'ProdRelease'){throw 'PaymentRelease is allowed only with ProdRelease'}
if($FreeServiceRelease -and !$PaymentRelease){throw 'FreeServiceRelease requires the verified production payment service'}
$env:JAVA_HOME=$jdk
$env:ANDROID_HOME="$sharedWork/tools/android-sdk"
$env:ANDROID_SDK_ROOT=$env:ANDROID_HOME
$env:GRADLE_USER_HOME="$sharedWork/gradle-home"
if(!(Test-Path -LiteralPath "$env:ANDROID_HOME/platforms/android-35/android.jar")){throw 'Official Android SDK platform35 is required'}
$logRoot=Join-Path $PSScriptRoot "build-logs/$Variant"
New-Item -ItemType Directory -Path $logRoot -Force | Out-Null
$releaseMap=@{DAILYHUNDRED_STORE_FILE='DAILYHUNDRED_STORE_FILE';DAILYHUNDRED_STORE_PASSWORD='DAILYHUNDRED_STORE_PASSWORD';DAILYHUNDRED_KEY_ALIAS='DAILYHUNDRED_KEY_ALIAS';DAILYHUNDRED_KEY_PASSWORD='DAILYHUNDRED_KEY_PASSWORD'}
$previous=@{}
foreach($target in $releaseMap.Keys){$previous[$target]=[Environment]::GetEnvironmentVariable($target,'Process')}
try {
 foreach($target in $releaseMap.Keys){
  $value=if($Variant.EndsWith('Release')){[Environment]::GetEnvironmentVariable($releaseMap[$target],'User')}else{$null}
  if($Variant.EndsWith('Release') -and !$value){throw "Missing User signing variable: $($releaseMap[$target])"}
  [Environment]::SetEnvironmentVariable($target,$value,'Process')
 }
 Remove-Variable value
 if(!$SkipWebBuild){
  Push-Location $projectRoot
  try {
   & npm.cmd run build > "$logRoot/web-build.log" 2>&1
   if($LASTEXITCODE){throw 'Web build failed; see the project build log'}
   & node scripts/sync-android-assets.mjs > "$logRoot/assets-sync.log" 2>&1
   if($LASTEXITCODE){throw 'Android asset sync failed'}
  } finally {Pop-Location}
 }
 & python "$PSScriptRoot/snapshot-android-build.py" --source $projectRoot --stage $StageRoot
 if($LASTEXITCODE){throw 'Source snapshot failed'}
 $tasks=@(":app:assemble$Variant")
 if($UnitTests){$tasks=@(':app:testProdDebugUnitTest',':app:testDevDebugUnitTest')+$tasks}
 $pay=$PaymentRelease.ToString().ToLowerInvariant()
 $freeService=$FreeServiceRelease.ToString().ToLowerInvariant()
 $ErrorActionPreference='Continue'; & $gradle -p "$StageRoot/android" @tasks --no-daemon "--max-workers=$Workers" --console=plain --init-script "$PSScriptRoot/network-repositories.init.gradle" '-Dorg.gradle.internal.http.connectionTimeout=15000' '-Dorg.gradle.internal.http.socketTimeout=15000' "-PpaymentRelease=$pay" "-PfreeServiceRelease=$freeService" > "$logRoot/android-build.log" 2>&1
 $ErrorActionPreference='Stop'; if($LASTEXITCODE){throw 'Android build failed; see the project build log'}
 & python "$PSScriptRoot/snapshot-android-build.py" --source $projectRoot --stage $StageRoot --verify
 if($LASTEXITCODE){throw 'Source changed during build; rebuild the final frozen inputs'}
 $flavor=if($Variant.StartsWith('Prod')){'prod'}else{'dev'}
 $buildType=if($Variant.EndsWith('Release')){'release'}else{'debug'}
 $apkPath="$StageRoot/android/app/build/outputs/apk/$flavor/$buildType/app-$flavor-$buildType.apk"
 $apk=if(Test-Path -LiteralPath $apkPath){Get-Item -LiteralPath $apkPath}else{$null}
 if(!$apk){throw 'Expected variant APK was not produced'}
 & "$env:ANDROID_HOME/build-tools/35.0.0/apksigner.bat" verify --print-certs $apk.FullName > "$logRoot/signature-verification.txt" 2>&1
 if($LASTEXITCODE){throw 'APK signature verification failed'}
 if($Variant.EndsWith('Release') -and !(Select-String -LiteralPath "$logRoot/signature-verification.txt" -SimpleMatch 'fac61745dc0903786fb9ede62a962b399f7348f0bb6f899b8332667591033b9c')){throw 'Release certificate does not match the existing official application'}
 $result=[ordered]@{variant=$Variant;paymentRelease=[bool]$PaymentRelease;apk=$apk.FullName;sha256=(Get-FileHash -LiteralPath $apk.FullName -Algorithm SHA256).Hash.ToLowerInvariant();sourceInputSha256=(Get-FileHash -LiteralPath "$StageRoot/build-source-input.json" -Algorithm SHA256).Hash.ToLowerInvariant();sourceUnchangedDuringBuild=$true;notInstalled=$true;notPublished=$true}
 $result | ConvertTo-Json | Set-Content -LiteralPath "$logRoot/build-result.json"
 $result | ConvertTo-Json
} finally {
 Remove-Variable value -ErrorAction SilentlyContinue
 foreach($target in $releaseMap.Keys){[Environment]::SetEnvironmentVariable($target,$previous[$target],'Process')}
}

