from pathlib import Path
import shutil
from datetime import datetime

root = Path(r'V:\work\original-vs-0419\release-mobile')
svc_path = root / r'android\app\src\main\java\com\futureyyy\tijing\ScreenCaptureService.kt'
ovl_path = root / r'android\app\src\main\java\com\futureyyy\tijing\OverlayController.kt'
gradle_path = root / r'android\app\build.gradle.kts'
bak_dir = Path(r'C:\Users\rmsama\AppData\Local\Temp\zt0422-gpt-pack\backup-0422')
bak_dir.mkdir(parents=True, exist_ok=True)
stamp = datetime.now().strftime('%H%M%S')
for p in (svc_path, ovl_path, gradle_path):
    shutil.copy2(p, bak_dir / (p.name + '.' + stamp + '.bak'))
    print('backed', p.name)

svc = svc_path.read_text(encoding='utf-8')
ovl = ovl_path.read_text(encoding='utf-8')
gradle = gradle_path.read_text(encoding='utf-8')

old_call = '        scheduleAutoStartRunner(generation)\n'
assert svc.count(old_call) == 1, 'call site count %s' % svc.count(old_call)
svc = svc.replace(old_call, '', 1)

old_members = '''    private var autoStartRunnable: Runnable? = null
    private var autoStartConsumed = false
'''
assert svc.count(old_members) == 1
svc = svc.replace(old_members, '', 1)

old_recover = '''    private fun recoverRun(generation: Long) {
        if (destroyed || generation != runnerGeneration || projectionRecovery.phase != null || !isCaptureReady()) return
        if (!gatewayRunnerStarted) {
            startAuthorizedRunner(generation)
            return
        }
        val session = gatewaySession
        val target = gatewayTarget
        if (session == null || session.expiresAt <= System.currentTimeMillis()) {
            overlayController?.showError("本轮使用时间已到，请结束本轮后重新开始。")
            return
        }
        if (target == null || QuizAccessibilityService.instance?.isTargetForeground(target) != true) {
            overlayController?.showError("请回到刚才显示题目和选项的页面，再点重试。")
            return
        }
        val runner = coordinator ?: return
        if (runner.snapshot().phase != RunnerPhase.PAUSED_ERROR) return
        overlayController?.dismissRunError()
        runner.retry()
    }
'''
assert old_recover in svc, 'recoverRun block not found'
new_recover = '''    private fun recoverRun(generation: Long) {
        // 所有恢复操作统一在主线程执行。
        if (Looper.myLooper() != Looper.getMainLooper()) {
            mainHandler.post { recoverRun(generation) }
            return
        }
        if (destroyed || generation != runnerGeneration) return
        val overlay = overlayController ?: return
        if (projectionRecovery.phase != null) {
            overlay.showRecognitionStatus("屏幕共享正在恢复，请稍候。")
            return
        }
        if (!isCaptureReady()) {
            overlay.showError("屏幕共享尚未准备好，请重新授权后再试。")
            return
        }
        // 权限核对正在进行时，不重复提交请求。
        if (pendingGatewayStart != null) {
            overlay.showRecognitionStatus("正在核对本轮答题权限，请稍候。")
            return
        }
        // 首次启动失败时，允许从悬浮窗重新发起启动流程。
        if (!gatewayRunnerStarted) {
            overlay.showRecognitionStatus("正在重新检查答题页面和本轮权限。")
            startAuthorizedRunner(generation)
            return
        }
        val session = gatewaySession
        val target = gatewayTarget
        if (session == null || session.expiresAt <= System.currentTimeMillis()) {
            overlay.showError("本轮使用时间已到，请结束本轮后重新开始。")
            return
        }
        val accessibility = QuizAccessibilityService.instance
        if (target.isNullOrBlank() || accessibility?.isTargetForeground(target) != true) {
            overlay.showError("请切回本次答题时使用的原题目页面，再点重试或继续。")
            return
        }
        val runner = coordinator
        if (runner == null) {
            overlay.showError("答题引擎尚未就绪，请结束本轮后重新开始。")
            return
        }
        val currentPhase = runner.snapshot().phase
        if (currentPhase != RunnerPhase.PAUSED_ERROR) {
            overlay.showError("当前答题任务不处于暂停状态，请检查页面；如无法恢复，请结束本轮后重新开始。")
            return
        }
        // 只有确认是可恢复的暂停状态，才执行真正的重试。
        overlay.dismissRunError()
        runner.retry()
    }
'''
svc = svc.replace(old_recover, new_recover, 1)

start = svc.find('    private fun scheduleAutoStartRunner(generation: Long) {')
assert start != -1, 'scheduleAutoStartRunner not found'
fail = svc.find('    private fun failAutoStart(message: String) {', start)
assert fail != -1, 'failAutoStart not found'
end = svc.find('    private fun notifySessionError', fail)
assert end != -1, 'notifySessionError not found'
svc = svc[:start] + svc[end:]

old_teardown = '''        autoStartRunnable?.let(mainHandler::removeCallbacks)
        autoStartRunnable = null
        autoStartConsumed = false
'''
assert svc.count(old_teardown) == 1
svc = svc.replace(old_teardown, '', 1)

old_consts = '''        private const val AUTO_START_INITIAL_DELAY_MS = 400L
        private const val AUTO_START_RETRY_MS = 250L
        private const val AUTO_START_WAIT_MS = 45_000L
'''
assert svc.count(old_consts) == 1
svc = svc.replace(old_consts, '', 1)

leftover = []
for k in ['scheduleAutoStartRunner', 'autoStartRunnable', 'autoStartConsumed', 'AUTO_START_', 'failAutoStart']:
    if k in svc:
        leftover.append('%s:%d' % (k, svc.count(k)))
if leftover:
    raise SystemExit('leftover ' + str(leftover))

uses = [i for i, l in enumerate(svc.splitlines()) if 'SystemClock' in l]
print('SystemClock lines', [i + 1 for i in uses])
if uses and all('import android.os.SystemClock' in svc.splitlines()[i] for i in uses):
    svc = svc.replace('import android.os.SystemClock\n', '', 1)
    print('removed unused SystemClock import')

old_btns = '''            addView(actionButton("重试") { runCatching { callbacks.onRetry() } })
            addView(actionButton("继续") { runCatching { callbacks.onResume() } })
'''
assert ovl.count(old_btns) == 1, 'overlay buttons not unique: %s' % ovl.count(old_btns)
new_btns = '''            addView(actionButton("重试") {
                showRecognitionStatus("正在重试当前题，请稍候…")
                runCatching {
                    callbacks.onRetry()
                }.onFailure { error ->
                    showErrorOnMain(error.message ?: "重试失败，请再次尝试。")
                }
            })
            addView(actionButton("继续") {
                showRecognitionStatus("正在恢复本轮答题，请稍候…")
                runCatching {
                    callbacks.onResume()
                }.onFailure { error ->
                    showErrorOnMain(error.message ?: "恢复失败，请再次尝试。")
                }
            })
'''
ovl = ovl.replace(old_btns, new_btns, 1)

assert 'versionCode = 88' in gradle and 'versionName = "0.4.21"' in gradle
gradle = gradle.replace('versionCode = 88', 'versionCode = 89', 1)
gradle = gradle.replace('versionName = "0.4.21"', 'versionName = "0.4.22"', 1)

svc_path.write_text(svc, encoding='utf-8', newline='\n')
ovl_path.write_text(ovl, encoding='utf-8', newline='\n')
gradle_path.write_text(gradle, encoding='utf-8', newline='\n')
print('patched ok')
print('svc', svc_path.stat().st_size, 'ovl', ovl_path.stat().st_size)
for i, l in enumerate(gradle.splitlines(), 1):
    if 'versionCode' in l or 'versionName' in l:
        print(i, l)
