﻿# Attach 0.4.22 sources + test logs to the existing ChatGPT thread. Do not start a new chat.
$ErrorActionPreference='Stop'
$outDir='C:\Users\rmsama\AppData\Local\Temp\zt0423-gpt-pack'
$attachDir=Join-Path $outDir 'attach-0422'
$log=Join-Path $outDir 'attach-sources-log.txt'
function Log($m){ $line='[' + (Get-Date -Format 'HH:mm:ss.fff') + '] ' + $m; Add-Content -Path $log -Value $line -Encoding UTF8; Write-Output $line }

New-Item -ItemType Directory -Force -Path $attachDir | Out-Null
$cRoot='C:\Users\rmsama\Documents\ChatGPT\答题小程序\每日百题APP\work\original-vs-0419\release-mobile'
$vRoot='V:\work\original-vs-0419\release-mobile'
$root = if (Test-Path (Join-Path $vRoot 'android\app\src\main\java\com\futureyyy\tijing\GatewaySessionEntry.kt')) { $vRoot } elseif (Test-Path (Join-Path $cRoot 'android\app\src\main\java\com\futureyyy\tijing\GatewaySessionEntry.kt')) { $cRoot } else { $null }
# GatewaySessionEntry was not changed; 0.4.22 ScreenCapture/Overlay are in the backup folder.
$bak=Join-Path $outDir 'backup-0422-src'
Copy-Item (Join-Path $bak 'ScreenCaptureService.kt') (Join-Path $attachDir 'ScreenCaptureService.kt') -Force
Copy-Item (Join-Path $bak 'OverlayController.kt') (Join-Path $attachDir 'OverlayController.kt') -Force
$gseCandidates=@(
  (Join-Path $vRoot 'android\app\src\main\java\com\futureyyy\tijing\payment\GatewaySessionEntry.kt'),
  (Join-Path $cRoot 'android\app\src\main\java\com\futureyyy\tijing\payment\GatewaySessionEntry.kt')
)
$gse=$gseCandidates | Where-Object { Test-Path $_ } | Select-Object -First 1
if (-not $gse) { throw 'GatewaySessionEntry.kt not found' }
Copy-Item $gse (Join-Path $attachDir 'GatewaySessionEntry.kt') -Force
Log ('COPIED_GSE ' + $gse)

$files=@(
  (Join-Path $attachDir 'GatewaySessionEntry.kt'),
  (Join-Path $attachDir 'ScreenCaptureService.kt'),
  (Join-Path $attachDir 'OverlayController.kt'),
  (Join-Path $attachDir 'REPORT.md'),
  (Join-Path $attachDir 'logcat-key.txt')
)
foreach($f in $files){ if(-not (Test-Path $f)){ throw ('MISSING ' + $f) } ; Log ('FILE ' + $f + ' ' + (Get-Item $f).Length) }

Add-Type -AssemblyName UIAutomationClient
Add-Type -AssemblyName UIAutomationTypes
Add-Type -AssemblyName System.Windows.Forms
Add-Type -TypeDefinition @"
using System;
using System.Text;
using System.Runtime.InteropServices;
public static class Win32Chat2 {
  public delegate bool EnumProc(IntPtr h, IntPtr l);
  [DllImport("user32.dll")] public static extern bool EnumWindows(EnumProc lp, IntPtr l);
  [DllImport("user32.dll")] public static extern int GetWindowText(IntPtr h, StringBuilder s, int n);
  [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr h);
  [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr h, out uint pid);
  [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
  [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr h, int n);
  [DllImport("user32.dll")] public static extern bool BringWindowToTop(IntPtr h);
  [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
  [DllImport("user32.dll")] public static extern bool AttachThreadInput(uint a, uint b, bool f);
  [DllImport("kernel32.dll")] public static extern uint GetCurrentThreadId();
  [DllImport("user32.dll")] public static extern bool SetCursorPos(int x, int y);
  [DllImport("user32.dll")] public static extern void mouse_event(int flags, int dx, int dy, int d, int e);
  [DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr h, out RECT r);
  public struct RECT { public int Left; public int Top; public int Right; public int Bottom; }
}
"@

function Force-Foreground([IntPtr]$h){
  $fg=[Win32Chat2]::GetForegroundWindow()
  $fgPid=0; $curTid=[Win32Chat2]::GetWindowThreadProcessId($fg, [ref]$fgPid)
  $myTid=[Win32Chat2]::GetCurrentThreadId()
  if($curTid -ne 0 -and $curTid -ne $myTid){ [void][Win32Chat2]::AttachThreadInput($myTid, $curTid, $true) }
  [void][Win32Chat2]::ShowWindow($h, 9)
  [void][Win32Chat2]::BringWindowToTop($h)
  $ok=[Win32Chat2]::SetForegroundWindow($h)
  if($curTid -ne 0 -and $curTid -ne $myTid){ [void][Win32Chat2]::AttachThreadInput($myTid, $curTid, $false) }
  return $ok
}

function Get-UiaEl([IntPtr]$h){ [System.Windows.Automation.AutomationElement]::FromHandle($h) }

function Walk($root, $max=2500){
  $walker=[System.Windows.Automation.TreeWalker]::ControlViewWalker
  $q=New-Object System.Collections.Generic.Queue[object]
  $q.Enqueue($root)
  $n=0
  while($q.Count -gt 0 -and $n -lt $max){
    $el=$q.Dequeue(); $n++
    $name=''; $ct=''; try { $name=$el.Current.Name; $ct=$el.Current.ControlType.ProgrammaticName } catch {}
    if($name -match '聊天|工作|发送|Send|停止|新聊天|New chat|Ask|提问|询问|附件|添加' -or $ct -match 'Edit|Document|Button|TabItem'){
      $r=$el.Current.BoundingRectangle
      Log ('UIA ' + $ct + ' name=[' + $name + '] en=' + $el.Current.IsEnabled + ' rect=' + [int]$r.X + ',' + [int]$r.Y + ' ' + [int]$r.Width + 'x' + [int]$r.Height)
    }
    try {
      $c=$walker.GetFirstChild($el)
      while($c){ $q.Enqueue($c); $c=$walker.GetNextSibling($c) }
    } catch {}
  }
}

function Find-ByName($root, $pattern, $typePat='.*'){
  $walker=[System.Windows.Automation.TreeWalker]::ControlViewWalker
  $q=New-Object System.Collections.Generic.Queue[object]
  $q.Enqueue($root)
  $n=0
  $hits=@()
  while($q.Count -gt 0 -and $n -lt 3000){
    $el=$q.Dequeue(); $n++
    $name=''; $ct=''; try { $name=$el.Current.Name; $ct=$el.Current.ControlType.ProgrammaticName } catch {}
    if($name -match $pattern -and $ct -match $typePat){ $hits += $el }
    try { $c=$walker.GetFirstChild($el); while($c){ $q.Enqueue($c); $c=$walker.GetNextSibling($c) } } catch {}
  }
  return $hits
}

function Click-El($el){
  $r=$el.Current.BoundingRectangle
  $x=[int]($r.X + $r.Width/2); $y=[int]($r.Y + $r.Height/2)
  [void][Win32Chat2]::SetCursorPos($x, $y)
  Start-Sleep -Milliseconds 80
  [Win32Chat2]::mouse_event(0x0002, 0, 0, 0, 0)
  Start-Sleep -Milliseconds 40
  [Win32Chat2]::mouse_event(0x0004, 0, 0, 0, 0)
  Log ('CLICK ' + $el.Current.Name + ' at ' + $x + ',' + $y)
}

# Find ChatGPT window via process main window (avoid EnumProc parse issues)
$proc=Get-Process | Where-Object { $_.ProcessName -match 'ChatGPT' -and $_.MainWindowHandle -ne 0 } | Select-Object -First 1
if(-not $proc){ throw 'CHATGPT_WINDOW_NOT_FOUND' }
$sb=New-Object System.Text.StringBuilder 512
[void][Win32Chat2]::GetWindowText($proc.MainWindowHandle, $sb, 512)
$win=[pscustomobject]@{ hwnd=[int64]$proc.MainWindowHandle; pid=$proc.Id; title=$sb.ToString(); proc=$proc.ProcessName }
Log ('PICK hwnd=' + $win.hwnd + ' pid=' + $win.pid + ' title=' + $win.title + ' proc=' + $win.proc)

$h=[IntPtr]$win.hwnd
$fgOk=Force-Foreground $h
$fgNow=[Win32Chat2]::GetForegroundWindow()
Log ('FG_OK=' + $fgOk + ' FG_NOW=' + [int64]$fgNow)
if((-not $fgOk) -or ($fgNow -ne $h)){ throw 'CHATGPT_NOT_FOREGROUND_ABORT' }

$root=Get-UiaEl $h
# Stay in this chat. Abort if a new-chat or mode switch would be needed.
$modeBtns=Find-ByName $root '当前模式' 'Button'
foreach($b in $modeBtns){ Log ('MODE ' + $b.Current.Name) }

$composer=$null
$comps=Find-ByName $root '询问 ChatGPT' 'Edit|Document'
if($comps.Count -eq 0){ $comps=Find-ByName $root '询问 ChatGPT' '.*' }
if($comps.Count -eq 0){ throw 'COMPOSER_NOT_FOUND' }
$composer=$comps | Select-Object -First 1
$cr=$composer.Current.BoundingRectangle
Log ('COMPOSER ' + [int]$cr.X + ',' + [int]$cr.Y + ' ' + [int]$cr.Width + 'x' + [int]$cr.Height)

# File drop list
$col=New-Object System.Collections.Specialized.StringCollection
foreach($f in $files){ [void]$col.Add($f) }
[System.Windows.Forms.Clipboard]::SetFileDropList($col)
Log 'CLIPBOARD_FILES_SET'

Click-El $composer
Start-Sleep -Milliseconds 200
$msg='按你的要求，把当前 0.4.22 的 GatewaySessionEntry.kt、ScreenCaptureService.kt、OverlayController.kt，以及 REPORT.md 和 logcat-key.txt 附在本对话里，供你继续判断授权 503。两处确认补丁已按你上一份方案写入工程，版本暂定为 0.4.23，按你的要求先不发布，等第 1 题真正进入识别和点击后再说。请继续完成 503 判断，并给出下一步可执行的改法。'
[System.Windows.Forms.Clipboard]::SetText($msg)
Start-Sleep -Milliseconds 150
[System.Windows.Forms.SendKeys]::SendWait('^a')
Start-Sleep -Milliseconds 80
[System.Windows.Forms.SendKeys]::SendWait('^v')
Log 'PASTED_TEXT'
Start-Sleep -Milliseconds 400
# Then paste the source/log files
$col=New-Object System.Collections.Specialized.StringCollection
foreach($f in $files){ [void]$col.Add($f) }
[System.Windows.Forms.Clipboard]::SetFileDropList($col)
Log 'CLIPBOARD_FILES_SET'
[System.Windows.Forms.SendKeys]::SendWait('^v')
Log 'PASTED_FILES'
Start-Sleep -Seconds 4

$root=Get-UiaEl $h
# Find send button; only click if name is 发送 and enabled
function Find-Send($root){
  $walker=[System.Windows.Automation.TreeWalker]::ControlViewWalker
  $q=New-Object System.Collections.Generic.Queue[object]
  $q.Enqueue($root)
  $n=0
  $cands=@()
  while($q.Count -gt 0 -and $n -lt 3000){
    $el=$q.Dequeue(); $n++
    $name=''; $ct=''; try { $name=$el.Current.Name; $ct=$el.Current.ControlType.ProgrammaticName } catch {}
    if($ct -match 'Button' -and $name -match '发送|Send|停止'){
      $r=$el.Current.BoundingRectangle
      $cands += [pscustomobject]@{ el=$el; name=$name; en=$el.Current.IsEnabled; x=[int]$r.X; y=[int]$r.Y; w=[int]$r.Width; h=[int]$r.Height }
    }
    try { $c=$walker.GetFirstChild($el); while($c){ $q.Enqueue($c); $c=$walker.GetNextSibling($c) } } catch {}
  }
  return $cands
}
$cands=Find-Send $root
foreach($c in $cands){ Log ('SENDCAND name=[' + $c.name + '] en=' + $c.en + ' rect=' + $c.x + ',' + $c.y + ' ' + $c.w + 'x' + $c.h) }
$pick=$cands | Where-Object { $_.en -and $_.name -eq '发送' -and $_.w -ge 24 -and $_.w -le 90 -and $_.h -ge 24 -and $_.h -le 90 } | Sort-Object x -Descending | Select-Object -First 1
if(-not $pick){
  Log 'SEND_NOT_READY'
  throw 'SEND_NOT_READY'
}
# Re-check foreground
if([Win32Chat2]::GetForegroundWindow() -ne $h){ throw 'LOST_FOREGROUND_BEFORE_SEND' }
Click-El $pick.el
Start-Sleep -Seconds 2
$root=Get-UiaEl $h
$after=Find-Send $root
foreach($c in $after){ Log ('AFTER name=[' + $c.name + '] en=' + $c.en) }
Log 'ATTACH_SCRIPT_DONE'
