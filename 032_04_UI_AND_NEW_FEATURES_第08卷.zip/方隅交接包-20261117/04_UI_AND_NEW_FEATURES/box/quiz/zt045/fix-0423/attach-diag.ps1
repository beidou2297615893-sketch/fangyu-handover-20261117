﻿# Attach diagnostic results + payment sources to the existing ChatGPT thread. Do not start a new chat.
$ErrorActionPreference='Stop'
$outDir='C:\Users\rmsama\AppData\Local\Temp\zt0423-gpt-pack'
$attachDir=Join-Path $outDir 'attach-diag'
$log=Join-Path $outDir 'attach-diag-log.txt'
function Log($m){ $line='[' + (Get-Date -Format 'HH:mm:ss.fff') + '] ' + $m; Add-Content -Path $log -Value $line -Encoding UTF8; Write-Output $line }

$files=@(
  (Join-Path $attachDir 'REPORT-DIAG.md'),
  (Join-Path $attachDir 'logcat-all-after-click.txt'),
  (Join-Path $attachDir '04-expanded.png'),
  (Join-Path $attachDir '05-after-start.png'),
  (Join-Path $attachDir 'AndroidPayment.kt'),
  (Join-Path $attachDir 'AndroidRunLedger.kt'),
  (Join-Path $attachDir 'RunBilling.kt'),
  (Join-Path $attachDir 'SecurePaymentStore.kt'),
  (Join-Path $attachDir 'GatewaySessionEntry.kt')
)
foreach($f in $files){ if(-not (Test-Path $f)){ throw ('MISSING ' + $f) } ; Log ('FILE ' + $f + ' ' + (Get-Item $f).Length) }

Add-Type -AssemblyName UIAutomationClient
Add-Type -AssemblyName UIAutomationTypes
Add-Type -AssemblyName System.Windows.Forms
Add-Type -TypeDefinition @"
using System;
using System.Text;
using System.Runtime.InteropServices;
public static class Win32Chat3 {
  [DllImport("user32.dll")] public static extern int GetWindowText(IntPtr h, StringBuilder s, int n);
  [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
  [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr h, int n);
  [DllImport("user32.dll")] public static extern bool BringWindowToTop(IntPtr h);
  [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
  [DllImport("user32.dll")] public static extern bool AttachThreadInput(uint a, uint b, bool f);
  [DllImport("kernel32.dll")] public static extern uint GetCurrentThreadId();
  [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr h, out uint pid);
  [DllImport("user32.dll")] public static extern bool SetCursorPos(int x, int y);
  [DllImport("user32.dll")] public static extern void mouse_event(int flags, int dx, int dy, int d, int e);
}
"@

function Force-Foreground([IntPtr]$h){
  $fg=[Win32Chat3]::GetForegroundWindow()
  $fgPid=0; $curTid=[Win32Chat3]::GetWindowThreadProcessId($fg, [ref]$fgPid)
  $myTid=[Win32Chat3]::GetCurrentThreadId()
  if($curTid -ne 0 -and $curTid -ne $myTid){ [void][Win32Chat3]::AttachThreadInput($myTid, $curTid, $true) }
  [void][Win32Chat3]::ShowWindow($h, 9)
  [void][Win32Chat3]::BringWindowToTop($h)
  $ok=[Win32Chat3]::SetForegroundWindow($h)
  if($curTid -ne 0 -and $curTid -ne $myTid){ [void][Win32Chat3]::AttachThreadInput($myTid, $curTid, $false) }
  return $ok
}

function Find-ByName($root, $pattern, $typePat='.*'){
  $walker=[System.Windows.Automation.TreeWalker]::ControlViewWalker
  $q=New-Object System.Collections.Generic.Queue[object]
  $q.Enqueue($root)
  $n=0
  $hits=@()
  while($q.Count -gt 0 -and $n -lt 8000){
    $el=$q.Dequeue(); $n++
    $name=''; $ct=''; try { $name=$el.Current.Name; $ct=$el.Current.ControlType.ProgrammaticName } catch {}
    if($name -match $pattern -and $ct -match $typePat){ $hits += $el }
    try { $c=$walker.GetFirstChild($el); while($c){ $q.Enqueue($c); $c=$walker.GetNextSibling($c) } } catch {}
  }
  return $hits
}

function Click-El($el){
  $r=$el.Current.BoundingRectangle
  $x=[int]($r.X + $r.Width/2); $y=[int]($r.Y + $r.Height/2)
  [void][Win32Chat3]::SetCursorPos($x, $y)
  Start-Sleep -Milliseconds 80
  [Win32Chat3]::mouse_event(0x0002, 0, 0, 0, 0)
  Start-Sleep -Milliseconds 40
  [Win32Chat3]::mouse_event(0x0004, 0, 0, 0, 0)
  Log ('CLICK ' + $el.Current.Name + ' at ' + $x + ',' + $y)
}

$proc=Get-Process | Where-Object { $_.ProcessName -match 'ChatGPT' -and $_.MainWindowHandle -ne 0 } | Select-Object -First 1
if(-not $proc){ throw 'CHATGPT_WINDOW_NOT_FOUND' }
$sb=New-Object System.Text.StringBuilder 512
[void][Win32Chat3]::GetWindowText($proc.MainWindowHandle, $sb, 512)
Log ('PICK hwnd=' + [int64]$proc.MainWindowHandle + ' pid=' + $proc.Id + ' title=' + $sb.ToString())
$h=[IntPtr]$proc.MainWindowHandle
$fgOk=Force-Foreground $h
$fgNow=[Win32Chat3]::GetForegroundWindow()
Log ('FG_OK=' + $fgOk + ' FG_NOW=' + [int64]$fgNow)
if((-not $fgOk) -or ($fgNow -ne $h)){ throw 'CHATGPT_NOT_FOREGROUND_ABORT' }

$root=[System.Windows.Automation.AutomationElement]::FromHandle($h)
$modeBtns=Find-ByName $root '当前模式' 'Button'
foreach($b in $modeBtns){ Log ('MODE ' + $b.Current.Name) }

$comps=Find-ByName $root '询问 ChatGPT' 'Edit|Document'
if($comps.Count -eq 0){ $comps=Find-ByName $root '询问 ChatGPT' '.*' }
if($comps.Count -eq 0){ throw 'COMPOSER_NOT_FOUND' }
$composer=$comps | Select-Object -First 1
$cr=$composer.Current.BoundingRectangle
Log ('COMPOSER ' + [int]$cr.X + ',' + [int]$cr.Y + ' ' + [int]$cr.Width + 'x' + [int]$cr.Height)

Click-El $composer
Start-Sleep -Milliseconds 200
$msg='按你的诊断方案，已只改 GatewaySessionEntry.kt 加日志，正式签名 0.4.23（versionCode 90）覆盖安装，未卸载、未清数据、未重置 runId。按你的要求启动了一次答题，失败后没有点重试。附件包括报告、截图、日志，以及你要的 AndroidPayment.kt（里面有 PaymentRuntime 和 gatewayAuthorizationOnWorker）、AndroidRunLedger.kt、RunBilling.kt、SecurePaymentStore.kt，还有当前的 GatewaySessionEntry.kt。请根据这些材料给出下一步最小方案。执行方只执行你的决定，不自行改授权或计费。'
[System.Windows.Forms.Clipboard]::SetText($msg)
Start-Sleep -Milliseconds 150
[System.Windows.Forms.SendKeys]::SendWait('^a')
Start-Sleep -Milliseconds 80
[System.Windows.Forms.SendKeys]::SendWait('^v')
Log 'PASTED_TEXT'
Start-Sleep -Milliseconds 400
$col=New-Object System.Collections.Specialized.StringCollection
foreach($f in $files){ [void]$col.Add($f) }
[System.Windows.Forms.Clipboard]::SetFileDropList($col)
Log 'CLIPBOARD_FILES_SET'
[System.Windows.Forms.SendKeys]::SendWait('^v')
Log 'PASTED_FILES'
Start-Sleep -Seconds 5

function Find-Send($root){
  $walker=[System.Windows.Automation.TreeWalker]::ControlViewWalker
  $q=New-Object System.Collections.Generic.Queue[object]
  $q.Enqueue($root)
  $n=0
  $cands=@()
  while($q.Count -gt 0 -and $n -lt 8000){
    $el=$q.Dequeue(); $n++
    $name=''; $ct=''; try { $name=$el.Current.Name; $ct=$el.Current.ControlType.ProgrammaticName } catch {}
    if($ct -match 'Button' -and $name -match '发送|Send|停止'){
      $r=$el.Current.BoundingRectangle
      $cands += [pscustomobject]@{ el=$el; name=$name; en=$el.Current.IsEnabled; x=[int]$r.X; y=[int]$r.Y; w=[int]$r.Width; h=[int]$r.Height }
    }
    try { $c=$walker.GetFirstChild($el); while($c){ $q.Enqueue($c); $c=$walker.GetNextSibling($c) } } catch {}
  }
  return $cands
}
$root=[System.Windows.Automation.AutomationElement]::FromHandle($h)
$cands=Find-Send $root
foreach($c in $cands){ Log ('SENDCAND name=[' + $c.name + '] en=' + $c.en + ' rect=' + $c.x + ',' + $c.y + ' ' + $c.w + 'x' + $c.h) }
$pick=$cands | Where-Object { $_.en -and $_.name -eq '发送' -and $_.w -ge 24 -and $_.w -le 90 -and $_.h -ge 24 -and $_.h -le 90 } | Sort-Object x -Descending | Select-Object -First 1
if(-not $pick){ Log 'SEND_NOT_READY'; throw 'SEND_NOT_READY' }
if([Win32Chat3]::GetForegroundWindow() -ne $h){ throw 'LOST_FOREGROUND_BEFORE_SEND' }
Click-El $pick.el
Start-Sleep -Seconds 2
$root=[System.Windows.Automation.AutomationElement]::FromHandle($h)
$after=Find-Send $root
foreach($c in $after){ Log ('AFTER name=[' + $c.name + '] en=' + $c.en) }
Log 'ATTACH_SCRIPT_DONE'
