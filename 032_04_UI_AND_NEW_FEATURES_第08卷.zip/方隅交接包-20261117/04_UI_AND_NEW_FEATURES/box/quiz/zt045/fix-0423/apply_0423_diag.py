# -*- coding: utf-8 -*-
"""Apply ChatGPT diagnostic patches A-D to GatewaySessionEntry.kt only.
Logs only. Does not change authorization, billing, or runId lifecycle.
"""
from pathlib import Path
import sys

SRC = Path(r"V:\work\original-vs-0419\release-mobile\android\app\src\main\java\com\futureyyy\tijing\payment\GatewaySessionEntry.kt")
BACKUP = Path(r"C:\Users\rmsama\AppData\Local\Temp\zt0423-gpt-pack\backup-0422-src\GatewaySessionEntry-pre-diag.kt")

def main():
    text = SRC.read_text(encoding="utf-8")
    if "fun shortHash(" in text or "exchange-preflight" in text or "run-selection id=" in text:
        print("ALREADY_APPLIED")
        return 0
    if "fun getOrCreateRunId" not in text or 'android.util.Log.i("ZhitiSession","http=$code error=$preview")' not in text:
        print("UNEXPECTED_SOURCE")
        return 2
    BACKUP.parent.mkdir(parents=True, exist_ok=True)
    if not BACKUP.exists():
        BACKUP.write_text(text, encoding="utf-8")
        print("BACKUP=" + str(BACKUP))

    old_imports = "import java.util.UUID\n"
    new_imports = "import java.security.MessageDigest\nimport java.util.UUID\n"
    if old_imports not in text:
        print("IMPORT_ANCHOR_MISSING")
        return 3
    text = text.replace(old_imports, new_imports, 1)

    old_object_open = "object GatewaySessionEntry {\n    private const val ORIGIN="
    new_object_open = (
        "object GatewaySessionEntry {\n"
        "    private fun shortHash(value:String):String =\n"
        "        MessageDigest.getInstance(\"SHA-256\")\n"
        "            .digest(value.toByteArray(Charsets.UTF_8))\n"
        "            .joinToString(\"\") { \"%02x\".format(it) }\n"
        "            .take(12)\n"
        "    private const val ORIGIN="
    )
    if old_object_open not in text:
        print("OBJECT_ANCHOR_MISSING")
        return 4
    text = text.replace(old_object_open, new_object_open, 1)

    old_existing = (
        "        if(existing!=null) {\n"
        "            check(target==targetPackage) { \"上次答题任务尚未结束，请先核对。\" }\n"
        "            val row=PaymentRuntime.get(context).ledger.read(existing)\n"
        "            if(!gatewayFreshStartAllowed(row?.phase,row?.submissionState,saved?.optString(\"state\"))) return@synchronized existing\n"
        "        }\n"
    )
    new_existing = (
        "        if(existing!=null) {\n"
        "            check(target==targetPackage) { \"上次答题任务尚未结束，请先核对。\" }\n"
        "            val row=PaymentRuntime.get(context).ledger.read(existing)\n"
        "            val freshAllowed=gatewayFreshStartAllowed(row?.phase,row?.submissionState,saved?.optString(\"state\"))\n"
        "            android.util.Log.i(\n"
        "                \"ZhitiSession\",\n"
        "                \"run-selection id=${shortHash(existing)} \" +\n"
        "                \"target=$targetPackage \" +\n"
        "                \"ledgerFound=${row != null} \" +\n"
        "                \"phase=${row?.phase ?: \\\"missing\\\"} \" +\n"
        "                \"submission=${row?.submissionState ?: \\\"missing\\\"} \" +\n"
        "                \"savedState=${saved?.optString(\\\"state\\\") ?: \\\"missing\\\"} \" +\n"
        "                \"freshAllowed=$freshAllowed\"\n"
        "            )\n"
        "            if(!freshAllowed) return@synchronized existing\n"
        "        }\n"
    )
    if old_existing not in text:
        print("EXISTING_BRANCH_ANCHOR_MISSING")
        return 5
    text = text.replace(old_existing, new_existing, 1)

    old_create = (
        "        val id=UUID.randomUUID().toString();check(p.edit().putString(\"runId\",id).putString(\"target\",targetPackage).commit()) { \"答题记录未能保存。\" };id\n"
    )
    new_create = (
        "        val id=UUID.randomUUID().toString();check(p.edit().putString(\"runId\",id).putString(\"target\",targetPackage).commit()) { \"答题记录未能保存。\" }\n"
        "        android.util.Log.i(\"ZhitiSession\",\"run-selection id=${shortHash(id)} target=$targetPackage created=true\")\n"
        "        id\n"
    )
    if old_create not in text:
        print("CREATE_BRANCH_ANCHOR_MISSING")
        return 6
    text = text.replace(old_create, new_create, 1)

    old_exchange = (
        "        val runtime=PaymentRuntime.get(app)\n"
        "        val auth=runtime.gatewayAuthorizationOnWorker(runId,targetPackage)\n"
        "        val payload=JSONObject().put(\"runId\",runId).put(\"taskBinding\",auth.binding).put(\"source\",auth.source)\n"
    )
    new_exchange = (
        "        val runtime=PaymentRuntime.get(app)\n"
        "        val auth=runtime.gatewayAuthorizationOnWorker(runId,targetPackage)\n"
        "        val row=runtime.ledger.read(runId)\n"
        "        android.util.Log.i(\n"
        "            \"ZhitiSession\",\n"
        "            \"exchange-preflight id=${shortHash(runId)} \" +\n"
        "            \"target=$targetPackage \" +\n"
        "            \"ledgerFound=${row != null} \" +\n"
        "            \"phase=${row?.phase ?: \\\"missing\\\"} \" +\n"
        "            \"submission=${row?.submissionState ?: \\\"missing\\\"} \" +\n"
        "            \"authSource=${auth.source} \" +\n"
        "            \"bindingPresent=${auth.binding.isNotBlank()} \" +\n"
        "            \"deviceDigestPresent=${!auth.deviceDigest.isNullOrBlank()}\"\n"
        "        )\n"
        "        val payload=JSONObject().put(\"runId\",runId).put(\"taskBinding\",auth.binding).put(\"source\",auth.source)\n"
    )
    if old_exchange not in text:
        print("EXCHANGE_ANCHOR_MISSING")
        return 7
    text = text.replace(old_exchange, new_exchange, 1)

    old_http = '                android.util.Log.i("ZhitiSession","http=$code error=$preview")\n'
    new_http = (
        "                val requestId=sequenceOf(\n"
        "                    c.getHeaderField(\"x-request-id\"),\n"
        "                    c.getHeaderField(\"x-tcb-traceid\"),\n"
        "                    c.getHeaderField(\"x-cloudbase-request-id\"),\n"
        "                    c.getHeaderField(\"trace-id\")\n"
        "                ).firstOrNull { !it.isNullOrBlank() } ?: \"missing\"\n"
        "                android.util.Log.i(\"ZhitiSession\",\"http=$code error=$preview requestId=$requestId\")\n"
    )
    if old_http not in text:
        print("HTTP_LOG_ANCHOR_MISSING")
        return 8
    text = text.replace(old_http, new_http, 1)

    # sanity: no secrets logged as full values
    forbidden = ['token=$', 'runId=$runId', 'taskBinding=$', 'deviceDigest=$auth']
    for f in forbidden:
        if f in text and 'shortHash' in text:
            # token is used in request headers already, just ensure we didn't add log of raw token
            pass
    log_block = text[text.find("exchange-preflight"):text.find("val payload=")]
    if "auth.token" in log_block or "taskBinding=${" in log_block or "deviceDigest=${auth" in log_block:
        print("LEAK_IN_PREFLIGHT")
        return 9

    SRC.write_text(text, encoding="utf-8")
    checks = [
        "fun shortHash(",
        "run-selection id=",
        "exchange-preflight id=",
        "requestId=$requestId",
        "created=true",
    ]
    missing = [c for c in checks if c not in text]
    if missing:
        print("POSTCHECK_MISSING " + ",".join(missing))
        return 10
    print("APPLIED=" + str(SRC))
    print("OK")
    return 0

if __name__ == "__main__":
    sys.exit(main())
