package com.futureyyy.tijing

import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.Looper
import android.util.Base64
import android.util.DisplayMetrics
import android.util.Log
import android.view.WindowManager
import android.widget.Toast
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

class ScreenCaptureService : Service() {
    private data class PendingCapture(
        val callback: (Result<CaptureFrame>) -> Unit,
    )

    private val mainHandler = Handler(Looper.getMainLooper())
    private lateinit var captureThread: HandlerThread
    private lateinit var captureHandler: Handler
    private val projectionRecovery = ProjectionRecovery()
    private var resumeRunnerAfterConsent = false
    private val projectionStarting = AtomicBoolean(false)
    private val legacyFrameAfterStart = AtomicBoolean(false)
    private val frameRequested = AtomicBoolean(false)

    @Volatile
    private var projection: MediaProjection? = null
    private var projectionCallback: MediaProjection.Callback? = null
    @Volatile
    private var virtualDisplay: VirtualDisplay? = null
    private val captureSurface = CaptureSurfaceLease<ImageReader> { reader ->
        runCatching { reader.setOnImageAvailableListener(null, null) }
        runCatching { reader.close() }
    }
    private var frameTimeout: Runnable? = null
    private var captureWidth = 0
    private var captureHeight = 0
    private var pendingCapture: PendingCapture? = null
    private var pendingSessionConfigJson: String? = null

    @Volatile
    private var runtimeConfig: QuizRuntimeConfig? = null
    private var overlayController: OverlayController? = null
    @Volatile
    private var coordinator: QuizRunCoordinator? = null
    @Volatile
    private var sweep: CaptureSweep? = null
    private var activeCaptureGateway: CaptureGateway? = null
    private var activeModelGateway: ModelGateway? = null
    private val ocrDelegate = lazy { OnDeviceQuestionOcr(this) }
    private val onDeviceOcr by ocrDelegate
    private var runnerGeneration = 0L
    private var gestureDispatchGeneration = 0L
    private var activeModelRequest: ModelRequestHandle? = null
    private var activeModelToken: Any? = null
    private class PendingGatewayStart(var explicitStop: Boolean = false)
    private var pendingGatewayStart: PendingGatewayStart? = null
    private var gatewaySession: com.futureyyy.tijing.payment.GatewaySession? = null
    private var gatewayTarget: String? = null
    internal fun currentGatewayTarget(): String? = gatewayTarget
    private var gatewayRunnerStarted = false
    @Volatile
    private var questionBankStore: QuestionBankStore? = null
    private val bankWriteExecutor = java.util.concurrent.Executors.newSingleThreadExecutor { runnable ->
        Thread(runnable, "TiJingBankWrite").apply { isDaemon = true }
    }
    @Volatile
    private var destroyed = false
    @Volatile
    private var terminalStopScheduled = false
    private val terminalStopRunnable = Runnable {
        if (!destroyed) stopSelf()
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
        captureThread = HandlerThread("QuizCapture").also { it.start() }
        captureHandler = Handler(captureThread.looper)
        createNotificationChannel()
        startForegroundCompat()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null) {
            if (projection == null) stopSelfResult(startId)
            return START_NOT_STICKY
        }
        if (intent.action == ACTION_STOP) {
            closeGatewaySession()
            stopSelf()
            return START_NOT_STICKY
        }

        if (intent.action == ACTION_RESTORE_PROJECTION) {
            val id = intent.getStringExtra(EXTRA_RECOVERY_ID)
            val data = projectionData(intent)
            if (id != null && data != null && intent.getIntExtra(EXTRA_RESULT_CODE, 0) == Activity.RESULT_OK &&
                projectionRecovery.approve(id)) {
                startCaptureFromAuthorization(Activity.RESULT_OK, data, false, id)
            }
            if (runtimeConfig == null && projection == null && !projectionStarting.get()) stopSelfResult(startId)
            return START_NOT_STICKY
        }
        if (projectionRecovery.phase != null) {
            showRecoveryControls("请先恢复本次屏幕共享，或关闭浮窗")
            return START_NOT_STICKY
        }
        val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, -1)
        val resultData = projectionData(intent)
        val requestLegacyFrame = intent.getBooleanExtra(EXTRA_REQUEST_FRAME, false)
        if (resultCode == Activity.RESULT_OK && resultData != null) {
            if (projection == null) {
                startCaptureFromAuthorization(resultCode, resultData, requestLegacyFrame)
            } else if (requestLegacyFrame) {
                requestNextFrame()
            }
        }

        intent.getStringExtra(EXTRA_SESSION_CONFIG)
            ?.takeIf { value -> value.isNotBlank() }
            ?.let(::queueRunnerSession)
        return START_NOT_STICKY
    }

    private fun projectionData(intent: Intent): Intent? = if (Build.VERSION.SDK_INT >= 33) {
        intent.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
    } else {
        @Suppress("DEPRECATION") intent.getParcelableExtra<Intent>(EXTRA_RESULT_DATA)
    }

    private fun startCaptureFromAuthorization(resultCode: Int, resultData: Intent, requestLegacyFrame: Boolean, recoveryId: String? = null) {
        if (requestLegacyFrame) legacyFrameAfterStart.set(true)
        if (!projectionStarting.compareAndSet(false, true)) return
        val posted = captureHandler.post {
            try {
                if (projection == null) startCaptureInternal(resultCode, resultData, recoveryId)
                if (projection != null && legacyFrameAfterStart.getAndSet(false)) beginLegacyFrame()
            } finally {
                if (projection == null && legacyFrameAfterStart.getAndSet(false)) deliverLegacyResult("")
                projectionStarting.set(false)
            }
        }
        if (!posted) {
            projectionStarting.set(false)
            if (legacyFrameAfterStart.getAndSet(false)) deliverLegacyResult("")
        }
    }

    private fun startCaptureInternal(resultCode: Int, resultData: Intent, recoveryId: String?) {
        if (projection != null) return
        val manager = getSystemService(MediaProjectionManager::class.java)
        val createdProjection = try {
            manager.getMediaProjection(resultCode, resultData)
        } catch (error: Exception) {
            notifyCaptureSetupFailure(error)
            return
        } ?: run {
            notifyCaptureSetupFailure(IllegalStateException("截图授权创建失败"))
            return
        }
        projection = createdProjection
        val callback = object : MediaProjection.Callback() {
            override fun onStop() {
                if (projection !== createdProjection) return
                releaseCaptureInternal("截图授权已结束", stopProjection = false)
                terminateCaptureSession("截图授权已结束")
            }
        }
        projectionCallback = callback

        try {
            createdProjection.registerCallback(callback, captureHandler)
            val metrics = DisplayMetrics()
            val windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
            @Suppress("DEPRECATION") windowManager.defaultDisplay.getRealMetrics(metrics)
            val width = metrics.widthPixels
            val height = metrics.heightPixels
            require(width > 0 && height > 0) { "屏幕尺寸无效" }
            captureWidth = width
            captureHeight = height
            virtualDisplay = createdProjection.createVirtualDisplay(
                "TiJingCapture",
                width,
                height,
                metrics.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                null,
                null,
                captureHandler,
            ) ?: throw IllegalStateException("虚拟屏幕创建失败")
            if (recoveryId == null) {
                mainHandler.post { maybeStartPendingRunner() }
            } else mainHandler.post {
                if (!destroyed && projectionRecovery.restored(recoveryId)) {
                    showRecoveryControls("屏幕共享已恢复。回到原题页后，点下方按钮继续。")
                }
            }
        } catch (error: Exception) {
            releaseCaptureInternal(error.message ?: "截图能力初始化失败", stopProjection = true)
            notifyCaptureSetupFailure(error)
        }
    }

    fun captureFreshFrame(callback: (Result<CaptureFrame>) -> Unit) {
        val completion = singleCaptureCompletion(callback)
        debugRunnerCapture("fresh-request")
        if (!::captureHandler.isInitialized || destroyed) {
            debugRunnerCapture("fresh-rejected-service-unavailable")
            completion(Result.failure(IllegalStateException("截图服务未运行")))
            return
        }
        val posted = captureHandler.post {
            when {
                projection == null || virtualDisplay == null -> {
                    debugRunnerCapture("fresh-rejected-projection-unavailable")
                    completion(Result.failure(IllegalStateException("截图授权未准备")))
                }
                pendingCapture != null -> {
                    debugRunnerCapture("fresh-rejected-pending")
                    completion(Result.failure(IllegalStateException("已有截图请求正在等待")))
                }
                else -> {
                    pendingCapture = PendingCapture(completion)
                    // The runner enters here after its overlay has been hidden. A new
                    // output queue cannot contain a frame from before that boundary.
                    beginFrameDelivery()
                }
            }
        }
        if (!posted) {
            debugRunnerCapture("fresh-rejected-post")
            completion(Result.failure(IllegalStateException("截图服务已停止")))
        }
    }

    fun requestNextFrame(): Boolean {
        if (!::captureHandler.isInitialized || projection == null || destroyed) return false
        return captureHandler.post {
            if (destroyed || projection == null || virtualDisplay == null) {
                frameRequested.set(false)
                deliverLegacyResult("")
            } else {
                beginLegacyFrame()
            }
        }
    }

    private fun beginLegacyFrame() {
        frameRequested.set(true)
        if (pendingCapture == null && captureSurface.current == null) beginFrameDelivery()
    }

    // A projection owns exactly one virtual display. Attach a fresh surface only
    // for the duration of each request so a static page can produce an initial frame.
    private fun beginFrameDelivery() {
        val display = virtualDisplay ?: return
        clearFrameTimeout()
        try {
            val reader = ImageReader.newInstance(captureWidth, captureHeight, PixelFormat.RGBA_8888, IMAGE_READER_CAPACITY)
            captureSurface.replace(reader) {
                reader.setOnImageAvailableListener({ available ->
                    if (captureSurface.owns(available)) encodeRequestedFrame(available, available.width, available.height)
                }, captureHandler)
                display.surface = reader.surface
            }
            val timeout = Runnable {
                if (captureSurface.owns(reader)) failFrameDelivery("截图超时，请重新授权屏幕共享")
            }
            frameTimeout = timeout
            check(captureHandler.postDelayed(timeout, CAPTURE_TIMEOUT_MS)) { "截图服务已停止" }
        } catch (error: Exception) {
            Log.w(RUNNER_LOG_TAG, "capture-output-setup-failed", error)
            failFrameDelivery("无法获取屏幕画面，请重新授权屏幕共享")
        }
    }

    private fun clearFrameTimeout() {
        frameTimeout?.let(captureHandler::removeCallbacks)
        frameTimeout = null
    }

    private fun finishFrameDelivery() {
        clearFrameTimeout()
        runCatching { virtualDisplay?.surface = null }
        captureSurface.clear()
    }

    private fun failFrameDelivery(message: String) {
        Log.w(RUNNER_LOG_TAG, "capture-output-unavailable")
        releaseCaptureInternal(message, stopProjection = true)
        terminateCaptureSession(message)
    }

    fun isCaptureReady(): Boolean = projection != null && virtualDisplay != null

    fun isSessionRunning(): Boolean =
        !terminalStopScheduled && runtimeConfig != null && (coordinator != null || sweep != null)

    private fun cancelFreshFrame(reason: String = "截图请求已取消") {
        if (!::captureHandler.isInitialized) return
        captureHandler.post {
            if (pendingCapture != null) {
                completePendingCapture(Result.failure(IllegalStateException(reason)))
                if (!frameRequested.get()) finishFrameDelivery()
            }
        }
    }

    private fun encodeRequestedFrame(reader: ImageReader, width: Int, height: Int) {
        val image = try {
            reader.acquireLatestImage()
        } catch (error: Exception) {
            failFrameDelivery("读取屏幕画面失败，请重新授权屏幕共享")
            return
        } ?: run {
            if (pendingCapture != null) debugRunnerCapture("frame-unavailable")
            return
        }
        var paddedBitmap: Bitmap? = null
        var croppedBitmap: Bitmap? = null
        val requestedByRunner = pendingCapture != null
        val requestedByLegacy = frameRequested.get()
        try {
            if (!requestedByRunner && !requestedByLegacy) return
            val plane = image.planes.firstOrNull() ?: throw IllegalStateException("截图像素平面为空")
            val pixelStride = plane.pixelStride
            val rowStride = plane.rowStride
            require(pixelStride > 0 && rowStride >= pixelStride * width) { "截图像素格式无效" }
            val rowPadding = rowStride - pixelStride * width
            paddedBitmap = Bitmap.createBitmap(
                width + rowPadding / pixelStride,
                height,
                Bitmap.Config.ARGB_8888,
            )
            paddedBitmap.copyPixelsFromBuffer(plane.buffer)
            croppedBitmap = Bitmap.createBitmap(paddedBitmap, 0, 0, width, height)
            val pixels = IntArray(width * height)
            croppedBitmap.getPixels(pixels, 0, width, 0, 0, width, height)
            val signature = FrameSignature.fromArgbPixels(width, height, pixels)
            val output = ByteArrayOutputStream()
            check(croppedBitmap.compress(Bitmap.CompressFormat.JPEG, JPEG_QUALITY, output)) {
                "截图编码失败"
            }
            val encoded = Base64.encodeToString(output.toByteArray(), Base64.NO_WRAP)
            val dataUrl = "data:image/jpeg;base64,$encoded"
            if (requestedByRunner) debugRunnerCapture("frame-encoded")
            if (requestedByRunner) {
                val localPng = if (runtimeConfig?.bankFirstAuto == true) ByteArrayOutputStream().use { local ->
                    if (croppedBitmap.compress(Bitmap.CompressFormat.PNG, 0, local)) local.toByteArray() else null
                } else null
                completePendingCapture(Result.success(CaptureFrame(dataUrl, signature, localPng)))
            }
            if (requestedByLegacy) completeLegacyFrame(dataUrl)
        } catch (error: Exception) {
            if (requestedByRunner) debugRunnerCapture("frame-failed=${error.javaClass.simpleName}")
            if (requestedByRunner) completePendingCapture(Result.failure(error))
            if (requestedByLegacy) completeLegacyFrame("")
        } finally {
            if (croppedBitmap !== paddedBitmap) runCatching { croppedBitmap?.recycle() }
            runCatching { paddedBitmap?.recycle() }
            runCatching { image.close() }
            finishFrameDelivery()
        }
    }

    private fun completeLegacyFrame(dataUrl: String) {
        if (frameRequested.compareAndSet(true, false)) deliverLegacyResult(dataUrl)
    }

    private fun deliverLegacyResult(dataUrl: String) {
        mainHandler.post { runCatching { listener?.invoke(dataUrl) } }
    }

    private fun singleCaptureCompletion(
        callback: (Result<CaptureFrame>) -> Unit,
    ): (Result<CaptureFrame>) -> Unit {
        val completed = AtomicBoolean(false)
        return { result ->
            if (completed.compareAndSet(false, true)) {
                mainHandler.post { runCatching { callback(result) } }
            }
        }
    }

    private fun completePendingCapture(result: Result<CaptureFrame>) {
        val pending = pendingCapture ?: return
        pendingCapture = null
        debugRunnerCapture(
            if (result.isSuccess) "fresh-complete=success"
            else "fresh-complete=failure:${result.exceptionOrNull()?.javaClass?.simpleName ?: "Unknown"}",
        )
        pending.callback(result)
    }

    private fun queueRunnerSession(configJson: String) {
        if (terminalStopScheduled) {
            mainHandler.removeCallbacks(terminalStopRunnable)
            terminalStopScheduled = false
            overlayController?.destroy()
            overlayController = null
        }
        pendingSessionConfigJson = configJson
        maybeStartPendingRunner()
    }

    private fun maybeStartPendingRunner() {
        val configJson = pendingSessionConfigJson ?: return
        if (!isCaptureReady()) return
        pendingSessionConfigJson = null
        startRunnerSession(configJson)
    }

    private fun startRunnerSession(configJson: String) {
        if (!isCaptureReady()) {
            pendingSessionConfigJson = configJson
            return
        }
        val config = try {
            QuizRuntimeConfig.fromJson(configJson)
        } catch (_: Exception) {
            notifySessionState(false)
            stopSelf()
            return
        }
        if (coordinator != null || sweep != null || runtimeConfig != null) closeGatewaySession()
        teardownRunner()
        runtimeConfig = config
        gatewayRunnerStarted = false
        val questionBankRepository = if (config.answerSource == QuizAnswerSource.QUESTION_BANK) {
            QuestionBankRepository(this)
        } else {
            null
        }
        questionBankStore = if (config.answerSource == QuizAnswerSource.QUESTION_BANK) {
            QuestionBankStore.get(this).also { store -> bankWriteExecutor.execute { runCatching { store.index } } }
        } else {
            null
        }
        val generation = ++runnerGeneration
        val overlay = OverlayController(this, object : OverlayController.Callbacks {
            override fun onPrimaryAction() {
                overlayController?.collapseToBubble()
                if (runtimeConfig?.mode == QuizMode.CAPTURE) {
                    startSweep(generation)
                } else {
                    startAuthorizedRunner(generation)
                }
            }

            override fun onRetry() {
                recoverRun(generation)
            }

            override fun onPause() {
                if (runtimeConfig?.mode == QuizMode.CAPTURE) stopSweep() else withRunner(generation) { runner -> runner.pause() }
            }

            override fun onResume() = recoverRun(generation)

            override fun onStop() {
                closeGatewaySession()
                if (runtimeConfig?.mode == QuizMode.CAPTURE) {
                    stopSweep()
                } else {
                    mainHandler.post {
                        if (!destroyed && generation == runnerGeneration) stopSelf()
                    }
                }
            }
        })
        overlayController = overlay
        if (config.mode == QuizMode.CAPTURE) overlay.setCaptureMode(true)
        if (!overlay.show()) {
            overlayController = null
            overlay.destroy()
            runtimeConfig = null
            terminateCaptureSession("悬浮窗创建失败，请检查题镜的悬浮窗权限")
            return
        }

        val captureGateway = object : CaptureGateway {
            private var activeCompletion: ((Result<CaptureFrame>) -> Unit)? = null

            override fun capture(callback: (Result<CaptureFrame>) -> Unit) {
                mainHandler.post {
                    debugRunnerCapture("gateway-capture-request")
                    val currentOverlay = overlayController
                    if (destroyed || generation != runnerGeneration || currentOverlay == null) {
                        debugRunnerCapture("gateway-capture-rejected-session")
                        callback(Result.failure(IllegalStateException("运行会话已停止")))
                        return@post
                    }
                    if (activeCompletion != null) {
                        debugRunnerCapture("gateway-capture-rejected-active")
                        callback(Result.failure(IllegalStateException("已有截图流程正在等待")))
                        return@post
                    }
                    val delivered = AtomicBoolean(false)
                    lateinit var completion: (Result<CaptureFrame>) -> Unit
                    completion = { result ->
                        if (delivered.compareAndSet(false, true)) {
                            if (activeCompletion === completion) activeCompletion = null
                            callback(result)
                        }
                    }
                    activeCompletion = completion
                    currentOverlay.hideForCapture {
                        if (activeCompletion !== completion || destroyed || generation != runnerGeneration) return@hideForCapture
                        debugRunnerCapture("gateway-overlay-hidden")
                        captureFreshFrame { result ->
                            if (activeCompletion !== completion) return@captureFreshFrame
                            debugRunnerCapture("gateway-capture-result=${if (result.isSuccess) "success" else "failure"}")
                            currentOverlay.restoreAfterCapture()
                            completion(result)
                        }
                    }
                }
            }

            override fun cancel() {
                val cancelAction = Runnable {
                    overlayController?.restoreAfterCapture()
                    activeCompletion?.invoke(Result.failure(IllegalStateException("截图请求已取消")))
                    cancelFreshFrame()
                }
                if (Looper.myLooper() == Looper.getMainLooper()) cancelAction.run() else mainHandler.post(cancelAction)
            }
        }
        val modelGateway = object : ModelGateway {
            private val concurrentHandles =
                java.util.Collections.synchronizedList(mutableListOf<ModelRequestHandle>())

            override fun analyze(frame: CaptureFrame, questionNo: Int, callback: (Result<String>) -> Unit) {
                request(frame, questionNo, cancelPrevious = true, callback = callback)
            }

            override fun analyzeConcurrent(frame: CaptureFrame, questionNo: Int, callback: (Result<String>) -> Unit) {
                request(frame, questionNo, cancelPrevious = false, callback = callback)
            }

            private fun requestConcurrent(payload: String, deliver: (Result<String>) -> Unit) {
                lateinit var handle: ModelRequestHandle
                handle = ModelClient.requestAsync(payload, connectionCheck = false) { result ->
                    mainHandler.post {
                        if (concurrentHandles.remove(handle)) deliver(result)
                    }
                }
                concurrentHandles.add(handle)
            }

            private fun request(
                frame: CaptureFrame,
                questionNo: Int,
                cancelPrevious: Boolean,
                callback: (Result<String>) -> Unit,
            ) {
                val currentConfig = runtimeConfig
                if (destroyed || generation != runnerGeneration || currentConfig == null) {
                    mainHandler.post { callback(Result.failure(IllegalStateException("运行会话已停止"))) }
                    return
                }
                val payload = JSONObject()
                    .put("endpoint", currentConfig.endpoint)
                    .put("model", currentConfig.model)
                    .put("apiKey", currentConfig.apiKey)
                    .put(
                        "prompt",
                        if (currentConfig.bankFirstAuto) {
                            QuizRuntimeConfig.BANK_SCREEN_PROMPT
                        } else if (currentConfig.answerSource == QuizAnswerSource.QUESTION_BANK) {
                            currentConfig.questionBankPrompt
                        } else {
                            currentConfig.prompt
                        },
                    )
                    .put("timeoutMs", currentConfig.timeoutMs)
                    .put("retryCount", currentConfig.retryCount)
                    .put("questionNo", questionNo)
                    .put("image", frame.dataUrl)
                    .toString()
                val requestToken = Any()
                if (cancelPrevious) {
                    activeModelRequest?.cancel()
                    activeModelToken = requestToken
                }
                debugRunnerGesture("model-request q=$questionNo cancelPrev=$cancelPrevious")

                fun finish(result: Result<String>) {
                    if (cancelPrevious && activeModelToken === requestToken) {
                        activeModelToken = null
                        activeModelRequest = null
                    }
                    callback(result)
                }

                fun dispatch(result: Result<String>) {
                    if (destroyed || generation != runnerGeneration ||
                        (cancelPrevious && activeModelToken !== requestToken)) return
                    debugRunnerGesture("model-result q=$questionNo success=${result.isSuccess}")
                    if (currentConfig.answerSource == QuizAnswerSource.QUESTION_BANK && result.isSuccess) {
                        val index = questionBankRepository?.index
                        val raw = result.getOrNull().orEmpty()
                        if (runCatching { QuestionStemParser.parse(raw) }.getOrNull().isNullOrBlank()) {
                            finish(Result.failure(IllegalStateException("没有读到题干。请让完整题目和选项显示在屏幕上，再点重试。")))
                            return
                        }
                        val bankStatus = index?.let { bankIndex ->
                            runCatching { QuestionBankResponseAdapter.matchStatus(raw, bankIndex) }.getOrNull()
                        }
                        if (index == null || bankStatus == null || QuestionBankResponseAdapter.shouldUseVisionFallback(bankStatus)) {
                            // A bank miss is resolved on the same screenshot with the
                            // regular visual-answer prompt. The next question starts a
                            // fresh bank request because the runtime config stays intact.
                            debugRunnerGesture("bank-vision-fallback q=$questionNo status=${bankStatus ?: "invalid"}")
                            overlayController?.showRecognitionStatus(
                                "题库未命中，正在切换到多模态视觉识别模式",
                                when (bankStatus) {
                                    QuestionBankMatchStatus.AMBIGUOUS -> "匹配不唯一"
                                    QuestionBankMatchStatus.CONFLICT -> "题库答案冲突"
                                    QuestionBankMatchStatus.NOT_FOUND, null -> "题库未命中"
                                    QuestionBankMatchStatus.EXACT -> "精确匹配"
                                    QuestionBankMatchStatus.KEY_PHRASE -> "关键短句匹配"
                                },
                            )
                            val fallbackPayload = JSONObject(payload)
                                .put("prompt", currentConfig.prompt)
                                .toString()
                            val onFallback: (Result<String>) -> Unit = fallback@{ fallbackResult ->
                                if (destroyed || generation != runnerGeneration ||
                                    (cancelPrevious && activeModelToken !== requestToken)) return@fallback
                                debugRunnerGesture("bank-vision-result q=$questionNo success=${fallbackResult.isSuccess}")
                                fallbackResult.getOrNull()?.let(::writeBackFallbackAnswer)
                                finish(fallbackResult.map { recognized ->
                                    runCatching {
                                        JSONObject(recognized)
                                            .put("match_status", "vision_fallback")
                                            .put("match_label", "视觉模型兜底")
                                            .put("answer_source", "vision")
                                            .toString()
                                    }.getOrElse { recognized }
                                })
                            }
                            if (cancelPrevious) {
                                val fallbackRequest = ModelClient.requestAsync(
                                    fallbackPayload,
                                    connectionCheck = false,
                                ) { fallbackResult -> mainHandler.post { onFallback(fallbackResult) } }
                                if (activeModelToken === requestToken) activeModelRequest = fallbackRequest
                            } else {
                                requestConcurrent(fallbackPayload) { fallbackResult -> onFallback(fallbackResult) }
                            }
                            return
                        }
                        val bankJson = runCatching {
                            QuestionBankResponseAdapter.toModelJson(raw, index, questionNo)
                        }
                        if (bankJson.isSuccess) {
                            finish(Result.success(bankJson.getOrThrow()))
                            return
                        }
                    }
                    finish(result)
                }

                if (cancelPrevious) {
                    val request = ModelClient.requestAsync(payload, connectionCheck = false) { result ->
                        mainHandler.post { dispatch(result) }
                    }
                    activeModelRequest = request
                } else {
                    requestConcurrent(payload) { result -> dispatch(result) }
                }
            }

            override fun cancel() {
                val cancelAction = Runnable {
                    activeModelToken = null
                    val request = activeModelRequest
                    activeModelRequest = null
                    request?.cancel()
                    val pending = synchronized(concurrentHandles) { concurrentHandles.toList() }
                    concurrentHandles.clear()
                    pending.forEach { handle -> runCatching { handle.cancel() } }
                }
                if (Looper.myLooper() == Looper.getMainLooper()) cancelAction.run() else mainHandler.post(cancelAction)
            }
        }
        var nodeGestureMode = false
        val gestureGateway = object : GestureGateway {
            private var activeTargetPackage: String? = null

            private fun resolveTargetPackage(service: QuizAccessibilityService): String? {
                val lockedTarget = activeTargetPackage
                if (lockedTarget != null) {
                    return lockedTarget.takeIf(service::isTargetForeground)
                }
                val preferredTarget = config.targetApp.packageName
                    .takeIf { it.isNotBlank() && service.isTargetForeground(it) }
                return (preferredTarget ?: service.foregroundApplicationPackage())
                    ?.also { activeTargetPackage = it }
            }

            override fun isTargetForeground(): Boolean {
                val service = QuizAccessibilityService.instance ?: return false
                return resolveTargetPackage(service) != null
            }

            override fun readQuestionPage(): HostQuestionPage {
                val service = QuizAccessibilityService.instance ?: return HostQuestionPage()
                val targetPackage = resolveTargetPackage(service) ?: return HostQuestionPage()
                return service.readQuestionPage(targetPackage)
            }

            override fun readQuestionStem(): String? {
                val service = QuizAccessibilityService.instance ?: return null
                val target = resolveTargetPackage(service) ?: return null
                return service.readBankQuestion(target, 1)?.question
            }

            override fun continueGradedPage(callback: (Boolean) -> Unit) {
                dispatchGestureAfterAnswer(generation, callback, keepOverlay = nodeGestureMode) { service, completion ->
                    val target = resolveTargetPackage(service)
                    if (target == null) completion(false)
                    else service.continueGradedPage(target, completion)
                }
            }

            override fun continueGradedPage(box: NormalizedBox?, callback: (Boolean) -> Unit) {
                if (box == null) { continueGradedPage(callback); return }
                dispatchGestureAfterAnswer(generation, callback) { service, completion ->
                    val target = resolveTargetPackage(service)
                    if (target == null) completion(false)
                    else service.tapNormalizedAsync(box.centerX / 100f, box.centerY / 100f, target, completion)
                }
            }

            override fun isFinishedPage(): Boolean {
                val service = QuizAccessibilityService.instance ?: return false
                val targetPackage = resolveTargetPackage(service) ?: return false
                return service.isFinishedPage(targetPackage)
            }

            override fun targetUnavailableMessage(): String = "请保持题目页在前台"

            override fun resetTarget() {
                nodeGestureMode = false
                activeTargetPackage = null
            }

            override fun tap(option: QuizOption, callback: (Boolean) -> Unit) {
                nodeGestureMode = option.screenRow
                dispatchGestureAfterAnswer(generation, callback, keepOverlay = nodeGestureMode) { service, completion ->
                    val targetPackage = resolveTargetPackage(service)
                    if (targetPackage == null) {
                        completion(false)
                    } else if (config.bankFirstAuto && !option.screenRow) {
                        tapCurrentOption(service, targetPackage, generation, option, completion)
                    } else {
                        service.tapOption(option, targetPackage, completion)
                    }
                }
            }

            override fun tapConfirm(box: NormalizedBox?, callback: (Boolean) -> Unit) {
                dispatchGestureAfterAnswer(
                    generation = generation,
                    callback = callback,
                    settleDelayMs = CONFIRM_SETTLE_DELAY_MS,
                ) { service, completion ->
                    val targetPackage = resolveTargetPackage(service)
                    if (targetPackage == null) {
                        completion(false)
                        return@dispatchGestureAfterAnswer
                    }
                    service.tapSubmit(targetPackage, completion) {
                        confirmFromCurrentFrame(service, targetPackage, generation, completion)
                    }
                }
            }

            override fun cancel() {
                val cancelAction = Runnable {
                    gestureDispatchGeneration += 1
                    overlayController?.cancelPendingGestureAction()
                    QuizAccessibilityService.instance?.cancelGestures()
                }
                if (Looper.myLooper() == Looper.getMainLooper()) cancelAction.run() else mainHandler.post(cancelAction)
            }
        }
        val listener = object : RunnerListener {
            override fun onSnapshot(snapshot: RunnerSnapshot) {
                mainHandler.post {
                    if (!destroyed && generation == runnerGeneration) {
                        debugRunnerGesture("snapshot phase=${snapshot.phase} q=${snapshot.questionNo}")
                        overlayController?.update(snapshot)
                    }
                }
            }

            override fun onAnswer(result: QuizModelResult) {
                mainHandler.post {
                    if (!destroyed && generation == runnerGeneration) {
                        overlayController?.showAnswer(
                            result,
                            autoCollapse = config.answerSource == QuizAnswerSource.VISION && config.mode == QuizMode.AUTO,
                        )
                    }
                }
            }

            override fun onCompleted() {
                mainHandler.post {
                    if (!destroyed && generation == runnerGeneration) {
                        // Only the coordinator's explicit host-result completion reaches here.
                        closeGatewaySession { result ->
                            if (!destroyed && generation == runnerGeneration) {
                                if (result.isFailure) android.widget.Toast.makeText(this@ScreenCaptureService,"本轮已完成，结束状态待核对，请在支付页核对付款状态。",android.widget.Toast.LENGTH_LONG).show()
                                notifySessionState(false)
                                stopSelf()
                            }
                        }
                    }
                }
            }

            override fun onError(message: String) {
                mainHandler.post {
                    if (!destroyed && generation == runnerGeneration) overlayController?.showError(message)
                }
            }
        }
        val scheduler = RunnerScheduler { delayMs, action ->
            val task = Runnable {
                if (!destroyed && generation == runnerGeneration) action()
            }
            mainHandler.postDelayed(task, delayMs)
            RunnerScheduledTask { mainHandler.removeCallbacks(task) }
        }
        activeCaptureGateway = captureGateway
        activeModelGateway = modelGateway
        if (config.mode == QuizMode.CAPTURE) {
            sweep = null
            overlay.updateSweepState(false, 0)
        } else {
            val newCoordinator = QuizRunCoordinator(
                mode = if (config.answerSource == QuizAnswerSource.QUESTION_BANK) QuizMode.MANUAL else config.mode,
                captureGateway = captureGateway,
                modelGateway = modelGateway,
                gestureGateway = gestureGateway,
                listener = listener,
                scheduler = scheduler,
                screenBankAnswer = { number ->
                    val service = QuizAccessibilityService.instance
                    val target = gatewayTarget
                    val expiresAt = gatewaySession?.expiresAt ?: 0L
                    if (config.answerSource == QuizAnswerSource.VISION && gatewayRunnerStarted &&
                        expiresAt > System.currentTimeMillis() && service != null && !target.isNullOrBlank()
                    ) {
                        service.readBankQuestion(target, number)?.let { screen ->
                            val index = QuestionBankStore.get(this).index
                            if (config.bankFirstAuto) index.verifiedAnswer(screen)
                            else index.answerForScreen(screen)
                        }?.also { Log.i("ZhitiBank", "no=$number source=screen_bank final=${it.answerIndices}") }
                    } else null
                },
                requireBankMatch = config.bankFirstAuto,
                answerResolver = if (config.answerSource == QuizAnswerSource.VISION) visionBankResolver(config) else { it -> it },
            )
            if (config.bankFirstAuto) {
                newCoordinator.bankFirstFallback = true
                val allowance = FallbackAllowance(getSharedPreferences("bank-first-allowance", MODE_PRIVATE))
                newCoordinator.reserveFallback = { number, stem -> allowance.reserve(gatewaySession?.runId, number, stem) }
                newCoordinator.frameReader = { frame, number, done ->
                    val phase = newCoordinator.snapshot().phase
                    val recognizing = phase == RunnerPhase.RECOGNIZING
                    fun live() = !destroyed && generation == runnerGeneration && gatewayRunnerStarted &&
                        (gatewaySession?.expiresAt ?: 0L) > System.currentTimeMillis()
                    fun read(lines: List<VisibleQuestionReader.Node>): QuizRunCoordinator.LocalRead {
                        val host = OcrHostPage.read(lines)
                        val page = onDeviceOcr.pageFromLines(lines, number)
                        val verified = if (live() && !host.result && !host.page.graded) {
                            runCatching {
                                val index = QuestionBankStore.get(this).index
                                (page?.let { runCatching { index.verifiedAnswer(it) }.getOrNull() } ?: index.verifiedOcrPage(lines, number))?.copy(matchSource = "device_ocr")
                            }.getOrNull()
                        } else null
                        return QuizRunCoordinator.LocalRead(host, verified ?: page, verified, lines)
                    }
                    fun deliver(value: QuizRunCoordinator.LocalRead) {
                        if (destroyed || generation != runnerGeneration) return
                        if (recognizing && value.verified != null) Log.i("ZhitiBank", "no=$number source=local_ocr_bank")
                        done(value)
                    }
                    onDeviceOcr.readLines(frame) { lines ->
                        val first = read(lines)
                        // A graded page still needs a readable continuation control. The
                        // second reader must also cover this phase, not only new questions.
                        val missingContinuation = first.host.needsContinuationRead(phase == RunnerPhase.WAITING_PAGE_CHANGE)
                        if (!live() || first.host.result || lines.isEmpty() ||
                            !missingContinuation && (!recognizing || first.verified != null || first.host.page.graded)) {
                            deliver(first)
                        } else onDeviceOcr.readIndependent(frame, lines) { secondLines ->
                            val second = read(secondLines)
                            // Both reads refer to this same captured image. Each is checked as a whole.
                            val compatibleProgress = first.host.page.progress == null || second.host.page.progress == null ||
                                second.host.page.progress == first.host.page.progress
                            val completeSecond = second.verified != null || second.host.page.graded &&
                                (!missingContinuation || second.host.nextBox != null)
                            if (second.host.result || compatibleProgress && completeSecond) deliver(second)
                            else deliver(first.copy(independentLines = secondLines))
                        }
                    }
                }
            }
            coordinator = newCoordinator
            overlay.update(newCoordinator.snapshot())
        }
    }

    private fun startSweep(generation: Long) {
        val overlay = overlayController ?: return
        val capture = activeCaptureGateway ?: return
        val model = activeModelGateway ?: return
        val config = runtimeConfig ?: return
        sweep?.stop()
        val sweepScheduler = RunnerScheduler { delayMs, action ->
            val task = Runnable { if (!destroyed && generation == runnerGeneration) action() }
            mainHandler.postDelayed(task, delayMs)
            RunnerScheduledTask { mainHandler.removeCallbacks(task) }
        }
        val newSweep = CaptureSweep(
            captureGateway = capture,
            modelGateway = model,
            tapNext = { callback -> tapNextMarker(generation, callback) },
            scheduler = sweepScheduler,
            startingQuestionNo = config.startingQuestionNo,
            settleDelayMs = SWEEP_SETTLE_DELAY_MS,
            listener = object : CaptureSweepListener {
                override fun onProgress(questionNo: Int, recognized: Int, pending: Int) {
                    mainHandler.post {
                        if (!destroyed && generation == runnerGeneration) {
                            overlayController?.updateSweepState(true, recognized, pending)
                        }
                    }
                }

                override fun onFinished(answers: List<SweptAnswer>) {
                    mainHandler.post {
                        if (!destroyed && generation == runnerGeneration) {
                            overlayController?.updateSweepState(false, answers.size)
                            overlayController?.showOverview(answers)
                        }
                    }
                }
            },
        )
        sweep = newSweep
        overlay.updateSweepState(true, 0)
        newSweep.start()
        notifySessionState(true)
    }

    private fun stopSweep() {
        sweep?.stop()
    }

    private fun tapNextMarker(generation: Long, callback: (Boolean) -> Unit) {
        val overlay = overlayController
        val coords = overlay?.markerNormalized()
        if (overlay == null || coords == null) {
            callback(false)
            return
        }
        overlay.tapMarker {
            mainHandler.post {
                // The user may stop during the marker-hide delay; never tap after that.
                if (destroyed || generation != runnerGeneration || sweep?.isRunning != true) {
                    callback(false)
                    return@post
                }
                val service = QuizAccessibilityService.instance
                val targetPackage = service?.foregroundApplicationPackage()
                if (service == null || targetPackage.isNullOrBlank()) {
                    callback(false)
                    return@post
                }
                service.tapNormalizedAsync(coords.first, coords.second, targetPackage) { success ->
                    mainHandler.post { callback(success) }
                }
            }
        }
    }

    /** Never replay the recognition coordinates on a changed choice layout. Multi-select rows can move. */
    private fun tapCurrentOption(service: QuizAccessibilityService, target: String, generation: Long,
                                 option: QuizOption, done: (Boolean) -> Unit) {
        val runner = coordinator ?: return done(false)
        val expected = runner.currentAnswer() ?: return done(false)
        val source = runner.questionFrameSignature()
        val epoch = gestureDispatchGeneration
        fun live() = !destroyed && generation == runnerGeneration && epoch == gestureDispatchGeneration &&
            projectionRecovery.phase == null && QuizAccessibilityService.instance === service && service.isTargetForeground(target)
        if (!live()) return done(false)
        captureFreshFrame { result ->
            val frame = result.getOrNull()
            if (frame == null || !live()) { done(false); return@captureFreshFrame }
            if (frame.signature == source && expected.matchSource == "device_ocr" && option.box != null) {
                service.tapOption(option, target, done)
                return@captureFreshFrame
            }
            fun locate(lines: List<VisibleQuestionReader.Node>, allowIndependent: Boolean) {
                if (!live()) return done(false)
                val no = expected.questionNo ?: 1
                val read = onDeviceOcr.pageFromLines(lines, no)
                val host = OcrHostPage.read(lines)
                val original = runner.startingHostProgress()
                if (host.result || host.page.graded || (host.page.progress != null && original != null && original != host.page.progress)) {
                    return done(false)
                }
                val samePage = frame.signature == source || original != null && original == host.page.progress ||
                    OcrHostPage.containsStem(lines, expected.question)
                val rows = if (samePage) OcrHostPage.optionRows(lines, expected.options) else null
                val box = rows?.getOrNull(option.index) ?: OcrHostPage.freshOption(expected, option, read) ?:
                    OcrHostPage.freshOption(expected, option, QuestionBankStore.get(this).index.verifiedOcrPage(lines, no))
                if (box == null) {
                    if (allowIndependent && lines.isNotEmpty()) onDeviceOcr.readIndependent(frame, lines) { locate(it, false) }
                    else done(false)
                    return
                }
                captureFreshFrame verify@{ latest ->
                    if (!live() || latest.getOrNull()?.signature != frame.signature) { done(false); return@verify }
                    service.tapOption(option.copy(box = box), target, done)
                }
            }
            onDeviceOcr.readLines(frame) { locate(it, true) }
        }
    }

    /** An option tap can enable or move the submit button. Read the frame after that tap. */
    private fun confirmFromCurrentFrame(service: QuizAccessibilityService, target: String, generation: Long,
                                        done: (Boolean) -> Unit, beforeScroll: Map<Int,Float>? = null) {
        val epoch = gestureDispatchGeneration
        val answer = coordinator?.currentAnswer() ?: return done(false)
        fun live() = !destroyed && generation == runnerGeneration && epoch == gestureDispatchGeneration &&
            projectionRecovery.phase == null && QuizAccessibilityService.instance === service && service.isTargetForeground(target)
        if (!live()) return done(false)
        val before = service.readQuestionPage(target)
        val originalProgress = coordinator?.startingHostProgress() ?: before.progress
        if (before.graded || service.isFinishedPage(target)) return done(true)
        captureFreshFrame { result ->
            val frame = result.getOrNull()
            if (frame == null || !live()) { done(false); return@captureFreshFrame }
            fun assess(lines:List<VisibleQuestionReader.Node>, canReread:Boolean, originalLines:List<VisibleQuestionReader.Node> = lines) {
                if (!live()) { done(false); return }
                val page = OcrHostPage.read(lines)
                val now = service.readQuestionPage(target)
                val currentProgress = now.progress ?: page.page.progress
                val next = originalProgress?.let { HostQuestionProgress(it.current + 1, it.total) }
                if (now.graded || page.page.graded || page.result || next != null && currentProgress == next) {
                    done(true)
                    return
                }
                val button = OcrHostPage.confirmBox(lines)
                if (button == null && canReread && lines.isNotEmpty()) {
                    onDeviceOcr.readIndependent(frame, lines) { independent ->
                        if (live()) assess(independent.ifEmpty { lines }, false, lines) else done(false)
                    }
                    return
                }
                val numbered = originalProgress != null && originalProgress == currentProgress
                if (originalProgress != null && currentProgress != null && currentProgress != originalProgress) {
                    done(false); return
                }
                val rows = if (button == null || !numbered) OcrHostPage.optionRows(lines, answer.options) else null
                val anchors = if (button == null || beforeScroll != null) listOf(lines, originalLines).map { ConfirmContinuity.anchors(it, answer.options) }.maxBy { it.size } else emptyMap()
                val firstRow = rows?.firstOrNull() ?: answer.options.firstOrNull()?.box
                val hasStem = numbered || OcrHostPage.containsStem(lines, answer.question) ||
                    firstRow != null && OcrHostPage.matchesCloudStem(lines, answer.question, firstRow)
                // Only reveal an off-screen control after seeing this very question and its last
                // choice at the bottom. Re-read the real label and page after a single swipe.
                val bottomChoice = (anchors[answer.options.lastIndex] ?: rows?.lastOrNull()?.centerY ?: 0f) >= 75f
                debugRunnerGesture("confirm-live page=${currentProgress?.current} original=${originalProgress?.current} same=$hasStem button=${button!=null} anchors=${anchors.size} bottom=$bottomChoice scrolled=${beforeScroll!=null}")
                if (button == null && beforeScroll == null && hasStem && bottomChoice) {
                    val queued = service.scrollTargetForward(target) { ok ->
                        if (!ok || !live()) done(false) else mainHandler.postDelayed({
                            if (live()) confirmFromCurrentFrame(service, target, generation, done, beforeScroll = anchors) else done(false)
                        }, ConfirmReveal.SCROLL_DELAY_MS)
                    }
                    if (!queued) done(false)
                    return
                }
                // Scrolling can move the header off screen. Only accept this case when a complete,
                // distinctive set of choice texts is still present in order on the new frame.
                val retainedChoices = ConfirmContinuity.followedScroll(beforeScroll, anchors)
                if (button == null || (!hasStem && !retainedChoices)) {
                    done(false)
                    return
                }
                // OCR can finish after an automatic transition. Never reuse its position on a changed screen.
                captureFreshFrame verify@{ latest ->
                    if (!live() || latest.getOrNull()?.signature != frame.signature) { done(false); return@verify }
                    service.tapNormalizedAsync(button.centerX / 100f, button.centerY / 100f, target, done)
                }
            }
            onDeviceOcr.readLines(frame) { lines -> assess(lines,true) }
        }
    }

    private fun withRunner(generation: Long, action: (QuizRunCoordinator) -> Unit) {
        mainHandler.post {
            if (!destroyed && generation == runnerGeneration && projectionRecovery.phase == null && isCaptureReady()) {
                coordinator?.let(action)
            }
        }
    }

    private fun dispatchGestureAfterAnswer(
        generation: Long,
        callback: (Boolean) -> Unit,
        settleDelayMs: Long = 0L,
        keepOverlay: Boolean = false,
        dispatch: (QuizAccessibilityService, (Boolean) -> Unit) -> Unit,
    ) {
        val completed = AtomicBoolean(false)
        var hiddenForGesture = false
        val finish: (Boolean) -> Unit = { succeeded ->
            if (completed.compareAndSet(false, true)) {
                if (hiddenForGesture) {
                    hiddenForGesture = false
                    overlayController?.restoreAfterCapture()
                }
                debugRunnerGesture("callback success=$succeeded")
                callback(succeeded)
            }
        }
        mainHandler.post {
            if (destroyed || generation != runnerGeneration) {
                debugRunnerGesture("rejected-stale-run")
                finish(false)
                return@post
            }
            val dispatchGeneration = gestureDispatchGeneration
            val runGesture = runGesture@{
                if (
                    destroyed || generation != runnerGeneration ||
                    dispatchGeneration != gestureDispatchGeneration
                ) {
                    debugRunnerGesture("rejected-stale-dispatch")
                    finish(false)
                    return@runGesture
                }
                val service = QuizAccessibilityService.instance
                if (service == null) {
                    debugRunnerGesture("rejected-service-missing")
                    finish(false)
                    return@runGesture
                }
                try {
                    debugRunnerGesture("dispatching settleDelayMs=$settleDelayMs")
                    dispatch(service) { succeeded -> mainHandler.post { finish(succeeded) } }
                } catch (error: Exception) {
                    debugRunnerGesture("dispatch-exception=${error.javaClass.simpleName}")
                    finish(false)
                }
            }
            val dispatchAfterHidden: () -> Unit = {
                if (settleDelayMs > 0L) {
                    mainHandler.postDelayed(runGesture, settleDelayMs)
                } else {
                    runGesture()
                }
                Unit
            }
            val hideThenDispatch: () -> Unit = {
                val overlay = overlayController
                if (overlay == null || keepOverlay) {
                    debugRunnerGesture("dispatch-without-hiding")
                    dispatchAfterHidden()
                } else {
                    // Accessibility gestures hit the top window. Hide the expanded
                    // floating panel so it cannot swallow option or confirm taps.
                    debugRunnerGesture("waiting-for-overlay-hidden")
                    hiddenForGesture = true
                    overlay.hideForCapture {
                        if (!completed.get()) dispatchAfterHidden()
                    }
                }
                Unit
            }
            debugRunnerGesture("waiting-for-overlay-collapse")
            overlayController?.runAfterAnswerCollapsed(hideThenDispatch) ?: hideThenDispatch()
        }
    }

    internal fun blocksGesture(bounds: android.graphics.Rect): Boolean =
        overlayController?.blocksGesture(bounds) == true

    private fun visionBankResolver(config: QuizRuntimeConfig): (QuizModelResult) -> QuizModelResult {
        val store = QuestionBankStore.get(this).also { bankWriteExecutor.execute { runCatching { it.index } } }
        return resolve@{ ai ->
            if (config.bankFirstAuto) {
                val matched = store.index.verifiedAnswer(ai).copy(matchSource = ai.matchSource)
                Log.i("ZhitiBank", "no=${ai.questionNo} source=visual_then_bank")
                return@resolve matched
            }
            if (config.mode == QuizMode.AUTO) store.index.requireCompleteVisionOptions(ai)
            val bank = store.index.answerForVision(ai)
            val resolved = bank ?: LocalArithmeticAssist.answerForVision(ai)
            Log.i("ZhitiBank", "no=${ai.questionNo} hit=${resolved != null} source=${resolved?.answerSource} ai=${ai.answerIndices} final=${resolved?.answerIndices}")
            resolved ?: ai
        }
    }

    private fun writeBackFallbackAnswer(raw: String) {
        val store = questionBankStore ?: return
        val parsed = runCatching { QuizModelParser.parse(raw) }.getOrNull() ?: return
        if (parsed.question.isBlank()) return
        if (parsed.answerIndices.isEmpty() && parsed.answerText.isNullOrBlank()) return
        // Serialising the whole bank and rebuilding the match index must stay off the main
        // thread, otherwise each write-back stalls the capture loop for hundreds of ms.
        bankWriteExecutor.execute {
            runCatching {
                store.writeBackFallback(
                    question = parsed.question,
                    type = parsed.type,
                    options = parsed.options,
                    answerIndices = parsed.answerIndices,
                    answerText = parsed.answerText.orEmpty(),
                )
                store.index
            }
        }
    }

    private fun debugRunnerGesture(event: String) {
        if (BuildConfig.DEBUG) Log.i(RUNNER_LOG_TAG, "gesture-$event")
    }

    private fun debugRunnerCapture(event: String) {
        if (BuildConfig.DEBUG) Log.i(RUNNER_LOG_TAG, "capture-$event")
    }

    private fun recoverRun(generation: Long) {
        // 所有恢复操作统一在主线程执行。
        if (Looper.myLooper() != Looper.getMainLooper()) {
            mainHandler.post { recoverRun(generation) }
            return
        }
        if (destroyed || generation != runnerGeneration) return
        val overlay = overlayController ?: return
        if (projectionRecovery.phase != null) {
            overlay.showRecognitionStatus("屏幕共享正在恢复，请稍候。")
            return
        }
        if (!isCaptureReady()) {
            overlay.showError("屏幕共享尚未准备好，请重新授权后再试。")
            return
        }
        // 权限核对正在进行时，不重复提交请求。
        if (pendingGatewayStart != null) {
            overlay.showRecognitionStatus("正在核对本轮答题权限，请稍候。")
            return
        }
        // 首次启动失败时，允许从悬浮窗重新发起启动流程。
        if (!gatewayRunnerStarted) {
            overlay.showRecognitionStatus("正在重新检查答题页面和本轮权限。")
            startAuthorizedRunner(generation)
            return
        }
        val session = gatewaySession
        val target = gatewayTarget
        if (session == null || session.expiresAt <= System.currentTimeMillis()) {
            overlay.showError("本轮使用时间已到，请结束本轮后重新开始。")
            return
        }
        val accessibility = QuizAccessibilityService.instance
        if (target.isNullOrBlank() || accessibility?.isTargetForeground(target) != true) {
            overlay.showError("请切回本次答题时使用的原题目页面，再点重试或继续。")
            return
        }
        val runner = coordinator
        if (runner == null) {
            overlay.showError("答题引擎尚未就绪，请结束本轮后重新开始。")
            return
        }
        val currentPhase = runner.snapshot().phase
        if (currentPhase != RunnerPhase.PAUSED_ERROR) {
            overlay.showError("当前答题任务不处于暂停状态，请检查页面；如无法恢复，请结束本轮后重新开始。")
            return
        }
        // 只有确认是可恢复的暂停状态，才执行真正的重试。
        overlay.dismissRunError()
        runner.retry()
    }

    /**
     * In-app start already created the overlay session. Once a host page is
     * in front, reuse the overlay primary action so answering starts on the
     * same path as the floating "开始答题" button.
     */
    private fun notifySessionError(message: String) {
        mainHandler.post { runCatching { sessionErrorListener?.invoke(message) } }
    }

    private fun safeGatewayErrorMessage(error: Throwable): String {
        val causes = generateSequence(error) { it.cause }.toList()
        return if (causes.any { it is java.io.IOException }) {
            "网络暂时无法连接答题授权服务，请检查网络后重试。"
        } else {
            "本轮答题授权暂未确认，请保留本次任务，稍后重试。"
        }
    }

    /** Acquire only at the user's actual start on a verified foreground target. */
    private fun startAuthorizedRunner(generation: Long) {
        if (destroyed || generation != runnerGeneration || pendingGatewayStart != null ||
            projectionRecovery.phase != null || !isCaptureReady()) return
        val accessibility = QuizAccessibilityService.instance
        val target = accessibility?.foregroundApplicationPackage()
        if (target.isNullOrBlank() || accessibility?.isTargetForeground(target) != true) {
            overlayController?.showError("请先打开题目页，再开始答题")
            return
        }
        val existing = gatewaySession
        if (existing != null) {
            if (gatewayTarget != target || existing.expiresAt <= System.currentTimeMillis()) {
                overlayController?.showError("请回到本次答题页面，或结束后重新开始")
                return
            }
            gatewayRunnerStarted = true
            overlayController?.collapseToBubble()
            withRunner(generation) { it.onPrimaryAction() }
            notifySessionState(true)
            return
        }
        val runId = try {
            com.futureyyy.tijing.payment.GatewaySessionEntry.getOrCreateRunId(this, target)
        } catch (error: Exception) {
            Log.w(RUNNER_LOG_TAG, "gateway-run-id-failed", error)
            overlayController?.showError(safeGatewayErrorMessage(error))
            return
        }
        val pending = PendingGatewayStart()
        pendingGatewayStart = pending
        overlayController?.showRecognitionStatus("正在核对本轮答题权限，请保持题目页打开。")
        com.futureyyy.tijing.payment.GatewaySessionEntry.begin(this, runId, target) { result ->
            if (pendingGatewayStart === pending) pendingGatewayStart = null
            if (pending.explicitStop) {
                result.fold(
                    onSuccess = { com.futureyyy.tijing.payment.GatewaySessionEntry.close(this, it) {} },
                    onFailure = { com.futureyyy.tijing.payment.GatewaySessionEntry.closePending(this) {} },
                )
                return@begin
            }
            if (destroyed || generation != runnerGeneration) return@begin
            result.fold(onSuccess = { session ->
                gatewaySession = session
                gatewayTarget = target
                val current = runtimeConfig
                if (current == null) return@fold
                runtimeConfig = current.copy(endpoint = session.endpoint, model = session.model, apiKey = session.apiKey)
                if (projectionRecovery.phase != null || !isCaptureReady()) return@fold
                if (QuizAccessibilityService.instance?.isTargetForeground(target) != true) {
                    overlayController?.showError("请回到本次答题页面，再开始答题")
                    return@fold
                }
                gatewayRunnerStarted = true
                overlayController?.collapseToBubble()
                withRunner(generation) { it.onPrimaryAction() }
                notifySessionState(true)
            }, onFailure = { error ->
                Log.w(RUNNER_LOG_TAG, "gateway-session-begin-failed", error)
                val message = safeGatewayErrorMessage(error)
                overlayController?.showError(message)
                notifySessionError(message)
                notifySessionState(false)
            })
        }
    }

    /** Explicit stop closes the grant; unexpected process death leaves the same run recoverable. */
    fun closeGatewaySession(done:(Result<Unit>)->Unit = {}) {
        val pending = pendingGatewayStart
        if (pending != null) {
            pending.explicitStop = true
            return
        }
        val session = gatewaySession
        gatewaySession = null
        gatewayTarget = null
        if (session != null) com.futureyyy.tijing.payment.GatewaySessionEntry.close(this, session, done)
        else com.futureyyy.tijing.payment.GatewaySessionEntry.closePending(this, done)
    }

    private fun teardownRunner() {
        val wasRunning = coordinator != null || sweep != null || runtimeConfig != null
        runnerGeneration += 1
        val currentCoordinator = coordinator
        coordinator = null
        currentCoordinator?.stop()
        val currentSweep = sweep
        sweep = null
        currentSweep?.stop()
        activeCaptureGateway = null
        activeModelGateway = null
        activeModelToken = null
        activeModelRequest?.cancel()
        activeModelRequest = null
        val currentOverlay = overlayController
        overlayController = null
        currentOverlay?.destroy()
        runtimeConfig = null
        questionBankStore = null
        if (wasRunning) notifySessionState(false)
    }

    private fun notifySessionState(running: Boolean) {
        mainHandler.post { runCatching { sessionStateListener?.invoke(running) } }
    }

    private fun notifyCaptureSetupFailure(error: Throwable) {
        val detail = error.message?.takeIf { it.isNotBlank() }
        val message = if (detail == null || detail == "截图能力初始化失败") {
            "截图能力初始化失败"
        } else {
            "截图能力初始化失败：${detail.take(120)}"
        }
        terminateCaptureSession(message)
    }

    private fun projectionConsentIntent(id: String) =
        Intent(this, MainActivity::class.java).setAction(ACTION_RESTORE_PROJECTION)
            .putExtra(EXTRA_RECOVERY_ID, id)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)

    private fun updateProjectionNotification() {
        runCatching { getSystemService(NotificationManager::class.java).notify(NOTIFICATION_ID, buildNotification()) }
    }

    fun openProjectionConsent(id: String?): Boolean {
        if (destroyed || !projectionRecovery.open(id)) return false
        overlayController?.hideProjectionConsentCard()
        return true
    }

    fun cancelProjectionConsent(id: String?) {
        if (!destroyed && projectionRecovery.cancel(id)) {
            showRecoveryControls("未授权屏幕共享。本次任务已暂停，可以重新授权。")
        }
    }

    private fun showRecoveryControls(message: String): Boolean {
        val id = projectionRecovery.challenge ?: return false
        val phase = projectionRecovery.phase
        if (phase != ProjectionRecovery.Phase.READY && phase != ProjectionRecovery.Phase.NEEDS_CONSENT) return true
        val ready = phase == ProjectionRecovery.Phase.READY
        return overlayController?.showProjectionRecovery(message, if (ready) "回到原题后继续" else "重新授权屏幕", next@{
            if (destroyed || projectionRecovery.challenge != id || phase != projectionRecovery.phase) return@next
            if (!ready) {
                try {
                    startActivity(projectionConsentIntent(id))
                } catch (_: Exception) {
                    Toast.makeText(this, "请从通知进入知题，重新授权屏幕", Toast.LENGTH_LONG).show()
                }
                return@next
            }
            val target = gatewayTarget
            if (target != null && QuizAccessibilityService.instance?.isTargetForeground(target) != true) {
                showRecoveryControls("请先切回本次答题页面，再点继续。")
                return@next
            }
            if (resumeRunnerAfterConsent && (gatewaySession?.expiresAt ?: 0L) <= System.currentTimeMillis()) {
                showRecoveryControls("本次答题授权已到期，请关闭浮窗并回到知题核对任务。")
                return@next
            }
            projectionRecovery.clear()
            updateProjectionNotification()
            overlayController?.finishProjectionRecovery()
            if (resumeRunnerAfterConsent) coordinator?.resumeAfterScreenAuthorization()
            resumeRunnerAfterConsent = false
            notifySessionState(true)
        }, close = {
            // Dismiss only this overlay/service. Its persisted paid run can be recovered from home.
            projectionRecovery.clear()
            stopSelf()
        }) == true
    }

    private fun terminateCaptureSession(message: String) {
        mainHandler.post {
            if (destroyed || terminalStopScheduled) return@post
            if (runtimeConfig != null && overlayController != null) {
                if (projectionRecovery.phase == null) {
                    val phase = coordinator?.snapshot()?.phase
                    resumeRunnerAfterConsent = gatewayRunnerStarted && phase != null &&
                        phase != RunnerPhase.READY && phase != RunnerPhase.STOPPED
                    if (resumeRunnerAfterConsent) coordinator?.pause()
                    sweep?.stop()
                }
                projectionRecovery.lost()
                updateProjectionNotification()
                if (showRecoveryControls(message)) return@post
            }
            terminalStopScheduled = true
            pendingSessionConfigJson = null
            runnerGeneration += 1
            val terminalCoordinator = coordinator
            coordinator = null
            val terminalSweep = sweep
            sweep = null
            runtimeConfig = null
            questionBankStore = null
            terminalCoordinator?.stop()
            terminalSweep?.stop()
            activeCaptureGateway = null
            activeModelGateway = null
            activeModelToken = null
            activeModelRequest?.cancel()
            activeModelRequest = null
            notifySessionState(false)
            overlayController?.showError(message)
            Toast.makeText(this, "$message，请回到知题重新启用", Toast.LENGTH_LONG).show()
            mainHandler.postDelayed(terminalStopRunnable, TERMINAL_MESSAGE_DELAY_MS)
        }
    }

    private fun startForegroundCompat() {
        val notification = buildNotification()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT < 26) return
        val manager = getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(
            NotificationChannel(
                CHANNEL_ID,
                getString(R.string.foreground_service_channel),
                NotificationManager.IMPORTANCE_LOW,
            ),
        )
    }

    private fun buildNotification(): Notification {
        val recoveryId = projectionRecovery.challenge
        val openApp = recoveryId?.let(::projectionConsentIntent) ?: Intent(this, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        val contentIntent = PendingIntent.getActivity(
            this,
            0,
            openApp,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val stopIntent = PendingIntent.getService(
            this,
            1,
            Intent(this, ScreenCaptureService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val builder = if (Build.VERSION.SDK_INT >= 26) {
            Notification.Builder(this, CHANNEL_ID)
        } else {
            @Suppress("DEPRECATION") Notification.Builder(this)
        }
        return builder
            .setContentTitle(getString(R.string.foreground_service_title))
            .setContentText(if (recoveryId == null) getString(R.string.foreground_service_text) else "屏幕共享已暂停，点此返回知题处理")
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .setContentIntent(contentIntent)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, getString(R.string.foreground_service_stop), stopIntent)
            .setOngoing(true)
            .build()
    }

    private fun releaseCaptureInternal(reason: String, stopProjection: Boolean) {
        completeLegacyFrame("")
        if (legacyFrameAfterStart.getAndSet(false)) deliverLegacyResult("")
        if (pendingCapture != null) {
            completePendingCapture(Result.failure(IllegalStateException(reason)))
        }
        finishFrameDelivery()
        val currentDisplay = virtualDisplay
        virtualDisplay = null
        runCatching { currentDisplay?.release() }
        captureWidth = 0
        captureHeight = 0
        val currentProjection = projection
        projection = null
        projectionCallback?.let { callback -> runCatching { currentProjection?.unregisterCallback(callback) } }
        projectionCallback = null
        if (stopProjection) runCatching { currentProjection?.stop() }
    }

    private fun stopCaptureSynchronously(reason: String) {
        if (!::captureHandler.isInitialized) return
        if (Looper.myLooper() == captureHandler.looper) {
            releaseCaptureInternal(reason, stopProjection = true)
            return
        }
        val latch = CountDownLatch(1)
        val posted = captureHandler.post {
            try {
                releaseCaptureInternal(reason, stopProjection = true)
            } finally {
                latch.countDown()
            }
        }
        if (posted) latch.await(CAPTURE_RELEASE_WAIT_MS, TimeUnit.MILLISECONDS)
    }

    override fun onDestroy() {
        destroyed = true
        if (ocrDelegate.isInitialized()) onDeviceOcr.close()
        bankWriteExecutor.shutdown()
        pendingSessionConfigJson = null
        mainHandler.removeCallbacks(terminalStopRunnable)
        teardownRunner()
        notifySessionState(false)
        stopCaptureSynchronously("截图服务已停止")
        if (::captureThread.isInitialized) captureThread.quitSafely()
        if (instance === this) instance = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?) = null

    companion object {
        private const val RUNNER_LOG_TAG = "TiJingRunner"
        internal const val ACTION_RESTORE_PROJECTION = "com.futureyyy.tijing.action.RESTORE_PROJECTION"
        internal const val EXTRA_RECOVERY_ID = "screenRecovery"
        const val ACTION_STOP = "com.futureyyy.tijing.action.STOP_CAPTURE"
        private const val CONFIRM_SETTLE_DELAY_MS = 240L
        private const val SWEEP_SETTLE_DELAY_MS = 1000L
        private const val CHANNEL_ID = "tijing-capture"
        private const val NOTIFICATION_ID = 4102
        private const val EXTRA_RESULT_CODE = "resultCode"
        private const val EXTRA_RESULT_DATA = "resultData"
        private const val EXTRA_REQUEST_FRAME = "requestFrame"
        private const val EXTRA_SESSION_CONFIG = "sessionConfig"
        private const val CAPTURE_TIMEOUT_MS = 4_000L
        private const val CAPTURE_RELEASE_WAIT_MS = 1_000L
        private const val TERMINAL_MESSAGE_DELAY_MS = 2_000L
        private const val IMAGE_READER_CAPACITY = 2
        private const val JPEG_QUALITY = 78

        @Volatile
        var instance: ScreenCaptureService? = null

        @Volatile
        var listener: ((String) -> Unit)? = null

        @Volatile
        var sessionStateListener: ((Boolean) -> Unit)? = null

        @Volatile
        var sessionErrorListener: ((String) -> Unit)? = null

        fun start(context: Context, resultCode: Int, resultData: Intent, requestFrame: Boolean = false) {
            val intent = baseStartIntent(context, resultCode, resultData)
                .putExtra(EXTRA_REQUEST_FRAME, requestFrame)
            startCompat(context, intent)
        }

        fun restoreProjection(context: Context, id: String, data: Intent) {
            startCompat(context, baseStartIntent(context, Activity.RESULT_OK, data)
                .setAction(ACTION_RESTORE_PROJECTION).putExtra(EXTRA_RECOVERY_ID, id))
        }

        fun startSession(context: Context, resultCode: Int, resultData: Intent, configJson: String) {
            val intent = baseStartIntent(context, resultCode, resultData)
                .putExtra(EXTRA_SESSION_CONFIG, configJson)
            startCompat(context, intent)
        }

        /** Reuses a live MediaProjection grant, so the system consent dialog is not shown again. */
        fun resumeSession(context: Context, configJson: String) {
            val intent = Intent(context, ScreenCaptureService::class.java)
                .putExtra(EXTRA_SESSION_CONFIG, configJson)
            startCompat(context, intent)
        }

        fun stop(context: Context) {
            instance?.closeGatewaySession()
            context.stopService(Intent(context, ScreenCaptureService::class.java))
        }

        private fun baseStartIntent(context: Context, resultCode: Int, resultData: Intent) =
            Intent(context, ScreenCaptureService::class.java)
                .putExtra(EXTRA_RESULT_CODE, resultCode)
                .putExtra(EXTRA_RESULT_DATA, resultData)

        private fun startCompat(context: Context, intent: Intent) {
            if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(intent) else context.startService(intent)
        }
    }
}
