@echo off
setlocal
set LOG=C:\Users\rmsama\AppData\Local\Temp\zt0423-gpt-pack\build-0424.log
echo BUILD_START %DATE% %TIME% > "%LOG%"
if not exist "V:\work\original-vs-0419\release-mobile\android\gradlew.bat" (
  echo V_MISSING >> "%LOG%"
  exit /b 2
)
set "JAVA_HOME=V:\work\tools\jdk\jdk-17.0.20.1+1"
set "PATH=%JAVA_HOME%\bin;%PATH%"
cd /d "V:\work\original-vs-0419\release-mobile\android"
echo JAVA=%JAVA_HOME% >> "%LOG%"
call gradlew.bat --no-daemon :app:assembleProdRelease -PpaymentRelease=true -PfreeServiceRelease=true >> "%LOG%" 2>&1
set EC=%ERRORLEVEL%
echo BUILD_EXIT=%EC% >> "%LOG%"
if exist "app\build\outputs\apk\prod\release\app-prod-release.apk" (
  echo APK_OK >> "%LOG%"
) else (
  echo APK_MISSING >> "%LOG%"
)
exit /b %EC%
