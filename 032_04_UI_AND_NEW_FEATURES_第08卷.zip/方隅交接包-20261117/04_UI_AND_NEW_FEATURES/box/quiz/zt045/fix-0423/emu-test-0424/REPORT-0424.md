# 0.4.24 / 91 受控测试报告（resume → session）

时间：2026-11-15 00:00–00:01（北京时间 / Asia/Shanghai）
模拟器：adb -P 5037 -s emulator-5556
包名：com.jimusoft.dailyhundredapp
正式签名 SHA-256：fac61745dc0903786fb9ede62a962b399f7348f0bb6f899b8332667591033b9c
APK：zhiti-0.4.24-resume.apk，6,601,519 字节，SHA-256 0D12BCA04AA088BCB8CA94B6539480F3CB1E56E791B9870AB672A6CECEA4C533
安装：覆盖安装，未卸载、未清数据、未重置 runId、未购买、未上传蒲公英
firstInstallTime 保持 2026-11-14 06:15:40（模拟器时钟，等于 14:15:40 北京时间）
新进程 PID：12889（旧进程 11716 已 force-stop）
题库：已导入 1,859 题仍在
测试页：微信百题验证 53/100，选项 D 仍为先前误选且未按「确认答案」；本次没有把这次选中当作自动点击结果

## 操作

只点击了一次悬浮窗「开始答题」。没有点「重试」「继续」「停止」或「确认答案」。

## 关键日志（完整原文）

```
11-14 15:59:15.533 I ZhitiSession: local-snapshot id=c20263ab1326 target=com.jimusoft.railwaymp ledgerFound=true source=free phase=confirmed submission=none savedState=active savedRunMatches=true tokenPresent=true expiresValid=false
11-14 16:00:20.259 I ZhitiSession: run-selection id=c20263ab1326 target=com.jimusoft.railwaymp ledgerFound=true phase=confirmed submission=none savedState= freshAllowed=false
11-14 16:00:20.268 I ZhitiSession: gateway-auth stage=start-enter
11-14 16:00:20.274 I ZhitiSession: gateway-auth stage=run-start-complete source=free phase=confirmed
11-14 16:00:20.275 I ZhitiSession: gateway-auth stage=confirmation-complete source=free phase=confirmed
11-14 16:00:20.285 I ZhitiSession: free-auth operation=resume phase=confirmed
11-14 16:00:30.055 I ZhitiSession: free-auth operation=resume result=ok
11-14 16:00:30.055 I ZhitiSession: gateway-auth stage=authorization-ready source=free state=confirmed
11-14 16:00:30.056 I ZhitiSession: exchange-preflight id=c20263ab1326 target=com.jimusoft.railwaymp ledgerFound=true phase=confirmed submission=none authSource=free bindingPresent=true deviceDigestPresent=true
11-14 16:00:49.048 I ZhitiSession: http=503 error=session_unavailable requestId=35a07f96-11de-49aa-8730-64159cbfc71c
11-14 16:00:49.049 W TiJingRunner: gateway-session-begin-failed
```

模拟器日志时间为 UTC。对应北京时间：

- 00:00:20 开始授权，发出 `/free/resume`
- 00:00:30 resume 成功，authorization-ready，随即发起 `/session`（exchange-preflight）
- 00:00:49 `/session` 返回 HTTP 503，error=session_unavailable，requestId=35a07f96-11de-49aa-8730-64159cbfc71c

没有 ZhitiBilling 的 network-failure 或 http-failure 记录。本次失败发生在 `/session`，不是 DNS 超时，也不是 `/free/resume` 失败。

## 对应你上一份方案的分支

符合「结果 D」：resume 成功且 authorization-ready 出现，但 `/session` 返回 503。

界面最终为「答题已暂停」：本轮答题授权暂未确认，请保留本次任务，稍后重试。出现「重试」「继续」「停止」。执行方未再点击。

无 CloudBase 控制台权限，无法代查该 requestId 的服务端记录。请根据这些材料给出下一步决定。执行方只执行你的决定，不自行改授权、计费或云函数。
