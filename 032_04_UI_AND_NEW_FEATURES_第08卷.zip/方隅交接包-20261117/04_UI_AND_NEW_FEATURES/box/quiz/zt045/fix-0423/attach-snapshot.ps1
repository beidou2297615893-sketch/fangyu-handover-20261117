﻿# Attach read-only snapshot results + FreeService.kt to the existing ChatGPT thread. Do not start a new chat.
$ErrorActionPreference='Stop'
$outDir='C:\Users\rmsama\AppData\Local\Temp\zt0423-gpt-pack'
$attachDir=Join-Path $outDir 'attach-snapshot'
$log=Join-Path $outDir 'attach-snapshot-log.txt'
New-Item -ItemType Directory -Force -Path $attachDir | Out-Null
function Log($m){ $line='[' + (Get-Date -Format 'HH:mm:ss.fff') + '] ' + $m; Add-Content -Path $log -Value $line -Encoding UTF8; Write-Output $line }

$files=@(
  (Join-Path $attachDir 'REPORT-SNAPSHOT.md'),
  (Join-Path $attachDir 'logcat-zhitisession.txt'),
  (Join-Path $attachDir 'FreeService.kt'),
  (Join-Path $attachDir '16-after-grant.png')
)
foreach($f in $files){ if(-not (Test-Path $f)){ throw ('MISSING ' + $f) } ; Log ('FILE ' + $f + ' ' + (Get-Item $f).Length) }

Add-Type -AssemblyName UIAutomationClient
Add-Type -AssemblyName UIAutomationTypes
Add-Type -AssemblyName System.Windows.Forms
Add-Type -TypeDefinition @"
using System;
using System.Text;
using System.Runtime.InteropServices;
public static class Win32ChatSnap {
  [DllImport("user32.dll")] public static extern int GetWindowText(IntPtr h, StringBuilder s, int n);
  [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
  [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr h, int n);
  [DllImport("user32.dll")] public static extern bool BringWindowToTop(IntPtr h);
  [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
  [DllImport("user32.dll")] public static extern bool AttachThreadInput(uint a, uint b, bool f);
  [DllImport("kernel32.dll")] public static extern uint GetCurrentThreadId();
  [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr h, out uint pid);
  [DllImport("user32.dll")] public static extern bool SetCursorPos(int x, int y);
  [DllImport("user32.dll")] public static extern void mouse_event(int flags, int dx, int dy, int d, int e);
}
"@

function Force-Foreground([IntPtr]$h){
  $fg=[Win32ChatSnap]::GetForegroundWindow()
  $fgPid=0; $curTid=[Win32ChatSnap]::GetWindowThreadProcessId($fg, [ref]$fgPid)
  $myTid=[Win32ChatSnap]::GetCurrentThreadId()
  if($curTid -ne 0 -and $curTid -ne $myTid){ [void][Win32ChatSnap]::AttachThreadInput($myTid, $curTid, $true) }
  [void][Win32ChatSnap]::ShowWindow($h, 9)
  [void][Win32ChatSnap]::BringWindowToTop($h)
  $ok=[Win32ChatSnap]::SetForegroundWindow($h)
  if($curTid -ne 0 -and $curTid -ne $myTid){ [void][Win32ChatSnap]::AttachThreadInput($myTid, $curTid, $false) }
  return $ok
}

function Walk-Hits($root, $max=12000){
  $walker=[System.Windows.Automation.TreeWalker]::ControlViewWalker
  $q=New-Object System.Collections.Generic.Queue[object]
  $q.Enqueue($root)
  $n=0
  $hits=@()
  while($q.Count -gt 0 -and $n -lt $max){
    $el=$q.Dequeue(); $n++
    $name=''; $ct=''
    try { $name=$el.Current.Name; $ct=$el.Current.ControlType.ProgrammaticName } catch {}
    $hits += [pscustomobject]@{ el=$el; name=$name; ct=$ct }
    try { $c=$walker.GetFirstChild($el); while($c){ $q.Enqueue($c); $c=$walker.GetNextSibling($c) } } catch {}
  }
  Log ('WALKED ' + $n)
  return $hits
}

function Click-El($el){
  $r=$el.Current.BoundingRectangle
  $x=[int]($r.X + $r.Width/2); $y=[int]($r.Y + $r.Height/2)
  [void][Win32ChatSnap]::SetCursorPos($x, $y)
  Start-Sleep -Milliseconds 80
  [Win32ChatSnap]::mouse_event(0x0002, 0, 0, 0, 0)
  Start-Sleep -Milliseconds 40
  [Win32ChatSnap]::mouse_event(0x0004, 0, 0, 0, 0)
  Log ('CLICK ' + $el.Current.Name + ' at ' + $x + ',' + $y)
}

$proc=Get-Process | Where-Object { $_.ProcessName -match 'ChatGPT' -and $_.MainWindowHandle -ne 0 } | Select-Object -First 1
if(-not $proc){ throw 'CHATGPT_WINDOW_NOT_FOUND' }
$sb=New-Object System.Text.StringBuilder 512
[void][Win32ChatSnap]::GetWindowText($proc.MainWindowHandle, $sb, 512)
Log ('PICK hwnd=' + [int64]$proc.MainWindowHandle + ' pid=' + $proc.Id + ' title=' + $sb.ToString())
$h=[IntPtr]$proc.MainWindowHandle
$fgOk=Force-Foreground $h
$fgNow=[Win32ChatSnap]::GetForegroundWindow()
Log ('FG_OK=' + $fgOk + ' FG_NOW=' + [int64]$fgNow)
if((-not $fgOk) -or ($fgNow -ne $h)){ throw 'CHATGPT_NOT_FOREGROUND_ABORT' }

$root=[System.Windows.Automation.AutomationElement]::FromHandle($h)
$hits=Walk-Hits $root
$doc = $hits | Where-Object { $_.ct -match 'Document' -and $_.name -eq '制定最小补丁方案' } | Select-Object -First 1
$wrong = $hits | Where-Object { $_.ct -match 'Document' -and $_.name -eq '小米YU7选购比较' } | Select-Object -First 1
if($doc){ Log 'THREAD_OK 制定最小补丁方案' } else { Log 'THREAD_MISSING' }
if($wrong){ Log 'YU7_DOCUMENT_VISIBLE' }
if(-not $doc){
  $btn = $hits | Where-Object { $_.name -eq '制定最小补丁方案' -and $_.ct -match 'Button' } | Select-Object -First 1
  if(-not $btn){ throw 'WRONG_THREAD' }
  Log 'SWITCHING_THREAD'
  Click-El $btn.el
  Start-Sleep -Seconds 2
  if([Win32ChatSnap]::GetForegroundWindow() -ne $h){ if(-not (Force-Foreground $h)){ throw 'LOST_FG_AFTER_SWITCH' } }
  $root=[System.Windows.Automation.AutomationElement]::FromHandle($h)
  $hits=Walk-Hits $root
  $doc = $hits | Where-Object { $_.ct -match 'Document' -and $_.name -eq '制定最小补丁方案' } | Select-Object -First 1
  if(-not $doc){ throw 'WRONG_THREAD' }
  Log 'THREAD_OK_AFTER_SWITCH'
}

$comps = $hits | Where-Object { $_.name -eq '询问 ChatGPT' -and $_.ct -match 'Edit|Document' }
if(-not $comps){ $comps = $hits | Where-Object { $_.name -eq '询问 ChatGPT' } }
if(-not $comps){ throw 'COMPOSER_NOT_FOUND' }
$composer=$comps[0].el
$cr=$composer.Current.BoundingRectangle
Log ('COMPOSER ' + [int]$cr.X + ',' + [int]$cr.Y + ' ' + [int]$cr.Width + 'x' + [int]$cr.Height)

Click-El $composer
Start-Sleep -Milliseconds 200
$msg=@'
按你批准的只读核对方案，已只增加 logLocalSnapshot，正式签名 0.4.23（versionCode 90）覆盖安装，未卸载、未清数据、未重置 runId，也没有点悬浮窗里的「开始答题」。

新进程 PID=11716。只读日志如下（无完整 runId / token）：

11-14 15:37:47.071 11716 11716 I ZhitiSession: local-snapshot id=c20263ab1326 target=com.jimusoft.railwaymp ledgerFound=true source=free phase=confirmed submission=none savedState=active savedRunMatches=true tokenPresent=true expiresValid=false

对照你的分支：不是 A/B/C/D；符合 E 的主体（savedState=active 且 savedRunMatches=true），但 expiresValid=false。同时 source=free、phase=confirmed、submission=none。

附件：REPORT-SNAPSHOT.md、logcat-zhitisession.txt、你要的 FreeService.kt，以及授权后未点开始的截图。我没有 CloudBase 控制台权限，无法核对该三次服务端请求。请根据这些材料给出下一步决定。执行方只执行你的决定，不自行改授权或计费。
'@
[System.Windows.Forms.Clipboard]::SetText($msg)
Start-Sleep -Milliseconds 150
[System.Windows.Forms.SendKeys]::SendWait('^a')
Start-Sleep -Milliseconds 80
[System.Windows.Forms.SendKeys]::SendWait('^v')
Log 'PASTED_TEXT'
Start-Sleep -Milliseconds 400
$col=New-Object System.Collections.Specialized.StringCollection
foreach($f in $files){ [void]$col.Add($f) }
[System.Windows.Forms.Clipboard]::SetFileDropList($col)
Log 'CLIPBOARD_FILES_SET'
[System.Windows.Forms.SendKeys]::SendWait('^v')
Log 'PASTED_FILES'
Start-Sleep -Seconds 5

$root=[System.Windows.Automation.AutomationElement]::FromHandle($h)
$hits2=Walk-Hits $root
$doc2 = $hits2 | Where-Object { $_.ct -match 'Document' -and $_.name -eq '制定最小补丁方案' } | Select-Object -First 1
if(-not $doc2){ throw 'WRONG_THREAD_BEFORE_SEND' }
$cands=@()
foreach($h2 in $hits2){
  if($h2.ct -match 'Button' -and $h2.name -match '发送|Send|停止'){
    $r=$h2.el.Current.BoundingRectangle
    $cands += [pscustomobject]@{ el=$h2.el; name=$h2.name; en=$h2.el.Current.IsEnabled; x=[int]$r.X; y=[int]$r.Y; w=[int]$r.Width; h=[int]$r.Height }
  }
}
foreach($c in $cands){ Log ('SENDCAND name=[' + $c.name + '] en=' + $c.en + ' rect=' + $c.x + ',' + $c.y + ' ' + $c.w + 'x' + $c.h) }
$pick=$cands | Where-Object { $_.en -and $_.name -eq '发送' -and $_.w -ge 24 -and $_.w -le 90 -and $_.h -ge 24 -and $_.h -le 90 } | Sort-Object x -Descending | Select-Object -First 1
if(-not $pick){ Log 'SEND_NOT_READY'; throw 'SEND_NOT_READY' }
if([Win32ChatSnap]::GetForegroundWindow() -ne $h){ throw 'LOST_FOREGROUND_BEFORE_SEND' }
Click-El $pick.el
Start-Sleep -Seconds 2
$root=[System.Windows.Automation.AutomationElement]::FromHandle($h)
$after=Walk-Hits $root
foreach($c in $after){
  if($c.ct -match 'Button' -and $c.name -match '发送|停止'){ Log ('AFTER name=[' + $c.name + '] en=' + $c.el.Current.IsEnabled) }
}
Log 'ATTACH_SCRIPT_DONE'
