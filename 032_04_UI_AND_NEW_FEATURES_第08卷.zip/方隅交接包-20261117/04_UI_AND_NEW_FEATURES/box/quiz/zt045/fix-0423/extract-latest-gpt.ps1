﻿$ErrorActionPreference='Stop'
$outDir='C:\Users\rmsama\AppData\Local\Temp\zt0423-gpt-pack'
$out=Join-Path $outDir 'chatgpt-503-reply.txt'
$raw=Join-Path $outDir 'chatgpt-503-reply-uia.txt'
Add-Type -AssemblyName UIAutomationClient
Add-Type -AssemblyName UIAutomationTypes
$proc=Get-Process | Where-Object { $_.ProcessName -match 'ChatGPT' -and $_.MainWindowHandle -ne 0 } | Select-Object -First 1
if(-not $proc){ throw 'CHATGPT_WINDOW_NOT_FOUND' }
$root=[System.Windows.Automation.AutomationElement]::FromHandle($proc.MainWindowHandle)
$walker=[System.Windows.Automation.TreeWalker]::ControlViewWalker
$q=New-Object System.Collections.Generic.Queue[object]
$q.Enqueue($root)
$n=0
$started=$false
$rows=@()
while($q.Count -gt 0 -and $n -lt 8000){
  $el=$q.Dequeue(); $n++
  $name=''; $ct=''; try { $name=$el.Current.Name; $ct=$el.Current.ControlType.ProgrammaticName } catch {}
  $r=$null; try { $r=$el.Current.BoundingRectangle } catch {}
  if($name -match '思考了 2m 8s'){ $started=$true }
  if($started -and $r -and $r.X -ge 2100){
    if($name -and $name.Trim().Length -gt 0){
      $rows += ('Y=' + [int]$r.Y + ' X=' + [int]$r.X + ' ' + $ct + ' [' + $name + ']')
    }
  }
  if($started -and $name -eq '询问 ChatGPT' -and $ct -match 'Edit'){ break }
  try { $c=$walker.GetFirstChild($el); while($c){ $q.Enqueue($c); $c=$walker.GetNextSibling($c) } } catch {}
}
Set-Content -Path $raw -Value $rows -Encoding UTF8
# also a cleaner text-only dump of substantial lines
$clean=@()
foreach($line in $rows){
  if($line -match 'ControlType\.(Text|ListItem|Button|Document|CheckBox) \[(.+)\]$'){
    $nm=$Matches[2]
    if($nm -match '询问 ChatGPT|发送|切换模式|新聊天|听写|添加照片|附件'){ continue }
    $clean += $nm
  }
}
Set-Content -Path $out -Value $clean -Encoding UTF8
Write-Output ('RAW_LINES=' + $rows.Count)
Write-Output ('CLEAN_LINES=' + $clean.Count)
Write-Output ('RAW=' + $raw)
Write-Output ('CLEAN=' + $out)
