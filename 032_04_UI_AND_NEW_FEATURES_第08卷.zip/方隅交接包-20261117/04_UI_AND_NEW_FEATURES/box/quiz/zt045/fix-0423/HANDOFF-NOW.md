# 知题接手说明（2026-11-15 00:19 北京时间）

换任何助手先读这份，再干活。不要重置 runId、不要清数据、不要卸载、不要点「重试 / 继续 / 停止 / 确认答案 / 开始答题」，也不要把 0.4.24 发到蒲公英，除非桌面 ChatGPT「制定最小补丁方案」明确批准，并且第 1 题已经真正进入识别/点击/确认。

## 现在停在哪

- 线上给手机用的仍是正式签名 **知题 0.4.22 / versionCode 89 / 蒲公英 build 41**：https://www.pgyer.com/meiribaiti
- 模拟器 emulator-5556 上已覆盖安装正式签名 **0.4.24 / versionCode 91**（未发布）。进程 PID **12889**。
- ChatGPT 批准的改动已生效：已确认的免费任务走 `/free/resume`，不再重复 `confirm`。
- 实测符合结果 D：`/free/resume` 成功（00:00:30），随后 `/session` 返回 **HTTP 503** `error=session_unavailable`，`requestId=35a07f96-11de-49aa-8730-64159cbfc71c`（00:00:49，均为北京时间）。
- 界面停在「答题已暂停：本轮答题授权暂未确认，请保留本次任务，稍后重试。」宿主「微信百题验证」仍是 53/100，选项 D 已选中但未确认。不要按宿主「确认答案」。
- 这份 503 结果包还没成功发进「制定最小补丁方案」。附件和脚本已备好。不要发到「小米YU7选购比较」或其他对话。不要自己改 CloudBase 或再改授权逻辑，等 ChatGPT 决定。

## 有用路径（保留，不要删）

### 用户电脑 RMSAMA（优先用 C: 路径，不要走 V: 拷贝）

- 当前正式签名包：`C:\Users\rmsama\AppData\Local\Temp\zt0423-gpt-pack\zhiti-0.4.24-resume.apk`（6,601,519 字节，SHA-256 `0D12BCA04AA088BCB8CA94B6539480F3CB1E56E791B9870AB672A6CECEA4C533`）
- 发送脚本：`C:\Users\rmsama\AppData\Local\Temp\zt0423-gpt-pack\attach-0424.ps1`（必须 `powershell -STA`）
- 待发送材料：`C:\Users\rmsama\AppData\Local\Temp\zt0423-gpt-pack\attach-0424\`（REPORT-0424.md、logcat、05/06 截图）
- 源码树：`C:\Users\rmsama\Documents\ChatGPT\答题小程序\每日百题APP\work\original-vs-0419\release-mobile`（等同 `V:\work\original-vs-0419\release-mobile`）
- 刚改过的文件：`android\app\src\main\java\com\futureyyy\tijing\payment\AndroidPayment.kt`；版本在 `android\app\build.gradle.kts`（91 / 0.4.24）
- 官方提镜 0.7.7：`C:\Users\rmsama\Documents\ChatGPT\答题小程序\每日百题APP\work\fullflow-alternatives\three-apk-baselines\TiJing-official-0.7.7.apk`（960,780 字节，SHA-256 `3F4988B2FE4C5EAAB22C4E604468C9C99114A0CE3B522611601B2B9A0FCFF20F`）
- adb：`V:\work\tools\android-sdk\platform-tools\adb.exe -P 5037 -s emulator-5556`
- 正式打包脚本：`C:\Users\rmsama\AppData\Local\Temp\zt0423-gpt-pack\build-0424-official.cmd`

### 云电脑证据（本目录）

- 实测：`/workspace/zt045/fix-0423/emu-test-0424/`（含 REPORT-0424.md、logcat-dump-after-wait.txt、05-after-start.png、06-after-wait.png）
- 已应用源码和备份：`/workspace/zt045/fix-0423/src-0424/`、`/workspace/zt045/fix-0423/backup-0424/`
- ChatGPT 上一轮完整批复：`/workspace/zt045/fix-0423/gpt-latest-reply.txt`
- 发送脚本副本：`/workspace/zt045/fix-0423/attach-0424.ps1`
- FreeService.kt：`/workspace/zt045/fix-0423/readonly-src/FreeService.kt`

## 工作法（必须遵守）

- 固定循环：模拟器发现问题 → 把证据交给桌面同一条 ChatGPT「制定最小补丁方案」→ 只执行它的方案 → 再模拟。不要自己另想一套改法。
- 切到该对话请用 UIA Invoke，不要靠鼠标坐标（坐标点不准；当前前台有时会变成别的对话）。点「发送」前确认按钮名称恰好是「发送」且可用，绝不点「停止」。
- 只覆盖安装，不卸载、不清数据。无障碍被覆盖安装清掉后，用 settings put 恢复。
- 先在用户电脑改和签，不要把大文件绕到云电脑。正式签名不要改证书。
- 本窗口定时「盯紧知题改到没问题」每 10 分钟必须让用户看见一句当前进度，不要发过时状态。

## 任务快照（同一笔免费任务，不要重置）

- shortHash：`c20263ab1326`，target：`com.jimusoft.railwaymp`
- source=free，phase=confirmed，submission=none，savedRunMatches=true，tokenPresent=true，expiresValid=false
- 0.4.24 run-selection：freshAllowed=false
