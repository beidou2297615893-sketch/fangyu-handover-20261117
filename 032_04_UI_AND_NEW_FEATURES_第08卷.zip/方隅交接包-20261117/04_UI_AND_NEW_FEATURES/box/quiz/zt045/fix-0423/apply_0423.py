#!/usr/bin/env python3
# Apply ChatGPT 0.4.23 patches A (Chinese error copy) and B (overlay placement).
# Auth/billing path is left unchanged.
from pathlib import Path
import sys

def must_replace(text, old, new, label):
    if old not in text:
        raise SystemExit('MISSING ' + label)
    if text.count(old) != 1:
        raise SystemExit('AMBIGUOUS ' + label + ' count=' + str(text.count(old)))
    return text.replace(old, new, 1)

def patch_scs(path: Path):
    text = path.read_text(encoding='utf-8')
    helper = (
        "    private fun safeGatewayErrorMessage(error: Throwable): String {\n"
        "        val causes = generateSequence(error) { it.cause }.toList()\n"
        "        return if (causes.any { it is java.io.IOException }) {\n"
        '            "网络暂时无法连接答题授权服务，请检查网络后重试。"\n'
        "        } else {\n"
        '            "本轮答题授权暂未确认，请保留本次任务，稍后重试。"\n'
        "        }\n"
        "    }\n"
        "\n"
    )
    old_start = (
        "    /** Acquire only at the user's actual start on a verified foreground target. */\n"
        "    private fun startAuthorizedRunner(generation: Long) {"
    )
    if "safeGatewayErrorMessage" in text:
        print("ALREADY helper in " + str(path))
    else:
        text = must_replace(text, old_start, helper + old_start, "helper-anchor")

    old_catch = (
        "        } catch (error: Exception) {\n"
        '            overlayController?.showError(error.message ?: "答题任务尚未确认")\n'
        "            return\n"
        "        }"
    )
    new_catch = (
        "        } catch (error: Exception) {\n"
        '            Log.w(RUNNER_LOG_TAG, "gateway-run-id-failed", error)\n'
        "            overlayController?.showError(safeGatewayErrorMessage(error))\n"
        "            return\n"
        "        }"
    )
    text = must_replace(text, old_catch, new_catch, "getOrCreateRunId-catch")

    old_fail = (
        "            }, onFailure = { error ->\n"
        '                val message = error.message ?: "答题服务暂不可用，请稍后重试"\n'
        "                overlayController?.showError(message)\n"
        "                notifySessionError(message)\n"
        "                notifySessionState(false)\n"
        "            })"
    )
    new_fail = (
        "            }, onFailure = { error ->\n"
        '                Log.w(RUNNER_LOG_TAG, "gateway-session-begin-failed", error)\n'
        "                val message = safeGatewayErrorMessage(error)\n"
        "                overlayController?.showError(message)\n"
        "                notifySessionError(message)\n"
        "                notifySessionState(false)\n"
        "            })"
    )
    text = must_replace(text, old_fail, new_fail, "begin-onFailure")
    path.write_text(text, encoding="utf-8")
    print("PATCHED " + str(path))

def patch_ov(path: Path):
    text = path.read_text(encoding="utf-8")

    old_gravity = (
        "            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL\n"
        "            y = statusBarHeight() + dp(8)"
    )
    new_gravity = (
        "            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL\n"
        "            y = navigationBarHeight() + dp(12)"
    )
    text = must_replace(text, old_gravity, new_gravity, "createCard-gravity")

    old_show = (
        "    private fun showCard() {\n"
        "        if (!hiddenForCapture) {\n"
        "            cardView?.visibility = View.VISIBLE\n"
        "            syncOverlayTouchPassthrough()\n"
        "        }\n"
        "    }"
    )
    new_show = (
        "    private fun showCard() {\n"
        "        if (!hiddenForCapture) {\n"
        "            bubbleView?.visibility = View.GONE\n"
        "            knowledgePanel?.visibility = View.GONE\n"
        "            knowledgeExpanded = false\n"
        "            cardView?.visibility = View.VISIBLE\n"
        "            syncOverlayTouchPassthrough()\n"
        "        }\n"
        "    }"
    )
    text = must_replace(text, old_show, new_show, "showCard")

    old_collapse = (
        "    private fun collapseCardOnMain() {\n"
        "        mainHandler.removeCallbacks(autoCollapseRunnable)\n"
        "        autoCollapseAtMs = 0L\n"
        "        if (!hiddenForCapture) {\n"
        "            cardView?.visibility = View.GONE\n"
        "            syncOverlayTouchPassthrough()\n"
        "        }\n"
        "    }"
    )
    new_collapse = (
        "    private fun collapseCardOnMain() {\n"
        "        mainHandler.removeCallbacks(autoCollapseRunnable)\n"
        "        autoCollapseAtMs = 0L\n"
        "        if (!hiddenForCapture) {\n"
        "            cardView?.visibility = View.GONE\n"
        "            if (!recoveringProjection && !knowledgeExpanded) {\n"
        "                bubbleView?.visibility = View.VISIBLE\n"
        "            }\n"
        "            syncOverlayTouchPassthrough()\n"
        "        }\n"
        "    }"
    )
    text = must_replace(text, old_collapse, new_collapse, "collapseCardOnMain")

    old_y = (
        "    private fun defaultBubbleY(): Int =\n"
        "        (screenHeight() / 5).coerceAtLeast(statusBarHeight() + edgeMargin)\n"
        "            .coerceAtMost((screenHeight() - bubbleSize - edgeMargin).coerceAtLeast(edgeMargin))\n"
    )
    new_y = (
        "    private fun defaultBubbleY(): Int {\n"
        "        val bottomInset = navigationBarHeight()\n"
        "        return (screenHeight() - bubbleSize - bottomInset - dp(24))\n"
        "            .coerceAtLeast(statusBarHeight() + edgeMargin)\n"
        "    }\n"
        "\n"
        "    private fun navigationBarHeight(): Int {\n"
        '        val resourceId = appContext.resources.getIdentifier("navigation_bar_height", "dimen", "android")\n'
        "        return if (resourceId > 0) {\n"
        "            appContext.resources.getDimensionPixelSize(resourceId)\n"
        "        } else {\n"
        "            0\n"
        "        }\n"
        "    }\n"
    )
    text = must_replace(text, old_y, new_y, "defaultBubbleY")

    old_place = (
        "    private fun placeKnowledgePanel(params: WindowManager.LayoutParams, width: Int, height: Int) {\n"
        "        val bubble = bubbleParams\n"
        "        val preferredX = if (bubble != null) bubble.x - width - dp(8) else dp(8)\n"
        "        val preferredY = if (bubble != null) bubble.y + bubbleSize / 2 - height / 2 else dp(80)\n"
        "        params.x = preferredX.coerceIn(dp(8), (screenWidth() - width - dp(8)).coerceAtLeast(dp(8)))\n"
        "        params.y = preferredY.coerceIn(dp(8), (screenHeight() - height - dp(8)).coerceAtLeast(dp(8)))\n"
        "    }"
    )
    new_place = (
        "    private fun placeKnowledgePanel(params: WindowManager.LayoutParams, width: Int, height: Int) {\n"
        "        val bubble = bubbleParams\n"
        "        val preferredX = bubble?.x ?: edgeMargin\n"
        "        params.x = preferredX.coerceIn(edgeMargin, (screenWidth() - width - edgeMargin).coerceAtLeast(edgeMargin))\n"
        "        params.y = (screenHeight() - height - navigationBarHeight() - dp(16))\n"
        "            .coerceIn(statusBarHeight() + dp(8), (screenHeight() - height).coerceAtLeast(statusBarHeight() + dp(8)))\n"
        "    }"
    )
    text = must_replace(text, old_place, new_place, "placeKnowledgePanel")
    path.write_text(text, encoding="utf-8")
    print("PATCHED " + str(path))

def bump_version(path: Path):
    text = path.read_text(encoding="utf-8")
    text2 = text.replace("versionCode = 89", "versionCode = 90", 1)
    text2 = text2.replace('versionName = "0.4.22"', 'versionName = "0.4.23"', 1)
    if text2 == text:
        raise SystemExit("VERSION_NOT_FOUND in " + str(path))
    path.write_text(text2, encoding="utf-8")
    print("BUMPED " + str(path))

def main():
    if len(sys.argv) < 2:
        raise SystemExit("usage: apply_0423.py <project-root>")
    root = Path(sys.argv[1])
    scs = root / "android" / "app" / "src" / "main" / "java" / "com" / "futureyyy" / "tijing" / "ScreenCaptureService.kt"
    ov = root / "android" / "app" / "src" / "main" / "java" / "com" / "futureyyy" / "tijing" / "OverlayController.kt"
    gradle = root / "android" / "app" / "build.gradle.kts"
    if not scs.exists():
        scs = root / "ScreenCaptureService.kt"
        ov = root / "OverlayController.kt"
        gradle = None
    if not scs.exists() or not ov.exists():
        raise SystemExit("missing sources under " + str(root))
    patch_scs(scs)
    patch_ov(ov)
    if gradle and gradle.exists():
        bump_version(gradle)
    print("OK")

if __name__ == "__main__":
    main()
