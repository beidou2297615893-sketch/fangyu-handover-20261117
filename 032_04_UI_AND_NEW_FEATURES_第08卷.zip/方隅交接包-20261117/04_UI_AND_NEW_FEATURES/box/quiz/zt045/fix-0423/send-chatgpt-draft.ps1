﻿$ErrorActionPreference='Stop'
Add-Type -AssemblyName UIAutomationClient
Add-Type -AssemblyName UIAutomationTypes
Add-Type -TypeDefinition @"
using System;
using System.Runtime.InteropServices;
public static class Win32Send {
  [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
  [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr h, int n);
  [DllImport("user32.dll")] public static extern bool BringWindowToTop(IntPtr h);
  [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
  [DllImport("user32.dll")] public static extern bool AttachThreadInput(uint a, uint b, bool f);
  [DllImport("kernel32.dll")] public static extern uint GetCurrentThreadId();
  [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr h, out uint pid);
  [DllImport("user32.dll")] public static extern bool SetCursorPos(int x, int y);
  [DllImport("user32.dll")] public static extern void mouse_event(int flags, int dx, int dy, int d, int e);
}
"@
function Force-Foreground([IntPtr]$h){
  $fg=[Win32Send]::GetForegroundWindow()
  $fgPid=0; $curTid=[Win32Send]::GetWindowThreadProcessId($fg, [ref]$fgPid)
  $myTid=[Win32Send]::GetCurrentThreadId()
  if($curTid -ne 0 -and $curTid -ne $myTid){ [void][Win32Send]::AttachThreadInput($myTid, $curTid, $true) }
  [void][Win32Send]::ShowWindow($h, 9)
  [void][Win32Send]::BringWindowToTop($h)
  $ok=[Win32Send]::SetForegroundWindow($h)
  if($curTid -ne 0 -and $curTid -ne $myTid){ [void][Win32Send]::AttachThreadInput($myTid, $curTid, $false) }
  return $ok
}
$proc=Get-Process | Where-Object { $_.ProcessName -match 'ChatGPT' -and $_.MainWindowHandle -ne 0 } | Select-Object -First 1
if(-not $proc){ throw 'CHATGPT_WINDOW_NOT_FOUND' }
$h=$proc.MainWindowHandle
if(-not (Force-Foreground $h)){ throw 'FOREGROUND_FAIL' }
Start-Sleep -Milliseconds 300
$root=[System.Windows.Automation.AutomationElement]::FromHandle($h)
$walker=[System.Windows.Automation.TreeWalker]::ControlViewWalker
$q=New-Object System.Collections.Generic.Queue[object]
$q.Enqueue($root)
$n=0
$docName=''
$send=$null
while($q.Count -gt 0 -and $n -lt 8000){
  $el=$q.Dequeue(); $n++
  $name=''; $ct=''
  try { $name=$el.Current.Name; $ct=$el.Current.ControlType.ProgrammaticName } catch {}
  if($ct -match 'Document' -and $name -eq '制定最小补丁方案'){ $docName=$name }
  if($ct -match 'Button' -and $name -eq '发送' -and $el.Current.IsEnabled){
    $r=$el.Current.BoundingRectangle
    if($r.Width -ge 24 -and $r.Width -le 90 -and $r.Height -ge 24 -and $r.Height -le 90){ $send=$el }
  }
  try { $c=$walker.GetFirstChild($el); while($c){ $q.Enqueue($c); $c=$walker.GetNextSibling($c) } } catch {}
}
if($docName -ne '制定最小补丁方案'){ throw 'WRONG_THREAD' }
if(-not $send){ throw 'SEND_NOT_READY' }
if([Win32Send]::GetForegroundWindow() -ne $h){
  if(-not (Force-Foreground $h)){ throw 'LOST_FOREGROUND_BEFORE_SEND' }
  Start-Sleep -Milliseconds 200
}
$r=$send.Current.BoundingRectangle
$x=[int]($r.X + $r.Width/2); $y=[int]($r.Y + $r.Height/2)
Write-Output ('CLICK 发送 at ' + $x + ',' + $y)
[void][Win32Send]::SetCursorPos($x, $y)
Start-Sleep -Milliseconds 80
[Win32Send]::mouse_event(0x0002,0,0,0,0)
Start-Sleep -Milliseconds 40
[Win32Send]::mouse_event(0x0004,0,0,0,0)
Start-Sleep -Seconds 2
$root=[System.Windows.Automation.AutomationElement]::FromHandle($h)
$q=New-Object System.Collections.Generic.Queue[object]
$q.Enqueue($root)
$n=0
while($q.Count -gt 0 -and $n -lt 8000){
  $el=$q.Dequeue(); $n++
  $name=''; $ct=''
  try { $name=$el.Current.Name; $ct=$el.Current.ControlType.ProgrammaticName } catch {}
  if($ct -match 'Button' -and $name -match '发送|停止'){
    Write-Output ('AFTER name=[' + $name + '] en=' + $el.Current.IsEnabled)
  }
  try { $c=$walker.GetFirstChild($el); while($c){ $q.Enqueue($c); $c=$walker.GetNextSibling($c) } } catch {}
}
Write-Output 'SEND_SCRIPT_DONE'
