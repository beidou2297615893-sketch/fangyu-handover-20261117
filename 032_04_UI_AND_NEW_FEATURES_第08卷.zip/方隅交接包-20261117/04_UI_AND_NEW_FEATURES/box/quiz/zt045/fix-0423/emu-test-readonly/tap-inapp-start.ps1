﻿$ErrorActionPreference='Stop'
$adb='V:\work\tools\android-sdk\platform-tools\adb.exe'
$out='C:\Users\rmsama\AppData\Local\Temp\zt0423-gpt-pack\emu-test-readonly'
function Shot($name){
  $remote="/sdcard/Download/$name"
  & $adb -P 5037 -s emulator-5556 shell screencap -p $remote
  & $adb -P 5037 -s emulator-5556 pull $remote (Join-Path $out $name) | Out-Null
  $f=Get-Item (Join-Path $out $name)
  Write-Output ("SHOT $name size=$($f.Length)")
}
Write-Output ('PID=' + (& $adb -P 5037 -s emulator-5556 shell pidof com.jimusoft.dailyhundredapp))
Shot '03-before-inapp-start.png'
& $adb -P 5037 -s emulator-5556 shell input tap 541 1617
Start-Sleep -Seconds 2
Shot '03-after-inapp-start.png'
Write-Output ('PID2=' + (& $adb -P 5037 -s emulator-5556 shell pidof com.jimusoft.dailyhundredapp))
& $adb -P 5037 -s emulator-5556 logcat -d -t 500 | Select-String 'ZhitiSession|local-snapshot|gateway-session|MediaProjection|ScreenCapture'
