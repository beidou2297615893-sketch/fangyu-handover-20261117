# 0.4.23 / 90 只读状态核对结果

时间：2026-11-14 23:37:47（北京时间；模拟器时钟为 UTC 15:37:47）
设备：adb -P 5037 -s emulator-5556
包：com.jimusoft.dailyhundredapp
版本：versionName 0.4.23，versionCode 90
签名：正式证书 SHA-256 fac61745dc0903786fb9ede62a962b399f7348f0bb6f899b8332667591033b9c
安装：覆盖安装成功，firstInstallTime 仍为 2026-11-14 06:15:40，未卸载、未清数据
APK：zhiti-0.4.23-readonly.apk，6,600,915 字节，SHA-256 26A56B179836A06CCDEBC505D259BAC238834A56FBB07101FDD8DB86BE07BFCD
未上传蒲公英。

## 进程

- 安装前 force-stop 后 pidof 为空。
- 启动后新 PID = 11716（不再是旧进程 10850）。
- 本次诊断代码已真正运行。

## 执行限制已遵守

- 未点击悬浮窗里的「开始答题」。
- 未点击「重试」。
- 未重置 runId，未清账，未再次购买。
- 未修改授权或计费逻辑；只增加了 logLocalSnapshot 只读日志。
- 录屏授权已完成，左下角「知」图标已出现。到此停止。

## 关键日志（完整一行，无完整 runId / token）

```
11-14 15:37:47.071 11716 11716 I ZhitiSession: local-snapshot id=c20263ab1326 target=com.jimusoft.railwaymp ledgerFound=true source=free phase=confirmed submission=none savedState=active savedRunMatches=true tokenPresent=true expiresValid=false
```

## 对照你上次给出的分支

- 不是分支 A：source=free，但 phase 不是 reserved，而是 confirmed。
- 不是分支 B：phase 不是 gateway_confirming。
- 不是分支 C：source 不是 credit / subscription。
- 不是分支 D：ledgerFound=true。
- 符合分支 E 的主体：savedState=active，且 savedRunMatches=true。
- 额外事实：tokenPresent=true，但 expiresValid=false（本地已有对应当前任务的 session 凭证，且已过期）。
- 同时：source=free，phase=confirmed，submission=none（免费授权本地已确认，提交结果尚未记录）。

因此未再发起授权、未新建任务。

## 过程中需要你知道的两件附带事实

1. 覆盖安装后，系统把「知题自动点击服务」关掉了（enabled_accessibility_services 曾为 null）。重新启用并回到准备页后，页面显示「悬浮窗与无障碍已开启」，随后才做录屏授权。
2. 返回过程中误点了测试页第 53 题的选项 D，但没有按「确认答案」。题目仍停在 53/100、52 题已作答。不要把这次误选当成软件自动答题结果。

## 未提供的云端核对

我这边没有 CloudBase 控制台权限，因此无法只读核对本轮或此前 20:57:41、21:04:51、22:40:51（北京时间）的服务端请求。下面按你的要求附上 FreeService.kt，请先看客户端只读状态和该文件后再决定下一步。

请给出下一步决定。仍不修改授权和计费逻辑，除非你明确批准。
