﻿$ErrorActionPreference='Stop'
$adb='V:\work\tools\android-sdk\platform-tools\adb.exe'
$out='C:\Users\rmsama\AppData\Local\Temp\zt0423-gpt-pack\emu-test-readonly'
function Shot($name){
  $remote="/sdcard/Download/$name"
  & $adb -P 5037 -s emulator-5556 shell screencap -p $remote
  & $adb -P 5037 -s emulator-5556 pull $remote (Join-Path $out $name) | Out-Null
  Write-Output ("SHOT $name size=$((Get-Item (Join-Path $out $name)).Length)")
}
# revert large pointer without leaving the current app
Write-Output '--- pointer setting ---'
& $adb -P 5037 -s emulator-5556 shell settings get secure accessibility_large_pointer_icon
& $adb -P 5037 -s emulator-5556 shell settings put secure accessibility_large_pointer_icon 0
& $adb -P 5037 -s emulator-5556 shell settings get secure accessibility_large_pointer_icon
Start-Sleep -Seconds 3
Write-Output ('PID=' + (& $adb -P 5037 -s emulator-5556 shell pidof com.jimusoft.dailyhundredapp))
Write-Output '--- focus ---'
& $adb -P 5037 -s emulator-5556 shell dumpsys window | Select-String 'mCurrentFocus|mFocusedApp' | Select-Object -First 6
Shot '06-wait-prep.png'
Write-Output '--- logs ---'
& $adb -P 5037 -s emulator-5556 logcat -d | Select-String 'ZhitiSession|local-snapshot|gateway-session|MediaProjection|ScreenCaptureService|TiJingRunner|Projection'
