﻿$ErrorActionPreference='Stop'
$adb='V:\work\tools\android-sdk\platform-tools\adb.exe'
$out='C:\Users\rmsama\AppData\Local\Temp\zt0423-gpt-pack\emu-test-readonly'
function Shot($name){
  $remote="/sdcard/Download/$name"
  & $adb -P 5037 -s emulator-5556 shell screencap -p $remote
  & $adb -P 5037 -s emulator-5556 pull $remote (Join-Path $out $name) | Out-Null
  Write-Output ("SHOT $name size=$((Get-Item (Join-Path $out $name)).Length)")
}
$focus=& $adb -P 5037 -s emulator-5556 shell dumpsys window | Select-String 'mCurrentFocus' | Select-Object -First 1
Write-Output ("FOCUS=$focus")
if("$focus" -notlike '*dailyhundredapp*'){ throw 'not on 知题, abort' }
# in-app prep start only; will not tap overlay 开始答题
& $adb -P 5037 -s emulator-5556 shell input tap 541 1617
Start-Sleep -Seconds 2
Write-Output ("FOCUS2=" + (& $adb -P 5037 -s emulator-5556 shell dumpsys window | Select-String 'mCurrentFocus' | Select-Object -First 1))
Write-Output ('PID=' + (& $adb -P 5037 -s emulator-5556 shell pidof com.jimusoft.dailyhundredapp))
Shot '15-after-inapp-start.png'
Write-Output '--- logs ---'
& $adb -P 5037 -s emulator-5556 logcat -d -t 800 | Select-String 'ZhitiSession|local-snapshot|gateway-session|MediaProjection|ScreenCapture'
