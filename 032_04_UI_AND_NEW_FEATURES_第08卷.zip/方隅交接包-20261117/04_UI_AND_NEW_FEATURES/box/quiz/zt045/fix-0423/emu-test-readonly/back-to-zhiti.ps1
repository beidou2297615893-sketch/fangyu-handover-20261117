﻿$ErrorActionPreference='Stop'
$adb='V:\work\tools\android-sdk\platform-tools\adb.exe'
$out='C:\Users\rmsama\AppData\Local\Temp\zt0423-gpt-pack\emu-test-readonly'
function Shot($name){
  $remote="/sdcard/Download/$name"
  & $adb -P 5037 -s emulator-5556 shell screencap -p $remote
  & $adb -P 5037 -s emulator-5556 pull $remote (Join-Path $out $name) | Out-Null
  Write-Output ("SHOT $name size=$((Get-Item (Join-Path $out $name)).Length)")
}
Write-Output '--- focus ---'
& $adb -P 5037 -s emulator-5556 shell dumpsys window | Select-String 'mCurrentFocus|mFocusedApp' | Select-Object -First 6
# turn Large mouse pointer back off
& $adb -P 5037 -s emulator-5556 shell input tap 969 1659
Start-Sleep -Seconds 1
Shot '04-pointer-off.png'
# bring 知题 back, do not force-stop
& $adb -P 5037 -s emulator-5556 shell am start -n com.jimusoft.dailyhundredapp/com.futureyyy.tijing.MainActivity
Start-Sleep -Seconds 2
Write-Output ('PID=' + (& $adb -P 5037 -s emulator-5556 shell pidof com.jimusoft.dailyhundredapp))
Shot '05-zhiti-back.png'
Write-Output '--- focus2 ---'
& $adb -P 5037 -s emulator-5556 shell dumpsys window | Select-String 'mCurrentFocus|mFocusedApp' | Select-Object -First 6
