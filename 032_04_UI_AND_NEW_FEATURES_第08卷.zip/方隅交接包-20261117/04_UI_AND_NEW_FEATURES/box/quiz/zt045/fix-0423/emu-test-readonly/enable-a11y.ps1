﻿$ErrorActionPreference='Stop'
$adb='V:\work\tools\android-sdk\platform-tools\adb.exe'
$out='C:\Users\rmsama\AppData\Local\Temp\zt0423-gpt-pack\emu-test-readonly'
function Shot($name){
  $remote="/sdcard/Download/$name"
  & $adb -P 5037 -s emulator-5556 shell screencap -p $remote
  & $adb -P 5037 -s emulator-5556 pull $remote (Join-Path $out $name) | Out-Null
  Write-Output ("SHOT $name size=$((Get-Item (Join-Path $out $name)).Length)")
}
$svc='com.jimusoft.dailyhundredapp/com.futureyyy.tijing.QuizAccessibilityService'
$cur=& $adb -P 5037 -s emulator-5556 shell settings get secure enabled_accessibility_services
Write-Output ("A11Y_BEFORE=$cur")
if([string]::IsNullOrWhiteSpace($cur) -or $cur -eq 'null'){
  $next=$svc
} elseif($cur -like "*${svc}*"){
  $next=$cur
} else {
  $next=($cur + ':' + $svc)
}
& $adb -P 5037 -s emulator-5556 shell settings put secure enabled_accessibility_services $next
& $adb -P 5037 -s emulator-5556 shell settings put secure accessibility_enabled 1
Start-Sleep -Seconds 2
Write-Output ("A11Y_AFTER=" + (& $adb -P 5037 -s emulator-5556 shell settings get secure enabled_accessibility_services))
Write-Output ("A11Y_ON=" + (& $adb -P 5037 -s emulator-5556 shell settings get secure accessibility_enabled))
Write-Output ('PID=' + (& $adb -P 5037 -s emulator-5556 shell pidof com.jimusoft.dailyhundredapp))
Write-Output '--- focus ---'
& $adb -P 5037 -s emulator-5556 shell dumpsys window | Select-String 'mCurrentFocus' | Select-Object -First 3
Shot '07-after-a11y.png'
