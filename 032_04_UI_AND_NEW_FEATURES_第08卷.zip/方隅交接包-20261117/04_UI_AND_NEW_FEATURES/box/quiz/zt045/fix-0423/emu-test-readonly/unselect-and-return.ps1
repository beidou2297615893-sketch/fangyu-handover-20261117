﻿$ErrorActionPreference='Stop'
$adb='V:\work\tools\android-sdk\platform-tools\adb.exe'
$out='C:\Users\rmsama\AppData\Local\Temp\zt0423-gpt-pack\emu-test-readonly'
function Shot($name){
  $remote="/sdcard/Download/$name"
  & $adb -P 5037 -s emulator-5556 shell screencap -p $remote
  & $adb -P 5037 -s emulator-5556 pull $remote (Join-Path $out $name) | Out-Null
  Write-Output ("SHOT $name size=$((Get-Item (Join-Path $out $name)).Length)")
}
# try unselect D; never tap 确认答案
& $adb -P 5037 -s emulator-5556 shell input tap 144 1248
Start-Sleep -Seconds 1
Shot '11-try-unselect.png'
# return to 知题 without BACK
& $adb -P 5037 -s emulator-5556 shell am start -n com.jimusoft.dailyhundredapp/com.futureyyy.tijing.MainActivity
Start-Sleep -Seconds 2
Write-Output ('PID=' + (& $adb -P 5037 -s emulator-5556 shell pidof com.jimusoft.dailyhundredapp))
Write-Output '--- focus ---'
& $adb -P 5037 -s emulator-5556 shell dumpsys window | Select-String 'mCurrentFocus' | Select-Object -First 2
Shot '12-zhiti-again.png'
