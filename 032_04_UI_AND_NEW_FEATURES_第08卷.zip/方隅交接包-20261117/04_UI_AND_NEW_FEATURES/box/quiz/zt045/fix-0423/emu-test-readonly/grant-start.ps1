﻿$ErrorActionPreference='Stop'
$adb='V:\work\tools\android-sdk\platform-tools\adb.exe'
$out='C:\Users\rmsama\AppData\Local\Temp\zt0423-gpt-pack\emu-test-readonly'
function Shot($name){
  $remote="/sdcard/Download/$name"
  & $adb -P 5037 -s emulator-5556 shell screencap -p $remote
  & $adb -P 5037 -s emulator-5556 pull $remote (Join-Path $out $name) | Out-Null
  Write-Output ("SHOT $name size=$((Get-Item (Join-Path $out $name)).Length)")
}
$focus=& $adb -P 5037 -s emulator-5556 shell dumpsys window | Select-String 'mCurrentFocus' | Select-Object -First 1
Write-Output ("FOCUS=$focus")
if("$focus" -notlike '*MediaProjectionPermissionActivity*'){ throw 'grant dialog not in front, abort' }
& $adb -P 5037 -s emulator-5556 shell input tap 892 1710
Start-Sleep -Seconds 3
Write-Output ("FOCUS2=" + (& $adb -P 5037 -s emulator-5556 shell dumpsys window | Select-String 'mCurrentFocus' | Select-Object -First 2))
Write-Output ('PID=' + (& $adb -P 5037 -s emulator-5556 shell pidof com.jimusoft.dailyhundredapp))
Shot '16-after-grant.png'
& $adb -P 5037 -s emulator-5556 logcat -d -s ZhitiSession:V TiJingRunner:V > (Join-Path $out 'logcat-zhitisession.txt')
& $adb -P 5037 -s emulator-5556 logcat -d > (Join-Path $out 'logcat-all-after-grant.txt')
Write-Output '--- snapshot lines ---'
Select-String -Path (Join-Path $out 'logcat-zhitisession.txt') -Pattern 'local-snapshot|ZhitiSession|gateway-session|run-selection|exchange-preflight' | ForEach-Object { $_.Line }
Write-Output ('ZHITI_LOG_BYTES=' + (Get-Item (Join-Path $out 'logcat-zhitisession.txt')).Length)
Write-Output ('ALL_LOG_BYTES=' + (Get-Item (Join-Path $out 'logcat-all-after-grant.txt')).Length)
