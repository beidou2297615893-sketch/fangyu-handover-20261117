﻿$ErrorActionPreference='Stop'
$adb='V:\work\tools\android-sdk\platform-tools\adb.exe'
$out='C:\Users\rmsama\AppData\Local\Temp\zt0423-gpt-pack\emu-test-readonly'
function Shot($name){
  $remote="/sdcard/Download/$name"
  & $adb -P 5037 -s emulator-5556 shell screencap -p $remote
  & $adb -P 5037 -s emulator-5556 pull $remote (Join-Path $out $name) | Out-Null
  Write-Output ("SHOT $name size=$((Get-Item (Join-Path $out $name)).Length)")
}
# refresh the 一键答题 page only; do not tap 开始答题
& $adb -P 5037 -s emulator-5556 shell input keyevent 4
Start-Sleep -Seconds 1
Shot '09-after-back.png'
& $adb -P 5037 -s emulator-5556 shell input tap 541 1263
Start-Sleep -Seconds 2
Shot '10-reenter-onekey.png'
Write-Output ('PID=' + (& $adb -P 5037 -s emulator-5556 shell pidof com.jimusoft.dailyhundredapp))
Write-Output '--- focus ---'
& $adb -P 5037 -s emulator-5556 shell dumpsys window | Select-String 'mCurrentFocus' | Select-Object -First 2
