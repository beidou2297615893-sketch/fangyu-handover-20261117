﻿$ErrorActionPreference='Stop'
$adb='V:\work\tools\android-sdk\platform-tools\adb.exe'
$out='C:\Users\rmsama\AppData\Local\Temp\zt0423-gpt-pack\emu-test-readonly'
Write-Output '--- settings ---'
& $adb -P 5037 -s emulator-5556 shell settings get secure enabled_accessibility_services
& $adb -P 5037 -s emulator-5556 shell settings get secure accessibility_enabled
Write-Output '--- dumpsys a11y ---'
& $adb -P 5037 -s emulator-5556 shell dumpsys accessibility | Select-String 'QuizAccessibility|dailyhundred|Enabled Services|Bound Services|Service connections|Service{|:Accessibility' | Select-Object -First 40
Write-Output '--- bounce ---'
& $adb -P 5037 -s emulator-5556 shell settings put secure accessibility_enabled 0
Start-Sleep -Milliseconds 400
& $adb -P 5037 -s emulator-5556 shell settings put secure enabled_accessibility_services com.jimusoft.dailyhundredapp/com.futureyyy.tijing.QuizAccessibilityService
& $adb -P 5037 -s emulator-5556 shell settings put secure accessibility_enabled 1
Start-Sleep -Seconds 2
Write-Output '--- dumpsys after bounce ---'
& $adb -P 5037 -s emulator-5556 shell dumpsys accessibility | Select-String 'QuizAccessibility|dailyhundred|Enabled|Bound' | Select-Object -First 40
