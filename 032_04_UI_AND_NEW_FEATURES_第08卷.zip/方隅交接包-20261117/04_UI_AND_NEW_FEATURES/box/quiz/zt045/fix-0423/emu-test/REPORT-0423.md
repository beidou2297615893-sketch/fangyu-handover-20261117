# 知题 0.4.23 模拟器实测（2026-11-14，Asia/Shanghai）

正式签名包：com.jimusoft.dailyhundredapp，versionCode 90，versionName 0.4.23，约 6,599,299 字节，证书 SHA-256 与现网正式包一致。本机 emulator-5556 覆盖安装，未卸载、未清数据，题库仍为 1,859 题。宿主仍是「微信百题验证」随机百题 53/100，未改宿主。

## 已按 ChatGPT 方案验证通过的部分

1. 收起的「知」悬浮球在左下角，不再挡住题干。见 05-now.png。
2. 点「知」展开后，面板贴在底部，题干、选项 A–D 和「确认答案」都还能看见；窗内有「开始答题」，点图标本身不会开跑。见 06-after-tap-zhi.png。
3. 点「开始答题」后，状态条出现在底部：「第 1 题 · 识别中 / 正在核对本轮答题权限，请保持题目页打开。」见 07-after-start-0.8s.png。
4. 授权失败后的暂停条也在底部，中文提示为：「本轮答题授权暂未确认，请保留本次任务，稍后重试。」有「重试」「继续」「停止」，不再出现英文 Connection reset / Unable to resolve host。见 08-after-start-plus10s.png。
5. 这次没有把 503 误判成网络故障（符合方案：只有 IOException 才走网络提示）。

6. 点「重试」会立即回到「第 1 题 · 识别中 / 正在核对本轮答题权限」，约十几秒后再次暂停，中文提示不变，仍无英文错误。logcat 第二次同样是 `ZhitiSession: http=503 error=session_unavailable`（模拟器时间 11-14 14:16:02）。见 09-after-retry-0.5s.png 与 11-after-retry-later.png。


## 仍未通过、需要 ChatGPT 继续决策的部分

主流程仍卡在授权。logcat（模拟器时间 11-14 14:14:51，即北京时间约 22:14）：

```
ZhitiSession: http=503 error=session_unavailable
TiJingRunner: gateway-session-begin-failed
java.lang.IllegalStateException: 答题授权暂未确认，请保留本次任务重试；如需新一轮，请明确结束本轮后重新开始。
```

第一题没有真正进入识别、选项点击和确认。「确认答案」仍是灰色，选项未被选中。按你上次要求，0.4.23 先不发布。

请只基于这些证据给出下一步可执行的 503 处理方案。计费和授权逻辑在你给出方案前先不动；不要用假 token 打正式授权接口；不要让用户再付一次款；不要卸载或清数据。
