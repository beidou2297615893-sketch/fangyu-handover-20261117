﻿$ErrorActionPreference='Stop'
$outDir='C:\Users\rmsama\AppData\Local\Temp\zt0423-gpt-pack'
$log=Join-Path $outDir 'attach-0424-retry-log.txt'
$attachDir=Join-Path $outDir 'attach-0424'
$thread=[System.IO.File]::ReadAllText((Join-Path $outDir 'attach-0424-thread.txt')).Trim()
$msg=[System.IO.File]::ReadAllText((Join-Path $outDir 'attach-0424-msg.txt'))
function Log($m){
  $line='[' + (Get-Date -Format 'HH:mm:ss.fff') + '] ' + $m
  Add-Content -Path $log -Value $line -Encoding UTF8
  Write-Output $line
}

$files=@(
  (Join-Path $attachDir 'REPORT-0424.md'),
  (Join-Path $attachDir 'logcat-dump-after-wait.txt'),
  (Join-Path $attachDir '05-after-start.png'),
  (Join-Path $attachDir '06-after-wait.png')
)
foreach($f in $files){ if(-not (Test-Path $f)){ throw ('MISSING ' + $f) } }
Log ('THREAD_NAME ' + $thread)

Add-Type -AssemblyName UIAutomationClient
Add-Type -AssemblyName UIAutomationTypes
Add-Type -AssemblyName System.Windows.Forms
Add-Type -TypeDefinition @"
using System;
using System.Text;
using System.Runtime.InteropServices;
public static class Win32ChatSnap2 {
  [DllImport("user32.dll")] public static extern int GetWindowText(IntPtr h, StringBuilder s, int n);
  [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
  [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr h, int n);
  [DllImport("user32.dll")] public static extern bool BringWindowToTop(IntPtr h);
  [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
  [DllImport("user32.dll")] public static extern bool AttachThreadInput(uint a, uint b, bool f);
  [DllImport("kernel32.dll")] public static extern uint GetCurrentThreadId();
  [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr h, out uint procId);
  [DllImport("user32.dll")] public static extern bool SetCursorPos(int x, int y);
  [DllImport("user32.dll")] public static extern void mouse_event(int flags, int dx, int dy, int d, int e);
}
"@

function Force-Foreground([IntPtr]$h){
  $fg=[Win32ChatSnap2]::GetForegroundWindow()
  $fgProc=0
  $curTid=[Win32ChatSnap2]::GetWindowThreadProcessId($fg, [ref]$fgProc)
  $myTid=[Win32ChatSnap2]::GetCurrentThreadId()
  if($curTid -ne 0 -and $curTid -ne $myTid){ [void][Win32ChatSnap2]::AttachThreadInput($myTid, $curTid, $true) }
  [void][Win32ChatSnap2]::ShowWindow($h, 9)
  [void][Win32ChatSnap2]::BringWindowToTop($h)
  $ok=[Win32ChatSnap2]::SetForegroundWindow($h)
  if($curTid -ne 0 -and $curTid -ne $myTid){ [void][Win32ChatSnap2]::AttachThreadInput($myTid, $curTid, $false) }
  return $ok
}
function FgTitle(){
  $hh=[Win32ChatSnap2]::GetForegroundWindow()
  $sb=New-Object System.Text.StringBuilder 512
  [void][Win32ChatSnap2]::GetWindowText($hh, $sb, $sb.Capacity)
  return ($hh.ToString() + '|' + $sb.ToString())
}
function Walk-Hits($root, $max=12000){
  $walker=[System.Windows.Automation.TreeWalker]::ControlViewWalker
  $q=New-Object System.Collections.Generic.Queue[object]
  $q.Enqueue($root)
  $n=0
  $hits=@()
  while($q.Count -gt 0 -and $n -lt $max){
    $el=$q.Dequeue(); $n++
    $name=''; $ct=''
    try { $name=$el.Current.Name; $ct=$el.Current.ControlType.ProgrammaticName } catch {}
    $hits += [pscustomobject]@{ el=$el; name=$name; ct=$ct }
    try { $c=$walker.GetFirstChild($el); while($c){ $q.Enqueue($c); $c=$walker.GetNextSibling($c) } } catch {}
  }
  Log ('WALKED ' + $n)
  return $hits
}
function Click-El($el){
  $r=$el.Current.BoundingRectangle
  $x=[int]($r.X + $r.Width/2); $y=[int]($r.Y + $r.Height/2)
  [void][Win32ChatSnap2]::SetCursorPos($x, $y)
  Start-Sleep -Milliseconds 80
  [Win32ChatSnap2]::mouse_event(0x0002, 0, 0, 0, 0)
  Start-Sleep -Milliseconds 40
  [Win32ChatSnap2]::mouse_event(0x0004, 0, 0, 0, 0)
  Log ('CLICK ' + $el.Current.Name + ' at ' + $x + ',' + $y)
}

Log ('START fg=' + (FgTitle))
$fgNow=FgTitle
if($fgNow -notmatch 'Grok Bot|ChatGPT'){
  Log ('ABORT_USER_FOREGROUND ' + $fgNow)
  throw 'USER_FOREGROUND'
}

$proc=Get-Process | Where-Object { $_.ProcessName -match 'ChatGPT' -and $_.MainWindowHandle -ne 0 } | Select-Object -First 1
if(-not $proc){ throw 'CHATGPT_WINDOW_NOT_FOUND' }
$h=[IntPtr]$proc.MainWindowHandle
Log ('PICK hwnd=' + $h + ' proc=' + $proc.Id)
$ok=Force-Foreground $h
Log ('FG_OK=' + $ok + ' FG_NOW=' + (FgTitle))
if(-not $ok -or (([Win32ChatSnap2]::GetForegroundWindow()) -ne $h)){ throw 'CANNOT_FOREGROUND' }
Start-Sleep -Milliseconds 400

$root=[System.Windows.Automation.AutomationElement]::FromHandle($h)
$hits=Walk-Hits $root
$doc = $hits | Where-Object { $_.ct -match 'Document' -and $_.name -eq $thread } | Select-Object -First 1
if($doc){ Log 'THREAD_ALREADY_OPEN' }

if(-not $doc){
  $btn = $hits | Where-Object { $_.name -eq $thread -and $_.ct -match 'Button|ListItem|Text' } | Select-Object -First 1
  if($btn){
    Log 'CLICK_VISIBLE_THREAD'
    Click-El $btn.el
    Start-Sleep -Seconds 2
  } else {
    $search = $hits | Where-Object { $_.name -eq [string]([char]0x641C+[char]0x7D22) -and $_.ct -match 'Button' }
    if(-not $search){ $search = $hits | Where-Object { $_.name -eq 'Search' -and $_.ct -match 'Button' } }
    $search = @($search) | Select-Object -First 1
    if(-not $search){ throw 'SEARCH_BUTTON_MISSING' }
    Log 'OPEN_SEARCH'
    Click-El $search.el
    Start-Sleep -Seconds 1
    $root=[System.Windows.Automation.AutomationElement]::FromHandle($h)
    $hits=Walk-Hits $root
    $box = $hits | Where-Object { $_.ct -match 'Edit' } | Select-Object -First 1
    if(-not $box){ throw 'SEARCH_BOX_MISSING' }
    Click-El $box.el
    Start-Sleep -Milliseconds 200
    [System.Windows.Forms.SendKeys]::SendWait('^a')
    Start-Sleep -Milliseconds 80
    [System.Windows.Forms.Clipboard]::SetText($thread)
    Start-Sleep -Milliseconds 80
    [System.Windows.Forms.SendKeys]::SendWait('^v')
    Log 'SEARCH_TYPED'
    Start-Sleep -Seconds 2
    $root=[System.Windows.Automation.AutomationElement]::FromHandle($h)
    $hits=Walk-Hits $root
    $cands = $hits | Where-Object { $_.name -eq $thread -and $_.ct -match 'Button|ListItem|Text|Hyperlink' }
    foreach($c in $cands){
      $r=$c.el.Current.BoundingRectangle
      Log ('SEARCHCAND ct=' + $c.ct + ' rect=' + [int]$r.X + ',' + [int]$r.Y + ' ' + [int]$r.Width + 'x' + [int]$r.Height)
    }
    $pick=@($cands) | Select-Object -First 1
    if(-not $pick){ throw 'THREAD_NOT_IN_SEARCH' }
    Click-El $pick.el
    Start-Sleep -Seconds 2
  }
  if(([Win32ChatSnap2]::GetForegroundWindow()) -ne $h){ if(-not (Force-Foreground $h)){ throw 'LOST_FG_AFTER_SWITCH' } }
  $root=[System.Windows.Automation.AutomationElement]::FromHandle($h)
  $hits=Walk-Hits $root
  $doc = $hits | Where-Object { $_.ct -match 'Document' -and $_.name -eq $thread } | Select-Object -First 1
  if(-not $doc){
    $docs = $hits | Where-Object { $_.ct -match 'Document' }
    foreach($d in $docs){ Log ('DOC_NOW [' + $d.name + ']') }
    throw 'WRONG_THREAD'
  }
  Log 'THREAD_OK_AFTER_SWITCH'
}

$ask = ([char]0x8BE2+[char]0x95EE+' ChatGPT')
$comps = $hits | Where-Object { $_.name -eq $ask -and $_.ct -match 'Edit|Document' }
if(-not $comps){ $comps = $hits | Where-Object { $_.name -eq $ask } }
if(-not $comps){
  $edits = $hits | Where-Object { $_.ct -match 'Edit' }
  foreach($e in $edits){ Log ('EDIT [' + $e.name + ']') }
  throw 'COMPOSER_NOT_FOUND'
}
$composer=@($comps)[0].el
Click-El $composer
Start-Sleep -Milliseconds 200

[System.Windows.Forms.Clipboard]::SetText($msg)
Start-Sleep -Milliseconds 150
[System.Windows.Forms.SendKeys]::SendWait('^a')
Start-Sleep -Milliseconds 80
[System.Windows.Forms.SendKeys]::SendWait('^v')
Log 'PASTED_TEXT'
Start-Sleep -Milliseconds 400
$col=New-Object System.Collections.Specialized.StringCollection
foreach($f in $files){ [void]$col.Add($f) }
[System.Windows.Forms.Clipboard]::SetFileDropList($col)
Log 'CLIPBOARD_FILES_SET'
[System.Windows.Forms.SendKeys]::SendWait('^v')
Log 'PASTED_FILES'
Start-Sleep -Seconds 5

$root=[System.Windows.Automation.AutomationElement]::FromHandle($h)
$hits2=Walk-Hits $root
$doc2 = $hits2 | Where-Object { $_.ct -match 'Document' -and $_.name -eq $thread } | Select-Object -First 1
if(-not $doc2){ throw 'WRONG_THREAD_BEFORE_SEND' }
$sendWord = [string]([char]0x53D1+[char]0x9001)
$stopWord = [string]([char]0x505C+[char]0x6B62)
$cands=@()
foreach($h2 in $hits2){
  if($h2.ct -match 'Button' -and ($h2.name -eq $sendWord -or $h2.name -eq 'Send' -or $h2.name -eq $stopWord)){
    $r=$h2.el.Current.BoundingRectangle
    $cands += [pscustomobject]@{ el=$h2.el; name=$h2.name; en=$h2.el.Current.IsEnabled; x=[int]$r.X; y=[int]$r.Y; w=[int]$r.Width; h=[int]$r.Height }
  }
}
foreach($c in $cands){ Log ('SENDCAND name=[' + $c.name + '] en=' + $c.en + ' rect=' + $c.x + ',' + $c.y + ' ' + $c.w + 'x' + $c.h) }
$pick=$cands | Where-Object { $_.en -and $_.name -eq $sendWord -and $_.w -ge 24 -and $_.w -le 90 -and $_.h -ge 24 -and $_.h -le 90 } | Sort-Object x -Descending | Select-Object -First 1
if(-not $pick){ Log 'SEND_NOT_READY'; throw 'SEND_NOT_READY' }
if([Win32ChatSnap2]::GetForegroundWindow() -ne $h){ throw 'LOST_FOREGROUND_BEFORE_SEND' }
Click-El $pick.el
Start-Sleep -Seconds 2
$root=[System.Windows.Automation.AutomationElement]::FromHandle($h)
$after=Walk-Hits $root
$hasStop=$false
foreach($c in $after){
  if($c.ct -match 'Button' -and ($c.name -eq $sendWord -or $c.name -eq $stopWord)){
    Log ('AFTER name=[' + $c.name + '] en=' + $c.el.Current.IsEnabled)
    if($c.name -eq $stopWord){ $hasStop=$true }
  }
}
if($hasStop){ Log 'SEND_CONFIRMED_STOP_VISIBLE' } else { Log 'SEND_UNCONFIRMED_NO_STOP' }
Log 'ATTACH_SCRIPT_DONE'
