﻿$ErrorActionPreference='Stop'
Add-Type -AssemblyName UIAutomationClient
Add-Type -AssemblyName UIAutomationTypes
Add-Type -TypeDefinition @"
using System;
using System.Runtime.InteropServices;
public static class Win32Sw {
  [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
  [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr h, int n);
  [DllImport("user32.dll")] public static extern bool BringWindowToTop(IntPtr h);
  [DllImport("user32.dll")] public static extern bool SetCursorPos(int x, int y);
  [DllImport("user32.dll")] public static extern void mouse_event(int flags, int dx, int dy, int d, int e);
}
"@
$proc=Get-Process | Where-Object { $_.ProcessName -match 'ChatGPT' -and $_.MainWindowHandle -ne 0 } | Select-Object -First 1
if(-not $proc){ throw 'CHATGPT_WINDOW_NOT_FOUND' }
$h=$proc.MainWindowHandle
[void][Win32Sw]::ShowWindow($h, 9)
[void][Win32Sw]::BringWindowToTop($h)
[void][Win32Sw]::SetForegroundWindow($h)
$root=[System.Windows.Automation.AutomationElement]::FromHandle($h)
$walker=[System.Windows.Automation.TreeWalker]::ControlViewWalker
$q=New-Object System.Collections.Generic.Queue[object]
$q.Enqueue($root)
$n=0
$target=$null
while($q.Count -gt 0 -and $n -lt 8000){
  $el=$q.Dequeue(); $n++
  $name=''; $ct=''
  try { $name=$el.Current.Name; $ct=$el.Current.ControlType.ProgrammaticName } catch {}
  if($name -eq '制定最小补丁方案' -and $ct -match 'Button|ListItem'){
    $r=$el.Current.BoundingRectangle
    Write-Output ('FOUND ' + $ct + ' ' + [int]$r.X + ',' + [int]$r.Y + ' ' + [int]$r.Width + 'x' + [int]$r.Height)
    if(-not $target -and $ct -match 'Button'){ $target=$el }
  }
  try { $c=$walker.GetFirstChild($el); while($c){ $q.Enqueue($c); $c=$walker.GetNextSibling($c) } } catch {}
}
if(-not $target){ throw 'THREAD_BUTTON_NOT_FOUND' }
$r=$target.Current.BoundingRectangle
$x=[int]($r.X + $r.Width/2); $y=[int]($r.Y + $r.Height/2)
[void][Win32Sw]::SetCursorPos($x, $y)
Start-Sleep -Milliseconds 80
[Win32Sw]::mouse_event(0x0002,0,0,0,0)
Start-Sleep -Milliseconds 40
[Win32Sw]::mouse_event(0x0004,0,0,0,0)
Write-Output ('CLICKED at ' + $x + ',' + $y)
Start-Sleep -Seconds 2
Write-Output 'SWITCH_DONE'
