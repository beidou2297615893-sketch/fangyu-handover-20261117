$ErrorActionPreference='Stop'
$aliasActualRoot=[System.IO.Path]::GetFullPath(($PSScriptRoot|Split-Path -Parent)).TrimEnd('\','/')
if(-not('DailyHundredDosDevice' -as [type])){
    Add-Type -TypeDefinition 'using System; using System.Text; using System.Runtime.InteropServices; public static class DailyHundredDosDevice { [DllImport("kernel32.dll", CharSet=CharSet.Unicode, SetLastError=true)] public static extern uint QueryDosDevice(string name, StringBuilder target, int size); }'
}
$aliasBuffer=[System.Text.StringBuilder]::new(4096)
$aliasFound=[DailyHundredDosDevice]::QueryDosDevice('V:',$aliasBuffer,$aliasBuffer.Capacity)
if($aliasFound -gt 0){
    $aliasExpected='\??\'+$aliasActualRoot
    if(-not $aliasBuffer.ToString().Equals($aliasExpected,[System.StringComparison]::OrdinalIgnoreCase)){
        throw 'V: is occupied by another path. Refusing to replace it.'
    }
}else{
    & subst.exe 'V:' $aliasActualRoot
    if($LASTEXITCODE -ne 0){throw 'Could not create project-only V: ASCII build alias.'}
}
if(-not(Test-Path -LiteralPath 'V:/outputs/daily-hundred-app/package.json')){throw 'Project build alias validation failed.'}
