
/** 知题: reuse the original bank match after the normal vision call; map the bank answer onto the AI option boxes. Null keeps the AI answer. */
fun QuestionBankIndex.answerForVision(ai: QuizModelResult): QuizModelResult? {
    val match = match(ai.question)
    val record = match.record?.takeIf { match.status == QuestionBankMatchStatus.EXACT || match.status == QuestionBankMatchStatus.KEY_PHRASE } ?: return null
    val key = { text: String -> QuestionBankIndex.normalize(text.replaceFirst(VISION_OPTION_LABEL, "")).let { mapOf("正确" to "对", "错误" to "错")[it] ?: it } }
    val screen = ai.options.map { key(it.text) }
    val bank = record.options.associate { it.index to key(it.text) }
    if (screen.size != bank.size || screen.toSet().size != screen.size || screen.toSet() != bank.values.toSet()) return null
    val answers = record.answerIndices.map { index -> ai.options[screen.indexOf(bank[index] ?: return null)] }
    if (answers.isEmpty() || answers.any { it.box == null }) return null
    val multi = answers.size > 1 && ai.type != QuestionType.MULTIPLE && ai.type != QuestionType.INDEFINITE
    return ai.copy(answerIndices = answers.map { it.index }, type = if (multi) QuestionType.MULTIPLE else ai.type, answerSource = "question_bank")
}

private val VISION_OPTION_LABEL = Regex("^\\s*[A-Za-zＡ-Ｚａ-ｚ]\\s*[.．、:：)）]\\s*")
