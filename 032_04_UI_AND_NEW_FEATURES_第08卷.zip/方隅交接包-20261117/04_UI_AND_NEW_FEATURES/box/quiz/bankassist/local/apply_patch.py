import os
R=r'C:\Users\rmsama\Documents\ChatGPT\答题小程序\每日百题APP\work\tijing-bankassist'
J=os.path.join(R,r'android\app\src\main\java\com\futureyyy\tijing')
T=os.path.join(R,r'android\app\src\test\java\com\futureyyy\tijing')
here=os.path.dirname(os.path.abspath(__file__))
open(os.path.join(T,'LocalBankVisionTest.kt'),'w',encoding='utf-8',newline='').write(open(os.path.join(here,'LocalBankVisionTest.kt'),encoding='utf-8').read())
def edit(path,old,new):
    s=open(path,encoding='utf-8').read()
    if new in s: print('already',os.path.basename(path)); return
    assert s.count(old)==1,(path,old[:60],s.count(old))
    open(path,'w',encoding='utf-8',newline='').write(s.replace(old,new)); print('patched',os.path.basename(path))
lq=os.path.join(J,'LocalQuestionBank.kt'); s=open(lq,encoding='utf-8').read()
snip=open(os.path.join(here,'bank_vision_snippet.kt'),encoding='utf-8').read()
if 'answerForVision' not in s: open(lq,'a',encoding='utf-8',newline='').write(snip); print('patched LocalQuestionBank.kt')
c=os.path.join(J,'QuizRunCoordinator.kt')
edit(c,"""    private val scheduler: RunnerScheduler = RunnerScheduler.SYSTEM,
) {""","""    private val scheduler: RunnerScheduler = RunnerScheduler.SYSTEM,
    private val answerResolver: (QuizModelResult) -> QuizModelResult = { it },
) {""")
edit(c,"""            QuizModelParser.parse(raw)
        } catch (error: Exception) {
            fail(runGeneration, errorMessage(error, "模型响应解析失败"))
            return
        }
""","""            QuizModelParser.parse(raw).let { ai -> runCatching { answerResolver(ai) }.getOrDefault(ai) }
        } catch (error: Exception) {
            fail(runGeneration, errorMessage(error, "模型响应解析失败"))
            return
        }
""")
s=os.path.join(J,'ScreenCaptureService.kt')
edit(s,"""                scheduler = scheduler,
            )
            coordinator = newCoordinator""","""                scheduler = scheduler,
                answerResolver = if (config.answerSource == QuizAnswerSource.VISION) visionBankResolver() else { it -> it },
            )
            coordinator = newCoordinator""")
edit(s,"""    private fun writeBackFallbackAnswer(raw: String) {""","""    private fun visionBankResolver(): (QuizModelResult) -> QuizModelResult {
        val store = QuestionBankStore.get(this).also { bankWriteExecutor.execute { runCatching { it.index } } }
        return { ai -> store.index.answerForVision(ai).also { Log.i("ZhitiBank", "no=${ai.questionNo} hit=${it != null} ai=${ai.answerIndices} final=${it?.answerIndices}") } ?: ai }
    }

    private fun writeBackFallbackAnswer(raw: String) {""")
g=os.path.join(R,r'android\app\build.gradle.kts')
edit(g,'versionCode = 67','versionCode = 68')
edit(g,'versionName = "0.4.0"','versionName = "0.4.1"')
b=os.path.join(R,r'work\build-android.ps1')
edit(b,'$StageRoot="$env:USERPROFILE/DailyHundredNativeBuild/work/tijing-integration-build"','$StageRoot="$env:USERPROFILE/DailyHundredNativeBuild/work/tijing-bankassist-build"')
