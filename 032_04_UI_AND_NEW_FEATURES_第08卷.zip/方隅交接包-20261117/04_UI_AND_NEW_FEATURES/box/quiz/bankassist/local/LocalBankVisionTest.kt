package com.futureyyy.tijing

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class LocalBankVisionTest {
    private fun rec(id: String, q: String, opts: List<String>, ans: List<Int>, type: QuestionType = QuestionType.SINGLE) =
        LocalQuestionBankRecord(id, q, type, ans, "", opts.mapIndexed { i, t -> QuizOption(i, t, null) })

    private fun ai(q: String, opts: List<String>, ans: List<Int>, type: QuestionType = QuestionType.SINGLE, boxes: Boolean = true) = QuizModelResult(
        1, type, q, opts.mapIndexed { i, t -> QuizOption(i, t, if (boxes) NormalizedBox(5f, 20f + i * 8f, 90f, 6f) else null) },
        ans, NormalizedBox(20f, 85f, 60f, 6f), null, 0.9, answerSource = "vision")

    private val index = QuestionBankIndex.fromRecords(listOf(
        rec("r1", "“禁停区”采用（  ）色带标识。", listOf("黄色", "红色", "白色", "黑色"), listOf(0)),
        rec("r2", "消防装备器材的检查保养应做到“三会”和“四无”。三会是指（ ）；四无是指“无积尘、无损坏、无霉变、无缺件”。", listOf("会检查", "会使用", "会保养", "会修理"), listOf(0, 1, 2), QuestionType.MULTIPLE),
        rec("r3", "列车日常运行时司机应将灯光调节至确保有效的瞭望距离。", listOf("正确", "错误"), listOf(0), QuestionType.TRUE_FALSE),
        rec("r4", "调车作业中，调车指挥人在作业前应向全体作业人员传达调车作业计划。", listOf("正确", "错误"), listOf(0), QuestionType.TRUE_FALSE),
        rec("r5", "调车作业中，调车指挥人在作业前可以不向全体作业人员传达调车作业计划。", listOf("正确", "错误"), listOf(1), QuestionType.TRUE_FALSE),
        rec("r6", "调度命令由（ ）发布。", listOf("列车调度员", "车站值班员", "司机", "乘务员"), listOf(0)),
    ))

    @Test fun shuffledOptionsUseBankAnswerOnScreenBox() {
        val out = index.answerForVision(ai("单选题：“禁停区”采用（ ）色带标识。", listOf("A. 红色", "B. 黑色", "C. 黄色", "D. 白色"), listOf(0)))
        assertEquals(listOf(2), out?.answerIndices); assertEquals("question_bank", out?.answerSource)
    }

    @Test fun stemTypoStillMatches() {
        val out = index.answerForVision(ai("消防装备器材的检査保养应做到“三会”和“四无”。三会是指（ ）；四无是指“无积尘、无损坏、无霉变、无缺件”。", listOf("A. 会修理", "B. 会保养", "C. 会检查", "D. 会使用"), listOf(0)))
        assertEquals(setOf(1, 2, 3), out?.answerIndices?.toSet()); assertEquals(QuestionType.MULTIPLE, out?.type)
    }

    @Test fun trueFalseSynonymsMap() {
        assertEquals(listOf(1), index.answerForVision(ai("列车日常运行时司机应将灯光调节至确保有效的瞭望距离。", listOf("A. 错", "B. 对"), listOf(0), QuestionType.TRUE_FALSE))?.answerIndices)
    }

    @Test fun noMatchKeepsAi() {
        assertNull(index.answerForVision(ai("光合作用主要发生在植物细胞的哪个结构？", listOf("叶绿体", "线粒体", "细胞核", "液泡"), listOf(0))))
    }

    @Test fun nearDuplicatesWithoutClearLeadKeepAi() {
        assertNull(index.answerForVision(ai("调车作业中，调车指挥人在作业前应当向全体作业人员传达调车作业计划。", listOf("对", "错"), listOf(0), QuestionType.TRUE_FALSE)))
    }

    @Test fun differentOptionSetKeepsAi() {
        assertNull(index.answerForVision(ai("调度命令由（ ）发布。", listOf("列车调度员", "车站值班员", "司机", "调车长"), listOf(1))))
    }

    @Test fun missingBoxKeepsAi() {
        assertNull(index.answerForVision(ai("“禁停区”采用（ ）色带标识。", listOf("黄色", "红色", "白色", "黑色"), listOf(1), boxes = false)))
    }
}
