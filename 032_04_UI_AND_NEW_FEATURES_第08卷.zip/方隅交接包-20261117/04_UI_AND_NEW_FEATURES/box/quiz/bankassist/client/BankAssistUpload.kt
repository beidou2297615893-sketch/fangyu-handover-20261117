package com.futureyyy.tijing.payment

import android.content.Context
import android.util.Log
import com.futureyyy.tijing.QuestionBankStore
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest

/**
 * Server-side bank retrieval (知题 bank-assist): keeps the user's imported bank on the owner's
 * server, isolated per installation, so the gateway can pick the most similar bank questions for
 * each screenshot. Runs after the run's gateway session is confirmed; skipped when the server
 * already holds the same bank. Never blocks a run: any failure only means the AI answers alone.
 */
object BankAssistUpload {
    const val BASE = "https://fh6-d5ga45c0ddae7008c-1439321968.ap-shanghai.app.tcloudbase.com/api/bank-assist/v1"
    private const val TAG = "ZhitiBankAssist"
    private const val MAX_ITEMS = 400
    private const val MAX_BYTES = 600_000

    fun sync(context: Context, token: String) {
        try {
            val items = buildItems(context)
            if (items.isEmpty()) return
            val all = JSONArray().apply { items.forEach { put(it) } }
            val hash = sha256(all.toString())
            val status = post("/bank/status", token, JSONObject())
            if (status.optString("hash") == hash) { Log.i(TAG, "bank already on server count=${items.size}"); return }
            val chunks = mutableListOf<MutableList<JSONObject>>()
            var current = mutableListOf<JSONObject>(); var bytes = 0
            for (item in items) {
                val size = item.toString().toByteArray(Charsets.UTF_8).size
                if (current.isNotEmpty() && (current.size >= MAX_ITEMS || bytes + size > MAX_BYTES)) { chunks.add(current); current = mutableListOf(); bytes = 0 }
                current.add(item); bytes += size
            }
            if (current.isNotEmpty()) chunks.add(current)
            chunks.forEachIndexed { index, chunk ->
                val body = JSONObject().put("hash", hash).put("index", index).put("total", chunks.size)
                    .put("items", JSONArray().apply { chunk.forEach { put(it) } })
                post("/bank/chunk", token, body)
            }
            Log.i(TAG, "bank uploaded count=${items.size} chunks=${chunks.size}")
        } catch (error: Exception) {
            Log.w(TAG, "bank upload skipped: ${error.javaClass.simpleName}")
        }
    }

    private fun buildItems(context: Context): List<JSONObject> =
        QuestionBankStore.get(context).snapshot()
            .filter { it.question.isNotBlank() && QuestionBankStore.FALLBACK_SOURCE !in it.sources }
            .map { record ->
                val options = record.options.sortedBy { it.index }.take(26)
                val positions = options.mapIndexed { position, option -> option.index to position }.toMap()
                JSONObject()
                    .put("q", record.question.take(4000))
                    .put("o", JSONArray().apply { options.forEach { put(it.text.take(1000)) } })
                    .put("a", JSONArray().apply { record.answerIndices.mapNotNull { positions[it] }.distinct().sorted().forEach { put(it) } })
                    .put("at", record.answerText.take(2000))
                    .put("t", record.type.name.lowercase().take(20))
            }

    private fun sha256(text: String): String =
        MessageDigest.getInstance("SHA-256").digest(text.toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it) }

    private fun post(path: String, token: String, body: JSONObject): JSONObject {
        val c = URL(BASE + path).openConnection() as HttpURLConnection
        try {
            c.instanceFollowRedirects = false; c.connectTimeout = 15000; c.readTimeout = 30000; c.useCaches = false; c.requestMethod = "POST"
            c.setRequestProperty("Authorization", "Bearer $token"); c.setRequestProperty("Content-Type", "application/json")
            val bytes = body.toString().toByteArray(Charsets.UTF_8)
            c.doOutput = true; c.setFixedLengthStreamingMode(bytes.size); c.outputStream.use { it.write(bytes) }
            if (c.responseCode !in 200..299) throw IllegalStateException("bank-assist ${c.responseCode}")
            return JSONObject(c.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText().take(8192) })
        } finally { c.disconnect() }
    }
}
