(function(){var module={exports:{}};
'use strict';
const TARGET = 100;
function validateBank(bank) {
  if (!Array.isArray(bank) || bank.length < TARGET) return 'BANK_INSUFFICIENT';
  const ids = new Set();
  for (let i = 0; i < bank.length; i++) {
    const q = bank[i];
    if (!q || typeof q.id !== 'string' || !q.id || typeof q.stem !== 'string' || !q.stem.trim()
      || ['single', 'multiple', 'boolean'].indexOf(q.type) < 0 || ids.has(q.id)
      || !Array.isArray(q.options) || q.options.length < 2
      || !Array.isArray(q.correctOptionIds) || !q.correctOptionIds.length
      || (q.type !== 'multiple' && q.correctOptionIds.length !== 1)) return 'BANK_INVALID';
    const optionIds = new Set();
    for (let k = 0; k < q.options.length; k++) {
      const o = q.options[k];
      if (!o || typeof o.id !== 'string' || !o.id || optionIds.has(o.id) || typeof o.text !== 'string' || !o.text.trim()) return 'BANK_INVALID';
      optionIds.add(o.id);
    }
    if (new Set(q.correctOptionIds).size !== q.correctOptionIds.length || q.correctOptionIds.some(id => !optionIds.has(id))) return 'BANK_INVALID';
    ids.add(q.id);
  }
  return '';
}
function createQuiz(bank, options) {
  options = options || {};
  const random = options.random || Math.random;
  const errorCode = validateBank(bank);
  const bankCount = Array.isArray(bank) ? bank.length : 0;
  let previousIds = '';
  let state = { phase: 'home', bankCount: bankCount, questions: [], index: 0, selectedId: '', selectedIds: [], answered: false, score: 0, wrong: 0, answeredCount: 0, correct: false, answerId: '', answerIds: [], errorCode: '' };
  function currentIs(id) { return state.phase === 'question' && state.questions[state.index].id === id; }
  return {
    start: function () {
      if (state.phase === 'question') return false;
      if (errorCode) { state.phase = 'error'; state.errorCode = errorCode; return false; }
      // Partial Fisher–Yates: an equal chance for each remaining question, without replacement.
      const all = bank.slice();
      for (let i = 0; i < TARGET; i++) {
        const value = random();
        const unit = typeof value === 'number' && isFinite(value) ? Math.min(Math.max(value, 0), 0.9999999999999999) : 0;
        const j = i + Math.floor(unit * (all.length - i));
        const hold = all[i]; all[i] = all[j]; all[j] = hold;
      }
      const questions = all.slice(0, TARGET);
      // Keep every available type represented; replace only from a type with spare questions.
      const counts = {};
      questions.forEach(q => { counts[q.type] = (counts[q.type] || 0) + 1; });
      function pickIndex(length) {
        const value = random();
        const unit = typeof value === 'number' && isFinite(value) ? Math.min(Math.max(value, 0), 0.9999999999999999) : 0;
        return Math.floor(unit * length);
      }
      ['single', 'multiple', 'boolean'].forEach(type => {
        if (counts[type]) return;
        const candidates = bank.filter(q => q.type === type);
        if (!candidates.length) return;
        const replaceable = [];
        questions.forEach((q, i) => { if (counts[q.type] > 1) replaceable.push(i); });
        const index = replaceable[pickIndex(replaceable.length)];
        counts[questions[index].type] -= 1;
        questions[index] = candidates[pickIndex(candidates.length)];
        counts[type] = 1;
      });
      if (questions.map(q => q.id).join('|') === previousIds) {
        const hold = questions[0]; questions[0] = questions[1]; questions[1] = hold;
      }
      previousIds = questions.map(q => q.id).join('|');
      state = { phase: 'question', bankCount: bankCount, questions: questions, index: 0, selectedId: '', selectedIds: [], answered: false, score: 0, wrong: 0, answeredCount: 0, correct: false, answerId: '', answerIds: [], errorCode: '' };
      return true;
    },
    select: function (id, questionId) {
      if (!currentIs(questionId) || state.answered) return false;
      const q = state.questions[state.index];
      const selected = Array.isArray(id) ? id.slice() : [id];
      if ((q.type !== 'multiple' && selected.length !== 1) || new Set(selected).size !== selected.length
        || selected.some(value => !q.options.some(o => o.id === value))) return false;
      state.selectedIds = selected;
      state.selectedId = q.type === 'multiple' ? '' : selected[0];
      return true;
    },
    confirm: function (questionId) {
      if (!currentIs(questionId) || state.answered || !state.selectedIds.length) return false;
      state.answered = true;
      state.answerIds = state.questions[state.index].correctOptionIds.slice();
      state.answerId = state.answerIds[0];
      state.correct = state.selectedIds.length === state.answerIds.length && state.selectedIds.every(id => state.answerIds.indexOf(id) >= 0);
      state.score += state.correct ? 1 : 0;
      state.wrong += state.correct ? 0 : 1;
      state.answeredCount += 1;
      return true;
    },
    next: function (questionId) {
      if (!currentIs(questionId) || !state.answered) return false;
      if (state.index === TARGET - 1) { state.phase = 'result'; return true; }
      state.index += 1; state.selectedId = ''; state.selectedIds = []; state.answered = false; state.correct = false; state.answerId = ''; state.answerIds = [];
      return true;
    },
    snapshot: function () { return JSON.parse(JSON.stringify(state)); }
  };
}
module.exports = { createQuiz: createQuiz, validateBank: validateBank };
window.__ENGINE__=module.exports;})();
