package com.jimusoft.railwaymp;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;

/** Hosts the original railway mini program pages (rendered as HTML) for on-device answering tests. */
public class MainActivity extends Activity {
    private WebView web;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.parseColor("#102b50"));
        getWindow().setNavigationBarColor(Color.parseColor("#f3f6fa"));
        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setTextZoom(100);
        s.setAllowFileAccess(true);
        web.addJavascriptInterface(new Recorder(), "Recorder");
        web.loadUrl("file:///android_asset/web/index.html");
        setContentView(web);
    }

    @Override public void onBackPressed() {
        web.evaluateJavascript("window.goBack()", v -> { if (!"true".equals(v)) finish(); });
    }

    /** Test-only score sink: the page's own state after each step, appended to files/events.jsonl. */
    private class Recorder {
        @JavascriptInterface public void save(String json) {
            Log.i("RailwayMP", json);
            try (FileOutputStream out = openFileOutput("events.jsonl", MODE_APPEND)) {
                out.write((json + "\n").getBytes(StandardCharsets.UTF_8));
            } catch (Exception ignored) { }
        }
    }
}
