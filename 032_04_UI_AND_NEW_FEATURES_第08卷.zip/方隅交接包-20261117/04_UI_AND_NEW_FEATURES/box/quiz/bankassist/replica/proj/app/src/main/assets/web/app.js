'use strict';
// Original pages (index / my / quiz) of the 1863-question railway mini program, rendered as HTML.
// quiz.js logic is preserved; only wx.* view plumbing is replaced. Recorder is a test-only sink.
(function(){
var bank = window.__BANK__;
var createQuiz = window.__ENGINE__.createQuiz;
var body = document.getElementById('body'), tab = document.getElementById('tab');
var navTitle = document.getElementById('nav-title'), navBack = document.getElementById('nav-back');
var esc = function(s){ return String(s == null ? '' : s).replace(/[&<>"]/g, function(c){ return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]; }); };
var stack = ['index'], quizPage = null;
function record(evt, data){ try { if (window.Recorder) window.Recorder.save(JSON.stringify({evt: evt, t: Date.now(), data: data})); } catch (e) {} }
function show(){
  var top = stack[stack.length - 1], isTab = top === 'index' || top === 'my';
  tab.style.display = isTab ? 'flex' : 'none'; body.className = 'wx-body' + (isTab ? ' has-tab' : '');
  navBack.style.display = isTab ? 'none' : 'flex';
  Array.prototype.forEach.call(tab.children, function(el){ el.className = el.getAttribute('data-tab') === top ? 'on' : ''; });
  if (top === 'index') { navTitle.textContent = '微信百题验证'; body.innerHTML = '<div class="page"><div class="card home"><span class="eyebrow">每日练习</span><span class="title">微信百题验证</span><span class="intro">用一轮百题，检验今天的学习成果。</span><span class="intro">练习入口在底部「我的」中。</span><span class="note">每轮随机抽取100道题，支持单选、多选和判断。无需登录，答题记录不上传。</span></div></div>'; }
  else if (top === 'my') { navTitle.textContent = '我的'; body.innerHTML = '<div class="page"><div class="card home"><span class="eyebrow">我的练习</span><span class="title">我的</span><span class="intro">题库共' + bank.questions.length + '道，每轮随机抽取100道。</span><div id="random-quiz-entry" class="wx-button primary start">随机百题</div><span class="note">进入后点击「开始100题」，即可开始本轮练习。</span></div></div>';
    document.getElementById('random-quiz-entry').onclick = function(){ stack.push('quiz'); quizPage = newQuizPage(); show(); }; }
  else { navTitle.textContent = '随机百题'; quizPage.render(); }
  window.scrollTo(0, 0);
}
function newQuizPage(){
  var page = { data: {} };
  page._quiz = createQuiz(bank.questions);
  page.render = function(){
    var state = this._quiz.snapshot();
    var q = state.questions[state.index];
    var right = q ? q.options.filter(function(o){ return state.answerIds.indexOf(o.id) >= 0; }) : [];
    var d = {
      phase: state.phase, bankCount: state.bankCount,
      current: q ? { id: q.id, stem: q.stem, type: q.type, typeLabel: { single: '单选', multiple: '多选', boolean: '判断' }[q.type],
        options: q.options.map(function(o){ return { id: o.id, text: o.text, selected: state.selectedIds.indexOf(o.id) >= 0 }; }) } : null,
      progress: q ? (state.index + 1) + '/100' : '', hasSelection: state.selectedIds.length > 0, answered: state.answered, correct: state.correct,
      answerText: right.map(function(o){ return o.id + '. ' + o.text; }).join('；'), analysis: state.answered && q ? q.analysis : '',
      lastQuestion: state.index === 99, score: state.score, wrong: state.wrong, answeredCount: state.answeredCount,
      errorText: state.errorCode === 'BANK_INSUFFICIENT' ? '题库不足100道，请补充题库后重新打开。' : state.errorCode ? '题库格式有误，请检查题目和标准答案后重新打开。' : ''
    };
    this.data = d; var h = '<div class="page">';
    if (d.phase === 'home') {
      h += '<div class="card home"><span class="eyebrow">随机百题</span><span class="title">准备开始练习</span><span class="intro">题库共' + d.bankCount + '道，每次随机抽100道。</span><span class="intro">单选和判断选择一项，多选选择所有正确选项，确认后查看对错。</span><span class="intro">完成100题后显示本次成绩。</span><div id="start-button" class="wx-button primary start">开始100题</div><span class="note">进入第一道题后，可打开每日百题浮窗开始答题。离开并重新进入本页后需重新开始。</span></div>';
    } else if (d.phase === 'question') {
      var c = d.current, multi = c.type === 'multiple', kind = multi ? 'wx-checkbox' : 'wx-radio';
      h += '<div class="topline"><span id="question-type" class="type">' + c.typeLabel + '</span><span id="question-progress" class="progress">' + d.progress + '</span></div><div class="card quiz-card"><span id="question-stem" class="stem">' + esc(c.stem) + '</span>';
      if (multi) h += '<span class="selection-note">请选择所有正确选项，再确认答案。</span>';
      h += '<div id="answer-options" class="options">';
      c.options.forEach(function(o){ h += '<label class="option ' + (o.selected ? 'selected' : '') + ' ' + (d.answered ? 'locked' : '') + '" data-id="' + esc(o.id) + '"><span id="option-' + esc(o.id) + '" class="' + kind + (o.selected ? ' checked' : '') + (d.answered ? ' dis' : '') + '"></span><span class="option-letter">' + esc(o.id) + '.</span><span class="option-text">' + esc(o.text) + '</span></label>'; });
      h += '</div>';
      if (!d.answered) h += '<div id="confirm-button" class="wx-button primary' + (d.hasSelection ? '' : ' disabled') + '">确认答案</div>';
      else h += '<div class="answer-block"><span id="answer-feedback" class="feedback ' + (d.correct ? 'right' : 'wrong') + '">' + (d.correct ? '回答正确' : '回答错误') + '</span><span class="standard-answer">正确答案：' + esc(d.answerText) + '</span>' + (d.analysis ? '<span class="analysis">' + esc(d.analysis) + '</span>' : '') + '<div id="next-button" class="wx-button primary">' + (d.lastQuestion ? '查看成绩' : '下一题') + '</div></div>';
      h += '</div><span class="footnote">' + d.answeredCount + '题已作答 · 每题1分</span>';
    } else if (d.phase === 'result') {
      h += '<div class="card result"><span id="completion-marker" class="result-title">微信百题验证已完成</span><span id="score" class="score">得分：' + d.score + '</span><span class="score-caption">满分100分</span><div class="summary"><span>答对' + d.score + '题</span><span>答错' + d.wrong + '题</span></div><span class="intro">本次100题已全部完成。</span><div id="restart-button" class="wx-button primary start">再来100题</div><span class="note">重新随机抽题；不同轮次之间可能遇到相同题目。</span></div>';
    } else {
      h += '<div class="card error"><span class="title">暂时无法开始</span><span class="intro">' + esc(d.errorText) + '</span></div>';
    }
    body.innerHTML = h + '</div>';
    this.bind(state);
  };
  page.bind = function(state){
    var self = this, d = this.data, $ = function(id){ return document.getElementById(id); };
    if ($('start-button')) $('start-button').onclick = function(){ self.startQuiz(); };
    if ($('restart-button')) $('restart-button').onclick = function(){ self.startQuiz(); };
    if (d.phase === 'question') {
      var qid = d.current.id, multi = d.current.type === 'multiple';
      Array.prototype.forEach.call(document.querySelectorAll('#answer-options .option'), function(el){
        el.onclick = function(ev){ ev.preventDefault(); if (d.answered) return; var id = el.getAttribute('data-id'), value;
          if (multi) { var cur = d.current.options.filter(function(o){ return o.selected; }).map(function(o){ return o.id; }); var on = cur.indexOf(id) < 0;
            value = d.current.options.map(function(o){ return o.id; }).filter(function(x){ return x === id ? on : cur.indexOf(x) >= 0; }); }
          else value = id;
          self.chooseAnswer({ detail: { value: value }, currentTarget: { dataset: { questionId: qid } } }); };
      });
      if ($('confirm-button')) $('confirm-button').onclick = function(){ if (!d.hasSelection) return; self.confirmAnswer({ currentTarget: { dataset: { questionId: qid } } }); };
      if ($('next-button')) $('next-button').onclick = function(){ self.nextQuestion({ currentTarget: { dataset: { questionId: qid } } }); };
    }
  };
  page.startQuiz = function(){ this._quiz.start(); this.render(); window.scrollTo(0, 0); var s = this._quiz.snapshot(); record('start', { ids: s.questions.map(function(q){ return q.id; }) }); record('show', { index: 0, id: s.questions[0] && s.questions[0].id }); };
  page.chooseAnswer = function(event){ if (this._quiz.select(event.detail.value, event.currentTarget.dataset.questionId)) this.render(); };
  page.confirmAnswer = function(event){ if (this._quiz.confirm(event.currentTarget.dataset.questionId)) { var s = this._quiz.snapshot(), q = s.questions[s.index];
      record('confirm', { index: s.index, id: q.id, type: q.type, selected: s.selectedIds, answer: s.answerIds, correct: s.correct, score: s.score, wrong: s.wrong, answeredCount: s.answeredCount }); this.render(); } };
  page.nextQuestion = function(event){ if (this._quiz.next(event.currentTarget.dataset.questionId)) { this.render(); window.scrollTo(0, 0); var s = this._quiz.snapshot(); record(s.phase === 'result' ? 'result' : 'show', { index: s.index, id: s.questions[s.index] && s.questions[s.index].id, score: s.score }); } };
  return page;
}
navBack.onclick = function(){ window.goBack(); };
window.goBack = function(){ if (stack.length > 1) { stack.pop(); show(); return true; } return false; };
Array.prototype.forEach.call(tab.children, function(el){ el.onclick = function(){ stack = [el.getAttribute('data-tab')]; show(); }; });
show();
})();
