'use strict';
// Bank-assist Event function (independent of dailyHundredImportV1Event). Handler=index.main
const {createHandler}=require('./lib/handler.cjs');
const {createStore}=require('./lib/store.cjs');
const {delegateUpstream,directUpstream}=require('./lib/upstream.cjs');
let cached;
function build(){
 const cloudbase=require('@cloudbase/node-sdk');
 const app=cloudbase.init({env:cloudbase.SYMBOL_CURRENT_ENV,timeout:50000});
 const db=app.database();
 const key=process.env.DEEPSEEK_API_KEY;
 const direct=typeof key==='string'&&key.length>=8;
 const upstream=direct?directUpstream({providerKey:key}):delegateUpstream({callFunction:o=>app.callFunction(o)});
 return createHandler({store:createStore({db}),upstream,mode:direct?'direct':'delegate',log:m=>console.log(JSON.stringify(m))});
}
exports.main=async event=>{
 try{cached=cached||build();return await cached(event)}
 catch{return {statusCode:503,headers:{'content-type':'application/json; charset=utf-8'},body:'{"error":"bank_assist_unavailable"}',isBase64Encoded:false}}
};
