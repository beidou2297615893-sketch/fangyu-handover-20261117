'use strict';
const crypto=require('node:crypto');
const sha=s=>crypto.createHash('sha256').update(s,'utf8').digest('hex');
function memoryDb({collections=['daily_hundred_import_v1']}={}){
 const data=new Map(collections.map(c=>[c,new Map()]));
 const coll=name=>({doc:id=>({async get(){if(!data.has(name))throw Object.assign(Error('collection not exist'),{code:'DATABASE_COLLECTION_NOT_EXIST'});const v=data.get(name).get(id);return {data:v?[{_id:id,...structuredClone(v)}]:[]}},
  async set(v){if(!data.has(name))throw Object.assign(Error('collection not exist'),{code:'DATABASE_COLLECTION_NOT_EXIST'});data.get(name).set(id,structuredClone(v));return {}}})});
 return {data,collection:coll,async createCollection(n){if(!data.has(n))data.set(n,new Map());return {}},async runTransaction(fn){return fn({collection:coll})}};
}
function seedSession(db,{token='A'.repeat(43),owner='i0123',expiresAt=Date.now()+3600000,used=0,state='active'}={}){
 const rk='gr-'+sha(owner+'\0run');const c=db.data.get('daily_hundred_import_v1');
 c.set('gs-'+sha(token),{kind:'gateway-session-v1',runKey:rk});
 c.set(rk,{kind:'gateway-run-v1',owner,runId:'run',binding:'b',source:'free',tokenHash:sha(token),state,createdAt:0,expiresAt,limit:160,used});
 return {token,rk};
}
const event=(path,token,body)=>({path,httpMethod:'POST',headers:{authorization:'Bearer '+token,'content-type':'application/json'},body:typeof body==='string'?body:JSON.stringify(body),isBase64Encoded:false});
const providerResponse=(content,usage={prompt_tokens:10,completion_tokens:5})=>({statusCode:200,headers:{'content-type':'application/json'},body:Buffer.from(JSON.stringify({choices:[{message:{content},finish_reason:'stop'}],usage}))});
module.exports={memoryDb,seedSession,event,providerResponse,sha};
