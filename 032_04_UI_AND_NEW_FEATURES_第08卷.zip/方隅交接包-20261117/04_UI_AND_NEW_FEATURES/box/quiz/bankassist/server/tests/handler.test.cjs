'use strict';
const test=require('node:test'),assert=require('node:assert');
const {createHandler,CHAT,BANK_STATUS,BANK_CHUNK}=require('../lib/handler.cjs');
const {createStore}=require('../lib/store.cjs');
const {memoryDb,seedSession,event,providerResponse,sha}=require('./support.cjs');
const original={model:'deepseek-flash',messages:[{role:'system',content:'ORIGINAL PROMPT'},{role:'user',content:[{type:'text',text:'这是第 1 题'},{type:'image_url',image_url:{url:'data:image/png;base64,AAAA'}}]}],temperature:0,max_tokens:1200,response_format:{type:'json_object'}};
const bankItems=[{q:'中国的首都是哪座城市？',o:['上海','北京','广州','深圳'],a:[1]},{q:'铁路信号中红灯表示什么？',o:['停车','减速','通过'],a:[0]}];
const hash='a'.repeat(64);
async function setup({mode='delegate',transcript='中国的首都是哪座城市？',bank=true,transcribeFails=false}={}){
 const db=memoryDb(),{token}=seedSession(db),store=createStore({db}),calls=[];
 const upstream=async(tok,buf)=>{calls.push({tok,body:buf.toString('utf8')});const j=JSON.parse(buf.toString('utf8'));
  if(j.messages[0].content.startsWith('你是题库题干提取器')){if(transcribeFails)throw Error('boom');return providerResponse(JSON.stringify({question:transcript}),{prompt_tokens:900,completion_tokens:20})}
  return providerResponse('{"question_no":1,"answer_indices":[1]}',{prompt_tokens:1500,completion_tokens:180});};
 const h=createHandler({store,upstream,mode});
 if(bank){const r=await h(event(BANK_CHUNK,token,{hash,index:0,total:1,items:bankItems}));assert.strictEqual(r.statusCode,200);}
 return {db,token,h,calls,store};
}
const meta=r=>JSON.parse(r.headers['x-bank-assist']);
test('hit: transcribe, retrieve, send candidates with original prompt; response bytes passed through',async()=>{
 const {h,token,calls}=await setup();const r=await h(event(CHAT,token,original));
 assert.strictEqual(r.statusCode,200);assert.strictEqual(calls.length,2);assert.ok(calls.every(c=>c.tok===token));
 const final=JSON.parse(calls[1].body);assert.strictEqual(final.messages[0].content,'ORIGINAL PROMPT');assert.match(final.messages[1].content[1].text,/标准答案：B\. 北京/);
 const body=JSON.parse(Buffer.from(r.body,'base64'));assert.strictEqual(body.choices[0].message.content,'{"question_no":1,"answer_indices":[1]}');
 const m=meta(r);assert.strictEqual(m.result,'candidates');assert.ok(m.scores[0]>0.95);assert.deepStrictEqual(m.transcribeUsage,{prompt:900,completion:20});
});
test('miss: final request is byte-identical to the client request',async()=>{
 const {h,token,calls}=await setup({transcript:'光合作用主要发生在植物细胞的哪个结构'});const raw=JSON.stringify(original);
 const r=await h(event(CHAT,token,raw));assert.strictEqual(r.statusCode,200);assert.strictEqual(calls.length,2);assert.strictEqual(calls[1].body,raw);assert.strictEqual(meta(r).result,'no_match');
});
test('no bank: single passthrough call, identical bytes',async()=>{
 const {h,token,calls}=await setup({bank:false});const raw=JSON.stringify(original);
 const r=await h(event(CHAT,token,raw));assert.strictEqual(calls.length,1);assert.strictEqual(calls[0].body,raw);assert.strictEqual(meta(r).result,'no_bank');
});
test('transcription failure degrades to passthrough',async()=>{
 const {h,token,calls}=await setup({transcribeFails:true});const raw=JSON.stringify(original);
 const r=await h(event(CHAT,token,raw));assert.strictEqual(r.statusCode,200);assert.strictEqual(calls.at(-1).body,raw);assert.strictEqual(meta(r).result,'assist_error');
});
test('unauthorized and expired sessions are rejected without upstream calls',async()=>{
 const {h,calls,db}=await setup({bank:false});
 assert.strictEqual((await h(event(CHAT,'B'.repeat(43),original))).statusCode,403);
 const {token}=seedSession(db,{token:'C'.repeat(43),owner:'i9',expiresAt:Date.now()-1});assert.strictEqual((await h(event(CHAT,token,original))).statusCode,403);
 assert.strictEqual((await h({...event(CHAT,'x',original),headers:{authorization:'Bearer short'}})).statusCode,401);
 assert.strictEqual(calls.length,0);
});
test('delegate mode never writes the live session counter; direct mode consumes exactly once',async()=>{
 const d=await setup();const rk=[...d.db.data.get('daily_hundred_import_v1').entries()].find(([k])=>k.startsWith('gr-'))[0];
 await d.h(event(CHAT,d.token,original));assert.strictEqual(d.db.data.get('daily_hundred_import_v1').get(rk).used,0);
 const x=await setup({mode:'direct'});await x.h(event(CHAT,x.token,original));assert.strictEqual(x.db.data.get('daily_hundred_import_v1').get(rk).used,1);
});
test('no bank collection yet: status returns empty, not an error',async()=>{
 const db=memoryDb(),{token}=seedSession(db),h=createHandler({store:createStore({db}),upstream:async()=>providerResponse('x')});
 assert.deepStrictEqual(JSON.parse((await h(event(BANK_STATUS,token,{}))).body),{hash:null,count:0});
});
test('banks are isolated per owner and status reports hash/count',async()=>{
 const {h,db,token}=await setup();const other=seedSession(db,{token:'D'.repeat(43),owner:'i-other'});
 const s1=JSON.parse((await h(event(BANK_STATUS,token,{}))).body),s2=JSON.parse((await h(event(BANK_STATUS,other.token,{}))).body);
 assert.deepStrictEqual(s1,{hash,count:2});assert.deepStrictEqual(s2,{hash:null,count:0});
});
test('multi-chunk upload completes only when every chunk exists',async()=>{
 const {h,token,store}=await setup({bank:false});const H='b'.repeat(64);
 let r=await h(event(BANK_CHUNK,token,{hash:H,index:1,total:2,items:[bankItems[1]]}));assert.strictEqual(r.statusCode,409);
 r=await h(event(BANK_CHUNK,token,{hash:H,index:0,total:2,items:[bankItems[0]]}));assert.deepStrictEqual(JSON.parse(r.body),{stored:0,complete:false});
 r=await h(event(BANK_CHUNK,token,{hash:H,index:1,total:2,items:[bankItems[1]]}));assert.deepStrictEqual(JSON.parse(r.body),{stored:1,complete:true,count:2});
 assert.strictEqual((await store.loadBank('i0123')).items.length,2);
});
test('invalid chunk payloads are rejected',async()=>{
 const {h,token}=await setup({bank:false});
 for(const p of [{hash:'x',index:0,total:1,items:bankItems},{hash,index:1,total:1,items:bankItems},{hash,index:0,total:1,items:[]},{hash,index:0,total:1,items:[{q:''}]}])
  assert.strictEqual((await h(event(BANK_CHUNK,token,p))).statusCode,400);
});
test('prefix-stripped paths from the HTTP service are accepted',async()=>{
 const {h,token}=await setup();const r=await h({...event(CHAT,token,original),path:'/openai/chat/completions'});assert.strictEqual(r.statusCode,200);
 assert.strictEqual(JSON.parse((await h({...event(BANK_STATUS,token,{}),path:'/bank/status'})).body).count,2);
});
test('unknown path and wrong method',async()=>{
 const {h,token}=await setup({bank:false});assert.strictEqual((await h(event('/api/import-ai/v1/openai/chat/completions',token,original))).statusCode,404);
 assert.strictEqual((await h({...event(CHAT,token,original),httpMethod:'GET'})).statusCode,405);
});
