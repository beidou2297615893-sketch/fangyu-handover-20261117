'use strict';
const test=require('node:test'),assert=require('node:assert');
const {normalize,prepare,topK}=require('../lib/match.cjs');
test('normalize strips numbering, type tags and punctuation',()=>{
 assert.strictEqual(normalize('第 3 题 单选题：中国的首都是哪座城市？'),'中国的首都是哪座城市');
 assert.strictEqual(normalize('12. （多选）下列， 正确的是（ ）'),'下列正确的是');
 assert.strictEqual(normalize(null),'');
});
test('topK ranks the exact question first and keeps negation variants distinguishable by score',()=>{
 const bank=prepare([{q:'下列说法正确的是哪一项？'},{q:'中国的首都是哪座城市？'},{q:'铁路调度命令应由谁发布？'},{q:'下列说法不正确的是哪一项？'}]);
 const r=topK(bank,'单选题：中国的首都是哪座城市?',3);
 assert.strictEqual(r[0].item.q,'中国的首都是哪座城市？');assert.ok(r[0].score>0.95);
 const n=topK(bank,'下列说法不正确的是哪一项',2);assert.strictEqual(n[0].item.q,'下列说法不正确的是哪一项？');assert.strictEqual(n[1].item.q,'下列说法正确的是哪一项？');
});
test('truncated OCR still finds the long stem via containment',()=>{
 const bank=prepare([{q:'列车在区间被迫停车后，司机应立即采取哪些防护措施并报告车站值班员？'},{q:'无关题目一二三'}]);
 const r=topK(bank,'列车在区间被迫停车后，司机应立即采取哪些防护措施',1);assert.ok(r[0].score>0.8);
});
test('no overlap returns low scores or nothing',()=>{
 const bank=prepare([{q:'铁路信号机的显示方式'}]);const r=topK(bank,'光合作用发生在叶绿体',5);assert.ok(r.length===0||r[0].score<0.2);
 assert.deepStrictEqual(topK(bank,'',5),[]);
});
test('2000-item bank retrieval is fast',()=>{
 const items=Array.from({length:2000},(_,i)=>({q:`第${i}号题目：关于铁路行车组织规则第${i*7%113}条的规定，下列哪项描述符合要求${i%17}`}));
 const p=prepare(items),t=process.hrtime.bigint();const r=topK(p,items[1234].q,5);const ms=Number(process.hrtime.bigint()-t)/1e6;
 assert.strictEqual(r[0].item,items[1234]);assert.ok(ms<200,'took '+ms);
});
