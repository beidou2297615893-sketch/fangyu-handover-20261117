'use strict';
const test=require('node:test'),assert=require('node:assert');
const {findImage,transcribeRequest,parseTranscription,augment,TRANSCRIBE_PROMPT}=require('../lib/prompt.cjs');
const original={model:'deepseek-flash',messages:[{role:'system',content:'ORIGINAL PROMPT'},{role:'user',content:[{type:'text',text:'这是第 1 题，请按系统提示词返回 JSON。'},{type:'image_url',image_url:{url:'data:image/png;base64,AAAA'}}]}],temperature:0,max_tokens:1200,response_format:{type:'json_object'}};
test('transcription uses TiJing original bank prompt and the same image',()=>{
 const img=findImage(original);assert.deepStrictEqual(img,{message:1,url:'data:image/png;base64,AAAA'});
 const t=transcribeRequest(original,img);assert.strictEqual(t.messages[0].content,TRANSCRIBE_PROMPT);assert.strictEqual(t.messages[1].content[1].image_url.url,img.url);assert.strictEqual(t.model,'deepseek-flash');
 assert.ok(TRANSCRIBE_PROMPT.startsWith('你是题库题干提取器'));
});
test('parseTranscription handles JSON, fenced JSON and plain text',()=>{
 assert.strictEqual(parseTranscription('{"question":" 中国的首都？ "}'),'中国的首都？');
 assert.strictEqual(parseTranscription('```json\n{"question":"A"}\n```'),'A');
 assert.strictEqual(parseTranscription('纯文本题干'),'纯文本题干');assert.strictEqual(parseTranscription(null),'');
});
test('augment keeps original prompt/params and inserts candidates before the image',()=>{
 const before=JSON.stringify(original);
 const a=augment(original,findImage(original),[{score:0.9,item:{q:'中国的首都是哪座城市？',o:['上海','北京'],a:[1],at:''}}]);
 assert.strictEqual(JSON.stringify(original),before,'input not mutated');
 assert.strictEqual(a.messages[0].content,'ORIGINAL PROMPT');assert.strictEqual(a.max_tokens,1200);assert.deepStrictEqual(a.response_format,{type:'json_object'});
 const parts=a.messages[1].content;assert.strictEqual(parts.length,3);assert.strictEqual(parts[0].text,original.messages[1].content[0].text);
 assert.match(parts[1].text,/标准答案：B\. 北京/);assert.strictEqual(parts[2].type,'image_url');
});
test('candidate without option list falls back to answer_text',()=>{
 const a=augment(original,findImage(original),[{score:0.8,item:{q:'判断：地球是圆的',o:[],a:[],at:'正确'}}]);
 assert.match(a.messages[1].content[1].text,/标准答案：正确/);
});
