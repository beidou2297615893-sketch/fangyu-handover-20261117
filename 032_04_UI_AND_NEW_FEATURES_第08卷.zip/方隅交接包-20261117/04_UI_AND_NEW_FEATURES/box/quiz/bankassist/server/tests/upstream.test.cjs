'use strict';
const test=require('node:test'),assert=require('node:assert');const {EventEmitter}=require('node:events');
const {delegateUpstream,directUpstream,withThinkingOff,LIVE_FUNCTION,LIVE_PATH}=require('../lib/upstream.cjs');
test('delegate calls the unchanged live function with an HTTP-shaped event and decodes base64',async()=>{
 let seen;const up=delegateUpstream({callFunction:async o=>{seen=o;return {result:{statusCode:200,headers:{'content-type':'application/json'},body:Buffer.from('{"ok":1}').toString('base64'),isBase64Encoded:true}}}});
 const r=await up('T'.repeat(43),Buffer.from('{"a":1}'));
 assert.strictEqual(seen.name,LIVE_FUNCTION);assert.strictEqual(seen.data.path,LIVE_PATH);assert.strictEqual(seen.data.headers.authorization,'Bearer '+'T'.repeat(43));assert.strictEqual(seen.data.body,'{"a":1}');
 assert.strictEqual(r.statusCode,200);assert.strictEqual(r.body.toString(),'{"ok":1}');
});
test('thinking disabled only when absent',()=>{
 assert.deepStrictEqual(JSON.parse(withThinkingOff(Buffer.from('{"a":1}'))),{a:1,thinking:{type:'disabled'}});
 assert.strictEqual(withThinkingOff(Buffer.from('{"thinking":{"type":"enabled"}}')).toString(),'{"thinking":{"type":"enabled"}}');
});
test('direct mode posts to DeepSeek with the configured key',async()=>{
 let url,opts,sent;const req=(u,o,cb)=>{url=u;opts=o;const r=new EventEmitter();r.end=b=>{sent=b;const res=new EventEmitter();res.statusCode=200;res.headers={'content-type':'application/json'};cb(res);res.emit('data',Buffer.from('{"x":1}'));res.emit('end')};r.on=EventEmitter.prototype.on;r.destroy=()=>{};return r};
 const r=await directUpstream({providerKey:'sk-testkey',requestImpl:req})('t',Buffer.from('{"m":1}'));
 assert.strictEqual(url,'https://api.deepseek.com/chat/completions');assert.strictEqual(opts.headers.authorization,'Bearer sk-testkey');assert.deepStrictEqual(JSON.parse(sent),{m:1,thinking:{type:'disabled'}});assert.strictEqual(r.body.toString(),'{"x":1}');
});
