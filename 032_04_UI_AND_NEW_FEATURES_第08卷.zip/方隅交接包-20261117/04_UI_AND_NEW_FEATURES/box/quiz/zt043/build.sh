set -e
export JAVA_HOME=/workspace/jdk/jdk-17.0.21+9 ANDROID_SDK_ROOT=/workspace/android-sdk ANDROID_HOME=/workspace/android-sdk GRADLE_USER_HOME=/workspace/zt043/gradle-home
export PATH=$JAVA_HOME/bin:$PATH
cd /workspace/zt043
[ -d gradle-8.7 ] || { curl -sSL -o g.zip https://services.gradle.org/distributions/gradle-8.7-bin.zip && unzip -q g.zip && rm g.zip; }
yes | $ANDROID_SDK_ROOT/cmdline-tools/latest/bin/sdkmanager --sdk_root=$ANDROID_SDK_ROOT "platforms;android-35" "build-tools;35.0.0" >/dev/null
./gradle-8.7/bin/gradle -p proj --no-daemon :app:assembleProdDebug
