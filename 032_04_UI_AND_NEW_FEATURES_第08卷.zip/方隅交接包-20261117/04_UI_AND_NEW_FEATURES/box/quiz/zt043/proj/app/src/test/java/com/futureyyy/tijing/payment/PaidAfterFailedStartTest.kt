package com.futureyyy.tijing.payment

import org.junit.Assert.*
import org.junit.Test
import org.json.JSONObject

/** 知题 0.4.3 regression: start before paying -> background release -> pay -> start must work. */
class PaidAfterFailedStartTest {
    // Mirrors AndroidRunLedger (patched hasOtherUnresolvedReservation).
    private class Ledger:RunLedger {
        val rows=linkedMapOf<String,BillingRun>()
        override fun read(id:String)=rows[id]
        override fun save(run:BillingRun) { rows[run.id]=run }
        override fun freeRemaining()=0
        override fun hasUnknownSubmission()=rows.values.any { it.submissionState=="unknown" }
        override fun hasOtherUnresolvedReservation(id:String)=rows.values.any { it.id!=id && it.phase=="reserving" }
        override fun releasingIds()=rows.values.filter { it.phase in setOf("reserving","releasing") && it.submissionState=="none" }.map { it.id }
    }
    // Mirrors payment-runs.js reserve/cancel: cancel of an unknown run writes a tombstone; reserve on a tombstone fails.
    private class Server:BillingTransport {
        var paid=false; val runs=mutableMapOf<String,String>()
        override fun request(path:String,method:String,body:JSONObject?,identity:BillingIdentity?):JSONObject {
            val b=body!!;val id=if(path=="/runs/reserve") b.getString("runId") else path.split("/")[2]
            val out=JSONObject().put("ownerId","owner").put("runId",id).put("taskBinding",b.getString("taskBinding"))
            return when {
                path=="/runs/reserve" -> { if(runs[id]=="tombstone" || !paid) throw IllegalStateException("run unavailable");runs[id]="reserved";out.put("status","reserved").put("source","subscription") }
                path.endsWith("/cancel") -> { runs[id]=if(runs[id]==null)"tombstone" else "released";out.put("status","cancelled") }
                else -> error(path)
            }
        }
    }
    // Mirrors patched GatewaySessionEntry.getOrCreateRunId.
    private var saved:String?=null; private var n=0
    private fun runId(l:Ledger,patched:Boolean):String { val e=saved
        val stale=patched && e!=null && l.read(e).let { it==null || it.phase in setOf("released","releasing") }
        if(e!=null && !stale)return e; n++; saved="run$n"; return saved!! }

    private fun scenario(patched:Boolean):String? {
        val l=Ledger();val s=Server()
        val b=RunBilling(PaymentConfig(PaymentConfig.ORIGIN,PaymentConfig.ORIGIN,true),l,s,{BillingIdentity("owner","token")},{"sig"})
        val first=runId(l,patched)
        assertThrows(IllegalStateException::class.java) { b.start(first,"target.pkg","original-tijing-v1") } // not paid yet
        b.recoverReleases()           // app back to foreground (from Alipay): background refresh releases it
        s.paid=true                   // user pays 9.9 month plan
        return try { val id=runId(l,patched);b.start(id,"target.pkg","original-tijing-v1");assertEquals("reserved",l.read(id)?.phase);null }
            catch(e:PaymentFailure) { e.message }
    }
    @Test fun oldBuildReproducesUserMessage() { assertEquals("本次任务需要先核对付款记录。",scenario(false)) }
    @Test fun patchedBuildStartsWithSubscription() { assertNull(scenario(true)) }
}
