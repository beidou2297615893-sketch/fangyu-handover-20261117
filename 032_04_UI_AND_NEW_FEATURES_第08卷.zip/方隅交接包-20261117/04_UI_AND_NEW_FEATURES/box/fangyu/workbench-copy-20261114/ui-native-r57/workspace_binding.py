"""Read-only, per-client production data authority. Never creates a workspace."""
import json
from pathlib import Path
import re
import stat

COMPANY_ID = 'fangyu-apartment-client'
SCHEMA = 'fangyu-production-workspace-v1'
BINDING_RELATIVE = Path('work/ui-native-r57/state/production-workspace.json')


class WorkspaceBindingError(RuntimeError):
    def __init__(self, code, message):
        super().__init__(message)
        self.code = code


def _plain(path, *, directory=False):
    for item in (path, *path.parents):
        info = item.lstat()
        if item.is_symlink() or getattr(info, 'st_file_attributes', 0) & 0x400:
            raise WorkspaceBindingError('WORKSPACE_BINDING_PATH_INVALID',
                '工作资料位置包含链接或重定向，请管理员核对原资料位置后重新打开。')
    info = path.stat()
    if (directory and not stat.S_ISDIR(info.st_mode) or not directory
            and (not stat.S_ISREG(info.st_mode) or info.st_nlink != 1)):
        raise WorkspaceBindingError('WORKSPACE_BINDING_PATH_INVALID',
            '工作资料位置无效，请管理员核对原资料位置后重新打开。')
    return info


def _read(path, limit):
    before = _plain(path)
    if before.st_size > limit:
        raise WorkspaceBindingError('WORKSPACE_BINDING_INVALID', '工作资料设置无效，请管理员修复后重新打开。')
    with path.open('rb') as stream:
        opened = stream.fileno()
        import os
        opened = os.fstat(opened)
        raw = stream.read(limit + 1)
        ended = os.fstat(stream.fileno())
    after = _plain(path)
    identity = lambda value: (value.st_dev, value.st_ino, value.st_size, value.st_mtime_ns)
    if len(raw) > limit or not identity(before) == identity(opened) == identity(ended) == identity(after):
        raise WorkspaceBindingError('WORKSPACE_BINDING_CHANGED', '工作资料设置发生变化，请重新打开。')
    return raw


def read_device_identity(path):
    """The existing Windows DPAPI read boundary, projected to stable metadata only."""
    import ctypes
    from ctypes import wintypes
    raw = _read(path, 131072)
    class Blob(ctypes.Structure):
        _fields_ = [('size', wintypes.DWORD), ('data', ctypes.POINTER(ctypes.c_byte))]
    data = ctypes.create_string_buffer(raw)
    source = Blob(len(raw), ctypes.cast(data, ctypes.POINTER(ctypes.c_byte)))
    result = Blob()
    api = ctypes.windll.crypt32.CryptUnprotectData
    api.argtypes = [ctypes.POINTER(Blob), ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p,
                   ctypes.c_void_p, wintypes.DWORD, ctypes.POINTER(Blob)]
    api.restype = wintypes.BOOL
    if not api(ctypes.byref(source), None, None, None, None, 1, ctypes.byref(result)):
        raise ValueError('device_binding_unavailable')
    try:
        if result.size > 131072:
            raise ValueError('device_binding_unavailable')
        value = json.loads(ctypes.string_at(result.data, result.size))
        device = value.get('device') or {}
        if (value.get('state') != 'bound' or not isinstance(device, dict)
                or not isinstance(value.get('token'), str)
                or not re.fullmatch(r'[A-Za-z0-9_-]{40,100}', value['token'])):
            raise ValueError('device_binding_unavailable')
        return {'state': value['state'], 'company_id': value.get('company_id'),
            'environment_id': value.get('environment_id'), 'device_id': device.get('id'),
            'owner': device.get('owner')}
    finally:
        ctypes.windll.kernel32.LocalFree.argtypes = [ctypes.c_void_p]
        ctypes.windll.kernel32.LocalFree(ctypes.cast(result.data, ctypes.c_void_p))


def resolve_workspace(project_root, *, company_id=COMPANY_ID):
    """Select the declared existing directory independently of LOCALAPPDATA.

    Stable device metadata anchors this installation to its reviewed vault;
    credentials never leave the DPAPI reader. No lease, migration or enrollment.
    """
    config = Path(project_root).absolute() / BINDING_RELATIVE
    try:
        raw = _read(config, 16384)
    except FileNotFoundError:
        raise WorkspaceBindingError('WORKSPACE_BINDING_MISSING',
            '工作资料位置尚未确认，请管理员修复后重新打开。已有资料不会被新建或替换。') from None
    except OSError:
        raise WorkspaceBindingError('WORKSPACE_BINDING_UNAVAILABLE',
            '工作资料设置暂不可读，请管理员核对后重新打开。') from None
    try:
        value = json.loads(raw.decode('utf-8-sig'))
        required = {'schema', 'company_id', 'data_dir', 'device_id', 'owner', 'environment_id'}
        if (type(value) is not dict or set(value) != required or value['schema'] != SCHEMA
                or value['company_id'] != company_id or company_id != COMPANY_ID
                or type(value['data_dir']) is not str or value['data_dir'] != value['data_dir'].strip()
                or not re.fullmatch(r'[A-Za-z0-9_-]{16,80}', value['device_id'])
                or not re.fullmatch(r'[A-Za-z0-9_.@-]{3,80}', value['owner'])
                or not re.fullmatch(r'[A-Za-z0-9_-]{3,100}', value['environment_id'])):
            raise ValueError
        directory = Path(value['data_dir'])
        if not directory.is_absolute() or '..' in directory.parts or str(directory).startswith('\\\\'):
            raise ValueError
    except (ValueError, TypeError, KeyError, UnicodeError):
        raise WorkspaceBindingError('WORKSPACE_BINDING_INVALID',
            '工作资料设置无效，请管理员核对所属企业和原资料位置后重新打开。') from None
    try:
        _plain(directory, directory=True)
        # Read only a bounded header. SQLite is never opened or repaired here.
        database = directory / 'workspace.sqlite3'
        info = _plain(database)
        if info.st_size < 100:
            raise ValueError
        with database.open('rb') as stream:
            if stream.read(16) != b'SQLite format 3\0':
                raise ValueError
        identity = read_device_identity(directory / 'assistant/device.dpapi')
        if any(identity.get(key) != value[key] for key in
                ('company_id', 'environment_id', 'device_id', 'owner')):
            raise WorkspaceBindingError('WORKSPACE_BINDING_DEVICE_MISMATCH',
                '工作资料与原电脑绑定不一致，请管理员核对后重新打开。请保留现有资料。')
        resolved = directory.resolve(strict=True)
        if resolved != directory:
            raise WorkspaceBindingError('WORKSPACE_BINDING_PATH_INVALID',
                '工作资料位置发生重定向，请管理员核对原资料位置后重新打开。')
        return resolved
    except WorkspaceBindingError:
        raise
    except (OSError, ValueError, TypeError, AttributeError):
        raise WorkspaceBindingError('WORKSPACE_BINDING_DATA_UNAVAILABLE',
            '原工作资料暂不可用，请管理员恢复原资料位置后重新打开。不会创建新的资料或电脑绑定。') from None
