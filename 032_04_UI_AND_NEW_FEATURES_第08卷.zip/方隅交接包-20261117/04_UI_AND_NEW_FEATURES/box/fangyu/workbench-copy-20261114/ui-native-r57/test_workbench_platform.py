"""Public gateway behavior over real employee auth and an isolated platform boundary."""
from pathlib import Path
import importlib
import sys
import tempfile
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT/'work/ui-runtime-r55/src'))
sys.path.insert(0, str(Path(__file__).resolve().parent))
from core.engine import Core
from test_workbench_backend import CloudFixture
from workbench_backend import WorkbenchBackend, WorkbenchError


class PlatformBoundary:
    def __init__(self, project_root, data_dir, company):
        self.core = Core(data_dir, defer_startup_recovery=True)
        self.core.deployment_config = company
        self.calls = []
        self.closed = False

    def snapshot(self, user):
        return {'device': {'state': 'unbound', 'bound': False}, 'accounts': [],
                'platforms': [], 'acquisition': {'taskId': '', 'status': 'idle'}}

    def start_acquisition(self, user, data):
        self.calls.append(dict(data))
        return {'taskId': 'fixture-task-1', 'status': 'queued'}

    def close(self):
        self.closed = True
        self.core.adapters.close()


class PlatformGatewayBehavior(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(dir=ROOT/'work')
        self.cloud = CloudFixture()
        self.patch = patch('integrations.request_json', side_effect=self.cloud)
        self.patch.start()
        self.company = {'id': 'fangyu-apartment-client', 'name': '方隅测试', 'edition': 'customer',
            'personalMode': False, 'authMode': 'managed', 'platforms': ['xiaohongshu'],
            'keywords': ['附近公寓'], 'managedWorkspace': {'environment_id': 'fixture-env',
            'endpoint': 'https://example.invalid/workspace'}}
        self.backend = WorkbenchBackend(ROOT, data_dir=self.temp.name, company=self.company,
                                        platform_factory=PlatformBoundary)
        self.login = self.backend.dispatch('login', {'username': 'fixture-employee',
            'password': '[REDACTED:assigned_secret]', 'rememberUsername': False})
        self.token = self.login['token']

    def tearDown(self):
        if hasattr(self, 'backend'):
            self.backend.close()
        self.patch.stop()
        self.temp.cleanup()

    def apply(self):
        return self.backend.dispatch('apply_preset', {'storeId': 'fixture-store-a',
            'searchPresetId': 'precise', 'intentPresetId': 'standard', 'expectedRevision': 0}, self.token)

    def test_shared_core_and_platform_snapshot_require_employee_session(self):
        self.assertIs(self.backend.core, self.backend.platform_runtime.core)
        with self.assertRaises(WorkbenchError) as error:
            self.backend.dispatch('platform_snapshot', {})
        self.assertEqual(error.exception.code, 'AUTH_REQUIRED')
        state = self.backend.dispatch('platform_snapshot', {}, self.token)
        self.assertEqual(state['platform']['device']['state'], 'unbound')

    def test_start_reuses_applied_preset_and_does_not_replay_duplicate_request(self):
        applied = self.apply()
        data = {'storeId': 'fixture-store-a', 'expectedRevision': applied['selection']['revision'],
                'platform': 'xiaohongshu', 'accountId': 'fixture-account', 'region': '',
                'time': '最近7天', 'requestId': 'fixture-request-0001'}
        first = self.backend.dispatch('acquisition_start', data, self.token)
        second = self.backend.dispatch('acquisition_start', data, self.token)
        self.assertEqual(first['job'], second['job'])
        self.assertEqual(self.backend.platform_runtime.calls[0]['keywords'], ['附近公寓'])
        self.assertEqual(len(self.backend.platform_runtime.calls), 1)
        for invalid in ({**data, 'storeId': 'another-store'},
                        {**data, 'platform': 'douyin'}, {**data, 'keywords': ['injected']}):
            with self.assertRaises(WorkbenchError):
                self.backend.dispatch('acquisition_start', invalid, self.token)

    def test_unknown_start_is_not_replayed(self):
        self.apply()
        data = {'storeId': 'fixture-store-a', 'expectedRevision': 1, 'platform': 'xiaohongshu',
            'accountId': 'fixture-account', 'region': '', 'time': '最近7天',
            'requestId': 'fixture-unconfirmed-0001'}
        def lost_receipt(user, values):
            self.backend.platform_runtime.calls.append(values)
            raise OSError('fixture receipt lost after dispatch')
        self.backend.platform_runtime.start_acquisition = lost_receipt
        with self.assertRaises(WorkbenchError):
            self.backend.dispatch('acquisition_start', data, self.token)
        with self.assertRaises(WorkbenchError) as error:
            self.backend.dispatch('acquisition_start', data, self.token)
        self.assertEqual(error.exception.code, 'REQUEST_UNCONFIRMED')
        with self.assertRaises(WorkbenchError) as changed:
            self.backend.dispatch('acquisition_start', {**data, 'requestId': 'fixture-new-request-0002'}, self.token)
        self.assertEqual(changed.exception.code, 'REQUEST_UNCONFIRMED')
        self.assertEqual(len(self.backend.platform_runtime.calls), 1)
        state = self.backend.dispatch('platform_snapshot', {}, self.token)['platform']
        self.assertEqual(state['lastRequest']['requestId'], data['requestId'])
        self.assertEqual(state['lastRequest']['state'], 'unconfirmed')
        self.assertEqual(state['lastRequest']['conditions'], {
            key: data[key] for key in ('storeId', 'platform', 'accountId', 'region', 'time', 'expectedRevision')})

    def test_changed_keyword_library_requires_reapplying_preset(self):
        self.apply()
        self.backend.company['keywords'] = ['已变更的搜索方向']
        with self.assertRaises(WorkbenchError) as error:
            self.backend.dispatch('acquisition_start', {'storeId': 'fixture-store-a',
                'expectedRevision': 1, 'platform': 'xiaohongshu', 'accountId': 'fixture-account',
                'region': '', 'time': '最近7天', 'requestId': 'fixture-stale-0001'}, self.token)
        self.assertEqual(error.exception.code, 'PRESET_STALE')
        self.assertEqual(self.backend.platform_runtime.calls, [])


if __name__ == '__main__':
    unittest.main()
