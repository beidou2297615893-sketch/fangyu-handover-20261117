"""Store material public API contracts over the actual temporary SQLite Store."""
import concurrent.futures
import hashlib
import json
import sys
import tempfile
import threading
import unittest
from pathlib import Path
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'work/ui-runtime-r55/src'))
sys.path.insert(0, str(Path(__file__).resolve().parent))
from core.store import Store
from store_materials import StoreMaterials, StoreMaterialsError


def fixture_catalog():
    value = {
        'schema_version': 'fangyu-store-materials-catalog/1', 'version': 'fixture-v1',
        'rulesSummary': {'version': 'fixture-draft-v2', 'enabled': False,
                         'priceVerified': False},
        'materials': [
            {'key': 'material-a', 'name': '测试甲门店', 'city': '上海', 'district': '测试区',
             'status': 'candidate', 'noteIds': ['01'], 'sourceRefs': ['first:01T'],
             'keywordIds': ['KA', 'KT', 'KS'], 'heldKeywordIds': ['KH'],
             'publicFactsSummary': [], 'priceVerified': False},
            {'key': 'material-b', 'name': '测试乙门店', 'city': '上海', 'district': '测试区',
             'status': 'candidate', 'noteIds': ['02'], 'sourceRefs': ['middle:02T'],
             'keywordIds': ['KB', 'KS'], 'heldKeywordIds': [],
             'publicFactsSummary': [], 'priceVerified': False},
            {'key': 'expired-material', 'name': '过期资料', 'city': '杭州', 'district': '',
             'status': 'expired', 'noteIds': ['17'], 'sourceRefs': [],
             'keywordIds': [], 'heldKeywordIds': [], 'publicFactsSummary': [],
             'priceVerified': False},
        ],
        'keywords': [], 'sourceArtifacts': [], 'sourceNotes': [], 'sources': [],
        'counts': {'materials': 3, 'keywords': 5},
    }
    for ident, word, eligible, keys, presets in [
        ('KA', '甲店租房', True, ['material-a'], ['precise']),
        ('KT', '甲店地铁租房', True, ['material-a'], ['precise', 'commute']),
        ('KB', '乙店租房', True, ['material-b'], ['precise']),
        ('KS', '测试区公寓', True, ['material-a', 'material-b'], ['precise']),
        ('KH', '月租999元', False, ['material-a'], ['precise']),
    ]:
        value['keywords'].append({'id': ident, 'keyword': word, 'priority': 75,
            'group': '测试分组', 'enabled': False, 'csvCandidateEligible': eligible,
            'volume': 'Unknown', 'difficulty': 'Unknown',
            'bindings': [{'materialKey': key, 'csvCandidateEligible': eligible,
                'presetIds': presets, 'sourceRefs': ['first:01T' if key == 'material-a' else 'middle:02T'],
                'noteIds': ['01' if key == 'material-a' else '02'],
                'sourceArtifactId': 'first' if key == 'material-a' else 'middle',
                'rawKeywordId': ident, 'rawKeywordPointer': None,
                'holdReasons': [] if eligible else ['price_not_verified']}
                for key in keys]})
    value['digest'] = hashlib.sha256(json.dumps(value, ensure_ascii=False,
        sort_keys=True, separators=(',', ':'), allow_nan=False).encode()).hexdigest()
    return value


class StoreMaterialBehavior(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(dir=ROOT / 'work')
        self.directory = Path(self.temp.name)
        self.path = self.directory / 'catalog.json'
        self.package = fixture_catalog()
        self.path.write_text(json.dumps(self.package, ensure_ascii=False), encoding='utf-8')
        self.core = SimpleNamespace(store=Store(self.directory / 'db'), lock=threading.RLock())
        self.user = {'id': 'user-a', 'tenant_id': 'tenant-a', 'username': 'employee-a',
                     'role': 'operator', 'cloud_bound': True, 'disabled': False}
        self.core.store.put('users', self.user)
        self.service = StoreMaterials(self.core, self.path)

    def tearDown(self):
        self.temp.cleanup()

    def test_catalog_offers_disabled_candidates_without_guessing_store_mapping(self):
        catalog = self.service.catalog(self.user, [{'id': 'opaque-a', 'name': '授权门店'}])
        self.assertEqual(catalog['cities'], ['上海', '杭州'])
        self.assertEqual(catalog['materials'][0]['name'], '测试甲门店')
        self.assertEqual(catalog['currentSelection']['revision'], 0)
        self.assertEqual(catalog['currentSelection']['materialKey'], None)
        self.assertEqual(catalog['storeIdMappingStatus'], 'pending_explicit_confirmation')
        self.assertEqual(catalog['materials'][0]['selectableKeywordIds'], ['KA', 'KT', 'KS'])
        self.assertEqual(catalog['materials'][0]['heldKeywordIds'], ['KH'])
        self.assertFalse(catalog['keywords'][0]['enabled'])
        self.assertEqual(catalog['keywords'][0]['volume'], 'Unknown')
        self.assertEqual(catalog['rulesSummary']['priceVerified'], False)
        self.assertNotIn('actualStoreId', catalog['materials'][0])

    def test_catalog_material_words_expose_their_own_eligible_bindings(self):
        result = self.service.catalog(self.user, [{'id': 'opaque-a'}])
        material_a, material_b = result['materials'][:2]
        words_a = {row['id']: row for row in material_a['keywords']}
        words_b = {row['id']: row for row in material_b['keywords']}
        self.assertEqual(set(words_a), {'KA', 'KT', 'KS', 'KH'})
        self.assertTrue(words_a['KA']['eligible'])
        self.assertFalse(words_a['KH']['eligible'])
        self.assertNotIn('KA', words_b)
        self.assertEqual(words_a['KS']['sourceRefs'], ['first:01T'])
        self.assertEqual(words_b['KS']['sourceRefs'], ['middle:02T'])

    def save(self, store='opaque-a', material='material-a', words=None, revision=0, **kwargs):
        return self.service.save_selection(self.user, store, material,
            ['KA', 'KT', 'KS'] if words is None else words, revision,
            confirm_binding=True, expected_catalog_digest=self.package['digest'], **kwargs)

    def test_explicit_selection_becomes_available_and_reopen_restores_exact_provenance(self):
        saved = self.save(words=['KT', 'KA'])
        self.assertEqual(saved['revision'], 1)
        self.assertEqual(saved['selectedKeywords'], ['甲店地铁租房', '甲店租房'])
        self.assertEqual(saved['source_material_name'], '测试甲门店')
        self.assertEqual(saved['bindingConfidence'], 'explicit_user_confirmed')
        self.assertEqual(saved['searchPresets']['commute']['keywords'], ['甲店地铁租房'])
        self.assertEqual(saved['searchPresets']['precise']['keywords'], saved['selectedKeywords'])
        self.assertEqual(saved['keywordBindings'][0]['sourceRefs'], ['first:01T'])
        self.assertEqual(saved['keywordBindings'][0]['noteIds'], ['01'])
        self.assertFalse(saved['startsCollection'])
        self.assertFalse(saved['callsAI'])
        self.assertFalse(saved['priceVerified'])
        reopened = StoreMaterials(self.core, self.path)
        self.assertEqual(reopened.read_selection(self.user, 'opaque-a'), saved)
        catalog = reopened.catalog(self.user, [{'id': 'opaque-a'}], {'storeId': 'opaque-a'})
        self.assertEqual(catalog['currentSelection'], saved)

    def test_existing_confirmed_binding_can_edit_words_but_remapping_needs_new_confirmation(self):
        self.save(words=['KA'])
        saved = self.service.save_selection(self.user, 'opaque-a', 'material-a', ['KT'], 1,
            expected_catalog_digest=self.package['digest'])
        self.assertEqual(saved['revision'], 2)
        self.assertEqual(saved['selectedKeywords'], ['甲店地铁租房'])
        self.assertEqual(saved['bindingConfidence'], 'existing_user_confirmed')
        with self.assertRaises(StoreMaterialsError) as caught:
            self.service.save_selection(self.user, 'opaque-a', 'material-b', ['KB'], 2,
                expected_catalog_digest=self.package['digest'])
        self.assertEqual(caught.exception.code, 'MATERIAL_BINDING_CONFIRMATION_REQUIRED')
        self.assertEqual(self.service.read_selection(self.user, 'opaque-a'), saved)

    def test_external_connection_requires_active_transaction_and_can_roll_back_material_write(self):
        with self.core.store.connect() as db:
            with self.assertRaises(StoreMaterialsError) as caught:
                self.save(db=db)
            self.assertEqual(caught.exception.code, 'MATERIAL_TRANSACTION_REQUIRED')
        with self.assertRaisesRegex(RuntimeError, 'prefs failed'):
            with self.core.lock, self.core.store.connect() as db:
                db.execute('BEGIN IMMEDIATE')
                saved = self.save(db=db)
                self.assertEqual(saved['revision'], 1)
                raise RuntimeError('prefs failed')
        self.assertEqual(self.service.read_selection(self.user, 'opaque-a')['revision'], 0)

    def test_held_cross_material_and_expired_queries_cannot_apply_or_mutate_selection(self):
        saved = self.save(words=['KA'])
        for material, words, code in [
            ('material-a', ['KH'], 'MATERIAL_KEYWORD_HELD'),
            ('material-a', ['KB'], 'MATERIAL_KEYWORD_HELD'),
            ('expired-material', [], 'MATERIAL_UNAVAILABLE'),
            ('material-a', ['KA'] * 101, 'MATERIAL_KEYWORDS_INVALID'),
        ]:
            with self.subTest(material=material, code=code):
                with self.assertRaises(StoreMaterialsError) as caught:
                    self.save(material=material, words=words, revision=1)
                self.assertEqual(caught.exception.code, code)
                self.assertFalse(caught.exception.mutation_committed)
                self.assertEqual(self.service.read_selection(self.user, 'opaque-a'), saved)

    def test_same_city_stores_and_other_owner_keep_separate_selection_and_trace(self):
        first = self.save(words=['KA', 'KS'])
        second = self.save(store='opaque-b', material='material-b', words=['KB', 'KS'])
        self.assertEqual(first['keywordBindings'][1]['sourceRefs'], ['first:01T'])
        self.assertEqual(second['keywordBindings'][1]['sourceRefs'], ['middle:02T'])
        self.assertEqual(self.service.read_selection(self.user, 'opaque-a'), first)
        self.assertEqual(self.service.read_selection(self.user, 'opaque-b'), second)
        other = {**self.user, 'id': 'user-b', 'username': 'employee-b'}
        self.core.store.put('users', other)
        self.assertEqual(self.service.read_selection(other, 'opaque-a')['revision'], 0)
        own = self.service.save_selection(other, 'opaque-a', 'material-b', ['KB'], 0,
            confirm_binding=True, expected_catalog_digest=self.package['digest'])
        self.assertEqual(own['selectedKeywords'], ['乙店租房'])
        self.assertEqual(self.service.read_selection(self.user, 'opaque-a'), first)

    def test_local_actor_revocation_tenant_and_owner_changes_block_writes(self):
        saved = self.save(words=['KA'])
        for changed in [ {'disabled': True}, {'cloud_bound': False},
                {'tenant_id': 'tenant-b'}, {'username': 'employee-b'}, {'role': 'admin'} ]:
            with self.subTest(changed=changed):
                self.core.store.put('users', {**self.user, **changed})
                with self.assertRaises(StoreMaterialsError) as caught:
                    self.save(words=['KT'], revision=1)
                self.assertEqual(caught.exception.code, 'AUTH_REQUIRED')
                self.core.store.put('users', self.user)
                self.assertEqual(self.service.read_selection(self.user, 'opaque-a'), saved)

    def test_two_instances_using_same_revision_commit_only_once(self):
        other_core = SimpleNamespace(store=Store(self.directory / 'db'), lock=threading.RLock())
        other = StoreMaterials(other_core, self.path)
        def save(service):
            try:
                return service.save_selection(self.user, 'opaque-a', 'material-a', ['KA'], 0,
                    confirm_binding=True, expected_catalog_digest=self.package['digest'])['revision']
            except StoreMaterialsError as error:
                return error.code
        with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
            values = list(pool.map(save, [self.service, other]))
        self.assertCountEqual(values, [1, 'MATERIAL_REVISION_CONFLICT'])
        self.assertEqual(self.service.read_selection(self.user, 'opaque-a')['revision'], 1)

    def test_catalog_change_requires_explicit_reapply_and_cleared_words_stay_empty(self):
        self.save(words=['KA'])
        revised = fixture_catalog()
        revised['version'] = 'fixture-v2'
        revised['digest'] = hashlib.sha256(json.dumps({k:v for k,v in revised.items() if k != 'digest'},
            ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()).hexdigest()
        self.path.write_text(json.dumps(revised, ensure_ascii=False), encoding='utf-8')
        updated = StoreMaterials(self.core, self.path)
        stale = updated.read_selection(self.user, 'opaque-a')
        self.assertTrue(stale['needsReapply'])
        self.assertFalse(stale['currentBindingConfirmed'])
        self.assertEqual(stale['selectedKeywords'], [])
        self.assertEqual(stale['searchPresets']['commute']['keywords'], [])
        with self.assertRaises(StoreMaterialsError) as caught:
            updated.save_selection(self.user, 'opaque-a', 'material-a', ['KA'], 1,
                confirm_binding=True, expected_catalog_digest=self.package['digest'])
        self.assertEqual(caught.exception.code, 'MATERIAL_CATALOG_STALE')
        with self.assertRaises(StoreMaterialsError) as caught:
            updated.save_selection(self.user, 'opaque-a', 'material-a', ['KA'], 1,
                expected_catalog_digest=revised['digest'])
        self.assertEqual(caught.exception.code, 'MATERIAL_BINDING_CONFIRMATION_REQUIRED')
        cleared = updated.save_selection(self.user, 'opaque-a', 'material-a', [], 1,
            confirm_binding=True, expected_catalog_digest=revised['digest'])
        self.assertFalse(cleared['needsReapply'])
        self.assertEqual(StoreMaterials(self.core, self.path).read_selection(self.user, 'opaque-a')['selectedKeywords'], [])

    def test_file_hash_pin_uses_raw_bytes_and_accepts_uppercase_expected_hash(self):
        sha = hashlib.sha256(self.path.read_bytes()).hexdigest()
        self.assertEqual(StoreMaterials(self.core, self.path, expected_sha256=sha.upper()).rule_version, 'fixture-draft-v2')
        self.path.write_bytes(self.path.read_bytes() + b'\n')
        with self.assertRaises(StoreMaterialsError) as caught:
            StoreMaterials(self.core, self.path, expected_sha256=sha)
        self.assertEqual(caught.exception.code, 'MATERIAL_CATALOG_INVALID')

    def test_read_with_outer_core_lock_and_default_save_finish_without_lock_inversion(self):
        with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
            def reader():
                with self.core.lock:
                    return self.service.read_selection(self.user, 'opaque-a')['revision']
            read = pool.submit(reader)
            saved = pool.submit(self.save)
            self.assertIn(read.result(timeout=5), (0, 1))
            self.assertEqual(saved.result(timeout=5)['revision'], 1)


class RuntimeCatalogBehavior(unittest.TestCase):
    def test_actual_pack_is_safe_and_preserves_held_terms_and_duplicate_sources(self):
        with tempfile.TemporaryDirectory(dir=ROOT / 'work') as directory:
            core = SimpleNamespace(store=Store(directory), lock=threading.RLock())
            user = {'id': 'fixture-runtime-user', 'tenant_id': 'fixture-runtime-tenant',
                'username': 'fixture-runtime-owner', 'role': 'operator',
                'cloud_bound': True, 'disabled': False}
            core.store.put('users', user)
            service = StoreMaterials(core)
            catalog = service.catalog(user, [{'id': 'opaque-fixture-store'}])
            self.assertEqual(len(catalog['materials']), 14)
            self.assertEqual(len(catalog['keywords']), 361)
            self.assertEqual(sum(word['csvCandidateEligible'] for word in catalog['keywords']), 290)
            self.assertEqual(catalog['intentRule']['version'], '2026-10-16-intent-budget-income-draft-v2')
            self.assertFalse(catalog['intentRule']['currentPricesVerified'])
            materials = {row['key']: row for row in catalog['materials']}
            self.assertEqual(materials['sh_zhongjun']['noteIds'], ['03', '04', '05'])
            self.assertEqual(materials['pending_note_17']['keywords'], [])
            self.assertEqual(materials['pending_note_17']['captureStatus'], 'expired')
            self.assertEqual(materials['candidate_上海龙柏方隅']['captureStatus'], 'partial_media')
            self.assertEqual(materials['fz_baihuting']['captureStatus'], 'partial_media')
            exported = json.dumps(catalog, ensure_ascii=False)
            self.assertNotRegex(exported, r'[A-Za-z]:[\\/]')
            self.assertNotRegex(exported, r'(?<!\d)1[3-9]\d{9}(?!\d)')
            self.assertTrue(all(len(row['selectableKeywordIds']) <= 100 for row in catalog['materials']))
            self.assertTrue(all(len(word['keyword']) <= 80 for word in catalog['keywords']))


if __name__ == '__main__':
    unittest.main()
