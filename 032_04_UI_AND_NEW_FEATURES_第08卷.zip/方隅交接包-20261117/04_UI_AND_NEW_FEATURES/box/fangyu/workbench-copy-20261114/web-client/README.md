# 方隅自动获客系统 · 云端网页客户端预览壳

用官方 Electron 快速开始结构（`main.js` + `preload.js`，npm 包 `electron`）把已有的 `打开预览.html` 包进桌面窗口，没有另画一套界面，也没有用 screenshot-to-code 重新生成。

## 启动

```bash
cd /workspace/fangyu-workbench-copy-20261114/web-client
npm install
npm start
```

窗口标题是「方隅自动获客系统」，默认约 1280×820。页顶工具条可切换四态、设置、客户侧栏和悬浮窗，和浏览器里打开预览一样。

本云电脑没有可用的 chrome-sandbox，启动命令已带 `--no-sandbox`。截四态主界面：

```bash
npm run shots
```

图在 `preview-shots/`。待开始四格是 —；其它态里的 86 / 54 / 32 / 1286 只是预览示意，不是真实统计。

## 这还只是云端预览壳

- 全部文件只在本云电脑副本的 `web-client/`，不会改、不会替换本机正在用的安装（原来的 pywebview / WebView2 壳仍保留）。
- 启动／暂停／知道了／登录按钮不会真的采集或发送，也不会连接现场 Bridge。
- 未打包安装包，未接到真实工作台后端。
