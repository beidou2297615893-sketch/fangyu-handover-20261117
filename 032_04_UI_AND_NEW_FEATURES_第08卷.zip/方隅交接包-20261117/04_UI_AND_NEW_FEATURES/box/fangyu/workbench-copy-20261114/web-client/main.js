const { app, BrowserWindow, ipcMain, nativeImage } = require('electron');
const path = require('path');
const fs = require('fs');

const TITLE = '方隅自动获客系统';
const PREVIEW_HTML = path.resolve(__dirname, '..', '打开预览.html');
const ICON_PATH = path.resolve(__dirname, '..', 'preview-assets', 'logo-mark-on-dark.png');
const SHOT_DIR = path.join(__dirname, 'preview-shots');
const SHOT_VIEWS = [
  { view: 'idle', file: '01-待开始.png' },
  { view: 'running', file: '02-运行中.png' },
  { view: 'need', file: '03-需要你处理.png' },
  { view: 'paused', file: '04-已安全暂停.png' }
];

function icon() {
  if (!fs.existsSync(ICON_PATH)) return undefined;
  return nativeImage.createFromPath(ICON_PATH);
}

function attachWindowControls(win) {
  ipcMain.removeAllListeners('window-minimize');
  ipcMain.removeAllListeners('window-maximize');
  ipcMain.removeAllListeners('window-close');
  ipcMain.on('window-minimize', () => {
    if (!win.isDestroyed()) win.minimize();
  });
  ipcMain.on('window-maximize', () => {
    if (win.isDestroyed()) return;
    if (win.isMaximized()) win.unmaximize();
    else win.maximize();
  });
  ipcMain.on('window-close', () => {
    if (!win.isDestroyed()) win.close();
  });
}

function hookPreviewChrome(win) {
  const script = `(() => {
    if (window.__fangyuShellHooked) return;
    window.__fangyuShellHooked = true;
    const style = document.createElement('style');
    style.textContent = '.fy-titlebar{-webkit-app-region:drag;} .fy-titlebar button,.fy-pills,.fy-winbtns,.fy-gear{-webkit-app-region:no-drag;}';
    document.head.appendChild(style);
    document.addEventListener('click', (event) => {
      const btn = event.target.closest && event.target.closest('.win');
      if (!btn || !window.fangyuShell) return;
      event.preventDefault();
      if (btn.classList.contains('min')) window.fangyuShell.minimize();
      else if (btn.classList.contains('restore')) window.fangyuShell.maximize();
      else if (btn.classList.contains('close')) window.fangyuShell.close();
    }, true);
  })();`;
  win.webContents.on('dom-ready', () => {
    win.webContents.executeJavaScript(script).catch(() => {});
  });
}

function createWindow(query = {}, options = {}) {
  const win = new BrowserWindow({
    width: 1280,
    height: 820,
    title: TITLE,
    backgroundColor: '#161210',
    icon: icon(),
    autoHideMenuBar: true,
    frame: false,
    show: options.show !== false,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true
    }
  });
  win.setTitle(TITLE);
  win.on('page-title-updated', (event) => {
    event.preventDefault();
    win.setTitle(TITLE);
  });
  attachWindowControls(win);
  hookPreviewChrome(win);
  const load = win.loadFile(PREVIEW_HTML, { query });
  return { win, load };
}

async function settle(win) {
  await win.webContents.executeJavaScript(`
    Promise.all(
      Array.from(document.images || []).map((img) => {
        if (img.complete) return Promise.resolve();
        return new Promise((ok) => { img.onload = ok; img.onerror = ok; });
      })
    ).then(() => new Promise((ok) => requestAnimationFrame(() => setTimeout(ok, 400))))
  `);
  await new Promise((ok) => setTimeout(ok, 500));
}

async function takeShots() {
  fs.mkdirSync(SHOT_DIR, { recursive: true });
  const { win, load } = createWindow({ view: 'idle', shot: '1' }, { show: true });
  await load;
  win.setContentSize(1280, 720);
  for (const item of SHOT_VIEWS) {
    await win.loadFile(PREVIEW_HTML, { query: { view: item.view, shot: '1' } });
    await settle(win);
    const image = await win.capturePage();
    const dest = path.join(SHOT_DIR, item.file);
    fs.writeFileSync(dest, image.toPNG());
    console.log('wrote', dest, image.getSize().width + 'x' + image.getSize().height);
  }
  win.close();
}

app.whenReady().then(async () => {
  if (!fs.existsSync(PREVIEW_HTML)) {
    console.error('missing preview:', PREVIEW_HTML);
    app.exit(1);
    return;
  }
  if (process.env.ELECTRON_SHOTS === '1') {
    try {
      await takeShots();
      app.exit(0);
    } catch (error) {
      console.error(error);
      app.exit(1);
    }
    return;
  }
  createWindow();
  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});
