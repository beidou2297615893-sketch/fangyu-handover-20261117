# 方隅界面 · batch-03-premium

日期：2026-11-10（Asia/Shanghai）
范围：只出设计图，不写代码、不改程序。
起因：用户认可 batch-02-free 的简洁版式，但要给投资人看，要求「高颜值」，希望加上高级家居背景和更强的氛围感。

## 设计思路

信息结构完全沿用 batch-02：窄侧栏（方隅 / 抖音 / 小红书 / 客户 / 设置），主区「今天」、巨大的「运行中」与「暂停」、三个数字（采集 / 回复 / 有效池）、下方「最近」三位打码客户。文字继续少而短。

在此之上做路演级氛围，而不是把界面重新做复杂：

- 全幅铺开略虚化的高级公寓内景摄影，界面做成磨砂玻璃窗浮在上面，细边高光、柔和投影，质感接近 macOS Sonoma / visionOS / Arc。
- 窗口略带一点透视，像产品发布会或融资路演的主视觉，而不是普通软件截图。
- 数字卡下加一条很小的无标注趋势曲线，状态点带一点微光。
- 配色仍是暖色系：陶土 / 琥珀 / 暖白。浅色面板配傍晚落地窗；深色面板配夜景暖光客厅。避开深蓝主调（夜景窗外天际线仍可能带一点自然的暗蓝，不作为界面主色）。
- 客户名继续打码（王** / 李** / 张**），不出现手机号、UID、Cookie。

## 三张图

| 文件 | 说明 | 重出 |
| --- | --- | --- |
| `01-home-glass-dusk.png` | 主界面，傍晚落地窗公寓 + 浅暖磨砂面板。一次通过。 | 0 |
| `02-home-glass-night.png` | 主界面，夜景暖光客厅 + 深色磨砂面板。一次通过。 | 0 |
| `03-floating-widget.png` | 同风格桌面上的磨砂悬浮小窗。第一张背景仍是上一批近景窗帘，已弃用；此为第二张。 | 1（最多 2） |

分辨率均为 1280×720，16:9。原始生成件为 JPEG，已转成真正的 PNG。版式参考 `/workspace/project-intake/fangyu/ui-design/batch-02-free/`。

### 01-home-glass-dusk.png

浅暖磨砂玻璃主窗浮在傍晚公寓里：落地窗、暖金色天际线、亚麻窗帘、橡木地板、沙发与陶罐。侧栏、今天、运行中、暂停、三张数字卡（带小曲线）、最近客户，与 batch-02 一致。

明显瑕疵：列表右侧「已回复 / 待回复」在磨砂上对比偏弱，略洗淡；玻璃中央比边缘更乳浊，通透感不如夜景那张；三条趋势线几乎相同，只是装饰波纹；状态点微光比较克制；侧栏与主区看起来略像两层叠放的玻璃板。中文清楚，无乱码。

### 02-home-glass-night.png

深色暖炭磨砂主窗浮在夜间客厅里：钨丝灯、吊灯、木柜与沙发。玻璃更通透，吊灯光晕透过面板，路演感更强。

明显瑕疵：窗外夜景带一点冷蓝天空（不是界面主色，但看得到）；中央吊灯光斑让玻璃中部略糊；「已回复 / 待回复」对比仍然偏弱；趋势线同样偏装饰。中文清楚，无乱码。

### 03-floating-widget.png

宽景傍晚公寓桌面，右下角深色磨砂小卡：方隅、运行中、第 12 位、采集 86、回复 54、暂停，带细边高光和一条小曲线。与两张主界面同一套空间语言。

明显瑕疵：画面中部墙面雾气偏重，建筑细节被虚掉一块；卡片通透感不如夜景主窗，更接近实色磨砂；小曲线只出现在 86 下方；卡片右缘贴近沙发。中文清楚，无乱码。

弃用稿：第一张悬浮窗几乎沿用 batch-02 的近景窗帘与木柜，和两张主界面的路演质感不匹配，未入库。

## 画面上的全部文字

主界面：方隅、抖音、小红书、客户、设置、今天、19:08、运行中、正在回复 第 12 位、暂停、采集、86、回复、54、有效池、32、最近、王**、高意向、李**、已回复、张**、待回复。

悬浮窗：方隅、运行中、第 12 位、86、采集、54、回复、暂停。

数字为示意排版，不是真实业务数据。

## 提示词

工具：cursor 命名空间 `GenerateImage`，aspect_ratio `16:9`。

### 01-home-glass-dusk.png

参考：`batch-02-free/01-home-light.png`。

```
A cinematic 16:9 product-launch hero photograph of a premium desktop app, like an Apple keynote slide or a refined Series A pitch visual, photorealistic, not a sketch, not a flat mockup board.

BACKGROUND fills the entire frame: a slightly out-of-focus photograph of a high-end apartment living room at dusk. Floor-to-ceiling windows, warm golden-hour sunlight, a soft city skyline in amber, gold and terracotta (no blue hour, no navy sky, no cyan or cool neon). Linen curtains, light oak floor, a hint of a beige sofa and a ceramic vase at the edges. Shallow depth of field, atmospheric and expensive, blurred just enough that it does not compete with the interface.

FLOATING WINDOW: a large rounded application window floats in the center with about 7 percent margin on all sides so the apartment photo is clearly visible around it. The window is warm-white frosted liquid glass in the style of macOS Sonoma, visionOS or Arc Browser: semi-translucent frosted panel, the dusk light faintly bleeding through the glass, a thin 1px warm-white rim highlight on the top and left edges, a soft realistic drop shadow underneath. Corner radius about 20px. Three tiny traffic-light dots at the top-left of this glass window.

Keep the exact information architecture and typography hierarchy of the attached reference UI, do not add extra pages, menus, or labels. Narrow left sidebar on the glass: geometric corner-mark logo and 方隅, then nav 抖音 (selected, soft terracotta-tinted pill), 小红书, 客户, 设置. Main area: large title 今天, small time 19:08 at the far right, a terracotta live status dot with a soft glow plus very large heavy type 运行中, quiet line 正在回复 第 12 位, a large terracotta rounded button with white text 暂停 on the right. Three frosted metric tiles in a row: 采集 86, 回复 54, 有效池 32; under each number add one tiny delicate unlabeled terracotta sparkline, slightly rising, no chart axes, no extra captions. Section 最近, then three rows 王** 高意向, 李** 已回复, 张** 待回复, with simple monogram circles. No phone numbers, no IDs, no cookies.

Palette: warm frosted glass, charcoal text #1A1613, secondary #8A8279, single terracotta/amber accent #C45C3E. No blue, no navy, no cyan, no teal, no purple.

Critical typography: every Chinese character is correctly formed, sharp, perfectly legible Simplified Chinese, no missing or extra strokes, no warped glyphs, no mojibake. The ONLY text in the entire image is exactly: 方隅, 抖音, 小红书, 客户, 设置, 今天, 19:08, 运行中, 正在回复 第 12 位, 暂停, 采集, 86, 回复, 54, 有效池, 32, 最近, 王**, 高意向, 李**, 已回复, 张**, 待回复. No English words, no watermarks, no browser chrome. Ultra-premium 4K product photography.
```

### 02-home-glass-night.png

参考：本批 dusk 成图，以及 `batch-02-free/02-home-dark.png`。

```
A cinematic 16:9 product-launch hero photograph, the dark-theme twin of the first attached reference. Same floating-window composition, same information architecture, same typography, same perspective, photorealistic and refined like an Apple keynote slide. Do not add, remove, or rearrange UI labels.

BACKGROUND fills the entire frame: a slightly out-of-focus photograph of a high-end apartment living room at night. Warm tungsten floor lamps and a soft pendant light, amber table lamp glow on oak and linen, a comfortable sofa, maybe a low vase. Floor-to-ceiling windows show a city at night with ONLY warm gold and amber window lights, no blue hour, no navy sky glow, no cyan or cool neon. Atmospheric, expensive, shallow depth of field.

FLOATING WINDOW: the same large rounded application window floats in the center with about 7 percent margin, now in dark warm frosted liquid glass (macOS Sonoma / visionOS / Arc style): smoky warm charcoal glass #1C1916, semi-translucent so the lamp-lit room faintly bleeds through, a thin 1px warm highlight rim on the top and left edges, a soft realistic drop shadow. Corner radius about 20px. Traffic-light dots at the top-left.

UI content identical to the references: sidebar logo and 方隅, nav 抖音 (selected, terracotta-tinted pill), 小红书, 客户, 设置. Title 今天, time 19:08, glowing terracotta live dot and large ivory type 运行中, line 正在回复 第 12 位, terracotta button 暂停. Three dark frosted metric tiles: 采集 86, 回复 54, 有效池 32, each with a tiny unlabeled amber sparkline under the number. Section 最近, rows 王** 高意向, 李** 已回复, 张** 待回复, monogram circles. Status tags must stay clearly readable on the dark glass, not washed out. No phone numbers, no IDs, no cookies.

Palette: warm charcoal frosted glass, ivory text #F3EDE6, secondary #9A9188, terracotta/amber accent #E07A55. No blue, no navy, no cyan, no teal, no purple, no cool gray-blue night.

Critical typography: every Chinese character correctly formed, sharp, perfectly legible Simplified Chinese, no warped glyphs, no mojibake. The ONLY text is exactly: 方隅, 抖音, 小红书, 客户, 设置, 今天, 19:08, 运行中, 正在回复 第 12 位, 暂停, 采集, 86, 回复, 54, 有效池, 32, 最近, 王**, 高意向, 李**, 已回复, 张**, 待回复. No English words, no watermarks. Ultra-premium 4K product photography.
```

### 03-floating-widget.png（采用的第二张）

第一张以两张主界面和 batch-02 悬浮窗为参考，结果背景仍是近景窗帘，弃用。

第二张只以两张主界面为参考，明确要求宽景公寓、不要近景窗帘、不要残缺白条：

```
A cinematic 16:9 product-launch photograph of a computer desktop, investor-pitch quality, photorealistic. Do NOT use a tight close-up of curtains. Use the SAME wide luxury apartment world as the two attached references.

BACKGROUND fills the entire frame: a slightly soft, wide view of a high-end apartment living room at dusk, like the first reference — floor-to-ceiling windows, warm golden-hour light, a soft amber city skyline, linen, oak, a sofa, generous empty wall space on the right side of the frame so a widget can sit there cleanly. Atmospheric and expensive. No blue hour, no navy, no cyan neon. No dock, no incomplete white bars, no cropped windows, no floating white rectangles. Clean wallpaper all the way to the bottom edge. Optional very thin empty menu bar at the top.

SUBJECT: a small always-on-top frosted-glass widget card in the lower-right area, fully visible, with clear margin from the right and bottom edges, sitting in open wall space, NOT overlapping furniture or a window frame. Compact, about one-fifth of the screen width. Material must match the attached app windows: dark warm charcoal frosted liquid glass, clearly semi-translucent so a hint of the room shows through, a crisp 1px warm highlight rim, soft realistic drop shadow, ~18px corner radius. macOS Sonoma / visionOS / Arc quality, not a flat opaque grey card.

Card content only, sparse and sharp: top left geometric corner-mark logo and 方隅; top right a terracotta live dot with a soft glow and 运行中; muted line 第 12 位; two large ivory numbers 86 with label 采集 and 54 with label 回复, a tiny unlabeled amber sparkline under the numbers is allowed; bottom right a terracotta button with white text 暂停. No traffic lights, no extra controls, no phone numbers, no IDs, no names.

Critical typography: every Chinese character correctly formed, sharp, perfectly legible Simplified Chinese, no warped glyphs, no mojibake. The ONLY text in the entire image is: 方隅, 运行中, 第 12 位, 86, 采集, 54, 回复, 暂停. No English, no watermarks. Ultra-premium 4K.
```
