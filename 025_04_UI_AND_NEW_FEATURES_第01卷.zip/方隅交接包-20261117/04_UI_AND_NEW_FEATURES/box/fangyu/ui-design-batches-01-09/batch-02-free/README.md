# 方隅界面 · batch-02-free

日期：2026-11-10（Asia/Shanghai）
范围：只出设计图，不写代码、不改程序。
起因：用户看过 batch-01 后觉得丑，取消此前全部样式约束（不必照参考图、不必白底、不必公寓照片渐隐、不必青绿、不必固定版式），要求凭审美判断这类软件该是什么样子。

## 设计思路

这是给公寓门店员工用的桌面客户端：自动在抖音 / 小红书采集有租房意向的客户，筛选后自动回复。员工不懂技术，日常只需点启动，看今天采了多少、回了多少、有效客户有哪些；遇到要人处理的事（如平台验证）再出面。

因此首屏不应该是采集工作台或报表，而应该是一个「今天」的驾驶舱：一眼看到机器还在不在跑、跑到哪一步、三个关键数字、最近几位客户。长时间挂机时，主窗口可以收起来，角落留一张小卡片。

视觉上按 Linear / Arc / Notion / Raycast 这一类现代高级桌面工具来想：窄侧栏、字重对比强、留白大、信息少而精、圆角和阴影克制。品牌名「方隅」用一个简单的转角几何标记，呼应名字，不做插画、不做照片底。

配色自定，只守一条用户明确不要的硬线：避开深蓝主调。浅色用暖白 / 米纸底，单一强调色为陶土色（#C45C3E）；深色用炭黑 / 暖灰（#161412），不是蓝黑，强调色略提亮（#E07A55）。同一套版式出浅、深两张，方便用户选调性。

客户名一律打码（王** / 李** / 张**），图中不出现完整手机号、UID、Cookie。

## 三张图

| 文件 | 说明 | 重出 |
| --- | --- | --- |
| `01-home-light.png` | 主界面·运行中，浅色。一次通过。 | 0 |
| `02-home-dark.png` | 同一主界面的深色版，以浅色图为参考保持版式。一次通过。 | 0 |
| `03-floating-widget.png` | 桌面悬浮小窗，深色磨砂卡叠在暖色室内壁纸右下角。第一张底边多了一条残缺白条，已弃用；此为第二张。 | 1（最多 2） |

分辨率均为 1280×720，16:9。原始生成件为 JPEG，已转成真正的 PNG。

### 01-home-light.png

浅色主界面，运行中。左侧窄栏：方隅、抖音（选中）、小红书、客户、设置。主区大标题「今天」，巨大的「运行中」+「正在回复 第 12 位」+ 陶土色「暂停」按钮，三张数字卡（采集 86 / 回复 54 / 有效池 32），下方「最近」三位打码客户。

明显瑕疵：暂停按钮相对「运行中」略偏下；侧栏图标是通用线框，不是平台官方标识。文字清楚，无乱码。

### 02-home-dark.png

与浅色同一版式的深色主界面，暖炭黑底，陶土强调色。

明显瑕疵：列表右侧标签（高意向 / 已回复 / 待回复）在深色底上对比偏弱，尤其是后两个灰色标签。文字清楚，无乱码。

### 03-floating-widget.png

长时间运行时放在桌面角落的小卡片：方隅、运行中、第 12 位、采集 86、回复 54、暂停。背景是暖色窗帘与木柜的室内壁纸，卡片风格与深色主界面一致。

明显瑕疵：卡片右缘略叠在木柜上；「第 12 位」字号偏小；桌面没有画出完整菜单栏或 Dock，更像壁纸照片上叠了一张卡片，而不是完整系统截图。文字清楚，无乱码。

弃用稿：第一张悬浮窗在画面底部多了一条残缺白条（像被裁切的窗口或半截 Dock），未入库。

## 画面上的全部文字（三张共用约定）

主界面：方隅、抖音、小红书、客户、设置、今天、19:08、运行中、正在回复 第 12 位、暂停、采集、86、回复、54、有效池、32、最近、王**、高意向、李**、已回复、张**、待回复。

悬浮窗：方隅、运行中、第 12 位、86、采集、54、回复、暂停。

数字为示意排版，不是真实业务数据。

## 提示词

工具：cursor 命名空间 `GenerateImage`，aspect_ratio `16:9`。

### 01-home-light.png

```
A photorealistic 16:9 screenshot of a premium macOS desktop application window, ultra-clean UI like Linear or Arc Browser, a finished product screenshot not a sketch and not a photo of a monitor. Warm light theme. Generous whitespace, strong typography contrast, restrained 12px rounded corners, almost no drop shadow.

Color palette only: warm paper background #F6F3EE, narrow sidebar #EFEBE4, cards off-white #FFFCF8, primary text warm charcoal #1A1613, secondary text #8A8279, a single warm terracotta accent #C45C3E. No blue, no navy, no cyan, no teal, no purple. No photographs inside the app. No apartment photos. No decorative gradients.

macOS window with three tiny traffic-light dots (red, yellow, green) at the top-left corner. Narrow left sidebar about one-seventh of the width. Wide main content area on the right.

Sidebar, top to bottom, lots of vertical space: a simple geometric corner-mark logo and the two Chinese characters 方隅 in medium weight. Then four navigation rows with a small simple line icon and a short label, generously spaced: 抖音 (selected, soft terracotta-tinted pill, terracotta label), then 小红书, then 客户, then 设置 in muted gray. No other sidebar items.

Main content, left-aligned, generous padding: top page title 今天 in heavy Noto Sans SC Bold, about 40px. Far right of that row, only a tiny muted time 19:08. Below, a spacious status region (not a heavy boxed card): a small filled terracotta live dot, then the two characters 运行中 in very large heavy type, about 60px. Under that, one quiet secondary line: 正在回复 第 12 位. On the right of this same status region, one large terracotta filled rounded-rectangle button with white text 暂停, about 140 by 48 pixels.

Below, three almost-flat metric tiles in a horizontal row with wide gaps. Each has a small muted label above a huge charcoal number, no icons and no charts. Left: label 采集, number 86. Middle: label 回复, number 54. Right: label 有效池, number 32.

Below, a small muted section label 最近. Then three sparse list rows with hairline separators only: left side names 王** , 李** , 张** ; right side small tags 高意向 (terracotta tint), 已回复 (muted), 待回复 (muted). Optional simple monogram circles with a single character. No phone numbers, no IDs, no cookies.

Critical typography: every Chinese character is correctly formed, sharp, perfectly legible Simplified Chinese, no missing or extra strokes, no warped glyphs, no mojibake, no Latin letters inside Chinese words. The ONLY text in the entire image is exactly: 方隅, 抖音, 小红书, 客户, 设置, 今天, 19:08, 运行中, 正在回复 第 12 位, 暂停, 采集, 86, 回复, 54, 有效池, 32, 最近, 王**, 高意向, 李**, 已回复, 张**, 待回复. No English words, no lorem ipsum, no extra buttons, no watermarks, no browser chrome. Crisp 4K UI screenshot.
```

### 02-home-dark.png

以 `01-home-light` 的生成件为 `reference_image_paths`。

```
Recreate the exact same macOS desktop app UI screenshot as the attached reference image, keeping the identical layout, spacing, typography hierarchy, iconography, and all the same Chinese labels and numbers. Do not add, remove, or rearrange any elements. This is only a dark-theme recolor of that same screen.

Dark warm theme, not blue-black: window background warm charcoal #161412, narrow left sidebar slightly lighter #1C1916, metric tiles #221E1B with hairline borders #2C2723, primary text warm ivory #F3EDE6, secondary text #9A9188, the same single terracotta accent now slightly brighter #E07A55. Selected sidebar item 抖音 has a soft terracotta-tinted dark pill. The 暂停 button is filled terracotta with white text. Live status dot is terracotta. Tags: 高意向 terracotta-tinted, 已回复 and 待回复 muted warm gray pills. No blue, no navy, no cyan, no teal, no purple, no cool gray-blue dark mode. No photographs inside the app.

Keep: traffic-light dots at top-left, sidebar logo and 方隅, nav 抖音 (selected) 小红书 客户 设置, title 今天, time 19:08, large 运行中 with live dot, line 正在回复 第 12 位, button 暂停, three tiles 采集 86 / 回复 54 / 有效池 32, section 最近, rows 王** 高意向, 李** 已回复, 张** 待回复, monogram circles.

Critical typography: every Chinese character must stay correctly formed, sharp, perfectly legible Simplified Chinese, no missing or extra strokes, no warped glyphs, no mojibake. The ONLY text is exactly the same as the reference: 方隅, 抖音, 小红书, 客户, 设置, 今天, 19:08, 运行中, 正在回复 第 12 位, 暂停, 采集, 86, 回复, 54, 有效池, 32, 最近, 王**, 高意向, 李**, 已回复, 张**, 待回复. No English words, no extra buttons, no watermarks. Crisp 4K UI screenshot, 16:9.
```

### 03-floating-widget.png（采用的第二张）

第一张以浅色、深色主界面为风格参考，提示词要求暖色室内壁纸 + 右下角深色磨砂卡，并写明画面里只能出现：方隅、运行中、第 12 位、86、采集、54、回复、暂停。成图底边多了一条残缺白条，弃用。

第二张以第一张为参考，只修那条白条，其余版式与壁纸保持不变：

```
Keep the same photorealistic 16:9 macOS desktop and the same floating widget as the attached reference: the same sunlit linen curtain and light wood furniture wallpaper, the same dark warm charcoal frosted card in the bottom-right corner, the same layout and typography inside the card. Do not redesign the widget.

FIX only these problems: completely remove the incomplete white rounded rectangle or cropped window bar at the bottom of the screen. The lower edge must be clean wallpaper only. Do not show any partial window, white slab, or broken dock. No dock at all. A very thin optional empty macOS menu bar at the top is fine. The widget card must stay fully visible, not cut off, with margin from the right and bottom edges.

Card content stays exactly: logo and 方隅 at top left; terracotta live dot and 运行中 at top right; muted line 第 12 位; large numbers 86 with label 采集 and 54 with label 回复; terracotta button 暂停 at the bottom right of the card. Same colors: warm charcoal card, ivory text, terracotta accent. No blue.

Critical typography: every Chinese character correctly formed, sharp, perfectly legible Simplified Chinese, no warped glyphs, no mojibake. The ONLY text in the entire image is: 方隅, 运行中, 第 12 位, 86, 采集, 54, 回复, 暂停. No English, no watermarks. Crisp 4K.
```
