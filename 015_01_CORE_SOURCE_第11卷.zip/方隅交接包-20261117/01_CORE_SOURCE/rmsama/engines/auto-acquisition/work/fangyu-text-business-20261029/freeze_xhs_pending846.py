import json,hashlib,sqlite3
from pathlib import Path
R=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent;D=W/'xhs-increment-846';D.mkdir(exist_ok=True)
def sha(x):return hashlib.sha256(x).hexdigest()
db=sqlite3.connect((R/'work/shared-acquisition-ledger/shared.sqlite3').as_uri()+'?mode=ro',uri=True)
old={json.loads(x)['comment_id'] for x in (W/'delivery-v2/source-input.jsonl').read_text(encoding='utf8').splitlines()};rows=[];seen=set();receipts=[]
for base in [R/'work/xhs-account-switch-recovery-candidate/runtime/new-account-task-20261029-1710',R/'work/xhs-partial-registration-recovery-20261029/runtime/new-task-batch8-recovery']:
 for line in (base/'analysis-manifest.jsonl').read_text(encoding='utf8').splitlines():
  e=json.loads(line)
  if e['status']!='registered_ready_for_classification':continue
  p=(base/e['input']).resolve();assert p.is_relative_to(base.resolve()) and sha(p.read_bytes())==e['sha256'];flat=[]
  for parent in json.loads(p.read_text(encoding='utf8')):
   for c in [parent,*parent.get('other_comments',[])]:
    same=not c.get('note_id') or c.get('note_id')==parent.get('note_id')
    x={k:c.get(k) for k in ['comment_id','comment_text','parent_text','parent_relationship','published_at','ip_location','missing_context']}
    x.update(platform='xiaohongshu',customer_uid=c.get('customer_uid',parent.get('customer_uid')),note_id=c.get('note_id',parent.get('note_id')),
     post_title=c.get('post_title') or (parent.get('post_title','') if same else ''),post_text=c.get('post_text') or (parent.get('post_text','') if same else ''),
     source_store='古北（仅采集来源，非本人需求地区）',source_account_uid=e['account_uid'],source_keyword=e['keyword'],source_page=e['page'],
     source_input=str(p),source_batch=e.get('batch',e.get('original_batch')),input_sha256=e['sha256'],source_registration=e['registration_source'],send_authorized=False)
    found=db.execute('select source from leads where platform=? and comment=?',('xiaohongshu',x['comment_id'])).fetchall();assert len(found)==1 and found[0][0]==e['registration_source']
    assert x['comment_id'] not in old and x['comment_id'] not in seen;seen.add(x['comment_id']);flat.append(x)
  assert len(flat)==e['inserted_comments'];rows+=flat;receipts.append({'input_file':str(p),'count':len(flat),'input_sha256':e['sha256']})
assert len(rows)==846
for i,x in enumerate(rows,1):x['review_key']=f'X{i:04d}'
packed=''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in rows).encode();p=D/'input.jsonl'
if p.exists():assert p.read_bytes()==packed
else:p.write_bytes(packed)
for i in range(2):(D/f'shard-{i}.jsonl').write_bytes(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in rows[i::2]).encode())
(D/'manifest.json').write_text(json.dumps({'registered_pending_comments':846,'input_sha256':sha(packed),'sources':receipts,'source_database_modified':False,'sent':0},ensure_ascii=False,indent=2),encoding='utf8')
print('Verified and froze 846 registered XHS comments; two shards of 423; no collection or source edits.')
