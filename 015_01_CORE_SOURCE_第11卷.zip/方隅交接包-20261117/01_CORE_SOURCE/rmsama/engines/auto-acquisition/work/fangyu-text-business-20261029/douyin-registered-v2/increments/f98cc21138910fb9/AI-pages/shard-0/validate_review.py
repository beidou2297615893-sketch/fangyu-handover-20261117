"""Identity, literal evidence, local family contract, real adapter SHA isolation."""
import json,hashlib,sys,collections,importlib.util
from pathlib import Path
P=Path(__file__).resolve().parent;B=P.parent.parent;W=B.parent.parent.parent
def read(p):return [json.loads(l) for l in p.read_text(encoding='utf-8').splitlines() if l.strip()]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
source=read(B/'shard-0.jsonl');rows=read(B/'reviewed-new-0.jsonl');sx={r['review_key']:r for r in source}
assert len(rows)==len(source)==269
assert all(hashlib.sha256(s['comment_text'].encode('utf-8')).hexdigest()==s['source_comment_sha256'] for s in source)
assert collections.Counter(r['review_key'] for r in rows)==collections.Counter(r['review_key'] for r in source)
pages=read(P/'reviewed-00.jsonl')+read(P/'reviewed-01.jsonl');assert {r['review_key']:r for r in pages}=={r['review_key']:r for r in rows}
families=json.loads((B/'local-mother-contract.json').read_text(encoding='utf-8'))['families']
errors=[];quote_count=0;param_count=0
def check_quote(key,q,field):
 global quote_count
 quote_count+=1
 if not isinstance(q,str) or not q or q not in sx[key]['comment_text']:errors.append([key,field,'quote_not_literal',q])
for r in rows:
 k=r['review_key'];s=sx[k]
 for f in ('comment_id','customer_uid','video_id','platform'):assert r[f]==s[f],(k,f)
 assert r['human_confirmed'] is False and r['send_authorized'] is False and r['store_assignment'] is None
 for field in ('topics','target_regions','time_mentions','other_constraints','contact_boundaries'):
  for x in r[field]:check_quote(k,x['quote'],field)
 for x in r['evidence']:check_quote(k,x,'evidence')
 p=r['reply_plan'];assert 'local_mother' in p
 assert p['preferred_mother_slot'] in (None,1,2,7,13,16,19,25,28,31,34)
 m=p['local_mother']
 if m is None:assert p['caution'];continue
 assert m['family'] in families
 assert set(m['fill'])==set(families[m['family']]['required_fill'])
 assert set(e['field'] for e in m['evidence'])==set(m['fill'])
 for e in m['evidence']:
  check_quote(k,e['quote'],'local_mother');param_count+=1
  assert m['fill'][e['field']] in e['quote'],(k,e)
  assert m['fill'][e['field']] in s['comment_text'],(k,e)
 assert p['missing_facts']
assert not errors,errors
# Classification metadata exists only in the true isolated preflight file.
isolation=[]
for r in rows:
 q=dict(r);q['classification_method']='ai_semantic_initial_and_detailed';q['classification_stages_completed']=['initial_semantic','detailed_semantic'];isolation.append(q)
iso=P/'isolation-semantic-with-stages.jsonl'
iso.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in isolation),encoding='utf-8')
digest=sha(iso)
spec=importlib.util.spec_from_file_location('original_mother_adapter',W/'mother_adapter.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
cache={};passed=0
for r in isolation:
 bound=dict(r);bound['classification_review_source']={'path':str(iso.resolve()),'sha256':digest}
 module.validate_new_review(bound,B,cache);passed+=1
result={'shard':0,'input_count':len(source),'output_count':len(rows),'page_counts':[180,89],'identity_set_equal':True,'page_content_equals_summary':True,'literal_quotes_checked':quote_count,'literal_quotes_passed':True,'local_mother_parameter_fields_checked':param_count,'local_mother_contract_passed':True,'explicit_local_mother_all_rows':True,'original_validator':'mother_adapter.validate_new_review','original_adapter_sha256':sha(W/'mother_adapter.py'),'real_isolated_validation_passed':passed,'isolation_file':str(iso.resolve()),'isolation_sha256':digest,'source_shard_sha256':sha(B/'shard-0.jsonl'),'reviewed_sha256':sha(B/'reviewed-new-0.jsonl'),'source_comment_sha_verified_count':len(source),'source_version_conflicts':sum(bool(s.get('source_version_conflict')) for s in source),'role_counts':dict(collections.Counter(r['role'] for r in rows)),'interest_counts':dict(collections.Counter(r['interest'] for r in rows)),'family_counts':dict(collections.Counter((r['reply_plan']['local_mother'] or {}).get('family','none') for r in rows)),'classification_stages_completed':['initial_semantic','detailed_semantic'],'independent_review_completed':False,'human_confirmed':False,'send_authorized':False,'platform_calls':0,'usage':'unknown','fee':'unknown','source_files_modified':False,'errors':[]}
(B/'shard-0-validation.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
(P/'progress.json').write_text(json.dumps({'shard':0,'completed_pages':[0,1],'comments_completed':269,'status':'completed_local_preflight','initial_and_detailed_same_model':True,'independent_review_completed':False,'platform_calls':0,'send_authorized':False,'usage':'unknown','validation_file':str((B/'shard-0-validation.json').resolve())},ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({k:result[k] for k in ('input_count','output_count','literal_quotes_checked','real_isolated_validation_passed','local_mother_parameter_fields_checked','reviewed_sha256','isolation_sha256')},ensure_ascii=False))
