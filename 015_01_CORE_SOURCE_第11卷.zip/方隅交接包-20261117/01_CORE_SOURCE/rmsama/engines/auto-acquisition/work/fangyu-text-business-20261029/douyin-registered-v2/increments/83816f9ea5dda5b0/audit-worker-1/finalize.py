from pathlib import Path
import json,hashlib
b=Path('work/fangyu-text-business-20261029/douyin-registered-v2/increments/83816f9ea5dda5b0'); o=b/'audit-worker-1'; p=b/'recall-audit/part-1'
v=json.loads((o/'validation.json').read_text(encoding='utf-8'))
assert v['status']=='complete' and v['records_reviewed']==v['formal_validate_count']==1751
assert v['full_task_id_set_equal'] and v['all_reviewed_keys_unique'] and not v['quote_errors'] and not v['formal_validate_errors']
a=[]; manifest=[]
for f in sorted(p.glob('page-*.audit.jsonl')):
 rows=[json.loads(s) for s in f.read_text(encoding='utf-8').splitlines() if s.strip()]; a.extend(rows)
 manifest.append({'path':str(f.relative_to(b)).replace('\\','/'),'records':len(rows),'sha256':hashlib.sha256(f.read_bytes()).hexdigest()})
assert len(manifest)==15 and len(a)==1751
ids={r['review_key'] for r in a}; byid={r['review_key']:r for r in a}
assert byid['D0754']['decision']==byid['D1670']['decision']=='keep'
assert 'D1125' not in ids and 'D1129' not in ids
cross={'diagnostic_source':'primary-cross-shard-consistency.json','method':'模型完整读本片共享正文、本人评论和原判断后独立裁决；不依赖多数票或字符串代判','groups':[{'video':'7658156070343828059','text':'新都有吗','owned_keys':['D0754'],'decision':'keep','role':'demand','demand_state':'active_at_comment','interest':'medium','reason':'正文是工资3K月租750套一的现居分享，不构成提供可租新都房源；本人提出地区有无的当时住房询问，但未明确房源对象、入住或看房等推进，维持中等而非仅凭地区询问判高。','limits':'不改D2095或D1656；非本片记录须由所属复核者和合并方独立裁决。'},{'video':'7598099011953923313','text':'真的吗','owned_keys':[],'decision':'outside_owned_part','reason':'D1125与D1129均不在本片1751个ID集合，不将诊断表当成已读原记录作裁决。','limits':'本片没有核心冲突key，跨片结论留所属复核者和合并方。'},{'video':'7658156070343828059','text':'龙泉有吗','owned_keys':['D1670'],'decision':'keep','role':'demand','demand_state':'active_at_comment','interest':'medium','reason':'正文现居分享没有提供可租龙泉房源；本人地区有无询问可保留当时住房需求，但仅此短问不足确认强推进，保留中等与地区母句待核计划。','limits':'不改D1833，所属复核者和合并方须独立裁决。'}]}
(o/'cross-context-review.json').write_text(json.dumps(cross,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
m={'batch':'83816f9ea5dda5b0','part':1,'pages':manifest,'records':1751,'decisions':v['decisions'],'isolated_sha256':v['isolated_sha256']}
(o/'page-manifest.json').write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
changes=[r for r in a if r['decision']=='change']
lines=['# 抖音文字独立复核报告：第1片','','已完成批次83816f9ea5dda5b0中part-1全部1751条、15页逐条文字语义复核。显式决定1713条keep、38条change；无未读补keep。每页完整核对共享正文、本人评论和初判，通过本地无损引用/字段覆盖展示避免重复长文；程序只做分页展示、按模型显式key记录和确定性校验，不代替模型分类。','','## 结果与验证','','- page-00至page-13各120条；page-14为71条。15页ID集合逐页相等，总ID集合与task.json完全相等，无重复。','- 改动仅保存在recall-audit/part-1/page-XX.audit.jsonl；未修改三份primary、adapter、其他片或全局合并状态。','- 真实隔离JSONL按完整primary原判断叠加本片patch构成，不是只校验patch。每条标明真实独立语义复核阶段。','- 隔离文件SHA绑定后逐条调用未改的mother_adapter.validate_new_review：1751/1751通过，正式错误0。','- evidence及topics、地区、时间、约束、possible_topics、联系边界的引文逐项核来源：0处错误。作者本人正文资格按原same_author核验；未将他人正文当本人需求。','- 模型仅选认可母句计划；不生成/修改回复正文。missing_facts包含待核事实，allow仅表示无已知拒联，不是发送授权。','- 保留unknown与真实未知；时间相对原发表时点，原帖/IP不当目标门店，工作/现居与期望地区分开；角色或兴趣变化相应核计划。','','## SHA与证据','','|文件|SHA-256|','|---|---|']
for s in v['primary_sources']:lines.append(f"|{s['path']}|{s['sha256']}（匹配task）|")
for name,dig in [('audit-worker-1/isolated-reviewed.jsonl',v['isolated_sha256']),('mother_adapter.py',v['adapter_sha256']),('audit-worker-1/validation.json',sha(o/'validation.json')),('audit-worker-1/page-manifest.json',sha(o/'page-manifest.json')),('audit-worker-1/cross-context-review.json',sha(o/'cross-context-review.json'))]:lines.append(f'|{name}|{dig}|')
lines+=['','正式验证详情在validation.json；15页各自SHA在page-manifest.json。adapter调用前后SHA一致。primary三份SHA与认领任务冻结值一致。','','## 同上下文冲突','','- D0754“新都有吗”：完整复核后keep medium；现居分享未提供可租房，短地区询问不直接当强推进。','- D1670“龙泉有吗”：完整复核后keep medium；同样保留当时住房关注和地区候选，不补强推进。','- “真的吗”组D1125、D1129均不属本片；不依据诊断表或其他片多数标签代判。','- 对非本片key不写patch。具体理由和裁决边界见cross-context-review.json；跨片冲突仍由所属复核者及合并方处置。','','## 38条修改','','以下为本模型逐条语义决定，patch见对应页。']
for r in changes: lines.append(f"- {r['review_key']}：{r['reason']}")
lines+=['','## 范围与限制','','只做已授权本地文字复核；未访问平台、源库、账号、凭据或其他聊天，未发送。未作视频画面核验，未冒充人工审核或平台回执。实际credits/token usage未知，不估算作已发生费用。本报告完成的是本片独立审计和隔离预检，不是全批次合并或发送验收。','']
(o/'report.md').write_text('\n'.join(lines),encoding='utf-8')
print(json.dumps({'report_sha256':sha(o/'report.md'),'validation_sha256':sha(o/'validation.json'),'page_manifest_sha256':sha(o/'page-manifest.json'),'cross_context_sha256':sha(o/'cross-context-review.json'),'isolated_sha256':v['isolated_sha256'],'records':len(a),'decisions':v['decisions']},ensure_ascii=False))
