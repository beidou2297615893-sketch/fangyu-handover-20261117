"""Apply frozen v1 then v2 patches to review-only candidate; never activate."""
import argparse,collections,copy,hashlib,json,pathlib,sys
sys.dont_write_bytecode=True
import prepare as core,prepare_repaired as v1
O=pathlib.Path(__file__).resolve().parent;W=O.parents[1];D1=W/'pool-mother-review/legacy-release-repairs';D2=W/'pool-mother-review/legacy-release-repairs-v2';ABC=O/'candidate-abc';BASE=O/'candidate-repaired';sha=core.sha;objsha=core.objsha;load=core.load;jl=core.jl;dump=core.dump;putjl=core.putjl;key=core.key
FIXED={'READY.json':'23eb7616b5d7ad5962acd780060142cc6c01275ee18070abfe2c9e9670f95497','manifest.json':'6bef452372b290bcf1f689447b1dac04726f0fce2bdcb5115a28346b5bd32ec0','repair-contract.json':'a7c6193ba4145ff1246e69eb17f836436369eaef0f316828eaee303e95cdffae','incremental-plan-overlays.jsonl':'2c2f12c65db07988af4638f23d7f2f5d9f232062beb4344c110806330baa9e21','source-bound-plan-overlays.jsonl':'8f932817830d917172f2f049a598aa3ca87eef77d6f4ada3b528ac180983567c','CLI-draft-body-overlays.jsonl':'af84e09a51c6e61ca816a8e3f0f2ac27ab36e7f4919106fa0106bd8d83245ed4'}
def apply_v2(abc,first,d):
 for f in ('platform','cid','uid','sourceSHA','source_file_sha256','original_classification_sha256'):
  if abc.get(f)!=d.get(f) or first.get(f)!=d.get(f):raise ValueError('v2 source mismatch '+f)
 if d['base_ABC_plan_sha256']!=objsha(abc) or d['base_v1_applied_plan_sha256']!=objsha(first):raise ValueError('v2 baseline hash mismatch')
 if d['v1_family']!=first.get('family') or d['v1_fill']!=first.get('fill'):raise ValueError('v2 prior plan mismatch')
 if d['original_contact_policy']!=abc.get('source_field_evidence',{}).get('contact_policy',abc.get('contact_policy_original')):raise ValueError('v2 contact mismatch')
 if any(d.get(k) is not False for k in ('classification_changed','send_authorized','can_send_now','applied')):raise ValueError('v2 permission/status changed')
 required={'family','fill','evidence','clarification_only','hold_reasons','status'}
 if not required.issubset(d['replacement_plan']):raise ValueError('v2 plan fields missing')
 out=copy.deepcopy(first);out.update(copy.deepcopy(d['replacement_plan']));return out
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--v2-ready',required=True);ap.add_argument('--output-dir',required=True);args=ap.parse_args();rp=pathlib.Path(args.v2_ready).resolve();dst=pathlib.Path(args.output_dir).resolve()
 if rp!=D2/'READY.json' or O not in dst.parents:raise ValueError('unexpected input or output directory')
 dst.mkdir(parents=True,exist_ok=True)
 for n,h in FIXED.items():
  if sha(D2/n)!=h:raise ValueError('v2 frozen SHA mismatch '+n)
 ready=load(rp);m=load(D2/'manifest.json');val=load(D2/'independent-local-verification.json');oldready=load(D1/'READY.json')
 if ready['status']!='complete_frozen_for_independent_review_not_published' or not ready['independent_semantic_review_pending'] or not val['all_independent_structural_checks_passed'] or ready['parent_v1_READY_SHA']!=v1.FIXED['READY.json']:raise ValueError('v2 readiness mismatch')
 protected=dict(m['sources_SHA256']);protected.update({str((D2/n).resolve()):h for n,h in ready['final_files_sha256'].items()});protected.update({str((D1/n).resolve()):h for n,h in oldready['final_files_sha256'].items()});protected[str(rp)]=FIXED['READY.json'];protected[str((D1/'READY.json').resolve())]=v1.FIXED['READY.json'];protected[str((O/'prepare_repaired_v2.py').resolve())]=sha(__file__);protected[str((O/'prepare_repaired.py').resolve())]=sha(O/'prepare_repaired.py');protected[str((O/'prepare.py').resolve())]=sha(O/'prepare.py')
 for n in ['candidate-manifest.json','merged-plans.jsonl','douyin-candidate.jsonl','xiaohongshu-candidate.jsonl','draft-change-ledger.jsonl','published-fix-annotations.jsonl']:
  protected[str((BASE/n).resolve())]=sha(BASE/n)
 pre={p:sha(p) for p in protected}
 if pre!=protected:raise ValueError('source differs from frozen lineage '+str([p for p in pre if pre[p]!=protected[p]]))
 abc=list(jl(ABC/'merged-plans.jsonl'));q1=list(jl(D1/'source-bound-plan-overlays.jsonl'));q2=list(jl(D2/'incremental-plan-overlays.jsonl'));cum=list(jl(D2/'source-bound-plan-overlays.jsonl'));v1plans=list(jl(BASE/'merged-plans.jsonl'))
 for rows in (abc,q1,q2,cum,v1plans):core.validate_unique(rows)
 if (len(abc),len(q1),len(q2),len(cum))!=(12963,813,266,1054):raise ValueError('patch count mismatch')
 p1={key(x):x for x in q1};p2={key(x):x for x in q2};pc={key(x):x for x in cum};prev={key(x):x for x in v1plans};base={key(x):x for x in abc}
 if not set(p1)<=set(base) or not set(p2)<=set(base) or set(pc)!=set(p1)|set(p2):raise ValueError('patch scope mismatch')
 plans=[]
 for original in abc:
  k=key(original);sem=copy.deepcopy(original);actual=copy.deepcopy(original)
  if k in p1:
   actual=v1.apply_patch(original,p1[k]);sem.update(copy.deepcopy(p1[k]['replacement_plan']))
  if actual!=prev[k]:raise ValueError('v1 source reconstruction mismatch '+str(k))
  if k in p2:
   nextsem=apply_v2(original,sem,p2[k]);actual.update(copy.deepcopy(p2[k]['replacement_plan']));actual.update(v2_overlay_sha256=objsha(p2[k]),v2_base_ABC_plan_sha256=objsha(original),v2_base_v1_plan_sha256=objsha(sem),v2_repair_reasons=copy.deepcopy(p2[k]['repair_reasons']),v2_repair_evidence=copy.deepcopy(p2[k]['repair_evidence']));sem=nextsem
  if k in pc:
   if pc[k]['base_merged_plan_sha256']!=objsha(original):raise ValueError('cumulative source mismatch')
   independent=copy.deepcopy(original);independent.update(copy.deepcopy(pc[k]['replacement_plan']))
   if sem!=independent:raise ValueError('v1+v2 and cumulative differ '+str(k))
  plans.append(actual)
 by={key(x):x for x in plans};contract=load(D2/'repair-contract.json');matrix=v1.contract_matrix(contract,plans)
 if len(matrix)!=396:raise ValueError('unexpected contract family count')
 cur=load(W/'region-brand-routing/current.json');srcmanifest=load(BASE/'candidate-manifest.json');snap=srcmanifest['immutable_baseline_sha256'];live={'region-current.json':W/'region-brand-routing/current.json','reply-pointer.json':W/'当前双平台回复结果指针.json','latest-manifest.json':W/'region-brand-routing/latest-manifest.json'}
 for name,path in live.items():
  if sha(path)!=snap[name] or sha(BASE/'immutable-baseline'/name)!=snap[name]:raise ValueError('source live pointer changed '+name)
 bd=dst/'immutable-baseline';bd.mkdir(exist_ok=True)
 for name in live:(bd/name).write_bytes((BASE/'immutable-baseline'/name).read_bytes())
 dump(dst/'merged-contract.json',contract);putjl(dst/'merged-plans.jsonl',plans);putjl(dst/'all-family-matrix.jsonl',[matrix[n] for n in sorted(matrix)])
 olddraft={}
 for plat in ('douyin','xiaohongshu'):
  for r in jl(BASE/(plat+'-candidate.jsonl')):
   k=(plat,str(r['comment_id']),str(r['customer_uid']))
   if k in by:olddraft[k]=r.get('mother_reply_text') or r.get('alternative_mother_reply_text')
 if set(olddraft)!=set(by):raise ValueError('v1 sidecar mismatch')
 counts=collections.Counter();families=collections.Counter();totals=collections.Counter();class_counts=collections.Counter();changes=[];seen=set();replayed=0
 for plat,path in cur['results'].items():
  digest=sha(path)
  with (dst/(plat+'-candidate.jsonl')).open('w',encoding='utf8',newline='\n') as out:
   for row in jl(path):
    k=(plat,str(row['comment_id']),str(row['customer_uid']));totals[plat]+=1;class_counts[(plat,row.get('role'),row.get('demand_state'),row.get('interest_at_comment'))]+=1
    if row.get('send_authorized') is not False or row.get('can_send_now') is not False:raise ValueError('source send flags')
    p=by.get(k);r=row
    if p:
     if k in seen:raise ValueError('duplicate source');
     seen.add(k);selection=core.verify_binding(p,row,digest)
     if k in p2 and p2[k]['original_contact_policy']!=row.get('contact_policy'):raise ValueError('v2 source contact mismatch')
     if p.get('family'):
      r=core.candidate_for(p,row,contract,digest);meta=r['local_mother_candidate'];meta.update(repair_overlay_sha256=p.get('repair_overlay_sha256'),repair_base_plan_sha256=p.get('repair_base_plan_sha256'),repair_newly_bound_short_lease=p.get('repair_newly_bound_short_lease',False),v2_overlay_sha256=p.get('v2_overlay_sha256'),v2_base_ABC_plan_sha256=p.get('v2_base_ABC_plan_sha256'),v2_base_v1_plan_sha256=p.get('v2_base_v1_plan_sha256'),contract_sha256=FIXED['repair-contract.json']);kind=meta['draft_type'];families[p['family']]+=1;new=r['mother_reply_text'] or r['alternative_mother_reply_text']
      if k in p2:
       replayed+=1
       if v1.sha_text(olddraft[k])!=p2[k]['old_preview_sha256'] or v1.sha_text(new)!=p2[k]['new_preview_sha256']:raise ValueError('v2 preview SHA mismatch '+str(k))
      if new!=olddraft[k]:changes.append({'platform':plat,'cid':k[1],'uid':k[2],'source_comment_sha256':p['sourceSHA'],'selection':selection,'v1_candidate_text':olddraft[k],'v2_candidate_text':new,'v2_overlay_sha256':p.get('v2_overlay_sha256'),'contract_sha256':FIXED['repair-contract.json']})
      counts[(plat,selection,kind)]+=1;counts[(plat,selection,kind+'_contact_unknown')]+=int(row.get('contact_policy') in (None,'unknown'));counts[(plat,selection,'contact_review_required')]+=int(meta['contact_review_required'])
     else:
      r=copy.deepcopy(row);r['local_mother_candidate']={'status':'basic_draft_pending_pool_binding','selection_preserved':selection,'hold_reasons':p['hold_reasons'],'contact_original':row.get('contact_policy'),'contact_review_required':row.get('contact_policy') in (None,'unknown','manual_review','identity_restricted','manual'),'contact_eligible':'not_assessed','send_authorized':False,'can_send_now':False};counts[(plat,selection,'basic_pending')]+=1;counts[(plat,selection,'basic_pending_contact_unknown')]+=int(row.get('contact_policy') in (None,'unknown'));counts[(plat,selection,'contact_review_required')]+=int(r['local_mother_candidate']['contact_review_required'])
    restored=copy.deepcopy(r);meta=restored.pop('local_mother_candidate',None)
    if meta and meta.get('old_draft_backup'):restored['mother_reply_text']=meta['old_draft_backup']['mother_reply_text'];restored['alternative_mother_reply_text']=meta['old_draft_backup']['alternative_mother_reply_text']
    if restored!=row:raise ValueError('original restoration mismatch '+str(k))
    out.write(json.dumps(r,ensure_ascii=False,sort_keys=True,separators=(',',':'))+'\n')
 if seen!=set(by) or replayed!=266:raise ValueError('replay coverage mismatch')
 if families!=collections.Counter({n:x['use_count'] for n,x in matrix.items() if x['use_count']}):raise ValueError('family matrix use mismatch')
 putjl(dst/'v2-draft-change-ledger.jsonl',changes);(dst/'published-fix-annotations.jsonl').write_bytes((BASE/'published-fix-annotations.jsonl').read_bytes())
 post={p:sha(p) for p in protected}
 if post!=pre:raise ValueError('input changed during v2 assembly')
 if any(sha(p)!=snap[n] for n,p in live.items()):raise ValueError('live pointer changed during v2 build')
 def group(c):
  x={}
  for (plat,sel,kind),n in sorted(c.items()):x.setdefault(plat,{}).setdefault(sel,{})[kind]=n
  return x
 names=['merged-contract.json','merged-plans.jsonl','all-family-matrix.jsonl','douyin-candidate.jsonl','xiaohongshu-candidate.jsonl','v2-draft-change-ledger.jsonl','published-fix-annotations.jsonl'];hashes={n:sha(dst/n) for n in names};mutable={str(x.resolve()) for x in live.values()};immutable_before={k:v for k,v in pre.items() if k not in mutable};immutable_after={k:v for k,v in post.items() if k not in mutable}
 man={'status':'candidate_only_needs_independent_astra_semantic_gate','repair_v1_READY_sha256':v1.FIXED['READY.json'],'repair_v2_READY_sha256':FIXED['READY.json'],'repair_v2_contract_sha256':FIXED['repair-contract.json'],'repair_v2_incremental_overlay_sha256':FIXED['incremental-plan-overlays.jsonl'],'v1_then_v2_equals_cumulative':True,'immutable_input_sha256_before':immutable_before,'immutable_input_sha256_after':immutable_after,'immutable_baseline_sha256':snap,'expected_previous_region_pointer_sha256':snap['region-current.json'],'expected_previous_reply_pointer_sha256':snap['reply-pointer.json'],'expected_previous_latest_manifest_sha256':snap['latest-manifest.json'],'output_sha256':hashes,'counts':group(counts),'candidate_rows':dict(totals),'classification_counts_unmodified':{'|'.join(str(z) for z in k):n for k,n in class_counts.items()},'families_total':len(matrix),'families_used':len(families),'families_unused':sum(x['unused'] for x in matrix.values()),'actual_plan_render_replays':sum(families.values()),'v1_overlay_count':813,'v2_overlay_count':replayed,'v2_draft_text_changed':len(changes),'published_241_annotations_applied':False,'source_writes':0,'pointer_updates':0,'send_authorized':False}
 dump(dst/'candidate-manifest.json',man);pointer={'status':man['status'],'candidate_manifest':str(dst/'candidate-manifest.json'),'candidate_manifest_sha256':sha(dst/'candidate-manifest.json'),'results':{p:str(dst/(p+'-candidate.jsonl')) for p in cur['results']},'expected_previous_region_pointer_sha256':snap['region-current.json'],'expected_previous_reply_pointer_sha256':snap['reply-pointer.json'],'activated':False,'send_authorized':False};dump(dst/'candidate-pointer.json',pointer)
 print(json.dumps({'status':man['status'],'counts':man['counts'],'candidate_rows':man['candidate_rows'],'families':{'total':len(matrix),'used':len(families),'unused':man['families_unused']},'replayed':sum(families.values()),'v2_overlays':replayed,'v2_changed':len(changes),'output_sha256':hashes},ensure_ascii=False))
if __name__=='__main__':main()
