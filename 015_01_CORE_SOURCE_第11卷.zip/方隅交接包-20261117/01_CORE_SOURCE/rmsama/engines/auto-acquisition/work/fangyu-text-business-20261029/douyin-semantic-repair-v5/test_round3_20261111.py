"""Round 3 (2026-11-11 ~14:00): 7 items from suspect-in-send-queue-1341.json plus boundaries."""
import unittest
import business_fit as f
import semantic_guard as g
B=g.base

class Round3(unittest.TestCase):
 def test_advice_complaint_rhetorical(self):
  for t in ['一个个说该退押金的，下次自己租一套满意的房子稳定下来，房东通知你下个月就搬走看你要不要违约金','想租哪里的[再见]','还去看看中介店租金吧！！[呲牙][呲牙][呲牙]']:
   with self.subTest(t=t):self.assertTrue(f.r3_flags(t)['advice'] or f.advice_not_self(t))
 def test_own_home_roommate_supply(self):
  self.assertTrue(f.r3_flags('杨浦区找个女的合租，不要男的，我自己租的房子，非中介，谢谢！')['own_home_roommate'])
  for t in ['我想找室友一起合租','想找个室友合租，还没找到房','我在杨浦，想找个女生合租','我自己租的房子太贵了想换','我家有两只猫，想找个室友合租']:
   with self.subTest(t=t):self.assertFalse(f.r3_flags(t)['own_home_roommate'])
 def test_bulk_manual(self):
  self.assertTrue(f.r3_flags('要40间。长期住。需独立卫浴。洗衣机 有房源的联系我')['bulk'])
  self.assertFalse(f.r3_flags('想找个房租，做四个人的员工宿舍')['bulk'])
 def test_weak_demand(self):
  self.assertTrue(f.r3_flags('想问一下都是在哪里遇到这样的房子的，中介吗？还是app')['weak'])
  for t in ['你在哪里找的房  可以推荐我吗？','这是在哪里租的？我也想租','我想找个一居室，你们在哪找的房','求租一个单间']:
   with self.subTest(t=t):self.assertFalse(f.r3_flags(t)['weak'])
 def test_screen_labels_and_holds(self):
  row=lambda t:{'comment_text':t,'platform':'douyin','role':'demand','published_at_unix':__import__('time').time()-86400*8}
  s=f.screen(row('要40间。长期住。需独立卫浴。洗衣机 有房源的联系我'))
  self.assertFalse(s['eligible_candidate']);self.assertEqual(s['exclusion_reasons'],[]);self.assertIn('bulk_enterprise_manual_followup',s['verification_required']);self.assertEqual(s['manual_followup'],['批量/企业需求-人工跟进'])
  s=f.screen(row('想问一下都是在哪里遇到这样的房子的，中介吗？还是app'))
  self.assertFalse(s['eligible_candidate']);self.assertEqual(s['manual_followup'],['需求弱-不自动回'])
  s=f.screen(row('杨浦区找个女的合租，不要男的，我自己租的房子，非中介，谢谢！'))
  self.assertIn('供给方：自有房找室友/分租出去',s['exclusion_reason_labels'])
  s=f.screen(row('想租哪里的[再见]'))
  self.assertIn('advice_not_self_demand',s['exclusion_reasons'])
 def test_location_not_verb_phrase(self):
  self.assertEqual(B._valid_locations(['刚来路']),[])
  self.assertEqual(B._valid_locations(['顺路']),[])
  self.assertEqual(B._valid_locations(['回龙观附近']),['回龙观附近'])
  d=B.render({'comment_text':'附近有房子租吗？刚来路过问一句','pools':['位置通勤']})['draft_text']
  self.assertNotIn('刚来路',d);self.assertIn('方隅公寓',d)

if __name__=='__main__':unittest.main()
