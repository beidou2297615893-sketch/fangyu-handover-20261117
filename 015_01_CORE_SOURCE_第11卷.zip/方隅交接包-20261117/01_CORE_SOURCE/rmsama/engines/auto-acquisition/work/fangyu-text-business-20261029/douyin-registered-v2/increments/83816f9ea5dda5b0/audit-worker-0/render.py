import json,pathlib,sys,collections
P=pathlib.Path(__file__).resolve().parent
B=P.parent
A=B/'recall-audit'/'part-0'
def j(x):return json.dumps(x,ensure_ascii=False,separators=(',',':'))
def render(n):
 d=json.loads((A/f'page-{n:02}.json').read_text('utf-8'))
 lo=int(sys.argv[2]) if len(sys.argv)>2 else 0
 hi=int(sys.argv[3]) if len(sys.argv)>3 else 9999
 ix=0
 for g in d['post_groups']:
  cs=g['comments'];g['comments']=[c for i,c in enumerate(cs,ix) if lo<=i<hi];ix+=len(cs)
 d['post_groups']=[g for g in d['post_groups'] if g['comments']]
 # Lossless display: own full quote is =, repeated values are dictionaries.
 strings=collections.Counter()
 def norm(v,t):
  if isinstance(v,str):return v.replace(t,'《本人全文》') if t and len(t)>2 else v
  if isinstance(v,list):return [norm(z,t) for z in v]
  if isinstance(v,dict):return {k:norm(z,t) for k,z in v.items()}
  return v
 def count(v):
  if isinstance(v,str) and len(v)>9:strings[v]+=1
  elif isinstance(v,list):
   for z in v:count(z)
  elif isinstance(v,dict):
   for z in v.values():count(z)
 for g in d['post_groups']:
  for c in g['comments']:count(norm(c['first_semantic_judgment'],c['text']))
 dic={v:'S'+str(i) for i,(v,ct) in enumerate(strings.items()) if ct>1}
 print('LOSSLESS shorthand: default judgment fields are topics,target_regions,time_mentions,other_constraints,possible_topics,needs_review,contact_boundaries,context_used=[]; reply_plan absent only means printed separately. 《本人全文》=entire current text. S references below. No judgment values removed except empty lists. Metadata default same_author=false,parent=null,reply_to=0,source_conflict=false.')
 for v,k in dic.items():print(k+'='+j(v))
 def sub(v):
  if isinstance(v,str):return '$'+dic[v] if v in dic else v
  if isinstance(v,list):return [sub(z) for z in v]
  if isinstance(v,dict):return {k:sub(z) for k,z in v.items() if z!=[]}
  return v
 def compact(z):
  z=dict(z)
  maps={'role':'r','demand_state':'s','interest':'i','reason':'why','topics':'t','target_regions':'loc','time_mentions':'time','other_constraints':'other','possible_topics':'maybe','needs_review':'nr','contact_boundaries':'bound','context_used':'ctx'}
  if z.get('context_used')==['own','body']:z.pop('context_used')
  if 'topics' in z:z['topics']=[[x['pool'],x['quote'],x['polarity'],x['subject'],x['condition_scope']] for x in z['topics']]
  if 'target_regions' in z:z['target_regions']=[[x['text'],x['quote'],x['relation'],x['group_relation'],x['condition_scope']] for x in z['target_regions']]
  return {maps.get(k,k):v for k,v in sub(z).items()}
 print('Abbrev: r=role,s=demand_state,i=interest,why=reason,t=topics tuples [pool,quote,polarity,subject,condition_scope];loc=target_regions tuples [text,quote,relation,group_relation,condition_scope];time=time_mentions,other=other_constraints,maybe=possible_topics,nr=needs_review,bound=contact_boundaries,ctx=context_used defaults own/body. Plans use exact fields as shown.')
 plans={}
 for g in d['post_groups']:
  print('BODY '+j({k:v for k,v in g.items() if k!='comments'}))
  for c in g['comments']:
   z=norm(c['first_semantic_judgment'],c['text']);plan=z.pop('reply_plan');ps=j(sub(plan))
   if ps not in plans:
    plans[ps]='P'+str(len(plans));print(plans[ps]+'='+ps)
   meta={k:v for k,v in c.items() if k not in ('key','text','first_semantic_judgment','audit_selection') and v not in (False,None,'0')}
   print(c['key']+' '+j(c['text'])+' '+j(meta)+' '+j(compact(z))+' '+plans[ps])
if __name__=='__main__':render(int(sys.argv[1]))
