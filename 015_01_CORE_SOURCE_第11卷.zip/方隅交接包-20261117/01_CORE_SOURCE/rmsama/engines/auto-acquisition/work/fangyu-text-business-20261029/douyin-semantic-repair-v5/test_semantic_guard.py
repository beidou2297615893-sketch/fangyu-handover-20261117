import unittest
import semantic_guard as g
class Semantics(unittest.TestCase):
 def test_internship_duration_does_not_remove_explicit_renewal_pool(self):
  row={'comment_text':'我想问一下实习五个月，人才公寓满三个月能续租吗','role':'demand','interest_at_comment':'medium','pools':['入住与租期']}
  reply=g.render(row)
  self.assertTrue(reply['draft_text'])
  self.assertNotIn('租五个月',reply['draft_text'])
  self.assertNotIn('能续租',reply['draft_text'])
  self.assertIn('入住与租期',reply['semantic_guard']['pools'])
 def test_duration_not_search(self):
  for text in ['我找了半天，最后决定租保租房了','说半天多少钱呢','看了一个月房了','我找了3天了 都没找找西罗园附近','我看了一个一个月800的整租套一精装']:
   with self.subTest(text=text):self.assertEqual(g.details(text)['time'],[])
 def test_duration_real(self):
  for text,expected in [('想租半天',['半天']),('能租三个月吗',['三个月']),('你好找一个房子租两个月预算一千五',['两个月']),('11月入住',['11月'])]:
   with self.subTest(text=text):self.assertEqual(g.details(text)['time'],expected)
 def test_state(self):
  for t in ['怎么才能直接找到房东','没找到合适房','预算能找到合租房吗','我决定租房了，有推荐吗','已经租到房了但我想换房']:
   self.assertEqual(g.state(t)[0],'active_or_unknown',t)
  self.assertEqual(g.state('我已经租到房了')[0],'ended')
  self.assertEqual(g.state('最后决定租保租房了')[0],'choice_made_unconfirmed')
 def test_actual_bad(self):
  r=g.render({'comment_text':'我找了半天，最后决定租保租房了，反正我不养猫，最后就算赔点钱也是赚的','pools':['入住与租期','宠物']})
  self.assertIsNone(r['draft_text'])
 def test_price(self):
  r=g.render({'comment_text':'说半天多少钱呢','pools':['入住与租期','价格预算']})
  self.assertNotIn('半天',r['draft_text']);self.assertIn('价格',r['draft_text'])
 def test_negations(self):
  r=g.render({'comment_text':'不养猫，预算2000找房','pools':['宠物','价格预算','房源状态']})
  self.assertIsNone(r['draft_text']);self.assertTrue(r['semantic_guard']['negative_conditions_preserved'])
  self.assertEqual(r['commercial_fit']['commercial_fit'],'very_low')
 def test_pet_question(self):
  self.assertIsNone(g.render({'comment_text':'不能养猫吗','pools':['宠物']})['draft_text'])
 def test_calendar_and_no_shared(self):
  self.assertIn('下个月',g.details('准备下个月租房，不合租')['time'])
  r=g.render({'comment_text':'准备下个月租房，不合租','pools':['入住与租期','户型面积与居住方式']})
  self.assertNotIn('不合租',r['draft_text'])
  self.assertIn('不合租',r['semantic_guard']['negative_conditions_preserved'])
 def test_agent_fee_not_agent(self):
  r=g.render({'comment_text':'不要中介费，求租','pools':['费用合同','房源状态']})
  self.assertIn('不要中介费',r['semantic_guard']['negative_conditions_preserved'])
  self.assertNotIn('不要中介',r['semantic_guard']['negative_conditions_preserved'])
 def test_short_lease_not_calendar(self):
  self.assertEqual(g.details('短租二月，租一月二月，不要押金')['time'],['一个月','两个月'])
  r=g.render({'comment_text':'短租二月，租一月二月，不要押金','pools':['入住与租期','费用合同']})
  self.assertIn('不要押金',r['semantic_guard']['negative_conditions_preserved'])
 def test_conditional_not_ready(self):
  r=g.render({'comment_text':'这个房子800[抠鼻]要是真的我马上就把这边房子退了，押金也不要就去了','pools':['价格预算']})
  self.assertIsNone(r['draft_text'])
 def test_agent_restriction(self):
  r=g.render({'comment_text':'求租不要中介','pools':['房源状态']})
  self.assertTrue(r['contact_hold'])
 def test_narrative_road_not_location(self):
  t='我最近找房子也是中介骑着小电驴带我看房在马路上我坐后面总有路人投来异样的眼光看着我，搞得我真的尴尬'
  self.assertEqual(g.details(t)['location'],[])
  self.assertIn('红松东路',g.details('红松东路附近求租')['location'][0])
if __name__=='__main__':unittest.main()
