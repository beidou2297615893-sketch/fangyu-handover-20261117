import json,pathlib,collections
W=pathlib.Path('work/fangyu-text-business-20261029'); inv=json.loads((W/'pool-mother-review/legacy-inventory/inventory.json').read_text(encoding='utf-8')); ps=[json.loads(l) for l in (W/'pool-mother-review/legacy-inventory/proposed-local-plan.jsonl').read_text(encoding='utf-8').splitlines()]; cur=json.loads((W/'region-brand-routing/current.json').read_text(encoding='utf-8')); rows={}
for p,f in cur['results'].items():
 for l in open(f,encoding='utf-8'):
  r=json.loads(l); rows[p,r['comment_id'],r['customer_uid']]=r
seen=set()
for p,s in inv['platforms'].items():
 for tag,es in s['sample_examples'].items():
  for e in es:
   k=p,e['cid'],e['uid']
   if k in seen:continue
   seen.add(k);r=rows[k]
   print(json.dumps({'n':len(seen),'tag':tag,'platform':p,'cid':e['cid'],'uid':e['uid'],'comment':e['comment'],'fields':next(x['source_field_evidence'] for x in ps if (x['platform'],x['cid'],x['uid'])==k),'post':r.get('post_body') or r.get('video_desc'),'source_keys':list(r['source_record'])},ensure_ascii=False))
print('unique samples',len(seen))
print('first source',json.dumps(next(iter(rows.values())),ensure_ascii=False)[:13000])
