import unittest
from renderer import render, SINGLE, SUBTAGS, CAT, TAG_ROUTES, CLASSIFIER_REGISTRY

class SOPTests(unittest.TestCase):
 def r(self,text,pools,subtags=None):return render({'comment_text':text,'pools':pools,'subtags':subtags or []})
 def test_registered_templates(self):self.assertEqual(sum(map(len,SUBTAGS.values())),49);self.assertEqual(len(SINGLE),49)
 def test_cat(self):self.assertEqual(self.r('可以养猫吗',['宠物'])['draft_text'],CAT)
 def test_price_no_slot(self):self.assertTrue(self.r('多少米',['价格预算'])['draft_text'])
 def test_price_does_not_invent_quote(self):self.assertNotIn('2500的房源',self.r('预算2500',['价格预算'])['draft_text'])
 def test_chinese_month(self):self.assertIn('七月底',self.r('七月底换房子，还有吗',['入住与租期','房源状态'])['draft_text'])
 def test_numeric_time(self):
  t=self.r('就7月初住10天',['入住与租期'])['draft_text'];self.assertIn('7月初',t);self.assertIn('10天',t);self.assertNotIn('可在',t)
 def test_district(self):self.assertIn('双流区',self.r('预算2k，双流区有套一吗',['价格预算','位置通勤','户型面积与居住方式'])['draft_text'])
 def test_or(self):
  r=self.r('浦东或者奉贤有没',['位置通勤','房源状态']);self.assertEqual(r['requested_details']['relation'],'alternative');self.assertNotIn('都有',r['draft_text'])
 def test_not_shared(self):
  t=self.r('不合租，预算3000',['户型面积与居住方式','价格预算'])['draft_text'];self.assertIn('不合租',t);self.assertNotIn('有合租',t)
 def test_view_no_slot(self):self.assertTrue(self.r('怎么联系看房',['看房联系'],['预约看房','联系咨询'])['draft_text'])
 def test_didi(self):self.assertTrue(self.r('滴滴',['看房联系'])['draft_text'])
 def test_dd(self):self.assertTrue(self.r('dd',['看房联系'])['draft_text'])
 def test_no_vacancy_claim(self):self.assertNotIn('有空房',self.r('还有没有房',['房源状态'])['draft_text'])
 def test_no_wrong_cat(self):self.assertNotIn('能带猫',self.r('不养猫',['宠物'])['draft_text'])
 def test_no_auto_send(self):self.assertFalse(self.r('租一个月',['入住与租期'])['send_authorized'])
 def test_unknown_pool(self):self.assertIsNone(self.r('哈哈',[])['draft_text'])
 def test_contact_boundary(self):self.assertTrue(self.r('中介勿扰',['看房联系'])['contact_hold'])
 def test_same_fact_check(self):self.assertIn('适用房源猫政策',self.r('猫可以吗',['宠物'])['fact_checks'])
 def test_pool_variation(self):self.assertGreater(len({self.r('想了解', [p])['draft_text'] for p in SUBTAGS}),7)
 def test_budget_cat_not_lost(self):
  t=self.r('预算2500带猫',['价格预算','宠物'])['draft_text'];self.assertIn('2500',t);self.assertIn('带猫',t)
 def test_budget_kitchen_lift(self):
  t=self.r('预算2500有厨房带电梯',['价格预算','房内设施','楼层电梯'])['draft_text'];self.assertIn('厨房',t);self.assertIn('电梯',t)
 def test_or_places_preserved(self):
  for a,b in [('浦东','奉贤'),('成华','武侯'),('杨浦','静安')]:
   t=self.r(a+'或者'+b+'有吗',['位置通勤','房源状态'])['draft_text'];self.assertIn(a+'或'+b,t)
 def test_price_and_layout(self):
  t=self.r('一室一厅多少',['价格预算','户型面积与居住方式'])['draft_text'];self.assertIn('一室一厅',t);self.assertIn('价格',t)
 def test_negative_cat_question(self):self.assertNotIn('能带猫的',self.r('不能养猫吗',['宠物'])['draft_text'])
 def test_lead_styles_differ(self):
  a=self.r('预算2500',['价格预算']);b=self.r('浦东区有吗',['位置通勤']);c=self.r('租一个月',['入住与租期']);d=self.r('一室一厅多少',['价格预算','户型面积与居住方式'])
  self.assertEqual(len({x['template_id'].split(':')[0] for x in [a,b,c,d]}),4)
  self.assertIn('价格也一起比比',d['draft_text'])
 def test_distance_preposition(self):
  r=self.r('离5号线多远',['位置通勤']);self.assertNotIn('找离',r['draft_text']);self.assertIn('5号线',r['draft_text']);self.assertTrue(any('距离另核' in x for x in r['unanswered_details']))
 def test_indefinite_months_are_term_not_movein(self):
  r=self.r('租几个月行吗',['入住与租期']);self.assertIn('租期挺灵活',r['draft_text']);self.assertNotIn('入住时间',r['draft_text'])
 def test_same_pool_facilities_all_kept(self):
  r=self.r('我也求这里的，想要燃气洗澡做饭',['房内设施']);self.assertIn('燃气',r['draft_text']);self.assertIn('做饭',r['draft_text'])
 def test_district_subarea_no_garbage(self):
  r=self.r('余杭区五常那边有没有便宜点的小区',['价格预算','位置通勤']);self.assertIn('余杭区五常',r['draft_text']);self.assertNotIn('那边有没有',r['draft_text']);self.assertNotIn('便宜点的小区',r['draft_text'])
 def test_generic_list_punctuation(self):
  r=self.r('这个户型价格',['价格预算','户型面积与居住方式']);self.assertIn('价格、房型',r['draft_text'])
 def test_classifier_registry_complete(self):
  for item in CLASSIFIER_REGISTRY['rules']:
   route=TAG_ROUTES[item['subtag']];self.assertIn(route['mode'],('explicit','pool_generic'))
   r=self.r('想了解',[item['pool']],[item['subtag']]);self.assertTrue(r['draft_text'])
 def test_non_kitchen_facility_never_defaults_kitchen(self):
  for tag in ['停车充电配套','环境与安全','管家服务']:
   r=self.r('想了解',['房内设施'],[tag]);self.assertNotIn('做饭',r['draft_text']);self.assertNotIn('厨房',r['draft_text']);self.assertEqual(r['template_id'],'subtag:'+tag)
 def test_unknown_facility_generic(self):
  r=self.r('想了解',['房内设施'],['未来新标签']);self.assertEqual(r['template_id'],'pool_generic:房内设施');self.assertNotIn('做饭',r['draft_text'])
 def test_alias_routes(self):
  r=self.r('想了解',['价格预算'],['预算']);self.assertEqual(r['template_id'],'subtag:预算上限')
 def test_qualification_not_occupancy_claim(self):
  r=self.r('想了解',['户型面积与居住方式'],['人数与居住资格']);self.assertNotIn('都可以住',r['draft_text']);self.assertEqual(r['template_id'],'subtag:人数与居住资格')
 def test_no_kitchen_excluded(self):
  r=self.r('不需要厨房',['房内设施'],['厨房']);self.assertIn('不需要厨房',r['draft_text']);self.assertNotIn('做饭挺方便',r['draft_text'])
 def test_dog_excluded_cat_wanted(self):
  r=self.r('不养狗但养猫',['宠物'],['狗','猫']);self.assertIn('不养狗',r['draft_text']);self.assertIn('带猫',r['draft_text']);self.assertNotIn('能带狗',r['draft_text'])
 def test_high_floor_excluded(self):
  r=self.r('不要高楼层',['楼层电梯'],['楼层']);self.assertIn('不要高楼层',r['draft_text']);self.assertNotIn('有高楼层',r['draft_text'])
 def test_question_not_negative_even_bad_upstream(self):
  r=render({'comment_text':'有没有短租一个月','pools':['入住与租期'],'subtags':['短租'],'constraints':{'negative_spans':[{'quote':'一个月','polarity':'excluded'}]}})
  self.assertNotIn('不租',r['draft_text']);self.assertEqual(r['requested_details']['exclusions'],[])

if __name__=='__main__':unittest.main()
