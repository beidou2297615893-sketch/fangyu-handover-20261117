"""Offline, conservative housing-comment rules. No network or model clients.

The automaton supplies lexical spans; business rules establish subject, rental
context and intent separately. A lexical hit alone never establishes demand.
"""
from __future__ import annotations

import hashlib
import json
import re
import sys
from pathlib import Path

_ROOT = Path(__file__).resolve().parent
if (_ROOT / 'vendor').is_dir():
    sys.path.insert(0, str(_ROOT / 'vendor'))
try:
    import ahocorasick
except ImportError:  # deterministic fallback, reported in the result
    ahocorasick = None


def _clauses(text):
    parts = []
    for m in re.finditer(r'[^，,；;。！？!?\n]+', text):
        parts.extend(x.strip() for x in re.split(r'(?=但我|但现在|但还|另外我|同时我)', m.group()) if x.strip())
    return parts


class LocalClassifier:
    def __init__(self, config_path=None):
        path = Path(config_path) if config_path else _ROOT / 'rule_config.json'
        raw = path.read_bytes()
        self.config = json.loads(raw.decode('utf-8-sig'))
        self.version = self.config['version']
        self.rule_version = self.version
        self.config_digest = hashlib.sha256(raw).hexdigest()
        self.patterns = {k: [re.compile(p) for p in values]
                         for k, values in self.config['patterns'].items()}
        self.words = {}
        for pool, words in self.config['topics'].items():
            for word in words:
                self.words.setdefault(word, []).append(('topic', pool))
        for region in self.config['regions']:
            self.words.setdefault(region, []).append(('region', region))
        self.automaton = None
        if ahocorasick:
            self.automaton = ahocorasick.Automaton()
            for word, tags in self.words.items():
                self.automaton.add_word(word, (word, tags))
            self.automaton.make_automaton()
        self.budget_re = re.compile(self.config['budget_pattern'])

    def has(self, name, text):
        return any(p.search(text) for p in self.patterns[name])

    def spans(self, text):
        if self.automaton is not None:
            for end, (word, tags) in self.automaton.iter(text):
                for kind, value in tags:
                    yield {'kind': kind, 'value': value, 'word': word,
                           'start': end - len(word) + 1, 'end': end + 1}
        else:
            for word, tags in self.words.items():
                for m in re.finditer(re.escape(word), text):
                    for kind, value in tags:
                        yield {'kind': kind, 'value': value, 'word': word,
                               'start': m.start(), 'end': m.end()}

    @staticmethod
    def _polarity(clause):
        if re.search(r'(?:超过|低于|高于|如果|除非|只要|要是|只有).*(?:不|才|就|可以|接受)', clause):
            return 'conditional'
        if re.search(r'不需要', clause):
            return 'not_required'
        if re.search(r'不介意|无所谓|也可|可以接受|能接受', clause):
            return 'accept'
        if re.search(r'不(?:要|能|接受|考虑|合租|养)|拒绝|不要|不能|没有.{0,8}不考虑', clause):
            return 'reject'
        if re.search(r'最好|优先|倾向|希望', clause):
            return 'prefer'
        if re.search(r'[吗嘛么?？]|多少|哪里|在哪|几室|几居|能否|是否', clause):
            return 'ask'
        if re.search(r'必须|一定要|只要|要求|需要|要', clause):
            return 'require'
        return 'fact'

    def _pet_ownership(self, sources):
        """Only explicit first-person facts establish commenter pet ownership.

        Housing permission, another beneficiary's needs and carrying a pet do
        not prove ownership. A newer explicit comment fact outranks own-body
        context. The nullable value distinguishes unknown from confirmed no pet.
        """
        found = []
        for source, value in sources:
            source_found = []
            for clause in _clauses(value):
                if self.has('pet_owner_nonassertive', clause):
                    continue
                has_pet = self.has('pet_owner_positive', clause)
                no_pet = self.has('pet_owner_negative', clause)
                if has_pet or no_pet:
                    source_found.append({'quote':clause, 'source':source, 'subject':'self',
                                         'has_pet':True if has_pet and not no_pet else False if no_pet and not has_pet else None})
            if source_found:
                found = source_found
                break
        values = {e['has_pet'] for e in found}
        value = next(iter(values)) if len(values) == 1 and None not in values else None
        status = 'confirmed_has_pet' if value is True else 'confirmed_no_pet' if value is False else 'conflicting_self_claims' if found else 'unknown'
        return {'owns_pet':value is True, 'owns_pet_false_semantics':'not_confirmed',
                'pet_ownership':value, 'pet_ownership_status':status,
                'pet_ownership_evidence':found}

    def classify(self, record: dict) -> dict:
        # Aliases support old frozen examples, while caller identity is preserved.
        text = str(record.get('comment_text', record.get('text', '')) or '')
        body = str(record.get('post_body', record.get('post_text', '')) or '')
        title = str(record.get('post_title', '') or '')
        own_body = record.get('post_author_same_as_commenter') is True
        sources = [('comment_text', text)]
        if own_body and body:
            sources.append(('post_body', body))
        personal = '\n'.join(s for _, s in sources)
        contextual = '\n'.join([title, body])
        parent = str(record.get('direct_parent_text', '') or '')
        if parent and record.get('reply_to'):
            contextual += '\n' + parent
        rental_context = self.has('rental_context', contextual) and not self.has('not_rental_context', contextual)
        seek_offer_ambiguity = any(self.has('supply', clause) and self.has('seek_offer_ambiguity', clause)
                                   for _, value in sources for clause in _clauses(value))
        supply = any(self.has('supply', clause) and not self.has('seek_offer_ambiguity', clause)
                     for _, value in sources for clause in _clauses(value))
        ended = self.has('ended', personal)
        historical = self.has('historical', personal)
        future = self.has('future_search', personal)
        future_plan = self.has('explicit_future_plan', personal)
        potential = self.has('potential', personal)
        beneficiary = 'other' if self.has('beneficiary_other', personal) else 'self'
        subject = 'other_person' if beneficiary == 'other' else 'own_demand'

        parts = []
        for source, source_text in sources:
            mode = 'supply' if supply else 'unknown'
            for clause in _clauses(source_text):
                is_supply = self.has('supply', clause) and not self.has('seek_offer_ambiguity', clause)
                demand = self.has('demand', clause)
                demand = demand and not self.has('negative_demand', clause) and not self.has('past_clause', clause)
                if supply:
                    # Generic price words after an offer are still the offer.
                    demand = demand and bool(re.search(r'求租|找房|找[一两二三四单]|(?:想|正在|现在)找|想(?:换租|租)|另外.{0,8}(?:租|找)|换租[一两二三四]', clause))
                if is_supply:
                    mode = 'supply'
                if demand and not is_supply:
                    mode = 'demand'
                parts.append({'source':source, 'quote':clause, 'explicit_demand': demand and not is_supply,
                              'mode':mode, 'is_supply':is_supply})
        demand = any(p['explicit_demand'] for p in parts)
        contextual_inquiry = bool(text.strip()) and rental_context and self.has('inquiry', text) and not supply
        # Short weak questions are only effective inquiries in an explicit rental context.
        if self.has('negative_demand', personal) and not demand:
            contextual_inquiry = False
        demand = demand or contextual_inquiry or (potential and not supply) or (future_plan and not supply)
        appointment = any(self.has('appointment', p['quote']) and not self.has('negated_appointment', p['quote']) and not self.has('past_clause', p['quote']) for p in parts) and (demand or rental_context)
        demand = demand or appointment
        fresh_demand = any(p['explicit_demand'] and re.search(r'现在|重新|另外|换租|还在|正在|求租', p['quote']) for p in parts)
        fresh_comment = any(p['source'] == 'comment_text' and p['explicit_demand'] and re.search(r'现在|重新|另外|换租|还在|正在|求租', p['quote']) for p in parts)
        unresolved_ended = (self.has('ended', text) and not fresh_comment) or (ended and not fresh_demand)
        if unresolved_ended:
            demand = False

        role = 'mixed' if supply and demand else 'supply' if supply else 'demand' if demand else 'discussion' if historical or unresolved_ended else 'unknown'
        state = 'ended' if unresolved_ended else 'historical' if historical and not demand else 'future' if future_plan or potential else 'active_at_comment' if demand else 'unknown'
        if role == 'unknown' and re.search(r'好看|漂亮|装修真|谢谢分享|路过|哈哈|点赞|建议|以前住', personal):
            role = 'discussion'
        if role == 'unknown' and self.has('negative_demand', personal) and self.has('explicit_bystander', personal):
            role = 'discussion'
        if role == 'supply':
            state = 'unknown'
        demand_parts = []
        if demand:
            demand_parts = [p for p in parts if p['mode'] == 'demand' or (not supply and not p['is_supply'])]
            if ended and fresh_demand:
                demand_parts = [p for p in demand_parts if not (self.has('ended', p['quote']) and not p['explicit_demand'])]
            demand_parts = [p for p in demand_parts if not self.has('past_clause', p['quote']) and not (beneficiary == 'self' and self.has('third_party_background', p['quote']))]

        topics, possible, topic_evidence, rule_hits, evidence = [], [], [], [], []
        target_regions, time_mentions, budgets, other = [], [], [], []
        active_parts = demand_parts if demand else []
        for source, value in sources:
            for hit in self.spans(value):
                hit = dict(hit, source=source)
                rule_hits.append(hit)
                if hit['kind'] == 'topic' and hit['value'] not in possible:
                    possible.append(hit['value'])
        for p in active_parts:
            clause = p['quote']
            hits = list(self.spans(clause))
            pools = {h['value'] for h in hits if h['kind'] == 'topic'}
            # Numeric prices and months are interpreted with their units and verbs.
            if self.budget_re.search(clause) or re.search(r'\d+(?:元|块|k|K)(?:以内|左右|预算|一月|每月)', clause):
                pools.add('价格预算')
            if re.search(r'\d+(?:平|㎡)|[一二三四五六七八九十两\d]+(?:人住|个人住|室|居)', clause):
                pools.add('户型面积与居住方式')
            if re.search(r'(?:租|住)[一二三四五六七八九十两\d]+(?:个)?(?:月|年|天)', clause):
                pools.add('入住与租期')
            if re.search(r'\d+楼', clause):
                pools.add('楼层电梯')
            if re.search(r'一个月多少钱|一个月多少|每月多少钱|月租多少', clause) and not re.search(r'入住|起租|租期|短租|长租|租一个月|住一个月', clause):
                pools.discard('入住与租期')
                pools.add('价格预算')
            if any(h['kind'] == 'region' for h in hits):
                pools.add('位置通勤')
            for pool in self.config['topics']:
                if pool not in pools:
                    continue
                if pool not in topics:
                    topics.append(pool)
                topic_evidence.append({'pool':pool, 'quote':clause, 'source':p['source'],
                                       'subject':subject, 'polarity':self._polarity(clause),
                                       'condition_scope':clause})
            evidence.append({'kind':'demand', 'quote':clause, 'source':p['source'], 'subject':subject})
            for h in hits:
                if h['kind'] != 'region':
                    continue
                before, after = clause[:h['start']], clause[h['end']:]
                # Work/current/old-offer locations are background, not a residence target.
                background = bool(re.search(r'上班|工作|公司|学校在|现住|目前住|原来住|旧房|现在住', clause)) and not re.search(r'想住|求租|想租|找房|附近|通勤|也可|优先|不考虑', clause)
                background = background or bool(re.match(r'(?:上班|工作|务工|读书|上学)', after))
                if background:
                    continue
                relation = 'excluded' if re.search(r'^(?:不考虑|不要|不接受|不行)', after) or re.search(r'(?:不考虑|不要|不接受)$', before) else 'preferred' if re.search(r'^.{0,2}优先', after) else 'acceptable' if re.search(r'^.{0,2}(?:也可|可以|能接受)', after) else 'target'
                item = {'name':h['value'], 'relation':relation, 'quote':clause, 'source':p['source'],
                        'subject':subject, 'condition_scope':clause}
                if item not in target_regions:
                    target_regions.append(item)
            for m in self.budget_re.finditer(clause):
                budgets.append({'quote':m.group(), 'source':p['source'], 'subject':subject,
                                'kind':'stated_budget', 'condition_scope':clause})
            for m in re.finditer(r'(?:\d{4}年)?\d{1,2}月(?:\d{1,2}[日号])?|下个月|下月|这个月|本月|明年|年底|周末|今天|明天|后天|今晚|[一二三四五六七八九十两\d]+(?:个)?(?:月|年|天)', clause):
                q = m.group()
                if re.search(r'多少|月租|每月', clause) and not re.search(r'入住|租期|搬家|看房|约看|开始找|才找|租[一两三\d]|住[一两三\d]', clause):
                    continue
                kind = 'move_in' if re.search(r'入住|搬家', clause) else 'viewing' if re.search(r'看房|约看', clause) else 'search_start' if self.has('future_search', clause) else 'lease_duration' if re.search(r'租|住|租期', clause) else 'unspecified'
                anchor = record.get('published_at_unix', record.get('published_at'))
                time_mentions.append({'quote':q, 'kind':kind, 'source':p['source'], 'subject':subject,
                                      'anchor':anchor, 'resolved_date':None, 'needs_date_check':True,
                                      'condition_scope':clause})
            if self.has('other_constraints', clause):
                other.append({'quote':clause, 'source':p['source'], 'subject':subject,
                              'polarity':self._polarity(clause), 'condition_scope':clause})
        if not demand:
            for p in parts:
                if p['is_supply'] or self.has('ended', p['quote']) or self.has('historical', p['quote']):
                    evidence.append({'kind':'supply' if p['is_supply'] else 'ended' if self.has('ended', p['quote']) else 'historical',
                                     'quote':p['quote'], 'source':p['source'], 'subject':'supply' if p['is_supply'] else 'current_home'})
        possible = [x for x in possible if x not in topics]
        # A bare unit ambiguity is a data gap, even when a listing exists.
        unit_ambiguous = bool(re.fullmatch(r'\s*(?:多少米|几米)[?？。!！\s]*', text))
        domain_ambiguous = self.has('buy_or_ambiguous', personal) or self.has('business_use', personal)
        semantic = demand and (self.has('semantic_conflict', personal) or seek_offer_ambiguity)
        source_conflict = bool(record.get('source_version_conflict'))
        reasons, review_reasons = [], []
        interest = 'uncertain'
        exception = None
        needs_model = False
        if role in ('supply', 'discussion') or state == 'ended':
            interest = 'unrelated'
            reasons.append('明确供给、历史讨论或本人需求已结束；未据此推断当前新需求')
        elif demand:
            interest = 'very_low' if potential else 'low' if future_plan else 'super_high' if appointment else 'high' if topics or contextual_inquiry else 'medium'
            reasons.append('本人表达租赁需求' if not contextual_inquiry else '本人对明确出租语境作询盘；正文条件未搬入本人需求')
        if not text.strip() and not (own_body and body.strip()):
            reasons.append('评论为空，不能建立本人需求')
        if role == 'unknown' or unit_ambiguous or domain_ambiguous:
            interest, exception = 'uncertain', 'needs_context'
            review_reasons.append('需补租售、用途、供需主体或提问对象；不能由模型补造缺失事实')
        if unit_ambiguous:
            topics, topic_evidence = [], []
            possible = ['价格预算', '户型面积与居住方式']
            review_reasons.append('米可能表示金额或面积，需本人明确单位')
        if semantic:
            interest, exception, needs_model = 'uncertain', 'semantic_review', True
            review_reasons.append('寻找住宅与句尾出租措辞有供需歧义，保留寻找主体及户型供复核' if seek_offer_ambiguity else '已有本人需求证据与否定表达冲突，保留原范围供语义复核')
        if source_conflict:
            interest, exception, needs_model = 'uncertain', 'source_conflict', False
            review_reasons.append('来源版本存在冲突，需核对原始记录；模型不能确认来源真伪')
        if role == 'unknown' and not reasons:
            reasons.append('现有文字不足以确认本人需求，不把未知当无关')
        family = self.has('family', personal)
        result = dict(record)
        result.update({'comment_text':text, 'post_body':body, 'post_author_same_as_commenter':own_body,
                       'role':role, 'demand_state':state, 'interest_at_comment':interest,
                       'beneficiary':beneficiary, 'topics':topics, 'topic_evidence':topic_evidence,
                       'target_regions':target_regions, 'time_mentions':time_mentions,
                       'budget_mentions':budgets, 'other_constraints':other, 'possible_topics':possible,
                       'evidence':evidence, 'reason':'；'.join(reasons), 'review_reasons':review_reasons,
                       'family_context':family,
                       'possible_new_demand':role == 'supply' and bool(re.search(r'换房|换租|搬家', personal)),
                       'classification_method':'local_rules', 'rule_version':self.version,
                       'config_digest':self.config_digest, 'matcher':'pyahocorasick' if self.automaton is not None else 'stdlib_regex_fallback',
                       'rule_hits':rule_hits, 'exception_type':exception, 'needs_model_review':needs_model,
                       'model_calls':0, 'current_need_verified':False, 'assigned_store':None,
                       'send_authorized':False, 'can_send_now':False})
        result.update(self._pet_ownership(sources))
        return result

    def choose_mother(self, result, mothers):
        return choose_mother(result, mothers)


def choose_mother(result: dict, mothers: list) -> dict:
    """Prepare only the user-approved general wording; never authorize sending."""
    out = {'draft_ready':False, 'draft_text':None, 'slot':None, 'mother_version':None,
           'mother_slot':None, 'mother_reply_text':None, 'reply_status':'not_prepared', 'reply_generation_model_calls':0,
           'assigned_store':None, 'send_authorized':False, 'can_send_now':False,
           'model_calls':0, 'mother_reason':None}
    if result.get('role') not in ('demand', 'mixed') or result.get('demand_state') == 'ended' or result.get('interest_at_comment') not in ('medium', 'high', 'super_high') or result.get('exception_type'):
        out['mother_reason'] = '非明确中高及超高需求，或存在待核异常，暂不备稿'
        return out
    mother = next((m for m in mothers if m.get('slot') == 1 and m.get('user_approved') is True), None)
    if not mother or not isinstance(mother.get('template'), str) or not mother['template'].strip():
        out['mother_reason'] = '缺少本人认可的通用母句slot1'
        return out
    template = mother['template']
    # A substituted/template placeholder cannot be filled from unverified records.
    if re.search(r'[【】{}]|\d+\s*(?:元|块)|有空房|现房|拎包入住', template):
        out['mother_reason'] = '通用母句含待核占位或具体房源承诺，暂不本地套用'
        return out
    if result.get('family_context'):
        template = re.sub(r'^\s*宝宝[，,、：:！!。\s]*', '', template)
    out.update({'draft_ready':True, 'draft_text':template, 'slot':1,
                'mother_slot':1, 'mother_reply_text':template, 'reply_status':'draft_local_pending_review',
                'mother_version':mother.get('version'), 'mother_reason':'按本人认可的通用口气准备本地候选；发送与门店事实另核'})
    return out
