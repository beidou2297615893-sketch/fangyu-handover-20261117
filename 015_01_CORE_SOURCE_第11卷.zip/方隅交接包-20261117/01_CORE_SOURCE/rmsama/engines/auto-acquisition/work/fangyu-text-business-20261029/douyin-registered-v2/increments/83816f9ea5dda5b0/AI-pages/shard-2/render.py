import json,sys,pathlib
P=pathlib.Path(__file__).resolve().parent
for n in map(int,sys.argv[1:]):
 d=json.loads((P/f'page-{n:02}.json').read_text('utf-8-sig'))
 for i,g in enumerate(d['shared_post_context']):
  print('POST',i,g['video'],json.dumps(g['post_body'],ensure_ascii=False))
  for c in g['comments']:
   print(c['key'],json.dumps(c['text'],ensure_ascii=False),c['published_at'],('OWNBODY' if c['same_author'] else ''),('PARENT='+str(c['parent']) if c['parent'] else ''),('CONFLICT' if c['source_conflict'] else ''))
