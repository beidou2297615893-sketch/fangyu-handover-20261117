"""Explicit model-authored per-key semantic decisions. Helpers only serialize decisions."""
from pathlib import Path
import json, hashlib, importlib.util
from collections import Counter

B=Path(__file__).resolve().parents[2]
P=Path(__file__).resolve().parent
D={}
def n(key,reason,role='discussion',state='unknown',interest='unrelated'):
    assert key not in D
    D[key]=dict(role=role,state=state,interest=interest,reason=reason,family=None,fill={},pools=[],regions=[],times=[],constraints=[],possible=[],extra=[])
def d(key,reason,family,pools,fill=None,regions=None,interest='high',times=None,extra=None):
    assert key not in D
    D[key]=dict(role='demand',state='active_at_comment',interest=interest,reason=reason,family=family,fill=fill or {},pools=pools,regions=regions or [],times=times or [],constraints=[],possible=[],extra=extra or [])
def u(key,reason):
    n(key,reason,'unknown','unknown','uncertain')

# Page 00: all 180 keys explicitly judged from their own comment and shared post.
d('D0002','本人询朝阳东坝租房；帖子是租房生活语境，未提供明确可租库存。','area',['L','A'],{'place':'朝阳东坝'},['朝阳东坝'],interest='medium')
d('D0005','本人询齿轮厂房子，保留租赁兴趣与原始地名，不推断城市或厂区用途。','area',['L','A'],{'place':'齿轮厂'},['齿轮厂'],interest='medium',extra=['齿轮厂具体指向及是否附近住宅待核'])
n('D0008','评价推荐帖子，没有本人租房动作。')
n('D0011','为作者加油，没有求租语义。')
n('D0014','纯点赞表情，没有住房诉求。')
d('D0017','明确出租帖下询所示房源是否仍在。','available',['A'])
d('D0020','明确出租帖下表达急租并询是否在。','urgent',['A','T'],extra=['急租未给具体入住日，不把评论日当入住日'])
d('D0023','可租公寓介绍下询价格。','price',['P'])
n('D0026','简单评价还不错，未表达本人找房推进。')
d('D0029','带看语境中询浦东新区房源。','area',['L','A'],{'place':'浦东新区'},['浦东新区'])
d('D0032','本人询所示房子的地点和月租；月租是计价口径。','price_location',['L','P'])
d('D0035','本人询房子地点与价格。','price_location',['L','P'])
d('D0038','本人马上实习、现在找上海低预算房，未给金额或明确入住日。','requirements',['P','L'],{'requirements':'上海、低预算'},['上海'],extra=['马上实习不是明确入住日期；预算金额待本人补充'])
d('D0041','本人询高桥整租一室户，地区和租住方式联立。','area_room',['L','H','A'],{'place':'高桥','room':'整租一室户'},['高桥'])
d('D0044','本人询杨浦区房源。','area',['L','A'],{'place':'杨浦区'},['杨浦区'])
n('D0047','给作者推荐上海公寓和价格，不是本人求租条件。')
n('D0050','给作者找房建议，拒二房东属于对他人的建议，不建立本人联系禁令。')
n('D0053','评论房源多并建议比较，没有本人找房。')
n('D0056','分享找房方法与找人时段，不是本人约看时间。')
n('D0059','分享过去找房方法和议价经历。')
n('D0062','推荐租房软件和中介收费信息，无本人求租。')
n('D0065','房主担心房子被弄乱，未提出具体出租或本人新需求。')
d('D0068','本人要在上海住一个月，询能否短租；现在表达寻找不因将来入住降为未来找。','lease_fixed',['T','L'],{'duration':'一个月'},['上海'],times=[('一个月','lease_duration')],extra=['第一套所指房型仅作语境；不能当方隅同款库存'])
n('D0071','评价视频房租贵，没有本人预算或找房动作。')
n('D0074','建议作者住酒店，非本人住房需求。')
u('D0077','仅艾特他人，住房用途不明，保留未知低优先待核。')
n('D0080','推荐作者居住片区，不能当本人目标地区。')
u('D0083','纯艾特，未说明是否本人求租。')
n('D0086','对揭秘内容接话，未表达本人需求。')
n('D0089','描述虚假房态引流经历，没有当前本人求租。')
n('D0092','表达已长期租自如的经历，无另找动作。')
n('D0095','讨论虚假房源引流及深圳市场，非本人住宅求租。')
n('D0098','泛泛认同视频内容。')
n('D0101','讨论预算与房屋质量关系，未给本人预算。')
n('D0104','推测视频房价，不能作为本人预算。')
d('D0107','独居生活分享下本人问价格，保留兴趣但未证实具体可租房。','price',['P'],interest='medium')
d('D0110','本人询月价格数量级，未确定金额，不把月计价当租期。','price',['P'],interest='medium',extra=['10几个原口径不明，不换算金额'])
d('D0113','住房生活分享下主动问价，未见明确租赁推进。','price',['P'],interest='medium')
d('D0116','住房生活分享下问价，未给本人预算。','price',['P'],interest='medium')
d('D0119','住房生活分享下问价格，保留中等兴趣。','price',['P'],interest='medium')
n('D0122','单个表情，无本人住房诉求。')
d('D0125','询川沙地铁旁住房；有哇为问句语气，非明确宣告供给。','area',['L','A'],{'place':'川沙地铁旁边'},['川沙地铁旁边'],extra=['有哇语气略歧义，若后续为提供房源应更正供给身份'])
d('D0128','租房中介视频下询所示住房位置。','location',['L'])
d('D0131','本人询小昆山附近房源。','area',['L','A'],{'place':'小昆山附近'},['小昆山附近'])
d('D0134','本人询徐汇区附近便宜房源；便宜是相对条件没有数字预算。','requirements',['L','P','A'],{'requirements':'徐汇区附近、这么便宜'},['徐汇区附近'])
n('D0137','叙述自家农村燃气供暖费用体验，无本人新租房。')
n('D0140','比较供暖与空调保暖，非租房推进。')
n('D0143','分享自己使用电褥子，无找房需求。')
u('D0146','评论文本为空，无法判断语义，不能断言无关。')
n('D0149','分享换厚被子日常，无住房求租。')
n('D0152','询剪发地点，非租房业务。')
n('D0155','称赞房东，没有本人找房。')
d('D0158','明确家庭短租房介绍下询青羊成都西站附近房源，未自报家庭或短租条件。','area',['L','A'],{'place':'青羊成都西站附近'},['青羊成都西站附近'])
n('D0161','办公室招租帖下仅表情，无可认定的住宅需求。')
d('D0164','独居合租生活分享下询位置，保留当时住房兴趣但供租状态未明。','location',['L'],interest='medium')
u('D0167','仅艾特他人，是否求租未知。')
u('D0170','纯艾特，不能借作者独居合租条件补本人需求。')
d('D0173','居住分享下询价格，非明确可租库存。','price',['P'],interest='medium')
d('D0176','租房攻略下询临平区，保留找房地区兴趣。','area',['L'],{'place':'临平区'},['临平区'],interest='medium')
d('D0179','本人在滨江实习且求找房方法；滨江是实习工作地，不直接写目标住宅。','commute',['L'],{'destination':'滨江'},[('滨江','work')],extra=['需要确认通勤接受范围；实习不是入住时间'])
n('D0182','仅陈述本人在瓜山及13张，未提出新找房且金额口径未明。')
d('D0185','本人明确询瓶窑广场可租住房。','area',['L','A'],{'place':'瓶窑广场'},['瓶窑广场'])
d('D0188','本人求下宁桥附近高性价比房，保留软性价格偏好。','requirements',['L','P'],{'requirements':'靠近下宁桥、性价比高'},['下宁桥'])
d('D0191','本人明确求两湖区养生堂园区附近800元内房，不静默纠地名。','requirements',['L','P','A'],{'requirements':'两湖区养生堂园区附近、800元内'},['两湖区养生堂园区附近'],extra=['两湖区原地名及城市需本人确认，不自动改为西湖区'])
d('D0194','本人求余杭区1000到1500左右住房，奥克斯时代之城是工作地点。','requirements',['L','P'],{'requirements':'余杭区、1000到1500左右'},['余杭区',('奥克斯时代之城','work')],extra=['工作地点用于通勤核实，不等同目标住宅地点'])
d('D0197','明确出租帖下询房子位置。','location',['L'])
d('D0200','明确出租帖下问位置。','location',['L'])
d('D0203','本人询明德门附近，保留目标而不按原帖福州改写城市。','area',['L','A'],{'place':'明德门附近'},['明德门附近'],extra=['目标明德门与原帖所在城市不直接联立，具体城市待确认'])
n('D0206','分享当前住房租金面积和免中介费，没有本人新租需求。')
n('D0209','叙述长期公寓居住经历，无找房动作。')
n('D0212','讨论中介经历与独租困难，未表当前本人求租。')
n('D0215','分享当前政府保租房并劝他人避坑，非本人新需求。')
n('D0218','评价小中介房源真实，无本人求租。')
n('D0221','讨论中介过去盈利，无住房需求。')
d('D0224','本人表示租一套，虽条件未明但有租赁动作。','topic_unspecified',['H'],interest='medium',extra=['具体房型地区预算及是否在询当前可租房待核'])
n('D0227','表达喜欢与房租贵的感受，没有当下求租推进或数额预算。')
n('D0230','单纯感叹价格贵，没有本人求租。')
n('D0233','评价租金高，不能当本人价格预算。')
n('D0236','买房相关调侃，无明确住宅租赁。')
n('D0239','陈述县城工作与现有年房租，不是新租预算或目标。')
n('D0242','建议他人不住公寓并抱怨噪音，未表本人当前找房；不强推公寓。')
d('D0245','独居生活分享下问价，未见具体可租信息。','price',['P'],interest='medium')
d('D0248','住房分享下询价格。','price',['P'],interest='medium')
d('D0251','住房分享下主动问价，保留中等兴趣。','price',['P'],interest='medium')
d('D0254','住房分享下问价格，无具体找房进度。','price',['P'],interest='medium')
n('D0257','给二房东费用分摊建议，没有本人找房。')
n('D0260','建议房东提高包水电租金，不是本人预算。')
n('D0263','点赞表情，无本人需求。')
d('D0266','房东租房内容下本人询北京哪个区及房租。','price_location',['L','P'])
d('D0269','本人明确询西二旗附近合租房源。','area_room',['L','H','A'],{'place':'西二旗附近','room':'合租'},['西二旗附近'])
n('D0272','陈述一人两个月用水费用，非租期或新求租。')
n('D0275','询作者来新疆经历，无住房求租。')
d('D0278','明确房东出租帖下询这套价格。','price',['P'])
d('D0281','明确出租帖下问价格。','price',['P'])
n('D0284','办公室招租下询地点，用途是办公，非可确定住宅租赁需求。',role='unknown',interest='uncertain')
d('D0287','居住生活分享下问价，未见明确可租库存。','price',['P'],interest='medium')
d('D0290','明确出租帖下问房子仍否在。','available',['A'])
d('D0293','明确出租帖下询地点。','location',['L'])
d('D0296','明确出租帖下询是否还在。','available',['A'])
d('D0299','可随时看房的公寓介绍下本人问价。','price',['P'])
d('D0302','带看房语境下本人询青浦房源。','area',['L','A'],{'place':'青浦'},['青浦'])
d('D0305','带看房内容下询青浦可租房。','area',['L','A'],{'place':'青浦'},['青浦'])
n('D0308','以过去居住经历劝作者避开一楼，未提出当前本人找房。')
n('D0311','比较视频房子与价格，非本人预算。')
n('D0314','讨论河滨大楼住户装饰，无本人租房动作。')
n('D0317','比较视频中几套房，雪纳瑞指所示房源，不能借成本人养狗要求。')
n('D0320','建议作者选第二套及评价厨房，并非本人独居或厨房需求。')
n('D0323','筛选作者候选房并拒一楼无梯，未见本人求租，不记本人硬条件。')
d('D0326','租房经历视频下询中介费口径，保留费用兴趣而非约租推进。','rent_process',['C'],interest='medium',extra=['半个月房租在此为中介费口径不是租赁时长'])
n('D0329','给作者推荐找房渠道，无本人需求。')
n('D0332','惊讶价格按月非年，不是本人希望租一年。')
n('D0335','以郑州价格比较建议作者换城，无本人目标地或租期。')
n('D0338','艾特并评论城市租房可怕，明确闲聊。')
n('D0341','评论视频房租与瑕疵，无本人求租条件。')
n('D0344','推测所示房源地段，非本人目标。')
n('D0347','分享已购房定居及职场经历，无新租需求。')
n('D0350','回顾已度过实习找房阶段，未表仍找房。',role='demand',state='historical')
n('D0353','鼓励作者，没有求租语义。')
n('D0356','叙述实习初期过渡与现已适应，未表当前另找房。',role='demand',state='historical')
n('D0359','感慨作者父亲支持，无本人住房需求。')
n('D0362','鼓励作者并分享自己工作实习期，不是入住或租赁期限。')
d('D0365','明确村房出租内容下问是否有房。','available',['A'])
d('D0368','明确出租房内容下询还有房否。','available',['A'])
d('D0371','明确出租内容下询房态。','available',['A'])
d('D0374','本人明确要500价位房并接受15地铁附近，保留金额原口径。','requirements',['P','L','A'],{'requirements':'500、15地铁'},[('15地铁','accepted')],extra=['500计价周期和全部费用口径未明；15地铁线路指向待核'])
n('D0377','评价作者费用便宜，没有本人求租。')
n('D0380','讨论作者过去事务，无本人住房需求。')
n('D0383','纯赞赏表情，无求租动作。')
d('D0386','明确可租LOFT介绍下询位置，不移植作者家庭需求。','location',['L'])
n('D0389','纯点赞表情，无本人需求。')
d('D0392','一室一厅分享下问位置，房态尚未证实。','location',['L'],interest='medium')
d('D0395','本人询短租，未说租多久，不补一个月。','requirements',['T'],{'requirements':'短租'},interest='high',extra=['需确认本人所需具体短租时长和可起租安排'])
d('D0398','住房分享下主动询客运中心附近房源。','area',['L','A'],{'place':'客运中心附近'},['客运中心附近'],interest='medium')
d('D0401','住房分享下询临安房源，未见具体库存推进。','area',['L','A'],{'place':'临安'},['临安'],interest='medium')
d('D0404','住房分享下询房子位置。','location',['L'],interest='medium')
d('D0407','本人针对1400房子明确马上签合同，属超高意向但未签成。','rent_process',['P','C','K'],interest='super_high',extra=['1400是所询价格不是已核报价；马上签合同是签约意愿不是入住日或已成交'])
n('D0410','叙述当前房屋禁养却偷偷养宠，未表本人另找房；不鼓励违约。')
d('D0413','明确出租帖下询省立医院附近房源。','area',['L','A'],{'place':'省立医院附近'},['省立医院附近'],extra=['省立医院具体城市院区待核'])
d('D0416','出租帖下询房子位置。','location',['L'])
d('D0419','出租帖下询位置。','location',['L'])
d('D0422','本人最近在找一个月或两个月的短租，当前找房动作明确。','lease_fixed',['T'],{'duration':'一个月两个月'},times=[('一个月两个月','lease_duration'),('最近想租','search_start')],extra=['一个月两个月为备选时长，不确定总时长；最近以发表时点理解不锚今天'])
n('D0425','人生苦短相关玩笑，无本人租房。')
d('D0428','本人请找周浦住房。','area',['L','A'],{'place':'周浦'},['周浦'])
d('D0431','本人询嘉定南翔房源。','area',['L','A'],{'place':'嘉定南翔'},['嘉定南翔'])
d('D0434','本人询浦东新区是否有房。','area',['L','A'],{'place':'浦东新区'},['浦东新区'])
d('D0437','本人询闵行区便宜房，价格为相对偏好无数额。','requirements',['L','P','A'],{'requirements':'闵行区、便宜'},['闵行区'])
d('D0440','本人上海松江找4500预算房，区域和预算联立。','requirements',['L','P','A'],{'requirements':'上海松江、4500预算'},['上海松江'])
d('D0443','本人询奉贤区房源。','area',['L','A'],{'place':'奉贤区'},['奉贤区'])
n('D0446','感叹视频预算下住房品质，非本人预算。')
n('D0449','以影视邻居调侃所示河滨大楼，无本人求租动作。')
u('D0452','评论文本为空，语义未知。')
n('D0455','询作者身份与旅居经历，非本人求租。')
n('D0458','给作者选区避一楼及夜间看房建议，不能当本人目标或预约。')
n('D0461','比较作者候选房价格且拒一楼，没有本人当前找房。')
n('D0464','建议去郊区并评论租金负担，无本人求租。')
n('D0467','喜欢所示第三套房大小风景，弱审美关注没有求租推进。')
d('D0470','本人询房租月年计价口径，非表达总租期。','price',['P'],interest='medium',extra=['一个月还是一年是价格周期询问，不能当lease_duration'])
n('D0473','询作者是否能住酒店，结合讨论语境未表本人订酒店或求租。')
d('D0476','本人询所示小区，住房关注但未见明确可租库存。','location',['L'],interest='medium')
n('D0479','评价租金贵，没有本人预算数字或找房动作。')
n('D0482','艾特讨论携程面试，无住宅求租。')
n('D0485','欢迎老乡来上海，无本人找房。')
n('D0488','评价外地人在上海生活，无租赁动作。')
n('D0491','祝福作者并评论视频剪辑，无住房求租。')
n('D0494','赞赏作者精神，无本人需求。')
n('D0497','感慨父爱，无住房求租。')
n('D0500','询公司总部并介绍自己家长身份和鼓励作者，未求租；虹桥非本人工作或目标。')
d('D0503','现居一居室分享下问位置，房态未知保留中等兴趣。','location',['L'],interest='medium')
n('D0506','疑似辨认公寓名称，未表达本人求租动作。')
d('D0509','本人询短租住房，期限未说清。','requirements',['T'],{'requirements':'短租'},extra=['需核具体短租时长与是否可承接'])
d('D0512','本人询所示住房是否商水商电，保留费用兴趣不编民用收费。','requirements',['C'],{'requirements':'商水商电'},interest='medium')
d('D0515','住房分享下询位置。','location',['L'],interest='medium')
d('D0518','本人原想去租仍在求居住建议，关注水电及阴暗环境，当前找房阶段未明。','requirements',['C','F'],{'requirements':'水9元一吨、电1.04分一度、环境非常阴暗'},interest='medium',extra=['还想去这租来着是否仍推进需核；数字是顾虑中的所述收费，未核实且不能当本人预算'])
d('D0521','住房探访内容下主动询房源还有否，未见明确可租房态。','available',['A'],interest='medium')
n('D0524','问作者最后租哪里，偏经历追问而非本人求租。')
n('D0527','评价所示住房夏天没空调，不自动当本人设施需求。')
n('D0530','追问作者最终租住经历，无本人求租。')
n('D0533','辨认高教大楼，无本人求租。')
d('D0536','本人请作者推荐中介，表达租房联系推进，非具体预约。','contact_how',['K'])
n('D0539','询作者是否与男友来杭州，非本人求租或入住人数。')

# Page 01: all 89 keys explicitly judged.
u('D0542','拱墅区有租房子的吗既可能找租客也可能询房，不能凭片区直接认定本人需求。')
D['D0542'].update(possible=[(['位置通勤','房源状态'],'租房子的吗供需指向不明，宝善桥5号线只能暂作未定主体位置线索')],regions=[('拱墅区','unresolved'),('宝善桥地铁5号线','unresolved')])
n('D0545','赞美作者，无本人租房需求。')
n('D0548','讨论主城区消费差异，无本人租房条件。')
d('D0551','本人明确也在找房，未给条件，保留当前寻找。','topic_unspecified',[],interest='high')
d('D0554','本人求上城住房推荐，找房动作明确。','area',['L'],{'place':'上城'},['上城'])
n('D0557','分享现在所租套三及1200租金，无另找动作。')
n('D0560','评论大源1400租房行情，未说明本人新求租。')
d('D0563','本人求1000内套一，可接受稍远地区；预算户型和距离条件联立。','requirements',['P','H','L'],{'requirements':'1000内的套一、稍微远点都行'},extra=['稍微远点为相对距离接受条件，未报目标地区或通勤基点'])
d('D0566','本人询找房渠道，保留住房寻找线索，未说明自己正在找。','topic_unspecified',[],interest='medium',extra=['在哪找的是求渠道还是单纯惊讶待核'])
D['D0566']['state']='unknown'
n('D0569','抱怨本人现租2k只有套一，无新找房动作。')
n('D0572','陈述已在市二医院附近租套三，不是新目标或新预算。')
n('D0575','表达步梯高于五楼不住的明确个人拒绝偏好，但当前找房动作未知。')
D['D0575'].update(pools=[('E','reject','unresolved','步梯高于5楼')],constraints=[('步梯高于5楼，无论再便宜我都不会去','仅步梯且高于五楼拒绝；不是无条件拒绝所有高层')])
n('D0578','国旗和鼓掌表情，无求租动作。')
d('D0581','明确700元出租帖下询真实性和租金，非自报预算。','price',['P'])
d('D0584','出租帖下询福州哪个区，福州为所询城市范围，具体区未知。','location',['L'],regions=[('福州','unresolved')])
d('D0587','明确可租房帖下本人希望更便宜房。','budget_low',['P'])
d('D0590','本人询徐汇区2000房源。','requirements',['L','P','A'],{'requirements':'徐汇区、2000'},['徐汇区'])
d('D0593','本人准备去花桥租房并因张江贵改变选择；花桥为目标，张江是被比较的原片区。','area',['L','P'],{'place':'花桥'},['花桥',('浦东张江','unresolved')],extra=['准备去花桥是当前找房打算，未给明确入住日期；未明确张江当前居住或工作'])
d('D0596','带看内容下本人询高桥同类房源，不借视频具体设施补条件。','area',['L','A'],{'place':'高桥'},['高桥'])
d('D0599','本人询曹路1000价位住房，金额计价周期未明。','requirements',['L','P','A'],{'requirements':'曹路、1000'},['曹路'])
d('D0602','本人询虹口足球场附近与视频相近住房；同类具体指向仍需核。','area',['L','A'],{'place':'虹口足球场这边'},['虹口足球场'],extra=['跟视频差不多的具体房型设施待本人确认，未自动复制视频条件'])
d('D0605','租房带看内容下本人问价。','price',['P'])
d('D0608','本人求肿瘤医院附近一室住房。','area_room',['L','H','A'],{'place':'肿瘤医院附近','room':'一室'},['肿瘤医院附近'],extra=['肿瘤医院具体城市院区待核'])
n('D0611','评价作者预算并期待偶遇，非本人预算或看房约定。')
n('D0614','以过去经历明确拒老房但未表当前找房，不能强推。')
D['D0614'].update(constraints=[('不要住老房子','明确不愿住老房；当前求租动作未知，不外推其他房型条件')])
n('D0617','感叹作者财富，没有本人需求。')
d('D0620','本人已找房数天并想看房，询合租，非具体时段预约。','requirements',['H','K'],{'requirements':'合租、看房子'},extra=['合租是本人询问的住法，未给人数；找了几天为已进行寻找时长非总租期'])
d('D0623','看房日记下询第二套位置，未见明确库存，保留中等兴趣。','location',['L'],interest='medium')
n('D0626','针对视频表达一楼不能租的建议，未表本人当前求租。')
n('D0629','评价最后一套可以，无本人求租推进。')
n('D0632','对视频提醒不要甲醛，没有本人找房动作；保留环境健康条件语义。')
D['D0632'].update(constraints=[('不要甲醛','对住房甲醛风险的否定意见，主体和当前求租未明')])
n('D0635','讨论一居室梯户密度，不是本人户型或电梯需求。')
n('D0638','表情感叹，无求租语义。')
d('D0641','本人问最后一套小区并称心动，住房兴趣清晰但非约看安排。','location',['L'],interest='medium',extra=['布局装修喜欢尚未形成具体硬条件，不转录所示配置作本人要求'])
n('D0644','分享已定居经历并祝福作者，无新租需求。')
n('D0647','感慨父亲陪伴和个人生活经历，无住房求租。')
n('D0650','鼓励作者，无本人住房需求。')
n('D0653','祝福作者实习和父爱，无本人求租。')
n('D0656','给作者公租房申请渠道建议，非本人申请或商业租赁需求。')
n('D0659','鼓励作者走出舒适圈，无本人求租。')
d('D0662','明确出租两房内容下本人询联系看房，未约时段或要求代预约，判高非超高。','contact_how',['K'])
d('D0665','住房探访下询押金退还保障，保留费用合同兴趣，未见实际看房租赁推进。','rent_process',['C'],interest='medium')
n('D0668','识别高教园地点，无本人找房。')
n('D0671','讨论金牛区行情，不能认作本人预算或房源供给。')
n('D0674','本人已找到满意的套二，分享租金和地点；未提出新需求。',role='demand',state='ended')
n('D0677','抱怨现租小隔断1300，无本人新找房动作。')
n('D0680','陈述现租1400套三老小区六楼，无新需求。')
d('D0683','本人追问找房地点并称三环内套一难找，保留寻房线索但是否当前找房未明。','topic_unspecified',[],interest='medium',extra=['三环内低于一千五套一是市场判断，不能直接当本人预算及硬目标'])
D['D0683']['state']='unknown'
d('D0686','本人询如何找到房子，保留渠道兴趣，未说明当前自己找房。','topic_unspecified',[],interest='medium',extra=['是求具体渠道还是感叹待核，未套用作者预算'])
D['D0686']['state']='unknown'
n('D0689','感慨杭州隔断房市场，无本人新求租。')
n('D0692','建议作者搬近妹妹，妹妹不是本人找房对象。')
n('D0695','辨认地点并建议投诉，不是求租目标。')
n('D0698','评论猫乖，不能当本人有猫或允许宠物需求。')
d('D0701','明确出租帖下询房子是否已租出。','available',['A'])
d('D0704','明确出租帖下询租赁方式与真实性，有租赁推进。','rent_process',['C','K'])
d('D0707','明确出租帖下询位置。','location',['L'])
d('D0710','明确出租帖下询位置。','location',['L'])
n('D0713','明确表示中山阜沙有房，属于供给不推销。',role='supply')
D['D0713'].update(pools=[('L','fact','supply',None),('A','fact','supply',None)],regions=[('中山阜沙','offered')])
d('D0716','本人询秀沿路租金行情。','requirements',['L','P'],{'requirements':'秀沿路、价格'},['秀沿路'])
d('D0719','本人询每月房费，非总租期。','price',['P'])
d('D0722','本人明确三千预算找房。','budget_fit',['P'],{'budget':'三千'})
d('D0725','本人询同类房子价格，不自报预算。','price',['P'])
d('D0728','本人求会区两室一厅，地区原文疑似缺字但不改成徐汇。','requirements',['L','H','A'],{'requirements':'会区、2室1厅'},[('会区','unresolved')],extra=['会区原文地名不完整，需本人确认，不自动改为徐汇区'])
d('D0731','本人要求宝山房源，短句仍有找房动作。','area',['L','A'],{'place':'宝山'},['宝山'])
d('D0734','本人明确求张江集鼎天地附近租房。','area',['L','A'],{'place':'张江集鼎天地附近'},['张江集鼎天地附近'])
n('D0737','为作者候选房选择二和三，无本人求租。')
n('D0740','为作者投票第二套，无本人求租。')
n('D0743','赞美河滨景观与上海生活，无本人找房。')
n('D0746','评论作者预算和商住选择，不能当本人预算或用途。')
n('D0749','建议作者住远点并讨论出行，无本人目标地。')
d('D0752','明确出租一室一厅内容下询房态。','available',['A'])
n('D0755','鼓励作者适应上海，没有本人求租。')
n('D0758','感动并鼓励作者，无本人需求。')
n('D0761','分享读研至买房定居经历，无新租需求。')
n('D0764','感动表情，无本人需求。')
n('D0767','讨论作者公司和现居通勤，不能借虹桥或迪斯尼作本人目标。')
n('D0770','给作者公司通勤选房建议，不是本人工作地或目标地。')
n('D0773','给作者地铁NFC建议，无住房求租。')
d('D0776','明确可租公寓帖下本人询如何联系与每月租金。','rent_process',['K','P'])
u('D0779','仅单个艾特符号，没有可判断的住房语义。')
d('D0782','明确公寓出租帖下本人询能否短租，时长未说。','requirements',['T'],{'requirements':'短租'},extra=['具体短租总时长待确认，不能把推广免租45天当本人租期'])
u('D0785','仅问多少，住房广告语境仍未指明价格或数量，保留候选不确定定价。')
D['D0785'].update(possible=[(['价格预算','户型面积与居住方式'],'多少所询指标不明，需确认是租金还是面积数量')])
d('D0788','明确可租公寓帖下询租金。','price',['P'])
d('D0791','本人核实免费住宣传的价格条件，不表示其已有免费资格。','price',['P'],extra=['免租宣传具体期限条件及收费须核，不冒称方隅免费'])
u('D0794','询出租还是售卖，交易方式与本人租赁意愿未明确。')
D['D0794'].update(constraints=[('是出租，还是售卖','本人询交易方式，不能据此确定只买或只租')])
d('D0797','住房分享下询上城同类房，未见可租库存。','area',['L','A'],{'place':'上城'},['上城'],interest='medium')
d('D0800','住房分享下询临平类似房源，不借作者户型租金作硬条件。','area',['L','A'],{'place':'临平'},['临平'],interest='medium')
d('D0803','本人询怎么租，有租赁推进，虽源帖为分享仍保留高兴趣。','rent_process',['C','K'])
d('D0806','住房分享下主动询西溪湿地附近房源。','area',['L','A'],{'place':'西溪湿地附近'},['西溪湿地附近'],interest='medium')

# Detailed pass corrections preserve actual current-demand uncertainty.
D['D0518']['state']='unknown'

# Explicit detailed evidence additions, all selected by semantic reading above.
D['D0020']['times']=[('急租','move_in')]
D['D0038']['times']=[('马上实习','other')]
D['D0407']['times']=[('马上签合同','other')]
D['D0620']['times']=[('找了几天','search_start')]
D['D0518']['pools']=[('C','ask','own_demand',None),('F','reject','own_demand','感觉环境非常阴暗')]
D['D0350']['times']=[('找房子找了好几天','search_start')]
D['D0356']['times']=[('一天酒店','other'),('一周青旅','other'),('实习的第三周','other')]
D['D0092']['times']=[('来上海五年','other')]
D['D0272']['times']=[('两个月','other')]
D['D0308']['times']=[('住过几个月','other')]
D['D0761']['times']=[('2015年','other'),('11年','other')]
D['D0239']['times']=[('一年房租','other')]
D['D0575']['extra']=['否定仅针对无梯步梯高于五楼，当前本人是否找房仍未知']
D['D0614']['extra']=['拒绝老房是本人偏好，未见当前求租推进，不强推']
D['D0632']['extra']=['甲醛否定意见保留，不据短建议认定本人正在找房']
D['D0713']['extra']=['提供房源方不作为需求客户推销']
D['D0284']['extra']=['源帖主用途明确办公；不能借人才公寓配套将此问句判住宅询盘']

# These assignments describe topic polarity, not text matching.
POL={
 ('D0038','P'):'require',('D0038','L'):'require',('D0041','H'):'require',
 ('D0068','T'):'require',('D0068','L'):'require',('D0134','P'):'prefer',
 ('D0188','P'):'prefer',('D0191','P'):'require',('D0194','P'):'require',
 ('D0269','H'):'require',('D0374','P'):'require',('D0374','L'):'accept',
 ('D0407','P'):'accept',('D0407','C'):'require',('D0422','T'):'require',
 ('D0437','P'):'prefer',('D0440','P'):'require',('D0563','P'):'require',
 ('D0563','H'):'require',('D0563','L'):'accept',('D0593','P'):'compare',
 ('D0599','P'):'require',('D0608','H'):'require',('D0620','H'):'ask',
 ('D0722','P'):'require',('D0728','H'):'require',('D0734','L'):'require',
}
POOL={'P':'价格预算','L':'位置通勤','H':'户型面积与居住方式','F':'房内设施','E':'楼层电梯','T':'入住与租期','A':'房源状态','C':'费用合同','K':'看房联系'}
SLOT={'area':31,'location':31,'price_location':31,'price':1,'budget_low':1,'budget_fit':2,'area_room':34,'requirements':34,'lease_fixed':19,'urgent':19,'available':28,'rent_process':28,'contact_how':28,'commute':31,'topic_unspecified':7}
SLOT_OVERRIDE={'D0326':25,'D0395':19,'D0509':19,'D0512':25,'D0518':25,'D0665':25,'D0782':19}

def dump(path,value):
    path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def jsonl(path,rows):
    path.write_text(''.join(json.dumps(r,ensure_ascii=False,separators=(',',':'))+'\n' for r in rows),encoding='utf-8')
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()

def execute():
    sourcefile=B/'shard-1.jsonl'
    raw=[json.loads(l) for l in sourcefile.read_text(encoding='utf-8').splitlines() if l.strip()]
    source={r['review_key']:r for r in raw}
    assert len(source)==len(raw)==len(D)==269 and set(source)==set(D)
    task=json.loads((P/'task.json').read_text(encoding='utf-8'))
    assert set(task['expected_review_keys'])==set(D)
    mothers=json.loads((B.parents[2]/'approved-mothers-model-view.json').read_text(encoding='utf-8'))
    facts={m['slot']:m['required_facts'] for m in mothers}
    contract=json.loads((B/'local-mother-contract.json').read_text(encoding='utf-8'))
    pages=[]; explicit=[]; allrows=[]
    for page in sorted(P.glob('page-*.json')):
        number=int(page.stem.split('-')[1])
        pg=json.loads(page.read_text(encoding='utf-8'))
        rows=[]; decisions=[]
        for group in pg['shared_post_context']:
            for c in group['comments']:
                k=c['key']; text=c['text']; s=source[k]; v=D[k]
                assert text==s['comment_text'] and group['video']==s['video_id']
                assert hashlib.sha256(text.encode('utf-8')).hexdigest()==s['source_comment_sha256']
                topics=[]
                for item in v['pools']:
                    code,pol,subject,scope=(item,POL.get((k,item),'ask'),'own_demand',text or None) if isinstance(item,str) else item
                    topics.append(dict(pool=POOL[code],quote=text,polarity=pol,subject=subject,condition_scope=scope))
                regions=[]
                for reg in v['regions']:
                    name,rel=(reg,'desired') if isinstance(reg,str) else reg
                    assert name in text,(k,name)
                    regions.append(dict(text=name,quote=name,relation=rel,group_relation='AND' if len(v['regions'])>1 else 'unknown',condition_scope=text))
                times=[]
                for quote,role in v['times']:
                    assert quote in text,(k,quote)
                    times.append(dict(quote=quote,time_role=role,anchor_source='comment.published_at',anchor_time=c['published_at'],normalized=None,verification='保留原时间词及可信评论发表时点；未归一到分析日，未将计价周期当总租期'))
                constraints=[dict(quote=q,detail=detail) for q,detail in v['constraints']]
                possible=[dict(candidate_pools=pools,ambiguity=why) for pools,why in v['possible']]
                family=v['family']; slot=SLOT_OVERRIDE.get(k,SLOT.get(family))
                needs=list(v['extra'])
                if v['role']=='demand' and v['state'] in ('active_at_comment','unknown'):
                    needs.append('评论时的租赁兴趣不代表今日仍有效，当前需求及目标承接范围待核')
                if v['role']=='unknown':
                    needs.append('需先澄清本条具体语义、供需或住宅租赁意愿，再决定是否接话')
                if family:
                    required=contract['families'][family]['required_fill']
                    assert set(v['fill'])==set(required),(k,family,v['fill'])
                    ev=[]
                    for field,value in v['fill'].items():
                        if field!='requirements': assert value in text,(k,field,value)
                        else: assert all(piece in text for piece in value.split('、')),(k,value)
                        ev.append(dict(field=field,quote=value if value in text else text))
                    local=dict(family=family,fill=v['fill'],evidence=ev)
                    missing=[facts[slot],'所询房态、地点、费用或全部明确条件须在同一适用房源核实；不能拿源帖房源事实代替方隅事实','真实住户身份、介绍优惠门店时效适用条件及介绍资格待核']
                    caution=['按需求池本地微调母句；仅为候选，不代表具体话术逐句获人工认可或已答复事实','未授权发送；源帖是解释语境，不是方隅库存、报价或设施证据']
                else:
                    local=None; missing=[]
                    caution=['本条为讨论、供给、历史结束或语义未知，不强推母句；'+v['reason']]
                plan=dict(preferred_mother_slot=slot,generic_intro_suitable=bool(family),tone='normal',missing_facts=missing,caution=caution,contact_policy='unknown' if v['role']=='unknown' else 'allow',local_mother=local)
                row=dict(review_key=k,platform=s['platform'],comment_id=s['comment_id'],customer_uid=s['customer_uid'],video_id=s['video_id'],role=v['role'],demand_state=v['state'],interest=v['interest'],topics=topics,target_regions=regions,time_mentions=times,other_constraints=constraints,possible_topics=possible,evidence=[text] if text else [],reason=v['reason'],context_used=['own','body'],needs_review=needs,contact_boundaries=[],context_flags=dict(same_author=c['same_author'],source_version_conflict=c['source_conflict'],published_at=c['published_at'],parent_context=c['parent'],post_context_only=True),reply_plan=plan,human_confirmed=False,send_authorized=False,store_assignment=None,analysis_method='AI逐key语义初筛与细筛，同轮判读不冒充独立二审或人工金标',analysis_page=number,source_comment_sha256=s['source_comment_sha256'],rule_version='business-text-20261029-v2')
                initial=dict(role=v['role'],demand_state='active_at_comment' if k in ('D0518','D0566','D0683','D0686') else v['state'],interest=v['interest'],reason=v['reason'])
                decisions.append(dict(review_key=k,comment_id=s['comment_id'],source_comment_sha256=s['source_comment_sha256'],initial_semantic=initial,detailed_semantic=dict(role=v['role'],demand_state=v['state'],interest=v['interest'],topics=topics,target_regions=regions,time_mentions=times,reply_plan=plan,reason=v['reason']),same_turn_not_independent_review=True))
                rows.append(row)
        jsonl(P/f'reviewed-{number:02}.jsonl',rows)
        jsonl(P/f'explicit-decisions-{number:02}.jsonl',decisions)
        pages.append(dict(page=number,input=len(rows),output=len(rows),status='initial_and_detailed_saved',source_sha256=sha(page),reviewed_sha256=sha(P/f'reviewed-{number:02}.jsonl')))
        allrows.extend(rows); explicit.extend(decisions)
        dump(P/'progress.json',dict(shard=1,total=269,pages=pages,reviewed_count=len(allrows),status='pages_in_progress' if len(allrows)<269 else 'all_pages_saved',platform_calls=0,reply_body_generated=False,usage='unknown'))
    # Formal result is byte-for-byte page concatenation in actual page order.
    out=B/'reviewed-new-1.jsonl'
    out.write_bytes(b''.join((P/f'reviewed-{p["page"]:02}.jsonl').read_bytes() for p in pages))
    # Local checks are separate from the unmodified production validator.
    errors=[]; identities=set()
    for r in allrows:
        k=r['review_key']; s=source[k]; text=s['comment_text']
        identity=tuple(r[f] for f in ('review_key','comment_id','customer_uid','video_id','platform'))
        assert identity not in identities; identities.add(identity)
        assert all(r[f]==s[f] for f in ('review_key','comment_id','customer_uid','video_id','platform','source_comment_sha256'))
        for field in ('topics','target_regions','time_mentions','other_constraints','contact_boundaries'):
            for e in r[field]:
                if isinstance(e,dict) and 'quote' in e: assert e['quote'] in text,(k,field,e)
        assert all(q in text for q in r['evidence'])
        local=r['reply_plan']['local_mother']
        if local:
            assert local['family'] in contract['families']
            assert all(e['quote'] in text for e in local['evidence'])
        assert not any(f in r for f in ('reply','draft_reply','reply_text'))
    # Actual isolated stage source: add only genuine same-turn stages, bind its exact bytes.
    staged=[]
    for row in allrows:
        row=dict(row)
        row.update(classification_method='ai_semantic_initial_and_detailed',classification_stages_completed=['initial_semantic','detailed_semantic'])
        staged.append(row)
    semantic=P/'isolated-semantic-stages.jsonl'; jsonl(semantic,staged)
    digest=sha(semantic); relative=semantic.relative_to(B).as_posix()
    isolated=[dict(r,classification_review_source=dict(path=relative,sha256=digest)) for r in staged]
    iso=P/'isolated-adapter-preflight.jsonl'; jsonl(iso,isolated)
    adapter=B.parents[2]/'mother_adapter.py'
    adapter_before=sha(adapter)
    spec=importlib.util.spec_from_file_location('unmodified_mother_adapter',adapter)
    module=importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
    cache={}
    for row in isolated:
        try: module.validate_new_review(row,B,cache)
        except Exception as exc: errors.append(str(exc))
    assert sha(adapter)==adapter_before
    result=dict(shard=1,input_count=len(raw),output_count=len(allrows),keys_equal=set(source)=={r['review_key'] for r in allrows},identity_fields_equal=True,duplicate_identities=0,source_text_sha256_valid=True,all_quote_fields_verbatim=True,local_mother_fields_explicit=269,local_mother_contract_valid=True,page_concatenation_equal=out.read_bytes()==b''.join((P/f'reviewed-{p["page"]:02}.jsonl').read_bytes() for p in pages),formal_review_sha256=sha(out),source_shard_sha256=sha(sourcefile),adapter_path=str(adapter),adapter_sha256=adapter_before,adapter_unmodified=True,production_validator='mother_adapter.validate_new_review',production_validator_passed=len(isolated)-len(errors),production_validator_errors=errors,isolated_preflight_path=str(iso),isolated_preflight_sha256=sha(iso),isolated_review_source_path=str(semantic),isolated_review_source_sha256=digest,classification_method='ai_semantic_initial_and_detailed',independent_second_review=False,human_gold_standard=False,reply_body_generated=False,usage='unknown',platform_calls=0,sent=0,pages=pages,role_counts=dict(Counter(r['role'] for r in allrows)),interest_counts=dict(Counter(r['interest'] for r in allrows)),family_counts=dict(Counter(r['reply_plan']['local_mother']['family'] if r['reply_plan']['local_mother'] else 'null' for r in allrows)))
    dump(B/'shard-1-validation.json',result)
    dump(P/'progress.json',dict(shard=1,total=269,pages=pages,reviewed_count=269,status='complete' if not errors else 'preflight_failed',platform_calls=0,reply_body_generated=False,usage='unknown',production_validator_passed=269-len(errors)))
    report=f'''# 分片1文本判读与隔离核验\n\n已完整读取两页共享正文及269条评论，逐key完成AI语义初筛和细筛。正式结果与逐页结果连接一致；全部源身份、文本SHA、逐字引文及母句字面参数检查通过。\n\n未修改的 mother_adapter.validate_new_review 对真实隔离JSONL及其SHA绑定逐条预检：{269-len(errors)}/269通过。正式评审不写编译阶段元数据，仅隔离预检补入实际同轮两阶段；不冒充独立二审、人工金标、每句人工认可或发送许可。\n\n母句按已判池选契约家族，仅返回family/fill/evidence，未生成回复正文。非需求、供给、历史结束及未知语义显式null并说明原因。未从采集店/IP补目标地；滨江实习地、余杭目标与奥克斯工作地点分开；会区和两湖区保留原词待核；租期、计价周期、签约意愿和入住日期分开。\n\n统计：角色 {json.dumps(result['role_counts'],ensure_ascii=False)}；意向 {json.dumps(result['interest_counts'],ensure_ascii=False)}。\n\n需后续核实：需求是否仍有效、具体城市/院区/片区、当店当房源全部硬条件、真实报价/库存/优惠/住户与对接资格。D0542供需不明；D0284办公用途未确认为住宅；D0785所问指标不明；D0794交易方式待核。\n\n未访问平台、账号、源库，未发送、发布、冻结或购买。实际usage未知，未以任务数或余额差额推算费用。\n\n正式结果SHA256：{result['formal_review_sha256']}\n\n适配器SHA256：{adapter_before}\n'''
    (B/'shard-1-report.md').write_text(report,encoding='utf-8')
    print(json.dumps(result,ensure_ascii=False,indent=2))
    assert not errors,errors

if __name__=='__main__': execute()
