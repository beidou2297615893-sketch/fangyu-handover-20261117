import json, pathlib, hashlib, datetime, collections
D=pathlib.Path(__file__).resolve().parent.parent;O=pathlib.Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
src=[json.loads(x) for x in (D/'shard0.jsonl').read_text(encoding='utf-8').splitlines()]
out=[json.loads(x) for x in (O/'labels.jsonl').read_text(encoding='utf-8').splitlines()]
ctx=load(D/'shared-contexts.json');errors=[];quotes=0;refs=0
expected={'shard0.jsonl':'a15fa6a2c447bb4a7d0de531a18ec93ab98a06b2ae685d3a8d7e56a398b12c1b','shared-contexts.json':'51a52ebb65825d447a3a17db3b3cb416099a84c857a25418803dae9a9b8015ca'}
for name,want in expected.items():
 if sha(D/name)!=want:errors.append('input changed: '+name)
if len(src)!=134 or len(out)!=134:errors.append('count mismatch')
if len({(x['platform'],x['cid']) for x in out})!=len(out):errors.append('duplicate')
allowed={'platform','cid','uid','source_comment_sha256','reference_mentions','price_relation','place_relation','time_relation','brand_source_relation','contact_action_direction','housing_purpose','evidence','unresolved_or_missing'}
for i,(x,z) in enumerate(zip(src,out)):
 for k in ('platform','cid','uid','source_comment_sha256'):
  if z.get(k)!=x[k]:errors.append(f'{i} identifier {k}')
 if hashlib.sha256(x['comment'].encode('utf-8')).hexdigest()!=x['source_comment_sha256']:errors.append(f'{i} comment sha')
 if set(z)!=allowed:errors.append(f'{i} fields {set(z)^allowed}')
 post=ctx['posts'][x['context_key']]['content'];sources={'comment':x['comment'],'post_title':post.get('post_title'),'post_body':post.get('post_body'),'direct_parent':ctx['parents'][x['parent_context_key']]['content'].get('parent_text')}
 def walk(v):
  global quotes
  if isinstance(v,dict):
   if 'source' in v and 'quote' in v:
    quotes+=1;s=v['source'];q=v['quote']
    if s not in sources or not isinstance(q,str) or not q or not sources[s] or q not in sources[s]:errors.append(f'{i} quote {s}: {q!r}')
    if s=='direct_parent':errors.append(f'{i} forbidden missing parent citation')
   for y in v.values():walk(y)
  elif isinstance(v,list):
   for y in v:walk(y)
 walk(z)
 for r in z['reference_mentions']:
  refs+=1
  if r['span'] not in x['comment']:errors.append(f'{i} span')
 if not any('direct_parent' in u and 'unknown' in u for u in z['unresolved_or_missing']):errors.append(f'{i} missing parent status')
counts={field:dict(collections.Counter(v['relation'] for z in out for v in z[field])) for field in ('price_relation','place_relation','time_relation')}
validation={'status':'passed' if not errors else 'failed','records':len(out),'input_records':len(src),'unique_ids':len({(x['platform'],x['cid']) for x in out}),'identifier_order_uid_sha_exact':not any('identifier' in e for e in errors),'source_comment_sha_verified':not any('comment sha' in e for e in errors),'checked_quote_occurrences':quotes,'reference_mentions':refs,'input_hashes':{n:sha(D/n) for n in expected},'input_hashes_unchanged':all(sha(D/n)==v for n,v in expected.items()),'errors':errors,'relation_counts':counts,'semantic_accuracy':'not_measured_no_human_gold','actual_usage':'unknown'}
(O/'validation.json').write_text(json.dumps(validation,ensure_ascii=False,indent=2),encoding='utf-8')
if errors:
 print(json.dumps(validation,ensure_ascii=False,indent=2));raise SystemExit(1)
report='''本分片语义关系补充已完成：134条输入对应134条标签，无重复。\n\n当前模型逐条阅读评论与必要同帖文本后作出判断，9个小页的显式判断保留在本目录。程序仅负责读取、字段整理、落盘和校验；未用关键词命中生成语义判断。\n\n覆盖指代、价格关系、地点关系、时间关系、品牌来源关系、联系方向及住宅用途证据。缺失父评全部保持未知；未确定品牌不推断为非方隅，未把源帖金额变成评论人预算。3800核价使用原帖月报价证据；月租歧义和评论人明确路口分别保留。\n\n结构校验检查了134条覆盖、唯一标识、UID及评论SHA、所有逐字引用与引用来源、输入及共享上下文SHA不变。结构通过不代表人工金标或语义准确率验收。没有生成回复正文、没有改原意向/角色/地区，没有平台访问或发送，也没有改current指针。实际usage未知。\n'''
(O/'报告.txt').write_text(report,encoding='utf-8')
manifest={'scope':'shard0_reference_semantic_supplement_only','records':134,'judgment_method':'current_model_explicit_per_record_semantic_judgment_in_nine_pages','semantic_stage_only':True,'classification_complete_claim':False,'human_gold':False,'accuracy_measured':False,'actual_usage':'unknown','input_hashes':validation['input_hashes'],'output_sha256':{p.name:sha(p) for p in O.iterdir() if p.is_file() and p.name not in ('manifest.json','READY.json','progress.json')},'platform_calls':0,'send_attempts':0,'reply_bodies_written':0,'original_classification_changed':False,'current_pointer_changed':False,'other_shards_read':False}
(O/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
(O/'progress.json').write_text(json.dumps({'status':'completed_semantic_supplement_only','written':134,'validated':134,'actual_usage':'unknown'},ensure_ascii=False,indent=2),encoding='utf-8')
(O/'READY.json').write_text(json.dumps({'status':'semantic_supplement_validated','records':134,'labels_sha256':sha(O/'labels.jsonl'),'manifest_sha256':sha(O/'manifest.json'),'validation_sha256':sha(O/'validation.json'),'human_gold':False,'actual_usage':'unknown','send_authorized':False},ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(validation,ensure_ascii=False,indent=2))
