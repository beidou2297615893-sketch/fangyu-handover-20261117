"""Single-instance local text watcher; no platform/client/sending calls."""
import json,os,time,subprocess,sys,msvcrt,hashlib
from pathlib import Path
from datetime import datetime,timezone
HERE=Path(__file__).resolve().parent
BASE=HERE.parent.parent/'fangyu-douyin-independent'
STATUS=BASE/'classification-handoff-status.json'
ROOT=HERE.parents[2]
def now():return datetime.now(timezone.utc).isoformat()
def write(path,value):
 tmp=path.with_suffix(path.suffix+'.tmp');tmp.write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf-8')
 for attempt in range(21):
  try:
   tmp.replace(path)
   return
  except PermissionError:
   if attempt==20:raise
   time.sleep(0.25)
def signature():
 paths=[BASE/'runtime/collection.sqlite3',BASE/'runtime/collection.sqlite3-wal',HERE/'semantic-reviewed.jsonl',HERE/'semantic_guard.py',HERE/'base_renderer.py',HERE/'build_snapshot.py',HERE.parent.parent/'shared-acquisition-ledger/shared.sqlite3',HERE.parent.parent/'shared-acquisition-ledger/shared.sqlite3-wal']
 paths.extend([HERE.parent/'business-fit/business_fit.py',HERE.parent/'pool-sop-v3/classifier/classifier.py',HERE.parent/'recency-priority/recency.py'])
 paths.extend([HERE/'local_recheck.py',HERE/'complete_local_demand.py',HERE.parent/'local-backlog-recheck-20261105/decisions.jsonl'])
 paths.append(HERE.parent/'old-library-audit-20261106/additional-decisions.jsonl')
 return [(str(p),p.stat().st_size,p.stat().st_mtime_ns) for p in paths if p.exists()]+[('active_window_time_bucket',int(time.time()//900),0)]
def mark(phase,error=None):
 data=json.loads(STATUS.read_text(encoding='utf-8-sig')) if STATUS.exists() else {}
 data['worker']={'pid':os.getpid(),'version':'douyin-semantic-scope-v5-20261102','phase':phase,'checked_at':now(),'poll_seconds':60,'model_auto_calls':False,'error':error,'stop_file':str(HERE/'STOP'),'watermark_eligible':data.get('eligible_registered'),'output_sha256':data.get('output_sha256')}
 write(STATUS,data)
 visible=data.get('visible_business_pool') or {}
 text='抖音本地分类与回复进度\n'+f"状态：{phase}\n符合条件：{visible.get('count','刷新中')}\n范围：30天内，中、高、超高意向\n检查时间：{now()}\n后台继续筛选，不发送。\n"
 (HERE/'实时进度.txt').write_text(text,encoding='utf-8')
with (HERE/'watch.lock').open('a+b') as lock:
 lock.seek(0)
 if not lock.read(1):lock.write(b'0');lock.flush()
 lock.seek(0);msvcrt.locking(lock.fileno(),msvcrt.LK_NBLCK,1)
 write(HERE/'worker-restart-receipt.json',{'pid':os.getpid(),'started_at':now(),'reason':'本地分类接续启动，按当前业务规则消费登记增量','platform_requests':0,'send_authorized':False})
 last=None
 while not (HERE/'STOP').exists():
  current=signature()
  if current!=last:
   mark('processing_local_snapshot')
   with (HERE/'watch.log').open('a',encoding='utf-8') as log:
    log.write('\n'+now()+' source/review change\n');log.flush()
    proc=subprocess.run([sys.executable,str(HERE/'build_snapshot.py')],cwd=ROOT,stdout=log,stderr=log)
   if proc.returncode:
    mark('retrying_local_failure','builder exit '+str(proc.returncode))
    time.sleep(60)
    continue
   last=current
  mark('watching_for_registered_delta')
  time.sleep(60)
 else:mark('stopped_by_local_stop_file')
