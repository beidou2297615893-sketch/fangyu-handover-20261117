import json,pathlib,sys,collections
B=pathlib.Path(__file__).resolve().parent.parent
x=json.loads(sys.stdin.read());page=x['page'];p=B/'recall-audit/part-1'/('page-%02d.json'%page)
cs=[c for g in json.loads(p.read_text(encoding='utf-8'))['post_groups'] for c in g['comments']]
rows=[]
for group in x['keep']:
 for key in group['keys'].split(): rows.append({'review_key':key,'decision':'keep','reason':group['reason'],'patch':{}})
rows+=x.get('change',[])
keys=[r['review_key'] for r in rows];expected=[c['key'] for c in cs]
assert len(set(keys))==len(keys)
assert set(keys)==set(expected),{'missing':sorted(set(expected)-set(keys)),'extra':sorted(set(keys)-set(expected))}
idx={r['review_key']:r for r in rows}
out=p.with_name(p.stem+'.audit.jsonl');out.write_text(''.join(json.dumps(idx[k],ensure_ascii=False,separators=(',',':'))+'\n' for k in expected),encoding='utf-8')
print(out,len(rows),collections.Counter(r['decision'] for r in rows))
