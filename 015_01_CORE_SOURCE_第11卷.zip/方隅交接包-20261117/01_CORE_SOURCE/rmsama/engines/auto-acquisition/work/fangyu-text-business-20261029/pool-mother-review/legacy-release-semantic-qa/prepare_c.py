import pathlib,json,hashlib,collections,re,functools
O=pathlib.Path(__file__).resolve().parent;P=O.parent;W=P.parent;C=P/'legacy-literal-binding'
def load(p):return json.loads(pathlib.Path(p).read_text('utf8'))
def jl(p):return [json.loads(l) for l in pathlib.Path(p).read_text('utf8').splitlines() if l.strip()]
@functools.lru_cache(None)
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def can(x):return hashlib.sha256(json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def key(x):return x['platform'],str(x.get('cid',x.get('comment_id'))),str(x.get('uid',x.get('customer_uid')))
def dump(n,x):(O/n).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n','utf8')
def putjl(n,x):(O/n).write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in x),'utf8')
v=load(C/'validate.json');assert v['all_passed'] and v['independent_file_validation_passed']
protected={**v['source_sha256'],**{str(C/n):h for n,h in v['output_sha256'].items()},str(C/'validate.json'):sha(C/'validate.json')}
for f,h in protected.items():assert sha(f)==h,f
excluded_files=[P/'legacy-local-planning/representative-review.jsonl',P/'legacy-short-preview/qa-v2/review-200.jsonl',O/'review-200.jsonl',C/'representative-review.jsonl',C/'representative-render-review.jsonl']
exclude={key(r) for f in excluded_files for r in jl(f)};exclude.update(key(c['plan']) for c in load(P/'legacy-combo-families/representative-validation.json')['cases']);exclude.update(key(r) for r in jl(O/'regression-review.jsonl'))
cur=load(W/'region-brand-routing/current.json');sources={key(r):r for f in cur['results'].values() for r in jl(f)}
rows=jl(C/'proposed-plans.jsonl');bound=[r for r in rows if r.get('family')];eligible=[r for r in bound if key(r) not in exclude]
base=load(pathlib.Path(load(C/'manifest.json')['base_contract']))['families'];addon=load(C/'contract-addon.json')['families'];families={**base,**addon}
def order(xs):return sorted(xs,key=lambda r:hashlib.sha256(('|'.join(key(r))+'C-semantic-release-20261030').encode()).hexdigest())
selected=[];chosen=set();why={}
def add(r,reason):
 if key(r) in chosen:return
 chosen.add(key(r));selected.append(r);why[key(r)]=reason
# Greedy set cover: atomic literal slots, business-action suffix combinations, platform and unknown contact.
def tags(r):
 f=r['family'];d={'platform:'+r['platform'],'family:'+f};d.update('slot:'+s for s in r['fill']);
 if f.startswith('literal_'):d.add('suffix:'+f.split('__',1)[1])
 if r.get('contact_policy_original') is None:d.add('contact:null')
 return d
available_tags=set().union(*(tags(r) for r in eligible));required={t for t in available_tags if not t.startswith('family:')};covered=set()
while required-covered and len(selected)<45:
 r=max(order(eligible),key=lambda r:(len((tags(r)&required)-covered),len(tags(r)&required),r['family'].startswith('literal_')))
 if not (tags(r)&required)-covered:break
 add(r,'greedy coverage of atomic literal slots and action-suffix combinations');covered.update(tags(r))
patterns=[('price inquiry vs budget',r'多少钱|多少一个月|实价|实惠'),('comparative quoted price',r'这么|那么|这个价格|贵|便宜'),('spatial radius',r'公里|千米|分钟|半小时'),('OR',r'或者|还是|或'),('negative',r'不要|不想|不能|不超|不合租'),('work subject',r'上班|工作'),('lease/time',r'入住|短租|起租|个月')]
for name,rx in patterns:
 for r in order([r for r in eligible if re.search(rx,sources[key(r)]['comment_text'])])[:2]:
  if len(selected)<60:add(r,'risk boundary '+name)
for r in order(eligible):
 if len(selected)>=60:break
 if r['family'] not in {x['family'] for x in selected}:add(r,'fresh exact-family diversity fill')
for r in order(eligible):
 if len(selected)>=60:break
 add(r,'deterministic fresh fill')
assert len(selected)==60
contexts={}
def sample(p,i,reason,fresh):
 k=key(p);s=sources[k];raw=s['source_record'];orig=s.get('original_raw_record') or {};cl=raw.get('classification') or raw
 ctxkey=k[0]+':'+str(s.get('video_id') or s.get('note_id') or raw.get('video_id') or raw.get('note_id'));ctx={'post_body':raw.get('post_body') or orig.get('post_text'),'post_title':raw.get('post_title') or orig.get('post_title'),'source_file':cur['results'][k[0]],'source_record_key':list(k),'missing_context':orig.get('missing_context',[])}
 if ctxkey in contexts:assert contexts[ctxkey]['post_body']==ctx['post_body'] and contexts[ctxkey]['post_title']==ctx['post_title']
 else:contexts[ctxkey]=ctx
 assert hashlib.sha256(s['comment_text'].encode()).hexdigest()==p['sourceSHA'];assert can(raw)==p['original_classification_sha256']
 render=families[p['family']]['template'].format(**p['fill']) if p['family'] else None;assert render==p['draft_text_preview'],(p['cid'],render,p['draft_text_preview'])
 return {'sample_index':i,'group':'C','platform':k[0],'cid':k[1],'uid':k[2],'comment_text':s['comment_text'],'source_comment_sha256':p['sourceSHA'],'plan_sha256':can(p),'plan_source_file':str(C/'proposed-plans.jsonl'),'source_file':cur['results'][k[0]],'source_file_sha256':sha(cur['results'][k[0]]),'context_key':ctxkey,'context_sha256':can(contexts[ctxkey]),'direct_parent_text':raw.get('direct_parent_text') or orig.get('parent_text'),'sampling_reason':reason,'family':p.get('family'),'fill':p.get('fill',{}),'rendered_text':render,'source_role':s.get('role'),'source_state':s.get('demand_state'),'source_interest':s.get('interest_at_comment'),'source_topic_evidence':cl.get('topic_evidence',cl.get('topics',[])),'target_regions':cl.get('target_regions',s.get('target_regions')),'time_mentions':cl.get('time_mentions',s.get('time_mentions')),'needs_review':cl.get('needs_review',[]),'source_blocking_reasons':raw.get('blocking_reasons',[]),'source_contact_policy':p.get('contact_policy_original'),'plan_contact_policy':p.get('contact_policy_effective_for_render'),'source_contact_boundaries':cl.get('contact_boundaries',[]),'delivery_holds':p.get('delivery_holds',[]),'original_semantic_scope_flags':p.get('original_semantic_scope_flags',[]),'source_reply_missing_facts':p.get('preserved_missing_facts',[]),'source_published_at':s.get('published_at'),'send_authorized':p['send_authorized'],'can_send_now':p['can_send_now'],'new_holdout':fresh}
samples=[sample(p,i,why[key(p)],True) for i,p in enumerate(selected,1)]
reg=[]
for p in rows:
 if p['cid']=='7255695817427174179':reg.append(sample(p,1,'Known developed regression: 这么便宜 deictic price comparison, excluded from new holdout',False))
boundary=[]
for cid in ['7662232963195781888','7579169170143937326','7284519671942955812','7649628332190876473','7660937995856233273','7661833774938358534']:
 p=next(p for p in rows if p['cid']==cid);assert not p.get('family')
 r=sample(p,len(boundary)+1,'Supplemental held boundary only: excluded from 60 newly bound previews; previous use='+str(key(p) in exclude),False);r['previously_used_in_development_or_review']=key(p) in exclude;boundary.append(r)
putjl('C-sample-60.jsonl',samples);putjl('C-regression-input.jsonl',reg);putjl('C-held-boundary-input.jsonl',boundary);dump('C-shared-contexts.json',contexts)
coveredfamilies={p['family'] for p in selected}&set(addon)
dump('C-manifest.json',{'sources_sha256_before':protected,'source_verification_passed_before_sampling':True,'new_holdout':60,'excluded_unique_IDs':len(exclude),'excluded_sources':[str(x) for x in excluded_files],'all_new_literal_family_count':len(addon),'new_exact_literal_families_covered_count':len(coveredfamilies),'exact_literal_families_covered':sorted(coveredfamilies),'exact_literal_families_not_covered':sorted(set(addon)-coveredfamilies),'atomic_slots_available':sorted(t for t in required if t.startswith('slot:')),'action_suffixes_available':sorted(t for t in required if t.startswith('suffix:')),'set_cover_uncovered_tags':sorted(required-set().union(*(tags(r) for r in selected))),'all_147_exact_families_in_60_mathematically_possible':False,'API_calls':0,'platform_calls':0,'send_attempts':0,'usage':'unknown'})
print(json.dumps({'C_new_holdout':len(samples),'new_literal_exact_family_coverage':len(coveredfamilies),'addon_total':len(addon),'set_cover_uncovered':sorted(required-set().union(*(tags(r) for r in selected))),'regression':len(reg),'source_SHA_checks':len(protected)},ensure_ascii=False))
