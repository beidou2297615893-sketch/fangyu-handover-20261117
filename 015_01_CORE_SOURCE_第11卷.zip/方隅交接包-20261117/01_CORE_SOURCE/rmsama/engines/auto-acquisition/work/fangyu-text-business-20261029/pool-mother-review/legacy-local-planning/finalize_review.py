import json,pathlib,hashlib,collections,re,string
O=pathlib.Path(__file__).resolve().parent;W=O.parents[1];B=W/'douyin-registered-v2/increments/f98cc21138910fb9'
def load(p):return json.loads(pathlib.Path(p).read_text(encoding='utf8'))
def jl(p):return [json.loads(l) for l in pathlib.Path(p).read_text(encoding='utf8').splitlines() if l.strip()]
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def objsha(x):return hashlib.sha256(json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def put(p,x):pathlib.Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
reasons={
'7255695817427174179':'“这么便宜”依赖原帖价位；只剩一居室会丢价格参照。保留待核，缺同房源价格参照绑定。',
'7255713560180917047':'原AI已判二环内为desired；area同时确认该地区有没有合适房，不丢房态。',
'7255856873403613989':'一号线、便宜点、养小猫均出自本人已有三池证据；综合条件核实保留三项，不声称可养。',
'7269422523753677626':'阜通是work而非住址；commute只确认去阜通是否方便。',
'7284519671942955812':'四五千是不能承受的比较价，并非可接受预算；西三旗是work。需要否定预算范围标签。',
'7273044584850440997':'虽无topic证据，但原AI已有唯一desired丰台，原评仅丰台求租；area可绑定且不重判意向。',
'7277058581849457443':'新疆是租客身份资格问题，非目的地；原约束缺主体类型，不能套area。',
'7355359365215372073':'毕业生女生是室友偏好，不能只留合租；需同住对象约束类型绑定。',
'7277061448881144616':'多个替代地区且拒绝中介；必须同时保留地区OR关系与接触身份边界。',
'7277190947837199119':'不是中介是联系对象限制；不能只保留西站附近而套普通住户引荐。',
'7291872510760223524':'纯询价；price问租金，不推断报价。',
'7295403553559200521':'纯询价；price保持未核价状态。',
'7296455778248016677':'月租多少为月价询问，非租一个月；price正确。',
'7296633319965901577':'一个月是价格单位；不得选monthly或lease_fixed。',
'7338839562125656882':'一年合同属于当前住处，核心是未到期换房规则；不能转成新租期。',
'7360345656550277938':'明天是联系时间，非入住/看房；必须保留历史发表日锚与未约定状态。',
'6ad9825e000000000a0231fa':'空房与看房均明确，但现有零填项contact并不明确核实看房，rent_process又未明确房态；缺空房加看房组合家族，不缺意向判断。',
'6ad35812000000000b0001a6':'主卧独卫或一室户是替代选项；1500-2000左右非硬上限。短列不能把二者变成同时必需。',
'6ad64050000000000b01afb9':'后天属于历史看房询问，非已约定看房；需原日期确认家族。',
'6acddb040000000007011bf6':'多地区替代关系未明，AB套为可接受选项，随时入住是灵活性；原有复杂范围需保留。',
'6ad9f986000000000f02fd2b':'问价足以选price；联系许可缺失仍独立保留，不能冒充可发送。',
'6ad4cab3000000000d02580b':'礼貌仅为语气，price可复用；缺联系许可不重判意向。',
'6add5e160000000013005ee7':'全女生是合租室友要求，两室一厅只是最好；缺偏好强度与对象绑定。',
'6ac8bf3c0000000008036f47':'1w以下和1w以上别私信共同限定预算与联系；不能只摘数额，不能把别联系吞掉。',
'6ad2e903000000000d027570':'询问是否与别人合租，不是已要求合租；需要合租状态询问加房态家族。',
'6add825f000000000a01d324':'民用水电与看房同时询问；单设施核实会漏看房，保持组合缺口。',
'6add986c0000000012025e9f':'商用水电作为原文条件核实，不改成民水民电，也不声称已确认。',
'6adeac14000000000f0317ec':'多少米缺结构化主题证据，原文也可能是价钱俗称；需原AI字段适配/少量标签补充，不本地重判。',
'6aaba50e00000000150082eb':'只想了解，无细分主题；可补需求主题或保留原基础母句，不强行套询价。',
'6aad005d000000000202b897':'价格加车位，车位已有原约束但缺类型主体适配；不能只回租金。',
'67815faf000000001a00e0aa':'要求一样借用上下文，8k以下、车位和放宽偏好均重要；不能将上下文要求静默省略。',
'6ad45e97000000001200ba46':'工作地未给实体，核心是用位置判断通勤；普通location能发位置但未表达通勤核对，保守留家族范围缺口，不需重判意向。',
'6ae2b2de000000000a027f17':'朱梅路为work，“不行”时才考虑双方合租；不可转成无条件合租需求。',
'7340274366159176499':'第一人称想租属于客户，不能塞进住户自述；缺细分pool标签，保留原判。',
'7403575513841615670':'客户我想租不作为填项；available只确认空房，品牌住户自述不改变客户事实归属。',
'7456979109173412649':'本人就租一个月为租期，抽一个月并用lease_fixed询问能否租，不将其当月价。',
'7474659746345648933':'租一个月是明确租期，“咋样”是询问语气；lease_fixed保留租期。',
'7480762288749085455':'800真实性是马上退房的前提；不能去掉条件后当即刻入住或预算。',
'7515263875277914938':'预算两千和两居室两项原AIrequire，可用实体短列核实，不夹客户第一人称。',
'7518573243277722395':'北京市五环之内为desired，预算1万为预算；两项短列完整且不外推门店库存。',
'7637955321743508250':'三林地铁站边上、2800左右、带独卫、民用水电可在已有四池原文中全部绑定；左右保留，不改硬上限。',
'7646056506236191538':'价位、独卫、水电为他人/市场房源陈述；不能强行归给本人需求。',
'7646838145304757050':'盈丰路是work，萧山区desired，通勤接受地铁加小电驴；需要多角色地点与交通组合标签，不能只保留2k和户型。',
'7662922769337041723':'女友院校与千元内属于他人条件，原AI地区unresolved；不得改成本人住址或本人预算。',
'7364774505778643753':'一房两厅、价格、宠物、离地铁近均需保留；残余地铁距离使计划暂缓，不能只摘宠物。',
'7276893708803785528':'原记录contact unknown且仅@他人；非候选负例，保留原排除。',
'7291369933999588159':'闲聊且联系unknown；非候选，不因本地模板扩充而吸纳。',
'7579433894443107112':'短租二月与一月二月存在日历/租期歧义，且不要押金及1200以内必须保留；需时间角色补充。',
'7613878551481991963':'金牛成华关系未知，不要太远距离未具体；不能用两地预算户型短列掩盖范围缺口。',
'7645585857198932771':'4千8不含水电燃气为当前住处价，不是新预算；附近参照当前七宝9号线，需比较与参照绑定。',
'7655444013865108273':'原试版只留包水电会漏掉月租询问；最终改为待核，缺价格加是否含水电组合家族。',
'7255871509112030012':'朗芳园、一居和询价需同时保留；现有requirements无租金询问，最终拒绝试版计划，缺明确组合家族。',
'7258289232179413801':'唯一desired亦庄加有没有房；area完整承接。',
'7261571317509489420':'通州附近原文逐字desired，area不推断距离或库存。',
'7276038268793471778':'一居室作为客户户型短项核实，未把客户求租转成住户自身事实。',
'7291666236168946459':'纯问位置，location可复用且不虚构具体地址。',
'7291687532953600809':'阳台条件加租金询问；只留阳台会漏价，最终保留待核，缺设施加价格家族。',
'7346458584756683572':'1200左右原文保留近似值，budget_fit不当硬上限。',
'7348094694620316450':'位置与多少钱均已原AI判ask；price_location同时承接，无具体条件待填。',
'7380615342697186111':'多少钱及在哪里两池零填项组合，price_location保留两问。',
'7447515726389330751':'具体在哪仅位置问题，location未虚构地址。',
'7483535742838489914':'两千为已有价格require证据内实体；budget_fit按原词核实，不增加月价单位。',
'7702170989710344996':'水电气加起来与“比超过1000”字面含歧义，原AI预算polarity unknown；不能自行纠成不超过或当纯租金。',
'7618738495263359781':'原地区quote是一整句客户自述，text才是字面实体市区；只允许原AI text在quote内的市区，不能把我想租放进住户句。残余若不能安全消解则暂缓。',
'7652766484415431461':'原地区quote为我要建国北，原AI text是建国北；只绑定建国北，客户我要不进入住户事实。',
'7679715460049355562':'原地区quote为我要租金牛区的有吗，text为金牛区；提取同一quote内地区实体并使用area，不传整句第一人称。',
}
samples=jl(O/'representative-input.jsonl'); plans=jl(O/'local-proposed-plans.jsonl');manifest=load(O/'plan-source-manifest.json');cur=load(W/'region-brand-routing/current.json');sources={}
for p,f in cur['results'].items():
 for r in jl(f):sources[p,r['comment_id'],r['customer_uid']]=r
out=[]
for s in samples:
 assert s['cid'] in reasons,s['cid'];r={**s,'review':{'reviewer':'current_assistant_semantic_review','model_id':'unexposed_runtime_model_id','new_remote_model_call':False,'judgment':'plan_preserves_intent_with_original_delivery_holds' if s['proposed_plan']['family'] else 'hold_preserves_unresolved_scope_or_template_gap','reason':reasons[s['cid']],'original_classification_changed':False,'human_gold_label_created':False,'review_scope':'family and literal-parameter semantic fit only; neither reclassify intent nor approve sending','context_used':'own comment plus existing AI evidence/roles; shared stored post context retained for unresolved references'}};out.append(r)
(O/'representative-review.jsonl').write_text(''.join(json.dumps(x,ensure_ascii=False,separators=(',',':'))+'\n' for x in out),encoding='utf8')
families=load(B/'local-mother-contract.json')['families'];checks=collections.Counter();issues=[]
for p in plans:
 key=p['platform'],p['cid'],p['uid'];r=sources[key];text=r['comment_text'];assert p['sourceSHA']==hashlib.sha256(text.encode()).hexdigest();checks['CID_UID_text_SHA_matches']+=1
 assert p['original_classification_sha256']==objsha(r['source_record']);checks['original_source_record_sha_unchanged']+=1
 assert not p['classification_changed'] and not p['send_authorized'] and not p['can_send_now'];checks['classification_and_send_flags_preserved']+=1
 if p['family']:
  assert not p['hold_reasons'];d=families[p['family']];names={n for _,n,_,_ in string.Formatter().parse(d['template']) if n};assert names==set(p['fill'])==set(d['required_fill'])
  for f,v in p['fill'].items():
   for span in v.split('、') if f=='requirements' else [v]:
    assert span in text and any(e['field']==f and e['quote']==span for e in p['evidence']);assert not re.search(r'我|我们|咱|本人|朋友|同事|女朋友',span);checks['literal_parameter_spans']+=1
  if p['family']=='commute':assert any(x.get('relation')=='work' and p['fill']['destination'] in x['quote'] for x in p['source_field_evidence']['target_regions'])
  if p['family']=='area':assert any(x.get('relation')=='desired' and p['fill']['place'] in x['quote'] for x in p['source_field_evidence']['target_regions'])
  if p['family']=='requirements':
   tags={x if isinstance(x,str) else x.get('pool') for x in p['source_field_evidence']['topics']}
   assert '价格预算' not in tags or any(e['pool']=='价格预算' for e in p['evidence'])
   assert '看房联系' not in tags
   assert '位置通勤' not in tags or p['source_field_evidence']['target_regions']
  checks['family_fill_schema_valid']+=1
 else:assert p['hold_reasons'];checks['held_with_specific_reasons']+=1
for path,h in manifest['sources'].items():assert sha(path)==h,('protected_source_changed',path)
assert sha(W/'region-brand-routing/current.json')==manifest['current_pointer_sha256']
assert len(samples)==len(out)<=80 and len(plans)==12963 and len({(p['platform'],p['cid'],p['uid']) for p in plans})==12963
family_counts=dict(collections.Counter(p['family'] for p in plans if p['family']));proposed=sum(bool(p['family']) for p in plans);held=len(plans)-proposed
# Disjoint next-action categories: no review accuracy is inferred from these technical coverage counts.
def bucket(p):
 hs=p['hold_reasons']
 if not hs:return 'locally_bound_review_only'
 if any('contact' in h for h in hs):return 'contact_boundary_or_policy'
 if any('subject' in h or 'condition_scope' in h or 'conditional_fact' in h or 'region_relation' in h or 'multiple_region' in h or 'time_role' in h or 'negation' in h for h in hs):return 'existing_semantic_scope_or_short_label_binding_needed'
 if 'missing_structured_pool_evidence' in hs or any('topic_evidence_not_literal' in h for h in hs):return 'legacy_schema_or_literal_evidence_gap'
 if 'other_constraint_needs_typed_subject_binding' in hs:return 'constraint_type_and_subject_binding_needed'
 if any(h.endswith('question_would_be_dropped_by_requirements') for h in hs) or 'no_existing_family_preserves_combination' in hs:return 'integrated_family_gap_no_reclassification_needed'
 return 'literal_extraction_or_existing_pool_binding_gap'
buckets=collections.Counter(bucket(p) for p in plans)
supplements=[];suppcounts=collections.Counter()
for p in plans:
 if p['family']:continue
 fs=p['source_field_evidence'];flags=[]
 if any(x.get('relation')=='unresolved' for x in fs['target_regions']):flags.append('region_relation_unresolved')
 if any(x.get('subject')=='unresolved' for x in p['literal_evidence']):flags.append('topic_subject_unresolved')
 if any(x.get('polarity')=='unknown' for x in p['literal_evidence']):flags.append('topic_polarity_unknown')
 if flags:
  suppcounts.update(flags);supplements.append({'platform':p['platform'],'cid':p['cid'],'uid':p['uid'],'sourceSHA':p['sourceSHA'],'source_file_sha256':p['source_file_sha256'],'unresolved_existing_AI_fields':flags,'existing_topic_evidence':p['literal_evidence'],'existing_target_regions':fs['target_regions'],'requested_addition':'Only bind the already unresolved subject/region relation/polarity to a literal span; do not rewrite reply or revise role/state/interest. Resolve from existing context first.','model_called':False})
(O/'label-supplement-input.jsonl').write_text(''.join(json.dumps(x,ensure_ascii=False,separators=(',',':'))+'\n' for x in supplements),encoding='utf8')
for p in plans:p['next_action_category']=bucket(p)
(O/'local-proposed-plans.jsonl').write_text(''.join(json.dumps(x,ensure_ascii=False,separators=(',',':'))+'\n' for x in plans),encoding='utf8')
put(O/'label-supplement-category-plan.json',{'full_corpus_model_rerun_required':False,'categories_disjoint':dict(buckets),'note':'These are field-binding workload buckets, not counts of truly missing AI decisions. Reuse original scope/quote labels first; only unresolved boundary cases need short label supplementation. No comment-level new labels or new reply bodies generated.','explicitly_unresolved_existing_AI_unique_candidates':len(supplements),'explicitly_unresolved_fields_overlapping_counts':dict(suppcounts),'minimal_additional_fields':['parameter spans tied to existing pool quote','subject of constraint','desired/work/current_home anchor and OR/AND relation','negation/approximation/fee inclusion scope','time role for disputed calendar month versus lease duration','context reference requirement binding'],'new_AI_calls_required_exact_count':None,'reason':'433 existing explicitly unresolved-label candidates are a bounded follow-up queue, not 8544 full reclassification requests. Resolve from stored original context first; no claim that each candidate requires a new call.'})
v={'all_checks_passed':True,'input_candidates':12963,'planned_family_count':proposed,'held_count':held,'family_counts':family_counts,'disjoint_next_action_counts':dict(buckets),'explicitly_unresolved_existing_AI_unique_candidates':len(supplements),'explicitly_unresolved_fields_overlapping_counts':dict(suppcounts),'checks':dict(checks),'representative_review_count':len(out),'representative_review_is_accuracy_estimate':False,'initial_pilot_defect_repaired':True,'technical_coverage_not_accuracy':True,'source_and_pointer_hashes_unchanged':True,'source_writes':0,'classification_changes':0,'new_reply_bodies_saved':0,'platform_calls':0,'send_attempts':0,'new_paid_API_calls':0,'independent_second_model_review':False,'human_confirmed':False,'usage':'unknown','missing_stored_comment_SHA':59,'independent_registered_text_verification':59,'missing_hash_mismatch_claimed':False,'no_contact_negative_control_count':sum(s['original_classification']['contact_policy']=='no_contact' for s in out),'unknown_contact_negative_control_count':sum(s['original_classification']['contact_policy']=='unknown' for s in out),'no_contact_control_note':'No historical no_contact record was found in the current sidecar during structural selection; unknown and identity-restricted boundaries are reviewed, no synthetic no_contact case is claimed.','artifacts_sha256':{n:sha(O/n) for n in ['local-proposed-plans.jsonl','representative-review.jsonl','representative-post-contexts.json','label-supplement-category-plan.json','label-supplement-input.jsonl']}}
put(O/'validation.json',v)
lines=['# 历史母句本地规划与代表核验','','本次只建立可回退计划，未生成新回复正文、未改原判/原稿/当前指针、未访问平台或发送。',f'历史候选共 12,963 条，已有标签可本地绑定家族 {proposed:,} 条；其余 {held:,} 条保留具体范围、证据或家族缺口。此数量是技术覆盖，不是语义准确率，也不是已发布数量。','',f'对 {len(out)} 条现存真实评论进行了当前助手语义核对，包含原盘点全部36次样例出现（重复评论合并）、月价/租期、水电预算、工作地、他人条件、第一人称与未知联系限制。没有新增第二模型调用；确切运行模型ID未暴露，用量未知。未找到当前旁注中的no_contact实体负例，不冒称该类已做真实样例验证。','','## 本地可推进的家族','']
lines += [f'- {k}：{n:,} 条。' for k,n in family_counts.items()]
lines += ['','按原AI池与关系选家族，参数仅取原quote中的实体和条件短项；位置与房态可以整合为area，work进入commute，预算加户型可进入requirements。若地区quote为客户整句第一人称，优先复用原AI text里的字面实体，不能把客户“我要租”塞进住户事实。联系许可缺失单独保留，未把缺失改成允许。所有宣传中的真实住户/优惠资格、具体报价、同店同房源条件仍沿用原缺事实清单，不能凭本地规划算作已核实。','','## 还缺什么','']
lines += [f'- {k}：{n:,} 条（互斥工作量分类）。' for k,n in buckets.items() if k!='locally_bound_review_only']
lines += ['',f'真正已标为未判的补标签候选 {len(supplements)} 条：地区关系unresolved {suppcounts["region_relation_unresolved"]}条、主题主体unresolved {suppcounts["topic_subject_unresolved"]}条、主题极性unknown {suppcounts["topic_polarity_unknown"]}条（类别重叠）。已单独准备只含ID、SHA和原证据的补标签输入；先查已有语境，确需模型才补对应短标签，不重判全库意向。']
lines += ['','这些待核数不等于必须再次调用AI的条数。先适配已有标签及条件quote；只有主体、条件范围、地名关系或时间角色仍确实未判的边界需要补少量标签。本次没有把所有8千余条直接扔回AI，也没有重跑历史意向。尚不能诚实给出“确需补AI”的精确条数，类别计划保留此数为未知。','','具体最小缺口：','- “多少一个月 包水电么”需要租金与是否含水电的组合家族，试版只填包水电会漏价，现已拒绝。','- “朗芳园一居多少钱呀”“阳台的多少钱”需要保留地点/户型/设施与租金的组合家族；不能借“没库存”统一退回自我介绍。','- “主卧独卫或者一室户…1500-2000左右”已有替代及约数标签，应适配保留，不能把独卫要求套到两个选项上。','- “在西三旗上班…租不去四五千”要保留work与不可承受比较价，不可当可接受预算。','- “我现在七宝…4千8不加水电燃气”是当前住房事实，不能当新租房预算。','- “预算水电气加起来比超过1000”原预算极性unknown且文字有歧义，只补确认标签，不自动纠字。','','抖音59条缺原存文本SHA，已引用主窗口独立本地来源核验59/59的CID、UID和完整原评一致证据；未补写原字段，也不称为不匹配。','',f'验收边界：全部来源/指针SHA、身份、原分类指纹、参数字面及字段通过；{len(out)}条代表核验不能推断全库准确率。原源写入0，平台调用0，发送0。']
(O/'report.md').write_text('\n'.join(lines)+'\n',encoding='utf8')
print(json.dumps({k:v[k] for k in ['all_checks_passed','input_candidates','planned_family_count','held_count','family_counts','disjoint_next_action_counts','representative_review_count']},ensure_ascii=False))
