"""Local text release; no source writes, model API, or sending operations."""
import collections
import hashlib
import importlib.util
import json
from pathlib import Path

HERE=Path(__file__).resolve().parent
WORK=HERE.parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return [json.loads(l) for l in p.open(encoding='utf-8-sig') if l.strip()]
def write(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def main():
    spec=importlib.util.spec_from_file_location('pool_sop_mothers',HERE/'mothers/renderer.py')
    mothers=importlib.util.module_from_spec(spec);spec.loader.exec_module(mothers)
    source=WORK/'high-intent-pools-20261101/all-high-intent-pools.jsonl'
    old={(r['platform'],str(r['comment_id'])):r for r in read(source)}
    digest=sha(source)
    class_digest=sha(HERE/'classifier/classified.jsonl')
    classes=read(HERE/'classifier/classified.jsonl')
    assert len(classes)==len(old)==12209
    assert {(r['platform'],str(r['comment_id'])) for r in classes}==set(old)
    counts=collections.defaultdict(collections.Counter); output=[]
    for c in classes:
        key=(c['platform'],str(c['comment_id'])); original=old[key]
        meta=original.get('original_classification') or {}
        request=dict(original,**{k:v for k,v in c.items() if k not in original})
        request.update(pools=c['pools'],subtags=c['subtags'],classification=c)
        request['tone']=meta.get('tone') or (meta.get('reply_plan') or {}).get('tone')
        reply=mothers.render(request)
        if not c['pools']:
            reply.update(draft_text=None,status='needs_semantic_pool')
        text=original['comment_text'];body=reply.get('draft_text')
        contact=meta.get('contact_boundaries') or original.get('contact_boundaries') or []
        # Legacy schema uses the literal 'allow'; this is not a restriction.
        if contact in ('allow','allowed','none',''):
            contact=[]
        ended=c.get('constraints',{}).get('current_state_review_needed',False)
        row=dict(platform=key[0],comment_id=key[1],comment_text=text,
                 source_sha256=digest,comment_sha256=hashlib.sha256(text.encode()).hexdigest(),
                 original_interest=original.get('interest') or meta.get('interest_at_comment'),
                 pools=c['pools'],subtags=c['subtags'],classification=c,reply=reply,
                 reply_body_sha256=hashlib.sha256(body.encode()).hexdigest() if body else None,
                 contact_boundaries=contact,needs_currentness_review=ended,
                 original_comment_date=original.get('published_at'),
                 actual_send_authorized=False,actual_send_attempted=False,
                 prior_receipts_preserved=True)
        output.append(row)
        counts[key[0]]['total']+=1
        counts[key[0]]['assigned_pool']+=bool(c['pools'])
        counts[key[0]]['sop_draft']+=bool(body)
        counts[key[0]]['needs_semantic_review']+=not bool(c['pools'])
        counts[key[0]]['contact_or_currentness_review']+=bool(contact or ended or reply.get('contact_hold'))
    out=HERE/'replies.jsonl'
    out.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in output),encoding='utf-8')
    for platform in counts:
        (HERE/(platform+'-replies.jsonl')).write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in output if r['platform']==platform),encoding='utf-8')
    assert sha(source)==digest
    assert sha(HERE/'classifier/classified.jsonl')==class_digest, 'Classification changed while building'
    by_id={(r['platform'],r['comment_id']):r for r in output}
    old_sample=read(WORK/'local-subtag-integration-20261101/user-review-50.jsonl')
    sample=[]
    for i,r in enumerate(old_sample,1):
        current=by_id[(r['platform'],str(r['comment_id']))]
        sample.append(dict(number=i,platform=r['platform'],comment_id=r['comment_id'],
                           comment_text=r['comment_text'],previous_reply=r['reply'].get('candidate_text'),
                           previous_status=r['reply']['status'],pools=current['pools'],
                           new_reply=current['reply'].get('draft_text'),
                           unanswered_details=current['reply'].get('unanswered_details',[])))
    write(HERE/'fifty-before-after.json',sample)
    report=dict(total=len(output),by_platform=dict(counts),source_sha256=digest,
                replies_file=str(out.resolve()),replies_sha256=sha(out),
                generated_drafts=sum(c['sop_draft'] for c in counts.values()),
                draft_is_not_send_authorization=True,production_consumer_verified=False,
                classification_report=json.loads((HERE/'classifier/report.json').read_text(encoding='utf-8')),
                dependency_sha256={str(p.relative_to(HERE)):sha(p) for p in [HERE/'classifier/classifier.py',HERE/'classifier/classified.jsonl',HERE/'mothers/renderer.py']})
    write(HERE/'release-report.json',report)
    human=Path('outputs/方隅双平台文本业务/本地分类与母句升级');human.mkdir(parents=True,exist_ok=True)
    lines=['# 同50条评论修订前后','', '以下均为真实评论。通用接话不承诺具体房态、报价或地域匹配；尚未发送。','', '|序号|平台|原评论|分类池|新版回复|','|---|---|---|---|---|']
    for r in sample:
        fields=[str(r['number']),'抖音' if r['platform']=='douyin' else '小红书',r['comment_text'],'、'.join(r['pools']),r['new_reply'] or '语义待核']
        lines.append('|'+ '|'.join(x.replace('|','／').replace('\n',' ') for x in fields)+'|')
    (human/'同50条评论修订后.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    print(json.dumps({k:v for k,v in report.items() if k not in ('classification_report','dependency_sha256')},ensure_ascii=False))
if __name__=='__main__':main()
