import json,sys,subprocess,pathlib
# Format-only expansion of model-authored rows; no text matching or semantic decision.
rows=json.loads(sys.stdin.read()); out=[]
for a in rows:
 z={'i':a['i'],'reference_mentions':[{'span':s,'reference_type':typ,'referent_type':target,'evidence':[{'source':'comment','quote':s}]} for s,typ,target in a.get('r',[])], 'price_relation':[{'relation':v,'source':src,'quote':q} for v,src,q in a.get('p',[])], 'place_relation':[{'relation':v,'source':src,'quote':q} for v,src,q in a.get('l',[])], 'time_relation':[{'relation':v,'source':src,'quote':q} for v,src,q in a.get('t',[])], 'brand_source_relation':a.get('b','unknown'), 'contact_action_direction':a.get('c','no_contact_action'),'housing_purpose':a.get('h','residential_evident'), 'evidence':[{'source':src,'quote':q} for src,q in a['e']], 'unresolved_or_missing':a.get('u',[])}
 out.append(z)
p=subprocess.run([sys.executable,str(pathlib.Path(__file__).with_name('write.py'))],input=json.dumps(out,ensure_ascii=False),text=True,encoding='utf-8',capture_output=True);print(p.stdout,p.stderr);sys.exit(p.returncode)
