"""Stream deterministic synthetic records through the classifier; never store the corpus."""
import argparse
from collections import Counter
import ctypes
from ctypes import wintypes
import hashlib
import json
import multiprocessing as mp
import os
from pathlib import Path
import time

HERE = Path(__file__).resolve().parent
TEXTS = ('正在找两室，希望有阳台', '转租我的房子，有厨房', '明年才找，现在不找',
         '方便约时间看房吗', '多少米', '已经租到了，谢谢',
         '想租一居，带猫，不能合租', '我在上海上班，求租北京一居')

def peak_bytes():
    if os.name != 'nt':
        try:
            import resource
            value = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
            return int(value if os.uname().sysname == 'Darwin' else value * 1024)
        except (ImportError, AttributeError):
            return None
    class Counters(ctypes.Structure):
        _fields_ = [('cb', ctypes.c_ulong), ('PageFaultCount', ctypes.c_ulong),
                    ('PeakWorkingSetSize', ctypes.c_size_t), ('WorkingSetSize', ctypes.c_size_t),
                    ('QuotaPeakPagedPoolUsage', ctypes.c_size_t), ('QuotaPagedPoolUsage', ctypes.c_size_t),
                    ('QuotaPeakNonPagedPoolUsage', ctypes.c_size_t), ('QuotaNonPagedPoolUsage', ctypes.c_size_t),
                    ('PagefileUsage', ctypes.c_size_t), ('PeakPagefileUsage', ctypes.c_size_t)]
    counters = Counters(); counters.cb = ctypes.sizeof(counters)
    current_process = ctypes.windll.kernel32.GetCurrentProcess
    current_process.restype = wintypes.HANDLE
    get_info = ctypes.windll.psapi.GetProcessMemoryInfo
    get_info.argtypes = [wintypes.HANDLE, ctypes.POINTER(Counters), wintypes.DWORD]
    get_info.restype = wintypes.BOOL
    ok = get_info(current_process(), ctypes.byref(counters), counters.cb)
    return int(counters.PeakWorkingSetSize) if ok else None

_classifier = None
def init():
    global _classifier
    from local_classifier import LocalClassifier
    _classifier = LocalClassifier()

def process(bounds):
    start, end = bounds
    counts = Counter(); digest_xor = 0; model_calls = 0
    for i in range(start, end):
        row = {'platform': 'synthetic', 'comment_id': str(i), 'customer_uid': str(i),
               'comment_text': TEXTS[i % len(TEXTS)], 'post_body': '一居室出租',
               'post_author_same_as_commenter': False}
        result = _classifier.classify(row)
        model_calls += result.get('model_calls', 0)
        counts[str(result.get('interest_at_comment'))] += 1
        # Commutative checksum allows verification across different worker counts.
        payload = json.dumps([i, result.get('role'), result.get('demand_state'),
                              result.get('interest_at_comment'), result.get('topics')],
                             ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode('utf-8')
        digest_xor ^= int.from_bytes(hashlib.sha256(payload).digest(), 'big')
    return end - start, dict(counts), digest_xor, peak_bytes(), model_calls

def run_cases(path):
    """Independently check authored expectations, provenance and operational guards."""
    from local_classifier import LocalClassifier
    classifier = LocalClassifier()
    data = json.loads(path.read_text(encoding='utf-8'))
    failures = []
    for case in data['cases']:
        record = case['record']; result = classifier.classify(record); errors = []
        for key, value in case['expected'].items():
            if result.get(key) != value:
                errors.append(f'{key}: expected {value!r}, got {result.get(key)!r}')
        for topic in case['topics_required']:
            if topic not in result.get('topics', []):
                errors.append(f'missing confirmed topic {topic}')
        for key, strings in case['forbidden_contains'].items():
            value = json.dumps(result.get(key), ensure_ascii=False)
            for text in strings:
                if text in value:
                    errors.append(f'{key} contains forbidden {text!r}')
        for key, expected in [('assigned_store', None), ('current_need_verified', False),
                              ('send_authorized', False), ('can_send_now', False), ('model_calls', 0)]:
            if key not in result or result[key] != expected:
                errors.append(f'{key}: expected {expected!r}')
        allowed = [record['comment_text']]
        if record.get('post_author_same_as_commenter') is True:
            allowed.append(record.get('post_body', ''))
        for item in result.get('evidence', []) + result.get('topic_evidence', []):
            quote = item.get('quote') if isinstance(item, dict) else None
            if not isinstance(quote, str) or not quote or not any(quote in s for s in allowed):
                errors.append('missing or untraceable evidence quote')
            if isinstance(item, dict) and item.get('source') == 'post_body' and (
                record.get('post_author_same_as_commenter') is not True or
                not isinstance(quote, str) or quote not in record.get('post_body', '')
            ):
                errors.append('post body evidence lacks verified same-author provenance')
        for topic in result.get('topics', []):
            if not any(isinstance(e, dict) and e.get('pool') == topic and e.get('quote')
                       for e in result.get('topic_evidence', [])):
                errors.append(f'confirmed topic lacks evidence: {topic}')
        if errors:
            failures.append({'case_id': case['id'], 'errors': errors})
    report = {'kind': 'synthetic business boundary checks, not accuracy',
              'cases': len(data['cases']), 'passed': len(data['cases']) - len(failures),
              'failed': len(failures), 'failures': failures}
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 1 if failures else 0

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--count', type=int, default=1000000)
    p.add_argument('--workers', type=int, choices=(1, 4), default=1)
    p.add_argument('--batch-size', type=int, default=5000)
    p.add_argument('--report', type=Path)
    p.add_argument('--cases', type=Path, help='run synthetic business acceptance checks instead of benchmark')
    a = p.parse_args()
    if a.cases:
        raise SystemExit(run_cases(a.cases))
    if a.count < 1 or a.batch_size < 1:
        p.error('count and batch size must be positive')
    batches = ((i, min(i + a.batch_size, a.count)) for i in range(0, a.count, a.batch_size))
    start = time.perf_counter(); count = 0; counts = Counter(); checksum = 0; peaks = []; model_calls = 0
    # imap can eagerly queue bounds; descriptors are tiny, but never queues input records.
    if a.workers == 1:
        init(); iterator = map(process, batches); pool = None
    else:
        pool = mp.get_context('spawn').Pool(a.workers, initializer=init)
        iterator = pool.imap(process, batches, chunksize=1)
    try:
        for n, c, h, peak, calls in iterator:
            count += n; counts.update(c); checksum ^= h
            model_calls += calls
            if peak is not None:
                peaks.append(peak)
    finally:
        if pool is not None:
            pool.close(); pool.join()
    elapsed = time.perf_counter() - start
    report = {'dataset': 'synthetic repeated templates, not real-comment accuracy or sourceDB load',
              'count': count, 'workers': a.workers, 'batch_size': a.batch_size,
              'elapsed_seconds': round(elapsed, 3), 'records_per_second': round(count / elapsed, 2),
              'interest_counts': dict(counts), 'result_xor_sha256': format(checksum, '064x'),
              'model_calls_reported': model_calls,
              'parent_peak_working_set_bytes': peak_bytes(),
              'largest_observed_worker_peak_working_set_bytes': max(peaks, default=None),
              'memory_note': 'Per-process peak; worker peak is maximum of workers, not aggregate.'}
    rendered = json.dumps(report, ensure_ascii=False, indent=2)
    if a.report:
        a.report.write_text(rendered + '\n', encoding='utf-8')
    print(rendered)

if __name__ == '__main__':
    mp.freeze_support()
    main()
