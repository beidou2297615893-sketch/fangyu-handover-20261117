import json, pathlib, sys, hashlib
D=pathlib.Path(__file__).resolve().parent.parent
O=pathlib.Path(__file__).resolve().parent
rows=[json.loads(x) for x in (D/'shard0.jsonl').read_text(encoding='utf-8').splitlines()]
contexts=json.loads((D/'shared-contexts.json').read_text(encoding='utf-8'))
def page(a,b):
 seen=set()
 for i in range(a,min(b,len(rows))):
  x=rows[i];k=x['context_key']
  if k not in seen:
   print('POST',k,json.dumps(contexts['posts'][k]['content'],ensure_ascii=False));seen.add(k)
  print(i,x['comment'])
def save(file):
 decisions=json.loads(pathlib.Path(file).read_text(encoding='utf-8-sig'))
 out=[]
 for d in decisions:
  x=rows[d['i']];z={k:x[k] for k in ('platform','cid','uid','source_comment_sha256')}
  ev=[]
  def e(field,s,q):
   v={'field':field,'source':s,'quote':q};ev.append(v);return {'source':s,'quote':q}
  z['reference_mentions']=[{'span':r[0],'reference_type':r[1],'referent_type':r[2],'evidence':e('reference_mentions','comment',r[0])} for r in d.get('r',[])]
  for mention in z['reference_mentions']:
   if mention['referent_type'].startswith('original_post_') and 'h' in d and d['h'][1] in ('post_title','post_body'):
    mention['referent_evidence']=[e('reference_mentions',d['h'][1],d['h'][2])]
   elif mention['referent_type']=='commenter_explicit_location':
    mention['referent_evidence']=[e('reference_mentions',q[1],q[2]) for q in d.get('e',[]) if q[0]=='reference_mentions']
  for field,key in [('price_relation','p'),('place_relation','l'),('time_relation','t')]:
   z[field]=[{'relation':v[0],'evidence':e(field,v[1],v[2])} for v in d.get(key,[])]
  z['brand_source_relation']=d.get('b',['unknown'])[0]
  if 'b' in d:e('brand_source_relation',d['b'][1],d['b'][2])
  z['contact_action_direction']=d.get('c',['no_contact_action'])[0]
  if 'c' in d:e('contact_action_direction',d['c'][1],d['c'][2])
  z['housing_purpose']=d.get('h',['unknown'])[0]
  if 'h' in d:e('housing_purpose',d['h'][1],d['h'][2])
  for extra in d.get('e',[]):e(extra[0],extra[1],extra[2])
  z['evidence']=ev
  z['unresolved_or_missing']=['direct_parent: unknown，父评论文本缺失；未引用父评']+d.get('u',[])
  if z['brand_source_relation']=='unknown':z['unresolved_or_missing'].append('brand_source_relation: unknown，现有文本未明确该房源品牌归属')
  out.append(z)
 with (O/'labels.jsonl').open('a',encoding='utf-8',newline='\n') as f:
  for z in out:f.write(json.dumps(z,ensure_ascii=False,separators=(',',':'))+'\n')
 (O/'progress.json').write_text(json.dumps({'status':'in_progress','written':sum(1 for _ in (O/'labels.jsonl').open(encoding='utf-8')),'last_page':pathlib.Path(file).name,'actual_usage':'unknown'},ensure_ascii=False,indent=2),encoding='utf-8')
 print('written',len(out))
if __name__=='__main__':
 if sys.argv[1]=='page':page(int(sys.argv[2]),int(sys.argv[3]))
 elif sys.argv[1]=='save':save(sys.argv[2])
