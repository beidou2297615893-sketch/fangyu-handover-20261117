"""Offline, standard-library sidecar. Never mutates source, sends, or invokes models.
Evidence is lexical, not semantic truth. Original AI intent remains authoritative.
"""
import argparse, collections, hashlib, json, re, time
from pathlib import Path
HERE=Path(__file__).resolve().parent
CONFIG=json.loads((HERE/'subtags-20261101-v2.json').read_text(encoding='utf-8-sig'))
RULES=[(x,re.compile(x['pattern'])) for x in CONFIG['rules']]
def clauses(text):
 return [(m.start(),m.end(),m.group()) for m in re.finditer(r'[^，,。；;！？!?\n]+[！？!?]?',text)]
def classify_intent(row):
 t=row.get('comment_text') or ''; reasons=[]
 result={'state':'needs_ai','role':'unknown','interest':'uncertain','evidence':[], 'current_need_verified':False}
 if not isinstance(t,str): return result
 if row.get('post_author_same_as_commenter') or str(row.get('reply_to','0'))!='0':
  return dict(result,reason='主体或回复链待核，短句不得脱离语境')
 if re.search(r'他说|她说|朋友说|别人说|“|”|"',t):
  return dict(result,reason='引用或转述先核主体，不将他人结束或供给算作本人')
 supply=re.search(r'我(?:这|这里|有).{0,8}(?:出租|转租|招租)|本人(?:出租|房东)|房东直租|我出租',t)
 seek=re.search(r'^(?:你好[，, ]*)?(?:我(?:想|要|正在|准备|打算)?(?:求租|租|找房|找(?:一|个|套|间))|求租|帮(?:父母|家人|爸妈|孩子)(?:找房|租房))|(?:^|[，,。？? ])急租(?:$|[，,。！! ])',t)
 if supply and (seek or re.search(r'我(?:想|要|正在|准备|打算)?(?:求租|租|找房)',t)):
  return dict(result,reason='供需混合待核')
 if re.search(r'(?:已经|已|刚|刚刚)(?:租到|找到房|租好了)|不(?:再|用|需要)租(?:房|了)|不找房了',t):
  return dict(result,state='local_decided',role='demand_ended',interest='inactive_at_comment',evidence=[t],reason='本人明确结束；记录保留，不推断当前状态')
 if supply:
  return dict(result,state='local_decided',role='supply',interest='not_rental_demand',evidence=[supply.group()],reason='明确本人供给，保留记录')
 if seek and re.search(r'租|房|公寓|单间|[一二三四两1234]室',t) and not re.search(r'如果|假如|据说|他说|她说|朋友说|以前|去年|曾经|“|”|"|不想租|不租了',t):
  return dict(result,state='local_decided',role='demand',interest='high_at_comment',evidence=[seek.group()],reason='明确本人或家庭代求租；设施否定只作条件，不排除需求')
 # A direct rental question may use a short condition only when the post supplies
 # explicit rental context. Never infer demand from a bare keyword or IP/region.
 context=row.get('post_body') or ''
 context_rental=bool(re.search(r'租房|出租|招租|公寓|房源|房租|整租|合租|租金',context))
 blocked=bool(re.search(r'转租|招租|房东|中介|我有|找室友|招室友|他说|她说|朋友说|以前|去年|“|”|"',t))
 if context_rental and not blocked:
  question=re.fullmatch(r'(?:请问|你好|麻烦问下|想问一下)?[，, ]*(?:多少钱|什么价|什么价格|怎么收费|租金多少|价格多少|月租多少|在哪|在哪里|在哪儿|哪里|地址在哪|具体位置|还有房吗|还有吗|有房吗|有空房吗|还能租吗|还在吗|怎么联系|如何联系|可以看房吗|能看房吗|怎么预约看房|可以养猫吗|可以养狗吗|能养猫吗|能养狗吗)[呀啊呢嘛吗？?！!。 ]*',t)
  condition_question=re.fullmatch(r'(?:请问|你好)?[，, ]*(?:有|有没有|还有).{1,30}(?:的吗|的吗？|的吗\?|吗|吗？|吗\?|有吗|有吗？|有吗\?)[？?。 ]*',t)
  explicit_condition=bool(re.search(r'预算|[一二三四两1234](?:室|居)|整租|合租|电梯|阳台|独卫|厨房|地铁|\d+元|\d+以内|猫|狗',t))
  if question or (condition_question and explicit_condition):
   return dict(result,state='local_decided',role='demand',interest='high_at_comment',evidence=[t],reason='明确租赁帖语境下本人直接询问价格地点房态设施或看房联系；地点时效另核，不推断当下仍求租')
  # Common concrete requests with place/room qualifiers; never interpret an
  # unscoped mention of price or a supply listing as a request.
  qualified_question = re.fullmatch(r'(?:请问[，, ]*)?(?:有|有没有|还有)[^。！？!?\n]{0,45}(?:房|房子|单间|套[一二三四1234]|[一二两三四1234](?:室|居室)|整租|合租)(?:出租|可以租)?(?:的吗|吗|嘛|啊|呀|呢)?[？?。 ]*',t)
  if qualified_question and (t.startswith('有没有') or re.search(r'吗|嘛|[？?]',t)):
   return dict(result,state='local_decided',role='demand',interest='high_at_comment',evidence=[t],reason='租赁语境下询问具体居住房源，原文条件另行分池核对')
 return dict(result,reason='未有足够明确主体与求租行为，保留待语义判读')
def annotate(row):
 t=row.get('comment_text') or ''; t=t if isinstance(t,str) else ''; hits=[]; cs=clauses(t)
 for rule,pattern in RULES:
  for m in pattern.finditer(t):
   start,end,clause=next((c for c in cs if c[0]<=m.start()<c[1]),(0,len(t),t))
   prefix=t[max(start,m.start()-8):m.start()]; near=t[max(start,m.start()-8):min(end,m.end()+5)]
   negative=bool(re.search(r'(?:不要|不想|不接受|不能|不可|不让|禁止|拒绝|不带|不养|没有|没|无|不需要|不用|不考虑)(?:.{0,4})$',prefix)) or rule['subtag'] in ('不接受宠物','联系限制')
   question=bool(re.search(r'吗|么|能否|可否|是否|多少|哪里|哪儿|几楼|有没有|有吗|[?？]',clause))
   # '能不能/可不可以' is an availability question, not a negative assertion.
   if re.search(r'能不能|可不可以',near): negative=False; question=True
   polarity='negative_question' if negative and question else 'negative' if negative else 'question' if question else 'positive_or_mention'
   condition=clause if re.search(r'如果|要是|假如|只要|前提|必须|至少|以内|以下|不超过|或者|还是|都要|且|并且',t) else None
   hits.append(dict(pool=rule['pool'],subtag=rule['subtag'],text=m.group(),start=m.start(),end=m.end(),clause=clause,clause_start=start,clause_end=end,polarity=polarity,condition=condition,evidence_kind='lexical_not_intent'))
 supply=bool(re.search(r'出租|招租|房东|转租',t)); demand=bool(re.search(r'求租|想租|找房|要租',t))
 role='mixed_supply_demand' if supply and demand else 'supply_signal' if supply else 'demand_signal' if demand else 'not_determined'
 flags=[]
 if role=='mixed_supply_demand': flags.append('供需混合需确认主体')
 if re.search(r'他说|她说|朋友说|“|”|"',t): flags.append('转述或引用主体待核')
 if re.search(r'这个|这样|这么|同款|同价|那里|那边',t): flags.append('指代需原帖语境')
 if not hits: flags.append('未命中保留')
 original=row.get('demand_pools') or row.get('topics') or []
 pools=sorted(set(h['pool'] for h in hits))
 return dict(version=CONFIG['version'],original_interest=row.get('interest_at_comment'),original_role=row.get('role'),original_pools=original,evidence=hits,local_pools=pools,role_signal=role,intent_decision=classify_intent(row),status='matched_sidecar' if hits else 'unmatched_retained',needs_semantic_review=bool(flags),review_reasons=flags,constraint_relation='alternative_or_mixed' if re.search(r'或者|或是|还是|要么|或',t) else 'conjunction_or_unspecified',time_evidence=[{'text':m.group(),'start':m.start(),'end':m.end(),'anchored':False} for m in re.finditer(r'[下本这]个?月|明天|后天|去年|明年|\d+月(?:\d+[日号])?|月底|月初|已经|已租',t)],region_evidence=[{'text':m.group(),'start':m.start(),'end':m.end()} for m in re.finditer(r'北京|上海|广州|深圳|杭州|南京|成都|武汉|天津|重庆|苏州|大兴|通州|朝阳|海淀|浦东|[二三四五六]环(?:内|外)?',t)],region_fallback='方隅公寓',ip_is_not_target_region=True,current_need_verified=False,send_authorized=False,model_calls=0,reply_generation_model_calls=0)
def run(source,out):
 out.mkdir(parents=True,exist_ok=True); before=hashlib.sha256(source.read_bytes()).hexdigest(); counts=collections.Counter(); pool_counts=collections.Counter(); mismatches=[]; n=0; started=time.perf_counter()
 with source.open(encoding='utf-8-sig') as f,(out/'annotated.jsonl').open('w',encoding='utf-8') as dest:
  for line in f:
   if not line.strip(): continue
   row=json.loads(line); a=annotate(row); n+=1
   dest.write(json.dumps({'comment_id':row.get('comment_id'),'platform':row.get('platform'),'comment_text':row.get('comment_text'),'source_line':n,'source_sha256':before,'local_subtag_sidecar':a},ensure_ascii=False)+'\n')
   counts[a['status']]+=1; counts['needs_semantic_review']+=a['needs_semantic_review']; counts['negative_or_negative_question']+=any(h['polarity'].startswith('negative') for h in a['evidence']); counts['mixed_supply_demand']+=a['role_signal']=='mixed_supply_demand'; counts['multi_pool']+=len(a['local_pools'])>1
   pool_counts.update(a['local_pools']); old={x.get('pool') if isinstance(x,dict) else x for x in a['original_pools']}; new=set(a['local_pools'])
   if old==new: counts['exact_pool_agreement']+=1
   else: mismatches.append({'comment_id':row.get('comment_id'),'comment_text':row.get('comment_text'),'existing_pools':sorted(old),'lexical_sidecar_pools':sorted(new),'missing_from_local':sorted(old-new),'additional_local':sorted(new-old)})
   counts['existing_pool_occurrences']+=len(old); counts['overlap_pool_occurrences']+=len(old&new)
 assert before==hashlib.sha256(source.read_bytes()).hexdigest(),'Source changed'
 report=dict(version=CONFIG['version'],source_sha256=before,records=n,counts=dict(counts),pool_counts=dict(pool_counts),exact_pool_agreement_rate=counts['exact_pool_agreement']/max(n,1),existing_pool_overlap=counts['overlap_pool_occurrences']/max(counts['existing_pool_occurrences'],1),subtags=len(CONFIG['rules']),major_pools=len(set(x['pool'] for x in CONFIG['rules'])),source_unchanged=True,elapsed_seconds=round(time.perf_counter()-started,3),measurement='一致性与覆盖，不是准确率；无人工金标；旁注不替代原AI意向；差异全部保留',model_calls=0)
 (out/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8'); (out/'pool-differences.jsonl').write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in mismatches),encoding='utf-8'); print(json.dumps(report,ensure_ascii=False))
if __name__=='__main__':
 p=argparse.ArgumentParser(); p.add_argument('--input',type=Path,required=True); p.add_argument('--output',type=Path,default=HERE/'full-run'); a=p.parse_args(); run(a.input,a.output)
