"""Single offline experiment. No production hooks. Historical AI agreement != truth."""
import os
os.environ['OMP_NUM_THREADS']='8'
os.environ['OPENBLAS_NUM_THREADS']='8'
import collections, hashlib, json, time, platform
from pathlib import Path
import joblib,numpy as np, sklearn,scipy
from sklearn.pipeline import Pipeline
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[2]
def digest(t): return hashlib.sha256(t.encode('utf-8')).hexdigest()
def dump(name,obj): (HERE/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2),encoding='utf-8')
def score(rows,probs):
 pos=probs>=.95; neg=probs<=.05; decided=pos|neg; labels=np.array([r['y'] for r in rows]); n=len(rows)
 return {'records':n,'reference_positive':int(sum(labels)),'decided':int(sum(decided)),'decided_coverage':float(sum(decided)/max(n,1)),'positive_decisions':int(sum(pos)),'negative_decisions':int(sum(neg)),'positive_vs_reference_negative':int(sum(pos&(labels==0))),'negative_vs_reference_positive':int(sum(neg&(labels==1))),'deferred':int(sum(~decided)),'agreement_among_decided':float(sum((pos==(labels==1))&decided)/max(sum(decided),1)),'positive_reference_agreement':float(sum(pos&(labels==1))/max(sum(pos),1)),'negative_reference_agreement':float(sum(neg&(labels==0))/max(sum(neg),1))}
def main():
 started=time.perf_counter(); pointer=ROOT/'fangyu-douyin-independent/text-screening-current-summary.json'
 meta=json.loads(pointer.read_text(encoding='utf-8-sig')); source=Path(meta['result_file']); sha=hashlib.sha256(source.read_bytes()).hexdigest()
 records=[json.loads(l) for l in source.read_text(encoding='utf-8-sig').splitlines() if l.strip()]; excluded=collections.Counter(); platforms=collections.Counter(); candidates=[]
 for r in records:
  role=r.get('role'); interest=r.get('interest_at_comment'); platforms[r.get('platform','unknown')]+=1
  if role=='demand' and interest in ('high','medium','super_high'): y=1
  elif role in ('supply','discussion') and interest in ('unrelated','low','very_low'): y=0
  else: excluded[str(role)+'/'+str(interest)]+=1; continue
  text=r.get('comment_text'); group=r.get('video_id') or r.get('post_id') or r.get('note_id')
  if not isinstance(text,str) or not text.strip(): excluded['empty_comment']+=1; continue
  if not group: excluded['missing_post_group']+=1; continue
  # Video IDs are platform-scoped. No source keywords, store, prior reason or topic feature.
  group=str(r.get('platform','unknown'))+':'+str(group)
  bucket=int(digest('lexical-v1-group-split:'+group)[:8],16)%100
  split='train' if bucket<70 else 'calibration' if bucket<85 else 'test'
  norm=''.join(text.split()).casefold(); body=(r.get('post_body') or '')[:300]
  candidates.append(dict(comment_id=str(r['comment_id']),platform=r.get('platform','unknown'),group=group,split=split,text_key=digest(norm),feature=text[:500]+'\n原帖：'+body,y=y))
 bytext=collections.defaultdict(list)
 for r in candidates: bytext[r['text_key']].append(r)
 sets=collections.defaultdict(list); dedup_counts=collections.Counter()
 for key,rs in bytext.items():
  if len({r['split'] for r in rs})>1: dedup_counts['cross_split_duplicate_records_removed']+=len(rs); continue
  if len({r['y'] for r in rs})>1: dedup_counts['conflicting_label_duplicate_records_removed']+=len(rs); continue
  # One deterministic record per identical normalized comment, within its group split.
  r=min(rs,key=lambda x:x['comment_id']); sets[r['split']].append(r); dedup_counts['within_split_duplicates_removed']+=len(rs)-1
 for s in sets: sets[s].sort(key=lambda r:r['comment_id'])
 assert not ({r['group'] for r in sets['train']}&{r['group'] for r in sets['test']})
 assert not ({r['text_key'] for r in sets['train']}&{r['text_key'] for r in sets['test']})
 model=Pipeline([('tfidf',TfidfVectorizer(analyzer='char',ngram_range=(2,4),min_df=2,max_features=150000,sublinear_tf=True,dtype=np.float32)),('classifier',LogisticRegression(C=1.0,max_iter=400,solver='liblinear',random_state=20261101))])
 model.fit([r['feature'] for r in sets['train']],[r['y'] for r in sets['train']]); joblib.dump(model,HERE/'model.joblib')
 reports={}
 for split in ('calibration','test'):
  rs=sets[split]; probs=model.predict_proba([r['feature'] for r in rs])[:,1]; reports[split]=score(rs,probs)
  reports[split]['platforms']={p:score([r for r in rs if r['platform']==p],np.array([prob for r,prob in zip(rs,probs) if r['platform']==p])) for p in {r['platform'] for r in rs}}
  with (HERE/(split+'-predictions.jsonl')).open('w',encoding='utf-8') as f:
   for r,prob in zip(rs,probs):
    f.write(json.dumps({'comment_id':r['comment_id'],'platform':r['platform'],'reference_y':r['y'],'probability_demand':float(prob),'decision':'positive' if prob>=.95 else 'negative' if prob<=.05 else 'needs_ai','production_enabled':False},ensure_ascii=False)+'\n')
 dump('manifest.json',{'production_enabled':False,'source_sha256':sha,'source_rows':len(records),'source_platforms':dict(platforms),'excluded_labels':dict(excluded),'deduplication':dict(dedup_counts),'split_method':'SHA256(platform:video/post id), 70/15/15; cross-split normalized-comment duplicates excluded from all splits; same-split dedup; label conflicts excluded','split_counts':{s:len(rs) for s,rs in sets.items()},'split_group_counts':{s:len({r['group'] for r in rs}) for s,rs in sets.items()},'feature_fields':['comment_text[:500]','post_body[:300]'],'thresholds':{'positive':.95,'negative':.05},'parameters':'TFIDF char 2-4,min_df2,max_features150000; LogisticRegression C1 liblinear max_iter400; no threshold tuning or calibration fitting','versions':{'python':platform.python_version(),'sklearn':sklearn.__version__,'numpy':np.__version__,'scipy':scipy.__version__},'model_sha256':hashlib.sha256((HERE/'model.joblib').read_bytes()).hexdigest(),'runtime_seconds':round(time.perf_counter()-started,3),'reference_limitation':'Historical AI labels, no human gold. Known-label selective test excludes unknown; outputs probability is not calibrated truth confidence. No production enablement.'})
 dump('report.json',reports); dump('split-manifest.json',{s:[{'comment_id':r['comment_id'],'group':r['group'],'text_key':r['text_key'],'y':r['y']} for r in rs] for s,rs in sets.items()})
 assert sha==hashlib.sha256(source.read_bytes()).hexdigest()
 print(json.dumps(reports,ensure_ascii=False))
if __name__=='__main__': main()

