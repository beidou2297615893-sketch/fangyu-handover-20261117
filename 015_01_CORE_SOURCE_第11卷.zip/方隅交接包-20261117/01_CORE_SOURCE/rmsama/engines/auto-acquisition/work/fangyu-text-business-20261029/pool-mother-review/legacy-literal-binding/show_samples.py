import json,pathlib
O=pathlib.Path('work/fangyu-text-business-20261029/pool-mother-review/legacy-literal-binding');s=[json.loads(l) for l in (O/'representative-input.jsonl').read_text(encoding='utf8').splitlines()]
for i,x in enumerate(s):print(i,x['plan']['cid'],x['comment'])
