import json,pathlib
O=pathlib.Path(__file__).resolve().parent
# Explicit model corrections after reading each affected row's actual bound context.
quotes={35:'杭州一室一厅1400',37:'整租独门独户两室一厅',38:'上海闵行区村房500块',42:'一室一厅一厨一卫',43:'两居室',44:'一室一厅一厨一卫',54:'上海闵行区村房500块',66:'两居室',70:'上海闵行区村房500块',74:'女生独居首选1b1b',84:'一室一厅一厨一卫',95:'福州两室一厅1300',102:'两居室',114:'一室一厅一厨一卫',116:'北京小一居室',126:'住宅服务式公寓'}
for p in O.glob('page-*.json'):
 ds=json.loads(p.read_text(encoding='utf-8-sig'))
 for d in ds:
  i=d['i']
  if i in quotes:d['h']=['residential_evident','post_body',quotes[i]]
  if i==38:
   d['p']=[['original_post_quote_confirmation','comment','500的房子']]
   d['e']=[['price_relation','post_body','村房500块']]
   d['u']=['500指原帖已给出的房源报价，不当作评论人预算；报价周期 unknown，原帖文字未明示']
  if i==114:d.pop('u',None)
  if i==126:d['u'].append('unknown：#安驻上海租房为品牌/来源提及，文本未进一步确认房源运营归属')
 p.write_text(json.dumps(ds,ensure_ascii=False,indent=2),encoding='utf-8')
