"""Batch-local evidence checks only; no semantic classification or platform access."""
import json,pathlib,hashlib,collections,datetime,sys,importlib.util
B=pathlib.Path(__file__).resolve().parent
W=B.parent.parent.parent
R=W.parent.parent
LOCKED={'mother_adapter.py':'fff622c0d202f0ddcd1c313723a81fa5efb1f555458f732a5ef9158fe7385cbd','publish_douyin_increment_snapshot.py':'b3653a7a7ddad1786cd05cf9aab05dc8bbdc2ac4b68cec1dc3f72d639cb147b7','test_mother_adapter.py':'5a94d3ed332999bef3750fe866e8a82d008fc415c2afd3efaa01e8e68666c5d5'}
def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for chunk in iter(lambda:f.read(8*1024*1024),b''):h.update(chunk)
    return h.hexdigest()
def get(p):return json.loads(p.read_text(encoding='utf-8'))
def jl(p):
    with p.open(encoding='utf-8') as f:
        for line in f:
            if line.strip():yield json.loads(line)
def put(p,d):p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def locked():
    actual={f:sha(W/f) for f in LOCKED};assert actual==LOCKED,actual;return actual
def pre():
    code_sha=locked();m=get(B/'manifest.json');inp=list(jl(B/'input.jsonl'))
    assert len(inp)==2075==m['new_comments']
    assert hashlib.sha256((B/'input.jsonl').read_bytes().replace(b'\r\n',b'\n')).hexdigest()==m['input_sha256']
    audit=get(B/'semantic-audit-merge-receipt.json');compiled=get(B/'semantic-compile-receipt.json')
    assert audit['complete'] is True and audit['independent_decisions']==1576
    assert compiled['AI_initial_and_detailed_complete']==2075
    assert compiled['unique_comments_with_independent_review']==1576
    assert compiled['independent_recall_and_level_calibration_complete']==1576
    assert compiled['semantic_final_sha256']==sha(B/'semantic-final.jsonl')
    for f,digest in compiled['original_review_file_versions'].items():assert sha(B/f)==digest
    for p in range(2):
        task=get(B/f'recall-audit/part-{p}/task.json')
        assert task['records']==788
        for source in task['primary_sources']:assert sha(B/source['path'])==source['sha256']
    semantic=list(jl(B/'semantic-final.jsonl'));out=[r for i in range(3) for r in jl(B/f'reviewed-{i}.jsonl')]
    ident=lambda r:tuple(r[f] for f in ['review_key','comment_id','customer_uid','video_id','platform'])
    assert len(out)==2075==len({r['review_key'] for r in out})==len({r['comment_id'] for r in out})
    assert set(map(ident,inp))==set(map(ident,out))
    source={r['review_key']:r for r in inp};quotes=0
    spec=importlib.util.spec_from_file_location('locked_adapter',W/'mother_adapter.py');adapter=importlib.util.module_from_spec(spec);spec.loader.exec_module(adapter);cache={}
    for r in out:
        adapter.validate_new_review(r,B,cache)
        s=source[r['review_key']];own=[s['comment_text']]+([s['post_body']] if s['post_author_same_as_commenter'] else [])
        qs=list(r.get('evidence',[]))
        for f in ['topics','target_regions','time_mentions','other_constraints','possible_topics','contact_boundaries']:
            qs.extend(v['quote'] for v in r.get(f,[]) if isinstance(v,dict) and 'quote' in v)
        assert all(q and any(q in text for text in own) for q in qs),(r['review_key'],'quote')
        quotes+=len(qs)
        assert r['reply_plan']['preferred_mother_slot'] in [None,1,2,7,13,16,19,25,28,31,34]
        assert r['human_confirmed'] is False and r['send_authorized'] is False and r['store_assignment'] is None
    assert sum(r['independent_recall_reviewed'] for r in out)==1576
    assert sha(W/'mother_adapter.py')==code_sha['mother_adapter.py']
    receipt={'batch':B.name,'all_checks_passed':True,'input_count':2075,'compiled_count':2075,'independent_reviewed':1576,'audit_changed_records':audit['changed_records'],'identity_set_equal':True,'quote_checks':quotes,'quotes_verbatim':True,'official_adapter_actual_file_bound_passed':2075,'semantic_final_sha256':sha(B/'semantic-final.jsonl'),'locked_code_sha256':code_sha,'primary_and_audit_SHA_verified':True,'usage':'unknown','platform_calls':0,'send_authorized':False,'checked_at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
    put(B/'prepublication-verification.json',receipt);print(json.dumps(receipt,ensure_ascii=False))
def post():
    code_sha=locked();summary=get(B/'summary.json');pointer_path=W.parent/'fangyu-douyin-independent/text-screening-current-summary.json';pointer=get(pointer_path)
    assert pointer==summary
    result=pathlib.Path(summary['result_file']);assert result.name==B.name+'-results.jsonl'
    actual_sha=sha(result);assert actual_sha==summary['result_sha256']==sha(B/'classified-snapshot.jsonl')
    manifest=get(B/'manifest.json');new_ids={r['comment_id'] for r in jl(B/'input.jsonl')}
    duplicate_label='同平台客户其他评论已有候选，保留备选不重复入队'
    # Legacy rows without a reply plan retain historical statuses. They were
    # already suppressed before this invocation and are not fresh suppressions.
    legacy_duplicate_status_ids={r['comment_id'] for r in jl(pathlib.Path(manifest['prior_result_file'])) if r.get('reply_plan') is None and not r.get('mother_reply_text') and r.get('reply_status')==duplicate_label}
    ids=set();customers=set();hi_ids=set();hi_customers=set();draft_ids=set();levels=collections.Counter();new_levels=collections.Counter();count=0;bad_flags=[];suppressed_ids=set()
    for r in jl(result):
        cid=r['comment_id'];assert cid not in ids;ids.add(cid);count+=1
        customer=(r.get('platform'),r['customer_uid']);customers.add(customer);level=r['interest_at_comment'];levels[level]+=1
        if cid in new_ids:new_levels[level]+=1
        if level in ['high','super_high']:hi_ids.add(cid);hi_customers.add(customer)
        if r.get('mother_reply_text'):draft_ids.add(cid)
        if r.get('send_authorized') is not False or r.get('can_send_now') is not False:bad_flags.append(cid)
        if r.get('reply_status')==duplicate_label:suppressed_ids.add(cid)
    assert not bad_flags
    assert ids==set(manifest['all_eligible_comment_ids'])
    assert count==29653==summary['snapshot_unique_comments']
    assert len(customers)==summary['unique_customers']
    assert dict(levels)==summary['interest_counts'] and dict(new_levels)==summary['new_interest_counts']
    assert len(hi_ids)==summary['high_or_super_comments'] and len(hi_customers)==summary['high_or_super_customers']
    assert len(draft_ids)==summary['local_mother_drafts']
    suppressed=len(suppressed_ids-legacy_duplicate_status_ids)
    assert suppressed==summary['same_customer_duplicates_prevented']
    actual_drafts=list(jl(B/'mother-drafts.jsonl'));assert len(actual_drafts)==len(draft_ids) and {r['comment_id'] for r in actual_drafts}==draft_ids
    state=get(W/'当前文本处理运行状态.json');assert state['douyin']['run']==B.name and state['douyin']['classified_comments']==count
    quota=state.get('quota_check',{});assert quota.get('ordinary_usage_allowed') is False
    assert state['douyin']['unprocessed_registered_comments']==0
    receipt={'batch':B.name,'publication_verified':True,'result_file':str(result),'result_sha256_actual':actual_sha,'result_sha256_matches_summary':True,'local_batch_and_result_bytes_sha_equal':True,'summary_pointer_matches':True,'snapshot_comments':count,'unique_comment_ids':len(ids),'unique_customers':len(customers),'new_comments':len(new_ids),'prior_comments':summary['previously_analyzed'],'interest_counts':dict(levels),'new_interest_counts':dict(new_levels),'high_or_super_comments':len(hi_ids),'high_or_super_customers':len(hi_customers),'mother_drafts':len(draft_ids),'same_customer_duplicates_prevented':suppressed,'preserved_legacy_duplicate_status_records':len(legacy_duplicate_status_ids),'all_send_authorized_and_can_send_now_false':True,'independent_reviewed_this_batch':1576,'locked_code_sha256':code_sha,'ordinary_usage_allowed':False,'existing_credits_authorized':True,'actual_task_usage':None,'actual_task_usage_status':'unknown','source_database_write_attempted_by_text_task':False,'platform_calls_by_text_task':0,'send_attempted_by_text_task':False,'platform_delivery_state':'not_checked_by_text_task','checked_at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
    put(B/'publication-verification.json',receipt);print(json.dumps(receipt,ensure_ascii=False))
if __name__=='__main__':{'pre':pre,'post':post}[sys.argv[1]]()
