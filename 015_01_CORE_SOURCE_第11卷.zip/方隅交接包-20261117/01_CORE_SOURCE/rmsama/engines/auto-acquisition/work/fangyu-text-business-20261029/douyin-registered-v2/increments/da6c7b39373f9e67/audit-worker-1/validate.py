import json,copy,hashlib,sys,datetime,collections
from pathlib import Path
W=Path(__file__).resolve().parent;B=W.parent;T=B.parents[2]
sys.path.insert(0,str(T))
import mother_adapter
def read(p):return [json.loads(x) for x in p.read_text(encoding='utf-8-sig').splitlines() if x.strip()]
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
task=json.loads((B/'recall-audit/part-1/task.json').read_text(encoding='utf-8-sig'))
expected=task['expected_review_keys']; originals={}; hashes={}
for src in task['primary_sources']:
 p=B/src['path']; hashes[src['path']]=digest(p); assert hashes[src['path']]==src['sha256']
 for r in read(p):
  if r['review_key'] in expected:
   assert r['review_key'] not in originals
   originals[r['review_key']]=r
allowed=set('role demand_state interest topics target_regions time_mentions other_constraints possible_topics evidence reason context_used needs_review contact_boundaries context_flags reply_plan'.split())
all_audits=[];texts={};inputs={};page_results=[];quotation_errors=[]
for n in range(4):
 p=B/f'recall-audit/part-1/page-{n:02d}.json';data=json.loads(p.read_text(encoding='utf-8-sig'))
 cs=[c for g in data['post_groups'] for c in g['comments']];aa=read(p.with_suffix('.audit.jsonl'))
 assert len(aa)==len(cs) and [a['review_key'] for a in aa]==[c['key'] for c in cs]
 for g in data['post_groups']:
  for c in g['comments']:
   key=c['key'];assert key not in texts
   texts[key]=[c['text']]+([g['post_body']] if c['same_author'] else [])
   inputs[key]=c
   for f,v in c['first_semantic_judgment'].items():assert originals[key][f]==v,(key,f,'primary-page mismatch')
 for a in aa:
  assert set(a)=={'review_key','decision','reason','patch'}
  assert a['decision'] in ('keep','change') and a['reason'].strip()
  assert set(a['patch'])<=allowed
  assert (a['patch']=={})==(a['decision']=='keep')
 all_audits+=aa
 page_results.append(dict(page=n,input=len(cs),output=len(aa),id_set_equal=True,keep=sum(a['decision']=='keep' for a in aa),change=sum(a['decision']=='change' for a in aa),audit_sha256=digest(p.with_suffix('.audit.jsonl')),input_sha256=digest(p)))
assert len(all_audits)==len(expected)==len(set(a['review_key'] for a in all_audits))==439
assert set(originals)==set(expected)==set(texts)==set(a['review_key'] for a in all_audits)
patched={k:copy.deepcopy(v) for k,v in originals.items()}
for a in all_audits:patched[a['review_key']].update(a['patch'])
formal_results={};source_files={}
for label,rows in [('original',originals),('patched',patched)]:
 prepared=[]
 for key in expected:
  r=copy.deepcopy(rows[key])
  assert all(r[x]==originals[key][x] for x in ['review_key','comment_id','customer_uid','platform','video_id'])
  assert r['human_confirmed'] is False and r['send_authorized'] is False and r['store_assignment'] is None
  assert r['reply_plan']['preferred_mother_slot'] in (None,1,2,7,13,16,19,25,28,31,34)
  quotes=[]
  for f in ['topics','target_regions','time_mentions','other_constraints','possible_topics','contact_boundaries']:
   for v in r[f]:
    if isinstance(v,dict) and 'quote' in v:quotes.append((f,v['quote']))
  quotes += [('evidence',v) for v in r['evidence']]
  for f,q in quotes:
   if not isinstance(q,str) or not q or not any(q in t for t in texts[key]):quotation_errors.append([label,key,f,q])
  r['classification_method']='ai_independent_semantic_fine_review' if label=='patched' else 'ai_semantic_initial_and_detailed'
  r['classification_stages_completed']=mother_adapter.REVIEW_METHOD_STAGES[r['classification_method']]
  r.pop('classification_review_source',None)
  prepared.append(r)
 source=W/f'{label}-isolated-semantic.jsonl'
 source.write_text(''.join(json.dumps(r,ensure_ascii=False,separators=(',',':'))+'\n' for r in prepared),encoding='utf-8')
 source_files[label]=dict(path=str(source.relative_to(B)),sha256=digest(source))
 cache={};errors=[]
 for r in prepared:
  candidate=copy.deepcopy(r);candidate['classification_review_source']=source_files[label]
  try:mother_adapter.validate_new_review(candidate,B,cache)
  except Exception as e:errors.append(str(e))
 formal_results[label]=dict(records=len(prepared),passed=len(prepared)-len(errors),errors=errors,uses_actual_jsonl_and_sha256=True)
assert not quotation_errors,quotation_errors
assert all(not x['errors'] for x in formal_results.values()),formal_results
result=dict(records=439,keep=sum(a['decision']=='keep' for a in all_audits),change=sum(a['decision']=='change' for a in all_audits),pages=page_results,id_set_equal=True,preserved_identifiers=True,quotation_errors=quotation_errors,formal_adapter=str(Path(mother_adapter.__file__).resolve()),formal_adapter_sha256=digest(Path(mother_adapter.__file__)),formal_validation=formal_results,isolated_sources=source_files,unchanged_primary_sha256=hashes,usage='unknown',human_confirmed=False,send_authorized=False,limitations=['仅本分片439条一次独立AI语义复核，不是人工金标或人工认可','只据提供正文、本人评论及初判；未读取平台、账号或深层回复','评论时意向不代表今日有效；实际门店报价、房态、政策、优惠和介绍资格待核','隔离编译元数据仅供结构预检，正式总文件与compiler绑定由主任务处理'])
(W/'validation.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
for p in page_results:
 (W/f"page-{p['page']:02d}.progress.json").write_text(json.dumps(dict(p,status='complete',formal_validation='passed'),ensure_ascii=False,indent=2),encoding='utf-8')
(W/'progress.json').write_text(json.dumps(dict(status='complete',records=439,keep=result['keep'],change=result['change'],at=datetime.datetime.now().astimezone().isoformat(),formal_validation='passed'),ensure_ascii=False,indent=2),encoding='utf-8')
report=f"本分片独立AI语义复核完成：439条，保留{result['keep']}条、修订{result['change']}条。\n\n四页逐条阅读共享正文、本人评论及原判断；每个review_key显式keep/change，完整覆盖439条且无重复。身份字段保持，全部引文逐字核对0错误。原判断439条和原判断加patch后439条分别以隔离真实JSONL及SHA256调用现有mother_adapter.validate_new_review，全部通过。\n\n修订重点：泛生活帖短询不写成高意向或现实找房推进；真实出租帖多少米保留询盘及价格/面积候选；本人明确求两室一厅不因泛标题压低；反问估价不当预算；未决短租长签纠纷保留后续换房机会；补贴资格保留住房线索；大床非必要与单人床接受分开；查询地区、通勤目的地与住房目标分开；供给无价不补价格池；宠物专项母句补同店允许猫及长租事实缺口。\n\n只有本分片页审计和audit-worker-1辅助产物写入，未改primary、part-0、adapter、总审计或总状态。未运行平台、访问账号凭据、采集或发送；未生成回复正文。\n\n限制：这是单次独立AI复核，不是人工认可；不保证零遗漏。今日需求与真实房源事实仍未核。credits获授权，实际usage未知，未购买。\n"
(W/'report.md').write_text(report,encoding='utf-8')
print(json.dumps(dict(records=439,keep=result['keep'],change=result['change'],formal_validation=formal_results,quotation_errors=quotation_errors),ensure_ascii=False))
