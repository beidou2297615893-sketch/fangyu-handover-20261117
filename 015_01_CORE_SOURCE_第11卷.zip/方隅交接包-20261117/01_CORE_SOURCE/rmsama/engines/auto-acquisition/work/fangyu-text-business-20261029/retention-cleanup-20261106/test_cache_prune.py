import json
from pathlib import Path
import sqlite3
import tempfile
import time
import unittest
from unittest.mock import patch
import prune_cached_records as p

class CachePruning(unittest.TestCase):
 def test_unused_lead_delete_preserves_any_delivery_or_assessment(self):
  with tempfile.TemporaryDirectory(dir=p.HERE) as directory:
   root=Path(directory);registry=root/'registry.json';ids=['old','fresh','reserved','assessed']
   registry.write_text(json.dumps({'digests':[p.retention30.fingerprint('douyin',cid) for cid in ids if cid!='fresh']}))
   database=root/'shared.sqlite3';db=sqlite3.connect(database)
   db.executescript('CREATE TABLE leads(platform,customer,comment,status,review_time); CREATE TABLE assessments(platform,comment); CREATE TABLE reservations(platform,comment);')
   db.executemany('INSERT INTO leads VALUES(?,?,?,?,NULL)', [('douyin',cid,cid,'unverified') for cid in ids]);db.execute("INSERT INTO reservations VALUES('douyin','reserved')");db.execute("INSERT INTO assessments VALUES('douyin','assessed')");db.commit();db.close()
   with patch.object(p.retention30,'REGISTRY',registry):removed=p.prune_unused_leads(database)
   db=sqlite3.connect(database);self.assertEqual(removed,1)
   self.assertEqual({r[0] for r in db.execute('SELECT comment FROM leads')},{'fresh','reserved','assessed'})
   self.assertEqual(db.execute('SELECT count(*) FROM business_cleared_fingerprints').fetchone()[0],1);db.close()
 def test_only_known_expired_rows_and_fk_children_removed(self):
  with tempfile.TemporaryDirectory(dir=p.HERE) as directory:
   root=Path(directory);registry=root/'registry.json'
   registry.write_text(json.dumps({'digests':[p.retention30.fingerprint('douyin','expired')]}))
   database=root/'cache.sqlite3';db=sqlite3.connect(database)
   db.executescript('CREATE TABLE results(platform,comment_id,data,PRIMARY KEY(platform,comment_id)); CREATE TABLE result_topics(platform,comment_id,pool,FOREIGN KEY(platform,comment_id) REFERENCES results(platform,comment_id));')
   db.executemany('INSERT INTO results VALUES(?,?,?)',[('douyin','expired','old'),('douyin','fresh','new')]);db.executemany('INSERT INTO result_topics VALUES(?,?,?)',[('douyin','expired','price'),('douyin','fresh','price')]);db.commit();db.close()
   with patch.object(p.retention30,'REGISTRY',registry):result=p.prune_cache(database)
   db=sqlite3.connect(database)
   self.assertEqual(db.execute('SELECT comment_id FROM results').fetchall(),[('fresh',)])
   self.assertEqual(db.execute('SELECT comment_id FROM result_topics').fetchall(),[('fresh',)])
   self.assertEqual(result['removed'],2);self.assertEqual(result['deferred'],[]);db.close()
 def test_shared_cleanup_never_removes_send_indexes_or_unknown(self):
  with tempfile.TemporaryDirectory(dir=p.HERE) as directory:
   root=Path(directory);registry=root/'registry.json';ids=['old','protected','unknown']
   registry.write_text(json.dumps({'digests':[p.retention30.fingerprint('douyin',cid) for cid in ids]}))
   task=root/'task';task.mkdir();(task/'approved-cli-queue.json').write_text(json.dumps({'items':[{'cid':'protected'}]}))
   database=root/'shared.sqlite3';db=sqlite3.connect(database)
   db.executescript('CREATE TABLE leads(platform,customer,comment,status); CREATE TABLE assessments(platform,customer,comment,updated,data); CREATE TABLE reservations(platform,comment,status);')
   db.executemany('INSERT INTO leads VALUES(?,?,?,?)',[('douyin',cid,cid,'unknown' if cid=='unknown' else 'sent') for cid in ids]);db.executemany('INSERT INTO assessments VALUES(?,?,?,?,?)',[('douyin',cid,cid,int(time.time())-1000,'body') for cid in ids]);db.commit();db.close()
   with patch.object(p.retention30,'REGISTRY',registry):result=p.prune_completed_assessments([task],database)
   db=sqlite3.connect(database)
   self.assertEqual(db.execute('SELECT count(*) FROM leads').fetchone()[0],3)
   self.assertEqual({row[0] for row in db.execute('SELECT comment FROM assessments')},{'protected','unknown'})
   self.assertEqual(result['removed_expired_assessment_bodies'],1);db.close()

if __name__=='__main__':unittest.main()
