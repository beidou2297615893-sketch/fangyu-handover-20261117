"""Compare a previously sealed historical model reference to a frozen classifier.

This summarizes disagreement only. It never outputs comment text or claims accuracy.
"""
import hashlib
import json
from collections import Counter, defaultdict
from pathlib import Path

from local_classifier import LocalClassifier

HERE = Path(__file__).resolve().parent
CORE_SHA = '1c3b4bc554e8b58702d507d19ebda663e467c98d7f632c2cf5b54c481926f72e'
CONFIG_SHA = '2c27bdbdb3324d71e2475ad895e14ff5ac89203517990b5c8213d4bd60fb8e79'
FIELDS = ('platform', 'comment_id', 'customer_uid', 'video_id', 'comment_text',
          'published_at_unix', 'published_at', 'post_title', 'post_body',
          'post_author_same_as_commenter', 'direct_parent_text', 'reply_to',
          'source_version_conflict', 'source_observations', 'ip_location_raw',
          'deeper_reply_count_visible')
POSITIVE = {'super_high', 'high', 'medium'}

def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()

def main():
    core, config = HERE / 'local_classifier.py', HERE / 'rule_config.json'
    meta = json.loads((HERE / 'holdout/freeze-metadata.json').read_text(encoding='utf8'))
    sample = HERE / 'holdout/historical-reference.jsonl'
    if (sha(core), sha(config)) != (CORE_SHA, CONFIG_SHA):
        raise SystemExit('Frozen classifier/config SHA mismatch; comparison refused')
    if sha(sample) != meta['sample_sha256']:
        raise SystemExit('Frozen sample SHA mismatch; comparison refused')
    c = LocalClassifier(); summary = Counter(); interest_pairs = Counter()
    samples = defaultdict(list); calls = 0; total = 0
    with sample.open(encoding='utf8') as f:
        for line in f:
            old = json.loads(line); total += 1
            record = {k: old[k] for k in FIELDS if k in old}
            out = c.classify(record); calls += out.get('model_calls', 0)
            reference_id = {'platform': str(old['platform']), 'comment_id': str(old['comment_id'])}
            for field in ('role', 'interest_at_comment', 'topics'):
                oldval, newval = old.get(field), out.get(field)
                if field == 'topics':
                    oldval, newval = sorted(set(oldval or [])), sorted(set(newval or []))
                label = field + ('_equal' if oldval == newval else '_different')
                summary[label] += 1
                if oldval != newval and len(samples[label]) < 5:
                    samples[label].append({**reference_id, 'historical': oldval, 'local': newval})
            oi, ni = old.get('interest_at_comment'), out.get('interest_at_comment')
            interest_pairs[f'{oi} -> {ni}'] += 1
            direction = ('local_positive_old_not' if ni in POSITIVE and oi not in POSITIVE else
                         'old_positive_local_not' if oi in POSITIVE and ni not in POSITIVE else None)
            if direction:
                summary[direction] += 1
                if len(samples[direction]) < 5:
                    samples[direction].append({**reference_id, 'historical': oi, 'local': ni})
            exception = out.get('exception_type')
            bucket = ('semantic_review' if out.get('needs_model_review') else
                      'needs_context' if exception == 'needs_context' else
                      'source_conflict' if exception == 'source_conflict' else
                      'other_exception' if exception else 'locally_determined')
            summary[bucket] += 1
    if total != meta['sample_count'] or (sha(core), sha(config), sha(sample)) != (CORE_SHA, CONFIG_SHA, meta['sample_sha256']):
        raise SystemExit('Count or frozen hashes changed during comparison')
    report = {'reference': 'historical model, not human gold; agreement is not accuracy',
              'sample_count': total, 'core_sha256': CORE_SHA, 'config_sha256': CONFIG_SHA,
              'sample_sha256': meta['sample_sha256'], 'source_sha256': meta['source_sha256'],
              'ordered_id_sha256': meta['ordered_id_sha256'], 'model_calls_reported': calls,
              'positive_definition': ['super_high', 'high', 'medium'],
              'counts': dict(summary), 'interest_pairs': dict(sorted(interest_pairs.items())),
              'representative_disagreements_max_five_per_category': dict(samples)}
    target = HERE / 'acceptance-fix3-holdout-report.json'
    if target.exists():
        raise SystemExit('Report exists; refusing overwrite')
    rendered = json.dumps(report, ensure_ascii=False, indent=2)
    target.write_text(rendered + '\n', encoding='utf8')
    print(rendered)

if __name__ == '__main__':
    main()
