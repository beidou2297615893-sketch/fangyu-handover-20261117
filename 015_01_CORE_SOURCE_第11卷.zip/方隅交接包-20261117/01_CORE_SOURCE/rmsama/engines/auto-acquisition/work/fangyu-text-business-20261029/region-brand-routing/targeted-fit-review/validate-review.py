import pathlib,json,hashlib,collections,datetime
D=pathlib.Path(__file__).resolve().parent
j=json.loads((D/'input.json').read_text(encoding='utf-8-sig'))
rows=[json.loads(s) for s in (D/'reviews.jsonl').read_text(encoding='utf-8').splitlines() if s.strip()]
initial=json.loads((D/'initial-semantic.json').read_text(encoding='utf-8'))
fp=json.loads((D/'source-fingerprints.json').read_text(encoding='utf-8'))
errors=[]
def ck(v,msg):
    if not v:errors.append(msg)
expected='c44b4a65cf9f27f2614ef754e739b695ee90c7f9cc1822bcd2bb66debcb06e91'
ck(hashlib.sha256((D/'input.json').read_bytes()).hexdigest()==expected,'input SHA mismatch')
ck(len(rows)==len(initial)==len(j['records'])==124,'record count mismatch')
keys=lambda r:(r['platform'],r['comment_id'],r['customer_uid'])
ck([keys(r) for r in rows]==[keys(r) for r in j['records']],'IDs or order mismatch')
ck(len(set(keys(r) for r in rows))==124,'duplicate full identity')
ck(len(set((r['platform'],r['comment_id']) for r in rows))==124,'duplicate comment')
required={'platform','comment_id','customer_uid','demand_state','generic_intro_suitable','tone','reason','evidence','needs_review','contact_policy','stages_completed','input_sha256'}
for i,(r,x) in enumerate(zip(j['records'],rows),1):
    ck(required.issubset(x),f'{i}: missing fields')
    ck(x['demand_state'] in ['active_at_comment','ended','future','historical','unknown'],f'{i}: demand state')
    ck(type(x['generic_intro_suitable']) is bool,f'{i}: fit type')
    ck(x['tone'] in ['normal','serious'],f'{i}: tone')
    ck(x['contact_policy'] in ['normal','no_contact','manual_review'],f'{i}: contact policy')
    ck(x['stages_completed']==['initial_semantic','detailed_semantic'],f'{i}: stages')
    ck(x['input_sha256']==expected,f'{i}: input sha attribution')
    ck(bool(x['evidence']) and all(type(q) is str and q and q in r['comment_text'] for q in x['evidence']),f'{i}: evidence not literal comment quote')
    ck(all(len(q)<=60 for q in x['evidence']),f'{i}: evidence longer than short-quote limit')
    ck(bool(x['reason']) and bool(x['needs_review']),f'{i}: no explanation/gap')
    ck(r['post_context_key'] in j['post_contexts'],f'{i}: missing post context')
    ck('role' not in x and 'interest_at_comment' not in x and 'reply_text' not in x,f'{i}: core/reply replacement')
    prior=r['original_AI'].get('reply_plan',{}).get('contact_policy')
    if prior=='no_contact':ck(x['contact_policy']=='no_contact',f'{i}: no_contact relaxed')
    if prior in ['manual_review','manual']:ck(x['contact_policy'] in ['manual_review','no_contact'],f'{i}: manual relaxed')
    if x['demand_state']=='unknown':ck(x['contact_policy']=='manual_review',f'{i}: unknown not manual')
checks={}
for p,v in fp.items():
    q=pathlib.Path(p)
    now=hashlib.sha256(q.read_bytes()).hexdigest()
    checks[p]={'before_sha256':v['sha256'],'after_sha256':now,'unchanged':now==v['sha256']}
    ck(now==v['sha256'],p+': fingerprint changed')
counts={
    'platform':dict(collections.Counter(x['platform'] for x in rows)),
    'demand_state':{s:sum(x['demand_state']==s for x in rows) for s in ['active_at_comment','ended','future','historical','unknown']},
    'generic_intro_suitable':{'true':sum(x['generic_intro_suitable'] for x in rows),'false':sum(not x['generic_intro_suitable'] for x in rows)},
    'tone':dict(collections.Counter(x['tone'] for x in rows)),
    'contact_policy':dict(collections.Counter(x['contact_policy'] for x in rows)),
}
v={'validated_at':datetime.datetime.now().astimezone().isoformat(),'input_sha256':expected,'status':'pass' if not errors else 'fail','errors':errors,'record_count':len(rows),'unique_comment_count':len(set((r['platform'],r['comment_id']) for r in rows)),'ids_and_uids_exact_match':not any(keys(r)!=keys(x) for r,x in zip(j['records'],rows)),'literal_quotes_verified':True,'quote_max_characters':max(len(q) for x in rows for q in x['evidence']),'post_contexts_read':len(j['post_contexts']),'parent_texts_available':sum(bool(r['direct_parent_text']) for r in j['records']),'all_context_keys_resolved':all(r['post_context_key'] in j['post_contexts'] for r in j['records']),'source_fingerprints':checks,'core_role_interest_source_unchanged':True,'source_library_accessed':False,'platform_calls':0,'cli_calls':0,'outbound_sends':0,'new_paid_calls':0,'subagents_spawned':0,'method':'same-model initial_semantic then detailed_semantic; not independent second reviewer or human gold','human_confirmed':False,'send_authorized':False,'usage':{'tokens':'unknown','cost':'unknown'},'counts':counts,'reviews_sha256':hashlib.sha256((D/'reviews.jsonl').read_bytes()).hexdigest(),'stage_changes':[{'record_number':i,'comment_id':b['comment_id'],'initial_demand_state':a['demand_state'],'final_demand_state':b['demand_state']} for i,(a,b) in enumerate(zip(initial,rows),1) if a['demand_state']!=b['demand_state']]}
(D/'validation.json').write_text(json.dumps(v,ensure_ascii=False,indent=2),encoding='utf-8')
assert not errors,errors
report='''# 124条旧记录的需求状态与通用介绍旁注复核

已完成全部124条（抖音102条、小红书22条）的初筛和细筛。两阶段由同一执行模型完成，不是独立二审或人工金标。逐条阅读本人评论、所关联的全部共享帖子内容和原AI判断；输入包没有可用父评正文。原AI提示存在而本包未提供的深层回复，逐条保留未读缺口，没有外查补全。

结果：评论时正在询房113条，明确未来计划或愿望6条，找房时点未知5条；已结束0条、纯历史0条。认可的笼统介绍可作接话122条，暂不适合直接套用2条。普通语气123条，涉及带孩读书的家庭租住计划沿用严肃语气1条。联系处理保留为正常119条、人工核查5条，没有原有限制被解除。正常仅描述语义联系政策，不是发送授权。

暂不直接套用的两条仍保留在输出中：

- “我刚在大江东定了2500的房子”：已定房和仍找房不是同一件事；成交是否完成、新需求是否存在未知。原超高意向需复核，未改原分类。
- “找人沙河合租，要00后长期稳定合租的室友来，尽量来男的”：可能只找室友，也可能一起找房，未确认仍需房源；原需求角色及高意向是否混入招室友或供给属性需复核，未改原分类。

另有三条保留未知但笼统介绍本身可以接话：“准备找仙霞或者伊犁附近的”“我过阵子要租房，所以我去干中介了…”“明年四月租下沙那边的…”。未来租住时间不等于未来才开始找；后两条由初筛的未来状态在细筛改为未知，完整保留两阶段文件。明确明年找房、后面换房和未来租住愿望没有被当成失效，低意向也没有升成高意向。

普通询价、位置、宠物、短租、看房及区域求房可用用户认可的“宝宝，我住方隅公寓这边，介绍有优惠的。”作笼统接话；逐条保留尚未回答的具体问题。没有城市或只有IP不阻止通用接话，不把IP当本人明示目标，不指定门店、不承诺房源事实。严肃语境沿用已标记去亲昵称呼的方式，本次没有逐条重写回复。

只写本复核目录的旁注、两阶段记录与校验文件。输入、读取的两份规则指纹前后一致；未访问平台、平台CLI、原始源库或其他聊天，未发送、未新增付费调用、未派子代理。原分类、母句、指针和源文件未改；即使暂不适合，源母句也未删除。程序只负责绑定ID、复制逐字引文和结构/指纹/计数核验，不按关键词替代AI语义裁决。

输入SHA-256：c44b4a65cf9f27f2614ef754e739b695ee90c7f9cc1822bcd2bb66debcb06e91。124条ID及客户UID与输入顺序完全一致；全部证据均为本人评论逐字短引，全部含初筛和细筛完成标记。技术核验通过不等于语义零误差、客户当前仍有需求或用户已经认可。用量与费用无法取得，均记未知。
'''
(D/'report.md').write_text(report,encoding='utf-8')
print(json.dumps({'status':v['status'],'counts':counts,'quote_max_characters':v['quote_max_characters'],'post_contexts_read':v['post_contexts_read'],'reviews_sha256':v['reviews_sha256'],'stage_changes':v['stage_changes']},ensure_ascii=False))
