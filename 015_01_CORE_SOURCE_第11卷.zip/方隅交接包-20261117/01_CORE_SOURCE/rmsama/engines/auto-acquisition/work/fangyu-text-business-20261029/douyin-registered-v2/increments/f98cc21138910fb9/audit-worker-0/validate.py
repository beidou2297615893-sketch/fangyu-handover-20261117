import json,hashlib,copy,importlib.util,collections,re
from pathlib import Path
worker=Path(__file__).resolve().parent;base=worker.parent;part=base/'recall-audit/part-0';W=base.parents[2]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return [json.loads(s) for s in p.read_text(encoding='utf8').splitlines() if s.strip()]
task=json.loads((part/'task.json').read_text(encoding='utf8'));families=json.loads((base/'local-mother-contract.json').read_text(encoding='utf8'))['families']
primary={};sources=[]
for src in task['primary_sources']:
 p=base/src['path'];actual=sha(p);assert actual==src['sha256'],p
 sources.append(dict(path=src['path'],expected=src['sha256'],actual=actual,passed=True))
 for r in read(p):assert r['review_key'] not in primary;primary[r['review_key']]=r
source={r['review_key']:r for r in read(base/'input.jsonl')}
allowed=set('role demand_state interest topics target_regions time_mentions other_constraints possible_topics evidence reason context_used needs_review contact_boundaries context_flags reply_plan'.split())
rows=[];audits=[];page_checks=[];quotes=0;params=0;local_plan_checks=[]
for p in sorted(part.glob('page-*.json')):
 d=json.loads(p.read_text(encoding='utf8'));comments=[(c,g) for g in d['post_groups'] for c in g['comments']];keys=[c['key'] for c,g in comments];a=read(p.with_suffix('.audit.jsonl'))
 assert [r['review_key'] for r in a]==keys and len(keys)==len(set(keys)),p
 page_checks.append(dict(page=p.name,input_count=len(keys),output_count=len(a),id_order_and_set_equal=True,input_sha256=sha(p),audit_sha256=sha(p.with_suffix('.audit.jsonl'))))
 for (c,g),audit in zip(comments,a):
  k=c['key'];r=copy.deepcopy(primary[k]);s=source[k];assert all(r.get(f)==v for f,v in c['first_semantic_judgment'].items()),k
  assert set(audit)=={'review_key','decision','reason','patch'} and audit['decision'] in ('keep','change') and audit['reason'].strip()
  assert set(audit['patch'])<=allowed and (audit['decision']=='keep')==(audit['patch']=={}),k
  assert r['video_id']==g['video']
  for f in ('comment_id','customer_uid','platform','video_id'):assert r[f]==s[f],(k,f)
  assert c['text']==s['comment_text']
  assert hashlib.sha256(s['comment_text'].encode('utf8')).hexdigest()==s['source_comment_sha256'],k
  r.update(audit['patch']);texts=[c['text']]+([g['post_body']] if c['same_author'] else [])
  def exact(q):return isinstance(q,str) and bool(q) and any(q in t for t in texts)
  for q in r['evidence']:assert exact(q),(k,'evidence',q);quotes+=1
  for field in ('topics','target_regions','time_mentions','other_constraints','possible_topics','contact_boundaries'):
   for x in r[field]:
    if isinstance(x,dict) and 'quote' in x:assert exact(x['quote']),(k,field,x['quote']);quotes+=1
  plan=r['reply_plan'];assert 'local_mother' in plan;kplan=plan['local_mother']
  assert plan['contact_policy'] in ('allow','identity_restricted','no_contact','unknown')
  if kplan is None:
   assert plan['caution'] and audit['reason'];local_plan_checks.append(dict(review_key=k,family=None,reason=audit['reason']))
  else:
   assert kplan['family'] in families;assert set(kplan['fill'])==set(families[kplan['family']]['required_fill'])
   assert set(x['field'] for x in kplan['evidence'])==set(kplan['fill'])
   for e in kplan['evidence']:
    assert exact(e['quote']),(k,'local_mother',e)
    v=kplan['fill'][e['field']];assert isinstance(v,str) and v.strip()
    if e['field']=='requirements':
     fragments=[x.strip() for x in re.split('[；;、]',v) if x.strip()]
     assert all(x in e['quote'] and x in c['text'] for x in fragments),(k,v,e['quote'])
    else:assert v in e['quote'] and v in c['text'],(k,v,e)
    params+=1;quotes+=1
   assert plan['missing_facts'];local_plan_checks.append(dict(review_key=k,family=kplan['family'],fill=kplan['fill'],reason=audit['reason']))
  if 'reply_plan' in audit['patch']:
   assert set(primary[k]['reply_plan'])<=set(plan),k
   assert all(x in plan['missing_facts'] for x in primary[k]['reply_plan']['missing_facts']),(k,'lost','missing_facts')
   if k not in ('D0571','D0681'):assert all(x in plan['caution'] for x in primary[k]['reply_plan']['caution']),(k,'lost','caution')
  assert r['human_confirmed'] is False and r['send_authorized'] is False and r['store_assignment'] is None
  r['classification_method']='ai_independent_semantic_fine_review';r['classification_stages_completed']=['initial_semantic','detailed_semantic','independent_semantic'];r.pop('classification_review_source',None);rows.append(r);audits.append(audit)
assert len(rows)==task['records']==341 and len({r['review_key'] for r in rows})==341
assert {r['review_key'] for r in rows}==set(task['expected_review_keys'])
iso=worker/'isolated-original-plus-patch.jsonl';iso.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows),encoding='utf8');digest=sha(iso)
adapter=W/'mother_adapter.py';adapter_before=sha(adapter);spec=importlib.util.spec_from_file_location('original_mother_adapter',adapter);mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
cache={};validated=[]
for r in rows:
 q=copy.deepcopy(r);q['classification_review_source']={'path':iso.relative_to(base).as_posix(),'sha256':digest};mod.validate_new_review(q,base,cache);validated.append(q)
bound=worker/'isolated-sha-bound-precheck.jsonl';bound.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in validated),encoding='utf8')
assert sha(adapter)==adapter_before
result=dict(part=0,input_count=341,output_count=len(rows),explicit_decisions=len(audits),keep_count=sum(a['decision']=='keep' for a in audits),change_count=sum(a['decision']=='change' for a in audits),page_checks=page_checks,id_set_equal=True,duplicate_keys=0,first_judgments_match_primary=True,primary_sources=sources,source_comment_sha_verified_count=len(rows),literal_quotes_checked=quotes,literal_quotes_passed=True,local_mother_parameter_fields_checked=params,local_mother_contract_passed=True,explicit_local_mother_all_rows=True,reply_plan_patch_preserves_all_original_fields_and_missing_facts=True,intentional_caution_corrections=['D0571','D0681'],local_mother_counts=dict(collections.Counter((r['reply_plan']['local_mother'] or {}).get('family','none') for r in rows)),isolated_jsonl=iso.name,isolated_sha256=digest,bound_jsonl=bound.name,bound_sha256=sha(bound),official_validator='mother_adapter.validate_new_review',official_validation_count=len(validated),official_validation_passed=True,adapter_sha256_before=adapter_before,adapter_sha256_after=sha(adapter),adapter_unmodified=True,primary_sources_unchanged_after=all(sha(base/s['path'])==s['sha256'] for s in task['primary_sources']),credits='existing_authorized',actual_usage='unknown',semantic_resolution_pending={'issue':'日记或住房分享下指定地区主动询房的high与medium统一口径，等待root裁决','recommended_change_keys':['D0801','D0804'],'same_context_original_medium_keys':['D0398','D0401','D0797','D0806'],'not_ready_for_unqualified_merge':True},fee='unknown',platform_calls=0,source_database_access=False,send_authorized=False,human_confirmed=False)
(worker/'local-plan-review.json').write_text(json.dumps(local_plan_checks,ensure_ascii=False,indent=2),encoding='utf8')
(worker/'validation.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps({k:v for k,v in result.items() if k not in ('page_checks','primary_sources')},ensure_ascii=False,indent=2))
