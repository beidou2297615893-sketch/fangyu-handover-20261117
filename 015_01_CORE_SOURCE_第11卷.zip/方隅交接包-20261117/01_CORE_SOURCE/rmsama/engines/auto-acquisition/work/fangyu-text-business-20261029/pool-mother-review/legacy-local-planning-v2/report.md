# 历史本地计划修复第二版

本次只写新目录，原规划、QA、源分类、合同、当前消费、50条用户稿及已发布字节全部保留。未调用模型/API、平台或发送。
全量 12,963 条计划：本地住房家族 4,389 条，最小确认接话 29 条，具体待核 8,545 条。技术覆盖不是准确率或可发送率。

修复按共性执行：预算槽与静态模板去重；保留附近/沿线/半径；需求动作与地点拆槽；相对便宜改家族；问位置不改有无房；现有未决关系改确认问题；明确住宅用途待核且缺正文的个人转租只问对象。不是逐ID补丁。

17条旧QA问题先做难例回归，再扩到全量。200条旧QA用于整改回归，不能称新留出准确率。30条阴性原状态保留；角色证据不足那一例仅留原提醒，未擅重分类。
原QA中14条模板元数据提醒原样保留；全量 307 条有家庭整租/全费用上限模板适用条件提醒。客户条件独立从本人逐字证据提取，原事实缺口数组不倒灌。
241条已发布短计划仅扫描，找到 2 条拟修，详见 published-241-proposed-fixes.jsonl；没有改其字节。

剩余缺口：原有复杂条件/主体/时间/多地关系未决、旧结构证据不足与无合适组合家族仍保留具体hold；本轮不以补覆盖为由重新判意向。确认接话不是关系或住宅已确认；住户身份、推荐资格、门店优惠、当前意向、真实同店房源及许可仍须原流程核实。

本地字段、字面、预算重复、源指纹及原判不变验证通过；新合同/新计划未接消费指针，待主窗口审阅。用量未知。

{
  "candidates": 12963,
  "v1_bound": 4419,
  "v2_bound_including_clarifications": 4418,
  "v2_housing_family_plans": 4389,
  "v2_clarification_only": 29,
  "v2_held": 8545,
  "family_counts": {
    "area": 1055,
    "budget_low_requirements": 6,
    "requirements": 367,
    "commute": 16,
    "price": 1343,
    "location": 584,
    "room_price_location": 165,
    "available": 733,
    "budget_fit": 17,
    "price_location": 86,
    "lease_fixed": 8,
    "budget_low": 2,
    "location_about_place": 6,
    "region_relation_check": 1,
    "area_two_spans": 1,
    "object_clarification": 28
  },
  "plan_or_contract_behavior_changed": 92,
  "newly_held_from_v1_bound": 1,
  "source_metadata_template_caution_records": 307,
  "QA_metadata_all_caution_records_preserved": 24,
  "QA_metadata_14_template_applicability_preserved": 14,
  "old_QA_200_regression": 200,
  "old_QA_17_fixed_or_clarified": 17,
  "published_batch_scanned": 241,
  "published_budget_fit_scanned": 5,
  "published_exact_budget_duplicate_cases": 0,
  "published_batch_proposed_fix_records": 2,
  "published_issue_counts": {
    "spatial_scope_suffix_not_retained": 1,
    "qualitative_price_inside_requirements_needs_family_review": 1
  }
}
