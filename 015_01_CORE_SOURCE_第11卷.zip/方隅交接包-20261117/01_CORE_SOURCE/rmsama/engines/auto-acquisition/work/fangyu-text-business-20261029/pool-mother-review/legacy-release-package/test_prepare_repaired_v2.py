import unittest,copy
import prepare_repaired_v2 as v
class V2Guard(unittest.TestCase):
 def setUp(self):
  self.a={'platform':'douyin','cid':'1','uid':'u','sourceSHA':'s','source_file_sha256':'f','original_classification_sha256':'r','family':'a','fill':{'p':'x'},'contact_policy_original':None,'source_field_evidence':{'contact_policy':None}}
  self.delta={'platform':'douyin','cid':'1','uid':'u','sourceSHA':'s','source_file_sha256':'f','original_classification_sha256':'r','base_ABC_plan_sha256':v.objsha(self.a),'base_v1_applied_plan_sha256':v.objsha(self.a),'v1_family':'a','v1_fill':{'p':'x'},'original_contact_policy':None,'replacement_plan':{'family':'b','fill':{'p':'y'},'evidence':[],'clarification_only':True,'hold_reasons':[],'status':'local_plan_proposed'},'classification_changed':False,'send_authorized':False,'can_send_now':False,'applied':False,'repair_reasons':[],'repair_evidence':[]}
 def test_valid_and_base_preserved(self):
  r=v.apply_v2(self.a,self.a,self.delta);self.assertEqual(r['family'],'b');self.assertEqual(self.a['family'],'a');self.assertTrue(r['clarification_only'])
 def test_reject_mutated_ids_source_baseline_contact_and_flags(self):
  for k,value in [('uid','x'),('sourceSHA','wrong'),('base_ABC_plan_sha256','bad'),('base_v1_applied_plan_sha256','bad'),('original_contact_policy','allow'),('send_authorized',True),('classification_changed',True)]:
   d=copy.deepcopy(self.delta);d[k]=value
   with self.assertRaises(ValueError,msg=k):v.apply_v2(self.a,self.a,d)
if __name__=='__main__':unittest.main()
