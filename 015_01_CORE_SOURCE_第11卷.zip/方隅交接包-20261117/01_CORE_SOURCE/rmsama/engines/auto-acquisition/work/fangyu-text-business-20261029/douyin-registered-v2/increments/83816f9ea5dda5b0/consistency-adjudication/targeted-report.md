# 五条地区询房评论一致性裁决

5条均判为需求者、评论时正在询房、中等兴趣。保留D0754、D2095、D1670的现有语义；D1656、D1833仅修改interest及其解释reason，其余13项语义字段原样保留。模型裁决不是人工金标，不计算准确率；usage未知。

## 判断依据

逐条读过本人原句、共享正文、作者关系、可信发表时点、直接父评及版本冲突。正文是作者现居小屋的生活分享，叙述月租750、套一和猫咪，没有明确在出租；这些条件不转为评论者预算、户型或宠物要求。“新都有吗”“龙泉有吗”足以确认本人当时正在询问指定地区的住房，所以不降为无关、未来才找或状态未知；但已保存文本不足以确定具体可租对象，也没有进一步租住方案或约看动作。

按既定业务分级“主动比较区域、公寓或通勤等，尚无具体房源询盘或下一步安排”落中意向；不能用明确地名直接取代高意向所需的租赁推进证据。可租库存、门店承接能力是独立事实，不把缺少方隅库存作为降级理由，也不等待库存、最低预算或租期资料再完成本裁决。这里判断的是本人已表达的行动，而非方隅能否承接。

五条均非原帖作者、无直接父评、无来源版本冲突；发表时间不同，但本人原文没有相对日期或需求更新，不能依据早晚判更急或已结束。D0754可见1条深层回复、D1833可见4条，其余0条，实际均未读取深层回复；不能从数量推测约看、成交或需求结束。各条依据写在裁决reason，未按多数票或词面规则统一。

同文不同key的topics、condition_scope和事实缺口存在原有表示差异，本次按授权仅处理role/demand_state/interest争议；未争议内容全部保留，不能把它们误报为支持不同意向等级的真实上下文差异。justified_difference均为null。

参考过旧批d13422df281e9e55的模型案例，现居分享下房态短问与明确租赁动作有区分；该案例不是人工金标，本结论直接依据本批原文和既定分级。营销Skill目录已评估，并读过social-selling-planner的适用边界；其B2B互动节奏流程与本次窄范围语义裁决不适配，未引入该运营流程，复用项目已验证契约及原校验器。

## 边界与验证

final_semantics严格含compiler允许的15字段。两条修订只变更interest、reason；其他三条15字段原样保留。所有quote和evidence逐字来自本人评论，五条身份与ID集合一致。原human_confirmed=false、send_authorized=false、store_assignment=null在隔离行完整保留。reply_plan原样保留认可31槽及通用介绍适用性，未新写回复正文；地区与IP、源店未混淆，没有门店分派。

已真实调用原mother_adapter.validate_new_review，5条通过；隔离JSONL绑定实际文件SHA，校验器SHA及输入、primary、裁决SHA见targeted-validation.json。仅为定向裁决隔离预检，未执行正式compiler发布，也不声称最终独立审计已合并。原primary文件前后SHA一致，未改audit、task、gate、publisher或其他目录；无平台、凭据、发送、购买动作。

本次写入：targeted-adjudications.jsonl、targeted-validation.json、targeted-report.md、targeted-isolated-review-source.jsonl、targeted-isolated-precheck.jsonl。后续由协调者叠加到最终独立审计，不重跑全批。
