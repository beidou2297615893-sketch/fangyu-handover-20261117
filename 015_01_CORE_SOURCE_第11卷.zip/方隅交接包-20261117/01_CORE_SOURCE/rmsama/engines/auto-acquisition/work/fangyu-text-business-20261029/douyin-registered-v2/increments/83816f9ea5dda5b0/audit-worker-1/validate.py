import pathlib,json,hashlib,sys,copy,collections,datetime
B=pathlib.Path(__file__).resolve().parent.parent;W=B.parents[2];O=B/'audit-worker-1';P=B/'recall-audit/part-1'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
task=json.loads((P/'task.json').read_text(encoding='utf-8'));primary={};prim=[]
for item in task['primary_sources']:
 p=B/item['path'];digest=sha(p);assert digest==item['sha256'];prim.append({'path':item['path'],'sha256':digest,'task_match':True})
 for line in p.read_text(encoding='utf-8').splitlines():
  r=json.loads(line);primary[r['review_key']]=r
allowed=set('role demand_state interest topics target_regions time_mentions other_constraints possible_topics evidence reason context_used needs_review contact_boundaries context_flags reply_plan'.split())
merged=[];pages=[];quote_errors=[];decisions=[]
for ap in sorted(P.glob('page-*.audit.jsonl')):
 inp=ap.with_name(ap.name.replace('.audit.jsonl','.json'));x=json.loads(inp.read_text(encoding='utf-8'));cs={c['key']:(c,g) for g in x['post_groups'] for c in g['comments']};ars=[json.loads(s) for s in ap.read_text(encoding='utf-8').splitlines() if s.strip()]
 keys=[a['review_key'] for a in ars];assert len(set(keys))==len(keys) and set(keys)==set(cs)
 for a in ars:
  k=a['review_key'];assert a['decision'] in ('keep','change') and a['reason'];assert a['decision']!='keep' or a['patch']=={};assert set(a['patch'])<=allowed
  r=copy.deepcopy(primary[k]);r.update(a['patch']);c,g=cs[k];original=c['text'];bodies=[original]+([g['post_body']] if c['same_author'] else [])
  quoted=[('evidence',v) for v in r.get('evidence',[])]
  for field in ('topics','target_regions','time_mentions','other_constraints','possible_topics','contact_boundaries'):
   for obj in r.get(field,[]):
    if isinstance(obj,dict) and 'quote' in obj:quoted.append((field,obj['quote']))
  for field,q in quoted:
   if q and not any(q in body for body in bodies):quote_errors.append({'review_key':k,'field':field,'quote':q})
  r.pop('classification_review_source',None);r['classification_method']='ai_independent_semantic_fine_review';r['classification_stages_completed']=['initial_semantic','detailed_semantic','independent_semantic'];merged.append(r);decisions.append(a)
 pages.append({'page':inp.name,'records':len(ars),'id_set_equal':True,'audit_sha256':sha(ap),'decisions':dict(collections.Counter(a['decision'] for a in ars))})
assert len({r['review_key'] for r in merged})==len(merged)
iso=O/'isolated-reviewed.jsonl';iso.write_text(''.join(json.dumps(r,ensure_ascii=False,separators=(',',':'))+'\n' for r in merged),encoding='utf-8');digest=sha(iso)
sys.path.insert(0,str(W));import mother_adapter
adapter_path=pathlib.Path(mother_adapter.__file__);adapter_before=sha(adapter_path);cache={};errors=[]
for r in merged:
 bound=copy.deepcopy(r);bound['classification_review_source']={'path':str(iso.relative_to(B)),'sha256':digest}
 try:mother_adapter.validate_new_review(bound,B,cache)
 except Exception as e:errors.append(str(e))
assert sha(adapter_path)==adapter_before
out={'status':'complete' if len(merged)==task['records'] and not errors and not quote_errors else 'in_progress' if not errors and not quote_errors else 'validation_failed','records_reviewed':len(merged),'expected_records':task['records'],'pages':pages,'remaining_pages':[p.name for p in sorted(P.glob('page-*.json')) if not p.with_name(p.stem+'.audit.jsonl').exists()],'decisions':dict(collections.Counter(a['decision'] for a in decisions)),'primary_sources':prim,'all_reviewed_keys_unique':True,'full_task_id_set_equal':set(task['expected_review_keys'])=={r['review_key'] for r in merged},'quote_errors':quote_errors,'isolated_jsonl':str(iso.relative_to(B)),'isolated_sha256':digest,'formal_validate_function':'unchanged mother_adapter.validate_new_review','adapter_sha256':adapter_before,'formal_validate_count':len(merged),'formal_validate_errors':errors,'platform_access':False,'sent':False,'usage':'unknown','timestamp':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(O/'validation.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8');(O/'progress.json').write_text(json.dumps({k:out[k] for k in ('status','records_reviewed','expected_records','remaining_pages','decisions','usage','timestamp')},ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps({k:out[k] for k in ('status','records_reviewed','decisions','quote_errors','formal_validate_errors')},ensure_ascii=False))
