"""Deterministic pool SOP drafts. No platform/network/model client or source writes."""
import json
import re
from pathlib import Path

HERE = Path(__file__).resolve().parent
VERSION = 'pool-sop-mothers-v3-20261101'
POOLS = ['价格预算','位置通勤','户型面积与居住方式','房内设施','宠物','楼层电梯','入住与租期','房源状态','费用合同','看房联系']
CAT = '宝宝，我住方隅公寓这边，能带猫的，我介绍有优惠。'
SUBTAGS = {
 '价格预算':['问价','预算上限','省租金','费用是否包含'],
 '位置通勤':['具体地点','地铁线路','工作地通勤','位置查询'],
 '户型面积与居住方式':['整租','合租','一室一厅等户型','面积','居住人数'],
 '房内设施':['厨房','卫生间','阳台','家电','燃气','隔音'],
 '宠物':['能带猫','狗','多只宠物','不接受宠物'],
 '楼层电梯':['电梯','楼层','低楼层'],
 '入住与租期':['入住时间','短租','长租','租期灵活'],
 '房源状态':['有无空房','是否仍可租','指定条件求房'],
 '费用合同':['水电','押付','中介费','合同限制'],
 '看房联系':['预约看房','联系咨询','联系限制'],
}

SINGLE = {
 '问价':'宝宝，我住方隅公寓，这边价格挺合适的，我介绍有优惠。',
 '预算上限':'宝宝，按你说的预算，可以看看方隅公寓这边，我介绍有优惠。',
 '省租金':'宝宝，我住方隅公寓，这边价格挺合适的，我介绍有优惠。',
 '费用是否包含':'宝宝，可以看看方隅公寓这边，租金和其他费用一起算，我介绍有优惠。',
 '具体地点':'宝宝，你想找的这个位置，可以一起看看方隅公寓，我介绍有优惠。',
 '地铁线路':'宝宝，地铁通勤可以看看方隅公寓这边，我介绍有优惠。',
 '工作地通勤':'宝宝，按你上班的位置，可以一起看看方隅公寓，我介绍有优惠。',
 '位置查询':'宝宝，我住方隅公寓，你想找哪边的呀？我介绍有优惠。',
 '整租':'宝宝，想整租可以看看方隅公寓这边，我介绍有优惠。',
 '合租':'宝宝，想合租可以看看方隅公寓这边，我介绍有优惠。',
 '一室一厅等户型':'宝宝，房型这块可以看看方隅公寓这边，我介绍有优惠。',
 '面积':'宝宝，按你想要的大小，可以看看方隅公寓这边，我介绍有优惠。',
 '居住人数':'宝宝，按你们的人数，可以看看方隅公寓的房型，我介绍有优惠。',
 '厨房':'宝宝，我住方隅公寓，这边做饭挺方便的，我介绍有优惠。',
 '卫生间':'宝宝，卫生间条件也可以一起看看方隅公寓这边，我介绍有优惠。',
 '阳台':'宝宝，想要阳台可以看看方隅公寓这边，我介绍有优惠。',
 '家电':'宝宝，我住方隅公寓，这边设施挺齐全的，我介绍有优惠。',
 '燃气':'宝宝，想找能用燃气的房子，可以看看方隅公寓这边，我介绍有优惠。',
 '隔音':'宝宝，比较在意隔音的话，可以看看方隅公寓这边，我介绍有优惠。',
 '能带猫':CAT,
 '狗':'宝宝，带狗找房可以看看方隅公寓这边，我介绍有优惠。',
 '多只宠物':'宝宝，带着宠物找房可以看看方隅公寓这边，我介绍有优惠。',
 '不接受宠物':'宝宝，介意宠物的话，按这个条件看看方隅公寓，我介绍有优惠。',
 '电梯':'宝宝，想找电梯房可以看看方隅公寓这边，我介绍有优惠。',
 '楼层':'宝宝，挑楼层可以看看方隅公寓这边，我介绍有优惠。',
 '低楼层':'宝宝，想找低楼层可以看看方隅公寓这边，我介绍有优惠。',
 '入住时间':'宝宝，按你说的入住时间，可以看看方隅公寓这边，我介绍有优惠。',
 '短租':'宝宝，我住方隅公寓，这边租期挺灵活的，我介绍有优惠。',
 '长租':'宝宝，长期住可以看看方隅公寓这边，我介绍有优惠。',
 '租期灵活':'宝宝，我住方隅公寓，这边租期挺灵活的，我介绍有优惠。',
 '有无空房':'宝宝，还在找房的话可以看看方隅公寓这边，我介绍有优惠。',
 '是否仍可租':'宝宝，想租的话可以看看方隅公寓这边，我介绍有优惠。',
 '指定条件求房':'宝宝，按你说的条件，可以看看方隅公寓这边，我介绍有优惠。',
 '水电':'宝宝，方隅公寓这边可以把水电和租金一起看看，我介绍有优惠。',
 '押付':'宝宝，押付方式也可以一起看看方隅公寓这边，我介绍有优惠。',
 '中介费':'宝宝，在意中介费的话，把总费用一起看看，方隅公寓我介绍有优惠。',
 '合同限制':'宝宝，按你的合同要求，可以一起看看方隅公寓这边，我介绍有优惠。',
 '预约看房':'宝宝，可以看看方隅公寓这边，我介绍有优惠，方便的话约着看。',
 '联系咨询':'宝宝，我住方隅公寓，有想了解的可以聊聊，我介绍有优惠。',
 '联系限制':'宝宝，按你方便的方式聊就好，方隅公寓我介绍有优惠。',
}
DEFAULTS={p:tags[0] for p,tags in SUBTAGS.items()}
DEFAULTS['看房联系']='联系咨询'
DEFAULTS['宠物']='多只宠物'

# Explicit interoperability with classifier labels; aliases mean the same thing.
# Qualification and service/environment tags are NOT aliases for room count,
# kitchens, household appliances, or pet permissions.
ALIASES={'预算':'预算上限','地点':'具体地点','通勤':'工作地通勤','户型':'一室一厅等户型',
         '空房查询':'有无空房','仍可租':'是否仍可租','明确求租或兴趣':'指定条件求房',
         '省略问价':'问价','猫':'能带猫'}
NEW_TEMPLATES={
 '人数与居住资格':('户型面积与居住方式','宝宝，按你说的入住条件，可以看看方隅公寓这边，我介绍有优惠。'),
 '停车充电配套':('房内设施','宝宝，有停车充电需求可以一起看看方隅公寓这边，我介绍有优惠。'),
 '环境与安全':('房内设施','宝宝，在意居住环境的话，可以实地看看方隅公寓这边，我介绍有优惠。'),
 '管家服务':('房内设施','宝宝，管家服务这块可以了解下方隅公寓，我介绍有优惠。'),
 '合同与资格':('费用合同','宝宝，申请资格和合同条件，可以一起了解下方隅公寓，我介绍有优惠。'),
 '宠物':('宠物','宝宝，带宠物找房可以看看方隅公寓这边，我介绍有优惠。'),
 '申请咨询':('看房联系','宝宝，申请条件可以了解下方隅公寓这边，我介绍有优惠。'),
 '公寓名称':('位置通勤','宝宝，我住的是方隅公寓，我介绍有优惠。'),
 '找房渠道':('看房联系','宝宝，找房也可以看看方隅公寓，我介绍有优惠。'),
}
for _label,(_pool,_text) in NEW_TEMPLATES.items():
 SUBTAGS[_pool].append(_label);SINGLE[_label]=_text
POOL_GENERIC={
 '价格预算':'宝宝，价格这块可以看看方隅公寓，我介绍有优惠。',
 '位置通勤':'宝宝，位置和通勤可以一起看看方隅公寓，我介绍有优惠。',
 '户型面积与居住方式':'宝宝，按你的居住需求，可以看看方隅公寓的房型，我介绍有优惠。',
 '房内设施':'宝宝，你关心的配套可以一起看看方隅公寓，我介绍有优惠。',
 '宠物':'宝宝，宠物需求可以一起看看方隅公寓，我介绍有优惠。',
 '楼层电梯':'宝宝，按你的楼层要求，可以看看方隅公寓，我介绍有优惠。',
 '入住与租期':'宝宝，入住和租期可以一起看看方隅公寓，我介绍有优惠。',
 '房源状态':'宝宝，还在找房的话可以看看方隅公寓，我介绍有优惠。',
 '费用合同':'宝宝，费用和合同可以一起看看方隅公寓，我介绍有优惠。',
 '看房联系':'宝宝，想了解方隅公寓的话可以聊聊，我介绍有优惠。',
}
REGISTRY_PATH=HERE.parent/'classifier/rules.json'
CLASSIFIER_REGISTRY=json.loads(REGISTRY_PATH.read_text(encoding='utf-8-sig')) if REGISTRY_PATH.exists() else {'rules':[]}
TAG_ROUTES={x['subtag']:dict(pool=x['pool'],target=ALIASES.get(x['subtag'],x['subtag']),
                           mode='explicit' if ALIASES.get(x['subtag'],x['subtag']) in SINGLE else 'pool_generic')
            for x in CLASSIFIER_REGISTRY['rules']}

def _unique(xs): return list(dict.fromkeys(x for x in xs if x))
def _texts(row):
 return row.get('comment_text') or row.get('text') or row.get('comment') or ''

def _base(row):
 c=row.get('classification') or row.get('local_subtag_sidecar') or {}
 pools=row.get('pools') or row.get('demand_pools') or row.get('original_pools') or c.get('original_pools') or []
 pools=[x.get('pool') if isinstance(x,dict) else x for x in pools]
 pools=[p for p in pools if p in POOLS]
 tags=row.get('subtags') or c.get('subtags') or []
 tags=[x.get('subtag') if isinstance(x,dict) else x for x in tags]
 if not tags: tags=[x.get('subtag') for x in c.get('evidence',[]) if isinstance(x,dict)]
 return c,_unique(pools),_unique([ALIASES.get(t,t) for t in tags if ALIASES.get(t,t) in SINGLE])

def _literal_details(t):
 patterns={
  'budget':r'(?:预算\s*|不超过\s*)[一二两三四五六七八九十百千万\d.kK]+(?:元|块|左右|以内|以下)?|\d+(?:\.\d+)?[kK](?:左右|以内|以下)?|\d+(?:元|块)(?:左右|以内|以下)?',
  'layout':r'[一二两三四1234](?:室(?:[一二两三四1234]厅)?|居室)|套[一二三123]|单间|独卫|整租|合租',
  'time':r'(?:[一二三四五六七八九十\d]+月(?:初|底|[一二三四五六七八九十\d]+[日号])?|[下本这]个?月(?:初|底)?|月底|月初|明天|后天)|[一二两三四五六七八九十半\d]+(?:个?月|天|周|年)',
  'location':r'[\u4e00-\u9fff\d]{1,10}(?:区|地铁站|号线|环内|环外|路|街|附近|周边)(?:附近)?',
 }
 result={k:_unique(m.group() for m in re.finditer(p,t)) for k,p in patterns.items()}
 # A search/discussion duration is not a requested lease duration.
 result['time']=[x for x in result['time'] if not re.search(r'(?:找|看|说|问|聊|等|折腾|研究)(?:房子|房|了|过|着|来|去|这么|那么|都|已经|整整|足足|大概|快|有|\s)*'+re.escape(x),t)]
 result['location']=[re.sub(r'^(?:求租|我在|想找|想租|有没有|还有|距离|靠近|离|有)','',x) for x in result['location']]
 result['location']=[x for x in result['location'] if x not in ('小区','社区','附近','周边') and not re.search(r'有没有|有无|便宜|多少|哪里|那边|这边|什么',x)]
 # Keep a named subarea attached to its district; reject ordinary question text
 # after a 区 suffix instead of treating it as a second geographical name.
 for district,area in re.findall(r'([\u4e00-\u9fff]{2,6}区)([\u4e00-\u9fff]{2,6}?)(?=那边|附近|有没有|有无|有吗|有嘛|$)',t):
  if re.search(r'有|吗|嘛|便宜|什么|多少|房|小区',area):continue
  result['location']=[x for x in result['location'] if x!=district]+[district+area]
 # Preserve alternatives as alternatives, without manufacturing two offerings.
 pair=re.search(r'([\u4e00-\u9fff]{2,6})(?:或者|或)([\u4e00-\u9fff]{2,6}?)(?=有|附近|区|$)',t)
 if pair and not any(x in pair.group() for x in ('合租','整租','水电','商业','民水')):
  result['location']=[pair.group(1)+'或'+pair.group(2)]+[x for x in result['location'] if pair.group(1) not in x and pair.group(2) not in x]
 return result

def _feature_requirements(t,pools):
 items=[]
 for pool,words in {
  '房内设施':['独卫','厨房','做饭','卫生间','阳台','家电','燃气','隔音','停车','充电','管家','保洁','维修','甲醛','潮湿','发霉'],
  '楼层电梯':['低楼层','电梯','楼层'],
  '费用合同':['民水民电','商业用电','水电','中介费','押一付一','押一付三','合同'],
  '看房联系':['看房'],
 }.items():
  if pool not in pools:continue
  for word in words:
   if word not in t:continue
   prefix='不要' if re.search(r'(?:不要|不用|不需要|不接受)(?:.{0,2})'+word,t) else ''
   items.append(prefix+word)
 if '宠物' in pools:
  for pet in ['猫','狗']:
   if pet not in t:continue
   if re.search(r'不(?:养|带|要|接受).{0,2}'+pet,t):items.append('不带'+pet)
   elif re.search(r'不能养'+pet+'吗|不让养'+pet+'吗',t):items.append(pet+'政策')
   else:
    count=re.search(r'[一二两三四五六七八九十\d]+只'+pet,t)
    items.append('带'+(count.group() if count else pet))
 return _unique(items)

def _negative_requirements(row,t,c):
 """Keep scoped explicit exclusions; 有没有 is never an exclusion by itself."""
 tokens=r'高楼层|低楼层|高层|低层|合租|整租|厨房|做饭|电梯|燃气|天然气|阳台|独卫|猫|狗|宠物|中介'
 found=[m.group() for m in re.finditer(r'(?:不要|不需要|不接受|不考虑|不养|不带|不能)(?:.{0,2})?(?:'+tokens+r')|不合租',t)]
 evidence=list(row.get('evidence') or c.get('evidence') or [])
 evidence+=list((row.get('constraints') or {}).get('negative_spans') or [])
 for e in evidence:
  if not isinstance(e,dict) or e.get('polarity') not in ('excluded','negative','negative_question'):continue
  quote=e.get('quote') or e.get('text') or ''
  # Trust scope only if the actual comment supplies a genuine negative marker.
  # This protects against the upstream historical 有没有→excluded bug.
  if re.search(r'不要|不需要|不接受|不考虑|不养|不带|不能|不合租',quote) and quote in t:found.append(quote)
 return _unique(found)

def render(row):
 """Pool-specific generic draft, even when exact property facts are absent.

 Keeps all raw requirements in requested_details. Returning a draft never says
 the requested rent/location/availability is offered, nor authorizes sending.
 """
 t=_texts(row); c,pools,tags=_base(row)
 pools=_unique(pools)
 if not pools:
  return dict(draft_text=None,template_id='unclassified',status='needs_semantic_pool',unanswered_details=[t],fact_checks=[],send_authorized=False,version=VERSION)
 details=_literal_details(t)
 negative_cat=bool(re.search(r'不(?:养|带|要|接受).{0,2}猫|没(?:有)?猫|不能养猫',t)) and not re.search(r'能不能|可不可以',t)
 cat_ambiguous=bool(re.search(r'不能养猫吗|不让养猫吗',t))
 exclusions=_negative_requirements(row,t,c)
 if re.search(r'不(?:要|想|能|接受|考虑)?合租|不能合租',t):exclusions.append('不合租')
 if negative_cat:exclusions.append('不带猫' if not cat_ambiguous else '猫政策反问待核')
 relation='alternative' if re.search(r'或者|还是|要么',t) else 'conjunction'
 # Prefer a literal condition lead-in to invented claims about our inventory.
 lead=[]
 if details['budget']:lead.append('、'.join(details['budget']))
 if details['location']:lead.append('、'.join(details['location']))
 if details['time'] and '入住与租期' in pools:lead.append('、'.join(details['time']))
 if exclusions:lead+=exclusions
 layout=details['layout']
 if '不合租' in exclusions:layout=[x for x in layout if x!='合租']
 if relation=='alternative' and '合租' in layout and '整租' in layout:
  lead.append('合租还是整租')
 else:lead+=layout
 # Concrete nonnumeric needs must not disappear just because budget/date created
 # the lead-in first. These phrases describe the customer's requirements only.
 features=_feature_requirements(t,pools)
 features=[x for x in features if not any(x.removeprefix('不要') in neg for neg in exclusions)]
 lead+=features
 if '价格预算' in pools and not details['budget']:lead.append('价格')
 if '位置通勤' in pools and not details['location']:lead.append('你说的位置')
 if '入住与租期' in pools and not details['time']:lead.append('租期')
 if '户型面积与居住方式' in pools and not layout:lead.append('房型')
 if '房内设施' in pools and not any(x in t for x in ['独卫','厨房','做饭','卫生间','阳台','家电','燃气','隔音','停车','充电','管家','保洁','维修','甲醛','潮湿','发霉']):lead.append('房内设施')
 if '楼层电梯' in pools and not any(x in t for x in ['电梯','楼层']):lead.append('楼层')
 lead=_unique(lead)
 primary=[p for p in pools if p!='房源状态'] or ['房源状态']
 cat_only=primary==['宠物'] and '猫' in t and not re.search(r'狗|[两二三四五六七八九十\d]+只|多只',t) and not negative_cat
 if cat_only:
  body=CAT; route='cat_exact_approved'
 elif lead and (len(primary)>1 or any(details.values()) or exclusions or len(features)>1):
  # All quoted customer dates/budgets are request context, never availability.
  condition='、'.join(lead)
  if details['budget']:
   budget='、'.join(details['budget'])
   remaining=[x for x in lead if x!=budget and x!='价格']
   needs=('、'.join(remaining)+'找房，') if remaining else ''
   body=f'宝宝，{budget}的话，{needs}可以看看方隅公寓这边，我介绍有优惠。'
   route_style='budget_context'
  elif details['location']:
   place='、'.join(details['location'])
   remaining=[x for x in lead if x!=place]
   needs=('、'.join(remaining)+'也一起看，') if remaining else ''
   body=f'宝宝，找{place}的话，{needs}可以看看方隅公寓这边，我介绍有优惠。'
   route_style='location_context'
  elif details['time']:
   when='、'.join(details['time'])
   remaining=[x for x in lead if x!=when and x!='租期']
   needs=('、'.join(remaining)+'也可以一起看，') if remaining else ''
   # An unanchored old month must not become a promise of future availability.
   if re.search(r'月初|月底|\d+月|[一二三四五六七八九十]+月',when) and not re.fullmatch(r'[一二两三四五六七八九十\d]+个月',when):
    body=f'宝宝，你提到{when}，{needs}找房也可以看看方隅公寓这边，我介绍有优惠。'
   else:
    body=f'宝宝，租{when}的话，{needs}可以看看方隅公寓这边，我介绍有优惠。'
   route_style='term_context'
  elif layout:
   request='、'.join(x for x in lead if x!='价格')
   price='价格也一起比比，' if '价格预算' in primary else ''
   body=f'宝宝，{request}可以看看方隅公寓这边，{price}我介绍有优惠。'
   route_style='layout_context'
  else:
   body=f'宝宝，{condition}可以一起看看方隅公寓这边，我介绍有优惠。'
   route_style='combined_context'
  if relation=='alternative' and '合租还是整租' in condition:
   body='宝宝，整租还是合租可以按你的打算选，方隅公寓这边也可以看看，我介绍有优惠。'
  route=route_style+':'+','.join(primary)
 elif len(primary)==1:
  p=primary[0]; available=[x for x in tags if x in SUBTAGS[p]]
  if p=='宠物' and '猫' not in t:available=[x for x in available if x!='能带猫']
  if p=='入住与租期' and not details['time'] and re.search(r'几个月|月租|短租|租期|租多久',t):available=['租期灵活']
  if p=='户型面积与居住方式' and '合租' in t and '整租' in t:
   body='宝宝，整租还是合租可以按你的打算选，方隅公寓这边也可以看看，我介绍有优惠。';route='housing_type_question'
  else:
   if available:
    label=available[0];body=SINGLE[label];route='subtag:'+label
   else:
    body=POOL_GENERIC[p];route='pool_generic:'+p
 elif set(primary)=={'看房联系','房源状态'}:
  body=SINGLE['预约看房'];route='viewing_available'
 else:
  names={'价格预算':'预算','位置通勤':'位置','户型面积与居住方式':'房型','房内设施':'设施','宠物':'宠物需求','楼层电梯':'楼层电梯','入住与租期':'入住和租期','房源状态':'房源','费用合同':'费用','看房联系':'看房'}
  needs='、'.join(names[p] for p in primary)
  body=f'宝宝，{needs}可以一起看看方隅公寓这边，我介绍有优惠。';route='multi_pool:'+','.join(primary)
 # Common combinations use their own concise SOP rather than a list of pools.
 if lead in ([],['价格']) and set(primary)=={'价格预算','看房联系'} and not re.search(r'勿扰|不要|别联系|别私信',t):
  body='宝宝，我住方隅公寓，这边价格挺合适的，有想了解的可以聊聊，我介绍有优惠。'
  route='price_contact_sop'
 if primary==['费用合同'] and set(tags)<= {'水电'} and re.search(r'民水民电',t) and re.search(r'商业用电|商水商电',t):
  body='宝宝，方隅公寓这边水电怎么计费也可以一起了解，我介绍有优惠。'
  route='utility_type_question_sop'
 # Respect serious context without changing factual scope.
 if row.get('tone')=='serious' or row.get('serious_context') is True:body=body.removeprefix('宝宝，')
 facts=['介绍优惠的账号资格、适用范围与时效']
 if '我住' in body:facts.append('实际发送账号的住户身份')
 if '能带猫' in body:facts.append('适用房源猫政策')
 if '价格挺合适' in body:facts.append('价格评价需有可对应的真实依据')
 if '租期挺灵活' in body:facts.append('适用租期政策')
 if '做饭挺方便' in body:facts.append('适用房源做饭条件')
 if '设施挺齐全' in body:facts.append('适用房源设施')
 unresolved=[]
 if re.search(r'多少钱|多少米|什么价|房租多少|最便宜|价格',t):unresolved.append('具体报价未在通用SOP中承诺')
 if '位置通勤' in pools:unresolved.append('目标地点保留，不承诺就在目标地点或具体通勤距离')
 if re.search(r'多远|距离|几分钟',t):unresolved.append('具体距离另核，不能把靠近线路当成已回答距离')
 if '房源状态' in pools:unresolved.append('库存与即时可租状态未作承诺')
 if '费用合同' in pools:unresolved.append('具体费用或合同事实另核；AI不能补造')
 if cat_ambiguous:unresolved.append('猫政策反问先按已有上下文核对，不反向肯定')
 contact_hold=bool(re.search(r'中介勿扰|不要私信|别私信|不要联系|别联系',t))
 return dict(draft_text=body,template_id=route,status='generic_pool_pitch',pools=pools,subtags=tags,
             requested_details=dict(raw_comment=t,literals=details,exclusions=exclusions,relation=relation),
             unanswered_details=unresolved,fact_checks=facts,contact_hold=contact_hold,
             send_authorized=False,production_send_ready=False,version=VERSION,
             reply_generation_model_calls=0,reason='未知具体事实不阻止池专用通用草稿；客户条件不是已验证房源事实')

if __name__=='__main__':
 import argparse
 parser=argparse.ArgumentParser();parser.add_argument('--input',type=Path,required=True);parser.add_argument('--output',type=Path,required=True);args=parser.parse_args()
 with args.input.open(encoding='utf-8-sig') as src,args.output.open('w',encoding='utf-8') as dst:
  for line in src:
   if line.strip():
    r=json.loads(line);dst.write(json.dumps(dict(platform=r.get('platform'),comment_id=r.get('comment_id'),comment_text=_texts(r),reply=render(r)),ensure_ascii=False)+'\n')
