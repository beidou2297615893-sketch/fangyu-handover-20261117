"""Assemble explicit model outputs; no new semantic judgments or reply rewriting."""
import json,copy,hashlib,pathlib,importlib.util
B=pathlib.Path(__file__).resolve().parent;W=B.parent.parent.parent;D=B/'region-inquiry-adjudication';O=B/'targeted-audit-assembly';O.mkdir(exist_ok=True)
def load(p):return json.loads(p.read_text(encoding='utf-8'))
def rows(p):return [json.loads(l) for l in p.read_text(encoding='utf-8').splitlines() if l.strip()]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def jl(p,rr):p.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rr),encoding='utf-8')
def unique(values):
 out=[]
 for v in values:
  if v not in out:out.append(v)
 return out
v=load(D/'validation.json');assert v['status']=='passed' and v['official_validation_count']==12 and v['official_validation_passed'] and v['adjudications_sha256']==sha(D/'adjudications.jsonl')
assert sha(D/'validation.json')=='da9d2f2a340d00faff87b999687bf7e0eba13bb5660702356f86da69ab72b925'
primary={r['review_key']:r for i in range(3) for r in rows(B/f'reviewed-new-{i}.jsonl')};source={r['review_key']:r for r in rows(B/'input.jsonl')}
cases={a['review_key']:a for a in rows(D/'adjudications.jsonl')};expected={r['review_key'] for r in load(B/'semantic-region-inquiry-adjudication-required.json')['records']};assert set(cases)==expected and len(cases)==12
base_root=B/'preserved-formal-independent-audits-before-adjudication';base_manifest=load(base_root/'manifest.json');assert len(base_manifest['files'])==6
for item in base_manifest['files']:assert sha(B/item['backup'])==item['sha256']
base_audits={r['review_key']:r for item in base_manifest['files'] for r in rows(B/item['backup'])};assert len(base_audits)==682 and expected<=set(base_audits)
assembled=copy.deepcopy(base_audits);case_checks=[]
for k,a in cases.items():
 raw=primary[k];s=source[k];original=base_audits[k];final=copy.deepcopy(raw);final.update(copy.deepcopy(original['patch']));before_plan=copy.deepcopy(final['reply_plan'])
 assert sha(B/a['baseline']['path'])==a['baseline']['sha256'];assert a['baseline']['kind']=='primary_before_independent_audit'
 assert a['decision'] in ('retain_current','revise_current');fields=a['override_fields']
 if a['decision']=='retain_current':assert fields==[]
 for field in fields:
  assert field in ('interest','topics','possible_topics','reason','needs_review')
  if field=='needs_review':final[field]=unique(final[field]+a['final_semantics'][field])
  elif k=='D0183' and field=='topics':final[field]=[t for t in final[field] if t['pool']!='房源状态']
  elif field=='possible_topics':final[field]=unique(final[field]+a['final_semantics'][field])
  else:final[field]=copy.deepcopy(a['final_semantics'][field])
 assert final['reply_plan']==before_plan and final['reply_plan']['local_mother']==raw['reply_plan']['local_mother']
 assert final['role']=='demand' and final['demand_state']=='active_at_comment' and final['interest']=='medium'
 if k=='D0183':assert all(t['pool']!='房源状态' for t in final['topics']) and final['possible_topics']
 patch={field:copy.deepcopy(final[field]) for field in final if final[field]!=raw[field]}
 new={'review_key':k,'decision':'change' if patch else 'keep','reason':a['reason'] if a['decision']=='revise_current' else original['reason'],'patch':patch,'assembly_provenance':{'original_independent_decision':original,'original_formal_audit_preservation_manifest':str(base_root/'manifest.json'),'original_formal_audit_preservation_manifest_sha256':sha(base_root/'manifest.json'),'targeted_adjudication_file':str(D/'adjudications.jsonl'),'targeted_adjudication_sha256':sha(D/'adjudications.jsonl'),'targeted_validation_file':str(D/'validation.json'),'targeted_validation_sha256':sha(D/'validation.json'),'override_fields_applied':fields,'not_additional_unique_coverage':True}}
 assembled[k]=new;case_checks.append({'review_key':k,'final_interest':final['interest'],'role_state_and_reply_plan_preserved':True,'override_fields':fields})
# Revalidate every assembled independent result using an actual persisted source.
sem=[]
for k,decision in assembled.items():
 r=copy.deepcopy(primary[k]);r.update(copy.deepcopy(decision['patch']));r['classification_method']='ai_independent_semantic_fine_review';r['classification_stages_completed']=['initial_semantic','detailed_semantic','independent_semantic'];sem.append(r)
isolation=O/'isolated-assembled-review.jsonl';jl(isolation,sem);digest=sha(isolation)
spec=importlib.util.spec_from_file_location('locked_adapter_assembly',W/'mother_adapter.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);cache={}
for r in sem:
 bound=copy.deepcopy(r);bound['classification_review_source']={'path':str(isolation),'sha256':digest};m.validate_new_review(bound,B,cache)
outputs=[]
for part in (0,1):
 task=load(B/f'recall-audit/part-{part}/task.json');seen=[]
 for page in range(task['pages']):
  p=B/f'recall-audit/part-{part}/page-{page:02}.json';expected_page=[c['key'] for g in load(p)['post_groups'] for c in g['comments']];out=B/f'recall-audit/part-{part}/page-{page:02}.audit.jsonl';data=[assembled[k] for k in expected_page];jl(out,data);seen+=expected_page;outputs.append({'path':str(out.relative_to(B)),'sha256':sha(out),'count':len(data)})
 assert len(seen)==task['records']==341 and set(seen)==set(task['expected_review_keys'])
receipt={'all_passed':True,'independent_audit_records':682,'targeted_adjudication_records':12,'overlap':12,'additional_unique':0,'unique_independent_coverage':682,'case_checks':case_checks,'original_audit_bytes_preserved':True,'original_formal_audit_manifest_sha256':sha(base_root/'manifest.json'),'adjudication_sha256':sha(D/'adjudications.jsonl'),'adjudication_validation_sha256':sha(D/'validation.json'),'real_isolation_file':str(isolation),'real_isolation_sha256':digest,'original_validator_passed':682,'output_page_files':outputs,'no_model_semantic_recomputation':True,'reply_body_model_rewrites':0,'platform_calls':0,'send_authorized':False}
(O/'validation.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps({k:receipt[k] for k in ('all_passed','independent_audit_records','targeted_adjudication_records','unique_independent_coverage','original_validator_passed')},ensure_ascii=False))
