"""Select 50 genuine precomputed replies for batch tone review, without rewriting."""
from pathlib import Path
import json,hashlib,re,csv,datetime,collections
D=Path(__file__).resolve().parent;W=D.parent;ROOT=W.parents[1]
OUT=ROOT/'outputs/方隅双平台文本业务/地区归类与品牌母句'
cur=json.loads((D/'current.json').read_text(encoding='utf-8'))
names={'douyin':'抖音','xiaohongshu':'小红书'}
pools=['价格预算','位置通勤','户型面积与居住方式','房内设施','宠物','楼层电梯','入住与租期','房源状态','费用合同','看房联系']
def topiclist(r):
    c=r['source_record'].get('classification',r['source_record'])
    raw=c.get('actual_pools') or c.get('topics') or []
    return [x if isinstance(x,str) else x.get('pool',x.get('name','')) for x in raw]
def clean(x):return str(x or '').replace('|','\\|').replace('\r','').replace('\n','<br>')
selected={}; receipts=[]
lines=['# 首批50条真实评论与已配回复','',
       '抖音25条、小红书25条，按不同需求场景挑选，供你一次审口气。评论和回复均来自当前已保存的结果，没有为了展示临时改写。','',
       '本批实际使用的是已认可基础母句，统一称“方隅公寓”。问价、宠物、地点等具体问题仍保留在需求记录中；这里的介绍不冒充具体房源答案。','']
for p,label in names.items():
    src=Path(cur['results'][p]);blob=src.read_bytes();assert hashlib.sha256(blob).hexdigest()==cur['result_sha256'].get(p,cur['result_sha256'].get(src.name))
    rs=[json.loads(l) for l in blob.decode('utf-8').splitlines() if l]
    candidates=[r for r in rs if r.get('mother_reply_text') and r['interest_at_comment'] in ('high','super_high','medium') and 3<=len(r['comment_text'])<=130 and not re.search(r'(?<!\d)1[3-9]\d{9}(?!\d)',r['comment_text'])]
    candidates.sort(key=lambda r:(str(r['published_at'] or ''),r['comment_id']),reverse=True)
    chosen=[];seen=set()
    def take(r):
        k=r['customer_uid']
        if k in seen or len(chosen)>=25:return False
        chosen.append(r);seen.add(k);return True
    for topic in pools:
        for r in [r for r in candidates if topic in topiclist(r)][:12]:
            if take(r):break
    for r in candidates:
        if len(topiclist(r))>=2:take(r)
        if len(chosen)>=20:break
    for r in candidates:
        take(r)
        if len(chosen)==25:break
    assert len(chosen)==25 and len({r['customer_uid'] for r in chosen})==25
    selected[p]=chosen
    lines += ['## '+label+'：25条','', '| 客户原评论 | 已判需求池 | 已配回复 |','|---|---|---|']
    for r in chosen:
        topics='、'.join(topiclist(r)) or '需求待细分'
        lines.append('| '+clean(r['comment_text'])+' | '+clean(topics)+' | '+clean(r['mother_reply_text'])+' |')
        receipts.append({'platform':p,'comment_id':r['comment_id'],'customer_uid':r['customer_uid'],'reply_sha256':hashlib.sha256(r['mother_reply_text'].encode('utf-8')).hexdigest(),'comment_sha256':hashlib.sha256(r['comment_text'].encode('utf-8')).hexdigest(),'topics':topiclist(r)})
    lines.append('')
OUT.mkdir(parents=True,exist_ok=True)
f=OUT/'首批50条真实评论与已配回复.md';f.write_text('\n'.join(lines),encoding='utf-8')
with (OUT/'首批50条真实评论与已配回复.csv').open('w',encoding='utf-8-sig',newline='') as h:
    w=csv.writer(h);w.writerow(['平台','客户原评论','需求池','已配回复'])
    for p,rr in selected.items():
        for r in rr:w.writerow([names[p],r['comment_text'],'、'.join(topiclist(r)),r['mother_reply_text']])
record={'platform_counts':{p:len(rr) for p,rr in selected.items()},'selection_method':'scene_coverage_then_recent_multi_pool_comments_not_random_holdout','source_pointer_sha256':hashlib.sha256((D/'current.json').read_bytes()).hexdigest(),'source_result_sha256':cur['result_sha256'],'selected':receipts,'shown_replies_equal_saved_replies':True,'reply_rewrites':0,'actual_sends':0,'report_sha256':hashlib.sha256(f.read_bytes()).hexdigest()}
(D/'reply-example-selection-receipt.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'file':str(f),'sample':[{'platform':names[p],'comment':r['comment_text'],'reply':r['mother_reply_text']} for p,rr in selected.items() for r in rr[:4]],'total':len(receipts)},ensure_ascii=False))
