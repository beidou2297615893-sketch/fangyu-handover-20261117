"""Read-only fixed-scope re-review; never imports or invokes the production publisher."""
import copy
import hashlib
import importlib.util
import json
from collections import Counter
from pathlib import Path

HERE=Path(__file__).resolve().parent
W=HERE.parent
B=W/'douyin-registered-v2/increments/097511857b51e174'
def read(p):return [json.loads(l) for l in p.read_text(encoding='utf8').splitlines() if l.strip()]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
receipt=json.loads((B/'semantic-compile-receipt.json').read_text(encoding='utf8'))
frozen=json.loads((HERE/'fix-wave-shas.json').read_text(encoding='utf8'))
prior=json.loads((HERE/'review-shas.json').read_text(encoding='utf8'))
checks={'fixed_code_shas_match':all(sha(W/n)==v for n,v in frozen.items()),'backup_matches_original_review':all(sha(HERE/'fix-wave-before'/n)==v for n,v in prior.items()),'all_original_source_hashes_match_receipt':all(sha(B/n)==v for n,v in receipt['original_review_file_versions'].items())}
semantic=read(B/'semantic-final.jsonl'); inputs=read(B/'input.jsonl')
source={r['review_key']:r for r in inputs}; final={r['review_key']:r for r in semantic}
reviews=sum((read(B/f'reviewed-{i}.jsonl') for i in range(3)),[])
checks.update(semantic_sha_matches=sha(B/'semantic-final.jsonl')=='4e737d0445d195da6b3bd6449f39f98712e89a40282de4c648d98f4e845e8c48',complete_unique_input_and_final=len(source)==len(final)==len(inputs)==len(semantic)==5806 and set(source)==set(final),complete_unique_transport=len(reviews)==len({r['review_key'] for r in reviews})==len({r['comment_id'] for r in reviews})==5806 and {r['review_key'] for r in reviews}==set(source))
manifest=json.loads((B/'manifest.json').read_text(encoding='utf8'))
raw=(B/'input.jsonl').read_bytes()
checks['frozen_input_sha_matches']=hashlib.sha256(raw).hexdigest()==manifest['input_sha256'] or hashlib.sha256(raw.replace(b'\r\n',b'\n')).hexdigest()==manifest['input_sha256']
checks['prior_12409_sha_matches']=sha(Path(manifest['prior_result_file']))==manifest['prior_result_sha256'] and len(read(Path(manifest['prior_result_file'])))==12409

primary={};origins={}
for i in range(3):
    p=B/f'reviewed-new-{i}.jsonl'
    for row in read(p):assert row['review_key'] not in primary;primary[row['review_key']]=row;origins[row['review_key']]=p
pilot={r['review_key']:r for r in read(B/'pilot-200/fine-reviewed.jsonl')}
pilot_initial={r['review_key']:r for r in read(B/'pilot-200/reviewed.jsonl')}
checks['primary5606_pilot200_partition']=len(primary)==5606 and len(pilot)==len(pilot_initial)==200 and set(pilot)==set(pilot_initial) and not(set(primary)&set(pilot)) and set(primary)|set(pilot)==set(source)
audits={};auditpaths={};audit_sizes=[]
for i in range(2):
    p=B/f'recall-audit-{i}.jsonl';data=read(p);audit_sizes.append(len(data))
    for row in data:assert row['review_key'] not in audits;audits[row['review_key']]=row;auditpaths[row['review_key']]=p
expected_audit={k for k,r in primary.items() if r['interest'] in ('unrelated','low','very_low','medium','super_high')}
checks['audit_complete_original_label_scope']=len(audits)==3046 and set(audits)==expected_audit and not(set(audits)&set(pilot)) and audit_sizes==[1523,1523]
checks['audit_explicit_decisions']=all(r['decision'] in ('keep','change') and isinstance(r['patch'],dict) and (r['decision']=='change' or not r['patch']) for r in audits.values())
checks['audit_change_count']=sum(r['decision']=='change' for r in audits.values())==342
metadata={'classification_method','classification_stages_completed','analysis_provenance','independent_recall_reviewed'}
reconstructed_ok=True;provenance_ok=True;identity_ok=True;quotes_ok=True
for key,row in final.items():
    expected=copy.deepcopy(pilot.get(key,primary.get(key)))
    if key in audits:expected.update(copy.deepcopy(audits[key]['patch']))
    reconstructed_ok &= {k:v for k,v in row.items() if k not in metadata}==expected
    method='ai_independent_semantic_fine_review' if key in pilot else 'ai_semantic_initial_and_detailed'
    stages=['initial_semantic','detailed_semantic']+(['independent_semantic'] if key in pilot else [])
    provenance_ok &= row['classification_method']==method and row['classification_stages_completed']==stages and row['independent_recall_reviewed']==(key in audits)
    expected_prov=[]
    if key in pilot:expected_prov.append({'stage':'initial_semantic','path':str(B/'pilot-200/reviewed.jsonl'),'sha256':sha(B/'pilot-200/reviewed.jsonl')})
    p=B/'pilot-200/fine-reviewed.jsonl' if key in pilot else origins[key]
    expected_prov.append({'stage':method,'path':str(p),'sha256':receipt['original_review_file_versions'][str(p.relative_to(B))]})
    if key in audits:
        p=auditpaths[key];a=audits[key];expected_prov.append({'stage':'independent_recall_calibration','path':str(p),'sha256':receipt['original_review_file_versions'][str(p.relative_to(B))],'decision':a['decision'],'reason':a['reason']})
    provenance_ok &= row['analysis_provenance']==expected_prov
    s=source[key];identity_ok &= all(row[k]==s[k] for k in ('comment_id','customer_uid','video_id'))
    own=[s['comment_text']]+([s['post_body']] if s['post_author_same_as_commenter'] else [])
    quotes=list(row['evidence'])+[q['quote'] for f in ('topics','target_regions','time_mentions') for q in row[f]]
    quotes_ok &= all(q and any(q in t for t in own) for q in quotes)
checks.update(final_equals_original_plus_explicit_patches=reconstructed_ok,provenance_and_stage_mapping_exact=provenance_ok,all_identities_match=identity_ok,quoted_evidence_verbatim=quotes_ok)

spec=importlib.util.spec_from_file_location('rereview_adapter',W/'mother_adapter.py');adapter=importlib.util.module_from_spec(spec);spec.loader.exec_module(adapter)
cache={}
for row in reviews:adapter.validate_new_review(row,B,cache)
checks['all5806_pass_real_I1_gate']=True
checks['transport_equals_semantic_except_pointer']=all({k:v for k,v in r.items() if k!='classification_review_source'}==final[r['review_key']] for r in reviews)
mothers=json.loads((W/'mothers/first50.json').read_text(encoding='utf8'));generic=next(m for m in mothers if m['slot']==1)
adapted={}
for original in semantic:
    row=copy.deepcopy(original);row['interest_at_comment']=row['interest'];row['source_version_conflict']=source[row['review_key']]['source_version_conflict']
    adapter.select_reply(row,mothers);adapter.human_review_lines(row);adapted[row['review_key']]=row
checks['all5806_adapter_and_human_renderer_complete']=True
checks['all_actual_generic_drafts_have_actual_required_facts']=all(generic['required_facts'] in r['reply_missing_facts'] for r in adapted.values() if r['mother_reply_text'])
checks['all_new_send_flags_closed']=all(r['send_authorized'] is False and r['can_send_now'] is False and r['send_attempted_scope']=='text_processing_task_only' and r['platform_delivery_state']=='not_checked_by_text_task' for r in adapted.values())
keys=['D0766','D4363','D2644','D3190','D4627','D4954','D4780','D3034']
eight=[]
for key in keys:
    r=adapted[key];eight.append({'review_key':key,'audit_decision':audits[key]['decision'],'role':r['role'],'interest':r['interest'],'demand_state':r['demand_state'],'needs_review':r['needs_review'],'local_generic_draft':bool(r['mother_reply_text']),'generic_missing_facts':r['reply_missing_facts'],'all_patch_fields_applied':all(final[key][k]==v for k,v in audits[key]['patch'].items())})
checks['eight_requested_repairs_applied']=all(r['all_patch_fields_applied'] and r['audit_decision']=='change' for r in eight)
checks['current_code_still_frozen']=all(sha(W/n)==v for n,v in frozen.items())
out={'scope':'One fixed-scope re-review; no production publisher or platform operation','checks':checks,'all_pass':all(checks.values()),'counts':{'input':len(inputs),'semantic_final':len(semantic),'transport':len(reviews),'original_primary':len(primary),'pilot_independent':len(pilot),'independent_recall':len(audits),'audit_changes':sum(r['decision']=='change' for r in audits.values()),'unique_with_independent_review':len(pilot)+len(audits),'review_source_cache_files':len(cache)},'interest_counts':dict(Counter(r['interest'] for r in semantic)),'eight_repairs':eight,'live_source_database_opened':False,'production_publisher_invoked':False,'platform_calls':0,'semantic_accuracy_claimed':False}
(HERE/'scoped-rereview-validation.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps({'all_pass':out['all_pass'],'checks':checks,'counts':out['counts'],'eight_repairs':eight},ensure_ascii=False,indent=2))
