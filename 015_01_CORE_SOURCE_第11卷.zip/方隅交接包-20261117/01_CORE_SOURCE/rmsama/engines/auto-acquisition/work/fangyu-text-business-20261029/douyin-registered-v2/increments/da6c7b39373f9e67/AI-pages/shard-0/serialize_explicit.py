"""Serialize explicit model decisions only. No text-based intent classifier."""
import json, pathlib, hashlib, sys, collections, copy
HERE=pathlib.Path(__file__).resolve().parent
B=HERE.parent.parent
W=B.parent.parent.parent
SOURCE=[json.loads(x) for x in (B/'shard-0.jsonl').read_text(encoding='utf-8').splitlines()]
S={x['review_key']:x for x in SOURCE}
P={'P':'价格预算','L':'位置通勤','H':'户型面积与居住方式','F':'房内设施','A':'宠物','E':'楼层电梯','T':'入住与租期','S':'房源状态','C':'费用合同','V':'看房联系'}
M={x['slot']:x for x in json.loads((W/'approved-mothers-model-view.json').read_text(encoding='utf-8'))}
D={}
def d(ids,kind,codes,reason,slot=None,state=None):
    # Every key below was explicitly assigned by the reviewing model after reading.
    role,interest={'q':('demand','high'),'s':('demand','super_high'),'m':('demand','medium'),'l':('demand','low'),'u':('unknown','uncertain'),'x':('discussion','unrelated'),'a':('supply','unrelated'),'z':('demand','unrelated')}[kind]
    for num in ids.split():
        k='D'+num.zfill(4)
        assert k not in D,k
        src=S[k]; text=src['comment_text']
        D[k]={'review_key':k,'platform':src['platform'],'comment_id':src['comment_id'],'customer_uid':src['customer_uid'],'video_id':src['video_id'],
          'role':role,'demand_state':state or ('active_at_comment' if kind in ('q','s') else 'unknown'), 'interest':interest,
          'topics':[{'pool':P[c],'quote':text,'polarity':'ask','subject':'supply' if kind=='a' else ('own_demand' if kind in ('q','s','m','l') else 'unresolved'),'condition_scope':None} for c in codes],
          'target_regions':[],'time_mentions':[],'other_constraints':[],'possible_topics':[], 'evidence':[text] if text else [],'reason':reason,
          'context_used':['own','body'],'needs_review':[],'contact_boundaries':[],
          'context_flags':{'same_author':src['post_author_same_as_commenter'],'source_version_conflict':src.get('source_version_conflict',False),'current_need_today_unverified':True},
          'reply_plan':{'preferred_mother_slot':slot,'generic_intro_suitable':kind in ('q','s','m'),'tone':'normal','missing_facts':[],'caution':[],'contact_policy':'allow'},
          'human_confirmed':False,'send_authorized':False,'store_assignment':None}
        r=D[k]
        if kind in ('q','s','m'):
            r['needs_review']=['评论后是否仍需租房及目标门店需核实']
            r['reply_plan']['missing_facts']=['真实住户身份、介绍资格、同店有效优惠及适用条件']
        if slot:
            r['reply_plan']['missing_facts'].append(M[slot]['required_facts'])
        if kind=='u':
            r['needs_review']=[reason]
            r['reply_plan'].update(contact_policy='unknown',generic_intro_suitable=False)
        if kind in ('x','a','z','l'):
            r['reply_plan']['generic_intro_suitable']=False
        if kind=='a':
            for t in r['topics']:t['polarity']='fact'
def r(num):return D['D'+str(num).zfill(4)]
def region(num,text,relation='desired',group='unknown',scope=None):
    assert text in S['D'+str(num).zfill(4)]['comment_text']
    r(num)['target_regions'].append({'text':text,'quote':text,'relation':relation,'group_relation':group,'condition_scope':scope})
def time(num,quote,role,normalized=None,verification='按发表时点理解；实际日期及现时有效性待核'):
    assert quote in S['D'+str(num).zfill(4)]['comment_text']
    src=S['D'+str(num).zfill(4)]
    import datetime
    anchor=datetime.datetime.fromtimestamp(src['published_at_unix'],datetime.timezone.utc).isoformat()
    r(num)['time_mentions'].append({'quote':quote,'time_role':role,'anchor_source':'published_at_unix','anchor_time':anchor,'normalized':normalized,'verification':verification})
def constraint(num,quote,detail):
    assert quote in S['D'+str(num).zfill(4)]['comment_text']
    r(num)['other_constraints'].append({'quote':quote,'detail':detail})
def ambiguity(num,quote,detail,pools=('价格预算','户型面积与居住方式')):
    r(num)['possible_topics'].append({'quote':quote,'candidate_pools':list(pools),'ambiguity':detail})
    r(num)['needs_review'].append(detail)
def pol(num,code,value,subject=None):
    for t in r(num)['topics']:
        if t['pool']==P[code]:
            t['polarity']=value
            if subject:t['subject']=subject
def page(n):
    keys=[c['key'] for g in json.loads((HERE/f'page-{n:02}.json').read_text(encoding='utf-8'))['shared_post_context'] for c in g['comments']]
    missing=set(keys)-set(D)
    if missing:raise RuntimeError('UNREAD/UNASSIGNED '+str(sorted(missing)))
    rows=[D[k] for k in keys]
    (HERE/f'reviewed-{n:02}.jsonl').write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in rows),encoding='utf-8')
    (HERE/'progress.json').write_text(json.dumps({'completed_pages':[int(p.stem[-2:]) for p in HERE.glob('reviewed-??.jsonl')],'decisions':len(D),'platform_calls':0,'independent_review':False},ensure_ascii=False,indent=2),encoding='utf-8')
    print('page',n,'written',len(rows))

# Page 00: each group is an explicit semantic decision, never a text match.
d('1','x','','合租不便的吐槽，未说本人正在换房')
d('4 10 19 22 25 37 97 151 154 160 163 166 169 190 193 196 202 214 217 235 241 247 280 316 355 358 361 364 385 409 415 454 475 511 514 517 526 529 535 538','q','P','可租房源语境下本人询问租金，属评论时询租兴趣',1)
d('7','u','','“稽查”指向不明，不能确认本人需求或纯互动')
d('13','q','PT','本人问价且明确5月要租，当前已在推进',1)
d('16','a','','同作者房源介绍下举手互动，供给作者身份，不是另一个求租人')
d('28 256','m','P','用让我死心的玩笑方式询价；保留关注，不能当明确成交或确定预算',1)
d('31','m','PL','泛租房价格讨论下追问3800房源位置，保留当时关注而非认定预算',31)
d('34','q','LSCT','本人询嘉定江桥房，现房月底到期，已有换房线索',31)
d('40 91 109 268 373 382 391 421 424 430 460 532','q','S','对应租赁房源询问是否仍有房，属当时有效询盘',1)
d('43 46 49 52 55 58 61 64 67','x','','对城市成本、房屋或视频表达感受及建议，未提出本人找房要求')
d('70','u','L','疑问识别昌平煊丽酒店，可能地点核对，实际租赁动作未明')
d('73 76 286 292 295 367 439 487 490 523','q','LS','本人查询指定地点或地铁沿线有无房源，属当时找房',31)
d('79','q','LHS','本人在大兴枣园附近求房并接受合租',34)
d('82 118','q','P','租房展示下明确问价，保留当时询盘',1)
d('85 103 205 277 406 451','q','PL','本人同时询租金与位置，不借用正文价格作为本人预算',31)
d('88','q','HLS','本人明确想租loft并查询顺义房源',34)
d('94 232 238 331','q','L','租房展示下本人问具体地址或小区，属询租关注',31)
d('100','q','C','本人区分商业电与民用水电计费，不能擅自判已拒绝商电',25)
d('106','q','V','本人要求联系，尚非明确预约或签约',28)
d('112','q','HLS','主动求70方两室、新华悦府现有房源，面积与户型均保留',34)
d('115','u','S','“还有”可能追问房源也可能话未完，保留房态候选待核')
d('121','q','HTS','本人求两居且7月5日前可有房；现在已在找房',34)
d('124','s','PCV','本人问月租及押一付一并明确现在就可签合同，推进很强',28)
d('127','q','S','明确想租并询仍有房源',1)
d('130','x','','关于中介费与骗局的评论，不是本人求租条件')
d('133','q','','明确需要房子求推荐；地区预算尚未说',1)
d('136','u','','“闵行5000”可能现住租金、报价或预算，泛价格讨论下主体及动作未明')
d('139','q','PLHF','明确南京西路4000、男生独居、独卫采光要求并问房',34)
d('142','l','','仅说可能要租而先关注，需求未落实、不是明确现在找房',None)
d('145','q','PHS','本人6k预算查询两室一厅',34)
d('148','q','L','明确想租市中心并求推荐',31)
d('157','q','PT','本人问长租月租，长租是租期线索，月价不是总租期',19)
d('172','x','','向作者建议普陀闸北及8k能租到的条件，不当本人目标预算')
d('175 184 346','u','','仅艾特或省略号，分享目的和本人需求不明，不生成推销稿')
d('178 181 187 223 226 310 340 343 349 352 400 418 445 481 484 496 499 502 505 508','x','','地点识别、估价、经验建议或视频互动，未见本人正在租房的请求')
d('199','q','PT','主动问价并说下周想租，当前已在推进而非下周才找',1)
d('208','q','C','水电费用询问明确；多少米指标仍有歧义，不能确定计入租金池',25)
d('211','u','','说去不了上海，但原本为旅行或租房不明，不能认定已完成求租或忽略去向变化')
d('220','q','T','本人问可否短租，保留短租条件、时长待核',19)
d('229','q','L','询房距地铁远近，通勤关注而未给明确距离上限',31)
d('244','m','P','带2000价格核实和真伪疑问，未给本人预算，保留关注',1)
d('250','q','PS','明确预算3500且急租、查询房源',2)
d('253','q','PLH','查询视频两居的位置及租金，未迁移其他正文条件',34)
d('259','q','SP','询是否仍有房并问价，当时有效询盘',1)
d('262','m','P','找房经验帖下问租金并求推荐，兼问生活费，保留潜在需求',1)
d('265','s','SV','询仍有房且提出现在看房，是明确即时约看请求',28)
d('271','q','PH','核实2500是否单间价格，是报价和居住单元询问而非确认预算',1)
d('274 463','m','P','针对挂牌租金表示核实或质疑，保留价格关注而非默认预算',1)
d('283','s','V','明确今天能否看房，已有具体约看时段但未获确认',28)
d('289','a','LH','自述房东直租大丰套一，供给不是求租')
d('298','u','C','本人在退房纠纷且换工作，可能后续换房但未明确求新房，保留待核机会')
d('301','q','TS','国庆求租一周房源，当前已询租而入住在未来',19)
d('304 307','q','LHS','本人查询指定地区合租，有主动找房动作',34)
d('313','q','LHS','明确需要大学城单人间，骗子别来是防骗要求，不扩大为拒绝联系',34)
d('319','m','P','到期搬离分享下问这个多少，可能房租询问但未确认当前可租及本人找房',1)
d('322','q','PH','本人问两房两厅月价，户型引用明确',7)
d('325','m','','“多少米一个月”虽有月计价线索仍待澄清指标，不硬定价格或面积',1)
d('328','u','','只问停车位与年租金，可能单独租车位，住宅租赁需求不明')
d('334','q','P','本人问租金并确认停车位，停车不丢为额外约束',1)
d('337','q','LHS','本人查询科技绿洲附近一居室',34)
d('370','q','PLH','问2500能否租到这类型并接受位置再往后，具体边界待核',34)
d('376','m','F','表达可做饭的正向关注，未明确找房推进，保留弱需求',1)
d('379','q','LHS','明确奉贤金海公路附近求俩室一厅',34)
d('388','q','H','本人询问一户几室，属于居住单元户型询盘',7)
d('394','q','P','问月租是否3500，金额是报价核实不是本人预算上限',1)
d('397','m','','询是否酒店式公寓，保留住宿类型关注，实际求租意愿待核',1)
d('403','q','LH','本人朝阳区找合租伙伴，属于主动合租需求',7)
d('412','q','LS','明确想租车公庄旁房子',31)
d('427','q','P','明确想租并问价',1)
d('433 442 448','a','','提供租房服务、挂出自有房或招揽客户，属于供给')
d('436 478','q','V','本人明确想找作者租房，联系推进但无具体约时',28)
d('457 472','m','','“多少米”可能问租金或面积，房源下保留询盘关注并待澄清',1)
d('466','s','V','明确“我要了”，订房式表达但仍核认真意图与是否实际成交',28)
d('469','u','','只问真的假的，对真实性关注但具体租房需求未明')
d('493','m','LH','表达想捡漏莘闵别墅，保留需求方向，实际租赁用途及认真程度待核',34)
d('520','q','P','明确要换房子并问价，属当时主动找房',1)

for n,t in [(34,'嘉定江桥'),(70,'昌平煊丽酒店'),(73,'宋家庄'),(76,'十八里店'),(79,'大兴枣园附近'),(88,'顺义区'),(112,'新华悦府'),(139,'南京西路'),(148,'市中心'),(238,'朝阳'),(286,'温江'),(289,'大丰附近'),(292,'武侯区大悦城'),(295,'海昌路附近'),(304,'东泰和'),(307,'仓山区'),(313,'大学城'),(337,'科技绿洲附近'),(367,'长宁'),(379,'奉贤区金海公路那边附近'),(403,'朝阳区'),(406,'朝阳区'),(412,'车公庄旁边'),(439,'西华大学附近'),(487,'宝山杨行'),(490,'1号线'),(493,'莘闵'),(523,'金山那边')]:
    region(n,t,'offered' if n==289 else 'unresolved' if n==70 else 'desired')
region(136,'闵行','unresolved'); ambiguity(136,'闵行5000','5000可能为预算、现房租金或房源报价，主体与需求动作待核',['价格预算'])
region(298,'福州','current_home');region(298,'仓山区','current_home');region(298,'马尾区','work')
time(13,'5月','move_in','2026-05');time(34,'月底要到期了','other','2026-07月底现房到期');time(121,'7月5号之前','move_in','2026-07-05之前')
time(124,'现在就签合同','other');time(157,'长租','lease_duration');time(199,'下周','move_in');time(220,'短租','lease_duration');time(250,'急租','move_in')
time(265,'现在可以看吗','viewing');time(283,'今天','viewing','2026-06-24（上海时区）');time(301,'国庆','move_in','2026年国庆期间');time(301,'一周','lease_duration','P1W')
for n in (208,325,457,472):ambiguity(n,'多少米','“米”所指租金或面积尚不明确，不计入确定价格/面积池')
constraint(328,'停车位有吗 年租金多少','可能单独求租停车位，年租金指车位，不能冒充住宅租期')
constraint(334,'有车位吗','需要核实同一房源车位情况')
constraint(262,'还有一月吃饭得多少钱','同时咨询生活成本，不是住房预算')
constraint(313,'骗子别来','防骗要求，不等于拒绝正规身份联系')
constraint(139,'男生一个人','男性单人入住语境');constraint(139,'采光好','要求采光好')
for n,codes in [(79,'H'),(88,'H'),(112,'H'),(121,'H'),(139,'PHF'),(145,'PH'),(250,'P'),(301,'T'),(304,'H'),(307,'H'),(313,'H'),(337,'H'),(379,'H'),(403,'H')]:
    for c in codes:pol(n,c,'accept' if n==79 and c=='H' else 'require')
pol(34,'C','fact','current_home');pol(34,'T','fact','current_home')
for n in (208,298,319,328,397,493):r(n)['needs_review'].append(r(n)['reason'])
for n in (298,313):r(n)['reply_plan']['tone']='serious'
page(0)

# Page 01, read in full with shared bodies and original comments.
d('541 544 550 559 568 577 607 610 616 643 649 652 655 658 664 670 673 676 697 700 703 706 709 712 718 724 727 742 748 778 781 784 790 808 811 814 817 838 847 871 967 970 976 1000 1003 1006 1009 1012 1021 1027 1030 1036 1054','q','P','可租房源语境下本人问租金，属评论时询租；正文其他条件不迁移',1)
d('547 565 739 826 832 853 874 880 883 889 946 952 955 958 1024 1075','x','','估价、感叹、科普或生活互动，没有本人求租动作')
d('553','q','LS','查询中关村附近或公交地铁沿线类似房源，替代地点关系需保留',31)
d('721 730','q','PL','本人询视频房源位置及租金，当时询租关注明确',31)
d('556 1033','q','PL','本人问指定区房源价格，不从帖子地区推定门店',31)
d('562 622 757 856 862 940 943 1048','q','L','在可租房源语境下询问位置，属于当时租房关注',31)
d('571','u','','问能注册吗，可能公司注册地址、其他登记或居住证，住宅用途不明')
d('574 667 820 973','q','PH','明确问一室一厅或两居租金，保留本人所询户型',7)
d('580','q','SPL','同时问房态、价格及位置，当前询租明确',31)
d('583 1039','m','P','核实房源是否2000，未说本人预算；保留价格关注',1)
d('586','a','LHPFC','在住一室并征合租室友、提供价格设施，属于合租供给')
d('589 592 595 598 601','a','LP','明确转租本人已租的房子，是供给；未明确本人另找新房')
d('604','s','V','提出明天能否看房，具体日期约看请求，尚未确认',28)
d('613 640 646 751 754 865 907 910 1045','q','S','对应租赁房源询问是否仍有，保留评论时房态询盘',1)
d('619','u','','艾特称刘总要了，可能代租、玩笑或转述，未证实本人主动委托或签订')
d('625 745','u','','仅真实性质疑，不能确认本人当前租房需求')
d('628','q','LHS','本人在桐梓林查询单间，属于主动找房',34)
d('631','u','','“四川成都找找我”可能求房或供给招揽，供需对象未明')
d('634','a','PC','明确中介自我介绍并招揽客户，居住经历不变成本次求租')
d('637 760 772 1057','q','LS','本人询指定地区有无房源，地区明确而其余要求待核',31)
d('661','q','A','主动问是否可以养狗，宠物种类保留，体型政策待核',13)
d('679 682 691 769 796 799 802 805 982 985 991','x','','对作者看房、环境、租金或自己旧经历的讨论，没有本人新租赁请求')
d('685 688 766 988 994 895 898 901 1078','u','','纯艾特、空文本或无动作称呼，目的不明而非确认无关；保留待核，不出推销稿')
d('694','q','PT','问价并说月底入住，评论时已经推进租赁',1)
d('715 775 787 793 964','m','','房源下多少米语义未完全明确，保留租金/面积候选，不能确定分池',1)
d('733','q','C','问怎么租的，租赁方式或流程待核，尚非确认签约',1)
d('736 850','q','LS','本人查询指定地点是否有类似房源',31)
d('763','l','','表达这辈子想在成都住一段时间，尚非明确当时开始找房',None)
d('823 1051','q','HS','本人询一室一厅或两室现有房源，户型明确',7)
d('829','x','','现居roomtour下只说喜欢，未提出租赁询问')
d('835','q','HLP','本人问该户型位置和租金，保留综合询盘',34)
d('841 844 892 904','m','','“米”或短问多少指标不明；前两条另有位置问询，后两条生活分享下动作未明',1)
# The four keys above have distinct contexts, explicitly refined here.
for n in (841,844):
    r(n)['role']='demand';r(n)['demand_state']='active_at_comment';r(n)['interest']='high'
    r(n)['topics']=[{'pool':'位置通勤','quote':S['D'+str(n).zfill(4)]['comment_text'],'polarity':'ask','subject':'own_demand','condition_scope':None}]
    r(n)['reason']='问月计量多少米并明确问在哪里，位置询盘成立，米的指标单独待核'
    r(n)['reply_plan']['preferred_mother_slot']=31
    r(n)['reply_plan']['missing_facts'].append(M[31]['required_facts'])
for n in (892,904):
    r(n).update(role='unknown',demand_state='unknown',interest='uncertain',reason='生活与闺蜜分享下只问多少，可能问租金或面积等，是否求租仍不明')
    r(n)['reply_plan'].update(preferred_mother_slot=None,generic_intro_suitable=False,contact_policy='unknown')
    r(n)['needs_review']=[r(n)['reason']]
d('859','q','PS','明确预算2000并查询是否有房源',2)
d('868','q','','明确求租，预算地点户型仍缺',1)
d('877','x','','咨询毕业参保后的补贴资格，属于政策申请而非新求租')
d('886','u','','申请教程下询人才门槛，存在住房福利线索，但商业租赁意愿未知')
d('913 979','u','','仅你好，没有明确需求，不默认当询租也不删除')
d('916','m','L','中介语境下报郫都，可视地区关注，完整求租动作仍弱',31)
d('919','m','S','中介租房语境下问有吗，指代房源尚不具体，保留关注',1)
d('922','q','PHEFV','明确预算、两室精装小区、电梯安保及请联系，条件需同房联立',34)
d('925','q','CV','明确本人要租，仅限个人房东无中介费且水电自交，联系有条件',25)
d('928','q','PH','只接受700并求两套，非700就算，条件性需求而非全面拒联',2)
d('931','q','PLT','福州问位置、几百预算且近几天要租，当前找房推进明确',31)
d('934','q','ST','询房仍在且这两天急搬家，当前需求明确',1)
d('937','q','PS','询700房型还有吗，属于预算和房态询盘',2)
d('949','m','P','房源下问贵不贵，弱价格关注而未具体推进',1)
d('961','q','LS','本人问松江有房并请求安排，未指定看房时段，不超高',31)
d('997','q','P','5000需要了解，明确咨询意向但金额是否硬预算仍待核',1)
d('1015','q','SPCT','问房态租金水电且急租，费用与入住紧迫性都保留',25)
d('1018','q','ES','问有无一层，楼层要求需核实，不能只回答有电梯',16)
d('1042','q','T','本人问能否短租，具体时长未明',19)
d('1060','q','LPHT','东郊预算3000套一且最近入住，现在已开始找房',34)
d('1063','q','LHS','查询华阳附近套一房源',34)
d('1066','a','LH','请求帮出租金牛凯德广场套二，是房源供给')
d('1069','m','V','对闺蜜表达找此博主，保留共同找房关注，尚未直接请求约看',28)
d('1072','x','','纯点赞互动，无需求语义')
for n,t in [(553,'中关村附近'),(556,'昌平'),(586,'上城区'),(586,'庆菱路'),(586,'庆春广场地铁站'),(589,'西湖区'),(592,'余杭区'),(595,'萧山'),(598,'上城区闸弄口'),(601,'滨江白马湖'),(628,'桐梓林'),(631,'四川成都'),(637,'金牛区'),(736,'欢乐谷附近'),(760,'金牛区'),(763,'成都'),(772,'武侯区'),(850,'十八里店'),(916,'郫都'),(931,'福州'),(961,'松江'),(1033,'朝阳区'),(1057,'龙泉'),(1060,'东郊这边'),(1063,'华阳附近'),(1066,'金牛区凯德广场附近')]:
    region(n,t,'offered' if n in (586,589,592,595,598,601,1066) else 'unresolved' if n in (631,) else 'desired')
region(553,'公交地铁沿线','accepted','OR','中关村附近或者公交地铁沿线');r(553)['target_regions'][0]['group_relation']='OR'
for n in (715,775,787,793,841,844,964):ambiguity(n,'多少米','“米”指标仍需澄清，不默认写入价格或面积池')
for n in (892,904):ambiguity(n,'多少','只问多少，指租金、面积还是其他事项不明')
constraint(571,'能注册吗','注册事项与住宅或办公用途均待核，不擅自说是居住证')
constraint(586,'有一室我在住','本人当前住其中一室，对外招另一室合租者')
constraint(922,'小区','要求小区房');constraint(922,'安保强','要求安保强，需与价格户型电梯在同房验证')
constraint(925,'如果你是个人房东','只考虑个人房东身份，不能用普通住户身份冒充个人房东')
constraint(928,'不是700就算了','700是明确接受条件；价格不符即不承接，不作全面禁联')
r(925)['contact_boundaries']=[{'quote':'如果你是个人房东，没有中介费，水电费租户自己交，那么请给我留言','scope':'只有符合个人房东、无中介费及水电自交条件才请求留言'}]
r(925)['reply_plan'].update(contact_policy='identity_restricted',tone='serious',generic_intro_suitable=False)
r(925)['needs_review'].append('个人房东身份限制与方隅实际出租主体是否相容，未核不出接话稿')
for n in (589,592,595,598,601):
    r(n)['needs_review'].append('转租后是否另需租房未说明，不把转租房条件当本人新房要求')
for n,q,role,norm in [(604,'明天','viewing','2026-07-05'),(694,'月底住','move_in','2026-07月底'),(931,'这几天','move_in',None),(934,'这两天','move_in',None),(1015,'急租','move_in',None),(1042,'短租','lease_duration',None),(1060,'最近入住','move_in',None),(763,'一段时间','lease_duration',None)]:time(n,q,role,norm)
for n,codes in [(859,'P'),(922,'PHEF'),(925,'C'),(928,'PH'),(937,'P'),(1060,'PH')]:
    for code in codes:pol(n,code,'require')
for t in r(928)['topics']:t['condition_scope']='700的话给我租两套，不是700就算了';t['polarity']='conditional'
pol(1018,'E','ask')
page(1)

# Page 02, complete post context plus every own comment read before assignment.
d('1081 1087 1114 1147 1150 1153 1240 1243 1246 1249 1255 1258 1264 1267 1270 1273 1327 1366 1369 1372 1375 1402','x','','生活分享、买房表达、经验或价格感叹，未见本人住宅租赁推进；不借用他人条件')
d('1084','u','','问闺蜜何时能一起住上，是愿望还是实际合租计划未知，保留机会')
d('1090','m','H','对朋友表达要一室一厅，住房偏好明确但未证实当时找房推进',7)
d('1093','q','PLH','直接问位置价格且明确三个人租，属于主动找房，人数保留',34)
d('1096 1306','q','CV','明确本人要租，仅接受个人房东无中介费及水电自交，联系受条件限制',25)
d('1099','m','P','问真只要700吗，是挂牌价格核实，未将其当本人预算',1)
d('1102','x','','一房一厅700羡慕的感叹，未主动求租')
d('1105 1108 1222 1234 1315 1414','q','S','可租房源下本人询房态，属当时询租；未确认现在仍需',1)
d('1111','q','P','明确以真700为租赁条件，尚非已成交',2)
d('1117','q','LPHS','主动求周浦研发中心附近2500以内、两房或隔断大一房，户型是替代关系',34)
d('1120 1330 1333 1339','q','LS','本人询指定地点或线路有无租房，属当前评论时找房',31)
d('1123','q','LST','查询东方万国企业中心附近房且月底住，工作楼地标不能当办公室用途',31)
d('1126','q','LHS','本人求野生动物园旁一室一厅',34)
d('1129 1135 1141 1144 1162 1168 1174 1177 1207 1219 1231 1237 1345 1348 1360 1363 1381 1384 1387 1390 1393 1396','q','P','可租房源语境下本人询问租金；保留当时兴趣，不代表今天仍需求',1)
d('1132 1201','m','','多少米指标不明，后者带让我死心玩笑，不据此认定预算或面积',1)
d('1138','q','C','本人问怎么租，属于租赁办理方式询问，尚非签约承诺',1)
d('1156','z','CE','先想搬家但最后明确凑合再住一年，目前找房停止；现房潮湿及学校限制仍保留',None,'ended')
d('1159 1378','u','','只有艾特与感叹或纯艾特，分享目的及本人需求未知')
d('1165','q','T','主动询可否短租，具体时长未知',19)
d('1171','q','PLH','本人同时问租金、地铁线路和是否仅一居室，不默认其一定只要一居',34)
d('1180','x','','以至少8700估价，未提出本人求租或预算')
d('1183','q','L','明确诚心租并问位置，主动询租',31)
d('1186','q','HS','本人询三室一厅是否仍有，户型与房态需求明确',7)
d('1189','q','LV','问位置并请求私信，尚未提出约看时段',31)
d('1192','m','','可租房源下蹲蹲，有弱关注但具体需求未明',1)
d('1195 1198 1204 1228 1309','q','L','租赁房源语境下本人询地点，保留评论时询租关注',31)
d('1210 1213 1216','q','PL','本人同时询房源位置和价格，目标朝阳仅由本人明确时记',31)
d('1225','q','V','请求私信，属于接触意愿，未明确约时看房',28)
d('1252','u','A','称装修好且能养猫的房难找，可能本人找房也可能经验感叹，当前动作未明')
d('1261','m','PL','生活与闺蜜居住分享下问位置价格，保留关注，当前可租与本人找房待核',31)
d('1276','u','H','只指一室一厅那个，未说明问价、求租还是描述，保留户型候选')
d('1279','q','HS','即使生活分享下，仍明确询这样的两室一厅有无房源，保留本人动作',7)
d('1282','m','P','生活分享下核实7000月价，有价格关注但当前可租及求租程度待核',1)
d('1285','m','V','表示马上转定金，但生活分享帖下可能玩笑，未证实出租与真实订房，不冒称成交',28)
d('1288','q','V','明确询能否看房，属当时高兴趣，帖子是否可租及安排待核',28)
d('1291','u','S','生活分享下只说还在吗，指向房源还是作者不明，保留房态候选待核')
d('1294','m','HS','疑似问一居有无，但“一的”指代不完整，户型需澄清',7)
d('1297','m','P','生活分享下问价格是否真实，保留价格关注但不确认已在租房',1)
d('1300','a','LPH','金牛套二转租并请联系，是供给；三十多张单位待核')
d('1303','a','CH','明确成都租房招揽、合租整租均提供，中介费收房东，属于供给')
d('1312','m','','明确想搬出去住，但未给时间地点预算或进一步动作，保留潜在需求',1)
d('1318','q','LS','主动查询具体道路门牌附近有无房，城市与承接门店待核',31)
d('1321','a','LH','明确自己有房招室友，三坊七巷附近及爱干净不抽烟是供给方择室友条件')
d('1324','m','','房源下表达越快越好并诉家暴，可能紧急安全住所需求；不公开复述隐私，不把情绪当签约',None)
d('1336','q','LT','本人求紫竹园或15号线附近2-3个月短租，两地点是替代而不是必须同时',19)
d('1342','q','LSV','九亭附近询房并请求看一下，无具体约时，按高兴趣',28)
d('1351','q','PV','请求私发价格，联系意愿不等于已约看',1)
d('1354','m','','房源下只说租房，方向有但动作和要求不完整，保留待核',1)
d('1357','q','PH','明确问一室价格，户型与租金关注',7)
d('1399','q','SP','询房态及价格，当时询盘有效',1)
d('1405 1420','q','PS','查询500块房源是否仍有，价格是所询房源条件而非迁移正文全部要求',2)
d('1408','q','PCHFL','本人单亲带娃求1000内、交一押一、可做饭卫生间阳光及便利出行，条件同房联立',34)
d('1411','q','LHS','明确爱琴海附近求两室一厅出租房',34)
d('1417','q','LPS','本人松江预算两千并询合适房源',2)
for n,t in [(1117,'周浦石药集团上海研发中心这附近'),(1120,'虹桥机场附近'),(1123,'浦东新区东方万国企业中心附近'),(1126,'野生动物园边上'),(1216,'朝阳区'),(1300,'金牛区'),(1303,'成都'),(1318,'中南中路华丽路49号'),(1321,'三坊七巷附近'),(1330,'2号线'),(1333,'徐汇'),(1336,'闵行区紫竹科学园附近'),(1336,'地铁15号线附近'),(1339,'中原附近'),(1342,'九亭附近'),(1411,'爱琴海附近'),(1417,'松江')]:
    region(n,t,'offered' if n in (1300,1303,1321) else 'desired','OR' if n==1336 else 'unknown')
region(1156,'围着学校','desired','unknown','此前想搬家但已决定凑合再住一年；学校附近是有条件的后续换房限制')
for n in (1096,1306):
    r(n)['contact_boundaries']=[{'quote':'如果你是个人房东，没有中介费，水电费租户自己交，那么请给我留言','scope':'仅符合个人房东无中介费及水电自交条件才请求留言'}]
    r(n)['reply_plan'].update(contact_policy='identity_restricted',tone='serious',generic_intro_suitable=False)
    r(n)['needs_review'].append('核实方隅出租主体是否满足个人房东限制，不以住户介绍冒充房东')
for n in (1132,1201):ambiguity(n,'多少米','“米”所指价格或面积仍不明确；保留询盘线索不计入确定池')
ambiguity(1252,'装修好还同意养猫的房真的难找','本人正在找房还是一般经验待核',['宠物','房内设施'])
ambiguity(1276,'一室一厅的那个','仅指代户型，未说求租或询价',['户型面积与居住方式'])
ambiguity(1294,'一的有吗','疑似一居室，但原词不完整不能确定具体户型',['户型面积与居住方式'])
constraint(1093,'三个人租','三人共同租住，人数要求不能丢')
constraint(1117,'两房或者隔断大一房','两种户型二选一，不要求同房同时两房与大一房')
for t in r(1117)['topics']:
    if t['pool']=='户型面积与居住方式':t['condition_scope']='两房或者隔断大一房'
constraint(1156,'今年太潮了，一楼发霉真的很厉害','现住一楼潮湿发霉，非已确认新房楼层硬条件')
constraint(1156,'娃读书只能围着学校找','孩子就学限制，学校名称未给；不能因家庭语境编造人数预算')
constraint(1156,'同样的价格','以前找房时不想提高租金，但具体金额未说，不能借别人预算')
constraint(1321,'爱干净不抽烟','这是本人房源招室友的条件，不是本人求新房的要求')
constraint(1324,'越快越好','可能急需安全住所，具体入住/求助目的须私密澄清')
constraint(1324,'我老公会家暴','本人表达家庭暴力风险，联系应尊重隐私，不能普通宝宝营销式回应')
constraint(1408,'单亲带娃','家庭居住语境，不能假定孩子人数或年龄')
constraint(1408,'有点阳光出行便利的','采光与出行便利要求，具体阈值未说明')
r(1324)['reply_plan'].update(tone='serious',generic_intro_suitable=False,contact_policy='allow',missing_facts=['本人是否在寻找安全住所、能否安全接收联系、目标地区及时间预算'],caution=['家庭暴力安全与隐私优先，暂不强推营销接话；不公开复述家庭细节'])
r(1324)['needs_review']=['越快越好的对象是否为住房与安全联络方式需谨慎澄清；不擅自作成交判断']
r(1408)['reply_plan']['tone']='serious';r(1408)['reply_plan']['caution'].append('家庭语境用严肃语气，不能编造满足预算及设施的房源')
for n in (1279,1282,1285,1288,1291,1294,1297):r(n)['needs_review'].append('原帖为自住分享，需核实是否有可租房、本人是否认真推进')
for n in (1084,1252,1276):r(n)['needs_review'].append(r(n)['reason'])
time(1123,'月底住','move_in','2026-09月底');time(1165,'短租','lease_duration');time(1156,'再住一年','other','当前房续住约一年')
time(1285,'马上','other');time(1324,'越快越好','move_in',None,'是否指安全住所及实际入住时间待核，不认定已约定')
time(1336,'2-3个月','lease_duration','P2M至P3M')
for n,codes in [(1090,'H'),(1093,'H'),(1096,'C'),(1117,'PH'),(1126,'H'),(1186,'H'),(1279,'H'),(1306,'C'),(1408,'PCHF'),(1411,'H'),(1417,'P')]:
    for code in codes:pol(n,code,'require')
for n in (1111,):
    pol(n,'P','conditional')
    for t in r(n)['topics']:t['condition_scope']='真700我就租了'
pol(1156,'C','fact','current_home');pol(1156,'E','fact','current_home')
page(2)

# Final semantic refinements after the full-page pass (no independent reviewer claimed).
def addtopic(num,code,polarity='ask',subject=None,quote=None,scope=None):
    row=r(num)
    q=quote or S[row['review_key']]['comment_text']
    assert q in S[row['review_key']]['comment_text']
    row['topics'].append({'pool':P[code],'quote':q,'polarity':polarity,'subject':subject or ('supply' if row['role']=='supply' else 'own_demand'),'condition_scope':scope})
for n,code in [(289,'F'),(433,'V'),(442,'V'),(448,'C'),(448,'V'),(592,'H'),(598,'C'),(601,'V'),(586,'V'),(1300,'V'),(1303,'V')]:
    addtopic(n,code,'fact','supply')
region(433,'成都','offered');region(442,'川师','offered')
constraint(586,'距离庆菱路800M庆春广场地铁站m756m','房源位置距离是供给描述，原距离写法不标准，不改造成本人通勤阈值')
constraint(589,'首月补贴300 相当于第一个月1200','这是转租供给首月补贴，不当本人求新房预算')
constraint(1300,'三十多张','转租价格的口语单位和计价周期待核，不自动换算')
constraint(1096,'如果你是个人房东','个人房东身份限制');constraint(1306,'如果你是个人房东','个人房东身份限制')
constraint(886,'需要E类人才吗','住房/生活补贴申请门槛疑问，不等于商业公寓求租')
r(886)['needs_review'].append('需核具体补贴/免费入住项目及是否愿意商业租房')
for n in (16,):r(n)['context_flags']['same_author_supply_body_used']=True
r(211)['context_flags']['travel_or_housing_purpose_unresolved']=True
for n in (106,436,478,1225):r(n)['reply_plan']['caution'].append('普通联系意愿不等于已经预约看房或授权发送')
for n in (34,112,139,145,250,304,307,313,337,379,553,628,859,922,928,931,1060,1063,1117,1123,1126,1336,1408,1411,1417):
    r(n)['reply_plan']['missing_facts'].append('适配地区及所有明确条件须在同一有效房源核验，不拼接不同房源')
for n in (298,328,571,619,631,886,1324):r(n)['reply_plan']['caution'].append('供需、用途或安全事实未澄清前不得强行推销或补造需求')
# Re-save pages with the refinements, preserving the explicit decision script as evidence.
for n in range(3):page(n)

def finalize():
    import importlib.util
    rows=[D[x['review_key']] for x in SOURCE]
    out=B/'reviewed-new-0.jsonl'
    out.write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in rows),encoding='utf-8')
    errors=[]
    for src,row in zip(SOURCE,rows):
        for f in ('review_key','comment_id','customer_uid','video_id','platform'):
            if row[f]!=src[f]:errors.append([row['review_key'],'identity',f])
        own=src['comment_text']
        allowed=own+('\n'+src['post_body'] if src['post_author_same_as_commenter'] else '')
        for q in row['evidence']:
            if not q or q not in allowed:errors.append([row['review_key'],'evidence',q])
        for f in ('topics','target_regions','time_mentions','other_constraints','possible_topics','contact_boundaries'):
            for item in row[f]:
                q=item.get('quote') if isinstance(item,dict) else item
                if q and q not in allowed:errors.append([row['review_key'],f,q])
        if row['human_confirmed'] or row['send_authorized'] or row['store_assignment'] is not None:errors.append([row['review_key'],'authorization'])
    assert len(rows)==474 and len(D)==474
    assert set(D)==set(S)
    assert len({(x['review_key'],x['comment_id']) for x in rows})==474
    # Only the isolated preflight gets compiler metadata; original semantic file stays untouched.
    semantic=[]
    for row in rows:
        iso=copy.deepcopy(row)
        iso.update(classification_method='ai_semantic_initial_and_detailed',classification_stages_completed=['initial_semantic','detailed_semantic'])
        semantic.append(iso)
    sp=HERE/'isolated-semantic-0.jsonl'
    sp.write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in semantic),encoding='utf-8')
    sha=hashlib.sha256(sp.read_bytes()).hexdigest()
    compiled=[]
    for iso in semantic:
        c=copy.deepcopy(iso)
        c['classification_review_source']={'path':str(sp.relative_to(B)),'sha256':sha}
        compiled.append(c)
    cp=HERE/'isolated-preflight-0.jsonl'
    cp.write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in compiled),encoding='utf-8')
    spec=importlib.util.spec_from_file_location('mother_adapter',W/'mother_adapter.py')
    adapter=importlib.util.module_from_spec(spec);spec.loader.exec_module(adapter)
    cache={};preflight=[]
    for row in [json.loads(x) for x in cp.read_text(encoding='utf-8').splitlines()]:
        try:adapter.validate_new_review(row,B,cache)
        except Exception as ex:preflight.append(str(ex))
    report={'shard':0,'input_count':len(SOURCE),'output_count':len(rows),'unique_key_comment_pairs':len({(x['review_key'],x['comment_id']) for x in rows}),
      'identity_sets_equal':set((x['review_key'],x['comment_id'],x['customer_uid'],x['video_id'],x['platform']) for x in SOURCE)==set((x['review_key'],x['comment_id'],x['customer_uid'],x['video_id'],x['platform']) for x in rows),
      'evidence_exact_substring_errors':errors,'formal_preflight':'mother_adapter.validate_new_review','formal_preflight_checked':len(compiled),'formal_preflight_errors':preflight,
      'review_sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'isolated_semantic_source_sha256':sha,'original_semantics_has_compiler_metadata':False,
      'classification_method':'same_round_model_initial_and_detailed_semantic','independent_review_claimed':False,'platform_calls':0,'send_attempts':0,
      'role_counts':dict(collections.Counter(x['role'] for x in rows)),'interest_counts':dict(collections.Counter(x['interest'] for x in rows)),
      'pages':[{'page':n,'count':len((HERE/f'reviewed-{n:02}.jsonl').read_text(encoding='utf-8').splitlines())} for n in range(3)]}
    report['passed']=not errors and not preflight and report['identity_sets_equal']
    (B/'shard-0-validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    (B/'shard-0-report.md').write_text('# 抖音本片评审核对\n\n474条已逐条读取共享正文及本人评论，由同轮模型完成初筛与细筛合并判读，三页为180、180、114条。\n\n输入输出的review_key、comment_id、customer_uid、video_id、platform恰好一致；逐字证据检查错误 '+str(len(errors))+' 条；现有 mother_adapter.validate_new_review 真实隔离预检 '+str(len(compiled))+' 条，错误 '+str(len(preflight))+' 条。\n\n未声称独立复核、人工确认、门店指派或发送许可。正式原评审未加compiler元数据，只有本片隔离JSONL补有同轮模型阶段与真实文件SHA供结构预检。allow仅表示文本未限制联系。\n\n未知、米单位、个人房东限制、供给转租、短租、现房到期、学校限制、紧急家庭安全线索均保留，事实缺口进入needs_review/reply_plan；未生成新回复正文。\n\n本报告是结构与证据核对，不等于用户金标或独立语义复核。\n',encoding='utf-8')
    print(json.dumps(report,ensure_ascii=False,indent=2))
    assert report['passed']

if __name__=='__main__':
    finalize()
