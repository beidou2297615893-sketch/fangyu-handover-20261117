$Host.UI.RawUI.WindowTitle = '抖音文字分类进度（只读显示）'
while ($true) {
 Clear-Host
 $progressFile = Join-Path $PSScriptRoot '实时进度.txt'
 if (Test-Path -LiteralPath $progressFile) { Get-Content -LiteralPath $progressFile -Encoding UTF8 }
 Write-Host '关闭此显示窗口不会停止分类；不执行采集或发送。'
 Start-Sleep -Seconds 5
}
