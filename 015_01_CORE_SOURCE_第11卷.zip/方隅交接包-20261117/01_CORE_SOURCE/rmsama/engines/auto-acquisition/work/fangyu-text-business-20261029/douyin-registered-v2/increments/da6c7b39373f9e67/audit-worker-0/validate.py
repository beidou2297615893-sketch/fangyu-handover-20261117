import sys
sys.dont_write_bytecode=True
import json,pathlib,hashlib,copy,importlib.util,collections
from decisions import B,OUT,ALL,PAGE,DEC
sys.stdout.reconfigure(encoding='utf-8')
W=B.parents[2]
task=json.loads((B/'recall-audit/part-0/task.json').read_text(encoding='utf-8'))
expected=set(task['expected_review_keys'])
assert len(expected)==task['records']==440
audit=[]
for p in range(4):
 rows=[json.loads(s) for s in (B/f'recall-audit/part-0/page-{p:02}.audit.jsonl').read_text(encoding='utf-8').splitlines()]
 assert [r['review_key'] for r in rows]==PAGE[p]
 audit+=rows
assert len(audit)==len({r['review_key'] for r in audit})==440
assert {r['review_key'] for r in audit}==expected==set(ALL)==set(DEC)
primary={};source_sha={}
for source in task['primary_sources']:
 path=B/source['path'];sha=hashlib.sha256(path.read_bytes()).hexdigest()
 assert sha==source['sha256'],path
 source_sha[source['path']]=sha
 for s in path.read_text(encoding='utf-8').splitlines():
  row=json.loads(s)
  if row['review_key'] in expected:
   assert row['review_key'] not in primary
   primary[row['review_key']]=row
assert set(primary)==expected
allowed=set('role demand_state interest topics target_regions time_mentions other_constraints possible_topics evidence reason context_used needs_review contact_boundaries context_flags reply_plan'.split())
merged=[];quote_checks=0
for a in audit:
 k=a['review_key'];c=ALL[k];orig=primary[k]
 assert set(a)=={'review_key','decision','reason','patch'}
 assert a['decision'] in ('keep','change') and a['reason'].strip()
 assert set(a['patch'])<=allowed
 assert (a['patch']=={})==(a['decision']=='keep')
 for f,v in c['first_semantic_judgment'].items():assert orig[f]==v,(k,f)
 row=copy.deepcopy(orig);row.update(copy.deepcopy(a['patch']))
 assert all(row[f]==orig[f] for f in ('review_key','comment_id','customer_uid','video_id','platform'))
 assert row['platform']=='douyin'
 assert row['human_confirmed'] is False and row['send_authorized'] is False and row['store_assignment'] is None
 sources=[c['text']]+([c['body']] if c['same_author'] else [])
 for f in ('topics','target_regions','time_mentions','other_constraints','possible_topics','contact_boundaries'):
  for item in row[f]:
   if isinstance(item,dict) and 'quote' in item:
    assert isinstance(item['quote'],str) and item['quote'] and any(item['quote'] in txt for txt in sources),(k,f,item['quote'])
    quote_checks+=1
 for q in row['evidence']:
  assert isinstance(q,str) and q and any(q in txt for txt in sources),(k,'evidence',q)
  quote_checks+=1
 assert set(row['context_used'])<=set(('own','title','parent','body'))
 assert row['reply_plan']['preferred_mother_slot'] in (None,1,2,7,13,16,19,25,28,31,34)
 assert row['reply_plan']['contact_policy'] in ('allow','identity_restricted','no_contact','unknown')
 merged.append(row)
assert len({r['comment_id'] for r in merged})==440
def dump(path,rows):path.write_text(''.join(json.dumps(r,ensure_ascii=False,separators=(',',':'))+'\n' for r in rows),encoding='utf-8')
dump(OUT/'semantic-merged-before-transport.jsonl',merged)
for r in merged:
 r['classification_method']='ai_independent_semantic_fine_review'
 r['classification_stages_completed']=['initial_semantic','detailed_semantic','independent_semantic']
 r.pop('classification_review_source',None)
semantic=OUT/'isolated-semantic-review.jsonl';dump(semantic,merged)
sha=hashlib.sha256(semantic.read_bytes()).hexdigest()
spec=importlib.util.spec_from_file_location('readonly_mother_adapter',W/'mother_adapter.py')
adapter=importlib.util.module_from_spec(spec);spec.loader.exec_module(adapter)
passed=[];cache={}
for r in merged:
 row=copy.deepcopy(r)
 row['classification_review_source']={'path':semantic.relative_to(B).as_posix(),'sha256':sha}
 adapter.validate_new_review(row,B,cache)
 passed.append(row)
dump(OUT/'isolated-validated-review.jsonl',passed)
pages=[]
for p in range(4):
 path=OUT/f'page-{p:02}.progress.json';progress=json.loads(path.read_text(encoding='utf-8'))
 progress.update(status='complete',validation='passed',validated_records=len(PAGE[p]));path.write_text(json.dumps(progress,ensure_ascii=False,indent=2),encoding='utf-8');pages.append(progress)
summary={'status':'passed','records':440,'audit_records':len(audit),'keep':sum(r['decision']=='keep' for r in audit),'change':sum(r['decision']=='change' for r in audit),'changed_keys':[r['review_key'] for r in audit if r['decision']=='change'],'review_key_sets_equal':True,'duplicate_review_keys':0,'duplicate_comment_ids':0,'identity_fields_unchanged':True,'first_judgment_matches_primary':True,'primary_sha256_verified':source_sha,'quote_and_evidence_checks':quote_checks,'quote_errors':0,'adapter':'mother_adapter.validate_new_review','adapter_rows_passed':len(passed),'isolated_semantic_source_sha256':sha,'semantic_before_transport_sha256':hashlib.sha256((OUT/'semantic-merged-before-transport.jsonl').read_bytes()).hexdigest(),'isolated_validated_sha256':hashlib.sha256((OUT/'isolated-validated-review.jsonl').read_bytes()).hexdigest(),'page_audit_sha256':{str(p):hashlib.sha256((B/f'recall-audit/part-0/page-{p:02}.audit.jsonl').read_bytes()).hexdigest() for p in range(4)},'formal_primary_modified':False,'formal_compiler_binding_done':False,'human_confirmed':False,'send_authorized':False,'usage':'unknown','limitations':['一次独立模型语义复核，不是人工金标或多轮独立验证','仅阅读提供文本，没有视频画面、未提供深层回复；不确认今日需求及房源事实','仅隔离真实JSONL和SHA预检；正式编译绑定由主代理处理']}
(OUT/'validation.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
(OUT/'progress.json').write_text(json.dumps({'status':'complete','pages':pages,'records':440,'keep':summary['keep'],'change':summary['change'],'validation':'passed','usage':'unknown'},ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(summary,ensure_ascii=False))
