"""Join explicit, complete, disjoint semantic audit pages; no default decisions."""
import argparse,json,hashlib,copy
from pathlib import Path
W=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('--run',required=True);args=p.parse_args()
assert len(args.run)==16 and all(c in '0123456789abcdef' for c in args.run)
B=W/'douyin-registered-v2/increments'/args.run
def get(p):return json.loads(p.read_text(encoding='utf-8'))
def jl(p):return [json.loads(l) for l in p.read_text(encoding='utf-8').splitlines() if l.strip()]
def write_frozen(p,raw):
    if p.exists():assert p.read_bytes()==raw,f'Existing frozen audit differs: {p.name}'
    else:p.write_bytes(raw)
src={r['review_key']:r for r in jl(B/'input.jsonl')}
primary={r['review_key']:r for i in range(3) for r in jl(B/f'reviewed-new-{i}.jsonl')}
allowed={'role','demand_state','interest','topics','target_regions','time_mentions','other_constraints','possible_topics','evidence','reason','context_used','needs_review','contact_boundaries','context_flags','reply_plan'}
parts=[];seen=set();sources={};missing=[]
for part in range(2):
    D=B/f'recall-audit/part-{part}';task=get(D/'task.json');out=[]
    for source in task['primary_sources']:
        assert hashlib.sha256((B/source['path']).read_bytes()).hexdigest()==source['sha256'],'Primary changed after audit freezing'
    for n in range(task['pages']):
        page=D/f'page-{n:02}.json';f=D/f'page-{n:02}.audit.jsonl'
        if not f.exists():missing.append(str(f.relative_to(B)));continue
        expected=[c['key'] for g in get(page)['post_groups'] for c in g['comments']]
        rows=jl(f)
        assert len(rows)==len(expected) and len({r['review_key'] for r in rows})==len(rows) and {r['review_key'] for r in rows}==set(expected),str(f)
        by={r['review_key']:r for r in rows}
        for k in expected:
            a=by[k];assert k not in seen;seen.add(k)
            assert a['decision'] in ('keep','change') and isinstance(a['reason'],str) and a['reason'].strip()
            assert isinstance(a['patch'],dict) and set(a['patch'])<=allowed
            assert a['decision']=='change' or a['patch']=={}
            merged=copy.deepcopy(primary[k]);merged.update(a['patch']);s=src[k]
            own=[s['comment_text']]+([s['post_body']] if s['post_author_same_as_commenter'] else [])
            quotes=list(merged.get('evidence',[]))
            for field in ['topics','target_regions','time_mentions','other_constraints','contact_boundaries']:
                quotes.extend(t['quote'] for t in merged.get(field,[]) if isinstance(t,dict) and 'quote' in t)
            assert all(isinstance(q,str) and q and any(q in text for text in own) for q in quotes),k
            out.append(a)
        sources[str(f.relative_to(B))]=hashlib.sha256(f.read_bytes()).hexdigest()
    parts.append(out)
if missing:
    print(json.dumps({'complete':False,'completed_decisions':len(seen),'missing_pages':missing},ensure_ascii=False));raise SystemExit(2)
selection=get(B/'semantic-audit-selection.json')
assert len(seen)==selection['selected'] and seen==set(selection['keys'])
for part,out in enumerate(parts):
    task=get(B/f'recall-audit/part-{part}/task.json')
    assert len(out)==task['records'] and {r['review_key'] for r in out}==set(task['expected_review_keys'])
    write_frozen(B/f'recall-audit-{part}.jsonl',''.join(json.dumps(r,ensure_ascii=False,separators=(',',':'))+'\n' for r in out).encode('utf-8'))
receipt=dict(complete=True,independent_decisions=len(seen),changed_records=sum(r['decision']=='change' for out in parts for r in out),parts=[len(out) for out in parts],page_source_sha256=sources,ID_and_quote_checks_passed=True,actual_task_usage=None,not_accuracy_measurement=True,source_modified=False,platform_calls=0)
write_frozen(B/'semantic-audit-merge-receipt.json',json.dumps(receipt,ensure_ascii=False,indent=2).encode('utf-8'))
gate=get(B/'quality-gate.json');gate.update(state='independent_audits_complete_await_compile',independent_recall_calibration_complete=len(seen),publication_allowed=False)
(B/'quality-gate.json').write_text(json.dumps(gate,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in receipt.items() if k!='page_source_sha256'},ensure_ascii=False))
