"""Reversible local family repair. Never imports/runs publishers or model clients."""
import pathlib,json,copy,hashlib,re,collections,string,sys,datetime
O=pathlib.Path(__file__).resolve().parent;W=O.parents[1];P=O.parent/'legacy-local-planning';Q=O.parent/'legacy-short-preview';B=W/'douyin-registered-v2/increments/f98cc21138910fb9'
def load(p):return json.loads(pathlib.Path(p).read_text(encoding='utf8'))
def jl(p):return [json.loads(l) for l in pathlib.Path(p).read_text(encoding='utf8').splitlines() if l.strip()]
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def canonical(x):return hashlib.sha256(json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def put(p,x):pathlib.Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
def putjl(p,x):pathlib.Path(p).write_text(''.join(json.dumps(r,ensure_ascii=False,separators=(',',':'))+'\n' for r in x),encoding='utf8')
cur=load(W/'region-brand-routing/current.json');old=jl(P/'local-proposed-plans.jsonl');oldcontract=load(B/'local-mother-contract.json');qa=jl(Q/'qa-v2/review-200.jsonl');negative=jl(Q/'qa-v2/review-negative-30.jsonl');qaidx={(r['platform'],r['cid'],r['uid']):r for r in qa};sources={}
for platform,f in cur['results'].items():
 for r in jl(f):sources[platform,r['comment_id'],r['customer_uid']]=r
protected={}
for d in (P,Q):
 for f in d.rglob('*'):
  if f.is_file():protected[str(f.resolve())]=sha(f)
for name,h in load(P/'plan-source-manifest.json')['sources'].items():protected[name]=h
for f in [B/'local-mother-contract.json',B/'pool-short-reply-plans.jsonl',B/'semantic-final.jsonl',B/'input.jsonl',W/'region-brand-routing/current.json',W/'region-brand-routing/latest-manifest.json',W/'当前双平台回复结果指针.json',W/'当前文本处理运行状态.json',W/'pool-mother-review/fifty-review-v3-short.jsonl']:
 if f.exists():protected[str(f.resolve())]=sha(f)
contract=copy.deepcopy(oldcontract);contract.update(version='legacy-local-planning-v2-review-only',cloned_from={'path':str((B/'local-mother-contract.json').resolve()),'sha256':sha(B/'local-mother-contract.json')},applied=False,send_authorized=False)
contract['families']['budget_fit']['template']='宝宝，我住方隅，{budget}有没有合适的帮你问，介绍有优惠。'
def family(name,template,slots,scope='housing_confirmation'):
 contract['families'][name]={'template':template,'required_fill':slots,'scope':scope,'wording_individually_user_approved':False}
family('area_two_spans','宝宝，我住方隅，{place_a}，{place_b}有没有合适的，我帮你问，介绍有优惠。',['place_a','place_b'])
family('location_about_place','宝宝，我住方隅，{place}的具体位置帮你问，介绍有优惠。',['place'])
family('price_location_about_place','宝宝，我住方隅，{place}的位置和租金帮你问，介绍有优惠。',['place'])
family('budget_low_requirements','宝宝，我住方隅，{requirements}有没有便宜点的房源，我帮你问，介绍有优惠。',['requirements'])
family('region_relation_check','宝宝，我住方隅，介绍有优惠。你想住{place}附近吗？',['place'],'clarification_only_region_relation')
family('region_scope_check','宝宝，我住方隅，介绍有优惠。你想住在{place}吗？',['place'],'clarification_only_region_relation')
family('object_clarification','宝宝，你是在找住的房子吗？',[],'clarification_only_object')
range_suffix=re.compile(r'(?:(?:地铁站|附近|周边|周围|沿线|边上|旁边|一带|以内|以外|之内|左右|内|外)|(?:[0-9一二两三四五六七八九十百\.]+\s*(?:公里|千米|米|分钟)(?:以内|之内|范围|左右)?))*')
relative=re.compile(r'便宜(?:点|些|一点|一些)?|低价|省点租金')
def fields(r):
 s=r.get('source_record') or {};a=s.get('classification') if isinstance(s.get('classification'),dict) else s;return s,a
def remarks(r):
 s,a=fields(r);out=[]
 for d in [r,s,a]:
  for k in ('needs_review','review_reasons','semantic_review_reasons','blocking_reasons'):
   v=d.get(k) or [];out.extend(v if isinstance(v,list) else [str(v)])
 return list(dict.fromkeys(str(x) for x in out))
def setplan(z,f,fill,evidence,reason):
 z.update(family=f,fill=fill,evidence=evidence,hold_reasons=[],status='local_plan_proposed');z['change_reasons'].append(reason)
def hold(z,reason):
 z.update(family=None,fill={},evidence=[],status='local_plan_held');z['hold_reasons']=list(dict.fromkeys(z['hold_reasons']+[reason]));z['change_reasons'].append(reason)
def bind(field,value,source='own_comment_literal_bound_to_existing_AI',pool='位置通勤',basis=None):return {'field':field,'quote':value,'source_field':source,'pool':pool,'existing_AI_quote':basis}
def locparts(rr,text):
 q=rr.get('quote') or '';v=rr.get('text') or q
 if q and q in text and '蹲' in q:
  parts=q.split('蹲')
  if len(parts)==2 and all(parts) and all(not re.search(r'我|咱|找房|求租|[?？]',p) for p in parts):return parts,'split_existing_region_quote_at_demand_action'
 # Prefer a region quote that already includes a literal spatial range, then grow a known literal entity only by adjacent range terms.
 if q in text and q and not re.search(r'我|咱|本人|求租|想租|推荐|房子|房源|便宜|上班|工作|租|在|有|吗|嘛|么|在哪|哪里|多少钱|预算|套[一二三123]|[?？\[\]]',q) and len(q)<=36:v=q
 elif v not in text or v not in q:v=q
 if not v or v not in text:return [],'nonliteral_region_binding'
 if re.search(r'我|咱|本人|求租|蹲|想租|有没有|有(?:吗|嘛|么|房)|推荐|便宜|上班|工作|[?？\[\]]',v):return [],'region_value_contains_customer_action'
 positions=[m.start() for m in re.finditer(re.escape(v),text)]
 if len(positions)!=1:return [v],'repeated_region_literal_no_scope_expansion'
 end=positions[0]+len(v);suffix=range_suffix.match(text[end:]).group();return [v+suffix],'preserve_adjacent_original_spatial_scope'
def transform(p):
 z=copy.deepcopy(p);r=sources[p['platform'],p['cid'],p['uid']];s,a=fields(r);text=r['comment_text'];oldfam=p['family'];z['previous_plan_sha256']=canonical(p);z['previous_family']=oldfam;z['change_reasons']=[];z['plan_version']='legacy-local-planning-v2';z['clarification_only']=False;z['original_role_state_interest_unchanged']=True
 z['source_metadata_preserved']={'source_reply_missing_facts':copy.deepcopy(s.get('reply_missing_facts')),'source_original_reply_missing_facts':copy.deepcopy(r.get('original_reply_missing_facts')),'source_reply_plan_missing_facts':copy.deepcopy((s.get('reply_plan') or {}).get('missing_facts')),'sidecar_reply_plan_missing_facts':copy.deepcopy((r.get('reply_plan') or {}).get('missing_facts')),'needs_review':remarks(r)}
 z['customer_requirements']=[{'quote':e['quote'],'pool':e.get('pool'),'subject':'own_demand','polarity':e.get('polarity'),'condition_scope':e.get('condition_scope'),'source_field':e.get('source_field')} for e in p['literal_evidence'] if e.get('subject')=='own_demand' and e.get('quote') and e['quote'] in text]
 z['metadata_cautions']=[{'kind':'source_metadata_is_not_customer_requirements','reason':'Original missing-fact/template applicability arrays are preserved separately. They never supply customer requirement parameters.'}]
 factlist=[]
 for v in z['source_metadata_preserved'].values():
  if isinstance(v,list):factlist.extend(x for x in v if isinstance(x,str))
 for q in dict.fromkeys(factlist):
  if re.search(r'家庭整租|全部必付费用上限|全部费用上限',q):z['metadata_cautions'].append({'kind':'template_applicability_not_customer_demand','quote':q,'reason':'Only own-comment evidence can establish family tenancy or an all-in cost ceiling; source template conditions are not added as customer facts.'})
 qaentry=qaidx.get((p['platform'],p['cid'],p['uid']))
 if qaentry and qaentry['source_plan_metadata_cautions']:z['qa_source_plan_metadata_cautions_preserved']=copy.deepcopy(qaentry['source_plan_metadata_cautions'])
 if not oldfam:
  z['change_reasons']=['original_specific_hold_preserved; metadata_separated_only'];return z
 fs=p['source_field_evidence'];regs=fs['target_regions'];tags={v if isinstance(v,str) else v.get('pool') for v in fs['topics']};reviews=remarks(r);raw=r.get('original_raw_record') or {};title=raw.get('post_title') or '';body=raw.get('post_text') or s.get('post_body') or ''
 # This is an explicit existing-review gate, not a keyword-based residential reclassification.
 object_review=any('标题未说明房屋具体用途' in x and '需核实住宅属性' in x for x in reviews)
 residential_title=bool(re.search(r'公寓|住宅|房子|房间|[一二三四1234]室|租房|整租|合租|卧室|serviced\s+apartment',title,re.I))
 if object_review and not body and '个人转租' in title and not residential_title:
  setplan(z,'object_clarification',{},[],'explicit_existing_residential_object_review_plus_missing_body; clarification_instead_of_promotion');z['clarification_only']=True;z['clarification_basis']={'existing_review_quotes':[x for x in reviews if '标题未说明房屋具体用途' in x],'title':title,'body_missing':True};return z
 ambiguous_region=any(re.search(r'工作锚点还是期望住处待核|工作.{0,8}还是.{0,8}住.{0,8}待核',x) for x in reviews)
 parts=[];partreason=None
 if len(regs)==1:parts,partreason=locparts(regs[0],text)
 if ambiguous_region:
  if len(parts)==1 and tags <= {'位置通勤','房源状态'}:
   value=parts[0];f='region_scope_check' if re.search(r'附近|周边|沿线|公里|以内|内$',value) else 'region_relation_check';setplan(z,f,{'place':value},[bind('place',value,basis=regs[0].get('quote'))],'existing_region_relation_caution_overrides_definite_work_template_without_changing_relation');z['clarification_only']=True;z['clarification_basis']={'existing_review_quotes':[x for x in reviews if '待核' in x],'original_region_relation':regs[0].get('relation')};return z
  hold(z,'explicit_region_ambiguity_needs_literal_clarification_slots');return z
 if len(regs)==1 and not parts:
  reason='region_disjunctive_radius_needs_separate_OR_slots_no_continuous_literal_value' if re.search(r'或者|或',regs[0].get('quote','')) else 'region_literal_or_action_scope_cannot_be_bound_safely'
  hold(z,reason);return z
 if len(parts)==2:
  if oldfam=='area' and tags <= {'位置通勤','房源状态'}:
   setplan(z,'area_two_spans',{'place_a':parts[0],'place_b':parts[1]},[bind('place_a',parts[0],basis=regs[0]['quote']),bind('place_b',parts[1],basis=regs[0]['quote'])],'split_demand_action_into_two_continuous_literal_location_slots_keep_radius')
  else:hold(z,'noncontinuous_region_requires_more_condition_slots');return z
 elif len(parts)==1:
  rr=regs[0];value=parts[0]
  if oldfam in ('area','commute'):
   slot='place' if oldfam=='area' else 'destination'
   if p['fill'].get(slot)!=value:setplan(z,oldfam,{slot:value},[bind(slot,value,basis=rr.get('quote'))],partreason)
  elif oldfam=='requirements':
   values=p['fill']['requirements'].split('、');old_e=next((e for e in p['evidence'] if e.get('pool')=='位置通勤' and e.get('source_field')=='target_regions'),None)
   if old_e and old_e['quote'] in values and old_e['quote']!=value:
    values[values.index(old_e['quote'])]=value;ev=[bind('requirements',v,basis=rr.get('quote')) if v==value else copy.deepcopy(next(e for e in p['evidence'] if e['quote']==v)) for v in values];setplan(z,'requirements',{'requirements':'、'.join(values)},ev,partreason)
 # An already classified location question is not transformed into an availability request.
 ask_where=any(e.get('pool')=='位置通勤' and e.get('polarity')=='ask' and re.search(r'在哪里|在哪|哪里|何处|位置在哪',e.get('quote') or '') for e in p['literal_evidence'])
 if ask_where and len(parts)==1:
  rest=text.replace(parts[0],'');rest=re.sub(r'\[[^\]]*\]|[\s，,。！!？?～~]','',rest)
  ask_where=bool(re.fullmatch(r'(?:请问|你好|在|的)*(?:在哪(?:儿|里)?|哪里|何处)(?:啊|呀|呢|嘛|哈)*',rest))
 if ask_where and len(parts)==1 and oldfam=='area' and tags <= {'位置通勤','价格预算'}:
  f='price_location_about_place' if '价格预算' in tags else 'location_about_place';setplan(z,f,{'place':parts[0]},[bind('place',parts[0],basis=regs[0]['quote'])],'preserve_existing_location_question_instead_of_availability')
 # Exact qualitative price spans remain qualitative; no numeric budget unit is invented.
 if oldfam=='budget_fit' and relative.fullmatch(p['fill'].get('budget','')):
  setplan(z,'budget_low',{},[],'qualitative_price_to_budget_low_not_numeric_budget_slot')
 elif z['family']=='requirements':
  vals=z['fill']['requirements'].split('、');rel=[v for v in vals if relative.fullmatch(v)]
  if rel:
   rest=[v for v in vals if v not in rel]
   if rest:setplan(z,'budget_low_requirements',{'requirements':'、'.join(rest)},[e for e in z['evidence'] if e['quote'] in rest],'qualitative_price_in_family_not_awkward_requirements_phrase')
   else:setplan(z,'budget_low',{},[],'qualitative_price_to_budget_low_not_awkward_requirements_phrase')
 if oldfam=='budget_fit' and z['family']=='budget_fit':z['change_reasons'].append('cloned_budget_fit_template_removes_static_duplicate_budget; literal_amount_and_qualifier_unchanged')
 if not z['change_reasons']:z['change_reasons']=['same_family_and_literal_fill; metadata_separated_only']
 return z
def render(z):
 if not z['family']:return None
 return contract['families'][z['family']]['template'].format(**z['fill'])
def validate(z):
 r=sources[z['platform'],z['cid'],z['uid']];txt=r['comment_text'];assert hashlib.sha256(txt.encode()).hexdigest()==z['sourceSHA'];assert canonical(r['source_record'])==z['original_classification_sha256'];assert z['source_field_evidence']==nextp[z['platform'],z['cid'],z['uid']]['source_field_evidence']
 assert z['send_authorized'] is False and z['can_send_now'] is False
 for q in z['customer_requirements']:assert q['quote'] in txt and q['subject']=='own_demand'
 if z['family']:
  d=contract['families'][z['family']];assert set(z['fill'])==set(d['required_fill'])=={n for _,n,_,_ in string.Formatter().parse(d['template']) if n};assert not z['hold_reasons']
  for f,v in z['fill'].items():
   for span in v.split('、') if f=='requirements' else [v]:assert span in txt and any(e['field']==f and e['quote']==span for e in z['evidence']),('nonliteral',z['cid'],f,v)
  newtext=render(z);assert not re.search(r'预算[^，。]{0,18}预算',newtext);assert '蹲' not in ''.join(z['fill'].values());assert not(z['family']=='budget_fit' and relative.search(z['fill']['budget']))
  for q in z['metadata_cautions']:
   if q.get('kind')=='template_applicability_not_customer_demand':assert not any(e.get('source_field')=='missing_facts' for e in z['evidence'])
 else:assert z['hold_reasons']
nextp={(p['platform'],p['cid'],p['uid']):p for p in old}
def regression_row(q,z):
 before=nextp[q['platform'],q['cid'],q['uid']];after=render(z);checks=['same_comment_SHA_original_role_state_interest_and_evidence']
 if q['verdict']=='hold':assert z['clarification_only'];checks.append('existing_uncertainty_retained_as_question_not_fact')
 if q['verdict']=='change_plan_only':
  assert after
  if before['family']=='budget_fit' and not relative.fullmatch(before['fill']['budget']):assert z['fill']['budget']==before['fill']['budget'];checks.append('budget_amount_qualifier_period_literal_unchanged_no_static_duplicate')
  if '附近' in q['reason']:assert '附近' in after;checks.append('nearby_scope_restored')
  if '5公里' in q['evidence_comment_quote']:assert '5公里' in after and '蹲' not in ''.join(z['fill'].values());checks.append('radius_preserved_demand_action_removed')
  if '相对' in q['reason'] or '截成' in q['reason']:assert z['family'] in ('budget_low','budget_low_requirements');checks.append('qualitative_budget_family')
  if '问位置' in q['reason']:assert z['family'] in ('location_about_place','price_location_about_place');checks.append('location_question_not_availability')
 return {'sample_index':q['sample_index'],'platform':q['platform'],'cid':q['cid'],'uid':q['uid'],'sourceSHA':z['sourceSHA'],'old_qa_verdict':q['verdict'],'old_qa_reason':q['reason'],'old_family':before['family'],'old_fill':before['fill'],'v2_family':z['family'],'v2_fill':z['fill'],'v2_preview_for_regression_only':after,'v2_clarification_only':z['clarification_only'],'change_reasons':z['change_reasons'],'source_classification_unchanged':True,'regression_status':'clarification_preserves_original_uncertainty' if z['clarification_only'] else 'specific_hold_preserved' if not z['family'] else 'plan_repaired' if q['verdict']!='pass' else 'previous_QA_grade_retained_mechanical_field_regression_only','regression_checks':checks,'fresh_semantic_grade_issued':False,'used_for_remediation_not_fresh_holdout':True}
if __name__=='__main__':
 stage=sys.argv[1] if len(sys.argv)>1 else 'pilot'
 if stage=='pilot':
  sample=[q for q in qa if q['verdict']!='pass'];out=[]
  for q in sample:
   z=transform(nextp[q['platform'],q['cid'],q['uid']]);validate(z);out.append(regression_row(q,z))
  put(O/'pilot-contract.json',contract);putjl(O/'pilot-17-regression.jsonl',out);print(json.dumps(out,ensure_ascii=False,indent=1));sys.exit()
 assert stage=='full'
 pilot=jl(O/'pilot-17-regression.jsonl');assert len(pilot)==17
 result=[transform(p) for p in old]
 for z in result:validate(z)
 resultidx={(z['platform'],z['cid'],z['uid']):z for z in result};put(O/'local-mother-contract-v2.json',contract);putjl(O/'local-proposed-plans.jsonl',result)
 changes=[{'platform':z['platform'],'cid':z['cid'],'uid':z['uid'],'sourceSHA':z['sourceSHA'],'previous_plan_sha256':z['previous_plan_sha256'],'v2_plan_sha256':canonical(z),'previous_family':z['previous_family'],'v2_family':z['family'],'old_fill':nextp[z['platform'],z['cid'],z['uid']]['fill'],'v2_fill':z['fill'],'change_reasons':z['change_reasons'],'classification_changed':False,'metadata_caution_count':len(z['metadata_cautions'])} for z in result];putjl(O/'per-record-repair-receipts.jsonl',changes)
 regress=[regression_row(q,resultidx[q['platform'],q['cid'],q['uid']]) for q in qa];putjl(O/'old-qa-200-regression.jsonl',regress)
 boundary=[{'original_QA':n,'v2_action':'preserve_original_no_new_draft_and_role_caution_only','no_classification_change':True,'no_new_reply':True} for n in negative];putjl(O/'old-qa-negative-30-preserved.jsonl',boundary)
 # Published batch scan uses only the 241 rendered non-null plans, keeps their original bytes, and emits proposals only.
 published=[r for r in jl(B/'pool-short-reply-plans.jsonl') if r['rendered'].get('text')];assert len(published)==241
 bi={r['review_key']:r for r in jl(B/'input.jsonl')};sem={r['review_key']:r for r in jl(B/'semantic-final.jsonl')};scan=[]
 for r in published:
  mother=r['local_mother'];f=mother['family'];fill=mother['fill'];own=bi[r['review_key']]['comment_text'];findings=[];proposed=None
  if f=='budget_fit' and '预算' in fill.get('budget',''):findings.append('same_static_budget_word_duplicate');proposed={'family':f,'fill':fill,'requires_cloned_contract':True}
  if f=='budget_fit' and relative.fullmatch(fill.get('budget','')):findings.append('qualitative_price_in_numeric_budget_slot');proposed={'family':'budget_low','fill':{}}
  if f=='requirements' and any(relative.fullmatch(v) for v in fill.get('requirements','').split('、')):findings.append('qualitative_price_inside_requirements_needs_family_review')
  if any('蹲' in v for v in fill.values()):findings.append('demand_action_inside_literal_slot')
  sr=sem[r['review_key']];regs=sr.get('target_regions') or []
  for rr in regs:
   parts,_=locparts(rr,own)
   if len(parts)==1:
    oldvals=[e['quote'] for e in mother.get('evidence',[]) if e.get('field') in ('place','destination','requirements') and (e['quote'] in (rr.get('quote') or '') or e['quote']==rr.get('text'))]
    if oldvals and parts[0] not in ''.join(fill.values()) and any(oldv in parts[0] for oldv in oldvals):
     findings.append('spatial_scope_suffix_not_retained')
     if f in ('area','commute'):
      slot='place' if f=='area' else 'destination';proposed={'family':f,'fill':{slot:parts[0]},'evidence':[{'field':slot,'quote':parts[0],'existing_AI_quote':rr.get('quote')}],'requires_cloned_contract':False}
  if f=='area' and any(e.get('pool')=='位置通勤' and e.get('polarity')=='ask' and re.search(r'在哪|哪里',e.get('quote') or '') for e in sr.get('topics',[]) if isinstance(e,dict)):findings.append('location_question_may_have_become_availability')
  if 'qualitative_price_inside_requirements_needs_family_review' in findings:
   rest=[v for v in fill['requirements'].split('、') if not relative.fullmatch(v)]
   if all(v in own for v in rest):proposed={'family':'budget_low_requirements' if rest else 'budget_low','fill':{'requirements':'、'.join(rest)} if rest else {},'evidence':[{'field':'requirements','quote':v} for v in rest],'requires_cloned_contract':bool(rest)}
  if findings:scan.append({'review_key':r['review_key'],'cid':r['comment_id'],'uid':r['customer_uid'],'sourceSHA':r['source_comment_sha256'],'source_plan_file_sha256':sha(B/'pool-short-reply-plans.jsonl'),'old_family':f,'old_fill':fill,'source_comment':own,'existing_literal_evidence':mother.get('evidence'),'existing_regions':regs,'issue_types':list(dict.fromkeys(findings)),'proposed_plan_only':proposed,'published_bytes_modified':False,'applied':False})
 putjl(O/'published-241-proposed-fixes.jsonl',scan)
 for path,h in protected.items():assert sha(path)==h,('protected_source_changed',path)
 stats={'candidates':len(result),'v1_bound':sum(bool(p['family']) for p in old),'v2_bound_including_clarifications':sum(bool(p['family']) for p in result),'v2_housing_family_plans':sum(bool(p['family']) and not p['clarification_only'] for p in result),'v2_clarification_only':sum(p['clarification_only'] for p in result),'v2_held':sum(not p['family'] for p in result),'family_counts':dict(collections.Counter(p['family'] for p in result if p['family'])),'plan_or_contract_behavior_changed':sum(z['change_reasons'] not in (['same_family_and_literal_fill; metadata_separated_only'],['original_specific_hold_preserved; metadata_separated_only']) for z in result),'newly_held_from_v1_bound':sum(bool(z['previous_family']) and not z['family'] for z in result),'source_metadata_template_caution_records':sum(any(m['kind']=='template_applicability_not_customer_demand' for m in z['metadata_cautions']) for z in result),'QA_metadata_all_caution_records_preserved':sum(bool(z.get('qa_source_plan_metadata_cautions_preserved')) for z in result),'QA_metadata_14_template_applicability_preserved':sum(any(re.search(r'家庭整租|全部必付费用上限',m.get('quote','')) for m in z.get('qa_source_plan_metadata_cautions_preserved',[])) for z in result),'old_QA_200_regression':len(regress),'old_QA_17_fixed_or_clarified':sum(q['old_qa_verdict']!='pass' and bool(q['v2_family']) for q in regress),'published_batch_scanned':len(published),'published_budget_fit_scanned':sum(r['local_mother']['family']=='budget_fit' for r in published),'published_exact_budget_duplicate_cases':sum('same_static_budget_word_duplicate' in x['issue_types'] for x in scan),'published_batch_proposed_fix_records':len(scan),'published_issue_counts':dict(collections.Counter(i for x in scan for i in x['issue_types']))}
 manifest={'created_at':datetime.datetime.now().astimezone().isoformat(),'scope':'local plans, cloned contract, regression and published-batch proposals only','protected_sources_sha256':protected,'input_plan_sha256':sha(P/'local-proposed-plans.jsonl'),'old_contract_sha256':sha(B/'local-mother-contract.json'),'v2_contract_sha256':sha(O/'local-mother-contract-v2.json'),'v2_plan_sha256':sha(O/'local-proposed-plans.jsonl'),'planner_sha256':sha(__file__),'source_writes':0,'pointer_changes':0,'published_source_byte_changes':0,'classification_changes':0,'new_API_or_model_calls':0,'platform_calls':0,'send_attempts':0,'applied':False,'usage':'unknown'};put(O/'plan-source-manifest.json',manifest)
 checks={'all_12963_CID_UID_source_SHA_and_original_classification_match':len(result)==12963,'literal_parameters_and_contract_fields':True,'no_budget_word_duplication':True,'no_demand_action_in_region_slots':True,'customer_requirements_from_own_evidence_only':True,'original_fact_gap_arrays_preserved_not_requirements':True,'all_protected_source_hashes_unchanged':True,'old_200_QA_is_regression_not_new_holdout':True,'negative_30_roles_states_preserved':len(boundary)==30,'published_241_read_only':len(published)==241,'no_source_pointer_platform_API_or_send_action':True}
 validation={'all_passed':all(checks.values()),'checks':checks,'statistics':stats,'technical_coverage_not_accuracy':True,'independent_second_QA_v2_not_performed':True,'source_manifest_sha256':sha(O/'plan-source-manifest.json'),'outputs_sha256':{n:sha(O/n) for n in ['local-proposed-plans.jsonl','local-mother-contract-v2.json','per-record-repair-receipts.jsonl','old-qa-200-regression.jsonl','old-qa-negative-30-preserved.jsonl','published-241-proposed-fixes.jsonl']}};put(O/'validation.json',validation);put(O/'repair-summary.json',stats)
 report=['# 历史本地计划修复第二版','','本次只写新目录，原规划、QA、源分类、合同、当前消费、50条用户稿及已发布字节全部保留。未调用模型/API、平台或发送。',f'全量 {len(result):,} 条计划：本地住房家族 {stats["v2_housing_family_plans"]:,} 条，最小确认接话 {stats["v2_clarification_only"]:,} 条，具体待核 {stats["v2_held"]:,} 条。技术覆盖不是准确率或可发送率。','','修复按共性执行：预算槽与静态模板去重；保留附近/沿线/半径；需求动作与地点拆槽；相对便宜改家族；问位置不改有无房；现有未决关系改确认问题；明确住宅用途待核且缺正文的个人转租只问对象。不是逐ID补丁。','','17条旧QA问题先做难例回归，再扩到全量。200条旧QA用于整改回归，不能称新留出准确率。30条阴性原状态保留；角色证据不足那一例仅留原提醒，未擅重分类。',f'原QA中14条模板元数据提醒原样保留；全量 {stats["source_metadata_template_caution_records"]} 条有家庭整租/全费用上限模板适用条件提醒。客户条件独立从本人逐字证据提取，原事实缺口数组不倒灌。',f'241条已发布短计划仅扫描，找到 {len(scan)} 条拟修，详见 published-241-proposed-fixes.jsonl；没有改其字节。','','剩余缺口：原有复杂条件/主体/时间/多地关系未决、旧结构证据不足与无合适组合家族仍保留具体hold；本轮不以补覆盖为由重新判意向。确认接话不是关系或住宅已确认；住户身份、推荐资格、门店优惠、当前意向、真实同店房源及许可仍须原流程核实。','','本地字段、字面、预算重复、源指纹及原判不变验证通过；新合同/新计划未接消费指针，待主窗口审阅。用量未知。','',json.dumps(stats,ensure_ascii=False,indent=2)]
 (O/'report.md').write_text('\n'.join(report)+'\n',encoding='utf8');print(json.dumps(stats,ensure_ascii=False,indent=2))
