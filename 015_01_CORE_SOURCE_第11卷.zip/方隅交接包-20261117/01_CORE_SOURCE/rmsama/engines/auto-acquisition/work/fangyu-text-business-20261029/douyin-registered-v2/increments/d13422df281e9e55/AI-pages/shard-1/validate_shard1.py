import json,pathlib,hashlib,collections,importlib.util,datetime
P=pathlib.Path(__file__).resolve().parent;B=P.parent.parent;W=B.parents[2]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return [json.loads(x) for x in p.read_text(encoding='utf-8-sig').splitlines() if x.strip()]
source=read(B/'shard-1.jsonl'); source_index={r['review_key']:r for r in source}
pages=[P/f'reviewed-{i:02}.jsonl' for i in range(4)]
joined=b''.join(p.read_bytes() for p in pages)
out=B/'reviewed-new-1.jsonl'
out.write_bytes(joined)
rows=read(out)
assert len(rows)==len(source)==692
idfields=('review_key','comment_id','customer_uid','video_id','platform')
identity=lambda r:tuple(r[f] for f in idfields)
assert len(set(identity(r) for r in rows))==len(rows)
assert set(identity(r) for r in rows)==set(identity(r) for r in source)
assert [r['review_key'] for p in pages for r in read(p)]==[r['review_key'] for r in rows]
assert out.read_bytes()==joined
quotes=0
for row in rows:
 s=source_index[row['review_key']]['comment_text']
 assert row['human_confirmed'] is False and row['send_authorized'] is False and row['store_assignment'] is None
 assert 'classification_method' not in row and 'classification_stages_completed' not in row and 'classification_review_source' not in row
 assert row['reply_plan']['preferred_mother_slot'] in (None,1,2,7,13,16,19,25,28,31,34)
 assert 'reply_text' not in row and 'draft_text' not in row
 for field in ('topics','target_regions','time_mentions','other_constraints','possible_topics','contact_boundaries'):
  for item in row[field]:
   if isinstance(item,dict) and 'quote' in item:
    assert isinstance(item['quote'],str) and item['quote'] in s,(row['review_key'],field,item['quote'])
    quotes+=1
 assert all(e in s for e in row['evidence'])
# The real adapter is imported unchanged. Both isolated files live inside the frozen batch.
adapter=W/'mother_adapter.py'; adapter_sha=sha(adapter)
spec=importlib.util.spec_from_file_location('real_mother_adapter',adapter);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
isolated=[]
for row in rows:
 r=dict(row)
 r.update(classification_method='ai_semantic_initial_and_detailed',classification_stages_completed=['initial_semantic','detailed_semantic'])
 isolated.append(r)
bound=P/'adapter-isolated-source.jsonl'
bound.write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in isolated),encoding='utf-8')
digest=sha(bound)
transport=[]
for row in isolated:
 r=dict(row);r['classification_review_source']={'path':str(bound.relative_to(B)).replace('\\','/'),'sha256':digest};transport.append(r)
transport_file=P/'adapter-isolated-transport.jsonl'
transport_file.write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in transport),encoding='utf-8')
cache={};errors=[]
for row in read(transport_file):
 try:m.validate_new_review(row,B,cache)
 except Exception as e:errors.append(str(e))
assert sha(adapter)==adapter_sha
validation={'shard':1,'batch':'d13422df281e9e55','input_count':len(source),'output_count':len(rows),'identity_fields':list(idfields),'identity_sets_equal':True,'duplicate_keys':0,'page_counts':[len(read(p)) for p in pages],'page_concatenation_exact':True,'verbatim_quote_checks':quotes,'verbatim_quote_failures':0,'evidence_verbatim':True,'formal_review_sha256':sha(out),'page_sha256':{p.name:sha(p) for p in pages},'adapter':'mother_adapter.validate_new_review','adapter_sha256':adapter_sha,'adapter_unmodified':True,'adapter_checked':len(rows),'adapter_passed':len(rows)-len(errors),'adapter_errors':errors,'isolated_source':str(bound.relative_to(B)).replace('\\','/'),'isolated_source_sha256':digest,'isolated_transport':str(transport_file.relative_to(B)).replace('\\','/'),'isolated_transport_sha256':sha(transport_file),'metadata_scope':'classification metadata added only to isolated precheck; compiler must bind final review SHA','classification_method':'ai_semantic_initial_and_detailed','classification_stages_completed':['initial_semantic','detailed_semantic'],'independent_review':False,'human_confirmed':False,'send_authorized':False,'store_assignment':None,'platform_calls':0,'usage':'unknown','interest_counts':dict(collections.Counter(x['interest'] for x in rows)),'role_counts':dict(collections.Counter(x['role'] for x in rows)),'contact_policy_counts':dict(collections.Counter(x['reply_plan']['contact_policy'] for x in rows)),'mother_slot_counts':dict(collections.Counter(str(x['reply_plan']['preferred_mother_slot']) for x in rows))}
(B/'shard-1-validation.json').write_text(json.dumps(validation,ensure_ascii=False,indent=2),encoding='utf-8')
progress={'shard':1,'status':'completed_initial_and_detailed_pending_independent_review','completed_pages':[0,1,2,3],'processed':692,'expected':692,'formal_review_sha256':sha(out),'adapter_checked':692,'adapter_errors':errors,'human_confirmed':False,'send_authorized':False,'usage':'unknown'}
(P/'progress.json').write_text(json.dumps(progress,ensure_ascii=False,indent=2),encoding='utf-8')
report='''# 抖音本片语义判读报告

已逐条完成本片692条AI语义初筛与细筛，逐页落盘为180、180、180、152条。正式文件与四页逐字节连接一致，五项身份与原片集合完全相等，无重复或漏项。

正式适配器母句校验已对692条在真实隔离文件中完成，错误{errors}条。隔离文件单独补入实际同轮初细筛方法与阶段并绑定SHA；正式评审未冒充独立二审或人工认可，待主任务独立复核及compiler正式绑定。

意向数量：{interest}。角色数量：{roles}。这些是评论时的模型判断，不代表今日仍找房、用户金标或平台发送许可。

引文共核{quotes}项，全部逐字来自本人评论。裸“多少米”和不明数字保留歧义；明确每月计价不作总租期。源帖预算、宠物、户型及供给事实不移给评论者。医疗目的地、工作地、现住地和询问位置分别保留。家庭主动代求租保留有效意向。停车、朝向、拒公寓、原房东身份限制、原帖一年起租与只租一月冲突均保留。

母句仅给槽位及reply_plan，不新写正文；现有价格、库存、优惠、住户身份、门店适配均未核实。无适合公寓接法的拒公寓评论保留需求且不推销。联系allow只代表原评未限制，不是发送许可。

原初筛字节保存在本片initial-reviewed各页，细筛补充脚本和逐key显式决定也在本片目录；没有格式兼容改写冒充无语义变化。未读深层回复保留未读，不补父评。源数据、平台、发送和其他分片均未修改；实际credits usage未知。

正式评审SHA256：{sha}
隔离源SHA256：{isolated}
正式适配器SHA256：{adapter}

本片已停止，交主任务独立复核。
'''.format(errors=len(errors),interest=json.dumps(validation['interest_counts'],ensure_ascii=False),roles=json.dumps(validation['role_counts'],ensure_ascii=False),quotes=quotes,sha=sha(out),isolated=digest,adapter=adapter_sha)
(B/'shard-1-report.md').write_text(report,encoding='utf-8')
print(json.dumps(validation,ensure_ascii=False,indent=2))
assert not errors,errors
