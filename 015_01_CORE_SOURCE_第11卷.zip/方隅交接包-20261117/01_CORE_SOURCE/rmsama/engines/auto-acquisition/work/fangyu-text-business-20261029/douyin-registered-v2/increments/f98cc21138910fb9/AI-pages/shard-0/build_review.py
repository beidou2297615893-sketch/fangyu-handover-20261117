"""Render explicitly authored per-key AI decisions; no keyword classification."""
import json,hashlib,sys,collections,shutil
from pathlib import Path
P=Path(__file__).resolve().parent
B=P.parent.parent
W=B.parent.parent.parent
for previous in (B/'reviewed-new-0.jsonl',P/'reviewed-00.jsonl',P/'reviewed-01.jsonl'):
 if previous.exists():
  backup=P/'before-detailed-corrections'/previous.name
  backup.parent.mkdir(exist_ok=True)
  if not backup.exists():shutil.copyfile(previous,backup)
sources=[json.loads(s) for s in (B/'shard-0.jsonl').read_text(encoding='utf-8').splitlines()]
src={s['review_key']:s for s in sources}
classes={'D':('discussion','unknown','unrelated'),'U':('unknown','unknown','uncertain'),'M':('demand','unknown','medium'),'H':('demand','active_at_comment','high'),'S':('demand','active_at_comment','super_high'),'E':('demand','ended','unrelated'),'B':('demand','active_at_comment','low')}
def topic(pool,quote,polarity='ask',subject='own_demand',scope=None):
 return dict(pool=pool,quote=quote,polarity=polarity,subject=subject,condition_scope=scope)
def region(text,quote=None,relation='desired',group='unknown',scope=None):
 return dict(text=text,quote=quote or text,relation=relation,group_relation=group,condition_scope=scope)
def tm(key,quote,role,verification,normalized=None):
 return dict(quote=quote,time_role=role,anchor_source='本人评论发表时间',anchor_time=src[key].get('published_at_unix') and __import__('datetime').datetime.fromtimestamp(src[key]['published_at_unix'],__import__('datetime').timezone.utc).isoformat(),normalized=normalized,verification=verification)
def con(quote,detail): return dict(quote=quote,detail=detail)
place={
'D0043':'浦东','D0124':'宁国路和龙华中间','D0127':'8号线.11号线','D0130':'七宝站附近','D0133':'江桥14号线附近','D0178':'临平万达附近','D0184':'上城区','D0193':'余杭区文一西路符近','D0304':'闵行','D0391':'余杭区','D0397':'临平','D0400':'富阳东洲','D0412':'下门区','D0430':'浦东','D0436':'金山区','D0439':'宝山 大华第一坊附近','D0442':'松江泗泾','D0598':'周浦','D0604':'宝山共富新村地铁站附近','D0607':'江湾镇','D0718':'火炬莲花科创园附近','D0724':'宝山共富或者大场这边','D0727':'浦建路巴黎春天附近','D0733':'联洋金桥洋泾这边','D0802':'萧山'}
req={
'D0019':'一室一厅','D0031':'短租吗？中介费多少','D0181':'拱墅区能有短租2个月','D0187':'钱塘区下沙附近有没有1000左右朝南带独立卫生间和厨房的房子','D0298':'下周就要入职了，很急！！！\n预算3000，离徐汇区近的\n朝南，可合租','D0340':'客厅，燃气，张江小区房','D0370':'离地铁近吗','D0421':'厨房和卧室一定要分开','D0424':'离地铁近吗','D0433':'巨峰路附近有无一千五的合租独卫','D0454':'上海市中心租房的话，中介费一般怎么算','D0517':'这里房子怎么样，地铁早上要排队吗？人流量多不多','D0523':'空调暖气','D0559':'合适的套二','D0562':'正儿八经干净点的套一','D0565':'12月去成都','D0580':'真七百我租，马上','D0592':'静安区两千以下我都租不到房子全是四壁间','D0601':'杨浦公园附近有没有房东或者转租的呀，预算单人1500-2500','D0676':'中介给我找到这种房子才配让我付中介费','D0712':'仓山万达附近的民水民电','D0730':'地铁可直达徐家汇地铁站 地铁通勤时间30-40分钟','D0781':'免费住','D0790':'多少钱，还有吗'}
slots={'price':1,'location':31,'available':34,'area':31,'area_room':34,'price_location':31,'budget_fit':2,'requirements':34,'topic_unspecified':7,'elevator':16}
common_gap='真实住户身份、介绍资格及当前优惠门店时效条件未核'
def make(key,code,family,reason,page):
 s=src[key]; role,state,interest=classes[code]; text=s['comment_text']
 row={k:s[k] for k in ('review_key','platform','comment_id','customer_uid','video_id')}
 row.update(role=role,demand_state=state,interest=interest,topics=[],target_regions=[],time_mentions=[],other_constraints=[],possible_topics=[],evidence=[text] if text else [],reason=reason,context_used=['own','body'],needs_review=[],contact_boundaries=[],context_flags={'same_author':s['post_author_same_as_commenter'],'source_version_conflict':s['source_version_conflict'],'page':page,'own_conditions_only':True},human_confirmed=False,send_authorized=False,store_assignment=None)
 plan=dict(preferred_mother_slot=None,generic_intro_suitable=False,tone='normal',missing_facts=[],caution=[],contact_policy='allow',local_mother=None)
 if family!='-':
  fill={}; ev=[]
  if family=='area': fill={'place':place[key]}
  elif family=='area_room': fill={'place':'三林','room':'两室一厅'}
  elif family=='budget_fit': fill={'budget':'三千'}
  elif family=='requirements': fill={'requirements':req[key]}
  for field,value in fill.items(): ev.append({'field':field,'quote':value})
  plan.update(preferred_mother_slot=slots[family],local_mother={'family':family,'fill':fill,'evidence':ev},missing_facts=[common_gap,'同店同一有效房源满足本人条件及所询价格、房态、位置或设施尚未核实'],caution=['仅母句家族及字面参数计划；新微调未逐条人工认可；不构成库存承诺或发送授权'])
  if code=='M': plan['caution'].append('先确认本人当前租房动作及所询对象，不能把关注当已确认在租')
  if family=='price': row['topics']=[topic('价格预算',text)]
  elif family=='location': row['topics']=[topic('位置通勤',text)]
  elif family=='price_location': row['topics']=[topic('价格预算',text),topic('位置通勤',text)]
  elif family=='available': row['topics']=[topic('房源状态',text)]
  elif family=='area':
   row['topics']=[topic('位置通勤',place[key])]
   row['target_regions']=[region(place[key])]
  elif family=='area_room': row['topics']=[topic('位置通勤','三林'),topic('户型面积与居住方式','两室一厅'),topic('房源状态','有没有')];row['target_regions']=[region('三林')]
  elif family=='budget_fit': row['topics']=[topic('价格预算','预算三千','require')]
  elif family=='elevator': row['topics']=[topic('楼层电梯','必须要电梯房','require',scope='此价格下；本人当前找房与给作者建议待区分')]
 else:
  plan['caution']=['无合适母句接法：'+reason]
  if code=='U': plan['contact_policy']='unknown'
 row['reply_plan']=plan
 if code in ('M','U'): row['needs_review'].append(reason)
 if role=='demand' and state=='active_at_comment': row['needs_review'].append('仅认定评论发表时动作，当前仍需租及实际匹配房态未核')
 return row
def customize(r):
 k=r['review_key'];s=src[k];p=r['reply_plan'];t=s['comment_text']
 T=r['topics'];R=r['target_regions'];C=r['other_constraints'];N=r['needs_review']
 if k=='D0001': r['possible_topics']=[{'pools':['看房联系'],'ambiguity':'心累可能为当前找房或既往经验，缺当期动作'}]
 if k=='D0004': T.extend([topic('价格预算','好贵啊3000多','reject',scope='对所见租金否定，非本人预算'),topic('入住与租期','打消了我想租房的念头','fact')])
 if k=='D0022': T.append(topic('房源状态',t,'compare','unresolved'));N.append('对比上大仅评价，不足以认定工作地或目标地区')
 if k=='D0031':
  T.extend([topic('入住与租期','可以短租吗','ask'),topic('费用合同','中介费多少','ask')]);N.append('短租具体时长未说，中介费与房态均未核');p['preferred_mother_slot']=19
 if k=='D0040': R.append(region('浦东',relation='unresolved'));r['possible_topics']=[{'pools':['房源状态'],'ambiguity':'有租房买房的人吗可能揽客，尚不能确定供需'}]
 if k=='D0055':
  T.extend([topic('房源状态','最后决定租保租房了','fact'),topic('宠物','我不养猫','not_required')]);N.extend(['决定保租房未等于已完成签约','是否愿考虑商业公寓需本人确认']);p['tone']='serious'
 if k=='D0058': C.append(con('房东人一定要好','房东人品要求，未证明当期找房'));N.append('须确认是否近期仍在找房，未选强推母句')
 if k=='D0124': R[:]=[region('宁国路','宁国路和龙华中间',group='AND',scope='宁国路与龙华之间'),region('龙华','宁国路和龙华中间',group='AND',scope='两端区间，不要求同时位于两处')]
 if k=='D0127': R[:]=[region('8号线',group='unknown'),region('11号线',group='unknown')];N.append('两线路是任选或换乘范围不明')
 if k=='D0136':
  T.append(topic('费用合同','取暖收费问了好多都是统一400每月','fact','unresolved',scope='询得报价不是本人预算'));N.append('可能是正在询房，也可能仅了解现居收费')
 if k=='D0139': r['time_mentions']=[tm(k,'今天','other','本人发表日暖气流水现象，不是入住日期', '2026-10-25')]
 if k=='D0142': r['time_mentions']=[tm(k,'26号试供暖','other','供暖通知日并非入住；按发表月可能10月26日，未核不归一')]
 if k=='D0145': C.append(con('电动自行车充电桩','仅公共充电位置咨询，不能视为租房配套要求'));R.append(region('天泰宾馆附近',relation='unresolved',scope='公共充电查询地，非租住目标'))
 if k=='D0181':
  T.extend([topic('位置通勤','拱墅区'),topic('入住与租期','短租2个月','require')]);R.append(region('拱墅区'));r['time_mentions']=[tm(k,'2个月','lease_duration','明确租赁总期限，无需归一','P2M')];p['preferred_mother_slot']=19
 if k=='D0184': R[:]=[region('上城区',relation='unresolved',scope='攻略总结查询区，是否个人租住目标待核')]
 if k=='D0187':
  T.extend([topic('位置通勤','钱塘区下沙附近','require'),topic('价格预算','1000左右','require',scope='计费周期未自报，不添加每月'),topic('房内设施','朝南带独立卫生间和厨房','require')]);R.append(region('钱塘区下沙附近'));C.append(con('朝南','房间朝向要求与独卫厨房预算区位同房联立'));p['missing_facts'].append('一套房同时满足朝南、独卫厨房、区位和原口径预算尚未核实')
 if k=='D0190': T.append(topic('费用合同','商用水电','fact','unresolved'));r['time_mentions']=[tm(k,'前两天','other','相对实地了解时间，以本人发表时间为锚，不当入住日期')]
 if k=='D0193': N.append('符近为本人原字，未静默更改；实际目标边界需核')
 if k=='D0211': r['demand_state']='historical';T.extend([topic('户型面积与居住方式','一室一厅整租','fact','supply'),topic('价格预算','加了三分之一的价格','fact','supply')])
 if k=='D0220': T.append(topic('楼层电梯','他们住一楼我们住三楼','fact','current_home'))
 if k=='D0229': T.append(topic('价格预算','10500','fact','other_person'));R.append(region('瑞虹六期 星星堂楼上',relation='unresolved',scope='朋友现居，不能移作本人目标'))
 if k=='D0232': R.append(region('黄埔','黄埔吗',relation='unresolved',scope='猜测所见房源地名，不更正为黄浦'))
 if k=='D0241': R.append(region('万源经典',relation='unresolved'));N.append('不能把只报小区名直接认作求租目标')
 if k=='D0244': T[:]=[topic('价格预算','能聊多少钱呢','ask')];N.append('1.2可能指第1、2套而非金额，不作为预算或报价')
 if k=='D0268': r['possible_topics']=[{'pools':['房源状态'],'ambiguity':'另外一套可能询库存也可能催看视频内容'}]
 if k=='D0274': T.extend([topic('户型面积与居住方式','我们三家合租','fact','current_home'),topic('费用合同','水费3个月不到100块钱','fact','current_home')]);r['time_mentions']=[tm(k,'3个月','other','水费累计期间，不是拟租总期限')]
 if k=='D0283': T.append(topic('房源状态',t));C.append(con(t,'所询为帖子明确办公空间，不确定住宅租赁'));N.append('办公房非当前住宅母句承接范围')
 if k=='D0286': N.append('一个月用于租金计价提问，没有明确只租一个月，不录租期')
 if k=='D0298':
  T.extend([topic('价格预算','预算3000','require',scope='未说月计价，不添加每月'),topic('位置通勤','离徐汇区近的','require'),topic('房内设施','朝南','require'),topic('户型面积与居住方式','可合租','accept'),topic('看房联系','有合适的私我！！带图来','require')]);R.append(region('徐汇区','离徐汇区近的',scope='要求近徐汇区，不要求位于区内'))
  r['time_mentions']=[tm(k,'下周就要入职了','other','入职节点而非明确入住日期；相对本人发表日，非今天')]
  C.extend([con('很急','急找房，但未明确签约或约看时段'),con('推荐也有偿','表示愿付推荐报酬，不是方隅优惠或价格事实')]);r['contact_boundaries']=[{'quote':'有合适的私我！！带图来','scope':'明确希望合适房源带图片私信；并非本任务发送授权'}];p['caution'].append('联系条件为合适且带图，推荐有偿不等于已确认佣金')
 if k=='D0301': T.append(topic('房源状态','现场实地拍摄','fact','supply'))
 if k=='D0340': T.extend([topic('户型面积与居住方式','客厅','require'),topic('房内设施','燃气','require'),topic('位置通勤','张江小区房','require')]);R.append(region('张江'));C.append(con('小区房','要求小区住宅类型，不能仅以公寓替代'))
 if k in ('D0370','D0424'): T.append(topic('位置通勤','离地铁近吗','ask'));N.append('本人未给具体站点或步行阈值，不借正文填入')
 if k=='D0403': N.append('两千多是他人推荐报价，未声明本人预算上限')
 if k=='D0412': N.append('下门区具体所指未知，不自动改厦门或其他区名')
 if k=='D0421': T.append(topic('房内设施','厨房和卧室一定要分开','require','unresolved',scope='可能本人标准或对作者建议，待核当期需求'))
 if k=='D0433': T.extend([topic('位置通勤','巨峰路附近','require'),topic('价格预算','一千五','require',scope='本人未明确周期，不加每月'),topic('户型面积与居住方式','合租','require'),topic('房内设施','独卫','require')]);R.append(region('巨峰路附近'))
 if k=='D0454': T.extend([topic('位置通勤','上海市中心','ask'),topic('费用合同','中介费一般怎么算','ask')]);R.append(region('上海市中心',relation='unresolved',scope='费用查询范围，是否具体住宅目标待核'));p['preferred_mother_slot']=25
 if k=='D0496': C.append(con('这次是买的','明确买房动作，不能作为求租'));r['time_mentions']=[tm(k,'最近也在看房子','other','明确为购房，不当租赁找房时间')]
 if k=='D0517': T.append(topic('位置通勤','地铁早上要排队吗？人流量多不多','ask'));C.append(con('这里房子怎么样','房屋质量与通勤拥挤评估，未说预约看房'))
 if k=='D0523': T.append(topic('房内设施','空调暖气','ask'));N.append('空调和暖气须同一所询房源核实')
 if k=='D0526': T.extend([topic('入住与租期','一个月一个月的租','fact','current_home'),topic('费用合同','押金300','fact','current_home'),topic('价格预算','租金700','fact','current_home')]);r['time_mentions']=[tm(k,'一个月一个月的租','lease_duration','描述现居按月续租，不是新找房期限','P1M')]
 if k=='D0535': R.append(region('高教大楼',relation='unresolved',scope='确认所见楼名，未明确租住目标'))
 if k=='D0538': R.append(region('余杭区瓶窑镇凤都工业园区',relation='unresolved'));N.append('地名性质未明，不能当desired或work，也不选area断言目标')
 if k=='D0556': T.extend([topic('户型面积与居住方式','老房子','fact','current_home'),topic('价格预算','很便宜','fact','current_home')])
 if k=='D0559': T.extend([topic('户型面积与居住方式','合适的套二','require')]);R.append(region('金牛区',relation='current_home',scope='本人说我就是金牛区，未明确新房必须在此'));N.append('金牛区为本人现处地，是否目标范围需确认')
 if k=='D0562': T.extend([topic('户型面积与居住方式','套一','require'),topic('房内设施','正儿八经干净点','require'),topic('价格预算','租房都好贵','reject')]);R.append(region('高新','工作在高新这边',relation='work'));N.append('高新是工作目的地，需确认可接受通勤；未给金额预算');p['caution'].append('不将工作地高新默认为居住区')
 if k=='D0565':
  R.append(region('成都'));T.extend([topic('位置通勤','成都','require'),topic('入住与租期','12月去成都','ask',scope='抵达月份，具体入住日未给')]);r['time_mentions']=[tm(k,'12月去成都','move_in','发表时2026年9月，十二月抵达成都；未明确入住日及总租期','2026-12')];N.append('去成都时间不等于精确入住日，租期预算未说')
 if k=='D0568': T.extend([topic('价格预算','租贵了','fact','current_home'),topic('房内设施','装修很差房东什么旧家具都留着','fact','current_home')]);N.append('现居不满不能直接当已明确换房，也不整体判无机会')
 if k=='D0571': r['demand_state']='historical';T.extend([topic('户型面积与居住方式','套三','fact','current_home'),topic('价格预算','1300','fact','current_home')]);r['time_mentions']=[tm(k,'找了一个星期','search_start','既往找房耗时，不是租赁期限或当前仍在找')];N.append('语义偏已找到经历，若重新找房需新证据')
 if k=='D0574': T.extend([topic('户型面积与居住方式','套三精装','fact','current_home'),topic('价格预算','2000','fact','current_home'),topic('价格预算','1000出头','fact','other_person'),topic('楼层电梯','老小区7楼','fact','other_person')]);R.extend([region('绕城',relation='current_home'),region('金牛区',relation='unresolved',scope='姐姐历史居住区，非本人新目标')])
 if k=='D0580':
  T.extend([topic('价格预算','真七百我租','conditional',scope='真实租金为七百才即时愿租，计费周期未本人说明'),topic('看房联系','我租，马上','conditional',scope='愿立即租，不等于成交或已约成功')]);r['time_mentions']=[tm(k,'马上','move_in','条件式即时租住意愿，具体可入住时间须核')];p['tone']='serious';N.append('先核七百真实性及所有必付项，条件未满足前不记已签约')
 if k=='D0589': r['possible_topics']=[{'pools':['位置通勤','看房联系'],'ambiguity':'问主包位置，不明确问房源还是人所在'}]
 if k=='D0592': T.extend([topic('位置通勤','静安区','require'),topic('价格预算','两千以下','require',scope='未说明月计价'),topic('户型面积与居住方式','全是四壁间','reject',scope='对寻得房间质量不满，具体最低标准待核')]);R.append(region('静安区'));N.append('四壁间具体含义及能接受房型需核，不自行补独卫厨房')
 if k=='D0601': T.extend([topic('位置通勤','杨浦公园附近','require'),topic('价格预算','预算单人1500-2500','require',scope='单人预算，不追加每月'),topic('户型面积与居住方式','单人','fact')]);R.append(region('杨浦公园附近'));C.append(con('房东或者转租','对房源来源的偏好，不等于全面拒绝中介或所有联系'));p['caution'].append('保留房东或转租来源偏好，未表达全面禁联')
 if k=='D0613': N.append('电梯是本人发出的条件性表态，但当期本人求租还是对作者建议待核')
 if k=='D0622': r['possible_topics']=[{'pools':['价格预算'],'ambiguity':'裸20000可能是在回答视频价位或本人预算，未确定主体及口径'}]
 if k=='D0652': T.append(topic('户型面积与居住方式','和别人合租下班以后也不开心','fact','current_home'));R.append(region('上海',relation='current_home'));N.append('想换工作与情绪困扰不自动变成求租，保留是否换房待核机会');p['tone']='serious'
 if k=='D0664': r['demand_state']='historical';r['time_mentions']=[tm(k,'住了三个月','lease_duration','本人既往已住时长，不是新租期','P3M')]
 if k=='D0667': r['demand_state']='historical';T.append(topic('价格预算','600 一个月','fact','current_home',scope='历史月租，非当期预算'))
 if k=='D0670': T.append(topic('价格预算','1000','fact','current_home'));N.append('单件疑似单间原字，未更正成新需求')
 if k=='D0676': T.append(topic('费用合同','才配让我付中介费','conditional',scope='中介找到这种房子才值得付费，非具体费用上限'));N.append('这种房子指代正文居住例子，不借正文具体条件作本人硬要求');p['preferred_mother_slot']=25
 if k=='D0688':
  r['role']='supply';r['demand_state']='unknown';r['interest']='uncertain';T.append(topic('费用合同','房东不让转租','fact','current_home'));C.append(con('自己转租，怎么弄','转租操作咨询，未说明另找房；新求租机会待核'));N.append('转租是否许可及是否另找住房均未核，不自动提供招租或求租稿');p['contact_policy']='allow'
 if k=='D0712': T.extend([topic('位置通勤','仓山万达附近','require'),topic('费用合同','民水民电','require')]);R.append(region('仓山万达附近'));p['preferred_mother_slot']=25
 if k=='D0724': R[:]=[region('宝山共富','宝山共富或者大场这边',group='OR'),region('大场','宝山共富或者大场这边',group='OR')]
 if k=='D0730': T.append(topic('位置通勤','地铁可直达徐家汇地铁站 地铁通勤时间30-40分钟','require'));R.append(region('徐家汇地铁站',relation='unresolved',scope='已明确通勤目的地但未说工作用途；契约无commute地区枚举，不作为desired'));C.append(con('地铁通勤时间30-40分钟','通勤时长条件，不是租期；直达与时长同时满足'));N.append('徐家汇为通勤目的地，未自报工作关系，不能推定职业');p['caution'].append('通勤目的地不转为居住地点；同线路直达与30-40分钟需核')
 if k=='D0733': R[:]=[region('浦东新区',group='AND',scope='联洋金桥洋泾的上层区域'),region('联洋',group='unknown',scope='与金桥洋泾为备选或范围待核'),region('金桥',group='unknown'),region('洋泾',group='unknown')]
 if k=='D0781': T.append(topic('费用合同','免费住','ask',scope='对原帖免租宣传的疑问，非已核实方隅优惠'));p['preferred_mother_slot']=25;p['missing_facts'].append('原帖免租活动并非方隅事实，不得直接迁移')
 if k=='D0787': N.append('一个月为租金计价提问，非仅住一个月')
 if k=='D0790': T.extend([topic('价格预算','多少钱'),topic('房源状态','还有吗')])
 # Specific evidence must always remain literal; no inferred geography or price units.
 return r
def write_jsonl(path,rows):path.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows),encoding='utf-8')
all_rows=[]
for page in (0,1):
 decisions=[]
 for line in (P/f'decisions-{page:02}.tsv').read_text(encoding='utf-8').splitlines():
  k,code,family,reason=line.split('\t');decisions.append((k,code,family,reason))
 actual=json.loads((P/f'page-{page:02}.json').read_text(encoding='utf-8'))
 expected=[c['key'] for g in actual['shared_post_context'] for c in g['comments']]
 assert len(decisions)==len(expected) and {d[0] for d in decisions}==set(expected)
 rows=[customize(make(*d,page)) for d in decisions]
 bykey={r['review_key']:r for r in rows};rows=[bykey[k] for k in expected]
 write_jsonl(P/f'reviewed-{page:02}.jsonl',rows)
 all_rows.extend(rows)
 (P/'progress.json').write_text(json.dumps({'shard':0,'completed_pages':list(range(page+1)),'comments_completed':len(all_rows),'initial_and_detailed_same_model':True,'independent_review_completed':False,'platform_calls':0,'send_authorized':False},ensure_ascii=False,indent=2),encoding='utf-8')
# Preserve original shard ordering; page concatenation has identical content set.
index={r['review_key']:r for r in all_rows}
assert set(index)==set(src) and len(index)==len(all_rows)==269
write_jsonl(B/'reviewed-new-0.jsonl',[index[s['review_key']] for s in sources])
print(json.dumps({'rows':len(all_rows),'page_counts':[180,89],'interest':dict(collections.Counter(r['interest'] for r in all_rows)),'families':dict(collections.Counter(r['reply_plan']['local_mother']['family'] if r['reply_plan']['local_mother'] else None for r in all_rows))},ensure_ascii=False))
