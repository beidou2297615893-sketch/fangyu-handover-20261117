"""Persist this assistant's explicit review of the 57 previously unanalysed records."""
import json,hashlib,re
from pathlib import Path
from datetime import datetime,timezone
HERE=Path(__file__).resolve().parent; ROOT=HERE.parents[1]
OUT=ROOT/'outputs/方隅双平台文本业务/验收与逐批记录';OUT.mkdir(parents=True,exist_ok=True)
a=json.loads((HERE/'backlog-57-input.json').read_text(encoding='utf8'))
supply={14,15,17,21,22,23,24,25,26,27,28,30,32,35,38,40,41,42,43,45,46,47,49,50,54,55,56}
topics={1:['户型面积与居住方式'],3:['看房联系'],4:['位置通勤'],5:['入住与租期'],6:['看房联系'],7:['看房联系'],8:['看房联系'],9:['看房联系'],10:['看房联系'],11:['看房联系'],13:['看房联系','费用合同'],18:['看房联系'],19:['看房联系'],20:['看房联系'],29:['看房联系'],31:['看房联系'],33:['位置通勤'],34:['看房联系'],36:['看房联系'],37:['看房联系'],39:['位置通勤'],48:['位置通勤'],53:['看房联系'],57:['价格预算']}
out=[]
for i,r in enumerate(a,1):
 role='房源或服务供给线索' if i in supply else '租期咨询，具体对象待核' if i==5 else '具体房源问价线索' if i==57 else '身份或询问对象待核'
 if i in supply:reason='提供房源、租售或砍价服务，不把广告中的地点、价格和配套当作评论者本人求租条件。'
 elif i==5:reason='本人明确问能否租两个月，保留租期；可租对象与本人目标地区未知，不能按两个月就确定门店或高意向。'
 elif i==57:reason='原文询问租金；标题提供房型语境，仍需确认具体出租对象及当前有效性，问价不等于本人预算。'
 elif i in {2,12,44}:reason='只有视频占位，没有可判定的本人原话；不由标题补造需求。'
 elif i in {51,52}:reason='数字占位无明确语义，不判无关或求租，保留待核。'
 elif i in {16,36}:reason='私信简短提示，无法确认供需角色和联系对象；不把它当平台发送回执。'
 elif i==1:reason='两房的可能是提供房源或补充自己的需求，缺直接上级，不能确定身份与诉求方向。'
 elif i in {4,39,48}:reason='出现地点或线路，但不能确定是本人求租范围还是向别人提供房源。'
 else:reason='可以识别咨询或视频/看房主题，但缺标题和直接上级等语境，不能确认具体租赁对象和本人当前需求。'
 z={**r,'review_version':'business-text-20261029-v1','reviewed_by':'current_gpt-6.1-sol','review_status':'已完成文本初筛，关键事实仍待核',
    'role':role,'candidate_topics':topics.get(i,[]),'reason':reason,'own_target_region':'unknown','current_need_validity':'unknown',
    'ip_inferred_target':False,'eligible_to_send':False,'human_approved':False,'source_databases_modified':False}
 out.append(z)
(HERE/'backlog-57-reviewed.jsonl').write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in out),encoding='utf8')
lines=['57条历史待分析评论的文本补核','',
'这57条是此前快照中的未分析或未找到分析记录，不是今天新增。现逐条补做文本初筛，供给和信息缺失保留；不更新生产意向、不生成或发送回复。',
'原评论的时间字段仅作来源记录，不自动证明今天仍在找房。所有目标地区、当前需求和联系许可仍需核实。','']
for z in out:
 text=re.sub(r'(?<!\d)1[3-9]\d{9}(?!\d)','[联系方式已省略]',z['t'])
 lines+=['────────────────','客户原评论：'+text,'已有帖子标题：'+(z['title'] or '缺失'),'本次文本判断：'+z['role'],
 '主题线索：'+('、'.join(z['candidate_topics']) or '没有确认本人需求主题'),'依据与待核：'+z['reason'],'']
(OUT/'57条历史待分析补核.txt').write_text('\n'.join(lines)+'\n',encoding='utf8')
base=ROOT/'work/xhs-standalone-session/collection-live';scan=[]
for p in sorted(base.glob('batch-*')):
 ready=p/'registered-ready.json';entry={'batch':p.name,'registered_ready':ready.exists(),'files':[f.name for f in p.iterdir() if f.is_file()]}
 if ready.exists():
  v=json.loads(ready.read_text(encoding='utf-8-sig'));entry['ready']=v;entry['input_exists']=(p/str(v.get('input','new-ai-input.json'))).exists()
 scan.append(entry)
manifest={'observed_at_utc':datetime.now(timezone.utc).isoformat(),'historical_backlog_reviewed':57,'new_platform_requests':0,'new_replies':0,
 'batch_scan':scan,'persistent_worker_installed':False,'actual_new_batch_consumed':False,'note':'本轮只补历史文本；未发现第19批完整已登记新增回执，不把失败尝试当新增，持续消费者属于代码交接。'}
(HERE/'batch-scan.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf8')
(OUT/'逐批分析接续记录.md').write_text('# 逐批文本分析接续记录\n\n本轮补核57条历史待分析记录，不把它们算为新采集。\n\n已检查本地真实批次目录；第19批当前仅有尝试、去重及失败诊断材料，未见完整已登记新增回执。小红书CLI窗口的最近状态也是账号会话核验中、尚无新增评论。故本轮没有可接收的新批次，不启动采集或复用测试文件凑数。\n\n今后以实际已登记新增文件为输入，按平台评论身份及内容和规则版本核对；同批重复递交不重复分析，来源改变或冲突保留待核，规则变化只产生新版本。分类结果保存来源、需求主题、否定、供需、地区、时间、门店候选、待核原因、认可和操作状态。软件自动接收、持久去重及断点由代码窗口实现，本次未部署常驻监听或服务器。\n',encoding='utf8')
assert len(out)==57 and len({z['comment_id'] for z in out})==57
print(json.dumps({'backlog_reviewed':57,'supply_or_service':len(supply),'pending':57-len(supply),'registered_batches':sum(x['registered_ready'] for x in scan),'unregistered_batches':[x['batch'] for x in scan if not x['registered_ready']]}))
