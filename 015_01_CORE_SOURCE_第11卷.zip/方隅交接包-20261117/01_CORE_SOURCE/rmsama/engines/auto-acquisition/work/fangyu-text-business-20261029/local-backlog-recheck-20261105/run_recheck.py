"""Recheck every frozen uncertain comment locally; preserve evidence and abstentions."""
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import sys
import time

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent/'douyin-semantic-repair-v5'))
import local_recheck
import business_fit
import semantic_guard

started=time.perf_counter()
manifest=json.loads((HERE/'manifest.json').read_text(encoding='utf-8'))
payload=(HERE/'input.jsonl').read_bytes()
assert hashlib.sha256(payload).hexdigest()==manifest['input_sha256']
rows=[json.loads(line) for line in payload.splitlines() if line.strip()]
assert len(rows)==manifest['input_count'] and len({r['comment_id'] for r in rows})==len(rows)
as_of=datetime.fromisoformat(manifest['as_of']).timestamp()
screen_live=business_fit.screen
business_fit.screen=lambda row,now=None:screen_live(row,as_of)
results=[]
for index,row in enumerate(rows,1):
    decision=local_recheck.decide(row)
    result=local_recheck.apply_decision(row,decision)
    fit=business_fit.screen(result)
    result['commercial_fit']=fit
    if fit['eligible_candidate'] and fit['lead_intent'] in ('medium','high','super_high'):
        classified=local_recheck.complete_local_demand.classifier.classify(dict(result,original_classification=result))
        pools=list(dict.fromkeys(decision['pools']+classified['pools']))
        result.update(pools=pools,subtags=classified.get('subtags',[]))
        result['reply']=semantic_guard.render(result)
    else:result['reply']={'draft_text':None,'status':'local_recheck_not_ready','send_authorized':False}
    assert result['comment_text']==row['comment_text']
    results.append(result)
    if index%500==0 or index==len(rows):
        (HERE/'实时进度.txt').write_text(f'本地复核：{index}/{len(rows)}\n模型调用：0\n已用时：{time.perf_counter()-started:.1f}秒\n',encoding='utf-8')

def write_jsonl(name,values):
    data=''.join(json.dumps(row,ensure_ascii=False)+'\n' for row in values).encode()
    (HERE/name).write_bytes(data)
    return hashlib.sha256(data).hexdigest()

result_sha=write_jsonl('results.jsonl',results)
seed_sha=write_jsonl('decisions.jsonl',[dict(comment_id=row['comment_id'],**row['local_recheck']) for row in results])
supported=[r for r in results if r['commercial_fit']['eligible_candidate'] and r['commercial_fit']['lead_intent'] in ('medium','high','super_high')]
summary={'completed_at':datetime.now(timezone.utc).isoformat(),'status':'all_frozen_records_locally_rechecked',
         'input_count':len(rows),'checked_count':len(results),'input_sha256':manifest['input_sha256'],
         'result_sha256':result_sha,'decisions_sha256':seed_sha,'rule_version':business_fit.VERSION,
         'local_recheck_version':local_recheck.VERSION,'model_calls':0,'platform_requests':0,
         'elapsed_seconds':round(time.perf_counter()-started,3),
         'local_categories':dict(Counter(r['local_recheck']['category'] for r in results)),
         'lead_intent_counts':dict(Counter(r['commercial_fit']['lead_intent'] for r in results)),
         'supported_demand_count':len(supported),
         'mother_reply_nonempty':sum(bool(r['reply'].get('draft_text')) for r in supported),
         'before_ledger_counts_only':True,'source_database_modified':False,'receipts_modified':False,
         'as_of':manifest['as_of'],'abstention_is_checked_not_unprocessed':True}
(HERE/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(summary,ensure_ascii=False))
