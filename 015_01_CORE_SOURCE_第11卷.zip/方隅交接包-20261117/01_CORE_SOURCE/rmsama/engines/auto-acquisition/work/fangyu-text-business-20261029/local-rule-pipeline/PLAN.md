# Local-first comment pipeline Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 已授权的评论分类、意向判断、母句套用走本地默认链路，仅将少数语义疑难归组供复核。

**Architecture:** 独立纯规则分类模块＋只读采集源的SQLite增量协调器。历史模型结果保留，派生库流式、幂等，CLI输出分方法计数。

**Tech Stack:** Python 3.12、SQLite、项目内pyahocorasick 2.3.1；不接模型API。

**Spec:** SPEC.md。

## Global Constraints

- 不修改采集源数据库、真实发送回执、软件客户端、其他客户或平台状态。
- 普通评论默认零模型；资料缺失不自动交模型补造，语义疑难按场景归组。
- 需求池、供需、时效、地区和联系状态独立；未知不等无关。
- 旧12409条初判保留，样本对照不能冒充人工准确率。
- 同平台稳定ID幂等，同客户一个本地母句候选；默认无发送授权。

## Review Focus

- 否定供需与未来入住被词面误判：核心边界测试。
- 他人正文/工作地/IP被转成本人条件：主体与地区测试。
- unknown请求后转parsed漏处理：源资格变更增量测试。
- 重跑/崩溃形成重复候选或读全量占内存：事务重跑与批次测试。
- 模型回退偷偷启动、母句编造事实：零网络/零调用及固定文案验证。

### Task 1: Rule classifier and mother selector

Files: local_classifier.py、rule_config.json、test_local_classifier.py。

- [ ] 写业务反例测试并确认缺模块时失败。
- [ ] 实现SPEC的classify与choose_mother接口，原字证据和异常类型。
- [ ] 跑边界测试并由独立审查者核代码与语义。

### Task 2: Streaming local coordinator

Files: run_local_pipeline.py、test_local_pipeline.py、state/、manifest.json。

- [ ] 写源只读、资格转变、重跑零重复、分批及历史保护测试，先确认失败。
- [ ] 实现派生库、源元数据增量、规则调用、母句去重、异常归组和当前指针。
- [ ] 与核心接口联调，保留无网络及模型调用计数，审查事务和缓存边界。

### Task 3: Verify and continue

Files: acceptance_report.json、benchmark_report.json、人读说明；更新分工和心跳。

- [ ] 历史200条独立于开发调词的对照，记录分歧而非准确率。
- [ ] 百万合成输入有界内存压测，区别真实数据验证。
- [ ] 完整审查通过后标verified并用本地入口处理实际新登记，再重跑检查幂等。
- [ ] 向已获授权的代码窗口传达准确性优先、可插拔低成本模型与实际usage计量；不要求现在部署重启。
