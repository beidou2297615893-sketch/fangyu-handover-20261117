"""Publish only current positive business metrics; remove obsolete human comment exports."""
import argparse,hashlib,json,os,sqlite3
from pathlib import Path
from datetime import datetime,timezone
HERE=Path(__file__).resolve().parent;WORK=HERE.parent;ROOT=WORK.parents[1]
OUT=ROOT/'outputs/方隅双平台文本业务'
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def atomic(p,value):
    tmp=p.with_suffix(p.suffix+'.visible.tmp');tmp.write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf-8');os.replace(tmp,p)
def run(cleanup=True):
    deleted=[]
    obsolete={'采集收益复盘','抖音筛选漏斗','抖音逐店采集与意向','古北分类与预生成回复','近期373条文案复核','旧库完整核对','全部高意向分池','小红书分类与母句处理','新增评论分池','验收与逐批记录'}
    for path in (OUT.rglob('*') if cleanup else []):
        if not path.is_file():continue
        rel=path.relative_to(OUT)
        remove=rel.parts[0] in obsolete or (rel.parts[0]=='当前语气与进度' and '母句' not in path.name) or (rel.parts[0]=='地区归类与品牌母句')
        if remove:
            if not path.resolve().is_relative_to(OUT.resolve()):raise RuntimeError('export path outside project')
            deleted.append({'file':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()});path.unlink()
    handoff=read(ROOT/'work/fangyu-douyin-independent/classification-handoff-status.json')
    dy=handoff['visible_business_pool'];xhs=read(HERE/'xiaohongshu-cleanup-result.json')
    records={};platforms={}
    for pl,file,sha in [('douyin',dy['file'],dy['sha256']),('xiaohongshu',xhs['visible_file'],xhs['visible_sha256'])]:
        p=Path(file);data=p.read_bytes()
        if hashlib.sha256(data).hexdigest()!=sha:raise RuntimeError('visible pool changed; retry')
        rows=[json.loads(l) for l in data.splitlines() if l.strip()]
        ids={str(r['comment_id']) for r in rows};records[pl]=ids
        platforms[pl]={'file':file,'sha256':sha,'符合条件':len(ids),'范围':'30天内，中、高、超高意向'}
    with sqlite3.connect((ROOT/'work/shared-acquisition-ledger/shared.sqlite3').resolve().as_uri()+'?mode=ro',uri=True) as db:
        for pl in platforms:
            sent={str(r[0]) for r in db.execute("SELECT comment FROM leads WHERE platform=? AND status='sent' UNION SELECT comment FROM reservations WHERE platform=? AND status='sent'",(pl,pl))}
            platforms[pl]['已回复']=len(records[pl]&sent)
    view={'updated_at':datetime.now(timezone.utc).isoformat(),'platforms':platforms,'hidden_unresolved_not_counted':True,'historical_cumulative_not_displayed':True,'sort':['时间','预算','意愿'],'reply':'本地按分类池选母句并微调','model_calls':0,'platform_requests':0}
    atomic(HERE/'visible-current.json',view)
    state={'updated_at':view['updated_at'],'display_scope':'30天内中、高、超高意向客户','douyin':platforms['douyin'],'xiaohongshu':platforms['xiaohongshu'],'unresolved':'后台继续处理，不计入客户显示','active_text_execution_policy':'本地分类、时间预算意愿排序、按池配母句；少量疑难另核','default_model_per_comment':False,'send_authorized':False,'collection_control_authorized':False,'cross_thread_confirmation_allowed':False,'platform_statistics_must_remain_separate':True,'current_local_view':str(HERE/'visible-current.json')}
    atomic(WORK/'当前文本处理运行状态.json',state)
    report='当前客户池\n\n| 平台 | 符合条件 | 已回复 |\n|---|---:|---:|\n'+''.join('| '+label+' | '+str(platforms[pl]['符合条件'])+' | '+str(platforms[pl]['已回复'])+' |\n' for pl,label in [('douyin','抖音'),('xiaohongshu','小红书')])+'\n只显示30天内中、高、超高意向；未判清的在后台继续处理。\n按时间、预算、意愿排序，本地按池配母句。\n'
    (OUT/'当前客户池.md').write_text(report,encoding='utf-8')
    for folder,title in [('小红书15店采集进度','小红书客户池'),('小红书回复发送进度','小红书回复进度')]:
        directory=ROOT/'outputs'/folder;directory.mkdir(exist_ok=True)
        count=platforms['xiaohongshu']['符合条件']
        (directory/'进度.html').write_text('<meta charset="utf-8"><meta http-equiv="refresh" content="30"><h1>'+title+'</h1><p>符合条件：'+str(count)+'条。</p><p>仅30天内中、高、超高意向；后台继续筛选。</p><p>本页只读，不控制采集或发送。</p>',encoding='utf-8')
    entry=OUT/'先看这里.md';text=entry.read_text(encoding='utf-8');text=text.split('## 两平台本地文本处理')[0]
    text=text.replace('最新进度和回复实样：见“地区归类与品牌母句/双平台最新进度与地区母句说明.md”和“地区归类与品牌母句/首批50条真实评论与已配回复.md”。','当前客户数量见“当前客户池.md”。已清除过期和确认低意向的客户导出；词库、分类规则和母句保留。')
    entry.write_text(text,encoding='utf-8')
    if deleted:atomic(HERE/'obsolete-export-removal.json',{'deleted_files':deleted,'deleted_count':len(deleted),'templates_rules_keywords_untouched':True})
    print(json.dumps({'removed_obsolete_exports':len(deleted),'platforms':{pl:{k:v for k,v in r.items() if k in ('符合条件','已回复')} for pl,r in platforms.items()}},ensure_ascii=False))
if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--refresh-only',action='store_true');args=parser.parse_args();run(not args.refresh_only)
