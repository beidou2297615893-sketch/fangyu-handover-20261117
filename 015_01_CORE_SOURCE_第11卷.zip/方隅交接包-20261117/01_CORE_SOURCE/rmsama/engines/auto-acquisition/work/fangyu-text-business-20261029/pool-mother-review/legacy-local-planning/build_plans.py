"""Derived, review-only legacy family binding. No source mutation, platform or model client."""
import json,pathlib,hashlib,re,collections,copy,sys,datetime
W=pathlib.Path('work/fangyu-text-business-20261029'); O=W/'pool-mother-review/legacy-local-planning'; I=W/'pool-mother-review/legacy-inventory'; B=W/'douyin-registered-v2/increments/f98cc21138910fb9'
def load(p):return json.loads(pathlib.Path(p).read_text(encoding='utf8'))
def jl(p):return [json.loads(l) for l in pathlib.Path(p).read_text(encoding='utf8').splitlines() if l.strip()]
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def objsha(x):return hashlib.sha256(json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def put(p,x):pathlib.Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
def putjl(p,rs):pathlib.Path(p).write_text(''.join(json.dumps(x,ensure_ascii=False,separators=(',',':'))+'\n' for x in rs),encoding='utf8')
c=load(W/'region-brand-routing/current.json'); inv=load(I/'inventory.json'); old=jl(I/'proposed-local-plan.jsonl'); contract=load(B/'local-mother-contract.json')
protected={v['path']:v['sha256'] for v in inv['source_checks'].values()}; protected[str((I/'proposed-local-plan.jsonl').resolve())]=sha(I/'proposed-local-plan.jsonl')
missingfile=I/'missing-text-hash-source-verification.json'; missing=load(missingfile) if missingfile.exists() else {}; verified={(x['platform'],x['cid'],x['uid']):x for x in missing.get('verified',[])}
rows={}
for p,f in c['results'].items():
 for r in jl(f):rows[p,r['comment_id'],r['customer_uid']]=r
num=r'[0-9一二两三四五六七八九十百千万千零点\.]+(?:[kKwW千万元百])?'
patterns={
 '价格预算':re.compile(r'(?:预算|价位(?:在)?|接受)?'+num+r'(?:[-—到至]'+num+r')?(?:元|块)?(?:以内|以下|左右|上下|出头|之内|封顶|不超过)?'),
 '户型面积与居住方式':re.compile(r'(?:[一二两三四五六123456](?:室|房|居)(?:[一二两三四1234]厅)?(?:[一二两三四1234]厨)?(?:[一二两三四1234]卫)?(?:室|户)?|套[一二三四1234]|(?:整租|合租)|(?:[一二两三四1234]人住))'),
 '房内设施':re.compile(r'(?:不要|不能|不带|带|要|有)?(?:独立卫浴|独卫|燃气热水器|阳台|厨房|空调|冰箱|洗衣机)'),
 '费用合同':re.compile(r'(?:不要押金|民用水电|民水民电|商用水电|包水电|含水电|(?:押[一二三123]付[一二三123]))'),
 '宠物':re.compile(r'(?:可以养|能养|养|能带|带)?(?:小猫|猫咪|猫猫|猫|小狗|狗狗|狗|宠物)(?:可以|能带|友好)?'),
 '楼层电梯':re.compile(r'(?:不要|不能|有|带|要)?(?:电梯|楼梯|低楼层|高楼层|[一二三四五六七八九十0-9]+楼)'),
}
fillers=re.compile(r'礼貌|请问一下|请问|你好呀|你好|您好|宝宝|姐妹|哥|啊|呀|呢|嘛|吗|么|的|了|吧|阿|吖|哇|哈|谢谢|麻烦|求推荐|推荐|找房子|找房|求租房|求租|租房子|房子|房间|房源|有木有|有没有|还有没有|还有|还在|在吗|有吗|可以吗|可以|能不能|能|想租|我想租|我就|我想|我|来住|租到|租个|租|想了解一下|想了解|了解一下|了解|方便|问问|想问|一下|多少一个月|多少钱一个月|多少钱|多少|什么价格|什么价位|什么价|价格|租金|月租|问价|询价|位置|地址|具体|在哪儿|在哪里|哪里|在哪|地点|怎么|咋样|加个|联系|看房|上班|这边|工作|在|边上|附近|有|要|是')
def norm(t):return re.sub(r'[^\u4e00-\u9fffA-Za-z0-9@]','',re.sub(r'\[[^\]]*\]','',t))
def residual(t,spans):
 for s in sorted(set(spans),key=len,reverse=True):t=t.replace(s,'')
 t=re.sub(r'\[[^\]]*\]','',t)
 for _ in range(3):t=fillers.sub('',t)
 return norm(t)
def classify(p):
 k=p['platform'],p['cid'],p['uid'];r=rows[k];a=p['source_field_evidence'];s=r.get('source_record') or {};z=copy.deepcopy(p);txt=r['comment_text'];ev=p['literal_evidence'];ts=a['time_mentions'];regs=a['target_regions'];cons=a['other_constraints'];tags={x if isinstance(x,str) else x.get('pool') for x in (a['topics'] or [])};tags.discard(None)
 z={key:z[key] for key in ('platform','cid','uid','sourceSHA','stored_comment_sha256','source_file_sha256','selection','literal_evidence','source_field_evidence')};z.update(family=None,fill={},evidence=[],hold_reasons=[],status='local_plan_held',send_authorized=False,can_send_now=False,original_classification_sha256=objsha(s),classification_changed=False)
 z['source_binding']='stored_comment_sha256' if p['source_sha_match'] else 'independent_registered_entity_verification' if k in verified and verified[k]['verified_text_sha256']==p['sourceSHA'] else 'unverified_missing_stored_sha'
 if k in verified:z['source_verification']=verified[k]
 holds=z['hold_reasons']
 if z['source_binding']=='unverified_missing_stored_sha':holds.append('source_binding_gap')
 if r.get('role')!='demand' or r.get('demand_state')!='active_at_comment' or r.get('interest_at_comment') not in ('medium','high','super_high'):holds.append('preserve_original_role_state_interest_hold')
 policy=r.get('contact_policy') or (a.get('reply_plan') or {}).get('contact_policy');z['contact_policy_original']=policy;z['delivery_holds']=['contact_policy_missing_not_inferred'] if not policy else ['original_contact_unknown_or_prohibited'] if policy in ('unknown','no_contact') else []
 if policy in ('unknown','no_contact'):holds.append('original_contact_unknown_or_prohibited')
 if s.get('source_version_conflict'):holds.append('source_version_conflict')
 if any(x.get('subject')!='own_demand' for x in ev):holds.append('subject_not_own_demand_requires_scope_label')
 if any(not x.get('quote') or x['quote'] not in txt for x in ev):holds.append('topic_evidence_not_literal_own_comment')
 if any(x.get('polarity') in ('conditional','unknown','compare','fact','not_required') for x in ev):holds.append('conditional_fact_or_comparison_scope_requires_binding')
 if any(x.get('condition_scope') and x['condition_scope']!=x.get('quote') for x in ev):holds.append('nontrivial_condition_scope_needs_preserving')
 if any(x.get('relation') not in ('desired','work') or not x.get('quote') or x['quote'] not in txt or x.get('condition_scope') not in (None,'',x.get('quote'),txt) for x in regs):holds.append('region_relation_or_scope_unresolved')
 if len(regs)>1:holds.append('multiple_region_relation_needs_binding')
 if cons:holds.append('other_constraint_needs_typed_subject_binding')
 if a['contact_boundaries']:holds.append('contact_boundary_requires_separate_review')
 if ts and not(all(x.get('time_role')=='lease_duration' and x.get('quote') and x['quote'] in txt for x in ts) and tags=={'入住与租期'}):holds.append('time_role_or_anchor_requires_specific_binding')
 if not ev and not regs:holds.append('missing_structured_pool_evidence')
 spans=[];bind=[];known=set();param_by_pool={}
 def region_value(rr):
  value=rr.get('text') or rr.get('quote') or ''
  if value not in (rr.get('quote') or '') or value not in txt:value=rr.get('quote') or ''
  return value
 def add(v,field,source,pool=None):
  if v and v not in spans:spans.append(v);bind.append({'field':field,'quote':v,'source_field':source,'pool':pool})
 for rr in regs:
  value=region_value(rr)
  if value and value in txt:
   if re.search(r'我|咱|本人|朋友|同事|[?？]',value):holds.append('region_entity_field_contains_customer_sentence')
   add(value,'place' if rr['relation']=='desired' else 'destination','target_regions', '位置通勤');known.add('位置通勤')
 for pool,pat in patterns.items():
  es=[x for x in ev if x.get('pool')==pool];found=[]
  for e in es:
   q=e.get('quote') or ''
   if pool=='价格预算' and e.get('polarity')=='ask':
    if '便宜点' in q and not re.search(r'这么|那种|现在|当前',q):found.append('便宜点')
    continue
   for m in pat.finditer(q):
    v=m.group()
    if pool=='价格预算' and not re.search(r'预算|价位|接受|元|块|千|万|[kKwW]|以内|以下|左右|封顶|不超过',v):continue
    if v in txt:found.append(v)
  if found:
   # If a negative/preferring expression surrounds the extracted token, do not silently remove it.
   if any(re.search(r'不|别|最好|至少|最多|以上|超过|或者|还是',e.get('quote','')) and not all(e.get('quote','')==v for v in found) for e in es):holds.append('negation_preference_or_alternative_not_bound_'+pool)
   for v in found:add(v,'requirements','topic_evidence',pool)
   param_by_pool[pool]=found;known.add(pool)
 # Simple question pools are covered by a fixed family, never interpreted as answered facts.
 question_pools={'价格预算','房源状态','位置通勤','看房联系'}
 for pool in tags:
  if pool in question_pools and all(e.get('polarity')=='ask' for e in ev if e.get('pool')==pool):known.add(pool)
 if ts and tags=={'入住与租期'}:
  q=ts[0]['quote'];m=re.search(r'(?:一|二|两|三|四|五|六|[0-9]+)个?月|半年|一年',q)
  if m and len(ts)==1:add(m.group(),'duration','time_mentions','入住与租期');known.add('入住与租期')
 if tags-known:holds.append('unbound_existing_pools:'+','.join(sorted(tags-known)))
 rem=residual(txt,spans);z['unbound_literal_residual']=rem
 unmatched=txt
 for v in spans:unmatched=unmatched.replace(v,'')
 if re.search(r'不要|不想|不是|不能|不租|不带|不接受|别|拒绝|不超过|以上|至少|最多|最好',unmatched):holds.append('unbound_negation_or_qualifier')
 if rem:holds.append('unbound_literal_condition_or_context')
 if not holds:
  fam=None;fill={};evidence=[]
  if tags=={'入住与租期'} and ts:
   fam='lease_fixed';fill={'duration':next(x['quote'] for x in bind if x['field']=='duration')}
  elif regs and len(regs)==1 and not param_by_pool and tags<= {'位置通勤','房源状态'}:
   fam='area' if regs[0]['relation']=='desired' else 'commute';fill={'place' if fam=='area' else 'destination':region_value(regs[0])}
  elif not spans and tags=={'价格预算'}:fam='price'
  elif not spans and tags=={'房源状态'}:fam='available'
  elif not spans and tags=={'位置通勤'}:fam='location'
  elif not spans and tags=={'价格预算','位置通勤'}:fam='price_location'
  elif not regs and set(param_by_pool)=={'价格预算'} and tags=={'价格预算'} and len(spans)==1:fam='budget_fit';fill={'budget':spans[0]}
  elif not regs and set(param_by_pool)=={'户型面积与居住方式'} and tags <= {'户型面积与居住方式','价格预算','位置通勤'} and '价格预算' in tags and len(spans)==1:fam='room_price_location';fill={'room':spans[0]}
  elif not regs and set(param_by_pool)=={'户型面积与居住方式'} and tags == {'户型面积与居住方式','位置通勤'} and len(spans)==1:fam='unknown_room_location';fill={'room':spans[0]}
  elif spans and len(spans)<=6 and sum(map(len,spans))<=70 and not any(x.get('relation')=='work' for x in regs):
   if '价格预算' in tags and '价格预算' not in param_by_pool:holds.append('price_question_would_be_dropped_by_requirements')
   elif '看房联系' in tags:holds.append('viewing_question_would_be_dropped_by_requirements')
   elif '位置通勤' in tags and not regs:holds.append('location_question_would_be_dropped_by_requirements')
   else:fam='requirements';fill={'requirements':'、'.join(spans)}
  if fam:
   z.update(family=fam,fill=fill,status='local_plan_proposed')
   for field,val in fill.items():
    for v in val.split('、') if field=='requirements' else [val]:
     be=next(x for x in bind if x['quote']==v);evidence.append({**be,'field':field})
   z['evidence']=evidence
  else:holds.append('no_existing_family_preserves_combination')
 z['hold_reasons']=list(dict.fromkeys(holds));z['covered_existing_pools']=sorted(known);return z
plans=[classify(p) for p in old]
assert len(plans)==12963
# Representative selection includes all 36 original sample occurrences (unique comments deduplicated), then difficult real controls.
selection=collections.OrderedDict()
for p,d in inv['platforms'].items():
 for tag,es in d['sample_examples'].items():
  for e in es:selection.setdefault((p,e['cid'],e['uid']),[]).append('inventory:'+tag)
for e in load(O/'extra-selection.json'):selection.setdefault((e['platform'],e['cid'],e['uid']),[]).extend(e['tags'])
for tag,es in load(O/'edge-selection.json').items():
 for e in es:selection.setdefault((e['platform'],e['cid'],e['uid']),[]).append(tag)
if (O/'more-selection.json').exists():
 for e in load(O/'more-selection.json'):selection.setdefault((e['platform'],e['cid'],e['uid']),[]).extend(e['tags'])
bykey={(p['platform'],p['cid'],p['uid']):p for p in plans}
samples=[];contexts={}
for k,tags in selection.items():
 r=rows[k];s=r.get('source_record') or {};a=s.get('classification') if isinstance(s.get('classification'),dict) else s;pid=str(s.get('video_id') or s.get('note_id') or r.get('video_id') or r.get('note_id') or 'unknown:'+r['comment_id']);ctxkey=k[0]+':'+pid
 contexts.setdefault(ctxkey,{'platform':k[0],'post_id':pid,'post_body':s.get('post_body'),'post_author_same_as_commenter':s.get('post_author_same_as_commenter'),'source':'source_record; post shared once; no platform fetch'})
 samples.append({'platform':k[0],'cid':k[1],'uid':k[2],'sourceSHA':hashlib.sha256(r['comment_text'].encode()).hexdigest(),'source_container_sha256':c['result_sha256'][k[0]+'-region-brand-results.jsonl'],'comment':r['comment_text'],'context_key':ctxkey,'direct_parent_text':s.get('direct_parent_text'),'sample_tags':tags,'original_classification':{'role':r.get('role'),'state':r.get('demand_state'),'interest':r.get('interest_at_comment'),'topic_evidence':a.get('topic_evidence',a.get('actual_pools',a.get('topics'))),'target_regions':r.get('target_regions'),'time_mentions':r.get('time_mentions'),'other_constraints':a.get('other_constraints'),'contact_policy':r.get('contact_policy'),'contact_boundaries':r.get('contact_boundaries')},'proposed_plan':{key:bykey[k][key] for key in ('family','fill','evidence','hold_reasons','delivery_holds')} if k in bykey else {'family':None,'fill':{},'hold_reasons':['outside_historical_candidate_scope_original_exclusion_preserved']}})
assert len(samples)<=80
putjl(O/'local-proposed-plans.jsonl',plans);putjl(O/'representative-input.jsonl',samples);put(O/'representative-post-contexts.json',contexts)
manifest={'scope':'12963 historical selected/alternative candidates; exclude latest 807','created_at':datetime.datetime.now().astimezone().isoformat(),'current_region_pointer':str((W/'region-brand-routing/current.json').resolve()),'current_pointer_sha256':sha(W/'region-brand-routing/current.json'),'sources':protected,'additional_registered_text_verification':{'path':str(missingfile.resolve()),'sha256':sha(missingfile),'verified_count':len(verified)},'classification_or_reply_source_writes':0,'send_attempts':0,'platform_calls':0,'new_paid_API_calls':0,'applied_or_pointer_changed':False,'contract_sha256':sha(B/'local-mother-contract.json'),'planner_sha256':sha(__file__),'usage':'unknown','semantic_model_id':'current assistant runtime; exact model id not exposed','representative_count':len(samples),'original_inventory_sample_occurrences':sum(len(es) for s in inv['platforms'].values() for es in s['sample_examples'].values())}
put(O/'plan-source-manifest.json',manifest)
print(json.dumps({'planned':sum(bool(x['family']) for x in plans),'families':dict(collections.Counter(x['family'] for x in plans if x['family'])),'holds':collections.Counter(y for x in plans for y in x['hold_reasons']).most_common(),'representatives':len(samples)},ensure_ascii=False))
