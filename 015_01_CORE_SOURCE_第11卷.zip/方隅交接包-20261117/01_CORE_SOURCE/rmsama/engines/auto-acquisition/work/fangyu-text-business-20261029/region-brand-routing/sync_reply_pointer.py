"""Publish local metadata pointers after validated region/mother sidecars only."""
from pathlib import Path
import json,hashlib,datetime
D=Path(__file__).resolve().parent;W=D.parent
def read(p):return json.loads(Path(p).read_text(encoding='utf-8'))
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(p,obj):
    p=Path(p);temp=p.with_suffix(p.suffix+'.tmp')
    temp.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');temp.replace(p)
c=read(D/'current.json');m=read(c['manifest']);s=read(c['summary']);v=read(c['validation'])
assert v.get('all_passed') is True and all(v['checks'].values())
assert sha(c['manifest'])==c['manifest_sha256']
now=datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=8))).isoformat()
out={'version':'brand_reply_current_v1','updated_at':now,'business_policy_file':str((W/'rules/地域与品牌母句执行方式.json').resolve()),'region_version_pointer':str((D/'current.json').resolve()),'platforms':{},'source_classifications_overwritten':False,'platform_calls':0,'send_authorized':False}
for p,src in m['platforms'].items():
    assert sha(src['result_file'])==src['result_sha256']
    f=Path(c['results'][p]);h=sha(f);assert h==c['result_sha256'].get(p,c['result_sha256'].get(f.name))
    st=s['platforms'][p]
    out['platforms'][p]={'classification_file':src['result_file'],'classification_sha256':src['result_sha256'],'reply_sidecar_file':str(f),'reply_sidecar_sha256':h,'classified_comments':st['records'],'high_super_high_comments':st['high_super_high_comments'],'high_super_high_unique_customers':st['high_super_high_unique_uids'],'selected_brand_mother_drafts':st['selected_local_mother'],'send_authorized':False}
write(W/'当前双平台回复结果指针.json',out)
state_path=W/'当前文本处理运行状态.json';state=read(state_path)
st=state.setdefault('region_brand_reply_sidecars',{})
st.update(current_pointer=str((W/'当前双平台回复结果指针.json').resolve()),region_pointer=str((D/'current.json').resolve()),completed_at=now,dy_classified=s['platforms']['douyin']['records'],xhs_classified=s['platforms']['xiaohongshu']['records'],dy_selected_mother_drafts=s['platforms']['douyin']['selected_local_mother'],xhs_selected_mother_drafts=s['platforms']['xiaohongshu']['selected_local_mother'],xhs_IP_restored=s['platforms']['xiaohongshu']['ip_restored'],xhs_remaining_intro_fit_unreviewed=s['platforms']['xiaohongshu']['requires_AI_intro_suitability'],targeted_fit_reviews=s.get('compatibility_review',{}).get('applied_count',0),dy_old_alternative_state_still_pending=s['platforms']['douyin'].get('unreviewed_original_draft_nonactive',0),platforms_separate=True,source_classifications_overwritten=False,send_authorized=False)
write(state_path,state)
print(json.dumps({'pointer_synced':True,'platforms':{p:x['selected_brand_mother_drafts'] for p,x in out['platforms'].items()},'source_modified':False,'platform_calls':0}))
