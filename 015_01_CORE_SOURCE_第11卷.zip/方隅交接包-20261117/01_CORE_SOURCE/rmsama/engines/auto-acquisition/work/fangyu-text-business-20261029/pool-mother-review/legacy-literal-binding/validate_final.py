"""Independent file-level verification and developer review evidence; read-only sources."""
import json,pathlib,hashlib,collections,importlib.util,re,string
W=pathlib.Path('work/fangyu-text-business-20261029');O=W/'pool-mother-review/legacy-literal-binding';B=W/'douyin-registered-v2/increments/f98cc21138910fb9'
def load(p):return json.loads(pathlib.Path(p).read_text(encoding='utf8'))
def jl(p):return [json.loads(l) for l in pathlib.Path(p).read_text(encoding='utf8').splitlines() if l.strip()]
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def objsha(x):return hashlib.sha256(json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def put(p,x):pathlib.Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
def putjl(p,rs):pathlib.Path(p).write_text(''.join(json.dumps(x,ensure_ascii=False,separators=(',',':'))+'\n' for x in rs),encoding='utf8')
m=load(O/'manifest.json');ps=jl(O/'proposed-plans.jsonl');pre=jl(O/'rendered-preview.jsonl');olds=jl(m['scope_source']);old={(p['platform'],p['cid'],p['uid']):p for p in olds if p.get('next_action_category')==m['scope_category']};c=load(m['source_pointer']);rs={}
for platform,f in c['results'].items():
 for r in jl(f):rs[platform,r['comment_id'],r['customer_uid']]=r
key=lambda p:(p['platform'],p['cid'],p['uid']);idx={key(p):p for p in ps};assert len(ps)==len(pre)==len(idx)==len(old)==4620 and set(idx)==set(old)
contract=load(B/'local-mother-contract.json');addon=load(O/'contract-addon.json');assert not(set(contract['families'])&set(addon['families']));contract['families'].update(addon['families'])
spec=importlib.util.spec_from_file_location('f98_verify_literal',B/'batch_short_mothers.py');renderer=importlib.util.module_from_spec(spec);spec.loader.exec_module(renderer)
for p in ps:
 r=rs[key(p)];orig=old[key(p)];assert p['sourceSHA']==hashlib.sha256(r['comment_text'].encode()).hexdigest();assert p['original_classification_sha256']==objsha(r['source_record']);assert p['original_plan_sha256']==objsha(orig)
 for field in ('literal_evidence','source_field_evidence','selection','stored_comment_sha256','source_binding','source_file_sha256'):assert p[field]==orig[field]
 assert p['contact_policy_original']==orig['contact_policy_original'];assert p['contact_policy_effective_for_render']==(orig['contact_policy_original'] or 'unknown');assert p['send_authorized'] is p['can_send_now'] is p['classification_changed'] is p['human_confirmed'] is False
 if not p['family']:assert p['hold_reasons'] and p['draft_text_preview'] is None;continue
 assert not p['hold_reasons'] and not p['original_semantic_scope_flags'];assert p['family'] in contract['families']
 for field,value in p['fill'].items():assert value in r['comment_text'] and not re.search(r'我|我们|本人|咱',value);assert any(e['field']==field and e['quote']==value for e in p['evidence'])
 assert not any(p['source_field_evidence'].get('other_constraints',[]))
 plan={'local_mother':{k:p[k] for k in ('family','fill','evidence')},'tone':(orig['source_field_evidence'].get('reply_plan') or {}).get('tone','normal'),'contact_policy':p['contact_policy_effective_for_render']}
 rendered=renderer.render_plan({**{k:orig['source_field_evidence'][k] for k in ('role','demand_state','interest_at_comment')},'reply_plan':plan,'source_version_conflict':bool(r['source_record'].get('source_version_conflict'))},r['comment_text'],contract)
 assert p['draft_text_preview']==rendered['validated_plan_text'] and p['rendered_text']==rendered['text'];assert len(p['draft_text_preview'])<=78
 if p['contact_policy_effective_for_render']=='unknown':assert p['rendered_text'] is None
 blocking=r['source_record'].get('blocking_reasons') or (r['source_record'].get('classification') or {}).get('blocking_reasons') or []
 assert not re.search(r'未明确住宅用途|需先确认交易对象|住房用途.*待核|缺正文',json.dumps(blocking,ensure_ascii=False))
for f,h in m['source_files'].items():assert sha(f)==h
samples=jl(O/'representative-review.jsonl');develop=[]
for sample in samples:
 p=idx[key(sample)];develop.append({**sample,'final_family':p['family'],'final_fill':p['fill'],'final_preview':p['draft_text_preview'],'final_holds':p['hold_reasons'],'development_sample_used_in_algorithm_design':True,'independent_holdout':False,'accuracy_claim':None})
putjl(O/'representative-render-review.jsonl',develop)
counts=load(O/'counts.json');bound=[p for p in ps if p['family']];addons_used=set(p['family'] for p in bound)&set(addon['families']);base_count=sum(p['family'] not in addon['families'] for p in bound);maxlen=max(len(p['draft_text_preview']) for p in bound);unknown=sum(p['contact_policy_effective_for_render']=='unknown' for p in bound)
family_table='\n'.join('- '+fam+'：'+str(count) for fam,count in sorted(collections.Counter(p['family'] for p in bound).items(),key=lambda x:-x[1])[:15])
examples=[]
for i in (0,30,33,35,36,37,44,47,50,53):
 s=develop[i];examples.append('- 原评：'+s['comment']+'\n  预览：'+str(s['final_preview'] or s['final_holds']))
report=f'''# 字面槽绑定本地审阅结果

本批只处理原规划的4620条字面绑定缺口，新增可审阅绑定{len(bound)}条，仍保留明确缺口{len(ps)-len(bound)}条。原分类、原稿、源文件和当前指针未改；平台调用、发送、逐条AI重写正文均为0。绑定不等于用户认可或可发送。

已有f98家族复用{base_count}条，新增固定池组合家族{len(addons_used)}个、承接{len(bound)-base_count}条。家族按字段与已判池组合生成固定文本，不是每条客户定制母句。参数全部是原评论连续字面；多个片段使用多个槽，不把拼接串当原quote。

## 根因和范围

原残片校验先删除短词导致租金剩金、问一下剩下，以及泛称房、这个等无意义残片。现在以完整短语优先，保留未绑定数字、否定、费用口径、范围和未知名词；只依据既有AI池及其主体/极性/地点关系/时间角色适配。未知词仍held，不从残片反推意向。

数值require/prefer/accept或明确预算文字才进入预算槽；数字询价走是否实价或价位可租询问，不把原帖报价变成本人预算或方隅事实。预算前后缀只出现一次。附近、公里内、沿线取原地区quote整体，工作地点只入去该地通勤问句。没有把蹲当地点。普通口吻沿宝宝、我住方隅、介绍有优惠；具体房源全部问询，不承诺满足。

## 长度和许可

{counts['length_distribution'].get('20-40',0)}条预览不超过40字，{counts['length_distribution'].get('41-60',0)}条41–60字，{counts['length_distribution'].get('61-78',0)}条61–78字；最长{maxlen}字。未采用复杂原评整句引用的统一兜底。

原contact缺失的{unknown}条只保留draft_text_preview，实际renderer的rendered_text为null，contact仍unknown；send_authorized/can_send_now/human_confirmed全部false。原母句missing_facts单独保留，不当客户要求倒灌；住户及介绍优惠资格、同店同房型事实仍待核。

## 代表语义核对与反例

当前助手在批算法之前核对60条真实代表：53条抖音、7条小红书，涵盖不同残片、多池、价格范围、费用、通勤、主体与弱互动；这是开发代表，不是独立留出，不报告准确率。确切运行模型ID未暴露，没有新增模型端点或平台调用。

- 1000的在哪/看过最低1.9k+/离地铁2公里外是询价与旧看房经历，未把1.9k+变预算，继续held。
- 西三旗上班/租不去四五千的比较否定、预算2000到1400倒序、一千一下错字、女生找室友主体关系继续留短作用范围缺口。
- 真的吗与单独蹲保留原判，不强行宣传。
- 原source_record.blocking_reasons/needs_review/review_reasons及嵌套classification中的住宅用途或交易对象未决，均会阻止推广计划；已明确的work不被误当未判。报告的保留数不能等同必须再次调用AI的条数。

{chr(10).join(examples)}

## 常用家族

{family_table}

## 验证

4620条ID/CID/UID、原文SHA、原分类指纹、原字段、字面槽/evidence、合同渲染重放和全部受保护源SHA通过独立本地复核。代表已参与开发，不冒称独立二审。后续由主窗口合并并统一QA；本目录没有发布或改变当前消费指针。

计划SHA256：{sha(O/'proposed-plans.jsonl')}
合同增量SHA256：{sha(O/'contract-addon.json')}
预览SHA256：{sha(O/'rendered-preview.jsonl')}
'''
(O/'report.md').write_text(report,encoding='utf8')
v=load(O/'validate.json');v.update(independent_file_validation_passed=True,independent_validation_script_sha256=sha(__file__),fixed_combination_family_count=len(addons_used),base_family_binding_count=base_count,new_family_binding_count=len(bound)-base_count,maximum_preview_length=maxlen,original_semantic_object_or_housing_scope_flags_held=sum(bool(p['original_semantic_scope_flags']) for p in ps),representative_render_review_count=len(develop));v['output_sha256'].update({f:sha(O/f) for f in ('report.md','representative-render-review.jsonl','manifest.json')});put(O/'validate.json',v)
print(json.dumps({'all_passed':True,'bound':len(bound),'held':len(ps)-len(bound),'base_bindings':base_count,'addon_families':len(addons_used),'addon_bindings':len(bound)-base_count,'maxlen':maxlen,'scope_flags_held':v['original_semantic_object_or_housing_scope_flags_held'],'files':{f:sha(O/f) for f in ('proposed-plans.jsonl','contract-addon.json','rendered-preview.jsonl','representative-review.jsonl','representative-render-review.jsonl','manifest.json','validate.json','report.md')}},ensure_ascii=False))
