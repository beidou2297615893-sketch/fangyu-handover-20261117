# v2 文本消费指针入口（默认不写指针）

此入口为 `activate_text_candidate.py`。当前 v2 独立 Astra 终审 gate 尚未作为本入口认可的完整门禁落盘，运行默认模式会拒绝；这不是技术失败。先确认最终原生审核明确通过、范围和证据与 v2 固定版本一致，再使用原生审核 manifest 的真实 SHA 运行 dry-run。技术 `all_passed`、旧 v1 审核和口头结论不能代替 v2 语义门禁。

目前入口的严格门禁字段为 `status=pass`、`reviewer_model=gpt-6-astra`、`source_repairs_v2_READY_SHA`、`source_contract_SHA`、`source_merged_plans_SHA`、`review_scope=bounded_template_version_not_individual_approval` 及 `files_sha256`；它验证审核文件实际路径位于 `legacy-final-semantic-review-v2/manifest.json`、文件 SHA 和逐项证据 SHA，并绑定 v2 READY、原合同及最终合并计划。审核文件尚未完成时不能假设其字段形式；若原生格式不同，由主任务依据已完成的真实审核证据适配校验入口，不能手写或虚构一份 PASS。

门禁就绪后，执行者可先运行（下面 SHA 应替换为真实终审 manifest SHA）：

```powershell
$pkg = 'C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-text-business-20261029\pool-mother-review\legacy-release-package'
python "$pkg\activate_text_candidate.py" --gate-sha '<真实终审manifest SHA>'
```

该命令是 dry-run，只读检验；要求全部源、分类 SHA、UID、正文、旧基线指针、合同和结果一致。若最终结果明确通过、消费方已隔离且确认不存在并发写入，由主任务执行：

```powershell
python "$pkg\activate_text_candidate.py" --gate-sha '<真实终审manifest SHA>' --apply --readers-quiesced
```

`--readers-quiesced` 是执行者对读取者已隔离的明确声明，脚本不能自行证明所有旧窗口停止读取。入口先将文件复制进自己的不可变版本目录、二次验源与门禁，再逐个原子替换两份文本指针；跨文件不是单一原子事务。它不更改 latest-manifest、运行状态、分类、采集、原始稿或发送回执；latest-manifest 会继续指向旧记录，若有消费方依赖该文件，应先验证其兼容性，不能假设它已同步。发表批次两条拟修只作旁注。

版本目录保存 precommit/publish 回执和原指针快照；当真实指针仍与本次发布回执中记录的新 SHA 一致时，先做只读回退预检，再按需显式执行：

```powershell
python "$pkg\activate_text_candidate.py" --rollback-receipt '<版本目录中的publish-receipt.json>'
python "$pkg\activate_text_candidate.py" --rollback-receipt '<版本目录中的publish-receipt.json>' --apply --readers-quiesced
```

回退只恢复两份文本指针，不回滚新分类、采集或运行状态。实际 `--apply` 仅由主任务在 gate 和消费者隔离条件全部满足后执行；本准备阶段未执行。
