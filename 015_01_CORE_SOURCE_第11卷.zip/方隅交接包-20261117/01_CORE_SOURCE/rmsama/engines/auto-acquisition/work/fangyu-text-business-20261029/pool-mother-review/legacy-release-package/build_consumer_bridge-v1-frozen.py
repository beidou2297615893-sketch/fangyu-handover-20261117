"""Local review-only consumer bridge. Never writes actual pointers or sends."""
import argparse,collections,copy,hashlib,json,pathlib,sys
sys.dont_write_bytecode=True
import prepare as core
O=pathlib.Path(__file__).resolve().parent;W=O.parents[1];sha=core.sha;load=core.load;jl=core.jl;dump=core.dump
LABELS={'housing_short_mother':('local_pool_family_short_candidate','按需求池短句待审'),'clarification_only':('local_clarification_candidate','确认接话待审'),'basic_pending':('historical_basic_pending_pool_binding','历史基础稿待按池')}
def bridge_row(row):
 r=copy.deepcopy(row);meta=r.get('local_mother_candidate')
 if not meta:return r
 selection='selected' if r.get('mother_reply_text') else 'alternative' if r.get('alternative_mother_reply_text') else 'held'
 if selection!=meta.get('selection_preserved') or selection=='held':raise ValueError('cannot alter existing selection or restore held')
 kind=meta.get('draft_type') or ('basic_pending' if meta.get('status')=='basic_draft_pending_pool_binding' else None)
 if kind not in LABELS:raise ValueError('unknown draft type '+str(kind))
 if r.get('send_authorized') is not False or r.get('can_send_now') is not False:raise ValueError('send flags must be false')
 backup={k:r.get(k) for k in ('reply_generation_strategy','reply_status')};presence={k:k in r for k in backup}
 r['reply_generation_strategy'],r['reply_status']=LABELS[kind]
 r['consumer_draft_metadata']={'draft_type':kind,'selection':selection,'original_metadata_backup':backup,'original_metadata_present':presence,'template_version_semantic_gate_passed':False,'review_scope':'version_semantic_gate_pending; individual_record_not_asserted_reviewed','contact_review_required':bool(meta.get('contact_review_required')),'contact_eligible':'not_assessed','send_authorized':False,'can_send_now':False}
 return r
def restore_metadata(row):
 r=copy.deepcopy(row);m=r.pop('consumer_draft_metadata',None)
 if m:
  for k,v in m['original_metadata_backup'].items():
   if m['original_metadata_present'][k]:r[k]=v
   else:r.pop(k,None)
 return r
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--candidate',required=True);ap.add_argument('--output-dir',required=True);args=ap.parse_args();src=pathlib.Path(args.candidate).resolve();dst=pathlib.Path(args.output_dir).resolve()
 if O not in dst.parents or O not in src.parents:raise ValueError('bridge must stay in isolated package')
 dst.mkdir(parents=True,exist_ok=True);cm=load(src/'candidate-manifest.json');cp=load(src/'candidate-pointer.json')
 if cp['activated'] or cp['send_authorized'] or not cm['status'].startswith('candidate_only_needs_independent'):raise ValueError('unsafe candidate status')
 for n,h in cm['output_sha256'].items():
  if sha(src/n)!=h:raise ValueError('candidate changed '+n)
 previous=load(src/'immutable-baseline/region-current.json');previous_reply=load(src/'immutable-baseline/reply-pointer.json');oldman=load(previous['manifest']);summary=load(previous['summary']);pre={n:sha(src/'immutable-baseline'/n) for n in cm['immutable_baseline_sha256']}
 if pre!=cm['immutable_baseline_sha256']:raise ValueError('baseline snapshot mismatch')
 for plat,x in oldman['platforms'].items():
  if sha(x['result_file'])!=x['result_sha256']:raise ValueError('classification source SHA mismatch')
 s=copy.deepcopy(summary);cnt=collections.Counter();role_counts=collections.Counter();uids={};selected={};platform_totals={};output_hashes={}
 for plat in ('douyin','xiaohongshu'):
  uids[plat]=set();selected[plat]=set();count=0;target=dst/(plat+'-region-brand-results.jsonl')
  with target.open('w',encoding='utf8',newline='\n') as f:
   for row in jl(src/(plat+'-candidate.jsonl')):
    count+=1;out=bridge_row(row)
    if restore_metadata(out)!=row:raise ValueError('bridge metadata not reversible')
    if row.get('interest_at_comment') in ('high','super_high'):uids[plat].add(row['customer_uid'])
    if row.get('mother_reply_text'):
     if row['customer_uid'] in selected[plat]:raise ValueError('duplicate selected UID')
     selected[plat].add(row['customer_uid'])
    role_counts[(plat,row.get('role'),row.get('demand_state'),row.get('interest_at_comment'))]+=1
    m=out.get('consumer_draft_metadata')
    if m:
     k=m['draft_type'];z=m['selection'];cnt[(plat,z,k)]+=1;cnt[(plat,z,'contact_review_required')]+=int(m['contact_review_required']);cnt[(plat,z,k+'_contact_unknown')]+=int(out.get('contact_policy') in (None,'unknown'))
    f.write(json.dumps(out,ensure_ascii=False,sort_keys=True,separators=(',',':'))+'\n')
  platform_totals[plat]=count;output_hashes[plat]=sha(target);st=s['platforms'][plat];original=summary['platforms'][plat]
  if count!=original['records'] or len(uids[plat])!=original['high_super_high_unique_uids'] or len(selected[plat])!=original['selected_local_mother']:raise ValueError('classification or selection totals mismatch '+plat)
  st['historical_basic_selected']=cnt[(plat,'selected','basic_pending')];st['historical_basic_alternatives']=cnt[(plat,'alternative','basic_pending')];st['historical_basic_candidates_before_dedup']=cnt[(plat,'selected','basic_pending')]+cnt[(plat,'alternative','basic_pending')];st['new_generic_drafts_before_dedup']=st['historical_basic_candidates_before_dedup'];st['new_generic_alternatives_after_dedup']=cnt[(plat,'alternative','basic_pending')];st['historical_comments_untouched_by_short_rewrite']=None
  st['legacy_pool_candidates']={sel:{k:cnt[(plat,sel,k)] for k in ('housing_short_mother','clarification_only','basic_pending','contact_review_required','housing_short_mother_contact_unknown','clarification_only_contact_unknown','basic_pending_contact_unknown')} for sel in ('selected','alternative')}
  st['all_historical_comments_short_rewritten']=False
 if {'|'.join(str(v) for v in k):n for k,n in role_counts.items()}!=cm['classification_counts_unmodified']:raise ValueError('classification aggregate changed')
 s['all_34840_converted_to_short_pool_mothers']=False;s['legacy_pool_short_scope']={'status':'candidate_needs_astra_gate_and_v2_patch','counts_exclude_latest_807':True,'semantic_gate_passed':False,'individually_reviewed_all':False,'classification_or_intent_changed':False,'send_authorized':False};dump(dst/'summary.json',s)
 man=copy.deepcopy(oldman);man['legacy_repaired_candidates']={'candidate_manifest_sha256':sha(src/'candidate-manifest.json'),'repair_contract_file':str(src/'merged-contract.json'),'repair_contract_sha256':sha(src/'merged-contract.json'),'plans_file':str(src/'merged-plans.jsonl'),'plans_sha256':sha(src/'merged-plans.jsonl'),'delta_ledger_sha256':sha(src/'draft-change-ledger.jsonl'),'semantic_gate_passed':False,'semantic_gate_scope':'pending; not per-record approval','v2_patch_status':'not_loaded_pending_ready','published_241_annotations_applied':False,'previous_region_pointer_snapshot':str(src/'immutable-baseline/region-current.json'),'previous_region_pointer_snapshot_sha256':pre['region-current.json'],'send_authorized':False};dump(dst/'manifest.json',man)
 validation={'all_passed':True,'checks':{'source_classification_SHA_and_counts':True,'source_selected_UID_unique':True,'source_records_and_metadata_restore':True,'all_send_flags_false':True,'output_sidecar_SHA':True,'candidate_source_SHA':True},'check_scope':'technical_local_consumer_contract_only','semantic_gate_passed':False,'activation_permitted':False,'v2_patch_status':'not_loaded_pending_ready','human_approved':False};dump(dst/'validation.json',validation)
 cur=copy.deepcopy(previous);cur.update(version='local_review_bridge_repaired_candidate_v1',manifest=str(dst/'manifest.json'),manifest_sha256=sha(dst/'manifest.json'),summary=str(dst/'summary.json'),validation=str(dst/'validation.json'),results={p:str(dst/(p+'-region-brand-results.jsonl')) for p in ('douyin','xiaohongshu')},platform_statistics=s['platforms'],activation_permitted=False,semantic_gate_passed=False)
 cur['result_sha256']={p:output_hashes[p] for p in output_hashes};cur['result_sha256'].update({'summary.json':sha(dst/'summary.json'),'region-tables.json':sha(cur['region_tables']),'store-shared-pools.json':sha(cur['store_shared_pools'])});cur['legacy_repaired_candidates']=man['legacy_repaired_candidates'];dump(dst/'current.json',cur)
 wrapper=copy.deepcopy(previous_reply);wrapper.update(version='local_review_bridge_candidate_v1',reply_strategy='legacy_short_clarification_basic_pending_plus_original_f98_807',activation_permitted=False,template_version_semantic_gate_passed=False,send_authorized=False);wrapper['region_version_pointer']=str(dst/'current.json')
 for plat in ('douyin','xiaohongshu'):
  st=wrapper['platforms'][plat];st['reply_sidecar_file']=cur['results'][plat];st['reply_sidecar_sha256']=output_hashes[plat];st['historical_basic_selected_drafts']=cnt[(plat,'selected','basic_pending')];st['legacy_pool_candidates']=s['platforms'][plat]['legacy_pool_candidates'];st['all_historical_comments_short_rewritten']=False
 dump(dst/'main-reply-pointer.json',wrapper)
 receipt={'status':'candidate_technical_only_v2_and_semantic_gate_pending','candidate_manifest_sha256':sha(src/'candidate-manifest.json'),'classification_sources':{p:{'sha256':x['result_sha256'],'count':x['count']} for p,x in oldman['platforms'].items()},'source_current_snapshot_sha256':pre['region-current.json'],'source_reply_snapshot_sha256':pre['reply-pointer.json'],'input_candidate_output_sha256':cm['output_sha256'],'bridge_result_sha256':output_hashes,'bridge_artifact_sha256':{n:sha(dst/n) for n in ('manifest.json','summary.json','validation.json','current.json','main-reply-pointer.json')},'counts':s['platforms'],'source_classification_and_uid_counts_unchanged':True,'metadata_restorable':True,'send_authorized':False,'activation_permitted':False}
 dump(dst/'bridge-receipt.json',receipt);print(json.dumps({'status':receipt['status'],'result_sha256':output_hashes,'candidate_current_sha256':sha(dst/'current.json'),'candidate_reply_pointer_sha256':sha(dst/'main-reply-pointer.json'),'counts':{p:s['platforms'][p]['legacy_pool_candidates'] for p in ('douyin','xiaohongshu')}},ensure_ascii=False))
if __name__=='__main__':main()
