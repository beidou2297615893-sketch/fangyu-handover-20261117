"""Verify the current local text snapshot against persisted receipts and file hashes."""
import pathlib,json,hashlib,collections,datetime
B=pathlib.Path(__file__).resolve().parent;W=B.parents[2];D=W.parent/'fangyu-douyin-independent'
get=lambda p:json.loads(p.read_text('utf-8-sig'))
jl=lambda p:[json.loads(l) for l in p.read_text('utf-8-sig').splitlines() if l.strip()]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
summary=get(B/'summary.json');current=get(D/'text-screening-current-summary.json');manifest=get(B/'manifest.json')
assert current==summary
result=pathlib.Path(summary['result_file']);assert result.name==B.name+'-results.jsonl'
digest=sha(result);assert digest==summary['result_sha256']==sha(B/'classified-snapshot.jsonl')
rows=jl(result);by={r['comment_id']:r for r in rows};customers={(r['platform'],r['customer_uid']) for r in rows}
assert len(rows)==len(by)==summary['snapshot_unique_comments']==manifest['eligible_snapshot_comments']==34033
assert len(customers)==summary['unique_customers']
assert dict(collections.Counter(r['interest_at_comment'] for r in rows))==summary['interest_counts']
assert sum(r['interest_at_comment'] in ('high','super_high') for r in rows)==summary['high_or_super_comments']
assert len({(r['platform'],r['customer_uid']) for r in rows if r['interest_at_comment'] in ('high','super_high')})==summary['high_or_super_customers']
assert all(r['send_authorized'] is False and r['can_send_now'] is False for r in rows)
assert all(r.get('human_confirmed') is False for r in rows)
assert all(r.get('assigned_store') is None and r.get('store_assignment') is None for r in rows)
drafts=[r for r in rows if r.get('mother_reply_text')];draftfile=jl(B/'mother-drafts.jsonl')
assert len(drafts)==len(draftfile)==summary['local_mother_drafts']
assert {r['comment_id'] for r in drafts}=={r['comment_id'] for r in draftfile}
assert len({(r['platform'],r['customer_uid']) for r in drafts})==len(drafts)
inputs=jl(B/'input.jsonl');new=[by[r['comment_id']] for r in inputs];semantic_sha=sha(B/'semantic-final.jsonl')
assert len(new)==summary['newly_analyzed']==4380
assert dict(collections.Counter(r['interest_at_comment'] for r in new))==summary['new_interest_counts']
for s,r in zip(inputs,new):
 assert all(s[k]==r[k] for k in ('review_key','comment_id','customer_uid','video_id','platform'))
 assert r['human_confirmed'] is False and r['send_authorized'] is False
 assert r['classification_review_source']['sha256']==semantic_sha
 assert pathlib.Path(r['classification_review_source']['path']).resolve()==(B/'semantic-final.jsonl').resolve()
old=jl(pathlib.Path(manifest['prior_result_file']))
assert len(old)==summary['previously_analyzed']==29653
semantic_fields=('role','demand_state','interest_at_comment','topic_evidence','target_regions','time_mentions','other_constraints','possible_topics','evidence','reason','contact_boundaries','reply_plan')
for before in old:
 after=by[before['comment_id']]
 assert all(before.get(k)==after.get(k) for k in semantic_fields),(before['comment_id'],'prior semantic judgment changed')
baseline=get(B/'publication-baseline.json')
for f,h in baseline['code_hashes'].items():assert sha(W/f)==h
for f,h in baseline['frozen_input_hashes'].items():assert sha(B/f)==h
assert sha(pathlib.Path(baseline['source_database_path']))==baseline['source_database_sha256']
state=get(W/'当前文本处理运行状态.json');dy=state['douyin']
assert dy['run']==B.name and dy['classified_comments']==34033 and dy['unprocessed_registered_comments']==0
assert dy['mother_drafts']==summary['local_mother_drafts']
assert state['quota_check']['ordinary_usage_allowed'] is False and state['quota_check']['existing_credits_available'] is True
receipt=get(B/'semantic-compile-receipt.json');assert receipt['AI_initial_and_detailed_complete']==4380
assert receipt['independent_recall_and_level_calibration_complete']==3505
report={'batch':B.name,'verified_at':datetime.datetime.now().astimezone().isoformat(),'result_file':str(result.resolve()),'result_sha256':digest,'snapshot_comments':len(rows),'unique_comment_ids':len(by),'unique_customers':len(customers),'new_comments':len(new),'previous_comments':len(old),'previous_semantic_judgments_unchanged':True,'interest_counts':summary['interest_counts'],'new_interest_counts':summary['new_interest_counts'],'high_or_super_comments':summary['high_or_super_comments'],'high_or_super_customers':summary['high_or_super_customers'],'mother_drafts':len(drafts),'draft_customers_unique':True,'AI_initial_and_detailed_complete':4380,'independent_recall_calibration_complete':3505,'audit_changed_records':receipt['audit_changed_records'],'semantic_final_sha256':sha(B/'semantic-final.jsonl'),'all_send_authorized_false':True,'all_can_send_now_false':True,'all_human_confirmed_false':True,'all_store_assignments_null':True,'immutable_input_hashes_unchanged':True,'locked_code_hashes_unchanged':True,'source_database_sha256_unchanged':True,'current_result_pointer_and_summary_match':True,'ordinary_usage_allowed':False,'existing_credits_authorized':True,'actual_task_usage':'unknown','text_task_send_attempted':False,'platform_delivery_state':'not_checked_by_text_task','not_accuracy_measurement':True,'passed':True}
(B/'publication-verification.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),'utf-8')
print(json.dumps(report,ensure_ascii=False))
