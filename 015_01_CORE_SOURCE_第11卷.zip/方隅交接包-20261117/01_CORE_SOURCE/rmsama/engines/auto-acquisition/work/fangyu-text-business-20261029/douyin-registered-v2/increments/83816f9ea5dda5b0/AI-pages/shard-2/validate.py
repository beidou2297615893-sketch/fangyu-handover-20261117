import pathlib,json,hashlib,sys,collections,copy,datetime
P=pathlib.Path(__file__).resolve().parent
B=P.parent.parent;W=B.parents[2]
sys.path.insert(0,str(W))
import mother_adapter
read=lambda p:[json.loads(l) for l in p.read_text('utf-8-sig').splitlines() if l.strip()]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
source_path=B/'shard-2.jsonl';source_sha=sha(source_path)
adapter_path=pathlib.Path(mother_adapter.__file__).resolve();adapter_sha=sha(adapter_path)
source=read(source_path);by={r['review_key']:r for r in source}
pages=[read(P/f'reviewed-{n:02}.jsonl') for n in range(9)]
rows=[r for a in pages for r in a];decisions=[r for n in range(9) for r in read(P/f'explicit-decisions-{n:02}.jsonl')]
assert [len(a) for a in pages]==[180]*8+[20]
assert len(source)==len(by)==len(rows)==len(decisions)==1460
assert {r['review_key'] for r in rows}==set(by)=={r['review_key'] for r in decisions}
assert len({r['review_key'] for r in rows})==1460
assert len({r['comment_id'] for r in rows})==1460
assert {r['comment_id'] for r in rows}=={r['comment_id'] for r in source}
quote_count=0;groups=collections.defaultdict(list);unknowns=[]
POOLS=['价格预算','位置通勤','户型面积与居住方式','房内设施','宠物','楼层电梯','入住与租期','房源状态','费用合同','看房联系']
for r in rows:
 s=by[r['review_key']]
 for k in ('review_key','comment_id','customer_uid','video_id','platform'):assert r[k]==s[k],(r['review_key'],k)
 allowed=[s['comment_text']]+([s['post_body']] if s['post_author_same_as_commenter'] else [])
 for q in r['evidence']+[x['quote'] for f in ('topics','target_regions','time_mentions','other_constraints','contact_boundaries','possible_topics') for x in r[f] if 'quote' in x]:
  assert any(q in t for t in allowed),(r['review_key'],q)
  quote_count+=1
 for t in r['topics']:assert t['pool'] in POOLS
 assert r['human_confirmed'] is False and r['send_authorized'] is False and r['store_assignment'] is None
 assert r['reply_plan']['preferred_mother_slot'] in (None,1,2,7,13,16,19,25,28,31,34)
 assert not any(k in r for k in ('classification_method','classification_stages_completed','classification_review_source','reply_text','mother_reply_text'))
 if r['role']=='unknown':assert r['interest']=='uncertain'
 groups[(s['video_id'],s['comment_text'],s['post_author_same_as_commenter'],str(s.get('parent_comment')),s.get('source_version_conflict'))].append(r)
conflicts=[]
for k,g in groups.items():
 if len(g)>1:
  if len({(r['role'],r['demand_state'],r['interest'],r['reply_plan']['preferred_mother_slot'],r['reply_plan']['generic_intro_suitable']) for r in g})>1:conflicts.append({'video_id':k[0],'text':k[1],'keys':[r['review_key'] for r in g]})
assert not conflicts,conflicts
out=B/'reviewed-new-2.jsonl';out.write_bytes(b''.join((P/f'reviewed-{n:02}.jsonl').read_bytes() for n in range(9)))
assert read(out)==rows
assert out.read_bytes()==b''.join((P/f'reviewed-{n:02}.jsonl').read_bytes() for n in range(9))
stage=[dict(copy.deepcopy(r),classification_method='ai_semantic_initial_and_detailed',classification_stages_completed=['initial_semantic','detailed_semantic']) for r in rows]
stage_path=P/'isolated-semantic-stages.jsonl';stage_path.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in stage),'utf-8');stage_sha=sha(stage_path)
cache={};validated=[]
for r in stage:
 r=copy.deepcopy(r);r['classification_review_source']={'path':str(stage_path),'sha256':stage_sha}
 mother_adapter.validate_new_review(r,B,cache);validated.append(r)
preflight=P/'isolated-adapter-preflight.jsonl';preflight.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in validated),'utf-8')
assert len(read(preflight))==1460
assert sha(source_path)==source_sha and sha(adapter_path)==adapter_sha
validation={'batch':'83816f9ea5dda5b0','shard':2,'input_count':1460,'output_count':1460,'explicit_decision_count':1460,'page_counts':[len(a) for a in pages],'completed_pages':list(range(9)),'review_key_set_equal':True,'comment_id_set_equal':True,'metadata_tuple_equal':True,'evidence_quotes_checked':quote_count,'evidence_exact_match':True,'page_concat_bytes_equal':True,'same_context_duplicate_groups':sum(len(g)>1 for g in groups.values()),'same_context_core_conflicts':conflicts,'formal_adapter_preflight_passed':1460,'adapter':str(adapter_path),'adapter_sha256':adapter_sha,'adapter_unmodified_during_preflight':True,'source_shard_sha256':source_sha,'source_shard_unmodified':True,'isolated_source':str(stage_path),'isolated_sha256':stage_sha,'isolated_bound_rows':str(preflight),'isolated_bound_rows_sha256':sha(preflight),'semantic_review_sha256':sha(out),'page_sha256':{f'reviewed-{n:02}.jsonl':sha(P/f'reviewed-{n:02}.jsonl') for n in range(9)},'roles':dict(collections.Counter(r['role'] for r in rows)),'interests':dict(collections.Counter(r['interest'] for r in rows)),'mothers':dict(collections.Counter(str(r['reply_plan']['preferred_mother_slot']) for r in rows)),'classification':'same model initial and detailed semantic judgment for every key; not independent second review or human gold','formal_compiler_binding_pending':True,'usage':'unknown','credits':'parent task explicitly authorized existing credits; no purchase','platform_calls':0,'sent':0,'human_confirmed':False,'send_authorized':False,'store_assignment':None,'checked_at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(B/'shard-2-validation.json').write_text(json.dumps(validation,ensure_ascii=False,indent=2),'utf-8')
(P/'progress.json').write_text(json.dumps({'shard':2,'completed_pages':list(range(9)),'reviewed_count':1460,'expected_count':1460,'formal_adapter_preflight_passed':1460,'status':'complete_wait_shard0_independent_audit','independent_review_claimed':False,'usage':'unknown','updated_at':validation['checked_at']},ensure_ascii=False,indent=2),'utf-8')
report=f'''# 抖音第三片判读与核验记录

本片1460条已完整读取9页共享正文及每条评论，逐key完成同轮AI初筛与细筛。前8页各180条，末页20条；逐页reviewed与progress均已保存。显式决定1460条，无默认补判；本地程序只把已写明的模型决定序列化，并核对身份、字节和逐字证据，不用关键词代判意向。

输入输出的review_key、comment_id、customer_uid、video_id、platform逐条一致，键与评论ID集合一致，无缺失或重复。正式汇总等于9页字节连接。逐字引文{quote_count}处通过，只取本人评论或严格同作者正文。同帖同文相同上下文的{validation['same_context_duplicate_groups']}组重复，核心标签、首选槽位及通用接话适合性无片内冲突；跨片一致性仍由协调者及独立审计核对。

保留了购房与租房用途、招室友供给与本人求租、现居与旧经历、保障申请及商业租赁接受度差别。工作地、现居、查询对象与目标地区分开，不从IP和采集门店补目标。多地双人通勤及OR替代条件保留。泊车、充电车位、儿童活动、房补、卫生与品质等十池之外条件单列；金额单位不明不补数值。裸多少/多少米不直接填确定价格或面积池。月/年计价不当实际总租期，实习时长不当承租总时长，入住与找房动作分开。相对时点只依发表时点，旧评论不直接判结束，也不宣称今日仍有效。

同作者D2415可引用本人看房正文预算5000，保留空间不足新信息；其他作者条件不转移。D2355、D3831、D3897等是即时或具体时段看房请求，不表示预约已成功；D3756为明确请带看协助，细筛升为超高。泛电话、微信、能看房仍不自动超高。中介勿扰、小程序渠道等限制只按范围保留，不扩大成全面拒联。

细筛作7项显式语义修订，原字节保留于本片before-detailed-refinement目录，修订日志为detailed-refinement-log.json；它们包括年度报价与租期拆分、未来居住愿望不当未来才找房、长期合作歧义和明确带看请求。这些是同模型细筛，不虚称独立复核。未以格式修正名义覆盖语义变化。

回复只包含认可槽位的reply_plan，没有新写回复正文。专项及通用母句涉及的真实住户、同店同房源条件、当前报价房态、优惠时效与介绍资格均保留事实缺口；allow不等于发送许可。未给门店指派，未编造房源。

已调用未修改的mother_adapter.validate_new_review，对实际写出的隔离语义JSONL、真实文件SHA绑定及隔离待验行全量预检，1460条通过。编译方法和阶段只补入隔离预检文件，正式评审不冒充compiler绑定；正式compiler绑定、独立审计、本地发布交由shard0协调者。源分片与adapter前后SHA一致。

正式评审SHA256：{validation['semantic_review_sha256']}
隔离语义源SHA256：{stage_sha}

实际usage未知，不用账户余额差额或任务数推算费用。existing credits已获授权，未购买。无平台调用、源库/产品代码修改、发送或全局状态修改。human_confirmed=false，send_authorized=false，store_assignment=null。完成本片核验后停止，等待协调者独立审计。
'''
(B/'shard-2-report.md').write_text(report,'utf-8')
print(json.dumps({k:validation[k] for k in ('input_count','output_count','explicit_decision_count','page_counts','evidence_quotes_checked','same_context_duplicate_groups','formal_adapter_preflight_passed','semantic_review_sha256','isolated_sha256','roles','interests')},ensure_ascii=False,indent=2))
