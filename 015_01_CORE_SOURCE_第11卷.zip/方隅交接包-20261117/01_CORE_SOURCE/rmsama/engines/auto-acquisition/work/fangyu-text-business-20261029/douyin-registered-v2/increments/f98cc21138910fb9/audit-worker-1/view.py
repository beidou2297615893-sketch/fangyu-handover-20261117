import json,pathlib,collections,sys
B=pathlib.Path(__file__).resolve().parent.parent
pages=[json.loads(p.read_text(encoding='utf-8')) for p in sorted((B/'recall-audit/part-1').glob('page-*.json'))]
counts=collections.Counter()
def walk(x):
 if isinstance(x,str):counts[x]+=1
 elif isinstance(x,list):
  for y in x:walk(y)
 elif isinstance(x,dict):
  for y in x.values():walk(y)
for d in pages:walk(d)
shared={s:f'#{i}' for i,(s,c) in enumerate(counts.items()) if c>1 and len(s)>=25}
def convert(x,text=None):
 if isinstance(x,str):
  if text and x==text:return '=原评'
  return shared.get(x,x)
 if isinstance(x,list):return [convert(y,text) for y in x]
 if isinstance(x,dict):return {k:convert(v,text) for k,v in x.items()}
 return x
def out(x):print(json.dumps(x,ensure_ascii=False,separators=(',',':')))
if len(sys.argv)==1:
 for s,k in shared.items():out([k,s])
else:
 pg=int(sys.argv[1]); start=int(sys.argv[2]) if len(sys.argv)>2 else 0; end=int(sys.argv[3]) if len(sys.argv)>3 else 999
 n=0
 for g in pages[pg]['post_groups']:
  selected=[(i,c) for i,c in enumerate(g['comments'],n) if start<=i<end]; n+=len(g['comments'])
  if not selected:continue
  out({'共享正文':g['post_body'],'video':g['video']})
  for i,c in selected:
   j=c['first_semantic_judgment']; p=j['reply_plan']
   obj={'i':i,'key':c['key'],'原评':c['text'],'same_author':c['same_author'],'at':c['published_at'],'parent':c['parent'],'reply_to':c['reply_to'],'conflict':c['source_conflict'],
     '判':[j['role'],j['demand_state'],j['interest'],j['reason']],
     'topics[pool,quote,polarity,subject,scope]':[[v.get(k) for k in ['pool','quote','polarity','subject','condition_scope']] for v in j['topics']],
     'regions[text,quote,relation,group,scope]':[[v.get(k) for k in ['text','quote','relation','group_relation','condition_scope']] for v in j['target_regions']],
     'times':j['time_mentions'],'other':j['other_constraints'],'possible':j['possible_topics'],'review':j['needs_review'],'boundaries':j['contact_boundaries'],'context':j['context_used'],
     'plan[slot,generic,tone,missing,caution,policy,local]':[p['preferred_mother_slot'],p['generic_intro_suitable'],p['tone'],p['missing_facts'],p['caution'],p['contact_policy'],p.get('local_mother')]}
   # Lossless viewer: empty lists omitted; constants printed once in header.
   obj.pop('same_author') if not obj['same_author'] else None
   obj.pop('parent') if obj['parent'] is None else None
   obj.pop('reply_to') if obj['reply_to']=='0' else None
   obj.pop('conflict') if not obj['conflict'] else None
   for k in list(obj):
    if obj[k]==[]:obj.pop(k)
   names={'原评':'T','判':'J','topics[pool,quote,polarity,subject,scope]':'P','regions[text,quote,relation,group,scope]':'R','times':'TM','other':'O','possible':'?','review':'N','boundaries':'B','context':'C','plan[slot,generic,tone,missing,caution,policy,local]':'M'}
   result=convert({names.get(k,k):v for k,v in obj.items()},c['text'])
   result['T']=c['text']
   out(result)
