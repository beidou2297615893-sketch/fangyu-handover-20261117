"""Shorten reusable mother families; preserve customer conditions and uncertainty."""
from pathlib import Path
import json,hashlib,csv,statistics
D=Path(__file__).resolve().parent;W=D.parent;ROOT=W.parents[1]
rows=[json.loads(l) for l in (D/'fifty-review-v2.jsonl').read_text(encoding='utf-8').splitlines()]
templates={
'budget_low':'宝宝，我住方隅，介绍有优惠，想省点租金可以看看。',
'area':'宝宝，我住方隅，{place}有没有合适的，我帮你问，介绍有优惠。',
'occupants':'宝宝，我住方隅，{count}个人住的房型帮你问，介绍有优惠。',
'requirements':'宝宝，我住方隅，{requirements}帮你核实，介绍有优惠。',
'pet':'宝宝，我住方隅，狗狗多大？能否带我帮你问，介绍有优惠。',
'elevator':'宝宝，我住方隅，有没有电梯帮你问，介绍有优惠。',
'floor':'宝宝，我住方隅，楼层、电梯帮你问，介绍有优惠。',
'monthly':'宝宝，我住方隅，月租多久呀？我帮你问，介绍有优惠。',
'urgent':'宝宝，我住方隅，现房和最早入住时间先帮你问，介绍有优惠。',
'available':'宝宝，我住方隅，空房帮你问，介绍有优惠。',
'rent_process':'宝宝，我住方隅，租金、押付和看房帮你对接，介绍有优惠。',
'contact':'宝宝，可以聊呀！我住方隅，空房帮你问，介绍有优惠。',
'contact_how':'宝宝，点我聊就行，我住方隅，介绍有优惠。',
'room_price_location':'宝宝，我住方隅，{room}的租金和位置帮你问，介绍有优惠。',
'all_in_budget':'宝宝，我住方隅，介绍有优惠。{place}附近，房租水电气{budget}，对吗？',
'price_location':'宝宝，我住方隅，位置发你，租金帮你问，介绍有优惠。',
'area_room':'宝宝，我住方隅，{place}的{room}帮你问，介绍有优惠。',
'unknown_room_location':'宝宝，我住方隅，{room}和位置帮你问，介绍有优惠。',
'relocation':'宝宝，我住方隅，介绍有优惠。明年搬{place}后想住附近吗？租金帮你问。',
'weak_wish':'宝宝，你也想合租吗？我住方隅，可以给你看看房型。',
'location':'宝宝，我住方隅，位置可以发你，介绍有优惠。',
'budget_two_places':'宝宝，我住方隅，介绍有优惠。{budget}、{room}；{place_a}、{place_b}都考虑吗？',
'line':'宝宝，我住方隅，位置发你看看离{line}多远，介绍有优惠。',
'living_mode':'宝宝，我住方隅，你想整租还是合租呀？介绍有优惠。',
'move_in':'宝宝，我住方隅，{when}起租的房态和租期帮你问，介绍有优惠。',
'utilities':'宝宝，我住方隅，是不是民水民电我帮你问，介绍有优惠。',
'pet_cat':'宝宝，我住方隅，猫猫能否带、是否另收费，我帮你问，介绍有优惠。',
'place_clarify':'宝宝，“{raw_place}”是{possible_place}吗？我住方隅，介绍有优惠。',
'share_budget':'宝宝，两人合租总预算多少呀？我住方隅，介绍有优惠。',
'price':'宝宝，我住方隅，租金帮你问，介绍有优惠。'
}
out=[]
for r in rows:
    values=dict(r['local_fill'])
    if r['family']=='requirements':
        values['requirements']=values['requirements'].replace('的一居室','一居室').replace('，还有','、').replace('这几样','').replace('这点','')
        if values['requirements']=='卫生间不在阳台':values['requirements']='卫生间不在阳台的房型'
    if r['family']=='area_room' and not values['place'].endswith('附近'):
        values['place']+='附近'
    text=templates[r['family']].format(**values)
    assert len(text)<len(r['reply_text']),(r['display_order'],len(text),len(r['reply_text']))
    assert '我住方隅' in text
    assert not any(x in text for x in ['肯定有','一定有','可以带狗','可以养猫','我们有电梯','都能满足'])
    for key,value in values.items():
        if key=='pet_question':continue
        assert value in text,(r['display_order'],key,value)
    q=dict(r);q.update(prior_long_reply=r['reply_text'],reply_text=text,reply_sha256=hashlib.sha256(text.encode()).hexdigest(),style='short_pool_micro_adjustment_v3',direction_user_approved=True,specific_wording_user_approved=False)
    out.append(q)
assert len(out)==50
(D/'pool-mother-short-variants.json').write_text(json.dumps({'direction_user_approved':True,'templates':templates,'facts_still_require_verification':True,'send_authorized':False},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
(D/'fifty-review-v3-short.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in out),encoding='utf-8')
O=ROOT/'outputs/方隅双平台文本业务/地区归类与品牌母句';lines=['# 首批50条真实评论与短版母句','', '保留原评、分类及必要条件，压缩回复铺垫；原长版留存。本批为方向获认可后的短版展示，未发送。','']
for p,label in [('douyin','抖音'),('xiaohongshu','小红书')]:
    lines+=['## '+label,'','| 序号 | 真实原评论 | 短版回复 |','|---:|---|---|']
    for r in out:
        if r['platform']==p:lines.append('| '+str(r['display_order'])+' | '+r['comment_text'].replace('|','\\|').replace('\n','<br>')+' | '+r['reply_text']+' |')
    lines.append('')
(O/'首批50条真实评论与短版回复.md').write_text('\n'.join(lines),encoding='utf-8')
v={'records':50,'all_shorter_than_prior_version':True,'all_supplied_condition_slots_preserved':True,'comment_text_and_source_id_unchanged':all(a['comment_sha256']==b['comment_sha256'] and a['comment_id']==b['comment_id'] for a,b in zip(rows,out)),'mean_before':round(statistics.mean(len(r['reply_text']) for r in rows),1),'mean_after':round(statistics.mean(len(r['reply_text']) for r in out),1),'max_after':max(len(r['reply_text']) for r in out),'direction_user_approved':True,'specific_wording_user_approved':False,'per_row_model_calls':0,'send_authorized':False,'whole_corpus_replaced':False}
(D/'short-validation.json').write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(v,ensure_ascii=False))
for r in out:print(str(r['display_order'])+' '+r['reply_text'])
