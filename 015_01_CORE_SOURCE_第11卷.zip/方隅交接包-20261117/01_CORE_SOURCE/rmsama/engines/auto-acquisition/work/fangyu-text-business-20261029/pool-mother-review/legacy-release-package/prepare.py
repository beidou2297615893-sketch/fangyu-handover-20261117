"""Deterministic review-only assembly; never activates a source pointer or sends."""
import argparse,collections,copy,hashlib,importlib.util,json,pathlib,sys
sys.dont_write_bytecode=True
O=pathlib.Path(__file__).resolve().parent;W=O.parents[1];A=W/'pool-mother-review/legacy-local-planning-v2';B=W/'pool-mother-review/legacy-combo-families';OLD=W/'pool-mother-review/legacy-local-planning';R=W/'douyin-registered-v2/increments/f98cc21138910fb9'
spec=importlib.util.spec_from_file_location('locked_renderer',R/'batch_short_mothers.py');renderer=importlib.util.module_from_spec(spec);spec.loader.exec_module(renderer)
def objsha(x):return hashlib.sha256(json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def sha(p):
 h=hashlib.sha256()
 with pathlib.Path(p).open('rb') as f:
  for chunk in iter(lambda:f.read(1048576),b''):h.update(chunk)
 return h.hexdigest()
def load(p):return json.loads(pathlib.Path(p).read_text(encoding='utf8'))
def jl(p):
 with pathlib.Path(p).open(encoding='utf8') as f:
  for line in f:
   if line.strip():yield json.loads(line)
def dump(p,x):pathlib.Path(p).write_text(json.dumps(x,ensure_ascii=False,sort_keys=True,indent=2)+'\n',encoding='utf8')
def putjl(p,rows):
 with pathlib.Path(p).open('w',encoding='utf8',newline='\n') as f:
  for x in rows:f.write(json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':'))+'\n')
def key(p):return (str(p['platform']),str(p['cid']),str(p['uid']))
def validate_unique(rows):
 seen=set(); cids=set()
 for p in rows:
  k=key(p); c=(k[0],k[1])
  if k in seen or c in cids:raise ValueError('duplicate CID or CID/UID: '+str(k))
  seen.add(k);cids.add(c)
def merge_addon(contract,addon):
 out=copy.deepcopy(contract)
 for name,definition in addon['families'].items():
  if name in out['families']:raise ValueError('addon family collision: '+name)
  out['families'][name]=copy.deepcopy(definition)
 return out
def verify_binding(p,r,source_file_sha):
 if key(p)!=(str(r['platform']),str(r['comment_id']),str(r['customer_uid'])):raise ValueError('identity mismatch')
 if p['sourceSHA']!=hashlib.sha256(r['comment_text'].encode('utf8')).hexdigest():raise ValueError('comment SHA mismatch')
 if p['source_file_sha256']!=source_file_sha:raise ValueError('container SHA mismatch')
 if p['original_classification_sha256']!=objsha(r.get('source_record') or {}):raise ValueError('source record mismatch')
 if p.get('send_authorized') is not False or p.get('can_send_now') is not False or r.get('send_authorized') is not False or r.get('can_send_now') is not False:raise ValueError('send permission must remain false')
 selection='selected' if r.get('mother_reply_text') else 'alternative' if r.get('alternative_mother_reply_text') else 'held'
 if selection!=p['selection']:raise ValueError('selection mismatch')
 if r.get('mother_reply_text') and r.get('alternative_mother_reply_text'):raise ValueError('ambiguous source selection')
 original_policy=r.get('contact_policy');stored_policy=p.get('contact_policy_original')
 if original_policy!=stored_policy and not (original_policy is None and stored_policy==(r.get('reply_plan') or {}).get('contact_policy')):raise ValueError('contact policy mismatch')
 return selection
def render_checked(p,r,contract):
 if p.get('family') not in contract['families']:raise ValueError('unknown family')
 row={'role':r.get('role'),'demand_state':r.get('demand_state'),'interest_at_comment':r.get('interest_at_comment'),'source_version_conflict':bool((r.get('source_record') or {}).get('source_version_conflict')),'reply_plan':{'local_mother':{'family':p['family'],'fill':p['fill'],'evidence':p['evidence']},'contact_policy':r.get('contact_policy') or 'unknown','tone':(r.get('reply_plan') or {}).get('tone') or r.get('effective_tone')}}
 try:result=renderer.render_plan(row,r['comment_text'],contract)
 except (ValueError,KeyError,TypeError) as e:raise ValueError('renderer failed: '+str(e)) from e
 if not result.get('validated_plan_text'):raise ValueError('no validated text')
 return result
def candidate_for(p,r,contract,source_file_sha):
 selection=verify_binding(p,r,source_file_sha);s=r.get('source_record') or {};policy=r.get('contact_policy');plan_policy=(r.get('reply_plan') or {}).get('contact_policy')
 if policy=='no_contact' or plan_policy=='no_contact' or r.get('contact_boundaries') or s.get('source_version_conflict') or r.get('source_version_conflict'):raise ValueError('explicit contact boundary or source conflict')
 if selection=='held' or r.get('role')!='demand' or r.get('demand_state')!='active_at_comment' or r.get('interest_at_comment') not in ('medium','high','super_high'):raise ValueError('original state not eligible for preview replacement')
 result=render_checked(p,r,contract);out=copy.deepcopy(r);field='mother_reply_text' if selection=='selected' else 'alternative_mother_reply_text';out[field]=result['validated_plan_text']
 out['local_mother_candidate']={'status':'candidate_needs_independent_semantic_gate','draft_type':'clarification_only' if p.get('clarification_only') else 'housing_short_mother','selection_preserved':selection,'family':p['family'],'fill':copy.deepcopy(p['fill']),'evidence':copy.deepcopy(p['evidence']),'old_draft_backup':{'mother_reply_text':r.get('mother_reply_text'),'alternative_mother_reply_text':r.get('alternative_mother_reply_text'),'reply_status':r.get('reply_status'),'source_version_sha256':source_file_sha},'renderer_status':result['status'],'renderer_text':result['text'],'contact_original':r.get('contact_policy'),'contact_review_required':policy in (None,'unknown','manual_review','identity_restricted','manual') or result.get('contact_identity_manual_review',False),'contact_eligible':'not_assessed','fact_gaps':copy.deepcopy(p.get('source_metadata_preserved') or {'original_reply_missing_facts':r.get('original_reply_missing_facts'),'reply_plan_missing_facts':(r.get('reply_plan') or {}).get('missing_facts')}),'send_authorized':False,'can_send_now':False,'plan_origin':p.get('plan_origin','A'),'overlay_fact_checks':copy.deepcopy(p.get('overlay_fact_checks') or []),'overlay_original_semantic_scope_flags':copy.deepcopy(p.get('overlay_original_semantic_scope_flags') or [])}
 return out
def overlay(base,extra,origin,scope):
 validate_unique(extra); out={key(p):copy.deepcopy(p) for p in base}; original={key(p):p for p in base}
 for q in extra:
  k=key(q)
  if k not in out:raise ValueError(origin+' unknown ID '+str(k))
  p=out[k]
  if p.get('next_action_category')!=scope or p.get('family'):raise ValueError(origin+' scope or already bound '+str(k))
  for f in ('sourceSHA','source_file_sha256','original_classification_sha256'):
   if q[f]!=p[f]:raise ValueError(origin+' original binding mismatch '+f)
  qpolicy=q.get('original_contact_policy') if origin=='B' else q.get('contact_policy_original')
  if qpolicy!=p.get('contact_policy_original'):raise ValueError(origin+' contact changed')
  if q.get('send_authorized') is not False or q.get('can_send_now') is not False or q.get('classification_changed') is not False:raise ValueError(origin+' permission or classification changed')
  z=copy.deepcopy(p);z.update(family=q.get('family'),fill=copy.deepcopy(q.get('fill',{})),evidence=copy.deepcopy(q.get('evidence',[])),plan_origin=origin,overlay_record_sha256=objsha(q),overlay_original_sha256=q.get('original_plan_sha256'),overlay_reason=q.get('unbound_reason'));z['hold_reasons']=[] if q.get('family') else (copy.deepcopy(q.get('hold_reasons')) or [q.get('unbound_reason') or 'overlay_unbound']);z['overlay_fact_checks']=copy.deepcopy(q.get('additional_fact_holds') or q.get('fact_checks_before_external_use') or []);z['overlay_original_semantic_scope_flags']=copy.deepcopy(q.get('original_semantic_scope_flags') or []);z['status']='local_plan_proposed' if q.get('family') else 'local_plan_held';out[k]=z
 return [out[key(p)] for p in base]
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--c-manifest');ap.add_argument('--output-dir',default=str(O/'candidate-ab'));args=ap.parse_args(); dest=pathlib.Path(args.output_dir).resolve()
 if dest!=O and O not in dest.parents:raise ValueError('output must stay in package directory')
 dest.mkdir(parents=True,exist_ok=True)
 va=load(A/'validation.json');vb=load(B/'validation.json');mb=load(B/'artifact-sha256.json');ma=load(A/'plan-source-manifest.json');cur=load(W/'region-brand-routing/current.json')
 if not va['all_passed'] or vb['input_count']!=223 or vb['bound_count']!=221:raise ValueError('upstream validation incomplete')
 for n,h in va['outputs_sha256'].items():
  if sha(A/n)!=h:raise ValueError('A hash mismatch '+n)
 for n,h in mb.items():
  if sha(B/n)!=h:raise ValueError('B hash mismatch '+n)
 protected=dict(ma['protected_sources_sha256']);protected.update(vb['source_sha_before']);protected.update({str((A/n).resolve()):h for n,h in va['outputs_sha256'].items()});protected.update({str((B/n).resolve()):h for n,h in mb.items()});protected[str((A/'validation.json').resolve())]=sha(A/'validation.json');protected[str((B/'artifact-sha256.json').resolve())]=sha(B/'artifact-sha256.json');protected[str(pathlib.Path(__file__).resolve())]=sha(__file__)
 pre={p:sha(p) for p in protected}
 mismatches={p:{'planning_sha256':protected[p],'build_start_sha256':h} for p,h in pre.items() if protected[p]!=h}
 allowed_discrepancy=str((W/'当前文本处理运行状态.json').resolve())
 if set(mismatches)-{allowed_discrepancy}:raise ValueError('protected inputs changed '+str(mismatches))
 original=list(jl(OLD/'local-proposed-plans.jsonl'));orig={key(p):p for p in original};base=list(jl(A/'local-proposed-plans.jsonl'));extra=list(jl(B/'source-bound-plans.jsonl'));validate_unique(base);validate_unique(extra)
 if len(base)!=12963 or len(extra)!=223:raise ValueError('upstream scope count mismatch')
 for q in extra:
  k=key(q)
  if k not in orig or q['original_plan_sha256']!=objsha(orig[k]) or q['source_original_preserved']!=orig[k]:raise ValueError('B original source plan mismatch '+str(k))
 contract=merge_addon(load(A/'local-mother-contract-v2.json'),load(B/'contract-addon.json'));plans=overlay(base,extra,'B','integrated_family_gap_no_reclassification_needed');cstate='pending_manifest_not_loaded'
 if args.c_manifest:
  cp=pathlib.Path(args.c_manifest).resolve();cm=load(cp)
  if cm.get('status')!='complete' or cm.get('scope')!='literal_extraction_or_existing_pool_binding_gap' or cm.get('input_count')!=4620:raise ValueError('C completion manifest incompatible or incomplete')
  for name in ('plans','contract_addon'):
   d=cm[name];path=pathlib.Path(d['path']).resolve()
   if sha(path)!=d['sha256']:raise ValueError('C artifact SHA mismatch '+name)
   protected[str(path)]=d['sha256'];pre[str(path)]=d['sha256']
  protected[str(cp)]=sha(cp);pre[str(cp)]=sha(cp)
  for item in cm.get('lineage',[]):
   lp=pathlib.Path(item['path']).resolve();actual=sha(lp)
   if actual!=item['sha256']:raise ValueError('C lineage SHA mismatch '+str(lp))
   protected[str(lp)]=actual;pre[str(lp)]=actual
  more=list(jl(cm['plans']['path']))
  if len(more)!=4620:raise ValueError('C full scope expected 4620')
  for q in more:
   k=key(q)
   if k not in orig or q.get('original_plan_sha256')!=objsha(orig[k]):raise ValueError('C original source plan mismatch '+str(k))
  contract=merge_addon(contract,load(cm['contract_addon']['path']));plans=overlay(plans,more,'C','literal_extraction_or_existing_pool_binding_gap');cstate='loaded_complete_manifest'
 by={key(p):p for p in plans};seen=set();counts=collections.Counter();platform_totals=collections.Counter();class_counts=collections.Counter();changed=collections.Counter();note_rows=[]
 dump(dest/'merged-contract.json',contract);putjl(dest/'merged-plans.jsonl',plans)
 for platform,path in cur['results'].items():
  digest=sha(path); outpath=dest/(platform+'-candidate.jsonl')
  with outpath.open('w',encoding='utf8',newline='\n') as f:
   for r in jl(path):
    k=(platform,str(r['comment_id']),str(r['customer_uid']));platform_totals[platform]+=1;class_counts[(platform,r.get('role'),r.get('demand_state'),r.get('interest_at_comment'))]+=1
    if r.get('send_authorized') is not False or r.get('can_send_now') is not False:raise ValueError('source send flags not false '+str(k))
    p=by.get(k);out=r
    if p:
     if k in seen:raise ValueError('duplicate source row '+str(k))
     seen.add(k);selection=verify_binding(p,r,digest)
     if p.get('family'):
      out=candidate_for(p,r,contract,digest);kind=out['local_mother_candidate']['draft_type'];counts[(platform,selection,kind)]+=1;counts[(platform,selection,'contact_review_required')]+=int(out['local_mother_candidate']['contact_review_required']);counts[(platform,selection,kind+'_contact_unknown')]+=int(r.get('contact_policy') in (None,'unknown'));changed[(platform,selection)]+=1
     else:
      out=copy.deepcopy(r);out['local_mother_candidate']={'status':'basic_draft_pending_pool_binding','selection_preserved':selection,'hold_reasons':p['hold_reasons'],'contact_original':r.get('contact_policy'),'contact_review_required':r.get('contact_policy') in (None,'unknown','manual_review','identity_restricted','manual'),'contact_eligible':'not_assessed','send_authorized':False,'can_send_now':False};counts[(platform,selection,'basic_pending')]+=1;counts[(platform,selection,'contact_review_required')]+=int(out['local_mother_candidate']['contact_review_required']);counts[(platform,selection,'basic_pending_contact_unknown')]+=int(r.get('contact_policy') in (None,'unknown'))
    if out.get('source_record')!=r.get('source_record') or out.get('original_reply')!=r.get('original_reply') or out.get('routing')!=r.get('routing') or out.get('contact_policy')!=r.get('contact_policy') or out.get('contact_boundaries')!=r.get('contact_boundaries') or out.get('comment_text')!=r.get('comment_text') or out.get('send_authorized') is not False or out.get('can_send_now') is not False:raise ValueError('source invariant violated '+str(k))
    restored=copy.deepcopy(out);meta=restored.pop('local_mother_candidate',None)
    if meta and meta.get('old_draft_backup'):
     restored['mother_reply_text']=meta['old_draft_backup']['mother_reply_text'];restored['alternative_mother_reply_text']=meta['old_draft_backup']['alternative_mother_reply_text']
    if restored!=r:raise ValueError('complete original row invariant violated '+str(k))
    f.write(json.dumps(out,ensure_ascii=False,sort_keys=True,separators=(',',':'))+'\n')
 if seen!=set(by):raise ValueError('missing planned rows '+str(len(set(by)-seen)))
 fixes=list(jl(A/'published-241-proposed-fixes.jsonl'));published={r['review_key']:r for r in jl(R/'pool-short-reply-plans.jsonl') if r['review_key'] in ('D0029','D0437')};semantic={r['review_key']:r for r in jl(R/'semantic-final.jsonl') if r['review_key'] in published}
 if len(fixes)!=2 or set(published)!={'D0029','D0437'}:raise ValueError('published patch scope')
 for fix in fixes:
  old=published[fix['review_key']];sem=semantic[fix['review_key']];prop=fix['proposed_plan_only']
  if old['comment_id']!=fix['cid'] or old['customer_uid']!=fix['uid'] or old['source_comment_sha256']!=fix['sourceSHA'] or fix['source_plan_file_sha256']!=sha(R/'pool-short-reply-plans.jsonl') or hashlib.sha256(fix['source_comment'].encode('utf8')).hexdigest()!=fix['sourceSHA'] or old['local_mother']['family']!=fix['old_family'] or old['local_mother']['fill']!=fix['old_fill'] or sem['comment_id']!=fix['cid'] or sem['customer_uid']!=fix['uid']:raise ValueError('published fix source identity')
  r={'platform':'douyin','comment_id':fix['cid'],'customer_uid':fix['uid'],'comment_text':fix['source_comment'],'role':sem['role'],'demand_state':sem['demand_state'],'interest_at_comment':sem.get('interest_at_comment',sem.get('interest')),'reply_plan':sem['reply_plan'],'contact_policy':sem['reply_plan'].get('contact_policy')}
  p={'family':prop['family'],'fill':prop['fill'],'evidence':prop['evidence']};render=render_checked(p,r,contract)
  note_rows.append({'review_key':fix['review_key'],'cid':fix['cid'],'uid':fix['uid'],'sourceSHA':fix['sourceSHA'],'source_comment':fix['source_comment'],'old_plan':old['local_mother'],'old_renderer_output':old['rendered'],'old_contract_sha256':sha(R/'local-mother-contract.json'),'old_plan_file_sha256':sha(R/'pool-short-reply-plans.jsonl'),'proposed_plan':prop,'proposed_renderer_output':render,'draft_preview':render['validated_plan_text'],'status':'proposed_annotation_only_not_applied','send_authorized':False})
 putjl(dest/'published-fix-annotations.jsonl',note_rows)
 post={p:sha(p) for p in protected}
 if post!=pre:raise ValueError('input changed during build')
 def group(c):
  x={}
  for (platform,selection,kind),v in sorted(c.items()):x.setdefault(platform,{}).setdefault(selection,{})[kind]=v
  return x
 outputfiles=['merged-contract.json','merged-plans.jsonl','douyin-candidate.jsonl','xiaohongshu-candidate.jsonl','published-fix-annotations.jsonl'];outputs={n:sha(dest/n) for n in outputfiles}
 manifest={'status':'candidate_only_needs_independent_semantic_gate','C_status':cstate,'input_sha256_before':pre,'input_sha256_after':post,'planning_snapshot_difference':mismatches,'output_sha256':outputs,'counts':group(counts),'candidate_rows':dict(platform_totals),'classification_counts_unmodified':{'|'.join(str(z) for z in k):v for k,v in class_counts.items()},'no_source_write':True,'no_pointer_update':True,'send_authorized':False,'qa_200_is_regression_not_fresh_holdout':True,'published_annotations_not_applied':True}
 dump(dest/'candidate-manifest.json',manifest)
 pointer={'status':'candidate_only_needs_independent_semantic_gate','candidate_manifest':str(dest/'candidate-manifest.json'),'candidate_manifest_sha256':sha(dest/'candidate-manifest.json'),'results':{p:str(dest/(p+'-candidate.jsonl')) for p in cur['results']},'C_status':cstate,'source_current_sha256':sha(W/'region-brand-routing/current.json'),'activated':False,'send_authorized':False};dump(dest/'candidate-pointer.json',pointer)
 print(json.dumps({'status':manifest['status'],'C_status':cstate,'counts':group(counts),'candidate_rows':dict(platform_totals),'annotations':len(note_rows),'output_sha256':outputs},ensure_ascii=False))
if __name__=='__main__':main()
