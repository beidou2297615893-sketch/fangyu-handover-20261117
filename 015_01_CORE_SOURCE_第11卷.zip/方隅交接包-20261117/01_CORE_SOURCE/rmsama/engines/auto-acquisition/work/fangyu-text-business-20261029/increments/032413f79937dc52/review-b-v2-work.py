import json, pathlib, shutil, collections
p=pathlib.Path('work/fangyu-text-business-20261029/increments/032413f79937dc52')
shutil.copy2(p/'reviewed-b.jsonl',p/'reviewed-b-v1.jsonl')
shutil.copy2(p/'b-validation.json',p/'b-validation-v1.json')
rows=[json.loads(x) for x in (p/'reviewed-b-v1.jsonl').open(encoding='utf8')]
by={d['review_key']:d for d in rows}
changed=[]
for d in rows:
 if d['interest']=='unrelated' and d['role']=='unknown':
  k=d['review_key']
  if k in ('I0439','I0485'):
   d['role']='discussion'; d['reason']='针对置换帖讨论购房价格或孩子情况，未表达本人新的租房需求。';d['needs_review']=[]
  else:
   d['interest']='uncertain';d['reason']='现有评论及标题未能确认本人是否有租房需求；相关房源可能涉及出售或交易类型未明。';d['needs_review']=['核对评论对象与原帖交易类型，不能推定本人当前求租。']
  changed.append(k)
for k in ('I0633','I0654'):
 d=by[k]; d['role']='unknown';d['demand_state']='unknown';d['interest']='uncertain';d['reason']='本人表达在看或正在找，但落户工具房语境未说明本人需求的租售方式。';d['needs_review']=['核对本人找的是购房还是租房，及需求是否仍在。'];changed.append(k)
for k in ('I0713','I0727'):
 d=by[k];d['topics']=[t for t in d['topics'] if t['pool']!='价格预算'];d['needs_review'].append('“多少米”是询价还是询问面积需结合上下文确认，暂不归价格或面积池。');changed.append(k)
# Preserve explicit questions as pending topics only, without inferring rental intent.
for key,pools in {'I0659':['户型面积与居住方式','位置通勤'],'I0690':['看房联系'],'I0695':['看房联系'],'I0699':['看房联系'],'I0751':['户型面积与居住方式'],'I0753':['看房联系'],'I0757':['看房联系'],'I0761':['位置通勤'],'I0766':['位置通勤','户型面积与居住方式'],'I0785':['看房联系']}.items():
 d=by[key]
 for pool in pools: d['topics'].append({'pool':pool,'quote':d['evidence'][0],'polarity':'ask'})
# Report complete input set and verify every quote against source comments.
inputs=[json.loads(s) for i in range(4,8) for s in (p/f'shard-{i:02}.jsonl').open(encoding='utf8')]
src={d['review_key']:d for d in inputs}
errors=[]
for d in rows:
 text=src[d['review_key']]['comment_text']
 for q in d['evidence']+[x['quote'] for x in d['topics']]+[x['quote'] for x in d['target_regions']]:
  if q not in text: errors.append(d['review_key'])
inids={(x['review_key'],x['comment_id']) for x in inputs}; outids={(x['review_key'],x['comment_id']) for x in rows}
with (p/'reviewed-b-v2.jsonl').open('w',encoding='utf8',newline='\n') as f:
 for d in rows: f.write(json.dumps(d,ensure_ascii=False)+'\n')
report={'input_count':len(inputs),'output_count':len(rows),'input_unique_key_count':len(inids),'output_unique_key_count':len(outids),'id_sets_equal':inids==outids,'all_quotes_verbatim_in_own_comment':not errors,'quote_errors':errors,'role_counts':dict(collections.Counter(x['role'] for x in rows)),'interest_counts':dict(collections.Counter(x['interest'] for x in rows)),'reviewed_requested_role_interest_count':54,'changed_unrelated_to_uncertain':50,'changed_unknown_to_discussion_unrelated':2,'retained_ended_unrelated':2,'ambiguous_mi_reviewed':['I0713','I0727'],'unknown_unrelated_count':sum(x['role']=='unknown' and x['interest']=='unrelated' for x in rows),'demand_unrelated_nonended_count':sum(x['role']=='demand' and x['interest']=='unrelated' and x['demand_state']!='ended' for x in rows),'model_decisions_not_human_gold':True,'send_authorized':False}
(p/'b-validation-v2.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps(report,ensure_ascii=False,indent=2))
