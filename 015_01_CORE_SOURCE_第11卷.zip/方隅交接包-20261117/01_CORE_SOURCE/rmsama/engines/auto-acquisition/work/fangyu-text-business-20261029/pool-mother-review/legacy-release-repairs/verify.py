"""Independent deterministic verification of frozen source/overlay contract invariants."""
import pathlib,json,hashlib,re,collections,string
O=pathlib.Path(__file__).resolve().parent;P=O.parent;W=P.parent
def load(p):return json.loads(pathlib.Path(p).read_text(encoding='utf8'))
def jl(p):return [json.loads(l) for l in pathlib.Path(p).read_text(encoding='utf8').splitlines() if l.strip()]
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def objsha(x):return hashlib.sha256(json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def key(r):return r['platform'],r.get('cid',r.get('comment_id')),r.get('uid',r.get('customer_uid'))
def put(p,x):pathlib.Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
m=load(O/'manifest.json');contract=load(O/'repair-contract.json');base=jl(P/'legacy-release-package/candidate-abc/merged-plans.jsonl');overlays=jl(O/'source-bound-plan-overlays.jsonl');regress=jl(O/'old-QA-regression.jsonl');stats=load(O/'statistics.json')
assert all(sha(p)==h for p,h in m['source_SHA256'].items());assert all(sha(O/n)==h for n,h in m['artifacts_sha256'].items());assert sha(O/'repair.py')==m['repair_script_sha256']
idx={key(p):p for p in base};assert len(idx)==len(base)==12963;patched={k:dict(p) for k,p in idx.items()};seen=set();sources={};cur=load(W/'region-brand-routing/current.json')
for plat,f in cur['results'].items():
 for r in jl(f):sources[key(r)]=r
counter=collections.Counter();literal_merges=[];remaining=[];applied_map={}
for ov in overlays:
 k=key(ov);assert k not in seen;seen.add(k);p=idx[k];r=sources[k];assert objsha(p)==ov['base_merged_plan_sha256'];assert p['sourceSHA']==ov['sourceSHA']==hashlib.sha256(r['comment_text'].encode()).hexdigest();assert objsha(r['source_record'])==ov['original_classification_sha256'];assert ov['send_authorized'] is False and ov['can_send_now'] is False and ov['classification_changed'] is False
 z=dict(p);z.update(ov['replacement_plan']);patched[k]=z;applied_map[k]=ov;counter['overlay_source_identity_comment_classification_SHA']+=1
for k,p in patched.items():
 if not p['family']:continue
 r=sources[k];text=r['comment_text'];d=contract['families'][p['family']];assert set(p['fill'])==set(d['required_fill'])=={n for _,n,_,_ in string.Formatter().parse(d['template']) if n}
 preview=d['template'].format(**p['fill']);counter['bound_plan_contract_fields']+=1
 assert not p['hold_reasons'];assert p['send_authorized'] is False and p['can_send_now'] is False
 for f,v in p['fill'].items():
  for span in v.split('、') if f=='requirements' else [v]:assert span in text and any(e['field']==f and span in e['quote'] and e['quote'] in text for e in p['evidence']);counter['literal_parameter_spans']+=1
 assert not re.search(r'预算[^，。]{0,18}预算',preview)
 if '最长' in preview:assert '最长' in text
 old=idx[k];ov=applied_map.get(k);reasons=ov['repair_reasons'] if ov else []
 for f,v in old['fill'].items():
  if v not in preview:
   assert f in ('lease','lease_2','duration') and 'merge_overlapping_short_and_monthly_lease_modes_no_price_cycle_inference' in reasons and not re.search(r'[0-9一二两三四五六七八九十半]+个?(?:月|天|周|年)',v)
   literal_merges.append({'cid':p['cid'],'old_slot':f,'old_span':v,'reason':'overlapping short/monthly lease mode represented once; no numerical duration dropped'})
 # If a source literal explicitly requests contact to the commenter, it cannot become contact-information retrieval.
 inbound=re.search(r'联系我|私信我|私聊我|私我|加我',text)
 if inbound and ov and any('contact' in x for x in reasons):
  assert '联系你的事' in preview and '点我聊就行' not in preview
  if re.search(r'私信我|私聊我|私我',text):assert '私聊' in preview
 if ov and 'price_cycle' in p['fill']:
  assert p['fill']['price_cycle']+'的租金' in preview
 if ov and not old['family']:
  assert p.get('clarification_only') is True and ov['newly_bound_small_short_lease_addition'] is True
 for e in old.get('literal_evidence',[]):
  if e.get('pool')=='价格预算' and e.get('subject')=='own_demand':
   for marker in re.finditer(r'[<＜≤≦>＞≥≧]=?\s*[0-9]+(?:\.[0-9]+)?(?:[kKwW万千元])?',e.get('quote','')):
    assert marker.group() in preview;counter['explicit_symbolic_price_comparators_preserved']+=1
 counter['contact_price_cycle_lease_comparator_structural_guards']+=1
assert len(patched)==12963 and counter['bound_plan_contract_fields']==stats['new_housing_plans']+stats['new_clarification_plans']
assert sum(not p['family'] for p in patched.values())==stats['held_after'];assert sum(bool(p['family']) and not patched[k]['family'] for k,p in idx.items())==stats['new_holds_from_bound']
# Known failures/negative boundaries are remediation regressions, never a fresh holdout score.
known_failed_bound=[q for q in regress if q['old_family'] and q['old_QA_verdict'] in ('change_plan_only','hold')]
for q in known_failed_bound:assert key(q) in seen or q['actual_source_context_correction'];counter['old_problem_case_has_source_bound_repair']+=1
neighbors=['7678171178498556726','7701496021305934634','7690164371854951225','7696331141074207497','7665130906604061475','7685400860373222179','7582274070550119225','7364774505778643753','7509108395146199844','7447474699702977314','7679144481312768826','7664654168267686713']
neighbor_rows=[]
for cid in neighbors:
 p=next(p for p in patched.values() if p['cid']==cid);r=sources[key(p)];draft=contract['families'][p['family']]['template'].format(**p['fill']) if p['family'] else None
 neighbor_rows.append({'cid':cid,'sourceSHA':p['sourceSHA'],'source_comment':r['comment_text'],'base_family':idx[key(p)]['family'],'repair_family':p['family'],'draft_for_development_regression':draft,'is_new_holdout':False,'original_classification_unchanged':True})
 n=neighbor_rows[-1]
 if cid=='7582274070550119225':assert '预算' not in draft and '500' in draft
 if cid=='7701496021305934634':assert '租房流程' not in draft
 if cid=='7665130906604061475':assert '这种' in draft and '同款价' not in draft
 if cid=='7364774505778643753':assert all(v in draft for v in ('一房两厅','宠物友好','离地铁近','租金'))
 if cid=='7509108395146199844':assert all(v in draft for v in ('宣武门','通勤','近一点','一千左右'))
 if cid=='7447474699702977314':assert all(v in draft for v in ('水电','民用','商用')) and '水电、水电标准' not in draft
 if cid=='7679144481312768826':assert '短租' in draft and '月租' not in draft
 if cid=='7664654168267686713':assert '短租' in draft and '一个月' in draft and '月租' not in draft
(O/'neighbor-and-coverage-regressions.jsonl').write_text(''.join(json.dumps(x,ensure_ascii=False,separators=(',',':'))+'\n' for x in neighbor_rows),encoding='utf8')
matrix=jl(O/'all-family-structure-matrix.jsonl');assert len(matrix)==187 and sum(x['source_bound_count'] for x in matrix)==6689
result={'all_verified_structural_invariants_passed':True,'protected_source_files':len(m['source_SHA256']),'overlays_verified':len(overlays),'checks':dict(counter),'explicit_lease_mode_merge_exceptions':literal_merges,'neighbor_and_coverage_development_cases':len(neighbor_rows),'old_QA_regression_rows':len(regress),'old_QA_context_error_corrected':sum(x['actual_source_context_correction'] for x in regress),'old_QA_hold_already_bound_by_frozen_C':sum(x['old_QA_hold_already_bound_by_frozen_C'] for x in regress),'remaining_semantic_QA':'root and existing independent reviewer recheck required; this is deterministic verification only','not_population_accuracy':True,'local_rendering_model_calls':0,'new_direct_API_requests':0,'overall_agent_judgment_usage':'unknown','platform_calls':0,'send_attempts':0,'source_write':0,'pointer_change':0,'manifest_SHA':sha(O/'manifest.json'),'neighbor_artifact_SHA':sha(O/'neighbor-and-coverage-regressions.jsonl')}
put(O/'independent-local-verification.json',result)
print(json.dumps(result,ensure_ascii=False,indent=2))
