import json,collections,hashlib,sys
from pathlib import Path
from local_subtagger import classify_intent
here=Path(__file__).resolve().parent
src=here.parent/'local-rule-pipeline/holdout/historical-reference.jsonl'
c=collections.Counter(); rows=[]
mode='development'
if '--fresh' in sys.argv:
 mode='fresh'
 pointer=json.loads((here.parent.parent/'fangyu-douyin-independent/text-screening-current-summary.json').read_text(encoding='utf-8-sig'))
 published=Path(pointer['result_file'])
 excluded={json.loads(x)['comment_id'] for x in src.read_text(encoding='utf-8-sig').splitlines() if x.strip()}
 candidates=[json.loads(x) for x in published.read_text(encoding='utf-8-sig').splitlines() if x.strip()]
 candidates=[r for r in candidates if r['comment_id'] not in excluded]
 chosen=sorted(candidates,key=lambda r:hashlib.sha256(('local-subtag-v2-fresh-fixed-seed:'+str(r['comment_id'])).encode()).hexdigest())[:200]
 src=here/'fresh-hash-200-reference.jsonl'
 src.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in chosen),encoding='utf-8')
for line in src.read_text(encoding='utf-8-sig').splitlines():
 r=json.loads(line); a=classify_intent(r); ref=r.get('interest_at_comment'); ref_positive=r.get('role')=='demand' and ref in ('high','medium','super_high'); decided=a['state']=='local_decided'; positive=decided and a['role']=='demand'
 c['total']+=1; c['local_decided' if decided else 'needs_ai']+=1; c['reference_positive']+=ref_positive; c['local_positive']+=positive
 if positive and not ref_positive: c['positive_disagreement']+=1; c['positive_vs_unknown_reference' if ref=='uncertain' or r.get('role')=='unknown' else 'positive_vs_reference_negative']+=1
 if ref_positive and not positive: c['reference_positive_not_locally_decided']+=1
 if decided and ((positive and ref_positive) or (not positive and not ref_positive)): c['binary_agreement_among_decided']+=1
 rows.append({'comment_id':r['comment_id'],'comment_text':r['comment_text'],'reference_role':r.get('role'),'reference_interest':ref,'local':a})
report={'counts':dict(c),'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'reference':('固定哈希新抽样，排除开发200；未参与规则改词；AI参考非人工金标' if mode=='fresh' else '开发阶段已查看的200条AI历史参考，非独立留出或人工金标'),'interpretation':'positive_disagreement是与AI参考不一致的误放候选；needs_ai是保留待核，不是负样本或删除。reference_positive_not_locally_decided是本地未直接判定，不能冒充漏删率。','model_calls':0}
(here/('fresh-intent-report.json' if mode=='fresh' else 'holdout-intent-report.json')).write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
(here/('fresh-intent-results.jsonl' if mode=='fresh' else 'holdout-intent-results.jsonl')).write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows),encoding='utf-8')
print(json.dumps(report,ensure_ascii=False))
