"""This batch only: validate AI plans, derive a reversible current sidecar, activate pointers."""
import argparse,collections,copy,datetime,hashlib,importlib.util,json,pathlib,shutil,subprocess,sys
from batch_short_mothers import render_plan
B=pathlib.Path(__file__).resolve().parent;W=B.parent.parent.parent;REGION=W/'region-brand-routing'
def load(p):return json.loads(pathlib.Path(p).read_text(encoding='utf-8'))
def sha(p):
 h=hashlib.sha256()
 with pathlib.Path(p).open('rb') as f:
  for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
 return h.hexdigest()
def jl(p):
 with pathlib.Path(p).open(encoding='utf-8') as f:
  for line in f:
   if line.strip():yield json.loads(line)
def put(p,v):pathlib.Path(p).write_text(json.dumps(v,ensure_ascii=False,indent=2,sort_keys=True)+'\n',encoding='utf-8',newline='\n')
def putjl(p,rows):
 with pathlib.Path(p).open('w',encoding='utf-8',newline='\n') as f:
  for r in rows:f.write(json.dumps(r,ensure_ascii=False,sort_keys=True,separators=(',',':'))+'\n')
def invariant_sources():
 safeguard=load(B/'coordination-start-safeguards.json')
 for name,digest in safeguard['locked_modules'].items():assert sha(W/name)==digest,('locked_module_changed',name)
 mutable_pointers={(REGION/'current.json').resolve(),(REGION/'latest-manifest.json').resolve(),(W/'当前双平台回复结果指针.json').resolve()}
 for filename,digest in safeguard['files_sha256'].items():
  p=pathlib.Path(filename)
  if p.resolve() not in mutable_pointers:assert sha(p)==digest,('immutable_source_changed',filename)
 return safeguard
def adapter():
 spec=importlib.util.spec_from_file_location('locked_adapter',W/'mother_adapter.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
def preflight():
 invariant_sources();source=list(jl(B/'input.jsonl'));rows=list(jl(B/'semantic-final.jsonl'));src={r['review_key']:r for r in source}
 assert len(rows)==len(src)==807 and len({r['review_key'] for r in rows})==807 and {r['review_key'] for r in rows}==set(src)
 contract=load(B/'local-mother-contract.json');contract_sha=sha(B/'local-mother-contract.json');semantic_sha=sha(B/'semantic-final.jsonl');a=adapter();cache={};out=[];quotes=0;params=0
 for r in rows:
  s=src[r['review_key']]
  assert all(r[k]==s[k] for k in ('review_key','comment_id','customer_uid','video_id','platform'))
  assert hashlib.sha256(s['comment_text'].encode('utf-8')).hexdigest()==s['source_comment_sha256']
  candidate=copy.deepcopy(r);candidate['classification_review_source']={'path':str(B/'semantic-final.jsonl'),'sha256':semantic_sha};a.validate_new_review(candidate,B,cache)
  for field in ('topics','target_regions','time_mentions','other_constraints','contact_boundaries'):
   for item in r[field]:
    if isinstance(item,dict) and 'quote' in item:
     q=item['quote'];assert q and (q in s['comment_text'] or s['post_author_same_as_commenter'] and q in s['post_body']);quotes+=1
  render_row=copy.deepcopy(r);render_row['source_version_conflict']=s['source_version_conflict']
  z=render_plan(render_row,s['comment_text'],contract);params+=len(z['literal_fields'])
  out.append({'review_key':r['review_key'],'platform':r['platform'],'comment_id':r['comment_id'],'customer_uid':r['customer_uid'],'video_id':r['video_id'],'source_comment_sha256':s['source_comment_sha256'],'semantic_final_sha256':semantic_sha,'local_mother_contract_sha256':contract_sha,'local_mother':copy.deepcopy(r['reply_plan']['local_mother']),'reply_plan':copy.deepcopy(r['reply_plan']),'rendered':z,'draft_sha256':hashlib.sha256(z['text'].encode('utf-8')).hexdigest() if z['text'] else None,'human_confirmed':False,'send_authorized':False,'can_send_now':False})
 putjl(B/'pool-short-reply-plans.jsonl',out)
 bykey={r['review_key']:r for r in out}
 # Real frozen comments for all observed edge types; synthetic no-contact/all-in/pet
 # checks are covered by the separately executed behavioral test suite.
 examples={
  'region_multi_conditions':['D0187','D0720'],
  'work_and_residence_separate':['D0562','D0194','D0730'],
  'negation_and_current_home':['D0421','D0518','D0693'],
  'pet_multi_conditions':['D0441'],
  'elevator_multi_conditions':['D0720','D0613'],
  'lease_and_monthly_price':['D0181','D0286','D0787','D0777'],
  'unknown_and_mixed_or_supply':['D0040','D0688','D0172'],
  'conditional_immediate_rent':['D0580']}
 observed={label:[{'review_key':k,'plan':bykey[k]['local_mother'],'rendered':bykey[k]['rendered']} for k in keys] for label,keys in examples.items()}
 test=subprocess.run([sys.executable,'-m','unittest','test_batch_short_mothers.py'],cwd=B,capture_output=True,text=True,encoding='utf-8');assert test.returncode==0,test.stdout+test.stderr
 (B/'short-mother-tests.log').write_text(test.stdout+test.stderr,encoding='utf-8')
 receipt={'all_passed':True,'input_comments':807,'formal_validator_real_SHA_bound_passed':807,'source_comment_sha_verified':807,'identity_fields_match':True,'quote_checks':quotes,'literal_parameter_spans_checked':params,'explicit_local_mother_all_rows':True,'plan_status_counts':dict(collections.Counter(r['rendered']['status'] for r in out)),'family_plan_counts':dict(collections.Counter(r['rendered']['family'] or 'none' for r in out)),'pool_short_candidates_before_dedup':sum(bool(r['rendered']['text']) for r in out),'rendering_model_calls':0,'behavior_test_count':8,'behavior_tests_passed':True,'representative_real_comments':observed,'representative_synthetic_cases':['all-in budget preserves water electricity gas fee scope','work commute is question and serious tone removes baby','negation and no invented monthly price unit','no contact/supply/mixed/unknown/ended held','cat/elevator/lease confirmations','fabricated field or unit rejected'],'contract_file':str(B/'local-mother-contract.json'),'contract_sha256':contract_sha,'semantic_final_sha256':semantic_sha,'plan_file':str(B/'pool-short-reply-plans.jsonl'),'plan_file_sha256':sha(B/'pool-short-reply-plans.jsonl'),'renderer_sha256':sha(B/'batch_short_mothers.py'),'classification_modified_by_renderer':False,'human_confirmed':False,'send_authorized':False,'platform_calls':0,'actual_usage':'unknown'}
 put(B/'pool-short-reply-validation.json',receipt);print(json.dumps({k:receipt[k] for k in ('all_passed','input_comments','plan_status_counts','pool_short_candidates_before_dedup','plan_file_sha256')},ensure_ascii=False))

def build_sidecar():
 safeguard=invariant_sources();pv=load(B/'pool-short-reply-validation.json');assert pv['all_passed'] and pv['semantic_final_sha256']==sha(B/'semantic-final.jsonl') and pv['plan_file_sha256']==sha(B/'pool-short-reply-plans.jsonl')
 pub=load(B/'summary.json');assert pub['snapshot_unique_comments']==34840 and pub['newly_analyzed']==807 and sha(pub['result_file'])==pub['result_sha256']
 old=safeguard['previous_region_current'];m=load(old['manifest']);m['platforms']['douyin']={'result_file':pub['result_file'],'result_sha256':pub['result_sha256'],'count':34840}
 m['pool_short_mothers']={'scope':'only_807_comments_in_f98cc21138910fb9','input_file':str(B/'input.jsonl'),'input_sha256':sha(B/'input.jsonl'),'semantic_final_file':str(B/'semantic-final.jsonl'),'semantic_final_sha256':sha(B/'semantic-final.jsonl'),'contract_file':str(B/'local-mother-contract.json'),'contract_sha256':sha(B/'local-mother-contract.json'),'plans_file':str(B/'pool-short-reply-plans.jsonl'),'plans_sha256':sha(B/'pool-short-reply-plans.jsonl'),'validation_file':str(B/'pool-short-reply-validation.json'),'validation_sha256':sha(B/'pool-short-reply-validation.json'),'renderer_file':str(B/'batch_short_mothers.py'),'renderer_sha256':sha(B/'batch_short_mothers.py'),'wording_individually_human_confirmed':False,'source_drafts_preserved':True}
 version=pub['result_sha256'][:16]+'-pool-short-f98cc21138910fb9';out=REGION/version;out.mkdir(exist_ok=True);base=out/'base-generic';base.mkdir(exist_ok=True)
 m['frozen_at']=load(old['manifest'])['frozen_at'];m['previous_region_manifest']={'file':old['manifest'],'sha256':old['manifest_sha256']};put(out/'manifest.json',m)
 run=subprocess.run([sys.executable,str(REGION/'build_region_brand_sidecars.py'),'--manifest',str(out/'manifest.json'),'--output-dir',str(base)],capture_output=True,text=True,encoding='utf-8')
 (out/'base-builder-run.log').write_text(run.stdout+'\n'+run.stderr,encoding='utf-8');assert run.returncode==0,run.stderr[-3000:]
 baseval=load(base/'validation.json');assert baseval['all_passed'];basecurrent=load(base/'current.json')
 previous={(r['comment_id'],r['customer_uid']):r for r in jl(old['results']['douyin'])};assert len(previous)==34033
 plans={(r['comment_id'],r['customer_uid']):r for r in jl(B/'pool-short-reply-plans.jsonl')};assert len(plans)==807
 assert set(previous).isdisjoint(plans)
 rows=[];preserved_source=0;preserved_original=0;old_candidates=0;new_candidates=0
 for fresh in jl(basecurrent['results']['douyin']):
  key=(fresh['comment_id'],fresh['customer_uid']);isnew=key in plans
  if isnew:
   r=fresh;q=plans[key];assert q['source_comment_sha256']==r['comment_text_sha256']
   assert q['local_mother']==r['reply_plan']['local_mother'];text=q['rendered']['text'];r['base_generic_before_pool_override']={'mother_reply_text':r['mother_reply_text'],'alternative_mother_reply_text':r['alternative_mother_reply_text'],'reply_status':r['reply_status']}
   r['pool_short_mother']={'batch':'f98cc21138910fb9','family':q['rendered']['family'],'plan':q['local_mother'],'render_status':q['rendered']['status'],'contract_sha256':pv['contract_sha256'],'semantic_final_sha256':pv['semantic_final_sha256'],'plans_sha256':pv['plan_file_sha256'],'text_sha256':q['draft_sha256'],'wording_individually_human_confirmed':False}
   r['reply_generation_strategy']='local_pool_family_literal_parameters';new_candidates+=bool(text)
   r['unanswered_specific_question']=bool(text) or r['unanswered_specific_question']
  else:
   r=previous.pop(key);assert (r['role'],r['interest_at_comment'],r['demand_state'])==(fresh['role'],fresh['interest_at_comment'],fresh['demand_state'])
   assert r['comment_text']==fresh['comment_text'];assert r['target_regions']==fresh['target_regions'];assert r['contact_policy']==fresh['contact_policy'];assert r['contact_boundaries']==fresh['contact_boundaries']
   before_source=copy.deepcopy(r['source_record']);before_original=copy.deepcopy(r['original_reply'])
   r['previous_sidecar_reply_selection']={'mother_reply_text':r['mother_reply_text'],'alternative_mother_reply_text':r['alternative_mother_reply_text'],'reply_status':r['reply_status'],'timeline_review':r.get('timeline_review')}
   text=r['mother_reply_text'] or r['alternative_mother_reply_text'];old_candidates+=bool(text)
   r['reply_generation_strategy']='preserved_historical_basic_mother';preserved_source+=r['source_record']==before_source;preserved_original+=r['original_reply']==before_original
  r['mother_reply_text']=text;r['alternative_mother_reply_text']=None;r.pop('timeline_review',None)
  r['reply_status']='本地按需求池短母句待审' if isnew and text else '历史基础母句保留待审' if text else '保留原判及计划，暂缓生成'
  r['send_authorized']=False;r['can_send_now']=False;r['text_task_send_attempted']=False
  rows.append(r)
 assert not previous and len(rows)==34840 and preserved_source==preserved_original==34033
 a=adapter();duplicate_count=a.reconcile_customers(rows)
 selected=[r for r in rows if r['mother_reply_text']];assert len({r['customer_uid'] for r in selected})==len(selected)
 for r in rows:
  if 'pool_short_mother' in r:
   key=(r['comment_id'],r['customer_uid']);q=plans[key];candidate=r['mother_reply_text'] or r['alternative_mother_reply_text'];assert candidate==q['rendered']['text']
   assert r['source_record']['reply_plan']['local_mother']==q['local_mother']
  assert r['send_authorized'] is False and r['can_send_now'] is False and r['assigned_store'] is None
 putjl(out/'douyin-region-brand-results.jsonl',rows)
 # The XHS source, original raw/IP records, originals and current drafts stay byte-identical.
 shutil.copyfile(old['results']['xiaohongshu'],out/'xiaohongshu-region-brand-results.jsonl')
 xhs=list(jl(out/'xiaohongshu-region-brand-results.jsonl'));assert len(xhs)==3601 and len({r['customer_uid'] for r in xhs if r['mother_reply_text']})==sum(bool(r['mother_reply_text']) for r in xhs)
 assert sha(out/'xiaohongshu-region-brand-results.jsonl')==sha(old['results']['xiaohongshu'])
 for name in ('region-tables.json','store-shared-pools.json'):shutil.copyfile(base/name,out/name)
 summary=load(base/'summary.json');dy=summary['platforms']['douyin'];hs=[r for r in rows if r['interest_at_comment'] in ('high','super_high')]
 pool=lambda r:'pool_short_mother' in r
 def retained_original_reason(r):
  if r['mother_reply_text'] or not (r['original_reply']['text'] or r['original_reply']['alternative_text']):return None
  if r.get('timeline_review') and r['alternative_mother_reply_text']:return 'later_or_unknown_timeline_review'
  if r['alternative_mother_reply_text']:return 'same_customer_duplicate_alternative'
  if r['contact_policy']=='no_contact':return 'no_contact'
  if pool(r):return 'new_batch_specific_plan_held'
  if r['generic_intro_suitability'] is False:return 'generic_intro_unsuitable'
  if r['role']!='demand':return 'role_not_demand'
  if r['demand_state']!='active_at_comment':return 'demand_state_'+str(r['demand_state'])
  if r['interest_at_comment'] not in ('high','super_high','medium'):return 'interest_outside_scope'
  return 'other_existing_hold'
 retained=collections.Counter(reason for r in rows if (reason:=retained_original_reason(r)))
 dy.update(records=len(rows),interest_counts=dict(collections.Counter(r['interest_at_comment'] for r in rows)),high_super_high_comments=len(hs),high_super_high_unique_uids=len({r['customer_uid'] for r in hs}),selected_local_mother=len(selected),new_generic_drafts_before_dedup=old_candidates,new_generic_alternatives_after_dedup=sum(bool(r['alternative_mother_reply_text']) and not pool(r) for r in rows),dedup_alternatives=duplicate_count,timeline_review=sum(bool(r.get('timeline_review')) for r in rows),pool_short_batch_comments=807,pool_short_candidates_before_dedup=new_candidates,pool_short_selected=sum(bool(r['mother_reply_text']) and pool(r) for r in rows),pool_short_alternatives=sum(bool(r['alternative_mother_reply_text']) and pool(r) for r in rows),pool_short_held=807-new_candidates,historical_comments_untouched_by_short_rewrite=34033,historical_basic_candidates_before_dedup=old_candidates,historical_basic_selected=sum(bool(r['mother_reply_text']) and not pool(r) for r in rows),historical_basic_alternatives=sum(bool(r['alternative_mother_reply_text']) and not pool(r) for r in rows),original_source_records_preserved=preserved_source,original_reply_records_preserved=preserved_original,original_actual_draft_records=sum(bool(r['original_reply']['text']) for r in rows))
 summary['platforms']['xiaohongshu']=load(old['summary'])['platforms']['xiaohongshu'];summary['pool_short_mothers']=m['pool_short_mothers'];summary['all_34840_converted_to_short_pool_mothers']=False;put(out/'summary.json',summary)
 dy['original_drafts_preserved_not_selected']=sum(retained.values());dy['original_drafts_preserved_not_selected_reasons']=dict(retained);put(out/'summary.json',summary)
 hashes={n:sha(out/n) for n in ('douyin-region-brand-results.jsonl','xiaohongshu-region-brand-results.jsonl','summary.json','region-tables.json','store-shared-pools.json')}
 check={'base_region_builder_and_idempotence_passed':baseval['all_passed'],'new_807_exact_CID_UID_join':len(plans)==807,'historical_34033_source_record_preserved':preserved_source==34033,'historical_34033_original_reply_preserved':preserved_original==34033,'original_124_targeted_reviews_preserved':summary['compatibility_review']['applied_count']==124,'XHS_3601_raw_IP_source_originals_byte_identical':sha(out/'xiaohongshu-region-brand-results.jsonl')==sha(old['results']['xiaohongshu']),'new_807_plans_SHA_contract_and_original_identity_validated':pv['all_passed'],'one_selected_per_platform_UID':len({r['customer_uid'] for r in selected})==len(selected),'same_pool_short_text_only_after_reconcile':all((r['mother_reply_text'] or r['alternative_mother_reply_text'])==plans[(r['comment_id'],r['customer_uid'])]['rendered']['text'] for r in rows if pool(r)),'no_send_assignment_or_task_send':all(r['send_authorized'] is False and r['can_send_now'] is False and r['assigned_store'] is None and r['text_task_send_attempted'] is False for r in rows),'latest_classification_count_34840':len(rows)==34840,'historical_all_short_claim_false':summary['all_34840_converted_to_short_pool_mothers'] is False}
 assert all(check.values());validation={'all_passed':True,'checks':check,'base_region_validation':str(base/'validation.json'),'base_region_validation_sha256':sha(base/'validation.json'),'pool_short_validation':str(B/'pool-short-reply-validation.json'),'pool_short_validation_sha256':sha(B/'pool-short-reply-validation.json'),'output_content_sha256':hashes,'source_classification_sha256':pub['result_sha256'],'source_files_and_locked_modules_unchanged':True,'send_authorized':False,'platform_calls':0};put(out/'validation.json',validation)
 current=copy.deepcopy(basecurrent);current.update(version='region-brand-sidecars-with-batch-short-mothers-v1',manifest=str(out/'manifest.json'),manifest_sha256=sha(out/'manifest.json'),results={p:str(out/(p+'-region-brand-results.jsonl')) for p in ('douyin','xiaohongshu')},result_sha256=hashes,summary=str(out/'summary.json'),validation=str(out/'validation.json'),region_tables=str(out/'region-tables.json'),store_shared_pools=str(out/'store-shared-pools.json'),platform_statistics=summary['platforms'],pool_short_mothers=m['pool_short_mothers'])
 put(out/'current.json',current);put(B/'short-sidecar-build-receipt.json',{'out':str(out),'current':str(out/'current.json'),'current_sha256':sha(out/'current.json'),'dy_statistics':dy,'sha256':hashes,'all_passed':True});invariant_sources()
 print(json.dumps({'out':str(out),'all_passed':True,'dy_statistics':dy,'result_sha256':hashes},ensure_ascii=False))

def activate():
 invariant_sources();receipt=load(B/'short-sidecar-build-receipt.json');out=pathlib.Path(receipt['out']);assert receipt['current_sha256']==sha(out/'current.json');c=load(out/'current.json');v=load(c['validation']);assert v['all_passed'] and all(v['checks'].values())
 for name,digest in c['result_sha256'].items():assert sha(out/name)==digest
 put(REGION/'current.json',c);put(REGION/'latest-manifest.json',{'manifest':c['manifest'],'manifest_sha256':c['manifest_sha256'],'current':str(out/'current.json')})
 for command in ([sys.executable,str(W/'sync_ai_text_status.py')],[sys.executable,str(REGION/'sync_reply_pointer.py')]):
  run=subprocess.run(command,capture_output=True,text=True,encoding='utf-8');assert run.returncode==0,run.stderr
 # Existing sync helper publishes the validated current sidecar. Add batch-specific
 # metadata after it without changing its locked/general implementation.
 pointer=load(W/'当前双平台回复结果指针.json');dy=load(c['summary'])['platforms']['douyin'];pointer['version']='brand_reply_current_with_bounded_pool_short_v1';pointer['reply_strategy']='historical_basic_plus_latest_807_pool_specific_short';pointer['pool_short_mothers']=c['pool_short_mothers'];pointer['platforms']['douyin'].update(pool_short_batch_comments=807,pool_short_selected_drafts=dy['pool_short_selected'],pool_short_alternatives=dy['pool_short_alternatives'],pool_short_held=dy['pool_short_held'],historical_basic_selected_drafts=dy['historical_basic_selected'],all_historical_comments_short_rewritten=False)
 put(W/'当前双平台回复结果指针.json',pointer)
 state=load(W/'当前文本处理运行状态.json');state['region_brand_reply_sidecars'].update(pool_short_batch_comments=807,pool_short_selected_drafts=dy['pool_short_selected'],pool_short_alternatives=dy['pool_short_alternatives'],pool_short_held=dy['pool_short_held'],historical_basic_selected_drafts=dy['historical_basic_selected'],pool_short_contract_sha256=sha(B/'local-mother-contract.json'),reply_strategy='historical_basic_plus_latest_807_pool_specific_short',all_historical_comments_short_rewritten=False);put(W/'当前文本处理运行状态.json',state)
 assert pointer['platforms']['douyin']['classification_sha256']==load(B/'summary.json')['result_sha256'];assert pointer['platforms']['douyin']['reply_sidecar_sha256']==sha(c['results']['douyin']);assert pointer['platforms']['douyin']['classified_comments']==34840
 put(B/'short-consumption-pointer-verification.json',{'all_passed':True,'classification_sha256':pointer['platforms']['douyin']['classification_sha256'],'reply_sidecar_sha256':pointer['platforms']['douyin']['reply_sidecar_sha256'],'current_region_pointer_sha256':sha(REGION/'current.json'),'current_reply_pointer_sha256':sha(W/'当前双平台回复结果指针.json'),'manifest_sha256':sha(c['manifest']),'classification_records':34840,'new_batch_records':807,'pool_short_selected':dy['pool_short_selected'],'pool_short_alternatives':dy['pool_short_alternatives'],'historical_basic_selected':dy['historical_basic_selected'],'XHS_records':3601,'source_classifications_overwritten':False,'platform_calls':0,'send_authorized':False})
 print(json.dumps({'activated':True,'classification_records':34840,'pool_short_selected':dy['pool_short_selected'],'historical_basic_selected':dy['historical_basic_selected']},ensure_ascii=False))
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('stage',choices=('preflight','build','activate'));args=p.parse_args()
 {'preflight':preflight,'build':build_sidecar,'activate':activate}[args.stage]()
