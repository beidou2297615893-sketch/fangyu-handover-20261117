"""Synthetic business boundaries; these are regression tests, not accuracy labels."""
import json
import tempfile
import unittest
from pathlib import Path

from local_classifier import LocalClassifier, choose_mother


class BusinessBoundaries(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.c = LocalClassifier()

    def run_case(self, text, **kwargs):
        return self.c.classify(dict(platform='xhs', comment_id='synthetic',
                                    customer_uid='synthetic', comment_text=text, **kwargs))

    def test_explicit_demand_without_rental_post(self):
        for text in ['正在找两室', '想租一年', '求租带阳台的一居室', '长租价格多少']:
            with self.subTest(text=text):
                r = self.run_case(text, post_body='装修分享')
                self.assertEqual(r['role'], 'demand')
                self.assertEqual(r['interest_at_comment'], 'high')

    def test_supply_is_not_demand(self):
        for text in ['本人出租，上海两室3000，可养猫', '转租我的房子，有阳台', '我有一套房出租，长租价格3000']:
            r = self.run_case(text)
            self.assertEqual(r['role'], 'supply')
            self.assertEqual(r['topics'], [])

    def test_supply_and_new_demand_not_blended(self):
        r = self.run_case('转租我的房子，古北两室3000；另外我求租北京一居，预算5000')
        self.assertEqual(r['role'], 'mixed')
        self.assertEqual(r['interest_at_comment'], 'high')
        self.assertNotIn('古北', json.dumps(r['target_regions'], ensure_ascii=False))
        self.assertTrue(all('3000' not in e['quote'] for e in r['topic_evidence']))

    def test_change_house_supply_not_assumed_new_demand(self):
        r = self.run_case('因为换房所以转租我的房子')
        self.assertEqual(r['role'], 'supply')
        self.assertTrue(r['possible_new_demand'])

    def test_ended_vs_status_question(self):
        self.assertEqual(self.run_case('我已经租到了，谢谢')['demand_state'], 'ended')
        r = self.run_case('已经租出去了吗', post_body='房东直租一居室')
        self.assertEqual(r['interest_at_comment'], 'high')
        self.assertIn('房源状态', r['topics'])

    def test_ended_old_need_with_new_demand(self):
        r = self.run_case('我已经租到了，但现在想换租两室')
        self.assertEqual(r['role'], 'demand')
        self.assertEqual(r['demand_state'], 'active_at_comment')

    def test_future_move_is_active_search(self):
        r = self.run_case('现在找房，12月入住，想租两室')
        self.assertEqual(r['demand_state'], 'active_at_comment')
        self.assertEqual(r['interest_at_comment'], 'high')

    def test_future_search_and_potential(self):
        r = self.run_case('明年才开始找房，现在不找')
        self.assertEqual(r['demand_state'], 'future')
        self.assertEqual(r['interest_at_comment'], 'low')
        self.assertEqual(self.run_case('以后有钱了我也想租这样的房子')['interest_at_comment'], 'very_low')

    def test_appointment_requires_explicit_booking(self):
        for text in ['周末能约看吗', '方便约时间看房吗', '我想预订这套房', '明天可以签约租房吗']:
            self.assertEqual(self.run_case(text, post_body='一居室出租')['interest_at_comment'], 'super_high')
        for text in ['方便看房吗', '微信多少', '能发图片吗']:
            r = self.run_case(text, post_body='一居室出租')
            self.assertEqual(r['interest_at_comment'], 'high')

    def test_ambiguous_short_comments_need_data_not_model(self):
        for text in ['', '多少米', '还有吗', '同求', '两室', '北京']:
            r = self.run_case(text, post_body='装修心得')
            self.assertEqual(r['interest_at_comment'], 'uncertain')
            self.assertEqual(r['exception_type'], 'needs_context')
            self.assertFalse(r['needs_model_review'])

    def test_clear_short_rental_inquiry(self):
        for text in ['多少钱', '还有吗', '多少平', '在哪里', '能养猫吗', '月租多少']:
            r = self.run_case(text, post_body='房东直租，整租一居室')
            self.assertEqual(r['role'], 'demand')
            self.assertEqual(r['interest_at_comment'], 'high')

    def test_other_body_does_not_import_conditions(self):
        r = self.run_case('多少钱', post_body='上海古北两室出租，预算3000，12月入住，可养宠')
        self.assertEqual(r['topics'], ['价格预算'])
        self.assertEqual(r['target_regions'], [])
        self.assertEqual(r['time_mentions'], [])
        self.assertTrue(all(e['quote'] in '多少钱' for e in r['topic_evidence']))

    def test_verified_own_body_can_add_evidence(self):
        r = self.run_case('补充一下', post_body='我求租北京两室，预算5000', post_author_same_as_commenter=True)
        self.assertEqual(r['role'], 'demand')
        self.assertIn('价格预算', r['topics'])
        self.assertTrue(any(e['source'] == 'post_body' for e in r['topic_evidence']))
        r2 = self.run_case('补充一下', post_body='我求租北京两室，预算5000', post_author_same_as_commenter='true')
        self.assertEqual(r2['role'], 'unknown')

    def test_region_subjects_and_ip(self):
        r = self.run_case('我在上海上班，想租北京两室', ip_location_raw='上海', source_store='古北店')
        self.assertEqual([x['name'] for x in r['target_regions']], ['北京'])
        self.assertIsNone(r['assigned_store'])
        r = self.run_case('求租，古北优先，虹桥也可，浦东不考虑')
        self.assertEqual({x['name']: x['relation'] for x in r['target_regions']}, {'古北':'preferred', '虹桥':'acceptable', '浦东':'excluded'})

    def test_price_question_not_budget(self):
        self.assertEqual(self.run_case('一个月多少钱', post_body='一居室出租')['budget_mentions'], [])
        self.assertNotIn('入住与租期', self.run_case('一个月多少钱', post_body='一居室出租')['topics'])
        self.assertTrue(self.run_case('求租，预算不超过3500')['budget_mentions'])

    def test_negation_multi_pools_and_composite_scope(self):
        r = self.run_case('求租，不能合租，最好独卫，不要中介费，超过六楼没有电梯不考虑')
        self.assertEqual(r['interest_at_comment'], 'high')
        self.assertTrue({'户型面积与居住方式', '房内设施', '费用合同', '楼层电梯'} <= set(r['topics']))
        e = next(e for e in r['topic_evidence'] if e['pool'] == '楼层电梯')
        self.assertEqual(e['condition_scope'], '超过六楼没有电梯不考虑')
        self.assertEqual(e['polarity'], 'conditional')

    def test_pet_allowance_does_not_claim_owner(self):
        r = self.run_case('求租，不介意猫，不需要宠物友好')
        self.assertIn('宠物', r['topics'])
        self.assertFalse(r['owns_pet'])

    def test_family_context_no_extra_pool(self):
        r = self.run_case('带孩子求租两室，要车位')
        self.assertTrue(r['family_context'])
        self.assertNotIn('家庭', r['topics'])
        self.assertTrue(r['other_constraints'])

    def test_buy_and_business_use_are_not_residential_rental(self):
        for text in ['我想买两室', '求租办公室', '租售价格多少']:
            r = self.run_case(text)
            self.assertEqual(r['interest_at_comment'], 'uncertain')
            self.assertFalse(choose_mother(r, self.mothers())['draft_ready'])

    def test_third_party_and_historical(self):
        r = self.run_case('帮朋友求租北京两室')
        self.assertEqual(r['beneficiary'], 'other')
        self.assertEqual(r['role'], 'demand')
        self.assertTrue(all(e['subject'] == 'other_person' for e in r['topic_evidence']))
        self.assertEqual(self.run_case('以前租过这里，隔音不好')['role'], 'discussion')

    def test_conflicts_are_explicit(self):
        r = self.run_case('我求租两室，但是我又完全不找房')
        self.assertTrue(r['needs_model_review'])
        self.assertEqual(r['exception_type'], 'semantic_review')
        r = self.run_case('求租两室', source_version_conflict=True)
        self.assertEqual(r['exception_type'], 'source_conflict')
        self.assertEqual(r['interest_at_comment'], 'uncertain')

    def test_negated_demand_is_not_positive_demand(self):
        for text in ['不是求租，只是看看', '我不想租房', '我不找房', '现在不找房']:
            with self.subTest(text=text):
                r = self.run_case(text)
                self.assertNotEqual(r['role'], 'demand')
                self.assertNotIn(r['interest_at_comment'], ['high', 'super_high', 'medium', 'low'])

    def test_supply_and_demand_same_sentence(self):
        r = self.run_case('转租我的古北两室但我还想找北京一居')
        self.assertEqual(r['role'], 'mixed')
        self.assertEqual([x['name'] for x in r['target_regions']], ['北京'])

    def test_context_must_be_offer_not_asking_or_experience(self):
        for body in ['求租上海一居室，有房东出租吗', '房子出租避坑经验', '我以前出租房子的经历']:
            r = self.run_case('多少钱', post_body=body)
            self.assertEqual(r['interest_at_comment'], 'uncertain')

    def test_quote_subject_not_inherited_from_other_people(self):
        r = self.run_case('朋友预算3000，我求租两室预算5000')
        self.assertTrue(all('3000' not in x['quote'] for x in r['budget_mentions']))
        self.assertTrue(all('3000' not in x['quote'] for x in r['topic_evidence']))

    def test_workplace_same_clause_does_not_become_target(self):
        r = self.run_case('我在上海上班想租北京两室')
        self.assertEqual([x['name'] for x in r['target_regions']], ['北京'])

    def test_appointment_negation_and_old_appointment(self):
        for text in ['求租两室，但我不约看房', '以前周末约看过房，现在求租两室']:
            self.assertNotEqual(self.run_case(text)['interest_at_comment'], 'super_high')

    def test_other_person_condition_only_candidate(self):
        r = self.run_case('我求租单间，朋友养猫')
        self.assertNotIn('宠物', r['topics'])
        self.assertIn('宠物', r['possible_topics'])

    def test_residential_context_does_not_convert_other_object_to_housing(self):
        for text in ['我想租车一年', '求租摄影器材']:
            r = self.run_case(text, post_body='一居室出租')
            self.assertEqual(r['interest_at_comment'], 'uncertain')

    def test_current_rent_not_new_budget(self):
        r = self.run_case('我求租两室，现租金5000，预算3500')
        self.assertEqual(len(r['budget_mentions']), 1)
        self.assertIn('3500', r['budget_mentions'][0]['quote'])

    def test_real_rental_offer_with_renovation_still_usable(self):
        r = self.run_case('多少钱', post_body='我这套一居室出租，刚装修好')
        self.assertEqual(r['interest_at_comment'], 'high')

    def test_safety_overrides_input_and_preserves_identity(self):
        r = self.run_case('求租两室', send_authorized=True, assigned_store='unsafe', reply_to='parent1')
        self.assertFalse(r['send_authorized'])
        self.assertIsNone(r['assigned_store'])
        self.assertEqual(r['reply_to'], 'parent1')

    def test_new_comment_ended_overrides_own_old_body(self):
        r = self.run_case('已经租好不找了', post_body='现在求租两室，预算5000', post_author_same_as_commenter=True)
        self.assertEqual(r['demand_state'], 'ended')
        self.assertEqual(r['interest_at_comment'], 'unrelated')
        self.assertEqual(r['topics'], [])

    def test_business_use_keeps_demand_but_blocks_residential_mother(self):
        r = self.run_case('我求租办公室')
        self.assertEqual(r['role'], 'demand')
        self.assertFalse(choose_mother(r, self.mothers())['draft_ready'])

    def test_confirmed_city_dictionary_and_machine_evidence_enums(self):
        r = self.run_case('求租福州白湖亭两室，不要合租，最好独卫，能养猫吗')
        self.assertEqual({x['name'] for x in r['target_regions']}, {'福州','白湖亭'})
        self.assertTrue(all(e['subject']=='own_demand' for e in r['topic_evidence']))
        self.assertTrue(all(e['polarity'] in {'ask','require','prefer','reject','accept','conditional','fact','not_required','unknown'} for e in r['topic_evidence']))

    def test_fix1_help_mother_seek_not_definite_supply(self):
        r = self.run_case('帮妈妈找一套一居室出租')
        self.assertEqual(r['role'], 'demand')
        self.assertIn('户型面积与居住方式', r['topics'])
        self.assertEqual(r['beneficiary'], 'other')
        self.assertEqual(r['interest_at_comment'], 'uncertain')
        self.assertEqual(r['exception_type'], 'semantic_review')
        self.assertFalse(choose_mother(r, self.mothers())['draft_ready'])

    def test_fix1_explicit_bystander_is_unrelated(self):
        r = self.run_case('我不找房，只是随便看看装修')
        self.assertEqual(r['role'], 'discussion')
        self.assertEqual(r['interest_at_comment'], 'unrelated')
        self.assertFalse(r['needs_model_review'])

    def test_fix1_in_rental_status_question(self):
        r = self.run_case('房子还在租吗', post_body='房东直租')
        self.assertEqual(r['interest_at_comment'], 'high')
        self.assertIn('房源状态', r['topics'])
        self.assertEqual(self.run_case('房子还在租吗')['interest_at_comment'], 'uncertain')

    def test_fix1_seek_with_pet_modifier_and_balcony_question(self):
        r = self.run_case('找能带猫的一居室，有阳台吗')
        self.assertEqual(r['role'], 'demand')
        self.assertTrue({'宠物','户型面积与居住方式','房内设施'} <= set(r['topics']))

    def test_fix1_seek_flatshare_tolerates_roommate_cat(self):
        r = self.run_case('我不介意室友养猫，找合租')
        self.assertEqual(r['role'], 'demand')
        self.assertIn('户型面积与居住方式', r['topics'])
        self.assertFalse(r['owns_pet'])

    def test_fix1_current_rental_comparison_and_fees(self):
        r = self.run_case('正在租房比较，不要中介费，水电怎么收')
        self.assertEqual(r['role'], 'demand')
        self.assertIn('费用合同', r['topics'])

    def test_fix1_true_supply_stays_supply(self):
        for text in ['帮妈妈出租一居室', '一居室出租', '本人出租一居室，可带猫', '我出租合租房间']:
            with self.subTest(text=text):
                r = self.run_case(text)
                self.assertEqual(r['role'], 'supply')
                self.assertEqual(r['topics'], [])
                self.assertEqual(r['interest_at_comment'], 'unrelated')

    def test_fix2_pet_permission_not_personal_ownership(self):
        for text in ['我在帮别人找能带猫的一居室', '想找能带猫的一居室',
                     '求租能养狗的房子', '我求租两室，不带猫', '求租，我不介意室友养猫']:
            with self.subTest(text=text):
                r = self.run_case(text)
                self.assertFalse(r['owns_pet'])
                self.assertIsNone(r['pet_ownership'])
                self.assertEqual(r['pet_ownership_status'], 'unknown')
                self.assertEqual(r['pet_ownership_evidence'], [])
                self.assertEqual(r['owns_pet_false_semantics'], 'not_confirmed')

    def test_fix2_explicit_self_pet_fact_has_separate_exact_evidence(self):
        for text in ['我养猫，求租一居', '我有一只狗，求租两室', '求租，我家有猫']:
            with self.subTest(text=text):
                r = self.run_case(text)
                self.assertIs(r['owns_pet'], True)
                self.assertIs(r['pet_ownership'], True)
                self.assertEqual(r['pet_ownership_status'], 'confirmed_has_pet')
                self.assertTrue(r['pet_ownership_evidence'])
                self.assertTrue(all(e['quote'] in text and e['subject']=='self' for e in r['pet_ownership_evidence']))

    def test_fix2_other_person_and_hypothetical_pet_are_unknown(self):
        for text in ['帮朋友求租，他有猫', '我想养猫所以求租一居',
                     '如果我养猫就找一居', '我帮朋友找房，他养狗', '我有猫吗？朋友在找房']:
            with self.subTest(text=text):
                r = self.run_case(text)
                self.assertFalse(r['owns_pet'])
                self.assertIsNone(r['pet_ownership'])

    def test_fix2_explicit_no_pet_distinct_from_unknown(self):
        r = self.run_case('我没有宠物，求租一居')
        self.assertFalse(r['owns_pet'])
        self.assertIs(r['pet_ownership'], False)
        self.assertEqual(r['pet_ownership_status'], 'confirmed_no_pet')
        self.assertTrue(r['pet_ownership_evidence'])

    def test_exact_quotes_and_safety(self):
        text = '求租北京两室，预算3000，12月入住，能养猫吗？'
        r = self.run_case(text)
        for e in r['evidence'] + r['topic_evidence']:
            self.assertIn(e['quote'], text)
        for key in ['current_need_verified', 'send_authorized', 'can_send_now']:
            self.assertIs(r[key], False)
        self.assertEqual(r['model_calls'], 0)
        self.assertEqual(r['classification_method'], 'local_rules')

    @staticmethod
    def mothers():
        return [{'slot':1, 'user_approved':True, 'template':'宝宝，我住方隅公寓这边，介绍有优惠的。', 'version':'test-v1'},
                {'slot':7, 'user_approved':True, 'template':'这户型有，3000元'}]

    def test_mother_only_approved_slot_one(self):
        r = self.run_case('求租两室')
        m = choose_mother(r, self.mothers())
        self.assertTrue(m['draft_ready'])
        self.assertEqual(m['slot'], 1)
        self.assertEqual(m['mother_slot'], 1)
        self.assertEqual(m['mother_reply_text'], m['draft_text'])
        self.assertEqual(m['reply_generation_model_calls'], 0)
        self.assertNotIn('reason', m)
        self.assertEqual(self.c.rule_version, r['rule_version'])
        self.assertEqual(m['draft_text'], self.mothers()[0]['template'])
        self.assertFalse(m['can_send_now'])
        self.assertFalse(m['send_authorized'])
        self.assertFalse(choose_mother(r, [dict(self.mothers()[0], user_approved=False)])['draft_ready'])
        self.assertFalse(choose_mother(self.run_case('本人出租两室'), self.mothers())['draft_ready'])
        self.assertFalse(choose_mother(self.run_case('我已经租到了'), self.mothers())['draft_ready'])

    def test_family_mother_removes_only_address(self):
        r = self.run_case('带孩子求租两室')
        m = self.c.choose_mother(r, self.mothers())
        self.assertEqual(m['draft_text'], '我住方隅公寓这边，介绍有优惠的。')

    def test_configuration_is_versioned_and_effective(self):
        path = Path(__file__).with_name('rule_config.json')
        data = json.loads(path.read_text(encoding='utf-8'))
        self.assertTrue(data['version'])
        data['regions'].append('测试镇')
        with tempfile.TemporaryDirectory() as folder:
            p = Path(folder) / 'rules.json'
            p.write_text(json.dumps(data, ensure_ascii=False), encoding='utf-8')
            r = LocalClassifier(p).classify({'comment_text':'求租测试镇两室'})
        self.assertEqual(r['target_regions'][0]['name'], '测试镇')


if __name__ == '__main__':
    unittest.main()
