import importlib.util
import unittest
from pathlib import Path

p=Path(__file__).resolve().parents[1]/'pool-sop-v3/classifier/classifier.py'
s=importlib.util.spec_from_file_location('pool_under_test',p)
m=importlib.util.module_from_spec(s);s.loader.exec_module(m)

class ScopeTests(unittest.TestCase):
 def test_scope(self):
  cases=[('找房找了两个月，预算1300','短租',False),('一个月1300元，求租','短租',False),('想租两个月','短租',True),('之前住了两年','长租',False),('想长租两年','长租',True),('走到地铁多少米','问价',False),('多少米','问价',True),('不养猫','猫',True),('不要中介费','中介费',True)]
  for text,tag,expected in cases:
   with self.subTest(text=text):
    self.assertEqual(tag in m.classify({'comment_text':text})['subtags'],expected)
 def test_negative_not_lost(self):
  for text,tag in [('不养猫','猫'),('不要中介费','中介费'),('不合租','合租')]:
   with self.subTest(text=text):
    es=m.classify({'comment_text':text})['evidence']
    self.assertTrue(any(e['subtag']==tag and e['polarity']=='excluded' for e in es))

if __name__=='__main__':unittest.main()
