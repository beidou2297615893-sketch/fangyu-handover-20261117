import json,pathlib,collections
W=pathlib.Path('work/fangyu-text-business-20261029');O=W/'pool-mother-review/legacy-literal-binding';ps=[json.loads(l) for l in (W/'pool-mother-review/legacy-local-planning/local-proposed-plans.jsonl').read_text(encoding='utf8').splitlines()];ps=[p for p in ps if p.get('next_action_category')=='literal_extraction_or_existing_pool_binding_gap'];c=json.loads((W/'region-brand-routing/current.json').read_text(encoding='utf8'));rs={}
for plat,f in c['results'].items():
 for l in pathlib.Path(f).read_text(encoding='utf8').splitlines():
  r=json.loads(l);rs[plat,r['comment_id'],r['customer_uid']]=r
samples=[json.loads(l) for l in (O/'representative-input.jsonl').read_text(encoding='utf8').splitlines()];samples=list({(x['plan']['platform'],x['plan']['cid'],x['plan']['uid']):x for x in samples}.values())
for p in [x for x in ps if x['platform']=='xiaohongshu'][:7]:
 r=rs[p['platform'],p['cid'],p['uid']];samples.append(dict(index=len(samples),plan=p,comment=r['comment_text'],source_record=r.get('source_record')))
(O/'representative-input.jsonl').write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in samples),encoding='utf8')
for s in samples:
 if s['plan']['platform']=='xiaohongshu':print(s['index'],s['comment'],json.dumps(s['plan'],ensure_ascii=False))
print('sample',len(samples));print('first full',json.dumps(samples[0],ensure_ascii=False));print('source keys',list(rs['douyin','7255891470896431930',samples[0]['plan']['uid']]))
