import pathlib,json,hashlib,sys,collections,copy
P=pathlib.Path(__file__).resolve().parent
B=P.parent.parent
W=B.parents[2]
sys.path.insert(0,str(W))
import mother_adapter
read=lambda p:[json.loads(l) for l in p.read_text('utf-8').splitlines() if l.strip()]
source=read(B/'shard-2.jsonl');rows=read(B/'reviewed-new-2.jsonl')
by={r['review_key']:r for r in source}
assert len(source)==len(rows)==len(by)==473
assert {r['review_key'] for r in rows}==set(by)
assert len({r['comment_id'] for r in rows})==473
assert {r['comment_id'] for r in rows}=={r['comment_id'] for r in source}
quotes=0
for r in rows:
 s=by[r['review_key']]
 for k in ('review_key','comment_id','customer_uid','video_id','platform'): assert r[k]==s[k],(r['review_key'],k)
 allowed=[s['comment_text']]+([s['post_body']] if s['post_author_same_as_commenter'] else [])
 for q in r['evidence']+[t['quote'] for f in ('topics','target_regions','time_mentions','other_constraints','contact_boundaries') for t in r[f] if isinstance(t,dict)]:
  assert any(q in text for text in allowed),(r['review_key'],q)
  quotes+=1
 assert r['reply_plan']['preferred_mother_slot'] in (None,1,2,7,13,16,19,25,28,31,34)
 assert not any(k in r for k in ('classification_method','classification_stages_completed','classification_review_source'))
 for t in r['topics']: assert t['pool'] in ('价格预算','位置通勤','户型面积与居住方式','房内设施','宠物','楼层电梯','入住与租期','房源状态','费用合同','看房联系')
# Isolated transport preflight only. The formal compiler owns final bindings.
stage=[dict(copy.deepcopy(r),classification_method='ai_semantic_initial_and_detailed',classification_stages_completed=['initial_semantic','detailed_semantic']) for r in rows]
stagepath=P/'isolated-semantic-stages.jsonl'
stagepath.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in stage),'utf-8')
digest=hashlib.sha256(stagepath.read_bytes()).hexdigest()
cache={};validated=[]
for row in stage:
 row=copy.deepcopy(row);row['classification_review_source']={'path':str(stagepath),'sha256':digest}
 mother_adapter.validate_new_review(row,B,cache)
 validated.append(row)
(P/'isolated-adapter-preflight.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in validated),'utf-8')
result={'shard':2,'input_count':473,'output_count':len(rows),'review_key_set_equal':True,'comment_id_set_equal':True,'metadata_tuple_equal':True,'evidence_quotes_checked':quotes,'evidence_exact_match':True,'page_counts':[len(read(P/f'reviewed-{i:02}.jsonl')) for i in range(3)],'formal_adapter_preflight_passed':len(validated),'adapter':str(pathlib.Path(mother_adapter.__file__).resolve()),'isolated_source':str(stagepath),'isolated_sha256':digest,'semantic_review_sha256':hashlib.sha256((B/'reviewed-new-2.jsonl').read_bytes()).hexdigest(),'roles':dict(collections.Counter(r['role'] for r in rows)),'interests':dict(collections.Counter(r['interest'] for r in rows)),'source_reads':'three full shared-post-context pages and every comment; full shard metadata for identity validation','classification':'single model pass with initial and detailed semantic decisions; not independent secondary review','formal_compiler_binding_pending':True,'platform_calls':0,'sent':0,'human_confirmed':False,'send_authorized':False}
(B/'shard-2-validation.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),'utf-8')
report=f'''# 抖音增量第三片文本判读与隔离校验

已逐条完成473条AI初筛及细筛，三个完整正文页与本人评论均已读取。逐页结果为180、180、113条。所有输入身份信息与输出逐条一致，review_key/comment_id均无缺失或重复。逐字证据共校验{quotes}处，全通过。

本片保留供给、短询、讨论、纯艾特未知，未将IP或来源门店当求租地区。本人预算、户型、设施、地区、租期与入住时间分开；不把月计价当总租期，不借帖主条件，不凭职业补预算。

主要语义处理：D0498为办公询价；D1290分别记录整租与拒合租；D1419将现居费用纠纷和新合租、停车需求区分；D1302为有房源请私信的两室求租；D1206停车与D1095整洁要求另留原文。D0201、D1032、D1080、D1164、D1233的多少米保留候选。泛租房生活展示下的短询为中兴趣并明确核实可租语境。

超高条目为D0867即时看房、D1185明确订房、D1401要此间及D1413留一间；只是本人请求，不表示预约/订房成功。其他一般看房或加联系不升超高。

已实际调用现有mother_adapter.validate_new_review，对473条真实隔离JSONL及SHA进行预检，473条全部通过。阶段和方法仅写入隔离文件；正式reviewed-new-2.jsonl未添加这些编译字段，等待compiler实际绑定。原语义评审保留。本次同轮初细筛不是独立二审、用户金标或发送许可。

本片无平台调用、无源库修改、无发送，human_confirmed=false、send_authorized=false、store_assignment=null。allow仅表示未在文本中见明确联系限制。回复计划只选择认可母句槽位并保留事实缺口，未写回复正文。未触及其他分片或总状态。

评审SHA256：{result['semantic_review_sha256']}
隔离预检源SHA256：{digest}
'''
(B/'shard-2-report.md').write_text(report,'utf-8')
(P/'progress.json').write_text(json.dumps({'completed_pages':[0,1,2],'reviewed_count':473,'formal_adapter_preflight_passed':473,'metadata_and_evidence_checks':'passed','status':'complete_wait_root_review','independent_review_claimed':False},ensure_ascii=False,indent=2),'utf-8')
print(json.dumps(result,ensure_ascii=False,indent=2))
