"""Source-bound plan/contract overlays only. No publishing, model client or platform code."""
import pathlib,json,copy,hashlib,re,string,collections,sys,datetime
sys.dont_write_bytecode=True
O=pathlib.Path(__file__).resolve().parent;W=O.parents[1];P=O.parent;A=P/'legacy-local-planning-v2';B=P/'legacy-combo-families';C=P/'legacy-literal-binding';Q=P/'legacy-release-semantic-qa';F=P/'legacy-release-package/candidate-abc';R=W/'douyin-registered-v2/increments/f98cc21138910fb9'
def load(p):return json.loads(pathlib.Path(p).read_text(encoding='utf8'))
def jl(p):return [json.loads(l) for l in pathlib.Path(p).read_text(encoding='utf8').splitlines() if l.strip()]
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def objsha(x):return hashlib.sha256(json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def key(r):return str(r['platform']),str(r.get('cid',r.get('comment_id'))),str(r.get('uid',r.get('customer_uid')))
def put(p,x):pathlib.Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
def putjl(p,rows):pathlib.Path(p).write_text(''.join(json.dumps(r,ensure_ascii=False,separators=(',',':'))+'\n' for r in rows),encoding='utf8')
cm=load(F/'candidate-manifest.json');assert cm['C_status']=='loaded_complete_manifest'
for n in ('merged-contract.json','merged-plans.jsonl'):assert sha(F/n)==cm['output_sha256'][n]
cv=load(Q/'C-validation.json');assert cv['mechanical_validation_passed'] and cv['new_C_holdout']==60
for n,h in load(Q/'C-manifest.json')['review_output_sha256'].items():assert sha(Q/n)==h,('C_not_frozen',n)
base=jl(F/'merged-plans.jsonl');assert len(base)==12963 and sum(bool(x['family']) for x in base)==6689
oldidx={key(p):p for p in base};cur=load(W/'region-brand-routing/current.json');sources={}
for platform,f in cur['results'].items():
 for r in jl(f):sources[key(r)]=r
qa=[]
for filename in ('review-200.jsonl','regression-review.jsonl','C-review-60.jsonl','C-regression-review.jsonl','C-held-boundary-review.jsonl'):
 for q in jl(Q/filename):q['QA_file']=filename;qa.append(q)
qaidx=collections.defaultdict(list)
for q in qa:qaidx[key(q)].append(q)
extra_development_CIDs={'7364774505778643753','7509108395146199844','7447474699702977314'}
for cid in sorted(extra_development_CIDs):
 p=next(p for p in base if p['cid']==cid);r=sources[key(p)]
 q={'QA_file':'extra-existing-development-coverage-correction','group':'C-extra-development','sample_index':None,'platform':p['platform'],'cid':p['cid'],'uid':p['uid'],'comment_text':r['comment_text'],'family':p['family'],'fill':p['fill'],'verdict':'development_regression_not_new_holdout','reason':'Existing proximity/utility_standard case omitted from original C60 atom/action coverage denominator; literal conditions and pronouns must survive.'};qa.append(q);qaidx[key(p)].append(q)
protected={str((F/n).resolve()):sha(F/n) for n in ('merged-contract.json','merged-plans.jsonl','candidate-manifest.json','candidate-pointer.json')}
for directory in (A,B,C,Q):
 for f in directory.rglob('*'):
  if f.is_file() and f.suffix in ('.json','.jsonl','.py','.md','.txt'):protected[str(f.resolve())]=sha(f)
for f in [W/'region-brand-routing/current.json',W/'region-brand-routing/latest-manifest.json',W/'当前双平台回复结果指针.json',P/'fifty-review-v3-short.jsonl',R/'batch_short_mothers.py',R/'local-mother-contract.json',R/'pool-short-reply-plans.jsonl']+[pathlib.Path(f) for f in cur['results'].values()]:
 if f.exists():protected[str(f.resolve())]=sha(f)
for f in (P/'legacy-semantic-contract-review').glob('*'):
 if f.is_file() and f.suffix in ('.json','.md'):protected[str(f.resolve())]=sha(f)
contract=load(A/'local-mother-contract-v2.json');contract=copy.deepcopy(contract);duplicates=[];lineage=[]
for path in (A/'local-mother-contract-v2.json',B/'contract-addon.json',C/'contract-addon.json'):
 d=load(path);lineage.append({'path':str(path.resolve()),'sha256':sha(path)})
 if path==A/'local-mother-contract-v2.json':continue
 for name,definition in d['families'].items():
  if name in contract['families']:
   if objsha(contract['families'][name])!=objsha(definition):raise ValueError('NON_EQUIVALENT_DUPLICATE_FAMILY '+name)
   duplicates.append(name)
  else:contract['families'][name]=copy.deepcopy(definition)
assert contract['families']==load(F/'merged-contract.json')['families']
oldcontract=copy.deepcopy(contract);contract.update(version='legacy-release-repairs-review-only',applied=False,send_authorized=False,lineage=lineage)
template_overrides=[]
for name in ('combo_available_price','combo_price_utilities','combo_rent_price_confirm'):
 old=contract['families'][name]['template'];new=old.replace('月租','租金');contract['families'][name]['template']=new
 if old!=new:template_overrides.append({'family':name,'old':old,'new':new,'reason':'quote_cycle_unspecified_use_neutral_rent'})
renderer={};exec(compile((R/'batch_short_mothers.py').read_text(encoding='utf-8-sig'),str(R/'batch_short_mothers.py'),'exec'),renderer)
def definition(name,template,slots,clarification=False):
 d={'template':template,'required_fill':slots,'scope':'clarification_only' if clarification else 'housing_confirmation','individually_user_approved':False,'source_policy':'literal own-comment parameters; static repair rule; never changes original classification'}
 if name in contract['families'] and contract['families'][name]!=d:raise ValueError('REPAIR_FAMILY_COLLISION '+name)
 contract['families'][name]=d;return name
def variant(origin,template,slots,clarification=False):return definition('repair_'+origin+'_'+objsha([template,slots,clarification])[:10],template,slots,clarification)
def comment_fields(r):
 s=r.get('source_record') or {};a=s.get('classification') if isinstance(s.get('classification'),dict) else s;return s,a
def remarks(r):
 s,a=comment_fields(r);out=[]
 for d in (r,s,a):
  for f in ('needs_review','review_reasons','semantic_review_reasons','blocking_reasons'):
   v=d.get(f) or [];out.extend(v if isinstance(v,list) else [str(v)])
 return list(dict.fromkeys(str(x) for x in out))
def own_evidence(p):return [x for x in p.get('literal_evidence',[]) if x.get('subject')=='own_demand']
def tone_template(z):return contract['families'][z['family']]['template'] if z['family'] else None
def core_text(template):
 t=re.sub(r'^宝宝，(?:可以聊呀！)?(?:我住方隅，)?','',template);t=t.replace('我住方隅，','').replace('介绍有优惠。','').rstrip('，。')
 return t
def evidence(field,quote,source='own_comment_literal',pool=None):return {'field':field,'quote':quote,'source_field':source,'pool':pool}
def rebind(z,f,fill,ev,reason,clarify=False,proof=None):
 z.update(family=f,fill=fill,evidence=ev,hold_reasons=[],clarification_only=clarify,status='local_plan_proposed');z['repair_reasons'].append(reason)
 if proof:z['repair_evidence'].append(proof)
def changed_template(z,template,reason,clarify=None):
 old=z['family'];cf=z.get('clarification_only',False) if clarify is None else clarify
 f=variant(old,template,list(z['fill']),cf);rebind(z,f,z['fill'],z['evidence'],reason,cf)
def append_action(template,action):
 if action in template:return template
 if '你说的“多少”' in action:return template.rstrip('。')+'。'+action.rstrip('呀')+'？'
 if '介绍有优惠。' in template:
  stem=template.replace('介绍有优惠。','').rstrip('，。');stem=re.sub(r'(?:我)?(?:一并|也)?帮你(?:问|核实)$','',stem).rstrip('，、');stem=stem.replace('有没有合适的','的房源').replace('位置可以发你','具体位置').replace('位置发你','具体位置')
  noun=re.sub(r'(?:我)?(?:一并|也)?帮你问$','',action).rstrip('，、');return stem+'、'+noun+'一起帮你问，介绍有优惠。'
 return template.rstrip('。')+'，'+action+'。'
def price_span(value,text,p):
 if not value or value not in text:return value
 positions=[m for m in re.finditer(re.escape(value),text)]
 if len(positions)!=1:return value
 m=positions[0];left=text[max(0,m.start()-12):m.start()];right=text[m.end():m.end()+20]
 # Only grow an already bound numeric span; do not infer its role from the pool or polarity.
 prefix=re.search(r'(?:[<＜≤≦>＞≥≧]=?\s*|不超过\s*|不高于\s*|低于\s*|少于\s*|小于\s*|大于\s*|高于\s*|至多\s*|至少\s*|最多\s*)$',left)
 suffix=re.match(r'(?:\s*(?:元|块))?(?:\s*(?:以内|以下|以上|左右|上下|出头|之内|封顶))?(?:\s*(?:/月|/天|/周|/年|每月|每周|每天|每年|一个月|一天|一周|一年))?',right)
 result=(prefix.group() if prefix else '')+value+(suffix.group() if suffix else '')
 return result if result in text else value
def strip_punct(t):return re.sub(r'\[[^\]]*\]|[\s，,。？！?!：:；;]','',t)
def is_pure_short_lease(p,r):
 fs=p['source_field_evidence'];tags={x if isinstance(x,str) else x.get('pool') for x in fs['topics']};txt=strip_punct(r['comment_text'])
 if r.get('role')!='demand' or r.get('demand_state')!='active_at_comment' or r.get('interest_at_comment') not in ('medium','high','super_high'):return None
 if tags!={'入住与租期'} or fs.get('target_regions') or fs.get('other_constraints') or fs.get('contact_boundaries'):return None
 if not own_evidence(p) or any(e.get('polarity') not in ('ask','require','prefer') for e in own_evidence(p)):return None
 m=re.fullmatch(r'(?:请问|你好)?(?:有|有没有|可以)?短租(?P<duration>(?:一个月|二个月|两个月|三个月|一周|两周|半个月))?(?:(?:可以|能)?(?:吗|么|不)|可以|能|有吗|多久)?',txt)
 return m
def normalize(p):
 z=copy.deepcopy(p);r=sources[key(p)];s,a=comment_fields(r);text=r['comment_text'];z['repair_reasons']=[];z['repair_evidence']=[];z['repair_hold_reasons']=[]
 if not p['family']:
  pure=is_pure_short_lease(p,r)
  if pure:
   duration=pure.group('duration')
   if duration:
    f=definition('repair_short_fixed_lease','宝宝，我住方隅，短租{duration}能不能租帮你问，介绍有优惠。',['duration'],True);rebind(z,f,{'duration':duration},[evidence('duration',duration,pool='入住与租期')],'authorized_small_addition_pure_short_lease_existing_AI_confirmed',True)
   else:
    f=definition('repair_short_lease_duration_check','宝宝，我住方隅，短租能否租、可租多久帮你问，介绍有优惠。',[],True);rebind(z,f,{},[],'authorized_small_addition_short_lease_duration_unknown_not_monthly_quote',True)
  return z
 # All raw source metadata remains intact; only literal parameter bindings may change.
 for field,value in list(z['fill'].items()):
  if field in ('budget','price_condition','asked_price'):
   new=price_span(value,text,p)
   if new!=value:
    z['fill'][field]=new;z['evidence']=[evidence(field,new,pool='价格预算') if e['field']==field else e for e in z['evidence']];z['repair_reasons'].append('preserve_literal_price_comparator_qualifier_cycle');z['repair_evidence'].append({'field':field,'old':value,'quote':new})
  if field.startswith('room') and value in text:
   m=re.search(re.escape(value)+r'(?:公寓|住宅)',text)
   if m and m.group()!=value:
    new=m.group();z['fill'][field]=new;z['evidence']=[evidence(field,new,pool='户型面积与居住方式') if e['field']==field else e for e in z['evidence']];z['repair_reasons'].append('preserve_literal_room_apartment_type')
  if field=='cost_preference' and value in text:
   m=re.search(r'(?:这么|那么|这样|这个价位(?:这么)?|如此)'+re.escape(value),text)
   if m:
    new=m.group();z['fill'][field]=new;z['evidence']=[evidence(field,new,pool='价格预算') if e['field']==field else e for e in z['evidence']];z['repair_reasons'].append('preserve_comparative_price_demonstrative');z['repair_evidence'].append({'quote':new,'role':'unresolved_comparison_reference_not_absolute_budget'})
 template=tone_template(z)
 # Explicit daily/weekly/yearly or unspecified quote cycles cannot be overwritten by monthly wording.
 monthly_price=bool(re.search(r'多少钱(?:一|每|个)?个月|多少(?:一|每|个)?个月|(?:月租|每月)[^，。?？]{0,5}(?:多少|价格|钱)|每个月多少钱|一个月多少钱|多少一个月',text))
 nonmonthly=bool(re.search(r'每天|每日|一天|日租|每周|一周|周租|半个月|每年|一年|年租',text))
 if '月租' in template and (not monthly_price or nonmonthly):
  template=template.replace('月租','租金');z['repair_reasons'].append('neutral_quote_cycle_not_impose_monthly_price')
 # Numerical price conditions are not automatically the customer's budget.
 if '预算' in template and '预算' not in text:
  template=template.replace('预算{budget}','{budget}这个价位').replace('{budget}预算','{budget}这个价位');z['repair_reasons'].append('numeric_condition_not_inferred_customer_budget_from_pool_polarity')
 if '{asked_price}是否实价' in template:
  explicit_ref=bool(re.search(r'真假|真的吗|真的是|实价|这个价|这个房子|原帖|这么便宜|那种价格|广告',text))
  if not explicit_ref:template=template.replace('{asked_price}是否实价','{asked_price}这个价位有没有合适的');z['repair_reasons'].append('price_condition_no_presumed_source_advertised_price')
  else:template=template.replace('{asked_price}是否实价','你指的{asked_price}是否属实');z['repair_reasons'].append('source_referenced_price_not_fangyu_quote')
 if 'cost_preference' in z['fill'] and re.search(r'这么|那么|如此|这个价',z['fill']['cost_preference']):template=template.replace('{cost_preference}','你说的“{cost_preference}”这个价位');z['repair_reasons'].append('comparison_reference_kept_as_question_not_absolute_price')
 # Overlapping lease-mode spans are merged locally; no "longest" or fixed month count is invented.
 leasekeys=[k for k in z['fill'] if k in ('lease','lease_2','duration')]
 if len(leasekeys)>1:
  vals=[z['fill'][k] for k in leasekeys]
  if any(any(v in other for j,other in enumerate(vals) if j!=i) for i,v in enumerate(vals)) or len(set(vals))<len(vals):
   if '短租' in text and '月租' in text and set(z['fill'])<=set(leasekeys) and not any(re.search(r'[0-9一二两三四五六七八九十半]+个?(?:月|年|天|周)',v) for v in vals):
    f=definition('repair_monthly_short_lease_mode','宝宝，我住方隅，能否按月短租、可租多久帮你问，介绍有优惠。',[]);rebind(z,f,{},[],'merge_overlapping_short_and_monthly_lease_modes_no_price_cycle_inference');template=tone_template(z)
   else:
    keep=[]
    for k in sorted(leasekeys,key=lambda k:len(z['fill'][k]),reverse=True):
     if not any(z['fill'][k] in z['fill'][kk] for kk in keep):keep.append(k)
    removed=[k for k in leasekeys if k not in keep]
    for k in removed:template=re.sub(r'\{'+re.escape(k)+r'\}、?','',template);z['fill'].pop(k);z['evidence']=[e for e in z['evidence'] if e['field']!=k]
    template=template.replace('，、','，');z['repair_reasons'].append('merge_overlapping_lease_literal_slots_without_new_duration')
 if 'lease' in z['fill'] and z['fill']['lease']=='月租' and re.search(r'月租(?:吗|么|不)',text):template=template.replace('{lease}、','能否按月租、');z['fill'].pop('lease');z['evidence']=[e for e in z['evidence'] if e['field']!='lease'];z['repair_reasons'].append('monthly_lease_mode_question_separate_from_quote_cycle')
 # Pricing-period spans must be adjacent to a price question in existing own-demand price evidence.
 periods=[];cycle=r'半个月|每半月|一个月|每个月|每月|一天|每天|每日|一周|每周|一年|每年|一晚|每晚'
 for e in own_evidence(p):
  if e.get('pool')!='价格预算' or e.get('polarity')!='ask':continue
  q=e.get('quote') or ''
  for pat in (r'('+cycle+r').{0,2}(?:多少钱|多少|租金|价格|房租)',r'(?:多少钱|多少|租金|价格|房租).{0,2}('+cycle+r')'):
   periods.extend(m.group(1) for m in re.finditer(pat,q) if m.group(1) in text)
 periods=list(dict.fromkeys(periods))
 if len(periods)==1 and re.search(r'租金|月租',template) and 'price_cycle' not in z['fill']:
  z['fill']['price_cycle']=periods[0];z['evidence'].append(evidence('price_cycle',periods[0],pool='价格预算'));template=template.replace('月租','{price_cycle}的租金').replace('租金','租金',1)
  if '{price_cycle}' not in template:template=template.replace('租金','{price_cycle}的租金')
  z['repair_reasons'].append('preserve_explicit_literal_price_cycle_separate_from_lease_duration')
 if z['fill'].get('fee')=='水电' and '{fee}、水电标准' in template:
  wording='{fee}按民用还是商用计费' if '民用' in text and '商用' in text else '{fee}标准'
  template=template.replace('{fee}、水电标准',wording);z['repair_reasons'].append('merge_redundant_utility_standard_and_preserve_original_alternatives')
 # Find-home and recommendation actions are not a rent-procedure request.
 if '租房流程' in template and re.search(r'推荐|哪里.{0,4}(?:租|有)|在哪.{0,3}租|想租|就租这套',text):
  template=template.replace('租房流程','找房位置和房源推荐');z['repair_reasons'].append('retain_home_search_recommendation_not_rent_process')
 # Preserve inbound contact direction, private channel, and independent viewing action.
 inbound=re.search(r'(?:联系我(?:一下)?|私信我(?:一下)?|私聊我|私我|私一下|加我|房东可以联系我)',text)
 customer_outbound=bool(re.search(r'(?:我|我们)(?:来|去|想|可以|能)?(?:私信|私聊|联系|私一下)(?:你|一下)?|(?:私信|私聊|联系)你',text))
 if customer_outbound and inbound and inbound.group()=='私一下':inbound=None
 private=bool(re.search(r'私信|私聊|私我|私一下',text));how=bool(re.search(r'怎么联系|如何联系|联系方式|联系你|怎样联系',text));view=bool(re.search(r'看房|约看',text))
 if how and '点我聊就行' in template:template=template.replace('点我聊就行','联系方式帮你问');z['repair_reasons'].append('contact_how_question_kept_as_method_not_forced_customer_action')
 if re.search(r'不要.{0,3}(?:私信|联系)|别.{0,3}(?:私信|联系)|勿.{0,3}(?:私信|联系)',text):
  z.update(family=None,fill={},evidence=[],status='local_plan_held');z['repair_hold_reasons'].append('explicit_contact_negation_requires_scope_review_not_auto_direction_repair');z['hold_reasons']=list(dict.fromkeys(p.get('hold_reasons',[])+z['repair_hold_reasons']));z['repair_reasons'].append('preserve_explicit_contact_negation_hold');return z
 if inbound or private:
  action=('私聊联系你的事' if private else '联系你的事') if inbound else ('你私聊的对接' if customer_outbound else '私聊对接')
  if '房东' in text and '房东' not in template:action='请房东'+action
  if '联系方式' in template:template=template.replace('联系方式',action)
  elif '点我聊就行' in template:template=template.replace('点我聊就行',action+'我一并帮你问')
  else:template=append_action(template,action+'我一并帮你问')
  z['repair_reasons'].append('preserve_contact_to_customer_direction_and_original_private_channel' if inbound else 'preserve_private_channel_without_inventing_initiator');z['repair_evidence'].append({'quote':inbound.group() if inbound else re.search(r'私信|私聊|私我|私一下',text).group(),'role':'contact_request_not_contact_information','direction':'to_customer' if inbound else 'customer_outbound' if customer_outbound else 'unspecified_private_channel'})
 elif how and not re.search(r'联系|点我聊',template):template=append_action(template,'怎么联系我也帮你问');z['repair_reasons'].append('retain_contact_method_in_addition_to_viewing')
 if view and not re.search(r'看房|约看',template):template=append_action(template,'看房安排也帮你问');z['repair_reasons'].append('retain_viewing_action_not_only_contact')
 actor=re.search(r'找(?:小姐姐|小哥哥|姐姐|房东)看房',text)
 if actor and 'actor_request' not in z['fill']:
  z['fill']['actor_request']=actor.group();z['evidence'].append(evidence('actor_request',actor.group(),pool='看房联系'));template=template.replace('看房安排','“{actor_request}”的安排').replace('约看时间','“{actor_request}”的约看时间');z['repair_reasons'].append('retain_viewing_counterparty_preference_without_sender_identity_claim')
 # Retain an unbound "how much" as an indicator question, not an invented price pool.
 if re.search(r'多少',text) and not re.search(r'租金|月租|价格|价位|费用|多少|多久|面积',template):
  template=append_action(template,'你说的“多少”是指租金、面积还是其他指标呀');z['repair_reasons'].append('retain_unknown_numeric_indicator_without_reclassifying_pool')
 # If original AI itself says the indicator is unknown, ask even when another branch would call it price.
 reviews=remarks(r)
 if any('多少' in x and re.search(r'指标未明|所指.*未明',x) for x in reviews):
  if '你说的“多少”' not in template:template=append_action(template,'你说的“多少”是指租金、面积还是其他指标呀');z['repair_reasons'].append('existing_AI_unknown_indicator_requires_minimal_question')
 # Rebuild a variant before object clarifications so every other literal condition/action survives.
 if template!=tone_template(z) or set(z['fill'])!=set(contract['families'][z['family']]['required_fill']):changed_template(z,template,'shared_template_or_slot_mode_repair')
 raw=r.get('original_raw_record') or {};title=raw.get('post_title') or '';body=raw.get('post_text') or s.get('post_body') or '';context=title+' '+body
 residential=bool(re.search(r'住宅|公寓|一室|二室|两室|[1234]室|卧室|房间|一居|整租|合租|serviced\s+apartment',context,re.I))
 semantic_object_warning=any(re.search(r'住宅属性|住宅用途|用途.{0,8}(?:未|不明|确认)|交易对象.{0,8}(?:未|确认)|先确认交易对象',x) for x in reviews)
 personal_unknown=not body and '个人转租' in title and not residential and not re.search(r'房子|住房|住宅|公寓|卧室|房间|租房',text)
 QA_object_warning=any(q.get('family') and q.get('verdict')!='pass' and re.search(r'住宅用途|住宅对象|对象确认|住宅线索|同帖缺住宅',q.get('reason','')) for q in qaidx[key(p)])
 # Prefer actual source context over a mistaken independent QA description.
 if (semantic_object_warning or personal_unknown or QA_object_warning) and not z.get('clarification_only'):
  core=core_text(tone_template(z))
  if residential:
   template='宝宝，你问的是原帖这套住房吗？也考虑方隅的房源吗？确认对象后，'+core+'。';reason='housing_is_evident_confirm_source_object_relation_not_unknown_residential_use'
  else:template='宝宝，你是在找住的房子吗？确认对象后，'+core+'。';reason='original_blocking_or_title_context_requires_object_clarification_not_promotion'
  changed_template(z,template,reason,True);z['repair_evidence'].append({'source':'actual_original_raw_record_and_source_record_metadata','title':title,'body_missing':not bool(body),'residential_clue_present':residential,'warning_quotes':[x for x in reviews if re.search(r'用途|对象|住宅',x)],'QA_context_corrected':bool(QA_object_warning and residential)})
 # Named entities without an actual location topic can be the object being quoted; never guess their nature.
 tags={x if isinstance(x,str) else x.get('pool') for x in p['source_field_evidence']['topics']}
 if p['family']=='combo_place_room_price' and '位置通勤' not in tags and 'place' in z['fill'] and not z.get('clarification_only'):
  f=variant('named_object_relation','宝宝，你问的是“{place}”的{room}租金吗？也考虑方隅的房源吗？',['place','room'],True);rebind(z,f,{'place':z['fill']['place'],'room':z['fill']['room']},[e for e in z['evidence'] if e['field'] in ('place','room')],'named_quote_object_relation_unresolved_not_guessed_project_or_area',True)
 specific=re.search(r'这套(?:房)?|这一套',text)
 if specific and not z.get('clarification_only'):
  z['fill']['object_reference']=specific.group();z['evidence'].append(evidence('object_reference',specific.group()));core=core_text(tone_template(z)).replace('找房位置和房源推荐','所指房源的租赁对接');template='宝宝，你说的“{object_reference}”是原帖房源吗？确认对象后，'+core+'。';changed_template(z,template,'preserve_specific_original_unit_reference_not_generic_fangyu_inventory',True)
 kind_reference=re.search(r'这种(?:价位|房型|房子)?|那种(?:价位|房型|房子)?|这类(?:房源)?|这样的(?:房子)?|同款',text)
 if kind_reference and 'kind_reference' not in z['fill'] and not z.get('clarification_only'):
  ref=kind_reference.group();z['fill']['kind_reference']=ref;z['evidence'].append(evidence('kind_reference',ref));reference_phrase='按你说的“{kind_reference}”，' if '价' in ref else '你说的“{kind_reference}”这类房源，'
  template='宝宝，我住方隅，'+reference_phrase+core_text(tone_template(z))+'，介绍有优惠。';changed_template(z,template,'preserve_deictic_housing_or_price_kind_reference_not_unreferenced_demand')
 unresolved_place=any(re.search(r'具体.{0,4}(?:园区|地点).{0,5}未明|不能自行定位',x) for x in reviews)
 if unresolved_place and z['fill'].get('place') and not z.get('clarification_only'):
  core=core_text(tone_template(z)).replace('{place}、','');template='宝宝，你说的“{place}”具体是哪处？确认地点后，'+core+'。';changed_template(z,template,'existing_AI_unresolved_site_requires_literal_location_confirmation',True)
 if z['fill'].get('cost_preference') and re.search(r'这么|那么|如此|这个价',z['fill']['cost_preference']) and not z.get('clarification_only'):
  core=core_text(tone_template(z));core=re.sub(r'你说的“\{cost_preference\}”这个价位、?','',core);template='宝宝，你说的“{cost_preference}”是指原帖的价位吗？确认价位后，'+core+'。';changed_template(z,template,'unresolved_comparison_anchor_kept_as_minimal_price_reference_question',True)
 if 'source_referenced_price_not_fangyu_quote' in z['repair_reasons'] and not z.get('clarification_only'):
  core=core_text(tone_template(z));core=re.sub(r'你指的\{asked_price\}是否属实、?','',core);template='宝宝，你指的{asked_price}是原帖报价吗？确认对象后，'+core+'。';changed_template(z,template,'source_advertised_quote_relation_kept_as_question_not_own_brand_price',True)
 return z
def render_plan(p,contract_used=contract):
 if not p.get('family'):return None
 r=sources[key(p)];return renderer['render_plan']({'role':r['role'],'demand_state':r['demand_state'],'interest_at_comment':r['interest_at_comment'],'reply_plan':{'local_mother':{'family':p['family'],'fill':p['fill'],'evidence':p['evidence']},'contact_policy':r.get('contact_policy') or 'unknown','tone':r.get('effective_tone')}},r['comment_text'],contract_used)['validated_plan_text']
def validate(p,z):
 r=sources[key(p)];assert p['sourceSHA']==hashlib.sha256(r['comment_text'].encode()).hexdigest();assert p['original_classification_sha256']==objsha(r['source_record']);assert z['source_field_evidence']==p['source_field_evidence'];assert z.get('send_authorized') is False and z.get('can_send_now') is False
 if z['family']:
  text=render_plan(z);assert text
  for k,v in z['fill'].items():
   for x in v.split('、') if k=='requirements' else [v]:assert x in r['comment_text'] and any(e['field']==k and x in e['quote'] for e in z['evidence'])
  assert not re.search(r'预算[^，。]{0,18}预算',text)
  assert '最长' not in text or '最长' in r['comment_text']
 else:assert z.get('hold_reasons')
 return True
def projection(p):return {k:p.get(k) for k in ('family','fill','evidence','clarification_only','hold_reasons','status')}
def overlay(p,z):
 newtext=render_plan(z);oldtext=render_plan(p,oldcontract) if p['family'] else None
 if projection(p)==projection(z) and newtext==oldtext:return None
 return {'platform':p['platform'],'cid':p['cid'],'uid':p['uid'],'sourceSHA':p['sourceSHA'],'source_file_sha256':p['source_file_sha256'],'original_classification_sha256':p['original_classification_sha256'],'base_merged_plan_sha256':objsha(p),'base_origin':p.get('plan_origin','A'),'base_family':p['family'],'base_fill':p['fill'],'replacement_plan':projection(z),'repair_reasons':list(dict.fromkeys(z['repair_reasons'])) or ['shared_contract_neutral_quote_cycle_change'],'repair_evidence':z['repair_evidence'],'original_source_contact_policy':p.get('contact_policy_original'),'source_contact_boundary_preserved':p['source_field_evidence'].get('contact_boundaries'),'source_needs_review_and_blocking_preserved':remarks(sources[key(p)]),'base_holds_preserved_as_evidence':p.get('hold_reasons'),'newly_bound_small_short_lease_addition':not p['family'] and bool(z['family']),'old_preview_sha256':hashlib.sha256(oldtext.encode()).hexdigest() if oldtext else None,'new_preview_sha256':hashlib.sha256(newtext.encode()).hexdigest() if newtext else None,'classification_changed':False,'send_authorized':False,'can_send_now':False,'applied':False}
def qa_regression(q,z,p):
 return {'QA_file':q['QA_file'],'group':q.get('group'),'sample_index':q.get('sample_index'),'platform':q['platform'],'cid':q['cid'],'uid':q['uid'],'sourceSHA':p['sourceSHA'],'old_QA_verdict':q['verdict'],'old_QA_reason':q['reason'],'old_family':q.get('family'),'old_fill':q.get('fill'),'frozen_ABC_family_before_this_repair':p['family'],'frozen_ABC_origin':p.get('plan_origin','A'),'old_QA_hold_already_bound_by_frozen_C':not q.get('family') and bool(p['family']) and p.get('plan_origin')=='C','new_family':z['family'],'new_fill':z['fill'],'new_clarification_only':z.get('clarification_only',False),'new_hold_reasons':z.get('hold_reasons'),'repair_reasons':list(dict.fromkeys(z['repair_reasons'])),'actual_source_context_correction':any(e.get('QA_context_corrected') for e in z['repair_evidence']),'regression_preview':render_plan(z),'unchanged_original_role':sources[key(p)]['role'],'unchanged_original_state':sources[key(p)]['demand_state'],'unchanged_original_interest':sources[key(p)]['interest_at_comment'],'remediation_regression_not_fresh_holdout':True,'new_semantic_grade_issued':False,'source_evidence_preserved':True}
if __name__=='__main__':
 stage=sys.argv[1] if len(sys.argv)>1 else 'prototype'
 if stage=='prototype':
  important=[q for q in qa if q.get('family') and q['verdict']!='pass'];seen=set();out=[]
  for q in important:
   k=key(q)
   if k in seen:continue
   seen.add(k);p=oldidx[k];z=normalize(p);validate(p,z);out.append(qa_regression(q,z,p))
  putjl(O/'prototype-regression.jsonl',out);put(O/'prototype-contract.json',contract);print(json.dumps({'prototype_count':len(out),'changes':sum(bool(x['repair_reasons']) for x in out),'clarifications':sum(x['new_clarification_only'] for x in out),'still_held':sum(not x['new_family'] for x in out)},ensure_ascii=False));sys.exit()
 assert stage=='full' and (O/'prototype-regression.jsonl').exists()
 result={};overlays=[];scans=[]
 for p in base:
  z=normalize(p);validate(p,z);result[key(p)]=z;ov=overlay(p,z)
  if ov:overlays.append(ov)
  if p['family'] or ov:
   newtext=render_plan(z);scans.append({'platform':p['platform'],'cid':p['cid'],'uid':p['uid'],'sourceSHA':p['sourceSHA'],'base_plan_sha256':objsha(p),'base_family':p['family'],'final_family':z['family'],'has_overlay':bool(ov),'held':not bool(z['family']),'clarification_only':z.get('clarification_only',False),'checks':['identity_SHA_source_classification','literal_parameter_and_fixed_contract','contact_direction_and_channel_scan','explicit_price_comparator_qualifier_role_cycle_scan','object_warning_and_source_context_scan','lease_overlap_and_view_action_scan'],'repair_reasons':list(dict.fromkeys(z['repair_reasons'])),'remaining_specific_hold':z.get('hold_reasons') if not z['family'] else []})
 put(O/'repair-contract.json',contract);putjl(O/'source-bound-plan-overlays.jsonl',overlays);putjl(O/'full-risk-scan-receipts.jsonl',scans)
 familymatrix=[]
 for name in sorted({p['family'] for p in base if p['family']}):
  members=[p for p in base if p['family']==name];d=oldcontract['families'][name]
  familymatrix.append({'original_family':name,'source_bound_count':len(members),'original_slots':d['required_fill'],'original_template':d['template'],'repaired_transitions':dict(collections.Counter(result[key(p)]['family'] or 'specific_hold' for p in members)),'compiled_and_literal_checked_for_all_members':True,'semantic_whole_family_approval_claim':False})
 putjl(O/'all-family-structure-matrix.jsonl',familymatrix)
 regress=[qa_regression(q,result[key(q)],oldidx[key(q)]) for q in qa];putjl(O/'old-QA-regression.jsonl',regress)
 for path,digest in protected.items():assert sha(path)==digest,('FROZEN_SOURCE_CHANGED',path)
 newbound=[z for z in result.values() if z['family']];stats={'base_total_plans':len(base),'base_bound_housing':sum(bool(p['family']) and not p.get('clarification_only') for p in base),'base_bound_clarification':sum(bool(p['family']) and bool(p.get('clarification_only')) for p in base),'overlays':len(overlays),'overlays_by_base_origin':dict(collections.Counter(x['base_origin'] for x in overlays)),'original_bound_risk_scanned':sum(bool(p['family']) for p in base),'newly_bound_short_lease_clarifications':sum(x['newly_bound_small_short_lease_addition'] for x in overlays),'new_housing_plans':sum(not z.get('clarification_only') for z in newbound),'new_clarification_plans':sum(bool(z.get('clarification_only')) for z in newbound),'held_after':len(base)-len(newbound),'new_holds_from_bound':sum(bool(p['family']) and not result[key(p)]['family'] for p in base),'repair_reason_counts':dict(collections.Counter(reason for x in overlays for reason in x['repair_reasons'])),'old_QA_regression_count':len(regress),'old_QA_wrong_context_corrected':sum(x['actual_source_context_correction'] for x in regress),'base_family_count':len({p['family'] for p in base if p['family']}),'merged_original_contract_family_count':len(oldcontract['families']),'repaired_contract_family_count':len(contract['families']),'duplicate_equivalent_definitions':duplicates}
 manifest={'status':'review_only_not_applied','created_at':datetime.datetime.now().astimezone().isoformat(),'source_SHA256':protected,'frozen_ABCs':{str(f.resolve()):sha(f) for f in [A/'local-proposed-plans.jsonl',B/'source-bound-plans.jsonl',C/'proposed-plans.jsonl',F/'merged-plans.jsonl']},'contract_lineage':lineage,'source_current_pointer_sha256':sha(W/'region-brand-routing/current.json'),'template_overrides':template_overrides,'repair_script_sha256':sha(__file__),'artifacts_sha256':{n:sha(O/n) for n in ('repair-contract.json','source-bound-plan-overlays.jsonl','full-risk-scan-receipts.jsonl','old-QA-regression.jsonl','all-family-structure-matrix.jsonl')},'source_classification_writes':0,'frozen_plan_or_QA_writes':0,'pointer_changes':0,'platform_calls':0,'local_renderer_model_calls':0,'new_direct_API_requests':0,'send_attempts':0,'overall_agent_judgment_usage':'unknown','usage':'unknown'}
 put(O/'manifest.json',manifest);put(O/'statistics.json',stats);put(O/'validation.json',{'all_technical_checks_passed':True,'technical_coverage_not_accuracy':True,'manifest_sha256':sha(O/'manifest.json'),'source_classification_preserved':True,'all_source_SHA_unchanged':True,'all_false_send_flags':True,'semantic_independent_recheck_pending':True,'statistics':stats})
 put(O/'coverage-correction.json',{'old_C60_claim_not_reused':True,'actual_old_C60_exact_family_coverage':'51 of 147; 96 not covered','missing_atom_or_action_in_old_C60':['proximity','utility_standard'],'extra_existing_development_regressions':[{'cid':cid,'family':next(p['family'] for p in base if p['cid']==cid),'sourceSHA':next(p['sourceSHA'] for p in base if p['cid']==cid)} for cid in sorted(extra_development_CIDs)],'new_holdout_claim':False,'old_QA_files_modified':False,'all_family_semantic_approval_claim':False})
 report=['# 合并历史计划的共性修补候选','','仅修计划、槽位和本地合同，未发布。冻结A/B/C、原QA、源分类、指针和50条用户稿保持不变。',f'扫描原已绑定 {stats["original_bound_risk_scanned"]} 条，产生 {len(overlays)} 条有行为变化的来源绑定覆盖计划。另新增纯短租最小确认 {stats["newly_bound_short_lease_clarifications"]} 条，单列并保留原hold依据。',f'修后住房家族 {stats["new_housing_plans"]} 条、确认接话 {stats["new_clarification_plans"]} 条、具体待核 {stats["held_after"]} 条。覆盖数是技术统计，不是语义准确率或可发送率。','','共性修补覆盖报价周期、比较符和金额边界、价位与本人预算、源报价预设、联系方向/渠道、看房动作、推荐找房与流程、未知“多少”指标、短租重叠槽、点名/这套对象、比较价参照和原AI未决地点。原客户条件及语义警告保持，不凭缺库存或住户/优惠事实未核而一律阻止纯草稿。','','A/B200、15回归、C60、C1回归和C6边界在旧QA回归对照中保留；全部已经用于整改，不算新留出或新语义全通过。A117按实际标题一室一厅的住宅线索修对象关系，不沿用旧QA错误的用途未明描述。短租多久不添加最长；有500等数字不凭pool/polarity改成客户预算。','','本轮等待root与现有QA独立复核。原源写0、指针改0、新直接API请求0、本地渲染模型调用0、平台0、发送0；整体agent判读token用量未知。','',json.dumps(stats,ensure_ascii=False,indent=2)]
 (O/'report.md').write_text('\n'.join(report)+'\n',encoding='utf8');print(json.dumps(stats,ensure_ascii=False,indent=2))
