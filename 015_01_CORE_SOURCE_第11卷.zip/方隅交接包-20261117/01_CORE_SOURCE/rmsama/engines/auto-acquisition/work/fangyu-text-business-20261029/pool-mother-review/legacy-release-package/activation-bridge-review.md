# 消费桥的最终激活核验补充（尚未执行）

当前 `consumer-bridge-v1/` 是 v1 技术演示，不是可激活版本。Astra 对 v1 的复核仍有两处待修，v2 修补及其最终 gate 均未完成；未满足之前禁止使用该目录替换真实消费指针。候选元数据当前明确标记 `activation_permitted=false` 与 `semantic_gate_passed=false`。

最终接续时，先按固定 v1、v2 的 READY 和 SHA 顺序合并，重新构建候选和消费桥，并重复 UID、原文与计划证据、合同、结果哈希、原首选/备选和发送权限检查。新独立 Astra gate 必须明确针对最终 v1+v2 结果及相应合同/计划/来源版本通过；只可标记合同版本范围的语义门禁通过，不能将每条标为独立二审通过。若 gate 与任一文件 SHA 不匹配，或仍有需要修补的事项，停止并重新构建。

激活前将本包 `immutable-baseline/` 的三个快照哈希与真实 region current、主回复指针、latest-manifest 逐项做 expected_previous 比较；不同则中止。按 `activation-rollback-review.md` 的兼容桥、互斥读取/维护窗口和回读协议操作，不覆盖当前运行状态。不要把旧版 current 的 live 路径列为激活后仍需等于旧哈希的不可变输入；旧版内容只能通过本包独立快照引用。

`check_registered_delta.py` 只检查其验证文件的技术 `all_passed`，本次隔离验证成功不能代替 Astra gate；原脚本还会写实际运行状态，不应直接用于激活前后验证。影子副本验证路径和不变收据见 `isolated-consumer-check/isolation-receipt.json`。原 `build_human_report.py` 能正常读取但含旧版基础母句叙述，不能按原样用于候选；可审阅的本地修正版在 `isolated-consumer-check/corrected-human-report/`，它同样是隔离候选，不代表已发布报告。

实际提交必须在读者隔离或有一致性守卫时进行；三个指针不具备跨文件原子更新。先准备可审核的新版本文件，完成完整 SHA 和作用域核验，再提交与读回；任一指针在最后核验后发生变化则中止。回退只能以本次新版本 SHA 为条件恢复三个旧指针快照，不回滚分类、采集、运行状态或发送回执。具体新增分类源接续见 `incremental-text-continuity.md`。
