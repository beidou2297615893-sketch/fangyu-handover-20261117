import json,pathlib,sys,hashlib,copy,collections,datetime
P=pathlib.Path(__file__).resolve().parent;B=P.parent;A=B/'recall-audit'/'part-0';W=B.parents[2]
sys.path.insert(0,str(W));import mother_adapter
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:[json.loads(s) for s in p.read_text('utf-8-sig').splitlines() if s.strip()]
task=json.loads((A/'task.json').read_text('utf-8'))
primary={};primary_shas={}
for src in task['primary_sources']:
 p=B/src['path'];digest=sha(p);assert digest==src['sha256'];primary_shas[src['path']]=digest
 for r in read(p):assert r['review_key'] not in primary;primary[r['review_key']]=r
adapter_sha=sha(pathlib.Path(mother_adapter.__file__))
allowed=set('role demand_state interest topics target_regions time_mentions other_constraints possible_topics evidence reason context_used needs_review contact_boundaries context_flags reply_plan'.split())
all_audit=[];selected=[];page_counts=[];quotes=0;initial_match=0
for n in range(task['pages']):
 page=json.loads((A/f'page-{n:02}.json').read_text('utf-8'));cs={c['key']:(c,g) for g in page['post_groups'] for c in g['comments']}
 decisions=read(A/f'page-{n:02}.audit.jsonl');assert len(decisions)==len(cs) and {r['review_key'] for r in decisions}==set(cs)
 assert len({r['review_key'] for r in decisions})==len(decisions)
 for audit in decisions:
  key=audit['review_key'];c,g=cs[key];old=primary[key]
  for f,value in c['first_semantic_judgment'].items():assert old[f]==value,(key,'primary first judgment mismatch',f)
  initial_match+=1
  assert audit['decision'] in ('keep','change') and audit['reason'].strip()
  assert set(audit['patch'])<=allowed
  if audit['decision']=='keep':assert audit['patch']=={}
  else:assert audit['patch']
  row=copy.deepcopy(old);row.update(copy.deepcopy(audit['patch']))
  for f in ('review_key','platform','video_id','comment_id','customer_uid'):assert row[f]==old[f]
  assert row['human_confirmed'] is False and row['send_authorized'] is False and row['store_assignment'] is None
  assert row['reply_plan']['preferred_mother_slot'] in (None,1,2,7,13,16,19,25,28,31,34)
  if row['role']=='unknown':assert row['interest']=='uncertain'
  if any(f in audit['patch'] for f in ('role','interest')):assert 'reply_plan' in audit['patch'],(key,'missing linked plan')
  texts=[c['text']]+([g['post_body']] if c['same_author'] else [])
  extracted=list(row['evidence'])+[t['quote'] for f in ('topics','target_regions','time_mentions','other_constraints','possible_topics','contact_boundaries') for t in row[f] if isinstance(t,dict) and 'quote' in t]
  for q in extracted:
   assert isinstance(q,str) and any(q in t for t in texts),(key,q,texts)
   quotes+=1
  selected.append(row)
 all_audit.extend(decisions);page_counts.append(len(decisions))
keys=[r['review_key'] for r in all_audit];assert len(keys)==len(set(keys))==task['records']
assert set(keys)==set(task['expected_review_keys'])
assert len({r['comment_id'] for r in selected})==len(selected)
semantic=P/'isolated-original-plus-patch.jsonl'
semantic.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in selected),'utf-8')
stage=[dict(copy.deepcopy(r),classification_method='ai_independent_semantic_fine_review',classification_stages_completed=['initial_semantic','detailed_semantic','independent_semantic']) for r in selected]
stagepath=P/'isolated-semantic-stages.jsonl';stagepath.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in stage),'utf-8')
digest=sha(stagepath);cache={};validated=[]
for r in stage:
 r=copy.deepcopy(r);r['classification_review_source']={'path':str(stagepath),'sha256':digest}
 mother_adapter.validate_new_review(r,B,cache);validated.append(r)
preflight=P/'isolated-adapter-preflight.jsonl';preflight.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in validated),'utf-8')
assert sha(pathlib.Path(mother_adapter.__file__))==adapter_sha
for src in task['primary_sources']:assert sha(B/src['path'])==src['sha256']
v={'batch':'83816f9ea5dda5b0','part':0,'records':len(keys),'page_counts':page_counts,'explicit_model_decisions':len(all_audit),'decisions':dict(collections.Counter(r['decision'] for r in all_audit)),'review_key_set_equal':True,'comment_id_set_equal':True,'identities_preserved':True,'first_judgment_primary_matches':initial_match,'quotes_exact_checked':quotes,'quotes_exact':True,'primary_sha256':primary_shas,'primary_unchanged':True,'adapter_path':str(pathlib.Path(mother_adapter.__file__)),'adapter_sha256':adapter_sha,'adapter_unchanged':True,'formal_adapter_preflight_passed':len(validated),'isolated_semantic_sha256':sha(semantic),'isolated_stage_source_sha256':digest,'preflight_sha256':sha(preflight),'page_audit_sha256':{f'page-{n:02}.audit.jsonl':sha(A/f'page-{n:02}.audit.jsonl') for n in range(task['pages'])},'cross_context_conflicts':{'新都有吗':{'D2095':'keep demand/active_at_comment/medium; explicit location inquiry under existing-home sharing, rentable object and actual search progress unconfirmed; not majority vote'},'真的吗':{'D1125':'keep unknown/unknown/uncertain','D1129':'change to unknown/unknown/uncertain; identical bare authenticity question has no personal rental action; timestamps do not establish different intent'},'龙泉有吗':'no assigned key in part-0; diagnosis read, no other-part mutation'},'unresolved_conflicts_in_assigned_keys':[],'unknowns_remain_unknown':True,'usage':'unknown','credits_authorized':True,'platform_calls':0,'send_attempts':0,'human_gold':False,'send_authorized':False,'formal_compiler_binding_pending':True,'verified_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'passed':True}
(P/'validation.json').write_text(json.dumps(v,ensure_ascii=False,indent=2),'utf-8')
(P/'progress.json').write_text(json.dumps({'status':'complete_wait_coordinator_merge','completed_pages':list(range(task['pages'])),'reviewed_count':len(keys),'changes':v['decisions'].get('change',0),'formal_adapter_preflight_passed':len(validated),'usage':'unknown','verified_at':v['verified_at']},ensure_ascii=False,indent=2),'utf-8')
(P/'report.md').write_text(f'''# 抖音独立语义复核

批次83816f9ea5dda5b0，本代理仅认领part-0。15页1752条已逐条阅读共享正文、本人评论和完整first_semantic_judgment，以无损去重复显示降低重复文本；每个key由模型显式keep/change，辅助程序只展开模型列出的键、合并补丁和核验，未以关键词代判或为未读项默认补keep。

保留{v['decisions'].get('keep',0)}条，修订{v['decisions'].get('change',0)}条。重点修订包括：城市迁移时间不冒充入住；孤立拼音/疑似错字与真实性短询保留未知；购房需求者与租赁用途分开；生活短询、受骗后未明状态和报价问题保留机会；环境品质不重复误放户型池；保障申请不误作看房联系；供给电梯条件、独卫备选作用范围、明确预算上限和价格否定保留。没有编写回复正文或发送。

同上下文核心冲突：本片D2095“新都有吗”独立判断保留当时需求、中等兴趣；现租分享中的具体可租对象与推进仍待核。D1125和D1129均为同帖裸“真的吗”，仅真实性短询不足建立本人求租，前者保留未知，后者改未知；发表时间不同不证明意向不同。龙泉组无本片key，已读诊断，不改他片。不以多数或字符串代判，未把旧批案例当金标。

15页ID集合分别完全相等，跨页无重复遗漏，1752条与task键集合相等；评论ID与原primary一一保留。全部页面原判断逐字段与primary匹配。逐字引文{quotes}处全部通过本人评论或确定同作者正文校验。primary三个SHA均与task一致且前后未变。真实隔离文件为原判断+patch，不以删字段或mock替代；加独立复核阶段后绑定实际隔离SHA，实际调用未修改的mother_adapter.validate_new_review，全1752条通过。正式compiler绑定仍由协调者执行。

完整SHA和计数见validation.json，各页审计位于recall-audit/part-0。语义隔离源SHA256：{sha(semantic)}。阶段隔离源SHA256：{digest}。适配器SHA256：{adapter_sha}。

allow仅表示文本无明确联系限制，不是发送许可；所有human_confirmed=false、send_authorized=false、store_assignment=null。没有访问平台、源库、账号、凭据或发送；没有修改primary、adapter、其他part或全局状态。现有credits已授权，实际usage未知。独立模型复核不是人工金标或准确率保证。
''','utf-8')
print(json.dumps({k:v[k] for k in ('records','decisions','quotes_exact_checked','formal_adapter_preflight_passed','isolated_semantic_sha256','isolated_stage_source_sha256','adapter_sha256','passed')},ensure_ascii=False,indent=2))
