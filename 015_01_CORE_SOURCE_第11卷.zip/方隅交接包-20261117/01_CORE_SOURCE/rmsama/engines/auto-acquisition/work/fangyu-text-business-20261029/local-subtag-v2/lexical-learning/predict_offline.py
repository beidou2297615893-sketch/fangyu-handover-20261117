import argparse,json
from pathlib import Path
import joblib
p=argparse.ArgumentParser(); p.add_argument('--input',type=Path,required=True); p.add_argument('--output',type=Path,required=True); a=p.parse_args(); h=Path(__file__).resolve().parent
if a.input.resolve()==a.output.resolve(): raise ValueError('Output must differ from input')
model=joblib.load(h/'model.joblib')
with a.input.open(encoding='utf-8-sig') as f,a.output.open('w',encoding='utf-8') as out:
 for line in f:
  if not line.strip(): continue
  r=json.loads(line); text=r.get('comment_text') or ''; context=r.get('post_body') or ''; q=float(model.predict_proba([text[:500]+'\n原帖：'+context[:300]])[0,1]); decision='positive' if q>=.95 else 'negative' if q<=.05 else 'needs_ai'
  out.write(json.dumps({'comment_id':r.get('comment_id'),'probability_demand':q,'candidate_decision':decision,'production_enabled':False,'send_authorized':False,'original_interest':r.get('interest_at_comment'),'warning':'未校准历史AI拟合概率；仅供离线审查'},ensure_ascii=False)+'\n')
