import json,pathlib,sys
sys.stdout.reconfigure(encoding='utf-8')
B=pathlib.Path(__file__).resolve().parents[1]
page=int(sys.argv[1]); start=int(sys.argv[2]); stop=int(sys.argv[3])
d=json.loads((B/f'recall-audit/part-0/page-{page:02}.json').read_text(encoding='utf-8'))
n=0
for g in d['post_groups']:
    visible=[(i,c) for i,c in enumerate(g['comments'],n) if start<=i<stop]
    n+=len(g['comments'])
    if not visible:continue
    print('POST',g['video'],json.dumps(g['post_body'],ensure_ascii=False))
    for i,c in visible:
        a={k:v for k,v in c.items() if k not in ('audit_selection','first_semantic_judgment')}
        print(i,json.dumps(a,ensure_ascii=False,separators=(',',':')))
        print('J',json.dumps(c['first_semantic_judgment'],ensure_ascii=False,separators=(',',':')))
