import json,pathlib,copy,datetime
B=pathlib.Path(__file__).resolve().parents[1]
OUT=pathlib.Path(__file__).resolve().parent
ALL={}
PAGE={}
for p in range(4):
 d=json.loads((B/f'recall-audit/part-0/page-{p:02}.json').read_text(encoding='utf-8'))
 PAGE[p]=[]
 for g in d['post_groups']:
  for c in g['comments']:
   c=copy.deepcopy(c);c['body']=g['post_body'];ALL[c['key']]=c;PAGE[p].append(c['key'])
DEC={}
def keep(keys,reason):
 for k in keys.split():
  assert k in ALL and k not in DEC,k
  DEC[k]={'review_key':k,'decision':'keep','reason':reason,'patch':{}}
def change(k,audit_reason,**patch):
 assert k in ALL and k not in DEC,k
 DEC[k]={'review_key':k,'decision':'change','reason':audit_reason,'patch':patch}
def j(k):return copy.deepcopy(ALL[k]['first_semantic_judgment'])
def no_plan():return {'preferred_mother_slot':None,'generic_intro_suitable':False,'tone':'normal','missing_facts':[],'caution':['先核实本人住宅租赁意愿及询问对象，不强行推介'],'contact_policy':'allow'}
def save(p):
 assert set(PAGE[p])<=set(DEC),(p,set(PAGE[p])-set(DEC))
 rows=[DEC[k] for k in PAGE[p]]
 (B/f'recall-audit/part-0/page-{p:02}.audit.jsonl').write_text(''.join(json.dumps(x,ensure_ascii=False,separators=(',',':'))+'\n' for x in rows),encoding='utf-8')
 (OUT/f'page-{p:02}.progress.json').write_text(json.dumps({'page':p,'status':'semantic_read_and_explicit_decisions_saved','records':len(rows),'keep':sum(r['decision']=='keep' for r in rows),'change':sum(r['decision']=='change' for r in rows),'read_scope':'共享完整正文、每条评论、发表时间、same_author、parent及first_semantic_judgment','validation':'pending','human_confirmed':False,'send_authorized':False,'usage':'unknown'},ensure_ascii=False,indent=2),encoding='utf-8')

keep('D0001 D0003 D0210 D0212 D0030 D0130 D0311 D0315 D0042 D0044 D0046 D0048 D0050 D0052 D0054 D0058 D0170 D0172 D0174 D0176 D0178 D0180 D0186 D0188 D0340 D0342 D0344 D0060 D0064 D0066 D0080 D0083 D0224 D0226 D0231 D0261 D0135 D0294','逐条核对为吐槽、评价、识别、建议、感叹或有语义的互动；没有本人找房行动，不借作者条件建需求，原无推介计划合理。')
keep('D0016 D0242','同作者房源互动或明确推荐其他公寓，供给角色无另找房证据；原不出求租推介合理。')
keep('D0056','本人报告现居郊区两室4500；已分清现居事实，未当新房预算和目标，无新行动保持原判。')
keep('D0035 D0138 D0182 D0184 D0346 D0348 D0070 D0236 D0328 D0320','逐条核对为用途不明的地名/金额/艾特、泛短询或可能单租车位；原保留具体未知、未强建住宅需求，计划留核合理。')
keep('D0011 D0013 D0214 D0219 D0026 D0133 D0299 D0302 D0305 D0307 D0309 D0313 D0140 D0145 D0147 D0350 D0068 D0074 D0076 D0239 D0092 D0101 D0104 D0250 D0252 D0259 D0112 D0114 D0120 D0122 D0126 D0270 D0273 D0277 D0151 D0157 D0322 D0338 D0198 D0205 D0208 D0263 D0286 D0288 D0290 D0292 D0296','逐条核对本人直接询租、具体条件或可租房源下询价房态；当前找房与未来入住分开，未挪用正文条件，原高兴趣和候选母句可保留，事实缺口仍待核。')
keep('D0028 D0032 D0143 D0078 D0087 D0228 D0244 D0256 D0116','逐条核对为住房关注、价格核实或玩笑短询，原中兴趣或米数歧义保留合理，未升超高或当确定预算，原计划缺口保留。')
keep('D0124 D0265 D0283 D0191','明确现在签合同、即时看房、今天或明天看房；超高为评论时推进强度，未冒称已预约成交，原时点锚定与母句对接缺口保留。')
change('D0085','原帖仅泛居住展示，双询租金位置可保留住房关注，但不足认定明确可租房源下高意向。',interest='medium',reason='本人问价格和位置；泛居住展示未明确可租房源，保留中等住房关注，推进程度另核。',needs_review=['原帖所询对象是否为现实可租住宅、本人是否正找房','评论后的需求及目标地区、承接门店待核'])
for k in ('D0072','D0222'):
 change(k,'只询租住性质或酒店属性，不能由此确认已开始找房；保留中等关注，动作状态改未知。',demand_state='unknown',reason='本人仅核询所示房屋性质，存在住房关注，但是否本人正在找房尚不明确。',needs_review=['是否本人正在找住宅、所询是否可租或酒店短住','评论后意愿、目标地区及承接门店待核'])
a=j('D0062');plan=a['reply_plan'];plan['preferred_mother_slot']=7;plan['missing_facts']+=['所询房源实际面积；价格仅为引用线索，不是本人预算或已接受租金']
change('D0062','问题只询面积，一万一是所指房源的价格线索，不能重复记为本人询价；改用面积户型候选并保留事实缺口。',topics=[a['topics'][1]],reply_plan=plan,reason='本人询一万一所指房源的面积；未问租金也未承诺本人预算，保留面积关注。')
a=j('D0267');a['topics']=[{'pool':'价格预算','quote':'真实几开头','polarity':'ask','subject':'own_demand','condition_scope':'出租房源2500语境中核询真实价格档位，不等于接受预算'}]
change('D0267','可租房源正文标2500，本人问真实几开头是在核询实际价格档位；补回价格关注，不抬高原中兴趣。',topics=a['topics'],reason='本人在标价2500的出租房源下核询真实价格档位；保留中兴趣，不当本人预算或确认成交。',needs_review=['实际租金及全部必付费用、评论后是否仍找房、目标门店待核'])
a=j('D0200');a['time_mentions'][0]['time_role']='other';a['time_mentions'][0]['verification']='按发表时点解释为2026年6月行程；是否入住或看房未明确，实际安排及现时有效性待核'
change('D0200','下个月去明确是行程，不能直接当已确认入住；仍保留当前招中介和6-8k预算。',time_mentions=a['time_mentions'])
change('D0275','4000立马签的条件性签约时间应单独保留，不当租期或确定入住。',time_mentions=[{'quote':'立马签','time_role':'other','anchor_source':'本人评论可信发表时间','anchor_time':ALL['D0275']['published_at'],'normalized':None,'verification':'4000条件下即时签约意愿；未确认签约、入住或今日仍有效'}])
change('D0318','到期搬离经历帖下单字价可能问旧租价，尚不确认本人当时正找房，改未知并先留核。',role='unknown',demand_state='unknown',interest='uncertain',topics=[{'pool':'价格预算','quote':'价','polarity':'ask','subject':'unresolved','condition_scope':None}],reason='到期搬离经历帖仅问价，历史租价或现实询租对象未明。',needs_review=['问历史租价还是本人现实找房；房源是否重新可租'],reply_plan=no_plan())
plan=j('D0325')['reply_plan'];plan['missing_facts']+=['所询同一房源真实月租及全部必付项；不能把月计价当总租期']
change('D0325','本人完整说多少米一个月，在明确出租公寓语境中一个月已将米限定为月租价，不宜只凭米字机械保留面积歧义；补确定询价，不推预算或总租期。',demand_state='active_at_comment',interest='high',topics=[{'pool':'价格预算','quote':'多少米一个月','polarity':'ask','subject':'own_demand','condition_scope':'按月询租价，未说明总租期或可接受预算'}],possible_topics=[],reason='可租公寓下问多少米一个月，完整句表达月租询价，未提出面积问题或总租期。',needs_review=['真实月租及全部必付费用、当前是否仍找房及可承接地区门店待核'],reply_plan=plan)
save(0)

keep('D0352 D0499 D0505 D0507 D0679 D0681 D0683 D0687 D0691 D0796 D0798 D0800 D0547 D0739 D0750 D0753 D0445 D0449 D0588 D0650 D0719 D0777','逐条核对为评价、估价、成本感叹、生活建议或表情互动；没有本人住宅求租行动，原判讨论且不推介合理。')
keep('D0501 D0503 D0685 D0689 D0395 D0407 D0554 D0563 D0731 D0571 D0745 D0629 D0631 D0635 D0619 D0497','逐条核对为纯艾特、泛短询、注册用途、供需不明或办公询价；原保留具体未知及不推介计划合理，不把未知硬判无关。')
keep('D0378 D0433 D0435 D0442 D0447 D0627 D0495 D0586 D0590 D0592 D0594 D0596 D0598 D0600 D0602','逐条核对明确供给、个人转租、现有房招室友或同作者办公推广；没有确定另找住宅动作，未把供给条件当本人新房要求，原不推介合理。')
keep('D0367 D0370 D0512 D0523 D0525 D0694 D0708 D0375 D0380 D0384 D0535 D0538 D0403 D0412 D0556 D0734 D0737 D0414 D0419 D0423 D0566 D0580 D0758 D0437 D0440 D0624 D0633 D0761 D0767 D0770 D0772 D0451 D0454 D0612 D0476 D0480 D0482 D0488 D0491 D0639 D0643 D0654 D0658 D0660 D0663 D0667','逐条核对为明确地点户型预算要求、指定区域房源请求、月租询问或出租帖询盘；原高兴趣有本人语义支持，未来入住未误作未来才找，原候选母句事实缺口保留。')
keep('D0397 D0399 D0405 D0549 D0552 D0558 D0723 D0726 D0729 D0583 D0463 D0472 D0493 D0793 D0775','逐条核对为泛短询、价格核实、米数或捡漏语义；原中等关注与具体待核保留合理，没有无证推高或补造预算。')
keep('D0604','提出明天能看房，有明确相对日期请求；原超高并不等于预约成功，发表时点和对接缺口保留。')
keep('D0485','明确以后需要才联系，目前仅关注，原future及低兴趣合理，不当现在正在租房。')
change('D0721','泛居住展示帖双询视频房间位置价格，尚不足确认是可租房源；从高改中保留关注。',interest='medium',reason='本人核询视频所示房间价格和位置；是否现实可租及本人正在租房另核，保留中等关注。',needs_review=['原帖所询房间是否为可租住宅、本人是否正在找房','评论后需求及可承接地区、门店待核'])
a=j('D0401');plan=a['reply_plan'];plan['preferred_mother_slot']=1;plan['missing_facts']=['当前是否仍找房、目标地区与可承接门店','账号真实住户及介绍资格、优惠门店时效及适用条件','同一房源真实月租、全部必付项与所述九月入住时段可用性；租住时长另问']
change('D0401','九月住是入住时间，未给总时长，不适合直接用这个租期可以住；改认可通用介绍候选并保留月价和入住事实缺口。',reply_plan=plan)
change('D0468','仅问真实吗不能确认已开始找房；保留中等房源真实性关注，动作状态改未知。',demand_state='unknown',reason='本人仅问房源信息真实性；保留中等关注，是否正在住宅租赁推进未明。',needs_review=['本人是否实际找房、质疑对象是报价还是房源事实','当前意愿、地区及门店待核'])
a=j('D0764');ts=a['topics'];rs=a['target_regions']
for t in ts:t['polarity']='unknown';t['subject']='unresolved';t['condition_scope']='套一、套二供需方向及是否可选未明'
for r in rs:r['relation']='unresolved';r['condition_scope']='供给所在区域或本人目标地区未明'
change('D0764','中介感想帖下仅报金牛区套一套二，没有问句或本人找房动作，可能供给也可能求租；保留未知并同步清除推介计划。',role='unknown',demand_state='unknown',interest='uncertain',topics=ts,target_regions=rs,reason='仅报地区与两种户型，供需方向及本人找房动作均不明确。',needs_review=['本人在求租还是提供金牛区房源','套一套二是备选需求还是供给户型清单'],reply_plan=no_plan())
save(1)

keep('D0802 D0804 D0982 D0984 D0992 D1147 D1151 D1153 D1155 D1157 D0826 D0828 D0832 D0834 D0852 D1024 D0874 D0877 D0879 D0881 D0883 D0885 D0887 D0889 D0914 D1072 D1098 D1102 D0945 D0947 D0951 D0953 D0955 D0959 D1115 D1075 D1081 D1085 D1087 D1091 D1180','逐条核对为现居、装修、价格/成本感叹、政策社保咨询、工作或表情互动；未提出本人新住宅求租，不借作者条件建立需求，原无推介合理。')
keep('D0830','本人表达未来买房愿望，原已区分购房与住宅租赁，不推介租房合理。')
keep('D0986 D0988 D0990 D0994 D1149 D1159 D0836 D0839 D1017 D1019 D1022 D0864 D0891 D0893 D0895 D0897 D0899 D0901 D0903 D0905 D1079 D1089','逐条核对纯艾特、空文、裸数字、泛位置价格短询或邀友旅行，原保留未知和具体歧义合理，未误报确定无关或强推介。')
keep('D0806 D0812 D0818 D0823 D1002 D1015 D1165 D1171 D1175 D0850 D1034 D0859 D1037 D1046 D0911 D0921 D0923 D1057 D1061 D1063 D0928 D0931 D0937 D0941 D1100 D1108 D1111 D0961 D1117 D1120 D1122 D1124 D0972 D0977 D1144 D1093','逐条核对为本人具体询租、价格房态、多人租住、指定区域户型或租期请求，原高兴趣符合评论时动作；条件、否定范围、地理与入住时间保留，候选母句仍须核同一房源事实。')
keep('D0843 D0846 D1026 D1029 D1032 D1039 D0919 D1068 D0933 D0949 D0957 D0964 D1077 D1083','逐条核对为泛居住展示短询、费用真实性、价格周期或米数关注，原中等关注及具体歧义合理；月计价未当总租期，不升高确定推进。')
keep('D0867 D0926','本人明确马上或当晚看房，后者以700为前提；原超高是条件性推进而非预约成功，时间锚定及对接事实缺口保留。')
keep('D1059 D1066','本人明确急转租、请求代出租，供给事实充分，没有本人另找房动作；原不把供给水费、时点、户型当自己需求。')
a=j('D0917');regions=a['target_regions']
for r in regions:r['group_relation']='AND';r['condition_scope']='同一供给房源描述：青羊区、四号线西南财大以及七号线金沙博物馆；300米具体量距另核'
change('D0917','本人用以及并列两条地铁配套，不是两个目标区域任选；供给地区关系由OR改为共同描述，不变成自己需求。',target_regions=regions)
change('D1132','当前本人只有多少米，没有让我死心；去除初判理由夹带的其他评论语境，原米数候选及中等关注保留。',reason='本人在可租房源下只问多少米，指标可能是租金或面积，保留中等关注并待澄清，不补本人预算。')
save(2)

keep('D1218 D1239 D1241 D1243 D1245 D1249 D1251 D1253 D1255 D1257 D1259 D1267 D1273 D1281 D1323 D1326 D1365 D1369 D1371 D1375 D1379 D1402','逐条核对为价格评价、生活家具、买房/租房观念、邀友或有语义的感叹，无本人当前住宅租赁推进，原不推荐计划合理。')
keep('D1247','现居小房子限制汽车模拟器使用是当前生活经历，原current_home及非新找房判断合理，未擅建新房硬条件。')
keep('D1263 D1265 D1269 D1275 D1283 D1291 D1304 D1359 D1367 D1377 D1415','逐条核对为语义弱的感叹邀友、短询、艾特、dd或裸楼层，原保留具体未知、不当确定需求或全面拒联，计划留核合理。')
keep('D1184 D1186 D1189 D1206 D1226 D1271 D1279 D1289 D1302 D1315 D1328 D1330 D1333 D1337 D1339 D1342 D1345 D1349 D1382 D1399 D1405 D1407 D1410 D1412 D1418 D1420','逐条核对为本人直接求租、指定户型区域预算、可租房源下询盘、月租或看房请求；原高兴趣有依据，多条件、通勤参照、停车与时间角色保留，候选母句仍须核实。')
keep('D1192 D1202 D1209 D1211 D1215 D1261 D1277 D1297 D1312 D1354','逐条核对为蹲候、玩笑询价、生活展示短询、邀友合住或搬出愿望，原保留中等关注及具体待核合理，不无证确认当前成交或预算。')
keep('D1295 D1394','本人直接询签或明确明天看房，原强推进信号合理；可租性、认真意图和预约仍待核，不能以生活分享标题抹除本人签约行动。')
keep('D1300 D1321 D1373','明确转租、自己已有房招室友或房东尚未租出，为供给；原已分清供给条件、非本人另找房，不推介合理。')
change('D1213','泛居住展示正文下仅问价格位置，缺少明确可租对象及额外推进，改中兴趣保留关注，不借泛标题确认高意向。',interest='medium',reason='本人问价格位置，属于住房关注；原帖只泛居住展示，是否可租及本人现实找房待核。',needs_review=['原帖所询是否现实可租住宅、本人是否正在找房','评论后意愿、目标地区及承接门店待核'])
plan=j('D1200')['reply_plan'];plan['preferred_mother_slot']=None;plan['missing_facts']=['本人住宅租赁还是酒店住宿用途','能否依法开具本人所需酒店发票、实际开票主体及项目','目标地区、租住时长及原帖所询对象是否可承接'];plan['caution']=['槽25仅谈水电，不能代替酒店发票答复；用途和开票事实未清前留核','allow只表示无文本拒联，不等于发送许可']
change('D1200','询酒店发票与水电母句不匹配，原通用介绍已不适合；候选留空并写明用途和发票事实缺口。',reply_plan=plan)
plan=j('D1285')['reply_plan'];plan['missing_facts']+=['原帖是否真实可租、本人是否认真订房；定金金额、收款主体、合同退还条件及同一房源事实'];plan['caution']+=['未发生或确认定金支付，不能冒称订房成功；不因生活分享标题直接认定玩笑']
change('D1285','马上给你转定金是本人明确即时订房推进，不能仅因生活分享标题压成玩笑中等；改强意向但保留真实性与未支付边界。',demand_state='active_at_comment',interest='super_high',reason='本人明确表示马上转定金，按评论时即时订房推进判断；是否认真、所指房源可租及实际支付均未确认。',needs_review=['本人认真订房意愿、原帖是否确有可租房源','定金金额、真实收款主体、合同及退还条件','评论后需求、目标地区与承接门店待核'],reply_plan=plan)
change('D1293','本人主动索要房主联系已在推进租房，不仅是生活展示欣赏；改高但未到预约或签约超高。',interest='high',reason='本人询房主在否并索要联系，租房分享语境下有主动联络推进；未提出明确约时或签约。',needs_review=['原帖房主联系方式与房源可租性、本人现时意愿','目标地区及可承接门店待核'])
plan=j('D1306')['reply_plan'];plan['preferred_mother_slot']=None;plan['generic_intro_suitable']=False;plan['missing_facts']=['对方仅接受个人房东：实际联系主体身份是否符合，不以住户介绍冒充房东','同一房源是否无中介费、水电由租户自己交及实际计费条件','目标地区、预算、入住安排及现时需求'];plan['caution']=['身份限制及费用条件联立；不扩大为拒绝所有联系','现有住户口气母句不能直接充当个人房东身份答复']
change('D1306','原身份限制判断正确，但住户水电母句不解决仅个人房东的联立要求，暂留母句空并明确实际缺口。',reply_plan=plan)
save(3)
