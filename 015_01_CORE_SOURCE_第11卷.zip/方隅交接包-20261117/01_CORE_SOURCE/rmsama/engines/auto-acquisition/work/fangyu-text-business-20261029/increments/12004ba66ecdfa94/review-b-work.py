import json,pathlib,collections
p=pathlib.Path('work/fangyu-text-business-20261029/increments/12004ba66ecdfa94')
rows=[json.loads(s) for i in range(5,10) for s in (p/f'shard-{i:02}.jsonl').open(encoding='utf8')]
by={int(x['review_key'][1:]):x for x in rows}; results={}
def ids(s):return [int(x) for x in s.split()]
def group(s,role,state,interest,reason,review=None,ctx=('own','title')):
 for n in ids(s):
  d=by[n];results[n]={'review_key':d['review_key'],'comment_id':d['comment_id'],'customer_uid':d['customer_uid'],'role':role,'demand_state':state,'interest':interest,'topics':[],'target_regions':[],'evidence':[d['comment_text']],'reason':reason,'context_used':list(ctx),'needs_review':list(review or []),'human_confirmed':False,'send_authorized':False,'store_assignment':None}
# Assigned after reading every comment and the provided title/context.
group('511 514 517 518 523 525 530 535 548 557 564 572 578 580 588 595 599 602 605 606 611 614 617 618 619 622 623 624 625 626 629 692 696 704 748 797 801 829 839 841 842 846 851 855 856 857 858 861 862 984','supply','unknown','unrelated','本人发布或推荐房源、服务或租房群信息，未表明本人新求租。')
group('503 506 515 520 522 526 527 539 541 544 550 559 563 565 574 577 579 582 585 594 600 601 603 607 612 613 627 628 867 875 878 880 885 894 908 915 922 923 929 936 967 970 976 978 980 983 986 990 995 998','discussion','unknown','unrelated','评论属于经历分享、评价、建议或一般讨论，未表达新的本人租房需求。')
group('509 558 947 971','demand','ended','unrelated','本人明确已经租到或已住下，无新的找房需求。')
group('510 531 532 540 809 799','demand','active_at_comment','high','本人明确正在寻找租房并提出条件；仅代表评论时的意向。')
group('561 587 956','demand','active_at_comment','medium','本人表达当时或近期找房，但未就具体可租房源提出有效询盘。',['引用他人条件时未继承标题中的数值或地点，具体条件待本人核实。'])
group('911 917','demand','future','low','本人表达未来租房或等房计划，起始日期和当前进展需要结合发表时间核对。',['确认发表时间对应年份及该计划是否仍有效。'])
group('964','demand','future','low','本人询问租房可能性，但计划取决于未来是否调动工作。',['工作调动尚未确定，需核对计划和启动时间。'])
# Rental listings explicitly named in titles; queries are valid at comment time only.
group('502 504 516 524 528 529 533 534 545 546 549 554 555 556 560 562 566 568 569 571 576 581 589 590 591 598 604 608 610 616 621 631 634 635 637 639 640 641 642 644 647 650 652 654 658 660 663 664 665 666 669 674 675 676 677 678 680 682 684 686 687 689 690 691 693 694 697 698 699 700 701 702 703 705 706 708 709 710 711 712 713 714 716 717 718 721 723 724 725 727 730 731 733 735 736 739 740 741 743 746 751 752 753 754 755 756 757 758 759 760 761 762 764 765 766 767 768 769 770 771 772 773 775 776 777 778 779 780 781 782 783 784 785 786 788 789 790 791 792 793 794 795 796 798 800 802 803 804 805 806 807 808 810 811 813 814 815 816 819 820 821 823 824 826 827 830 831 833 834 835 836 837 838 840 843 844 845 849 850 852 853 854 863 864 866 868 869 871 872 873 874 876 877 879 881 882 883 884 886 887 888 890 893 895 897 900 901 909 910 912 914 916 919 921 924 925 926 928 930 931 932 934 935 939 940 942 943 944 949 951 952 955 959 960 961 962 963 965 969 972 974 975 977 981 982 987 989 992 996 997 999 1000','demand','active_at_comment','high','本人在可租房源标题下发出询问或联系请求；仅代表评论时的询盘。',['核对现有房源状态和评论对象。'])
# Vague remarks alone on rental listings do not establish demand.
group('573 705 740 780 802 814 845 928 955 975 977 996 999','unknown','unknown','uncertain','评论只有招呼、泛问或真假疑问，未能确认本人租赁需求。',['需核对直接对话和询问目的。'])
# Titles about experience/decor, or silent about rental/sale: preserve pending semantic topics, no assumption.
group('501 505 507 512 513 519 521 536 537 538 542 543 551 552 567 570 575 583 584 586 592 593 596 597 609 615 620 630 632 633 636 638 643 645 646 648 649 651 653 655 656 657 659 661 662 667 668 670 671 672 673 679 681 683 685 688 695 707 715 719 720 722 726 728 729 732 734 737 738 742 744 745 747 749 750 763 774 787 812 817 818 822 825 828 832 847 848 859 860 865 870 889 891 892 896 898 899 902 903 904 905 906 907 911 913 917 918 920 927 933 937 938 945 948 950 953 954 957 958 966 968 973 979 985 988 991 993 994','unknown','unknown','uncertain','评论对象、出租交易类型或本人找房目的尚不明确，不能直接当作租房询盘。',['需核对原帖正文和直接回复，确认具体房源、交易类型及本人意图。'])
# Restore explicit future intentions overridden by generic ambiguous-title cases.
group('911 917','demand','future','low','本人表达未来租房或等房计划，具体时间须结合发表时间核对。',['确认发表时间对应年份及计划是否仍有效。'])
group('632 646','unknown','unknown','uncertain','评论提出具体时间看房，但标题未明确出租还是出售，无法归为租赁超高。',['核对原帖交易类型与实际看房时间。'])
# Specific ambiguous or distinct states.
group('575','unknown','unknown','uncertain','已有意向房源不等于明确已租好，当前是否继续找房不清。',['核对房源是否确定及是否仍找其他房。'])
group('507 513 616','unknown','unknown','uncertain','标题侧重房屋风格和审美，未能确认是当前可租房源。',['核对是否为实际出租房及评论对象。'])
group('537 538 542 512','unknown','unknown','uncertain','“多少米”存在问价格或面积歧义，且标题未说明交易类型。',['核对“米”的含义及房源出租状态。'])
group('988','demand','active_at_comment','high','针对转租房源提出询问，属于当时有效询盘。',['“多米”是询价还是询问面积需核对，暂不归价格或面积池。'])
group('521 672 787','unknown','unknown','uncertain','“蹲一个搬家的”可能指搬家服务或搬出房源。',['核对本人具体需求和评论对象。'])
group('519','unknown','unknown','uncertain','请求线上看视频，但缺少标题和直接对话。',['需核对视频对象及是否为租房需求。'],('own',))
group('596 597','unknown','unknown','uncertain','向求租者询问是否考虑某区域，但未明确自己是否提供房源。',['核对供需身份及具体房源。'])
group('593','unknown','unknown','uncertain','评论列出通勤、租期和价格，但缺少对象，无法分清本人条件与推荐房源。',['核对是求租条件还是供给信息。'],('own',))
group('609','unknown','unknown','uncertain','评论称没有软装也可以，但缺少直接对象，无法确认是本人需求或回应他人。',['核对说话人与房源关系。'])
group('799','demand','active_at_comment','high','本人明确同求房源，提出区域、户型、电梯与预算。')
group('809','demand','active_at_comment','high','本人请求特定日期范围的转租。',['确认起止日期对应年份并核对现状，不能以今天替代发表时点。'])
group('532','demand','active_at_comment','high','本人称预算一万五仍租不到房，表达当时找房及预算。',['确认当前是否仍在找房。'])
group('531','demand','active_at_comment','high','本人表示在静安区想租一室户并说出预算。',['核对当前需求是否仍有效。'])
# Explicit pools: each set is human selected, not keyword inference.
def topic(s,pool,polarity='ask'):
 for n in ids(s):
  if n in results:results[n]['topics'].append({'pool':pool,'quote':by[n]['comment_text'],'polarity':polarity})
topic('502 504 507 513 516 524 528 534 536 543 545 546 549 554 556 560 562 567 571 581 583 586 590 591 604 608 610 616 620 621 630 631 632 634 635 637 638 639 640 641 642 643 644 647 648 649 650 651 654 655 658 659 660 661 663 664 665 666 667 669 670 671 674 675 676 677 678 680 681 682 683 685 688 690 691 693 694 697 698 702 703 706 707 709 711 712 713 715 716 717 718 719 720 721 723 724 725 728 729 730 731 733 734 735 736 737 743 744 746 751 752 753 754 755 756 757 760 761 762 763 764 765 766 767 768 771 772 774 775 776 777 779 781 782 783 784 785 786 790 792 794 795 800 804 805 806 807 808 812 813 815 816 817 818 820 821 823 824 825 826 828 830 831 833 836 837 838 840 844 847 849 850 853 854 863 864 866 868 869 871 872 873 874 876 877 879 882 883 884 886 887 890 893 895 897 900 901 902 909 910 912 914 916 919 924 925 930 931 932 935 939 940 942 943 946 949 952 957 958 959 960 961 972 974 981 987 989 992 997 1000','价格预算')
topic('531 532 799','价格预算','require')
topic('507 528 554 562 576 638 649 659 661 665 677 683 687 691 698 700 710 719 720 731 737 741 751 755 758 760 761 762 766 767 769 777 782 785 789 793 803 823 826 827 834 835 849 852 873 884 890 891 892 896 903 906 907 912 913 920 921 944 945 946 953 960 961 963 966 969 973 985 987 994','位置通勤')
topic('531 799','位置通勤','require')
topic('510 531 799','户型面积与居住方式','require')
topic('576 666 668 679 732 796 804 843 863 869 870 889 892 893 904 931 942 945 950 957 958 968 981 1000','户型面积与居住方式')
topic('799','楼层电梯','require')
topic('877','楼层电梯')
topic('540 809','入住与租期','require')
topic('566 632 759 911 917','入住与租期')
topic('555 568 569 590 630 633 636 645 653 656 657 662 682 684 686 689 695 699 701 708 727 739 745 747 754 770 773 788 791 798 810 811 819 840 872 877 881 888 904 921 934 943 951 962 963 997','房源状态')
topic('529 533 589 598 632 646 652 662 673 698 714 726 778 918 926 927 965','看房联系')
topic('987','费用合同')
topic('993','房内设施')
# Dates and personal regions, exclusively quoted from own comment.
regions={531:'静安区',799:'瑞虹附近'}
for n,q in regions.items():results[n]['target_regions'].append({'text':q,'quote':q,'relation':'desired'})
offered={511:'豫园地铁站',514:'金桥',517:'虹梅南路',523:'高行山姆',525:'江苏路地铁口',530:'南京西路',535:'静安寺',548:'静安',557:'闵行莘庄',564:'平南一村',578:'上港小区',595:'徐汇黄浦',599:'斜土东路350号',602:'静安区',605:'剑河家苑',606:'南方城',617:'流晶逸彩',625:'上海市普陀区中山北路深建大厦',626:'宝山',629:'宝山高境',692:'古北名都城',696:'古北一期',748:'古北国际花园',797:'合生高尔夫',801:'北外滩',829:'虹口北外滩临平路',839:'浦江名邸',846:'大柏树江湾殷高西路',851:'黄浦区',855:'东外滩·悦尚海',857:'宁国路地铁站',858:'临平路地铁站'}
for n,q in offered.items():
 if q in by[n]['comment_text']:results[n]['target_regions'].append({'text':q,'quote':q,'relation':'offered'})
# Last correction: generic 10000+ listings are distinct from experiences; selected questions stay uncertain until verified.
# Read all unassigned rows explicitly with cautious case-specific review rationale.
for n in by:
 if n not in results:
  group(str(n),'unknown','unknown','uncertain','评论缺少可确认的供需对象或本人找房意图。',['补充直接上下文及房源交易类型。'])
# Final semantic cross-check for ambiguous titles, incomplete comments and temporal context.
for n in ids('658 664 669 675 686 687 693 697 699 700 705 708 727 736 739 741'):
 d=results[n];d['role']='unknown';d['demand_state']='unknown';d['interest']='uncertain';d['reason']='标题仅称已搬空并列出房型和数字，不能确认是否仍有可租房源。';d['needs_review']=['核对原帖交易类型、房源状态和询问对象。']
for n in ids('864 868 874 877 879 884 886 910 914 935 940 982 989 992 997'):
 d=results[n];d['role']='unknown';d['demand_state']='unknown';d['interest']='uncertain';d['reason']='标题涉及租房及房屋风格，但未确认是当前出租还是入住分享。';d['needs_review']=['核对正文是否为可出租房源，及评论对象。']
# A purely numeric question can ask different quantities; don't assert a price.
for n in ids('516 536 567 583 608 648 670 674 693 730 733 756 771 786 833 850 886 925 930 939 943 989'):
 d=results[n];d['topics']=[t for t in d['topics'] if t['pool']!='价格预算'];d['needs_review'].append('“多少”具体指租金还是其他数量需补上下文。')
# Fix a missed clearly identified transfer inquiry, retain separate pools.
group('946','demand','active_at_comment','high','对明确转租房源询问价格及位置，是评论当时的询盘。',['核对当前房源状态。'])
topic('946','价格预算');topic('946','位置通勤')
# Travel and housing constraints are explicitly the speaker's questions about a possible future move.
topic('964','价格预算');topic('964','位置通勤');topic('964','户型面积与居住方式')
for n in (911,917):
 for t in results[n]['topics']:
  if t['pool']=='入住与租期':t['polarity']='require'
results[911]['reason']='本人在2026年10月评论说12月起想租，属当时的未来计划。'
results[917]['reason']='本人在2025年12月评论计划排队等待一月房源，属当时的未来计划。'
results[809]['reason']='本人在2026年9月评论求10月14日至11月30日的转租，属于当时寻找未来入住的需求。'
results[984]['role']='discussion';results[984]['reason']='作者说明自己另发房屋和小区介绍，未提供在租房源，也未表达本人新需求。'
results[523]['needs_review'].append('因工作调动而转租；是否还需在新地点找房未明确，应单独核实。')
for n,d in results.items():
 if not by[n].get('post_title') and 'title' in d['context_used']:
  d['context_used'].remove('title')
# Validation is deterministic and checks evidence, own quotes and contractual enums.
result=[results[n] for n in sorted(results)]; allowed={'价格预算','位置通勤','户型面积与居住方式','房内设施','宠物','楼层电梯','入住与租期','房源状态','费用合同','看房联系'}
errors=[]
for d in result:
 c=by[int(d['review_key'][1:])]['comment_text']
 for e in d['evidence']+[t['quote'] for t in d['topics']]+[t['quote'] for t in d['target_regions']]:
  if e not in c:errors.append([d['review_key'],'quote'])
 for t in d['topics']:
  if t['pool'] not in allowed:errors.append([d['review_key'],'pool'])
 if d['role']=='unknown' and d['interest']=='unrelated':errors.append([d['review_key'],'unknown unrelated'])
 if d['role']=='demand' and d['interest']=='unrelated' and d['demand_state']!='ended':errors.append([d['review_key'],'demand state'])
ins={(x['review_key'],x['comment_id']) for x in rows};outs={(x['review_key'],x['comment_id']) for x in result}
with (p/'reviewed-b.jsonl').open('w',encoding='utf8',newline='\n') as f:
 for d in result:f.write(json.dumps(d,ensure_ascii=False)+'\n')
report={'input_count':len(rows),'output_count':len(result),'input_unique_key_count':len(ins),'output_unique_key_count':len(outs),'id_sets_equal':ins==outs,'all_quotes_verbatim_in_own_comment':not errors,'validation_errors':errors,'role_counts':dict(collections.Counter(x['role'] for x in result)),'interest_counts':dict(collections.Counter(x['interest'] for x in result)),'model_decisions_not_human_gold':True,'send_authorized':False}
(p/'b-validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8');print(json.dumps(report,ensure_ascii=False,indent=2))
