"""Validate model reviews and publish text pools with local consumption receipts."""
import json,hashlib,re,sys,collections
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent/'increments'
run=sys.argv[1] if len(sys.argv)>1 else '032413f79937dc52';D=W/run
priority=W.parent/'文本处理优先顺序.json'
if priority.exists() and json.loads(priority.read_text(encoding='utf8')).get('new_increment_processing_authorized_now') is False and not (D/'completion.json').exists():
 print(json.dumps({'status':'held_for_original_text_review','completed_receipts_added':0,'source_databases_modified':False,'send_authorized':False},ensure_ascii=False));raise SystemExit(0)
def jl(p):return [json.loads(x) for x in p.read_text(encoding='utf8').splitlines() if x.strip()]
src=jl(D/'input.jsonl');bykey={x['review_key']:x for x in src};assert len(src)==len(bykey)
files=[D/f'reviewed-{n}-v2.jsonl' if (D/f'reviewed-{n}-v2.jsonl').exists() else D/f'reviewed-{n}.jsonl' for n in ['a','b','c']];allrows=[]
for p in files:allrows.extend(jl(p))
assert len(allrows)==len(src) and {r['review_key'] for r in allrows}==set(bykey)
assert len({r['comment_id'] for r in allrows})==len(allrows)
pools={'价格预算','位置通勤','户型面积与居住方式','房内设施','宠物','楼层电梯','入住与租期','房源状态','费用合同','看房联系'}
fixes=[]
for r in allrows:
 s=bykey[r['review_key']];assert r['comment_id']==s['comment_id'] and r['customer_uid']==s['customer_uid']
 text=s['comment_text']
 for q in r.get('evidence',[]):assert q and q in text,(r['review_key'],'evidence')
 for t in r['topics']:assert t['pool'] in pools and t['quote'] and t['quote'] in text,(r['review_key'],'topic')
 for t in r['target_regions']:assert t['quote'] and t['quote'] in text and t['text'] in text,(r['review_key'],'region')
 assert r['human_confirmed'] is False and r['send_authorized'] is False and r['store_assignment'] is None
 assert not (r['role']=='unknown' and r['interest']=='unrelated'),r['review_key']
 if run=='032413f79937dc52' and r['review_key']=='I0405':
  fixes.append({'review_key':r['review_key'],'before':r['interest'],'after':'high','reason':'方便看房吗是泛问，未明确约看/时间，不自动超高'})
  r['interest']='high';r['reason']='在出租语境询问看房可行性与民用水电，泛问看房不自动超高。'
 if run=='032413f79937dc52' and r['review_key']=='I0317':
  fixes.append({'review_key':r['review_key'],'before':[r['role'],r['interest']],'after':['mixed','uncertain'],'reason':'保留供给与换房背景，是否仍需求租待核'})
  r['role']='mixed';r['interest']='uncertain';r['demand_state']='unknown';r['reason']='明确转租旧房且说因换房，供给成立；本人新求租是否仍需推进未知，保留两部分不整体删去。';r['needs_review'].append('换房可能是新租、已找到或其他安排，不能从旧房地区推新目标')
 if '多少米' in text and len(text)<25:
  r['possible_topics']=[{'pool':'价格预算','quote':'多少米'},{'pool':'户型面积与居住方式','quote':'多少米'}]
  r['topics']=[t for t in r['topics'] if t['pool'] not in {'价格预算','户型面积与居住方式'}]
  if not any('面积' in z for z in r['needs_review']):r['needs_review'].append('多少米可能指租金或面积，主题需上下文核对')
 r.update(rule_version='business-text-20261029-v1',review_model='gpt-6.1-terra',root_review_model='gpt-6.1-sol',current_need_confirmed=False,
   source_batch=s['batch'],source_input_sha256=s['input_sha256'],source_comment_text_sha256=hashlib.sha256(text.encode()).hexdigest(),
   ip_location=s.get('ip_location'),ip_role='仅平台属地参考，非本人求租地区',source_store=s['collection_store'],target_store=None,
   reply_state='今天不发送；仅文本模型分析，尚未本人核实',context_missing=not bool(s.get('post_text')),
   actual_pools=r['topics'] if r['role'] in {'demand','mixed'} else [],pending_pools=r['topics'] if r['role']=='unknown' else [])
allrows.sort(key=lambda r:r['review_key'])
packed=''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in allrows)
(D/'final-reviewed.jsonl').write_text(packed,encoding='utf8')
(D/'root-corrections.json').write_text(json.dumps(fixes,ensure_ascii=False,indent=2),encoding='utf8')
processed=W/'processed-comments.jsonl';previous=jl(processed) if processed.exists() else []
seen={(z['platform'],z['comment_id'],z['rule_version'],z['source_comment_text_sha256']) for z in previous};add=[]
for r in allrows:
 key=('xiaohongshu',r['comment_id'],r['rule_version'],r['source_comment_text_sha256'])
 if key in seen:continue
 seen.add(key);add.append({'platform':'xiaohongshu','comment_id':r['comment_id'],'customer_uid':r['customer_uid'],'rule_version':r['rule_version'],
 'source_comment_text_sha256':r['source_comment_text_sha256'],'source_batch':r['source_batch'],'input_sha256':r['source_input_sha256'],'run':run,
 'result_sha256':hashlib.sha256(json.dumps(r,ensure_ascii=False,sort_keys=True).encode()).hexdigest(),'status':'model_review_complete_pending_human','send_authorized':False})
with processed.open('a',encoding='utf8') as f:
 for r in add:f.write(json.dumps(r,ensure_ascii=False)+'\n')
batch_numbers=sorted({int(x['batch'].split('-')[-1]) for x in src})
P=ROOT/'outputs/方隅双平台文本业务/新增评论分池'/f'古北登记评论{batch_numbers[0]}至{batch_numbers[-1]}批';P.mkdir(parents=True,exist_ok=True)
def clean(v):
 v=re.sub(r'https?://\S+','[链接已省略]',v or '')
 v=re.sub(r'(?<!\d)1[3-9]\d{9}(?!\d)','[联系方式已省略]',v)
 v=re.sub(r'@[\w\u4e00-\u9fff.]+','[提及账号已省略]',v)
 return v
roles={'demand':'本人求租或房源询盘线索','supply':'提供房源或服务','mixed':'供给及本人换房线索并存','unknown':'身份或需求待核','discussion':'讨论经历或无关'}
levels={'super_high':'评论时超高兴趣线索','high':'评论时高兴趣线索','medium':'评论时中兴趣线索','low':'未来计划，当前低推进','very_low':'本人潜在愿望','uncertain':'待核','unrelated':'供给、无新需求或已结束'}
statuses={'active_at_comment':'当时在推进；今日有效性未确认','future':'未来安排，时间待核','ended':'本人已结束且无新需求','historical':'历史经历','unknown':'当前需求或时态未确认'}
lines=['# 新登记评论的文本分池','',
'本次仅消费登记回执、输入摘要及原账本来源一致的评论。分类是模型初判，尚未本人核实，不是发送名单；采集来源古北不等于这些客户都适合古北。属地只作参考，目标地区以本人原话判断。','']
counts=collections.Counter(r['source_batch'] for r in allrows);roles_count=collections.Counter(r['role'] for r in allrows);topic_count=collections.Counter(t['pool'] for r in allrows for t in r['actual_pools'])
for r in allrows:
 s=bykey[r['review_key']];topic='、'.join(t['pool']+'（'+clean(t['quote'])+'；'+{'ask':'询问','require':'要求','reject':'拒绝','accept':'接受','compare':'比较'}.get(t['polarity'],t['polarity'])+'）' for t in r['actual_pools'])
 pending='、'.join(t['pool'] for t in r['pending_pools'])
 reg='；'.join(clean(t['text'])+'（'+{'desired':'本人目标','excluded':'本人排除','work':'工作地点','current_home':'当前住处','offered':'供应房源地点'}.get(t['relation'],t['relation'])+'）' for t in r['target_regions'])
 lines+=['────────────────','客户原评论：'+clean(s['comment_text']),'帖子标题：'+clean(s.get('post_title') or '未提供'),
 '直接上级：'+clean(s.get('parent_text') or '未提供或不适用'),'身份与需求：'+roles[r['role']],'意向：'+levels[r['interest']],
 '时态：'+statuses[r['demand_state']],'需求池：'+(topic or '未确认本人具体需求池'),'待核主题：'+(pending or ('、'.join(t['pool'] for t in r.get('possible_topics',[])) or '无额外明确线索')),
 '地点原话归属：'+(reg or '本人目标地区未确认'),'平台属地：'+clean(s.get('ip_location') or '缺失，不能猜测'),
 '本次依据：'+clean(r['reason']),'待核：'+('；'.join(clean(z) for z in r['needs_review']) or '还需核今日需求、门店事实与历史回执'),
 '实际门店分配：尚未核实，不按搜索来源分配；本次未发送。','']
(P/'逐条评论与分池.txt').write_text('\n'.join(lines),encoding='utf8')
pl=['# 各需求池索引','', '同一评论可以出现在多个池；此表只包含明确需求或混合线索的主题，待核主题不当作已确认偏好。条数不是人数，也不能相加当客户总量。','']
for topic in sorted(pools):
 pl+=['## '+topic,'']
 selected=[r for r in allrows if any(t['pool']==topic for t in r['actual_pools'])]
 pl += [clean(bykey[r['review_key']]['comment_text'])+'\n判断：'+clean(r['reason'])+'；今日有效性及门店待核。' for r in selected]
 if not selected:pl.append('本批尚无确认的本人该类需求主题。')
 pl.append('')
(P/'各需求池索引.md').write_text('\n\n'.join(pl),encoding='utf8')
raw22=ROOT/'work/xhs-account-switch-recovery-candidate/runtime/resume-new10000-20261029-batch22/batch-0022/partial-0005.json'
overlap=None
if raw22.exists():
 x=json.loads(raw22.read_text(encoding='utf8'));ids={k['comment_id'] for c in x.get('customers',[]) for k in [c,*c.get('other_comments',[])]};overlap=len(ids&{r['comment_id'] for r in allrows})
report={'run':run,'comments':len(allrows),'distinct_customer_uids':len({x['customer_uid'] for x in allrows}),'batches':dict(counts),'roles':dict(roles_count),
 'interest':dict(collections.Counter(r['interest'] for r in allrows)),'topic_comments':dict(topic_count),'multitopic_comments':sum(len({t['pool'] for t in r['actual_pools']})>1 for r in allrows),
 'needs_semantic_review':sum(bool(r['needs_review']) for r in allrows),'new_receipt_records':len(add),'source22_raw_overlap_not_extra':overlap,
 'source_ids_match':True,'verbatim_quotes_checked':True,'rule_version':'business-text-20261029-v1','source_databases_modified':False,'sent':0,'human_confirmed':False,
 'final_output_sha256':hashlib.sha256(packed.encode()).hexdigest()}
(D/'completion.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
summary=['# 本批登记与分池说明','',f'本批已核登记评论{len(allrows)}条，去重平台客户标识{report["distinct_customer_uids"]}个。不是新增可回复人数，同一人可能多条评论。',
 '来源批次：'+'；'.join('第'+str(int(k.split('-')[-1]))+'批 '+str(v)+'条' for k,v in counts.items())+'。',
 '供需初判：'+'；'.join(roles[k]+str(v)+'条' for k,v in roles_count.items())+'。',
 '本文只报告这些已完成文本分析的固定批次，后续新增另记，不把本轮结论当作实时总量。',
 f'第22批部分文件中有{overlap}条评论在本轮正式输入出现，只按正式登记计算一次，部分文件本身不另加。',
 '每条原文、主题及否定方向、本人地点和供应地点、属地、依据及待核原因均保留。缺失不猜；地区和事实不足不强行指派古北。',
 '登记与原文校验通过，语义结果仍为模型初判，尚未本人确认，今天不发送。分类成功不代表客户现在仍在找房或适合该店。','']
(P/'本批说明.md').write_text('\n\n'.join(summary),encoding='utf8')
print(json.dumps(report,ensure_ascii=False))
