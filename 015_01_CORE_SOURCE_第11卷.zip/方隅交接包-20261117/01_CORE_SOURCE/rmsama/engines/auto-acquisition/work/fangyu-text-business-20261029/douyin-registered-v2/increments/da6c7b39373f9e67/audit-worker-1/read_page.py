import json,sys,pathlib,collections
B=pathlib.Path(__file__).resolve().parent.parent
p=int(sys.argv[1]); start=int(sys.argv[2]) if len(sys.argv)>2 else 0; end=int(sys.argv[3]) if len(sys.argv)>3 else 1000
x=json.loads((B/f'recall-audit/part-1/page-{p:02}.json').read_text(encoding='utf-8-sig'))
groups=x['post_groups'][start:end]
counts=collections.Counter()
def count(o):
 if isinstance(o,str) and len(o)>15:counts[o]+=1
 elif isinstance(o,list):
  for v in o:count(v)
 elif isinstance(o,dict):
  for v in o.values():count(v)
for g in groups:
 for c in g['comments']:count(c['first_semantic_judgment'])
strings={s:f'#{i}' for i,(s,n) in enumerate(counts.items()) if n>1}
print('DICTIONARY',json.dumps({v:k for k,v in strings.items()},ensure_ascii=False,separators=(',',':')))
def compress(o,txt):
 if isinstance(o,str):return '@COMMENT' if o==txt else strings.get(o,o)
 if isinstance(o,list):return [compress(v,txt) for v in o]
 if isinstance(o,dict):return {k:compress(v,txt) for k,v in o.items()}
 return o
for i,g in enumerate(groups,start):
 print('\nBODY',i,g['video'],g['post_body'])
 for c in g['comments']:
  j=c['first_semantic_judgment']; cj={}
  for k,v in j.items():
   if v==[]:continue
   if k=='context_used' and v==['own','body']:continue
   if k=='topics':v=[[t[z] for z in ['pool','quote','polarity','subject','condition_scope']] for t in v]
   if k=='target_regions':v=[[t[z] for z in ['text','quote','relation','group_relation','condition_scope']] for t in v]
   if k=='time_mentions':v=[[t[z] for z in ['quote','time_role','anchor_source','anchor_time','normalized','verification']] for t in v]
   if k=='reply_plan':v=[v[z] for z in ['preferred_mother_slot','generic_intro_suitable','tone','missing_facts','caution','contact_policy']]
   cj[{'role':'R','demand_state':'D','interest':'I','reason':'why','topics':'T','target_regions':'G','time_mentions':'TIME','other_constraints':'O','possible_topics':'P','needs_review':'N','contact_boundaries':'B','context_used':'C','reply_plan':'PLAN'}.get(k,k)]=v
  print(c['key'],json.dumps(c['text'],ensure_ascii=False),c['published_at'],('SAME_AUTHOR ' if c['same_author'] else ''),('PARENT='+json.dumps(c['parent'],ensure_ascii=False) if c['parent'] else ''),'CONFLICT' if c['source_conflict'] else '')
  print(json.dumps(compress(cj,c['text']),ensure_ascii=False,separators=(',',':')))
