"""Remove expired comment payloads from this project's text derivatives only."""
import argparse
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import sqlite3
import sys
import time

HERE=Path(__file__).resolve().parent
WORK=HERE.parent
ROOT=WORK.parents[1]
sys.path.insert(0,str(WORK/'recency-priority'))
import retention30 as retention
NOW=time.time()
SOURCE=ROOT/'work/fangyu-douyin-independent/runtime/collection.sqlite3'
source_dates={}
source_fingerprints=set()
existing=set()
def load_context():
    global source_dates,source_fingerprints,existing
    with sqlite3.connect(SOURCE.resolve().as_uri()+'?mode=ro',uri=True) as db:
        source_dates={str(cid):retention.stamp(json.loads(data)) for cid,data in db.execute("SELECT source_id,data FROM entities WHERE kind='comments'")}
        source_fingerprints={row[0] for row in db.execute('SELECT digest FROM expired_comment_fingerprints')}
        if db.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='excluded_comment_fingerprints'").fetchone():
            source_fingerprints.update(row[0] for row in db.execute('SELECT digest FROM excluded_comment_fingerprints'))
    if retention.REGISTRY.exists():existing=set(json.loads(retention.REGISTRY.read_text(encoding='utf-8'))['digests'])
    for path in [WORK/'recency-priority/xiaohongshu-all-pool-business-fit.jsonl']:
        if path.exists():
            for line in path.open(encoding='utf-8-sig'):
                row=json.loads(line)
                if retention.expired(row,'xiaohongshu',NOW):existing.add(retention.fingerprint('xiaohongshu',retention.cid(row)))
    registry_temp=retention.REGISTRY.with_suffix('.tmp')
    registry_temp.write_text(json.dumps({'digests':sorted(existing|source_fingerprints)},separators=(',',':')),encoding='utf-8')
    os.replace(registry_temp,retention.REGISTRY)

DROP=object()
ASSET_PARTS={'mothers','stores','rules','classifier','node_modules','.git'}
LIVE_NAMES={'all-pool-business-fit.jsonl','douyin-replies.jsonl','pending-candidates.jsonl','increment-results.jsonl','local-recheck-results.jsonl','affected-review.jsonl','increment-needs-review.jsonl','retained-business-customers.jsonl'}

def platform_for(path):
    value=str(path).lower()
    if 'xiaohongshu' in value or 'xhs-' in value or 'xhs_' in value:return 'xiaohongshu'
    if 'douyin' in value or 'funnel-audit' in value or 'old-library-audit' in value:return 'douyin'
    return None

def scrub(value, platform, counts):
    if isinstance(value,dict):
        candidate_platform=value.get('platform')
        if candidate_platform in ('douyin','xiaohongshu'):platform=candidate_platform
        comment=retention.cid(value)
        # The source platform timestamp overrides old flattened snapshots.
        if comment and comment in source_dates and platform!='xiaohongshu':
            published=source_dates[comment]
            value=dict(value)
            if published is not None:
                value['published_at_unix']=published
                value['published_at']=datetime.fromtimestamp(published,timezone.utc).isoformat()
        if comment and retention.expired(value,platform,NOW):
            counts['removed']+=1
            if platform:counts['digests'].add(retention.fingerprint(platform,comment))
            return DROP
        result={}
        for key,item in value.items():
            cleaned=scrub(item,platform,counts)
            if cleaned is not DROP:result[key]=cleaned
        return result
    if isinstance(value,list):
        result=[]
        for item in value:
            cleaned=scrub(item,platform,counts)
            if cleaned is not DROP:result.append(cleaned)
        return result
    return value

def candidate(path):
    relative=path.relative_to(WORK)
    if any(part in ASSET_PARTS for part in relative.parts):return False
    if relative.parts[0]=='retention-cleanup-20261106':return False
    if relative.parts[0]=='douyin-semantic-repair-v5' and path.name in LIVE_NAMES:return False
    if path.name.startswith(('fifty-review','approved-mother','mother-library','template-')):return False
    if path.suffix not in ('.jsonl','.json'):return False
    if path.suffix=='.json' and path.stat().st_size>64*1024*1024:return False
    return True

def clean_file(path):
    resolved=path.resolve()
    allowed=resolved.is_relative_to(WORK.resolve()) or resolved.is_relative_to((ROOT/'work/fangyu-douyin-independent/text-classification-snapshots').resolve())
    if not allowed:raise ValueError('path outside intended project text roots')
    before=path.stat()
    counts={'removed':0,'digests':set()}
    temp=path.with_name(path.name+f'.retention-{os.getpid()}.tmp')
    original_digest=hashlib.sha256();new_digest=hashlib.sha256();records=0
    try:
        if path.suffix=='.jsonl':
            with path.open('rb') as src,temp.open('wb') as dest:
                for line in src:
                    original_digest.update(line)
                    if not line.strip():continue
                    cleaned=scrub(json.loads(line),platform_for(path),counts)
                    if cleaned is DROP:continue
                    data=(json.dumps(cleaned,ensure_ascii=False)+'\n').encode()
                    records+=1;dest.write(data);new_digest.update(data)
        else:
            raw=path.read_bytes();original_digest.update(raw)
            value=scrub(json.loads(raw.decode('utf-8-sig')),platform_for(path),counts)
            if value is DROP:value={}
            data=json.dumps(value,ensure_ascii=False,indent=2).encode()
            temp.write_bytes(data);new_digest.update(data)
        if not counts['removed']:
            temp.unlink(missing_ok=True)
            return {'path':str(path),'removed':0,'digests':[]}
        current=path.stat()
        if (before.st_size,before.st_mtime_ns)!=(current.st_size,current.st_mtime_ns):
            temp.unlink(missing_ok=True)
            return {'path':str(path),'removed':0,'deferred':'concurrent_writer','digests':[]}
        for attempt in range(21):
            try:os.replace(temp,path);break
            except PermissionError:
                if attempt==20:raise
                time.sleep(.25)
        return {'path':str(path),'removed':counts['removed'],'old_sha256':original_digest.hexdigest(),'sha256':new_digest.hexdigest(),'records':records,'digests':list(counts['digests'])}
    except (ValueError,json.JSONDecodeError,PermissionError) as error:
        temp.unlink(missing_ok=True)
        return {'path':str(path),'removed':0,'deferred':type(error).__name__,'digests':[]}

def update_pointer_files(changed):
    pairs=[('file','sha256'),('result_file','result_sha256'),('result_file','sha256'),('results_file','results_sha256'),('queue','sha256'),('source','source_sha256'),('output','output_sha256'),('all_pool_file','all_pool_sha256')]
    def visit(value):
        if isinstance(value,dict):
            for key,hash_key in pairs:
                target=value.get(key)
                if isinstance(target,str) and target in changed:
                    value[hash_key]=changed[target]['sha256']
                    if key in ('file','result_file','results_file','queue'):
                        for count_key in ('count','records','snapshot_unique_comments'):
                            if count_key in value:value[count_key]=changed[target]['records']
            for item in value.values():visit(item)
        elif isinstance(value,list):
            for item in value:visit(item)
    files=list(WORK.glob('*指针.json'))+list((ROOT/'work/fangyu-douyin-independent').glob('*summary.json'))+list(WORK.glob('**/current.json'))
    for path in files:
        try:
            value=json.loads(path.read_text(encoding='utf-8-sig'));before=json.dumps(value,ensure_ascii=False,sort_keys=True);visit(value)
            if before!=json.dumps(value,ensure_ascii=False,sort_keys=True):
                temp=path.with_name(path.name+'.retention-pointer.tmp');temp.write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf-8');os.replace(temp,path)
        except (ValueError,PermissionError):continue

if __name__=='__main__':
    load_context()
    paths=[path for path in WORK.rglob('*') if path.is_file() and candidate(path)]
    baseline=ROOT/'work/fangyu-douyin-independent/text-classification-snapshots'
    paths.extend(baseline.glob('*.jsonl'))
    report=[];all_digests=existing|source_fingerprints
    with ThreadPoolExecutor(max_workers=4) as pool:
        for index,result in enumerate(pool.map(clean_file,paths),1):
            all_digests.update(result.pop('digests'));report.append(result)
            if index%25==0:(HERE/'实时进度.txt').write_text(f'清理文本副本：{index}/{len(paths)}\n删除超期记录引用：{sum(row["removed"] for row in report)}\n不操作采集、发送进程。\n',encoding='utf-8')
    retention.REGISTRY.write_text(json.dumps({'digests':sorted(all_digests)},separators=(',',':')),encoding='utf-8')
    changed={row['path']:row for row in report if row['removed']}
    update_pointer_files(changed)
    summary={'checked_files':len(report),'changed_files':len(changed),'removed_record_references':sum(row['removed'] for row in report),'deferred':[row for row in report if row.get('deferred')],'source_database_modified':False,'active_send_batch_modified':False,'rule_assets_untouched':True,'files':report}
    (HERE/'text-cleanup-result.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({key:value for key,value in summary.items() if key!='files'},ensure_ascii=False))
