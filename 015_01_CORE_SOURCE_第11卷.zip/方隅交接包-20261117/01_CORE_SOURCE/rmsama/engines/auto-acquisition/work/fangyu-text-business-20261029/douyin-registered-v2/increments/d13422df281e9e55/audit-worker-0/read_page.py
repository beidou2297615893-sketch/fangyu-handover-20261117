import json,sys,collections
from pathlib import Path
base=Path(__file__).resolve().parent.parent
page=int(sys.argv[1]);start=int(sys.argv[2]) if len(sys.argv)>2 else 0;end=start+40
d=json.loads((base/f"recall-audit/part-0/page-{page:02}.json").read_text(encoding="utf8"))
def j(x):return json.dumps(x,ensure_ascii=False,separators=(",",":"))
selected=[];i=0
for g in d["post_groups"]:
 for c in g["comments"]:
  if start<=i<end:selected.append((g,c))
  i+=1
counts=collections.Counter()
def count(x):
 if isinstance(x,str):counts[x]+=1
 elif isinstance(x,dict):
  for v in x.values():count(v)
 elif isinstance(x,list):
  for v in x:count(v)
for _,c in selected:count(c["first_semantic_judgment"])
strings={s:f"§{n}" for n,s in enumerate((s for s,c in counts.items() if c>1 and len(s)>18),1)}
def conv(x):
 if isinstance(x,str):return strings.get(x,x)
 if isinstance(x,list):return [conv(v) for v in x]
 if isinstance(x,dict):return {k:conv(v) for k,v in x.items()}
 return x
print("Judgment tuple: role,state,interest,reason. Omitted lists=[]; T=[pool,quote,polarity,subject,scope]; R=[text,quote,relation,group,scope]; P=[slot,generic,tone,missing,caution,policy]; X=[same_author,published_at,parent,conflict], defaults false,null,null,false except timestamp always. N=needs_review; U=context_used; C=constraints; A=possible; B=boundaries; F=context_flags; E=evidence. All body printed for each group.")
for s,ref in strings.items():print(ref+"="+s)
last=None
for g,c in selected:
 if g["video"]!=last:print("POST "+g["video"]+" "+j(g["post_body"]));last=g["video"]
 a=c['first_semantic_judgment'];b={"J":[a[k] for k in ('role','demand_state','interest','reason')]}
 for src,dst in [('topics','T'),('target_regions','R'),('time_mentions','time')]:
  if a.get(src):b[dst]=[list(v.values()) for v in a[src]]
 for src,dst in [('other_constraints','C'),('possible_topics','A'),('needs_review','N'),('context_used','U'),('contact_boundaries','B'),('context_flags','F'),('evidence','E')]:
  if a.get(src):b[dst]=a[src]
 b['P']=list(a['reply_plan'].values())
 extra={k:v for k,v in c.items() if k not in ('key','text','first_semantic_judgment','audit_selection','reply_to')}
 print(c['key']+' '+j(c['text'])+' X='+j(list(extra.values()))+' '+j(conv(b)))
