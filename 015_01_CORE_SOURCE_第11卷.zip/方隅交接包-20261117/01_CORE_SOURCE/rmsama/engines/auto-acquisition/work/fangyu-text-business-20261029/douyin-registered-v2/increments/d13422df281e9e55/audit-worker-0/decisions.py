import json,copy
from pathlib import Path
base=Path(__file__).resolve().parent.parent
assigned={}
for p in (base/'recall-audit/part-0').glob('page-*.json'):
 for g in json.loads(p.read_text(encoding='utf8'))['post_groups']:
  for c in g['comments']:assigned[c['key']]=(p,c,g)
changes={};keeps={}
def keep(keys,reason):
 for k in keys.split():
  assert k not in keeps and k not in changes,k
  keeps[k]=reason
def change(k,reason,patch):
 assert k not in keeps and k not in changes,k
 changes[k]={'review_key':k,'decision':'change','reason':reason,'patch':patch}
def orig(k):return copy.deepcopy(assigned[k][1]['first_semantic_judgment'])
def neutral(k,reason):
 a=orig(k);p=a['reply_plan'];p.update(preferred_mother_slot=None,generic_intro_suitable=False,missing_facts=[],caution=['先核本人实际找房动作，不据短语主动推介'])
 return dict(role='unknown',demand_state='unknown',interest='uncertain',reason=reason,needs_review=[reason],reply_plan=p)
def flush(page):
 p=base/f'recall-audit/part-0/page-{page:02}.json'
 keys=[c['key'] for g in json.loads(p.read_text(encoding='utf8'))['post_groups'] for c in g['comments']]
 assert all(k in keeps or k in changes for k in keys),[k for k in keys if k not in keeps and k not in changes]
 rows=[changes[k] if k in changes else dict(review_key=k,decision='keep',reason=keeps[k],patch={}) for k in keys]
 p.with_suffix('.audit.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows),encoding='utf8')
 (base/'audit-worker-0/progress.json').write_text(json.dumps({'pages_written':page+1,'explicit_decisions':len(keeps)+len(changes),'changes':len(changes),'credits':'existing_authorized','actual_usage':'unknown'},ensure_ascii=False,indent=2),encoding='utf8')

keep('D0001 D0003 D0005 D0007 D0009 D0011 D0014 D0017 D0020 D0256 D0258 D0260 D0262 D0264 D0267 D0269 D0271 D0273 D0029 D0033 D0040 D0276 D0281 D0285 D0287 D0291 D0044 D0047 D0054 D0295 D0300 D0302 D0304 D0307 D0057 D0059 D0061','逐条核对本人原文与共享正文，询租、猜测、供需及工作地分开，原等级和母句事实缺口可保留。')
a=orig('D0042');a['topics'][2]['polarity']='prefer'
change('D0042','3000左右为近似预算偏好，不能写成刚性要求。',{'topics':a['topics']})
a=orig('D0050');a['topics'][0]['subject']='unresolved'
change('D0050','中介介绍的房屋不证明本人现居；费用仍属经历，未表达新求租。',{'topics':a['topics'],'reason':'叙述中介曾介绍的自建房费用，是否入住未明，不当本人现居或新房条件。'})
a=orig('D0297');a['topics']=a['topics'][:2]
change('D0297','女生是自述身份，未提出合租对象或居住方式要求，不单独计入户型池。',{'topics':a['topics']})
keep('D0064 D0067 D0069 D0071 D0073 D0075 D0077 D0079 D0081 D0083 D0085 D0087 D0089 D0309 D0311 D0313 D0091 D0093 D0095 D0097 D0099 D0101 D0103 D0105 D0108 D0110 D0317 D0319 D0321 D0323 D0325 D0327 D0329 D0331 D0333 D0112 D0114 D0116 D0118','已逐条核正文、本人短询及互动；青旅用途、相对时间、纯艾特与泛向往的未知保留，未借作者条件。')
change('D0315','中古风是本人装修风格偏好，十池外约束需另存，合住仍保留。',{'other_constraints':[{'quote':'我想要那个中古风的','detail':'本人对住房中古装修风格的偏好；实际求租推进仍待核。'}]})
keep('D0120 D0123 D0125 D0129 D0335 D0131 D0134 D0136 D0140 D0143 D0145 D0151 D0153 D0156 D0159 D0161 D0163 D0165 D0168 D0172 D0175 D0185 D0196 D0198 D0200 D0202 D0204 D0206 D0208 D0210 D0212 D0214 D0230 D0235 D0241 D0243 D0250 D0254','已逐条核房态、签约条件、反讽、联系身份边界及时间锚；原判断与候选母句事实缺口可保留。')
change('D0170','仅说嘉定，未明确询房或本人找房；保留地点候选，不直接认定当前推进。',neutral('D0170','仅报嘉定，可能询房或补充信息，实际求租动作和所指待核。'))
a=orig('D0248');a['topics'][0]['subject']='unresolved';a['target_regions'][0]['relation']='unresolved'
change('D0248','我在这里只表本人当时位置，不证明现住房；仍保留核实房态的求租动作。',{'topics':a['topics'],'target_regions':a['target_regions'],'needs_review':a['needs_review']+['梅陇镇政府为当时所在地，是否现居或目标区域未明。']})
flush(0)

keep('D0337 D0341 D0346 D0349 D0352 D0355 D0357 D0359 D0361 D0514 D0516 D0519 D0521 D0523 D0363 D0367 D0372 D0378 D0382 D0591 D0595 D0600 D0386 D0388 D0391 D0393 D0396 D0398 D0402 D0404 D0406 D0410 D0412 D0414 D0608 D0610','逐条复核可租与实住语境，明确求租保留，签约推进、供给、价格质疑与不完整召唤分开。')
a=orig('D0375');z=neutral('D0375','仅报南通砂之船附近，询房、工作地或补充位置均未明确。');a['topics'][0]['subject']='unresolved';z['topics']=a['topics'];change('D0375','裸地点不足以认定当前找房，保留待核位置。',z)
change('D0380','只有真假质疑，没有询租动作或具体问题；不据此主动推介。',neutral('D0380','房源语境下问这是真的吗，实际找房及疑问对象仍待核。'))
a=orig('D0400');a['topics'][0]['polarity']='prefer';change('D0400','一千左右是近似预算，不设刚性金额。',{'topics':a['topics']})
a=orig('D0408');[t.update(subject='unresolved') for t in a['topics']];a['target_regions'][0]['relation']='unresolved';change('D0408','报道虹口房价面积未明示本人现居，不推作现住条件。',{'topics':a['topics'],'target_regions':a['target_regions']})
keep('D0612 D0616 D0618 D0620 D0622 D0626 D0416 D0421 D0424 D0429 D0434 D0629 D0436 D0438 D0440 D0442 D0444 D0446 D0450 D0452 D0631 D0633 D0635 D0637 D0639 D0641 D0645 D0455 D0458 D0460 D0462 D0464 D0467 D0469 D0471 D0473 D0475','逐条核本人住房动作及政策住宿用途，供给与未知保留；米数歧义、未来条件和月租模式未强归一。')
a=orig('D0614');a['topics'][0]['subject']='unresolved';a['target_regions'][0]['relation']='unresolved';change('D0614','上海酒店为过往经历，不能记成评论时现居或今日已结束需求。',{'demand_state':'historical','topics':a['topics'],'target_regions':a['target_regions'],'reason':'回忆过去上海找房未果后住酒店；无当前新需求表述。'})
a=orig('D0624');[t.update(subject='unresolved') for t in a['topics']];a['target_regions'][0]['relation']='unresolved';change('D0624','过去工作时住处不等于评论时现居，保留历史说明。',{'topics':a['topics'],'target_regions':a['target_regions']})
a=orig('D0426');a['topics'][0]['quote']='特别特别小的一个单间都2千';a['topics'][0]['polarity']='fact';a['topics'].append({'pool':'价格预算','quote':'这个得4千➕吧','polarity':'compare','subject':'unresolved','condition_scope':None});change('D0426','视频房估价与本人现居单间价格应分主体保存。',{'topics':a['topics']})
keep('D0482 D0487 D0494 D0496 D0498 D0501 D0503 D0505 D0507 D0509 D0511 D0526 D0528 D0531 D0533 D0535 D0537 D0539 D0541 D0543 D0547 D0550 D0552 D0556 D0558 D0560 D0562 D0564 D0566 D0568 D0570 D0576 D0580 D0582 D0605','逐条核多项联立条件、否定合租、工作地与现居；经历、建议、互动和供给未当新租要求，源冲突保留。')
a=orig('D0545');a['topics'][0]['subject']='unresolved';a['target_regions'][0]['relation']='unresolved';change('D0545','看过的下沙房不等于入住，不能标为现居。',{'topics':a['topics'],'target_regions':a['target_regions']})
change('D0554','艾特说我俩去未说明去看房还是一般向往，不直接认定找房。',neutral('D0554','向朋友说我俩去，目的及租房推进不明，保留关注待核。'))
a=orig('D0572');a['topics'][0]['polarity']='prefer';change('D0572','600左右保留弹性，不能标成绝对硬预算。',{'topics':a['topics']})
a=orig('D0578');a['target_regions'][0]['relation']='unresolved';change('D0578','本人近期看房不等于现居；保留不满意后的续找机会待核，不绝对过滤。',{'interest':'low','topics':[{'pool':'位置通勤','quote':'瓜山社区没便宜的吧','polarity':'compare','subject':'unresolved','condition_scope':None}],'target_regions':a['target_regions'],'reason':'回忆瓜山看房拥挤气味及价格；当前是否仍找房未明。','needs_review':['本人看房后是否继续求租、目标区域和环境要求需核；看过不等于入住。']})
a=orig('D0584');a['topics'][0]['subject']='unresolved';change('D0584','我们这边为区域报价比较，未证明本人现居费用；乱码保留。',{'topics':a['topics'],'needs_review':a['needs_review']+['原评论含乱码，区域价格比较不能据此认定本人房租或目标预算。']})
flush(1)

keep('D0650 D0653 D0655 D0657 D0660 D0662 D0664 D0666 D0856 D0858 D0860 D0863 D0865 D0868 D0870 D0872 D0874 D0668 D0673 D0882 D0884 D0886 D0888 D0892 D0894 D0687 D0691 D0693 D0896 D0899 D0901 D0903 D0905 D0697 D0699 D0701 D0703','逐条核主体与正文，明确需求、月计价、工作地、短租与地标猜测分开；母句只为待核候选。')
for k in ['D0647','D0695']:
 a=orig(k);a['topics'][0]['subject']='unresolved';z=neutral(k,'核对博主展示住房地名，未明确本人实际租房动作。');z['topics']=a['topics'];change(k,'辨识展示房所在地不足以认定本人当前找房并主动推介。',z)
a=orig('D0689');a['topics'][2]['quote']='整租';a['topics'][2]['condition_scope']='整租且面积30平左右，面积为近似偏好';a['topics'].append({'pool':'户型面积与居住方式','quote':'30平左右','polarity':'prefer','subject':'own_demand','condition_scope':'整租且面积30平左右'});change('D0689','整租为明确要求，30平左右为弹性面积，拆开方向。',{'topics':a['topics']})
keep('D0705 D0707 D0709 D0711 D0713 D0922 D0924 D0926 D0928 D0930 D0932 D0934 D0936 D0938 D0940 D0715 D0717 D0719 D0721 D0723 D0725 D0727 D0729 D0731 D0733 D0942 D0948 D0950 D0952 D0737 D0739 D0741 D0743 D0745 D0747 D0749 D0751','已逐条核本人评论与共享正文；通勤经验和建议不当新需求，向往及纯艾特保留未知或低优先，实际看房保留高意向。')
change('D0944','走吧未说明租房行动，不能仅凭艾特邀约认定在推进。',neutral('D0944','向同伴说走吧，是否看房、旅行或玩笑未明。'))
a=orig('D0946');change('D0946','单问多少指标未给，价格及面积仅可作候选。',{'topics':[],'possible_topics':[{'quote':'多少','candidate_pools':['价格预算','户型面积与居住方式'],'ambiguity':'生活分享下单问多少，价格、面积或其他指标不明。'}],'needs_review':a['needs_review']+['先核多少的指标，不建立确定价格池。']})
a=orig('D0735');[t.update(subject='unresolved') for t in a['topics']];a['target_regions'][0]['relation']='unresolved';change('D0735','当年住过的房子为历史经历，不当当前现居。',{'topics':a['topics'],'target_regions':a['target_regions']})
keep('D0754 D0757 D0763 D0765 D0907 D0909 D0912 D0915 D0917 D0919 D0770 D0777 D0780 D0786 D0788 D0790 D0792 D0794 D0796 D0799 D0801 D0803 D0805 D0810 D0822 D0824 D0826 D0828 D0831 D0833 D0835 D0837 D0839 D0841 D0846 D0850 D0852 D0854','逐条核可租条件、供给、OR地区与供需身份；转租和推荐未借作本人需求，实住帖短询及米数歧义保留待核。')
change('D0782','仅真实性质疑未明实际找房，不直接认定推进及推介。',neutral('D0782','房源语境下问真的假的，实际找房或单纯质疑未明。'))
a=orig('D0820');a['topics'][0]['subject']='own_demand';a['topics'][0]['condition_scope']='询出售价格，非租赁预算';change('D0820','明确询购房应保留需求者身份，但不计确定住宅租赁意向。',{'role':'demand','demand_state':'active_at_comment','topics':a['topics'],'other_constraints':[{'quote':'如果卖呢？多少钱','detail':'本人询出售价格，属于购房用途；是否另有租赁需求未表述。'}],'needs_review':['询购房，商业公寓租赁承接意愿未明。']})
flush(2)

keep('D0954 D0956 D0958 D0960 D1130 D1132 D1134 D1136 D1138 D1140 D1142 D1144 D1146 D1148 D0962 D0964 D0970 D0972 D0974 D0976 D1150 D1152 D1154 D1157 D1159 D1161 D1163 D1165 D1167 D0987 D0990 D0994 D0998 D1187 D1200','逐条核正文和原评论；互动、现居抱怨、政策住宿、供给及实际求租分开，联系身份边界和条件性搬入均保留。')
a=orig('D0966');p1=orig('D0101')['reply_plan'];change('D0966','我找的都是直接描述本人找房及价格受挫，不能凭空加曾字抹掉找房线索。',{'role':'demand','demand_state':'active_at_comment','interest':'medium','reason':'本人描述在钱塘找房遇到1400起价，保留当时找房线索；不是接受1400预算。','needs_review':['是否仍继续找、可接受真实预算及钱塘是否目标地区需核；评论时找房不代表今日仍有效。'],'reply_plan':p1})
a=orig('D0968');a['target_regions'][0]['relation']='preferred';change('D0968','本人明确要靠近市中心，属于位置偏好而非无法辨认的地区。',{'target_regions':a['target_regions']})
a=orig('D0978');[t.update(subject='unresolved') for t in a['topics']];a['target_regions'][0]['relation']='unresolved';change('D0978','十年前住处不能标评论时现居，历史时间仍保留。',{'topics':a['topics'],'target_regions':a['target_regions']})
a=orig('D0980');a['topics'][2]['polarity']='prefer';a['topics'][1]['condition_scope']='独住方案为一室一卫；另接受找室友方案，不将一室要求套到所有方案。';change('D0980','800左右为弹性预算，独住及找室友是可选方案，保持条件作用范围。',{'topics':a['topics']})
a=orig('D1195');a['target_regions'][0]['relation']='unresolved';change('D1195','离秦禾不远是当时本人位置，不证明现居，不当目标地。',{'target_regions':a['target_regions']})
keep('D1205 D1001 D1003 D1005 D1007 D1009 D1011 D1013 D1015 D1020 D1028 D1034 D1036 D1230 D1233 D1239 D1242 D1040 D1042 D1044 D1046 D1048 D1050 D1052 D1054 D1244 D1246 D1248 D1250 D1252 D1254 D1256 D1258 D1260 D1067 D1079 D1082 D1085','逐条核出租、服务式公寓用途与体验正文；泛联系不推超高，短多少留候选，供给和他人建议不借作本人条件。')
a=orig('D1059');p1=orig('D0101')['reply_plan'];p1['caution'].append('我要租为强烈求租表达，未明确约时、订房或签约。');change('D1059','我要租是明确高兴趣，缺具体预约订房签约行为，不直接超高。',{'interest':'high','reason':'明确想租，未见具体预约、订房或签约请求。','reply_plan':p1})
a=orig('D1076');z=neutral('D1076','辨认展示房是否小米公寓，未表本人实际求租。');a['topics'][0]['subject']='unresolved';z['topics']=a['topics'];change('D1076','辨认公寓品牌不足以认定实际找房及主动推介。',z)
keep('D1088 D1094 D1263 D1265 D1268 D1271 D1274 D1096 D1098 D1102 D1104 D1108 D1110 D1112 D1114 D1116 D1118 D1120 D1122 D1124 D1126 D1128 D1169 D1171 D1178 D1180 D1182 D1184 D1207 D1209 D1212 D1214 D1218 D1220 D1222','逐条核多条件与否定合租；月价和租期分开，供给招室友及博主地标猜测未当本人新需求，体验短询保留待核。')
change('D1100','仅永丰南这边，未形成明确询房句，不认定当前推进。',neutral('D1100','仅提永丰南这边，工作地、目标地或补充攻略信息不明。'))
for k,idx in [('D1106',1),('D1176',1)]:
 a=orig(k);a['topics'][idx]['polarity']='prefer';change(k,'左右价格为弹性预算，不当绝对硬要求。',{'topics':a['topics']})
change('D1174','明确不租了属于搬离线索，供给身份保留，另找需求不能静默丢掉。',{'needs_review':['本人正转出租处并说不租了；搬离后是否另找、是否离开当地及时间需核，不据此编造新求租。']})
change('D1216','通勤短询可能为住房关注或问博主经历，不能确定无关或认定本人通勤目标。',neutral('D1216','询位置对应通勤耗时，是否本人求租及通勤终点未知。'))
flush(3)

keep('D1277 D1280 D1448 D1450 D1453 D1456 D1458 D1461 D1463 D1292 D1294 D1296 D1298 D1300 D1468 D1472 D1475 D1302 D1304 D1306 D1308 D1312 D1314 D1316 D1528 D1530 D1532 D1534 D1536 D1538 D1542 D1318 D1320 D1322 D1324 D1326','已逐条核主体、多项联立、供给、购房用途与当前求租；工作点、月价、短租时长和纯艾特均保留准确角色。')
a=orig('D1283');a['topics']=a['topics'][:1];change('D1283','周末是看房时间，不额外计入住租期池；看房时段和超高推进保留。',{'topics':a['topics']})
a=orig('D1290');a['topics'][1]['polarity']='prefer';change('D1290','2k左右不是刚性上限。',{'topics':a['topics']})
a=orig('D1470');a['topics'][0]['polarity']='prefer';change('D1470','通勤半小时左右为弹性偏好，不写死硬限时长。',{'topics':a['topics']})
a=orig('D1310');z=neutral('D1310','艾特让朋友问问这个，未明确本人代求租或朋友真实住房需求。');a['topics'][0]['subject']='unresolved';z['topics']=a['topics'];change('D1310','问问这个可能推荐中介，不能直接当本人或主动代亲友求租。',z)
keep('D1328 D1330 D1332 D1334 D1336 D1489 D1491 D1493 D1495 D1497 D1499 D1501 D1503 D1505 D1507 D1338 D1340 D1342 D1345 D1347 D1349 D1351 D1353 D1355 D1509 D1511 D1513 D1518 D1520 D1357 D1360 D1373 D1549 D1557 D1560 D1378','逐条核全部艾特与短询，实际找房多条件不被泛正文压低；明天看房时间以北京时间核对，房东渠道边界保留待核。')
a=orig('D1516');a['topics'].pop(1);change('D1516','环境好不是房内设施，保留为十池外约束，避免重复错分池。',{'topics':a['topics']})
a=orig('D1522');a['topics'].pop(1);change('D1522','独厨卫能做饭属于设施，不等于整租或一人居住，不补居住方式池。',{'topics':a['topics']})
a=orig('D1526');a['topics'][1]['polarity']='prefer';change('D1526','1100左右保留预算弹性。',{'topics':a['topics']})
a=orig('D1382');a['time_mentions'][0]['normalized']=None;a['time_mentions'][0]['verification']='询按年租方案价格；未承诺总租期恰好一年。';change('D1382','询年租方案不等于总入住时长恰好一年，保留原词不强归一。',{'time_mentions':a['time_mentions']})
keep('D1398 D1405 D1407 D1409 D1411 D1413 D1415 D1417 D1419 D1421 D1423 D1604 D1606 D1428 D1430 D1432 D1434 D1436 D1438 D1440 D1442 D1477 D1479 D1481 D1483 D1487 D1566 D1569 D1571 D1573 D1575 D1577 D1579 D1581 D1585 D1588 D1592 D1596','逐条核评论、空文与正文；理想住房、历史猫梗故事保留未知，真实询租、反感看房经历和设施否定保持原义。')
a=orig('D1485');a['topics'][0]['subject']='unresolved';change('D1485','实习时租房通勤是历史经历，不标评论时现居。',{'topics':a['topics']})
a=orig('D1564');a['target_regions'][0]['relation']='unresolved';change('D1564','上半年租过未说明目前仍住，不认定现居地区。',{'target_regions':a['target_regions']})
flush(4)

keep('D1608 D1610 D1612 D1614 D1616 D1618 D1620 D1803 D1805 D1807 D1809 D1811 D1813 D1815 D1817 D1819 D1622 D1630 D1632 D1636 D1840 D1843 D1846 D1848 D1643 D1645 D1647 D1649 D1652 D1654 D1656 D1659 D1860 D1862 D1865 D1868 D1871','逐条核正文、求租推进与他人建议；今天看房及这间我租保留超高但未当成交，半年与短租不当未来才找。')
a=orig('D1626');a['target_regions'][0]['relation']='unresolved';a['target_regions'][1]['relation']='unresolved';change('D1626','我在所述街道一带不证明现住，最好附近是明确偏好并单列。',{'target_regions':a['target_regions']})
change('D1634','单问真的吗不足认定当前找房并主动推介。',neutral('D1634','出租语境下真呢吗为真实性疑问，实际求租动作未明。'))
p1=orig('D0101')['reply_plan'];p1['caution'].append('我要表达想要住房，不等于已预约、已订房或签约。');change('D1855','我要缺具体订房动作，不直接超高。',{'interest':'high','reason':'出租语境表达想要住房，未给预约、订房或签约行动。','reply_plan':p1})
keep('D1874 D1877 D1661 D1663 D1665 D1667 D1671 D1673 D1675 D1677 D1679 D1880 D1882 D1884 D1886 D1681 D1683 D1685 D1888 D1890 D1687 D1693 D1695 D1697 D1699 D1701 D1703 D1705 D1707 D1709 D1711 D1713 D1715 D1717 D1719 D1721','逐条核通勤攻略、多条件及本人找房；刚租好保留结束，招合租供需未知不强判高，实际求租及供给各自保留。')
for k,idx in [('D1892',1),('D1689',2)]:
 a=orig(k);a['topics'][idx]['polarity']='prefer';change(k,'左右租金保留近似预算弹性。',{'topics':a['topics']})
a=orig('D1894');[r.update(relation='unresolved') for r in a['target_regions']];change('D1894','对象方庄、我在五道口未直说工作地，不借上下文补两人的单位位置。',{'target_regions':a['target_regions'],'reason':'两人分别在方庄与五道口，求可养狗整租一居3500至4000，便宜更好；地点角色待核。','needs_review':a['needs_review']+['方庄和五道口是工作地、现居地还是其他活动点未明，不预定通勤事实。']})
change('D1691','裸锦江区不足认定当前找房或推介。',neutral('D1691','中介语境仅提锦江区，询房、建议或补充地点未明。'))
keep('D1723 D1725 D1727 D1729 D1731 D1733 D1735 D1739 D1741 D1750 D1752 D1756 D1758 D1763 D1765 D1767 D1770 D1772 D1774 D1778 D1780 D1783 D1785 D1788 D1790 D1794 D1797 D1801 D1821 D1823 D1827 D1832 D1834 D1836 D1838','逐条核本人原文与上下文；报价比较、他人遭遇和明确新需求分开，签租、一般联系及时间角色未混同。')
a=orig('D1737');a['reply_plan']['generic_intro_suitable']=False;a['reply_plan']['caution'].append('先核已有房招室友还是组团找房，不直接当确定房源询租。');change('D1737','问有没有人合租有行动但供需未明，不直接高意向。',{'interest':'medium','reason':'滨江区政府附近寻合租伙伴，有无现房及是否需另找待核。','needs_review':a['needs_review']+['确认已有房招室友还是与同伴共同另找住房。'],'reply_plan':a['reply_plan']})
a=orig('D1776');a['time_mentions'][0]['time_role']='other';change('D1776','开始沪漂为行程或迁移时间，未确定入住日。',{'time_mentions':a['time_mentions']})
p1=orig('D0810')['reply_plan'];change('D1792','明确可租视频下询多少米有住房询盘线索，指标未知不抹掉询租。',{'role':'demand','demand_state':'active_at_comment','interest':'medium','reason':'明确出租公寓下询视频房多少米，保留询盘；金额或面积未明。','needs_review':['先澄清米的指标、实际所询房型及本人当前是否仍找房。'],'reply_plan':p1})
for k in ['D1825','D1829']:
 a=orig(k);a['topics'].pop(1);change(k,'稍微好一点是笼统品质偏好，未给户型或房内设施要求。',{'topics':a['topics'],'other_constraints':a.get('other_constraints',[])+[{'quote':'稍微好一点','detail':'希望住房整体品质稍好，具体装修、面积或设施标准待核，不扩写硬条件。'}]})
flush(5)

keep('D1896 D1898 D1900 D1902 D1904 D1906 D1908 D1910 D1912 D1914 D1916 D1918 D1920 D1925 D1927 D1929 D1931 D1933 D1935 D1937 D1939 D1941 D1943 D1945 D1947 D1949 D1954 D1960 D1970 D1972 D1974 D1976 D1978 D1980 D1982 D1984 D1986 D1988 D1991','逐条完整核正文、本人评论与初判；纯艾特保持未知，实际求租、原房东边界、工作地与AND/OR条件保留。')
a=orig('D1922');a['time_mentions'][0]['time_role']='other';p1=orig('D1922')['reply_plan'];p1.update(preferred_mother_slot=None,generic_intro_suitable=False,missing_facts=[],caution=['以后到杭州再租的关注意愿；当前是否找房需核，不强推本地推介。']);change('D1922','关注并说到杭州租未证明当前推进，也未明确未来才开始找房；时间角色保留待核。',{'demand_state':'unknown','interest':'low','reason':'收藏关注后表示到杭州租，属于条件性未来居住意愿，当前找房动作未明。','time_mentions':a['time_mentions'],'needs_review':['是否已经来杭州、何时开始找房及现在是否愿意推进尚未明确。'],'reply_plan':p1})
keep('D1996 D2000 D2006 D2011 D2013 D2017 D2019 D2021 D2023 D2025 D2027 D2029 D2038 D2040 D2044 D2050 D2055 D2058 D2060 D2063 D2067 D2070 D2072 D2074','逐条核本人原文、共享正文与时间；明天看房按北京时间锚定，@多少钱不当问价；条件预算不合并，供需及泛互动分开。')
a=orig('D1993');a['reply_plan']['missing_facts'].append('同一门店同一可租一房的国外护照接待与住宿登记要求、长租时长和有效报价待核。');change('D1993','国外护照是联立承接条件，加入实际母句适配事实缺口。',{'reply_plan':a['reply_plan']})
p1=orig('D0810')['reply_plan'];change('D2002','明确可租公寓下多少米仍有询盘，歧义保留而非抹去需求线索。',{'role':'demand','demand_state':'active_at_comment','interest':'medium','reason':'明确可租公寓下询多少米，保留住房询盘；金额或面积未明。','needs_review':['需澄清米的指标、视频房型及本人实际需求，不作为确定价格或面积统计。'],'reply_plan':p1})
a=orig('D2015');[t.update(subject='unresolved') for t in a['topics']];a['target_regions'][0]['relation']='unresolved';change('D2015','去年租过不证明现居，保留历史报价而非本人当前条件。',{'topics':a['topics'],'target_regions':a['target_regions']})
a=orig('D2053');p1=orig('D0101')['reply_plan'];p1['caution'].append('询房态并表达我要，未提出明确订房手续或签约预约，不写成已订。');change('D2053','有没有啊我要是求租与房态询问，缺具体订房或签约推进，不直接超高。',{'interest':'high','reason':'问有没有并表达想租，未给具体预约、订房手续或签约动作。','reply_plan':p1})
flush(6)
