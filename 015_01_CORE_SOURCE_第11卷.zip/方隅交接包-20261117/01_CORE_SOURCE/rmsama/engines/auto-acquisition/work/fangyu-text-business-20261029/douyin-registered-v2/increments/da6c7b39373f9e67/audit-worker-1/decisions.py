import json,pathlib,copy,datetime
B=pathlib.Path(__file__).resolve().parent.parent
P=B/'recall-audit/part-1'
def load(p):
 x=json.loads((P/f'page-{p:02}.json').read_text(encoding='utf-8-sig'))
 return {c['key']:(g,c) for g in x['post_groups'] for c in g['comments']}
def topic(pool,q,pol='ask',sub='own_demand',scope=None):
 return dict(pool=pool,quote=q,polarity=pol,subject=sub,condition_scope=scope)
def nullplan(caution,policy='allow',tone='normal'):
 return dict(preferred_mother_slot=None,generic_intro_suitable=False,tone=tone,missing_facts=[],caution=[caution],contact_policy=policy)
def save(p,keep,changes):
 source=load(p); out={}
 for keys,reason in keep:
  for k in keys.split():
   assert k in source and k not in out
   out[k]=dict(review_key=k,decision='keep',reason=reason,patch={})
 for k,(why,patch) in changes.items():
  assert k in source and k not in out
  out[k]=dict(review_key=k,decision='change',reason=why,patch=patch)
 assert set(out)==set(source),(set(source)-set(out),set(out)-set(source))
 dest=P/f'page-{p:02}.audit.jsonl'
 dest.write_text(''.join(json.dumps(out[k],ensure_ascii=False,separators=(',',':'))+'\n' for k in source),encoding='utf-8')
 progress=dict(completed_page=p,records=len(out),changes=len(changes),at=datetime.datetime.now().astimezone().isoformat(),status='page_written_not_finally_validated')
 (B/'audit-worker-1/progress.json').write_text(json.dumps(progress,ensure_ascii=False,indent=2),encoding='utf-8')
 print(dest.name,len(out),len(changes))

def page0():
 s=load(0); ch={}
 def update(k,why,**patch): ch[k]=(why,patch)
 for k in 'D0063 D0084 D0240 D0264 D0321'.split():
  update(k,'泛生活、已签或搬离语境中表达关注，未明确现实找房动作；保留原有中等兴趣和问题，不将关注写成已推进。',demand_state='unknown',needs_review=s[k][1]['first_semantic_judgment']['needs_review']+['本人是否正在找房及所指是否当前可租房源待核'])
 k='D0082'; update(k,'原帖只描述一人两人居住，短问价不能单独证明出租房源或现实求租；与同帖弱询盘均保留未知。',role='unknown',demand_state='unknown',interest='uncertain',topics=[topic('价格预算',s[k][1]['text'],sub='unresolved')],reason='泛生活分享下问价，询价对象与本人是否找房尚未明确。',needs_review=['是否询问当前可租房源、本人是否正在找房待核'],reply_plan=nullplan('短询房租线索保留，澄清语境后再选择母句'))
 k='D0230'; update(k,'“这不得”是反问估价，未证明本人租房推进，五千亦不是预算上限。',role='unknown',demand_state='unknown',interest='uncertain',topics=[topic('价格预算',s[k][1]['text'],'compare','unresolved')],reason='泛生活分享下以反问估价，可能感叹价格或认真询价，保留歧义。',needs_review=['反问是价格感叹还是本人询租待核；五千不是确认预算'],reply_plan=nullplan('未确认现实租赁需求，不以反问生成推荐稿'))
 for k in 'D0099 D0168'.split():
  update(k,'仅核真假或真实性，未出现求租、问具体条件或看房动作，保留住房关注而非确定需求推进。',role='unknown',demand_state='unknown',interest='uncertain',reason='房源真实性短问可为质疑或关注，无法确认本人现实求租。',needs_review=['本人是认真找房还是单纯质疑真实性待核'],reply_plan=nullplan('先澄清本人求租意愿，不把真实性短问当已找房'))
 k='D0249'; update(k,'“这两千  真假”保留价格真实性疑问，不能无证据认定本人正在求租或两千预算。',role='unknown',demand_state='unknown',interest='uncertain',topics=[topic('价格预算',s[k][1]['text'],'ask','unresolved')],reason='本人核实两千报价的真实性，当前求租意愿未知。',needs_review=['核实是否本人正在找房及所指报价对象'],reply_plan=nullplan('报价真实性未明，不强推推荐'))
 k='D0314'; update(k,'短租长签、待转与失联仍是未解决的本人租约变化，不能按历史经历整体过滤；是否另找房需留核。',role='unknown',demand_state='unknown',interest='uncertain',reason='本人投诉短租长签及转租失联，现有居住变化未解决，后续是否另找房未知。',needs_review=['现合同和转租是否解决、是否仍需搬离及另找房待核'],reply_plan=nullplan('先回应严肃纠纷语境，不强行推销；保留后续换房机会',tone='serious'))
 k='D0206'; update(k,'不用大床是非必要，单人床即可是接受；价格和房态为询问，不能全部写成同一硬要求。',topics=[topic('房内设施','不用大床','not_required',scope='不用大床，单人床即可'),topic('房内设施','单人床即可','accept',scope='不用大床，单人床即可'),topic('房源状态','有没有？'),topic('价格预算','多钱？')],reason='本人不要求大床、接受单人床，并主动询房态和价格；不排斥床本身。')
 keep=[('D0002 D0027 D0041 D0043 D0045 D0047 D0049 D0051 D0055 D0057 D0171 D0173 D0181 D0183 D0187 D0339 D0341 D0343 D0345 D0347 D0349 D0351 D0061 D0065 D0067 D0069 D0071 D0223 D0227 D0111 D0131 D0134 D0310 D0312 D0209 D0213','逐条核对共享正文和本人评论，属于建议、评价、经历感叹或明确互动，未见本人新求租；维持讨论及不生成推荐稿。'),('D0007 D0136 D0053 D0175 D0177 D0179 D0185 D0077 D0086 D0225 D0233 D0258 D0113 D0115 D0298 D0211 D0317','逐条核对歧义及主体，稽查、省略、艾特、反事实接受、泛短询或未决居住变动均已有具体待核；维持未知，不补造需求或全面拒联。'),('D0289','本人主动提供大丰套一房东房源，没有同时另找房，供给条件与本人需求已分开。'),('D0142','只可能要租并先关注，未形成现实推进；低意向及不推稿与原文相符。'),('D0012 D0015 D0017 D0218 D0220 D0029 D0285 D0287 D0291 D0293 D0295 D0031 D0034 D0139 D0144 D0146 D0149 D0059 D0073 D0075 D0079 D0237 D0088 D0103 D0243 D0251 D0253 D0260 D0117 D0121 D0123 D0125 D0127 D0266 D0269 D0271 D0274 D0276 D0278 D0301 D0304 D0306 D0308 D0153 D0324 D0326 D0337 D0189 D0197 D0199 D0204 D0262 D0319','逐条核对本人询租、弱关注及原判等级；地区、住房条件与时间主体未借用正文。明确求房不因泛标题压低，弱关注未抬成高意向；现有母句候选及事实待核保留。')]
 save(0,keep,ch)
def page1():
 s=load(1); ch={}
 def update(k,why,**patch):ch[k]=(why,patch)
 for k in 'D0396 D0402 D0555 D0732 D0720 D0479'.split():
  update(k,'泛租房生活或价格讨论中短询只能证明关注，尚未证明现实找房推进；保留问题和原中等意向。',demand_state='unknown',needs_review=s[k][1]['first_semantic_judgment']['needs_review']+['本人现实找房动作及所询房源当前可租性待核'])
 k='D0730';update(k,'同帖只有一人两人生活描述，位置和价格短问没有额外现实求租证据，不能误判为高意向。',role='unknown',demand_state='unknown',interest='uncertain',topics=[topic('位置通勤',s[k][1]['text'],sub='unresolved'),topic('价格预算',s[k][1]['text'],sub='unresolved')],reason='泛生活展示下问价和位置，实际租赁意愿及询问对象待核。',needs_review=['所询是否当前可租房源及本人是否正在找房待核'],reply_plan=nullplan('泛短询留核，暂不生成推销稿'))
 k='D0546';update(k,'“这个合生汇”是所询房源位置线索，不是已明确的本人目标地区；保留住房关注与查询地。',demand_state='unknown',target_regions=[dict(text='合生汇',quote='合生汇',relation='unresolved',group_relation='unknown',condition_scope='这个合生汇多少钱啊')],needs_review=s[k][1]['first_semantic_judgment']['needs_review']+['合生汇是查询对象还是本人目标地、实际租赁意愿待核'])
 k='D0450';update(k,'仅询价格真假可为质疑，不能认定本人已找房；同时保留价格真实性问题。',role='unknown',demand_state='unknown',interest='uncertain',topics=[topic('价格预算',s[k][1]['text'],sub='unresolved')],reason='仅核报价真假，认真求租还是质疑未知。',needs_review=['本人实际找房意愿及所指报价真实性待核'],reply_plan=nullplan('仅真实性质疑，先澄清本人租赁意愿'))
 for k in 'D0457 D0787 D0715'.split():
  update(k,'明确住宅出租房源下主动询“多少米”，指标歧义不等于没有询租动作；保留价格/面积候选而提高当时询盘等级。',demand_state='active_at_comment',interest='high',reason='明确出租房源下主动短询，询租兴趣成立；米指价格还是面积仍待澄清。')
 k='D0376';update(k,'“可以做饭就挺不错”是正向偏好而非询问，尚未明确实际找房，保持弱关注。',topics=[topic('房内设施',s[k][1]['text'],'prefer','unresolved')])
 k='D0595';update(k,'只提出萧山房源自租转供，没有任何租金或预算，移除无证据的价格池。',topics=[topic('位置通勤',s[k][1]['text'],'fact','supply')])
 k='D0587';update(k,'保留转租供给的地点、月价、燃气、联系和剩余租期；未说具体户型与费用合同条款，不额外分池。',topics=[topic(pool,s[k][1]['text'],'fact','supply') for pool in ['位置通勤','价格预算','房内设施','看房联系','入住与租期']])
 keep=[('D0393 D0400 D0565 D0418 D0769 D0481 D0484 D0492 D0496 D0502 D0504 D0506 D0508 D0682 D0690 D0795 D0799 D0651 D0657 D0773 D0776','逐条核对正文及本人，均为估价、建议、感叹、表情、经历或非住房互动，未见本人现实新求租，维持讨论及不推稿。'),('D0404 D0548 D0551 D0560 D0722 D0725 D0728 D0738 D0431 D0744 D0625 D0630 D0766 D0469 D0680 D0684 D0686 D0688 D0692 D0797 D0801 D0599','逐条核对省略、纯艾特、泛短询、真假与租购用途歧义，现有未知及具体待核符合原文，不无证补需求或清除候选。'),('D0446 D0448 D0634 D0771 D0500 D0589 D0593 D0597 D0601 D0603','本人供房、转租或中介招揽明确，未提本人另找新房；供给主体及转租后是否另需房的待核范围保留。'),('D0354 D0369 D0521 D0524 D0528 D0695 D0374 D0379 D0383 D0537 D0398 D0406 D0410 D0553 D0557 D0736 D0413 D0421 D0569 D0574 D0582 D0584 D0749 D0752 D0757 D0434 D0436 D0439 D0441 D0443 D0628 D0632 D0637 D0760 D0763 D0452 D0466 D0609 D0616 D0620 D0474 D0487 D0490 D0494 D0498 D0591 D0641 D0649 D0659 D0662 D0666 D0672','逐条核对本人语义与实际正文：主动求房、问条件和联系分级适当；办公询价不当住宅，愿望未当现行找房；入住和租期分开，目标与查询地区分，原母句候选及事实待核保留。')]
 save(1,keep,ch)
def page2():
 s=load(2);ch={}
 def update(k,why,**patch):ch[k]=(why,patch)
 for k in 'D0835 D1020 D1035 D0894 D1062 D1118 D1092'.split():
  update(k,'泛生活或经历帖下问具体条件保留住房关注，但未明确实际找房动作；原中等兴趣不应同时写成已推进。',demand_state='unknown',interest='medium',needs_review=s[k][1]['first_semantic_judgment']['needs_review']+['本人是否现实求租及所询是否当前可租房源待核'])
 for k in 'D0837 D1038'.split():
  update(k,'价格真实性核问不等于已找房，保留其报价问题及中等关注，不认定现实推进或预算。',demand_state='unknown',needs_review=s[k][1]['first_semantic_judgment']['needs_review']+['是否认真询租而非价格质疑，所问金额不是确认预算'])
 k='D1023';update(k,'朝阳是查询房源的区域线索，未明确本人目标；短问价保留关注，但当前动作未证实。',demand_state='unknown',target_regions=[dict(text='朝阳',quote='朝阳',relation='unresolved',group_relation='unknown',condition_scope='朝阳多少钱')],needs_review=s[k][1]['first_semantic_judgment']['needs_review']+['朝阳是查询地还是本人目标、现实租赁意愿待核'])
 k='D1033';update(k,'泛居住展示下仅问朝阳区价格，与同帖短问仍有真实求租歧义；不能单凭地区名认定高意向。',role='unknown',demand_state='unknown',interest='uncertain',topics=[topic('价格预算',s[k][1]['text'],sub='unresolved'),topic('位置通勤',s[k][1]['text'],sub='unresolved')],target_regions=[dict(text='朝阳区',quote='朝阳区',relation='unresolved',group_relation='unknown',condition_scope=None)],reason='询朝阳区报价但未说明本人找房，查询对象和目标地区待核。',needs_review=['本人实际求租意愿与朝阳区是否目标地待核'],reply_plan=nullplan('泛短询保留未知，先澄清再选择母句'))
 k='D0876';update(k,'本人询租房补贴学历门槛，不能作为纯无关讨论过滤；住房福利线索与商业租赁意愿分开待核。',role='unknown',demand_state='unknown',interest='uncertain',reason='询本科硕博与专科租房/生活补贴资格，有住房福利线索，实际住宿与商业租赁意愿未明。',other_constraints=[dict(quote='租房补贴和生活补贴是只有本科硕士博士才有然后专科没有的嘛宝宝',detail='住房及生活补贴学历资格疑问，不等于已求商业公寓')],needs_review=['本人申请哪项补贴、实际住宿需求及是否考虑商业租赁待核'],reply_plan=nullplan('保留住房福利线索，不将资格咨询直接推成商业公寓需求'))
 k='D0900';update(k,'生活帖只说多少，租金或面积均可能；不可机械落入确定价格池及现实找房。',role='unknown',demand_state='unknown',interest='uncertain',topics=[],possible_topics=[dict(quote='多少',candidate_pools=['价格预算','户型面积与居住方式'],ambiguity='只问多少，指租金、面积还是其他事项不明')],reason='泛生活分享下指标与本人求租动作皆不明。',needs_review=['多少的计量对象、所询房源可租性和实际求租意愿待核'],reply_plan=nullplan('保留候选池与未知，澄清前不推稿'))
 k='D0960';update(k,'线路可选范围与到人民广场通勤目的地不能压成两个住宅目标的AND；保留全部联立条件。',target_regions=[dict(text='1号线',quote='1和8号线上',relation='desired',group_relation='OR',condition_scope='1和8号线范围可选，且到人民广场通勤40分钟；是否必须双线交会待核'),dict(text='8号线',quote='1和8号线上',relation='desired',group_relation='OR',condition_scope='1和8号线范围可选，且到人民广场通勤40分钟；是否必须双线交会待核'),dict(text='人民广场',quote='距离人民广场通勤40分钟',relation='unresolved',group_relation='AND',condition_scope='通勤目的地，不等同住宅目标；与线路、3000以内、一室独住联立')],needs_review=s[k][1]['first_semantic_judgment']['needs_review']+['1和8号线是任一线路还是需双线交会、40分钟交通方式待核'])
 k='D1080';update(k,'本人明确求有无两室一厅，泛生活标题不能盖过本人完整求房动作；多少米仍只存候选。',interest='high',reason='本人主动求两室一厅房源并询指标，属于评论时找房；多少米未明确价格或面积，不确定分池。')
 keep=[('D0803 D0805 D0983 D0985 D0987 D0989 D0991 D0993 D0995 D1148 D1150 D1152 D1154 D1158 D0829 D0853 D0872 D0878 D0880 D0882 D0888 D0906 D0930 D1101 D0944 D0946 D0948 D0950 D0952 D0954 D0956 D0958 D1074 D1076 D1114','逐条核读本人及共享正文，是建议、感叹、旧经历、购买愿望或互动而无现实新求租；维持讨论且不生成推荐稿。'),('D0827 D0831 D0833 D0842 D0845 D0848 D1025 D0884 D0886 D0890 D0892 D0896 D0898 D0902 D0904 D0913 D0932 D0979 D1016 D1078 D1082 D1084 D1086 D1088','逐条核对私人参观、泛短询、资格、艾特和夸张反讽等歧义，保留未知与具体待核，未把严重措辞当签约或把纯互动当无关。'),('D1179 D1067','分别为同作者出租帖举手及明确成都双流转租；未含本人另找新房动作，供给语义保留。'),('D1156','本人先想搬但最后明确再住一年，当前找房结束，学校限制和潮湿现房语境已保留，没有抹掉否定与后续条件。'),('D0809 D0816 D0820 D0825 D1011 D1161 D1167 D1173 D0851 D1018 D1028 D1031 D0860 D0866 D1042 D1051 D0916 D0918 D0920 D0922 D1058 D1060 D1064 D1069 D0925 D0927 D0934 D0940 D1096 D1099 D1103 D1110 D1116 D1121 D1123 D1126 D0962 D0969 D0973 D1143 D1145 D1090 D1181','逐条核读本人询租与较弱关注，现有分级、主体、车位/安保等额外条件、否定偏好、时间角色及身份限制符合原文；认可母句候选和事实缺口保留，不把联系许可当发送许可。')]
 save(2,keep,ch)
def page3():
 s=load(3);ch={}
 def update(k,why,**patch):ch[k]=(why,patch)
 for k in 'D1203 D1292 D1296 D1383'.split():
  update(k,'位置、名称短问或口头来一套能保留住房关注，尚未明确实际找房推进；不与订房成功混同。',demand_state='unknown',needs_review=s[k][1]['first_semantic_judgment']['needs_review']+['本人是否正在实际找房、所询对象与当前可租性待核'])
 k='D1210';update(k,'一人两人生活描述下仅短问位置价格，缺少当前可租房源及本人求租证据，不能认定高意向。',role='unknown',demand_state='unknown',interest='uncertain',topics=[topic('位置通勤',s[k][1]['text'],sub='unresolved'),topic('价格预算',s[k][1]['text'],sub='unresolved')],reason='泛生活展示下短问价与位置，实际求租意愿待核。',needs_review=['本人是否正在找房、是否所询当前可租房源待核'],reply_plan=nullplan('泛短询保留未知，澄清前不生成推荐稿'))
 k='D1266';update(k,'“后面一套多少”计量对象未明，且是生活分享而非明确可租帖；不能确定价格池或本人推进。',role='unknown',demand_state='unknown',interest='uncertain',topics=[],possible_topics=[dict(quote='后面一套多少',candidate_pools=['价格预算','户型面积与居住方式'],ambiguity='多少可能询租金或面积，当前可租性和本人是否求租不明')],reason='生活分享下问后套多少，指标及本人求租意愿皆待核。',needs_review=['多少所指租金或面积、本人是否在找房及所询可租性待核'],reply_plan=nullplan('保留候选与歧义，澄清后再选母句'))
 k='D1294';update(k,'原文一的有吗未确定具体户型，不能一面存候选一面统计确定户型池。',topics=[topic('房源状态','一的有吗',sub='unresolved')],reason='有无房源的短询可保留关注，但一的指代不完整，户型仍为候选待核。')
 k='D1322';plan=copy.deepcopy(s[k][1]['first_semantic_judgment']['reply_plan']);plan['missing_facts']+=['同一可承接门店确实允许猫及具体种类体型限制，长期租期可安排；不能只凭通用介绍答复宠物问题'];update(k,'宠物专项母句必须明确核实同店允许猫，并与大连甘井子及长期条件联立，原计划遗漏专项事实缺口。',reply_plan=plan)
 keep=[('D1240 D1242 D1244 D1246 D1248 D1250 D1254 D1256 D1258 D1264 D1270 D1272 D1327 D1329 D1364 D1366 D1370 D1372 D1374 D1376 D1380','逐条核对本人评论及实际共享正文，均为经验感叹、建议、购买愿望、物品询问或社交互动，没有本人新求租；不迁移作者条件或生成推荐稿。'),('D1196 D1208 D1252 D1260 D1268 D1274 D1276 D1278 D1280 D1284 D1286 D1305 D1378','逐条核对残句、指代、艾特、假设改造、养猫难找及现房/供给歧义，原判保留未知与具体核点合理，未当成高意向或武断无关。'),('D1299 D1303 D1368','明确为温江招租、成都中介供给或本人两室出租的价格讨论，无本人另找房，保留供给及不推稿。'),('D1185 D1188 D1190 D1201 D1212 D1214 D1216 D1223 D1229 D1262 D1282 D1290 D1301 D1311 D1313 D1318 D1324 D1331 D1336 D1338 D1340 D1343 D1347 D1351 D1357 D1395 D1401 D1404 D1406 D1408 D1411 D1413 D1417 D1419','逐条核对本人明确求房、订房式请求与较弱关注：泛标题不盖过完整本人需求；期限、否定、备选地点、低楼层、家庭与停车语义保留。家暴急迫对象待核及严肃不营销计划适当，母句候选不等于事实或发送许可。')]
 save(3,keep,ch)
if __name__=='__main__':
 import sys
 globals()[f'page{sys.argv[1] if len(sys.argv)>1 else 0}']()
