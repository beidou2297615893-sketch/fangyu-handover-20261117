"""Meaningful behavior checks for this batch-local rendering boundary."""
import unittest,json,copy,importlib.util
from pathlib import Path
from batch_short_mothers import render_plan
CONTRACT=json.loads(Path(__file__).with_name('local-mother-contract.json').read_text(encoding='utf-8'))
def record(family,fill,evidence,**kw):
 r={'role':'demand','demand_state':'active_at_comment','interest':'high','human_confirmed':False,'send_authorized':False,'store_assignment':None,'reply_plan':{'tone':'normal','contact_policy':'allow','local_mother':{'family':family,'fill':fill,'evidence':evidence},'caution':[]}}
 r.update(kw);return r
class RenderingBoundary(unittest.TestCase):
 def test_multiple_literal_conditions_and_negation_survive_without_added_month_unit(self):
  own='浦东 不要暗卫 民水民电 预算4000以内'
  r=record('requirements',{'requirements':'浦东；不要暗卫；民水民电；预算4000以内'},[{'field':'requirements','quote':own}]);before=copy.deepcopy(r)
  z=render_plan(r,own,CONTRACT)
  for value in ('浦东','不要暗卫','民水民电','预算4000以内'):self.assertIn(value,z['text'])
  self.assertNotIn('/月',z['text']);self.assertEqual(r,before)
 def test_work_destination_uses_commute_question_and_serious_tone(self):
  r=record('commute',{'destination':'高新'},[{'field':'destination','quote':'工作在高新'}]);r['reply_plan']['tone']='serious'
  z=render_plan(r,'工作在高新',CONTRACT)
  self.assertIn('去高新方不方便',z['text']);self.assertFalse(z['text'].startswith('宝宝'))
 def test_full_rent_budget_is_preserved(self):
  r=record('all_in_budget',{'place':'徐汇','budget':'3000以内'},[{'field':'place','quote':'徐汇'},{'field':'budget','quote':'房租水电气3000以内'}])
  z=render_plan(r,'徐汇附近房租水电气3000以内',CONTRACT)
  self.assertIn('房租水电气3000以内',z['text']);self.assertNotIn('有房',z['text'])
 def test_ended_supply_mixed_unknown_and_no_contact_do_not_generate(self):
  for changes in ({'demand_state':'ended'},{'role':'supply'},{'role':'mixed'},{'role':'unknown'},{'interest':'uncertain'}):
   r=record('available',{},[],**changes);self.assertIsNone(render_plan(r,'还有吗',CONTRACT)['text'])
  r=record('available',{},[]);r['reply_plan']['contact_policy']='no_contact';self.assertIsNone(render_plan(r,'还有吗，别联系',CONTRACT)['text'])
 def test_fabricated_fields_and_money_units_are_rejected(self):
  for fill in ({'budget':'3000/月'},{'budget':'3000','place':'北京'}):
   r=record('budget_fit',fill,[{'field':'budget','quote':'3000'}])
   with self.assertRaises(ValueError):render_plan(r,'预算3000',CONTRACT)
 def test_lease_monthly_cat_and_elevator_remain_confirmation_questions(self):
  for family,fill,own,ev,part in [('lease_fixed',{'duration':'两个月'},'短租两个月',[{'field':'duration','quote':'两个月'}],'两个月能不能租'),('pet_cat',{},'能带猫吗',[],'猫猫能否带'),('elevator',{},'有电梯吗',[],'有没有电梯')]:
   self.assertIn(part,render_plan(record(family,fill,ev),own,CONTRACT)['text'])
 def test_relocation_requires_explicit_next_year_move_and_null_has_reason(self):
  r=record('relocation',{'place':'滨江'},[{'field':'place','quote':'滨江'}])
  with self.assertRaises(ValueError):render_plan(r,'工作在滨江',CONTRACT)
  r['reply_plan']['local_mother']=None;r['reply_plan']['caution']=['没有适合承接的本人需求'];self.assertIsNone(render_plan(r,'@朋友',CONTRACT)['text'])
 def test_existing_UID_reconciliation_keeps_short_and_legacy_alternatives_then_applies_later_end(self):
  w=Path(__file__).resolve().parents[3];spec=importlib.util.spec_from_file_location('locked_adapter_test',w/'mother_adapter.py');a=importlib.util.module_from_spec(spec);spec.loader.exec_module(a)
  new=render_plan(record('area',{'place':'浦东'},[{'field':'place','quote':'浦东'}]),'浦东有吗',CONTRACT)['text']
  records=[dict(platform='douyin',customer_uid='same',comment_id='old',role='demand',demand_state='active_at_comment',interest_at_comment='high',published_at='2026-09-01T00:00:00+08:00',mother_reply_text='旧基础稿'),dict(platform='douyin',customer_uid='same',comment_id='new',role='demand',demand_state='active_at_comment',interest_at_comment='high',published_at='2026-10-01T00:00:00+08:00',mother_reply_text=new)]
  self.assertEqual(a.reconcile_customers(records),1);self.assertEqual(records[0]['alternative_mother_reply_text'],'旧基础稿');self.assertEqual(records[1]['mother_reply_text'],new)
  records.append(dict(platform='douyin',customer_uid='same',comment_id='end',role='demand',demand_state='ended',published_at='2026-10-02T00:00:00+08:00',mother_reply_text=None))
  a.reconcile_customers(records);self.assertTrue(all(r['mother_reply_text'] is None for r in records));self.assertEqual(records[1]['alternative_mother_reply_text'],new)
if __name__=='__main__':unittest.main()
