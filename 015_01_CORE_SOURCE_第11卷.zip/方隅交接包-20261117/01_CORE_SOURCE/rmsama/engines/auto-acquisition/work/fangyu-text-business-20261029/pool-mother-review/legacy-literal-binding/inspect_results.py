import json,pathlib,collections
O=pathlib.Path('work/fangyu-text-business-20261029/pool-mother-review/legacy-literal-binding');ps=[json.loads(l) for l in (O/'proposed-plans.jsonl').read_text(encoding='utf8').splitlines()];c=json.loads(pathlib.Path('work/fangyu-text-business-20261029/region-brand-routing/current.json').read_text(encoding='utf8'));rs={}
for plat,f in c['results'].items():
 for l in pathlib.Path(f).read_text(encoding='utf8').splitlines():
  r=json.loads(l);rs[plat,r['comment_id'],r['customer_uid']]=r
samples=[json.loads(l) for l in (O/'representative-review.jsonl').read_text(encoding='utf8').splitlines()];idx={(p['platform'],p['cid'],p['uid']):p for p in ps}
for s in samples:
 p=idx[s['platform'],s['cid'],s['uid']];print('REP',s['review_index'],s['comment'],p['draft_text_preview'] or p['hold_reasons'])
for rem in ('月','子','要','租','找','合适','了','上班','私','人'):
 for p in [p for p in ps if p.get('unbound_literal_residual')==rem][:3]:print('HOLD',rem,rs[p['platform'],p['cid'],p['uid']]['comment_text'],p['literal_evidence'])
