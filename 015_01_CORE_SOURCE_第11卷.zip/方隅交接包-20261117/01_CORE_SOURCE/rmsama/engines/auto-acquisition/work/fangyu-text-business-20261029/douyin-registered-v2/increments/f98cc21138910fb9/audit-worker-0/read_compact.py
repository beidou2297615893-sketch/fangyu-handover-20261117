import json,sys
from pathlib import Path
b=Path(__file__).resolve().parent.parent;p=int(sys.argv[1]);lo=int(sys.argv[2]);hi=int(sys.argv[3]);d=json.loads((b/f'recall-audit/part-0/page-{p:02}.json').read_text(encoding='utf8'))
n=0;seen={}
def ref(v):
 s=json.dumps(v,ensure_ascii=False,separators=(',',':'))
 if s not in seen:
  x='T'+str(len(seen));seen[s]=x;print(x+'='+s)
 return seen[s]
for g in d['post_groups']:
 cs=g['comments']
 if any(lo<=i<hi for i in range(n,n+len(cs))):
  print('BODY',g['video'],json.dumps(g['post_body'],ensure_ascii=False))
  for c in cs:
   if lo<=n<hi:
    a=dict(c);a.pop('audit_selection',None);j=dict(a.pop('first_semantic_judgment'));r=dict(j['reply_plan'])
    for f in ['missing_facts','caution']:r[f]=ref(r[f])
    j['reply_plan']=r;j['context_used']=ref(j['context_used']);a['first_semantic_judgment']=j
    for f in ['parent','reply_to','source_conflict','same_author']:
     if a[f] in [None,'0',False]:a.pop(f)
    print(n,json.dumps(a,ensure_ascii=False,separators=(',',':')))
   n+=1
 else:n+=len(cs)
print('TOTAL',n,'Omitted metadata defaults: parent=null,reply_to=0,source_conflict=false,same_author=false; all judgment fields retained; T refs expanded above.')
