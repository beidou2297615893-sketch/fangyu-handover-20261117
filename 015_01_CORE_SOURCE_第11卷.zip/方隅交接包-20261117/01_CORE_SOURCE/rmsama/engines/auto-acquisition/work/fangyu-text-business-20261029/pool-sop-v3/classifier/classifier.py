"""Versioned local demand-pool annotation. Does not classify new leads as high.

Uses already-reviewed labels when present. A pool is not a property promise or a
send permission. Unknown facts never block assigning an evidenced demand pool.
"""
import collections, hashlib, json, re, unicodedata
from pathlib import Path

HERE=Path(__file__).resolve().parent
WORK=HERE.parents[1]
VERSION='pool-sop-classifier-v3-20261103-scope'
POOLS=['价格预算','位置通勤','户型面积与居住方式','房内设施','宠物','楼层电梯','入住与租期','房源状态','费用合同','看房联系']
CHANNEL_PATTERN=r'(?:个人转租|转租|房源).{0,8}(?:在哪|哪里|哪儿)(?:看|找|搜)|(?:在哪|哪里|哪儿)(?:找|搜)(?:房|公寓)|(?:什么|哪个).{0,3}(?:app|APP|软件|平台).{0,8}(?:找房|看房|房源)|找房渠道'
RULES=[
 ('价格预算','问价',r'多少钱|多少米|多少m|几米|多米|多小米|几张|什么价|房租多少|租金|价格|价位|问价|(?:一室一厅|两室|单间).{0,3}多少'),
 ('价格预算','预算',r'预算|\d+(?:\.\d+)?[kK千]|\d+\s*(?:元|块)|\d+.{0,3}(?:以内|以下|封顶)'),
 ('价格预算','省租金',r'便宜|优惠|省钱|低价'),
 ('位置通勤','地点',r'附近|周边|(?:浦东|奉贤|杨浦|静安|普陀|双流|成华|武侯|余杭|五常|常营|望京|俸伯|中关村|北苑|萧山|浦江镇|滨江|番禺|大江东|天府\d?街|爱琴海|王庄|象园|瀛洲)|[\u4e00-\u9fff]{2,8}(?:区|镇|街道|地铁站)|[一二三四五六七八九十\d]+环'),
 ('位置通勤','地铁线路',r'地铁|[一二三四五六七八九十\d]+号线'),
 ('位置通勤','通勤',r'通勤|上班|工作地|离.{0,15}多远|(?:走|步行|距离).{0,8}(?:多少米|几米)'),
 ('位置通勤','位置查询',r'在哪|哪里|哪儿|地址|具体位置'),
 ('位置通勤','公寓名称',r'什么公寓|名字叫|公寓叫'),
 ('户型面积与居住方式','整租',r'整租'),
 ('户型面积与居住方式','合租',r'合租|室友'),
 ('户型面积与居住方式','户型',r'[一二两三四1234](?:室(?:[一二两三四1234]厅)?|居室)|单间|套[一二两三四1234]|户型'),
 ('户型面积与居住方式','面积',r'面积|平米|平方|㎡|\d+平'),
 ('户型面积与居住方式','人数与居住资格',r'[一二两三四1234]个人|[一二两三四1234]人住|男的行|女生能|新疆人.{0,6}住|非应届|应届生|入住资格'),
 ('房内设施','厨房',r'厨房|做饭'),
 ('房内设施','卫生间',r'独卫|卫生间|厕所'),
 ('房内设施','阳台',r'阳台'),
 ('房内设施','家电',r'冰箱|洗衣机|空调|热水器|家电'),
 ('房内设施','燃气',r'燃气|天然气'),
 ('房内设施','隔音',r'隔音|吵|噪音'),
 ('房内设施','环境与安全',r'甲醛|潮湿|潮吗|发霉|串串房'),
 ('房内设施','停车充电配套',r'停车位|充电桩|汽车.{0,4}充电|停车'),
 ('房内设施','管家服务',r'管家|保洁|维修'),
 ('宠物','猫',r'猫'),('宠物','狗',r'狗'),('宠物','宠物',r'宠物'),
 ('楼层电梯','电梯',r'电梯'),('楼层电梯','楼层',r'楼层|几楼|[一二三四五六七八九十\d]+楼|低层|高层'),
 ('入住与租期','入住时间',r'[下本这]个?月|月底|月初|[一二三四五六七八九十\d]+月(?:底|初|\d+[日号])?|入住|马上到期|急租'),
 ('入住与租期','短租',r'短租|月租|[一二两三四五六七八九十\d]+个?月|[一二两三四五六七八九十\d]+天'),
 ('入住与租期','长租',r'长租|半年|[一二两三四1234]年'),
 ('入住与租期','租期灵活',r'租几个月|几个月.{0,4}(?:行|可以|能|租)|租期.{0,4}灵活|灵活.{0,3}租|租多久'),
 ('房源状态','空房查询',r'有无.{0,8}房|有没有.{0,12}房|还有.{0,8}房|有房|房源|有吗|有嘛|有没|有无'),
 ('房源状态','仍可租',r'还在|还能租|还可租'),
 ('房源状态','明确求租或兴趣',r'求租|想租|要租|找房|求.{0,3}一套|来一套|蹲.{0,8}一套|给我来一个|看上了|求🏘'),
 ('费用合同','水电',r'水电|水费|电费|商业用电|民水民电'),
 ('费用合同','押付',r'押[一二三123]|月付|押金|押付'),
 ('费用合同','中介费',r'中介费|服务费'),
 ('费用合同','合同与资格',r'合同|违约|居住证|保障房|申请|登记备案|清河驿站'),
 ('看房联系','预约看房',r'看房|约看|带看'),
 ('看房联系','找房渠道',CHANNEL_PATTERN),
 ('看房联系','联系咨询',r'联系|微信|私信|留言|咨询|介绍一下|详情|加我|加个|(?:^|\s)[dD]{2}(?:$|\s)|滴滴(?!打车|出行|司机)|踢踢|踢我|蹲蹲'),
 ('看房联系','联系限制',r'勿扰|别私信|不要私信|不回|没回'),
 ('看房联系','申请咨询',r'怎么申请|申请吗|登记|刷新页面|出结果|转圈'),
]

def normalize(text):
 value=re.sub(r'[\s，,。！？!?~～]+','',unicodedata.normalize('NFKC',text).lower())
 # Only whole utterance equivalents, not arbitrary fuzzy replacement.
 return {'滴滴':'dd','滴滴滴':'dd','多少米':'多少钱','多少米啊':'多少钱','多少钱啊':'多少钱'}.get(value,value)

def metadata(row):
 o=row.get('original_classification') or {}
 if isinstance(o.get('classification'),dict): o=o['classification']|o
 return o

def context_key(row):
 o=metadata(row)
 # Require exact source context and relationship for cached semantic decisions.
 parts=[row.get('platform'),o.get('video_id') or o.get('note_id'),o.get('post_body'),o.get('direct_parent_text'),o.get('reply_to'),o.get('post_author_same_as_commenter')]
 return hashlib.sha256(json.dumps(parts,ensure_ascii=False,sort_keys=True).encode()).hexdigest()

def guard_signature(text):
 return {'negations':re.findall(r'不要|不合租|不接受|不养|不带|不能|没有|勿扰',text),
         'numbers':re.findall(r'\d+(?:\.\d+)?|[一二两三四五六七八九十]+(?:月|天|年|室|只)',text),
         'role_cues':re.findall(r'我出租|本人出租|我求租|我想租|帮父母|他说|她说|已经租到',text),
         'alternatives':bool(re.search(r'或者|还是|要么',text))}

def cache_key(row):
 return hashlib.sha256((normalize(row.get('comment_text',''))+'\0'+context_key(row)+'\0'+json.dumps(guard_signature(row.get('comment_text','')),ensure_ascii=False,sort_keys=True)).encode()).hexdigest()

def classify(row, review=None):
 t=row.get('comment_text') or row.get('text') or ''; o=metadata(row)
 original=[p for p in (row.get('demand_pools') or o.get('topics') or []) if isinstance(p,str) and p in POOLS]
 pools=list(dict.fromkeys(original)); evidence=[]; subtags=[]
 for pool,subtag,pattern in RULES:
  for m in re.finditer(pattern,t):
   # Search duration and historical occupancy are not a requested lease term.
   # Keep source text and pre-existing reviewed topics, but do not add false
   # local lease evidence or slots from these spans.
   if pool=='入住与租期' and subtag in ('短租','长租','入住时间'):
    before=t[max(0,m.start()-12):m.start()]
    after=t[m.end():m.end()+8]
    if re.search(r'(?:找|看|等|说|问)(?:房|房子)?(?:了|过|整整|足足|快|将近|大概|差不多|已经|有|也)*$',before):
     continue
    if subtag=='短租' and re.match(r'\s*\d+\s*(?:元|块|米|[，,。]|$)',after):
     continue
    if re.search(r'(?:以前|之前|去年|曾经|已经).{0,4}(?:租|住)(?:了|过)?$',before):
     continue
   if pool=='价格预算' and m.group() in ('多少米','几米','多少m') and re.search(r'离|距离|步行|走|长|宽|高|面积',t[max(0,m.start()-12):m.start()]):
    continue
   # State the scope of a negation; interrogatives 有无/有没有 are not rejection.
   clause_start=max(t.rfind(x,0,m.start()) for x in '，,。；;！？!?')+1
   clause_end=min([pos for x in '，,。；;！？!?' if (pos:=t.find(x,m.end()))>=0] or [len(t)])
   if subtag=='位置查询' and re.search(CHANNEL_PATTERN,t[clause_start:clause_end]):
    continue
   # Mask full interrogative structures BEFORE taking a local prefix window.
   # Otherwise a sliced 有没有 can become 没有 and invent a negation. Do not
   # suppress all negatives merely because the clause also contains a question:
   # 有没有不合租的 must preserve the real 不合租 constraint.
   full_prefix=t[clause_start:m.start()]
   normalized_prefix=re.sub(r'有没有|有无|能不能|可不可以',lambda q:' '*len(q.group()),full_prefix)
   prefix=normalized_prefix[-8:]
   negative=bool(re.search(r'(?:不要|不想|不接受|不能|不合|不养|不带|没有|不需要|不考虑|不|无).{0,3}$',prefix)) or (subtag=='联系限制')
   polarity='excluded' if negative else 'question' if re.search(r'吗|嘛|么|多少|有无|有没有|[？?]',t) else 'mentioned'
   evidence.append(dict(pool=pool,subtag=subtag,quote=m.group(),start=m.start(),end=m.end(),polarity=polarity,source='comment_literal'))
   if pool not in pools:pools.append(pool)
   if subtag not in subtags:subtags.append(subtag)
 # These are semantic reviews of previously uncovered exact expressions, not a
 # wildcard routing rule. Reuse only in the same reviewed source context.
 decision=(review or {}).get((row.get('platform'),str(row.get('comment_id'))))
 if decision and (decision.get('text')!=t or decision.get('context_key')!=context_key(row)):
  decision=None
 if decision:
  for p in decision['pools']:
   if p not in pools:pools.append(p)
  subtags += [x for x in decision['subtags'] if x not in subtags]
  evidence.append(dict(source='current_batch_semantic_review',quote=t,reason=decision['reason'],review_id=decision['review_id']))
 missing=[]
 if re.search(r'这个|这里|这套|那边|同价|这种',t):missing.append('所指房源/地点/价格未在评论展开；不阻止通用母句')
 constraints={
  'raw_comment':t,
  'negative_spans':[e for e in evidence if e.get('polarity')=='excluded'],
  'choice_relation':'alternative' if re.search(r'或者|还是|要么',t) else 'not_explicit',
  'explicit_time_strings':re.findall(r'[一二三四五六七八九十\d]+月底|[一二三四五六七八九十\d]+月初|[一二两三四五六七八九十\d]+个?月|[一二两三四五六七八九十\d]+天|\d+月\d+[日号]|马上到期|月底|月初',t),
  'contact_boundaries':row.get('contact_boundaries') or o.get('contact_boundaries') or [],
  'current_state_review_needed':bool(re.search(r'已(?:经)?租到|刚.{0,5}定了|不租了|已找到',t)),
  'source_vs_target_separate':True,
 }
 method='existing_AI_reused' if original else 'current_batch_AI_review' if decision else 'local_new' if pools else 'needs_AI'
 return dict(version=VERSION,platform=row.get('platform'),cid=str(row.get('comment_id')),comment_id=str(row.get('comment_id')),text=t,comment_text=t,
             pools=pools,subtags=subtags,evidence=evidence,classification_method=method,
             original_pools=original,original_intent=row.get('interest_at_comment') or row.get('interest') or o.get('interest_at_comment'),original_role=row.get('role') or o.get('role'),
             original_intent_preserved=True,constraints=constraints,missing_references=missing,
             needs_AI=not bool(pools),topic_conflict_blocks_pool_assignment=False,
             context_key=context_key(row),semantic_cache_key=cache_key(row),guard_signature=guard_signature(t),
             cache_reuse_eligible=bool(o.get('post_body') or o.get('direct_parent_text')) and o.get('post_author_same_as_commenter') is False,
             semantic_reference={'source_cid':str(row.get('comment_id')),'method':method,'review_id':decision.get('review_id') if decision else None},
             original_metadata={'published_at':row.get('published_at'),'ip_location_raw':row.get('ip_location_raw'),
                 'target_regions':row.get('target_regions'),'time_mentions':row.get('time_mentions'),
                 'post_body':o.get('post_body'),'reason':o.get('reason'),'direct_parent_text':o.get('direct_parent_text'),
                 'post_author_same_as_commenter':o.get('post_author_same_as_commenter'),'reply_to':o.get('reply_to'),
                 'source_stage':row.get('source_stage'), 'tone':o.get('tone') or (o.get('reply_plan') or {}).get('tone'),
                 'serious_context':o.get('serious_context'), 'source_version_conflict':o.get('source_version_conflict'),
                 'context_flags':o.get('context_flags'), 'contact_boundaries':row.get('contact_boundaries') or o.get('contact_boundaries') or []},send_authorized=False)

def reusable_review(candidate, cached):
 """Similar text alone never permits silent inheritance of a semantic label."""
 return (candidate.get('version')==VERSION and cached.get('version')==VERSION and candidate.get('cache_reuse_eligible') and cached.get('cache_reuse_eligible') and candidate['semantic_cache_key']==cached['semantic_cache_key'] and
         candidate['context_key']==cached['context_key'] and
         candidate['guard_signature']==cached['guard_signature'])

def classify_with_cache(row,cached_rows,review=None):
 """One actual cache/fallback entry. Returns a request, never calls an API.

 A new CID may reuse audited pools for the same normalized utterance and exact
 source context. The original lead intent and availability remain untouched.
 """
 result=classify(row,review)
 if result['pools']:return result
 for item in cached_rows:
  if item.get('classification_method') not in ('existing_AI_reused','current_batch_AI_review','AI_cache_reused'):
   continue
  if item.get('pools') and reusable_review(result,item):
   result.update(pools=list(item['pools']),subtags=list(item.get('subtags') or []),
                 classification_method='AI_cache_reused',needs_AI=False,
                 cache_reference={'platform':item.get('platform'),'cid':item.get('cid'),
                                  'semantic_reference':item.get('semantic_reference')})
   result['evidence'].append({'source':'guarded_semantic_cache','quote':result['text'],
                              'source_cid':item.get('cid'),'context_key':item['context_key']})
   return result
 result['ai_review_request']={'schema_version':'pool-semantic-review-request-v1',
     'platform':result['platform'],'cid':result['cid'],'text':result['text'],
     'context':result['original_metadata'],'existing_intent':result['original_intent'],
     'existing_role':result['original_role'],'allowed_pools':POOLS,
     'output_fields':['pools','subtags','evidence','negative_conditions','choice_relation','uncertainties'],
     'reply_generation_requested':False,'automatic_API_call':False,
     'cache_key':result['semantic_cache_key'],'context_key':result['context_key']}
 return result

def run():
 source=WORK/'high-intent-pools-20261101/all-high-intent-pools.jsonl'
 rows=[json.loads(l) for l in source.open(encoding='utf-8-sig')]
 digest=hashlib.sha256(source.read_bytes()).hexdigest()
 reviews=[json.loads(l) for l in (HERE/'semantic-reviews.jsonl').open(encoding='utf-8')]
 lookup={(r['platform'],r['cid']):r for r in reviews}; counts=collections.Counter(); platforms=collections.defaultdict(collections.Counter)
 out=[]; cache=[]
 for row in rows:
  r=classify(row,lookup);r['source_sha256']=digest;out.append(r)
  counts[r['classification_method']]+=1;counts['assigned' if r['pools'] else 'unassigned']+=1
  platforms[r['platform']]['total']+=1;platforms[r['platform']]['assigned']+=bool(r['pools'])
  if r['classification_method'] in ('existing_AI_reused','current_batch_AI_review'):
   cache.append({k:r[k] for k in ['version','platform','cid','text','pools','subtags','context_key','semantic_cache_key','guard_signature','classification_method','cache_reuse_eligible','semantic_reference']})
 for name,data in [('classified.jsonl',out),('needs-ai.jsonl',[r for r in out if r['needs_AI']]),('semantic-cache.jsonl',cache)]:
  (HERE/name).write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in data),encoding='utf-8')
 assert hashlib.sha256(source.read_bytes()).hexdigest()==digest
 report=dict(version=VERSION,total=len(out),counts=dict(counts),platforms=dict(platforms),coverage=counts['assigned']/len(out),
             source_sha256=digest,output_sha256=hashlib.sha256((HERE/'classified.jsonl').read_bytes()).hexdigest(),
             source_unchanged=True,coverage_is_not_accuracy=True,pure_local_generalization_measured=False,
             measurement='历史高意向快照分池覆盖：复用既有AI标签+本地补充+本轮少量空池语义复核；不是新评论纯规则准确率',
             reviewed_rows=len(reviews),additional_paid_API_calls=0,send_authorized=False)
 (HERE/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
 (HERE/'rules.json').write_text(json.dumps({'version':VERSION,'pools':POOLS,'rules':[dict(pool=p,subtag=s,pattern=x) for p,s,x in RULES]},ensure_ascii=False,indent=2),encoding='utf-8')
 print(json.dumps(report,ensure_ascii=False))

if __name__=='__main__':run()
