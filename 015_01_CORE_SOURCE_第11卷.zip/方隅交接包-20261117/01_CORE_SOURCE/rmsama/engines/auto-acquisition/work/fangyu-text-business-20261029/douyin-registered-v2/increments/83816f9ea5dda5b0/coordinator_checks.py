"""Receipt and exact-context comparison only; never classify or alter judgments."""
import pathlib,json,hashlib,collections,datetime,sys
B=pathlib.Path(__file__).resolve().parent
read=lambda p:[json.loads(l) for l in p.read_text('utf-8-sig').splitlines() if l.strip()]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
put=lambda p,x:p.write_text(json.dumps(x,ensure_ascii=False,indent=2),'utf-8')
src={r['review_key']:r for r in read(B/'input.jsonl')}
primary={r['review_key']:r for i in range(3) for r in read(B/f'reviewed-new-{i}.jsonl')}
assert len(primary)==len(src)==4380 and set(primary)==set(src)
versions={f'reviewed-new-{i}.jsonl':sha(B/f'reviewed-new-{i}.jsonl') for i in range(3)}
for i in range(3):
 v=json.loads((B/f'shard-{i}-validation.json').read_text('utf-8'))
 assert v['input_count']==v['output_count']==v.get('formal_adapter_preflight_passed',v.get('adapter_full_validation_count'))==1460
 assert v.get('semantic_review_sha256',v.get('output_sha256'))==versions[f'reviewed-new-{i}.jsonl']
 assert v['adapter_sha256']=='fff622c0d202f0ddcd1c313723a81fa5efb1f555458f732a5ef9158fe7385cbd'
 isolated=pathlib.Path(v.get('isolated_source',v.get('real_isolated_source')))
 assert sha(isolated)==v.get('isolated_sha256',v.get('real_isolated_source_sha256'))
 pages=b''.join((B/f'AI-pages/shard-{i}/reviewed-{n:02}.jsonl').read_bytes() for n in range(9))
 assert pages==(B/f'reviewed-new-{i}.jsonl').read_bytes()
 shardkeys={r['review_key'] for r in read(B/f'shard-{i}.jsonl')}
 assert {r['review_key']:r for r in map(json.loads,pages.decode('utf-8').splitlines())}=={k:v for k,v in primary.items() if k in shardkeys}
merged={k:dict(v) for k,v in primary.items()};audits={};missing=[]
for i in range(2):
 D=B/f'recall-audit/part-{i}'; task=json.loads((D/'task.json').read_text('utf-8'))
 for s in task['primary_sources']:assert versions[s['path']]==s['sha256']
 for n in range(task['pages']):
  f=D/f'page-{n:02}.audit.jsonl'
  if not f.exists():missing.append(str(f.relative_to(B)));continue
  expected={c['key'] for g in json.loads((D/f'page-{n:02}.json').read_text('utf-8'))['post_groups'] for c in g['comments']}
  rows=read(f);assert len(rows)==len(expected) and {r['review_key'] for r in rows}==expected
  for r in rows:
   k=r['review_key'];assert k not in audits;audits[k]=r
   assert r['decision'] in ('keep','change') and (r['decision']=='change' or r['patch']=={})
   merged[k].update(r['patch'])
groups=collections.defaultdict(list)
for k,r in merged.items():
 s=src[k];groups[(s['video_id'],s['comment_text'],s['post_author_same_as_commenter'],s['direct_parent_text'],s['post_body'],s['source_version_conflict'])].append(r)
conflicts=[]
for g,rs in groups.items():
 labels={(r['role'],r['demand_state'],r['interest']) for r in rs}
 if len(labels)>1:
  conflicts.append({'video_id':g[0],'text':g[1],'post_body':g[4],'same_author':g[2],'parent':g[3],'source_conflict':g[5],'rows':[{'key':r['review_key'],'comment_id':r['comment_id'],'published_at_unix':src[r['review_key']]['published_at_unix'],'role':r['role'],'demand_state':r['demand_state'],'interest':r['interest'],'reason':r['reason'],'reply_plan':r['reply_plan'],'independent_audit':audits.get(r['review_key'])} for r in rs]})
report={'batch':B.name,'initial_records':len(primary),'independent_audit_records_present':len(audits),'missing_audit_pages':missing,'complete_audit_pages':not missing,'core_conflict_groups':len(conflicts),'groups':conflicts,'primary_sha256':versions,'diagnostic_only_not_auto_relabeling':True,'checked_at':datetime.datetime.now().astimezone().isoformat()}
put(B/'post-audit-cross-shard-consistency.json',report)
print(json.dumps({k:v for k,v in report.items() if k not in ('groups','primary_sha256')},ensure_ascii=False))
