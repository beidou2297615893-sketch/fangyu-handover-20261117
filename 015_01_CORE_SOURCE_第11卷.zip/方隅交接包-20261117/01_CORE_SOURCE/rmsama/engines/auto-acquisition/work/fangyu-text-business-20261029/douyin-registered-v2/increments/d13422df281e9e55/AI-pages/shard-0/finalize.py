import pathlib,json,hashlib,collections,sys,datetime,importlib.util
HERE=pathlib.Path(__file__).resolve().parent
BATCH=HERE.parent.parent
W=BATCH.parent.parent.parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return [json.loads(l) for l in p.read_text(encoding='utf-8').splitlines() if l.strip()]
def write(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def jl(p,rs):p.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rs),encoding='utf-8')
pages=[HERE/f'reviewed-{i:02}.jsonl' for i in range(4)]
target=BATCH/'reviewed-new-0.jsonl'
target.write_bytes(b''.join(p.read_bytes() for p in pages))
src=read(BATCH/'shard-0.jsonl');reviewed=read(target)
identity=lambda r:tuple(r[f] for f in ('review_key','comment_id','customer_uid','video_id','platform'))
assert len(src)==len(reviewed)==692
assert len({r['review_key'] for r in reviewed})==692
assert len({r['comment_id'] for r in reviewed})==692
assert set(map(identity,src))==set(map(identity,reviewed))
si={r['review_key']:r for r in src}
quotes=0
for r in reviewed:
    text=si[r['review_key']]['comment_text']
    assert all(q in text for q in r['evidence'])
    for f in ('topics','target_regions','time_mentions','other_constraints','possible_topics','contact_boundaries'):
        for v in r[f]:
            if 'quote' in v:
                assert v['quote'] in text,(r['review_key'],f,v)
                quotes+=1
    assert r['human_confirmed'] is False and r['send_authorized'] is False and r['store_assignment'] is None
    assert r['reply_plan']['preferred_mother_slot'] in (None,1,2,7,13,16,19,25,28,31,34)
    assert 'classification_method' not in r and 'classification_review_source' not in r
module=importlib.util.spec_from_file_location('unchanged_mother_adapter',W/'mother_adapter.py')
adapter=importlib.util.module_from_spec(module);module.loader.exec_module(adapter)
adapter_before=sha(W/'mother_adapter.py')
assert adapter_before=='fff622c0d202f0ddcd1c313723a81fa5efb1f555458f732a5ef9158fe7385cbd'
isolation=[]
for r in reviewed:
    bound=dict(r)
    bound['classification_method']='ai_semantic_initial_and_detailed'
    bound['classification_stages_completed']=['initial_semantic','detailed_semantic']
    isolation.append(bound)
source=HERE/'preflight-semantic-source.jsonl';jl(source,isolation)
digest=sha(source);cache={};errors=[];checked=[]
for r in isolation:
    bound=dict(r)
    bound['classification_review_source']={'path':str(source.relative_to(BATCH)),'sha256':digest}
    try:adapter.validate_new_review(bound,BATCH,cache)
    except Exception as e:errors.append({'review_key':r['review_key'],'error':str(e)})
    checked.append(bound)
jl(HERE/'preflight-bound.jsonl',checked)
assert sha(W/'mother_adapter.py')==adapter_before
counts=dict(collections.Counter(r['interest'] for r in reviewed));roles=dict(collections.Counter(r['role'] for r in reviewed))
validation={'shard':0,'input_count':len(src),'output_count':len(reviewed),'identity_set_equal':True,'identity_fields':['review_key','comment_id','customer_uid','video_id','platform'],'duplicate_keys':0,'duplicate_comment_ids':0,'page_counts':[len(read(p)) for p in pages],'page_concat_byte_equal':target.read_bytes()==b''.join(p.read_bytes() for p in pages),'all_evidence_verbatim':True,'quote_fields_checked':quotes,'reviewed_sha256':sha(target),'source_shard_sha256':sha(BATCH/'shard-0.jsonl'),'official_adapter_preflight':{'call':'mother_adapter.validate_new_review','input_count':len(checked),'passed':len(checked)-len(errors),'errors':errors,'adapter_sha256':adapter_before,'isolated_source_path':str(source),'isolated_source_sha256':digest,'isolated_bound_path':str(HERE/'preflight-bound.jsonl'),'isolated_bound_sha256':sha(HERE/'preflight-bound.jsonl')},'interest_counts':counts,'role_counts':roles,'independent_semantic_review':False,'human_confirmed':False,'send_authorized':False,'platform_calls':0,'source_writes':0,'task_specific_usage':None,'task_specific_usage_status':'unknown','completed_at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
write(BATCH/'shard-0-validation.json',validation)
write(HERE/'progress.json',{'state':'complete','pages_complete':4,'pages_total':4,'comments_complete':692,'comments_expected':692,'primary_semantics':'AI_initial_and_detailed','official_adapter_passed':len(checked)-len(errors),'independent_review_completed':False,'task_specific_usage':'unknown'})
report='''# 本片文字判读结果

已逐条完成692条评论的同轮AI初筛、细筛与认可母句槽位选择。四页分别为180、180、180、152条；汇总逐字节等于四页连接，输入与输出的评论、账号、视频、平台身份集合一致，无重复遗漏。

逐字证据校验通过；未修改的平台与发布适配器对692条真实隔离记录执行SHA绑定结构预检，结果为%s条通过、%s条错误。隔离记录内编译元数据仅用于结构预检；正式文件未伪造编译绑定、独立复核或人工认可。

意向分布：%s。角色分布：%s。

保留短询歧义、纯艾特、供给/经历、工作地和目标地差别、条件预算、宠物、停车、身份边界与入住/看房/租期证据。相对看房日期锚定原发表时间，报价周期不冒充总租期。母句中真实住户、优惠资格、同店同房源事实仍待核；没有重写母句正文。

最终自校对前的页结果及显式决定原字节保存在本片pre-final-review-bytes。自校对调整包括未知主题主体统一为未确定、未来就业设想不当租房、月租模式不当金额、相对日期补原发表锚；这些是同轮细筛修订，不是独立二审。该备份没有覆盖任何原始输入。

human_confirmed=false、send_authorized=false、store_assignment=null。未访问平台、源库、凭据，未发送。现有credits授权有效；本任务实际usage未知，不用账户余额推算。后续独立复核与本地发布按唯一协调授权继续，不能把本片结构通过称作模型准确率或本人验收。
'''%(len(checked)-len(errors),len(errors),json.dumps(counts,ensure_ascii=False),json.dumps(roles,ensure_ascii=False))
(BATCH/'shard-0-report.md').write_text(report,encoding='utf-8')
print(json.dumps(validation,ensure_ascii=False))
assert not errors,errors[:3]
