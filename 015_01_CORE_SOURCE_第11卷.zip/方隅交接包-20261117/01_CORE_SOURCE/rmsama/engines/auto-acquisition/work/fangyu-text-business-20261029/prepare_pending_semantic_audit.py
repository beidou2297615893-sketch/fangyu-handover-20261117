"""Select semantic-review work from model labels; never classify comment text."""
import argparse,json,hashlib,collections,copy
from mother_adapter import validate_new_review
from pathlib import Path
from datetime import datetime,timezone
W=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('--run',required=True);args=p.parse_args()
assert len(args.run)==16 and all(c in '0123456789abcdef' for c in args.run)
B=W/'douyin-registered-v2/increments'/args.run
def read(p):return [json.loads(l) for l in p.read_text(encoding='utf-8').splitlines() if l.strip()]
def put(p,v):
    raw=json.dumps(v,ensure_ascii=False,indent=2).encode('utf-8')
    if p.exists():assert p.read_bytes()==raw, f'Audit input already differs: {p}'
    else:p.write_bytes(raw)
inputs=read(B/'input.jsonl');src={r['review_key']:r for r in inputs}
primary=[r for i in range(3) for r in read(B/f'reviewed-new-{i}.jsonl')]
models={r['review_key']:r for r in primary}
assert len(primary)==len(models)==len(src) and set(models)==set(src)
for k,r in models.items():assert all(r[x]==src[k][x] for x in ['comment_id','customer_uid','video_id'])
# Exercise the locked structural validator in memory. This is not a provenance
# file or a new model stage; the compiler later binds the actual persisted source.
checked=copy.deepcopy(primary)
for r in checked:
    r['classification_method']='ai_semantic_initial_and_detailed'
    r['classification_stages_completed']=['initial_semantic','detailed_semantic']
memory_path=(B/'schema-preflight-in-memory-only.jsonl').resolve()
digest=hashlib.sha256(json.dumps(checked,ensure_ascii=False).encode('utf-8')).hexdigest()
cache={memory_path:(digest,{(r['review_key'],r['comment_id']):r for r in checked})}
for r in checked:
    candidate=copy.deepcopy(r)
    candidate['classification_review_source']={'path':str(memory_path),'sha256':digest}
    validate_new_review(candidate,B,cache)
selected=[];reasons={}
for s in inputs:
    k=s['review_key'];r=models[k];why=[]
    if r['interest']!='high':why.append('non_high_label_recall_or_level_check')
    if r['role']=='mixed':why.append('mixed_supply_and_demand')
    if len(r.get('topics',[]))>=2:why.append('multiple_labeled_constraints')
    if r['reply_plan']['contact_policy']!='allow':why.append('contact_or_identity_limitation')
    if r.get('time_mentions'):why.append('time_interpretation')
    if s.get('reply_to') not in ('0',0,None,''):why.append('reply_context')
    if int(hashlib.sha256(s['comment_id'].encode()).hexdigest()[:8],16)%10==0:why.append('deterministic_tenth_of_remaining_high_labels')
    if why:selected.append(k);reasons[k]=why
assert selected and len(selected)==len(set(selected))
for part in range(2):
    keys=selected[part::2];D=B/f'recall-audit/part-{part}';D.mkdir(parents=True,exist_ok=True)
    for page_no,start in enumerate(range(0,len(keys),120)):
        groups={}
        for k in keys[start:start+120]:
            s=src[k];r=models[k]
            g=groups.setdefault(s['video_id'],dict(video=s['video_id'],post_body=s['post_body'],comments=[]))
            g['comments'].append(dict(key=k,text=s['comment_text'],same_author=s['post_author_same_as_commenter'],published_at=datetime.fromtimestamp(s['published_at_unix'],timezone.utc).isoformat() if s['published_at_unix'] else None,parent=s.get('direct_parent_text'),reply_to=s.get('reply_to'),source_conflict=s['source_version_conflict'],audit_selection=reasons[k],first_semantic_judgment={f:r.get(f) for f in ['role','demand_state','interest','reason','topics','target_regions','time_mentions','other_constraints','possible_topics','needs_review','contact_boundaries','context_used','reply_plan']}))
        put(D/f'page-{page_no:02}.json',dict(purpose='independent_semantic_recall_level_constraints_and_reply_plan_review_not_keyword_reclassification',post_groups=list(groups.values())))
    put(D/'task.json',dict(records=len(keys),pages=(len(keys)+119)//120,expected_review_keys=keys,primary_sources=[dict(path=f'reviewed-new-{i}.jsonl',sha256=hashlib.sha256((B/f'reviewed-new-{i}.jsonl').read_bytes()).hexdigest()) for i in range(3)],output=f'recall-audit-{part}.jsonl',selection_does_not_change_any_judgment=True))
put(B/'semantic-audit-selection.json',dict(selected=len(selected),total=len(src),reason_counts=dict(collections.Counter(x for why in reasons.values() for x in why)),parts=[len(selected[0::2]),len(selected[1::2])],keys=selected,not_accuracy_sample=True,randomized_gold_labels=False))
gate=json.loads((B/'quality-gate.json').read_text(encoding='utf-8'))
gate.update(state='await_independent_semantic_audit',AI_initial_and_detailed_complete=len(src),independent_recall_required=True,independent_recall_calibration_queued=len(selected),expected_audit_parts=[len(selected[0::2]),len(selected[1::2])],publication_allowed=False)
(B/'quality-gate.json').write_text(json.dumps(gate,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(dict(total=len(src),selected=len(selected),parts=[len(selected[0::2]),len(selected[1::2])]),ensure_ascii=False))
