"""Offline incremental sidecar. No model client, platform requests, or source writes.

Reuse the reviewed runner's read-only qualification/metadata transport only.
The unverified historical classifier and its blanket mother selector stay disabled.
"""
import argparse
import collections
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import sqlite3
import time
from datetime import datetime, timezone, timedelta

HERE = Path(__file__).resolve().parent
WORK = HERE.parent
BASE = WORK.parent / 'fangyu-douyin-independent'
spec = importlib.util.spec_from_file_location('local_transport', WORK/'local-rule-pipeline/run_local_pipeline.py')
transport = importlib.util.module_from_spec(spec)
spec.loader.exec_module(transport)
VERSION = 'local-delta-conservative-20261031-v1'


def now():
    return datetime.now(timezone(timedelta(hours=8))).isoformat()


def signature(row):
    # Short replies are not transferable between posts, authors, or parent threads.
    return transport.digest([row.get('comment_text'), row.get('video_id'), row.get('post_body'),
                             row.get('post_author_same_as_commenter'), row.get('reply_to', '0'),
                             row.get('direct_parent_text')])


def initialize(state):
    state.executescript('''
      CREATE TABLE IF NOT EXISTS baseline(cid TEXT PRIMARY KEY);
      CREATE TABLE IF NOT EXISTS semantic_cache(signature TEXT PRIMARY KEY, data TEXT NOT NULL);
      CREATE TABLE IF NOT EXISTS delta(cid TEXT PRIMARY KEY, stage TEXT NOT NULL, data TEXT NOT NULL);
      CREATE TABLE IF NOT EXISTS delta_batches(batch TEXT PRIMARY KEY, data TEXT NOT NULL);
    ''')
    pointer = transport.load_json(BASE/'text-screening-current-summary.json')
    source = Path(pointer['result_file'])
    if transport.meta_get(state, 'baseline_sha') == pointer['result_sha256']:
        return pointer
    if hashlib.sha256(source.read_bytes()).hexdigest() != pointer['result_sha256']:
        raise ValueError('Historical pointer hash mismatch')
    # Import IDs and exact-context semantic references, never reclassify history.
    with source.open(encoding='utf-8-sig') as stream:
        for line in stream:
            if not line.strip():
                continue
            row = json.loads(line)
            state.execute('INSERT OR IGNORE INTO baseline VALUES(?)', (str(row['comment_id']),))
            if (row.get('comment_text') and row.get('post_body') and row.get('video_id')
                    and row.get('post_author_same_as_commenter') is False
                    and str(row.get('reply_to', '0')) == '0'
                    and not row.get('needs_model_review') and not row.get('context_flags')
                    and not row.get('source_version_conflict') and not row.get('contact_boundaries')
                    and row.get('role') in ('demand', 'supply', 'discussion')
                    and row.get('interest_at_comment') in ('high', 'medium', 'low', 'unrelated')):
                ref = {k: row.get(k) for k in ('comment_id', 'role', 'interest_at_comment', 'topics', 'reason')}
                state.execute('INSERT OR IGNORE INTO semantic_cache VALUES(?,?)',
                              (signature(row), transport.dumps(ref)))
    transport.meta_set(state, 'baseline_sha', pointer['result_sha256'])
    state.commit()
    return pointer


def decide(record, cached=None):
    text = record['comment_text']
    result = dict(record, classification_version=VERSION, role='unknown', interest_at_comment='uncertain',
                  demand_state='unknown', classification_stage='uncertain_retained', topics=[],
                  needs_model_review=True, model_calls=0, reply_generation_model_calls=0,
                  assigned_store=None, current_need_verified=False, send_authorized=False,
                  can_send_now=False, mother_reply_text=None, draft_ready=False,
                  ai_initial_screen_completed=False, ai_fine_screen_completed=False,
                  target_region_reference=None, ip_region_hint=record.get('ip_location_raw'),
                  region_status='客户明示地点待核；原始IP仅作区域辅助，不指定城市或门店',
                  time_status='原评论时间保留；当前是否仍求租未确认')
    if record.get('source_error') or record.get('source_version_conflict'):
        result.update(reason='来源结构或身份冲突，保留待核', needs_model_review=False,
                      classification_stage='source_integrity_pending')
        return result
    if not isinstance(text, str):
        result.update(reason='评论正文类型异常，保留待核', needs_model_review=False)
        return result
    if record.get('post_author_same_as_commenter') or str(record.get('reply_to', '0')) != '0':
        result['reason'] = '作者自评或回复链存在主体关系，不自动继承需求'
        return result
    # This small terminal rule concerns an explicit purchase request, not a buy-related keyword hit.
    if (re.fullmatch(r'[^。！？!?\n]{0,65}(?:想买|求购|买一套房|买套房)[。！! ]*', text)
            and not re.search(r'不|没|否|如果|但是|但|租|朋友|别人|他说|她说|[“”"？?]', text)):
        result.update(role='purchase_demand', interest_at_comment='unrelated',
                      classification_stage='local_completed', needs_model_review=False,
                      reason='本人明确表达购买，不作为租房客户；原记录保留',
                      transaction_type='purchase', evidence=[text])
        return result
    if cached:
        result.update(role=cached['role'], interest_at_comment=cached['interest_at_comment'],
                      topics=cached.get('topics') or [], classification_stage='local_completed',
                      needs_model_review=False, evidence=[text],
                      reason='原文、同一作品正文及主体/回复关系完全一致，复用已有语义标签',
                      semantic_reference_cid=cached['comment_id'],
                      classification_method='exact_context_semantic_cache')
        return result
    # A narrow local completion lane. All negation, mixed supply, beneficiaries, dates,
    # conditional language, and referential requests remain explicit uncertainties.
    if (re.match(r'^(?:你好[，, ]*)?(?:求租|我(?:想|要|正在|还在)?(?:租|找房|找个房|找一套))', text)
            and re.search(r'租|找房|房子|公寓|单间|[一二三四两1234]室', text)
            and not re.search(r'不|没|无|已|以前|之前|曾|去年|明年|个月后|转租|出租|招租|房东|中介|帮|朋友|家人|父母|孩子|他|她|如果|但是|只是|[“”"]', text)):
        result.update(role='demand', interest_at_comment='high', demand_state='active_at_comment',
                      classification_stage='local_completed', needs_model_review=False,
                      classification_method='narrow_explicit_self_rental', evidence=[text],
                      reason='本人直接求租；复杂主体、否定及时间情形不走此本地通道')
    else:
        result['reason'] = '未命中已核对的明确场景或同语境缓存，集中留待语义判读，不当作低意向删除'
    return result


def add_pool_draft(result, config, mothers):
    text = result['comment_text']
    if (result['role'] != 'demand' or result['classification_stage'] != 'local_completed'
            or result['interest_at_comment'] not in ('high', 'medium', 'super_high')):
        return
    pools = [p.get('pool') if isinstance(p, dict) else p for p in result.get('topics') or []]
    pools = [p for p in pools if p]
    for pool, words in config['topics'].items():
        if any(word in text for word in words) and pool not in pools:
            pools.append(pool)
    if re.search(r'预算|\d+(?:元|块|k|K)', text) and '价格预算' not in pools:
        pools.append('价格预算')
    if re.search(r'[一二三四两1234](?:室|居)|单间|套[一二三四1234]', text) and '户型面积与居住方式' not in pools:
        pools.append('户型面积与居住方式')
    result['topics'] = pools
    result['pool_assignment_method'] = '需求身份确认后本地多标签；原文条件完整保留'
    # Only static, already presented short families. No inventory/policy assertions.
    family = None
    if len(pools) > 1:
        result['reply_gap'] = '多需求组合保留原文；不退回统一介绍句，待已有组合家族适配'
        return
    mapping = {'价格预算':'price', '位置通勤':'location', '宠物':'pet',
               '楼层电梯':'floor', '入住与租期':'urgent', '房源状态':'available', '看房联系':'contact_how'}
    if len(pools) == 1:
        family = mapping.get(pools[0])
    if family == 'pet':
        family = ('pet_cat' if '猫' in text and not re.search(
            r'狗|不养猫|不带猫|没养猫|没有猫|不要猫|不接受猫|多猫|\d+只猫', text) else None)
    # Ask variants requiring specific subject or timing evidence cannot be used generically.
    if family in ('pet', 'urgent', 'contact_how'):
        family = None
    if family and '{' not in mothers.get(family, ''):
        result.update(mother_family=family, mother_reply_text=mothers[family], draft_ready=True,
                      reply_status='按池本地草稿；未发送',
                      mother_approval_scope='已获认可的短句方向；变体非逐句认可',
                      fact_gaps=['住户账号与优惠适用事实仍须核实'])
    else:
        result['reply_gap'] = '当前已有母句缺适配或必要事实，留存缺口，不编房源信息'


def sweep():
    directory = HERE/'state'
    state = transport.open_state(directory)
    try:
        baseline = initialize(state)
        source = transport.open_source(BASE/'runtime/collection.sqlite3')
        try:
            policy = transport.load_json(transport.DEFAULT_POLICY)
            transport.refresh_metadata(source, state, 'douyin', policy)
            keys = [r[0] for r in state.execute(f'''SELECT DISTINCT o.stable_key FROM observations o
                JOIN qualified q ON {transport.QUALIFIED_JOIN}
                LEFT JOIN baseline b ON b.cid=substr(o.stable_key,9)
                LEFT JOIN delta d ON d.cid=substr(o.stable_key,9)
                WHERE o.platform='douyin' AND b.cid IS NULL AND d.cid IS NULL
                ORDER BY o.source_rowid LIMIT 500''')]
            config = transport.load_json(WORK/'local-rule-pipeline/rule_config.json')
            mothers = transport.load_json(WORK/'pool-mother-review/pool-mother-short-variants.json')['templates']
            override=WORK/'pool-mother-review/approved-mother-overrides-20261101.json'
            if override.exists():
                mothers.update(transport.load_json(override)['templates'])
            rows = []
            for key in keys:
                record = transport.make_record(source, state, 'douyin', key, VERSION)
                # Preserve actual acquisition identities alongside the existing source transport.
                record['source_accounts'] = [r[0] for r in state.execute(
                    f'SELECT DISTINCT o.account_uid FROM observations o JOIN qualified q ON {transport.QUALIFIED_JOIN} '
                    'WHERE o.platform=? AND o.stable_key=?', ('douyin',key))]
                found = state.execute('SELECT data FROM semantic_cache WHERE signature=?', (signature(record),)).fetchone()
                result = decide(record, json.loads(found[0]) if found else None)
                add_pool_draft(result, config, mothers)
                result['processed_at'] = now()
                rows.append(result)
            source.rollback()
            if source.total_changes != 0:
                raise RuntimeError('Read-only source invariant failed')
        finally:
            source.close()
        batch = datetime.now().strftime('%Y%m%dT%H%M%S')+'-'+str(time.time_ns())
        folder = directory/'increments'/batch
        if rows:
            folder.mkdir(parents=True)
            payload = ''.join(transport.dumps(r)+'\n' for r in rows)
            path = folder/'results.jsonl'
            path.write_text(payload, encoding='utf8')
            receipt = {'batch':batch, 'processed_at':now(), 'new_cids':[r['comment_id'] for r in rows],
                       'rows':len(rows), 'stages':dict(collections.Counter(r['classification_stage'] for r in rows)),
                       'result_file':str(path), 'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
                       'source_database_modified':False, 'model_calls':0, 'platform_calls':0, 'sent':0}
            transport.atomic_json(folder/'receipt.json', receipt)
            for r in rows:
                state.execute('INSERT INTO delta VALUES(?,?,?)', (r['comment_id'], r['classification_stage'], transport.dumps(r)))
            state.execute('INSERT INTO delta_batches VALUES(?,?)', (batch, transport.dumps(receipt)))
            state.commit()
        stage_counts = dict(state.execute('SELECT stage,count(*) FROM delta GROUP BY stage'))
        eligible = state.execute(f'''SELECT count(DISTINCT o.stable_key) FROM observations o
                    JOIN qualified q ON {transport.QUALIFIED_JOIN} WHERE o.platform='douyin' ''').fetchone()[0]
        summary = {'checked_at':now(), 'platform':'douyin', 'worker_pid':os.getpid(),
                   'historical_published':baseline['snapshot_unique_comments'], 'historical_sha256':baseline['result_sha256'],
                   'eligible_registered':eligible, 'new_sidecar_records':sum(stage_counts.values()),
                   'local_classification_completed':stage_counts.get('local_completed',0),
                   'ai_semantic_review_completed':stage_counts.get('ai_semantic_review_completed',0),
                   'ai_reviewed_unresolved':stage_counts.get('ai_reviewed_unresolved',0),
                   'uncertain_retained':stage_counts.get('uncertain_retained',0),
                   'source_integrity_pending':stage_counts.get('source_integrity_pending',0),
                   'new_this_sweep':len(rows), 'source_read_only':True, 'platform_calls':0,
                   'worker_model_calls':0, 'sent':0, 'historical_results_modified':False,
                   'old_classifier_enabled':False, 'canonical_publication_pointer_modified':False,
                   'continuous_local_poll_seconds':60, 'model_heartbeat_resumed':False,
                   'result_store':str(directory/'derived.sqlite3'),
                   'uncertainty_policy':'集中留存；不自动启动AI；分类未完成不得计为已完成'}
        transport.atomic_json(directory/'current.json', summary)
        # Only NEW unresolved rows go into the durable review queue, with every ID included.
        with (directory/'uncertain-review-queue.jsonl').open('w',encoding='utf8') as f:
            for (raw,) in state.execute("SELECT data FROM delta WHERE stage IN ('uncertain_retained','source_integrity_pending','ai_reviewed_unresolved') ORDER BY cid"):
                f.write(raw+'\n')
        (directory/'本地接续进度.txt').write_text(
            f'抖音文字增量进度（{summary["checked_at"]}）\n'
            f'历史已发布分类：{summary["historical_published"]}条，原结果保留。\n'
            f'本地新增登记：{summary["new_sidecar_records"]}条；其中已明确判断'
            f'{summary["local_classification_completed"]}条、语义待核'
            f'{summary["uncertain_retained"]}条、来源待核{summary["source_integrity_pending"]}条。\n'
            f'新增中已做小批AI语义补判{summary["ai_semantic_review_completed"]}条，'
            f'补判后仍缺语境{summary["ai_reviewed_unresolved"]}条；以上不是独立二审或人工金标。\n'
            '待核不等于低意向；未完成分类的不计为已分类。已判断也不代表有可发送回复。\n'
            '本地每60秒检查新增；没有模型定时唤醒，不自动派AI、不重跑历史、不发送。\n'
            '本地明确场景和同语境缓存优先；不匹配的集中留存，旧未验收分类器保持关闭。\n',
            encoding='utf8')
        return summary
    finally:
        state.close()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--watch',action='store_true')
    args = parser.parse_args()
    HERE.mkdir(exist_ok=True)
    with (HERE/'worker.lock').open('a+b') as lock:
        import msvcrt
        lock.seek(0)
        if lock.read(1) == b'':
            lock.write(b'0'); lock.flush()
        lock.seek(0)
        msvcrt.locking(lock.fileno(),msvcrt.LK_NBLCK,1)
        while True:
            try:
                result = sweep()
                transport.atomic_json(HERE/'worker-health.json', {'state':'healthy','pid':os.getpid(), 'checked_at':now(),
                                      'new_this_sweep':result['new_this_sweep']})
                if result['new_this_sweep'] or not args.watch:
                    print(json.dumps(result,ensure_ascii=True),flush=True)
            except Exception as exc:
                transport.atomic_json(HERE/'worker-health.json', {'state':'failed','pid':os.getpid(),
                                      'checked_at':now(),'error_type':type(exc).__name__,'error':str(exc)})
                raise
            if not args.watch:
                break
            time.sleep(60)


if __name__ == '__main__':
    main()
