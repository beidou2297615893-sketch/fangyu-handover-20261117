import json, pathlib, hashlib, datetime, collections, sys
HERE=pathlib.Path(__file__).resolve().parent
BATCH=HERE.parent.parent
W=BATCH.parent.parent.parent
SRC=[json.loads(x) for x in (BATCH/'shard-0.jsonl').read_text(encoding='utf-8').splitlines() if x.strip()]
INDEX={r['review_key']:r for r in SRC}
MOTHERS={r['slot']:r for r in json.loads((W/'approved-mothers-model-view.json').read_text(encoding='utf-8'))}
POOLS={'P':'价格预算','L':'位置通勤','H':'户型面积与居住方式','F':'房内设施','G':'宠物','E':'楼层电梯','T':'入住与租期','A':'房源状态','C':'费用合同','V':'看房联系'}
CODES={'h':('demand','active_at_comment','high'),'s':('demand','active_at_comment','super_high'),'m':('demand','active_at_comment','medium'),'a':('demand','unknown','medium'),'u':('unknown','unknown','uncertain'),'d':('discussion','unknown','unrelated'),'p':('supply','unknown','unrelated'),'e':('demand','ended','unrelated'),'f':('demand','future','low'),'x':('mixed','unknown','medium'),'n':('demand','active_at_comment','unrelated')}
POL={'?':'ask','r':'require','p':'prefer','!':'reject','+':'accept','c':'conditional','f':'fact','n':'not_required','=':'compare','u':'unknown'}
def dump(p,obj): p.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def jsonl(p,rs): p.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rs),encoding='utf-8')
def build(page):
    raw=(HERE/f'decisions-{page:02}.txt').read_text(encoding='utf-8')
    decisions=[]
    for line in raw.splitlines():
        if not line.strip():continue
        bits=line.split('|',5)
        if len(bits)<5: raise ValueError(line)
        key,code,pools,slot,reason=bits[:5]
        extra=json.loads(bits[5]) if len(bits)==6 else {}
        s=INDEX[key]; role,state,interest=CODES[code]; text=s['comment_text']
        out={k:s[k] for k in ('review_key','platform','comment_id','customer_uid','video_id')}
        topics=[]
        for token in [t.strip() for t in pools.split(',')] if pools!='-' else []:
            subject={'p':'supply','d':'unresolved','u':'unresolved','e':'current_home'}.get(code,'own_demand')
            topics.append({'pool':POOLS[token[0]],'quote':text,'polarity':POL[token[1:]] if len(token)>1 else 'ask','subject':subject,'condition_scope':extra.get('scope')})
        regions=[]
        for reg in extra.get('regions',[]):
            # Explicit model-authored region triples; this helper performs no text inference.
            relation,quote,*rest=reg
            regions.append({'text':rest[0] if rest else quote,'quote':quote,'relation':relation,'group_relation':extra.get('group','unknown'),'condition_scope':extra.get('scope')})
        times=[]
        anchor=datetime.datetime.fromtimestamp(s['published_at_unix'],datetime.timezone.utc).isoformat()
        for tm in extra.get('times',[]):
            quote,trole,verification,*norm=tm
            times.append({'quote':quote,'time_role':trole,'anchor_source':'本人评论可信发表时间','anchor_time':anchor,'normalized':norm[0] if norm else None,'verification':verification})
        slot=None if slot=='-' else int(slot)
        generic=slot is not None and role in ('demand','mixed') and state in ('active_at_comment','future')
        missing=[]
        if slot is not None:missing.append(MOTHERS[slot]['required_facts'])
        if generic and slot!=1:missing.append(MOTHERS[1]['required_facts'])
        if generic:missing.append('客户当前需求及目标城市、门店承接与对应房源尚待核实；原帖事实不代表方隅房源事实')
        reviews=extra.get('review',[])
        if role in ('demand','mixed'):reviews+=['评论时意向不等于今日需求，需核是否仍找房及当前承接房源']
        if code in ('u','a','m','x'):reviews+=[reason]
        boundary=extra.get('boundaries',[])
        out.update(role=role,demand_state=state,interest=interest,topics=topics,target_regions=regions,time_mentions=times,other_constraints=[{'quote':q,'detail':detail} for q,detail in extra.get('constraints',[])],possible_topics=[{'quote':q,'candidate_pools':[POOLS[p] for p in ps],'ambiguity':amb} for q,ps,amb in extra.get('possible',[])],evidence=[text] if text else [],reason=reason,context_used=['own','body'],needs_review=reviews,contact_boundaries=[{'quote':q,'scope':scope} for q,scope in boundary],context_flags={'post_author_same_as_commenter':s['post_author_same_as_commenter'],'source_version_conflict':s['source_version_conflict'],'post_conditions_not_transferred':True},reply_plan={'preferred_mother_slot':slot,'generic_intro_suitable':extra.get('generic',generic),'tone':extra.get('tone','normal'),'missing_facts':missing,'caution':extra.get('caution',[])+(['只作认可母句候选，未核事实不能据此声称已满足；不等于发送授权'] if slot else ['未形成适合主动介绍的确定需求，保留原语义待核']),'contact_policy':extra.get('contact','identity_restricted' if boundary else 'allow')},human_confirmed=False,send_authorized=False,store_assignment=None)
        for field,replace in extra.get('replace',{}).items():out[field]=replace
        for field in ('topics','target_regions','time_mentions','other_constraints','possible_topics','contact_boundaries'):
            for item in out[field]:
                if 'quote' in item and item['quote'] not in text:raise ValueError((key,field,item['quote']))
        decisions.append(out)
    page_data=json.loads((HERE/f'page-{page:02}.json').read_text(encoding='utf-8'))
    keys=[c['key'] for g in page_data['shared_post_context'] for c in g['comments']]
    assert len(decisions)==len(keys)==len({r['review_key'] for r in decisions})
    assert set(keys)=={r['review_key'] for r in decisions},(set(keys)-{r['review_key'] for r in decisions})
    # Preserve original page order and source identity without defaulting any decision.
    by_key={r['review_key']:r for r in decisions};decisions=[by_key[k] for k in keys]
    jsonl(HERE/f'reviewed-{page:02}.jsonl',decisions)
    dump(HERE/f'progress-{page:02}.json',{'page':page,'input_count':len(keys),'output_count':len(decisions),'exact_keys':True,'explicit_decisions':True,'evidence_verbatim':True,'status':'semantic_initial_and_detailed_complete','independent_review':False,'usage':'unknown'})
    print(json.dumps({'page':page,'count':len(decisions),'interest':dict(collections.Counter(r['interest'] for r in decisions))},ensure_ascii=False))
if __name__=='__main__':build(int(sys.argv[1]))
