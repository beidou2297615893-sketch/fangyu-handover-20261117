# 母句适配实现记录

范围：复用原发布脚本，按已完成的 AI 结构化评审选择认可母句；没有基于评论文字本地识别语义或生成逐条回复。未运行生产发布，未修改生产源库、冻结输入、评审原件、母句库、主结果指针、软件或平台，未采集或发送。

- 新评审使用 reply_plan 的适用性、严肃语气、事实缺口与联系政策；专项母句仅留候选及缺口；无核实房源 facts 时只可选已认可的第 1 条通用介绍，并注明具体问题尚未回答。
- 严肃语气去开头“宝宝”；身份限制保留并标人工核；明确 no_contact 不入队。缺联系政策且 AI 来源注记为 ai_semantic_initial_and_detailed 或 ai_independent_semantic_fine_review，且 contact_boundaries 明确为空时按无已识别限制；非空、无来源注记或缺字段为 unknown 人工核。外部合并流程负责提供真实、可核的分类方法注记，适配器不推断模型来源。
- 没有 reply_plan 的历史稿及其原调用计数保留；同平台同 UID 根据可信时间判断后续明确结束，旧稿保留备选；时间未知不强排先后，跨平台分开。各客户每平台最多一个主候选，其余保留备选。发送权限始终关闭。
- 数据库采用 URI mode=ro 且 PRAGMA query_only=ON；仅基于 observation 的 request_id + stable_key 和 attempt 的显式 account_uid 做派生溯源，不读取凭据内容；来源缺失或账号不一致标人工核、不猜。历史评论者 UID 与采集账号分开。
- 来源冲突仅增加待核，不改已有分类结论；分类原因不被母句理由覆盖。reply_generation_model_calls=0 仅指新草稿本地套句，不代表分类模型未调用。

验证命令：
```
python -m unittest discover -s work/fangyu-text-business-20261029 -p test_mother_adapter.py -v
python -m py_compile work/fangyu-text-business-20261029/mother_adapter.py work/fangyu-text-business-20261029/publish_douyin_increment_snapshot.py
```
最新结果：10 项通过；编译通过。真实端到端进程在临时目录使用合成 SQLite、合成冻结输入和合成输出，确认源 SQLite 和冻结观察字节不变。初次红灯为适配器缺失；另分别以有混合新需求但意向不确定、已核 AI 空联系边界、历史模型调用计数三处变更观察预期失败后修复并转绿。首次端到端夹具因测试数据漏写 send_authorized 而失败，补全夹具后通过；该失败不是生产代码缺陷。

限制：没有真实门店房源核实输入，不输出专项事实；通用接话及身份、优惠、联系、时效须人工复核。模型分类与回复适用性为初判，非人工金标；没有真实平台回执和发送授权。测试证明合成夹具行为，不证明真实批次数据语义正确。独立审查待完成。

SHA256：
- `mother-adapter-implementation/publisher-before.py`: `495a4628e631af62f5c0130a7edbf742cd195ba31eb2371e7fb59ebdd7ef9256`
- `publish_douyin_increment_snapshot.py`: `374e9b6f6911046337452245f910d450722c9dc6aa8ad6890ffd6bd66e6d8419`
- `mother_adapter.py`: `d22f028aa7e7c163df998b0a046887d84c8888f302a5d5f7669342fb7682d858`
- `test_mother_adapter.py`: `f92fe415d8724030b59a29430143e19dbfab4136c7d7462f47a3f6e1deb8e954`
