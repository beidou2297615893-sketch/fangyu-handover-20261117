# 母句适配：一次完整修复波次

结论：已完成 I1–I3 及文字任务发送状态口径修复；原 10 项测试保留，新增 7 组回归后共 17 项通过。没有运行生产 publish，没有改源库、原评审、母句库或主结果指针，没有平台调用或发送。等待一次定向复审，不自行合入生产。技术通过不代表用户内容认可或真实平台验收。

## 版本与范围

实际修改仅为同目录 `mother_adapter.py`、`publish_douyin_increment_snapshot.py`、`test_mother_adapter.py`，以及本修复波次的证据文件。修改前将三文件逐字备份到 `fix-wave-before/`，`fix-wave-before/shas.json` 与原 `review-shas.json` 完全一致。原最终审查、实施报告和 probes 没有覆盖。

现有已验证的确定性本地适配路线直接增量修复，没有另造分类器、服务或发送系统。只基于既有模型结构化语义决定适配，不从评论文字用关键词、正则或本地规则重判意向。住户推荐口气继续允许；身份与优惠事实等待审核不等于所有稿件禁止生成。

## I1：新评审完整性及来源门槛

- 在新评审归一兼容之前、正式结果和主摘要写入之前，校验必需字段、角色/需求状态/意向枚举、结构化列表及有关子字段、`reply_plan` 必需项与类型、确认/授权/门店状态。新增缺 plan 或非法 state 报错携带 review_key，不再走历史例外。
- AI 明确 `generic_intro_suitable=false` 是有效完成记录，可发布“暂不生成”结论；并非处理遗漏。
- `classification_method` 必须区分 `ai_semantic_initial_and_detailed` 与 `ai_independent_semantic_fine_review`。对应 `classification_stages_completed` 分别要求 `[initial_semantic,detailed_semantic]` 与再含 `independent_semantic`。这些是既有阶段的登记，不代表本轮新调用模型。
- 每行携带 `classification_review_source={path,sha256}`，路径解析后限在当前冻结批次 S 内。源文件哈希、review_key+comment_id 和整条语义行精确绑定；传输行除来源指针外须与来源行完全一致。每个文件只读一次并缓存哈希与身份索引，避免逐条重读全量文件。
- 正式合并可使用主任务生成的 `semantic-final.jsonl` 作为来源，它只是原语义及明确 patch 的合并，不是又一轮独立模型全判。原始模型输出和独立召回复核证据仍须由主任务保留并验证其 provenance；本门槛证明文件/记录/阶段登记的一致，不单凭哈希证明模型确实执行过。
- 兼容真实原件中的 `interest/needs_review/store_assignment`、`context_flags` 为 dict 或 list，以及 pilot 缺 contact_policy 的原有 AI 空边界规则。历史无 plan 保留原稿、母句选择和历史分类/回复模型调用数。

负向子进程覆盖 12 类缺字段/非法 schema（缺 plan、非法 state、缺 suitability、缺首选槽位、非文字事实列表、缺 reason、缺联系边界、缺阶段、坏时间、坏边界、坏其他条件、坏候选主题），以及 6 类来源错误（缺来源、错 SHA、批次外路径、错误方法、来源行理由不符、阶段证据不符）。失败时预置的正式快照、源侧快照、主摘要和人读 TXT 均保持原字节。

## I2：实际通用稿的事实缺口

实际选用 slot 1 时，将其 required_facts 并入 reply_missing_facts，并按完整文本去重。计划原缺口、首选专项缺口与实际通用优惠缺口同时保留；首选 28/19/34 回退和首选 1 均覆盖。专项事实未核实仍只留候选，不向正文补房源、价格、房态或优惠条件。严肃语气只去掉原句开头“宝宝”。

同时增加最小的当前通用句保护：实际输出只允许与当前已认可 slot 1 原句逐字一致，且存在明确的 required_facts。未来若 slot 1 换成占位符或具体房源断言，将在正式结果写入前拒绝；须重新审阅并更新允许的通用句版本。这里比较的是模板版本，不对客户原文分类，也没有新不可解释黑名单。真实母句库当前 slot 1 与该原句已只读核对一致。

## I3：正式逐条人读材料完整性

逐条按业务语言输出有意义的联系限制及身份要求、实际优惠/推荐/房源待核条件、接话提醒、具体问题尚未回答及真实答复范围、时间线待核、来源账号冲突或缺失、审核状态、暂缓原因和保留备选稿。无对应问题时不加空栏目；历史采集账号与评论者分别说明，不冒称当前登录身份已认证。

测试通过实际隔离 publisher 生成 TXT，验证 identity_restricted、unknown、no_contact、未知时间结束信号、采集账号冲突均能在人读正文看到。明确拒联没有新主稿；家庭等语境不因 context_flags 一刀切禁稿。机器 JSON 保留原身份、评论文本、时间、来源观察与全部审核字段，可与人读条目的原评论/时间/搜索来源相互核对；人读文本不直接输出程序字段、本机路径或规则代号。

`mother-drafts.jsonl` 继续仅供人工审核；summary 明示 `draft_purpose=human_review_only_not_cli_send_input`、`send_approved_records=0`。所有行 send_authorized/can_send_now 均 false。本范围没有实现 CLI 消费或发送守门，不能宣称平台发送链已拦截或验收。

## 发送状态真实性

兼容 `send_attempted=false` 与 summary.actual_sent=0，但增加 `send_attempted_scope` / `actual_sent_scope=text_processing_task_only`、`text_task_send_attempted=false` 和 `platform_delivery_state=not_checked_by_text_task`。人读逐条及汇总明确：“本窗口未发送；平台真实发送状态以发送账本为准。”

这些字段只描述本地文字处理任务，不覆盖、读取或推断其他窗口维护的平台真实回执，更不代表全账号历史未发送。未来软件发送去重和未知回执守门仍需在发送链实现，本波次没有实现发送。

## TDD 与验证证据

1. 修改前原 10 项全部通过。
2. 先写 7 组回归，未修实现时 `fix-wave-red.txt` 留存 18 个预期失败。首次夹具 stderr 受 Windows 默认编码影响，改子进程显式 `-X utf8` 后重新取得纯断言失败的红灯；没有把夹具编码错误算成生产缺陷。
3. 加强子字段完整性复现后 `fix-wave-schema-red.txt` 留存 4 个预期失败，补最小校验转绿。
4. 最终完整子项目发现命令：`python -X utf8 -m unittest discover -s work/fangyu-text-business-20261029 -v`，17 项通过，最后一次 2.961 秒；完整输出 `fix-wave-final-tests.txt`。早期绿灯也留在 `fix-wave-green.txt`。原历史保留、跨平台隔离、时间线及只读账号回溯测试全部保留。
5. `python -X utf8 -m py_compile work/fangyu-text-business-20261029/mother_adapter.py work/fangyu-text-business-20261029/publish_douyin_increment_snapshot.py work/fangyu-text-business-20261029/test_mother_adapter.py`：exit 0。
6. 所有 publisher 子进程使用 TemporaryDirectory 中的合成 SQLite、冻结输入、评审源、母句库和输出。每次调用后对临时源 SQLite、历史快照、冻结输入、来源观察和母句夹具逐项比较 SHA，确认未写；失败用例还验证既有正式材料保持不变。没有拿活源数据库整文件哈希做前后比较。
7. 另对真实 5806 条静态评审做只读 schema 兼容探针：仅在内存/临时文件合成来源登记，5806 条全通过，缓存文件数 1，耗时约 1.703 秒。`fix-wave-schema-compatibility.json` 留存原静态评审文件 SHA 前后完全相同的证据。这个探针不运行生产 publisher，也不证明正式合并 provenance 或全量语义准确率。

## 新 SHA256

- mother_adapter.py：`fff622c0d202f0ddcd1c313723a81fa5efb1f555458f732a5ef9158fe7385cbd`
- publish_douyin_increment_snapshot.py：`b3653a7a7ddad1786cd05cf9aab05dc8bbdc2ac4b68cec1dc3f72d639cb147b7`
- test_mother_adapter.py：`5a94d3ed332999bef3750fe866e8a82d008fc415c2afd3efaa01e8e68666c5d5`

另存机器清单 `fix-wave-shas.json`。若后续修改三文件，应以新冻结 SHA 再审，不能沿用本报告的精确版本结论。

## 尚未验证的边界

D0766/D4363 及弱意图/看房等级校准由独立语义队列处理，本波次不改其原评审。正式合并输入及逐层 provenance 由主任务核对，随后一次定向复审 I1–I3 与语义修订即可。仍未做真实门店房源核实、人工文案认可、账号登录认证、生产 publish 或平台发送；不声称零漏判、准确率或真实发送完成。
