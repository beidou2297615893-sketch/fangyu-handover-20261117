import json,pathlib,hashlib,collections,datetime
O=pathlib.Path(__file__).resolve().parent;D=O.parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
expected={'shard1.jsonl':'a7a9d899911f4674b88aba009034c5e26c4050d34961c8f21afb708fbb3ec0bc','shared-contexts.json':'51a52ebb65825d447a3a17db3b3cb416099a84c857a25418803dae9a9b8015ca'}
errors=[];checks={}
for f,h in expected.items():checks[f+'_sha_unchanged']=sha(D/f)==h
r=[json.loads(l) for l in (D/'shard1.jsonl').read_text(encoding='utf-8').splitlines()];z=[json.loads(l) for l in (O/'labels.jsonl').read_text(encoding='utf-8').splitlines()];c=json.loads((D/'shared-contexts.json').read_text(encoding='utf-8'))
keys=['platform','cid','uid','source_comment_sha256'];identity=lambda a:tuple(a[k] for k in keys)
checks['133_input_133_output']=len(r)==len(z)==133
checks['no_duplicate_platform_cid']=len({(a['platform'],a['cid']) for a in z})==len(z)
checks['exact_identifier_coverage_and_order']=[identity(a) for a in r]==[identity(a) for a in z]
checks['comment_sha256_recomputed']=all(hashlib.sha256(a['comment'].encode('utf-8')).hexdigest()==a['source_comment_sha256'] for a in r)
required=set(keys+['reference_mentions','price_relation','place_relation','time_relation','brand_source_relation','contact_action_direction','evidence','unresolved_or_missing'])
allowed=required|{'housing_purpose'}
checks['required_fields_only']=all(required<=set(a)<=allowed for a in z)
checks['no_role_state_interest_reply_fields']=all(not(set(a)&{'role','demand_state','interest','reply','reply_text','draft','target_regions'}) for a in z)
checks['context_hash_links_match']=all(c['posts'][a['context_key']]['content_sha256']==a['context_sha256'] for a in r)
checks['direct_parent_missing_preserved']=all('direct_parent: unknown（父评未提供）' in a['unresolved_or_missing'] for a in z)
checks['no_unknown_brand_negative_claim']=all(not any('不是方隅' in u for u in a['unresolved_or_missing']) for a in z if a['brand_source_relation']=='unknown')
checks['unknown_brand_has_missing_note']=all(any('brand/source: unknown' in u for u in a['unresolved_or_missing']) for a in z if a['brand_source_relation']=='unknown')
quote_count=0
for i,(x,a) in enumerate(zip(r,z)):
 ctx=c['posts'][x['context_key']]['content'];src={'comment':x['comment'],'post_title':ctx.get('post_title') or '', 'post_body':ctx.get('post_body') or '', 'direct_parent':''}
 def walk(node):
  global quote_count
  if isinstance(node,dict):
   if 'quote' in node:
    quote_count+=1
    if not node.get('source') in src or not node['quote'] or node['quote'] not in src[node['source']]:errors.append({'row':i,'invalid_quote':node})
   for v in node.values():walk(v)
  elif isinstance(node,list):
   for v in node:walk(v)
 walk(a)
 for ref in a['reference_mentions']:
  if not ref.get('span') or ref['span'] not in x['comment']:errors.append({'row':i,'invalid_span':ref})
  if not {'span','reference_type','referent_type','evidence'}<=set(ref):errors.append({'row':i,'invalid_reference_shape':ref})
 if a['brand_source_relation'] not in ['explicit_fangyu','explicit_other_source','unknown']:errors.append({'row':i,'brand_enum':a['brand_source_relation']})
 if a['contact_action_direction'] not in ['commenter_initiates','asks_other_to_contact_commenter','asks_method','no_contact_action','unknown']:errors.append({'row':i,'contact_enum':a['contact_action_direction']})
 if a['housing_purpose'] not in ['residential_evident','nonresidential_evident','unknown']:errors.append({'row':i,'housing_enum':a['housing_purpose']})
 for f,en in [('price_relation',['original_post_quote_confirmation','price_range_for_new_search','price_comparison','price_inquiry_unspecified','not_price','unknown']),('place_relation',['original_post_place','commenter_current_place','commenter_desired_place','commenter_workplace','unspecified','unknown']),('time_relation',['calendar_period','rent_duration','price_cycle','relative_time','other','unknown'])]:
  for v in a[f]:
   if v.get('relation') not in en:errors.append({'row':i,'field':f,'invalid_relation':v})
checks['all_quote_spans_valid']=not errors
checks['all_direct_parent_contexts_unknown']=all(c['parents'][a['parent_context_key']]['content']['availability']=='unknown' and c['parents'][a['parent_context_key']]['content']['parent_text'] is None for a in r)
checks['input_shared_sha_after_unchanged']=all(sha(D/f)==h for f,h in expected.items())
valid=all(checks.values()) and not errors
stats={'by_platform':dict(collections.Counter(a['platform'] for a in z)),'brand_source_relation':dict(collections.Counter(a['brand_source_relation'] for a in z)),'contact_action_direction':dict(collections.Counter(a['contact_action_direction'] for a in z)),'price_relation':dict(collections.Counter(v['relation'] for a in z for v in a['price_relation'])),'time_relation':dict(collections.Counter(v['relation'] for a in z for v in a['time_relation'])),'housing_purpose':dict(collections.Counter(a['housing_purpose'] for a in z))}
result={'status':'PASS' if valid else 'FAIL','scope':'133-record local semantic reference supplement only','checks':checks,'records':len(z),'quote_occurrences_checked':quote_count,'errors':errors,'input_sha256':{f:sha(D/f) for f in expected},'labels_sha256':sha(O/'labels.jsonl'),'statistics':stats,'actual_usage':'unknown','no_accuracy_or_human_gold_claim':True}
(O/'validation.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(result,ensure_ascii=False,indent=2));raise SystemExit(0 if valid else 1)
