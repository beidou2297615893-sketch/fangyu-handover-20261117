"""Run existing readers in a shadow workspace; original SQLite and sources read-only."""
import pathlib,sys,json,hashlib,subprocess,os,shutil
O=pathlib.Path(__file__).resolve().parent;W=O.parents[1];ROOT=W.parents[1];dst=O/'isolated-consumer-check';shadow=dst/'shadow';sw=shadow/'work/fangyu-text-business-20261029';sd=sw/'region-brand-routing';b=ROOT/'work/fangyu-douyin-independent';sd.mkdir(parents=True,exist_ok=True)
bridge=O/'consumer-bridge-v1';shadow_b=shadow/'work/fangyu-douyin-independent';shadow_b.mkdir(parents=True,exist_ok=True)
sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
for name in ('current.json',):shutil.copyfile(bridge/name,sd/name)
shutil.copyfile(bridge/'main-reply-pointer.json',sw/'当前双平台回复结果指针.json')
shutil.copyfile(W/'当前文本处理运行状态.json',sw/'当前文本处理运行状态.json')
shutil.copyfile(b/'text-screening-current-summary.json',shadow_b/'text-screening-current-summary.json')
original=W/'check_registered_delta.py';text=original.read_text(encoding='utf8');old="B=ROOT/'work/fangyu-douyin-independent'";new='B=Path('+repr(str(b.resolve()))+')';assert text.count(old)==1;text=text.replace(old,new)
old="(W/'douyin-registered-v2/increments').glob('*/manifest.json')";new='Path('+repr(str((W/'douyin-registered-v2/increments').resolve()))+").glob('*/manifest.json')";assert text.count(old)==1;text=text.replace(old,new)
copy=sw/'check_registered_delta.py';copy.write_text(text,encoding='utf8')
orig_report=W/'region-brand-routing/build_human_report.py';shutil.copyfile(orig_report,sd/'build_human_report.py')
protected={str(p.resolve()):sha(p) for p in [W/'当前文本处理运行状态.json',W/'当前双平台回复结果指针.json',W/'region-brand-routing/current.json',original,orig_report]}
env=os.environ.copy();env.update(PYTHONDONTWRITEBYTECODE='1',PYTHONIOENCODING='utf-8')
res=[]
for script in [copy,sd/'build_human_report.py']:
 run=subprocess.run([sys.executable,str(script)],capture_output=True,text=True,encoding='utf8',env=env);res.append({'script':str(script),'exit_code':run.returncode,'stdout':run.stdout[-4000:],'stderr':run.stderr[-4000:]})
post={p:sha(p) for p in protected};report=shadow/'outputs/方隅双平台文本业务/地区归类与品牌母句/双平台最新进度与地区母句说明.md';stale=[]
if report.exists():
 s=report.read_text(encoding='utf8')
 for q in ('本次使用已认可基础母句','新版统一改用无具体店名的已认可基础母句'):
  if q in s:stale.append(q)
out={'isolated_runs':res,'original_registered_checker_sha256':sha(original),'registered_checker_copy_sha256':sha(copy),'original_human_report_sha256':sha(orig_report),'human_report_copy_sha256':sha(sd/'build_human_report.py'),'registered_copy_adaptations':['source B remains real read-only SQLite URI','source batch manifests read-only','outputs redirected to shadow W'], 'shadow_root':str(shadow),'protected_live_files_before':protected,'protected_live_files_after':post,'protected_live_files_unchanged':protected==post,'original_export_stale_claims':stale,'original_human_export_approved_for_candidate':False,'source_sqlite_mode':'ro query_only BEGIN','platform_calls':0,'send_authorized':False}
(dst/'isolation-receipt.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n',encoding='utf8');print(json.dumps({'exit_codes':[r['exit_code'] for r in res],'stderr':[r['stderr'][-700:] for r in res],'protected_unchanged':protected==post,'stale_claims':stale},ensure_ascii=False))
