import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import scrub_text_records as s

class Scrubbing(unittest.TestCase):
 def test_keeps_current_and_unknown_and_removes_expired(self):
  with tempfile.TemporaryDirectory(dir=s.HERE) as directory:
   file=Path(directory)/'douyin-test.jsonl'
   rows=[{'comment_id':'1234567890123','published_at_unix':s.NOW-31*86400,'comment_text':'old'},
         {'comment_id':'1234567890124','published_at_unix':s.NOW-86400,'comment_text':'fresh'},
         {'comment_id':'1234567890125','comment_text':'unknown'}]
   file.write_text(''.join(json.dumps(row)+'\n' for row in rows),encoding='utf-8')
   result=s.clean_file(file)
   kept=[json.loads(line) for line in file.read_text(encoding='utf-8').splitlines()]
   self.assertEqual(result['removed'],1)
   self.assertEqual([row['comment_text'] for row in kept],['fresh','unknown'])
 def test_authoritative_source_timestamp_protects_fresh_record(self):
  row={'comment_id':'1234567890124','published_at_unix':s.NOW-100*86400,'comment_text':'fresh source'}
  with patch.object(s,'source_dates',{'1234567890124':s.NOW-86400}):
   result=s.scrub(row,'douyin',{'removed':0,'digests':set()})
  self.assertIsNot(result,s.DROP)
  self.assertEqual(result['comment_text'],'fresh source')
 def test_rules_and_mothers_are_not_comment_payloads(self):
  self.assertFalse(s.candidate(s.WORK/'rules/example.json'))
  self.assertFalse(s.candidate(s.WORK/'mothers/first50.json'))
  self.assertIsNot(s.scrub({'template_id':'price','published_at':1000},None,{'removed':0,'digests':set()}),s.DROP)
 def test_active_canonical_output_is_protected(self):
  self.assertFalse(s.candidate(s.WORK/'douyin-semantic-repair-v5/douyin-replies.jsonl'))
  self.assertFalse(s.candidate(s.WORK/'douyin-semantic-repair-v5/all-pool-business-fit.jsonl'))

if __name__=='__main__':unittest.main()
