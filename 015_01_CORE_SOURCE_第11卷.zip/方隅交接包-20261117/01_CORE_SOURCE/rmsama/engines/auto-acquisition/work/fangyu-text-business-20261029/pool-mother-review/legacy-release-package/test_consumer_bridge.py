import copy,unittest
import build_consumer_bridge as b
class BridgeTests(unittest.TestCase):
 def sample(self):return {'reply_generation_strategy':'preserved_historical_basic_mother','reply_status':'历史基础母句保留待审','source_record':{'x':1},'original_reply':{'text':'old'},'contact_policy':None,'send_authorized':False,'can_send_now':False,'mother_reply_text':'new','alternative_mother_reply_text':None,'local_mother_candidate':{'draft_type':'housing_short_mother','selection_preserved':'selected','contact_review_required':True}}
 def test_changes_current_metadata_but_preserves_old(self):
  r=self.sample();a=b.bridge_row(r);self.assertNotEqual(a['reply_generation_strategy'],r['reply_generation_strategy']);self.assertEqual(a['consumer_draft_metadata']['original_metadata_backup']['reply_status'],r['reply_status']);self.assertIsNone(a['contact_policy']);self.assertFalse(a['send_authorized']);self.assertFalse(a['consumer_draft_metadata']['template_version_semantic_gate_passed']);self.assertEqual(b.restore_metadata(a),r)
 def test_clarification_is_not_housing_promotion(self):
  r=self.sample();r['local_mother_candidate']['draft_type']='clarification_only';a=b.bridge_row(r);self.assertEqual(a['consumer_draft_metadata']['draft_type'],'clarification_only')
 def test_no_reactivation_of_held(self):
  r=self.sample();r['mother_reply_text']=None;r['local_mother_candidate']['selection_preserved']='selected'
  with self.assertRaises(ValueError):b.bridge_row(r)
if __name__=='__main__':unittest.main()
