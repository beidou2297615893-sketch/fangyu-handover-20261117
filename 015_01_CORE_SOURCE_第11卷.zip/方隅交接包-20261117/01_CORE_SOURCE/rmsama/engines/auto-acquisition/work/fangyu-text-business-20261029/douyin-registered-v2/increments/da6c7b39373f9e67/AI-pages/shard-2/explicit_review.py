import json, pathlib, hashlib, sys, collections, copy
P=pathlib.Path(__file__).resolve().parent
B=P.parent.parent
W=B.parents[2]
src={x['review_key']:x for x in map(json.loads,(B/'shard-2.jsonl').read_text('utf-8').splitlines())}
pages=[json.loads((P/f'page-{i:02}.json').read_text('utf-8')) for i in range(3)]
ctx={c['key']:(g,c) for p in pages for g in p['shared_post_context'] for c in g['comments']}
M={m['slot']:m for m in json.loads((W/'approved-mothers-model-view.json').read_text('utf-8'))}
rows={}
def add(keys,kind='demand',interest='high',pools='',reason='本人在租房语境中主动询租',slot=1,state=None,polarity='ask',subject=None,review=None):
 for key in keys.split():
  assert key in src and key not in rows,key
  s=src[key];g,c=ctx[key];text=c['text']; active=kind in ('demand','mixed') and interest in ('high','super_high','medium','low')
  rows[key]={**{f:s[f] for f in ('review_key','platform','comment_id','customer_uid','video_id')},'role':kind,'demand_state':state or ('active_at_comment' if active else 'unknown'),'interest':interest,'topics':[{'pool':p,'quote':text,'polarity':polarity,'subject':subject or ('own_demand' if kind=='demand' else 'supply' if kind=='supply' else 'unresolved'),'condition_scope':text} for p in pools.split('|') if p],'target_regions':[],'time_mentions':[],'other_constraints':[],'possible_topics':[],'evidence':[text],'reason':reason,'context_used':['own','body']+(['parent'] if c['parent'] else []),'needs_review':review or ([] if interest=='unrelated' else ['评论时需求不等于今日仍有效，需核实目前状态'] if active else ['本人是否有正在推进的住宅租赁需求尚不明确']),'human_confirmed':False,'send_authorized':False,'store_assignment':None,'contact_boundaries':[],'context_flags':{'same_author':c['same_author'],'source_conflict':c['source_conflict'],'post_conditions_not_inherited':not c['same_author'],'source_store_and_ip_not_target':True},'reply_plan':{'preferred_mother_slot':slot if active else None,'generic_intro_suitable':active,'tone':'normal','missing_facts':(['目前需求及可承接门店','真实住户身份、介绍资格、同店推荐优惠及活动时效条件',M[slot]['required_facts'],'针对本人原文问题核实同一房源的完整条件：'+text] if active else []),'caution':['通用介绍不能冒充已回答具体问题；allow不等于发送授权'] if active else ['暂无适当住宅租赁推荐接法'],'contact_policy':'allow'},'analysis_method':'逐条完整正文及本人评论AI初筛和细筛，同轮判读，非独立二审','analysis_page':next(i for i,p in enumerate(pages) if any(c2['key']==key for g2 in p['shared_post_context'] for c2 in g2['comments']))}
def reg(key,items,relation='desired',group='unknown'):
 for t in items.split('|'):
  assert t in ctx[key][1]['text'],(key,t)
  rows[key]['target_regions'].append({'text':t,'quote':ctx[key][1]['text'],'relation':relation,'group_relation':group,'condition_scope':ctx[key][1]['text']})
def time(key,quote,role,normalized=None):
 assert quote in ctx[key][1]['text']
 rows[key]['time_mentions'].append({'quote':quote,'time_role':role,'anchor_source':'本人评论可信发表时间','anchor_time':ctx[key][1]['published_at'],'normalized':normalized,'verification':'按发表时点解释；是否仍有效另核'})
def possible(key,pools,why): rows[key]['possible_topics'].append({'candidate_pools':pools.split('|'),'ambiguity':why})
def note(key,quote,detail):
 assert quote in ctx[key][1]['text']
 rows[key]['other_constraints'].append({'quote':quote,'detail':detail})
def save(page):
 keys=[c['key'] for g in pages[page]['shared_post_context'] for c in g['comments']]
 assert set(keys)<=rows.keys(),sorted(set(keys)-rows.keys())
 out=[rows[k] for k in keys]
 (P/f'reviewed-{page:02}.jsonl').write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in out),'utf-8')
 (P/'progress.json').write_text(json.dumps({'completed_pages':list(range(page+1)),'reviewed_count':len(rows),'method':'显式逐key语义决定；仅程序展开及结构校验'},ensure_ascii=False,indent=2),'utf-8')

# page 00: each key below is an explicit semantic decision after full reading.
add('D0003 D0210 D0213 D0027 D0030 D0312 D0315 D0492 D0042 D0045 D0048 D0051 D0054 D0057 D0171 D0174 D0180 D0183 D0186 D0339 D0342 D0345 D0351 D0504 D0507 D0060 D0066 D0069 D0231 D0393 D0294 D0111 D0135 D0261',kind='discussion',interest='unrelated',reason='对视频、既有经历或价格的评价/建议，未提出本人当前找房动作')
add('D0177 D0348 D0501 D0258',kind='unknown',interest='uncertain',reason='纯艾特或语义不完整，不能确认找房也不能断言无关')
add('D0006 D0009 D0012 D0018 D0021 D0216 D0219 D0024 D0036 D0078 D0084 D0087 D0228 D0402 D0405 D0090 D0093 D0246 D0432 D0123 D0273 D0276 D0453 D0456 D0150 D0153 D0156 D0159 D0165 D0327 D0330 D0333 D0336 D0192 D0207 D0357 D0360 D0363 D0366 D0510 D0513 D0516 D0519 D0522 D0387 D0534 D0537 D0540 D0471',pools='价格预算',reason='明确出租住宅语境下主动问价；月计价不作为租期',slot=2)
add('D0015 D0075 D0270',pools='价格预算|位置通勤',reason='本人提出目标地区和低价/预算要求',slot=2)
add('D0132 D0300 D0303 D0033 D0477 D0480 D0483 D0486 D0489 D0081 D0234 D0408 D0108 D0297 D0438 D0444',pools='位置通勤',reason='本人在租房语境中询求指定区域房源',slot=31)
add('D0306 D0285 D0288 D0291 D0441',pools='位置通勤|户型面积与居住方式',reason='本人询求目标区域及具体户型',slot=7)
add('D0309',pools='位置通勤|户型面积与居住方式|房内设施',reason='本人求单间并明确带内卫，晋安区或鼓楼区可选',slot=34)
add('D0141',reason='本人明确也想租房')
add('D0138',kind='unknown',interest='uncertain',pools='位置通勤|价格预算|户型面积与居住方式',reason='地点价格户型陈述，可能分享现居或供给，不能认定本人求租',polarity='unknown',subject='unresolved')
add('D0144',pools='价格预算|位置通勤|房源状态',reason='本人询3800对应房源位置及是否已租',slot=2)
add('D0147',pools='户型面积与居住方式',reason='本人求一人住，面积不用太大；不凭应届生身份推预算',slot=7,polarity='require')
add('D0039 D0102 D0255 D0417 D0129 D0279 D0459 D0462 D0465 D0195 D0390',pools='房源状态',reason='本人对可租住宅询当前房态，未能确认今天仍有效')
add('D0063 D0072 D0222 D0099 D0249 D0168 D0450 D0468 D0267',interest='medium',pools='',reason='本人询房源性质、地点或真实性，存在住房关注但推进程度待核')
add('D0096 D0396 D0399 D0240 D0282 D0426 D0429',pools='位置通勤',reason='本人询房源位置或明确想找该处；不把原帖地点转为自报目标',slot=31)
add('D0225',kind='unknown',interest='uncertain',reason='询入住人数和入职住此处的方式，住宅租赁与员工入住身份未明')
add('D0237',pools='价格预算|入住与租期',reason='本人询长租价格，长租时长未量化',slot=19)
add('D0411',pools='房源状态')
add('D0105 D0372',pools='价格预算',reason='本人询具体预算范围内房源',slot=2)
add('D0243 D0423 D0198 D0204 D0369 D0525 D0126',pools='价格预算|户型面积与居住方式',reason='本人询具体户型及租金，原帖其他条件不继承',slot=7)
add('D0252 D0420',pools='看房联系',reason='本人请求通过联系以继续询租，未提出约看时间，不升超高',slot=28)
add('D0414 D0354 D0375',pools='户型面积与居住方式|房源状态',reason='本人询指定户型是否还有',slot=7)
add('D0435 D0447 D0378 D0495',kind='supply',interest='unrelated',reason='本人提供转租/带看/房源服务，没有本人另求租证据')
add('D0114',pools='户型面积与居住方式|入住与租期',reason='现询两室一厅，下一月10号需要，未来入住不等于未来才找',slot=7)
add('D0117',pools='户型面积与居住方式|入住与租期',reason='本人求长租整租两室有厅',slot=7,polarity='require')
add('D0120',pools='房源状态|入住与租期|户型面积与居住方式|位置通勤',reason='现问房态，下月要，三室亦可，目标萧山',slot=34)
add('D0162 D0381',pools='费用合同',reason='主动问如何租赁，具体签租程序待核')
add('D0324 D0384',pools='房源状态|价格预算',slot=2)
add('D0189',pools='价格预算|入住与租期',reason='本人最近想换房，问月价和最短起租月份；不把月价当租期',slot=19)
add('D0201',interest='high',reason='可租住宅下询多少米，有明确询租但价格/面积指标歧义')
possible('D0201','价格预算|户型面积与居住方式','多少米可能是价格或面积，未澄清不确定分池')
add('D0528',pools='价格预算|位置通勤',reason='本人问租金、具体位置和地铁距离',slot=31)
add('D0264',interest='medium',reason='本人表示相中但原帖独居生活分享，需核实是否正找房，非确定房态询盘')
add('D0318 D0321',interest='medium',pools='价格预算',reason='退租搬离经历帖下问价，住房兴趣存在，是否询可租房源待核',slot=2)
add('D0531',reason='明确出租住宅下本人想要该房，未明确约时/订房，不升超高')
add('D0498',kind='demand',interest='unrelated',pools='价格预算',reason='正文明确办公室出租，本人询价属于办公租赁，不能当住宅租赁需求',state='active_at_comment')
for k,t in {'D0015':'龙柏新村附近','D0132':'福大旗山附近','D0300':'福州秀山地铁站附近','D0303':'鼓楼区','D0306':'福州鼓楼区','D0033':'嘉定','D0477':'长宁区','D0480':'汉中路|宜川路附近','D0483':'金桥|高行','D0486':'嘉定区','D0489':'浦东新区','D0075':'狼垡附近|北大医院大兴院区周边','D0081':'朝阳公园','D0234':'合生汇附近','D0408':'朝阳工体附近','D0108':'武侯区川音附近','D0285':'18号线','D0288':'四川省肿瘤医院武侯院区附近','D0291':'时代一号附近','D0297':'中和附近','D0438':'七号线','D0441':'锦江区','D0444':'成华区','D0120':'萧山','D0270':'滨江'}.items(): reg(k,t,group='OR' if '|' in t else 'unknown')
reg('D0309','晋安区|鼓楼区',group='OR');reg('D0138','浦东南码头','unresolved')
reg('D0435','成华区','offered');reg('D0447','郫都','offered');reg('D0495','国际医学中心旁','offered')
time('D0114','下个月10号','move_in','2026-07-10');time('D0120','下个月','move_in','2026-08');time('D0117','长租','lease_duration');time('D0237','长租','lease_duration');time('D0189','最近','search_start');time('D0189','几个月起租','lease_duration')
add('D0474',pools='价格预算|位置通勤',reason='本人询租金和小区',slot=31)
for k in ['D0123','D0276','D0240']:
 for pool in ['价格预算','位置通勤']:
  if pool not in [t['pool'] for t in rows[k]['topics']]: rows[k]['topics'].append({'pool':pool,'quote':ctx[k][1]['text'],'polarity':'ask','subject':'own_demand','condition_scope':ctx[k][1]['text']})
save(0)

# page 01
add('D0543 D0552 D0555 D0723 D0726 D0729 D0843 D0846 D1020 D1026 D0567 D0759 D1044 D1056 D0606 D0609 D0648 D0654 D0666 D0669 D0672 D0675 D0678 D0780 D0786 D0789 D0792 D0693 D0696 D0699 D0702 D0705 D0711 D0807 D0810 D0813 D0819 D0822 D0825 D0996 D0999 D1005 D1008 D1014 D0714 D0717 D0774 D0966 D0972 D0975 D0981',pools='价格预算',reason='出租住宅语境下本人主动问租金；月计价不是总租期',slot=2)
add('D0546 D0549 D0732 D1023 D1029 D1002',pools='价格预算|位置通勤',reason='本人同时询租金与区域/房源位置',slot=31)
add('D0558 D0561 D0564 D0735 D0840 D0849 D1035 D0579 D0582 D0858 D0873 D1047 D1053 D0615 D0633 D0636 D0762 D0765 D0768 D0915 D0924 D1065 D1071 D0939 D0942',pools='位置通勤',reason='本人主动询租房位置或指定目标区域',slot=31)
add('D0720',interest='medium',pools='价格预算',reason='虽问价但附让我死心，兼有调侃或预算退缩，不能确认高推进',slot=2)
add('D0738 D0831 D1017 D0864 D0630',kind='unknown',interest='uncertain',reason='简短感叹、单个数字或不明问句，不足确认本人正在找房，保留未知')
add('D0834 D0852 D0750 D0753 D0588 D0651 D0657 D0681 D0687 D0690 D0795 D0798 D0804 D0984 D0987 D0993 D0777 D0828 D0876 D0879 D0882 D0885 D0888 D0906 D0930 D0945 D0948 D0951 D0954 D1074',kind='discussion',interest='unrelated',reason='评价视频/价格、生活经历、补贴或工作互动，未提出本人住宅租赁推进')
add('D0744 D0684 D0801 D0990 D0891 D0897',kind='unknown',interest='uncertain',reason='纯艾特分享对象，用途未知，保留未知且不出推销稿')
add('D0837 D1038 D0933',interest='medium',pools='价格预算',reason='对具体价格真伪的短询，保留住房关注，尚不足确认推进',slot=2)
add('D1032',pools='位置通勤',reason='本人询位置及多少米，后者价格或面积未明',slot=31)
possible('D1032','价格预算|户型面积与居住方式','多少米指标未明确，不能直接当价格')
add('D0570 D0963',pools='户型面积与居住方式',reason='本人明确需要或询一居/一室一厅',slot=7)
add('D0573 D0576 D0585 D0747 D0855 D0870 D1050 D0612 D0618 D0621 D0909 D0642 D0645 D0936',pools='房源状态',reason='明确出租住宅下本人询是否仍可租')
add('D0741 D0783',pools='费用合同',reason='本人问怎么租，租赁程序待核')
add('D0756',pools='看房联系',reason='本人明确想看此房但无约时，仅高意向',slot=28)
add('D0867',interest='super_high',pools='位置通勤|看房联系',reason='本人询地址并明确马上看房，提出即时带看推进；预约未获确认',slot=28)
time('D0867','马上','viewing')
add('D0861 D1041',reason='本人明确想要或要租一套住宅，未提出订房签约')
add('D0591',pools='位置通勤|看房联系',reason='本人找房找疯了并求上城中介推荐，现行求租明确',slot=31)
add('D0594 D0597 D0600 D0603 D0627 D0771 D1059',kind='supply',interest='unrelated',reason='本人明确转租、待出租或提供中介服务，未表达本人另找房动作')
add('D0912 D0978',pools='看房联系',reason='本人要求加联系继续询租，不能当已约看',slot=28)
add('D0624',pools='价格预算|位置通勤|户型面积与居住方式',reason='本人询红星桥1500预算套一，条件联立',slot=34)
add('D0918 D0921',pools='位置通勤|户型面积与居住方式',reason='本人求指定区域合租/单间',slot=7)
add('D1062 D1068',interest='medium',pools='费用合同',reason='中介经历帖下询电费/中介费，保留询租服务兴趣；具体房源未明',slot=25)
add('D0639',pools='入住与租期',reason='本人询能否月租，按租赁时长待核，不编造已接受一年',slot=19)
time('D0639','月租','lease_duration')
add('D0660',pools='价格预算|费用合同',reason='本人问租金及水电费，均需核同店真实口径',slot=25)
add('D0663',reason='本人询新疆人能否入住，属于住宅询租；不推断其他要求')
note('D0663','新疆人可以住嘛','本人询地域身份是否影响入住，需核真实入住政策')
add('D0708 D0816',pools='价格预算|房源状态',reason='本人同时询价及是否还有',slot=2)
add('D1011',pools='价格预算|看房联系',reason='本人询月租及联系方式，未约时',slot=28)
add('D0894 D0900',interest='medium',pools='价格预算',reason='独居合租生活分享帖下问价，是否当下求租需核',slot=2)
add('D0903',kind='unknown',interest='uncertain',reason='艾特并称这个好，可能分享欣赏或选房，未明本人求租')
add('D0927',pools='位置通勤|入住与租期',reason='本人求鼓楼附近短租一月，有工作后才考虑长租；不把条件长租视为已定',slot=19)
time('D0927','短租一个月','lease_duration','P1M');time('D0927','等有工作了会考虑长租','lease_duration')
add('D0957',interest='medium',pools='价格预算',reason='询视频标价是否一年租金，属于价格周期疑问，不能当本人租一年',slot=2)
add('D0960',pools='价格预算|位置通勤|户型面积与居住方式',reason='本人求一室独住、3000以内、1或8号线且到人民广场40分钟，条件必须联立',slot=34,polarity='require')
add('D0969',pools='看房联系|费用合同',reason='本人问如何租和联系，未约看具体时间',slot=28)
add('D1077',interest='medium',pools='户型面积与居住方式|位置通勤|价格预算',reason='独居分享帖下询一室一厅地址价格，有兴趣但可租及当前动作需核',slot=7)
add('D1080',interest='medium',pools='户型面积与居住方式',reason='询两室一厅及多少米，后者价/面积歧义，原帖非明确可租广告',slot=7)
possible('D1080','价格预算|户型面积与居住方式','多少米未明确价格或面积指标；两室一厅户型另有确定证据')
for k,t in {'D0546':'合生汇','D0561':'大兴','D0564':'朝阳区','D0735':'4号线靠西城区附近','D0840':'环贸中心附近','D0849':'顺义','D1023':'朝阳','D0582':'垡头路金蝉南里|附近','D0591':'上城','D0615':'萧山','D0624':'红星桥','D0633':'科华王府井旁边','D0636':'郫都','D0762':'青羊','D0765':'武侯区','D0768':'离电子科技大学清水河校区近的几个地铁站','D0915':'郫都区','D0918':'天府新区','D0921':'锦江','D0924':'成都成华区','D1065':'温江','D1071':'春熙路附近','D0927':'鼓楼附近','D0942':'安海','D0960':'1和8号线|人民广场'}.items(): reg(k,t,group='OR' if k=='D0582' else 'AND' if k=='D0960' else 'unknown')
rows['D0960']['target_regions'][0]['condition_scope']='1和8号线上的可选线路；不是要求同时属于两条线路，且到人民广场通勤40分钟'
for k,t in {'D0594':'临平乔司南附近','D0597':'上城区|牛田苑','D0600':'滨江春波南苑','D0627':'成都','D0771':'成都七中隔壁|清凤时代城','D1059':'双流区'}.items(): reg(k,t,'offered',group='AND' if '|' in t else 'unknown')
time('D1059','9.2号之前','other');time('D1059','10个月','other')
save(1)

# page 02
add('D1083 D1296',interest='medium',pools='位置通勤',reason='生活分享帖下询位置，关注住房但可租与本人推进需核',slot=31)
add('D1092',interest='medium',pools='户型面积与居住方式|价格预算',reason='生活分享帖下询两室一厅价格，是否有可租及本人现求租待核',slot=7)
add('D1266',interest='medium',pools='价格预算',reason='生活分享帖下问后套价格，当前求租推进待核',slot=2)
add('D1086 D1260 D1263 D1089 D1269 D1275 D1278',kind='unknown',interest='uncertain',reason='感叹憧憬/邀友去杭州，未明确租赁找房动作，保留未知')
add('D1272',kind='discussion',interest='unrelated',reason='本人邀友买房，非住宅租赁需求')
add('D1095',reason='本人明确要租且要求干净',polarity='require')
note('D1095','必须是干净的','房屋整洁卫生为明确硬要求')
add('D1098 D1101 D1323 D1326 D1329 D1152 D1155 D1158 D1365 D1371 D1374 D1380 D1218 D1239 D1242 D1245 D1248 D1251 D1254 D1257 D1281',kind='discussion',interest='unrelated',reason='既有经历、价格评价/反讽或视频互动，未提出本人当前住宅求租')
add('D1104 D1317 D1353',reason='本人明确要租房或求推荐，预算充足不等于可推具体金额')
add('D1107 D1113 D1311 D1314 D1320 D1119 D1125 D1332 D1335 D1341 D1131 D1191 D1197 D1227 D1287',pools='位置通勤',reason='本人询房源位置或指定区域房源',slot=31)
add('D1110 D1161',pools='房源状态|价格预算',reason='本人询房态和租金',slot=2)
add('D1305',kind='unknown',interest='uncertain',pools='位置通勤|价格预算|户型面积与居住方式',reason='本人房子价格户型陈述，现居分享与提供房源未明，不当本人求租',polarity='fact',subject='unresolved')
add('D1308 D1224 D1230 D1236 D1344 D1407 D1416',pools='房源状态',reason='明确出租语境下本人问是否还有房可租')
add('D1116',pools='位置通勤|户型面积与居住方式|入住与租期',reason='本人求8.17合租，男不抽烟不喝酒不打游戏为本人生活自述，不强加室友',slot=34)
note('D1116','男，不抽烟不喝酒不打游戏的','本人性别和生活习惯陈述，不推断预算或强制室友条件')
time('D1116','8.17号','move_in')
add('D1122',pools='位置通勤|户型面积与居住方式',reason='本人求浦东顾唐路民雷路一室户',slot=7)
add('D1338',pools='户型面积与居住方式|房源状态',reason='本人明确想租，求整租一房一厅',slot=7)
add('D1128',pools='费用合同',reason='本人询如何租赁，签租程序需核')
add('D1134 D1137 D1140 D1143 D1146 D1170 D1176 D1386 D1389 D1392 D1398 D1182 D1194 D1209 D1221 D1347 D1350 D1356 D1362',pools='价格预算',reason='可租住宅语境下本人问价；月租不自动当租期',slot=2)
add('D1149 D1377 D1284 D1359',kind='unknown',interest='uncertain',reason='纯艾特或dd互动，不能确认本人需求，保留未知不推销')
add('D1368',kind='supply',interest='unrelated',pools='价格预算|户型面积与居住方式|房内设施',reason='本人称两室出租并讨论是否租便宜，没有本人求租',polarity='fact')
add('D1164',reason='本人在可租住宅下询多少米，存在询租但价格/面积待澄清')
possible('D1164','价格预算|户型面积与居住方式','多少米无法确定价格或面积，保留候选')
add('D1167 D1395 D1206 D1215',pools='价格预算|位置通勤',reason='本人同时询房源位置与月租',slot=31)
note('D1206','有停车位吗','需核停车位可用性及费用，不能丢失停车约束')
add('D1173',pools='入住与租期',reason='本人急租并询短租一个月，当前找房明确，紧急不等于已约看/订房',slot=19)
time('D1173','短租一个月','lease_duration','P1M')
add('D1179',kind='supply',interest='unrelated',reason='房源作者举手互动，结合本人出租正文为提供房源，无另求租')
add('D1383',interest='medium',pools='位置通勤',reason='询公寓名称，具体租赁推进程度未明',slot=31)
add('D1185',interest='super_high',pools='位置通勤|看房联系',reason='本人要求发位置并明确定了，为订房推进，不等于成交已确认',slot=28)
add('D1188',pools='户型面积与居住方式|看房联系',reason='本人想看三室房，无指定约时仅高兴趣',slot=28)
add('D1200',interest='medium',pools='费用合同',reason='本人询能否开酒店发票，短住或住宅长租用途不明，暂不硬推住宅',slot=25)
rows['D1200']['reply_plan']['generic_intro_suitable']=False
rows['D1200']['needs_review'].append('酒店住宿或住宅租赁用途及开票类型待核')
add('D1203',pools='位置通勤',reason='本人询昌平具体位置，不能当本人确定目标',slot=31)
add('D1212',pools='入住与租期',reason='本人询能否年租，尚未确认接受',slot=19)
time('D1212','年租','lease_duration','P1Y')
add('D1233',pools='位置通勤',reason='本人询位置及多米，价格/面积指标未明',slot=31)
possible('D1233','价格预算|户型面积与居住方式','多米可能价格或面积，未确定不得分价格池')
add('D1290',pools='户型面积与居住方式',reason='本人求整租，明确不要合租；否定仅限居住方式',slot=7,polarity='require')
rows['D1290']['topics']=[{'pool':'户型面积与居住方式','quote':'整租的有吗','polarity':'ask','subject':'own_demand','condition_scope':'整租'},{'pool':'户型面积与居住方式','quote':'不要合租','polarity':'reject','subject':'own_demand','condition_scope':'合租'}]
add('D1293',pools='看房联系',reason='本人询房主及联系，分享帖未明确现有房可租，保留中兴趣',interest='medium',slot=28)
add('D1299',kind='supply',interest='unrelated',reason='本人询有没有要租房的人，为房源/租客招揽，无本人求租')
add('D1302',pools='户型面积与居住方式|价格预算|看房联系',reason='本人求两室一厅，要求有房源者私信，价格可商量；不能误判供应',slot=7)
add('D1401 D1413',interest='super_high',pools='看房联系',reason='明确要此间/请留一间，为订房保留请求；不代表订房已成功',slot=28)
add('D1404',pools='价格预算|位置通勤',reason='本人询所列地址周边600或700房，离远一点亦可',slot=2)
add('D1410',pools='位置通勤|价格预算|户型面积与居住方式|房内设施',reason='本人求列明上海区域500单间并问独立水池，条件同房源核实',slot=34)
add('D1419',pools='户型面积与居住方式',reason='本人抱怨当前民房费用并明确想换地方求合租、方便停车，保留新的活跃需求',slot=7)
rows['D1419']['topics'].append({'pool':'费用合同','quote':'当初说好的25的水费，我买了个洗衣机又变成30了','polarity':'fact','subject':'current_home','condition_scope':'现居费用纠纷，不能转成新房预算要求'})
note('D1419','方便停车的','换租房需方便停车，停车位及费用需核')
time('D1419','还不到一个月','other')
for k,t in {'D1107':'上街','D1311':'南宁','D1119':'嘉定|安亭昌吉东路','D1122':'浦东顾唐路民雷路','D1125':'长宁','D1332':'3号线','D1335':'杨浦','D1341':'九亭','D1227':'宋家庄地铁口','D1287':'上城区九堡','D1404':'上海市闵行区三鲁公路5569弄28','D1410':'上海闵行|徐汇|松江|宝山|嘉定|青浦'}.items(): reg(k,t,'unresolved' if k in ['D1107','D1311','D1227'] else 'desired',group='OR' if k=='D1410' else 'AND' if k=='D1119' else 'unknown')
reg('D1116','浦东|仁济东院附近|4号线',group='OR');rows['D1116']['target_regions'][0]['group_relation']='AND';rows['D1116']['target_regions'][0]['condition_scope']='浦东合租，仁济东院附近或4号线为备选范围'
reg('D1305','闽侯','unresolved');reg('D1203','昌平','unresolved');reg('D1299','温江','offered')
rows['D1404']['target_regions'][0]['condition_scope']='所列地址周边；离地址远一点也可以，距离上限未明'
def extra_topic(key,pool,quote=None,polarity='ask',scope=None):
 rows[key]['topics'].append({'pool':pool,'quote':quote or ctx[key][1]['text'],'polarity':polarity,'subject':'own_demand','condition_scope':scope or ctx[key][1]['text']})
extra_topic('D0063','位置通勤')
extra_topic('D0228','看房联系')
extra_topic('D0666','看房联系')
extra_topic('D1317','价格预算','预算充足','fact','未给金额，不能推定具体预算或可无上限')
# These exact short questions were read in a generic Beijing housing/lifestyle caption,
# rather than an explicit available rental listing; do not turn their interest into certainty.
for k in 'D0078 D0084 D0087 D0228 D0396 D0399 D0402 D0405 D0240 D0546 D0549 D0552 D0555 D0558 D0723 D0726 D0729 D0732 D0843 D0846 D1020 D1023 D1026 D1029 D1032 D1035 D1203 D1209 D1215'.split():
 rows[k]['interest']='medium'
 rows[k]['reason']='泛租房生活展示正文下的具体短询，保留住房兴趣；原帖是否提供可租住宅及本人推进需核'
 rows[k]['needs_review'].append('正文未明确提供可租住宅，需核询价/询位置对象与本人租赁意愿')
# Re-save only this shard's completed page artifacts after these explicit semantic corrections.
save(0);save(1);save(2)

if __name__=='__main__':
 assert set(rows)==set(src),(set(src)-set(rows),set(rows)-set(src))
 out=[rows[k] for k in src]
 (B/'reviewed-new-2.jsonl').write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in out),'utf-8')
 print('Completed explicit semantic rows:',len(out))
