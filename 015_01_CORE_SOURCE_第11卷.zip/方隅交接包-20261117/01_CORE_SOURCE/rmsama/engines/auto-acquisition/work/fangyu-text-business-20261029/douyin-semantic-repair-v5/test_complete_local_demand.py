import unittest
from datetime import datetime, timezone
import complete_local_demand as completion


class Completion(unittest.TestCase):
    def row(self, text, **extra):
        return dict(platform='douyin', comment_text=text, role='demand',
                    interest_at_comment='high', pools=[],
                    published_at=datetime.now(timezone.utc).isoformat(), **extra)

    def test_existing_demand_gets_appropriate_pool(self):
        for text, pool in [('多少钱', '价格预算'), ('什么位置', '位置通勤'),
                           ('位置在那里', '位置通勤'), ('看看位置', '位置通勤'),
                           ('多少呀', '价格预算'), ('多少？第一套', '价格预算'),
                           ('求租一居室', '户型面积与居住方式')]:
            with self.subTest(text=text):
                result = completion.complete(self.row(text))
                self.assertIn(pool, result['pools'])
                self.assertTrue(result['reply']['draft_text'])
                self.assertEqual(result['reply_generation_model_calls'], 0)

    def test_low_budget_contact_and_low_source_remain_held(self):
        for row in [self.row('预算1300求租'), self.row('求租，不要联系我'),
                    self.row('多少钱', post_body='整租，月租1800'),
                    self.row('我想租，中介勿扰')]:
            with self.subTest(text=row['comment_text']):
                self.assertIsNone(completion.complete(row))

    def test_nested_and_source_author_not_automatically_completed(self):
        self.assertIsNone(completion.complete(self.row('多少钱', reply_to='123')))
        self.assertIsNone(completion.complete(self.row('多少钱', post_author_same_as_commenter=True)))
        row = self.row('多少钱')
        row['interest_at_comment'] = 'uncertain'
        self.assertIsNone(completion.complete(row))

    def test_search_duration_and_negative_pet_do_not_become_claims(self):
        row = self.row('找了半天，不带猫，想租一居室')
        result = completion.complete(row)
        draft = result['reply']['draft_text']
        self.assertNotIn('半天', draft)
        self.assertNotIn('能带猫', draft)
        self.assertNotIn('宠物', result['reply']['semantic_guard']['pools'])
        self.assertEqual(row['comment_text'], '找了半天，不带猫，想租一居室')


if __name__ == '__main__':
    unittest.main()
