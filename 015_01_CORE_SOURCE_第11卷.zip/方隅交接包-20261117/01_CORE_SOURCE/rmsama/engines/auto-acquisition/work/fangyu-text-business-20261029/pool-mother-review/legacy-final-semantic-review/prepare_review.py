import pathlib,json,hashlib,string,collections
O=pathlib.Path(__file__).resolve().parent;P=O.parent;W=P.parent;R=P/'legacy-release-repairs'
def load(p):return json.loads(pathlib.Path(p).read_text(encoding='utf-8-sig'))
def jl(p):return [json.loads(s) for s in pathlib.Path(p).read_text(encoding='utf-8-sig').splitlines() if s.strip()]
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def objsha(x):return hashlib.sha256(json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def key(x):return x['platform'],x.get('cid',x.get('comment_id')),x.get('uid',x.get('customer_uid'))
def put(n,x): (O/n).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
expected={'READY.json':'7de8c6665b7951e781d4cf9fd3a8affa895dc2997154f890f401e120483ec50e','manifest.json':'823a4589164a491e7fc1ae50a4c4da12074b5203b5a6490853639ae6574129d8','repair-contract.json':'18043c2a448db1f4d2dd662b9ad9c640f33e6d4aae84875c23dde8bea50e8629','source-bound-plan-overlays.jsonl':'380f92e327faf7f82202999817591391386ad10d6dcb433c8efed1b295937a0a'}
assert all(sha(R/n)==h for n,h in expected.items())
ready=load(R/'READY.json');assert all(sha(R/n)==h for n,h in ready['final_files_sha256'].items())
m=load(R/'manifest.json');assert all(sha(p)==h for p,h in m['source_SHA256'].items())
base={key(x):x for x in jl(P/'legacy-release-package/candidate-abc/merged-plans.jsonl')}
ov={key(x):x for x in jl(R/'source-bound-plan-overlays.jsonl')};contract=load(R/'repair-contract.json')['families']
sources={}
for path in load(W/'region-brand-routing/current.json')['results'].values():
 for x in jl(path):sources[key(x)]=x
patched={k:{**x,**ov[k]['replacement_plan']} if k in ov else x for k,x in base.items()}
for k,x in ov.items():
 assert objsha(base[k])==x['base_merged_plan_sha256']
 assert hashlib.sha256(sources[k]['comment_text'].encode()).hexdigest()==x['sourceSHA']
 assert objsha(sources[k]['source_record'])==x['original_classification_sha256']
 assert x['send_authorized'] is False and x['can_send_now'] is False
template_checks=[]
for name,c in contract.items():
 fields=[f for _,f,_,_ in string.Formatter().parse(c['template']) if f]
 assert set(fields)==set(c['required_fill'])
 template_checks.append({'family':name,'required_fill':c['required_fill'],'syntax_valid':True,'used_after':sum(x['family']==name for x in patched.values())})
bound=0;clar=0
for k,x in patched.items():
 assert x['send_authorized'] is False and x['can_send_now'] is False
 assert x.get('contact_policy_original')==base[k].get('contact_policy_original')
 if not x['family']:continue
 c=contract[x['family']];assert set(x['fill'])==set(c['required_fill']);c['template'].format(**x['fill']);bound+=1;clar+=bool(x.get('clarification_only'))
matrix=jl(R/'all-family-structure-matrix.jsonl')
old_counts=collections.Counter(x['family'] for x in base.values() if x['family'])
assert {x['original_family']:x['source_bound_count'] for x in matrix}==dict(old_counts)
for row in matrix:
 actual=collections.Counter(patched[k]['family'] or 'specific_hold' for k,x in base.items() if x['family']==row['original_family'])
 assert dict(actual)==row['repaired_transitions']
regress=jl(R/'old-QA-regression.jsonl');known=[x for x in regress if x['old_family'] and x['old_QA_verdict'] in ('change_plan_only','hold')]
neighbors=jl(R/'neighbor-and-coverage-regressions.jsonl')
selected={key(x):['known_problem'] for x in known}
for n in neighbors:
 k=next(k for k in base if k[1]==n['cid']);selected.setdefault(k,[]).append('neighbor_or_coverage')
for cid in ['7677175967064916773','7689489892791092002']:
 k=next(k for k in base if k[1]==cid);selected.setdefault(k,[]).append('unchanged_adjacent_old_pass')
for k,x in ov.items():
 if x.get('newly_bound_small_short_lease_addition'):selected.setdefault(k,[]).append('newly_bound_short_lease')
cases=[];contexts={}
for k,tags in selected.items():
 r=sources[k];b=base[k];p=patched[k];raw=r.get('original_raw_record') or {};sr=r['source_record']
 ctxid=k[0]+':'+str(r.get('note_id') or r.get('video_id') or raw.get('note_id') or raw.get('video_id'))
 ctx={'post_title':raw.get('post_title'),'post_text':raw.get('post_text'),'source_post_body':sr.get('post_body'),'parent_text':raw.get('parent_text') or sr.get('direct_parent_text'),'parent_relationship':raw.get('parent_relationship')}
 contexts[ctxid]=ctx
 cases.append({'key':list(k),'cid':k[1],'selection':tags,'comment':r['comment_text'],'source_comment_sha':hashlib.sha256(r['comment_text'].encode()).hexdigest(),'context_ref':ctxid,'context_sha':objsha(ctx),'source_record_sha':objsha(sr),'source_topics':sr.get('topic_evidence') or sr.get('classification',{}).get('topics'),'source_regions':r.get('target_regions'),'source_time':r.get('time_mentions'),'source_review':list(dict.fromkeys((r.get('semantic_review_reasons') or [])+(sr.get('needs_review') or [])+(sr.get('classification',{}).get('needs_review') or []))),'source_blocking':sr.get('blocking_reasons'),'source_contact':r.get('contact_policy'),'base_family':b['family'],'final_family':p['family'],'fill':p['fill'],'preview':contract[p['family']]['template'].format(**p['fill']) if p['family'] else None,'clarification_only':p.get('clarification_only',False),'holds':p.get('hold_reasons'),'repair_reasons':ov.get(k,{}).get('repair_reasons',[]),'base_plan_sha':objsha(b),'replacement_sha':objsha(ov[k]['replacement_plan']) if k in ov else None,'send_authorized':False})
put('review-input.json',cases);put('shared-contexts.json',contexts);put('contract-structure-checks.json',template_checks)
verification={'expected_anchor_hashes_verified':expected,'all_READY_files_SHA_verified':len(ready['final_files_sha256']),'protected_source_SHA_verified':len(m['source_SHA256']),'overlays_checked':len(ov),'contract_families_syntax_checked':len(contract),'actual_used_after':len({x['family'] for x in patched.values() if x['family']}),'used_family_fill_sets_checked':bound,'matrix_old_families_checked':len(matrix),'matrix_old_bound_members_checked':sum(old_counts.values()),'new_bound_not_in_old_matrix':sum(bool(patched[k]['family']) and not x['family'] for k,x in base.items()),'housing':bound-clar,'clarification':clar,'held':len(base)-bound,'known_problem_rows':len(known),'known_problem_unique':len({key(x) for x in known}),'neighbor_rows':len(neighbors),'selected_unique_cases':len(cases),'all_send_false':True,'unknown_contact_not_upgraded':True,'semantic_review_complete':False}
put('initial-validation.json',verification)
print(json.dumps(verification,ensure_ascii=False))
