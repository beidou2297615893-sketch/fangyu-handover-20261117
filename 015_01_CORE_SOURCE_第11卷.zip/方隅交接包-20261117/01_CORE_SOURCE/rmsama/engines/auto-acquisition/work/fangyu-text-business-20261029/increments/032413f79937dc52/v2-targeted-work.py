import json,pathlib,collections,copy,hashlib,datetime
from zoneinfo import ZoneInfo
p=pathlib.Path('work/fangyu-text-business-20261029/increments/032413f79937dc52'); inputs=[json.loads(x) for x in (p/'input.jsonl').open(encoding='utf8')]; old=[json.loads(x) for x in (p/'final-reviewed.jsonl').open(encoding='utf8')]; src={x['review_key']:x for x in inputs}; out=copy.deepcopy(old);by={x['review_key']:x for x in out};before={x['review_key']:x for x in old};semantic=collections.defaultdict(list)
def change(k,message):semantic[k].append(message)
def addreview(k,s):
 x=by[k];
 if s not in x['needs_review']:x['needs_review'].append(s)
# Schema compatibility is mechanical; unknown old semantics remain unresolved rather than inferred.
for x in out:
 old_role=x['role'];
 for t in x['topics']:
  t['subject']='own_demand' if old_role=='demand' and x['interest'] not in ['uncertain','unrelated'] else 'unresolved';t['condition_scope']=None
 for r in x['target_regions']:r['group_relation']='unknown';r['condition_scope']=None
 x['time_mentions']=[];x['other_constraints']=[];x['possible_topics']=[];x['prior_rule_version']=x.get('rule_version');x['rule_version']='business-text-20261029-v2';x['v2_review_method']='复用v1模型判读，结构全量校验与规则影响定向复核，未全量重新判读';x['human_confirmed']=False;x['send_authorized']=False;x['store_assignment']=None
# The old discussion label suppressed a clearly resolved personal search.
x=by['I0181'];x['role']='demand';x['demand_state']='ended';x['interest']='unrelated';x['reason']='本人说已找到，且未明确新的求租需求，保存为本人需求已结束。';change('I0181','已找到应记录为demand/ended/unrelated')
by['I0452']['reason']='本人明确暂时不需要租房；未说一定已租到。';change('I0452','不把暂不需要租说成已租到')
# Soft preferences and topic boundaries, directly from the original phrases.
def ts(k,pool,quote,polarity,scope=None,subject='own_demand'):
 assert quote in src[k]['comment_text'];return {'pool':pool,'quote':quote,'polarity':polarity,'subject':subject,'condition_scope':scope}
by['I0193']['topics']=[ts('I0193','户型面积与居住方式','全女生合租的房子','require','合租室友均为女生'),ts('I0193','户型面积与居住方式','最好是两室一厅','prefer','偏好，不当硬性限制')];change('I0193','两室一厅是最好而非硬要求')
by['I0029']['topics']=[ts('I0029','户型面积与居住方式','主卧独卫或者一室户','require','主卧带独卫与一室户为替代选项，不是同一房源均须满足'),ts('I0029','房内设施','主卧独卫','conditional','独卫适用于主卧选项'),ts('I0029','价格预算','1500-2000左右','prefer','上下浮动空间未明，不能当明确硬上限')];change('I0029','保留主卧带独卫或一室户二选一及左右价位')
for k in ['I0024','I0032']:
 for t in by[k]['topics']:
  if t['pool']=='看房联系':t['polarity']='ask';t['condition_scope']='表达想看房，并未确认预约'
 change(k,'泛看房意向是询问，不改判已预约')
for t in by['I0381']['topics']:
 if t['pool']=='看房联系':t['polarity']='fact';t['condition_scope']='本人陈述持续看房，并非新预约'
change('I0381','持续看房为本人事实而非新的硬要求')
by['I0204']['topics']=[ts('I0204','价格预算','价位在2500左右','prefer','约数而非明确硬上限'),ts('I0204','位置通勤','近地铁站','require','具体站和距离待明确'),ts('I0204','房内设施','燃气热水器','require'),ts('I0204','户型面积与居住方式','1室1厅1厨1卫','require'),ts('I0204','户型面积与居住方式','AB套可以','accept','AB套是可接受选项，不覆盖一室一厅一厨一卫条件'),ts('I0204','入住与租期','随时可以入住','accept','表示可随时入住，不是房源必须立即交房'),ts('I0204','看房联系','视频看房','require'),ts('I0204','费用合同','线上签约','require'),ts('I0204','看房联系','有房的可以联系我','ask')];
for r in by['I0204']['target_regions']:r['group_relation']='unknown';r['condition_scope']='列出若干区域，替代关系待核'
addreview('I0204','多个区域是分别接受还是有其他约束待核；2500为约数。');change('I0204','拆分AB套接受范围、约数、随时入住与多地点关系')
for t in by['I0413']['topics']:
 if t['pool']=='价格预算':t['polarity']='prefer';t['quote']='价格在1300左右';t['condition_scope']='约数，不是已明确硬上限'
change('I0413','1300左右为目标价而非严格上限')
by['I0427']['topics']=[ts('I0427','位置通勤','12号线沿线','require'),ts('I0427','房内设施','装修简单干净就行','accept','简单干净即可，不增加装修档次'),ts('I0427','房内设施','安静一点','prefer','程度偏好'),ts('I0427','户型面积与居住方式','一居室','require'),ts('I0427','房源状态','房东有么','ask')];change('I0427','分开装修最低条件、安静偏好和一居室')
by['I0530']['target_regions'][0]['relation']='unresolved';by['I0530']['target_regions'][0]['condition_scope']='上海浦江静安的地名分界及并列关系待核';change('I0530','不将无法拆分的地域合并表述当作已确认目标区域')
by['I0553']['target_regions']=[{'text':'黄埔','quote':'黄埔','relation':'desired','group_relation':'OR','condition_scope':'原词可能有误，是否指黄浦待核'},{'text':'闵行','quote':'闵行','relation':'desired','group_relation':'OR','condition_scope':'与黄埔为替代选择'}];change('I0553','保留原文两个区域或关系及黄埔名称疑点')
by['I0734']['topics']=[ts('I0734','房内设施','卫生间不在阳台','require','要求卫生间位置不在阳台，不是否定卫生间')];change('I0734','保留卫生间不在阳台的复合范围')
by['I1111']['topics']=[ts('I1111','户型面积与居住方式','同找阁楼','require'),ts('I1111','房内设施','要求安静，独卫，能做饭','require','三项均为本人要求'),ts('I1111','位置通勤','区域优先','prefer','列举位置优先，其他地方亦可'),ts('I1111','位置通勤','其他地方也行','accept','其他地点也接受，具体地点待核')]
for r in by['I1111']['target_regions']:r['relation']='preferred';r['group_relation']='OR';r['condition_scope']='列示地域为优先选项，其他地方也可以'
by['I1111']['target_regions'].append({'text':'其他地方','quote':'其他地方','relation':'accepted','group_relation':'OR','condition_scope':'具体地域未指明'});change('I1111','将地区从硬限制改为优先并保留其他地方也行')
# Mixed: transferring an old room plus a change of residence or explicit cheaper alternative, while the new need is not established as active.
for k in ['I0464','I0534','I0739','I0740','I0767']:
 x=by[k];x['role']='mixed';x['demand_state']='unknown';x['interest']='uncertain';x['reason']='明确提供旧房转租，同时提及换房或新房选择；本人新租需求是否仍在推进待核，旧房条件不转为新需求。';x['needs_review']=[y for y in x['needs_review'] if '不能仅据此判 mixed' not in y];addreview(k,'确认新住处是否已落实、是否仍找房；旧房位置和条件不作为新需求。');change(k,'旧房供给与可能的新需求并存，保留待核')
for k in ['I0199','I0219','I0247','I0375','I0481','I0581','I0687','I0849']:
 addreview(k,'因工作变动或搬家转租；是否另有新住房需求未明确，不能据旧房条件推新需求。');change(k,'提示工作调动或搬家后的新住处状态待核')
# Ambiguous quantities never become confirmed price/area pools.
for k in ['I0713','I0727','I0993','I1033']:
 x=by[k];q='多少米';x['topics']=[t for t in x['topics'] if t['pool'] not in ('价格预算','户型面积与居住方式')];x['possible_topics'].append({'pools':['价格预算','户型面积与居住方式'],'quote':q,'subject':'unresolved','reason':'“多少米”可能指价格或面积，未辨清前不进入确定池。'});change(k,'以可能主题保留多少米的价格或面积歧义')
# Personal short-rental wording itself establishes rental intent; amount might mean money or length.
x=by['I0948'];x['role']='demand';x['demand_state']='active_at_comment';x['interest']='high';x['topics']=[ts('I0948','入住与租期','短租','ask','询问短租，价格或时长指向尚未明确')];x['possible_topics']=[{'pools':['价格预算','入住与租期'],'quote':'短租多少呀','subject':'own_demand','reason':'“多少”可能指价格或时长。'}];x['reason']='本人询问短租，结合房源语境是评论时租赁询盘；具体问价格还是时长尚待核。';x['needs_review']=['核对“多少”是金额还是时长，以及房源现状。'];change('I0948','本人短租语境成立，但价格与时长仍有歧义')
# Relative times are anchored only when a trustworthy timestamp is present; no implied appointment success.
def time(k,quote,role,normalized,verification):
 assert quote in src[k]['comment_text'];by[k]['time_mentions'].append({'quote':quote,'time_role':role,'anchor_source':'published_at','anchor_time':src[k].get('published_at'),'normalized':normalized,'verification':verification})
time('I0009','后天','viewing','2026-10-22','发表时间换算至上海时区为10月20日；该时间是询问并非约定成功。');change('I0009','后天以发表时点上海时间为锚，非预约成功')
time('I0754','这两天','viewing',None,'发表时点为2026-10-28；“这两天”具体边界及是否约成待核。');change('I0754','保留看房时间原话与发表锚点')
time('I0204','随时可以入住','move_in',None,'表示本人时间灵活，未说具体入住日期。');change('I0204','单独保留入住时点原话')
time('I0848','1到两个月','lease_duration','1至2个月','租期时长，不是入住日期。');change('I0848','保留本人短租时长')
time('I0888','长住','lease_duration',None,'具体租期与起始时间未说明。');change('I0888','保留本人长住表述')
# Rebuild legacy split without treating unknown topics or ambiguous candidate pools as confirmed.
for x in out:
 x['actual_pools']=copy.deepcopy(x['topics']) if x['role'] in ('demand','mixed') and x['interest'] not in ('uncertain','unrelated') else []
 x['pending_pools']=copy.deepcopy(x['topics']) if x['role']=='unknown' or x['interest']=='uncertain' else []
# Structural assertions and own-text quote audit over every record.
allowed_pools={'价格预算','位置通勤','户型面积与居住方式','房内设施','宠物','楼层电梯','入住与租期','房源状态','费用合同','看房联系'};errors=[]
for x in out:
 d=src.get(x['review_key']);
 if not d:errors.append([x['review_key'],'missing input']);continue
 text=d['comment_text']
 if (x['comment_id'],x['customer_uid'])!=(d['comment_id'],d['customer_uid']):errors.append([x['review_key'],'identity'])
 for q in x.get('evidence',[]):
  if q not in text:errors.append([x['review_key'],'evidence'])
 for field in ('topics','target_regions','time_mentions','other_constraints','possible_topics'):
  for q in x[field]:
   if q.get('quote') not in text:errors.append([x['review_key'],field])
 for t in x['topics']:
  if t['pool'] not in allowed_pools or t['polarity'] not in ('ask','require','prefer','reject','accept','conditional','fact','not_required','compare','unknown'):errors.append([x['review_key'],'topic enum'])
 if x['role']=='unknown' and x['interest']!='uncertain':errors.append([x['review_key'],'unknown consistency'])
 if x['human_confirmed'] or x['send_authorized'] or x['store_assignment'] is not None:errors.append([x['review_key'],'authorization'])
ins={(x['review_key'],x['comment_id']) for x in inputs};outs={(x['review_key'],x['comment_id']) for x in out}
with (p/'reviewed-v2.jsonl').open('w',encoding='utf8',newline='\n') as f:
 for x in out:f.write(json.dumps(x,ensure_ascii=False)+'\n')
# Explicit change ledger captures semantic updates and source links; prior file remains unchanged.
ledger={'source_rule':'business-text-20261029-v1','target_rule':'business-text-20261029-v2','method':'原逐条模型判断+全量结构和逐字证据检查+风险条目定向复核；非全量独立重判，不是用户金标。','prior_file':'final-reviewed.jsonl','new_file':'reviewed-v2.jsonl','semantic_changed_count':len(semantic),'semantic_changes':[{'review_key':k,'changes':v,'prior':{n:before[k].get(n) for n in ('role','demand_state','interest','topics','target_regions','needs_review')},'new':{n:by[k].get(n) for n in ('role','demand_state','interest','topics','target_regions','time_mentions','possible_topics','needs_review')}} for k,v in sorted(semantic.items())], 'mechanical_changes':'全量新增subject、condition_scope等字段，按既有角色保留或标 unresolved；增加空时间/其他限制/可能池并保留版本，不凭空补充条件。'}
(p/'changes-v2.json').write_text(json.dumps(ledger,ensure_ascii=False,indent=2),encoding='utf8')
lines=['# 第一批历史初判：新版规则定向复核','',ledger['method'],'','原文件完整保留；本次仅针对可明确定位的新版规则影响修正，仍可能有未发现的语义问题。','',f"定向改变或补注 {len(semantic)} 条；全部 {len(out)} 条完成结构与引文检查。",'']
for k,v in sorted(semantic.items()):lines.append(f"- {k}：{'；'.join(v)}。")
(p/'changes-v2.md').write_text('\n'.join(lines)+'\n',encoding='utf8')
report={'input_count':len(inputs),'prior_count':len(old),'output_count':len(out),'input_unique_key_count':len(ins),'output_unique_key_count':len(outs),'id_sets_equal':ins==outs,'all_evidence_and_quotes_in_own_comment':not errors,'errors':errors,'semantic_review_count':len(semantic),'role_counts':dict(collections.Counter(x['role'] for x in out)),'interest_counts':dict(collections.Counter(x['interest'] for x in out)),'human_gold':False,'full_independent_reclassification':False,'source_unchanged_sha256':hashlib.sha256((p/'final-reviewed.jsonl').read_bytes()).hexdigest()}
(p/'v2-validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8');print(json.dumps(report,ensure_ascii=False,indent=2))
