import json,pathlib,sys
D=pathlib.Path(__file__).resolve().parent.parent
r=[json.loads(l) for l in (D/'shard1.jsonl').read_text(encoding='utf-8').splitlines()]
c=json.loads((D/'shared-contexts.json').read_text(encoding='utf-8'))
a=int(sys.argv[1]);b=int(sys.argv[2])
for i,x in enumerate(r[a:b],a):print(i,x['comment'],'|CTX',x['context_key'])
for k in dict.fromkeys(x['context_key'] for x in r[a:b]):print('POST',k,json.dumps(c['posts'][k]['content'],ensure_ascii=False))
