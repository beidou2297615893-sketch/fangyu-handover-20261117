"""Read-only source checks and real isolated mother_adapter preflight. No publication."""
import json, hashlib, sys
from pathlib import Path
from collections import Counter
HERE=Path(__file__).resolve().parent
BASE=HERE.parents[1]
WORK=BASE.parents[2]
sys.path.insert(0,str(WORK))
from mother_adapter import validate_new_review
def read(path):return [json.loads(l) for l in path.read_text(encoding='utf8').splitlines() if l.strip()]
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
src=read(BASE/'shard-1.jsonl'); out=read(BASE/'reviewed-new-1.jsonl')
idx={s['review_key']:s for s in src}
assert len(src)==len(out)==len(idx)==473
assert set(idx)=={r['review_key'] for r in out}
assert len({r['review_key'] for r in out})==473
assert len({r['comment_id'] for r in out})==473
quotes=0
for r in out:
 s=idx[r['review_key']]
 for f in ('review_key','comment_id','customer_uid','video_id','platform'):assert r[f]==s[f],(r['review_key'],f)
 assert r['human_confirmed'] is False and r['send_authorized'] is False and r['store_assignment'] is None
 assert not any(k.startswith('classification_') for k in r),'Final semantic output must not include compiler binding metadata'
 own=s['comment_text']; same=s['post_body'] if s['post_author_same_as_commenter'] else ''
 for q in r['evidence']:
  assert q and (q in own or same and q in same),(r['review_key'],'evidence',q)
  quotes+=1
 for fld in ('topics','target_regions','time_mentions','other_constraints','possible_topics','contact_boundaries'):
  for item in r[fld]:
   if isinstance(item,dict) and 'quote' in item:
    q=item['quote'];assert q and (q in own or same and q in same),(r['review_key'],fld,q)
    quotes+=1
 for rg in r['target_regions']:assert rg['text'] in own,(r['review_key'],rg)
 assert r['reply_plan']['preferred_mother_slot'] in (None,1,2,7,13,16,19,25,28,31,34)
 assert isinstance(r['context_flags'],dict) and isinstance(r['contact_boundaries'],list)

page_counts=[]
for p in range(3):
 pg=json.loads((HERE/f'page-{p:02d}.json').read_text(encoding='utf8'))
 expected={c['key'] for post in pg['shared_post_context'] for c in post['comments']}
 result=read(HERE/f'reviewed-{p:02d}.jsonl')
 assert {r['review_key'] for r in result}==expected
 assert all(r==next(x for x in out if x['review_key']==r['review_key']) for r in result)
 page_counts.append(len(result))

semantic={r['review_key']:r for r in out}
for key in ('D0014','D0218','D0368','D0371','D0713','D0785','D0968','D1025','D1178','D1385'):
 assert semantic[key]['possible_topics'] and not semantic[key]['topics'],key
for key in ('D0046' if False else 'D0446','D0587','D0590','D0593','D0596','D0602','D0917','D1067','D1373'):
 assert semantic[key]['role']=='supply',key
for key in ('D0191','D0275','D0620','D0926','D1295','D1313','D1394'):
 assert semantic[key]['interest']=='super_high',key
for key in ('D0239','D0401','D1301','D1418'):
 assert semantic[key]['demand_state']=='active_at_comment' and semantic[key]['time_mentions'],key
assert semantic['D0485']['demand_state']=='future'
assert semantic['D0875']['reply_plan']['generic_intro_suitable'] is False
assert semantic['D0497']['role']=='unknown'
assert semantic['D0932']['interest']=='uncertain'
assert semantic['D1340']['topics'][-1]['polarity']=='reject'

# The transport pointer must match bytes on disk and the isolated staging records exactly.
staged=[]
for r in out:
 c=dict(r)
 c.update(classification_method='ai_semantic_initial_and_detailed',classification_stages_completed=['initial_semantic','detailed_semantic'])
 staged.append(c)
source=HERE/'isolated-classification-source.jsonl'
source.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in staged),encoding='utf8')
digest=sha(source)
validated=[];cache={}
for r in staged:
 c=dict(r); c['classification_review_source']={'path':str(source.relative_to(BASE)),'sha256':digest}
 validate_new_review(c,BASE,cache)
 validated.append(c)
(HERE/'isolated-preflight-with-source.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in validated),encoding='utf8')
report=dict(shard=1,input_count=len(src),output_count=len(out),pages=page_counts,id_sets_equal=True,all_identity_fields_equal=True,duplicates=0,evidence_quotes_checked=quotes,evidence_failures=0,approved_mother_slots_only=True,adapter_preflight_passed=len(validated),adapter_preflight_failed=0,adapter_source=str(source.relative_to(BASE)),adapter_source_sha256=digest,semantic_file_sha256=sha(BASE/'reviewed-new-1.jsonl'),classification_method='ai_semantic_initial_and_detailed',independent_second_review=False,formal_compiler_binding=False,platform_calls=0,send_authorized=False,roles=dict(Counter(r['role'] for r in out)),interest=dict(Counter(r['interest'] for r in out)),unknown_retained=sum(r['role']=='unknown' for r in out),store_assignment_null=all(r['store_assignment'] is None for r in out),scope='本片473条；不改变其他片或全局；不发送，不访问平台/凭据/源库')
(BASE/'shard-1-validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
(BASE/'shard-1-report.md').write_text(f'''# 抖音文本判读第2片核对报告

已完整阅读3页共享正文和本人原评论，逐条完成473条AI初筛及同轮细筛；代码只序列化显式决定，不以关键词规则判意向。本次不是独立二审，也不等于用户金标。

- 输入473条，输出473条，各页为{page_counts}；key、comment_id、customer_uid、video_id、platform逐条一致，集合相等，无重复。
- 本人逐字证据及各结构引文共核{quotes}处，失败0；不从他人正文、IP或来源门店补本人条件。
- 现有mother_adapter.validate_new_review真实隔离预检473/473通过，使用实际隔离JSONL及SHA；正式语义文件没有编译绑定元数据，正式绑定交compiler。
- 独立保留供给、未知、住宅与办公用途、免费驿站申请、相对时间角色、明确拒绝合租及条件性步梯接受；多少米歧义保留候选，不作确定分池。
- 看房联系泛请求为高；明确约时段或签约推进才可超高。供应与帖子条件不冒充本人求租条件；未知不强判无关。
- 回复仅选择认可母句槽位，不重新创作正文；门店、真实住户身份、优惠、预算内房态和专项条件联立都留事实待核。allow仅为文本未表达联系限制，绝非发送许可。
- 全部human_confirmed=false、send_authorized=false、store_assignment=null；平台调用0，未发送，未改其他片、全局、产品代码或源库。

角色分布：{report['roles']}。
意向分布：{report['interest']}。

语义结果SHA256：{report['semantic_file_sha256']}
隔离评审来源SHA256：{digest}

待root另行复核；本片处理到此停止。
''',encoding='utf8')
print(json.dumps(report,ensure_ascii=False,indent=2))
