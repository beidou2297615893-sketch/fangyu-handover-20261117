import json,pathlib,collections
W=pathlib.Path('work/fangyu-text-business-20261029');c=json.loads((W/'region-brand-routing/current.json').read_text(encoding='utf8')); groups=collections.defaultdict(list)
for p,f in c['results'].items():
 for l in open(f,encoding='utf8'):
  r=json.loads(l);s=r.get('source_record') or {};a=s.get('classification') if isinstance(s.get('classification'),dict) else s;t=r['comment_text']; candidate=bool(r.get('mother_reply_text') or r.get('alternative_mother_reply_text'))
  tests={'inclusive_budget':candidate and any(x in t for x in ['含水电','包水电','包括水电','加水电','水电在内']),'contact_block':r.get('contact_policy') in ('no_contact','unknown'),'pet_literal':candidate and any(x.get('pool')=='宠物' for x in a.get('topic_evidence',a.get('actual_pools',[])) if isinstance(x,dict)) and len(t)<30,'negative_requirement':candidate and '不要' in t and len(t)<35}
  for k,v in tests.items():
   if v and len(groups[k])<2:groups[k].append({'platform':p,'cid':r['comment_id'],'uid':r['customer_uid'],'text':t,'topics':a.get('topics'),'ev':a.get('topic_evidence',a.get('actual_pools',[])),'regions':r.get('target_regions'),'time':r.get('time_mentions'),'contact':r.get('contact_policy'),'candidate':candidate})
print(json.dumps(groups,ensure_ascii=False,indent=1));(W/'pool-mother-review/legacy-local-planning/edge-selection.json').write_text(json.dumps(groups,ensure_ascii=False,indent=2),encoding='utf8')
