import json,pathlib,sys
base=pathlib.Path(__file__).resolve().parents[1]
p=base/'recall-audit'/'part-1'/f'page-{int(sys.argv[1]):02}.json'
d=json.loads(p.read_text(encoding='utf-8-sig'))
# Lossless string dictionary: repeated prose is read once, every record references it.
strings={}; vals=[]
def pack(x):
    if isinstance(x,str) and len(x)>14:
        if x not in strings: strings[x]=len(vals); vals.append(x)
        return '@'+str(strings[x])
    if isinstance(x,list): return [pack(v) for v in x]
    if isinstance(x,dict): return {k:pack(v) for k,v in x.items()}
    return x
start=int(sys.argv[2]) if len(sys.argv)>2 else 0
end=int(sys.argv[3]) if len(sys.argv)>3 else 1000
ix=0
pool={'价格预算':'价','位置通勤':'地','户型面积与居住方式':'型','房内设施':'设','宠物':'宠','楼层电梯':'梯','入住与租期':'期','房源状态':'态','费用合同':'费','看房联系':'联'}
def short(v,text):
    if isinstance(v,list): return [short(a,text) for a in v]
    if isinstance(v,dict): return {k:short(a,text) for k,a in v.items()}
    if v==text:return '='
    return pool.get(v,v) if isinstance(v,str) else v
lines=[]
for g in d['post_groups']:
    chosen=[]
    for c in g['comments']:
        n=ix;ix+=1
        if not start<=n<end:continue
        j=c['first_semantic_judgment'];t=c['text'];o={'k':c['key'],'text':t,'at':c['published_at']}
        if c['same_author']:o['same_author']=True
        if c['parent'] is not None:o['parent']=c['parent']
        if c['reply_to']!='0':o['reply_to']=c['reply_to']
        if c['source_conflict']:o['conflict']=True
        o['J']=[j['role'],j['demand_state'],j['interest'],j['reason']]
        for k in ('topics','target_regions','time_mentions'):
            if j[k]:o[k]=[[short(v,t) for v in a.values()] for a in j[k]]
        for k in ('other_constraints','possible_topics','needs_review','contact_boundaries','context_flags'):
            if j.get(k):o[k]=short(j[k],t)
        o['context']=j['context_used']
        p=j['reply_plan'];o['plan']=[p[k] for k in ['preferred_mother_slot','generic_intro_suitable','tone','missing_facts','caution','contact_policy']]
        chosen.append(o)
    if chosen:
        lines.append(('BODY',g['post_body']))
        lines.extend(('C',x) for x in chosen)
# Deduplicate only repeated prose >=20 chars, keeping original body/comment intact.
counts={}
def count(x):
    if isinstance(x,str) and len(x)>19:counts[x]=counts.get(x,0)+1
    elif isinstance(x,list):
        for a in x:count(a)
    elif isinstance(x,dict):
        for a in x.values():count(a)
for typ,v in lines:
    if typ=='C':count({k:x for k,x in v.items() if k!='text'})
refs={s:'@'+str(i) for i,(s,n) in enumerate((x for x in counts.items() if x[1]>1))}
def ref(x):
    if isinstance(x,str):return refs.get(x,x)
    if isinstance(x,list):return [ref(a) for a in x]
    if isinstance(x,dict):return {k:(a if k=='text' else ref(a)) for k,a in x.items()}
    return x
print('Default omitted fields: same_author=false,parent=null,reply_to=0,conflict=false; empty judgment lists. J=role/state/interest/reason; plan=slot,generic,tone,missing,caution,policy. Topic arrays follow pool/quote/polarity/subject/scope; regions text/quote/relation/group/scope; times quote/role/anchor_source/time/normalized/verification. = means full current comment. Pools 价地型设宠梯期态费联 per contract.')
for s,r in refs.items():print(r+'='+s)
for typ,v in lines:print(typ,json.dumps(ref(v) if typ=='C' else v,ensure_ascii=False,separators=(',',':')))
