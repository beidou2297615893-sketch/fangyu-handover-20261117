import json,hashlib,sqlite3,re
from pathlib import Path
R=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent;D=W/'delivery-v2';D.mkdir(exist_ok=True)
B=R/'work/xhs-account-switch-recovery-candidate/runtime';db=sqlite3.connect((R/'work/shared-acquisition-ledger/shared.sqlite3').as_uri()+'?mode=ro',uri=True)
rows=[];receipts=[];seen=set()
for name in ['resume-new10000-20261029-batch23','resume-new10000-20261029-batch39']:
 base=B/name;p=base/'analysis-manifest.jsonl'
 for line in p.read_text(encoding='utf8').splitlines():
  e=json.loads(line)
  if e['status']!='registered_ready_for_classification':continue
  f=(base/e['input']).resolve();assert f.is_relative_to(base.resolve());sha=hashlib.sha256(f.read_bytes()).hexdigest();assert sha==e['sha256']
  reg=json.loads((f.parent/'register-result.json').read_text(encoding='utf8'));reg=reg.get('result',reg)
  ready=json.loads((f.parent/'registered-ready.json').read_text(encoding='utf8'));assert ready['registered'] and reg['mode']=='apply' and reg['inserted']==ready['inserted_comments']==e['inserted_comments']
  flat=[]
  for parent in json.loads(f.read_text(encoding='utf8')):
   for child in [parent,*parent.get('other_comments',[])]:
    same=not child.get('note_id') or child.get('note_id')==parent.get('note_id')
    row={k:child.get(k) for k in ['comment_id','comment_text','published_at','parent_text','parent_relationship','ip_location','ip_location_source','missing_context']}
    row.update(platform='xiaohongshu',customer_uid=child.get('customer_uid',parent.get('customer_uid')),note_id=child.get('note_id',parent.get('note_id')),
     post_title=child.get('post_title') or (parent.get('post_title','') if same else ''),post_text=child.get('post_text') or (parent.get('post_text','') if same else ''),
     batch=e['batch'],keyword=e['keyword'],page=e['page'],source_account_uid=e['account_uid'],registration_source=e['registration_source'],input_sha256=sha,collection_store='古北搜索来源；非客户归属',send_authorized=False)
    found=db.execute('select source,status from leads where platform=? and comment=?',('xiaohongshu',row['comment_id'])).fetchall();assert len(found)==1 and found[0][0]==e['registration_source'];row['ledger_status']=found[0][1]
    flat.append(row)
  assert len(flat)==len({x['comment_id'] for x in flat})==e['inserted_comments']
  for row in flat:
   assert row['comment_id'] not in seen;seen.add(row['comment_id']);rows.append(row)
  receipts.append({'batch':e['batch'],'count':len(flat),'sha256':sha,'registration_verified':True})
assert len(rows)==2755
packed=''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in rows);p=D/'source-input.jsonl'
if p.exists():assert p.read_text(encoding='utf8')==packed
else:p.write_text(packed,encoding='utf8')
delta=[dict(x,review_key=f'N{i:04d}') for i,x in enumerate([x for x in rows if x['batch']=='batch-0039'],1)]
(D/'batch39-input.jsonl').write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in delta),encoding='utf8')
(D/'source-validation.json').write_text(json.dumps({'registered':len(rows),'distinct_uids':len({x['customer_uid'] for x in rows}),'sources':receipts,'source_sha256':hashlib.sha256(packed.encode()).hexdigest(),'batch40_partial_excluded':True,'source_database_modified':False,'sent':0},ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps({'registered':len(rows),'batch39':len(delta),'uids':len({x['customer_uid'] for x in rows})},ensure_ascii=False))
