"""Human-readable report from frozen audit evidence, with a read-only CLI preview."""
from datetime import datetime, timedelta, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import sys

HERE = Path(__file__).resolve().parent
WORK = HERE.parent
ROOT = WORK.parents[1]
def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))
def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

before_folder = HERE / 'snapshots/20261105-134956-715044'
before = read(before_folder / 'audit.json')
comparison = read(before_folder / 'before-after.json')
after_folder = Path(read(HERE / 'current.json')['snapshot'])
after = read(after_folder / 'audit.json')
status = read(after_folder / 'status.json')
assert after['rule_version'] == comparison['rule_version']
assert digest(after_folder / 'all-pool.jsonl') == after['source_sha256']
assert digest(after_folder / 'replies.jsonl') == after['result_sha256']
as_of = datetime.fromisoformat(after['classification_as_of']).astimezone(timezone(timedelta(hours=8)))
out = ROOT / 'outputs/方隅双平台文本业务/抖音筛选漏斗'
out.mkdir(parents=True, exist_ok=True)
lines = ['# 抖音筛选核对', '', f'分类快照：{as_of:%Y年%m月%d日 %H:%M:%S}。采集仍在继续，以下不是实时累计数。', '',
         '## 判断结果', '',
         '预算未知不等于预算不够。明确本人求租且无冲突，保留高意向；仅问价格、位置等为中意向；明确求租、预算匹配且评论近15天，才是超高意向。询价或写出金额本身都不足以升为超高。', '',
         '实际发现旧回复索引只接了部分历史意向，造成符合业务条件的人没有回复。已修复按池补母句，不额外逐条调用模型。', '',
         f'固定同一批{comparison["cohort_size"]:,}条评论、同一份账本、同一时刻复算：待回复由{comparison["before_pending"]:,}增到{comparison["after_same_cohort_pending"]:,}条，补齐{comparison["locally_completed"]}条（中意向{comparison["completed_intent"]["medium"]}、高意向{comparison["completed_intent"]["high"]}）。剩余{comparison["technical_waiting_after"]}条未自动套用，不冒充无效或已完成。', '',
         f'另有{len(comparison["conditional_restrictions_moved_to_review_not_sendable"])}条“不要中介／不要私信”等条件限制，从一概排除改为保留核对，未自动放行。真正的拒绝联系继续拦截。', '',
         '## 最新快照逐层对账', '',
         f'总登记{after["raw_registered"]:,}条，其中超过30天归档{after["archived_outside_30"]:,}条，日期异常隔离{after["quarantined_dates"]}条，30天有效池{after["active_count"]:,}条。', '',
         '| 条件 | 进入 | 本层移出 | 剩余 |', '|---|---:|---:|---:|']
for stage in after['layers']:
    lines.append(f'| {stage["layer"]} | {stage["input"]:,} | {stage["removed"]:,} | {stage["remaining"]:,} |')
lines += ['', '上表按顺序逐条归因，数量可相加；同一评论的多个标签不能重复算作流失。回复未备好包含待核旧意向，不能全部当成已通过独立细筛。', '',
          '## 不同处理状态', '', '| 状态 | 数量 |', '|---|---:|']
for label, count in after['retained_groups'].items():
    lines.append(f'| {label} | {count:,} |')
lines += ['', f'独立账本快照核对后，可保留排序的共{after["retained_sortable"]:,}条，其中含待核和待补回复；只有准备完成且通过发送前核验的才进入CLI。账本截取时点与分类快照略有不同，此表分组与上表分组顺序也不同，两表不能混加。', '',
          '## 预算与排序', '',
          '- 本人明确整租月预算上限低于3000元：低意向，退出待回复。3000—3999元：承接待核。4000元及以上：预算匹配，还需看本人求租意愿与时效。',
          '- 没报预算：保持未知，不因此删人。押金、工资、水电、过去租金、人均费用和日租不冒充整租月预算。',
          '- 来源帖明确月租低于3000元，且客户没有更强的兼容预算证据：低价来源排除。仅标题正文可见的价格有据；未提取的画面、口播保持未知。',
          '- 顺序固定为：近7天 → 8—15天 → 16—30天；同一时间档内先预算匹配，再意愿强弱，最后按原评论新旧。超过30天留历史档案，不进抖音有效待发池。',
          '- 例如：5天前预算未知的中意向，排在20天前预算5000元的高意向之前；同为近7天，则预算匹配优先。',
          '- 地区未知不硬归门店，也不因缺少“已核实门店”字段删人；明确地区冲突才拦截。', '',
          '## 修复与验证', '',
          '已补旧回复索引、明确询价及位置问法。评论“找了半天”不填成租半天；“不带猫”不套成可养猫；已联系、结果未知和占用记录不重发。CLI入队时再核最新业务条件，防止等待期间刚超过30天的旧快照继续入队。', '',
          '业务筛选15项、语义及母句补齐17项、时间排序及入队10项，共42项回归通过。这是针对行为的回归验证，不是全库准确率，也不是每条都重新经过AI或人工审核。', '',
          '历史非求租分类保留；抽核未发现明确本人求租被机械排除的样例，不据此承诺全部历史分类无误。疑难语境继续独立保留，后续只补必要上下文或小批复核。', '',
          '本次未请求平台、未发送评论、未改采集源库、未改真实发送回执，未停止采集。小红书不在本次核对范围内。', '']
(out / '筛选核对.md').write_text('\n'.join(lines), encoding='utf-8')
handoff = {'report': str(out / '筛选核对.md'), 'audit': str(after_folder / 'audit.json'),
           'baseline_comparison': str(before_folder / 'before-after.json'),
           'rule_version': after['rule_version'], 'active_pool_policy': after['active_policy'],
           'snapshot_as_of': after['classification_as_of'],
           'source_all_pool': str(after_folder / 'all-pool.jsonl'), 'source_sha256': after['source_sha256'],
           'result': str(after_folder / 'replies.jsonl'), 'result_sha256': after['result_sha256'],
           'pending': str(after_folder / 'pending.jsonl'), 'pending_sha256': after['pending_sha256'],
           'pending_count': after['actual_pending'], 'retained_with_review': after['retained_sortable'],
           'retained_queue_not_sendable': str(after_folder / 'retained-sorted.jsonl'),
           'live_status': str(ROOT / 'work/fangyu-douyin-independent/classification-handoff-status.json'),
           'live_order_pointer': str(WORK / 'recency-priority/daily-priority/current.json'),
           'cli_consumer_thread': '01a1983f-c793-7e50-aa95-54edf2224bfc',
           'consumer_read_confirmed': False, 'send_authorized_by_this_audit': False}
(HERE / 'handoff.json').write_text(json.dumps(handoff, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps({'report': str(out / '筛选核对.md'), 'as_of': as_of.isoformat(),
                  'active': after['active_count'], 'pending': after['actual_pending'],
                  'retained': after['retained_sortable'], 'handoff': str(HERE / 'handoff.json')}, ensure_ascii=False))
