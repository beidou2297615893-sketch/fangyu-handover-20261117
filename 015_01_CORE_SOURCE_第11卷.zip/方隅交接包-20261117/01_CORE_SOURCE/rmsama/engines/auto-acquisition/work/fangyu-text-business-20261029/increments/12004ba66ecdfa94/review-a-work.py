import json
from pathlib import Path
from collections import Counter

p=Path(__file__).parent
rows=[json.loads(s) for i in range(5) for s in (p/f'shard-{i:02}.jsonl').read_text(encoding='utf-8').splitlines()]
def ids(s): return {int(v) for v in s.split()}

# Each ID was assigned after reading the individual comment and its post title.
price=ids('''1 2 3 5 6 7 8 10 12 14 15 17 19 20 21 29 30 34 35 37 38 41 42 43 44 46 47 50 51 52 54 56 57 58 61 64 68 71 75 76 77 78 81 85 97 104 109 113 114 115 118 120 123 132 142 143 144 146 149 156 159 160 163 164 171 176 177 178 184 185 192 194 195 196 197 199 202 209 211 213 214 218 221 240 246 263 264 275 285 297 300 304 306 329 332 337 341 349 354 381 384 387 394 400 436 459 462 468 469 470 471 480 482 483 485 486 492 493 496 498''')
location=ids('''1 3 4 8 9 12 15 17 18 23 37 38 42 43 45 46 48 52 53 60 71 72 73 76 79 80 91 108 112 113 114 118 121 123 132 143 151 154 158 160 164 167 175 192 200 459 468 469 471 472 477 478 479 480 482 483 484 485 486 489 497 498 500''')
status=ids('''11 28 32 39 56 69 74 92 127 135 161 169 173 174 175 181 202 232 236 381 466''')
view=ids('''27 84 86 110''')
term=ids('''75 88 99 134 246 247 316''')
housing=ids('''40 63 91 102 142 150 153 160 165 180 190 203 224 259 281 287 288 328 370 383 407''')
pet=ids('''87''')
floor=ids('''31 80''')
facility=ids('''63 203''')
commercial=ids('''13 16 23 124 180 193 224''')
sale=ids('''457 458 460 461 464 465 467 473 475 476 481 487 488 490 491 494 499''')
unknown_context=ids('''2 9 20 22 24 25 26 31 35 36 40 41 44 47 49 63 70 74 80 81 82 87 88 89 91 93 94 95 96 98 99 100 105 107 111 112 116 121 122 125 126 127 131 134 135 138 139 140 142 143 144 146 149 150 151 152 154 158 159 163 164 167 170 171 178 183 185 186 189 191 192 198 207 208 213 217 220 221 223 225 230 235 246 247 256 267 268 270 278 279 280 281 286 290 301 303 309 314 315 317 319 324 325 327 331 342 343 348 351 355 356 360 363 364 370 371 373 374 375 376 377 378 386 389 390 393 395 397 401 405 407 412 418 419 423 424 432 434 435 438 441 443 445 449 450 451 453 454 474''')
supply=ids('''55 59 65 66 67 101 103 106 111 119 129 133 136 137 141 145 147 148 157 162 166 168 172 179 182 187 205 206 210 212 216 222 226 228 229 231 233 234 238 239 241 242 243 244 245 248 249 251 252 253 254 255 258 260 261 262 266 271 272 273 276 277 282 283 284 291 292 294 296 298 299 302 305 307 308 310 311 318 321 322 323 326 330 333 336 338 339 340 344 345 347 350 353 357 358 359 361 362 365 366 367 369 372 380 382 385 388 391 392 397 398 399 404 406 408 409 410 411 413 414 415 417 420 421 422 425 427 428 429 430 431 433 437 439 444 446 447 448 452 455 456 463''')
discussion=ids('''117 215 227 237 257 265 274 289 293 295 312 313 320 334 335 346 352 368 379 396 402 403 440 442''')
personal=ids('''102 153 165 190 201 203 204 219 259 269 281 287 288 328 370 383''')
ended=ids('''426''')
unclear_questions=ids('''22 24 25 26 33 36 49 62 70 74 82 83 89 90 93 94 95 96 98 99 100 105 107 112 116 121 122 124 125 126 127 130 131 134 135 138 139 140 142 143 144 146 149 150 151 152 154 158 159 163 164 167 170 171 178 183 184 185 186 189 191 192 198 207 208 213 217 220 221 223 225 230 235 246 247 256 267 268 270 278 279 280 281 286 290 301 303 309 314 315 317 319 324 325 327 331 342 343 348 351 355 356 360 363 364 371 373 374 375 376 377 378 386 389 390 393 395 401 405 407 412 418 419 423 424 432 434 435 438 441 443 445 449 450 451 453 454 474''')
# Remove explicitly supported rental questions and active first-person searches from ambiguity groups.
strong=ids('''1 3 4 5 6 7 8 10 11 12 14 15 17 18 19 21 27 28 29 30 32 34 37 38 39 42 43 45 46 48 50 51 52 53 54 56 57 58 61 64 68 69 71 72 73 75 76 77 78 79 84 85 86 92 97 102 104 108 109 110 113 114 115 118 120 123 128 132 153 156 160 161 165 169 173 174 175 176 177 180 181 190 193 194 195 196 197 199 200 201 202 203 204 209 211 214 218 219 224 232 236 246 247 259 263 264 269 275 281 285 287 288 297 300 304 306 316 328 329 332 337 341 349 354 370 381 383 384 387 394 400 426 436 459 462 466 468 469 470 471 472 477 478 479 480 482 483 484 485 486 489 492 493 495 496 497 498 500''')
strong |= commercial | sale
strong |= ids('63 87 88 91')
strong |= ids('188')
status |= ids('188')
strong -= ids('28 84 110 156 194 195 232 328 337 341 370 470')
unclear_questions |= ids('28 84 110 156 194 195 232 328 337 341 470')
unclear_questions |= ids('2 9 20 31 35 40 41 44 47 60 80 81 155 240 250 416')

# Explicitly named offered locations, never inherited from source title or IP.
offered={59:'兴亚广场',65:'普陀真如高尚领域',66:'三元桥',67:'通州区张家湾',103:'玉华苑',141:'静安寺嘉里中心对面',145:'江宁路地铁站',147:'名都古北',162:'普陀武宁路地铁口',166:'上海市闵行区吴中路405弄',168:'上海黄浦区的海华花园',179:'交通大学站附近',182:'武康大楼旁',187:'祁安路',205:'古北虹桥路',206:'徐汇区',234:'长寿路地铁口',242:'天山五村',251:'江苏路愚园路镇宁路附近',252:'上海长寿路苏州河地段',253:'源达大厦',254:'源达大厦',255:'中宁路站',258:'闵行莘庄春申路都市路',260:'世纪大道站',261:'大柏树地铁站',266:'赤峰路地铁站附近',271:'上海宝山',272:'虹足附近',276:'宝山区7号线刘行地铁站',277:'赤峰路曲阳路',282:'中山新村',283:'愚园路',292:'交大',294:'徐汇田林桂林新苑',298:'国际会展中心旁边二联家园',302:'颛桥',305:'四平路',307:'金运路',308:'七莘路地铁站',321:'杨浦凯兴苑',322:'花木苑',323:'静安大悦城旁边',330:'杨浦区',333:'闵行交大附近',338:'富锦路',339:'同济大学附近',340:'上海南站附近',344:'曲阳路地铁',347:'闵行众秀新家园',350:'中潭路地铁站',353:'赤一小区',357:'赤峰路地铁',358:'虹口足球场',359:'闵行伊犁南路24弄',361:'微领地北虹桥社区',362:'上钢一村1200弄',366:'赤一小区',367:'九亭',369:'逸仙路 1230 弄镇北小区',372:'宝山顾村',380:'普陀区志丹路77号',385:'密云小区',391:'普陀区长宁区交界',392:'普陀区长宁区交界',406:'虹口曲阳东四小区',408:'真新新村地铁口',409:'顾村环绿国际',410:'大柏树江湾殷高西路',411:'高科苑',413:'闵行元吉小区南区',414:'张江川扬新苑四期',415:'杨浦区隆昌',417:'莘庄地铁',425:'莘庄',427:'虹口区广灵二村',429:'宝山区7号线地铁口',430:'宝山区7号线顾村公园～美兰湖',431:'广灵二路',437:'静安区柳营路',439:'徐汇桂林路',448:'上海万洋科技城',452:'曲阳路地铁口',455:'浦东南路浦三路海浦小区',456:'浦东南路浦三路海浦小区'}
topic_sets=[('价格预算',price),('位置通勤',location),('房源状态',status),('看房联系',view),('入住与租期',term),('户型面积与居住方式',housing),('宠物',pet),('楼层电梯',floor),('房内设施',facility)]
out=[]
for d in rows:
 n=int(d['review_key'][1:]); t=d['comment_text']
 a=dict(role='unknown',demand_state='unknown',interest='uncertain',topics=[],target_regions=[],reason='评论指代对象或本人供需角色不明确。',context_used=['own'],needs_review=['需核对缺失的父评论或具体房源内容，确定说话对象和本人角色。'])
 if n in supply:
  a.update(role='supply',interest='unrelated',reason='评论者提供或推广房源、场地或相关服务，并非本人明确求租。',needs_review=[])
  if n in offered: a['target_regions']=[dict(text=offered[n],quote=offered[n],relation='offered')]
  if n==362: a['role']='mixed'; a['interest']='uncertain'; a['needs_review']=['保底房转租并称看到目标区域房源，但是否已经另行签约及需求是否结束未知。']; a['reason']='明确转租保底房，同时提到目标区域另有房源，保留可能的另找房需求。'
 elif n in discussion:
  a.update(role='discussion',interest='unrelated',reason='提供经验、评论或建议，没有表达本人新的租房需求。',needs_review=[])
 elif n in ended:
  a.update(role='demand',demand_state='ended',interest='unrelated',reason='本人明确表示已经找到房子。',needs_review=[])
 elif n in strong:
  a.update(role='demand',demand_state='active_at_comment',interest='high',reason='针对出租或转租内容提出具体询问，体现评论时兴趣。',context_used=['own','title'],needs_review=['评论为历史时点兴趣，当前需求状态未知。'])
  for pool, group in topic_sets:
   if n in group: a['topics'].append(dict(pool=pool,quote=t,polarity='ask'))
  if n in personal: a.update(reason='评论者表达本人寻找或合租房源的需求。',context_used=['own'])
  if n in (27,86): a['interest']='high'; a['reason']='询问能否看房，未提出具体预约时间。'
  if n==128: a['topics']=[dict(pool='看房联系',quote='有房子视频吗 可以看看吗',polarity='ask')]
  if n in (13,16,23,124,180,193,224): a['interest']='unrelated'; a['reason']='对象是办公、仓储或美业场地，非住宅租赁需求。'; a['needs_review']=['场地细节及后续状态未知。']
  if n in sale: a['interest']='unrelated'; a['reason']='针对房东直卖房源咨询，属于买房相关而非住宅租赁。'; a['needs_review']=['购房目的和后续状态未知。']; a['topics']=[]
  if n==495: a['topics']=[dict(pool='费用合同',quote=t,polarity='ask')]
  if n in (201,204,219,259,281): a['needs_review']=['“同求／我也找”所指具体条件只见帖子标题，不能继承为本人要求。']
  if n==102: a['target_regions']=[dict(text='上海',quote='上海',relation='desired')]; a['topics']=[dict(pool='户型面积与居住方式',quote='三室一厅',polarity='require')]
  if n==165: a['topics']=[dict(pool='户型面积与居住方式',quote='合租一居',polarity='require'),dict(pool='价格预算',quote='预算2k多',polarity='require')]
  if n==190: a['topics']=[dict(pool='户型面积与居住方式',quote='两室或以上整租',polarity='require'),dict(pool='费用合同',quote='房东直租',polarity='require')]
  if n==203: a['topics']=[dict(pool='价格预算',quote='预算8k以下',polarity='require'),dict(pool='房内设施',quote='装修可放低要求',polarity='accept'),dict(pool='位置通勤',quote='位置可放宽',polarity='accept')]; a['needs_review']=['“要求一样”的具体指代只见标题；车位需求无合适房内设施池，保留在原文证据。']
  if n==224: a['topics']=[dict(pool='户型面积与居住方式',quote='求工作室',polarity='require')]; a['needs_review']=['“同地址”缺少本人评论中的具体地区；办公用途非住宅。']
  if n==259: a['topics']=[dict(pool='户型面积与居住方式',quote='搞个大一点的跟你合租也行',polarity='accept')]
  if n==269: a['topics']=[]; a['needs_review']=['“那一块”具体地点只见标题，评论本身未明示。']
  if n==287: a['topics']=[dict(pool='户型面积与居住方式',quote='找已租好房缺室友的女生',polarity='require')]; a['target_regions']=[dict(text='上海徐汇',quote='上海徐汇',relation='desired')]
  if n==288: a['topics']=[dict(pool='入住与租期',quote='10月住',polarity='require')]; a['needs_review']=['“同求”条件不能直接从标题继承；所述入住为2026年10月，现状未知。']
  if n==328: a['topics']=[dict(pool='入住与租期',quote='差不多这个时间要搬',polarity='require')]; a['needs_review']=['“这个时间”指代仅见标题且未具体说明，不能自行定日期。']
  if n==383: a['topics']=[]; a['interest']='medium'; a['needs_review']=['未明确具体房型、地点与时间。']
 elif n in unclear_questions:
  if t.startswith('[视频]'): a['needs_review']=['仅有视频标记，视频内容未采集，无法确定供需角色。']
  elif n==93: a['needs_review']=['“多少米”可能指价格或面积，未确认前不归入价格或面积池。']
  elif n in (337,341,470): a['needs_review']=['只问“多少”，不确定是价格、面积或其他数值，需核对上下文。']
  elif n in (84,110): a['needs_review']=['提到什么时候看或明天去看，但缺少所看对象及父评论，不能确认是约看租房。']
  elif n==28: a['needs_review']=['问是否租出去但缺少帖子和父评论，无法确定询问者是求租方或其他角色。']
  elif n==328: a['needs_review']=['表示要搬，但未说明是另找住处还是提供房源，具体时间指代也缺失。']
  elif n in (24,25,155): a['needs_review']=['“搬家的”可能指搬家的人或服务，缺少父评论。']
  elif n in (2,9,20,31,35,40,41,44,47,49,60,63,70,74,80,81,87,88,91,112,121,127,135,142,143,144,146,149,150,151,154,158,159,163,164,167,171,178,184,185,192,194,195,213,221,232,240,303): a['needs_review']=['标题未明确是住宅出租还是出售，需核对原帖详情及评论者目的。']
  elif n in (246,247): a['needs_review']=['虽询问租期，但是否本人欲租及具体对象仍需核实。']
  else: a['needs_review']=['短句所指内容、对象或房源供需角色不明，需核对帖子正文或父评论。']
  for pool,group in topic_sets:
   if n in group and n not in (93,337,341,470,84,110,328): a['topics'].append(dict(pool=pool,quote=t,polarity='ask'))
 if n==370: a['needs_review']=['询问16号入住及一个月短租，但评论是求租还是提供给发帖人的房源不明，月份也未明确。']; a['topics']=[]
 if n==386: a.update(role='demand',demand_state='unknown',interest='uncertain',reason='评论提到本人也找不到短租，但陈述多为经验，是否仍在找不确定。',needs_review=['本人短租需求是否仍在持续需核实。'])
 if n==13 or n==16: a['topics']=[dict(pool='价格预算',quote=t,polarity='ask')]
 if n==23: a['topics']=[dict(pool='位置通勤',quote=t,polarity='ask')]
 if n==426: a['topics']=[]; a['evidence_override']=['本人现在已经找到房子啦']
 if n in (201,204,219,259,269,281,287,288,383): a['interest']='medium' if n in (201,204,219,259,281,383) else 'high'
 if n in (1,3,4,7,8,12,15,17,18,19,21,29,30,37,38,42,43,45,46,48,50,51,52,53,54,57,58,64,68,69,71,72,73,75,76,78,85,113,123,128,132,169,181,232,236,316): a['needs_review'].append('“个人转租”标题未说明房屋具体用途，需核实住宅属性。')
 evidence=a.pop('evidence_override',[t]); out.append(dict(review_key=d['review_key'],comment_id=d['comment_id'],customer_uid=d.get('customer_uid'),**a,evidence=evidence,human_confirmed=False,send_authorized=False,store_assignment=None))

assert len(rows)==len(out)==500
assert len({r['review_key'] for r in rows})==500
assert {(r['review_key'],r['comment_id']) for r in rows}=={(r['review_key'],r['comment_id']) for r in out}
for r,o in zip(rows,out):
 for v in o['evidence']+[x['quote'] for x in o['topics']]+[x['quote'] for x in o['target_regions']]: assert v in r['comment_text'], (r['review_key'],v)
 assert not (o['role']=='unknown' and o['interest']=='unrelated')
(p/'reviewed-a.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in out),encoding='utf-8')
val=dict(input_count=len(rows),output_count=len(out),unique_review_keys=len({x['review_key'] for x in out}),id_pairs_equal=True,all_evidence_and_quotes_verbatim=True,role_counts=dict(Counter(x['role'] for x in out)),interest_counts=dict(Counter(x['interest'] for x in out)),needs_review_count=sum(bool(x['needs_review']) for x in out),human_confirmed=False,send_authorized=False)
(p/'a-validation.json').write_text(json.dumps(val,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print(json.dumps(val,ensure_ascii=False,indent=2))
