# 审核后本地激活与回退步骤（仅准备，未执行）

本文件不是激活命令。当前 `candidate-repaired/` 仍为 needs_independent_astra_semantic_gate，未通过该门禁前不得改变任何实际指针。两条已发表批次拟修继续只作为旁注，不计作已修正。

## 必备条件

1. Astra 最终独立复核针对本候选的固定合同、计划、两平台结果及修补输入 SHA 明确通过；若要求修补或资产哈希变更，先生成新候选、重放检查及重新取得相应门禁。技术校验不得代替语义 gate。
2. 读取 `technical-validation-repaired.json`，核对候选结果、全部 366 家族矩阵、813 条新旧草稿账本及源分类文件哈希；全量核对 CID、UID、原文 SHA、原选择、原分类指纹、联系边界与发送 false。历史 6,274 条仍是基础稿待绑定，不得统计为已短化。确认接话是文案类型，不是新线索或意向分类。
3. 以 `candidate-repaired/immutable-baseline/` 中的三个原始指针快照及 `candidate-manifest.json` 里的三个 expected_previous_* SHA 为乐观并发基线，逐个确认当前真实 region current、主回复指针和 latest-manifest 仍与快照一致。任一发生变化即中止，重新对齐新源后构建；不得覆盖别的窗口更新。运行状态文件不作为回退对象，不用旧快照覆盖。
4. 运行消费者兼容性预演。原 `current.json` 具有 `manifest`、`manifest_sha256`、`results`、`result_sha256`、`summary`、`validation` 等真实消费字段；候选内的 `candidate-pointer.json` 只是说明，不可直接拷贝为真实 current。必须先在隔离位置准备和验证兼容的版本化 manifest、summary、validation、region current 与主回复指针文本，检查两平台原分类 34,840/3,601、原始分类文件 SHA、全部 38,441 条行、原选择总数、备选、历史旧稿、发送 false；更正旧版按策略细分的统计，不能把旧的 historical_basic_selected 或全部已短化标签原样搬到新结果。保留旧 f98 807 批的合同/计划/已发表状态和原稿。
5. 版本化新 manifest 只把 `immutable-baseline/region-current.json` 等快照作为旧基线证据，将 `expected_previous_pointer_sha` 单独列为激活前比较条件。不要把可变路径 `region-brand-routing/current.json` 的旧 SHA 放进激活后仍要求读取同一路径的不可变源清单，否则指针切换后立即自我失效。源分类和候选数据用各自不可变文件 SHA 固定。

## 提交与核验方案（须由主任务后续执行）

- 先明确本地消费者的读取锁或维护窗口；两个指针分别替换不是跨文件原子事务。在没有隔离读者或版本一致性守卫的情况下，不应进行双指针切换。
- 将准备好的新版本材料先放到独立、稳定的版本目录并逐文件回读校验；再次比较三个真实指针的 expected_previous SHA。按消费者兼容协议逐一使用同卷临时文件与原子替换写入 region current、主回复指针和若有需要的 latest-manifest，保证过程中读者不可见混合版本；每一步记录前后 SHA 和结果。不重写源分类、账号、采集、发送回执或运行状态。
- 立即以真实读取器回读三个引用，逐一核新 manifest、合同、两平台结果 SHA 和统计，确认主回复指针与 region current 指向同一版本、UID与去重不变、send_authorized/can_send_now 均 false。失败时停止读者，按本地回退步骤处理并记录事实；不得自动向平台发送。
- 不直接运行现有 `region-brand-routing/sync_reply_pointer.py`：该脚本除更新主回复指针，还会写入当前文本处理运行状态并按旧 summary 生成字段；不符合此轮只更新指针及不回滚状态的边界。应先完成独立受控的兼容桥及隔离验证。

## 回退方案（须由主任务后续执行）

在同样的读取锁或维护窗口下，先确认待回退的当前三个指针仍是本次激活产生的确切 SHA；发生新的并发更新则停止，由主任务对齐，不覆盖他人结果。在确认无并发变化后，以快照字节和原子替换恢复三个旧指针并回读哈希；旧分类、旧稿和版本目录从未覆盖，无须重写。只回退指针，不回滚运行状态、分类、采集、回执或新增数据；保留本次候选、激活记录与失败证据。
