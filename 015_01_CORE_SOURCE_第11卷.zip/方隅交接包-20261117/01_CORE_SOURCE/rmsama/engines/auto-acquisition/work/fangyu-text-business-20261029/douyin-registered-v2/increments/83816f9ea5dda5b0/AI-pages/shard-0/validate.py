import json,pathlib,hashlib,sys,collections,copy,datetime
from materialize import build
P=pathlib.Path(__file__).resolve().parent
B=P.parent.parent
W=B.parents[2]
sys.path.insert(0,str(W))
import mother_adapter
read=lambda p:[json.loads(l) for l in p.read_text('utf-8-sig').splitlines() if l.strip()]
for n in range(9): build(n)
src=read(B/'shard-0.jsonl'); pages=[read(P/f'reviewed-{n:02}.jsonl') for n in range(9)];rows=sum(pages,[])
by={r['review_key']:r for r in src}
assert len(src)==len(by)==len(rows)==1460
assert [len(p) for p in pages]==[180]*8+[20]
assert {r['review_key'] for r in rows}==set(by)
assert len({r['comment_id'] for r in rows})==1460
assert {r['comment_id'] for r in rows}=={r['comment_id'] for r in src}
explicit=[x for n in range(9) for x in json.loads((P/f'semantic-decisions-{n:02}.json').read_text('utf-8'))]
assert len(explicit)==1460 and {r['key'] for r in explicit}==set(by)
quotes=0
for r in rows:
 s=by[r['review_key']]
 for k in ('review_key','platform','comment_id','customer_uid','video_id'):assert r[k]==s[k],(r['review_key'],k)
 allowed=[s['comment_text']]+([s['post_body']] if s['post_author_same_as_commenter'] else [])
 for q in r['evidence']+[t['quote'] for f in ('topics','target_regions','time_mentions','other_constraints','contact_boundaries','possible_topics') for t in r[f] if isinstance(t,dict) and 'quote' in t]:
  assert any(q in a for a in allowed),(r['review_key'],q)
  quotes+=1
 assert not any(k in r for k in ('classification_method','classification_stages_completed','classification_review_source','reply_text','mother_reply_text'))
 assert r['human_confirmed'] is False and r['send_authorized'] is False and r['store_assignment'] is None
 assert r['reply_plan']['preferred_mother_slot'] in (None,1,2,7,13,16,19,25,28,31,34)
 if r['role']=='unknown':assert r['interest']=='uncertain'
 for t in r['topics']:assert t['pool'] in ('价格预算','位置通勤','户型面积与居住方式','房内设施','宠物','楼层电梯','入住与租期','房源状态','费用合同','看房联系')
out=B/'reviewed-new-0.jsonl';out.write_bytes(b''.join((P/f'reviewed-{n:02}.jsonl').read_bytes() for n in range(9)))
assert read(out)==rows
stage=[dict(copy.deepcopy(r),classification_method='ai_semantic_initial_and_detailed',classification_stages_completed=['initial_semantic','detailed_semantic']) for r in rows]
stagepath=P/'isolated-semantic-stages.jsonl';stagepath.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in stage),'utf-8')
digest=hashlib.sha256(stagepath.read_bytes()).hexdigest();cache={};validated=[]
for r in stage:
 r=copy.deepcopy(r);r['classification_review_source']={'path':str(stagepath),'sha256':digest}
 mother_adapter.validate_new_review(r,B,cache);validated.append(r)
(P/'isolated-adapter-preflight.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in validated),'utf-8')
result={'batch':'83816f9ea5dda5b0','shard':0,'input_count':1460,'output_count':len(rows),'unique_review_keys':len({r['review_key'] for r in rows}),'unique_comment_ids':len({r['comment_id'] for r in rows}),'review_key_set_equal':True,'comment_id_set_equal':True,'metadata_tuple_equal':True,'evidence_quotes_checked':quotes,'evidence_exact_match':True,'page_counts':[len(p) for p in pages],'page_concat_bytes_equal':True,'explicit_decision_count':len(explicit),'formal_adapter_preflight_passed':len(validated),'adapter':str(pathlib.Path(mother_adapter.__file__).resolve()),'adapter_sha256':hashlib.sha256(pathlib.Path(mother_adapter.__file__).read_bytes()).hexdigest(),'isolated_source':str(stagepath),'isolated_sha256':digest,'semantic_review_sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'roles':dict(collections.Counter(r['role'] for r in rows)),'interests':dict(collections.Counter(r['interest'] for r in rows)),'classification':'single model explicit initial and detailed semantic decisions, not independent review or human gold labels','formal_compiler_binding_pending':True,'usage':'unknown','credits_authorized_by_parent':True,'platform_calls':0,'text_task_send_attempted':False,'human_confirmed':False,'send_authorized':False,'verified_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'passed':True}
(B/'shard-0-validation.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),'utf-8')
(P/'progress.json').write_text(json.dumps({'completed_pages':list(range(9)),'reviewed_count':1460,'formal_adapter_preflight_passed':1460,'status':'completed_wait_independent_review','usage':'unknown','verified_at':result['verified_at']},ensure_ascii=False,indent=2),'utf-8')
(B/'shard-0-report.md').write_text(f'''# 抖音分片文本判读核验

本片1460条、9页已逐key完成模型初筛和细筛；每页有明确模型决定及结构化JSONL。逐页计数为八页180条和末页20条。完整共享正文与每条评论均已阅读；程序只回填身份、固定结构与核对，不按关键词代判。

输入输出键、评论、账号、视频及平台逐条一致，正式结果与9页字节连接相等。逐字证据共核对{quotes}处。实际调用未改动的mother_adapter.validate_new_review，以真实隔离语义JSONL、阶段和SHA绑定逐条预检，1460条通过。隔离编译字段未写入正式评审；正式compiler绑定及独立二审仍待执行。

重点保留：居住展示问价为中等关注；明确月租、长租和本人求租建立当时租赁动作。裸多少/多少米仅候选，不冒充确定价格面积；多少米一个月明确是价格。已租好无新需求保留demand/ended/unrelated。转租后本人是否新找房不明保留mixed待核。个人现房困扰与假房受骗后未明状态不直接过滤。工作地、现居、查询地与目标分开，未从IP或采集店补目标；家庭入住和别人条件不搬给本人。

车位、租房补贴、居住证、交通工具及合租对象约束保留。保障房申请与商业租赁意愿分开，登记/申请不冒充预约或入住。D4153只找房东避中介属身份限制，不扩大成拒绝全部联系。相对时间保留发表时点，未按分析当天归一；月报价非租赁总时长。

仅选认可母句槽位的reply_plan，不新写回复正文。住户身份、优惠资格、适配地区、同一房源全部条件与具体房态价格仍须核实。allow不是发送许可，所有human_confirmed=false、send_authorized=false、store_assignment=null。

意向计数：{json.dumps(result['interests'],ensure_ascii=False)}。

正式评审SHA256：{result['semantic_review_sha256']}。
隔离语义源SHA256：{digest}。
适配器SHA256：{result['adapter_sha256']}。

模型usage未知，现有credits已授权与实际花费未知分别保留。本文字任务未触发平台请求、源库修改、登录或发送，不代表平台全部历史发送状态。初细筛不是独立复核、人工金标、用户重新认可或准确率。
''','utf-8')
print(json.dumps(result,ensure_ascii=False,indent=2))
