"""Independently reload protected sources and rendered products; no source writes."""
import collections, hashlib, json, pathlib, string
O=pathlib.Path(__file__).resolve().parent
W=O.parents[1]
def h(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def objh(x):return hashlib.sha256(json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode('utf-8')).hexdigest()
def j(p):return json.loads(pathlib.Path(p).read_text(encoding='utf-8'))
def jl(p):return [json.loads(l) for l in pathlib.Path(p).read_text(encoding='utf-8').splitlines() if l.strip()]
m=j(O/'source-manifest.json');checks=collections.Counter()
for p,sha in m['inputs'].items():assert h(p)==sha,p
checks['protected_files_unchanged']=len(m['inputs'])
old_manifest=j(W/'pool-mother-review/legacy-local-planning/plan-source-manifest.json')
for p,sha in old_manifest['sources'].items():assert h(p)==sha,p
checks['historical_manifest_files_unchanged']=len(old_manifest['sources'])
old=[r for r in jl(m['source_selection']['path']) if r['next_action_category']==m['source_selection']['value']]
snapshot=jl(O/'source-bound-input.jsonl');plans=jl(O/'source-bound-plans.jsonl');previews=jl(O/'rendered-preview.jsonl')
assert len(old)==len(snapshot)==len(plans)==len(previews)==223
sources={}
for platform in ('douyin','xiaohongshu'):
    path=W/f'region-brand-routing/adf75ead836bc43c-pool-short-f98cc21138910fb9/{platform}-region-brand-results.jsonl'
    file_sha=h(path)
    for r in jl(path):sources[r['platform'],r['comment_id'],r['customer_uid']]=(r,file_sha)
base=j(W/'douyin-registered-v2/increments/f98cc21138910fb9/local-mother-contract.json')
addon=j(O/'contract-addon.json');assert all(k.startswith('combo_') for k in addon['families'])
assert not set(base['families'])&set(addon['families'])
families={**base['families'],**addon['families']}
for i,(original,snap,p,v) in enumerate(zip(old,snapshot,plans,previews)):
    actual,file_sha=sources[p['platform'],p['cid'],p['uid']]
    text=actual['comment_text']
    assert p['index']==i and p['source_original_preserved']==original==snap['original_plan']
    assert actual==snap['source_record']
    assert objh(actual['source_record'])==p['original_classification_sha256']==original['original_classification_sha256']
    assert file_sha==p['source_file_sha256']
    assert hashlib.sha256(text.encode('utf-8')).hexdigest()==p['sourceSHA']
    assert p['source_field_evidence']==original['source_field_evidence']
    assert p['original_contact_policy']==original['contact_policy_original']
    assert p['contact_policy']==(original['contact_policy_original'] or 'unknown')
    assert p['send_authorized'] is False and p['can_send_now'] is False
    assert v['send_authorized'] is False and v['can_send_now'] is False
    assert p['classification_changed'] is False and p['human_confirmed'] is False
    checks['original_identity_text_SHA_and_classification_match']+=1
    checks['original_plan_fields_preserved']+=1
    checks['contact_policy_preserved']+=1
    if p['family']:
        d=families[p['family']]
        fields={f for _,f,_,_ in string.Formatter().parse(d['template']) if f}
        assert set(p['fill'])==set(d['required_fill'])==fields
        for field,value in p['fill'].items():
            e=next(e for e in p['evidence'] if e['field']==field)
            assert e['quote']==value and text[e['start']:e['end']]==value
            assert e['own_comment_sha256']==p['sourceSHA']
            assert all(value in ev['quote'] for ev in e['existing_evidence'])
            checks['literal_contiguous_fill_spans']+=1
        if 'work' in p['fill']:
            assert any(r['relation']=='work' and p['fill']['work'] in r['quote'] for r in original['source_field_evidence']['target_regions'])
            assert not any(r['relation']=='desired' for r in original['source_field_evidence']['target_regions'])
            checks['workplace_not_converted_to_home']+=1
        if 'place' in p['fill']:
            assert any(r['relation']=='desired' and p['fill']['place'] in r['quote'] for r in original['source_field_evidence']['target_regions'])
        expected=d['template'].format(**p['fill'])
        if original['source_field_evidence']['reply_plan'].get('tone')=='serious' and expected.startswith('宝宝，'):expected=expected[3:]
        assert v['text']==expected and v['length']==len(expected)
        checks['template_only_renders']+=1
    else:
        assert p['unbound_reason'] and v['text'] is None
        checks['specific_unbound_gap']+=1
# Representative semantic guards: no missing_facts contamination and no lost joined questions.
assert plans[137]['fill']=={'budget':'3500'}
assert '家庭' not in previews[137]['text'] and '水电' not in previews[137]['text']
assert '月租' in previews[71]['text'] and '是否包水电' in previews[71]['text']
assert '看房' in previews[201]['text'] and '是否民用水电' in previews[201]['text']
assert '位置' in previews[127]['text'] and '点我聊' in previews[127]['text']
assert plans[218]['fill']=={'room_a':'2房','room_b':'3房'}
assert '看房' in previews[12]['text'] and '点我聊' in previews[12]['text']
assert '看房' in previews[70]['text'] and '点我聊' in previews[70]['text']
assert '租金' in previews[42]['text'] and '看房' in previews[42]['text']
checks['representative_semantic_guards']=8
result={'status':'PASS','checks':dict(checks),'independent_source_reload':True,
 'input_count':223,'bound_count':checks['template_only_renders'],'unbound_count':checks['specific_unbound_gap'],
 'platform_calls':0,'send_attempts':0,'source_writes':0,
 'limitations':'Technical source/slot/template checks plus representative semantic review; not human approval, intent accuracy or platform acceptance.'}
(O/'independent-validation.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result,ensure_ascii=False,indent=2))
