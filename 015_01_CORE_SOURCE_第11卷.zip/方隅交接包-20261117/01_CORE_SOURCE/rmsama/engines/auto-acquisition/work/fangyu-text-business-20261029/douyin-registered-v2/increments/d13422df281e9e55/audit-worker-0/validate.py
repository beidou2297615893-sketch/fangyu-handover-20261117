import json,hashlib,copy,importlib.util,collections
from pathlib import Path
worker=Path(__file__).resolve().parent;base=worker.parent;part=base/'recall-audit/part-0';task=json.loads((part/'task.json').read_text(encoding='utf8'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return [json.loads(s) for s in p.read_text(encoding='utf8').splitlines() if s.strip()]
primary={};sources=[]
for src in task['primary_sources']:
 p=base/src['path'];actual=sha(p);assert actual==src['sha256'],p
 sources.append(dict(path=src['path'],expected=src['sha256'],actual=actual,passed=True))
 for row in read(p):assert row['review_key'] not in primary;primary[row['review_key']]=row
allowed=set('role demand_state interest topics target_regions time_mentions other_constraints possible_topics evidence reason context_used needs_review contact_boundaries context_flags reply_plan'.split())
rows=[];audits=[];page_checks=[];evidence_issues=[];read_proofs=[]
for p in sorted(part.glob('page-*.json')):
 d=json.loads(p.read_text(encoding='utf8'));comments=[(c,g) for g in d['post_groups'] for c in g['comments']];keys=[c['key'] for c,g in comments]
 a=read(p.with_suffix('.audit.jsonl'));ak=[r['review_key'] for r in a]
 assert len(ak)==len(set(ak)) and ak==keys,(p,len(ak),len(keys))
 page_checks.append(dict(page=p.name,input_count=len(keys),output_count=len(a),id_order_and_set_equal=True,input_sha256=sha(p),audit_sha256=sha(p.with_suffix('.audit.jsonl'))))
 lookup={r['review_key']:r for r in a}
 for c,g in comments:
  k=c['key'];r=copy.deepcopy(primary[k]);a=lookup[k];assert set(a)=={'review_key','decision','reason','patch'};assert a['decision'] in ('keep','change')
  assert a['reason'].strip() and isinstance(a['patch'],dict) and set(a['patch'])<=allowed
  assert (a['decision']=='keep')==(a['patch']=={}),k
  assert all(r.get(f)==v for f,v in c['first_semantic_judgment'].items()),'frozen first judgment mismatch '+k
  assert r['video_id']==g['video'],k
  r.update(a['patch'])
  texts=[c['text']]+([g['post_body']] if c['same_author'] else [])
  def exact(q):return isinstance(q,str) and any(q in t for t in texts)
  for e in r['evidence']:
   if not exact(e):evidence_issues.append([k,'evidence',e])
  for field in ('topics','target_regions','time_mentions','other_constraints','possible_topics','contact_boundaries'):
   for x in r[field]:
    if isinstance(x,dict) and 'quote' in x and not exact(x['quote']):evidence_issues.append([k,field,x['quote']])
  assert r['human_confirmed'] is False and r['send_authorized'] is False and r['store_assignment'] is None
  r['classification_method']='ai_independent_semantic_fine_review';r['classification_stages_completed']=['initial_semantic','detailed_semantic','independent_semantic']
  r.pop('classification_review_source',None);rows.append(r);audits.append(a)
assert len(rows)==task['records']==788 and len({r['review_key'] for r in rows})==788
assert {r['review_key'] for r in rows}==set(task['expected_review_keys'])
print('evidence_issues',json.dumps(evidence_issues,ensure_ascii=False))
assert not evidence_issues,'fix exact evidence before validation'
isolated=worker/'isolated-reviewed-part-0.jsonl';isolated.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows),encoding='utf8');digest=sha(isolated)
adapter=base.parents[2]/'mother_adapter.py'
if not adapter.exists():raise RuntimeError(str(adapter))
adapter_before=sha(adapter);spec=importlib.util.spec_from_file_location('original_mother_adapter',adapter);mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
cache={};validated=[]
for r in rows:
 t=copy.deepcopy(r);t['classification_review_source']={'path':isolated.relative_to(base).as_posix(),'sha256':digest};mod.validate_new_review(t,base,cache);validated.append(t)
assert sha(adapter)==adapter_before
bound=worker/'isolated-bound-preflight-part-0.jsonl';bound.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in validated),encoding='utf8')
result={'part':0,'input_count':788,'output_count':len(rows),'independent_explicit_decisions':len(audits),'keep_count':sum(a['decision']=='keep' for a in audits),'change_count':sum(a['decision']=='change' for a in audits),'page_checks':page_checks,'id_set_equal':True,'duplicate_keys':0,'evidence_quote_issues':evidence_issues,'first_judgments_match_primary':True,'primary_sources':sources,'isolated_jsonl':isolated.name,'isolated_sha256':digest,'bound_jsonl':bound.name,'bound_sha256':sha(bound),'official_validator':'mother_adapter.validate_new_review','official_validation_count':len(validated),'official_validation_passed':True,'adapter_sha256_before':adapter_before,'adapter_sha256_after':sha(adapter),'adapter_unmodified':True,'primary_sources_unchanged_after':all(sha(base/s['path'])==s['sha256'] for s in task['primary_sources']),'credits':'existing_authorized','actual_usage':'unknown','not_publication_or_send_authorization':True}
(worker/'validation.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf8');print(json.dumps({k:v for k,v in result.items() if k not in ('page_checks','primary_sources')},ensure_ascii=False,indent=2))
