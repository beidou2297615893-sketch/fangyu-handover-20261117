"""Audit the full old source library by FIRST collection date, not draft coverage."""
from collections import Counter
from datetime import datetime, timezone, timedelta
import hashlib
import importlib.util
import json
from pathlib import Path
import sqlite3
import subprocess
import sys

HERE=Path(__file__).resolve().parent
WORK=HERE.parent
ROOT=WORK.parents[1]
def read(path):return json.loads(Path(path).read_text(encoding='utf-8-sig'))
def sha(data):return hashlib.sha256(data).hexdigest()
def dump(path,value):Path(path).write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf-8')
def lines(path):return [json.loads(line) for line in Path(path).read_text(encoding='utf-8-sig').splitlines() if line.strip()]
spec=importlib.util.spec_from_file_location('frozen_funnel',WORK/'funnel-audit/run_audit.py')
funnel=importlib.util.module_from_spec(spec);spec.loader.exec_module(funnel)
cutoff=datetime(2026,11,6,tzinfo=timezone(timedelta(hours=8)))
status_path=ROOT/'work/fangyu-douyin-independent/classification-handoff-status.json'
live=read(status_path)
if not live.get('local_backlog_recheck'):raise RuntimeError('本地复核尚未发布；不拿旧结果冒充完成')
cohort_summary=read(WORK/'local-backlog-recheck-20261105/summary.json')
if live['commercial_fit']['version']!=cohort_summary['rule_version'] or live['local_backlog_recheck']['version']!=cohort_summary['local_recheck_version']:
    raise RuntimeError('最新规则仍在发布中，等待当前构建完成后再冻结')
folder=funnel.capture()
audit=funnel.analyse(folder)
status=read(folder/'status.json')
archive_data=Path(status['active_pool']['archive_file']).read_bytes()
quarantine_data=Path(status['active_pool']['quarantine_file']).read_bytes()
(folder/'archive.jsonl').write_bytes(archive_data)
(folder/'quarantine.jsonl').write_bytes(quarantine_data)
active=lines(folder/'all-pool.jsonl');archive=lines(folder/'archive.jsonl');quarantine=lines(folder/'quarantine.jsonl')
assert len(archive)==status['active_pool']['archived_outside_window']
assert len(quarantine)==status['active_pool']['quarantined_dates']
if read(status_path)['output_sha256']!=status['output_sha256']:raise RuntimeError('发布源已变，重新冻结再审计')
qualified={row['comment_id'] for row in active+archive+quarantine}
assert len(qualified)==len(active)+len(archive)+len(quarantine)==status['eligible_registered']

source=ROOT/'work/fangyu-douyin-independent/runtime/collection.sqlite3'
sql="SELECT stable_key,MIN(collected_at) AS first_collected_at FROM observations WHERE kind='comments' GROUP BY stable_key"
with sqlite3.connect(source.resolve().as_uri()+'?mode=ro',uri=True) as db:
    first={str(key).removeprefix('comment:'):date for key,date in db.execute(sql)}
old=set();new=set();unknown=set()
for cid,date in first.items():
    try:stamp=datetime.fromisoformat(date.replace('Z','+00:00'))
    except (TypeError,ValueError):unknown.add(cid);continue
    if stamp.tzinfo is None:unknown.add(cid);continue
    (old if stamp<cutoff else new).add(cid)
old_qualified=old & qualified
old_active=[row for row in active if row['comment_id'] in old]
old_archived=[row for row in archive if row['comment_id'] in old]
old_quarantine=[row for row in quarantine if row['comment_id'] in old]
details=lines(folder/'triage-details.jsonl')
old_details=[row for row in details if row['comment_id'] in old]
old_groups=Counter(row['funnel_group'] for row in old_details)
assert sum(old_groups.values())==len(old_active)
assert len(old_qualified)==len(old_active)+len(old_archived)+len(old_quarantine)

with sqlite3.connect((WORK/'douyin-semantic-repair-v5/qualification-snapshot.sqlite3').resolve().as_uri()+'?mode=ro',uri=True) as db:
    cached_qualified={str(key).removeprefix('comment:') for key, in db.execute("""SELECT DISTINCT o.stable_key FROM observations o JOIN qualified q
       ON o.platform=q.platform AND o.request_id=q.request_id AND o.target=q.target
       AND (q.account_uid='' OR o.account_uid=q.account_uid) WHERE o.platform='douyin'""")}
missing_qualified_old=sorted((old & cached_qualified)-qualified)
if missing_qualified_old:raise RuntimeError(f'旧合格来源仍缺分类覆盖：{len(missing_qualified_old)}条')
before=read(WORK/'local-backlog-recheck-20261105/manifest.json')
before_folder=Path(before['source_snapshot'])
before_pending={row['comment_id'] for row in lines(before_folder/'pending.jsonl')}
after_pending={row['comment_id'] for row in lines(folder/'pending.jsonl')}
cohort={row['comment_id'] for row in lines(WORK/'local-backlog-recheck-20261105/input.jsonl')}
cohort_pending=after_pending & cohort
cohort_expired=cohort & {row['comment_id'] for row in archive}
record={'recorded_at':datetime.now(timezone.utc).isoformat(),'classification_as_of':audit['classification_as_of'],
        'old_library_definition':'首次采集早于2026-11-06 00:00:00+08:00，原评论30天时效另算',
        'old_cutoff':cutoff.isoformat(),'old_raw_unique':len(old),'old_qualified':len(old_qualified),
        'old_source_not_qualified':len(old-qualified),'new_by_first_collection':len(new),
        'unknown_first_collection_date':len(unknown),'old_archived':len(old_archived),
        'old_comment_date_quarantine':len(old_quarantine),'old_active':len(old_active),
        'old_active_intent_counts':dict(Counter(r['commercial_fit']['lead_intent'] for r in old_active)),
        'old_active_processing_groups':dict(old_groups),'old_current_pending':len(old & after_pending),
        'old_pending_intents':dict(Counter(r['commercial_fit']['lead_intent'] for r in lines(folder/'pending.jsonl') if r['comment_id'] in old)),
        'old_business_ready_missing_draft':old_groups['回复待补'],
        'qualified_old_missing_any_derived_record':missing_qualified_old,
        'backlog_cohort_count':len(cohort),'backlog_cohort_pending_now':len(cohort_pending),
        'backlog_cohort_expired_since_freeze':len(cohort_expired),
        'backlog_cohort_new_pending_ids':sorted(cohort_pending-before_pending),
        'backlog_cohort_new_pending_count':len(cohort_pending-before_pending),
        'live_pending_added_since_before':len((old & after_pending)-before_pending),
        'live_pending_removed_since_before':len((old & before_pending)-after_pending),
        'comparison_warning':'实时差额含时效滚动和持续发送；固定4712条规则重跑对照见cohort_summary，不能把净增当准确率',
        'cohort_summary':read(WORK/'local-backlog-recheck-20261105/summary.json'),
        'rule_version':status['commercial_fit']['version'],'source_sha256':audit['source_sha256'],
        'result_sha256':audit['result_sha256'],'pending_sha256':audit['pending_sha256'],
        'archive_sha256':sha(archive_data),'quarantine_sha256':sha(quarantine_data),
        'snapshot':str(folder),'source_query':sql,'platform_requests':0,'model_calls':0,
        'source_or_receipts_modified':False,'active_sending_batch_modified':False}
dump(HERE/'audit.json',record)
dump(HERE/'current.json',{'audit':str(HERE/'audit.json'),'audit_sha256':sha((HERE/'audit.json').read_bytes()),'snapshot':str(folder)})

out=ROOT/'outputs/方隅双平台文本业务/旧库完整核对'
out.mkdir(parents=True,exist_ok=True)
labels={'super_high':'超高意向','high':'高意向','medium':'中意向','low':'低意向','uncertain':'尚不能证实当前租需或条件待确认','non_customer':'非本人求租、互动或讨论','ended':'需求已结束'}
text=['# 抖音旧评论完整核对','',record['old_library_definition']+'。以下按同一冻结快照核对；采集、发送继续独立运行。','',
      '| 去向 | 数量 |','|---|---:|',f'| 旧库原始去重评论 | {len(old):,} |',
      f'| 来源未通过登记规则 | {len(old-qualified):,} |',f'| 合格旧评论 | {len(old_qualified):,} |',
      f'| 原评论超过30天，历史归档 | {len(old_archived):,} |',f'| 原评论日期隔离 | {len(old_quarantine):,} |',
      f'| 30天内有效旧评论 | {len(old_active):,} |','','30天内按互斥处理状态分组：','', '| 状态 | 数量 |','|---|---:|']
text += [f'| {key} | {value:,} |' for key,value in old_groups.items()]
text += ['', '意向分级与处理状态是两种统计，不能混加：','', '| 分级 | 全部30天有效旧评论 | 当前待回复 |','|---|---:|---:|']
for key,label in labels.items():text.append(f'| {label} | {record["old_active_intent_counts"].get(key,0):,} | {record["old_pending_intents"].get(key,0):,} |')
co=record['cohort_summary']
text += ['',f'固定待核{co["input_count"]:,}条已全部本地复核。规则恢复中意向{co["lead_intent_counts"].get("medium",0):,}、高意向{co["lead_intent_counts"].get("high",0):,}、超高意向{co["lead_intent_counts"].get("super_high",0):,}；其中{co["mother_reply_nonempty"]:,}条已配母句，数量在发送账本去重之前。',
         f'该批现在仍在有效窗口且通过账本检查、进入待回复的有{record["backlog_cohort_pending_now"]:,}条；与原冻结候选相比新增{record["backlog_cohort_new_pending_count"]:,}条。',
         f'旧库合格来源缺失派生记录：{len(missing_qualified_old)}条。有效旧评论业务可保留但仍缺回复：{old_groups["回复待补"]}条。后者保留具体清单，未冒充已完成。',
         '', '预算未知不当作低预算；明确低预算或明显低价来源单独排除；金额范围、用途冲突、联系限制和当前性疑点保留。纯点赞、@朋友与历史租房讨论不当作明确本人求租。空正文经源库核对存在图片评论，不能从图片猜预算或意愿。',
         '', '已恢复退出的本地分类进程，接入缓存和新评论同一规则。不逐条调用模型，不覆盖原采集数据、发送回执和正在发送的批次。',
         '', '逐层筛选条件及扣除数量：','', '| 条件 | 本层移出 | 剩余 |','|---|---:|---:|']
text += [f'| {stage["layer"]} | {stage["removed"]:,} | {stage["remaining"]:,} |' for stage in audit['layers']]
(out/'旧评论核对.md').write_text('\n'.join(text)+'\n',encoding='utf-8')
record['report']=str(out/'旧评论核对.md');dump(HERE/'audit.json',record)
dump(HERE/'current.json',{'audit':str(HERE/'audit.json'),'audit_sha256':sha((HERE/'audit.json').read_bytes()),'snapshot':str(folder),'report':record['report']})
print(json.dumps({key:value for key,value in record.items() if key not in ('backlog_cohort_new_pending_ids','cohort_summary')},ensure_ascii=False))
