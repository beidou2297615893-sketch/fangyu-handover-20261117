"""Apply this one explicit 21-ID semantic batch; reply bodies remain local templates."""
import hashlib
import json
from pathlib import Path
import sqlite3
from datetime import datetime, timezone
import local_delta_worker as worker

P='位置通勤'; R='户型面积与居住方式'; A='房源状态'; B='价格预算'; F='房内设施'
# cid, role, interest, pools, explicit target, family, literal slots, evidence-based reason
LABELS=[
('7646467649992672057','demand','high',[P,R,A],'福州大学至诚学院附近','area_room',{'place':'福州大学至诚学院附近','room':'一室一厅'},'直接询问指定学校附近一室一厅，按评论当时的找房询盘保留'),
('7646597791220810536','demand','high',[P,A],'江夏','area',{'place':'江夏'},'直接问该区域有无房；江夏具体城市不明，不按福建IP直接解释'),
('7646814813088023333','demand','high',[P,R,F,A],'闽侯上街世茂璀璨江山','area_room',{'place':'闽侯上街世茂璀璨江山','room':'三房一厅一卫一厨'},'指定区域并明确居室厨卫组合；不虚构库存'),
('7647082488766513957','demand','high',[P,A],'闽侯上街','area',{'place':'闽侯上街'},'询问指定区域有无类似房源；不继承视频中未说明的配置'),
('7647110748782478129','discussion','unrelated',[],None,None,{},'遗憾式感叹，未表达本人现在找房；也不能断言已经租到'),
('7647201767125500722','demand','high',[P,R,B,A],'金屿或者厚庭地铁站附近','requirements',{'requirements':'金屿或者厚庭地铁站附近、两室一厅、2000以内'},'本人明确两个可选地铁站、两室一厅和2000以内；预算不扩大为全部费用'),
('7647206785149715227','demand','high',[P,A],'闽侯旗山花园附近','area',{'place':'闽侯旗山花园附近'},'主动询问具体区域房源'),
('7647208066333983546','demand','high',[P,R,A],'金山地铁','area_room',{'place':'金山地铁','room':'两室'},'主动询问地铁区域两室；不擅补具体车站或户型厅数'),
('7647330459735196443','unknown','uncertain',[F],None,None,{},'装修时长问题同时含串串房质疑，不能确认是本人租房需求；视频正文没有装修日期'),
('7647392269247955746','demand','high',[A],None,'available',{},'在租房作品下主动询问还有无类似房间；未给出个人明确地点或预算'),
('7648158364924724019','demand','high',[P,A],'鼓楼','area',{'place':'鼓楼'},'租房作品下问指定区域房源；鼓楼城市需另核，IP不硬定市'),
('7648615531415880507','discussion','unrelated',[],None,None,{},'讲述来源房屋和租赁渠道，不是本人求租；国企和无中介费仅是评论者说法'),
('7650152826656539441','demand','high',[P,A],'阵坂附近','area',{'place':'阵坂附近'},'主动问指定地名附近房源；保留阵坂原词，不擅自改地名'),
('7650880582486410036','demand','high',[P,F,A],'晋安区鼓山镇福兴东路253号','requirements',{'requirements':'晋安区鼓山镇福兴东路253号、阳台厨房浴室'},'本人明确地点和阳台厨房浴室；原文福近不改变地址本身'),
('7664100914580833024','demand','medium',[P],None,'location',{},'租房作品下询问所示房源位置，保留中等询盘；不把所问房源位置当本人目标地'),
('7667617500486468411','demand','high',[P,A],'福建医科大学附近','area',{'place':'福建医科大学附近'},'明确问学校附近房源，优先于北京IP；具体校区不明'),
('7670841129218474802','demand','high',[P,B,R],'福州晋安区附近','requirements',{'requirements':'福州晋安区附近、2000左右、单身公寓'},'直接列出地点、预算和单身公寓需求；未给出入住日期'),
('7674590637312623386','demand','medium',[P,A],'鼓楼','area',{'place':'鼓楼'},'有区域询盘也可能含感叹，保留中等兴趣，不因疑问句一律判高'),
('7679400792893948709','demand','high',[P,A],'晋安区','area',{'place':'晋安区'},'在租房作品下直接询问指定区域房源'),
('7688771711797887802','demand','high',[P,R,A],'仓山','area_room',{'place':'仓山','room':'两房'},'主动询问仓山两房；不额外补厅数和租金'),
('7700347664265052985','unknown','uncertain',[A],None,None,{},'真有吗可能是房源核实也可能只是质疑；现有上下文不足确认本人求租')]


def main():
    path=worker.HERE/'state/derived.sqlite3'
    db=sqlite3.connect(path,timeout=30)
    mothers=worker.transport.load_json(worker.WORK/'pool-mother-review/pool-mother-short-variants.json')['templates']
    label_sha=worker.transport.digest(LABELS)
    folder=worker.HERE/'semantic-review-20261101-21'
    folder.mkdir(exist_ok=True)
    if worker.transport.meta_get(db,'applied_review:'+label_sha):
        print('already_applied');db.close();return
    originals=[];reviewed=[];decisions=[]
    for cid,role,interest,pools,target,family,slots,reason in LABELS:
        found=db.execute('SELECT data FROM delta WHERE cid=?',(cid,)).fetchone()
        if not found: raise ValueError('Missing new comment '+cid)
        raw=json.loads(found[0]);assert raw['classification_stage']=='uncertain_retained'
        # Each supplied slot consists solely of literal comment fragments, separated locally.
        for value in slots.values():
            assert all(part in raw['comment_text'] for part in value.split('、')),(cid,value)
        row=dict(raw)
        row.update(role=role,interest_at_comment=interest,topics=pools,target_region_reference=target,
                   classification_stage='ai_reviewed_unresolved' if role=='unknown' else 'ai_semantic_review_completed',
                   classification_method='small_batch_semantic_review',reason=reason,evidence=[raw['comment_text']],
                   ai_semantic_review_completed=True,independent_fine_review_completed=False,
                   ai_initial_screen_completed=False,ai_fine_screen_completed=False,
                   needs_model_review=False,needs_context=role=='unknown',
                   demand_state='active_at_comment' if role=='demand' else 'unknown',
                   actual_task_token_usage=None,usage_status='unknown_not_an_API_request_count',
                   semantic_review_at=worker.now(),review_batch=str(folder),
                   mother_reply_text=None,draft_ready=False,send_authorized=False,can_send_now=False,
                   current_need_verified=False,assigned_store=None)
        ts=raw.get('published_at_unix')
        if ts:
            row['comment_age_days_at_review']=round((datetime.now(timezone.utc).timestamp()-ts)/86400,2)
        row['time_status']='按评论当时判断意向；原评论较旧，当前是否仍求租未知，不冒充已结束或当前有效'
        if family:
            reply=mothers[family].format(**slots)
            assert not any(c in reply for c in '{}【】')
            row.update(mother_family=family,mother_literal_slots=slots,mother_reply_text=reply,draft_ready=True,
                       reply_status='按池选择现有短母句并本地填原文；草稿未发送',
                       mother_approval_scope='短句方向已获认可；变体非逐句认可',
                       fact_gaps=['住户账号与介绍优惠适用事实仍须核实','具体房源库存、报价和客户当前需求未核'])
        decisions.append({'comment_id':cid,'source_comment_sha256':raw['source_comment_sha256'],
                          'label':{'role':role,'interest_at_comment':interest,'topics':pools,'target':target,
                                   'family':family,'literal_slots':slots,'reason':reason}})
        originals.append(raw);reviewed.append(row)
    for name,rows in [('before.jsonl',originals),('semantic-labels.jsonl',decisions),('results.jsonl',reviewed)]:
        data=''.join(worker.transport.dumps(r)+'\n' for r in rows)
        (folder/name).write_text(data,encoding='utf8')
    db.execute('BEGIN IMMEDIATE')
    for row in reviewed:
        db.execute('UPDATE delta SET stage=?,data=? WHERE cid=?',
                   (row['classification_stage'],worker.transport.dumps(row),row['comment_id']))
    worker.transport.meta_set(db,'applied_review:'+label_sha,worker.now());db.commit();db.close()
    receipt={'reviewed_new_comments':len(reviewed),'semantic_completed':sum(r['role']!='unknown' for r in reviewed),
             'context_still_unknown':sum(r['role']=='unknown' for r in reviewed),
             'high_at_comment':sum(r['interest_at_comment']=='high' for r in reviewed),
             'medium_at_comment':sum(r['interest_at_comment']=='medium' for r in reviewed),
             'local_pool_drafts':sum(r['draft_ready'] for r in reviewed),
             'label_sha256':label_sha,'result_sha256':hashlib.sha256((folder/'results.jsonl').read_bytes()).hexdigest(),
             'review_type':'one small semantic batch, no independent second review or human gold',
             'actual_task_token_usage':None,'reply_generation_model_calls':0,'platform_calls':0,'sends':0,
             'source_database_modified':False,'historical_canonical_result_modified':False}
    worker.transport.atomic_json(folder/'receipt.json',receipt)
    print(json.dumps(receipt,ensure_ascii=True))


if __name__=='__main__':main()
