"""Read-only legacy binding, source AI labels remain authoritative. No network/model client."""
import json,pathlib,re,hashlib,copy,collections,sys,datetime,importlib.util
W=pathlib.Path('work/fangyu-text-business-20261029');O=W/'pool-mother-review/legacy-literal-binding';P=W/'pool-mother-review/legacy-local-planning';B=W/'douyin-registered-v2/increments/f98cc21138910fb9'
def load(p):return json.loads(pathlib.Path(p).read_text(encoding='utf8'))
def jl(p):return [json.loads(l) for l in pathlib.Path(p).read_text(encoding='utf8').splitlines() if l.strip()]
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def objsha(x):return hashlib.sha256(json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def put(p,x):pathlib.Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
def putjl(p,rs):pathlib.Path(p).write_text(''.join(json.dumps(x,ensure_ascii=False,separators=(',',':'))+'\n' for x in rs),encoding='utf8')
source=P/'local-proposed-plans.jsonl';manifest=load(P/'plan-source-manifest.json');protected={**manifest['sources'],str(source.resolve()):sha(source),str((P/'plan-source-manifest.json').resolve()):sha(P/'plan-source-manifest.json')}
for p,h in protected.items():assert sha(p)==h,('source_pre_changed',p)
c=load(W/'region-brand-routing/current.json');rows={}
for platform,f in c['results'].items():
 for r in jl(f):rows[platform,r['comment_id'],r['customer_uid']]=r
ps=[p for p in jl(source) if p.get('next_action_category')=='literal_extraction_or_existing_pool_binding_gap'];assert len(ps)==4620
contract=load(B/'local-mother-contract.json');base_families=set(contract['families']);addons={}
spec=importlib.util.spec_from_file_location('f98_literal_renderer',B/'batch_short_mothers.py');renderer=importlib.util.module_from_spec(spec);spec.loader.exec_module(renderer)
# Tokenization only removes whole known phrases, longest first. It never decides lead intent.
# Distances, conditions, negatives, numbers, unknown nouns are deliberately not generic fillers.
generic='请问一下 请问 请教一下 请教 想问一下 想问 问一下 问问 你好呀 你好 您好 宝宝 姐妹 博主 主播 小姐姐 姐姐 帅哥 美女 哥 谢谢 麻烦 求推荐 推荐 找房子 找房 求租房 求租 租房子 租房 房子 房间 房源 公寓 这套房 这房子 这套 这间 这个房 这种房 这种 这个 这样的 这样 这 那套 那个 那种 那 有木有 有没有 还有没有 还有 还在 在吗 有吗 没有吗 有没 有无 有房没 房 有么 有没得 有 还 可不可以 可以吗 可以 能不能 能否 能 么 想租 我想租 想了解一下 想了解 了解一下 了解 方便 想 我想 我 就 真的 真 是 的吗 的 呢 嘛 吗 啊 呀 吧 哇 嘞 呗 哦 阿 哈 哩 不 现在 现 目前 也 求 蹲 出租 租出去 出去没 出去 出 需要 需 来个 来 个 一下 一点 一个 你 我去'.split()
question_words={
 '价格预算':'月租 租金 房租 月租 价格 价钱 价位 什么价位 什么价格 什么价 啥价格 啥价 多少钱一个月 多少一个月 多少钱 多钱 多少钱钱 多少米 几米 几钱 几多钱 多少 价格多少 钱 租金多少 房租多少 米一个月 一个多少 一月 一个月 大概 大约',
 '位置通勤':'位置 地址 地点 具体 在什么位置 什么位置 啥位置 在哪里 在哪儿 哪里 哪儿 在哪 这哪里 这哪 那里 哪个小区 什么小区 哪个区 什么区 什小区 哪个 何处 哪 什地方 什么地方 那个地方 那边 这边 在',
 '房源状态':'空房 空 房态 现在 目前',
 '看房联系':'看房 约时间看房 约看房 看一下 看看 看 怎么联系 联系 联系方式 怎么租 怎么组 私信 私聊 加个 加你 想看看 约 什么时候方便看房 什么时候 方便看房',
}
def norm(t):return re.sub(r'[^\u4e00-\u9fffA-Za-z0-9]','',re.sub(r'\[[^\]]*\]','',t))
def leftover(text,spans,tags):
 t=text
 for v in sorted(set(spans),key=len,reverse=True):t=t.replace(v,' ')
 t=re.sub(r'\[[^\]]*\]','',t)
 toks=generic[:]+['这个房子','这种房子','这套房子','那套房子','租','找','了','要','合适','有房没','没得','什么','想要','租到','有希望','希望']
 if '看房联系' in tags:toks+=['私','联系','看','我']
 for tag in tags:toks+=question_words.get(tag,'').split()
 # Do not eat a sentence-internal negative. Final standalone 不 is the dialect question particle.
 t=re.sub(r'不(?=[？?！!。\s]*$)','',t)
 toks=[x for x in toks if x!='不']
 t=re.sub('|'.join(re.escape(v) for v in sorted(set(toks),key=len,reverse=True)),'',t)
 return norm(t)
num=r'[0-9一二两三四五六七八九十百千万千零点.]+(?:[kKwW千万元百])?'
budget_pat=re.compile(r'(?:总预算|预算(?:在)?|价位(?:在)?|接受)?'+num+r'(?:[-—到至~～]'+num+r')?(?:元|块)?(?:以内|以下|左右|上下|出头|之内|封顶|不超过)?(?:预算)?')
room_pat=re.compile(r'(?:[一二两三四五六123456](?:室|房|居)(?:[一二两三四1234]厅)?(?:[一二两三四1234]厨)?(?:[一二两三四1234]卫)?(?:室|户)?|套[一二三四1234]|(?:整租|合租|单间|开间|平房|主卧|次卧|复式)|[一二两三四1234](?:个)?(?:女生|男生|人住|个人住)|独居)')
facility_pat=re.compile(r'(?:不要|不能|不带|带|要|有)?(?:独立卫浴|独立卫生间|独立厨房|燃气热水器|独卫|阳台|厨房|空调|冰箱|洗衣机|做饭)')
fee_pat=re.compile(r'(?:不要押金|民用水电|民水民电|商用水电|商水商电|包水电|含水电|(?:押[一二三123]付[一二三123])|水电气|水电|押金|物业费|管理费|中介费|服务费)')
pet_pat=re.compile(r'(?:可以养|能养|养|能带|带个|带)?(?:小猫|猫咪|猫猫|猫|小狗|狗狗|狗|宠物|边牧)(?:可以|能带|友好)?')
floor_pat=re.compile(r'(?:不要|不能|有|带|要)?(?:电梯|楼梯|低楼层|高楼层|[一二三四五六七八九十0-9]+楼)')
lease_pat=re.compile(r'短租|长租|月租')
patterns={'户型面积与居住方式':('room',room_pat),'房内设施':('facility',facility_pat),'费用合同':('fee',fee_pat),'宠物':('pet',pet_pat),'楼层电梯':('floor',floor_pat),'入住与租期':('lease',lease_pat)}
# These are binding safety flags, not reclassification or a keyword lead filter.
risk_patterns=[(r'我看过|我现在|现在住|目前住|我住在|已经租|已租到','reported_existing_home_or_comparison_not_budget'),(r'租不去|负担不起|承受不起|比.*贵','negative_comparison_scope_needs_short_binding'),(r'办公|仓库|商铺|工作室|开店|保障房|人才房|安居房','housing_purpose_needs_original_short_scope'),(r'找室友|找合租室友','occupant_and_existing_supply_relation_needs_short_binding'),(r'套路|骗人|诈骗|真假|真的吗','specific_truth_or_fee_scope_needs_short_binding')]
def add_family(name,template,fill):
 definition={'template':template,'required_fill':list(fill)}
 if name in addons:assert addons[name]==definition,(name,addons[name],definition)
 addons[name]=definition;contract['families'][name]=definition
 return name

def bind(p):
 r=rows[p['platform'],p['cid'],p['uid']];a=p['source_field_evidence'];txt=r['comment_text'];ev=p['literal_evidence'];regs=a['target_regions'];tags=set(x['pool'] for x in ev)
 z=copy.deepcopy(p);z.update(family=None,fill={},evidence=[],hold_reasons=[],status='local_plan_held',classification_changed=False,human_confirmed=False,send_authorized=False,can_send_now=False,contact_policy_effective_for_render=p.get('contact_policy_original') or 'unknown',original_plan_sha256=objsha(p),binding_strategy=None)
 z['original_hold_reasons']=p['hold_reasons'];z['original_unbound_literal_residual']=p.get('unbound_literal_residual');z['source_location']={'file':c['results'][p['platform']],'file_sha256':sha(c['results'][p['platform']]) if False else p['source_file_sha256'],'record_key':[p['platform'],p['cid'],p['uid']],'source_record_sha256':objsha(r.get('source_record') or {})}
 holds=z['hold_reasons'];details={};evidence=[];spans=[];covered=set();asks=[]
 def add(field,val,pool,src):
  assert val and val in txt
  if field in details:
   if details[field]==val:return
   field=field+'_'+str(sum(k.startswith(field) for k in details)+1)
  details[field]=val;spans.append(val);evidence.append({'field':field,'quote':val,'source_field':src,'pool':pool});return field
 scope_flags=[]
 source_record=r.get('source_record') or {}
 source_layers=[source_record]+([source_record['classification']] if isinstance(source_record.get('classification'),dict) else [])
 for layer in source_layers:
  for key in ('blocking_reasons','needs_review','review_reasons','semantic_review_reasons'):
   value=layer.get(key)
   if value is not None:
    flag=json.dumps(value,ensure_ascii=False)
    if re.search(r'住宅用途|交易对象|住房用途|租赁对象|(?:工作|居住).*(?:关系|用途).*(?:未知|待核|不明|未明)|主体未明|主体不明|主体.*待核|缺正文|用途.*(?:未知|未明|不明|待核)|语境不明|上下文不足',flag):scope_flags.append({'source_field':key,'value':value})
 z['original_semantic_scope_flags']=scope_flags
 if scope_flags:holds.append('original_AI_semantic_object_or_housing_purpose_unresolved')
 for regex,reason in risk_patterns:
  if re.search(regex,txt):holds.append(reason)
 if not ev:holds.append('missing_structured_pool_evidence')
 for e in ev:
  if e.get('subject')!='own_demand' or e.get('polarity') not in ('ask','require','prefer','accept'):holds.append('existing_subject_or_polarity_not_simple')
  if not e.get('quote') or e['quote'] not in txt:holds.append('existing_quote_not_own_literal')
 if len(regs)>1:holds.append('multiple_region_relation_binding_gap')
 for rr in regs:
  v=rr.get('quote') or ''
  # Full quoted entity preserves 附近/沿线/距离; never use only text if it drops scope.
  if rr.get('relation') not in ('desired','work') or not v or v not in txt:holds.append('region_literal_relation_gap');continue
  if re.search(r'我|咱|本人|朋友|同事|[?？]|^蹲',v):holds.append('region_entity_not_short_literal');continue
  add('place' if rr['relation']=='desired' else 'destination',v,'位置通勤','target_regions');covered.add('位置通勤')
 for pool,(field,pat) in patterns.items():
  es=[e for e in ev if e['pool']==pool]
  vals=[]
  for e in es:
   q=e['quote'];ms=list(pat.finditer(q))
   for m in ms:
    value=m.group()
    # Short typed original quote is preferable when it preserves accepted/preferred/negative scope.
    if len(q)<=18 and (e['polarity'] in ('prefer','accept','reject') or re.search(r'不要|不能|不带|最好|最多|至少|以上|或者',q)):value=q
    if value not in vals:vals.append(value)
  for v in vals:add(field,v,pool,'topic_evidence')
  if vals:covered.add(pool)
 # Price require/accept/prefer is not an ask-listing price. Preserve text prefix/range exactly.
 pe=[e for e in ev if e['pool']=='价格预算'];price_inquiry=False
 if pe:
  numeric=[];numeric_price_ask=[]
  for e in pe:
   price_q=re.sub(r'[一二两三四五六七八九十0-9]+个?月',' ',e['quote'])
   for bound in sorted(details.values(),key=len,reverse=True):price_q=price_q.replace(bound,' ')
   for m in budget_pat.finditer(price_q):
    v=m.group()
    if not re.search(r'[0-9百千万kKwW元块]',v):continue
    if e['polarity'] in ('require','prefer','accept') or re.search(r'预算|价位|接受',v):numeric.append(v)
    else:numeric_price_ask.append(v)
  numeric=list(dict.fromkeys(numeric));numeric_price_ask=list(dict.fromkeys(numeric_price_ask))
  if len(numeric)==1:
   v=numeric[0]
   nums=re.findall(r'\d+(?:\.\d+)?',v)
   if len(nums)==2 and float(nums[0])>float(nums[1]):holds.append('budget_range_order_needs_confirmation')
   add('budget',v,'价格预算','topic_evidence');covered.add('价格预算')
  elif numeric:holds.append('multiple_budget_literals_scope_gap')
  elif numeric_price_ask:
   # Numeric listing questions remain price questions. Do not mint a budget from them.
   if len(numeric_price_ask)==1:
    v=numeric_price_ask[0];add('price_condition' if re.search(r'以内|以下|左右|上下|出头|之内|封顶|不超过',v) else 'asked_price',v,'价格预算','topic_evidence');price_inquiry=not bool(re.search(r'以内|以下|左右|上下|出头|之内|封顶|不超过',v));covered.add('价格预算')
   else:holds.append('multiple_asked_prices_scope_gap')
  else:price_inquiry=True;covered.add('价格预算')
  cheap=re.search(r'便宜(?:一点|点)?|价格合适|穷鬼',txt)
  if cheap:add('cost_preference',cheap.group(),'价格预算','topic_evidence')
 for e in a['time_mentions']:
  if e.get('time_role')=='lease_duration' and e.get('quote') in txt:add('duration',e['quote'],'入住与租期','time_mentions');covered.add('入住与租期')
  else:holds.append('time_anchor_or_role_gap')
 # Pure question pools can be represented by fixed words, never claims of factual answers.
 for pool in tags:
  es=[e for e in ev if e['pool']==pool]
  if pool in ('房源状态','看房联系','位置通勤') and all(e['polarity']=='ask' for e in es):covered.add(pool)
 if '房源状态' in tags:asks.append('空房')
 if price_inquiry:asks.append('月租' if re.search(r'个月|一月|月租|月多少钱',txt) else '租金')
 if '位置通勤' in tags and not regs:asks.append('位置')
 if '看房联系' in tags:
  contact_quotes=' '.join(e['quote'] for e in ev if e['pool']=='看房联系')
  contact_label='房东联系方式' if '房东' in contact_quotes else '约看时间' if re.search(r'约|时间|时候',contact_quotes) and '看' in contact_quotes else '看房安排' if '看' in contact_quotes else '联系方式' if re.search(r'联系|私|加',contact_quotes) else '租房流程'
  asks.append(contact_label)
  if contact_label=='房东联系方式':spans.append('房东')
 # Source price literal must remain tied to a question, not inserted as a requirement.
 if 'asked_price' in details:asks=[x for x in asks if x not in ('租金','月租')]
 if 'destination' in details:
  spans+=re.findall(r'上班|工作',txt)
  for e in ev:
   if e['pool']=='位置通勤':
    mm=re.search(r'近一点|离[^，。？? ]{1,12}近',e['quote'])
    if mm:add('proximity',mm.group(),'位置通勤','topic_evidence')
 if '位置通勤' in tags and not regs:
  for e in ev:
   if e['pool']=='位置通勤':
    mm=re.search(r'离地铁近|离地铁远不远',e['quote'])
    if mm:add('proximity',mm.group(),'位置通勤','topic_evidence')
 # Fixed presence/area/utility questions preserve semantics without inventing literal values.
 for e in ev:
  q=e['quote'];pool=e['pool']
  if pool=='户型面积与居住方式' and e['polarity']=='ask' and re.fullmatch(r'(?:多少|多大|几)(?:平|平方|平米|面积|室|居)(?:[啊呀呢吗么])?[？?]?',q):
   spans.append(q);covered.add(pool);asks.append('面积户型')
  if pool=='费用合同' and e['polarity']=='ask' and re.fullmatch(r'水电是民用是商用[？?]?',q):
   spans.append(q);covered.add(pool);asks.append('水电标准')
  if pool=='房内设施' and e['polarity']=='ask' and re.fullmatch(r'没(?:有)?厨房[吗么？?]*',q):spans.append(q)
 if norm(txt)=='蹲':holds.append('weak_waiting_interaction_specific_action_unresolved')
 rem=leftover(txt,spans,tags);z['unbound_literal_residual']=rem
 if rem:holds.append('unbound_short_literal_or_condition:'+rem)
 if tags-covered:holds.append('unbound_existing_pools:'+','.join(sorted(tags-covered)))
 if any(re.search(r'我|我们|本人|咱',v) for v in details.values()):holds.append('literal_first_person_cannot_be_reply_speaker')
 # Any detail must come from original AI evidence or a typed region/time record.
 if any(not any(v in e['quote'] for e in ev) and not any(v==rr.get('quote') for rr in regs) and not any(v==tt.get('quote') for tt in a['time_mentions']) for v in details.values()):holds.append('extracted_literal_outside_existing_AI_evidence')
 if not holds:
  fam=None;fill=details.copy();ee=evidence[:];template=None
  if not details:
   existing={frozenset({'价格预算'}):'price',frozenset({'房源状态'}):'available',frozenset({'位置通勤'}):'location',frozenset({'价格预算','位置通勤'}):'price_location'}
   fam=existing.get(frozenset(tags))
   if '月租' in asks:fam=None
  elif set(details)=={'place'} and tags <= {'位置通勤','房源状态'}:fam='area'
  elif set(details)=={'destination'} and tags <= {'位置通勤','房源状态'}:fam='commute'
  elif set(details)=={'room'} and tags=={'户型面积与居住方式'}:fam='requirements';fill={'requirements':details['room']};ee=[dict(e,field='requirements') for e in evidence]
  elif set(details)=={'duration'} and tags=={'入住与租期'}:fam='lease_fixed';fill={'duration':details['duration']}
  if not fam:
   components=[]
   for field,val in details.items():
    marker='{'+field+'}'
    if field=='destination':marker='去'+marker+'的通勤'
    elif field=='budget' and not re.search(r'预算|价位|接受',val):marker='预算'+marker
    elif field=='asked_price':marker=marker+'是否实价'
    elif field=='price_condition':marker=marker+'有没有合适的'
    elif field=='cost_preference' and val=='穷鬼':
     # Retain the literal in evidence but do not call the customer this in a reply.
     holds.append('cost_preference_needs_polite_short_binding');continue
    components.append(marker)
   components+=asks
   if not components:holds.append('no_specific_pool_family')
   elif not holds:
    # One integrated fixed family per structural combination, not per-comment wording.
    signature='_'.join(details)+('_labelled' if 'budget' in details and re.search(r'预算|价位|接受',details['budget']) else '')+'__'+'_'.join({'空房':'available','租金':'price','位置':'location','看房联系':'viewing','房东联系方式':'landlord_contact','约看时间':'viewing_time','看房安排':'viewing_arrangement','联系方式':'contact_method','租房流程':'rent_process','月租':'monthly_price','面积户型':'size_room','水电标准':'utility_standard'}[x] for x in asks)
    fam='literal_'+(signature or 'question')
    template='宝宝，我住方隅，'+'、'.join(components)+'帮你问，介绍有优惠。'
    add_family(fam,template,fill)
  if fam and not holds:
   z.update(family=fam,fill=fill,evidence=ee,status='local_plan_proposed',binding_strategy='existing_pool_family_with_literal_slots' if fam in base_families else 'fixed_pool_combination_with_literal_slots')
 if holds:z.update(family=None,fill={},evidence=[],status='local_plan_held')
 z['hold_reasons']=list(dict.fromkeys(holds));z['covered_existing_pools']=sorted(covered);z['preserved_missing_facts']=copy.deepcopy((a.get('reply_plan') or {}).get('missing_facts') or [])
 z['additional_fact_holds']=['真实住户身份及介绍优惠适用资格待核','具体房源、同店同适用房型与全部所提条件待核；未答复报价或承诺满足']
 z['draft_text_preview']=None;z['rendered_text']=None
 if z['family']:
  plan={'local_mother':{k:z[k] for k in ('family','fill','evidence')},'tone':(a.get('reply_plan') or {}).get('tone','normal'),'contact_policy':z['contact_policy_effective_for_render']}
  rr={'role':a['role'],'demand_state':a['demand_state'],'interest_at_comment':a['interest_at_comment'],'source_version_conflict':bool((r.get('source_record') or {}).get('source_version_conflict')),'reply_plan':plan}
  rendered=renderer.render_plan(rr,txt,contract);z['draft_text_preview']=rendered.get('validated_plan_text');z['rendered_text']=rendered['text'];z['renderer_status']=rendered['status']
  if len(z['draft_text_preview'])>78:
   z.update(family=None,fill={},evidence=[],status='local_plan_held',draft_text_preview=None,rendered_text=None);z['hold_reasons'].append('short_template_length_exceeds_78_needs_short_scope_binding')
 return z
plans=[bind(p) for p in ps]
used={p['family'] for p in plans if p['family']};addons={k:v for k,v in addons.items() if k in used}
putjl(O/'proposed-plans.jsonl',plans);put(O/'contract-addon.json',{'version':'legacy-literal-binding-v1','base_contract_file':str((B/'local-mother-contract.json').resolve()),'base_contract_sha256':sha(B/'local-mother-contract.json'),'families':addons,'send_authorized':False,'specific_wording_individually_user_approved':False})
putjl(O/'rendered-preview.jsonl',[{k:p.get(k) for k in ('platform','cid','uid','sourceSHA','family','fill','draft_text_preview','rendered_text','renderer_status','contact_policy_original','contact_policy_effective_for_render','delivery_holds','hold_reasons','send_authorized','can_send_now')} for p in plans])
checks=[];old={(p['platform'],p['cid'],p['uid']):p for p in ps}
for p in plans:
 key=p['platform'],p['cid'],p['uid'];r=rows[key];original=old[key]
 assert p['sourceSHA']==hashlib.sha256(r['comment_text'].encode()).hexdigest()
 assert p['original_classification_sha256']==objsha(r.get('source_record') or {})
 assert p['literal_evidence']==original['literal_evidence'] and p['source_field_evidence']==original['source_field_evidence']
 assert p['contact_policy_original']==original['contact_policy_original'] and p['contact_policy_effective_for_render']==(original['contact_policy_original'] or 'unknown')
 assert not p['send_authorized'] and not p['can_send_now'] and not p['classification_changed']
 for field,value in p['fill'].items():
  assert value in r['comment_text'];assert any(e['field']==field and e['quote']==value for e in p['evidence'])
 assert not p['draft_text_preview'] or all(v in p['draft_text_preview'] for v in p['fill'].values())
 assert (p['family'] is not None)==(p['status']=='local_plan_proposed')
 if p['contact_policy_effective_for_render']=='unknown':assert p['rendered_text'] is None
for f,h in protected.items():assert sha(f)==h,('source_changed',f)
assert len(plans)==len({(p['platform'],p['cid'],p['uid']) for p in plans})==4620
counts={'scope':4620,'newly_bound':sum(bool(p['family']) for p in plans),'still_held':sum(not p['family'] for p in plans),'families':dict(collections.Counter(p['family'] for p in plans if p['family'])),'hold_reasons':dict(collections.Counter(h for p in plans for h in p['hold_reasons'])),'platforms':dict(collections.Counter(p['platform'] for p in plans)),'unknown_contact_bound_previews':sum(bool(p['family']) and p['contact_policy_effective_for_render']=='unknown' for p in plans),'length_distribution':dict(collections.Counter('20-40' if len(p['draft_text_preview'])<=40 else '41-60' if len(p['draft_text_preview'])<=60 else '61-78' for p in plans if p['draft_text_preview']))}
put(O/'counts.json',counts)
put(O/'validate.json',{'all_passed':True,'records':4620,'ID_CID_UID_sourceSHA_classification_fingerprint':True,'original_fields_preserved':True,'fill_is_single_contiguous_own_comment_span':True,'every_fill_has_exact_evidence':True,'unknown_contact_not_escalated':True,'renderer_reused':str((B/'batch_short_mothers.py').resolve()),'renderer_sha256':sha(B/'batch_short_mothers.py'),'source_files_and_pointers_unchanged':True,'protected_source_count':len(protected),'source_sha256':protected,'platform_calls':0,'send_attempts':0,'model_batch_rewrite_calls':0,'per_comment_reclassification':False,'representative_review_count':60,'representative_review_is_independent_holdout':False,'accuracy_claim':None,'output_sha256':{f:sha(O/f) for f in ('proposed-plans.jsonl','contract-addon.json','rendered-preview.jsonl','representative-input.jsonl','representative-review.jsonl','counts.json')}})
put(O/'manifest.json',{'scope_category':'literal_extraction_or_existing_pool_binding_gap','scope_source':str(source.resolve()),'scope_source_sha256':sha(source),'scope_count':4620,'planner_file':str(pathlib.Path(__file__).resolve()),'planner_sha256':sha(__file__),'base_contract':str((B/'local-mother-contract.json').resolve()),'base_contract_sha256':sha(B/'local-mother-contract.json'),'source_pointer':str((W/'region-brand-routing/current.json').resolve()),'source_pointer_sha256':sha(W/'region-brand-routing/current.json'),'source_files':protected,'applied':False,'send_authorized':False,'platform_calls':0,'created_at':datetime.datetime.now().astimezone().isoformat()})
print(json.dumps({k:v for k,v in counts.items() if k not in ('families','hold_reasons')},ensure_ascii=False));print('families',counts['families']);print('top holds',collections.Counter(counts['hold_reasons']).most_common(30))
