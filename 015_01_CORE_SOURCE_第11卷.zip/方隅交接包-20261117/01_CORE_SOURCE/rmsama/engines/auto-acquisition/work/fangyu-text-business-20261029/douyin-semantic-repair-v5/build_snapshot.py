import json, sqlite3, importlib.util, collections, re, hashlib, os, time
from pathlib import Path
from datetime import datetime,timezone
import semantic_guard as guard
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent.parent/'recency-priority'))
import recency
import retention30
import business_fit
import complete_local_demand
import local_recheck
HERE=Path(__file__).resolve().parent;WORK=HERE.parent;BASE=WORK.parent/'fangyu-douyin-independent'
# Every invocation, including the already-running watcher's subprocess, shares a
# Windows lock. Concurrent rebuild requests cannot overwrite the same snapshot.
import msvcrt
_build_lock=(HERE/'build.lock').open('a+b');_build_lock.seek(0)
if not _build_lock.read(1):_build_lock.write(b'0');_build_lock.flush()
_build_lock.seek(0);msvcrt.locking(_build_lock.fileno(),msvcrt.LK_LOCK,1)
def load(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def module(name,p):
 s=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
def ro(p):return sqlite3.connect(Path(p).resolve().as_uri()+'?mode=ro',uri=True)
def dump(p,obj):
 p=Path(p);tmp=p.with_suffix(p.suffix+'.tmp');tmp.write_text(json.dumps(obj,ensure_ascii=False,indent=2),encoding='utf-8');replace_file(tmp,p)
def jl(p,rows):
 p=Path(p);tmp=p.with_suffix(p.suffix+'.tmp');tmp.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows),encoding='utf-8');replace_file(tmp,p)

def replace_file(source,target):
 for attempt in range(21):
  try:
   os.replace(source,target)
   return
  except PermissionError:
   if attempt==20:raise
   time.sleep(0.25)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def apply_business_fit_with_reply_digest(row):
 screened = business_fit.apply(row)
 draft = (screened.get('reply') or {}).get('draft_text') or ''
 screened['reply_body_sha256'] = hashlib.sha256(draft.encode('utf-8')).hexdigest()
 return screened
def dated_record(row):
 row=dict(row)
 source_date=source_dates.get(str(row.get('comment_id','')))
 if source_date is not None:
  row['published_at_unix']=source_date
  row['published_at']=datetime.fromtimestamp(source_date,timezone.utc).isoformat()
 if not row.get('published_at'):
  timestamp=recency.stamp(row)
  if timestamp is not None:row['published_at']=datetime.fromtimestamp(timestamp,timezone.utc).isoformat()
 return row
classifier=module('poolclassifier',WORK/'pool-sop-v3/classifier/classifier.py')
transport=module('transport',WORK/'local-rule-pipeline/run_local_pipeline.py')
with ro(BASE/'runtime/collection.sqlite3') as source_clock_db:
 source_dates={}
 for source_cid,raw in source_clock_db.execute("SELECT source_id,data FROM entities WHERE kind='comments'"):
  item=json.loads(raw)
  if str(item.get('cid'))==str(source_cid):source_dates[str(source_cid)]=retention30.stamp(item)
pointer=load(BASE/'text-screening-current-summary.json');historical_path=Path(pointer['result_file'])
baseline={r['comment_id']:dated_record(r) for r in map(json.loads,historical_path.read_text(encoding='utf-8-sig').splitlines())}
oldstate=ro(WORK/'local-first-resumption/state/derived.sqlite3');state=sqlite3.connect(HERE/'qualification-snapshot.sqlite3');oldstate.backup(state)
delta={r[0]:json.loads(r[1]) for r in oldstate.execute('select cid,data from delta')};oldstate.close()
source=transport.open_source(BASE/'runtime/collection.sqlite3');transport.refresh_metadata(source,state,'douyin',load(transport.DEFAULT_POLICY))
keys=[x[0] for x in state.execute(f"SELECT DISTINCT o.stable_key FROM observations o JOIN qualified q ON {transport.QUALIFIED_JOIN} WHERE o.platform='douyin'")]
eligible={k.removeprefix('comment:') for k in keys}
if retention30.enabled('douyin'):
 eligible={cid for cid in eligible if cid in source_dates and retention30.allowed({'comment_id':cid,'published_at_unix':source_dates[cid]},'douyin')}
newids=eligible-set(baseline);new={}
for cid in sorted(newids):
 r=delta.get(cid) or transport.make_record(source,state,'douyin','comment:'+cid,guard.VERSION)
 new[cid]=dated_record(r)
source.close();state.close()
original_all=dict(baseline);original_all.update(new)
business_fit.prepare_low_price_comment_videos(original_all.values())
baseline_total=len(baseline)
active_now=datetime.now(timezone.utc).timestamp()
active_ids={cid for cid,row in original_all.items() if cid in eligible and recency.within_douyin_active_window(row,active_now)}
unknown_dates=[row for cid,row in original_all.items() if cid in eligible and recency.key(row,active_now)[0]==6]
outside_dates=[row for cid,row in original_all.items() if cid in eligible and recency.key(row,active_now)[0] in (3,4,5)]
assert len(active_ids)+len(outside_dates)+len(unknown_dates)==len(eligible)
baseline={cid:row for cid,row in baseline.items() if cid in active_ids}
new={cid:row for cid,row in new.items() if cid in active_ids}
local_cache={}
local_seed_ids=set()
for local_seed in [WORK/'local-backlog-recheck-20261105/decisions.jsonl',WORK/'old-library-audit-20261106/additional-decisions.jsonl']:
 if local_seed.exists():
  for line in local_seed.read_text(encoding='utf-8-sig').splitlines():
   decision=json.loads(line)
   if decision.get('version')==local_recheck.VERSION:
    local_cache[decision['input_evidence_sha256']]=decision;local_seed_ids.add(decision['comment_id'])
cache_path=HERE/'local-recheck-cache.json'
if cache_path.exists():
 for key,decision in load(cache_path).items():
  if decision.get('version')==local_recheck.VERSION and key not in local_cache:local_cache[key]=decision
local_decisions={}
def recheck_local(row):
 key=local_recheck.evidence_hash(row)
 decision=local_cache.get(key)
 if not decision:
  decision=local_recheck.decide(row);local_cache[key]=decision
 local_decisions[row['comment_id']]=decision
 return local_recheck.apply_decision(row,decision)
for cid,row in list(baseline.items()):
 if cid in local_seed_ids or business_fit.screen(row)['lead_intent']=='uncertain':baseline[cid]=recheck_local(row)
ledger=ro(WORK.parent/'shared-acquisition-ledger/shared.sqlite3');ledger.row_factory=sqlite3.Row
leads=[dict(r) for r in ledger.execute("SELECT * FROM leads WHERE platform='douyin'")]
reservations=[dict(r) for r in ledger.execute("SELECT * FROM reservations WHERE platform='douyin'")];ledger.close()
bycid=collections.defaultdict(list);bycustomer=collections.defaultdict(list)
for r in leads+reservations:bycid[r['comment']].append(r);bycustomer[r['customer']].append(r)
rank={'sent':4,'unknown':3,'reserved':2,'not_sent':1,'unverified':0}
def delivery(cid,uid):
 records=bycid[cid]+bycustomer[uid];status=max((r['status'] for r in records),key=lambda s:rank.get(s,3),default='not_sent')
 if status=='unverified':status='not_sent'
 evidence=[]
 for p in [BASE/'reply-pilot'/f'{cid}.json',BASE/'reply-pilot/pilot.json']:
  if p.exists():
   r=load(p)
   if str(r.get('comment_id',r.get('cid')))==cid:evidence.append({'path':str(p),'sha256':sha(p),'record':r})
 return {'status':status,'ledger_records':records,'actual_attempt_records':evidence,'actual_attempt_details_status':'located' if evidence else 'not_located_ledger_evidence_only','excluded_from_pending':status in ('sent','unknown','reserved')}
reviews={}
review_path=HERE/'semantic-reviewed.jsonl'
if review_path.exists():
 for line in review_path.read_text(encoding='utf-8-sig').splitlines():
  rev=json.loads(line);reviews[rev['comment_id']]=rev
def infer(r):
 rev=reviews.get(r['comment_id'])
 if rev and rev.get('comment_text_sha256')==hashlib.sha256(r.get('comment_text','').encode()).hexdigest():
  r['contact_hold']=bool(rev.get('contact_hold'))
  r['brand_recommendation_allowed']=rev.get('brand_recommendation_allowed',True)
 if r['comment_id'] in local_seed_ids:
  r.update(recheck_local(r))
  return r.get('interest_at_comment','uncertain'),r.get('role','unknown'),'local_backlog_recheck'
 if rev and rev.get('comment_text_sha256')==hashlib.sha256(r.get('comment_text','').encode()).hexdigest() and rev['interest_at_comment'] not in ('unknown','uncertain'):
  return rev['interest_at_comment'],rev['role'],'targeted_AI_semantic_review'

 t=r.get('comment_text','');prior=r.get('classification_stage')
 if prior in ('ai_semantic_review_completed','local_completed') and r.get('interest_at_comment') not in ('unknown','uncertain'):
  return r.get('interest_at_comment','uncertain'),r.get('role','unknown'),'prior_review_reused'
 r.update(recheck_local(r))
 if r['local_recheck']['role']!='unknown':return r['interest_at_comment'],r['role'],'local_backlog_recheck'
 if r.get('source_error') or r.get('source_version_conflict') or r.get('post_author_same_as_commenter') or str(r.get('reply_to','0'))!='0':return 'uncertain','unknown','context_review'
 st,_=guard.state(t)
 if st!='active_or_unknown':return 'uncertain','unknown',st
 if re.search(r'我.{0,3}(?:有房|出租|转租)|找室友|招室友|房东|中介|不|没|如果|以前|去年|已经|决定',t):return 'uncertain','unknown','complex_semantics'
 if re.search(r'真的假的|真有吗|太贵|好贵|这么贵|好便宜',t):return 'uncertain','unknown','price_reaction_review'
 if re.search(r'求租|想租|要租|正在找房|礼貌问价|礼貌询价|多少钱|什么价|哪里|在哪|位置|价格|多少米|(?:一室|两室|一居|两房|一房|套一|套二).{0,6}(?:有吗|有嘛|私我)|有没有|有房|有这样|有这么|有吗|有嘛|有不|还有吗|还在吗|预算',t) or re.fullmatch(r'多少[?？!！。 ]*',t):
  if re.search(r'租|公寓|整租|房',r.get('post_body','')) or re.search(r'求租|想租|要租|预算',t):return 'high','demand','local_explicit_rental_question'
 return 'uncertain','unknown','needs_semantic_review'
old=[row for row in map(json.loads,(WORK/'reply-handoff-current/douyin-replies.jsonl').read_text(encoding='utf-8-sig').splitlines()) if row['comment_id'] in active_ids]
result=[];affected=[]
for r in old:
 cid=r['comment_id']; original=baseline.get(cid,new.get(cid,{}));uid=str(original.get('customer_uid',''))
 merged=dict(original,**r)
 if original.get('role'):merged['role']=original['role']
 if original.get('target_regions'):merged['target_regions']=original['target_regions']
 if original.get('source_error'):merged['source_error']=original['source_error']
 if original.get('source_version_conflict'):merged['source_version_conflict']=original['source_version_conflict']
 reply=guard.render(merged);g=reply['semantic_guard'];interest=original.get('interest_at_comment') or 'high';reason='existing_high_snapshot_reused'
 if g['state']!='active_or_unknown':interest='uncertain';reason=g['state']
 if g['discarded_time_slots'] or g['negative'] or g['state']!='active_or_unknown':affected.append({'comment_id':cid,'comment':r['comment_text'],'before':r['reply']['draft_text'],'after':reply.get('draft_text'),'guard':g})
 d=delivery(cid,uid);out=dict(merged,customer_uid=uid,reply=reply,interest_at_comment=interest,semantic_review_stage=reason,delivery=d)
 out['pending_candidate']=bool(reply.get('draft_text')) and not reply.get('contact_hold') and interest in ('high','super_high','medium') and not d['excluded_from_pending'] and not r.get('contact_boundaries') and not r.get('needs_currentness_review')
 out=apply_business_fit_with_reply_digest(out)
 if not out['commercial_fit']['eligible_candidate'] and r.get('reply',{}).get('draft_text'):out['prior_draft_before_business_fit']=r['reply']
 result.append(out)
existing={r['comment_id'] for r in result};increment=[]
for cid,r in new.items():
 interest,role,method=infer(r);cr=classifier.classify(dict(r,original_classification=r));pools=cr['pools']
 if r.get('local_recheck',{}).get('role')=='demand':
  pools=list(dict.fromkeys(r['local_recheck']['pools']+pools))
  cr.update(pools=pools,needs_AI=not bool(pools),classification_method='local_evidence_recheck')
 if method=='targeted_AI_semantic_review':
  rev=reviews[cid];pools=rev['pools'];cr.update(pools=pools,review_reason=rev['reason'],review_evidence=rev['evidence'])
 if interest=='high' and not pools and re.fullmatch(r'(?:多少|礼貌询价)[?？!！。 ]*',r.get('comment_text','')):pools=['价格预算']
 rr=dict(r,pools=pools,subtags=cr.get('subtags',[]),classification=cr)
 if method=='targeted_AI_semantic_review':
  rr['semantic_review']=reviews[cid]
  rr['contact_hold']=bool(reviews[cid].get('contact_hold'))
  rr['brand_recommendation_allowed']=reviews[cid].get('brand_recommendation_allowed',True)

 reply=guard.render(rr) if interest in ('high','super_high','medium') else {'draft_text':None,'status':'not_classified_as_current_demand'}
 if rr.get('brand_recommendation_allowed') is False:
  reply={'draft_text':None,'status':'explicit_brand_type_exclusion','review_evidence':reviews[cid].get('evidence'),'send_authorized':False}
 if rr.get('contact_hold'):
  reply['contact_hold']=True
 d=delivery(cid,str(r.get('customer_uid','')))
 out=dict(rr,interest_at_comment=interest,role=role,semantic_review_stage=method,reply=reply,delivery=d,pending_candidate=bool(reply.get('draft_text')) and not reply.get('contact_hold') and not d['excluded_from_pending'] and not r.get('contact_boundaries') and not r.get('needs_currentness_review') and not r.get('source_error') and not r.get('source_version_conflict') and not reply.get('contact_hold') and not re.search(r'勿扰|不要私信|别私信|不要联系|别联系',r.get('comment_text','')))
 if rr.get('contact_hold') or rr.get('brand_recommendation_allowed') is False:out['pending_candidate']=False
 out=apply_business_fit_with_reply_digest(out);increment.append(out)
 if cid not in existing:result.append(out)
completed=[]
for index,row in enumerate(result):
 if (row.get('reply') or {}).get('draft_text'):
  continue
 supplement=complete_local_demand.complete(row)
 if supplement:
  supplement['delivery']=delivery(row['comment_id'],str(row.get('customer_uid') or ''))
  supplement['pending_candidate']=not supplement['delivery']['excluded_from_pending']
  result[index]=apply_business_fit_with_reply_digest(supplement)
  completed.append(result[index])
existing={row['comment_id'] for row in result}
for cid,row in baseline.items():
 if cid in existing:
  continue
 supplement=complete_local_demand.complete(row)
 if supplement:
  supplement['delivery']=delivery(cid,str(row.get('customer_uid') or ''))
  supplement['pending_candidate']=not supplement['delivery']['excluded_from_pending']
  supplement=apply_business_fit_with_reply_digest(supplement)
  result.append(supplement);completed.append(supplement);existing.add(cid)
# Keep the complete historical all-intent pool, including low/medium/unrelated,
# independently searchable. This is a commercial rescreen, not intent reanalysis.
all_source=dict(baseline);all_source.update(new)
for reviewed in increment:
 cid=reviewed['comment_id']
 all_source[cid]=dict(all_source[cid],role=reviewed.get('role'),interest_at_comment=reviewed.get('interest_at_comment'),pools=reviewed.get('pools'),semantic_review_stage=reviewed.get('semantic_review_stage'),classification=reviewed.get('classification'),brand_recommendation_allowed=reviewed.get('brand_recommendation_allowed',True))
 for key in ('local_recheck','local_recheck_completed','prior_local_recheck'):
  if key in reviewed:all_source[cid][key]=reviewed[key]
for reviewed in completed:
 cid=reviewed['comment_id']
 all_source[cid]=dict(all_source[cid],pools=reviewed['pools'],classification=reviewed['classification'],semantic_review_stage=reviewed['semantic_review_stage'])
completed_by_id={row['comment_id']:row for row in completed}
increment=[completed_by_id.get(row['comment_id'],row) for row in increment]
all_pool=[dict(r,commercial_fit=business_fit.screen(r)) for r in all_source.values()]
visible_pool=[row for row in all_pool if row['commercial_fit']['lead_intent'] in ('medium','high','super_high') and row['commercial_fit']['eligible_candidate']]
jl(HERE/'retained-business-customers.jsonl',visible_pool)
jl(HERE/'archived-outside-30days.jsonl',[] if retention30.enabled('douyin') else outside_dates)
jl(HERE/'quarantined-comment-dates.jsonl',unknown_dates)
jl(HERE/'all-pool-business-fit.jsonl',all_pool)
jl(HERE/'local-recheck-results.jsonl',[row for row in all_pool if row['comment_id'] in local_decisions])
dump(cache_path,local_cache)
jl(HERE/'douyin-replies.jsonl',result);jl(HERE/'affected-review.jsonl',affected);jl(HERE/'increment-results.jsonl',increment)
jl(HERE/'pending-candidates.jsonl',sorted([r for r in result if r['pending_candidate']],key=recency.priority_key));jl(HERE/'increment-needs-review.jsonl',[r for r in increment if r['interest_at_comment']=='uncertain'])
counts=collections.Counter(r['interest_at_comment'] for r in increment)
status={'updated_at':datetime.now(timezone.utc).isoformat(),'platform':'douyin','status':'bounded_snapshot_completed_with_explicit_review_backlog','semantic_repair_completed':True,'semantic_validation':'12 unittest methods passed including positive and negative cases; not an overall accuracy estimate','historical_high_snapshot_checked':len(old),'historical_affected':len(affected),'historical_all_comment_intent_reanalysis':False,'eligible_registered':len(eligible),'published_baseline':len(baseline),'increment_snapshot':len(new),'new_since_prior_worker':len(newids-set(delta)),'increment_interest_counts':dict(counts),'increment_methods':dict(collections.Counter(r['semantic_review_stage'] for r in increment)),'increment_unresolved':sum(r['interest_at_comment']=='uncertain' for r in increment),'historical_high_reply_nonempty':sum(bool(r['reply'].get('draft_text')) for r in result[:len(old)]),'historical_high_demoted_for_state':sum(r['interest_at_comment']=='uncertain' for r in result[:len(old)]),'ledger_status_counts':dict(collections.Counter(r['status'] for r in leads)),'excluded_counts':dict(collections.Counter(r['delivery']['status'] for r in result if r['delivery']['excluded_from_pending'])),'source_result_sha256':sha(historical_path),'output':str(HERE/'douyin-replies.jsonl'),'output_sha256':sha(HERE/'douyin-replies.jsonl'),'pending_candidates':str(HERE/'pending-candidates.jsonl'),'pending_candidates_count':sum(r['pending_candidate'] for r in result),'increment_needs_review':str(HERE/'increment-needs-review.jsonl'),'new_collection_confirmed':bool(newids-set(delta)),'collection_status_observed':load(BASE/'active-runner.json').get('status'),'source_database_modified':False,'shared_ledger_modified':False,'actual_sent_records_modified':False,'platform_requests':0,'reply_generation_model_calls':0,'new_AI_semantic_calls':'unknown' if reviews else 0,'targeted_semantic_review_records':sum(r['semantic_review_stage']=='targeted_AI_semantic_review' for r in increment),'worker_not_restarted':True,'all_increment_semantics_completed':False,'send_authorized':False}
status['commercial_fit']={'version':business_fit.VERSION,'all_pool_records':len(all_pool),'all_pool_counts':dict(collections.Counter(r['commercial_fit']['commercial_fit'] for r in all_pool)),'all_pool_file':str(HERE/'all-pool-business-fit.jsonl'),'all_pool_sha256':sha(HERE/'all-pool-business-fit.jsonl'),'reply_counts':dict(collections.Counter(r['commercial_fit']['commercial_fit'] for r in result)),'priority_pending_count':sum(r['pending_candidate'] and r['commercial_priority'] for r in result),'generic_pending_count':sum(r['pending_candidate'] and not r['commercial_priority'] for r in result),'code_sha256':sha(WORK/'business-fit/business_fit.py'),'historical_intent_preserved':True,'whole_home_monthly_maximum_below_3000_excluded':True,'budget_3000_3999_held':True}
status['active_pool']={'policy':recency.DOUYIN_ACTIVE_POOL_POLICY,'as_of':datetime.fromtimestamp(active_now,timezone.utc).isoformat(),'maximum_age_days':30,'active_registered':len(active_ids),'archived_outside_window':len(outside_dates),'quarantined_dates':len(unknown_dates),'archive_file':str(HERE/'archived-outside-30days.jsonl'),'quarantine_file':str(HERE/'quarantined-comment-dates.jsonl'),'source_registered_preserved':len(eligible)}
status['published_baseline']=baseline_total
if retention30.enabled('douyin'):
 status['published_baseline']=len(baseline)
 status['active_pool']['archived_outside_window']=0
 status['active_pool']['retention_mode']='delete_expired_no_business_archive'
 status['active_pool']['source_registered_preserved']=len(active_ids)
status['raw_increment_registered']=len(newids)
status['local_reply_completion']={'records':len(completed),'pending_after_ledger':sum(row['pending_candidate'] for row in completed),'model_calls':0,'method':'已具备业务判断的需求按池选母句，本地补齐旧索引遗漏或空池'}
status['local_reply_completion']['code_sha256']=sha(HERE/'complete_local_demand.py')
status['commercial_fit']['lead_intent_counts']=dict(collections.Counter(row['commercial_fit']['lead_intent'] for row in all_pool))
status['commercial_fit']['pending_lead_intent_counts']=dict(collections.Counter(row['commercial_fit']['lead_intent'] for row in result if row['pending_candidate']))
status['visible_business_pool']={'file':str(HERE/'retained-business-customers.jsonl'),'sha256':sha(HERE/'retained-business-customers.jsonl'),'count':len(visible_pool),'intent_counts':dict(collections.Counter(row['commercial_fit']['lead_intent'] for row in visible_pool)),'scope':'within_30_days_medium_high_super_high_only','unresolved_not_displayed':True}
status['local_backlog_recheck']={'version':local_recheck.VERSION,'checked_active_records':len(local_decisions),'categories':dict(collections.Counter(d['category'] for d in local_decisions.values())),'model_calls':0,'results':str(HERE/'local-recheck-results.jsonl'),'results_sha256':sha(HERE/'local-recheck-results.jsonl'),'fixed_cohort_summary':str(WORK/'local-backlog-recheck-20261105/summary.json'),'code_sha256':local_recheck.CODE_SHA256}
status['semantic_validation']='Deterministic semantic, business-fit and queue-admission regression suites; not an overall accuracy estimate'
if (HERE/'worker-restart-receipt.json').exists():
 status['worker_not_restarted']=False;status['local_worker_restart_receipt']=load(HERE/'worker-restart-receipt.json')
dump(HERE/'manifest.json',status);dump(BASE/'classification-handoff-status.json',status);print(json.dumps(status,ensure_ascii=False))
# Refresh the local consumption pointer after each completed source snapshot.
# No model/platform calls; a transient sorter lock does not erase classification.
import subprocess
try:
 refreshed=subprocess.run([sys.executable,str(WORK/'recency-priority/daily_time_sort.py'),'--platform','douyin'],capture_output=True,timeout=90)
 if refreshed.returncode==0:
  report=subprocess.run([sys.executable,str(WORK/'pool-audit/report_rescreen.py'),'--platform','douyin'],capture_output=True,timeout=90)
 dump(HERE/'priority-refresh-status.json',{'at':datetime.now(timezone.utc).isoformat(),'returncode':refreshed.returncode,'error':refreshed.stderr.decode('utf-8',errors='replace')[-1500:] if refreshed.returncode else None,'model_calls':0,'platform_requests':0})
except (OSError,subprocess.TimeoutExpired) as error:
 dump(HERE/'priority-refresh-status.json',{'at':datetime.now(timezone.utc).isoformat(),'error':str(error),'model_calls':0,'platform_requests':0})
try:
 visible_refresh=subprocess.run([sys.executable,str(WORK/'retention-cleanup-20261106/refresh_visible_business.py'),'--refresh-only'],capture_output=True,timeout=30)
 dump(HERE/'visible-refresh-status.json',{'returncode':visible_refresh.returncode,'error':visible_refresh.stderr.decode('utf-8',errors='replace')[-1000:] if visible_refresh.returncode else None,'platform_requests':0})
except (OSError,subprocess.TimeoutExpired) as error:
 dump(HERE/'visible-refresh-status.json',{'error':str(error),'platform_requests':0})
