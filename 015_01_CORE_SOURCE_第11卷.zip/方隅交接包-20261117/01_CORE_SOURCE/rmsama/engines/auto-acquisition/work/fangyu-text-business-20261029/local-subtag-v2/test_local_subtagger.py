import unittest
from local_subtagger import annotate, classify_intent
class HardCases(unittest.TestCase):
 def test_local_negation(self):
  a=annotate({'comment_text':'不要合租，要整租，能养猫吗','interest_at_comment':'high'})
  d={h['subtag']:h['polarity'] for h in a['evidence']}
  self.assertEqual(d['合租'],'negative'); self.assertNotEqual(d['整租'],'negative'); self.assertEqual(d['能带猫'],'question')
 def test_negated_question(self):
  a=annotate({'comment_text':'不能养猫吗？'})
  self.assertEqual(a['evidence'][0]['polarity'],'negative_question')
 def test_supply_mix(self):
  a=annotate({'comment_text':'我出租一室一厅，但我想租两室，预算3000'})
  self.assertEqual(a['role_signal'],'mixed_supply_demand'); self.assertTrue(a['needs_semantic_review'])
 def test_condition(self):
  a=annotate({'comment_text':'如果可以养猫就下个月入住，或者短租'})
  self.assertTrue(any(h['condition'] for h in a['evidence'])); self.assertEqual(a['constraint_relation'],'alternative_or_mixed')
 def test_preserve(self):
  a=annotate({'comment_text':'哈哈','interest_at_comment':'high','demand_pools':['宠物']})
  self.assertEqual(a['original_interest'],'high'); self.assertEqual(a['status'],'unmatched_retained'); self.assertEqual(a['original_pools'],['宠物'])
 def test_span(self):
  t='不要燃气，要厨房和独卫'; a=annotate({'comment_text':t})
  for h in a['evidence']: self.assertEqual(t[h['start']:h['end']],h['text'])
 def test_not_promote(self):
  a=annotate({'comment_text':'出租，电梯房，猫可以','interest_at_comment':'low'})
  self.assertEqual(a['original_interest'],'low'); self.assertEqual(a['role_signal'],'supply_signal')
class IntentCases(unittest.TestCase):
 def test_context_question(self):
  self.assertEqual(classify_intent({'comment_text':'多少钱','post_body':'北京公寓出租'})['state'],'local_decided')
 def test_question_without_context(self):
  self.assertEqual(classify_intent({'comment_text':'多少钱'})['state'],'needs_ai')
 def test_author_guard(self):
  self.assertEqual(classify_intent({'comment_text':'多少钱','post_body':'公寓出租','post_author_same_as_commenter':True})['state'],'needs_ai')
 def test_reply_guard(self):
  self.assertEqual(classify_intent({'comment_text':'多少钱','post_body':'公寓出租','reply_to':'123'})['state'],'needs_ai')
 def test_explicit(self):
  self.assertEqual(classify_intent({'comment_text':'我想租房，不要合租，预算3000'})['role'],'demand')
 def test_family(self):
  self.assertEqual(classify_intent({'comment_text':'帮父母找房，必须电梯'})['state'],'local_decided')
 def test_short(self):
  self.assertEqual(classify_intent({'comment_text':'有吗'})['state'],'needs_ai')
 def test_nonhousing(self):
  self.assertEqual(classify_intent({'comment_text':'我想找个工作'})['state'],'needs_ai')
 def test_supply(self):
  self.assertEqual(classify_intent({'comment_text':'我出租两室一厅'})['role'],'supply')
 def test_ended(self):
  self.assertEqual(classify_intent({'comment_text':'已经租到了，谢谢'})['role'],'demand_ended')
 def test_quoted(self):
  self.assertEqual(classify_intent({'comment_text':'我想租房，他说不行'})['state'],'needs_ai')
class SupplyQuestionRegression(unittest.TestCase):
 def test_quoted_ended_is_not_own_ended(self):
  self.assertEqual(classify_intent({'comment_text':'他说已经租到了，我还没找到'})['state'],'needs_ai')
 def test_supply_and_seeking_is_not_supply_only(self):
  self.assertEqual(classify_intent({'comment_text':'我出租一室一厅，但我想租两室'})['state'],'needs_ai')
 def test_availability_is_not_supply(self):
  from local_subtagger import classify_intent
  r=classify_intent({'comment_text':'还有房子出租吗？','post_body':'上海租房'})
  self.assertEqual((r['state'],r['role']),('local_decided','demand'))
 def test_listing_is_not_question(self):
  from local_subtagger import classify_intent
  r=classify_intent({'comment_text':'有房出租','post_body':'上海租房'})
  self.assertEqual(r['state'],'needs_ai')
 def test_urgent_rental(self):
  from local_subtagger import classify_intent
  r=classify_intent({'comment_text':'房子还有吗？急租','post_body':'杭州租房'})
  self.assertEqual((r['state'],r['role']),('local_decided','demand'))

if __name__=='__main__': unittest.main()
