import json,hashlib,sys,datetime
from pathlib import Path
P=Path(__file__).parent
rows=json.loads((P/'review-wave2-frozen.json').read_text(encoding='utf-8'))
poolnames={'价':'价格预算','地':'位置通勤','型':'户型面积与居住方式','设':'房内设施','宠':'宠物','层':'楼层电梯','期':'入住与租期','房':'房源状态','费':'费用合同','联':'看房联系'}
decisions=json.loads(sys.stdin.read());old=[json.loads(l) for l in (P/'semantic-reviewed.jsonl').read_text(encoding='utf-8').splitlines()]
seen={(x['comment_id'],x['comment_text_sha256']):x for x in old}
for item in decisions:
 i,code,pools,reason=item[:4];r=rows[i];t=r['comment_text'];codes={'H':('high','demand','active_at_comment'),'M':('medium','demand','need_currentness_unknown'),'U':('uncertain','unknown','unclear'),'N':('unrelated','discussion','no_current_demand'),'S':('unrelated','supply','offering_property_or_services')}
 interest,role,state=codes[code];h=hashlib.sha256(t.encode()).hexdigest()
 out={'comment_id':r['comment_id'],'comment_text_sha256':h,'interest_at_comment':interest,'role':role,'pools':[poolnames[c] for c in pools],'demand_state':state,'reason':reason,'evidence':[t],'context_used':['own_comment','existing_post_body'],'review_stage':'bounded_AI_semantic_review','review_version':'douyin-v5-review-wave2-20261102','actual_usage':'unknown','API_request_count':'unknown','reply_generated':False,'current_need_verified':False,'wave2_index':i}
 if len(item)>4:out.update(item[4])
 if code in ('M','U'):out['current_need_review_required']=True
 seen[(r['comment_id'],h)]=out
tmp=P/'semantic-reviewed.jsonl.tmp';tmp.write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in seen.values()),encoding='utf-8');tmp.replace(P/'semantic-reviewed.jsonl')
progress=json.loads((P/'review-progress.json').read_text(encoding='utf-8'));count=sum('wave2_index' in x for x in seen.values());progress.update(completed=count,pending=len(rows)-count,updated_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),status='complete' if count==len(rows) else 'running');tmp=P/'review-progress.json.tmp';tmp.write_text(json.dumps(progress,ensure_ascii=False,indent=2),encoding='utf-8');tmp.replace(P/'review-progress.json');print(count,len(rows))
