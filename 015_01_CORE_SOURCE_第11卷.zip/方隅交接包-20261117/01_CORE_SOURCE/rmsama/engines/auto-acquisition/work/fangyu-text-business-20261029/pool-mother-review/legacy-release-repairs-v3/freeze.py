"""Final local verification then immutable READY. Never publishes."""
import pathlib,json,hashlib,subprocess,sys
O=pathlib.Path(__file__).resolve().parent
def load(p):return json.loads(p.read_text(encoding='utf8'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def put(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
assert not (O/'READY.json').exists(),'Already frozen. Use a new version for further changes.'
stats=load(O/'statistics.json');m=load(O/'manifest.json')
report=f'''# 引用语义补充后的本地修补稿

已按267条补充语义标签选择固定母句，另按授权调整1条短租用途确认句。共268条增量覆盖计划；没有重新判断原意向、逐条生成AI回复或修改旧文件，尚未发布。

全量仍为12963条，其中住房草稿6262、确认接话432、原held 6269。6694条已绑定草稿中，6426条正文与v2逐字相同；其余12695条计划记录与v2完全一致。变动范围仅267条标签输入及指定的额外1条。新增36个固定母句定义，旧合同的全部定义保留。

来源与选择：两片标签分别134/133条，去重后267条，和冻结input一一对应；原始标签完整保留，原评、客户、原分类、容器与共享帖子SHA均核对。程序按补充标签的引用关系选择路线，不再从“这个”猜语义。explicit_other_source可能只说明个人转租供应来源，不能证明不是方隅；unknown品牌也不等于未知住宅用途。住宅依据可来自reference_mentions/evidence，不能因没有独立housing字段机械追问。

八类闭合路线均有实际记录，路线允许组合：明确本人目标路口2、明确方隅3、其它或未明来源住房254、原帖价格关系6（其中3条金额关系仍未知，使用短报价确认）、同价位新找房1、比较价格1、月租/日历歧义1、额外住宅用途确认1。计数重叠，不能相加当人数。其它/未明来源用可选“也考虑这边吗”承接，不认领原帖房源，也不假定客户接受替代。

已知边界：明确路口直接保留原拼写与完整交叉口；三个明确方隅例不再问重复对象问题，但仍不承诺同店库存。3800问原帖报价，不改成找同价位房或本人预算。2.2k只作为原帖标价参照，单独绑定原帖与字段SHA。8500保留评论人的金额参照，不叫本人预算。月租歧义用中性租金承接，不问语法。C42保留租金、位置、私聊动作，不改联系方向。额外短租句固定为“宝宝，你是想找能短租的住处吗？”，仍不推广，contact未知不提升。

唯一帖子参数post_price_anchor需要bounded_renderer.py的限定引用校验：只允许既有AI明确的原帖价位参照，校验CID/UID/评论SHA、上下文SHA、帖子ID、字段SHA、逐字值、冻结AI引用与“原帖标的”归属。它不是客户要求，也不是方隅报价。原评论参数继续走未修改的锁定renderer；任意帖子正文不能填成自身事实。消费桥须使用该wrapper，不能把帖子参数直接塞进旧renderer。

独立本地JSON回放核验了全部12963个来源/原分类/联系绑定、6694个渲染、268个正文与clarification标记、6426条未变正文。累计1056条覆盖计划可直接叠加ABC，与v2之后再叠268条增量等价。故意篡改金额、客户、来源SHA、归属措辞、AI价格关系及原评字面值的6项阴性检查均被拒绝。

旧QA对照368条仅作为开发回归，另列9个实际边界；没有发新语义分数，不是新留出准确率。20–40字草稿266条，超40字1条（多项参照），不足20字1条（指定用途确认）。家族、长度和路线分布见statistics.json。技术覆盖不能当全库语义准确率，仍供root/Astra作有限独立补核。

使用方式：冻结ABC完整记录更新v2累计replacement_plan后，校验base_v2_applied_plan_sha256，再只更新v3增量replacement_plan；或直接从ABC应用本版累计覆盖计划。两条路径不要重复叠加。所有联系权限、原标签与发送边界保持；草稿可读不代表能发送。

新直接API请求0，本地模板渲染模型调用0；补充标签由此前两个Sol完成，整体agent判读usage未知。源/分类写入0、当前指针修改0、平台调用0、发送0。冻结后不再运行本目录会写盘的脚本；后续问题必须另版本。
'''
(O/'report.md').write_text(report,encoding='utf8')
m['status']='complete_local_candidate_frozen_pending_independent_semantic_review_not_published'
for name in ('verify.py','freeze.py','report.md'):m['outputs_SHA256'][name]=sha(O/name)
put(O/'manifest.json',m)
subprocess.run([sys.executable,str(O/'verify.py')],check=True)
assert all(sha(pathlib.Path(p))==h for p,h in m['source_SHA256'].items())
files={p.name:sha(p) for p in O.iterdir() if p.is_file() and p.name!='READY.json'}
put(O/'READY.json',{'status':'complete_frozen_for_independent_review_not_published','manifest_sha256':sha(O/'manifest.json'),'contract_sha256':sha(O/'repair-contract.json'),'incremental_overlay_sha256':sha(O/'incremental-plan-overlays.jsonl'),'cumulative_overlay_sha256':sha(O/'source-bound-plan-overlays.jsonl'),'final_files_sha256':files,'statistics':{k:v for k,v in stats.items() if k not in ('families','user_text_length')},'parent_v2_READY_sha256':m['v2_READY_SHA'],'source_or_classification_writes':0,'current_pointer_changes':0,'send_attempts':0,'local_rendering_model_calls':0,'new_direct_API_requests':0,'overall_agent_judgment_usage':'unknown','independent_semantic_review_pending':True})
print(json.dumps({'READY_SHA':sha(O/'READY.json'),'manifest_SHA':sha(O/'manifest.json'),'contract_SHA':sha(O/'repair-contract.json'),'incremental_SHA':sha(O/'incremental-plan-overlays.jsonl'),'cumulative_SHA':sha(O/'source-bound-plan-overlays.jsonl'),'CLI_SHA':sha(O/'CLI-draft-body-overlays.jsonl'),'validation_SHA':sha(O/'validation.json')},ensure_ascii=False,indent=2))
