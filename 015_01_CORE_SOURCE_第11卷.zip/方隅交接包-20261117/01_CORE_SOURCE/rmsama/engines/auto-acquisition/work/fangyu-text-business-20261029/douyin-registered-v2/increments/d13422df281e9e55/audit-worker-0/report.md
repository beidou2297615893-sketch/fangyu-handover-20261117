# 独立语义复核报告

本代理仅认领本批 part-0，逐页完整读取 7 页共享正文、788 条原评论及第一轮判断，对每个 key 显式作出 keep/change。使用同类已读 key 列表组织落盘，未按关键词程序代判，也未为未读剩余自动补 keep。

- 输入 788 条，输出 788 条；keep 723，change 65。
- 7 页输入输出 ID 顺序及集合完全一致，跨页没有重复或遗漏。
- 所有 first_semantic_judgment 与冻结 primary 对应字段一致。
- 本人逐字证据与所有结构化 quote 全量检查，错误 0；未引用异作者正文作为本人条件。
- 三个 primary SHA 与 task.json 完全一致，校验后未变化。
- 原判断加 patch 已形成真实隔离 JSONL，补隔离编译元数据后通过未修改 mother_adapter.validate_new_review 全量 788 条预检。
- adapter SHA 前后相同：fff622c0d202f0ddcd1c313723a81fa5efb1f555458f732a5ef9158fe7385cbd。

主要纠正：历史看过/住过与评论时现居混淆；裸地点及邀朋友短语过早认定求租；左右预算或近似面积被硬化；工作地点并未明说却被补定；环境和笼统品质错分设施；查看时间误计入住租期；低估明确本人找房或可租视频短询的线索；把一般想租提成超高；国外护照事实缺口不够具体。保留供给、搬离机会、主动代求租判断规则、购房用途、否定与备选方案及未知，不生成母句新正文。

代表条目：D0966 保留本人正在找房的线索；D1792/D2002 保留可租视频下米数短询但不确定分池；D1059/D1855/D2053 将一般想租降为高兴趣，未改明确看房时段或特定房订租的强动作；D1894 地点未直说工作地则保留角色未知；D1174 补搬离后的另找机会待核；D1993 补国外护照接待与登记事实缺口。

补丁字段分布：{"topics": 38, "reason": 26, "other_constraints": 4, "role": 18, "demand_state": 20, "interest": 23, "needs_review": 26, "reply_plan": 23, "target_regions": 14, "possible_topics": 1, "time_mentions": 3}。

## 隔离文件与绑定

- isolated-reviewed-part-0.jsonl SHA256：cefd99e91798ea4a7d47677a026e27f21883cba04a28a3d03a4fb21ebd1bb497
- isolated-bound-preflight-part-0.jsonl SHA256：d84845301bfd4f590c8d22ad427e9f22267a01e52dd17d2e352c681cc8162786
- validation.json 保留逐页 ID、输入输出 SHA、primary SHA 与正式预检结果。
- decisions.py 保留每组显式 key 和逐条 change；read_page.py 仅作无损缩写展示，validate.py 仅作确定性结构、引用和绑定校验。

仅写本 part 的 page-XX.audit.jsonl 和本 worker 目录。没有修改 primary、其他 part、总状态或总审计、adapter、产品，没有接触平台、源库、凭据、发送或创建新冻结。现有 credits 明确获准；实际 usage 未知。技术预检不等于用户认可、业务金标、正式发布或发送许可；协调者负责后续合并、编译与本地发布。
