import unittest
import local_delta_worker as worker


def record(text, **extra):
    return dict(comment_text=text, platform='douyin', comment_id='test', video_id='v',
                post_body='成都整租套二 #成都租房', post_author_same_as_commenter=False,
                reply_to='0', direct_parent_text=None, ip_location_raw='四川', **extra)


class Guards(unittest.TestCase):
    def test_explicit_purchase_kept_without_rental_reply(self):
        r = worker.decide(record('兄弟，找个价格合适的套二想买'))
        self.assertEqual(r['role'], 'purchase_demand')
        self.assertEqual(r['classification_stage'], 'local_completed')
        self.assertIsNone(r['mother_reply_text'])

    def test_purchase_negation_and_mixed_are_not_removed(self):
        for text in ['不想买', '买不起想租', '我不买房，只想租', '朋友想买', '他说想买', '“想买”']:
            self.assertEqual(worker.decide(record(text))['classification_stage'], 'uncertain_retained')

    def test_short_availability_is_not_automatically_high(self):
        r = worker.decide(record('真有吗'))
        self.assertEqual(r['interest_at_comment'], 'uncertain')
        self.assertTrue(r['needs_model_review'])
        self.assertIsNone(r['assigned_store'])

    def test_clear_self_rental_and_ambiguous_restrictions(self):
        self.assertEqual(worker.decide(record('求租成都一室公寓'))['role'], 'demand')
        for text in ['求租，不要中介', '我想租，帮父母找', '求租但已经找到', '求租明年入住']:
            r = worker.decide(record(text))
            self.assertEqual(r['classification_stage'], 'uncertain_retained')

    def test_parent_and_author_context_require_review(self):
        r = record('求租成都公寓'); r['reply_to'] = 'parent'
        self.assertTrue(worker.decide(r)['needs_model_review'])
        r['reply_to'] = '0'; r['post_author_same_as_commenter'] = True
        self.assertTrue(worker.decide(r)['needs_model_review'])

    def test_cache_binds_post_and_parent_not_just_words(self):
        r = record('真有吗')
        for field,value in [('post_body','别的正文'),('video_id','other'),('reply_to','parent')]:
            altered=dict(r); altered[field]=value
            self.assertNotEqual(worker.signature(r), worker.signature(altered))

    def test_source_conflict_cannot_use_cache(self):
        r = worker.decide(record('求租公寓',source_version_conflict=True),
                          {'role':'demand','interest_at_comment':'high','topics':[],'comment_id':'ref'})
        self.assertEqual(r['classification_stage'],'source_integrity_pending')
        self.assertIsNone(r['mother_reply_text'])


if __name__ == '__main__':
    unittest.main()
