"""Human-readable candidate report, written only inside the isolated package."""
import csv,json,pathlib,hashlib,collections,argparse
O=pathlib.Path(__file__).resolve().parent;ap=argparse.ArgumentParser();ap.add_argument('--bridge',default=str(O/'consumer-bridge-v1'));ap.add_argument('--output-dir',default=str(O/'isolated-consumer-check/corrected-human-report'));args=ap.parse_args();B=pathlib.Path(args.bridge).resolve();OUT=pathlib.Path(args.output_dir).resolve()
if O not in OUT.parents or O not in B.parents:raise ValueError('report and bridge must be inside package')
OUT.mkdir(parents=True,exist_ok=True)
cur=json.loads((B/'current.json').read_text(encoding='utf8'));summary=json.loads(pathlib.Path(cur['summary']).read_text(encoding='utf8'));platform_names={'douyin':'抖音','xiaohongshu':'小红书'}
labels={'housing_short_mother':'住房短句待审','clarification_only':'先确认需求待审','basic_pending':'基础稿待细化'}
report=['# 双平台文案准备情况（隔离审阅）','','本报告仅用于审核本地候选。模板版本仍待独立语义复核，文字尚未授权发送；住房、优惠和联系条件仍需核实。','','| 平台 | 已分类评论 | 高及超高意向评论 | 高及超高意向人数 | 已选中草稿 |','|---|---:|---:|---:|---:|']
counts=collections.Counter();files=[]
for platform,name in platform_names.items():
 s=summary['platforms'][platform];report.append(f"| {name} | {s['records']:,} | {s['high_super_high_comments']:,} | {s['high_super_high_unique_uids']:,} | {s['selected_local_mother']:,} |")
report+=['','下表只统计本轮历史候选；原有最新批次草稿另行保留，不与本表重复计数。确认接话用于先弄清需求，不代表已确认是住宅需求。','','| 平台 | 原选择 | 住房短句 | 确认接话 | 基础稿待细化 | 联系条件待核 |','|---|---|---:|---:|---:|---:|']
for platform,name in platform_names.items():
 for sel,label in [('selected','选中'),('alternative','备选')]:
  x=summary['platforms'][platform]['legacy_pool_candidates'][sel];report.append(f"| {name} | {label} | {x['housing_short_mother']:,} | {x['clarification_only']:,} | {x['basic_pending']:,} | {x['contact_review_required']:,} |")
report+=['','这些数量是草稿准备状态，不是独立逐条复核通过、可联系、已发送或客户成交数量。另有原来已选中的批次草稿保留。客户当前是否仍找房、实际账号住户身份、优惠资格、门店及房源事实均需另核。','']
for platform,name in platform_names.items():
 path=pathlib.Path(cur['results'][platform]);expected=cur['result_sha256'][platform];assert hashlib.sha256(path.read_bytes()).hexdigest()==expected
 outfile=OUT/(name+'历史候选草稿明细.csv');files.append(outfile)
 with outfile.open('w',encoding='utf-8-sig',newline='') as out,path.open(encoding='utf8') as inp:
  writer=csv.writer(out);writer.writerow(['客户评论','评论时需求状态','本地草稿','原选择','文案状态','联系条件','事实与发送状态'])
  for line in inp:
   r=json.loads(line);m=r.get('consumer_draft_metadata')
   if not m:continue
   kind=m['draft_type'];sel=m['selection'];counts[(platform,sel,kind)]+=1;reply=r.get('mother_reply_text') or r.get('alternative_mother_reply_text') or ''
   contact='联系条件待核' if m['contact_review_required'] else '仍需核对联系与发送条件'
   writer.writerow([r['comment_text'],'评论时有需求；当前需另核',reply,'选中' if sel=='selected' else '备选',labels[kind],contact,'住户身份、优惠、适用房源与发送状态需另核'])
 for sel in ('selected','alternative'):
  for k in labels:assert counts[(platform,sel,k)]==summary['platforms'][platform]['legacy_pool_candidates'][sel][k]
summaryfile=OUT/'双平台文案准备情况.md';summaryfile.write_text('\n'.join(report)+'\n',encoding='utf8');files.append(summaryfile)
receipt={'candidate_only':True,'semantic_gate_passed':False,'send_authorized':False,'source_current_sha256':hashlib.sha256((B/'current.json').read_bytes()).hexdigest(),'source_sidecars_sha256':{p:cur['result_sha256'][p] for p in platform_names},'files_sha256':{f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in files},'counts':{'|'.join(k):v for k,v in counts.items()},'old_report_claims_removed':True,'source_classifications_untouched':True}
(OUT/'报告核验.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n',encoding='utf8');print(json.dumps({'output':str(OUT),'files':[f.name for f in files],'counts':receipt['counts']},ensure_ascii=False))
