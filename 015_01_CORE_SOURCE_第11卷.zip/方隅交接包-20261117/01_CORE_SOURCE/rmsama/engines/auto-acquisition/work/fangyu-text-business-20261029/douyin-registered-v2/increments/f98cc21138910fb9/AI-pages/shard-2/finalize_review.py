import pathlib,json,hashlib,sys,collections
P=pathlib.Path(__file__).resolve().parent
B=P.parent.parent
W=B.parent.parent.parent
sys.path.insert(0,str(W))
import mother_adapter
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
adapter_sha=sha(W/'mother_adapter.py')
sources=[json.loads(l) for l in (B/'shard-2.jsonl').read_text(encoding='utf-8').splitlines()]
pages=[[json.loads(l) for l in (P/f'reviewed-{i:02}.jsonl').read_text(encoding='utf-8').splitlines()] for i in range(2)]
bykey={r['review_key']:r for page in pages for r in page}
assert len(bykey)==269==len(sources)
assert set(bykey)=={r['review_key'] for r in sources}
rows=[bykey[s['review_key']] for s in sources]
families=json.loads((B/'local-mother-contract.json').read_text(encoding='utf-8'))['families']
for src,row in zip(sources,rows):
 for k in ('review_key','platform','comment_id','customer_uid','video_id'): assert row[k]==src[k],(k,row['review_key'])
 own=src['comment_text']
 for x in row['topics']+row['target_regions']+row['time_mentions']+row['other_constraints']: assert x['quote'] in own,(row['review_key'],x)
 for q in row['evidence']: assert q in own
 for x in row['time_mentions']: assert x['anchor_time']
 plan=row['reply_plan']; lm=plan['local_mother']
 assert plan['preferred_mother_slot'] in (None,1,2,7,13,16,19,25,28,31,34)
 assert type(plan['generic_intro_suitable']) is bool
 if lm is None: assert plan['caution']
 else:
  assert lm['family'] in families
  assert set(lm['fill'])>=set(families[lm['family']]['required_fill'])
  assert all(isinstance(v,str) and v for v in lm['fill'].values())
  assert {e['field'] for e in lm['evidence']}==set(lm['fill'])
  assert all(e['quote'] in own for e in lm['evidence'])
  if lm['family']=='area': assert any(r['relation']=='desired' and r['text']==lm['fill']['place'] for r in row['target_regions'])
  if lm['family']=='commute': assert any(r['relation']=='work' and r['text']==lm['fill']['destination'] for r in row['target_regions'])
 assert row['human_confirmed'] is False and row['send_authorized'] is False and row['store_assignment'] is None
formal=B/'reviewed-new-2.jsonl'
formal.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows),encoding='utf-8')
# Preserve the exact first-write representation reproducibly. This is explicitly
# reconstructed from the original write logic, not falsely labelled a captured backup.
prior=json.loads(json.dumps(pages[0],ensure_ascii=False))
for row in prior:
 for mention in row['time_mentions']: mention['anchor_time']=None
 if row['review_key']=='D0270': row['reply_plan']['local_mother']['family']='weak_wish'
(P/'page-00-first-write-reconstructed.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in prior),encoding='utf-8')
(P/'revision-note.json').write_text(json.dumps({'page00_revision':'D0270原weak_wish会无证追问合租，细筛改topic_unspecified；已有可信发表时间补入time_mentions.anchor_time','first_write_representation':'按首次写入确定性逻辑重建，并非原始捕获备份','final_semantic_file':'reviewed-new-2.jsonl','independent_review_completed':False},ensure_ascii=False,indent=2),encoding='utf-8')
isolated=[]
for row in rows:
 x=dict(row)
 x['classification_method']='ai_semantic_initial_and_detailed'
 x['classification_stages_completed']=['initial_semantic','detailed_semantic']
 isolated.append(x)
iso=P/'isolation-review-source.jsonl'
iso.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in isolated),encoding='utf-8')
digest=sha(iso)
bound=[]; cache={}
for row in isolated:
 x=dict(row)
 x['classification_review_source']={'path':iso.relative_to(B).as_posix(),'sha256':digest}
 mother_adapter.validate_new_review(x,B,cache)
 bound.append(x)
(P/'isolation-bound.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in bound),encoding='utf-8')
assert sha(W/'mother_adapter.py')==adapter_sha
assert [bykey[r['review_key']] for r in rows]==rows
report={'shard':2,'input_count':len(sources),'output_count':len(rows),'pages':[len(p) for p in pages],'all_identity_fields_equal':True,'review_key_set_equal':True,'evidence_verbatim':True,'local_mother_explicit_each_row':True,'local_mother_families_valid':True,'page_union_equals_formal':True,'formal_order_equals_shard':True,'initial_semantic_completed':True,'detailed_semantic_completed':True,'independent_review_completed':False,'human_confirmed':False,'send_authorized':False,'platform_calls':0,'model_reply_rewrite_calls':0,'usage':'unknown','validator':'unmodified mother_adapter.validate_new_review','validator_passed':len(bound),'adapter_sha256':adapter_sha,'input_sha256':sha(B/'shard-2.jsonl'),'formal_review_sha256':sha(formal),'isolation_review_source_sha256':digest,'isolation_bound_sha256':sha(P/'isolation-bound.jsonl'),'role_counts':dict(collections.Counter(r['role'] for r in rows)),'interest_counts':dict(collections.Counter(r['interest'] for r in rows)),'local_mother_counts':dict(collections.Counter(r['reply_plan']['local_mother']['family'] if r['reply_plan']['local_mother'] else 'null' for r in rows)),'revisions':'page00更改已按首次确定性写入逻辑重建旧表示并明确标识；详见revision-note.json'}
(B/'shard-2-validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
(P/'progress.json').write_text(json.dumps({'shard':2,'completed_pages':[0,1],'comments_completed':269,'initial_semantic_completed':True,'detailed_semantic_completed':True,'independent_review_completed':False,'formal_preflight_pass':269,'platform_calls':0,'send_authorized':False,'usage':'unknown','status':'complete_for_parent_review'},ensure_ascii=False,indent=2),encoding='utf-8')
(B/'shard-2-report.md').write_text('''# 本片评论判读结果

269条评论已完成同轮AI初筛与细筛，两页分别为180条、89条，逐页记录与汇总一致。独立复核尚未执行，人工确认和发送授权均为否。

全部原始评论身份一致，逐字证据检查通过。每条均明确填写本地母句家族或null；按本人条件选池并填原词参数，无回复正文生成。问价与月租周期、办公与住宅、现住地与目标地、宠物主体、已看放弃与已租好均分别判断。

调用未修改的mother_adapter.validate_new_review，以真实隔离JSONL和SHA逐条绑定校验，269条通过。正式评审不伪造编译或独立复核状态；编译元数据只在隔离预检文件补入。SHA及数量见本片validation。

细筛时D0270从会无证追问合租的weak_wish改为topic_unspecified；时间提及补已有发表时间锚。首次页面表示按原确定性写入逻辑重建并如实标识，不冒称提前捕获备份。

仍需核当前找房状态、具体房源及全部同房硬条件、门店承接、真实住户介绍资格与优惠。评论时高兴趣不代表今天仍有效，不保证零遗漏。没有平台访问、发送、源库账号读取、新付费或其他片写入；credits实际usage未知。完成后交由主任务安排独立复核和本地发布，本片停止。
''',encoding='utf-8')
print(json.dumps(report,ensure_ascii=False))
