"""Plain-language exports from the verified current sidecar; never rewrites replies."""
import pathlib,json,csv,collections,shutil,hashlib
from short_reply_pipeline import load,jl,sha
B=pathlib.Path(__file__).resolve().parent;W=B.parent.parent.parent;ROOT=W.parents[1];OUT=ROOT/'outputs/方隅双平台文本业务';DETAIL=OUT/'地区归类与品牌母句';DETAIL.mkdir(exist_ok=True)
current=load(W/'region-brand-routing/current.json');summary=load(current['summary']);dy=summary['platforms']['douyin'];xhs=summary['platforms']['xiaohongshu'];p=load(B/'publication-verification.json');assert p['all_passed']
rr={platform:list(jl(path)) for platform,path in current['results'].items()};back=B/'preserved-business-exports';back.mkdir(exist_ok=True)
names={'douyin':'抖音','xiaohongshu':'小红书'}
levels={'super_high':'超高','high':'高','medium':'中','low':'低','very_low':'很低','uncertain':'信息不足待核','unrelated':'供给、讨论或已结束'}
states={'active_at_comment':'评论时有找房动作，当前另核','future':'未来计划','ended':'本人表示已结束','historical':'过去经历','unknown':'找房状态未说清',None:'旧记录状态待核'}
def backup(path):
 if path.exists():
  target=back/path.name
  if not target.exists():shutil.copyfile(path,target)
def write_text(path,text):backup(path);path.write_text(text,encoding='utf-8')
def region_note(r):
 wanted=r['explicit_desired_preferred_accepted']
 if wanted:return '客户明示：'+'；'.join(t.get('quote') or t.get('text') or '' for t in wanted)
 return '未明示住宅目标，评论IP仅作地区辅助' if r['original_ip'] else '客户住宅目标和评论IP均未明确'
def business_row(r):
 text=r['mother_reply_text'] or r['alternative_mother_reply_text'] or ''
 if r['mother_reply_text']:status='同平台同客户选中的待审草稿'
 elif r['alternative_mother_reply_text']:status='同客户备选，未重复入队'
 else:status='先核需求状态或适配，暂不生成接话'
 family='本批按需求池选的短句' if 'pool_short_mother' in r else '保留的历史基础句'
 needs=['当前是否仍找房待确认','实际位置、费用和房源条件尚需核实']
 if r['contact_policy'] in ('manual','manual_review','identity_restricted','unknown'):needs.append('联系身份或范围需人工确认')
 if r['contact_policy']=='no_contact':needs.append('本人有限制联系要求，不能直接联系')
 if r.get('timeline_review'):needs.append('同一客户的前后需求状态需人工核对')
 when='；'.join(t.get('quote','') for t in r['time_mentions']) or '未明确入住或租期'
 return [r['comment_text'],levels[r['interest_at_comment']],states.get(r['demand_state'],'状态待核'),r['original_ip'] or '原评论未提供',region_note(r),r['published_at'] or '发表时间未明',when,text,family,status,'；'.join(needs),'本地待审草稿，未授权本次发送']
headers=['客户评论','评论时意向','找房状态','评论IP属地','住宅地点依据','评论发表时间','入住或租期原话','当前回复草稿','草稿来源','准备状态','还需核实','本次发送权限']
for platform,rows in rr.items():
 for label,selected in [('高及超高意向明细',[r for r in rows if r['interest_at_comment'] in ('high','super_high')]),('选中母句明细',[r for r in rows if r['mother_reply_text']])]:
  path=DETAIL/(names[platform]+label+'.csv');backup(path)
  with path.open('w',encoding='utf-8-sig',newline='') as f:
   writer=csv.writer(f);writer.writerow(headers);writer.writerows(business_row(r) for r in selected)
region_tables=load(current['region_tables']);store_catalog=load(load(current['manifest'])['store_catalog'])['store_names_from_existing_catalog'];store_path=DETAIL/'十五家店共享地区候选.csv';backup(store_path)
with store_path.open('w',encoding='utf-8-sig',newline='') as f:
 writer=csv.writer(f);writer.writerow(['门店','城市共享池','抖音城市池高意向评论','抖音城市池去重人数','小红书城市池高意向评论','小红书城市池去重人数','省级待细分池','抖音省级池高意向评论','抖音省级池去重人数','小红书省级池高意向评论','小红书省级池去重人数','统计说明'])
 for store in store_catalog:
  city=next(c for c in ('上海','北京','杭州','成都','福州') if c in store);province={'杭州':'浙江','成都':'四川','福州':'福建'}.get(city);values=[]
  for loc in (city,province):
   for platform in ('douyin','xiaohongshu'):
    info=region_tables[platform][loc] if loc else {};values.extend([info.get('high_super_high_comments',0),info.get('unique_customer_uids',0)])
  writer.writerow([store,city,*values[:4],province or '直辖市',*values[4:],'同区域共享，不能把多家店相加；省级IP不当成城市；未确认具体门店承接'])
note='''# 本批新增评论处理说明

本次新增807条评论已完成AI初筛和细筛，其中682条经过独立语义复核。另对12条有分歧的地区询房作了定向裁决；这12条已包含在682条内，不能重复相加。模型判断和本地核验不代表人工逐条认可，也不保证客户今天仍在找房。

本批回复按客户的需求池选择短句，再填入原评论里的地点、预算、户型、设施、租期等条件。没有逐条调用AI重写整条回复。多条件同时保留，不把工作地点当住宅目标，不把月租价格当总租期，也不把待核房源写成已经有房。

| 本批回复状态 | 评论数 |
|---|---:|
| 可生成需求池短句 | 241 |
| 同平台同客户去重后选中 | 230 |
| 保留为同客户备选 | 11 |
| 先核需求、状态或接话适配，暂缓生成 | 566 |

暂缓不等于删除线索。中意向、地区未明、过去经历、供给、已结束及联系限制分别保留，具体原因和原评论仍可核对。

当前抖音已分类34840条评论，对应32831个客户账号，高及超高意向评论11236条。当前回复草稿共选中11567条，其中本批短句230条，历史基础句11337条。本次只调整新增807条的短句计划，没有把历史34033条全部重新改成需求池短句。

分类快照仍保留11504条原版基础草稿；当前回复又经过地区、状态及同客户去重整理，所以这个原稿数不等于当前选中数。历史原判断、原稿和未选中的备选均有保留。

小红书3601条分类和原IP旁注保持不变，仍有950条选中的基础草稿。原先124条定向补核继续保留；客户明示住宅地点优先，IP只作地区辅助，同区域多店共享线索，不按采集来源强行指派门店。

短句只是本地待审接话稿，实际房源、报价、优惠和介绍资格仍须核实。用户认可的是短句方向，不代表每一句新微调都已逐条认可。本次没有请求平台、发送评论、修改源库或新增付费，也没有开始下一批；平台真实发送状态仍以对应发送账本为准。
'''
write_text(OUT/'本批新增评论处理说明.md',note)
human=['# 双平台最新进度与地区回复说明','',note.split('\n',1)[1],'','## 当前平台快照','', '| 平台 | 已分类评论 | 高及超高意向评论 | 高及超高意向客户 | 当前选中回复草稿 |','|---|---:|---:|---:|---:|']
for platform,label in names.items():
 s=summary['platforms'][platform];human.append(f"| {label} | {s['records']} | {s['high_super_high_comments']} | {s['high_super_high_unique_uids']} | {s['selected_local_mother']} |")
human+=['','两平台分别记账，同一客户多条评论不会重复进入选中队列。评论时意向与今日需求分开核实；没有用旧日期、IP或来源门店直接删除客户。','','各平台的高意向明细和选中回复明细已按当前结果更新。原先单独给用户审口气的50条样稿未自动刷新。']
write_text(DETAIL/'双平台最新进度与地区母句说明.md','\n'.join(human)+'\n')
# Preserve the publisher's original snapshot report and add a plain clarification.
legacy=OUT/'抖音逐店采集与意向/最新已分析评论汇总.md';backup(legacy);text=legacy.read_text(encoding='utf-8');marker='当前回复说明：'
if marker not in text:text+='\n\n当前回复说明：上述母句稿数是分类快照保留的原稿。当前已选中的回复草稿为11567条，其中本批按需求池整理的短句230条，历史基础句11337条；另有本批同客户备选11条。详见“本批新增评论处理说明”。\n'
legacy.write_text(text,encoding='utf-8')
files=[OUT/'本批新增评论处理说明.md',DETAIL/'双平台最新进度与地区母句说明.md',store_path,*[DETAIL/(names[p]+label+'.csv') for p in names for label in ('高及超高意向明细','选中母句明细')]]
check={}
for path in files:
 if path.suffix=='.csv':
  with path.open(encoding='utf-8-sig',newline='') as f:data=list(csv.reader(f))
  check[path.name]=len(data)-1
assert check['抖音选中母句明细.csv']==11567 and check['小红书选中母句明细.csv']==950 and check['抖音高及超高意向明细.csv']==11236 and check['十五家店共享地区候选.csv']==15
(B/'business-export-verification.json').write_text(json.dumps({'all_passed':True,'files_sha256':{str(f):sha(f) for f in files},'csv_row_counts':check,'user_fifty_review_file_unchanged':True,'source_records_unchanged':True},ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps({'plain_language_exports_updated':True,'csv_rows':check},ensure_ascii=False))
