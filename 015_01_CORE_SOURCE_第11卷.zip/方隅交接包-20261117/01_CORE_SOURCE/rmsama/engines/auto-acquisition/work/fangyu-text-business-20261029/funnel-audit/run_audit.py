"""Freeze local evidence and reconcile the Douyin funnel without platform access."""
import argparse
from collections import Counter, defaultdict
from contextlib import closing
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import sqlite3
import sys
import time

HERE = Path(__file__).resolve().parent
WORK = HERE.parent
ROOT = WORK.parents[1]
STATUS = ROOT / 'work/fangyu-douyin-independent/classification-handoff-status.json'
sys.path.insert(0, str(WORK / 'recency-priority'))
import recency


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def rows(data):
    return [json.loads(line) for line in data.decode('utf-8-sig').splitlines() if line.strip()]


def sha(data):
    return hashlib.sha256(data).hexdigest()


def write(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding='utf-8')


def capture():
    for attempt in range(5):
        status = read(STATUS)
        pool = Path(status['commercial_fit']['all_pool_file']).read_bytes()
        replies = Path(status['output']).read_bytes()
        pending = Path(status['pending_candidates']).read_bytes()
        latest = read(STATUS)
        stable = (status['output_sha256'] == latest['output_sha256']
                  and sha(pool) == status['commercial_fit']['all_pool_sha256']
                  and sha(replies) == status['output_sha256']
                  and len(rows(pending)) == status['pending_candidates_count'])
        if stable:
            break
        if attempt == 4:
            raise RuntimeError('分类快照正在更换，暂不混合不同版本')
        time.sleep(0.3)
    folder = HERE / 'snapshots' / datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S-%f')
    folder.mkdir(parents=True)
    files = {'all-pool.jsonl': pool, 'replies.jsonl': replies, 'pending.jsonl': pending}
    for name, data in files.items():
        (folder / name).write_bytes(data)
    write(folder / 'status.json', status)
    statements = {
        'leads': "SELECT comment,customer,status FROM leads WHERE platform='douyin'",
        'reservations': "SELECT comment,customer,status FROM reservations WHERE platform='douyin'",
        'history': "SELECT comment,customer,delivery_state AS status FROM historical_deliveries WHERE platform='douyin'",
        'aliases': "SELECT alias,canonical FROM identity_aliases WHERE platform='douyin' AND verified=1",
    }
    with closing(sqlite3.connect((ROOT / 'work/shared-acquisition-ledger/shared.sqlite3').as_uri() + '?mode=ro', uri=True)) as db:
        db.row_factory = sqlite3.Row
        db.execute('BEGIN')
        ledger = {name: [dict(row) for row in db.execute(sql)] for name, sql in statements.items()}
        db.rollback()
    write(folder / 'ledger.json', ledger)
    write(folder / 'manifest.json', {
        'captured_at': datetime.now(timezone.utc).isoformat(),
        'classification_as_of': status['active_pool']['as_of'],
        'source_result_sha256': status['output_sha256'],
        'files': {name: sha(data) for name, data in files.items()},
        'executed_sql': statements,
        'source_database_read_only': True,
        'platform_requests': 0,
    })
    return folder


HARD_STEPS = [
    ('供给方、讨论或原分类明确非求租', {'not_supported_customer_demand'}),
    ('明确需求已结束', {'demand_ended'}),
    ('明确地区不适配', {'known_region_conflict'}),
    ('明确禁联或身份、品牌限制', {'contact_or_brand_restricted', 'contact_boundary', 'contact_identity_restricted'}),
    ('明确低预算或明显低价来源', {'whole_home_monthly_budget_below_3000', 'source_post_advertised_rent_below_3000'}),
    ('来源或时间异常', {'source_error_or_conflict', 'outside_douyin_active_30_day_window'}),
]
HOLD_NAMES = {
    'budget_3000_3999_requires_confirmation': '3000至3999元承接待核',
    'conflicting_budget_requires_confirmation': '预算相互冲突',
    'standalone_rental_amount_requires_confirmation': '金额用途不明',
    'low_amount_scope_or_ceiling_unverified': '低金额口径或上限不明',
    'source_post_low_rent_range_requires_confirmation': '来源价格范围待核',
    'demand_role_unverified': '本人求租身份待核',
    'demand_time_state_requires_confirmation': '计划时间或历史状态待核',
    'currentness_review_required': '需求当前性有具体疑点',
    'original_comment_text_missing': '缺少原评论文字',
    'contact_identity_requires_confirmation': '限定房东或个人身份，需核对回复账号',
    'public_reply_scope_requires_confirmation': '禁止私信，公开回复范围待核',
    'contact_scope_requires_confirmation': '联系渠道或具体限制待核',
}


def analyse(folder):
    status = read(folder / 'status.json')
    pool = rows((folder / 'all-pool.jsonl').read_bytes())
    replies = {row['comment_id']: row for row in rows((folder / 'replies.jsonl').read_bytes())}
    pending = {row['comment_id'] for row in rows((folder / 'pending.jsonl').read_bytes())}
    assert len(pool) == len({row['comment_id'] for row in pool})
    as_of = datetime.fromisoformat(status['active_pool']['as_of']).timestamp()
    assert all(recency.within_douyin_active_window(row, as_of) for row in pool)
    stages = []
    remaining = list(pool)

    def remove_stage(name, predicate, reason):
        nonlocal remaining
        removed = [row for row in remaining if predicate(row)]
        reasons = Counter(reason(row) for row in removed)
        stages.append({'layer': name, 'input': len(remaining), 'removed': len(removed),
                       'remaining': len(remaining) - len(removed), 'mutually_exclusive_reasons': dict(reasons)})
        removed_ids = {row['comment_id'] for row in removed}
        remaining = [row for row in remaining if row['comment_id'] not in removed_ids]

    for name, codes in HARD_STEPS:
        remove_stage(name, lambda row, codes=codes: bool(codes & set(row['commercial_fit']['exclusion_reasons'])),
                     lambda row, name=name: name)
    hard_count = len(pool) - len(remaining)
    remove_stage('业务条件待核，保留复核', lambda row: not row['commercial_fit']['eligible_candidate'],
                 lambda row: next((HOLD_NAMES[code] for code in row['commercial_fit']['verification_required'] if code in HOLD_NAMES), '其他条件待核'))
    business_pass = len(remaining)
    remove_stage('尚未进入回复明细，属于处理缺口', lambda row: row['comment_id'] not in replies,
                 lambda row: row['commercial_fit']['lead_intent_label'])
    remove_stage('已有明细但正文未备好', lambda row: not (replies[row['comment_id']].get('reply') or {}).get('draft_text'),
                 lambda row: (replies[row['comment_id']].get('reply') or {}).get('status', '正文待处理'))
    remove_stage('已发送、未知或占用，账本拦截', lambda row: replies[row['comment_id']]['delivery']['excluded_from_pending'],
                 lambda row: replies[row['comment_id']]['delivery']['status'])
    remove_stage('其他既有候选限制', lambda row: not replies[row['comment_id']]['pending_candidate'], lambda row: '需具体核对')
    assert {row['comment_id'] for row in remaining} == pending
    assert sum(stage['removed'] for stage in stages) + len(pending) == len(pool)

    ledger = read(folder / 'ledger.json')
    aliases = {row['alias']: row['canonical'] for row in ledger['aliases']}

    def canon(value):
        seen = set()
        while value in aliases and value not in seen:
            seen.add(value)
            value = aliases[value]
        return value

    uid_customers = defaultdict(set)
    by_comment = defaultdict(list)
    by_customer = defaultdict(list)
    pool_by_cid = {row['comment_id']: row for row in pool}
    events = ledger['leads'] + ledger['reservations'] + ledger['history']
    for event in events:
        by_comment[event['comment']].append(event)
        by_customer[canon(event['customer'])].append(event)
        original = pool_by_cid.get(event['comment'])
        if original and original.get('customer_uid'):
            uid_customers[original['customer_uid']].add(canon(event['customer']))

    counts = Counter()
    details = []
    for original in pool:
        row = dict(original)
        cid = row['comment_id']
        fit = row['commercial_fit']
        reply = replies.get(cid)
        hard = next((name for name, codes in HARD_STEPS if codes & set(fit['exclusion_reasons'])), None)
        history = list(by_comment[cid])
        keys = {canon(row.get('customer_uid') or '')} | uid_customers[row.get('customer_uid')]
        for customer in keys:
            history.extend(by_customer[customer])
        blocked = {event['status'] for event in history} & {'sent', 'unknown', 'reserved', 'accepted', 'platform_receipt_unverified'}
        if hard:
            group, why = '硬排除', hard
        elif blocked:
            group, why = '账本拦截', '已联系或结果未知、占用'
        elif not fit['eligible_candidate'] or fit['lead_intent'] == 'uncertain':
            group, why = '待核保留', '语义或条件待核'
        elif not reply or not (reply.get('reply') or {}).get('draft_text'):
            group, why = '回复待补', '业务条件可保留，正文尚未备好'
        elif cid in pending:
            group = '可排序低优先' if fit['lead_intent'] == 'medium' else '可排序优先'
            why = fit['lead_intent_label']
        else:
            group, why = '待核保留', '其他发送前限制'
        counts[group] += 1
        row.update(funnel_group=group, funnel_reason=why)
        details.append(row)
    assert sum(counts.values()) == len(pool)
    details.sort(key=lambda row: recency.priority_key(row, as_of))
    (folder / 'triage-details.jsonl').write_text(''.join(json.dumps(row, ensure_ascii=False) + '\n' for row in details), encoding='utf-8')
    sortable = [row for row in details if row['funnel_group'] not in ('硬排除', '账本拦截')]
    (folder / 'retained-sorted.jsonl').write_text(''.join(json.dumps(row, ensure_ascii=False) + '\n' for row in sortable), encoding='utf-8')
    result = {'classification_as_of': status['active_pool']['as_of'], 'rule_version': status['commercial_fit']['version'],
              'active_policy': status['active_pool']['policy'], 'raw_registered': status['eligible_registered'],
              'archived_outside_30': status['active_pool']['archived_outside_window'],
              'quarantined_dates': status['active_pool']['quarantined_dates'], 'active_count': len(pool),
              'layers': stages, 'business_hard_exclusions': hard_count, 'business_pass_count': business_pass,
              'actual_pending': len(pending), 'retained_groups': dict(counts), 'retained_sortable': len(sortable),
              'overlapping_hold_hits_not_additive': dict(Counter(code for row in pool for code in row['commercial_fit']['verification_required'])),
              'source_sha256': status['commercial_fit']['all_pool_sha256'], 'result_sha256': status['output_sha256'],
              'pending_sha256': sha((folder / 'pending.jsonl').read_bytes()), 'snapshot': str(folder),
              'network_requests': 0, 'source_or_receipts_modified': False}
    write(folder / 'audit.json', result)
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--snapshot', type=Path)
    args = parser.parse_args()
    folder = args.snapshot or capture()
    report = analyse(folder)
    write(HERE / 'current.json', {'snapshot': str(folder), 'audit': str(folder / 'audit.json'),
                                 'audit_sha256': sha((folder / 'audit.json').read_bytes())})
    print(json.dumps(report, ensure_ascii=False))
