"""Persist independent per-record review notes; does not change input or implementation."""
import json
from pathlib import Path
HERE=Path(__file__).resolve().parent
data=json.loads((HERE/'risk-focused-sample.json').read_text(encoding='utf8'))
notes={
'D1585':('pass','询问博主手机，与本人住房需求无关；不套母句合适。'),
'D2662':('pass','明确向博主询实习岗位；不能从博主正文租房经历移植本人住房需求。'),
'D4363':('recall_review','只有@他人，缺转发意图/父评论；可为分享租房攻略。建议unknown/uncertain留机会，无需生成稿；不能据此确认客户，但unrelated且无待核过强。'),
'D0757':('pass','给他人合同操作建议，主语你，不移植成本人找房或本人结束信号。'),
'D2365':('pass','明显展示房源获客的供给方，未见本人住房动作。'),
'D3622':('pass','评论他人签约纠纷，不是本人需求。'),
'D3619':('pass','给博主建议与评价，不是本人需求。'),
'D0334':('pass','问便宜房位置，保留uncertain合理；unknown不生成稿不等于删除机会。'),
'D1426':('pass','问博主房价/位置，未把1700当本人预算；待核保留正确。'),
'D0874':('pass','求北漂攻略可能有住房关注，但未明确本人找房；未知保留正确。'),
'D2800':('pass','空文本未知/联系未知；不凭正文构造需求。'),
'D3502':('pass','地名房型价格可能是供给也可能其他表达，保留未知；未把700当预算。'),
'D4990':('pass','想看余杭攻略可留潜在区域机会；未直接当已确认租住目标合理。'),
'D0388':('pass','对便宜房询问且抱怨租金，uncertain保留，没有直接排除。'),
'D3220':('pass','出租帖下催联系具有需求线索；高合理，原作者联系请求不等于本项目发送许可。'),
'D1699':('pass','本人指定地点询房；目标区域有本人证据。'),
'D2848':('pass','真实出租语境问价；保留高是可用口径，仍未确认当前需求或接受方隅。'),
'D5122':('pass','位置和价格双池正确，未照搬原帖价格和地址为本人条件。'),
'D1888':('pass','本人目标丰台和义正确；方隅可承接未核。'),
'D3082':('pass','油烟机、近地铁、丰台、2300是本人联立条件，不能跨房源拼满足；专项仅候选。'),
'D0424':('pass','将台+是否仍有房双池正确。'),
'D2644':('calibration','真假可保留中兴趣机会，但active_at_comment确定性偏强；补本人求租动作/真实性疑问待核，别自动当已推进。'),
'D3328':('pass','请求中介推荐是联系线索，保留中合理；不是已约看。'),
'D3190':('calibration','单字问仅表兴趣，保留中可接受，但具体诉求、本人求租状态应待核。'),
'D4627':('calibration','真实性疑问可留中兴趣，但不能据此确认本人正在找房；补状态不确定。'),
'D5296':('pass','嘉定租房语境求群可留中；需注意找群用途和真实求租状态仍未确认。'),
'D4954':('calibration','这房子还行仅评价，保留弱机会合理，active_at_comment需加本人动作待核。'),
'D5071':('pass','租房转租语境求群有潜在线索，保留中合理；求群不是向本账号授权。'),
'D2395':('pass','在哪我来看明确看房行动意向，超高有依据；不等于已确认预约或方隅地址匹配。'),
'D3922':('pass','1500我定了有价格条件和预定意向；未见已实际成交证据，不能当ended。'),
'D4780':('calibration','能看房吗仍是看房可行性询问；与pilot D0050口径一致应优先高/待核，超高不应被解释成已安排。'),
'D3655':('pass','留电话过去看看有明确下一步意向，超高可解释；仍无本项目许可或已确认预约。'),
'D3382':('pass','本人合同15号到期及条件性看房明确；时间锚在原评论，不能以旧日期判已租好。'),
'D3847':('pass','明天约看有明确时间和行动；原评论2025年的明天不变成现在明天，当前性待核。'),
'D3034':('calibration','想看看房仅意向，按pilot未确定安排则高的口径，应校准超高；保留客户及母句方向。'),
'D0526':('pass','本人转租受收费，mixed/uncertain保留换房可能；原文乱码未修造。'),
'D0766':('recall_review','本人合同正常到期且正处理押金，可能换房，现无证据确认新租也无证据排除；建议discussion或mixed保留uncertain并写后续住房待核，不强升高，不生成推销稿。'),
'D0919':('pass','室友离开而不想再合租，mixed/uncertain保留独居需求可能；2100等是转出房条件。'),
'D1129':('pass','本人急转租保留潜在后续需求，未把免费等供给条件计为找房条件。'),
'D1243':('pass','个人转租后续未知保留正确。'),
'D1495':('pass','个人转租后续未知保留正确。'),
'D1498':('pass','个人转租后续未知保留正确；你不一定能住未外推为全面禁联。'),
'D1510':('pass','医院附近住宿与费用压力明确；严肃通用接话可留，但租期和地区适配未核。'),
'D1900':('pass','送养狗而非本人宠物住房需求；家人身体不好不能机械变成租房需求。'),
'D2233':('pass','四人七天为住房条件，未因家庭语气拒绝；严肃通用稿可留，实际四人短租未核。'),
'D2602':('pass','本人转租且新住房未知保留；价格设施噪声属于供给房。'),
'D2896':('pass','因通勤远转租保留后续换房可能；广兰路为现居非目标地，正确。'),
'D2935':('pass','已私信原作者并催联系保留高；contact_boundaries明确不等于本账号许可，适配器会人工核。'),
'D2986':('pass','本人良渚求租明确；已加原作者不等于本账号许可，区域未从来源猜。'),
'D3418':('pass','因工作转租可能再租或离城，mixed/uncertain保留；原房宠物条件未移成本人新需求。'),
}
rows=[]
for record in data['records']:
    status,note=notes[record['key']]
    rows.append({'review_key':record['key'],'original_comment':record['comment'],'post_id':record['video'],'same_author':record['same_author'],'review_status':status,'finding':note,'original_interest':record['analysis']['interest'],'original_demand_state':record['analysis']['demand_state'],'original_preferred_mother_slot':record['analysis']['reply_plan']['preferred_mother_slot'],'source_modified':False})
out={'review_type':'Independent model risk-focused semantic spot check; not random accuracy measurement or human gold labels','reviewed_records':len(rows),'reviewed_all_shared_post_contexts':True,'zero_missed_customers_claimed':False,'scope_limits':['全部50条same_author=false，未覆盖同作者正文继承','本样本未覆盖明确ended时间线、identity_restricted、no_contact；相关代码合成行为与真实语义验收分开','没有独立全判其余5606条；没有确认全部批次已完成','专项母句均仅候选，实际草稿仅认可slot1；没有核实房源和优惠事实'], 'recall_review_keys':['D4363','D0766'],'calibration_keys':[r['review_key'] for r in rows if r['review_status']=='calibration'],'records':rows}
(HERE/'semantic-sample-review.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps({'reviewed':len(rows),'recall_review_keys':out['recall_review_keys'],'calibration_keys':out['calibration_keys']},ensure_ascii=False))
