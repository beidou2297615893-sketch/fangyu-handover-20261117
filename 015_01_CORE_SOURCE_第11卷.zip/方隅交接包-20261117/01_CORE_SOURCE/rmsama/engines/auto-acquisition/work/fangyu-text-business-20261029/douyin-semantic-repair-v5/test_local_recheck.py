import unittest
import local_recheck as local


class LocalRecheck(unittest.TestCase):
    def row(self, text, post='上海公寓出租，整租房源，可预约看房', **extra):
        return dict(comment_text=text, post_body=post, platform='douyin', reply_to='0', **extra)

    def test_direct_inquiries_and_shorthand(self):
        for text in ['多少米', '多少呀', '怎么联系', 'dd', '滴滴', '可以短租吗', '不合租的有吗', '能带猫吗', '哪个小区']:
            with self.subTest(text=text):
                got=local.decide(self.row(text))
                self.assertEqual(got['role'], 'demand')
                self.assertTrue(got['pools'])

    def test_own_request_not_rejected_for_negative_word(self):
        for text in ['我想租，不合租', '给父母找房，想找一居室', '我还在找房，没有合适的', '我想租，预算5000']:
            self.assertEqual(local.decide(self.row(text))['interest'], 'high', text)

    def test_supply_discussion_and_purchase_not_renter(self):
        for text in ['我这有空房，地理位置好', '本人出租一居室', '我有房出租', '我去年租了三千，太贵了', '我去年想租个房子，后来没有搬家', '想买一套房',
                     '这么便宜 我北京40平 1w', '我之前通过中介找的房，找到房东直租的了，房子还可以']:
            self.assertNotEqual(local.decide(self.row(text))['role'], 'demand', text)
        for text in ['猫猫太可爱了', '这个电梯真漂亮', '真的假的', '@朋友', '[赞][赞]', '我找了半天，最后决定租保租房了']:
            self.assertNotEqual(local.decide(self.row(text))['role'], 'demand', text)

    def test_context_and_numbers_are_not_guessed(self):
        self.assertEqual(local.decide(self.row('多少米', post='今天的衣服很漂亮'))['role'], 'unknown')
        self.assertEqual(local.decide(self.row('1300'))['role'], 'unknown')
        row=self.row('多少钱');row['reply_to']='123'
        self.assertEqual(local.decide(row)['role'], 'unknown')

    def test_ads_speaker_direction_advice_and_negation(self):
        for text in ['[群聊] 杭州求租转租房东群','我的车位80，所以一直不想换房子',
                     '还在找房子吗我这里房源挺多的要不要看一下','我这里房源很多 公寓 环境好 有想要租房的可以来找我啊',
                     '想租余杭区的单间 都私信我好吗 我这个月22号要走','有没有租我房子的4000一个月就行',
                     '想租三件套附近的话可以考虑看看洋泾那边','我知道你想要的房子在哪里',
                     '我觉得你挺介意有没有燃气 说明要自己做饭你后面中意的房子厨房太小',
                     '我房子就直租，后来才知道租客早想租了','有没有大佬给我房子的，房产证直接过户给我']:
            with self.subTest(text=text):self.assertNotEqual(local.decide(self.row(text))['role'],'demand')
        self.assertEqual(local.decide(self.row('我想租，最好房东直租，不合租'))['role'],'demand')
        row=self.row('多少钱');row['post_author_same_as_commenter']=True
        self.assertEqual(local.decide(row)['role'], 'unknown')

    def test_original_decision_is_preserved(self):
        row=self.row('我想租');row.update(role='unknown', interest_at_comment='uncertain')
        result=local.apply_decision(row,local.decide(row))
        self.assertEqual(row['interest_at_comment'],'uncertain')
        self.assertEqual(result['prior_local_recheck']['interest_at_comment'],'uncertain')
        self.assertEqual(result['interest_at_comment'],'high')

    def test_legacy_missing_reply_is_rechecked_not_unconditionally_approved(self):
        direct=self.row('我想去西海洪租房');direct.update(role='demand',interest_at_comment='medium')
        self.assertEqual(local.decide(direct)['role'],'demand')
        unclear=self.row('@朋友 咱们去杭州');unclear.update(role='demand',interest_at_comment='medium')
        decision=local.decide(unclear);decision['recheck_legacy_missing_reply']=True
        result=local.apply_decision(unclear,decision)
        self.assertNotIn(result['interest_at_comment'],('medium','high','super_high'))
        self.assertEqual(result['prior_local_recheck']['interest_at_comment'],'medium')


if __name__ == '__main__':unittest.main()
