"""Read-only independent verification of V1 -> delta and ABC -> cumulative equivalence."""
import pathlib,json,copy,hashlib,re,collections,string
O=pathlib.Path(__file__).resolve().parent;P=O.parent;W=P.parent;V=P/'legacy-release-repairs';F=P/'legacy-release-package/candidate-abc'
def load(p):return json.loads(pathlib.Path(p).read_text(encoding='utf8'))
def jl(p):return [json.loads(l) for l in pathlib.Path(p).read_text(encoding='utf8').splitlines() if l.strip()]
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def objsha(x):return hashlib.sha256(json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def key(x):return x['platform'],x['cid'],x['uid']
def project(x):return {k:x.get(k) for k in ('family','fill','evidence','clarification_only','hold_reasons','status')}
def put(p,x):pathlib.Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
m=load(O/'manifest.json');assert all(sha(p)==h for p,h in m['sources_SHA256'].items());assert all(sha(O/n)==h for n,h in m['outputs_SHA256'].items())
contract=load(O/'repair-contract.json');v1contract=load(V/'repair-contract.json');addon=load(O/'contract-addon.json')
assert all(contract['families'][name]==d for name,d in v1contract['families'].items())
assert {name:d for name,d in contract['families'].items() if name not in v1contract['families']}==addon['families']
abc={key(x):x for x in jl(F/'merged-plans.jsonl')};v1={k:copy.deepcopy(x) for k,x in abc.items()}
for ov in jl(V/'source-bound-plan-overlays.jsonl'):
 k=key(ov);assert objsha(abc[k])==ov['base_merged_plan_sha256'];v1[k].update(ov['replacement_plan'])
delta=jl(O/'incremental-plan-overlays.jsonl');cumulative=jl(O/'source-bound-plan-overlays.jsonl');clis=jl(O/'CLI-draft-body-overlays.jsonl');scans=jl(O/'all-6694-final-object-guard-scan.jsonl');regress=jl(O/'v1-and-final-review-regression.jsonl')
assert len({key(x) for x in delta})==len(delta)==len(clis);deltaidx={key(x):x for x in delta};cliidx={key(x):x for x in clis};v2={k:copy.deepcopy(x) for k,x in v1.items()};c2={k:copy.deepcopy(x) for k,x in abc.items()};counter=collections.Counter()
for d in delta:
 k=key(d);assert objsha(v1[k])==d['base_v1_applied_plan_sha256'];assert objsha(abc[k])==d['base_ABC_plan_sha256'];v2[k].update(d['replacement_plan']);assert not d['send_authorized'] and not d['can_send_now'] and not d['classification_changed'];counter['delta_parent_bindings_verified']+=1
assert len({key(x) for x in cumulative})==len(cumulative)
for c in cumulative:
 k=key(c);assert objsha(abc[k])==c['base_merged_plan_sha256'];c2[k].update(c['replacement_plan'])
for k in v2:assert project(v2[k])==project(c2[k])
cur=load(W/'region-brand-routing/current.json');sources={}
for plat,path in cur['results'].items():
 for x in jl(path):sources[x['platform'],x['comment_id'],x['customer_uid']]=x
def render(x,c):return c['families'][x['family']]['template'].format(**x['fill']) if x['family'] else None
for k,x in v2.items():
 r=sources[k];assert x['sourceSHA']==hashlib.sha256(r['comment_text'].encode()).hexdigest();assert x['original_classification_sha256']==objsha(r['source_record']);assert x['source_field_evidence']==v1[k]['source_field_evidence'];assert x['contact_policy_original']==v1[k]['contact_policy_original'];assert x['send_authorized'] is False and x['can_send_now'] is False
 if not x['family']:continue
 d=contract['families'][x['family']];assert set(x['fill'])==set(d['required_fill'])=={f for _,f,_,_ in string.Formatter().parse(d['template']) if f};text=render(x,contract);counter['all_6694_bound_render_field_checks']+=1
 for f,val in x['fill'].items():
  for span in val.split('、') if f=='requirements' else [val]:assert span in r['comment_text'] and any(e['field']==f and span in e['quote'] for e in x['evidence']);counter['literal_parameter_checks']+=1
 for f,val in v1[k]['fill'].items():
  for span in val.split('、') if f=='requirements' else [val]:assert span in text
 if k in deltaidx:
  cli=cliidx[k];assert cli['draft_body']==text and cli['draft_body_sha256']==deltaidx[k]['new_preview_sha256']==hashlib.sha256(text.encode()).hexdigest();assert cli['clarification_only'] is True and x['clarification_only'] is True and '？' in text;assert not re.search(r'我住方隅|介绍有优惠',text);assert cli['source_contact_policy']==v1[k]['contact_policy_original'];counter['CLI_body_and_clarification_metadata_consistent']+=1
 else:assert render(x,contract)==render(v1[k],v1contract);counter['unchanged_bound_CLI_drafts_byte_identical']+=1
for c in cumulative:
 text=render(c2[key(c)],contract);assert c['new_preview_sha256']==hashlib.sha256(text.encode()).hexdigest()
assert len(scans)==6694 and all(x['final_guard_executed_for_bound_path'] for x in scans)
for s in scans:
 if s['source_object_warning_quotes'] and not s['actual_context_residential_evidence']:assert s['body_contains_housing_purpose_question'] and not s['body_contains_promotion']
 temporal=[]
 for q in s['object_reference_scan']:
  if q['decision']=='temporal_or_period_reference_not_housing_object':temporal.append(q)
 if temporal:assert key(s) not in deltaidx
assert len(regress)==346
for q in regress:
 if not q['changed']:assert q['unchanged_draft_byte_identical'] is True
required=['7696414781808689957','6acf7c9f0000000008031dc0'];targeted=[]
for cid in required:
 cli=next(x for x in clis if x['cid']==cid);r=sources[key(cli)];ov=deltaidx[key(cli)]
 targeted.append({'cid':cid,'sourceSHA':cli['sourceSHA'],'source_comment':r['comment_text'],'v1_body':render(v1[key(cli)],v1contract),'v2_body':cli['draft_body'],'v2_clarification_only':True,'repair_reasons':ov['repair_reasons'],'contact_original_preserved':cli['source_contact_policy'],'send_authorized':False,'source_classification_changed':False})
c42=targeted[0]['v2_body'];assert all(s in c42 for s in ('这个','原帖','租金','位置','私聊联系你的事')) and not re.search(r'只要|只租|已经私信|已发送|只此|一套',c42)
short=targeted[1]['v2_body'];assert '你是在找住的房子吗' in short and '短租' in short and '多久' in short and not re.search(r'我住方隅|介绍有优惠|月租',short)
new5=[x for x in jl(V/'source-bound-plan-overlays.jsonl') if x.get('newly_bound_small_short_lease_addition')]
assert len(new5)==5
for x in new5:
 if x['cid']=='6acf7c9f0000000008031dc0':continue
 k=key(x);assert k not in deltaidx and render(v2[k],contract)==render(v1[k],v1contract);targeted.append({'cid':x['cid'],'sourceSHA':x['sourceSHA'],'v1_body':render(v1[k],v1contract),'v2_body':render(v2[k],contract),'positive_control_residential_context_unchanged':True})
# Existing 这套/type-reference/multi-action cases stay unchanged or preserve every old literal/action via object-only prefixing.
for cid in ('7594158042996851513','7658716647620379441','7665130906604061475','7469838306076410624','7622875857048617765'):
 k=next(k for k in v1 if k[1]==cid);targeted.append({'cid':cid,'sourceSHA':v1[k]['sourceSHA'],'v1_body':render(v1[k],v1contract),'v2_body':render(v2[k],contract),'existing_object_type_or_multi_action_regression':True,'unchanged':k not in deltaidx})
put(O/'targeted-two-fixes-and-positive-regressions.json',targeted)
result={'all_independent_structural_checks_passed':True,'source_or_v1_or_QA_byte_changes':0,'frozen_source_files_checked':len(m['sources_SHA256']),'incremental_delta_count':len(delta),'cumulative_overlay_count':len(cumulative),'ABC_then_cumulative_equals_V1_then_delta':True,'checks':dict(counter),'all_bound_paths_final_guard':6694,'old_v1_and_final_QA_regressions':len(regress),'targeted_two_cases_and_controls':len(targeted),'four_residential_new_short_cases_unchanged':4,'temporal_this_month_not_housing_reference':True,'semantic_population_accuracy_claim':False,'independent_semantic_recheck_pending':True,'source_current_pointer_sha256':sha(W/'region-brand-routing/current.json'),'manifest_sha256':sha(O/'manifest.json'),'new_direct_API_requests':0,'local_rendering_model_calls':0,'overall_agent_judgment_usage':'unknown','platform_calls':0,'send_attempts':0}
put(O/'independent-local-verification.json',result);print(json.dumps(result,ensure_ascii=False,indent=2))
