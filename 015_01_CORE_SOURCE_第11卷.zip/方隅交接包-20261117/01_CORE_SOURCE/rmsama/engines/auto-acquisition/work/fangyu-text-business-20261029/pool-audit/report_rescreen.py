import argparse,json,collections,csv,hashlib,os,sys
from pathlib import Path
W=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(W/'business-fit'))
import business_fit
OUT=W.parents[1]/'outputs/方隅双平台文本业务/筛选池复盘'
HIGH_OUT=OUT.parent/'全部高意向分池'
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
configs=[('抖音',read(W.parent/'fangyu-douyin-independent/classification-handoff-status.json')),('小红书',read(W/'recency-priority/xiaohongshu-source-priority-report.json'))]
parser=argparse.ArgumentParser();parser.add_argument('--platform',choices=['douyin','xiaohongshu']);args=parser.parse_args()
if args.platform:configs=[entry for entry in configs if entry[0]=={'douyin':'抖音','xiaohongshu':'小红书'}[args.platform]]
report={};verified=[];table=['# 本地交叉重筛结果','','按求租意愿、原评论时效和预算限制交叉判断。预算未写明时保留待确认标记，来源帖明确低价另作拦截。','','| 平台 | 本次核对记录 | 明确低预算 | 其他排除 | 其他待核 | 筛选后高意向 | 首次联系候选 |','|---|---:|---:|---:|---:|---:|---:|']
if args.platform:
 previous=W/'pool-audit/rescreen-audit.json'
 if previous.exists():report=read(previous)
 previous=W/'pool-audit/screened-high-intent.jsonl'
 if previous.exists():verified=[row for row in map(json.loads,previous.read_bytes().splitlines()) if row.get('platform')!=args.platform]
poollines=['','## 各需求池复盘','','同一评论可进多个池，不能相加当人数。','','| 平台 | 需求池 | 记录数 | 排除数 |','|---|---|---:|---:|']
for platform,status in configs:
 fit=status['commercial_fit'];path=Path(fit['all_pool_file'])
 assert hashlib.sha256(path.read_bytes()).hexdigest()==fit['all_pool_sha256']
 rows=[json.loads(l) for l in path.open(encoding='utf-8-sig')]
 if fit['version']!=business_fit.VERSION or args.platform=='douyin':
  for row in rows:row['commercial_fit']=business_fit.screen(row)
 low=sum('whole_home_monthly_budget_below_3000' in r['commercial_fit']['exclusion_reasons'] for r in rows)
 excluded=sum(r['commercial_fit']['candidate_state']=='excluded' for r in rows)
 high=[r for r in rows if r['commercial_fit']['eligible_priority']]
 verified.extend(high)
 HIGH_OUT.mkdir(parents=True,exist_ok=True)
 target=HIGH_OUT/(platform+'高意向分池明细.csv')
 tmp=target.with_suffix('.tmp')
 with tmp.open('w',encoding='utf-8-sig',newline='') as stream:
  writer=csv.writer(stream);writer.writerow(['客户原评论','筛选结果','月租预算下限','月租预算上限','预算状态'])
  for row in high:
   budget=row['commercial_fit']['budget']
   text=row.get('comment_text') or ''
   if text.lstrip().startswith(('=','+','-','@')):text="'"+text
   writer.writerow([text,row['commercial_fit']['lead_intent_label'],budget['monthly_minimum'],budget['monthly_maximum'],budget['state']])
 os.replace(tmp,target)
 unconfirmed=len(rows)-excluded-len(high)
 report[platform]={'核对记录':len(rows),'明确低预算':low,'其他排除':excluded-low,'待核或适配未证实':unconfirmed,'筛选后高意向':len(high),'高意向中预算4000档':sum(r['commercial_fit']['budget']['state']=='budget_at_least_4000' for r in high),'需求池':{},'结果文件':str(path),'sha256':fit['all_pool_sha256']}
 report[platform]['近期分级']=dict(collections.Counter(r['commercial_fit']['lead_intent_label'] for r in rows if r['commercial_fit']['eligible_candidate'] and r['commercial_fit']['eligible_priority']))
 queue_platform='douyin' if platform=='抖音' else 'xiaohongshu'
 pending=read(W/'recency-priority/daily-priority/current.json')['platforms'][queue_platform]['count']
 table.append(f'| {platform} | {len(rows)} | {low} | {excluded-low} | {unconfirmed} | {len(high)} | {pending} |')
 pc=collections.Counter();ec=collections.Counter()
 for r in rows:
  tags=r.get('pools') or r.get('topics') or (r.get('classification') or {}).get('pools') or (r.get('classification') or {}).get('topics') or []
  for p in set(x if isinstance(x,str) else x['pool'] for x in tags):
   pc[p]+=1;ec[p]+=r['commercial_fit']['candidate_state']=='excluded'
 for p,n in pc.items():
  report[platform]['需求池'][p]={'记录':n,'排除':ec[p]};poollines.append(f'| {platform} | {p} | {n} | {ec[p]} |')
table+=['','首次联系候选经过已有发送账本过滤，仍有预算/地区/当前性待核的普通咨询，不能称为已证实高意向。低价范围、分摊和开放上限无法确定时另留待核。','小红书本表覆盖已有分类快照，不代表全部采集记录已分类。','已发及未知回执未修改。发送窗口必须重新读取新版结果，消息送达不等于已切换。']+poollines
OUT.mkdir(parents=True,exist_ok=True)
visible_lines=['# 当前客户池','','| 平台 | 符合条件 |','|---|---:|']
for name,config in configs:
 source=Path(config['commercial_fit']['all_pool_file'])
 visible_count=sum(business_fit.screen(json.loads(line))['eligible_candidate'] for line in source.open(encoding='utf-8-sig') if line.strip())
 visible_lines.append(f'| {name} | {visible_count} |')
visible_lines+=['','仅30天内中、高、超高意向；未判清的在后台继续处理。']
(OUT/'本地重筛结果.md').write_text('\n'.join(visible_lines)+'\n',encoding='utf-8')
(W/'pool-audit/rescreen-audit.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
high_file=W/'pool-audit/screened-high-intent.jsonl'
high_bytes=''.join(json.dumps(row,ensure_ascii=False)+'\n' for row in verified).encode('utf-8')
tmp=high_file.with_suffix('.tmp');tmp.write_bytes(high_bytes);os.replace(tmp,high_file)
pointer={'scope':'screened_commercial_high_intent','business_fit_version':business_fit.VERSION,
         'results_file':str(high_file),'results_sha256':hashlib.sha256(high_bytes).hexdigest(),
         'stats':{name:data['筛选后高意向'] for name,data in report.items()},'not_a_send_queue':True,
         'historical_pool_file':str(W/'high-intent-pools-20261101/all-high-intent-pools.jsonl')}
if args.platform=='douyin':pointer['douyin_active_pool_policy']='douyin-active-30days-20261105'
target=W/'当前全部高意向分池指针.json';tmp=target.with_suffix('.tmp')
tmp.write_text(json.dumps(pointer,ensure_ascii=False,indent=2),encoding='utf-8');os.replace(tmp,target)
print(json.dumps(report,ensure_ascii=False))
