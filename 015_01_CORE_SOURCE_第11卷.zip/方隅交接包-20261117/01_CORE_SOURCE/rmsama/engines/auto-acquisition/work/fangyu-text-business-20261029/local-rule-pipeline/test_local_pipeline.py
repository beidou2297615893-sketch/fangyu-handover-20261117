"""Offline coordinator integration tests; all source databases are disposable."""
import hashlib
import importlib.util
import json
from pathlib import Path
import socket
import sqlite3
import tempfile
import unittest
from unittest.mock import patch

HERE = Path(__file__).resolve().parent

class StubClassifier:
    def __init__(self): self.calls = []
    def classify(self, record):
        self.calls.append(record)
        return dict(record, role='demand', demand_state='active_at_comment', interest_at_comment='high',
                    topics=['价格预算'], classification_method='local_rule', exception_type=None,
                    needs_model_review=False, model_calls=0)
    def choose_mother(self, result, mothers):
        return {'mother_slot': 1, 'mother_reply_text': mothers[0]['template']}

class PipelineTests(unittest.TestCase):
    def setUp(self):
        (HERE/'fixtures').mkdir(exist_ok=True)
        self.temp = tempfile.TemporaryDirectory(dir=HERE / 'fixtures')
        self.root = Path(self.temp.name); self.source = self.root / 'source.sqlite3'
        self.state = self.root / 'state'
        self.policy = self.root / 'policy.json'
        self.policy.write_text(json.dumps({'account_uid':'account', 'qualified_request_ids':['manual']}), encoding='utf8')
        self.mothers = self.root / 'mothers.json'
        self.mothers.write_text(json.dumps([{'slot':1,'user_approved':True,'template':'已认可母句'}]), encoding='utf8')
        db = sqlite3.connect(self.source)
        db.executescript('''CREATE TABLE entities(stable_key TEXT PRIMARY KEY,kind TEXT,source_id TEXT,first_request TEXT,data TEXT);
        CREATE TABLE attempts(request_id TEXT PRIMARY KEY,collected_at TEXT,spec TEXT,response TEXT,digest TEXT,state TEXT,detail TEXT,added INTEGER);
        CREATE TABLE observations(request_id TEXT,stable_key TEXT,scan_id TEXT,account_uid TEXT,store_id TEXT,keyword TEXT,kind TEXT,target TEXT,collected_at TEXT,data TEXT,PRIMARY KEY(request_id,stable_key));''')
        db.commit();db.close()
        self.classifier = StubClassifier()
        spec = importlib.util.spec_from_file_location('runner_under_test', HERE / 'run_local_pipeline.py')
        self.assertIsNotNone(spec)
        self.runner = importlib.util.module_from_spec(spec); spec.loader.exec_module(self.runner)
    def tearDown(self): self.temp.cleanup()
    def add(self, cid, uid='u', request='r', state='parsed', eligibility=None, account='account', text='想租房预算两千'):
        db=sqlite3.connect(self.source)
        spec={'kind':'comments','target':'v','account_uid':account,'eligibility':eligibility if eligibility is not None else {'state':'eligible'}}
        db.execute('INSERT OR REPLACE INTO attempts VALUES(?,?,?,?,?,?,?,?)',(request,'today',json.dumps(spec),'{}','',state,'',1))
        data=json.dumps({'cid':cid,'text':text,'aweme_id':'v','user':{'uid':uid},'create_time':100,'reply_id':'0'})
        db.execute('INSERT OR REPLACE INTO entities VALUES(?,?,?,?,?)',('comment:'+cid,'comments',cid,request,data))
        db.execute('INSERT OR REPLACE INTO observations VALUES(?,?,?,?,?,?,?,?,?,?)',(request,'comment:'+cid,'scan',account,'门店','租房','comments','v','today',data))
        db.commit();db.close()
    def run_pipeline(self, **kw):
        return self.runner.run_pipeline(source_db=self.source,state_dir=self.state,policy_path=self.policy,
            mothers_path=self.mothers,legacy_result=kw.pop('legacy_result',False),classifier=self.classifier,**kw)
    def test_late_parsed_is_not_lost_and_source_unchanged(self):
        self.add('1',state='unknown')
        before=hashlib.sha256(self.source.read_bytes()).hexdigest()
        self.assertEqual(self.run_pipeline()['newly_analyzed'],0)
        self.assertEqual(hashlib.sha256(self.source.read_bytes()).hexdigest(),before)
        db=sqlite3.connect(self.source);db.execute("UPDATE attempts SET state='parsed'");db.commit();db.close()
        before=hashlib.sha256(self.source.read_bytes()).hexdigest()
        self.assertEqual(self.run_pipeline()['newly_analyzed'],1)
        self.assertEqual(self.run_pipeline()['newly_analyzed'],0)
        self.assertEqual(len(self.classifier.calls),1)
        self.assertEqual(hashlib.sha256(self.source.read_bytes()).hexdigest(),before)
    def test_history_import_and_same_customer_platform_isolation(self):
        self.add('1');self.add('2');self.add('3',uid='other')
        legacy=self.root/'legacy.jsonl';legacy.write_text(json.dumps({'platform':'douyin','comment_id':'1','customer_uid':'u','interest_at_comment':'high','topics':[],'mother_reply_text':'旧母句'})+'\n',encoding='utf8')
        before=legacy.read_bytes()
        summary=self.run_pipeline(legacy_result=legacy)
        self.assertEqual(summary['snapshot_unique_comments'],3)
        self.assertEqual(summary['local_mother_drafts'],2)
        self.assertEqual(summary['method_counts']['historical_model_reference'],1)
        self.assertEqual(len(self.classifier.calls),2)
        self.assertEqual(legacy.read_bytes(),before)
        summary=self.run_pipeline(platform='xiaohongshu')
        self.assertEqual(summary['snapshot_unique_comments'],6)
        self.assertEqual(summary['local_mother_drafts'],4)
    def test_limit_manual_account_eligibility_shape_and_no_network(self):
        for i in range(5): self.add(str(i),uid=str(i))
        self.add('bad',request='manual',account='wrong',eligibility={'state':'no'})
        self.add('shape',request='shape',eligibility='eligible')
        with patch.object(socket,'socket',side_effect=AssertionError('network forbidden')):
            s=self.run_pipeline(max_new=2)
        self.assertEqual(s['newly_analyzed'],2)
        self.assertEqual(s['model_calls'],0);self.assertFalse(s['has_model_calls'])
        self.assertEqual(self.run_pipeline(max_new=2)['newly_analyzed'],2)
        self.assertEqual(self.run_pipeline(max_new=2)['newly_analyzed'],1)
    def test_dry_run_no_formal_state_and_export(self):
        self.add('1')
        self.assertEqual(self.run_pipeline(dry_run=True)['newly_analyzed'],1)
        self.assertFalse(self.state.exists())
        export=self.root/'all.jsonl';s=self.run_pipeline(export_all=export)
        self.assertEqual(len(export.read_text(encoding='utf8').splitlines()),1)
        self.assertTrue(Path(s['increment_file']).exists())
    def test_official_source_gate_and_verification_isolation(self):
        self.add('1')
        with patch.object(self.runner,'DEFAULT_SOURCE',self.source):
            with self.assertRaises(PermissionError): self.run_pipeline()
            self.assertFalse(self.state.exists())
            self.assertEqual(self.run_pipeline(verification_run=True)['newly_analyzed'],1)
            with patch.object(self.runner,'DEFAULT_STATE',self.state):
                with self.assertRaises(ValueError): self.run_pipeline(verification_run=True)
    def test_semantic_queue_has_three_examples_and_context_stays_separate(self):
        class Exceptions(StubClassifier):
            def classify(inner,record):
                result=super().classify(record)
                result.update(exception_type='compound_condition',needs_model_review=record['comment_id']!='context',rule_hits=['compound'])
                if record['comment_id']=='context': result['exception_type']='needs_context'
                return result
        self.classifier=Exceptions()
        for cid in ['a','b','c','d','context']: self.add(cid,uid=cid)
        summary=self.run_pipeline()
        self.assertEqual(summary['needs_model_review'],4)
        queue=[json.loads(x) for x in (self.state/'semantic-review-groups.jsonl').read_text(encoding='utf8').splitlines()]
        self.assertEqual(len(queue),1);self.assertEqual(queue[0]['count'],4)
        self.assertEqual(len(queue[0]['examples']),3)
        self.assertEqual(summary['local_mother_drafts'],0)
    def test_version_conflict_and_same_author_require_strict_uid(self):
        self.add('a')
        db=sqlite3.connect(self.source)
        data=json.dumps({'cid':'a','text':'different','aweme_id':'v','user':{'uid':'u'}})
        db.execute('INSERT INTO attempts SELECT ?,collected_at,spec,response,digest,state,detail,added FROM attempts LIMIT 1',('second',))
        db.execute('INSERT INTO observations SELECT ?,stable_key,scan_id,account_uid,store_id,keyword,kind,target,collected_at,? FROM observations LIMIT 1',('second',data))
        db.execute('INSERT INTO entities VALUES(?,?,?,?,?)',('video:v','search','v','r',json.dumps({'desc':'房源描述','author':{'uid':'u-other'}})))
        db.commit();db.close()
        summary=self.run_pipeline()
        self.assertEqual(len(self.classifier.calls),0)
        self.assertEqual(summary['exception_counts']['source_integrity'],1)
        result=json.loads(Path(summary['increment_file']).read_text(encoding='utf8'))
        self.assertFalse(result['post_author_same_as_commenter'])
        self.assertEqual(result['interest_at_comment'],'uncertain')
    def test_interrupted_export_is_recovered_without_reclassification(self):
        self.add('1')
        with patch.object(self.runner,'export_batches',side_effect=OSError('simulated output interruption')):
            with self.assertRaises(OSError): self.run_pipeline()
        summary=self.run_pipeline()
        self.assertEqual(summary['snapshot_unique_comments'],1)
        self.assertEqual(len(self.classifier.calls),1)
        db=sqlite3.connect(self.state/'derived.sqlite3')
        batches=db.execute('SELECT batch_id,exported FROM runs').fetchall();db.close()
        for batch,exported in batches:
            self.assertEqual(exported,1)
            self.assertTrue((self.state/'increments'/batch/'results.jsonl').exists())
    def test_repeated_historical_import_does_not_create_phantom_candidate(self):
        self.add('1')
        self.run_pipeline()
        legacy=self.root/'legacy.jsonl'
        legacy.write_text(json.dumps({'platform':'douyin','comment_id':'1','customer_uid':'different-user','mother_reply_text':'旧母句'})+'\n',encoding='utf8')
        summary=self.run_pipeline(legacy_result=legacy)
        self.assertEqual(summary['snapshot_unique_comments'],1)
        self.assertEqual(summary['local_mother_drafts'],1)
    def test_new_conflicting_observation_suspends_existing_candidate_without_reclassifying(self):
        self.add('1')
        self.assertEqual(self.run_pipeline()['local_mother_drafts'],1)
        self.add('1',uid='different-person',request='later')
        summary=self.run_pipeline()
        self.assertEqual(len(self.classifier.calls),1)
        self.assertEqual(summary['local_mother_drafts'],0)
        self.assertEqual(summary['source_integrity_audits'],1)
    def test_real_classifier_and_approved_mother_contract(self):
        from local_classifier import LocalClassifier
        self.classifier=LocalClassifier()
        self.mothers=HERE.parent/'mothers'/'first50.json'
        self.add('1')
        summary=self.run_pipeline()
        result=json.loads(Path(summary['increment_file']).read_text(encoding='utf8'))
        mother=next(x for x in json.loads(self.mothers.read_text(encoding='utf8')) if x['slot']==1)
        self.assertEqual(summary['local_mother_drafts'],1)
        self.assertEqual(result['mother_slot'],1)
        self.assertEqual(result['mother_reply_text'],mother['template'])
        self.assertEqual(result['reply_generation_model_calls'],0)
    def test_export_cannot_overwrite_source_or_historical_reference(self):
        self.add('1')
        before=self.source.read_bytes()
        with self.assertRaises(ValueError): self.run_pipeline(export_all=self.source)
        self.assertEqual(self.source.read_bytes(),before)
        legacy=self.root/'legacy.jsonl';legacy.write_text('{}\n',encoding='utf8')
        with self.assertRaises(ValueError): self.run_pipeline(legacy_result=legacy,export_all=legacy)
        self.assertEqual(legacy.read_text(encoding='utf8'),'{}\n')
    def test_real_family_mother_only_removes_approved_salutation(self):
        from local_classifier import LocalClassifier
        self.classifier=LocalClassifier();self.mothers=HERE.parent/'mothers'/'first50.json'
        self.add('1',text='我想租两室给父母住')
        summary=self.run_pipeline()
        result=json.loads(Path(summary['increment_file']).read_text(encoding='utf8'))
        template=next(x['template'] for x in json.loads(self.mothers.read_text(encoding='utf8')) if x['slot']==1)
        self.assertEqual(result['mother_reply_text'],template.removeprefix('宝宝，'))
    def test_historical_candidate_must_be_approved_and_have_live_demand_role(self):
        legacy=self.root/'legacy.jsonl'
        records=[]
        for cid,role,state,interest,text in [
            ('supply','supply','active_at_comment','high','已认可母句'),
            ('ended','demand','ended','high','已认可母句'),
            ('unrelated','demand','active_at_comment','unrelated','已认可母句'),
            ('unapproved','demand','active_at_comment','high','未认可旧句'),
            ('valid','demand','active_at_comment','high','已认可母句')]:
            records.append(dict(platform='douyin',comment_id=cid,customer_uid=cid,role=role,demand_state=state,
                                interest_at_comment=interest,mother_slot=1,mother_reply_text=text))
        legacy.write_text(''.join(json.dumps(x)+'\n' for x in records),encoding='utf8')
        original=legacy.read_bytes();summary=self.run_pipeline(legacy_result=legacy)
        self.assertEqual(summary['local_mother_drafts'],1)
        self.assertEqual(legacy.read_bytes(),original)
    def test_audit_deactivates_every_current_draft_alias(self):
        class Aliases(StubClassifier):
            def choose_mother(inner,result,mothers):
                return dict(mother_slot=1,mother_reply_text=mothers[0]['template'],draft_ready=True,
                            draft_text=mothers[0]['template'],slot=1)
        self.classifier=Aliases();self.add('1');self.run_pipeline()
        self.add('1',uid='other',request='later')
        export=self.root/'current.jsonl';self.run_pipeline(export_all=export)
        current=json.loads(export.read_text(encoding='utf8'))
        self.assertFalse(current['draft_ready']);self.assertIsNone(current['draft_text'])
        self.assertIsNone(current['mother_reply_text']);self.assertIsNone(current['mother_slot'])
        self.assertIsNone(current['slot'])
    def test_valid_json_wrong_shape_is_recorded_and_does_not_poison_later_comments(self):
        self.add('a');self.add('z',uid='valid',request='other')
        db=sqlite3.connect(self.source);db.execute("UPDATE entities SET data='[]' WHERE stable_key='comment:a'");db.commit();db.close()
        summary=self.run_pipeline()
        self.assertEqual(summary['snapshot_unique_comments'],2)
        self.assertEqual(summary['exception_counts']['source_integrity'],1)
        self.assertEqual(len(self.classifier.calls),1)
        self.assertEqual(self.run_pipeline()['newly_analyzed'],0)

if __name__=='__main__':
    (HERE/'fixtures').mkdir(exist_ok=True)
    unittest.main()
