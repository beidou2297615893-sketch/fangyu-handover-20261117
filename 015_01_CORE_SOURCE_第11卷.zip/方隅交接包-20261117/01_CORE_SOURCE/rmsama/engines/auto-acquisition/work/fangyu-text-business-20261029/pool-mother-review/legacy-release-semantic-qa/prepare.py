import json,pathlib,hashlib,collections,re,functools
O=pathlib.Path(__file__).resolve().parent; P=O.parent; W=P.parent
def load(p): return json.loads(pathlib.Path(p).read_text('utf-8-sig'))
def jl(p): return [json.loads(x) for x in pathlib.Path(p).read_text('utf-8-sig').splitlines() if x.strip()]
@functools.lru_cache(maxsize=None)
def sha(p): return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def can(x): return hashlib.sha256(json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def key(x): return (x['platform'],str(x.get('cid',x.get('comment_id'))),str(x.get('uid',x.get('customer_uid'))))
def put(n,x): (O/n).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n','utf-8')
def putjl(n,x): (O/n).write_text(''.join(json.dumps(y,ensure_ascii=False)+'\n' for y in x),'utf-8')
af=P/'legacy-local-planning-v2/local-proposed-plans.jsonl'; bf=P/'legacy-combo-families/source-bound-plans.jsonl'
cf=P/'legacy-local-planning-v2/local-mother-contract-v2.json'; base=W/'douyin-registered-v2/increments/f98cc21138910fb9/local-mother-contract.json'; addon=P/'legacy-combo-families/contract-addon.json'
exclude_files=[P/'legacy-local-planning/representative-review.jsonl',P/'legacy-short-preview/qa-v2/review-200.jsonl']
exclude={key(x) for f in exclude_files for x in jl(f)}
repfile=P/'legacy-combo-families/representative-validation.json'; reps=load(repfile)['cases']; exclude.update(key(x['plan']) for x in reps)
curfile=W/'region-brand-routing/current.json'; cur=load(curfile); sourcefiles=[pathlib.Path(f) for f in cur['results'].values()]
src={key(x):x for f in sourcefiles for x in jl(f)}
A=jl(af); B=jl(bf); ac=load(cf)['families']; bc={**load(base)['families'],**load(addon)['families']}
protected=[af,bf,cf,base,addon,curfile,*sourcefiles,*exclude_files,repfile,P/'legacy-combo-families/rendered-preview.jsonl',W/'rules/按池选母句与微调执行方式.json',W/'当前双平台回复结果指针.json']
before={str(f):sha(f) for f in protected}
chosen=[]; seen=set(); why={}
def add(group,p,reason):
 k=key(p)
 if k in exclude or k in seen:return
 chosen.append((group,p));seen.add(k);why[k]=reason
def order(rows):return sorted(rows,key=lambda p:hashlib.sha256(('|'.join(key(p))+'semantic-release-20261030').encode()).hexdigest())
# Cover every family still represented outside all development sets.
availB=[p for p in B if key(p) not in exclude]
for fam in sorted(set(p['family'] for p in availB),key=str):
 rows=order([p for p in availB if p['family']==fam]);
 for p in rows[:min(3,len(rows))]:add('B',p,'B family stratification, at most three per rare available family')
for p in order(availB):
 if sum(g=='B' for g,_ in chosen)>=60:break
 add('B',p,'B deterministic hash fill to 60; new versus B25 and all previous review IDs')
availA=[p for p in A if key(p) not in exclude and key(p) not in seen]
bound=[p for p in availA if p.get('family')]
for change in sorted(set(tuple(p.get('change_reasons',[])) for p in bound)):
 if change==('same_family_and_literal_fill; metadata_separated_only',):continue
 for p in order([p for p in bound if tuple(p.get('change_reasons',[]))==change])[:6]:add('A',p,'A v2 repair stratum '+str(change))
for fam in sorted(set(p['family'] for p in bound)):
 for p in order([p for p in bound if p['family']==fam])[:3]:add('A',p,'A family stratum '+fam)
# Unknown contact/platform and exact range/negative/time/metadata slices.
tests={
 'contact null':lambda p:p.get('contact_policy_original') is None,
 'xiaohongshu':lambda p:p['platform']=='xiaohongshu',
 'radius':lambda p:bool(re.search(r'公里|千米|半小时|分钟',src[key(p)]['comment_text'])),
 'OR':lambda p:bool(re.search(r'或者|或|还是',src[key(p)]['comment_text'])),
 'negative':lambda p:bool(re.search(r'不要|不合租|不考虑|不超|不想',src[key(p)]['comment_text'])),
 'spatial scope':lambda p:bool(re.search(r'附近|沿线',src[key(p)]['comment_text'])),
 'time':lambda p:bool(p.get('source_field_evidence',{}).get('time_mentions')),
 'template metadata caution':lambda p:any(c.get('kind')!='source_metadata_is_not_customer_requirements' for c in p.get('metadata_cautions',[])),
}
for name,test in tests.items():
 for p in order([p for p in bound if test(p)])[:10]:add('A',p,'A boundary stratum '+name)
held=[p for p in availA if not p.get('family')]
heldpatterns=[('5公里 radius',r'附近5公里|附近五公里'),('negative',r'不要|不合租|不想合租'),('OR',r'或者'),('lease',r'短租|租期'),('unresolved object',r'住的|干什么')]
heldchosen=[]
for name,rx in heldpatterns:
 for p in order([p for p in held if re.search(rx,src[key(p)]['comment_text'])])[:2]:
  if key(p) not in {key(x) for x in heldchosen}:heldchosen.append(p);add('A',p,'A held boundary '+name+' remains separate, not intent relabel')
for p in order(held):
 if len(heldchosen)>=10:break
 if key(p) not in {key(x) for x in heldchosen}:heldchosen.append(p);add('A',p,'A held scope remains separate; not intent relabel')
for p in order(bound):
 if sum(g=='A' for g,_ in chosen)>=140:break
 add('A',p,'A deterministic hash fill to 140')
assert len(chosen)==200,collections.Counter(g for g,p in chosen)
contexts={}; samples=[]
def sample(group,p,reason,index):
 k=key(p); s=src[k]; raw=s.get('source_record') or {}; cl=raw.get('classification') or raw; orig=s.get('original_raw_record') or {}; ctxkey=f"{k[0]}:{s.get('video_id') or s.get('note_id') or raw.get('video_id') or raw.get('note_id')}"
 ctx={'post_body':raw.get('post_body') or orig.get('post_text'),'post_title':raw.get('post_title') or orig.get('post_title'),'missing_context':orig.get('missing_context',[]),'source_file':str(next(f for f in sourcefiles if k[0] in f.name)),'source_record_key':list(k),'post_id':ctxkey.split(':',1)[1]}
 if ctxkey not in contexts:contexts[ctxkey]=ctx
 else:assert contexts[ctxkey]['post_body']==ctx['post_body'],ctxkey
 family=p.get('family'); render=(ac if group=='A' else bc)[family]['template'].format(**p.get('fill',{})) if family else None
 text=s['comment_text']; assert hashlib.sha256(text.encode()).hexdigest()==p['sourceSHA']; assert s['comment_text_sha256']==p['sourceSHA']
 return {'sample_index':index,'group':group,'platform':k[0],'cid':k[1],'uid':k[2],'comment_text':text,'source_comment_sha256':p['sourceSHA'],'plan_sha256':can(p),'plan_source_file':str(af if group=='A' else bf),'source_file':ctx['source_file'],'source_file_sha256':sha(ctx['source_file']),'context_key':ctxkey,'direct_parent_text':raw.get('direct_parent_text') or orig.get('parent_text'),'sampling_reason':reason,'family':family,'fill':p.get('fill',{}),'rendered_text':render,'source_role':s.get('role'),'source_state':s.get('demand_state'),'source_interest':s.get('interest_at_comment'),'source_topic_evidence':cl.get('topic_evidence',cl.get('topics',[])),'target_regions':cl.get('target_regions',s.get('target_regions')),'time_mentions':cl.get('time_mentions',s.get('time_mentions')),'other_constraints':cl.get('other_constraints'),'needs_review':cl.get('needs_review',[]),'source_blocking_reasons':raw.get('blocking_reasons',[]),'source_contact_policy':p.get('contact_policy_original',p.get('original_contact_policy')),'plan_contact_policy':p.get('contact_policy'),'source_contact_boundaries':raw.get('contact_boundaries',[]),'hold_reasons':p.get('hold_reasons') or p.get('unbound_reason'),'metadata_cautions':p.get('metadata_cautions',[]),'source_reply_missing_facts':s.get('reply_plan',{}).get('missing_facts',[]),'change_reasons':p.get('change_reasons',[]),'source_published_at':s.get('published_at'),'send_authorized':p['send_authorized'],'can_send_now':p['can_send_now']}
for i,(group,p) in enumerate(chosen,1):samples.append(sample(group,p,why[key(p)],i))
new_fams=set(p['family'] for g,p in chosen if g=='B'); missing=sorted(set(load(addon)['families'])-new_fams)
reg=[]
for fam in missing:
 p=next(p for p in B if p.get('family')==fam); reg.append(sample('B',p,'Regression only: every record for this family was already in B25 or other development/review IDs',len(reg)+1))
# Explicit prior brand/project example is not a new holdout.
for p in B:
 if key(p) in exclude and '朗芳园' in src[key(p)]['comment_text'] and key(p) not in {key(r) for r in reg}:
  reg.append(sample('B',p,'Regression only: explicitly requested other-project scope question',len(reg)+1));break
covered_changes={tuple(p.get('change_reasons',[])) for g,p in chosen if g=='A'}
for change in sorted({tuple(p.get('change_reasons',[])) for p in A if p.get('family')}-covered_changes):
 p=next(p for p in A if p.get('family') and tuple(p.get('change_reasons',[]))==change)
 reg.append(sample('A',p,'Regression only: all v2 change representatives excluded from fresh sample; '+str(change),len(reg)+1))
putjl('sample-200.jsonl',samples);putjl('regression-input.jsonl',reg);put('shared-contexts.json',contexts)
put('manifest.json',{'scope':'reply semantic fit only, not intent reclassification, not human labels or corpus accuracy','source_files_sha256_before':before,'sample_counts':dict(collections.Counter(x['group'] for x in samples)),'excluded_unique_IDs':len(exclude),'excluded_sources':[str(x) for x in [*exclude_files,repfile]],'new_holdout_combo_families':sorted(new_fams & set(load(addon)['families'])),'combo_families_only_available_as_regression':missing,'new_holdout_all_21_families_possible':False,'reason':'Previously developed B25 contains all records of these families; no eligible fresh row exists. They are separate regression, never included in 200.','sampling_seed':'semantic-release-20261030','selection_is_purposive_stratified_not_population_estimate':True,'usage':'unknown','API_calls':0,'platform_calls':0,'send_attempts':0,'source_writes':0,'pointer_changes':0})
print(json.dumps({'samples':len(samples),'counts':dict(collections.Counter(x['group'] for x in samples)),'regression':len(reg),'missing_new_families':missing,'context_count':len(contexts)},ensure_ascii=False))
