import json, pathlib, hashlib, collections, importlib.util, copy
P=pathlib.Path(__file__).resolve().parent
B=P.parent.parent
W=B.parent.parent.parent
sha=lambda raw:hashlib.sha256(raw).hexdigest()
srcraw=(B/'shard-1.jsonl').read_bytes()
src=[json.loads(x) for x in srcraw.decode('utf8').splitlines() if x.strip()]
source={x['review_key']:x for x in src}
pagefiles=[P/f'reviewed-{i:02}.jsonl' for i in range(9)]
assert all(f.exists() for f in pagefiles)
raw=b''.join(f.read_bytes() for f in pagefiles)
out=[json.loads(x) for x in raw.decode('utf8').splitlines() if x.strip()]
assert len(src)==len(out)==1460
ident=lambda r:tuple(r[k] for k in ('review_key','comment_id','customer_uid','video_id','platform'))
assert len({ident(r) for r in src})==len({ident(r) for r in out})==1460
assert {ident(r) for r in src}=={ident(r) for r in out}
pools={'价格预算','位置通勤','户型面积与居住方式','房内设施','宠物','楼层电梯','入住与租期','房源状态','费用合同','看房联系'}
quote_count=0
for r in out:
 s=source[r['review_key']]
 assert r['human_confirmed'] is False and r['send_authorized'] is False and r['store_assignment'] is None
 assert r['context_used']==['own','body']+(['parent'] if s['direct_parent_text'] is not None else [])
 if r['role']=='unknown':assert r['demand_state']=='unknown' and r['interest']=='uncertain'
 assert r['reply_plan']['preferred_mother_slot'] in (None,1,2,7,13,16,19,25,28,31,34)
 allowed=[s['comment_text']]+([s['post_body']] if s['post_author_same_as_commenter'] else [])
 for e in r['evidence']:assert any(e in a for a in allowed)
 for field in ('topics','target_regions','time_mentions','other_constraints','possible_topics','contact_boundaries'):
  for item in r[field]:
   if isinstance(item,dict) and item.get('quote') is not None:
    assert any(item['quote'] in a for a in allowed),(r['review_key'],field,item['quote'])
    quote_count+=1
 for t in r['topics']:assert t['pool'] in pools
 for pt in r['possible_topics']:
  candidates=pt.get('candidate_pools',pt.get('pools',[pt.get('pool')]))
  assert all(c in pools for c in candidates)
groups=collections.defaultdict(list)
for r in out:
 s=source[r['review_key']]
 groups[(s['video_id'],s['comment_text'],s['post_author_same_as_commenter'],s['direct_parent_text'],s['source_version_conflict'])].append(r)
contradictions=[v for v in groups.values() if len({(r['role'],r['demand_state'],r['interest']) for r in v})>1]
assert not contradictions
output=B/'reviewed-new-1.jsonl'
if output.exists():assert output.read_bytes()==raw,'refuse to overwrite different existing aggregate'
else:output.write_bytes(raw)
assert output.read_bytes()==raw
staged=[]
for r in out:
 q=copy.deepcopy(r)
 q['classification_method']='ai_semantic_initial_and_detailed'
 q['classification_stages_completed']=['initial_semantic','detailed_semantic']
 staged.append(q)
stagefile=P/'preflight-semantic-with-stages.jsonl'
stagebytes=''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in staged).encode('utf8')
stagefile.write_bytes(stagebytes)
digest=sha(stagebytes)
bound=[]
for r in staged:
 q=copy.deepcopy(r)
 q['classification_review_source']={'path':stagefile.relative_to(B).as_posix(),'sha256':digest}
 bound.append(q)
boundfile=P/'preflight-sha-bound.jsonl'
boundfile.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in bound),encoding='utf8')
adapter=W/'mother_adapter.py'
adaptersha=sha(adapter.read_bytes())
spec=importlib.util.spec_from_file_location('unmodified_mother_adapter',adapter)
mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
cache={}
checked=0
for r in map(json.loads,boundfile.read_text(encoding='utf8').splitlines()):
 mod.validate_new_review(r,B,cache)
 checked+=1
assert checked==1460 and sha(adapter.read_bytes())==adaptersha
validation=dict(batch=B.name,shard=1,input_count=len(src),output_count=len(out),pages=9,page_counts=[len(f.read_text(encoding='utf8').splitlines()) for f in pagefiles],input_unique_count=1460,output_unique_count=1460,identity_fields=['review_key','comment_id','customer_uid','video_id','platform'],id_sets_equal=True,page_concatenation_equal=True,evidence_verbatim_valid=True,structured_quote_count=quote_count,all_topic_pools_valid=True,same_context_core_contradictions=0,duplicate_context_groups=sum(len(v)>1 for v in groups.values()),adapter_full_validation_count=checked,adapter_errors=[],adapter_sha256=adaptersha,adapter_unmodified=True,real_isolated_source=str(stagefile),real_isolated_source_sha256=digest,real_isolated_bound_jsonl=str(boundfile),bound_sha256=sha(boundfile.read_bytes()),input_sha256=sha(srcraw),output_sha256=sha(raw),page_sha256={f.name:sha(f.read_bytes()) for f in pagefiles},role_counts=dict(collections.Counter(r['role'] for r in out)),interest_counts=dict(collections.Counter(r['interest'] for r in out)),state_counts=dict(collections.Counter(r['demand_state'] for r in out)),topic_counts=dict(collections.Counter(t['pool'] for r in out for t in r['topics'])),preferred_slot_counts=dict(collections.Counter(str(r['reply_plan']['preferred_mother_slot']) for r in out)),independent_audit_completed=False,human_confirmed=False,send_authorized=False,platform_calls=0,usage='unknown',publication_performed=False)
(B/'shard-1-validation.json').write_text(json.dumps(validation,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
progress=json.loads((P/'progress.json').read_text(encoding='utf8'))
progress.update(status='semantic_review_and_preflight_complete',completed_rows=1460,completed_pages=[f'{i:02}' for i in range(9)],adapter_validated=1460,publication_performed=False,independent_audit_completed=False)
(P/'progress.json').write_text(json.dumps(progress,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
report=f'''# 抖音分片判读报告

本分片1460条、9页已逐key完成AI语义初筛与细筛；仅处理已冻结本地文本。9页连接与正式汇总字节相同，原片1460组review_key、comment_id、customer_uid、video_id、platform身份集合完全一致，无缺项或重复。

已按每条本人评论和共享正文区分供需、生活展示关注、主动询租、已结束、历史经历、未来找房与未知。时间记录不锚分析当天，月租计价不当租赁总时长。地区来自本人原文，不按IP、采集门店或帖子作者条件补目标。身份限制保留原范围。多地点通勤、否定和条件范围、停车及费用合计等约束分别保留。

角色计数：{json.dumps(validation['role_counts'],ensure_ascii=False)}。
意向计数：{json.dumps(validation['interest_counts'],ensure_ascii=False)}。
找房状态计数：{json.dumps(validation['state_counts'],ensure_ascii=False)}。

逐字证据和结构化引文校验通过（结构化引文{quote_count}处）。片内同帖同文、作者身份、父评和来源冲突版本相同的核心判断冲突为0。17组模型裁决仅作语境参考，未当成人工金标。

正式mother_adapter.validate_new_review已对1460条执行真实隔离JSONL+SHA绑定全量预检，错误0；适配器代码未改。编译方法与阶段仅添加在片内隔离预检文件，正式语义汇总未加编译元数据，后续应由协调者compiler实际绑定。原片SHA256：{validation['input_sha256']}；汇总SHA256：{validation['output_sha256']}。详细页和隔离SHA见shard-1-validation.json。

回复只提供认可槽位及适配计划，没有新写回复正文。专项与通用介绍的住户、优惠、权限、房型、价格、租期、地区及有效房源事实仍待核。所有human_confirmed=false、send_authorized=false、store_assignment=null。模型初细筛不等于独立复核或人工认可，也不证明当前需求或方隅库存有效。

使用本地专用契约、纠偏与认可母句；参考已读社交销售Skill中导出数据边界和完成前验证Skill。没有平台调用、源库/凭据读取、发送、购买、新批冻结、全局写入、合并或本地发布。credits沿用已授权范围；任务实际usage未知，未用任务数或余额差额估算费用。

完成后停止，由shard0协调者安排独立审计与本地发布。
'''
(B/'shard-1-report.md').write_text(report,encoding='utf8')
print(json.dumps({k:validation[k] for k in ('input_count','output_count','page_counts','id_sets_equal','page_concatenation_equal','evidence_verbatim_valid','same_context_core_contradictions','adapter_full_validation_count','adapter_errors','output_sha256','role_counts','interest_counts')},ensure_ascii=False,indent=2))
