import json, pathlib, hashlib, collections, datetime
D=pathlib.Path(__file__).resolve().parent
j=json.loads((D/'input.json').read_text(encoding='utf-8-sig'))
rows=json.loads((D/'initial-semantic.json').read_text(encoding='utf-8'))
# Detailed semantic pass: a future occupancy time does not establish deferred search start.
rows[1]['demand_state']='unknown'
rows[1]['contact_policy']='manual_review'
rows[1]['reason']='“过阵子要租房”确定未来租住计划；已经去干中介是现时行为，却未说明本人现在找房还是到时才找，需求状态留未知，不把将来入住机械当未来才找。'
rows[1]['needs_review']=['何时开始为自己找房、做中介是否已包含自用找房；从业身份和本人需求分开，原medium保持不变']
rows[83]['demand_state']='unknown'
rows[83]['contact_policy']='manual_review'
rows[83]['reason']='“明年四月租”说明2027年4月租住计划，未说明现在已开始找，亦未明确未来才开始；按找房时点保留未知，未来计划没有失效。'
short={
7:'2500左右，能不能租到一室一厅，或者大单间能做饭的',
12:'我们就是打算明年或者后年找个毛坯房，简装入住',
26:'有没有女生一起合租？我会做饭，但是希望对方爱干净',
36:'有没有长宁区一起合租的男女不限',
45:'有没有宝山杨浦静安附近的房子',
71:'有推荐好的小区吗，预算1000左右',
79:'附近 有房子么。单间带卫生间的。',
102:'感觉我们以后可以找一个这种的你一户我一户',
123:'同找阁楼，要求安静，独卫，能做饭',
}
# Original review uncertainty is preserved when it refers to evidence not present in the supplied packet.
unread={2:'原AI记有1条深层回复未读取，本包无该回复，后续结果未知',4:'原AI记有5条深层回复未读取，本包无该回复，后续结果未知',8:'原AI记有下级回复未读取，本包无该回复，后续结果未知',9:'原AI记有下级回复未读取，本包无该回复，后续结果未知',10:'原AI记有下级回复未读取，本包无该回复，后续结果未知',14:'原AI记有下级回复未读取，本包无该回复，后续结果未知',15:'原AI记有下级回复未读取，本包无该回复，后续结果未知',19:'原AI记有下级回复未读取，本包无该回复，后续结果未知',31:'原AI记有下级回复未读取，本包无该回复，后续结果未知',45:'原AI记有下级回复未读取，本包无该回复，后续结果未知',49:'原AI记有下级回复未读取，本包无该回复，后续结果未知',55:'原AI记有下级回复未读取，本包无该回复，后续结果未知',56:'原AI记有5条深层回复未读取，本包无该回复，后续结果未知',59:'原AI记有下级回复未读取，本包无该回复，后续结果未知',63:'原AI记有下级回复未读取，本包无该回复，后续结果未知',64:'原AI记有下级回复未读取，本包无该回复，后续结果未知',65:'原AI记有下级回复未读取，本包无该回复，后续结果未知',71:'原AI记有下级回复未读取，本包无该回复，后续结果未知',78:'原AI记有下级回复未读取，本包无该回复，后续结果未知'}
for n,(r,x) in enumerate(zip(j['records'],rows),1):
    if n in short:x['evidence']=[short[n]]
    if n==12:x['evidence'].append('因为打算带小孩过来读书，准备找个这样的房子长期租')
    if n==45:x['evidence'].append('我不需要靠近地铁站的')
    if n==71:x['evidence'].append('接受地铁通勤20分钟以内的，然后希望不要往西湖去')
    if n==123:x['evidence'].append('其他地方也行')
    if x['generic_intro_suitable']:
        x['reason']+='认可通用介绍可接话；不表示已答具体询问、已核房源或已获发送授权。'
    x['needs_review'].append('评论后的需求或计划变化及现在是否仍找房未核；此处状态仅针对评论时点')
    if n in unread:x['needs_review'].append(unread[n])
    # Do not relax inherited restrictions even if generic sentence fits.
    rp=r['original_AI'].get('reply_plan',{})
    if rp.get('contact_policy') in ('no_contact','manual_review','manual'):
        x['contact_policy']='no_contact' if rp['contact_policy']=='no_contact' else 'manual_review'
        x['needs_review'].append('保持原AI联系限制，不因本次通用介绍适配而解除')
    x['stages_completed']=['initial_semantic','detailed_semantic']
    x['input_sha256']='c44b4a65cf9f27f2614ef754e739b695ee90c7f9cc1822bcd2bb66debcb06e91'
    assert all(q in r['comment_text'] for q in x['evidence'])
(D/'reviews.jsonl').write_text(''.join(json.dumps(x,ensure_ascii=False,separators=(',',':'))+'\n' for x in rows),encoding='utf-8')
print(json.dumps({'demand_state':dict(collections.Counter(x['demand_state'] for x in rows)),'generic_intro_suitable':dict(collections.Counter(x['generic_intro_suitable'] for x in rows)),'contact_policy':dict(collections.Counter(x['contact_policy'] for x in rows)),'tone':dict(collections.Counter(x['tone'] for x in rows))},ensure_ascii=False))
