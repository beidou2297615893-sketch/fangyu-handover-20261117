# SDD ledger — plan: local-rule-pipeline/PLAN.md

Goal: 本地规则优先、准确性优先的百万级文字链路，普通评论不逐条调模型，语义疑难集中复核。

Ruling: 用户已详细授权现行分类、母句方案并要求直接检查跑通继续；本阶段不再询问常规设计选择。沿用Python/SQLite离线流程，不改软件客户端或平台操作。

Ruling: 用户明确默认不建工作树，输出属于当前项目离线文字目录；使用项目work下独立文件与派生库，不创建Git工作树、不提交既有用户文件、不推广其他客户。

Ruling: 后续软件可接DeepSeek等廉价模型，但当前不新增付费API调用。先记录真实本地覆盖、疑难量、模型usage可得性，不能用虚假准确率或费用做路由依据。

Preflight: GitHub CLI未登录，按agent-reach开发路由转公开GitHub主仓库与PyPI元数据。pyahocorasick 2.3.1、BSD-3-Clause、非归档、Windows CPython3.12 wheel已核实并安装到项目vendor；FlashText只对比未安装。

Historical baseline: 95a批已收尾，累计12409条模型初判、2692条本地母句稿，未动源库/发送。后续停止整批逐条模型分类，心跳已改成本地链路验收门。

Task1: local_rules_core 编写规则核心/母句/反例测试，in_progress。
Task2: local_rules_runner 编写只读源+派生SQLite流式协调器/幂等测试，in_progress。
Task3: local_rules_acceptance 已机械冻结200条未读历史参考样本；独立反例/百万合成压测准备中。参考不是人工gold，代码冻结前不用于调词。

Software handoff: 经本人本轮明确授权，已一次发送给「代码与功能整合」；准确优先、本地规则+集中疑难、未来DeepSeek/实际usage、增量幂等、不重启部署或停采。未向其他窗口发消息。

Task1: 核心39个自测通过，独立52业务反例46通过、6不通过；200留出仍未读。fix round1进入，问题包括帮人找出租房误判供给、明确需求/状态询盘词覆盖不足。不得改期望迁就实现；歧义场景可待核，不可无据确定供给。
Task2: 协调器独立审查0Critical/3Important，fix round1进入：旧母句候选准入、冲突后全部稿状态别名一致、毒JSON不得堵后续条目；补export目标等于采集源路径的拒绝保护。审查早于作者最终自审形成源码漂移，后续以封版SHA复审，不并发改同文件。
Evidence: 活动采集源可由采集窗口继续更新，不能用本次活库物理SHA变化冒称本模块写源；以mode=ro/query_only/total_changes=0、固定隔离源SHA和覆盖路径负向测试核对。

Task2: fix round1/5 完成，原3Important均ADDRESSED，源/历史同路径导出保护通过；冻结runner debb6b1e...，tests 99dfce30...；独立复审未发现修复新问题。正式manifest尚未开启。
Task1: fix round1/5 原6项已修，52反例独立复测全过；新增两例揭示“能带猫”误填owns_pet=true，进入fix round2。200留出仍未读，核心fix2与独立代码审查后再启封。

Task1: fix2宠物字段经52+2反例通过；fix3六类原Important均ADDRESSED，但相邻修复新发现历史范围跨句导致当前明确求租/约看被误当历史，进入round4，按规则升级新实现者Astra。
Task3: 核心百万合成吞吐19.118秒/4进程、零模型；此为合成分类器测试，不是实际准确率或端到端百万源库验证。200历史参考已启封，本地确定30、needs_context170、语义复核0；角色相同71、意向相同69，旧模型不是人工gold。
Ruling: 纯规则当前覆盖不足，不应凭速度启用全量替代；200条中均有正文，不能把未覆盖一概叫资料缺失。遵循用户最新准确优先和允许低成本模型的口径，改为稳定规则/缓存本地、未覆盖场景同帖共享上下文批量短标签模型辅助、母句全本地。当前不接付费API；先做可核对的紧凑批请求/结果应用，实际usage缺失如实标未知。已暴露200参考今后只作回归，后续改规则不再称其独立验证。

Ruling superseded by latest user: 不使用纯规则版；所有合格新增评论初筛、细筛均由AI判断，母句仍本地。停止纯规则修复/上线流程，保留实验与历史证据。普通额度已100%，ordinaryUsageAllowed=false，有现有credits但尚未获新增批量消费选择；5806条已冻结、未派工，等待额度选择，不造已完成回执。
