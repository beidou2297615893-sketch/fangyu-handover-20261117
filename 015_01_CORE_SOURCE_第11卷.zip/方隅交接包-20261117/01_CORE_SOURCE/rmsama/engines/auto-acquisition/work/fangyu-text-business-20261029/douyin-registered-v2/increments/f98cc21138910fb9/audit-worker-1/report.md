# part-1 独立语义复核交接

已逐页读完本 part 三页共 341 条共享正文、原评论和初次语义判断。每个 key 均在 decisions.tsv 显式记录 keep/change 与中文理由，没有默认补齐剩余 keep，也没有程序关键词代判。

当前状态是 **已复核并通过真实隔离预检，4 条重要意向口径待 root 裁决**。按本批协调者 /root/dy_807_primary_0 的停止指令保存现场后停止，不等待占用活跃代理。未合并、未发布，未写任何正式 page-XX.audit.jsonl。不是业务最终验收或用户金标。

## 显式决定及待裁决范围

- 341 条显式决定：311 keep，30 change；其中 4 条 change 是暂存提案，尚未最终裁决，其余为 311 keep 与 26 条修改。
- 待裁决 key：D0183、D0393、D0402、D0798。问题是无明确库存的租房攻略或生活分享下，“指定地区有无房源”的短询能否直接判高兴趣。本地暂存 medium，保留 demand、active_at_comment、本人地区及 area 计划，未删除需求。
- 对照证据：D0002“朝阳东坝有吗”原 medium；D0183“滨江区有无”、D0393“西溪谷数智产业园有吗”、D0402“钱塘区有没有”、D0798“滨江有吗”原 high；D0800“临平有这样的吗”同现居分享原 medium。须根据本人动作及实际正文裁决，不能按多数票，也不能仅按日记标题统一压低明确求租。
- 这些评论已全部读过并有明确暂存提案，缺的是关键口径裁决；不能将隔离文件的兼容元数据当作四条已最终通过或已发布。

## 主要复核修改

- 同一生活或看房分享下，部分同类简短问价/位置原为 active、其他为 unknown。D0110、D0116、D0245、D0251、D0164、D0287、D0470、D0476、D0503、D0515 保留中兴趣及原候选母句，改为找房动作未知，并补具体待核提醒。
- D0125“川沙地铁旁边有哇”可能是在提供房源或询问，改供需未知、意向不确定、地区 unresolved，明确 local_mother=null 待核。
- D0054 为本人看过房的收费经历，不能把它标成别人的条件。改需求机会待核，收费主题主体 unresolved，仍明确 null 计划，不把该收费当新房硬条件。
- D0004 保留因贵打消租房念头的结束判断，去掉不适当的入住租期池；D0664 住了三个月为过去已住时长，改时间角色 other。
- D0194 requirements 补“工作地方在奥克斯时代之城”，保留余杭区、1000到1500左右；D0562 补“工作在高新这边”，保留正规干净套一及租贵的价格负担语境。工作地均未改成 desired。
- D0068 保留上海、短租和一个月；D0298 补带图来并保留入职急迫、预算3000、近徐汇、朝南及可合租；D0407 保留这个1400、马上签合同，但未声称已签成。
- D0620 保留“合租吗”的问句范围与想看房；D0662 保留联系看房目的；D0776 保留每月价格与联系；D0791 保留免费住疑问及资格、免租时长和收费待核，不套用源帖免租事实。
- D0693 增加提醒：噪音异味为现居搬家原因，不冒充已确认的新房硬指标；富阳只为现居地。
- D0716 一般租金行情查询未证明住宅目标，改 medium、动作未知及地区 unresolved。D0523 探访问空调暖气留 medium 设施关注和可租性待核。
- D0730 地铁直达徐家汇站及30-40分钟已完整保留在 requirements，未当住宅地区或无证工作地。

所有替换 reply_plan 都从原对象完整复制，仅改明确指定字段；local_mother 每条显式对象或 null。供给、讨论、结束、未知、混合和不宜接话没有强推母句；原联系限制、缺口、角色、否定范围均保留。只写家族与字面参数计划，未写回复正文。

## 实际验证

build_audit.py 从真实原判断复制并套显式补丁，在本目录写 isolated-reviewed.jsonl。仅在该隔离文件中补结构预检元数据，再给每个 candidate 绑定该真实文件路径与实际 SHA，使用未修改的 mother_adapter.validate_new_review，未使用伪内存源冒充文件验证。

- 原适配器全量通过 341/341。
- task、三页来源与本 part key 集合相等：341，无跨页重漏；review_key、comment_id、customer_uid、video_id、platform 与冻结输入及原判断逐条相符。
- 721 处证据/quote 逐字匹配本人原评，确定同作者正文仅按原授权范围核对；local_mother 填项证据严格来自本人原评。
- 341/341 显式 local_mother；当前隔离候选对象109，null232。固定契约家族、占位键和逐字参数全量验证通过；不把参数验证当语义验收。渲染检查只保存家族、状态、字面字段和长度，未保存回复正文。
- 原三片 SHA 与 task 完全相同；冻结 input SHA 与 manifest 相同。主判断、原适配器及其他锁定模块未修改。
- 正式页审计写出0页，正式页输出 ID 验证尚不适用。validation.json 显式 formal_page_audits_written=0、all_semantic_decisions_final=false，防止把来源页检查误作最终页验收。

真实隔离文件 SHA：c8d9d600fe67831423927c64710db4c6ee95b9aaa7e364986850b729b367f209。

本次已有 credits 使用量为 unknown。平台请求0，发送0，新冻结0，未操作账号、凭据、采集源库、全局总状态或产品模块。

## 供协调者继续

收到 root 有证据的地区短询口径后，先按裁决调整 decisions.tsv 与 build_audit.py 对应显式补丁并记录依据，再在本 part 范围重跑真实隔离预检。只有裁决已落实，才使用 --ruling-resolved 写正式三页审计并核 ID。不得把参数开关当作已获得裁决。正式合并和发布仍由唯一协调者负责。

本目录：C:/Users/rmsama/Documents/ChatGPT/自动获客系统/work/fangyu-text-business-20261029/douyin-registered-v2/increments/f98cc21138910fb9/audit-worker-1

文件：report.md、validation.json、progress.json、decisions.tsv、isolated-reviewed.jsonl、render-validation.json、build_audit.py、view.py。
