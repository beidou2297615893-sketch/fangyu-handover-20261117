"""Recheck existing XHS text locally, retain positive customers and hidden review work."""
import hashlib,json,os,sys,time
from collections import Counter
from pathlib import Path
HERE=Path(__file__).resolve().parent
WORK=HERE.parent
sys.path[:0]=[str(WORK/'business-fit'),str(WORK/'recency-priority')]
import business_fit,retention30

def atomic(path,data):
    tmp=path.with_name(path.name+f'.{os.getpid()}.tmp');tmp.write_bytes(data);os.replace(tmp,path)

def run():
    source=WORK/'recency-priority/xiaohongshu-all-pool-business-fit.jsonl'
    original=source.read_bytes();rows=[json.loads(line) for line in original.splitlines() if line.strip()]
    digests=set(retention30.registry());kept=[];visible=[];counts=Counter();removed=[]
    for row in rows:
        row['platform']='xiaohongshu'
        fit=business_fit.screen(row);row['commercial_fit']=fit
        cid=retention30.cid(row)
        if fit['lead_intent'] in ('low','non_customer','ended') or retention30.expired(row,'xiaohongshu'):
            if cid:digests.add(retention30.fingerprint('xiaohongshu',cid))
            removed.append({'digest':retention30.fingerprint('xiaohongshu',cid),'reason':fit['lead_intent']})
            continue
        kept.append(row);counts[fit['lead_intent']]+=1
        if fit['lead_intent'] in ('medium','high','super_high') and fit['eligible_candidate']:visible.append(row)
    if source.read_bytes()!=original:raise RuntimeError('XHS source changed during local recheck')
    atomic(retention30.REGISTRY,json.dumps({'digests':sorted(digests)},separators=(',',':')).encode())
    payload=lambda values:''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in values).encode()
    atomic(source,payload(kept))
    dest=WORK/'recency-priority/xiaohongshu-retained-business-customers.jsonl'
    data=payload(visible);atomic(dest,data)
    result={'version':business_fit.VERSION,'source':str(source),'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'visible_file':str(dest),'visible_sha256':hashlib.sha256(data).hexdigest(),'visible_count':len(visible),'visible_intents':dict(Counter(r['commercial_fit']['lead_intent'] for r in visible)),'hidden_unresolved':sum(counts.values())-len(visible),'removed_count':len(removed),'deleted_fingerprints':removed,'model_calls':0,'platform_requests':0,'send_batch_modified':False}
    atomic(HERE/'xiaohongshu-cleanup-result.json',json.dumps(result,ensure_ascii=False,indent=2).encode())
    print(json.dumps({k:v for k,v in result.items() if k!='deleted_fingerprints'},ensure_ascii=False))

if __name__=='__main__':run()
