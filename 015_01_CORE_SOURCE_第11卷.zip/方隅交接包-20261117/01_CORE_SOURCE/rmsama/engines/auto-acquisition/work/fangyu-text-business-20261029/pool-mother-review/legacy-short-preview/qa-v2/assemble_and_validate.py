import json,hashlib,collections
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent
OUT=ROOT/'qa-v2'
def read_jsonl(name): return [json.loads(x) for x in (ROOT/name).read_text(encoding='utf-8').splitlines() if x.strip()]
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
rows=read_jsonl('qa-holdout-200-v2.jsonl')
negative=read_jsonl('qa-negative-boundaries-v2.jsonl')
contexts=json.loads((ROOT/'qa-shared-contexts-v2.json').read_text(encoding='utf-8'))
inputs={name:sha(ROOT/name) for name in ['qa-holdout-200-v2.jsonl','qa-shared-contexts-v2.json','qa-negative-boundaries-v2.jsonl']}
notes={}
for line in (OUT/'manual-notes-200.txt').read_text(encoding='utf-8').splitlines():
 f=line.split('|');n=int(f[0]);assert n not in notes
 notes[n]={'verdict':f[1],'reason':f[2],'issues':[], 'reminders':[]}
 for extra in f[3:]:
  notes[n]['issues' if extra.isascii() else 'reminders'].append(extra)
assert sorted(notes)==list(range(1,201))
# Explicit reviewer-identified metadata cautions, not a rule-based semantic classifier.
fee_metadata_ids=[3,15,18,30,33,48,55,88,95,125,136,137,147,157]
verified_wording_ids=[9,10,25,39,67,80,98,106,117,139]
result=[]
for i,r in enumerate(rows,1):
 n=notes[i];c=contexts[r['context_key']];rem=list(n['reminders']);metadata=[]
 if i in fee_metadata_ids:
  metadata.append({'quote':'同店有符合全部必付费用上限及家庭整租要求的房型','source':'fact_gaps_from_existing_reply_fields','reason':'原评论未提出家庭整租；预算/问价也未明确为含全部费用的上限。这是原母句事实缺口中的泛化条件，不得反向写成用户已提出的需求。'})
 if i in verified_wording_ids:
  metadata.append({'quote':'适配位置和有效报价已核、优惠属实','source':'fact_gaps_from_existing_reply_fields','reason':'此词位于待核事实列表，不能将已核二字当作核实回执。实际位置、报价、优惠均未独立核实。'})
 quote_field='post_body' if c.get('post_body') is not None else 'post_title'
 result.append({'sample_index':i,'platform':r['platform'],'cid':r['cid'],'uid':r['uid'],'verdict':n['verdict'],
 'evidence_comment_quote':r['comment'],'evidence_draft_quote':r['draft_text_preview'],
 'evidence_context_quote':c.get(quote_field),'evidence_context_source':r['context_key']+'.'+quote_field,
 'evidence_plan_fill':r['plan']['fill'],'plan_family':r['plan']['family'],
 'reason':n['reason'],'issue_types':n['issues'],'classification_reminder':rem,
 'source_needs_review':r['original_classification'].get('needs_review'),
 'source_plan_metadata_cautions':metadata,'contact_review_required':r['contact_review_required'],
 'source_contact_policy':r['original_classification'].get('contact_policy'),
 'contact_eligible':'not_assessed','send_authorized':False,
 'source_fact_gaps_preserved':r['fact_gaps_from_existing_reply_fields'],
 'unverified_fact_claims':[
  {'draft_quote':'我住方隅','gap':'发送账号的实际住户身份未独立核实；用户允许住户口气不等于身份属实。'},
  {'draft_quote':'介绍有优惠','gap':'本人介绍资格、具体门店优惠、活动有效期及适用条件未独立核实。'},
  {'draft_quote':r['draft_text_preview'],'gap':'方隅承接地区、同一有效房源能否符合本评论完整要求及当前报价/房态均未独立核实；帖子不证明方隅事实。'}],
 'semantic_scope':'仅本地预览文字；通过不等于事实核实、当前意向确认、联系许可或发送批准。',
 'review_method':'reviewer_manual_per_item','original_role':r['original_classification']['role'],
 'original_state':r['original_classification']['state'],'original_interest':r['original_classification']['interest'],
 'source_comment_sha256':r['source_comment_sha256']})
with (OUT/'review-200.jsonl').open('w',encoding='utf-8',newline='\n') as f:
 for r in result:f.write(json.dumps(r,ensure_ascii=False,separators=(',',':'))+'\n')
neg_notes={}
for line in (OUT/'manual-notes-negative-30.txt').read_text(encoding='utf-8').splitlines():
 f=line.split('|');neg_notes[int(f[0])]=(f[1],f[2])
assert sorted(neg_notes)==list(range(1,31))
neg_result=[]
for i,r in enumerate(negative,1):
 v,reason=neg_notes[i]
 neg_result.append({'sample_index':i,'platform':r['platform'],'cid':r['cid'],'uid':r['uid'],
 'verdict':v,'conclusion':'本包不新生成推广稿；不代表永久排除本人未来需求。',
 'evidence_comment_quote':r['comment'],'reason':reason,
 'original_role':r['original_role'],'original_demand_state':r['original_demand_state'],'original_interest':r['original_interest'],
 'original_contact_policy':r['original_contact_policy'],
 'contact_review_required':r['original_contact_policy'] in [None,'unknown'],
 'contact_policy_is_only_no_generation_reason':False,'send_authorized':False,
 'original_labels_unchanged':True,'review_method':'reviewer_manual_per_item','source_comment_sha256':r['source_comment_sha256']})
with (OUT/'review-negative-30.jsonl').open('w',encoding='utf-8',newline='\n') as f:
 for r in neg_result:f.write(json.dumps(r,ensure_ascii=False,separators=(',',':'))+'\n')
# Mechanical validation only: identities, exact preservation, counts and hashes.
errors=[]
for i,(src,dst) in enumerate(zip(rows,result),1):
 if (src['platform'],src['cid'],src['uid'])!=(dst['platform'],dst['cid'],dst['uid']):errors.append(['id_mismatch',i])
 if dst['evidence_comment_quote']!=src['comment']:errors.append(['comment_quote_mismatch',i])
 if dst['evidence_draft_quote']!=src['draft_text_preview']:errors.append(['draft_quote_mismatch',i])
 if hashlib.sha256(src['comment'].encode()).hexdigest()!=src['source_comment_sha256']:errors.append(['input_comment_hash_mismatch',i])
 if not dst['reason'] or not dst['verdict']:errors.append(['missing_judgment',i])
for i,(src,dst) in enumerate(zip(negative,neg_result),1):
 if (src['platform'],src['cid'],src['uid'])!=(dst['platform'],dst['cid'],dst['uid']):errors.append(['negative_id_mismatch',i])
 if dst['evidence_comment_quote']!=src['comment']:errors.append(['negative_quote_mismatch',i])
 if hashlib.sha256(src['comment'].encode()).hexdigest()!=src['source_comment_sha256']:errors.append(['negative_input_comment_hash_mismatch',i])
no_contact_count=sum(r.get('original_contact_policy')=='no_contact' for r in negative)
validation={'review_date':'2026-10-30','scope':'人工逐条语义复核的200条本地预览及30条角色/状态边界，非发送测试',
 'input_sha256':inputs,'input_sha256_rechecked':{n:sha(ROOT/n) for n in inputs},
 'counts':{'input_preview':len(rows),'reviewed_preview':len(result),'input_negative':len(negative),'reviewed_negative':len(neg_result),
 'preview_by_platform':dict(collections.Counter(r['platform'] for r in result)),
 'preview_verdicts':dict(collections.Counter(r['verdict'] for r in result)),
 'preview_issue_types':dict(collections.Counter(t for r in result for t in r['issue_types'])),
 'preview_contact_review_required':sum(r['contact_review_required'] for r in result),
 'preview_actual_identity_and_discount_unverified':len(result),
 'preview_source_gap_list_empty':sum(not r['fact_gaps_from_existing_reply_fields'] for r in rows),
 'preview_source_fee_metadata_caution':len(fee_metadata_ids),'preview_source_verified_wording_caution':len(verified_wording_ids),
 'negative_verdicts':dict(collections.Counter(r['verdict'] for r in neg_result)),
 'negative_by_platform':dict(collections.Counter(r['platform'] for r in neg_result)),
 'negative_original_roles':dict(collections.Counter(r['original_role'] for r in negative)),
 'negative_original_states':dict(collections.Counter(r['original_demand_state'] for r in negative)),
 'negative_contact_review_required':sum(r['contact_review_required'] for r in neg_result),'negative_real_no_contact':no_contact_count},
 'completion':{'all_200_manually_read_and_judged':True,'all_30_negative_manually_read_and_judged':True,
 'all_200_comment_and_preview_verbatim_evidence':True,'all_30_comment_verbatim_evidence':True,
 'all_needed_contexts_read':True,'original_labels_and_intents_changed':False,'new_replies_written':False,
 'source_files_changed_by_this_reviewer':False,'source_pointers_or_consumers_written':False,'platform_calls_made':False,
 'external_model_or_api_or_gpu_used':False,'sending_attempted':False,'contact_unknown_not_sole_no_generation_reason':True,
 'real_no_contact_present':bool(no_contact_count),'extrapolatable_accuracy':False},
 'unique_preview_id_count':len({(r['platform'],r['cid']) for r in result}),
 'unique_negative_id_count':len({(r['platform'],r['cid']) for r in neg_result}),
 'exact_evidence_validation_errors':errors,'mechanical_validation_passed':not errors,
 'accuracy_limit':'没有独立金标；本次是定向抽样文案审核。判定数量不是总体准确率，不得外推至所有评论、分类器或发送成效。',
 'limitations':['小红书上下文仅有标题，正文、父评及子评缺失。','实际账号住户身份、介绍资格和具体优惠未独立核实。','平台联系规则、当前找房状态、具体方隅门店和房源未独立核实。','30条阴性没有真实no_contact，不能声称验证拒绝联系边界。'],
 'artifacts_sha256':{n:sha(OUT/n) for n in ['review-200.jsonl','review-negative-30.jsonl','manual-notes-200.txt','manual-notes-negative-30.txt']}}
assert validation['input_sha256']==validation['input_sha256_rechecked']
(OUT/'validation.json').write_text(json.dumps(validation,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'counts':validation['counts'],'errors':errors},ensure_ascii=False,indent=2))
