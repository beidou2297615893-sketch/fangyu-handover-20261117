"""Freeze a private, deterministic historical-model reference sample; no semantic review."""
import argparse
import hashlib
import heapq
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
DEFAULT_POINTER = HERE.parent.parent / 'fangyu-douyin-independent' / 'text-screening-current-summary.json'
SALT = 'fangyu-local-rule-holdout-20261029-v1'

def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()

def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--pointer', type=Path, default=DEFAULT_POINTER)
    ap.add_argument('--count', type=int, default=200)
    args = ap.parse_args()
    if args.count < 1:
        ap.error('count must be positive')
    pointer = args.pointer.resolve()
    pointer_hash = sha(pointer)
    info = json.loads(pointer.read_text(encoding='utf-8-sig'))
    src = Path(info['result_file']).resolve()
    source_hash = sha(src)
    if source_hash != info['result_sha256']:
        raise SystemExit('Source hash does not match pointer; refusing to freeze.')
    outdir = HERE / 'holdout'
    outdir.mkdir(exist_ok=True)
    output = outdir / 'historical-reference.jsonl'
    meta = outdir / 'freeze-metadata.json'
    if output.exists() or meta.exists():
        raise SystemExit('Holdout already exists; refusing to overwrite the frozen sample.')
    heap, seen, rows = [], set(), 0
    with src.open(encoding='utf-8-sig') as f:
        for line in f:
            if not line.strip():
                continue
            row = json.loads(line); rows += 1
            cid = str(row.get('comment_id') or '')
            platform = str(row.get('platform') or '')
            if not cid or not platform:
                raise SystemExit('A row lacks a platform or stable comment ID; no output written.')
            key = (platform, cid)
            if key in seen:
                raise SystemExit('Duplicate platform/comment ID; resolve source ambiguity before sampling.')
            seen.add(key)
            digest = hashlib.sha256((SALT + '\0' + platform + '\0' + cid).encode('utf-8')).digest()
            rank = int.from_bytes(digest, 'big')
            item = (-rank, platform, cid, row)
            if len(heap) < args.count:
                heapq.heappush(heap, item)
            elif rank < -heap[0][0]:
                heapq.heapreplace(heap, item)
    if len(heap) < args.count:
        raise SystemExit('Not enough unique records; no output written.')
    if sha(src) != source_hash or sha(pointer) != pointer_hash:
        raise SystemExit('Source or pointer changed during sampling; no output written.')
    selected = sorted(heap, key=lambda x: (-x[0], x[1], x[2]))
    id_hasher = hashlib.sha256()
    for _, platform, cid, _ in selected:
        id_hasher.update((platform + '\0' + cid + '\n').encode('utf-8'))
    try:
        with output.open('x', encoding='utf-8', newline='\n') as f:
            for _, _, _, row in selected:
                f.write(json.dumps(row, ensure_ascii=False, separators=(',', ':')) + '\n')
        metadata = {'reference_kind': 'historical_model_not_human_gold', 'salt': SALT,
                    'selection': 'lowest sha256(salt NUL platform NUL comment_id)',
                    'source_pointer': str(pointer), 'pointer_sha256': pointer_hash,
                    'source_file': str(src), 'source_sha256': source_hash,
                    'source_rows': rows, 'sample_count': len(selected),
                    'ordered_id_sha256': id_hasher.hexdigest(), 'sample_sha256': sha(output)}
        with meta.open('x', encoding='utf-8', newline='\n') as f:
            json.dump(metadata, f, ensure_ascii=False, indent=2); f.write('\n')
    except BaseException:
        output.unlink(missing_ok=True); meta.unlink(missing_ok=True)
        raise
    print(json.dumps({'source_rows': rows, 'sample_count': len(selected),
                      'source_sha256': source_hash, 'ordered_id_sha256': id_hasher.hexdigest(),
                      'sample_sha256': metadata['sample_sha256']}))

if __name__ == '__main__':
    main()
