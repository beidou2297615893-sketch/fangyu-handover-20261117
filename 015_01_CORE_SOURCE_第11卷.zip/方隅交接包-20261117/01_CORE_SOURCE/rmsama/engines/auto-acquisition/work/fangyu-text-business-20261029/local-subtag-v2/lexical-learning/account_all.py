"""Summarize full raw split denominator without scoring excluded unknown labels."""
import json,hashlib,collections
from pathlib import Path
H=Path(__file__).resolve().parent
pointer=json.loads((H.parents[2]/'fangyu-douyin-independent/text-screening-current-summary.json').read_text(encoding='utf-8-sig'))
source=Path(pointer['result_file']); m=json.loads((H/'manifest.json').read_text(encoding='utf-8')); report=json.loads((H/'report.json').read_text(encoding='utf-8'))
assert hashlib.sha256(source.read_bytes()).hexdigest()==m['source_sha256']
c=collections.defaultdict(collections.Counter)
for l in source.read_text(encoding='utf-8-sig').splitlines():
 r=json.loads(l); group=r.get('video_id') or r.get('post_id') or r.get('note_id'); group=str(r.get('platform','unknown'))+':'+str(group)
 b=int(hashlib.sha256(('lexical-v1-group-split:'+group).encode()).hexdigest()[:8],16)%100; s='train' if b<70 else 'calibration' if b<85 else 'test'; c[s]['all_raw_records']+=1
 if r.get('role')=='unknown' or r.get('interest_at_comment')=='uncertain' or r.get('role')=='mixed': c[s]['unknown_or_uncertain_or_mixed']+=1
for s in ('calibration','test'):
 n=c[s]['all_raw_records']; d=report[s]['decided']; c[s]['decision_count_on_known_unique_records']=d; c[s]['conservative_overall_decided_coverage']=d/n; c[s]['conservative_overall_deferred_fraction']=1-d/n
m['overall_split_accounting']={s:dict(v) for s,v in c.items()}; m['overall_accounting_policy']='All unknown/uncertain/mixed, duplicates and excluded labels count as deferred; known unique decisions only. This conservative overall coverage is not predictive accuracy or full production throughput.'
(H/'manifest.json').write_text(json.dumps(m,ensure_ascii=False,indent=2),encoding='utf-8'); print(json.dumps(m['overall_split_accounting']))
