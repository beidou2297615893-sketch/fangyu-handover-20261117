"""Small final-object-guard patch on immutable release-repairs v1; never publishes."""
import pathlib,json,hashlib,copy,re,string,collections,sys,datetime
sys.dont_write_bytecode=True
O=pathlib.Path(__file__).resolve().parent;P=O.parent;W=P.parent;V=P/'legacy-release-repairs';F=P/'legacy-release-package/candidate-abc';Q=P/'legacy-final-semantic-review';R=W/'douyin-registered-v2/increments/f98cc21138910fb9'
def load(p):return json.loads(pathlib.Path(p).read_text(encoding='utf8'))
def jl(p):return [json.loads(l) for l in pathlib.Path(p).read_text(encoding='utf8').splitlines() if l.strip()]
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def objsha(x):return hashlib.sha256(json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def key(x):
 if 'key' in x and isinstance(x['key'],list):return tuple(str(v) for v in x['key'])
 return str(x['platform']),str(x.get('cid',x.get('comment_id'))),str(x.get('uid',x.get('customer_uid')))
def put(p,x):pathlib.Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
def putjl(p,x):pathlib.Path(p).write_text(''.join(json.dumps(v,ensure_ascii=False,separators=(',',':'))+'\n' for v in x),encoding='utf8')
ready=load(V/'READY.json');assert ready['status']=='complete_frozen_for_independent_review_not_published'
assert sha(V/'READY.json')=='7de8c6665b7951e781d4cf9fd3a8affa895dc2997154f890f401e120483ec50e'
for n,h in ready['final_files_sha256'].items():assert sha(V/n)==h,('V1_FROZEN_CHANGED',n)
assert sha(Q/'manifest.json')=='e618442bc64954681e2f044e596900975d02e79c3fce60ff364da4ea8d9b71d0'
qm=load(Q/'manifest.json');assert qm['status']=='final_finite_review_complete_two_plan_fixes_required'
for n,h in qm['files_sha256'].items():assert sha(Q/n)==h,('FINAL_QA_NOT_FROZEN',n)
advisory=load(Q/'required-patch.json');assert len(advisory['cases'])==2
base=jl(F/'merged-plans.jsonl');abc={key(p):p for p in base};v1ov=jl(V/'source-bound-plan-overlays.jsonl');v1={k:copy.deepcopy(p) for k,p in abc.items()}
for ov in v1ov:
 k=key(ov);assert objsha(abc[k])==ov['base_merged_plan_sha256'];v1[k].update(copy.deepcopy(ov['replacement_plan']))
assert len(v1)==12963 and sum(bool(p['family']) for p in v1.values())==6694
contract=load(V/'repair-contract.json');original_contract=copy.deepcopy(contract);abc_contract=load(F/'merged-contract.json');newdefs={}
contract.update(version='legacy-release-repairs-v2-final-object-guard',applied=False,send_authorized=False,parent_contract_sha256=sha(V/'repair-contract.json'))
cur=load(W/'region-brand-routing/current.json');sources={}
for platform,f in cur['results'].items():
 for r in jl(f):sources[key(r)]=r
protected=dict(load(V/'manifest.json')['source_SHA256']);protected.update({str((V/n).resolve()):h for n,h in ready['final_files_sha256'].items()});protected[str((V/'READY.json').resolve())]=sha(V/'READY.json');protected.update({str((Q/n).resolve()):h for n,h in qm['files_sha256'].items()});protected[str((Q/'manifest.json').resolve())]=sha(Q/'manifest.json')
renderer={};exec(compile((R/'batch_short_mothers.py').read_text(encoding='utf-8-sig'),str(R/'batch_short_mothers.py'),'exec'),renderer)
def render(p,which=contract):
 if not p.get('family'):return None
 r=sources[key(p)];row={'role':r['role'],'demand_state':r['demand_state'],'interest_at_comment':r['interest_at_comment'],'reply_plan':{'local_mother':{'family':p['family'],'fill':p['fill'],'evidence':p['evidence']},'contact_policy':r.get('contact_policy') or 'unknown','tone':r.get('effective_tone')}}
 return renderer['render_plan'](row,r['comment_text'],which)['validated_plan_text']
def fields(r):
 s=r.get('source_record') or {};a=s.get('classification') if isinstance(s.get('classification'),dict) else s;return s,a
def remarks(r):
 s,a=fields(r);out=[]
 for d in (r,s,a):
  for f in ('needs_review','review_reasons','semantic_review_reasons','blocking_reasons'):
   v=d.get(f) or [];out.extend(v if isinstance(v,list) else [str(v)])
 return list(dict.fromkeys(str(x) for x in out))
def context(r):
 s,a=fields(r);raw=r.get('original_raw_record') or {};title=raw.get('post_title') or '';body=raw.get('post_text') or s.get('post_body') or '';full=title+' '+body
 return {'title':title,'body':body,'residential_evidence':bool(re.search(r'住宅|公寓|一室|二室|两室|[1234]室|卧室|房间|一居|整租|合租|serviced\s+apartment',full,re.I)),'source_SHA':objsha([title,body]),'warning_quotes':[x for x in remarks(r) if re.search(r'住宅属性|住宅用途|用途.{0,8}(?:未|不明|确认)|交易对象.{0,8}(?:未|确认)|先确认交易对象',x)]}
def purpose_question(text):return bool(re.search(r'你是在找住的房子吗|是在找住房吗|找住的房子|住宅用途.{0,4}[?？]',text or ''))
def relation_question(text):return bool(re.search(r'原帖.{0,20}[?？]|[?？].{0,8}确认对象',text or ''))
def ordinary_reference(r,p):
 """Literal object reference only; temporal/price/known-work anchors are separated, no intent relabel."""
 text=r['comment_text'];s,a=fields(r);records=[]
 for m in re.finditer('这个',text):
  after=text[m.end():m.end()+10]
  if re.match(r'月|星期|礼拜|周|季度|学期|时候|时间|月底|月初|点钟',after):records.append({'span':'这个','start':m.start(),'decision':'temporal_or_period_reference_not_housing_object'});continue
  if re.match(r'价位|价格|价钱|预算|租金|金额|费用|押金|要求|条件|政策|优惠|功能|标准',after):records.append({'span':'这个','start':m.start(),'decision':'price_condition_or_other_noun_reference_not_housing_object'});continue
  regs=p['source_field_evidence'].get('target_regions') or []
  if any(x.get('relation') in ('work','current_home','excluded') and x.get('quote') and x['quote'] in text and '这个' in x['quote'] for x in regs):records.append({'span':'这个','start':m.start(),'decision':'existing_AI_work_current_home_anchor_not_reassigned_to_housing'});continue
  # Existing own-demand housing/query evidence and actual post context constrain the literal binding.
  ev=[e for e in p.get('literal_evidence',[]) if e.get('subject')=='own_demand' and e.get('quote') and e['quote'] in text]
  if not ev:records.append({'span':'这个','start':m.start(),'decision':'missing_own_evidence_specific_review_needed'});continue
  records.append({'span':'这个','start':m.start(),'decision':'source_post_object_reference_pending_relation','own_AI_pool_evidence':ev})
 return records
def core(template):
 t=re.sub(r'^宝宝，(?:可以聊呀！)?(?:我住方隅，)?','',template);t=t.replace('我住方隅，','').replace('介绍有优惠。','').rstrip('，。')
 # A deferred location question does not claim the source address has already been obtained.
 return t.replace('位置可以发你','位置帮你问').replace('位置发你','位置帮你问')
def add_family(origin,template,fill):
 name='repair_v2_'+origin+'_'+objsha([template,list(fill)])[:10];d={'template':template,'required_fill':list(fill),'scope':'clarification_only','individually_user_approved':False,'source_policy':'final source-object/purpose guard; literal parameters; no source classification edits'}
 if name in contract['families'] and contract['families'][name]!=d:raise ValueError('NON_EQUIVALENT_FAMILY_COLLISION '+name)
 contract['families'][name]=d;newdefs[name]=d;return name
def project(p):return {k:p.get(k) for k in ('family','fill','evidence','clarification_only','hold_reasons','status')}
def changed(z,template,reason,proof):
 f=add_family(z['family'],template,z['fill']);z.update(family=f,clarification_only=True,hold_reasons=[],status='local_plan_proposed');z['v2_change_reasons'].append(reason);z['v2_evidence'].append(proof)
def final_object_guard(z,r,ctx,ref):
 """Every bound path, including prior/new clarification-only plans, reaches this final guard."""
 if not z['family']:return z
 text=render(z);unresolved=bool(ctx['warning_quotes']) and not ctx['residential_evidence']
 # Real housing evidence in a title is not erased merely because the body is absent.
 if unresolved and (not purpose_question(text) or re.search(r'我住方隅|介绍有优惠',text)):
  original=contract['families'][z['family']]['template'];c=core(original)
  if ref and not purpose_question(text):
   if 'v2_object_reference' not in z['fill']:z['fill']['v2_object_reference']='这个';z['evidence'].append({'field':'v2_object_reference','quote':'这个','source_field':'own_comment_exact_span'})
   question='宝宝，你说的“{v2_object_reference}”是想找住的房子吗？'
  else:question='宝宝，你是在找住的房子吗？'
  changed(z,question+'确认对象后，'+c+'。','all_branch_final_housing_purpose_guard_prevents_promotion_before_confirmation',{'source_blocking_and_review_quotes':ctx['warning_quotes'],'actual_title':ctx['title'],'actual_body_missing':not bool(ctx['body']),'residential_evidence':False})
 return z
def patch(p):
 z=copy.deepcopy(p);z['v2_change_reasons']=[];z['v2_evidence']=[];r=sources[key(p)];ctx=context(r);refs=ordinary_reference(r,p);ref=any(x['decision']=='source_post_object_reference_pending_relation' for x in refs)
 if not p['family']:return z,{'bound':False,'guard_not_applicable_to_unbound':True}
 before=render(p,original_contract)
 if ref and not relation_question(before) and not purpose_question(before) and not (ctx['warning_quotes'] and not ctx['residential_evidence']):
  z['fill']['v2_object_reference']='这个';z['evidence'].append({'field':'v2_object_reference','quote':'这个','source_field':'own_comment_exact_span'})
  template='宝宝，你说的“{v2_object_reference}”是原帖里介绍的房源吗？确认对象后，'+core(contract['families'][z['family']]['template'])+'。'
  changed(z,template,'preserve_ordinary_source_post_object_reference_without_single_unit_or_alternative_assumption',{'quote':'这个','reference_granularity':'source_post_object_not_asserted_single_unit','relation_to_brand':'unknown','alternative_acceptance':'unknown','original_AI_evidence':next(x['own_AI_pool_evidence'] for x in refs if x['decision']=='source_post_object_reference_pending_relation'),'post_context_SHA':ctx['source_SHA']})
 # No early return above is permitted to bypass this final semantic guard.
 z=final_object_guard(z,r,ctx,ref)
 after=render(z);assert not(ctx['warning_quotes'] and not ctx['residential_evidence']) or (purpose_question(after) and not re.search(r'我住方隅|介绍有优惠',after)),('PURPOSE_GUARD_BODY_FAILURE',p['cid'])
 receipt={'platform':p['platform'],'cid':p['cid'],'uid':p['uid'],'sourceSHA':p['sourceSHA'],'v1_applied_plan_sha256':objsha(p),'family_before':p['family'],'family_after':z['family'],'original_contact_policy':p.get('contact_policy_original'),'object_reference_scan':refs,'source_object_warning_quotes':ctx['warning_quotes'],'actual_context_residential_evidence':ctx['residential_evidence'],'actual_context_SHA':ctx['source_SHA'],'final_guard_executed_for_bound_path':True,'body_contains_housing_purpose_question':purpose_question(after),'body_contains_source_relation_question':relation_question(after),'body_contains_promotion':bool(re.search(r'我住方隅|介绍有优惠',after)),'changed':project(z)!=project(p),'change_reasons':z['v2_change_reasons']}
 return z,receipt
def validate(p,z):
 r=sources[key(p)];assert hashlib.sha256(r['comment_text'].encode()).hexdigest()==p['sourceSHA'];assert objsha(r['source_record'])==p['original_classification_sha256'];assert z['source_field_evidence']==p['source_field_evidence'];assert z['can_send_now'] is False and z['send_authorized'] is False
 if z['family']:
  text=render(z);d=contract['families'][z['family']];assert set(z['fill'])==set(d['required_fill'])=={k for _,k,_,_ in string.Formatter().parse(d['template']) if k}
  for f,v in p['fill'].items():
   for span in v.split('、') if f=='requirements' else [v]:assert span in text,('OLD_LITERAL_CONDITION_DROPPED',p['cid'],f,v)
  if project(p)!=project(z):assert z.get('clarification_only') is True and '？' in text
 return True
def main():
 result={};receipts=[];delta=[];drafts=[]
 for k,p in v1.items():
  z,rec=patch(p);validate(p,z);result[k]=z
  if p['family']:receipts.append(rec)
  if project(z)!=project(p):
   text=render(z);oldtext=render(p,original_contract);delta.append({'platform':p['platform'],'cid':p['cid'],'uid':p['uid'],'sourceSHA':p['sourceSHA'],'source_file_sha256':p['source_file_sha256'],'original_classification_sha256':p['original_classification_sha256'],'base_v1_applied_plan_sha256':objsha(p),'base_ABC_plan_sha256':objsha(abc[k]),'v1_family':p['family'],'v1_fill':p['fill'],'replacement_plan':project(z),'repair_reasons':z['v2_change_reasons'],'repair_evidence':z['v2_evidence'],'old_preview_sha256':hashlib.sha256(oldtext.encode()).hexdigest(),'new_preview_sha256':hashlib.sha256(text.encode()).hexdigest(),'original_review_and_blocking_preserved':remarks(sources[k]),'original_contact_policy':p.get('contact_policy_original'),'classification_changed':False,'send_authorized':False,'can_send_now':False,'applied':False})
   drafts.append({'platform':p['platform'],'cid':p['cid'],'uid':p['uid'],'sourceSHA':p['sourceSHA'],'family':z['family'],'fill':z['fill'],'clarification_only':True,'draft_body':text,'draft_body_sha256':hashlib.sha256(text.encode()).hexdigest(),'source_contact_policy':p.get('contact_policy_original'),'contact_eligible':'not_assessed','can_send_now':False,'send_authorized':False,'local_template_render_not_freeform_AI_body':True})
 # V2 cumulative overlays remain consumable against original frozen ABC, while delta is explicit against applied V1.
 cumulative={key(x):copy.deepcopy(x) for x in v1ov}
 for d in delta:
  k=key(d);old=cumulative.get(k,{});new=copy.deepcopy(old);abc_text=render(abc[k],abc_contract)
  new.update(platform=d['platform'],cid=d['cid'],uid=d['uid'],sourceSHA=d['sourceSHA'],source_file_sha256=d['source_file_sha256'],original_classification_sha256=d['original_classification_sha256'],base_merged_plan_sha256=objsha(abc[k]),base_origin=abc[k].get('plan_origin','A'),base_family=abc[k]['family'],base_fill=abc[k]['fill'],replacement_plan=d['replacement_plan'],v2_parent_v1_applied_plan_sha256=d['base_v1_applied_plan_sha256'],v2_delta_reasons=d['repair_reasons'],v2_delta_evidence=d['repair_evidence'],repair_reasons=list(dict.fromkeys(old.get('repair_reasons',[])+d['repair_reasons'])),repair_evidence=old.get('repair_evidence',[])+d['repair_evidence'],original_source_contact_policy=v1[k].get('contact_policy_original'),source_contact_boundary_preserved=v1[k]['source_field_evidence'].get('contact_boundaries'),source_needs_review_and_blocking_preserved=remarks(sources[k]),old_preview_sha256=hashlib.sha256(abc_text.encode()).hexdigest() if abc_text else None,new_preview_sha256=d['new_preview_sha256'],classification_changed=False,can_send_now=False,send_authorized=False,applied=False);cumulative[k]=new
 put(O/'repair-contract.json',contract);put(O/'contract-addon.json',{'version':'v2-small-final-object-guard-addon','parent_contract_SHA':sha(V/'repair-contract.json'),'families':newdefs});putjl(O/'incremental-plan-overlays.jsonl',delta);putjl(O/'source-bound-plan-overlays.jsonl',[cumulative[k] for k in sorted(cumulative)]);putjl(O/'CLI-draft-body-overlays.jsonl',drafts);putjl(O/'all-6694-final-object-guard-scan.jsonl',receipts)
 assert len(receipts)==6694
 for name,d in original_contract['families'].items():assert contract['families'][name]==d,('V1_CONTRACT_MUTATED_IN_V2',name)
 # Regress all old V1 QA records and the complete frozen final finite review, without issuing new semantic scores.
 regress=[]
 for origin,rows in [('V1-285',jl(V/'old-QA-regression.jsonl')),('final-finite-61',jl(Q/'case-review.jsonl'))]:
  for q in rows:
   k=key(q);p=v1[k];z=result[k];before=render(p,original_contract);after=render(z);regress.append({'origin':origin,'platform':k[0],'cid':k[1],'uid':k[2],'sourceSHA':p['sourceSHA'],'v1_family':p['family'],'v2_family':z['family'],'v2_fill':z['fill'],'changed':project(p)!=project(z),'unchanged_draft_byte_identical':before==after if project(p)==project(z) else None,'v1_draft':before,'v2_draft':after,'repair_reasons':z['v2_change_reasons'],'original_classification_unchanged':True,'old_regression_not_new_holdout':True,'new_semantic_grade_issued':False})
 putjl(O/'v1-and-final-review-regression.jsonl',regress)
 required={'7696414781808689957','6acf7c9f0000000008031dc0'};bycid={d['cid']:d for d in drafts};assert required<=set(bycid)
 c42=bycid['7696414781808689957'];assert all(x in c42['draft_body'] for x in ('这个','原帖','租金','位置','私聊联系你的事')) and '介绍有优惠' not in c42['draft_body']
 short=bycid['6acf7c9f0000000008031dc0'];assert purpose_question(short['draft_body']) and all(x in short['draft_body'] for x in ('短租','多久')) and not re.search(r'我住方隅|介绍有优惠|月租',short['draft_body']) and short['source_contact_policy'] is None
 additions=[x for x in v1ov if x.get('newly_bound_small_short_lease_addition')];assert len(additions)==5
 for x in additions:
  if x['cid']=='6acf7c9f0000000008031dc0':continue
  k=key(x);assert project(result[k])==project(v1[k]) and render(result[k])==render(v1[k],original_contract),('CLEAR_RESIDENTIAL_SHORT_LEASE_CHANGED',x['cid'])
 unchanged=sum(bool(p['family']) and project(result[k])==project(p) for k,p in v1.items());changed=len(delta)
 stats={'base_total':12963,'v1_bound_scanned':6694,'incremental_changed_plans':changed,'ordinary_reference_changes':sum(any('ordinary_source' in s for s in d['repair_reasons']) for d in delta),'final_purpose_guard_changes':sum(any('final_housing_purpose_guard' in s for s in d['repair_reasons']) for d in delta),'cumulative_ABC_overlays':len(cumulative),'unchanged_bound_plans':unchanged,'v2_housing_plans':sum(bool(z['family']) and not z.get('clarification_only') for z in result.values()),'v2_clarification_plans':sum(bool(z['family']) and z.get('clarification_only') for z in result.values()),'held':sum(not z['family'] for z in result.values()),'v1_final_review_rows':len(regress),'four_residential_new_short_cases_unchanged':4,'new_contract_definitions':len(newdefs),'date_or_period_nonobject_exclusions':sum(x['decision']=='temporal_or_period_reference_not_housing_object' for r in receipts for x in r['object_reference_scan']),'all_original_definition_bytes_preserved':True}
 for path,h in protected.items():assert sha(path)==h,('PROTECTED_SOURCE_CHANGED',path)
 outnames=['repair-contract.json','contract-addon.json','incremental-plan-overlays.jsonl','source-bound-plan-overlays.jsonl','CLI-draft-body-overlays.jsonl','all-6694-final-object-guard-scan.jsonl','v1-and-final-review-regression.jsonl']
 manifest={'status':'complete_candidate_not_applied_pending_independent_review','v1_READY_SHA':sha(V/'READY.json'),'v1_contract_SHA':sha(V/'repair-contract.json'),'v1_overlays_SHA':sha(V/'source-bound-plan-overlays.jsonl'),'base_ABC_merged_plans_SHA':sha(F/'merged-plans.jsonl'),'final_finite_review_manifest_SHA':sha(Q/'manifest.json'),'delta_apply_semantics':'deep-copy frozen ABC complete row; update only v1 replacement_plan fields; compare base_v1_applied_plan_sha256; update only v2 replacement_plan fields','cumulative_apply_semantics':'source-bound-plan-overlays.jsonl compares base_merged_plan_sha256 to frozen ABC and replaces only replacement_plan fields; new_preview_sha256 uses v2 full contract','sources_SHA256':protected,'outputs_SHA256':{n:sha(O/n) for n in outnames},'patch_script_SHA':sha(__file__),'statistics':stats,'source_or_original_classification_writes':0,'current_pointer_changes':0,'platform_calls':0,'send_attempts':0,'new_direct_API_requests':0,'local_rendering_model_calls':0,'overall_agent_judgment_usage':'unknown'}
 put(O/'manifest.json',manifest);put(O/'validation.json',{'all_structural_checks_passed':True,'all_6694_paths_pass_final_purpose_guard':True,'two_required_fixes_rendered_and_source_bound':True,'CLI_body_matches_clarification_metadata':True,'four_short_lease_residential_controls_unchanged':True,'unchanged_v1_regression_byte_identical':True,'original_source_classification_and_unknown_contact_preserved':True,'semantic_population_accuracy_claim':False,'statistics':stats,'manifest_SHA':sha(O/'manifest.json')})
 report=['# 冻结修补版的第二版小补丁','','本版仅新增普通“这个”的原帖对象确认与所有绑定分支共用的最终住宅用途守卫。未改v1、A/B/C、QA、原分类、50用户稿或current。',f'扫描6694条已有绑定，增量改变{changed}条；仍有{stats["unchanged_bound_plans"]}条绑定正文逐字不变。输出完整合同、增量和可对ABC直接叠加的累计覆盖计划，以及CLI实际草稿正文与clarification_only一致性证据。',f'最终住房草稿{stats["v2_housing_plans"]}，确认接话{stats["v2_clarification_plans"]}，held {stats["held"]}；没有为凑覆盖增减客户或改意向。','','普通“这个”不自动等于一套、只要原房或愿意换方隅；确认所指原帖对象后保留原位置、询价、私聊及联系方向。这个月等时间/周期表达不当房源指代，原AI明确工作/现住址锚点不改住址。','','用途未决的新增短租改为“你是在找住的房子吗”之后再问短租与可租多久；实际CLI正文不再带未确认住房推广。其余4条有住宅线索的新短租原文保持。clarification_only标签不能替代正文的确认问句。','','Astra最终报告已完整冻结并纳入来源：61例59通过、2改计划。这里对这两项及实际同类和旧v1回归作局部整改，不再重做285全量AI审核，不称新留出准确率。','','本地渲染模型调用0，新直接API请求0，整体agent判读usage未知；平台0、发送0、当前指针更改0。等待root/Astra只读补核，禁止自动发布。','',json.dumps(stats,ensure_ascii=False,indent=2)]
 (O/'report.md').write_text('\n'.join(report)+'\n',encoding='utf8');print(json.dumps(stats,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
