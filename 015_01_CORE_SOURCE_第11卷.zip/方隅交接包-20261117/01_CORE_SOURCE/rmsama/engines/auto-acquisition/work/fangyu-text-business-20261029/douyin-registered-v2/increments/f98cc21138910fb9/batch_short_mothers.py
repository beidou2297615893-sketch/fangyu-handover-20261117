"""Bounded local template validation and rendering; never changes classification."""
import re,string

def render_plan(row, own_text, contract):
    plan=row.get('reply_plan')
    if not isinstance(plan,dict) or 'local_mother' not in plan:
        raise ValueError('Every final row must explicitly contain local_mother')
    mother=plan['local_mother']
    if mother is None:
        if not plan.get('caution') and not row.get('reason'):
            raise ValueError('Null plan requires an explicit reason')
        return {'text':None,'family':None,'status':'no_suitable_AI_plan','literal_fields':[]}
    if not isinstance(mother,dict) or mother.get('family') not in contract['families']:
        raise ValueError('Unknown mother family')
    family=mother['family'];definition=contract['families'][family];fill=mother.get('fill');evidence=mother.get('evidence')
    placeholders={name for _,name,_,_ in string.Formatter().parse(definition['template']) if name}
    if not isinstance(fill,dict) or set(fill)!=placeholders or set(fill)!=set(definition['required_fill']):
        raise ValueError('Literal fill keys must exactly match the fixed template')
    if not isinstance(evidence,list) or any(not isinstance(e,dict) or e.get('field') not in fill or not isinstance(e.get('quote'),str) or not e['quote'] or e['quote'] not in own_text for e in evidence):
        raise ValueError('Parameter evidence must be literal own comment')
    if {e['field'] for e in evidence}!=set(fill):
        raise ValueError('Every parameter requires evidence')
    literal_fields=[]
    for field,value in fill.items():
        if not isinstance(value,str) or not value.strip():raise ValueError('Invalid empty parameter')
        quotes=[e['quote'] for e in evidence if e['field']==field]
        # requirements may be an AI-authored short list of original literal spans.
        spans=[x.strip() for x in re.split('[、；;]',value)] if field=='requirements' else [value]
        if not all(span and span in own_text and any(span in q for q in quotes) for span in spans):
            raise ValueError('Parameter contains a non-literal customer detail: '+field)
        literal_fields.extend(spans)
    if family=='relocation' and '明年搬' not in own_text:
        raise ValueError('Relocation template requires own explicit next-year move')
    if family=='pet' and '狗' not in own_text:raise ValueError('Dog template cannot be used for other pets')
    if family=='pet_cat' and '猫' not in own_text:raise ValueError('Cat template cannot be used for other pets')
    text=definition['template'].format(**fill)
    if plan.get('tone')=='serious' and text.startswith('宝宝，'):text=text[len('宝宝，'):]
    if any(v not in text for v in fill.values()):raise ValueError('Template dropped a literal parameter')
    policy=plan.get('contact_policy','unknown')
    eligible=(row.get('role')=='demand' and row.get('demand_state')=='active_at_comment' and row.get('interest_at_comment',row.get('interest')) in ('medium','high','super_high') and policy not in ('unknown','no_contact') and not row.get('source_version_conflict'))
    reason='rendered_for_local_human_review' if eligible else 'held_by_original_role_state_interest_contact_or_source'
    return {'text':text if eligible else None,'family':family,'status':reason,'literal_fields':literal_fields,'validated_plan_text':text,'contact_identity_manual_review':policy in ('identity_restricted','manual_review','manual')}
