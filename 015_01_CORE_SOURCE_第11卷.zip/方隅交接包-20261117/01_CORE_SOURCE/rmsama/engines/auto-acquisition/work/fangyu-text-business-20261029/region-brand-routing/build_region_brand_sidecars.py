import argparse, collections, hashlib, importlib.util, json, pathlib, subprocess, sys
from copy import deepcopy

HERE=pathlib.Path(__file__).resolve().parent
W=HERE.parent
parser=argparse.ArgumentParser()
parser.add_argument('--manifest', type=pathlib.Path, default=HERE/'manifest.json')
parser.add_argument('--output-dir', type=pathlib.Path, default=HERE)
parser.add_argument('--internal-idempotence-pass', action='store_true', help=argparse.SUPPRESS)
args=parser.parse_args()
MANIFEST=args.manifest.resolve()
OUT=args.output_dir.resolve()
if not OUT.is_relative_to(HERE): raise ValueError('output-dir must be inside region-brand-routing')
OUT.mkdir(parents=True,exist_ok=True)
M=json.loads(MANIFEST.read_text(encoding='utf-8-sig'))
spec=importlib.util.spec_from_file_location('mother_adapter', W/'mother_adapter.py')
adapter=importlib.util.module_from_spec(spec); spec.loader.exec_module(adapter)
MOTHER='宝宝，我住方隅公寓这边，介绍有优惠的。'
SERIOUS='我住方隅公寓这边，介绍有优惠的。'
LOCATIONS=('上海','北京','杭州','成都','福州','浙江','四川','福建')
CITY={'上海','北京','杭州','成都','福州'}

def sha(p):
 h=hashlib.sha256()
 with open(p,'rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''): h.update(b)
 return h.hexdigest()
def readlines(p):
 with open(p,encoding='utf-8') as f: return [json.loads(l) for l in f if l.strip()]
def dump(p,o): p.write_text(json.dumps(o,ensure_ascii=False,indent=2,sort_keys=True)+'\n',encoding='utf-8',newline='\n')
def map_places(text):
 # A city shown with its province is a city, not a second province-level target.
 text=str(text or ''); hits=[x for x in LOCATIONS if x in text]
 for province,city in [('浙江','杭州'),('四川','成都'),('福建','福州')]:
  if city in hits and province in hits: hits.remove(province)
 return hits
def canonical_counter(c): return dict(sorted((str(k),v) for k,v in c.items()))
def flag(label,value,checks): checks[label]=bool(value)

def build():
 checks={}; pre={}; expected={M['policy_file']:M['policy_sha256']}
 manifest_before=sha(MANIFEST); catalog_before=sha(M['store_catalog']); adapter_before=sha(W/'mother_adapter.py')
 compat=M.get('compatibility_review'); review_index={}; review_inputs={}
 if compat:
  for field in ('input','reviews','validation'):
   item=compat[field]; expected[item['file']]=item['sha256']
 for p in M['platforms'].values():
  expected[p['result_file']]=p['result_sha256']
  for raw in p.get('raw_inputs',[]): expected[raw['file']]=raw['sha256']
 before={p:sha(p) for p in expected}; flag('input_sha256_before',before==expected,checks)
 if before!=expected: raise ValueError('Fixed input SHA mismatch')
 catalog=json.loads(pathlib.Path(M['store_catalog']).read_text(encoding='utf-8')); stores=catalog['store_names_from_existing_catalog']
 assert len(stores)==15
 store_city={s:next((x for x in CITY if x in s),None) for s in stores}
 assert collections.Counter(store_city.values())=={'上海':7,'北京':3,'杭州':3,'成都':1,'福州':1}
 rawindex={}; raw_source={}
 for f in M['platforms']['xiaohongshu']['raw_inputs']:
  for r in readlines(f['file']):
   k=(r['comment_id'],r['customer_uid']); assert k not in rawindex
   rawindex[k]=r; raw_source[k]=f['file']
 sources={p:readlines(v['result_file']) for p,v in M['platforms'].items()}
 if compat:
  review_validation=json.loads(pathlib.Path(compat['validation']['file']).read_text(encoding='utf8'))
  review_input=json.loads(pathlib.Path(compat['input']['file']).read_text(encoding='utf8'))
  reviews=readlines(compat['reviews']['file']); inputs=review_input['records']
  if not (review_validation.get('status')=='pass' and not review_validation.get('errors') and review_validation.get('record_count')==124 and review_validation.get('ids_and_uids_exact_match') is True and review_validation.get('literal_quotes_verified') is True and review_validation.get('input_sha256')==compat['input']['sha256'] and review_validation.get('reviews_sha256')==compat['reviews']['sha256']): raise ValueError('Compatibility review validation is not final PASS and SHA-bound')
  key=lambda r:(r['platform'],r['comment_id'],r['customer_uid'])
  if len(inputs)!=124 or len(reviews)!=124 or len({key(r) for r in inputs})!=124 or [key(r) for r in inputs]!=[key(r) for r in reviews]: raise ValueError('Compatibility review IDs, UIDs, order or count invalid')
  if collections.Counter(r['platform'] for r in reviews)!={'douyin':102,'xiaohongshu':22}: raise ValueError('Compatibility platform count invalid')
  for i,r in zip(inputs,reviews):
   if not (r.get('input_sha256')==compat['input']['sha256'] and r.get('demand_state') in ('active_at_comment','future','ended','historical','unknown') and type(r.get('generic_intro_suitable')) is bool and r.get('tone') in ('normal','serious') and r.get('contact_policy') in ('normal','manual_review','no_contact') and r.get('stages_completed')==['initial_semantic','detailed_semantic'] and isinstance(r.get('evidence'),list) and r['evidence'] and all(isinstance(q,str) and q and q in i['comment_text'] for q in r['evidence'])): raise ValueError('Compatibility review contract/quote invalid '+str(key(r)))
   review_index[key(r)]=r; review_inputs[key(i)]=i
  srcindex={(p,r['comment_id'],r['customer_uid']):r for p,rs in sources.items() for r in rs}
  for k,i in review_inputs.items():
   source=srcindex.get(k)
   if source is None: raise ValueError('Reviewed record missing in frozen source '+str(k))
   classification=source.get('classification',source); original=i['original_AI']; text=rawindex[(k[1],k[2])]['comment_text'] if k[0]=='xiaohongshu' else source.get('comment_text')
   if text!=i['comment_text'] or any(original.get(f)!=classification.get(f) for f in ('role','demand_state')) or original.get('interest_at_comment')!=classification.get('interest_at_comment',classification.get('interest')): raise ValueError('Review input differs from source '+str(k))
  flag('compatibility_validation_and_source_124_exact',True,checks)
 for p,rs in sources.items():
  assert len(rs)==M['platforms'][p]['count']; assert len({r['comment_id'] for r in rs})==len(rs)
 # Mandatory real join preflight before deriving full outputs.
 x=sources['xiaohongshu']; joinerrors=[]
 for r in x:
  k=(r['comment_id'],r['customer_uid']); a=rawindex.get(k)
  if not a or hashlib.sha256(a['comment_text'].encode('utf8')).hexdigest()!=r['comment_text_sha256'] or (a.get('note_id') and r.get('note_id') and a['note_id']!=r['note_id']): joinerrors.append(r['comment_id'])
 pre['raw_join_checked_records']=len(x); pre['raw_join_errors']=len(joinerrors)
 if joinerrors: raise ValueError('XHS raw join errors: '+str(joinerrors[:5]))
 def derive(p,r):
  c=r.get('classification',r); k=(r['comment_id'],r['customer_uid'])
  raw=rawindex[k] if p=='xiaohongshu' else None
  ip=(raw.get('ip_location') if raw else r.get('ip_location_raw')) or None
  oldip=c.get('ip_location') if raw else None
  conflict=bool(oldip and ip and oldip!=ip)
  targets=deepcopy(c.get('target_regions') or [])
  wanted=[t for t in targets if isinstance(t,dict) and t.get('relation') in ('desired','preferred','accepted')]
  places=[]; unmapped=[]
  for t in wanted:
   mapped=map_places(t.get('text'))
   if mapped: places.extend(mapped)
   else: unmapped.append(deepcopy(t))
  places=list(dict.fromkeys(places)); ipmap=map_places(ip)
  primary=places if wanted else ipmap
  status=('explicit_location' if places and not unmapped else 'explicit_location_with_unmapped' if places else 'explicit_unmapped' if wanted else 'raw_ip' if ipmap else 'other_ip' if ip else 'unknown')
  plan=c.get('reply_plan') or {}; role=c.get('role'); state=c.get('demand_state'); interest=c.get('interest_at_comment',c.get('interest'))
  if p=='douyin': existing=r.get('mother_reply_text'); oldalt=r.get('alternative_mother_reply_text'); legacy=bool(existing or oldalt)
  else: existing=r.get('reply_text'); oldalt=r.get('alternative_reply_text'); legacy=bool(r.get('reply_variant'))
  original_state=state; original_suitability=plan.get('generic_intro_suitable'); suitability=original_suitability
  reviewed=review_index.get((p,r['comment_id'],r['customer_uid']))
  tone=plan.get('tone'); policy=plan.get('contact_policy',c.get('effective_contact_policy'))
  if reviewed:
   state=reviewed['demand_state']; suitability=reviewed['generic_intro_suitable'] if original_suitability is not False else False
   tone='serious' if tone=='serious' or reviewed['tone']=='serious' else 'normal'
   old_manual=policy in ('manual_review','manual','identity_restricted','unknown') or bool(c.get('contact_manual_review')) or bool(c.get('contact_boundaries'))
   if policy=='no_contact' or reviewed['contact_policy']=='no_contact': policy='no_contact'
   elif old_manual or reviewed['contact_policy']=='manual_review': policy='manual_review'
  eligible=role=='demand' and state=='active_at_comment' and interest in ('high','super_high','medium')
  suitable=(suitability is True or (suitability is None and legacy)) and suitability is not False
  blocked=policy=='no_contact' or bool(c.get('source_version_conflict'))
  draft=(SERIOUS if tone=='serious' else MOTHER) if eligible and suitable and not blocked else None
  awaiting=eligible and suitability is None and not legacy
  return {'platform':p,'comment_id':r['comment_id'],'customer_uid':r['customer_uid'], 'note_id':r.get('note_id'),'video_id':r.get('video_id'),
    'comment_text':raw['comment_text'] if raw else r.get('comment_text'), 'comment_text_sha256':r.get('comment_text_sha256') if raw else r.get('source_comment_sha256'),
    'original_raw_input_file':raw_source[k] if raw else None, 'original_raw_record':raw,
    'source_record':r,'source_store':r.get('source_store'),'source_store_role':'provenance_only',
    'role':role,'demand_state':state,'original_demand_state':original_state,'targeted_compatibility_review':deepcopy(reviewed),'compatibility_review_source':deepcopy(compat) if reviewed else None,'interest_at_comment':interest,'published_at':r.get('comment_published_at') if raw else r.get('published_at'),
    'time_mentions':deepcopy(c.get('time_mentions') or []), 'time_mentions_field_missing':'time_mentions' not in c,
    'target_regions':targets,'explicit_desired_preferred_accepted':wanted,
    'work_current_home_excluded':[t for t in targets if isinstance(t,dict) and t.get('relation') in ('work','current_home','excluded')],
    'original_ip':ip,'original_ip_source':(raw.get('ip_location_source') or 'registered_raw_comment_input') if raw else 'result.ip_location_raw',
    'previous_classification_ip':oldip,'ip_conflict':conflict,'ip_restored_from_raw':bool(raw and ip and not oldip),
    'routing':{'status':status,'primary_regions':primary,'explicit_unmapped':unmapped,'ip_auxiliary_regions':ipmap if wanted else [],'ip_auxiliary_is_confirmed_target':False,'raw_ip_unmapped':ip if ip and not ipmap else None,'province_is_city':False},
    'assigned_store':None,'original_reply':{'text':existing,'alternative_text':oldalt,'variant':r.get('reply_variant'),'status':r.get('text_status',r.get('reply_status'))},
    'semantic_review_reasons':deepcopy(r.get('semantic_review_reasons',[])),'review_reasons':deepcopy(c.get('review_reasons',c.get('needs_review',[]))),
    'contact_boundaries':deepcopy(c.get('contact_boundaries',[])),'contact_policy':policy,'reply_plan':deepcopy(plan),
    'original_reply_missing_facts':deepcopy(r.get('reply_missing_facts',[])), 'unanswered_specific_question':bool(draft) or bool(r.get('reply_unanswered_specific_question')),
    'generic_intro_suitability':suitability,'effective_tone':tone,'requires_AI_intro_suitability':awaiting,'candidate_eligibility':eligible,'legacy_suitability_basis':legacy,
    'mother_reply_text':draft,'alternative_mother_reply_text':None,'reply_status':'本地通用母句备选，未授权发送' if draft else '保留原判与原稿，未生成通用母句',
    'send_authorized':False,'can_send_now':False,'text_task_send_attempted':False,'platform_delivery_state':'not_checked_by_text_task'}
 if compat:
  # Exercise real reviewed records in every material decision class before bulk generation.
  sample_preds={
   'active_suitable':lambda v:v['demand_state']=='active_at_comment' and v['generic_intro_suitable'],
   'unknown':lambda v:v['demand_state']=='unknown',
   'future':lambda v:v['demand_state']=='future',
   'unsuitable':lambda v:not v['generic_intro_suitable'],
   'serious':lambda v:v['tone']=='serious',
   'manual_review':lambda v:v['contact_policy']=='manual_review',
   'xhs_fit':lambda v:v['platform']=='xiaohongshu'}
  pre['compatibility_samples']={}
  for label,predicate in sample_preds.items():
   v=next((v for v in review_index.values() if predicate(v)),None)
   if v is None: raise ValueError('Missing required compatibility edge sample '+label)
   k=(v['platform'],v['comment_id'],v['customer_uid']); z=derive(v['platform'],srcindex[k]);
   ok=z['targeted_compatibility_review']==v and z['demand_state']==v['demand_state']
   if label in ('unknown','future','unsuitable'): ok=ok and z['mother_reply_text'] is None
   if label=='serious' and z['mother_reply_text']: ok=ok and z['mother_reply_text']==SERIOUS
   if label=='manual_review': ok=ok and z['contact_policy'] in ('manual_review','no_contact')
   flag('compatibility_sample_'+label,ok,checks)
   if not ok: raise ValueError('Compatibility preflight failed '+label)
   pre['compatibility_samples'][label]={'platform':v['platform'],'comment_id':v['comment_id'],'customer_uid':v['customer_uid'],'state':z['demand_state'],'candidate':bool(z['mother_reply_text'])}
 # Representative observations before bulk transform, including evidence categories.
 for p,rs in sources.items():
  predicates={
   'high':lambda z:z['interest_at_comment'] in ('high','super_high'),
   'medium':lambda z:z['interest_at_comment']=='medium',
   'supply':lambda z:z['role']=='supply',
   'ended':lambda z:z['demand_state']=='ended',
   'unknown_region':lambda z:z['routing']['status'] in ('unknown','other_ip','explicit_unmapped'),
   'multiple_regions':lambda z:len(z['routing']['primary_regions'])>1,
   'province_ip':lambda z:any(t in ('浙江','四川','福建') for t in z['routing']['primary_regions']) and z['routing']['status']=='raw_ip',
   'ai_disallowed':lambda z:z['generic_intro_suitability'] is False,
   'duplicate_uid':lambda z:uidcounts[z['customer_uid']]>1}
  uidcounts=collections.Counter(r['customer_uid'] for r in rs)
  remaining=set(predicates); found={}
  for r in rs:
   z=derive(p,r)
   for name in list(remaining):
    if predicates[name](z):
     found[name]={'comment_id':z['comment_id'],'customer_uid':z['customer_uid'],'routing':z['routing']['status'],'has_candidate':bool(z['mother_reply_text'])}; remaining.remove(name)
   if not remaining: break
  pre[p]=found; pre[p+'_not_observed']=sorted(remaining)
 # Synthetic edge-case checks use derived copies only and do not modify sources.
 sample=deepcopy(sources['douyin'][0]); sample['comment_id']='synthetic-sample'; sample.update(role='demand',demand_state='active_at_comment',interest_at_comment='high',ip_location_raw='浙江',target_regions=[{'text':'昆山','relation':'desired','quote':'昆山','group_relation':'unknown','condition_scope':None}],reply_plan={'generic_intro_suitable':True,'tone':'normal'},source_version_conflict=False)
 probe=derive('douyin',sample)
 flag('sample_explicit_unmapped_ip_only_auxiliary',probe['routing']['status']=='explicit_unmapped' and not probe['routing']['primary_regions'] and probe['routing']['ip_auxiliary_regions']==['浙江'],checks)
 sample['target_regions']=[{'text':'上海和北京','relation':'desired','quote':'上海和北京','group_relation':'OR','condition_scope':None}]
 flag('sample_multiple_explicit_regions_retained',set(derive('douyin',sample)['routing']['primary_regions'])=={'上海','北京'},checks)
 sample['target_regions']=[]; flag('sample_province_not_mapped_to_city',derive('douyin',sample)['routing']['primary_regions']==['浙江'],checks)
 sample['reply_plan']['generic_intro_suitable']=False; flag('sample_explicit_ai_prohibition',derive('douyin',sample)['mother_reply_text'] is None,checks)
 sample['reply_plan']['generic_intro_suitable']=True; sample['role']='supply'; flag('sample_supply_no_candidate',derive('douyin',sample)['mother_reply_text'] is None,checks)
 sample['role']='demand'; sample['demand_state']='ended'; flag('sample_ended_no_candidate',derive('douyin',sample)['mother_reply_text'] is None,checks)
 fixture=[{'platform':'test','customer_uid':'same','comment_id':'one','role':'demand','demand_state':'active_at_comment','interest_at_comment':'high','published_at':'2024-01-01T00:00:00+00:00','mother_reply_text':MOTHER}, {'platform':'test','customer_uid':'same','comment_id':'two','role':'demand','demand_state':'ended','published_at':'2024-01-02T00:00:00+00:00','mother_reply_text':None}]
 adapter.reconcile_customers(fixture); flag('sample_later_end_moves_draft_to_alternative',fixture[0]['mother_reply_text'] is None and fixture[0]['alternative_mother_reply_text']==MOTHER and bool(fixture[0].get('timeline_review')),checks)
 fixture[0].update(mother_reply_text=MOTHER,alternative_mother_reply_text=None,published_at=None); fixture[1]['published_at']=None
 adapter.reconcile_customers(fixture); flag('sample_unknown_timeline_marked',bool(fixture[0].get('timeline_review')),checks)
 rows={p:[derive(p,r) for r in rs] for p,rs in sources.items()}
 duplicates={p:adapter.reconcile_customers(z) for p,z in rows.items()}
 outputs={}; summaries={}; region_tables={}; store_tables={}
 for p,rr in rows.items():
  src=sources[p]; cmp=lambda z:(z.get('role'),z.get('demand_state'),z.get('interest_at_comment',z.get('interest')))
  flag(p+'_source_classifications_unchanged',all(cmp(r.get('classification',r))==cmp(z['source_record'].get('classification',z['source_record'])) for r,z in zip(src,rr)),checks)
  flag(p+'_role_interest_unchanged',all((cmp(r.get('classification',r))[0],cmp(r.get('classification',r))[2])==(z['role'],z['interest_at_comment']) for r,z in zip(src,rr)),checks)
  flag(p+'_state_changes_only_reviewed',all(z['original_demand_state']==cmp(r.get('classification',r))[1] and (z['demand_state']==z['original_demand_state'] if not z['targeted_compatibility_review'] else z['demand_state']==z['targeted_compatibility_review']['demand_state']) for r,z in zip(src,rr)),checks)
  flag(p+'_source_contact_restrictions_preserved',all(not ((z['source_record'].get('classification',z['source_record']).get('reply_plan') or {}).get('contact_policy')=='no_contact' and z['contact_policy']!='no_contact') for z in rr),checks)
  flag(p+'_review_does_not_relax_manual_restrictions',all(not (z['targeted_compatibility_review'] and (((z['source_record'].get('classification',z['source_record']).get('reply_plan') or {}).get('contact_policy') in ('manual','manual_review','identity_restricted','unknown')) or z['source_record'].get('classification',z['source_record']).get('contact_manual_review') or z['contact_boundaries']) and z['contact_policy'] not in ('manual_review','no_contact')) for z in rr),checks)
  flag(p+'_review_does_not_relax_generic_unsuitable',all(not (z['targeted_compatibility_review'] and (z['source_record'].get('classification',z['source_record']).get('reply_plan') or {}).get('generic_intro_suitable') is False and z['generic_intro_suitability'] is not False) for z in rr),checks)
  flag(p+'_comment_ids_unique',len({r['comment_id'] for r in rr})==len(rr),checks)
  selected=[r for r in rr if r['mother_reply_text']]; flag(p+'_one_selected_per_uid',len({r['customer_uid'] for r in selected})==len(selected),checks)
  flag(p+'_no_ineligible_candidates',all(r['role']=='demand' and r['demand_state']=='active_at_comment' and r['interest_at_comment'] in ('high','super_high','medium') and r['generic_intro_suitability'] is not False for r in rr if r['mother_reply_text'] or r['alternative_mother_reply_text']),checks)
  flag(p+'_approved_mother_only',all(r[k] in (None,MOTHER,SERIOUS) for r in rr for k in ('mother_reply_text','alternative_mother_reply_text')),checks)
  flag(p+'_no_authorization_assignment_or_task_send',all(not r['send_authorized'] and not r['can_send_now'] and r['assigned_store'] is None and not r['text_task_send_attempted'] for r in rr),checks)
  high=[r for r in rr if r['interest_at_comment'] in ('high','super_high')]
  region_tables[p]={}
  for loc in LOCATIONS:
   included=[r for r in high if loc in r['routing']['primary_regions']]
   aux=[r for r in high if r['explicit_desired_preferred_accepted'] and r['routing']['explicit_unmapped'] and loc in r['routing']['ip_auxiliary_regions']]
   region_tables[p][loc]={'high_super_high_comments':len(included),'unique_customer_uids':len({r['customer_uid'] for r in included}), 'comment_ids':[r['comment_id'] for r in included], 'ip_auxiliary_unconfirmed_high_super_high_comments':len(aux),'ip_auxiliary_unconfirmed_unique_uids':len({r['customer_uid'] for r in aux}),'ip_auxiliary_unconfirmed_comment_ids':[r['comment_id'] for r in aux], 'scope':'province_shared_pool_not_city' if loc not in CITY else 'regional_shared_pool_not_store_assignment'}
  store_tables[p]=[{ 'store':s,'region':store_city[s], **{k:v for k,v in region_tables[p][store_city[s]].items() if not k.startswith('ip_auxiliary_unconfirmed_')},'shared_pool':True,'not_additive_across_stores':True,'actual_assignment':False} for s in stores]
  def retained_reason(r):
   if r['mother_reply_text']: return None
   if not (r['original_reply']['text'] or r['original_reply']['alternative_text']): return None
   if r.get('timeline_review') and r['alternative_mother_reply_text']: return 'later_or_unknown_timeline_review'
   if r['alternative_mother_reply_text']: return 'same_customer_duplicate_alternative'
   if r['contact_policy']=='no_contact': return 'no_contact'
   if r['generic_intro_suitability'] is False: return 'generic_intro_unsuitable'
   if r['role']!='demand': return 'role_not_demand'
   if r['demand_state']!='active_at_comment': return 'demand_state_'+str(r['demand_state'])
   if r['interest_at_comment'] not in ('high','super_high','medium'): return 'interest_outside_scope'
   return 'other_existing_hold'
  retained=collections.Counter(x for x in (retained_reason(r) for r in rr) if x)
  summaries[p]={'targeted_compatibility_reviewed':sum(bool(r['targeted_compatibility_review']) for r in rr),'targeted_review_state_counts':canonical_counter(collections.Counter(r['demand_state'] for r in rr if r['targeted_compatibility_review'])),'targeted_review_unsuitable':sum(bool(r['targeted_compatibility_review']) and r['generic_intro_suitability'] is False for r in rr),'unreviewed_original_draft_nonactive':sum(not r['targeted_compatibility_review'] and bool(r['original_reply']['text'] or r['original_reply']['alternative_text']) and r['demand_state']!='active_at_comment' for r in rr),'original_drafts_preserved_not_selected':sum(retained.values()),'original_drafts_preserved_not_selected_reasons':canonical_counter(retained),'records':len(rr),'interest_counts':canonical_counter(collections.Counter(r['interest_at_comment'] for r in rr)),
   'high_super_high_comments':len(high),'high_super_high_unique_uids':len({r['customer_uid'] for r in high}),
   'original_actual_draft_records':sum(bool(r['original_reply']['text']) for r in rr),
   'new_generic_drafts_before_dedup':sum(bool(r['mother_reply_text'] or r['alternative_mother_reply_text']) for r in rr),
   'new_generic_alternatives_after_dedup':sum(bool(r['alternative_mother_reply_text']) for r in rr),
   'selected_local_mother':len(selected),'requires_AI_intro_suitability':sum(r['requires_AI_intro_suitability'] for r in rr),
   'no_raw_ip':sum(not r['original_ip'] for r in rr),'ip_restored':sum(r['ip_restored_from_raw'] for r in rr),'ip_conflicts':sum(r['ip_conflict'] for r in rr),
   'timeline_review':sum(bool(r.get('timeline_review')) for r in rr),'missing_published_at':sum(not r['published_at'] for r in rr),
   'missing_time_mentions':sum(not r['time_mentions'] for r in rr),'routing_status_counts':canonical_counter(collections.Counter(r['routing']['status'] for r in rr)),
   'dedup_alternatives':duplicates[p]}
  path=OUT/(p+'-region-brand-results.jsonl')
  with path.open('w',encoding='utf8',newline='\n') as f:
   for r in rr: f.write(json.dumps(r,ensure_ascii=False,sort_keys=True,separators=(',',':'))+'\n')
  outputs[p]=str(path)
 if compat:
  flag('compatibility_exactly_124_applied',sum(bool(z['targeted_compatibility_review']) for rr in rows.values() for z in rr)==124,checks)
  flag('compatibility_xhs_all_22_applied',sum(bool(z['targeted_compatibility_review']) for z in rows['xiaohongshu'])==22,checks)
 flag('xiaohongshu_raw_join_all',not joinerrors and len(rawindex)==len(x),checks)
 flag('xiaohongshu_expected_raw_ip_3571',sum(bool(z['original_ip']) for z in rows['xiaohongshu'])==3571,checks)
 after={p:sha(p) for p in expected}; flag('input_sha256_after',before==after,checks)
 flag('manifest_catalog_adapter_unchanged',manifest_before==sha(MANIFEST) and catalog_before==sha(M['store_catalog']) and adapter_before==sha(W/'mother_adapter.py'),checks)
 summary={'compatibility_review':{'applied_count':len(review_index),'source':deepcopy(compat) if compat else None},'platforms':summaries,'shared_pool_note':'区域池可跨多个门店共享，不能将门店表相加；不是实际分配或库存承接。','region_counts_include_only_high_super_high':True}
 dump(OUT/'summary.json',summary); dump(OUT/'region-tables.json',region_tables); dump(OUT/'store-shared-pools.json',store_tables)
 hashes={path.name:sha(path) for path in [*(pathlib.Path(x) for x in outputs.values()),OUT/'summary.json',OUT/'region-tables.json',OUT/'store-shared-pools.json']}
 val={'checks':checks,'preflight':pre,'source_sha256_before':before,'source_sha256_after':after,'output_content_sha256':hashes,'all_passed':all(checks.values()),'notes':['原始分类及回复保留于每条 source_record，原始小红书记录保留于 original_raw_record。','备选与选中母句均未授权发送，任务未调用平台；历史发送状态未核查。']}
 dump(OUT/'validation.json',val)
 pointer=OUT/'current.json'
 preserve_newer_root_pointer=OUT==HERE and pointer.exists() and pathlib.Path(json.loads(pointer.read_text(encoding='utf8'))['manifest']).resolve()!=MANIFEST
 if not preserve_newer_root_pointer: dump(pointer,{'version':'region-brand-sidecars-v1','manifest':str(MANIFEST),'manifest_sha256':manifest_before,'input_sha256':before,'result_sha256':hashes,'platform_statistics':summaries,'compatibility_review':summary['compatibility_review'],'results':outputs,'summary':str(OUT/'summary.json'),'validation':str(OUT/'validation.json'),'region_tables':str(OUT/'region-tables.json'),'store_shared_pools':str(OUT/'store-shared-pools.json')})
 print(json.dumps({'summaries':summaries,'checks':checks,'preflight':pre,'hashes':hashes},ensure_ascii=False,indent=2))
 if not all(checks.values()): raise SystemExit(1)
if __name__=='__main__':
 build()
 if not args.internal_idempotence_pass:
  files=['douyin-region-brand-results.jsonl','xiaohongshu-region-brand-results.jsonl','summary.json','region-tables.json','store-shared-pools.json','current.json']
  first={f:sha(OUT/f) for f in files}
  run=subprocess.run([sys.executable,str(pathlib.Path(__file__).resolve()),'--manifest',str(MANIFEST),'--output-dir',str(OUT),'--internal-idempotence-pass'],capture_output=True,text=True,encoding='utf8')
  second={f:sha(OUT/f) for f in files}
  validation=json.loads((OUT/'validation.json').read_text(encoding='utf8'))
  validation['checks']['repeat_run_succeeded']=run.returncode==0
  validation['checks']['repeat_run_content_hashes_identical']=first==second
  validation['idempotence']={'first_run_sha256':first,'second_run_sha256':second,'repeat_exit_code':run.returncode}
  validation['all_passed']=all(validation['checks'].values())
  dump(OUT/'validation.json',validation)
  if not validation['all_passed']: raise SystemExit('Repeat validation failed: '+run.stderr)
  print('Repeat run checks: PASS')

