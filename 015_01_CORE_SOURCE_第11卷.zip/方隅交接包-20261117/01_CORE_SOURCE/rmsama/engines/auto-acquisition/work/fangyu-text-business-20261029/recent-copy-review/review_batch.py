"""Bounded mother-family revision; original CSV and sending receipts untouched."""
import csv,json,hashlib,collections,re
from pathlib import Path
from datetime import datetime,timezone
W=Path(__file__).resolve().parents[1];ROOT=W.parents[1];HERE=Path(__file__).resolve().parent
SOURCE=ROOT/'outputs/抖音近期候选分类池-20261104.csv'
OUT=ROOT/'outputs/方隅双平台文本业务/近期373条文案复核';OUT.mkdir(parents=True,exist_ok=True)
def sha(b):return hashlib.sha256(b).hexdigest()
before=SOURCE.read_bytes();source_rows=list(csv.DictReader(before.decode('utf-8-sig').splitlines()))
by=collections.defaultdict(list)
canonical=W/'douyin-semantic-repair-v5/douyin-replies.jsonl'
for line in canonical.open(encoding='utf-8-sig'):
 r=json.loads(line);by[(r.get('comment_text'),r.get('original_comment_date') or r.get('published_at'))].append(r)
templates={
 'price':'宝宝，租金可以了解下方隅公寓，我介绍有优惠。',
 'price_contact':'宝宝，想了解租金可以聊聊方隅公寓，我介绍有优惠。',
 'location':'宝宝，可以看看方隅公寓，你想找哪个区域呀？我介绍有优惠。',
 'location_known':'宝宝，找{place}的话，可以了解方隅公寓的位置，我介绍有优惠。',
 'lease':'宝宝，租期可以了解下方隅公寓，我介绍有优惠。',
 'short_lease':'宝宝，短租可以了解下方隅公寓的租期，我介绍有优惠。',
 'month_lease':'宝宝，月租可以了解下方隅公寓的租期，我介绍有优惠。',
 'contact':'宝宝，想租房可以聊聊方隅公寓，我介绍有优惠。',
 'cat':'宝宝，带猫找房可以了解下方隅公寓，我介绍有优惠。',
 'parking':'宝宝，停车费用可以了解下方隅公寓，我介绍有优惠。',
 'brand':'宝宝，是方隅公寓，我介绍有优惠。',
 'registered_address':'宝宝，注册地址这项要单独确认，方隅公寓是否适用还不能确定。',
 'location_choice':'宝宝，大红门和菜户营这两个位置，你更看重通勤还是预算？',
}
out=[]
for s in source_rows:
 matches=by[(s['评论原文'],s['原评论时间'])];assert len(matches)==1,(s['顺位'],len(matches))
 r=matches[0];t=s['评论原文'];old=s['拟回复文案'];family='preserved';draft=old;gaps=[];holds=[]
 if '充电' in old and '充电' not in t:family='parking'
 elif '我住' in old:
  if '可注册地址' in t:family='registered_address';gaps.append('注册地址用途是否允许')
  elif '大红门' in t and '菜户营' in t:family='location_choice'
  elif '能带猫' in old:family='cat';gaps.append('具体适用房源携宠政策')
  elif '租期挺灵活' in old:
   family='short_lease' if '短租' in t or '一两个月' in t else 'month_lease' if '月租' in t else 'lease'
   gaps.append('客户期望租期及具体房源起租条件')
  elif '价格挺合适' in old:family='price_contact' if '有想了解' in old else 'price';gaps.append('当前报价和客户预算匹配未确认')
  elif '你想找哪边' in old:
   family='location';places=[p for p in ['宝山','闵行','七宝','拱墅','杭州'] if p in t]
   if places:family='location_known'
   gaps.append('不回答或冒认原帖子房源地址')
  elif '我住的是' in old:family='brand'
  else:family='contact'
 if family!='preserved':draft=templates[family].format(place='、'.join(places) if family=='location_known' else '')
 if family in ('registered_address','location_choice'):holds.append('新增特殊场景母句待审阅')
 if '房东' in t and re.search(r'联系|微信|给介绍|中介',t):holds.append('客户指定房东身份或渠道，发送账号身份未核实')
 fit=r.get('commercial_fit') or {}
 if fit.get('eligible_candidate') is not True:holds.append('原商业适配筛选未放行')
 if r.get('contact_boundaries') or (r.get('reply') or {}).get('contact_hold'):holds.append('保留原联系限制')
 if '我介绍有优惠' in draft:gaps.append('沿用用户认可优惠口气；发送账号介绍优惠资格和当前适用范围需核实')
 status='draft_review_hold' if holds else 'draft_revised_not_send_authorized'
 entry=dict(source_row=s,comment_id=r['comment_id'],customer_uid=r.get('customer_uid'),comment_text=t,comment_text_sha256=sha(t.encode()),original_comment_time=s['原评论时间'],prior_reply=old,revised_reply=draft,reply_sha256=sha(draft.encode()),mother_family=family,changed=draft!=old,pools=r.get('pools'),commercial_fit=fit,contact_boundaries=r.get('contact_boundaries'),needs_currentness_review=r.get('needs_currentness_review'),fact_gaps=gaps,holds=holds,status=status,source_csv_sha256=sha(before),version='recent373-copy-v1-20261104',user_individually_approved=False,send_authorized=False,model_reply_rewrite_calls=0)
 out.append(entry)
assert len(out)==373 and len({r['comment_id'] for r in out})==373
assert all('我住' not in r['revised_reply'] for r in out)
assert all('充电' not in r['revised_reply'] or '充电' in r['comment_text'] for r in out)
assert sha(SOURCE.read_bytes())==sha(before)
jpath=HERE/'reviewed-373.jsonl';jpath.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in out),encoding='utf-8')
csvpath=OUT/'373条原评与修订回复.csv'
with csvpath.open('w',encoding='utf-8-sig',newline='') as f:
 writer=csv.DictWriter(f,fieldnames=['顺位','原评论时间','时效档','预算证据','评论原文','原拟回复','修订回复','复核状态','待核事项']);writer.writeheader()
 for r in out:
  s=r['source_row'];writer.writerow({'顺位':s['顺位'],'原评论时间':s['原评论时间'],'时效档':s['时效档'],'预算证据':s['预算证据'],'评论原文':r['comment_text'],'原拟回复':r['prior_reply'],'修订回复':r['revised_reply'],'复核状态':'待复核' if r['holds'] else '已修订草稿，尚未发送','待核事项':'；'.join(r['holds']+r['fact_gaps'])})
manifest={'version':'recent373-copy-v1-20261104','created_at':datetime.now(timezone.utc).isoformat(),'source':str(SOURCE),'source_sha256':sha(before),'source_unchanged':True,'total':373,'changed':sum(r['changed'] for r in out),'unchanged':sum(not r['changed'] for r in out),'identity_claims_removed':sum('我住' in r['prior_reply'] for r in out),'unasked_charging_removed':sum('充电' in r['prior_reply'] and '充电' not in r['comment_text'] for r in out),'exact_text_and_time_unique_cid_matches':373,'review_holds':sum(bool(r['holds']) for r in out),'families':dict(collections.Counter(r['mother_family'] for r in out)),'output':str(jpath),'output_sha256':sha(jpath.read_bytes()),'human_csv':str(csvpath),'human_csv_sha256':sha(csvpath.read_bytes()),'entire_corpus_replaced':False,'send_authorized':False,'existing_user_send_hold_not_released':True,'per_comment_AI_reply_calls':0}
(HERE/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(manifest,ensure_ascii=False))
