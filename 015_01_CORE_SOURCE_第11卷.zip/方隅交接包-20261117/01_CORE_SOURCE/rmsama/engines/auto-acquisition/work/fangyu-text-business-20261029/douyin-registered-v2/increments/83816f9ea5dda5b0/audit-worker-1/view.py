import json,pathlib,collections,sys
B=pathlib.Path(__file__).resolve().parent.parent
x=json.loads((B/'recall-audit/part-1'/('page-%02d.json'%int(sys.argv[1]))).read_text(encoding='utf-8'))
enc=lambda v:json.dumps(v,ensure_ascii=False,separators=(',',':'))
cs=[c for g in x['post_groups'] for c in g['comments']]
base={k:json.loads(collections.Counter(enc(c['first_semantic_judgment'][k]) for c in cs).most_common(1)[0][0]) for k in cs[0]['first_semantic_judgment']}
basec={k:json.loads(collections.Counter(enc(c[k]) for c in cs).most_common(1)[0][0]) for k in ('same_author','parent','reply_to','source_conflict')}
print('BASE_J '+enc(base));print('BASE_C '+enc(basec))
start=int(sys.argv[2]) if len(sys.argv)>2 else 0;end=int(sys.argv[3]) if len(sys.argv)>3 else len(cs)
i=0
for g in x['post_groups']:
 included=[c for c in g['comments'] if start<=cs.index(c)<end]
 if not included:continue
 print('BODY '+enc({k:v for k,v in g.items() if k!='comments'}))
 for c in included:
  j=c['first_semantic_judgment']
  print(enc([c['key'],c['text'],c['published_at'],{k:c[k] for k in basec if c[k]!=basec[k]},{k:v for k,v in j.items() if v!=base[k]}]))
