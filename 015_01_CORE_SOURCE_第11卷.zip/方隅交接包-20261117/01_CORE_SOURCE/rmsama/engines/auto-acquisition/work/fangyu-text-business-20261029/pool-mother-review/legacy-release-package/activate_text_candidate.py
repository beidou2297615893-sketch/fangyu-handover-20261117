"""Text pointer release, defaults to read-only dry run. Requires verified v2 Astra gate."""
import argparse,copy,hashlib,json,os,pathlib,shutil,sys,tempfile,datetime
sys.dont_write_bytecode=True
import build_consumer_bridge as bridge
O=pathlib.Path(__file__).resolve().parent;W=O.parents[1];B=O/'consumer-bridge-v2';C=O/'candidate-repaired-v2';V2=W/'pool-mother-review/legacy-release-repairs-v2';GATE_DIR=W/'pool-mother-review/legacy-final-semantic-review-v2';VERS=O/'published-versions'
READY='23eb7616b5d7ad5962acd780060142cc6c01275ee18070abfe2c9e9670f95497';CONTRACT='a7c6193ba4145ff1246e69eb17f836436369eaef0f316828eaee303e95cdffae'
def sha(p):
 h=hashlib.sha256()
 with pathlib.Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def read(p):return json.loads(pathlib.Path(p).read_text(encoding='utf8'))
def bytes_json(x):return (json.dumps(x,ensure_ascii=False,sort_keys=True,indent=2)+'\n').encode('utf8')
def hbytes(b):return hashlib.sha256(b).hexdigest()
def validate_gate_record(g,ready,contract,plans):
 if not isinstance(g,dict):raise ValueError('independent Astra v2 gate missing')
 # Fail closed until an independently produced gate explicitly binds this version.
 if g.get('status')!='pass' or g.get('reviewer_model')!='gpt-6-astra' or g.get('source_repairs_v2_READY_SHA')!=ready or g.get('source_contract_SHA')!=contract or g.get('source_merged_plans_SHA')!=plans or g.get('review_scope')!='bounded_template_version_not_individual_approval':raise ValueError('Astra v2 gate status/model/scope/source binding invalid')
 if not isinstance(g.get('files_sha256'),dict) or not g['files_sha256']:raise ValueError('gate has no independently verifiable evidence files')
def validate_flags(r):
 if r.get('send_authorized') is not False or r.get('can_send_now') is not False:raise ValueError('send flags not false')
 m=r.get('consumer_draft_metadata')
 if m and (m.get('send_authorized') is not False or m.get('can_send_now') is not False):raise ValueError('draft permission changed')
def check_previous(region,reply,expected_region,expected_reply):
 if sha(region)!=expected_region or sha(reply)!=expected_reply:raise ValueError('previous pointer SHA mismatch; stop')
def atomic_bytes(path,data):
 path=pathlib.Path(path);fd,name=tempfile.mkstemp(prefix=path.name+'.pending-',dir=str(path.parent))
 try:
  with os.fdopen(fd,'wb') as f:f.write(data);f.flush();os.fsync(f.fileno())
  os.replace(name,path)
 finally:
  if os.path.exists(name):os.unlink(name)
def swap_pair(region,reply,expected_region,expected_reply,new_region,new_reply):
 region=pathlib.Path(region);reply=pathlib.Path(reply)
 if region.read_bytes()!=expected_region or reply.read_bytes()!=expected_reply:raise ValueError('pointer baseline changed')
 atomic_bytes(region,new_region)
 try:
  if reply.read_bytes()!=expected_reply:raise ValueError('reply pointer changed during commit')
  atomic_bytes(reply,new_reply)
  if region.read_bytes()!=new_region or reply.read_bytes()!=new_reply:raise ValueError('pointer readback mismatch')
 except Exception:
  if region.read_bytes()==new_region:atomic_bytes(region,expected_region)
  raise
def check_gate(path,expected,plans_sha):
 path=pathlib.Path(path).resolve()
 if path!=GATE_DIR/'manifest.json' or not path.exists() or not expected or sha(path)!=expected:raise ValueError('Astra v2 gate file missing or SHA mismatch')
 gate=read(path);validate_gate_record(gate,READY,CONTRACT,plans_sha)
 for name,h in gate['files_sha256'].items():
  f=(path.parent/name).resolve()
  if path.parent not in f.parents or not f.is_file() or sha(f)!=h:raise ValueError('Astra gate evidence SHA mismatch: '+name)
 return gate
def preflight(gate_path,gate_sha):
 cm=read(C/'candidate-manifest.json');bc=read(B/'current.json');bp=read(B/'main-reply-pointer.json');br=read(B/'bridge-receipt.json');v=read(O/'consumer-bridge-validation-v2.json')
 if not v['technical_checks_passed'] or cm['status']!='candidate_only_needs_independent_astra_semantic_gate' or bc['semantic_gate_passed'] or bp['template_version_semantic_gate_passed']:raise ValueError('candidate not in expected pending state')
 if sha(V2/'READY.json')!=READY or sha(V2/'repair-contract.json')!=CONTRACT or br['candidate_manifest_sha256']!=sha(C/'candidate-manifest.json'):raise ValueError('candidate lineage mismatch')
 for path,h in cm['immutable_input_sha256_before'].items():
  if sha(path)!=h:raise ValueError('immutable source SHA mismatch '+path)
 for name,h in cm['output_sha256'].items():
  if sha(C/name)!=h:raise ValueError('candidate output SHA mismatch '+name)
 for name,h in br['bridge_artifact_sha256'].items():
  if sha(B/name)!=h:raise ValueError('bridge artifact SHA mismatch '+name)
 for plat in ('douyin','xiaohongshu'):
  if sha(B/(plat+'-region-brand-results.jsonl'))!=bc['result_sha256'][plat] or sha(bc['results'][plat])!=bp['platforms'][plat]['reply_sidecar_sha256']:raise ValueError('bridge sidecar hash mismatch')
  classified=bp['platforms'][plat]
  if sha(classified['classification_file'])!=classified['classification_sha256']:raise ValueError('classification SHA changed')
  ids=set();uids=set();count=0
  with (B/(plat+'-region-brand-results.jsonl')).open(encoding='utf8') as f,(C/(plat+'-candidate.jsonl')).open(encoding='utf8') as source:
   for line,original in zip(f,source,strict=True):
    r=json.loads(line);original_row=json.loads(original);count+=1;validate_flags(r)
    if bridge.restore_metadata(r)!=original_row:raise ValueError('candidate identity or source record changed')
    cid=r['comment_id']
    if cid in ids:raise ValueError('duplicate CID')
    ids.add(cid)
    if r.get('mother_reply_text'):
     if r['customer_uid'] in uids:raise ValueError('duplicate selected UID')
     uids.add(r['customer_uid'])
  if count!=classified['classified_comments'] or len(uids)!=classified['selected_brand_mother_drafts']:raise ValueError('classification or selected counts changed')
 region=W/'region-brand-routing/current.json';reply=W/'当前双平台回复结果指针.json';check_previous(region,reply,cm['expected_previous_region_pointer_sha256'],cm['expected_previous_reply_pointer_sha256'])
 if sha(W/'region-brand-routing/latest-manifest.json')!=cm['expected_previous_latest_manifest_sha256']:raise ValueError('latest manifest baseline changed')
 for name,h in cm['immutable_baseline_sha256'].items():
  if sha(C/'immutable-baseline'/name)!=h:raise ValueError('immutable snapshot mismatch')
 gate=check_gate(gate_path,gate_sha,sha(C/'merged-plans.jsonl'))
 return {'candidate_manifest_sha256':sha(C/'candidate-manifest.json'),'bridge_current_sha256':sha(B/'current.json'),'gate_sha256':gate_sha,'region_before_sha256':sha(region),'reply_before_sha256':sha(reply),'latest_manifest_before_sha256':sha(W/'region-brand-routing/latest-manifest.json'),'source_contract_sha256':CONTRACT,'source_plans_sha256':sha(C/'merged-plans.jsonl'),'status':'all_preflight_checks_passed','gate_scope':gate['review_scope']}
def materialize(pre,gate_path):
 VERS.mkdir(exist_ok=True);dest=VERS/('text-'+pre['bridge_current_sha256'][:16]+'-'+pre['gate_sha256'][:12]);dest.mkdir(exist_ok=False)
 for n in ('merged-contract.json','merged-plans.jsonl','all-family-matrix.jsonl','v2-draft-change-ledger.jsonl','published-fix-annotations.jsonl'):
  shutil.copyfile(C/n,dest/n)
  if sha(dest/n)!=sha(C/n):raise ValueError('version copy SHA mismatch '+n)
 snap=dest/'immutable-baseline';shutil.copytree(C/'immutable-baseline',snap)
 gate=read(gate_path);gd=dest/'semantic-review';gd.mkdir();shutil.copyfile(gate_path,gd/'manifest.json')
 for n,h in gate['files_sha256'].items():
  source=(pathlib.Path(gate_path).parent/n).resolve();target=gd/n;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,target)
  if sha(target)!=h:raise ValueError('copied gate evidence mismatch')
 bc=read(B/'current.json');summary=read(B/'summary.json');manifest=read(B/'manifest.json');validation=read(B/'validation.json');wrapper=read(B/'main-reply-pointer.json')
 for plat in ('douyin','xiaohongshu'):
  source=B/(plat+'-region-brand-results.jsonl');target=dest/(plat+'-region-brand-results.jsonl')
  with source.open(encoding='utf8') as f,target.open('w',encoding='utf8',newline='\n') as out:
   for line in f:
    r=json.loads(line);validate_flags(r);before=copy.deepcopy(r);m=r.get('consumer_draft_metadata')
    if m:
     if m.get('template_version_semantic_gate_passed') is not False:raise ValueError('unexpected initial gate state')
     m['template_version_semantic_gate_passed']=True;m['review_scope']='bounded_template_version_semantic_gate_passed; individual_record_not_asserted_reviewed'
     verify=copy.deepcopy(r);verify['consumer_draft_metadata']['template_version_semantic_gate_passed']=False;verify['consumer_draft_metadata']['review_scope']=before['consumer_draft_metadata']['review_scope']
     if verify!=before:raise ValueError('unexpected materialization change')
    out.write(json.dumps(r,ensure_ascii=False,sort_keys=True,separators=(',',':'))+'\n')
 for field,name in [('region_tables','region-tables.json'),('store_shared_pools','store-shared-pools.json')]:
  original=pathlib.Path(bc[field]);shutil.copyfile(original,dest/name)
  if sha(dest/name)!=sha(original):raise ValueError('version copy SHA mismatch '+name)
  bc[field]=str(dest/name)
 scope=summary['legacy_pool_short_scope'];scope.update(status='bounded_template_version_semantic_gate_passed',semantic_gate_passed=True,individually_reviewed_all=False);(dest/'summary.json').write_bytes(bytes_json(summary))
 validation.update(semantic_gate_passed=True,template_version_semantic_gate_passed=True,semantic_review_scope=gate['review_scope'],activation_permitted=True);(dest/'validation.json').write_bytes(bytes_json(validation))
 info=manifest['legacy_repaired_candidates'];info.update(repair_contract_file=str(dest/'merged-contract.json'),repair_contract_sha256=sha(dest/'merged-contract.json'),plans_file=str(dest/'merged-plans.jsonl'),plans_sha256=sha(dest/'merged-plans.jsonl'),delta_ledger_sha256=sha(dest/'v2-draft-change-ledger.jsonl'),semantic_gate_passed=True,semantic_gate_scope=gate['review_scope'],v2_patch_status='loaded_and_version_gate_passed',previous_region_pointer_snapshot=str(snap/'region-current.json'),previous_region_pointer_snapshot_sha256=sha(snap/'region-current.json'),semantic_review_manifest=str(gd/'manifest.json'),semantic_review_manifest_sha256=sha(gd/'manifest.json'),send_authorized=False);(dest/'manifest.json').write_bytes(bytes_json(manifest))
 bc.update(version='local_text_repaired_v2_gate_passed',manifest=str(dest/'manifest.json'),manifest_sha256=sha(dest/'manifest.json'),summary=str(dest/'summary.json'),validation=str(dest/'validation.json'),results={p:str(dest/(p+'-region-brand-results.jsonl')) for p in ('douyin','xiaohongshu')},platform_statistics=summary['platforms'],activation_permitted=True,semantic_gate_passed=True,legacy_repaired_candidates=info)
 bc['result_sha256']={p:sha(dest/(p+'-region-brand-results.jsonl')) for p in ('douyin','xiaohongshu')};bc['result_sha256'].update({'summary.json':sha(dest/'summary.json'),'region-tables.json':sha(dest/'region-tables.json'),'store-shared-pools.json':sha(dest/'store-shared-pools.json')})
 wrapper.update(version='local_text_repaired_v2_gate_passed',region_version_pointer=str((W/'region-brand-routing/current.json').resolve()),activation_permitted=True,template_version_semantic_gate_passed=True,semantic_review_scope=gate['review_scope'],send_authorized=False)
 for plat in ('douyin','xiaohongshu'):
  wrapper['platforms'][plat]['reply_sidecar_file']=bc['results'][plat];wrapper['platforms'][plat]['reply_sidecar_sha256']=bc['result_sha256'][plat];wrapper['platforms'][plat]['send_authorized']=False
 (dest/'prepared-region-current.json').write_bytes(bytes_json(bc));(dest/'prepared-main-reply-pointer.json').write_bytes(bytes_json(wrapper))
 for plat in ('douyin','xiaohongshu'):
  if sha(bc['results'][plat])!=wrapper['platforms'][plat]['reply_sidecar_sha256']:raise ValueError('materialized sidecar SHA mismatch')
 return dest,bc,wrapper
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--apply',action='store_true');ap.add_argument('--gate',default=str(GATE_DIR/'manifest.json'));ap.add_argument('--gate-sha');ap.add_argument('--readers-quiesced',action='store_true');ap.add_argument('--rollback-receipt');args=ap.parse_args()
 if args.rollback_receipt:
  if args.apply and not args.readers_quiesced:raise ValueError('rollback apply requires --readers-quiesced')
  rp=pathlib.Path(args.rollback_receipt).resolve()
  if VERS.resolve() not in rp.parents or rp.name!='publish-receipt.json':raise ValueError('rollback receipt outside version directory')
  rec=read(rp);dest=rp.parent;region=W/'region-brand-routing/current.json';reply=W/'当前双平台回复结果指针.json';check_previous(region,reply,rec['region_after_sha256'],rec['reply_after_sha256']);oldr=(dest/'immutable-baseline/region-current.json').read_bytes();oldp=(dest/'immutable-baseline/reply-pointer.json').read_bytes()
  if hbytes(oldr)!=rec['region_before_sha256'] or hbytes(oldp)!=rec['reply_before_sha256']:raise ValueError('rollback snapshot hash mismatch')
  if not args.apply:
   print(json.dumps({'mode':'rollback_dry_run','would_restore_region_sha256':hbytes(oldr),'would_restore_reply_sha256':hbytes(oldp),'applied':False}));return
  lock=O/'text-activation.lock'
  with lock.open('x',encoding='utf8') as lf:lf.write('two-pointer text-only rollback\\n')
  try:
   check_previous(region,reply,rec['region_after_sha256'],rec['reply_after_sha256']);swap_pair(region,reply,region.read_bytes(),reply.read_bytes(),oldr,oldp);(dest/'rollback-receipt.json').write_bytes(bytes_json({'status':'rolled_back_text_pointers_only','region_sha256':sha(region),'reply_sha256':sha(reply),'runtime_state_or_classification_modified':False}));print('rollback complete')
  finally:lock.unlink(missing_ok=True)
  return
 pre=preflight(args.gate,args.gate_sha)
 if not args.apply:print(json.dumps({'mode':'dry_run','preflight':pre,'applied':False},ensure_ascii=False));return
 if not args.readers_quiesced:raise ValueError('apply requires --readers-quiesced; pointer pair is not atomic')
 lock=O/'text-activation.lock'
 with lock.open('x',encoding='utf8') as lf:
  lf.write('two-pointer text-only activation\n');lf.flush()
 try:
  dest,bc,wrapper=materialize(pre,args.gate);pre_after_copy=preflight(args.gate,args.gate_sha)
  if pre_after_copy!=pre:raise ValueError('source or gate changed during materialization')
  region=W/'region-brand-routing/current.json';reply=W/'当前双平台回复结果指针.json';check_previous(region,reply,pre['region_before_sha256'],pre['reply_before_sha256']);oldr=region.read_bytes();oldp=reply.read_bytes();newr=bytes_json(bc);newp=bytes_json(wrapper)
  pending={'status':'prepared_not_activated','gate_sha256':pre['gate_sha256'],'region_before_sha256':hbytes(oldr),'reply_before_sha256':hbytes(oldp),'region_planned_sha256':hbytes(newr),'reply_planned_sha256':hbytes(newp),'version_dir':str(dest),'send_authorized':False};(dest/'precommit-receipt.json').write_bytes(bytes_json(pending))
  swap_pair(region,reply,oldr,oldp,newr,newp)
  try:
   rec={'status':'text_pointers_activated','gate_sha256':pre['gate_sha256'],'region_before_sha256':hbytes(oldr),'reply_before_sha256':hbytes(oldp),'region_after_sha256':sha(region),'reply_after_sha256':sha(reply),'version_dir':str(dest),'classification_or_runtime_or_receipts_modified':False,'send_authorized':False};(dest/'publish-receipt.json').write_bytes(bytes_json(rec))
  except Exception:
   if region.read_bytes()==newr and reply.read_bytes()==newp:swap_pair(region,reply,newr,newp,oldr,oldp)
   raise
  print(json.dumps(rec,ensure_ascii=False))
 finally:lock.unlink(missing_ok=True)
if __name__=='__main__':
 try:main()
 except Exception as e:print('REFUSED: '+str(e),file=sys.stderr);sys.exit(2)
