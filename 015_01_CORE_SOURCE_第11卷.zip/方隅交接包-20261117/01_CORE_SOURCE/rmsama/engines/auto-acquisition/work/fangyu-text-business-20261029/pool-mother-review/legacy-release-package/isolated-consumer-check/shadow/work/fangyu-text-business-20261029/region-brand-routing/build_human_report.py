"""Business exports from immutable classification and region/mother sidecars."""
from pathlib import Path
import json, csv, hashlib, collections, datetime

D = Path(__file__).resolve().parent
W = D.parent
ROOT = W.parents[1]
OUT = ROOT / 'outputs/方隅双平台文本业务/地区归类与品牌母句'
OUT.mkdir(parents=True, exist_ok=True)
cur = json.loads((D/'current.json').read_text(encoding='utf-8'))
summary = json.loads(Path(cur['summary']).read_text(encoding='utf-8'))
regions = json.loads(Path(cur['region_tables']).read_text(encoding='utf-8'))
stores = json.loads(Path(cur['store_shared_pools']).read_text(encoding='utf-8'))
now = datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=8)))
names = {'douyin':'抖音', 'xiaohongshu':'小红书'}
labels = {'high':'高意向','super_high':'超高意向','medium':'中意向','uncertain':'信息不足待核','low':'低意向','very_low':'很低意向','unrelated':'供给、无关或非本人求租'}
state_labels = {'active_at_comment':'评论时有需求，当前另核','ended':'需求已结束，保留记录','future':'未来计划，保留跟进','historical':'历史需求，另核当前','unknown':'需求状态待核',None:'旧记录缺状态，保留原判断'}
rows = {}
for p, f in cur['results'].items():
    raw = Path(f).read_bytes()
    expected = cur['result_sha256'].get(p, cur['result_sha256'].get(Path(f).name))
    assert expected and hashlib.sha256(raw).hexdigest() == expected
    rows[p] = [json.loads(x) for x in raw.decode('utf-8').splitlines() if x]

def text_of(value):
    if isinstance(value, dict):
        return str(value.get('quote') or value.get('text') or '')
    return str(value or '')

def region_note(row):
    wanted = row['explicit_desired_preferred_accepted']
    if wanted:
        return '客户明示：'+'；'.join(text_of(x) for x in wanted)
    return '按评论IP归地区；未明示求租地' if row['original_ip'] else '客户地点及IP均未明确'

def age_bucket(value):
    try:
        t = datetime.datetime.fromisoformat(str(value).replace('Z','+00:00'))
        if not t.tzinfo: return '日期时区待核'
        age = (now.date()-t.astimezone(now.tzinfo).date()).days
        return '日期晚于本次核对，待核' if age < 0 else '近7天' if age <= 7 else '8至30天前' if age <= 30 else '31至90天前' if age <= 90 else '90天以上'
    except (ValueError,TypeError):
        return '日期待核'

def write_csv(name, headers, values):
    with (OUT/name).open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.writer(f);w.writerow(headers);w.writerows(values)

def pool_union(p, region_names):
    keep = [r for r in rows[p] if r['interest_at_comment'] in ('high','super_high') and any(x in r['routing']['primary_regions'] for x in region_names)]
    aux = [r for r in rows[p] if r['interest_at_comment'] in ('high','super_high') and r['routing']['explicit_unmapped'] and any(x in r['routing']['ip_auxiliary_regions'] for x in region_names)]
    return len(keep),len({r['customer_uid'] for r in keep}),len(aux),len({r['customer_uid'] for r in aux})

human = ['# 双平台进度、地区归类和品牌母句', '', f'核对时间：{now:%Y年%m月%d日 %H:%M}。两平台分别记账，未把同一客户的多条评论当成多个人。', '',
 '已按最新口径执行：客户说了求租地点，保留他说的地点；没说的按评论IP归区域。回复统一称“方隅公寓”，不主动带古北等具体店名，不等待各店最低预算、租期或库存口径。', '',
 '| 平台 | 已分类评论 | 高及超高意向评论 | 高及超高意向人数 | 新版通用母句去重后选中 | 母句适配待核 |', '|---|---:|---:|---:|---:|---:|']
for p in names:
    s=summary['platforms'][p]
    human.append(f"| {names[p]} | {s['records']:,} | {s['high_super_high_comments']:,} | {s['high_super_high_unique_uids']:,} | {s['selected_local_mother']:,} | {s['requires_AI_intro_suitability']:,} |")
human += ['', '选中的母句包含中意向需求，所以数量可以大于高意向人数；它们是本地草稿。客户当前是否仍在找、联系限制及已有回执仍分开保留，本窗口没有发送。', '',
 '高意向是评论发表时的需求判断，不等于已经确认今天仍在找房。供给、结束、未来计划和信息不足分别保留，未用IP或旧日期机械删除。', '', '## 抖音进度', '']
dy_source=json.loads((ROOT/'work/fangyu-douyin-independent/text-screening-current-summary.json').read_text(encoding='utf-8'))
assert dy_source['snapshot_unique_comments']==summary['platforms']['douyin']['records']
source_rows=[r['source_record'] for r in rows['douyin']]
dual=sum({'initial_semantic','detailed_semantic'}.issubset(set(r.get('classification_stages_completed',[]))) for r in source_rows)
indep=sum(r.get('independent_recall_reviewed') is True for r in source_rows)
human += [f"已发布 {len(source_rows):,} 条、{dy_source['unique_customers']:,} 个客户账号。其中新增流程的AI初筛、细筛完成 {dual:,} 条；另 {len(source_rows)-dual:,} 条历史初判保留，没有把历史初判冒充新增双筛。独立语义复核累计标记 {indep:,} 条。", '',
 '最近4380条已完成初筛、细筛；其中3505条经过独立语义复核。跨分片发现的同文判断分歧已裁决后合入。', '']
check_path=W/'last-registered-delta-check.json'
if check_path.exists():
    ck=json.loads(check_path.read_text(encoding='utf-8'))
    human += [f"最近一次只读核对：登记共 {ck['all_registered_comments']:,} 条，合格租房来源 {ck['eligible_registered_comments']:,} 条，排除已知不属本轮租房范围的 {ck['out_of_scope_comments']} 条；当时尚未发布的合格新增为 {ck['pending_registered_comments']} 条。该数字是核对时的快照。", '']
human += [f"原版已配母句 {dy_source['local_mother_drafts']:,} 条保留；本次另外整理无具体店名的新版。两版适用状态和去重结果分别记录，没有覆盖旧稿。", '',
 '## 小红书进度', '',
 '采集保持暂停。原2755条及后来新增846条合计3601条均有分类记录，合计3144个客户账号。原版709条已配母句保留，新版统一改用无具体店名的已认可基础母句。', '',
 f"原采集文件有IP的 {3601-summary['platforms']['xiaohongshu']['no_raw_ip']:,} 条。按评论、客户和原文核对，补回旧分类汇总缺失的 {summary['platforms']['xiaohongshu']['ip_restored']:,} 条IP，冲突 {summary['platforms']['xiaohongshu']['ip_conflicts']} 条；{summary['platforms']['xiaohongshu']['no_raw_ip']} 条原采集记录本来没有IP，单独保留。", '',
 '## 地区候选分布', '',
 '下表是高及超高意向的地区候选；明示地点还没能定位的，单列IP辅助。浙江、四川和福建的省级IP不硬当成杭州、成都或福州。同一客户可能表达多个地区，地区行不能直接相加。', '',
 '| 地区 | 抖音评论／人数 | 抖音明示地点待定位，IP辅助评论／人数 | 小红书评论／人数 | 小红书明示地点待定位，IP辅助评论／人数 |', '|---|---:|---:|---:|---:|']
for label,locs in [('上海',['上海']),('北京',['北京']),('杭州及浙江',['杭州','浙江']),('成都及四川',['成都','四川']),('福州及福建',['福州','福建'])]:
    d=pool_union('douyin',locs);x=pool_union('xiaohongshu',locs)
    human.append(f'| {label} | {d[0]:,}／{d[1]:,} | {d[2]:,}／{d[3]:,} | {x[0]:,}／{x[1]:,} | {x[2]:,}／{x[3]:,} |')
human += ['', '其他地区、只有尚未定位的具体地点、没有IP的记录都在逐条明细里保留，没有计入上面五个地区的已定位列。', '',
 '## 十五家店怎样使用', '',
 '上海7家、北京3家、杭州3家、成都1家、福州1家分别共享所在地区候选。逐店表给出城市池和省级待细分池，不能把同区域的同一批人重复算成多家店各自独占的业绩；没有按采集来源强分店。', '',
 '逐店明细见“十五家店共享地区候选.csv”。这表示可供各店继续确认的地区线索，不表示已核实房源可以承接的人数。', '',
 '## 母句与规则', '',
 '本次使用已认可基础母句：“宝宝，我住方隅公寓这边，介绍有优惠的。”已由AI标明严肃语境的，去掉“宝宝”。没有填具体店名、地址、报价、库存或未经核实的设施承诺。母句只作为接话；客户问的具体问题和事实缺口另留，不能把一条介绍当作全部问题已经回答。', '',
 '十五家店的首轮优先词库均为每店200条，共3000条门店与搜索词关系；两平台共用文字词库，采集进度分别记录。十个需求池、多池组合、供需、否定、地区、时间和异常复核继续使用，新增合格评论由AI初筛和细筛，回复在本地选已认可母句。', '',
 '母句首版共50条，其中10条已认可、40条待集中校准。本次没有把待认可的40条自动投入使用。需求池、母句库和异常处理池长期维护，不设整库到期。', '',
 '## 评论时间', '',
 '下表只统计高及超高意向评论的发表时间，帮助安排复核顺序，不用日期自动判客户失效。入住时间、租期及未来计划保留客户原话；未说的保持未说。', '',
 '| 发表时间 | 抖音高及超高意向评论 | 小红书高及超高意向评论 |', '|---|---:|---:|']
ages={p:collections.Counter(age_bucket(r['published_at']) for r in rr if r['interest_at_comment'] in ('high','super_high')) for p,rr in rows.items()}
for label in ['近7天','8至30天前','31至90天前','90天以上','日期晚于本次核对，待核','日期时区待核','日期待核']:
    if ages['douyin'][label] or ages['xiaohongshu'][label]:human.append(f"| {label} | {ages['douyin'][label]:,} | {ages['xiaohongshu'][label]:,} |")
human+=['', '## 可直接查看的文件', '', '每个平台分别提供“高及超高意向明细”和“选中母句明细”。未选中的重复评论、结束信号、待核理由仍留在对应本地账本，没有删除或冒充发送完成。', '']
if summary.get('compatibility_review',{}).get('applied_count'):
    idx=human.index('## 地区候选分布')
    human[idx:idx]=['## 旧记录及母句适配补核', '',
        '124条定向补核已完成并合入：抖音102条、小红书22条。其中113条能确认评论时有需求，6条为未来计划，5条状态仍不明确；122条适合通用接话，2条暂不直接套用。适合接话不代表未来或未知状态可以直接联系。', '',
        '这次是同一模型先初筛、再细筛，没有冒充独立二审或人工认可。小红书原22条母句适配缺口已全部补核。另有4条抖音旧备选的需求状态尚未明确，原稿和记录保留，未进入选中队列；1条客户时间线另待核。', '']
(OUT/'双平台最新进度与地区母句说明.md').write_text('\n'.join(human),encoding='utf-8')

for p,rr in rows.items():
    def business_row(r):
        draft=r.get('mother_reply_text') or r.get('alternative_mother_reply_text') or ''
        status='同一客户选中的本地草稿' if r.get('mother_reply_text') else '保留为备选' if r.get('alternative_mother_reply_text') else '待AI核母句适配' if r.get('requires_AI_intro_suitability') else '保留判断及原稿，待核'
        needs=[text_of(x) for x in r.get('review_reasons',[]) + r.get('semantic_review_reasons',[])]
        if r.get('timeline_review'):needs.append(r['timeline_review'])
        if r.get('unanswered_specific_question'):needs.append('客户具体问题和房源事实仍需核对')
        return [r['comment_text'],labels.get(r['interest_at_comment'],'待核'),state_labels.get(r['demand_state'],'状态待核'),r['original_ip'] or '原记录未提供',region_note(r),str(r['published_at'] or '日期未明'),'；'.join(text_of(t) for t in r['time_mentions']) or '未明确入住时间或租期',draft,status,'；'.join(dict.fromkeys(x for x in needs if x)),'未发送']
    headers=['客户评论','意向判断','需求状态','评论IP属地','客户地点依据','评论发表时间','入住时间和租期原话','本地母句','母句准备状态','仍需核对','发送状态']
    write_csv(names[p]+'高及超高意向明细.csv',headers,(business_row(r) for r in rr if r['interest_at_comment'] in ('high','super_high')))
    write_csv(names[p]+'选中母句明细.csv',headers,(business_row(r) for r in rr if r.get('mother_reply_text')))

store_names=json.loads(Path(json.loads(Path(cur['manifest']).read_text(encoding='utf-8'))['store_catalog']).read_text(encoding='utf-8'))['store_names_from_existing_catalog']
store_data=[]
for store in store_names:
    city=next(c for c in ['上海','北京','杭州','成都','福州'] if c in store)
    province={'杭州':'浙江','成都':'四川','福州':'福建'}.get(city)
    d=pool_union('douyin',[city]);x=pool_union('xiaohongshu',[city]);dp=pool_union('douyin',[province]) if province else (0,0,0,0);xp=pool_union('xiaohongshu',[province]) if province else (0,0,0,0)
    store_data.append([store,city,d[0],d[1],x[0],x[1],province or '直辖市',dp[0],dp[1],xp[0],xp[1],'同区域共享，不能逐店相加；明示地点未定位的IP辅助另留；尚未按房源条件确认为可承接'])
write_csv('十五家店共享地区候选.csv',['门店','城市共享池','抖音城市池高意向评论','抖音城市池去重人数','小红书城市池高意向评论','小红书城市池去重人数','省级待细分池','抖音省级池高意向评论','抖音省级池去重人数','小红书省级池高意向评论','小红书省级池去重人数','统计说明'],store_data)
receipt={'region_pointer_sha256':hashlib.sha256((D/'current.json').read_bytes()).hexdigest(),'files':{f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in OUT.iterdir() if f.is_file()},'source_intent_counts_unchanged':True,'platforms_separate':True,'actual_sends':0,'generated_at':now.isoformat()}
(D/'human-export-receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'output_directory':str(OUT),'files':list(receipt['files']),'source_comments':{p:len(r) for p,r in rows.items()}},ensure_ascii=False))
