import json,pathlib,copy
base=pathlib.Path(__file__).resolve().parents[1]
part=base/'recall-audit'/'part-1'
pages={}; source={}; decisions={}
for p in sorted(part.glob('page-??.json')):
    cs=[c for g in json.loads(p.read_text(encoding='utf-8-sig'))['post_groups'] for c in g['comments']]
    pages[p.stem]=cs
    source.update({c['key']:c for c in cs})
def K(keys,reason):
    for key in keys.split():
        assert key not in decisions,key
        decisions[key]={'review_key':key,'decision':'keep','reason':reason,'patch':{}}
def C(key,audit_reason,**patch):
    assert key not in decisions,key
    decisions[key]={'review_key':key,'decision':'change','reason':audit_reason,'patch':patch}
def orig(key,field): return copy.deepcopy(source[key]['first_semantic_judgment'][field])
def plan(key,**changes):
    p=orig(key,'reply_plan');p.update(changes);return p
def addfact(key,fact):
    p=plan(key);p['missing_facts'].append(fact);return p

# Page 00: explicitly read both halves, every key assigned here.
K('D0002 D0015 D0268 D0270 D0274 D0032 D0036 D0277 D0282 D0286 D0294 D0041 D0043 D0045 D0048 D0055 D0296 D0299 D0301 D0303 D0308 D0068 D0138 D0142 D0144 D0147 D0160 D0162 D0166 D0169 D0174 D0219 D0236 D0242 D0246 D0249 D0251','本人询租或明确求房成立；工作地、并列条件及母句事实缺口保留，未补今日有效或发送许可。')
K('D0006 D0008 D0018 D0255 D0257 D0263 D0266 D0272 D0289 D0053 D0062 D0090 D0096 D0098 D0100 D0324 D0334 D0113 D0115 D0117 D0119 D0121 D0124 D0128 D0171 D0189','展示或经历语境下的短询保留中等关注和具体待核；不无证升级为确定推进，母句仅候选。')
K('D0010 D0070 D0312 D0314 D0094 D0102 D0109 D0316 D0318 D0328 D0130 D0157 D0177 D0213 D0234','原句用途、指代或实际租赁动作不明，保留未知及无主动推销计划。')
K('D0259 D0261 D0305 D0060 D0066 D0072 D0074 D0076 D0078 D0080 D0082 D0084 D0086 D0088 D0310 D0092 D0104 D0106 D0320 D0322 D0326 D0152 D0155 D0164 D0197 D0199 D0201 D0203 D0205 D0207 D0209 D0211','原文为供给、经验、比较、求职或互动评价，没有把他人和现居条件移成本人新求租。')
K('D0027 D0336','本人明确表示愿租，保留超高行动信号；不等于已成交或预约。')
C('D0004','标题仅居住展示，与现场落差的经历不能证明当前找房推进；保留问址问价线索为中等。',interest='medium',reason='展示帖询位置价格并担忧实景不符；是否实际在找租房待核',needs_review=orig('D0004','needs_review')+['原帖未明确可租；需核本人目前是否找房及实景所指。'])
tm=orig('D0012','time_mentions');tm[0].update(time_role='other',verification='询月租方式，未说明租一个月或总租期；可能指按月计价，先澄清。')
C('D0012','月租问法不等于总租期，不据此承诺该租期可住。',time_mentions=tm,reply_plan=plan('D0012',preferred_mother_slot=1,missing_facts=['真实住户、介绍资格、具体门店优惠时效及适用条件待核。','月租指按月计价还是按月短租、实际总租期及报价待核。']),needs_review=orig('D0012','needs_review')+['月租方式与总租期分开，未给总时长。'])
rs=orig('D0058','target_regions');rs[0]['group_relation']='unknown'
C('D0058','套三或套二是户型备选，单一成华地区不应标为地区OR。',target_regions=rs)
C('D0330','实住闺蜜分享并未说明房源在租，多项短询仍不足确认当前求租推进。',interest='medium',reason='询区位价格和是否两室，保留住房兴趣；在租语境与本人找房动作待核',needs_review=orig('D0330','needs_review')+['该帖为实住分享，需核本人是否求租及所问住房是否在租。'])
ts=orig('D0332','topics');ts[0].update(subject='unresolved',polarity='unknown')
C('D0332','艾特朋友谈可住三人是可能性讨论，不能认定正在求租或本人硬条件。',role='unknown',demand_state='unknown',interest='uncertain',topics=ts,reason='向朋友探讨三人居住可能，是否本人实际求租未知',needs_review=['是否实际一起找房、三人居住是否本人要求待核。'],reply_plan=plan('D0332',preferred_mother_slot=None,generic_intro_suitable=False,missing_facts=[],caution=['租赁动作及需求主体不明，暂不安排推销接话。']))
rs=orig('D0111','target_regions');rs[0]['relation']='unresolved'
C('D0111','我就在只能证明当时所在位置，不能直接当作现居住址。',target_regions=rs,needs_review=orig('D0111','needs_review')+['三新家园是当时所在位置，是否现居待核。'])
for key in ['D0133','D0135']:
    C(key,'个人房东身份是联系前提；母句事实缺口必须显式保留身份与费用限制。',reply_plan=addfact(key,'须核对接者确为个人房东且免中介费、水电由租户自行缴纳；住户介绍不能冒充个人房东。'))

# Page 01.
K('D0342 D0368 D0385','明确要房或提出带具体日期的看房请求，保留超高信号及未确认事实。')
K('D0522 D0525 D0364 D0374 D0377 D0379 D0590 D0592 D0387 D0394 D0418 D0425 D0427 D0437 D0439 D0463 D0465 D0477 D0485 D0489 D0495 D0497 D0500 D0502 D0504 D0506 D0508 D0569 D0575','本人具体求房或询可租房源成立，保留预算、工作地、否定与联立条件以及母句事实待核。')
K('D0339 D0350 D0390 D0422 D0431 D0627 D0443 D0445 D0453 D0640 D0643 D0456 D0461 D0474 D0510 D0561 D0563','短询、服务区域或申请住宿线索保留中等；不把未明条件、资格或动作硬升为明确推进。')
K('D0347 D0354 D0513 D0381 D0601 D0609 D0617 D0630 D0634 D0529 D0540 D0553','空互动、真假疑问或愿望及居住困扰仍存在关键歧义，未知保留且无推销计划。')
K('D0356 D0358 D0360 D0362 D0515 D0518 D0520 D0397 D0399 D0401 D0403 D0405 D0407 D0409 D0411 D0611 D0619 D0621 D0623 D0625 D0415 D0435 D0448 D0451 D0632 D0636 D0646 D0459 D0468 D0470 D0472 D0527 D0532 D0536 D0538 D0542 D0544 D0546 D0549 D0551 D0555 D0557 D0559 D0567 D0571 D0577 D0583 D0606','供给、现住或已解决经历、价格比较和互动无新求租；原判未借他人条件或虚构新需求，保留。')
C('D0597','找房东渠道的身份限制须写入母句事实缺口，不只存在联系策略标签。',reply_plan=addfact('D0597','须澄清是否只接受房东及介绍者身份能否符合；不得冒充房东。'))
C('D0392','单问真的不能证明本人正在找房；保留真假关注但未知。',role='unknown',demand_state='unknown',interest='uncertain',reason='仅质疑出租信息真实性，是否本人求租未知',needs_review=['真假所指及本人是否找房待核。'],reply_plan=plan('D0392',preferred_mother_slot=None,generic_intro_suitable=False,missing_facts=[],caution=['先澄清意图，不因真假短询安排推销。']))
ts=orig('D0413','topics');ts[1]['subject']='unresolved'
C('D0413','武汉租的时候是历史费用经历，不能标成确定现居事实。',topics=ts)
C('D0613','明确询租金计价周期仍是住房价格关注，判无关过低；不据此认定当前找房。',interest='low',reason='问视频价格是否年租总额，属于低优先价格讨论；未明本人求租',needs_review=['本人是否当前找房待核；一年只是在问计价口径。'])
ts=orig('D0615','topics')
for x in ts:x['subject']='unresolved'
C('D0615','在上海的时候住酒店是历史经历，不是现居事实。',topics=ts)
rs=orig('D0441','target_regions');rs[0]['relation']='desired'
C('D0441','刚来上海并想租房表明本次城市求租语境，但不证明已有现居住房。',target_regions=rs)
C('D0638','网上申请是青年驿站申请流程，不能硬归看房联系或当作已接受商业公寓推荐。',topics=[],other_constraints=[{'quote':'网上事先申请的吗','detail':'青年驿站或相关住宿项目申请流程咨询，具体项目与资格待核。'}],reply_plan=plan('D0638',preferred_mother_slot=None,generic_intro_suitable=False,missing_facts=['具体申请项目、资格及是否考虑商业公寓待核。'],caution=['不能把申请流程当成约看；尚无适合直接回应该问题的认可母句。']))
for key in ['D0534','D0581']:
    ts=orig(key,'topics');rs=orig(key,'target_regions')
    for x in ts:x['subject']='unresolved'
    for x in rs:x.update(relation='unresolved',condition_scope='本人及朋友此前居住经历，不是明确当前住址或求租目标。')
    C(key,'明确之前住过，不能将旧居写成现居或目标；保留历史体验。',topics=ts,target_regions=rs)
C('D0565','仅多少且展示语境无计量单位，不能确定为价格池。',topics=[],possible_topics=[{'quote':'多少','candidate_pools':['价格预算','户型面积与居住方式'],'ambiguity':'可能问价格或面积，原评论未明确指标。'}],needs_review=orig('D0565','needs_review')+['须澄清多少所指，候选不计作确定池。'])
tm=orig('D0579','time_mentions');tm[0].update(normalized='2027',verification='以2026年可信发表时间锚定明年为2027；只是换房意愿，是否已开始找房未知。')
C('D0579','明年想换是未来换房意愿，原句未证明当前已推进找房，不能直接高意向。',demand_state='unknown',interest='medium',reason='现住湘湖1700并想明年换便宜房，是否已开始找房待核',time_mentions=tm)

# Page 02.
K('D0651 D0661 D0864 D0866 D0871 D0667 D0669 D0686 D0876 D0887 D0890 D0893 D0690 D0898 D0902 D0904 D0906 D0740 D0750 D0752 D0755 D0760 D0764 D0913 D0916 D0918 D0778 D0807 D0845','本人具体问房或求房成立；保留工作地、目标、预算及硬条件联立和当前事实待核。')
K('D0654 D0659 D0663 D0665 D0857 D0869 D0873 D0925 D0714 D0716 D0720 D0722 D0730 D0941 D0949 D0953 D0742 D0774 D0816 D0821 D0851 D0853','展示短询、备选居住方式或模糊地区保留中等线索，尚未凭短句补强行动或具体指标。')
K('D0648 D0855 D0861 D0883 D0688 D0927 D0724 D0726 D0728 D0744 D0911 D0766 D0827 D0838 D0840','用途、指标、地点或主体不清，维持未知；无据不补需求或接话。')
K('D0656 D0885 D0692 D0694 D0696 D0698 D0700 D0704 D0706 D0708 D0710 D0712 D0921 D0923 D0929 D0931 D0933 D0935 D0937 D0939 D0718 D0732 D0945 D0947 D0951 D0734 D0736 D0738 D0746 D0748 D0908 D0781 D0784 D0787 D0789 D0791 D0793 D0795 D0797 D0800 D0802 D0804 D0825 D0829 D0832 D0834 D0836','经验、推荐、供给或互动不等于本人当前住宅租赁；现居困扰保留追核提示，不编造换房或发送。')
C('D0859','泛居住展示下直接问址问价仍不足证明确定推进，与同类短询统一中等。',interest='medium',reason='问展示住房地点价格，实际在租语境及本人推进待核',needs_review=orig('D0859','needs_review')+['原帖仅居住展示，需核可租对象及本人找房动作。'])
ts=[x for x in orig('D0895','topics') if x['pool']!='价格预算']
C('D0895','1.5-2的单位与所指不明，只留预算候选，避免同时进入确定价格池。',topics=ts)
C('D0900','每月住七八天是使用频率，没有总租期可据以选租期承诺母句。',reply_plan=plan('D0900',preferred_mother_slot=7,missing_facts=['同一门店同一有效房源可合住或提供所求单房，且满足一千以内及每月住七八天使用方式待核。','实际总租期、合住安排及是否考虑商业公寓待核。','如采用通用介绍，真实住户身份、本人介绍资格及具体门店优惠时效适用条件待核。']))
C('D0702','评论谈电动车价格和实习身份，未直接给住房位置条件；不把交通工具价格写为住房主题。',topics=[])
C('D0943','仅多少无单位，不能确定为价格；保留价格或面积候选。',topics=[],possible_topics=[{'quote':'多少','candidate_pools':['价格预算','户型面积与居住方式'],'ambiguity':'未明确价格或面积指标。'}])
C('D0823','询问月租计价仍有低优先住房价格关注，完全无关过低；不视为总租期要求。',interest='low',reason='问视频一万是否月租口径，未明本人求租',needs_review=['本人是否实际找房未知；一个月是价格口径，非给定总租期。'])
tm=orig('D0849','time_mentions');tm[0].update(time_role='other',verification='单说月租，可能问月租金或按月可租，不足认定总租期。')
C('D0849','月租片段所问模式与价格不清，不能定为租赁总期并据此用19。',interest='medium',time_mentions=tm,reply_plan=plan('D0849',preferred_mother_slot=1,missing_facts=['真实住户、介绍资格及具体门店优惠时效适用条件待核。','须澄清月租金还是按月可租、实际总租期及相应报价。']))

# Page 03.
K('D0965 D0969 D0971 D0977 D0979 D1158 D1166 D0986 D0992 D0996 D1196 D1016 D1229 D1232 D1066 D1072 D1099 D1101 D1103 D1105 D1107 D1170 D1173 D1179 D1181 D1206 D1213','自身询租或主动求房充分，保留具体条件、工作地和明示排除；母句事实待核或不适配理由有保留。')
K('D0999','以真实性为前提明确立马租，保留超高；不冒充订租已成功。')
K('D0957 D1032 D1035 D1240 D1077 D1086 D1095 D1266 D1272 D1113 D1175 D1210','短询、服务接触或偏好保留中等，指标歧义、当前找房动作及母句适配待核。')
K('D1129 D1135 D1137 D1139 D1141 D1143 D1145 D1147 D1153 D1162 D1039 D1249 D1255 D1261 D1125 D1177 D1183','纯艾特或历史困扰指代不清，未知保留；不补当前找房或推销。')
K('D0959 D1131 D1133 D0961 D0963 D0967 D0973 D1149 D1151 D1156 D1160 D1168 D0988 D1188 D1002 D1004 D1006 D1008 D1010 D1012 D1021 D1041 D1043 D1045 D1047 D1049 D1051 D1053 D1055 D1243 D1245 D1247 D1251 D1253 D1257 D1259 D1083 D1097 D1111 D1115 D1117 D1119 D1121 D1123 D1127 D1185 D1208 D1215 D1217 D1219 D1221','供给、价格比较、历史或现住经历、互动评价没有新求租动作；不移用作者条件，保留原判断。')
C('D0955','多少没有计量单位，不能直接确定为价格。',topics=[],possible_topics=[{'quote':'多少','candidate_pools':['价格预算','户型面积与居住方式'],'ambiguity':'价格或面积尚未明确。'}])
ts=orig('D0975','topics');rs=orig('D0975','target_regions')
for x in ts:x['subject']='unresolved'
for x in rs:x.update(relation='unresolved',condition_scope='2019年历史租住，不是明确现居或本次目标。')
C('D0975','19年旧租房经历不是当前住址或需求事实。',topics=ts,target_regions=rs)
C('D1164','寻房东渠道及限制范围不明，要在母句实际事实缺口中保留，不能冒充房东。',reply_plan=addfact('D1164','须澄清是否限定房东渠道、介绍者身份是否符合；九月后具体入住年份和日期待核。'))
C('D1202','纯真假疑问不足认定本人正在求租，维持未知关注。',role='unknown',demand_state='unknown',interest='uncertain',reason='仅质疑真假，未说明本人是否租房',needs_review=['真假所指与本人租赁动作待核。'],reply_plan=plan('D1202',preferred_mother_slot=None,generic_intro_suitable=False,missing_facts=[],caution=['先澄清意图，不凭真假短询推销。']))
C('D1014','不用租了未明指本人取消还是劝别人，不应擅定为对他人说并过滤。',role='unknown',demand_state='unknown',interest='uncertain',reason='对上海租房失望并说不用租了，是否本人停止找房或泛劝未知',needs_review=['本人是否取消、已解决或仍需另找住房待核。'])
C('D1234','多少单独出现无法确定价格指标，保留住房询盘为中等及候选。',interest='medium',topics=[],possible_topics=[{'quote':'多少','candidate_pools':['价格预算','户型面积与居住方式'],'ambiguity':'原句未明价格或面积。'}],needs_review=orig('D1234','needs_review')+['多少指标及本人具体所求待核。'])
for key in ['D1080','D1092','D1264','D1270']:
    C(key,'泛居住展示下询位置、收费或类型，没有明确可租或本人推进；不凭短询定高。',interest='medium',needs_review=orig(key,'needs_review')+['原帖为居住展示，实际在租状态与本人找房动作待核。'])
ts=[x for x in orig('D1276','topics') if x['pool']!='价格预算']
C('D1276','朝阳多少的指标未明，不能默认为租金并定高意向。',interest='medium',topics=ts,possible_topics=[{'quote':'多少','candidate_pools':['价格预算','户型面积与居住方式'],'ambiguity':'价格或面积指标未明确。'}],needs_review=orig('D1276','needs_review')+['须澄清朝阳所指与多少指标，实际租赁推进未明。'])
rs=orig('D1109','target_regions');rs[0]['relation']='unresolved'
ts=orig('D1109','topics');ts[0]['subject']='unresolved'
C('D1109','我在你对面仅证明位置关系，未明说现居，保留为未定地点。',topics=ts,target_regions=rs)

# Page 04.
K('D1279 D1281 D1449 D1462 D1286 D1293 D1295 D1297 D1299 D1469 D1471 D1474 D1303 D1307 D1309 D1315 D1529 D1531 D1533 D1535 D1540 D1339 D1341 D1346 D1348 D1350 D1356 D1514 D1521 D1523 D1527 D1359 D1366 D1543 D1558 D1379 D1591 D1594','本人求房或具体询房成立，工作地、范围、预算、设施联立和偏好强弱已有保留；母句事实未冒认。')
K('D1451 D1454 D1457 D1460 D1291 D1343 D1510 D1517 D1383 D1404 D1406 D1431','展示短询、应用或合租形式咨询保留中等及具体待核；无证不强化行动或借用正文条件。')
K('D1446 D1313 D1537 D1317 D1319 D1321 D1323 D1325 D1327 D1329 D1331 D1333 D1335 D1488 D1490 D1492 D1494 D1496 D1498 D1500 D1502 D1504 D1506 D1352 D1508 D1412 D1414 D1420 D1607 D1441 D1563 D1580 D1587','空互动、供需未知或当前动作不清保留未知与待核，不出推销计划。')
K('D1301 D1305 D1311 D1337 D1512 D1519 D1377 D1408 D1410 D1416 D1418 D1422 D1603 D1605 D1427 D1429 D1433 D1435 D1437 D1439 D1466 D1476 D1478 D1480 D1482 D1484 D1486 D1565 D1568 D1570 D1572 D1574 D1576 D1578 D1582','供给、旧优惠、观点比较或互动评价无新本人住宅求租；未将朋友预算、月卡或历史活动当成可承接事实。')
C('D1354','租不到便宜房可能涉及本人找房受挫也可能市场评论，不能直接排成无关。',role='unknown',demand_state='unknown',interest='uncertain',reason='述该片区租不到便宜房及最低报价，是否本人当前找房未知',needs_review=['是否本人正在找房、实际预算和可接受居住方式待核；1200不是明确本人预算。'])
C('D1554','猜是否沧州是地点核对，不能直接推定高求租推进。',demand_state='unknown',interest='medium',reason='核问房源是否在沧州，是否本人想租待核',needs_review=orig('D1554','needs_review')+['沧州是所询房源位置，尚非本人确认目标或明确找房动作。'])

# Page 05.
K('D1621 D1624 D1628 D1631 D1633 D1845 D1847 D1672 D1680 D1682 D1684 D1887 D1891 D1893 D1728 D1730 D1734 D1736 D1740 D1742 D1751 D1755 D1786 D1789 D1791 D1796 D1799','本人求租或具体问房成立，保留预算、总租期、实际入住时间、双人工作地及同房联立核实。')
K('D1635','明确要所询房，保留超高但不声称成交或预约成功。')
K('D1617 D1842 D1640 D1644 D1646 D1655 D1658 D1863 D1869 D1878 D1662 D1883 D1686 D1889 D1688 D1738 D1759 D1766 D1826','保留中等住房关注、条件偏好或潜在换房；尚未把旧租金、未来迁往和含糊互动写成确定新需求。')
K('D1613 D1802 D1814 D1816 D1818 D1820 D1854 D1648 D1867 D1873 D1666 D1678 D1702 D1704 D1706 D1708 D1710 D1712 D1714 D1716 D1718 D1720 D1722 D1895 D1757 D1835','艾特、数字、单位或供需主体不明，保留未知及候选，不补确定预算或租赁动作。')
K('D1609 D1615 D1619 D1804 D1806 D1808 D1810 D1812 D1858 D1660 D1664 D1670 D1674 D1676 D1885 D1690 D1694 D1696 D1698 D1700 D1724 D1726 D1764 D1768 D1771 D1773 D1775 D1777 D1779 D1781 D1793 D1822 D1824 D1828 D1831 D1833 D1837 D1839','供给、仓储用途、经验建议及节目互动无确定本人住宅新求租，不借工资和他人条件补预算。')
C('D1611','问月租金额仍有低优先价格关注，完全无关偏低；不认定本人找房。',interest='low',reason='核对视频月租金额，未说明本人求租',needs_review=['本人是否实际找房未知；一个月为计价周期。'])
for key in ['D1651','D1653','D1861','D1875']:
    C(key,'泛居住展示下短问价或问址，没有确定在租语境或本人推进，不宜高意向。',interest='medium',needs_review=orig(key,'needs_review')+['该帖为居住展示，需核可租对象及本人实际找房动作。'])
ts=orig('D1881','topics');ts[0]['subject']='unresolved'
C('D1881','上次找的且已换了，不能把旧处通勤当成现居事实。',topics=ts)
C('D1692','当前短租纠纷求助与新租赁尚未建立，不宜用水电收费母句回答违约金问题。',reply_plan=plan('D1692',preferred_mother_slot=None,generic_intro_suitable=False,missing_facts=['是否需要另找住房及本人实际新需求待核。'],caution=['合同纠纷求助不能用公寓收费介绍冒充解决方案；不生成营销正文。']))
C('D1732','本人明确下月租房且已关注渠道，不能仅因入住在下月压低；下月并不是总租期。',interest='high',reply_plan=plan('D1732',preferred_mother_slot=1,missing_facts=['真实住户、本人介绍资格、具体门店优惠时效及适用条件待核。','实际入住日、总租期、目标地区、预算及可承接房源待核；下月不是租一个月。']))
ts=[x for x in orig('D1784','topics') if x['pool']!='价格预算']
C('D1784','带浴缸明确，但多少尚无计量单位，价格只列候选，不掩盖设施询盘。',topics=ts,possible_topics=[{'quote':'多少','candidate_pools':['价格预算','户型面积与居住方式'],'ambiguity':'可能问价格或面积，未给计量单位。'}],reason='询带浴缸住房，多少的具体指标待核',needs_review=orig('D1784','needs_review')+['多少指价格还是面积需澄清。'])

# Page 06.
K('D1926 D1928 D1930 D1932 D1953 D1955 D1967 D1992 D1998 D2014 D2042','本人实际问房或求租成立；时间角色、工作地、预算设施及同房条件与母句待核均保留。')
K('D1946 D1995 D2001 D2007 D2052 D2054 D2057 D2061 D2066 D2069 D2073','短询及联系意图保留中等，指标或推进不明处有具体待核；不误认约看已成功。')
K('D1897 D1899 D1901 D1903 D1905 D1907 D1909 D1911 D1913 D1981 D1983 D2075','艾特或缺少被问正文的追问保留未知，不擅自补需求或出推销。')
K('D1915 D1917 D1924 D1936 D1940 D1942 D1944 D1971 D1973 D1975 D1977 D1979 D1985 D1987 D1989 D2004 D2012 D2016 D2018 D2020 D2022 D2024 D2026 D2028 D2030','供给、返校转租、购房用途、现居费用或栏目互动没有新本人住宅求租；不借他人条件。')
ts=[x for x in orig('D1919','topics') if x['pool']!='价格预算']
C('D1919','多少没有给计量单位，地区明确但价格指标仍须澄清。',topics=ts,possible_topics=[{'quote':'多少','candidate_pools':['价格预算','户型面积与居住方式'],'ambiguity':'可能问价格或面积，原句未指定指标。'}],reason='询乔司地铁站住房指标，多少具体所指待核')
ts=orig('D1921','topics');rs=orig('D1921','target_regions')
for x in ts:x.update(subject='unresolved',polarity='unknown')
for x in rs:x['relation']='unresolved'
C('D1921','有没有租房的可问资源也可能招租或寻伙伴，攻略标题不足消除供需歧义。',role='unknown',demand_state='unknown',interest='uncertain',topics=ts,target_regions=rs,reason='问萧山有没有租房的，需求方、供给方或找同伴用途未明',needs_review=['须澄清是在求房源、招租还是寻合租伙伴，以及萧山地点关系。'],reply_plan=plan('D1921',preferred_mother_slot=None,generic_intro_suitable=False,missing_facts=[],caution=['供需主体未明，先核意图，不直接推销。']))
C('D1934','仅列户型和地点，可能求房但缺动作与主体，不能直接高意向。',demand_state='unknown',interest='medium',reason='攻略下列一室一厅与聚才路附近，有住房线索；是否本人求租待核',needs_review=orig('D1934','needs_review')+['须澄清本人求租还是描述已有房源，以及实际居住安排。'])
ts=orig('D1938','topics');ts[1]['polarity']='unknown'
C('D1938','只不过是合租表达顾虑，未明确拒绝合租，不写成确定reject。',topics=ts,needs_review=['是否实际求租及对合租的接受度未明；不把顾虑变成硬排除。'])
tm=orig('D1948','time_mentions');tm[0]['normalized']='P3M'
C('D1948','三个月为明确总租期，可以归一时长而不补入住日。',time_mentions=tm)
C('D2039','一个人入住不等于排除合租或要求整租，不能把人数写成独住方式。',reason='求可供一人居住的便宜房，是否独立整租或合租未说明',needs_review=orig('D2039','needs_review')+['一人入住不等于独立整租，具体居住方式待核。'])
C('D2048','纯真的吗不足证明本人找房，维持未知而非确定需求推进。',role='unknown',demand_state='unknown',interest='uncertain',reason='仅核真假，是否本人求租未知',needs_review=['真假所指与本人租赁行动待核。'],reply_plan=plan('D2048',preferred_mother_slot=None,generic_intro_suitable=False,missing_facts=[],caution=['先澄清意图，不凭真假短询推销。']))
C('D2059','泛居住展示下问价地址，尚不证明房源在租和本人明确推进，统一中等。',interest='medium',needs_review=orig('D2059','needs_review')+['该帖为居住展示，实际在租语境与本人找房动作待核。'])
C('D2071','展示语境单说多少，不应确定价格指标并定高。',interest='medium',topics=[],possible_topics=[{'quote':'多少','candidate_pools':['价格预算','户型面积与居住方式'],'ambiguity':'价格或面积未明确。'}],reason='展示住房下短询多少，具体指标与求租行动待核',needs_review=orig('D2071','needs_review')+['多少指价格还是面积、本人是否求租待核。'])

def save():
    written=0
    for name,cs in pages.items():
        keys=[c['key'] for c in cs]
        if not all(k in decisions for k in keys):continue
        out=part/(name+'.audit.jsonl')
        out.write_text(''.join(json.dumps(decisions[k],ensure_ascii=False,separators=(',',':'))+'\n' for k in keys),encoding='utf-8')
        written+=len(keys)
    (base/'audit-worker-1'/'progress.json').write_text(json.dumps({'explicit_decisions':len(decisions),'complete_page_records':written,'expected':788,'usage':'unknown','credits':'already_authorized'},ensure_ascii=False,indent=2),encoding='utf-8')
    print({'explicit_decisions':len(decisions),'written':written})
if __name__=='__main__':save()
