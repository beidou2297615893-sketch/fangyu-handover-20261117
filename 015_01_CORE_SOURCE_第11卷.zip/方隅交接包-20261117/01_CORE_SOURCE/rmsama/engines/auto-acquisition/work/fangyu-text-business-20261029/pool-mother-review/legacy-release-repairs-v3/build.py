"""Label-driven, bounded local templates on immutable v2. No semantic keyword routing."""
import pathlib,json,copy,hashlib,collections,string,sys,re,runpy
sys.dont_write_bytecode=True
O=pathlib.Path(__file__).resolve().parent;P=O.parent;W=P.parent
V=P/'legacy-release-repairs-v2';S=P/'reference-semantic-supplement';A=P/'legacy-semantic-contract-review/reference-routing-addendum'
# Reuse existing builder source loaders, identities, source records and locked renderer; main is not run.
B=runpy.run_path(str(V/'patch.py'),run_name='reuse_builder_not_main')
load,jl,sha,objsha,key,put,putjl=(B[n] for n in ('load','jl','sha','objsha','key','put','putjl'))
abc=B['abc'];base={k:copy.deepcopy(x) for k,x in abc.items()}
for x in jl(V/'source-bound-plan-overlays.jsonl'):
 assert objsha(abc[key(x)])==x['base_merged_plan_sha256'];base[key(x)].update(x['replacement_plan'])
oldcontract=load(V/'repair-contract.json');contract=copy.deepcopy(oldcontract);contract.update(version='legacy-release-repairs-v3-label-routed-natural-voice',parent_contract_sha256=sha(V/'repair-contract.json'),applied=False,send_authorized=False)
sources=B['sources'];inputs={key(x):x for x in jl(S/'input.jsonl')};contexts=load(S/'shared-contexts.json');labels={};label_sources={};newdefs={}
EXPECTED=['755eb2ee72b38f1b18e55643fddf0ab144636ee5605f0012d5c90452c2a9d776','59c7ecfa91da674a15c9398d9a56b5d842ac0740114622e6964f35541254b244']
assert sha(A/'manifest.json')=='660eab2c7bf468b32224cfbc003233577a738f756298a8d8a5bace5c5d1dd4a8'
routing=load(A/'routing-contract.json')
for n,h in load(S/'manifest.json')['outputs_sha256'].items():assert sha(S/n)==h
for shard,h in enumerate(EXPECTED):
 path=S/f'labels-shard{shard}/labels.jsonl';assert sha(path)==h
 for label in jl(path):
  k=key(label);assert k not in labels and k in inputs;labels[k]=label;label_sources[k]={'shard':shard,'label_file_sha256':h,'label_record_sha256':objsha(label)}
assert len(labels)==267 and set(labels)==set(inputs)
for section in ('posts','parents'):
 for x in contexts[section].values():assert objsha(x['content'])==x['content_sha256']

def source_text(k,source):
 i=inputs[k];r=sources[k]
 if source=='comment':return r['comment_text']
 if source in ('post_title','post_body'):return contexts['posts'][i['context_key']]['content'].get(source) or ''
 if source=='direct_parent':return contexts['parents'][i['parent_context_key']]['content'].get('parent_text') or ''
 raise ValueError('UNKNOWN_CITATION_SOURCE '+str(source))

def citations(x):
 if isinstance(x,list):
  for y in x:yield from citations(y)
 elif isinstance(x,dict):
  if 'source' in x and 'quote' in x:yield x
  for k,y in x.items():
   if isinstance(y,(dict,list)):yield from citations(y)

label_receipts=[]
for k,label in labels.items():
 i=inputs[k];r=sources[k];p=base[k]
 assert label['source_comment_sha256']==i['source_comment_sha256']==p['sourceSHA']==hashlib.sha256(r['comment_text'].encode()).hexdigest()
 assert i['source_record_sha256']==p['original_classification_sha256']==objsha(r['source_record'])
 assert i['source_container_sha256']==p['source_file_sha256']
 assert contexts['posts'][i['context_key']]['content_sha256']==i['context_sha256']
 ev=list(citations(label))
 for e in ev:assert e['quote'] and e['quote'] in source_text(k,e['source']),('LABEL_NONLITERAL_CITATION',k,e)
 label_receipts.append({'platform':k[0],'cid':k[1],'uid':k[2],**label_sources[k],'input_record_sha256':objsha(i),'context_sha256':i['context_sha256'],'literal_label_citations_checked':len(ev),'compatibility_notes':['housing_purpose is optional extra field; residential evidence may also be in reference_mentions/evidence','explicit_other_source may describe private subletting supply; it does not prove a non-Fangyu brand','unknown brand does not imply unknown housing or explicit other brand']})

def rels(label,name):return {x.get('relation') for x in label[name]}
def def_family(route,template,fill,scope):
 name='natural_v3_'+route+'_'+objsha([template,sorted(fill)])[:10]
 d={'template':template,'required_fill':list(fill),'scope':scope,'individually_user_approved':False,'source_policy':'AI reference labels plus unchanged original pools; literal own-comment parameters only except explicitly attributed post_price_anchor','attributed_post_fields':['post_price_anchor'] if 'post_price_anchor' in fill else []}
 assert name not in oldcontract['families']
 if name in newdefs:assert newdefs[name]==d
 contract['families'][name]=d;newdefs[name]=d;return name

def original_v1_plan(k):
 return B['v1'][k]

def components(p):
 """Map the actual previously chosen families/slots, not raw customer keyword intent."""
 f=p['family'];fill=copy.deepcopy(p['fill']);t=B['original_contract']['families'][f]['template']
 # These are slots/actions of the existing accepted plan, never semantic reference tests.
 parts=[]
 if 'room' in fill:parts.append('{room}')
 if 'requirements' in fill:parts.append('是否{requirements}' if fill['requirements']=='合租' else '{requirements}房源')
 if 'fee' in fill:parts.append('是否{fee}')
 if 'duration' in fill:parts.append('能否{duration}')
 if 'lease' in fill:parts.append('能否{lease}')
 if '空房' in t:parts.append('空房')
 if '租金' in t or '月租帮你问' in t:parts.append('{price_cycle}的租金' if 'price_cycle' in fill else '租金')
 if '位置' in t:parts.append('位置')
 if '面积户型' in t:parts.append('面积')
 if '租房流程' in t:parts.append('租赁方式')
 if '看房安排' in t:parts.append('看房安排')
 # Contact is composed separately from the new directional label.
 return list(dict.fromkeys(parts)),fill

def post_evidence(k,field,value):
 i=inputs[k];matches=[e for e in citations(labels[k]) if e['source'] in ('post_title','post_body') and value in e['quote']]
 assert matches,('POST_SLOT_NO_AI_CITATION',k,value);e=matches[0];content=source_text(k,e['source']);assert value in content
 ctx=contexts['posts'][i['context_key']]
 return {'field':field,'quote':value,'source_field':e['source'],'policy':'attributed_post_quote_only','context_key':i['context_key'],'context_sha256':ctx['content_sha256'],'post_id':ctx['content']['post_id'],'post_field_sha256':hashlib.sha256(content.encode()).hexdigest(),'AI_citation':e,'not_customer_requirement':True,'not_Fangyu_fact':True}

def choose(k):
 p=base[k];r=sources[k];l=labels[k];v1=original_v1_plan(k);parts,fill=components(v1);route=[];notes=[];extra=[];clarify=False
 # v2's extra object-reference parameter is intentionally discarded; underlying original literal conditions remain.
 price=rels(l,'price_relation');place=rels(l,'place_relation');brand=l['brand_source_relation'];unknown_time='unknown' in rels(l,'time_relation')
 intro='宝宝，我住方隅，介绍有优惠。';optional='也考虑这边吗？'
 # All 267 have explicit model residential evidence, already verified against source quotations above.
 assert any(e['source'] in ('comment','post_title','post_body') for e in citations(l))
 if 'commenter_desired_place' in place and fill.get('place'):
  route.append('own_target_place');wanted=fill['place'];fill={'place':wanted}
  if 'original_post_place' in place:
   template=intro+'{place}的房源我帮你问，原帖位置也得问问。';notes.append('own desired area and original-post location retained as separate objects')
  else:template=intro+'{place}有无合适房源，我帮你问。'
 elif 'original_post_quote_confirmation' in price:
  route.append('source_price_verification');assert 'asked_price' in fill
  if '空房' in parts:core='原帖{asked_price}的房源是否还在，还得问问。'
  else:core='原帖{asked_price}的报价还得核实。'
  template='宝宝，'+core+'也考虑方隅吗？我住这边，介绍有优惠。';clarify=True
 elif 'price_range_for_new_search' in price:
  route.append('new_search_price_or_explicit_budget');assert not fill
  # One source-bound numeric anchor, selected only from this AI-labelled same-price relation.
  anchor=next(e['quote'].split()[-1] for e in citations(l) if e['source']=='post_body' and e['quote']=='正规一居 2.2k')
  fill={'post_price_anchor':anchor};extra=[post_evidence(k,'post_price_anchor',anchor)]
  template=intro+optional+'原帖标的{post_price_anchor}这个价位，空房帮你问。';clarify=True
 elif 'price_comparison' in price:
  route.append('comparative_price');assert 'budget' in fill
  fill={'price_reference':fill.pop('budget')};template='宝宝，你提的{price_reference}我看到了，原帖位置还得问问。也考虑方隅吗？我住这边，介绍有优惠。';clarify=True;notes.append('old budget slot retyped as commenter price reference; no personal budget assertion')
 elif 'unknown' in price and 'asked_price' in fill:
  route.append('source_price_verification');scope='{room}的' if 'room' in fill else ''
  template='宝宝，'+scope+'{asked_price}是你看到的原帖报价吗？'+('位置也还得问问。' if '位置' in parts else '房源是否还在，也得问问。' if '空房' in parts else '')
  clarify=True;notes.append('amount-to-original-price relation unresolved in AI label; one material price relation question, no budget/search inference')
 else:
  if brand=='explicit_fangyu':route.append('explicit_fangyu_housing')
  else:route.append('other_or_unknown_brand_housing');clarify=True
  if unknown_time:route.append('material_time_ambiguity');notes.append('ambiguous this-month/monthly segmentation intentionally neutral rent wording, no grammar question')
  # Preserve the existing pools without making a new procedural action out of bare desire.
  if v1['family']=='literal___rent_process' and 'unknown' in price:parts=['租金和租赁方式']
  if not parts:parts=['租房需求']
  if l['contact_action_direction']=='asks_method':parts=[x for x in parts if x!='租房需求']
  # Rendering style integrates conditions and actions into one mother, not an 8-route paragraph.
  phrase='、'.join(parts)
  if l['contact_action_direction']=='asks_other_to_contact_commenter':
   private=any(e['source']=='comment' and any(q in e['quote'] for q in ('私信','私聊')) for e in citations(l))
   assert private;tail=(phrase+'可以私聊。') if phrase else '可以私聊。'
  elif l['contact_action_direction']=='asks_method':tail=(phrase+'可以聊，' if phrase else '')+'可以在这里联系我。'
  else:tail=phrase+'帮你问。'
  template=intro+('' if brand=='explicit_fangyu' else optional)+tail
  if brand=='explicit_fangyu':notes.append('explicit Fangyu source permits direct pool acknowledgment; no same-store inventory/quote assertion')
 # Exact required slots only: no obsolete/v2 reference slot and no stray quote evidence.
 required={f for _,f,_,_ in string.Formatter().parse(template) if f};fill={f:v for f,v in fill.items() if f in required};assert set(fill)==required,(k,template,fill)
 ev=[copy.deepcopy(e) for e in v1['evidence'] if e['field'] in fill]
 if 'price_reference' in fill:
  ev=[{**copy.deepcopy(e),'field':'price_reference'} for e in v1['evidence'] if e['field']=='budget']
 ev+=extra
 z=copy.deepcopy(p);z.update(family=def_family('__'.join(route),template,fill,'clarification_only' if clarify else 'housing_draft'),fill=fill,evidence=ev,clarification_only=clarify,hold_reasons=[],status='local_plan_proposed')
 return z,{'routes':route,'routing_label_record_sha256':objsha(l),'compatibility_notes':notes,'original_AI_pools':p['covered_existing_pools'],'source_price_not_customer_budget':bool(price & {'original_post_quote_confirmation','price_comparison'}),'all_reference_semantics_from_AI_labels_not_program_guessed':True}

def render(p,c=contract):
 if not p.get('family'):return None
 r=sources[key(p)];d=c['families'][p['family']];post=set(d.get('attributed_post_fields',[]));ownfill={f:v for f,v in p['fill'].items() if f not in post};ownev=[e for e in p['evidence'] if e['field'] not in post]
 if not post:return B['render'](p,c)
 # A separate bounded wrapper validates post quotation; it does not widen locked own-comment renderer.
 assert post=={'post_price_anchor'} and key(p) in labels and 'price_range_for_new_search' in rels(labels[key(p)],'price_relation')
 for f in post:
  es=[e for e in p['evidence'] if e['field']==f];assert len(es)==1;assert es[0]==post_evidence(key(p),f,p['fill'][f]);assert '原帖标的{'+f+'}' in d['template']
 probe={'families':{'probe':{'template':'宝宝，'+'、'.join('{'+f+'}' for f in ownfill),'required_fill':list(ownfill)}}}
 row={'role':r['role'],'demand_state':r['demand_state'],'interest_at_comment':r['interest_at_comment'],'reply_plan':{'local_mother':{'family':'probe','fill':ownfill,'evidence':ownev},'contact_policy':r.get('contact_policy') or 'unknown','tone':r.get('effective_tone')}}
 B['renderer']['render_plan'](row,r['comment_text'],probe)
 return d['template'].format(**p['fill'])

def extra_short():
 k=next(k for k in base if k[1]=='6acf7c9f0000000008031dc0');assert k not in labels;p=base[k];assert p['clarification_only'] and p['contact_policy_original'] is None
 z=copy.deepcopy(p);z.update(family=def_family('housing_purpose_unknown','宝宝，你是想找能短租的住处吗？',{},'clarification_only'),fill={},evidence=[],clarification_only=True)
 return k,z,{'routes':['housing_purpose_unknown'],'reason':'root explicitly authorized one extra fixed natural-style purpose question; no promotional assumption','source_warning_quotes':B['remarks'](sources[k]),'AI267_label_scope':False}

PROTOTYPES=['7687783794661278479','7432282565551653670','7563441906236769087','7564246228821623594','7610009622871638799','7696414781808689957','7668177041443865390','7662621180151890737','7699930355282051903','7701051945951740721']
def prototype():
 rows=[]
 for cid in PROTOTYPES:
  k=next(k for k in labels if k[1]==cid);z,rec=choose(k);rows.append({'cid':cid,'comment':sources[k]['comment_text'],'v2':render(base[k],oldcontract),'v3':render(z),'fill':z['fill'],'route':rec['routes'],'sourceSHA':z['sourceSHA'],'label':labels[k]})
 k,z,rec=extra_short();rows.append({'cid':k[1],'comment':sources[k]['comment_text'],'v2':render(base[k],oldcontract),'v3':render(z),'fill':{},'route':rec['routes'],'sourceSHA':z['sourceSHA']})
 put(O/'prototype-boundary-examples.json',rows)
 print(json.dumps([{k:v for k,v in r.items() if k!='label'} for r in rows],ensure_ascii=False,indent=2))

PROJECT=('family','fill','evidence','clarification_only','hold_reasons','status')
def project(p):return {f:p.get(f) for f in PROJECT}
def main():
 result={k:copy.deepcopy(p) for k,p in base.items()};decisions={};delta=[];drafts=[];allcheck=[]
 for k in sorted(labels):result[k],decisions[k]=choose(k)
 k,z,rec=extra_short();result[k]=z;decisions[k]=rec
 for k,rec in decisions.items():
  p=base[k];z=result[k];before=render(p,oldcontract);after=render(z);assert before!=after
  assert not any(x in after for x in routing['body_forbidden_phrases'])
  assert after.count('？')<=1,(k,after)
  # All original comment parameters survive, except the rejected generic-reference slot and semantically corrected budget field name.
  v1=original_v1_plan(k)
  if k in labels:
   for f,value in v1['fill'].items():
    for span in value.split('、') if f=='requirements' else [value]:assert span in after,('COMMENT_CONDITION_DROPPED',k,f,value)
  assert z['source_field_evidence']==p['source_field_evidence'] and z['customer_requirements']==p['customer_requirements'] and z['source_metadata_preserved']==p['source_metadata_preserved']
  assert z['contact_policy_original']==p['contact_policy_original'] and not z['send_authorized'] and not z['can_send_now']
  delta.append({'platform':k[0],'cid':k[1],'uid':k[2],'sourceSHA':p['sourceSHA'],'source_file_sha256':p['source_file_sha256'],'original_classification_sha256':p['original_classification_sha256'],'base_v2_applied_plan_sha256':objsha(p),'base_ABC_plan_sha256':objsha(abc[k]),'replacement_plan':project(z),'routing_decision':rec,'semantic_label':labels.get(k),'semantic_label_source':label_sources.get(k),'input_record':inputs.get(k),'old_preview_sha256':hashlib.sha256(before.encode()).hexdigest(),'new_preview_sha256':hashlib.sha256(after.encode()).hexdigest(),'original_contact_policy':p['contact_policy_original'],'original_blocking_and_needs_review':B['remarks'](sources[k]),'classification_changed':False,'can_send_now':False,'send_authorized':False,'applied':False})
  drafts.append({'platform':k[0],'cid':k[1],'uid':k[2],'sourceSHA':p['sourceSHA'],'family':z['family'],'fill':z['fill'],'clarification_only':z['clarification_only'],'draft_body':after,'draft_body_sha256':hashlib.sha256(after.encode()).hexdigest(),'source_contact_policy':p['contact_policy_original'],'can_send_now':False,'send_authorized':False,'local_template_render_not_freeform_AI_body':True})
 for k,p in base.items():
  z=result[k];assert p['sourceSHA']==hashlib.sha256(sources[k]['comment_text'].encode()).hexdigest();assert p['original_classification_sha256']==objsha(sources[k]['source_record'])
  assert p['source_field_evidence']==z['source_field_evidence'] and p['contact_policy_original']==z['contact_policy_original']
  if k not in decisions:assert p==z
  if not p['family']:continue
  before=render(p,oldcontract);after=render(z)
  if k not in decisions:assert before==after
  allcheck.append({'platform':k[0],'cid':k[1],'uid':k[2],'sourceSHA':p['sourceSHA'],'source_record_sha256':p['original_classification_sha256'],'v2_draft_sha256':hashlib.sha256(before.encode()).hexdigest(),'v3_draft_sha256':hashlib.sha256(after.encode()).hexdigest(),'changed':k in decisions,'unchanged_fields_and_original_contact':True,'send_authorized':False,'can_send_now':False})
 assert len(delta)==268 and len(allcheck)==6694 and sum(x['changed'] for x in allcheck)==268
 cumulative={key(x):copy.deepcopy(x) for x in jl(V/'source-bound-plan-overlays.jsonl')}
 for d in delta:
  k=key(d);old=cumulative.get(k,{})
  old.update(platform=k[0],cid=k[1],uid=k[2],sourceSHA=d['sourceSHA'],source_file_sha256=d['source_file_sha256'],original_classification_sha256=d['original_classification_sha256'],base_merged_plan_sha256=objsha(abc[k]),replacement_plan=d['replacement_plan'],v3_routing_decision=d['routing_decision'],v3_semantic_label_source=d['semantic_label_source'],v3_semantic_label=d['semantic_label'],v3_input_record=d['input_record'],new_preview_sha256=d['new_preview_sha256'],classification_changed=False,send_authorized=False,can_send_now=False,applied=False)
  if 'old_preview_sha256' not in old:
   t=render(abc[k],B['abc_contract']);old['old_preview_sha256']=hashlib.sha256(t.encode()).hexdigest() if t else None
  cumulative[k]=old
 for name,definition in oldcontract['families'].items():assert contract['families'][name]==definition
 regression=[]
 for origin,path in [('v2-346',V/'v1-and-final-review-regression.jsonl'),('v2-final-finite',P/'legacy-final-semantic-review-v2/case-review.jsonl')]:
  if not path.exists():continue
  for q in jl(path):
   try:k=key(q)
   except KeyError:continue
   if k not in base:continue
   regression.append({'origin':origin,'platform':k[0],'cid':k[1],'uid':k[2],'sourceSHA':base[k]['sourceSHA'],'old_review_record_sha256':objsha(q),'v2_draft':render(base[k],oldcontract),'v3_draft':render(result[k]),'changed':k in decisions,'routing_decision':decisions.get(k),'not_new_holdout':True,'new_semantic_grade_issued':False})
 stats={'all_plans':len(base),'bound':6694,'AI_label_scope':267,'extra_fixed_short_purpose_style':1,'incremental_overlays':len(delta),'cumulative_ABC_overlays':len(cumulative),'unchanged_bound_drafts':sum(not x['changed'] for x in allcheck),'all_other_plan_rows_exactly_unchanged':len(base)-len(delta),'housing_drafts':sum(bool(z['family']) and not z.get('clarification_only') for z in result.values()),'clarification_drafts':sum(bool(z['family']) and z.get('clarification_only') for z in result.values()),'held':sum(not z['family'] for z in result.values()),'new_contract_definitions':len(newdefs),'post_quote_slot_rows':sum('post_price_anchor' in d['replacement_plan']['fill'] for d in delta),'user_text_length':dict(sorted(collections.Counter(len(x['draft_body']) for x in drafts).items())),'routes':dict(collections.Counter(r for x in decisions.values() for r in x['routes'])),'families':dict(collections.Counter(x['family'] for x in drafts)),'regression_rows':len(regression),'length_20_to_40':sum(20<=len(x['draft_body'])<=40 for x in drafts),'length_over_40':sum(len(x['draft_body'])>40 for x in drafts),'length_under_20':sum(len(x['draft_body'])<20 for x in drafts)}
 put(O/'repair-contract.json',contract);put(O/'contract-addon.json',{'parent_v2_contract_SHA':sha(V/'repair-contract.json'),'families':newdefs});putjl(O/'incremental-plan-overlays.jsonl',delta);putjl(O/'source-bound-plan-overlays.jsonl',[cumulative[k] for k in sorted(cumulative)]);putjl(O/'CLI-draft-body-overlays.jsonl',drafts);putjl(O/'merged-semantic-labels.jsonl',[labels[k] for k in sorted(labels)]);putjl(O/'label-source-validation.jsonl',label_receipts);putjl(O/'all-bound-unchanged-validation.jsonl',allcheck);putjl(O/'old-QA-regression.jsonl',regression);put(O/'statistics.json',stats)
 protected=dict(load(V/'manifest.json')['sources_SHA256'])
 for directory in (V,S/'labels-shard0',S/'labels-shard1',A,P/'legacy-final-semantic-review-v2'):
  for path in directory.rglob('*'):
   if path.is_file():protected[str(path.resolve())]=sha(path)
 for path in S.iterdir():
  if path.is_file():protected[str(path.resolve())]=sha(path)
 for path,h in protected.items():assert sha(path)==h
 outnames=['repair-contract.json','contract-addon.json','incremental-plan-overlays.jsonl','source-bound-plan-overlays.jsonl','CLI-draft-body-overlays.jsonl','merged-semantic-labels.jsonl','label-source-validation.jsonl','all-bound-unchanged-validation.jsonl','old-QA-regression.jsonl','statistics.json','prototype-boundary-examples.json','build.py','bounded_renderer.py']
 put(O/'manifest.json',{'status':'complete_candidate_not_applied_pending_independent_local_verify','v2_READY_SHA':sha(V/'READY.json'),'v2_contract_SHA':sha(V/'repair-contract.json'),'v2_cumulative_overlays_SHA':sha(V/'source-bound-plan-overlays.jsonl'),'source_SHA256':protected,'outputs_SHA256':{n:sha(O/n) for n in outnames},'statistics':stats,'delta_apply_semantics':'deep-copy ABC row; update only frozen v2 cumulative replacement_plan; verify base_v2_applied_plan_sha256; update only v3 replacement_plan','cumulative_apply_semantics':'deep-copy frozen ABC row; verify base_merged_plan_sha256; update only v3 cumulative replacement_plan; do not double-apply v1/v2','post_quote_consumer_requirement':'Use bounded_renderer.render_plan with frozen label and post contexts for the one post_price_anchor row. Own-comment slots retain unchanged locked renderer validation. No arbitrary post prose is allowed.','new_direct_API_requests':0,'local_rendering_model_calls':0,'overall_agent_judgment_usage':'unknown','platform_calls':0,'send_attempts':0,'source_writes':0,'pointer_changes':0,'historical_classification_changes':0,'semantic_population_accuracy_claim':False})
 print(json.dumps({k:v for k,v in stats.items() if k not in ('families','user_text_length')},ensure_ascii=False,indent=2))

if __name__=='__main__':
 if '--all' in sys.argv:main()
 else:prototype()
