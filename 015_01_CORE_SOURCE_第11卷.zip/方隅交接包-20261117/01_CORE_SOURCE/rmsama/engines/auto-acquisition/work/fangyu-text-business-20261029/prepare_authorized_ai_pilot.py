"""Prepare a small AI-reviewed pilot, preserving the single frozen increment."""
import json
from pathlib import Path
from datetime import datetime, timezone
W=Path(__file__).resolve().parent
B=W/'douyin-registered-v2/increments/097511857b51e174'
now=datetime.now().astimezone().isoformat()
p=W/'rules/评论分析执行方式.json'
d=json.loads(p.read_text(encoding='utf-8'))
d.update(credits_spending_authorized_for_new_bulk_jobs=True,quota_decision='existing_credits_authorized_small_pilot_then_continue',credit_authorization_recorded_at=now,credit_authorization_quote='允许使用现有 credits，先小批核对消耗后继续')
p.write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding='utf-8')
sfile=W/'当前文本处理运行状态.json';s=json.loads(sfile.read_text(encoding='utf-8'))
s['douyin'].update(state='AI_credit_pilot_prepared',ordinary_model_calls_disabled=False,ordinary_model_calls_disabled_reason=None,model_work_budget_mode='existing_credits_authorized_small_pilot_then_continue')
s['quota_check'].update(bulk_credit_spending_choice='authorized_small_pilot_then_continue',choice_recorded_at=now)
sfile.write_text(json.dumps(s,ensure_ascii=False,indent=2),encoding='utf-8')
h=W/'双平台分工与后台文本接续.md';t=h.read_text(encoding='utf-8')
t=t.replace('新增5806条已冻结，尚未派工，等待本人选择是否使用现有额外credits。不得自动购买或默认为已同意额外credits消费。','新增5806条已冻结；本人现已明确允许使用现有credits，先做小批并核对消耗后继续。先处理首200条，未完成全批不得发布为全批完成；不购买或充值。')
h.write_text(t,encoding='utf-8')
rows=[json.loads(x) for x in (B/'input.jsonl').read_text(encoding='utf-8').splitlines()][:200]
P=B/'pilot-200';P.mkdir(exist_ok=True)
raw=''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in rows)
f=P/'input.jsonl'
if f.exists(): assert f.read_text(encoding='utf-8')==raw
else:f.write_text(raw,encoding='utf-8')
groups={}
for r in rows:
 k=(r['video_id'],r['post_body'])
 g=groups.setdefault(k,{'video':r['video_id'],'post_body':r['post_body'],'comments':[]})
 g['comments'].append({'key':r['review_key'],'text':r['comment_text'],'published_at':datetime.fromtimestamp(r['published_at_unix'],timezone.utc).isoformat() if r.get('published_at_unix') else None,'same_author':r['post_author_same_as_commenter'],'reply_to':r['reply_to'],'parent':r['direct_parent_text'],'source_conflict':r['source_version_conflict']})
payload={'analysis_date':'2026-10-29','comments':len(rows),'shared_post_context':list(groups.values())}
f=P/'grouped-model-input.json';packed=json.dumps(payload,ensure_ascii=False,separators=(',',':'))
if f.exists():assert f.read_text(encoding='utf-8')==packed
else:f.write_text(packed,encoding='utf-8')
baseline={'checked_at':now,'account_credit_balance_before_pilot':'23609.5934545000','ordinary_used_percent':100,'scope':'whole_account_not_task_specific','unit_and_currency':'not_exposed_by_usage_tool','pilot_comments':len(rows),'full_input_utf8_bytes':len(raw.encode()),'grouped_input_utf8_bytes':len(packed.encode()),'actual_task_tokens':None,'actual_task_cost':None,'caveat':'Account balance changes can include other chats. Input byte reduction is not measured token or price reduction.'}
(P/'usage-check-before.json').write_text(json.dumps(baseline,ensure_ascii=False,indent=2),encoding='utf-8')
(B/'model-work-status.json').write_text(json.dumps({'state':'pilot_prepared','owner':'root_authorized_AI_pilot','input_comments':5806,'pilot_comments':200,'dispatched_comments':0,'completed_comments':0,'remaining_not_dispatched':5806,'authorization':'existing_credits_small_pilot_then_continue','updated_at':now,'platform_calls':0,'source_modified':False},ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'pilot':str(P),'comments':len(rows),'post_groups':len(groups),'full_input_bytes':len(raw.encode()),'grouped_input_bytes':len(packed.encode()),'credits_authorized':True},ensure_ascii=False))
