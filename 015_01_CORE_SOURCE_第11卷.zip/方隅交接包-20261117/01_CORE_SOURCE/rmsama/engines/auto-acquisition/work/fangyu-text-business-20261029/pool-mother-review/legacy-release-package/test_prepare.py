import unittest, copy, hashlib, json
import prepare
class Safety(unittest.TestCase):
 def setUp(self):
  self.r={'platform':'douyin','comment_id':'1','customer_uid':'u','comment_text':'朝阳附近','source_record':{'k':1},'mother_reply_text':'old','alternative_mother_reply_text':None,'role':'demand','demand_state':'active_at_comment','interest_at_comment':'high','contact_policy':None,'contact_boundaries':[],'send_authorized':False,'can_send_now':False,'original_reply':{'text':'old'}}
  self.p={'platform':'douyin','cid':'1','uid':'u','sourceSHA':hashlib.sha256('朝阳附近'.encode()).hexdigest(),'source_file_sha256':'abc','original_classification_sha256':prepare.objsha(self.r['source_record']),'selection':'selected','family':'area','fill':{'place':'朝阳附近'},'evidence':[{'field':'place','quote':'朝阳附近'}],'hold_reasons':[],'send_authorized':False,'can_send_now':False,'contact_policy_original':None}
  self.contract={'families':{'area':{'template':'{place}帮你问','required_fill':['place']}}}
 def test_correct_and_wrong_uid_or_sha(self):
  prepare.verify_binding(self.p,self.r,'abc')
  for field,value in [('uid','other'),('sourceSHA','0'*64),('source_file_sha256','bad'),('original_classification_sha256','bad')]:
   p=copy.deepcopy(self.p);p[field]=value
   with self.assertRaises(ValueError):prepare.verify_binding(p,self.r,'abc')
 def test_missing_evidence_rejected(self):
  p=copy.deepcopy(self.p);p['evidence']=[]
  with self.assertRaises(ValueError):prepare.render_checked(p,self.r,self.contract)
 def test_no_contact_and_send_guard(self):
  for field,value in [('contact_policy','no_contact'),('contact_policy','allow'),('send_authorized',True),('can_send_now',True)]:
   r=copy.deepcopy(self.r);r[field]=value
   with self.assertRaises(ValueError):prepare.candidate_for(self.p,r,self.contract,'abc')
 def test_unknown_contact_is_preview_not_allow(self):
  r=prepare.candidate_for(self.p,self.r,self.contract,'abc')
  self.assertIsNone(r['contact_policy']);self.assertEqual(r['mother_reply_text'],'朝阳附近帮你问');self.assertTrue(r['local_mother_candidate']['contact_review_required']);self.assertFalse(r['can_send_now']);self.assertEqual(r['local_mother_candidate']['old_draft_backup']['mother_reply_text'],'old')
 def test_missing_top_level_contact_stays_unknown_even_if_reply_plan_allows(self):
  r=copy.deepcopy(self.r);r['reply_plan']={'contact_policy':'allow'};p=copy.deepcopy(self.p);p['contact_policy_original']='allow'
  o=prepare.candidate_for(p,r,self.contract,'abc');self.assertIsNone(o['contact_policy']);self.assertTrue(o['local_mother_candidate']['contact_review_required']);self.assertIsNone(o['local_mother_candidate']['renderer_text'])
 def test_selection_never_promotes_alternative(self):
  p=copy.deepcopy(self.p);p['selection']='alternative';r=copy.deepcopy(self.r);r['mother_reply_text']=None;r['alternative_mother_reply_text']='backup'
  o=prepare.candidate_for(p,r,self.contract,'abc');self.assertIsNone(o['mother_reply_text']);self.assertEqual(o['alternative_mother_reply_text'],'朝阳附近帮你问')
 def test_reject_duplicate_and_contract_conflicts(self):
  with self.assertRaises(ValueError):prepare.validate_unique([self.p,self.p])
  with self.assertRaises(ValueError):prepare.merge_addon(self.contract,{'families':{'area':{'template':'changed','required_fill':[]}}})
 def test_reproducible_candidate(self):
  self.assertEqual(prepare.candidate_for(self.p,self.r,self.contract,'abc'),prepare.candidate_for(self.p,self.r,self.contract,'abc'))
if __name__=='__main__':unittest.main()
