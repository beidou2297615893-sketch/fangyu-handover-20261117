"""Merge a frozen reviewed increment, select mother sentences locally and publish files."""
import json,sqlite3,hashlib,collections,sys,re,csv
from pathlib import Path
from datetime import datetime,timezone,timedelta
from mother_adapter import select_reply, reconcile_customers, open_source_readonly, enrich_observations, validate_new_review, human_review_lines
R=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent;B=R/'work/fangyu-douyin-independent';D=W/'douyin-registered-v2'
run=sys.argv[1];S=D/'increments'/run
def jl(p):return [json.loads(x) for x in p.read_text(encoding='utf8').splitlines() if x.strip()]
def sha(b):return hashlib.sha256(b).hexdigest()
inputs=jl(S/'input.jsonl');manifest=json.loads((S/'manifest.json').read_text(encoding='utf8'))
raw_input=(S/'input.jsonl').read_bytes();logical_input=(S/'input.jsonl').read_text(encoding='utf8').encode('utf8')
assert sha(raw_input)==manifest['input_sha256'] or sha(logical_input)==manifest['input_sha256'],'Frozen content changed'
(S/'input-integrity-reconciliation.json').write_text(json.dumps({'manifest_logical_sha256':manifest['input_sha256'],'physical_file_sha256':sha(raw_input),'logical_sha256':sha(logical_input),'windows_crlf_vs_lf_only':raw_input.replace(b'\r\n',b'\n')==logical_input,'source_input_modified':False},ensure_ascii=False,indent=2),encoding='utf8')
source={x['comment_id']:x for x in inputs}
prior=Path(manifest.get('prior_result_file',str(D/'classified-109.jsonl'))).resolve();assert prior.is_relative_to(D.resolve()) or prior.is_relative_to((B/'text-classification-snapshots').resolve())
old=jl(prior);assert sha(prior.read_bytes())==manifest['prior_result_sha256']
reviewed=[x for i in range(3) for x in jl(S/f'reviewed-{i}.jsonl')];assert len(reviewed)==len(inputs) and len({x['comment_id'] for x in reviewed})==len(reviewed) and {x['comment_id'] for x in reviewed}==set(source)
review_source_cache={}
for x in reviewed: validate_new_review(x,S,review_source_cache)
# The locked text contract uses interest/topics-with-evidence/needs_review/store_assignment.
# Accept that original representation without changing judgments or frozen review files.
compat=[]
for x in reviewed:
 if 'interest_at_comment' not in x:
  assert 'interest' in x and 'needs_review' in x and 'store_assignment' in x
  assert all(isinstance(t,dict) and 'pool' in t and 'quote' in t for t in x['topics'])
  x['interest_at_comment']=x['interest'];x['review_reasons']=x['needs_review'];x['assigned_store']=x['store_assignment']
  x['topic_evidence']=x['topics'];x['topics']=sorted({t['pool'] for t in x['topic_evidence'] if t.get('subject')=='own_demand'})
  compat.append(x['comment_id'])
if compat:
 (S/'contract-field-compatibility.json').write_text(json.dumps({'normalized_records':len(compat),'comment_ids':compat,'interest_values_unchanged':True,'topic_evidence_preserved':True,'unresolved_or_supply_topics_not_counted_as_own_demand':True,'original_review_files_modified':False},ensure_ascii=False,indent=2),encoding='utf8')
poolnames={'价格预算','位置通勤','户型面积与居住方式','房内设施','宠物','楼层电梯','入住与租期','房源状态','费用合同','看房联系'}
allowed_roles={'demand','supply','mixed','unknown','discussion'};levels={'super_high','high','medium','low','very_low','uncertain','unrelated'}
new=[]
for x in reviewed:
 s=source[x['comment_id']];assert x['customer_uid']==s['customer_uid'] and str(x['video_id'])==s['video_id'] and x['review_key']==s['review_key']
 assert x['role'] in allowed_roles and x['interest_at_comment'] in levels
 assert not (x['role']=='unknown' and x['interest_at_comment']=='unrelated'),x['review_key']
 assert set(x['topics'])<=poolnames
 x['evidence_by_source']=[]
 for q in x.get('evidence',[]):
  assert q in s['comment_text'] or s['post_author_same_as_commenter'] and q in s['post_body'],(x['review_key'],'own evidence')
  x['evidence_by_source'].append({'source_kind':'own_comment' if q in s['comment_text'] else 'verified_same_author_post','quote':q})
 for t in x.get('topic_evidence',[]):
  kind=t.get('source_kind',t.get('source','own_comment'));q=t['quote']
  assert q in s['comment_text'] or s['post_author_same_as_commenter'] and q in s['post_body'],(x['review_key'],'topic quote')
 for t in x.get('target_regions',[]):assert t['quote'] in s['comment_text'] or s['post_author_same_as_commenter'] and t['quote'] in s['post_body'],(x['review_key'],'region quote')
 assert x['send_authorized'] is False and x.get('assigned_store') is None
 if s['source_version_conflict']:
  x['review_reasons'].append('同评论存在文本、作品或作者版本冲突，需对账')
 x.update(source_version_conflict=s['source_version_conflict'],platform='douyin',comment_text=s['comment_text'],published_at=datetime.fromtimestamp(s['published_at_unix'],timezone(timedelta(hours=8))).isoformat() if s['published_at_unix'] else None,
  source_stores_seen=sorted({o['source_store'] for o in s['source_observations']}),source_keywords_seen=sorted({o['keyword'] for o in s['source_observations']}),
  source_store=s['source_observations'][0]['source_store'],source_keyword=s['source_observations'][0]['keyword'],source_observations=s['source_observations'],
  source_comment_sha256=s['source_comment_sha256'],ip_location_raw=s['ip_location_raw'],ip_is_not_target_region=True,
  post_body=s['post_body'],post_author_same_as_commenter=s['post_author_same_as_commenter'],direct_parent_text=None,
  deeper_reply_count_visible=s['deeper_reply_count_visible'],deeper_replies_read=False,registration_state='verified_local_qualified_ledger',
  rule_version='business-text-20261029-v2',current_need_verified=False,human_confirmed=False,send_attempted=False,
  review_method=('逐条AI语义初细筛；证据、字段和登记关系本地校验；不代表独立二审或用户金标' if x['classification_method']=='ai_semantic_initial_and_detailed' else '逐条AI初判及独立语义细筛；来源、证据、字段和登记关系本地校验；不代表用户金标'))
 new.append(x)
rows=old+new;assert len(rows)==manifest['eligible_snapshot_comments'] and len({x['comment_id'] for x in rows})==len(rows)
obs=json.loads((S/'all-source-observations.json').read_text(encoding='utf8'))
db=open_source_readonly(B/'runtime/collection.sqlite3')
for x in rows:
 c=db.execute("select data from entities where stable_key=? and kind='comments' and source_id=?",('comment:'+x['comment_id'],x['comment_id'])).fetchone();assert c
 actual=json.loads(c[0]);assert actual['text']==x['comment_text'] and str(actual['aweme_id'])==str(x['video_id']) and str(actual['user']['uid'])==x['customer_uid']
 x['source_observations']=enrich_observations(db,'comment:'+x['comment_id'],obs['comment:'+x['comment_id']]);x['source_stores_seen']=sorted({o['source_store'] for o in x['source_observations']});x['source_keywords_seen']=sorted({o['keyword'] for o in x['source_observations']})
ledger_total=db.execute("select count(*) from entities where kind='comments'").fetchone()[0];db.commit();db.close()
mothers=json.loads((W/'mothers/first50.json').read_text(encoding='utf8'))
for x in rows:
 select_reply(x,mothers)
 x.setdefault('mother_reply_text',None)
duplicates=reconcile_customers(rows)
rows.sort(key=lambda x:(x['published_at'] or '',x['comment_id']))
packed=''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in rows);result=S/'classified-snapshot.jsonl';result.write_text(packed,encoding='utf8')
drafts=[x for x in rows if x['mother_reply_text']];(S/'mother-drafts.jsonl').write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in drafts),encoding='utf8')
# Keep a source-local result pointer and receipt. Do not update the acquisition database.
sidecar=B/'text-classification-snapshots';sidecar.mkdir(exist_ok=True);local=sidecar/f'{run}-results.jsonl';local.write_text(packed,encoding='utf8')
high=[x for x in rows if x['interest_at_comment'] in ['high','super_high']]
storegroups=collections.defaultdict(list)
for x in rows:
 for store in x['source_stores_seen']:storegroups[store].append(x)
catalog=R/'outputs/方隅双平台文本业务/门店词库/双平台优先搜索总表.csv'
for entry in csv.DictReader(catalog.open(encoding='utf-8-sig')):storegroups.setdefault(entry['适用门店资料组'],[])
summary={'snapshot_unique_comments':len(rows),'newly_analyzed':len(new),'previously_analyzed':len(old),'unique_customers':len({(x.get('platform'),x['customer_uid']) for x in rows}),
 'interest_counts':dict(collections.Counter(x['interest_at_comment'] for x in rows)),'new_interest_counts':dict(collections.Counter(x['interest_at_comment'] for x in new)),
 'high_or_super_comments':len(high),'high_or_super_customers':len({(x.get('platform'),x['customer_uid']) for x in high}),
 'high_pool_counts':{p:sum(p in x['topics'] for x in high) for p in sorted(poolnames)},
 'by_source_store':{store:{'comments':len(xs),**dict(collections.Counter(x['interest_at_comment'] for x in xs)),'assigned_store_verified':0} for store,xs in storegroups.items()},
 'multi_source_comment_count':sum(len(x['source_stores_seen'])>1 for x in rows),'store_table_rows_not_additive':True,
 'local_mother_drafts':len(drafts),'same_customer_duplicates_prevented':duplicates,'store_assignment_verified':0,'can_send_now':0,
 'ledger_total_at_read_including_out_of_scope_and_later_pages':ledger_total,'snapshot_not_live_total':True,
 'source_qualification_policy_sha256':manifest['policy_sha256'],'excluded_known_buying_source_comments':18,
 'result_file':str(local),'result_sha256':sha(local.read_bytes()),'reply_generation_model_calls':0,'source_or_ledger_modified':False,'platform_calls':0,'actual_sent':0,
 'actual_sent_scope':'text_processing_task_only','text_task_send_attempted':False,'platform_delivery_state':'not_checked_by_text_task',
 'draft_purpose':'human_review_only_not_cli_send_input','send_approved_records':0}
(S/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf8');(B/'text-screening-current-summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf8')
O=R/'outputs/方隅双平台文本业务/抖音逐店采集与意向'
lines=['# 抖音租房来源评论：最新已分析快照','',f'本快照已分析{len(rows)}条去重评论，对应{summary["unique_customers"]}个平台客户；其中本次新增{len(new)}条。采集仍可继续，本文不是实时总量。历史来源按原人工认可清单核对，新页仅接收租房来源资格已通过且成功登记的评论；已知误选买房来源18条排除。','',
'兴趣分布：'+'；'.join({'super_high':'超高','high':'高','medium':'中','low':'低','very_low':'很低','uncertain':'待核','unrelated':'供给、讨论或已结束'}[k]+' '+str(v) for k,v in summary['interest_counts'].items())+'。','',
'|搜索来源门店|评论关联数|超高|高|中|低及很低|待核|供给或讨论|','|---|---:|---:|---:|---:|---:|---:|---:|']
for store,xs in storegroups.items():
 c=collections.Counter(x['interest_at_comment'] for x in xs);lines.append(f'|{store}|{len(xs)}|{c["super_high"]}|{c["high"]}|{c["medium"]}|{c["low"]+c["very_low"]}|{c["uncertain"]}|{c["unrelated"]}|')
lines+=['','门店表列齐15家。0条表示本快照没有已分析的合格来源评论，不代表平台没有需求或实时采集量为0。同一评论可能由多个搜索门店看到，分店关联数不能相加当去重总数。来源资格只是租房相关，不证明本人需求或该门店可承接；所有实际门店归属仍未确认。','',
f'本地母句审核稿{len(drafts)}条，同客户重复候选抑制{duplicates}条。未逐条调用模型写回复，也没有用不同人的条件拼房源承诺。兴趣针对评论时点；时效、目标地区、联系边界和缺深层回复分别保留。本窗口未发送；平台真实发送状态以发送账本为准。未改采集数据库。这些稿件仅供人工审核，不能直接作为发送清单。','',
'## 高及超高初判的需求池','', '|池|评论数|','|---|---:|']
for p,c in summary['high_pool_counts'].items():lines.append(f'|{p}|{c}|')
lines+=['','同一人可多池，上表不可相加。模型初判与结构证据校验不是用户金标或准确率；需补事实或上下文的保存待核原因，不冒称全部已核实。','']
(O/'最新已分析评论汇总.md').write_text('\n'.join(lines),encoding='utf8')
detail=[];rolelabels={'demand':'本人需求','supply':'供给','mixed':'供需混合','unknown':'身份或对象待核','discussion':'讨论经历'}
level_labels={'super_high':'超高','high':'高','medium':'中','low':'低','very_low':'很低','uncertain':'待核','unrelated':'供给、讨论或已结束'}
for x in rows:
 detail+=['────────','搜索来源：'+'、'.join(x['source_stores_seen']),'原评论：'+(x['comment_text'] or '文字为空，附件未核'),
  '发表时间：'+(x['published_at'] or '时间不明'),'身份与兴趣：'+rolelabels[x['role']]+'；'+level_labels[x['interest_at_comment']],
  '需求池：'+('、'.join(x['topics']) or '无已确认具体主题'),'依据：'+x['reason'],
  '待核：'+'；'.join(x.get('review_reasons',[])+['今日需求、实际地区及门店适配未确认']),
  '本地母句审核稿：'+(x['mother_reply_text'] or '暂缓或同客户不重复入队')]
 detail+=human_review_lines(x)+['']
(O/'最新已分析评论逐条记录.txt').write_text('\n'.join(detail),encoding='utf8')
print(json.dumps({k:v for k,v in summary.items() if k not in ['by_source_store','high_pool_counts']},ensure_ascii=False))
