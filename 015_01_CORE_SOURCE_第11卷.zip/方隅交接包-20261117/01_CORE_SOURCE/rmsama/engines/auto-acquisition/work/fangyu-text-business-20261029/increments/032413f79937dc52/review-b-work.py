import json, pathlib, collections
base=pathlib.Path('work/fangyu-text-business-20261029/increments/032413f79937dc52')
rows=[]
for n in range(4,8):
 for line in (base/f'shard-{n:02}.jsonl').open(encoding='utf-8'):
  rows.append(json.loads(line))
by={int(x['review_key'][1:]):x for x in rows}
results={}
def ids(s): return [int(x) for x in s.split()]
def setgroup(s,role,state,interest,reason,needs=None,context=('own',)):
 for n in ids(s):
  d=by[n]; results[n]={'review_key':d['review_key'],'comment_id':d['comment_id'],'customer_uid':d['customer_uid'],'role':role,'demand_state':state,'interest':interest,'topics':[],'target_regions':[],'evidence':[d['comment_text']],'reason':reason,'context_used':list(context),'needs_review':list(needs or []),'human_confirmed':False,'send_authorized':False,'store_assignment':None}
# The following explicit groups were assigned after reading each comment and its title.
setgroup('402 403 404 406 410 416 424 425 426 428 429 432 440 441 442 444 445 448 451 453 454 458 459 460 463 464 466 470 475 476 478 479 481 482 483 484 489 490 491 493 494 495 496 497 498 503 509 512 513 514 516 517 519 520 521 522 523 525 526 528 532 534 535 536 537 538 539 541 542 545 548 549 550 551 554 556 557 558 561 564 565 568 569 570 571 572 573 574 575 576 579 580 581 582 583 584 585 586 587 588 590 591 592 594 597 598 600 603 605 606 607 608 610 611 612 613 614 615 616 617 618 622 625 627 628 637 644 668 671 672 679 687 692 694 697 703 710 717 720 721 724 728 731 733 735 739 740 741 742 743 745 747 749 752 767 768 769 770 776 779 780 786 787 788 789 790 791 792 794 796','supply','unknown','unrelated','提供房源、转租、售房或招租信息，未见本人新求租条件。',context=('own','title'))
setgroup('435 452','demand','ended','unrelated','本人明确已租到或暂不需要租房。',context=('own','title'))
setgroup('446 472 485 547 626 648 656 663 708 711 725 736','discussion','unknown','unrelated','评论是房源经验、交流或评价，未明确表达本人当前租房需求。',context=('own','title'))
# Explicitly sale / purchase context: inquiry cannot become rental lead.
setgroup('408 411 418 420 433 438 439 447 450 461 465 474 485 492 502 507 510 511 515 529 531 533 595 631 634 636 639 642 659 664 675 683 690 691 695 699 709 715 716 719 750 751 753 756 757 761 766 771 778 785','unknown','unknown','unrelated','标题指向售房、置换或购买相关内容，不能据此认定本人在求租。',['如需判断买房意向需按销售业务单独核对。'],('own','title'))
setgroup('633 654','demand','active_at_comment','unrelated','评论表达对落户工具房的关注或寻找，标题语境指向购房，不可当作求租。',['需核对是否另有租房需求。'],('own','title'))
# Clearly rentable property, or directly expressed concrete rental search.
setgroup('405 407 409 413 414 415 417 419 421 422 423 427 430 431 436 437 449 455 457 462 468 469 473 480 486 487 488 499 501 504 505 506 530 544 553 555 559 566 577 596 602 629 630 635 638 640 641 645 647 649 651 652 655 658 661 666 670 673 674 676 677 680 681 682 685 686 688 689 693 696 698 700 702 704 707 712 713 714 718 722 723 726 729 734 737 738 744 748 758 759 760 762 764 765 772 773 774 775 777 781 782 783 784','demand','active_at_comment','high','本人询问可租房源或明确提出租住条件；判断仅适用于评论发表时。',context=('own','title'))
# The phrase about general viewing alone is not an appointment. 405 asks generic availability.
# Transfer title is sufficient for rental but is generic; verify exact target/state.
setgroup('632 643 646 650 653 657 665 667 669 684 701 705 706 727 730 732 754 755 763 795','demand','active_at_comment','high','针对转租房源提出本人询问，属于当时有效询盘。',['未采正文，仍需核对具体房源及当前状态。'],('own','title'))
# Listing titles lacking explicit rental; preserve ambiguity rather than infer a property offer.
setgroup('524 577 643 712 777 797 798 799 800','unknown','unknown','uncertain','询问该房信息，但现有标题不足以确认是出租还是出售。',['需核对原帖交易类型及该房源状态。'],('own','title'))
# Weak or ambiguous statements deliberately left pending.
setgroup('401 412 434 443 456 467 471 477 500 508 518 527 543 546 552 560 562 563 567 578 589 593 601 604 609 619 620 621 623 624 660 662 678 746 793','unknown','unknown','uncertain','现有评论及已存上下文无法确定本人是否有当前租房需求。',['需补充评论对象或上下文，核对供需身份及需求。'],('own','title'))
# nuanced overrides
setgroup('479','supply','unknown','unrelated','对求租者推荐通勤及标价房源，供给倾向明确，但未采房源正文。',['需核对该推荐对应的具体房源。'],('own','title'))
setgroup('534 739 740','supply','unknown','unrelated','转租保底房；本人说已看到目标区域更便宜的房，但未明确是否仍在另找。',['确认另找房是否仍在进行；不能仅据此判 mixed。'],('own','title'))
setgroup('499','unknown','unknown','uncertain','询问女生合租，但缺少直接上级评论，无法判断本人找室友还是寻求合租。',['核对直接回复对象及供需身份。'],('own','title'))
setgroup('567','unknown','unknown','uncertain','提及年租稳定但“没次数了”对象不明，不能确认本人在找房。',['需补充对话确定身份和表述含义。'],('own','title'))
setgroup('660','unknown','unknown','uncertain','问对方是否找到房，未表达本人需求，也可能是供给方。',['核对对话对象及询问目的。'],('own','title'))
setgroup('619 620 621','unknown','unknown','uncertain','询问求租帖作者的找房情况或要求，可能提供房源但身份未明确。',['核对是否提供房源。'],('own','title'))
setgroup('662','unknown','unknown','uncertain','“蹲一个搬家的”含义和具体对象不清。',['核对是否在找租房或搬家服务。'],('own','title'))
setgroup('708','discussion','unknown','unrelated','表达对隔断与隔音的担忧，但未明确本人正在求租。',['需核对是否为本人找房时的明确限制。'],('own','title'))
setgroup('734','demand','active_at_comment','high','明确提出卫生间不在阳台的条件，处于求租语境。',['直接回复对象未采，需确认是本人要求。'],('own','title'))
setgroup('754','demand','active_at_comment','super_high','对转租房源询价、索取视频并明确询问这两天能否看房。',['查看发表时点并核对原帖及房源现状。'],('own','title'))
setgroup('435 452','demand','ended','unrelated','本人明确已租到或暂不需要租房。',context=('own','title'))
# Allocate pools only based on own text, preserving exact words and polarity.
def topics(s,pool,polarity='ask'):
 for n in ids(s):
  results[n]['topics'].append({'pool':pool,'quote':by[n]['comment_text'],'polarity':polarity})
topics('409 413 421 422 423 436 455 524 530 577 596 602 629 632 640 641 643 646 647 650 651 652 653 655 657 658 665 666 667 669 670 674 682 684 688 689 693 701 704 705 706 712 713 718 723 727 730 732 737 754 755 758 763 777 783 795 797 798 799 800','价格预算')
topics('407 409 413 414 427 430 431 437 449 457 462 468 473 480 486 487 501 504 505 506 530 544 553 555 559 566 596 630 635 638 645 649 661 673 677 680 681 685 686 693 696 698 702 707 713 714 722 726 729 738 744 748 759 760 762 764 765 772 773 782 784 797','位置通勤')
topics('427 530 555 657 713','户型面积与居住方式')
topics('427 488','房内设施','require')
topics('734','房内设施','reject')
topics('405 415 417 419','费用合同')
topics('469 676 700 775 781','房源状态')
topics('405 652 754 774','看房联系')
topics('754','看房联系')
# Remove duplicate topic created by overlapping selection.
for x in results.values():
 seen=set(); x['topics']=[t for t in x['topics'] if not ((t['pool'],t['quote'],t['polarity']) in seen or seen.add((t['pool'],t['quote'],t['polarity'])))]
# Quote is from the person, never IP/title. Distinguish precise preferred area from a question about location.
regions={414:'嘉定区清能路附近',427:'12号线沿线',430:'复兴西路附近',431:'长海医院附近',457:'长宁',462:'浦东新区',473:'闵行区',480:'青浦',486:'杨浦',487:'张江',501:'漕河泾附近',504:'黄浦区',505:'浦东新区',530:'上海浦江静安',544:'普伽区',553:'黄埔或者闵行',555:'祝桥',559:'徐汇',566:'浦东',596:'静安区',630:'黄浦',638:'嘉定',645:'闵行金色西郊城',661:'嘉定江桥',680:'11号线沿线',681:'周浦印象生活广场附近',685:'塘桥',686:'嘉定安亭',707:'嘉定',713:'普陀',714:'浦东新区',722:'耀华路，成山路，东明路',738:'松江',759:'上海普陀',782:'嘉定丽江佳苑',784:'杨浦'}
for n,q in regions.items():
 assert q in by[n]['comment_text'],(n,q)
 results[n]['target_regions'].append({'text':q,'quote':q,'relation':'desired'})
# "附近" refers to an unspecified location in the listing, rather than a confirmed target area.
results[413]['needs_review'].append('“这附近”所指地点未在本人评论说明，需核对具体位置。')
results[427]['needs_review'].append('具体地铁站和当前房源可用性待核。')
results[544]['needs_review'].append('“普伽区”地区名称可能有误，不擅自改写。')
results[553]['needs_review'].append('“黄埔”是否指黄浦待本人确认。')
results[530]['needs_review'].append('“上海浦江静安”具体地域范围与并列关系待确认。')
results[405]['needs_review'].append('仅泛问能否看房，未明确预约时间或约看请求。')
# 405 asks a viewing request, per rule explicitly "方便看房吗" equivalent explicit request.
results[405]['interest']='super_high'; results[405]['reason']='明确询问方便看房，并询问水电性质；只代表当时的约看请求。';results[405]['needs_review']=['未采正文与直接回复，需核对具体房源及当前状态。']
# Other asks for location / condition must not become desired geographic area.
# For offered locations, only assign an exact location stated in the comment, where clear.
offered={402:'忠烈小区',403:'松江闵行',404:'定边路',406:'源达大厦',416:'松江小昆山镇',424:'黄浦区打浦桥',426:'江浦路地铁站',428:'虹桥站附近',429:'上海奉贤区卓越世纪中心14#',432:'徐汇滨江',440:'闵行颛桥地铁站附近',442:'北新泾地铁站',444:'高行镇汇郡海棠苑',445:'高行镇汇郡海棠苑',451:'乐秀路附近',453:'沈杜公路地铁站',454:'闵行古美路',458:'金运路地铁站',459:'东靖路地铁站附近',460:'爱博二村',464:'嘉定区嘉怡路',470:'罗南新村',475:'徐汇区 徐汇世家花园',476:'宝佳苑',478:'上海大学地铁站',481:'巷韵华庭（青浦）',482:'芳芯路',483:'芳芯路',489:'七韵美地苑',490:'虹口曲阳',491:'普陀真如',493:'嘉定新城',494:'金运路',496:'凌兆新村地铁站',497:'东靖路地铁站附近',498:'普陀区镇坪路',503:'普陀两湾城',512:'宝安公路',513:'闵行虹桥火车站附近',514:'浦锦路',519:'上海宝山',520:'静安区彭浦新村',522:'唐镇附近',523:'宝山区 罗南新村',525:'外高桥品欣雅苑',526:'安居古浪新苑',528:'崇明',532:'丽水华庭',534:'上钢一村1200弄',535:'临潼苑',536:'徐汇康健',537:'上海诗林小区',538:'上海九亭地铁站青年城',539:'嘉定新城',541:'金沙雅苑二期',545:'芳芯路地铁站',548:'源竹小区 南片',549:'通河新村',550:'呼兰路地铁站口',554:'普陀内环边',557:'上海嘉定',558:'南洋新都',564:'金运路',565:'唐镇',568:'嘉定安亭',569:'远东大道',570:'闵行万源路',571:'九昊公寓',573:'佘山镇',575:'世纪公园',576:'宝山',580:'南桥贝港三区',581:'曙建路',582:'嘉定新城地铁口',585:'上海虹桥站附近',586:'大华碧云天',588:'静安大宁',591:'普陀万里',592:'下南路地铁站',594:'金沙江路',597:'万科天空之城',598:'浦东北蔡',600:'浦东新区微山新村小区',603:'普陀中远两湾城',606:'普陀桃浦',608:'普陀真如',611:'张江春港丽园',613:'漕河泾开发区地铁口',615:'古北',616:'愚园路',618:'浦东野生动物园',622:'上海古美',625:'六灶鹿祥雅苑',627:'徐汇康健',628:'虹桥火车站附近',637:'颛桥地铁站',644:'徐家汇天钥花苑',668:'浦东双江路',671:'静安大宁',679:'颛桥 鑫峰苑',687:'奉贤区西渡鸿宝二村',692:'闵行区紫藤新园',697:'古北尚郡',703:'颛桥地铁站',710:'颛桥地铁站',717:'安顺路中山西路',721:'鑫峰院',724:'徐家汇附近',731:'双江路',733:'华丰苑',735:'翔泰苑',739:'上钢一村1200弄',740:'上钢一村1200弄',741:'颛桥宝铭苑',742:'双江路地铁口附近',745:'静安府 金茂府',747:'云和花园',770:'颛桥地铁站附近',780:'达安花园',786:'莘庄附近',787:'普陀真如',788:'闵行区银都路地铁站附近',789:'闵行区银都路地铁站附近',791:'颛桥，莘庄南广场',794:'普陀绿洲城市花园'}
for n,q in offered.items():
 if q in by[n]['comment_text']: results[n]['target_regions'].append({'text':q,'quote':q,'relation':'offered'})
# Final case-specific review: preserve ambiguous speakers and geography.
setgroup('479 513 568 596','unknown','unknown','uncertain','评论提到房源、区域或通勤，但未说明本人是找房还是在向他人推荐。',['需补充直接回复对象及供需身份。'],('own','title'))
setgroup('599','demand','active_at_comment','high','针对标题中的转租房询问位置，属于当时询盘。',['需核对该房源现在是否仍可租。'],('own','title'))
topics('599','位置通勤')
results[738]['target_regions']=[]
results[738]['needs_review'].append('本人询问松江房源位置，不自动认定接受该区域。')
results[652]['topics']=[t for t in results[652]['topics'] if t['pool'] != '看房联系']
results[652]['needs_review'].append('停车条件与房源状态需核实。')
for n in (413,530):
 for t in results[n]['topics']:
  if t['pool']=='价格预算': t['polarity']='require'
for t in results[427]['topics']:
 if t['pool']=='户型面积与居住方式': t['polarity']='require'
# Availability questions remain distinct from location and price requirements.
topics('413 414 427 430 431 457 462 473 480 486 487 488 501 504 505 530 544 553 555 559 566 630 638 645 661 680 681 685 686 707 714 722 726 759 782 784','房源状态')
for n in (530,555,713):
 for t in results[n]['topics']:
  if t['pool']=='户型面积与居住方式': t['polarity']='require'
results[774]['topics']=[t for t in results[774]['topics'] if t['pool']!='看房联系']
# Guard against accidentally omitted rows: these remain explicitly unresolved.
for n in by:
 if n not in results:
  setgroup(str(n),'unknown','unknown','uncertain','评论语义或对象不足以确认本人租房需求。',['需补充直接上下文，核对供需身份。'],('own','title'))
out=base/'reviewed-b.jsonl'
with out.open('w',encoding='utf-8',newline='\n') as f:
 for n in sorted(results): f.write(json.dumps(results[n],ensure_ascii=False)+'\n')
ins={(x['review_key'],x['comment_id']) for x in rows}; outs={(x['review_key'],x['comment_id']) for x in results.values()}
errors=[]
for n,x in results.items():
 c=by[n]['comment_text']
 for e in x['evidence']:
  if e not in c: errors.append([n,'evidence'])
 for t in x['topics']:
  if t['quote'] not in c: errors.append([n,'topic'])
 for t in x['target_regions']:
  if t['quote'] not in c: errors.append([n,'region'])
report={'input_count':len(rows),'output_count':len(results),'input_unique_key_count':len(ins),'output_unique_key_count':len(outs),'id_sets_equal':ins==outs,'all_quotes_verbatim_in_own_comment':not errors,'quote_errors':errors,'role_counts':dict(collections.Counter(x['role'] for x in results.values())),'interest_counts':dict(collections.Counter(x['interest'] for x in results.values())),'model_decisions_not_human_gold':True,'send_authorized':False}
(base/'b-validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(report,ensure_ascii=False,indent=2))
