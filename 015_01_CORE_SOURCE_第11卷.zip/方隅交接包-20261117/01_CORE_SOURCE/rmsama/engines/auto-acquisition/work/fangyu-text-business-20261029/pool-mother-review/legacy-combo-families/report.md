# Local combination-family addon: technical handoff

- Selection: exact next_action_category=integrated_family_gap_no_reclassification_needed in immutable legacy-local-planning/local-proposed-plans.jsonl, 223 rows.
- Bound: 221; unbound: 2 (index20/cid 7587452926210573093, index106/cid 7667464103624147775).
- New combo_ families: 21; bound to addon:147; reused unchanged base families:74.
- Existing field blocks retained verbatim in source_original_preserved and source_field_evidence. Classification fingerprint recomputed against current protected source_record, all223 equal.
- Independent validator reloaded both actual source files, compared snapshot records, original plans, CID/UID/text SHA and source-file SHA; checked all81 contiguous literal spans,221 fixed-template renders,24 protected input files and20 old-manifest files. PASS.
- Contact original null:47, effective unknown. Send authorization and can_send_now false for every plan/preview. No source writes, pointer changes, API/platform calls or send attempts.
- Base f98 contract and renderer validation pattern reused; base contract unchanged. No new tool/framework needed, no external search needed for this bounded known route.
- New family phrases are batch-review candidates, not individually user-approved. No intent accuracy or platform acceptance claim.

## Files

- contract-addon.json: only new combo_ families, base SHA binding, no base modifications.
- source-bound-plans.jsonl: all223 original source-bound plans plus fixed family/fill/evidence or specific gap.
- rendered-preview.jsonl:221 fixed-template local previews;2 null gap previews.
- representative-validation.json:25 representatives run before full expansion.
- validation.json, independent-validation.json, row-validation.jsonl: full checks.
- source-manifest.json, artifact-sha256.json: input/output provenance.
- build_combo_plans.py: local deterministic build only.
- validate_combo_plans.py: independent protected source re-read checks.

## Reproduction

Run build_combo_plans.py, then validate_combo_plans.py locally. They write only this directory, perform no platform/network/model calls, and do not apply to current consumers. The input snapshot is limited to these223 selected rows; source files remain read-only.

## Scope evidence

- index71: monthly rental price plus inclusion of utilities, not lease duration or a confirmed inclusive quote.
- indices31/59/60/62/97/98/102/121/122/125/135/151/182: workplace relation retained, no desired-home relation invented.
- index137: old missing_facts contained family-whole-unit/all-mandatory-fees requirements absent from own comment; retained only as original source fields and excluded from fill/preview.
- index218: two noncontiguous room spans use room_a/room_b, not a fabricated continuous quote.
- indices12/70/127: contact route retained together with viewing/location.
- No pet or time conditions in selected223; no invented demonstration or cross-corpus claim.
