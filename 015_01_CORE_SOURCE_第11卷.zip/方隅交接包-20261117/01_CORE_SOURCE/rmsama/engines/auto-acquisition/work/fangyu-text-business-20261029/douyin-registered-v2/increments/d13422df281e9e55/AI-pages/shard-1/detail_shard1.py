"""Explicit model detailed decisions; no keyword screening or inferred missing rows."""
import json,pathlib,datetime,calendar,shutil,hashlib
P=pathlib.Path(__file__).resolve().parent
SRC={r['review_key']:r for r in map(json.loads,(P.parent.parent/'shard-1.jsonl').read_text(encoding='utf-8').splitlines())}
rows={}
for i in range(4):
 p=P/f'reviewed-{i:02}.jsonl'; backup=P/f'initial-reviewed-{i:02}.jsonl'
 if not backup.exists():shutil.copyfile(p,backup)
 for row in map(json.loads,backup.read_text(encoding='utf-8').splitlines()):rows[row['review_key']]=row
def note(k,s):rows[k]['needs_review'].append(s)
def extra(k,q,s):rows[k]['other_constraints'].append(dict(quote=q,detail=s))
def time(k,q,role,norm,verification):
 anchor=datetime.datetime.fromtimestamp(SRC[k]['published_at_unix'],datetime.timezone(datetime.timedelta(hours=8))).isoformat()
 rows[k]['time_mentions'].append(dict(quote=q,time_role=role,anchor_source='frozen_comment_published_at_unix（北京时间）',anchor_time=anchor,normalized=norm,verification=verification))
def region(k,quote,rel,group='unknown',detail=None):
 row=rows[k]
 for x in row['target_regions']:
  if x['quote']==quote:x['relation']=rel;x['group_relation']=group;x['condition_scope']=detail or SRC[k]['comment_text']
def flags(k,**kw):rows[k]['context_flags'].update(kw)
def serious(k):rows[k]['reply_plan']['tone']='serious'
# Ambiguous numeric housing enquiries are preserved only as possible topics.
for k,q in [('D0032','多少米'),('D0227','多少米'),('D0461','多少米 怎么算'),('D0464','多少米'),('D1649','多少米'),('D1865','多少米'),('D1871','多少米'),('D1514','得多少米'),('D0176','多少'),('D0188','多少'),('D0431','多少'),('D0629','多少'),('D0716','多少呀'),('D0941','多少呀'),('D0806','多少'),('D0809','多少'),('D0812','多少'),('D0815','多少'),('D0818','多少'),('D0842','多少'),('D1019','多少'),('D1022','多少'),('D1223','多少'),('D1232','多少'),('D1235','多少'),('D1238','多少'),('D1289','多少'),('D2009','多少'),('D2054','多少'),('D2060','多少'),('D0329','多少')]:
 rows[k]['possible_topics']=[dict(quote=q,candidate_pools=['价格预算','户型面积与居住方式'],ambiguity='原问句未明确金额或面积；房屋语境可支持询盘，但不能确定指标。')]
 note(k,'先澄清所问为租金、面积或其他指标；不将候选池统计为确定需求。')
rows['D1514']['topics']=[x for x in rows['D1514']['topics'] if x['pool']!='价格预算']
rows['D1514']['reason']='求彭埠江景独卫阳台并问多少米，数值指标未澄清。'
# Other explicitly ambiguous numbers are not supplied as definite budgets.
for k,q,ambiguity in [('D0116','两个3250','两个所指为人数、房间或报价对象不明。'),('D0341','5.5','裸数字含义单位均未知。'),('D0434','3500','可能预算、报价或评论价格，供需身份未知。'),('D1463','1开头','可能价位提示或其他数字，不能补位数与对象。'),('D1757','真的70','单位及是否笔误未明，不改写成700。')]:
 rows[k]['possible_topics']=[dict(quote=q,candidate_pools=['价格预算'],ambiguity=ambiguity)]
# Explicit non-pool conditions.
extra('D0308','能免费停车','同一房源须可免费停车；不能只核五人及2500预算。')
extra('D0254','车好停吗','需核停车便利、可用车位和全部停车费用。')
extra('D0425','朝南的','朝南为本人所求朝向；需与2000预算及独立厨卫联立核同房。')
extra('D1004','可以免费停车','供给房源自称免费停车，非本人另找房条件，真实性未核。')
extra('D1730','女生','可能自报性别或限定女性合租对象，不自动推断室友性别硬限制。')
extra('D0980','本人烹饪专业毕业的','自报专业及愿意做饭，不用于推断收入或扩大预算。')
extra('D0980','有厨房的话可以做饭一起吃','厨房为条件表达而非无条件硬要求；找室友是单独可接受方案。')
extra('D0740','因为公司位置经常变动 有时候在城北拱墅，有时候又在城南滨江','工作地点变动，两地作为通勤参照，不能当作两个都必须入住的目标。')
extra('D0500','去协和医院','医疗目的地，不是本人明说的工作地；住宅或陪诊暂住用途、时长均需核。')
region('D0500','协和医院','unresolved')
region('D1106','光熙门','unresolved')
note('D1106','光熙门是通勤参照点，未明确为工作地或目标住所，不替本人确定。')
extra('D1925','有原房东吗','寻原房东对象；未明确全面拒联，也未证明本账号满足身份。')
extra('D1304','求购锦江区精装套四，房龄新点','明确购买用途，精装修和较新房龄保留；不生成住宅租赁推销稿。')
extra('D1538','买来孩子读书用','购房教育用途，非租房；面积不要太大。')
rows['D1304'].update(role='demand',demand_state='active_at_comment')
rows['D1538'].update(role='demand',demand_state='active_at_comment')
note('D1304','购买需求不作租赁商机；不据地名和套四推定接受方隅租房。')
note('D1538','购买需求不作租赁商机，不能把问房人过滤成无身份信息。')
extra('D1517','共用一张床吗','只是询问合租形式，不代表本人接受共床或床位租。')
extra('D0998','签不下来国道互砍','夸张冲突措辞不得复述为回复，不当作已签约或暴力行动事实。')
serious('D0998')
rows['D0998']['reply_plan']['caution'].append('先核询租真实性，严肃平和，不接续冲突语言。')
# Exact identity restrictions remain scoped, and are not blanket no-contact.
rows['D0134']['contact_boundaries']=[dict(quote='如果你是个人房东',scope='本人只邀请满足个人房东身份及无中介费、水电租户自己交条件的对象留言。')]
rows['D0134']['reply_plan']['contact_policy']='identity_restricted'
rows['D0134']['reply_plan']['caution'].append('不得将普通住户身份冒充个人房东；先核身份和费用条件。')
note('D0134','个人房东是明确接触条件；商业公寓及当前账号身份是否可承接待核。')
rows['D1925']['contact_boundaries']=[dict(quote='有原房东吗',scope='询原房东房源，不扩大成全面拒绝任何联系。')]
rows['D1925']['reply_plan']['contact_policy']='identity_restricted'
rows['D1925']['reply_plan']['caution'].append('先核原房东对象偏好及本账号身份，不冒充原房东。')
# Explicit apartment rejection blocks generic apartment promotion, not all contact.
rows['D1181']['reply_plan'].update(preferred_mother_slot=None,generic_intro_suitable=False,missing_facts=['客户明确不要公寓；当前方隅产品是否属于其排除范围、是否愿意了解替代方案未核。'],caution=['保留套一需求，但不得直接推荐其明示拒绝的公寓。'],contact_policy='allow')
note('D1181','不要公寓是本人硬排除；不能因高意向强推通用公寓母句。')
# Family assistance remains valid demand and uses a serious register.
for k in ('D0242','D1166','D0500'):serious(k)
flags('D0242',family_assisted_demand=True)
extra('D0242','父母住一间我住一间','本人主动为父母及自己求两间，不能当作仅谈别人需求。')
# Region alternatives retain OR; mixed hierarchical points are not flattened into alternatives.
region('D0419','景西路附近','accepted','OR')
region('D0419','双柏路附近','accepted','OR')
for k in ('D0914','D0920','D1307','D1925'):
 note(k,'并列地名可能为范围层级或邻近参照；未明确AND/OR时保留unknown，不擅自扩大区域。')
extra('D0527','30.1公里每天上下班','现有长通勤经历；是否准备换房未明，保留追核机会。')
note('D0527','需问是否因现有通勤考虑另租；未明确前不是当前求租高兴趣。')
for k in ('D0542','D0710','D0962','D0212','D1121','D2030'):
 note(k,'描述现居或通勤不等于无后续机会；是否准备换房尚未表达，不能当作已结束新需求。')
# Housing applications and old source facts need the real applicable scope.
note('D0638','原帖有青年驿站语境，需核具体申请项目及资格，不当作约看或可售库存。')
note('D1016','原帖同时包含人才/保障住房语境，实际可申请资格及商业公寓接受意愿未明。')
note('D1466','这是2024年同作者推广补充，非当下优惠依据；不得推广为当前活动或全门店价。')
note('D2033','原帖明示一年起租，与本人只租一月有冲突；仅保留已批准租期母句候选，未核前不能声称可住。')
rows['D2033']['reply_plan']['missing_facts'].append('需核确有接收仅一个月的同店房源；不能直接沿用原帖一年起租项目。')
for k in ('D1466','D0356','D0515','D0908','D1004','D1940'):
 flags(k,supply_facts_unverified=True)
# Time roles are written explicitly and anchored only to the frozen publication.
time('D0053','马上暑假了','move_in',None,'暑假起止及入住日未明；发表时为2026-06-12，不用分析日锚定。')
time('D0053','短租','lease_duration',None,'未说具体总时长，低价短租攻略请求。')
time('D0368','明天','viewing','2026-10-01','以2026-09-30北京时间发表锚定次日；仅请求，预约未确认。')
time('D1283','周末','viewing','2025-06-28/2025-06-29','按2025-06-25发表后最近周末候选；具体哪天和看房时段待核。')
time('D0230','月底到期','other','2026-06-30','现居到期，非新租总时长；到期当日及当前是否换租仍需核。')
time('D0254','月底之前','move_in','before 2026-07-31','从2026-07-23发表锚定当月底前需两间；具体交付日待核，不等于只租到月底。')
time('D0887','月底换房','move_in','2026-10 end','以2026-10-02发表锚定十月底换房，具体日期未定。')
time('D0971','短租3个月','lease_duration','P3M','明确总租期三个月，起租日期未说。')
time('D1103','两到三个月','lease_duration','P2M/P3M','总租期为大概两至三个月，不假定入住日。')
time('D1355','下周','other','2026-08-24/2026-08-30','2026-08-22发表所述下周入职，不当作准确入住日或未来才找房。')
time('D1466','免租两个月','other','P2M rent_free_claim','供给方2024年活动口径，非租赁总时长，现时效未核。')
time('D1940','八月中旬回学校','other','2026-08 middle','以2026-08-06发表推定同年八月中旬返校，日期不精确；不是本人新房入住。')
time('D1628','明天到达上海，就租','move_in','2026-09-14','以2026-09-13发表锚定次日抵沪及求租计划，不表示已签约或精确入住完成。')
time('D1766','明年去杭州','other','2026','2025-09-10发表所述下一年；未说明届时才找房，不因未来迁往改成未来才推进。')
time('D1922','去杭州了租','search_start',None,'条件是以后到杭州再租；目前是否同步咨询未知，不锚成分析日。')
time('D1382','年租','lease_duration','P1Y','询年租价格及对应租法，是否确定签一年待核。')
time('D0467','月租','lease_duration',None,'询可否月租，不自动认定总租期恰好一月。')
time('D0860','短租','lease_duration',None,'短租具体月数未提供。')
for k in ('D1079','D1796','D1631'):time(k,'长租','lease_duration',None,'长租具体总时长未给；月租问价不当作总时长。')
time('D0143','急租','search_start',None,'评论时急求租，未说具体入住日期，不归一到分析当天。')
time('D0764','急租','search_start',None,'评论时急求租，具体入住日未提供。')
# All final per-key detailed results and the exact pre-detail bytes stay page-local.
for i in range(4):
 old=[json.loads(x) for x in (P/f'initial-reviewed-{i:02}.jsonl').read_text(encoding='utf-8').splitlines()]
 final=[rows[r['review_key']] for r in old]
 for r in final:
  s=SRC[r['review_key']]['comment_text']
  for field in ('topics','target_regions','time_mentions','other_constraints','possible_topics','contact_boundaries'):
   for item in r[field]:
    if isinstance(item,dict) and 'quote' in item:assert item['quote'] in s,(r['review_key'],field,item['quote'])
  assert all(q in s for q in r['evidence'])
 p=P/f'reviewed-{i:02}.jsonl'
 p.write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in final),encoding='utf-8')
 print(i,len(final),hashlib.sha256(p.read_bytes()).hexdigest())
(P/'detailed-decisions.json').write_text(json.dumps({k:v for k,v in rows.items()},ensure_ascii=False,indent=1),encoding='utf-8')
