import json,pathlib,collections
W=pathlib.Path('work/fangyu-text-business-20261029'); c=json.loads((W/'region-brand-routing/current.json').read_text(encoding='utf8')); ids={(r['platform'],r['cid'],r['uid']) for l in open(W/'pool-mother-review/legacy-inventory/proposed-local-plan.jsonl',encoding='utf8') if (r:=json.loads(l))}; out=[]; cases={'all_in':lambda t,a:'水电' in t and ('预算' in t or any(z in t for z in ['以内','包括','含','左右'])),'budget':lambda t,a:'预算' in t and len(t)<45,'lease':lambda t,a:any(x.get('time_role')=='lease_duration' for x in a.get('time_mentions',[]) if isinstance(x,dict)) and len(t)<35,'other_subject':lambda t,a:any(x.get('subject')=='other_person' for x in a.get('topic_evidence',a.get('actual_pools',[])) if isinstance(x,dict)),'first_person':lambda t,a:('我租' in t or '我们预算' in t or '我想租' in t) and len(t)<45,'negation':lambda t,a:any(z in t for z in ['不要','不想','不能']) and len(t)<45,'unknown_contact':lambda t,a:False}; counts=collections.Counter()
for p,f in c['results'].items():
 for l in open(f,encoding='utf8'):
  r=json.loads(l)
  if (p,r['comment_id'],r['customer_uid']) not in ids:continue
  s=r.get('source_record') or {};a=s.get('classification') if isinstance(s.get('classification'),dict) else s;t=r['comment_text']
  tags=[k for k,fn in cases.items() if fn(t,a) and counts[k]<2]
  if tags:
   for k in tags:counts[k]+=1
   out.append({'platform':p,'cid':r['comment_id'],'uid':r['customer_uid'],'tags':tags,'text':t,'ev':a.get('topic_evidence',a.get('actual_pools',a.get('topics'))),'regions':r.get('target_regions'),'time':r.get('time_mentions'),'constraints':a.get('other_constraints'),'contact':r.get('contact_policy'),'parent':s.get('direct_parent_text'),'post_id':s.get('video_id',s.get('note_id')),'post':s.get('post_body')})
print(json.dumps(out,ensure_ascii=False,indent=1))
(W/'pool-mother-review/legacy-local-planning/extra-selection.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8')
