"""Optional attributed-post-slot wrapper. The locked own-comment renderer is unchanged."""
import hashlib,json,copy,string
def canonical_sha(x):return hashlib.sha256(json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def render_plan(row,own_text,contract,base_render_plan,post_contexts=None,semantic_label=None):
 mother=row['reply_plan']['local_mother'];definition=contract['families'][mother['family']];post=set(definition.get('attributed_post_fields',[]))
 if not post:return base_render_plan(row,own_text,contract)
 assert post=={'post_price_anchor'},'Only the narrow original-price reference slot is enabled'
 assert semantic_label is not None and any(x.get('relation')=='price_range_for_new_search' for x in semantic_label['price_relation'])
 assert semantic_label['source_comment_sha256']==hashlib.sha256(own_text.encode()).hexdigest()
 assert semantic_label['platform']==row['platform'] and str(semantic_label['cid'])==str(row['comment_id']) and str(semantic_label['uid'])==str(row['customer_uid'])
 f='post_price_anchor';value=mother['fill'][f];e=[x for x in mother['evidence'] if x['field']==f];assert len(e)==1;e=e[0]
 assert e['policy']=='attributed_post_quote_only' and e['not_customer_requirement'] is True and e['not_Fangyu_fact'] is True
 ctx=post_contexts[e['context_key']];content=ctx['content'];assert ctx['content_sha256']==canonical_sha(content)==e['context_sha256']
 assert content['post_id']==e['post_id'] and e['source_field'] in ('post_body','post_title')
 raw=content.get(e['source_field']) or '';assert e['post_field_sha256']==hashlib.sha256(raw.encode()).hexdigest()
 assert value==e['quote'] and value in raw and value in e['AI_citation']['quote'] and e['AI_citation']['quote'] in raw
 assert e['AI_citation']['source']==e['source_field'] and ('原帖标的{'+f+'}') in definition['template']
 # Require the exact cited evidence in the frozen semantic label, not an arbitrary excerpt of source prose.
 def citations(x):
  if isinstance(x,list):
   for y in x:yield from citations(y)
  elif isinstance(x,dict):
   if 'source' in x and 'quote' in x:yield x
   for y in x.values():
    if isinstance(y,(list,dict)):yield from citations(y)
 assert e['AI_citation'] in list(citations(semantic_label))
 own={k:v for k,v in mother['fill'].items() if k not in post};evidence=[x for x in mother['evidence'] if x['field'] not in post]
 probe=copy.deepcopy(row);probe['reply_plan']['local_mother']={'family':'own_probe','fill':own,'evidence':evidence}
 probe_contract={'families':{'own_probe':{'template':'宝宝，'+'、'.join('{'+k+'}' for k in own),'required_fill':list(own)}}}
 result=base_render_plan(probe,own_text,probe_contract)
 assert set(mother['fill'])==set(definition['required_fill'])=={k for _,k,_,_ in string.Formatter().parse(definition['template']) if k}
 text=definition['template'].format(**mother['fill'])
 if row['reply_plan'].get('tone')=='serious' and text.startswith('宝宝，'):text=text[len('宝宝，'):]
 result.update(family=mother['family'],validated_plan_text=text,text=text if result['text'] is not None else None,literal_fields=list(own.values()),attributed_post_fields=[f])
 return result
