# 百万级评论本地优先文字流水线

用户已授权直接执行，准确性优先；规则稳定的普通评论本地处理，语义疑难集中复核，可接受低成本模型辅助，但不逐条重复调用。软件后续可选DeepSeek；本窗口不接付费接口、不改客户端或平台采集发送。

## 路线与边界

沿用Python/SQLite及既有原始账本，词匹配复用pyahocorasick 2.3.1（BSD-3-Clause，项目vendor内）；配置化业务语义判断补足该库不能提供的租赁供需、否定、时间和门店规则。FlashText作为对比候选，当前不采用。GPU不用于简单词匹配。

不采用逐条模型主链路；也不采用单纯命中词就判高意向的路线。保留旧12409条模型初判作为历史参考和回归材料，不改写成新规则结果，不当人工金标准。

## 稳定接口

`local_classifier.py`提供`LocalClassifier(config_path=None)`、`classify(record: dict) -> dict`、`choose_mother(result: dict, mothers: list) -> dict`。

输入字段与原冻结input一致：platform/comment_id/customer_uid/video_id/comment_text/published_at_unix/post_body/post_author_same_as_commenter/direct_parent_text/reply_to/source_version_conflict/source_observations/ip_location_raw/deeper_reply_count_visible。

输出带回身份与原文，保留role、demand_state、interest_at_comment、topics（确认本人需求池名列表）、topic_evidence（pool/quote/subject/polarity/condition_scope）、target_regions、time_mentions、other_constraints、possible_topics、evidence、reason、review_reasons；增加classification_method、rule_hits、exception_type、needs_model_review、model_calls=0。current_need_verified=false、assigned_store=null、send_authorized=false、can_send_now=false。

机器枚举固定：role=demand/supply/mixed/discussion/unknown；interest_at_comment=super_high/high/medium/low/very_low/uncertain/unrelated；demand_state=active_at_comment/future/ended/historical/unknown。中文等级只用于人读导出，不能写入机器枚举。分类器公开rule_version字符串（本实现版本local-rules-20261029-v1，可含配置摘要）；choose_mother返回mother_slot、mother_reply_text、reply_status、reply_generation_model_calls=0以及上述无授权安全字段，供协调器合并，不改变原分类。

每个引文必须逐字来自本人评论，或输入明确核实同作者的正文；他人正文只解释对象。主题命中不代表求租或高意向；只给词名但不能判主体时作为possible_topics/unresolved。十池及业务语义沿用现行锁定规则。

明确供给与新需求分开，明确已租好且无新需求为ended；已租出去了吗是房态问句。未来入住与未来才开始找分开。明确约看才可超高，微信/泛看房不自动超高。未知不写无关。IP、来源店、工作地不当目标店。数字与上下文敏感条件不跨人复用。

纯资料缺失不能靠模型补造：标needs_context且needs_model_review=false。只有资料已具备、规则仍不能可靠解释的语义冲突/复合条件等标needs_model_review=true，按场景聚合；默认模型调用为0。相似表达只聚合，不复用具体预算、地区、日期或角色判断。

母句只选既有user_approved的版本；当前通用推荐母句slot1，家庭严肃语境可去宝宝；不新增具体房租、空房、设施和门店事实。需求明确的中高及超高可备稿，供给/结束/未知不硬套；每个平台同客户仅一个本地候选，历史真实发送及未知回执不被触碰。

## 增量与百万规模

`run_local_pipeline.py --max-new 5000`为唯一离线执行入口，manifest标验收前可用`--dry-run`/测试源，正式运行需明确verified状态。采集SQLite仅mode=ro；派生SQLite另建本目录state，不附带任何平台/模型网络客户端。

历史当前结果一次流式导入派生results作为historical_model；随后不重判旧条目。源observations按rowid增量复制最少元数据和原文摘要，派生库自建stable_key/request_id索引；每轮从源attempts更新成功parsed的合格来源关系，避免unknown后转parsed而被游标漏掉。手选来源须同时校对policy账号，其他页须eligibility.state=eligible；买房误源不得进入。search实体增量缓存作品描述及作者，仅必要时用。

只为缺少结果的合格评论按源stable_key主键取原文；一次最多5000，批次提交、内存有界。结果主键含平台与稳定评论标识，规则/输入/上下文摘要用于版本及幂等保护。重跑不新增重复候选，源身份/版本冲突留异常。历史原始JSONL/采集源库/真实回执全部保留。

CLI可读结果为流式JSONL、按意向及十池统计、人读汇总、同客去重母句、异常分组及当前结果指针。百万级不一次读入全部结果或每批重写全部历史快照；派生SQLite保留完整记录，增量文件及稳定查询/导出入口可读，旧文件仍有版本。

## 验证

先业务边界测试，再至少200条未参与调词的历史对照（模型参考不是人工金标），分别报告本地可确定、资料缺口、语义复核、与旧模型一致/分歧，不把词命中算准确率。重点是供给、否定、已结束、跨地区、未来入住、数量单位、同作者正文及多需求。

验证增量、重跑零重复、只读源库、无网络/模型调用、母句事实不新增；使用有界内存对百万条合成输入做性能压力检查，报告实际时间和内存，不把合成压测当百万真实评论准确率。未通过时不启用正式接续，不回退逐条模型。

## 软件交接

本地规则/场景例库/母句版本可由软件复用，模型后端可配置DeepSeek等，使用真实usage统计每千条输入输出token与费用；未有usage只标估算。根据抽查质量、分歧、模型调用比例及实际成本选择路由，不为省token强判，不因模型便宜而每条重读全文和重写回复。
