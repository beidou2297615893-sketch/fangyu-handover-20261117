import pathlib,json,hashlib,collections
O=pathlib.Path(__file__).resolve().parent;R=O.parent/'legacy-release-repairs'
def load(p):return json.loads(pathlib.Path(p).read_text(encoding='utf-8-sig'))
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def put(n,x):(O/n).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
cases=load(O/'review-input.json');contexts=load(O/'shared-contexts.json');v=load(O/'initial-validation.json')
notes={
'7678239814047449905':('contact_direction','闵行区与请对方联系本人均保留；没有改为获取号码或声称已联系。'),
'7699026168108106523':('contact_direction','温江询房与联系本人合并保留；历史当前状态待核未转成已确认。'),
'6a365d4a0000000014039b90':('purpose_confirmation','源明确用途未决；先问住房对象再承接有无与位置，无品牌推广。'),
'7686835983463170870':('neutral_rate','没有本人周期；中性租金并问空房，未倒灌源公寓设施。'),
'7581408098686878501':('neutral_rate','中性租金替代月租；未把源帖宠物友好当本人要求。'),
'7628833450720641851':('neutral_rate','有无房及金额询问并存，不再新增月周期。'),
'7654649452104106767':('neutral_rate','不添加报价周期或认领源帖房东身份；保留房态价格待问。'),
'7677510189944177467':('neutral_rate','无月周期新增；不把源帖物业网络费用承诺写进草稿。'),
'6ad9f1d4000000001203823b':('neutral_rate','标题已出租属于现房态提醒，仍保存；草稿只表示帮问，未声称原房可租。'),
'7695641380349559587':('neutral_rate','重复有无问题自然合并，租金不强定周期。'),
'7683707599766979385':('neutral_rate','租了没有与租金均为待问，不推出当前仍在或周期。'),
'6ae2bd1b00000000130068c5':('purpose_confirmation','缺住宅对象时先确认用途，联系方式待问，不再反向点我聊。'),
'7564803578410386233':('metric_confirmation','保留一室户并明确数值指标确认，不默定租金或面积。'),
'6ae23912000000000b017f32':('purpose_confirmation','实际标题无住宅线索；用途确认与价格后续承接成立，去重限制仍独立。'),
'6aaf3d85000000001303f174':('source_object_confirmation','实际一室一厅标题有住房线索；确认的是所询原房与方隅选择，未再误判住宅用途。'),
'7694770413826376506':('metric_confirmation','位置和未知多少指标均保留，未改变原池。'),
'7665404653265339193':('metric_confirmation','源AI明确指标未明；新问句保留一居室和指标歧义。'),
'7620394027410801414':('neutral_rate','租赁对象与金额确认仍在，月租已改为中性租金。'),
'7255871509112030012':('named_object_confirmation','朗芳园一居租金原对象保留，方隅仅为是否考虑的备选，无项目关系或优惠混同。'),
'7669110378022159146':('price_scope','<3000完整保留，独卫单间接受合租和地点均未删，未再从require增预算。'),
'6a6ccd5d0000000009014618':('lease_semantics','只问短租多久，无最长、固定月数或月报价新增。'),
'7700564058365723441':('recommendation_work_scope','二环和平门是通勤目的地，预算2-3k有本人原话，动作已回推荐房源。'),
'7684075599099478820':('price_scope','1000-1200是价格条件询房与位置，不再预设广告实价或本人预算。'),
'7672626211214934790':('contact_direction','瓶窑附近2室一厅与房东联系本人的方向均保留，发送账号没有自称房东。'),
'7659693892442489649':('lease_semantics','按月短租模式表达一次，具体期限待问；没有当成月价，类型指代保留。'),
'7636676032036094757':('contact_direction','联系本人、徐家汇、单间公寓均保留，不改为索号码。'),
'7688079252282164005':('recommendation_work_scope','推荐房源替代租房流程，源教程未转成本人流程请求。'),
'7622875857048617765':('multi_action','单间、明确一个月租金、约看时间、联系方法四项均保留。'),
'7698422052085498675':('contact_direction','私一下按请求对方私聊本人承接，价格问题保留，无已发状态。'),
'7642635546086785833':('contact_direction','一室一厅、租金、私聊本人均保留，不转联系方式。'),
'7684064954102563636':('named_actor','找小姐姐看房完整作为待问安排，未把发信人认成小姐姐。'),
'7661815509964473088':('lease_semantics','能否按月租、租金、位置三个含义分开，不把租赁方式当价格周期。'),
'7594158042996851513':('source_object_confirmation','这套房原对象确认与位置、私聊本人共同保留，不泛化成方隅库存。'),
'7572120511053955889':('contact_direction','明确一个月计价与私聊渠道保留；无私我时不硬定发起方。'),
'7469838306076410624':('multi_action','有无、看房、联系方法均保留，未宣称约看完成。'),
'7658716647620379441':('source_object_confirmation','这套原帖对象及所指房源租赁对接保留；没有推送替代房，排他需求未被改成可替代。'),
'7696414781808689957':('source_object_missing','租金位置及私聊方向已修，但原评这个指向源帖公寓，最终无对象引用且开头我住方隅；对象被泛化。'),
'7650141787701314350':('place_confirmation','京东附近5公里完整保留并询具体哪处；没有用IP或来源门店定位。'),
'7693129902963049250':('lease_semantics','短租只表达一次待问，不新增期限或月价。'),
'7669778373426365238':('price_scope','武侯区套一与1500价位询有无保留，不预设广告价或本人预算。'),
'7701664972170969914':('recommendation_work_scope','杭州与哪里能租到由位置和推荐动作承接，不再问租房流程。'),
'7255695817427174179':('comparative_price_confirmation','这么便宜的比较价参照保留为问题，未擅填价格或退回一般便宜偏好。'),
'7678171178498556726':('explicit_budget_positive','本人预算六千、大点一居、电梯及附近地点完整；没有源帖入住日倒灌。'),
'7701496021305934634':('recommendation_work_scope','原租房意愿承接为找房推荐，不擅定流程；租金问题保留。'),
'7690164371854951225':('contact_method_positive','确实在问联系方法，联系方式帮问仍适配。'),
'7696331141074207497':('explicit_rate_positive','本人多少米一个月明确月计价；未把原帖剩8个月当客户租期。'),
'7665130906604061475':('kind_reference','这种类型指代已保留，不声称本品牌同款现价或仅接受原套。'),
'7685400860373222179':('geography_OR','登云佳园或附近原替代范围保留，无强制园内限定。'),
'7582274070550119225':('price_scope','500保持价格条件，不再依据require写成个人预算。'),
'7364774505778643753':('proximity_pet','一房两厅、宠物友好、近地铁和租金同为待核，proximity未丢；不承诺全部可满足。'),
'7509108395146199844':('proximity_work','宣武门明确工作地，近一点与一千左右价位均保留，不新增住址或通勤时长。'),
'7447474699702977314':('utility_alternative','民用还是商用二选询问保留，水电不再复读，不擅报价格。'),
'7679144481312768826':('lease_semantics','可住房语境下短租有无待问，未知时长不构成永久模板hold。'),
'7664654168267686713':('lease_semantics','短租一个月保持租期而非报价周期。'),
'7677175967064916773':('explicit_budget_work_positive','未改相邻例：鼓楼大街保持工作地，预算1w有本人明确用词。'),
'7689489892791092002':('geography_OR','未改相邻例：完整或选路段保留，不擅重排边界或转成全需满足。'),
'7666365069089669942':('new_short_lease','源正文明确沙河方隅公寓，新增仅问短租是否可租及期限，无月数新增；联系未知不升级。'),
'7678169405322789678':('new_short_lease','原帖住宅房间语境充分，纯短租可用待问稿；未搬入帖主870、朝南或合住等事实。'),
'7694578248827749120':('new_short_lease','正文明确公寓转租，新增纯短租待问成立；未冒称当前可租或已联系。'),
'6acf7c9f0000000008031dc0':('new_short_lease_purpose_bypass','实际标题仅个人转租且无正文，源blocking明确住宅用途未决；新增纯短租分支提前return，草稿仍推广方隅优惠，clarification_only标记不能替代用途确认。'),
'6a5f1fd5000000002b0014fb':('new_short_lease','标题明确服务式公寓，缺正文不抹掉住宅语境；纯短租待问可保留，不搬入包水电事实。')}
assert set(notes)=={x['cid'] for x in cases}
issues={
'7696414781808689957':{'priority':'P1','action':'source_bound_plan_overlay_or_specific_hold','required_plan_changes':{'object_reference':'这个','object_reference_source':'own_comment_exact_span','object_granularity':'source_post_object_not_asserted_single_unit','family_semantics':'source_object_confirmation_then_price_location_private_contact_to_customer','preserve':['租金询问','位置询问','私信我的方向和渠道'],'forbid':['assume_Fangyu_owns_source_property','infer_sender_store_from_collection_source','global_change_of_all_contact_templates']},'reason':'Existing specific-object guard only matches 这套/这一套 and misses this observed 这个 reference.'},
'6acf7c9f0000000008031dc0':{'priority':'P0','action':'object_only_confirmation_overlay_or_restore_original_hold','required_plan_changes':{'family_semantics':'housing_purpose_confirmation_then_short_lease_feasibility_duration_question','clarification_only':True,'promotion_before_purpose_confirmation':False,'preserve':['原短租问题','住宅用途未决','contact unknown','send false'],'forbid':['clear_source_blocking_reason','assume_short_lease_means_housing','use_clarification_boolean_as_semantic_proof']},'reason':'New unbound short-lease branch returns before existing source-object warning guards.'}}
rows=[]
for c in cases:
 group,reason=notes[c['cid']];r={**c,'verdict':'change_plan_only' if c['cid'] in issues else 'pass_local_draft','semantic_interaction_group':group,'reason':reason,'human_confirmed':False,'fresh_holdout':False,'review_method':'independent_current_assistant_semantic_review_of_source_context_and_frozen_plan','usage':'unknown'}
 if c['cid'] in issues:r['required_patch']=issues[c['cid']]
 rows.append(r)
(O/'case-review.jsonl').write_text(''.join(json.dumps(x,ensure_ascii=False,separators=(',',':'))+'\n' for x in rows),encoding='utf-8')
groups={}
for r in rows:
 g=groups.setdefault(r['semantic_interaction_group'],{'cases':[],'verdicts':collections.Counter()});g['cases'].append(r['cid']);g['verdicts'][r['verdict']]+=1
coverage={'selection_counts':dict(collections.Counter(t for r in rows for t in r['selection'])),'selected_unique_cases':len(rows),'semantic_interactions':groups,'selected_final_exact_family_count':len({x['final_family'] for x in rows}),'final_exact_used_family_count':v['actual_used_after'],'old_C60_exact_family_coverage':'51/147; unchanged historical denominator','structural_contract_coverage':{'all_declared':366,'actual_used_after':268,'all_bound_rows':6694,'old_matrix_families':187,'old_matrix_members':6689,'new_bound_outside_matrix_but_checked':5},'not_covered_semantically':['all_147_literal_families_individually','all_268_final_used_families_individually','population_intent_accuracy','all_negation_AND_OR_multisubject_interactions','real_sender_identity_referral_inventory_facts','actual_platform_send_or_receipt'],'fresh_holdout':False,'sampling_is_not_accuracy_estimate':True}
put('semantic-coverage.json',coverage)
put('required-patch.json',{'frozen_contract_SHA':sha(R/'repair-contract.json'),'frozen_overlays_SHA':sha(R/'source-bound-plan-overlays.jsonl'),'preserve_frozen_bytes':True,'cases':[{'cid':cid,**x} for cid,x in issues.items()],'targeted_regression_requirement':['C42 explicit generic demonstrative plus location price private contact','new short lease plus explicit unknown housing purpose','same short-lease template with four clear residential contexts','existing this-property and type-reference confirmations remain intact'],'not_required':'rerun285_or147_fulltext_AI_or_historical_classification'})
ready=load(R/'READY.json');manifest=load(R/'manifest.json')
assert all(sha(R/n)==h for n,h in ready['final_files_sha256'].items())
assert all(sha(p)==h for p,h in manifest['source_SHA256'].items())
summary={**v,'semantic_review_complete':True,'verdict_counts':dict(collections.Counter(r['verdict'] for r in rows)),'known_problem_verdicts':dict(collections.Counter(r['verdict'] for r in rows if 'known_problem' in r['selection'])),'neighbor_verdicts':dict(collections.Counter(r['verdict'] for r in rows if 'neighbor_or_coverage' in r['selection'])),'newly_bound_short_lease_verdicts':dict(collections.Counter(r['verdict'] for r in rows if 'newly_bound_short_lease' in r['selection'])),'local_draft_version_release_verdict':'NOT_READY_TWO_SOURCE_BOUND_PLAN_FIXES_REQUIRED','platform_publish_or_send_authorized':False,'frozen_files_unchanged_after_review':True,'sources_unchanged_after_review':True,'new_API_calls':0,'platform_calls':0,'send_attempts':0,'source_writes':0,'pointer_writes':0,'usage':'unknown'}
put('validation.json',summary)
print(json.dumps(summary,ensure_ascii=False))
