"""Explicit current-assistant semantic review labels, not an automated classifier."""
import json,re,hashlib
from pathlib import Path
HERE=Path(__file__).resolve().parent
OUT=HERE.parents[1]/'outputs/方隅双平台文本业务/验收与逐批记录'
data=[json.loads(x) for x in (HERE/'holdout-200.jsonl').read_text(encoding='utf8').splitlines()]
S=[1,7,11,14,18,20,21,23,24,26,28,31,32,33,34,35,36,37,38,40,41,43,46,47,48,50,56,57,58,59,60,61,62,63,64,65,72,74,78,82,83,86,91,92,93,95,104,105,106,112,116,117,118,120,121,123,124,125,126,128,129,131,132,133,136,140,142,143,146,147,148,153,157,158,159,160,161,166,168,169,171,172,173,175,176,177,178,183,184,185,187,188,189,190,191,193,196,197,198,199,200]
Q=[15,17,22,25,27,69,84,87,88,100,110,115,127,179,192]
U=[3,4,5,8,10,12,13,16,29,44,53,54,66,85,90,97,109,134,137,139,141,144,163,167,182]
N=[2,6,9,19,30,39,42,45,49,51,52,55,67,68,70,71,73,75,76,77,79,80,81,89,94,96,98,99,101,102,103,107,108,111,113,114,119,122,130,135,138,145,149,150,151,152,154,155,156,162,164,165,170,174,180,181,186,194,195]
S.remove(168);S.remove(153);N.append(153);Q.remove(115);U.append(115);M=[168]
groups=[S,Q,U,N,M];assert len(set(sum(groups,[])))==200 and len(sum(groups,[]))==200
topics={15:['看房联系'],17:['入住与租期','看房联系'],22:['位置通勤'],25:['房源状态'],27:['价格预算'],69:['价格预算'],84:['价格预算'],87:[],88:['位置通勤','价格预算'],100:['看房联系'],110:['户型面积与居住方式'],115:['价格预算'],127:['价格预算'],179:['价格预算','位置通勤','户型面积与居住方式'],192:['看房联系']}
ambiguous={3:['价格预算'],4:['价格预算'],8:['看房联系'],10:['位置通勤','价格预算'],12:['看房联系'],13:['位置通勤'],16:['价格预算','位置通勤','户型面积与居住方式'],29:['价格预算','位置通勤','户型面积与居住方式'],54:['看房联系'],66:['户型面积与居住方式'],85:['价格预算'],90:['看房联系'],97:['价格预算','户型面积与居住方式'],109:['价格预算','位置通勤'],134:['位置通勤'],137:['位置通勤'],139:['位置通勤','价格预算','户型面积与居住方式'],144:['价格预算'],163:['价格预算'],167:['价格预算','位置通勤']}
notes={15:'本人明确仍在看房；未明确地区或可接受房型，不能套具体门店房源。',17:'明确长租、联系看房；标题可解释房源但当前有效性仍待核。',22:'上级为个人转租报价，本人问位置；标题已租到不能移给评论者。',25:'标题指向具体出租房，本人问是否仍在；原帖正文未取得，当前房态未知。',27:'标题明确出租降价，本人问价；问价不等于本人预算。',69:'标题明确急转租，本人询价；不得回应为本店该房价格。',84:'针对降价房源询价，不能套本店更便宜。',87:'本人表示先找着；上级提示太早，时间未定，先保留待核。',88:'针对明确转租房问小区及价格，两个需求同时保留。',100:'索取具体房源联系渠道，按已定边界不因问微信自动超高。',110:'本人明确拒绝合租，不能把合租词命中当接受合租。',115:'本人问这套价格；父文只有道路，具体房源对象仍待核，价格只记待核线索。',127:'出租标题下问价格，未自报预算；当时时点询盘与今日有效性不同。',179:'本人纠结用距离换面积，明确比较价格/距离/面积；不是确认已经搬家。',192:'针对古北方隅问看房方式；泛问不等于已预约或具体时间。',101:'是假设没有买房时的搬家想法，不能按当前求租推进。',108:'品牌投诉及对他人建议，未发现评论者本人新求租需求；无关健康叙述不进入画像。',144:'标题为喜爱某个家，未能确认可租房源；单独多少需上下文。',163:'父文为已选公寓的经历，问对方租价不等于本人当前找房。',168:'本人一边转租旧房，一边说工作地点变迁、十一月初要换房；保留供给和本人换租线索，是否仍需求租、目标地区均待核，不从旧房虹口补成求租地区。',97:'表达差点预订及价格比较，当前是否继续找房未明。',141:'已回可能是供给方应答，需核对说话者与房源关系。',182:'表达租房能力变化，但没有明确新求租行动，不自动判当前高意向。'}
ambiguous[115]=['价格预算'];ambiguous[168]=['入住与租期']
notes[153]='本人讨论自己发布的帖子不可见；不能由发过贴就确认当前有房源或本人求租。'
notes[85]='多少缺少具体对象，标题可能涉及健身房转租而非住宅；须先确认住宅租赁语境，不能直接套公寓母句。'
map12={'价格预算':'价格预算','位置区域':'位置通勤','通勤交通':'位置通勤','房型面积':'户型面积与居住方式','租住方式':'户型面积与居住方式','宠物':'宠物','楼层电梯':'楼层电梯','租期':'入住与租期','入住看房':'看房联系','费用合同':'费用合同','居住设施':'房内设施'}
result=[]
for i,r in enumerate(data,1):
    role='供给或房源推荐' if i in S else '本人求租或具体询盘线索' if i in Q else '身份或需求待核' if i in U else '供给与本人换租线索并存' if i in M else '讨论经历假设或无关'
    expected=topics.get(i,[]) if i in Q else []
    word=sorted(set(map12[t] for t in r['source_topics'] if t in map12))
    result.append({**r,'semantic_review':{'reviewer':'当前GPT-6.1 Sol语义复核','human_approved':False,
    'role':role,'own_need_topics':expected,'possible_topics_pending':ambiguous.get(i,[]),
    'source_word_topics_mapped':word,'word_topics_are_not_demand':i not in Q,
    'historical_signal_not_current_confirmation':True,'target_region':'未完成本人地区事实核验','template_review_state':'待本人校准且需账号/门店事实',
    'direct_reply_authorized':False,'reason':notes.get(i,'原文为房源提供或推荐，不能把其中条件转成评论者的求租需求。' if i in S else '本人需求、对象或说话者不清，需结合已有上下文核对。' if i in U else '原文为讨论、经历或无关内容，没有据此确认当前求租。')}})
OUT.mkdir(parents=True,exist_ok=True)
(HERE/'holdout-200-reviewed.jsonl').write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in result),encoding='utf8')
def clean(s):
    s=re.sub(r'https?://\S+','[链接已省略]',s or '')
    s=re.sub(r'(?<!\d)1[3-9]\d{9}(?!\d)','[联系方式已省略]',s)
    s=re.sub(r'@[\w\u4e00-\u9fff.]+','[提及账号已省略]',s)
    return s
lines=['200条真实评论的留出核对','',
'这是100条按固定顺序抽取的常规评论和100条定向难例。每位客户和相同原文只取一次，排除了此前测试与定向抽查材料；不是平台总体随机样本，也不是用户认可金标准。',
'以下由当前模型逐条作语义复核。当前词面候选与本人需求分开；新文本规则未接入执行器，不能声称已测得新分类器准确率、自动母句覆盖率或速度收益。',
'所有条目仅供文本核对，均未授权发送，需求时效、本人地区及账号/门店事实仍需分别确认。','']
for r in result:
    s=r['semantic_review'];t=clean(r['text'])
    if '肿瘤' in t:t='[品牌投诉及对他人的搬家建议；无关健康描述已省略]'
    lines+=['────────────────','客户原评论：'+t,'可得帖子标题：'+clean(r['post_title'] or '未提供'),
    '可得直接上级：'+clean(r['parent_text'] or '未提供或不适用'),'本次需求状态：'+s['role'],
    '本人需求主题：'+('、'.join(s['own_need_topics']) or '未确认本人具体需求'),
    '待核主题线索：'+('、'.join(s['possible_topics_pending']) or '无额外明确线索'),
    '原词面候选：'+('、'.join(s['source_word_topics_mapped']) or '未命中'),
    '核对理由：'+s['reason'],'母评论承接：先满足身份、门店事实、地区时间与本人语气认可条件，再选句；本次不发送。','']
(OUT/'200条真实评论核对.txt').write_text('\n'.join(lines)+'\n',encoding='utf8')
summary={'sample_count':200,'ordinary':100,'directed':100,'reviewer':'current_gpt-6.1-sol','user_gold_standard':False,
    'roles':{'供给或推荐':len(S),'本人求租或询盘线索':len(Q),'待核':len(U),'供给与换租并存':len(M),'讨论经历或无关':len(N)},
    'v2_word_hit_nonseeker':sum(bool(r['semantic_review']['source_word_topics_mapped']) and r['semantic_review']['word_topics_are_not_demand'] for r in result),
    'new_classifier_accuracy_measured':False,'mother_user_approval_count':0,'sent':0}
(HERE/'holdout-review-summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps(summary,ensure_ascii=False))
