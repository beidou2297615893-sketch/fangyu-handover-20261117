import json,sqlite3,sys,collections,hashlib
from pathlib import Path
from datetime import datetime,timezone
import recency
HERE=Path(__file__).resolve().parent;WORK=HERE.parent;ROOT=WORK.parent.parent
sys.path.insert(0,str(WORK/'business-fit'))
import business_fit
SOURCE=WORK/'reply-handoff-current/xiaohongshu-replies.jsonl'
EVIDENCE=ROOT/'work/xhs-source-priority/source-evidence.jsonl'
def load(p):return json.loads(p.read_text(encoding='utf-8-sig'))
rows=[json.loads(l) for l in SOURCE.read_text(encoding='utf-8-sig').splitlines()]
classified=[json.loads(l) for l in (WORK/'xhs-increment-846/classified-3601.jsonl').read_text(encoding='utf-8-sig').splitlines()];by={r['comment_id']:r for r in classified}
source_posts=collections.defaultdict(list)
for path in [WORK/'delivery-v2/source-input.jsonl',WORK/'xhs-increment-846/input.jsonl']:
 for line in path.read_text(encoding='utf-8-sig').splitlines():
  source=json.loads(line);source_posts[source['comment_id']].append(source)
handoff_text={r['comment_id']:r['comment_text'] for r in rows}
recovered_text=0
for r in classified:
 text=handoff_text.get(r['comment_id'])
 if not text:
  for quote in (r.get('classification') or {}).get('evidence',[]):
   if isinstance(quote,str) and hashlib.sha256(quote.encode()).hexdigest()==r.get('comment_text_sha256'):
    text=quote;recovered_text+=1;break
 if text:r['comment_text']=text
 matches=[source for source in source_posts[r['comment_id']]
          if source.get('customer_uid')==r.get('customer_uid') and source.get('note_id')==r.get('note_id')
          and hashlib.sha256((source.get('comment_text') or '').encode()).hexdigest()==r.get('comment_text_sha256')]
 bodies={'\n'.join(str(source.get(key) or '') for key in ('post_title','post_text')) for source in matches}
 if len(bodies)==1:r['post_body']=next(iter(bodies))
all_pool=[dict(r,commercial_fit=business_fit.screen(r)) for r in classified]
all_path=HERE/'xiaohongshu-all-pool-business-fit.jsonl'
all_path.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in all_pool),encoding='utf-8')
evidence={}
if EVIDENCE.exists():
 for line in EVIDENCE.read_text(encoding='utf-8-sig').splitlines():
  e=json.loads(line)
  if e.get('verified') is True and e.get('evidence') and e.get('basis')!='nickname_only' and e.get('source_identity') in ['peer','non_peer']:evidence[e['note_id']]=e
c=sqlite3.connect((ROOT/'work/shared-acquisition-ledger/shared.sqlite3').resolve().as_uri()+'?mode=ro',uri=True);c.row_factory=sqlite3.Row
leads=[dict(r) for r in c.execute("select * from leads where platform='xiaohongshu'")];lby={r['comment']:r for r in leads}
aliases={r['alias']:r['canonical'] for r in c.execute("select * from identity_aliases where platform='xiaohongshu' and verified=1")}
def canon(x):
 seen=set()
 while x in aliases and x not in seen:seen.add(x);x=aliases[x]
 return x
blocked={canon(r['customer']) for r in leads if r['status']!='unverified'}
blocked.update(canon(r['customer']) for r in c.execute("select * from reservations where platform='xiaohongshu' and status not in ('not_sent','released')"))
queue=[];excluded=0;commercial_excluded=[]
for r in rows:
 old=by.get(r['comment_id'],{});e=evidence.get(old.get('note_id'));identity=e['source_identity'] if e else 'unknown'
 merged=dict(old,**r)
 # Handoff has topic classification; original source has customer role/state.
 source_class=old.get('classification') or {}
 merged['role']=source_class.get('role') or (r.get('classification') or {}).get('original_role') or 'unknown'
 merged['current_need_confirmed']=old.get('current_need_confirmed') or source_class.get('current_need_confirmed',False)
 for field in ('demand_state','source_error','source_version_conflict'):
  if old.get(field) is not None:merged[field]=old[field]
 merged['source_classification']=source_class
 r=business_fit.apply(merged)
 if not r['commercial_fit']['eligible_candidate']:commercial_excluded.append(r);continue
 if r['comment_id'] not in lby or canon(lby[r['comment_id']]['customer']) in blocked or r.get('contact_boundaries') or r.get('needs_currentness_review'):excluded+=1;continue
 r['source_priority']={'identity':identity,'evidence':e,'nickname_inference':False,'commenter_identity_unchanged':True}
 r['published_at']=old.get('comment_published_at') or r.get('original_comment_date')
 r['source_note_id']=old.get('note_id');queue.append(r)
# Known peer posts move back; retain recency-first ranking within source groups.
rank={'non_peer':0,'unknown':1,'peer':2}
queue.sort(key=recency.priority_key)
p=HERE/'xiaohongshu-pending-by-source-and-recency.jsonl';p.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in queue),encoding='utf-8')
report={'updated_at':datetime.now(timezone.utc).isoformat(),'source_comments':len(rows),'pending_comments':len(queue),'excluded_by_ledger_or_existing_constraints':excluded,'source_identity_counts':dict(collections.Counter(r['source_priority']['identity'] for r in queue)),'verified_source_evidence_records':len(evidence),'missing_evidence_does_not_mean_non_peer':True,'incoming_replies':'已回复我们的客户走独立优先跟进队列；本文件只含首次触达候选，不把已联系客户再入首触达','file':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'automatic_send_authorized':False,'live_sender_integration_verified':False}
held=HERE/'xiaohongshu-business-fit-held.jsonl';held.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in commercial_excluded),encoding='utf-8')
report['commercial_fit']={'version':business_fit.VERSION,'all_pool_records':len(all_pool),'all_pool_counts':dict(collections.Counter(r['commercial_fit']['commercial_fit'] for r in all_pool)),'all_pool_file':str(all_path),'all_pool_sha256':hashlib.sha256(all_path.read_bytes()).hexdigest(),'held_from_reply_candidates':len(commercial_excluded),'held_file':str(held),'priority_pending_count':sum(r['commercial_priority'] for r in queue),'generic_pending_count':sum(not r['commercial_priority'] for r in queue),'code_sha256':hashlib.sha256((WORK/'business-fit/business_fit.py').read_bytes()).hexdigest(),'historical_intent_preserved':True}
report['commercial_fit'].update(original_text_missing=sum(not r.get('comment_text') for r in all_pool),original_text_recovered_by_exact_sha256=recovered_text)
(HERE/'xiaohongshu-source-priority-report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(report,ensure_ascii=False))
