"""Scheduled local worker host. Never logs in, collects, or sends."""
import msvcrt
from pathlib import Path
import subprocess
import sys

HERE=Path(__file__).resolve().parent
WORKER=HERE.parent/'douyin-semantic-repair-v5/watch_increment.py'
lock_path=WORKER.with_name('watch.lock')
with lock_path.open('a+b') as handle:
    handle.seek(0)
    if not handle.read(1):handle.write(b'0');handle.flush()
    handle.seek(0)
    try:msvcrt.locking(handle.fileno(),msvcrt.LK_NBLCK,1)
    except OSError:sys.exit(0)
    handle.seek(0);msvcrt.locking(handle.fileno(),msvcrt.LK_UNLCK,1)
with (HERE/'scheduled-worker.log').open('a',encoding='utf-8') as log:
    result=subprocess.run([sys.executable,'-u',str(WORKER)],cwd=HERE.parents[2],stdout=log,stderr=log)
sys.exit(result.returncode)
