import sys,json,pathlib,hashlib,collections,re,datetime,importlib.util,copy
sys.dont_write_bytecode=True
W=pathlib.Path('work/fangyu-text-business-20261029').resolve(); O=W/'pool-mother-review/legacy-short-preview'; P=W/'pool-mother-review/legacy-local-planning'; B=W/'douyin-registered-v2/increments/f98cc21138910fb9'
def sha(p):
 h=hashlib.sha256()
 with pathlib.Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''): h.update(b)
 return h.hexdigest()
def objsha(o): return hashlib.sha256(json.dumps(o,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode('utf8')).hexdigest()
def load(p):return json.loads(pathlib.Path(p).read_text(encoding='utf8'))
def jl(p):
 with pathlib.Path(p).open(encoding='utf8') as f:
  for l in f:
   if l.strip():yield json.loads(l)
def put(p,x):pathlib.Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
def putjl(p,rs):
 with pathlib.Path(p).open('w',encoding='utf8',newline='\n') as f:
  for x in rs:f.write(json.dumps(x,ensure_ascii=False,separators=(',',':'))+'\n')
manifest=load(P/'plan-source-manifest.json'); validation=load(P/'validation.json'); current=load(W/'region-brand-routing/current.json')
protected=dict(manifest['sources']); protected[manifest['additional_registered_text_verification']['path']]=manifest['additional_registered_text_verification']['sha256']
for n in ['local-proposed-plans.jsonl','representative-review.jsonl']:
 protected[str((P/n).resolve())]=validation['artifacts_sha256'][n]
for n in ['plan-source-manifest.json','validation.json','report.md']:
 protected[str((P/n).resolve())]=sha(P/n)
pre={p:sha(p) for p in protected}; mismatches={p:{'expected':protected[p],'actual':h} for p,h in pre.items() if h!=protected[p]}
if mismatches:raise RuntimeError('input hash mismatch '+json.dumps(mismatches,ensure_ascii=False))
assert pre[str((W/'region-brand-routing/current.json').resolve())]==manifest['current_pointer_sha256']
spec=importlib.util.spec_from_file_location('short_renderer',B/'batch_short_mothers.py'); renderer=importlib.util.module_from_spec(spec);spec.loader.exec_module(renderer);contract=load(B/'local-mother-contract.json')
plans=list(jl(P/'local-proposed-plans.jsonl')); bound=[p for p in plans if p['family']]; assert len(plans)==12963 and len(bound)==4419
rep=list(jl(P/'representative-review.jsonl')); repkeys={(r['platform'],str(r['cid']),str(r['uid'])) for r in rep}; assert len(rep)==66 and len(repkeys)==66
bykey={(p['platform'],str(p['cid']),str(p['uid'])):p for p in bound}; assert len(bykey)==4419
sources={}; allrows=[]
for platform,path in current['results'].items():
 for r in jl(path):
  k=(platform,str(r['comment_id']),str(r['customer_uid']))
  if k in bykey:
   if k in sources: raise ValueError('duplicate source key '+str(k))
   sources[k]=r
  allrows.append((k,r))
assert set(sources)==set(bykey)
rows=[]
for p in bound:
 k=(p['platform'],str(p['cid']),str(p['uid'])); r=sources[k]; s=r.get('source_record') or {}; text=r['comment_text']; errors=[]
 if hashlib.sha256(text.encode('utf8')).hexdigest()!=p['sourceSHA']:errors.append('source_comment_sha_mismatch')
 if objsha(s)!=p['original_classification_sha256']:errors.append('source_record_fingerprint_mismatch')
 if pre[str(pathlib.Path(current['results'][p['platform']]).resolve())]!=p['source_file_sha256']:errors.append('source_file_sha_mismatch')
 policy=p.get('contact_policy_original'); src_policy=r.get('contact_policy'); plan_policy=(r.get('reply_plan') or {}).get('contact_policy')
 # Only an explicit recorded policy is used; null/empty is unknown, never allow.
 effective=policy if policy else 'unknown'
 if src_policy and plan_policy and src_policy!=plan_policy: effective='unknown';errors.append('conflicting_original_contact_policies')
 if src_policy and policy and src_policy!=policy:effective='unknown';errors.append('plan_source_contact_policy_mismatch')
 if r.get('contact_boundaries'):effective='unknown';errors.append('original_contact_boundaries_require_manual_review')
 conflict=bool(r.get('source_version_conflict') or s.get('source_version_conflict') or (s.get('context_flags') or {}).get('source_conflict'))
 base={'role':r.get('role'),'demand_state':r.get('demand_state'),'interest_at_comment':r.get('interest_at_comment'),'source_version_conflict':conflict,'reply_plan':{'local_mother':{'family':p['family'],'fill':p['fill'],'evidence':p['evidence']},'tone':(r.get('reply_plan') or {}).get('tone') or r.get('effective_tone'),'contact_policy':effective}}
 result=None
 try:result=renderer.render_plan(base,text,contract)
 except Exception as e:errors.append('renderer_'+type(e).__name__+': '+str(e))
 # A source-integrity or contact conflict is a mandatory hold even if renderer returned text.
 if errors and result and result.get('text'):
  result['text']=None;result['status']='held_by_independent_source_or_boundary_check'
 selection='selected' if r.get('mother_reply_text') else 'alternative' if r.get('alternative_mother_reply_text') else 'held'
 if selection!=p['selection']:errors.append('original_selection_mismatch: planned='+str(p['selection'])+', source='+selection)
 if errors and result and result.get('text'):
  result['text']=None;result['status']='held_by_independent_source_or_boundary_check'
 rows.append({'platform':k[0],'cid':k[1],'uid':k[2],'source_comment_sha256':p['sourceSHA'],'stored_comment_sha256':p.get('stored_comment_sha256'),'source_container_sha256':p['source_file_sha256'],'source_binding':p['source_binding'],'source_verification':p.get('source_verification'),'comment':text,'original_selection':selection,'planned_original_selection':p['selection'],'original_mother_reply_text':r.get('mother_reply_text'),'original_alternative_mother_reply_text':r.get('alternative_mother_reply_text'),'original_reply_status':r.get('reply_status'),'original_reply':r.get('original_reply'),'source_record':s,'original_classification_sha256':p['original_classification_sha256'],'original_role':r.get('role'),'original_demand_state':r.get('demand_state'),'original_interest':r.get('interest_at_comment'),'original_contact_policy':src_policy,'original_reply_plan_contact_policy':plan_policy,'planned_original_contact_policy':policy,'effective_renderer_contact_policy':effective,'original_contact_boundaries':r.get('contact_boundaries'),'original_delivery_holds':p.get('delivery_holds'),'source_version_conflict':conflict,'local_plan':{'family':p['family'],'fill':p['fill'],'evidence':p['evidence'],'literal_evidence':p['literal_evidence'],'covered_existing_pools':p.get('covered_existing_pools'),'source_field_evidence':p['source_field_evidence']},'rendered':result,'validation_errors':errors,'send_authorized':False,'can_send_now':False,'human_confirmed':False})
putjl(O/'rendered-preview.jsonl',rows)
# Candidates with no returned text remain held, including all missing-contact records.
usable=[x for x in rows if x['rendered'] and x['rendered']['status']=='rendered_for_local_human_review' and x['rendered']['text'] and not x['validation_errors'] and (x['platform'],x['cid'],x['uid']) not in repkeys]
def features(x):
 p=x['local_plan']; t=x['comment']; topics=p['source_field_evidence'].get('topics') or []; fs=['family:'+p['family']]
 if len(topics)>=2:fs.append('multi_pool')
 if re.search(r'不|别|不要|不能|拒绝|无|没',t):fs.append('negation_marker')
 if re.search(r'水电|燃气|费用|押金|押付|包|含',t):fs.append('fee_scope_marker')
 if any(q.get('relation')=='work' for q in p['source_field_evidence'].get('target_regions') or []):fs.append('workplace_existing_label')
 if re.search(r'我|我们|本人|咱',t):fs.append('first_person_marker')
 return fs
# Prioritize rare families and rare edge features, then deterministic SHA-ordered round robin.
for x in usable:x['_features']=features(x)
avail=collections.Counter(f for x in usable for f in x['_features']); order=sorted(avail,key=lambda f:(avail[f],f))
def sortkey(x):return hashlib.sha256((x['platform']+'|'+x['cid']+'|'+x['uid']).encode()).hexdigest()
def select(candidates,n):
 buckets={f:sorted((x for x in candidates if f in x['_features']),key=sortkey) for f in order}; chosen=[];seen=set(); idx={f:0 for f in order}
 while len(chosen)<n:
  added=False
  for f in order:
   b=buckets[f];i=idx[f]
   while i<len(b) and (b[i]['platform'],b[i]['cid'],b[i]['uid']) in seen:i+=1
   idx[f]=i+1
   if i<len(b):
    x=b[i];k=(x['platform'],x['cid'],x['uid']);seen.add(k);chosen.append(x);added=True
    if len(chosen)>=n:break
  if not added:break
 return chosen
# Honor platform target where possible, backfill shortfall with other platform to maximize review coverage.
dy=[x for x in usable if x['platform']=='douyin']; xhs=[x for x in usable if x['platform']=='xiaohongshu']; chosen=select(dy,160)+select(xhs,40); taken={(x['platform'],x['cid'],x['uid']) for x in chosen};chosen+=select([x for x in usable if (x['platform'],x['cid'],x['uid']) not in taken],200-len(chosen));assert len({(x['platform'],x['cid'],x['uid']) for x in chosen})==len(chosen)<=200
contexts={}; qa=[]
def context_for(x):
 r=sources[(x['platform'],x['cid'],x['uid'])];s=r.get('source_record') or {};raw=r.get('original_raw_record') or {};pid=str(s.get('video_id') or s.get('note_id') or r.get('video_id') or r.get('note_id') or 'unknown:'+x['cid']);key=x['platform']+':'+pid
 context={'platform':x['platform'],'post_id':pid,'post_body':s.get('post_body') or raw.get('post_text') or None,'post_title':s.get('post_title') or raw.get('post_title') or None,'post_author_same_as_commenter':s.get('post_author_same_as_commenter'),'source_missing_context':raw.get('missing_context'),'source':'existing local source; not treated as customer demands'}
 if key in contexts and contexts[key]!=context:
  key=key+':comment:'+x['cid']
 contexts[key]=context
 return key,s.get('direct_parent_text') or raw.get('parent_text') or None
for x in chosen:
 key,parent=context_for(x);r=sources[(x['platform'],x['cid'],x['uid'])];s=r.get('source_record') or {};cls=s.get('classification') if isinstance(s.get('classification'),dict) else s
 missing=[]
 for z in [r.get('original_reply_missing_facts'),(r.get('reply_plan') or {}).get('missing_facts'),s.get('reply_missing_facts'),(s.get('reply_plan') or {}).get('missing_facts')]:
  for item in z or []:
   if item not in missing:missing.append(item)
 qa.append({'platform':x['platform'],'cid':x['cid'],'uid':x['uid'],'source_comment_sha256':x['source_comment_sha256'],'source_container_sha256':x['source_container_sha256'],'comment':x['comment'],'context_key':key,'direct_parent_text':parent,'original_classification':{'role':x['original_role'],'state':x['original_demand_state'],'interest':x['original_interest'],'topics':cls.get('topic_evidence',cls.get('actual_pools',cls.get('topics'))),'target_regions':r.get('target_regions'),'time_mentions':r.get('time_mentions'),'other_constraints':cls.get('other_constraints'),'contact_policy':x['original_contact_policy'],'reply_plan_contact_policy':x['original_reply_plan_contact_policy'],'contact_boundaries':x['original_contact_boundaries']},'original_selection':x['original_selection'],'plan':x['local_plan'],'render_status':x['rendered']['status'],'proposed_reply':x['rendered']['text'],'fact_gaps_from_all_existing_reply_fields':missing,'existing_source_review_reasons':r.get('review_reasons'),'sample_features':x['_features'],'send_authorized':False,'human_confirmed':False})
putjl(O/'qa-holdout-200.jsonl',qa);put(O/'qa-shared-contexts.json',contexts)
# Actual boundary controls selected separately from full existing sidecars; no generated reply.
def negtypes(k,r):
 pol=r.get('contact_policy') or (r.get('reply_plan') or {}).get('contact_policy'); types=[]
 if r.get('role')=='supply':types.append('supply')
 if r.get('demand_state') not in (None,'active_at_comment','unknown'):types.append('non_active_state:'+str(r.get('demand_state')))
 if pol=='no_contact':types.append('explicit_no_contact')
 if not pol or pol=='unknown':types.append('contact_unknown_or_missing')
 return types
pool=[]
for k,r in allrows:
 if k in repkeys or k in {(x['platform'],x['cid'],x['uid']) for x in chosen}:continue
 types=negtypes(k,r)
 if types:pool.append((k,r,types))
negative=[]; seen=set(); categories=sorted({t for _,_,ts in pool for t in ts},key=lambda x:(x=='contact_unknown_or_missing',x))
for cat in categories:
 matches=sorted((z for z in pool if cat in z[2]),key=lambda z:hashlib.sha256('|'.join(z[0]).encode()).hexdigest())
 for k,r,types in matches[:8]:
  if k in seen or len(negative)>=30:continue
  seen.add(k);negative.append({'platform':k[0],'cid':k[1],'uid':k[2],'source_comment_sha256':hashlib.sha256((r.get('comment_text') or '').encode()).hexdigest(),'comment':r.get('comment_text'),'original_role':r.get('role'),'original_demand_state':r.get('demand_state'),'original_interest':r.get('interest_at_comment'),'original_contact_policy':r.get('contact_policy'),'original_reply_plan':r.get('reply_plan'),'original_contact_boundaries':r.get('contact_boundaries'),'boundary_types':types,'expected':'不应新生成推广稿','note':'保留原标签及原稿；此包不生成新回复','send_authorized':False})
putjl(O/'qa-negative-boundaries.jsonl',negative)
post={p:sha(p) for p in protected}; changed={p:{'before':pre[p],'after':post[p]} for p in pre if post[p]!=pre[p]};statuses=collections.Counter(x['rendered']['status'] if x['rendered'] else 'renderer_exception' for x in rows);errors=collections.Counter(e for x in rows for e in x['validation_errors']);qa_features=collections.Counter(f for x in qa for f in x['sample_features']); negcounts=collections.Counter(t for x in negative for t in x['boundary_types']); actual=collections.Counter(x['platform'] for x in qa)
assert all(x['rendered'] is None or x['rendered']['status']!='held_by_original_role_state_interest_contact_or_source' or x['rendered']['text'] is None for x in rows)
assert all(x['rendered'] is None or x['effective_renderer_contact_policy']!='unknown' or x['rendered']['text'] is None for x in rows)
assert not ({(x['platform'],x['cid'],x['uid']) for x in qa}&repkeys)
assert len(qa)==len(set((x['platform'],x['cid'],x['uid']) for x in qa))
fixed={'created_at':datetime.datetime.now().astimezone().isoformat(),'input_manifest':str((P/'plan-source-manifest.json').resolve()),'input_sha256_before':pre,'input_sha256_after':post,'input_expected_sha256':protected,'input_hash_changed':changed,'contract_sha256':sha(B/'local-mother-contract.json'),'renderer_sha256':sha(B/'batch_short_mothers.py'),'planning_source_manifest_sha256':sha(P/'plan-source-manifest.json'),'preview_scope':'only 4419 already-bound family plans; no classification rerun','platform_calls':0,'model_api_calls':0,'gpu_used':False,'source_writes':0,'send_attempts':0,'pointer_updates':0}
put(O/'manifest.json',fixed)
v={'counts':{'planned_bound':len(bound),'output_rows':len(rows),'render_status':dict(statuses),'errors':dict(errors),'eligible_before_excluding_representative':sum(bool(x['rendered'] and x['rendered'].get('text')) for x in rows),'eligible_after_excluding_representative':len(usable),'independent_qa_count':len(qa),'qa_platforms':dict(actual),'requested_platform_targets':{'douyin':160,'xiaohongshu':40},'qa_backfill_note':'小红书联系策略缺失导致可用拟回复为0；额外40条抖音填足200，总计抖音200，不冒充小红书。','qa_features_overlapping':dict(qa_features),'negative_controls_count':len(negative),'negative_control_types_overlapping':dict(negcounts),'representative_review_count':len(rep)},'checks':{'every_bound_plan_has_output':len(rows)==4419,'bound_keys_unique':len(bykey)==4419,'qa_ids_unique':len(qa)==len(set((x['platform'],x['cid'],x['uid']) for x in qa)),'no_overlap_with_representative':True,'held_text_not_exposed_as_proposed_reply':True,'unknown_contact_not_allowed':True,'input_sha_unchanged':not changed,'parameter_validation_errors_retained':True},'limits':['技术和字面校验不是语义准确率','分层选择不是随机抽样，不能估计全库准确率','拟回复中的住户身份、优惠和具体房源等仍待事实核实','validated_plan_text仅为契约校验轨迹，held不得作为拟回复或选中稿','所有原选择、原稿与分类未写回或变更'],'source_outputs_sha256':{n:sha(O/n) for n in ['rendered-preview.jsonl','qa-holdout-200.jsonl','qa-shared-contexts.json','qa-negative-boundaries.jsonl','manifest.json']}}
put(O/'preview-validation.json',v)
report=['# 历史短母句本地预渲染与独立审核包','','本次只生成隔离预览，未更改原分类、原稿、消费文件或指针，未调用模型、平台或发送。','',f'已处理 {len(rows)} 条已绑定计划。渲染状态：'+ '；'.join(f'{k} {n}' for k,n in statuses.items())+'。',f'逐条错误：{sum(errors.values())} 项；'+('；'.join(f'{k}: {n}' for k,n in errors.items()) if errors else '无格式或输入校验错误。'),'渲染器的字面参数校验只检查填充值及原文字面证据；模板是否完整承接预算、条件、否定、时间、地区与多池含义，仍须独立审核，不能把技术通过当作准确率。','',f'独立母句适配包 {len(qa)} 条，抖音 {actual["douyin"]} 条、小红书 {actual["xiaohongshu"]} 条；均与原 66 条审阅不重叠，且只使用渲染器实际返回可审核正文的记录。全部小红书绑定计划联系策略缺失而暂缓；原定40条小红书配额无法满足，用额外40条抖音填足，不以暂缓行的 validated_plan_text 冒充可用回复。','按平台目标先选择，再按稀有家族、多个池、否定、费用、工作地及第一人称标记轮转，使用ID哈希固定排序；不足时从其余可用平台补足。标记只是筛选线索，不代表语义已核，非随机样本，不能估计整体准确率。','',f'另有独立阴性边界 {len(negative)} 条，分类计数（可重叠）：{dict(negcounts)}。期待“不应新生成推广稿”，不改原标签和原稿；若未列 no_contact 则未发现真实该类样本。','事实缺口沿用已有字段；原帖内容只作上下文，不把IP或来源门店当作客户要求。需要的住户身份、优惠资格、具体同房源事实仍待确认。','',f'来源文件结束复核：{"全部与开始一致" if not changed else "发现变化，详情见manifest"}。无模型、GPU、平台、发送或源数据写入。','独立模型审核及人工认可均未进行。']
(O/'report.md').write_text('\n'.join(report)+'\n',encoding='utf8')
print(json.dumps({'statuses':dict(statuses),'errors':dict(errors),'qa':dict(actual),'qa_total':len(qa),'negative':dict(negcounts),'changed':len(changed),'usable':len(usable),'features':dict(qa_features)},ensure_ascii=True))
