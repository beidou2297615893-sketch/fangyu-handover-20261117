import pathlib,json
O=pathlib.Path('work/fangyu-text-business-20261029/pool-mother-review/legacy-local-planning');W=O.parents[1];c=json.loads((W/'region-brand-routing/current.json').read_text(encoding='utf8'));es=json.loads((O/'more-selection.json').read_text(encoding='utf8')); ids={'7618738495263359781','7652766484415431461','7679715460049355562'}
for p,f in c['results'].items():
 for l in open(f,encoding='utf8'):
  r=json.loads(l)
  if r['comment_id'] in ids:
   es.append({'platform':p,'cid':r['comment_id'],'uid':r['customer_uid'],'tags':['region_entity_not_full_customer_sentence'],'text':r['comment_text'],'source_record':r['source_record']});print(json.dumps({'cid':r['comment_id'],'text':r['comment_text'],'region':r['target_regions']},ensure_ascii=False))
(O/'more-selection.json').write_text(json.dumps(es,ensure_ascii=False,indent=2),encoding='utf8')
