import json,pathlib,collections,sys
B=pathlib.Path(__file__).resolve().parent.parent
x=json.loads((B/'recall-audit/part-1'/('page-%02d.json'%int(sys.argv[1]))).read_text(encoding='utf-8'))
enc=lambda v:json.dumps(v,ensure_ascii=False,separators=(',',':'))
cs=[c for g in x['post_groups'] for c in g['comments']]
base={k:json.loads(collections.Counter(enc(c['first_semantic_judgment'][k]) for c in cs).most_common(1)[0][0]) for k in cs[0]['first_semantic_judgment']}
basec={k:json.loads(collections.Counter(enc(c[k]) for c in cs).most_common(1)[0][0]) for k in ('same_author','parent','reply_to','source_conflict')}
start=int(sys.argv[2]) if len(sys.argv)>2 else 0;end=int(sys.argv[3]) if len(sys.argv)>3 else len(cs)
out=[['BASE_J',base],['BASE_C',basec]]
for g in x['post_groups']:
 included=[c for c in g['comments'] if start<=cs.index(c)<end]
 if not included:continue
 out.append(['BODY',{k:v for k,v in g.items() if k!='comments'}])
 for c in included:
  j=c['first_semantic_judgment']
  out.append([c['key'],c['text'],c['published_at'],{k:c[k] for k in basec if c[k]!=basec[k]},{k:v for k,v in j.items() if v!=base[k]}])
counts=collections.Counter()
def scan(v):
 counts[enc(v)]+=1
 if isinstance(v,dict):
  for s in v.values():scan(s)
 elif isinstance(v,list):
  for s in v:scan(s)
for a in out:scan(a)
refs={};vals=[]
def pack(v):
 s=enc(v)
 if isinstance(v,(str,list,dict)) and len(s)>25 and counts[s]>1:
  if s in refs:return refs[s]
  vv=walk(v);r='@'+str(len(vals));refs[s]=r;vals.append([r,vv]);return r
 return walk(v)
def walk(v):
 if isinstance(v,dict):return {k:pack(a) for k,a in v.items()}
 if isinstance(v,list):return [pack(a) for a in v]
 return v
out=[pack(a) for a in out]
print('无损引用表，@编号按此表替换；BASE_J/BASE_C为逐条缺省，其余覆盖。')
for a in vals:print(enc(a))
for a in out:print(enc(a))
