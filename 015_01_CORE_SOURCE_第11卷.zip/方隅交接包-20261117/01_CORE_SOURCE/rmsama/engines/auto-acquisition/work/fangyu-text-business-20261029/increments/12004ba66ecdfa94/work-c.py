import json
from pathlib import Path
p=Path('work/fangyu-text-business-20261029/increments/12004ba66ecdfa94')
rows=[]
for n in (10,11,12,13): rows.extend(json.loads(s) for s in (p/f'shard-{n:02}.jsonl').read_text(encoding='utf-8').splitlines())
def ids(s): return {'I'+x for x in s.split()}
# Reviewed individually; these memberships are judgments, not keyword-based classifiers.
supply=ids('1083 1086 1088 1099 1107 1111 1116 1117 1118 1123 1128 1130 1131 1136 1137 1140 1142 1146 1149 1150 1152 1153 1154 1162 1163 1165 1166 1167 1170 1173 1174 1175 1177 1181 1182 1184 1185 1186 1187 1188 1189 1190 1191 1196 1197 1198 1199 1279 1307 1316 1335 1346 1356 1378 1379 1380 1382')
discussion=ids('1007 1008 1009 1010 1011 1013 1014 1018 1022 1023 1028 1032 1033 1035 1036 1037 1041 1046 1060 1063 1064 1067 1068 1077 1078 1143 1193 1200 1211 1230 1235 1277 1350 1358 1368')
unknown=ids('1031 1051 1158 1183 1054 1058 1066 1074 1114 1124 1127 1145 1151 1168 1192 1195 1220 1222 1232 1233 1283 1291 1308 1325 1334 1343 1345 1351 1355 1363 1364 1373 1376')
active=ids('1016 1050 1081 1119 1194 1239 1248 1267 1275 1278 1321 1323 1349 1362 1367 1371')
# Entire titles reviewed as offering an identifiable rental or transfer.
listing_titles={
'中山公园转租，着急离开上海，送半个月房租',
'上海3500民用水电整租两室一厅',
'古北｜转租神仙1房带露台🤗',
'普陀真人个人转租急🥹中介❌',
'个人转租古北路（2室）带阳台❗️因工作位置',
'古北个人转租（已搬走）宽敞2室🥹租期剩6个月',
'闵行小姐姐转租🌟一室一厅正在转租中‼️‼️',
'上海转租 静安小一室一厅3.3k（没删就还在）',
'静安转租（小姐姐工作调动）小一室一厅3.1k',
'🏡 上海静安寺｜55㎡一室一厅转租，无中介费',
'长寿路租房｜整租一室一厅4800带院子',
'自家房子出租✨无中介费'
}
topicsets={
'价格预算':ids('1014 1040 1002 1006 1015 1017 1021 1024 1025 1030 1034 1039 1047 1050 1052 1053 1056 1059 1065 1069 1070 1072 1073 1075 1082 1084 1085 1087 1089 1092 1093 1097 1098 1104 1108 1110 1112 1113 1119 1120 1121 1126 1129 1132 1133 1134 1138 1141 1144 1156 1157 1159 1160 1164 1169 1172 1178 1201 1202 1203 1206 1208 1209 1210 1213 1214 1216 1217 1218 1221 1225 1226 1228 1229 1231 1236 1237 1238 1244 1245 1246 1247 1251 1253 1257 1259 1261 1262 1264 1265 1271 1276 1280 1281 1282 1284 1285 1288 1289 1294 1296 1297 1298 1300 1301 1302 1303 1305 1306 1313 1315 1317 1318 1320 1322 1324 1326 1327 1328 1329 1330 1331 1332 1333 1336 1338 1339 1342 1347 1349 1354 1360 1361 1365 1366 1369 1370 1372 1375 1377'),
'位置通勤':ids('1001 1003 1004 1017 1020 1024 1026 1027 1029 1030 1034 1038 1045 1049 1057 1062 1073 1079 1085 1091 1096 1102 1103 1106 1108 1115 1129 1132 1133 1139 1141 1178 1179 1201 1202 1209 1210 1212 1215 1217 1223 1224 1225 1227 1228 1231 1234 1236 1237 1238 1240 1246 1249 1250 1254 1256 1259 1262 1265 1266 1267 1268 1269 1272 1273 1274 1275 1282 1284 1286 1287 1290 1295 1298 1299 1300 1303 1304 1310 1312 1313 1315 1318 1320 1326 1328 1329 1331 1333 1337 1341 1347 1352 1359 1360 1365 1369 1374'),
'户型面积与居住方式':ids('1016 1045 1119 1122 1194 1238 1270 1278 1328 1348 1349'),
'房内设施':ids('1353'),
'宠物':ids('1081 1300 1321'),
'楼层电梯':ids('1272'),
'入住与租期':ids('1050 1081 1242 1267 1305'),
'房源状态':ids('1012 1042 1043 1055 1090 1094 1095 1105 1109 1122 1125 1147 1155 1171 1204 1205 1219 1222 1232 1241 1243 1263 1278 1292 1293 1311 1314 1319 1323 1327 1337 1338 1344 1347 1357 1381'),
'费用合同':ids('1019 1071 1135 1258'),
'看房联系':ids('1103 1148 1239 1248 1260 1275 1362 1367 1371 1384')}
# The region names below come only from the author's own explicit words.
regions={'1181':[('大柏树','offered')],
'1349':[], '1083':[('四川北路','offered')], '1107':[('普陀区','offered')],
'1111':[('赤峰路曲阳路','offered')], '1116':[('临沂新村地铁站','offered')],
'1117':[('黄陂南路','offered')], '1118':[('呼兰路地铁','offered')],
'1123':[('虹口水电路灵新小区','offered')], '1128':[('古浪路地铁站对面小区','offered')],
'1131':[('普陀长征','offered')], '1136':[('长寿路地铁站','offered')], '1137':[('祁安路','offered')],
'1152':[('普陀','offered')], '1162':[('鹤沙航城','offered')], '1163':[('虹口足球场鲁迅公园','offered')],
'1166':[('飞虹路','offered')], '1170':[('西藏北路','offered')], '1173':[('殷高西路站附近','offered')],
'1174':[('四川北路1915号','offered')], '1175':[('邮电新村','offered')], '1182':[('四川北路','offered')],
'1183':[('杨浦','offered')], '1184':[('普陀区长寿路','offered')], '1185':[('润欣公寓','offered')],
'1186':[('国贸花园','offered')], '1190':[('瑞虹一期','offered')], '1196':[('东体育会路408弄','offered')],
'1199':[('和平花苑','offered')], '1307':[('静安寺','offered')], '1316':[('静安区','offered')],
'1335':[('天潼路地铁站','offered')], '1346':[('静安','offered')], '1356':[('北外滩','offered')],
'1378':[('北外滩','offered')], '1379':[('北外滩','offered')], '1382':[('海泰苑','offered')]}
# Key-specific interpretation notes, particularly under non-offer or ambiguous titles.
manual={
'I1007':('discussion','unknown','unrelated','讨论租金与收入，并未明确本人当前求租。',[]),
'I1010':('discussion','historical','unrelated','分享已购房经历，没有提出当前求租。',[]),
'I1011':('demand','ended','unrelated','本人已租到房，未表达新的求租需求。',[]),
'I1013':('discussion','historical','unrelated','回顾以往租房经历，不代表当前需求。',[]),
'I1014':('unknown','unknown','uncertain','在泛租房讨论中询问价格，不足以确认本人求租。',['缺少本人找房意图或具体房源背景。']),
'I1016':('demand','active_at_comment','high','询问有没有合适的两房，表达当时找房意向。',[]),
'I1018':('unknown','unknown','uncertain','在看房日记下询问某公寓评价，尚不能确认本人求租。',['询问目的与是否准备租住待核。']),
'I1019':('unknown','unknown','uncertain','询问杂费，现有看房日记不足以确认本人求租。',['所问公寓及本人意图需要核实。']),
'I1029':('unknown','unknown','uncertain','在攻略帖下询问小区与中介推荐，可能找房但没有明确本人求租。',['房源对象与找房目的待核。']),
'I1040':('unknown','unknown','uncertain','询问某预算能否满足博主条件，未确认是否本人求租。',['博主的具体条件未采集，不得继承。']),
'I1044':('demand','active_at_comment','unrelated','本人询问店铺或办公室购买，属于商业物业购买需求。',[]),
'I1045':('unknown','unknown','uncertain','询问三房和位置，标题为入住展示，未明确房源出租。',['出租还是售房、本人需求均需核实。']),
'I1048':('demand','active_at_comment','unrelated','本人表示看中具体小区，标题语境为看房购房。',['是否购房需以完整上下文核实。']),
'I1050':('demand','active_at_comment','high','在整租房源下询问短租和价格。',[]),
'I1061':('unknown','unknown','uncertain','看房日记下询问房间隔音，尚未确认是否本人正在找房。',['具体对象及本人找房目的待核。']),
'I1071':('unknown','unknown','uncertain','询问指定公寓水电性质，是否本人求租未明。',['看房日记非明确可租房源，意图待核。']),
'I1076':('demand','active_at_comment','unrelated','表示本人也在看房，结合标题语境为购房。',['未表达租房需求。']),
'I1079':('unknown','unknown','uncertain','请求推荐附近公寓，但未说明是否求租。',['地点为推荐范围，租住目的未确认。']),
'I1081':('demand','future','medium','本人表示也在找房，提及宠物要求和入住日期。',['仅有月日，年份需结合可信发表时间核实；不继承帖主其他条件。']),
'I1090':('unknown','unknown','uncertain','“还有那”所指不明确，现有标题不够确认具体房源状态。',['疑似询问是否还有房，但文字不完整且缺少明确出租上下文。']),
'I1100':('demand','ended','unrelated','明确表示已经找到，未见新的找房需求。',[]),
'I1124':('unknown','unknown','uncertain','仅有户型和视频标记，无法辨别供需。',['视频内容未采集，不能判断是否提供房源。']),
'I1127':('unknown','unknown','uncertain','在求租帖下描述位置与数字，疑似房源推荐。',['缺乏明确出租说明且视频未采集。']),
'I1151':('unknown','unknown','uncertain','提及搬家、主页和价格，可能为转租推荐，也可能另有找房需求。',['具体是供给还是另找房需核实，不能只因搬家就认定已结束。']),
'I1168':('unknown','unknown','uncertain','询问时间是否可行，具体事项和供需对象不明。',['缺少对应的时间与上下文。']),
'I1180':('unknown','unknown','uncertain','“已出”可能表示房源已转出，评论主体和对象未明确。',['需核实评论者是否为房源提供者及所指对象。']),
'I1192':('unknown','unknown','uncertain','在求租帖下回答“有啊”，供需对象未明确。',['需核实所说对象和本人是否提供房源。']),
'I1200':('discussion','unknown','unrelated','明确表示不租房，仅询问家具。',[]),
'I1207':('demand','active_at_comment','high','在转租房源下询问数量，表现当时兴趣。',['“几张”所指不明，可能是租金或其他数量，不归入具体主题。']),
'I1211':('discussion','unknown','uncertain','质疑价格真实性，不能确认本人求租。',['询问用途可能只是核验真实性。']),
'I1222':('unknown','unknown','uncertain','在房屋居住讨论帖下问是否还有，指代与需求不明。',['标题不是明确出租帖，缺少所问对象。']),
'I1230':('discussion','unknown','uncertain','询问真实性，尚未表达本人租房意向。',['核验对象和目的待核。']),
'I1232':('unknown','unknown','uncertain','在居住讨论帖下询问是否还在，指代不明。',['标题未明确出租房源。']),
'I1235':('discussion','unknown','uncertain','询问是否引流，评论未明确本人求租。',['需确认质疑对象和目的。']),
'I1239':('demand','active_at_comment','high','询问能否看房和是否中介。',['泛询看房，未提出具体预约时间。']),
'I1242':('demand','future','uncertain','提出十月入住需求，但标题未明确这套房是否可租。',['年份及房源出租状态待核。']),
'I1248':('demand','active_at_comment','high','在转租房源下询问方便看房。',['泛询看房，未提出具体预约时间。']),
'I1267':('demand','future','high','询问位置与短租，并提出十月初的使用时间。',['年份及具体起租日期需结合发表时间核实。']),
'I1275':('demand','active_at_comment','high','询问位置和是否可以看房。',['泛询看房，未提出具体预约时间。']),
'I1277':('discussion','unknown','uncertain','询问真实性，未明确本人求租。',['核验目的待核。']),
'I1291':('unknown','unknown','uncertain','仅询问对方在不在，无法确认具体目的。',['可能是联系发帖者，也可能询问房源状态。']),
'I1321':('demand','active_at_comment','high','询问出租方是否接受养猫租客。',[]),
'I1323':('demand','active_at_comment','high','询问房屋是否可以租。',['房源状态需由发布者确认。']),
'I1349':('demand','active_at_comment','high','本人询问预算以内的特定三房并请求联系。',[]),
'I1362':('demand','active_at_comment','high','询问能否看看房子。',['未明确线下看房或预约时间。']),
'I1367':('demand','active_at_comment','high','明确想看房。',['尚未约定具体看房时间。']),
'I1371':('demand','active_at_comment','high','询问是否可以看房。',['未提出具体预约时间。']),
'I1383':('demand','ended','unrelated','表示已经找到房源，未见新的求租需求。',[])
}
# Generic numeric expressions: do not assume price or area.
ambiguous=ids('1080 1161 1207 1255 1256 1340 1343 1357')
outputs=[]
for x in rows:
 k=x['review_key']; own=x['comment_text']; title=x.get('post_title',''); review=[]
 if k in manual: role,state,interest,reason,review=manual[k]; review=list(review)
 elif k in supply: role,state,interest,reason='supply','unknown','unrelated','评论在提供、转租或推荐房源，未明确表达本人另找房。'
 elif k in discussion: role,state,interest,reason='discussion','unknown','unrelated','评论讨论经历、观点或其他事项，未见本人当前求租。'
 elif k in unknown: role,state,interest,reason='unknown','unknown','uncertain','评论不能确认供需身份或具体意图。'; review=['内容或上下文不足以确定所指对象及供需关系。']
 elif k in active: role,state,interest,reason='demand','active_at_comment','high','本人询问房源或提出租住需求，记录为评论时意向。'
 elif title in listing_titles: role,state,interest,reason='demand','active_at_comment','high','在明确整租或转租房源下询问条件，记录为评论时兴趣。'
 else: role,state,interest,reason='unknown','unknown','uncertain','询问房屋信息，但现有标题不足以确认本人正在求租。'; review=['标题未明确当前可租房源，需核实询问目的及对象。']
 if k in unknown and k not in manual:
  details={
   'I1031':'仅说明可办理车位，房源提供者身份与房屋关系不明。',
   'I1051':'“太早”未说明时间或所指事项。',
   'I1054':'纯数字不能确认询问对象或需求。',
   'I1074':'仅表情，未表达可判读需求。',
   'I1145':'仅写“求”，未说明要求的具体内容。',
   'I1158':'仅有一室一厅描述，未说明是本人要求还是推荐房源。',
   'I1183':'只有金额、地点和视频标记；视频未采集且供需关系不明。',
   'I1195':'只请求回复，所问事项不明。',
   'I1233':'只写“咨询”，没有说明所咨询事项。',
   'I1283':'仅有视频标记，视频内容未采集。',
   'I1308':'仅列房型，未说明是本人要求还是提供的房源。',
   'I1334':'描述房型与价格感受，未说明是本人需求还是推荐。',
   'I1343':'仅写“多少”且缺少标题与上下文，所问对象和数量不明。',
   'I1345':'“多人”所指不明，无法确认是询问人数还是其他含义。',
   'I1351':'仅说询问，未说明问题或询问对象。',
   'I1355':'仅写房型，无法判断是本人要求还是提供房源。',
   'I1363':'只写地点，无法判断其与房源或本人需求的关系。',
   'I1364':'只写地点，无法判断其与房源或本人需求的关系。',
   'I1373':'只写“这个”，指代对象及目的不明。',
   'I1376':'仅描述景观，无法确认是提供房源还是讨论。'}
  review=[details.get(k,'仅有简短互动或表情，未说明房源对象或本人意图。')]
 topics=[]
 if role not in ('supply','discussion'):
  for pool,ks in topicsets.items():
   if k in ks and k not in ambiguous:
    polarity='require' if k in {'I1081','I1242','I1267','I1349'} else 'ask'
    topics.append({'pool':pool,'quote':own,'polarity':polarity})
 if k in ambiguous:
  if k=='I1256': topics=[{'pool':'位置通勤','quote':own,'polarity':'ask'}]
  review.append('数量所指未说明，价格、面积或其他含义待核，不归入具体数量主题。')
 if k=='I1081':
  topics=[{'pool':'入住与租期','quote':'10.15入住','polarity':'require'}]; review.append('不要求宠物友好不等于排斥宠物，宠物池不记录为拒绝。')
 if k=='I1040': topics.append({'pool':'位置通勤','quote':'稍微偏一点可以','polarity':'accept'})
 if k=='I1349': topics=[{'pool':'价格预算','quote':'2w 以内','polarity':'require'},{'pool':'户型面积与居住方式','quote':'横厅3 房','polarity':'require'},{'pool':'看房联系','quote':'可以联系我','polarity':'ask'}]
 if k=='I1252' or k=='I1309': review.append('车位或停车要求没有对应池，暂不强行归类。')
 if k=='I1310': review.append('停车问题无对应池，位置主题单独记录。')
 if k=='I1238': review.append('公寓名是位置识别问题，未把标题设施视为本人要求。')
 if k in {'I1122','I1194'}: review.append('所指视频或示例房型具体特征未采集。')
 target=[]
 for frag,relation in regions.get(k[1:],[]):
  if frag in own: target.append({'text':frag,'quote':frag,'relation':relation})
 context=['own']+(['title'] if title and k not in {'I1010','I1011','I1013','I1200'} else [])
 outputs.append({'review_key':k,'comment_id':x['comment_id'],'customer_uid':x['customer_uid'],'role':role,'demand_state':state,'interest':interest,'topics':topics,'target_regions':target,'evidence':[own] if own else [],'reason':reason,'context_used':context,'needs_review':review,'human_confirmed':False,'send_authorized':False,'store_assignment':None})
errors=[]
for x,y in zip(rows,outputs):
 for q in y['evidence']+[t['quote'] for t in y['topics']]+[t['quote'] for t in y['target_regions']]:
  if not q or q not in x['comment_text']: errors.append(y['review_key'])
keys=lambda a:[(z['review_key'],z['comment_id']) for z in a]
assert len(rows)==len(outputs) and len(set(keys(rows)))==len(rows) and set(keys(rows))==set(keys(outputs)) and not errors
assert not any(y['role']=='unknown' and y['interest']=='unrelated' for y in outputs)
(p/'reviewed-c.jsonl').write_text(''.join(json.dumps(y,ensure_ascii=False)+'\n' for y in outputs),encoding='utf-8')
from collections import Counter
report={'input_count':len(rows),'output_count':len(outputs),'id_pair_set_equal':set(keys(rows))==set(keys(outputs)),'unique_id_pairs':len(set(keys(outputs))),'evidence_verbatim_errors':errors,'role_counts':dict(Counter(y['role'] for y in outputs)),'interest_counts':dict(Counter(y['interest'] for y in outputs)),'needs_review_count':sum(bool(y['needs_review']) for y in outputs),'human_confirmed':False,'send_authorized':False,'scope':'shard-10 to shard-13'}
(p/'c-validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(report,ensure_ascii=False,indent=2))
