# fix3 六项定向复审

结论：**原六项均 ADDRESSED，但出现 1 类 Important 相邻回归，因此暂不通过本轮正式接续门槛。** 未新增其他开放范围问题，未发现 Critical。

本轮仅复审 fix1 报告的六项、原公开 25 条探针及与改动直接相邻的 8 条对照。未读取 holdout、未重跑 61 单元/52+2 验收/16 协调器/200 历史参考/压测，也未改核心、配置、manifest、测试、源库、归档或真实业务。所有执行本地离线，模型/网络/平台调用均 0。

版本：`fangyu-local-rules-20261029-v1-fix3`；core SHA256 `1c3b4bc554e8b58702d507d19ebda663e467c98d7f632c2cf5b54c481926f72e`；config SHA256 `2c27bdbdb3324d71e2475ad895e14ff5ac89203517990b5c8213d4bd60fb8e79`。

独立执行：

```text
python core-review-probes.py --output core-review-probe-fix3-results.json
python core-review-fix3-adjacent-probes.py
```

两命令 exit 0，完整输出分别保存到 `core-review-probe-fix3-results.json`、`core-review-fix3-adjacent-results.json`；后者同时调用归档 fix2 和当前 fix3，原样保存各版本结果。8 条相邻输入中 3 条属于下述同一回归，其余 5 条为主体、当前时态及局部条件保护的对照。样本为定向合成，不报告真实准确率。

## 原六项状态

| 原项 | 状态 | 实测证据与当前行为 |
|---|---|---|
| 1. 纯第三人/围观、代找主体与跨人条件 | **ADDRESSED** | `other_person_only/other_person_budget/quoted_other_demand` 均 discussion/unrelated、不备稿且无确认预算；`explicit_two_subjects` 保留妈妈两室需求，自己的5000预算转 unresolved_conditions/semantic_review，不错归给妈妈、不备稿；额外 `reported_then_own_control`、`proxy_and_self_control` 保留各自明确新需求。核心116–169、219–231行在确认角色前确定 actor，并分开条件。 |
| 2. 同作者旧资料时态/条件冲突 | **ADDRESSED（原反例）** | `own_older_body_current_stop` 为 ended/unrelated、不备稿；`own_older_body_current_supersedes` 只确认评论预算2000、虹桥，不混入正文5000、古北；旧正文留 context_evidence；已租好对照仍 ended。核心159–168行明确当前评论优先。下述 R1 为这次时间传播引入的独立相邻回归。 |
| 3. 否定供给、省主语 mixed | **ADDRESSED** | `negated_supply` 识别代找出租房态询盘 high；`mixed_no_punct/mixed_natural_no_punct/mixed_explicit_subject_no_punct` 均 mixed/high，供给旧单间不作为新两室条件。核心23–26、139–158行。 |
| 4. 局部多池 polarity | **ADDRESSED** | `condition_polarity` 独卫reject、电梯require；相反顺序对照亦正确；无法安全切开的“不要独卫必须有电梯”只确认两室，将局部条件保存为 unresolved/semantic_review、不备稿，符合不强解要求。核心261–273行及切句规则。 |
| 5. 地区排除、问地点不当target | **ADDRESSED** | `condition_region` 古北excluded；`condition_region_and` 古北/虹桥均excluded；`region_question` 不建立target，保留region_mentions/question；工作地两条对照只确认虹桥目标。核心284–307行。 |
| 6. 过去失败约看不超高 | **ADDRESSED（原反例）** | `past_appointment/past_appointment_natural` 按独立当前两室需求保留high，不再由过去失败约看升super_high；历史事件留context_evidence。核心135–142、197行；但历史事件之后明确再约的恢复有R1回归。 |

## Important R1：历史范围跨句持续，新的明确求租/约看没有常规当前标记就被全部删除

位置：**local_classifier.py 135–143 行**（历史范围设定/重置与 eligible），联动 **189–207 行**（误判最终 historical/discussion/unrelated）；rule_config.json `current_scope`。属于本次从逐句过滤改为时间状态传播直接引入，不是新增无关场景。

`temporal='historical'` 遇见历史分句后持续到后续句；新的“求租/想找/这周末想约看”本身没被允许重置当前范围，于是 142 行 eligible=false，143 行连新需求都不再承认，最后无异常地判不相关：

| 自有隔离案例 | fix2 实际 | fix3 实际 | 业务含义 |
|---|---|---|---|
| `history_then_new_search`：以前租过一室，想找两室，预算3000 | demand / active_at_comment / high，确认两室及3000 | discussion / historical / unrelated，无任何确认条件、无异常 | 过去住过与新找房动作应分开，不能让“以前”覆盖后面的愿望/行动。 |
| `history_then_explicit_seeking`：以前住过这里，求租两室 | demand / active_at_comment / high | discussion / historical / unrelated，无异常 | “求租两室”是明确新需求，至少不应被确定归无关。 |
| `failed_viewing_then_new_viewing`：上次看房没去成，这周末想约看 | demand / active_at_comment / super_high | discussion / historical / unrelated，无异常 | 不应该把失败旧事件变成超高，但新的本周末约看请求应独立保留。 |

对照 `history_then_now_control`：“以前住过这里，现在求租两室”在 fix3 为high，证实当前实现依赖“现在”这个窄重置词。原始评论常省略该词，不能因此删除明确求租。

建议只对这类新的独立需求/约看谓词确定时间作用域：能确认新动作则重置，若无法区分历史叙事中引用求租与当前请求，则保留原话并标局部语义待核；**不能一律把后句求租当历史无关，也不能简单让任何历史引文里的“求租”都重置**。无须扩为全量模型复核。请先为上述3条及原过去约看不超高对照做红绿回归，再定向独立复测 R1。

## 保留限制与证据更正

本次通用母句逐字复用、发送guard仍false；母句有限黑名单不当成事实证明。固定当前母库SHA的根manifest信任边界由根任务负责，本复审不新增黑名单、不把该非阻断限制提升为新的阻断。

原默认 `core-review-probe-results.json` 被作者复现先后更新；fix1 原JSON未另存，原 fix1 报告只保留当时实测摘要及版本说明。本轮新结果采用上述独立 fix3 文件，未覆盖原默认文件或 review-archive。原报告的失败历史与本报告的修复状态分开保存，不把任一轮实测等同人工gold或真实平台验收。
