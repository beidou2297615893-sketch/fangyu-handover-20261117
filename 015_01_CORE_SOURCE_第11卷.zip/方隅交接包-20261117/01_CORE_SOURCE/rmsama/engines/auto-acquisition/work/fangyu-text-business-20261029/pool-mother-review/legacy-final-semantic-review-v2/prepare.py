import pathlib,json,hashlib,string,collections,re
O=pathlib.Path(__file__).resolve().parent;P=O.parent;W=P.parent;R=P/'legacy-release-repairs-v2';V=P/'legacy-release-repairs'
def load(p):return json.loads(pathlib.Path(p).read_text(encoding='utf-8-sig'))
def jl(p):return [json.loads(l) for l in pathlib.Path(p).read_text(encoding='utf-8-sig').splitlines() if l.strip()]
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def objsha(x):return hashlib.sha256(json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def key(x):return x['platform'],x.get('cid',x.get('comment_id')),x.get('uid',x.get('customer_uid'))
def put(n,x):(O/n).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
anchors={'READY.json':'23eb7616b5d7ad5962acd780060142cc6c01275ee18070abfe2c9e9670f95497','manifest.json':'6bef452372b290bcf1f689447b1dac04726f0fce2bdcb5115a28346b5bd32ec0','repair-contract.json':'a7c6193ba4145ff1246e69eb17f836436369eaef0f316828eaee303e95cdffae','incremental-plan-overlays.jsonl':'2c2f12c65db07988af4638f23d7f2f5d9f232062beb4344c110806330baa9e21','source-bound-plan-overlays.jsonl':'8f932817830d917172f2f049a598aa3ca87eef77d6f4ada3b528ac180983567c'}
assert all(sha(R/n)==h for n,h in anchors.items())
ready=load(R/'READY.json');m=load(R/'manifest.json');assert all(sha(R/n)==h for n,h in ready['final_files_sha256'].items());assert all(sha(p)==h for p,h in m['sources_SHA256'].items())
base={key(x):x for x in jl(P/'legacy-release-package/candidate-abc/merged-plans.jsonl')};v1={k:dict(x) for k,x in base.items()}
for ov in jl(V/'source-bound-plan-overlays.jsonl'):v1[key(ov)].update(ov['replacement_plan'])
delta={key(x):x for x in jl(R/'incremental-plan-overlays.jsonl')};v2={k:dict(x) for k,x in v1.items()}
for k,ov in delta.items():assert objsha(v1[k])==ov['base_v1_applied_plan_sha256'];v2[k].update(ov['replacement_plan'])
cum={k:dict(x) for k,x in base.items()}
for ov in jl(R/'source-bound-plan-overlays.jsonl'):assert objsha(base[key(ov)])==ov['base_merged_plan_sha256'];cum[key(ov)].update(ov['replacement_plan'])
assert cum==v2
sources={}
for path in load(W/'region-brand-routing/current.json')['results'].values():
 for x in jl(path):sources[key(x)]=x
c1=load(V/'repair-contract.json')['families'];c2=load(R/'repair-contract.json')['families'];assert all(c2[k]==x for k,x in c1.items())
for name,c in c2.items():assert set(f for _,f,_,_ in string.Formatter().parse(c['template']) if f)==set(c['required_fill'])
def render(p,c):return c[p['family']]['template'].format(**p['fill']) if p['family'] else None
bound=clar=0;used=set();metadata=[]
for k,p in v2.items():
 assert p['send_authorized'] is False and p['can_send_now'] is False
 assert {a:b for a,b in p.items() if a not in ('family','fill','evidence','clarification_only','hold_reasons','status')}=={a:b for a,b in v1[k].items() if a not in ('family','fill','evidence','clarification_only','hold_reasons','status')}
 if not p['family']:continue
 assert set(p['fill'])==set(c2[p['family']]['required_fill']);render(p,c2);bound+=1;clar+=bool(p.get('clarification_only'));used.add(p['family'])
 for f,value in p['fill'].items():
  for span in value.split('、') if f=='requirements' else [value]:assert span in sources[k]['comment_text']
cli={key(x):x for x in jl(R/'CLI-draft-body-overlays.jsonl')}
for k,ov in delta.items():
 assert objsha(sources[k]['source_record'])==ov['original_classification_sha256'];assert hashlib.sha256(sources[k]['comment_text'].encode()).hexdigest()==ov['sourceSHA']
 assert cli[k]['draft_body']==render(v2[k],c2) and cli[k]['clarification_only']==v2[k]['clarification_only']
 assert cli[k]['send_authorized'] is False and cli[k]['can_send_now'] is False
rows=[];contexts={}
for k,ov in delta.items():
 r=sources[k];s=r['source_record'];raw=r.get('original_raw_record') or {};a=s.get('classification') or s
 ctx={'title':raw.get('post_title'),'body':raw.get('post_text') or s.get('post_body'),'parent':raw.get('parent_text') or s.get('direct_parent_text')};h=objsha(ctx);contexts[h]=ctx
 rows.append({'key':list(k),'cid':k[1],'comment':r['comment_text'],'source_comment_SHA':ov['sourceSHA'],'source_record_SHA':objsha(s),'source_topics':a.get('topic_evidence') or a.get('topics'),'source_regions':r.get('target_regions'),'source_time':r.get('time_mentions'),'source_review':a.get('needs_review'),'source_blocking':s.get('blocking_reasons'),'source_contact':r.get('contact_policy'),'context_SHA':h,'context_brand_Fangyu':bool(re.search('方隅',str(ctx))),'v1_family':v1[k]['family'],'v2_family':v2[k]['family'],'fill':v2[k]['fill'],'v1_body':render(v1[k],c1),'v2_body':render(v2[k],c2),'v2_clarification_only':v2[k].get('clarification_only'),'repair_reasons':ov['repair_reasons']})
old=[]
for x in jl(P/'legacy-final-semantic-review/case-review.jsonl'):
 k=tuple(x['key']);old.append({'key':list(k),'cid':k[1],'plan_unchanged':v1[k]==v2[k],'body_unchanged':render(v1[k],c1)==render(v2[k],c2),'v1_plan_SHA':objsha(v1[k]),'v2_plan_SHA':objsha(v2[k]),'v1_body_SHA':hashlib.sha256((render(v1[k],c1) or '').encode()).hexdigest(),'v2_body_SHA':hashlib.sha256((render(v2[k],c2) or '').encode()).hexdigest()})
put('changed-candidates.json',rows);put('shared-contexts.json',contexts);put('old61-hash-checks.json',old)
put('initial-validation.json',{'anchors':anchors,'READY_files_SHA_checked':len(ready['final_files_sha256']),'source_SHA_checked':len(m['sources_SHA256']),'definitions_checked':len(c2),'v1_definitions_unchanged':len(c1),'actual_used_families':len(used),'slot_rows_checked':bound,'delta_count':len(delta),'cumulative_equivalence':True,'metadata_unchanged_all_12963':True,'all_send_false':True,'housing':bound-clar,'clarification':clar,'held':len(v2)-bound,'old61_changed':[x['cid'] for x in old if not x['body_unchanged']],'old61_unchanged':sum(x['body_unchanged'] for x in old),'usage':'unknown'})
counts=collections.Counter(x['v2_family'] for x in rows)
for family,count in counts.items():
 sample=next(x for x in rows if x['v2_family']==family);print(json.dumps({'count':count,'family':family,'cid':sample['cid'],'comment':sample['comment'],'preview':sample['v2_body']},ensure_ascii=False))
print('BRAND_AND_SPECIAL')
for x in rows:
 if x['context_brand_Fangyu'] or re.search('这个[\s]*(?:月|价|预算|要求|不|没|不是|短)|不要|不接受|不租|多少钱.*这个|这个.*便宜',x['comment']):print(json.dumps({k:x[k] for k in ['cid','comment','context_brand_Fangyu','context_SHA','v2_body']},ensure_ascii=False))
