"""Independent synthetic probes. No source or held-out samples are loaded."""
import hashlib
import json
import argparse
from pathlib import Path
from local_classifier import LocalClassifier

root = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument('--output', default='core-review-probe-results.json')
args = parser.parse_args()
c = LocalClassifier()
base = {'platform': 'synthetic', 'published_at_unix': 1793270000,
        'post_body': '房东直租，两室公寓出租，可租。'}
cases = [
 ('other_person_only', '朋友正在找两室，我只是围观'),
 ('other_person_budget', '朋友正在找两室，预算3000，他想住古北；我现在不找房'),
 ('negated_supply', '不是本人出租，帮朋友问一下还有吗'),
 ('future_search_first_person', '我明年才开始找房，现在不找'),
 ('future_move_in', '现在找两室，明年入住'),
 ('condition_polarity', '求租两室，不要独卫但必须有电梯'),
 ('condition_region', '求租两室，除了古北都可以'),
 ('condition_region_and', '求租两室，古北不要，虹桥也不考虑'),
 ('workplace_same_clause', '求租两室，我在古北上班想住虹桥'),
 ('past_appointment', '我正在找两室，明天看房是去年的事了'),
 ('conditional_no_search', '如果朋友不找房了，我也不找房'),
 ('nonresidential', '想租一个办公室，预算3000'),
 ('mixed_no_punct', '我转租单间但想租两室'),
 ('explicit_two_subjects', '帮妈妈找两室，我自己的预算是5000'),
 ('no_demand_decoration', '房租这个词看着真好玩，哈哈'),
 ('quoted_other_demand', '她说想租一室，我只是来看装修的'),
 ('negative_wish', '我不想租房，明年也不想租'),
 ('region_question', '正在找两室，古北在哪啊'),
 ('mixed_natural_no_punct', '我转租单间同时想找两室'),
 ('mixed_explicit_subject_no_punct', '我转租单间但我想找两室'),
 ('region_workplace_label', '求租两室，工作地古北，想住虹桥'),
 ('past_appointment_natural', '我还在找两室，上次约周末看房没去成'),
]
out=[]
for key, comment in cases:
    r = dict(base, comment_text=comment, comment_id=key)
    result=c.classify(r)
    result['probe_mother']=c.choose_mother(result,[{'slot':1,'user_approved':True,'template':'宝宝，我住方隅公寓这边，介绍有优惠的','version':'synthetic'}])
    out.append({'id':key,'input':r,'result':result})
for key, comment, body in [
    ('own_older_body_current_stop','现在不找房了','正在找两室，预算3000，想住古北'),
    ('own_older_body_current_supersedes','现在求租一室，预算2000，想住虹桥','之前正在找两室，预算5000，想住古北'),
    ('own_older_body_ended','我已经租好了','正在找两室，预算3000'),
]:
    r=dict(base, comment_text=comment, post_body=body, post_author_same_as_commenter=True, comment_id=key)
    result=c.classify(r)
    result['probe_mother']=c.choose_mother(result,[{'slot':1,'user_approved':True,'template':'宝宝，我住方隅公寓这边，介绍有优惠的','version':'synthetic'}])
    out.append({'id':key,'input':r,'result':result})
guard_input=c.classify(dict(base,comment_text='正在找两室',comment_id='mother_fact_guard'))
mother_guard_probes=[]
for template in ['宝宝，我住方隅公寓这边，介绍有优惠的', '宝宝，方隅月租两千五，独卫阳台都有', '宝宝，这样的方隅有，宠物随便养']:
    mother_guard_probes.append({'template':template,'result':c.choose_mother(guard_input,[{'slot':1,'user_approved':True,'template':template,'version':'synthetic-guard'}])})
payload={'kind':'independent invented probes, not accuracy measurement',
         'sha256': {n:hashlib.sha256((root/n).read_bytes()).hexdigest() for n in ['local_classifier.py','rule_config.json']},
         'model_calls':0,'network_calls':0,'heldout_read':False,'cases':out,'mother_guard_probes':mother_guard_probes}
(root/args.output).write_text(json.dumps(payload,ensure_ascii=False,indent=2),encoding='utf-8')
for x in out:
    r=x['result']
    print(json.dumps({'id':x['id'],'text':x['input']['comment_text'],'role':r['role'],'state':r['demand_state'],'interest':r['interest_at_comment'],'exception':r['exception_type'],'topics':r['topics'],'regions':[(t['name'],t['relation']) for t in r['target_regions']],'budget':r['budget_mentions'],'polarity':[(t['pool'],t['polarity']) for t in r['topic_evidence']],'draft':r['probe_mother']['draft_ready']},ensure_ascii=True))
print(json.dumps({'mother_guard_probes':mother_guard_probes},ensure_ascii=True))
