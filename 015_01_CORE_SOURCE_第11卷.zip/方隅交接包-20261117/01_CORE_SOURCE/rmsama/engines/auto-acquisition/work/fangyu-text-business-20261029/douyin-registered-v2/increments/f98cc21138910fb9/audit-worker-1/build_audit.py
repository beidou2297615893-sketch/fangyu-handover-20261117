"""Materialize explicit model decisions; deterministic checks never classify text."""
import json,pathlib,hashlib,copy,sys,collections,importlib.util
from datetime import datetime,timezone
A=pathlib.Path(__file__).resolve().parent; B=A.parent; W=B.parents[2]
PART=B/'recall-audit/part-1'
def read(p):return [json.loads(l) for l in p.read_text(encoding='utf-8').splitlines() if l.strip()]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def put(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
task=json.loads((PART/'task.json').read_text(encoding='utf-8'))
manifest=json.loads((B/'manifest.json').read_text(encoding='utf-8'))
assert sha(B/'input.jsonl')==manifest['input_sha256'],'frozen input SHA mismatch'
sources={x['path']:sha(B/x['path']) for x in task['primary_sources']}
assert all(sources[x['path']]==x['sha256'] for x in task['primary_sources']), 'primary SHA mismatch'
primary={r['review_key']:r for x in task['primary_sources'] for r in read(B/x['path'])}
inputs={r['review_key']:r for r in read(B/'input.jsonl')}
pages=[json.loads(p.read_text(encoding='utf-8')) for p in sorted(PART.glob('page-*.json'))]
comments={c['key']:c for p in pages for g in p['post_groups'] for c in g['comments']}
decisions={}
for line in (A/'decisions.tsv').read_text(encoding='utf-8').splitlines():
 k,d,r=line.split('|',2);assert k not in decisions;assert d in ('keep','change')
 decisions[k]={'review_key':k,'decision':d,'reason':r,'patch':{}}
assert set(decisions)==set(comments)==set(task['expected_review_keys'])
assert len(comments)==len(decisions)==task['records']==341
patches={}
def patch(k,**kw):patches.setdefault(k,{}).update(kw)
def plan(k):return copy.deepcopy(primary[k]['reply_plan'])
def local(k,requirement,extra_missing=(),extra_caution=()):
 p=plan(k);p['local_mother']={'family':'requirements','fill':{'requirements':requirement},'evidence':[{'field':'requirements','quote':inputs[k]['comment_text']}]}
 p['missing_facts']+=list(extra_missing);p['caution']+=list(extra_caution);patch(k,reply_plan=p)
patch('D0004',topics=copy.deepcopy(primary['D0004']['topics'][:1]))
p=plan('D0054');p.update(preferred_mother_slot=None,generic_intro_suitable=False,missing_facts=[],caution=['本人看过房的费用经历不等于他人条件；是否仍继续找房待核，暂不强推母句'],local_mother=None)
t=copy.deepcopy(primary['D0054']['topics']);t[0]['subject']='unresolved';t[0]['condition_scope']='本人看过房源的收费经历，非本人新房费用硬条件'
patch('D0054',role='demand',demand_state='unknown',interest='medium',topics=t,reason='本人看房后抱怨水电贵，保留可能继续找房机会；尚未明确当前动作，不把所看房收费当本人新房硬条件。',needs_review=['是否仍在继续找房及能接受的费用口径待核；电1.2水10是所看房收费而非本人预算'],reply_plan=p)
local('D0068','上海；短租；一个月')
for k in ['D0110','D0116','D0245','D0251','D0164','D0287','D0470','D0476','D0503','D0515']:
 p=plan(k);p['caution'].append('找房动作未知；本计划仅保留候选，先确认是否本人当前找房及所询对象，不把生活分享当可租库存')
 patch(k,demand_state='unknown',reason='本人在生活或看房分享下简短询问价格或位置，保留中等住房关注；未明确当期找房推进，房源可租性及本人动作待核。',needs_review=primary[k]['needs_review']+['是否本人当前在找房及所询对象待核，不能仅凭生活分享短询确认找房动作'],reply_plan=p)
t=copy.deepcopy(primary['D0125']['topics'])
for v in t:v.update(polarity='unknown',subject='unresolved',condition_scope='有哇可为告知供给或询问房源，供需语气待核')
r=copy.deepcopy(primary['D0125']['target_regions'])
for v in r:v.update(relation='unresolved',condition_scope='本人所述川沙地铁旁边，供给地或求租目标尚未确定')
p=plan('D0125');p.update(preferred_mother_slot=None,generic_intro_suitable=False,missing_facts=[],caution=['川沙地铁旁边有哇的供需语气未明，先确认是否本人求租，不生成推广接话'],contact_policy='unknown',local_mother=None)
patch('D0125',role='unknown',demand_state='unknown',interest='uncertain',topics=t,target_regions=r,needs_review=['有哇可为提供川沙房源或问有没有，需确认供需语气及当前动作'],reason='川沙地铁旁边有哇缺少明确问句或提供声明，既可能供给也可能询房，不能无证判本人高兴趣求租。',reply_plan=p)
# These four explicit provisional decisions await the coordinator's recorded ruling.
pending=['D0183','D0393','D0402','D0798']
for k in pending:
 p=plan(k);p['caution'].append('地区短询的意向级别待统一口径裁决；当前房源及本人找房状态未核')
 patch(k,interest='medium',reason='非明确库存的生活分享或租房攻略下指定地区短询，保留本人询房动作与地区；泛短询暂记中兴趣，当前实际需求仍待核。',needs_review=primary[k]['needs_review']+['泛短询未给更多本人推进证据，当前需求及可租对象待核'],reply_plan=p)
local('D0194','余杭区；工作地方在奥克斯时代之城；1000到1500左右',extra_caution=['奥克斯时代之城仅工作目的地，用于通勤核实，不当目标住宅地点'])
local('D0298','下周就要入职了，很急；预算3000；离徐汇区近的；朝南，可合租；带图来')
local('D0407','这个1400；马上签合同',extra_caution=['1400是本人接受的所示房价，未核方隅报价；马上签合同只是意愿，未签约成功'])
p=plan('D0523');p['caution'].append('住房探访不是确认有库存；设施短询不足确认高意向，当前实际找房待核')
patch('D0523',interest='medium',reason='住房探访下询空调暖气，保留两项设施兴趣；未有明确可租库存或更多本人推进证据，记中兴趣并留核。',needs_review=primary['D0523']['needs_review']+['当前是否实际找房及所询房源可租性待核'],reply_plan=p)
local('D0562','正儿八经干净点的套一；工作在高新这边；租房都好贵',extra_caution=['高新只按本人工作地用于通勤核实；租房贵是价格负担表达，未提供具体预算'])
k='D0716';r=copy.deepcopy(primary[k]['target_regions'])
for v in r:v.update(relation='unresolved',condition_scope='租金行情查询范围，是否本人具体住宅目标待核')
p=plan(k);p['caution'].append('秀沿路是本条租金行情查询范围，不等于已确认目标；本人找房动作待核')
patch(k,demand_state='unknown',interest='medium',target_regions=r,reason='本人询秀沿路一般租金，保留价格与地区关注；行情查询不足确认本人正在推进租赁或该地为确定居住目标。',needs_review=primary[k]['needs_review']+['本人是否正在找房、具体房型及秀沿路是否居住目标待核'],reply_plan=p)
local('D0620','合租吗；想看房子')
local('D0662','联系看房')
t=copy.deepcopy(primary['D0664']['time_mentions'])
for v in t:v.update(time_role='other',normalized=None,verification='本人既往已经住过的时长，不是新租期或明确合同总期限')
patch('D0664',time_mentions=t)
p=plan('D0693');p['caution'].append('噪音和异味是现居搬家原因，未确认新房具体硬指标；富阳仅现居地，先核是否已开始找房，不把原因当库存承诺')
patch('D0693',reply_plan=p)
local('D0776','多少一个月；怎么联系')
local('D0791','免费住吗',extra_missing=['免费住的适用资格、免租时长、合同与全部收费条件须另核，不能把源帖活动套给方隅'],extra_caution=['免费住吗保留为疑问；未核方隅免租活动及本人适用资格，不能渲染为已可免费入住'])

for k,decision in decisions.items():
 if decision['decision']=='change':
  assert k in patches and patches[k],f'No patch for explicit change {k}'
  decision['patch']=patches[k]
 else:assert k not in patches,f'Patch on keep {k}'
allowed={'role','demand_state','interest','topics','target_regions','time_mentions','other_constraints','possible_topics','evidence','reason','context_used','needs_review','contact_boundaries','context_flags','reply_plan'}
for d in decisions.values():assert set(d['patch'])<=allowed

# All review content is joined only by frozen identity; no text classifier is used.
final=[];quote_count=0;render_checks=[]
spec=importlib.util.spec_from_file_location('locked_mother_adapter',W/'mother_adapter.py');adapter=importlib.util.module_from_spec(spec);spec.loader.exec_module(adapter)
spec2=importlib.util.spec_from_file_location('local_fixed_template',B/'batch_short_mothers.py');renderer=importlib.util.module_from_spec(spec2);spec2.loader.exec_module(renderer)
contract=json.loads((B/'local-mother-contract.json').read_text(encoding='utf-8'))
def check_quotes(obj,own,allowed_body):
 global quote_count
 if isinstance(obj,dict):
  if 'quote' in obj:
   q=obj['quote'];assert isinstance(q,str) and q and (q in own or q in allowed_body),f'Nonliteral quote {q!r}'
   quote_count+=1
  for v in obj.values():check_quotes(v,own,allowed_body)
 elif isinstance(obj,list):
  for v in obj:check_quotes(v,own,allowed_body)
for k in task['expected_review_keys']:
 raw=primary[k];s=inputs[k];c=comments[k]
 assert all(raw[x]==s[x] for x in ['review_key','comment_id','customer_uid','video_id','platform']),k
 assert c['text']==s['comment_text'] and all(c['first_semantic_judgment'][f]==raw.get(f) for f in c['first_semantic_judgment']),k
 row=copy.deepcopy(raw);row.update(copy.deepcopy(decisions[k]['patch']))
 assert all(row[x]==raw[x] for x in ['review_key','comment_id','customer_uid','video_id','platform'])
 own=s['comment_text'];same_body=s.get('post_body','') if s.get('post_author_same_as_commenter') else ''
 check_quotes({f:row[f] for f in ['topics','target_regions','time_mentions','other_constraints','possible_topics','contact_boundaries']},own,same_body)
 for q in row['evidence']:
  assert q and (q in own or q in same_body),k
  quote_count+=1
 assert 'local_mother' in row['reply_plan'],k
 check_quotes(row['reply_plan']['local_mother'],own,'')
 info=renderer.render_plan(row,own,contract)
 render_checks.append({'review_key':k,'family':info['family'],'status':info['status'],'literal_fields':info['literal_fields'],'rendered_character_count':len(info.get('validated_plan_text') or '')})
 row['classification_method']='ai_independent_semantic_fine_review'
 row['classification_stages_completed']=['initial_semantic','detailed_semantic','independent_semantic']
 row.pop('classification_review_source',None)
 final.append(row)
isolation=A/'isolated-reviewed.jsonl'
isolation.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in final),encoding='utf-8')
digest=sha(isolation);cache={}
for row in final:
 candidate=copy.deepcopy(row);candidate['classification_review_source']={'path':str(isolation),'sha256':digest}
 adapter.validate_new_review(candidate,B,cache)
assert all(sha(B/x['path'])==x['sha256'] for x in task['primary_sources'])

status='validated_pending_semantic_ruling' if pending and '--ruling-resolved' not in sys.argv else 'complete'
if status=='complete':
 for page_no,page in enumerate(pages):
  keys=[c['key'] for g in page['post_groups'] for c in g['comments']]
  out=[decisions[k] for k in keys];assert len(out)==len(set(keys))
  (PART/f'page-{page_no:02}.audit.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in out),encoding='utf-8')
put(A/'render-validation.json',render_checks)
checks={'state':status,'records':len(final),'explicit_keep':sum(d['decision']=='keep' for d in decisions.values()),'explicit_change':sum(d['decision']=='change' for d in decisions.values()),'pages':len(pages),'source_page_id_sets_equal':True,'formal_page_audits_written':3 if status=='complete' else 0,'formal_page_id_sets_equal':True if status=='complete' else None,'all_semantic_decisions_final':status=='complete','task_id_set_equal':True,'duplicate_keys':0,'identity_preserved':True,'literal_quotes_checked':quote_count,'literal_quotes_passed':True,'local_mother_explicit':341,'local_mother_null':sum(r['reply_plan']['local_mother'] is None for r in final),'fixed_template_checks_passed':len(render_checks),'real_isolation_file':str(isolation),'real_isolation_sha256':digest,'original_mother_adapter_validate_new_review_passed':len(final),'primary_sources':sources,'primary_sha_task_match':True,'locked_adapter_sha256':sha(W/'mother_adapter.py'),'input_sha256':sha(B/'input.jsonl'),'input_sha_manifest_match':True,'local_mother_contract_sha256':sha(B/'local-mother-contract.json'),'pending_semantic_ruling':pending if status!='complete' else [],'model_usage':'unknown','platform_calls':0,'sent':0,'human_confirmed':False,'send_authorized':False,'new_reply_body_written':False,'completed_at':datetime.now(timezone.utc).isoformat()}
put(A/'validation.json',checks)
put(A/'progress.json',{'state':status,'pages_fully_read':[0,1,2],'comments_semantically_reviewed':341,'explicit_decisions':len(decisions),'usage':'unknown','pending_ruling':checks['pending_semantic_ruling'],'scope':'part-1 only; no primary/source/platform/product changes'})
print(json.dumps(checks,ensure_ascii=False))
