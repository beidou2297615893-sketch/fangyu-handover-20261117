import json,sqlite3,hashlib,collections
from pathlib import Path
R=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent;B=R/'work/fangyu-douyin-independent';D=W/'douyin-registered-v2'
def sha(b):return hashlib.sha256(b).hexdigest()
policy_path=B/'runner-audit-myeaj720/runner-qualification-policy.json';policy=json.loads(policy_path.read_text(encoding='utf8'))
prior=D/'classified-109.jsonl'
current=B/'text-screening-current-summary.json'
if current.exists():
 latest=json.loads(current.read_text(encoding='utf8'));candidate=Path(latest.get('result_file',''))
 if candidate.is_file():
  candidate=candidate.resolve();assert candidate.is_relative_to(D.resolve()) or candidate.is_relative_to((B/'text-classification-snapshots').resolve())
  prior=candidate
old=[json.loads(x) for x in prior.read_text(encoding='utf8').splitlines()];done={x['comment_id'] for x in old}
db=sqlite3.connect((B/'runtime/collection.sqlite3').as_uri()+'?mode=ro',uri=True);db.execute('BEGIN')
qualified={}
for rid,spec,state in db.execute('select request_id,spec,state from attempts'):
 s=json.loads(spec)
 if not isinstance(s,dict) or s.get('kind')!='comments' or state!='parsed':continue
 e=s.get('eligibility');is_manual=rid in policy['qualified_request_ids']
 if is_manual or isinstance(e,dict) and e.get('state')=='eligible':
  if is_manual:assert s['account_uid']==policy['account_uid']
  qualified[rid]=s
assoc=collections.defaultdict(list);versions=collections.defaultdict(set)
for rid,key,store,word,target,at,data in db.execute("select request_id,stable_key,store_id,keyword,target,collected_at,data from observations where kind='comments'"):
 if rid not in qualified:continue
 s=qualified[rid];assert s['target']==target
 item=json.loads(data);versions[key].add((item.get('text'),str(item.get('aweme_id')),str(item.get('user',{}).get('uid'))))
 assoc[key].append({'request_id':rid,'source_store':store,'keyword':word,'video_id':target,'observed_at':at,'qualification':'manual_source_policy' if rid in policy['qualified_request_ids'] else 'eligible_source_spec'})
videos={vid:json.loads(data) for vid,data in db.execute("select source_id,data from entities where kind='search'")}
rows=[];allids=[]
for key,cid,data in db.execute("select stable_key,source_id,data from entities where kind='comments' order by rowid"):
 if key not in assoc:continue
 allids.append(cid)
 if cid in done:continue
 c=json.loads(data);assert cid==c['cid'] and isinstance(cid,str) and isinstance(c['user']['uid'],str)
 v=videos.get(str(c['aweme_id']),{});uid=c['user']['uid'];pa=str(v.get('author',{}).get('uid',v.get('author_user_id','')))
 rows.append({'review_key':f'D{len(rows)+1:04d}','platform':'douyin','comment_id':cid,'customer_uid':uid,'video_id':str(c['aweme_id']),
  'comment_text':c.get('text') or '','published_at_unix':c.get('create_time'),'post_body':v.get('desc') or '',
  'post_author_uid':pa,'post_author_same_as_commenter':bool(pa and pa==uid),'direct_parent_text':None,
  'reply_to':str(c.get('reply_id','0')),'deeper_reply_count_visible':c.get('reply_comment_total',0),'deeper_replies_read':False,
  'ip_location_raw':c.get('ip_label'),'source_observations':assoc[key],'source_version_conflict':len(versions[key])>1,
  'source_stable_key':key,'source_comment_sha256':sha((c.get('text') or '').encode()),'rule_version':'business-text-20261029-v2','send_authorized':False})
db.commit();db.close();assert done<=set(allids)
if not rows:
 print(json.dumps({'new_comments':0,'already_analyzed':len(old),'eligible_snapshot':len(allids),'source_database_modified':False}));raise SystemExit(0)
packed=''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in rows);run=sha(packed.encode())[:16];dest=D/'increments'/run;dest.mkdir(parents=True,exist_ok=True)
p=dest/'input.jsonl'
if p.exists():assert p.read_text(encoding='utf8')==packed
else:p.write_bytes(packed.encode('utf8'))
for i in range(3):
 subset=rows[i::3];(dest/f'shard-{i}.jsonl').write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in subset),encoding='utf8')
manifest={'previous_comments':len(old),'eligible_snapshot_comments':len(allids),'new_comments':len(rows),'input_sha256':sha(packed.encode()),'policy_sha256':sha(policy_path.read_bytes()),'prior_result_sha256':sha(prior.read_bytes()),'prior_result_file':str(prior),'eligibility_request_count':len(qualified),'all_eligible_comment_ids':allids,'source_database_modified':False,'sent':0}
(dest/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf8');(dest/'all-source-observations.json').write_text(json.dumps(dict(assoc),ensure_ascii=False),encoding='utf8')
print(json.dumps({'directory':str(dest),'prior':len(old),'eligible_snapshot':len(allids),'new':len(rows),'shards':[len(rows[i::3]) for i in range(3)]},ensure_ascii=False))
