import json,sys,pathlib
base=pathlib.Path(__file__).parent
d=json.loads((base/f'page-{int(sys.argv[1]):02d}.json').read_text(encoding='utf-8'))
for i,p in enumerate(d['shared_post_context']):
 print('POST',i,p['video'],p['post_body'])
 for c in p['comments']:
  print(c['key'],json.dumps(c['text'],ensure_ascii=False),('OWNBODY' if c['same_author'] else ''),('PARENT='+str(c['parent']) if c['parent'] else ''),('CONFLICT' if c['source_conflict'] else ''))
