import pathlib,json,hashlib,collections
O=pathlib.Path(__file__).resolve().parent;P=O.parent;W=P.parent;R=P/'legacy-release-repairs-v2'
def load(p):return json.loads(pathlib.Path(p).read_text(encoding='utf-8-sig'))
def jl(p):return [json.loads(x) for x in pathlib.Path(p).read_text(encoding='utf-8-sig').splitlines() if x.strip()]
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def objsha(x):return hashlib.sha256(json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def put(n,x):(O/n).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
candidates=load(O/'changed-candidates.json');bycid={x['cid']:x for x in candidates};contexts=load(O/'shared-contexts.json')
notes={
'7301965013462303515':('pass','contact_method','原帖住房对象保留，问联系方法未反转为让客户来联系。'),
'7380302177145750281':('pass','viewing_progression','保留原帖对象，以看房安排承接想要房的推进，不声称已订房或已约看。'),
'7546632139191092025':('pass','room_explicit_rate','两房、明确一个月报价及原帖对象均保留；未新增租期。'),
'7563441906236769087':('redundant_confirmation','source_brand_known','正文已有方隅管理及明确单间对象，重复问是不是原帖房源无必要；可直接保留原帖对象/月租待问。来源品牌不是发送账号同店核验。'),
'7564246228821623594':('change_plan_only','source_price_verification','本人这个3800？是在核原帖3800元/月报价，现稿却问3800价位有没有合适的，价格角色与动作仍错。'),
'7593092244895728441':('pass','housing_mode_question','合租是否成立保持待核，没有把客户问题变成已接受合租。'),
'7617120932772233999':('pass','source_price_availability','原帖500房与空房询问有对象承接；500非本人预算。有没有合适的略重复，可简化但不另判实质反向。'),
'7628835192904008502':('pass','availability_price_location','有无房、价格、位置三动作保持，来源房源未默认方隅可租库存。'),
'7645355320000627513':('pass','short_lease','原评明确公寓，短租可否询问保留，不新增月数或报价周期。'),
'7646850595835822911':('pass','area_query','多少平作为面积询问保留，未转为金额或新的面积要求。'),
'7649985549595771654':('pass','rent_process','本人怎么租可对应租赁对接/流程，不是把推荐需求擅变流程。'),
'7662621180151890737':('pass','room_price_location','3800、一室一厅与位置保留为原帖所指对象下的询问；无对应源报价实证，不擅认预算或已核现价。'),
'7682343363664069416':('pass','monthly_lease_mode','可以月租吗仍为租赁方式待问，没有输出具体价格、确定期限或月价已核；建议后续文案明确能否按月租。'),
'7687783794661278479':('change_plan_only','own_place_reference','这个位置指本人已写出的路口，源帖是上海低预算攻略，不能新增是否原帖房源确认。原desired地点关系应保留。'),
'7699545802644980515':('pass','utility_question','民水民电保留为问询，没有把源帖未有的费率或民用资格当事实。'),
'7699930355282051903':('pass','accepted_price_location','8500还可以的价位接受与位置询问均保留，未升级为严格预算上限。'),
'7432282565551653670':('redundant_confirmation','source_brand_known','正文明确北京未来云城方隅的一间转租房，所问这个多钱有现成对象，重复问原帖对象降低接话质量；可引用原帖对象待问报价。'),
'7520428159360402228':('redundant_confirmation','source_brand_known','正文明确未来云城方隅，评论又写这个房子，没必要再次确认是否原帖；保留同品牌来源信息但不扩成实际账号/库存事实。'),
'7696414781808689957':('pass','prior_blocker_contact_object','原阻断已修：这个原帖对象、租金、位置、私聊联系本人均在，没有只要原房或已接受替代的新增判断。'),
'6acf7c9f0000000008031dc0':('pass','prior_blocker_purpose','原阻断已修：真实个人转租空正文下先问住房用途，无品牌推广，短租及期限问题仍保留。')}
rows=[]
for cid,(verdict,group,reason) in notes.items():rows.append({**bycid[cid],'verdict':verdict,'semantic_group':group,'reason':reason,'selection':'two_prior_blockers_plus_eighteen_changed_true_cases','new_holdout':False,'human_confirmed':False,'send_authorized':False})
sources={}
for path in load(W/'region-brand-routing/current.json')['results'].values():
 for x in jl(path):sources[x['comment_id']]=x
scan={x['cid']:x for x in jl(R/'all-6694-final-object-guard-scan.jsonl')}
boundary={
'7610009622871638799':('change_plan_only','comparative_price_reference','这个价格的还有嘛指向源帖2.2k价位；不当实体是正确的，但排除后沿用空房/租金泛问仍丢价位比较锚点。应保留原帖该价位询有无，不强认本人预算。'),
'7668177041443865390':('needs_targeted_label_or_neutral_reference','ambiguous_monthly_reference','这个月租多少钱可切分这个/月租多少钱或这个月/租多少钱；不能由紧邻月字认定纯时间指代。补最小指代角色或保留不消歧的原话，禁止将排除收据写成语义已证实。')}
for cid,(verdict,group,reason) in boundary.items():
 r=sources[cid];s=r['source_record'];raw=r.get('original_raw_record') or {};ctx={'title':raw.get('post_title'),'body':raw.get('post_text') or s.get('post_body'),'parent':raw.get('parent_text') or s.get('direct_parent_text')};h=objsha(ctx);contexts[h]=ctx
 rows.append({'cid':cid,'key':[r['platform'],cid,r['customer_uid']],'comment':r['comment_text'],'source_comment_SHA':hashlib.sha256(r['comment_text'].encode()).hexdigest(),'source_record_SHA':objsha(s),'context_SHA':h,'source_topics':s.get('topic_evidence'),'exclusion_receipt':scan[cid],'verdict':verdict,'semantic_group':group,'reason':reason,'selection':'unchanged_nonentity_exclusion_boundary','new_holdout':False,'human_confirmed':False,'send_authorized':False})
put('shared-contexts.json',contexts)
(O/'case-review.jsonl').write_text(''.join(json.dumps(x,ensure_ascii=False,separators=(',',':'))+'\n' for x in rows),encoding='utf-8')
newslots=set(k for x in candidates for k in x['fill']);seenslots=set(k for x in rows[:20] for k in x['fill'])
assert newslots<=seenslots
assert all(x['v2_clarification_only'] and '？' in x['v2_body'] and '确认对象后' in x['v2_body'] for x in candidates)
fixes=[
 {'cid':'7687783794661278479','priority':'P1','required':'Restore v1 area plan or exclude own explicit desired-location anaphora from source-post-object conversion; retain exact road intersection and original spelling; no source reclassification.'},
 {'cid':'7564246228821623594','priority':'P1','required':'Use source quote verification action for 3800, preserve original property reference; do not ask for general houses at that price. Source post price is evidence of what is being queried, not verified Fangyu actual offer.'},
 {'cid':'7610009622871638799','priority':'P1','required':'Preserve source price reference for availability inquiry; nonentity exclusion must route to price-reference handling, not erase comparison anchor.'},
 {'cid':'7668177041443865390','priority':'P1','required':'Do not assert temporal-only reference from regex. Use existing evidence if sufficient, otherwise one short reference-role tag or neutral original-reference family; no full intent rerun.'},
 {'cids':['7432282565551653670','7520428159360402228','7563441906236769087'],'priority':'P2','required':'Replace unnecessary repeated source-object question with source-referenced query using known context; do not infer sender identity, exact store inventory or actual offer validity.'}]
put('required-patch.json',{'release_condition':'resolve_three_semantic_errors_and_one_reference_ambiguity; streamline_three_redundant_confirmations','preserve_v2_frozen_bytes':True,'fixes':fixes,'avoid':'another blanket regex expansion; use typed subject/object/price-role information or neutral closed template','not_required':'full285_or147_or6694_semantic_rerun'})
coverage={'changed_semantic_review_count':20,'extra_exclusion_boundary_count':2,'prior61_actual_changes_reviewed':['7696414781808689957','6acf7c9f0000000008031dc0'],'prior61_unchanged_hash_only':59,'all_new_fill_keys':sorted(newslots),'selected_fill_keys':sorted(seenslots),'all_new_fill_keys_represented':True,'exact_new_families_selected':len({x['v2_family'] for x in rows[:20]}),'exact_new_families_total':30,'all_exact_new_families_semantically_reviewed':False,'interactions':dict(collections.Counter(x['semantic_group'] for x in rows)),'negation_comparison_note':'Changed266 contains no observed explicit exclusion/negation or comparative-price demand beyond interrogative negative forms; original61 comparison/negation-related records unchanged by hashes, not regraded. Nonentity price-reference boundary was separately checked and failed.','not_population_accuracy':True,'new_holdout':False}
put('coverage.json',coverage)
m=load(R/'manifest.json');ready=load(R/'READY.json');assert all(sha(R/n)==h for n,h in ready['final_files_sha256'].items());assert all(sha(p)==h for p,h in m['sources_SHA256'].items())
v=load(O/'initial-validation.json');v.update({'finite_semantic_review_complete':True,'changed_sample_verdict_counts':dict(collections.Counter(x['verdict'] for x in rows[:20])),'extra_boundary_verdict_counts':dict(collections.Counter(x['verdict'] for x in rows[20:])),'all_changed266_actual_confirmation_body_check':True,'local_draft_version_enable_verdict':'NOT_READY_TYPED_REFERENCE_AND_PRICE_ROLE_FIXES_REQUIRED','original_two_blockers_fixed':True,'frozen_and_sources_SHA_unchanged_after':True,'platform_calls':0,'send_attempts':0,'source_or_pointer_writes':0,'usage':'unknown'})
put('validation.json',v)
print(json.dumps({'changed_sample_verdicts':v['changed_sample_verdict_counts'],'boundary_verdicts':v['extra_boundary_verdict_counts'],'coverage':coverage,'enable_verdict':v['local_draft_version_enable_verdict']},ensure_ascii=True))
