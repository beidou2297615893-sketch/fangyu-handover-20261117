"""Publish an ordered transport queue from the classification module's snapshot."""
from collections import Counter
from contextlib import closing
from datetime import datetime, timedelta, timezone
import hashlib
import json
from pathlib import Path
import sqlite3
import subprocess
import sys
import time

from daily_time_sort import atomic
import recency

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
sys.path.insert(0, str(HERE.parent / 'business-fit'))
import business_fit
PRODUCER = 'douyin-classification-ready-v1'


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def sha(value):
    return hashlib.sha256(value).hexdigest()


def snapshot():
    pointer = HERE / 'daily-priority/current.json'
    current = read(pointer)
    source = current['platforms']['douyin']
    local_day = datetime.now(timezone(timedelta(hours=8))).date().isoformat()
    if (current['local_day'] != local_day
            or source.get('reply_priority_version') != recency.DOUYIN_REPLY_PRIORITY_VERSION
            or source.get('active_pool_policy') != recency.DOUYIN_ACTIVE_POOL_POLICY
            or sha(Path(source['source']).read_bytes()) != source['source_sha256']):
        for attempt in range(3):
            subprocess.run([sys.executable, str(HERE / 'daily_time_sort.py'), '--platform', 'douyin'],
                           capture_output=True, cwd=ROOT)
            current = read(pointer)
            source = current['platforms']['douyin']
            if (current['local_day'] == local_day
                    and source.get('reply_priority_version') == recency.DOUYIN_REPLY_PRIORITY_VERSION
                    and source.get('active_pool_policy') == recency.DOUYIN_ACTIVE_POOL_POLICY
                    and sha(Path(source['source']).read_bytes()) == source['source_sha256']):
                break
            if attempt == 2:
                raise RuntimeError('上游排序快照仍在更新，请稍后重新启动') from None
            time.sleep(1)
    data = Path(source['queue']).read_bytes()
    if sha(data) != source['sha256']:
        raise RuntimeError('分类排序文件校验失败')
    return source, [json.loads(line) for line in data.splitlines() if line.strip()]


def ordered_items(rows, canonical, comments, customers, skipped_videos, task, skipped=None):
    if skipped is None:
        skipped = Counter()
    for row in rows:
        cid, uid, video = (str(row.get(key) or '') for key in ('comment_id', 'customer_uid', 'video_id'))
        band = row['reply_priority']['time_band']
        if video in skipped_videos:
            skipped[band, '视频不可用'] += 1
            continue
        if (cid in comments or uid in customers or (task / (cid + '.json')).exists()
                or (task / (cid + '.json.submitted')).exists()):
            skipped[band, '已有记录或同批重复'] += 1
            continue
        if not all(value.isdigit() for value in (cid, uid, video)):
            skipped[band, '目标编号不全'] += 1
            continue
        source = canonical.get(cid)
        if not source or any(source.get(key) != row.get(key) for key in
                ('customer_uid', 'video_id', 'comment_text', 'reply_body_sha256', 'reply')):
            skipped[band, '分类来源不一致'] += 1
            continue
        # A valid frozen row can age out while collection and sending continue.
        if not business_fit.screen(source)['eligible_candidate']:
            skipped[band, '最新业务条件或30天时效不符'] += 1
            continue
        reply = source.get('reply') or {}
        draft = reply.get('draft_text') or ''
        if (source.get('pending_candidate') is not True
                or source.get('commercial_fit', {}).get('eligible_candidate') is not True
                or not draft.strip()
                or reply.get('contact_hold') or source.get('needs_currentness_review')
                or sha(draft.encode()) != source.get('reply_body_sha256')):
            skipped[band, '原稿或分类暂缓'] += 1
            continue
        priority = row['reply_priority']
        comments.add(cid)
        customers.add(uid)
        yield dict(cid=cid, uid=uid, video=video, text=source['comment_text'], draft=draft,
                   created=row.get('published_at') or row.get('original_comment_date'),
                   original_reply_sha256=source['reply_body_sha256'], reply_sha256=source['reply_body_sha256'],
                   reply_priority=priority)


def publish(task, *, preview=False):
    task = task.resolve()
    if task.parent != ROOT / 'work':
        raise RuntimeError('发送任务目录不匹配')
    target = task / 'approved-cli-queue.json'
    manifest = read(target)
    if manifest.get('authorized') is not True or not manifest.get('account_uid'):
        raise RuntimeError('未核对发送账号的既有授权')
    source, rows = snapshot()
    now = datetime.now(timezone.utc).timestamp()
    for row in rows:
        row['reply_priority'] = recency.douyin_reply_priority(row, now)
    rows.sort(key=lambda row: row['reply_priority']['key'])
    handoff_path = ROOT / 'work/fangyu-douyin-independent/classification-handoff-status.json'
    handoff = read(handoff_path)
    data = Path(handoff['output']).read_bytes()
    if sha(data) != handoff['output_sha256']:
        raise RuntimeError('分类交接文件校验失败')
    ids = {row['comment_id'] for row in rows}
    canonical = {}
    for line in data.splitlines():
        if line.strip():
            record = json.loads(line)
            if record.get('comment_id') in ids:
                canonical[record['comment_id']] = record

    ledger = ROOT / 'work/shared-acquisition-ledger/shared.sqlite3'
    with closing(sqlite3.connect(ledger.as_uri() + '?mode=ro', uri=True)) as db:
        attempts = db.execute("SELECT comment, customer FROM reservations WHERE platform='douyin'").fetchall()
    receipts = ROOT / 'Codex获客工作台/work/reply_receipts.sqlite3'
    with closing(sqlite3.connect(receipts.as_uri() + '?mode=ro', uri=True)) as db:
        attempts.extend(db.execute('SELECT cid, uid FROM sends'))
    exclusions = task / 'unavailable-targets.json'
    excluded = read(exclusions) if exclusions.exists() else {}
    comments = {str(cid) for cid, _ in attempts} | set(excluded.get('comments', {}))
    customers = {str(uid) for _, uid in attempts}
    skipped = Counter()
    items = list(ordered_items(rows, canonical, comments, customers, excluded.get('operator_skipped_videos', {}), task, skipped))
    payload = json.dumps(items, ensure_ascii=False, sort_keys=True, separators=(',', ':'))
    if read(handoff_path)['output_sha256'] != handoff['output_sha256']:
        raise RuntimeError('分类交接刚更新，请重新生成队列')
    if manifest.pop('priority_band_limit', None) is not None:
        manifest['authorization'] = 'User 2026-11-04: send in upstream order and continue beyond an empty time band.'
    manifest.update(prepared_by=PRODUCER, items=items, items_sha256=sha(payload.encode()),
                    source_output_sha256=handoff['output_sha256'], priority_queue_sha256=source['sha256'],
                    active_pool_policy=recency.DOUYIN_ACTIVE_POOL_POLICY)
    if not preview:
        atomic(target, manifest)
    return {
        'classified': Counter(row['reply_priority']['time_band'] for row in rows),
        'ready': Counter(item['reply_priority']['time_band'] for item in items),
        'first_band': items[0]['reply_priority']['time_band'] if items else None,
        'skipped': {band: {reason: count for (label, reason), count in skipped.items() if label == band}
                    for band in recency.BANDS},
        'ordered': all(a['reply_priority']['key'] <= b['reply_priority']['key']
                       for a, b in zip(items, items[1:])),
    }


if __name__ == '__main__':
    print(json.dumps(publish(Path(sys.argv[1]), preview='--preview' in sys.argv[2:]), ensure_ascii=False))
