import pathlib,json,hashlib,sys,collections,copy
P=pathlib.Path(__file__).resolve().parent
B=P.parent.parent
W=B.parents[2]
sys.path.insert(0,str(W))
import mother_adapter
read=lambda p:[json.loads(l) for l in p.read_text('utf-8-sig').splitlines() if l.strip()]
source=read(B/'shard-2.jsonl')
pages=[read(P/f'reviewed-{i:02}.jsonl') for i in range(4)]
rows=[r for page in pages for r in page]
assert [len(x) for x in pages]==[180,180,180,151]
assert len(source)==len(rows)==691
by={r['review_key']:r for r in source}
assert len(by)==691 and len({r['review_key'] for r in rows})==691
assert {r['review_key'] for r in rows}==set(by)
assert len({r['comment_id'] for r in rows})==691
assert {r['comment_id'] for r in rows}=={r['comment_id'] for r in source}
quotes=0
for r in rows:
 s=by[r['review_key']]
 for k in ('review_key','comment_id','customer_uid','video_id','platform'):assert r[k]==s[k],(r['review_key'],k)
 allowed=[s['comment_text']]+([s['post_body']] if s['post_author_same_as_commenter'] else [])
 for q in r['evidence']+[t['quote'] for f in ('topics','target_regions','time_mentions','other_constraints','contact_boundaries','possible_topics') for t in r[f] if isinstance(t,dict) and 'quote' in t]:
  assert any(q in text for text in allowed),(r['review_key'],q)
  quotes+=1
 assert r['human_confirmed'] is False and r['send_authorized'] is False and r['store_assignment'] is None
 assert r['reply_plan']['preferred_mother_slot'] in (None,1,2,7,13,16,19,25,28,31,34)
 assert not any(k in r for k in ('classification_method','classification_stages_completed','classification_review_source'))
 assert not any(k in r for k in ('reply_text','mother_reply_text'))
 if r['role']=='unknown':assert r['interest']=='uncertain'
 for t in r['topics']:assert t['pool'] in ('价格预算','位置通勤','户型面积与居住方式','房内设施','宠物','楼层电梯','入住与租期','房源状态','费用合同','看房联系')
assert len([r for i in range(4) for r in read(P/f'explicit-decisions-{i:02}.jsonl')])==691
merged=''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows)
out=B/'reviewed-new-2.jsonl'
out.write_text(merged,'utf-8')
assert out.read_bytes()==b''.join((P/f'reviewed-{i:02}.jsonl').read_bytes() for i in range(4))
stage=[dict(copy.deepcopy(r),classification_method='ai_semantic_initial_and_detailed',classification_stages_completed=['initial_semantic','detailed_semantic']) for r in rows]
stagepath=P/'isolated-semantic-stages.jsonl'
stagepath.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in stage),'utf-8')
digest=hashlib.sha256(stagepath.read_bytes()).hexdigest()
cache={};validated=[]
for row in stage:
 row=copy.deepcopy(row);row['classification_review_source']={'path':str(stagepath),'sha256':digest}
 mother_adapter.validate_new_review(row,B,cache)
 validated.append(row)
(P/'isolated-adapter-preflight.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in validated),'utf-8')
result={'batch':'d13422df281e9e55','shard':2,'input_count':691,'output_count':len(rows),'review_key_set_equal':True,'comment_id_set_equal':True,'metadata_tuple_equal':True,'evidence_quotes_checked':quotes,'evidence_exact_match':True,'page_counts':[len(x) for x in pages],'page_concat_bytes_equal':True,'explicit_decision_count':691,'formal_adapter_preflight_passed':len(validated),'adapter':str(pathlib.Path(mother_adapter.__file__).resolve()),'adapter_sha256':hashlib.sha256(pathlib.Path(mother_adapter.__file__).read_bytes()).hexdigest(),'isolated_source':str(stagepath),'isolated_sha256':digest,'semantic_review_sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'roles':dict(collections.Counter(r['role'] for r in rows)),'interests':dict(collections.Counter(r['interest'] for r in rows)),'source_reads':'four full shared-post-context pages and every comment; shard metadata used for identity/evidence validation','classification':'single model initial and detailed semantic decisions; not independent secondary review','formal_compiler_binding_pending':True,'usage':'unknown','credits':'parent task states authorized; no purchase','platform_calls':0,'sent':0,'human_confirmed':False,'send_authorized':False}
(B/'shard-2-validation.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),'utf-8')
(P/'progress.json').write_text(json.dumps({'completed_pages':[0,1,2,3],'reviewed_count':691,'formal_adapter_preflight_passed':691,'metadata_and_evidence_checks':'passed','status':'complete_wait_root_independent_review','independent_review_claimed':False,'usage':'unknown'},ensure_ascii=False,indent=2),'utf-8')
report=f'''# 抖音增量第三片：文本判读与隔离核验

本片691条已逐条完成AI初筛与细筛。四页完整共享正文及每条评论均已读取，逐页结果为180、180、180、151条。每个键均有显式决定，程序仅序列化模型决定及核对身份、证据，不用关键词程序代判意向。

输入输出的review_key、comment_id、customer_uid、video_id、platform逐条一致；无缺失及重复。正式汇总与四页字节连接相等。逐字引文校验{quotes}处通过；仅来自本人原评或确为同作者的正文。

语义要点：工作地、查询参照地、现居与目标分开；D1527高德置地仅为通勤参照，身份待核。D1662现居经海路租金与换房偏好分开，找房是否继续待核。D1884已租好且无新需，保留需求者、结束、无关。D1692为本人短租合同纠纷，新住房机会未知，严肃语气，不把纠纷误当新硬条件。D2004为购买咨询，不当租赁需求。纯艾特与空评保留未知；裸多少米只保留价格/面积候选，不加入确定价格/面积主题。

明确主动求租、代找或直接询租均按评论时动作判断，不因原评论日期旧判已结束。入住与找房动作分开；D0900每月七八天是使用频次，月报价也不当总租期；D1164九月之后未给年份不强行归一。D0135个人房东与自交水电等为条件联系，不扩大为全面拒联。不会凭职业、头像、IP或来源门店补预算或目标。

回复仅有认可母句槽位的reply_plan，未写新回复正文。专项及通用母句的住户身份、优惠、资格、同店同房源适配等事实均待核。allow只说明文本未见明确联系限制，不是发送许可。

已实际调用未修改的mother_adapter.validate_new_review，对真实隔离JSONL及SHA绑定逐条预检，691条通过。分类方法和阶段仅补入隔离文件，正式评审未伪造compiler绑定。正式compiler绑定、独立复核及本地发布由主任务另行处理；本次并非独立二审、人工金标或用户认可。细筛微调前的逐页原字节保留在本片before-detailed-refinement目录；细筛修订了参照地关系、主题主体和待核说明，非冒称纯格式修正。

正式评审SHA256：{result['semantic_review_sha256']}
隔离语义源SHA256：{digest}

实际usage未知，不用任务数或账户余额推算费用。无平台调用、源库修改或发送；human_confirmed=false、send_authorized=false、store_assignment=null。仅写本片范围，完成停止，等待主任务独立复核。
'''
(B/'shard-2-report.md').write_text(report,'utf-8')
print(json.dumps(result,ensure_ascii=False,indent=2))
