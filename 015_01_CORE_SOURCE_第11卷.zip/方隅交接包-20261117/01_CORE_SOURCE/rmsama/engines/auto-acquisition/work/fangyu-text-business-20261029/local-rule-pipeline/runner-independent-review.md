# 本地增量协调器独立审查

当前结论：**Fix1 定向复审通过**。原三项 Important 均为 **ADDRESSED**；本轮指定修复范围内未发现新增 Critical/Important。下面先记录 Fix1 复审，后面保留初审基线和原反例，避免把历史缺陷误当成当前开放项。本报告不设置或替代整体 verified 验收门。

## Fix1 定向复审（冻结代码）

已核对与主任务提供的冻结 SHA 完全相同：

- run_local_pipeline.py：`debb6b1e7b814d322b9e08b1d497d29da976d78726cf47ba7566276124f7629f`。
- test_local_pipeline.py：`99dfce30360b37441e552dfab64927d3ff9c1f6f27e2a7efac1db4445565dba5`。

读取 runner-implementation-report.json 的修复和红绿记录；作者报告协调器 16 项、与核心合计 55 项通过，这些结果属于作者验证，本次未重复执行。独立复审只重跑既有 runner-review-probes.py 的三个反例，并追加已要求的 source-db 本身导出冲突探针。为兼容修复后的零候选结果，仅将历史探针改为允许查询不到候选；原始输入、预期边界和另外两个反例保持不变。初审结果 runner-review-probe-results.json 保留，复审结果另存 runner-review-probe-fix1-results.json。

| 原问题 | 状态 | 修复代码与独立结果 |
| --- | --- | --- |
| I1 历史候选绕过认可及需求边界 | **ADDRESSED** | :118-126 的共用资格函数用于 :198-201 的历史导入及 :455 的新增结果；:137-140 保留历史母句参考并先停用当前别名。原供给/结束/无关且未认可旧句探针当前候选数为 0、没有候选文本。作者新增测试逐项拆开供给/结束/无关/未认可，并有有效正例；本次只读核对测试，不重复运行。 |
| I2 审计后当前 draft 别名仍有效 | **ADDRESSED** | :113-116 共用停用函数覆盖 mother_slot/mother_reply_text/draft_ready/draft_text/slot；:335-340 冲突导出调用同一函数。独立结果 audit_count=1、active_candidate_count=0、draft_ready=false、draft_text=null、mother_reply_text=null；旧版本增量仍保留，符合留史要求。 |
| I3 JSON `[]` 阻塞后续正常评论 | **ADDRESSED** | :283-285 在取字段前检查根对象，错误形状转来源异常；同一 `comment:a=[]`、后续 `comment:z` 探针连续运行两次均无异常，最终 results=2。此次判定针对原根形状反例及其后续不阻塞行为，不扩大为任意损坏字段均已验证。 |

附加保护：:407-412 将实际 source_db 路径纳入导出保护集合。隔离探针将 export_all 指向 source.sqlite3，得到明确 ValueError，前后 SHA 相同；历史 JSONL 同路径导出也被拒绝且 SHA 不变。这是固定隔离源的证据。活源库可能被其他采集进程改变，本次不以它的物理 SHA 漂移归因于协调器写源。

修复相关联的定向质量检查：同客户去重仍保留 INSERT OR IGNORE；重复/无效候选现在先统一清空别名，历史原文件只读且母句保留于历史参考字段。原始正常候选正例在晚审计探针第一轮仍然存在，后续冲突才停用，没有出现“修复使全部新候选消失”的破坏。源异常路径依旧零模型、无发送授权。没有修改分类器、源码或 manifest。

**Fix1 verdict：三项原 Important 关闭；可交主任务继续其余整体验收。** 未执行百万性能、人工语义金标或平台回执验收，不据本定向复审宣称这些事项完成。

---

## 初审基线（以下问题描述属于修复前版本）

初审结论为 With fixes（0 Critical、3 Important），针对下文所列 `674bf80...` 版本。以下行号与探针结果仅为历史基线，不指向 Fix1 冻结代码。

## 审查对象与边界

- 已读取 SPEC.md、PLAN.md、原 runner-review-package.diff，并以实际最新源码为准。原 diff 只有初版 430 行 runner，不代表本次被审代码。
- 本轮固定核对的 run_local_pipeline.py：499 行，SHA256 `674bf80bf8dbd574dcd34e20024c76ca2d305e710c4690490774e0de85f66f91`。
- test_local_pipeline.py：13 项测试，SHA256 `bb0aebe71d54d31840baab797c96a7ef4a11e303da54acdd2ca43d6d5d8c8c97`。
- 未重跑作者已报告的测试；独立运行 runner-review-probes.py 的新隔离反例。证据为 runner-review-probe-results.json。仅使用本目录下临时构造的 SQLite，未访问平台、读取凭据、写采集源库或发送；未修改源码、验收 manifest 或分类器语义。
- 审查过程中作者增补了输出路径保护和冲突导出覆盖。以下结论已基于增补版复核，已修复的疑点不作为开放问题。

## 已确认的优点

- 源连接 `mode=ro`、`query_only=ON`，独立派生 SQLite，无 ATTACH；新增保护拒绝源/派生数据库同路径以及 export-all 覆盖当前历史输入等受保护文件。
- 每轮从所有 parsed attempts 更新资格，不以 attempts rowid 游标决定资格；unknown 原位变 parsed 的来源可再次进入。手选来源校对账号，普通来源要求结构化 eligible；资格 join 同时校对 target 和账号。
- 结果、作品缓存、观察及候选均按平台分区，候选按平台和客户 UID 唯一；未知 UID 不生成候选，不按相似措辞共享具体预算、日期或地区。输入摘要包括所用正文和观察摘要。
- 旧模型原文件不改写，派生结果记录 historical_model_reference；不存在用旧模型一致率宣称准确率的文案。
- Python 每轮最多 5000 个 key，单条观察最多保留 100 个展示项；历史 JSONL、观察和输出按流处理，分类结果与候选处于同一派生事务。已提交 run 保留待导出状态，可在输出异常后补导出，避免重新分类。
- 协调器未导入网络、平台或模型客户端；当前分类器接口也是本地实现，强制零模型调用和无发送授权。正式默认源受 verified manifest 门控。
- 初次源冲突进入独立来源异常；后续合格观察与历史身份摘要不一致时，保留原判断另记审计，当前活跃候选统计会暂停相应客户。

## Important（必须修复后接续）

### I1：历史母句绕过当前认可与需求状态校验，直接占据活跃候选

位置：`run_local_pipeline.py:178-180`，调用 `store_result` 的候选写入点 `:122-134`。

复现：历史 JSONL 一条记录带 `role=supply`、`demand_state=ended`、`interest_at_comment=unrelated`、`customer_uid=u`，母句为当前 mothers 中完全不存在的文本。空白派生库导入后，`local_mother_drafts=1`，candidates.data 中保留该未认可旧句。独立探针 `historical_unapproved_candidate` 已确认。

原因与影响：新判断路径在 :433-438 校验需求状态与 user_approved 固定母句，但历史导入完全绕过此处。保留旧初判及旧草稿作为历史参考是正确的；将旧草稿同时加入本轮活跃候选，会使供给/已结束记录被算成可备稿客户，并以唯一键阻止同客户的新合格评论进入当前候选。无发送授权并不能消除当前候选错误。

建议：历史原结果原样保留为参考；历史候选独立标记/隔离，不占当前候选唯一键。若确需延续旧候选，也必须先按当前认可母库和现有分类字段执行相同边界校验，不重新分类旧条目。

### I2：冲突后的完整导出仅清除一个文案字段，仍声称草稿已就绪

位置：`run_local_pipeline.py:313-318`（export_complete）。

复现：按正常选择器契约生成候选，具有 `draft_ready=true`、`draft_text=认可母句` 和 `mother_reply_text=认可母句`。再加入同 stable_key 的合格异作者观察，运行 `--export-all`。汇总正确显示 `source_integrity_audits=1`、活跃候选 0，导出也清掉 mother_reply_text，但 **draft_ready 仍 true、draft_text 仍为原母句**。独立探针 `late_audit_current_export` 已确认。

原因与影响：实际 LocalClassifier.choose_mother 正常返回 draft_ready/draft_text（不仅是测试桩字段）。当前导出因此同时表示“来源冲突暂停”与“草稿已就绪”。使用稳定完整导出的人工工具或后续软件若遵循公开 draft_* 字段，会继续展示或选中已暂停草稿。

建议：当前导出覆盖层统一清除所有当前候选别名（至少 draft_ready=false、draft_text=null、mother_reply_text=null；同步候选 slot/status 等），保留历史原文另存参考字段。无需重写不可变历史结果或旧增量文件。

### I3：合法 JSON 的错误数据形状成为永久阻塞记录

位置：`run_local_pipeline.py:262-265`；同函数 `:291` 也假定 text 为字符串。

复现：测试源合格评论 `comment:a` 的 entities.data 为合法 JSON `[]`；后面还有完全正常的 `comment:z`。连续运行两次，均为 `AttributeError: 'list' object has no attribute 'get'`，两次后 results 数仍 0，正常 z 永远不能被处理。独立探针 `malformed_source_poison_record` 已确认。

原因与影响：只捕获 JSON 解码错误，没有在 .get 前验证根对象形状；顶层 null/数字及非字符串 text 也有同类风险。这绕过已设计的 source_error/source_exception 路径。由于 keys 每轮稳定排序，重跑会不断撞到同一条坏数据，失去“异常留审计、其他评论继续”的本地增量能力。

建议：源实体先做最小结构验证，错误转成可持久化的 source_integrity 异常并保留稳定 key，避免调用分类器；验证 text 的字符串类型再摘要。不要用宽泛吞异常掩盖分类器自身故障。

## 新增独立反例结果

运行命令：`python work/fangyu-text-business-20261029/local-rule-pipeline/runner-review-probes.py`。

| 反例 | 观察结果 |
| --- | --- |
| 供给/结束历史条目及未认可母句 | 当前候选计数 1，确认 I1 |
| 后续异作者观察 + 完整导出 | 活跃候选 0，但 draft_ready=true 且 draft_text 保留，确认 I2 |
| export-all 与历史 JSONL 相同路径 | ValueError 拒绝，原文件 SHA 不变，保护有效 |
| 错误根形状 + 后续正常评论，重跑两次 | 同样 AttributeError，两次后正常结果数 0，确认 I3 |

## 未作结论的范围

- 分类器的具体租赁语义、词库准确性、业务边界是否全部正确：另一个封版审查范围，本次仅审接口及协调器防护。
- 百万条实际时间与峰值内存：代码结构符合有界处理方向，本次未重复执行性能压测，不能据静态审查宣称百万性能验收。
- 实际平台采集、账号身份与真实发送回执：本任务明确不访问；没有对此作验收声明。
- 200 条旧模型对照及准确率：没有人工 gold；未读取冻结 holdout 来调词，未把一致性当准确率。
- 原始账本实体缓存默认追加不变的契约：已核对现有 ledger._observe 使用 INSERT OR IGNORE；不为任意外部直接修改现有行另行设计迁移机制。
- 旧增量文件仍留存原草稿：规格要求保留旧版本，本身不作为缺陷；I2 仅针对明确称为当前完整导出的字段安全。
- manifest 的 verified 标记：属于主验收负责人，本次未设置或认可。

最终判断：协调器主体方案符合本地零模型、只读源、保留历史及增量幂等方向。上述 3 项有隔离复现，应先修复并针对反例核对，再由主任务完成整体验收门；本报告不等于内容准确率或生产平台验收。
