import unittest,tempfile,pathlib,hashlib,json
import activate_text_candidate as a
class Gate(unittest.TestCase):
 def test_missing_gate_refused(self):
  with self.assertRaises(ValueError):a.validate_gate_record(None,'v2','contract','plans')
 def test_old_gate_or_wrong_sha_refused(self):
  for g in ({'status':'technical_pass','reviewer_model':'gpt-6-astra','source_repairs_v2_READY_SHA':'v2'}, {'status':'pass','reviewer_model':'gpt-6-astra','source_repairs_v2_READY_SHA':'old','source_contract_SHA':'contract','source_merged_plans_SHA':'plans'}):
   with self.assertRaises(ValueError):a.validate_gate_record(g,'v2','contract','plans')
 def test_semantic_gate_wrong_artifact_and_wrong_file_hash_refused(self):
  g={'status':'pass','reviewer_model':'gpt-6-astra','source_repairs_v2_READY_SHA':'v2','source_contract_SHA':'contract','source_merged_plans_SHA':'wrong','review_scope':'bounded_template_version_not_individual_approval','files_sha256':{'report.md':'x'}}
  with self.assertRaises(ValueError):a.validate_gate_record(g,'v2','contract','plans')
  with self.assertRaises(ValueError):a.check_gate(pathlib.Path(__file__),'0'*64,'plans')
 def test_send_flags_refused(self):
  with self.assertRaises(ValueError):a.validate_flags({'send_authorized':True,'can_send_now':False})
 def test_pointer_cas_and_rollback(self):
  with tempfile.TemporaryDirectory(dir=pathlib.Path(__file__).parent) as d:
   p=pathlib.Path(d);x=p/'region.json';y=p/'reply.json';x.write_bytes(b'old-a');y.write_bytes(b'old-b');h=lambda b:hashlib.sha256(b).hexdigest()
   with self.assertRaises(ValueError):a.check_previous(x,y,'wrong',h(b'old-b'))
   a.swap_pair(x,y,b'old-a',b'old-b',b'new-a',b'new-b');self.assertEqual(x.read_bytes(),b'new-a');a.swap_pair(x,y,b'new-a',b'new-b',b'old-a',b'old-b');self.assertEqual((x.read_bytes(),y.read_bytes()),(b'old-a',b'old-b'))
if __name__=='__main__':unittest.main()
