from collections import Counter
from datetime import datetime, timedelta, timezone
import tempfile
from pathlib import Path
import unittest
import publish_douyin_send_queue as queue


class QueueAdmission(unittest.TestCase):
    def row(self, days):
        draft = '宝宝，我住方隅，你想找哪边的呀？我介绍有优惠。'
        row = dict(platform='douyin', comment_id='123', customer_uid='456', video_id='789',
                   comment_text='什么位置', role='demand', interest_at_comment='high',
                   published_at=(datetime.now(timezone.utc)-timedelta(days=days)).isoformat(),
                   pending_candidate=True, commercial_fit={'eligible_candidate': True},
                   reply={'draft_text': draft}, reply_body_sha256=queue.sha(draft.encode()))
        row['reply_priority'] = queue.recency.douyin_reply_priority(row)
        return row

    def test_expired_frozen_candidate_not_requeued(self):
        row = self.row(30.01)
        skipped = Counter()
        with tempfile.TemporaryDirectory() as temp:
            result = list(queue.ordered_items([row], {'123': row}, set(), set(), {}, Path(temp), skipped))
        self.assertEqual(result, [])
        self.assertEqual(sum(skipped.values()), 1)

    def test_current_candidate_preserves_original_mother_reply(self):
        row = self.row(1)
        with tempfile.TemporaryDirectory() as temp:
            result = list(queue.ordered_items([row], {'123': row}, set(), set(), {}, Path(temp)))
        self.assertEqual(len(result), 1)
        self.assertEqual(result[0]['draft'], row['reply']['draft_text'])


if __name__ == '__main__':
    unittest.main()
