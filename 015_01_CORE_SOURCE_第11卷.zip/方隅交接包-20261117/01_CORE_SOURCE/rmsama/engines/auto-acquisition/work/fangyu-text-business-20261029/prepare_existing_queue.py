"""Text-only next-word proposal drawn exactly from the pre-existing 46 words."""
import pathlib,json,csv,hashlib
ROOT=pathlib.Path(__file__).resolve().parents[2];W=pathlib.Path(__file__).resolve().parent
source=ROOT/'outputs/古北店获客体系/首轮搜索词.txt';allowed=[x.strip() for x in source.read_text(encoding='utf-8-sig').splitlines() if x.strip()]
assert len(allowed)==46
nextwords=['红松东路租房','姚虹路租房','金虹桥公寓出租','古北服务公寓','古北一居室','古北财富中心附近租房','古北国际财富中心实习租房','漕河泾上班租房','古北企业租房','古北行政找房','古北员工住宿','古北宠物友好公寓','姚虹路带猫租房','古北带保洁公寓','古北家具齐全公寓','上海高岛屋附近租房','1699商业广场附近租房','漕河泾印象城附近公寓','古北方隅还有空房吗','红松东路1000号月租','城方璟辰附近替代公寓','古北馨乐庭公寓怎么选','上海佰舍田林租房对比','Gubei apartment for rent','Shanghai Gubei monthly rental','Caohejing serviced apartment','Gubei corporate housing','古北月租公寓']
assert len(set(nextwords))==28 and set(nextwords)<=set(allowed)
deferred=[x for x in allowed if x not in nextwords and x not in ['古北租房','古北求租']]
out=ROOT/'outputs/方隅双平台文本业务/门店词库';out.mkdir(parents=True,exist_ok=True)
rows=[]
for n,k in enumerate(nextwords,1):rows.append({'order':n,'keyword':k,'source_set':'existing_46','status':'existing_authorized_word_queue','resume_from_verified_ledger':True,'default_start_page_if_never_searched':1,'initial_pages_if_never_searched':[1,2,3],'hard_page_limit':None,'existing_task_untouched':True,'note':'当前3词队列继续原断点；此词若已采，按可信游标续，不重刷已完成页；3页不是停止线'})
package={'version':'gubei-existing46-continuation-20261029-v1','scope':'text-only queue; execution governed by existing human authorization','source':str(source),'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'do_not_enable_new3000':True,'current_keywords_preserve':['古北找房','古北求租','古北租房'],'current_ranges_from_cli_handoff':{'古北找房':[5,8],'古北求租':[9,14],'古北租房':[11,16]},'keywords':rows,'deferred_old_words':deferred,'deferred_reason':'明确短租/过渡/探亲等词不纳入本次长租优先接续；保留原库，不宣称删除或其他租期一概不接','stop_conditions':['本人要求暂停','账号不可用/验证/限流/接口故障','关键词结果确已耗尽；换下一个已授权词而非宣布整体完成'],'customer_geo_policy':'本人求租地区优先，IP辅助；搜索来源不等于归属店','send_authorized':False}
(W/'gubei-existing46-next.json').write_text(json.dumps(package,ensure_ascii=False,indent=2),encoding='utf8')
with (out/'古北原46词长租接续清单.csv').open('w',encoding='utf-8-sig',newline='') as f:
 c=csv.writer(f);c.writerow(['接续顺序','搜索词','来源','起始页与接续','启动页建议','后续处理','备注'])
 for r in rows:c.writerow([r['order'],r['keyword'],'原有46词内','已有可信断点优先；未搜才从1开始','1、2、3页','继续实际后续结果，三页不是停止线','不启用新3000候选；客户地区另核'])
(out/'古北接续使用说明.md').write_text('# 古北原46词长租接续\n\n本清单选出原有46词中的28个词，不添加新3000候选。当前古北找房、古北求租、古北租房沿既有断点与本人授权继续，不用此文件覆盖正在运行的队列。\n\n当前队列到预设页数后不代表任务完成。下一词先核台账；有断点续断点，未搜从第一页起步，首3页只是启动建议，仍按实际新结果继续。结果耗尽换下一已授权词，验证码、会话失效或限流按执行窗口规则停止处理，不绕过或重复空刷。\n\n公开区域、竞品或上班地点只帮助找帖子，不等于评论者想住该区域；本人求租地区优先，IP辅助；缺失保留待核。明确短租/过渡/探亲词暂不放本次长租优先清单，原词库保留。此处只是文本接续，不启动或停止进程，不发送。\n',encoding='utf8')
print(json.dumps({'next_words':len(rows),'all_from_existing46':True,'new3000_enabled':False,'csv':str(out/'古北原46词长租接续清单.csv')},ensure_ascii=False))
