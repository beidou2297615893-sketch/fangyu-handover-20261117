import unittest
from classifier import classify,cache_key,reusable_review,classify_with_cache,context_key

class ClassifierTests(unittest.TestCase):
 def row(self,text,**kw):
  return {'platform':'douyin','comment_id':'1','comment_text':text,'role':'demand','interest_at_comment':'high',**kw}
 def test_money_slang(self):
  self.assertIn('价格预算',classify(self.row('dd 多少米'))['pools'])
  self.assertIn('看房联系',classify(self.row('dd 多少米'))['pools'])
 def test_distance_not_money(self):
  for text in ['离地铁多少米','走多少米','步行几米','房间宽几米','面积多少平米']:
   self.assertNotIn('价格预算',classify(self.row(text))['pools'],text)
 def test_contact_not_high(self):
  r=classify({'comment_text':'滴滴','platform':'douyin','comment_id':'x','interest_at_comment':'uncertain'})
  self.assertEqual(r['original_intent'],'uncertain')
  self.assertIn('看房联系',r['pools'])
 def test_quote_spans(self):
  text='不合租，要整租，七月底入住，dd 多少米'
  for e in classify(self.row(text))['evidence']:
   self.assertEqual(text[e['start']:e['end']],e['quote'])
 def test_dd_not_transport(self):
  self.assertNotIn('看房联系',classify(self.row('滴滴打车上班'))['pools'])
 def test_have_not_negative(self):
  r=classify(self.row('有没有月租的'))
  self.assertEqual(r['constraints']['negative_spans'],[])
 def test_no_is_not_negative(self):
  self.assertEqual(classify(self.row('有无套一'))['constraints']['negative_spans'],[])
 def test_negative_local(self):
  r=classify(self.row('不合租，要整租'))
  self.assertTrue(any(e.get('subtag')=='合租' and e.get('polarity')=='excluded' for e in r['evidence']))
  self.assertFalse(any(e.get('subtag')=='整租' and e.get('polarity')=='excluded' for e in r['evidence']))
 def test_preserve_old(self):
  r=classify(self.row('求租一居室',demand_pools=['户型面积与居住方式']))
  self.assertEqual(r['classification_method'],'existing_AI_reused');self.assertFalse(r['needs_AI'])
 def test_choice(self):
  r=classify(self.row('浦东或者奉贤有没'))
  self.assertEqual(r['constraints']['choice_relation'],'alternative')
  self.assertIn('位置通勤',r['pools'])
 def test_unknown_fact_does_not_hold(self):
  self.assertFalse(classify(self.row('这个房租多少'))['needs_AI'])
 def test_chinese_month(self):
  self.assertIn('七月底',classify(self.row('七月底换房子'))['constraints']['explicit_time_strings'])
 def test_qualification(self):
  self.assertIn('户型面积与居住方式',classify(self.row('新疆人可以住吗'))['pools'])
 def test_cache_context(self):
  a=self.row('可以养猫吗',original_classification={'post_body':'北京租房','video_id':'1'})
  b=self.row('可以养猫吗',original_classification={'post_body':'上海租房','video_id':'2'})
  self.assertNotEqual(cache_key(a),cache_key(b))
 def test_cache_negation(self):
  self.assertNotEqual(cache_key(self.row('可以养猫')),cache_key(self.row('不可以养猫')))
 def test_no_generic_pool(self):
  self.assertTrue(classify(self.row('嗯'))['needs_AI'])
 def test_dont_change_intent(self):
  r=classify(self.row('我出租一室',interest_at_comment='low'))
  self.assertEqual(r['original_intent'],'low')
 def cached(self):
  r=self.row('我可以',original_classification={'post_body':'北京公寓出租','video_id':'v1','post_author_same_as_commenter':False})
  review={('douyin','1'):{'text':'我可以','context_key':context_key(r),'pools':['房源状态'],'subtags':['求租兴趣'],'reason':'本条出租语境的接受表达','review_id':'review-1'}}
  return r,classify(r,review)
 def test_new_cid_cache_reuse(self):
  r,cached=self.cached();r['comment_id']='2';r['interest_at_comment']='uncertain'
  out=classify_with_cache(r,[cached])
  self.assertEqual(out['classification_method'],'AI_cache_reused')
  self.assertEqual(out['original_intent'],'uncertain')
  self.assertEqual(out['cache_reference']['cid'],'1')
 def test_negation_cache_miss(self):
  r,cached=self.cached();r['comment_id']='2';r['comment_text']='我不可以'
  out=classify_with_cache(r,[cached]);self.assertTrue(out['needs_AI'])
  self.assertFalse(out['ai_review_request']['reply_generation_requested'])
 def test_changed_post_cache_miss(self):
  r,cached=self.cached();r['original_classification']['video_id']='v2'
  self.assertTrue(classify_with_cache(r,[cached])['needs_AI'])
 def test_channel_query_not_address(self):
  for text in ['个人转租在哪看','哪里找房源','用什么app找房']:
   out=classify(self.row(text,demand_pools=['看房联系']))
   self.assertIn('看房联系',out['pools'])
   self.assertNotIn('位置通勤',out['pools'],text)
   self.assertIn('找房渠道',out['subtags'])
  # Explicit district still matters even when the question also asks for a channel.
  self.assertIn('位置通勤',classify(self.row('浦东哪里找房源'))['pools'])
 def test_flexible_term_alias(self):
  out=classify(self.row('租几个月行吗'))
  self.assertIn('入住与租期',out['pools'])
  self.assertIn('租期灵活',out['subtags'])
 def test_long_interrogative_not_sliced_negation(self):
  out=classify(self.row('有没有短租一个月两个月那种，最近想租'))
  self.assertEqual(out['constraints']['negative_spans'],[])
  self.assertIn('入住与租期',out['pools'])
 def test_true_negation_survives_question_mask(self):
  for text,subtag in [('没有厨房','厨房'),('不需要厨房','厨房'),('有没有不合租的','合租')]:
   out=classify(self.row(text))
   self.assertTrue(any(e.get('subtag')==subtag and e.get('polarity')=='excluded' for e in out['evidence']),text)
 def test_cache_version_mismatch(self):
  r,cached=self.cached();cached['version']='old-schema'
  self.assertTrue(classify_with_cache(r,[cached])['needs_AI'])

if __name__=='__main__':unittest.main()
