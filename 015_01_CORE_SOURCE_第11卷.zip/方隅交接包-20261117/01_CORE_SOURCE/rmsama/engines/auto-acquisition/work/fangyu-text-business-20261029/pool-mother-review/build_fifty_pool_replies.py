"""Render the same 50 genuine comments through reusable pool mother variants.
No per-comment model request; original published judgments and old drafts preserved.
"""
from pathlib import Path
import csv,json,hashlib,datetime,re
HERE=Path(__file__).resolve().parent;W=HERE.parent;ROOT=W.parents[1]
OUT=ROOT/'outputs/方隅双平台文本业务/地区归类与品牌母句'
source=OUT/'首批50条真实评论与已配回复.csv'
with source.open(encoding='utf-8-sig',newline='') as f: original=list(csv.DictReader(f))
assert len(original)==50
receipt_path=W/'region-brand-routing/reply-example-selection-receipt.json'
source_receipt=json.loads(receipt_path.read_text(encoding='utf-8'))
assert len(source_receipt['selected'])==50
# Pool-level review variants of the approved tone. These are not new verified housing facts.
families={
 'budget_low':(1,'价格预算','宝宝，想找便宜点的话，可以看看方隅公寓，我住这边，介绍有优惠的。'),
 'area':(31,'位置通勤','宝宝，我住方隅公寓这边，你要找{place}的话，可以先看看位置合不合适，介绍有优惠的。'),
 'occupants':(7,'户型面积与居住方式','宝宝，你们{count}个人一起住的话，我可以帮你问问合适的房型。我住方隅公寓这边，介绍有优惠的。'),
 'requirements':(34,'多池组合','宝宝，我住方隅公寓这边，{requirements}我帮你一起问清楚，介绍有优惠的。'),
 'pet':(13,'宠物','宝宝，我住方隅公寓这边，{pet_question}我帮你问问能不能带，介绍有优惠的。'),
 'elevator':(16,'楼层电梯','宝宝，我住方隅公寓这边，有没有电梯我帮你确认一下，介绍有优惠的。'),
 'floor':(16,'楼层电梯','宝宝，我住方隅公寓这边，具体哪层、有没有电梯，我帮你一起问下，介绍有优惠的。'),
 'monthly':(19,'入住与租期','宝宝，我住方隅公寓这边，你想按月租多久呀？我帮你问问租期，介绍有优惠的。'),
 'urgent':(19,'房源状态','宝宝，你急着找房的话，我先帮你问问方隅公寓现在的空房和最早入住时间。我住这边，介绍有优惠的。'),
 'available':(28,'房源状态','宝宝，我住方隅公寓这边，现在还有哪些空房我帮你问问，介绍有优惠的。'),
 'rent_process':(28,'费用合同、看房联系','宝宝，我住方隅公寓这边，可以帮你对接问问房型、租金和押付方式，合适再约看，介绍有优惠的。'),
 'contact':(28,'看房联系','宝宝，可以聊呀，我住方隅公寓这边，可以帮你对接了解，介绍有优惠的。'),
 'contact_how':(28,'看房联系','宝宝，你可以点我聊聊，我住方隅公寓这边，可以帮你对接了解，介绍有优惠的。'),
 'room_price_location':(31,'价格预算、位置通勤、户型面积与居住方式','宝宝，我住方隅公寓这边，{room}的租金和位置我帮你一起问问，介绍有优惠的。'),
 'all_in_budget':(34,'价格预算、费用合同、位置通勤','宝宝，你是说房租、水电气加起来{budget}，对吗？我住方隅公寓这边，介绍有优惠的，我按总预算帮你问问{place}附近的。'),
 'price_location':(31,'价格预算、位置通勤','宝宝，我住方隅公寓这边，可以把位置给你看看，具体租金我帮你问清楚，介绍有优惠的。'),
 'area_room':(34,'位置通勤、户型面积与居住方式','宝宝，你想找{place}的{room}，我帮你问问方隅公寓有没有合适的。我住这边，介绍有优惠的。'),
 'unknown_room_location':(7,'位置通勤、户型面积与居住方式','宝宝，我住方隅公寓这边，可以帮你问问{room}，再把位置给你看看，介绍有优惠的。'),
 'relocation':(31,'价格预算、位置通勤','宝宝，公司搬到{place}后，你想住附近还是通勤过去呀？我住方隅公寓这边，租金我帮你问问，介绍有优惠的。'),
 'weak_wish':(7,'合租语境待确认','宝宝，你也在考虑合租吗？我住方隅公寓这边，可以给你看看房型。'),
 'location':(31,'位置通勤','宝宝，我住方隅公寓这边，可以把位置给你看看，介绍有优惠的。'),
 'budget_two_places':(34,'价格预算、位置通勤、户型面积与居住方式','宝宝，我住方隅公寓这边，你说的{budget}、{room}我帮你问问。{place_a}和{place_b}你是两边都考虑吗？介绍有优惠的。'),
 'line':(31,'位置通勤','宝宝，我住方隅公寓这边，可以把位置给你看看，你看去{line}方不方便，介绍有优惠的。'),
 'living_mode':(7,'户型面积与居住方式','宝宝，我住方隅公寓这边，你想找自己独立住的，还是也考虑合租呀？介绍有优惠的。'),
 'move_in':(19,'入住与租期','宝宝，{when}起租也可以看看方隅公寓，我住这边，具体房态和租期我帮你问问，介绍有优惠的。'),
 'utilities':(25,'费用合同','宝宝，我住方隅公寓这边，是不是民水民电、具体怎么收费，我帮你问清楚，介绍有优惠的。'),
 'pet_cat':(13,'宠物','宝宝，我住方隅公寓这边，猫猫能不能带、有没有额外费用，我帮你确认一下，介绍有优惠的。'),
 'place_clarify':(31,'位置通勤、地名待确认','宝宝，你说的“{raw_place}”是{possible_place}吗？我住方隅公寓这边，介绍有优惠的。'),
 'share_budget':(7,'户型面积与居住方式、位置通勤','宝宝，你们两个人合租，总预算大概多少呀？我住方隅公寓这边，介绍有优惠的。'),
 'price':(1,'价格预算','宝宝，我住方隅公寓这边，具体租金我帮你问问，介绍有优惠的。')
}
plan=[
 ('budget_low',{}),('area',{'place':'凤凰山体育广场附近'}),('occupants',{'count':'三'}),
 ('requirements',{'requirements':'乔司的一居室、民水民电，还有明厨明卫和油烟隔离这几样'}),
 ('pet',{'pet_question':'你家狗狗多大呀？'}),('elevator',{}),('monthly',{}),('urgent',{}),('rent_process',{}),('contact',{}),
 ('area',{'place':'航天城附近'}),('room_price_location',{'room':'两室'}),
 ('all_in_budget',{'place':'世纪城、海昌路、中和','budget':'不超过1000'}),('price_location',{}),('price_location',{}),
 ('area_room',{'place':'滨江长河','room':'单间'}),('unknown_room_location',{'room':'单间'}),
 ('area_room',{'place':'拱墅区万达附近','room':'两室一厅'}),('relocation',{'place':'奉贤'}),
 ('room_price_location',{'room':'两室'}),('available',{}),('weak_wish',{}),('available',{}),('available',{}),('location',{}),
 ('budget_two_places',{'budget':'1350—1700','room':'一室一厅','place_a':'浦江','place_b':'静安'}),('line',{'line':'11号线'}),('living_mode',{}),
 ('requirements',{'requirements':'卫生间不在阳台这点'}),('pet_cat',{}),('floor',{}),
 ('move_in',{'when':'12月'}),('available',{}),('utilities',{}),('contact_how',{}),('area',{'place':'浦东'}),('price_location',{}),
 ('place_clarify',{'raw_place':'普伽区','possible_place':'普陀区'}),('area',{'place':'长宁'}),('share_budget',{}),
 ('area',{'place':'嘉定安亭'}),('area',{'place':'嘉定'}),('price_location',{}),('area',{'place':'徐汇'}),('area',{'place':'杨浦'}),
 ('location',{}),('area',{'place':'宜山路附近'}),('available',{}),('available',{}),('price',{})
]
assert len(plan)==50
records=[]
for n,(r,(family,fill)),identity in zip(range(1,51),zip(original,plan),source_receipt['selected']):
    comment=r['客户原评论'];assert hashlib.sha256(comment.encode()).hexdigest()==identity['comment_sha256']
    slot,pool,template=families[family];reply=template.format(**fill)
    pool=r['需求池'] or pool
    pool={4:'位置通勤、户型面积与居住方式、房内设施、费用合同',13:'价格预算、位置通勤（房租水电气总预算）',22:'合租意向待确认',38:'位置通勤（地名待确认）',47:'位置通勤、房源状态'}.get(n,pool)
    assert '方隅公寓' in reply and not re.search(r'【|\{[^}]*\}',reply)
    assert not any(t in reply for t in ['肯定有','一定能住','可以带狗','可以养猫','我们有电梯','都能满足'])
    records.append({'platform':identity['platform'],'comment_id':identity['comment_id'],'customer_uid':identity['customer_uid'],'display_order':n,'comment_text':comment,'comment_sha256':identity['comment_sha256'],'original_pools':r['需求池'],'display_pool':pool,'parent_approved_mother_slot':slot,'family':family,'local_fill':fill,'reply_text':reply,'reply_sha256':hashlib.sha256(reply.encode()).hexdigest(),'approval_status':'batch_micro_adjustment_for_user_review_not_individual_approval','source_status':'same_real_fifty_not_reselected','model_calls_for_reply_rendering':0,'send_authorized':False,'notes':['确认/对接措辞是拟回复中的后续动作，不冒充本窗口已核实或已联系']})
assert len({(r['platform'],r['comment_id']) for r in records})==50
HERE.mkdir(parents=True,exist_ok=True)
(HERE/'pool-mother-variants.json').write_text(json.dumps({'status':'derived_review_variants','authority':'user_correction_pool_selection_and_local_micro_adjustment','families':{k:{'parent_slot':v[0],'pool':v[1],'template':v[2]} for k,v in families.items()}},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
(HERE/'fifty-review-v2.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in records),encoding='utf-8')
lines=['# 首批50条真实评论与按池微调回复','', '沿用上次同50条原评论。按分类池选母句，再填评论中的地点、户型、预算、时间及需要确认的问题；同类问题可用同句。以下是本轮审阅稿，尚未发送。','']
for platform,title in [('douyin','抖音：1—25'),('xiaohongshu','小红书：26—50')]:
    lines += ['## '+title,'','| 序号 | 真实原评论 | 分类池 | 按池微调回复 |','|---:|---|---|---|']
    for r in records:
        if r['platform']==platform:
            escape=lambda s:s.replace('|','\\|').replace('\n','<br>')
            lines.append('| '+str(r['display_order'])+' | '+escape(r['comment_text'])+' | '+escape(r['display_pool'])+' | '+escape(r['reply_text'])+' |')
    lines.append('')
(OUT/'首批50条真实评论与按池微调回复.md').write_text('\n'.join(lines),encoding='utf-8')
with (OUT/'首批50条真实评论与按池微调回复.csv').open('w',encoding='utf-8-sig',newline='') as f:
    w=csv.writer(f);w.writerow(['平台','客户原评论','分类池','按池微调回复'])
    for r in records:w.writerow(['抖音' if r['platform']=='douyin' else '小红书',r['comment_text'],r['display_pool'],r['reply_text']])
check={'records':50,'same_original_comment_hashes':True,'platform_counts':{p:sum(r['platform']==p for r in records) for p in ['douyin','xiaohongshu']},'reusable_mother_families_used':len({r['family'] for r in records}),'distinct_reply_texts':len({r['reply_text'] for r in records}),'reply_rendering_model_calls':0,'all_customer_values_from_comment_except_explicit_clarification':True,'original_batch_overwritten':False,'production_full_corpus_replaced':False,'new_batch_individually_user_approved':False,'send_authorized':False,'source_csv_sha256':hashlib.sha256(source.read_bytes()).hexdigest()}
(HERE/'validation.json').write_text(json.dumps(check,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(check,ensure_ascii=False))
print('\n'.join(lines))
