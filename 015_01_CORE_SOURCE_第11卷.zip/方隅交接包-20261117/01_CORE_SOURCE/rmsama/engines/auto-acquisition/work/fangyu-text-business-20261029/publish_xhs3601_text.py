"""Publish local XHS classification and mother-sentence results; never collect or send."""
import json,hashlib,collections,re
from pathlib import Path
R=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent;D=W/'xhs-increment-846';P=W/'delivery-v2/cli-readonly-bundle'
def jl(p):return [json.loads(s) for s in p.read_text(encoding='utf8').splitlines() if s.strip()]
def sha(b):return hashlib.sha256(b).hexdigest()
manifest=json.loads((D/'manifest.json').read_text(encoding='utf8'));assert sha((D/'input.jsonl').read_bytes())==manifest['input_sha256']
inputs=jl(D/'input.jsonl');src={x['comment_id']:x for x in inputs};reviews=jl(D/'reviewed-0.jsonl')+jl(D/'reviewed-1.jsonl');assert len(reviews)==846 and len({x['comment_id'] for x in reviews})==846 and set(src)=={x['comment_id'] for x in reviews}
poolnames={'价格预算','位置通勤','户型面积与居住方式','房内设施','宠物','楼层电梯','入住与租期','房源状态','费用合同','看房联系'}
mothers={x['slot']:x for x in json.loads((W/'mothers/first50.json').read_text(encoding='utf8'))};assert mothers[1]['user_approved'] and mothers[31]['user_approved']
old=jl(P/'all-classifications.jsonl');assert len(old)==2755;rows=old[:];new=[]
for x in reviews:
 s=src[x['comment_id']];assert x['review_key']==s['review_key'] and x['customer_uid']==s['customer_uid'] and x['note_id']==s['note_id']
 assert set(x['topics'])<=poolnames and not(x['role']=='unknown' and x['interest_at_comment']=='unrelated')
 assert all(q in s['comment_text'] for q in x['evidence'])
 for e in x['topic_evidence']:assert e['quote'] in s['comment_text'] and e['pool'] in poolnames
 for e in x['target_regions']:assert e['quote'] in s['comment_text']
 assert x['send_authorized'] is False and x['assigned_store'] is None
 confirmed=[e for e in x['topic_evidence'] if e.get('subject')=='own_demand']
 pending=[e for e in x['topic_evidence'] if e.get('subject')!='own_demand']
 reasons=[]
 if x['role']!='demand':reasons.append({'unknown':'身份或对象待核','supply':'供给，无明确本人新求租','mixed':'供给与可能新需求分别待核','discussion':'讨论或经历'}[x['role']])
 if x['interest_at_comment'] not in ['super_high','high','medium']:reasons.append('未满足本轮中高需求承接条件')
 if x['demand_state'] in ['ended','historical','future']:reasons.append('已结束、历史经历或未来才开始找')
 target=[z for z in x['target_regions'] if z['relation'] in ['desired','preferred','accepted']];targettext='、'.join(z['text'] for z in target)
 if re.search('北京|杭州|成都|福州|苏州|深圳|广州|嘉定|安亭|松江|浦东|临港|宝山|杨浦|虹口|普陀|青浦|徐泾|奉贤|金山|莘庄',targettext):reasons.append('本人目标涉及其他区域，先核门店转介，不按古北来源发推介')
 if re.search('拒中介|中介勿扰|中介.*绕道|不要中介',s['comment_text']):reasons.append('本人联系身份限制需核对，保留需求但不自动推介')
 if any(re.search('用途不明|租售.*不明|供需.*不明|对象不明|所指不明',z) for z in x['review_reasons']):reasons.append('关键对象或用途未明，暂不套母句')
 loc=any(e['pool']=='位置通勤' and e.get('polarity')=='ask' for e in confirmed);slot=31 if loc else 1
 text=mothers[slot]['template'].replace('【已核实位置】','红松东路1000号')
 if re.search('住院|陪护|父母|老人|一家人',s['comment_text']):text=text.removeprefix('宝宝，')
 c={'review_key':x['review_key'],'comment_id':x['comment_id'],'customer_uid':x['customer_uid'],'role':x['role'],'demand_state':x['demand_state'],'interest':x['interest_at_comment'],
  'topics':confirmed if x['role']=='demand' else [],'possible_topics':pending,'target_regions':x['target_regions'],'reason':x['reason'],'evidence':x['evidence'],
  'needs_review':x['review_reasons'],'missing_context':s.get('missing_context',[]),'rule_version':'business-text-20261029-v2','human_confirmed':False,'send_authorized':False,'store_assignment':None}
 row={'platform':'xiaohongshu','comment_id':x['comment_id'],'note_id':x['note_id'],'customer_uid':x['customer_uid'],'source_account_uid':s['source_account_uid'],
  'required_sending_account_uid':s['source_account_uid'],'sending_account_binding_note':'采集账号保留，实际发送账号需按本人当时选择独立核对；不自动换绑',
  'source_batch':s['source_batch'],'source_keyword':s['source_keyword'],'source_page':s['source_page'],'source_input':s['source_input'],'input_sha256':s['input_sha256'],
  'comment_text_sha256':sha(s['comment_text'].encode()),'comment_published_at':s['published_at'],'source_store':'古北（历史任务来源）','selected_store':None,'candidate_store':None,
  'rule_version':'business-text-20261029-v2','classification':c,'reply_variant':f'approved_mother_{slot}' if not reasons else None,'mother_slot':slot if not reasons else None,
  'reply_text':None if reasons else text,'reply_sha256':None if reasons else sha(text.encode()),'text_generation_complete':not reasons,
  'reply_method':'local_mother_selection_and_fact_fill','reply_generation_model_calls':0,'requires_model_at_send':False,
  'user_approved_variant':True if not reasons else None,'text_status':'held_no_reply' if reasons else 'precomputed_pending_sender_checks',
  'blocking_reasons':reasons,'semantic_review_reasons':x['review_reasons'],'current_need_confirmed':False,
  'geography_status':'本人目标与古北门店范围未确认，不按采集来源认领','gubei_match_verified':False,
  'sender_checks':['实际账号和本次发送授权','当前需求、地区及门店适配','历史已发、在途或未知回执','不得新增未核具体房态、价格、设施承诺'],
  'send_authorized':False,'can_send_now':False,'delivery_state':'not_attempted'}
 new.append(row);rows.append(row)
assert len(rows)==len({x['comment_id'] for x in rows})==3601
for x in rows:
 x['geography_status']='未完成实际门店地区适配核验';x['gubei_match_verified']=False;x['selected_store']=None;x['candidate_store']=None
groups=collections.defaultdict(list)
for x in rows:
 if x.get('reply_text'):groups[x['customer_uid']].append(x)
rank={'super_high':3,'high':2,'medium':1};suppressed=0
# Already prepared original targets keep priority; later batches cannot silently replace them.
fixed_original_ids={x['comment_id'] for x in jl(P/'precomputed-replies.jsonl')}
assert len(fixed_original_ids)==567
for xs in groups.values():
 xs.sort(key=lambda x:(x['comment_id'] in fixed_original_ids,rank.get(x['classification']['interest'],0),x['comment_published_at'] or ''),reverse=True)
 for x in xs[1:]:x['alternative_reply_text']=x['reply_text'];x['reply_text']=None;x['reply_sha256']=None;x['text_generation_complete']=False;x['text_status']='held_duplicate_customer';x['blocking_reasons'].append('原批已固定目标优先；同平台同客户不重复入队');suppressed+=1
assert {x['comment_id'] for x in old if x.get('reply_text')}==fixed_original_ids
result=D/'classified-3601.jsonl';packed=''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in rows).encode();result.write_bytes(packed)
newfile=D/'classified-increment846.jsonl';newfile.write_bytes(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in new).encode())
drafts=[x for x in rows if x.get('reply_text')];(D/'mother-drafts-3601.jsonl').write_bytes(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in drafts).encode())
sourcegroups=collections.defaultdict(list)
for x in new:sourcegroups[src[x['comment_id']]['source_input']].append(x)
receipts=[]
for inputfile,xs in sourcegroups.items():
 p=Path(inputfile);assert sha(p.read_bytes())==xs[0]['input_sha256'];out=p.parent/'text-classification-result-v2-increment846.jsonl'
 data=''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in xs).encode();out.write_bytes(data)
 receipt={'platform':'xiaohongshu','rule_version':'business-text-20261029-v2','source_input':p.name,'input_sha256':sha(p.read_bytes()),'classified_comments':len(xs),
  'result_file':out.name,'result_sha256':sha(data),'local_mother_texts':sum(bool(x['reply_text']) for x in xs),'reply_generation_model_calls':0,'source_input_modified':False,'source_database_modified':False,'sent':0}
 (p.parent/'text-processing-receipt-v2-increment846.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2),encoding='utf8');receipts.append(receipt)
high=[x for x in rows if x['classification']['interest'] in ['high','super_high']]
summary={'platform':'xiaohongshu','classified_snapshot_comments':3601,'newly_analyzed':846,'previously_analyzed':2755,'unique_customers':len({x['customer_uid'] for x in rows}),
 'interest_counts':dict(collections.Counter(x['classification']['interest'] for x in rows)),'new_interest_counts':dict(collections.Counter(x['classification']['interest'] for x in new)),
 'high_or_super_comments':len(high),'high_or_super_customers':len({x['customer_uid'] for x in high}),
 'high_pool_counts':{p:sum(any(t['pool']==p for t in x['classification']['topics']) for x in high) for p in sorted(poolnames)},
 'local_mother_drafts':len(drafts),'new_increment_texts_retained':sum(bool(x['reply_text']) for x in new),'new_cross_snapshot_duplicate_candidates_prevented':suppressed,
 'can_send_now':0,'store_match_verified':0,'all_post_bodies_collected':False,'all_direct_parents_collected':False,'all_deep_context_collected':False,
 'result_file':str(result),'result_sha256':sha(packed),'source_database_modified':False,'source_inputs_modified':False,'platform_calls':0,'actual_sent':0,'reply_generation_model_calls':0}
(D/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf8');(D/'writeback-receipts.json').write_text(json.dumps(receipts,ensure_ascii=False,indent=2),encoding='utf8')
(W/'xhs-text-current-summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf8')
O=R/'outputs/方隅双平台文本业务/小红书分类与母句处理';O.mkdir(exist_ok=True)
labels={'super_high':'超高','high':'高','medium':'中','low':'低','very_low':'很低','uncertain':'待核','unrelated':'供给、讨论或已结束'}
lines=['# 小红书已登记评论的本地文本处理','',
 '小红书采集保持暂停；本轮没有恢复采集或操作平台。原2755条保留，新增846条完成模型初判和结构证据校验，共3601条已分析。本文汇总总量，原批与新增批的回复准备分开，两平台也单独统计，本文不含抖音。','',
'|意向或状态|评论数|','|---|---:|']
for k in ['super_high','high','medium','low','very_low','uncertain','unrelated']:lines.append(f'|{labels[k]}|{summary["interest_counts"].get(k,0)}|')
lines+=['',f'高及超高初判合计{len(high)}条，去重{summary["high_or_super_customers"]}个平台客户。这是评论时兴趣，不是当前有效或已核门店适配人数。',
 f'本地母句接话稿{len(drafts)}条，本轮增量保留{summary["new_increment_texts_retained"]}条；只选已有母句及填已核位置，不逐条AI写回复。无需求、歧义、其他地区、明确联系限制、历史结束和同客重复分别保留处理原因。',
 '每条有分类及处理结果，不等于每条都应生成推介。原567条固定稿保持原目标和文案，不等后续补稿才准备；新增批保留142条独立母句候选，跨批同客户保留原目标优先。正文、直接上级与深层回复仍有采集缺口；当前需求、地区和历史回执的最终核对由平台执行窗口处理。本窗口没有更换真实发送账号、发送评论或更改回执。','',
 '## 高及超高初判的需求池','', '|需求池|评论数|','|---|---:|']
for pool,c in summary['high_pool_counts'].items():lines.append(f'|{pool}|{c}|')
lines+=['','同条可多池，不将待核主题算作本人已确认条件。模型初判、逐字校验、业务认可与真实门店匹配分别记录，不声称准确率。','']
(O/'3601条意向、分池与母句处理汇总.md').write_text('\n'.join(lines),encoding='utf8')
oldtext={x['comment_id']:x['comment_text'] for x in jl(W/'delivery-v2/source-input.jsonl')}
detail=[]
for x in rows:
 text=src[x['comment_id']]['comment_text'] if x['comment_id'] in src else oldtext[x['comment_id']]
 text=re.sub(r'https?://\S+','[链接已省略]',text);text=re.sub(r'(?<!\d)1[3-9]\d{9}(?!\d)','[联系方式已省略]',text)
 detail+=['────────','原评论：'+text,'意向：'+labels[x['classification']['interest']],'需求池：'+('、'.join(t['pool'] for t in x['classification']['topics']) or '未确认具体主题'),
  '依据：'+x['classification']['reason'],'本地母句稿：'+(x.get('reply_text') or '暂缓或同客户不重复入队'),
  '暂缓或待核：'+'；'.join(x.get('blocking_reasons',[])+['当前需求、地区和门店适配未核实，未发送']),'']
(O/'3601条逐条分类与本地母句.txt').write_text('\n'.join(detail),encoding='utf8')
print(json.dumps(summary,ensure_ascii=False))
