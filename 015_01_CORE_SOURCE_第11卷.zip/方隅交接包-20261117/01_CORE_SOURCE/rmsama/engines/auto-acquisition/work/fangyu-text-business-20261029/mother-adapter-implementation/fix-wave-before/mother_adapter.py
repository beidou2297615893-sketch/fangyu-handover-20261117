"""Local, deterministic selection from approved mother sentences; no intent classification."""
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path
import sqlite3


def select_reply(row, mothers):
    """Keep legacy decisions unchanged; select only the generic approved intro for new plans."""
    row['send_authorized'] = False
    row['can_send_now'] = False
    plan = row.get('reply_plan')
    if plan is None:
        return row
    row['reply_generation_model_calls'] = 0
    if not isinstance(plan, dict):
        raise ValueError('reply_plan must be an object')
    if type(plan.get('generic_intro_suitable')) is not bool or plan.get('tone') not in ('normal', 'serious'):
        raise ValueError('invalid reply_plan suitability or tone')
    if any(not isinstance(plan.get(k), list) for k in ('missing_facts', 'caution')):
        raise ValueError('reply_plan missing_facts and caution must be lists')
    slot = plan.get('preferred_mother_slot')
    if slot is not None and (type(slot) is not int or slot < 1):
        raise ValueError('invalid preferred mother slot')
    policy = plan.get('contact_policy')
    if policy is None:
        ai_reviewed = row.get('classification_method') in ('ai_semantic_initial_and_detailed', 'ai_independent_semantic_fine_review')
        policy = 'allow' if ai_reviewed and row.get('contact_boundaries') == [] else 'unknown'
    if policy not in ('allow', 'identity_restricted', 'no_contact', 'unknown'):
        raise ValueError('invalid structured contact policy')
    row['effective_contact_policy'] = policy
    by_slot = {m['slot']: m for m in mothers}
    preferred = by_slot.get(slot)
    generic = by_slot.get(1)
    missing = list(plan['missing_facts'])
    if slot != 1 and preferred:
        fact = preferred.get('required_facts')
        if fact and fact not in missing: missing.append(fact)
    if slot is not None and (not preferred or not preferred.get('user_approved')):
        missing.append('首选母句未获认可，不能直接使用')
    if row.get('contact_boundaries') or policy in ('identity_restricted', 'unknown'):
        row['contact_manual_review'] = True
    else:
        row['contact_manual_review'] = False
    eligible = (plan['generic_intro_suitable'] is True and row.get('role') in ('demand','mixed')
                and row.get('demand_state') in ('active_at_comment','future')
                and row.get('interest_at_comment') != 'unrelated'
                and not row.get('source_version_conflict',False) and policy != 'no_contact')
    if eligible and (not generic or not generic.get('user_approved') or not generic.get('template')):
        raise ValueError('approved generic mother slot 1 is required')
    text = generic['template'] if eligible else None
    if text and plan['tone'] == 'serious': text = text.removeprefix('宝宝，')
    row.update(preferred_mother_slot=slot, mother_slot=1 if eligible else None,
               mother_reply_text=text, reply_kind='generic_intro' if eligible else None,
               reply_missing_facts=missing, reply_unanswered_specific_question=bool(eligible),
               reply_scope='通用介绍接话，不代表已回答具体问题或确认房源、费用及门店适配',
               reply_status='本地母句审核稿，未授权发送' if eligible else '待核或不适合接话，暂不生成')
    return row


def _time(value):
    if not isinstance(value, str): return None
    try:
        result = datetime.fromisoformat(value.replace('Z','+00:00'))
        return result.astimezone(timezone.utc) if result.tzinfo is not None else None
    except (ValueError, OverflowError): return None


def reconcile_customers(rows):
    groups = defaultdict(list)
    for row in rows:
        if row.get('platform') and row.get('customer_uid'):
            groups[(row['platform'],row['customer_uid'])].append(row)
    duplicates = 0
    rank = {'super_high':3,'high':2,'medium':1}
    for group in groups.values():
        endings = [r for r in group if r.get('demand_state') == 'ended' and r.get('role') in ('demand','mixed') and not r.get('source_version_conflict',False)]
        for row in group:
            if not row.get('mother_reply_text'): continue
            when = _time(row.get('published_at'))
            if any(when is None or _time(e.get('published_at')) is None for e in endings):
                row['timeline_review'] = '存在时间未明的结束信号，无法判断先后'
            if when is not None and any(_time(e.get('published_at')) is not None and _time(e.get('published_at')) > when for e in endings):
                row['alternative_mother_reply_text'] = row['mother_reply_text']
                row['mother_reply_text'] = None
                row['reply_status'] = '同平台客户有较晚结束信号，旧稿保留备选并待核'
                row['timeline_review'] = '较晚评论明确找房结束；当前状态仍待人工核实'
        candidates = [r for r in group if r.get('mother_reply_text')]
        candidates.sort(key=lambda r:(rank.get(r.get('interest_at_comment'),0), _time(r.get('published_at')) or datetime.min.replace(tzinfo=timezone.utc),str(r.get('comment_id',''))), reverse=True)
        for row in candidates[1:]:
            row['alternative_mother_reply_text'] = row['mother_reply_text']; row['mother_reply_text'] = None
            row['reply_status'] = '同平台客户其他评论已有候选，保留备选不重复入队'; duplicates += 1
    return duplicates


def open_source_readonly(path):
    db = sqlite3.connect(Path(path).resolve().as_uri() + '?mode=ro', uri=True)
    db.execute('PRAGMA query_only=ON')
    db.execute('BEGIN')
    return db


def enrich_observations(db, stable_key, observations):
    result = []
    for item in observations:
        out = dict(item)
        rows = db.execute("SELECT o.account_uid, CASE WHEN json_valid(a.spec) THEN json_extract(a.spec,'$.account_uid') END FROM observations o LEFT JOIN attempts a ON a.request_id=o.request_id WHERE o.request_id=? AND o.stable_key=? AND o.kind='comments'", (item.get('request_id'), stable_key)).fetchall()
        account = None
        if len(rows) == 1:
            observed, spec = rows[0]
            if isinstance(observed,str) and observed and (spec is None or spec == observed): account = observed
            elif observed in (None, '') and isinstance(spec,str) and spec: account = spec
        out['collection_account_uid'] = account
        if account is None: out['account_trace_review'] = '来源记录缺失、账号缺失或账号不一致，需核对'
        result.append(out)
    return result
