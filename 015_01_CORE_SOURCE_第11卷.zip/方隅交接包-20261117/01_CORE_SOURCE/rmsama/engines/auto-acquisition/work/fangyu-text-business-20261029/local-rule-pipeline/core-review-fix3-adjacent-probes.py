"""Compare only actor/time/condition scopes touched by the six fix3 changes."""
import importlib.util
import hashlib
import json
from pathlib import Path

root=Path(__file__).resolve().parent
def classifier(directory, name):
    spec=importlib.util.spec_from_file_location(name,directory/'local_classifier.py')
    module=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module.LocalClassifier(directory/'rule_config.json')
current=classifier(root,'core_review_fix3')
old_dir=root/'review-archive'/'fix2'
old=classifier(old_dir,'core_review_fix2')
cases=[
 ('history_then_new_search','以前租过一室，想找两室，预算3000'),
 ('history_then_explicit_seeking','以前住过这里，求租两室'),
 ('failed_viewing_then_new_viewing','上次看房没去成，这周末想约看'),
 ('history_then_now_control','以前住过这里，现在求租两室'),
 ('reported_then_own_control','朋友正在找两室，我也想找一室'),
 ('proxy_and_self_control','帮妈妈找两室，我也想找一室'),
 ('unsplit_polarity_control','求租两室，不要独卫必须有电梯'),
 ('split_polarity_control','求租两室，必须有电梯但不要独卫'),
]
out=[]
for key,text in cases:
    rec={'platform':'synthetic','comment_id':key,'comment_text':text,'post_body':'房东直租，两室公寓出租，可租。','published_at_unix':1793270000}
    out.append({'id':key,'input':rec,'fix2':old.classify(rec),'fix3':current.classify(rec)})
payload={'scope':'six-finding adjacent regression probes only, not accuracy','heldout_read':False,'model_calls':0,'network_calls':0,'sha256':{n:hashlib.sha256((root/n).read_bytes()).hexdigest() for n in ['local_classifier.py','rule_config.json']},'cases':out}
(root/'core-review-fix3-adjacent-results.json').write_text(json.dumps(payload,ensure_ascii=False,indent=2),encoding='utf-8')
for x in out:
    print(json.dumps({'id':x['id'],'input':x['input']['comment_text'],'versions':{v:{k:x[v][k] for k in ['role','demand_state','interest_at_comment','exception_type','topics','target_regions','budget_mentions']} for v in ['fix2','fix3']}},ensure_ascii=True))
