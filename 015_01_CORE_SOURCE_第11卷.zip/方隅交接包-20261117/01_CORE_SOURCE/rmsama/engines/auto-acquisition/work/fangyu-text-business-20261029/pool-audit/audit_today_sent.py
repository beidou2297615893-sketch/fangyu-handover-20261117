import json,re,subprocess,sqlite3,sys,collections
from pathlib import Path
from datetime import datetime,timezone,timedelta
W=Path(__file__).resolve().parents[1];ROOT=W.parents[1]
sys.path.insert(0,str(W/'recency-priority'));import recency
now=datetime.now(timezone(timedelta(hours=8)));day=now.date().isoformat()
by={}
for p in [W/'douyin-semantic-repair-v5/all-pool-business-fit.jsonl',W/'douyin-semantic-repair-v5/douyin-replies.jsonl']:
 for l in p.open(encoding='utf-8-sig'):
  r=json.loads(l);by[r['comment_id']]=r
db=sqlite3.connect((ROOT/'work/shared-acquisition-ledger/shared.sqlite3').resolve().as_uri()+'?mode=ro',uri=True)
ledger={(p,c):s for p,c,s in db.execute('select platform,comment,status from reservations')}
records={};states=collections.defaultdict(set)
for f in subprocess.check_output(['rg','--files',str(ROOT/'work'),'-g','发送回执记录.txt'],text=True,encoding='utf-8').splitlines():
 for line in Path(f).read_text(encoding='utf-8-sig').splitlines():
  if not line.startswith(day):continue
  m=re.search(r'目标评论：(.*?) \| 结果：(.*?) \|',line)
  if not m:continue
  cid,status=m.groups();states[status].add(cid)
  if status!='sent':continue
  when=line.split(' | ')[0];row=by.get(cid,{})
  stamp=datetime.fromisoformat(when).timestamp();band=recency.BANDS[recency.key(row,stamp)[0]]
  records.setdefault(cid,dict(cid=cid,sent_at=when,original_comment_time=row.get('original_comment_date') or row.get('published_at'),age_band_at_send=band,ledger_status=ledger.get(('douyin',cid),'missing'),source_log=f))
out={'checked_at':now.isoformat(),'date':day,'count_definition':'当天带日期的sent回执按目标评论ID去重；按发送当时原评论年龄分档','confirmed_success':len(records),'ledger_matched_success':sum(r['ledger_status']=='sent' for r in records.values()),'bands':dict(collections.Counter(r['age_band_at_send'] for r in records.values())),'other_today_states':{k:len(v) for k,v in states.items() if k!='sent'},'latest_success_at':max((r['sent_at'] for r in records.values()),default=None)}
dest=W/'pool-audit';(dest/'today-sent-age-audit.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8');(dest/'today-sent-age-details.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in records.values()),encoding='utf-8');print(json.dumps(out,ensure_ascii=False))
