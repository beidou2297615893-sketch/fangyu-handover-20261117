"""Create frozen, source-only deictic semantic labels input; never classify or call platforms."""
import json,pathlib,hashlib,collections,copy,datetime
O=pathlib.Path(__file__).resolve().parent;W=O.parents[1];D=W/'pool-mother-review/legacy-release-repairs-v2';REG=W/'region-brand-routing';Q=D/'incremental-plan-overlays.jsonl'
def sha(p):
 h=hashlib.sha256()
 with pathlib.Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def objsha(x):return hashlib.sha256(json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode('utf8')).hexdigest()
def load(p):return json.loads(pathlib.Path(p).read_text(encoding='utf8'))
def jl(p):
 with pathlib.Path(p).open(encoding='utf8') as f:
  for l in f:
   if l.strip():yield json.loads(l)
def put(p,x):pathlib.Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2,sort_keys=True)+'\n',encoding='utf8')
def putjl(p,rows):
 with pathlib.Path(p).open('w',encoding='utf8',newline='\n') as f:
  for r in rows:f.write(json.dumps(r,ensure_ascii=False,sort_keys=True,separators=(',',':'))+'\n')
expected_ready='23eb7616b5d7ad5962acd780060142cc6c01275ee18070abfe2c9e9670f95497';expected_overlay='2c2f12c65db07988af4638f23d7f2f5d9f232062beb4344c110806330baa9e21';expected_current='4267c842b65ffce9a0c863aba2eacff98de92346efc3ce312c37f1f50a00d21d'
if sha(D/'READY.json')!=expected_ready or sha(Q)!=expected_overlay or sha(REG/'current.json')!=expected_current:raise ValueError('frozen input or pointer changed')
c=load(REG/'current.json');ready=load(D/'READY.json')
if ready['status']!='complete_frozen_for_independent_review_not_published' or ready['incremental_overlays_sha256']!=expected_overlay:raise ValueError('v2 is not frozen')
rows=list(jl(Q));refs=[p for p in rows if 'v2_object_reference' in (p.get('replacement_plan') or {}).get('fill',{})]
if len(rows)!=266 or len(refs)!=265:raise ValueError('reference scope mismatch')
selected={}
for p in refs:
 k=(str(p['platform']),str(p['cid']))
 if k in selected:raise ValueError('duplicate target CID')
 selected[k]=p
extras=[('douyin','7610009622871638799'),('douyin','7668177041443865390')]
for k in extras:selected.setdefault(k,None)
protected={str((D/'READY.json').resolve()):expected_ready,str(Q.resolve()):expected_overlay,str((REG/'current.json').resolve()):expected_current}
for plat,path in c['results'].items():
 digest=sha(path);expected=c['result_sha256'].get(plat,c['result_sha256'].get(pathlib.Path(path).name))
 if digest!=expected:raise ValueError('current source SHA mismatch '+plat)
 protected[str(pathlib.Path(path).resolve())]=digest
before={p:sha(p) for p in protected};sources={}
for plat,path in c['results'].items():
 for r in jl(path):
  k=(plat,str(r['comment_id']))
  if k in selected:
   if k in sources:raise ValueError('duplicate source CID '+str(k))
   sources[k]=r
if set(sources)!=set(selected):raise ValueError('missing actual source '+str(set(selected)-set(sources)))
contexts={'posts':{},'parents':{}};out=[];unknown=collections.Counter();byplat=collections.Counter()
def available(value):return value if isinstance(value,str) and value.strip() else None
for k in sorted(selected):
 plat,cid=k;r=sources[k];s=r.get('source_record') or {};raw=r.get('original_raw_record') or {};classif=s.get('classification') if isinstance(s.get('classification'),dict) else s;comment=r.get('comment_text');uid=str(r['customer_uid'])
 if not isinstance(comment,str) or not comment:raise ValueError('missing original comment '+str(k))
 textsha=hashlib.sha256(comment.encode('utf8')).hexdigest();plan=selected[k]
 if plan:
  if str(plan['uid'])!=uid or plan['sourceSHA']!=textsha or plan['source_file_sha256']!=protected[str(pathlib.Path(c['results'][plat]).resolve())] or plan['original_classification_sha256']!=objsha(s):raise ValueError('ID/UID/text/source fingerprint mismatch '+str(k))
  if plan['classification_changed'] is not False or plan['send_authorized'] is not False or plan['can_send_now'] is not False:raise ValueError('target source safety mismatch '+str(k))
 pid=str(s.get('video_id') or s.get('note_id') or r.get('video_id') or r.get('note_id') or '') or None
 if plat=='douyin':
  title=None;body=available(s.get('post_body'));parent=available(s.get('direct_parent_text'));same=s.get('post_author_same_as_commenter') if isinstance(s.get('post_author_same_as_commenter'),bool) else None
 else:
  title=available(raw.get('post_title'));body=available(raw.get('post_text'));parent=available(raw.get('parent_text'));same=s.get('post_author_same_as_commenter') if isinstance(s.get('post_author_same_as_commenter'),bool) else None
 post={'platform':plat,'post_id':pid,'post_title':title,'post_body':body,'post_author_same_as_commenter':same,'missing_fields':[x for x,v in (('post_id',pid),('post_title',title if plat=='xiaohongshu' else 'not_applicable'),('post_body',body)) if v is None]};ph=objsha(post);ctx=plat+':'+(pid or 'post_id_unknown')+':'+ph[:16];contexts['posts'].setdefault(ctx,{'content':post,'content_sha256':ph})
 parent_payload={'platform':plat,'parent_text':parent,'availability':'available' if parent is not None else 'unknown'};pph=objsha(parent_payload);parent_key=plat+':parent:'+pph[:16];contexts['parents'].setdefault(parent_key,{'content':parent_payload,'content_sha256':pph})
 topics=classif.get('topic_evidence') or classif.get('actual_pools') or classif.get('topics') or s.get('topic_evidence') or s.get('topics') or []
 ns=s.get('needs_review') if isinstance(s.get('needs_review'),list) else [];nc=classif.get('needs_review') if isinstance(classif.get('needs_review'),list) else [];bs=s.get('blocking_reasons') if isinstance(s.get('blocking_reasons'),list) else [];bc=classif.get('blocking_reasons') if isinstance(classif.get('blocking_reasons'),list) else []
 if body is None:unknown['post_body']+=1
 if plat=='xiaohongshu' and title is None:unknown['post_title']+=1
 if parent is None:unknown['direct_parent']+=1
 if same is None:unknown['post_author_same_as_commenter']+=1
 out.append({'platform':plat,'cid':cid,'uid':uid,'comment':comment,'source_comment_sha256':textsha,'source_container_sha256':protected[str(pathlib.Path(c['results'][plat]).resolve())],'source_record_sha256':objsha(s),'original_stored_comment_sha256':r.get('comment_text_sha256'),'existing_pool_evidence':copy.deepcopy(topics),'existing_target_regions':copy.deepcopy(r.get('target_regions') or []),'existing_time_mentions':copy.deepcopy(r.get('time_mentions') or []),'existing_needs_review':{'source_record':copy.deepcopy(ns),'classification':copy.deepcopy(nc)},'existing_blocking_reasons':{'source_record':copy.deepcopy(bs),'classification':copy.deepcopy(bc)},'context_key':ctx,'context_sha256':ph,'parent_context_key':parent_key,'parent_context_sha256':pph,'comment_source_availability':'available','context_or_parent_missing':'unknown_if_missing'});byplat[plat]+=1
if len(out)!=len(selected) or len({(x['platform'],x['cid']) for x in out})!=len(out):raise ValueError('output dedup failed')
# Stable within-platform hash sorting, assign to least represented platform then overall shard size.
shards=[[],[]]
for plat in sorted(byplat):
 items=sorted((x for x in out if x['platform']==plat),key=lambda x:hashlib.sha256((x['platform']+'|'+x['cid']).encode()).hexdigest())
 for item in items:
  pcounts=[sum(x['platform']==plat for x in shard) for shard in shards];j=min(range(2),key=lambda q:(pcounts[q],len(shards[q]),q));shards[j].append(item)
if abs(len(shards[0])-len(shards[1]))>1:raise ValueError('shards not balanced')
inputkeys={(x['platform'],x['cid']) for x in out};keys0={(x['platform'],x['cid']) for x in shards[0]};keys1={(x['platform'],x['cid']) for x in shards[1]}
if keys0&keys1 or keys0|keys1!=inputkeys:raise ValueError('shards overlap or coverage gap')
putjl(O/'input.jsonl',out);putjl(O/'shard0.jsonl',shards[0]);putjl(O/'shard1.jsonl',shards[1]);put(O/'shared-contexts.json',contexts)
schema={'task':'为原评论补充最少引用关系标签；不得改原角色/意向，不写回复正文。','identifier':['platform','cid','uid','source_comment_sha256'],'output_fields':{'reference_mentions':'数组：引用原评论中的精确短语；逐项给 reference_type、referent_type 和证据。若指代不明标 unknown；不存在标空数组。','place_relation':'逐项标 original_post_place / commenter_current_place / commenter_desired_place / commenter_workplace / unspecified / unknown；只在已有证据支持时使用。','price_relation':'按文本区分 original_post_quote_confirmation / price_range_for_new_search / price_comparison / price_inquiry_unspecified / not_price / unknown；可多项；不造金额或费用口径。','time_relation':'按文本区分 calendar_period / rent_duration / price_cycle / relative_time / other / unknown；原文歧义保持 unknown。','brand_source_relation':'explicit_fangyu / explicit_other_source / unknown；仅依据文本明示，IP、采集来源门店或无关帖子不能证明。','contact_action_direction':'commenter_initiates / asks_other_to_contact_commenter / asks_method / no_contact_action / unknown；证据不足为 unknown。','evidence':'每项结论附 source=comment/post_title/post_body/direct_parent 和该来源的逐字短引用；没有可引用证据时返回 unknown 并注明缺失，不把原帖作者条件当评论人需求。','unresolved_or_missing':'数组：上下文缺失、关系歧义和需要进一步核实处；未知明确 unknown。'},'required_constraints':['不得生成或建议回复正文。','不得改写原 role、demand_state、interest，也不新增分类结论。','区分历史时间、租期、报价周期；不以当日推算原评论意图。','不得根据 IP 或来源门店推断地理、客户要求或品牌归属。','来源帖子、父评论与评论人自述分别标注；无法确认归属时保留 unknown。','每条只返回一条结构化标签，原文本和来源引用不得改写。'],'suggested_record':{'platform':'原值','cid':'原值','uid':'原值','source_comment_sha256':'原值','reference_mentions':[],'place_relation':[],'price_relation':[],'time_relation':[],'brand_source_relation':'unknown','contact_action_direction':'unknown','evidence':[],'unresolved_or_missing':[]}}
put(O/'label-schema.json',schema)
post={p:sha(p) for p in protected}
if post!=before:raise ValueError('protected source changed')
outputs={n:sha(O/n) for n in ('input.jsonl','shard0.jsonl','shard1.jsonl','shared-contexts.json','label-schema.json')};manifest={'scope':'265 frozen ordinary-reference IDs plus two real price/month boundary IDs; deduplicate by platform and cid','current_pointer_sha256':expected_current,'v2_READY_sha256':expected_ready,'incremental_overlay_sha256':expected_overlay,'sources_sha256_before':before,'sources_sha256_after':post,'records':len(out),'by_platform':dict(byplat),'shards':[{'name':'shard0.jsonl','count':len(shards[0]),'by_platform':dict(collections.Counter(x['platform'] for x in shards[0]))},{'name':'shard1.jsonl','count':len(shards[1]),'by_platform':dict(collections.Counter(x['platform'] for x in shards[1]))}],'distinct_post_contexts':len(contexts['posts']),'distinct_parent_contexts':len(contexts['parents']),'context_missing_overlapping':dict(unknown),'checks':{'CID_UID_comment_and_source_fingerprints':True,'contexts_canonical_SHA_valid':True,'shards_disjoint_complete':True,'source_sha_unchanged':True,'prior_reply_or_audit_verdict_in_inputs':False,'classification_calls':0,'platform_calls':0,'source_or_pointer_writes':0,'send_authorized':False},'outputs_sha256':outputs,'semantics':'input preparation only; no new labels, no accuracy claim'}
put(O/'manifest.json',manifest);put(O/'READY.json',{'status':'input_prepared_not_labeled','manifest_sha256':sha(O/'manifest.json'),'records':len(out),'shard_counts':[len(shards[0]),len(shards[1])],'output_sha256':outputs,'send_authorized':False});print(json.dumps({'records':len(out),'by_platform':dict(byplat),'shards':[len(shards[0]),len(shards[1])],'unknown':dict(unknown),'manifest_sha256':sha(O/'manifest.json'),'READY_sha256':sha(O/'READY.json'),'outputs':outputs},ensure_ascii=True))
