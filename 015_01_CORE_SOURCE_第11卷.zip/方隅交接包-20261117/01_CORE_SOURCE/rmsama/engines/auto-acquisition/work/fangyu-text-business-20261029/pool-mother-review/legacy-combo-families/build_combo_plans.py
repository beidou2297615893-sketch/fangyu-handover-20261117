"""Local, source-bound template addon. No platform, model/API, or source mutation."""
import collections
import hashlib
import json
import pathlib
import string

OUT = pathlib.Path(__file__).resolve().parent
ROOT = OUT.parents[1]
OLD = ROOT / 'pool-mother-review/legacy-local-planning'
CONTRACT = ROOT / 'douyin-registered-v2/increments/f98cc21138910fb9/local-mother-contract.json'

def digest(data):
    return hashlib.sha256(data).hexdigest()

def canonical(obj):
    return json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode('utf-8')

def read(path):
    return json.loads(path.read_text(encoding='utf-8'))

def dump(name, obj):
    (OUT/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

def lines(name, rows):
    (OUT/name).write_text(''.join(json.dumps(x,ensure_ascii=False,separators=(',',':'))+'\n' for x in rows),encoding='utf-8')

# One business action in each fixed mother. Missing facts never become fill values.
templates = {
 'combo_available_price': '宝宝，我住方隅，空房和月租一起帮你问，介绍有优惠。',
 'combo_available_location': '宝宝，我住方隅，空房和具体位置一起帮你问，介绍有优惠。',
 'combo_view': '宝宝，我住方隅，看房安排帮你问，介绍有优惠。',
 'combo_available_view': '宝宝，我住方隅，空房和看房安排一起帮你问，介绍有优惠。',
 'combo_location_view': '宝宝，我住方隅，具体位置和看房安排一起帮你问，介绍有优惠。',
 'combo_price_contact': '宝宝，我住方隅，租金帮你问，点我聊就行，介绍有优惠。',
 'combo_room_price': '宝宝，我住方隅，{room}的房态和租金帮你问，介绍有优惠。',
 'combo_place_price': '宝宝，我住方隅，{place}的房态、位置和租金帮你问，介绍有优惠。',
 'combo_place_room_price': '宝宝，我住方隅，{place}{room}的房态、位置和租金帮你问，介绍有优惠。',
 'combo_room_location_available': '宝宝，我住方隅，{room}的空房和位置帮你问，介绍有优惠。',
 'combo_room_contact': '宝宝，我住方隅，{room}的空房帮你问，点我聊就行，介绍有优惠。',
 'combo_work_budget': '宝宝，我住方隅，预算{budget}、去{work}上班方便的房源帮你问，介绍有优惠。',
 'combo_work_budget_room': '宝宝，我住方隅，{room}、预算{budget}，去{work}上班方便的房源帮你问，介绍有优惠。',
 'combo_budget_location': '宝宝，我住方隅，预算{budget}能选哪些位置帮你问，介绍有优惠。',
 'combo_price_utilities': '宝宝，我住方隅，月租和是否{utilities}一起帮你问，介绍有优惠。',
 'combo_view_utilities': '宝宝，我住方隅，看房安排和是否{utilities}一起帮你问，介绍有优惠。',
 'combo_feature_price': '宝宝，我住方隅，带{feature}的房型租金帮你问，介绍有优惠。',
 'combo_rent_price_confirm': '宝宝，你问的是出租房源和月租对吗？我住方隅，介绍有优惠。',
 'combo_two_rooms_price': '宝宝，我住方隅，{room_a}和{room_b}的租金分别帮你问，介绍有优惠。',
 'combo_location_contact': '宝宝，我住方隅，具体位置帮你问，点我聊就行，介绍有优惠。',
 'combo_view_contact': '宝宝，我住方隅，看房安排帮你问，点我聊就行，介绍有优惠。',
}
families = {
 k:{'template':v,'required_fill':[f for _,f,_,_ in string.Formatter().parse(v) if f],
    'fill_policy':'each complete fill is one unchanged contiguous own-comment span',
    'fact_policy':'confirmation_or_inquiry_only; no inventory/price/discount verification implied',
    'individually_user_approved':False}
 for k,v in templates.items()
}
base=read(CONTRACT)
ALL={**base['families'],**families}
assert not set(base['families']) & set(families)

# These are bindings to the already-classified 223-row set, not classification rules.
BINDINGS={}
def bind(indices,family,**fill):
    for i in indices:
        assert i not in BINDINGS, i
        BINDINGS[i]=(family,dict(fill))

bind([3,4,7,8,15,18,22,23,27,35,47,50,67,69,77,80,94,100,111,113,117,124,132,136,140,144,150,173,174,180,183,184,191,192,200,204,207,209,212,213,216,217,221],'combo_available_price')
bind([25,38,48,72,75,78,79,91,116,134,142,146,148,149,158,161,162,163,165,168,179,186,187,195,211],'combo_available_location')
bind([17,21,68,119,145,147,177,185,188,202,203,210,215,219,222],'combo_view')
bind([6,199,208],'combo_available_view')
bind([81,108,220],'combo_location_view')
bind([28,29],'combo_price_contact')
bind([12,70],'combo_view_contact')
bind([2,5,36,39,41,43,45,49,51,53,56,61,63,73,74,76,82,90,99,103,107,114,120,123,129,130,131,141,152,154,155,157,159,160,164,166,169,178,181,193,194,197,214],'contact_how')
bind([24,42,57,65,105,109,118,156,170,176,196,198],'rent_process')
bind([9,26,32,55,66,83,87,112,138,139,143,171,190],'contact')
bind([133,172],'location')
bind([127],'combo_location_contact')
bind([30],'combo_rent_price_confirm')
bind([1],'combo_feature_price',feature='阳台')
bind([19],'combo_room_location_available',room='两居室')
bind([40],'combo_room_contact',room='两室一厅')
for i,room in {16:'两居',54:'一居室',58:'一居室',167:'三室'}.items():
    bind([i],'combo_room_price',room=room)
for i,place,room in [(0,'朗芳园','一居'),(10,'长宁','一居室'),(11,'漕河泾开发区','一居室'),(13,'古北','一室二室'),(37,'上海','一室'),(52,'闵行七宝','两室一厅'),(110,'春熙路','套一'),(128,'成华区东站附近','整租套二'),(153,'汽车西站附近','两室一厅')]:
    bind([i],'combo_place_room_price',place=place,room=room)
for i,place in {14:'普陀区',44:'闵行',46:'金山',64:'朱辛庄地铁 生命科学园附近',84:'朝阳区',85:'朝阳',86:'昌平',88:'朝阳区',89:'朝阳',92:'新天地',93:'国贸',95:'国贸',96:'亚运村',101:'昌平',104:'昌平合生汇',115:'西湖区',175:'滨江附近',205:'汉中路',206:'长江南路'}.items():
    bind([i],'combo_place_price',place=place)
for i,work,budget in [(31,'长宁','1500以内'),(59,'酒仙桥','一千以内'),(60,'崇文门','1-1.5k'),(62,'中关村','1500左右'),(97,'北京西','1-1.5k'),(98,'中关村','2k以内'),(102,'石景山','1.5-2k'),(121,'益泽路','2k左右'),(122,'鼓楼大街','1w'),(125,'丰台科技园','1k-1.6k'),(135,'丰台六里桥','1k')]:
    bind([i],'combo_work_budget',work=work,budget=budget)
for i,work,budget,room in [(151,'亮马桥','5k以内','整租'),(182,'海淀知春路站','5k以内','整租两居室')]:
    bind([i],'combo_work_budget_room',work=work,budget=budget,room=room)
for i,place in {33:'龙耀路',126:'闵行区',189:'成都温江'}.items():bind([i],'area',place=place)
bind([34],'commute',destination='娄山关路')
bind([137],'combo_budget_location',budget='3500')
bind([71],'combo_price_utilities',utilities='包水电')
bind([201],'combo_view_utilities',utilities='民用水电')
bind([218],'combo_two_rooms_price',room_a='2房',room_b='3房')
HOLDS={20:'原评仅“你好”，已判池不变；尚不能判定想咨询房型、联系还是其他事项，不强配具体接话。',106:'原评仅“在吗”，已判池不变；缺少要接哪个住房问题的具体语义，不强配具体接话。'}

raw=[json.loads(x) for x in (OUT/'source-bound-input.jsonl').read_text(encoding='utf-8').splitlines()]
assert len(raw)==223
assert set(BINDINGS)|set(HOLDS)==set(range(223))
tracked=[OLD/'local-proposed-plans.jsonl',OLD/'report.md',OLD/'plan-source-manifest.json',CONTRACT,
         ROOT/'douyin-registered-v2/increments/f98cc21138910fb9/batch_short_mothers.py',
         ROOT/'rules/按池选母句与微调执行方式.json',ROOT/'rules/AI判读纠偏与母句适配要点.md',ROOT/'rules/地域与品牌母句执行方式.json']
tracked += [pathlib.Path(p) for p in read(OLD/'plan-source-manifest.json')['sources'] if pathlib.Path(p).exists()]
tracked=list(dict.fromkeys(tracked))
before={str(p):digest(p.read_bytes()) for p in tracked}
plans=[];previews=[];checks=[]

def plan_one(record):
    i=record['index'];old=record['original_plan'];source=record['source_record'];text=source['comment_text']
    assert old['cid']==source['comment_id'] and old['uid']==source['customer_uid']
    assert digest(text.encode('utf-8'))==old['sourceSHA']
    assert digest(canonical(source['source_record']))==old['original_classification_sha256']
    family,fill=BINDINGS.get(i,(None,{}));evidence=[]
    for field,value in fill.items():
        assert value in text,(i,field,value)
        supporting=[e for e in old['literal_evidence'] if value in e['quote']]
        supporting += [{'source_field':'source_field_evidence.target_regions','quote':e['quote'],'relation':e.get('relation')} for e in old['source_field_evidence']['target_regions'] if value in e['quote']]
        assert supporting,(i,field,'no existing evidence')
        evidence.append({'field':field,'quote':value,'start':text.index(value),'end':text.index(value)+len(value),
                         'own_comment_sha256':old['sourceSHA'],'existing_evidence':supporting})
    effective_policy=old.get('contact_policy_original') or 'unknown'
    plan={'index':i,'platform':old['platform'],'cid':old['cid'],'uid':old['uid'],'sourceSHA':old['sourceSHA'],
          'source_file_sha256':old['source_file_sha256'],'stored_comment_sha256':old['stored_comment_sha256'],
          'original_classification_sha256':old['original_classification_sha256'],
          'original_plan_sha256':digest(canonical(old)),'source_field_evidence':old['source_field_evidence'],
          'literal_evidence':old['literal_evidence'],'original_contact_policy':old.get('contact_policy_original'),
          'contact_policy':effective_policy,'source_original_preserved':old,
          'family':family,'fill':fill,'evidence':evidence,'unbound_reason':HOLDS.get(i),
          'status':'local_template_bound' if family else 'local_template_gap',
          'fact_scope':'All literal fills are own-comment details; old missing_facts remain unverified template obligations, never customer requirements.',
          'classification_changed':False,'human_confirmed':False,'send_authorized':False,'can_send_now':False,
          'store_assignment':None,'platform_calls':0,'current_source_applied':False,
          'fact_checks_before_external_use':['实际发送账号的住户身份和介绍资格','方隅优惠的适用范围与时效','同一适用房源的实际报价、房态及明确客户条件'],
          'contact_or_delivery_holds_preserved':old.get('delivery_holds',[])}
    rendered=None
    if family:
        definition=ALL[family]
        assert set(fill)==set(definition['required_fill'])
        rendered=definition['template'].format(**fill)
        if old['source_field_evidence'].get('reply_plan',{}).get('tone')=='serious' and rendered.startswith('宝宝，'):rendered=rendered[3:]
        assert all(v in rendered for v in fill.values())
        assert '方隅' in rendered
        assert rendered.count('？')<=1
    preview={'index':i,'platform':old['platform'],'cid':old['cid'],'uid':old['uid'],'sourceSHA':old['sourceSHA'],
             'comment_text':text,'family':family,'text':rendered,'length':len(rendered) if rendered else None,
             'local_preview_only':True,'contact_policy':effective_policy,'human_confirmed':False,
             'send_authorized':False,'can_send_now':False,'unbound_reason':HOLDS.get(i)}
    return plan,preview

# Hard chain is checked before expanding the complete set.
REPRESENTATIVES=[0,1,12,13,19,30,31,34,42,58,64,70,71,98,127,128,137,151,182,201,208,218,220,20,106]
rep=[]
for i in REPRESENTATIVES:
    p,v=plan_one(raw[i]);rep.append({'plan':p,'preview':v})
dump('representative-validation.json',{'checked_before_expansion':True,'count':len(rep),'all_literal_and_source_checks_passed':True,'cases':rep})
for record in raw:
    p,v=plan_one(record);plans.append(p);previews.append(v)
    assert p['source_original_preserved']==record['original_plan']
    checks.append({'index':p['index'],'source_and_identity_match':True,'original_plan_and_classification_fields_unchanged':True,
                   'each_fill_exact_contiguous_own_comment_span':True,'fixed_template_only':True,'send_disabled':True})

dump('contract-addon.json',{'version':'legacy-combo-local-addon-v1','base_contract_sha256':digest(CONTRACT.read_bytes()),
 'base_contract_path':str(CONTRACT),'families':families,'base_families_unchanged':True,
 'status':'batch_review_candidate_not_published','all_fills_exact_contiguous':True,'send_authorized':False,'can_send_now':False,
 'selection_policy':'Only existing AI pools/subject/polarity/region relation plus literal slot binding. No intent reclassification.',
 'unknown_contact_policy':'Preview allowed, contact eligibility unknown; never upgraded to allow.',
 'scope_guards':['Do not import post author conditions or old template missing_facts into customer details.',
                 'Work destination stays work; no implicit desired home location.',
                 'Price inquiry is not customer budget or Fangyu price.',
                 'Monthly price is not lease duration. Negation, caps, approx and alternative scope must stay literal.',
                 'No store assignment; no asserted inventory, current rate, appointment or factual benefit verification.']})
lines('source-bound-plans.jsonl',plans)
lines('rendered-preview.jsonl',previews)
lines('row-validation.jsonl',checks)
after={str(p):digest(p.read_bytes()) for p in tracked}
assert before==after,'Protected input changed'
summary={'input_count':len(raw),'bound_count':sum(bool(p['family']) for p in plans),'unbound_count':sum(not p['family'] for p in plans),
 'addon_family_count':len(families),'new_family_bound_count':sum(p['family'] in families for p in plans),
 'base_family_bound_count':sum(bool(p['family']) and p['family'] not in families for p in plans),
 'family_counts':dict(collections.Counter(p['family'] or 'UNBOUND' for p in plans)),
 'original_contact_unknown_count':sum(p['contact_policy']=='unknown' for p in plans),
 'original_contact_values_preserved':True,'source_unchanged_count':len(before),'source_sha_before':before,'source_sha_after':after,
 'all_source_identity_and_comment_SHA_match':True,'all_original_fields_preserved':True,
 'all_fills_contiguous_literal_and_evidenced':True,'all_rendered_by_fixed_templates':True,
 'representative_count_before_expansion':len(rep),'local_preview_length_distribution':dict(collections.Counter('20-40' if 20<=v['length']<=40 else 'over40' if v['length'] and v['length']>40 else 'under20' for v in previews if v['text'])),
 'max_preview_length':max(v['length'] or 0 for v in previews),
 'platform_calls':0,'model_API_calls':0,'source_writes':0,'send_attempts':0,'pointer_changed':False,
 'scope_validation_notes':['No pet or time conditions occur in these 223 existing plans; no synthetic pet/time success claimed.',
 '25 representatives checked for scope and rendering before expansion; no per-row independent rewrite or human approval claimed.',
 'The 223 original work categories include ordinary contact/viewing single-pool rows; source categories were retained.']}
dump('validation.json',summary)
dump('source-manifest.json',{'inputs':before,'input_snapshot_sha256':digest((OUT/'source-bound-input.jsonl').read_bytes()),
 'source_selection':{'path':str(OLD/'local-proposed-plans.jsonl'),'field':'next_action_category','value':'integrated_family_gap_no_reclassification_needed','count':223},
 'rules_used':['copy-editing: clarity, consistent short voice, claim evidence, specificity','verification-before-completion: fresh full-source and row checks'],
 'new_external_search_required':False,'reuse_reason':'Existing verified local contract and renderer validation pattern reused. Only missing combination templates added.',
 'originals_unchanged':True,'applied':False,'platform_calls':0})
print(json.dumps({k:v for k,v in summary.items() if k not in ('source_sha_before','source_sha_after')},ensure_ascii=False,indent=2))
