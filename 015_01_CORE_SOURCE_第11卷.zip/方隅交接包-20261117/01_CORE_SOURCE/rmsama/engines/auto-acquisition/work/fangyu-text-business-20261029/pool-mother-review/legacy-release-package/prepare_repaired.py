"""Replay frozen source-bound repairs into a review-only candidate; no activation."""
import argparse,collections,copy,hashlib,json,pathlib,string,sys
sys.dont_write_bytecode=True
import prepare as prior
O=pathlib.Path(__file__).resolve().parent;W=O.parents[1];D=W/'pool-mother-review/legacy-release-repairs';ABC=O/'candidate-abc';R=W/'douyin-registered-v2/increments/f98cc21138910fb9'
objsha=prior.objsha;sha=prior.sha;load=prior.load;jl=prior.jl;dump=prior.dump;putjl=prior.putjl;key=prior.key
FIXED={'READY.json':'7de8c6665b7951e781d4cf9fd3a8affa895dc2997154f890f401e120483ec50e','manifest.json':'823a4589164a491e7fc1ae50a4c4da12074b5203b5a6490853639ae6574129d8','repair-contract.json':'18043c2a448db1f4d2dd662b9ad9c640f33e6d4aae84875c23dde8bea50e8629','source-bound-plan-overlays.jsonl':'380f92e327faf7f82202999817591391386ad10d6dcb433c8efed1b295937a0a'}
def apply_patch(base,patch):
 for field in ('platform','cid','uid','sourceSHA','source_file_sha256','original_classification_sha256'):
  if base.get(field)!=patch.get(field):raise ValueError('repair identity/source mismatch '+field)
 if patch.get('base_merged_plan_sha256')!=objsha(base) or patch.get('base_family')!=base.get('family') or patch.get('base_fill')!=base.get('fill'):raise ValueError('repair base plan mismatch')
 if patch.get('original_source_contact_policy')!=base.get('source_field_evidence',{}).get('contact_policy',base.get('contact_policy_original')):raise ValueError('repair original contact mismatch')
 if patch.get('classification_changed') is not False or patch.get('send_authorized') is not False or patch.get('can_send_now') is not False or patch.get('applied') is not False:raise ValueError('repair alters classification, permission or applied status')
 replacement=patch['replacement_plan'];required={'family','fill','evidence','clarification_only','hold_reasons','status'}
 if not required.issubset(replacement):raise ValueError('repair replacement missing fields')
 if not base.get('family') and not patch.get('newly_bound_small_short_lease_addition'):raise ValueError('unapproved newly bound plan')
 out=copy.deepcopy(base)
 for field in required:out[field]=copy.deepcopy(replacement[field])
 out.update(repair_overlay_sha256=objsha(patch),repair_base_plan_sha256=objsha(base),repair_reasons=copy.deepcopy(patch['repair_reasons']),repair_evidence=copy.deepcopy(patch['repair_evidence']),repair_source_boundary=copy.deepcopy(patch['source_contact_boundary_preserved']),repair_newly_bound_short_lease=patch['newly_bound_small_short_lease_addition'])
 return out
def contract_matrix(contract,plans):
 uses=collections.Counter(x['family'] for x in plans if x.get('family'));out={}
 for name,d in contract['families'].items():
  try:
   fields=[n for _,n,_,_ in string.Formatter().parse(d['template']) if n]
   required=d['required_fill']; unique=set(fields)
   if not isinstance(required,list) or len(required)!=len(set(required)) or set(required)!=unique or any(any(z in n for z in ('.','[',']')) for n in fields):raise ValueError('fill mismatch')
   sentinel={f:'【'+f+'】' for f in required};render=d['template'].format(**sentinel)
   if not all(v in render for v in sentinel.values()):raise ValueError('placeholder missing')
  except (KeyError,ValueError,IndexError) as e:raise ValueError('family structure '+name+': '+str(e)) from e
  out[name]={'family':name,'template':d['template'],'required_fill':required,'use_count':uses[name],'unused':uses[name]==0,'structure_valid':True,'synthetic_format_checked':True,'semantic_approval':False}
 missing=set(uses)-set(out)
 if missing:raise ValueError('used family absent '+str(missing))
 return out
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--output-dir',required=True);args=ap.parse_args();dst=pathlib.Path(args.output_dir).resolve()
 if dst!=O and O not in dst.parents:raise ValueError('outside permitted output directory')
 dst.mkdir(parents=True,exist_ok=True)
 for n,h in FIXED.items():
  if sha(D/n)!=h:raise ValueError('frozen SHA mismatch: '+n)
 ready=load(D/'READY.json');m=load(D/'manifest.json');v=load(D/'validation.json')
 if ready['status']!='complete_frozen_for_independent_review_not_published' or not v['all_technical_checks_passed'] or not v['semantic_independent_recheck_pending']:raise ValueError('repair not frozen or semantic state inconsistent')
 protected=dict(m['source_SHA256']);protected.update({str((D/n).resolve()):h for n,h in ready['final_files_sha256'].items()});protected[str((D/'READY.json').resolve())]=FIXED['READY.json'];protected[str(pathlib.Path(__file__).resolve())]=sha(__file__);protected[str((O/'prepare.py').resolve())]=sha(O/'prepare.py')
 pre={p:sha(p) for p in protected}
 if pre!=protected:raise ValueError('frozen inputs mismatch '+str([p for p in pre if pre[p]!=protected[p]]))
 base=list(jl(ABC/'merged-plans.jsonl'));patches=list(jl(D/'source-bound-plan-overlays.jsonl'));prior.validate_unique(base);prior.validate_unique(patches)
 if len(base)!=12963 or len(patches)!=813:raise ValueError('plan count mismatch')
 patchby={key(x):x for x in patches};baseby={key(x):x for x in base}
 if not set(patchby)<=set(baseby):raise ValueError('repair unknown source IDs')
 plans=[apply_patch(p,patchby[key(p)]) if key(p) in patchby else copy.deepcopy(p) for p in base];by={key(p):p for p in plans};contract=load(D/'repair-contract.json')
 if len(contract['families'])!=366:raise ValueError('repair contract family count')
 matrix=contract_matrix(contract,plans);cur=load(W/'region-brand-routing/current.json');oldcurrent=sha(W/'region-brand-routing/current.json')
 if oldcurrent!=m['source_current_pointer_sha256']:raise ValueError('source pointer mismatch')
 snapshot=dst/'immutable-baseline';snapshot.mkdir(exist_ok=True)
 files={'region-current.json':W/'region-brand-routing/current.json','reply-pointer.json':W/'当前双平台回复结果指针.json','latest-manifest.json':W/'region-brand-routing/latest-manifest.json'}
 for name,path in files.items():(snapshot/name).write_bytes(path.read_bytes())
 snap={name:sha(snapshot/name) for name in files}
 if any(snap[name]!=sha(path) for name,path in files.items()):raise ValueError('pointer snapshot drift')
 dump(dst/'merged-contract.json',contract);putjl(dst/'merged-plans.jsonl',plans);putjl(dst/'all-family-matrix.jsonl',[matrix[n] for n in sorted(matrix)])
 olddraft={}
 for platform in ('douyin','xiaohongshu'):
  for r in jl(ABC/(platform+'-candidate.jsonl')):
   k=(platform,str(r['comment_id']),str(r['customer_uid']))
   if k in by:olddraft[k]=r.get('mother_reply_text') or r.get('alternative_mother_reply_text')
 if set(olddraft)!=set(by):raise ValueError('ABC baseline ID mismatch')
 counts=collections.Counter();changed=[];seen=set();families=collections.Counter();totals=collections.Counter();class_counts=collections.Counter();overlay_replayed=0
 for platform,path in cur['results'].items():
  digest=sha(path);output=dst/(platform+'-candidate.jsonl')
  with output.open('w',encoding='utf8',newline='\n') as f:
   for r in jl(path):
    k=(platform,str(r['comment_id']),str(r['customer_uid']));totals[platform]+=1;class_counts[(platform,r.get('role'),r.get('demand_state'),r.get('interest_at_comment'))]+=1
    if r.get('send_authorized') is not False or r.get('can_send_now') is not False:raise ValueError('source send flag changed')
    p=by.get(k);out=r
    if p:
     if k in seen:raise ValueError('duplicate source')
     seen.add(k);selection=prior.verify_binding(p,r,digest)
     if k in patchby:
      q=patchby[k];rp=r.get('contact_policy');rb=r.get('contact_boundaries') or []
      if q['original_source_contact_policy']!=rp or q['source_contact_boundary_preserved']!=rb:raise ValueError('repair contact boundary mismatch '+str(k))
      if not q.get('newly_bound_small_short_lease_addition') and q.get('old_preview_sha256') and sha_text(olddraft[k])!=q['old_preview_sha256']:raise ValueError('repair old preview mismatch '+str(k))
     if p.get('family'):
      out=prior.candidate_for(p,r,contract,digest);meta=out['local_mother_candidate'];meta['repair_overlay_sha256']=p.get('repair_overlay_sha256');meta['repair_base_plan_sha256']=p.get('repair_base_plan_sha256');meta['repair_newly_bound_short_lease']=p.get('repair_newly_bound_short_lease',False);meta['contract_sha256']=FIXED['repair-contract.json'];kind=meta['draft_type'];families[p['family']]+=1
      new=out['mother_reply_text'] or out['alternative_mother_reply_text']
      if k in patchby:
       overlay_replayed+=1
       if sha_text(new)!=patchby[k]['new_preview_sha256']:raise ValueError('repair new preview mismatch '+str(k))
      if new!=olddraft[k]:changed.append({'platform':platform,'cid':k[1],'uid':k[2],'source_comment_sha256':p['sourceSHA'],'selection':selection,'prior_candidate_text':olddraft[k],'repaired_candidate_text':new,'base_plan_sha256':objsha(baseby[k]),'repaired_plan_sha256':objsha(p),'repair_overlay_sha256':p.get('repair_overlay_sha256'),'contract_sha256':FIXED['repair-contract.json']})
      counts[(platform,selection,kind)]+=1;counts[(platform,selection,kind+'_contact_unknown')]+=int(r.get('contact_policy') in (None,'unknown'));counts[(platform,selection,'contact_review_required')]+=int(meta['contact_review_required'])
     else:
      out=copy.deepcopy(r);out['local_mother_candidate']={'status':'basic_draft_pending_pool_binding','selection_preserved':selection,'hold_reasons':p['hold_reasons'],'contact_original':r.get('contact_policy'),'contact_review_required':r.get('contact_policy') in (None,'unknown','manual_review','identity_restricted','manual'),'contact_eligible':'not_assessed','send_authorized':False,'can_send_now':False};counts[(platform,selection,'basic_pending')]+=1;counts[(platform,selection,'basic_pending_contact_unknown')]+=int(r.get('contact_policy') in (None,'unknown'));counts[(platform,selection,'contact_review_required')]+=int(out['local_mother_candidate']['contact_review_required'])
    restored=copy.deepcopy(out);meta=restored.pop('local_mother_candidate',None)
    if meta and meta.get('old_draft_backup'):restored['mother_reply_text']=meta['old_draft_backup']['mother_reply_text'];restored['alternative_mother_reply_text']=meta['old_draft_backup']['alternative_mother_reply_text']
    if restored!=r:raise ValueError('original row could not be restored '+str(k))
    f.write(json.dumps(out,ensure_ascii=False,sort_keys=True,separators=(',',':'))+'\n')
 if seen!=set(by) or overlay_replayed!=813:raise ValueError('coverage mismatch')
 putjl(dst/'draft-change-ledger.jsonl',changed)
 (dst/'published-fix-annotations.jsonl').write_bytes((ABC/'published-fix-annotations.jsonl').read_bytes())
 if families!=collections.Counter({n:d['use_count'] for n,d in matrix.items() if d['use_count']}):raise ValueError('family replay counts mismatch')
 post={p:sha(p) for p in protected}
 if post!=pre:raise ValueError('protected source changed during replay')
 if any(sha(path)!=snap[name] for name,path in files.items()):raise ValueError('live pointer changed during replay')
 def group(c):
  out={}
  for (plat,sel,kind),n in sorted(c.items()):out.setdefault(plat,{}).setdefault(sel,{})[kind]=n
  return out
 outputfiles=['merged-contract.json','merged-plans.jsonl','all-family-matrix.jsonl','douyin-candidate.jsonl','xiaohongshu-candidate.jsonl','draft-change-ledger.jsonl','published-fix-annotations.jsonl'];output_sha={n:sha(dst/n) for n in outputfiles}
 mutable_pointer_paths={str(x.resolve()) for x in files.values()}
 immutable_pre={k:v for k,v in pre.items() if k not in mutable_pointer_paths};immutable_post={k:v for k,v in post.items() if k not in mutable_pointer_paths}
 manifest={'status':'candidate_only_needs_independent_astra_semantic_gate','repair_READY_sha256':FIXED['READY.json'],'repair_manifest_sha256':FIXED['manifest.json'],'repair_contract_sha256':FIXED['repair-contract.json'],'repair_overlay_sha256':FIXED['source-bound-plan-overlays.jsonl'],'immutable_input_sha256_before':immutable_pre,'immutable_input_sha256_after':immutable_post,'immutable_baseline_sha256':snap,'expected_previous_region_pointer_sha256':snap['region-current.json'],'expected_previous_reply_pointer_sha256':snap['reply-pointer.json'],'expected_previous_latest_manifest_sha256':snap['latest-manifest.json'],'note_mutable_pointers':'These hashes bind immutable snapshot bytes; activation preflight compares live old pointers separately. Do not treat a new live pointer as immutable input after activation.','output_sha256':output_sha,'counts':group(counts),'candidate_rows':dict(totals),'classification_counts_unmodified':{'|'.join(str(z) for z in k):n for k,n in class_counts.items()},'families_total':len(matrix),'families_used':len(families),'families_unused':sum(x['unused'] for x in matrix.values()),'actual_plan_render_replays':sum(families.values()),'overlay_replayed':overlay_replayed,'draft_text_changed_from_ABC':len(changed),'published_241_annotations_applied':False,'source_writes':0,'pointer_updates':0,'send_authorized':False}
 dump(dst/'candidate-manifest.json',manifest)
 pointer={'status':manifest['status'],'candidate_manifest':str(dst/'candidate-manifest.json'),'candidate_manifest_sha256':sha(dst/'candidate-manifest.json'),'results':{p:str(dst/(p+'-candidate.jsonl')) for p in cur['results']},'expected_previous_region_pointer_sha256':snap['region-current.json'],'expected_previous_reply_pointer_sha256':snap['reply-pointer.json'],'activated':False,'send_authorized':False};dump(dst/'candidate-pointer.json',pointer)
 print(json.dumps({'status':manifest['status'],'counts':manifest['counts'],'candidate_rows':manifest['candidate_rows'],'families':{'total':len(matrix),'used':len(families),'unused':sum(x['unused'] for x in matrix.values())},'replayed':sum(families.values()),'overlays':overlay_replayed,'drafts_changed':len(changed),'output_sha256':output_sha},ensure_ascii=False))
def sha_text(x):return hashlib.sha256((x or '').encode('utf8')).hexdigest()
if __name__=='__main__':main()
