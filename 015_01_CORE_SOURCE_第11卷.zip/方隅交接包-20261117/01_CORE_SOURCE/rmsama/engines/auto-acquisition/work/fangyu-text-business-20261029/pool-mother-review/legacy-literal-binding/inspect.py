import json,pathlib,collections
W=pathlib.Path('work/fangyu-text-business-20261029');O=W/'pool-mother-review/legacy-literal-binding'
ps=[json.loads(x) for x in (W/'pool-mother-review/legacy-local-planning/local-proposed-plans.jsonl').read_text(encoding='utf8').splitlines()];ps=[p for p in ps if p.get('next_action_category')=='literal_extraction_or_existing_pool_binding_gap'];c=json.loads((W/'region-brand-routing/current.json').read_text(encoding='utf8'));rs={}
for plat,f in c['results'].items():
 for l in pathlib.Path(f).read_text(encoding='utf8').splitlines():
  r=json.loads(l);rs[plat,r['comment_id'],r['customer_uid']]=r
print('count',len(ps));print('holds',collections.Counter(y for p in ps for y in p['hold_reasons']));print('residual',collections.Counter(p.get('unbound_literal_residual') for p in ps).most_common(80));print('pools',collections.Counter(tuple(x['pool'] for x in p['literal_evidence']) for p in ps).most_common(25))
sel=[];seen=set()
for p in sorted(ps,key=lambda p:(not bool(p.get('unbound_literal_residual')),len(p.get('unbound_literal_residual','')))):
 sig=(p.get('unbound_literal_residual'),tuple(x['pool'] for x in p['literal_evidence']),p['platform'])
 if sig in seen:continue
 seen.add(sig);sel.append(p)
# spread through simple residual/multicondition/range cases, forced known examples
sel=sel[:30]+[p for p in ps if p['cid'] in ('7255891470896431930','7255695817427174179')]
for regex in ['附近','公里','沿线','预算','水电','一居','上班','便宜','押','地铁','蹲','不要','不超过']:
 cand=[p for p in ps if regex in rs[p['platform'],p['cid'],p['uid']]['comment_text'] and p not in sel]
 sel.extend(cand[:2])
sel=sel[:56];out=[]
for i,p in enumerate(sel):
 r=rs[p['platform'],p['cid'],p['uid']];out.append(dict(index=i,plan=p,comment=r['comment_text'],source_record=r.get('source_record')));print(i,p['platform'],p['cid'],r['comment_text'],json.dumps({'ev':p['literal_evidence'],'reg':p['source_field_evidence']['target_regions'],'hold':p['hold_reasons'],'rem':p.get('unbound_literal_residual')},ensure_ascii=False))
(O/'representative-input.jsonl').write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in out),encoding='utf8')
