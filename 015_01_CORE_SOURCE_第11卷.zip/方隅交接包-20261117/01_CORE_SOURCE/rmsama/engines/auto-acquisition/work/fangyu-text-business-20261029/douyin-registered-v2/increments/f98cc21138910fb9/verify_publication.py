"""Final evidence for the current classification and bounded short-mother sidecar."""
import collections,json,pathlib,hashlib,datetime,sys
from short_reply_pipeline import load,sha,jl,invariant_sources
B=pathlib.Path(__file__).resolve().parent;W=B.parent.parent.parent;REG=W/'region-brand-routing'
invariant_sources();protected=load(B/'pre-publication-protected-fingerprints.json')
assert all(sha(p)==h for p,h in protected['files_sha256'].items())
summary=load(B/'summary.json');classification=list(jl(summary['result_file']));assert sha(summary['result_file'])==summary['result_sha256'] and len(classification)==34840
assert len({r['comment_id'] for r in classification})==34840 and len({r['customer_uid'] for r in classification})==summary['unique_customers']==32831
assert dict(collections.Counter(r['interest_at_comment'] for r in classification))==summary['interest_counts']
assert all(r['send_authorized'] is False and r['can_send_now'] is False for r in classification)
current=load(REG/'current.json');latest=load(REG/'latest-manifest.json');pointer=load(W/'当前双平台回复结果指针.json');manifest=load(current['manifest']);s=load(current['summary']);v=load(current['validation'])
assert v['all_passed'] and all(v['checks'].values());assert sha(current['manifest'])==current['manifest_sha256']==latest['manifest_sha256'] and latest['manifest']==current['manifest']
assert manifest['platforms']['douyin']['result_sha256']==summary['result_sha256'] and manifest['platforms']['douyin']['count']==34840
for platform,src in manifest['platforms'].items():
 assert sha(src['result_file'])==src['result_sha256'];assert pointer['platforms'][platform]['classification_sha256']==src['result_sha256'];assert pointer['platforms'][platform]['reply_sidecar_sha256']==sha(current['results'][platform])==current['result_sha256'][pathlib.Path(current['results'][platform]).name]
plans={(r['comment_id'],r['customer_uid']):r for r in jl(B/'pool-short-reply-plans.jsonl')};source_keys=set(plans);assert len(source_keys)==807
old=load(B/'coordination-start-safeguards.json')['previous_region_current'];canon=lambda x:hashlib.sha256(json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode('utf-8')).hexdigest()
old_hash={(r['comment_id'],r['customer_uid']):(canon(r['source_record']),canon(r['original_reply'])) for r in jl(old['results']['douyin'])};assert len(old_hash)==34033
rr=list(jl(current['results']['douyin']));xs=list(jl(current['results']['xiaohongshu']));assert len(rr)==34840 and len(xs)==3601
assert sha(current['results']['xiaohongshu'])==sha(old['results']['xiaohongshu'])
new=[];historical=[]
for r in rr:
 key=(r['comment_id'],r['customer_uid']);assert r['send_authorized'] is False and r['can_send_now'] is False and r['assigned_store'] is None
 if key in plans:
  q=plans[key];assert 'pool_short_mother' in r and r['reply_plan']['local_mother']==q['local_mother'];assert (r['mother_reply_text'] or r['alternative_mother_reply_text'])==q['rendered']['text']
  if r['mother_reply_text'] or r['alternative_mother_reply_text']:assert r['unanswered_specific_question'] is True
  new.append(r)
 else:
  assert 'pool_short_mother' not in r;assert old_hash.pop(key)==(canon(r['source_record']),canon(r['original_reply']));historical.append(r)
assert not old_hash and len(new)==807 and len(historical)==34033
dy=s['platforms']['douyin'];assert dy['records']==len(rr)
for platform,rs in [('douyin',rr),('xiaohongshu',xs)]:
 selected=[r for r in rs if r['mother_reply_text']];assert len({r['customer_uid'] for r in selected})==len(selected)==s['platforms'][platform]['selected_local_mother']
 assert dict(collections.Counter(r['interest_at_comment'] for r in rs))==s['platforms'][platform]['interest_counts']
assert sum(bool(r['mother_reply_text']) for r in new)==dy['pool_short_selected']==230
assert sum(bool(r['alternative_mother_reply_text']) for r in new)==dy['pool_short_alternatives']==11
assert sum(bool(r['mother_reply_text']) for r in historical)==dy['historical_basic_selected']==11337
assert sum(bool(r['alternative_mother_reply_text']) for r in historical)==dy['historical_basic_alternatives']==642
assert sum(bool(r['mother_reply_text'] or r['alternative_mother_reply_text']) for r in new)==dy['pool_short_candidates_before_dedup']==241
assert dy['pool_short_held']==566 and dy['pool_short_selected']+dy['historical_basic_selected']==dy['selected_local_mother']==11567
assert sum(bool(r['targeted_compatibility_review']) for r in rr+xs)==124
assert not s['all_34840_converted_to_short_pool_mothers'];assert pointer['platforms']['douyin']['pool_short_selected_drafts']==230 and pointer['platforms']['douyin']['historical_basic_selected_drafts']==11337
for rec in load(B/'preserved-original-independent-audits/preservation-manifest.json')['files']:assert sha(B/rec['backup'])==rec['sha256']
assembly=load(B/'targeted-audit-assembly/validation.json');compile=load(B/'semantic-compile-receipt.json');audit=load(B/'semantic-audit-merge-receipt.json');assert assembly['all_passed'] and compile['unique_comments_with_independent_review']==682 and audit['independent_decisions']==682
idem=load(B/'short-wrapper-idempotence.json');assert idem['all_passed']
result={'all_passed':True,'publication_completed':True,'classification_records':34840,'new_classification_records':807,'historical_classification_records':34033,'unique_customer_accounts':32831,'AI_initial_and_detailed_complete':807,'independent_recall_reviewed':682,'targeted_astra_adjudication_records':12,'targeted_overlap_with_682':12,'targeted_additional_unique':0,'unique_independent_reviewed':682,'audit_changed_records':60,'coordinator_literal_parameter_refinements':1,'new_batch_interest_counts':summary['new_interest_counts'],'classification_interest_counts':summary['interest_counts'],'source_classification_original_basic_drafts':summary['local_mother_drafts'],'current_DY_selected_drafts':11567,'current_DY_pool_short_candidates':241,'current_DY_pool_short_selected':230,'current_DY_pool_short_alternatives':11,'current_DY_pool_short_held':566,'historical_basic_candidates':11979,'historical_basic_selected':11337,'historical_basic_alternatives':642,'original_historical_source_and_reply_preserved':34033,'XHS_records_unchanged':3601,'XHS_selected_drafts_unchanged':950,'targeted_124_preserved':True,'wrapper_idempotence_passed':True,'source_input_primary_original_audits_and_locked_modules_SHA_unchanged':True,'source_database_bytes_SHA_unchanged':True,'classification_file':summary['result_file'],'classification_sha256':summary['result_sha256'],'semantic_final_sha256':sha(B/'semantic-final.jsonl'),'contract_sha256':sha(B/'local-mother-contract.json'),'pool_short_plans_sha256':sha(B/'pool-short-reply-plans.jsonl'),'reply_sidecar_file':current['results']['douyin'],'reply_sidecar_sha256':sha(current['results']['douyin']),'current_reply_pointer_sha256':sha(W/'当前双平台回复结果指针.json'),'region_manifest_sha256':sha(current['manifest']),'pool_short_validation_sha256':sha(B/'pool-short-reply-validation.json'),'all_historical_short_rewritten':False,'reply_body_AI_rewrites':0,'task_specific_usage':'unknown','fee':'unknown','actual_sent_by_this_text_task':0,'platform_delivery_state':'not_checked_by_text_task','source_database_modified':False,'platform_calls':0,'human_confirmed':False,'send_authorized':False,'next_batch_frozen':False,'verified_at':datetime.datetime.now().astimezone().isoformat()}
(B/'publication-verification.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(result,ensure_ascii=False))
