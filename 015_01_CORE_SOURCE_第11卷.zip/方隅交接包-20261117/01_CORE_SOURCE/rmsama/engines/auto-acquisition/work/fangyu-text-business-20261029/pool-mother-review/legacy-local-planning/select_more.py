import json,pathlib,collections
O=pathlib.Path('work/fangyu-text-business-20261029/pool-mother-review/legacy-local-planning');W=O.parents[1]; c=json.loads((W/'region-brand-routing/current.json').read_text(encoding='utf8')); existing={(r['platform'],r['cid'],r['uid']) for l in open(O/'representative-input.jsonl',encoding='utf8') if (r:=json.loads(l))}; ps=[json.loads(l) for l in open(O/'local-proposed-plans.jsonl',encoding='utf8')]; want={'requirements':3,'price_location':2,'location':2,'budget_fit':2,'area':2};got=collections.Counter();added=[];sources={}
for p,f in c['results'].items():
 for l in open(f,encoding='utf8'):
  r=json.loads(l);sources[p,r['comment_id'],r['customer_uid']]=r
for p in ps:
 k=p['platform'],p['cid'],p['uid'];f=p['family']
 if k not in existing and f in want and got[f]<want[f]:
  r=sources[k];got[f]+=1;added.append({'platform':k[0],'cid':k[1],'uid':k[2],'tags':['planned_family:'+f],'text':r['comment_text'],'plan':{'family':f,'fill':p['fill']},'source_record':r.get('source_record')})
for k,r in sources.items():
 if r.get('contact_policy')=='no_contact':
  added.append({'platform':k[0],'cid':k[1],'uid':k[2],'tags':['no_contact_control'],'text':r['comment_text'],'source_record':r.get('source_record')});break
for k,r in sources.items():
 if k in existing:continue
 t=r['comment_text']
 if any(x in t for x in ['含水电','包括水电','水电在内','水电气','水电加']) and ('预算' in t or '以内' in t):
  added.append({'platform':k[0],'cid':k[1],'uid':k[2],'tags':['all_in_budget_scope'],'text':t,'source_record':r.get('source_record')});break
(O/'more-selection.json').write_text(json.dumps(added,ensure_ascii=False,indent=2),encoding='utf8')
for e in added:
 s=e.pop('source_record') or {};a=s.get('classification') or s;e['ev']=a.get('topic_evidence',a.get('actual_pools',a.get('topics')));e['regions']=s.get('target_regions',a.get('target_regions'));e['bounds']=s.get('contact_boundaries');print(json.dumps(e,ensure_ascii=False))
