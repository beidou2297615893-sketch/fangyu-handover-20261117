"""Compare fixes on one frozen cohort; never mutate source data or receipts."""
from collections import Counter
from datetime import datetime
import hashlib
import json
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / 'douyin-semantic-repair-v5'))
import complete_local_demand as completion
import business_fit

folder = Path(sys.argv[1])
status = json.loads((folder / 'status.json').read_text(encoding='utf-8'))
as_of = datetime.fromisoformat(status['active_pool']['as_of']).timestamp()
screen_live = business_fit.screen
business_fit.screen = lambda row, now=None: screen_live(row, as_of)
rows = [json.loads(line) for line in (folder / 'triage-details.jsonl').read_text(encoding='utf-8').splitlines()]
completed = []
restricted_to_review = []
for row in rows:
    before = row['commercial_fit']
    after = business_fit.screen(row)
    if before['exclusion_reasons'] and not after['exclusion_reasons']:
        assert not after['eligible_candidate']
        restricted_to_review.append({'comment_id': row['comment_id'],
                                     'before': before['exclusion_reasons'],
                                     'after': after['verification_required']})
    if row['funnel_group'] != '回复待补':
        continue
    result = completion.complete(row)
    if result:
        assert before['eligible_candidate'] and after['eligible_candidate']
        completed.append(result)

payload = ''.join(json.dumps(row, ensure_ascii=False) + '\n' for row in completed).encode('utf-8')
(folder / 'completion-preview.jsonl').write_bytes(payload)
before_pending = status['pending_candidates_count']
report = {'as_of': status['active_pool']['as_of'], 'cohort_size': len(rows),
          'before_pending': before_pending, 'after_same_cohort_pending': before_pending + len(completed),
          'locally_completed': len(completed),
          'completed_intent': dict(Counter(business_fit.screen(row)['lead_intent'] for row in completed)),
          'technical_waiting_before': sum(row['funnel_group'] == '回复待补' for row in rows),
          'technical_waiting_after': sum(row['funnel_group'] == '回复待补' for row in rows) - len(completed),
          'conditional_restrictions_moved_to_review_not_sendable': restricted_to_review,
          'source_pool_sha256': status['commercial_fit']['all_pool_sha256'],
          'preview_sha256': hashlib.sha256(payload).hexdigest(),
          'rule_version': business_fit.VERSION, 'model_calls': 0,
          'network_requests': 0, 'source_or_receipts_modified': False,
          'comparison_scope': 'same frozen comments, same ledger states, same evaluation time; not live queue count'}
(folder / 'before-after.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps({key: value if not isinstance(value, list) else len(value) for key, value in report.items()}, ensure_ascii=False))
