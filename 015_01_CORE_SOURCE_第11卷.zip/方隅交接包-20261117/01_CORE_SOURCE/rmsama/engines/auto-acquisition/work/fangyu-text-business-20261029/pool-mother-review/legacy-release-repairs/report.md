# 合并历史计划的共性修补候选

仅修计划、槽位和本地合同，未发布。冻结A/B/C、原QA、源分类、指针和50条用户稿保持不变。
扫描原已绑定 6689 条，产生 813 条有行为变化的来源绑定覆盖计划。另新增纯短租最小确认 5 条，单列并保留原hold依据。
修后住房家族 6524 条、确认接话 170 条、具体待核 6269 条。覆盖数是技术统计，不是语义准确率或可发送率。

共性修补覆盖报价周期、比较符和金额边界、价位与本人预算、源报价预设、联系方向/渠道、看房动作、推荐找房与流程、未知“多少”指标、短租重叠槽、点名/这套对象、比较价参照和原AI未决地点。原客户条件及语义警告保持，不凭缺库存或住户/优惠事实未核而一律阻止纯草稿。

A/B200、15回归、C60、C1回归和C6边界在旧QA回归对照中保留；全部已经用于整改，不算新留出或新语义全通过。A117按实际标题一室一厅的住宅线索修对象关系，不沿用旧QA错误的用途未明描述。短租多久不添加最长；有500等数字不凭pool/polarity改成客户预算。

本轮等待root与现有QA独立复核。原源写0、指针改0、新直接API请求0、本地渲染模型调用0、平台0、发送0；整体agent判读token用量未知。

{
  "base_total_plans": 12963,
  "base_bound_housing": 6660,
  "base_bound_clarification": 29,
  "overlays": 813,
  "overlays_by_base_origin": {
    "C": 470,
    "B": 114,
    "A": 229
  },
  "original_bound_risk_scanned": 6689,
  "newly_bound_short_lease_clarifications": 5,
  "new_housing_plans": 6524,
  "new_clarification_plans": 170,
  "held_after": 6269,
  "new_holds_from_bound": 0,
  "repair_reason_counts": {
    "preserve_comparative_price_demonstrative": 6,
    "comparison_reference_kept_as_question_not_absolute_price": 6,
    "shared_template_or_slot_mode_repair": 562,
    "unresolved_comparison_anchor_kept_as_minimal_price_reference_question": 6,
    "named_quote_object_relation_unresolved_not_guessed_project_or_area": 1,
    "price_condition_no_presumed_source_advertised_price": 95,
    "preserve_explicit_literal_price_cycle_separate_from_lease_duration": 196,
    "preserve_deictic_housing_or_price_kind_reference_not_unreferenced_demand": 94,
    "neutral_quote_cycle_not_impose_monthly_price": 47,
    "contact_how_question_kept_as_method_not_forced_customer_action": 48,
    "shared_contract_neutral_quote_cycle_change": 39,
    "preserve_contact_to_customer_direction_and_original_private_channel": 26,
    "preserve_specific_original_unit_reference_not_generic_fangyu_inventory": 49,
    "merge_redundant_utility_standard_and_preserve_original_alternatives": 1,
    "retain_contact_method_in_addition_to_viewing": 2,
    "numeric_condition_not_inferred_customer_budget_from_pool_polarity": 77,
    "retain_unknown_numeric_indicator_without_reclassifying_pool": 32,
    "merge_overlapping_lease_literal_slots_without_new_duration": 35,
    "preserve_private_channel_without_inventing_initiator": 8,
    "source_referenced_price_not_fangyu_quote": 1,
    "source_advertised_quote_relation_kept_as_question_not_own_brand_price": 1,
    "preserve_literal_room_apartment_type": 1,
    "retain_home_search_recommendation_not_rent_process": 12,
    "existing_AI_unresolved_site_requires_literal_location_confirmation": 3,
    "merge_overlapping_short_and_monthly_lease_modes_no_price_cycle_inference": 1,
    "monthly_lease_mode_question_separate_from_quote_cycle": 1,
    "authorized_small_addition_short_lease_duration_unknown_not_monthly_quote": 5,
    "preserve_literal_price_comparator_qualifier_cycle": 4,
    "retain_viewing_counterparty_preference_without_sender_identity_claim": 1,
    "housing_is_evident_confirm_source_object_relation_not_unknown_residential_use": 2,
    "original_blocking_or_title_context_requires_object_clarification_not_promotion": 74
  },
  "old_QA_regression_count": 285,
  "old_QA_wrong_context_corrected": 1,
  "base_family_count": 187,
  "merged_original_contract_family_count": 209,
  "repaired_contract_family_count": 366,
  "duplicate_equivalent_definitions": []
}
