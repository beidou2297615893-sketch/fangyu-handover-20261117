"""Bounded-memory, offline derivation from an immutable acquisition ledger.

Only this module's separate SQLite state and requested exports are written. No
platform, model, HTTP or credential client is imported. Source records are never
attached to the writable database. Historical model judgments remain references.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import sqlite3
import tempfile
import time
import uuid

HERE = Path(__file__).resolve().parent
WORK = HERE.parent
ROOT = WORK.parents[1]
BASE = ROOT / 'work' / 'fangyu-douyin-independent'
DEFAULT_SOURCE = BASE / 'runtime' / 'collection.sqlite3'
DEFAULT_STATE = HERE / 'state'
DEFAULT_POLICY = BASE / 'runner-audit-myeaj720' / 'runner-qualification-policy.json'
DEFAULT_MOTHERS = WORK / 'mothers' / 'first50.json'
LEGACY_POINTER = BASE / 'text-screening-current-summary.json'
COMMIT_SIZE = 500

def dumps(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'))

def digest(value):
    return hashlib.sha256(dumps(value).encode('utf8')).hexdigest()

def load_json(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))

def atomic_json(path, value):
    path = Path(path)
    temp = path.with_name(path.name + '.tmp-' + str(os.getpid()))
    temp.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding='utf8')
    os.replace(temp, path)

def open_source(path):
    db = sqlite3.connect(Path(path).resolve().as_uri() + '?mode=ro', uri=True)
    db.execute('PRAGMA query_only=ON')
    db.execute('BEGIN')
    # WITHOUT ROWID sources cannot support the incremental cursor contract.
    for table in ('entities', 'observations'):
        db.execute(f'SELECT rowid FROM {table} LIMIT 1').fetchone()
    return db

def open_state(directory):
    directory.mkdir(parents=True, exist_ok=True)
    db = sqlite3.connect(directory / 'derived.sqlite3', timeout=30)
    db.execute('PRAGMA journal_mode=WAL')
    db.execute('PRAGMA synchronous=FULL')
    db.executescript('''
    CREATE TABLE IF NOT EXISTS meta(key TEXT PRIMARY KEY,value TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS observations(
      platform TEXT NOT NULL,source_rowid INTEGER NOT NULL,request_id TEXT NOT NULL,
      stable_key TEXT NOT NULL,account_uid TEXT,store_id TEXT,keyword TEXT,target TEXT,
      collected_at TEXT,identity_digest TEXT,malformed INTEGER NOT NULL DEFAULT 0,
      PRIMARY KEY(platform,source_rowid));
    CREATE INDEX IF NOT EXISTS obs_key ON observations(platform,stable_key,request_id);
    CREATE INDEX IF NOT EXISTS obs_request ON observations(platform,request_id,stable_key);
    CREATE TABLE IF NOT EXISTS qualified(
      platform TEXT,request_id TEXT,target TEXT,account_uid TEXT,qualification TEXT,
      PRIMARY KEY(platform,request_id));
    CREATE TABLE IF NOT EXISTS videos(
      platform TEXT,video_id TEXT,body TEXT,author_uid TEXT,context_digest TEXT,
      PRIMARY KEY(platform,video_id));
    CREATE TABLE IF NOT EXISTS results(
      platform TEXT NOT NULL,comment_id TEXT NOT NULL,stable_key TEXT NOT NULL,
      customer_uid TEXT,method TEXT,rule_version TEXT,input_digest TEXT,
      interest TEXT,role TEXT,exception_type TEXT,needs_model_review INTEGER,
      batch_id TEXT,data TEXT NOT NULL,PRIMARY KEY(platform,comment_id));
    CREATE INDEX IF NOT EXISTS result_stable ON results(platform,stable_key);
    CREATE INDEX IF NOT EXISTS result_batch ON results(batch_id);
    CREATE INDEX IF NOT EXISTS result_method ON results(method);
    CREATE TABLE IF NOT EXISTS result_identities(
      platform TEXT,stable_key TEXT,comment_id TEXT,customer_uid TEXT,identity_digest TEXT,
      PRIMARY KEY(platform,stable_key));
    CREATE TABLE IF NOT EXISTS source_audits(
      platform TEXT,stable_key TEXT,comment_id TEXT,customer_uid TEXT,data TEXT,
      PRIMARY KEY(platform,stable_key));
    CREATE INDEX IF NOT EXISTS source_audit_customer ON source_audits(platform,customer_uid);
    CREATE TABLE IF NOT EXISTS result_topics(
      platform TEXT,comment_id TEXT,pool TEXT,PRIMARY KEY(platform,comment_id,pool));
    CREATE TABLE IF NOT EXISTS candidates(
      platform TEXT,customer_key TEXT,comment_id TEXT,batch_id TEXT,data TEXT,
      PRIMARY KEY(platform,customer_key));
    CREATE INDEX IF NOT EXISTS candidate_batch ON candidates(batch_id);
    CREATE TABLE IF NOT EXISTS exceptions(
      platform TEXT,comment_id TEXT,exception_type TEXT,scenario TEXT,
      needs_model_review INTEGER,data TEXT,PRIMARY KEY(platform,comment_id));
    CREATE INDEX IF NOT EXISTS exception_group ON exceptions(needs_model_review,scenario);
    CREATE TABLE IF NOT EXISTS runs(
      batch_id TEXT PRIMARY KEY,created_at REAL,exported INTEGER DEFAULT 0);
    ''')
    return db

def meta_get(db, key, default=None):
    row = db.execute('SELECT value FROM meta WHERE key=?', (key,)).fetchone()
    return row[0] if row else default

def meta_set(db, key, value):
    db.execute('INSERT OR REPLACE INTO meta VALUES(?,?)', (key, str(value)))

def identity(item):
    user = item.get('user') if isinstance(item.get('user'), dict) else {}
    return digest([item.get('text') or '', str(user.get('uid', '')), str(item.get('aweme_id', ''))])

def deactivate_draft(result,status):
    result.update(mother_slot=None,mother_reply_text=None,draft_ready=False,draft_text=None,slot=None,
                  reply_status=status,reply_generation_model_calls=0,send_authorized=False,can_send_now=False)
    return result

def candidate_is_eligible(result,candidate,mothers):
    if (result.get('role') not in ('demand','mixed') or result.get('interest_at_comment') not in ('super_high','high','medium')
        or result.get('demand_state') in ('ended','historical') or result.get('needs_model_review')
        or result.get('exception_type') or result.get('source_version_conflict') or result.get('source_error')
        or result.get('contact_boundaries') or result.get('context_flags') or not candidate.get('mother_reply_text')):
        return False
    approved=[m for m in mothers if m.get('user_approved') is True and m.get('slot')==candidate.get('mother_slot')]
    return bool(approved and candidate['mother_reply_text'] in
                (approved[0]['template'],approved[0]['template'].removeprefix('宝宝，')))

def store_result(db, result, batch, method, input_hash, rule_version, candidate=None):
    platform = result['platform']; cid = str(result['comment_id'])
    if db.execute('SELECT 1 FROM results WHERE platform=? AND comment_id=?',(platform,cid)).fetchone():
        return False
    result = dict(result)
    result.update(classification_method=method, method=method, input_digest=input_hash,
                  rule_version=rule_version, current_need_verified=False, assigned_store=None,
                  send_authorized=False, can_send_now=False)
    uid = str(result.get('customer_uid') or '')
    if method=='historical_model_reference' and result.get('mother_reply_text'):
        result['historical_mother_reference']={k:result.get(k) for k in
            ('mother_slot','mother_reply_text','draft_ready','draft_text','slot','reply_status')}
    deactivate_draft(result,'未形成当前合格本地候选')
    if candidate and candidate.get('mother_reply_text'):
        # Unknown authors cannot be treated as one person or contacted blindly.
        if uid:
            candidate = dict(candidate, platform=platform, comment_id=cid, customer_uid=uid,
                             send_authorized=False, can_send_now=False,draft_ready=True,
                             draft_text=candidate['mother_reply_text'],slot=candidate.get('mother_slot'),
                             reply_generation_model_calls=0)
            changed = db.execute('INSERT OR IGNORE INTO candidates VALUES(?,?,?,?,?)',
                (platform, uid, cid, batch, dumps(candidate))).rowcount
            if not changed:
                result['alternative_mother_reply_text'] = candidate['mother_reply_text']
                deactivate_draft(result,'同客户已有本地候选，不重复入队')
            else:
                result.update(candidate)
        else:
            result['mother_reply_text'] = None
    inserted = db.execute('INSERT OR IGNORE INTO results VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)',
        (platform,cid,result.get('source_stable_key') or 'comment:'+cid,uid,method,rule_version,
         input_hash,result.get('interest_at_comment','uncertain'),result.get('role','unknown'),
         result.get('exception_type'),int(bool(result.get('needs_model_review'))),batch,dumps(result))).rowcount
    if not inserted:
        return False
    stable_key=result.get('source_stable_key') or 'comment:'+cid
    if 'comment_text' in result and uid and result.get('video_id') and not result.get('source_version_conflict'):
        baseline=digest([result.get('comment_text') or '',uid,str(result.get('video_id') or '')])
        db.execute('INSERT OR IGNORE INTO result_identities VALUES(?,?,?,?,?)',(platform,stable_key,cid,uid,baseline))
    for topic in result.get('topics', []):
        pool = topic.get('pool') if isinstance(topic, dict) else topic
        if pool:
            db.execute('INSERT OR IGNORE INTO result_topics VALUES(?,?,?)',(platform,cid,pool))
    kind = result.get('exception_type')
    if kind or result.get('needs_model_review'):
        # Scenario grouping never shares a person's budget, date or role judgment.
        scenario = dumps({'type':kind or 'semantic_review','rule_hits':sorted(str(x) for x in result.get('rule_hits',[]))})
        example = {k:result.get(k) for k in ('platform','comment_id','comment_text','review_reasons','reason','exception_type')}
        db.execute('INSERT INTO exceptions VALUES(?,?,?,?,?,?)',
            (platform,cid,kind,scenario,int(bool(result.get('needs_model_review'))),dumps(example)))
    return True

def import_legacy(db, legacy, default_platform, mothers):
    if not legacy or meta_get(db, 'legacy_import_complete'):
        return 0
    legacy = Path(legacy).resolve()
    old = meta_get(db,'legacy_import_path')
    if old and old != str(legacy):
        raise ValueError('Interrupted historical import points to a different file')
    meta_set(db,'legacy_import_path',legacy)
    count = 0; h = hashlib.sha256()
    with legacy.open('rb') as stream:
        for raw in stream:
            h.update(raw)
            if not raw.strip(): continue
            result = json.loads(raw.decode('utf-8-sig'))
            if not isinstance(result,dict) or not result.get('comment_id'):
                raise ValueError('Historical record lacks stable comment identity')
            result = dict(result);result.setdefault('platform',default_platform)
            result['historical_classification_method'] = result.get('classification_method',result.get('review_method'))
            candidate = {k:result.get(k) for k in ('mother_slot','mother_reply_text','reply_status')}
            if not candidate_is_eligible(result,candidate,mothers): candidate={}
            count += store_result(db,result,'legacy','historical_model_reference',digest(result),
                                  result.get('rule_version','historical_unknown'),candidate)
            if count and count % COMMIT_SIZE == 0: db.commit()
    meta_set(db,'legacy_import_sha256',h.hexdigest())
    meta_set(db,'legacy_import_complete',1)
    db.commit()
    return count

def refresh_metadata(source, state, platform, policy):
    prefix = platform + ':'
    last = int(meta_get(state,prefix+'observation_rowid',0))
    maximum = source.execute('SELECT coalesce(max(rowid),0) FROM observations').fetchone()[0]
    if maximum < last: raise ValueError('Source observation rowids moved backwards; audit source replacement')
    cursor = source.execute('''SELECT rowid,request_id,stable_key,account_uid,store_id,keyword,target,collected_at,data,kind
                              FROM observations WHERE rowid>? ORDER BY rowid''',(last,))
    copied = 0
    for rowid,rid,key,account,store,word,target,at,raw,kind in cursor:
        if kind == 'comments':
            try: ih=identity(json.loads(raw)); malformed=0
            except (ValueError,TypeError,AttributeError): ih=digest(['malformed',raw]);malformed=1
            state.execute('INSERT OR IGNORE INTO observations VALUES(?,?,?,?,?,?,?,?,?,?,?)',
                (platform,rowid,rid,key,account,store,word,str(target),at,ih,malformed))
            copied += 1
        meta_set(state,prefix+'observation_rowid',rowid)
        if rowid % COMMIT_SIZE == 0: state.commit()
    state.commit()
    # Refresh all parsed eligibility, including older unknown requests. A rowid
    # watermark on attempts would permanently miss in-place state transitions.
    state.execute('DELETE FROM qualified WHERE platform=?',(platform,))
    manual = set(policy.get('qualified_request_ids',[]))
    for rid,raw in source.execute("SELECT request_id,spec FROM attempts WHERE state='parsed'"):
        try: spec=json.loads(raw)
        except (ValueError,TypeError): continue
        if not isinstance(spec,dict) or spec.get('kind')!='comments': continue
        eligibility = spec.get('eligibility')
        is_manual = rid in manual
        if is_manual:
            valid = bool(policy.get('account_uid')) and spec.get('account_uid') == policy['account_uid']
        else:
            valid = isinstance(eligibility,dict) and eligibility.get('state')=='eligible'
        if not valid: continue
        state.execute('INSERT INTO qualified VALUES(?,?,?,?,?)',
            (platform,rid,str(spec.get('target','')),str(spec.get('account_uid') or ''),
             'manual_source_policy' if is_manual else 'eligible_source_spec'))
    state.commit()
    last = int(meta_get(state,prefix+'entity_rowid',0))
    maximum = source.execute('SELECT coalesce(max(rowid),0) FROM entities').fetchone()[0]
    if maximum < last: raise ValueError('Source entity rowids moved backwards; audit source replacement')
    for rowid,vid,raw in source.execute("SELECT rowid,source_id,data FROM entities WHERE rowid>? AND kind='search' ORDER BY rowid",(last,)):
        try:
            video=json.loads(raw);author=video.get('author') or {}
            uid=str(author.get('uid',video.get('author_user_id','')) or '')
            body=video.get('desc') or ''
        except (ValueError,TypeError,AttributeError): body='';uid=''
        state.execute('INSERT OR REPLACE INTO videos VALUES(?,?,?,?,?)',(platform,str(vid),body,uid,digest([body,uid])))
    meta_set(state,prefix+'entity_rowid',maximum)
    state.commit()
    return copied

QUALIFIED_JOIN = '''o.platform=q.platform AND o.request_id=q.request_id AND o.target=q.target
 AND (q.account_uid='' OR o.account_uid=q.account_uid)'''

ACTIVE_CANDIDATE = '''NOT EXISTS(SELECT 1 FROM source_audits a
                                  WHERE a.platform=c.platform AND a.customer_uid=c.customer_key)'''

def audit_existing_identities(state,platform):
    # A newly qualified/re-observed version can conflict with an old judgment.
    # Keep that judgment immutable; add an independent audit and suspend drafts.
    for key,cid,uid,count in state.execute(f'''SELECT i.stable_key,i.comment_id,i.customer_uid,count(*)
       FROM result_identities i JOIN observations o ON o.platform=i.platform AND o.stable_key=i.stable_key
       JOIN qualified q ON {QUALIFIED_JOIN} WHERE i.platform=? AND i.identity_digest<>o.identity_digest
       GROUP BY i.stable_key,i.comment_id,i.customer_uid''',(platform,)):
        audit={'platform':platform,'comment_id':cid,'source_stable_key':key,'exception_type':'source_integrity_late',
               'reason':'后续合格观察与已保存评论的文字、作者或作品不一致；原判断保留为历史记录，母句暂停',
               'conflicting_observations_at_first_audit':count,'needs_model_review':False,'model_calls':0}
        state.execute('INSERT OR IGNORE INTO source_audits VALUES(?,?,?,?,?)',(platform,key,cid,uid,dumps(audit)))
    state.commit()

def make_record(source,state,platform,key,rule_version):
    row=source.execute("SELECT source_id,data FROM entities WHERE stable_key=? AND kind='comments'",(key,)).fetchone()
    source_error=None
    if row:
        cid,raw=row
        try: item=json.loads(raw)
        except (ValueError,TypeError): item={};source_error='malformed_source_entity'
        if not isinstance(item,dict): item={};source_error='source_entity_not_object'
    else: cid=key.removeprefix('comment:');item={};source_error='missing_source_entity'
    user=item.get('user') if isinstance(item.get('user'),dict) else {}
    uid=user.get('uid'); video=str(item.get('aweme_id') or '')
    if not isinstance(cid,str) or not isinstance(uid,str) or item.get('cid')!=cid:
        source_error=source_error or 'source_identity_invalid'
    uid=str(uid or '');cid=str(cid)
    post=state.execute('SELECT body,author_uid FROM videos WHERE platform=? AND video_id=?',(platform,video)).fetchone()
    body,author=post if post else ('','')
    observations=[];first_digest=None;conflict=False;malformed=False;count=0;oh=hashlib.sha256()
    for rid,store,word,target,at,ih,bad,qualification in state.execute(f'''SELECT o.request_id,o.store_id,o.keyword,o.target,
        o.collected_at,o.identity_digest,o.malformed,q.qualification FROM observations o JOIN qualified q ON {QUALIFIED_JOIN}
        WHERE o.platform=? AND o.stable_key=? ORDER BY o.source_rowid''',(platform,key)):
        count+=1;conflict |= first_digest is not None and first_digest!=ih;first_digest=first_digest or ih
        malformed |= bool(bad)
        obs={'request_id':rid,'source_store':store,'keyword':word,'video_id':target,'observed_at':at,'qualification':qualification}
        oh.update(dumps([obs,ih]).encode('utf8'))
        if len(observations)<100: observations.append(obs)
    conflict |= bool(first_digest and first_digest!=identity(item))
    return {'platform':platform,'comment_id':cid,'customer_uid':uid,'video_id':video,
       'comment_text':item.get('text') or '','published_at_unix':item.get('create_time'),
       'post_body':body,'post_author_uid':author,'post_author_same_as_commenter':bool(uid and uid==author),
       'direct_parent_text':None,'reply_to':str(item.get('reply_id','0')),
       'deeper_reply_count_visible':item.get('reply_comment_total',0),'deeper_replies_read':False,
       'ip_location_raw':item.get('ip_label'),'ip_is_not_target_region':True,
       'source_stable_key':key,'source_observations':observations,'source_observation_count':count,
       'source_observations_truncated':count>100,'source_observations_digest':oh.hexdigest(),
       'source_version_conflict':conflict,'source_error':source_error or ('malformed_source_observation' if malformed else None),
       'source_comment_sha256':hashlib.sha256((item.get('text') or '').encode('utf8')).hexdigest(),
       'rule_version':rule_version,'send_authorized':False}

def source_exception(record):
    return dict(record,role='unknown',demand_state='unknown',interest_at_comment='uncertain',topics=[],
       topic_evidence=[],possible_topics=[],target_regions=[],time_mentions=[],other_constraints=[],evidence=[],
       reason='来源身份或版本不一致，保留原始账本待核对',review_reasons=[record.get('source_error') or 'source_version_conflict'],
       exception_type='source_integrity',needs_model_review=False,classification_method='local_source_guard',rule_hits=[],model_calls=0)

def export_rows(path,cursor):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    temp=path.with_name(path.name+'.tmp-'+str(os.getpid()))
    with temp.open('w',encoding='utf8',newline='\n') as stream:
        for (raw,) in cursor: stream.write(raw+'\n')
    os.replace(temp,path)

def export_complete(db,path):
    def rows():
        for raw,audit,blocked in db.execute('''SELECT r.data,a.data,
            EXISTS(SELECT 1 FROM source_audits b WHERE b.platform=r.platform AND b.customer_uid=r.customer_uid)
            FROM results r LEFT JOIN source_audits a ON a.platform=r.platform AND a.stable_key=r.stable_key
            ORDER BY r.platform,r.comment_id'''):
            if audit or blocked:
                item=json.loads(raw)
                if audit: item.update(source_integrity_audit=json.loads(audit),source_version_conflict=True)
                item.update(contact_candidate_suspended='同客户来源记录冲突待核')
                deactivate_draft(item,'来源版本冲突，当前母句暂停')
                raw=dumps(item)
            yield (raw,)
    export_rows(path,rows())

def export_batches(db,state_dir):
    directory=state_dir/'increments';directory.mkdir(exist_ok=True)
    for (batch,) in db.execute('SELECT batch_id FROM runs WHERE exported=0 ORDER BY created_at').fetchall():
        target=directory/batch;target.mkdir(exist_ok=True)
        export_rows(target/'results.jsonl',db.execute('SELECT data FROM results WHERE batch_id=? ORDER BY platform,comment_id',(batch,)))
        export_rows(target/'mother-drafts.jsonl',db.execute(f'SELECT c.data FROM candidates c WHERE c.batch_id=? AND {ACTIVE_CANDIDATE} ORDER BY c.platform,c.customer_key',(batch,)))
        db.execute('UPDATE runs SET exported=1 WHERE batch_id=?',(batch,));db.commit()

def grouped_exceptions(db,path,model_only=False):
    where='WHERE needs_model_review=1' if model_only else ''
    # SQLite does the grouping; retain at most three examples per scenario.
    cursor=db.execute(f'''SELECT scenario,exception_type,needs_model_review,count(*) FROM exceptions {where}
                          GROUP BY scenario,exception_type,needs_model_review ORDER BY scenario''')
    temp=path.with_name(path.name+'.tmp-'+str(os.getpid()))
    with temp.open('w',encoding='utf8') as stream:
        for scenario,kind,review,count in cursor:
            examples=[json.loads(row[0]) for row in db.execute('SELECT data FROM exceptions WHERE scenario=? AND needs_model_review=? ORDER BY platform,comment_id LIMIT 3',(scenario,review))]
            stream.write(dumps({'scenario':json.loads(scenario),'exception_type':kind,'needs_model_review':bool(review),'count':count,'examples':examples})+'\n')
        if not model_only:
            count=db.execute('SELECT count(*) FROM source_audits').fetchone()[0]
            if count:
                examples=[json.loads(row[0]) for row in db.execute('SELECT data FROM source_audits ORDER BY platform,stable_key LIMIT 3')]
                stream.write(dumps({'scenario':{'type':'source_integrity_late'},'exception_type':'source_integrity_late',
                                    'needs_model_review':False,'count':count,'examples':examples})+'\n')
    os.replace(temp,path)

def aggregate(db):
    def counts(sql): return dict(db.execute(sql))
    return {'snapshot_unique_comments':db.execute('SELECT count(*) FROM results').fetchone()[0],
      'unique_customers':db.execute("SELECT count(*) FROM (SELECT platform,customer_uid FROM results WHERE customer_uid<>'' GROUP BY platform,customer_uid)").fetchone()[0],
      'interest_counts':counts('SELECT interest,count(*) FROM results GROUP BY interest'),
      'method_counts':counts('SELECT method,count(*) FROM results GROUP BY method'),
      'pool_counts':counts('SELECT pool,count(*) FROM result_topics GROUP BY pool'),
      'exception_counts':counts('SELECT coalesce(exception_type,\'unspecified\'),count(*) FROM exceptions GROUP BY exception_type'),
      'local_mother_drafts':db.execute(f'SELECT count(*) FROM candidates c WHERE {ACTIVE_CANDIDATE}').fetchone()[0],
      'source_integrity_audits':db.execute('SELECT count(*) FROM source_audits').fetchone()[0],
      'needs_model_review':db.execute('SELECT count(*) FROM exceptions WHERE needs_model_review=1').fetchone()[0]}

def run_pipeline(*,source_db=DEFAULT_SOURCE,state_dir=DEFAULT_STATE,legacy_result=None,policy_path=DEFAULT_POLICY,
                 mothers_path=DEFAULT_MOTHERS,max_new=5000,platform='douyin',dry_run=False,
                 verification_run=False,export_all=None,classifier=None,config_path=None):
    if not 0 <= max_new <= 5000: raise ValueError('max_new must be between 0 and 5000')
    source_db=Path(source_db).resolve();state_dir=Path(state_dir).resolve()
    if source_db==(state_dir/'derived.sqlite3').resolve():
        raise ValueError('Derived state database must be separate from the source database')
    if platform not in ('douyin','xiaohongshu'): raise ValueError('Unsupported platform namespace')
    is_official=source_db==DEFAULT_SOURCE.resolve()
    if verification_run and state_dir==DEFAULT_STATE.resolve():
        raise ValueError('verification-run requires an isolated --state-dir')
    if is_official and not (dry_run or verification_run):
        manifest=load_json(HERE/'manifest.json') if (HERE/'manifest.json').exists() else {}
        if manifest.get('status')!='verified': raise PermissionError('Pipeline manifest is not verified; use --dry-run or isolated --verification-run')
    if dry_run:
        with tempfile.TemporaryDirectory(prefix='fangyu-local-dry-') as directory:
            result=run_pipeline(source_db=source_db,state_dir=directory,legacy_result=legacy_result,policy_path=policy_path,
                mothers_path=mothers_path,max_new=max_new,platform=platform,verification_run=True,classifier=classifier,config_path=config_path)
            result.update(dry_run=True,temporary_outputs_removed=True)
            return result
    started=time.perf_counter()
    policy=load_json(policy_path) if policy_path and Path(policy_path).exists() else {}
    mothers=load_json(mothers_path)
    if legacy_result is None and is_official and LEGACY_POINTER.exists():
        legacy_result=load_json(LEGACY_POINTER)['result_file']
    protected={source_db,DEFAULT_SOURCE.resolve(),LEGACY_POINTER.resolve(),(state_dir/'derived.sqlite3').resolve(),
               (state_dir/'derived.sqlite3-wal').resolve(),(state_dir/'derived.sqlite3-shm').resolve(),
               (state_dir/'local-current-summary.json').resolve(),(HERE/'manifest.json').resolve()}
    if legacy_result: protected.add(Path(legacy_result).resolve())
    if export_all and Path(export_all).resolve() in protected:
        raise ValueError('Export path would overwrite a protected source, historical reference or state file')
    version_files=[HERE/'local_classifier.py',Path(config_path) if config_path else HERE/'rule_config.json']
    vh=hashlib.sha256()
    for path in version_files:
        if path.exists(): vh.update(path.read_bytes())
    rule_version='local-rules-'+vh.hexdigest()[:16]
    if classifier is None:
        from local_classifier import LocalClassifier
        classifier=LocalClassifier(config_path=config_path)
    selector=getattr(classifier,'choose_mother',None)
    if selector is None:
        from local_classifier import choose_mother
        selector=choose_mother
    source=open_source(source_db);state=open_state(state_dir)
    batch=time.strftime('%Y%m%dT%H%M%S')+'-'+uuid.uuid4().hex[:12]
    try:
        previous_legacy=meta_get(state,'legacy_import_path')
        if export_all and previous_legacy and Path(export_all).resolve()==Path(previous_legacy).resolve():
            raise ValueError('Export would overwrite the saved historical reference')
        previous_source=meta_get(state,platform+':source_path')
        if previous_source and previous_source!=str(source_db): raise ValueError('State belongs to a different source database')
        meta_set(state,platform+':source_path',source_db)
        imported=import_legacy(state,legacy_result,platform,mothers)
        copied=refresh_metadata(source,state,platform,policy)
        # Missing-result filtering occurs exclusively on indexed derived metadata.
        keys=[row[0] for row in state.execute(f'''SELECT DISTINCT o.stable_key FROM observations o
            JOIN qualified q ON {QUALIFIED_JOIN} LEFT JOIN results r ON r.platform=o.platform AND r.stable_key=o.stable_key
            WHERE o.platform=? AND r.comment_id IS NULL ORDER BY o.stable_key LIMIT ?''',(platform,max_new))]
        state.execute('INSERT INTO runs(batch_id,created_at) VALUES(?,?)',(batch,time.time()))
        new=0
        for key in keys:
            record=make_record(source,state,platform,key,rule_version)
            ih=digest(record)
            if record['source_error'] or record['source_version_conflict']:
                result=source_exception(record)
            else:
                result=classifier.classify(record)
                result=dict(record,**result)
            if result.get('model_calls',0)!=0: raise ValueError('Offline classifier reported model calls')
            result.update(model_calls=0,send_authorized=False,can_send_now=False,assigned_store=None,current_need_verified=False)
            candidate=selector(result,mothers)
            if not isinstance(candidate,dict): raise ValueError('Mother selector must return an object')
            # Guard the selector at the coordinator boundary, including test stubs.
            if not candidate_is_eligible(result,candidate,mothers): candidate={}
            new+=store_result(state,result,batch,result.get('classification_method','local_rule'),ih,rule_version,candidate)
            if new and new%COMMIT_SIZE==0: state.commit()
        state.commit();source.rollback()
        audit_existing_identities(state,platform)
        export_batches(state,state_dir)
        if export_all:
            export_complete(state,Path(export_all))
        grouped_exceptions(state,state_dir/'exception-groups.jsonl')
        grouped_exceptions(state,state_dir/'semantic-review-groups.jsonl',True)
        summary=aggregate(state)
        eligible,pending=state.execute(f'''SELECT count(DISTINCT o.stable_key),
            count(DISTINCT CASE WHEN r.comment_id IS NULL THEN o.stable_key END)
            FROM observations o JOIN qualified q ON {QUALIFIED_JOIN}
            LEFT JOIN results r ON r.platform=o.platform AND r.stable_key=o.stable_key WHERE o.platform=?''',(platform,)).fetchone()
        summary.update(newly_analyzed=new,historical_imported=imported,observations_copied=copied,
          eligible_snapshot_comments=eligible,pending_eligible_comments=pending,
          eligible_request_count=state.execute('SELECT count(*) FROM qualified WHERE platform=?',(platform,)).fetchone()[0],
          result_store=str(state_dir/'derived.sqlite3'),result_storage='sqlite_streaming',result_file=None,
          export_all_file=str(Path(export_all).resolve()) if export_all else None,
          increment_file=str(state_dir/'increments'/batch/'results.jsonl'),
          mother_increment_file=str(state_dir/'increments'/batch/'mother-drafts.jsonl'),
          batch_id=batch,rule_version=rule_version,legacy_result_file=meta_get(state,'legacy_import_path'),
          legacy_result_sha256=meta_get(state,'legacy_import_sha256'),accuracy=None,accuracy_status='unknown_without_independent_human_gold',
          source_database_modified=False,source_query_only=bool(source.execute('PRAGMA query_only').fetchone()[0]),
          source_connection_total_changes=source.total_changes,platform_calls=0,model_calls=0,has_model_calls=False,actual_sent=0,
          send_authorized=False,can_send_now=0,verification_run=verification_run,dry_run=False,
          snapshot_not_live_total=True,elapsed_seconds=round(time.perf_counter()-started,4))
        # This new pointer is deliberately distinct from the original model pointer.
        atomic_json(state_dir/'local-current-summary.json',summary)
        atomic_json(state_dir/'increments'/batch/'summary.json',summary)
        labels={'super_high':'超高','high':'高','medium':'中','low':'低','very_low':'很低','uncertain':'待核','unrelated':'不相关或已结束'}
        note=['评论本地处理汇总','',f'当前保留{summary["snapshot_unique_comments"]}条评论，本批新增判断{new}条。',
          '意向：'+'；'.join(labels.get(k,k)+' '+str(v) for k,v in summary['interest_counts'].items())+'。',
          f'历史模型参考{summary["method_counts"].get("historical_model_reference",0)}条；本地母句候选{summary["local_mother_drafts"]}位客户。',
          f'有{summary["needs_model_review"]}条语义疑难按场景保留，每组最多展示三例；资料缺失另存待核。',
          '历史结果保持原文件，本次没有模型调用、平台操作或发送。准确率尚无独立人工标注可核定。',
          '意向针对原评论时点，今天是否仍找房、实际地区和门店适配另行核对；候选稿不代表允许发送。','']
        (state_dir/'本地处理汇总.txt').write_text('\n'.join(note),encoding='utf8')
        return summary
    finally:
        source.close();state.close()

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source-db',type=Path,default=DEFAULT_SOURCE)
    parser.add_argument('--state-dir',type=Path,default=DEFAULT_STATE)
    parser.add_argument('--legacy-result',type=Path)
    parser.add_argument('--no-legacy',action='store_true')
    parser.add_argument('--policy-path',type=Path,default=DEFAULT_POLICY)
    parser.add_argument('--mothers-path',type=Path,default=DEFAULT_MOTHERS)
    parser.add_argument('--config-path',type=Path)
    parser.add_argument('--platform',choices=['douyin','xiaohongshu'],default='douyin')
    parser.add_argument('--max-new',type=int,default=5000)
    parser.add_argument('--dry-run',action='store_true')
    parser.add_argument('--verification-run',action='store_true')
    parser.add_argument('--export-all',type=Path)
    options=vars(parser.parse_args());no_legacy=options.pop('no_legacy')
    if no_legacy: options['legacy_result']=False
    print(json.dumps(run_pipeline(**options),ensure_ascii=False,indent=2))

if __name__=='__main__': main()
