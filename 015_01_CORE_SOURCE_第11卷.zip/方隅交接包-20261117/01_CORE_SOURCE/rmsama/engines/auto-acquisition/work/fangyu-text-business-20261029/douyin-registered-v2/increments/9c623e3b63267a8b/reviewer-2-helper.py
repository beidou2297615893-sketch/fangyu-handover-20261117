from pathlib import Path
import json,datetime
B=Path('work/fangyu-text-business-20261029/douyin-registered-v2/increments/9c623e3b63267a8b')
SRC=[json.loads(x) for x in (B/'shard-2.jsonl').open(encoding='utf-8')]
def S(s):return set(map(int,s.split()))
def run(batch,lo,hi,groups,topics={},regions={},times={},extras={},notes={},usebody=(),possible={}):
 out=[]
 for x in SRC[lo:hi]:
  n=int(x['review_key'][1:]);c=x['comment_text']; group=next((k for k,v in groups.items() if n in v),'u')
  states={'u':('unknown','unknown','uncertain','本人需求、询问对象、说话人身份或租赁语境未明确。'),'h':('demand','active_at_comment','high','本人明确找房并提出条件，或针对明确出租房源发出询问；不代表如今仍在找。'),'m':('demand','active_at_comment','medium','本人询问或比较租房方向，尚未确认具体房源询盘或预约。'),'s':('supply','unknown','unrelated','本人提供或推广房源、转租或租赁服务，未见新的本人求租。'),'d':('discussion','unknown','unrelated','本人讨论、分享、建议或评价，未明确提出新的本人求租。'),'e':('demand','ended','unrelated','本人明确已租到或已签约，未见新的求租。'),'f':('demand','future','low','本人明确未来才启动找房，目前未表明推进。'),'v':('demand','active_at_comment','super_high','本人明确提出预约看房或订房等行动；不等于双方已确认。')}
  role,state,interest,reason=states[group]; tt=[]
  for z in topics.get(n,[]):
   pool,q,pol,sub,*scope=z;assert q in c,(n,q)
   tt.append(dict(pool=pool,quote=q,polarity=pol,subject=sub,condition_scope=scope[0] if scope else q))
  rr=[]
  for z in regions.get(n,[]):
   q,rel,*rest=z;assert q in c,(n,q);rr.append(dict(text=q,quote=q,relation=rel,group_relation=rest[0] if rest else 'unknown',condition_scope=rest[1] if len(rest)>1 else q))
  tm=[]
  for q,k in times.get(n,[]):
   assert q in c,(n,q);tm.append(dict(quote=q,time_role=k,anchor_source='published_at_unix' if x.get('published_at_unix') else 'unknown',anchor_time=x.get('published_at_unix'),normalized=None,verification='保留本人原词和发表时间，具体时间未擅自归一。'))
  oo=[]
  for q,d in extras.get(n,[]):assert q in c,(n,q);oo.append(dict(quote=q,description=d))
  review=list(notes.get(n,[]))
  if group=='u' and not review:review.append('需核实说话人身份、本人需求及询问对象。')
  if not c:review.append('评论为空，无法判断意图。')
  if x.get('deeper_reply_count_visible',0) and not x.get('deeper_replies_read'):review.append('可见深层回复未读取，不能推断后续结果。')
  if x.get('reply_to') not in (None,'0',0) and not x.get('direct_parent_text'):review.append('直接上级评论缺失，无法核实回复对象。')
  out.append(dict(review_key=x['review_key'],comment_id=x['comment_id'],customer_uid=x['customer_uid'],video_id=x['video_id'],published_at_unix=x.get('published_at_unix'),ip_location_raw=x.get('ip_location_raw'),role=role,demand_state=state,interest_at_comment=interest,topics=list(dict.fromkeys(z['pool'] for z in tt if z['subject']=='own_demand')),topic_evidence=tt,target_regions=rr,time_mentions=tm,other_constraints=oo,possible_topics=[dict(pool=p,ambiguity='原句具体指价格、面积或其他内容未明确。') for p in possible.get(n,[])],evidence=[c] if c else [],reason=reason,context_used=['own']+(['body'] if n in usebody else []),review_reasons=review,human_confirmed=False,current_need_verified=False,send_authorized=False,assigned_store=None))
 p=B/f'reviewed-2-stage-{batch}.jsonl'
 with p.open('x',encoding='utf-8',newline='\n') as f:
  for o in out:f.write(json.dumps(o,ensure_ascii=False)+'\n')
 print(batch,len(out))
