import json,pathlib,sys
P=pathlib.Path(__file__).resolve().parent
B=P.parent.parent
read=lambda p: [json.loads(x) for x in p.read_text('utf-8-sig').splitlines() if x.strip()]
source={r['review_key']:r for r in read(B/'shard-2.jsonl')}
mothers={x['slot']:x for x in json.loads((B.parents[2]/'approved-mothers-model-view.json').read_text('utf-8-sig'))}
pools=dict(zip('plhfpetacv',[])) if False else {'p':'价格预算','l':'位置通勤','h':'户型面积与居住方式','f':'房内设施','d':'宠物','e':'楼层电梯','t':'入住与租期','a':'房源状态','c':'费用合同','v':'看房联系'}
profiles={'H':('demand','active_at_comment','high'),'M':('demand','active_at_comment','medium'),'N':('demand','unknown','medium'),'Z':('demand','active_at_comment','super_high'),'U':('unknown','unknown','uncertain'),'X':('discussion','unknown','unrelated'),'Q':('discussion','unknown','low'),'S':('supply','unknown','unrelated'),'E':('demand','ended','unrelated'),'F':('demand','future','low'),'B':('mixed','active_at_comment','high'),'I':('demand','active_at_comment','unrelated')}
profiles.update(T=('demand','historical','unrelated'), L=('demand','unknown','low'), W=('mixed','unknown','uncertain'))
def process(page):
 data=json.loads((P/f'page-{page:02}.json').read_text('utf-8-sig'))
 pageitems={c['key']:(g,c) for g in data['shared_post_context'] for c in g['comments']}
 rows=[]; decisions=[]
 for line in (P/f'decisions-{page:02}.txt').read_text('utf-8-sig').splitlines():
  if not line.strip():continue
  fields=line.split('|',5);assert len(fields)>=5,line
  key,profile,codes,slot,note=fields[:5]; extra=json.loads(fields[5]) if len(fields)>5 else {}
  assert key in pageitems and key not in [r['review_key'] for r in rows],key
  group,comment=pageitems[key];s=source[key]; text=comment['text'];role,state,interest=profiles[profile]
  subject=extra.get('subject','supply' if role=='supply' else 'own_demand' if role in ('demand','mixed') else 'unresolved')
  topics=[]
  for code in codes.split(',') if codes else []:
   polarity={'!':'require','~':'prefer','-':'reject','+':'accept','?':'unknown','=':'fact','^':'conditional',':':'compare'}.get(code[-1],'ask')
   topics.append({'pool':pools[code[0]],'quote':extra.get('topic_quotes',{}).get(code,text),'polarity':polarity,'subject':extra.get('topic_subjects',{}).get(code,subject),'condition_scope':text if polarity in ('require','prefer','reject','conditional','accept') else None})
  regions=[]
  for item in extra.get('regions',[]):
   loc,relation,*rest=item
   regions.append({'text':loc,'quote':loc,'relation':relation,'group_relation':rest[0] if rest else 'unknown','condition_scope':text if relation in ('desired','preferred','accepted','excluded') else None})
  times=[]
  for item in extra.get('times',[]):
   quote,trole,*rest=item
   times.append({'quote':quote,'time_role':trole,'anchor_source':'published_at' if comment.get('published_at') else 'unknown','anchor_time':comment.get('published_at'),'normalized':rest[0] if rest else None,'verification':rest[1] if len(rest)>1 else '保留原词及发表时点；不按分析当天推算；不代表今日状态'})
  needs=extra.get('needs',[])
  if profile in ('U','N','L','W'):needs=['待核：'+note]+needs
  if profile=='M':needs=['待核：'+note,'需核实所询指标、本人实际租赁推进及当前可租语境']+needs
  if role in ('demand','mixed') and state in ('active_at_comment','future'):needs+=['评论时需求不代表今日仍有效，后续需核实']
  if s.get('source_version_conflict'):needs+=['本条来源文本存在版本冲突，保留当前证据待核']
  chosen=int(slot) or None;generic=extra.get('generic',chosen is not None)
  missing=[]
  if chosen:missing.append(mothers[chosen]['required_facts'])
  if generic and chosen!=1:missing.append(mothers[1]['required_facts'])
  missing+=extra.get('missing',[])
  if generic:missing+=['本人目标地区及同店同房源能否满足全部条件、当前报价和空房状态待核']
  cautions=['仅为本地母句候选，未授权发送；不表示已回答具体询问'] if chosen or generic else ['需求语境或适配尚不明确，暂不强推母句']
  cautions+=extra.get('caution',[])
  boundaries=[{'quote':q,'scope':scope} for q,scope in extra.get('boundaries',[])]
  r={k:s[k] for k in ('review_key','platform','comment_id','customer_uid','video_id')}
  r.update(role=role,demand_state=state,interest=interest,topics=topics,target_regions=regions,time_mentions=times,
   other_constraints=[{'quote':q,'detail':desc} for q,desc in extra.get('other',[])],
   possible_topics=[{'pools':[pools[c] for c in poolcodes],'ambiguity':amb,'quote':q} for q,poolcodes,amb in extra.get('possible',[])],
   evidence=[text] if text else [],reason=note,context_used=['own','body']+(['parent'] if comment.get('parent') else []),needs_review=needs,contact_boundaries=boundaries,
   context_flags={'same_author':comment['same_author'],'source_version_conflict':comment['source_conflict'],'post_context_only':not comment['same_author'],'published_at':comment.get('published_at'),'parent_context':comment.get('parent')},
   reply_plan={'preferred_mother_slot':chosen,'generic_intro_suitable':generic,'tone':extra.get('tone','normal'),'missing_facts':missing,'caution':cautions,'contact_policy':extra.get('policy','allow')},
   human_confirmed=False,send_authorized=False,store_assignment=None)
  rows.append(r);decisions.append({'review_key':key,'initial_profile':profile,'detailed_decision':note,'explicit_fields':extra,'explicit_topic_codes':codes,'explicit_mother_slot':chosen})
 assert set(pageitems)=={r['review_key'] for r in rows},set(pageitems)-{r['review_key'] for r in rows}
 # Page order follows frozen page, rather than grouped manual drafting order.
 rows.sort(key=lambda r:list(pageitems).index(r['review_key']))
 (P/f'reviewed-{page:02}.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows),'utf-8')
 (P/f'explicit-decisions-{page:02}.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in decisions),'utf-8')
 done=sorted(int(p.stem.split('-')[1]) for p in P.glob('reviewed-??.jsonl'))
 (P/'progress.json').write_text(json.dumps({'completed_pages':done,'reviewed_count':sum(len(read(P/f'reviewed-{i:02}.jsonl')) for i in done),'status':'AI_semantic_review_in_progress','independent_review_claimed':False,'usage':'unknown'},ensure_ascii=False,indent=2),'utf-8')
 print(page,len(rows))
if __name__=='__main__':process(int(sys.argv[1]))
