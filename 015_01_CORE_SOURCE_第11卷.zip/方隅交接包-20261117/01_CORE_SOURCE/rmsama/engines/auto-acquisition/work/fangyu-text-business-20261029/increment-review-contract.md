# 已登记增量文本判读契约

本文件为文本定稿契约，版本business-text-20261029-v2，供业务使用但效果未保证；不得拿本契约静默重写既有1166条第一稿初判或1384条未合并初判。只分析已核登记的暂存文件，不读凭据、不运行平台、不修改源库或软件、不发送。平台采集维持已有暂停状态，除非本人明确恢复。规则来源 outputs/方隅双平台文本业务/筛选与分类规则/筛选与分类业务规则.md。评论自身优先，IP、源门店与本人目标地区分开。

十池名称逐字使用：价格预算、位置通勤、户型面积与居住方式、房内设施、宠物、楼层电梯、入住与租期、房源状态、费用合同、看房联系。

逐条按语义判断，不把词面命中冒充本人需求。长广告明确提供房源为供给；转租并本人另找房则mixed同时保留。抱怨、经验、已解决而无新需求不作为当前求租。相对入住时间只有可信发表时点可锚定，不能用今天代替发表日；未知时态保留。明确可租房源标题下本人问价/房态可判当时高兴趣；标题是经历/装修/退房/泛租房，短问句需待核。问微信/泛看房不自动超高，明确约看请求/时间/订房/签约才可能超高。供需对象不明不得编造。

输出JSONL每个输入review_key和comment_id恰好一条，保留customer_uid，字段为：
- role: demand/supply/mixed/unknown/discussion
- demand_state: active_at_comment/future/ended/historical/unknown（表示找房动作，不是入住日期；也不是今日已确认）
- interest: super_high/high/medium/low/very_low/uncertain/unrelated
- topics: [{pool,quote,polarity,subject,condition_scope}]；quote逐字来自当前评论；polarity为ask/require/prefer/reject/accept/conditional/fact/not_required/compare/unknown；subject区分own_demand/supply/current_home/other_person/unresolved。供给条件不能作为本人需求；unknown可存待核主题但须说明。条件作用范围原文保留，不把最好写成硬要求，复合否定不压扁为一个方向。
- target_regions: [{text,quote,relation,group_relation,condition_scope}]；quote只能来自本人评论；relation为desired/preferred/accepted/excluded/work/current_home/offered/unresolved；group_relation为AND/OR/unknown。工作地、旧房地不当目标，不从IP或标题补目标地区。
- time_mentions: [{quote,time_role,anchor_source,anchor_time,normalized,verification}]；time_role区分move_in/viewing/lease_duration/search_start/other。可信发表时间与相对原词都保留，缺时间锚不归一到今天；future入住不自动改成future才找房。
- other_constraints: 十池不能准确表达的本人要求及证据；不能丢失车位等约束，也不擅自增需求池。
- possible_topics: 仅记录未确定的候选池和具体歧义，例如“多少米”可能为价格或面积；不当成确定池统计。
- evidence: [本人逐字原文]；reason:简明中文；context_used:[own/title/parent/body]；needs_review:[具体原因]。
- human_confirmed:false；send_authorized:false；store_assignment:null。

允许topics为空，不等于无需求。多需求并列、否定方向保留，家庭仅语境。信息缺少具体说明，不用毫无区别的笼统待核理由。任何判断无法完成时输出uncertain及原因，不省略记录。

本人明确长租或月租等可直接建立租赁语境，标题缺少出租词不能盖过本人完整语义；仍核住宅或其他用途。现在找、下月入住，按评论时动作分意向，入住另记。仅说未来才开始找且现在不推进才低意向。unknown/unknown/uncertain不得写成unrelated；本人已租好且无新需求保留demand/ended/unrelated；因换房转租但新租不明保留待核新需求，不整体过滤。多少米未澄清前只留possible_topics，不填确定价格/面积主题。

写入各自独立文件，禁止覆盖其他代理输出。提供本条输入计数、输出计数、ID集合相等、证据逐字校验结果。模型判断不是用户金标或发送许可。

## 本地发布必备结构补充（2026-10-30）

这是现有发布器结构的明确化，不改变业务判断。每条保留platform、video_id及原review_key/comment_id/customer_uid，不能省略。

- contact_boundaries必须为列表，没有明确边界时为[]。明确限制推荐对象{quote,scope}，二者均非空文本，quote为本人逐字证据。不要把中介勿扰扩大成拒绝所有联系。
- context_flags必须为对象或列表；context_used只列实际所读own/title/parent/body。
- reply_plan必须含preferred_mother_slot（整数或null）、generic_intro_suitable（布尔）、tone（normal/serious）、missing_facts（字符串列表）、caution（字符串列表）、contact_policy（allow/identity_restricted/no_contact/unknown）。列表可空，但每个现有条目均须非空字符串，不能是嵌套数组。allow不等于发送授权。
- other_constraints对象必须有quote和detail、meaning或description之一。若已有constraint字段，应保留并新增同值detail，不能仅有constraint导致下游失读。
- possible_topics对象必须有ambiguity说明，以及pool、pools或candidate_pools中至少一个非空候选。候选不是确定分池。
- topics对象必须含pool、quote、polarity、subject、condition_scope；target_regions对象必须含text、quote、relation、group_relation、condition_scope。condition_scope可为null或文本。
- time_mentions对象必须含quote、time_role、anchor_source、anchor_time、normalized、verification。anchor_time和normalized允许null，其他说明为文本。月租金额不能当lease_duration。
- human_confirmed=false、send_authorized=false、store_assignment=null始终保留。

同轮模型初细筛与独立复核分开。compiler绑定实际评审文件SHA、classification_method和classification_stages_completed；代理不能虚构独立模型复核。完成前使用现有mother_adapter.validate_new_review做隔离结构预检，自建局部校验不等于正式发布校验。只在隔离预检中补编译元数据，正式绑定由compiler执行；语义原评审和兼容修正前字节都保留。
