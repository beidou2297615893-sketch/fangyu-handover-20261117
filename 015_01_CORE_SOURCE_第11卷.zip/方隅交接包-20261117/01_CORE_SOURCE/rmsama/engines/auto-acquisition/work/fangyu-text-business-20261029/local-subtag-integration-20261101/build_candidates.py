"""Offline source-preserving adapter. Candidates are never send authorization."""
import collections
import hashlib
import importlib.util
import json
import re
from pathlib import Path

HERE = Path(__file__).resolve().parent
WORK = HERE.parent

def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def build():
    classifier = load_module('subtags', WORK/'local-subtag-v2/local_subtagger.py')
    mothers = load_module('mothers', WORK/'subtag-mother-contract/renderer.py')
    source = WORK/'high-intent-pools-20261101/all-high-intent-pools.jsonl'
    source_sha = sha(source)
    by_label = {x['subtag']: x for x in mothers.CONTRACT['subtags']}
    counts = collections.defaultdict(collections.Counter)
    output = HERE/'high-intent-candidates.jsonl'
    examples = []
    with source.open(encoding='utf-8-sig') as stream, output.open('w',encoding='utf-8') as dest:
        for line in stream:
            row = json.loads(line)
            text = row['comment_text']
            a = classifier.annotate(row)
            labels = list(dict.fromkeys(h['subtag'] for h in a['evidence']))
            old = set(row.get('demand_pools') or [])
            local = set(a['local_pools'])
            holds = []
            if old != local: holds.append('新旧分池差异，保留原判断待核')
            if a['needs_semantic_review']: holds += a['review_reasons']
            if a['constraint_relation'] == 'alternative_or_mixed': holds.append('可选条件不能改写成同时满足')
            if any(h['polarity'].startswith('negative') for h in a['evidence']): holds.append('否定条件需要专用承接')
            if re.search(r'已经租到|已租到|不租了|不用了|不要私信|别私信',text): holds.append('结束或联系限制')
            original = row.get('original_classification') or {}
            if original.get('contact_boundaries') or original.get('source_version_conflict'):
                holds.append('原评审保留限制')
            slots = {}
            patterns = {
                'layout': r'[一二两三四1234](?:室(?:[一二两三四1234]厅)?|居室)|单间|套[一二三123]',
                'budget': r'(?:不超过)?\s*\d+(?:\.\d+)?\s*(?:[kK千]|元|块)?(?:左右|以内|以下|上下)?',
                'area': r'\d+(?:[~到\-]\d+)?\s*(?:平米|平方|㎡|平)',
                'metro': r'\d+号线',
                'people_count': r'[一二两三四1234]个人|[一二两三四1234]人',
                'pet_count': r'[一二两三四1234]只(?:猫|狗)',
                'move_in': r'(?:[下本这]个?月|月底|月初|\d+月\d+[日号]|明天|后天)',
                'term': r'(?:[一二两三四六十123456]+个?月|半年|一年|两年)',
                'floor': r'\d+楼|\d+层',
            }
            needed = {s for label in labels if label in by_label for s in by_label[label]['adjustment_slots']}
            for key in needed:
                # Price/fees/address are property facts, never copy customer guesses as facts.
                if key not in patterns: continue
                matches = list(re.finditer(patterns[key],text))
                if key == 'budget' and not re.search(r'预算|元|块|[kK千]|以内|以下',text): continue
                if len(matches) == 1: slots[key] = matches[0].group().strip()
            result = mothers.render_candidate(None, labels, slots=slots, conflict=bool(holds))
            if result.get('candidate_text'):
                body = result['candidate_text']
                # A concrete quantity must never disappear through a too-coarse tag.
                source_numbers = set(re.findall(r'\d+(?:\.\d+)?',text))
                rendered_numbers = set(re.findall(r'\d+(?:\.\d+)?',body))
                if source_numbers-rendered_numbers:
                    holds.append('具体数字条件未完整承接')
                for term in re.findall(r'[一二两三四五六七八九十半\d]+(?:天|周|个月|年)',text):
                    if term not in body: holds.append('具体租期未完整承接：'+term)
                if re.search(r'附近|上班|通勤',text) and '位置通勤' not in local:
                    holds.append('地理条件尚未完整识别')
                if holds:
                    result = dict(status='hold',candidate_text=None,reason='；'.join(holds),
                                  missing_facts=[],send_authorized=False,contract_version=mothers.CONTRACT['version'])
            result['hold_reasons'] = holds or ([result.get('reason')] if result['status']=='hold' else [])
            result['slots_are_customer_requirements_not_property_facts'] = True
            record = dict(platform=row['platform'],comment_id=str(row['comment_id']),
                          comment_text=text,source_sha256=source_sha,
                          comment_sha256=hashlib.sha256(text.encode()).hexdigest(),
                          original_interest=row.get('interest'),original_pools=sorted(old),
                          classification=a,reply=result,send_authorized=False,
                          source_stage='historical_intent_preserved_new_local_subtags',
                          reply_body_sha256=hashlib.sha256((result.get('candidate_text') or '').encode()).hexdigest())
            dest.write(json.dumps(record,ensure_ascii=False)+'\n')
            counts[row['platform']][result['status']] += 1
            if result['status']=='draft_candidate' and len(examples)<30:
                examples.append({k:record[k] for k in ('platform','comment_id','comment_text')} | {'reply':result})
    assert sha(source)==source_sha
    report=dict(source_sha256=source_sha,output_sha256=sha(output),
                records=sum(sum(c.values()) for c in counts.values()),by_platform=dict(counts),
                local_model_calls=0,source_unchanged=True,send_authorized=False,
                production_consumer_verified=False,
                limitation='逐条建立旁注不等于全部适配；草稿事实缺口保留，hold不填统一句。',
                dependencies={str(p.relative_to(WORK)):sha(p) for p in [
                    WORK/'local-subtag-v2/local_subtagger.py',WORK/'local-subtag-v2/subtags-20261101-v2.json',
                    WORK/'subtag-mother-contract/renderer.py',WORK/'subtag-mother-contract/subtag-mother-contract-20261101-v1.json']})
    (HERE/'candidate-report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    (HERE/'candidate-examples.json').write_text(json.dumps(examples,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(report,ensure_ascii=False))

if __name__=='__main__': build()
