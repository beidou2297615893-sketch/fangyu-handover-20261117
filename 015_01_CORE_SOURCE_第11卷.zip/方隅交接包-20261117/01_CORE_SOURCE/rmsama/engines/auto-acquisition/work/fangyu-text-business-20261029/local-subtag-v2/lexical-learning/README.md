# 本地词组学习单次离线验证

结论：本次固定方案不适合直接接管生产。固定0.95/0.05阈值下，测试已知去重样本仅16/3778条可直接决定（0.4235%）；将未知、混合、排除及重复记录一律记作待核后，原始测试分组16/5706条（0.2804%），99.7196%仍待核。没有调低阈值、二次训练或逐条AI复核。

## 实际路线

复用scikit-learn官方成熟管线：TFIDF字符2—4gram + LogisticRegression。依据：
- https://scikit-learn.org/stable/auto_examples/text/plot_document_classification_20newsgroups.html
- https://github.com/scikit-learn/scikit-learn （BSD-3-Clause）

在本目录独立venv安装成功，未改全局Python。源34,840条全部为抖音；没有小红书验证证据。仅用评论前500字符和原帖正文前300字符作特征；不输入AI判断、旧意向、需求标签、来源关键词、门店等字段。

正类为role=demand且意向high/medium/super_high；负类仅明确supply/discussion且unrelated/low/very_low。未知、不确定、mixed及低意向demand等不作为负类，全部报告排除，不能宣称这些记录已由模型解决。

按platform+作品ID固定SHA256分70/15/15训练/校准检查/测试。跨分组的同一规范化评论从全部split移除，同split重复只留确定一条，同文标签冲突移除。模型只在训练集拟合；calibration仅报告，无概率校准拟合、无阈值调参。训练17,314条，校准检查2,426条，测试3,778条；作品组分别499/86/108。单次训练及输出共9.405秒。

## 固定阈值结果

校准检查7/2426条明确（3正4负），测试16/3778条明确（7正9负）。这些明确记录均与历史AI参考一致；测试正误放候选0、负疑漏候选0，但样本少、覆盖极低且标签非人工金标，不能宣传100%准确率。

原始测试分组共5,706条，其中unknown/uncertain/mixed共1,270条；整体保守覆盖0.2804%，待核99.7196%。训练样本不计算泛化覆盖，不能拿训练拟合或排除未知的known子集冒充全量能力。历史AI自身偏差、长程上下文、回复主体和时效并未由词组模型解决，概率未校准，0.95不代表真实95%正确率。

## 文件与复现

- `train.py`：单方案训练脚本。
- `model.joblib`、`manifest.json`：实际模型、版本、源和模型SHA256、划分方式及production_enabled=false。
- `report.json`：固定阈值结果；`calibration-predictions.jsonl`、`test-predictions.jsonl`：逐条记录。
- `split-manifest.json`：各split的ID、作品组、规范化文本哈希和参考标签，便于核查无交叉泄漏。
- `account_all.py`：原始全分组分母、未知和整体待核统计。
- `predict_offline.py`：只写独立审查旁注，不改源意向、不接平台或生产。

```powershell
./venv/Scripts/python.exe train.py
./venv/Scripts/python.exe account_all.py
./venv/Scripts/python.exe predict_offline.py --input 某评论文件.jsonl --output 独立审查结果.jsonl
```

本次仅训练一次。模型已保存但生产始终关闭；它不具备替代当前AI筛选的证据，保留为失败/低覆盖路线的可复核结果，不继续扩训或迎合阈值。
