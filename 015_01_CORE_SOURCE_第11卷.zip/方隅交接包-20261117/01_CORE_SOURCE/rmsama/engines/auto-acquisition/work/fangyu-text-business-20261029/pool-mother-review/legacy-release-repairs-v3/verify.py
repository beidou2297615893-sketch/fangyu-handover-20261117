"""Independent JSON replay, source/field/attribution/flags and negative checks. Run before freeze only."""
import pathlib,json,hashlib,copy,collections,string,runpy,sys
sys.dont_write_bytecode=True
O=pathlib.Path(__file__).resolve().parent;P=O.parent;W=P.parent
def load(p):return json.loads(pathlib.Path(p).read_text(encoding='utf8'))
def jl(p):return [json.loads(x) for x in pathlib.Path(p).read_text(encoding='utf8').splitlines() if x.strip()]
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def objsha(x):return hashlib.sha256(json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def key(p):return str(p['platform']),str(p.get('cid',p.get('comment_id'))),str(p.get('uid',p.get('customer_uid')))
def project(p):return {f:p.get(f) for f in ('family','fill','evidence','clarification_only','hold_reasons','status')}
def put(p,x):pathlib.Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
m=load(O/'manifest.json');assert all(sha(p)==h for p,h in m['source_SHA256'].items());assert all(sha(O/n)==h for n,h in m['outputs_SHA256'].items())
oldcontract=load(P/'legacy-release-repairs-v2/repair-contract.json');contract=load(O/'repair-contract.json');addon=load(O/'contract-addon.json')
assert all(contract['families'][n]==d for n,d in oldcontract['families'].items())
assert {n:d for n,d in contract['families'].items() if n not in oldcontract['families']}==addon['families']
abc={key(x):x for x in jl(P/'legacy-release-package/candidate-abc/merged-plans.jsonl')};v2={k:copy.deepcopy(x) for k,x in abc.items()}
for x in jl(P/'legacy-release-repairs-v2/source-bound-plan-overlays.jsonl'):
 assert objsha(abc[key(x)])==x['base_merged_plan_sha256'];v2[key(x)].update(x['replacement_plan'])
v3={k:copy.deepcopy(x) for k,x in v2.items()};cumulative={k:copy.deepcopy(x) for k,x in abc.items()};delta=jl(O/'incremental-plan-overlays.jsonl');cli={key(x):x for x in jl(O/'CLI-draft-body-overlays.jsonl')};labels={key(x):x for x in jl(O/'merged-semantic-labels.jsonl')};contexts=load(P/'reference-semantic-supplement/shared-contexts.json')
assert len(delta)==len(cli)==268 and len(labels)==267
for x in delta:
 k=key(x);assert objsha(v2[k])==x['base_v2_applied_plan_sha256'] and objsha(abc[k])==x['base_ABC_plan_sha256'];v3[k].update(x['replacement_plan']);assert not x['classification_changed'] and not x['send_authorized'] and not x['can_send_now']
 if k in labels:assert x['semantic_label']==labels[k] and x['semantic_label_source']['label_record_sha256']==objsha(labels[k])
for x in jl(O/'source-bound-plan-overlays.jsonl'):
 k=key(x);assert objsha(abc[k])==x['base_merged_plan_sha256'];cumulative[k].update(x['replacement_plan'])
for k,p in v3.items():assert project(p)==project(cumulative[k])
cur=load(W/'region-brand-routing/current.json');sources={key(x):x for f in cur['results'].values() for x in jl(f)}
namespace={};locked_path=W/'douyin-registered-v2/increments/f98cc21138910fb9/batch_short_mothers.py';exec(compile(locked_path.read_text(encoding='utf-8-sig'),str(locked_path),'exec'),namespace)
wrapper=runpy.run_path(str(O/'bounded_renderer.py'))['render_plan'];counters=collections.Counter()
def row_for(k,p):
 r=sources[k];return {'platform':r['platform'],'comment_id':r['comment_id'],'customer_uid':r['customer_uid'],'role':r['role'],'demand_state':r['demand_state'],'interest_at_comment':r['interest_at_comment'],'reply_plan':{'local_mother':{'family':p['family'],'fill':p['fill'],'evidence':p['evidence']},'contact_policy':r.get('contact_policy') or 'unknown','tone':r.get('effective_tone')}}
def render(k,p,c):
 if not p['family']:return None
 return wrapper(row_for(k,p),sources[k]['comment_text'],c,namespace['render_plan'],contexts['posts'],labels.get(k))['validated_plan_text']
for k,p in v3.items():
 r=sources[k];assert p['sourceSHA']==hashlib.sha256(r['comment_text'].encode()).hexdigest();assert p['original_classification_sha256']==objsha(r['source_record']);assert p['source_field_evidence']==v2[k]['source_field_evidence'];assert p['contact_policy_original']==v2[k]['contact_policy_original'];assert not p['send_authorized'] and not p['can_send_now']
 assert p['customer_requirements']==v2[k]['customer_requirements'] and p['source_metadata_preserved']==v2[k]['source_metadata_preserved'];counters['all_source_classification_contact_bindings']+=1
 if not p['family']:assert p==v2[k];continue
 d=contract['families'][p['family']];assert set(p['fill'])==set(d['required_fill'])=={f for _,f,_,_ in string.Formatter().parse(d['template']) if f};text=render(k,p,contract);before=render(k,v2[k],oldcontract);counters['bound_full_field_render_checks']+=1
 if k not in cli:assert p==v2[k] and text==before;counters['untouched_bound_byte_identical']+=1
 else:
  c=cli[k];assert c['draft_body']==text and c['draft_body_sha256']==hashlib.sha256(text.encode()).hexdigest();assert c['clarification_only']==p['clarification_only'];assert c['source_contact_policy']==v2[k]['contact_policy_original'];assert not c['send_authorized'] and not c['can_send_now'];assert not any(x in text for x in ('确认对象后','实体','私聊联系你的事帮你问','待绑定','关系unknown'));counters['changed_CLI_flags_and_render_consistent']+=1
  if k in labels:
   label=labels[k];assert label['source_comment_sha256']==p['sourceSHA']
   if label['brand_source_relation']=='explicit_fangyu':assert '也考虑' not in text and '原帖里介绍的房源吗' not in text;counters['known_Fangyu_no_redundant_source_question']+=1
   if label['brand_source_relation']=='explicit_other_source':assert '不是方隅' not in text and '不属于方隅' not in text;counters['other_source_not_inferred_other_brand']+=1
  if r.get('contact_policy') in (None,'unknown'):assert c['source_contact_policy'] in (None,'unknown');counters['unknown_contact_not_promoted']+=1
for x in delta:assert x['new_preview_sha256']==hashlib.sha256(render(key(x),v3[key(x)],contract).encode()).hexdigest()
for x in jl(O/'source-bound-plan-overlays.jsonl'):assert x['new_preview_sha256']==hashlib.sha256(render(key(x),cumulative[key(x)],contract).encode()).hexdigest()
# Independently exercise the narrow post slot, including deliberate invalid inputs.
post_keys=[k for k,p in v3.items() if 'post_price_anchor' in p['fill']];assert len(post_keys)==1
k=post_keys[0];p=v3[k];text=render(k,p,contract);assert '原帖标的2.2k这个价位' in text and '预算' not in text
rejections=[]
def reject(name,func):
 try:func()
 except (AssertionError,ValueError,KeyError):rejections.append(name);return
 raise AssertionError('NEGATIVE_TEST_ACCEPTED '+name)
bad=copy.deepcopy(p);bad['fill']['post_price_anchor']='1.2k';reject('post_quote_value_mutation',lambda:render(k,bad,contract))
badlabel=copy.deepcopy(labels[k]);badlabel['uid']='wrong';reject('post_quote_wrong_customer',lambda:wrapper(row_for(k,p),sources[k]['comment_text'],contract,namespace['render_plan'],contexts['posts'],badlabel))
badcontexts=copy.deepcopy(contexts['posts']);e=p['evidence'][0];badcontexts[e['context_key']]['content']['post_body']='changed';reject('post_context_SHA_mismatch',lambda:wrapper(row_for(k,p),sources[k]['comment_text'],contract,namespace['render_plan'],badcontexts,labels[k]))
badcontract=copy.deepcopy(contract);badcontract['families'][p['family']]['template']=badcontract['families'][p['family']]['template'].replace('原帖标的','方隅价格');reject('post_quote_unattributed_own_fact',lambda:render(k,p,badcontract))
badlabel=copy.deepcopy(labels[k]);badlabel['price_relation']=[];reject('post_quote_without_AI_price_role',lambda:wrapper(row_for(k,p),sources[k]['comment_text'],contract,namespace['render_plan'],contexts['posts'],badlabel))
ownkey=next(k for k,p in v3.items() if k in labels and p['fill'].get('room'));bad=copy.deepcopy(v3[ownkey]);bad['fill']['room']='虚构三室';reject('own_comment_slot_nonliteral',lambda:render(ownkey,bad,contract))
bycid={k[1]:k for k in v3};target=[]
for cid in ('7687783794661278479','7564246228821623594','7610009622871638799','7668177041443865390','7432282565551653670','7520428159360402228','7563441906236769087','7696414781808689957','6acf7c9f0000000008031dc0'):
 k=bycid[cid];text=render(k,v3[k],contract);target.append({'cid':cid,'comment':sources[k]['comment_text'],'sourceSHA':v3[k]['sourceSHA'],'before':render(k,v2[k],oldcontract),'after':text,'clarification_only':v3[k]['clarification_only'],'not_new_holdout':True})
 if cid=='7687783794661278479':assert '闽行六磊路与华西路交叉口' in text and '原帖' not in text
 if cid=='7564246228821623594':assert '原帖3800的报价' in text and '这个价位有没有' not in text
 if cid=='7668177041443865390':assert '租金' in text and '月租' not in text and '这个月' not in text
 if cid=='7696414781808689957':assert all(x in text for x in ('租金','位置','可以私聊')) and '私聊我' not in text
 if cid=='6acf7c9f0000000008031dc0':assert text=='宝宝，你是想找能短租的住处吗？' and v3[k]['clarification_only'] and v3[k]['contact_policy_original'] is None
assert counters['untouched_bound_byte_identical']==6426
for x in jl(O/'old-QA-regression.jsonl'):
 k=key(x);assert x['v3_draft']==render(k,v3[k],contract)
 if not x['changed']:assert x['v2_draft']==x['v3_draft']
result={'status':'all_local_source_field_attribution_flag_and_replay_checks_passed','frozen_source_files_checked':len(m['source_SHA256']),'checks':dict(counters),'negative_rejections':rejections,'targeted_boundary_examples':len(target),'new_semantic_scores':0,'not_population_accuracy':True,'cumulative_and_incremental_apply_equivalent':True,'old_definitions_unchanged':True,'v2_extra_short_purpose_guard_preserved_with_natural_text':True,'API_direct_requests':0,'local_rendering_model_calls':0,'overall_agent_judgment_usage':'unknown','source_or_pointer_writes':0,'send_attempts':0,'independent_semantic_review_pending':True}
put(O/'boundary-regression.json',target);put(O/'validation.json',result);print(json.dumps(result,ensure_ascii=False,indent=2))
