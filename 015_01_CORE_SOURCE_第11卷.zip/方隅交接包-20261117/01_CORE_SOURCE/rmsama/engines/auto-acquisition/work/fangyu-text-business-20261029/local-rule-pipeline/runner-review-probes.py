"""Independent, isolated counterexamples. Never opens an acquisition database."""
import hashlib
from contextlib import closing
import importlib.util
import json
from pathlib import Path
import sqlite3
import tempfile

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('reviewed_runner', HERE/'run_local_pipeline.py')
runner = importlib.util.module_from_spec(spec)
spec.loader.exec_module(runner)

class Classifier:
    def classify(self, record):
        return dict(record, role='demand', demand_state='active_at_comment',
                    interest_at_comment='high', topics=[], exception_type=None,
                    needs_model_review=False, model_calls=0)
    def choose_mother(self, result, mothers):
        return dict(mother_slot=1, mother_reply_text=mothers[0]['template'],
                    draft_ready=True, draft_text=mothers[0]['template'], reply_status='draft_local_pending_review')

class Fixture:
    def __init__(self, directory):
        self.root=Path(directory); self.source=self.root/'source.sqlite3'; self.state=self.root/'state'
        self.mothers=self.root/'mothers.json'
        self.mothers.write_text(json.dumps([dict(slot=1,user_approved=True,template='认可母句')]),encoding='utf8')
        with closing(sqlite3.connect(self.source)) as db:
            db.executescript('''CREATE TABLE entities(stable_key TEXT PRIMARY KEY,kind TEXT,source_id TEXT,first_request TEXT,data TEXT);
            CREATE TABLE attempts(request_id TEXT PRIMARY KEY,spec TEXT,state TEXT);
            CREATE TABLE observations(request_id TEXT,stable_key TEXT,account_uid TEXT,store_id TEXT,keyword TEXT,kind TEXT,target TEXT,collected_at TEXT,data TEXT);''')
    def add(self, cid='1', uid='u', request='r', text='想租房'):
        item=dict(cid=cid,text=text,aweme_id='v',user=dict(uid=uid))
        with closing(sqlite3.connect(self.source)) as db:
            db.execute('INSERT INTO attempts VALUES(?,?,?)',(request,json.dumps(dict(kind='comments',target='v',account_uid='account',eligibility=dict(state='eligible'))),'parsed'))
            db.execute('INSERT OR IGNORE INTO entities VALUES(?,?,?,?,?)',('comment:'+cid,'comments',cid,request,json.dumps(item)))
            db.execute('INSERT INTO observations VALUES(?,?,?,?,?,?,?,?,?)',(request,'comment:'+cid,'account','store','word','comments','v','today',json.dumps(item)))
            db.commit()
    def run(self, **kwargs):
        return runner.run_pipeline(source_db=self.source,state_dir=self.state,mothers_path=self.mothers,
            policy_path=None,legacy_result=kwargs.pop('legacy_result',False),classifier=Classifier(),**kwargs)

out={}
fixtures=HERE/'fixtures'; fixtures.mkdir(exist_ok=True)
with tempfile.TemporaryDirectory(prefix='independent-review-',dir=fixtures) as root:
    root=Path(root)
    for name in ['historical','late_audit','overwrite','malformed']:
        (root/name).mkdir()
    f=Fixture(root/'historical')
    legacy=f.root/'legacy.jsonl'
    legacy.write_text(json.dumps(dict(platform='douyin',comment_id='h',customer_uid='u',role='supply',
        demand_state='ended',interest_at_comment='unrelated',mother_reply_text='未认可且不应成为当前候选的旧句'))+'\n',encoding='utf8')
    summary=f.run(legacy_result=legacy)
    with closing(sqlite3.connect(f.state/'derived.sqlite3')) as db:
        candidate_row=db.execute('SELECT data FROM candidates').fetchone()
        candidate=json.loads(candidate_row[0]) if candidate_row else {}
    out['historical_unapproved_candidate']={'candidate_count':summary['local_mother_drafts'],'text':candidate.get('mother_reply_text')}

    f=Fixture(root/'late_audit');f.add()
    first=f.run();first_draft=Path(first['mother_increment_file'])
    f.add(uid='other-user',request='later',text='不同作者')
    current=f.root/'current-results.jsonl';summary=f.run(export_all=current)
    record=json.loads(current.read_text(encoding='utf8'))
    out['late_audit_current_export']={'active_candidate_count':summary['local_mother_drafts'],
        'audit_count':summary['source_integrity_audits'],'current_export_draft_ready':record['draft_ready'],
        'current_export_draft_text':record.get('draft_text'),
        'current_export_reply_status':record['reply_status'],'current_export_text':record['mother_reply_text'],
        'old_increment_still_contains_draft':bool(first_draft.read_text(encoding='utf8').strip())}

    f=Fixture(root/'overwrite');f.add()
    legacy=f.root/'legacy.jsonl';legacy.write_text(json.dumps(dict(platform='douyin',comment_id='h',customer_uid='history-user'))+'\n',encoding='utf8')
    before=hashlib.sha256(legacy.read_bytes()).hexdigest()
    try:
        f.run(legacy_result=legacy,export_all=legacy)
        rejection=None
    except ValueError as e:
        rejection=str(e)
    out['legacy_export_path_collision']={'source_file_changed':before!=hashlib.sha256(legacy.read_bytes()).hexdigest(),
        'lines_after':len(legacy.read_text(encoding='utf8').splitlines()),'rejection':rejection}
    source_before=hashlib.sha256(f.source.read_bytes()).hexdigest()
    try:
        f.run(export_all=f.source)
        source_rejection=None
    except ValueError as e:
        source_rejection=str(e)
    out['source_export_path_collision']={'source_file_changed':source_before!=hashlib.sha256(f.source.read_bytes()).hexdigest(),
        'rejection':source_rejection}

    f=Fixture(root/'malformed');f.add(cid='a');f.add(cid='z',request='r2')
    with closing(sqlite3.connect(f.source)) as db:
        db.execute("UPDATE entities SET data='[]' WHERE stable_key='comment:a'")
        db.commit()
    failures=[]
    for _ in range(2):
        try: f.run()
        except Exception as e: failures.append(type(e).__name__+': '+str(e))
    with closing(sqlite3.connect(f.state/'derived.sqlite3')) as db:
        count=db.execute('SELECT count(*) FROM results').fetchone()[0]
    out['malformed_source_poison_record']={'failures':failures,'results_after_two_runs':count,'valid_later_comment':'z'}

(HERE/'runner-review-probe-fix1-results.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps(out,ensure_ascii=False,indent=2))
