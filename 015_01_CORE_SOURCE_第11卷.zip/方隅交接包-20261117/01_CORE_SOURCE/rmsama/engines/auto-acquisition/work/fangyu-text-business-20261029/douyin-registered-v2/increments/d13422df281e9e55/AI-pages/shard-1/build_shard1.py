import json, pathlib, hashlib, sys, collections, datetime, calendar, importlib.util
P=pathlib.Path(__file__).resolve().parent
B=P.parent.parent
W=B.parents[2]
source=[json.loads(x) for x in (B/'shard-1.jsonl').read_text(encoding='utf-8-sig').splitlines() if x.strip()]
src={x['review_key']:x for x in source}
pool=dict(价='价格预算',位='位置通勤',型='户型面积与居住方式',设='房内设施',宠='宠物',梯='楼层电梯',期='入住与租期',态='房源状态',费='费用合同',联='看房联系')
profiles={'H':('demand','active_at_comment','high'),'M':('demand','active_at_comment','medium'),'V':('demand','active_at_comment','super_high'),'U':('unknown','unknown','uncertain'),'D':('discussion','unknown','unrelated'),'L':('discussion','unknown','low'),'S':('supply','unknown','unrelated'),'E':('demand','ended','unrelated'),'F':('demand','future','low'),'K':('unknown','unknown','low')}
mothers={x['slot']:x for x in json.loads((W/'approved-mothers-model-view.json').read_text(encoding='utf-8-sig'))}
# All semantic decisions are explicitly model-authored in the page decision files.
# This script only expands those decisions and checks contracts; it classifies no text.
def build(n):
 page=json.loads((P/f'page-{n:02}.json').read_text(encoding='utf-8-sig'))
 inputs={c['key']:(c,p) for p in page['shared_post_context'] for c in p['comments']}
 decisions=[]
 for line in (P/f'decisions-{n:02}.txt').read_text(encoding='utf-8-sig').splitlines():
  if not line.strip():continue
  cols=line.split('|'); assert len(cols)==6,(len(cols),line)
  key,code,reason,ts,rs,slot=cols; s=src[key]; c,post=inputs[key]
  role,state,interest=profiles[code]; slot=None if slot=='-' else int(slot)
  topics=[]
  for spec in filter(None,ts.split(';')):
   typ,quote=spec.split('=',1); z=typ.split('~'); p=z[0]
   topics.append(dict(pool=pool[p],quote=quote,polarity=z[1] if len(z)>1 else 'ask',subject=z[2] if len(z)>2 else 'own_demand',condition_scope=s['comment_text']))
  regions=[]
  for spec in filter(None,rs.split(';')):
   relation,q=spec.split('=',1)
   regions.append(dict(text=q,quote=q,relation=relation,group_relation='unknown',condition_scope=s['comment_text']))
  needs=[]
  if code in ('H','M','V'):needs=['评论时询租不代表当前仍在找房；待核实际入住安排和可承接门店。']
  if code in ('M','U','K','L'):needs.append(reason+'；住房意向或具体所指需核实。')
  if code=='S':needs.append('供给或转租服务不当作本人新租需求；另找房意图未提供。')
  if code=='D':needs.append('未明确新的找房动作，不据经历补当前求租。')
  missing=[] if slot is None else [mothers[slot]['required_facts'],'逐项核实本评审保留条件能否由同一门店同一有效房源满足；原帖展示内容不证明方隅事实。']
  generic=code in ('H','M','V')
  if generic:missing.append('如使用通用介绍：真实住户身份、本人介绍资格、具体门店推荐优惠及时效适用条件待核。')
  row={k:s[k] for k in ('review_key','platform','comment_id','customer_uid','video_id')}
  row.update(role=role,demand_state=state,interest=interest,topics=topics,target_regions=regions,time_mentions=[],other_constraints=[],possible_topics=[],evidence=[s['comment_text']] if s['comment_text'] else [],reason=reason,context_used=['own','body'],needs_review=needs,contact_boundaries=[],context_flags={'same_author':c['same_author'],'source_version_conflict':c['source_conflict'],'post_is_context_only':not c['same_author'],'deeper_replies_read':False},reply_plan=dict(preferred_mother_slot=slot,generic_intro_suitable=generic,tone='normal',missing_facts=missing,caution=['只选已认可母句，不生成新正文；allow不是发送许可。']+(['通用介绍不构成具体价格、房态或条件承诺。'] if generic else ['不生成推销草稿，先核具体意图。']),contact_policy='allow'),human_confirmed=False,send_authorized=False,store_assignment=None)
  decisions.append(row)
 assert len({x['review_key'] for x in decisions})==len(decisions)
 assert set(inputs)=={x['review_key'] for x in decisions},(set(inputs)-{x['review_key'] for x in decisions},{x['review_key'] for x in decisions}-set(inputs))
 overrides=json.loads((P/'semantic-overrides.json').read_text(encoding='utf-8-sig')) if (P/'semantic-overrides.json').exists() else {}
 for r in decisions:
  if r['review_key'] in overrides:r.update(overrides[r['review_key']])
  text=src[r['review_key']]['comment_text']
  for fld in ('topics','target_regions','time_mentions','other_constraints','possible_topics','contact_boundaries'):
   for item in r[fld]:
    if isinstance(item,dict) and item.get('quote') is not None:assert item['quote'] in text,(r['review_key'],fld,item['quote'],text)
  assert all(q in text for q in r['evidence'])
 out=P/f'reviewed-{n:02}.jsonl'
 out.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in decisions),encoding='utf-8')
 progress={'shard':1,'completed_pages':[i for i in range(4) if (P/f'reviewed-{i:02}.jsonl').exists()],'processed':sum(len((P/f'reviewed-{i:02}.jsonl').read_text(encoding='utf-8').splitlines()) for i in range(4) if (P/f'reviewed-{i:02}.jsonl').exists()),'expected':692,'method':'AI逐key初筛与细筛；脚本仅结构展开和核验','independent_review':False,'human_confirmed':False,'send_authorized':False,'usage':'unknown'}
 (P/'progress.json').write_text(json.dumps(progress,ensure_ascii=False,indent=2),encoding='utf-8')
 print(json.dumps({'page':n,'records':len(decisions),'sha256':hashlib.sha256(out.read_bytes()).hexdigest()},ensure_ascii=False))
if __name__=='__main__':
 for a in sys.argv[1:]:build(int(a))
