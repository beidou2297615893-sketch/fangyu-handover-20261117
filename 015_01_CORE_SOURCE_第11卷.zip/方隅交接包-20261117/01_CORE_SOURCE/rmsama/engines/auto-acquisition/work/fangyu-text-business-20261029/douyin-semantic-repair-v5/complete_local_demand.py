"""Fill missing local mother replies for already-supported rental demand."""
import importlib.util
from pathlib import Path

import semantic_guard
import business_fit

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('completion_pool_classifier', HERE.parent / 'pool-sop-v3/classifier/classifier.py')
classifier = importlib.util.module_from_spec(spec)
spec.loader.exec_module(classifier)
classifier.RULES.extend([
    ('位置通勤', '位置查询', r'什么位置|哪个位置|啥位置|位置在[哪那]里|在[哪那]个位置|看看位置|发我位置|给个位置|^位置[?？!！。\s]*$'),
    ('价格预算', '价格询问', r'^(?:第[一二三四五六七八九十\d]+套)?多少(?:啊|呀|呢)?[?？!！。\s]*(?:第[一二三四五六七八九十\d]+套)?$'),
])


def complete(row):
    fit = business_fit.screen(row)
    if not fit['eligible_candidate'] or fit['lead_intent'] not in ('medium', 'high', 'super_high'):
        return None
    metadata = (row.get('classification') or {}).get('original_metadata') or {}
    if (row.get('post_author_same_as_commenter') or metadata.get('post_author_same_as_commenter')
            or str(row.get('reply_to', metadata.get('reply_to', '0')) or '0') != '0'):
        return None
    classification = classifier.classify(dict(row, original_classification=row))
    if row.get('local_recheck', {}).get('role') == 'demand':
        classification['pools'] = list(dict.fromkeys(row['local_recheck']['pools'] + classification['pools']))
        classification['needs_AI'] = not bool(classification['pools'])
        classification['classification_method'] = 'local_evidence_recheck'
    if classification.get('needs_AI') or not classification['pools']:
        return None
    result = dict(row, prior_classification=row.get('classification'), classification=classification,
                  pools=classification['pools'], subtags=classification.get('subtags', []))
    reply = semantic_guard.render(result)
    if not reply.get('draft_text') or reply.get('contact_hold'):
        return None
    result.update(reply=reply, semantic_review_stage='local_existing_demand_pool_completion',
                  reply_generation_model_calls=0)
    return result
