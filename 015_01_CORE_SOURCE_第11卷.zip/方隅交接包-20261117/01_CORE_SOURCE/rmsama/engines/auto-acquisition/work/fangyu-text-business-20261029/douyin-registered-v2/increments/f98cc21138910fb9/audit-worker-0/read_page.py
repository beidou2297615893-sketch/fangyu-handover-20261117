import json,sys
from pathlib import Path
b=Path('work/fangyu-text-business-20261029/douyin-registered-v2/increments/f98cc21138910fb9')
p=int(sys.argv[1]);lo=int(sys.argv[2]);hi=int(sys.argv[3])
d=json.loads((b/f'recall-audit/part-0/page-{p:02}.json').read_text(encoding='utf8'))
n=0
for g in d['post_groups']:
 cs=g['comments']; ids=[i for i in range(n,n+len(cs)) if lo<=i<hi]
 if ids:
  print('BODY',g['video'],json.dumps(g['post_body'],ensure_ascii=False))
  for c in cs:
   if lo<=n<hi:print(n,json.dumps(c,ensure_ascii=False,separators=(',',':')))
   n+=1
 else:n+=len(cs)
print('TOTAL',n)
