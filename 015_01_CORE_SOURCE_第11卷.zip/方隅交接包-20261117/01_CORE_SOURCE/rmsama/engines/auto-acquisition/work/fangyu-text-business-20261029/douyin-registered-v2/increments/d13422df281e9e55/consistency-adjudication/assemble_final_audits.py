"""Assemble explicit judgments only; no classification, publisher, or gate mutation."""
import copy
import hashlib
import json
import sys
from pathlib import Path

B = Path(__file__).resolve().parent.parent
D = B / 'consistency-adjudication'
W = B.parents[2]
sys.path.insert(0, str(W))
from mother_adapter import validate_new_review

FIELDS = {'role', 'demand_state', 'interest', 'topics', 'target_regions',
          'time_mentions', 'other_constraints', 'possible_topics', 'evidence',
          'reason', 'context_used', 'needs_review', 'contact_boundaries',
          'context_flags', 'reply_plan'}
IDENTITY = ('review_key', 'comment_id', 'customer_uid', 'video_id')
POOLS = {'价格预算','位置通勤','户型面积与居住方式','房内设施','宠物','楼层电梯','入住与租期','房源状态','费用合同','看房联系'}

def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p): return json.loads(p.read_text(encoding='utf-8'))
def rows(p): return [json.loads(s) for s in p.read_text(encoding='utf-8').splitlines() if s.strip()]
def encoded(rs): return ''.join(json.dumps(r,ensure_ascii=False,separators=(',',':'))+'\n' for r in rs).encode('utf-8')
def check_frozen(path, data):
    if path.exists() and path.read_bytes() != data: raise ValueError(f'existing output differs: {path}')
def write_frozen(path, data):
    check_frozen(path,data)
    if not path.exists():
        with path.open('xb') as f: f.write(data)
def require(ok, message):
    if not ok: raise ValueError(message)

def main():
    adjudication = D/'adjudications.jsonl'
    validation = D/'validation.json'
    if not adjudication.is_file() or not validation.is_file():
        print('WAITING: complete adjudications.jsonl and validation.json are required; no output written')
        return 2
    # No incomplete or malformed adjudication can produce derived outputs.
    adrows=rows(adjudication); val=read(validation)
    require(val.get('passed') is True and val.get('adjudication_count')==85
            and val.get('review_key_set_equal') is True and val.get('comment_id_set_equal') is True
            and val.get('quotes_exact_substrings') is True and val.get('formal_adapter_validated_count')==85
            and val.get('adjudications_sha256')==sha(adjudication)
            and val.get('validator_sha256')==sha(W/'mother_adapter.py')
            and val.get('input_sha256')==sha(D/'input-85.json')
            and val.get('compact_input_sha256')==sha(D/'input-85-compact.json'), 'adjudication validation incomplete or SHA mismatch')
    compact=read(D/'input-85-compact.json'); expected=compact['expected_review_keys']
    require(len(expected)==85 and len(set(expected))==85,'invalid expected keys')
    require(len(adrows)==85 and len({a['review_key'] for a in adrows})==85 and {a['review_key'] for a in adrows}==set(expected),'incomplete adjudications')
    require(sha(D/'input-85.json')==compact['full_original_packet_sha256'],'compact input source changed')
    require(set(next(iter(compact['semantic_variants'].values())))==FIELDS,'compiler field contract mismatch')
    for a in adrows:
        require(set(a)=={'review_key','decision','reason','final_semantics','justified_difference'},'adjudication schema mismatch')
        require(isinstance(a['decision'],str) and a['decision'].strip() and isinstance(a['reason'],str) and a['reason'].strip(),'missing adjudication decision/reason')
        require(set(a['final_semantics'])==FIELDS,'adjudication fields mismatch')
        require(a['justified_difference'] is None or isinstance(a['justified_difference'],str),'invalid difference statement')
    by_ad={a['review_key']:a for a in adrows}

    source_paths=[B/'manifest.json',B/'input.jsonl',B/'semantic-audit-selection.json',D/'input-85.json',D/'input-85-compact.json',adjudication,validation,B/'coordinator-semantic-consistency-observations.json',W/'mother_adapter.py',W/'compile_reviewed_increment.py',W/'merge_completed_semantic_audits.py']
    for i in range(3): source_paths.extend([B/f'reviewed-new-{i}.jsonl',B/f'shard-{i}.jsonl'])
    for part in range(2):
        base=B/f'recall-audit/part-{part}';source_paths.append(base/'task.json')
        for n in range(7): source_paths.extend([base/f'page-{n:02}.json',base/f'page-{n:02}.audit.jsonl'])
    source_sha={str(p):sha(p) for p in source_paths}
    manifest=read(B/'manifest.json'); inputs=rows(B/'input.jsonl'); src={r['review_key']:r for r in inputs}
    require(hashlib.sha256((B/'input.jsonl').read_bytes().replace(b'\r\n',b'\n')).hexdigest()==manifest['input_sha256'] and manifest['input_sha256'].startswith(B.name),'input sha mismatch')
    require(len(inputs)==len(src)==manifest['new_comments']==2075,'input count or keys mismatch')
    primary={}; origin={}
    for i in range(3):
        p=B/f'reviewed-new-{i}.jsonl'; sp=B/f'shard-{i}.jsonl'
        require(rows(sp)==inputs[i::3],'input shard mismatch')
        rs=rows(p);require(len(rs)==len({r['review_key'] for r in rs}),'duplicate primary keys')
        for r in rs:
            k=r['review_key']; require(k not in primary and k in src,'unexpected or repeated primary')
            require(all(r.get(f)==src[k].get(f) for f in IDENTITY),'primary identity mismatch')
            require(FIELDS <= set(r),'primary fields incomplete')
            require(r.get('human_confirmed') is False and r.get('send_authorized') is False and r.get('store_assignment') is None,'primary permissions or store mismatch')
            primary[k]=r;origin[k]=p
    require(set(primary)==set(src) and len(primary)==2075,'primary coverage mismatch')

    selection=read(B/'semantic-audit-selection.json'); audits={}; assignments=[[],[]]
    for part in range(2):
        base=B/f'recall-audit/part-{part}'; taskpath=base/'task.json';task=read(taskpath)
        require(task['pages']==7,'unexpected page count')
        for source in task['primary_sources']:
            require(sha(B/source['path'])==source['sha256'],'primary frozen SHA mismatch')
        local=[]
        for n in range(task['pages']):
            page=base/f'page-{n:02}.json'; ap=base/f'page-{n:02}.audit.jsonl'
            comments=[c for g in read(page)['post_groups'] for c in g['comments']]; ks=[c['key'] for c in comments]
            rs=rows(ap); keyed={r['review_key']:r for r in rs}
            require(len(ks)==len(set(ks))==len(rs)==len(keyed) and set(ks)==set(keyed),'page coverage mismatch')
            for c in comments:
                k=c['key']; a=keyed[k]
                require(k in primary and k not in audits and c['text']==src[k]['comment_text'],'audit key or source quote mismatch')
                require(a['decision'] in ('keep','change') and isinstance(a['reason'],str) and a['reason'].strip(),'audit decision/reason mismatch')
                require(isinstance(a['patch'],dict) and set(a['patch'])<=FIELDS and (a['decision']!='keep' or not a['patch']),'invalid audit patch')
                audits[k]=(part,ap,a);local.append(k);assignments[part].append(k)
        require(len(local)==task['records'] and set(local)==set(task['expected_review_keys']),'part coverage mismatch')
    require(len(audits)==selection['selected']==1576 and set(audits)==set(selection['keys']),'selection coverage mismatch')
    require(set(expected)<=set(primary) and len(set(expected)&set(audits))==48,'overlap mismatch')
    # Newly adjudicated keys follow frozen input order, not judgment order.
    extra=[r['review_key'] for r in inputs if r['review_key'] in by_ad and r['review_key'] not in audits]
    require(len(extra)==37,'new adjudication count mismatch')
    for i,k in enumerate(extra): assignments[i%2].append(k)
    require(sum(map(len,assignments))==1613 and len(set(assignments[0]+assignments[1]))==1613,'final coverage mismatch')

    result=[[],[]]; final={k:copy.deepcopy(v) for k,v in primary.items()};adsha=sha(adjudication)
    for part,keys in enumerate(assignments):
        for k in keys:
            old=audits.get(k); a=by_ad.get(k); merged=copy.deepcopy(primary[k])
            if old: merged.update(copy.deepcopy(old[2]['patch']))
            if a: merged.update(copy.deepcopy(a['final_semantics']))
            patch={f:copy.deepcopy(merged[f]) for f in sorted(FIELDS) if merged[f]!=primary[k][f]}
            meta={'original_audit': None if not old else {'path':str(old[1].relative_to(B)).replace('\\','/'),'sha256':sha(old[1]),'decision':old[2]['decision'],'reason':old[2]['reason']},
                  'adjudication':None if not a else {'path':str(adjudication.relative_to(B)).replace('\\','/'),'sha256':adsha,'decision':a['decision'],'reason':a['reason'],'justified_difference':a['justified_difference']}}
            result[part].append({'review_key':k,'decision':'change' if patch else 'keep','reason':a['reason'] if a else old[2]['reason'],'patch':patch,'metadata':meta})
            final[k]=merged
    require(set(by_ad)<=set(assignments[0]+assignments[1]),'adjudication omitted')

    # Mirrors compiler quote and fixed-pool checks; all 2075, not only reviewed subset.
    for k,r in final.items():
        s=src[k];require(all(r.get(f)==primary[k].get(f) for f in r if f not in FIELDS),'nonsemantic field changed')
        require(all(r.get(f)==s.get(f) for f in IDENTITY),'final identity mismatch')
        require(r.get('human_confirmed') is False and r.get('send_authorized') is False and r.get('store_assignment') is None,'final permissions or store mismatch')
        require(all(t['pool'] in POOLS for t in r['topics']),'invalid topic pool')
        own=[s['comment_text']]+([s['post_body']] if s['post_author_same_as_commenter'] else [])
        quotes=list(r.get('evidence',[]))
        for field in ('topics','target_regions','time_mentions','other_constraints','contact_boundaries'):
            quotes += [x['quote'] for x in r.get(field,[]) if isinstance(x,dict) and 'quote' in x]
        require(all(isinstance(q,str) and q and any(q in text for text in own) for q in quotes),f'quote mismatch: {k}')

    # The only added attributes are the same method and stages compiler supplies.
    isolated=[]
    for s in inputs:
        r=copy.deepcopy(final[s['review_key']]);r['classification_method']='ai_semantic_initial_and_detailed';r['classification_stages_completed']=['initial_semantic','detailed_semantic'];isolated.append(r)
    isolation=D/'isolated-final-semantic-source.jsonl'; data=encoded(isolated);check_frozen(isolation,data);write_frozen(isolation,data)
    digest=sha(isolation);cache={}
    for r in isolated:
        item=copy.deepcopy(r);item['classification_review_source']={'path':str(isolation),'sha256':digest}
        validate_new_review(item,B,cache)
    require(len(cache)==1,'unexpected validation source cache')

    payloads=[encoded(part) for part in result];outputs=[B/f'recall-audit-{i}.jsonl' for i in range(2)]
    receipt={'complete':True,'primary_count':len(primary),'original_audit_count':len(audits),'adjudication_count':len(adrows),'overlapping_adjudications':48,'new_adjudications':37,'unique_review_count':1613,'part_counts':[len(p) for p in result],'original_audit_change_decisions':sum(v[2]['decision']=='change' for v in audits.values()),'final_patch_nonempty':sum(bool(r['patch']) for p in result for r in p),'adjudicated_patch_nonempty':sum(bool(r['patch']) for p in result for r in p if r['metadata']['adjudication']), 'audit_sha256':[hashlib.sha256(x).hexdigest() for x in payloads], 'isolated_source_path':str(isolation.relative_to(B)).replace('\\','/'),'isolated_source_sha256':digest,'adapter_validated_count':len(isolated),'identity_permissions_store_and_quote_checks_passed':True,'semantic_fields_contract':sorted(FIELDS),'semantic_field_count':len(FIELDS),'source_sha256':source_sha,'old_merger_must_not_be_rerun':'It would produce different original-only audit files and mutates quality-gate.json.', 'counts_are_not_accuracy_or_recovered_people':True,'platform_calls':0,'actual_task_usage':None}
    receiptpath=D/'final-audit-assembly-receipt.json';receiptdata=json.dumps(receipt,ensure_ascii=False,indent=2).encode('utf-8')
    for p,data in list(zip(outputs,payloads))+[(receiptpath,receiptdata)]: check_frozen(p,data)
    # Re-read every input before committing derived artifacts to detect concurrent edits.
    require(all(sha(Path(p))==h for p,h in source_sha.items()),'source changed during assembly')
    for p,data in list(zip(outputs,payloads))+[(receiptpath,receiptdata)]: write_frozen(p,data)
    print(json.dumps({k:receipt[k] for k in ('primary_count','original_audit_count','adjudication_count','new_adjudications','unique_review_count','part_counts','adapter_validated_count')},ensure_ascii=False))
    return 0

if __name__=='__main__':
    try: sys.exit(main())
    except (ValueError,KeyError,TypeError,AssertionError,OSError,json.JSONDecodeError) as exc:
        print(f'ASSEMBLY FAILED: {exc}',file=sys.stderr);sys.exit(1)
