"""Adapt the validated d13422df281e9e55 assembly route; preserve every source byte.
Model judgments enter only through explicit audit/adjudication records.
"""
import pathlib,json,hashlib,copy,sys,datetime
B=pathlib.Path(__file__).resolve().parent.parent;D=B/'consistency-adjudication';W=B.parents[2]
sys.path.insert(0,str(W))
from mother_adapter import validate_new_review
FIELDS={'role','demand_state','interest','topics','target_regions','time_mentions','other_constraints','possible_topics','evidence','reason','context_used','needs_review','contact_boundaries','context_flags','reply_plan'}
IDENTITY=('review_key','comment_id','customer_uid','video_id','platform')
get=lambda p:json.loads(p.read_text('utf-8-sig'))
jl=lambda p:[json.loads(l) for l in p.read_text('utf-8-sig').splitlines() if l.strip()]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
encode=lambda rs:''.join(json.dumps(r,ensure_ascii=False,separators=(',',':'))+'\n' for r in rs).encode('utf-8')
def require(ok,message):
 if not ok:raise ValueError(message)
def freeze(p,raw):
 if p.exists():require(p.read_bytes()==raw,'Frozen derived output differs: '+str(p))
 else:p.write_bytes(raw)
def main():
 if len(sys.argv)!=3:raise ValueError('Pass adjudication JSONL and validation JSON paths')
 adpath=pathlib.Path(sys.argv[1]).resolve();valpath=pathlib.Path(sys.argv[2]).resolve()
 require(adpath.is_relative_to(B) and valpath.is_relative_to(B),'adjudication must be batch local')
 packetpath=D/'targeted-conflict-packet.json';packet=get(packetpath)
 expected=[r['source']['review_key'] for g in packet['groups'] for r in g['records']]
 adrows=jl(adpath);val=get(valpath);byad={r['review_key']:r for r in adrows}
 require(val.get('status')=='PASS' and val['validator']['pass_count']==5 and val['validator']['failure_count']==0,'targeted validation not passed')
 require(val['id_set_equal'] is True and val['complete_semantic_field_count']==15,'targeted validation incomplete')
 require(val['packet']['sha256']==sha(packetpath) and val['adjudications']['sha256']==sha(adpath),'targeted source/adjudication SHA mismatch')
 require(val['validator']['sha256']==sha(W/'mother_adapter.py'),'targeted adapter differs')
 for field in ('isolated_review_source','isolated_precheck'):
  require(sha(pathlib.Path(val[field]['path']))==val[field]['sha256'],'targeted isolation changed')
 require(len(expected)==len(set(expected))==len(adrows)==len(byad)==5 and set(byad)==set(expected),'targeted key coverage')
 for a in adrows:
  require(set(a['final_semantics'])==FIELDS,'complete 15 semantic fields required')
  require(isinstance(a['reason'],str) and a['reason'].strip(),'adjudication reason required')
  require(a.get('justified_difference') is None or isinstance(a['justified_difference'],str),'invalid difference statement')
 inputs=jl(B/'input.jsonl');src={r['review_key']:r for r in inputs};m=get(B/'manifest.json')
 require(len(inputs)==len(src)==m['new_comments']==4380,'source coverage')
 require(hashlib.sha256((B/'input.jsonl').read_bytes().replace(b'\r\n',b'\n')).hexdigest()==m['input_sha256'],'input hash changed')
 sourcepaths=[packetpath,adpath,valpath,B/'input.jsonl',B/'manifest.json',B/'semantic-audit-selection.json',W/'mother_adapter.py',W/'compile_reviewed_increment.py']
 primary={};origin={}
 for i in range(3):
  p=B/f'reviewed-new-{i}.jsonl';s=B/f'shard-{i}.jsonl';sourcepaths.extend([p,s,B/f'shard-{i}-validation.json'])
  require(jl(s)==inputs[i::3],'source shard differs')
  require(sha(p)==packet['primary_sources'][p.name],'primary changed after targeted packet')
  for r in jl(p):
   k=r['review_key'];require(k not in primary and k in src,'duplicate or unexpected primary')
   require(all(r.get(f)==src[k].get(f) for f in IDENTITY),'primary identity mismatch')
   require(FIELDS<=set(r),'primary fields missing');primary[k]=r;origin[k]=p
 require(set(primary)==set(src),'primary coverage')
 audits={};assignments=[[],[]];task_counts=[]
 for part in range(2):
  folder=B/f'recall-audit/part-{part}';taskfile=folder/'task.json';task=get(taskfile);sourcepaths.append(taskfile)
  require(task['pages']==15,'expected 15 original audit pages')
  for s in task['primary_sources']:require(sha(B/s['path'])==s['sha256'],'audit primary SHA changed')
  for n in range(task['pages']):
   page=folder/f'page-{n:02}.json';ap=folder/f'page-{n:02}.audit.jsonl';sourcepaths.extend([page,ap])
   ks=[c['key'] for g in get(page)['post_groups'] for c in g['comments']];rs=jl(ap);index={r['review_key']:r for r in rs}
   require(len(rs)==len(index)==len(ks) and set(index)==set(ks),'audit page coverage')
   for k in ks:
    a=index[k];require(k not in audits,'duplicate audit key')
    require(a['decision'] in ('keep','change') and isinstance(a['reason'],str) and bool(a['reason'].strip()),'invalid explicit audit')
    require(set(a['patch'])<=FIELDS and (a['decision']!='keep' or a['patch']=={}),'invalid audit patch')
    audits[k]=(part,ap,a);assignments[part].append(k)
  require(len(assignments[part])==task['records'] and set(assignments[part])==set(task['expected_review_keys']),'part coverage')
  task_counts.append(task['records'])
 require(task_counts==[1752,1751],'original task record counts')
 selection=get(B/'semantic-audit-selection.json')
 require(len(audits)==selection['selected']==3503 and set(audits)==set(selection['keys']),'original selected audit coverage')
 extra=[r['review_key'] for r in inputs if r['review_key'] in byad and r['review_key'] not in audits]
 require(len(extra)==2 and len(set(byad)&set(audits))==3,'targeted overlap or extra count differs')
 for i,k in enumerate(extra):assignments[i%2].append(k)
 versions={str(p):sha(p) for p in sourcepaths};adsha=sha(adpath)
 result=[[],[]];final={k:copy.deepcopy(r) for k,r in primary.items()}
 for part,keys in enumerate(assignments):
  for k in keys:
   original=audits.get(k);ad=byad.get(k);merged=copy.deepcopy(primary[k])
   if original:merged.update(copy.deepcopy(original[2]['patch']))
   if ad:merged.update(copy.deepcopy(ad['final_semantics']))
   patch={f:copy.deepcopy(merged[f]) for f in sorted(FIELDS) if merged[f]!=primary[k][f]}
   provenance={'original_audit':None if not original else {'path':str(original[1].relative_to(B)),'sha256':versions[str(original[1])],'decision':original[2]['decision'],'reason':original[2]['reason']},'targeted_adjudication':None if not ad else {'path':str(adpath.relative_to(B)),'sha256':adsha,'decision':ad['decision'],'reason':ad['reason'],'justified_difference':ad.get('justified_difference')}}
   result[part].append({'review_key':k,'decision':'change' if patch else 'keep','reason':ad['reason'] if ad else original[2]['reason'],'patch':patch,'metadata':provenance});final[k]=merged
 require(sum(map(len,result))==3505 and len({r['review_key'] for p in result for r in p})==3505,'final unique independent coverage')
 quotes=0
 for k,r in final.items():
  require(all(r.get(f)==primary[k].get(f) for f in r if f not in FIELDS),'nonsemantic mutation')
  require(all(r.get(f)==src[k].get(f) for f in IDENTITY),'final identity mismatch')
  require(r['human_confirmed'] is False and r['send_authorized'] is False and r['store_assignment'] is None,'permission/store mismatch')
  s=src[k];own=[s['comment_text']]+([s['post_body']] if s['post_author_same_as_commenter'] else [])
  qs=r['evidence']+[x['quote'] for f in ('topics','target_regions','time_mentions','other_constraints','contact_boundaries','possible_topics') for x in r[f] if isinstance(x,dict) and 'quote' in x]
  require(all(isinstance(q,str) and q and any(q in t for t in own) for q in qs),'quote mismatch '+k);quotes+=len(qs)
 grouped={}
 for k,r in final.items():
  s=src[k];g=(s['video_id'],s['comment_text'],s['post_author_same_as_commenter'],s['direct_parent_text'],s['post_body'],s['source_version_conflict']);grouped.setdefault(g,[]).append(r)
 conflicts=[]
 for g,rs in grouped.items():
  if len({(r['role'],r['demand_state'],r['interest']) for r in rs})>1:
   conflicts.append({'text':g[1],'video_id':g[0],'keys':[r['review_key'] for r in rs],'labels':[(r['role'],r['demand_state'],r['interest']) for r in rs]})
 require(not conflicts,'Unresolved same-context core conflicts: '+json.dumps(conflicts,ensure_ascii=False))
 isolated=[]
 for s in inputs:
  r=copy.deepcopy(final[s['review_key']]);r.update(classification_method='ai_semantic_initial_and_detailed',classification_stages_completed=['initial_semantic','detailed_semantic']);isolated.append(r)
 isolation=D/'isolated-final-semantic-source.jsonl';freeze(isolation,encode(isolated));digest=sha(isolation);cache={}
 for r in isolated:
  candidate=copy.deepcopy(r);candidate['classification_review_source']={'path':str(isolation),'sha256':digest};validate_new_review(candidate,B,cache)
 outputs=[B/f'recall-audit-{i}.jsonl' for i in range(2)];payloads=[encode(p) for p in result]
 receipt={'complete':True,'primary_count':4380,'original_audit_count':3503,'targeted_adjudication_count':5,'overlapping_adjudications':3,'new_adjudications':2,'unique_review_count':3505,'part_counts':list(map(len,result)),'original_audit_change_decisions':sum(a[2]['decision']=='change' for a in audits.values()),'final_patch_nonempty':sum(bool(r['patch']) for p in result for r in p),'audit_sha256':[hashlib.sha256(p).hexdigest() for p in payloads],'isolated_source_path':str(isolation.relative_to(B)),'isolated_source_sha256':digest,'adapter_validated_count':4380,'adapter_sha256':sha(W/'mother_adapter.py'),'identity_permissions_store_and_quote_checks_passed':True,'quote_checks':quotes,'same_context_core_conflicts':0,'source_sha256':versions,'old_merger_must_not_be_rerun':True,'counts_are_not_accuracy_or_recovered_people':True,'actual_task_usage':None,'platform_calls':0,'source_database_modified':False}
 require(all(sha(pathlib.Path(p))==h for p,h in versions.items()),'input changed during assembly')
 # All comparisons precede commit of final canonical audit files.
 for p,data in zip(outputs,payloads):
  if p.exists():require(p.read_bytes()==data,'Existing canonical audits differ')
 for p,data in zip(outputs,payloads):freeze(p,data)
 freeze(D/'final-audit-assembly-receipt.json',json.dumps(receipt,ensure_ascii=False,indent=2).encode('utf-8'))
 print(json.dumps({k:receipt[k] for k in ('primary_count','original_audit_count','targeted_adjudication_count','new_adjudications','unique_review_count','part_counts','adapter_validated_count','same_context_core_conflicts')},ensure_ascii=False))
if __name__=='__main__':main()
