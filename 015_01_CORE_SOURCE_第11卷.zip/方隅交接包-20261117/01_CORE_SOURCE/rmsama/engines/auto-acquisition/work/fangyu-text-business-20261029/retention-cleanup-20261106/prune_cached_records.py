"""Short-transaction removal from private text caches; shared send indexes stay intact."""
import hashlib
import json
from pathlib import Path
import sqlite3
import sys
import time

HERE=Path(__file__).resolve().parent
WORK=HERE.parent
ROOT=WORK.parents[1]
sys.path.insert(0,str(WORK/'recency-priority'))
import retention30

def known_expired(value,platform=None):
    value=str(value or '')
    if value.startswith('comment:'):value=value.split(':',1)[1]
    if not value:return False
    domains=(platform,) if platform in ('douyin','xiaohongshu') else ('douyin','xiaohongshu')
    return any(retention30.fingerprint(domain,value) in retention30.registry() for domain in domains)

def prune_cache(path):
    path=path.resolve()
    if not path.is_relative_to(WORK.resolve()):raise ValueError('cache outside intended text workspace')
    if path.name.endswith('-wal') or 'fixtures' in path.parts:return {'path':str(path),'removed':0}
    db=sqlite3.connect(path,timeout=2,isolation_level=None)
    db.execute('PRAGMA foreign_keys=ON')
    totals={};deferred=[]
    try:
        tables=[row[0] for row in db.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'")]
        # Child tables are processed before their referenced parents.
        ordered=[];seen=set()
        def visit(table):
            if table in seen:return
            seen.add(table)
            for other in tables:
                if any(row[2]==table for row in db.execute('PRAGMA foreign_key_list("'+other.replace('"','""')+'")')):visit(other)
            ordered.append(table)
        for table in tables:visit(table)
        for table in ordered:
            safe='"'+table.replace('"','""')+'"'
            columns={row[1] for row in db.execute('PRAGMA table_info('+safe+')')}
            key=next((name for name in ('comment_id','cid','comment','stable_key') if name in columns),None)
            if not key:continue
            query='SELECT rowid,"'+key+'"'+(',platform' if 'platform' in columns else '')+' FROM '+safe
            where=" WHERE kind='comments'" if 'kind' in columns else ''
            try:rows=db.execute(query+where).fetchall()
            except sqlite3.DatabaseError:continue
            stale=[(row[0],row[1]) for row in rows if known_expired(row[1],row[2] if len(row)>2 else None)]
            removed=0
            for start in range(0,len(stale),200):
                try:
                    db.execute('BEGIN IMMEDIATE')
                    before=db.total_changes
                    db.executemany('DELETE FROM '+safe+' WHERE rowid=? AND "'+key+'"=?',stale[start:start+200])
                    removed+=db.total_changes-before;db.commit()
                except sqlite3.DatabaseError as error:
                    db.rollback();deferred.append({'table':table,'error':getattr(error,'sqlite_errorname','sqlite_error')});break
                time.sleep(.005)
            if removed:totals[table]=removed
    finally:db.close()
    return {'path':str(path),'removed':sum(totals.values()),'tables':totals,'deferred':deferred}

def prune_completed_assessments(protected_tasks,database=None):
    protected=set()
    for task in protected_tasks:
        queue=task/'approved-cli-queue.json'
        if queue.exists():
            for item in json.loads(queue.read_text(encoding='utf-8-sig')).get('items',[]):
                protected.add(str(item.get('cid') or item.get('comment_id') or ''))
    path=database or ROOT/'work/shared-acquisition-ledger/shared.sqlite3'
    db=sqlite3.connect(path,timeout=2,isolation_level=None)
    db.execute('PRAGMA foreign_keys=ON')
    rows=db.execute('SELECT a.platform,a.customer,a.comment,a.updated,l.status FROM assessments a JOIN leads l USING(platform,customer,comment)').fetchall()
    stale=[row for row in rows if known_expired(row[2],row[0]) and row[2] not in protected and row[4] not in ('reserved','unknown') and row[3]<time.time()-600]
    removed=0
    for start in range(0,len(stale),100):
        db.execute('BEGIN IMMEDIATE')
        for platform,customer,comment,updated,status in stale[start:start+100]:
            removed+=db.execute('''DELETE FROM assessments WHERE platform=? AND customer=? AND comment=? AND updated=?
             AND NOT EXISTS(SELECT 1 FROM reservations WHERE platform=? AND comment=? AND status IN ('reserved','unknown'))''',
             (platform,customer,comment,updated,platform,comment)).rowcount
        db.commit();time.sleep(.01)
    db.close()
    return {'removed_expired_assessment_bodies':removed,'protected_active_queue_comments':len(protected),
            'leads_reservations_and_evidence_untouched':True}

def prune_unused_leads(database=None):
    """Remove confirmed cleared, uncontacted rows; never touch a delivery index."""
    path=database or ROOT/'work/shared-acquisition-ledger/shared.sqlite3'
    db=sqlite3.connect(path,timeout=2,isolation_level=None);db.execute('PRAGMA foreign_keys=ON')
    db.execute('CREATE TABLE IF NOT EXISTS business_cleared_fingerprints(digest TEXT PRIMARY KEY)')
    rows=db.execute("SELECT platform,customer,comment FROM leads WHERE status='unverified' AND (review_time IS NULL OR review_time<?)", (int(time.time())-600,)).fetchall()
    removed=0
    for platform,customer,comment in rows:
        if not known_expired(comment,platform):continue
        try:
            db.execute('BEGIN IMMEDIATE')
            # Recheck eligibility inside the same short transaction as deletion.
            if db.execute("SELECT 1 FROM leads WHERE platform=? AND customer=? AND comment=? AND status='unverified' AND (review_time IS NULL OR review_time<?) AND NOT EXISTS(SELECT 1 FROM reservations WHERE platform=? AND comment=?) AND NOT EXISTS(SELECT 1 FROM assessments WHERE platform=? AND comment=?)",(platform,customer,comment,int(time.time())-600,platform,comment,platform,comment)).fetchone():
                db.execute('INSERT OR IGNORE INTO business_cleared_fingerprints VALUES(?)',(retention30.fingerprint(platform,comment),))
                removed+=db.execute("DELETE FROM leads WHERE platform=? AND customer=? AND comment=? AND status='unverified'",(platform,customer,comment)).rowcount
            db.commit()
        except sqlite3.DatabaseError:
            db.rollback();raise
    db.close();return removed

if __name__=='__main__':
    paths=[p for p in WORK.rglob('*.sqlite3') if p.is_file() and 'fixtures' not in p.parts]
    results=[prune_cache(path) for path in paths]
    tasks=[ROOT/'work/douyin-local-20261104-40aaf15b06']
    control=ROOT/'work/douyin-local-control/active.json'
    if control.exists():
        current=json.loads(control.read_text(encoding='utf-8-sig')).get('task')
        if current:tasks.append(Path(current))
    shared=prune_completed_assessments(tasks)
    shared['removed_unused_cleared_leads']=prune_unused_leads()
    summary={'cache_databases':results,'cache_rows_removed':sum(result['removed'] for result in results),'shared':shared,
             'platform_requests':0,'active_send_batch_modified':False}
    (HERE/'cache-cleanup-result.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({'cache_rows_removed':summary['cache_rows_removed'],'shared':shared,'deferred':[r for r in results if r.get('deferred')]},ensure_ascii=False))
