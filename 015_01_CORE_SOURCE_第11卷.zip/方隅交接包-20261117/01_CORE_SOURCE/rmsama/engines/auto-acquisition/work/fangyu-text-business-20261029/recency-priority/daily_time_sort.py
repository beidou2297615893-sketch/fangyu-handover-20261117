"""Only reorder existing eligible queues by original time; no AI or platform IO."""
import argparse,json,hashlib,os,msvcrt,sqlite3,sys
from pathlib import Path
from datetime import datetime,timezone,timedelta
import recency
HERE=Path(__file__).resolve().parent
WORK=HERE.parent
sys.path.insert(0,str(WORK/'business-fit'))
import business_fit
OUT=HERE/'daily-priority'
OUT.mkdir(exist_ok=True)
def sha(b):return hashlib.sha256(b).hexdigest()
def atomic(p,data):
 tmp=p.with_name(p.name+f'.{os.getpid()}.tmp');tmp.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8');tmp.replace(p)
def run(platform=None):
 now=datetime.now(timezone.utc);record={'updated_at':now.isoformat(),'local_day':now.astimezone(timezone(timedelta(hours=8))).date().isoformat(),'sort':'time_window_7_15_days_then_budget_then_intent_then_newest','model_calls':0,'platform_requests':0,'source_classification_modified':False,'platforms':{}}
 if platform and (OUT/'current.json').exists():
  record['platforms']=json.loads((OUT/'current.json').read_text(encoding='utf-8-sig'))['platforms']
 sources={'douyin':WORK/'douyin-semantic-repair-v5/pending-candidates.jsonl','xiaohongshu':HERE/'xiaohongshu-pending-by-source-and-recency.jsonl'}
 if platform:sources={platform:sources[platform]}
 for platform,source in sources.items():
  data=source.read_bytes();rows=[json.loads(l) for l in data.decode('utf-8-sig').splitlines() if l.strip()]
  ledger=WORK.parent/'shared-acquisition-ledger/shared.sqlite3'
  with sqlite3.connect(ledger.resolve().as_uri()+'?mode=ro',uri=True) as db:
   blocked=list(db.execute("SELECT comment,customer FROM leads WHERE platform=? AND status IN ('sent','unknown','reserved') UNION SELECT comment,customer FROM reservations WHERE platform=? AND status IN ('sent','unknown','reserved')",(platform,platform)))
   aliases=dict(db.execute('SELECT alias,canonical FROM identity_aliases WHERE platform=? AND verified=1',(platform,)))
  def canon(uid):
   uid=str(uid or '');seen=set()
   while uid in aliases and uid not in seen:seen.add(uid);uid=aliases[uid]
   return uid
  blocked_ids={str(x[0]) for x in blocked};blocked_users={canon(x[1]) for x in blocked if x[1]}
  before=len(rows)
  rows=[r for r in rows if str(r.get('comment_id')) not in blocked_ids and (not r.get('customer_uid') or canon(r['customer_uid']) not in blocked_users)]
  excluded_by_current_ledger=before-len(rows)
  before_screening=len(rows)
  if platform=='douyin':
   pool=WORK/'douyin-semantic-repair-v5/all-pool-business-fit.jsonl'
   if pool.exists():
    business_fit.prepare_low_price_comment_videos_from_jsonl(pool, only_video_ids={str(r.get('video_id') or '') for r in rows if r.get('video_id')})
   else:
    business_fit.prepare_low_price_comment_videos(rows)
  else:
   business_fit.prepare_low_price_comment_videos(rows)
  screened=[]
  for row in rows:
   fit=business_fit.screen(row)
   if fit['eligible_candidate']:
    row['commercial_fit']=fit
    row['commercial_priority']=fit['eligible_priority']
    screened.append(row)
  rows=screened
  excluded_by_latest_business_fit=before_screening-len(rows)
  if platform=='douyin':
   for row in rows:
    row['reply_priority']=recency.douyin_reply_priority(row,now.timestamp())
   rows.sort(key=lambda r:r['reply_priority']['key'])
  else:
   rows.sort(key=lambda r:recency.priority_key(r,now.timestamp()))
  assert all(r.get('commercial_fit',{}).get('eligible_candidate') is True for r in rows),'unvalidated input queue'
  payload=''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows).encode('utf-8')
  # If a live builder replaced the source, retry next run instead of publishing stale metadata.
  if sha(source.read_bytes())!=sha(data):raise RuntimeError('source changed while sorting; rerun')
  digest=sha(payload);dest=OUT/f'{platform}-{digest[:16]}.jsonl'
  if not dest.exists():dest.write_bytes(payload)
  counts={label:sum(recency.key(r,now.timestamp())[0]==i for r in rows) for i,label in enumerate(recency.BANDS)}
  record['platforms'][platform]={'source':str(source),'source_sha256':sha(data),'queue':str(dest),'sha256':digest,'count':len(rows),'excluded_by_current_ledger':excluded_by_current_ledger,'ledger_recheck_required_at_send':True,'recent_7_days':counts[recency.BANDS[0]],'recent_15_days':counts[recency.BANDS[0]]+counts[recency.BANDS[1]],'time_band_counts':counts,'time_unknown':counts[recency.BANDS[-1]]}
  record['platforms'][platform]['business_fit_version']=business_fit.VERSION
  record['platforms'][platform]['excluded_by_latest_business_fit']=excluded_by_latest_business_fit
  if platform=='douyin':record['platforms'][platform]['active_pool_policy']=recency.DOUYIN_ACTIVE_POOL_POLICY
  if platform=='douyin':
   from collections import Counter
   record['platforms'][platform]['reply_priority_version']=recency.DOUYIN_REPLY_PRIORITY_VERSION
   record['platforms'][platform]['reply_pool_counts']=dict(Counter(row['reply_priority']['followup_pool'] for row in rows))
 atomic(OUT/'current.json',record)
 print(json.dumps(record,ensure_ascii=False))
if __name__=='__main__':
 parser=argparse.ArgumentParser();parser.add_argument('--platform',choices=['douyin','xiaohongshu']);args=parser.parse_args()
 with (OUT/'sort.lock').open('a+b') as lock:
  lock.seek(0)
  if not lock.read(1):lock.write(b'0');lock.flush()
  lock.seek(0);msvcrt.locking(lock.fileno(),msvcrt.LK_NBLCK,1)
  try:run(args.platform)
  except Exception as e:
   atomic(OUT/'last-error.json',{'at':datetime.now(timezone.utc).isoformat(),'error':str(e)});raise
