import json
from pathlib import Path
p=Path('work/fangyu-text-business-20261029/increments/032413f79937dc52')
rows=[]
for n in (8,9,10,11):
 rows += [json.loads(l) for l in (p/f'shard-{n:02}.jsonl').read_text(encoding='utf-8').splitlines()]
def ids(s): return {'I'+x for x in s.split()}
# Each set is an individually reviewed list, not a lexical classifier.
supply=ids('0811 0812 0813 0814 0845 0849 0856 0878 0879 0881 0882 0883 0889 0890 0891 0898 0899 0908 0911 0922 0929 0933 0938 0947 0953 0955 0958 0961 0962 0963 0970 0971 0973 0974 0975 0987 1060 1087 1089 1092 1097 1106 1125 1128 1140 1145 1146 1147 1155 1159 1160 1161 1162 1165')
discussion=ids('1056 1085 1139 1163 0875 0907 0912 0960 1007 1070 1076 1077 1079 1084 1100 1110 1117 1123 1126 1133 1148 1151 1164')
unknown=ids('0805 0940 0946 0839 0853 0870 0901 0904 0915 0918 0920 0952 0956 0957 0965 0976 1039 1046 1114 1116 1124 1127 1138 1144')
# First-person explicit search/needs even where the surrounding post is not an offer.
active=ids('0815 0828 0848 0860 0888 0903 0921 0927 0932 0945 0978 1005 1032 1035 1043 1048 1051 1055 1065 1067 1069 1088 1090 1102 1111 1113 1118 1120 1137 1149 1154')
# Exact titles reviewed as explicit rental or transfer offers; questions concern that offer.
listing_titles={
'古北 3室 租客已经搬走了 家具🉑配仅15k',
'长宁区转一室一厅2350（可做饭）',
'个人转租，','个人转租 ｜共康路','长宁区｜个人转租 14k｜两房两厅带衣帽间',
'长宁区｜个人转租 14k｜两房两厅带衣帽间',
'上海一室户出租1600带阳台采光好',
'个人转租 永嘉路顶楼带大露台整租 视野好',
'上海闵行｜一楼带私家小院的房子出租',
'普陀区长风二村 朝南次卧 房东直租 限女生',
'谁来租我的家啊啊啊啊啊啊','上海女生之家转租','上海静安区转租！'
}
# Quoted topic spans are copied from own comment unchanged; manually assigned after reading.
topicsets={
'价格预算':ids('0802 0804 0806 0807 0808 0809 0810 0818 0819 0822 0823 0824 0827 0836 0837 0840 0842 0843 0846 0847 0852 0854 0858 0860 0862 0864 0865 0869 0871 0872 0873 0874 0876 0884 0885 0886 0895 0896 0897 0900 0909 0910 0914 0916 0917 0919 0923 0924 0930 0931 0934 0936 0937 0939 0948 0951 0959 0964 0967 0980 0981 0982 0983 0984 0985 0986 0988 0989 0990 0991 0993 0996 0997 0998 0999 1000 1001 1002 1003 1004 1005 1006 1008 1009 1010 1011 1015 1016 1017 1018 1019 1020 1021 1022 1023 1024 1025 1027 1029 1031 1033 1034 1036 1038 1041 1042 1044 1045 1047 1050 1052 1053 1054 1055 1057 1059 1061 1062 1063 1066 1068 1071 1073 1074 1075 1078 1080 1081 1082 1086 1091 1093 1094 1096 1101 1104 1108 1109 1121 1122 1129 1130 1134 1136 1142 1143 1148 1156 1157 1166'),
'位置通勤':ids('0802 0803 0810 0815 0816 0817 0820 0821 0824 0826 0828 0832 0834 0838 0841 0844 0850 0851 0855 0857 0866 0887 0893 0921 0926 0927 0932 0939 0941 0943 0944 0945 0954 0969 0983 0984 0988 0989 0992 0995 0996 1004 1005 1010 1013 1014 1017 1035 1043 1055 1063 1067 1069 1073 1083 1088 1090 1102 1111 1112 1113 1118 1120 1137 1141 1152 1153'),
'户型面积与居住方式':ids('0825 0867 0892 0903 0968 0977 1048 1051 1065 1098 1099 1111 1115'),
'房内设施':ids('1032 1095 1111'),
'宠物':ids('0807 0925 1028 1107'),
'楼层电梯':ids('0905 1026'),
'入住与租期':ids('0831 0833 0848 0860 0888 0948 0949 1105 1135'),
'房源状态':ids('0801 0830 0859 0861 0863 0868 0877 0892 0928 0935 0942 0950 0966 0979 1003 1012 1030 1037 1040 1049 1058 1064 1103 1132 1149 1150 1158 1166'),
'费用合同':ids('0906 1119 1141'),
'看房联系':ids('0835 0894')}
# Purely descriptive comments under personal experience posts: topic is preserved pending purpose.
# 0972 is a paraphrase of the original poster's requirements, not evidence of the commenter's own search.
discussion.add('I0972')
regions={
'0815':[('徐汇滨江附近','desired')], '0828':[('静安','desired')], '0921':[('嘉定新城','desired')],
'0927':[('嘉定江桥','desired')], '0932':[('民雷路地铁站附近','desired')], '0945':[('静安','desired')],
'0969':[('隆德路','desired')], '1005':[('汉中路','desired')], '1035':[('莘庄','desired')],
'1043':[('古美板块','desired')], '1055':[('长江南路','desired')], '1067':[('青浦','desired')],
'1069':[('上海肺科医院周边','desired')], '1088':[('青浦新城','desired')], '1090':[('浦东','desired')],
'1102':[('美兰湖附近','desired')], '1111':[(v,'desired') for v in ['灵岩南路','凌兆新村','杨思','前滩','长清路','世博']],
'1113':[('上海大学宝山校区附近','desired')], '1118':[('七宝','desired')], '1120':[('胜利小区','desired')],
'1137':[('古北路','desired')], '0857':[('古北','unknown')], '0851':[('周浦','unknown')], '1153':[('闵行','unknown')]
}
# Directly identifiable offered area in long supply comments; no IP/title inheritance.
offered={'0811':'上海徐汇','0812':'上海徐汇','0813':'浦东塘桥','0814':'浦东大道','0845':'爱博四村','0849':'高行山姆','0856':'奉贤区','0878':'青浦新城','0879':'青浦新城','0882':'杨思板块','0889':'普陀','0890':'普陀','0891':'普陀','0898':'杨浦凯兴苑','0908':'普陀桃浦','0922':'佘北家园','0929':'松江区','0933':'浦东南路','0938':'东泉苑','0955':'梅园五街坊','0958':'三林路711弄','0963':'嘉定新城','0970':'爱国路','0971':'前滩','0973':'齐河溢翠苑','0975':'互联宝地','0987':'嘉定','1060':'嘉定白银路','1087':'静安区','1089':'龙湖新壹城','1106':'杨浦区江浦公园地铁站附近','1128':'场中路','1140':'淞虹路北平家园','1147':'静安区','1155':'宁国路','1160':'虹口区广灵二村','1161':'淞发路'}
for k,v in offered.items(): regions.setdefault(k,[]).append((v,'offered'))
# Questions about a named listing locality are not automatically a desired location.
for k in ('0857','0851','1153'): regions.pop(k,None)
# Per-record overrides for interpretive edge cases.
manual={
'0901':('unknown','unknown','uncertain','未采到上下文，询问房子视频的对象及用途不明。',['缺少上下文，不能确认是否求租。']),
'0915':('unknown','unknown','uncertain','仅有线路和视频标记，无法判断供需。',['视频内容未采集，不能判断房源或求租。']),
'0918':('unknown','unknown','uncertain','询问对方是否仍在找房，未明确本人提供房源。',['缺少后续内容，供需身份不明。']),
'0953':('supply','unknown','uncertain','询问对方位置要求，疑似提供房源但没有明确房源。',['未明确具体房源或身份。']),
'0955':('supply','unknown','uncertain','在求租帖下描述小区位置，疑似推荐房源。',['未明确出租关系，需核实。']),
'0970':('supply','unknown','uncertain','在求租帖下描述一套房屋，疑似推荐房源。',['未明确出租关系，需核实。']),
'0972':('discussion','unknown','uncertain','在求租帖下复述一组条件，指代可能是原帖主。',['缺少上下文，无法确认这些条件是否属于评论者。']),
'0974':('supply','unknown','uncertain','在求租帖下描述房屋设施，疑似推荐房源。',['未明确房源与出租关系。']),
'0978':('demand','active_at_comment','medium','询问是否有类似房源，表达找类似房的意向。',['标题未明确该房是否可租，具体所指待核。']),
'1007':('discussion','unknown','uncertain','询问房屋夏季虫情，但未明确是否求租。',['仅凭虫情问题不足以确定求租意向。']),
'1044':('discussion','unknown','uncertain','质疑图片与价格真实性，未明确本人需求。',['标题未明确出租，评论可能只是质疑。']),
'1051':('demand','active_at_comment','medium','询问如何找到阁楼，说明正在找相关房型。',['地区与预算未说明。']),
'1067':('demand','active_at_comment','medium','询问是否有类似房子，表现找房意向。',['参考房源与具体需求待核。']),
'1072':('demand','active_at_comment','high','在直租房源下请求看看，表现对房源的兴趣。',['未明确是否约定线下看房。']),
'1114':('unknown','unknown','uncertain','只提出联系，标题未明确房源是否出租。',['联系目的待核。']),
'1124':('unknown','unknown','uncertain','询问求租者预算，尚未表明是否有房。',['无法确认供给身份。']),
'1127':('unknown','unknown','uncertain','只写地点，未明确供需及与地点关系。',['缺少上下文。']),
'1131':('demand','active_at_comment','high','在直租房源下询问详情。',['具体想了解的内容未说明。']),
'1135':('demand','active_at_comment','high','在转租房源下询问十一月、十二月是否可行。',['未明确具体日期和用途，不能锚定年份。']),
'1144':('unknown','unknown','uncertain','在经历帖询问位置，未明确求租。',['仅凭位置询问不足以确认找房。']),
'1148':('discussion','unknown','uncertain','经历帖下询问价格，可能仅是了解。',['标题为居住经历，无法确认本人求租。']),
'1154':('demand','active_at_comment','medium','希望房东介绍类似房间，表达找房意向。',['地区、预算和时间未说明。']),
'1159':('supply','unknown','uncertain','询问是否考虑并附价格及视频，疑似推荐房源。',['缺少上下文与视频内容，供给关系待核。'])}
manual={"I"+k:v for k,v in manual.items()}
# No fields inferred from supplied room's characteristics.
outputs=[]
for x in rows:
 k=x['review_key']; n=k[1:]; own=x['comment_text']; title=x.get('post_title','')
 review=[]
 if k in manual: role,state,interest,reason,review=manual[k]
 elif k in supply: role,state,interest,reason='supply','unknown','unrelated','评论提供、转租或向求租者推荐房源，并非本人明确求租。'
 elif k in discussion: role,state,interest,reason='discussion','unknown','unrelated','评论讨论、评价或分享信息，未表达当前找房需求。'
 elif k in unknown: role,state,interest,reason='unknown','unknown','uncertain','评论不足以确定供需身份或具体意向。'; review=['缺少有效内容或上下文，无法确认供需对象。']
 elif k in active: role,state,interest,reason='demand','active_at_comment','high','本人询问房源或明确表达找房需求，记录为评论时意向。'
 elif title in listing_titles: role,state,interest,reason='demand','active_at_comment','high','在明确出租或转租房源下询问房源条件，记录为评论时兴趣。'
 else: role,state,interest,reason='unknown','unknown','uncertain','评论询问房屋信息，但现有标题不足以确定本人正在求租。'; review=['标题未明确该房源正在出租，需结合正文或上下文核实。']
 if k in {'I0835','I0894'}: interest='high'; review.append('仅询问能否看房，尚未明确预约时间。')
 if k=='I0815': review.append('“这种”所指的房型条件需结合原帖核实。')
 if k=='I1111': review.append('其他地方也可，列出的地点为优先区域。')
 if k=='I1048': review.append('租期、预算及地区未在评论中说明。')
 if k=='I0904': review=['原评论已删除，无法判读本人原文。']
 topics=[]
 if role not in ('supply','discussion'):
  for pool, ks in topicsets.items():
   if k in ks: topics.append({'pool':pool,'quote':own,'polarity':'require' if k in {'I0848','I0888','I0903','I1111'} else 'ask'})
 # active explicit demand involving price doesn't necessarily assert a price limit; asking is preserved.
 target=[]
 for frag,relation in regions.get(n,[]):
  if frag in own: target.append({'text':frag,'quote':frag,'relation':relation})
 context=['own'] + (['title'] if title and (role in ('demand','supply','unknown') or k in {'I0972','I1007','I1044','I1148'}) else [])
 outputs.append({'review_key':k,'comment_id':x['comment_id'],'customer_uid':x['customer_uid'],'role':role,'demand_state':state,'interest':interest,'topics':topics,'target_regions':target,'evidence':[own] if own else [],'reason':reason,'context_used':context,'needs_review':review,'human_confirmed':False,'send_authorized':False,'store_assignment':None})
# Second semantic review: keep ambiguous quantities and reference targets explicit.
bykey={y['review_key']:y for y in outputs}
for key in ('I0993','I1033'):
 y=bykey[key]; q=y['evidence'][0]
 y['topics']=[{'pool':'价格预算','quote':q,'polarity':'ask'},{'pool':'户型面积与居住方式','quote':q,'polarity':'ask'}]
 y['needs_review'].append('“多少米”可能询问租金或面积，两个主题均为待核候选。')
for key in ('I0964','I0967','I1023','I1054','I1130','I1156'):
 y=bykey[key]; y['topics']=[t for t in y['topics'] if t['pool']!='价格预算']
 y['needs_review'].append('数量所指未说明，可能是价格、面积或其他信息，主题待核。')
y=bykey['I0807']; y['topics']=[t for t in y['topics'] if t['pool']!='价格预算']; y['needs_review'].append('“多少”可能指租金或宠物数量，具体所问待核。')
y=bykey['I0948']; y['needs_review'].append('“短租多少”可能询问价格或时长，两个主题均需核实。')
y=bykey['I0972']; y['role']='unknown'; y['reason']='这组条件的所属对象不明，可能是复述发帖者要求。'
y=bykey['I0978']; y['topics'].append({'pool':'房源状态','quote':y['evidence'][0],'polarity':'ask'}); y['needs_review'].append('“类似”具体指哪套房及哪些特征待核，房源状态主题为候选。')
y=bykey['I1067']; y.update(role='unknown',demand_state='unknown',interest='uncertain',reason='询问青浦位置及是否有类似房子，参考对象和本人租房目的未明。'); y['topics'].append({'pool':'房源状态','quote':y['evidence'][0],'polarity':'ask'}); y['target_regions']=[]; y['needs_review']=['“类似的房子”所指及询问目的不明，不能确认是本人需求；青浦仅为询问位置。']
y=bykey['I1120']; y.update(role='unknown',demand_state='unknown',interest='uncertain',reason='询问胜利小区是否有类似对象，指代及本人租房目的未明。'); y['topics'].append({'pool':'房源状态','quote':y['evidence'][0],'polarity':'ask'}); y['target_regions']=[]; y['needs_review']=['“类似于这样”的对象和用途待核，地点不能直接认定为本人求租目标地区。']
bykey['I1083']['needs_review'].append('“这种”所指房屋特征需结合正文确认。')
# Validate evidence and exact identity, including multi-topic quotes.
errors=[]
for x,y in zip(rows,outputs):
 for q in y['evidence']+[t['quote'] for t in y['topics']]+[t['quote'] for t in y['target_regions']]:
  if not q or q not in x['comment_text']: errors.append(y['review_key'])
keys=lambda a:[(z['review_key'],z['comment_id']) for z in a]
assert len(rows)==len(outputs) and len(set(keys(rows)))==len(rows) and set(keys(rows))==set(keys(outputs)) and not errors
(p/'reviewed-c.jsonl').write_text(''.join(json.dumps(y,ensure_ascii=False)+'\n' for y in outputs),encoding='utf-8')
from collections import Counter
report={'input_count':len(rows),'output_count':len(outputs),'id_pair_set_equal':set(keys(rows))==set(keys(outputs)),'unique_id_pairs':len(set(keys(outputs))),'evidence_verbatim_errors':errors,'role_counts':dict(Counter(y['role'] for y in outputs)),'interest_counts':dict(Counter(y['interest'] for y in outputs)),'needs_review_count':sum(bool(y['needs_review']) for y in outputs),'human_confirmed':False,'send_authorized':False,'scope':'shard-08 to shard-11'}
(p/'c-validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(report,ensure_ascii=False,indent=2))
