import json,pathlib,hashlib,sys,copy,collections,importlib.util
worker=pathlib.Path(__file__).resolve().parent
base=worker.parent
part=base/'recall-audit'/'part-1'
root=base.parents[2]
task=json.loads((part/'task.json').read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
primary_before={x['path']:sha(base/x['path']) for x in task['primary_sources']}
assert all(primary_before[x['path']]==x['sha256'] for x in task['primary_sources'])
primary={}
for x in task['primary_sources']:
    for line in (base/x['path']).read_text(encoding='utf-8').splitlines():
        r=json.loads(line);assert r['review_key'] not in primary;primary[r['review_key']]=r
allowed=set('role demand_state interest topics target_regions time_mentions other_constraints possible_topics evidence reason context_used needs_review contact_boundaries context_flags reply_plan'.split())
all_keys=[];rows=[];audit_shas={};pagechecks=[];quote_checks=0;errors=[]
approved={x['slot'] for x in json.loads((root/'approved-mothers-model-view.json').read_text(encoding='utf-8-sig')) if x['approved']}
for p in sorted(part.glob('page-??.json')):
    groups=json.loads(p.read_text(encoding='utf-8-sig'))['post_groups']
    comments=[c for g in groups for c in g['comments']]
    a=part/(p.stem+'.audit.jsonl')
    audit_shas[a.name]=sha(a)
    audits=[json.loads(l) for l in a.read_text(encoding='utf-8').splitlines() if l.strip()]
    keys=[c['key'] for c in comments];outs=[r['review_key'] for r in audits]
    assert keys==outs,(p.name,'page ids differ')
    pagechecks.append({'page':p.name,'input':len(keys),'output':len(outs),'id_order_and_set_equal':True,'input_sha256':sha(p),'audit_sha256':sha(a)})
    for c,audit in zip(comments,audits):
        k=c['key'];all_keys.append(k)
        assert audit['decision'] in ('keep','change') and isinstance(audit['reason'],str) and audit['reason'].strip()
        assert isinstance(audit['patch'],dict) and set(audit['patch'])<=allowed
        assert (audit['patch']=={}) if audit['decision']=='keep' else bool(audit['patch'])
        orig=primary[k]
        assert all(orig[f]==v for f,v in c['first_semantic_judgment'].items()),(k,'first judgment changed')
        row=copy.deepcopy(orig);row.update(copy.deepcopy(audit['patch']))
        assert row['human_confirmed'] is False and row['send_authorized'] is False and row['store_assignment'] is None
        assert row['reply_plan']['preferred_mother_slot'] is None or row['reply_plan']['preferred_mother_slot'] in approved
        # All quoted evidence must be in this exact comment. No other author's conditions allowed.
        quotes=list(row['evidence'])
        for field in ['topics','target_regions','time_mentions','other_constraints','possible_topics','contact_boundaries']:
            quotes.extend(x['quote'] for x in row[field] if isinstance(x,dict) and 'quote' in x)
        for q in quotes:
            quote_checks+=1
            if not isinstance(q,str) or not q or q not in c['text']:errors.append({'key':k,'quote':q,'error':'not exact substring of own comment'})
        row['classification_method']='ai_independent_semantic_fine_review'
        row['classification_stages_completed']=['initial_semantic','detailed_semantic','independent_semantic']
        row.pop('classification_review_source',None)
        rows.append(row)
assert len(all_keys)==788 and len(set(all_keys))==788
assert set(all_keys)==set(task['expected_review_keys'])
assert not errors,errors
raw=worker/'isolated-original-plus-patch.jsonl'
raw.write_text(''.join(json.dumps(r,ensure_ascii=False,separators=(',',':'))+'\n' for r in rows),encoding='utf-8')
digest=sha(raw)
bound=[]
for row in rows:
    r=copy.deepcopy(row);r['classification_review_source']={'path':raw.relative_to(base).as_posix(),'sha256':digest};bound.append(r)
boundfile=worker/'isolated-sha-bound-precheck.jsonl'
boundfile.write_text(''.join(json.dumps(r,ensure_ascii=False,separators=(',',':'))+'\n' for r in bound),encoding='utf-8')
adapter=root/'mother_adapter.py';adapter_before=sha(adapter)
spec=importlib.util.spec_from_file_location('mother_adapter_existing_unchanged',adapter)
mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
cache={}
for row in bound:mod.validate_new_review(row,base,cache)
primary_after={x['path']:sha(base/x['path']) for x in task['primary_sources']}
assert primary_before==primary_after and sha(adapter)==adapter_before
decision_counts=collections.Counter()
field_changes=collections.Counter()
for p in sorted(part.glob('page-??.audit.jsonl')):
    for line in p.read_text(encoding='utf-8').splitlines():
        a=json.loads(line);decision_counts[a['decision']]+=1
        field_changes.update(a['patch'].keys())
report={'batch':base.name,'part':1,'records':len(rows),'pages':pagechecks,'ids_unique':True,'expected_ids_equal':True,'own_quote_checks':quote_checks,'own_quote_errors':errors,'first_judgments_equal_primary':True,'primary_sources':primary_before,'primary_after_unchanged':True,'audit_sha256':audit_shas,'isolated_semantic_jsonl':{'path':str(raw),'sha256':digest,'records':len(rows)},'isolated_bound_jsonl':{'path':str(boundfile),'sha256':sha(boundfile),'records':len(bound)},'formal_precheck':{'call':'unchanged mother_adapter.validate_new_review','validated':len(bound),'errors':0,'adapter_sha256':adapter_before,'adapter_after_unchanged':True},'decisions':dict(decision_counts),'patched_fields':dict(field_changes),'credits':'existing_authorized','actual_usage':'unknown','platform_or_source_db_access':False,'sent':False,'published':False,'human_confirmed':False}
(worker/'validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(report,ensure_ascii=False,indent=2))
