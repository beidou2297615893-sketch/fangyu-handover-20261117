import json,pathlib,hashlib,os,datetime,collections
p=pathlib.Path('work/fangyu-text-business-20261029/douyin-semantic-repair-v5'); a=json.loads((p/'remaining-review-frozen-20261103.json').read_text(encoding='utf-8'))
# Explicit per-comment semantic assessments, not keyword inference.
d={}
def put(i,k,pools,reason): d[i]=(k,pools.split(',') if pools else [],reason)
notes={0:'劝女生不要异性合租，未表达本人找房',1:'附和称呼无租住需求',2:'计算服务费制度，不是本人预算',4:'纯表情',5:'比较中介费与服务费制度',6:'邀请到双桥找自己，供给招揽',7:'纯表情',11:'呼叫豆包整理视频，不是求租',13:'明确已经租了西红门房子，询问开销合理性',16:'中介选择建议，没有求租表达',17:'分享已租南法信村房经验',19:'询问诈骗方式，不是房源需求',21:'转发让第三人租房，无本人或代求租条件',22:'找人住自己的次卧，室友供给招募',23:'夸赞中介',24:'对服务费反应',28:'询问电马桶概念',29:'分享本人已有郊区房租',30:'评论衣服官周',32:'分享已有租住价格',39:'问薪资福利非租房',40:'评价展示公寓价格面积',41:'评价低价房环境，不是本人预算',42:'明确打算回家并提醒来沪成本，未求房',43:'提供选址通勤建议',44:'分享包住工作经验',45:'描述市场价格并向别人建议区域',48:'转发喜欢房子，未表达实际找房',55:'讨论房东收租动机',56:'解释房东成本和短租顾虑',57:'分享成都付款方式见闻',58:'房东讲欠租经历',60:'收藏内容，未表达本人申请或租房',61:'要求继续更新',62:'明确不愿去成都，比较绵阳已有住房',64:'讨论房东收租与租客风险',65:'评论账号转型',69:'调侃熟人',70:'赞设计，没有本人求租',71:'解释房东不接受月付',72:'解释房东换租成本',73:'讨论重庆付款惯例',77:'推广租房群',78:'明确房东身份解释收租',79:'讲述已谈妥月付经历，没有新增房源请求',80:'评论租客稳定性',81:'明确找工作不是找住房',82:'房东要稳定租客的说明',83:'仅提及账号，昵称狗狗不是宠物需求',91:'向朋友介绍人才公寓',94:'仅提及账号',95:'分享自己现有租金费用',96:'推测视频房价，没有求租',100:'夸张反驳宣传价格，无求租表达',101:'反驳价格真实性，无求租表达',107:'建议不要合租，无本人求租',109:'仅提及账号',110:'纯表情'}
for i,r in notes.items(): put(i,'unrelated','',r)
for i,ps,r in [
(3,'户型面积与居住方式','泛问公寓与合租选择，未明确本人是否正在找房'),(8,'位置通勤','仅报地铁地点，供需方向不足'),(33,'价格预算','说明收入与两千以上负担，未明确当前找房'),(35,'价格预算,位置通勤,户型面积与居住方式','报价和地点可能为现住分享或供给，主体不明'),(46,'位置通勤','仅地名，不能确定求租或景点讨论'),(50,'价格预算','无问号短语可为确认事实或问价，需保留歧义'),(59,'费用合同','对自己的中介费提出疑问，尚不明确是否仍找房'),(66,'费用合同','仅季付加哭表情，未明确自身需求'),(75,'费用合同','担忧预付风险，但未明确个人当前求租'),(86,'','表示后悔消息迟，需求现状未知'),(93,'','泛问真假，正文不足定位本人租房需求')]: put(i,'uncertain',ps,r)
for i,ps,r in [
(9,'位置通勤,房源状态','明确求13号线房源推荐'),(10,'价格预算,位置通勤,户型面积与居住方式','询问杨庄小一居价格'),(12,'位置通勤,户型面积与居住方式,楼层电梯,看房联系','明确整租三居与多个可选地点，高楼层需电梯并求私信；偏好房东直租'),(14,'价格预算,位置通勤,户型面积与居住方式','明确预算5000至5500套二近地铁，排除班车；公寓民房为可选项'),(15,'价格预算,位置通勤','和平门上班求推荐，预算2000至2500通勤一小时内'),(18,'位置通勤','回龙观东大街上班求房推荐'),(20,'价格预算,位置通勤','西铁营上班预算2000以内求推荐'),(25,'位置通勤,房源状态','询问天通苑长庚医院附近房源'),(26,'位置通勤,户型面积与居住方式','两人异地上班寻合适居住地'),(27,'价格预算,位置通勤,户型面积与居住方式','新宫往北3000以内公寓或整租需求'),(31,'价格预算,位置通勤,户型面积与居住方式,房内设施','明确望京上班单人不合租明窗及预算通勤限制'),(36,'看房联系','要求评论当天看房，须重核历史时间'),(37,'位置通勤,入住与租期','浦东求短租一个月，3.6k是民宿报价非明确预算；就业不确定'),(47,'价格预算,看房联系','租赁房源下询价并要求回复'),(49,'价格预算','明确询问该房租金'),(51,'看房联系','租赁房源下私字请求私聊'),(52,'位置通勤,价格预算','吴中路一千多月租房源需求，月租金额不是只租一月'),(53,'入住与租期','询问能否只租一个月'),(54,'价格预算','房源评论单字价为询租金'),(67,'位置通勤','替对象说明要在郫都公司附近另找房，旧房费用不可作为新预算'),(74,'位置通勤,价格预算','明确咨询北京交大附近租金，地点仍须区分具体校区'),(76,'看房联系','要求评论次日看房，须重核历史时间'),(84,'房源状态','明说这几天在找房，前面的还有吗为转述但找房需求真实'),(87,'位置通勤,价格预算,户型面积与居住方式','询问这片区域4200以内两室一厅，具体区域指代待核'),(88,'位置通勤,房源状态','询问杭州东站附近房源'),(90,'房源状态','明确询问有无出租住房'),(98,'价格预算','房源下多钱为询价'),(99,'位置通勤,房源状态','明确找闵行颛桥万达附近房源'),(102,'位置通勤,房源状态','问上海闵行中庚漫游城或顾戴路房源，两处是可选'),(105,'位置通勤,房源状态','租赁房源下询问唐镇有没有'),(106,'房源状态','询问该类型住房是否还有出租'),(108,'位置通勤,房源状态','询问浦东新区有没有房源')]: put(i,'high',ps,r)
for i,ps,r in [(34,'价格预算','向实际租赁帖核问500价格真实性，保留潜在咨询'),(38,'价格预算','向实际租赁帖核问500价格真实性'),(63,'入住与租期','在校生咨询免费住宿申请资格，不能推定接受商业租房'),(68,'价格预算,费用合同,户型面积与居住方式','与朋友看房满意但首期季付负担不起，保留需求；2300和90平是看过房源'),(85,'价格预算','向租赁帖确认500价格真实性'),(89,'户型面积与居住方式','咨询免费住宿能否带父母一方，非商业公寓已适配'),(92,'入住与租期','研二赴上海实习询问免费住宿资格'),(97,'价格预算','请求真实价格，保留房源价格咨询'),(103,'入住与租期','上海岗位求职者询免费住宿申请材料条件'),(104,'价格预算,位置通勤,房内设施','评估1900近地铁燃气独卫房源价值，未明确已经入住')]: put(i,'medium',ps,r)
assert set(d)==set(range(len(a))),set(range(len(a)))-set(d)
rows=[]
for i,s in enumerate(a):
 k,ps,r=d[i]; t=s['comment_text']; role='demand' if k in ('high','medium') else ('unknown' if k=='uncertain' else 'discussion')
 if i in [6,22,58,77,78,82]: role='supply'
 row=dict(comment_id=s['comment_id'],comment_text_sha256=hashlib.sha256(t.encode()).hexdigest(),interest_at_comment=k,role=role,pools=ps,demand_state='active_at_comment' if k=='high' else ('inquiry_at_comment' if k=='medium' else ('unknown' if k=='uncertain' else 'discussion_only')),reason=r,evidence=[t],context_used=['own_comment','existing_post_body'],review_stage='bounded_AI_semantic_review',review_version='douyin-v5-review111-20261103',actual_usage='unknown',API_request_count='unknown',reply_generated=False,current_need_verified=False,current_need_review_required=k in ('high','medium','uncertain'))
 if role=='supply': row['demand_state']='supply'
 if i in [13,17,29,32,79,95]: row['demand_state']='already_housed'
 if k in ('uncertain','unrelated') or i in [36,63,76,89,92,103]: row.update(contact_hold=True,brand_recommendation_allowed=False)
 if i in [63,89,92,103]: row['program_scope']='免费人才/实习住宿资格，未证明商业租房意愿'
 if s.get('source_comment_sha256'): assert row['comment_text_sha256']==s['source_comment_sha256']
 rows.append(row)
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
progress={'phase':'remaining_semantic_review_111','frozen_total':111,'already_reviewed_uncertain_not_repeated':52,'completed':0,'pending':111,'status':'running','model_usage':'unknown','updated_at':now()}
def atomic(path,text):
 tmp=path.with_suffix(path.suffix+'.remaining-review.tmp');tmp.write_text(text,encoding='utf-8');os.replace(tmp,path)
oldlines=(p/'semantic-reviewed.jsonl').read_text(encoding='utf-8').splitlines(); original={json.loads(x)['comment_id']:json.loads(x) for x in oldlines}
atomic(p/'review-progress.json',json.dumps(progress,ensure_ascii=False,indent=2))
for start in range(0,111,50):
 path=p/'semantic-reviewed.jsonl'; lines=path.read_text(encoding='utf-8').splitlines(); existing={json.loads(x)['comment_id'] for x in lines}
 add=[r for r in rows[start:start+50] if r['comment_id'] not in existing]
 atomic(path,'\n'.join(lines+[json.dumps(r,ensure_ascii=False) for r in add])+'\n')
 progress.update(completed=min(start+50,111),pending=max(111-start-50,0),updated_at=now());atomic(p/'review-progress.json',json.dumps(progress,ensure_ascii=False,indent=2))
final=[json.loads(x) for x in (p/'semantic-reviewed.jsonl').read_text(encoding='utf-8').splitlines()]; fm={x['comment_id']:x for x in final}
assert len(final)==len(fm)
assert all(fm[c]==r for c,r in original.items())
assert all(fm[r['comment_id']]==r for r in rows)
progress.update(status='complete',total_semantic_reviewed=len(final),result_counts=dict(collections.Counter(r['interest_at_comment'] for r in rows)),original_reviewed_preserved=len(original),road_word_cases=[{'comment_id':s['comment_id'],'text':s['comment_text']} for s in a if any(w in s['comment_text'] for w in ['马路','路人','上班路上'])],updated_at=now())
atomic(p/'review-progress.json',json.dumps(progress,ensure_ascii=False,indent=2));print(json.dumps(progress,ensure_ascii=False))
