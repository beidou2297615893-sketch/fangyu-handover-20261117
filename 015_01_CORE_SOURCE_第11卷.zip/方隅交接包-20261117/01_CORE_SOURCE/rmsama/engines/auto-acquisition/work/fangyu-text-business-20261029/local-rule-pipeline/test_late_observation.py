"""Old parsed requests can acquire new observations without a new attempt row."""
import json,sqlite3,unittest
import run_local_pipeline as pipeline

class LateObservationTest(unittest.TestCase):
 def test_backfill_old_attempt_is_ingested_and_repeat_is_idempotent(self):
  source=sqlite3.connect(':memory:');state=sqlite3.connect(':memory:')
  source.executescript('CREATE TABLE attempts(request_id,state,spec); CREATE TABLE entities(source_id,data,kind); CREATE TABLE observations(request_id,stable_key,account_uid,store_id,keyword,target,collected_at,data,kind);')
  state.executescript('CREATE TABLE meta(key PRIMARY KEY,value); CREATE TABLE observations(platform,source_rowid,request_id,stable_key,account_uid,store_id,keyword,target,collected_at,identity_digest,malformed,PRIMARY KEY(platform,source_rowid)); CREATE TABLE qualified(platform,request_id,target,account_uid,qualification); CREATE TABLE videos(platform,video_id,body,author_uid,context_digest);')
  spec={'kind':'comments','account_uid':'account','target':'video','eligibility':{'state':'eligible'}}
  source.execute('INSERT INTO attempts VALUES(?,?,?)',('old-request','parsed',json.dumps(spec)))
  def append(cid):
   item={'cid':cid,'text':'求租','aweme_id':'video','user':{'uid':'customer-'+cid}}
   source.execute('INSERT INTO observations VALUES(?,?,?,?,?,?,?,?,?)',('old-request','comment:'+cid,'account','store','word','video','2026-11-05',json.dumps(item),'comments'))
  append('one');self.assertEqual(pipeline.refresh_metadata(source,state,'douyin',{}),1)
  attempt_rowid=source.execute('SELECT max(rowid) FROM attempts').fetchone()[0]
  append('two');self.assertEqual(pipeline.refresh_metadata(source,state,'douyin',{}),1)
  self.assertEqual(source.execute('SELECT max(rowid) FROM attempts').fetchone()[0],attempt_rowid)
  keys={r[0] for r in state.execute(f'SELECT DISTINCT o.stable_key FROM observations o JOIN qualified q ON {pipeline.QUALIFIED_JOIN}')}
  self.assertEqual(keys,{'comment:one','comment:two'})
  self.assertEqual(pipeline.refresh_metadata(source,state,'douyin',{}),0)
  self.assertEqual(state.execute('SELECT count(*) FROM observations').fetchone()[0],2)
  source.close();state.close()

if __name__=='__main__':unittest.main()
