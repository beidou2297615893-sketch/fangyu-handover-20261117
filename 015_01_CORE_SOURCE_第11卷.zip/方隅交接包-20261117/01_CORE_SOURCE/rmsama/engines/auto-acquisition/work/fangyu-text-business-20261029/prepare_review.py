"""Offline text-review staging only; never opens a platform or mutates source data."""
import json, hashlib, re
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
SRC=ROOT/'work/reply-classification-20261029'
def loadlines(p):
    return [json.loads(x) for x in p.read_text(encoding='utf-8-sig').splitlines() if x.strip()]
def sha(s): return hashlib.sha256(s.encode()).hexdigest()
rows={}
old=loadlines(SRC/'old-snapshot.jsonl')
for customer in old:
    for c in customer['comments']:
        f=c['original_fields']; cid=f['comment_id']
        rows[cid]={'comment_id':cid,'customer_uid':customer['platform_uid'],'text':f.get('text',''),
        'parent_text':f.get('parent_text',''),'post_title':f.get('content_title',''),'post_text':'',
        'published_at':f.get('published_at',''),'source_group':'旧备份','source_high':customer['observed_high_interest'],
        'source_topics':c['topic_candidate'].get('topics',[]),'source_assessment':customer['projection_original']['customer']}
for name in ['new-snapshot.jsonl','ledger-remainder.jsonl']:
    for c in loadlines(SRC/name):
        cid=c.get('comment_id'); observations=c.get('input_observations',[])
        if not observations: continue
        fs=[x.get('data',x) for x in observations]
        f=max(fs,key=lambda v:len(v.get('parent_text',''))+len(v.get('post_text',''))+len(v.get('post_title','')))
        if cid in rows:
            for key in ['parent_text','post_title','post_text']:
                if not rows[cid].get(key) and f.get(key):rows[cid][key]=f[key]
            continue
        topics=list(dict.fromkeys(t for z in c.get('topic_candidates_by_text',[]) for t in z.get('topics',[])))
        rows[cid]={'comment_id':cid,'customer_uid':(c.get('customer_uids') or [f.get('customer_uid','')])[0],
            'text':f.get('comment_text',''),'parent_text':f.get('parent_text',''),'post_title':f.get('post_title',''),
            'post_text':f.get('post_text',''),'published_at':f.get('published_at',''),'source_group':'新快照' if name.startswith('new') else '账本补充',
            'source_high':c.get('snapshot_high_or_super_high',c.get('high_or_super_high',False)),
            'source_topics':topics,'source_assessment':[a.get('analysis',a).get('result',{}) for a in c.get('analysis_versions',[])]}
benchmark=json.loads((ROOT/'work/xhs-topic-pool-evaluation/sample-comparison.json').read_text(encoding='utf8'))
excluded={x.get('source_text_sha256') for x in benchmark['samples']}
excluded.update(sha(x.get('anonymous_original_comment','')) for x in benchmark['samples'])
# Exclude the prior targeted audit as a whole customer, including all their comments.
for n in [124,142,264,511,671,1094,976,894,1043]:
    for c in old[n-1]['comments']:excluded.add(sha(c['original_fields'].get('text','')))
new=loadlines(SRC/'new-snapshot.jsonl')
for n in [91,128,161,214,653,681,1010,175,69,13,19]:
    excluded.update(sha(t) for t in new[n-1].get('comment_text_variants',[]))
eligible=[r for r in rows.values() if r['text'].strip() and sha(r['text']) not in excluded]
eligible.sort(key=lambda r:sha('holdout-v1|'+r['comment_id']))
selected=[];seen=set();seen_text=set()
def add(r,stratum):
    uid=r['customer_uid'] or r['comment_id']
    if uid in seen or sha(r['text']) in seen_text:return False
    seen.add(uid);seen_text.add(sha(r['text']));selected.append({**r,'stratum':stratum});return True
for r in eligible:
    if add(r,'按身份去重的常规留出') and len(selected)>=100:break
edge=re.compile(r'不|没|无|拒|已|明年|去年|个月|哪里|什么|多少|预算|养|宠|看房|联系|转租|招租|合租|一楼|地铁')
for r in eligible:
    if edge.search(r['text']) and add(r,'定向难例留出') and len(selected)>=200:break
assert len(selected)==200
for i,r in enumerate(selected):r['review_key']=f'R{i+1:03d}'
HERE.mkdir(parents=True,exist_ok=True)
(HERE/'holdout-200.jsonl').write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in selected),encoding='utf8')
(HERE/'holdout-manifest.json').write_text(json.dumps({'count':200,'ordinary':100,'directed':100,
    'excluded_previous_benchmark':True,'sampling':'按comment_id固定散列排序，UID与原文去重，前100常规，后100难例',
    'rule_tuning_allowed':False,'source_comments':len(rows),'source_file_hashes':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in [SRC/'old-snapshot.jsonl',SRC/'new-snapshot.jsonl',SRC/'ledger-remainder.jsonl']},
    'reference_state':'待当前模型语义复核，非用户金标准'},ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps({'count':200,'source_unique_comments':len(rows),'output':'holdout-200.jsonl'}))
