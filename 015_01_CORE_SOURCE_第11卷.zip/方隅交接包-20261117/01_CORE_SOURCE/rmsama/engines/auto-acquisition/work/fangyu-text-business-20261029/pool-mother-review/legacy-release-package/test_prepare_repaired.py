import unittest,copy,hashlib,json
import prepare_repaired as p
class OverlayGuards(unittest.TestCase):
 def setUp(self):
  self.base={'platform':'douyin','cid':'c','uid':'u','sourceSHA':'sha','source_file_sha256':'file','original_classification_sha256':'class','selection':'selected','family':'area','fill':{'place':'昌平'},'contact_policy_original':None,'hold_reasons':[],'send_authorized':False,'can_send_now':False}
  self.patch={'platform':'douyin','cid':'c','uid':'u','sourceSHA':'sha','source_file_sha256':'file','original_classification_sha256':'class','base_merged_plan_sha256':p.objsha(self.base),'base_family':'area','base_fill':{'place':'昌平'},'original_source_contact_policy':None,'replacement_plan':{'family':'area','fill':{'place':'昌平附近'},'evidence':[{'field':'place','quote':'昌平附近'}],'clarification_only':False,'hold_reasons':[],'status':'local_plan_proposed'},'repair_reasons':[],'repair_evidence':[],'source_contact_boundary_preserved':[],'classification_changed':False,'send_authorized':False,'can_send_now':False,'applied':False,'newly_bound_small_short_lease_addition':False}
 def test_valid_overlay_and_base_preserved(self):
  out=p.apply_patch(self.base,self.patch);self.assertEqual(out['fill']['place'],'昌平附近');self.assertEqual(self.base['fill']['place'],'昌平')
 def test_reject_mismatched_identity_source_and_policy(self):
  for k,v in [('uid','bad'),('sourceSHA','bad'),('source_file_sha256','bad'),('original_classification_sha256','bad'),('base_merged_plan_sha256','bad'),('original_source_contact_policy','allow'),('send_authorized',True),('classification_changed',True)]:
   z=copy.deepcopy(self.patch);z[k]=v
   with self.assertRaises(ValueError,msg=k):p.apply_patch(self.base,z)
 def test_contract_structure_rejects_missing_or_extra_slots(self):
  with self.assertRaises(ValueError):p.contract_matrix({'families':{'bad':{'template':'{x}','required_fill':[]}}},[])
 def test_contract_structure_lists_unused(self):
  matrix=p.contract_matrix({'families':{'a':{'template':'{x}','required_fill':['x']},'b':{'template':'ok','required_fill':[]}}},[self.base|{'family':'a','fill':{'x':'value'}}]);self.assertEqual(matrix['b']['use_count'],0)
if __name__=='__main__':unittest.main()
