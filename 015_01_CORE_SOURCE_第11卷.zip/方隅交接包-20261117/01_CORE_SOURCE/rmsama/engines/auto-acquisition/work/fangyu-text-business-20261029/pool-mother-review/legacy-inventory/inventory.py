import json, hashlib, pathlib, collections, re
W=pathlib.Path('work/fangyu-text-business-20261029'); O=W/'pool-mother-review/legacy-inventory'; B=W/'douyin-registered-v2/increments/f98cc21138910fb9'
def load(p): return json.loads(pathlib.Path(p).read_text(encoding='utf-8'))
def sha(p):
 h=hashlib.sha256()
 with open(p,'rb') as f:
  for b in iter(lambda:f.read(1<<20),b''): h.update(b)
 return h.hexdigest()
def jl(p):
 with open(p,encoding='utf-8') as f:
  for s in f:
   if s.strip(): yield json.loads(s)
def put(p,o): pathlib.Path(p).write_text(json.dumps(o,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
c=load(W/'region-brand-routing/current.json'); man=load(c['manifest']); new=list(jl(B/'input.jsonl')); newids={r['comment_id'] for r in new}; assert len(new)==len(newids)==807
checks={}
def check(name,p,expect=None):
 p=pathlib.Path(p); h=sha(p); checks[name]={'path':str(p.resolve()),'sha256':h,'expected':expect,'match':None if not expect else h==expect}
check('current',W/'region-brand-routing/current.json');check('manifest',c['manifest'],c['manifest_sha256']);check('policy',W/'rules/按池选母句与微调执行方式.json');check('new_input',B/'input.jsonl',c['pool_short_mothers']['input_sha256']);check('contract',B/'local-mother-contract.json',c['pool_short_mothers']['contract_sha256']);check('renderer',B/'batch_short_mothers.py',c['pool_short_mothers']['renderer_sha256']);check('pipeline',B/'short_reply_pipeline.py');check('fifty_short',W/'pool-mother-review/fifty-review-v3-short.jsonl');check('summary',c['summary'],c['result_sha256']['summary.json'])
for p,path in c['results'].items():check(p,path,c['result_sha256'][p+'-region-brand-results.jsonl'])
for path,digest in c.get('input_sha256',{}).items(): check('input:'+path,path,digest)
assert all(x['match'] is not False for x in checks.values())
contract=load(B/'local-mother-contract.json'); fams=contract['families']; stats={}; samples=[]; allpro=[]
# Deliberately narrow, exact-complete-comment proposals with corresponding pre-existing AI pool evidence.
lex={'price':('价格预算',{'多少钱','什么价格','价格多少','什么价','价格','问价','询价','礼貌问价','礼貌询价','多少钱一个月','多少一个月','租金多少'}),'available':('房源状态',{'还有吗','还在吗','还有房吗','房子还在吗','还有房子吗','房子还有吗'}),'elevator':('楼层电梯',{'有电梯吗','有没有电梯','电梯有吗'})}
for platform,path in c['results'].items():
 rows=list(jl(path)); hist=[r for r in rows if not(platform=='douyin' and r['comment_id'] in newids)]; cand=[r for r in hist if r.get('mother_reply_text') or r.get('alternative_mother_reply_text')]; assert len(hist)==(34033 if platform=='douyin' else 3601)
 C=collections.Counter(); distr={k:collections.Counter() for k in ['role','state','interest','topics','relations','time_roles','topic_subject','topic_source','topic_polarity','preferred_slot','tone','contact_policy','family_proposals','reason']}; examples={};
 for r in cand:
  s=r.get('source_record') or {}; a=s.get('classification') if isinstance(s.get('classification'),dict) else s; plan=r.get('reply_plan') or s.get('reply_plan') or {}; txt=r.get('comment_text') or ''; comment_sha=hashlib.sha256(txt.encode()).hexdigest(); stored_sha=r.get('comment_text_sha256'); sha_ok=bool(stored_sha) and comment_sha==stored_sha; C['comment_sha_missing']+=int(not stored_sha); C['comment_sha_mismatch']+=int(bool(stored_sha) and not sha_ok)
  topics=a.get('topics');ev=a.get('topic_evidence');evkind='source_record.topic_evidence'
  if not isinstance(ev,list):
   ev=a.get('actual_pools') if isinstance(a.get('actual_pools'),list) else (topics if isinstance(topics,list) and all(isinstance(x,dict) for x in topics) else [])
   evkind='source_record.classification.actual_pools' if 'classification' in s else 'source_record.topics'
  regions=r.get('target_regions') or a.get('target_regions') or []; times=r.get('time_mentions') or a.get('time_mentions') or []; constraints=a.get('other_constraints') or s.get('other_constraints') or []; bounds=r.get('contact_boundaries') or a.get('contact_boundaries') or []
  tags=topics if isinstance(topics,list) else []; tag_names={x if isinstance(x,str) else x.get('pool') for x in tags if isinstance(x,(str,dict))}; tag_names.discard(None)
  poolnames={x.get('pool') for x in ev if isinstance(x,dict) and x.get('pool')}; C['local_mother_present']+=int('local_mother' in plan);C['local_mother_non_null']+=int(bool(plan.get('local_mother')))
  for key in ('topics','topic_evidence','target_regions','time_mentions','other_constraints','reply_plan','contact_boundaries'):
   raw=(r.get(key) if key in r and r.get(key) is not None else a.get(key) if key in a else s.get(key)); C[key+'_field_present']+=int(raw is not None); C[key+'_field_unknown_or_absent']+=int(raw is None)
  for key,val in [('topics',tags),('topic_evidence_or_actual_pools',ev),('target_regions',regions),('time_mentions',times),('other_constraints',constraints),('reply_plan',plan),('contact_boundaries',bounds)]:C[key+'_nonempty']+=int(bool(val))
  C['source_direct']+=int(a is s);C['source_nested_classification']+=int(a is not s);C['topic_evidence_literal_own']+=int(any(isinstance(x,dict) and x.get('quote') and x['quote'] in txt for x in ev)); C['regions_literal_own']+=int(any(isinstance(x,dict) and x.get('quote') and x['quote'] in txt for x in regions)); C['time_literal_own']+=int(any(isinstance(x,dict) and x.get('quote') and x['quote'] in txt for x in times));C['constraints_literal_own']+=int(any(isinstance(x,dict) and x.get('quote') and x['quote'] in txt for x in constraints))
  for key,v in [('role',r.get('role')),('state',r.get('demand_state')),('interest',r.get('interest_at_comment')),('preferred_slot',plan.get('preferred_mother_slot',s.get('preferred_mother_slot'))),('tone',plan.get('tone')),('contact_policy',r.get('contact_policy') or plan.get('contact_policy'))]:distr[key][str(v)]+=1
  for x in tag_names:distr['topics'][x]+=1
  for x in regions:
   if isinstance(x,dict):distr['relations'][str(x.get('relation'))]+=1
  for x in times:
   if isinstance(x,dict):distr['time_roles'][str(x.get('time_role'))]+=1
  for x in ev:
   if isinstance(x,dict):
    for key,field in [('topic_subject','subject'),('topic_source','source'),('topic_polarity','polarity')]:distr[key][str(x.get(field))]+=1
  pool_ev=[x for x in ev if isinstance(x,dict)]; normalized=txt.strip().strip('？?。！!，, '); family=None; reasons=[]
  for f,(pool,lexicon) in lex.items():
   if sha_ok and normalized in lexicon and poolnames=={pool} and tag_names in ({pool},set()) and pool_ev and all(x.get('subject')=='own_demand' and x.get('polarity')=='ask' and x.get('quote') and x['quote'] in txt and not x.get('condition_scope') for x in pool_ev) and not(regions or times or constraints or bounds):family=f;break
  if not sha_ok:reasons.append('原记录未保存评论摘要，待补来源核对' if not stored_sha else '当前评论字节与记录摘要不一致，暂停待核');
  if not family:reasons.append('未落入严格整句与单池候选，原有条件、主体、范围或语义需核对')
  if not ev:reasons.append('缺少结构化逐字主题证据，旧格式待适配')
  if len(poolnames)>1:reasons.append('多池整合与作用范围待核')
  if regions:reasons.append('地区关系及逐字范围待核，工作地不能当住址')
  if times:reasons.append('时间角色与原发表日需核对')
  if constraints:reasons.append('已有约束不得遗漏，逐字证据及主体待核')
  if not (r.get('contact_policy') or plan.get('contact_policy')):reasons.append('联系限制未明确，待核')
  if any(isinstance(x,dict) and (x.get('subject')!='own_demand' or x.get('condition_scope')) for x in pool_ev):reasons.append('主题主体或条件范围待核')
  if any(x in txt for x in ('不要','不想','不能','不是','不租','别','除了','预算','押','水电','合租','转租','我朋友','我同事')):reasons.append('否定、条件、引用或换主体待核')
  eligible=(r.get('role')=='demand' and r.get('demand_state')=='active_at_comment' and r.get('interest_at_comment') in ('medium','high','super_high'))
  if not eligible:reasons.append('原有角色状态或意向不满足短句资格，保留原判')
  # Existing templates may not preserve the full semantic context: every proposal remains unverified.
  item={'platform':platform,'cid':r['comment_id'],'uid':r['customer_uid'],'sourceSHA':comment_sha,'stored_comment_sha256':r.get('comment_text_sha256'),'source_sha_match':sha_ok,'source_file_sha256':checks[platform]['sha256'],'selection':'selected' if r.get('mother_reply_text') else 'alternative','status':'proposal_not_applied','family':family,'fill':{},'literal_evidence':[{'source_field':evkind,'pool':x.get('pool'),'quote':x.get('quote'),'subject':x.get('subject'),'polarity':x.get('polarity'),'condition_scope':x.get('condition_scope')} for x in pool_ev], 'source_field_evidence':{'role':r.get('role'),'demand_state':r.get('demand_state'),'interest_at_comment':r.get('interest_at_comment'),'topics':topics,'target_regions':regions,'time_mentions':times,'other_constraints':constraints,'reply_plan':plan,'contact_policy':r.get('contact_policy'),'contact_boundaries':bounds},'pending_reasons':reasons+['计划未做逐条语义和适配验证；不能直接生成、激活或发送']}
  allpro.append(item); C['strict_single_pool_family_candidates']+=int(bool(family));distr['family_proposals'][family or 'unknown']+=1
  for z in reasons:distr['reason'][z]+=1
  sampletags=[]
  if not ev:sampletags.append('旧格式无结构化主题证据')
  if len(poolnames)>1:sampletags.append('多池')
  if regions:sampletags.append('地区')
  if times:sampletags.append('时间')
  if constraints:sampletags.append('其他约束')
  if any(x in txt for x in ('不要','不想','不能','不是','不租','别')):sampletags.append('否定')
  if any(x in txt for x in ('预算','水电','元','租期','个月','月租')):sampletags.append('预算或租期')
  if any(x in txt for x in ('上班','工作','公司','朋友','同事','我家')):sampletags.append('工作地或他人需求')
  if family:sampletags.append('严格零填项')
  for tag in sampletags:
   if len(examples.setdefault(tag,[]))<2:examples[tag].append({'cid':r['comment_id'],'uid':r['customer_uid'],'comment':txt,'topic_evidence':pool_ev,'target_regions':regions,'time_mentions':times,'other_constraints':constraints,'family':family,'pending_reasons':reasons})
 stats[platform]={'total_records':len(rows),'historical_records':len(hist),'new_807_excluded':len(rows)-len(hist),'historical_selected':sum(bool(x.get('mother_reply_text')) for x in cand),'historical_alternatives':sum(bool(x.get('alternative_mother_reply_text')) for x in cand),'candidate_total':len(cand),'coverage_counts':dict(C),'distributions':{k:dict(v) for k,v in distr.items()},'sample_examples':examples}
 assert len(cand)==stats[platform]['historical_selected']+stats[platform]['historical_alternatives']
with open(O/'proposed-local-plan.jsonl','w',encoding='utf-8',newline='\n') as f:
 for r in allpro:f.write(json.dumps(r,ensure_ascii=False,separators=(',',':'))+'\n')
inv={'scope':'历史已有选中或备选母句，排除新807；计划仅为本地盘点，不激活','source_checks':checks,'platforms':stats,'confirmed_directly_usable_count':0,'confirmed_directly_usable_reason':'历史字段适配及复杂条件尚未逐条验证；严格整句候选是待核下限，不是准确率或已验证可直接生成数量。','status':'proposal_not_applied','platform_calls':0,'model_calls':0,'usage':'unknown'}
put(O/'inventory.json',inv)
lines=['# 历史母句盘点（未激活）','','已核对当前指针、清单、结果、输入和短句契约的已有 SHA；这里只整理原有字段，没有重判意向、生成回复、修改源库或发送。短句家族需保留原评论明确的条件；原判断、原稿保持原样。抖音 59 条旧记录没有保存评论摘要，已计算当前文本摘要供定位，但来源绑定仍待核；不应称作摘要不匹配。','']
for p,s in stats.items():
 lines += [f"## {p}",f"历史评论 {s['historical_records']} 条；已有基础母句选中 {s['historical_selected']} 条、备选 {s['historical_alternatives']} 条。已排除新批 {s['new_807_excluded']} 条。",f"已有 local_mother 非空 {s['coverage_counts'].get('local_mother_non_null',0)} 条；严格整句、单池、原文主体证据的零填项候选 {s['coverage_counts'].get('strict_single_pool_family_candidates',0)} 条。这些仍需复核，不是准确率，也不是可直接上线数量。",'','代表性原始评论及现有字段：']
 for tag,examples in s['sample_examples'].items():
  for e in examples:lines.append('- '+tag+'：'+e['comment']+'；原判断证据：'+json.dumps({k:e[k] for k in ('topic_evidence','target_regions','time_mentions','other_constraints') if e[k]},ensure_ascii=False)+'；待核：'+'、'.join(e['pending_reasons']))
 lines.append('')
lines += ['已有标签可作为候选家族线索，不能只凭关键词补写语义。可优先检查少量完整单句的价格、空房、电梯类，沿用现有家族及原文证据；多条件需要确认所有条件在同一句中保留，未确认以前不生成。历史数据的旧格式和小红书嵌套分类字段需要兼容；联系限制缺失、区域关系、否定、引用他人、时间角色与费用口径均保留待核。','', '该盘点不代表母句已发布或用户逐条认可；实际模型用量未知。']
(O/'report.md').write_text('\n'.join(lines)+'\n',encoding='utf-8');print(json.dumps({p:{k:s[k] for k in ('historical_records','historical_selected','historical_alternatives','candidate_total','coverage_counts')} for p,s in stats.items()},ensure_ascii=False))


