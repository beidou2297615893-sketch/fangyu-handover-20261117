"""Regression for 2026-11-11 slot filling and listing-ad exclusion."""
import re
import unittest
import semantic_guard as g
import business_fit as f
B=g.base

class SlotFix(unittest.TestCase):
 def test_budget_complete_amounts(self):
  for text,expected in [('预算两千五六一月，想找整租',['预算两千五六']),('一千五左右的单间有吗',['一千五左右']),('预算1500-2000合租',['预算1500-2000']),
                        ('望京上班，想整租一居室，4-5K预算',['4-5K']),('男生借评论区找预算一个人4000 一起整租可以养猫',['预算4000']),('预算5000左右',['预算5000左右'])]:
   with self.subTest(text=text):self.assertEqual(B._budgets(text),expected)
 def test_budget_incomplete_not_filled(self):
  for text in ['1500平？','预算一个月','预算20','押金2000元','3号线附近','2023-2024年','预算一般']:
   with self.subTest(text=text):self.assertEqual(B._budgets(text),[])
 def test_location_noise_rejected(self):
  self.assertEqual(B._valid_locations(['男生借评论区','哪个区','这个小区怎么租','可以推荐一个杭州萧山区','们小区']),[])
  self.assertEqual(B._valid_locations(['郫都区保税区附近']),['郫都区保税区附近'])
  self.assertEqual(B._valid_locations(['给孩子租一套在朝阳区']),['朝阳区'])
 def test_example_sentence(self):
  row={'comment_text':'男生借评论区找预算一个人4000 一起整租可以养猫 我可以做健身餐 最好7/14沿线','role':'demand','interest_at_comment':'high','pools':['价格预算','户型面积与居住方式','宠物','位置通勤']}
  d=B.render(row)['draft_text']
  self.assertNotIn('评论区',d);self.assertNotIn('预算一的话',d);self.assertIn('预算4000',d);self.assertIn('方隅公寓',d)
 def test_slots_whitelisted(self):
  for text,pools in [('有没有在黄浦区合租的',['位置通勤','户型面积与居住方式']),('是在哪个区？我刚在滨江租到1家6户的房子，也是付了2个月租金',['位置通勤','价格预算','入住与租期']),
                     ('想找个六环外，民水民电一居室可以停车的地方',['位置通勤','费用合同','房内设施','户型面积与居住方式'])]:
   with self.subTest(text=text):
    r=B.render({'comment_text':text,'pools':pools})
    for x in r['requested_details']['slots']:self.assertTrue(B._slot_ok(x,r['requested_details']['literals']),x)
    self.assertFalse(re.search(r'、、|，，|、，|哪个|评论|方隅公寓公寓',r['draft_text']))

class ListingAd(unittest.TestCase):
 ADS=['你好 还需要找房吗？成都各区有房源 并且无中介费 无带看费 需要的话我去看看符合你需求的','到底谁要租房啊，本人中介，真图真价房子对接房东','我有单间出租，嘉定的，行吗',
      '个人转租七号线罗南新村一居室独卫带厨房考虑不 可以看下主页','首经贸附近半价转租，有人需要吗','全成都有房源，实图实价','我是中介 不收中介费，13号线金运路站旁边考虑吗','您好还在租房吗我们这边有很多房源供你挑选']
 CUSTOMERS=['求无中介费的房，浦东','有房源的私我，求整租','滨江有没有个人转租啊','在哪里有单间出租','求租 黄村西大街附近的房东直租2居 转租 也找室友','有没有人转租啊',
            '浦东陆家嘴附近5公里有房源吗','有没有石景山区苹果园一区附近的房东直租呀','找个转租房子到11月20左右到期的','武侯大道附近租房，只能押一付一，套一或者合租都可以，有合适的私我','萧山有中介吗']
 def test_ads(self):
  for t in self.ADS:
   with self.subTest(t=t):self.assertTrue(f.listing_ad(t))
 def test_customers_kept(self):
  for t in self.CUSTOMERS:
   with self.subTest(t=t):self.assertIsNone(f.listing_ad(t))
 def test_screen_reason_label(self):
  got=f.screen(dict(comment_text=self.ADS[0],role='demand',pools=['房源状态'],interest_at_comment='high'))
  self.assertIn('listing_ad_or_agent',got['exclusion_reasons']);self.assertIn('房源广告/中介',got['exclusion_reason_labels'])
  self.assertFalse(got['eligible_candidate'])
  r=g.render(dict(comment_text=self.ADS[0],role='demand',pools=['房源状态'],interest_at_comment='high'))
  self.assertIsNone(r['draft_text'])

if __name__=='__main__':unittest.main()