import json,pathlib
O=pathlib.Path('work/fangyu-text-business-20261029/pool-mother-review/legacy-literal-binding');ss=[json.loads(l) for l in (O/'representative-input.jsonl').read_text(encoding='utf8').splitlines()]
notes='''保留房山区建设路附近；房为动作残片，地区加房态可复用area
合租是已判居住方式；房为泛称，可用requirements
租金多少是询价；金来自先删租的伪残片
问一下为礼貌动作，不构成新要求；保留询价
还有房是房态提问，不新增条件
看为看房动作，不视为未判条件
啥为疑问词，具体价格池已覆盖
你为联系对象，不移作主体条件
短租不能删短；保留短租可否核实族
房租多少不含预算；沿用price
嘞为语气词，价位未答必须询价
杨浦区为目标；房态询问不可写成已有库存
啥为疑问词，沿用location
我去为感叹，不能推为已经前往
没厨房吗为厨房有无询问；不能写成已确定无厨房
现在还有与什么价是两池，必须同时核房态和租金
联系问法不等于已能发私信；固定联系接话可预览
这房子为语境指代，不能把来源房源当方隅库存
原问位置，不重复问客户地点
真假尚未说明核什么；保留具体核验对象短标签缺口
那啊为简短位置问法；原AI位置池保留，不重判
是多少钱为询价，不从这推方隅报价
现在是报价时效，不是入住日期
尾不为疑问式，不是拒租否定
有吗还为房态提问
原房源还在吗只能核库存，不能承诺同房
多少平为面积询问；不是可接受面积数值
怎么组有错字，原看房联系保留；可用流程核实，不能改原字
易居国际为原AI目标地区，不解释为我住易居国际
现在为房态时点，不是租期
这么便宜的一居室需保留便宜诉求、一居与空房；价格未知只问
八里桥附近的好房含主观偏好，可保留好房原短词或明确待核
高楼金附近、价格合适：可承接但不能声称优惠比原帖便宜
十公里内与2000以内必须联立保留，不能只剩小红门
1000为所询报价，1.9k+及2公里外是看过的房源经历；短作用范围不足保持held
学知园到清河沿线、5000、一居联立，沿线不能删
蹲是求房动作；东西城七号线沿线是目标；5000预算不应重复预算
北京、一居、预算3000和找房东联系均保留；不冒充房东
预算2000到1400倒序有歧义，不自动交换；边牧保留；保持预算范围待核
1800为所询报价，水电与套路需核实费用条款，不当本人预算
民用商用是费用二选一询问，不拆成两种都要求
这样是源房型指代；一居及房态保留
多钱是询价同义；一居不丢
西三旗是工作地，四五千是负担不起比较价；不转预算，保留短标签缺口
宣武门工作地、近一点、一千左右联立；通勤问句，不转目标
一千一下疑似以下错字，不静默修正；两区之间和平房可接受保留待核
便宜一千左右为所求价位，短字面保留，不编方隅报价
800为所询报价，押金多少及房态都核，不转预算
八百为报价疑问，位置和押金都不可遗漏
来广营地铁目标、一个女生居住主体和房态保留，不推合租
一房两厅、价格、宠物友好和离地铁近联立；不能只问房型
二号线目标、两室一厅、低价诉求；穷鬼不是数值预算
蹲缺具体推进语义，原判不动，不当地点；保留短标签缺口
可约时间看房；原contact缺失保持unknown，允许技术预览而非发送
看房不尾不为疑问；原contact缺失保持unknown
何时方便看房不是已预约；原contact缺失保持unknown
找女生室友且有房主体关系需核，不改为确定整套公寓居住需求
约看未完成；原contact缺失保持unknown
求为请求动作；位置池已覆盖；contact缺失保持unknown
me为口语转写残片，但民水民电问题已知；保留询问不答事实，contact缺失保持unknown'''.splitlines()
assert len(notes)==len(ss)==60
out=[]
for i,(s,n) in enumerate(zip(ss,notes)):
 out.append({'review_index':i,'platform':s['plan']['platform'],'cid':s['plan']['cid'],'uid':s['plan']['uid'],'sourceSHA':s['plan']['sourceSHA'],'comment':s['comment'],'semantic_review':n,'classification_changed':False,'reviewer':'current assistant semantic representative review; exact runtime model id unavailable','review_stage':'before_batch_binding_algorithm','independent_holdout':False,'human_confirmed':False})
(O/'representative-review.jsonl').write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in out),encoding='utf8')
print({'reviewed':len(out)})
