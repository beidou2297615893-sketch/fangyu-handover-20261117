import json,pathlib,sys,datetime
P=pathlib.Path(__file__).resolve().parent;A=P.parent/'recall-audit'/'part-0'
def save(n,groups,changes=None):
 changes=changes or {};d=json.loads((A/f'page-{n:02}.json').read_text('utf-8'));expected=[c['key'] for g in d['post_groups'] for c in g['comments']]
 rows=[]
 for reason,keys in groups:
  for key in keys.split():rows.append({'review_key':key,'decision':'keep','reason':reason,'patch':{}})
 for key,(reason,patch) in changes.items():rows.append({'review_key':key,'decision':'change','reason':reason,'patch':patch})
 assert len(rows)==len(expected) and {r['review_key'] for r in rows}==set(expected)
 lookup={r['review_key']:r for r in rows};assert len(lookup)==len(rows)
 (A/f'page-{n:02}.audit.jsonl').write_text(''.join(json.dumps(lookup[k],ensure_ascii=False)+'\n' for k in expected),'utf-8')
 progress={'completed_pages':[int(p.name[5:7]) for p in A.glob('page-*.audit.jsonl')],'usage':'unknown','updated_at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 (P/'progress.json').write_text(json.dumps(progress,ensure_ascii=False,indent=2),'utf-8')
 print(n,len(rows),len(changes))
