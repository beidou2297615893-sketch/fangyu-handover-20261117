"""Round 2 (2026-11-11 13:xx): agent / sublet-supplier / advice comments must not enter the send queue."""
import unittest
import business_fit as f

ADS=['金桥可以让我帮忙找房子哦[看]','西江湾路白领公寓有人需要租吗，低价转租','我是刚入职没多久的，双流东升想租房的可以找我，可以帮忙搬家',
 '新人入职中介，需要租房的可以找我没有套路不骗人','有人要租房吗？没找到合适的工作，打算转租出去[苦涩]','谁想租房找我呀','成华有人租的没我需要转租',
 '有房出租','台江鼓楼租房正规中介，需要私我，有中介费','想问一下浦东新区还有人要租房吗，在曹路附近的，我这边有转租的','临平没有人需要租吗[流泪]',
 '九亭找房可以找我[舔屏]','有的，，，具体在哪个位置，我们这边可以提供房源，全网价格价值最优','松江有房出租','上海大学附近想租房的找我，个人房直租无中介费',
 '中原这片有人租嘛？中原路殷行路附近 2室一厅，有天井','萧山区可以加我，我是良心中介','在滨江做中介有没有人想加我一下',
 '彭浦新村， 哦有房可以出租','浦东五洲大道附近有要租房的可以看看我主页，无中介费','泗泾地铁站附近一室 直租 3000有要的吗',
 '武候立交内2.5环旁小套二房东自己出租，无中介。可以吗','有没有朋友需要中介服务的，可打折','有帮我找房子的中介，人非常好。可以推荐。做13号线14号线的。']
KEEP=['有人转租吗','有没有单间出租','求房东直租','有没有个人转租啊','萧山有中介吗','中介太坑了有没有房东直租','求无中介费的房','有房源的私我，求整租',
 '在哪里有单间出租','有房出租吗','哪里有房出租','我想转租一个单间','同租，有的私我，国宾板块','有没有人转租啊','五角场有人租吗','你好，我想找房子，你们可以帮我找吗',
 '还是要找正规中介公司，有门店的这种，','建议你们出个三千的','马上淡季了，我想现在找房便宜点',
 '有没有，出租门头沟小院的？不要太大，联系我啊！','有合适的房东或者中介可以联系我','要是有女宝宝合租的话也可以找我','大家建议住哪个区','求建议，想在滨江租房','有中介可以推荐吗','宝 求推荐中介！ 我就在附近！','您好，请问房子租出去了吗？','这房子租出去了吗','能不能只租个房间和公共区域然后帮你照顾小猫']

class Round2(unittest.TestCase):
 def test_supply_detected(self):
  for t in ADS:
   with self.subTest(t=t):self.assertTrue(f.listing_ad(t))
 def test_customers_kept(self):
  for t in KEEP:
   with self.subTest(t=t):self.assertIsNone(f.listing_ad(t));self.assertIsNone(f.advice_not_self(t))
 def test_advice_excluded_as_not_self(self):
  s=f.screen({'comment_text':'马上淡季了，你现在找房子应该也很找到便宜点的','role':'unknown','platform':'douyin'})
  self.assertIn('advice_not_self_demand',s['exclusion_reasons']);self.assertNotIn('listing_ad_or_agent',s['exclusion_reasons'])
  self.assertIn('非本人找房需求（劝告/科普/反问他人/房东经验）',s['exclusion_reason_labels'])
 def test_landlord_and_advice_not_self(self):
  for t in ['我北京的房子很容易就出租了，几乎当天就能签合同','建议厨房和卧室中间不要弄帘子','您好博主，我不租房子我可以帮你养猫咪']:
   with self.subTest(t=t):self.assertTrue(f.advice_not_self(t))
 def test_agent_screen_label(self):
  s=f.screen({'comment_text':'台江鼓楼租房正规中介，需要私我，有中介费','role':'demand','platform':'douyin'})
  self.assertIn('房源广告/中介',s['exclusion_reason_labels'])

if __name__=='__main__':unittest.main()
