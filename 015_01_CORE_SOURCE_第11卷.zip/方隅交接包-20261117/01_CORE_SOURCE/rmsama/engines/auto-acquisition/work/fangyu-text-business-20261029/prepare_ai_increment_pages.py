"""Group a frozen run into model input pages without classifying text."""
import argparse
import hashlib
import json
import re
from datetime import date, datetime, timezone
from pathlib import Path

W = Path(__file__).resolve().parent


def read(path):
    return [json.loads(line) for line in path.read_text(encoding='utf-8').splitlines() if line.strip()]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--run', required=True, help='16-character frozen run hash')
    parser.add_argument('--analysis-date', help='ISO date for analysis; defaults to today on first preparation')
    args = parser.parse_args()
    if not re.fullmatch(r'[0-9a-f]{16}', args.run):
        parser.error('--run must be a 16-character lowercase hexadecimal hash')
    b = W / 'douyin-registered-v2' / 'increments' / args.run
    manifest = json.loads((b / 'manifest.json').read_text(encoding='utf-8'))
    raw = (b / 'input.jsonl').read_bytes().replace(b'\r\n', b'\n')
    assert hashlib.sha256(raw).hexdigest() == manifest['input_sha256'] and manifest['input_sha256'].startswith(args.run)
    inputs = read(b / 'input.jsonl')
    assert len(inputs) == manifest['new_comments']
    source = {r['review_key']: r for r in inputs}
    assert len(source) == len(inputs)
    shards = [read(b / f'shard-{i}.jsonl') for i in range(3)]
    assert all(shards[i] == inputs[i::3] for i in range(3)), 'Frozen shards do not match input'
    pilot_path = b / 'pilot-200' / 'fine-reviewed.jsonl'
    pilot_rows = read(pilot_path) if pilot_path.exists() else []
    pilot_keys = {r['review_key'] for r in pilot_rows}
    assert len(pilot_keys) == len(pilot_rows) and pilot_keys <= source.keys()
    for r in pilot_rows:
        assert all(r[k] == source[r['review_key']][k] for k in ('comment_id', 'customer_uid', 'video_id'))
    existing_page = b / 'AI-pages' / 'shard-0' / 'page-00.json'
    analysis_date = args.analysis_date or (json.loads(existing_page.read_text(encoding='utf-8'))['analysis_date'] if existing_page.exists() else date.today().isoformat())
    date.fromisoformat(analysis_date)
    planned = []
    counts = []
    for i, shard in enumerate(shards):
        selected = [r for r in shard if r['review_key'] not in pilot_keys]
        dest = b / 'AI-pages' / f'shard-{i}'
        for page_no, offset in enumerate(range(0, len(selected), 180)):
            groups = {}
            for r in selected[offset:offset + 180]:
                key = (r['video_id'], r['post_body'])
                group = groups.setdefault(key, {'video': r['video_id'], 'post_body': r['post_body'], 'comments': []})
                group['comments'].append({'key': r['review_key'], 'text': r['comment_text'], 'published_at': datetime.fromtimestamp(r['published_at_unix'], timezone.utc).isoformat() if r.get('published_at_unix') else None, 'same_author': r['post_author_same_as_commenter'], 'reply_to': r['reply_to'], 'parent': r['direct_parent_text'], 'source_conflict': r['source_version_conflict']})
            packed = json.dumps({'analysis_date': analysis_date, 'shared_post_context': list(groups.values())}, ensure_ascii=False, separators=(',', ':'))
            planned.append((dest / f'page-{page_no:02}.json', packed))
        task = {'shard': i, 'comments': len(selected), 'pages': (len(selected) + 179) // 180, 'source_full_metadata_file': str(b / f'shard-{i}.jsonl'), 'exclude_pilot_comment_ids': sorted(source[k]['comment_id'] for k in pilot_keys), 'expected_review_keys': [r['review_key'] for r in selected], 'output_file': str(b / f'reviewed-new-{i}.jsonl'), 'status': 'prepared', 'all_comment_semantics': 'AI_initial_and_detailed', 'reply_generation': 'local_approved_mothers', 'platform_calls': 0}
        planned.append((dest / 'task.json', json.dumps(task, ensure_ascii=False, indent=2)))
        counts.append(len(selected))
    assert sum(counts) + len(pilot_keys) == len(inputs)
    # Refuse conflicting existing pages/tasks and unexpected stale page files; never overwrite evidence.
    for path, content in planned:
        if path.exists():
            assert path.read_text(encoding='utf-8') == content, f'Existing task/page differs: {path}'
    expected_pages = {p for p, _ in planned if p.name.startswith('page-')}
    for path in (b / 'AI-pages').glob('shard-*/page-*.json'):
        assert path in expected_pages, f'Unexpected existing page: {path}'
    for path, content in planned:
        path.parent.mkdir(parents=True, exist_ok=True)
        if not path.exists():
            path.write_bytes(content.encode('utf-8'))
    print(json.dumps({'run': args.run, 'remaining_model_records': sum(counts), 'per_shard': counts, 'page_size': 180, 'existing_pilot_not_repeated': len(pilot_keys), 'source_modified': False, 'platform_calls': 0}))


if __name__ == '__main__':
    main()
