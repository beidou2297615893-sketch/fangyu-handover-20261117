import copy, hashlib, importlib.util, json, shutil, sqlite3, subprocess, sys, tempfile, unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent
MODULE = ROOT / 'mother_adapter.py'

def adapter():
    if not MODULE.exists():
        raise AssertionError('mother adapter is not yet implemented')
    spec = importlib.util.spec_from_file_location('mother_adapter', MODULE)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

MOTHERS = [{'slot': 1, 'user_approved': True, 'template': '宝宝，我住方隅公寓这边，介绍有优惠的。', 'required_facts': '住户及优惠'}, {'slot': 2, 'user_approved': True, 'template': '有【已核实预算内房型】', 'required_facts': '预算内房源'}, {'slot': 3, 'user_approved': False, 'template': '未认可', 'required_facts': '条件'}]
def row(cid='1', uid='u', platform='douyin', at='2026-01-01T00:00:00+08:00', **changes):
    x = dict(comment_id=cid, customer_uid=uid, platform=platform, published_at=at, role='demand', demand_state='active_at_comment', interest_at_comment='high', reason='原分类理由', context_flags={'same_author': False}, contact_boundaries=[], reply_plan=dict(preferred_mother_slot=1, generic_intro_suitable=True, tone='normal', missing_facts=[], caution=[], contact_policy='allow'))
    x.update(changes)
    return x

class AdapterTests(unittest.TestCase):
    def test_ai_rejects_generic_and_mixed_can_be_allowed(self):
        a = adapter(); x = row(); x['reply_plan']['generic_intro_suitable'] = False
        a.select_reply(x, MOTHERS); self.assertIsNone(x['mother_reply_text'])
        y = row(role='mixed', interest_at_comment='uncertain'); a.select_reply(y, MOTHERS); self.assertEqual(y['mother_slot'], 1)
        self.assertEqual(y['reason'], '原分类理由'); self.assertFalse(y['send_authorized']); self.assertFalse(y['can_send_now'])
    def test_serious_and_identity_limit_remain_draft(self):
        a=adapter(); x=row(); x['reply_plan'].update(tone='serious',contact_policy='identity_restricted')
        a.select_reply(x,MOTHERS); self.assertEqual(x['mother_reply_text'],'我住方隅公寓这边，介绍有优惠的。'); self.assertTrue(x['contact_manual_review'])
    def test_legacy_ai_empty_contact_list_is_allow_but_missing_or_nonempty_needs_review(self):
        a=adapter()
        for boundary, expected in (([],False), (['身份限制'],True), (None,True)):
            x=row(); x['reply_plan'].pop('contact_policy'); x['classification_method']='ai_independent_semantic_fine_review'
            if boundary is None: x.pop('contact_boundaries')
            else: x['contact_boundaries']=boundary
            a.select_reply(x,MOTHERS); self.assertEqual(x['contact_manual_review'],expected); self.assertIsNotNone(x['mother_reply_text'])
        x=row(); x['reply_plan'].pop('contact_policy'); x.pop('classification_method',None)
        a.select_reply(x,MOTHERS); self.assertTrue(x['contact_manual_review'])
    def test_special_and_unapproved_never_fabricate(self):
        a=adapter()
        for slot in (2,3):
            x=row(); x['reply_plan']['preferred_mother_slot']=slot; a.select_reply(x,MOTHERS)
            self.assertEqual(x['mother_slot'],1); self.assertEqual(x['preferred_mother_slot'],slot); self.assertNotIn('【',x['mother_reply_text']); self.assertTrue(x['reply_missing_facts']); self.assertTrue(x['reply_unanswered_specific_question'])
    def test_disallowed_states_and_no_contact(self):
        a=adapter()
        for changes in (dict(role='unknown'),dict(role='supply'),dict(demand_state='ended'),dict(demand_state='historical'),dict(source_version_conflict=True)):
            x=row(**changes); a.select_reply(x,MOTHERS); self.assertIsNone(x['mother_reply_text'])
        x=row(); x['reply_plan']['contact_policy']='no_contact'; a.select_reply(x,MOTHERS); self.assertIsNone(x['mother_reply_text'])
    def test_history_not_rewritten_and_later_ended_then_active(self):
        a=adapter(); old=row(cid='old'); old.pop('reply_plan'); old.update(mother_slot=7,mother_reply_text='原来认可的历史稿',reply_generation_model_calls=4,classification_model_calls=9)
        a.select_reply(old,MOTHERS); self.assertEqual(old['mother_reply_text'],'原来认可的历史稿'); self.assertEqual(old['reply_generation_model_calls'],4); self.assertEqual(old['classification_model_calls'],9)
        end=row(cid='end',at='2026-02-01T00:00:00+08:00',demand_state='ended'); a.select_reply(end,MOTHERS)
        rows=[old,end]; a.reconcile_customers(rows); self.assertIsNone(old['mother_reply_text']); self.assertEqual(old['alternative_mother_reply_text'],'原来认可的历史稿')
        new=row(cid='new',at='2026-03-01T00:00:00+08:00'); a.select_reply(new,MOTHERS); a.reconcile_customers(rows+[new]); self.assertEqual(new['mother_slot'],1); self.assertIsNotNone(new['mother_reply_text'])
    def test_no_cross_platform_merge_and_alternatives(self):
        a=adapter(); xs=[row(cid='a'),row(cid='b',at='2026-02-01T00:00:00+08:00'),row(cid='c',platform='xhs')]
        for x in xs:a.select_reply(x,MOTHERS)
        a.reconcile_customers(xs); self.assertIsNone(xs[0]['mother_reply_text']); self.assertIsNotNone(xs[0]['alternative_mother_reply_text']); self.assertIsNotNone(xs[1]['mother_reply_text']); self.assertIsNotNone(xs[2]['mother_reply_text'])
    def test_unknown_time_does_not_prove_ended(self):
        a=adapter(); x=row(); a.select_reply(x,MOTHERS); e=row(cid='e',at=None,demand_state='ended'); a.select_reply(e,MOTHERS); a.reconcile_customers([x,e]); self.assertIsNotNone(x['mother_reply_text']); self.assertTrue(x['timeline_review'])
    def test_readonly_account_trace_and_mismatch(self):
        a=adapter()
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'test.sqlite'; db=sqlite3.connect(p)
            db.executescript('CREATE TABLE observations(request_id TEXT,stable_key TEXT,account_uid TEXT,kind TEXT); CREATE TABLE attempts(request_id TEXT PRIMARY KEY,spec TEXT);')
            db.executemany('INSERT INTO observations VALUES(?,?,?,?)',[('r1','comment:1','acct-a','comments'),('r2','comment:1','acct-b','comments'),('r3','comment:1','acct-c','comments')]); db.executemany('INSERT INTO attempts VALUES(?,?)', [('r1',json.dumps({'account_uid':'acct-a'})),('r2',json.dumps({'account_uid':'acct-b'})),('r3',json.dumps({'account_uid':'other'}))]); db.commit(); db.close()
            db=a.open_source_readonly(p); out=a.enrich_observations(db,'comment:1',[{'request_id':'r1'},{'request_id':'r2'},{'request_id':'r3'},{'request_id':'missing'}]); self.assertEqual([o['collection_account_uid'] for o in out],['acct-a','acct-b',None,None]); self.assertTrue(out[2]['account_trace_review']); self.assertTrue(out[3]['account_trace_review'])
            with self.assertRaises(sqlite3.OperationalError): db.execute("INSERT INTO attempts VALUES ('x','{}')")
            db.close()


class PublisherIntegrationTests(unittest.TestCase):
    def test_isolated_publisher_preserves_old_and_reviews_source_account(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory); w=root/'work/fangyu-text-business-20261029'; b=root/'work/fangyu-douyin-independent'; d=w/'douyin-registered-v2'; run='synthetic'; inc=d/'increments'/run
            inc.mkdir(parents=True); (w/'mothers').mkdir(); (b/'runtime').mkdir(parents=True); (b/'text-classification-snapshots').mkdir(); out=root/'outputs/方隅双平台文本业务/抖音逐店采集与意向'; out.mkdir(parents=True); catalog=root/'outputs/方隅双平台文本业务/门店词库'; catalog.mkdir(parents=True)
            (catalog/'双平台优先搜索总表.csv').write_text('适用门店资料组\n测试店\n',encoding='utf-8-sig')
            for name in ('mother_adapter.py','publish_douyin_increment_snapshot.py'): shutil.copy(ROOT/name,w/name)
            (w/'mothers/first50.json').write_text(json.dumps(MOTHERS,ensure_ascii=False),encoding='utf8')
            old=row(cid='1',uid='old'); old.pop('reply_plan'); old.update(video_id='v1',comment_text='old text',mother_slot=7,mother_reply_text='原历史稿',topics=[],source_stores_seen=['测试店'],source_keywords_seen=['词'],source_observations=[])
            prior=d/'prior.jsonl'; prior.write_bytes((json.dumps(old,ensure_ascii=False)+'\n').encode())
            source=dict(comment_id='2',customer_uid='new',video_id='v2',review_key='D0001',comment_text='new text',post_body='',post_author_same_as_commenter=False,source_version_conflict=True,published_at_unix=1767225600,source_observations=[dict(request_id='r2',source_store='测试店',keyword='词')],source_comment_sha256='fixture',ip_location_raw=None,deeper_reply_count_visible=0)
            reviewed=row(cid='2',uid='new'); reviewed.update(video_id='v2',review_key='D0001',topics=[],evidence=['new text'],target_regions=[],review_reasons=[],assigned_store=None,send_authorized=False)
            raw=(json.dumps(source,ensure_ascii=False)+'\n').encode(); (inc/'input.jsonl').write_bytes(raw)
            manifest=dict(input_sha256=hashlib.sha256(raw).hexdigest(),prior_result_file=str(prior),prior_result_sha256=hashlib.sha256(prior.read_bytes()).hexdigest(),eligible_snapshot_comments=2,policy_sha256='fixture')
            (inc/'manifest.json').write_text(json.dumps(manifest),encoding='utf8')
            for i in range(3): (inc/f'reviewed-{i}.jsonl').write_text(json.dumps(reviewed,ensure_ascii=False)+'\n' if i==0 else '',encoding='utf8')
            obs={'comment:1':[dict(request_id='r1',source_store='测试店',keyword='词')], 'comment:2':source['source_observations']}
            (inc/'all-source-observations.json').write_text(json.dumps(obs,ensure_ascii=False),encoding='utf8'); frozen=(inc/'all-source-observations.json').read_bytes()
            dbpath=b/'runtime/collection.sqlite3'; db=sqlite3.connect(dbpath); db.executescript('CREATE TABLE entities(stable_key TEXT,kind TEXT,source_id TEXT,data TEXT); CREATE TABLE observations(request_id TEXT,stable_key TEXT,account_uid TEXT,kind TEXT); CREATE TABLE attempts(request_id TEXT PRIMARY KEY,spec TEXT);')
            for cid,uid in [('1','old'),('2','new')]:
                db.execute('INSERT INTO entities VALUES(?,?,?,?)',(f'comment:{cid}','comments',cid,json.dumps(dict(text='old text' if cid=='1' else 'new text',aweme_id='v'+cid,user=dict(uid=uid)))))
                db.execute('INSERT INTO observations VALUES(?,?,?,?)',('r'+cid,'comment:'+cid,'account-'+cid,'comments')); db.execute('INSERT INTO attempts VALUES(?,?)',('r'+cid,json.dumps(dict(account_uid='account-'+cid))))
            db.commit(); db.close(); before=dbpath.read_bytes()
            proc=subprocess.run([sys.executable,str(w/'publish_douyin_increment_snapshot.py'),run],capture_output=True,text=True,encoding='utf8'); self.assertEqual(proc.returncode,0,proc.stderr)
            actual={x['comment_id']:x for x in map(json.loads,(inc/'classified-snapshot.jsonl').read_text(encoding='utf8').splitlines())}
            self.assertEqual(actual['1']['mother_reply_text'],'原历史稿'); self.assertEqual(actual['1']['mother_slot'],7)
            self.assertEqual(actual['2']['reason'],'原分类理由'); self.assertEqual(actual['2']['interest_at_comment'],'high'); self.assertIsNone(actual['2']['mother_reply_text'])
            self.assertEqual(actual['1']['source_observations'][0]['collection_account_uid'],'account-1'); self.assertEqual(actual['2']['source_observations'][0]['collection_account_uid'],'account-2')
            self.assertEqual(before,dbpath.read_bytes()); self.assertEqual(frozen,(inc/'all-source-observations.json').read_bytes())

if __name__ == '__main__': unittest.main()

