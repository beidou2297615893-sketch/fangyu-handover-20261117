import json,pathlib,hashlib,collections,functools
O=pathlib.Path(__file__).resolve().parent; P=O.parent; W=P.parent
def load(p):return json.loads(pathlib.Path(p).read_text('utf-8-sig'))
def jl(p):return [json.loads(l) for l in pathlib.Path(p).read_text('utf-8-sig').splitlines() if l.strip()]
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def can(x):return hashlib.sha256(json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def key(x):return x['platform'],str(x.get('cid',x.get('comment_id'))),str(x.get('uid',x.get('customer_uid')))
def dump(n,x):(O/n).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n','utf8')
def out(n,x):(O/n).write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in x),'utf8')
manifest=load(O/'manifest.json');contexts=load(O/'shared-contexts.json');checks=collections.Counter();source_files={f:sha(f) for f in manifest['source_files_sha256_before']}
assert source_files==manifest['source_files_sha256_before'];checks['protected_source_file_SHA_unchanged']=len(source_files)
sourcepaths=load(W/'region-brand-routing/current.json')['results']; sources={key(r):r for f in sourcepaths.values() for r in jl(f)}
plans={};families={}
for group,planfile,contractfiles in [('A',P/'legacy-local-planning-v2/local-proposed-plans.jsonl',[P/'legacy-local-planning-v2/local-mother-contract-v2.json']),('B',P/'legacy-combo-families/source-bound-plans.jsonl',[W/'douyin-registered-v2/increments/f98cc21138910fb9/local-mother-contract.json',P/'legacy-combo-families/contract-addon.json'])]:
 plans[group]={key(p):p for p in jl(planfile)};families[group]={k:v for f in contractfiles for k,v in load(f)['families'].items()}
excluded=set()
for f in manifest['excluded_sources']:
 if f.endswith('.json'):excluded.update(key(x['plan']) for x in load(f)['cases'])
 else:excluded.update(key(x) for x in jl(f))
notes=lambda f:{int(a):(b,c) for l in pathlib.Path(f).read_text('utf8').splitlines() if l.strip() for a,b,c in [l.split('|',2)]}
def assemble(inputfile,notefile,fresh):
 ns=notes(O/notefile);rs=jl(O/inputfile);assert set(ns)==set(range(1,len(rs)+1));result=[]
 for r in rs:
  k=key(r);p=plans[r['group']][k];s=sources[k];raw=s.get('source_record') or {};orig=s.get('original_raw_record') or {};cl=raw.get('classification') or raw;ctx=contexts[r['context_key']]
  assert can(p)==r['plan_sha256']; assert hashlib.sha256(s['comment_text'].encode()).hexdigest()==r['source_comment_sha256']==p['sourceSHA'];assert s['comment_text']==r['comment_text'];assert can(raw)==p['original_classification_sha256'];assert source_files[r['source_file']]==r['source_file_sha256']==p['source_file_sha256'];checks['ID_UID_text_and_plan_SHA_and_classification_match']+=1
  assert r['source_contact_policy']==p.get('contact_policy_original',p.get('original_contact_policy')); assert not r['send_authorized'] and not r['can_send_now']
  if fresh:assert k not in excluded;checks['fresh_ID_not_in_development_or_old_QA']+=1
  if p.get('family'):assert r['rendered_text']==families[r['group']][p['family']]['template'].format(**p['fill']);checks['fixed_template_render_match']+=1
  else:assert r['rendered_text'] is None
  assert ctx['post_body']==(raw.get('post_body') or orig.get('post_text'));assert ctx['post_title']==(raw.get('post_title') or orig.get('post_title'));assert r['direct_parent_text']==(raw.get('direct_parent_text') or orig.get('parent_text'));checks['stored_shared_context_and_parent_match']+=1
  verdict,reason=ns[r['sample_index']];assert verdict in ('pass','change_plan_only','hold')
  facts=[{'claim':'我住方隅','status':'actual_sender_resident_identity_unverified'},{'claim':'介绍有优惠','status':'referral_eligibility_store_validity_conditions_unverified'},{'claim':'同店同一适用房源的现价/房态/设施/通勤','status':'unverified; source_post_is_not_fangyu_facts'}]
  if not r['rendered_text'] or r['family']=='object_clarification':facts=[]
  identity={'role':r['source_role'],'state':r['source_state'],'interest':r['source_interest'],'subject_polarity_scope_evidence':r['source_topic_evidence'],'needs_review':r['needs_review'],'blocking_reasons':r['source_blocking_reasons'],'changed':False}
  result.append({**r,'verdict':verdict,'reason':reason,'evidence_comment_quote':r['comment_text'],'evidence_plan_slot_quote':r['fill'],'evidence_render_quote':r['rendered_text'],'evidence_context_quote':ctx.get('post_title') or ctx.get('post_body'),'context_source_fields':['source_record.post_body' if raw.get('post_body') else 'original_raw_record.post_text','source_record.post_title' if raw.get('post_title') else 'original_raw_record.post_title'],'context_sha256':can(ctx),'original_classification_preserved':identity,'boundary_review':{'geography':{'original':r['target_regions'],'status':'literal_or_original_uncertainty_preserved_unless_reason_flags_issue'},'time':{'published_at':r['source_published_at'],'mentions':r['time_mentions'],'current_need':'unknown_not_inferred_from_active_at_comment','quote_cycle':'unknown_if_not_explicit; review_reason_flags_monthly_addition'},'identity':{'actor':'own_demand_evidence_kept','resident':'unverified_fact_not_sending_permission'},'contact':{'original':r['source_contact_policy'],'effective':r['source_contact_policy'] or 'unknown','eligibility':'not_granted_by_semantic_QA','boundaries':r['source_contact_boundaries']}},'unverified_fact_claims':facts,'original_missing_facts_preserved':r['source_reply_missing_facts'],'human_confirmed':False,'review_method':'current_assistant_individual_semantic_review_of_each_comment_plan_render_and_stored_context; local_deterministic_assembly_only','new_holdout':fresh,'classification_accuracy_claim':None,'API_calls':0,'send_attempts':0,'usage':'unknown'})
 return result
fresh=assemble('sample-200.jsonl','manual-notes-200.txt',True);reg=assemble('regression-input.jsonl','manual-notes-regression.txt',False);assert len(fresh)==200 and len({key(r) for r in fresh})==200
allcombo=set(load(P/'legacy-combo-families/contract-addon.json')['families']);covered={r['family'] for r in fresh+reg};assert allcombo<=covered
out('review-200.jsonl',fresh);out('regression-review.jsonl',reg)
summary={'new_holdout_count':len(fresh),'new_holdout_verdicts':dict(collections.Counter(r['verdict'] for r in fresh)),'new_holdout_by_group':{g:dict(collections.Counter(r['verdict'] for r in fresh if r['group']==g)) for g in ['A','B']},'regression_count':len(reg),'regression_verdicts':dict(collections.Counter(r['verdict'] for r in reg)),'unknown_original_contact_in_holdout':sum(r['source_contact_policy'] is None for r in fresh),'all_21_combo_families_covered_combined':True,'new_only_combo_family_count':len({r['family'] for r in fresh}&allcombo),'new_only_all_21_coverage':False,'checks':dict(checks),'mechanical_checks_passed':True,'semantic_release_all_passed':all(r['verdict']=='pass' for r in fresh+reg),'original_sources_and_pointers_unchanged':True,'all_send_false':True,'remote_API_or_model_calls':0,'platform_calls':0,'send_attempts':0,'usage':'unknown','scope':'reply fit semantic QA; not population accuracy, intent relabelling, human approval or sending authorization'}
dump('validation.json',summary)
manifest.update(review_output_sha256={n:sha(O/n) for n in ['review-200.jsonl','regression-review.jsonl','sample-200.jsonl','regression-input.jsonl','shared-contexts.json','manual-notes-200.txt','manual-notes-regression.txt']},source_files_sha256_after=source_files,summary=summary)
dump('manifest.json',manifest)
print(json.dumps(summary,ensure_ascii=False))
