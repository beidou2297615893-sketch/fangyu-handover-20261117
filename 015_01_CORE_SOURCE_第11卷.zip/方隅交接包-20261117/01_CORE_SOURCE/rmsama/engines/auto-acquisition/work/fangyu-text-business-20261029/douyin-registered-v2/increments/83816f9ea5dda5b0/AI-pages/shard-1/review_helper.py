import json, pathlib, hashlib, collections, sys, runpy
P=pathlib.Path(__file__).resolve().parent
B=P.parent.parent
W=B.parent.parent.parent
POOLS=['价格预算','位置通勤','户型面积与居住方式','房内设施','宠物','楼层电梯','入住与租期','房源状态','费用合同','看房联系']
MOTHERS={m['slot']:m for m in json.loads((W/'approved-mothers-model-view.json').read_text(encoding='utf8'))}
PROFILES={
 'H':('demand','active_at_comment','high','本人在租房语境提出当时询租或具体住房条件。'),
 'M':('demand','unknown','medium','居住分享或一般租房语境下有明确住房关注，本人实际找房动作未明。'),
 'A':('demand','active_at_comment','medium','本人有当时住房询问，但原帖为生活分享或弱语境，所指可租对象待核。'),
 'V':('demand','active_at_comment','super_high','本人明确提出预约、时段或订租动作，尚不代表对方已确认。'),
 'U':('unknown','unknown','uncertain','文字或供需对象不足以确定本人租房需求，保留具体待核线索。'),
 'T':('unknown','unknown','uncertain','主要为艾特或转发互动，用途不明，不能判断本人求租。'),
 'Z':('unknown','unknown','uncertain','评论为空，无法进行可靠语义判断。'),
 'Q':('unknown','unknown','uncertain','裸数量问句未说明价格或面积，住房线索保留，指标和本人找房动作均待核。'),
 'X':('discussion','unknown','unrelated','表达评价、建议或闲聊，没有本人新求租动作。'),
 'S':('supply','unknown','unrelated','提供房源、转租或住房服务，未表达本人新求租。'),
 'E':('demand','ended','unrelated','本人明确已解决或结束此次找房，没有提出后续求租。'),
 'R':('demand','historical','unrelated','回顾本人过去租房经历，没有表达当前新求租。'),
 'P':('demand','active_at_comment','unrelated','本人明确其他用途需求，不作为已确认住宅租赁线索。'),
 'K':('demand','unknown','uncertain','本人已有租住或找房经历，但当前是否需新住房不明，后续机会保留。'),
 'L':('demand','future','low','明确未来计划才找房，当前尚未推进，计划条件待核。'),
 'B':('mixed','active_at_comment','high','同时提供转租或合租机会并表达本人另找住房，供需条件分别保留。'),
}
J={}
def put(ids,code,topics='',slot=None,reason=None,**extra):
 for n in str(ids).split():
  key=f'D{int(n):04}'
  assert key not in J,key
  J[key]=dict(code=code,topics=topics,slot=slot,reason=reason,**extra)
def topic(pool,quote,polarity='ask',subject='own_demand',scope=None):
 return dict(pool=POOLS[int(pool)] if isinstance(pool,int) else pool,quote=quote,polarity=polarity,subject=subject,condition_scope=scope)
def region(text,relation='desired',quote=None,group='unknown',scope=None):
 return dict(text=text,quote=quote or text,relation=relation,group_relation=group,condition_scope=scope)
def tm(quote,role,verification,normalized=None):
 return dict(quote=quote,time_role=role,anchor_source='published_at_unix',anchor_time=None,normalized=normalized,verification=verification)
def render(page):
 d=json.loads((P/f'page-{page:02}.json').read_text(encoding='utf8'))
 for g in d['shared_post_context']:
  print('BODY',g['video'],g['post_body'])
  for c in g['comments']:
   print(c['key'],c['text'],json.dumps({k:c[k] for k in ('same_author','parent','source_conflict')},ensure_ascii=False))
def finish(page):
 src={x['review_key']:x for x in map(json.loads,(B/'shard-1.jsonl').read_text(encoding='utf8').splitlines())}
 data=json.loads((P/f'page-{page:02}.json').read_text(encoding='utf8'))
 cs=[c for g in data['shared_post_context'] for c in g['comments']]
 assert {c['key'] for c in cs}==set(J),(len(cs),len(J),set(c['key'] for c in cs)-set(J),set(J)-set(c['key'] for c in cs))
 out=[]
 for c in cs:
  j=J[c['key']]; s=src[c['key']]; txt=c['text']; role,state,interest,base=PROFILES[j['code']]
  ts=[topic(int(i),txt,subject='supply' if role=='supply' else 'own_demand',polarity='fact' if role=='supply' else 'ask') for i in j['topics'].split(',') if i!='']
  ts+=j.get('ts',[])
  times=j.get('times',[])
  for t in times:
   if t['anchor_source']=='published_at_unix':
    from datetime import datetime,timezone
    t['anchor_time']=datetime.fromtimestamp(s['published_at_unix'],timezone.utc).isoformat() if s.get('published_at_unix') else None
    if t['anchor_time'] is None:t['anchor_source']='无可信发表时间'
  slot=j['slot']; generic=j.get('generic',role in ('demand','mixed') and interest not in ('unrelated','uncertain','low','very_low'))
  missing=[]
  if slot is not None:missing.append(MOTHERS[slot]['required_facts'])
  if generic and slot!=1:missing.append(MOTHERS[1]['required_facts'])
  missing+=j.get('missing',[])
  reviews=j.get('review',[])
  if j['code'] in ('M','U','Q'):reviews=['本人是否正在找住宅及所询对象待核']+reviews
  if j['code']=='Q':reviews+=['多少或多少米的价格/面积指标未明']
  if j['code']=='T':reviews+=['仅艾特的具体目的、需求主体未明']
  if j['code']=='Z':reviews+=['缺评论可读原文']
  if role in ('demand','mixed') and interest!='unrelated':reviews+=['仅判评论时意向；当前需求、可租状态及方隅同店适配未核']
  possible=j.get('possible',[])
  if j['code']=='Q':possible=[dict(candidate_pools=[POOLS[0],POOLS[2]],quote=txt,ambiguity='未指明金额或面积，不计入确定主题')]+possible
  r={k:s[k] for k in ('review_key','comment_id','customer_uid','video_id','platform')}
  r.update(role=role,demand_state=state,interest=interest,topics=ts,target_regions=j.get('regions',[]),time_mentions=times,other_constraints=j.get('other',[]),possible_topics=possible,evidence=[txt] if txt else [],reason=j.get('reason') or base,context_used=['own','body']+(['parent'] if c['parent'] is not None else []),needs_review=list(dict.fromkeys(reviews)),contact_boundaries=j.get('boundaries',[]),context_flags={'post_author_same_as_commenter':c['same_author'],'source_version_conflict':c['source_conflict'],'comment_published_at':c['published_at'],'deeper_replies_read':s.get('deeper_replies_read',False)},reply_plan=dict(preferred_mother_slot=slot,generic_intro_suitable=generic,tone=j.get('tone','normal'),missing_facts=list(dict.fromkeys(missing)),caution=j.get('caution',[])+(['通用介绍不代表报价、房态、条件满足或当前有效；未授权发送'] if generic else []),contact_policy=j.get('policy','allow')),human_confirmed=False,send_authorized=False,store_assignment=None)
  for field in ('topics','target_regions','time_mentions','other_constraints','possible_topics','contact_boundaries'):
   for item in r[field]:
    if isinstance(item,dict) and item.get('quote') is not None:assert item['quote'] in txt or (c['same_author'] and item['quote'] in s['post_body']),(c['key'],field,item['quote'])
  out.append(r)
 (P/f'decisions-{page:02}.json').write_text(json.dumps(J,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
 (P/f'reviewed-{page:02}.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in out),encoding='utf8')
 pages=sorted(P.glob('reviewed-??.jsonl'))
 progress={'shard':1,'batch':B.name,'completed_pages':[p.stem[-2:] for p in pages],'completed_rows':sum(len(p.read_text(encoding='utf8').splitlines()) for p in pages),'total_rows':1460,'status':'in_progress','usage':'unknown','human_confirmed':False,'send_authorized':False}
 (P/'progress.json').write_text(json.dumps(progress,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
 print(json.dumps({'page':page,'rows':len(out),'roles':dict(collections.Counter(r['role'] for r in out)),'progress':progress['completed_rows']},ensure_ascii=False))
if __name__=='__main__':render(int(sys.argv[1]))
