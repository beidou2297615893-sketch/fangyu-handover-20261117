import json,pathlib,hashlib,collections,re,datetime,copy
O=pathlib.Path('work/fangyu-text-business-20261029/pool-mother-review/legacy-short-preview').resolve();W=O.parents[1];P=W/'pool-mother-review/legacy-local-planning'
def sha(p):
 h=hashlib.sha256()
 with pathlib.Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def load(p):return json.loads(pathlib.Path(p).read_text(encoding='utf8'))
def jl(p):
 with pathlib.Path(p).open(encoding='utf8') as f:
  for l in f:
   if l.strip():yield json.loads(l)
def put(p,x):pathlib.Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
def putjl(p,rs):
 with pathlib.Path(p).open('w',encoding='utf8',newline='\n') as f:
  for x in rs:f.write(json.dumps(x,ensure_ascii=False,separators=(',',':'))+'\n')
v1=load(O/'preview-validation.json'); original_files=['build_preview.py','rendered-preview.jsonl','qa-holdout-200.jsonl','qa-shared-contexts.json','qa-negative-boundaries.jsonl','manifest.json','preview-validation.json','report.md']; pre={str((O/n).resolve()):sha(O/n) for n in original_files};assert all(pre[str((O/n).resolve())]==h for n,h in v1['source_outputs_sha256'].items())
first_manifest=load(O/'manifest.json'); protected=first_manifest['input_expected_sha256']; initial={p:sha(p) for p in protected};assert initial==protected
cur=load(W/'region-brand-routing/current.json'); old=list(jl(O/'rendered-preview.jsonl')); rep=list(jl(P/'representative-review.jsonl'));repkeys={(r['platform'],str(r['cid']),str(r['uid'])) for r in rep};assert len(old)==4419 and len(repkeys)==66
sources={}
keys={(r['platform'],r['cid'],r['uid']) for r in old}
for platform,path in cur['results'].items():
 for r in jl(path):
  k=(platform,str(r['comment_id']),str(r['customer_uid']))
  if k in keys:sources[k]=r
assert set(sources)==keys
v2=[]
for r in old:
 x=copy.deepcopy(r); z=x['rendered']; policy=x.get('original_contact_policy');plan_policy=x.get('original_reply_plan_contact_policy');poli=x.get('planned_original_contact_policy');bound=x.get('original_contact_boundaries') or []
 explicit_no=any(p=='no_contact' for p in (policy,plan_policy,poli))
 role_ok=x['original_role']=='demand' and x['original_demand_state']=='active_at_comment' and x['original_interest'] in ('medium','high','super_high')
 valid=bool(z and z.get('validated_plan_text') and not x['validation_errors'])
 plan_ok=bool(x['local_plan'].get('family') and not x.get('source_version_conflict'))
 eligibility=valid and role_ok and plan_ok and not explicit_no
 contact_missing=not policy and not plan_policy and not poli or any(p=='unknown' for p in (policy,plan_policy,poli))
 x.update(text_rendering_valid=valid,draft_text_preview=z['validated_plan_text'] if eligibility else None,contact_review_required=bool(contact_missing or bound or explicit_no or x['effective_renderer_contact_policy'] in ('unknown','manual_review','identity_restricted','manual')),contact_eligible='not_assessed',send_authorized=False,preview_only=True,preview_eligibility={'role_state_interest_match':role_ok,'existing_bound_plan_and_no_source_conflict':plan_ok,'explicit_no_contact':explicit_no,'literal_renderer_valid':valid,'semantic_fit_independent_review_pending':True},admin_preview_note='文字预览仅供语义审核；不改变原渲染器text与held状态，不作为可联系或可发送结论')
 v2.append(x)
putjl(O/'rendered-preview-v2.jsonl',v2)
usable=[x for x in v2 if x['draft_text_preview'] and (x['platform'],x['cid'],x['uid']) not in repkeys]
def features(x):
 p=x['local_plan'];t=x['comment'];topics=p['source_field_evidence'].get('topics') or [];fs=['family:'+p['family']]
 if len(topics)>=2:fs.append('multi_pool')
 if re.search(r'不|别|不要|不能|拒绝|无|没',t):fs.append('negation_marker')
 if re.search(r'水电|燃气|费用|押金|押付|包|含',t):fs.append('fee_scope_marker')
 if any(q.get('relation')=='work' for q in p['source_field_evidence'].get('target_regions') or []):fs.append('workplace_existing_label')
 if re.search(r'我|我们|本人|咱',t):fs.append('first_person_marker')
 return fs
for x in usable:x['_features']=features(x)
def select(candidates,n,used_uid=None):
 used_uid=set(used_uid or [])
 counts=collections.Counter(f for x in candidates for f in x['_features']); order=sorted(counts,key=lambda f:(counts[f],f)); key=lambda x:hashlib.sha256((x['platform']+'|'+x['cid']+'|'+x['uid']).encode()).hexdigest(); buckets={f:sorted((x for x in candidates if f in x['_features']),key=key) for f in order}; chosen=[];seen=set();i={f:0 for f in order}
 while len(chosen)<n:
  added=False
  for f in order:
   b=buckets[f];j=i[f]
   while j<len(b) and (b[j]['cid'] in seen or b[j]['uid'] in used_uid):j+=1
   i[f]=j+1
   if j<len(b):chosen.append(b[j]);seen.add(b[j]['cid']);used_uid.add(b[j]['uid']);added=True
   if len(chosen)>=n:break
  if not added:break
 return chosen
chosen=select([x for x in usable if x['platform']=='douyin'],160)
chosen+=select([x for x in usable if x['platform']=='xiaohongshu'],40,{x['uid'] for x in chosen})
assert len(chosen)==200 and len({x['cid'] for x in chosen})==200 and len({x['uid'] for x in chosen})==200
contexts={};qa=[]
for x in chosen:
 r=sources[(x['platform'],x['cid'],x['uid'])];s=r.get('source_record') or {};raw=r.get('original_raw_record') or {};cls=s.get('classification') if isinstance(s.get('classification'),dict) else s; pid=str(s.get('video_id') or s.get('note_id') or r.get('video_id') or r.get('note_id') or 'unknown:'+x['cid']);key=x['platform']+':'+pid
 c={'platform':x['platform'],'post_id':pid,'post_body':s.get('post_body') or raw.get('post_text') or None,'post_title':s.get('post_title') or raw.get('post_title') or None,'post_author_same_as_commenter':s.get('post_author_same_as_commenter'),'source_missing_context':raw.get('missing_context'),'source':'本地原记录；不把帖子、IP或门店推定为客户需求'}
 if key in contexts and contexts[key]!=c:key+=':comment:'+x['cid']
 contexts[key]=c; missing=[]
 for z in [r.get('original_reply_missing_facts'),(r.get('reply_plan') or {}).get('missing_facts'),s.get('reply_missing_facts'),(s.get('reply_plan') or {}).get('missing_facts')]:
  for item in z or []:
   if item not in missing:missing.append(item)
 qa.append({'platform':x['platform'],'cid':x['cid'],'uid':x['uid'],'source_comment_sha256':x['source_comment_sha256'],'source_container_sha256':x['source_container_sha256'],'comment':x['comment'],'context_key':key,'direct_parent_text':s.get('direct_parent_text') or raw.get('parent_text') or None,'original_classification':{'role':x['original_role'],'state':x['original_demand_state'],'interest':x['original_interest'],'topics':cls.get('topic_evidence',cls.get('actual_pools',cls.get('topics'))),'target_regions':r.get('target_regions'),'time_mentions':r.get('time_mentions'),'other_constraints':cls.get('other_constraints'),'contact_policy':x['original_contact_policy'],'reply_plan_contact_policy':x['original_reply_plan_contact_policy'],'planned_original_contact_policy':x['planned_original_contact_policy'],'contact_boundaries':x['original_contact_boundaries'],'needs_review':cls.get('needs_review'),'reason':cls.get('reason')},'original_selection':x['original_selection'],'plan':x['local_plan'],'renderer_status':x['rendered']['status'],'renderer_text':x['rendered']['text'],'text_rendering_valid':x['text_rendering_valid'],'draft_text_preview':x['draft_text_preview'],'contact_review_required':x['contact_review_required'],'contact_eligible':'not_assessed','fact_gaps_from_existing_reply_fields':missing,'existing_source_review_reasons':r.get('review_reasons'),'sample_features':x['_features'],'send_authorized':False,'human_confirmed':False})
putjl(O/'qa-holdout-200-v2.jsonl',qa);put(O/'qa-shared-contexts-v2.json',contexts)
neg=list(jl(O/'qa-negative-boundaries.jsonl'))
for n in neg:
 genuine=[t for t in n['boundary_types'] if t!='contact_unknown_or_missing'];assert genuine
 n['expectation_reason']='原角色或需求状态：'+', '.join(genuine)+'；联系缺失单独待核，不单独作为不能预览的理由'
putjl(O/'qa-negative-boundaries-v2.jsonl',neg)
assert len(neg)==30
post={p:sha(p) for p in protected};postv1={p:sha(p) for p in pre};assert post==initial and postv1==pre
counts=collections.Counter(x['platform'] for x in qa); statuses=collections.Counter(x['renderer_status'] for x in qa);features_count=collections.Counter(f for x in qa for f in x['sample_features']); assert counts=={'douyin':160,'xiaohongshu':40}
outputs={n:sha(O/n) for n in ('rendered-preview-v2.jsonl','qa-holdout-200-v2.jsonl','qa-shared-contexts-v2.json','qa-negative-boundaries-v2.jsonl')}
m={'created_at':datetime.datetime.now().astimezone().isoformat(),'inputs_sha256_before':initial,'inputs_sha256_after':post,'v1_files_sha256_before':pre,'v1_files_sha256_after':postv1,'outputs_sha256':outputs,'rule':'管理员文案预览不是联系资格或发送授权；保留原 renderer text/status 和原策略，unknown仍需联系核验','semantic_review':'pending_independent_sol_high','platform_calls':0,'source_writes':0,'send_authorized':False}
put(O/'manifest-v2.json',m)
summary={'bound':len(v2),'draft_text_preview_count':sum(bool(x['draft_text_preview']) for x in v2),'render_status':dict(collections.Counter(x['rendered']['status'] if x['rendered'] else 'error' for x in v2)),'contact_review_required_count':sum(x['contact_review_required'] for x in v2),'qa_count':len(qa),'qa_platforms':dict(counts),'qa_render_status':dict(statuses),'qa_features_overlapping':dict(features_count),'negative_count':len(neg),'contact_unknown_only_negative':sum(all(t=='contact_unknown_or_missing' for t in n['boundary_types']) for n in neg),'original_v1_unchanged':postv1==pre,'input_source_unchanged':post==initial,'qa_unique_cid_uid':True,'representative_overlap':0,'context_keys_valid':all(x['context_key'] in contexts for x in qa),'send_authorized':False,'fit_accepted':False,'sample_not_random_accuracy_estimate':True}
put(O/'preview-validation-v2.json',summary)
(O/'report-v2.md').write_text('# 管理员文案预览与独立审核包 v2\n\n本包仅用于审核文字。已绑定计划中可展示文案 '+str(summary['draft_text_preview_count'])+' 条；原渲染器状态、正文和联系策略不变，联系缺失仍待核。文案字面可渲染、可联系、发送授权是不同状态；没有授权发送。\n\n独立审核包 200 条：抖音160、小红书40，均未出现在原66条已审样本。按稀有家族与多个池、否定、费用、工作地和第一人称标记分层，非随机抽样，不能推断总体准确率。\n\n另附30条真实阴性边界；联系缺失本身不作为不能预览理由。事实缺口和共享上下文原样带入，不从IP或来源门店推断客户要求。独立审核尚未完成。\n\n源文件及原版预览哈希核对一致；未发送、改源或更新指针。\n',encoding='utf8')
print(json.dumps(summary,ensure_ascii=True))
