"""Review-only probes. Imports frozen code and uses synthetic temporary fixtures."""
import copy
import importlib.util
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
WORK = HERE.parent
spec = importlib.util.spec_from_file_location('review_fixture', WORK / 'test_mother_adapter.py')
fixture = importlib.util.module_from_spec(spec)
spec.loader.exec_module(fixture)
a = fixture.adapter()
mothers = json.loads((WORK / 'mothers/first50.json').read_text(encoding='utf8'))
results = {}

x = fixture.row()
x['reply_plan'].update(preferred_mother_slot=28, missing_facts=['账号有真实对接权限，门店可看，不表示预约已确认'])
a.select_reply(x, mothers)
results['fallback_actual_template_facts'] = {k: x[k] for k in ('mother_slot','mother_reply_text','reply_missing_facts','send_authorized','can_send_now')}
results['fallback_actual_template_facts']['actual_generic_required_facts_present'] = mothers[0]['required_facts'] in x['reply_missing_facts']

original_dumps = fixture.json.dumps
original_run = fixture.subprocess.run
def without_new_plan(value, *args, **kwargs):
    if isinstance(value, dict) and value.get('review_key') == 'D0001' and 'reply_plan' in value:
        value = dict(value)
        value.pop('reply_plan')
    return original_dumps(value, *args, **kwargs)
def inspect_temp_process(args, *pos, **kwargs):
    proc = original_run(args, *pos, **kwargs)
    inc = Path(args[1]).parent / 'douyin-registered-v2/increments' / args[2]
    rows = [json.loads(line) for line in (inc/'classified-snapshot.jsonl').read_text(encoding='utf8').splitlines()]
    new = next(row for row in rows if row['comment_id'] == '2')
    results['new_missing_plan_publisher'] = {'exit_code':proc.returncode,'published':True,'new_reply_plan_present':'reply_plan' in new,'registration_state':new['registration_state'],'review_method':new['review_method'],'mother_reply_text':new['mother_reply_text']}
    return proc
try:
    fixture.json.dumps = without_new_plan
    fixture.subprocess.run = inspect_temp_process
    fixture.PublisherIntegrationTests('test_isolated_publisher_preserves_old_and_reviews_source_account').test_isolated_publisher_preserves_old_and_reviews_source_account()
finally:
    fixture.json.dumps = original_dumps
    fixture.subprocess.run = original_run

unknown = fixture.row()
unknown['reply_plan']['contact_policy'] = 'unknown'
a.select_reply(unknown, mothers)
results['unknown_contact_is_draft_not_sendable'] = {k:unknown[k] for k in ('effective_contact_policy','contact_manual_review','mother_reply_text','send_authorized','can_send_now')}
results['human_export_omits_review_fields'] = [field for field in ['reply_missing_facts','contact_boundaries','contact_manual_review','timeline_review','account_trace_review','reply_status','reply_scope'] if field not in (WORK/'publish_douyin_increment_snapshot.py').read_text(encoding='utf8').split('detail=[];',1)[1]]

(HERE/'independent-review-probes.json').write_text(original_dumps(results,ensure_ascii=False,indent=2),encoding='utf8')
print(original_dumps(results,ensure_ascii=False,indent=2))
