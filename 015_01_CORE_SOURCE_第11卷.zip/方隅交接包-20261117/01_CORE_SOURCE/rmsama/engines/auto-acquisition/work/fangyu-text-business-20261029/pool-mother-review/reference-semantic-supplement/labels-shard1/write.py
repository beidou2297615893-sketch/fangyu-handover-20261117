import json,pathlib,sys,hashlib
D=pathlib.Path(__file__).resolve().parent.parent;O=D/'labels-shard1'
r=[json.loads(l) for l in (D/'shard1.jsonl').read_text(encoding='utf-8').splitlines()]
c=json.loads((D/'shared-contexts.json').read_text(encoding='utf-8'))
# These declarations are authored individually by the model. This script only expands format, copies identifiers, verifies quotations and writes files.
existing={x['cid']:x for x in [json.loads(l) for l in (O/'labels.jsonl').read_text(encoding='utf-8').splitlines()]} if (O/'labels.jsonl').exists() else {}
for s in json.loads(sys.stdin.read()):
 i=s.pop('i');x=r[i];ctx=c['posts'][x['context_key']]['content']; src={'comment':x['comment'],'post_title':ctx.get('post_title') or '', 'post_body':ctx.get('post_body') or '', 'direct_parent':''}
 z={k:x[k] for k in ['platform','cid','uid','source_comment_sha256']}
 # No semantic inference: all relation values and quotes come from per-row authored declarations.
 z.update(s);z.setdefault('reference_mentions',[]);z.setdefault('place_relation',[]);z.setdefault('price_relation',[]);z.setdefault('time_relation',[])
 z.setdefault('brand_source_relation','unknown');z.setdefault('contact_action_direction','no_contact_action')
 z.setdefault('unresolved_or_missing',[]);z['unresolved_or_missing'] += ['direct_parent: unknown（父评未提供）']
 if z['brand_source_relation']=='unknown':z['unresolved_or_missing'].append('brand/source: unknown（现有文本未明确房源品牌或供应归属）')
 for e in z['evidence']:assert e['quote'] and e['quote'] in src[e['source']],(i,e)
 for a in z['reference_mentions']:
  assert a['span'] in x['comment'],(i,a)
  for e in a['evidence']:assert e['quote'] and e['quote'] in src[e['source']],(i,e)
 for f in ['price_relation','place_relation','time_relation']:
  for a in z[f]:assert a['quote'] in src[a['source']] and a['quote'],(i,f,a)
 existing[x['cid']]=z
out=[existing[x['cid']] for x in r if x['cid'] in existing]
(O/'labels.jsonl').write_text(''.join(json.dumps(x,ensure_ascii=False,separators=(',',':'))+'\n' for x in out),encoding='utf-8')
(O/'progress.json').write_text(json.dumps({'status':'semantic_supplement_in_progress','records_written':len(out),'expected':len(r),'actual_usage':'unknown','method':'model_per_record_semantic_judgment; deterministic_io_validation_only'},ensure_ascii=False,indent=2),encoding='utf-8')
print('written',len(out))
