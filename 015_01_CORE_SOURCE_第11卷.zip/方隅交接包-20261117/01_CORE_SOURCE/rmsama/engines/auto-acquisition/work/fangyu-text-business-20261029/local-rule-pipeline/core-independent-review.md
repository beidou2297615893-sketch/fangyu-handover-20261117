# 方隅本地规则核心独立审查

结论：**暂不通过正式接续门槛**。未发现 Critical；发现 6 类 Important 业务语义问题。它们会把他人的条件、已停止的旧需求或明确排除条件写成已确认需求，或丢失明确的新需求；现有实现没有把这些案例留为疑难，部分直接生成本地母句候选。无需把普通评论逐条交模型，修复应优先建立主体、时间和条件范围的确定性隔离，无法确定的小部分保留具体待核原因。

审查范围为 SPEC.md、PLAN.md、local_classifier.py、rule_config.json、core-implementation-report.json 以及《全部评论意向判断规则.md》。未读取 holdout、未重跑已有 46 自测/52 独立案例/200 历史对照/压测，未改源码、配置、原测试、manifest、源数据库或其他业务文件。实际调用本地 Python 运行自有 25 条合成分类探针和 3 条母句输入探针；没有网络、模型或平台调用。公开输入见 `core-review-probes.py`；当时完整输出写入 `core-review-probe-results.json`，该默认文件后被后续复现更新，fix1 实测摘要以本报告为准，具体更正见下。复现脚本已添加 `--output` 参数，后续审查用独立版本文件。定向反例不能用于计算真实准确率。

审查冻结版本：

- local_classifier.py SHA256：`1e93e72e3cabaea3bfe1ca1978c97e334e03d737e469d8aebd14803549157ce9`
- rule_config.json SHA256：`11769d9c4fd1758c01e104d53555e785c25eb04ab8da077ee5b2e68338d912ae`

并发状态说明：fix1 原证据于本地时间 22:54:47 写出，当时内部两项 SHA 与上述冻结版一致，输出 rule_version 为 `fangyu-local-rules-20261029-v1-fix1`。收尾时发现实现于 22:56:15 被其他工作变更为 core `0c1c136c76f634dc3a6d10479658b16e2610aafeed5bb635713981283de026ec`、config `9691ac8a25bd5cecd5a8f04596f3df292b5494290c7d84461eb08ce23ccefcdb`。本报告的源码行号、反例结果和暂不通过结论**仅针对上述已取证的 fix1**；本审查没有修改实现。

后续记录更正：原作者为复现公开案例运行本脚本，默认 `core-review-probe-results.json` 先后更新为 fix2/fix3 结果，因此 **fix1 原 JSON 未另存，不能声称其字节仍保留**；本报告 fix1 实测摘要保留，默认 JSON 当前版本以其内部 SHA 为准。根任务已归档后续各轮材料至 `review-archive/fix2`、`review-archive/fix3`。定向复审将使用独立文件 `core-review-probe-fix3-results.json`，不会再次覆盖默认 JSON 或归档。

## Important 1：过滤他人证据发生在需求成立之后，且主体被整段统一赋值

位置：local_classifier.py **120–138、153–158、192–212**；其中 131 行先把任何人的找房表达变成 demand，158 行之后才剔除部分第三人句，112–113 行又只按全文是否有“帮/替”统一确定所有条件主体。

复现（默认正文均为“房东直租，两室公寓出租，可租。”）：

- `other_person_only`：“朋友正在找两室，我只是围观” → `role=demand, interest=medium, topics=[], exception_type=null, draft_ready=true`。已经找不到有效的本人需求证据，仍按 medium 备稿；这是明确围观，不应成为本人需求。
- `other_person_budget`：“朋友正在找两室，预算3000，他想住古北；我现在不找房” → `high`，且“预算3000”被写为 `subject=own_demand`，无待核，并备稿。跨分句未延续朋友主体。
- `explicit_two_subjects`：“帮妈妈找两室，我自己的预算是5000” → “我自己的预算是5000”被写为 `subject=other_person`。明确自/他条件被合并给受益人。

建议：需求角色成立和条件归属使用同一套分段主体结果；第三人背景不建立评论者需求；明确代找保留受益人，遇到主体切换分别保留，不能只靠全文 beneficiary 一次赋值。无法确定条件归属时放候选/疑难，不以 high+无异常输出。

## Important 2：同作者旧正文会重新激活已停止需求，并把旧条件无冲突合并到新需求

位置：local_classifier.py **93–109、120–146、153–158**，rule_config.json 的 `ended`/`future_search`。第 109 行计算的 `future` 没有参与状态决策；当前停止找房若未命中较窄 ended 格式，就无法压过正文 demand。正文历史分句的后续预算/地区也未继承历史范围。

复现（`post_author_same_as_commenter=true`）：

- `own_older_body_current_stop`：评论“现在不找房了”；正文“正在找两室，预算3000，想住古北” → `active_at_comment/high`，保留正文预算和古北 target，`exception_type=null` 并备稿。当前评论明确停止推进，不能继续用旧正文激活。
- `own_older_body_current_supersedes`：评论“现在求租一室，预算2000，想住虹桥”；正文“之前正在找两室，预算5000，想住古北” → 新旧预算 2000/5000 并存为确认条件，古北和虹桥均 target，未标冲突。即使“之前正在找两室”被 past_clause 剔除，后两句仍被当当前条件。

对照 `own_older_body_ended`：“我已经租好了”可正确压过正文；问题不是完全缺乏评论优先机制，而是停止格式和范围传播不完整。建议先识别当前评论与旧正文的时态/冲突关系，再提取确认条件；同作者不是同时间，正文冲突可保留原话但不合并成当前需求。

## Important 3：否定的供给仍能判成 supply，同句混合供需会被整句 is_supply 吞掉

位置：local_classifier.py **23–26、103–106、119–130、145**；rule_config.json `supply` 无否定作用域。

- `negated_supply`：“不是本人出租，帮朋友问一下还有吗” → `supply/unrelated, exception_type=null`。字面“本人出租”命中就把明确否定供给当真实供给，出租语境中的有效询盘被屏蔽。应保留代找询盘，或主体/对象不足时待核，不能确认为供给删除。
- `mixed_natural_no_punct`：“我转租单间同时想找两室” → `supply/unrelated`，明确新找房条件全部丢失。`mixed_no_punct`“我转租单间但想租两室”同样失败。
- 对照 `mixed_explicit_subject_no_punct`“我转租单间但我想找两室”成功 mixed，证明只有内置的少数切句起点生效；“但/同时”省略重复主语是正常表达，不应依赖必须再写一次“我”。

建议在供给谓词匹配前处理否定范围；同句供给和新需求按谓词及连接关系分别建段。无法安全切分时 retained mixed/semantic_review，比定为 unrelated 更符合既定边界。

## Important 4：整分句共享 polarity 会反写同句不同主题的肯定/否定

位置：local_classifier.py **70–85、187–194**。

`condition_polarity`：“求租两室，不要独卫但必须有电梯” → 房内设施 `reject`，楼层电梯也 `reject`，未标疑难。实际是拒绝独卫、必须电梯。原引文虽然保留完整，但机器确认标签已经与原话相反，后续按 polarity 选店或过滤会出错。

建议按条件谓词/转折范围给各池建立 polarity，不能把 `_polarity(clause)` 复制给所有池；若实现暂不能解析多个条件，则原引文保留、池可留候选并标局部语义复核，不能输出错误的确定排除。

## Important 5：地区提及默认 target，常见排除表达会被反写为可接受/目标

位置：local_classifier.py **196–208**，特别是 **205** 行；询问关系和泛排除范围未处理。

- `condition_region`：“求租两室，除了古北都可以” → 古北 `acceptable`，实际明确排除古北。
- `condition_region_and`：“求租两室，古北不要，虹桥也不考虑” → 古北 excluded 正确，虹桥 `target` 错误。
- `region_question`：“正在找两室，古北在哪啊” → 古北 `target`。问地点不等于想住此地，应保留问位置而不确认 target。

这些案例均 `high`、无异常、可备稿。建议地区关系先确认存在求租/居住/接受/排除谓词；“除了…都…”、“也不…”按作用域处理；未明确居住关系的地点不要默认正向 target。工作地/IP/source 店的常规保护存在，本次 `workplace_same_clause` 和 `region_workplace_label` 对照正确，不能据此外推所有地区语义都安全。

## Important 6：历史失败约看会升级当前意向为 super_high

位置：local_classifier.py **137、244**；rule_config.json `past_clause` 只覆盖有限起点，appointment 不区分既往未成行。

`past_appointment_natural`：“我还在找两室，上次约周末看房没去成” → `super_high`、无异常、备稿。前半句只证明还在找；后半句明确描述上次未成行，不能变成这次明确约看请求。

建议约看超高只使用当前肯定请求范围；“上次/那次/已取消/没去成”等事件状态应阻止历史事件升级。仍可依据当前“两室”需求保留 high，无须整条交模型。

## 非阻断限制与已确认保护

- `choose_mother` 290 行阻断 ended/unknown/异常/非中高，293 行只选 user_approved slot1，302 行家庭语境去宝宝，286–289 行始终保留无发送授权。当前探针的通用母句逐字复用，没有自行填门店、价格或设施；分类器 276–277 行也固定 `assigned_store=null, current_need_verified=false, can_send_now=false`。
- 母句 guard（299 行）是有限词面过滤，不是事实证明。输入被标为 user_approved 的 slot1 若为“宝宝，方隅月租两千五，独卫阳台都有”或“宝宝，这样的方隅有，宠物随便养”，仍 `draft_ready=true`。这是接口信任边界/后续模板变更风险：本次冻结的通用版本不含这些事实，不能据此声称当前实际母句已编造；若对外承诺所有已认可版本都能防事实承诺，应固定已审通用版本/摘要或另设事实准入，不能仅扩大黑名单后宣称通用保障。
- 当前办公用途探针正确保留需求角色但标 needs_context、不备稿；未来才开始找与未来入住对照正确；明确“我已经租好了”压过旧正文正确；不相关装修用语未仅因“房租”升高。没有发现导入网络/模型客户端或按来源店/IP直接 assigned_store 的代码。
- 部分纯缺上下文案例没有模型复核是合理的。上述重要问题属于资料已有而规则确定性输出相反结论；建议只对无法可靠解析的局部语义放复核，不改成逐条模型主链。

建议修复上述 Important 后，由独立验收方针对公开新反例复测，再决定正式接续；原历史模型只能作参考，不应据本报告、已有合成测试或压测宣称人工准确率。
