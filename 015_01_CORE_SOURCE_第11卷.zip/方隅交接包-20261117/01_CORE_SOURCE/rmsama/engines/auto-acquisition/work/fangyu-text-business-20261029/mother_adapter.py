"""Local, deterministic selection from approved mother sentences; no intent classification."""
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path
import sqlite3
import hashlib
import json


APPROVED_GENERIC_INTRO = '宝宝，我住方隅公寓这边，介绍有优惠的。'
REVIEW_METHOD_STAGES = {
    'ai_semantic_initial_and_detailed': ['initial_semantic', 'detailed_semantic'],
    'ai_independent_semantic_fine_review': ['initial_semantic', 'detailed_semantic', 'independent_semantic'],
}


def validate_new_review(row, batch, source_cache):
    """Validate only new AI reviews, before legacy normalization or any result write.

    The source is a recorded semantic result, not proof of another model call.
    Cache each batch-local file once; neither filenames nor method labels infer semantics.
    """
    key = row.get('review_key', '<missing review_key>')
    def require(ok, message):
        if not ok: raise ValueError(f'{key}: {message}')
    for field in ('review_key', 'comment_id', 'customer_uid', 'video_id', 'reason'):
        require(isinstance(row.get(field), str) and bool(row[field].strip()), f'invalid or missing {field}')
    require(row.get('role') in ('demand','supply','mixed','unknown','discussion'), 'invalid role')
    require(row.get('demand_state') in ('active_at_comment','future','ended','historical','unknown'), 'invalid demand_state')
    level = row.get('interest_at_comment', row.get('interest'))
    require(level in ('super_high','high','medium','low','very_low','uncertain','unrelated'), 'invalid interest')
    for field in ('topics','target_regions','time_mentions','other_constraints','possible_topics','evidence','context_used','contact_boundaries'):
        require(isinstance(row.get(field), list), f'invalid or missing {field}')
    for field in ('evidence','context_used'):
        require(all(isinstance(v,str) for v in row[field]), f'invalid {field} item')
    for topic in row['topics'] + row.get('topic_evidence',[]):
        if isinstance(topic,str): continue  # original normalized contract
        require(isinstance(topic,dict) and {'pool','quote','polarity','subject','condition_scope'} <= set(topic), 'incomplete topic')
        require(all(isinstance(topic[f],str) for f in ('pool','quote','polarity','subject')) and (topic['condition_scope'] is None or isinstance(topic['condition_scope'],str)), 'invalid topic fields')
        require(topic['polarity'] in ('ask','require','prefer','reject','accept','conditional','fact','not_required','compare','unknown') and topic['subject'] in ('own_demand','supply','current_home','other_person','unresolved'), 'invalid topic enum')
    for region in row['target_regions']:
        require(isinstance(region,dict) and {'text','quote','relation','group_relation','condition_scope'} <= set(region), 'incomplete target region')
        require(all(isinstance(region[f],str) for f in ('text','quote','relation','group_relation')) and (region['condition_scope'] is None or isinstance(region['condition_scope'],str)), 'invalid target region fields')
        require(region['relation'] in ('desired','preferred','accepted','excluded','work','current_home','offered','unresolved') and region['group_relation'] in ('AND','OR','unknown'), 'invalid target region enum')
    for time in row['time_mentions']:
        require(isinstance(time,dict) and {'quote','time_role','anchor_source','anchor_time','normalized','verification'} <= set(time), 'incomplete time mention')
        require(all(isinstance(time[f],str) for f in ('quote','time_role','anchor_source','verification')) and all(time[f] is None or isinstance(time[f],str) for f in ('anchor_time','normalized')), 'invalid time mention fields')
        require(time['time_role'] in ('move_in','viewing','lease_duration','search_start','other'), 'invalid time role')
    for constraint in row['other_constraints']:
        require(isinstance(constraint,dict) and isinstance(constraint.get('quote'),str) and any(isinstance(constraint.get(f),str) for f in ('detail','meaning','description')), 'incomplete other constraint')
    for possible in row['possible_topics']:
        require(isinstance(possible,dict) and isinstance(possible.get('ambiguity'),str) and any(isinstance(possible.get(f),(str,list)) and bool(possible[f]) for f in ('pool','pools','candidate_pools')), 'incomplete possible topic')
    for boundary in row['contact_boundaries']:
        require(isinstance(boundary,str) and bool(boundary.strip()) or isinstance(boundary,dict) and all(isinstance(boundary.get(f),str) and bool(boundary[f].strip()) for f in ('quote','scope')), 'incomplete contact boundary')
    reviews = row.get('review_reasons', row.get('needs_review'))
    require(isinstance(reviews,list) and all(isinstance(v,str) for v in reviews), 'invalid or missing review reasons')
    require(isinstance(row.get('context_flags'), (dict,list)), 'invalid or missing context_flags')
    require(row.get('human_confirmed') is False and row.get('send_authorized') is False, 'invalid confirmation or authorization')
    require(('assigned_store' in row or 'store_assignment' in row) and row.get('assigned_store',row.get('store_assignment')) is None, 'unverified store assignment')
    plan = row.get('reply_plan')
    require(isinstance(plan,dict), 'reply_plan must be a complete object')
    require({'preferred_mother_slot','generic_intro_suitable','tone','missing_facts','caution'} <= set(plan), 'reply_plan missing required fields')
    require(type(plan['generic_intro_suitable']) is bool and plan['tone'] in ('normal','serious'), 'invalid reply_plan suitability or tone')
    slot = plan['preferred_mother_slot']
    require(slot is None or type(slot) is int and slot > 0, 'invalid preferred mother slot')
    for field in ('missing_facts','caution'):
        require(isinstance(plan[field],list) and all(isinstance(v,str) and bool(v.strip()) for v in plan[field]), f'invalid reply_plan {field}')
    require(plan.get('contact_policy') in (None,'allow','identity_restricted','no_contact','unknown'), 'invalid contact_policy')
    method = row.get('classification_method')
    require(method in REVIEW_METHOD_STAGES, 'missing or invalid classification_method')
    require(row.get('classification_stages_completed') == REVIEW_METHOD_STAGES[method], 'incomplete classification stages')
    source = row.get('classification_review_source')
    require(isinstance(source,dict) and isinstance(source.get('path'),str) and isinstance(source.get('sha256'),str), 'missing classification review source')
    path = Path(source['path'])
    path = (path if path.is_absolute() else Path(batch)/path).resolve()
    require(path.is_relative_to(Path(batch).resolve()), 'review source must be inside frozen batch')
    require(len(source['sha256']) == 64 and all(c in '0123456789abcdef' for c in source['sha256']), 'invalid review source sha256')
    if path not in source_cache:
        try:
            raw = path.read_bytes()
            records = [json.loads(line) for line in raw.decode('utf8').splitlines() if line.strip()]
            index = {(r['review_key'],r['comment_id']):r for r in records}
            require(len(index) == len(records), 'duplicate review source identity')
            source_cache[path] = (hashlib.sha256(raw).hexdigest(), index)
        except (OSError, UnicodeError, json.JSONDecodeError, KeyError, TypeError) as exc:
            raise ValueError(f'{key}: invalid classification review source') from exc
    digest, index = source_cache[path]
    require(digest == source['sha256'], 'review source sha256 mismatch')
    actual = index.get((row['review_key'],row['comment_id']))
    require(actual is not None, 'review source identity missing')
    # The transport pointer is the only field added after the semantic merge.
    require({k:v for k,v in row.items() if k != 'classification_review_source'} == actual, 'review source content or stage mismatch')


def select_reply(row, mothers):
    """Keep legacy decisions unchanged; select only the generic approved intro for new plans."""
    row['send_authorized'] = False
    row['can_send_now'] = False
    row.update(send_attempted=False, send_attempted_scope='text_processing_task_only',
               text_task_send_attempted=False, platform_delivery_state='not_checked_by_text_task')
    plan = row.get('reply_plan')
    if plan is None:
        return row
    row['reply_generation_model_calls'] = 0
    if not isinstance(plan, dict):
        raise ValueError('reply_plan must be an object')
    if type(plan.get('generic_intro_suitable')) is not bool or plan.get('tone') not in ('normal', 'serious'):
        raise ValueError('invalid reply_plan suitability or tone')
    if any(not isinstance(plan.get(k), list) for k in ('missing_facts', 'caution')):
        raise ValueError('reply_plan missing_facts and caution must be lists')
    slot = plan.get('preferred_mother_slot')
    if slot is not None and (type(slot) is not int or slot < 1):
        raise ValueError('invalid preferred mother slot')
    policy = plan.get('contact_policy')
    if policy is None:
        ai_reviewed = row.get('classification_method') in ('ai_semantic_initial_and_detailed', 'ai_independent_semantic_fine_review')
        policy = 'allow' if ai_reviewed and row.get('contact_boundaries') == [] else 'unknown'
    if policy not in ('allow', 'identity_restricted', 'no_contact', 'unknown'):
        raise ValueError('invalid structured contact policy')
    row['effective_contact_policy'] = policy
    by_slot = {m['slot']: m for m in mothers}
    preferred = by_slot.get(slot)
    generic = by_slot.get(1)
    missing = list(plan['missing_facts'])
    if slot != 1 and preferred:
        fact = preferred.get('required_facts')
        if fact and fact not in missing: missing.append(fact)
    if slot is not None and (not preferred or not preferred.get('user_approved')):
        missing.append('首选母句未获认可，不能直接使用')
    if row.get('contact_boundaries') or policy in ('identity_restricted', 'unknown'):
        row['contact_manual_review'] = True
    else:
        row['contact_manual_review'] = False
    eligible = (plan['generic_intro_suitable'] is True and row.get('role') in ('demand','mixed')
                and row.get('demand_state') in ('active_at_comment','future')
                and row.get('interest_at_comment') != 'unrelated'
                and not row.get('source_version_conflict',False) and policy != 'no_contact')
    if eligible and (not generic or not generic.get('user_approved') or generic.get('template') != APPROVED_GENERIC_INTRO
                     or not isinstance(generic.get('required_facts'),str) or not generic['required_facts'].strip()):
        raise ValueError('current approved generic mother slot 1 and explicit required facts are required')
    if eligible:
        missing.append(generic['required_facts'])
    missing = list(dict.fromkeys(missing))
    text = generic['template'] if eligible else None
    if text and plan['tone'] == 'serious': text = text.removeprefix('宝宝，')
    row.update(preferred_mother_slot=slot, mother_slot=1 if eligible else None,
               mother_reply_text=text, reply_kind='generic_intro' if eligible else None,
               reply_missing_facts=missing, reply_unanswered_specific_question=bool(eligible),
               reply_scope='通用介绍接话，不代表已回答具体问题或确认房源、费用及门店适配',
               reply_status='本地母句审核稿，未授权发送' if eligible else (
                   '明确拒绝联系，暂不生成' if policy == 'no_contact' else
                   '同评论来源版本冲突，暂不生成并待核' if row.get('source_version_conflict',False) else
                   'AI判定不适合通用介绍，暂不生成' if plan['generic_intro_suitable'] is False else
                   '需求状态或身份尚不适合接话，暂不生成'))
    return row


def human_review_lines(row):
    """Render review constraints as business language; machine provenance stays in JSON."""
    lines = []
    policy = row.get('effective_contact_policy')
    policy_text = {'identity_restricted':'对方限制联系者身份，需先核实是否符合要求',
                   'unknown':'联系意愿不明，需人工核实',
                   'no_contact':'对方明确拒绝联系，暂不生成新稿'}
    boundaries = []
    for item in row.get('contact_boundaries',[]):
        if isinstance(item,str): boundaries.append(item)
        elif isinstance(item,dict):
            boundaries.extend(item[k] for k in ('quote','scope') if isinstance(item.get(k),str) and item[k])
    contact = ([policy_text[policy]] if policy in policy_text else []) + boundaries
    if row.get('contact_manual_review') and not contact: contact.append('联系条件需人工核实')
    if contact: lines.append('联系限制：'+'；'.join(dict.fromkeys(contact)))
    missing = row.get('reply_missing_facts',[])
    if missing: lines.append('需要核实的推荐、优惠或房源条件：'+'；'.join(missing))
    caution = (row.get('reply_plan') or {}).get('caution',[])
    if caution: lines.append('接话提醒：'+'；'.join(caution))
    if row.get('reply_unanswered_specific_question'):
        lines.append('答复范围：具体问题尚未回答；'+row['reply_scope'])
    elif row.get('reply_scope'):
        lines.append('答复范围：'+row['reply_scope'])
    if row.get('timeline_review'): lines.append('时间线待核：'+row['timeline_review'])
    account_reviews = list(dict.fromkeys(o['account_trace_review'] for o in row.get('source_observations',[]) if o.get('account_trace_review')))
    if account_reviews: lines.append('来源账号待核：'+'；'.join(account_reviews)+'；采集账号与评论者分别记录')
    else: lines.append('来源账号：历史采集账号已留存；当前登录身份尚未核实，采集账号与评论者分别记录')
    lines.append('审核状态：'+row.get('reply_status','保留历史原稿及原决定，仍需人工审核'))
    if row.get('alternative_mother_reply_text'):
        lines.append('保留备选稿：'+row['alternative_mother_reply_text'])
    lines.append('发送状态：本窗口未发送；平台真实发送状态以发送账本为准。')
    return lines


def _time(value):
    if not isinstance(value, str): return None
    try:
        result = datetime.fromisoformat(value.replace('Z','+00:00'))
        return result.astimezone(timezone.utc) if result.tzinfo is not None else None
    except (ValueError, OverflowError): return None


def reconcile_customers(rows):
    groups = defaultdict(list)
    for row in rows:
        if row.get('platform') and row.get('customer_uid'):
            groups[(row['platform'],row['customer_uid'])].append(row)
    duplicates = 0
    rank = {'super_high':3,'high':2,'medium':1}
    for group in groups.values():
        endings = [r for r in group if r.get('demand_state') == 'ended' and r.get('role') in ('demand','mixed') and not r.get('source_version_conflict',False)]
        for row in group:
            if not row.get('mother_reply_text'): continue
            when = _time(row.get('published_at'))
            if any(when is None or _time(e.get('published_at')) is None for e in endings):
                row['timeline_review'] = '存在时间未明的结束信号，无法判断先后'
            if when is not None and any(_time(e.get('published_at')) is not None and _time(e.get('published_at')) > when for e in endings):
                row['alternative_mother_reply_text'] = row['mother_reply_text']
                row['mother_reply_text'] = None
                row['reply_status'] = '同平台客户有较晚结束信号，旧稿保留备选并待核'
                row['timeline_review'] = '较晚评论明确找房结束；当前状态仍待人工核实'
        candidates = [r for r in group if r.get('mother_reply_text')]
        candidates.sort(key=lambda r:(rank.get(r.get('interest_at_comment'),0), _time(r.get('published_at')) or datetime.min.replace(tzinfo=timezone.utc),str(r.get('comment_id',''))), reverse=True)
        for row in candidates[1:]:
            row['alternative_mother_reply_text'] = row['mother_reply_text']; row['mother_reply_text'] = None
            row['reply_status'] = '同平台客户其他评论已有候选，保留备选不重复入队'; duplicates += 1
    return duplicates


def open_source_readonly(path):
    db = sqlite3.connect(Path(path).resolve().as_uri() + '?mode=ro', uri=True)
    db.execute('PRAGMA query_only=ON')
    db.execute('BEGIN')
    return db


def enrich_observations(db, stable_key, observations):
    result = []
    for item in observations:
        out = dict(item)
        rows = db.execute("SELECT o.account_uid, CASE WHEN json_valid(a.spec) THEN json_extract(a.spec,'$.account_uid') END FROM observations o LEFT JOIN attempts a ON a.request_id=o.request_id WHERE o.request_id=? AND o.stable_key=? AND o.kind='comments'", (item.get('request_id'), stable_key)).fetchall()
        account = None
        if len(rows) == 1:
            observed, spec = rows[0]
            if isinstance(observed,str) and observed and (spec is None or spec == observed): account = observed
            elif observed in (None, '') and isinstance(spec,str) and spec: account = spec
        out['collection_account_uid'] = account
        if account is None: out['account_trace_review'] = '来源记录缺失、账号缺失或账号不一致，需核对'
        result.append(out)
    return result
