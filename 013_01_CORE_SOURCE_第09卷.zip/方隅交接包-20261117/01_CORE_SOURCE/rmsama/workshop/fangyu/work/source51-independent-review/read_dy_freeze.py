from pathlib import Path
import hashlib,json
HERE=Path(__file__).resolve().parent
ROOT=HERE.parent/'source51-dy-owner-downstream'
file=ROOT/'evidence/FROZEN.json';raw=file.read_bytes()
assert len(raw)==81390 and hashlib.sha256(raw).hexdigest().upper()=='03D999555B7CA29A5C5B1E6317D85D9E768BB1631755D5D557F310EE325FF430'
value=json.loads(raw)
print(json.dumps({'keys':list(value),'schema':value.get('schema'),'targets':value.get('targets'),
    'evidence':value.get('evidence'),'result':value.get('actual_result_path')},ensure_ascii=False,indent=2))
