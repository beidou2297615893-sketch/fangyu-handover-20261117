from pathlib import Path
import ast,hashlib,json
HERE=Path(__file__).resolve().parent;ROOT=HERE.parent/'source51-dy-owner-downstream'
FORMAL=HERE.parent/'app/src';APP=ROOT/'app/src'
def pin(path):
    raw=Path(path).read_bytes();return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest().upper()}
frozen=ROOT/'evidence/FROZEN.json'
assert pin(frozen)=={'bytes':81390,'sha256':'03D999555B7CA29A5C5B1E6317D85D9E768BB1631755D5D557F310EE325FF430'}
value=json.loads(frozen.read_bytes());verified=[]
def verify(path,expected,kind):
    actual=pin(path);assert actual==expected,(str(path),actual,expected)
    verified.append({'path':str(path),'kind':kind,'pin':actual})
for row in value['targets']:verify(row['candidate'],row['candidate_pin'],'six_frozen_business_source')
for row in value['parents_preserved']:
    verify(row['path'],row['pin'],'preserved_parent')
    verify(row['formal_current']['path'],row['formal_current']['pin'],'current_formal_before_Source50')
for row in value['actual_evidence']:verify(row['path'],row['pin'],'new_actual_evidence')
for row in value['carrier_files']:verify(row['path'],row['pin'],'new_story_carrier')
for key in ('diff','readme'):verify(value[key]['path'],value[key]['pin'],key)
proposal=value['entry_proposal']
verify(proposal['candidate'],proposal['candidate_pin'],'entry_proposal_not_installed')
for key in ('parent_file','diff'):verify(proposal[key]['path'],proposal[key]['pin'],'entry_'+key)
old=Path(proposal['parent_file']['path']).read_bytes();new=Path(proposal['candidate']).read_bytes()
assert old.replace(proposal['old_sha256'].encode(),proposal['new_sha256'].encode())==new
source50=value['source50_dependency']
for key in ('prepared','frozen','public_snapshot_index'):
    verify(source50[key]['path'],source50[key]['pin'],'Source50_metadata_pointer_only')
overlay_mjs=next(row for row in source50['overlay_targets'] if row['target'].endswith('self-operating-read.mjs'))
verify(overlay_mjs['candidate'],overlay_mjs['candidate_pin'],'Source50_exact_mjs_parent')
assert overlay_mjs['candidate_pin']==value['targets'][-1]['parent']
declared={str(Path(row['path']).relative_to(APP)).replace('\\','/'):row['pin']['sha256'].lower()
          for row in value['public_dependencies'] if Path(row['path']).is_relative_to(APP)}
parents={str(Path(row['target']).relative_to(FORMAL)).replace('\\','/'):row['parent']['sha256'].lower() for row in value['targets']}
finals={str(Path(row['target']).relative_to(FORMAL)).replace('\\','/'):row['candidate_pin']['sha256'].lower() for row in value['targets']}
maps=[]
for impact in value['source_revision_impacts']:
    module=impact['module'];tree=ast.parse((APP/module).read_text('utf-8'))
    assignment=next(node for node in tree.body if isinstance(node,ast.Assign) and any(isinstance(x,ast.Name) and x.id==impact['fixed_sources_constant'] for x in node.targets))
    sources=list(ast.literal_eval(assignment.value));assert sources==impact['source_files']
    before={name:parents.get(name,declared.get(name)) for name in sources}
    after={name:finals.get(name,declared.get(name)) for name in sources}
    assert None not in before.values() and after==impact['candidate_sha256_lower']
    digest=lambda mapping:hashlib.sha256(json.dumps(mapping,sort_keys=impact['digest_sort_keys'],ensure_ascii=False,separators=(',',':')).encode()).hexdigest()
    assert digest(before)==impact['source50_revision']
    assert digest(after)==impact['six_business_candidate_revision']
    assert [name for name in sources if before[name]!=after[name]]==impact['changed_paths']
    maps.append({'purpose':impact['purpose'],'old':digest(before),'new':digest(after),'changed_paths':impact['changed_paths'],'sort_keys':impact['digest_sort_keys']})
report={'schema':'source51_dy_independent_frozen_readback_v1','result':'MATCH_READBACK_AND_STATIC_MAPS',
    'frozen':{'path':str(frozen),'pin':pin(frozen)},'verified':verified,'source_revision_maps':maps,
    'static_maps_use_declared_public_dependency_pins':True,'public_dependencies_pointer_count':len(value['public_dependencies']),
    'snapshot_781_traversed':False,'Source50_protected_367_traversed':False,'runtime_binaries_rehashed':False,
    'purpose_or_account_granted':False,'QA_or_story_executed':False,'formal_author_App_data_changes':0}
dest=HERE/'DY-FREEZE-READBACK.json';dest.write_bytes((json.dumps(report,ensure_ascii=False,indent=2)+'\n').encode())
print(json.dumps({'result':report['result'],'verified_pin_count':len(verified),'maps':maps,'out':str(dest),'pin':pin(dest)},ensure_ascii=False,indent=2))
