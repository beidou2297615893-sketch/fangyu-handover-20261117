from pathlib import Path
import hashlib,json
HERE=Path(__file__).resolve().parent
ROOT=HERE.parent/'source51-store-scope'
def pin(path):
    raw=Path(path).read_bytes();return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest().upper()}
frozen=ROOT/'FROZEN.json';value=json.loads(frozen.read_bytes())
assert pin(frozen)=={'bytes':14804,'sha256':'D6287074B1ACD2FB9A0AB84D043289EAD5A740435F6A26871F5E6D5E9BB9D646'}
for row in value['targets']:assert pin(row['candidate'])==row['candidate_pin']
report={'schema':'source51_store_scope_non_author_review_v1','result':'NO_MUST_FIX_FINDING_IN_REVIEWED_SCOPE',
    'frozen':{'path':str(frozen),'pin':pin(frozen)},'targets':value['targets'],
    'evidence':[{'path':str(HERE/'SCOPE-FREEZE-READBACK.json'),'pin':pin(HERE/'SCOPE-FREEZE-READBACK.json')},
                {'path':str(HERE/'SCOPE-REVIEW.md'),'pin':pin(HERE/'SCOPE-REVIEW.md')},
                {'path':value['actual_scope_story_path'],'pin':pin(value['actual_scope_story_path'])}],
    'independent_QA_executed':False,'new_representative_required':False,'formal_or_author_source_writes':0,
    'App_or_helper_actions':0,'real_SDK_deployment_or_data_verified':False,
    'failure_history_limit':'READ-RED.json overwritten; empty actual_source_ids contradict stale reason; not earliest two-store proof',
    'join_authorized':False,'requires_source50_original_protection_readback_before_root_successor_CAS':True,
    'unverified':['real CloudBase SDK and compound index','real deployment and data migration','real SDK multi-page cursor and transaction conflicts/failure rollback','physical store approval and complete manager/department business system']}
dest=HERE/'SCOPE-REVIEW.json';dest.write_bytes((json.dumps(report,ensure_ascii=False,indent=2)+'\n').encode())
print(json.dumps({'path':str(dest),'pin':pin(dest),'report_pin':pin(HERE/'SCOPE-REVIEW.md')},ensure_ascii=False,indent=2))
