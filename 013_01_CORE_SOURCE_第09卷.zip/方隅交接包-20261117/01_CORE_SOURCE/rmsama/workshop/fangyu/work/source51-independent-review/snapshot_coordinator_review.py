from pathlib import Path
import hashlib,json
HERE=Path(__file__).resolve().parent;WORK=HERE.parent
def pin(path):
    raw=path.read_bytes();return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest().upper()}
files=[WORK/'source51-root-integration/next_open_source51.py',WORK/'desktop-self-use-entry/next_open_source.py',WORK/'product-upgrade-20261009/audits/join-source50-reviewed.py']
value={'schema':'source51_coordinator_structure_review_v1','result':'P2_PROTECTED_UNCHANGED_SCOPE_NOT_CHECKED',
    'final_pin_or_QA_pass':False,'read_snapshot':[{'path':str(p),'pin':pin(p)}for p in files],
    'report':{'path':str(HERE/'COORDINATOR-STRUCTURE-REVIEW.md'),'pin':pin(HERE/'COORDINATOR-STRUCTURE-REVIEW.md')},
    'executed_import_preflight_lock_CAS_QA':False,'Root_or_formal_or_App_changes':0,'join_authorized':False}
dest=HERE/'COORDINATOR-STRUCTURE-REVIEW.json';dest.write_bytes((json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode())
print(json.dumps({'path':str(dest),'pin':pin(dest),'snapshot':value['read_snapshot'][0],'report':value['report']},ensure_ascii=False,indent=2))
