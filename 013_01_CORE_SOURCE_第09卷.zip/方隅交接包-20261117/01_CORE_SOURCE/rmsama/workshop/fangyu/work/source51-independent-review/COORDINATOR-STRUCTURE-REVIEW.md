# Source51 协调器草稿结构审

这是未授权、未安装草稿的结构审，**不是最终 pin PASS 或状态故事通过**。只读 `work/source51-root-integration/next_open_source51.py` 和已审 Source50 的 `_plan/_readback/_exclusive_existing_lock/_start_once` 接口，以及原 CAS 的成功回执字段。没有执行import/preflight/取锁/CAS/业务代码/QA，没有修改正式、Root草稿、50 helper/script或当前App。

## [P2] 后继读回漏核原50受保护的未覆盖项

原 `join-source50-reviewed.py:145-147` 成功receipt有 `protected` 列表；其实际pin在原CAS前/后核过。新 `_base_receipt` 的 `pins` 仅来自 `base['targets']`（55业务目标），循环只核该集合；新 `_readback` 只另外核51 targets。于是原50 protected中既非55、又非51 overlay的一件云/portal源码后续变化时，51成功receipt仍可通过这个读回并返回continue。Source50的service保护依赖已经是该后继的实际原因，不能把其它未覆盖保护项悄悄降为不核。

最小补法不修改已审50：新协调器用**固定已审50 prepared/gate pin**取得原protected权威列表（或Root编译同一精确列表），核50原receipt的protected与该列表完全相同。核未覆盖项仍等原protected pin；51覆盖项须parent_pin等原50保护pin，当前等51 final_pin。与55目标合并核验、去重时须拒绝同path冲突。只允许固定源码路径，不从自由receipt字段扩到数据/账号文件，不引入任意环境或CLI授权。

建议补一个自有正常后继故事断言：50真实自有receipt + 51真实自有receipt生成后，只篡改一个原50 protected且非51目标的自有source文件，正常下一开/metadata读回须held、0再次apply、0业务导入；恢复原byte再核才可以正常continue。这个是新增后继边界，不能以原50故事替代。

## 已成立的结构与尚待最终接线核对

- 默认 `JOIN_AUTHORIZED=False`、MANIFEST_PIN=None、targets空，`_plan`拒授权；顶层只有定义/常量，没有I/O。固定manifest/gate/JOIN路径与原instance，目标禁止pilot/data。metadata函数仅 `_plan/expected/blob/readback`，未取锁、创建STARTED或业务import。
- normal要求原preflight真正ready+instance，再同原1字节OS锁、锁内preflight/plan复核。50 receipt缺失时调用原50 `_start_once`、同PID固定CAS50、原50 `_readback`；之后才取50原receipt pin、登记51 STARTED、执行51 CAS和读回。50/51 FAILED阻止新invoke，未知50 STARTED由原 `_start_once`拒，未知51 STARTED在协调器拒；receipt存在不等于成功，须全部校验。
- `_invoke`紧邻执行 `raw=legacy.expected(path,proof)` 后 `exec(compile(raw,...))`，没有再次按路径读取/执行；保留argv并接受SystemExit0/None。成功后退出持锁区再exec固定新ENTRY，fresh Python先加载新entry/pins，由原main正常重新争同锁；没有继承grant、模块cache或升级flag。
- 后续有51receipt时绕过原50 `_readback`的全55旧byte相等限制，改核50原receipt里55 candidate仍等50原final；51与55重叠的parent必须等50final，当前byte等51final；51全target另外精确读回。这个叠加方向正确，需补上上述protected集合。
- caller/最终pin尚不存在本草稿审的结论：未来普通launcher必须先验证固定协调器/helper字节，调用新metadata函数选择51 ENTRY pin，并确保 `--check-only`在任何业务import、lock和write之前return。最终新ENTRY还需绑定新HOST/source_revision保护；安装后的最后图不能凭本草稿审认定通过。

精度提示（不列安全阻断）：当前before_normal_open在 `_invoke`前设置invoked=True，所以脚本在最终expected校核前被篡改也会返回source_mutations=None；实际exec未发生但STARTED已保留。这是保守未知，未导致重提；如需held0精确区分，可让 `_invoke`在已取得raw且即将exec处通知调用者设置invoked。不改变已started不重apply。

## Root 最小必要自有状态故事

1. 使用现自有固定入口/普通OS锁夹具，初态无50/51receipt：metadata/check-only记录0业务import/写入/锁/CAS；普通ready后在同锁中只50CAS一次，确认其真实receipt，再51CAS一次，确认读回后fresh ENTRY边界。门与脚本全部fixture固定，不触原App；原50能力不另造。
2. 已有自有50成功、51待合：只invoke51；51已成功再次普通打开：0invoke，50未变项+51覆盖项继续；其中加入上面的protected未覆盖source篡改断言，以及51final/50原receipt pin变动须held的同一原号分支。
3. 在该故事各确定阶段保留未知STARTED或FAILED、无有效成功receipt：后续普通打开不第二次apply。alive/unknown/preflight变化/自有锁忙均held。只做新协调器因果断言，不重原50旧QA；不得用录制preflight或exec边界声称已验证实际原App退出/重开。

本审不授权安装、填true、改桌面入口或对真实源码apply；Root定稿改动、精确50+51固定图和新自有故事完成后仍需最终审核。实际pins仅作为这次读取快照，由COORDINATOR-STRUCTURE-REVIEW.json记录。
