# Source51 极窄非作者审前准备

状态：PRE-REVIEW，仅基于 `work/product-upgrade-20261009/audits/source51-current.md` 顶部范围和当前正式成熟模块；没有读取正在变动的 Source51 作者候选，没有运行测试或旧矩阵，没有 PASS、合入或真人验证结论。沿前阶段已实际读取的 tdd / codebase-design，审真实公开行为与可信范围，不重造封装或证据体系。正式源码、中央文档、作者目录和运行 App 均未改。

冻结后只接受 Root 提供的 exact FROZEN、targets/父 pin、候选 CODE 和作者本轮新实际代表指针。先核冻结图与实际父，再审下列接缝；只有无法从代码及新代表判断的明确风险才提出一个最小补充代表，不复制旧 QA。Source50 仍待正常下一开，不能用当前49+49b父覆盖已审Source50待合候选，或漏更新受影响HOST/source_revision保护图。

Root 新增的实际依赖：Source50 PREPARED.json L535保护 `cloud/workspace/service.cjs`，店级Source51不能先合正式service。Root准备复用正常下一开链作后继51装载；本审前准备不接线、不修改已审50/helper/entry，不操作App。冻结审需核后继父和保护图顺序，候选通过也不意味着可以抢先apply。

## 抖音保存 → 来源池 → 明确分析

当前成熟锚点：

| 原正式位置 | 必须保持的已有事实 |
| --- | --- |
| `assistant/owner_douyin_source_archive.py:76` `_OwnerDouyinArchiveScope` | 精确 factory seal / thread frame / reads-helper-workspace identity；不能借 XHS TLS；metadata 与新存储分别控制；原回执 schema 为 `local_owner_douyin_archive_v1`，账号 digest 含 platform。 |
| 同文件 `:198` `_history_source`、`:251` `_history_projection` | 绑定 actor/device/account/UID/connection、platform=`douyin`、原 safe/original/routing hash、post/comment/source_uid；隐私来源不得成为自由文本。canonical source 在去重保存事件间不变，不能猜其 input_digest 等于后来的事件 batch digest。 |
| `core/platform_reads.py:191`、`assistant/platform_receipt_archive.py:234` / `:266` / `:274` | source_uid 带平台前缀；SOURCE row/lead id 使用完整 source_uid；公开 source_id 去掉平台前缀后可相同，不能单凭 source_id 关联证明。 |
| `assistant/self_operating_source_intent.py:64` / `:138` / `:301` | 当前 host/account/guard/receipt 固定 XHS；execute 首 lead 决定原 account，必须改成可信实际 source/account 分派，不能 HTTP 参数指定授权。 |
| `assistant/source_intent_analysis.py:101` `_Capture._load` / `:183` check | 原归档源、账号、同批、receipt 全链校验；同组字段包含 platform/post/account/UID/digests/read_operation_id；注册 attempt/保存前再次比原 snapshot。 |
| `assistant/self_operating_read.py:301` 评级索引 / `:400` `_source_page` | 当前来源 accounts 与 archive/analysis proof 为 XHS固定。来源可见、明确分析可执行、已分析评级投影是三个需要一致分派的接缝。 |

重点按实际冻结改动核四条：

1. **同 source_id 异平台不借证。** 合成 XHS/Dy 拥有相同公开 source_id（或相同作品/评论字符串），但不同 platform/source_uid/lead_id。列表、选择、批 receipt、AI cache/attempt/操作回执与 priority 投影必须沿完整身份关联。拿 XHS `local_owner_archive_v2` 或分析 proof 替 Dy（反向亦然）必须拒绝，0 新分析 dispatch/commit；不能让“值相同”或自由 DTO 取代 factory seal。混合平台/账号/读取批选项不能通过第一 lead 的 host 为其它 lead 授权。
2. **当前原账号和版本关闭。** source/account.platform 不同、同平台另一 account/UID/conn、actor/instance/tenant 不同均拒；新分析按固定 Dy `_account` / execution_guard / binding 进入原可信 context，不用 XHS `_call` 包 Dy，也不借 archive存储范围作模型用途。模型执行中至 commit 前切换账号、成员/provider绑定、source snapshot、风险/组件许可必须停止新保存并保原号；已有本地状态/unknown恢复保留原语义，不能错误断言未扣费或自动重试。
3. **v2专有，v1继续关闭。** v1经正常公开接口注入 Dy lead/action/cursor，或人工把 account/source.platform 改 Dy，不得启用新平台；guard、模型、状态保存分别按现合同拒绝。Wx transport-only/无身份预览仍不进入来源自由文本和明确分析。XHS成熟入口与历史原号读取不因扩平台失效。
4. **正常最难代表就够。** 作者本轮自有真实公开接口 Dy原保存→本人来源池→手动选定→明确分析→本地评级/优先池闭合；平台/模型 adapter录制必须标明。优先查看与①或②同一故事中的失败分支，不重跑既过局部链。Source51是否扩 OwnerAcq 必须是实际新缺口；不能把保存/分析通过写成公司交接、客户同意、资源部接收或平台真实获客通过。

## 店级共享四云目标

当前成熟锚点：`service.cjs:36` cleanLead、`:203` shared disabled gate、`:228` list、`:241` member_save、`:272` publish、`:351` v2异步续接；`shared_leads_v2.cjs:17` upsertBatch / `:34` listPage / 迁移；`index.js:50` listSharedPage；`shared_feature.cjs:2` 默认 false。

正式原行为：共享记录 id是 platform、换行和 source_id的hash；旧数组 publish 按 id 覆盖，v2按 company+leadId doc覆盖。公开 cleanLead 仅列出的平字段 + comment_level/id，后续添加 updatedBy/updatedAt。member_save清会话但不增加共享revision；当前v2查询前事务与查询后 fresh检查只核 revision、enabled、session存在，没绑定门店/角色。这些是审查锚点，不把共享默认关闭称为已经发生生产泄露。

| 审查点 | 对冻结 CODE / 新实际代表的必要判断 |
| --- | --- |
| 固定来源店 | 只有服务端 fresh user.store_id 产生 source_store_id；请求顶层或item字段伪造不能改变。operator非法/无店拒读写。HQ可读改原公司范围，但HQ无店不得新建未知来源；admin有store也不能意外缩原HQ范围。 |
| 同 id跨店覆盖 | A先建、B同 platform/source_id publish：事务内读取原记录并拒跨店覆盖，原source_store_id和正文不变；不能只靠 list隐藏。反向同样；新batch混入一条foreign必须整事务拒/回滚，v2文档/sequence/revision不能部分写。HQ修改保留原店，转店不迁原来源。 |
| 旧无范围 | operator不能读、认领或利用同id覆盖来加自己的店；HQ仍可按原管理范围查看/更新，但不补猜店。旧数组和v2迁移都保留缺范围状态；迁移/内部 upsert调用不能因新增scope形参而隐式认领。 |
| v2查询前后fresh | 查询where至少 company+服务端店，返回每行重新验证存储范围；再读公司authority，绑定同 session、enabled、role、store/scope，而非只同username/revision。正常 member_save在query挂起时把A转B/降权/disabled/清session，旧page必须拒返回；重新登录只见B，不迁A旧行。范围扩大至HQ也不能交付旧operator page。 |
| SDK适配与分页 | review `index.js`实际 createStore 接线而非仅 memory假list函数；有新代表显示查询谓词及fresh后检查。范围在任意页/cursor/revision同样强制；客户端不能选择scope。含lookahead的候选查询结果不能把异公司/异店record投影出去；游标不是权限令牌。 |
| 公开DTO兼容 | 内部source_store_id需存储并保护，但旧公开lead DTO字段/格式和list revision/max_batch/next_cursor保持现客户端约定。若移除/增加字段必须精确核原消费者，不凭“前端忽略未知字段”宣称兼容；scope元数据不替代平台source_id。HQ/旧无范围投影也遵守同一兼容策略。 |
| 默认关闭/职责边界 | SHARED_FEATURE_ENABLED=false时list/publish仍423，0共享读写；受信显式shared=true仅自有代表。acquisitionPolicy.managers不能借作新店长角色，Contact/设备/交接/会话协议不因共享scope扩权。 |

## 最终结论限制

非作者冻结审只报告具体通过范围、CODE finding或未验证。没有新代表支撑的 SDK异步分页/转店Race保留未验证，不用测试数量补齐。0真实DB/Cookie/账号/平台/模型/云/GUI/CUE/外发/部署/打包；源码和录制适配通过不构成商业验收或真实平台身份验证。
