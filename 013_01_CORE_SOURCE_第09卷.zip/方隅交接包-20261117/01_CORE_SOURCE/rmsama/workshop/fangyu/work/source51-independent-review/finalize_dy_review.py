from pathlib import Path
import hashlib,json
HERE=Path(__file__).resolve().parent;ROOT=HERE.parent/'source51-dy-owner-downstream'
def pin(path):
    raw=Path(path).read_bytes();return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest().upper()}
frozen=ROOT/'evidence/FROZEN.json';value=json.loads(frozen.read_bytes())
assert pin(frozen)=={'bytes':81390,'sha256':'03D999555B7CA29A5C5B1E6317D85D9E768BB1631755D5D557F310EE325FF430'}
for row in value['targets']:assert pin(row['candidate'])==row['candidate_pin']
report={'schema':'source51_dy_six_business_non_author_review_v1','result':'NO_MUST_FIX_FINDING_IN_REVIEWED_SCOPE',
    'frozen':{'path':str(frozen),'pin':pin(frozen)},'targets':value['targets'],'entry_proposal_static_only':value['entry_proposal'],
    'evidence':[{'path':str(HERE/'DY-FREEZE-READBACK.json'),'pin':pin(HERE/'DY-FREEZE-READBACK.json')},
                {'path':str(HERE/'DY-REVIEW.md'),'pin':pin(HERE/'DY-REVIEW.md')},*value['actual_evidence']],
    'Source50_next_open_dependency':True,'join_authorized':False,'six_business_targets_only':True,
    'author_result_is_not_review_result':True,'independent_story_or_QA_executed':False,'new_representative_required':False,
    'snapshot_781_or_protected_367_or_runtime_binary_rechecked':False,
    'formal_or_author_or_source50_or_App_data_changes':0,
    'recorded_model_dispatches_in_author_story':{'total_distinct_requests':2,'succeeded':1,'late_change_unknown':1,'original_key_redispatch':0},
    'real_purpose_or_account_or_customer_consent_or_model_or_cloud_or_GUI_verified':False,
    'unverified':['real platform account/read/save','real model billing','natural customer consent','production company/SDK/deployment','GUI and full frontend','final 11-target combined integration and original App next opening']}
dest=HERE/'DY-REVIEW.json';dest.write_bytes((json.dumps(report,ensure_ascii=False,indent=2)+'\n').encode())
print(json.dumps({'path':str(dest),'pin':pin(dest),'report_pin':pin(HERE/'DY-REVIEW.md')},ensure_ascii=False,indent=2))
