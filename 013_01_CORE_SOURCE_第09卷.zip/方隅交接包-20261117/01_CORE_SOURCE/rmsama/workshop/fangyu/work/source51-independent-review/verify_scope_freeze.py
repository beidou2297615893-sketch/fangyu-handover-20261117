from pathlib import Path
import hashlib,json
ROOT=Path('C:/积木软件工坊/项目/方隅公寓客户版/work/source51-store-scope')
frozen=ROOT/'FROZEN.json'
raw=frozen.read_bytes()
assert len(raw)==14804 and hashlib.sha256(raw).hexdigest().upper()=='D6287074B1ACD2FB9A0AB84D043289EAD5A740435F6A26871F5E6D5E9BB9D646'
value=json.loads(raw)
def pin(path):
    data=Path(path).read_bytes();return {'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest().upper()}
verified=[]
def verify(path,expected,kind):
    actual=pin(path);assert actual==expected,(str(path),actual,expected)
    verified.append({'path':str(path),'kind':kind,'pin':actual})
for target in value['targets']:
    verify(target['candidate'],target['candidate_pin'],'candidate')
    if target['parent'] is not None:verify(target['target'],target['parent'],'formal_parent')
    else:assert not Path(target['target']).exists()
for row in value['evidence']:verify(row['path'],row['pin'],'frozen_evidence')
for row in value['unchanged_public_dependencies']:
    verify(row['path'],row['pin'],'formal_dependency')
    verify(ROOT/'candidate/cloud/workspace'/row['relative'],row['pin'],'candidate_dependency')
verify(value['source50_prepared_path'],value['source50_prepared_pin'],'protected_source50_prepared')
scope=value['source50_protected_service_parent'];verify(scope['path'],scope['pin'],'source50_protected_service_parent')
result={'schema':'source51_store_scope_independent_freeze_readback_v1','frozen':{'path':str(frozen),'pin':pin(frozen)},
    'candidate_count':len(value['targets']),'formal_parent_count':len([t for t in value['targets'] if t['parent'] is not None]),
    'new_target_absent':True,'verified':verified,'actual_QA_executed':False,'actual_source_or_App_changes':0}
out=Path(__file__).resolve().parent/'SCOPE-FREEZE-READBACK.json';out.write_bytes((json.dumps(result,ensure_ascii=False,indent=2)+'\n').encode())
print(json.dumps({'result':'MATCH','frozen':result['frozen'],'candidate_count':result['candidate_count'],'verified_pin_count':len(verified),'out':str(out),'out_pin':pin(out)},ensure_ascii=False,indent=2))
