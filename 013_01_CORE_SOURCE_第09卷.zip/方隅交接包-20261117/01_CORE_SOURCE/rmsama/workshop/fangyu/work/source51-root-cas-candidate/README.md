# Source51 后继 CAS 草稿

仅准备独立候选。`join-source51-reviewed.py` 的 `JOIN_AUTHORIZED=False` 固定首拒，未执行、未安装、未写正式源码、原实例、Root audits、入口或快捷方式。平台 6 源的 exact FROZEN 尚未消费；店级 4 件冻结保持。Root 最终填充并独立审核后才可能进入普通下一开。

复用来源是已审核 Source50 CAS（17271 / DEEE79A75AF115E9510ED40F9F17821EB7FC18026EED28E1AA121F4352BFE6D8），及原 Source44 固定五 AST 工具（9601 / 5F5E3EA22AF7C1FA0FEA71CFEFDA12A9D669C190D5470960901029BF8F4750FB）。`existing_lock_is_held`、`original_main_dead` 与 Source50 原函数逐 AST 比较。没有新升级框架，也没有业务源码 import。

固定 11 个目标：Dy 六源、cloud/workspace 店级四源、原 desktop_entry.py 最后。只有 shared_store_scope.cjs 可创建；目标父目录必须已存在且非 reparse，没有新增目标目录。备份仍是 PROJECT/backups/source51-owner/新随机子目录，保留原十父。新目标使用 Windows rename 拒覆盖，既有目标 replace 前紧邻核父，attempted-first；异常仅回滚自己实际 candidate，外来变动记录拒绝，逐项继续。恢复临时件纳入 finally；不递归删除任何目录。

## 与 Root 协调器的真实接口

固定调用 `audits/join-source51-reviewed.py --apply <Root approval SHA>`，协调器同一 PID 持有原 instance.lock byte 0 / length 1。CAS 使用 child probe 检查锁确实已被持有，不重新抢锁。原 main 进程 alive 或 unknown 均拒；只读 running.json 的有界原元数据和锁身份，不打开 DB/Cookie。Root 协调器检查 STARTED 未知无成功即 hold，不自动再次 apply。

固定 Root 元数据：

- `audits/source51-manifest.json`：schema `source51_next_open_manifest_v1`，batch 51，instance_id，join_authorized true，`base_manifest_pin` 固定 Source50 FA18，`approval_pin`、`join_script_pin`，`targets:[{path,parent_pin,final_pin}]`，`protected:[{path,pin}]`。
- `audits/source51-final-root-read.json`：schema `source51_final_root_read`，独审 code/actual QA/CAS、next_normal_open_only true，`base_manifest_pin` 同一固定值，`join_script_pin`、`prepared_manifest_pin`、`additional_evidence:[{path,pin}]`；customer DB/session copy/deploy or packaging false。
- `audits/source51-next-open-started.json`：schema `source51_next_open_started_v1`，同 iid/batch/pid、approval SHA、manifest pin、真实 `base_receipt_pin`、auto_retry false。
- `work/source51-root-integration/PREPARED.json`：schema `source51_owner_prepared_v1`、batch 51、join_authorized false、iid、base_manifest_pin、`targets:[{target,candidate,parent,candidate_pin}]`、`protected:[{path,pin}]`、`candidate_dependencies:[{path,pin}]`、`evidence:[{path,pin}]`、`new_directories:[]`。candidate 必须在同目录 `candidates` 内，没有 `..` 路径；10 parent proof 非空，唯一 new parent null。可由 Root 最终改固定 PREPARED/candidate 根后再审，不能通过运行参数改根。

Source50 固定 manifest FA18 精确授权 55 件；其固定 gate 绑定旧 PREPARED 5613。Source51 CAS 核真实 source50-joined 成功回执：55 target、candidate、authority/prepared pin、原 protected 全数组及 false 边界。51 任何写前先实际读回 55 个 final。51 覆盖的既有 50 target/原 protected，parent 必须等于前代 pin。后继 protection 必须是 50 final + 原 protected 减 11 target，再合并两冻结候选的公开不变依赖；依赖冲突拒绝。Source51 authority.protected 与 prepared.protected 必须同一数组。

成功：`audits/source51-joined.json` schema `source51_owner_joined_v1`，batch、approval SHA、authority/prepared/base_receipt pins、targets `{target,parent,candidate,backup}`、protected、new_directories []；App restart/marker/DB/session/deploy/real GUI/commercial_complete false。后继成功后读回原 55 只允许上述授权覆盖，未覆盖源继续原 pin。失败：`audits/source51-join-failed.json` schema `source51_owner_join_failed_v1`，独立 CreateNew，包含同 authority/base/approval、error type、backup 可空、逐项 rollback、automatic_retry false。现有成功或失败路径 lexists 即拒，原史不覆盖。

## 最小新代表方案（由 Root 执行，本文未跑）

所有 fixture globals 固定 Root 自有临时项目，包括 PROJECT/WORK/AUDITS/PILOT/ENTRY、55 前代/原保护、11 后继/candidates/STARTED/receipt/backup；不得指真实原实例。无业务 import，无真人平台/模型/SDK，无 App 启动。

1. 真 byte OS 锁的正常 50→51 序列：50 CAS 只用明确录制已验证接口；实际新 51 CAS 在自有十父/一新目标提交。核 base receipt55、十一 final/十备份/一新、protected、entry 最后、零 staging；释放锁后仅录制 exec 边缘。再正常 metadata readback 0 invoke。将未被 51 覆盖的一件原 50 protected 改字节，必须 held / 0 invoke。
2. 坏父：正常锁和真实同 PID STARTED/前代回执，但 11 target 某既有 parent 不符。0 replacement、保原父，生成唯一 failure（backup 可空）；第二次拒，不自动恢复或重试。
3. 提交中断：在自有实际新目标 rename 已执行之后抛错（attempted 已记录），其余自己提交的既有源恢复到父，新 scope unlink，仅自有 staging 清理；失败回执/原 backup 保史。另一次独立 fixture 可让一件 candidate 外来变动，必须 refused rollback、继续恢复其他自己的项，绝不覆盖 foreign。

该代表验证此次新增前后代边界、正常锁、父 CAS 与失败状态，不重复 Source50 原业务矩阵、店级功能 QA 或平台链。
