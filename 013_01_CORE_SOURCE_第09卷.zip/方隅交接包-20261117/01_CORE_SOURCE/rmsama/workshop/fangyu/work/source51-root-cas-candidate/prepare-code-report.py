"""Owned, metadata-only draft preparation; does not import or execute any CAS."""
import ast,difflib,hashlib,json
from pathlib import Path
OWN=Path(__file__).absolute().parent
PROJECT=Path('C:/积木软件工坊/项目/方隅公寓客户版')
BASE=PROJECT/'work/overnight-commercial-20261014/source50-preparation/join-source50-reviewed.py'
HELPER=PROJECT/'work/product-upgrade-20261009/audits/join-source44-reviewed.py'
def proof(raw):return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest().upper()}
base_raw=BASE.read_bytes();draft_raw=(OWN/'join-source51-reviewed.py').read_bytes();helper_raw=HELPER.read_bytes()
assert proof(base_raw)=={'bytes':17271,'sha256':'DEEE79A75AF115E9510ED40F9F17821EB7FC18026EED28E1AA121F4352BFE6D8'}
assert proof(helper_raw)=={'bytes':9601,'sha256':'5F5E3EA22AF7C1FA0FEA71CFEFDA12A9D669C190D5470960901029BF8F4750FB'}
base_ast=ast.parse(base_raw);draft_ast=ast.parse(draft_raw);compile(draft_raw,str(OWN/'join-source51-reviewed.py'),'exec')
def functions(tree):return {node.name:node for node in tree.body if isinstance(node,ast.FunctionDef)}
before=functions(base_ast);after=functions(draft_ast)
unchanged={name:ast.dump(before[name])==ast.dump(after[name]) for name in ('existing_lock_is_held','original_main_dead')}
assert all(unchanged.values())
assignments={node.targets[0].id:node.value for node in draft_ast.body if isinstance(node,ast.Assign) and isinstance(node.targets[0],ast.Name)}
assert ast.literal_eval(assignments['JOIN_AUTHORIZED']) is False
targets=ast.literal_eval(assignments['TARGET_RELATIVE']);assert len(targets)==11 and len(set(targets))==11
assert targets[-1]=='desktop-self-use-entry/desktop_entry.py' and targets.count('cloud/workspace/shared_store_scope.cjs')==1
diff=''.join(difflib.unified_diff(base_raw.decode('utf-8').splitlines(True),draft_raw.decode('utf-8').splitlines(True),fromfile='reviewed-source50',tofile='uninstalled-source51-draft'))
(OWN/'candidate.diff').write_text(diff,encoding='utf-8',newline='\n')
result={'schema':'source51_cas_draft_code_shape_v1','source_batch':51,'base_script_pin':proof(base_raw),'helper_pin':proof(helper_raw),
    'draft_pin':proof(draft_raw),'compile_only':True,'cas_executed':False,'join_authorized':False,
    'unchanged_mature_functions':unchanged,'target_count':len(targets),'targets':list(targets),
    'entry_last':True,'only_new_target':'cloud/workspace/shared_store_scope.cjs','business_qa_rerun':False,
    'real_instance_metadata_read':False,'App_started':False,'formal_mutations':0,'root_approval_created':False}
(OWN/'CODE-SHAPE.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
files=[]
for name in ('join-source51-reviewed.py','README.md','candidate.diff','CODE-SHAPE.json','prepare-code-report.py'):
    path=OWN/name;files.append({'path':str(path),'pin':proof(path.read_bytes())})
frozen={'schema':'source51_root_cas_uninstalled_draft_v1','source_batch':51,'join_authorized':False,
    'exact_author_candidate_pins_available':False,'formal_mutations':0,'Root_finalization_required':True,
    'cas_executed':False,'files':files,'base_script':{'path':str(BASE),'pin':proof(base_raw)},
    'base_manifest_pin':{'bytes':17143,'sha256':'FA18DE22A451370BD49417A6315ED317134B261D615BED0622031379BEF57267'}}
path=OWN/'FROZEN.json';path.write_text(json.dumps(frozen,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({'FROZEN':proof(path.read_bytes()),'draft':proof(draft_raw),'AST_and_compile':'PASS','actual_apply':0}))
