# 已生成固定绑定候选，待Root签发与发布

最终候选在 `staging-r2`，共13份新53公有文件；精确未来路径与pins见 PLAN.json。生成器只写本owned staging，没有原SOURCE/audits写、publish、install、原guard/PID/preflight或生产入口执行。两冻结基底46CAA63A / 562FDC64及其所有文件均保持原pin。

依赖顺序为 unchanged PREPARED(false) → enabled CAS（manifest pin仍None）→ business Root gate方案 → manifest → helper固定CAS/manifest pin → launcher固定helper pin → source-package freeze → native graph → native Root gate方案 → installer固定graph/gate pin。业务manifest不包含helper/native图pin，source-package不包含native图/gate/installer，native图/gate不反绑installer，故无hash循环。CAS、helper、launcher及installer**所有原function字节逐项相同**，仅顶部常量/路径及绑定发生变化，差异全文见PLAN。

未来集中目录是 `work/source53-root-integration`，canonical新authority/CAS为新 `audits/source53-*`/`join-source53-reviewed.py`。成熟native接口按 basename检查 `AUTHORITY-PROPOSAL.json`、`GATE-PROPOSAL.json`、`join-source53-reviewed.py`，因此未来root-integration另保留这三个新53同字节审计别名；其pins与canonical文件严格相等。别名不是原false proposal的改写，也不改变旧50/51/52authority。

enabled字节和gate内true字段是**待Root签发的方案值**，文件带 STAGED_ROOT_SIGNING_PROPOSAL / Root_acceptance_pending / proposed_values_not_actual_Root_signature 标志。它们不代表实际Root批准、独立binding审通过、发布或已加载；本阶段不导入/调用staged生产绑定code。Root仍须独立binding审、保存真实接受事实后才能决定新authority发布；真正native安装和business apply仍受新availability、actual52 native dependency、原lock/fresh guard与所有累计原backup/rawlineage核对约束。

新增代表实际 PASS：对13文件做惰性AST globals解析与pin/别名/依赖拓扑核对，检查native同一行WORK/AUDITS完整、新helper/CAS/manifest接线与future52 launcher父；随后复用已有owned fixture故事，只执行一条重定址副本的 generated helper `_cas`/`before_normal_open` → checked CAS固定manifest传入 → 三file事务、真实existing byte锁/child probe与50/51/52/53累计读回。3 targets/470 protection及原exec flags记录准确。该fixture位于本proposal已有fixtures自有根；旧批次/legacy callbacks、guard/PID/preflight和最终exec录制，没有原App。旧10或native9 QA没有重跑。

最初staging-r1只按整行替换native OWN，误删同一行WORK/AUDITS；仅语法及function相等不足以发现global缺口。本次已保留staging-r1、PLAN-r1-HISTORICAL.json与FIRST-R1-ISSUE.json，r2改为只替换精确AST assignment片段并通过新增代表。r1不能发布/安装。

未验证：真实Root签发/新authority发布、真实52安装与新availability、生产normal完整50→53、真实原层receipts/backups/guard/PID、原生UI与人工认可、云/平台/账号/商业完整交付。当前仅编制生产绑定候选，未因运行条件不足停止该独立准备。
