import ast,hashlib,json
from pathlib import Path
OWN=Path(__file__).resolve().parent
BASE=OWN.parent
def pin(raw):return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest().upper()}
def raw(value):return (json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode()
plan=json.loads((OWN/'PLAN.json').read_bytes());representative=json.loads((OWN/'REPRESENTATIVE.json').read_bytes())
assert representative['status']=='PASS_LIMITED_GENERATED_BINDING' and representative['staged_production_code_imported_or_called'] is False
baselines={BASE/'FROZEN.json':{'bytes':7629,'sha256':'46CAA63AA94EB08709A306D2B46FA9C66EFB383905EFBEE3E1D658CDE55C10FB'},BASE/'native/FROZEN.json':{'bytes':6415,'sha256':'562FDC64968F6935EE547E84769FFEC0FBD968A7CE6E9981EB06FA504068784E'}}
for path,proof in baselines.items():
    assert pin(path.read_bytes())==proof
    for source,value in json.loads(path.read_bytes())['files'].items():assert pin(Path(source).read_bytes())==value
files={str(OWN/name):pin((OWN/name).read_bytes()) for name in ('generate.py','representative.py','REPRESENTATIVE.json','PLAN.json','REPORT.md','freeze.py','FIRST-R1-ISSUE.json','PLAN-r1-HISTORICAL.json')}
for row in plan['artifacts']:
    path=Path(row['stage']);assert path.resolve().is_relative_to((OWN/'staging-r2').resolve())
    assert pin(path.read_bytes())==row['pin'];files[str(path)]=row['pin']
    if path.suffix=='.py':ast.parse(path.read_bytes())
for name in ('generate.py','representative.py','freeze.py'):ast.parse((OWN/name).read_bytes())
root=Path(representative['owned_rebound_actual_new_helper_CAS']['root'])
assert root.resolve().is_relative_to((BASE/'fixtures').resolve())
artifacts={str(path):pin(path.read_bytes()) for path in root.glob('work/product-upgrade-20261009/audits/source53-*.json')}
frozen={'schema':'source53_approved_binding_signing_proposal_frozen_v1','status':'FROZEN_STAGED_ROOT_SIGNING_PROPOSAL','Root_signature_actual':False,'production_executed':False,'published':False,'installed':False,'baseline_pins':[{'path':str(p),'pin':v} for p,v in baselines.items()],'files':files,'owned_artifacts':artifacts,'staged_artifacts':13,'all_original_function_bytes_preserved':True,'enabled_staged_production_code_imported_or_called':False,'old10_native9_QA_reexecuted':False,'new_generated_helper_owned_story_actual':True,'historical_r1_not_publishable':True,'pending':['independent binding review','Root actual acceptance/signing/publication decision','genuine availability and actual52 dependency','production cumulative/native acceptance']}
(OWN/'FROZEN.json').write_bytes(raw(frozen))
print(json.dumps({'frozen_pin':pin((OWN/'FROZEN.json').read_bytes()),'staged_artifacts':13,'Root_signature_actual':False,'production_executed':False}))
