import json
from pathlib import Path
STATE=Path('C:\\积木软件工坊\\项目\\方隅公寓客户版\\work\\source53-successor-proposal\\fixtures\\rawlineage\\41465a63f6c445aca50b8ac7687efdd0\\guard-recording.json')
def source_state(caller_pid):
 value=json.loads(STATE.read_text())
 i=value['index'];states=value['states'];state=states[min(i,len(states)-1)]
 value['index']=i+1;value['calls'].append(state)
 STATE.write_text(json.dumps(value))
 return {'scope':'fangyu_customer_source_metadata_v1','state':state}
