"""Check staged production bindings without importing production-bound code.
Only one new rebound OWNED helper/CAS story reuses the previously passed fixture.
"""
import ast,hashlib,importlib.util,json,os,sys,types
from pathlib import Path
OWN=Path(__file__).resolve().parent
BASE=OWN.parent
PROJECT=Path('C:/积木软件工坊/项目/方隅公寓客户版')
FUTURE=PROJECT/'work/source53-root-integration'
AUDITS=PROJECT/'work/product-upgrade-20261009/audits'
def pin(raw):return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest().upper()}
def raw(value):return (json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode()
def load(path,name):
    spec=importlib.util.spec_from_file_location(name,path);mod=importlib.util.module_from_spec(spec);sys.modules[name]=mod;spec.loader.exec_module(mod);return mod
def read_globals(data):
    # Interpreter for inert config assignments only; no Python module execution.
    names={}
    def value(node):
        if isinstance(node,ast.Constant):return node.value
        if isinstance(node,ast.Name):return names[node.id]
        if isinstance(node,(ast.Tuple,ast.List)):return tuple(value(x) for x in node.elts) if isinstance(node,ast.Tuple) else [value(x) for x in node.elts]
        if isinstance(node,ast.Dict):return {value(k):value(v) for k,v in zip(node.keys,node.values)}
        if isinstance(node,ast.BinOp) and isinstance(node.op,ast.Div):return value(node.left)/value(node.right)
        if isinstance(node,ast.BinOp) and isinstance(node.op,ast.Add):return value(node.left)+value(node.right)
        if isinstance(node,ast.Call) and isinstance(node.func,ast.Name) and node.func.id=='Path' and len(node.args)==1 and not node.keywords:return Path(value(node.args[0]))
        if isinstance(node,ast.Attribute) and node.attr=='parent':return value(node.value).parent
        if isinstance(node,ast.Call) and isinstance(node.func,ast.Name) and node.func.id=='frozenset' and len(node.args)==1:return frozenset(value(node.args[0]))
        raise ValueError('noninert top assignment: '+ast.dump(node))
    for node in ast.parse(data).body:
        if isinstance(node,ast.Assign):
            assert len(node.targets)==1 and isinstance(node.targets[0],ast.Name)
            names[node.targets[0].id]=value(node.value)
    return names
def main():
    plan=json.loads((OWN/'PLAN.json').read_bytes());items={x['future']:x for x in plan['artifacts']}
    stage=OWN/'staging-r2'
    def bytes_for(path):
        row=items[str(path)];physical=Path(row['stage']);assert physical.resolve().is_relative_to(stage.resolve())
        data=physical.read_bytes();assert pin(data)==row['pin'];return data
    for row in plan['artifacts']:
        data=bytes_for(Path(row['future']))
        if row['alias_of']:assert row['pin']==items[row['alias_of']]['pin']
    cas=read_globals(bytes_for(AUDITS/'join-source53-reviewed.py'))
    helper=read_globals(bytes_for(FUTURE/'next_open_source53.py'))
    launcher=read_globals(bytes_for(FUTURE/'source_next_open_launcher.py'))
    installer=read_globals(bytes_for(FUTURE/'native/install_native53.py'))
    manifest=json.loads(bytes_for(AUDITS/'source53-manifest.json'));gate=json.loads(bytes_for(AUDITS/'source53-final-root-read.json'))
    graph=json.loads(bytes_for(FUTURE/'native/GRAPH.json'));native_gate=json.loads(bytes_for(FUTURE/'native/NATIVE-ROOT-APPROVAL.json'))
    assert cas['JOIN_AUTHORIZED'] is True and cas['AUTHORITY_PIN'] is None
    assert cas['OWN']==FUTURE and cas['AUTHORITY']==AUDITS/'source53-manifest.json' and cas['APPROVAL']==AUDITS/'source53-final-root-read.json'
    assert cas['PREPARED_PIN']==items[str(FUTURE/'PREPARED.json')]['pin']
    assert gate['join_script_pin']==manifest['join_script_pin']==items[str(AUDITS/'join-source53-reviewed.py')]['pin']
    assert manifest['approval_pin']==items[str(AUDITS/'source53-final-root-read.json')]['pin']
    assert helper['MANIFEST_PIN']==items[str(AUDITS/'source53-manifest.json')]['pin'] and helper['CAS']==AUDITS/'join-source53-reviewed.py'
    assert helper['CAS_PIN']==manifest['join_script_pin'] and helper['JOIN_AUTHORIZED'] is True
    assert launcher['NEWEST_PIN']==items[str(FUTURE/'next_open_source53.py')]['pin'] and launcher['NEWEST']==PROJECT/'work/desktop-self-use-entry/next_open_source53.py'
    assert installer['GRAPH_PIN']==items[str(FUTURE/'native/GRAPH.json')]['pin'] and installer['GATE_PIN']==items[str(FUTURE/'native/NATIVE-ROOT-APPROVAL.json')]['pin']
    assert installer['INSTALL_AUTHORIZED'] is True and installer['WORK']==PROJECT/'work' and installer['AUDITS']==AUDITS
    assert native_gate['graph_pin']==installer['GRAPH_PIN'] and native_gate['stage1_frozen_pin']==graph['stage1_frozen']['pin']
    assert graph['stage1_frozen']['pin']==items[str(FUTURE/'SOURCE-PACKAGE-FROZEN.json')]['pin']
    assert installer['HELPER_PIN']==graph['targets'][0]['final']==launcher['NEWEST_PIN']
    assert installer['LAUNCHER_PIN']==graph['targets'][1]['final']==items[str(FUTURE/'source_next_open_launcher.py')]['pin']
    assert graph['future52_launcher_parent']=={'bytes':4987,'sha256':'598E11A541AADBBEB8A1CA55E6169B5D793C5D80D875603086B773E2671DA432'}
    assert json.loads(bytes_for(FUTURE/'PREPARED.json'))['join_authorized'] is False
    for row in graph['stage1_files']:assert row['pin']==items[row['path']]['pin']
    # The dependency graph has strict production-edge order, with aliases at
    # their canonical step. Manifest/CAS exclude helper/native backreferences.
    dependencies={str(AUDITS/'join-source53-reviewed.py'):[str(FUTURE/'PREPARED.json')],str(AUDITS/'source53-final-root-read.json'):[str(AUDITS/'join-source53-reviewed.py')],str(AUDITS/'source53-manifest.json'):[str(AUDITS/'source53-final-root-read.json'),str(AUDITS/'join-source53-reviewed.py')],str(FUTURE/'next_open_source53.py'):[str(AUDITS/'source53-manifest.json'),str(AUDITS/'join-source53-reviewed.py')],str(FUTURE/'source_next_open_launcher.py'):[str(FUTURE/'next_open_source53.py')],str(FUTURE/'SOURCE-PACKAGE-FROZEN.json'):[str(FUTURE/'source_next_open_launcher.py')],str(FUTURE/'native/GRAPH.json'):[str(FUTURE/'SOURCE-PACKAGE-FROZEN.json')],str(FUTURE/'native/NATIVE-ROOT-APPROVAL.json'):[str(FUTURE/'native/GRAPH.json')],str(FUTURE/'native/install_native53.py'):[str(FUTURE/'native/GRAPH.json'),str(FUTURE/'native/NATIVE-ROOT-APPROVAL.json')]}
    assert all(items[dependency]['step']<items[parent]['step'] for parent,children in dependencies.items() for dependency in children)
    # Reuse the passed OWNED installed-parent/byte-lock fixture, only this new
    # generated binding is executed after all private addresses are rebased.
    fixture_tools=load(BASE/'representative.py','owned53_bind_generation_fixture')
    old,prepared,state,root=fixture_tools.fixture('generated-binding-r2')
    generator=load(OWN/'generate.py','owned53_constant_adapter')
    rootfuture=root/'work/source53-root-integration';rootaudits=root/'work/product-upgrade-20261009/audits'
    fixture_tools.write(rootfuture/'PREPARED.json',raw(prepared));prep_pin=pin((rootfuture/'PREPARED.json').read_bytes())
    cas_bytes,_=generator.constants(bytes_for(AUDITS/'join-source53-reviewed.py'),{'PROJECT':"Path("+repr(root.as_posix())+")",'PREPARED_PIN':repr(prep_pin),'ANCESTORS':repr(old.ANCESTORS),'SOURCE_GUARD_PIN':repr(old.SOURCE_GUARD_PIN),'EXPECTED_TARGET_PINS':repr(old.EXPECTED_TARGET_PINS)})
    cas_pin=fixture_tools.write(rootaudits/'join-source53-reviewed.py',cas_bytes)
    owned_gate=json.loads(old.APPROVAL.read_bytes());owned_gate['join_script_pin']=cas_pin;owned_gate['prepared_manifest_pin']=prep_pin
    owned_gate_pin=fixture_tools.write(rootaudits/'source53-final-root-read.json',raw(owned_gate))
    owned_authority=json.loads(old.AUTHORITY.read_bytes());owned_authority['join_script_pin']=cas_pin;owned_authority['approval_pin']=owned_gate_pin
    owned_manifest_pin=fixture_tools.write(rootaudits/'source53-manifest.json',raw(owned_authority))
    helper_bytes,_=generator.constants(bytes_for(FUTURE/'next_open_source53.py'),{'PROJECT':"Path("+repr(root.as_posix())+")",'CAS_PIN':repr(cas_pin),'MANIFEST_PIN':repr(owned_manifest_pin)})
    helper_path=rootfuture/'next_open_source53.py';fixture_tools.write(helper_path,helper_bytes)
    mapped=read_globals(helper_bytes);assert all(not isinstance(v,Path) or v.is_relative_to(root) for v in mapped.values())
    h=load(helper_path,'owned53_generated_normal_helper')
    legacy=types.SimpleNamespace(expected=old.expected)
    bound=h._cas(legacy)
    assert bound.AUTHORITY_PIN==owned_manifest_pin and all(not isinstance(v,Path) or v.is_relative_to(root) for v in vars(bound).values())
    legacy.RECEIPT=Path(old.ANCESTORS[0]['receipt']);legacy.STARTED=Path(old.ANCESTORS[0]['started']);legacy._exclusive_existing_lock=lambda entry:fixture_tools.lock(bound)
    succ=types.SimpleNamespace(RECEIPT=Path(old.ANCESTORS[1]['receipt']),STARTED=Path(old.ANCESTORS[1]['started']),FAILED=Path(old.ANCESTORS[1]['failed']),BASE_FAILED=Path(old.ANCESTORS[0]['failed']))
    latest=types.SimpleNamespace(RECEIPT=Path(old.ANCESTORS[2]['receipt']),STARTED=Path(old.ANCESTORS[2]['started']),FAILED=Path(old.ANCESTORS[2]['failed']))
    authorities=[json.loads(Path(old.ANCESTORS[i]['authority']).read_bytes()) for i in (2,1,0)]
    latest._plan=lambda a,b:tuple(authorities)
    latest._source_idle=lambda a,p:bound.require_source_idle(p)
    latest._readback=lambda *args:bound.predecessor(prepared)
    entry=types.SimpleNamespace(__file__=str(bound.ENTRY),PILOT=bound.PILOT,preflight=lambda:{'state':'ready_for_original_native_main','instance_id':bound.INSTANCE_ID})
    requests=[]
    class RecordedExec(BaseException):pass
    def record_exec(executable,args):requests.append(args);raise RecordedExec()
    h.os=types.SimpleNamespace(name='nt',path=os.path,execv=record_exec)
    try:h.before_normal_open(entry,legacy,succ,latest)
    except RecordedExec:pass
    assert requests and requests[0][1:5]==['-X','utf8','-B','-I']
    bound.readback();receipt=json.loads(bound.RECEIPT.read_bytes());assert len(receipt['targets'])==3 and len(receipt['protected'])==470
    report={'schema':'source53_generated_enabled_binding_owned_representative_v1','status':'PASS_LIMITED_GENERATED_BINDING','topological_order_valid':True,'staged_artifacts':len(items),'all_original_function_bytes_preserved':True,'native_compound_WORK_AUDITS_preserved':True,'staged_production_code_imported_or_called':False,
        'owned_rebound_actual_new_helper_CAS':{'root':str(root),'fixed_manifest_pin':owned_manifest_pin,'receipt_pin':pin(bound.RECEIPT.read_bytes()),'targets':3,'protected':470,'real_existing_byte_lock_and_child_probe':True,'original_exec_flags_recorded':requests[0]},
        'recorded':['all old50/51/52 layers and legacy callbacks','entry preflight/PID/guard states','final exec request'],
        'production_executed':False,'published':False,'installed':False,'Root_signature_actual':False,'old10_or_native9_QA_reexecuted':False}
    (OWN/'REPRESENTATIVE.json').write_bytes(raw(report));print(json.dumps({'status':report['status'],'staged_production_code_imported_or_called':False,'owned_new_helper_actual':True}))
if __name__=='__main__':main()
