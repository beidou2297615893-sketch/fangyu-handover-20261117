"""One new helper->checked CAS bind/normal-open fixture. Never production root."""
import ast,hashlib,importlib.util,json,os,sys,types
from pathlib import Path
OWN=Path(__file__).resolve().parent
STAGE=OWN.parent.parent
def pin(raw):return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest().upper()}
def raw(value):return (json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode()
def load(path,name):
    spec=importlib.util.spec_from_file_location(name,path);mod=importlib.util.module_from_spec(spec);sys.modules[name]=mod;spec.loader.exec_module(mod);return mod
tools=load(STAGE/'representative.py','owned_source53_fixture_build_support')
def prepare(name):
    old,prep,state,root=tools.fixture('binding-'+name)
    assert root.resolve().is_relative_to((STAGE/'fixtures').resolve())
    # Bind only owned code literals; verified fixture roots precede any call.
    text=(STAGE/'join-source53-reviewed.py').read_text(encoding='utf-8').replace(tools.ORIGINAL.as_posix(),root.as_posix())
    replacements={'PREPARED_PIN':old.PREPARED_PIN,'ANCESTORS':old.ANCESTORS,'SOURCE_GUARD_PIN':old.SOURCE_GUARD_PIN,'EXPECTED_TARGET_PINS':old.EXPECTED_TARGET_PINS,'JOIN_AUTHORIZED':True}
    for key,value in replacements.items():
        line=next(x for x in text.splitlines() if x.startswith(key+'='));text=text.replace(line,key+'='+repr(value))
    cas_path=Path(old.__file__);cas_pin=tools.write(cas_path,text.encode())
    gate=json.loads(old.APPROVAL.read_text());gate['join_script_pin']=cas_pin
    gate_pin=tools.write(old.APPROVAL,raw(gate))
    authority=json.loads(old.AUTHORITY.read_text());authority['join_script_pin']=cas_pin;authority['approval_pin']=gate_pin
    authority_pin=tools.write(old.AUTHORITY,raw(authority))
    helper_text=(STAGE/'next_open_source53.py').read_text(encoding='utf-8').replace(tools.ORIGINAL.as_posix(),root.as_posix())
    for key,value in {'JOIN_AUTHORIZED':True,'MANIFEST_PIN':authority_pin,'CAS_PIN':cas_pin}.items():
        line=next(x for x in helper_text.splitlines() if x.startswith(key+'='));helper_text=helper_text.replace(line,key+'='+repr(value))
    helper_path=root/'work/source53-successor-proposal/next_open_source53.py';helper_pin=tools.write(helper_path,helper_text.encode())
    helper=load(helper_path,'owned_source53_new_coordinator')
    assert helper.PROJECT==root and helper.CAS==cas_path
    legacy=types.SimpleNamespace(expected=old.expected)
    bound=helper._cas(legacy) # Actual checked-byte load and passed fixed manifest.
    assert bound.AUTHORITY_PIN==authority_pin and bound.JOIN_AUTHORIZED is True
    assert all(not isinstance(x,Path) or x.is_relative_to(root) for x in vars(bound).values())
    legacy.RECEIPT=Path(old.ANCESTORS[0]['receipt']);legacy.STARTED=Path(old.ANCESTORS[0]['started'])
    legacy._exclusive_existing_lock=lambda entry:tools.lock(bound)
    successor=types.SimpleNamespace(RECEIPT=Path(old.ANCESTORS[1]['receipt']),STARTED=Path(old.ANCESTORS[1]['started']),FAILED=Path(old.ANCESTORS[1]['failed']),BASE_FAILED=Path(old.ANCESTORS[0]['failed']))
    latest=types.SimpleNamespace(RECEIPT=Path(old.ANCESTORS[2]['receipt']),STARTED=Path(old.ANCESTORS[2]['started']),FAILED=Path(old.ANCESTORS[2]['failed']))
    authority52,authority51,authority50=[json.loads(Path(old.ANCESTORS[i]['authority']).read_text()) for i in (2,1,0)]
    latest._plan=lambda a,b:(authority52,authority51,authority50) # RECORDED legacy planning callback
    latest._source_idle=lambda a,phase:bound.require_source_idle(phase) # Owned recorded guard, actual53 adapter
    latest._readback=lambda a,b,m,base,prior:bound.predecessor(prep)
    preflight_calls=[]
    def preflight():preflight_calls.append(True);return {'state':'ready_for_original_native_main','instance_id':bound.INSTANCE_ID}
    entry=types.SimpleNamespace(__file__=str(bound.ENTRY),PILOT=bound.PILOT,preflight=preflight)
    requested=[]
    class RecordedExec(BaseException):pass
    def fresh_exec(executable,args):requested.append({'executable':executable,'args':args});raise RecordedExec()
    helper.os=types.SimpleNamespace(name='nt',path=os.path,execv=fresh_exec)
    return helper,bound,legacy,successor,latest,entry,requested,RecordedExec,preflight_calls,root,authority_pin,helper_pin
def main():
    h,cas,legacy,succ,last,entry,requested,Exec,preflights,root,authority_pin,helper_pin=prepare('success')
    try:h.before_normal_open(entry,legacy,succ,last)
    except Exec:pass
    assert requested and len(preflights)==2
    assert requested[0]['args'][1:5]==['-X','utf8','-B','-I'] and requested[0]['args'][-1]==str(cas.ENTRY)
    cas.readback();receipt=json.loads(cas.RECEIPT.read_text())
    assert len(receipt['targets'])==3 and len(receipt['protected'])==470
    success={'root':str(root),'helper_pin':helper_pin,'fixed_manifest_pin':authority_pin,'receipt_pin':pin(cas.RECEIPT.read_bytes()),'recorded_exec_request':requested[0],'preflight_calls_recorded':len(preflights)}
    h,cas,legacy,succ,last,entry,requested,Exec,preflights,root,authority_pin,helper_pin=prepare('bad-binding')
    h.MANIFEST_PIN=pin(b'owned foreign manifest')
    result=h.before_normal_open(entry,legacy,succ,last)
    assert result['decision']=='held' and result['source_mutations']==0 and not preflights and not requested and not cas.STARTED.exists()
    report={'schema':'source53_actual_new_helper_owned_binding_v1','status':'PASS_LIMITED_NEW_HELPER_BINDING','success':success,'bad_fixed_manifest':{'root':str(root),'held_before_preflight_guard_started':True},'real':['new53 helper._cas checked bytes + fixed manifest pin injection','new53 before_normal_open existing-lock section','new53 threefile CAS, original backups and cumulative readback','owned existing Windows byte0 length1 lock and child probe'],'recorded':['all historical installed50/51/52 layers and legacy _plan/readback callbacks','entry preflight/PID/guard states','final original exec request; no native App launched'],'production_execution':False,'actual_legacy50_51_52_business_executed':False,'real_normal_entire50_to53_chain_verified':False}
    tools.write(OWN/'REPRESENTATIVE.json',raw(report));print(json.dumps({'status':report['status'],'production_execution':False}))
if __name__=='__main__':main()
