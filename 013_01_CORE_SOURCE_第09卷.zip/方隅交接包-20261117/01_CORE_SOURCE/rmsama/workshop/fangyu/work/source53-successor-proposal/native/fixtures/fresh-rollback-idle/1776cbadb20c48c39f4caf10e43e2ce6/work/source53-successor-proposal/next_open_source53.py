"""Inert, uninstalled Source53 normal-next-open successor candidate."""
import json,os,sys,types
from pathlib import Path
PROJECT=Path('C:/积木软件工坊/项目/方隅公寓客户版/work/source53-successor-proposal/native/fixtures/fresh-rollback-idle/1776cbadb20c48c39f4caf10e43e2ce6')
WORK=PROJECT/'work'
OWN=WORK/'source53-successor-proposal'
ENTRY=WORK/'desktop-self-use-entry/desktop_entry.py'
PILOT=WORK/'self-operating-pilot'
CAS=OWN/'join-source53-reviewed.py'
CAS_PIN={'bytes': 26570, 'sha256': 'CAD66B402CA943074FC08DAF7C4F090AB9B8219998DAAB4322244444A2BF4462'}
JOIN_AUTHORIZED=True
MANIFEST_PIN={'bytes': 388, 'sha256': '3A35EC5D70B7F3340B2180C97A4AACE0906DAF8529DD20F269364646DD12F112'}

def _cas(legacy):
    if JOIN_AUTHORIZED is not True or MANIFEST_PIN is None:
        raise ValueError('53 proposal not joined; no original metadata/guard action permitted')
    raw=legacy.expected(CAS,CAS_PIN)
    module=types.ModuleType('source53_fixed_cas');module.__file__=str(CAS)
    sys.modules[module.__name__]=module
    exec(compile(raw,str(CAS),'exec'),module.__dict__)
    if module.JOIN_AUTHORIZED is not True or module.AUTHORITY_PIN is not None or not module.proof(MANIFEST_PIN):
        raise ValueError('53 fixed new authority not bound')
    # Caller helper is itself pinned by the thin launcher. Assign the already
    # fixed manifest pin AFTER checked CAS load, avoiding CAS <-> manifest hash
    # recursion. The proposal stays false/None, and cannot reach this branch.
    module.AUTHORITY_PIN=MANIFEST_PIN
    return module

def reviewed_entry_pin_if_joined(legacy,successor,latest):
    cas=_cas(legacy)
    cas._authority_plan()
    if os.path.lexists(cas.RECEIPT):
        cas.readback()
        layers=cas._layers(False,False)
        return next(x[3][ENTRY] for x in reversed(layers) if ENTRY in x[3])
    if os.path.lexists(cas.STARTED) or os.path.lexists(cas.FAILED):
        raise ValueError('53 original invocation has no verified success')
    return latest.reviewed_entry_pin_if_joined(legacy,successor)

def before_normal_open(entry,legacy,successor,latest):
    held={'decision':'held','source_mutations':0,'automatic_retry':False}
    if JOIN_AUTHORIZED is not True:return held
    if (os.name!='nt' or getattr(sys,'frozen',False) or Path(entry.__file__)!=ENTRY or entry.PILOT!=PILOT):return held
    invoked=False
    try:
        cas=_cas(legacy);authority,gate,prepared=cas._authority_plan()
        report=entry.preflight()
        if report.get('state')!='ready_for_original_native_main' or report.get('instance_id')!=cas.INSTANCE_ID:return held
        if os.path.lexists(cas.RECEIPT):
            cas.readback();return {'decision':'continue','source_mutations':0,'automatic_retry':False}
        if any(os.path.lexists(x) for x in (cas.STARTED,cas.FAILED,latest.FAILED,successor.FAILED,successor.BASE_FAILED)):return held
        if any(os.path.lexists(layer.STARTED) and not os.path.lexists(layer.RECEIPT) for layer in (legacy,successor,latest)):return held
        with legacy._exclusive_existing_lock(entry):
            again=entry.preflight()
            if again.get('state')!='ready_for_original_native_main' or again.get('instance_id')!=cas.INSTANCE_ID:return held
            authority,gate,prepared=cas._authority_plan()
            if any(os.path.lexists(layer.STARTED) and not os.path.lexists(layer.RECEIPT) for layer in (legacy,successor,latest)):return held
            manifest,base,prior=latest._plan(legacy,successor)
            latest._source_idle(legacy,'before_source_chain')
            # Same original 50 -> 51 -> 52 steps, no nested before_normal_open,
            # no earlier helper exec before Source53 can be applied.
            if not os.path.lexists(legacy.RECEIPT):
                if os.path.lexists(legacy.STARTED):return held
                legacy._start_once(prior);invoked=True
                successor._invoke(legacy,legacy.JOIN,prior['join_script_pin'],prior['approval_pin']['sha256'])
            if not os.path.lexists(successor.RECEIPT):
                if os.path.lexists(successor.STARTED):return {**held,'source_mutations':None if invoked else 0,'join_invoked':invoked}
                legacy._readback(prior)
                prior_pin=successor._base_receipt(legacy,base,prior,False)
                successor._start_once(legacy,base,prior_pin);invoked=True
                successor._invoke(legacy,successor.JOIN,base['join_script_pin'],base['approval_pin']['sha256'])
            if not os.path.lexists(latest.RECEIPT):
                if os.path.lexists(latest.STARTED):return {**held,'source_mutations':None if invoked else 0,'join_invoked':invoked}
                successor._readback(legacy,base,prior)
                base_pin=latest._predecessor_backups(legacy,successor,base,prior)
                latest._source_idle(legacy,'before_source52_started')
                latest._start_once(legacy,manifest,base_pin);invoked=True
                successor._invoke(legacy,latest.JOIN,manifest['join_script_pin'],manifest['approval_pin']['sha256'])
            latest._readback(legacy,successor,manifest,base,prior)
            parent_pin=cas.predecessor(prepared)
            cas.start_once(parent_pin);invoked=True
            # Same-PID execution under the existing lock. This module's checked
            # bytes are already bound by the fresh new authority/gate.
            saved_args=sys.argv
            try:
                sys.argv=[str(CAS),'--apply',authority['approval_pin']['sha256']]
                cas.main()
            finally:sys.argv=saved_args
            cas.readback()
        os.execv(sys.executable,[sys.executable,'-X','utf8','-B','-I',str(ENTRY)])
        return {**held,'source_mutations':None,'join_invoked':True}
    except Exception:
        return {**held,'source_mutations':None if invoked else 0,'join_invoked':invoked}
