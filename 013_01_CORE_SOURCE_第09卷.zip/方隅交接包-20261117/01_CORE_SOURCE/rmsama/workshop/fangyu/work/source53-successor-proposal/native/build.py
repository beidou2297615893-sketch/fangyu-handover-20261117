"""Prepare only the native successor candidate in this new owned subdirectory."""
import ast,hashlib,json
from pathlib import Path
PROJECT=Path('C:/积木软件工坊/项目/方隅公寓客户版')
OWN=Path(__file__).resolve().parent;STAGE=OWN.parent
def pin(raw):return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest().upper()}
def write(name,value):
    path=OWN/name;path.write_text(value if isinstance(value,str) else json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');return pin(path.read_bytes())
frozen_pin=pin((STAGE/'FROZEN.json').read_bytes())
assert frozen_pin=={'bytes':7629,'sha256':'46CAA63AA94EB08709A306D2B46FA9C66EFB383905EFBEE3E1D658CDE55C10FB'}
frozen=json.loads((STAGE/'FROZEN.json').read_text(encoding='utf-8'))
for path,proof in frozen['files'].items():assert pin(Path(path).read_bytes())==proof
old=PROJECT/'work/source52-root-integration/install-native-authorized.py'
oldraw=old.read_bytes();assert len(oldraw)==8911 and pin(oldraw)['sha256'].startswith('6DC1')
source=oldraw.decode('utf-8-sig');tree=ast.parse(source)
header=source[:source.index('\nraw=(AUDITS')]
header=header.replace("OWN=WORK/'source52-root-integration'","OWN=WORK/'source53-successor-proposal/native'")
header=header.replace('source52-native-installed','source53-native-installed').replace('source52-native-install-failed','source53-native-install-failed')
header=header.replace("GUARD=OWN/'source_idle_guard.py'","GUARD=WORK/'source52-root-integration/source_idle_guard.py'")
header=header.replace('INSTALL_AUTHORIZED=True','INSTALL_AUTHORIZED=False')
header=header.replace("NEW_HELPER=WORK/'desktop-self-use-entry/next_open_source52.py'","SOURCE52=WORK/'desktop-self-use-entry/next_open_source52.py'\nNEW_HELPER=WORK/'desktop-self-use-entry/next_open_source53.py'")
header=header[:header.index('PARENT_PIN=')]+"PARENT_PIN={'bytes':4987,'sha256':'598E11A541AADBBEB8A1CA55E6169B5D793C5D80D875603086B773E2671DA432'}\n"
header=header[:header.index('PEER=')]+header[header.index('INSTALL_AUTHORIZED='):]
helper53_pin=pin((STAGE/'next_open_source53.py').read_bytes());launcher53_pin=pin((STAGE/'source_next_open_launcher.py').read_bytes())
pins={name:pin((STAGE/name).read_bytes()) for name in ('join-source53-reviewed.py','next_open_source53.py','source_next_open_launcher.py','AUTHORITY-PROPOSAL.json','GATE-PROPOSAL.json')}
immutable=[{'path':str(PROJECT/'work/desktop-self-use-entry'/name),'pin':proof} for name,proof in (('next_open_source.py',{'bytes':18590,'sha256':'6DD31FBCB9864272C329C146DD7EA3E9F74F334131F84DDFEB5E3D63ED8BB611'}),('next_open_source51.py',{'bytes':14697,'sha256':'8540B5A0AE7572E5C2DC8A550AD74BA0918FF931C09945E7F802E0FB00F6EEF0'}),('next_open_source52.py',{'bytes':15464,'sha256':'18F99253AF933F1964A0A1F27F78F23D045C2C46363C4A252C22E65761E01680'}))]
graph={'schema':'source53_future_native_graph_v1','source_batch':53,'status':'PREPARED_UNBOUND_NOT_INSTALLABLE','join_authorized':False,'stage1_frozen':{'path':str(STAGE/'FROZEN.json'),'pin':frozen_pin},'stage1_files':[{'path':str(STAGE/name),'pin':proof} for name,proof in pins.items()],'immutable_helpers':immutable,'source_guard':{'path':str(PROJECT/'work/source52-root-integration/source_idle_guard.py'),'pin':{'bytes':5948,'sha256':'1E97220595CCD6954F67FAABFCAE83E52734D4EE59188F0657C9B0363FBA3AA1'}},'source52_native_receipt':str(PROJECT/'work/product-upgrade-20261009/audits/source52-native-installed.json'),'source52_native_failure':str(PROJECT/'work/product-upgrade-20261009/audits/source52-native-install-failed.json'),'future52_launcher_parent':{'bytes':4987,'sha256':'598E11A541AADBBEB8A1CA55E6169B5D793C5D80D875603086B773E2671DA432'},'targets':[{'target':str(PROJECT/'work/desktop-self-use-entry/next_open_source53.py'),'candidate':str(STAGE/'next_open_source53.py'),'parent':None,'final':helper53_pin},{'target':str(PROJECT/'work/desktop-self-use-entry/source_next_open_launcher.py'),'candidate':str(STAGE/'source_next_open_launcher.py'),'parent':{'bytes':4987,'sha256':'598E11A541AADBBEB8A1CA55E6169B5D793C5D80D875603086B773E2671DA432'},'final':launcher53_pin}],'business_apply_calls':0,'runtime_ready':False,'requires_new_reviewed_bound53_revision':True,'no_reverse_native_graph_binding':True}
graph_pin=write('GRAPH-PROPOSAL.json',graph)
gate={'schema':'source53_native_install_gate_v1','source_batch':53,'install_authorized':False,'graph_pin':graph_pin,'stage1_frozen_pin':frozen_pin,'independent_native_review_passed':False,'future52_native_required':True,'business_apply_authorized':False,'App_control_authorized':False}
write('GATE-PROPOSAL.json',gate)
header+="GRAPH=OWN/'GRAPH-PROPOSAL.json'\nGRAPH_PIN="+repr(graph_pin)+"\nGATE=OWN/'GATE-PROPOSAL.json'\nGATE_PIN=None\nSTAGE=OWN.parent\nIMMUTABLE=IMMUTABLE+((SOURCE52,"+repr(immutable[-1]['pin'])+"),)\nHELPER_PIN="+repr(helper53_pin)+"\nLAUNCHER_PIN="+repr(launcher53_pin)+"\n"
helper44=PROJECT/'work/product-upgrade-20261009/audits/join-source44-reviewed.py'
text=helper44.read_text(encoding='utf-8-sig');names=['blob','pin','expected','no_link_parent','prepared_temp']
nodes={x.name:x for x in ast.parse(text).body if isinstance(x,ast.FunctionDef)}
header+='\n\n'.join(ast.get_source_segment(text,nodes[name]) for name in names)+'\n'
header+='\n\n'.join(ast.get_source_segment(source,x) for x in tree.body if isinstance(x,ast.FunctionDef) and x.name in ('proof','absent'))+'\n'
header=header.replace('module.SOURCE_PATHS=(LAUNCHER,SOURCE50,SOURCE51,NEW_HELPER)','module.SOURCE_PATHS=(LAUNCHER,SOURCE50,SOURCE51,SOURCE52,NEW_HELPER)')
body=ast.get_source_segment(source,next(x for x in tree.body if isinstance(x,ast.FunctionDef) and x.name=='main'))
begin=body.index('    if INSTALL_AUTHORIZED');end=body.index('    changes=[]')
body=body[:begin]+(OWN/'plan-checks.txt').read_text(encoding='utf-8')+'\n'+body[end:]
body=body.replace('source52-native','source53-native').replace('source52_native_installed_v1','source53_native_installed_v1').replace('source52_native_install_failed_v1','source53_native_install_failed_v1').replace("'source_batch':52","'source_batch':53")
body=body.replace("native52.get('schema')!='source53_native_installed_v1'", "native52.get('schema')!='source52_native_installed_v1'")
body=body.replace("'final_native_review_pin':PEER_PIN","'native_gate_pin':GATE_PIN")
body=body.replace("'source52_business_apply_calls':0,","'source52_business_apply_calls':0,'source53_business_apply_calls':0,'source52_helper_pin':IMMUTABLE[2][1],")
body=body.replace("'native_gate_pin':GATE_PIN", "'native_gate_pin':GATE_PIN,'source52_native_receipt_pin':parent_native_pin")
# Parent receipt and all ancestor helpers are immutable through both replacements/seal.
body=body.replace('            for path,value in IMMUTABLE:expected(path,value)','            for path,value in IMMUTABLE:expected(path,value)\n            expected(Path(graph[\'source52_native_receipt\']),parent_native_pin)')
body=body.replace('        absent()\n        for row,_,_ in changes:','        absent()\n        expected(Path(graph[\'source52_native_receipt\']),parent_native_pin)\n        for row,_,_ in changes:')
body=body.replace("expected(target,row['final']);os.replace(restore,target)","expected(target,row['final']);absent();os.replace(restore,target)")
body=body.replace("'failed':True,'error_type':type(error).__name__", "'failed':True,'automatic_retry':False,'error_type':type(error).__name__")
write('install_native53.py',header+'\n'+body+"\n\nif __name__=='__main__':main()\n")
write('REUSE.json',{'source52_installer':{'path':str(old),'pin':pin(oldraw)},'source44_helpers':{'path':str(helper44),'pin':pin(helper44.read_bytes())},'stage1_frozen_pin':frozen_pin,'production_execution':False,'original_authority_or_installer_writes':0})
print(json.dumps({'graph_pin':graph_pin,'installer_pin':pin((OWN/'install_native53.py').read_bytes()),'install_authorized':False}))
