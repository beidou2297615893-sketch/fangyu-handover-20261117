import json
from pathlib import Path
STATE=Path('C:\\积木软件工坊\\项目\\方隅公寓客户版\\work\\source53-successor-proposal\\native\\fixtures\\fresh-rollback-idle\\1776cbadb20c48c39f4caf10e43e2ce6\\native-guard-recording.json')
def source_state(pid):
 value=json.loads(STATE.read_text());i=value['index'];items=value['states'];state=items[min(i,len(items)-1)]
 value['index']=i+1;value['calls'].append(state);STATE.write_text(json.dumps(value))
 return {'scope':'fangyu_customer_source_metadata_v1','state':state}
