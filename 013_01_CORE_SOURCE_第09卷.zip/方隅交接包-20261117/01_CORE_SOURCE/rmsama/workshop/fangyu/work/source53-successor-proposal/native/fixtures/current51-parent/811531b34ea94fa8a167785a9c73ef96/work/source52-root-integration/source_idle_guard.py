import json
from pathlib import Path
STATE=Path('C:\\积木软件工坊\\项目\\方隅公寓客户版\\work\\source53-successor-proposal\\native\\fixtures\\current51-parent\\811531b34ea94fa8a167785a9c73ef96\\native-guard-recording.json')
def source_state(pid):
 value=json.loads(STATE.read_text());i=value['index'];items=value['states'];state=items[min(i,len(items)-1)]
 value['index']=i+1;value['calls'].append(state);STATE.write_text(json.dumps(value))
 return {'scope':'fangyu_customer_source_metadata_v1','state':state}
