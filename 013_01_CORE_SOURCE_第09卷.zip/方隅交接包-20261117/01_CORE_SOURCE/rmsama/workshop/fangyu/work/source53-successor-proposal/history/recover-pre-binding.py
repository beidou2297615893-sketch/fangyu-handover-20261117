"""Recover exact intermediate r1 bytes from the explicit binding delta + pins.
This is recovery of overwritten owned proposal artifacts, not production repair.
"""
from pathlib import Path
import hashlib,json
OWN=Path(__file__).resolve().parent.parent
HISTORY=OWN/'history/r1-pre-binding'
HISTORY.mkdir(parents=True,exist_ok=True)
def pin(raw):return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest().upper()}
def raw(value):return (json.dumps(value,ensure_ascii=False,indent=2)+'\n').replace('\n','\r\n').encode('utf-8')
frozen=json.loads((OWN/'FROZEN.json').read_text(encoding='utf-8'))
for path in frozen['files']:
    source=Path(path);(HISTORY/source.name).write_bytes(source.read_bytes())
block="""    # Caller helper is itself pinned by the thin launcher. Assign the already
    # fixed manifest pin AFTER checked CAS load, avoiding CAS <-> manifest hash
    # recursion. The proposal stays false/None, and cannot reach this branch.
    module.AUTHORITY_PIN=MANIFEST_PIN
"""
for name in ('helper-delta.txt','next_open_source53.py'):
    text=(HISTORY/name).read_text(encoding='utf-8').replace(block,'').replace('if module.JOIN_AUTHORIZED is not True or module.AUTHORITY_PIN is not None or not module.proof(MANIFEST_PIN):','if module.JOIN_AUTHORIZED is not True or module.AUTHORITY_PIN!=MANIFEST_PIN:')
    (HISTORY/name).write_bytes(text.encode() if name.endswith('.txt') else text.replace('\n','\r\n').encode())
oldhelper=pin((HISTORY/'next_open_source53.py').read_bytes())
assert oldhelper['sha256']=='C755CF769CF4A3FEA7DFCF24496F23DED99D2FA0FF245831F63B8F6F23F932FD'
oldlauncher=(HISTORY/'source_next_open_launcher.py').read_text(encoding='utf-8')
oldlauncher=oldlauncher.replace(next(x for x in oldlauncher.splitlines() if x.startswith('NEWEST_PIN = ')),'NEWEST_PIN = '+repr(oldhelper))
(HISTORY/'source_next_open_launcher.py').write_text(oldlauncher,encoding='utf-8')
assert pin((HISTORY/'source_next_open_launcher.py').read_bytes())['sha256']=='BE3CBA92B605D98DDDE89597ECB086A7F17B975B70C2E4FA45B43F8731FC1F5A'
report=(HISTORY/'REPORT.md').read_text(encoding='utf-8');report=report.split('\n\n新manifest pin由',1)[0]
for endings in range(5):
    candidate=report.rstrip('\n')+'\n'*endings
    for ending_style in ('\n','\r\n'):
        candidate_bytes=candidate.replace('\n',ending_style).encode()
        if pin(candidate_bytes)['sha256']=='6FD5D64482F500AB717AA1139EDB02B78192AF19432F7E2A3597A59CAB74AAF8':
            report=candidate_bytes.decode();break
(HISTORY/'REPORT.md').write_bytes(report.encode())
assert pin((HISTORY/'REPORT.md').read_bytes())['sha256']=='6FD5D64482F500AB717AA1139EDB02B78192AF19432F7E2A3597A59CAB74AAF8'
install=json.loads((HISTORY/'INSTALL-PROPOSAL.json').read_text(encoding='utf-8'))
install['native_targets'][0]['candidate_pin']=oldhelper
install['native_targets'][1]['candidate_pin']=pin((HISTORY/'source_next_open_launcher.py').read_bytes())
(HISTORY/'INSTALL-PROPOSAL.json').write_bytes(raw(install))
for path in frozen['files']:frozen['files'][path]=pin((HISTORY/Path(path).name).read_bytes())
data=raw(frozen)
assert pin(data)=={'bytes':7629,'sha256':'617886F2A5B8B66B0D5BE00AE9AB509BE60704F3AE42B5BB1D1E44CF5E17CB45'},pin(data)
(HISTORY/'FROZEN.json').write_bytes(data)
(HISTORY/'RECOVERY-NOTE.json').write_bytes(raw({'schema':'source53_owned_intermediate_history_recovery_v1','method':'reverse explicit helper bind delta, reconstruct file bytes and frozen metadata; all known old hashes matched','old_frozen_pin':pin(data),'original_frozen_paths_in_metadata_are_historical':True,'production_files_changed':False}))
print(json.dumps({'restored_old_frozen_pin':pin(data),'history':str(HISTORY)}))
