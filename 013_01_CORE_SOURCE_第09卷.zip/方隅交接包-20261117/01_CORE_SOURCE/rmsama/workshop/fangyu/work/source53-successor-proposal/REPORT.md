# Source53 后继候选：已形成可审代码，未安装

本目录准备三目标 CAS、正常下一开 53 协调增量、薄 launcher 接线及固定父图。候选 production `JOIN_AUTHORIZED=False` / `AUTHORITY_PIN=None`，新 gate/authority proposal 的 `join_authorized=false`；没有发布/改写旧 authority，没有正式 SOURCE 写入、安装、运行原入口或查询原占用。Source52 首次 HOLD 继续保留，本候选不会触发它重试。

直接父：MJS 407892/9CF6B4E2 → 409955/C8C52A07；两份 CSS 均100324/3534C301 →105043/6E76B4A2，本地 mirror 不表示云部署。470 prospective protection 从不可变52 prepared protection462 + 9targets - 1重叠MJS构成；準备只读取公有代码/metadata，不对470真实源文件执行读取或hash。

复用：Source44 已审 blob/pin/expected/no_link_parent/prepared_temp；Source52 CAS 原 proof、固定 guard 调用、existing byte0/length1 OS lock 子进程核对、original_main_dead；helper52 `_layer` 原父backup/raw receipt闭合算法。新53增量包括三目标CAS、跨50/51/52/53 overlay读回与累计保护闭合。正常下一开候选保50→51→52→53同锁顺序，不调用会提前exec的51/52 before_normal_open；最后保持原 `-X utf8 -B -I` 重开参数。任何 STARTED 无成功或 FAILED 保留并停止，不自动 reapply。

launcher 的直接父是**未来已经安装的52 launcher 4987/598E11A5**，不是当前已装51 launcher；53 helper要求新建且不覆盖旧50/51/52 helpers。这里只提供接入提案，没有53 native installer，也没有用新launcher一跳绕过52安装门。新53正式authority/精确native安装图、真实availability、52真实安装及正常全链读回均待Root后续处理。

自有代表结果见 REPRESENTATIVE.json。真实执行部分：53三目标用已审UI实际字节替换，三份原父backup、累计原backup/rawlineage读回、Windows existing byte0 length1 OS锁及child probe、临时文件清理、phase拒绝及原FAILED保留。录制部分：全部50/51/52已装历史层、公有保护源合成字节、guard idle/live/unknown及owned entry PID dead。直接MJS/CSS父和53候选用真实公有代码字节。每次执行前全部私态Path、ancestor refs、guard重定址到自有fixture根；无原root上下文运行。

行为代表包括 unbound CAS/helper 在metadata/guard前立即拒绝、成功与累计读回、原50backup漂移拒绝、初始live/unknown在STARTED/backup前拒绝、bad-parent、raw50→51漂移、fresh replace unknown与rollback live、fresh seal unknown与rollback unknown，以及fresh rollback idle实际恢复原父。失败代表保留FAILED、无success、无自动重试，临时文件清理。最初 FIRST-RED 只是候选文件尚不存在的FileNotFoundError，不是事务缺陷复现。freeze首次父launcher长hash笔误被断言拒绝，工具实读父代码后已纠正；没有父源码修改。

未验证：真实50/51/52业务安装及历史真实父backup闭合、原occupancy/PID、完整正常50→53执行、source53 native安装/生产加载/回退恢复、真实GUI像素/键盘/原生表单和人工认可、云部署与完整商业。440指其他原named functions（含业务及视觉），不表示440项业务验收。已审UI和旧失败不改写；完整R01–R25及原商业未验继续。

非作者53增量审待Root安排；冻结不等于授权、安装或用户验收。

新manifest pin由未来已固定hash的53正常协调helper在checked CAS加载后赋值，CAS默认None；manifest仍绑定CAS固定hash。这避免CAS和manifest相互嵌入hash造成封存循环。生产helper/CAS各自false，均须Root未来独立生成新批准版本。本阶段只证false提前拒绝及owned CAS事务，授权后helper全链接线仍未运行。
