import json
from pathlib import Path
STATE=Path('C:\\积木软件工坊\\项目\\方隅公寓客户版\\work\\source53-successor-proposal\\native\\fixtures\\fresh-rollback-live\\786e43dc6a0c4369b76f1390797e3127\\native-guard-recording.json')
def source_state(pid):
 value=json.loads(STATE.read_text());i=value['index'];items=value['states'];state=items[min(i,len(items)-1)]
 value['index']=i+1;value['calls'].append(state);STATE.write_text(json.dumps(value))
 return {'scope':'fangyu_customer_source_metadata_v1','state':state}
