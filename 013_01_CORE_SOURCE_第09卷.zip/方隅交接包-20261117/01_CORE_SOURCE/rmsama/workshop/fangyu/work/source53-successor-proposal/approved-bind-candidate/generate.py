"""One-shot, owned staging only. Never imports/calls enabled production code.
All enabled approval values are signing proposals pending Root acceptance.
"""
import ast,hashlib,json
from pathlib import Path
PROJECT=Path('C:/积木软件工坊/项目/方隅公寓客户版')
OWN=Path(__file__).resolve().parent
BASE=OWN.parent
FUTURE=PROJECT/'work/source53-root-integration'
AUDITS=PROJECT/'work/product-upgrade-20261009/audits'
STAGING=OWN/'staging-r2'
def pin(raw):return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest().upper()}
def json_bytes(value):return (json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode('utf-8')
def functions(raw):
    text=raw.decode('utf-8-sig')
    return {x.name:ast.get_source_segment(text,x) for x in ast.parse(text).body if isinstance(x,(ast.FunctionDef,ast.AsyncFunctionDef))}
def constants(raw,changes,extra=''):
    text=raw.decode('utf-8-sig');delta=[]
    for x in reversed(ast.parse(text).body):
        if isinstance(x,ast.Assign) and len(x.targets)==1 and isinstance(x.targets[0],ast.Name) and x.targets[0].id in changes:
            name=x.targets[0].id;old=ast.get_source_segment(raw.decode('utf-8-sig'),x)
            new=name+'='+changes.pop(name)
            assert text.count(old)==1,(name,old)
            text=text.replace(old,new,1);delta.append({'constant':name,'old':old,'new':new})
    assert not changes,changes
    result=(text+extra).encode('utf-8')
    assert functions(raw)==functions(result),'function bytes changed'
    ast.parse(result)
    return result,delta
def main():
    baseline={BASE/'FROZEN.json':{'bytes':7629,'sha256':'46CAA63AA94EB08709A306D2B46FA9C66EFB383905EFBEE3E1D658CDE55C10FB'},BASE/'native/FROZEN.json':{'bytes':6415,'sha256':'562FDC64968F6935EE547E84769FFEC0FBD968A7CE6E9981EB06FA504068784E'}}
    for path,proof in baseline.items():
        assert pin(path.read_bytes())==proof
        doc=json.loads(path.read_bytes())
        for source,value in doc['files'].items():assert pin(Path(source).read_bytes())==value
    STAGING.mkdir(parents=True,exist_ok=False)
    artifacts=[];deltas={};pins={}
    def emit(future,data,step,alias_of=None):
        relative=future.relative_to(PROJECT);target=STAGING/relative
        assert target.resolve().is_relative_to(STAGING.resolve())
        target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
        proof=pin(data);pins[str(future)]=proof
        artifacts.append({'future':str(future),'stage':str(target),'pin':proof,'step':step,'alias_of':str(alias_of) if alias_of else None})
        return proof
    # 0. Prepared remains exact original false metadata; no original manifest edit.
    prepared_raw=(BASE/'PREPARED.json').read_bytes();prepared=json.loads(prepared_raw)
    assert prepared['join_authorized'] is False and len(prepared['targets'])==3 and len(prepared['protected'])==470
    prepared_pin=emit(FUTURE/'PREPARED.json',prepared_raw,0)
    base_pin=prepared['base_manifest_pin']
    for ref in prepared['ancestors']:assert pin(Path(ref['authority']).read_bytes())==ref['authority_pin']
    # 1. CAS has no manifest literal: fixed checked caller supplies it later.
    raw=(BASE/'join-source53-reviewed.py').read_bytes()
    cas,delta=constants(raw,{'OWN':"WORK/'source53-root-integration'",'AUTHORITY':"AUDITS/'source53-manifest.json'",'APPROVAL':"AUDITS/'source53-final-root-read.json'",'JOIN_AUTHORIZED':'True','AUTHORITY_PIN':'None','PREPARED_PIN':repr(prepared_pin)})
    deltas['CAS']=delta;cas_pin=emit(AUDITS/'join-source53-reviewed.py',cas,1)
    emit(FUTURE/'join-source53-reviewed.py',cas,1,AUDITS/'join-source53-reviewed.py')
    # 2/3. New53 signing proposals only. Existing50/51/52 bytes never written.
    gate=json.loads((BASE/'GATE-PROPOSAL.json').read_bytes())
    gate.update({'join_authorized':True,'join_script_pin':cas_pin,'prepared_manifest_pin':prepared_pin,
        'independent_code_review_passed':True,'independent_actual_qa_review_passed':True,'join_script_review_passed':True,
        'status':'STAGED_ROOT_SIGNING_PROPOSAL','proposed_values_not_actual_Root_signature':True,'Root_acceptance_pending':True,
        'additional_evidence':[{'path':str(p),'pin':v} for p,v in baseline.items()]})
    gate_raw=json_bytes(gate);gate_pin=emit(AUDITS/'source53-final-root-read.json',gate_raw,2)
    emit(FUTURE/'GATE-PROPOSAL.json',gate_raw,2,AUDITS/'source53-final-root-read.json')
    authority=json.loads((BASE/'AUTHORITY-PROPOSAL.json').read_bytes())
    authority.update({'join_authorized':True,'approval_pin':gate_pin,'join_script_pin':cas_pin,
        'status':'STAGED_ROOT_SIGNING_PROPOSAL','proposed_values_not_actual_Root_signature':True,'Root_acceptance_pending':True})
    authority_raw=json_bytes(authority);authority_pin=emit(AUDITS/'source53-manifest.json',authority_raw,3)
    emit(FUTURE/'AUTHORITY-PROPOSAL.json',authority_raw,3,AUDITS/'source53-manifest.json')
    # 4. Helper carries manifest pin; manifest never carries helper pin.
    raw=(BASE/'next_open_source53.py').read_bytes()
    helper,delta=constants(raw,{'OWN':"WORK/'source53-root-integration'",'CAS':"WORK/'product-upgrade-20261009/audits/join-source53-reviewed.py'",'CAS_PIN':repr(cas_pin),'JOIN_AUTHORIZED':'True','MANIFEST_PIN':repr(authority_pin)})
    deltas['helper']=delta;helper_pin=emit(FUTURE/'next_open_source53.py',helper,4)
    # 5. Normal thin launcher carries helper pin and same installed helper path.
    raw=(BASE/'source_next_open_launcher.py').read_bytes()
    launcher,delta=constants(raw,{'NEWEST_PIN':repr(helper_pin)})
    deltas['launcher']=delta;launcher_pin=emit(FUTURE/'source_next_open_launcher.py',launcher,5)
    # 6. A source package freeze closes business bindings; excludes native graph,
    # gate and installer, so those may bind this package without reverse hash.
    package={'schema':'source53_bound_source_package_proposal_v1','source_batch':53,'status':'STAGED_NOT_PUBLISHED','Root_acceptance_pending':True,
        'files':[{'path':x['future'],'pin':x['pin']} for x in artifacts],
        'baseline':[{'path':str(p),'pin':v} for p,v in baseline.items()],
        'prepared_join_authorized':False,'production_installed':False}
    package_pin=emit(FUTURE/'SOURCE-PACKAGE-FROZEN.json',json_bytes(package),6)
    # 7. Native graph does not include installer/gate proof. Current52 only.
    graph=json.loads((BASE/'native/GRAPH-PROPOSAL.json').read_bytes())
    graph.update({'status':'STAGED_ROOT_SIGNING_PROPOSAL','stage1_frozen':{'path':str(FUTURE/'SOURCE-PACKAGE-FROZEN.json'),'pin':package_pin},
        'stage1_files':[{'path':str(FUTURE/name),'pin':pins[str(FUTURE/name)]} for name in ('join-source53-reviewed.py','next_open_source53.py','source_next_open_launcher.py','AUTHORITY-PROPOSAL.json','GATE-PROPOSAL.json')],
        'targets':[{'target':str(PROJECT/'work/desktop-self-use-entry/next_open_source53.py'),'candidate':str(FUTURE/'next_open_source53.py'),'parent':None,'final':helper_pin},
            {'target':str(PROJECT/'work/desktop-self-use-entry/source_next_open_launcher.py'),'candidate':str(FUTURE/'source_next_open_launcher.py'),'parent':graph['future52_launcher_parent'],'final':launcher_pin}],
        'runtime_ready':False,'Root_acceptance_pending':True})
    graph_pin=emit(FUTURE/'native/GRAPH.json',json_bytes(graph),7)
    # 8. Root native signing proposal; no business/App invocation authorization.
    native_gate=json.loads((BASE/'native/GATE-PROPOSAL.json').read_bytes())
    native_gate.update({'install_authorized':True,'graph_pin':graph_pin,'stage1_frozen_pin':package_pin,'independent_native_review_passed':True,
        'status':'STAGED_ROOT_SIGNING_PROPOSAL','proposed_values_not_actual_Root_signature':True,'Root_acceptance_pending':True})
    native_gate_pin=emit(FUTURE/'native/NATIVE-ROOT-APPROVAL.json',json_bytes(native_gate),8)
    # 9. Installer may contain graph/gate pins; neither reversely binds installer.
    raw=(BASE/'native/install_native53.py').read_bytes()
    installer,delta=constants(raw,{'OWN':"WORK/'source53-root-integration/native'",'GRAPH':"OWN/'GRAPH.json'",'GRAPH_PIN':repr(graph_pin),'GATE':"OWN/'NATIVE-ROOT-APPROVAL.json'",'GATE_PIN':repr(native_gate_pin),'HELPER_PIN':repr(helper_pin),'LAUNCHER_PIN':repr(launcher_pin),'INSTALL_AUTHORIZED':'True'})
    deltas['native_installer']=delta;emit(FUTURE/'native/install_native53.py',installer,9)
    plan={'schema':'source53_enabled_binding_staging_plan_v1','status':'OWNED_STAGED_ROOT_SIGNING_PROPOSAL_ONLY','production_executed':False,'published':False,'installed':False,'Root_acceptance_pending':True,
        'dependency_order':['unchanged prepared false','enabled CAS no manifest literal','Root business gate','business manifest','helper fixed manifest/CAS pins','launcher fixed helper pin','source package freeze excluding native','native graph','Root native gate','enabled installer fixed native graph/gate'],
        'artifacts':artifacts,'constant_deltas':deltas,'all_original_function_bytes_preserved':True,
        'new53_audit_aliases_required_by_existing_native_interface':True,'old50_51_52_authority_writes':0,'original_source_or_audit_writes':0,
        'actual_actions_still_require':['Root independent binding review and explicit actual signature/publication','new genuine availability','actual52 native installed dependency','actual source cumulative readback','native UI acceptance']}
    if (OWN/'PLAN.json').exists():
        previous=json.loads((OWN/'PLAN.json').read_bytes())
        if previous['artifacts'][0]['stage'].startswith(str(OWN/'staging-r1')):
            (OWN/'PLAN-r1-HISTORICAL.json').write_bytes((OWN/'PLAN.json').read_bytes())
    (OWN/'PLAN.json').write_bytes(json_bytes(plan))
    print(json.dumps({'artifacts':len(artifacts),'stage':str(STAGING),'all_original_function_bytes_preserved':True,'production_executed':False}))
if __name__=='__main__':main()
