"""Freeze only this proposal and explicitly owned representative artifacts."""
import ast,hashlib,json
from pathlib import Path
OWN=Path(__file__).resolve().parent
def pin(raw):return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest().upper()}
def write(name,value):
    (OWN/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
prepared=json.loads((OWN/'PREPARED.json').read_text(encoding='utf-8'))
report=json.loads((OWN/'REPRESENTATIVE.json').read_text(encoding='utf-8'))
assert report['original_root_execution'] is False and report['status']=='PASS_LIMITED_OWNED_REPRESENTATIVE'
reuse=json.loads((OWN/'REUSE.json').read_text(encoding='utf-8'))
for path,proof in reuse['old_code_pins'].items():assert pin(Path(path).read_bytes())==proof
for ref in prepared['ancestors']:assert pin(Path(ref['authority']).read_bytes())==ref['authority_pin']
base=Path('C:/积木软件工坊/项目/方隅公寓客户版/work/source52-root-integration/source_next_open_launcher-final.py')
parent=pin(base.read_bytes())
assert parent=={'bytes':4987,'sha256':'598E11A541AADBBEB8A1CA55E6169B5D793C5D80D875603086B773E2671DA432'}
write('INSTALL-PROPOSAL.json',{'schema':'source53_future_native_connection_proposal_v1','join_authorized':False,'installed':False,'installer_present':False,'requires_actual_installed52_before_native53':True,'native_targets':[{'target':'work/desktop-self-use-entry/next_open_source53.py','expected_absent':True,'candidate':str(OWN/'next_open_source53.py'),'candidate_pin':pin((OWN/'next_open_source53.py').read_bytes())},{'target':'work/desktop-self-use-entry/source_next_open_launcher.py','parent_state':'future52 installed; never current51 one-hop','future_parent':parent,'candidate':str(OWN/'source_next_open_launcher.py'),'candidate_pin':pin((OWN/'source_next_open_launcher.py').read_bytes())}],'old_helper_writes':0,'old_authority_writes':0,'requires':['new53 independent reviewed exact authority','new genuine availability','exact future52 native/helper/authority/actual receipt binding','same existing OS lock + fresh original guard','normal cumulative readback'],'source52_first_HOLD_preserved':True})
write('DELTA.json',{'schema':'source53_successor_delta_v1','status':'CANDIDATE_ONLY_UNBOUND','business_targets':prepared['targets'],'protected_count':470,'code_reuse':reuse,'new_behavior':['exact-three-target CAS and explicit newly covered CSS parents','immutable 50/51/52 layers plus 53 original backups and raw receipt chain','fresh guard before STARTED/backups/replace/seal/ownrollback','same normal-open existing byte lock and final original fresh flags','STARTED-without-success/FAILED stop before ancestor replay','new53 helper and future52 launcher successor candidate'],'representative_cases':len(report['results']),'original_source_writes':0,'installed':False,'published':False,'native_GUI_verified':False,'pending':['independent53 review','new53 production authority binding','exact native installer candidate and actual installed52 dependency','genuine new availability','native visual/keyboard acceptance']})
names=['PLAN.md','REPORT.md','build.py','freeze.py','cas-delta.txt','helper-delta.txt','join-source53-reviewed.py','next_open_source53.py','source_next_open_launcher.py','PREPARED.json','GATE-PROPOSAL.json','AUTHORITY-PROPOSAL.json','REUSE.json','FIRST-RED.json','representative.py','REPRESENTATIVE.json','INSTALL-PROPOSAL.json','DELTA.json']
for name in names:
    if name.endswith('.py'):ast.parse((OWN/name).read_text(encoding='utf-8'))
files={str(OWN/name):pin((OWN/name).read_bytes()) for name in names}
artifacts={}
for result in report['results']:
    root=result.get('root')
    if root:
        root=Path(root);assert root.resolve().is_relative_to((OWN/'fixtures').resolve())
        for path in root.glob('work/product-upgrade-20261009/audits/source53-*.json'):
            artifacts[str(path)]=pin(path.read_bytes())
write('FROZEN.json',{'schema':'source53_successor_proposal_frozen_v1','status':'FROZEN_CANDIDATE_ONLY','join_authorized':False,'production_authority_bound':False,'business_target_count':3,'prospective_protected_count':470,'files':files,'owned_artifacts':artifacts,'source_installed':False,'source52_installer_guard_PID_preflight_calls':0,'normal_full_chain_executed':False,'real_OS_lock_on_owned_fixture':True,'old_layers_guard_PID_recorded':True,'native_visual_accepted':False,'pending':['independent53 increment review','new fixed production authority/native graph','new genuine availability','actual cumulative lineage and native UI acceptance']})
print(json.dumps({'frozen':str(OWN/'FROZEN.json'),'pin':pin((OWN/'FROZEN.json').read_bytes()),'representative_cases':len(report['results'])}))
