"""Public-code preparation only. Outputs stay in this owned proposal directory."""
import ast,hashlib,json
from pathlib import Path
ROOT=Path('C:/积木软件工坊/项目/方隅公寓客户版')
OWN=Path(__file__).resolve().parent
def pin(raw):return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest().upper()}
def write(name,value):
    path=OWN/name
    path.write_text(value if isinstance(value,str) else json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    return pin(path.read_bytes())
def selected(path,names):
    raw=path.read_bytes();text=raw.decode('utf-8-sig');tree=ast.parse(text)
    defs={x.name:ast.get_source_segment(text,x) for x in tree.body if isinstance(x,ast.FunctionDef) and x.name in names}
    assert set(defs)==set(names)
    return '\n\n'.join(defs[x] for x in names)+'\n'
proposal=json.loads((ROOT/'work/source53-collection-ui-candidate/LINEAGE-PROPOSAL.json').read_text(encoding='utf-8-sig'))
source52=ROOT/'work/source52-root-integration'
old52=source52/'join-source52-reviewed-final.py'
helper44=ROOT/'work/product-upgrade-20261009/audits/join-source44-reviewed.py'
assert pin(helper44.read_bytes())=={'bytes':9601,'sha256':'5F5E3EA22AF7C1FA0FEA71CFEFDA12A9D669C190D5470960901029BF8F4750FB'}
assert pin(old52.read_bytes())=={'bytes':30339,'sha256':'277723C7F097EF8DE0B8C767FC1FD717B4E3117A2C311630B352FD181A241812'}
assert pin((source52/'next_open_source52-final.py').read_bytes())=={'bytes':15464,'sha256':'18F99253AF933F1964A0A1F27F78F23D045C2C46363C4A252C22E65761E01680'}
refs=[]
for batch,prep in ((50,'overnight-commercial-20261014/source50-preparation'),(51,'source51-root-integration'),(52,'source52-root-integration')):
    audits=ROOT/'work/product-upgrade-20261009/audits'
    authority=audits/f'source{batch}-manifest.json'
    refs.append({'batch':batch,'authority':str(authority),'authority_pin':pin(authority.read_bytes()),'approval':str(audits/f'source{batch}-final-root-read.json'),'prepared':str(ROOT/'work'/prep/'PREPARED.json'),'receipt':str(audits/f'source{batch}-joined.json'),'started':str(audits/f'source{batch}-next-open-started.json'),'failed':str(audits/f'source{batch}-join-failed.json')})
prepared={'schema':'source53_owner_prepared_v1','source_batch':53,'join_authorized':False,'instance_id':'d075ac9c039e44038ddbc6f3e753d73c','base_manifest_pin':refs[-1]['authority_pin'],'new_directories':[],
 'targets':[{'target':r['target'],'candidate':r['candidate'],'parent':r['future_parent'],'candidate_pin':r['candidate_pin']} for r in proposal['targets']],
 'protected':proposal['prospective_protected'],'ancestors':refs,'evidence':[{'path':str(ROOT/'work/source53-collection-ui-candidate/FROZEN.json'),'pin':proposal['frozen53']['pin']}]}
assert len(prepared['protected'])==470
for row in prepared['targets']:assert pin(Path(row['candidate']).read_bytes())==row['candidate_pin']
prep_pin=write('PREPARED.json',prepared)
header='''"""Source53 isolated CAS candidate. Import is inert; unauthorized by default.
Reviewed production bind must be a new authority. No old authority is rewritten.
"""
import ast,ctypes,hashlib,json,os,stat,subprocess,sys,tempfile,types,uuid
from ctypes import wintypes
from pathlib import Path
PROJECT=Path('C:/积木软件工坊/项目/方隅公寓客户版')
WORK=PROJECT/'work'
OWN=WORK/'source53-successor-proposal'
AUDITS=WORK/'product-upgrade-20261009/audits'
PREPARED=OWN/'PREPARED.json'
AUTHORITY=OWN/'AUTHORITY-PROPOSAL.json'
APPROVAL=OWN/'GATE-PROPOSAL.json'
STARTED=AUDITS/'source53-next-open-started.json'
RECEIPT=AUDITS/'source53-joined.json'
FAILED=AUDITS/'source53-join-failed.json'
PILOT=WORK/'self-operating-pilot'
ENTRY=WORK/'desktop-self-use-entry/desktop_entry.py'
INSTANCE_ID='d075ac9c039e44038ddbc6f3e753d73c'
JOIN_AUTHORIZED=False
AUTHORITY_PIN=None
PREPARED_PIN=PREP_LITERAL
ANCESTORS=ANCESTOR_LITERAL
SOURCE_GUARD=WORK/'source52-root-integration/source_idle_guard.py'
SOURCE_GUARD_PIN={'bytes':5948,'sha256':'1E97220595CCD6954F67FAABFCAE83E52734D4EE59188F0657C9B0363FBA3AA1'}
ALLOWED=frozenset(('app/src/web/workspace/self-operating-read.mjs','app/src/web/workspace/upgrade-ui.css','cloud/workspace/site/upgrade-ui.css'))
EXPECTED_TARGET_PINS=TARGET_LITERAL
'''.replace('PREP_LITERAL',repr(prep_pin)).replace('ANCESTOR_LITERAL',repr(refs)).replace('TARGET_LITERAL',repr({Path(r['target']).relative_to(ROOT/'work').as_posix():(r['parent'],r['candidate_pin']) for r in prepared['targets']}))
support=selected(helper44,['blob','pin','expected','no_link_parent','prepared_temp'])
support+=selected(old52,['proof','require_source_idle','existing_lock_is_held','original_main_dead'])
# Same reviewed _layer algorithm, taking this module as its byte-reader adapter.
support+=selected(source52/'next_open_source52-final.py',['_layer'])
custom=(OWN/'cas-delta.txt').read_text(encoding='utf-8')
cas_pin=write('join-source53-reviewed.py',header+'\n'+support+'\n'+custom)
gate={'schema':'source53_final_root_read','source_batch':53,'join_authorized':False,'base_manifest_pin':refs[-1]['authority_pin'],'prepared_manifest_pin':prep_pin,'join_script_pin':cas_pin,'source_guard_pin':{'bytes':5948,'sha256':'1E97220595CCD6954F67FAABFCAE83E52734D4EE59188F0657C9B0363FBA3AA1'},'independent_code_review_passed':False,'independent_actual_qa_review_passed':False,'join_script_review_passed':False,'next_normal_open_only':True,'customer_database_opened':False,'session_copied':False,'deployment_or_packaging_performed':False,'additional_evidence':[]}
gate_pin=write('GATE-PROPOSAL.json',gate)
authority={'schema':'source53_next_open_manifest_v1','source_batch':53,'join_authorized':False,'instance_id':prepared['instance_id'],'base_manifest_pin':refs[-1]['authority_pin'],'approval_pin':gate_pin,'join_script_pin':cas_pin,'source_guard_pin':gate['source_guard_pin'],'targets':[{'path':r['target'],'parent_pin':r['parent'],'final_pin':r['candidate_pin']} for r in prepared['targets']],'protected':prepared['protected']}
write('AUTHORITY-PROPOSAL.json',authority)
helper_pin=write('next_open_source53.py',(OWN/'helper-delta.txt').read_text(encoding='utf-8').replace('CAS_LITERAL',repr(cas_pin)))
launcher=(source52/'source_next_open_launcher-final.py').read_text(encoding='utf-8-sig')
launcher=launcher.replace("# Root fills these exact pins after the deferred wrapper/code/config review.","NEWEST = PROJECT/'work/desktop-self-use-entry/next_open_source53.py'\nNEWEST_PIN = "+repr(helper_pin)+"\n# New candidate remains unauthorized and uninstalled.")
launcher=launcher.replace("entry_pin = latest.reviewed_entry_pin_if_joined(helper, successor) or entry_pin", "newest = _load(NEWEST, NEWEST_PIN, 'source53_fixed_next_open')\n                entry_pin = newest.reviewed_entry_pin_if_joined(helper, successor, latest) or entry_pin",1)
launcher=launcher.replace("        entry_pin = latest.reviewed_entry_pin_if_joined(helper, successor) or entry_pin", "        newest = _load(NEWEST, NEWEST_PIN, 'source53_fixed_next_open')\n        entry_pin = newest.reviewed_entry_pin_if_joined(helper, successor, latest) or entry_pin")
launcher=launcher.replace('result = latest.before_normal_open(entry, helper, successor)','result = newest.before_normal_open(entry, helper, successor, latest)')
write('source_next_open_launcher.py',launcher)
write('REUSE.json',{'old_code_pins':{str(p):pin(p.read_bytes()) for p in (helper44,old52,source52/'next_open_source52-final.py',source52/'source_idle_guard.py')},'extracted_definitions':'Source44 byte reader/temp; Source52 proof/OS byte-lock/pid metadata/guard + helper52 _layer','production_io_at_import':False,'production_join_authorized':False,'original_source_writes':0})
print(json.dumps({'prepared_targets':len(prepared['targets']),'protected':len(prepared['protected']),'cas_pin':cas_pin,'join_authorized':False}))
