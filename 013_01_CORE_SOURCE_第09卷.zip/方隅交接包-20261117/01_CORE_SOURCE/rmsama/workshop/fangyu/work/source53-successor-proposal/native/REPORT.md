# Source53 native 候选与新 helper 实际接线代表

本子目录独立准备新53 helper + 替换未来已装52 launcher的**两文件**安装候选。阶段1 FROZEN 7629/46CAA63AA94EB08709A306D2B46FA9C66EFB383905EFBEE3E1D658CDE55C10FB 及其文件未再改变。这里没有52安装函数、业务apply、publish或生产执行；52首次HOLD保持。

生产 installer `INSTALL_AUTHORIZED=False`、`GATE_PIN=None`，在读取metadata/guard前即拒绝。新 native graph/授权gate与业务manifest分离；native graph绑定阶段1文件，阶段1不反绑native graph。当前阶段1业务/helper仍false/unbound，即使只翻转native installer也会拒绝未批准业务绑定，不能把本候选叫正式可安装。未来须Root独立批准并生成新的已绑定53业务/helper版本和精确native graph/gate，再有真实52安装及新availability才执行。

复用 fixed52 installer的两file conditional transaction、原父backup/temp、guard transport/fresh replace/seal/ownrollback及失败保留；Source44成熟byte helpers直接取已审函数定义，import inert。精确前置固定50/51/52 helper原pin（52=15464/18F99253）、launcher父仅52=4987/598E11A5；拒绝当前51=4626/AA029206，无53一跳顺带52安装。原52 native成功回执的两文件/pins/禁用副作用字段必须吻合，并在replace/seal前核raw pin不变。新53成功回执保存该52 raw pin。新53failed保留且automatic_retry=false。

Guard沿用原52固定文件5948/1E972205，未修改WQL或原占用门。仅复用原native `absent`的固定thin consumer参数，包含launcher/50/51/52/新53 helper，不扩全机扫描。此guard不证明新53installer本身互斥；本native候选沿用**Root唯一正式写者**前提，没有新增/替换original lock，也不冒全局OS互斥。guard保护消费者与native文件变更，新53业务事务仍由原existing byte0/length1 OS lock串行化。

native自有9个代表 PASS：unbound在metadata前拒绝、两file真实install/backup/temp、50/51/52 helper bytes保留、当前51launcher拒绝、初始live/unknown无backup、fresh replace unknown下rollback idle真实恢复/rollback live及unknown拒绝、fresh seal unknown与rollback unknown。所有所谓install/receipt只在 native/fixtures 根；未来52已装native receipt、stage1批准/绑定及guard全部录制，未执行原52installer/guard/WMI/PID或new53原生App。

另 `binding-owned/REPRESENTATIVE.json` 实际运行新53 helper `_cas` 和 `before_normal_open`：checked CAS加载后固定manifest pin赋值成功，真实owned现有byte锁与child probe、三file实际CAS、原父backup与累计50/51/52/53 readback完成，最后记录原 `-X utf8 -B -I` exec请求。错误固定manifest pin在preflight/guard/STARTED前hold。旧50/51/52已装层与legacy plan/readback callbacks、entry preflight/PID/guard和final exec明确录制；没有启动App，不是生产normal完整50→53证明。

制作期间首次native代表发现批次替换误伤52 dependency schema，已修仅认52原成功；第二次发现fixture缺owned backups父目录，已补fixture。两次发生在自有根，均在backup前停止，没有生产动作。后续9 native + 新helper绑定/错误pin代表实际通过。关键原失败保留，新事实仅写本子目录。

未验证：Root批准的生产53 revision/authorities/native gate、原52实际安装、原occupancy与真实cumulative receipts/backups、完整normal50→53与53原生加载、UI像素/焦点/原生表单/人工认可、云端/真实平台/账号/商业完整验收。阶段1与本候选需分别非作者审；不能把准备/合成成功称已加载。
