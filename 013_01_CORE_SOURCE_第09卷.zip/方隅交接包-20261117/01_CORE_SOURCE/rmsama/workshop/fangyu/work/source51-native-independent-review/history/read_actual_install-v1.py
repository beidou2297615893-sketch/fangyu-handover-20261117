"""Read installed public bytes and original backup; no loader/CAS/App calls."""
from pathlib import Path
import ast,hashlib,json,os,stat

HERE=Path(__file__).resolve().parent
WORK=HERE.parent;PROJECT=WORK.parent
OWN=WORK/'source51-root-integration';AUDITS=WORK/'product-upgrade-20261009/audits'
ENTRY=WORK/'desktop-self-use-entry'
pin=lambda raw:{'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest().upper()}


def ordinary(path):
    current=PROJECT
    for part in ('',*path.relative_to(PROJECT).parts):
        if part:current=current/part
        info=current.lstat()
        assert not current.is_symlink() and not getattr(info,'st_file_attributes',0)&0x400
    assert stat.S_ISREG(info.st_mode) and info.st_nlink==1
    return path.read_bytes()


def record(path,expected):
    raw=ordinary(path);assert pin(raw)==expected
    return {'path':str(path),'pin':pin(raw),'ordinary_single_link':True},raw


def main():
    receipt_path=AUDITS/'source51-native-installed.json'
    receipt_record,raw=record(receipt_path,{'bytes':1702,'sha256':'EE289F148CE3BAD509446A05FC8505A526702FBBE13CCBF53C4178A0487FC87D'})
    receipt=json.loads(raw)
    assert receipt['schema']=='source51_native_installed_v1' and receipt['source_batch']==51
    expected_files={
        ENTRY/'next_open_source51.py':{'bytes':14697,'sha256':'8540B5A0AE7572E5C2DC8A550AD74BA0918FF931C09945E7F802E0FB00F6EEF0'},
        ENTRY/'source_next_open_launcher.py':{'bytes':4626,'sha256':'AA029206565CA20227131E06C200FBAA385C909CA5C21B274CA83477F1992176'},
    }
    assert len(receipt['files'])==2 and {Path(row['path']):row['pin'] for row in receipt['files']}==expected_files
    candidate_names=('next_open_source51-final.py','source_next_open_launcher-final.py')
    files=[]
    for row,candidate_name in zip(receipt['files'],candidate_names):
        path=Path(row['path']);item,raw=record(path,row['pin'])
        candidate,candidate_raw=record(OWN/candidate_name,row['pin'])
        assert raw==candidate_raw
        ast.parse(raw)
        files.append({**item,'exact_approved_candidate':candidate})
    new,existing=receipt['files']
    assert new['parent'] is None and new['backup'] is None
    parent={'bytes':4238,'sha256':'ACDC026618A717A8F87CDE4FDD654819D0B2DC7EF87CF517FB8FFFF57682D599'}
    assert existing['parent']==parent
    backup_root=PROJECT/'backups/source51-native/95679f2f7ea14fd3a36ad44d8bc53f95'
    backup_path=backup_root/'source_next_open_launcher.py'
    assert Path(existing['backup'])==backup_path
    backup,_=record(backup_path,parent)
    assert sorted(path.name for path in backup_root.iterdir())==['source_next_open_launcher.py']
    old_pin={'bytes':18590,'sha256':'6DD31FBCB9864272C329C146DD7EA3E9F74F334131F84DDFEB5E3D63ED8BB611'}
    assert receipt['source50_helper_pin']==old_pin
    old_helper,_=record(ENTRY/'next_open_source.py',old_pin)
    graph,_=record(OWN/'FINAL-GRAPH.json',receipt['graph_pin'])
    assert graph['pin']=={'bytes':1143,'sha256':'CA2BE24A9E46191526521ADFFEFEE32D5F6B75F86F8A026028B5647B825BFE21'}
    peer,_=record(HERE/'FINAL-DELTA-REVIEW.md',receipt['final_delta_review_pin'])
    prior=json.loads((HERE/'FINAL-GRAPH-READBACK.json').read_bytes())
    # Original graph nodes remain fixed; do not rehash original runtime/protection.
    metadata=[]
    for key in ('prepared','gate','manifest','CAS'):
        node=prior['final_nodes'][key]
        item,_=record(Path(node['path']),node['pin']);metadata.append(item)
    installer,_=record(OWN/'install_native.py',{'bytes':7731,'sha256':'870E5BE1417B3BC8CBD3C5045E011893977F970ECA90DA597F80377E91F44FA3'})
    temps=[str(path) for path in ENTRY.glob('.source44-*.tmp')]
    assert not temps
    assert not os.path.lexists(AUDITS/'source51-native-install-failed.json')
    assert receipt['source50_business_apply_calls']==receipt['source51_business_apply_calls']==0
    assert receipt['fixed_flags']==['-X','utf8','-B','-I']
    assert all(receipt[key] is False for key in ('original_App_started_or_stopped','marker_or_platform_grants_changed',
        'database_or_session_copied','desktop_shortcuts_changed','commercial_complete'))
    result={'schema':'source51_native_install_non_author_actual_readback_v1',
        'status':'PASS ACTUAL 2 INSTALLED PUBLIC FILES / 1 PARENT BACKUP / OLD50 HELPER / ZERO STAGING',
        'receipt':receipt_record,'installed_files':files,'parent_backup':backup,
        'backup_directory_only_one_parent':True,'new_helper_without_original_parent':True,
        'original_Source50_helper':old_helper,'fixed_graph':graph,'final_graph_review':peer,
        'unchanged_graph_metadata_nodes':metadata,'actual_authorized_installer':installer,
        'target_adjacent_staging':temps,'installation_failed_receipt_absent':True,
        'installer_receipt_business_payload_counts':{'Source50':0,'Source51':0},
        'review_performed_only_file_readback':True,'wrapper_check_only_called_by_this_review':False,
        'business_QA_or_loader_CAS_or_App_or_original_lock_called':False,'GUI_or_platform_or_model_called':False,
        'formal_source_or_instance_mutations_by_this_review':0,'desktop_links_read_or_modified':False,
        'actual_business_Source50_or51_apply_verified':False,'commercial_acceptance':False}
    path=HERE/'INSTALL-ACTUAL-READBACK.json'
    with path.open('x',encoding='utf-8') as out:out.write(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'readback_pin':pin(path.read_bytes()),'files':2,'parent_backups':1,'old_helper_exact':True,'temps':0}))


if __name__=='__main__':main()
