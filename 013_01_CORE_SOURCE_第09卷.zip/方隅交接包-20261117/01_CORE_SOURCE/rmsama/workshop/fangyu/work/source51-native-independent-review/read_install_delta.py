"""Only installer byte/literal readback; never import or execute it."""
from pathlib import Path
import ast,hashlib,json

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent/'source51-root-integration'
pin=lambda raw:{'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest().upper()}
old_path=ROOT/'history/install_native-v1.py';new_path=ROOT/'install_native.py'
old=old_path.read_bytes();new=new_path.read_bytes()
assert pin(old)=={'bytes':7637,'sha256':'2A2BD1D6961A9704536C0B35C4E8EAC3CC90DB60F0EC32CC9E3ECEBCDCF321E0'}
assert pin(new)=={'bytes':7732,'sha256':'7BF2661DD99CA5579EA1A5C09616C143B07D5D483668934B8C9F74F781E8EDFB'}
before=b"graph=json.loads(blob(OWN/'FINAL-GRAPH.json'))"
after=b"graph=json.loads(expected(OWN/'FINAL-GRAPH.json',{'bytes':1143,'sha256':'CA2BE24A9E46191526521ADFFEFEE32D5F6B75F86F8A026028B5647B825BFE21'}))"
assert old.count(before)==1 and old.replace(before,after)==new
graph_path=ROOT/'FINAL-GRAPH.json';graph=graph_path.read_bytes()
assert pin(graph)=={'bytes':1143,'sha256':'CA2BE24A9E46191526521ADFFEFEE32D5F6B75F86F8A026028B5647B825BFE21'}
assert new.count(b'INSTALL_AUTHORIZED=False')==1
authorized=new.replace(b'INSTALL_AUTHORIZED=False',b'INSTALL_AUTHORIZED=True')
ast.parse(new);ast.parse(authorized)
value={'schema':'source51_native_install_fixed_graph_delta_code_review_v1','status':'PASS ONE LINE FIX + ONE PERMITTED AUTHORITY LITERAL',
    'draft':{'path':str(new_path),'pin':pin(new)},'preserved_parent':{'path':str(old_path),'pin':pin(old)},
    'fixed_graph':{'path':str(graph_path),'pin':pin(graph)},
    'only_FIX_delta':'blob graph replaced by expected exact1143/CA2B fixed graph',
    'authorized_bytes_only_literal':'INSTALL_AUTHORIZED=False -> INSTALL_AUTHORIZED=True',
    'authorized_expected_pin':pin(authorized),'authorized_candidate_written':False,
    'installer_or_CIM_or_CAS_or_App_executed':False,'formal_source_or_data_or_lock_touched':False}
path=HERE/'INSTALL-CODE-DELTA.json'
with path.open('x',encoding='utf-8') as stream:stream.write(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'readback_pin':pin(path.read_bytes()),'authorized_expected_pin':pin(authorized)}))
