"""Independent readback only; do not import/run the loader, CAS or any fixture."""
from pathlib import Path
import ast
import hashlib
import json

HERE = Path(__file__).resolve().parent
STORY = HERE.parent / 'source51-native-state-story'
pin = lambda raw: {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest().upper()}


def record(path):
    return {'path': str(path), 'pin': pin(path.read_bytes())}


def within_story(path):
    assert path.resolve().is_relative_to(STORY.resolve())
    return path


def control(raw, ignored):
    tree = ast.parse(raw)
    for node in tree.body:
        if isinstance(node, ast.Assign) and isinstance(node.targets[0], ast.Name) and node.targets[0].id in ignored:
            node.value = ast.Constant(None)
    return ast.dump(tree).encode()


def main():
    raw = (STORY / 'FROZEN.json').read_bytes()
    assert pin(raw) == {'bytes': 5142, 'sha256': '7FB3E0D9F6A5A8B0BA40336993DD4580ADB3D48D179675BD1218EAF791A71FFA'}
    frozen = json.loads(raw)
    evidence = []
    for item in frozen['evidence']:
        path = within_story(Path(item['path']))
        assert pin(path.read_bytes()) == item['pin']
        evidence.append(item)
    snapshot = json.loads((STORY / 'SNAPSHOT.json').read_bytes())
    for item in snapshot['inputs']:
        assert pin(within_story(Path(item['snapshot'])).read_bytes()) == item['pin']
    assignments = {
        'join-source51-reviewed.py': {'PROJECT', 'BASE_MANIFEST_PIN', 'JOIN_AUTHORIZED'},
        'next_open_source51.py': {'PROJECT', 'BASE_MANIFEST_PIN', 'JOIN_AUTHORIZED', 'MANIFEST_PIN', 'TARGET_PATHS'},
        'next_open_source.py': {'PROJECT', 'ROOT_MANIFEST_PIN', 'TARGET_PATHS'},
        'source_next_open_launcher.py': {'PROJECT', 'SUCCESSOR_PIN', 'HELPER_PIN', 'ENTRY_PARENT_PIN'},
        'desktop_entry.py': {'PROJECT', 'SOURCE', 'PILOT', 'RUNTIME', 'REVIEW', 'REVIEW_SHA', 'ORIGINAL_MARKER_SHA', 'PINS', '_HOST_PATHS', 'HOST_PINS'},
    }
    ast_rows = json.loads((STORY / 'CONTROL-AST-READBACK.json').read_bytes())['items']
    for item in ast_rows:
        path = within_story(Path(item['path']))
        raw = path.read_bytes()
        assert pin(raw) == item['pin']
        allowed = assignments[item['snapshot']]
        assert set(item['assignment_bindings_only']) == allowed
        assert control(raw, allowed) == control((STORY / 'snapshot' / item['snapshot']).read_bytes(), allowed)
        tree = ast.parse(raw)
        project = next(node.value for node in tree.body if isinstance(node, ast.Assign)
                       and isinstance(node.targets[0], ast.Name) and node.targets[0].id == 'PROJECT')
        assert isinstance(project, ast.Call) and isinstance(project.func, ast.Name) and project.func.id == 'Path'
        assert len(project.args) == 1 and Path(ast.literal_eval(project.args[0])).resolve().is_relative_to((STORY / 'runs').resolve())
    first = next(Path(item['path']) for item in frozen['evidence'] if Path(item['path']).name.startswith('01-normal50to51-'))
    second = next(Path(item['path']) for item in frozen['evidence'] if Path(item['path']).name.startswith('02-future-readback-'))
    third = STORY / 'runs/8035b9e79e7c4b42a77f559a835cbb2b/RESULT.json'
    unknown = next(Path(item['path']) for item in frozen['evidence'] if Path(item['path']).name.startswith('UNKNOWN-OS-'))
    one, two, three, unk = [json.loads(path.read_bytes()) for path in (first, second, third, unknown)]
    assert all(item['status'] == 'PASS' for item in (one, two, three, unk))
    assert one['fixture']['invocations'] == {'50': 1, '51': 1}
    assert three['story_selection'] == ['03-unknown-and-rollback'] and len(three['stories']) == 1
    root = within_story(Path(one['fixture']['root']))
    audits = root / 'work/product-upgrade-20261009/audits'
    receipt_records, target_records, backup_records = [], [], []
    for batch in (50, 51):
        path = audits / ('source' + str(batch) + '-joined.json')
        blob = path.read_bytes()
        assert pin(blob) == one['fixture']['source' + str(batch) + '_receipt_pin']
        receipt = json.loads(blob)
        assert len(receipt['targets']) == (55 if batch == 50 else 11)
        for row in receipt['targets']:
            if batch == 51:
                target = within_story(Path(row['target']))
                assert pin(target.read_bytes()) == row['candidate']
                target_records.append(record(target))
            if row['backup'] is not None:
                backup = within_story(Path(row['backup']))
                assert pin(backup.read_bytes()) == row['parent']
                backup_records.append({'batch': batch, **record(backup)})
        receipt_records.append(record(path))
    assert len(backup_records) == 15 and sum(row['batch'] == 51 for row in backup_records) == 10
    assert one['fixture']['OS_events'][-1]['target'].endswith('desktop_entry.py')
    assert one['fixture']['exec_edges'][0]['original_byte_lock_released'] is True
    assert one['fixture']['exec_edges'][0]['argv'][1:5] == ['-X', 'utf8', '-B', '-I']
    assert not list(root.rglob('.source44-*.tmp'))
    assert all(row.get('delta_invocations', 0) == 0 for row in two['events'][1:])
    cases = three['stories'][0]['cases']
    assert all(row['held'] and row['delta_invocations'] == 0 for row in cases[:5])
    assert cases[5]['failure']['backup'] is None and cases[5]['failure']['rollback'] == []
    assert all(row['second_open_held'] and row['delta_invocations'] == 0 for row in cases[5:])
    assert all(row['fixture']['staging_count'] == 0 and not row['fixture']['new_exists'] for row in cases)
    assert all(row['restored'] for row in cases[6]['failure']['rollback'])
    assert sum(not row['restored'] for row in cases[7]['failure']['rollback']) == 1
    assert unk['real_Windows_pid_state'] == 'unknown' and unk['preflight_state'] == 'held_unknown_process'
    assert unk['delta_invocations'] == 0
    output = {
        'schema': 'source51_native_independent_saved_evidence_readback_v1',
        'result': 'PASS CODE + SAVED OWNED STATE EVIDENCE ONLY',
        'frozen': record(STORY / 'FROZEN.json'), 'snapshots': snapshot['inputs'],
        'evidence_pins_checked': evidence,
        'saved_control_AST_only_fixed_owned_constants': True,
        'saved_control_AST_files_verified': len(ast_rows),
        'actual_owned_normal_target_readbacks': target_records,
        'actual_owned_parent_backup_readbacks': backup_records,
        'normal_owned_receipts': receipt_records,
        'normal_owned_adjacent_staging': 0,
        'story_selection': ['first-run normal', 'first-run future', 'story3-only corrected continuation', 'real Windows unknown supplement'],
        'new_QA_or_loader_CAS_execution': False, 'formal_source_or_App_or_lock_touched': False,
        'all_367_or_412_protected_rehashed': False,
        'Source50_CAS': 'explicit synthetic recorder',
        'Source51_CAS_and_OS_lock': 'saved actual own execution; control AST independently matched',
        'preflight_runtime_webview_SQLite': 'synthetic metadata stand-ins',
        'execv': 'recorded edge with actual original byte lock release; no real App exec',
        'final_real_joint_graph_or_install_authorized': False,
    }
    path = HERE / 'READBACK.json'
    with path.open('x', encoding='utf-8') as stream:
        stream.write(json.dumps(output, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'readback': record(path), 'saved_control_AST': len(ast_rows),
                      'normal_targets': len(target_records), 'parent_backups': len(backup_records)}))


if __name__ == '__main__':
    main()
