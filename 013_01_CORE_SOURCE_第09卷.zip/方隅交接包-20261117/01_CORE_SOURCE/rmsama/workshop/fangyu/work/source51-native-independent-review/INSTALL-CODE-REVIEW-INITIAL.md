两薄文件安装脚本首版 CODE 审查：HOLD，需一个固定图 pin 修正；不要求新的功能 QA。绑定 install_native.py 7637 / 2A2BD1D6961A9704536C0B35C4E8EAC3CC90DB60F0EC32CC9E3ECEBCDCF321E0，INSTALL_AUTHORIZED=false。仅只读代码与已审图，没有执行 installer、CIM、业务 CAS、App 或锁。

必须补齐的 [P2] 固定图绑定：graph=json.loads(blob(OWN/'FINAL-GRAPH.json')) 只核 schema/11/459，其 gate/manifest/CAS 校验 pin 随后来自该未固定字节的 JSON。因此即便两个硬编码候选本身不变，安装程序仍可接受并把另一组 gate/manifest/CAS pin 写成成功安装记录。已固定 coordinator 中的 manifest pin 会令错误图未来 fail-closed，不能把此问题说成业务 CAS 权限漏洞；但这不足以证明本次 exact 图安装契约。最小修正是把这一行 blob 替换为 expected 并固定 FINAL-GRAPH 1143 / CA2BE24A9E46191526521ADFFEFEE32D5F6B75F86F8A026028B5647B825BFE21，该 pin 与上一轮独立 FINAL-GRAPH-READBACK 完全相同。

其余窄审暂未见 must-fix：成熟 Source44 五 AST 函数来自 9601/5F5E3EA2 定址字节；最终 delta 审报告 5640/8DA31D0A 被固定。两个唯一目标的候选14697/8540B5A0与4626/AA029206、launcher原父4238/ACDC0266及旧50helper18590/6DD31FBC固定；new helper先rename，existing launcher后replace，备份原 launcher，阶段中重复校旧 helper。每个 write前核原父／缺席与candidate temp；失败只回滚仍属本次final的目标，撤销自己的new helper，foreign漂移保留，既有receipt/failure拒重做，保史并清temp。

CIM命令只取正常Python进程；输出仅 unknown／normal-opening-live标记，未输出其他任务CommandLine。缺CommandLine、查询失败、stderr或任何匹配均拒安装，没有强停。该进程占用检查在备份前及temp后重新取 fresh；本次未实际查询进程。没有shortcut、marker、用途文件、数据库／会话迁移、App启动、Source50/51业务apply。

Root修正固定图这一行并重冻结后，可仅审该delta及INSTALL_AUTHORIZED false→true。首意见保留，后继报告另外保存；本报告不给原7637版本执行PASS。
