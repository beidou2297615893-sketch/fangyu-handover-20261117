实际安装读回首载体在检查安装脚本 pin 时停止：载体把 INSTALL_AUTHORIZED=true 版预期7731/870E误绑到仍保留的 draft install_native.py（7732/7BF2）。已安装两文件、原父备份、旧50helper、固定图与关键节点字节在此之前都通过。实际独立授权文件名为 install_native-authorized.py，文件现存7731/870E；Root保留False草稿是正确保史。

载体只改该一个固定文件名，首载体字节保 history/read_actual_install-v1.py，原工具结果 8a4120 留存。本修正是只读证据载体路径修正，不是产品／安装／CAS／守卫变更，也没有新增或重跑业务QA、installer、CIM、App或锁。后继读回仍检查同一批已安装公共文件和备份。
