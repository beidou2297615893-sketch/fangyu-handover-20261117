"""Final graph/delta readback only. Never import or execute loader/CAS/product."""
from pathlib import Path
import ast
import hashlib
import json
import os

HERE = Path(__file__).resolve().parent
WORK = HERE.parent
PROJECT = WORK.parent
OWN = WORK / 'source51-root-integration'
AUDITS = WORK / 'product-upgrade-20261009/audits'
SNAP = WORK / 'source51-native-state-story/snapshot'
PIN = lambda raw: {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest().upper()}


def rec(path):
    return {'path': str(path), 'pin': PIN(path.read_bytes())}


def checked(path, proof):
    raw = path.read_bytes()
    assert PIN(raw) == proof, str(path)
    return raw


def normalized(raw, keys):
    tree = ast.parse(raw)
    for node in tree.body:
        if isinstance(node, ast.Assign) and isinstance(node.targets[0], ast.Name) and node.targets[0].id in keys:
            node.value = ast.Constant(None)
    return ast.dump(tree)


def assignments(raw):
    return {node.targets[0].id: node.value for node in ast.parse(raw).body
            if isinstance(node, ast.Assign) and isinstance(node.targets[0], ast.Name)}


def main():
    pins = {
        'prepared': (OWN / 'PREPARED.json', {'bytes': 182535, 'sha256': 'FAACF573300DCEBD6E7AF453DF7850003DE950962A5B013FD15C6A1E88A973ED'}),
        'gate': (AUDITS / 'source51-final-root-read.json', {'bytes': 2131, 'sha256': '59B07E68777462F2577C17BFBD93DBBF928ED8D3D95D236A952BC84F420A0B6A'}),
        'manifest': (AUDITS / 'source51-manifest.json', {'bytes': 160775, 'sha256': '7E9ACEC49AAF60D216A05F57B4C640348948CD501FEA6527F2B30391B232BB10'}),
        'CAS': (AUDITS / 'join-source51-reviewed.py', {'bytes': 19502, 'sha256': '772ED8BF46AB199B669747F8C99174DE7CCDEB281423907F0D99C73CB4FB71C4'}),
        'coordinator': (OWN / 'next_open_source51-final.py', {'bytes': 14697, 'sha256': '8540B5A0AE7572E5C2DC8A550AD74BA0918FF931C09945E7F802E0FB00F6EEF0'}),
        'launcher': (OWN / 'source_next_open_launcher-final.py', {'bytes': 4626, 'sha256': 'AA029206565CA20227131E06C200FBAA385C909CA5C21B274CA83477F1992176'}),
    }
    raws = {name: checked(path, proof) for name, (path, proof) in pins.items()}
    prepared, gate, manifest = [json.loads(raws[name]) for name in ('prepared', 'gate', 'manifest')]
    summary = json.loads((OWN / 'FINAL-GRAPH.json').read_bytes())
    for field, name in [('prepared_pin', 'prepared'), ('gate_pin', 'gate'), ('manifest_pin', 'manifest'),
                        ('CAS_pin', 'CAS'), ('helper_candidate_pin', 'coordinator'), ('launcher_candidate_pin', 'launcher')]:
        assert summary[field] == pins[name][1]
    base_path = WORK / 'overnight-commercial-20261014/source50-preparation/PREPARED.json'
    base_pin = {'bytes': 165442, 'sha256': '5613B97635D7DD386DCE6E88D0B31C50D563F71BC8D970D3033A82882FC3BBD0'}
    base = json.loads(checked(base_path, base_pin))
    authority50_path = AUDITS / 'source50-manifest.json'
    authority50_pin = {'bytes': 17143, 'sha256': 'FA18DE22A451370BD49417A6315ED317134B261D615BED0622031379BEF57267'}
    authority50 = json.loads(checked(authority50_path, authority50_pin))
    base_finals = {Path(row['path']): row['final_pin'] for row in authority50['targets']}
    base_candidates = {Path(row['target']): row for row in base['targets']}
    old = {Path(row['path']): row['pin'] for row in base['protected']}
    assert len(base_finals) == len(base_candidates) == 55 and len(old) == 367
    assert all(base_candidates[path]['candidate_pin'] == proof for path, proof in base_finals.items())

    dy_path = WORK / 'source51-dy-owner-downstream/evidence/FROZEN.json'
    store_path = WORK / 'source51-store-scope/FROZEN.json'
    dy = json.loads(checked(dy_path, {'bytes': 81390, 'sha256': '03D999555B7CA29A5C5B1E6317D85D9E768BB1631755D5D557F310EE325FF430'}))
    store = json.loads(checked(store_path, {'bytes': 14804, 'sha256': 'D6287074B1ACD2FB9A0AB84D043289EAD5A740435F6A26871F5E6D5E9BB9D646'}))
    accepted = {Path(row['target']): row for row in dy['targets'] + store['targets'] + [dy['entry_proposal']]}
    targets = {Path(row['target']): row for row in prepared['targets']}
    paths = list(targets)
    expected_relative = ast.literal_eval(assignments(raws['CAS'])['TARGET_RELATIVE'])
    assert len(targets) == 11 and [path.relative_to(WORK).as_posix() for path in paths] == list(expected_relative)
    assert set(targets) == set(accepted) and len(accepted) == 11
    assert paths[-1] == WORK / 'desktop-self-use-entry/desktop_entry.py'
    actual_candidates, actual_parents, raw_candidates = [], [], {}
    for path, row in targets.items():
        assert set(row) == {'target', 'candidate', 'parent', 'candidate_pin'}
        assert row['parent'] == accepted[path]['parent'] and row['candidate_pin'] == accepted[path]['candidate_pin']
        candidate = Path(row['candidate'])
        assert candidate == OWN / 'candidates' / path.relative_to(WORK)
        raw = checked(candidate, row['candidate_pin'])
        assert raw == checked(Path(accepted[path]['candidate']), accepted[path]['candidate_pin'])
        raw_candidates[path] = raw
        actual_candidates.append(rec(candidate))
        if path in base_finals:
            assert row['parent'] == base_finals[path]
            parent_path = Path(base_candidates[path]['candidate'])
            checked(parent_path, row['parent'])
            actual_parents.append({'target': str(path), 'phase': 'Source50 exact future candidate', **rec(parent_path)})
        elif row['parent'] is not None:
            assert row['parent'] == old.get(path, row['parent'])
            checked(path, row['parent'])
            actual_parents.append({'target': str(path), 'phase': 'current formal public parent', **rec(path)})
        else:
            assert path == WORK / 'cloud/workspace/shared_store_scope.cjs' and not os.path.lexists(path)
    assert len(actual_parents) == 10 and sum(row['parent'] is None for row in targets.values()) == 1

    entry = WORK / 'desktop-self-use-entry/desktop_entry.py'
    before_entry = checked(Path(base_candidates[entry]['candidate']), base_finals[entry])
    old_host, new_host = dy['entry_proposal']['old_sha256'].encode(), dy['entry_proposal']['new_sha256'].encode()
    assert before_entry.count(old_host) == 1 and before_entry.replace(old_host, new_host) == raw_candidates[entry]
    assert PIN(raw_candidates[entry]) == {'bytes': 15900, 'sha256': 'B3251E2C1D963CC6A337D7A87215A76EA669FF6455F559C44AC5D68BFE198C7E'}

    origin = {Path(row['path']): Path(row['formal_target']) for row in dy['public_dependency_origin']}
    wanted_deps = {}
    for row in dy['public_dependencies'] + store['unchanged_public_dependencies']:
        original = Path(row['path'])
        path = origin.get(original, original)
        if path in wanted_deps:
            assert wanted_deps[path] == row['pin']
        wanted_deps[path] = row['pin']
    dependencies = {Path(row['path']): row['pin'] for row in prepared['candidate_dependencies']}
    assert len(dependencies) == len(prepared['candidate_dependencies']) == 48
    assert dependencies == wanted_deps
    wanted_protection = {}
    for collection in (old, base_finals, dependencies):
        for path, proof in collection.items():
            if path in targets:
                continue
            if path in wanted_protection:
                assert wanted_protection[path] == proof
            wanted_protection[path] = proof
    protected = {Path(row['path']): row['pin'] for row in prepared['protected']}
    assert len(protected) == len(prepared['protected']) == 459
    assert protected == wanted_protection
    assert manifest['protected'] == prepared['protected']
    assert manifest['targets'] == [{'path': row['target'], 'parent_pin': row['parent'], 'final_pin': row['candidate_pin']} for row in prepared['targets']]
    assert not set(targets) & set(protected)
    assert prepared['join_authorized'] is False and manifest['join_authorized'] is True
    iid = 'd075ac9c039e44038ddbc6f3e753d73c'
    assert prepared['instance_id'] == manifest['instance_id'] == iid
    assert prepared['base_manifest_pin'] == gate['base_manifest_pin'] == manifest['base_manifest_pin'] == authority50_pin
    assert gate['prepared_manifest_pin'] == pins['prepared'][1]
    assert manifest['approval_pin'] == pins['gate'][1]
    assert manifest['join_script_pin'] == gate['join_script_pin'] == pins['CAS'][1]
    assert all(gate[key] is True for key in ('join_authorized', 'independent_code_review_passed',
        'independent_actual_qa_review_passed', 'join_script_review_passed', 'next_normal_open_only'))
    assert all(gate[key] is False for key in ('customer_database_opened', 'session_copied',
        'deployment_or_packaging_performed', 'real_GUI_verified', 'commercial_complete'))
    assert gate['real_platform_or_model_calls'] == 0 and gate['native_final_delta_review_and_install_readback_required'] is True
    assert prepared['new_directories'] == []

    for name, filename, allowed in (
        ('CAS', 'join-source51-reviewed.py', {'JOIN_AUTHORIZED'}),
        ('coordinator', 'next_open_source51.py', {'JOIN_AUTHORIZED', 'MANIFEST_PIN', 'TARGET_PATHS'}),
        ('launcher', 'source_next_open_launcher.py', {'SUCCESSOR_PIN'}),
    ):
        assert normalized(raws[name], allowed) == normalized((SNAP / filename).read_bytes(), allowed)
    assert raws['CAS'] == (SNAP / 'join-source51-reviewed.py').read_bytes().replace(b'JOIN_AUTHORIZED=False', b'JOIN_AUTHORIZED=True')
    c = assignments(raws['coordinator'])
    l = assignments(raws['launcher'])
    assert ast.literal_eval(c['JOIN_AUTHORIZED']) is True and ast.literal_eval(c['MANIFEST_PIN']) == pins['manifest'][1]
    assert ast.literal_eval(l['SUCCESSOR_PIN']) == pins['coordinator'][1]
    assert isinstance(c['TARGET_PATHS'], ast.Tuple)
    parsed_paths = []
    for item in c['TARGET_PATHS'].elts:
        assert isinstance(item, ast.BinOp) and isinstance(item.op, ast.Div)
        assert isinstance(item.left, ast.Name) and item.left.id == 'PROJECT'
        parsed_paths.append(PROJECT / ast.literal_eval(item.right))
    assert parsed_paths == paths
    assert ast.literal_eval(l['HELPER_PIN']) == {'bytes': 18590, 'sha256': '6DD31FBCB9864272C329C146DD7EA3E9F74F334131F84DDFEB5E3D63ED8BB611'}
    assert ast.literal_eval(l['ENTRY_PARENT_PIN']) == {'bytes': 15900, 'sha256': 'C2FEE1D2355A7A6605E807BFCC71E339D1C23B83D23E92913849DA4E96B980B3'}
    assert ast.literal_eval(assignments(raws['CAS'])['INSTANCE_ID']) == iid
    assert ast.literal_eval(c['INSTANCE_ID']) == iid

    all_evidence = prepared['evidence'] + gate['additional_evidence']
    evidence_records = []
    for row in all_evidence:
        path = Path(row['path'])
        checked(path, row['pin'])
        evidence_records.append(row)
    # All hash arrows point to pre-existing inputs/candidates. No thin-loader,
    # final authority or this final review is included in the prepared closure.
    outside = {WORK / 'desktop-self-use-entry' / name for name in
        ('next_open_source.py', 'next_open_source51.py', 'source_next_open_launcher.py')}
    assert not outside & (set(targets) | set(protected) | set(dependencies))
    assert not {path for path, proof in pins.values()} & {Path(row['path']) for row in prepared['evidence']}

    revision_path = OWN / 'source-revision-readback.json'
    revisions = json.loads(revision_path.read_bytes())
    reviewed_impacts = {row['purpose']: row for row in dy['source_revision_impacts']}
    assert len(revisions['revision_maps']) == 4
    revision_results = []
    necessary_revision_readbacks = {}
    def final_source(relative):
        path = WORK / 'app/src' / relative
        if path in raw_candidates:
            return raw_candidates[path]
        if path in base_candidates:
            candidate = Path(base_candidates[path]['candidate'])
            raw = checked(candidate, base_finals[path])
            necessary_revision_readbacks[candidate] = rec(candidate)
            return raw
        raw = checked(path, dependencies.get(path, old.get(path)))
        necessary_revision_readbacks[path] = rec(path)
        return raw
    for row in revisions['revision_maps']:
        impact = reviewed_impacts[row['purpose']]
        module_raw = final_source(row['module'])
        sources = list(ast.literal_eval(assignments(module_raw)[impact['fixed_sources_constant']]))
        assert sources == row['sources'] == impact['source_files']
        assert row['sort_keys'] == impact['digest_sort_keys']
        mapping = {relative: hashlib.sha256(final_source(relative)).hexdigest() for relative in sources}
        computed = hashlib.sha256(json.dumps(mapping, ensure_ascii=False, sort_keys=row['sort_keys'], separators=(',', ':')).encode()).hexdigest()
        assert computed == row['source_revision'] == impact['six_business_candidate_revision']
        assert mapping == impact['candidate_sha256_lower']
        assert row['store_or_entry_changes_affect_revision'] is False and row['platform_purpose_granted'] is False
        revision_results.append({'purpose': row['purpose'], 'module': row['module'],
                                 'fixed_source_tuple_matches': True, 'revision': computed})
    assert revisions['real_platform_purpose_granted'] is False and revisions['instance_marker_modified'] is False
    result = {
        'schema': 'source51_native_final_graph_delta_independent_readback_v1',
        'status': 'PASS FINAL CODE CONSTANT DELTA + FIXED PUBLIC GRAPH ONLY',
        'final_nodes': {name: {'path': str(path), 'pin': proof} for name, (path, proof) in pins.items()},
        'graph_summary': rec(OWN / 'FINAL-GRAPH.json'),
        'Source50_prepared': rec(base_path), 'Source50_manifest': rec(authority50_path),
        'Source51_targets_11': actual_candidates, 'Source51_parents_10': actual_parents,
        'only_new': str(WORK / 'cloud/workspace/shared_store_scope.cjs'),
        'entry_one_HOST_literal_only': True,
        'protected_exact_metadata_union': {'original50': 367, 'final50': 55, 'candidate_dependencies': 48,
            'minus_exact_11_targets': True, 'deduplicated_final': 459, 'all_pin_collisions_agree': True},
        'controls_AST_only_allowed_literal_deltas': True,
        'fixed_iid_and_original_entry_parent': True,
        'thin_loaders_outside_target_protected_dependency_graph': True,
        'graph_has_no_self_hash_or_review_cycle': True,
        'four_revision_results': revision_results,
        'necessary_unchanged_revision_sources_readback': list(necessary_revision_readbacks.values()),
        'fixed_evidence_readbacks': evidence_records,
        'history': {'prepare_v1': rec(OWN / 'history/prepare_source51-v1.py'),
                    'prepare_first_fail': rec(OWN / 'history/PREPARE-FIRST-FAIL.json')},
        'review_scope': 'integration graph/constants only; six authored Dy business files independently reviewed by source51-independent-review, not re-reviewed here',
        'new_QA_or_loader_CAS_execution': False, 'runtime_binary_or_367_protected_rehashed': False,
        'formal_source_or_data_or_App_or_lock_touched': False,
        'actual_Source50_or51_apply_verified': False, 'real_platform_model_GUI_or_cloud_verified': False,
        'commercial_acceptance': False, 'installed_by_this_review': False,
    }
    path = HERE / 'FINAL-GRAPH-READBACK.json'
    with path.open('x', encoding='utf-8') as stream:
        stream.write(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'result': result['status'], 'readback': rec(path), 'targets': 11,
                      'parents': 10, 'protected': 459, 'revisions': 4}))


if __name__ == '__main__':
    main()
