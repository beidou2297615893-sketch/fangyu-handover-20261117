"""Freeze owned artifacts; reads fixed public inputs, never original state or code execution."""
import ast,hashlib,json
from pathlib import Path
OWN=Path(__file__).resolve().parent
def pin(raw):return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest().upper()}
def jb(value):return (json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode()
def main():
    plan=json.loads((OWN/'PLAN.json').read_bytes())
    plan['shared_original_backups']=['backups/source52-owner','backups/source53-owner','backups/source52-native','backups/source53-native']
    (OWN/'PLAN.json').write_bytes(jb(plan))
    for path,proof in plan['inputs'].items():assert pin(Path(path).read_bytes())==proof,('input drift',path)
    for row in plan['files']:assert pin(Path(row['candidate']).read_bytes())==row['pin']
    source=json.loads((OWN/'REPRESENTATIVE.json').read_bytes());native=json.loads((OWN/'NATIVE-SEAMS.json').read_bytes())
    assert source['status']==native['status']=='PASS_LIMITED'
    evidence={}
    for parent in ('owned-inputs','owned-native'):
        for p in (OWN/parent).rglob('*'):
            if p.is_file() and '__pycache__' not in p.parts:evidence[str(p)]=pin(p.read_bytes())
    (OWN/'OWNED-EVIDENCE-INVENTORY.json').write_bytes(jb({'schema':'owned_guard_revision_evidence_inventory_v1','files':evidence,'no_production_paths':True}))
    report='''# 52/53 EC86 guard revision candidate

18件固定候选已形成；仅供Root与非作者审查。NOT_ACTUAL_ROOT_AUTHORITY，True是签发提案值，未发布、未安装、未调用原root代码。正式目标全部是新的source52-root-integration/guard-token-r2与source53-root-integration/guard-token-r2目录；PLAN.files可供Root exclusive-copy。原PUBLIC、aliases、旧门、首HOLD和失败回执保留。缺少新正式目标路径/Root接受时不得运行stage程序。

复用成熟路线：52 PREPARED原字节169430/BF80D4F7保持，9target/462protected/17dependencies及candidate白名单OWN原址不变；53三个UI payload与470protected原集合不变。52 CAS→gate→manifest→helper→launcher→native graph，随后53 PREPARED祖52/basepin→CAS→gate→manifest→checked helper→launcher→package→native graph/gate→installer递推；无反向hash绑定。50/51 authority、helper和rawreceipt地址不改。53native固定新52helper、future52launcherparent及实际native52两文件raw receipt核验，PUBLISHED/Root接受不是实际apply凭证。

所有业务STARTED/FAILED/RECEIPT、native installed/failed仍指原audits。备份实际原base是backups/source52-owner、source53-owner、source52-native、source53-native。新路径不能自动重apply未知或失败；已有旧success必须匹配新authority/graph与rawchain。原成功不是迁移许可。

代码差异只为已列常量及两处native main增量：各native在control metadata/guard/backup前拒本批business STARTED/FAILED/RECEIPT任何presence；52native的三个control核验expected(AUDITS/name,graph[key])改为expected(OWN/name,graph[key])，AUDITS及顶级固定join44公有字节/五成熟函数抽取仍原址。其余CAS/helper/launcher与native非main函数段保持成熟字节。旧PEER/PEER_PIN只证明原成熟语义；本次新guard+binding必须另审并由Root外部接受。guard6243/EC86C01D完全复用已审新bytes；不改WQL、SOURCE_PATHS门和existing lock。native守卫不提供全局安装mutex，继续Root唯一writer前提。

实际有限代表：新53 checked helper._cas/before_normal_open→新52实际helper plan/start/readback→checked新52 CAS九文件真实事务→新53 CAS三文件真实事务→raw52→53及12原parent backups累计读回→recordedexec。新调用持自有original-existing byte0/length1 OS锁，CAS子进程probe真实。共享原52 STARTED/FAILED两条均held/source_mutations0、未触发CAS；wrong-authority53 receipt读回拒。native52/53各STARTED/FAILED/RECEIPT六条actual main拒，control读取0/guard0/backup0；native53真实checked graph/helper/CAS语义后，旧native52两file pin集合不匹配新revision拒，guard0/backup0。

录制边界：旧50/51层原步骤与历史源码synthetic bytes、旧51回调和旧invoke运输、entry/preflight/PID、guard返回状态、最终exec运输均录制。新52与新53事务/metadata核验、实际parent backup、rawreceipt/OS锁真实。native代表只核早拒，不声称新native安装或GUI验证。未跑旧QA/UI/业务20故事/guard查询；未访问App、真实DB/API/Cookie/Vault/平台。生产freshguard、新真正availability、实际52 native、真实50–53累计normal-open、UI人工验收均未验证。

原始RED保留：ACTUAL-RED.txt为载体静态锚点未按52native真实raw字段切分，惰性解释器拒read_bytes，未执行原module；最小切分修后源故事通过。NATIVE-RED-1.txt为owned载体同秒同size导入pyc缓存导致旧GATEpin，修为checked-owned字节compile及禁bytecode后仅重native新seam，未重已过source故事。18候选自生成后未修改。54 native r1/P2与后续Stage3暂停，不进入本包。
'''
    (OWN/'REPORT.md').write_text(report,encoding='utf-8')
    frozenfiles={}
    for row in plan['files']:frozenfiles[row['candidate']]=row['pin']
    for name in ('PLAN.json','generate.py','representative.py','native-seams-only.py','finalize.py','REPRESENTATIVE.json','NATIVE-SEAMS.json','OWNED-EVIDENCE-INVENTORY.json','REPORT.md','ACTUAL-RED.txt','NATIVE-RED-1.txt'):
        p=OWN/name;frozenfiles[str(p)]=pin(p.read_bytes())
    freeze={'schema':'source52_53_guard_revision_fixed_candidate_freeze_v1','status':'FROZEN_NOT_ACTUAL_ROOT_AUTHORITY','files':frozenfiles,
        'candidate_files':18,'production_executed':False,'published':False,'installed':False,'formal_source_writes':0,
        'Root_acceptance_pending':True,'dependency_binding_review_pending':True,'payload_writes':0,'old_public_immutable':True}
    fp=OWN/'FROZEN.json';assert not fp.exists();fp.write_bytes(jb(freeze))
    print(json.dumps({'FROZEN':pin(fp.read_bytes()),'PLAN':pin((OWN/'PLAN.json').read_bytes()),'REPORT':pin((OWN/'REPORT.md').read_bytes()),'evidence_files':len(evidence),'candidate_files':18}))
if __name__=='__main__':main()
