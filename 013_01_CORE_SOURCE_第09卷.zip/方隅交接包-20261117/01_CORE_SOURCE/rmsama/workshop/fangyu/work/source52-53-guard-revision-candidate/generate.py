"""Owned staging only. This generator never imports or runs bound source code.
True values below are NOT_ACTUAL_ROOT_AUTHORITY; Root alone publishes after review.
"""
import ast,hashlib,json
from pathlib import Path
PROJECT=Path('C:/积木软件工坊/项目/方隅公寓客户版')
OWN=Path(__file__).resolve().parent
WORK=PROJECT/'work';AUDITS=WORK/'product-upgrade-20261009/audits'
B52=WORK/'source52-root-integration';B53=WORK/'source53-root-integration'
F52=B52/'guard-token-r2';F53=B53/'guard-token-r2'
STAGE=OWN/'staging'
GP={'bytes':6243,'sha256':'EC86C01DA85F6AC984CAC4BBA78DEB400D32C2E92FDCA30409CF007A0DA08B0F'}
def pin(raw):return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest().upper()}
def jb(value):return (json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode('utf-8')
def functions(raw):
    text=raw.decode('utf-8-sig')
    return {x.name:ast.get_source_segment(text,x) for x in ast.parse(text).body if isinstance(x,(ast.FunctionDef,ast.AsyncFunctionDef))}
def constants(raw,changes):
    text=raw.decode('utf-8-sig');source=text;delta=[]
    for x in reversed(ast.parse(source).body):
        if isinstance(x,ast.Assign) and len(x.targets)==1 and isinstance(x.targets[0],ast.Name) and x.targets[0].id in changes:
            name=x.targets[0].id;old=ast.get_source_segment(source,x);new=name+'='+changes.pop(name)
            assert text.count(old)==1,(name,old)
            text=text.replace(old,new,1);delta.append({'name':name,'old':old,'new':new})
    assert not changes,changes
    result=text.encode('utf-8');assert functions(raw)==functions(result)
    ast.parse(result);return result,delta
def main():
    assert not STAGE.exists(),'single generation; do not overwrite a staged package'
    STAGE.mkdir(parents=True)
    files=[];deltas={};inputs={};proofs={}
    def read(path):
        raw=path.read_bytes();inputs[str(path)]=pin(raw);return raw
    def doc(path):return json.loads(read(path))
    def emit(path,raw):
        target=STAGE/path.relative_to(PROJECT);assert target.resolve().is_relative_to(STAGE.resolve())
        target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw)
        p=pin(raw);proofs[str(path)]=p;files.append({'candidate':str(target),'target':str(path),'pin':p});return p
    def jsonemit(path,value):return emit(path,jb(value))
    def code(path,base,changes):
        raw,delta=constants(read(base),changes);deltas[str(path)]=delta;return emit(path,raw)
    def proposal(value):
        value.update({'status':'NOT_ACTUAL_ROOT_AUTHORITY','proposed_values_not_actual_Root_signature':True,'Root_acceptance_pending':True})
        return value
    guard=read(WORK/'rea-candidate-audit/guard-token-candidate/candidate_guard.py');assert pin(guard)==GP
    emit(F52/'source_idle_guard.py',guard)
    prepared52=doc(B52/'PREPARED.json');assert len(prepared52['targets'])==9 and len(prepared52['protected'])==462 and len(prepared52['candidate_dependencies'])==17
    # Keep OWN and PREPARED unchanged for the mature candidate path whitelist.
    cas52=code(F52/'join-source52-reviewed.py',B52/'join-source52-reviewed-final.py',{
        'APPROVAL':"WORK/'source52-root-integration/guard-token-r2/source52-final-root-read.json'",
        'AUTHORITY':"WORK/'source52-root-integration/guard-token-r2/source52-manifest.json'",
        'SOURCE_GUARD':"WORK/'source52-root-integration/guard-token-r2/source_idle_guard.py'",'SOURCE_GUARD_PIN':repr(GP)})
    gate52=doc(AUDITS/'source52-final-root-read.json');gate52.update({'join_script_pin':cas52,'source_guard_pin':GP})
    pg52=jsonemit(F52/'source52-final-root-read.json',proposal(gate52))
    m52=doc(AUDITS/'source52-manifest.json');m52.update({'join_script_pin':cas52,'approval_pin':pg52,'source_guard_pin':GP})
    pm52=jsonemit(F52/'source52-manifest.json',proposal(m52))
    h52=code(F52/'next_open_source52-final.py',B52/'next_open_source52-final.py',{
        'MANIFEST':"WORK/'source52-root-integration/guard-token-r2/source52-manifest.json'",
        'APPROVAL':"WORK/'source52-root-integration/guard-token-r2/source52-final-root-read.json'",
        'JOIN':"WORK/'source52-root-integration/guard-token-r2/join-source52-reviewed.py'",
        'GUARD':"WORK/'source52-root-integration/guard-token-r2/source_idle_guard.py'",'GUARD_PIN':repr(GP),'MANIFEST_PIN':repr(pm52)})
    l52=code(F52/'source_next_open_launcher-final.py',B52/'source_next_open_launcher-final.py',{'LATEST_PIN':repr(h52)})
    g52=doc(B52/'FINAL-GRAPH.json');g52.update({'source_guard_pin':GP,'CAS_pin':cas52,'gate_pin':pg52,'manifest_pin':pm52,'helper_candidate_pin':h52,'launcher_candidate_pin':l52})
    g52pin=jsonemit(F52/'FINAL-GRAPH.json',proposal(g52))
    i52raw,id52=constants(read(B52/'install-native-authorized.py'),{'OWN':"WORK/'source52-root-integration/guard-token-r2'",'GUARD_PIN':repr(GP),'GRAPH_PIN':repr(g52pin),'HELPER_PIN':repr(h52),'LAUNCHER_PIN':repr(l52)})
    # Shared original state paths, before metadata/guard/target backup. No state migration.
    text=i52raw.decode();anchor="    expected(PEER,PEER_PIN)"
    insertion="    if any(os.path.lexists(AUDITS/name) for name in ('source52-next-open-started.json','source52-join-failed.json','source52-joined.json')):raise ValueError('original52 business evidence preserved; no native retry')\n"
    assert text.count(anchor)==1;text=text.replace(anchor,insertion+anchor,1)
    assert text.count('expected(AUDITS/name,graph[key])')==1;text=text.replace('expected(AUDITS/name,graph[key])','expected(OWN/name,graph[key])',1)
    i52raw=text.encode();ast.parse(i52raw);deltas[str(F52/'install-native-authorized.py')]=id52+[{'function':'main','delta':'shared own-batch business evidence early refusal; three control reads OWN/name'}]
    emit(F52/'install-native-authorized.py',i52raw)
    # New53 metadata inherits the new52 authority while old state/prepared addresses stay shared.
    prep53=doc(B53/'PREPARED.json');original53=doc(B53/'PREPARED.json')
    prep53['base_manifest_pin']=pm52
    ancestor52=next(x for x in prep53['ancestors'] if x['batch']==52)
    ancestor52.update({'authority':str(F52/'source52-manifest.json'),'authority_pin':pm52,'approval':str(F52/'source52-final-root-read.json')})
    prep53pin=jsonemit(F53/'PREPARED.json',prep53)
    cas53=code(F53/'join-source53-reviewed.py',B53/'join-source53-reviewed.py',{
        'OWN':"WORK/'source53-root-integration/guard-token-r2'",'AUTHORITY':"OWN/'AUTHORITY-PROPOSAL.json'",'APPROVAL':"OWN/'GATE-PROPOSAL.json'",
        'PREPARED_PIN':repr(prep53pin),'ANCESTORS':repr(prep53['ancestors']),
        'SOURCE_GUARD':"WORK/'source52-root-integration/guard-token-r2/source_idle_guard.py'",'SOURCE_GUARD_PIN':repr(GP)})
    gate53=doc(B53/'GATE-PROPOSAL.json');gate53.update({'base_manifest_pin':pm52,'source_guard_pin':GP,'join_script_pin':cas53,'prepared_manifest_pin':prep53pin})
    pg53=jsonemit(F53/'GATE-PROPOSAL.json',proposal(gate53))
    m53=doc(B53/'AUTHORITY-PROPOSAL.json');m53.update({'base_manifest_pin':pm52,'source_guard_pin':GP,'join_script_pin':cas53,'approval_pin':pg53})
    pm53=jsonemit(F53/'AUTHORITY-PROPOSAL.json',proposal(m53))
    h53=code(F53/'next_open_source53.py',B53/'next_open_source53.py',{'OWN':"WORK/'source53-root-integration/guard-token-r2'",'CAS':"WORK/'source53-root-integration/guard-token-r2/join-source53-reviewed.py'",'CAS_PIN':repr(cas53),'MANIFEST_PIN':repr(pm53)})
    l53=code(F53/'source_next_open_launcher.py',B53/'source_next_open_launcher.py',{'LATEST_PIN':repr(h52),'NEWEST_PIN':repr(h53)})
    package={'schema':'source53_bound_source_package_proposal_v1','status':'NOT_ACTUAL_ROOT_AUTHORITY','Root_acceptance_pending':True,
        'files':[{'path':r['target'],'pin':r['pin']} for r in files if r['target'].startswith(str(F53))],
        'prepared_join_authorized':False,'production_installed':False}
    packpin=jsonemit(F53/'SOURCE-PACKAGE-FROZEN.json',package)
    graph53=doc(B53/'native/GRAPH.json')
    graph53.update({'stage1_frozen':{'path':str(F53/'SOURCE-PACKAGE-FROZEN.json'),'pin':packpin},
        'stage1_files':[{'path':str(F53/name),'pin':proofs[str(F53/name)]} for name in ('join-source53-reviewed.py','next_open_source53.py','source_next_open_launcher.py','AUTHORITY-PROPOSAL.json','GATE-PROPOSAL.json')],
        'source_guard':{'path':str(F52/'source_idle_guard.py'),'pin':GP},'future52_launcher_parent':l52})
    graph53['immutable_helpers'][2]['pin']=h52
    graph53['targets'][0].update({'candidate':str(F53/'next_open_source53.py'),'final':h53})
    graph53['targets'][1].update({'candidate':str(F53/'source_next_open_launcher.py'),'parent':l52,'final':l53})
    graph53pin=jsonemit(F53/'native/GRAPH.json',proposal(graph53))
    ng53=doc(B53/'native/NATIVE-ROOT-APPROVAL.json');ng53.update({'graph_pin':graph53pin,'stage1_frozen_pin':packpin})
    ng53pin=jsonemit(F53/'native/NATIVE-ROOT-APPROVAL.json',proposal(ng53))
    # IMMUTABLE has two AST assignments. Preserve its first unchanged and replace only extension.
    native53=read(B53/'native/install_native53.py');oldextension=next(ast.get_source_segment(native53.decode(),x) for x in ast.parse(native53).body if isinstance(x,ast.Assign) and isinstance(x.value,ast.BinOp) and any(isinstance(t,ast.Name) and t.id=='IMMUTABLE' for t in x.targets))
    native53=native53.replace(oldextension.encode(),("IMMUTABLE=IMMUTABLE+((SOURCE52,"+repr(h52)+"),)").encode(),1)
    i53,id53=constants(native53,{'OWN':"WORK/'source53-root-integration/guard-token-r2/native'",'GUARD':"WORK/'source52-root-integration/guard-token-r2/source_idle_guard.py'",'GUARD_PIN':repr(GP),
        'PARENT_PIN':repr(l52),'GRAPH_PIN':repr(graph53pin),'GATE_PIN':repr(ng53pin),'HELPER_PIN':repr(h53),'LAUNCHER_PIN':repr(l53)})
    text=i53.decode();anchor="    gate=json.loads(expected(GATE,GATE_PIN));graph=json.loads(expected(GRAPH,GRAPH_PIN))"
    insertion="    if any(os.path.lexists(AUDITS/name) for name in ('source53-next-open-started.json','source53-join-failed.json','source53-joined.json')):raise ValueError('original53 business evidence preserved; no native retry')\n"
    assert text.count(anchor)==1;text=text.replace(anchor,insertion+anchor,1);i53=text.encode();ast.parse(i53)
    deltas[str(F53/'native/install_native53.py')]=id53+[{'name':'IMMUTABLE extension','new52_helper_pin':h52},{'function':'main','delta':'shared own-batch business evidence early refusal'}]
    emit(F53/'native/install_native53.py',i53)
    assert prep53['targets']==original53['targets'] and prep53['protected']==original53['protected']
    assert m52['targets']==doc(AUDITS/'source52-manifest.json')['targets'] and m52['protected']==prepared52['protected']
    assert m53['targets']==doc(B53/'AUTHORITY-PROPOSAL.json')['targets'] and m53['protected']==original53['protected']
    state_names=['source52-next-open-started.json','source52-join-failed.json','source52-joined.json','source53-next-open-started.json','source53-join-failed.json','source53-joined.json','source52-native-installed.json','source52-native-install-failed.json','source53-native-installed.json','source53-native-install-failed.json']
    plan={'schema':'source52_53_guard_revision_binding_v1','status':'NOT_ACTUAL_ROOT_AUTHORITY','published':False,'installed':False,'production_executed':False,
        'future52':str(F52),'future53':str(F53),'files':files,'constant_and_explicit_deltas':deltas,'inputs':inputs,
        'shared_original_state_paths':[str(AUDITS/name) for name in state_names],
        'shared_original_backups':['backups/source52-owner','backups/source53-owner','backups/source52-native','backups/source53-native'],
        'prepared52_exact_reused':inputs[str(B52/'PREPARED.json')],'payload_writes':0,'old_public_writes':0,
        'counts':{'source52_targets':9,'source52_protected':462,'source52_dependencies':17,'source53_targets':3,'source53_protected':470},
        'dependency_order':['new EC86 guard','52 CAS + unchanged prepared','52 gate','52 manifest','52 helper','52 launcher','52 graph/installer','53 prepared+ancestor52','53 CAS','53 gate','53 manifest','53 helper','53 launcher','53 package','53 native graph','53 native gate','53 installer'],
        'required_before_production':['Root independent binding review','Root exclusive new-path publication','independent exact public readback','new genuine availability; fresh original guard by Root','actual52 native before53 native','normal-open actual50/51/52/53 raw receipt and original backup closure'],
        'native_delta':'reject own-batch business STARTED/FAILED/RECEIPT before control metadata or target backup; preserve originals; no retry or migration'}
    (OWN/'PLAN.json').write_bytes(jb(plan))
    print(json.dumps({'files':len(files),'plan':str(OWN/'PLAN.json'),'production_executed':False}))
if __name__=='__main__':main()
