"""New binding seams only. No production-bound module import or callable execution."""
import ast,hashlib,importlib.util,json,os,sys,types,traceback,uuid
from pathlib import Path
OWN=Path(__file__).resolve().parent
PROJECT=Path('C:/积木软件工坊/项目/方隅公寓客户版')
sys.dont_write_bytecode=True
def pin(raw):return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest().upper()}
def jb(value):return (json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode()
def load(path,name):
    m=types.ModuleType(name);m.__file__=str(path);sys.modules[name]=m;exec(compile(path.read_bytes(),str(path),'exec'),m.__dict__);return m
def main():
    g=load(OWN/'generate.py','guard_revision_owned_generator')
    # read_globals is a small inert AST interpreter, not production execution.
    reader=load(PROJECT/'work/source53-successor-proposal/approved-bind-candidate/representative.py','guard_revision_inert_reader')
    globals_=reader.read_globals
    plan=json.loads((OWN/'PLAN.json').read_bytes());rows={r['target']:r for r in plan['files']}
    def data(path):
        row=rows[str(path)];p=Path(row['candidate']);assert p.is_relative_to(OWN/'staging');raw=p.read_bytes();assert pin(raw)==row['pin'];return raw
    f52=g.F52;f53=g.F53
    for r in rows.values():data(Path(r['target']))
    assert len(rows)==18 and all(Path(p).is_relative_to(f52) or Path(p).is_relative_to(f53) for p in rows)
    c52=globals_(data(f52/'join-source52-reviewed.py').split(b'HELPER=AUDITS/')[0])
    h52=globals_(data(f52/'next_open_source52-final.py'));h53=globals_(data(f53/'next_open_source53.py'));c53=globals_(data(f53/'join-source53-reviewed.py'))
    l52=globals_(data(f52/'source_next_open_launcher-final.py'));l53=globals_(data(f53/'source_next_open_launcher.py'))
    i52=globals_(data(f52/'install-native-authorized.py').split(b"raw=(AUDITS/'join-source44-reviewed.py')")[0]);i53=globals_(data(f53/'native/install_native53.py'))
    p53=json.loads(data(f53/'PREPARED.json'));m52=json.loads(data(f52/'source52-manifest.json'));m53=json.loads(data(f53/'AUTHORITY-PROPOSAL.json'))
    gate52=json.loads(data(f52/'source52-final-root-read.json'));gate53=json.loads(data(f53/'GATE-PROPOSAL.json'))
    assert gate52['join_script_pin']==m52['join_script_pin']==rows[str(f52/'join-source52-reviewed.py')]['pin']
    assert m52['approval_pin']==rows[str(f52/'source52-final-root-read.json')]['pin']
    assert h52['MANIFEST_PIN']==p53['base_manifest_pin']==m53['base_manifest_pin']==rows[str(f52/'source52-manifest.json')]['pin']
    assert h52['JOIN']==f52/'join-source52-reviewed.py' and h52['GUARD_PIN']==c52['SOURCE_GUARD_PIN']==c53['SOURCE_GUARD_PIN']==g.GP
    assert c53['ANCESTORS']==p53['ancestors'] and c53['AUTHORITY']==f53/'AUTHORITY-PROPOSAL.json'
    assert gate53['join_script_pin']==m53['join_script_pin']==h53['CAS_PIN']==rows[str(f53/'join-source53-reviewed.py')]['pin']
    assert h53['MANIFEST_PIN']==rows[str(f53/'AUTHORITY-PROPOSAL.json')]['pin'] and l53['LATEST_PIN']==l52['LATEST_PIN']==rows[str(f52/'next_open_source52-final.py')]['pin']
    assert l53['NEWEST_PIN']==rows[str(f53/'next_open_source53.py')]['pin']
    graph=json.loads(data(f53/'native/GRAPH.json'));ng=json.loads(data(f53/'native/NATIVE-ROOT-APPROVAL.json'))
    assert graph['immutable_helpers'][2]['pin']==rows[str(f52/'next_open_source52-final.py')]['pin']==i53['IMMUTABLE'][2][1]
    assert graph['future52_launcher_parent']==i53['PARENT_PIN']==rows[str(f52/'source_next_open_launcher-final.py')]['pin']
    assert i53['GRAPH_PIN']==ng['graph_pin']==rows[str(f53/'native/GRAPH.json')]['pin'] and i53['GATE_PIN']==rows[str(f53/'native/NATIVE-ROOT-APPROVAL.json')]['pin']
    for module,batch in ((c52,52),(h52,52),(c53,53)):
        assert module['STARTED']==g.AUDITS/f'source{batch}-next-open-started.json'
        assert module['FAILED']==g.AUDITS/f'source{batch}-join-failed.json'
        assert module['RECEIPT']==g.AUDITS/f'source{batch}-joined.json'
    for module,batch in ((i52,52),(i53,53)):
        assert module['RECEIPT']==g.AUDITS/f'source{batch}-native-installed.json' and module['FAILED']==g.AUDITS/f'source{batch}-native-install-failed.json'
    # Mature fixture factory writes only into explicitly rebound owned input dir.
    ft=load(PROJECT/'work/source53-successor-proposal/representative.py','guard_revision_fixture_factory')
    inp=OWN/'owned-inputs';inp.mkdir(exist_ok=False)
    for name in ('PREPARED.json','join-source53-reviewed.py'):
        (inp/name).write_bytes((PROJECT/'work/source53-successor-proposal'/name).read_bytes())
    ft.OWN=inp
    old,prep,state,root=ft.fixture('checked-new52-new53')
    assert root.is_relative_to(OWN) and root!=PROJECT
    rf52=root/'work/source52-root-integration/guard-token-r2';rf53=root/'work/source53-root-integration/guard-token-r2'
    rb52=root/'work/source52-root-integration';ra=root/'work/product-upgrade-20261009/audits'
    refs=old.ANCESTORS;ref52=refs[2];old52p=json.loads(Path(ref52['prepared']).read_bytes());old52a=json.loads(Path(ref52['authority']).read_bytes());old52g=json.loads(Path(ref52['approval']).read_bytes())
    old52receipt=json.loads(Path(ref52['receipt']).read_bytes())
    # All old50/51 steps stay explicitly recorded. Rewind only the recorded52 layer,
    # then actual new52 CAS must create its own rawreceipt and original backups.
    for row in old52p['targets']:
        target=Path(row['target']);ft.write(Path(row['candidate']),target.read_bytes())
        backup=next(Path(r['backup']) for r in old52receipt['targets'] if r['target']==row['target'])
        ft.write(target,backup.read_bytes())
    Path(ref52['receipt']).unlink()
    old52p['evidence']=[];ft.write(Path(ref52['prepared']),jb(old52p))
    guard_raw=old.SOURCE_GUARD.read_bytes();guardpin=ft.write(rf52/'source_idle_guard.py',guard_raw)
    # AST extraction helper44 is public source; no original-root module is imported.
    ft.write(ra/'join-source44-reviewed.py',(g.AUDITS/'join-source44-reviewed.py').read_bytes())
    c52raw,_=g.constants(data(f52/'join-source52-reviewed.py'),{'PROJECT':"Path("+repr(root.as_posix())+")",'SOURCE_GUARD_PIN':repr(guardpin),
        'BASE_MANIFEST_PIN':repr(refs[1]['authority_pin']),'PRIOR_MANIFEST_PIN':repr(refs[0]['authority_pin']),
        'EXPECTED_TARGET_PINS':repr({Path(x['target']).relative_to(root/'work').as_posix():(x['parent'],x['candidate_pin']) for x in old52p['targets']})})
    cp52=ft.write(rf52/'join-source52-reviewed.py',c52raw)
    old52g.update({'join_script_pin':cp52,'source_guard_pin':guardpin,'prepared_manifest_pin':pin(jb(old52p)),'additional_evidence':[]})
    gp52=ft.write(rf52/'source52-final-root-read.json',jb(old52g))
    old52a.update({'join_script_pin':cp52,'approval_pin':gp52,'source_guard_pin':guardpin})
    mp52=ft.write(rf52/'source52-manifest.json',jb(old52a))
    h52raw,_=g.constants(data(f52/'next_open_source52-final.py'),{'PROJECT':"Path("+repr(root.as_posix())+")",'GUARD_PIN':repr(guardpin),'MANIFEST_PIN':repr(mp52),'BASE_MANIFEST_PIN':repr(refs[1]['authority_pin'])})
    hp52=rf52/'next_open_source52-final.py';ft.write(hp52,h52raw)
    mapped=globals_(h52raw);assert all(not isinstance(v,Path) or v.is_relative_to(root) for v in mapped.values())
    latest=load(hp52,'owned_guard_revision_helper52')
    ref52.update({'authority':str(rf52/'source52-manifest.json'),'approval':str(rf52/'source52-final-root-read.json'),'authority_pin':mp52})
    prep['ancestors']=refs;prep['base_manifest_pin']=mp52
    pp53=ft.write(rf53/'PREPARED.json',jb(prep))
    c53raw,_=g.constants(data(f53/'join-source53-reviewed.py'),{'PROJECT':"Path("+repr(root.as_posix())+")",'PREPARED_PIN':repr(pp53),'ANCESTORS':repr(refs),'SOURCE_GUARD_PIN':repr(guardpin),'EXPECTED_TARGET_PINS':repr(old.EXPECTED_TARGET_PINS)})
    cp53=ft.write(rf53/'join-source53-reviewed.py',c53raw)
    og=json.loads(old.APPROVAL.read_bytes());og.update({'base_manifest_pin':mp52,'join_script_pin':cp53,'prepared_manifest_pin':pp53,'source_guard_pin':guardpin})
    gp53=ft.write(rf53/'GATE-PROPOSAL.json',jb(og))
    oa=json.loads(old.AUTHORITY.read_bytes());oa.update({'base_manifest_pin':mp52,'join_script_pin':cp53,'approval_pin':gp53,'source_guard_pin':guardpin})
    mp53=ft.write(rf53/'AUTHORITY-PROPOSAL.json',jb(oa))
    h53raw,_=g.constants(data(f53/'next_open_source53.py'),{'PROJECT':"Path("+repr(root.as_posix())+")",'CAS_PIN':repr(cp53),'MANIFEST_PIN':repr(mp53)})
    hp53=rf53/'next_open_source53.py';ft.write(hp53,h53raw)
    assert all(not isinstance(v,Path) or v.is_relative_to(root) for v in globals_(h53raw).values())
    newest=load(hp53,'owned_guard_revision_helper53');legacy=types.SimpleNamespace(**{k:getattr(old,k) for k in ('expected','pin','blob','prepared_temp','no_link_parent')})
    legacy.PROJECT=root;legacy.ROOT_MANIFEST_PIN=refs[0]['authority_pin'];legacy.APPROVAL=Path(refs[0]['approval']);legacy.RECEIPT=Path(refs[0]['receipt']);legacy.STARTED=Path(refs[0]['started'])
    legacy._exclusive_existing_lock=lambda entry:ft.lock(old)
    prior=json.loads(Path(refs[0]['authority']).read_bytes());base=json.loads(Path(refs[1]['authority']).read_bytes())
    successor=types.SimpleNamespace(RECEIPT=Path(refs[1]['receipt']),STARTED=Path(refs[1]['started']),FAILED=Path(refs[1]['failed']),BASE_FAILED=Path(refs[0]['failed']),APPROVAL=Path(refs[1]['approval']))
    successor._plan=lambda l:(base,prior)
    successor.MANIFEST_PIN=refs[1]['authority_pin']
    # This old51 callback checks physical cumulative metadata via actual new53 CAS;
    # it permits the not-yet-installed52 delta only while no52 rawreceipt exists.
    successor._readback=lambda *a:None # RECORDED old51 invocation; new52 CAS validates full51 closure itself.
    invokes=[]
    def invoke(l,path,proof,approval):
        assert path==rf52/'join-source52-reviewed.py' and pin(path.read_bytes())==proof
        module=load(path,'owned_guard_revision_cas52');assert all(not isinstance(v,Path) or v.is_relative_to(root) for v in vars(module).values())
        args=sys.argv;sys.argv=[str(path),'--apply',approval]
        try:module.main();invokes.append({'batch':52,'actual_checked_same_pid_CAS':True})
        finally:sys.argv=args
    successor._invoke=invoke
    entry=types.SimpleNamespace(__file__=str(old.ENTRY),PILOT=old.PILOT,preflight=lambda:{'state':'ready_for_original_native_main','instance_id':old.INSTANCE_ID})
    requests=[]
    class RecordedExec(BaseException):pass
    def exec_(exe,args):requests.append(args);raise RecordedExec()
    newest.os=types.SimpleNamespace(name='nt',path=os.path,execv=exec_)
    # Shared original52 pending/failed blocks the new53 helper before new52/53 CAS.
    holds=[]
    for path in (latest.STARTED,latest.FAILED):
        ft.write(path,b'OWNED recorded original shared evidence')
        result=newest.before_normal_open(entry,legacy,successor,latest)
        assert result['decision']=='held' and result['source_mutations']==0 and not invokes
        assert not (root/'backups/source53-owner').exists()
        holds.append({'path':str(path),'decision':result,'original_bytes_preserved':path.read_bytes()==b'OWNED recorded original shared evidence'});path.unlink()
    try:newest.before_normal_open(entry,legacy,successor,latest)
    except RecordedExec:pass
    assert requests and invokes,{'requests':requests,'invokes':invokes,'failed52':latest.FAILED.read_text() if latest.FAILED.exists() else None}
    cas=newest._cas(legacy);cas.readback();raw52=latest.RECEIPT.read_bytes();raw53=cas.RECEIPT.read_bytes();r52=json.loads(raw52);r53=json.loads(raw53)
    assert r53['base_receipt_pin']==pin(raw52) and len(r52['targets'])==9 and len(r53['targets'])==3
    assert r52['authority_manifest_pin']==mp52 and r53['authority_manifest_pin']==mp53
    for receipt in (r52,r53):
        for r in receipt['targets']:assert pin(Path(r['backup']).read_bytes())==r['parent']
    # Old revision receipt is not a migration credential for the new fixed authority.
    bad=dict(r53);bad['authority_manifest_pin']={'bytes':1,'sha256':'0'*64};ft.write(cas.RECEIPT,jb(bad))
    try:cas.readback()
    except ValueError as error:wrong_receipt=str(error)
    else:raise AssertionError('wrong old authority receipt accepted')
    ft.write(cas.RECEIPT,raw53)
    # Native narrow seams only: no installation transaction or OS guard queries.
    nr=OWN/'owned-native'/uuid.uuid4().hex;nr.mkdir(parents=True,exist_ok=False);nw=nr/'work';na=nw/'product-upgrade-20261009/audits';nf52=nw/'source52-root-integration/guard-token-r2';nf53=nw/'source53-root-integration/guard-token-r2'
    ft.write(na/'join-source44-reviewed.py',(g.AUDITS/'join-source44-reviewed.py').read_bytes())
    native_seams=[]
    for batch,source,changes in ((52,f52/'install-native-authorized.py',{}),(53,f53/'native/install_native53.py',{})):
        rebased,_=g.constants(data(source),{'PROJECT':"Path("+repr(nr.as_posix())+")"})
        np=nf52/'install-native-authorized.py' if batch==52 else nf53/'native/install_native53.py';ft.write(np,rebased)
        n=load(np,f'owned_native_state_seam{batch}')
        assert all(not isinstance(v,Path) or v.is_relative_to(nr) for v in vars(n).values())
        counters={'metadata':0,'guard':0}
        def forbidden_metadata(*a):counters['metadata']+=1;raise AssertionError('state gate touched control metadata')
        def forbidden_guard(*a):counters['guard']+=1;raise AssertionError('state gate queried guard')
        n.expected=forbidden_metadata;n.absent=forbidden_guard
        for name in (f'source{batch}-next-open-started.json',f'source{batch}-join-failed.json',f'source{batch}-joined.json'):
            statefile=na/name;ft.write(statefile,b'OWNED shared existing state')
            try:n.main()
            except ValueError as error:reason=str(error)
            else:raise AssertionError('native shared state was bypassed')
            assert counters=={'metadata':0,'guard':0} and not (nr/'backups').exists() and statefile.read_bytes()==b'OWNED shared existing state'
            native_seams.append({'batch':batch,'state':name,'error':reason,'control_metadata_reads':0,'guard_queries':0,'backups':0});statefile.unlink()
    # Native53 actual checked graph/helper/CAS semantics reach the old-native52
    # exact two-file receipt refusal. 50/51 code is public bytes copied, never imported.
    desktop=nw/'desktop-self-use-entry'
    for name in ('next_open_source.py','next_open_source51.py'):
        ft.write(desktop/name,(g.WORK/'desktop-self-use-entry'/name).read_bytes())
    ownh52pin=ft.write(desktop/'next_open_source52.py',h52raw)
    parentraw,_=g.constants(data(f52/'source_next_open_launcher-final.py'),{'PROJECT':"Path("+repr(nr.as_posix())+")",'LATEST_PIN':repr(ownh52pin)})
    parentpin=ft.write(desktop/'source_next_open_launcher.py',parentraw)
    for name,raw in (('join-source53-reviewed.py',c53raw),('next_open_source53.py',h53raw),('AUTHORITY-PROPOSAL.json',jb(oa)),('GATE-PROPOSAL.json',jb(og))):ft.write(nf53/name,raw)
    ownlauncher,_=g.constants(data(f53/'source_next_open_launcher.py'),{'PROJECT':"Path("+repr(nr.as_posix())+")",'LATEST_PIN':repr(ownh52pin),'NEWEST_PIN':repr(pin(h53raw))})
    ownlauncherpin=ft.write(nf53/'source_next_open_launcher.py',ownlauncher)
    pack=ft.write(nf53/'SOURCE-PACKAGE-FROZEN.json',jb({'recorded_owned_package':True}))
    graph.update({'source_guard':{'path':str(nf52/'source_idle_guard.py'),'pin':g.GP},
        'stage1_frozen':{'path':str(nf53/'SOURCE-PACKAGE-FROZEN.json'),'pin':pack},
        'stage1_files':[{'path':str(nf53/name),'pin':pin((nf53/name).read_bytes())} for name in ('join-source53-reviewed.py','next_open_source53.py','source_next_open_launcher.py','AUTHORITY-PROPOSAL.json','GATE-PROPOSAL.json')],
        'immutable_helpers':[{'path':str(desktop/Path(x['path']).name),'pin':x['pin']} for x in graph['immutable_helpers']],
        'future52_launcher_parent':parentpin,'source52_native_receipt':str(na/'source52-native-installed.json'),'source52_native_failure':str(na/'source52-native-install-failed.json')})
    graph['immutable_helpers'][2]['pin']=ownh52pin
    graph['targets']=[{'target':str(desktop/'next_open_source53.py'),'candidate':str(nf53/'next_open_source53.py'),'parent':None,'final':pin(h53raw)},
        {'target':str(desktop/'source_next_open_launcher.py'),'candidate':str(nf53/'source_next_open_launcher.py'),'parent':parentpin,'final':ownlauncherpin}]
    ngp=ft.write(nf53/'native/GRAPH.json',jb(graph));ng.update({'graph_pin':ngp,'stage1_frozen_pin':pack});ngate=ft.write(nf53/'native/NATIVE-ROOT-APPROVAL.json',jb(ng))
    iraw=data(f53/'native/install_native53.py');text=iraw.decode();extension=next(ast.get_source_segment(text,x) for x in ast.parse(text).body if isinstance(x,ast.Assign) and isinstance(x.value,ast.BinOp) and any(isinstance(t,ast.Name) and t.id=='IMMUTABLE' for t in x.targets))
    iraw=text.replace(extension,"IMMUTABLE=IMMUTABLE+((SOURCE52,"+repr(ownh52pin)+"),)",1).encode()
    iraw,_=g.constants(iraw,{'PROJECT':"Path("+repr(nr.as_posix())+")",'GRAPH_PIN':repr(ngp),'GATE_PIN':repr(ngate),'PARENT_PIN':repr(parentpin),'HELPER_PIN':repr(pin(h53raw)),'LAUNCHER_PIN':repr(ownlauncherpin)})
    ip=nf53/'native/install_native53.py';ft.write(ip,iraw);native=load(ip,'owned_native53_wrong_parent_receipt')
    assert all(not isinstance(v,Path) or v.is_relative_to(nr) for v in vars(native).values())
    wrongnative={'schema':'source52_native_installed_v1','source_batch':52,'files':[{'path':str(desktop/'next_open_source52.py'),'pin':{'bytes':15464,'sha256':'18F99253AF933F1964A0A1F27F78F23D045C2C46363C4A252C22E65761E01680'}},{'path':str(desktop/'source_next_open_launcher.py'),'pin':{'bytes':4987,'sha256':'598E11A541AADBBEB8A1CA55E6169B5D793C5D80D875603086B773E2671DA432'}}]}
    for name in ('original_App_started_or_stopped','marker_or_platform_grants_changed','database_or_session_copied','desktop_shortcuts_changed','commercial_complete'):wrongnative[name]=False
    for name in ('source50_business_apply_calls','source51_business_apply_calls','source52_business_apply_calls'):wrongnative[name]=0
    ft.write(na/'source52-native-installed.json',jb(wrongnative));native.absent=lambda:(_ for _ in ()).throw(AssertionError('wrong parent receipt queried guard'))
    try:native.main()
    except ValueError as error:native_wrong=str(error)
    else:raise AssertionError('old native52 receipt became new revision credential')
    assert native_wrong=='actual52 native installed dependency absent or changed' and not (nr/'backups').exists()
    report={'schema':'source52_53_guard_revision_owned_representative_v1','status':'PASS_LIMITED','staged_files':18,'fixed_bindings_static_pass':True,'production_bound_code_imported_or_called':False,
        'owned_actual':['new53 helper._cas/before_normal_open','new52 helper plan/start/readback','checked new52 CAS 9file actual transaction','new53 CAS 3file actual transaction','same existing OS byte lock+child probe','new52+53 original parent backups','new raw52->53 receipt binding/readback'],
        'root':str(root),'receipt52_pin':pin(raw52),'receipt53_pin':pin(raw53),'shared_original52_holds':holds,'old_wrong_authority_receipt_refused':wrong_receipt,
        'recorded':['old50/51 source steps and synthetic old public bytes','old51 callback/invocation transport','entry/PID/preflight','guard state (no real guard queries)','final exec request'],
        'native_shared_state_early_refusals':native_seams,'old_native52_wrong_revision_receipt_refused':native_wrong,
        'exec_args':requests[0],'no_original_source_writes':True,'published':False,'installed':False,'original_QA_reexecuted':False}
    (OWN/'REPRESENTATIVE.json').write_bytes(jb(report));print(json.dumps({'status':'PASS_LIMITED','actual52_CAS':True,'actual53_helper_CAS':True,'shared52_holds':len(holds)}))
if __name__=='__main__':
    try:main()
    except BaseException:
        n=1
        while (OWN/f'ACTUAL-RED-{n}.txt').exists():n+=1
        (OWN/f'ACTUAL-RED-{n}.txt').write_text(traceback.format_exc(),encoding='utf-8');raise
