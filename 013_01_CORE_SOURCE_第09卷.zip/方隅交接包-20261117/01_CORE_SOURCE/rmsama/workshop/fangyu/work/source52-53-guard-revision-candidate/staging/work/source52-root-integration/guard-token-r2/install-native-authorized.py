"""Root two thin files only. Unbound/unauthorized draft; business CAS is never called."""
import ast,hashlib,json,os,stat,subprocess,tempfile,types,uuid
from pathlib import Path
PROJECT=Path('C:/积木软件工坊/项目/方隅公寓客户版')
WORK=PROJECT/'work';OWN=WORK/'source52-root-integration/guard-token-r2';AUDITS=WORK/'product-upgrade-20261009/audits'
RECEIPT=AUDITS/'source52-native-installed.json'
FAILED=AUDITS/'source52-native-install-failed.json'
GUARD=OWN/'source_idle_guard.py'
GUARD_PIN={'bytes': 6243, 'sha256': 'EC86C01DA85F6AC984CAC4BBA78DEB400D32C2E92FDCA30409CF007A0DA08B0F'}
PEER=WORK/'source52-independent-review/FINAL-NATIVE-REVIEW.md'
PEER_PIN={'bytes': 4539, 'sha256': '5760E4A2D10E2C7F40CF50EFB6AB8662B73AA789DA698FE37E55C46EA27F006D'}
GRAPH=OWN/'FINAL-GRAPH.json'
GRAPH_PIN={'bytes': 3435, 'sha256': '2D443ADF4B0A7B2B3AC0D0D8A39116A96FC8A775F0469BE46370387F48124A50'}
HELPER_PIN={'bytes': 15623, 'sha256': '1C919E94AA3477E6ABC17EA6B4BC348ACD2E13161FA96E9CC0622AE112FF1FAF'}
LAUNCHER_PIN={'bytes': 4985, 'sha256': 'E8138AD0126C3F5F93747651CDD2106188567C47E6FDD356E9E0F3229CCB6236'}
INSTALL_AUTHORIZED=True
NEW_HELPER=WORK/'desktop-self-use-entry/next_open_source52.py'
LAUNCHER=WORK/'desktop-self-use-entry/source_next_open_launcher.py'
SOURCE50=WORK/'desktop-self-use-entry/next_open_source.py'
SOURCE51=WORK/'desktop-self-use-entry/next_open_source51.py'
IMMUTABLE=(
 (SOURCE50,{'bytes':18590,'sha256':'6DD31FBCB9864272C329C146DD7EA3E9F74F334131F84DDFEB5E3D63ED8BB611'}),
 (SOURCE51,{'bytes':14697,'sha256':'8540B5A0AE7572E5C2DC8A550AD74BA0918FF931C09945E7F802E0FB00F6EEF0'}))
PARENT_PIN={'bytes':4626,'sha256':'AA029206565CA20227131E06C200FBAA385C909CA5C21B274CA83477F1992176'}

raw=(AUDITS/'join-source44-reviewed.py').read_bytes()
if len(raw)!=9601 or hashlib.sha256(raw).hexdigest().upper()!='5F5E3EA22AF7C1FA0FEA71CFEFDA12A9D669C190D5470960901029BF8F4750FB':raise ValueError('mature helpers changed')
names={'blob','pin','expected','no_link_parent','prepared_temp'}
nodes=[x for x in ast.parse(raw).body if isinstance(x,ast.FunctionDef) and x.name in names]
if len(nodes)!=5 or {x.name for x in nodes}!=names:raise ValueError('mature helper definitions changed')
exec(compile(ast.Module(body=nodes,type_ignores=[]),'source44-five-reviewed-helpers','exec'),globals())

def proof(value):
    return (type(value) is dict and set(value)=={'bytes','sha256'} and type(value['bytes']) is int
        and value['bytes']>0 and type(value['sha256']) is str and len(value['sha256'])==64
        and all(x in '0123456789ABCDEF' for x in value['sha256']))

def absent():
    # Only these thin Python opening paths are promoted. The old main may stay
    # live because no business/app/portal/cloud source is changed by this file.
    # Reuse the reviewed WQL/JSON transport with an explicit narrower fixed set;
    # this is a wrapper-consumer check, never a claim the business source is idle.
    module=types.ModuleType('source52_thin_consumer_guard');module.__file__=str(GUARD)
    exec(compile(expected(GUARD,GUARD_PIN),str(GUARD),'exec'),module.__dict__)
    module.SOURCE_PATHS=(LAUNCHER,SOURCE50,SOURCE51,NEW_HELPER)
    module.ALIASES=tuple(x.name for x in module.SOURCE_PATHS)
    module.RUNTIMES=('python.exe','pythonw.exe','py.exe','pypy.exe','pypy3.exe')
    result=module.source_state(os.getpid())
    if type(result) is not dict or result.get('scope')!='fangyu_customer_source_metadata_v1' or result.get('state')!='idle':
        raise ValueError('normal thin opening live or unknown; preserve it')

def main():
    if INSTALL_AUTHORIZED is not True or not all(proof(x) for x in (PEER_PIN,GRAPH_PIN,HELPER_PIN,LAUNCHER_PIN)):
        raise ValueError('fixed reviewed native install authority absent')
    if os.name!='nt' or os.path.lexists(RECEIPT) or os.path.lexists(FAILED):raise ValueError('original installation evidence preserved')
    if any(os.path.lexists(AUDITS/name) for name in ('source52-next-open-started.json','source52-join-failed.json','source52-joined.json')):raise ValueError('original52 business evidence preserved; no native retry')
    expected(PEER,PEER_PIN)
    graph=json.loads(expected(GRAPH,GRAPH_PIN))
    if (graph.get('schema')!='source52_root_final_graph_uninstalled_v1' or graph.get('targets')!=9
        or graph.get('protected')!=462 or graph.get('helper_candidate_pin')!=HELPER_PIN
        or graph.get('launcher_candidate_pin')!=LAUNCHER_PIN or graph.get('source_guard_pin')!=GUARD_PIN):
        raise ValueError('fixed reviewed Source52 graph changed')
    for name,key in (('source52-final-root-read.json','gate_pin'),('source52-manifest.json','manifest_pin'),('join-source52-reviewed.py','CAS_pin')):
        expected(OWN/name,graph[key])
    for path,value in IMMUTABLE:expected(path,value)
    items=[{'target':NEW_HELPER,'candidate':OWN/'next_open_source52-final.py','parent':None,'final':HELPER_PIN},
        {'target':LAUNCHER,'candidate':OWN/'source_next_open_launcher-final.py','parent':PARENT_PIN,'final':LAUNCHER_PIN}]
    changes=[]
    for row in items:
        no_link_parent(row['target'])
        if row['parent'] is None:
            if os.path.lexists(row['target']):raise ValueError('new fixed helper already exists')
            before=None
        else:before=expected(row['target'],row['parent'])
        changes.append((row,before,expected(row['candidate'],row['final'])))
    absent()
    backup_base=PROJECT/'backups/source52-native'
    no_link_parent(backup_base);backup_base.mkdir(exist_ok=True)
    backup=backup_base/uuid.uuid4().hex
    no_link_parent(backup);backup.mkdir()
    temporaries=[];attempted=[];records=[]
    try:
        for row,before,after in changes:
            saved=backup/row['target'].name
            if before is not None:saved.write_bytes(before);expected(saved,row['parent'])
            records.append({'path':str(row['target']),'parent':row['parent'],'pin':row['final'],
                'backup':str(saved) if before is not None else None})
            temporaries.append(prepared_temp(row['target'],after))
        for (row,before,after),temporary in zip(changes,temporaries):
            target=row['target'];no_link_parent(target);expected(temporary,row['final'])
            if before is None:
                if os.path.lexists(target):raise ValueError('new fixed helper appeared')
            else:expected(target,row['parent'])
            absent()
            for path,value in IMMUTABLE:expected(path,value)
            attempted.append((row,before,after))
            if before is None:os.rename(temporary,target)
            else:os.replace(temporary,target)
            expected(target,row['final'])
        for path,value in IMMUTABLE:expected(path,value)
        absent()
        for row,_,_ in changes:
            no_link_parent(row['target']);expected(row['target'],row['final'])
        value={'schema':'source52_native_installed_v1','source_batch':52,'files':records,'graph_pin':GRAPH_PIN,
            'final_native_review_pin':PEER_PIN,'source50_helper_pin':IMMUTABLE[0][1],'source51_helper_pin':IMMUTABLE[1][1],
            'source50_business_apply_calls':0,'source51_business_apply_calls':0,'source52_business_apply_calls':0,
            'original_App_started_or_stopped':False,'marker_or_platform_grants_changed':False,'database_or_session_copied':False,
            'desktop_shortcuts_changed':False,'fixed_flags':['-X','utf8','-B','-I'],'commercial_complete':False}
        temp=prepared_temp(RECEIPT,(json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode('utf-8'))
        temporaries.append(temp);os.rename(temp,RECEIPT)
        print(json.dumps({'installed':True,'files':2,'backup':str(backup),'receipt_pin':pin(blob(RECEIPT)),
            'business_apply_calls':0},ensure_ascii=False))
    except BaseException as error:
        rollback=[]
        for row,before,after in reversed(attempted):
            try:
                target=row['target'];no_link_parent(target);current=blob(target) if target.exists() else None
                if current==before:rollback.append({'path':str(target),'no_change':True});continue
                if current!=after:raise ValueError('foreign thin target drift retained')
                absent()
                if before is None:
                    no_link_parent(target);expected(target,row['final']);target.unlink()
                else:
                    restore=prepared_temp(target,before);temporaries.append(restore)
                    expected(target,row['final']);os.replace(restore,target);expected(target,row['parent'])
                rollback.append({'path':str(target),'restored':True})
            except BaseException as fault:rollback.append({'path':str(row['target']),'held':True,'error_type':type(fault).__name__})
        with FAILED.open('x',encoding='utf-8') as stream:stream.write(json.dumps({'schema':'source52_native_install_failed_v1',
            'failed':True,'error_type':type(error).__name__,'backup':str(backup),'rollback':rollback},ensure_ascii=False,indent=2)+'\n')
        raise
    finally:
        for temporary in temporaries:temporary.unlink(missing_ok=True)

if __name__=='__main__':main()
