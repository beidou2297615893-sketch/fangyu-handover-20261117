"""Root two thin files only. Unbound/unauthorized draft; business CAS is never called."""
import ast,hashlib,json,os,stat,subprocess,tempfile,types,uuid
from pathlib import Path
PROJECT=Path('C:/积木软件工坊/项目/方隅公寓客户版/work/source52-53-guard-revision-candidate/owned-native')
WORK=PROJECT/'work';OWN=WORK/'source53-root-integration/guard-token-r2/native';AUDITS=WORK/'product-upgrade-20261009/audits'
RECEIPT=AUDITS/'source53-native-installed.json'
FAILED=AUDITS/'source53-native-install-failed.json'
GUARD=WORK/'source52-root-integration/guard-token-r2/source_idle_guard.py'
GUARD_PIN={'bytes': 6243, 'sha256': 'EC86C01DA85F6AC984CAC4BBA78DEB400D32C2E92FDCA30409CF007A0DA08B0F'}
INSTALL_AUTHORIZED=True
SOURCE52=WORK/'desktop-self-use-entry/next_open_source52.py'
NEW_HELPER=WORK/'desktop-self-use-entry/next_open_source53.py'
LAUNCHER=WORK/'desktop-self-use-entry/source_next_open_launcher.py'
SOURCE50=WORK/'desktop-self-use-entry/next_open_source.py'
SOURCE51=WORK/'desktop-self-use-entry/next_open_source51.py'
IMMUTABLE=(
 (SOURCE50,{'bytes':18590,'sha256':'6DD31FBCB9864272C329C146DD7EA3E9F74F334131F84DDFEB5E3D63ED8BB611'}),
 (SOURCE51,{'bytes':14697,'sha256':'8540B5A0AE7572E5C2DC8A550AD74BA0918FF931C09945E7F802E0FB00F6EEF0'}))
PARENT_PIN={'bytes': 5038, 'sha256': 'FF61B1A25E706BDC4ADCAB13B2F9742E7D7F0038B4D631425DFDE1BC5E4FC570'}
GRAPH=OWN/'GRAPH.json'
GRAPH_PIN={'bytes': 5679, 'sha256': 'E23ECDA157686085A504A030D8BF12EA44FBF7987CFFA5B43F017FCB92C5FE35'}
GATE=OWN/'NATIVE-ROOT-APPROVAL.json'
GATE_PIN={'bytes': 634, 'sha256': 'F34EE25A48D65EA6EAA3F70F8FEB848DEA80468F02A5B8A5D007B10447E6FCD3'}
STAGE=OWN.parent
IMMUTABLE=IMMUTABLE+((SOURCE52,{'bytes': 15742, 'sha256': '92F9A12B7AE62D9E8E14426A14E262B99B2F4637EA9B75A3841ED9D31B3C929E'}),)
HELPER_PIN={'bytes': 6020, 'sha256': '5FE9C53877A9BCB5DDEC23ADC202640343C8F0F103259D05366D071686D6CFFB'}
LAUNCHER_PIN={'bytes': 5458, 'sha256': '3C11FBECED723DA852AE8FA6018DF15FD0BE71398D425FF7C537BAC1649E64DF'}
def blob(path):
    current=PROJECT
    for part in path.relative_to(PROJECT).parts:
        current=current/part
        info=current.lstat()
        if current.is_symlink() or getattr(info,'st_file_attributes',0)&0x400:
            raise ValueError('reparse path changed')
    if not stat.S_ISREG(info.st_mode) or info.st_nlink!=1:
        raise ValueError('file kind changed')
    return path.read_bytes()

def pin(value):
    return {'bytes':len(value),'sha256':hashlib.sha256(value).hexdigest().upper()}

def expected(path,proof):
    value=blob(path)
    if pin(value)!=proof:
        raise ValueError('pinned file changed: '+str(path))
    return value

def no_link_parent(path):
    current=PROJECT
    for part in path.parent.relative_to(PROJECT).parts:
        current=current/part
        info=current.lstat()
        if (not stat.S_ISDIR(info.st_mode) or current.is_symlink()
                or getattr(info,'st_file_attributes',0)&0x400):
            raise ValueError('new-source parent changed')

def prepared_temp(target,value):
    no_link_parent(target)
    descriptor,name=tempfile.mkstemp(prefix='.source44-',suffix='.tmp',dir=target.parent)
    temporary=Path(name)
    try:
        with os.fdopen(descriptor,'wb') as stream:
            stream.write(value)
            stream.flush()
            os.fsync(stream.fileno())
        if blob(temporary)!=value:
            raise ValueError('complete temporary write mismatch')
        return temporary
    except BaseException:
        # This explicit temporary file is new and private to this join.
        temporary.unlink(missing_ok=True)
        raise
def proof(value):
    return (type(value) is dict and set(value)=={'bytes','sha256'} and type(value['bytes']) is int
        and value['bytes']>0 and type(value['sha256']) is str and len(value['sha256'])==64
        and all(x in '0123456789ABCDEF' for x in value['sha256']))

def absent():
    # Only these thin Python opening paths are promoted. The old main may stay
    # live because no business/app/portal/cloud source is changed by this file.
    # Reuse the reviewed WQL/JSON transport with an explicit narrower fixed set;
    # this is a wrapper-consumer check, never a claim the business source is idle.
    module=types.ModuleType('source52_thin_consumer_guard');module.__file__=str(GUARD)
    exec(compile(expected(GUARD,GUARD_PIN),str(GUARD),'exec'),module.__dict__)
    module.SOURCE_PATHS=(LAUNCHER,SOURCE50,SOURCE51,SOURCE52,NEW_HELPER)
    module.ALIASES=tuple(x.name for x in module.SOURCE_PATHS)
    module.RUNTIMES=('python.exe','pythonw.exe','py.exe','pypy.exe','pypy3.exe')
    result=module.source_state(os.getpid())
    if type(result) is not dict or result.get('scope')!='fangyu_customer_source_metadata_v1' or result.get('state')!='idle':
        raise ValueError('normal thin opening live or unknown; preserve it')

def main():
    if INSTALL_AUTHORIZED is not True or not all(proof(x) for x in (GATE_PIN,GRAPH_PIN,HELPER_PIN,LAUNCHER_PIN)):
        raise ValueError('Source53 native proposal unbound; metadata/guard not permitted')
    if os.name!='nt' or os.path.lexists(RECEIPT) or os.path.lexists(FAILED):raise ValueError('original installation evidence preserved')
    if any(os.path.lexists(AUDITS/name) for name in ('source53-next-open-started.json','source53-join-failed.json','source53-joined.json')):raise ValueError('original53 business evidence preserved; no native retry')
    gate=json.loads(expected(GATE,GATE_PIN));graph=json.loads(expected(GRAPH,GRAPH_PIN))
    if (gate.get('schema')!='source53_native_install_gate_v1' or gate.get('source_batch')!=53
        or gate.get('install_authorized') is not True or gate.get('graph_pin')!=GRAPH_PIN
        or gate.get('independent_native_review_passed') is not True or gate.get('future52_native_required') is not True
        or gate.get('business_apply_authorized') is not False or gate.get('App_control_authorized') is not False
        or graph.get('schema')!='source53_future_native_graph_v1' or graph.get('source_batch')!=53
        or graph.get('join_authorized') is not False or gate.get('stage1_frozen_pin')!=graph['stage1_frozen']['pin']
        or graph.get('source_guard')!={'path':str(GUARD),'pin':GUARD_PIN}
        or graph.get('immutable_helpers')!=[{'path':str(path),'pin':value} for path,value in IMMUTABLE]
        or graph.get('future52_launcher_parent')!=PARENT_PIN or graph.get('business_apply_calls')!=0
        or graph.get('no_reverse_native_graph_binding') is not True):raise ValueError('53 native fixed reviewed graph/gate changed')
    expected(Path(graph['stage1_frozen']['path']),graph['stage1_frozen']['pin'])
    files={Path(x['path']).name:x for x in graph['stage1_files']}
    if set(files)!={'join-source53-reviewed.py','next_open_source53.py','source_next_open_launcher.py','AUTHORITY-PROPOSAL.json','GATE-PROPOSAL.json'}:raise ValueError('53 business binding set changed')
    for row in graph['stage1_files']:expected(Path(row['path']),row['pin'])
    business=json.loads(blob(Path(files['AUTHORITY-PROPOSAL.json']['path'])))
    business_gate=json.loads(expected(Path(files['GATE-PROPOSAL.json']['path']),business['approval_pin']))
    if (business.get('schema')!='source53_next_open_manifest_v1' or business.get('source_batch')!=53
        or business.get('join_authorized') is not True or business_gate.get('join_authorized') is not True
        or business.get('join_script_pin')!=files['join-source53-reviewed.py']['pin']):raise ValueError('53 business revision unbound; refuse native promotion')
    helper_raw=expected(STAGE/'next_open_source53.py',HELPER_PIN)
    assignments={x.targets[0].id:ast.literal_eval(x.value) for x in ast.parse(helper_raw).body
        if isinstance(x,ast.Assign) and len(x.targets)==1 and isinstance(x.targets[0],ast.Name) and x.targets[0].id in ('JOIN_AUTHORIZED','MANIFEST_PIN','CAS_PIN')}
    cas_raw=blob(Path(files['join-source53-reviewed.py']['path']))
    cas_auth=[ast.literal_eval(x.value) for x in ast.parse(cas_raw).body if isinstance(x,ast.Assign) and any(isinstance(y,ast.Name) and y.id=='JOIN_AUTHORIZED' for y in x.targets)]
    if (assignments.get('JOIN_AUTHORIZED') is not True or assignments.get('MANIFEST_PIN')!=files['AUTHORITY-PROPOSAL.json']['pin']
        or assignments.get('CAS_PIN')!=files['join-source53-reviewed.py']['pin'] or cas_auth!=[True]):raise ValueError('new53 fixed helper/CAS not activated by reviewed revision')
    for path,value in IMMUTABLE:expected(path,value)
    if os.path.lexists(graph['source52_native_failure']):raise ValueError('original52 native failure preserved')
    parent_native_raw=blob(Path(graph['source52_native_receipt']));parent_native_pin=pin(parent_native_raw)
    native52=json.loads(parent_native_raw)
    native52_files=native52.get('files')
    if (native52.get('schema')!='source52_native_installed_v1' or native52.get('source_batch')!=52
        or type(native52_files) is not list or len(native52_files)!=2
        or {x['path']:x['pin'] for x in native52_files}!={str(SOURCE52):IMMUTABLE[2][1],str(LAUNCHER):PARENT_PIN}
        or any(native52.get(x) is not False for x in ('original_App_started_or_stopped','marker_or_platform_grants_changed','database_or_session_copied','desktop_shortcuts_changed','commercial_complete'))
        or any(native52.get(x)!=0 for x in ('source50_business_apply_calls','source51_business_apply_calls','source52_business_apply_calls'))):raise ValueError('actual52 native installed dependency absent or changed')
    items=[{'target':NEW_HELPER,'candidate':STAGE/'next_open_source53.py','parent':None,'final':HELPER_PIN},
        {'target':LAUNCHER,'candidate':STAGE/'source_next_open_launcher.py','parent':PARENT_PIN,'final':LAUNCHER_PIN}]
    if graph.get('targets')!=[{'target':str(x['target']),'candidate':str(x['candidate']),'parent':x['parent'],'final':x['final']} for x in items]:raise ValueError('exact53 two-file native map changed')

    changes=[]
    for row in items:
        no_link_parent(row['target'])
        if row['parent'] is None:
            if os.path.lexists(row['target']):raise ValueError('new fixed helper already exists')
            before=None
        else:before=expected(row['target'],row['parent'])
        changes.append((row,before,expected(row['candidate'],row['final'])))
    absent()
    backup_base=PROJECT/'backups/source53-native'
    no_link_parent(backup_base);backup_base.mkdir(exist_ok=True)
    backup=backup_base/uuid.uuid4().hex
    no_link_parent(backup);backup.mkdir()
    temporaries=[];attempted=[];records=[]
    try:
        for row,before,after in changes:
            saved=backup/row['target'].name
            if before is not None:saved.write_bytes(before);expected(saved,row['parent'])
            records.append({'path':str(row['target']),'parent':row['parent'],'pin':row['final'],
                'backup':str(saved) if before is not None else None})
            temporaries.append(prepared_temp(row['target'],after))
        for (row,before,after),temporary in zip(changes,temporaries):
            target=row['target'];no_link_parent(target);expected(temporary,row['final'])
            if before is None:
                if os.path.lexists(target):raise ValueError('new fixed helper appeared')
            else:expected(target,row['parent'])
            absent()
            for path,value in IMMUTABLE:expected(path,value)
            expected(Path(graph['source52_native_receipt']),parent_native_pin)
            attempted.append((row,before,after))
            if before is None:os.rename(temporary,target)
            else:os.replace(temporary,target)
            expected(target,row['final'])
        for path,value in IMMUTABLE:expected(path,value)
        absent()
        expected(Path(graph['source52_native_receipt']),parent_native_pin)
        for row,_,_ in changes:
            no_link_parent(row['target']);expected(row['target'],row['final'])
        value={'schema':'source53_native_installed_v1','source_batch':53,'files':records,'graph_pin':GRAPH_PIN,
            'native_gate_pin':GATE_PIN,'source52_native_receipt_pin':parent_native_pin,'source50_helper_pin':IMMUTABLE[0][1],'source51_helper_pin':IMMUTABLE[1][1],
            'source50_business_apply_calls':0,'source51_business_apply_calls':0,'source52_business_apply_calls':0,'source53_business_apply_calls':0,'source52_helper_pin':IMMUTABLE[2][1],
            'original_App_started_or_stopped':False,'marker_or_platform_grants_changed':False,'database_or_session_copied':False,
            'desktop_shortcuts_changed':False,'fixed_flags':['-X','utf8','-B','-I'],'commercial_complete':False}
        temp=prepared_temp(RECEIPT,(json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode('utf-8'))
        temporaries.append(temp);os.rename(temp,RECEIPT)
        print(json.dumps({'installed':True,'files':2,'backup':str(backup),'receipt_pin':pin(blob(RECEIPT)),
            'business_apply_calls':0},ensure_ascii=False))
    except BaseException as error:
        rollback=[]
        for row,before,after in reversed(attempted):
            try:
                target=row['target'];no_link_parent(target);current=blob(target) if target.exists() else None
                if current==before:rollback.append({'path':str(target),'no_change':True});continue
                if current!=after:raise ValueError('foreign thin target drift retained')
                absent()
                if before is None:
                    no_link_parent(target);expected(target,row['final']);target.unlink()
                else:
                    restore=prepared_temp(target,before);temporaries.append(restore)
                    expected(target,row['final']);absent();os.replace(restore,target);expected(target,row['parent'])
                rollback.append({'path':str(target),'restored':True})
            except BaseException as fault:rollback.append({'path':str(row['target']),'held':True,'error_type':type(fault).__name__})
        with FAILED.open('x',encoding='utf-8') as stream:stream.write(json.dumps({'schema':'source53_native_install_failed_v1',
            'failed':True,'automatic_retry':False,'error_type':type(error).__name__,'backup':str(backup),'rollback':rollback},ensure_ascii=False,indent=2)+'\n')
        raise
    finally:
        for temporary in temporaries:temporary.unlink(missing_ok=True)

if __name__=='__main__':main()
