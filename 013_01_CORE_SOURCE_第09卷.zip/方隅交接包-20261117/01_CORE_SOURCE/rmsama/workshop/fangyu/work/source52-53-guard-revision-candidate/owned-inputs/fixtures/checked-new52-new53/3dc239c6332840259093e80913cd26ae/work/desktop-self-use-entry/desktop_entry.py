def pid_state(pid):
    return "dead" # RECORDED owned entry; no OS PID query
