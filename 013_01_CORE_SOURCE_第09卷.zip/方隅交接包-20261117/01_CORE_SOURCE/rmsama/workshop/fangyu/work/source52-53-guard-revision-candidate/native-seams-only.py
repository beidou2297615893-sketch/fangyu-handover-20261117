"""Only newly added native rejection seams; do not rerun the passed source story."""
import ast,hashlib,importlib.util,json,os,sys,types,traceback,uuid
from pathlib import Path
OWN=Path(__file__).resolve().parent
PROJECT=Path('C:/积木软件工坊/项目/方隅公寓客户版')
sys.dont_write_bytecode=True
def pin(raw):return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest().upper()}
def jb(value):return (json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode()
def load(path,name):
    m=types.ModuleType(name);m.__file__=str(path);sys.modules[name]=m;exec(compile(path.read_bytes(),str(path),'exec'),m.__dict__);return m
def main():
    g=load(OWN/'generate.py','native_seam_owned_generator')
    reader=load(PROJECT/'work/source53-successor-proposal/approved-bind-candidate/representative.py','native_seam_inert_reader')
    ft=load(PROJECT/'work/source53-successor-proposal/representative.py','native_seam_owned_factory_defs')
    plan=json.loads((OWN/'PLAN.json').read_bytes());rows={r['target']:r for r in plan['files']};f52=g.F52;f53=g.F53
    def data(path):
        row=rows[str(path)];p=Path(row['candidate']);assert p.is_relative_to(OWN/'staging');raw=p.read_bytes();assert pin(raw)==row['pin'];return raw
    root=Path(json.loads((OWN/'REPRESENTATIVE.json').read_bytes())['root']);assert root.is_relative_to(OWN)
    rf52=root/'work/source52-root-integration/guard-token-r2';rf53=root/'work/source53-root-integration/guard-token-r2'
    h52raw=(rf52/'next_open_source52-final.py').read_bytes();h53raw=(rf53/'next_open_source53.py').read_bytes();c53raw=(rf53/'join-source53-reviewed.py').read_bytes()
    oa=json.loads((rf53/'AUTHORITY-PROPOSAL.json').read_bytes());og=json.loads((rf53/'GATE-PROPOSAL.json').read_bytes())
    graph=json.loads(data(f53/'native/GRAPH.json'));ng=json.loads(data(f53/'native/NATIVE-ROOT-APPROVAL.json'))
    # Execute the explicit owned native seam block from our own carrier only.
    # It only imports freshly PROJECT-rebased candidates, never production.
    source=(OWN/'representative.py').read_text(encoding='utf-8')
    start=source.index('    # Native narrow seams only:');end=source.index('    report={',start)
    block='\n'.join(line[4:] for line in source[start:end].splitlines())
    context=dict(globals());context.update(locals());exec(compile(block,str(OWN/'representative.py')+':native-owned-block','exec'),context)
    report={'schema':'source52_53_guard_revision_native_rejection_seams_v1','status':'PASS_LIMITED','native_shared_state_early_refusals':context['native_seams'],
        'old_native52_wrong_revision_receipt_refused':context['native_wrong'],'production_executed':False,'guard_queries':0,'backups':0,
        'recorded':['oldnative52 receipt transport and synthetic old signature','old50/51 helper public bytes copied, never imported'],'source_story_reexecuted':False}
    (OWN/'NATIVE-SEAMS.json').write_bytes(jb(report));print(json.dumps({'status':'PASS_LIMITED','state_refusals':len(report['native_shared_state_early_refusals']),'old_native52_refused':True,'guard_queries':0}))
if __name__=='__main__':
    try:main()
    except BaseException:
        n=1
        while (OWN/f'NATIVE-RED-{n}.txt').exists():n+=1
        (OWN/f'NATIVE-RED-{n}.txt').write_text(traceback.format_exc(),encoding='utf-8');raise
