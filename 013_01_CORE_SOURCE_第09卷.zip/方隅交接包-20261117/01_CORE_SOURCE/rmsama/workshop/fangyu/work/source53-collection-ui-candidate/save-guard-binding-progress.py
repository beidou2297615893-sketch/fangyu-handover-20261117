import hashlib,json,uuid
from pathlib import Path
P=Path('C:/积木软件工坊/项目/方隅公寓客户版')
W=P/'work'
receipt=W/'source53-root-integration/GUARD-CANDIDATE-ROOT-LIMITED-ACCEPTED.json'
accepted=json.loads(receipt.read_text(encoding='utf-8'))
assert accepted['status']=='ACCEPTED_ISOLATED_SEMANTICS_AND_OWNED_ONLY'
assert accepted['production_guard_replacement_authorized'] is False
paths=[W/'product-upgrade-20261009/handoff/CURRENT.md',W/'source53-root-integration/NEXT.md',W/'product-upgrade-20261009/audits/source53-current.md',P/'outputs/采集界面修复/采集页具体改动与验收.md']
backup=W/'source53-collection-ui-candidate/document-backups'/('guard-binding-'+uuid.uuid4().hex)
backup.mkdir()
prefix='''# 2026-10-14 最新进展：采集页接入优先，守卫候选已审，固定修订正在闭合

用户催快并已明确答“已正常退出，可以重新评估安装”。原52 installer新一次实际ac3d26仍在backup/temp/replace前HOLD，原首65e463失败证据保持。实际新一次诊断为unknown/live_count0/unknown_count3；没有因此认定原客户空闲或排除真实unknown。

隔离guard-token候选EC86C01D及7组/8自有Windows countpairs已非作者PASS，Root实际全文有限接受记录为work/source53-root-integration/GUARD-CANDIDATE-ROOT-LIMITED-ACCEPTED.json。唯一动态参数识别语句修复；原守卫1E、所有旧签字节/失败记录未覆盖，当前仍0新安装/0业务apply。

本线程所属author在work/source52-53-guard-revision-candidate生成一次完整52/53新固定签名包，正式候选新路径为source52-root-integration/guard-token-r2及source53-root-integration/guard-token-r2。只新控制路径，原业务/native单号状态与backup地址共享；旧pending/FAILED/不匹配旧success继续拒。52九业务payload/462保护/17依赖、53三UIpayload/470保护与50/51原链保持，不重做旧研究/QA。新native增加本批业务证据早拒是明确delta，须独审。Root复制器已准备，未执行；新包冻结/必要代表/独审及实际读回前不执行生产修订installer。

其他功能暂停扩展，54native r1 P2仍待后台最小修补，不阻塞53采集页。现在仍不能称正在使用的客户端已更新、真实GUI已认可或R01–R25商业完成。0原App控制/截图绕行/网页替代/真实DBCookieVault读hashcopy/平台模型发送/打包部署付费。以下旧记录保留，当前事实以上段及实际后续回执为准。

'''.encode('utf-8')
records=[]
for i,path in enumerate(paths):
    raw=path.read_bytes()
    saved=backup/(str(i)+'.md')
    saved.write_bytes(raw)
    assert saved.read_bytes()==raw
    path.write_bytes(prefix+raw)
    records.append({'path':str(path),'backup':str(saved),'before_sha256':hashlib.sha256(raw).hexdigest().upper()})
(backup/'RECORD.json').write_text(json.dumps(records,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'updated':len(paths),'backup':str(backup),'formal_SOURCE_changes':0},ensure_ascii=False))
