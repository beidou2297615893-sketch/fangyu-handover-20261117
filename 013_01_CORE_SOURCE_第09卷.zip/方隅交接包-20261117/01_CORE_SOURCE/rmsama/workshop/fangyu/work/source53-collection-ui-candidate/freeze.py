from pathlib import Path
import hashlib, json, difflib, shutil
ROOT=Path(__file__).resolve().parent
def pin(p):
    raw=p.read_bytes()
    return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest().upper()}
files={}
for variant in ('current','future51'):
    folder=ROOT if variant=='current' else ROOT/'future51'
    frozen=ROOT/'frozen-r1'/variant
    frozen.mkdir(parents=True,exist_ok=True)
    for name in ('self-operating-read.mjs','upgrade-ui.css'):
        source=folder/'candidate'/name
        target=frozen/name
        assert not target.exists(), 'Frozen candidates are immutable; use another revision'
        shutil.copyfile(source,target)
        before=(folder/('parent-'+name)).read_text(encoding='utf-8').splitlines(keepends=True)
        after=source.read_text(encoding='utf-8').splitlines(keepends=True)
        (frozen/(name+'.patch')).write_text(''.join(difflib.unified_diff(before,after,fromfile='parent/'+name,tofile='candidate/'+name)),encoding='utf-8')
        files[str(target)]=pin(target)
    for name in ('PREPARED.json','VERIFY.json'):
        target=frozen/name
        shutil.copyfile(folder/name,target)
        files[str(target)]=pin(target)
for name in ('build.py','collection.css','verify.mjs','FIRST-RED.md'):
    files[str(ROOT/name)]=pin(ROOT/name)
manifest={'schema':'source53_isolated_ui_frozen_v1','status':'FROZEN_CANDIDATE_ONLY',
 'changedOriginalFunctions':['composeFourOwnerPages'],'originalBusinessFunctionsUnchanged':440,
 'variants':['current formal public source','fixed Source51 future public candidate'],
 'files':files,'sourceInstalled':False,'normalAppControlled':False,'nativeVisualAccepted':False,
 'source52InstallerOrGuardRun':False,'customerDataRead':False,
 'pending':['independent review','sealed lineage successor preparation','new genuine availability evidence before install','real native layout and keyboard review','human software acceptance']}
(ROOT/'FROZEN.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'status':manifest['status'],'files':len(files)},ensure_ascii=False))
