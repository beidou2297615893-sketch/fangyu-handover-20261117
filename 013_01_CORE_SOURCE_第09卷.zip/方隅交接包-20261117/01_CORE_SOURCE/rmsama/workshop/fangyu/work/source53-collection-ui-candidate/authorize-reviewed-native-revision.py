import hashlib,json
from pathlib import Path
P=Path('C:/积木软件工坊/项目/方隅公寓客户版');W=P/'work';ROOT=W/'source53-root-integration';R=W/'source53-collection-ui-review'
def fixed(path,size,digest):
    raw=path.read_bytes();assert len(raw)==size and hashlib.sha256(raw).hexdigest().upper()==digest,str(path)
    return {'path':str(path),'pin':{'bytes':size,'sha256':digest}}
readback=fixed(R/'GUARD-REVISION-PUBLICATION-ACTUAL-READBACK.md',1606,'6C1D96BBE5614978D1749DCEBD1E1D4FE7B12C528260EA0D91F204E4D8882CB5')
readback_json=fixed(R/'GUARD-REVISION-PUBLICATION-ACTUAL-READBACK.json',26934,'836996E3634FE7443289DFBEE8681105E87F4C0BEC474B9A7D9BAD950E3D6C52')
accept=fixed(ROOT/'GUARD-REVISION-ROOT-ACCEPTED.json',2932,'9A34E7B6BED18D82760AA6E88C59D9CF34ABAAD6C1831BCE36B8D771135DB88D')
publication=fixed(ROOT/'GUARD-REVISION-PUBLISHED.json',9880,'9CE8014DDF667C127E63DA37AD49F6DC34CD795DE83716D10692277DC9B9ADCD')
installers=[fixed(W/'source52-root-integration/guard-token-r2/install-native-authorized.py',9139,'A6B996F29F922BD089B32311A75DB52967DBA2FA6C69018535FB17D220E49B81'),fixed(W/'source53-root-integration/guard-token-r2/native/install_native53.py',14503,'D08CF3FFB567C0CB2F942E7B1881E608660962EB07E906C3DBC56167599F8CC5')]
result={'schema':'source52_53_guard_revision_actual_root_native_decision_v1',
 'root_chat':'01a13a0e-b66c-72a3-a82a-8ad950462a6b','independent_readback':readback,'readback_json':readback_json,
 'root_acceptance':accept,'publication':publication,'installers':installers,
 'root_full_read_tool':'d7ae8c','user_fresh_action':'已正常退出，可以重新评估安装',
 'installation_authorized':True,'scope':'only exact52 thin two files, then exact53 thin two files only after actual52 native receipt checks',
 'business_apply_authorized_here':False,'App_start_stop_or_control_authorized':False,
 'fresh_guard_required_inside_each_exact_installer':True,'actual_idle_assumed':False,
 'current_unknown_exempted':False,'old_failures_or_state_overwrite_authorized':False,
 'original_first_and_new_exit_HOLD_preserved':True,'retry_after_HOLD_without_new_evidence_authorized':False,
 'reason':'reviewed dynamic-token guard bugfix plus shared original business evidence early refusal; no old code gate bypass',
 'external_publish_package_deploy_pay_authorized':False,'commercial_complete':False}
target=ROOT/'GUARD-REVISION-NATIVE-ROOT-DECISION.json'
with target.open('x',encoding='utf-8') as stream:json.dump(result,stream,ensure_ascii=False,indent=2);stream.write('\n')
print(json.dumps({'decision':str(target),'installation_authorized':True,'fresh_idle_not_assumed':True},ensure_ascii=False))
