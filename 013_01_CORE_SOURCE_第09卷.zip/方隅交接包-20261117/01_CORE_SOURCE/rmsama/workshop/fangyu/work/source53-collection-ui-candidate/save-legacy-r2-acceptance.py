from pathlib import Path
import hashlib
import json
import sys
import uuid

root=Path(__file__).resolve().parent
customer=root.parents[1]
review=Path(sys.argv[1]).resolve()
assert review.parent==customer/'work/source53-collection-ui-review'
review_raw=review.read_bytes()
assert 'PASS' in review_raw.decode('utf-8'), 'Root must read and accept PASS review first'
candidate=customer/'work/legacy-export-scope-candidate/r2'
pins=[]
for path in [review, candidate/'FROZEN.json',candidate/'business.py',candidate/'FIRST-RED.json',candidate/'GREEN.json']:
    raw=path.read_bytes()
    pins.append({'path':str(path),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest().upper()})
assert pins[1]['sha256']=='08BE492EE0BD25DF8B54297B8C65E96735F6BCA5AC59C81D67A73A47D453EB21'
assert pins[2]['sha256']=='8E364FA703AFF478ED793D76792B85E4C822C802F497F46E9F20925DAC89C409'
out=root/'LEGACY-R2-ROOT-ACCEPTED.json'
with out.open('x',encoding='utf-8') as handle:
    json.dump({'schema':'legacy_export_r2_root_limited_acceptance_v1',
       'root_chat':'01a13a0e-b66c-72a3-a82a-8ad950462a6b',
       'status':'ACCEPTED_ISOLATED_CODE_AND_OWNED_EVIDENCE_NOT_INSTALLED',
       'review_read_in_full':True,'evidence':pins,'related_owned_cases':20,
       'source53_modified':False,'formal_source_written':False,
       'native_installed':False,'current_owner_leads_list_enabled':False,
       'real_App_DB_API_guard_actions':0,'production_throughput_verified':False,
       'cross_process_DB_isolation_verified':False},handle,ensure_ascii=False,indent=2)
    handle.write('\n')
block='''# 2026-10-14 接续补充：旧导出权限r2已有限审核，未合入

REA C04定点检查实际发现旧商业leads_list快照在来源失权后仍可续页；r1独审又发现未选中组的缓存名称/计数遗漏。两次RED与r1 CHANGES_REQUIRED保留。r2由服务端在分析汇总/分类筛选前冻结全部贡献source IDs，每页及末确认重核当前权限，失权/缺失/未知清原token，恢复来源也不复活旧号；调用者不能注入或替换scope。成功原items/view/排序/计数保持。9新增+11相关owned公开__call__验证通过，最小非作者r2复审与Root全文有限接受完成。

正式business父9329EE39保持，r2候选8E364FA7尚未合入/安装，不改已发布Source53或当前owner开放范围。完整scope可能大于10000输出行，生产DB吞吐和跨进程隔离尚未验。Root接受work/source53-collection-ui-candidate/LEGACY-R2-ROOT-ACCEPTED.json；详细outputs/REA接收/旧导出修复与接入状态.md。后续必须独立后继核对链，不能直接覆盖Source50–53保护源或冒已经接入。

Source53采集UI与13份本地接入文件的实际签发/独立读回已完成；当前正式MJS/CSS与51桌面入口保持，52首安装HOLD未解除、53未安装。无新genuine availability不跑installer/guard/PID/preflight/check-only或原App；真实GUI与用户软件认可、全部R01–R25商业验收继续未完成。

以下历史保持，以上段和实际回执为当前事实。

'''
backup=root/'document-backups'/uuid.uuid4().hex
backup.mkdir(parents=True)
paths=[customer/'memory/STATUS.md',customer/'outputs/产品升级/当前执行事实.md',
       customer/'outputs/产品升级/需求交付与证据台账.md',
       customer/'work/product-upgrade-20261009/handoff/CURRENT.md',
       customer/'work/product-upgrade-20261009/audits/source53-current.md',
       customer/'work/source53-root-integration/NEXT.md',
       customer/'outputs/REA接收/新窗口接收回执.md',
       customer/'memory/sessions/2026-10-14-新聊天接续采集界面修复.md']
records=[]
for index,path in enumerate(paths):
    raw=path.read_bytes()
    dest=backup/(str(index)+'-'+path.name)
    dest.write_bytes(raw)
    path.write_bytes(block.encode('utf-8')+raw)
    records.append({'path':str(path),'backup':str(dest),
                    'before_sha256':hashlib.sha256(raw).hexdigest().upper(),
                    'after_sha256':hashlib.sha256(path.read_bytes()).hexdigest().upper()})
ui=customer/'outputs/REA接收/旧导出修复与接入状态.md'
body='''# 旧导出修复与接入状态

REA规格包已由正确新聊天接收；定点检查和修订已经完成有限代码验证，尚未合入或装载。

旧商业导出会缓存原筛选结果。过去续页只核原用户与有效期，来源转移或缺失后仍可能返回缓存行；首修订又遗漏了未选中分类组贡献的名称和计数。两次失败反例和独立审查已保留，没有把失败版本标作完成。

最终r2在服务端冻结所有贡献导出行与缓存汇总的来源编号。开始导出、续页与最终确认均重新核对当前权限；任一来源失权、缺失或状态未知都会使原快照失效，恢复权限后也不能复用旧编号。成功时原筛选、顺序、数量和分组汇总保持。9项新增和11项相关公开接口合成验证通过，独立复审与Root有限接受完成。

这属于旧商业链。当前本人采集页面没有开放旧leads_list导出接口，不把此问题当作本次采集布局回归，也没有新增owner CSV入口。Source53冻结与本地接入文件保持不变；正式business.py尚未被改写。完整权限范围可能大于一万输出行，真实数据库吞吐、跨进程隔离和正常客户端使用尚未验证。

后续接入须独立准备后继和累积源码核对，保护50–53原父、原实际回执及备份；当前52首安装HOLD仍有效，无新真实条件不重试。采集UI候选也尚未装入原客户端。完整商业版未验收。

'''
body+='候选文件：`'+str(candidate/'business.py').replace('\\','/')+'`。\n\n候选文件夹：`'+str(candidate).replace('\\','/')+'`。\n\n独审文件：`'+str(review).replace('\\','/')+'`。\n\n独审文件夹：`'+str(review.parent).replace('\\','/')+'`。\n\n本说明文件：`'+str(ui).replace('\\','/')+'`。\n\n本说明文件夹：`'+str(ui.parent).replace('\\','/')+'`。\n'
with ui.open('x',encoding='utf-8') as handle:handle.write(body)
with (root/'LEGACY-R2-DOCUMENT-UPDATED.json').open('x',encoding='utf-8') as handle:
    json.dump({'documents':records,'new_output':str(ui),'formal_source_written':False},handle,ensure_ascii=False,indent=2)
    handle.write('\n')
print(json.dumps({'accepted':str(out),'backed_up_documents':len(records),'new_output':str(ui),'formal_source_written':False},ensure_ascii=False))
