from pathlib import Path
import hashlib,json
root=Path(__file__).resolve().parent;customer=root.parents[1]
script=customer/'work/source52-root-integration/install-native-authorized.py'
raw=script.read_bytes();actual={'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest().upper()}
expected={'bytes':8911,'sha256':'6DC1D17AB09DFCBC1A9DAFADF2123C3221CA21735DF4098C76CBA9979ECA0F11'}
assert actual==expected,'Original reviewed52 installer changed'
receipt=customer/'work/source53-root-integration/INSTALL-NEW-EXIT-AUTHORIZATION-20261014.json'
with receipt.open('x',encoding='utf-8') as handle:
    json.dump({'schema':'source52_53_root_new_human_exit_conditional_attempt_v1',
      'root_chat':'01a13a0e-b66c-72a3-a82a-8ad950462a6b',
      'human_actual_response':'已正常退出，可以重新评估安装',
      'authorization_source':'本聊天人类对正常退出状态询问的实际回答，结合既有采集UI修复授权',
      'source52_installer':str(script),'source52_installer_pin':actual,
      'conditional_original52_attempt_authorized':True,
      'conditional53_attempt_requires_actual52_install_and_readback':True,
      'all_original_fresh_guard_and_pin_checks_required':True,
      'source52_first_hold_preserved':True,'automatic_retry':False,
      'App_start_stop_refresh_or_business_apply_by_Root_authorized':False,
      'private_DB_Cookie_Vault_read_or_copy_authorized':False,
      'GUI_or_user_acceptance_claimed':False},handle,ensure_ascii=False,indent=2);handle.write('\n')
print(json.dumps({'authorization_recorded':str(receipt),'installer_pin':actual},ensure_ascii=False))
