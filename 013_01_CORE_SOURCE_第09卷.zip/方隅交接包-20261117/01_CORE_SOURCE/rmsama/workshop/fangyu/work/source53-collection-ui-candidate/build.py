"""Public source only; produce an isolated UI candidate, never install it."""
from pathlib import Path
import hashlib, json, sys

BASE = Path(__file__).resolve().parent
ROOT = BASE / 'future51' if '--future51' in sys.argv else BASE
ROOT.mkdir(exist_ok=True)
SOURCE = BASE.parent / 'app/src/web/workspace'
SOURCES = {name: SOURCE / name for name in ('self-operating-read.mjs', 'upgrade-ui.css')}
if '--future51' in sys.argv:
    plan = json.loads((BASE.parent / 'source51-root-integration/PREPARED.json').read_bytes())
    entries = [entry for entry in plan['targets'] if entry['target'].endswith('self-operating-read.mjs')]
    assert len(entries) == 1
    entry = entries[0]
    future = Path(entry['candidate'])
    raw = future.read_bytes()
    assert len(raw) == entry['candidate_pin']['bytes']
    assert hashlib.sha256(raw).hexdigest().upper() == entry['candidate_pin']['sha256'].upper()
    SOURCES['self-operating-read.mjs'] = future
DEST = ROOT / 'candidate'
DEST.mkdir(exist_ok=True)
names = ('self-operating-read.mjs', 'upgrade-ui.css')
parents = {}
for name in names:
    raw = SOURCES[name].read_bytes()
    parents[name] = {'path': str(SOURCES[name]), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}
    (ROOT / ('parent-' + name)).write_bytes(raw)

src = SOURCES[names[0]].read_text(encoding='utf-8')
start = src.index(' /* Collection: current state and stop/original-number controls stay visible. */')
end = src.index(' /* Handoff separates package preparation', start)
old = src[start:end]
new = ''' /* Collection uses the existing controls in working order. No request or guard changes. */
 composeOwnerCollection(tasks);
'''
fn = '''function composeOwnerCollection(tasks){
 const tasksTitle=tasks.querySelector('h2');tasksTitle.className='sr-only';
 const readForm=$('owner-read-form'),account=$('owner-account');
 const accountBar=ownerSurface('本次使用账号');accountBar.classList.add('owner-collection-account');
 const accountLabel=node('label','小红书账号');account.setAttribute('form','owner-read-form');accountLabel.append(account);
 const accountSettings=button('平台账号与登录',()=>show('devices'));accountSettings.className='secondary';
 const accountCopy=node('p','找笔记和采集评论使用同一账号；账号需先核实。');accountCopy.className='owner-surface-intro';accountBar.append(accountLabel,accountSettings,accountCopy);
 const keyword=$('owner-keyword-form').closest('section');keyword.classList.add('owner-surface','owner-keyword-surface','owner-collection-step');
 const keywordTitle=keyword.querySelector('h3');if(keywordTitle)keywordTitle.textContent='1 · 按关键词找笔记';
 $('owner-keyword-submit').textContent='搜索笔记';$('owner-keyword-status').textContent='核对本次搜索';$('owner-keyword-cancel').textContent='停止本次搜索';
 const keywordNotes=Array.from(keyword.children).filter(el=>el.tagName==='P'&&!el.id);ownerPreserveNotes(keyword,'搜索用途与范围',keywordNotes);
 const keywordActions=node('div');keywordActions.className='owner-inline-actions';keywordActions.append($('owner-keyword-status'),$('owner-keyword-cancel'));
 $('owner-keyword-state').after(keywordActions);
 const results=$('owner-keyword-results');results.setAttribute('aria-label','本次搜索的笔记');
 const resultGuide=node('p','搜索结果出现后，选择一篇笔记；也可以直接粘贴已知笔记链接。');resultGuide.className='owner-collection-guide';results.before(resultGuide);
 const readPanel=ownerSurface('2 · 采集笔记评论','核对笔记链接后明确开始，本次至多20条。');readPanel.classList.add('owner-collection-step');readPanel.append(readForm);
 readForm.querySelector('#owner-xhs-read-submit').textContent='采集这篇笔记';
 const reference=readForm.querySelector('[name="reference"]');reference.placeholder='粘贴小红书笔记链接，或使用上方选择的笔记';
 const current=ownerSurface('本次采集状态');current.classList.add('owner-collection-state');current.setAttribute('aria-label','采集状态与原请求操作');
 const readState=$('owner-read-state');readState.setAttribute('role','status');readState.setAttribute('aria-live','polite');
 const currentActions=node('div');currentActions.className='owner-inline-actions';currentActions.append($('owner-xhs-read-status'),$('owner-xhs-read-cancel'),$('owner-xhs-read-confirm'));for(const control of currentActions.children)control.classList.add('secondary');
 const next=button('查看已保存来源',()=>show('leads'));next.className='secondary';
 const nextStep=node('div');nextStep.className='owner-collection-next';nextStep.append(node('h3','采集之后'),node('p','采集完成后到客户工作台查看本次预览；允许保存时，先保存来源，再核对结束。'),next);
 current.append(readState,currentActions,nextStep);
 const taskNotes=Array.from(tasks.children).filter(el=>el.tagName==='P'&&!el.id);
 const flow=node('div');flow.className='owner-collection-flow';flow.append(keyword,readPanel);
 const grid=node('div');grid.className='owner-collection-grid';grid.append(flow,current);
 const other=node('section');other.className='owner-other-platforms';other.append($('owner-dy-section'),$('owner-channels-tasks'));for(const section of other.children)section.classList.add('owner-surface');
 ownerSecondaryPlatform(other.children[0],'抖音采集与已保存评论',['owner-dy-state','owner-dy-status','owner-dy-cancel','owner-dy-archive-controls']);
 ownerSecondaryPlatform(other.children[1],'视频号采集与连接设置',['owner-channels-state','owner-channels-status','owner-channels-cancel']);
 const technical=$('owner-xhs-read-technical');technical.classList.add('owner-collection-recovery');
 tasks.append(accountBar,grid,other,technical);ownerPreserveNotes(tasks,'保存与采集结束说明',taskNotes);
}

'''
# Only the collection composition changes. All business functions keep their bytes.
src = src[:start] + new + src[end:]
src = src.replace('function composeFourOwnerPages(', fn + 'function composeFourOwnerPages(', 1)
(DEST / names[0]).write_text(src, encoding='utf-8', newline='\n')
css = SOURCES[names[1]].read_text(encoding='utf-8')
extra = (BASE / 'collection.css').read_text(encoding='utf-8')
(DEST / names[1]).write_text(css + '\n' + extra, encoding='utf-8', newline='\n')
manifest = {'status': 'isolated candidate only', 'source': 'Source53 collection UI', 'parents': parents,
            'changed_scope': 'collection DOM composition + collection-only CSS',
            'installed': False, 'real_gui_verified': False, 'business_requests': 0,
            'database_cookie_vault_reads': 0, 'original_app_control': 0,
            'targets': {name: {'path':str(DEST/name), 'bytes':(DEST/name).stat().st_size,
                       'sha256':hashlib.sha256((DEST/name).read_bytes()).hexdigest()} for name in names}}
(ROOT / 'PREPARED.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2)+'\n',encoding='utf-8')
print(json.dumps({'status':manifest['status'],'targets':list(manifest['targets'])},ensure_ascii=False))
