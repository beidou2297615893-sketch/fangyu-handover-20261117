from pathlib import Path
import hashlib,json,os,types
root=Path(__file__).resolve().parent;customer=root.parents[1]
path=customer/'work/source52-root-integration/source_idle_guard.py'
raw=path.read_bytes()
assert len(raw)==5948 and hashlib.sha256(raw).hexdigest().upper()=='1E97220595CCD6954F67FAABFCAE83E52734D4EE59188F0657C9B0363FBA3AA1'
module=types.ModuleType('original52_same_thin_guard_diagnostic');module.__file__=str(path)
exec(compile(raw,str(path),'exec'),module.__dict__)
entry=customer/'work/desktop-self-use-entry'
module.SOURCE_PATHS=tuple(entry/name for name in ('source_next_open_launcher.py','next_open_source.py','next_open_source51.py','next_open_source52.py'))
module.ALIASES=tuple(path.name for path in module.SOURCE_PATHS)
module.RUNTIMES=('python.exe','pythonw.exe','py.exe','pypy.exe','pypy3.exe')
original_run=module.subprocess.run
trace={}
def capture(*args,**kwargs):
    try:
        value=original_run(*args,**kwargs)
    except Exception as error:
        trace['transport_exception_type']=type(error).__name__
        raise
    trace.update({'returncode':value.returncode,'stdout_length':len(value.stdout),'stderr_length':len(value.stderr)})
    if len(value.stdout)<=512:
        try:trace['stdout_json']=json.loads(value.stdout)
        except Exception as error:trace['json_error_type']=type(error).__name__;trace['stdout_preview']=value.stdout[:200]
    # The original script only SELECTs ProcessId. Errors contain fixed query
    # predicates, never real command-line rows. No additional query is made.
    if value.stderr.strip():trace['transport_error']=value.stderr[:2400]
    return value
module.subprocess.run=capture
try:state=module.source_state(os.getpid())
finally:module.subprocess.run=original_run
result={'schema':'source52_new_exit_same_guard_diagnostic_v1','original_fixed_guard_pin':{'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest().upper()},'scope_unchanged_from52_installer':True,'result':state,'transport':trace,'queries_executed':'original fixed live/unknown count predicates only','additional_process_inventory':False,'source_or_guard_modified':False,'App_control_or_DB_read':False}
out=customer/'work/source53-root-integration/INSTALL-NEW-EXIT-GUARD-DIAGNOSTIC.json'
with out.open('x',encoding='utf-8') as handle:json.dump(result,handle,ensure_ascii=False,indent=2);handle.write('\n')
print(json.dumps(result,ensure_ascii=False))
