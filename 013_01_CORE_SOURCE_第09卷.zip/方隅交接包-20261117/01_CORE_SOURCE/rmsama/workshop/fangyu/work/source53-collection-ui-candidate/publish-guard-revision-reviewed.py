"""Root-only exclusive publication of the reviewed guard revision controls.

This script does not install desktop files or run any guard, CAS, or App.
"""
import hashlib
import json
import os
import stat
from pathlib import Path

PROJECT = Path('C:/积木软件工坊/项目/方隅公寓客户版')
WORK = PROJECT / 'work'
STAGE = WORK / 'source52-53-guard-revision-candidate'
ROOT = WORK / 'source53-root-integration'
ACCEPTED = ROOT / 'GUARD-REVISION-ROOT-ACCEPTED.json'
RESULT = ROOT / 'GUARD-REVISION-PUBLISHED.json'
ALLOWED_ROOTS = (
    WORK / 'source52-root-integration/guard-token-r2',
    WORK / 'source53-root-integration/guard-token-r2',
)

def pin(raw):
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest().upper()}

def checked(path, proof=None):
    current = PROJECT
    for part in path.relative_to(PROJECT).parts:
        current /= part
        info = current.lstat()
        if current.is_symlink() or getattr(info, 'st_file_attributes', 0) & 0x400:
            raise ValueError('reparse path refused')
    if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1:
        raise ValueError('non-regular file refused')
    raw = path.read_bytes()
    if proof is not None and pin(raw) != proof:
        raise ValueError('reviewed pin changed: ' + str(path))
    return raw

def safe_parent(path):
    current = PROJECT
    for part in path.parent.relative_to(PROJECT).parts:
        current /= part
        if not os.path.lexists(current):
            if not any(current == root or current.is_relative_to(root) for root in ALLOWED_ROOTS):
                raise ValueError('new directory outside revision roots')
            current.mkdir()
        info = current.lstat()
        if (not stat.S_ISDIR(info.st_mode) or current.is_symlink()
                or getattr(info, 'st_file_attributes', 0) & 0x400):
            raise ValueError('revision parent changed')

def main():
    acceptance = json.loads(checked(ACCEPTED))
    if (acceptance.get('schema') != 'source52_53_guard_revision_root_acceptance_v1'
            or acceptance.get('root_control_publication_authorized') is not True
            or acceptance.get('installation_authorized') is not False):
        raise ValueError('actual limited Root acceptance absent')
    plan_path = Path(acceptance['plan']['path'])
    if not plan_path.is_relative_to(STAGE):
        raise ValueError('plan outside owned candidate')
    plan = json.loads(checked(plan_path, acceptance['plan']['pin']))
    checked(Path(acceptance['frozen']['path']), acceptance['frozen']['pin'])
    checked(Path(acceptance['independent_review']['path']), acceptance['independent_review']['pin'])
    if plan.get('schema') != 'source52_53_guard_revision_binding_v1':
        raise ValueError('binding plan schema changed')
    rows = plan.get('files')
    if not isinstance(rows, list) or not 8 <= len(rows) <= 32:
        raise ValueError('fixed control set changed')
    changes = []
    seen = set()
    for row in rows:
        candidate, target = Path(row['candidate']), Path(row['target'])
        if (not candidate.is_absolute() or not target.is_absolute()
                or '..' in candidate.parts or '..' in target.parts):
            raise ValueError('non-canonical control path refused')
        if not candidate.is_relative_to(STAGE):
            raise ValueError('candidate outside owned stage')
        if not any(target.is_relative_to(root) for root in ALLOWED_ROOTS):
            raise ValueError('target outside new control roots')
        identity = str(target).replace('\\', '/').casefold()
        if identity in seen or os.path.lexists(target):
            raise ValueError('duplicate or existing control target')
        seen.add(identity)
        changes.append((candidate, target, row['pin'], checked(candidate, row['pin'])))
    if os.path.lexists(RESULT):
        raise ValueError('actual publication evidence preserved')
    records = []
    for candidate, target, proof, raw in changes:
        safe_parent(target)
        with target.open('xb') as stream:
            stream.write(raw)
            stream.flush()
            os.fsync(stream.fileno())
        checked(target, proof)
        records.append({'candidate': str(candidate), 'target': str(target), 'pin': proof})
    result = {
        'schema': 'source52_53_guard_revision_actual_publication_v1',
        'plan': acceptance['plan'], 'root_acceptance_pin': pin(checked(ACCEPTED)),
        'files': records, 'control_files': len(records),
        'old_public_controls_overwritten': 0, 'desktop_install_calls': 0,
        'business_apply_calls': 0, 'guard_query_calls': 0, 'App_control_calls': 0,
        'real_database_cookie_vault_reads_or_copies': 0,
        'installation_authorized': False, 'client_UI_updated': False,
    }
    with RESULT.open('x', encoding='utf-8') as stream:
        json.dump(result, stream, ensure_ascii=False, indent=2)
        stream.write('\n')
    print(json.dumps({'control_files': len(records), 'publication_receipt': str(RESULT),
                      'receipt_pin': pin(checked(RESULT)), 'client_UI_updated': False}, ensure_ascii=False))

if __name__ == '__main__':
    main()
