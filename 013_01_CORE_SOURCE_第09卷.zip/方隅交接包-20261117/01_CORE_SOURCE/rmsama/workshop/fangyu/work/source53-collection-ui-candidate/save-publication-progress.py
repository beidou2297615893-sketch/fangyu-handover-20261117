from pathlib import Path
import hashlib
import json
import uuid

root = Path(__file__).resolve().parent
customer = root.parents[1]
block = '''# 2026-10-14 当前：采集UI与Source53本地接入文件已审核，尚未安装

新聊天01a13a0e-b66c-72a3-a82a-8ad950462a6b是本客户唯一正式/中央写者。采集投诉第一优先，完整R01–R25、初版二版和商业目标继续；不以局部通过记整产品完成。

采集Source53真实代码候选已冻结：账号条→关键词找笔记→笔记评论，右侧独立状态/核对/停止/确认结束，短按钮与窄窗口样式。保留原ID和107监听器、440其他原named函数、真实范围与原号未知保持。源码/模块DOM有限通过；真实原生画面、Tab/Enter、form验证、BDF原图1:1与用户软件认可尚未验。

后继CAS/累积50→53协调、两目标native准备及最终绑定已分别通过有限独立审。Root实际本地签发并独占复制13份新53控制代码/元数据；非作者实际逐份读回一致，Root全文接受PUBLICATION-ACTUAL-READBACK。事实回执work/source53-root-integration/PUBLISHED.json、PUBLICATION-READBACK-ROOT-ACCEPTED.json。这是本地接入文件准备，不是正式SOURCE/desktop安装、真实装载或对外发布。旧52三authority、当前MJS/CSS及51desktop代码均保持；原52首HOLD保留，52/53桌面helper尚未安装。不重installer/guard/PID/preflight/check-only，不猜现在占用/退出，不绕52依赖或自动reapply。

REA v1.2包已按固定ZIP/hash/9文件实收并完成三聊天授权协调。旧商业leads_list快照C04发现来源失权续页缺口；r1 TDD候选后独审又发现selected group的非选中组缓存元数据未核权限，CHANGES_REQUIRED保留。r2正在独立冻结所有贡献view的source IDs并补公开接口反例；未合入，不混入Source53，不当当前owner采集UI回归。

当前R02/R07/R10/R24：采集UI候选和接入文件具备有限代码证据，真实使用仍未验。R19：Source52店长/HQ r2已有限审及本地authority签发，仍首安装HOLD；不是旧表“无候选”，也不是商业就绪。R25：新53本地发布与读回已完成，真实安装和交付包未完成。台账旧9/10不是完整商业百分比。本人获客、模型精准费用吞吐、自然人同意、真实资源部/第二实体机、SDK KMS云、成交支付等继续未知。

最新后继work/product-upgrade-20261009/audits/source53-current.md及work/source53-root-integration/NEXT.md。0原App控制/ComputerUse/截图绕行/网页替代、0真实DBCookieVault读hashcopy、0平台模型发送/打包部署付费。历史goal未伪造恢复或complete。

以下历史保留，当前事实以上段及实际回执为准。

'''
paths = [customer/'memory/STATUS.md', customer/'outputs/产品升级/当前执行事实.md',
         customer/'outputs/产品升级/需求交付与证据台账.md',
         customer/'work/product-upgrade-20261009/handoff/CURRENT.md',
         customer/'work/product-upgrade-20261009/audits/source53-current.md']
backup = root/'document-backups'/uuid.uuid4().hex
backup.mkdir(parents=True)
receipt=[]
for index, path in enumerate(paths):
    raw=path.read_bytes()
    assert not raw.startswith(block.encode('utf-8')), 'Already recorded'
    dest=backup/(str(index)+'-'+path.name)
    dest.write_bytes(raw)
    path.write_bytes(block.encode('utf-8')+raw)
    receipt.append({'path':str(path),'backup':str(dest),
                    'before_sha256':hashlib.sha256(raw).hexdigest().upper(),
                    'after_sha256':hashlib.sha256(path.read_bytes()).hexdigest().upper()})
ui=customer/'outputs/采集界面修复/采集页具体改动与验收.md'
raw=ui.read_bytes()
(backup/'5-采集页具体改动与验收.md').write_bytes(raw)
txt=raw.decode('utf-8')
old='新后继CAS与正常下一开协调正在独立准备，旧50/51/52 authorities和失败保持。'
assert old in txt
txt=txt.replace(old,'新后继CAS、正常下一开协调与native绑定已经有限独审；Root已本地签发13份新53接入代码/元数据，非作者逐份实际读回相符并获Root接受。旧50/51/52 authorities和失败保持，当前业务源码与51桌面入口保持原样；52首安装HOLD仍有效，53不能越过52实际安装依赖。')
txt=txt.replace('仍待：新后继代码与独审、真实安装条件证据、正常装载与实际读回、','仍待：真实安装条件证据、正常装载与实际读回、')
ui.write_text(txt,encoding='utf-8')
receipt.append({'path':str(ui),'backup':str(backup/'5-采集页具体改动与验收.md'),
                'before_sha256':hashlib.sha256(raw).hexdigest().upper(),
                'after_sha256':hashlib.sha256(ui.read_bytes()).hexdigest().upper()})
out=root/'PUBLICATION-DOCUMENT-UPDATED.json'
with out.open('x',encoding='utf-8') as handle:
    json.dump({'schema':'source53_publication_progress_document_backup_v1',
               'documents':receipt,'original_source_written':False},handle,ensure_ascii=False,indent=2)
    handle.write('\n')
print(json.dumps({'documents':len(receipt),'original_source_written':False}))
