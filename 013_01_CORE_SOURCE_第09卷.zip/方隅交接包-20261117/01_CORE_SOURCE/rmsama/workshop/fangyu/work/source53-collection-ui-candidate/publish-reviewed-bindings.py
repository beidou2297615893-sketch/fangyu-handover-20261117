"""Root-only local publication of reviewed public metadata/code. No installation."""
from pathlib import Path
import hashlib, json, os
CUSTOMER=Path('C:/积木软件工坊/项目/方隅公寓客户版')
OWN=CUSTOMER/'work/source53-collection-ui-candidate'
STAGED=CUSTOMER/'work/source53-successor-proposal/approved-bind-candidate'
DEST=CUSTOMER/'work/source53-root-integration'
AUDITS=CUSTOMER/'work/product-upgrade-20261009/audits'
def pin(p):
    raw=p.read_bytes();return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest().upper()}
def no_links(p):
    for part in (p,*p.parents):
        if part.exists() and (part.is_symlink() or getattr(part.lstat(),'st_file_attributes',0)&0x400):
            raise ValueError('linked publication path refused')
frozen_path=STAGED/'FROZEN.json'
assert pin(frozen_path)=={'bytes':8683,'sha256':'1F6CABA10F3F1D86047DFBBC75DAE3EECB9ECC0A7E9EBB681CE292266419C3E0'}
frozen=json.loads(frozen_path.read_bytes())
for path,expected in frozen['files'].items():assert pin(Path(path))==expected
reviews=CUSTOMER/'work/source53-collection-ui-review'
review_paths=[reviews/name for name in ('REVIEW.md','LINEAGE-REVIEW.md','SUCCESSOR-REVIEW.md','NATIVE-BINDING-REVIEW.md','FINAL-BINDING-REVIEW.md')]
assert all(p.is_file() for p in review_paths)
assert 'PASS_STAGED_CONSTANT_BINDING_ONLY' in review_paths[-1].read_text(encoding='utf-8')
plan=json.loads((STAGED/'PLAN.json').read_bytes())
assert plan['Root_acceptance_pending'] is True and len(plan['artifacts'])==13
audit_allow={AUDITS/name for name in ('join-source53-reviewed.py','source53-final-root-read.json','source53-manifest.json')}
publish=[]
for row in plan['artifacts']:
    target=Path(row['future'])
    assert target.is_relative_to(DEST) or target in audit_allow
    no_links(target)
    assert not os.path.lexists(target), 'Do not overwrite an existing immutable publication'
    source=Path(row['stage'])
    assert source.is_relative_to(STAGED/'staging-r2') and pin(source)==row['pin']
    publish.append((source,target,row['pin']))
no_links(DEST)
assert not DEST.exists(), 'Root publication is once only, never automatic reapply'
DEST.mkdir()
accept={'schema':'source53_actual_root_conditional_publication_acceptance_v1',
        'status':'ROOT_ACCEPTED_LOCAL_BINDINGS_ONLY_NOT_INSTALLED',
        'authorization':'User continued collection UI repair and complete task handoff; Root actual reviews read and accepted',
        'frozen':{'path':str(frozen_path),'pin':pin(frozen_path)},
        'independent_reviews':[{'path':str(p),'pin':pin(p)} for p in review_paths],
        'root_reports_full_read':True,
        'signature_scope':'Adopt exact staged signing proposals as conditional new local Source53 authorities. Proposal markers retained as provenance; this separate receipt is actual Root acceptance.',
        'proposal_marker_is_not_install_or_runtime_proof':True,
        'approved_install_now':False,
        'actual_execution_still_requires':['new genuine availability','actual52 native installed exact dependency','original OS lock and fresh guard','cumulative actual receipts and historical backups'],
        'original_source_business_targets_written':0,'native_launcher_or_helper_installed':0,
        'original_App_control':0,'source52_installer_guard_pid_preflight_calls':0,
        'real_database_cookie_vault_read_copy':0,'platform_model_send_package_deploy_payment':0,
        'source52_original_first_HOLD_preserved':True,
        'real_GUI_acceptance':False,'complete_R01_R25':False}
accept_path=DEST/'ROOT-ACCEPTED.json'
with accept_path.open('x',encoding='utf-8') as stream:stream.write(json.dumps(accept,ensure_ascii=False,indent=2)+'\n')
written=[]
try:
    for source,target,expected in publish:
        target.parent.mkdir(parents=True,exist_ok=True)
        with target.open('xb') as stream:stream.write(source.read_bytes())
        assert pin(target)==expected
        written.append({'path':str(target),'pin':expected})
except Exception as error:
    failure={'status':'LOCAL_PUBLICATION_PARTIAL_NO_INSTALL','written':written,'error':str(error),'automatic_retry':False}
    (DEST/'PUBLICATION-FAILED.json').write_text(json.dumps(failure,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    raise
result={'schema':'source53_root_actual_local_publication_v1','status':'LOCAL_PUBLIC_AUTHORITIES_PUBLISHED_NO_INSTALL',
        'root_acceptance':{'path':str(accept_path),'pin':pin(accept_path)},'files':written,
        'count':len(written),'source_installed':False,'native_installed':False,
        'original_source_writes':0,'guard_PID_installer_App_actions':0,'old_authority_writes':0,
        'automatic_apply_or_retry':False}
(DEST/'PUBLISHED.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'status':result['status'],'files':len(written),'source_installed':False,'native_installed':False},ensure_ascii=False))
