import hashlib,json
from pathlib import Path
P=Path('C:/积木软件工坊/项目/方隅公寓客户版');W=P/'work';S=W/'source52-53-guard-revision-candidate'
R=W/'source53-collection-ui-review';ROOT=W/'source53-root-integration'
def fixed(path,size,digest):
    raw=path.read_bytes();assert len(raw)==size and hashlib.sha256(raw).hexdigest().upper()==digest,str(path)
    return {'path':str(path),'pin':{'bytes':size,'sha256':digest}}
frozen=fixed(S/'FROZEN.json',8443,'2813AE566255EA6105426EA634C170B0FF291A6F22E2C13075F8EC317FD0676F')
plan=fixed(S/'PLAN.json',33220,'56BCA7F5BFCD4F72B5EA0E2AE11C3338D6070205FE377E61BB5EAA904A0ED3F4')
report=fixed(S/'REPORT.md',3733,'E3C12CFFB5877922D691E1D5CFB3808D32F3166D7DAC8A607FE51E78285B9BBD')
peer=fixed(R/'GUARD-REVISION-BINDING-REVIEW.md',4203,'945BA694FC2750BA29D21E14F18EF1542B12809C83792B48A98F5E12E1A5B4BD')
peer_json=fixed(R/'GUARD-REVISION-BINDING-REVIEW.json',22753,'9D420AB7E15C3E8B36A174C9FB1BC1539427262A7EEB0936D91DE73E0D4224DC')
data=json.loads((S/'FROZEN.json').read_text(encoding='utf-8'));mapping=json.loads((S/'PLAN.json').read_text(encoding='utf-8'))
assert data['candidate_files']==18 and len(mapping['files'])==18
for row in mapping['files']:
    assert data['files'][row['candidate']]==row['pin']
    fixed(Path(row['candidate']),row['pin']['bytes'],row['pin']['sha256'])
assert 'PASS_LIMITED_FROZEN_BINDING_AND_OWNED_SEAMS' in (R/'GUARD-REVISION-BINDING-REVIEW.md').read_text(encoding='utf-8')
result={
 'schema':'source52_53_guard_revision_root_acceptance_v1',
 'root_chat':'01a13a0e-b66c-72a3-a82a-8ad950462a6b',
 'status':'ACTUAL_ROOT_LIMITED_CONTROL_PUBLICATION_ACCEPTED',
 'plan':plan,'frozen':frozen,'author_report':report,'independent_review':peer,'independent_review_json':peer_json,
 'root_reports_read_in_full':True,'root_delta_read_tool':'15f191','root_peer_full_read_tool':'ee4647',
 'root_control_publication_authorized':True,'installation_authorized':False,
 'guard_revision_adopted_as_reviewed_bugfix':True,
 'guard_fix':'dynamic option token prefix only; genuine dynamic/NULL/empty/relative/leading unknown and live refusal preserved',
 'old_guard_and_public_controls_overwrite_authorized':False,
 'current_unknown_exemption_authorized':False,'actual_idle_proven':False,
 'same_original_state_receipt_backup_paths':True,
 'new_native_business_evidence_early_refusal_accepted':True,
 'source52_business_payload_targets_protected_dependencies':[9,462,17],
 'source53_UI_payload_targets_protected':[3,470],
 'user_new_action_evidence':'已正常退出，可以重新评估安装',
 'remaining_before_install':'independent actual18 public readback and Root actual installation decision; fresh guard remains inside exact new installer',
 'prior_first_and_new_exit_HOLD_preserved':True,
 'original_App_control_calls':0,'business_apply_calls':0,'guard_queries':0,
 'real_database_cookie_vault_reads_or_copies':0,'client_UI_updated':False,'commercial_complete':False,
}
target=ROOT/'GUARD-REVISION-ROOT-ACCEPTED.json'
with target.open('x',encoding='utf-8') as stream:json.dump(result,stream,ensure_ascii=False,indent=2);stream.write('\n')
print(json.dumps({'accepted':str(target),'candidate_files':18,'installation_authorized':False},ensure_ascii=False))
