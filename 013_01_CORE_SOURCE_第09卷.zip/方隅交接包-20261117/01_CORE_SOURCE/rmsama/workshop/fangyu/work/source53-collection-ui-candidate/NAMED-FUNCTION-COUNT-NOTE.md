# 原函数计数口径

FROZEN.json中的 historical 字段名 originalBusinessFunctionsUnchanged 记录值440，实际来自 verify.mjs 对441个原named functions逐个toString比较，排除改变的composeFourOwnerPages后剩余440个原函数。它包含业务和视觉函数，不表示全部440个都是业务函数，也不是440项功能验收。

保留冻结元数据与已绑定pins，不为术语修正变更冻结源或破坏后继绑定。实际新报告和独立REVIEW已使用“其他原named functions（含业务与视觉）”口径。没有据该计数判断完整功能、GUI或商业完成。
