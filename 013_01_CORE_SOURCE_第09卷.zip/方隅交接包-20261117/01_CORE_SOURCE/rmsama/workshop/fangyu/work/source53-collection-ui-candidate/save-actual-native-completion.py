import hashlib,json,uuid
from pathlib import Path
P=Path('C:/积木软件工坊/项目/方隅公寓客户版');W=P/'work';A=W/'product-upgrade-20261009/audits';R=W/'source53-collection-ui-review';ROOT=W/'source53-root-integration'
def fixed(path,size,digest):
    raw=path.read_bytes();assert len(raw)==size and hashlib.sha256(raw).hexdigest().upper()==digest,str(path)
    return {'path':str(path),'pin':{'bytes':size,'sha256':digest}}
peer=fixed(R/'GUARD-REVISION-NATIVE-ACTUAL-READBACK.md',1676,'3C6BAEE27525EAB1D79BE69308510221AC195055740F2365C47512EAE5DA4786')
peer_json=fixed(R/'GUARD-REVISION-NATIVE-ACTUAL-READBACK.json',8544,'1884E4C5026F96EB4459E115C29E5AF2A36AAB4EF4762006D5584942CDCECA40')
raw52=fixed(A/'source52-native-installed.json',1874,'613E43C5461A775FB5BFABE45E2A36178E0CB03CB9AD9DDF1A2F3BC0C3196E51')
raw53=fixed(A/'source53-native-installed.json',2175,'644B80863EA5E452438A062FAC902EA1902B69F0D1087B4E98F8C69C3C6DDF8E')
value={'schema':'source52_53_guard_revision_actual_native_root_read_v1','status':'ACCEPTED_ACTUAL_NATIVE52_TO53_ONLY',
 'root_chat':'01a13a0e-b66c-72a3-a82a-8ad950462a6b','peer_report':peer,'peer_json':peer_json,'root_full_read_tool':'9c89b2',
 'actual_native52':{'tool':'e52d40','exit_code':0,'receipt':raw52,'backup':str(P/'backups/source52-native/c6cb3e367157496fa9f46855849cc496')},
 'actual_native53':{'tool':'05236f','exit_code':0,'receipt':raw53,'backup':str(P/'backups/source53-native/598bf82b4ac84a05bb19b3b1c7d63c9d')},
 'original51_parent_and52_parent_backups_independently_verified':True,'original50_51_helpers_preserved':True,
 'local_control_publication_files':18,'native_file_write_operations':4,'unique_native_targets':3,
 'installer_reported_business_apply_calls':0,'Root_normal_open_wrapper_calls':0,'Root_App_control_calls':0,
 'normal_open_business50_53_verified':False,'client_UI_loaded_or_visually_accepted':False,
 'prior_first_and_new_exit_HOLD_evidence_preserved':True,'new_revision_guards_accepted_without_unknown_exemption':True,
 'real_database_cookie_vault_reads_or_copies':0,'external_publish_package_deploy_pay_calls':0,
 'goal_status_not_modified':True,'commercial_R01_R25_complete':False,
 'required_next':'human normal original desktop opening; no Root App control. Only actual new opening evidence permits necessary business raw/backup/current readback. Independent54 P2+new53 rebase may continue.'}
target=ROOT/'GUARD-REVISION-NATIVE-ROOT-READ.json'
with target.open('x',encoding='utf-8') as stream:json.dump(value,stream,ensure_ascii=False,indent=2);stream.write('\n')
prefix='''# 2026-10-14 最新实际成果：采集新版已接入原桌面入口，52→53薄安装已独审读回

用户已明确正常退出允许重评。Root完整接受已审EC86 token守卫修复及18件新固定控制包，实际本地exclusive发布d9af0e，旧PUBLIC/1E guard与首65e463、后ac3d26 HOLD原件保持。修复不排除真实unknown；真正动态/relative/NULL/empty/leading与live仍拒，所有原单号/备份地址共享。publication与Root限定接受原记录不倒填installed。

Root唯一实际新52 installer A6B996F2 于e52d40 exit0，两薄文件安装成功；随后53 installer D08CF3FF 于05236f exit0成功。原native52收据1874/613E43C5，native53收据2175/644B8086，均businessapply0/App等flagsfalse。actual52 backup c6cb3e367157496fa9f46855849cc496保存原51launcher AA029206；actual53 backup598bf82b4ac84a05bb19b3b1c7d63c9d保存新52launcher E8138AD0。当前桌面H52=15623/1C919E94、H53=5903/93DE3F1E、launcher=5405/994ED84B；50/51helpers保持，原桌面快捷方式不改。

非作者actual联合4eac7d核当前three thin targets、两原native raw、raw53→raw52、两实际parent backups、保护与temp，PASS；Root全文9c89b2读接受，实际记录work/source53-root-integration/GUARD-REVISION-NATIVE-ROOT-READ.json。不冒旧52launcher仍在当前：其原成功父已被53覆盖，按actual53backup核。所有失败历史保持，无重installer/guard/wrapper或强停。

下一步用户可从原桌面“方隅工作台”正常打开；启动链将按既有OS锁、fresh本客户来源门与原raw/backup链核对并装载50→51→新52→新53。Root未打开/退出/重启原App。薄入口安装不是业务Source52九件/53三UI件已经apply，更不是采集GUI/原图1:1/本人获客或完整商业R01–R25验收。当前业务源码未查，不假设人类是否已打开；仅有新的实际打开/成功证据才必要联合读回business原raw/实际parent backups/current/protected。STARTED无success/FAILED保原号，不自动reapply。

完整商业、真实SDK/KMS/云/第二实体机/自然同意/模型精准费用吞吐/支付及GUI仍未验。本线程所属author继续独立54旧导出候选的r1 P2与新53guard-token-r2前驱重基，保持false/unbound/无Stage3或生产安装，旧冻保持；不能因等打开或反馈停止这项真实独立工作。0真实DBCookieVault读hashcopy/ComputerUse截图绕行/网页替代/平台模型发送/打包部署付费；automation ACTIVE、goal未伪造恢复/完成。

以下旧记录保留，当前事实以上段及实际回执为准。

'''.encode('utf-8')
paths=[W/'product-upgrade-20261009/handoff/CURRENT.md',P/'memory/STATUS.md',P/'outputs/产品升级/当前执行事实.md',A/'source52-current.md',A/'source53-current.md',ROOT/'NEXT.md',P/'outputs/采集界面修复/采集页具体改动与验收.md',P/'memory/sessions/2026-10-14-新聊天接续采集界面修复.md']
originals=[(path,path.read_bytes()) for path in paths]
backup=W/'source53-collection-ui-candidate/document-backups'/('actual-native-'+uuid.uuid4().hex);backup.mkdir()
records=[]
for i,(path,raw) in enumerate(originals):
    saved=backup/(str(i)+'.md');saved.write_bytes(raw);assert saved.read_bytes()==raw
    path.write_bytes(prefix+raw)
    records.append({'path':str(path),'backup':str(saved),'before_sha256':hashlib.sha256(raw).hexdigest().upper()})
(backup/'RECORD.json').write_text(json.dumps(records,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'native_root_acceptance':str(target),'updated':len(paths),'backup':str(backup),'Root_App_control_calls':0,'business_apply_calls':0},ensure_ascii=False))
