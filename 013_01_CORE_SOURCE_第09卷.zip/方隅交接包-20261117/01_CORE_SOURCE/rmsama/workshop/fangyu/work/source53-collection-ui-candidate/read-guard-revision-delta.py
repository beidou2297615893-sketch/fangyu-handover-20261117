import ast,difflib,hashlib,json
from pathlib import Path
P=Path('C:/积木软件工坊/项目/方隅公寓客户版');W=P/'work'
plan=json.loads((W/'source52-53-guard-revision-candidate/PLAN.json').read_text(encoding='utf-8'))
def pin(raw):return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest().upper()}
old={
 'source52-root-integration/guard-token-r2/join-source52-reviewed.py':'source52-root-integration/join-source52-reviewed-final.py',
 'source52-root-integration/guard-token-r2/next_open_source52-final.py':'source52-root-integration/next_open_source52-final.py',
 'source52-root-integration/guard-token-r2/source_next_open_launcher-final.py':'source52-root-integration/source_next_open_launcher-final.py',
 'source52-root-integration/guard-token-r2/install-native-authorized.py':'source52-root-integration/install-native-authorized.py',
 'source53-root-integration/guard-token-r2/join-source53-reviewed.py':'source53-root-integration/join-source53-reviewed.py',
 'source53-root-integration/guard-token-r2/next_open_source53.py':'source53-root-integration/next_open_source53.py',
 'source53-root-integration/guard-token-r2/source_next_open_launcher.py':'source53-root-integration/source_next_open_launcher.py',
 'source53-root-integration/guard-token-r2/native/install_native53.py':'source53-root-integration/native/install_native53.py',
}
def functions(raw):
    lines=raw.decode('utf-8').splitlines(keepends=True)
    return {n.name:''.join(lines[n.lineno-1:n.end_lineno]) for n in ast.parse(raw).body if isinstance(n,ast.FunctionDef)}
records=[]
for row in plan['files']:
    raw=Path(row['candidate']).read_bytes();assert pin(raw)==row['pin']
    key=Path(row['target']).relative_to(W).as_posix()
    if key in old:
        before=functions((W/old[key]).read_bytes());after=functions(raw)
        assert before.keys()==after.keys()
        changed=[n for n in before if before[n]!=after[n]]
        if changed:
            assert changed==['main'] and ('install-native-authorized' in key or 'install_native53' in key)
            print(''.join(difflib.unified_diff(before['main'].splitlines(True),after['main'].splitlines(True),fromfile=old[key],tofile=key,n=2)))
        records.append({'file':key,'functions':len(before),'changed':changed})
    elif key.endswith('source_idle_guard.py'):
        assert raw==(W/'rea-candidate-audit/guard-token-candidate/candidate_guard.py').read_bytes()
        records.append({'file':key,'exact_reviewed_guard':True})
newprep=Path(next(r['candidate'] for r in plan['files'] if r['target'].endswith('PREPARED.json')))
before=json.loads((W/'source53-root-integration/PREPARED.json').read_text(encoding='utf-8'));after=json.loads(newprep.read_text(encoding='utf-8'))
for key in ('targets','protected','candidate_dependencies'):
    if key in before:
        assert before[key]==after[key],key
print(json.dumps({'all_plan_files_match':len(plan['files']),'function_deltas':records,'source53_payload_and_protection_unchanged':True,'production_module_imports':0,'queries':0},ensure_ascii=False))
