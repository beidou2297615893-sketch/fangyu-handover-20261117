from pathlib import Path
import hashlib, json, uuid
ROOT=Path(__file__).resolve().parent
CUSTOMER=ROOT.parent.parent
AUDITS=ROOT.parent/'product-upgrade-20261009/audits'
backups=ROOT/'document-backups'/uuid.uuid4().hex
backups.mkdir(parents=True)
block='''# 2026-10-14 新聊天已激活：采集 UI 正在实际修复

本客户唯一正式/中央写者为新聊天01a13a0e-b66c-72a3-a82a-8ad950462a6b，已实读ACTIVE迁移回执和原Root激活消息；automation-14已迁移，原聊天仅留历史。用户最新采集UI投诉优先，完整R01–R25/初版二版/商业目标继续。

Source53采集UI两基底隔离候选已冻结并通过最小非作者CODE/模块DOM审：账号→找笔记→采集评论，独立状态侧栏与窄宽度样式、主按钮短文案；原255/257 ID、107监听器和440其他原named函数保持，未知原号不重发，可查/停。首次detached表单查找RED及修正版必要复验保留。不是已安装、真实GUI或用户软件认可。

三物理target（future51 MJS、CSS和本地CSS镜像）与470prospective保护的Source53后继元数据方案已独审，仍PROPOSAL_NOT_INSTALLABLE、join_authorized=false。新的53 CAS/正常下一开协调候选正由本聊天所属agent在独立目录准备；不以安装52HOLD停止此独立开发。现时0正式SOURCE写，旧50/51/52图和52首HOLD保持；无新状态不重旧installer/guard/PID/preflight/check-only，不改占用门/强停/自动reapply。

详细新后继：work/product-upgrade-20261009/audits/source53-current.md；用户可读outputs/采集界面修复/采集页具体改动与验收.md。0真实DB/Cookie/Vault读取hash复制、0原App控制/ComputerUse/截图/网页替代/平台模型发送/打包部署付费。完整GUI/本人账号/自然同意/第二机/SDK KMS云/模型费用精准吞吐/成交支付继续未验。未伪造历史goal恢复、active/newgoal/complete。

以下历史原件保留，当前阶段以上段和新实际回执为准。

'''
paths=[CUSTOMER/'memory/STATUS.md',CUSTOMER/'outputs/产品升级/当前执行事实.md',
       ROOT.parent/'product-upgrade-20261009/handoff/CURRENT.md']
receipt=[]
for i,p in enumerate(paths):
    raw=p.read_bytes()
    backup=backups/(str(i)+'-'+p.name)
    backup.write_bytes(raw)
    p.write_bytes(block.encode('utf-8')+raw)
    receipt.append({'path':str(p),'backup':str(backup),'before_sha256':hashlib.sha256(raw).hexdigest().upper(),'after_sha256':hashlib.sha256(p.read_bytes()).hexdigest().upper()})
pointer=AUDITS/'source53-current.md'
assert not pointer.exists(), 'Do not overwrite a newer pointer'
pointer.write_text(block+'''Source53独立CODE：work/source53-collection-ui-candidate/FROZEN.json、ROOT-ACCEPTED.json、FIRST-RED.md。
后继metadata：LINEAGE-PROPOSAL.json与prepare-lineage.py，独审work/source53-collection-ui-review/REVIEW.md、LINEAGE-REVIEW.md。
当前唯一新agents：collection_ui_review已完成有限审；collection_successor_prepare在work/source53-successor-proposal准备后继。未沿用旧agents或假装自动迁移。
下一有用动作是候选后继代码及独审；当前没有新真实availability，不请求或轮询原52gate。原图BDF与完整需求台账保持，不能用此阶段代替整体完成。
''',encoding='utf-8')
(ROOT/'DOCUMENT-UPDATED.json').write_text(json.dumps({'schema':'source53_progress_document_backup_v1','source_code_written':False,'documents':receipt,'new_pointer':str(pointer)},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'backed_up_documents':len(receipt),'source_code_written':False},ensure_ascii=False))
