from pathlib import Path
import json, hashlib
ROOT=Path(__file__).resolve().parent
def pin(path):
    raw=path.read_bytes();return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest().upper()}
frozen=json.loads((ROOT/'FROZEN.json').read_bytes())
for path,expected in frozen['files'].items():assert pin(Path(path))==expected
prepared=json.loads((ROOT/'PREPARED.json').read_bytes())
unchanged={}
for name,parent in prepared['parents'].items():
    current=pin(Path(parent['path']))
    assert current['bytes']==parent['bytes'] and current['sha256']==parent['sha256'].upper()
    unchanged[parent['path']]=current
review=ROOT.parent/'source53-collection-ui-review/REVIEW.md'
assert review.exists()
lineage_review=ROOT.parent/'source53-collection-ui-review/LINEAGE-REVIEW.md'
assert lineage_review.exists()
report={'schema':'source53_root_candidate_review_acceptance_v1','status':'ACCEPT_ISOLATED_CODE_ONLY',
        'frozen_pin':pin(ROOT/'FROZEN.json'),'independent_review':{'path':str(review),'pin':pin(review)},
        'root_full_review_read_tool':'functions.exec REVIEW.md full read after agent review',
        'public_formal_sources_still_original':unchanged,
        'code_issue_first_red_preserved':True,'original_source_writes':0,
        'original_app_control':0,'source52_installer_guard_pid_calls':0,
        'real_database_cookie_vault_reads':0,'GUI_or_user_acceptance':False,
        'installable_successor':False,'lineage_proposal_review':{'path':str(lineage_review),'pin':pin(lineage_review),'status':'ACCEPT_METADATA_ONLY'},
        'completion_scope':'isolated collection UI candidate; full R01-R25 remains open'}
(ROOT/'ROOT-ACCEPTED.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'status':report['status'],'formal_source_writes':0,'full_project_complete':False},ensure_ascii=False))
