from pathlib import Path
import hashlib
import json

customer = Path(__file__).resolve().parents[2]
review = customer / 'work/source53-collection-ui-review'
integration = customer / 'work/source53-root-integration'
paths = [review / 'PUBLICATION-ACTUAL-READBACK.md',
         review / 'PUBLICATION-ACTUAL-READBACK.json',
         integration / 'ROOT-ACCEPTED.json', integration / 'PUBLISHED.json']
pins = []
for path in paths:
    raw = path.read_bytes()
    pins.append({'path': str(path), 'bytes': len(raw),
                 'sha256': hashlib.sha256(raw).hexdigest().upper()})
out = integration / 'PUBLICATION-READBACK-ROOT-ACCEPTED.json'
data = {'schema': 'source53_publication_readback_root_acceptance_v1',
        'root_chat': '01a13a0e-b66c-72a3-a82a-8ad950462a6b',
        'status': 'ACCEPTED_ACTUAL_LOCAL_PUBLICATION_NOT_INSTALLED',
        'review_read_in_full': True, 'evidence': pins,
        'published_files': 13, 'independent_actual_readback': True,
        'source_installed': False, 'native_installed': False,
        'approved_install_now': False,
        'source52_first_hold_preserved': True,
        'new_availability_observed': False,
        'Root_guard_PID_installer_App_actions': 0,
        'Root_original_source_writes': 0,
        'GUI_or_user_acceptance_claimed': False}
with out.open('x', encoding='utf-8') as handle:
    json.dump(data, handle, ensure_ascii=False, indent=2)
    handle.write('\n')
print(json.dumps({'receipt': str(out), 'status': data['status']}))
