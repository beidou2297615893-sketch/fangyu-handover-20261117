from pathlib import Path
import hashlib,json,uuid
root=Path(__file__).resolve().parent
customer=root.parents[1]
block='''# 2026-10-14 当前继续：Source54 Stage2默认不授权的薄入口准备

Stage1已有限独审并Root实际接受，现所属author在work/source54-legacy-export-proposal/native准备两个native目标及false/unbound安装代码，reviewer并行审新增前置接口。Stage1冻结与53已签字节保持。不为阶段推进重新跑7事务/20业务或旧QA。

54 helper只apply54而不重放53，因此新native安装的将来前置必须同时具备actual native53 installed与actual Source53 business success、原50–53 raw/backups/current proof；只发布53或只装53薄入口均不足，不能提前换54入口堵住53初次装载。新增helper54，launcher仅以future53父为基底，50/51/52/53helper和原entry/desktoplinks保持。false默认在metadata/guard前拒，原窄门和Root唯一writer前提保持，不扩大占用扫描或声称globalmutex。

当前尚无Stage2冻结/独审或54签发/安装。无新genuineavailability，不执行原52/53/54installer/guard/PID/preflight/check-only/App；真实数据、平台模型发送、打包部署付费均0。采集UI未装入原客户端及完整R01–R25商业未验收保持。下一根据本线程新native冻结/必要代表/独审继续，不能用已有false候选执行生产。

以下历史保留，当前以上段及实际新回执为准。

'''
backup=root/'document-backups'/uuid.uuid4().hex;backup.mkdir(parents=True)
records=[]
for i,path in enumerate([customer/'work/product-upgrade-20261009/handoff/CURRENT.md',customer/'memory/STATUS.md',customer/'outputs/产品升级/当前执行事实.md',customer/'work/product-upgrade-20261009/audits/source54-current.md',customer/'work/source54-root-integration/NEXT.md']):
    raw=path.read_bytes();dest=backup/(str(i)+'-'+path.name);dest.write_bytes(raw)
    path.write_bytes(block.encode('utf-8')+raw)
    records.append({'path':str(path),'backup':str(dest),'before_sha256':hashlib.sha256(raw).hexdigest().upper(),'after_sha256':hashlib.sha256(path.read_bytes()).hexdigest().upper()})
with (root/'STAGE54-NATIVE-START-DOCUMENTS.json').open('x',encoding='utf-8') as handle:
    json.dump({'documents':records,'source_writes':0,'original_App_guard_private_actions':0},handle,ensure_ascii=False,indent=2);handle.write('\n')
print(json.dumps({'backed_up_documents':len(records),'source_writes':0}))
