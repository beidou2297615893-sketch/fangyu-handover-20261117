from pathlib import Path
import hashlib,json
root=Path(__file__).resolve().parent;customer=root.parents[1]
candidate=customer/'work/rea-candidate-audit/guard-token-candidate'
review=customer/'work/source53-collection-ui-review/GUARD-TOKEN-REVIEW.md'
pins=[]
for path in [review,candidate/'FROZEN.json',candidate/'candidate_guard.py',candidate/'REPORT.md',candidate/'FIRST-RED.json',candidate/'GREEN.json']:
    raw=path.read_bytes();pins.append({'path':str(path),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest().upper()})
assert pins[0]['sha256']=='7F66E4208A6C9A30C753A2FF45EA565C2172634E28E750C51BCF19188EEC89F6'
assert pins[1]['sha256']=='E1E66979840D02BAAD402D5E03028AAC1A8099255280ED0DDA19C60E88BCCA6A'
out=customer/'work/source53-root-integration/GUARD-CANDIDATE-ROOT-LIMITED-ACCEPTED.json'
with out.open('x',encoding='utf-8') as handle:
    json.dump({'schema':'guard_token_root_limited_candidate_acceptance_v1','root_chat':'01a13a0e-b66c-72a3-a82a-8ad950462a6b','status':'ACCEPTED_ISOLATED_SEMANTICS_AND_OWNED_ONLY','review_read_in_full':True,'evidence':pins,'tests':7,'owned_windows_count_pairs':8,'production_guard_replacement_authorized':False,'old_guard_and_signed_chains_preserved':True,'current_unknown_exempted':False,'actual_unknown_identity_proven':False,'actual_idle_claimed':False,'required_next':'fixed new52/53 revision binding map, candidate and independent review before any Root adoption; no runtime patch or automatic installer retry','App_control_or_DB_Cookie_Vault_actions':0},handle,ensure_ascii=False,indent=2);handle.write('\n')
print(json.dumps({'receipt':str(out),'original_guard_replaced':False},ensure_ascii=False))
