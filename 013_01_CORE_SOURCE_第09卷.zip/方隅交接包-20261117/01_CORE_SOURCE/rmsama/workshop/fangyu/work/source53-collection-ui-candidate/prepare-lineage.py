"""Prepare public metadata only. Never import/apply a CAS, gate, guard, or App."""
from pathlib import Path
import hashlib, json
ROOT=Path(__file__).resolve().parent
CUSTOMER=ROOT.parent.parent
def pin(path):
    raw=path.read_bytes()
    return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest().upper()}
def same(a,b):
    return a['bytes']==b['bytes'] and a['sha256'].upper()==b['sha256'].upper()
prepared52=ROOT.parent/'source52-root-integration/PREPARED.json'
graph52=ROOT.parent/'source52-root-integration/FINAL-GRAPH.json'
graph=json.loads(graph52.read_bytes())
assert same(pin(prepared52),graph['prepared_pin'])
plan=json.loads(prepared52.read_bytes())
frozen=json.loads((ROOT/'FROZEN.json').read_bytes())
future=ROOT/'frozen-r1/future51'
metadata=json.loads((future/'PREPARED.json').read_bytes())
for path,value in frozen['files'].items():
    assert same(pin(Path(path)),value)
js_target=ROOT.parent/'app/src/web/workspace/self-operating-read.mjs'
css_target=ROOT.parent/'app/src/web/workspace/upgrade-ui.css'
mirror=ROOT.parent/'cloud/workspace/site/upgrade-ui.css'
public_parent={Path(row['path']):row['pin'] for row in plan['protected']}
assert js_target in public_parent
assert same(public_parent[js_target],metadata['parents']['self-operating-read.mjs'])
assert js_target not in [Path(row['target']) for row in plan['targets']]
css_pin=pin(css_target)
assert same(css_pin,metadata['parents']['upgrade-ui.css'])
assert same(pin(mirror),css_pin)
targets=[{'target':str(js_target),'candidate':str(future/'self-operating-read.mjs'),
          'future_parent':public_parent[js_target],'candidate_pin':pin(future/'self-operating-read.mjs'),
          'coverage':'inherits Source52 protected future Source51 byte'},
         {'target':str(css_target),'candidate':str(future/'upgrade-ui.css'),
          'future_parent':css_pin,'candidate_pin':pin(future/'upgrade-ui.css'),
          'coverage':'explicit newly covered existing public CSS'},
         {'target':str(mirror),'candidate':str(future/'upgrade-ui.css'),
          'future_parent':css_pin,'candidate_pin':pin(future/'upgrade-ui.css'),
          'coverage':'explicit newly covered existing local mirror; no cloud deployment'}]
next_expected=dict(public_parent)
for row in plan['targets']:
    target=Path(row['target'])
    assert target not in next_expected
    next_expected[target]=row['candidate_pin']
for row in targets:
    target=Path(row['target'])
    if target in next_expected:
        assert same(next_expected[target],row['future_parent'])
        del next_expected[target]
proof={'schema':'source53_public_lineage_proposal_v1','status':'PROPOSAL_NOT_INSTALLABLE',
       'join_authorized':False,'base_is_future_Source52_not_current_runtime':True,
       'prepared52':{'path':str(prepared52),'pin':pin(prepared52)},
       'graph52':{'path':str(graph52),'pin':pin(graph52)},
       'frozen53':{'path':str(ROOT/'FROZEN.json'),'pin':pin(ROOT/'FROZEN.json')},
       'targets':targets,'prospective_protected':[{'path':str(p),'pin':v} for p,v in sorted(next_expected.items())],
       'cumulative_receipts':'pending actual installed50/51/52 and their exact historical parent backups',
       'no_existing_authority_changed':True,'source52_installer_guard_pid_calls':0,
       'original_source_writes':0,'gui_platform_model_data_actions':0,
       'pending':['independent proposal review','new successor CAS/launcher with exact cumulative lineage and rollback review','genuine availability evidence','native/UI acceptance']}
(ROOT/'LINEAGE-PROPOSAL.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'status':proof['status'],'physical_targets':len(targets),'prospective_protected':len(next_expected),'original_source_writes':0},ensure_ascii=False))
