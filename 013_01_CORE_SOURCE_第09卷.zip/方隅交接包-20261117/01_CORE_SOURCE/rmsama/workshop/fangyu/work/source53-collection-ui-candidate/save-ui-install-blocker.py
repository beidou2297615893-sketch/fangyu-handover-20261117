from pathlib import Path
import hashlib,json,uuid
root=Path(__file__).resolve().parent;customer=root.parents[1]
block='''# 2026-10-14 最新人类催快与实际安装阻塞：守卫unknown分类修订候选

用户明确催“还要多久，快一点”，并实际答“已正常退出，可以重新评估安装”。Root已将Source53采集页真实接入恢复第一优先，54native仅后台最小收尾，不扩Stage3。退出不是idle推断；原52 fixed8911/6DC新实际尝试ac3d26仍第一absent50/main75拒，发生backup/temp/replace前，0安装，首65e463 HOLD原件保持。

同原guard5948/1E、同native52 thin4/仅Python5一次必要诊断e96b97：transport正常return0/stdout98/stderr0，stateunknown/live_count0/unknown_count3。0knownlive不等原客户所有运行结束；未知不排除、不强停。新回执work/source53-root-integration/INSTALL-NEW-EXIT-HOLD.json及GUARD-DIAGNOSTIC.json保存。

只读count-only更窄分类fe4686：NULL/空/leading/aliases0，粗-c2/-m4/e+eval2，token边界与首option候选0。计数可重叠/瞬态，不与3机械对等，只定位粗substring支路，未证明真实进程filename/argv；无IDS/CmdLine/CWD/Exe输出。首EncodedCommand WinError206运输失败发生查询前保史。原guard与占用门、所有52/53已签字节保持，未再次installer。

当前rea所属agent在work/rea-candidate-audit/guard-token-candidate做最小ownedWindows TDD：仅候选动态参数前缀boundary，保live/relativealiases/runtime/NULL/empty/leading/exclusions及source_state。先验证普通filepath含-c/m旧误匹配与真正动态选项继续unknown，再非作者审；没有授权以候选排除真实unknown或直接开门。Root待具体冻结/代表/审后评估必要signature重绑方案，不做in-memory绕签名/未审改门。

54native r1独审另P2：缺activated-helper业务绑定准入，保持CHANGES_REQUIRED；author仅native/revision2隔离修补，不能阻塞主线或启最终True绑定。Stage1已接受保持。采集UI代码/13本地接入文件已审但尚未装入客户端，真实GUI/用户认可与完整商业R01–R25仍未验。0原App控制/截图/网页替代/DBCookieVault读hashcopy/平台模型发送/打包部署付费；goal未伪造恢复完成。

以下历史保持，以本段和实际原回执为当前事实。

'''
backup=root/'document-backups'/uuid.uuid4().hex;backup.mkdir(parents=True)
records=[]
paths=[customer/'work/product-upgrade-20261009/handoff/CURRENT.md',customer/'memory/STATUS.md',customer/'outputs/产品升级/当前执行事实.md',customer/'work/product-upgrade-20261009/audits/source53-current.md',customer/'work/source53-root-integration/NEXT.md',customer/'memory/sessions/2026-10-14-新聊天接续采集界面修复.md']
for i,path in enumerate(paths):
    raw=path.read_bytes();dest=backup/(str(i)+'-'+path.name);dest.write_bytes(raw)
    path.write_bytes(block.encode('utf-8')+raw)
    records.append({'path':str(path),'backup':str(dest),'before_sha256':hashlib.sha256(raw).hexdigest().upper(),'after_sha256':hashlib.sha256(path.read_bytes()).hexdigest().upper()})
with (root/'UI-INSTALL-BLOCKER-DOCUMENTS.json').open('x',encoding='utf-8') as handle:json.dump({'documents':records,'source_writes':0,'automatic_retry':False},handle,ensure_ascii=False,indent=2);handle.write('\n')
print(json.dumps({'backed_up_documents':len(records),'source_writes':0}))
