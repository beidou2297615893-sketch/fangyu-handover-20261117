# 新短文案挂载顺序失败

工具实际 chunk d33394，exit1，当前与future51两个模拟setup均报：

```
TypeError: Cannot set properties of null (setting 'textContent')
at composeOwnerCollection (evalmachine.<anonymous>:1234:40)
at composeFourOwnerPages (evalmachine.<anonymous>:1261:2)
```

原因：readForm搬入尚未挂载的新readPanel后，按document全局ID找其submit失败。
修正为从已持有原readForm.querySelector取得原submit；未重建控制器或监听器。
本次是候选合成DOM失败。0 App控制/HTTP/真实账号/DB/Cookie/Vault。首次失败保留。
之前的VERIFY是短文案修改前的通过，不能证明失败版本或修正版。修正版需重新运行相关代表。
