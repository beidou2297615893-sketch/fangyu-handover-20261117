from pathlib import Path
import hashlib,json,uuid

root=Path(__file__).resolve().parent
customer=root.parents[1]
proposal=customer/'work/source54-legacy-export-proposal'
review=customer/'work/source53-collection-ui-review/SOURCE54-STAGE1-REVIEW.md'
assert 'PASS' in review.read_text(encoding='utf-8'), 'Read actual final review before running'
pins=[]
for path in [review,proposal/'FROZEN.json',proposal/'REPORT.md',proposal/'REPRESENTATIVE.json',
             customer/'work/source53-collection-ui-review/LINEAGE-PLAN-REVIEW.md',
             customer/'work/rea-candidate-audit/SOURCE54-DEPENDENCY-NOTE.md']:
    raw=path.read_bytes();pins.append({'path':str(path),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest().upper()})
assert pins[1]['sha256']=='94576779A873FBFC7133429B1CC89A8B7B3826085DD109042032CA648E8B9E17'
own=customer/'work/source54-root-integration'
own.mkdir(exist_ok=True)
with (own/'ROOT-STAGE1-ACCEPTED.json').open('x',encoding='utf-8') as handle:
    json.dump({'schema':'source54_root_stage1_limited_acceptance_v1',
       'root_chat':'01a13a0e-b66c-72a3-a82a-8ad950462a6b',
       'status':'ACCEPTED_STAGE1_CODE_AND_OWNED_ONLY',
       'review_read_in_full':True,'evidence':pins,
       'business_existing_targets':1,'inherited_protected':473,'new_dependencies':8,'protected_total':481,
       'owned_representative_groups':7,'old50_through53_guard_PID_preflight_exec_recorded':True,
       'false_unbound':True,'native_candidate_prepared':False,'published':False,
       'approved_install_now':False,'source_installed':False,'native_installed':False,
       'original_SOURCE_or_App_or_private_data_or_guard_actions':0,
       'source52_first_hold_preserved':True,'source53_UI_and_publication_unchanged':True,
       'GUI_business_DB_throughput_cross_process_verified':False},handle,ensure_ascii=False,indent=2)
    handle.write('\n')
block='''# 2026-10-14 当前：旧导出Source54 Stage1已有限独审接受，未签发/安装

Source54冻结94576779、CAS900FAEE1、helperEADD535D、PREPARED5A199636。Root全文读作者REPORT/7组REP及非作者最终Stage1报告，有限接受新接入代码/自有证据。唯一business目标9329EE39→已接受r2的8E364FA7；473继承保护+8显式新增public依赖纳保护，总481。business不在旧50–53清单，只有54自己原父backup，初472假设纠正保史。旧Source53采集UI三final已列入保护，13项实际本地签发保持。

7组owned代表含新helper checked CAS/manifest→实际owned byte锁/child probe→53success核→54单文件事务/481读回→recorded原flags exec；缺53success在preflight/guard/STARTED前拒，旧future53CSS/新dependency漂移及ownbackup坏拒保持。旧50–53已装层、guard/PID/preflight/exec是recorded；不能称真实生产联跑。single-success夹具后被ownbackup坏测试故意破坏，保为负例；cleanhelper独立证据另存。没有重20业务或旧53QA。

Stage1仍false/unbound，没有新54 authority本地签发/native准备或安装。Root接受work/source54-root-integration/ROOT-STAGE1-ACCEPTED.json，后继NEXT.md。下一独立事项是必要native/正式绑定候选与其最小审；尚未实施。无新genuine availability不跑原52/53/54installer/guard/PID/preflight/check-only，不借新入口重试52HOLD。正式SOURCE、原51桌面入口、原App及真实数据保持。

采集页改版仍尚未装入原客户端；GUI/原图1:1与用户软件认可、本人获客、真实模型费用精度吞吐、自然同意/第二实体机/SDK KMS云/支付成交以及完整R01–R25商业验收仍未完成。技术候选成功不等内容验收或用户认可。0原App控制/ComputerUse/截图绕行/网页替代、0DBCookieVault读hashcopy、0平台模型发送/打包部署付费；历史goal未伪造恢复或complete。

以下历史保留，以上段及实际回执为当前事实。

'''
backup=root/'document-backups'/uuid.uuid4().hex;backup.mkdir(parents=True)
paths=[customer/'work/product-upgrade-20261009/handoff/CURRENT.md',customer/'memory/STATUS.md',
       customer/'outputs/产品升级/当前执行事实.md',customer/'outputs/产品升级/需求交付与证据台账.md',
       customer/'work/product-upgrade-20261009/audits/source54-current.md',
       customer/'outputs/REA接收/旧导出修复与接入状态.md',
       customer/'memory/sessions/2026-10-14-新聊天接续采集界面修复.md']
receipts=[]
for i,path in enumerate(paths):
    raw=path.read_bytes();dest=backup/(str(i)+'-'+path.name);dest.write_bytes(raw)
    path.write_bytes(block.encode('utf-8')+raw)
    receipts.append({'path':str(path),'backup':str(dest),'before_sha256':hashlib.sha256(raw).hexdigest().upper(),'after_sha256':hashlib.sha256(path.read_bytes()).hexdigest().upper()})
with (own/'NEXT.md').open('x',encoding='utf-8') as handle:handle.write(block)
with (root/'STAGE54-ACCEPTANCE-DOCUMENTS.json').open('x',encoding='utf-8') as handle:
    json.dump({'documents':receipts,'root_acceptance':str(own/'ROOT-STAGE1-ACCEPTED.json'),'source_writes':0,'original_App_guard_private_actions':0},handle,ensure_ascii=False,indent=2);handle.write('\n')
print(json.dumps({'accepted':str(own/'ROOT-STAGE1-ACCEPTED.json'),'backed_up_documents':len(receipts),'source_writes':0},ensure_ascii=False))
