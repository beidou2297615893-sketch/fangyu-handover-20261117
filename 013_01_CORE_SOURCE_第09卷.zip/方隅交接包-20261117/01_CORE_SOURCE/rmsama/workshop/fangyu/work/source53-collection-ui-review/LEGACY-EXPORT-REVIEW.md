# 旧导出来源权限候选独审

结论：CHANGES_REQUIRED，发现1个确定静态 P2 范围遗漏。旧链候选未合入/安装；不能当当前owner采集UI回归或混入Source53。

实际f5f526读回FROZEN4341/E0A7A105与22冻结文件pin一致；parent72676/9329EE39、candidate73299/9D0E6CC4。整模块AST比较仅BusinessExecutor._export_page变化，其他AST完全相同，正式business/Core公有父pin实读保持。已读取tdd与tests/mocking要点、实际__call__→_execute公开seam、FIRST-RED及11GREEN，未重跑11测试或旧QA。

## P2：选中分类导出漏核其他来源贡献的缓存元数据

位置：candidate business.py168–200；未改_execute约805–821；source-materials/assistant/lead_groups.py58–95。_execute先在全部visible items计算view.analysis_*，group_rows又先对全部items生成groups(label/count)，最后才按选中group_key缩items；_export_page仅把缩后rows存为entry.items，却保整个view。新循环只重新读取entry.items的id，返回仍展开entry.view。

因此先导出选中组A，另一组B原来源随后转给其他员工/跨tenant/缺失，B不在entry.items，不触发失权拒绝，续页/末确认仍可能返回B的缓存帖子标题/博主名/计数及全量analysis计数。这是从实际代码可确定的范围盲区，11已有测试均未覆盖selected group分支；本审没有执行这个新反例。

最小后继：在group_rows筛选之前保存所有贡献items与view的原source ids为独立冻结validation scope；begin/每续页/最终确认全scope当前_lead_access，任何失权/未知废原token，不重筛选、缩计数、换号或冒成功。追加一条实际__call__ grouped-selected owned RED：改变/删除非选中组B，原token拒绝，恢复B归属后原token仍不可复活。需r2重新冻结和最小审。

其他核查：Core为RLock，_export_lock是仅快照方法取得的Lock，新增次序Core→export，未见本模块反向锁链。每次task_cache新建，source.cloud_owner/tenant/缺失通过实际_get与_lead_access当前检查；task失权/缺失及account归属由原_task_access核，未用缓存权限替代。新scan中普通未知_get/_lead_access异常会del原token并controlled ValueError(from None)，不释放行/计数。原username/TTL/坏token/权益门和被冻结排序/数量/分页AST保持，author已有限GREEN。

开销限制：每次请求都在Core锁内核全N行，10000行/25一页完整400页约400万次lead get，再加末确认，task_cache只减少重复task读取。没有生产DB/10000行吞吐或耗时证据；本Core锁也不是跨进程DB隔离。当前性能不承诺，不能由memory11GREEN推实宿主完成。

边界：只读旧链公有源码/快照证据，0原App/privateDB/Cookie/Vault/API/guard/installer或平台模型动作；正式parent/Core、Source53冻结/authority未写。仅写本独审两报告。
