# 正常打开薄修复 native 最终候选独审

PASS_LIMITED_NATIVE_REPAIR_R2_DRAFT；无确定 P1/P2。只支持Root对精确候选另行条件签发决策；当前 INSTALL_AUTHORIZED=False/GATE_PIN=None，未发布/安装，不运行wrapper/App。payload独审另见SOURCE52-EMPTY-PROTECTION-PAYLOAD-REVIEW.md，原提示未更新误读已撤销。

d60230全文新main/dependencies/fresh/rollback/图/gate；252c25核r1冻结11项、r2冻结7项、r1原freeze保持。最终FROZEN2580/ABAB7EFD，code13525/0119E1DC，GRAPH5103/09CFAB6E，Falsegate990/AA7DFECE。r2仅LAUNCHER_PIN、PAYLOAD_EVIDENCE、GRAPH_PIN三常量变化，全部10functions字节与r1相同；blob/pin/expected/no_link_parent/prepared_temp/proof/absent七函数同成熟native53父。

严格两个existing targets：H52原15623/1C919E94→16027/B4F6BE49；53launcher原5405/994ED84B→5910/EC31A4C0。graph/code/gate共同绑定payload r2 PLAN3050/5C04168A、FROZEN3416/9F04435C及两个全新empty-protection-r3路径；每次fresh/rollback再核evidence exact，独审flag不能代替字节证据。原50/51/H53/ENTRY四immutable保持；无reverse graph绑定，Root后继只需signed两assignment INSTALL_AUTHORIZED/GATE_PIN并保全部function bytes。

原native52 raw1874/613E43C5、原native53 raw2175/644B8086、实际52备份AA029206与53备份E813固定pin依赖；本次新backup同时保存旧H52 1C与旧53launcher994，独立normal-opening-repair-native receipt/FAILED/backupbase不替代或倒填旧raw。原native历史描述旧parents，新repair描述新overlay，不能把旧收据改成新pins。

默认False/None在任何文件查询/guard/PID前拒。任何原50–53 business STARTED/FAILED/success 12项presence、原native失败、本repair收据/失败都拒，无auto reapply。backup/temp前、逐replace与seal前fresh核旧依赖/guard/evidence、target current parent或已completedfinal、own原backup、candidate字节，然后薄guard必须idle。rollback只在fixed依赖/guard仍允许、target仍本次after、actualparentbackup匹配才恢复；live/unknown、foreigntarget/原raw漂移保留并记FAILED。新增failure只记录新repair，原parents/raw/失败不清不换号。

载体真实边界是main，不是镜像事务adapter。r1两条RED（复制旧schema不适用、缺payload evidence误准入）原文保留，9 owned tests已capture019b39；r2仅一条同main两file txn GREEN185d28，未重9。只读测试源确认实际事务/文件/回滚代码，guard状态/OS故障合成，parentraw/lineage是fixed合成owned字节。TemporaryDirectory用例已清理，本审不冒有当前receiptartifact供独立冷读，也不重事务。不得以此称原guard/真实native安装或业务50–53通过。

Root唯一writer，无全局installer OSmutex；断电崩溃恢复、外部并发改写不由owned样例证明。0本审原guard/query/PID/preflight/check-only/App/private/业务收据/生产callable，0源码写/旧QA/54Stage3。Root若接受并发布五新controls，必要后继只读精确5字节+两signedassignment、旧controls/原native依赖、当前两parent与immutable；随后实际薄替换及新receipt/ownbackup/currentoverlay读回另留证，不把安装读回冒用户打开/GUI完成。
