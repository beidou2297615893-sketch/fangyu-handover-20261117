# Source54 native r3 正常打开修复 overlay 前驱方案独审

确认阶段性前驱不兼容：001e99只读旧54 native r2代码，IMMUTABLE仍要求currentH52 1C919E；require_predecessors原native53raw launcher row也直接比PARENT_PIN994ED84。实际normalrepair已合法将current改为B4F6/EC31（已独立实际读回，不在本次重验）。r2尚False/None，这不是已运行54故障；r3必须扩展真实历史overlay证明。

1. Split historic native53 launcher final994 from active native54 launcher parentEC31; original raw row pins never rewritten.
2. Keep original native52/53 raw pins613E/644B and AA/E813 physical launcher backups. Prove old H52 native1C and old native53final994 through normalrepair actualtwo parent backups.
3. Strict normalrepair originalraw4844/B461 pin, exact two record map/parent1C+994/finalB4+EC31/actual cdb7 backup paths and parent hashes, graph09CF/gate0A8F/payload evidence/immutable historic fields/zero installer side effects/failure refusal.
4. Current repaired H52B4 and repaired active launcherEC31 exact before54; after54replace use actual54 own backupEC31 plus current54final; H52 B4 must stay fixed.
5. Fresh normalrepair raw, original raw parents, both normalrepair backups, oldlineage, fixed public refs beforebackup/replace/seal; altered or missing proof holds, never autoapply/recover/replace receipt.
6. Do not call normalrepair installer/business_absent or require old50-53 businessabsence: actualsource53 success remains required. Do not require historical originalENTRY15900/C2 current after legitimate50/51 businessoverlays; use existing originalbusiness raw/parentbackups/current _layers closure.
7. New launcher inherits actual reviewed repairedEC31 base: fixed generic_failure_message, H52B4, legacy50/51/53/ENTRY andflags/held/check-only; onlyadd54helper binding/coordinator.
8. KeepStage1 CAS/helper/business1target481protection and all existingfrozen artifacts unchanged; native defaultsFalse/None metadata-beforeIO refusal, new independentr3 scopedpaths, noStage3.

尤其不能把原native53 raw row pin994直接改成新active parentEC31；正常repair自身是追加历史overlay，旧收据仍描述旧安装。原H52 1C保存在normalrepair actualbackup，currentB4单独核。54自身替换以后再追加其actualEC31parentbackup证明，而不是从原53backup E813推EC31。

另一必要时间边界：normalrepair安装时要求业务证据12项缺席；54安装需要实际source53业务成功，两者不矛盾但不能复用修复installer的当前business_absent。normalrepair历史immutableENTRY C2只属于修复时快照，50/51业务后ENTRY可合法变更；应由成熟source53业务raw/actualparentbackups/current protection验证，避免新门再次堵正常bootstrap。

本方案已主动发Root/author。仅静态publiccode读及既有自己报告参考，0原metadata函数/business receipts/guard/query/PID/preflight/check-only/App/DB、0旧QA/normalrepair重复验证。方案不是新候选批准，待author精确r3freeze后只核新增证明、launcher继承及有限owned接缝；无54签发/发布/Stage3。
