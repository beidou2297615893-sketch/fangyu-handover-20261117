# 52/53 guard-token-r2 最终增量独审

结论：PASS_LIMITED_FROZEN_BINDING_AND_OWNED_SEAMS；无确定 P1/P2。此结论支持 Root 对精确 18 件另行作本地条件接受/发布决策，不等于安装、runtime ready、实际空闲或 GUI 验收。原 guard/control/authority 不得由本报告自动覆盖。

实际冻结核：FROZEN 8443/2813AE566255EA6105426EA634C170B0FF291A6F22E2C13075F8EC317FD0676F；PLAN 33220/56BCA7F5BFCD4F72B5EA0E2AE11C3338D6070205FE377E61BB5EAA904A0ED3F4；REPORT 3733/E3C12CFFB5877922D691E1D5CFB3808D32F3166D7DAC8A607FE51E78285B9BBD。6aab1b 核全部 29 冻结项、18 parents，18 control 与预冻 snapshot pins 相同；未重 57 函数/旧 QA。

此前 dce805、ce5171、10a642、2e65b6 实核：除唯一 guard _queries dynamic names.extend 与两个 native main 外，55/57 原函数字节全同，非 assignment 其余顶层 AST 保持。52 native main 同时新增原本批 business STARTED/FAILED/RECEIPT presence 早拒，并将 expected(AUDITS/name,graph[key]) 改 OWN/name；53 native main 仅新增本批 presence 早拒。两者都在 control metadata、guard、backup/temp 前拒。其它常量变化限新路径、pins、53 ancestor52/prepared 绑定和 native IMMUTABLE 新52 pin。

52 PREPARED 原字节 BF80 保持：9 targets/462 protected/17 dependencies。53 PREPARED 仅 ancestors52/base_manifest 改，3 UI targets/470 protected/原 evidence 保持。50/51 authority/helper pins、原业务/原 native state paths 和 source52-owner/source53-owner/native backups 地址保持。新 53 ancestor52、native52 helper pin/future launcher parent 与固定 stage1 files/package 匹配；旧 success 的新签名不匹配会拒，PUBLISHED/Root 接受不能充当 apply。原 PEER/PEER_PIN 精确保留，仅代表成熟旧语义，新 guard/new binding 由本次增量与 Root 外部接受，不能冒原 PEER 已审新绑定。外部接受不写回 immutable candidate，也不增加报告↔code hash 环。

9ac8f3/a796af 只读新增载体确认代表边界：实际 owned checked 新53 helper._cas/before_normal_open→实际新52 helper plan/start/readback→checked CAS9 files→新53 CAS3 files，实际同一 existing byte0/length1 OS锁和 CAS child probe，最终 exec 录制。旧50/51步骤/旧51调用、合成历史源码、entry/preflight/PID、guard状态均录制；guard fixture/pins 也重绑为 owned，不能当 EC86 的真实 source_state transport。EC86 固定绑定已静态核，动态边界沿用此前隔离 guard 审，不重 Windows7/query。

6aab1b 独立被动读回 owned 原 raw52 220743/2B49C2A79FC084DB68FF2A949203DD8321EBFA40A64C2405A6C0BF91FCCC406F、raw53 218917/5E548E828902184E6565EDC3D26395C5237ECB7ECD3AEC7609C1140F239EA87F，与 REPRESENTATIVE pins 相同；12 parent backups、当前12 finals、raw53.base_receipt_pin=raw52 pin、新 owned authority pins 精确。错 authority 收据负例后已恢复原 raw53，因此不把负例改坏状态冒正常成功。

NATIVE-SEAMS 是新增拒绝代表：两个实际 rebased main 各三种 presence 共6例，control metadata/guard/backup均0；实际 checked native53 graph/helper/CAS 准入达到旧 native52 两file pin 不匹配而拒。没有本次 native 正常安装事务新 PASS。ACTUAL-RED 是载体 inert AST 切分范围错误；NATIVE-RED-1 保存 owned carrier assertion失败，随后 checked bytes compile载体通过；不据此称原 App/安装器故障。

限制：本次0生产 import/call、0原 state/receipt/PID/private读取、0真实 guard/query/installer/App/source写，0旧 QA/UI/业务20/事务重跑。native无全局 installer OS互斥，Root唯一writer前提保持。真实 availability、native52→native53、正常打开50–53累积 raw/backup/current 与采集页人工验收仍须分别实际证明。staged True 是待 Root 条件接受方案值，不是实际运行授权。

发布后最小读回 schema 已附 GUARD-REVISION-PUBLICATION-READBACK-SCHEMA.json：精确18新targets与 FROZEN/PLAN、Root实际 acceptance/publication18清单、旧public输入/50–51固定helpers与desktop launcher未写；不得读原私态或把本地发布写成 installed/ready。后续真实安装结果另留证。
