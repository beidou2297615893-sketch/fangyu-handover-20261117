# Owner 关键词保存契约 r2 窄审

结论：PASS_LIMITED_NEW_POSTCOMMIT_SEAM；未发现 P1/P2。FROZEN 4535/31FE11AF36C21D4DB4D903B755E28053BFDB0C37ECBE47CAE23B058E80A8D644；13 个新冻结项及原 r1 18 项实际 pins 精确。Integrations 保持 r1 bytes；反换新增 keyword_state span，module 全文恢复 r1，仅该 wrapper 分支改变。

旧 LocalAIWorkflow.keyword_state 正常返回（原 SQLite transaction 已结束）后才进入末 _current 的 try。save 遇 CoreError 转固定 OwnerKeywordError，mutation_committed=True、类级 auto_retry=False、from None，不返回保存内容/原拒绝细节；read 原异常保留。旧 save 本身在 try 外，异常对象直接传播，不猜提交、不二次保存。实际 AST 消息为「关键词保存已提交；请由本人重新核对，不可自动重复保存。」。本审一条手写预期文案比较写成另一中性句导致 assertion，已用 actual AST 提取与整段反换核正；不是候选 RED 或源码问题。

已读 captured 新 RED/GREEN 的实际载体：未改 own copy LocalAIWorkflow 对 owned SQLite CAS 保存 revision=1，然后 recorded actor gate 拒绝。r1 缺提交字段；r2 true/noRetry、无保存内容或私有异常串，并保留旧 save 直接抛错的同一对象。独立冷读两 owned SQLite exact pins，均有一条 regional_state revision=1；持久内容对应捕获结果。调用次数、异常字段和无远端调用来自冻结当时断言，不冒 current App 结果。没有重跑 r1 四故事或新 seam。

这修补是未接线接口的提交契约补齐，不倒称 r1 先前静态限制为正式生产 P2。未来 product_action/UI 必须传递 true/noRetry 和中性提示；真实保存窗口/失权时序及储存自身未知仍未验，不从本改动扩展为所有异常都已提交。workspace/UI/CSV 未改变、未接线、未签发发布安装。0 原 callable/private/DB/API/network/model/guard/PID/installer/App/旧 QA；只写本独审报告。
