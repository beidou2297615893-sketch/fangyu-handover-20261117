# Owner 本地 CSV 新候选源契约预核

仅父契约预核，未批准动态候选。99d630/e24b15实际6个公共父pins精确：workspace51 54052/9E9CFEFD、UI53future51 409955/C8C52A07；intent/platform archive/Core/AIworkflow依赖见PARENTS。只读固定公代码，没有Root App/DB/API/平台/业务收据或guard动作。

作者约定3 product_action：owner_source_export_begin {request_id,source_ids,filter}；page {request_id,snapshot,offset,limit}；confirm {request_id,snapshot}。filter只all/pending/priority/review/other，selected最多本页50个，UI safeDTO.id是localleadID；server从tenant+lead.source_uid求canonicalSOURCE并保accountUID/device/actor/hash/readonly/Dy等实际safeproof。返回保持原product_action result外壳，最终fresh通过后才给CSV。

87be27定位原_source_page明确bounded seek，既非token又非MVCC；遇无效SOURCE/lead/account/proof会continue并缩rows。导出不能借drop语义代替权限复核：任一冻结selected contributor失权/未知/缺失应废整份token并保request tombstone；冻结scope/principal/account/filter/order/count，page(None)只能既有原requestlookup，不自动newbegin/换号/缩scope；最终全scope fresh。privateAI权限依赖的safeprojection/analysisproof降级也应拒旧缓存CSV，不能仅比leadid仍owned。

关键outer_actor接缝：父dispatch在action解析前_actor，Owner禁用/role/session/instance拒绝可能绕过exporthandler导致未废token。必须覆盖public dispatch begin→outer_actor拒page/confirm→恢复→原token仍拒。作者已回复新3目的专用prefix置于outer_actor前、actor/instance实际验证由export.__call__承担catch废token；其他旧route/statements原顺序保留。这是方案承诺，尚未读未冻code验证，不列实现缺陷。

待freeze仅核最难multi-source非当前页失权/不复活、None原号resume、finalfresh、snapshot规则/CSV公式防护、原Owner门和UI listeners，以及captured/currentfixture/真实GUI界限。不得用旧legacy leads_list或旧导出token代替新Owner链；不重旧业务/transactions/guard/54Stage3。
