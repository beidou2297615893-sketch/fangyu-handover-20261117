# 52 零字节保护 pin 入口薄修复最小独审方案

已确认代码缺口：52 helper `_proof` 要求 bytes>0，但 `_plan` 用它验证 protected。实际固定 manifest/prepared 的462列表完整相同，其中8项 pin 为合法 bytes=0/空文件SHA256 E3B0C442...；因此它们必触发 Source52 exact protection graph changed。50/51 使用非负大小。此是保护pin语义错误，不是漂移证据；Root已有隔离诊断，不应触发新 apply/重试来定位。仅静态读取，未调用原metadata/preflight/check-only。

建议最小两target修复：52 helper `_proof` 接受 bytes>=0，保 type int（拒bool）、拒负数、严格字典/hash格式与后续真实字节 expected；或专用protected pin验证器保持其它positive约束。现有固定 authority/gate/目标集合/pins仍严格核验，真实空文件也必须匹配E3B0...，不删除8项保护。53 launcher只更新 LATEST_PIN 至新52 helper，增加固定用户可见启动失败提示；不展示原异常/私态，不改变 held/live/unknown/失败return、不fallback/重apply，不在check-only分支增加GUI副作用。失败提示自身失败亦保拒。

旧52/53已发布control/CAS/authority/PREPARED、native原raw收据/backup/parents全部保留。新薄修订不能改原native52/53收据helper/launcher pins；新独立receipt/backup记录两existing targets的原parent H52=15623/1C919E94及53launcher=5405/994ED84B、final新pins与实际原backup。旧native记录的parent字节通过本次actualbackup证明，新current通过新receipt证明，不能假称旧收据直接描述新字节。50/51/H53/ENTRY及业务sources保持签名。若任何历史薄修订STARTED/FAILED/receipt已存在，默认hold、不清号/不自动重跑。

Root唯一正式writer。正式薄替换须单独Root接受精确候选/安装图、核原parents与native原raw证据、必要freshguard；backup/temp/replace/seal/rollback保live/unknown拒与foreignbytes保留。本审不运行任何原guard/PID/installer/App或读业务私态，不能用移交或先前缺席快照替当前空闲。

最小代表：真实零pin静态predicate RED→GREEN，负数/bool/坏pin/真实digest不符仍拒；必要隔离public-only metadata拒私态/写/process能力验证前置图通过，不调用原metadata；ownedlauncher固定failure提示调用与check-only无提示；owned真实2file事务/原parentbackup/readback与guardunknown/foreignbytes hold。原业务/UI/20QA及54Stage3不重测。

此为修复方案，未批准未冻结新候选；待author精确freeze后只核新增seams。实际可打开/业务50–53/采集UI仍需后继真实证明。
