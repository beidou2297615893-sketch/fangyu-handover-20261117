# 52/53 守卫签名修订最小复审清单

结论：保留原单号状态与备份地址、仅另建固定控制/签名路径的方案可以闭合。此为冻结前清单，不是候选 PASS、采用授权或安装成功。

只读现有公有 native/CAS/helper 与 PREPARED/GRAPH；未读取真实 STARTED/FAILED/RECEIPT、PID 或私态，未 import 生产模块、调用守卫/安装器/App。工具 8635f4、e0ef1d、4967cd；作者与 Root 已收到清单。

1. 共享原业务 52/53 STARTED/FAILED/RECEIPT、native installed/failed 和 backupbase。FAILED 一律拒；STARTED 缺精确同新 revision 成功收据拒。不得新路径另起单号门、删改原证据、复制旧 success。
2. 新 native52/53 在第一 backup/temp 前显式核原业务 pending/failed。已有 success 要验证新 authority/graph/raw 与实际备份；与新签名不符即拒，不能迁移旧收据或以 PUBLISHED/Root 接受替代 apply。fresh replace/seal/rollback 的 live/unknown 拒绝保持。
3. 实际旧 PREPARED 计数为 52：9 targets、462 protected、17 candidate_dependencies；53：3 UI targets、470 protected。path/parent/final 与业务依赖集合逐项相等；53 新 base_manifest/ancestors52 元数据须指新 52。
4. 50/51 原 authority/helper pins/物理字节、现有 byte lock、same-PID STARTED、PID dead/unknown、raw 收据和各批次实际 parent backups 保持。新 53 native parent 是新 52 launcher/helper，不能一跳旧 51。
5. 全部消费者固定新 guard pin。唯一动态识别语义是已审 names.extend；其余 query/source_state 不变。新增共享状态前置拒绝与 paths/pins literals 列出精确 delta，不冒称仅常量变化。
6. CAS/manifest/helper/native graph 严格无 hash 环；checked caller 注入固定 manifest。native 准入核 helper JOIN_AUTHORIZED/MANIFEST_PIN/CAS_PIN、CAS/业务 gate 一致激活。未批准 false/None 在 metadata/guard 前拒。
7. 最小新增 owned 代表：旧共享 pending/FAILED 在新路径仍 0 backup/0 apply；旧成功错误新绑定拒；checked 新 53 helper→新 52→53 实际事务/锁/raw/backup/readback，旧 50/51、guard/PID/exec 录制。区分真正 coordinator 链与 directCAS，不重旧 Windows7/UI/QA。

旧 native52 `main:55`、native53 `main:95` 仅直接查各自 installed/failed；本次显式加入共享业务 pending/FAILED 是必要控制补足。旧 52 `_start_once:178`、53 `start_once:262` 已拒原单号状态；旧 52 `_readback:141–162`、53 `_layers:204–234` 使用原 raw/备份闭合，新签名不能削弱这些条件。

旧 CAS52 PROJECT 最终 AST literal 核为正确客户路径；早期长 stdout 乱码已撤销为显示问题，不列源码缺陷。不得因此额外修改 PROJECT。

等待作者精确冻结后只审新增绑定、共享门和必要 owned 证据；不另起收据链，不触发真实查询/安装/正常打开。
