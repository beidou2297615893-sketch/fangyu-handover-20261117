import hashlib,json
from pathlib import Path
OWN=Path(__file__).absolute().parent
PROJECT=Path('C:/积木软件工坊/项目/方隅公寓客户版')
WORK=PROJECT/'work'
def pin(raw):return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest().upper()}
frozen_path=WORK/'source51-store-scope/FROZEN.json';frozen_raw=frozen_path.read_bytes();base=json.loads(frozen_raw)
assert pin(frozen_raw)=={'bytes':14804,'sha256':'D6287074B1ACD2FB9A0AB84D043289EAD5A740435F6A26871F5E6D5E9BB9D646'}
service=next(row for row in base['targets'] if Path(row['target']).name=='service.cjs')
assert pin(Path(service['candidate']).read_bytes())==service['candidate_pin']
relatives=('app/src/web/workspace/member-admin-ui.mjs','owner-admin-20261004/site/member-admin-ui.mjs',
 'app/src/web/workspace/app.mjs','app/src/web/workspace/index.html','owner-admin-20261004/owner_admin.py','owner-admin-20261004/site/index.html')
targets=[{'target':service['target'],'parent_source':service['candidate'],'parent':service['candidate_pin'],
 'parent_kind':'immutable_Source51_frozen_successor_not_actual_apply'}]
for relative in relatives:
 path=WORK/relative;targets.append({'target':str(path),'parent_source':str(path),'parent':pin(path.read_bytes()),'parent_kind':'current_public_formal_readonly'})
assert targets[1]['parent']==targets[2]['parent']
inputs={'schema':'source52_store_member_manager_proposal_inputs_v1','code_implementation_started':False,'formal_mutations':0,
 'source51_frozen':{'path':str(frozen_path),'pin':pin(frozen_raw)},'proposed_target_count':7,'targets':targets,
 'Source51_other_three_unchanged_dependencies':[{'target':row['target'],'candidate':row['candidate'],'pin':row['candidate_pin']} for row in base['targets'] if row is not service]}
path=OWN/'PARENTS.json'
with path.open('x',encoding='utf-8') as stream:stream.write(json.dumps(inputs,ensure_ascii=False,indent=2)+'\n')
files=[OWN/'PROPOSAL.md',path,OWN/'trace-manager-gap.cjs',Path(__file__)] + list(OWN.glob('MANAGER-GAP-*.json'))
proposal={'schema':'source52_manager_gap_proposal_frozen_v1','status':'PROPOSAL_ONLY','Root_business_scope_acceptance_required':True,
 'no_formal_mutations':True,'real_cloud_or_App_calls':0,'evidence':[{'path':str(p),'pin':pin(p.read_bytes())} for p in files]}
out=OWN/'FROZEN-PROPOSAL.json'
with out.open('x',encoding='utf-8') as stream:stream.write(json.dumps(proposal,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'proposal_pin':pin((OWN/'PROPOSAL.md').read_bytes()),'parents_pin':pin(path.read_bytes()),'frozen_pin':pin(out.read_bytes()),'targets':7}))
