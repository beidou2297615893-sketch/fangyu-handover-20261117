"""Freeze owned state evidence/readback only. No state or Root code execution."""
import ast,hashlib,json
from pathlib import Path
OWN=Path(__file__).resolve().parent;SNAP=OWN/'snapshot'
def pin(raw):return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest().upper()}
def entry(path):return {'path':str(path),'pin':pin(path.read_bytes())}
def create(path,value):
    with path.open('x',encoding='utf-8') as stream:stream.write(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
run_ids=('0e15cfcdecb746a9b850e6e2c1e32cb6','8ef47d89355f4c13b494ceb0f7b04550','0044e8fa0eba4bcba0e025a107796c76','62e03218bcd649cc875f749ef21515e5','f6cdc1632486423e9f5bc9ab4dac5315')
evidence=[];roots=set()
for run in run_ids:
    root=OWN/'runs'/run;result=json.loads((root/'RESULT.json').read_bytes());assert result['status']=='PASS'
    assert result['carrier_pin']==pin((root/'carrier-snapshot.py').read_bytes())
    item=entry(root/'RESULT.json');item['carrier_snapshot']=entry(root/'carrier-snapshot.py');item['cases']=[]
    for row in result['cases']+result.get('inherited_initial_live_unknown_only',[]):
        case=Path(row['path']);assert pin(case.read_bytes())==row['pin'];roots.add(case.parent)
        value=json.loads(case.read_bytes());assert value['formal_App_data_cookie_CIM_platform_model_calls']==0
        item['cases'].append(entry(case))
    item['post_run_tamper_notes']=[entry(path) for path in sorted(root.glob('*/TAMPER-*.json'))]
    if (root/'AST-PROOFS.json').exists():item['runtime_AST_constant_binding_proofs']=entry(root/'AST-PROOFS.json')
    evidence.append(item)
first=OWN/'runs/cd08bf0279d344af9f6a24f9a9d63841/FIRST-FAIL.json'
assert json.loads(first.read_bytes())['status']=='FAIL'
failure={'first':entry(first),'carrier_snapshot':entry(first.parent/'carrier-snapshot.py')}
roots.add(first.parent/'guard-transition-before_backups_and_temps')
bindings={
 'source_idle_guard.py':({'PROJECT'},'work/source52-root-integration/source_idle_guard.py'),
 'join-source52-reviewed.py':({'PROJECT','BASE_MANIFEST_PIN','PRIOR_MANIFEST_PIN','JOIN_AUTHORIZED','SOURCE_GUARD_PIN'},'work/product-upgrade-20261009/audits/join-source52-reviewed.py'),
 'next_open_source.py':({'PROJECT','ROOT_MANIFEST_PIN','TARGET_PATHS'},'work/desktop-self-use-entry/next_open_source.py'),
 'next_open_source51.py':({'PROJECT','BASE_MANIFEST_PIN','MANIFEST_PIN'},'work/desktop-self-use-entry/next_open_source51.py'),
 'next_open_source52.py':({'PROJECT','BASE_MANIFEST_PIN','MANIFEST_PIN','JOIN_AUTHORIZED','GUARD_PIN'},'work/desktop-self-use-entry/next_open_source52.py'),
 'source_next_open_launcher.py':({'PROJECT','HELPER_PIN','SUCCESSOR_PIN','LATEST_PIN','ENTRY_PARENT_PIN'},'work/desktop-self-use-entry/source_next_open_launcher.py')}
def masked(raw,names):
    tree=ast.parse(raw)
    for node in tree.body:
        if isinstance(node,ast.Assign) and isinstance(node.targets[0],ast.Name) and node.targets[0].id in names:node.value=ast.Constant(None)
    return ast.dump(tree,include_attributes=False)
proofs=[]
for root in sorted(roots):
    for name,(names,relative) in bindings.items():
        source=SNAP/name;copy=root/relative;assert masked(source.read_bytes(),names)==masked(copy.read_bytes(),names)
        proofs.append({'fixture':str(root),'snapshot':entry(source),'bound_source':entry(copy),'only_constant_bindings':sorted(names),'control_AST_unchanged':True})
    helper=root/'work/product-upgrade-20261009/audits/join-source44-reviewed.py'
    assert helper.read_bytes()==(SNAP/'join-source44-reviewed.py').read_bytes()
create(OWN/'READBACK-AST.json',{'post_run_read_only_not_new_runtime_QA':True,'fixture_roots':len(roots),'proofs':proofs,'Source44_exact_raw':True})
create(OWN/'FROZEN.json',{'schema':'source52_native_owned_actual_evidence_frozen_v1','author_evidence_only':True,
 'Root_CAS_snapshot':entry(SNAP/'join-source52-reviewed.py'),'Root_helper_snapshot':entry(SNAP/'next_open_source52.py'),
 'guard_snapshot_A8_recorded_transport_only_not_WMI_PASS':entry(SNAP/'source_idle_guard.py'),
 'snapshot_inputs':entry(OWN/'SNAPSHOT.json'),'evidence':evidence,'first_failure_preserved':failure,
 'report':entry(OWN/'REPORT.md'),'post_run_control_readback':entry(OWN/'READBACK-AST.json'),
 'current_carrier':entry(OWN/'native-story.py'),'freezer':entry(OWN/'freeze-results.py'),
 'four_groups_plus_only_missing_local_parent_delta':True,'business_and_old_passed_states_not_replayed':True,
 'boundaries':{'actual52_file_CAS_OS_lock_replace_backup_rollback':True,'old50_51_apply':'recorded',
 'entry_preflight_pid_and_exec':'recorded','consumer_PowerShell_CIM_transport':'recorded',
 'real_customer_App_CIM_DB_cookie_platform_model_SDK':0,'Root_or_formal_mutations':0,
 'Root_new_WQL_guard_and_pin_literal_delta_needs_separate_binding':True,
 'commercial_complete':False,'independent_final_approval':False}})
print(json.dumps({'frozen':entry(OWN/'FROZEN.json'),'report':entry(OWN/'REPORT.md'),'readback':entry(OWN/'READBACK-AST.json'),'fixtures':len(roots)},ensure_ascii=False))
