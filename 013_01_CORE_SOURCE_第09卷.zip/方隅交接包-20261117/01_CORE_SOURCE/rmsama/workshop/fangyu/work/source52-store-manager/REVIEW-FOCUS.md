# 非作者审查边界

1. service.cjs 的 memberGrant/memberManagement 是服务端派生授权。actor/session/store/grant 在原事务中重新取得，不信客户端 grant、角色标签或 scope stamp 自授。source_store_id 仍由冻结 Source51 负责；本次不改变共享读写语义、SDK where 或共享默认关闭。
2. HQ 成员保存先核新能力与公司/actor/scope，grant 新增需 team；撤 grant 与停用减量不被统一 team 拒绝锁死。密码重置 omitted grant 只保持相同 active operator 原 store 的合法 grant，转店不迁移。任何成员修改仍沿原席位、门店额度、最高人数与会话撤销路径。
3. 经理只能 edit 本店普通 staff。self/peer/admin/partner/cross-store/转店/授 grant/增 can_reply 拒绝；create/update 固定模式，create 重名 409 不重置旧密码。旧 HQ 无新字段 upsert 兼容仍在，不能把它当新前端的唯一写协议。
4. members 旧公开投影兼容增加 bool capability/can_edit；正常 employee HTTP 和 WorkspaceCloud 的既有回包校验已实过。member_save 回执须身份、bool、scope 一致。原生 Owner 每次 call 仍 user()，members cap 探测之前 0 写；新 grant 手写 POST 也核新能力与成功 bool/scope，旧云缺能力 409 当前只读。
5. 两份 member-admin-ui 字节一致。operator 允许请求 fresh members，但只有接受新 store scope 才能写；busy 保存期间不能用公共刷新释放 unknown，成功后内部 load 另受范围门限制。cancel/edit 不清 needsRead，迟回/403/撤权清导航、名单和敏感编辑值。名单读回不冒密码核实。
6. app.mjs 的 team-tab/admin-nav/account-menu/route 使用独立 team 能力，review/maintenance/HQ 仍保旧 admin 限制。此处是代码差异与实际模块 DOM 验证，未运行完整浏览器/真实 GUI 页面；请独审装配入口与初始化顺序。
7. employee_workspace.py 仅 members/member_save 捕获 IntegrationError：可证 400/401/403/409/422/429 安全投影 mutation_committed=False；未知 503/None。真实 remote commit 后 URLError 已实过，UI 只一次写、保存 hold、0 自动重提。其他 operations 与 App 通用 catch 不改。
8. local-transport.mjs 只有三处身份稳定修正：same bool 不换 actor；restore/login 纳顶层 bool 并返回 this.user。保原 401 前端 user/token/epoch reset、真实登录 epoch、原超时与无自动重试。此新增因原 actor 每次回包重建导致 ui.scope null 的 FIRST-FAIL；不缓存 grant。
9. 主 http carrier 在 d7 与 c281 字节相同；c281 新 seam 在 DOM 子 carrier 和 cloud fixture。DOM-RESULT 第 8 check 是 direct native grant remote200 missing bool → local503。记录包含当前子载体精确字节，旧 f0/d7 子载体未单独保存当时 SHA，不能倒推它们也包含该断言。

依赖为 Source51 frozen 四件中的服务父与另外三件，以及现有公开云模块/原生 Owner/员工 Core/AppServer；AppServer 使用冻结 Source50 future app.py D9AB9A…，没有执行未装 Source51 平台函数。DEPENDENCIES.json 仅公开代码及自有合成配置，不收 runs 中数据库、Cookie、DPAPI 或令牌。INPUTS.json 是准备时 provenance，含后来被明确 overlay 的 service/app/employee 旧项；最终实际依赖以新的逐文件 index 为准。

本轮 author story 是技术证据，非真人权限/真实 SDK/云部署/GUI/商业整体验收。formal/source50/source51/entry mutations=0；后继只能在 Root 已核真实 51 回执、父与保护图后另审。
