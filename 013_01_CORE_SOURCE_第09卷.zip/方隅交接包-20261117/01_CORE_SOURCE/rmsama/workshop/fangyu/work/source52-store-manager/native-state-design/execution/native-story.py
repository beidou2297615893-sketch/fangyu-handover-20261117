"""New 52 file-state seams only. Root code functions are unchanged AST.

Actual: reviewed52 CAS, Source44 tools, existing byte OS lock, child probe,
replace/backup/own rollback. Recorded: old50/51 apply, preflight/process/exec,
and fixed guard's PowerShell transport. No original App/data/CIM is touched.
"""
import ast,base64,contextlib,hashlib,json,msvcrt,os,stat,subprocess,sys,traceback,types,uuid
from pathlib import Path
OWN=Path(__file__).resolve().parent;SNAP=OWN/'snapshot'
GROUP=sys.argv[1] if len(sys.argv) in (2,3) else None
if GROUP not in ('normal','guards','rollback','backups'):raise ValueError('one explicit new state group required')
RESUME=len(sys.argv)==3 and sys.argv[2]=='--resume-unfinished-guards'
LOCAL_PARENT_ONLY=len(sys.argv)==3 and sys.argv[2]=='--only-local-parent-guard'
if len(sys.argv)==3 and not (RESUME and GROUP=='guards' or LOCAL_PARENT_ONLY and GROUP=='rollback'):
    raise ValueError('only explicit unfinished/new delta branches may run')
RUN=OWN/'runs'/uuid.uuid4().hex;RUN.mkdir(parents=True)
AST_PROOFS=[];CASES=[]
def pin(raw):return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest().upper()}
def put(path,raw):
    assert path.resolve().is_relative_to(RUN.resolve())
    path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(raw);return pin(raw)
def js(path,value,new=True):
    raw=(json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode()
    if new:
        path.parent.mkdir(parents=True,exist_ok=True)
        with path.open('xb') as stream:stream.write(raw)
    else:put(path,raw)
    return pin(raw)
def exp(value):
    if isinstance(value,Path):return ast.Call(func=ast.Name(id='Path',ctx=ast.Load()),args=[ast.Constant(str(value))],keywords=[])
    if isinstance(value,dict):return ast.Dict(keys=[exp(x) for x in value],values=[exp(x) for x in value.values()])
    if isinstance(value,(tuple,list)):return (ast.Tuple if isinstance(value,tuple) else ast.List)(elts=[exp(x) for x in value],ctx=ast.Load())
    return ast.Constant(value)
def masked(tree,names):
    tree=ast.parse(ast.unparse(tree))
    for node in tree.body:
        if isinstance(node,ast.Assign) and isinstance(node.targets[0],ast.Name) and node.targets[0].id in names:node.value=ast.Constant(None)
    return ast.dump(tree,include_attributes=False)
def bound(name,path,constants):
    raw=(SNAP/name).read_bytes();tree=ast.parse(raw);original=masked(tree,set(constants));seen=set()
    for node in tree.body:
        if isinstance(node,ast.Assign) and isinstance(node.targets[0],ast.Name) and node.targets[0].id in constants:
            key=node.targets[0].id;node.value=exp(constants[key]);seen.add(key)
    assert seen==set(constants),(name,set(constants)-seen)
    ast.fix_missing_locations(tree);assert masked(tree,set(constants))==original
    data=(ast.unparse(tree)+'\n').encode();compile(data,str(path),'exec');put(path,data)
    AST_PROOFS.append({'snapshot':name,'snapshot_pin':pin(raw),'fixture':str(path),'fixture_pin':pin(data),
        'constants_only':sorted(constants),'control_AST_unchanged':True})
    return pin(data)
class FreshExecRecorded(BaseException):pass
BUSINESS=json.loads((SNAP/'BUSINESS52.json').read_bytes())
PARENT_RAW={Path(row['target']).relative_to(Path('C:/积木软件工坊/项目/方隅公寓客户版/work')).as_posix():Path(row['parent_source']).read_bytes() for row in BUSINESS['targets']}
FINAL_RAW={Path(row['target']).relative_to(Path('C:/积木软件工坊/项目/方隅公寓客户版/work')).as_posix():Path(row['candidate']).read_bytes() for row in BUSINESS['targets']}
for row in BUSINESS['targets']:
    key=Path(row['target']).relative_to(Path('C:/积木软件工坊/项目/方隅公寓客户版/work')).as_posix()
    assert pin(PARENT_RAW[key])==row['parent'] and pin(FINAL_RAW[key])==row['candidate_pin']
put(RUN/'carrier-snapshot.py',Path(__file__).read_bytes())

class Fixture:
    def __init__(self,name):
        self.root=RUN/name;self.work=self.root/'work';self.audits=self.work/'product-upgrade-20261009/audits';self.audits.mkdir(parents=True)
        (self.root/'backups').mkdir();self.pilot=self.work/'self-operating-pilot';self.data=self.pilot/'data';self.data.mkdir(parents=True)
        self.entry=self.work/'desktop-self-use-entry/desktop_entry.py';self.entry.parent.mkdir()
        self.iid='d075ac9c039e44038ddbc6f3e753d73c';self.counts={50:0,51:0,52:0};self.events=[];self.execs=[];self.phase=None
        self.policy=lambda phase:'idle';self.inject=None;self.fired=False;self.guard_queries=0
        self.paths52=[self.work/key for key in FINAL_RAW];self.local=self.work/'app/src/web/workspace/local-transport.mjs';self.service=self.work/'cloud/workspace/service.cjs'
        for key,raw in PARENT_RAW.items():put(self.work/key,raw)
        self.paths51=[self.work/key for key in ast.literal_eval(next(n.value for n in ast.parse((SNAP/'join-source52-reviewed.py').read_bytes()).body if isinstance(n,ast.Assign) and n.targets[0].id=='BASE_TARGET_RELATIVE'))]
        self.new51=self.work/'cloud/workspace/shared_store_scope.cjs'
        for path in self.paths51:
            if path not in (self.entry,self.new51):put(path,b'# SYNTHETIC previous source51 file\n')
        put(self.data/'instance.lock',b'existing owned byte lock')
        js(self.data/'running.json',{'pid':1234,'url':'http://127.0.0.1:18001','mode':'headless-test'})
        js(self.data/'recorded-process.json',{'pid_state':'dead'})
        js(self.data/'recorded-preflight.json',{'state':'ready_for_original_native_main','instance_id':self.iid})
        def entry_raw(phase):
            return ("# EXPLICIT recorded entry/preflight/process metadata edge, not real App.\nimport json,stat\nfrom pathlib import Path\n"
                +"PROJECT=Path("+repr(str(self.root))+")\nPILOT=PROJECT/'work/self-operating-pilot'\nPHASE="+str(phase)+"\n"
                +"def plain(path):\n p=Path(path);s=p.lstat();assert stat.S_ISREG(s.st_mode) and s.st_nlink==1 and not p.is_symlink();return p\n"
                +"def preflight():return json.loads((PILOT/'data/recorded-preflight.json').read_bytes())\n"
                +"def pid_state(pid):return json.loads((PILOT/'data/recorded-process.json').read_bytes())['pid_state']\n"
                +"def message(text):return None\nLIVE_MESSAGE='synthetic live'\nHELD_MESSAGE='synthetic held'\n").encode()
        self.entry49=entry_raw(49);self.entry50=entry_raw(50);self.entry51=entry_raw(51);put(self.entry,self.entry49)
        existing50=[self.work/'app/src/assistant/owner_company_receipt_bridge.py',self.work/'app/src/web/workspace/self-operating-read.mjs',
                    self.work/'app/src/app.py',self.work/'app/src/assistant/owner_douyin_read.py',self.entry]
        for path in existing50:
            if not path.exists():put(path,b'# SYNTHETIC old50 parent\n')
        self.parents50={path:path.read_bytes() for path in existing50}
        self.final50={path:b'# SYNTHETIC final50 public stand-in\n' for path in existing50};self.final50[self.entry]=self.entry50
        for number in range(50):self.final50[self.work/f'synthetic-runtime50/file-{number:02}.txt']=f'SYNTHETIC new50 {number}\n'.encode()
        self.parents51={path:(self.final50[path] if path in self.final50 else path.read_bytes()) for path in self.paths51 if path!=self.new51}
        self.final51={path:b'# SYNTHETIC final51 source stand-in\n' for path in self.paths51};self.final51[self.entry]=self.entry51
        self.final51[self.service]=PARENT_RAW['cloud/workspace/service.cjs']
        required={path for path in self.paths51 if path not in self.final50 and path!=self.new51}
        required|={path for path in self.paths52 if path not in self.paths51 and path!=self.local}
        for number in range(367-len(required)):
            path=self.work/f'synthetic-protected/source-{number:03}.txt';put(path,f'SYNTHETIC protected {number}\n'.encode());required.add(path)
        assert len(required)==367 and self.local not in required and self.local not in self.final50
        self.protected50=[{'path':str(path),'pin':pin(path.read_bytes())} for path in sorted(required)]
        closure={Path(row['path']):row['pin'] for row in self.protected50};closure.update({path:pin(raw) for path,raw in self.final50.items()})
        for path in self.paths51:closure.pop(path,None)
        deps51=[]
        for number in range(47):
            path=self.work/f'synthetic-public-deps51/dependency-{number:02}.txt';proof=put(path,f'SYNTHETIC dep51 {number}\n'.encode());closure[path]=proof;deps51.append({'path':str(path),'pin':proof})
        self.protected51=[{'path':str(path),'pin':proof} for path,proof in sorted(closure.items())];assert len(closure)==459
        closure.update({path:pin(raw) for path,raw in self.final51.items()})
        for path in self.paths52:closure.pop(path,None)
        self.protected52=[{'path':str(path),'pin':proof} for path,proof in sorted(closure.items())];assert len(closure)==462
        self.recorder(50,self.parents50,self.final50,self.protected50)
        self.recorder(51,self.parents51,self.final51,self.protected51)
        self.prep50=self.prepared(50,self.parents50,self.final50,self.protected50,[])
        self.join50=self.audits/'join-source50-reviewed.py';self.join51=self.audits/'join-source51-reviewed.py';self.join52=self.audits/'join-source52-reviewed.py'
        common={'join_authorized':True,'independent_code_review_passed':True,'independent_actual_qa_review_passed':True,'join_script_review_passed':True,
                'next_normal_open_only':True,'customer_database_opened':False,'session_copied':False,'deployment_or_packaging_performed':False,
                'fixture_only_synthetic_authorization':True,'additional_evidence':[]}
        def gate(batch,prepared,join,extra={}):
            return {'schema':f'source{batch}_final_root_read','source_batch':batch,**common,
                    'prepared_manifest_pin':pin(prepared.read_bytes()),'join_script_pin':pin(join.read_bytes()),**extra}
        g50=js(self.audits/'source50-final-root-read.json',gate(50,self.prep50,self.join50))
        self.m50={'schema':'source50_next_open_manifest_v1','source_batch':50,'join_authorized':True,'instance_id':self.iid,
                  'approval_pin':g50,'join_script_pin':pin(self.join50.read_bytes()),'targets':[{'path':str(path),'final_pin':pin(raw)} for path,raw in self.final50.items()]}
        self.p50=js(self.audits/'source50-manifest.json',self.m50)
        self.prep51=self.prepared(51,self.parents51,self.final51,self.protected51,deps51,self.p50)
        g51=js(self.audits/'source51-final-root-read.json',gate(51,self.prep51,self.join51,{'base_manifest_pin':self.p50}))
        self.m51={'schema':'source51_next_open_manifest_v1','source_batch':51,'join_authorized':True,'instance_id':self.iid,'base_manifest_pin':self.p50,
                  'approval_pin':g51,'join_script_pin':pin(self.join51.read_bytes()),'targets':[{'path':str(path),'parent_pin':pin(self.parents51[path]) if path in self.parents51 else None,'final_pin':pin(raw)} for path,raw in self.final51.items()],
                  'protected':self.protected51}
        self.p51=js(self.audits/'source51-manifest.json',self.m51)
        put(self.audits/'join-source44-reviewed.py',(SNAP/'join-source44-reviewed.py').read_bytes())
        self.guard=self.work/'source52-root-integration/source_idle_guard.py';guard_pin=bound('source_idle_guard.py',self.guard,{'PROJECT':self.root})
        bound('join-source52-reviewed.py',self.join52,{'PROJECT':self.root,'BASE_MANIFEST_PIN':self.p51,'PRIOR_MANIFEST_PIN':self.p50,'JOIN_AUTHORIZED':True,'SOURCE_GUARD_PIN':guard_pin})
        self.prep52=self.prepared(52,
             {self.work/key:raw for key,raw in PARENT_RAW.items()},{self.work/key:raw for key,raw in FINAL_RAW.items()},self.protected52,self.protected52[:17],self.p51)
        g52=js(self.audits/'source52-final-root-read.json',gate(52,self.prep52,self.join52,{'base_manifest_pin':self.p51,'source_guard_pin':guard_pin}))
        self.m52={'schema':'source52_next_open_manifest_v1','source_batch':52,'join_authorized':True,'instance_id':self.iid,'base_manifest_pin':self.p51,
                  'approval_pin':g52,'join_script_pin':pin(self.join52.read_bytes()),'source_guard_pin':guard_pin,
                  'targets':[{'path':str(self.work/key),'parent_pin':pin(PARENT_RAW[key]),'final_pin':pin(raw)} for key,raw in FINAL_RAW.items()], 'protected':self.protected52}
        self.p52=js(self.audits/'source52-manifest.json',self.m52)
        self.legacy_path=self.entry.parent/'next_open_source.py';self.successor_path=self.entry.parent/'next_open_source51.py';self.latest_path=self.entry.parent/'next_open_source52.py';self.launcher_path=self.entry.parent/'source_next_open_launcher.py'
        l50=bound('next_open_source.py',self.legacy_path,{'PROJECT':self.root,'ROOT_MANIFEST_PIN':self.p50,'TARGET_PATHS':tuple(self.final50)})
        l51=bound('next_open_source51.py',self.successor_path,{'PROJECT':self.root,'BASE_MANIFEST_PIN':self.p50,'MANIFEST_PIN':self.p51})
        l52=bound('next_open_source52.py',self.latest_path,{'PROJECT':self.root,'BASE_MANIFEST_PIN':self.p51,'MANIFEST_PIN':self.p52,'JOIN_AUTHORIZED':True,'GUARD_PIN':guard_pin})
        bound('source_next_open_launcher.py',self.launcher_path,{'PROJECT':self.root,'HELPER_PIN':l50,'SUCCESSOR_PIN':l51,'LATEST_PIN':l52,'ENTRY_PARENT_PIN':pin(self.entry49)})
        self.launcher=self.load(self.launcher_path)
        self.legacy=self.launcher._load(self.legacy_path,l50,'owned50_'+uuid.uuid4().hex)
        self.successor=self.launcher._load(self.successor_path,l51,'owned51_'+uuid.uuid4().hex)
        self.latest=self.launcher._load(self.latest_path,l52,'owned52_'+uuid.uuid4().hex)
    def load(self,path):
        module=types.ModuleType('owned_'+uuid.uuid4().hex);module.__file__=str(path);exec(compile(path.read_bytes(),str(path),'exec'),module.__dict__);return module
    def entry_module(self):return self.launcher._load(self.entry,pin(self.entry.read_bytes()),'entry_'+uuid.uuid4().hex)
    def prepared(self,batch,parents,finals,protected,deps,base=None):
        own=self.work/('overnight-commercial-20261014/source50-preparation' if batch==50 else f'source{batch}-root-integration');rows=[]
        for path,raw in finals.items():
            candidate=own/'candidates'/path.relative_to(self.work);put(candidate,raw)
            rows.append({'target':str(path),'candidate':str(candidate),'parent':pin(parents[path]) if path in parents else None,'candidate_pin':pin(raw)})
        value={'schema':f'source{batch}_owner_prepared_v1','source_batch':batch,'join_authorized':False,'instance_id':self.iid,
               'targets':rows,'protected':protected,'candidate_dependencies':deps,'evidence':[],'new_directories':[],'fixture_only_synthetic_authorization':True}
        if base is not None:value['base_manifest_pin']=base
        path=own/'PREPARED.json';js(path,value);return path
    def recorder(self,batch,parents,finals,protected):
        plan=self.root/f'RECORDED-{batch}-PLAN.json';js(plan,{'targets':[{'target':str(path),'before_hex':parents[path].hex() if path in parents else None,'after_hex':raw.hex()} for path,raw in finals.items()]})
        code=("# EXPLICIT old CAS recorder only, never original CAS.\nimport hashlib,json,uuid\nfrom pathlib import Path\nROOT=Path("+repr(str(self.root))+");BATCH="+str(batch)+"\n"
          "def pin(raw):return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest().upper()}\n"
          "A=ROOT/'work/product-upgrade-20261009/audits';M=json.loads((A/f'source{BATCH}-manifest.json').read_bytes());G=json.loads((A/f'source{BATCH}-final-root-read.json').read_bytes());P=json.loads((ROOT/f'RECORDED-{BATCH}-PLAN.json').read_bytes())\n"
          "prepared=ROOT/'work'/('overnight-commercial-20261014/source50-preparation/PREPARED.json' if BATCH==50 else 'source51-root-integration/PREPARED.json')\n"
          "B=ROOT/f'backups/source{BATCH}-owner'/uuid.uuid4().hex;B.mkdir(parents=True);rows=[]\n"
          "for row in P['targets']:\n t=Path(row['target']);before=bytes.fromhex(row['before_hex']) if row['before_hex'] is not None else None;after=bytes.fromhex(row['after_hex']);bp=None\n if before is not None:\n  assert t.read_bytes()==before;bp=B/t.relative_to(ROOT/'work');bp.parent.mkdir(parents=True,exist_ok=True);bp.write_bytes(before)\n else:assert not t.exists()\n t.parent.mkdir(parents=True,exist_ok=True);t.write_bytes(after);rows.append({'target':str(t),'parent':pin(before) if before is not None else None,'candidate':pin(after),'backup':str(bp) if bp else None})\n"
          "V={'schema':f'source{BATCH}_owner_joined_v1','source_batch':BATCH,'approval_sha256':M['approval_pin']['sha256'],'authority_manifest_pin':pin((A/f'source{BATCH}-manifest.json').read_bytes()),'prepared_manifest_pin':pin(prepared.read_bytes()),'backup':str(B),'targets':rows,'protected':json.loads(prepared.read_bytes())['protected'],'new_directories':[],'synthetic_recorded_old_apply':True}\n"
          "for key in ('App_restarted','marker_changed','customer_database_opened','session_copied','deployed','real_GUI_verified','commercial_complete'):V[key]=False\n"
          "if BATCH==51:V['base_receipt_pin']=pin((A/'source50-joined.json').read_bytes())\n"
          "with (A/f'source{BATCH}-joined.json').open('x',encoding='utf-8') as stream:stream.write(json.dumps(V,ensure_ascii=False,indent=2)+'\\n')\n")
        put(self.audits/f'join-source{batch}-reviewed.py',code.encode())
    def profile(self,frame,event,arg):
        if event!='call':return
        file=frame.f_globals.get('__file__');name=frame.f_code.co_name
        if file in (str(self.join50),str(self.join51)) and name=='<module>':self.counts[50 if file==str(self.join50) else 51]+=1
        if file==str(self.join52) and name=='main':self.counts[52]+=1
        if name in ('require_source_idle','_source_idle') and file in (str(self.join52),str(self.latest_path)):self.phase=frame.f_locals['phase']
    def record(self,batch):return json.loads((self.audits/f'source{batch}-joined.json').read_bytes())
    def backup_for(self,batch,path):return Path(next(row['backup'] for row in self.record(batch)['targets'] if row['target']==str(path)))
    def staging(self):return [str(path) for path in self.root.rglob('*') if path.is_file() and (path.name.startswith('.source52') or path.suffix=='.tmp')]
    @contextlib.contextmanager
    def io(self):
        replace,rename,execv,run=os.replace,os.rename,os.execv,subprocess.run
        def actual_replace(source,target):
            result=replace(source,target);target=Path(target)
            if target in self.paths52:
                self.events.append({'operation':'actual_replace','target':str(target),'current_pin':pin(target.read_bytes())})
                if self.inject:self.inject('replace',target)
            return result
        def actual_rename(source,target):
            result=rename(source,target)
            if self.inject:self.inject('rename',Path(target))
            return result
        def recorded_exec(executable,argv):
            assert argv==[sys.executable,'-X','utf8','-B','-I',str(self.entry)]
            with (self.data/'instance.lock').open('r+b') as lock:
                lock.seek(0);msvcrt.locking(lock.fileno(),msvcrt.LK_NBLCK,1);lock.seek(0);msvcrt.locking(lock.fileno(),msvcrt.LK_UNLCK,1)
            self.execs.append({'argv':argv,'actual_byte_lock_released':True,'real_App_started':False});raise FreshExecRecorded()
        def recorded_query(args,**kwargs):
            if Path(args[0]).name.lower()=='powershell.exe':
                assert args[1:4]==['-NoProfile','-NonInteractive','-EncodedCommand']
                program=base64.b64decode(args[4]).decode('utf-16le')
                literal_program=program.replace('[_]','_').replace('[%]','%').replace('[[]','[')
                assert str(self.root) in literal_program or str(self.root).replace('\\','/') in literal_program
                state=self.policy(self.phase);assert state in ('idle','live','unknown');self.guard_queries+=1
                self.events.append({'operation':'recorded_consumer_transport','phase':self.phase,'state':state})
                value={'scope':'fangyu_customer_source_metadata_v1','state':state,'live_count':int(state=='live'),'unknown_count':int(state=='unknown')}
                return subprocess.CompletedProcess(args,0,json.dumps(value),'')
            assert Path(args[0])==Path(sys.executable) and args[1:3]==['-B','-c'] and str(self.data/'instance.lock')==args[-1]
            return run(args,**kwargs)
        os.replace,os.rename,os.execv,subprocess.run=actual_replace,actual_rename,recorded_exec,recorded_query;sys.setprofile(self.profile)
        try:yield
        finally:sys.setprofile(None);os.replace,os.rename,os.execv,subprocess.run=replace,rename,execv,run
    def seed51(self):
        with self.io(),self.legacy._exclusive_existing_lock(self.entry_module()):
            self.legacy._start_once(self.m50);self.successor._invoke(self.legacy,self.join50,self.m50['join_script_pin'],self.m50['approval_pin']['sha256'])
            raw=self.successor._base_receipt(self.legacy,self.m51,self.m50,False);self.successor._start_once(self.legacy,self.m51,raw)
            self.successor._invoke(self.legacy,self.join51,self.m51['join_script_pin'],self.m51['approval_pin']['sha256'])
            self.successor._readback(self.legacy,self.m51,self.m50)
    def normal(self,launcher=False):
        before=dict(self.counts);args=sys.argv;sys.argv=[str(self.launcher_path)]
        try:
            with self.io():
                try:result=self.launcher.main() if launcher else self.latest.before_normal_open(self.entry_module(),self.legacy,self.successor)
                except FreshExecRecorded:result={'decision':'fresh_exec_recorded','source_mutations':None,'real_App_started':False}
        finally:sys.argv=args
        return result,{key:self.counts[key]-before[key] for key in self.counts}
    def summary(self,name,result,delta,**extra):
        value={'case':name,'result':result,'invoke_delta':delta,'counts':self.counts,'events':self.events,'execs':self.execs,
            'staging':self.staging(),'actual52_CAS':True,'old50_51_apply':'explicit recorders','preflight_process_exec_consumer_query':'recorded only',
            'formal_App_data_cookie_CIM_platform_model_calls':0,**extra}
        js(self.root/'CASE.json',value);CASES.append({'case':name,'path':str(self.root/'CASE.json'),'pin':pin((self.root/'CASE.json').read_bytes())})

def normal_group():
    f=Fixture('normal-idle-chain');result,delta=f.normal(launcher=True)
    assert result['decision']=='fresh_exec_recorded' and delta=={50:1,51:1,52:1},(result,delta)
    receipt=f.record(52);assert len(receipt['targets'])==9 and all(row['backup'] for row in receipt['targets'])
    for row in receipt['targets']:assert pin(Path(row['backup']).read_bytes())==row['parent'] and pin(Path(row['target']).read_bytes())==row['candidate']
    assert not f.staging() and len(f.execs)==1
    assert f.local not in {Path(row['path']) for row in f.m51['protected']} and f.local not in f.final50 and f.local not in f.paths51
    assert pin(f.backup_for(51,f.service).read_bytes())==pin(f.parents51[f.service])
    assert pin(f.backup_for(52,f.service).read_bytes())==pin(PARENT_RAW['cloud/workspace/service.cjs'])
    assert pin(f.backup_for(52,f.local).read_bytes())==pin(PARENT_RAW['app/src/web/workspace/local-transport.mjs'])
    f.latest._readback(f.legacy,f.successor,f.m52,f.m51,f.m50)
    future,again=f.normal();assert future['decision']=='continue' and again=={50:0,51:0,52:0}
    phases=[event['phase'] for event in f.events if event['operation']=='recorded_consumer_transport']
    assert phases.count('before_replace')==9 and all(phase in phases for phase in ('before_source_chain','before_source52_started','before_backups_and_temps','before_success_receipt'))
    f.summary('idle chain then cumulative future zero invoke',result,delta,future=future,future_delta=again,
              target_count=9,backup_count=9,new_count=0,local_transport_no_ancestor_mapping=True)
    for name,path in (('51-original-parent-backup',f.backup_for(51,f.service)),('52-local-transport-parent-backup',f.backup_for(52,f.local)),('raw-source50-receipt',f.audits/'source50-joined.json')):
        original=path.read_bytes();put(f.root/'history'/name,original);put(path,b'SYNTHETIC TAMPER\n')
        held,delta=f.normal();assert held['decision']=='held' and delta=={50:0,51:0,52:0}
        js(f.root/('TAMPER-'+name+'.json'),{'held':held,'invoke_delta':delta,'tampered':str(path)});put(path,original)

def guards_group():
    for state in (() if RESUME else ('live','unknown')):
        f=Fixture('initial-guard-'+state);f.seed51();f.policy=lambda phase,state=state:state
        result,delta=f.normal();assert result['decision']=='held' and result['source_mutations']==0 and delta=={50:0,51:0,52:0}
        assert not (f.audits/'source52-next-open-started.json').exists();f.summary('initial '+state+' before STARTED',result,delta)
    for phase,state in (('before_backups_and_temps','unknown'),('before_replace','live'),('before_success_receipt','unknown')):
        f=Fixture('guard-transition-'+phase);f.seed51()
        def policy(current):
            written=sum(event['operation']=='actual_replace' for event in f.events)
            if current==phase and (phase!='before_replace' or written>=1):f.fired=True
            return state if f.fired else 'idle'
        f.policy=policy;result,delta=f.normal();assert result['decision']=='held' and result['source_mutations'] is None and delta[52]==1
        failure=json.loads((f.audits/'source52-join-failed.json').read_bytes())
        if phase=='before_backups_and_temps':assert failure['backup'] is None
        else:assert any(row['restored'] is False for row in failure['rollback'])
        assert not f.staging();held,again=f.normal();assert held['decision']=='held' and again=={50:0,51:0,52:0}
        f.summary('fresh '+phase+' '+state+' refuses rollback when occupied',result,delta,failure=failure,future=held,future_delta=again)
    for filename in ('source52-next-open-started.json','source52-join-failed.json'):
        f=Fixture('unknown-'+filename);f.seed51();original=b'{"synthetic_unknown_original":true}\n';put(f.audits/filename,original)
        result,delta=f.normal();assert result['decision']=='held' and delta=={50:0,51:0,52:0};assert (f.audits/filename).read_bytes()==original
        f.summary('preserved '+filename,result,delta)
    f=Fixture('actual-owned-lock-busy');f.seed51();code="import msvcrt,sys;f=open(sys.argv[1],'r+b');f.seek(0);msvcrt.locking(f.fileno(),msvcrt.LK_NBLCK,1);print('locked',flush=True);sys.stdin.readline();f.seek(0);msvcrt.locking(f.fileno(),msvcrt.LK_UNLCK,1);f.close()"
    child=subprocess.Popen([sys.executable,'-B','-c',code,str(f.data/'instance.lock')],stdin=subprocess.PIPE,stdout=subprocess.PIPE,text=True,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
    try:
        assert child.stdout.readline().strip()=='locked';result,delta=f.normal();assert result['decision']=='held' and delta=={50:0,51:0,52:0};f.summary('actual owned lock busy',result,delta)
    finally:child.stdin.write('\n');child.stdin.flush();child.wait(timeout=15)

def rollback_group():
    if LOCAL_PARENT_ONLY:
        f=Fixture('independent-local-parent-after-started');f.seed51()
        def inject(operation,target):
            if operation=='rename' and target==f.audits/'source52-next-open-started.json':put(f.local,b'SYNTHETIC BAD independent parent\n')
        f.inject=inject;result,delta=f.normal()
        assert result['decision']=='held' and result['source_mutations'] is None and delta[52]==1
        failure=json.loads((f.audits/'source52-join-failed.json').read_bytes())
        assert failure['backup'] is None and failure['rollback']==[] and not f.staging()
        assert not any(event['operation']=='actual_replace' for event in f.events)
        assert f.local.read_bytes()==b'SYNTHETIC BAD independent parent\n'
        held,again=f.normal();assert held['decision']=='held' and again=={50:0,51:0,52:0}
        f.summary('new local-transport parent has no ancestor mapping but CAS rejects its actual bad byte',result,delta,
                  failure=failure,actual_replacements=0,no_52_backup_or_temp=True,future=held,future_delta=again)
        return
    for foreign in (False,True):
        f=Fixture('idle-partial-rollback-'+str(foreign));f.seed51();changed=[]
        def inject(operation,target):
            if operation=='replace' and not f.fired:
                changed.append(target)
                if len(changed)==2:
                    f.fired=True
                    if foreign:put(changed[0],b'SYNTHETIC FOREIGN preserved\n')
                    raise OSError('synthetic IO interruption after two actual replacements')
        f.inject=inject;result,delta=f.normal();assert result['decision']=='held' and result['source_mutations'] is None and delta[52]==1
        failure=json.loads((f.audits/'source52-join-failed.json').read_bytes());assert len(failure['rollback'])==2 and not f.staging()
        for key,raw in PARENT_RAW.items():
            path=f.work/key
            assert path.read_bytes()==(b'SYNTHETIC FOREIGN preserved\n' if foreign and path==changed[0] else raw)
        assert sum(row['restored'] is False for row in failure['rollback'])==int(foreign)
        before=(f.audits/'source52-join-failed.json').read_bytes();held,again=f.normal();assert again=={50:0,51:0,52:0} and (f.audits/'source52-join-failed.json').read_bytes()==before
        f.summary('actual idle IO rollback foreign='+str(foreign),result,delta,failure=failure,remaining_foreign=foreign,future=held,future_delta=again)

def backups_group():
    for fault in ('missing51-before-started','crossbatch50-before-started','missing50-after-started','missing51-after-first-replace'):
        f=Fixture(fault);f.seed51();original50=(f.audits/'source50-joined.json').read_bytes();original51=(f.audits/'source51-joined.json').read_bytes()
        put(f.root/'history/source50-original.json',original50);put(f.root/'history/source51-original.json',original51)
        if fault=='missing51-before-started':f.backup_for(51,f.service).unlink()
        if fault=='crossbatch50-before-started':
            receipt=f.record(50);wrong=Path(f.record(51)['backup']);receipt['backup']=str(wrong)
            for row in receipt['targets']:
                if row['backup'] is not None:row['backup']=str(wrong/Path(row['target']).relative_to(f.work))
            js(f.audits/'source50-joined.json',receipt,new=False);receipt51=f.record(51);receipt51['base_receipt_pin']=pin((f.audits/'source50-joined.json').read_bytes());js(f.audits/'source51-joined.json',receipt51,new=False)
        def inject(operation,target):
            if not f.fired and fault=='missing50-after-started' and operation=='rename' and target==f.audits/'source52-next-open-started.json':
                f.fired=True;f.backup_for(50,f.entry).unlink()
            if not f.fired and fault=='missing51-after-first-replace' and operation=='replace':
                f.fired=True;f.backup_for(51,f.service).unlink()
        f.inject=inject;result,delta=f.normal();assert result['decision']=='held'
        if fault.endswith('before-started'):
            assert delta=={50:0,51:0,52:0} and not (f.audits/'source52-next-open-started.json').exists()
        elif fault=='missing50-after-started':
            assert delta[52]==1 and result['source_mutations'] is None and not (f.root/'backups/source52-owner').exists()
        else:
            assert delta[52]==1 and result['source_mutations'] is None
            failure=json.loads((f.audits/'source52-join-failed.json').read_bytes());assert all(row['restored'] for row in failure['rollback'])
        assert not f.staging();held,again=f.normal();assert held['decision']=='held' and again=={50:0,51:0,52:0}
        f.summary('predecessor '+fault,result,delta,future=held,future_delta=again,
                  no_52_backups_before_start_or_CAS_preflight=not (f.root/'backups/source52-owner').exists())

try:
    {'normal':normal_group,'guards':guards_group,'rollback':rollback_group,'backups':backups_group}[GROUP]()
    js(RUN/'AST-PROOFS.json',{'proofs':AST_PROOFS,'all_control_AST_unchanged':all(row['control_AST_unchanged'] for row in AST_PROOFS)})
    inherited=[]
    if RESUME:
        first=OWN/'runs/cd08bf0279d344af9f6a24f9a9d63841/FIRST-FAIL.json';history=json.loads(first.read_bytes())
        for row in history['completed_cases']:
            data=Path(row['path']).read_bytes();assert pin(data)==row['pin'];case=json.loads(data)
            assert case['result']['decision']=='held' and case['invoke_delta']=={'50':0,'51':0,'52':0}
            inherited.append(row)
    result={'schema':'source52_native_owned_new_state_group_v1','status':'PASS','group':GROUP,'cases':CASES,
            'inherited_initial_live_unknown_only':inherited,
            'carrier_pin':pin(Path(__file__).read_bytes()),'snapshot_inputs_pin':pin((OWN/'SNAPSHOT.json').read_bytes()),
            'actual52_CAS_OS_byte_lock_replace_rollback':True,'old50_51_apply_preflight_process_consumer_exec':'explicit recorders',
            'Root_source_or_graph_App_DB_cookie_real_CIM_platform_model_calls':0,'old_business_QA_runs':0}
    js(RUN/'RESULT.json',result);print(json.dumps({'group':GROUP,'result':str(RUN/'RESULT.json'),'pin':pin((RUN/'RESULT.json').read_bytes())},ensure_ascii=False))
except BaseException:
    js(RUN/'FIRST-FAIL.json',{'status':'FAIL','group':GROUP,'traceback':traceback.format_exc(),'carrier_pin':pin(Path(__file__).read_bytes()),'completed_cases':CASES})
    raise
