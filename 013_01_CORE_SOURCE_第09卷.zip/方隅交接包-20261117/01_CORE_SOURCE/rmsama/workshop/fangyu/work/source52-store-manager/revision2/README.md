# Source52 后继 revision2：恢复后店级入口可达

首 FROZEN 20306/44446145 与其九件候选、c281 HTTP/DOM、非作者 CHANGES_REQUIRED 均保留。本后继仍九个既有目标，仅修改 app.mjs 和两份相同 member-admin-ui.mjs；其他六件逐字继承，真实合入父仍与首九一致。delta_parent 指首候选，target.parent 指未来正式合入父，两者不能混用。

非作者发现：初始 development_local_only=true 时成员 probe 被拒，店级入口隐藏；checkDevelopmentIdentity 核实同身份 me false 后只恢复设备/任务，没有重新读取成员能力，入口无法到达。另 cloud.user=value.user 会漏掉已核顶层 false，下次回包可能再换 actor。

app 在原同 epoch/generation/id/tenant_id/username 校验之后，将已核顶层 false 纳入 actor，然后 await probeMemberEntry(sameSession)，前后继续原 sameSession 门。probe 改调用 module.probe；module.probe 复用 load 的全部 actor/公司/环境/epoch/范围/回包校验，但 automatic 读回不解除 needsRead。保存未知后，即使自动恢复重新核得 fresh store scope、只读入口可到达，保存仍 hold、没有重提；只有原主动 load 接受当前范围名单才按旧规则解除，并明确密码未独立核实。没有缓存 grant 或开放 review、maintenance/HQ。

新增代表只针对这一接缝：执行候选 app 的 checkDevelopmentIdentity/refreshTeam/probeMemberEntry/syncMemberEntry/stopDevelopmentIdentityWatch 原函数体、真实 member module 和 WorkspaceCloud；DOM 与 browser 回包明确合成，设备/任务边缘录制。没有执行完整 app import、真实 AppServer HTTP、浏览器或 GUI。原 c281 是首候选的实际 HTTP 证据，本增量不重跑它，也不冒其已执行 revision2 三个新字节。

revision2/runs/79d100bc-7d97-41cc-8123-e22b18568291/FIRST-RED.json 是新 P2 的首唯一复现；04cbaf9d-c1f8-4e94-96a0-54e102b88b34/RESULT.json 核 hidden→同身份 me false→fresh capability 后仅店级入口可见、unknown 自动读仍 hold/主动读解、迟回 epoch 拒及普通员工 403；cfe94d4d-5ca4-4b9d-85c7-cc94d6ce4bfa/RESULT.json 仅跑后来明确的 401 边界，不重这四个已过分支。每个 run 创建当时完整 app/module/transport/carrier 原字节快照，不倒填旧 f0/d7 子载体历史。

本候选 formal/50/51/entry/SDK/platform/GUI mutations=0。仍需非作者只审三件增量与新证据；Root 最后按 revision2 合成九 pins 重绑后继 CAS。cas-draft 首版默认 false，仍绑定首九候选 literal，不是本 revision2 的可授权最终脚本。
