# Source52 本机状态代表设计：未运行

当前只设计与准备骨架，Root 最终 CAS/idle guard/helper52/launcher/图尚未给精确 pin。run_enabled=false，0 状态代表执行、0 正式/Root 图/helper 写入、0 原 App/原锁/真实 DB/Cookie/平台/模型。没有 RESULT/PASS。原 Source51 状态故事仅复用成熟锁与文件夹具方式，不重新执行。

权威输入为 source52-current.md 顶部、source52-native-proposal/PROPOSAL.md 与 PARENT-INTERFACES.json、业务 revision2 FROZEN20693/73771949。native proposal 的 8existing 是旧未冻结阶段：当前 exact9existing/9backup/0new，四平台/业务不重验。Source51 当前图为 Root 给出的 11final/459protected；52 新保护数量待 Root 实际 union，不能预报或把本设计当最终授权图。52 local-transport 父5301/00F1未列51 targets/protected，没有旧层映射；其余8可与51 future集合对应。

最终实际运行前必须收到 Root 固定：52 CAS、client-source idle guard、helper52、launcher、52 PREPARED/manifest/gate；及所依赖 immutable50/51 helpers、原 entry、Source44 helper、50/51 PREPARED/manifest/gate。所有 public raw snapshot 先核 exact pin，再 AST 仅绑定 Root 允许的固定路径/pin constants到自有 fixture root；所有函数控制 AST 必须原字节/结构一致。guard 的消费者 metadata/CIM 运输、旧50/51 CAS、entry preflight 和 fresh exec 明示录制；52 CAS 与 msvcrt 原existing byte0/length1排他锁、child probe、九件原父备份/临时文件/真实 replace/回滚必须实际执行。不会读取原客户进程metadata、扫描真实PID、占原锁或触GUI。

单一 harness 使用每个分支唯一自有 runs/<uuid>/project，所有 PROJECT/WORK/AUDITS/OWN/PILOT/ENTRY/backup/global paths必须落在该根；禁止指真实 PILOT、正式代码或真实 Root audits。fixture 九父与九 final 可以复用业务冻公共字节，只验证安装文件契约，不 import业务，不冒业务功能再验。50大runtime和前代非本批文件只用合成公开 bytes/pins；50/51 recorder 按成熟回执shape生成自有真实文件、原父backup和成功raw，明确不称前代真实 CAS执行。Root最终metadata shape若与设计不同，先修 skeleton并提交具体差异，不先跑。

四个必要因果组均属于此次52原生装载边界：

1. **正常 idle 与累计证明。** 初始无成功，正常 checked-raw launcher/helper低层调度，50→51→52各invoke一次，在同原byte锁内实际52替换九existing并保九backup/0new/0temp；不调用会exec的旧51.before_normal_open。累计readback立即成功、释放自己的锁后fresh exec只录制固定 `[python, '-X', 'utf8', '-B', '-I', ENTRY]`，并真实检验锁已释放。已50/已51起点可用明确录制边缘补后级；同一实际52CAS控制源驱动此次正常及必要失败分支，前代功能不重跑。未来52成功0invoke，原raw receipts不重写。
2. **live/unknown与原号保史。** Root guard固定本客户 app/src、owner-admin/server+site、cloud/workspace；其 metadata运输依最终接口分别提供 idle/live/unknown，禁止真实CIM。正常轨迹记录锁内52 STARTED前、备份/temp前、replace前、success封口前均fresh guard调用，不用一次idle缓存代后面。初始live/unknown各一条拒绝必须0invoke/0replacement；中途unknown或live的最难一条（由最终guard接口决定）进入实际52CAS后拒并保失败/自己的rollback，source_mutations必须unknown，不能因尚未replace便写0。STARTED未知、FAILED存在、实际另自有进程锁忙均hold/0invoke，不覆盖原史、不自动retry。
3. **九父CAS与故障回滚。** 若正常STARTED前readback已拒坏父，只能记门禁，不要求CAS伪造failure。要触达实际CAS坏父拒绝则在自己的真实STARTED已CreateNew之后、CAS调用前注入；0replacement、唯一failure、下一开hold。另一唯一fixture在实际至少两次replace后由OS/运输接口注入IO异常；自己candidate恢复、九backup/STARTED/FAILED保留、0temp。foreign支路只在已replace的自有文件注入外来byte：拒覆盖foreign，继续恢复其他自己的项，不能回滚已成功50/51。各首失效唯一文件保留，不覆盖。
4. **层级备份与篡改拒绝。** 正常成功fixture复用，只改自有物：原50被51覆盖的目标必须用51成功回执实际原父backup证明；原50未被51覆盖但被52覆盖用52backup；原51被52覆盖用52backup；未覆盖项用current，52final用current。选择service一次同时触达50→51backup、51→52backup、current52三层，选择local-transport自己的52backup验证其无旧层映射。分别篡改51原父backup、52原父backup或原51/raw50receipt，未来读回必须held/0invoke，按唯一分支记录不冒旧层原bytes。修复只改自有夹具，不删除失败或真实回执。

精确计数和证据以最终 Root 图为准，设计不构造已通过断言。正常轨迹须记录 stage invoke计数、guard phasefresh次序、锁握持/释放、9target/9backup/0new/0temp、fixed argv、前代raw receipt链、三层service证明以及local-transport独立parent来源。拒绝轨迹记录前级是否invoke过：只有各级都未invoke才source_mutations=0；任一级已调用后失败均unknown，不能把作者知道fixture已回滚等同生产业务0变化。

载体历史从本轮首次运行就保完整 raw snapshots，保存根/常量绑定表/body AST proof/当前carrier，以及首唯一失败、结果和输出。任何回执和backup路径必须从固定同份manifest/成功receipt推导，普通单链接、无reparse，并核parent字节；不能任选路径或重造backup补证据。真实平台、SDK/云、GUI、原App自然重开、全商业验收继续未验。
