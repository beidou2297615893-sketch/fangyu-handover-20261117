import hashlib,json
from pathlib import Path
OWN=Path(__file__).absolute().parent;PROJECT=Path('C:/积木软件工坊/项目/方隅公寓客户版')
source=PROJECT/'work/app/src/web/workspace/local-transport.mjs';raw=source.read_bytes()
def pin(value):return {'bytes':len(value),'sha256':hashlib.sha256(value).hexdigest().upper()}
parent=OWN/'parents/work/app/src/web/workspace/local-transport.mjs';parent.parent.mkdir(parents=True,exist_ok=True)
with parent.open('xb') as stream:stream.write(raw)
text=raw.decode('utf-8')
old='        if(this.user)this.user={...this.user,development_local_only:next};'
assert text.count(old)==1;text=text.replace(old,'        if(this.user&&this.user.development_local_only!==next)this.user={...this.user,development_local_only:next};',1)
old="      this.user=value.user;this.token='local-session';return value.user;"
assert old in text;text=text.replace(old,"      this.user={...value.user,development_local_only:value.development_local_only===true};this.token='local-session';return this.user;",1)
old="    this.user=value.user;this.token='local-session';this.localOnly=false;return value.user;"
assert old in text;text=text.replace(old,"    this.user={...value.user,development_local_only:value.development_local_only===true};this.token='local-session';this.localOnly=false;return this.user;",1)
target=OWN/'candidate/work/app/src/web/workspace/local-transport.mjs';target.write_text(text,encoding='utf-8',newline='\n')
# The unchanged parent transport was already saved for the actual first DOM
# failure. Do not overwrite it: the corrected adapter has its own test filename.
corrected=OWN/'tests/local-transport-candidate.mjs';corrected.write_bytes(target.read_bytes())
parents=json.loads((OWN/'PARENTS-8.json').read_bytes());parents['proposed_target_count']=9
parents['targets'].append({'target':str(source),'parent_source':str(parent),'parent':pin(raw),'parent_kind':'unchanged_Source51_public_transport_parent',
 'Root_explicit_addition':'same-bool responses must preserve current actor identity, restore/login normalize bool'})
with (OWN/'PARENTS-9.json').open('x',encoding='utf-8') as stream:stream.write(json.dumps(parents,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'parent':pin(raw),'candidate':pin(target.read_bytes()),'targets':9}))
