# Source52 Root CAS 不可授权草稿

join-source52-reviewed.py 27414/2678AA33373EF0B166B05BCA562B134151F87F8E64FEFAE70CE56F1725E7772F 仅为独立草稿，没有执行。JOIN_AUTHORIZED=False；BASE_MANIFEST_PIN=None 且 main/source51_predecessor 均明确拒空 pin，即便翻布尔值也不能 apply。Root 最后消费非作者代码审、实际新接缝证据、真实 Source51 authority 与未来真实回执后再绑图。首九业务候选已收到 P2 CHANGES_REQUIRED，最终三件 revision2 literal 必须由 Root 后继替换并独审，不能以本首版 literal 冒最终通过。

复用已审核 Source51 草稿 19503/C6647941… 及成熟 Source44 五 AST 工具 9601/5F5E3EA2…。original_main_dead、existing_lock_is_held、proof、base_readback 与原 Source51 逐 AST 完全相同。没有新升级框架或业务 import。exact9 existing/9父备份/0new，无新目标目录；同 normal-open instance.lock 的 byte0/length1 子进程 probe，不重新抢调用者锁。实例 alive/unknown 拒，unknown STARTED/FAILED 由外层正常协调器保史并禁重试。

Root 接口沿原 51 shape：

- work/source52-root-integration/PREPARED.json：schema source52_owner_prepared_v1、batch52、join_authorized false、iid、base_manifest_pin 固定51、targets[{target,candidate,parent,candidate_pin}]、protected[{path,pin}]、candidate_dependencies[{path,pin}]、evidence[{path,pin}]、new_directories[]。
- audits/source52-manifest.json：schema source52_next_open_manifest_v1、batch52、iid、join_authorized true、base_manifest_pin 固定51、approval_pin、join_script_pin、targets[{path,parent_pin,final_pin}]、protected 同 prepared。
- audits/source52-final-root-read.json：schema source52_final_root_read、batch52、join_authorized true、三独审标志、next_normal_open_only true、base_manifest_pin 同51、join_script_pin、prepared_manifest_pin、additional_evidence，DB/session/deploy or packaging false。
- audits/source52-next-open-started.json：schema source52_next_open_started_v1、batch52、iid、同 os.getpid()、approval_sha256、manifest_pin、base_receipt_pin 绑定真实 source51-joined 原 raw 字节、auto_retry false。
- source52-joined.json：schema source52_owner_joined_v1、batch52、approval/prepared/authority/base_receipt pins、targets[{target,parent,candidate,backup}] 九件、protected、new_directories[]，App restart/marker/DB/session/deploy/GUI/commercial_complete false。
- source52-join-failed.json：schema source52_owner_join_failed_v1、唯一 CreateNew、authority/approval/base receipt、error type、backup 可空、逐项 rollback、automatic_retry false；成功或失败既存路径即拒。

前代验证固定51 manifest→gate→prepared→真实51 receipt11 targets/parent/final/保护；51 receipt.base_receipt_pin 继续核真实50 raw，50 authority仍固定 FA18，55回执与旧 protected 同原prepared。检查51 protected 是50 final+旧protected减51十一target+51依赖的闭包，实际读回允许且仅允许已授权51覆盖。52 STARTED必须绑定该真实51 raw，52保护为51 final+51protected减九target+52公开不变依赖，authority/prepared数组相等。任何52写前核所有父/候选/保护；ENTRY 只是51 final保护，用来提取原 pid_state，不属于52 target。

既有目标备份后逐件临时完整写；每次 replace 紧邻 no_link_parent/temp proof/parent CAS，attempted-first。异常只恢复自己实际 candidate，foreign 拒且继续其余；restore临时统一 finally，失败和备份不删除，不递归清理。

下一阶段最小新状态方案由 Root 核后才跑：自有合成项目、真实原 byte OS 锁、50/51前代元数据与回执明确录制、实际52九父/九backup/0new CAS；正常成功与未来0invoke、坏父0replace、partial replace IO中断自己回滚/foreign拒恢复其余。无需重50/51/store业务。当前 CAS/story/真实文件 apply 均 0。
