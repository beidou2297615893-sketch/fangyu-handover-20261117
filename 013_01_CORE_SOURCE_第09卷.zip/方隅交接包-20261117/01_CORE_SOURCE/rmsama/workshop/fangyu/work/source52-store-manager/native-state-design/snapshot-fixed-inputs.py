"""Read exact public Root sources and save owned snapshots; no code execution."""
import hashlib,json
from pathlib import Path
OWN=Path(__file__).resolve().parent/'execution'
PROJECT=Path('C:/积木软件工坊/项目/方隅公寓客户版');WORK=PROJECT/'work'
FIXED={
 'PREPARED52.json':('source52-root-integration/PREPARED.json',169430,'BF80D4F7E920C2F15D2FEBB4190C7516E9728595D04CD111CD30FD034CBB7B60'),
 'join-source52-reviewed.py':('source52-root-integration/join-source52-reviewed.py',30340,'55B81D09EA8A4E133631195F45EF9036A25BE7B6D64AA30DCCE48FCC25E08BCC'),
 'next_open_source52.py':('source52-root-integration/next_open_source52.py',15374,'CBD8C9A58CFA264DB403726BBC21C9047AFB3CDA42AAEC4F0E3DEFFA164CF81E'),
 'source_idle_guard.py':('source52-root-integration/source_idle_guard.py',5688,'A8B4475C9E0EB3FDB57C5CAE791A0D7953F432E434FE4F21AFB1C9D2B93DF398'),
 'source_next_open_launcher.py':('source52-root-integration/source_next_open_launcher.py',4897,'07545078E773134223590806A00A17DAB05B30EFFD75945C41FECED1322682E9'),
 'next_open_source.py':('desktop-self-use-entry/next_open_source.py',18590,'6DD31FBCB9864272C329C146DD7EA3E9F74F334131F84DDFEB5E3D63ED8BB611'),
 'next_open_source51.py':('desktop-self-use-entry/next_open_source51.py',14697,'8540B5A0AE7572E5C2DC8A550AD74BA0918FF931C09945E7F802E0FB00F6EEF0'),
 'join-source44-reviewed.py':('product-upgrade-20261009/audits/join-source44-reviewed.py',9601,'5F5E3EA22AF7C1FA0FEA71CFEFDA12A9D669C190D5470960901029BF8F4750FB')}
def pin(raw):return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest().upper()}
OWN.mkdir();snap=OWN/'snapshot';snap.mkdir();inputs=[]
for name,(relative,size,digest) in FIXED.items():
 source=WORK/relative;raw=source.read_bytes();assert pin(raw)=={'bytes':size,'sha256':digest},str(source)
 target=snap/name
 with target.open('xb') as stream:stream.write(raw)
 inputs.append({'source':str(source),'snapshot':str(target),'pin':pin(raw)})
business=WORK/'source52-store-manager/revision2/FROZEN.json';raw=business.read_bytes()
assert pin(raw)=={'bytes':20693,'sha256':'737719494423FEB5F5F928735264629188C7A94F24C19B7C680811480DB94517'}
with (snap/'BUSINESS52.json').open('xb') as stream:stream.write(raw)
inputs.append({'source':str(business),'snapshot':str(snap/'BUSINESS52.json'),'pin':pin(raw)})
with (OWN/'SNAPSHOT.json').open('x',encoding='utf-8') as stream:stream.write(json.dumps({'schema':'source52_native_exact_public_snapshots_v1','inputs':inputs,'Root_SOURCE_mutations':0,'process_or_App_calls':0},ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'snapshots':len(inputs),'CAS_executions':0,'Root_mutations':0}))
