# Source52：总部授予本店人员管理候选

这是独立待审代码候选，9 个既有目标，正式写入为 0；不修改 Source50/51 待合图、正常入口、生产共享开关或云部署。主服务父是已冻结 Source51 的 C4D44315… 候选，必须等待真实 Source51 成功回执及父字节吻合，由 Root 另行准备后继装载。不能直接以当前正式 service 为父合入。

复用现有 createService、公司与账号会话、同事务权威、成员密码与会话撤销、validateMemberChange 席位/门店额度、product_entitlements、原成员 UI、原生 Owner HTTPS/CSRF 通道及 employee gateway。保留 admin/operator/origin_partner 三个角色；没有把公司受信交接 acquisitionPolicy.managers 当作店长。Casbin 域权限只是 Root 已核过的设计参考，没有安装或集成 Casbin、新 enforcer 或策略库。

总部通过有效新成员能力与公司 scope 显式授予 operator 本店人员管理。可信字段 store_member_management 只由服务端生成，固定最终门店；新 grant 需 team。撤销、停用、转店或改角色清旧 grant；仅改密或普通维护保留同店有效 grant，不猜旧记录。经理只能新建/管理本店普通 operator 员工；不能管理自己、同级经理、总部、来源伙伴、跨店员工，不能转店、授予管理权限或扩大 can_reply。新员工 can_reply=false，已有员工保持原权限。总部旧无新字段客户端保原 upsert 兼容，新管理界面/经理请求强制 create/update 和服务端 scope stamp。

成员能力只来自当前范围的 fresh members 回包。前端绑定账号、公司、环境、epoch、actor 身份与服务器 scope stamp；读取前清除旧名单/编辑值，迟回、撤权、401 或范围切换不能恢复旧授权。未知保存保 hold，取消/旧编辑不能解除；仅当前范围接受的主动读回可解 hold，这不等于密码已核实。普通员工入口仍无管理授权，店级入口不开放 review、maintenance 或总部功能。

必要扩展由实际接缝证据驱动：7 个提案目标 → 第 8 个 employee_workspace.py，将 members/member_save 的真实网络、超时、5xx 等未知异常投影为 WorkspaceError 503/None，已证远端 4xx 用固定安全状态 → 第 9 个 local-transport.mjs，只修相同 bool 回包保持 actor 对象，以及 restore/login 返回一致 actor。登录 epoch、401 前端清 user/token、超时与零自动重试规则保持。401 不声称删除后端 DPAPI/Cookie，也不声称清掉 Owner 身份缓存。

最终新代表为 runs/c281b33405984ec6abdb3363a9b8a827/RESULT.json 及同目录 DOM-RESULT.json：正常原生 Owner HTTP/CSRF/Core/DPAPI → 真实 AppServer HTTP/employee gateway/WorkspaceCloud → scoped member UI。使用全新自有 SQLite/DPAPI、合成账号、显式 JSON SDK 事务适配器及本机 loopback 运输；GUI、真实平台/模型、生产 SDK、正式 App 和客户数据均为 0。生产 shared=false，未跑 Source50/51 旧业务矩阵。

RESULT 记录 8 个主因果步骤；新 native grant 缺 bool 回执门是 DOM 子步骤，不是第 9 个主事件。其精确运输/断言在 tests/cloud-fixture.cjs L19/L23 与 tests/dom-story.mjs L65–68；http-story.py L113 调用该子载体，L115 读取其成功结果。缺 bool 的实际 service 200 被运输删字段后，原生 Owner 返 503；不会把未知提交当成功或明确未提交。

差异见 candidate.diff，权限/接缝审查重点见 REVIEW-FOCUS.md，证据保留限制见 HISTORY-NOTE.md。FROZEN.json 绑定九个父/候选、公开代码依赖快照、当前载体和最终/历史结果。它不构成作者最终验收或实际合入授权；须由非作者审查。
