import hashlib,json,shutil
from pathlib import Path
OWN=Path(__file__).absolute().parent
PROJECT=Path('C:/积木软件工坊/项目/方隅公寓客户版')
WORK=PROJECT/'work';CANDIDATE=OWN/'candidate';RUNTIME=OWN/'runtime/app/src'
parents=json.loads((OWN/'PARENTS.json').read_bytes());base=json.loads((WORK/'source51-store-scope/FROZEN.json').read_bytes())
def pin(raw):return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest().upper()}
inputs=[]
for row in parents['targets']:
 source=Path(row['parent_source']);raw=source.read_bytes();assert pin(raw)==row['parent']
 target=CANDIDATE/'work'/Path(row['target']).relative_to(WORK);target.parent.mkdir(parents=True,exist_ok=True)
 with target.open('xb') as stream:stream.write(raw)
 inputs.append({'source':str(source),'copy':str(target),'pin':pin(raw),'target':row['target']})
for row in base['targets']+base['unchanged_public_dependencies']:
 source=Path(row.get('candidate',row.get('path')));proof=row.get('candidate_pin',row.get('pin'));raw=source.read_bytes();assert pin(raw)==proof
 relative=Path(row.get('target',row.get('path'))).relative_to(WORK)
 target=CANDIDATE/'work'/relative
 if not target.exists():target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw)
 inputs.append({'source':str(source),'copy':str(target),'pin':proof,'dependency':True})
stub=WORK/'source51-store-scope/candidate/node_modules/@cloudbase/node-sdk/index.js'
target=CANDIDATE/'node_modules/@cloudbase/node-sdk/index.js';target.parent.mkdir(parents=True);target.write_bytes(stub.read_bytes())
inputs.append({'source':str(stub),'copy':str(target),'pin':pin(target.read_bytes()),'synthetic_JSON_SDK_only':True})
# Copy only public Python source for actual Core/AppServer/DPAPI testing. No data,
# credentials, artifacts, platform runtime or private directory is copied.
for source in sorted((WORK/'app/src').rglob('*.py')):
 if any(x in ('node_modules','__pycache__','private','data') for x in source.parts):continue
 target=RUNTIME/source.relative_to(WORK/'app/src');target.parent.mkdir(parents=True,exist_ok=True);raw=source.read_bytes();target.write_bytes(raw)
 inputs.append({'source':str(source),'copy':str(target),'pin':pin(raw),'public_Python_dependency':True})
# AppServer is the immutable Source50 future baseline; owner/operator path does
# not invoke the pending Source51 owner/platform functions.
source=WORK/'overnight-commercial-20261014/source50-preparation/candidates/app/src/app.py'
assert pin(source.read_bytes())=={'bytes':126224,'sha256':'D9AB9A78923BAD556897EC5E70770FB6BF98493FBCC2E24EC8DD229F48C6E48E'}
target=RUNTIME/'app.py';target.write_bytes(source.read_bytes());inputs.append({'source':str(source),'copy':str(target),'pin':pin(target.read_bytes()),'Source50_future_baseline':True})
with (OWN/'INPUTS.json').open('x',encoding='utf-8') as stream:stream.write(json.dumps({'inputs':inputs,'formal_mutations':0},ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'candidate_targets':7,'public_inputs':len(inputs),'formal_mutations':0}))
