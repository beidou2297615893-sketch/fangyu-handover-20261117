"""Reuse new seam's exact app/module fixture; only recorded browser status is 401."""
from pathlib import Path
OWN=Path(__file__).resolve().parent
source=(OWN/'recovery-story.mjs').read_text('utf-8')
prefix=source[:source.index('const checks=[];')]
assert prefix.count('status=403;')==1
prefix=prefix.replace('status=403;','status=401;',1)
tail='''
try{
 const revoked=fixture({ordinary:true});await revoked.functions.checkDevelopmentIdentity(0);
 assert.equal(revoked.module.scope(),null);assert.equal(revoked.nav['team-tab'].hidden,true);
 assert.equal(revoked.d.list.children.length,0);assert.equal(revoked.d.fields.password.value,'');
 assert.equal(revoked.cloud.user,null);assert.equal(revoked.cloud.token,'');assert.equal(revoked.cloud.epoch,8);
 const result={status:'PASS',checks:[{check:'same app recovery seam fresh members 401 clears frontend identity and never restores old personnel capability',passed:true,calls:revoked.calls}],
  app_pin:pin(appRaw),module_pin:pin(moduleRaw),transport_pin:pin(transportRaw),carrier_pin:pin(carrierRaw),source_function_pin:pin(Buffer.from(source)),
  exact_app_function_bodies:true,normal_module_and_WorkspaceCloud:true,transport:'explicit synthetic browser 401 reply only',
  HTTP:false,GUI:false,DPAPI_deletion_claim:false,formal_mutations:0,prior_passed_branches_replayed:0};
 const output=path.join(run,'RESULT.json');fs.writeFileSync(output,JSON.stringify(result,null,2)+'\\n',{flag:'wx'});
 console.log(JSON.stringify({output,pin:pin(fs.readFileSync(output)),status:result.status}));
}catch(error){const output=path.join(run,'FIRST-FAIL.json');fs.writeFileSync(output,JSON.stringify({status:'FAIL',stack:error.stack,carrier_pin:pin(carrierRaw)},null,2)+'\\n',{flag:'wx'});throw error;}
'''
with (OWN/'recovery-401-story.mjs').open('x',encoding='utf-8',newline='\n') as stream:stream.write(prefix+tail)
