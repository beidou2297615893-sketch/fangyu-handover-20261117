'use strict';
const http=require('node:http'),path=require('node:path');
const {memoryDatabase}=require('./public-fixture.cjs');
const root=path.resolve(__dirname,'../candidate/work/cloud/workspace');
const {createService}=require(root+'/service.cjs'),{createStore}=require(root+'/index.js');
const ENV='fh6-d5ga45c0ddae7008c',COMPANY='fangyu-apartment-client',PASSWORD='[REDACTED:assigned_secret]';
const policy={package:'team',features:['team'],seat_limit:6,store_limit:3};
const service=createService({store:createStore(memoryDatabase(),COMPANY),environmentId:ENV,companyId:COMPANY,
 initialAdmin:'rmsama',initialPassword:PASSWORD,productAccessPolicy:policy,sharedFeatureEnabled:false});
let calls=[],legacy=false,badAck=false;
const server=http.createServer(async(req,res)=>{
 let raw='';for await(const part of req)raw+=part;let result;
 try{
  if(req.url==='/control/expire'){policy.expires_at=1;result={status:200,data:{fixture_expired:true}};}
  else if(req.url==='/control/restore'){delete policy.expires_at;result={status:200,data:{fixture_restored:true}};}
  else if(req.url==='/control/stats'){result={status:200,data:{calls}};}
  else if(req.url==='/control/legacy'){legacy=true;result={status:200,data:{synthetic_legacy_capability:true}};}
  else if(req.url==='/control/current'){legacy=false;result={status:200,data:{synthetic_current_capability:true}};}
  else if(req.url==='/control/bad-ack'){badAck=true;result={status:200,data:{synthetic_missing_grant_ack:true}};}
  else{const body=JSON.parse(raw),token=String(req.headers.authorization||'').replace(/^Bearer /,'');result=await service(body,token);
   calls.push({operation:body.operation,status:result.status,username:body.username||null,member_mode:body.member_mode||null});
   if(legacy&&body.operation==='members')delete result.data.member_management;
   if(badAck&&body.operation==='member_save'&&result.status===200){badAck=false;delete result.data.user.can_manage_store_members;}}
 }catch(error){result={status:503,data:{error:'synthetic fixture unavailable'}};}
 res.writeHead(result.status,{'Content-Type':'application/json'});res.end(JSON.stringify(result.data));
});
server.listen(0,'127.0.0.1',()=>process.stdout.write(JSON.stringify({origin:'http://127.0.0.1:'+server.address().port,SDK:'synthetic JSON transaction adapter',shared:false})+'\n'));
process.stdin.on('data',()=>server.close(()=>process.exit(0)));
