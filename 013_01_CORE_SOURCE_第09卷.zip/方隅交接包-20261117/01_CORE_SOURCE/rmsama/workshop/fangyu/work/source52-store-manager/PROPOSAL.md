Source52 的真实缺口是店长人员管理，不是新角色名称。Source51 冻结 service.cjs 的 members / member_save 仍仅允许 admin。唯一正常公开请求代表中，HQ member_save 提交 can_manage_store_members:true 得 200，但没有授予字段或能力；同账号重新登录仍 operator / store-a，其 members 返回 403。默认 shared=false，代表未发 list/publish。代码定位和该 RED_CODE_GAP 只证明缺口，不证明生产云泄露或授权成功。

使用已读取 codebase-design 的最小 module/interface/seam 判断：在既有当前公司事务的 members/member_save interface 内集中人员范围，不新建通用 enforcer、角色枚举、策略数据库或管理协议。继续复用 Root 已核 Casbin domain 思路；不重复外部研究，不声称安装 Casbin。

现可复用的实现：service.cjs 的企业 companyId、有效原 session 和 fresh user、scrypt、停用/改密会话撤销、member_mode 原子 create/update；product_entitlements.cjs 的 requireFeature('team')、validateMemberChange 的席位/门店与降级减量保护；Source51 validStore 与固定公司+门店模型。employee_workspace.py 已允许 members/member_save 的正常同源 gateway，凭据只在原 DPAPI/_cloud 通道；没有必要增加设备操作白名单。member-admin-ui.mjs 已有能力核对、create/update、400/401/403/409/429安全失败、未知结果需有效重新读取且 cancel/edit 不解除 hold。原生 Owner.call 每次真实 user()，原 CSRF/HTTPS/_cloud 固定通道均可复用。

实际入口缺件：

- Source51 service.cjs L240/245 为 admin-only，没有店级人员 grant 或返回管理范围。
- 两份 member-admin-ui.mjs L7/24 要求 admin 且 localWorkspace!=true。现角色仍 admin/operator/origin_partner，没有店长权限。
- workspace app.mjs L129 把本机 team 隐藏，L163 将本机 team 导航改回 tasks。原表单/团队页面已存在，可以窄复用。
- native Owner.call L128 白名单不接受 grant 字段；site/index.html L48 没有 HQ 授店长控件。
- acquisitionPolicy.managers 只属公司受信交接，不能拿来管理门店员工。Source51 来源共享范围也不自动授人员管理权。

建议权限语义（待 Root 按真实链核准，不先改业务候选）：

1. 角色保留 admin/operator/origin_partner。只有当前公司 admin 可通过 member_save 的显式布尔 can_manage_store_members 授予/撤销；服务端派生内部 grant 的 store_id 为最终 next.store_id，不接收客户端内部 grant/授权门店。仅 active operator + 有效非空门店可授。新 grant 使用原 requireFeature('team')；撤销不被降级/过期阻断。
2. 内部 grant 与授权时门店固定绑定。未授默认无权限；旧用户不推断、不迁移、不从标签或交接经理名单认领。HQ 转店/停用/改角色自动清旧 grant；想在新店授予须同次或之后再次显式 true，原 Source51 历史来源门店不迁。HQ 留空 flag 且门店/角色/启用状态不变时保原 grant，包括改密；不能因 createUser 改密重建漏掉 grant。
3. 店长仍普通 operator，仅在原当前会话内，每次成员读写 fresh 核 current store_id 与固定 grant 相等。本店可读 operator 名单，返回谁可编辑；只能创建/改密/停用本店普通员工。不可编辑自己、其他获授店长、admin、origin_partner；不能授管理权、换角色、转店或读取跨店成员。管理权不扩为平台/设备/HQ权。
4. 建议最窄不允许店长扩大 can_reply：现成员保持原值，新建普通员工默认 false，由 HQ 继续授回复权限。客户端角色/store/回复字段只可作为与服务端固定值相符的旧表单兼容值；任何不符拒。若 Root 选择店长也可授本店回复权，需要独立明示管理动作语义，不能顺手借 operator role 放大。
5. Store manager 所有写入必须显式 member_mode=create/update，不承接 legacy upsert。同名 create / 消失 update 保原 409，不重置旧密码。跨店或高权限同名冲突没有写；整次原事务拒。HQ 原自我停用/降权保护保持。新增/恢复使用原 validateMemberChange，全公司席位/店数计算；减量仍保成熟过期/降级维护能力，不重造收费/额度系统。
6. members 返回新的明确 member_management 能力版本及 scope（company 或 store、服务器固定 store_id、actor username、允许动作），兼容原 users/member_save_modes DTO。public user 仅额外投影布尔已授状态，不公开内部 grant。成员变更仍撤销该目标 access/remembered sessions，撤权或转店后旧 manager token 失效。服务端同事务重新授权，不靠浏览器/本机 30 秒身份缓存授予。
7. UI 只在有效当前 members 返回该 capability/scope 后启用。Scope/账号/企业/环境/epoch 变化清名单与表单，未知密码结果 hold 只由同当前范围的有效主动读取解除，不把名单当密码核实。写入携带预期 scope stamp 或服务器范围回显用于拒绝 stale form，服务端当前范围为权威、客户端字段不能授权。缺新能力的新 grant 保存必须只读拒绝；旧云即使忽略 flag，也不能称授店长已成功。
8. 不必改 integrations.py 以复制 grant 到本机身份：从 fresh members 能力学习本店入口，默认未知隐藏。普通 operator 的一次 members 403 是无该入口，不应弹权限错误或默认为已授。workspace app.mjs 只开放已核 team 的导航，review/maintenance/HQ企业设置继续原门禁；不放开 admin 登录原员工桌面。Owner 原管理员入口保持 HQ，可用同 module 新 checkbox。

预计 7 个既有 target，无新角色/SDK/enforcer/目录：

- cloud/workspace/service.cjs（父必须是 Source51 已冻 C4D44315…43A7D8，尚不能把当前正式旧 0DB1 当后继父）。
- app/src/web/workspace/member-admin-ui.mjs 与 owner-admin-20261004/site/member-admin-ui.mjs（两份同字节公共 module）。
- app/src/web/workspace/app.mjs、app/src/web/workspace/index.html（仅 team 入口与表单权限控件）。
- owner-admin-20261004/owner_admin.py、owner-admin-20261004/site/index.html（HQ新字段与新能力保存门、控件）。

预计不改 Owner site/owner-admin.mjs：它已有 module + 实核管理员上下文接线。预计不改 employee_workspace.py / integrations.py / product_entitlements.cjs / Source51 其他三件：现 gateway、HTTP错误与既有额度、店域工具已可复用。若实际正常 HTTP 代表证明需要字段投影或状态转换，先指出原因再缩小 delta，不能预先重构。

先验最难一条新链：自有正常 HQ 原生 HTTP/CSRF + createService 明示授权本店 operator → 该 operator 正常 employee gateway/transport + 复用 module 读本店/创建普通员工/停用或改密 → 另一店成员、HQ、合作来源、同级店长、自身、client grant/store/role spoof 拒，状态/原密码无写 → HQ 撤权/转店期间旧表单和原 token 拒；丢结果 UI 保 hold / 当前同店有效读取才解除。只该新 seam，保首唯一 RED/失败，SDK 为明示 JSON adapter，不重 store/shared/平台业务矩阵。默认共享关闭。

依赖必须后继 Source51：当前 50/51 payload 等正常下一开；本目录只读定位/合成 tracer，0正式变更。未来正式52必须 Root 依据真实 Source51 成功回执和新保护图准备，不修改原 50/51 图或靠本报告声称已加载。实际云/实体机/SDK/GUI/收费未授权未验证，R19 HQ经理全体系仍不能由本店人员管理一项替代。
