from pathlib import Path
OWN=Path(__file__).absolute().parent;PROJECT=Path('C:/积木软件工坊/项目/方隅公寓客户版')
tests=OWN/'tests';tests.mkdir(exist_ok=True)
raw=(PROJECT/'work/source51-store-scope/tests/public-fixture.cjs').read_text('utf-8')
raw=raw.replace("'../candidate/cloud/workspace'","'../candidate/work/cloud/workspace'",1).replace('module.exports={fixture,lead,ROOT};','module.exports={fixture,lead,ROOT,memoryDatabase};',1)
(tests/'public-fixture.cjs').write_text(raw,encoding='utf-8',newline='\n')
config={'id':'fangyu-apartment-client','name':'SYNTHETIC Source52 staff fixture','authMode':'managed',
 'platforms':['xiaohongshu'],'managedWorkspace':{'environment_id':'fh6-d5ga45c0ddae7008c','endpoint':'https://fixture-source52.invalid/workspace'}}
import json
path=OWN/'runtime/app/src/resources/companies/general.json';path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(config)+'\n',encoding='utf-8')
# Owner.__init__ derives its own PRIVATE from candidate __file__ and reuses real
# Core/DPAPI; Runtime public Python is placed in its import root, not formal SOURCE.
for source in (OWN/'runtime/app/src').rglob('*.py'):
 relative=source.relative_to(OWN/'runtime/app/src');target=OWN/'candidate/work/app/src'/relative
 if not target.exists():target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(source.read_bytes())
