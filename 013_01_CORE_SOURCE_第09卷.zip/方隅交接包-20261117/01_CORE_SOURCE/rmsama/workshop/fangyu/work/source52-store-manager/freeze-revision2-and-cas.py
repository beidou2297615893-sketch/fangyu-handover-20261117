"""Freeze owned recovery delta/composed nine and unauthorized CAS; no apply."""
import difflib,hashlib,json,subprocess
from pathlib import Path
OWN=Path(__file__).resolve().parent;WORK=OWN.parents[1]/'work'
def pin(raw):return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest().upper()}
def entry(path):return {'path':str(path),'pin':pin(path.read_bytes())}
def create(path,value):
    with path.open('x',encoding='utf-8',newline='\n') as stream:stream.write(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
base_raw=(OWN/'FROZEN.json').read_bytes();assert pin(base_raw)=={'bytes':20306,'sha256':'44446145C039640067278B2247A5ACAC6709753E6FA3DA7F836B63BFA20C3465'}
base=json.loads(base_raw);revision=OWN/'revision2';targets=[];delta=[];diff=[]
for old in base['targets']:
    source=Path(old['candidate']);before=source.read_bytes();assert pin(before)==old['candidate_pin']
    final=revision/'candidate/work'/Path(old['target']).relative_to(WORK);after=final.read_bytes()
    item=dict(old);item['candidate']=str(final);item['candidate_pin']=pin(after);targets.append(item)
    if before!=after:
        delta.append({'target':old['target'],'delta_parent':entry(source),'final':entry(final)})
        diff.extend(difflib.unified_diff(before.decode('utf-8').splitlines(True),after.decode('utf-8').splitlines(True),fromfile=str(source),tofile=str(final)))
assert len(targets)==9 and len(delta)==3
assert {Path(item['target']).relative_to(WORK).as_posix() for item in delta}=={
    'app/src/web/workspace/app.mjs','app/src/web/workspace/member-admin-ui.mjs','owner-admin-20261004/site/member-admin-ui.mjs'}
assert Path(targets[1]['candidate']).read_bytes()==Path(targets[2]['candidate']).read_bytes()
with (revision/'candidate.diff').open('x',encoding='utf-8',newline='\n') as stream:stream.writelines(diff)
syntax=[]
for path in (Path(targets[1]['candidate']),Path(targets[3]['candidate'])):
    result=subprocess.run(['node','--check',str(path)],capture_output=True,text=True,timeout=20)
    assert result.returncode==0,result.stderr;syntax.append({'path':str(path),'method':'node --check','status':'PASS'})
create(revision/'STATIC.json',{'checks':syntax,'identical_second_module_readback':True,'business_invocations':0,'formal_mutations':0})
evidence=[]
for run,name,expected_status in (
    ('79d100bc-7d97-41cc-8123-e22b18568291','FIRST-RED.json','RED_EXPECTED'),
    ('04cbaf9d-c1f8-4e94-96a0-54e102b88b34','RESULT.json','PASS'),
    ('cfe94d4d-5ca4-4b9d-85c7-cc94d6ce4bfa','RESULT.json','PASS')):
    root=revision/'runs'/run;result=json.loads((root/name).read_bytes());assert result['status']==expected_status
    item=entry(root/name);item['snapshot_files']=[entry(root/file) for file in ('app-snapshot.mjs','module-snapshot.mjs','transport-snapshot.mjs','carrier-snapshot.mjs')]
    for key,file in (('app_pin','app-snapshot.mjs'),('module_pin','module-snapshot.mjs'),('transport_pin','transport-snapshot.mjs'),('carrier_pin','carrier-snapshot.mjs')):
        assert result[key]==pin((root/file).read_bytes())
    if expected_status=='PASS':
        assert (root/'app-snapshot.mjs').read_bytes()==Path(targets[3]['candidate']).read_bytes()
        assert (root/'module-snapshot.mjs').read_bytes()==Path(targets[1]['candidate']).read_bytes()
    evidence.append(item)
create(revision/'FROZEN.json',{'schema':'source52_store_manager_candidate_revision_v1','revision':2,
    'join_authorized':False,'formal_mutations':0,'target_count':9,'existing_count':9,'new_count':0,
    'delta_count':3,'unchanged_first_candidates':6,'first_candidate_freeze':entry(OWN/'FROZEN.json'),
    'requires_non_author_delta_review':True,'requires_real_Source51_receipt_and_parent_readback':True,
    'targets':targets,'delta_targets':delta,'new_seam_evidence':evidence,
    'inherited_public_dependency_index':next(item for item in base['documents'] if Path(item['path']).name=='DEPENDENCIES.json'),
    'inherited_actual_HTTP_evidence_scope':'c281 is first-nine-byte evidence, not rerun with revision2 three new files',
    'inherited_final_main':base['final_main_result'],'inherited_final_DOM':base['final_DOM_result'],
    'documents':[entry(revision/file) for file in ('README.md','candidate.diff','STATIC.json','recovery-story.mjs','recovery-401-story.mjs','prepare-401-story.py')],
    'preparation':[entry(OWN/'prepare-revision2.py'),entry(OWN/'freeze-revision2-and-cas.py')],
    'boundaries':{'new_story':'exact original app recovery function bodies + normal module/transport, synthetic browser replies',
        'no_complete_app_import':True,'new_HTTP_runs':0,'GUI':False,'real_App_platform_model_SDK_calls':0,
        'prior_passed_branches_replayed_for_401_story':0,'old_c281_Source51_business_runs':0,
        'production_shared_switch_changed':False,'Source50_Source51_graph_entry_changes':0}})
cas=OWN/'cas-draft';script=cas/'join-source52-reviewed.py'
assert pin(script.read_bytes())=={'bytes':27414,'sha256':'2678AA33373EF0B166B05BCA562B134151F87F8E64FEFAE70CE56F1725E7772F'}
create(cas/'FROZEN.json',{'schema':'source52_root_cas_uninstalled_draft_v1','source_batch':52,
    'JOIN_AUTHORIZED':False,'BASE_MANIFEST_PIN':None,'no_empty_pin_can_apply':True,
    'target_count':9,'existing_count':9,'new_count':0,'backup_count':9,
    'first_nine_literal_requires_Root_revision2_final_rebinding':True,
    'cas_executed':False,'state_story_executed':False,'formal_mutations':0,
    'base_script':entry(WORK/'source51-root-cas-candidate/join-source51-reviewed.py'),
    'files':[entry(cas/file) for file in ('join-source52-reviewed.py','candidate.diff','CODE-SHAPE.json','README.md')],
    'preparation':entry(OWN/'prepare-cas-draft.py'),
    'final_business_revision':entry(revision/'FROZEN.json')})
print(json.dumps({'revision2':entry(revision/'FROZEN.json'),'delta':delta,'CAS':entry(cas/'FROZEN.json')},ensure_ascii=False))
