'use strict';
// Only the immutable Source51 public fixture is reused; no SOURCE/data access.
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const {fixture}=require('../source51-store-scope/tests/public-fixture.cjs');
const pin=raw=>({bytes:raw.length,sha256:crypto.createHash('sha256').update(raw).digest('hex').toUpperCase()});
async function main(){
 const f=await fixture({enabled:false});
 const attempted=await f.call('member_save',{username:'staff-a',role:'operator',store_id:'store-a',can_reply:false,
  member_mode:'update',can_manage_store_members:true},f.admin.token);
 const manager=await f.login('staff-a');
 const localMembers=await f.call('members',{},manager.token);
 const adminMembers=f.ok(await f.call('members',{},f.admin.token));
 const report={schema:'source52_manager_gap_public_tracer_v1',result:'RED_CODE_GAP',
  interface:'normal immutable Source51 createService + createStore JSON SDK transaction adapter',
  base_service_pin:pin(fs.readFileSync(path.resolve(__dirname,'../source51-store-scope/candidate/cloud/workspace/service.cjs'))),
  HQ_attempted_grant_status:attempted.status,HQ_reply_field_keys:Object.keys(attempted.data.user||{}),
  HQ_attempted_grant_returned:true===attempted.data.user?.can_manage_store_members,
  manager_role:manager.user.role,manager_store_id:manager.user.store_id,
  manager_normal_members_status:localMembers.status,manager_normal_members_error:localMembers.data.error,
  admin_members_status:200,admin_modes:adminMembers.member_save_modes,
  admin_has_store_management_capability:adminMembers.member_management!==undefined,
  cause:'HQ unknown grant field is ignored; operator normal members still admin-only. A role label/grant attempt does not confer staff management.',
  shared_enabled:false,shared_requests:0,formal_mutations:0,real_DB_or_Cookie_read:false,
  actual_cloud_platform_model_or_App_calls:0,old_QA_rerun:false};
 if(attempted.status!==200||report.HQ_attempted_grant_returned||localMembers.status!==403||manager.user.role!=='operator')
  throw Error('immutable baseline differs from expected narrow gap; review before continuing');
 const output=path.resolve(__dirname,'MANAGER-GAP-'+crypto.randomUUID()+'.json');
 fs.writeFileSync(output,JSON.stringify(report,null,2)+'\n',{flag:'wx'});
 console.log(JSON.stringify({path:output,pin:pin(fs.readFileSync(output)),result:report.result}));
}
main().catch(error=>{console.error(error.message);process.exitCode=1;});
