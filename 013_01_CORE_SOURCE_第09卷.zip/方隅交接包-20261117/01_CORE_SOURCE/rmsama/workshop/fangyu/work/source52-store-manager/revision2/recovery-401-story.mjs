// New recovery seam only: exact app function bodies + real module/transport;
// explicit synthetic browser replies and recorded device/task edges, no HTTP/GUI.
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import crypto from 'node:crypto';
import {fileURLToPath,pathToFileURL} from 'node:url';
const own=path.dirname(fileURLToPath(import.meta.url)),base=path.dirname(own);
const baseline=process.argv.includes('--baseline');
const sourceRoot=baseline?base:own;
const appPath=path.join(sourceRoot,'candidate/work/app/src/web/workspace/app.mjs');
const modulePath=path.join(sourceRoot,'candidate/work/app/src/web/workspace/member-admin-ui.mjs');
const transportPath=path.join(base,'candidate/work/app/src/web/workspace/local-transport.mjs');
const run=path.join(own,'runs',crypto.randomUUID());fs.mkdirSync(run,{recursive:true});
const pin=raw=>({bytes:raw.length,sha256:crypto.createHash('sha256').update(raw).digest('hex').toUpperCase()});
const appRaw=fs.readFileSync(appPath),moduleRaw=fs.readFileSync(modulePath),transportRaw=fs.readFileSync(transportPath),carrierRaw=fs.readFileSync(fileURLToPath(import.meta.url));
for(const [name,raw] of [['app-snapshot.mjs',appRaw],['module-snapshot.mjs',moduleRaw],['transport-snapshot.mjs',transportRaw],['carrier-snapshot.mjs',carrierRaw]])fs.writeFileSync(path.join(run,name),raw,{flag:'wx'});
const app=appRaw.toString('utf8');
const slice=(start,end)=>{const a=app.indexOf(start),b=app.indexOf(end,a+start.length);assert(a>=0&&b>a);return app.slice(a,b).trim();};
const source=[slice('function stopDevelopmentIdentityWatch(){','async function checkDevelopmentIdentity('),
 slice('async function checkDevelopmentIdentity(','function startDevelopmentIdentityWatch('),
 slice("async function refreshTeam(",'function syncMemberEntry('),
 slice('function syncMemberEntry(','async function probeMemberEntry('),
 slice('async function probeMemberEntry(','async function refreshMaintenance(')].join('\n');
const {WorkspaceCloud}=await import(pathToFileURL(transportPath));
class Element{
 constructor(tag='div'){this.tag=tag;this.children=[];this.dataset={};this.listeners={};this.textContent='';this.hidden=false;this.disabled=false;this.value='';this.checked=false;this.classes=new Set();this.classList={add:x=>this.classes.add(x),toggle:(x,on)=>on?this.classes.add(x):this.classes.delete(x)};}
 append(...children){for(const child of children){child.parent=this;this.children.push(child);}}replaceChildren(...children){this.children=[];this.append(...children);}
 addEventListener(type,fn){this.listeners[type]=fn;}focus(){}closest(tag){return this.parent?.tag===tag?this.parent:null;}toggleAttribute(key,value){if(key==='hidden')this.hidden=value;}
}
const doc={hidden:false,createElement:tag=>new Element(tag),querySelectorAll:()=>[]};globalThis.document=doc;
const {createMemberAdminUI}=await import(pathToFileURL(modulePath));
function dom(){
 const form=new Element('form'),save=new Element('button'),fields=Object.fromEntries(['username','password','role','store_id','can_reply','disabled','can_manage_store_members'].map(k=>[k,new Element('input')]));
 const grantLabel=new Element('label');grantLabel.append(fields.can_manage_store_members);form.elements={namedItem:k=>fields[k]};form.querySelector=()=>save;
 form.reset=()=>{for(const field of Object.values(fields)){field.value='';field.checked=false;}fields.role.value='operator';fields.can_reply.checked=true;};form.reset();
 return {form,fields,save,list:new Element(),count:new Element(),feedback:new Element(),title:new Element(),cancel:new Element('button'),passwordLabel:new Element(),disabledRow:new Element()};
}
function fixture({ordinary=false,late=false}={}){
 const username=ordinary?'staff-a':'manager-a',identity={id:'synthetic-manager-id',tenant_id:'synthetic-company',username,role:'operator'};
 const calls=[],edges=[],nav=Object.fromEntries(['team-tab','admin-nav','team-menu','review-tab','maintenance-tab'].map(k=>[k,Object.assign(new Element(),{hidden:true})]));
 let release=null;const environmentId='source52-recorded-env',companyId='source52-recorded-company';
 const dto={member_save_modes:['create','update'],member_management:{version:'store-members-v1',actor:{username,role:'operator'},scope:{type:'store',store_id:'store-a',stamp:'a'.repeat(64)},operations:['create','update']},users:[
  {username,role:'operator',store_id:'store-a',disabled:false,can_reply:false,can_manage_store_members:true,can_edit:false},
  {username:'staff-a',role:'operator',store_id:'store-a',disabled:false,can_reply:false,can_manage_store_members:false,can_edit:true}]};
 const fetcher=async(url,options)=>{
  const payload=JSON.parse(options.body).data;calls.push(payload.operation);
  let status=200,value;
  if(payload.operation==='me')value={user:identity,development_local_only:false};
  else if(payload.operation==='members'){
   if(ordinary){status=401;value={error:'synthetic ordinary staff has no grant'};}
   else{value={...dto,development_local_only:false};if(late)await new Promise(resolve=>release=resolve);}
  }else if(payload.operation==='member_save'){status=503;value={error:'synthetic unknown save reply',mutation_committed:null};}
  else throw Error('unexpected synthetic operation');
  return {ok:status===200,status,json:async()=>({contract:'fangyu-workspace-v1',environment_id:environmentId,company_id:companyId,...value})};
 };
 const cloud=new WorkspaceCloud({environmentId,companyId},fetcher);cloud.user={...identity,development_local_only:true};cloud.localOnly=true;cloud.token='local-session';cloud.epoch=7;
 const d=dom();let functions;
 const module=createMemberAdminUI({...d,call:(op,data)=>cloud.call(op,data),getContext:()=>({user:cloud.user,epoch:cloud.epoch,environmentId,companyId,localWorkspace:true}),onScope:s=>functions?.syncMemberEntry(s)});
 const context={cloud,document:{...doc,querySelectorAll:selector=>selector==='[data-menu-page="team"]'?[nav['team-menu']]:[]},memberAdmin:module,
  $:id=>nav[id],refreshDevices:async()=>edges.push('recorded refreshDevices'),refreshTasks:async()=>edges.push('recorded refreshTasks'),
  state:{selected:''},enterpriseWorkspace:{profile:()=>edges.push('recorded profile'),latest:()=>edges.push('recorded latest')},config:{localWorkspace:true},
  AbortController,clearInterval,developmentIdentityWatch:0,developmentIdentityGeneration:0,developmentIdentityClosing:false,developmentIdentityRequest:null};
 vm.createContext(context);functions=vm.runInContext(source+'\n({checkDevelopmentIdentity,probeMemberEntry,syncMemberEntry})',context);
 return {cloud,d,module,nav,calls,edges,functions,release:()=>release?.(),hasRelease:()=>!!release};
}

try{
 const revoked=fixture({ordinary:true});await revoked.functions.checkDevelopmentIdentity(0);
 assert.equal(revoked.module.scope(),null);assert.equal(revoked.nav['team-tab'].hidden,true);
 assert.equal(revoked.d.list.children.length,0);assert.equal(revoked.d.fields.password.value,'');
 assert.equal(revoked.cloud.user,null);assert.equal(revoked.cloud.token,'');assert.equal(revoked.cloud.epoch,8);
 const result={status:'PASS',checks:[{check:'same app recovery seam fresh members 401 clears frontend identity and never restores old personnel capability',passed:true,calls:revoked.calls}],
  app_pin:pin(appRaw),module_pin:pin(moduleRaw),transport_pin:pin(transportRaw),carrier_pin:pin(carrierRaw),source_function_pin:pin(Buffer.from(source)),
  exact_app_function_bodies:true,normal_module_and_WorkspaceCloud:true,transport:'explicit synthetic browser 401 reply only',
  HTTP:false,GUI:false,DPAPI_deletion_claim:false,formal_mutations:0,prior_passed_branches_replayed:0};
 const output=path.join(run,'RESULT.json');fs.writeFileSync(output,JSON.stringify(result,null,2)+'\n',{flag:'wx'});
 console.log(JSON.stringify({output,pin:pin(fs.readFileSync(output)),status:result.status}));
}catch(error){const output=path.join(run,'FIRST-FAIL.json');fs.writeFileSync(output,JSON.stringify({status:'FAIL',stack:error.stack,carrier_pin:pin(carrierRaw)},null,2)+'\n',{flag:'wx'});throw error;}
