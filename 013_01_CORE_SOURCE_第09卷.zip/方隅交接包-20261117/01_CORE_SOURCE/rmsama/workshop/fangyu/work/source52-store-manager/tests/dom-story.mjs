// Public module and unchanged WorkspaceCloud with actual owned AppServer HTTP.
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {pathToFileURL} from 'node:url';
import {WorkspaceCloud} from './local-transport-candidate.mjs';
const p=JSON.parse(fs.readFileSync(process.argv[2],'utf8'));
const {createMemberAdminUI}=await import(pathToFileURL(p.module));
class Element{
 constructor(tag='div'){this.tag=tag;this.children=[];this.dataset={};this.listeners={};this.textContent='';this.hidden=false;this.disabled=false;this.value='';this.checked=false;this.classes=new Set();this.classList={add:x=>this.classes.add(x),toggle:(x,on)=>on?this.classes.add(x):this.classes.delete(x)};}
 append(...children){for(const child of children){child.parent=this;this.children.push(child);}}replaceChildren(...children){this.children=[];this.append(...children);}
 addEventListener(type,fn){this.listeners[type]=fn;}focus(){this.focused=true;}closest(tag){return this.parent?.tag===tag?this.parent:null;}toggleAttribute(key,value){if(key==='hidden')this.hidden=value;}
}
globalThis.document={createElement:tag=>new Element(tag)};
function dom(){
 const form=new Element('form'),save=new Element('button'),fields=Object.fromEntries(['username','password','role','store_id','can_reply','disabled','can_manage_store_members'].map(k=>[k,new Element('input')]));
 const grantLabel=new Element('label');grantLabel.append(fields.can_manage_store_members);
 form.elements={namedItem:k=>fields[k]};form.querySelector=()=>save;
 form.reset=()=>{for(const field of Object.values(fields)){field.value='';field.checked=false;}fields.role.value='operator';fields.can_reply.checked=true;};form.reset();
 return {form,fields,save,grantLabel,list:new Element(),count:new Element(),feedback:new Element(),title:new Element(),cancel:new Element('button'),passwordLabel:new Element(),disabledRow:new Element()};
}
let cookie=p.cookie,delay=null,delayRelease=null,seen=[],scopeEvents=[],resetCount=0;
const browser=async(url,options)=>{
 const data=options.body?JSON.parse(options.body):null;
 const reply=await fetch(new URL(url,p.origin),{...options,headers:{...options.headers,Origin:p.origin,Cookie:cookie}});
 if(reply.headers.get('set-cookie'))cookie=reply.headers.get('set-cookie').split(';')[0];
 seen.push({operation:data?.data?.operation,status:reply.status});
 if(delay&&data?.data?.operation==='members'){delay=null;await new Promise(resolve=>delayRelease=resolve);}
 return reply;
};
const cloud=new WorkspaceCloud({environmentId:p.environment_id,companyId:p.company_id,onSessionExpired:()=>resetCount++},browser);
const restored=await cloud.restore();assert.equal(cloud.user.role,'operator');assert.equal(restored,cloud.user);
const context={companyId:p.company_id,environmentId:p.environment_id,localWorkspace:true};
const d=dom(),ui=createMemberAdminUI({...d,call:(op,data)=>cloud.call(op,data),getContext:()=>({...context,user:cloud.user,epoch:cloud.epoch}),onScope:scope=>scopeEvents.push(scope)});
const submit=()=>d.form.listeners.submit({preventDefault(){}});
const edit=name=>d.list.children.find(row=>row.children[0]?.children[0]?.textContent===name).children[2].onclick();
const check=(name,values={})=>checks.push({check:name,passed:true,...values});
const checks=[];
await ui.load();assert.equal(ui.scope().type,'store');assert.equal(ui.scope().store_id,'store-a');
assert.equal(d.fields.role.disabled,true);assert.equal(d.fields.store_id.disabled,true);assert.equal(d.fields.can_reply.disabled,true);assert.equal(d.grantLabel.hidden,true);
for(const name of ['manager-a','manager-peer'])assert.equal(d.list.children.find(row=>row.children[0]?.children[0]?.textContent===name).children[2].disabled,true);
check('operator module accepts actual scoped DTO, only editable ordinary staff, no role/store/reply/grant lift');
d.fields.username.value='new-staff-a';d.fields.password.value='synthetic-new-staff-password';await submit();
assert.match(d.feedback.textContent,/已创建 new-staff-a/);assert.equal(d.fields.password.value,'');
let roster=await cloud.call('members');const created=roster.users.find(row=>row.username==='new-staff-a');assert.equal(created.can_reply,false);assert.equal(created.can_manage_store_members,false);assert.equal(created.store_id,'store-a');
check('normal manager UI creates own-store nonreply ordinary staff through unchanged WorkspaceCloud');
await ui.load();edit('staff-a');d.fields.password.value='synthetic-DOM-new-password';
await fetch(p.loss_control+'/loss',{method:'POST'});const before=seen.filter(x=>x.operation==='member_save').length;await submit();
assert.equal(seen.at(-1).status,503);assert.equal(d.save.disabled,true);assert.match(d.feedback.textContent,/结果未确认/);assert.equal(d.fields.password.value,'');
await submit();d.cancel.listeners.click();edit('staff-a');await submit();assert.equal(seen.filter(x=>x.operation==='member_save').length,before+1);assert.equal(d.save.disabled,true);
check('real committed response loss maps 503/unknown and cancel/old edit/submit hold with one write');
await ui.load();assert.equal(d.save.disabled,false);assert.match(d.feedback.textContent,/密码.*未独立核实/);
check('only fresh accepted current-scope members read releases unknown, without password verification claim');
// A real read can complete late, but not restore grant after current epoch changes.
delay=true;const pending=ui.load().catch(()=>false);while(!delayRelease)await new Promise(r=>setImmediate(r));cloud.epoch++;delayRelease();await pending;
assert.equal(ui.scope(),null);assert.equal(d.save.disabled,true);assert.equal(d.list.children.length,0);assert.equal(d.fields.password.value,'');
check('late members response cannot restore scope/navigation/editor after epoch change');
await ui.load();edit('staff-a');const writesBefore=seen.filter(x=>x.operation==='member_save').length;context.companyId='different-synthetic-company';await submit();assert.equal(seen.filter(x=>x.operation==='member_save').length,writesBefore);assert.equal(d.fields.password.value,'');context.companyId=p.company_id;
check('stale company/scope editor never writes');
// New HQ form and direct POST gate reject a server without the new capability.
const hqCall=async(op,data={})=>{const reply=await fetch(p.hq_origin+'/api/cloud',{method:'POST',headers:{'Content-Type':'application/json',...p.hq_headers},body:JSON.stringify({operation:op,data})});const value=await reply.json();if(!reply.ok)throw Object.assign(Error(value.error),{status:reply.status});return value;};
const hd=dom(),hqActor={username:'rmsama',role:'admin'},hqUI=createMemberAdminUI({...hd,call:hqCall,getContext:()=>({user:hqActor,epoch:0,companyId:p.company_id,environmentId:p.environment_id,localWorkspace:false})});
await hqUI.load();const peer=hd.list.children.find(row=>row.children[0]?.children[0]?.textContent==='manager-peer');peer.children[2].onclick();assert.equal(hd.fields.can_manage_store_members.checked,true);
await hd.form.listeners.submit({preventDefault(){}});assert.match(hd.feedback.textContent,/已更新 manager-peer/);
check('HQ form actual true grant return boolean validates, original same grant retained');
await fetch(p.cloud_origin+'/control/bad-ack',{method:'POST',body:'{}'});
const ackScope=await hqCall('members');
try{await hqCall('member_save',{username:'manager-peer',role:'operator',store_id:'store-a',can_manage_store_members:true,member_mode:'update',member_scope_stamp:ackScope.member_management.scope.stamp});assert.fail('missing bool ack accepted');}catch(error){assert.equal(error.status,503);}
check('native direct new grant POST refuses 200 remote missing boolean ack as unknown after commit');
const cap=await hqCall('members'),stamp=cap.member_management.scope.stamp;
await fetch(p.cloud_origin+'/control/legacy',{method:'POST',body:'{}'});
const stats=async()=>await (await fetch(p.cloud_origin+'/control/stats',{method:'POST',body:'{}'})).json();
const count=(await stats()).calls.filter(x=>x.operation==='member_save').length;
await hqUI.load();assert.equal(hd.save.disabled,true);hd.fields.username.value='staff-b';hd.fields.role.value='operator';hd.fields.can_manage_store_members.checked=true;await hd.form.listeners.submit({preventDefault(){}});
try{await hqCall('member_save',{username:'staff-b',role:'operator',store_id:'store-b',can_manage_store_members:true,member_mode:'update',member_scope_stamp:stamp});assert.fail('manual grant accepted legacy service');}catch(error){assert.equal(error.status,409);}
assert.equal((await stats()).calls.filter(x=>x.operation==='member_save').length,count);
check('missing new capability disables UI and native handwritten grant POST before any remote save');
await fetch(p.cloud_origin+'/control/current',{method:'POST',body:'{}'});
const liveHQ=await hqCall('members');
await hqCall('member_save',{username:'manager-a',role:'operator',store_id:'store-a',can_manage_store_members:false,member_mode:'update',member_scope_stamp:liveHQ.member_management.scope.stamp});
const epochBefore=cloud.epoch;
try{await ui.load();assert.fail('revoked session accepted');}catch(error){assert.equal(error.status,401);}
assert.equal(cloud.user,null);assert.equal(cloud.token,'');assert.equal(cloud.epoch,epochBefore+1);assert.equal(resetCount,1);assert.equal(ui.scope(),null);assert.equal(d.list.children.length,0);assert.equal(d.fields.password.value,'');
check('actual revoked-session 401 clears frontend user/token/epoch and stale personnel values, not DPAPI deletion');
const renewHQ=await hqCall('members');
await hqCall('member_save',{username:'manager-a',role:'operator',store_id:'store-a',can_manage_store_members:true,member_mode:'update',member_scope_stamp:renewHQ.member_management.scope.stamp});
const logged=await cloud.login('manager-a','synthetic-source52-password-123');assert.equal(logged,cloud.user);
const stableActor=cloud.user;await cloud.call('members');assert.equal(cloud.user,stableActor);await ui.load();assert.equal(ui.scope().type,'store');
check('login/restore return current actor and same-bool HTTP replies preserve identity with fresh scope only');
const result={schema:'source52_scoped_member_DOM_v1',status:'PASS',checks,HTTP:seen,scope_callback_count:scopeEvents.length,
 actual_member_DTO_validator:true,actual_WorkspaceCloud_response_validator:true,actual_Owner_HTTP:true,
 frontend_epoch_change:true,'401_frontend_reset_count':resetCount,GUI:false,platform_model_calls:0,formal_mutations:0};
fs.writeFileSync(p.output,JSON.stringify(result,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({status:'PASS',checks:checks.length}));
