'use strict';
const path=require('node:path');
const assert=require('node:assert/strict');
const ROOT=path.resolve(__dirname,'../candidate/work/cloud/workspace');
const {createService}=require(path.join(ROOT,'service.cjs'));
const {createStore}=require(path.join(ROOT,'index.js'));
const clone=x=>x===undefined?undefined:structuredClone(x);
function memoryDatabase(){
 let docs=new Map(),tail=Promise.resolve(),afterQuery=null;
 const operations=[];
 const database={command:{lt:value=>({lt:value})},operations,
  afterSharedQuery(fn){afterQuery=fn;},
  seedV2(company){const key='fangyu_workspace_private:'+company;const value=clone(docs.get(key));
   value.state.sharedLeadsMode='v2';value.state.sharedLeadSequence=0;delete value.state.items;docs.set(key,value);},
  mutateCompany(company,fn){const key='fangyu_workspace_private:'+company;const value=clone(docs.get(key));fn(value.state);docs.set(key,value);},
  collection:name=>collection(name,()=>docs),
  runTransaction:fn=>{const work=tail.then(async()=>{const staged=new Map([...docs].map(([k,v])=>[k,clone(v)]));
   const value=await fn({collection:name=>collection(name,()=>staged)});docs=staged;return value;});tail=work.catch(()=>{});return work;}}
 function collection(name,map){return {
  doc:id=>({get:async()=>{operations.push({operation:'get',collection:name,id});return {data:clone(map().get(name+':'+id))||null};},
   set:async value=>{operations.push({operation:'set',collection:name,id});map().set(name+':'+id,clone(value));}}),
  where:filters=>({orderBy:(field,direction)=>({limit:limit=>({get:async()=>{
   operations.push({operation:'query',collection:name,filters:clone(filters),field,direction,limit});
   const data=[...map().entries()].filter(([key])=>key.startsWith(name+':')).map(([,value])=>clone(value))
    .filter(row=>Object.entries(filters).every(([key,value])=>value&&typeof value==='object'&&Object.hasOwn(value,'lt')?row[key]<value.lt:row[key]===value))
    .sort((a,b)=>direction==='desc'?b[field]-a[field]:a[field]-b[field]).slice(0,limit);
   if(name==='fangyu_shared_leads'&&afterQuery){const fn=afterQuery;afterQuery=null;await fn();}
   return {data};}})})})};}
 return database;
}
const ENV='synthetic-source51-env',COMPANY='fangyu-apartment-client',PASSWORD='[REDACTED:assigned_secret]';
async function fixture({v2=false,enabled=true}={}){
 const db=memoryDatabase(),store=createStore(db,COMPANY);
 const options={store,companyId:COMPANY,environmentId:ENV,initialAdmin:'hq-admin',initialPassword:PASSWORD,
  productAccessPolicy:{package:'team',features:['acquisition','intent_analysis','export','handoff','strategy','team'],
   seat_limit:5,store_limit:3,analysis_quota:null,billing_period:'pilot'}};
 if(enabled!==undefined)options.sharedFeatureEnabled=enabled;
 const service=createService(options),call=(operation,data={},token='')=>service({environment_id:ENV,operation,...data},token);
 const ok=response=>{assert.equal(response.status,200,JSON.stringify(response.data));return response.data;};
 const admin=ok(await call('login',{username:'hq-admin',password:PASSWORD}));
 for(const [username,store_id] of [['staff-a','store-a'],['colleague-a','store-a'],['staff-b','store-b']])
  ok(await call('member_save',{username,password:PASSWORD,role:'operator',store_id,member_mode:'create',can_reply:false},admin.token));
 const login=async username=>ok(await call('login',{username,password:PASSWORD}));
 const a=await login('staff-a'),peer=await login('colleague-a'),b=await login('staff-b');
 if(v2)db.seedV2(COMPANY);
 return {db,store,service,call,ok,admin,a,peer,b,login,COMPANY};
}
const lead=name=>({platform:'xiaohongshu',source_id:'synthetic-source51-'+name,
 text:'synthetic '+name,url:'https://www.xiaohongshu.com/explore/0123456789abcdef01234567'});
module.exports={fixture,lead,ROOT,memoryDatabase};
