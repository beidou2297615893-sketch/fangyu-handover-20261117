from pathlib import Path
OWN=Path(__file__).absolute().parent
path=OWN/'candidate/work/cloud/workspace/service.cjs'
source=path.read_text('utf-8')
old="const publicUser = u => ({username: u.username, role: u.role, disabled: !!u.disabled, can_reply: u.can_reply !== false,\n  ...(u.store_id?{store_id:u.store_id}:{})});"
new="""const validMemberStore=value=>typeof value==='string'&&/^[A-Za-z0-9_-]{1,80}$/.test(value);
const memberGrant=u=>!!u&&!u.disabled&&u.role==='operator'&&validMemberStore(u.store_id)
  &&u.store_member_management?.version==='store-members-v1'&&u.store_member_management.store_id===u.store_id
  &&typeof u.store_member_management.granted_by==='string'&&!!u.store_member_management.granted_by;
const publicUser = u => ({username: u.username, role: u.role, disabled: !!u.disabled, can_reply: u.can_reply !== false,
  ...(u.store_id?{store_id:u.store_id}:{}),can_manage_store_members:memberGrant(u)});
function memberScope(user,sessionDigest,companyId){
  if(user.role!=='admin'&&!memberGrant(user))return null;
  const type=user.role==='admin'?'company':'store',store_id=type==='store'?user.store_id:'';
  return {version:'store-members-v1',actor:{username:user.username,role:user.role},
    scope:{type,store_id,stamp:hash(JSON.stringify([companyId,user.username,user.role,store_id,
      user.store_member_management||null,sessionDigest]))},operations:['create','update']};
}
const memberCanEdit=(scope,actor,row)=>scope.scope.type==='company'||row.role==='operator'
  &&row.store_id===scope.scope.store_id&&row.username!==actor.username&&!memberGrant(row);"""
assert old in source;source=source.replace(old,new,1)
start=source.index("        if (payload.operation === 'members') {")
end=source.index("        if (payload.operation === 'publish') {",start)
source=source[:start]+"""        if (payload.operation === 'members') {
          const management=memberScope(user,session.digest,companyId);
          if(!management)return finish(403,{error:'没有当前门店人员管理权限',mutation_committed:false});
          const rows=management.scope.type==='company'?state.users:state.users.filter(row=>row.role==='operator'&&row.store_id===management.scope.store_id);
          return finish(200,{users:rows.map(row=>({...publicUser(row),can_edit:memberCanEdit(management,user,row)})),
            member_save_modes:['create','update'],member_management:management});
        }
        if (payload.operation === 'member_save') {
          const management=memberScope(user,session.digest,companyId);
          if(!management)return finish(403,{error:'没有当前门店人员管理权限',mutation_committed:false});
          const manager=management.scope.type==='store';
          if(['store_member_management','member_management','can_edit','member_management_scope'].some(key=>Object.hasOwn(payload,key)))
            return finish(400,{error:'人员管理授权只能由服务器建立',mutation_committed:false});
          const newInterface=manager||Object.hasOwn(payload,'member_scope_stamp')||Object.hasOwn(payload,'can_manage_store_members');
          if(newInterface&&(payload.member_scope_stamp!==management.scope.stamp||!['create','update'].includes(payload.member_mode)))
            return finish(409,{error:'当前人员管理范围已变化，请重新读取成员',mutation_committed:false});
          const {username,password,role}=payload;validateUsername(username);
          if(!['admin','operator','origin_partner'].includes(role))throw new Error('角色无效');
          if(username===user.username&&(payload.disabled||role!=='admin'))throw new Error('不能停用自己或取消自己的管理员权限');
          const previous=state.users.find(row=>row.username===username);
          if(payload.member_mode!==undefined&&!['create','update'].includes(payload.member_mode))return finish(400,{error:'成员操作方式无效',mutation_committed:false});
          if(payload.member_mode==='create'&&previous)return finish(409,{error:'用户名已存在，请从成员名单选择编辑；本次没有修改账号',mutation_committed:false});
          if(payload.member_mode==='update'&&!previous)return finish(409,{error:'原成员已不存在，请刷新成员名单；本次没有创建账号',mutation_committed:false});
          if(manager){
            if(role!=='operator'||username===user.username||Object.hasOwn(payload,'can_manage_store_members')
              ||previous&&!memberCanEdit(management,user,previous)
              ||Object.hasOwn(payload,'store_id')&&payload.store_id!==management.scope.store_id
              ||Object.hasOwn(payload,'can_reply')&&payload.can_reply!==(previous?previous.can_reply!==false:false))
              return finish(403,{error:'仅能管理本店普通员工，不能修改授权、角色、门店或回复权限',mutation_committed:false});
          }
          if(previous&&((previous.role==='origin_partner')!==(role==='origin_partner')))throw new Error('合作来源与员工身份不能互相转换');
          if(Object.hasOwn(payload,'can_manage_store_members')&&typeof payload.can_manage_store_members!=='boolean')throw new Error('人员管理授权格式无效');
          let next=previous?{...previous,role,disabled:payload.disabled===true}:createUser(username,password,role);
          if(previous&&password)next={...createUser(username,password,role),disabled:payload.disabled===true};
          if(payload.can_reply!==undefined&&typeof payload.can_reply!=='boolean')throw new Error('回复权限格式无效');
          next.can_reply=manager?(previous?previous.can_reply!==false:false):payload.can_reply===undefined?previous?.can_reply!==false:payload.can_reply;
          next.store_id=manager?management.scope.store_id:payload.store_id===undefined?previous?.store_id||'':payload.store_id;
          if(role==='origin_partner'){
            if(payload.can_reply===true||payload.store_id)throw new Error('合作来源没有回复或门店权限');
            next={...next,access_class:'owner_origin_only',can_reply:false,store_id:'',account_version:(previous?.account_version||0)+1};
          }
          delete next.store_member_management;
          if(!manager&&payload.can_manage_store_members===true){
            if(role!=='operator'||next.disabled||!validMemberStore(next.store_id))throw new Error('仅可授予已启用且绑定门店的员工');
            if(!memberGrant(previous)||previous.store_id!==next.store_id)productEntitlements.requireFeature('team');
            next.store_member_management={version:'store-members-v1',store_id:next.store_id,granted_by:user.username};
          }else if(!manager&&payload.can_manage_store_members===undefined&&memberGrant(previous)
            &&role==='operator'&&!next.disabled&&next.store_id===previous.store_id){
            next.store_member_management={...previous.store_member_management};
          }
          productEntitlements.validateMemberChange(state,next);
          if(!previous&&state.users.length>=100)throw new Error('当前部署支持最多 100 位成员');
          state.users=state.users.filter(row=>row.username!==username).concat(next);
          state.sessions=state.sessions.filter(row=>row.username!==username);
          state.rememberedDevices=state.rememberedDevices.filter(row=>row.username!==username);
          audit(user.username,'member_save');return finish(200,{user:publicUser(next),member_management:management});
        }
"""+source[end:]
path.write_text(source,encoding='utf-8',newline='\n')
