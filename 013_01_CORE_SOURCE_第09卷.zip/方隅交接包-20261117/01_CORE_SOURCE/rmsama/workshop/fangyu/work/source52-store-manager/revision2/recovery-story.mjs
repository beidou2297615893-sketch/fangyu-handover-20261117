// New recovery seam only: exact app function bodies + real module/transport;
// explicit synthetic browser replies and recorded device/task edges, no HTTP/GUI.
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import crypto from 'node:crypto';
import {fileURLToPath,pathToFileURL} from 'node:url';
const own=path.dirname(fileURLToPath(import.meta.url)),base=path.dirname(own);
const baseline=process.argv.includes('--baseline');
const sourceRoot=baseline?base:own;
const appPath=path.join(sourceRoot,'candidate/work/app/src/web/workspace/app.mjs');
const modulePath=path.join(sourceRoot,'candidate/work/app/src/web/workspace/member-admin-ui.mjs');
const transportPath=path.join(base,'candidate/work/app/src/web/workspace/local-transport.mjs');
const run=path.join(own,'runs',crypto.randomUUID());fs.mkdirSync(run,{recursive:true});
const pin=raw=>({bytes:raw.length,sha256:crypto.createHash('sha256').update(raw).digest('hex').toUpperCase()});
const appRaw=fs.readFileSync(appPath),moduleRaw=fs.readFileSync(modulePath),transportRaw=fs.readFileSync(transportPath),carrierRaw=fs.readFileSync(fileURLToPath(import.meta.url));
for(const [name,raw] of [['app-snapshot.mjs',appRaw],['module-snapshot.mjs',moduleRaw],['transport-snapshot.mjs',transportRaw],['carrier-snapshot.mjs',carrierRaw]])fs.writeFileSync(path.join(run,name),raw,{flag:'wx'});
const app=appRaw.toString('utf8');
const slice=(start,end)=>{const a=app.indexOf(start),b=app.indexOf(end,a+start.length);assert(a>=0&&b>a);return app.slice(a,b).trim();};
const source=[slice('function stopDevelopmentIdentityWatch(){','async function checkDevelopmentIdentity('),
 slice('async function checkDevelopmentIdentity(','function startDevelopmentIdentityWatch('),
 slice("async function refreshTeam(",'function syncMemberEntry('),
 slice('function syncMemberEntry(','async function probeMemberEntry('),
 slice('async function probeMemberEntry(','async function refreshMaintenance(')].join('\n');
const {WorkspaceCloud}=await import(pathToFileURL(transportPath));
class Element{
 constructor(tag='div'){this.tag=tag;this.children=[];this.dataset={};this.listeners={};this.textContent='';this.hidden=false;this.disabled=false;this.value='';this.checked=false;this.classes=new Set();this.classList={add:x=>this.classes.add(x),toggle:(x,on)=>on?this.classes.add(x):this.classes.delete(x)};}
 append(...children){for(const child of children){child.parent=this;this.children.push(child);}}replaceChildren(...children){this.children=[];this.append(...children);}
 addEventListener(type,fn){this.listeners[type]=fn;}focus(){}closest(tag){return this.parent?.tag===tag?this.parent:null;}toggleAttribute(key,value){if(key==='hidden')this.hidden=value;}
}
const doc={hidden:false,createElement:tag=>new Element(tag),querySelectorAll:()=>[]};globalThis.document=doc;
const {createMemberAdminUI}=await import(pathToFileURL(modulePath));
function dom(){
 const form=new Element('form'),save=new Element('button'),fields=Object.fromEntries(['username','password','role','store_id','can_reply','disabled','can_manage_store_members'].map(k=>[k,new Element('input')]));
 const grantLabel=new Element('label');grantLabel.append(fields.can_manage_store_members);form.elements={namedItem:k=>fields[k]};form.querySelector=()=>save;
 form.reset=()=>{for(const field of Object.values(fields)){field.value='';field.checked=false;}fields.role.value='operator';fields.can_reply.checked=true;};form.reset();
 return {form,fields,save,list:new Element(),count:new Element(),feedback:new Element(),title:new Element(),cancel:new Element('button'),passwordLabel:new Element(),disabledRow:new Element()};
}
function fixture({ordinary=false,late=false}={}){
 const username=ordinary?'staff-a':'manager-a',identity={id:'synthetic-manager-id',tenant_id:'synthetic-company',username,role:'operator'};
 const calls=[],edges=[],nav=Object.fromEntries(['team-tab','admin-nav','team-menu','review-tab','maintenance-tab'].map(k=>[k,Object.assign(new Element(),{hidden:true})]));
 let release=null;const environmentId='source52-recorded-env',companyId='source52-recorded-company';
 const dto={member_save_modes:['create','update'],member_management:{version:'store-members-v1',actor:{username,role:'operator'},scope:{type:'store',store_id:'store-a',stamp:'a'.repeat(64)},operations:['create','update']},users:[
  {username,role:'operator',store_id:'store-a',disabled:false,can_reply:false,can_manage_store_members:true,can_edit:false},
  {username:'staff-a',role:'operator',store_id:'store-a',disabled:false,can_reply:false,can_manage_store_members:false,can_edit:true}]};
 const fetcher=async(url,options)=>{
  const payload=JSON.parse(options.body).data;calls.push(payload.operation);
  let status=200,value;
  if(payload.operation==='me')value={user:identity,development_local_only:false};
  else if(payload.operation==='members'){
   if(ordinary){status=403;value={error:'synthetic ordinary staff has no grant'};}
   else{value={...dto,development_local_only:false};if(late)await new Promise(resolve=>release=resolve);}
  }else if(payload.operation==='member_save'){status=503;value={error:'synthetic unknown save reply',mutation_committed:null};}
  else throw Error('unexpected synthetic operation');
  return {ok:status===200,status,json:async()=>({contract:'fangyu-workspace-v1',environment_id:environmentId,company_id:companyId,...value})};
 };
 const cloud=new WorkspaceCloud({environmentId,companyId},fetcher);cloud.user={...identity,development_local_only:true};cloud.localOnly=true;cloud.token='local-session';cloud.epoch=7;
 const d=dom();let functions;
 const module=createMemberAdminUI({...d,call:(op,data)=>cloud.call(op,data),getContext:()=>({user:cloud.user,epoch:cloud.epoch,environmentId,companyId,localWorkspace:true}),onScope:s=>functions?.syncMemberEntry(s)});
 const context={cloud,document:{...doc,querySelectorAll:selector=>selector==='[data-menu-page="team"]'?[nav['team-menu']]:[]},memberAdmin:module,
  $:id=>nav[id],refreshDevices:async()=>edges.push('recorded refreshDevices'),refreshTasks:async()=>edges.push('recorded refreshTasks'),
  state:{selected:''},enterpriseWorkspace:{profile:()=>edges.push('recorded profile'),latest:()=>edges.push('recorded latest')},config:{localWorkspace:true},
  AbortController,clearInterval,developmentIdentityWatch:0,developmentIdentityGeneration:0,developmentIdentityClosing:false,developmentIdentityRequest:null};
 vm.createContext(context);functions=vm.runInContext(source+'\n({checkDevelopmentIdentity,probeMemberEntry,syncMemberEntry})',context);
 return {cloud,d,module,nav,calls,edges,functions,release:()=>release?.(),hasRelease:()=>!!release};
}
const checks=[];
try{
 const normal=fixture();await normal.functions.probeMemberEntry();assert.equal(normal.calls.length,0);assert.equal(normal.nav['team-tab'].hidden,true);
 await normal.functions.checkDevelopmentIdentity(0);
 if(baseline){
  assert.equal(normal.nav['team-tab'].hidden,true);assert.equal(normal.calls.filter(x=>x==='members').length,0);
  const result={status:'RED_EXPECTED',reason:'development identity recovered but app never probes fresh personnel capability; hidden entry remains',calls:normal.calls,
   app_pin:pin(appRaw),module_pin:pin(moduleRaw),transport_pin:pin(transportRaw),carrier_pin:pin(carrierRaw),source_function_pin:pin(Buffer.from(source)),GUI:false,HTTP:false,formal_mutations:0};
  const output=path.join(run,'FIRST-RED.json');fs.writeFileSync(output,JSON.stringify(result,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify({output,pin:pin(fs.readFileSync(output)),status:result.status}));
 }else{
  assert.equal(normal.cloud.user.development_local_only,false);assert.equal(normal.calls.filter(x=>x==='members').length,1);
  assert.equal(normal.module.scope().type,'store');for(const key of ['team-tab','admin-nav','team-menu'])assert.equal(normal.nav[key].hidden,false);
  for(const key of ['review-tab','maintenance-tab'])assert.equal(normal.nav[key].hidden,true);
  checks.push({check:'exact app identity recovery probes once and fresh store scope reveals only personnel entries',passed:true,calls:normal.calls});
  const held=fixture();held.cloud.user={...held.cloud.user,development_local_only:false};held.cloud.localOnly=false;await held.module.load();
  held.d.list.children.find(row=>row.children[0]?.children[0]?.textContent==='staff-a').children[2].onclick();held.d.fields.password.value='synthetic-unknown-password';
  await held.d.form.listeners.submit({preventDefault(){}});assert.equal(held.d.save.disabled,true);assert.match(held.d.feedback.textContent,/结果未确认/);
  held.cloud.user={...held.cloud.user,development_local_only:true};held.cloud.localOnly=true;await held.functions.checkDevelopmentIdentity(0);
  assert.equal(held.module.scope().type,'store');assert.equal(held.nav['team-tab'].hidden,false);assert.equal(held.d.save.disabled,true);
  held.module.reset();await held.d.form.listeners.submit({preventDefault(){}});assert.equal(held.calls.filter(x=>x==='member_save').length,1);
  await held.module.load();assert.equal(held.d.save.disabled,false);assert.match(held.d.feedback.textContent,/密码.*未独立核实/);
  checks.push({check:'automatic recovery read preserves unknown hold and makes explicit fresh read reachable; no write replay',passed:true,calls:held.calls});
  const late=fixture({late:true});const pending=late.functions.checkDevelopmentIdentity(0);
  while(!late.hasRelease())await new Promise(resolve=>setImmediate(resolve));late.cloud.epoch++;late.release();await pending;
  assert.equal(late.module.scope(),null);assert.equal(late.nav['team-tab'].hidden,true);assert.equal(late.d.list.children.length,0);
  checks.push({check:'late recovery capability cannot restore entry after epoch changes',passed:true,calls:late.calls});
  const staff=fixture({ordinary:true});await staff.functions.checkDevelopmentIdentity(0);assert.equal(staff.module.scope(),null);assert.equal(staff.nav['team-tab'].hidden,true);
  checks.push({check:'ordinary operator 403 fresh read keeps personnel and HQ entries hidden',passed:true,calls:staff.calls});
  const result={status:'PASS',checks,app_pin:pin(appRaw),module_pin:pin(moduleRaw),transport_pin:pin(transportRaw),carrier_pin:pin(carrierRaw),source_function_pin:pin(Buffer.from(source)),
   exact_app_function_bodies:true,normal_module_and_WorkspaceCloud:true,transport:'explicit synthetic browser replies',device_task_edges:'recorded, not invoked',
   no_complete_app_import:true,HTTP:false,GUI:false,platform_model_SDK_calls:0,formal_mutations:0,old_business_story_runs:0};
  const output=path.join(run,'RESULT.json');fs.writeFileSync(output,JSON.stringify(result,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify({output,pin:pin(fs.readFileSync(output)),status:result.status}));
 }
}catch(error){const output=path.join(run,'FIRST-FAIL.json');fs.writeFileSync(output,JSON.stringify({status:'FAIL',stack:error.stack,carrier_pin:pin(carrierRaw)},null,2)+'\n',{flag:'wx'});throw error;}
