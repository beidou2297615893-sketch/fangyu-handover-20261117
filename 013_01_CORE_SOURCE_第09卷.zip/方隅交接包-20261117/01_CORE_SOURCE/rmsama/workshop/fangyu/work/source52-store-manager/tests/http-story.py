"""One new personnel HTTP/CSRF/Core/DPAPI story, synthetic transport only."""
import hashlib,http.client,importlib.util,json,os,shutil,subprocess,sys,threading,traceback,uuid
from pathlib import Path
from unittest.mock import patch
from urllib.request import Request,build_opener
from urllib.error import URLError
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
OWN=Path(__file__).resolve().parents[1];RUN=OWN/'runs'/uuid.uuid4().hex;RUN.mkdir(parents=True)
SRC=OWN/'runtime/app/src';sys.dont_write_bytecode=True;sys.path.insert(0,str(SRC))
PORTS=set()
def fence(event,args):
 if event=='socket.connect' and (args[1][0]!='127.0.0.1' or args[1][1] not in PORTS):raise PermissionError('only owned loopback transport')
 if event=='socket.getaddrinfo' and args[0] not in ('127.0.0.1','localhost'):raise PermissionError('no external DNS')
 if event=='sqlite3.connect' and not Path(args[0]).resolve().is_relative_to(OWN):raise PermissionError('no original customer database')
sys.addaudithook(fence)
from app import AppServer
import integrations
from assistant import employee_workspace
def pin(raw):return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest().upper()}
events=[];wire=[];loss={'pending':False};servers=[];node=None
def checkpoint(name,**values):events.append({'step':name,'passed':True,**values});print(name,flush=True)
def request(origin,path='/',data=None,headers=None,method='POST'):
 port=int(origin.rsplit(':',1)[1]);conn=http.client.HTTPConnection('127.0.0.1',port,timeout=15)
 try:
  headers=dict(headers or {});headers.setdefault('Origin',origin)
  if data is not None:headers.setdefault('Content-Type','application/json')
  conn.request(method,path,json.dumps(data) if data is not None else None,headers);answer=conn.getresponse();raw=answer.read()
  return answer.status,dict(answer.getheaders()),json.loads(raw) if answer.getheader('Content-Type','').startswith('application/json') else raw
 finally:conn.close()
def run():
 global node
 baseline='--baseline-loss' in sys.argv
 node=subprocess.Popen(['node',str(OWN/'tests/cloud-fixture.cjs')],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
 line=node.stdout.readline()
 if not line:raise RuntimeError('owned Node fixture did not initialize: '+node.stderr.read()[-2500:])
 cloud_origin=json.loads(line)['origin'];PORTS.add(int(cloud_origin.rsplit(':',1)[1]))
 portal=RUN/'portal/work/owner-admin-20261004';portal.mkdir(parents=True)
 shutil.copyfile(OWN/'candidate/work/owner-admin-20261004/owner_admin.py',portal/'owner_admin.py')
 (portal/'site').mkdir()
 for name in ('index.html','member-admin-ui.mjs'):shutil.copyfile(OWN/'candidate/work/owner-admin-20261004/site'/name,portal/'site'/name)
 spec=importlib.util.spec_from_file_location('owned_source52_portal',portal/'owner_admin.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
 ordinary_open=build_opener(integrations.NoRedirect())
 class OwnedLoopback:
  def open(self,req,timeout):
   assert req.full_url in (m.ENDPOINT,'https://fixture-source52.invalid/workspace')
   payload=json.loads(req.data);wire.append({'operation':payload['operation'],'username':payload.get('username'),
    'password_present':'password' in payload})
   reply=ordinary_open.open(Request(cloud_origin,data=req.data,headers=dict(req.header_items()),method=req.get_method()),timeout=timeout)
   if loss['pending'] and payload['operation']=='member_save' and payload.get('username')=='staff-a' and payload.get('password'):
    assert reply.status==200;reply.read();reply.close();loss['pending']=False
    raise URLError('synthetic response lost after actual service commit')
   return reply
 with patch.object(integrations,'build_opener',lambda *args:OwnedLoopback()):
  owner=m.Owner();assert owner.bootstrap('synthetic-source52-password-123')['authorized'] is True
  hq=m.Server(owner);servers.append(hq);PORTS.add(hq.server_port);thread=threading.Thread(target=hq.serve_forever,daemon=True);thread.start()
  hq_origin=hq.origin
  status,headers,auth=request(hq_origin,'/api/bootstrap',{'launch':hq.launch});assert status==200
  hq_headers={'Cookie':headers['Set-Cookie'].split(';')[0],'X-Fangyu-CSRF':auth['csrf'],'Origin':hq_origin}
  def admin(op,data=None):return request(hq_origin,'/api/cloud',{'operation':op,'data':data or {}},hq_headers)
  def members():
   status,_,value=admin('members');assert status==200;return value
  def change(data):
   data={**data,'member_scope_stamp':members()['member_management']['scope']['stamp']}
   status,_,value=admin('member_save',data);return status,value
  for username,store,grant,reply in [('manager-a','store-a',True,False),('manager-peer','store-a',True,False),('staff-a','store-a',False,True),('staff-b','store-b',False,False)]:
   status,row=change({'username':username,'password':'[REDACTED:assigned_secret]','role':'operator','store_id':store,'can_reply':reply,'can_manage_store_members':grant,'member_mode':'create'})
   assert status==200 and row['user']['can_manage_store_members'] is grant
  checkpoint('HQ normal Owner user/CSRF/Core/DPAPI grants only operator fixed store')
  # Normal AppServer on fresh owned data, no platform runtime started.
  server=AppServer(('127.0.0.1',0),RUN/'employee-data',employee_workspace=True);servers.append(server);PORTS.add(server.server_port)
  threading.Thread(target=server.serve_forever,daemon=True).start();origin='http://127.0.0.1:'+str(server.server_port)
  cookie=''
  def employee(op,data=None,extra=None):
   nonlocal cookie
   status,headers,value=request(origin,'/api',{'action':'desktop_workspace','data':{'operation':op,**(data or {})}},
    {'X-Local-App':'1','Cookie':cookie,**(extra or {})})
   if 'Set-Cookie' in headers:cookie=headers['Set-Cookie'].split(';')[0]
   return status,value
  status,value=employee('login',{'username':'manager-a','password':'[REDACTED:assigned_secret]'});assert status==200 and value['user']['role']=='operator' and cookie
  status,roster=employee('members');assert status==200
  assert roster['member_management']['scope']['type']=='store' and roster['member_management']['scope']['store_id']=='store-a'
  assert {r['username'] for r in roster['users']}=={'manager-a','manager-peer','staff-a'}
  assert all(type(r['can_edit']) is bool and type(r['can_manage_store_members']) is bool for r in roster['users'])
  assert next(r for r in roster['users'] if r['username']=='staff-a')['can_edit'] is True
  assert next(r for r in roster['users'] if r['username']=='manager-peer')['can_edit'] is False
  checkpoint('normal AppServer operator login/gateway and fresh scoped DTO pass actual projections')
  scope=roster['member_management']['scope']['stamp'];loss['pending']=True
  status,lost=employee('member_save',{'username':'staff-a','role':'operator','store_id':'store-a','can_reply':True,'password':'[REDACTED:assigned_secret]','member_mode':'update','member_scope_stamp':scope})
  assert loss['pending'] is False
  # Independent public login confirms the synthetic remote write committed;
  # roster readability itself is never claimed as password verification.
  status_login,_,public_login=request(cloud_origin,data={'operation':'login','environment_id':m.ENV,'username':'staff-a','password':'[REDACTED:assigned_secret]'})
  assert status_login==200 and public_login['user']['role']=='operator'
  if baseline:
   assert status==400
   result={'status':'RED_EXPECTED_NEW_UNKNOWN_503','actual_member_HTTP_status':status,'expected_new_status':503,
    'real_commit_confirmed_by_independent_synthetic_login':True,'gateway_baseline_pin':pin((SRC/'assistant/employee_workspace.py').read_bytes()),
    'cause':'original IntegrationError(ValueError) is collapsed by App generic 400; new UI treats 400 as known rejection'}
  else:
   assert status==503 and lost['mutation_committed'] is None
   checkpoint('actual commit then transport loss becomes unknown 503/None, no automatic retry')
   class LossControl(BaseHTTPRequestHandler):
    def log_message(self,*args):pass
    def do_POST(self):
     if self.path!='/loss':self.send_error(404);return
     loss['pending']=True;raw=b'{"owned_transport_loss_armed":true}'
     self.send_response(200);self.send_header('Content-Type','application/json');self.send_header('Content-Length',str(len(raw)));self.end_headers();self.wfile.write(raw)
   control=ThreadingHTTPServer(('127.0.0.1',0),LossControl);servers.append(control);PORTS.add(control.server_port)
   threading.Thread(target=control.serve_forever,daemon=True).start()
   # Reuse the real employee transport and candidate DOM module through owned HTTP.
   launch=RUN/'DOM-INPUT.json';launch.write_text(json.dumps({'origin':origin,'cookie':cookie,'hq_origin':hq_origin,'hq_headers':hq_headers,'cloud_origin':cloud_origin,'loss_control':'http://127.0.0.1:'+str(control.server_port),'module':str(OWN/'candidate/work/app/src/web/workspace/member-admin-ui.mjs'),
    'environment_id':m.ENV,'company_id':m.COMPANY,'output':str(RUN/'DOM-RESULT.json')})+'\n',encoding='utf-8')
   dom=subprocess.run(['node',str(OWN/'tests/dom-story.mjs'),str(launch)],capture_output=True,text=True,timeout=45,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
   if dom.returncode:raise RuntimeError('owned DOM failed: '+dom.stderr[-3000:])
   assert json.loads((RUN/'DOM-RESULT.json').read_bytes())['status']=='PASS';checkpoint('actual WorkspaceCloud + DTO module DOM scope/unknown/late response story')
   status,_=employee('login',{'username':'manager-a','password':'[REDACTED:assigned_secret]'});assert status==200
   # Safe rejection and grant persistence/expiry are exercised once at the same interface.
   scope=employee('members')[1]['member_management']['scope']['stamp']
   for name,data in [('other-store',{'username':'staff-b'}),('peer-manager',{'username':'manager-peer'}),('self',{'username':'manager-a'}),('admin',{'username':'rmsama','role':'admin'}),('grant-spoof',{'username':'staff-a','can_manage_store_members':True}),('store-spoof',{'username':'staff-a','store_id':'store-b'}),('reply-escalation',{'username':'new-staff-a','can_reply':True})]:
    payload={'username':'staff-a','role':'operator','store_id':'store-a','can_reply':True,'member_mode':'update','member_scope_stamp':scope,**data}
    refused,_=employee('member_save',payload);assert refused in (403,409), (name,refused)
   checkpoint('cross-store/self/peer/HQ/grant/store/reply spoof writes refused')
   status,row=change({'username':'manager-a','role':'operator','store_id':'store-a','password':'[REDACTED:assigned_secret]','member_mode':'update'})
   assert status==200 and row['user']['can_manage_store_members'] is True
   status,_=employee('members');assert status==401
   status,login=employee('login',{'username':'manager-a','password':'[REDACTED:assigned_secret]'});assert status==200
   status,value=employee('members');assert status==200 and value['member_management']['scope']['type']=='store'
   checkpoint('HQ password reset retains lawful grant and revoked old cloud session returns 401')
   request(cloud_origin,'/control/expire',{})
   status,value=employee('members');assert status==200
   status,_=employee('member_save',{'username':'staff-a','role':'operator','store_id':'store-a','can_reply':True,'disabled':True,'member_mode':'update','member_scope_stamp':value['member_management']['scope']['stamp']});assert status==200
   status,_=change({'username':'staff-b','role':'operator','store_id':'store-b','can_manage_store_members':True,'member_mode':'update'});assert status==403
   status,row=change({'username':'manager-a','role':'operator','store_id':'store-a','can_manage_store_members':False,'member_mode':'update'});assert status==200 and row['user']['can_manage_store_members'] is False
   status,_=employee('members');assert status==401
   checkpoint('expired safe roster/deactivation/revoke remain, new grant denied, old manager session invalid')
   request(cloud_origin,'/control/restore',{})
   status,row=change({'username':'manager-a','role':'operator','store_id':'store-a','can_manage_store_members':True,'member_mode':'update'});assert status==200 and row['user']['can_manage_store_members'] is True
   status,row=change({'username':'manager-a','role':'operator','store_id':'store-b','member_mode':'update'});assert status==200 and row['user']['can_manage_store_members'] is False
   status,_=employee('login',{'username':'manager-a','password':'[REDACTED:assigned_secret]'});assert status==200
   status,_=employee('members');assert status==403
   checkpoint('HQ transfer without new explicit grant does not migrate old personnel grant')
   result={'status':'PASS','events':events,'wire':wire,'normal_AppServer_HTTP':True,'normal_Owner_HTTP_CSRF':True,'actual_Core_SQLite_DPAPI_owned_only':True,
    'SDK':'synthetic JSON adapter','shared':False,'shared_requests':0,'platform_model_GUI_real_App_calls':0,'formal_mutations':0,
    '401_frontend_reset_only_not_DPAPI_deletion':True,'employee_gateway_pin':pin((SRC/'assistant/employee_workspace.py').read_bytes())}
  result['run']=str(RUN);result['carrier_pin']=pin(Path(__file__).read_bytes())
  out=RUN/('FIRST-RED.json' if baseline else 'RESULT.json')
  with out.open('x',encoding='utf-8') as stream:stream.write(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
  print(json.dumps({'path':str(out),'pin':pin(out.read_bytes()),'status':result['status']}))
try:run()
except BaseException:
 with (RUN/'FIRST-FAIL.json').open('x',encoding='utf-8') as stream:stream.write(json.dumps({'status':'FAIL','traceback':traceback.format_exc()},ensure_ascii=False,indent=2)+'\n')
 raise
finally:
 for server in reversed(servers):server.shutdown();server.server_close()
 if node is not None and node.poll() is None:
  node.stdin.write('stop\n');node.stdin.flush();node.wait(timeout=5)
