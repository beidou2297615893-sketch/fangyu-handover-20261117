# 本轮失败与载体历史说明

原 PROPOSAL/PARENTS/FROZEN-PROPOSAL 不覆盖，反映七目标方案，随后 Root 根据真实接缝分别核准第八、第九目标。PARENTS-8/9 也是当时输入，不把其中 code_implementation_started=false 旧提案字段冒成最终状态。

所有本轮实际 FIRST-FAIL/FIRST-RED 留在唯一 run 目录，不覆写：020dae… 是 fixture 缺 site/assets、业务前退出；157c16… 是原 employee gateway 实际已提交丢响应仍变 400 的首 RED；9ea227… 是 DOM 载体属性名引号语法错误；06ee4e… 是旧 local-transport 相同 bool 回包重建 actor，fresh UI scope 为 null。原旧 transport 全字节保存在 parents/work/app/src/web/workspace/local-transport.mjs 与 tests/local-transport.mjs。首 RED 记录原 gateway 与当时主 carrier pin。

f016844… 是九件首次正常 HTTP+DOM 因果通过。d738adb… 后继新增实际撤权 401 前端 user/token/epoch reset、restore/login actor 一致性与 HQ 转店不迁旧 grant；c281b33… 后继新增原生 Owner direct grant 回执 bool/scope 校验及运输删除真实 service200 的 bool 回包后本机503未知断言。各 run 的原 RESULT/DOM-RESULT 保留。

主 RESULT 中 carrier_pin 是当时 http-story.py 的 pin；d7 与 c281 主 carrier 均 13837/CEC219588576EF64BB5047F6D270F6A072FA64EFA2AD1B7EBE7912BC701C6894，8 条 events 相同。新增 c281 断言真实在 tests/dom-story.mjs L65–68，由 tests/cloud-fixture.cjs L19/L23 只改运输回包；c281 DOM-RESULT 第8 check 独立记录通过，不能把主 events 未变当成新 seam 已单独记录。

限制：旧 f0/d7 DOM/cloud 子载体原字节与当时 SHA 未完整单独留存，首 RED 原主载体后续也增量编辑了，不能声称完整保留所有运行当时的全部载体。保留的真实结果、当时主 carrier pin、首旧 transport 和当前冻结载体各有其含义。当前载体 SHA 在 FROZEN 中标明冻结时读取；不补造历史 SHA，也不重跑已过故事来替代旧证据。c281 当前 DOM/cloud 文件 mtime 早于其 DOM-RESULT，这仅是时序佐证，不能取代运行时内容签名。

本轮未重跑旧矩阵或真实业务；迭代故事仅用于必要新修正与新边界。真实 SDK/GUI/账号/部署仍未验，生产 shared=false，0 正式变更。
