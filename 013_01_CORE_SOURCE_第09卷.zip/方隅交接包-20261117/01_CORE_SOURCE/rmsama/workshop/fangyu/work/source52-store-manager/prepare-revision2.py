"""Preserve first nine candidates; prepare only the reviewed recovery seam delta."""
import hashlib,json
from pathlib import Path
OWN=Path(__file__).resolve().parent;WORK=OWN.parents[1]/'work'
def pin(raw):return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest().upper()}
raw=(OWN/'FROZEN.json').read_bytes()
assert pin(raw)=={'bytes':20306,'sha256':'44446145C039640067278B2247A5ACAC6709753E6FA3DA7F836B63BFA20C3465'}
frozen=json.loads(raw);revision=OWN/'revision2';revision.mkdir()
for item in frozen['targets']:
    source=Path(item['candidate']);data=source.read_bytes();assert pin(data)==item['candidate_pin']
    target=revision/'candidate/work'/Path(item['target']).relative_to(WORK)
    target.parent.mkdir(parents=True,exist_ok=True)
    with target.open('xb') as stream:stream.write(data)
app=revision/'candidate/work/app/src/web/workspace/app.mjs'
text=app.read_text('utf-8')
assert text.count('  cloud.user=value.user;')==1
text=text.replace('  cloud.user=value.user;','  cloud.user={...value.user,development_local_only:false};\n  await probeMemberEntry(sameSession);\n  if(!sameSession())return;',1)
before='async function probeMemberEntry(){try{return await refreshTeam();}catch{return false;}}'
after="async function probeMemberEntry(accept=()=>true){try{return await memberAdmin?.probe('',accept);}catch{return false;}}"
assert text.count(before)==1;text=text.replace(before,after,1)
app.write_text(text,encoding='utf-8',newline='\n')
for relative in ('app/src/web/workspace/member-admin-ui.mjs','owner-admin-20261004/site/member-admin-ui.mjs'):
    path=revision/'candidate/work'/relative;text=path.read_text('utf-8')
    before="async function load(highlight='',accept=()=>true,internal=false){"
    after="async function load(highlight='',accept=()=>true,internal=false,releaseUnknown=true){"
    assert text.count(before)==1;text=text.replace(before,after,1)
    before='const held=needsRead;if(modesVerified)needsRead=false;if(held&&modesVerified)say('
    after='const held=needsRead;if(modesVerified&&releaseUnknown)needsRead=false;if(held&&modesVerified&&releaseUnknown)say('
    assert text.count(before)==1;text=text.replace(before,after,1)
    before='return {load,reset,scope:()=>writable()?{...management.scope}:null};'
    after="return {load,probe:(highlight='',accept=()=>true)=>load(highlight,accept,false,false),reset,scope:()=>writable()?{...management.scope}:null};"
    assert text.count(before)==1;text=text.replace(before,after,1)
    path.write_text(text,encoding='utf-8',newline='\n')
print(json.dumps({'revision':str(revision),'existing_targets':9,'changed_targets':3,'business_runs':0,'formal_mutations':0},ensure_ascii=False))
