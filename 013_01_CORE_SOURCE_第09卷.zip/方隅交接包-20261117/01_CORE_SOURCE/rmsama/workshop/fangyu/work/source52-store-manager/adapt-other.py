import hashlib,json,re
from pathlib import Path
OWN=Path(__file__).absolute().parent;C=OWN/'candidate';PROJECT=Path('C:/积木软件工坊/项目/方隅公寓客户版')
def pin(raw):return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest().upper()}
for rel in ('work/app/src/web/workspace/index.html','work/owner-admin-20261004/site/index.html'):
 path=C/rel;s=path.read_text('utf-8');match=re.search(r'<form id="member".*?</form>',s,re.S);assert match
 form=match.group().replace('</form>','<label class="check-label"><input name="can_manage_store_members" type="checkbox">授予本店人员管理（仅已绑定门店员工）</label></form>')
 s=s[:match.start()]+form+s[match.end():];path.write_text(s,encoding='utf-8',newline='\n')
path=C/'work/owner-admin-20261004/owner_admin.py';s=path.read_text('utf-8')
s=s.replace("'disabled','member_mode'}","'disabled','member_mode','can_manage_store_members','member_scope_stamp'}",1)
needle="                capability=self.integrations._cloud(config,user,'members').get('member_save_modes')"
assert needle in s;s=s.replace(needle,"                members=self.integrations._cloud(config,user,'members')\n                capability=members.get('member_save_modes')",1)
needle="            if operation=='maintenance_pending':"
added="""                if 'can_manage_store_members' in data or 'member_scope_stamp' in data:
                    management=members.get('member_management')
                    scope=management.get('scope') if isinstance(management,dict) else None
                    actor=management.get('actor') if isinstance(management,dict) else None
                    if (not isinstance(scope,dict) or not isinstance(actor,dict)
                            or management.get('version')!='store-members-v1'
                            or actor.get('username')!=user['username'] or actor.get('role')!='admin'
                            or scope.get('type')!='company' or scope.get('store_id')!=''
                            or not isinstance(scope.get('stamp'),str) or not re.fullmatch(r'[a-f0-9]{64}',scope['stamp'])
                            or data.get('member_scope_stamp')!=scope['stamp']
                            or 'can_manage_store_members' in data and type(data['can_manage_store_members']) is not bool):
                        error=IntegrationError('当前人员管理服务或范围需重新核对，当前可只读')
                        error.code='OWNER_MEMBER_SERVICE_UPDATE_REQUIRED';error.http_status=409
                        raise error
"""
assert needle in s;s=s.replace(needle,added+needle,1);path.write_text(s,encoding='utf-8',newline='\n')
path=C/'work/app/src/web/workspace/app.mjs';s=path.read_text('utf-8')
s=s.replace("$('team-tab').hidden=!adminAllowed;","$('team-tab').hidden=!memberAdmin?.scope();",1)
needle="for(const item of document.querySelectorAll('.admin-menu-item'))item.hidden=!adminAllowed;"
assert needle in s;s=s.replace(needle,needle+"syncMemberEntry(memberAdmin?.scope());",1)
needle="if(config.localWorkspace&&['review','team','maintenance'].includes(name))name='tasks'"
assert needle in s;s=s.replace(needle,"if(config.localWorkspace&&(['review','maintenance'].includes(name)||name==='team'&&memberAdmin?.scope()?.type!=='store'))name='tasks'",1)
needle="async function refreshTeam(highlightUsername='',accept=()=>true){return memberAdmin?.load(highlightUsername,accept);}"
assert needle in s;s=s.replace(needle,needle+"\nfunction syncMemberEntry(scope){const allowed=!!scope&&!!cloud.user&&(scope.type==='store'&&cloud.user.role==='operator'||scope.type==='company'&&!config.localWorkspace&&cloud.user.role==='admin');$('team-tab').hidden=!allowed;for(const item of document.querySelectorAll('[data-menu-page=\"team\"]'))item.hidden=!allowed;}\nasync function probeMemberEntry(){try{return await refreshTeam();}catch{return false;}}",1)
needle=" void enterpriseWorkspace?.profile();void enterpriseWorkspace?.latest();\n}"
assert needle in s;s=s.replace(needle," void enterpriseWorkspace?.profile();void enterpriseWorkspace?.latest();\n await probeMemberEntry();\n}",1)
needle="call:(operation,data)=>cloud.call(operation,data),getContext:()=>({user:cloud.user,epoch:cloud.epoch,companyId:config.companyId,environmentId:config.environmentId,localWorkspace:config.localWorkspace===true})});"
assert needle in s;s=s.replace(needle,needle[:-3]+",onScope:syncMemberEntry});",1)
path.write_text(s,encoding='utf-8',newline='\n')
# The eighth target is explicitly authorized by Root after the real ValueError
# seam was located; all other gateway actions are unchanged.
source=PROJECT/'work/app/src/assistant/employee_workspace.py';raw=source.read_bytes();path=C/'work/app/src/assistant/employee_workspace.py';path.parent.mkdir(parents=True,exist_ok=True)
s=raw.decode('utf-8');needle='    return public(_cloud(server, user, operation, data))'
assert s.count(needle)==1
new="""    if operation in ('members','member_save'):
        try:
            return public(_cloud(server,user,operation,data))
        except IntegrationError as error:
            statuses={400:'人员配置未通过校验，请核对后再操作',
                      401:'当前人员会话已失效，请重新登录',
                      403:'没有当前门店人员操作权限',
                      409:'成员或管理范围已变化，请刷新当前名单',
                      422:'人员配置需核对，请刷新后再操作',
                      429:'席位、门店额度或服务频率已达限制'}
            status=getattr(error,'http_status',None)
            if status in statuses:
                raise WorkspaceError(statuses[status],status,mutation_committed=False) from None
            raise WorkspaceError('人员操作结果未确认，请先刷新当前范围成员；没有自动重试',
                                 503,mutation_committed=None) from None
    return public(_cloud(server, user, operation, data))"""
s=s.replace(needle,new,1);path.write_text(s,encoding='utf-8',newline='\n')
parents=json.loads((OWN/'PARENTS.json').read_bytes());parents['proposed_target_count']=8;parents['targets'].append({'target':str(source),'parent_source':str(source),'parent':pin(raw),'parent_kind':'unchanged_Source51_public_gateway_parent','Root_explicit_addition':'member HTTP unknown/known response mapping'})
with (OWN/'PARENTS-8.json').open('x',encoding='utf-8') as stream:stream.write(json.dumps(parents,ensure_ascii=False,indent=2)+'\n')
# Keep the runtime's ORIGINAL gateway for the first lost-after-commit RED.
service=C/'work/cloud/workspace/service.cjs';s=service.read_text('utf-8').replace("if(username===user.username&&(payload.disabled||role!=='admin'))","if(!manager&&username===user.username&&(payload.disabled||role!=='admin'))",1);service.write_text(s,encoding='utf-8',newline='\n')
print(json.dumps({'candidate_targets':8,'gateway_runtime_still_baseline_for_RED':True}))
