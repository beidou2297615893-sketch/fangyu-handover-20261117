"""Save public protocol/design inputs only; do not run the state harness."""
import hashlib,json
from pathlib import Path
OWN=Path(__file__).resolve().parent
PROJECT=OWN.parents[2]
WORK=PROJECT/'work'
def pin(raw):return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest().upper()}
def entry(path):return {'path':str(path),'pin':pin(path.read_bytes())}
def create(path,value):
    with path.open('x',encoding='utf-8',newline='\n') as stream:stream.write(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
snapshot=OWN/'protocol-snapshot';snapshot.mkdir()
inputs=[]
current=WORK/'product-upgrade-20261009/audits/source52-current.md'
raw=current.read_bytes();top=('\n'.join(raw.decode('utf-8-sig').splitlines()[:10])+'\n').encode('utf-8')
target=snapshot/'source52-current-top.md'
with target.open('xb') as stream:stream.write(top)
inputs.append({'source':str(current),'scope':'first ten lines only, current read','snapshot':entry(target)})
for name in ('PROPOSAL.md','PARENT-INTERFACES.json'):
    source=WORK/'source52-native-proposal'/name;target=snapshot/name;raw=source.read_bytes()
    with target.open('xb') as stream:stream.write(raw)
    inputs.append({'source':str(source),'source_pin':pin(raw),'snapshot':entry(target),
                   'old_eight_provisional_count_superseded_by_r2_nine':True})
revision=WORK/'source52-store-manager/revision2/FROZEN.json'
assert pin(revision.read_bytes())=={'bytes':20693,'sha256':'737719494423FEB5F5F928735264629188C7A94F24C19B7C680811480DB94517'}
create(OWN/'INPUTS.json',{'schema':'source52_native_state_design_inputs_v1','read_only_inputs':inputs,
    'business_candidate':entry(revision),'final_Root_native_pins_provided':False,
    'actual_SOURCE_or_original_instance_reads':0})
create(OWN/'FROZEN.json',{'schema':'source52_native_state_design_unrun_v1','status':'NOT_RUN',
    'run_enabled':False,'final_Root_bindings':{},'no_result_or_PASS_constructed':True,
    'target_plan':{'existing':9,'backup':9,'new':0,'local_transport_has_no_old_layer_mapping':True},
    'files':[entry(OWN/name) for name in ('DESIGN.md','harness-skeleton.py','INPUTS.json','freeze-design.py')],
    'state_harness_executed':False,'Root_CAS_guard_helper_executed':False,
    'formal_Root_graph_helper_mutations':0,'original_App_lock_data_cookie_platform_model_calls':0})
print(json.dumps({'design':entry(OWN/'DESIGN.md'),'skeleton':entry(OWN/'harness-skeleton.py'),
                 'frozen':entry(OWN/'FROZEN.json'),'status':'NOT_RUN'},ensure_ascii=False))
