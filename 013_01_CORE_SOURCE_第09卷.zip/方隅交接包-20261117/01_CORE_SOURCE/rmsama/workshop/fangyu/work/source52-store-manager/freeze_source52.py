"""Freeze only Source52 owned candidate/public evidence; never apply or run business."""
import ast,difflib,hashlib,json,subprocess
from pathlib import Path

OWN=Path(__file__).resolve().parent
PROJECT=Path('C:/积木软件工坊/项目/方隅公寓客户版')
assert OWN==PROJECT/'work/source52-store-manager'
WORK=PROJECT/'work'
def pin(raw):return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest().upper()}
def filepin(path):return {'path':str(path),'pin':pin(path.read_bytes())}
def create(path,value):
    with path.open('x',encoding='utf-8',newline='\n') as stream:
        stream.write(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
parents=json.loads((OWN/'PARENTS-9.json').read_bytes())
targets=[];diff=[]
for item in parents['targets']:
    parent=Path(item['parent_source']);raw=parent.read_bytes()
    assert pin(raw)==item['parent'],str(parent)
    relative=Path(item['target']).relative_to(WORK)
    saved=OWN/'parents/work'/relative
    if saved.exists():assert saved.read_bytes()==raw,str(saved)
    else:
        saved.parent.mkdir(parents=True,exist_ok=True)
        with saved.open('xb') as stream:stream.write(raw)
    candidate=OWN/'candidate/work'/relative;final=candidate.read_bytes()
    assert final!=raw,str(candidate)
    targets.append({'target':item['target'],'candidate':str(candidate),
                    'parent_source':str(saved),'parent_kind':item['parent_kind'],
                    'original_parent_source':str(parent),'parent':pin(raw),'candidate_pin':pin(final)})
    diff.extend(difflib.unified_diff(raw.decode('utf-8-sig').splitlines(True),
                                    final.decode('utf-8-sig').splitlines(True),
                                    fromfile='parent/work/'+relative.as_posix(),
                                    tofile='candidate/work/'+relative.as_posix()))
assert len(targets)==9
assert Path(targets[1]['candidate']).read_bytes()==Path(targets[2]['candidate']).read_bytes()
with (OWN/'candidate.diff').open('x',encoding='utf-8',newline='\n') as stream:stream.writelines(diff)

dependencies=[];seen=set();target_paths={str(Path(row['candidate'])) for row in targets}
def dependency(path,kind,source=None,expected=None):
    path=Path(path)
    if str(path) in seen or str(path) in target_paths:return
    raw=path.read_bytes()
    if expected is not None:assert pin(raw)==expected,str(path)
    seen.add(str(path));item={'path':str(path),'pin':pin(raw),'kind':kind}
    if source is not None:item['source']=str(source)
    dependencies.append(item)
for item in parents['Source51_other_three_unchanged_dependencies']:
    raw=Path(item['candidate']).read_bytes();assert pin(raw)==item['pin']
    copied=OWN/'candidate/work'/Path(item['target']).relative_to(WORK)
    dependency(copied,'Source51_frozen_required_unchanged',item['candidate'],item['pin'])
base=json.loads(Path(parents['source51_frozen']['path']).read_bytes())
assert pin(Path(parents['source51_frozen']['path']).read_bytes())==parents['source51_frozen']['pin']
for item in base['unchanged_public_dependencies']:
    copied=OWN/'candidate/work'/Path(item['path']).relative_to(WORK)
    dependency(copied,'existing_public_cloud_dependency',item['path'],item['pin'])
for root in (OWN/'runtime/app/src',OWN/'candidate/work/app/src'):
    for path in sorted(root.rglob('*.py')):
        assert not any(name.lower() in ('private','data','__pycache__') for name in path.relative_to(root).parts)
        dependency(path,'owned_public_Python_runtime_snapshot')
for relative in ('candidate/node_modules/@cloudbase/node-sdk/index.js',
                 'runtime/app/src/resources/companies/general.json',
                 'tests/local-transport-candidate.mjs'):
    dependency(OWN/relative,'explicit_synthetic_fixture_dependency')
app=OWN/'runtime/app/src/app.py'
assert pin(app.read_bytes())=={'bytes':126224,'sha256':'D9AB9A78923BAD556897EC5E70770FB6BF98493FBCC2E24EC8DD229F48C6E48E'}
assert (OWN/'runtime/app/src/assistant/employee_workspace.py').read_bytes()==Path(targets[7]['candidate']).read_bytes()
assert (OWN/'tests/local-transport-candidate.mjs').read_bytes()==Path(targets[8]['candidate']).read_bytes()
latest=OWN/'runs/c281b33405984ec6abdb3363a9b8a827'
owner_copy=latest/'portal/work/owner-admin-20261004/owner_admin.py'
assert owner_copy.read_bytes()==Path(targets[5]['candidate']).read_bytes()
create(OWN/'DEPENDENCIES.json',{'schema':'source52_public_fixture_dependencies_v1',
       'count':len(dependencies),'public_code_or_explicit_synthetic_configuration_only':True,
       'no_runs_database_cookie_DPAPI_token_inventory':True,
       'Source50_future_AppServer':filepin(app),
       'Source51_pending_platform_functions_not_invoked':True,'files':dependencies})

syntax=[]
for item in targets:
    path=Path(item['candidate'])
    if path.suffix=='.py':
        ast.parse(path.read_bytes(),filename=str(path));syntax.append({'path':str(path),'method':'Python AST only','status':'PASS'})
    elif path.suffix in ('.mjs','.cjs'):
        check=subprocess.run(['node','--check',str(path)],capture_output=True,text=True,timeout=20)
        assert check.returncode==0,check.stderr
        syntax.append({'path':str(path),'method':'node --check only','status':'PASS'})
create(OWN/'STATIC.json',{'schema':'source52_candidate_syntax_only_v1','checks':syntax,
                        'business_story_invocations':0,'formal_mutations':0})

carriers=[filepin(OWN/'tests'/name) for name in ('http-story.py','dom-story.mjs','cloud-fixture.cjs','public-fixture.cjs')]
current=json.loads((latest/'RESULT.json').read_bytes())
assert current['carrier_pin']==pin((OWN/'tests/http-story.py').read_bytes())
assert current['status']=='PASS' and len(current['events'])==8
dom=json.loads((latest/'DOM-RESULT.json').read_bytes())
assert dom['status']=='PASS' and len(dom['checks'])==11
assert 'missing boolean ack' in dom['checks'][7]['check']
evidence=[]
for path in sorted((OWN/'runs').glob('*/FIRST-*.json')):evidence.append(filepin(path))
for run in ('f016844021784249ba47c7459e211fc2','d738adbc3f0c47c8b01897fc72c3e9bf','c281b33405984ec6abdb3363a9b8a827'):
    for name in ('RESULT.json','DOM-RESULT.json'):
        path=OWN/'runs'/run/name
        if path.exists():
            entry=filepin(path);record=json.loads(path.read_bytes())
            if 'carrier_pin' in record:entry['recorded_at_runtime_main_carrier_pin']=record['carrier_pin']
            evidence.append(entry)
docs=[filepin(OWN/name) for name in ('README.md','REVIEW-FOCUS.md','HISTORY-NOTE.md','candidate.diff','DEPENDENCIES.json','STATIC.json','freeze_source52.py')]
inputs=[filepin(OWN/name) for name in ('PROPOSAL.md','PARENTS.json','PARENTS-8.json','PARENTS-9.json','FROZEN-PROPOSAL.json','INPUTS.json','MANAGER-GAP-c1b25e0d-2ca3-446a-93c0-0b6a39618201.json')]
create(OWN/'FROZEN.json',{
    'schema':'source52_store_manager_candidate_frozen_v1','join_authorized':False,
    'formal_mutations':0,'target_count':9,'new_target_count':0,'role_enum_unchanged':['admin','operator','origin_partner'],
    'required_successor_base':parents['source51_frozen'],
    'requires_real_Source51_receipt_and_exact_parent_readback_before_any_Root_join':True,
    'Source50_Source51_pending_graph_or_entry_mutations':0,
    'targets':targets,'Source51_other_three_unchanged_dependencies':parents['Source51_other_three_unchanged_dependencies'],
    'documents':docs,'historical_inputs':inputs,'evidence':evidence,
    'final_main_result':filepin(latest/'RESULT.json'),'final_DOM_result':filepin(latest/'DOM-RESULT.json'),
    'carriers_current_bytes_read_at_freeze_not_all_historical_runtime_signatures':carriers,
    'latest_native_bool_ack_subseam':{
       'invoked_by':'tests/http-story.py:113; checked child RESULT at line 115',
       'assertion':'tests/dom-story.mjs:65-68','transport_only_drop':'tests/cloud-fixture.cjs:19,23',
       'result':'c281 DOM-RESULT checks[7] (eighth check)',
       'same_eight_main_events_and_same_main_carrier_as_d7':True,
       'old_DOM_cloud_subcarrier_runtime_bytes_or_SHA_not_all_retained':True},
    'boundaries':{'SDK':'synthetic JSON adapter, not production SDK','shared':False,
       'real_platform_model_GUI_App_calls':0,'real_customer_DB_cookie_account_reads':0,
       'cloud_deployments':0,'actual_Source52_apply':0,'no_author_final_approval':True,
       'normal_module_DOM_only_not_complete_browser_page_or_GUI':True}})
print(json.dumps({'frozen':filepin(OWN/'FROZEN.json'),'targets':len(targets),
                  'public_dependencies':len(dependencies),'report':filepin(OWN/'REVIEW-FOCUS.md'),
                  'final_main':filepin(latest/'RESULT.json'),'final_DOM':filepin(latest/'DOM-RESULT.json')},ensure_ascii=False))
