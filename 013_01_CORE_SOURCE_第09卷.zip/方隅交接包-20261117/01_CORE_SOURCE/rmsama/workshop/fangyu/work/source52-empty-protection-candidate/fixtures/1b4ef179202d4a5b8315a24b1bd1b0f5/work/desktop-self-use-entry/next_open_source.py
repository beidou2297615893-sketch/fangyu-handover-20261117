"""Prepared only: a fixed Root source CAS at the next ordinary native opening.

This is not a package updater or an instance/platform upgrade. Missing Root
authorization, pins or any uncertain process/lock fact leaves the opening held.
"""
from contextlib import contextmanager
import hashlib
import json
import os
from pathlib import Path
import stat
import sys
import tempfile

PROJECT = Path('C:/积木软件工坊/项目/方隅公寓客户版/work/source52-empty-protection-candidate/fixtures/1b4ef179202d4a5b8315a24b1bd1b0f5')
AUDITS = PROJECT/'work/product-upgrade-20261009/audits'
ENTRY = PROJECT/'work/desktop-self-use-entry/desktop_entry.py'
PILOT = PROJECT/'work/self-operating-pilot'
APPROVAL = AUDITS/'source50-final-root-read.json'
MANIFEST = AUDITS/'source50-manifest.json'
JOIN = AUDITS/'join-source50-reviewed.py'
RECEIPT = AUDITS/'source50-joined.json'
STARTED = AUDITS/'source50-next-open-started.json'

# Root must fill these only after independent review of the fixed Source50 set.
# There are no CLI, HTTP or environment inputs for authority or any path.
JOIN_AUTHORIZED = True
ROOT_MANIFEST_PIN={'bytes': 21928, 'sha256': '29492E4969C2E72BD4E880D2C79FDAB9BFBFB98E18CA28DBAF8CABD68005FF70'}
TARGET_PATHS = (
    Path('C:/积木软件工坊/项目/方隅公寓客户版/work/source52-empty-protection-candidate/fixtures/1b4ef179202d4a5b8315a24b1bd1b0f5/work/app/src/assistant/owner_company_receipt_bridge.py'),
    Path('C:/积木软件工坊/项目/方隅公寓客户版/work/source52-empty-protection-candidate/fixtures/1b4ef179202d4a5b8315a24b1bd1b0f5/work/app/src/web/workspace/self-operating-read.mjs'),
    Path('C:/积木软件工坊/项目/方隅公寓客户版/work/source52-empty-protection-candidate/fixtures/1b4ef179202d4a5b8315a24b1bd1b0f5/work/app/src/app.py'),
    Path('C:/积木软件工坊/项目/方隅公寓客户版/work/source52-empty-protection-candidate/fixtures/1b4ef179202d4a5b8315a24b1bd1b0f5/work/app/src/assistant/owner_douyin_read.py'),
    Path('C:/积木软件工坊/项目/方隅公寓客户版/work/source52-empty-protection-candidate/fixtures/1b4ef179202d4a5b8315a24b1bd1b0f5/work/app/work/runtime/dy/douyin-bridge-source-cid-v1/node.exe'),
    Path('C:/积木软件工坊/项目/方隅公寓客户版/work/source52-empty-protection-candidate/fixtures/1b4ef179202d4a5b8315a24b1bd1b0f5/work/app/work/runtime/dy/douyin-bridge-source-cid-v1/NODE-LICENSE.txt'),
    Path('C:/积木软件工坊/项目/方隅公寓客户版/work/source52-empty-protection-candidate/fixtures/1b4ef179202d4a5b8315a24b1bd1b0f5/work/app/work/runtime/dy/douyin-bridge-source-cid-v1/LICENSE'),
    Path('C:/积木软件工坊/项目/方隅公寓客户版/work/source52-empty-protection-candidate/fixtures/1b4ef179202d4a5b8315a24b1bd1b0f5/work/app/work/runtime/dy/douyin-bridge-source-cid-v1/package.json'),
    Path('C:/积木软件工坊/项目/方隅公寓客户版/work/source52-empty-protection-candidate/fixtures/1b4ef179202d4a5b8315a24b1bd1b0f5/work/app/work/runtime/dy/douyin-bridge-source-cid-v1/package-lock.json'),
    Path('C:/积木软件工坊/项目/方隅公寓客户版/work/source52-empty-protection-candidate/fixtures/1b4ef179202d4a5b8315a24b1bd1b0f5/work/app/work/runtime/dy/douyin-bridge-source-cid-v1/cli.js'),
    Path('C:/积木软件工坊/项目/方隅公寓客户版/work/source52-empty-protection-candidate/fixtures/1b4ef179202d4a5b8315a24b1bd1b0f5/work/app/work/runtime/dy/douyin-bridge-source-cid-v1/server.js'),
    Path('C:/积木软件工坊/项目/方隅公寓客户版/work/source52-empty-protection-candidate/fixtures/1b4ef179202d4a5b8315a24b1bd1b0f5/work/app/work/runtime/dy/douyin-bridge-source-cid-v1/scripts/douyin.user.js'),
    Path('C:/积木软件工坊/项目/方隅公寓客户版/work/source52-empty-protection-candidate/fixtures/1b4ef179202d4a5b8315a24b1bd1b0f5/work/app/work/runtime/dy/douyin-bridge-source-cid-v1/lib/audit.js'),
    Path('C:/积木软件工坊/项目/方隅公寓客户版/work/source52-empty-protection-candidate/fixtures/1b4ef179202d4a5b8315a24b1bd1b0f5/work/app/work/runtime/dy/douyin-bridge-source-cid-v1/lib/client/bridge-client.js'),
    Path('C:/积木软件工坊/项目/方隅公寓客户版/work/source52-empty-protection-candidate/fixtures/1b4ef179202d4a5b8315a24b1bd1b0f5/work/app/work/runtime/dy/douyin-bridge-source-cid-v1/lib/commands/comment-page.js'),
    Path('C:/积木软件工坊/项目/方隅公寓客户版/work/source52-empty-protection-candidate/fixtures/1b4ef179202d4a5b8315a24b1bd1b0f5/work/app/work/runtime/dy/douyin-bridge-source-cid-v1/lib/commands/dm.js'),
    Path('C:/积木软件工坊/项目/方隅公寓客户版/work/source52-empty-protection-candidate/fixtures/1b4ef179202d4a5b8315a24b1bd1b0f5/work/app/work/runtime/dy/douyin-bridge-source-cid-v1/lib/commands/get.js'),
    Path('C:/积木软件工坊/项目/方隅公寓客户版/work/source52-empty-protection-candidate/fixtures/1b4ef179202d4a5b8315a24b1bd1b0f5/work/app/work/runtime/dy/douyin-bridge-source-cid-v1/lib/commands/helpers.js'),
    Path('C:/积木软件工坊/项目/方隅公寓客户版/work/source52-empty-protection-candidate/fixtures/1b4ef179202d4a5b8315a24b1bd1b0f5/work/app/work/runtime/dy/douyin-bridge-source-cid-v1/lib/commands/index.js'),
    Path('C:/积木软件工坊/项目/方隅公寓客户版/work/source52-empty-protection-candidate/fixtures/1b4ef179202d4a5b8315a24b1bd1b0f5/work/app/work/runtime/dy/douyin-bridge-source-cid-v1/lib/commands/post.js'),
    Path('C:/积木软件工坊/项目/方隅公寓客户版/work/source52-empty-protection-candidate/fixtures/1b4ef179202d4a5b8315a24b1bd1b0f5/work/app/work/runtime/dy/douyin-bridge-source-cid-v1/lib/commands/replies.js'),
    Path('C:/积木软件工坊/项目/方隅公寓客户版/work/source52-empty-protection-candidate/fixtures/1b4ef179202d4a5b8315a24b1bd1b0f5/work/app/work/runtime/dy/douyin-bridge-source-cid-v1/lib/commands/search.js'),
    Path('C:/积木软件工坊/项目/方隅公寓客户版/work/source52-empty-protection-candidate/fixtures/1b4ef179202d4a5b8315a24b1bd1b0f5/work/app/work/runtime/dy/douyin-bridge-source-cid-v1/lib/memory/comments.js'),
    Path('C:/积木软件工坊/项目/方隅公寓客户版/work/source52-empty-protection-candidate/fixtures/1b4ef179202d4a5b8315a24b1bd1b0f5/work/app/work/runtime/dy/douyin-bridge-source-cid-v1/lib/memory/corpus.js'),
    Path('C:/积木软件工坊/项目/方隅公寓客户版/work/source52-empty-protection-candidate/fixtures/1b4ef179202d4a5b8315a24b1bd1b0f5/work/app/work/runtime/dy/douyin-bridge-source-cid-v1/lib/memory/db.js'),
    Path('C:/积木软件工坊/项目/方隅公寓客户版/work/source52-empty-protection-candidate/fixtures/1b4ef179202d4a5b8315a24b1bd1b0f5/work/app/work/runtime/dy/douyin-bridge-source-cid-v1/lib/memory/events.js'),
    Path('C:/积木软件工坊/项目/方隅公寓客户版/work/source52-empty-protection-candidate/fixtures/1b4ef179202d4a5b8315a24b1bd1b0f5/work/app/work/runtime/dy/douyin-bridge-source-cid-v1/lib/memory/failures.js'),
    Path('C:/积木软件工坊/项目/方隅公寓客户版/work/source52-empty-protection-candidate/fixtures/1b4ef179202d4a5b8315a24b1bd1b0f5/work/app/work/runtime/dy/douyin-bridge-source-cid-v1/lib/memory/users.js'),
    Path('C:/积木软件工坊/项目/方隅公寓客户版/work/source52-empty-protection-candidate/fixtures/1b4ef179202d4a5b8315a24b1bd1b0f5/work/app/work/runtime/dy/douyin-bridge-source-cid-v1/lib/memory/videos.js'),
    Path('C:/积木软件工坊/项目/方隅公寓客户版/work/source52-empty-protection-candidate/fixtures/1b4ef179202d4a5b8315a24b1bd1b0f5/work/app/work/runtime/dy/douyin-bridge-source-cid-v1/lib/miniapp-delivery-state.js'),
    Path('C:/积木软件工坊/项目/方隅公寓客户版/work/source52-empty-protection-candidate/fixtures/1b4ef179202d4a5b8315a24b1bd1b0f5/work/app/work/runtime/dy/douyin-bridge-source-cid-v1/lib/risk-control.js'),
    Path('C:/积木软件工坊/项目/方隅公寓客户版/work/source52-empty-protection-candidate/fixtures/1b4ef179202d4a5b8315a24b1bd1b0f5/work/app/work/runtime/dy/douyin-bridge-source-cid-v1/lib/server/registry.js'),
    Path('C:/积木软件工坊/项目/方隅公寓客户版/work/source52-empty-protection-candidate/fixtures/1b4ef179202d4a5b8315a24b1bd1b0f5/work/app/work/runtime/dy/douyin-bridge-source-cid-v1/lib/server/router.js'),
    Path('C:/积木软件工坊/项目/方隅公寓客户版/work/source52-empty-protection-candidate/fixtures/1b4ef179202d4a5b8315a24b1bd1b0f5/work/app/work/runtime/dy/douyin-bridge-source-cid-v1/lib/server/ws-hub.js'),
    Path('C:/积木软件工坊/项目/方隅公寓客户版/work/source52-empty-protection-candidate/fixtures/1b4ef179202d4a5b8315a24b1bd1b0f5/work/app/work/runtime/dy/douyin-bridge-source-cid-v1/lib/shared/protocol.js'),
    Path('C:/积木软件工坊/项目/方隅公寓客户版/work/source52-empty-protection-candidate/fixtures/1b4ef179202d4a5b8315a24b1bd1b0f5/work/app/work/runtime/dy/douyin-bridge-source-cid-v1/lib/shared/serialize.js'),
    Path('C:/积木软件工坊/项目/方隅公寓客户版/work/source52-empty-protection-candidate/fixtures/1b4ef179202d4a5b8315a24b1bd1b0f5/work/app/work/runtime/dy/douyin-bridge-source-cid-v1/node_modules/ws/package.json'),
    Path('C:/积木软件工坊/项目/方隅公寓客户版/work/source52-empty-protection-candidate/fixtures/1b4ef179202d4a5b8315a24b1bd1b0f5/work/app/work/runtime/dy/douyin-bridge-source-cid-v1/node_modules/ws/LICENSE'),
    Path('C:/积木软件工坊/项目/方隅公寓客户版/work/source52-empty-protection-candidate/fixtures/1b4ef179202d4a5b8315a24b1bd1b0f5/work/app/work/runtime/dy/douyin-bridge-source-cid-v1/node_modules/ws/index.js'),
    Path('C:/积木软件工坊/项目/方隅公寓客户版/work/source52-empty-protection-candidate/fixtures/1b4ef179202d4a5b8315a24b1bd1b0f5/work/app/work/runtime/dy/douyin-bridge-source-cid-v1/node_modules/ws/browser.js'),
    Path('C:/积木软件工坊/项目/方隅公寓客户版/work/source52-empty-protection-candidate/fixtures/1b4ef179202d4a5b8315a24b1bd1b0f5/work/app/work/runtime/dy/douyin-bridge-source-cid-v1/node_modules/ws/wrapper.mjs'),
    Path('C:/积木软件工坊/项目/方隅公寓客户版/work/source52-empty-protection-candidate/fixtures/1b4ef179202d4a5b8315a24b1bd1b0f5/work/app/work/runtime/dy/douyin-bridge-source-cid-v1/node_modules/ws/lib/buffer-util.js'),
    Path('C:/积木软件工坊/项目/方隅公寓客户版/work/source52-empty-protection-candidate/fixtures/1b4ef179202d4a5b8315a24b1bd1b0f5/work/app/work/runtime/dy/douyin-bridge-source-cid-v1/node_modules/ws/lib/constants.js'),
    Path('C:/积木软件工坊/项目/方隅公寓客户版/work/source52-empty-protection-candidate/fixtures/1b4ef179202d4a5b8315a24b1bd1b0f5/work/app/work/runtime/dy/douyin-bridge-source-cid-v1/node_modules/ws/lib/event-target.js'),
    Path('C:/积木软件工坊/项目/方隅公寓客户版/work/source52-empty-protection-candidate/fixtures/1b4ef179202d4a5b8315a24b1bd1b0f5/work/app/work/runtime/dy/douyin-bridge-source-cid-v1/node_modules/ws/lib/extension.js'),
    Path('C:/积木软件工坊/项目/方隅公寓客户版/work/source52-empty-protection-candidate/fixtures/1b4ef179202d4a5b8315a24b1bd1b0f5/work/app/work/runtime/dy/douyin-bridge-source-cid-v1/node_modules/ws/lib/limiter.js'),
    Path('C:/积木软件工坊/项目/方隅公寓客户版/work/source52-empty-protection-candidate/fixtures/1b4ef179202d4a5b8315a24b1bd1b0f5/work/app/work/runtime/dy/douyin-bridge-source-cid-v1/node_modules/ws/lib/permessage-deflate.js'),
    Path('C:/积木软件工坊/项目/方隅公寓客户版/work/source52-empty-protection-candidate/fixtures/1b4ef179202d4a5b8315a24b1bd1b0f5/work/app/work/runtime/dy/douyin-bridge-source-cid-v1/node_modules/ws/lib/receiver.js'),
    Path('C:/积木软件工坊/项目/方隅公寓客户版/work/source52-empty-protection-candidate/fixtures/1b4ef179202d4a5b8315a24b1bd1b0f5/work/app/work/runtime/dy/douyin-bridge-source-cid-v1/node_modules/ws/lib/sender.js'),
    Path('C:/积木软件工坊/项目/方隅公寓客户版/work/source52-empty-protection-candidate/fixtures/1b4ef179202d4a5b8315a24b1bd1b0f5/work/app/work/runtime/dy/douyin-bridge-source-cid-v1/node_modules/ws/lib/stream.js'),
    Path('C:/积木软件工坊/项目/方隅公寓客户版/work/source52-empty-protection-candidate/fixtures/1b4ef179202d4a5b8315a24b1bd1b0f5/work/app/work/runtime/dy/douyin-bridge-source-cid-v1/node_modules/ws/lib/subprotocol.js'),
    Path('C:/积木软件工坊/项目/方隅公寓客户版/work/source52-empty-protection-candidate/fixtures/1b4ef179202d4a5b8315a24b1bd1b0f5/work/app/work/runtime/dy/douyin-bridge-source-cid-v1/node_modules/ws/lib/validation.js'),
    Path('C:/积木软件工坊/项目/方隅公寓客户版/work/source52-empty-protection-candidate/fixtures/1b4ef179202d4a5b8315a24b1bd1b0f5/work/app/work/runtime/dy/douyin-bridge-source-cid-v1/node_modules/ws/lib/websocket-server.js'),
    Path('C:/积木软件工坊/项目/方隅公寓客户版/work/source52-empty-protection-candidate/fixtures/1b4ef179202d4a5b8315a24b1bd1b0f5/work/app/work/runtime/dy/douyin-bridge-source-cid-v1/node_modules/ws/lib/websocket.js'),
    Path('C:/积木软件工坊/项目/方隅公寓客户版/work/source52-empty-protection-candidate/fixtures/1b4ef179202d4a5b8315a24b1bd1b0f5/work/desktop-self-use-entry/desktop_entry.py'),
)
ORIGINAL_INSTANCE_ID = 'd075ac9c039e44038ddbc6f3e753d73c'


# The five original Source44 backup/CAS helpers, reused without importing its
# executable top level. They never open SQLite or platform credentials.
def blob(path):
    current = PROJECT
    for part in path.relative_to(PROJECT).parts:
        current = current/part
        info = current.lstat()
        if current.is_symlink() or getattr(info, 'st_file_attributes', 0)&0x400:
            raise ValueError('reparse path changed')
    if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1:
        raise ValueError('file kind changed')
    return path.read_bytes()


def pin(value):
    return {'bytes': len(value), 'sha256': hashlib.sha256(value).hexdigest().upper()}


def expected(path, proof):
    value = blob(path)
    if pin(value) != proof:
        raise ValueError('pinned file changed: '+str(path))
    return value


def no_link_parent(path):
    current = PROJECT
    for part in path.parent.relative_to(PROJECT).parts:
        current = current/part
        info = current.lstat()
        if (not stat.S_ISDIR(info.st_mode) or current.is_symlink()
                or getattr(info, 'st_file_attributes', 0)&0x400):
            raise ValueError('new-source parent changed')


def prepared_temp(target, value):
    no_link_parent(target)
    descriptor, name = tempfile.mkstemp(prefix='.source44-', suffix='.tmp', dir=target.parent)
    temporary = Path(name)
    try:
        with os.fdopen(descriptor, 'wb') as stream:
            stream.write(value)
            stream.flush()
            os.fsync(stream.fileno())
        if blob(temporary) != value:
            raise ValueError('complete temporary write mismatch')
        return temporary
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise


def _proof(value):
    return (type(value) is dict and set(value) == {'bytes', 'sha256'}
        and type(value['bytes']) is int and value['bytes'] >= 0
        and type(value['sha256']) is str and len(value['sha256']) == 64
        and all(c in '0123456789ABCDEF' for c in value['sha256']))


def _plan():
    if JOIN_AUTHORIZED is not True or not _proof(ROOT_MANIFEST_PIN) or not TARGET_PATHS:
        raise ValueError('Root reviewed fixed Source50 authority is absent')
    manifest = json.loads(expected(MANIFEST, ROOT_MANIFEST_PIN))
    if (manifest.get('schema') != 'source50_next_open_manifest_v1'
            or manifest.get('source_batch') != 50 or manifest.get('join_authorized') is not True
            or manifest.get('instance_id') != ORIGINAL_INSTANCE_ID
            or not _proof(manifest.get('approval_pin')) or not _proof(manifest.get('join_script_pin'))):
        raise ValueError('fixed next-opening manifest changed')
    targets = manifest.get('targets')
    if (type(targets) is not list or len(targets) != len(TARGET_PATHS)
            or any(type(row) is not dict or set(row) != {'path', 'final_pin'}
                   or type(row['path']) is not str or not _proof(row['final_pin']) for row in targets)
            or {Path(row['path']) for row in targets} != set(TARGET_PATHS)
            or len({row['path'] for row in targets}) != len(targets) or ENTRY not in TARGET_PATHS):
        raise ValueError('Root compiled exact target set changed')
    if any(path == PILOT or path.is_relative_to(PILOT) for path in TARGET_PATHS):
        raise ValueError('source CAS cannot target the pilot instance or data')
    gate = json.loads(expected(APPROVAL, manifest['approval_pin']))
    if (gate.get('schema') != 'source50_final_root_read' or gate.get('source_batch') != 50
            or gate.get('join_authorized') is not True
            or gate.get('independent_code_review_passed') is not True
            or gate.get('independent_actual_qa_review_passed') is not True
            or gate.get('next_normal_open_only') is not True
            or gate.get('customer_database_opened') is not False
            or gate.get('session_copied') is not False
            or gate.get('deployment_or_packaging_performed') is not False):
        raise ValueError('Root fixed deferred scope has not been approved')
    expected(JOIN, manifest['join_script_pin'])
    return manifest


@contextmanager
def _exclusive_existing_lock(entry):
    # The exact original main uses this same byte-range lock. Require an
    # existing nonempty ordinary file; do not create/write or take over it.
    import msvcrt
    path = entry.plain(PILOT/'data/instance.lock')
    before = path.lstat()
    file = path.open('r+b')
    locked = False
    try:
        opened = os.fstat(file.fileno())
        after = path.lstat()
        if (opened.st_size < 1 or opened.st_nlink != 1
                or (opened.st_dev, opened.st_ino) != (before.st_dev, before.st_ino)
                or (after.st_dev, after.st_ino) != (before.st_dev, before.st_ino)):
            raise ValueError('original instance lock changed')
        file.seek(0)
        msvcrt.locking(file.fileno(), msvcrt.LK_NBLCK, 1)
        locked = True
        yield
    finally:
        try:
            if locked:
                file.seek(0)
                msvcrt.locking(file.fileno(), msvcrt.LK_UNLCK, 1)
        finally:
            file.close()


def _readback(manifest):
    receipt = json.loads(blob(RECEIPT))
    if (receipt.get('source_batch') != 50
            or receipt.get('approval_sha256') != manifest['approval_pin']['sha256']):
        raise ValueError('Root original Source50 receipt mismatch')
    records = receipt.get('targets')
    if (type(records) is not list or len(records) != len(manifest['targets'])
            or len({row.get('target') for row in records}) != len(records)):
        raise ValueError('Root Source50 receipt target set mismatch')
    pins = {Path(row['path']): row['final_pin'] for row in manifest['targets']}
    if {Path(row['target']) for row in records} != set(pins):
        raise ValueError('Root Source50 receipt physical scope mismatch')
    for row in records:
        target = Path(row['target'])
        if row.get('candidate') != pins[target]:
            raise ValueError('Root Source50 receipt candidate pin mismatch')
        expected(target, pins[target])


def _start_once(manifest):
    # A lost/failed apply has no automatic second invocation. The original
    # started note and Root CAS backups/receipt remain for Root recovery.
    if os.path.lexists(STARTED):
        raise ValueError('Source50 original invocation needs Root recovery')
    value = {'schema': 'source50_next_open_started_v1', 'source_batch': 50,
        'instance_id': ORIGINAL_INSTANCE_ID, 'approval_sha256': manifest['approval_pin']['sha256'],
        'manifest_pin': ROOT_MANIFEST_PIN, 'pid': os.getpid(), 'auto_retry': False}
    temporary = prepared_temp(STARTED, (json.dumps(value, ensure_ascii=False, sort_keys=True)+'\n').encode('utf-8'))
    try:
        # On Windows rename fails if the fixed started note already exists.
        os.rename(temporary, STARTED)
    finally:
        temporary.unlink(missing_ok=True)


def reviewed_entry_pin_if_joined():
    """Read-only original receipt/source check; never takes a lock or applies."""
    if not os.path.lexists(RECEIPT):
        return None
    manifest = _plan()
    _readback(manifest)
    return next(row['final_pin'] for row in manifest['targets'] if Path(row['path']) == ENTRY)


def before_normal_open(entry):
    """Called only after check-only is handled, before any source business import."""
    held = {'decision': 'held', 'source_mutations': 0, 'automatic_retry': False}
    if (os.name != 'nt' or getattr(sys, 'frozen', False)
            or Path(entry.__file__) != ENTRY or entry.PILOT != PILOT):
        return held
    # Requiring real dead-process preflight is deliberate: no in-process
    # closed capability, remembered answer, timer or fake UI implies idle here.
    report = entry.preflight()
    if (report.get('state') != 'ready_for_original_native_main'
            or report.get('instance_id') != ORIGINAL_INSTANCE_ID):
        return held
    invoked = False
    try:
        manifest = _plan()
        if RECEIPT.exists():
            _readback(manifest)
            return {'decision': 'continue', 'source_mutations': 0, 'automatic_retry': False}
        with _exclusive_existing_lock(entry):
            again = entry.preflight()
            if (again.get('state') != 'ready_for_original_native_main'
                    or again.get('instance_id') != ORIGINAL_INSTANCE_ID):
                return held
            manifest = _plan()  # exact authority/script pins rechecked under lock
            _start_once(manifest)
            original_args = sys.argv
            sys.argv = [str(JOIN), '--apply', manifest['approval_pin']['sha256']]
            try:
                try:
                    raw = expected(JOIN, manifest['join_script_pin'])
                    invoked = True
                    exec(compile(raw, str(JOIN), 'exec'),
                        {'__name__': '__main__', '__file__': str(JOIN)})
                except SystemExit as result:
                    if result.code is not None and not (type(result.code) is int and result.code == 0):
                        raise ValueError('Root fixed CAS did not complete')
            finally:
                sys.argv = original_args
            _readback(manifest)
        # Fresh Python executes the now-pinned current entry and HOST_PINS.
        # It reacquires the original main lock normally; no lock/grant, module
        # cache, platform upgrade flag or former main receipt is passed along.
        os.execv(sys.executable, [sys.executable, '-X', 'utf8', '-B', '-I', str(ENTRY)])
        return {**held, 'source_mutations': None, 'join_invoked': True}
    except Exception:
        return {**held, 'source_mutations': None if invoked else 0,
                'join_invoked': invoked}
