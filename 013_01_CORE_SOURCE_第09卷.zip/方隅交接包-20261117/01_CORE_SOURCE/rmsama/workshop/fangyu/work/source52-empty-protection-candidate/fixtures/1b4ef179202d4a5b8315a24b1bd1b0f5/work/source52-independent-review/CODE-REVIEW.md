# Source52 exact9 非作者代码与本轮因果审

结论：发现 1 个 P2 人员入口可达性遗漏，本冻结版本暂不作通过结论。其余下述必要权限、回执和 transport 范围未发现新的 must-fix。未执行候选、QA、App、GUI、真实 SDK 或任何外部请求；未改正式、作者、中央文档或 Source50/51 图。

本次只审 `source52-store-manager/FROZEN.json`：20306 字节 / `44446145C039640067278B2247A5ACAC6709753E6FA3DA7F836B63BFA20C3465`。独立读回 49 项声明 pin 均一致；另记录现有公开 `owner-admin.mjs` 的观察 pin，共 50 行，详见本目录 `PIN-READBACK.json`。9 个既有目标、0 新目标；服务父为尚待真实 Source51 后继的 C4D44315…，不是当前正式 service。没有把未来候选当成已经安装。

## Finding：P2，恢复连接后没有可达的人员能力核对入口

文件：`candidate/work/app/src/web/workspace/app.mjs`，受影响现接缝 L32–51；新探测仅 L1312。必要配合代码：`member-admin-ui.mjs` L36、L60–66；`app.mjs` L129、L1162–1164、L1337、L1375。

可从冻结代码完整推出以下路径：

1. development workspace 的正常恢复入口 L1287–1300 接受带 `development_local_only=true` 的本机 operator，再进入 `enterWorkspace`。成员模块 L36 此时拒绝授权，L1312 的初始 probe 不调用 members；L129 及 L1163 将 team-tab、admin-nav、account-menu 的 team 入口隐藏。
2. 原 `checkDevelopmentIdentity` L32–51 之后成功接受当前身份的远端 me 和顶层 false。新 transport L61–64 会换 actor；app L44 也更新 user，随后刷新设备、任务与原 profile/latest。
3. 这条恢复链没有 `refreshTeam` / `probeMemberEntry`。全文件唯一 probe 调用仍为 L1312；其他成员读取由已隐藏的 team 菜单/页面触发。已获本店 grant 的 operator 因此在恢复连接后仍无正常可见入口取得 fresh members capability，需要重开/重新进入。

本轮 DOM 故事直接调用 `ui.load()`，故其成功不能证明 app 的恢复入口可达；这不是 SDK、权限绕过或真实账号问题。已向 Root 和作者发送准确行与最小约束，没有自行修改。

最小修复要求：复用现有已确认恢复身份接缝，给当前普通 operator 可达的只读能力核对路径；能力仍只来自 fresh members，不从 me/user/local store 缓存 grant，不打开 review、maintenance 或总部准入功能。尤其不要为自动恢复探测而自动解除既有未知保存 hold；可以让核对由可见的只读入口主动触发，或只在不存在未知保存的首次能力获取状态探测。作者应选择最小接线并给 1 个新因果代表，不能以直接调用模块 load 绕过 app 可达性。

最小必要代表建议：同一公开 app/transport 接线，初始 operator local-only → members 未发送且 team 隐藏 → 当前身份 me 恢复 false → 通过正常可见核对路径接受当前 store capability → team 可见而 HQ 菜单仍隐藏；插入既有未知保存时，不得因自动恢复读取清 hold或重提密码。此建议尚未执行，不是本审已有运行证据。

## 已核的必要代码与本轮证据

- **权威权限事务**：service L18–31、L183–205、L253–308 从当前 session/user 派生固定店 grant 和 scope stamp。manager 名单仅本店 operator，自己/peer manager 不可编辑；服务端在同一事务再次拒 cross-store/self/peer/admin/partner、角色/转店/grant/can_reply 提升。新员工固定本店且 can_reply=false；客户端不能写内部 grant。三角色枚举保持。create/update 409 保原账号；旧 HQ 不带新字段保旧 upsert 兼容。
- **grant 与权益**：L294–303 清旧内部 grant，HQ 显式 true 只给启用且有效店的 operator；新 grant 或转到新店重授需 team。omitted grant 的改密只保同店 active operator 原 grant；停用/转店/改角色不迁。原 product_entitlements L62–69 保席位/店额度、过期减量；所有保存 L306–307 撤目标 cloud sessions/remembered devices。额度越限本轮未独立运行，只核成熟原接缝仍被实际调用。
- **新 DTO / native 双门**：publicUser 仅增 bool，内部 grant 不公开；members 增 actor、scope、operations、can_edit，UI验证完整当前cap/所有行 bool 与本店范围。Owner L109–118 仍真实 user 身份；L127–153 手写新 grant POST 先读 members 能力与公司/admin/scope；L195–209 对成功 bool、actor、scope 再核。缺 cap 在远端保存前409；缺成功 bool变未知503。原 Host、Origin、cookie、CSRF、固定 HTTPS 和 `_cloud` 公司/环境校验保持，没有借 AI 身份。
- **UI 与 transport**：两份 member UI 字节相同。L60–83 读取前清旧cap/名单/编辑值，按 epoch/company/env/actor/read revision 接受；L85–107 保存绑定 editor scope，busy阻并发读，未知需 fresh 当前范围读回，cancel/旧edit不解除。回执 bool/scope/成员值不符按未知处理。401 沿真实 local transport L45–49 清前端 user/token/epoch；稳定 bool L63 保 actor，restore/login 返回 this.user并纳顶层bool。登录、超时、0自动重试保持。没有把本机身份缓存或公开 user.can_manage_store_members 当作 grant。
- **正常在线 app 装配**：L1457 模块绑定 onScope，L1312 入工作台主动probe，L1163 单独控制 team-nav/menu；L163 本机仅允许 store scope进入 team，review/maintenance 保旧限制。原生 owner-admin.mjs L151–170 的 admin identity及memberEpoch装配仍在。上述是静态装配核查，P2 是其离线恢复分支遗漏。
- **未知错误接缝**：employee_workspace L438–452 只对 members/member_save 映射明确远端400/401/403/409/422/429；网络、无status或其他未知为503/None。App future50 L992–1004 将 WorkspaceError 状态实际传至 transport。Integration `_cloud` L451–454 仍核 contract/company/env，verify_identity30秒缓存没有缓存人员grant；401只确认前端清理，不声称删除 DPAPI/Cookie。

本轮真实载体审阅而非接受作者 PASS：`http-story.py` CEC21958… 的 L49–51 只在真实 service200 后制造 URLError，L90–100 通过另一公开合成 login 确认提交，再核员工 HTTP503/None；L113–115 实际执行并检查 DOM 子结果。DOM carrier B10A8F38… L31–58 用真实 WorkspaceCloud与 owned AppServer HTTP，覆盖本店创建、单次未知保存hold、主动fresh名单读回、晚回epoch、旧company编辑拒；L79–88 覆盖真实撤权401与login/restore同actor。主结果记录 8 个主事件；DOM记录 11 个子检查。

新增 native 缺 bool seam只属于 c281：cloud-fixture L20 先 await 真 service，L21记录200，L23仅删运输 DTO bool；DOM L65–68 的手写 POST得到本机503。没有调用模型、发送平台或伪造 service失败。FROZEN与最终结果精确绑定当前载体；不是独立重跑。

## 证据与边界

最终 main：10726 / `51680491E45C5F0BF17BEB4B8B2B5C9C3C47D562C52F5E9CC46BD4CD919F30FF`；最终 DOM：2828 / `B4A6F7FEFA5094EE4D27F89B1E6FBF924CF337978E6F778277DA10682FD1B707`。四当前 carrier和真实 transport子依赖的完整 pin在本目录JSON。

HISTORY-NOTE如实限制：旧 f0/d7 DOM/cloud子载体当时完整字节或SHA未全部保存；d7与c281主carrier/8events一致，新 seam在c281子carrier。没有倒推旧结果含新增断言，未补历史、重失败或称全部首失败完整保留。

本审没有完整浏览器页面/GUI/真人账号、生产SDK、云部署、真实额度/店配置、正式Source52安装或明晨验收证据；自有故事仅隔离 Core/SQLite/DPAPI、JSON SDK事务适配器、owned loopback。shared默认关闭；Source51 另外三公共依赖 pin核对但不重其业务QA。508依赖快照仅固定索引和必要6文件读回，没有全量hash/二进制QA。

后继仍需 Root 真51receipt、父字节和保护图后另审装载；本审不授权 apply。P2修复及精确新freeze到来前，本结论仅覆盖本次exact9。
