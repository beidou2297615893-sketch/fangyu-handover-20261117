# Source52 revision2 必要增量非作者复审

结论：首审 S52-P2-RECONNECT-CAP-ENTRY 在本冻结 revision2 的必要范围已修复；3 处增量未发现新的 must-fix。结合首审未变 6 件的结论及本次合成图核对，Source52 revision2 exact9 可供 Root 继续后继图绑定。此结论不是实际合入授权、完整页面/GUI、生产云部署或真人权限验收。

固定输入：`source52-store-manager/revision2/FROZEN.json`，20693 / `737719494423FEB5F5F928735264629188C7A94F24C19B7C680811480DB94517`。首冻结 44446145…和首独审 MD 8089 / 2CF932B4… CHANGES_REQUIRED 保留，未覆盖或改史。首 c281 业务证据未重跑，其 HTTP/DOM 只证明首候选字节，不冒它运行了本增量。

本次读审差异为 app.mjs 与两份相同 member-admin-ui.mjs；其余 6 件仅核必要精确继承，没有重审业务或执行旧矩阵。独立 pin 单 `REVISION2-PIN-READBACK.json` 记录 60 项固定 pin 全符、9 项图关系一致和 3 项 raw 函数提取校验一致。九合入父与首冻结的 target/parent/parent_source/parent_kind/original_parent_source 完全相同；6 候选与首候选实际逐字相同。两份新 module 均 12540 / `ED6D2F52ABA1677CCAAB90A51BFD676A47F42972755CB39824380D083393C408`；新 app 156088 / `66A32B03AC5B59CFF72A9136003E330A7926B5A6D2DEC98F61F4982D3BA6F3AD`。

## P2 关闭的代码依据

`app.mjs` L38–46 复用原 generation/visibility/closing/epoch/id/tenant_id/username 的 sameSession 门。在 me 已核当前身份且顶层 false 后，L44 把 false 纳入新 actor，L45 `await probeMemberEntry(sameSession)`，L46 再核当前会话，之后才续原设备/任务链。这样恢复探测不依赖初始被隐藏的 team 菜单，也不会在身份或 epoch 已变后续恢复旧导航。

L1166 的 probe 直接用真实 memberAdmin.probe；L1461 仍将同一个 cloud.call、user/epoch/company/environment/localWorkspace 和 onScope 接入模块。函数初始化顺序保原装配；probe 调用只有已装配后的初入 L1314 或原 development 身份观察恢复，不从 profile、me bool或角色标签猜 grant。

module L60、L83、L110 的唯一增量是复用原 load 传 `releaseUnknown=false`。因此自动 probe 保全部授权、busy、accept、actor对象、company/env/epoch/readRevision、服务端范围及 DTO 校验；可接受新当前 scope并让 team 的只读核对入口可见，但不清 needsRead。原主动 load 默认 true，在接受当前范围名单后才解 hold，并提示密码未独立核实。保存函数、请求协议、server权限、三角色、can_reply、总部/合作来源入口均未变。

sameSession 通过 accept 同时进入读取前和结果接受门；401实际 transport先清 user/token/epoch，模块读取前已清旧cap/名单/密码，probe捕获失败后 app的第二道 sameSession门停止后续恢复。普通 staff403同样不能创建 scope。过期回包无法靠自动probe恢复旧editor或导航。新代码没有重提 member_save、缓存 grant或扩大本机 admin/HQ功能。

## 新因果证据的审结

读取作者当时载体与结果，未把作者 PASS 直接当结论。三个 run 都在载体 L17–18 用 CreateNew 保 app/module/transport/carrier 四份 raw；这些文件现字节与 FROZEN 和结果的对应4pin均一致。独立从当时 app raw按同一切片规则重算 source_function_pin：首 RED 2050 / 49ACACE9…，两个 GREEN均2182 / 70824AC3…，吻合各结果。没有执行 VM 或候选。

- 首唯一 RED `79d100bc-7d97-41cc-8123-e22b18568291/FIRST-RED.json`，861 / `89058542BCDFF5E54423996B04EE873A0F8922F32E1AB6EA8167466C49AE463E`：首app/module真实函数恢复只发 me，team隐藏，members计数0，与首审静态P2相符。
- 新四分支 GREEN `04cbaf9d-c1f8-4e94-96a0-54e102b88b34/RESULT.json`，1844 / `3147A1F6790417665A90FAD9EF0CBD21ABBC9F06F569C449B043767F7655446B`：载体L70–81 从local-only初probe不发送members到当前me false后一次members，store能力使team-tab/admin-nav/team-menu可见；L82–89 真实模块的503未知保存后自动恢复读仍save disabled，reset/submit不增第二次write，主动load后才解hold并保密码未核实提示；L90–95晚回epoch变化拒scope及普通staff403拒入口。
- 单独401 GREEN `cfe94d4d-5ca4-4b9d-85c7-cc94d6ce4bfa/RESULT.json`，1160 / `423E768F09E55548872C6091BDD2B07BD921A4508B99AD65E15317D8BA103C9E`：独立载体只跑一个新增401分支，真实 WorkspaceCloud响应门清user/token、epoch7→8，scope/list/password为空且team隐藏，没有重放前4分支，也没有DPAPI删除声称。

这些新载体从 app快照取原 checkDevelopmentIdentity/stop watcher/refreshTeam/probe/syncMemberEntry 函数体，在 VM 中与真实 module及已审实际 WorkspaceCloud组合；browser me/members/503/403/401 回包、DOM和device/task边缘均明确录制。HTTP=false、完整app import=false、GUI=false。新四分支中的 review/maintenance initially hidden保持不变，证明新sync未打开它们；完整页面的HQ门仍依首审静态接线，不能把该断言当成完整页面权限运行。

## 严格边界与后继条件

这次只复审 P2增量，未重 c281、Source51业务或其余6目标；旧 f0/d7子carrier保留不足仍按首HISTORY-NOTE限制，不因本轮新raw快照补齐而改旧结论。未全hash508依赖、未读真实DB/Cookie/账号/数据、未跑App/GUI/SDK/平台/模型、未部署或改正式/作者/中央/50/51图。

九合入父中 service依然是 Source51 frozen successor C4D44315…，后继必须先有真实Source51成功回执和正确父/保护读回，再由 Root 独占合入。首cas-draft仍绑首九 literal，不能凭本审自动激活；Root须用此revision2 exact9最终pins绑定并另审装载。上述真实外部和整页验收维持未验证。
