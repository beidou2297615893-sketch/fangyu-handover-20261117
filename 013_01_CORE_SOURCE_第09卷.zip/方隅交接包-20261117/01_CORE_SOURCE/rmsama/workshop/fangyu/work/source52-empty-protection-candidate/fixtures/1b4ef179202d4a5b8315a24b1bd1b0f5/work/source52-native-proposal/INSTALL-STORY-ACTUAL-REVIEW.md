# Source52 两薄文件：唯一七分支非作者实际结果读回

结论有限PASS，无must-fix。仅核作者唯一两薄文件自有安装故事的raw／bodyAST关联、七分支结果与九关键own物理artifacts；没有重跑installer/guard/故事/Windows/业务，没有当前机器CIM／进程／App查询或控制，不修改Root／正式／作者材料。它不同于九目标Source52业务CAS状态故事，不能代替真实最终graph／安装授权，也不证明客户当前idle。

实际入口 `C:/积木软件工坊/项目/方隅公寓客户版/work/source52-independent-review/INSTALL-STORY-READY.json`13231 / `FA37F40635A60E3DE763F811584CB7C77DF7AFE10B3860B116D9C93055B9CEAB`。唯一完成run为 `install-story-runs/ab5c91630a2a4eccbb07c8fcf7828451`，RESULT7740 / `4A4E247203451BDE952C32B5FCEA6BC819BCEF40DC26728897E7C314B6C6048A`。READY列明的原raw、FIRST-FAIL、carrier、history与RESULT pins实际全部吻合。

## 控制body与边界实际关联

Root `C:/积木软件工坊/项目/方隅公寓客户版/work/source52-root-integration/install_native.py`8555 / `E365AFAD4AD3E1E7C45A5882652983AC6A88A6ED3243E8BDBE43A1B9ACB74378` 实际字节等于完成run installer-snapshot，Root INSTALL_AUTHORIZED仍False。carrier-snapshot12940 / `46ED0395FB982EFFE7C8B5B67BB3308F9D0DD5046C38243BFD2362404B35F221` 的24–29、71–76行直接选原proof/absent/main三个function AST与Source44五工具，未改控制语句后compile/exec入own fixture globals。control AST摘要SHA256 `F0041639A6FC0412CBE185937BBCB378908F70CC521AE4457E821FCB345FEC86`；Source44五工具AST摘要 `2EC224818D54697DE6B9918346D2CDB5395FC9C86E545717DBEB67DD4FAD4066`。完整Source44 snapshot9601/5F5E3EA2…实际匹配。

guard snapshot5948 / `1E97220595CCD6954F67FAABFCAE83E52734D4EE59188F0657C9B0363FBA3AA1` 实际绑定已单独审CODE＋四ownedWindows代表报告6162/6A619971…。这里guard的PowerShell完成输出是subprocess.run录制：carrier78–90行按case hook注入idle/live/unknown，83–84行仅校验own PROJECT的正斜杠路径和无原客户entry路径。不执行真正WQL或新的Windows代表，不能将这次录制归为实际CIM PASS。

权限True、四fixture pins／graph metadata、PARENT与IMMUTABLE及薄文件payload都明确录制。normal的27/29byte新payload、29byte旧launcher和46/48byte旧helper是自有合成文本；“immutable保持”只指这些ownfixture文件，不是原生产50/51helpers原字节。Root最终真实prepared/gate/manifest/helpers与父pin须另审。这次main只执行自有filesystem/CAS，不执行业务50/51/52 payload或App。

## 七分支与必要物理结果

| 接缝 | 实际非作者读回 |
|---|---|
| normal | 两final普通文件匹配owncandidate、唯一oldlauncher backup匹配original parent、own50/51 immutable匹配receipt pins；receipt2149/B0C0833D…存在、FAILED不存在、0相邻Source44 temp。真实own文件backup/temp/fsync/rename/replace行为来自原body与Source44。 |
| initial live | 录制firstguard live；physical新helper不存在、launcher仍old、backups父内无child、无receipt/FAILED、0temp。拒绝在备份与目标改动前。 |
| initial unknown | 同上，仅状态unknown；没有借unknown继续写、无重试声明。 |
| backup_base junction | `junction/backups/source52-native` 实际lstat仍有reparse属性，readlink指向同owncase `own-junction-destination`；目的地实际空，没有UUID/backup。helper无、launcher old、无receipt。只读该ownartifact，不创建/删junction、不跟踪客户路径。 |
| final seal drift | 第四guard运输hook注入foreign helper；actualforeign helper保留、launcher actual恢复old、无成功receipt、有FAILED。不能以运输idle结果跳过随后final-pin封口。 |
| rollback foreign | 第三录制guard live触拒，第四rollback guard idle时hook改helper为foreign；physicalforeign helper保留、launcher old、FAILED保留，无成功receipt。carrier审计hook实际记录target_unlink_calls0；不以写前ownership判断覆盖/删除guard后的新foreign。 |
| rollback live | actual owncandidate helper仍在、launcher old，FAILED660 / `43379BFFA6F4FD253952AB2417A0D5E6C1C8D1CF3BDE783EEF907337399C5EFE` 中held true。CONTROL2记录ValueError且guardcall列表与CONTROL1相同，FAILED rawpin保持，拒再次提起安装。 |

七case的own50/51合成immutable与0相邻temp实际核对。九关键实际artifact逐个读回为：normal两个final＋一个parentbackup＋两份immutable（5）；seal-drift foreignhelper（1）；rollback-foreign foreignhelper（1）；rollback-live retained candidatehelper＋FAILED（2）。其完整路径/pin保存在独立READBACK，另核各case launcher／receipt／first-control／reparse状态。这些物理证据与carrier注入时序、原body关联一起支持上表，文件数本身不代替因果。

## 两次首carrier失败历史

INSTALL-STORY-HISTORY.md2843 / `44E072D6504EFFB729BF4E93AB26C1806D65FC59258FBFFE243215ECF2F6DCEF` 及原raw已实际读回。

- 413aa0…FIRST-FAIL981 / `54C782328A04E20B9CF2F1D6854F3FDC32A210AC9CDF5BDA2DA5503012BFD83B`，carrier12549/AFC696C2…。completed_cases空。首transport用了未经过LIKE/WQL/JSON层的rawWindows路径作substring，guard fail-closed后normal外层assert失败；未走到installerbackup/targetCAS。补fixture既有backups父是准备修正，首run未触达，不能冒已执行到另一个失败。
- 59e9fc…FIRST-FAIL981 / `3FFC4888E471E9C98FEDC4B93D15736B7220D26F66A4B9B8A9C24BF047B663F3`，carrier12860/5D55E6EF…。completed_cases空；CONTROL-1说明recorded_guard_calls空，双backslash substring仍未适配JSON层。最终只修carrier正斜杠fixed-own路径校验与invoke日志编号/已授权junction命令运输，Root installer/guard不改。

两个FIRST-FAIL只保存外层assert，未泄出guard内部原异常；精确根因的说明来自保留carrier代码与CONTROL记录，不能把FIRST-FAIL自己冒成内部异常实录或产品RED。最终RESULT的first_unexpected_failures空仅指最终run，不能说整个工作没有这两首失败。首材料不删、原pin不覆写。

## 独立产物和最终范围

独立 `C:/积木软件工坊/项目/方隅公寓客户版/work/source52-native-proposal/INSTALL-STORY-INDEPENDENT-READBACK.json`33223 / `CCFB3AF0F3BD3B49F8422B4807005A32FD42A517FB74F254E93009ACC82E014E`；只读reader9006 / `E776FCE95BA7AB43E0B4EEAED1ADE9FAF288EE9F8341D1B50AA90554BC6D71D1`。没有运行任何author控制函数、installer、guard/source_state、CIM/进程/Windows故事/业务QA，没有读正式SRC/原backup/DB/Cookie/Vault，没有Root或作者稿写入。

限定CODEbody关联＋own文件安装/rollback＋录制运输与权限PASS；真实当前idle、最终Rootgraph与安装授权、实际正式两薄接线/业务50→51→52、GUI/平台/真人/云或商业完成不在范围。Root INSTALL_AUTHORIZED=False不能仅依据本报告直接视为最终授权常量已审通过。
