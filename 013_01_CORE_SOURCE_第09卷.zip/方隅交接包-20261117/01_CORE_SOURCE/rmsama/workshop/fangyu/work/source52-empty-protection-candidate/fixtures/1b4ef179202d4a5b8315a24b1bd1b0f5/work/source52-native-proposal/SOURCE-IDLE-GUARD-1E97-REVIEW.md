# Source52 guard 1E97：CODE delta＋唯一必要 owned Windows代表

结论：`source_idle_guard.py`5948 / `1E97220595CCD6954F67FAABFCAE83E52734D4EE59188F0657C9B0363FBA3AA1` 的 CODE delta及本轮四项必要自有Windows/PS5/WMI承载代表有限PASS，无must-fix。这个结论不证明当前客户source idle，不审核最终CAS/helper/installer绑定、锁时序或最终安装授权；0source_state、0原客户PID查询、0App/正式byte-lock/平台/业务/真实数据调用。

实际guard路径为 `C:/积木软件工坊/项目/方隅公寓客户版/work/source52-root-integration/source_idle_guard.py`。前A8B的Windows HOLD、首F33/静态意见、前建议withdrawn纠正和完整失败证据全部保留；本后继只覆盖Root定点修正的新固定pin。

## CODE差异实际核验

以已实读A8B snapshot5688 / `A8B4475C9E0EB3FDB57C5CAE791A0D7953F432E434FE4F21AFB1C9D2B93DF398` 为父，own verifier构造exact三项AST变换后，整module AST（不含行号／注释）逐结构等于新guard；不是仅函数名或diff标签比对。

| 必要修正 | 新源码行 | 核验 |
|---|---:|---|
| LIKE string-parser backslash doubling | 27–32 | 原fixed双引号delimiter与非法双引号拒绝保持；仅return中的value增加backslash→doublebackslash，之后LIKE literal bracket行为保持。单引号作为双引号内部数据，JSON/PS层doubling保持。 |
| raw controls换成无control的negated printable range | 46–52 | 原blanks.extend(raw SP/TAB/CR/LF/VT/FF)仅换blanks.append `[^!-~]%`；NULL/empty仍在，Name/runtime/aliases/dynamic patterns全部保持。这个ASCII范围保守包含所有非printable首字符及Unicode，可能额外unknown，不放开来源。 |
| module-progress运输 | 62–64 | 仅PS program增加 `$ProgressPreference='SilentlyContinue'`；ErrorActionStop、CIM错误、timeout、stderr/schema fail-closed与live优先均未改。 |

其余module docstring/imports/constants/functions与父AST相同。三客户根＋原entry、仅SELECT ProcessId、server fixed predicates、caller严格等于os.getpid、仅caller/query-child两项排除、NULL/empty与runtime缺归属unknown、禁止私态/CWD追查及异常unknown边界仍是首窄审范围。由AST关系复用先前六成功case，不重跑原alias/dynamic/forwardslash项目。

CODE-DELTA.json实际554 / `F8B378022B213580041DFA50CF3007EEA1F79FC86A7483911C1AEA7BCF7D74DC`。

## Root批准的唯一newpin必要Windows代表

只spawn一个自有Python dummy55584，caller63464；每条CIM query在server WHERE明确 `ProcessId = 55584`，仅 `SELECT ProcessId`，另排除caller和这次query PS自身。未调用source_state或原客户source query。AST仅exec新pin四纯builder定义，固定ALIASES/RUNTIMES，SOURCE_PATHS在owned carrier namespace用假中文路径替代；Root候选和正式图不改。

假路径 `C:/自有WQL兼容/O'Brien/work/owner_admin`，fixture参数使用Windows backslash形式。为实际leading SP，CreateProcess/Popen使用固定miniconda python.exe explicit executable，raw commandline以一空格开始，后接-B/-I/-c owned stdin等待代码和假路径。raw中不重复exe token，使CRT空argv0后正确解释options；ARGV／raw commandline完整保存。实际dummy待stdin、查询完自然退出0，dummy stderr为空。

| 本轮四项新case | expected | observed |
|---|---:|---:|
| double_backslash_Unicode_apostrophe_literal | 1 | 1 |
| literal_underscore_negative_ownerXadmin | 0 | 0 |
| complete_new_unknown_compound_parses | 1 | 1 |
| negated_printable_range_matches_real_leading_SP | 1 | 1 |

四项各执行一次，0query error／0count mismatch。八条CASE_START/CASE_RESULT即时trace实际保留；PS exit0且stderr空。测试通过意味着当前字符串parser层doublebackslash确实被WMI解释为路径匹配，underscore负例没有通配泄漏，完整newunknown谓词可parse，并且无rawcontrol的range实际匹配前置SP。它不是整个机器的idle／future race／任意注入证明。

actual RESULT1251 / `A391CC658B9AB0FF1A42250AD0A6689B026E52E8C64DCA5A8E4374F8F0BA2111`，TRACE4049 / `D7488AA314A4558F7F3800788781025AAB236B570BFB9D58CB14F42A14B04A7A`。

## 证据与首carrier失败保史

实际成功唯一目录：`C:/积木软件工坊/项目/方隅公寓客户版/work/source52-native-proposal/owned-wql-guard-1E97-606646d56c144ee0b86f40acca0a2be2`。

| 文件 | bytes | SHA256 |
|---|---:|---|
| guard-snapshot.py | 5948 | 1E97220595CCD6954F67FAABFCAE83E52734D4EE59188F0657C9B0363FBA3AA1 |
| verify-carrier.py | 12866 | 1800F4B1FE7344D236253CCCCC9C2DA3660C79545618B6DB541B9E8742F549D9 |
| CODE-DELTA.json | 554 | F8B378022B213580041DFA50CF3007EEA1F79FC86A7483911C1AEA7BCF7D74DC |
| RESULT.json | 1251 | A391CC658B9AB0FF1A42250AD0A6689B026E52E8C64DCA5A8E4374F8F0BA2111 |
| TRACE.jsonl | 4049 | D7488AA314A4558F7F3800788781025AAB236B570BFB9D58CB14F42A14B04A7A |
| PS-CARRIER.ps1 | 3276 | B601E1DD3AAE76A97D4584C62E14289294C2412B99BC1B44BFDA45CE3153067F |
| ARGS.json | 308 | 48A54AD0AA3450ED6B6F24BFE3C554AF5B2C1EAC339DDE0F26B3313F8D3A7324 |
| CASES.json | 1498 | AB96693B3A45487932F8FB959636120C8765D9FB1341F49E1A102CA93C8FB4C8 |
| PS-STDERR.txt / OWN-DUMMY-STDERR.bin | 各0 | E3B0C44298FC1C149AFBF4C8996FB92427AE41E4649B934CA495991B7852B855 |

PS-CARRIER-UTF16LE.b64、PS-STDOUT.txt、RAW-READBACK.json和old-guard-snapshot.py也原样保留。

另在 `owned-wql-guard-1E97-588a4803916e4ded8a9bec8460b7a9f2` 保留own carrier第一次纯AST准备错误：program selector未限str Constant，同时选中了后续program.replace赋值，assert在Popen前失败。其verify-carrier.py、guard snapshots、PREPARATION-FIRSTFAIL.json、HISTORY-NOTE.md保史；仅修own selector，0spawn/0CIM，非guard失败。随后唯一actual四case代表在上面的成功目录执行，没有参数轮询、多次actualspawn或旧QA重跑。

后续Root可将此固定guard与报告纳入native图／新状态故事；仍需独立审核真实CAS/helper绑定与原锁内实时检查时序。不得用本范围PASS直接翻最终安装授权常量或称当前客户source idle、Source52实际已合入或商业／真人／GUI验收。
