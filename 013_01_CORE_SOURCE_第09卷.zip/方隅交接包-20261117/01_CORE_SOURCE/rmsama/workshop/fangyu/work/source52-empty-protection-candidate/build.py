"""Build only two owned repair payloads. No production writes or executable calls."""
import ast,hashlib,json
from pathlib import Path
OWN=Path(__file__).resolve().parent;PROJECT=Path('C:/积木软件工坊/项目/方隅公寓客户版');DESKTOP=PROJECT/'work/desktop-self-use-entry'
FUTURE=PROJECT/'work/source52-root-integration/empty-protection-r3'
def pin(raw):return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest().upper()}
def jb(v):return (json.dumps(v,ensure_ascii=False,indent=2)+'\n').encode()
def dump(p,raw):
    with p.open('xb') as f:f.write(raw)
    return pin(raw)
def main():
    red=json.loads((OWN/'ACTUAL-RED.json').read_bytes());assert red['status']=='DEFECT_REPRODUCED' and red['empty_protected_files']==8
    helper=(DESKTOP/'next_open_source52.py').read_bytes();launcher=(DESKTOP/'source_next_open_launcher.py').read_bytes()
    assert pin(helper)=={'bytes':15623,'sha256':'1C919E94AA3477E6ABC17EA6B4BC348ACD2E13161FA96E9CC0622AE112FF1FAF'}
    assert pin(launcher)=={'bytes':5405,'sha256':'994ED84BB4AB1154290AB1AA8E291B1976E0C03C3076C7B22ACF73C189D83D26'}
    text=helper.decode();newline='\r\n' if '\r\n' in text else '\n';needle="or not _proof(x['pin']) for x in protected)";assert text.count(needle)==1
    text=text.replace(needle,"or not _protected_proof(x['pin']) for x in protected)",1)
    fn="\r\ndef _protected_proof(value):\r\n    # A fixed protected empty file is legal; targets/authority stay nonempty.\r\n    return (_proof(value) or (type(value) is dict and set(value)=={'bytes','sha256'}\r\n        and type(value['bytes']) is int and value['bytes']==0\r\n        and type(value['sha256']) is str\r\n        and value['sha256']=='E3B0C44298FC1C149AFBF4C8996FB92427AE41E4649B934CA495991B7852B855'))\r\n"
    fn=fn.replace('\r\n',newline);anchor=newline+'def _plan('
    assert text.count(anchor)==1;text=text.replace(anchor,fn+anchor,1)
    newhelper=text.encode();ast.parse(newhelper);hp=dump(OWN/'next_open_source52.py',newhelper)
    text=launcher.decode();n=next(n for n in ast.parse(text).body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='LATEST_PIN' for t in n.targets));old=ast.get_source_segment(text,n)
    text=text.replace(old,'LATEST_PIN='+repr(hp),1)
    fn="\r\nOPEN_FAILURE_MESSAGE='启动核对未通过，本次窗口尚未打开。请保留现状，等待本次启动问题修复。'\r\n\r\ndef _failure_message():\r\n    # Fixed normal-mode product notice; never exposes original errors or paths.\r\n    import ctypes\r\n    from ctypes import wintypes\r\n    user32=ctypes.WinDLL('user32',use_last_error=True)\r\n    user32.MessageBoxW.argtypes=(wintypes.HWND,wintypes.LPCWSTR,wintypes.LPCWSTR,wintypes.UINT)\r\n    user32.MessageBoxW(None,OPEN_FAILURE_MESSAGE,'方隅工作台',0x10)\r\n"
    assert text.count('\r\ndef main():')==1;text=text.replace('\r\ndef main():',fn+'\r\ndef main():',1)
    anchor="        # A missing/unreviewed gate remains a failed opening, not permission to\r\n        # use stale code or perform a different update/instance upgrade.\r\n        return 1"
    assert text.count(anchor)==1;text=text.replace(anchor,anchor.replace('        return 1','        _failure_message()\r\n        return 1'),1)
    newlauncher=text.encode();ast.parse(newlauncher);lp=dump(OWN/'source_next_open_launcher.py',newlauncher)
    plan={'schema':'source52_empty_protection_repair_payload_plan_v1','status':'OWNED_CANDIDATE_NOT_PUBLISHED','production_executed':False,'published':False,'installed':False,
        'files':[{'candidate':str(OWN/'next_open_source52.py'),'target':str(FUTURE/'next_open_source52.py'),'pin':hp},
            {'candidate':str(OWN/'source_next_open_launcher.py'),'target':str(FUTURE/'source_next_open_launcher.py'),'pin':lp}],
        'native_targets':[{'target':str(DESKTOP/'next_open_source52.py'),'parent':pin(helper),'final':hp,'candidate_public':str(FUTURE/'next_open_source52.py')},
            {'target':str(DESKTOP/'source_next_open_launcher.py'),'parent':pin(launcher),'final':lp,'candidate_public':str(FUTURE/'source_next_open_launcher.py')}],
        'unchanged':['all business authorities/gates/PREPARED/CAS','9 target parent/final pins and462 protected collection','original50/51/53 helpers and desktop_entry','EC86guard/byteOSlock/flags','original native52/53 rawreceipts/backups'],
        'native_repair_required':'Independent Root repair state/receipt/backup must prove original1C919E/994ED84 parents and new current bytes; never backfill originalnative receipts.',
        'Stage54':False}
    dump(OWN/'PLAN.json',jb(plan));print(json.dumps({'helper':hp,'launcher':lp,'future':str(FUTURE)}))
if __name__=='__main__':main()
