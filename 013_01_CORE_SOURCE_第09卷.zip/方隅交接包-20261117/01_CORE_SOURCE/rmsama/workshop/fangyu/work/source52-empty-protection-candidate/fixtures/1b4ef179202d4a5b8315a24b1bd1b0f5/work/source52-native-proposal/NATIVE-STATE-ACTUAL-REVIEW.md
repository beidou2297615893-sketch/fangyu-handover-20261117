# Source52 native 状态：非作者实际证据／控制AST／自有物理读回

结论有限PASS，无must-fix：作者四组新状态＋唯一local-transport独立父delta的冻结证据、必要实际ownpublic文件和控制AST关系吻合。未重跑任何故事／QA／Windows／guard，不调用loader/CAS/source_state、正式锁、App、CIM或平台，不读原客户SRC/backup/DB/Cookie。最终真实graph／prepared／gate／授权literal及安装仍是后续单独范围。

实际冻结入口：`C:/积木软件工坊/项目/方隅公寓客户版/work/source52-store-manager/native-state-design/execution/FROZEN.json`，17410 / `D8131B6BF014FC9D27AECCCBC68A3C218DA856838432E4D36E53859CA3A1E38A`；REPORT4113 / `23AD69D8C93B5F7DDCBA587C7DCC57C4202D867668C91ED0FE6DA70992D034E7`。所有列明path/pin实际读回匹配。READBACK-AST120883 / `0B3BDFE5DC372BCA44F8EDDF5E7214AA02F3AD524D27FFB1A01D5E46E3FB6652` 以本地筛选处理，没有把120KB raw返回上下文或执行其代码。

## 必要四组及独立父结果

| 因果接缝 | 独立实际读回结论 |
|---|---|
| normal／0e15cfc… | 实际52九replace、九existing目标／九原父backup／0new，九current final与九backup parent bytes均独立hash吻合，0相邻source52 temp。旧50/51 apply各1是明确recorder；52实际CAS各1。recorded fresh argv精确原-X utf8 -B -I，carrier195–199行实际打开own原instance.lock检验byte0/length1已释放后才记录fresh edge；没有真实fresh App。成功后future50/51/52 invoke全部0。 |
| guards／8ef47d…＋初始cd08bf… | 初始live/unknown两条继承已冻结case，52 STARTED前0invoke；续六分支无重跑。before_backups_and_temps unknown：0replace，own当前9parent。第二before_replace live：实际只1candidate留存，physical1final+8parent，rollback fresh live拒；before_success unknown：physical9final但无successreceipt，九rollback fresh unknown拒。已invoke首次source_mutations均null，FAILED/partial/backup保史；未来0invoke/0本次新写不等于旧未知已解决。未知STARTED/FAILED以及actual own另进程占同byte锁均HOLD/0invoke。 |
| rollback／0044e8… | 两次actual candidate replace后的owned IO中断。idle分支实际恢复自己的两件，physical9parent；foreign分支physical1foreign+8parent，继续恢复另一own项而保foreign，失败receipt里的restored false/true与实际字节一致。0相邻temp、FAILED原史与九backup留存、future0invoke。events的actual_replace也包含恢复写，不能把4/3条event误算成4/3次新candidate写。 |
| backups／62e032… | 缺51backup、串batch50backup均在52 STARTED前HOLD/0invoke；串batch故事的own原raw链篡改明确记录，不冒原生产回执。STARTED后缺50backup：52实际invoke1但在任何52backup/temp前拒，未知STARTED保留，不编造尚未生成的FAILED。第一candidate replace后缺51backup在fresh predecessor_backups_only门拒，idle own恢复；physical9parent，FAILED保留，future0invoke。 |
| 唯一local父／f6cdc… | local-transport不在旧50/51映射的事实被实际metadata核实；STARTED后注入其own坏父，52实际invoke1但0replace/0backup/temp，FAILED/unknown保留；physical8parent+1原注入bad独立父未被回滚覆盖，future0invoke。 |

## 三层父／回执与版本绑定

在normal自有fixture，raw50→raw51→actual52 receipt pins逐层实际匹配；九52backup与实际frozen52 parent相符。service.cjs的50旧层证明来自实际51 original-parent backup，51 C4父来自实际52 original-parent backup；当前52 final只用于52当前层，不能借它冒旧pin。其余七继承覆盖项的旧层／51层由actual52 parent backup证明；local-transport在两旧层皆无映射，只证明52explicit parent/backup/final。原50/51的apply、非本批前代public字节与部分保护/dependency内容是合成recorded fixture，不能将这些own backup写成原生产50/51真实合入证据。

独立实际检查17个ownroot中的六种绑定源码，共102关系：实际bound-source raw pin匹配、整module AST仅屏蔽经过明确列出的top-level路径／pin常量后与对应Root snapshot相同；不是相信作者的control_AST_unchanged布尔。17份Source44实际fixture副本都等于9601 / `5F5E3EA22AF7C1FA0FEA71CFEFDA12A9D669C190D5470960901029BF8F4750FB` snapshot，成熟filesystem/lock工具未改。这里只证明CODE关联；状态结论来自上表case/注入时序/物理结果，不能以文件数替代因果。

当时Root CAS snapshot30340/55B81D09…与helper15374/CBD8C9A5…及guard5688/A8B…用于故事，消费者PowerShell/CIM运输是recorded。A8不能称真实WMI PASS，Root实际RED两份和已withdrawn的反斜杠推断保持独立历史。

当前Root候选实际读回：

- CAS `C:/积木软件工坊/项目/方隅公寓客户版/work/source52-root-integration/join-source52-reviewed.py` 30340 / `DAA27AA127AC0FA9EE08DA4DD32EC274743352D2DFE7FD5DD18786610892B245`。整个AST仅SOURCE_GUARD_PIN赋值由A8变新5948/1E972205…，其它控制body、JOIN_AUTHORIZED=False保持。
- helper `C:/积木软件工坊/项目/方隅公寓客户版/work/source52-root-integration/next_open_source52.py` 15374 / `D9250FC3DCD2ED859DAF2CD5A98D54291A7D3681A3F8B3AF9813667E528B51BF`。整个AST仅GUARD_PIN赋值同一后继变更，其余body、JOIN_AUTHORIZED=False和MANIFEST_PIN=None保持。

该literal关系连接已单独审新guard5948/`1E97220595CCD6954F67FAABFCAE83E52734D4EE59188F0657C9B0363FBA3AA1`，对应CODE＋四项ownedWindows代表PASS报告6162 / `6A61997131FBC86C8C1261BEB4C0D5EB2BFDB2E58089180E277C5AAE2C03C630`。本轮没有重跑那些Windows代表，也没有调用当前source_state。这足够连接新parser/blank修正与已执行控制body，不把author录制运输当真实客户idle。

## 首失效和本轮边界

cd08bf…FIRST-FAIL1777/F36B4A0E…及当次carrier raw实际保留。首carrier的录制运输对包含[_]的固定root未还原literal，于是guard fail-closed unknown在52 STARTED前HOLD，作者随后期待已invoke的断言失败。初始live/unknown两个已完成case单独继承，后续只续六分支。这是运输assert问题，不能混同Root后来A8真实WMI InvalidQuery；两份历史都未删改。

本轮独立reader仅读frozen metadata、102ownpublic绑定源码、ownSource44、16已冻结case的九批public目标／ownmarkers、normal九backup和必要51backup／rawreceipt；没有读取旧367真实binary或原客户资料，没有执行状态故事、QA或CIM。physical回读partial/foreign和marker留存吻合，0相邻source52临时项。

独立材料存 `C:/积木软件工坊/项目/方隅公寓客户版/work/source52-native-proposal/`：

- NATIVE-STATE-INDEPENDENT-READBACK.json125046 / `6DCEE8B94386FF1CB50089302C35EA0AB1E6DF5F6D2081EB61C860B49D492056`：实际refs/AST/pins、normal父链和过滤case。
- NATIVE-STATE-PHYSICAL-READBACK.json48174 / `BD9E28575C941C664913B08DA1F9306DBEBADB62C9F1ACD335E6A078FB2683C7`：16case当前public状态、ownreceipt markers、相邻temp。
- read_native_state_actual.py9886 / `525F3DC171961BE5183356F0A954505C4381A0E6B63CDEA47FDCF40926971340`；read_native_physical_states.py3501 / `639897C3BE694462E90A8D14F54310761C24F715E7E2712F89E9AC92905E311D`，仅只读取证代码。

限定CODE／自有文件CAS、实际own byte-lock与录制边缘故事PASS；无真实App正常重开、当前idle、生产云、平台用途／真人、GUI或商业完整验收声明。当前False／None草稿不能仅凭本报告变为最终可安装。
