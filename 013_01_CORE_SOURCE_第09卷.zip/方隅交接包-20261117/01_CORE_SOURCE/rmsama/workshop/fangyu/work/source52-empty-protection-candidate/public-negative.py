"""Only two public metadata rejection seams; reuse passed owned fixture."""
import json,types,sys,hashlib
from pathlib import Path
sys.dont_write_bytecode=True
OWN=Path(__file__).resolve().parent
def load(p,n):
    m=types.ModuleType(n);m.__file__=str(p);sys.modules[n]=m;exec(compile(p.read_bytes(),str(p),'exec'),m.__dict__);return m
def main():
    t=load(OWN/'representative.py','own_negative_defs');root=Path(json.loads((OWN/'REPRESENTATIVE.json').read_bytes())['owned_root']);assert root.is_relative_to(OWN)
    m=[load(root/'work/desktop-self-use-entry'/f,'owned_public_negative_'+str(i)) for i,f in enumerate(('next_open_source.py','next_open_source51.py','next_open_source52.py'))]
    assert all(not isinstance(v,Path) or v.is_relative_to(root) for mod in m for v in vars(mod).values())
    h=m[2];paths=(h.MANIFEST,h.APPROVAL,h.PREPARED);before={p:p.read_bytes() for p in paths};fixed=h.MANIFEST_PIN;results=[]
    for kind in ('wrong_empty_protected_hash','empty_target_final'):
        manifest=json.loads(before[h.MANIFEST]);gate=json.loads(before[h.APPROVAL]);prepared=json.loads(before[h.PREPARED])
        if kind=='wrong_empty_protected_hash':
            index=next(i for i,r in enumerate(manifest['protected']) if r['pin']['bytes']==0)
            manifest['protected'][index]['pin']['sha256']='0'*64;prepared['protected'][index]['pin']['sha256']='0'*64
        else:manifest['targets'][0]['final_pin']={'bytes':0,'sha256':'E3B0C44298FC1C149AFBF4C8996FB92427AE41E4649B934CA495991B7852B855'}
        gate['prepared_manifest_pin']=t.write(h.PREPARED,t.jb(prepared));manifest['approval_pin']=t.write(h.APPROVAL,t.jb(gate));h.MANIFEST_PIN=t.write(h.MANIFEST,t.jb(manifest))
        try:t.guarded_call(root,lambda:h.reviewed_entry_pin_if_joined(m[0],m[1]))
        except ValueError as error:reason=str(error)
        else:raise AssertionError('malformed public metadata passed')
        assert reason==('Source52 exact protection graph changed' if kind=='wrong_empty_protected_hash' else 'Source52 exact nine parent/final graph changed')
        results.append({'case':kind,'public_metadata_refused':reason,'production_executed':False})
    for p,b in before.items():p.write_bytes(b)
    h.MANIFEST_PIN=fixed
    (OWN/'PUBLIC-NEGATIVE.json').write_bytes(t.jb({'schema':'source52_empty_protection_public_negative_v1','status':'PASS_LIMITED','results':results,'recorded_own_approval_rebound':True,'process_guard_preflight_apply_calls':0}))
    print(json.dumps({'status':'PASS_LIMITED','public_rejections':len(results)}))
if __name__=='__main__':main()
