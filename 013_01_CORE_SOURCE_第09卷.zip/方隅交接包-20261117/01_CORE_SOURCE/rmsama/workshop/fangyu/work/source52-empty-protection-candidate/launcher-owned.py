"""Root Source52 normal opening candidate. No final reviewed coordinator pin yet."""
import hashlib
import importlib.util
import json
from pathlib import Path
import stat
import sys
import os

PROJECT = Path('C:/积木软件工坊/项目/方隅公寓客户版/work/source52-empty-protection-candidate/fixtures/1b4ef179202d4a5b8315a24b1bd1b0f5')
ENTRY = PROJECT/'work/desktop-self-use-entry/desktop_entry.py'
HELPER = PROJECT/'work/desktop-self-use-entry/next_open_source.py'
SUCCESSOR = PROJECT/'work/desktop-self-use-entry/next_open_source51.py'
SUCCESSOR_PIN = {'bytes': 14697, 'sha256': '8540B5A0AE7572E5C2DC8A550AD74BA0918FF931C09945E7F802E0FB00F6EEF0'}
LATEST = PROJECT/'work/desktop-self-use-entry/next_open_source52.py'
LATEST_PIN={'bytes': 16027, 'sha256': 'B4F6BE4903F7E25F7C25B11F1CEAB96779CC60D26F511C1511E8257D012072A4'}
NEWEST = PROJECT/'work/desktop-self-use-entry/next_open_source53.py'
NEWEST_PIN={'bytes': 5903, 'sha256': '93DE3F1E74D9B010DBF5D68FD45AA836F19130F20B37CEB0CDFE9FA07DA6F4E1'}
# New candidate remains unauthorized and uninstalled.
# The one-time wrapper/helper must stay outside Source50's target/hash graph.
HELPER_PIN = {'bytes': 18590, 'sha256': '6DD31FBCB9864272C329C146DD7EA3E9F74F334131F84DDFEB5E3D63ED8BB611'}
ENTRY_PARENT_PIN = {'bytes': 15900, 'sha256': 'C2FEE1D2355A7A6605E807BFCC71E339D1C23B83D23E92913849DA4E96B980B3'}


def _load(path, proof, name):
    if (type(proof) is not dict or set(proof) != {'bytes', 'sha256'}
            or type(proof['bytes']) is not int or proof['bytes'] < 0
            or type(proof['sha256']) is not str or len(proof['sha256']) != 64
            or any(c not in '0123456789ABCDEF' for c in proof['sha256'])):
        raise ValueError('fixed reviewed loader pin absent')
    current = PROJECT
    for part in ('', *path.relative_to(PROJECT).parts):
        if part:current = current/part
        item = current.lstat()
        if current.is_symlink() or getattr(item, 'st_file_attributes', 0)&0x400:
            raise ValueError('fixed loader path changed')
    if not stat.S_ISREG(item.st_mode) or item.st_nlink != 1:
        raise ValueError('ordinary fixed loader file required')
    raw = path.read_bytes()
    if {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest().upper()} != proof:
        raise ValueError('fixed reviewed loader changed')
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    # Execute the already checked bytes, not a second unpinned path read.
    exec(compile(raw, str(path), 'exec'), module.__dict__)
    return module


OPEN_FAILURE_MESSAGE='启动核对未通过，本次窗口尚未打开。请保留现状，等待本次启动问题修复。'

def _failure_message():
    # Fixed normal-mode product notice; never exposes original errors or paths.
    import ctypes
    from ctypes import wintypes
    user32=ctypes.WinDLL('user32',use_last_error=True)
    user32.MessageBoxW.argtypes=(wintypes.HWND,wintypes.LPCWSTR,wintypes.LPCWSTR,wintypes.UINT)
    user32.MessageBoxW(None,OPEN_FAILURE_MESSAGE,'方隅工作台',0x10)

def main():
    if sys.argv[1:] not in ([], ['--check-only']):
        raise ValueError('ordinary fixed opening or check-only only')
    report = {'state':'held_pending_root_gate','check_only_no_business_loaded':True,
        'source_mutations':0,'join_authorized':False,'automatic_retry':False}
    try:
        # --check-only only checks fixed metadata. The optional helper has no
        # executable top-level I/O; its public metadata interface cannot write a
        # started note, take the instance lock, apply or relaunch.
        if sys.argv[1:] == ['--check-only']:
            entry_pin = ENTRY_PARENT_PIN
            if HELPER_PIN is not None:
                helper = _load(HELPER, HELPER_PIN, 'source50_fixed_next_open_metadata')
                successor = _load(SUCCESSOR, SUCCESSOR_PIN, 'source51_fixed_next_open_metadata')
                latest = _load(LATEST, LATEST_PIN, 'source52_fixed_next_open_metadata')
                newest = _load(NEWEST, NEWEST_PIN, 'source53_fixed_next_open')
                entry_pin = newest.reviewed_entry_pin_if_joined(helper, successor, latest) or entry_pin
            entry = _load(ENTRY, entry_pin, 'source50_original_entry_metadata')
            report.update(entry.preflight())
            print(json.dumps(report, ensure_ascii=False));return 0
        helper = _load(HELPER, HELPER_PIN, 'source50_fixed_next_open')
        entry_pin = ENTRY_PARENT_PIN
        successor = _load(SUCCESSOR, SUCCESSOR_PIN, 'source51_fixed_next_open')
        latest = _load(LATEST, LATEST_PIN, 'source52_fixed_next_open')
        newest = _load(NEWEST, NEWEST_PIN, 'source53_fixed_next_open')
        entry_pin = newest.reviewed_entry_pin_if_joined(helper, successor, latest) or entry_pin
        entry = _load(ENTRY, entry_pin, 'source50_original_entry_metadata')
        report = entry.preflight()
        if report.get('state') != 'ready_for_original_native_main':
            # No focus, stop, F5, model/platform or new question on a live/unknown main.
            entry.message(entry.LIVE_MESSAGE if report.get('state') == 'held_live_pilot' else entry.HELD_MESSAGE)
            return 1
        result = newest.before_normal_open(entry, helper, successor, latest)
        if result.get('decision') == 'continue':
            os.execv(sys.executable, [sys.executable, '-X', 'utf8', '-B', '-I', str(ENTRY)])
        entry.message(entry.HELD_MESSAGE)
        return 1
    except Exception:
        if sys.argv[1:] == ['--check-only']:
            print(json.dumps(report, ensure_ascii=False));return 0
        # A missing/unreviewed gate remains a failed opening, not permission to
        # use stale code or perform a different update/instance upgrade.
        _failure_message()
        return 1


if __name__ == '__main__':raise SystemExit(main())
