"""Freeze owned minimal repair only. Never modifies installed/public source."""
import ast,hashlib,json
from pathlib import Path
OWN=Path(__file__).resolve().parent;PROJECT=Path('C:/积木软件工坊/项目/方隅公寓客户版');DESKTOP=PROJECT/'work/desktop-self-use-entry'
def pin(raw):return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest().upper()}
def jb(v):return (json.dumps(v,ensure_ascii=False,indent=2)+'\n').encode()
def funcs(raw):
    text=raw.decode();return {n.name:ast.get_source_segment(text,n) for n in ast.parse(text).body if isinstance(n,ast.FunctionDef)}
def main():
    plan=json.loads((OWN/'PLAN.json').read_bytes());deltas={}
    for row in plan['native_targets']:
        baseline=Path(row['target']).read_bytes();assert pin(baseline)==row['parent']
        candidate=(OWN/Path(row['candidate_public']).name).read_bytes();assert pin(candidate)==row['final']
        bf=funcs(baseline);af=funcs(candidate);changed=[n for n in bf if bf[n]!=af.get(n)];added=sorted(set(af)-set(bf))
        if Path(row['target']).name=='next_open_source52.py':assert changed==['_plan'] and added==['_protected_proof'] and bf['_proof']==af['_proof']
        else:assert changed==['main'] and added==['_failure_message']
        deltas[row['target']]={'parent_pin':row['parent'],'candidate_pin':row['final'],'changed_functions':changed,'added_functions':added,
            'all_other_original_function_segments_unchanged':True}
    (OWN/'DELTA.json').write_bytes(jb({'schema':'source52_empty_protection_exact_delta_v1','targets':deltas,'9_nonempty_targets_and462_protected_unchanged':True}))
    report='''# Source52 empty protection and silent-opening minimal candidate

Fixed only two existing thin targets: H52 parent15623/1C919E94→16027/B4F6BE49; latest53launcher parent5405/994ED84B→5949/01106E9C. Author candidates are isolated in this directory. Future public payload paths are new work/source52-root-integration/empty-protection-r3/next_open_source52.py and source_next_open_launcher.py. No publication, installation, originalroot executable call, guard/PID/preflight/check-only/App/DB action or Stage54 work occurred.

Real defect: Source52 _proof bytes>0 was also applied to protected462, rejecting8 legitimate fixed length0/E3B0C442…B855 files. Original50/51 accept length0 protection. New _protected_proof applies only to the protection list: existing positive _proof remains unchanged; accepts exact {bytes,sha256}, integer bytes0 and canonical uppercase SHA256(empty). Boolean/negative/extra fields/nonstring/lowercase/wrong empty SHA remain refused. _plan changes one protection predicate. All9 targets, authority and guard still use the original nonempty _proof. Target/parent/final collection, protected462 list, signed business controls/CAS/prepared/guard/state/backups remain unchanged; all other H52 function segments match original bytes.

New launcher binds the new H52 pin. Ordinary exception now calls an independent standard-library Windows MessageBox with fixed understandable Chinese text, exposes no raw exception/path/private value, and returns failure1. It does not continue, bypass a proof or automatically retry. Check-only behavior, old held/live entry messages, original flags -X utf8 -B -I and helper50/51/53/entry pins remain. _failure_message is inert at import; actual user32/UI was not called by author tests. Root repair must give an independent repair receipt/FAILED/state/backup proving original H52/launcher parents and new current bytes. Original native52/53 rawreceipts must not be backfilled; old historical helper pin stays original and is proved via repair parent backup. Root sole writer; actual guard and exclusive repair remain separate prerequisites.

Evidence: ACTUAL-RED.json reproduces exact Source52 exact protection graph changed through a rebased owned real four-helper metadata interface with8 empty protected pins. GREEN uses actual rebased53 reviewed_entry→checkedCAS authority_plan→52 reviewed_entry/_plan→51/50 metadata; returnsNone as the approved fallback to original entry when receipts are recorded absent. A scoped audit hook rejects writes/private/outsideowned opens/process/guard/PID transport during this call, blocked actions0. Six malformed proof examples refused; PUBLIC-NEGATIVE.json also verifies wrong empty protected hash and empty target final through actual public52 reviewed_entry interface with independently rebound owned approvals. No old transaction or QA matrix is run.

Launcher representative records transport only: an early metadata exception yields exactly1 fixed notice and exit1, entry/preflight/guard/apply not reached, no private original error displayed. A recorded ready/held branch retains exactly1 existing held message and exit1. State absence, entry ready/held decisions and Windows MessageBox transport are recorded. No actual GUI opening, original live/dead state, source business application, cumulative production rawreceipt or user acceptance is inferred.

Carrier detail retained: the first build used a CRLF anchor for LF H52 and stopped before writing a payload; the immediately attempted green carrier consequently found no candidate file (CARRIER-RED-1.txt). Minimal newline-aware anchor fixed the builder. This is not an additional production defect. The actual original-protection RED was obtained before candidate implementation and remains unchanged. Final payloads did not change after GREEN. No old freeze/control or native evidence was rewritten.
'''
    (OWN/'REPORT.md').write_text(report,encoding='utf-8')
    inventory={str(p):pin(p.read_bytes()) for p in (OWN/'fixtures').rglob('*') if p.is_file() and '__pycache__' not in p.parts}
    (OWN/'OWNED-EVIDENCE-INVENTORY.json').write_bytes(jb({'schema':'source52_empty_owned_evidence_inventory_v1','files':inventory}))
    files={str(p):pin(p.read_bytes()) for p in OWN.iterdir() if p.is_file() and p.name!='FROZEN.json'}
    f={'schema':'source52_empty_protection_fixed_candidate_freeze_v1','status':'FROZEN_CANDIDATE_NOT_PUBLISHED','files':files,'native_targets':plan['native_targets'],
        'production_executed':False,'published':False,'installed':False,'Stage54':False,'original_business_or_native_evidence_writes':0,'review_pending':True}
    assert not (OWN/'FROZEN.json').exists();(OWN/'FROZEN.json').write_bytes(jb(f))
    print(json.dumps({'FROZEN':pin((OWN/'FROZEN.json').read_bytes()),'PLAN':pin((OWN/'PLAN.json').read_bytes()),'REPORT':pin((OWN/'REPORT.md').read_bytes()),'REP':pin((OWN/'REPRESENTATIVE.json').read_bytes()),'DELTA':pin((OWN/'DELTA.json').read_bytes())}))
if __name__=='__main__':main()
