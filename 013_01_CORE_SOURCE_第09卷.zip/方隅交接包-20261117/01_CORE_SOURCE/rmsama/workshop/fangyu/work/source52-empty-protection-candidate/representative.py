"""Owned metadata/launcher seams only. No original executable call or private read."""
import ast,hashlib,json,os,sys,types,uuid,traceback,ctypes,tempfile,stat,subprocess
from ctypes import wintypes
from pathlib import Path
sys.dont_write_bytecode=True
OWN=Path(__file__).resolve().parent;PROJECT=Path('C:/积木软件工坊/项目/方隅公寓客户版');WORK=PROJECT/'work';AUDITS=WORK/'product-upgrade-20261009/audits'
def pin(raw):return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest().upper()}
def jb(v):return (json.dumps(v,ensure_ascii=False,indent=2)+'\n').encode()
def write(p,b):p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);return pin(b)
def const(raw,changes):
    text=raw.decode();source=text
    for n in reversed(ast.parse(source).body):
        if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name) and n.targets[0].id in changes:
            old=ast.get_source_segment(source,n);assert text.count(old)==1;text=text.replace(old,n.targets[0].id+'='+changes.pop(n.targets[0].id),1)
    assert not changes,changes;ast.parse(text);return text.encode()
def load(p,name):
    m=types.ModuleType(name);m.__file__=str(p);sys.modules[name]=m;exec(compile(p.read_bytes(),str(p),'exec'),m.__dict__);return m
def fixture(candidate):
    root=OWN/'fixtures'/uuid.uuid4().hex
    # Fixed public controls only, read before enabling the owned runtime audit hook.
    refs=[{'batch':50,'authority':AUDITS/'source50-manifest.json','approval':AUDITS/'source50-final-root-read.json','prepared':WORK/'overnight-commercial-20261014/source50-preparation/PREPARED.json','cas':AUDITS/'join-source50-reviewed.py'},
        {'batch':51,'authority':AUDITS/'source51-manifest.json','approval':AUDITS/'source51-final-root-read.json','prepared':WORK/'source51-root-integration/PREPARED.json','cas':AUDITS/'join-source51-reviewed.py'},
        {'batch':52,'authority':WORK/'source52-root-integration/guard-token-r2/source52-manifest.json','approval':WORK/'source52-root-integration/guard-token-r2/source52-final-root-read.json','prepared':WORK/'source52-root-integration/PREPARED.json','cas':WORK/'source52-root-integration/guard-token-r2/join-source52-reviewed.py'},
        {'batch':53,'authority':WORK/'source53-root-integration/guard-token-r2/AUTHORITY-PROPOSAL.json','approval':WORK/'source53-root-integration/guard-token-r2/GATE-PROPOSAL.json','prepared':WORK/'source53-root-integration/guard-token-r2/PREPARED.json','cas':WORK/'source53-root-integration/guard-token-r2/join-source53-reviewed.py'}]
    originals=[(r,json.loads(r['authority'].read_bytes()),json.loads(r['approval'].read_bytes()),json.loads(r['prepared'].read_bytes()),r['cas'].read_bytes()) for r in refs]
    def remap(v):
        if type(v) is dict:return {k:remap(x) for k,x in v.items()}
        if type(v) is list:return [remap(x) for x in v]
        if type(v) is str and (v.startswith(str(PROJECT)) or v.startswith(PROJECT.as_posix())):return str(root/Path(v).relative_to(PROJECT))
        return v
    # Only metadata functions use these public evidence copies; no old CAS is run.
    for r,a,g,p,c in originals:
        for evidence in p.get('evidence',[])+g.get('additional_evidence',[]):
            path=Path(evidence['path']);raw=path.read_bytes();assert pin(raw)==evidence['pin'];write(root/path.relative_to(PROJECT),raw)
    guard=WORK/'source52-root-integration/guard-token-r2/source_idle_guard.py';write(root/guard.relative_to(PROJECT),guard.read_bytes())
    ownrefs=[];manifests=[];gates=[];preps=[];previous=None
    for r,a,g,p,c in originals:
        nr={k:root/v.relative_to(PROJECT) if isinstance(v,Path) else v for k,v in r.items()};a=remap(a);g=remap(g);p=remap(p)
        if previous is not None:a['base_manifest_pin']=g['base_manifest_pin']=p['base_manifest_pin']=previous
        if r['batch']==53:
            p['ancestors']=ownrefs
            c=const(c,{'PROJECT':'Path('+repr(root.as_posix())+')','ANCESTORS':repr(ownrefs)})
        pp=write(nr['prepared'],jb(p));g['prepared_manifest_pin']=pp
        if r['batch']==53:c=const(c,{'PREPARED_PIN':repr(pp)})
        cp=write(nr['cas'],c);g['join_script_pin']=a['join_script_pin']=cp
        gp=write(nr['approval'],jb(g));a['approval_pin']=gp
        ap=write(nr['authority'],jb(a));previous=ap
        ref={'batch':r['batch'],'authority':str(nr['authority']),'authority_pin':ap,'approval':str(nr['approval']),'prepared':str(nr['prepared']),
            'receipt':str(root/'work/product-upgrade-20261009/audits'/f"source{r['batch']}-joined.json"),'started':str(root/'work/product-upgrade-20261009/audits'/f"source{r['batch']}-next-open-started.json"),'failed':str(root/'work/product-upgrade-20261009/audits'/f"source{r['batch']}-join-failed.json")}
        ownrefs.append(ref);manifests.append(a);gates.append(g);preps.append(p)
    modules=[]
    for batch,name in ((50,'next_open_source.py'),(51,'next_open_source51.py'),(52,'next_open_source52.py'),(53,'next_open_source53.py')):
        raw=candidate if batch==52 else (WORK/'desktop-self-use-entry'/name).read_bytes()
        # Rebase literal TARGET_PATHS as well as PROJECT before any owned call.
        raw=raw.replace(PROJECT.as_posix().encode(),root.as_posix().encode())
        changes={}
        if batch==50:changes['ROOT_MANIFEST_PIN']=repr(ownrefs[0]['authority_pin'])
        if batch==51:changes.update({'BASE_MANIFEST_PIN':repr(ownrefs[0]['authority_pin']),'MANIFEST_PIN':repr(ownrefs[1]['authority_pin'])})
        if batch==52:changes.update({'BASE_MANIFEST_PIN':repr(ownrefs[1]['authority_pin']),'MANIFEST_PIN':repr(ownrefs[2]['authority_pin'])})
        if batch==53:changes.update({'CAS_PIN':repr(pin(Path(ownrefs[3]['authority']).parent.joinpath('join-source53-reviewed.py').read_bytes())),'MANIFEST_PIN':repr(ownrefs[3]['authority_pin'])})
        raw=const(raw,changes);path=root/'work/desktop-self-use-entry'/name;write(path,raw);m=load(path,'owned_empty_metadata_'+str(batch)+'_'+uuid.uuid4().hex)
        assert all(not isinstance(v,Path) or v.is_relative_to(root) for v in vars(m).values())
        if batch==50:assert all(v.is_relative_to(root) for v in m.TARGET_PATHS)
        modules.append(m)
    # Gate52 evidence has mapped PREPARED51 whose bytes changed; bind actual owned
    # metadata copy instead of importing any old/runtime code.
    for evidence in gates[2]['additional_evidence']+preps[2]['evidence']:
        if evidence['path']==ownrefs[1]['prepared']:evidence['pin']=pin(Path(evidence['path']).read_bytes())
    pp=write(Path(ownrefs[2]['prepared']),jb(preps[2]));gates[2]['prepared_manifest_pin']=pp
    gp=write(Path(ownrefs[2]['approval']),jb(gates[2]));manifests[2]['approval_pin']=gp
    ap=write(Path(ownrefs[2]['authority']),jb(manifests[2]));ownrefs[2]['authority_pin']=ap;modules[2].MANIFEST_PIN=ap
    # Reclose53 ancestor52 after the mapped evidence pin changed.
    preps[3]['ancestors']=ownrefs[:3];preps[3]['base_manifest_pin']=ap;manifests[3]['base_manifest_pin']=gates[3]['base_manifest_pin']=ap
    pp=write(Path(ownrefs[3]['prepared']),jb(preps[3]));gates[3]['prepared_manifest_pin']=pp
    cp=Path(ownrefs[3]['authority']).parent/'join-source53-reviewed.py';c=const(cp.read_bytes(),{'ANCESTORS':repr(ownrefs[:3]),'PREPARED_PIN':repr(pp)});cpp=write(cp,c)
    gates[3]['join_script_pin']=manifests[3]['join_script_pin']=cpp;modules[3].CAS_PIN=cpp
    gp=write(Path(ownrefs[3]['approval']),jb(gates[3]));manifests[3]['approval_pin']=gp
    ap=write(Path(ownrefs[3]['authority']),jb(manifests[3]));modules[3].MANIFEST_PIN=ap
    return root,modules,ownrefs,manifests,preps
def guarded_call(root,call):
    active={'on':True};blocked=[]
    def hook(event,args):
        if not active['on']:return
        if event=='open':
            p=args[0];mode=args[1] if len(args)>1 else 'r'
            if not isinstance(p,(str,bytes,Path)) or not Path(p).resolve().is_relative_to(root.resolve()) or mode and any(c in mode for c in 'wax+'):
                blocked.append(event);raise AssertionError('owned metadata read scope violated')
        if event in ('subprocess.Popen','os.system','ctypes.dlopen','os.remove','os.rename','os.mkdir','socket.connect'):
            blocked.append(event);raise AssertionError('runtime action forbidden at metadata seam')
    sys.addaudithook(hook)
    try:return call(),blocked
    finally:active['on']=False
def main():
    mode=sys.argv[1];baseline=(WORK/'desktop-self-use-entry/next_open_source52.py').read_bytes()
    candidate=baseline if mode=='red' else (OWN/'next_open_source52.py').read_bytes()
    root,ms,refs,manifests,preps=fixture(candidate)
    empty=[r for r in manifests[2]['protected'] if r['pin']['bytes']==0]
    assert len(empty)==8 and all(r['pin']['sha256']=='E3B0C44298FC1C149AFBF4C8996FB92427AE41E4649B934CA495991B7852B855' for r in empty)
    def metadata():return ms[3].reviewed_entry_pin_if_joined(ms[0],ms[1],ms[2])
    if mode=='red':
        try:guarded_call(root,metadata)
        except ValueError as e:assert str(e)=='Source52 exact protection graph changed';error=str(e)
        else:raise AssertionError('original empty protection defect absent')
        report={'status':'DEFECT_REPRODUCED','error':error,'empty_protected_files':8,'owned_root':str(root),'production_executed':False}
        write(OWN/'ACTUAL-RED.json',jb(report));print(json.dumps(report));return
    result,blocked=guarded_call(root,metadata);assert result is None and not blocked
    # Public52 metadata plan rejects malformed/negative/false empty proofs and
    # empty targets; no process/guard/preflight or physical business execution.
    rejects=[]
    for value in ({'bytes':-1,'sha256':'E3B0C44298FC1C149AFBF4C8996FB92427AE41E4649B934CA495991B7852B855'},
        {'bytes':False,'sha256':'E3B0C44298FC1C149AFBF4C8996FB92427AE41E4649B934CA495991B7852B855'},
        {'bytes':0,'sha256':'0'*64},{'bytes':0,'sha256':'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855'},
        {'bytes':0,'sha256':7},{'bytes':0,'sha256':'E3B0C44298FC1C149AFBF4C8996FB92427AE41E4649B934CA495991B7852B855','extra':1}):
        assert not ms[2]._protected_proof(value);rejects.append(value)
    assert not ms[2]._proof({'bytes':0,'sha256':'E3B0C44298FC1C149AFBF4C8996FB92427AE41E4649B934CA495991B7852B855'})
    # Launcher thin failure visibility, owned collaborators record transport.
    lp=OWN/'launcher-owned.py';write(lp,(OWN/'source_next_open_launcher.py').read_bytes().replace(PROJECT.as_posix().encode(),root.as_posix().encode()))
    launcher=load(lp,'owned_empty_launcher_'+uuid.uuid4().hex);messages=[];calls=[]
    launcher._failure_message=lambda:messages.append(launcher.OPEN_FAILURE_MESSAGE)
    def loader(path,proof,name):
        calls.append(name)
        if 'source53_fixed_next_open' in name:return types.SimpleNamespace(reviewed_entry_pin_if_joined=lambda *a:(_ for _ in ()).throw(ValueError('PRIVATE PATH MUST NEVER BE SHOWN')))
        return object()
    launcher._load=loader;args=sys.argv;sys.argv=[str(lp)]
    try:status=launcher.main()
    finally:sys.argv=args
    assert status==1 and messages==[launcher.OPEN_FAILURE_MESSAGE] and not any('entry' in n for n in calls)
    assert 'PRIVATE' not in messages[0] and '\\' not in messages[0] and 'C:' not in messages[0]
    # A held decision still produces the original reviewed entry product message.
    held_messages=[];entry=types.SimpleNamespace(preflight=lambda:{'state':'ready_for_original_native_main'},message=held_messages.append,HELD_MESSAGE='OWNED FIXED HELD',LIVE_MESSAGE='OWNED FIXED LIVE')
    newest=types.SimpleNamespace(reviewed_entry_pin_if_joined=lambda *a:None,before_normal_open=lambda *a:{'decision':'held','source_mutations':0})
    launcher._load=lambda path,proof,name:entry if path==launcher.ENTRY else newest if path==launcher.NEWEST else object()
    sys.argv=[str(lp)]
    try:held_status=launcher.main()
    finally:sys.argv=args
    assert held_status==1 and held_messages==['OWNED FIXED HELD']
    report={'schema':'source52_empty_protection_minimal_owned_representative_v1','status':'PASS_LIMITED','owned_root':str(root),'empty_protected_files':8,
        'actual_metadata_chain':'new53 reviewed_entry -> fixed CAS authority_plan -> new52 reviewed_entry/plan -> actual rebased51/50 metadata -> recorded absent receipts',
        'guard_process_preflight_apply_calls':0,'blocked_actions':blocked,'target_nonempty_rule_preserved':True,'invalid_proof_examples_refused':len(rejects),
        'launcher_exception':{'exit_code':status,'fixed_notice_count':len(messages),'entry_loaded':False,'private_error_shown':False},'launcher_held':{'exit_code':held_status,'notice_count':len(held_messages)},
        'recorded':['shared business receipts/started/failed absent','launcher collaborators/messagebox transport','entry ready and held decision'],'production_executed':False,'published':False,'installed':False,'Stage54':False}
    write(OWN/'REPRESENTATIVE.json',jb(report));print(json.dumps({'status':'PASS_LIMITED','empty_protected':8,'negative_examples':len(rejects),'launcher_failure_notice':True}))
if __name__=='__main__':
    try:main()
    except BaseException:
        n=1
        while (OWN/f'CARRIER-RED-{n}.txt').exists():n+=1
        write(OWN/f'CARRIER-RED-{n}.txt',traceback.format_exc().encode());raise
