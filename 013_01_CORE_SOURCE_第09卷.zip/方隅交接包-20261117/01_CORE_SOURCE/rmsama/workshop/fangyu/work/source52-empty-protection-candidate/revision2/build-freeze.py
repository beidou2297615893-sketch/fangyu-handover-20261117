"""Single notice literal correction; no old metadata/runtime representative rerun."""
import ast,hashlib,json,sys,types
from pathlib import Path
sys.dont_write_bytecode=True
OWN=Path(__file__).resolve().parent;BASE=OWN.parent
def pin(b):return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest().upper()}
def jb(v):return (json.dumps(v,ensure_ascii=False,indent=2)+'\n').encode()
def write(p,b):
    with p.open('xb') as f:f.write(b)
    return pin(b)
def funcs(b):
    text=b.decode();return {n.name:ast.get_source_segment(text,n) for n in ast.parse(text).body if isinstance(n,ast.FunctionDef)}
def main():
    originalfreeze=(BASE/'FROZEN.json').read_bytes();assert pin(originalfreeze)=={'bytes':5015,'sha256':'D689B2CAB5CD1584FCDCDD2B393FFD997093729D6F3677D3413EFD044D286BB9'}
    for p,proof in json.loads(originalfreeze)['files'].items():assert pin(Path(p).read_bytes())==proof
    old=(BASE/'source_next_open_launcher.py').read_bytes();text=old.decode()
    node=next(n for n in ast.parse(text).body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='OPEN_FAILURE_MESSAGE' for t in n.targets))
    literal=ast.get_source_segment(text,node);newliteral="OPEN_FAILURE_MESSAGE='客户端未能正常打开，请保留现状，等待修复。'"
    assert text.count(literal)==1;new=text.replace(literal,newliteral,1).encode();assert funcs(old)==funcs(new)
    launcherpin=write(OWN/'source_next_open_launcher.py',new)
    plan=json.loads((BASE/'PLAN.json').read_bytes());plan['status']='OWNED_REVISION2_NOTICE_CORRECTION_NOT_PUBLISHED'
    plan['previous_candidate_frozen']={'path':str(BASE/'FROZEN.json'),'pin':pin(originalfreeze)}
    for row in plan['files']:
        if Path(row['target']).name=='source_next_open_launcher.py':row.update({'candidate':str(OWN/'source_next_open_launcher.py'),'pin':launcherpin})
    for row in plan['native_targets']:
        if Path(row['target']).name=='source_next_open_launcher.py':row['final']=launcherpin
    assert plan['files'][0]['pin']=={'bytes':16027,'sha256':'B4F6BE4903F7E25F7C25B11F1CEAB96779CC60D26F511C1511E8257D012072A4'}
    planpin=write(OWN/'PLAN.json',jb(plan))
    # Only fixed-notice seam: execute own module definitions without main/entry.
    m=types.ModuleType('owned_revision2_notice');m.__file__=str(OWN/'source_next_open_launcher.py');exec(compile(new,m.__file__,'exec'),m.__dict__)
    messages=[]
    class User32:
        class Box:
            def __call__(self,hwnd,message,title,flags):messages.append({'message':message,'title':title});return 1
        MessageBoxW=Box()
    import ctypes
    before=ctypes.WinDLL
    ctypes.WinDLL=lambda name,**kw:User32() if name=='user32' else (_ for _ in ()).throw(AssertionError('unexpected DLL'))
    try:m._failure_message()
    finally:ctypes.WinDLL=before
    assert messages==[{'message':'客户端未能正常打开，请保留现状，等待修复。','title':'方隅工作台'}]
    assert all(s not in messages[0]['message'] for s in ('未更新','未应用','0更新','C:','\\'))
    rep={'schema':'source52_empty_protection_revision2_notice_seam_v1','status':'PASS_LIMITED_NOTICE_ONLY','notice':messages[0],
        'actual_fixed_notice_function_executed':True,'user32_messagebox_transport_recorded':True,'launcher_main_metadata_entry_guard_or_apply_executed':False,
        'all_launcher_function_segments_unchanged':True,'H52_original_candidate_bytes_unchanged':True,'old_metadata_or_negative_QA_reexecuted':False,'production_executed':False,'published':False,'installed':False}
    reppin=write(OWN/'REPRESENTATIVE.json',jb(rep))
    deltapin=write(OWN/'DELTA.json',jb({'schema':'source52_empty_revision2_literal_delta_v1','baseline_launcher_pin':pin(old),'candidate_launcher_pin':launcherpin,
        'old_assignment':literal,'new_assignment':newliteral,'function_changes':[],'H52_changed':False}))
    report='''# Revision2 fixed notice wording correction

Only OPEN_FAILURE_MESSAGE changes to 「客户端未能正常打开，请保留现状，等待修复。」. The ordinary exception branch can occur after before_normal_open, message or execv, so it must not imply no source application or only a preliminary verification failure. All launcher function segments remain byte-identical to the first candidate. H52 remains exact16027/B4F6BE49;9targets/462protection, all source controls/guards/flags and original native evidence remain unchanged.

Original D689 first freeze/reports/ACTUAL-RED/carrier error evidence are retained. PLAN reuses its H52 and original installed parents1C919E94/994ED84B, updates only new launcher candidate/final pin; future public paths remain the not-yet-published empty-protection-r3 paths. Independent repair installer graph/gate must bind this revision2 PLAN/FROZEN and new launcher pin. No original native receipt is backfilled.

Only notice seam was rerun: actual new candidate _failure_message emits exactly the fixed wording/title through recorded user32.MessageBoxW transport. No launcher main, metadata/negative proof tests, private state, guard/PID/preflight/check-only/App/business apply, production publication/install or Stage54 actions occurred. Previous metadata/held/negative evidence is retained and functions remain identical. Actual desktop opening/GUI remains unverified by author.
'''
    reportpin=write(OWN/'REPORT.md',report.encode())
    files={str(p):pin(p.read_bytes()) for p in OWN.iterdir() if p.is_file() and p.name!='FROZEN.json'}
    files[str(BASE/'FROZEN.json')]=pin(originalfreeze);files[str(BASE/'next_open_source52.py')]=plan['files'][0]['pin']
    freeze={'schema':'source52_empty_protection_revision2_fixed_notice_freeze_v1','status':'FROZEN_CANDIDATE_NOT_PUBLISHED','files':files,'native_targets':plan['native_targets'],
        'production_executed':False,'published':False,'installed':False,'H52_changed':False,'metadata_QA_reexecuted':False,'review_pending':True}
    frozenpin=write(OWN/'FROZEN.json',jb(freeze));print(json.dumps({'launcher':launcherpin,'FROZEN':frozenpin,'PLAN':planpin,'REPORT':reportpin,'REP':reppin,'DELTA':deltapin}))
if __name__=='__main__':main()
