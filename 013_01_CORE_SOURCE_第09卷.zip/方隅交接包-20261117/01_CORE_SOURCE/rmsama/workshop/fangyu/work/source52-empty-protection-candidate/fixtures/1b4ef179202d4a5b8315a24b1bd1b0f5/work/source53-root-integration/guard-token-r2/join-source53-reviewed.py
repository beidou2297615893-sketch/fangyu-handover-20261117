"""Source53 isolated CAS candidate. Import is inert; unauthorized by default.
Reviewed production bind must be a new authority. No old authority is rewritten.
"""
import ast,ctypes,hashlib,json,os,stat,subprocess,sys,tempfile,types,uuid
from ctypes import wintypes
from pathlib import Path
PROJECT=Path('C:/积木软件工坊/项目/方隅公寓客户版/work/source52-empty-protection-candidate/fixtures/1b4ef179202d4a5b8315a24b1bd1b0f5')
WORK=PROJECT/'work'
OWN=WORK/'source53-root-integration/guard-token-r2'
AUDITS=WORK/'product-upgrade-20261009/audits'
PREPARED=OWN/'PREPARED.json'
AUTHORITY=OWN/'AUTHORITY-PROPOSAL.json'
APPROVAL=OWN/'GATE-PROPOSAL.json'
STARTED=AUDITS/'source53-next-open-started.json'
RECEIPT=AUDITS/'source53-joined.json'
FAILED=AUDITS/'source53-join-failed.json'
PILOT=WORK/'self-operating-pilot'
ENTRY=WORK/'desktop-self-use-entry/desktop_entry.py'
INSTANCE_ID='d075ac9c039e44038ddbc6f3e753d73c'
JOIN_AUTHORIZED=True
AUTHORITY_PIN=None
PREPARED_PIN={'bytes': 207204, 'sha256': 'B3282E70A81CDE19EACE719DFF3C8BCBEE76F67313AEEDD89F6D394C83D85BAE'}
ANCESTORS=[{'batch': 50, 'authority': 'C:\\积木软件工坊\\项目\\方隅公寓客户版\\work\\source52-empty-protection-candidate\\fixtures\\1b4ef179202d4a5b8315a24b1bd1b0f5\\work\\product-upgrade-20261009\\audits\\source50-manifest.json', 'authority_pin': {'bytes': 21928, 'sha256': '29492E4969C2E72BD4E880D2C79FDAB9BFBFB98E18CA28DBAF8CABD68005FF70'}, 'approval': 'C:\\积木软件工坊\\项目\\方隅公寓客户版\\work\\source52-empty-protection-candidate\\fixtures\\1b4ef179202d4a5b8315a24b1bd1b0f5\\work\\product-upgrade-20261009\\audits\\source50-final-root-read.json', 'prepared': 'C:\\积木软件工坊\\项目\\方隅公寓客户版\\work\\source52-empty-protection-candidate\\fixtures\\1b4ef179202d4a5b8315a24b1bd1b0f5\\work\\overnight-commercial-20261014\\source50-preparation\\PREPARED.json', 'receipt': 'C:\\积木软件工坊\\项目\\方隅公寓客户版\\work\\source52-empty-protection-candidate\\fixtures\\1b4ef179202d4a5b8315a24b1bd1b0f5\\work\\product-upgrade-20261009\\audits\\source50-joined.json', 'started': 'C:\\积木软件工坊\\项目\\方隅公寓客户版\\work\\source52-empty-protection-candidate\\fixtures\\1b4ef179202d4a5b8315a24b1bd1b0f5\\work\\product-upgrade-20261009\\audits\\source50-next-open-started.json', 'failed': 'C:\\积木软件工坊\\项目\\方隅公寓客户版\\work\\source52-empty-protection-candidate\\fixtures\\1b4ef179202d4a5b8315a24b1bd1b0f5\\work\\product-upgrade-20261009\\audits\\source50-join-failed.json'}, {'batch': 51, 'authority': 'C:\\积木软件工坊\\项目\\方隅公寓客户版\\work\\source52-empty-protection-candidate\\fixtures\\1b4ef179202d4a5b8315a24b1bd1b0f5\\work\\product-upgrade-20261009\\audits\\source51-manifest.json', 'authority_pin': {'bytes': 201665, 'sha256': '7B3B1E57D8DB582200C76BFD87BB0BF93069FA026C143A590C438BA0E88ABC1F'}, 'approval': 'C:\\积木软件工坊\\项目\\方隅公寓客户版\\work\\source52-empty-protection-candidate\\fixtures\\1b4ef179202d4a5b8315a24b1bd1b0f5\\work\\product-upgrade-20261009\\audits\\source51-final-root-read.json', 'prepared': 'C:\\积木软件工坊\\项目\\方隅公寓客户版\\work\\source52-empty-protection-candidate\\fixtures\\1b4ef179202d4a5b8315a24b1bd1b0f5\\work\\source51-root-integration\\PREPARED.json', 'receipt': 'C:\\积木软件工坊\\项目\\方隅公寓客户版\\work\\source52-empty-protection-candidate\\fixtures\\1b4ef179202d4a5b8315a24b1bd1b0f5\\work\\product-upgrade-20261009\\audits\\source51-joined.json', 'started': 'C:\\积木软件工坊\\项目\\方隅公寓客户版\\work\\source52-empty-protection-candidate\\fixtures\\1b4ef179202d4a5b8315a24b1bd1b0f5\\work\\product-upgrade-20261009\\audits\\source51-next-open-started.json', 'failed': 'C:\\积木软件工坊\\项目\\方隅公寓客户版\\work\\source52-empty-protection-candidate\\fixtures\\1b4ef179202d4a5b8315a24b1bd1b0f5\\work\\product-upgrade-20261009\\audits\\source51-join-failed.json'}, {'batch': 52, 'authority': 'C:\\积木软件工坊\\项目\\方隅公寓客户版\\work\\source52-empty-protection-candidate\\fixtures\\1b4ef179202d4a5b8315a24b1bd1b0f5\\work\\source52-root-integration\\guard-token-r2\\source52-manifest.json', 'authority_pin': {'bytes': 202102, 'sha256': '62B160FC1C870E5E669314601CDBDCFD605C0841E59CFC8053669C7F46253AEA'}, 'approval': 'C:\\积木软件工坊\\项目\\方隅公寓客户版\\work\\source52-empty-protection-candidate\\fixtures\\1b4ef179202d4a5b8315a24b1bd1b0f5\\work\\source52-root-integration\\guard-token-r2\\source52-final-root-read.json', 'prepared': 'C:\\积木软件工坊\\项目\\方隅公寓客户版\\work\\source52-empty-protection-candidate\\fixtures\\1b4ef179202d4a5b8315a24b1bd1b0f5\\work\\source52-root-integration\\PREPARED.json', 'receipt': 'C:\\积木软件工坊\\项目\\方隅公寓客户版\\work\\source52-empty-protection-candidate\\fixtures\\1b4ef179202d4a5b8315a24b1bd1b0f5\\work\\product-upgrade-20261009\\audits\\source52-joined.json', 'started': 'C:\\积木软件工坊\\项目\\方隅公寓客户版\\work\\source52-empty-protection-candidate\\fixtures\\1b4ef179202d4a5b8315a24b1bd1b0f5\\work\\product-upgrade-20261009\\audits\\source52-next-open-started.json', 'failed': 'C:\\积木软件工坊\\项目\\方隅公寓客户版\\work\\source52-empty-protection-candidate\\fixtures\\1b4ef179202d4a5b8315a24b1bd1b0f5\\work\\product-upgrade-20261009\\audits\\source52-join-failed.json'}]
SOURCE_GUARD=WORK/'source52-root-integration/guard-token-r2/source_idle_guard.py'
SOURCE_GUARD_PIN={'bytes': 6243, 'sha256': 'EC86C01DA85F6AC984CAC4BBA78DEB400D32C2E92FDCA30409CF007A0DA08B0F'}
ALLOWED=frozenset(('app/src/web/workspace/self-operating-read.mjs','app/src/web/workspace/upgrade-ui.css','cloud/workspace/site/upgrade-ui.css'))
EXPECTED_TARGET_PINS={'app/src/web/workspace/self-operating-read.mjs': ({'bytes': 407892, 'sha256': '9CF6B4E2A8681665C18B20D7C0D2B0B382B90FC13D554DB2B7F49A220725A2F8'}, {'bytes': 409955, 'sha256': 'C8C52A073BAF06B8577440FFBF996DE0E399ABF23D5EA4B0CF424093944EEA47'}), 'app/src/web/workspace/upgrade-ui.css': ({'bytes': 100324, 'sha256': '3534C301C2C16427C08F100EEBF6641B3D54AB55C0BA07EF64BBB5079449F775'}, {'bytes': 105043, 'sha256': '6E76B4A2775658D99592A065521A04F022A8BBF8E85DFD8D00873AA1965309AB'}), 'cloud/workspace/site/upgrade-ui.css': ({'bytes': 100324, 'sha256': '3534C301C2C16427C08F100EEBF6641B3D54AB55C0BA07EF64BBB5079449F775'}, {'bytes': 105043, 'sha256': '6E76B4A2775658D99592A065521A04F022A8BBF8E85DFD8D00873AA1965309AB'})}

def blob(path):
    current=PROJECT
    for part in path.relative_to(PROJECT).parts:
        current=current/part
        info=current.lstat()
        if current.is_symlink() or getattr(info,'st_file_attributes',0)&0x400:
            raise ValueError('reparse path changed')
    if not stat.S_ISREG(info.st_mode) or info.st_nlink!=1:
        raise ValueError('file kind changed')
    return path.read_bytes()

def pin(value):
    return {'bytes':len(value),'sha256':hashlib.sha256(value).hexdigest().upper()}

def expected(path,proof):
    value=blob(path)
    if pin(value)!=proof:
        raise ValueError('pinned file changed: '+str(path))
    return value

def no_link_parent(path):
    current=PROJECT
    for part in path.parent.relative_to(PROJECT).parts:
        current=current/part
        info=current.lstat()
        if (not stat.S_ISDIR(info.st_mode) or current.is_symlink()
                or getattr(info,'st_file_attributes',0)&0x400):
            raise ValueError('new-source parent changed')

def prepared_temp(target,value):
    no_link_parent(target)
    descriptor,name=tempfile.mkstemp(prefix='.source44-',suffix='.tmp',dir=target.parent)
    temporary=Path(name)
    try:
        with os.fdopen(descriptor,'wb') as stream:
            stream.write(value)
            stream.flush()
            os.fsync(stream.fileno())
        if blob(temporary)!=value:
            raise ValueError('complete temporary write mismatch')
        return temporary
    except BaseException:
        # This explicit temporary file is new and private to this join.
        temporary.unlink(missing_ok=True)
        raise
def proof(value):
    return (type(value) is dict and set(value)=={'bytes','sha256'} and type(value['bytes']) is int
        and value['bytes']>=0 and type(value['sha256']) is str and len(value['sha256'])==64
        and all(c in '0123456789ABCDEF' for c in value['sha256']))

def require_source_idle(phase):
    # Same fixed guard as normal opening. No business code or private state.
    import types
    if not proof(SOURCE_GUARD_PIN):raise ValueError('fixed source guard absent')
    raw=expected(SOURCE_GUARD,SOURCE_GUARD_PIN)
    module=types.ModuleType('source52_cas_source_guard');module.__file__=str(SOURCE_GUARD)
    exec(compile(raw,str(SOURCE_GUARD),'exec'),module.__dict__)
    value=module.source_state(os.getpid())
    if (type(value) is not dict or value.get('scope')!='fangyu_customer_source_metadata_v1'
        or value.get('state')!='idle'):raise ValueError('source live or unknown at '+phase)
    return value

def existing_lock_is_held():
    # Read only metadata and probe the same existing byte range from a child.
    # A free/unknown range cannot stand in for the caller's normal-open lock.
    path=PILOT/'data/instance.lock'
    no_link_parent(path);info=path.lstat()
    if path.is_symlink() or getattr(info,'st_file_attributes',0)&0x400 or not stat.S_ISREG(info.st_mode) or info.st_nlink!=1 or info.st_size<1:
        raise ValueError('existing lock identity unknown')
    code="import errno,msvcrt,os,sys; f=open(sys.argv[1],'r+b'); f.seek(0)\ntry:\n msvcrt.locking(f.fileno(),msvcrt.LK_NBLCK,1)\nexcept OSError as e:\n if e.errno not in (errno.EACCES,errno.EDEADLK): raise\n print('held')\nelse:\n f.seek(0); msvcrt.locking(f.fileno(),msvcrt.LK_UNLCK,1); print('free')\nfinally:\n f.close()"
    probe=subprocess.run([sys.executable,'-B','-c',code,str(path)],capture_output=True,text=True,timeout=15,
        creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
    after=path.lstat()
    if probe.returncode or probe.stderr.strip() or probe.stdout.strip()!='held' or (info.st_dev,info.st_ino)!=(after.st_dev,after.st_ino):
        raise ValueError('original normal-open OS lock is free or unknown')

def original_main_dead():
    raw=blob(PILOT/'data/running.json')
    if len(raw)>4096:raise ValueError('main metadata unknown')
    value=json.loads(raw)
    if (type(value) is not dict or set(value)!={'pid','url','mode'} or type(value['pid']) is not int
        or not 0<value['pid']<=0xffffffff or value['mode'] not in ('headless-test','assistant','browser')):
        raise ValueError('main identity unknown')
    if pid_state(value['pid'])!='dead':raise ValueError('original main alive or unknown')
    return value['pid']
def _layer(legacy,batch,authority,authority_pin,gate_path,prepared_path,receipt_path):
    """Validate immutable raw authority, preparation and receipt, without current-source assumptions."""
    gate=json.loads(legacy.expected(gate_path,authority['approval_pin']))
    prepared=json.loads(legacy.expected(prepared_path,gate['prepared_manifest_pin']))
    if (prepared.get('schema')!=f'source{batch}_owner_prepared_v1' or prepared.get('source_batch')!=batch
        or prepared.get('join_authorized') is not False or prepared.get('instance_id')!=INSTANCE_ID):
        raise ValueError('ancestor prepared metadata changed')
    raw=legacy.blob(receipt_path);receipt=json.loads(raw)
    if (receipt.get('schema')!=f'source{batch}_owner_joined_v1' or receipt.get('source_batch')!=batch
        or receipt.get('approval_sha256')!=authority['approval_pin']['sha256']
        or receipt.get('authority_manifest_pin')!=authority_pin
        or receipt.get('prepared_manifest_pin')!=gate['prepared_manifest_pin']
        or receipt.get('protected')!=prepared.get('protected')
        or any(receipt.get(x) is not False for x in ('App_restarted','marker_changed',
            'customer_database_opened','session_copied','deployed','real_GUI_verified','commercial_complete'))):
        raise ValueError('actual original ancestor success receipt changed')
    prep=prepared.get('targets');rows=receipt.get('targets')
    if (type(prep) is not list or type(rows) is not list or len(rows)!=len(prep)
        or len({x['target'] for x in prep})!=len(prep)
        or any(type(x) is not dict or set(x)!={'target','parent','candidate','backup'} for x in rows)
        or len({x['target'] for x in rows})!=len(rows)):
        raise ValueError('ancestor target record set changed')
    targets={Path(x['target']):x for x in prep};records={Path(x['target']):x for x in rows}
    final={Path(x['path']):x['final_pin'] for x in authority['targets']}
    if set(targets)!=set(records) or {p:x['candidate_pin'] for p,x in targets.items()}!=final:
        raise ValueError('ancestor final graph changed')
    if batch>=51:
        if receipt.get('new_directories')!=[] or authority.get('protected')!=prepared['protected']:
            raise ValueError('successor directory/protection metadata changed')
        if {Path(x['path']):x['parent_pin'] for x in authority['targets']}!={p:x['parent'] for p,x in targets.items()}:
            raise ValueError('successor original parent graph changed')
    root=Path(receipt['backup']);relative=root.relative_to(PROJECT/f'backups/source{batch}-owner')
    if (len(relative.parts)!=1 or len(relative.name)!=32
        or any(c not in '0123456789abcdef' for c in relative.name)):
        raise ValueError('ancestor backup root changed')
    # Validate all original parent backups, not an alternate batch's plausible path.
    for path,row in records.items():
        pin=targets[path]['parent']
        if row['parent']!=pin or row['candidate']!=final[path]:raise ValueError('ancestor target pin changed')
        if pin is None:
            if row['backup'] is not None:raise ValueError('new target falsely has original parent')
        else:
            backup=root/path.relative_to(WORK)
            if row['backup']!=str(backup):raise ValueError('ancestor backup address changed')
            legacy.expected(backup,pin)
    return raw,receipt,records,final,prepared['protected']

def _self():
    return sys.modules[__name__]

def _authority_plan():
    if JOIN_AUTHORIZED is not True or not proof(AUTHORITY_PIN):
        raise ValueError('Source53 new reviewed authority absent; proposal not installable')
    raw=expected(AUTHORITY,AUTHORITY_PIN);authority=json.loads(raw)
    gate=json.loads(expected(APPROVAL,authority['approval_pin']))
    prepared=json.loads(expected(PREPARED,PREPARED_PIN))
    if (authority.get('schema')!='source53_next_open_manifest_v1' or authority.get('source_batch')!=53
        or authority.get('join_authorized') is not True or authority.get('instance_id')!=INSTANCE_ID
        or authority.get('base_manifest_pin')!=ANCESTORS[-1]['authority_pin']
        or authority.get('source_guard_pin')!=SOURCE_GUARD_PIN
        or gate.get('schema')!='source53_final_root_read' or gate.get('source_batch')!=53
        or gate.get('join_authorized') is not True or gate.get('base_manifest_pin')!=ANCESTORS[-1]['authority_pin']
        or gate.get('prepared_manifest_pin')!=PREPARED_PIN or gate.get('join_script_pin')!=authority['join_script_pin']
        or gate.get('source_guard_pin')!=SOURCE_GUARD_PIN
        or any(gate.get(x) is not True for x in ('independent_code_review_passed','independent_actual_qa_review_passed','join_script_review_passed','next_normal_open_only'))
        or any(gate.get(x) is not False for x in ('customer_database_opened','session_copied','deployment_or_packaging_performed'))
        or prepared.get('schema')!='source53_owner_prepared_v1' or prepared.get('source_batch')!=53
        or prepared.get('join_authorized') is not False or prepared.get('instance_id')!=INSTANCE_ID
        or prepared.get('base_manifest_pin')!=ANCESTORS[-1]['authority_pin'] or prepared.get('ancestors')!=ANCESTORS
        or prepared.get('new_directories')!=[]):
        raise ValueError('Source53 fixed new authority/gate/prepared binding changed')
    expected(Path(__file__).absolute(),authority['join_script_pin'])
    expected(SOURCE_GUARD,SOURCE_GUARD_PIN)
    rows=prepared.get('targets')
    if (type(rows) is not list or len(rows)!=3
        or any(type(x) is not dict or set(x)!={'target','candidate','parent','candidate_pin'} or not proof(x['parent']) or not proof(x['candidate_pin']) for x in rows)
        or len({x['target'] for x in rows})!=3
        or {Path(x['target']).relative_to(WORK).as_posix():(x['parent'],x['candidate_pin']) for x in rows}!=EXPECTED_TARGET_PINS
        or {Path(x['target']).relative_to(WORK).as_posix() for x in rows}!=ALLOWED
        or authority.get('targets')!=[{'path':x['target'],'parent_pin':x['parent'],'final_pin':x['candidate_pin']} for x in rows]
        or authority.get('protected')!=prepared.get('protected')):
        raise ValueError('Source53 exact three-target mapping changed')
    protected=prepared['protected']
    if (len(protected)!=470 or len({x['path'] for x in protected})!=470
        or any(type(x) is not dict or set(x)!={'path','pin'} or not proof(x['pin']) for x in protected)
        or {x['path'] for x in protected}&{x['target'] for x in rows}):
        raise ValueError('Source53 exact 470 protection set changed')
    for item in prepared['evidence']+gate['additional_evidence']:expected(Path(item['path']),item['pin'])
    return authority,gate,prepared

def _layers(include53=False,check_current=True):
    """Original raw receipts and every original parent backup, never substitutes."""
    layers=[];previous=None;previous_authority_pin=None
    refs=ANCESTORS+([{'batch':53,'authority':str(AUTHORITY),'authority_pin':AUTHORITY_PIN,'approval':str(APPROVAL),'prepared':str(PREPARED),'receipt':str(RECEIPT),'started':str(STARTED),'failed':str(FAILED)}] if include53 else [])
    for ref in refs:
        batch=ref['batch']
        if os.path.lexists(ref['failed']):raise ValueError('original failure evidence preserved')
        authority=json.loads(expected(Path(ref['authority']),ref['authority_pin']))
        rows=authority.get('targets')
        if (authority.get('schema')!=f'source{batch}_next_open_manifest_v1'
            or authority.get('source_batch')!=batch or authority.get('instance_id')!=INSTANCE_ID
            or authority.get('join_authorized') is not True
            or type(rows) is not list or len(rows)!={50:55,51:11,52:9,53:3}[batch]
            or len({x['path'] for x in rows})!=len(rows)
            or any(not proof(x['final_pin']) for x in rows)
            or (previous_authority_pin is not None and authority.get('base_manifest_pin')!=previous_authority_pin)):
            raise ValueError('fixed ancestor authority or raw chain changed')
        result=_layer(_self(),batch,authority,ref['authority_pin'],Path(ref['approval']),Path(ref['prepared']),Path(ref['receipt']))
        raw,receipt,records,final,protected=result
        if previous is not None and receipt.get('base_receipt_pin')!=pin(previous):raise ValueError('actual raw predecessor lineage changed')
        previous=raw;previous_authority_pin=ref['authority_pin'];layers.append(result)
    if check_current:
        for i,(_,_,_,final,protected) in enumerate(layers):
            for path,value in list(final.items())+[(Path(x['path']),x['pin']) for x in protected]:
                for overlay in layers[i+1:]:
                    if path in overlay[2]:
                        record=overlay[2][path]
                        if record['parent']!=value or record['backup'] is None:raise ValueError('original overlay parent changed')
                        expected(Path(record['backup']),value);break
                else:expected(path,value)
    return layers

def predecessor(prepared,check_current=True):
    layers=_layers(False,check_current)
    _,_,_,final,protected=layers[-1]
    required={x['path']:x['pin'] for x in protected}
    for path,value in final.items():
        if str(path) in required and required[str(path)]!=value:raise ValueError('52 final/protected conflict')
        required[str(path)]=value
    for row in prepared['targets']:
        if row['target'] in required and required[row['target']]!=row['parent']:raise ValueError('53 exact parent is not 52 final/protected')
        required.pop(row['target'],None)
    if required!={x['path']:x['pin'] for x in prepared['protected']}:raise ValueError('53 cumulative 470 protected closure changed')
    if check_current:
        for row in prepared['targets']:expected(Path(row['target']),row['parent'])
    return pin(layers[-1][0])

def _own_original_backups(saved):
    for row in saved:expected(Path(row['backup']),row['parent'])

def readback():
    authority,gate,prepared=_authority_plan()
    layers=_layers(True,True)
    if layers[-1][4]!=prepared['protected']:raise ValueError('Source53 success protection changed')
    return pin(layers[-1][0])

def start_once(base_pin):
    authority,gate,prepared=_authority_plan()
    if any(os.path.lexists(x) for x in (STARTED,FAILED,RECEIPT)):raise ValueError('original Source53 invocation requires Root recovery')
    require_source_idle('before_source53_started')
    if predecessor(prepared)!=base_pin:raise ValueError('53 raw parent changed before STARTED')
    value={'schema':'source53_next_open_started_v1','source_batch':53,'instance_id':INSTANCE_ID,
        'approval_sha256':authority['approval_pin']['sha256'],'manifest_pin':AUTHORITY_PIN,
        'base_receipt_pin':base_pin,'pid':os.getpid(),'auto_retry':False}
    temporary=prepared_temp(STARTED,(json.dumps(value,ensure_ascii=False,sort_keys=True)+'\n').encode('utf-8'))
    try:os.rename(temporary,STARTED)
    finally:temporary.unlink(missing_ok=True)

def main():
    if JOIN_AUTHORIZED is not True:raise ValueError('Source53 proposal cannot authorize apply')
    if os.name!='nt' or len(sys.argv)!=3 or sys.argv[1]!='--apply':raise ValueError('fixed normal-open apply only')
    authority,gate,manifest=_authority_plan()
    if sys.argv[2]!=authority['approval_pin']['sha256']:raise ValueError('exact new Root approval SHA required')
    if any(os.path.lexists(x) for x in (RECEIPT,FAILED)):raise ValueError('original execution evidence preserved')
    started=json.loads(blob(STARTED));base_pin=predecessor(manifest)
    if (started.get('schema')!='source53_next_open_started_v1' or started.get('source_batch')!=53
        or started.get('instance_id')!=INSTANCE_ID or started.get('pid')!=os.getpid()
        or started.get('approval_sha256')!=authority['approval_pin']['sha256']
        or started.get('manifest_pin')!=AUTHORITY_PIN or started.get('base_receipt_pin')!=base_pin
        or started.get('auto_retry') is not False):raise ValueError('53 actual normal-open caller not bound')
    # Only fixed predecessor-final entry function definition, no entry/App import.
    entry_pin=next(x[3][ENTRY] for x in reversed(_layers(False,False)) if ENTRY in x[3])
    raw=expected(ENTRY,entry_pin)
    definitions=[x for x in ast.parse(raw).body if isinstance(x,ast.FunctionDef) and x.name=='pid_state']
    if len(definitions)!=1:raise ValueError('original process-state interface changed')
    exec(compile(ast.Module(body=definitions,type_ignores=[]),str(ENTRY),'exec'),globals())
    original_pid=original_main_dead();existing_lock_is_held()
    backup=None;saved=[];temporaries=[];attempted=[]
    try:
        changes=[]
        for item in manifest['targets']:
            target=Path(item['target']);candidate=Path(item['candidate'])
            candidate.relative_to(WORK/'source53-collection-ui-candidate/frozen-r1/future51')
            if '..' in candidate.parts:raise ValueError('candidate parent alias refused')
            no_link_parent(target);before=expected(target,item['parent']);after=expected(candidate,item['candidate_pin'])
            changes.append((item,target,before,after))
        require_source_idle('before_backups_and_temps')
        backup_base=PROJECT/'backups/source53-owner';no_link_parent(backup_base);backup_base.mkdir(exist_ok=True)
        backup=backup_base/uuid.uuid4().hex;no_link_parent(backup);backup.mkdir()
        for item,target,before,after in changes:
            path=backup/target.relative_to(WORK);path.parent.mkdir(parents=True,exist_ok=True)
            path.write_bytes(before);expected(path,item['parent'])
            saved.append({'target':str(target),'parent':item['parent'],'candidate':item['candidate_pin'],'backup':str(path)})
            temporaries.append(prepared_temp(target,after))
        (backup/'PREPARED.json').write_text(json.dumps(saved,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
        if original_main_dead()!=original_pid:raise ValueError('original main changed')
        existing_lock_is_held();predecessor(manifest)
        for item in manifest['protected']:expected(Path(item['path']),item['pin'])
        for (item,target,before,after),temporary in zip(changes,temporaries):
            no_link_parent(target);expected(temporary,item['candidate_pin']);expected(target,item['parent'])
            require_source_idle('before_replace')
            if predecessor(manifest,False)!=base_pin:raise ValueError('original raw lineage changed during join')
            _own_original_backups(saved)
            attempted.append((item,target,before,after));os.replace(temporary,target);expected(target,item['candidate_pin'])
        for item in manifest['protected']:expected(Path(item['path']),item['pin'])
        for item,target,before,after in changes:expected(target,item['candidate_pin'])
        if original_main_dead()!=original_pid:raise ValueError('original main restarted during join')
        existing_lock_is_held();require_source_idle('before_success_receipt')
        if predecessor(manifest,False)!=base_pin:raise ValueError('original raw lineage changed before seal')
        _own_original_backups(saved)
        result={'schema':'source53_owner_joined_v1','source_batch':53,'approval_sha256':authority['approval_pin']['sha256'],
            'prepared_manifest_pin':PREPARED_PIN,'authority_manifest_pin':AUTHORITY_PIN,'base_receipt_pin':base_pin,
            'backup':str(backup),'targets':saved,'protected':manifest['protected'],'new_directories':[],
            'App_restarted':False,'marker_changed':False,'customer_database_opened':False,'session_copied':False,
            'deployed':False,'real_GUI_verified':False,'commercial_complete':False}
        receipt_temp=prepared_temp(RECEIPT,(json.dumps(result,ensure_ascii=False,indent=2)+'\n').encode('utf-8'))
        temporaries.append(receipt_temp);os.rename(receipt_temp,RECEIPT)
    except BaseException as error:
        rollback=[]
        for item,target,before,after in reversed(attempted):
            try:
                no_link_parent(target);current=blob(target)
                if current==before:rollback.append({'target':str(target),'restored':True,'no_change':True});continue
                if current!=after:raise ValueError('foreign target drift; refuse rollback')
                restore=prepared_temp(target,before);temporaries.append(restore)
                expected(target,item['candidate_pin']);no_link_parent(target)
                require_source_idle('before_own_rollback');os.replace(restore,target);expected(target,item['parent'])
                rollback.append({'target':str(target),'restored':True})
            except BaseException:rollback.append({'target':str(target),'restored':False})
        failure={'schema':'source53_owner_join_failed_v1','source_batch':53,'failed':True,
            'approval_sha256':authority['approval_pin']['sha256'],'authority_manifest_pin':AUTHORITY_PIN,
            'base_receipt_pin':base_pin,'error_type':type(error).__name__,'backup':str(backup) if backup else None,
            'rollback':rollback,'automatic_retry':False}
        with FAILED.open('x',encoding='utf-8') as stream:stream.write(json.dumps(failure,ensure_ascii=False,indent=2)+'\n')
        raise
    finally:
        for temporary in temporaries:temporary.unlink(missing_ok=True)

if __name__=='__main__':main()
