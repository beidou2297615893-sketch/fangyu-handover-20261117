$ErrorActionPreference='Stop'
$ProgressPreference='SilentlyContinue'
[Console]::OutputEncoding=[System.Text.UTF8Encoding]::new($false)
$encoding=[System.Text.UTF8Encoding]::new($false)
$owned=57712
$caller=14328
$cases=('[{"name": "full_fake_live", "predicate": "(CommandLine LIKE \"%C:\\自有WQL兼容\\O''Brien\\work\\owner[_]admin%\" OR CommandLine LIKE \"%C:/自有WQL兼容/O''Brien/work/owner[_]admin%\")", "expected": 1}, {"name": "full_unknown_with_NULL_empty_all_leading_controls", "predicate": "(Name = ''python.exe'' OR Name = ''pythonw.exe'' OR Name = ''py.exe'' OR Name = ''pypy.exe'' OR Name = ''pypy3.exe'' OR Name = ''node.exe'' OR Name = ''bun.exe'' OR Name = ''deno.exe'') AND (CommandLine IS NULL OR CommandLine = \"\" OR CommandLine LIKE \" %\" OR CommandLine LIKE \"\t%\" OR CommandLine LIKE \"\r%\" OR CommandLine LIKE \"\n%\" OR CommandLine LIKE \"\u000b%\" OR CommandLine LIKE \"\f%\" OR CommandLine LIKE \"%owner[_]admin.py%\" OR CommandLine LIKE \"%owner[_]window.py%\" OR CommandLine LIKE \"%desktop[_]entry.py%\" OR CommandLine LIKE \"%app.py%\" OR CommandLine LIKE \"%index.js%\" OR CommandLine LIKE \"%service.cjs%\" OR CommandLine LIKE \"%shared[_]leads[_]v2.cjs%\" OR CommandLine LIKE \"%shared[_]store[_]scope.cjs%\" OR CommandLine LIKE \"%employee[_]workspace.py%\" OR CommandLine LIKE \"%-m%\" OR CommandLine LIKE \"%-c%\" OR CommandLine LIKE \"%-e%\" OR CommandLine LIKE \"%--eval%\")", "expected": 1}, {"name": "backslash_Unicode_apostrophe_literal", "predicate": "CommandLine LIKE \"%C:\\自有WQL兼容\\O''Brien\\work\\owner[_]admin%\"", "expected": 1}, {"name": "forwardslash_Unicode_apostrophe_literal", "predicate": "CommandLine LIKE \"%C:/自有WQL兼容/O''Brien/work/owner[_]admin%\"", "expected": 1}, {"name": "underscore_not_wildcard", "predicate": "CommandLine LIKE \"%C:\\自有WQL兼容\\O''Brien\\work\\ownerXadmin%\"", "expected": 0}, {"name": "relative_alias_literal", "predicate": "CommandLine LIKE \"%owner[_]admin.py%\"", "expected": 1}, {"name": "dynamic_m", "predicate": "CommandLine LIKE \"%-m%\"", "expected": 1}, {"name": "dynamic_c", "predicate": "CommandLine LIKE \"%-c%\"", "expected": 1}, {"name": "dynamic_e", "predicate": "CommandLine LIKE \"%-e%\"", "expected": 1}, {"name": "dynamic_eval", "predicate": "CommandLine LIKE \"%--eval%\"", "expected": 1}]' | ConvertFrom-Json)
$trace='C:\积木软件工坊\项目\方隅公寓客户版\work\source52-native-proposal\owned-wql-trace-593ce4d8bac74b578a749e7073d685d2\TRACE.jsonl'
$firstfail='C:\积木软件工坊\项目\方隅公寓客户版\work\source52-native-proposal\owned-wql-trace-593ce4d8bac74b578a749e7073d685d2\FIRSTFAIL-CASE.json'
$records=@()
function Record($value){[System.IO.File]::AppendAllText($trace,($value|ConvertTo-Json -Depth 8 -Compress)+[Environment]::NewLine,$encoding)}
foreach($case in $cases){
  $query='SELECT ProcessId FROM Win32_Process WHERE ProcessId = '+$owned+' AND ProcessId <> '+$caller+' AND ProcessId <> '+$PID+' AND ('+$case.predicate+')'
  Record ([pscustomobject]@{event='CASE_START';name=$case.name;query=$query})
  try {
    $found=@(Get-CimInstance -Query $query -OperationTimeoutSec 8 -ErrorAction Stop)
    $keys=@($found | ForEach-Object {[int]$_.ProcessId})
    if(@($keys|Where-Object {$_ -ne $owned}).Count -ne 0){throw 'owned PID query boundary violated'}
    $record=[pscustomobject]@{event='CASE_RESULT';name=$case.name;expected=[int]$case.expected;count=$found.Count;pids=$keys;query=$query;query_error=$false}
  } catch {
    $record=[pscustomobject]@{event='CASE_ERROR';name=$case.name;expected=[int]$case.expected;query=$query;query_error=$true;error_type=$_.Exception.GetType().FullName;error=$_.Exception.Message;error_id=$_.FullyQualifiedErrorId}
    if(-not [System.IO.File]::Exists($firstfail)){[System.IO.File]::WriteAllText($firstfail,($record|ConvertTo-Json -Depth 8),$encoding)}
  }
  Record $record
  $records+=@($record)
}
[pscustomobject]@{owned_pid=$owned;caller_pid=$caller;query_pid=$PID;records=$records}|ConvertTo-Json -Depth 8 -Compress
