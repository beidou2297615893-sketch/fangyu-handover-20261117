"""One Root-approved PS5/WMI compatibility sample, server-bound to one owned PID."""
import ast
import base64
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import uuid

OWN = Path('C:/积木软件工坊/项目/方隅公寓客户版/work/source52-native-proposal')
GUARD = Path('C:/积木软件工坊/项目/方隅公寓客户版/work/source52-root-integration/source_idle_guard.py')
PIN = (5688, 'A8B4475C9E0EB3FDB57C5CAE791A0D7953F432E434FE4F21AFB1C9D2B93DF398')
PS = Path('C:/Windows/System32/WindowsPowerShell/v1.0/powershell.exe')
OUT = OWN / ('owned-wql-compat-' + uuid.uuid4().hex)
OUT.mkdir()

def save(name, value):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

raw = GUARD.read_bytes()
assert (len(raw), hashlib.sha256(raw).hexdigest().upper()) == PIN
(OUT / 'guard-snapshot.py').write_bytes(raw)
(OUT / 'verify-carrier.py').write_bytes(Path(__file__).read_bytes())
tree = ast.parse(raw.decode('utf-8'), filename=str(GUARD))
allowed = ('_wql_string', '_like_literal', '_wql_like', '_queries')
nodes = [node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name in allowed]
assert tuple(node.name for node in nodes) == allowed
constants = {}
for node in tree.body:
    if isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name):
        if node.targets[0].id in ('ALIASES', 'RUNTIMES'):
            constants[node.targets[0].id] = ast.literal_eval(node.value)
assert set(constants) == {'ALIASES', 'RUNTIMES'}
fake = Path("C:/自有WQL兼容/O'Brien/work/owner_admin")
ns = {'SOURCE_PATHS': (fake,), **constants}
exec(compile(ast.fix_missing_locations(ast.Module(body=nodes, type_ignores=[])),
             '<pinned-pure-wql-builders>', 'exec'), ns)
save('AUTH-SCOPE.json', {
    'authorization': 'Root approved one owned dummy Windows compatibility sample',
    'guard_path': str(GUARD), 'guard_bytes': PIN[0], 'guard_sha256': PIN[1],
    'only_pure_ast_definitions': list(allowed), 'source_state_calls': 0,
    'real_customer_process_queries': 0, 'database_cookie_vault_reads': 0,
    'root_source_or_graph_mutations': 0,
})

cmd = [sys.executable, '-B', '-I', '-c', 'import sys; sys.stdin.buffer.read(1)',
       str(fake / 'fixture.py'), (fake / 'fixture.py').as_posix(),
       'owner_admin.py', '-m "app"', '-e"fixture"', '--eval=fixture']
save('ARGS.json', {'argv': cmd, 'fake_paths_only': True, 'stdin_exit': True})
result = {'schema': 'source52_owned_pid_wql_compat_v1', 'pass': False,
          'guard_bytes': PIN[0], 'guard_sha256': PIN[1],
          'real_customer_process_queries': 0, 'source_state_calls': 0,
          'app_lock_or_business_calls': 0, 'source_data_mutations': 0}
child = None
started = time.monotonic()
try:
    child = subprocess.Popen(cmd, stdin=subprocess.PIPE, stdout=subprocess.DEVNULL,
                             stderr=subprocess.DEVNULL, creationflags=subprocess.CREATE_NO_WINDOW)
    assert child.poll() is None
    own_pid, caller_pid = child.pid, os.getpid()
    result.update(owned_pid=own_pid, caller_pid=caller_pid)
    queries = ns['_queries'](caller_pid, 1)
    prefix = f'SELECT ProcessId FROM Win32_Process WHERE ProcessId <> {caller_pid} AND ProcessId <> 1 AND '
    assert all(q.startswith(prefix) for q in queries)
    predicates = {'live': queries[0][len(prefix):], 'unknown': queries[1][len(prefix):][1:-1]}
    def like(value):
        return 'CommandLine LIKE ' + ns['_wql_like']('%' + ns['_like_literal'](value) + '%')
    cases = [
        {'name': 'full_fake_live', 'predicate': predicates['live'], 'expected': 1},
        {'name': 'full_unknown_with_NULL_empty_all_leading_controls', 'predicate': predicates['unknown'], 'expected': 1},
        {'name': 'backslash_Unicode_apostrophe_literal', 'predicate': like(str(fake)), 'expected': 1},
        {'name': 'forwardslash_Unicode_apostrophe_literal', 'predicate': like(fake.as_posix()), 'expected': 1},
        {'name': 'underscore_not_wildcard', 'predicate': like(str(fake).replace('owner_admin', 'ownerXadmin')), 'expected': 0},
        {'name': 'relative_alias_literal', 'predicate': like('owner_admin.py'), 'expected': 1},
        *({'name': 'dynamic_' + name, 'predicate': 'CommandLine LIKE ' + ns['_wql_like'](pattern), 'expected': 1}
          for name, pattern in (('m', '%-m%'), ('c', '%-c%'), ('e', '%-e%'), ('eval', '%--eval%'))),
    ]
    save('CASES.json', {'owned_pid': own_pid, 'caller_pid': caller_pid, 'cases': cases})
    # Same JSON single-quoted PS literal and UTF-16LE EncodedCommand carrier as the guard.
    literal = "'" + json.dumps(cases, ensure_ascii=False).replace("'", "''") + "' | ConvertFrom-Json"
    program = """$ErrorActionPreference='Stop'
[Console]::OutputEncoding=[System.Text.UTF8Encoding]::new($false)
$owned=OWNED_VALUE
$caller=CALLER_VALUE
$cases=(MATERIAL_VALUE)
$records=@()
foreach($case in $cases){
  $query='SELECT ProcessId FROM Win32_Process WHERE ProcessId = '+$owned+' AND ProcessId <> '+$caller+' AND ProcessId <> '+$PID+' AND ('+$case.predicate+')'
  $found=@(Get-CimInstance -Query $query -OperationTimeoutSec 8 -ErrorAction Stop)
  $keys=@($found | ForEach-Object {[int]$_.ProcessId})
  if(@($keys | Where-Object {$_ -ne $owned}).Count -ne 0){throw 'owned PID query boundary violated'}
  $records+=@([pscustomobject]@{name=$case.name;expected=[int]$case.expected;count=$found.Count;pids=$keys;query=$query})
}
[pscustomobject]@{owned_pid=$owned;caller_pid=$caller;query_pid=$PID;records=$records}|ConvertTo-Json -Depth 8 -Compress
"""
    program = program.replace('OWNED_VALUE', str(own_pid)).replace('CALLER_VALUE', str(caller_pid)).replace('MATERIAL_VALUE', literal)
    assert 'SELECT ProcessId FROM Win32_Process WHERE ProcessId = ' in program
    assert 'SELECT CommandLine' not in program and 'source_state' not in program
    (OUT / 'PS-CARRIER.ps1').write_text(program, encoding='utf-8')
    encoded = base64.b64encode(program.encode('utf-16le')).decode('ascii')
    (OUT / 'PS-CARRIER-UTF16LE.b64').write_text(encoded + '\n', encoding='ascii')
    value = subprocess.run([str(PS), '-NoProfile', '-NonInteractive', '-EncodedCommand', encoded],
                           capture_output=True, encoding='utf-8', errors='strict', timeout=35,
                           creationflags=subprocess.CREATE_NO_WINDOW)
    (OUT / 'PS-STDOUT.txt').write_text(value.stdout, encoding='utf-8')
    (OUT / 'PS-STDERR.txt').write_text(value.stderr, encoding='utf-8')
    result.update(powershell_exit=value.returncode, powershell_stderr_empty=not value.stderr.strip())
    assert value.returncode == 0 and not value.stderr.strip(), 'PS5/WMI carrier rejected a fixed predicate; preserve first failure'
    observed = json.loads(value.stdout)
    save('RAW-READBACK.json', observed)
    assert observed['owned_pid'] == own_pid and observed['caller_pid'] == caller_pid
    assert type(observed['query_pid']) is int and observed['query_pid'] not in (own_pid, caller_pid)
    records = observed['records']
    assert len(records) == len(cases)
    for case, record in zip(cases, records):
        assert record['name'] == case['name'] and record['expected'] == case['expected']
        assert record['count'] == case['expected'], record['name']
        assert record['pids'] == ([own_pid] if case['expected'] else []), record['name']
        assert record['query'].startswith(f'SELECT ProcessId FROM Win32_Process WHERE ProcessId = {own_pid} AND ')
    result.update(pass_=True, query_count=len(cases), own_pid_only=True,
                  both_full_sets_hit_same_own_pid=True, guard_live_priority_projection='live',
                  cases=[{'name': r['name'], 'expected': r['expected'], 'observed': r['count']} for r in records])
    result['pass'] = result.pop('pass_')
except Exception as exc:
    result.update(error_type=type(exc).__name__, error=str(exc), pass_=False)
    result['pass'] = result.pop('pass_')
    save('FIRSTFAIL.json', result)
finally:
    if child is not None:
        try:
            child.stdin.write(b'X')
            child.stdin.flush()
            child.stdin.close()
            child.wait(timeout=5)
            result.update(owned_shutdown='stdin_natural_exit', owned_exit=child.returncode)
        except Exception as exc:
            if child.poll() is None:
                child.terminate()
                child.wait(timeout=5)
            result.update(owned_shutdown='owned_only_terminate_after_stdin_failure', shutdown_error=type(exc).__name__, owned_exit=child.returncode)
    result['elapsed_seconds'] = round(time.monotonic() - started, 3)
    save('RESULT.json', result)
    print(json.dumps({'result_path': str(OUT / 'RESULT.json'), 'pass': result['pass'],
                      'query_count': result.get('query_count'), 'owned_shutdown': result.get('owned_shutdown')}, ensure_ascii=False))
sys.exit(0 if result['pass'] else 1)
