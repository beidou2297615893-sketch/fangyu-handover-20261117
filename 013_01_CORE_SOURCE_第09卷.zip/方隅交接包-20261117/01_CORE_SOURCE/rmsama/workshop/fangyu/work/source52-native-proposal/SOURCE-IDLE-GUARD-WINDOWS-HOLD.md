# Source52 guard A8B：唯一自有 Windows 小样实际 HOLD

当前结论是 HOLD／Windows compatibility 未通过。先前静态报告的 CODE 有限 PASS 只保留为静态结论，不能升级成本范围可调用 PASS，不能作为最终安装或客户 source idle 证据。

本轮经 Root 明确批准，只执行了一次自有 dummy Python／PS5／WMI 兼容代表，guard 绑定 5688 / `A8B4475C9E0EB3FDB57C5CAE791A0D7953F432E434FE4F21AFB1C9D2B93DF398`。仅 AST 提取 `_wql_string/_like_literal/_wql_like/_queries` 四纯函数；不 import 完整 guard，不调用 source_state。SOURCE_PATHS 在自有 carrier namespace 替换成假中文 `C:/自有WQL兼容/O'Brien/work/owner_admin`，ALIASES/RUNTIMES 仍实际 pinned AST 常量。所有 server query 都加 `ProcessId = 60872`，仅 `SELECT ProcessId`，另外排除 caller22572 和 query PS 自己 `$PID`；无原客户或其它任务 PID／CommandLine 返回。

实际结果：PS exit1，Get-CimInstance 返回 Invalid Query，HRESULT `0x80041017`。stderr 同时包含首次使用 CIM module 的 progress CLIXML。dummy60872 经 stdin 自然退出，exit0；没有查询或控制原 App，没有正式／业务／数据修改，没有重试、参数轮转或重复 spawn。

raw carrier 的顺序是 full_fake_live、full_unknown（含 NULL/empty/全部 leading controls）、其它单条件；脚本只在全部完成后返回 records，所以首失败 stderr 无 case 标签，不能据此冒称已准确定位是路径/apostrophe 还是控制字符谓词。该取证限制保留，不用预期替代实际。完整 args、fixed cases、PS 程序和 encoded payload 已在唯一目录原样保存，Root 可定点读 raw material 判断下一修正；当前报告不跑第二次。

必要下一步建议：

- Root 定点核这两个首谓词的真实 WMI parser 兼容。控制字符 LIKE 是否可被 parser 接受尚未知，不应以官方一般字符串规则直接当实兼容通过。若需要第二个定位代表，应先批准固定新 carrier：仅新 owned PID，逐 case 持久输出名与有限错误／结果，不能回落到当前客户查询或广泛更改参数重试。
- PS 设置 `$ProgressPreference='SilentlyContinue'` 可避免新 PS process 的正常 module-import progress 写入 stderr 后触发 guard 的 `stderr.strip()` unknown。保留 ErrorAction Stop、真实错误 stderr、timeout 与 schema 检查，不能清空或吞真实查询异常。本条是实际 stderr 的可用性风险；不把它与 Invalid Query 混为同一根因。
- 无论查询原因是什么，现 guard 的异常路径会 unknown，未出现 false idle 的实际证据。外层必须 HOLD，不能以失败静态兼容故事视为当前 source idle、FAILED 可 retry 或 source_mutations=0。

## 实际证据 pins

目录：`C:/积木软件工坊/项目/方隅公寓客户版/work/source52-native-proposal/owned-wql-compat-a4dc5847f0b148ee9b29140c64684a27`。

| 文件 | bytes | SHA256 |
|---|---:|---|
| RESULT.json | 635 | C3F10348FE2E0B59322A1B4139984378467D8231FDD54B3197E0B8EA97992CF6 |
| FIRSTFAIL.json | 543 | FE9ADA9F1E6488D14DE1B76BE2BF14D62E7B4CACA30A2290509F487346A445EE |
| PS-CARRIER.ps1 | 2949 | 8E9C7E17D1D0ACC072717E24D70CA907B0BC20184E74DB266C5603DF683F36D5 |
| PS-STDERR.txt | 1242 | D44ACE11EEB62B80E8BF24F2AB649F460FD5C452B90F17C162878E5DBA9255A6 |
| CASES.json | 2481 | 508E982D056D71073B191708E5608DE3ED6D81E053D7618FA2E68D638FC5F115 |
| ARGS.json | 420 | DC698DCD5729A86E0E37DB919FA0A366E5C4268DB4A7C90AFF6C27AC70F50935 |

自有 verify_owned_wql.py 8912 / `3837A9280C00769A2B983FF6EDB3A1E764DCBFBB8FB99D7DE57FE98233427252` 已作为 verify-carrier.py 保存。snapshot 字节等于 A8B guard；raw stdout/stderr/FIRSTFAIL/RESULT 不改写。

先前 SOURCE-IDLE-GUARD-REVIEW.md 6219 / `B6AD564E10D1E5898FC1F8EEE37DB216D7379E98725D285E0B0B6E160AAA671E`，JSON1435 / `C513AAABB3BC8693BF9975FD9AF3F0FEE327330578F5FBC3BB84F0A50DF572DC`，SOURCE-IDLE-PROPOSAL.md10341 / `9C0E71260B8A3D4CAAA0DFCD29AB0EB7F950A91A84B6EB271B8CD14F337225AC` 均保留。

边界：仅 CODE＋这一次 owned PID 录制／Windows carrier；无真实客户当前 idle、原 byte-lock、实际 Source50/51/52业务 apply、GUI、真人或生产验收声明。
