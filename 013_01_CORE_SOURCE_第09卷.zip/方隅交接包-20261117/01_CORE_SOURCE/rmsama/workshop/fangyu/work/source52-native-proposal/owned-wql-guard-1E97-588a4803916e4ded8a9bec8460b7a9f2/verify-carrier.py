"""Root-approved one new-pin four-case sample; no original customer queries."""
import ast
import base64
import copy
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import uuid

OWN = Path('C:/积木软件工坊/项目/方隅公寓客户版/work/source52-native-proposal')
OLD = OWN / 'owned-wql-trace-593ce4d8bac74b578a749e7073d685d2/guard-snapshot.py'
GUARD = Path('C:/积木软件工坊/项目/方隅公寓客户版/work/source52-root-integration/source_idle_guard.py')
PIN = (5948, '1E97220595CCD6954F67FAABFCAE83E52734D4EE59188F0657C9B0363FBA3AA1')
OLDPIN = (5688, 'A8B4475C9E0EB3FDB57C5CAE791A0D7953F432E434FE4F21AFB1C9D2B93DF398')
PYTHON = Path('C:/Users/rmsama/miniconda3/python.exe')
PS = Path('C:/Windows/System32/WindowsPowerShell/v1.0/powershell.exe')
OUT = OWN / ('owned-wql-guard-1E97-' + uuid.uuid4().hex)
OUT.mkdir()

def save(name, value):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

def checked(path, pin):
    raw = path.read_bytes()
    assert (len(raw), hashlib.sha256(raw).hexdigest().upper()) == pin
    return raw

raw, old_raw = checked(GUARD, PIN), checked(OLD, OLDPIN)
(OUT / 'guard-snapshot.py').write_bytes(raw)
(OUT / 'old-guard-snapshot.py').write_bytes(old_raw)
(OUT / 'verify-carrier.py').write_bytes(Path(__file__).read_bytes())
new_tree, old_tree = ast.parse(raw.decode('utf-8')), ast.parse(old_raw.decode('utf-8'))
expected = copy.deepcopy(old_tree)
expected_functions = {n.name: n for n in expected.body if isinstance(n, ast.FunctionDef)}
# Exact AST whitelist: one LIKE return expression, one blanks expression, one PS string line.
like_return = expected_functions['_wql_like'].body[-1]
assert isinstance(like_return, ast.Return) and isinstance(like_return.value.left.right, ast.Name)
like_return.value.left.right = ast.Call(func=ast.Attribute(value=ast.Name(id='value', ctx=ast.Load()), attr='replace', ctx=ast.Load()),
                                      args=[ast.Constant(value=chr(92)), ast.Constant(value=chr(92) * 2)], keywords=[])
queries_function = expected_functions['_queries']
blank_nodes = [i for i, n in enumerate(queries_function.body)
               if isinstance(n, ast.Expr) and isinstance(n.value, ast.Call)
               and isinstance(n.value.func, ast.Attribute) and isinstance(n.value.func.value, ast.Name)
               and n.value.func.value.id == 'blanks' and n.value.func.attr == 'extend']
assert len(blank_nodes) == 1
queries_function.body[blank_nodes[0]] = ast.parse("blanks.append('CommandLine LIKE '+_wql_like('[^!-~]%'))").body[0]
program_assignments = [n for n in expected_functions['source_state'].body
                       if isinstance(n, ast.Assign) and isinstance(n.targets[0], ast.Name) and n.targets[0].id == 'program']
assert len(program_assignments) == 1
old_program = program_assignments[0].value.value
assert old_program.count("$ErrorActionPreference='Stop'\n") == 1
program_assignments[0].value.value = old_program.replace("$ErrorActionPreference='Stop'\n", "$ErrorActionPreference='Stop'\n$ProgressPreference='SilentlyContinue'\n")
assert ast.dump(expected, include_attributes=False) == ast.dump(new_tree, include_attributes=False), 'new guard contains unreviewed AST delta'
save('CODE-DELTA.json', {'pass': True, 'old_guard_bytes': OLDPIN[0], 'old_guard_sha256': OLDPIN[1],
                        'new_guard_bytes': PIN[0], 'new_guard_sha256': PIN[1],
                        'whole_module_AST_equals_exact_three_edits': True,
                        'edits': ['LIKE string-parser backslash doubling', 'raw-control blanks extend replaced by negated printable range append', 'PS ProgressPreference only'],
                        'other_module_functions_constants_imports_unchanged': True})
allowed = ('_wql_string', '_like_literal', '_wql_like', '_queries')
nodes = [n for n in new_tree.body if isinstance(n, ast.FunctionDef) and n.name in allowed]
assert tuple(n.name for n in nodes) == allowed
constants = {}
for n in new_tree.body:
    if isinstance(n, ast.Assign) and len(n.targets) == 1 and isinstance(n.targets[0], ast.Name) and n.targets[0].id in ('ALIASES', 'RUNTIMES'):
        constants[n.targets[0].id] = ast.literal_eval(n.value)
assert set(constants) == {'ALIASES', 'RUNTIMES'}
fake = Path("C:/自有WQL兼容/O'Brien/work/owner_admin")
ns = {'SOURCE_PATHS': (fake,), **constants}
exec(compile(ast.fix_missing_locations(ast.Module(body=nodes, type_ignores=[])), '<pinned-pure-wql-builders>', 'exec'), ns)
# With explicit executable, leading SP produces an empty CRT argv0; options follow it.
# This runs only the owned stdin dummy, with no duplicate executable argument to be treated as a script.
dummy_options = ['-B', '-I', '-c', 'import sys; sys.stdin.buffer.read(1)', str(fake / 'fixture.py')]
raw_command_line = ' ' + subprocess.list2cmdline(dummy_options)
save('ARGS.json', {'explicit_executable': str(PYTHON), 'raw_command_line': raw_command_line,
                   'leading_SP': True, 'owned_stdin_dummy_only': True, 'fake_backslash_path_only': True})
save('AUTH-SCOPE.json', {'approval': 'Root approved one fixed-1E97 four-case owned Windows sample',
                        'source_state_calls': 0, 'real_customer_process_queries': 0,
                        'formal_source_data_app_lock_operations': 0})
result = {'schema': 'source52_owned_pid_wql_guard_1E97_v1', 'pass': False,
          'guard_bytes': PIN[0], 'guard_sha256': PIN[1], 'exact_CODE_delta_pass': True,
          'source_state_calls': 0, 'real_customer_process_queries': 0,
          'app_lock_business_data_mutations': 0, 'raw_leading_SP': True}
child = None
started = time.monotonic()
try:
    child = subprocess.Popen(raw_command_line, executable=str(PYTHON), stdin=subprocess.PIPE,
                             stdout=subprocess.DEVNULL, stderr=subprocess.PIPE,
                             creationflags=subprocess.CREATE_NO_WINDOW)
    assert child.poll() is None, 'own raw-leading-SP dummy exited before query; do not retry argv'
    owned, caller = child.pid, os.getpid()
    result.update(owned_pid=owned, caller_pid=caller)
    queries = ns['_queries'](caller, 1)
    prefix = f'SELECT ProcessId FROM Win32_Process WHERE ProcessId <> {caller} AND ProcessId <> 1 AND '
    assert all(q.startswith(prefix) for q in queries)
    unknown = queries[1][len(prefix):][1:-1]
    def like(value):
        return 'CommandLine LIKE ' + ns['_wql_like']('%' + ns['_like_literal'](value) + '%')
    cases = [
        {'name': 'double_backslash_Unicode_apostrophe_literal', 'predicate': like(str(fake)), 'expected': 1},
        {'name': 'literal_underscore_negative_ownerXadmin', 'predicate': like(str(fake).replace('owner_admin', 'ownerXadmin')), 'expected': 0},
        {'name': 'complete_new_unknown_compound_parses', 'predicate': unknown, 'expected': 1},
        {'name': 'negated_printable_range_matches_real_leading_SP', 'predicate': 'CommandLine LIKE ' + ns['_wql_like']('[^!-~]%'), 'expected': 1},
    ]
    assert len(cases) == 4 and not any(ord(ch) < 32 for case in cases for ch in case['predicate'])
    save('CASES.json', {'owned_pid': owned, 'caller_pid': caller, 'cases': cases})
    literal = "'" + json.dumps(cases, ensure_ascii=False).replace("'", "''") + "' | ConvertFrom-Json"
    def ps_literal(value):
        return "'" + str(value).replace("'", "''") + "'"
    program = """$ErrorActionPreference='Stop'
$ProgressPreference='SilentlyContinue'
[Console]::OutputEncoding=[System.Text.UTF8Encoding]::new($false)
$encoding=[System.Text.UTF8Encoding]::new($false)
$owned=OWNED_VALUE
$caller=CALLER_VALUE
$cases=(MATERIAL_VALUE)
$trace=TRACE_VALUE
$firstfail=FIRSTFAIL_VALUE
$records=@()
function Record($value){[System.IO.File]::AppendAllText($trace,($value|ConvertTo-Json -Depth 8 -Compress)+[Environment]::NewLine,$encoding)}
foreach($case in $cases){
  $query='SELECT ProcessId FROM Win32_Process WHERE ProcessId = '+$owned+' AND ProcessId <> '+$caller+' AND ProcessId <> '+$PID+' AND ('+$case.predicate+')'
  Record ([pscustomobject]@{event='CASE_START';name=$case.name;query=$query})
  try {
    $found=@(Get-CimInstance -Query $query -OperationTimeoutSec 8 -ErrorAction Stop)
    $keys=@($found|ForEach-Object {[int]$_.ProcessId})
    if(@($keys|Where-Object {$_ -ne $owned}).Count -ne 0){throw 'owned PID query boundary violated'}
    $record=[pscustomobject]@{event='CASE_RESULT';name=$case.name;expected=[int]$case.expected;count=$found.Count;pids=$keys;query=$query;query_error=$false}
  } catch {
    $record=[pscustomobject]@{event='CASE_ERROR';name=$case.name;expected=[int]$case.expected;query=$query;query_error=$true;error_type=$_.Exception.GetType().FullName;error=$_.Exception.Message;error_id=$_.FullyQualifiedErrorId}
    if(-not [System.IO.File]::Exists($firstfail)){[System.IO.File]::WriteAllText($firstfail,($record|ConvertTo-Json -Depth 8),$encoding)}
  }
  Record $record
  $records+=@($record)
}
[pscustomobject]@{owned_pid=$owned;caller_pid=$caller;query_pid=$PID;records=$records}|ConvertTo-Json -Depth 8 -Compress
"""
    program = (program.replace('OWNED_VALUE', str(owned)).replace('CALLER_VALUE', str(caller))
               .replace('MATERIAL_VALUE', literal).replace('TRACE_VALUE', ps_literal(OUT / 'TRACE.jsonl'))
               .replace('FIRSTFAIL_VALUE', ps_literal(OUT / 'FIRSTFAIL-CASE.json')))
    assert 'SELECT ProcessId FROM Win32_Process WHERE ProcessId = ' in program and 'SELECT CommandLine' not in program
    (OUT / 'PS-CARRIER.ps1').write_text(program, encoding='utf-8')
    encoded = base64.b64encode(program.encode('utf-16le')).decode('ascii')
    (OUT / 'PS-CARRIER-UTF16LE.b64').write_text(encoded + '\n', encoding='ascii')
    value = subprocess.run([str(PS), '-NoProfile', '-NonInteractive', '-EncodedCommand', encoded],
                           capture_output=True, encoding='utf-8', errors='strict', timeout=35,
                           creationflags=subprocess.CREATE_NO_WINDOW)
    (OUT / 'PS-STDOUT.txt').write_text(value.stdout, encoding='utf-8')
    (OUT / 'PS-STDERR.txt').write_text(value.stderr, encoding='utf-8')
    result.update(powershell_exit=value.returncode, stderr_empty=not value.stderr.strip())
    assert value.returncode == 0 and not value.stderr.strip()
    observed = json.loads(value.stdout)
    save('RAW-READBACK.json', observed)
    assert observed['owned_pid'] == owned and observed['caller_pid'] == caller
    records = observed['records']
    assert len(records) == 4
    for case, record in zip(cases, records):
        assert case['name'] == record['name'] and case['expected'] == record['expected']
        assert record['query'].startswith(f'SELECT ProcessId FROM Win32_Process WHERE ProcessId = {owned} AND ')
        if not record['query_error']:
            assert all(pid == owned for pid in record['pids'])
    trace = [json.loads(line) for line in (OUT / 'TRACE.jsonl').read_text(encoding='utf-8').splitlines()]
    assert len(trace) == 8
    errors = [r for r in records if r['query_error']]
    mismatches = [r for r in records if not r['query_error'] and r['count'] != r['expected']]
    result.update(query_count=4, owned_pid_only=True, failed_cases=[r['name'] for r in errors],
                  mismatched_cases=[r['name'] for r in mismatches],
                  cases=[{'name': r['name'], 'expected': r['expected'], 'observed': r.get('count'), 'query_error': r['query_error']} for r in records],
                  pass_=not errors and not mismatches)
    result['pass'] = result.pop('pass_')
    if not result['pass']:
        save('FIRSTFAIL.json', result)
except Exception as exc:
    result.update(error_type=type(exc).__name__, error=str(exc))
    save('FIRSTFAIL.json', result)
finally:
    if child is not None:
        try:
            child.stdin.write(b'X')
            child.stdin.flush()
            child.stdin.close()
            child.wait(timeout=5)
            result.update(owned_shutdown='stdin_natural_exit', owned_exit=child.returncode)
        except Exception as exc:
            if child.poll() is None:
                child.terminate()
                child.wait(timeout=5)
            result.update(owned_shutdown='owned_only_terminate_after_stdin_failure', shutdown_error=type(exc).__name__, owned_exit=child.returncode)
        (OUT / 'OWN-DUMMY-STDERR.bin').write_bytes(child.stderr.read())
    result['elapsed_seconds'] = round(time.monotonic() - started, 3)
    save('RESULT.json', result)
    print(json.dumps({'result_path': str(OUT / 'RESULT.json'), 'pass': result['pass'],
                      'failed_cases': result.get('failed_cases'), 'mismatched_cases': result.get('mismatched_cases'),
                      'owned_shutdown': result.get('owned_shutdown')}, ensure_ascii=False))
sys.exit(0 if result['pass'] else 1)
