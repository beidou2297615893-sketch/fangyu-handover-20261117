"""Read-only independent artifact/AST verification. Does not run any native story."""
import ast
import copy
import hashlib
import json
from pathlib import Path

OWN = Path('C:/积木软件工坊/项目/方隅公寓客户版/work/source52-native-proposal')
EX = Path('C:/积木软件工坊/项目/方隅公寓客户版/work/source52-store-manager/native-state-design/execution').resolve()
ROOTC = Path('C:/积木软件工坊/项目/方隅公寓客户版/work/source52-root-integration')
FROZEN = EX / 'FROZEN.json'
reads = {}

def pin(raw):
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest().upper()}

def read(path, expected=None, fixture_only=True):
    path = Path(path).resolve(strict=True)
    if fixture_only:
        assert path.is_relative_to(EX), str(path)
    raw = path.read_bytes()
    actual = pin(raw)
    if expected is not None:
        assert actual == expected, (str(path), actual, expected)
    reads[str(path)] = actual
    return raw

def load(path, expected=None):
    return json.loads(read(path, expected))

f = load(FROZEN, {'bytes': 17410, 'sha256': 'D8131B6BF014FC9D27AECCCBC68A3C218DA856838432E4D36E53859CA3A1E38A'})

def verify_refs(value):
    if isinstance(value, dict):
        if 'path' in value and 'pin' in value:
            read(value['path'], value['pin'])
        for child in value.values():
            verify_refs(child)
    elif isinstance(value, list):
        for child in value:
            verify_refs(child)

verify_refs(f)
snapshot = load(f['snapshot_inputs']['path'], f['snapshot_inputs']['pin'])
for row in snapshot['inputs']:
    read(row['snapshot'], row['pin'])
rb = load(f['post_run_control_readback']['path'], f['post_run_control_readback']['pin'])
expected_binds = {
    'source_idle_guard.py': {'PROJECT'},
    'join-source52-reviewed.py': {'BASE_MANIFEST_PIN','JOIN_AUTHORIZED','PRIOR_MANIFEST_PIN','PROJECT','SOURCE_GUARD_PIN'},
    'next_open_source.py': {'PROJECT','ROOT_MANIFEST_PIN','TARGET_PATHS'},
    'next_open_source51.py': {'BASE_MANIFEST_PIN','MANIFEST_PIN','PROJECT'},
    'next_open_source52.py': {'BASE_MANIFEST_PIN','GUARD_PIN','JOIN_AUTHORIZED','MANIFEST_PIN','PROJECT'},
    'source_next_open_launcher.py': {'ENTRY_PARENT_PIN','HELPER_PIN','LATEST_PIN','PROJECT','SUCCESSOR_PIN'},
}

def masked(raw, names):
    tree = ast.parse(raw)
    seen = set()
    for node in tree.body:
        if isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name) and node.targets[0].id in names:
            seen.add(node.targets[0].id)
            node.value = ast.Constant(value='INDEPENDENT_FIXED_FIXTURE_BINDING')
    assert seen == names, (seen, names)
    return ast.dump(tree, include_attributes=False)

proofs = []
fixtures = set()
for row in rb['proofs']:
    fixture = Path(row['fixture']).resolve(strict=True)
    assert fixture.is_relative_to(EX / 'runs')
    source, bound = row['snapshot'], row['bound_source']
    assert Path(bound['path']).resolve(strict=True).is_relative_to(fixture)
    names = set(row['only_constant_bindings'])
    assert names == expected_binds[Path(source['path']).name]
    original = read(source['path'], source['pin'])
    actual = read(bound['path'], bound['pin'])
    assert masked(original, names) == masked(actual, names), bound['path']
    proofs.append({'fixture': str(fixture), 'file': Path(source['path']).name, 'pin': pin(actual),
                   'actual_control_AST_unchanged': True, 'only_constant_bindings': sorted(names)})
    fixtures.add(fixture)
assert len(proofs) == 102 and len(fixtures) == 17
source44_pin = {'bytes': 9601, 'sha256': '5F5E3EA22AF7C1FA0FEA71CFEFDA12A9D669C190D5470960901029BF8F4750FB'}
for fixture in fixtures:
    read(fixture / 'work/product-upgrade-20261009/audits/join-source44-reviewed.py', source44_pin)

newguard = {'bytes': 5948, 'sha256': '1E97220595CCD6954F67FAABFCAE83E52734D4EE59188F0657C9B0363FBA3AA1'}
delta = []
for key, filename, constant, finalpin in (
    ('Root_CAS_snapshot','join-source52-reviewed.py','SOURCE_GUARD_PIN',{'bytes':30340,'sha256':'DAA27AA127AC0FA9EE08DA4DD32EC274743352D2DFE7FD5DD18786610892B245'}),
    ('Root_helper_snapshot','next_open_source52.py','GUARD_PIN',{'bytes':15374,'sha256':'D9250FC3DCD2ED859DAF2CD5A98D54291A7D3681A3F8B3AF9813667E528B51BF'}),
):
    oldraw = read(f[key]['path'], f[key]['pin'])
    actual = read(ROOTC / filename, finalpin, fixture_only=False)
    expected = ast.parse(oldraw)
    assignments = [n for n in expected.body if isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Name) and n.targets[0].id == constant]
    assert len(assignments) == 1
    assert ast.literal_eval(assignments[0].value) == f['guard_snapshot_A8_recorded_transport_only_not_WMI_PASS']['pin']
    assignments[0].value = ast.parse(repr(newguard), mode='eval').body
    assert ast.dump(expected, include_attributes=False) == ast.dump(ast.parse(actual), include_attributes=False)
    constants = {n.targets[0].id: n.value for n in ast.parse(actual).body if isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Name)}
    assert ast.literal_eval(constants['JOIN_AUTHORIZED']) is False
    if filename == 'next_open_source52.py':
        assert ast.literal_eval(constants['MANIFEST_PIN']) is None
    delta.append({'path': str(ROOTC/filename), 'pin': finalpin, 'exact_only_assignment_changed': constant,
                  'new_guard_pin': newguard, 'control_AST_unchanged': True, 'JOIN_AUTHORIZED': False})

case_rows = []
for group in f['evidence']:
    groupresult = load(group['path'], group['pin'])
    for entry in group['cases']:
        case = load(entry['path'], entry['pin'])
        row = {key: value for key, value in case.items() if key not in ('events','execs')}
        row['path'] = entry['path']
        row['pin'] = entry['pin']
        row['events_summary'] = [{'operation': e.get('operation'), 'phase': e.get('phase'), 'state': e.get('state'),
                                  'target': Path(e['target']).name if e.get('target') else None}
                                 for e in case.get('events', [])]
        row['execs'] = case.get('execs', [])
        case_rows.append(row)

normal = Path(f['evidence'][0]['cases'][0]['path']).parent
audits = normal / 'work/product-upgrade-20261009/audits'
receipts = {batch: load(audits/f'source{batch}-joined.json') for batch in (50,51,52)}
assert receipts[51]['base_receipt_pin'] == pin(read(audits/'source50-joined.json'))
assert receipts[52]['base_receipt_pin'] == pin(read(audits/'source51-joined.json'))
normal52 = []
for row in receipts[52]['targets']:
    target = Path(row['target']).resolve(strict=True)
    backup = Path(row['backup']).resolve(strict=True)
    assert target.is_relative_to(normal) and backup.is_relative_to(normal/'backups')
    assert pin(read(target)) == row['candidate']
    assert pin(read(backup)) == row['parent']
    normal52.append({'target': str(target.relative_to(normal/'work')), 'parent_pin': row['parent'],
                     'final_pin': row['candidate'], 'backup_pin_actual': pin(read(backup))})
assert len(normal52) == 9
map50 = {row['target']:row['candidate'] for row in receipts[50]['targets']}
map50.update({row['path']:row['pin'] for row in receipts[50]['protected']})
map51 = {row['target']:row['candidate'] for row in receipts[51]['targets']}
map51.update({row['path']:row['pin'] for row in receipts[51]['protected']})
local = str(normal/'work/app/src/web/workspace/local-transport.mjs')
assert local not in map50 and local not in map51
coverage = []
for row in receipts[52]['targets']:
    target = row['target']
    if target == local:
        coverage.append({'target': target, 'independent52_only': True, 'actual52_backup_equals_explicit_parent': True})
        continue
    assert map51[target] == row['parent']
    if map50[target] == row['parent']:
        layer50proof = 'actual52_parent_backup'
    else:
        previous = next(x for x in receipts[51]['targets'] if x['target'] == target)
        assert previous['parent'] == map50[target]
        assert pin(read(previous['backup'])) == map50[target]
        layer50proof = 'actual51_original_parent_backup'
    coverage.append({'target': target, 'layer50_proof': layer50proof, 'layer51_proof': 'actual52_original_parent_backup',
                     'current52_final_alone_not_reused_as_older_pin': True})
assert len(coverage) == 9

result = {
    'schema':'source52_native_actual_independent_readback_v1',
    'FROZEN_pin':pin(read(FROZEN)), 'frozen_refs_all_match_actual':True,
    'fixture_roots':17,'actual_control_AST_proofs':102,'Source44_actual_exact_fixture_copies':17,
    'Root_guard_pin_only_delta':delta, 'case_count':len(case_rows), 'cases':case_rows,
    'normal_actual52_targets_and_backups':normal52,'normal_cumulative_coverage':coverage,
    'normal_raw50_to_raw51_to_actual52_receipt_pin_chain':True,
    'old50_51_apply':'recorded','nonbatch_predecessor_public_bytes':'synthetic recorded fixtures',
    'entry_preflight_pid_state_fresh_exec':'recorded; own byte-lock release was actually probed',
    'consumer_PowerShell_CIM_transport':'recorded A8; not WMI PASS',
    'new_guard_1E97_windows_four_cases':'separate previously reviewed owned evidence, not rerun',
    'reader_runtime_story_CIM_App_source_state_lock_calls':0,'reader_formal_backups_SRC_DB_cookie_reads':0,
    'actual_file_pins_read':reads,
}
out=OWN/'NATIVE-STATE-INDEPENDENT-READBACK.json'
out.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
summary={key:value for key,value in result.items() if key not in ('cases','actual_file_pins_read','normal_actual52_targets_and_backups','normal_cumulative_coverage')}
summary['case_summaries']=[{key:value for key,value in row.items() if key not in ('events_summary','execs','path','pin')} for row in case_rows]
summary['output_path']=str(out)
print(json.dumps(summary,ensure_ascii=False,indent=2))
