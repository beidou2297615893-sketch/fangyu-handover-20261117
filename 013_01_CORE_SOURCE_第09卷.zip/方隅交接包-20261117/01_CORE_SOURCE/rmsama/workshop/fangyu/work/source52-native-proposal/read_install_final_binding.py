"""Only pinned public-code AST and three published-authority byte readback."""
import ast
import hashlib
import json
from pathlib import Path
OWN=Path('C:/积木软件工坊/项目/方隅公寓客户版/work/source52-native-proposal')
BASE=Path('C:/积木软件工坊/项目/方隅公寓客户版/work/source52-root-integration')
AUDITS=Path('C:/积木软件工坊/项目/方隅公寓客户版/work/product-upgrade-20261009/audits')
PEER=Path('C:/积木软件工坊/项目/方隅公寓客户版/work/source52-independent-review/FINAL-NATIVE-REVIEW.md')
reads={}
def pin(raw):return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest().upper()}
def read(path,proof=None):
    raw=path.read_bytes();actual=pin(raw)
    if proof is not None:assert actual==proof,(str(path),actual,proof)
    reads[str(path)]=actual;return raw
oldpin={'bytes':8555,'sha256':'E365AFAD4AD3E1E7C45A5882652983AC6A88A6ED3243E8BDBE43A1B9ACB74378'}
newpin={'bytes':8911,'sha256':'6DC1D17AB09DFCBC1A9DAFADF2123C3221CA21735DF4098C76CBA9979ECA0F11'}
peerpin={'bytes':4539,'sha256':'5760E4A2D10E2C7F40CF50EFB6AB8662B73AA789DA698FE37E55C46EA27F006D'}
graphpin={'bytes':3306,'sha256':'66A2C256FC8C31278F7C0354AC6A69DD3D0D9EE5BB102E0B21266D206E86ABEA'}
helperpin={'bytes':15464,'sha256':'18F99253AF933F1964A0A1F27F78F23D045C2C46363C4A252C22E65761E01680'}
launcherpin={'bytes':4987,'sha256':'598E11A541AADBBEB8A1CA55E6169B5D793C5D80D875603086B773E2671DA432'}
old=read(BASE/'install_native.py',oldpin);new=read(BASE/'install-native-authorized.py',newpin)
expected=ast.parse(old)
values={'PEER_PIN':peerpin,'GRAPH_PIN':graphpin,'HELPER_PIN':helperpin,'LAUNCHER_PIN':launcherpin,'INSTALL_AUTHORIZED':True}
seen=set()
for node in expected.body:
    if isinstance(node,ast.Assign) and len(node.targets)==1 and isinstance(node.targets[0],ast.Name) and node.targets[0].id in values:
        key=node.targets[0].id
        assert ast.literal_eval(node.value) is (False if key=='INSTALL_AUTHORIZED' else None)
        node.value=ast.parse(repr(values[key]),mode='eval').body;seen.add(key)
assert seen==set(values)
assert ast.dump(expected,include_attributes=False)==ast.dump(ast.parse(new),include_attributes=False)
graph=json.loads(read(BASE/'FINAL-GRAPH.json',graphpin))
peer=read(PEER,peerpin).decode('utf-8')
assert graph['helper_candidate_pin']==helperpin and graph['launcher_candidate_pin']==launcherpin
assert graph['source_guard_pin']=={'bytes':5948,'sha256':'1E97220595CCD6954F67FAABFCAE83E52734D4EE59188F0657C9B0363FBA3AA1'}
assert graph['launcher_parent_pin']=={'bytes':4626,'sha256':'AA029206565CA20227131E06C200FBAA385C909CA5C21B274CA83477F1992176'}
read(BASE/'next_open_source52-final.py',helperpin);read(BASE/'source_next_open_launcher-final.py',launcherpin)
published=json.loads(read(BASE/'AUTHORITY-PUBLISHED.json'))
assert published['graph_pin']==graphpin and published['final_peer_pin']==peerpin and published['bound_installer_pin']==newpin
pairs=[('join-source52-reviewed-final.py','join-source52-reviewed.py','CAS_pin'),
       ('authority-stage/source52-final-root-read.json','source52-final-root-read.json','gate_pin'),
       ('authority-stage/source52-manifest.json','source52-manifest.json','manifest_pin')]
actual=[]
assert len(published['files'])==3
for source,target,key in pairs:
    stage=read(BASE/source,graph[key]);target_path=AUDITS/target;current=read(target_path,graph[key])
    assert stage==current
    record=next(row for row in published['files'] if Path(row['path'])==target_path)
    assert record['pin']==graph[key]
    actual.append({'stage':str(BASE/source),'AUDITS':str(target_path),'pin':graph[key],'actual_bytes_equal':True})
assert published['thin_files_installed'] is False and published['business_apply_calls']==0
out={'schema':'source52_install_final_binding_independent_readback_v1','pass':True,
     'parent':oldpin,'candidate':newpin,'whole_module_AST_exact_five_assignments_only':True,
     'assignments':values,'unchanged_bindings':['GUARD_PIN','PARENT_PIN','IMMUTABLE','PROJECT','WORK','OWN','AUDITS'],
     'published_stage_AUDITS_exact_three':actual,
     'peer_actual_pin':peerpin,'peer_scope_read':'limited stage graph/literal and accepted own/recorded evidence, not source idle or real App/production/business completion',
     'graph_uninstalled_snapshot_flags_not_rewritten':True,
     'installation_or_business_execution':0,'source_state_CIM_process_App_original_lock_backup_QA_calls':0,
     'Root_source_or_author_mutations':0,'actual_pins':reads}
path=OWN/'INSTALL-FINAL-BINDING-READBACK.json';path.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'output':str(path),'pass':True,'AST_changes':list(values),'published_bytes':actual,'peer_pin':peerpin,'runtime_calls':0},ensure_ascii=False))
