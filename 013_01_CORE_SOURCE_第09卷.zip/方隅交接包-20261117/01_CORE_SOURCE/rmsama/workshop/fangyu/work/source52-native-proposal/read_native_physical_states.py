"""Read only current owned fixture artifacts; no story/control invocation."""
import hashlib
import json
from pathlib import Path
OWN=Path('C:/积木软件工坊/项目/方隅公寓客户版/work/source52-native-proposal')
EX=Path('C:/积木软件工坊/项目/方隅公寓客户版/work/source52-store-manager/native-state-design/execution').resolve()
material=json.loads((OWN/'NATIVE-STATE-INDEPENDENT-READBACK.json').read_bytes())
parents={row['target']:row['parent_pin'] for row in material['normal_actual52_targets_and_backups']}
finals={row['target']:row['final_pin'] for row in material['normal_actual52_targets_and_backups']}
def pin(raw):return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest().upper()}
def get(path):
    path=Path(path).resolve(strict=True)
    assert path.is_relative_to(EX)
    return path.read_bytes()
rows=[]
for case in material['cases']:
    fixture=Path(case['path']).parent.resolve(strict=True)
    assert fixture.is_relative_to(EX/'runs')
    work=fixture/'work';states={};temps=set()
    for relative,parent in parents.items():
        target=work/relative;raw=get(target);actual=pin(raw)
        state='parent' if actual==parent else 'final52' if actual==finals[relative] else 'other'
        if raw==b'SYNTHETIC FOREIGN preserved\n':state='foreign_preserved'
        if raw==b'SYNTHETIC BAD independent parent\n':state='bad_independent_parent_preserved'
        states[relative]={'state':state,'pin':actual}
        for p in target.parent.iterdir():
            if p.is_file() and (p.name.startswith('.source52') or p.suffix=='.tmp'):temps.add(str(p))
    assert not temps
    audits=work/'product-upgrade-20261009/audits'
    marker_pins={name:pin(get(audits/name)) if (audits/name).exists() else None
                 for name in ('source52-next-open-started.json','source52-join-failed.json','source52-joined.json')}
    counts={state:sum(v['state']==state for v in states.values()) for state in sorted({v['state'] for v in states.values()})}
    label=case['case']
    if label=='idle chain then cumulative future zero invoke':assert counts=={'final52':9} and marker_pins['source52-joined.json'] is not None
    elif label.startswith('fresh before_success_receipt'):assert counts=={'final52':9} and marker_pins['source52-joined.json'] is None
    elif label.startswith('fresh before_replace'):assert counts=={'final52':1,'parent':8}
    elif label=='actual idle IO rollback foreign=True':assert counts=={'foreign_preserved':1,'parent':8}
    elif label.startswith('new local-transport parent'):assert counts=={'bad_independent_parent_preserved':1,'parent':8}
    else:assert counts=={'parent':9}, (label,counts)
    rows.append({'case':label,'fixture':str(fixture),'current_owned_public_target_state_counts':counts,
                 'marker_pins':marker_pins,'adjacent_source52_temps':[], 'target_states':states})
result={'schema':'source52_owned_physical_states_independent_readback_v1','pass':True,
        'runtime_story_queries_locks_App_calls':0,'formal_original_backups_SRC_data_reads':0,
        'cases':rows,'scope':'only 16 frozen-case owned public targets and own receipt markers; no old367 binary reads'}
out=OWN/'NATIVE-STATE-PHYSICAL-READBACK.json';out.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'output_path':str(out),'pass':True,'case_counts':[{k:r[k] for k in ('case','current_owned_public_target_state_counts','adjacent_source52_temps')} for r in rows]},ensure_ascii=False))
