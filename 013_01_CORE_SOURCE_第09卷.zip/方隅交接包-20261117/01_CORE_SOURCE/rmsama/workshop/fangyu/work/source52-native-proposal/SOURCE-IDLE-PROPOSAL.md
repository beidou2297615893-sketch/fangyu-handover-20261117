Source52 源占用最小可实施路线：复用本项目已运行的CIM subprocess／失败即hold接口，改为服务端固定范围WQL、只取ProcessId存在性，输出live／unknown／idle。相对／动态启动与不可归属metadata必须unknown。它是已知正常本客户启动方式的保守瞬时metadata守卫，不是全机任意注入、历史CWD、所有import或未来无竞争的证明。Root独占实现与批准图；本报告没有执行CIM、PID／pilot／preflight查询、源码consumer、App、DB／Cookie／Vault或Owner私有state。

已读 source52-current 顶部最新r2及CAS占用HOLD记录，本原CAS-CODE-REVIEW6866/850F7F56仍保史。实际成熟来源是 [join-source49b-native-origin-admin-reviewed.py:22](C:/积木软件工坊/项目/方隅公寓客户版/work/product-upgrade-20261009/audits/join-source49b-native-origin-admin-reviewed.py:22)，7811/F8D92D20BDEC6088FA7C1B2DE0C9BFC75949C872F39F1311751D0A89556AD3CB；其ensure_portal_absent在60及73行分别于备份前／temp后调用，26–28行以timeout／stderr／未知状态拒绝。该代码随实际49b join成功回执2599/6B983910E1A27AC5024A17BE06CE5C8E39AD813EEB5C883A7FEA67845E42DD4B已运行。Source49同接口在28–35行、66／79行调用。它们覆盖owner-admin/cloud；51 installer的同类接口在21–29行只覆盖wrapper。旧实现均先取Win32_Process再Where-Object，不能按当前窄隐私边界原样复制。可以复用成熟transport／timeout／静态错误／有限输出，不复用全机cmdline收集或旧人工作业空闲确认。

必要真实源码行证： [owner_admin.py:241](C:/积木软件工坊/项目/方隅公寓客户版/work/owner-admin-20261004/owner_admin.py:241) 每请求读HOME/site；244–247行还从work/app/src/web/workspace取assets。189行Server维持进程，故pilot dead不证明site消费者idle。377行写入的私有state含cookie，383行runtime.dpapi属于私态，不能为PID探测读取或解封。普通Native入口是 [desktop_entry.py:215](C:/积木软件工坊/项目/方隅公寓客户版/work/desktop-self-use-entry/desktop_entry.py:215)，OS初始CommandLine可以仍是这个入口，而不是Python内部后改的sys.argv app.py；app范围因此还需确切desktop_entry.py入口。旧同PID／byte锁是另一独立条件，不可代替源占用。

官方能力核对：微软 [Get-CimInstance](https://learn.microsoft.com/en-us/powershell/module/cimcmdlets/get-ciminstance?view=powershell-7.5) 的示例3/4及Property段支持服务端Query/Filter和仅所需返回属性（网页行160–170、211–218、495–498）；不用Where-Object遍历原始CommandLine。 [Win32_Process](https://learn.microsoft.com/en-us/windows/win32/cimwin32prov/win32-process) 属性表有启动CommandLine但没有CWD属性，这是从完整属性表得出的范围判断（行39–75、128–138）。psutil的 [cwd定义](https://psutil.readthedocs.io/stable/#psutil.Process.cwd) 是当前目录并可能为空（行865–866），不能据此推最初相对脚本路径；本任务不引入它或追查其它PID内存。Restart Manager的 [资源占用接口](https://learn.microsoft.com/en-us/windows/win32/rstmgr/using-restart-manager) 也不能据一次未见文件占用推断已缓存Python/Node源码消费者不存在，故不替换本接口。

按agent-reach实际尝试GitHub CLI公共repo API，但CLI本机未认证，未登录或索要token；随后用匿名官方GitHub API和微软／原项目文档做最小交叉核验。PowerShell/PowerShell为MIT、未归档，pushed_at2026-10-13T23:22:40Z；giampaolo/psutil为BSD-3-Clause、未归档，pushed_at2026-10-13T18:53:30Z。来源为各repo公开API，非安装验收。本路线用现有Windows PowerShell/CIM，无额外GUI、驱动、SDK、硬件、付费或新Python包；不为一次守卫安装PowerShell7／psutil或重复CAS研究。

建议固定私有接口 source_state(caller_pid)：caller_pid必须type int、positive且等于os.getpid；不得来自HTTP／env／任意caller PID白名单。Root CAS另核STARTED同pid、原entry及实际原byte锁。只明确排除这个普通caller与本次PowerShell child的$PID，不排除旧main、其它启动器或匹配源码消费者。child是查询worker，不是源使用许可。返回只允许scope／state及匿名count；不输出ProcessId列表／CommandLine／CWD／路径／其它任务内容。query或JSON失败、超时、stderr、schema不符皆unknown。

固定范围与决定顺序：

- live谓词含本客户work/app/src、work/owner-admin-20261004（含server/site）、work/cloud/workspace；另纳确切普通desktop-self-use-entry/desktop_entry.py。同时有Windows backslash与forward slash固定表示。绝对命中就是保守live；允许false-positive hold，不进行数据／私态确认。
- unknown谓词在固定已知Python/Node等正常runtime名内，核缺CommandLine（NULL、empty及不明确空白）、固定relative entry aliases、无法归属的-m/-c/-e/--eval等动态模式。owner_admin.py、desktop_entry.py、app.py、index.js/service.cjs等可为其它路径的同名启动，不能断言是本客户live，也不能断言与本客户无关；只返回unknown，不追查CWD或其它任务命令行。绝对本客户live优先于unknown，unknown再优先于idle。
- idle只意味着上述已声明正常runtime／入口模型内的两条完整metadata查询均成功且无匹配。绝不写“全机不存在任意源注入/隐藏import”。不支持的host／改名runtime／随意eval字符串等无法由这个方法完备归属；需要此种更强证明时仍unknown／另行设计，不能扩大当前授权去枚举私有cmdline。相对启动/CWD未知、字段缺席或未完成查询都不能仅凭绝对root空结果变成idle。

服务端只用SELECT ProcessId FROM Win32_Process WHERE <固定谓词>，PowerShell只数返回数组，不取CommandLine再本地过滤。本客户固定源命中及相对潜在候选存在性查询是Root已明确接受的有限scope；模糊候选不进行PID后续探测。如果某后继边界连这种潜在alias存在性检查也不允许，能力将不足以产生完整idle，应直接unknown，不以删掉相对谓词换可用性。

WQL与宿主编码必须分层，不能一个escape同时处理所有场景：

1. 普通scalar字符串：微软 [WHERE Clause](https://learn.microsoft.com/en-us/windows/win32/wmisdk/where-clause) 行38–41及 [about_WQL5.1](https://learn.microsoft.com/en-us/powershell/module/microsoft.powershell.core/about/about_wql?view=powershell-5.1) 行410–440说明反斜杠／引号规则。比如等值Caption中的反斜杠需双写，单引号可写反斜杠加单引号。Name='python.exe'这些固定值没有特殊字符。
2. LIKE不能照搬上述backslash双写：微软协议 [MS-WMI2.2.1](https://learn.microsoft.com/en-us/openspecs/windows_protocols/ms-wmi/6c8a38f4-4ee1-47cb-99f1-b42718a575ce) 行37明确LIKE的backslash例外。固定Windows路径LIKE pattern保每个单backslash；不要将其改为两个字面backslash而漏真实根。建议LIKE使用WQL双引号delimiter，固定Windows路径无双引号；路径中的单引号于是是普通字符，不需借普通scalar的\'。若将来固定常量中出现非法双引号，拒绝，不引入任意输入quote猜测。
3. LIKE通配： [LIKE Operator](https://learn.microsoft.com/en-us/windows/win32/wmisdk/like-operator) 行34–47及 [MS-WMI表达式表](https://learn.microsoft.com/en-us/openspecs/windows_protocols/ms-wmi/cf0410f3-541f-477a-848f-9133a1272725) 行176–189明确_是单字符通配，literal写[_]；literal %和[分别按[%]、[[]]形式。先处理原常量，再加有意的两端%通配；不要把新插入的bracket再escape。此处路径与alias都是Root固定常量，不是通用SQL输入函数。
4. PS单引号literal：将JSON整个包为单引号字符串时，JSON文本中的'需double成''；然后ConvertFrom-Json恢复WQL字符串。JSON own backslash escape只是承载层，不能第二次改变最终WQL LIKE pattern。EncodedCommand用UTF-16LE，stdout只有限JSON；不要让PS直接解释查询文本为代码。

下面均是最终WQL文本示例，未执行；显示的LIKE反斜杠是单个，不是Python/JSON字符串源码：

```text
Name = 'python.exe'
Caption = 'Fabrikam\\TimO'
Name = 'Tim O\'Brian'
CommandLine LIKE "%C:\客户\work\owner-admin-20261004\owner[_]admin.py%"
CommandLine LIKE "%C:\O'Brien\work\cloud\workspace%"
CommandLine LIKE "%owner[_]admin.py%"
CommandLine IS NULL OR CommandLine = ''
```

WQL NULL和empty不同，about_WQL5.1行382–394有明确例子。空白commandline也应保守unknown，不用当前scope无匹配推idle。NOT规则方面，LIKE Operator行49–50要求NOT置于field前；当前首guard的AND NOT (OR group)不应未经隔离代表宣称已可调用。最小无需排除live即可删掉该NOT条件：同一条绝对行同时增加unknown_count不妨碍live优先。若保留排除，逐项AND NOT CommandLine LIKE <pattern>，不要泛化普通SQL语法。

Root首guard5136/F33EAD3479444187CE79DD12BDD32ADDC9E5AB653A5C0887FAEF809A12A98F3D的窄CODE意见是待修／非最终PASS：LIKE当前共用_wql_string双写backslash，可漏node receiver.cjs C:\客户\work\cloud\workspace这类非alias loader的根参数，导致两谓词均miss而误idle；unknown只IS NULL会漏empty；精确'% -m app%'会漏-m "app"，空格依赖的-c/-e会漏quoted／紧邻／其它空白形式。需将LIKE单独处理、missing补齐、动态flag保守扩成unknown；NOT group按上一段简化。PS JSON单引号doubling／UTF16LE EncodedCommand、仅SELECT ProcessId、child $PID与same caller约束的方向正确，但尚未作真实WMI代表。

落点保持原审核要求：同原byte锁内且任何52 STARTED/业务invoke前核一次；CAS备份/temp前、replace前及success封口前fresh核。任何已invoke后失败source_mutations未知，不能根据rollback/PID/elapsed冒0。新状态代表只需自有运行时literal/Unicode/relative/dynamic/NULL/empty/query-fail/错caller、live/unknown拒和当前root-positive路径等必要边缘；可用只匹配自有新PID的隔离WMI代表证明LIKE／PS5层，不能以这份静态文档称当前本机真实源idle，不能运行当前guard来替代Root授权。
