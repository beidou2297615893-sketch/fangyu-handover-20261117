# Source52 guard A8B：唯一因果 trace 与前建议纠正

结论仍为 Windows compatibility HOLD。Root 批准的第二项工作是唯一必要的定位 trace，不是更改匹配参数反复试验：guard snapshot5688/A8B、首 CASES 的10个 predicate、首 dummy argv均不改。只用新 owned57712、caller14328替换查询边界 PID，并逐 case即时写 TRACE；每个原 fixed case 仅执行一次。新增 `$ProgressPreference='SilentlyContinue'` 只抑制正常 module-import progress，真实 CIM ErrorAction Stop 错误在该 case 的 catch 中记录后继续其余固定 case。

所有实际 CIM query 都是 server `WHERE ProcessId = 57712`，仅 `SELECT ProcessId`，且排除 caller与本次query PS自身；无原 App、其它任务 PID、CommandLine输出或来源状态 query。没有调用 source_state、正式 byte-lock、Source50/51/52业务、数据或平台。新dummy经stdin自然退出0。

## 实际逐 case 结果

| 原 fixed case | 实际 |
|---|---|
| full_fake_live | Invalid Query 0x80041017 |
| full_unknown_with_NULL_empty_all_leading_controls | Invalid Query 0x80041017 |
| backslash_Unicode_apostrophe_literal | Invalid Query 0x80041017 |
| forwardslash_Unicode_apostrophe_literal | 成功，expected1 / observed1 |
| underscore_not_wildcard（反斜杠路径） | Invalid Query 0x80041017，不能据此称负例已过 |
| relative_alias_literal | 成功，expected1 / observed1 |
| dynamic_m / dynamic_c / dynamic_e / dynamic_eval | 各成功，expected1 / observed1 |

10项均实际发起一次；6项成功，4项真实查询错误，0 count mismatch。PS exit0仅代表carrier完整逐casecatch，不代表guard通过。stderr实际空，说明progress抑制承载可用；这与4个 Invalid Query不是同一根因。完整20条CASE_START/结果事件实际保留。

## 必要纠正和最小下一步

先前 SOURCE-IDLE-PROPOSAL.md 与静态报告依据 MS-WMI 协议的 LIKE backslash例外，建议本机 LIKE不使用普通scalar的 backslash doubling。这个推断被本机实际 WMI parser否定：相同假路径与相同quote／JSON／Unicode层，单反斜杠形式实际拒绝，正斜杠形式实际命中。将此旧建议标为 withdrawn，首F33中“double backslash必漏路径”的 P1推断不能继续作为合入依据；其它NULL/empty/relative动态缺口独立保留。Root应修WQL string parser层，再用新固定pin的必要owned-PID代表验证真实命中，不能用文档推断直接称double或single已经兼容。

完整unknown谓词与当前guard的runtime／alias／NULL／empty／SP/TAB/CR/LF/VT/FF结构相同，实际WMI拒绝。现在已经定位到这一个compound，但尚未将其拆成单control逐项尝试，不能冒称哪一个控制字符是唯一原因。最小可考虑用没有raw控制字符的ASCII首字符negatedrange（如 `[^!-~]%`）保守匹配所有非printable首字符及Unicode；额外unknown是保守HOLD。该替代模式仅为给Root的候选思路，未执行，需Root固定新pin后代表，不能写成已验证方案。NULL/empty仍必须保留，不能为了过parser漏掉missing metadata。

当前guard没有任何实际false idle证据：异常路径会unknown，故主要阻断是正常接线不可用。必须继续HOLD，而不是允许安装时以当前pilot dead、elapsed或后继业务QA取代source guard。

没有第三次spawn或参数循环。若Root修guard后批准新pin代表，仅核上述真实两个parser层修正＋progress的同最难链；不查当前客户、不重复旧平台/商业QA。

## 实际证据 pins

唯一目录：`C:/积木软件工坊/项目/方隅公寓客户版/work/source52-native-proposal/owned-wql-trace-593ce4d8bac74b578a749e7073d685d2`。

| 文件 | bytes | SHA256 |
|---|---:|---|
| RESULT.json | 1482 | A5D61E18ABBD43636E685987A508634D8E51D0A08B1934ACCDB6CFF2CC36EFF7 |
| FIRSTFAIL.json | 1391 | D97504658BCB38E9DA7F8D99F55A069CB8F6CCE2336CA8CE61C902C49A5D6948 |
| FIRSTFAIL-CASE.json | 632 | 897E805EE0E1CBCB14F6DD1ADDCA75DD3D0620294ED195E788E9AF428CF42731 |
| TRACE.jsonl | 8228 | 14C4B7F086C30DF4282963083F2EF71578523E5C193FCABD0A6CB19FBDB0D49B |
| PS-CARRIER.ps1 | 4056 | 2A3EFD719230EE3B05EF86D601D73E51F5DDE55A7915F6B1DD19352BC68E91E6 |
| PS-STDERR.txt | 0 | E3B0C44298FC1C149AFBF4C8996FB92427AE41E4649B934CA495991B7852B855 |

ORIGINAL-ARGS.json与ORIGINAL-CASES.json分别完整保留首420/DC698DCD…F50935与2481/508E982D…C5F115字节；guard-snapshot.py完整保留5688/A8B。新CASES含新PID metadata但其cases数组与首原文逐对象相同；新ARGV与首argv逐项相同，实际代码checked父pins并assert。PS-CARRIER-UTF16LE.b64、PS-STDOUT.txt、RAW-READBACK.json和verify-carrier.py均保留。第一兼容失败目录、HOLD报告、首静态报告、首路线报告不改写。

本报告只覆盖CODE＋owned Windows carrier实证；没有当前客户source idle、GUI、真人、平台、生产或最终52安装PASS声明。
