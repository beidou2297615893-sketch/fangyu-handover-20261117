载体首次准备在纯AST检查处失败：program selector既选中初始str literal赋值，也选中后续program.replace赋值。该错误在Popen及CIM前发生，0dummy/0query，不是Root guard或Windows代表失败。

本目录原verify-carrier.py与两个guard snapshot保留。仅将own carrier selector限定str ast.Constant，原Root候选pin、匹配函数、CASE谓词、假argv均不改；经Root已批准的唯一新pinactual owned Windows代表尚未执行，随后在新唯一目录执行一份。
