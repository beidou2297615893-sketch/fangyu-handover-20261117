Source52 原生最小后继协议建议。范围仅是方案与既有接口定位，尚无实现／状态代表／CODE PASS；没有生成空 pin 可执行 helper，也未写 Root 源码、正式图、installer、中心文档或原实例。8 个业务目标仍需作者冻结，实际候选 pin 与 exact set 未确认。

已实际只读核的原生父：旧 next_open_source.py 18590 / 6DD31FBCB9864272C329C146DD7EA3E9F74F334131F84DDFEB5E3D63ED8BB611；next_open_source51.py 14697 / 8540B5A0AE7572E5C2DC8A550AD74BA0918FF931C09945E7F802E0FB00F6EEF0；当前 launcher4626 / AA029206565CA20227131E06C200FBAA385C909CA5C21B274CA83477F1992176；当前 entry15900 / C2FEE1D2355A7A6605E807BFCC71E339D1C23B83D23E92913849DA4E96B980B3。这是当前实际父状态；正常打开后阶段性 entry 父会是 Source50 的1FF419A6或Source51的B3251E2C，不能混称已经发生。

业务父约束暂按 Root 提供的范围收敛为8 existing／0 new：service.cjs 的父必须是 Source51 exact future 30955 / C4D44315A93138CDAE8FE4980267DEA2034EF910F4B827818438BFC8EF43A7D8，其余7个父需在 Source51 459 protected 中逐对象比对，待8 freeze确认。Source52 targets不能包含 entry、thin helpers、launcher、marker或data。其后继保护集应从已审51 protected459、51 targets11 final及本次必要公开依赖形成 union，减去exact8再去重，冲突pin必须拒绝；不预报实际最终数量。四平台revision tuple没有本批8路径的事实沿 Root 已核报告，待冻结时只做集合关系核，不重四平台功能QA。

需要一个新、最终精确 pin 的薄 helper52；保原50和51 helper immutable。当前51 _readback 会按当前文件字节校验51目标／保护，52改这些文件后它应拒绝，因此不能改旧51逻辑去容许新平台，也不能在未来52成功后无条件继续调旧51 readback。现launcher可由Root按原两文件备份CAS方式后继替换，原父是4626/AA029206；新launcher只load已核raw的50、51和52固定helper。新helper52／launcher继续在业务prepared／保护图之外，使pin图单向：业务candidates→prepared；CAS与prepared／独审→gate；gate／CAS／exacttargets／protected→52 manifest；manifest→helper52；helper52＋immutable旧helperpins→launcher。不生成任何真实用途材料。

同一普通打开应在原现有byte OS锁内完成所需50→51→52阶段，而不是串调51.before_normal_open：该函数在51完成后直接fresh exec，不会返回供52同锁接续。可复用已审底层接口而保函数体不变：50._plan、50._exclusive_existing_lock、50._start_once、50._readback；51._plan、51._base_receipt、51._start_once、51._invoke及51._readback。新52只加阶段调度及累计证明，无任意HTTP／env路径选择器。

普通路径伪码（仅说明，不是可执行代码）：

1. checked-raw load旧50、旧51和最终52 helper；52 metadata接口先拒自己的未完成STARTED／FAILED，再选择本阶段已核entry pin。原entry.preflight必须ready、固定iid d075ac9c039e44038ddbc6f3e753d73c。
2. 已有52成功：先累计readback52，证明所有原回执／backup／当前final；零apply，允许普通fresh original entry。任何failure或不明证明拒绝，不拿现52bytes充当旧版本。
3. 未有52成功：任何52 STARTED／FAILED先held。复用50._exclusive_existing_lock，锁内再同原entry.preflight＋固定iid／固定52计划。现有51成功时用未受52覆盖的51._readback证明51及50；不要再直接50._readback当前已被51覆盖的文件。
4. 没有51成功时：若50尚无成功，50._start_once＋51._invoke执行原50 CAS一次；50 unknown STARTED拒绝。50成功readback通过后，51._base_receipt(applied=False)给真实50 raw receipt pin，51._start_once＋51._invoke原51 CAS一次，再51._readback。已成功的50／51不重复invoke；相应FAILED或未知不得越过。
5. 真实51成功之后核52八父全部相等、保护完整；原52 STARTED创建包含同pid、固定iid、52manifest／approval和原51 raw receipt pin；原51成功receipt已绑定原50 raw receipt pin，建议52同记录原50 raw pin便于审查。原52 CAS应校验这个当次STARTED及同一byte锁，才可替换8existing／8backup。
6. 52成功后在锁内立即累计readback52。只释放自己的锁，随后fresh original argv固定为 [sys.executable, '-X', 'utf8', '-B', '-I', ENTRY]，原main自行重取原锁。没有平台升级／recovery参数、marker动作、会话迁移或grant穿越。

累计readback52必须区分“旧版本证据”与“当前版本”：

| 要证明的旧层 | 当前目标被覆盖时必须读取的实物 | 绑定关系 |
| --- | --- | --- |
| 原50 final或protected，目标曾被51覆盖 | 51实际成功receipt指定的原父backup，即使后来52又覆盖 | 51.parent == 50旧pin；backup实际字节 == 51.parent |
| 原50 final或protected，未被51覆盖，仅被52覆盖 | 52实际成功receipt指定的原父backup | 52.parent == 50旧pin；backup实际字节 == 52.parent |
| 原51 final或protected，被52覆盖 | 52实际成功receipt指定的原父backup | 52.parent == 51旧pin；backup实际字节 == 52.parent |
| 上述旧层没有被后继覆盖 | 当前公共文件字节 | 当前字节 == 对应旧层固定pin |
| 本次52 final及未覆盖protected | 当前公共文件字节 | 当前字节 ==52固定manifest／prepared pin |

最难service代表：50原protected若包含原service，必须由51的原父backup证明50旧字节；51 service C4D44315必须由52的原父backup证明；当前service仅证明52final。不能用52backup C4D证明原50service，也不能用52current证明51。原50已被51覆盖的mjs／entry继续用51 backup证明50，不能因为它们在52没有改动就直接拿51current充当50。

每份receipt仍须核真实原schema／batch／iid关系、authority／prepared／gate pin、exact target与parent/final/protected集合、禁业务flag。52 receipt必须绑定原51 raw receipt pin，51 receipt中的base_receipt_pin必须仍等于原50实际raw pin，原回执不得重写成新overlay。备份需是同份成功receipt记录的实际backup根下 target.relative_to(WORK) 路径，普通单链接／无reparse，并逐字节等于固定parent；不能接收任选路径、另一批backup或后造fixture。所有被52覆盖的51旧pin应与52parent对应，所有被51覆盖的50旧pin应与51parent对应；pin碰撞不一致或实物缺席一律held。

8 existing CAS沿已审成熟Source44五工具／父备份／temp／replace／own rollback。52失败只撤销仍属本次52final的自己的替换，保留foreign漂移、原52 STARTED／FAILED／8backup；不回滚已成功50／51，不删除旧receipt或抹掉前级成功。任何中途失败的source_mutations在已经invoke过任一级时应为unknown，不误报0；下一开只held原号，Root明确恢复另行审定，绝不自动从失败前级重新apply。

需要的新代表限装载因果：从尚无50成功一路到52，及已50／已51只补后继的正常分支；52成功未来0invoke且上述两级backup真实验证，篡改51原父backup／52原父backup／原receipt均held；52 STARTED未知／FAILED／byte锁busy不重试；52某actual replace后IO中断只恢复自己、foreign留存、0temp。可用自有固定8字节／实际52CAS与OS锁、明示50/51 recorder／preflight／exec surrogate，不重复平台／店级功能或旧矩阵；8freeze和Root实现后再定点CODE与实际代表审，不能由本方案预先宣称通过。

本轮只读核原生4文件pin、51 service冻结metadata及既有函数接口；没有读取原367runtime全量／真实业务DB、扫描CLI、联网、占原锁、打开GUI／App、操作桌面link或创建新任务。实际实现／新helper／最终pins／安装仍由Root后继，现有51图与旧helpers保持。
