"""Fixed customer source metadata guard. No data, command-line output, or process control.

This is a conservative snapshot of known source consumers, not a universal
closed capability against arbitrary code injection or a future process race.
Relative/dynamic launches and inaccessible runtime metadata hold as unknown.
Nothing is queried at import, or by the launcher's check-only branch.
"""
import base64,json,os,subprocess
from pathlib import Path
PROJECT=Path('C:/积木软件工坊/项目/方隅公寓客户版')
SCOPE='fangyu_customer_source_metadata_v1'
POWERSHELL=Path('C:/Windows/System32/WindowsPowerShell/v1.0/powershell.exe')
SOURCE_PATHS=(PROJECT/'work/app/src',PROJECT/'work/owner-admin-20261004',PROJECT/'work/cloud/workspace',
    PROJECT/'work/desktop-self-use-entry/desktop_entry.py')
ALIASES=('owner_admin.py','owner_window.py','desktop_entry.py','app.py',
    'index.js','service.cjs','shared_leads_v2.cjs','shared_store_scope.cjs',
    'employee_workspace.py')
RUNTIMES=('python.exe','pythonw.exe','py.exe','pypy.exe','pypy3.exe','node.exe','bun.exe','deno.exe')

def _wql_string(value):
    return "'"+value.replace('\\','\\\\').replace("'","\\'")+"'"

def _like_literal(value):
    # WQL LIKE wildcard brackets quote literal underscore and percent.
    return value.replace('[','[[]').replace('_','[_]').replace('%','[%]')

def _wql_like(value):
    # MS-WMI: backslash escaping excludes LIKE clauses. A Windows source path
    # cannot contain a double quote; single quotes are ordinary here.
    if '"' in value:raise ValueError('fixed LIKE literal delimiter changed')
    return '"'+value+'"'

def _queries(caller_pid,query_pid):
    exclude=f'ProcessId <> {caller_pid} AND ProcessId <> {query_pid}'
    absolute=[]
    for path in SOURCE_PATHS:
        for value in (str(path),path.as_posix()):
            absolute.append('CommandLine LIKE '+_wql_like('%'+_like_literal(value)+'%'))
    live='('+ ' OR '.join(absolute)+')'
    runtimes='('+ ' OR '.join('Name = '+_wql_string(x) for x in RUNTIMES)+')'
    names=['CommandLine LIKE '+_wql_like('%'+_like_literal(x)+'%') for x in ALIASES]
    # No CWD is exposed by Win32_Process; ambiguous relative -m / -c / -e
    # consumers cannot be upgraded to idle just because absolute roots miss.
    names.extend('CommandLine LIKE '+_wql_like(x) for x in ('%-m%','%-c%','%-e%','%--eval%'))
    # Both filtered sets may include a known live consumer. Live has priority;
    # no unsupported NOT-of-an-OR expression is needed to suppress duplicates.
    blanks=['CommandLine = '+_wql_like('')]
    blanks.extend('CommandLine LIKE '+_wql_like(x+'%') for x in (' ', '\t', '\r', '\n', '\v', '\f'))
    ambiguous=f'{runtimes} AND (CommandLine IS NULL OR '+ ' OR '.join(blanks+names)+')'
    return (f'SELECT ProcessId FROM Win32_Process WHERE {exclude} AND {live}',
        f'SELECT ProcessId FROM Win32_Process WHERE {exclude} AND ({ambiguous})')

def source_state(caller_pid):
    unknown={'scope':SCOPE,'state':'unknown'}
    if os.name!='nt' or type(caller_pid) is not int or caller_pid!=os.getpid() or caller_pid<=0:
        return unknown
    # All filters are fixed by this reviewed file. PowerShell's own PID is only
    # an exclusion for its query command, never an unverified consumer exemption.
    program="""$ErrorActionPreference='Stop'
[Console]::OutputEncoding=[System.Text.UTF8Encoding]::new($false)
$caller=CALLER_VALUE
$patterns=PATTERN_VALUE
$exclusion='ProcessId <> '+$caller+' AND ProcessId <> '+$PID
$absolute=$patterns.live
$ambiguous=$patterns.unknown
$live=@(Get-CimInstance -Query ('SELECT ProcessId FROM Win32_Process WHERE '+$exclusion+' AND '+$absolute) -OperationTimeoutSec 8 -ErrorAction Stop)
$uncertain=@(Get-CimInstance -Query ('SELECT ProcessId FROM Win32_Process WHERE '+$exclusion+' AND ('+$ambiguous+')') -OperationTimeoutSec 8 -ErrorAction Stop)
$state='idle'
if($uncertain.Count -gt 0){$state='unknown'}
if($live.Count -gt 0){$state='live'}
[pscustomobject]@{scope='fangyu_customer_source_metadata_v1';state=$state;live_count=$live.Count;unknown_count=$uncertain.Count}|ConvertTo-Json -Compress
"""
    # Build WQL predicates locally; no real process metadata is available here.
    queries=_queries(caller_pid,1)
    prefix=f'SELECT ProcessId FROM Win32_Process WHERE ProcessId <> {caller_pid} AND ProcessId <> 1 AND '
    predicates={'live':queries[0].removeprefix(prefix),'unknown':queries[1].removeprefix(prefix)[1:-1]}
    # JSON is passed as a single-quoted PowerShell literal with proper quoting.
    literal="'"+json.dumps(predicates,ensure_ascii=False).replace("'","''")+"' | ConvertFrom-Json"
    program=program.replace('CALLER_VALUE',str(caller_pid)).replace('PATTERN_VALUE','('+literal+')')
    encoded=base64.b64encode(program.encode('utf-16le')).decode('ascii')
    try:
        value=subprocess.run([str(POWERSHELL),'-NoProfile','-NonInteractive','-EncodedCommand',encoded],
            capture_output=True,encoding='utf-8',errors='strict',timeout=22,
            creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
        if value.returncode!=0 or value.stderr.strip() or len(value.stdout)>512:return unknown
        result=json.loads(value.stdout)
        if (type(result) is not dict or set(result)!={'scope','state','live_count','unknown_count'}
            or result['scope']!=SCOPE or result['state'] not in ('idle','live','unknown')
            or any(type(result[x]) is not int or result[x]<0 for x in ('live_count','unknown_count'))):return unknown
        expected='live' if result['live_count'] else 'unknown' if result['unknown_count'] else 'idle'
        return result if result['state']==expected else unknown
    except Exception:return unknown
