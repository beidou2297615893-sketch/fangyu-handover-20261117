只读metadata载体首假设9项父均在Source51 target/protected中，于新增local-transport.mjs处KeyError（工具185a6f）。实际Source51固定prepared没有这个文件；其余8项父匹配。首载体字节保 history/read_cas_code_shape-v1.py。

载体改为明确单独读取该公共current parent，实际5301/00F1B97B…与revision2冻结parent相同。它是52显式覆盖父，不冒旧51保护；不改旧50/51图，未来旧层证明也不应凭空多出这一项。本次仍无CAS/状态/进程/业务DB/实例执行或写入，只做同批固定CODE与metadata读回，错误与修正均保史。
