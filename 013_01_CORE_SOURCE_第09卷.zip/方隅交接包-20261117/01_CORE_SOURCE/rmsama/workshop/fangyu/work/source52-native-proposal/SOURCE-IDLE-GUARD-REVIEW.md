# Source52 fixed source metadata guard：当前 A8B 静态窄审

结论：当前候选的固定 WQL／PowerShell 接线 CODE 有限 PASS；首 F33 的四项具体问题已修。这个结论不证明当前客户源 idle，不是最终 Source52 安装／CAS／业务授权。尚未执行 source_state、CIM 当前进程查询、App、原锁、平台或旧 QA；新 Windows parser 兼容代表待 Root 明确批准后仅对自有新 PID 做。

实际读回对象为 `C:/积木软件工坊/项目/方隅公寓客户版/work/source52-root-integration/source_idle_guard.py`，5688 bytes，SHA256 `A8B4475C9E0EB3FDB57C5CAE791A0D7953F432E434FE4F21AFB1C9D2B93DF398`。范围是这一候选 CODE，Root 后续 CAS/helper 的 exact pin 与调用时序需在其独立最终图／新因果故事中核。

## 必要源码结论

| 接缝 | 当前源码行 | 结论 |
|---|---:|---|
| 客户固定源与入口 | 10–18 | 三客户源根加明确原入口；固定 Python/Node 等 runtime 与 relative aliases。无 env/HTTP/任意目标选择。 |
| scalar 与 LIKE 分开 | 20–31、36–41 | scalar 的 backslash/quote escape 仅给固定 Name；LIKE 保单个 backslash，用双引号 delimiter，固定值若含双引号直接拒。literal `_`→`[_]`、`%`→`[%]`、`[`→`[[]]`；添加的外侧 `%`仍为有意通配。单引号路径作为 LIKE 双引号内部数据，经后层 PS doubling 承载。 |
| relative／动态命令 | 41–49 | 既有 aliases 加宽 `%-m%`、`%-c%`、`%-e%`、`%--eval%`，包含 quoted/紧邻/其它分隔形式时保守 unknown；不以缺绝对根或 pilot dead 推 idle。没有 CWD／私态追查。 |
| NULL 与空白 | 47–49 | NULL、empty 及 leading SP/TAB/CR/LF/VT/FF 都进入匹配 runtime 的 unknown 集合；不是仅 NULL。控制字符 literal 的真实 WMI parser 接受性仍待自有 PID 小样证明。若查询拒绝，当前返回 unknown，不能误报 idle。 |
| 不重复过滤 live | 45–51、66–70 | unknown query 不含未经证明的 NOT-of-OR；绝对命中可同时被 unknown 命中，最终 live 优先，不妨碍拒绝。 |
| 只查询 PID 存在性 | 50–51、63–67 | server WQL `SELECT ProcessId` 与 fixed WHERE；无全机 CommandLine 列表、客户端过滤或任何 CommandLine 输出。仅明确排除 same caller 和这次 query PowerShell `$PID`。 |
| caller 约束 | 53–58 | caller 为严格 int、正数且等于 `os.getpid()`；不能调用者指定别 PID豁免。该约束仍需外层原 entry／STARTED／同 PID byte-lock 证明配合；这里只审本函数边界。 |
| PS5 承载 | 59–84 | fixed PowerShell path、NoProfile/NonInteractive、single-quoted JSON literal 中 apostrophe doubling、ConvertFrom-Json、UTF-16LE EncodedCommand、UTF-8 limited stdout、CREATE_NO_WINDOW。WQL 文本进入 query 参数，不被作为 PowerShell 指令 exec。 |
| fail closed | 81–92 | timeout／非零／stderr／非 JSON／超长 stdout／字段集合、类型、count 或 priority 不符都 unknown。计数 bool 不冒 int；没有 retry／stop／启动／真实数据读取。 |

源码 docstring 行 3–6 对能力限制准确：这是已知源消费者的保守 metadata snapshot；不能冒任意注入或后续新进程 race 的普遍隔离证明。当前固定范围以外、未知 relative loader、非枚举 runtime 或未来进程需额外授权和证据；不把本报告扩大为整机无任意来源消费者。

## 官方规则与已验证项目路线

成熟路线和实际项目行证完整保存在 `C:/积木软件工坊/项目/方隅公寓客户版/work/source52-native-proposal/SOURCE-IDLE-PROPOSAL.md`，10341 / `9C0E71260B8A3D4CAAA0DFCD29AB0EB7F950A91A84B6EB271B8CD14F337225AC`。它保留首 F33 的 HOLD，不被本后继报告改写。原 Source49b 的成熟两次 source-consumer metadata 检查及实际 CAS 回执可复用时序，但旧全机 CommandLine 返回模式不符合本轮窄隐私边界，故只复用 CIM/WQL 接口与 fixed-source 检查目的。

微软 [MS-WMI 2.2.1](https://learn.microsoft.com/en-us/openspecs/windows_protocols/ms-wmi/6c8a38f4-4ee1-47cb-99f1-b42718a575ce) 中 LIKE 的 backslash 例外支持当前 27–31 行；[LIKE Operator](https://learn.microsoft.com/en-us/windows/win32/wmisdk/like-operator) 和 [WQL 表达式 grammar](https://learn.microsoft.com/en-us/openspecs/windows_protocols/ms-wmi/cf0410f3-541f-477a-848f-9133a1272725) 支持当前 literal wildcard brackets。普通 scalar 引号与 backslash 依据 [WHERE Clause](https://learn.microsoft.com/en-us/windows/win32/wmisdk/where-clause)，不能再次用于 LIKE。

[about_WQL 5.1](https://learn.microsoft.com/en-us/powershell/module/microsoft.powershell.core/about/about_wql?view=powershell-5.1) 区分 NULL 与 empty。[Get-CimInstance](https://learn.microsoft.com/en-us/powershell/module/cimcmdlets/get-ciminstance?view=powershell-7.5) 的 server query 支持先 fixed WHERE 再返回有限字段；[Win32_Process](https://learn.microsoft.com/en-us/windows/win32/cimwin32prov/win32-process) 暴露 startup CommandLine，没有可复用的初始 CWD 字段，因此不能把 relative 未绝对命中推成归属不存在。

以上是公开官方文档依据与 CODE 推断，没有当前本机查询证明。采用本机现有 PowerShell 5.1／CIM；不安装 PowerShell7 或 psutil、不引入 CWD/私态推断。

## 一项最小可选 Windows 兼容代表

已向 Root 提出，等待其批准：仅 spawn 自有 dummy Python，stdin 等待；unused 参数为假中文路径，含 backslash／apostrophe／underscore。所有 CIM 查询在 server WHERE 加这一个已知 owned PID，仅 `SELECT ProcessId`，不调用 source_state 或查询原 App/其它来源。复用当前 AST 中无 side effect 的 query builders 与相同 PS JSON／UTF-16LE 承载，核路径命中、underscore 变形不命中、alias/动态 flags unknown、完整控制字符 unknown 谓词可 parse。仅关闭自己的 dummy；不改 Root 候选／正式图／SOURCE／数据。

若 Root 决定由 author 的单一新状态故事承担这个 parser 点，则本报告停留 CODE 有限 PASS，Windows 实兼容仍未验证。不得用本报告当实际 idle 或安装成功回执，也不新增旧 QA 矩阵。
