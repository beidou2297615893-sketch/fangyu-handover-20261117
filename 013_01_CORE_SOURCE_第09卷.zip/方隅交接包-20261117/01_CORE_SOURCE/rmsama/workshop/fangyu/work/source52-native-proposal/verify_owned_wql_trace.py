"""Root-approved one causal trace: unchanged first predicates and dummy argv."""
import base64
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import uuid

OWN = Path('C:/积木软件工坊/项目/方隅公寓客户版/work/source52-native-proposal')
FIRST = OWN / 'owned-wql-compat-a4dc5847f0b148ee9b29140c64684a27'
GUARD = Path('C:/积木软件工坊/项目/方隅公寓客户版/work/source52-root-integration/source_idle_guard.py')
PIN = (5688, 'A8B4475C9E0EB3FDB57C5CAE791A0D7953F432E434FE4F21AFB1C9D2B93DF398')
PS = Path('C:/Windows/System32/WindowsPowerShell/v1.0/powershell.exe')
OUT = OWN / ('owned-wql-trace-' + uuid.uuid4().hex)
OUT.mkdir()

def save(name, value):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

def checked(path, pin):
    raw = path.read_bytes()
    assert (len(raw), hashlib.sha256(raw).hexdigest().upper()) == pin
    return raw

guard_raw = checked(GUARD, PIN)
args_raw = checked(FIRST / 'ARGS.json', (420, 'DC698DCD5729A86E0E37DB919FA0A366E5C4268DB4A7C90AFF6C27AC70F50935'))
cases_raw = checked(FIRST / 'CASES.json', (2481, '508E982D056D71073B191708E5608DE3ED6D81E053D7618FA2E68D638FC5F115'))
(OUT / 'guard-snapshot.py').write_bytes(guard_raw)
(OUT / 'ORIGINAL-ARGS.json').write_bytes(args_raw)
(OUT / 'ORIGINAL-CASES.json').write_bytes(cases_raw)
(OUT / 'verify-carrier.py').write_bytes(Path(__file__).read_bytes())
cmd = json.loads(args_raw)['argv']
cases = json.loads(cases_raw)['cases']
assert len(cases) == 10
save('AUTH-SCOPE.json', {
    'approval': 'Root approved one per-case trace, unchanged guard/predicates/argv',
    'guard_bytes': PIN[0], 'guard_sha256': PIN[1],
    'progress_only_suppressed': True, 'true_query_errors_recorded': True,
    'source_state_calls': 0, 'real_customer_process_queries': 0,
    'formal_source_data_app_lock_operations': 0,
})
result = {'schema': 'source52_owned_pid_wql_trace_v1', 'pass': False,
          'guard_bytes': PIN[0], 'guard_sha256': PIN[1],
          'matching_predicates_changed': False, 'synthetic_argv_changed': False,
          'progress_only_suppressed': True, 'source_state_calls': 0,
          'real_customer_process_queries': 0, 'app_lock_business_or_data_mutations': 0}
child = None
started = time.monotonic()
try:
    child = subprocess.Popen(cmd, stdin=subprocess.PIPE, stdout=subprocess.DEVNULL,
                             stderr=subprocess.DEVNULL, creationflags=subprocess.CREATE_NO_WINDOW)
    assert child.poll() is None
    owned, caller = child.pid, os.getpid()
    result.update(owned_pid=owned, caller_pid=caller)
    save('ARGS.json', {'argv': cmd, 'owned_pid': owned, 'argv_identical_to_first': True})
    save('CASES.json', {'owned_pid': owned, 'caller_pid': caller, 'cases': cases, 'predicates_identical_to_first': True})
    literal = "'" + json.dumps(cases, ensure_ascii=False).replace("'", "''") + "' | ConvertFrom-Json"
    trace_literal = "'" + str(OUT / 'TRACE.jsonl').replace("'", "''") + "'"
    firstfail_literal = "'" + str(OUT / 'FIRSTFAIL-CASE.json').replace("'", "''") + "'"
    program = """$ErrorActionPreference='Stop'
$ProgressPreference='SilentlyContinue'
[Console]::OutputEncoding=[System.Text.UTF8Encoding]::new($false)
$encoding=[System.Text.UTF8Encoding]::new($false)
$owned=OWNED_VALUE
$caller=CALLER_VALUE
$cases=(MATERIAL_VALUE)
$trace=TRACE_VALUE
$firstfail=FIRSTFAIL_VALUE
$records=@()
function Record($value){[System.IO.File]::AppendAllText($trace,($value|ConvertTo-Json -Depth 8 -Compress)+[Environment]::NewLine,$encoding)}
foreach($case in $cases){
  $query='SELECT ProcessId FROM Win32_Process WHERE ProcessId = '+$owned+' AND ProcessId <> '+$caller+' AND ProcessId <> '+$PID+' AND ('+$case.predicate+')'
  Record ([pscustomobject]@{event='CASE_START';name=$case.name;query=$query})
  try {
    $found=@(Get-CimInstance -Query $query -OperationTimeoutSec 8 -ErrorAction Stop)
    $keys=@($found | ForEach-Object {[int]$_.ProcessId})
    if(@($keys|Where-Object {$_ -ne $owned}).Count -ne 0){throw 'owned PID query boundary violated'}
    $record=[pscustomobject]@{event='CASE_RESULT';name=$case.name;expected=[int]$case.expected;count=$found.Count;pids=$keys;query=$query;query_error=$false}
  } catch {
    $record=[pscustomobject]@{event='CASE_ERROR';name=$case.name;expected=[int]$case.expected;query=$query;query_error=$true;error_type=$_.Exception.GetType().FullName;error=$_.Exception.Message;error_id=$_.FullyQualifiedErrorId}
    if(-not [System.IO.File]::Exists($firstfail)){[System.IO.File]::WriteAllText($firstfail,($record|ConvertTo-Json -Depth 8),$encoding)}
  }
  Record $record
  $records+=@($record)
}
[pscustomobject]@{owned_pid=$owned;caller_pid=$caller;query_pid=$PID;records=$records}|ConvertTo-Json -Depth 8 -Compress
"""
    program = (program.replace('OWNED_VALUE', str(owned)).replace('CALLER_VALUE', str(caller))
               .replace('MATERIAL_VALUE', literal).replace('TRACE_VALUE', trace_literal)
               .replace('FIRSTFAIL_VALUE', firstfail_literal))
    assert 'SELECT ProcessId FROM Win32_Process WHERE ProcessId = ' in program
    assert 'SELECT CommandLine' not in program and 'source_state' not in program
    (OUT / 'PS-CARRIER.ps1').write_text(program, encoding='utf-8')
    encoded = base64.b64encode(program.encode('utf-16le')).decode('ascii')
    (OUT / 'PS-CARRIER-UTF16LE.b64').write_text(encoded + '\n', encoding='ascii')
    value = subprocess.run([str(PS), '-NoProfile', '-NonInteractive', '-EncodedCommand', encoded],
                           capture_output=True, encoding='utf-8', errors='strict', timeout=35,
                           creationflags=subprocess.CREATE_NO_WINDOW)
    (OUT / 'PS-STDOUT.txt').write_text(value.stdout, encoding='utf-8')
    (OUT / 'PS-STDERR.txt').write_text(value.stderr, encoding='utf-8')
    result.update(powershell_exit=value.returncode, stderr_empty=not value.stderr.strip())
    assert value.returncode == 0 and not value.stderr.strip()
    observed = json.loads(value.stdout)
    save('RAW-READBACK.json', observed)
    assert observed['owned_pid'] == owned and observed['caller_pid'] == caller
    records = observed['records']
    assert len(records) == len(cases)
    for case, record in zip(cases, records):
        assert case['name'] == record['name'] and case['expected'] == record['expected']
        assert record['query'].startswith(f'SELECT ProcessId FROM Win32_Process WHERE ProcessId = {owned} AND ')
        if not record['query_error']:
            assert all(pid == owned for pid in record['pids'])
    trace = [json.loads(line) for line in (OUT / 'TRACE.jsonl').read_text(encoding='utf-8').splitlines()]
    assert len(trace) == 2 * len(cases)
    assert [row['name'] for row in trace if row['event'] == 'CASE_START'] == [row['name'] for row in cases]
    errors = [row for row in records if row['query_error']]
    mismatches = [row for row in records if not row['query_error'] and row['count'] != row['expected']]
    result.update(query_count=len(records), owned_pid_only=True,
                  failed_cases=[row['name'] for row in errors],
                  mismatched_cases=[row['name'] for row in mismatches],
                  successful_cases=[{'name': row['name'], 'expected': row['expected'], 'observed': row['count']}
                                    for row in records if not row['query_error']],
                  causal_trace_complete=True, pass_=not errors and not mismatches)
    result['pass'] = result.pop('pass_')
    if not result['pass']:
        save('FIRSTFAIL.json', result)
except Exception as exc:
    result.update(error_type=type(exc).__name__, error=str(exc))
    save('FIRSTFAIL.json', result)
finally:
    if child is not None:
        try:
            child.stdin.write(b'X')
            child.stdin.flush()
            child.stdin.close()
            child.wait(timeout=5)
            result.update(owned_shutdown='stdin_natural_exit', owned_exit=child.returncode)
        except Exception as exc:
            if child.poll() is None:
                child.terminate()
                child.wait(timeout=5)
            result.update(owned_shutdown='owned_only_terminate_after_stdin_failure', shutdown_error=type(exc).__name__, owned_exit=child.returncode)
    result['elapsed_seconds'] = round(time.monotonic() - started, 3)
    save('RESULT.json', result)
    print(json.dumps({'result_path': str(OUT / 'RESULT.json'), 'pass': result['pass'],
                      'failed_cases': result.get('failed_cases'), 'mismatched_cases': result.get('mismatched_cases'),
                      'owned_shutdown': result.get('owned_shutdown')}, ensure_ascii=False))
sys.exit(0 if result['pass'] else 1)
