"""Read-only Source52 draft AST/pin audit; no import, process query or QA."""
from pathlib import Path
import ast,hashlib,json

HERE=Path(__file__).resolve().parent
WORK=HERE.parent
DRAFT=WORK/'source52-store-manager/cas-draft'
pin=lambda raw:{'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest().upper()}


def rec(path):return {'path':str(path),'pin':pin(path.read_bytes())}


def constants(raw):
    return {node.targets[0].id:node.value for node in ast.parse(raw).body
        if isinstance(node,ast.Assign) and isinstance(node.targets[0],ast.Name)}


def functions(raw):return {node.name:node for node in ast.parse(raw).body if isinstance(node,ast.FunctionDef)}


def main():
    frozen_raw=(DRAFT/'FROZEN.json').read_bytes()
    assert pin(frozen_raw)=={'bytes':2351,'sha256':'DD1BB6A36E71A55FF77161618AEA8121E72D1977F56210981A0A3AE853C9F262'}
    frozen=json.loads(frozen_raw)
    for row in frozen['files']:
        assert pin(Path(row['path']).read_bytes())==row['pin']
    cas_path=DRAFT/'join-source52-reviewed.py';raw=cas_path.read_bytes()
    assert pin(raw)=={'bytes':27414,'sha256':'2678AA33373EF0B166B05BCA562B134151F87F8E64FEFAE70CE56F1725E7772F'}
    base_path=Path(frozen['base_script']['path']);base=base_path.read_bytes()
    assert pin(base)==frozen['base_script']['pin']
    current=functions(raw);previous=functions(base)
    unchanged={name:ast.dump(current[name])==ast.dump(previous[name]) for name in
        ('existing_lock_is_held','original_main_dead','proof','base_readback')}
    assert all(unchanged.values())
    c=constants(raw)
    assert ast.literal_eval(c['JOIN_AUTHORIZED']) is False and ast.literal_eval(c['BASE_MANIFEST_PIN']) is None
    literal=ast.literal_eval(c['EXPECTED_TARGET_PINS'])
    relative=ast.literal_eval(c['TARGET_RELATIVE'])
    assert len(relative)==len(set(relative))==len(literal)==9
    assert set(relative)==set(literal) and all(row[0] is not None for row in literal.values())
    final_path=Path(frozen['final_business_revision']['path']);final_raw=final_path.read_bytes()
    assert pin(final_raw)==frozen['final_business_revision']['pin']
    final=json.loads(final_raw)
    actual={Path(row['target']).relative_to(WORK).as_posix():(row['parent'],row['candidate_pin']) for row in final['targets']}
    assert set(actual)==set(literal) and len(actual)==9
    changes=[{'target_relative':name,'draft':literal[name],'revision2_required':actual[name]}
             for name in relative if literal[name]!=actual[name]]
    assert {row['target_relative'] for row in changes}=={
        'app/src/web/workspace/member-admin-ui.mjs',
        'owner-admin-20261004/site/member-admin-ui.mjs','app/src/web/workspace/app.mjs'}
    prior51=json.loads((WORK/'source51-root-integration/PREPARED.json').read_bytes())
    final51={Path(row['target']):row['candidate_pin'] for row in prior51['targets']}
    protected51={Path(row['path']):row['pin'] for row in prior51['protected']}
    source_parent_equality=[]
    for row in final['targets']:
        path=Path(row['target'])
        value=final51[path] if path in final51 else protected51[path]
        assert row['parent']==value
        source_parent_equality.append({'target':str(path),'Source51_future_or_protected':value})
    helper=WORK/'product-upgrade-20261009/audits/join-source44-reviewed.py'
    assert pin(helper.read_bytes())=={'bytes':9601,'sha256':'5F5E3EA22AF7C1FA0FEA71CFEFDA12A9D669C190D5470960901029BF8F4750FB'}
    helper_names={'blob','pin','expected','no_link_parent','prepared_temp'}
    assert helper_names <= functions(helper.read_bytes()).keys()
    result={'schema':'source52_cas_draft_non_author_code_review_v1',
        'status':'HOLD FINAL APPLY; ROOT SOURCE-CONSUMER IDLE GUARD REQUIRED',
        'draft_frozen':rec(DRAFT/'FROZEN.json'),'draft_code':rec(cas_path),
        'fixed_base51_code':rec(base_path),'revision2_business_frozen':rec(final_path),
        'Source44_fixed_function_source':rec(helper),
        'unchanged_original_control_AST':unchanged,'JOIN_AUTHORIZED':False,'BASE_MANIFEST_PIN':None,
        'none_pin_flip_cannot_apply_CODE':True,'exact9_existing_no_new_literal':True,
        'required_revision2_final_pin_delta':changes,'Source51_parent_metadata_equality':source_parent_equality,
        'finding':{'priority':'P1','code_location':'original_main_dead / main mutation guard',
            'condition':'pilot main dead while same-client owner-admin/site or cloud source consumer may be live',
            'impact':'target replacement can mix versions in a running same-client source consumer',
            'minimum_Root_supplement':'fixed same-client app/src + owner-admin entry/site + cloud/workspace source idle/live/unknown guard, repeated under the original byte lock before mutations; unknown holds; no unrelated CommandLine collection'},
        'cumulative_ancestor_interface':{
            'CAS_predecessor_checks_current51_fixed_overlays':True,
            'CAS_source51_predecessor_reads_actual51_parent_backups':False,
            'must_not_reuse_current51_readback_for_future52':True,
            'Root_new_helper_must_use_51_backup_for_old50_overwritten_by51_and_52_backup_for_old51_overwritten_by52':True},
        'failed_source_mutations_scope':'CAS failure has no source_mutations=0 assertion; outer coordinator must use unknown after any invocation',
        'pending_final_scope':'Root must rebind Base51 exact pin, revision2 final9, fixed gate/prepared/manifest and new native coordinator before final CODE/graph/story review',
        'CAS_or_state_QA_executed':False,'processes_or_DB_Cookie_or_App_queried':False,
        'Root_or_formal_source_or_50_51_graph_written':False,'commercial_or_GUI_or_platform_verified':False}
    path=HERE/'CAS-CODE-REVIEW.json'
    with path.open('x',encoding='utf-8') as out:out.write(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'report':rec(path),'rebind_final_pin_rows':len(changes),'parent_rows_metadata_verified':9}))


if __name__=='__main__':main()
