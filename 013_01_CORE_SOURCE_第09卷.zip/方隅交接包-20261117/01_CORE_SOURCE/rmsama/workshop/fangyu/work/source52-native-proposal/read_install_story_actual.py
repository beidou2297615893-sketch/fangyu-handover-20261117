"""Only read frozen two-thin artifacts/AST; no installer, guard or process calls."""
import ast
import hashlib
import json
import os
from pathlib import Path
import stat

OWN=Path('C:/积木软件工坊/项目/方隅公寓客户版/work/source52-native-proposal')
BASE=Path('C:/积木软件工坊/项目/方隅公寓客户版/work/source52-independent-review').resolve()
ROOT_INSTALLER=Path('C:/积木软件工坊/项目/方隅公寓客户版/work/source52-root-integration/install_native.py')
reads={}
def pin(raw):return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest().upper()}
def read(path,expected=None,own_only=True):
    path=Path(path).resolve(strict=True)
    if own_only:assert path.is_relative_to(BASE),str(path)
    raw=path.read_bytes();actual=pin(raw)
    if expected is not None:assert actual==expected,(str(path),actual,expected)
    reads[str(path)]=actual
    return raw
def load(path,expected=None):return json.loads(read(path,expected))
ready=load(BASE/'INSTALL-STORY-READY.json',{'bytes':13231,'sha256':'FA37F40635A60E3DE763F811584CB7C77DF7AFE10B3860B116D9C93055B9CEAB'})
def refs(v):
    if isinstance(v,dict):
        if 'path' in v and 'pin' in v:read(v['path'],v['pin'])
        for x in v.values():refs(x)
    elif isinstance(v,list):
        for x in v:refs(x)
refs(ready)
result=load(ready['result']['path'],ready['result']['pin'])
run=Path(ready['result']['path']).parent.resolve(strict=True)
assert len(result['cases'])==7 and result['status']=='PASS'
installer=read(run/'installer-snapshot.py',result['raw_inputs']['installer-snapshot.py'])
assert read(ROOT_INSTALLER,result['raw_inputs']['installer-snapshot.py'],False)==installer
tree=ast.parse(installer)
authorization=[n for n in tree.body if isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Name) and n.targets[0].id=='INSTALL_AUTHORIZED']
assert len(authorization)==1 and ast.literal_eval(authorization[0].value) is False
control_nodes=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in {'proof','absent','main'}]
assert len(control_nodes)==3
source44=read(run/'source44-snapshot.py',result['raw_inputs']['source44-snapshot.py'])
helper_nodes=[n for n in ast.parse(source44).body if isinstance(n,ast.FunctionDef) and n.name in {'blob','pin','expected','no_link_parent','prepared_temp'}]
assert len(helper_nodes)==5
guard=read(run/'guard-snapshot.py',result['raw_inputs']['guard-snapshot.py'])
assert pin(guard)=={'bytes':5948,'sha256':'1E97220595CCD6954F67FAABFCAE83E52734D4EE59188F0657C9B0363FBA3AA1'}
carrier=read(run/'carrier-snapshot.py',result['carrier_pin'])
carrier_tree=ast.parse(carrier)
assert b"n.name in {'proof','absent','main'}" in carrier
assert b'exec(helper_code,g);exec(control_code,g)' in carrier
OLD=b'# own synthetic old launcher\n'
NEW_HELPER=b'# own synthetic new helper\n'
NEW_LAUNCHER=b'# own synthetic new launcher\n'
FOREIGN=b'# independent synthetic foreign helper, preserve\n'
physical=[];nine=[]
for case in result['cases']:
    project=Path(case['project']).resolve(strict=True);assert project.is_relative_to(run)
    thin=project/'work/desktop-self-use-entry';audits=project/'work/audits'
    helper=thin/'next_open_source52.py';launcher=thin/'source_next_open_launcher.py'
    label=project.name;control=load(project/'CONTROL-1.json')
    receipt_path=audits/'source52-native-installed.json';failure_path=audits/'source52-native-install-failed.json'
    immutable={}
    for filename in ('next_open_source.py','next_open_source51.py'):
        raw=read(thin/filename);assert raw==('# own synthetic immutable '+filename+'\n').encode()
        immutable[filename]=pin(raw)
    temporary=[]
    for parent in (thin,audits,project/'work/candidate'):
        temporary.extend(str(p) for p in parent.glob('.source44-*.tmp'))
    assert not temporary
    item={'case':case['case'],'project':str(project),'recorded_guard_calls':case['recorded_guard_calls'],
          'immutable_synthetic50_51_actual_match':immutable,'adjacent_temp':[],
          'receipt_exists':receipt_path.exists(),'failure_exists':failure_path.exists(),
          'control_pin':pin(read(project/'CONTROL-1.json'))}
    if label=='normal':
        receipt=load(receipt_path,case['receipt_pin']);assert len(receipt['files'])==2
        for row in receipt['files']:
            raw=read(row['path'],row['pin'])
            expected=NEW_HELPER if Path(row['path']).name=='next_open_source52.py' else NEW_LAUNCHER
            assert raw==expected
            nine.append({'role':'normal_final','path':row['path'],'pin':pin(raw)})
            if row['backup']:
                backup=read(row['backup'],row['parent']);assert backup==OLD
                nine.append({'role':'normal_original_launcher_backup','path':row['backup'],'pin':pin(backup)})
        assert sum(row['backup'] is not None for row in receipt['files'])==1 and not failure_path.exists()
        for filename in immutable:
            nine.append({'role':'normal_synthetic_immutable','path':str(thin/filename),'pin':immutable[filename]})
        assert receipt['source50_helper_pin']==immutable['next_open_source.py'] and receipt['source51_helper_pin']==immutable['next_open_source51.py']
        item['actual_final_files']=2;item['actual_original_parent_backup_files']=1
    elif label in ('initial-live','initial-unknown','junction'):
        assert not helper.exists() and read(launcher)==OLD and not receipt_path.exists()
        if label!='junction':assert list((project/'backups').iterdir())==[]
        else:
            base=Path(case['reparse_path']);destination=Path(case['destination']).resolve(strict=True)
            assert destination.is_relative_to(project) and base.absolute().is_relative_to(project)
            status=base.lstat();assert getattr(status,'st_file_attributes',0)&stat.FILE_ATTRIBUTE_REPARSE_POINT
            assert list(destination.iterdir())==[]
            item['junction_reparse_preserved']=True;item['junction_destination_empty']=True
            item['junction_readlink']=os.readlink(base)
    else:
        assert not receipt_path.exists() and failure_path.exists()
        if label in ('seal-drift','rollback-foreign'):
            assert read(helper)==FOREIGN and read(launcher)==OLD
            nine.append({'role':label+'_foreign_helper','path':str(helper),'pin':pin(read(helper))})
            item['foreign_new_helper_preserved']=True
            if label=='rollback-foreign':assert case['target_unlink_calls']==0
        else:
            assert label=='rollback-live' and read(helper)==NEW_HELPER and read(launcher)==OLD
            failure=load(failure_path,case['failure_pin']);assert failure['rollback'][0]['held'] is True
            nine.append({'role':'rollback_live_candidate_helper_retained','path':str(helper),'pin':pin(read(helper))})
            nine.append({'role':'rollback_live_failure_retained','path':str(failure_path),'pin':pin(read(failure_path))})
            first=load(project/'CONTROL-1.json');second=load(project/'CONTROL-2.json')
            assert second['error_type']=='ValueError' and second['recorded_guard_calls']==first['recorded_guard_calls']
            item['second_invoke_no_guard_or_file_retry']=True
        item['failure_pin_actual']=pin(read(failure_path))
    physical.append(item)
assert len(nine)==9
firstfails=[load(row['path'],row['pin']) for row in ready['first_failures']]
assert len(firstfails)==2 and all(row['completed_cases']==[] for row in firstfails)
out={
    'schema':'source52_two_thin_install_independent_actual_readback_v1','pass':True,
    'READY_pin':pin(read(BASE/'INSTALL-STORY-READY.json')),'RESULT_pin':ready['result']['pin'],
    'all_frozen_refs_actual_match':True,'Root_installer_exact_snapshot_and_false':True,
    'installer_control_functions_original_AST_sha256':hashlib.sha256(ast.dump(ast.Module(body=control_nodes,type_ignores=[]),include_attributes=False).encode()).hexdigest().upper(),
    'installer_control_functions':['proof','absent','main'],
    'actual_Source44_five_original_AST_sha256':hashlib.sha256(ast.dump(ast.Module(body=helper_nodes,type_ignores=[]),include_attributes=False).encode()).hexdigest().upper(),
    'guard_exact_previously_reviewed_1E97':True,
    'physical_cases':physical,'nine_critical_actual_artifacts':nine,
    'two_first_carrier_failures_preserved_empty_completed_cases':True,
    'authority_pins_old_payloads_process_transport':'recorded fixture only; not production proof',
    'real_CIM_process_guard_business_installer_App_calls':0,'Root_formal_data_mutations_or_reads':0,
    'actual_file_pins_read':reads,'finalGraph_install_authorization':False,
}
path=OWN/'INSTALL-STORY-INDEPENDENT-READBACK.json';path.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'output_path':str(path),'pass':True,'physical_cases':[{k:r[k] for k in ('case','receipt_exists','failure_exists','adjacent_temp')} for r in physical],
                  'nine_actual_artifacts':9,'Root_authorization':False,'runtime_calls':0},ensure_ascii=False))
