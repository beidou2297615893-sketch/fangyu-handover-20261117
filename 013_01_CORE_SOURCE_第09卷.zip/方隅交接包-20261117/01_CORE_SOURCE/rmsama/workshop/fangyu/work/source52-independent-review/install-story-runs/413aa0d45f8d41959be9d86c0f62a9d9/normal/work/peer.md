own recorded final review input, no Root authority
