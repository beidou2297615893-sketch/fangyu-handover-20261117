# Source52 首原生装载草稿非作者代码审

结论：首草稿发现 1 个必须修复的累计备份前置门遗漏；暂 CHANGES_REQUIRED，不能给最终安装或 literal绑定PASS。Root并行改稿期间已出现新native字节，本报告只保首审发现及已完成的固定图核对，新稿须由Root明确派exact delta后再判。

固定业务图 PREPARED169430 / `BF80D4F7E920C2F15D2FEBB4190C7516E9728595D04CD111CD30FD034CBB7B60` 核对吻合。NATIVE-DRAFT首声明CAS28636/60CB1584…、helper14749/03B00F70…、guard5136/F33EAD34…；launcher4897/07545078…，LATEST_PIN=None。首helper/CAS JOIN_AUTHORIZED=False；helper MANIFEST_PIN=None保持准备态。已完整读helper/CAS/launcher首代码和必要50/51接口，只读guard调用契约；guard WQL细审由platforms负责，本审不重复研究或调用CIM。

## 必须修复：累计原备份核验晚于 Source52 写入

首 `next_open_source52.py` L80–125 的 `_layer` 能正确绑定各层固定authority/gate/prepared/receipt，验证原backup必须位于 `backups/source{batch}-owner/<32hex>/`，每目标定址为root/target.relative_to(WORK)，核原parent bytes，并检查原raw回执链。L131–148 的累计 `_readback` 能从51 backup验证50旧pin、从52 backup验证51旧pin及仅52覆盖50项，拒替代batch或仅现目标hash冒旧父。

但是该完整门首次调用在 L216，即Source52 CAS已经被 L215 执行后。52 STARTED前 L211 仅调用已审原51 `_readback`，原51 L154–184只核receipt fields、当前final/protected，不检查backup地址或原backup字节。首CAS `source51_predecessor` L165–234同样不检查50/51原backup；其主路径 L290/L308之后就可以创建52备份/temp并replace9件。

因此可由代码精确推出：已有51合法原receipt/raw lineage和current pins，但51原备份被删除、损坏或receipt backup指错batch时，旧51读回和52 CAS的前置检查仍过，52先改9件，末尾累计读回才held。此处是恢复材料和累计lineage未在写前闭合，不是让本审读真实backup或运行原App。

最小修复：只改新52 helper/CAS，复用新 `_layer` 的50/51定址/原parent核验构建predecessor-only累计读回，在同原byte锁内52 STARTED前检查；CAS在任何52备份、temp或replace之前也核对应累计备份链。保持原50/51脚本不变，原receipt raw绑定、固定父、STARTED/FAILED不retry和未知source_mutations语义不变。已向Root报告；本审没有实施修复。

必要新代表建议：仅自有公开源码/原backup夹具，已录制50→51成功，再分别损坏51原parent backup或将backup地址串到其他batch；52 STARTED/业务源码/temp/备份应0写且held。保一条正常累计链和一个invoke后失败的unknown结果即可，不重业务QA。由Root按其新native状态故事范围选择执行，本审未执行。

## 其他已核必要接线

- helper `_plan` 固定52路径、9白名单、parent/final、prepared与manifest protected完全一致，并经过原50/51固定authority门；没有任意HTTP/env/路径入参。首 `_readback` 的未来52累计原父恢复逻辑正确，缺口是写前未调用。
- before_normal_open原preflight及instance核对后进入原50 `_exclusive_existing_lock`，同一个existing文件同byte范围持锁下低层50→51→52，不调用会exec的51 before_normal_open；52成功后才普通 `-X utf8 -B -I` fresh exec ENTRY。已有receipt52需累计读回，不apply；未知STARTED/FAILEDheld；任何invoke发生后catch回source_mutations=None保守未知。
- 新52 CAS复用已审Source44五助手，expected校核bytes、普通文件/no-link-parent、完整同目录temp与fsync；9原父/候选literal固定，target不含数据/入口，备份CAS/foreign drift拒rollback。caller同pid STARTED和原existing byte锁检查保持。guard由pin校核raw compile执行，52 STARTED前、CAS备份/temp前、每replace前、success/ownrollback前fresh要求idle；live/unknownheld，不kill/F5/自动新用途。
- launcher `_load` 校核固定普通字节后直接compile(raw)，没有重新从path执行未绑定脚本。只允[]或[--check-only]；check-only仅metadata选择entry与preflight，未调用source_guard、锁、CAS、STARTED或business import。首LATEST_PIN=None直接held，不借缺pin继续旧入口。最终helper/manifest pin和安装尚未绑定，本报告不将准备态当已可启动。

## 固定图与HOST/revision交集

独立只从公开元数据算闭包：Source51 protected459 + targets11 = future470；Source52只覆盖其中8件，故保护462正相等，9target/protected互斥无重复；17direct公开依赖已在future图且pin一致。唯一新覆盖公开父是local-transport，固定parent 00F1B97B…，不是新文件或旧层backup。9候选parent/final与已审r2 exact9均一致。

Source51 future ENTRY的8项HOST_PINS与新9 target交集为空，全部在不变保护中且预期SHA相同。Dy_read、Dy_storage、Wx_preview、Wx_preview_storage的实际 `_SOURCES/_SOURCE_FILES/_MATERIALS` 元数据tuple与新9交集均为空，所有声明成员仍在不变保护图；不需因为52重新生成平台用途revision，更不表示用途获批。未物理hash462、44依赖、781/508快照或二进制。详见本目录 `NATIVE-METADATA-READBACK.json`。

## pin漂移与严格边界

本审途中先只读见CAS28636/09EA3A42…、helper14749/FC6408E3…、guard5536/6D3F7F33…，后来元数据pin单观测到CAS30086/2DC8FCC3…、helper15374/CBD8C9A5…、guard5688/A8B4475C…；launcher仍4897/07545078…。它们与首NATIVE-DRAFT声明不符是并行新草稿，不冒首pin冻结或新稿已审；只保本发现，后续必须固定exact delta。

Root已明确接受此P1并报告两处候选修复：helper15374/CBD8C9A5…、CAS30340/55B81D09…以及guard5688/A8B4475C…将保持稳定，待首审报告保存后另派P1/guard literal delta。该报告消息不是本审的新代码读回或关闭结论，本首审仍保 CHANGES_REQUIRED 历史。

真实进程查询、App/GUI/CIM/SDK/平台/模型、DB/Cookie/Vault和原backup读取、业务QA、正式/作者/中央/50/51写入均为0。仅自己的独立报告与元数据读回单写入。本审没有实际原OS锁、52CAS、状态故事、final literal、生产部署或安装证据；等待Root最终delta与新native代表。
