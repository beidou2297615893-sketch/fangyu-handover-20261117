# Source52 店长人员管理：实现前窄边界审

结论：固定店域operator grant方案在本范围未见新的越权语义缺口；**发现一个必须补进实现的P1员工gateway接缝**，Root已接受第8件最小目标 employee_workspace.py。这是提案/原接缝审，尚未读作者实现或给冻结CODE PASS，0QA执行/正式或中心文档修改。

输入为提案7648/972FC0F0…、PARENTS5020/622C7094…、唯一gap1130/70D47A87…，完整实际pins见BOUNDARY-REVIEW.json。gap只证明HQ提交未知flag得到200但未授能力、同operator正常members403；不证明生产云泄露或权限已授。

## [P1] 员工成员保存未知结果被降为明确400

实际源码链：`integrations.py:21` IntegrationError继承ValueError；request_json在HTTP异常附http_status，网络/超时/无效结果没有确定status（:149-156）；`Integrations._cloud:434-451`重新抛该异常。`assistant/employee_workspace.py:315-321`直接返回_cloud、gateway `:438`直接public(_cloud)，没有成员错误转换。`app.py:988-992` desktop_workspace只捕WorkspaceError，通用 `:1365`将ValueError回400。`member-admin-ui.mjs:81`把400视为确定拒绝，needsRead=false。新员工店长UI可达后，member_save远端真实提交但响应丢失会变400，UI解除hold、允许再次提交密码。

最小修复仅gateway的members/member_save：将IntegrationError中已知安全http_status 400/401/403/409/422/429转固定安全WorkspaceError相应状态、mutation_committed=False；其余网络、5xx、未知/身份响应失配保503+None，保原无自动重试。其他operations、白名单、endpoint/凭据来源、App通用catch不改。Root已要求作者新增正常原生HTTP lost-after-commit→503→UIhold且0再次member_save的单因果RED/GREEN；本审没有自行运行。

401复用的确切前端接缝是local-transport.mjs:43-48：清cloud.user/token、epoch++、onSessionExpired→app.resetWorkspaceSession。不能声称Integrations._cloud已自动删除DPAPI/Cookie会话：它重新抛异常，Handler.user/verify_identity可能沿原30秒身份cache。成员实际授权必须仍由每次云事务fresh范围控制；restore/me缓存profile不重新授cap。若新正常代表显示需清identity cache或其它动作，作者先给具体最小原因，不预扩App/Integrations目标或复制新grant到本机身份。

## 实现和冻结审必须保的具体约束

1. **能力学习不能卡在旧admin门或设备条件。** 现module `authorized()/load()`在请求前就拒operator，app.enterWorkspace没有members probe。新已登录operator须沿既有gateway显式读取fresh members能力；普通403只表示无人员入口，cap未知默认隐藏。成功store能力应独立于设备/平台配对，不从Core本机user、role标签、交接manager名单或30秒me cache推出。employee public是递归secret黑名单，members/member_save已允许，无新增白名单或grant复制需求。
2. **导航父节点和多入口一致。** app.mjs:129不仅hide team-tab，还固定admin-nav.hidden=true并统一hide admin-menu-item；:163将local team改tasks。只解除team-tab不够。需单独teamAllowed使父容器/菜单/route可达，review/maintenance和originPartnerAdmin保原HQ/cloud门禁；不能复用adminAllowed=true来打开店长全部管理功能。index现团队表单可复用；workspace nav与account-menu两个team入口都要走实际refreshTeam，新cap读取失败撤导航、名单/编辑权限。
3. **旧云可忽略新flag，必须有双门和真回执。** native Owner.call:128-136原仅核member_save_modes，这不能证明支持grant。新HQ grant保存须fresh核确切member_management版本/company scope/actor和支持字段；手写native POST也不能绕过。UI新grant字段未支持时禁用，不能因200或原create/update模式就称授权成功。成功回执的公开布尔须核期望，内部fixed-store grant/授权店不入公开DTO；新保存scope stamp字段亦须列入native精确白名单并服务端拒stale，绝不作为客户端授权。
4. **fixed grant和目标事实都在同原事务fresh核。** actor必须active operator、有效store且内部grant店等当前店；只有HQ显式布尔可授/撤，旧无grant不猜。store manager只能本店普通operator；自己/有效peer manager/admin/partner/越店/转店/role/grant/can_reply提升均拒，create/update显式且同名/消失409不改密码。目标在请求等待中被HQ转店/授manager时必须拒。HQ改密码重建createUser不能漏既有grant；HQ转店/停用/改角色清grant，异店只能再次HQ明授。原shared source店不迁。
5. **fresh UI与unknown hold按原人员范围绑定。** cap必须绑定actor对象/username、公司/环境、cloud.epoch、服务端scope/store stamp；不能只沿原UIstamp（其没有store/grant）。已获列表后cap失效/403/401、scope变更或乱序晚回须清列表、编辑、可写权与敏感输入；同一账号新session不能沿旧editor。当前needsRead全局布尔/任意成功load会清，需要保证未知密码请求只由原当前有效人员范围的主动读解除；cancel/reset、其它账户/门店读取、已丢失grant或旧格式名单不能解除。读名单只是解除继续操作条件，不能声称上次密码已核实，也不自动重发。
6. **原额度/维护边界不扩大。** 新grant requireFeature(team)，撤销及减量保成熟过期/降级维护；不能在所有members/disable路径一概加team到期拒绝。普通新员工can_reply默认false；已有值仅按服务端事实匹配，不借原表单默认checked提升。原validateMemberChange的全公司启用席位、门店计数负责新增/恢复；不新造角色/SDK/策略库、设备/回复/平台权限。

方案目标原7件，加已接受的极窄employee_workspace第8件；service父仍是Source51已冻C4D44315，不是正式旧0DB1。需等Root真实51成功及后继保护图，不能提前合正式。后续冻结CODE审只审新8件和这条正常HTTP/模块因果代表，不重Source51共享/平台/长矩阵。

未验：作者实现、实际public能力DTO形状与stamp、正常native/employee lost响应故事、实体门店审批、真实SDK/部署/GUI、完整店长/总部/部门经营体系。0真实DB/Cookie/账号/平台/当前App动作。
