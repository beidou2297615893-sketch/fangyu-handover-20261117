from pathlib import Path
import ast,hashlib,json,sys
sys.stdout.reconfigure(encoding='utf-8')
WORK=Path('C:/积木软件工坊/项目/方隅公寓客户版/work');BASE=WORK/'source52-root-integration';OWN=WORK/'source52-independent-review'
def pin(raw):return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest().upper()}
def pinned(p):return {'path':str(p),'pin':pin(Path(p).read_bytes())}
specs=[(BASE/'install_native.py',{'bytes':8555,'sha256':'E365AFAD4AD3E1E7C45A5882652983AC6A88A6ED3243E8BDBE43A1B9ACB74378'}),
 (BASE/'install-revision1/install_native.py',{'bytes':8293,'sha256':'B3C0FD2095237BCE1636611E16A746B62333623AF9995EF57F63609264F50E3A'}),
 (BASE/'source_idle_guard.py',{'bytes':5948,'sha256':'1E97220595CCD6954F67FAABFCAE83E52734D4EE59188F0657C9B0363FBA3AA1'}),
 (OWN/'INSTALL-CODE-REVIEW.md',{'bytes':4659,'sha256':'4390B12EC3A8682387206F2BB177FCBA3177D487AD0E1E0389FC00299908AE43'})]
rows=[]
for p,e in specs:
    a=pin(p.read_bytes());rows.append({'path':str(p),'expected':e,'actual':a,'match':e==a});assert e==a
raw=(BASE/'install_native.py').read_bytes();constants={t.id:ast.literal_eval(x.value) for x in ast.parse(raw).body if isinstance(x,ast.Assign) for t in x.targets if isinstance(t,ast.Name) and t.id in ('INSTALL_AUTHORIZED','PEER_PIN','GRAPH_PIN','HELPER_PIN','LAUNCHER_PIN','GUARD_PIN')}
assert constants['INSTALL_AUTHORIZED'] is False and all(constants[x] is None for x in ('PEER_PIN','GRAPH_PIN','HELPER_PIN','LAUNCHER_PIN'))
assert constants['GUARD_PIN']==specs[2][1]
pr={'schema':'source52_installer_three_gate_delta_pin_readback_v1','checks':rows,'constants':constants,'all_match':True,'candidate_runtime_executions':0,'actual_query_or_state_calls':0}
(OWN/'INSTALL-DELTA-PIN.json').write_text(json.dumps(pr,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
report={'schema':'source52_installer_three_gate_delta_code_review_v1','status':'SCOPED_CODE_DELTA_PASS_THREE_FINDINGS_CLOSED',
 'reviewer':'overnight_selfuse_non_author','fixed_inputs':rows,'pin_readback':pinned(OWN/'INSTALL-DELTA-PIN.json'),
 'closed_findings':[{'id':'S52-INSTALL-P1-FOREIGN-UNLINK','priority':1,'new_lines':[119,121],'closed_at_code_level':True,'reason':'fresh no_link_parent/expected(final) after absent immediately before new helper unlink'},
 {'id':'S52-INSTALL-P2-FINAL-SEAL','priority':2,'new_lines':[100,103],'closed_at_code_level':True,'reason':'both actual ordinary target finals rechecked after final absent before receipt preparation'},
 {'id':'S52-INSTALL-P1-BACKUP-ROOT','priority':1,'new_lines':[76,79],'closed_at_code_level':True,'reason':'backup_base split mkdir then no_link_parent(backup) includes base before uuid child creation and any backup writes'}],
 'new_findings':[],'change_scope':'Only three gate changes plus guard literal; target/fixed parent/old helper immutable scope unchanged.',
 'preparation_constants':constants,'guard_scope':'Literal equality and fixed wrapper4/Python scope only; actual WQL compatibility and historical RED handled independently by platforms.',
 'limitations':['No finalGraph/literal authority binding or actual two-thin installation.',
   'No new installer three-gate state representative; business52 CAS story is not that evidence.',
   'No candidate import/invoke/query/CIM/SDK/App/platform/GUI or original backup/source/data reads.',
   'No repeated unrelated native/helper/CAS/r2/462/guard official review.'],
 'bounds':{'formal_author_Root_central_Source50_Source51_mutations':0,'candidate_runtime_QA_state_installer_queries':0,'real_backup_business_source_DB_cookie_Vault_reads':0,'actual_installations':0},
 'narrative':pinned(OWN/'INSTALL-DELTA-REVIEW.md')}
(OWN/'INSTALL-DELTA-REVIEW.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'report':pinned(OWN/'INSTALL-DELTA-REVIEW.json'),'narrative':report['narrative'],'pins':report['pin_readback'],'status':report['status']},ensure_ascii=False,indent=2))
