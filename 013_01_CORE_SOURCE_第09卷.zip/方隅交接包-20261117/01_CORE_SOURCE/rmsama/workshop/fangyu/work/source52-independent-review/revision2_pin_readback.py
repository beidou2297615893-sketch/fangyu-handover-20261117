from pathlib import Path
import hashlib,json,sys
sys.stdout.reconfigure(encoding='utf-8')
BASE=Path('C:/积木软件工坊/项目/方隅公寓客户版/work/source52-store-manager')
R2=BASE/'revision2';OWN=BASE.parent/'source52-independent-review'
def pin(raw):return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest().upper()}
rows=[]
def check(path,expected,kind):
    actual=pin(Path(path).read_bytes());rows.append({'kind':kind,'path':str(path),'expected':expected,'actual':actual,'match':expected==actual})
check(R2/'FROZEN.json',{'bytes':20693,'sha256':'737719494423FEB5F5F928735264629188C7A94F24C19B7C680811480DB94517'},'revision2_fixed_freeze')
j=json.loads((R2/'FROZEN.json').read_bytes());f=j['first_candidate_freeze'];check(f['path'],f['pin'],'first_freeze_retained')
first=json.loads(Path(f['path']).read_bytes());original={t['target']:t for t in first['targets']};deltas={t['target'] for t in j['delta_targets']}
graph=[]
for t in j['targets']:
    old=original[t['target']]
    parent_equal=all(t[k]==old[k] for k in ('target','parent','parent_source','parent_kind','original_parent_source'))
    check(t['candidate'],t['candidate_pin'],'revision2_candidate')
    check(t['parent_source'],t['parent'],'inherited_join_parent')
    check(old['candidate'],old['candidate_pin'],'first_candidate_retained')
    same_bytes=Path(t['candidate']).read_bytes()==Path(old['candidate']).read_bytes()
    graph.append({'target':t['target'],'join_parent_exactly_inherited':parent_equal,'delta':t['target'] in deltas,
                  'unchanged_first_candidate_exact_bytes':same_bytes,'consistent':parent_equal and (not same_bytes if t['target'] in deltas else same_bytes)})
for d in j['delta_targets']:
    check(d['delta_parent']['path'],d['delta_parent']['pin'],'delta_parent_first_candidate')
    check(d['final']['path'],d['final']['pin'],'delta_final')
for d in j['documents']:check(d['path'],d['pin'],'revision2_doc_or_carrier')
for k in ('inherited_public_dependency_index','inherited_final_main','inherited_final_DOM'):
    d=j[k];check(d['path'],d['pin'],'inherited_pointer_only_no_QA_rerun')
source_checks=[]
segments=[('function stopDevelopmentIdentityWatch(){','async function checkDevelopmentIdentity('),
          ('async function checkDevelopmentIdentity(','function startDevelopmentIdentityWatch('),
          ('async function refreshTeam(','function syncMemberEntry('),
          ('function syncMemberEntry(','async function probeMemberEntry('),
          ('async function probeMemberEntry(','async function refreshMaintenance(')]
for e in j['new_seam_evidence']:
    check(e['path'],e['pin'],'new_seam_result')
    snapshots={Path(s['path']).name:s for s in e['snapshot_files']}
    for s in e['snapshot_files']:check(s['path'],s['pin'],'new_seam_raw_snapshot')
    result=json.loads(Path(e['path']).read_bytes())
    result_pins_match=all(result[k]==snapshots[n]['pin'] for k,n in [('app_pin','app-snapshot.mjs'),('module_pin','module-snapshot.mjs'),('transport_pin','transport-snapshot.mjs'),('carrier_pin','carrier-snapshot.mjs')])
    app=Path(snapshots['app-snapshot.mjs']['path']).read_bytes().decode('utf-8')
    parts=[]
    for start,end in segments:
        a=app.index(start);b=app.index(end,a+len(start));parts.append(app[a:b].strip())
    actual=pin('\n'.join(parts).encode('utf-8'))
    source_checks.append({'result':e['path'],'result_4raw_pins_match':result_pins_match,'source_function_expected':result['source_function_pin'],
                          'source_function_actual':actual,'source_function_match':actual==result['source_function_pin']})
check(OWN/'CODE-REVIEW.md',{'bytes':8089,'sha256':'2CF932B4E6FED3A1AEE8B4BC5430833F66510D8B95B61B5AFA77D77899F2CE08'},'first_independent_changes_required_retained')
out={'schema':'source52_revision2_independent_pin_readback_v1','pin_checks':rows,'graph_checks':graph,'new_seam_source_checks':source_checks,
 'all_selected_match':all(x['match'] for x in rows) and all(x['consistent'] for x in graph) and all(x['result_4raw_pins_match'] and x['source_function_match'] for x in source_checks),
 'candidate_runtime_QA_executions':0,'formal_mutations':0,'full_508_snapshot_hash':False}
(OWN/'REVISION2-PIN-READBACK.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'all_selected_match':out['all_selected_match'],'pin_check_count':len(rows),'graph_check_count':len(graph),'raw_function_check_count':len(source_checks),'mismatches':[x for x in rows if not x['match']],'bad_graph':[x for x in graph if not x['consistent']],'source_checks':source_checks},ensure_ascii=False,indent=2))
