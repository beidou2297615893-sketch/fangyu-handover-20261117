# Source52 两薄文件 installer 首代码审

结论：固定首草稿8293/B3C0FD20…有3处 must-fix，CHANGES_REQUIRED。False/None准备门能阻实际安装；待这些定点修复和最终pin绑定后另审必要增量。未执行installer、guard或状态故事，未查询进程或读原backup/source/data。

本审先实际读取完整 `source52-root-integration/install_native.py` 并在同次工具调用中核对精确输入：8293 / `B3C0FD2095237BCE1636611E16A746B62333623AF9995EF57F63609264F50E3A`。没有导入候选。Source44五AST助手沿既有独审接口复用，未重复helper/CAS/r2/462/guard官方审。

## P1：新helper回滚删除前未fresh核own bytes

首L112先读target、L114判current==after，再L115调用absent（可等待守卫运输）；新helper分支L116之后直接unlink。若在该守卫等待中target已被foreign替换或改写，旧current仍匹配，删除会落到foreign文件上。旧launcher恢复L119已有紧邻expected(final)，新helper分支遗漏了相同门。

最小修：absent通过后、紧邻unlink前，再复用ordinary/no_link_parent与expected(target,row.final)校核。foreign漂移或reparse/hardlink变化应留原文件并记held，不能以早先current==after冒当前仍是自己的写入。此结论为首代码因果推导，未制造/读取真实target。

## P2：成功回执前缺两target最终读回

首L96逐件读回final，但helper之后还要经历第二件的absent，以及L98最终absent。L97–105成功封口仅核旧50/51 immutable，未在最后守卫后重核new helper和launcher final。第一件若在后续等待中漂移，仍会发“两files installed”回执；下一开虽会按helper pin拒绝，安装回执已经不准确。

最小修：最终absent通过后、制备receipt前，重新expected两固定target final并保ordinary门；不能用旧50/51 immutable或graph pin代替两件actual读回。仍保失败/foreign恢复规则，无新业务apply。

## P1：备份根本层可能重定向

首L76–77调用 `no_link_parent(backup.parent)`。Source44该函数只逐层核参数path的parent，不核path自身，因此此处检查到backups祖先，漏掉 `backups/source52-native` 本层。若这层已为junction/symlink，随后 `backup.mkdir(parents=True)` 和saved.write_bytes会穿过该重定向，扩展备份写入scope。

最小沿成熟CAS接缝：先普通祖先核backup_base并mkdir(exist_ok=True)，再 `no_link_parent(backup)`（包含backup_base本层），最后固定uuid子目录mkdir；必须在该子目录和任何备份写前拒reparse根。不要另造路径规则或删已有目录。

三个finding已向Root逐条发送。本首审保存3处完整结论，不将Root后续并行修改字节自动当通过。

## 其余必要范围

L53在任何absent/备份/target写前要求INSTALL_AUTHORIZED=True及PEER/GRAPH/HELPER/LAUNCHER四固定有效pin；当前False+四None，fail-closed。固定peer和FINAL-GRAPH身份/hash、gate/manifest/CAS pin均需expected，准备文件不自授权。items只NEW_HELPER与LAUNCHER两个常量：新helper原必须不存在，launcher父4626/AA029206…；候选路径固定，50/51两个原helper只expected immutable，不是targets。无任意HTTP/env/路径输入或业务CAS调用。

absent复用已核raw guard运输，明确SOURCE_PATHS仅四thin路径、ALIASES为这四Python名、RUNTIMES只Python系。它是opening wrapper占用检查：返回窄scope/state metadata并要求idle，live/unknown拒；原business App可保持live，因为两thin安装不修改business来源。不能把它的idle冒所有业务源码idle。此处只审固定覆盖和调用，实际Windows/WQL兼容由platforms的自有PID代表另审。

首backup→同目录prepared_temp→每replace前父/new absent、占用门及immutable→replace/rename→expected(final)路径保持。成功receipt是独立source52-native-installed，明确三业务apply_calls=0、App/marker/platform/data/session/shortcut均未动；失败以exclusive-create保FAILED，已有receipt/FAILED拒新尝试，不自动retry。自己的guard若live/unknown，rollback拒恢复并记held；foreign bytes拒恢复。以上受3个finding补门限制，不构成实际读回或安装PASS。

必要后续代表只新2thin scope：占用/unknown门、备份reparse根拒、final seal target漂移拒、guard等待后foreign新helper不删除，以及一次正常备份CAS/immutable读回。代表和正式安装均未由本审执行。最终4pins/graph/authority当前未绑定，新native状态仍待；旧业务/50/51源图、真实账号/DBCookie/Vault/进程和全机cmdlines均没有访问。
