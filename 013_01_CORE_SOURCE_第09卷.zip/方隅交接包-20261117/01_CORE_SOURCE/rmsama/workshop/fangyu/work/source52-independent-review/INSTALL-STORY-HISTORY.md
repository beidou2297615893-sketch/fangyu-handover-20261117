# Two-thin 状态代表保留记录

最终 run 为 `install-story-runs/ab5c91630a2a4eccbb07c8fcf7828451`，7个必要分支实际通过。Root installer/guard保持8555/E365、5948/1E97不改；每run在控制调用前以CreateNew保存完整installer/guard/Source44/carrier raw。函数由原body AST编译，未改控制语句；authority True/four fixture pins/父和immutable以及PowerShell完成结果为明确录制。

两次首夹具失败均保留，不覆盖、删除或倒填：

- `413aa0d45f8d41959be9d86c0f62a9d9/FIRST-FAIL.json`981/54C78232…，carrier12549/AFC696C2…。首normal停在录制运输的路径substring断言，guard保守unknown，未进入installer备份/目标CAS。首carrier错误拿未经过LIKE方括号、WQL及JSON字符串层的Windows路径作匹配。首FIRST-FAIL只保存外层assert，不含guard内部异常串；此定位来自保留carrier代码，不能把这文件冒产品RED。该首夹具也未预建成熟工程已存在的backups父，修夹具时补齐，但首运行未走到该前提，不称它是已执行到的第二失败。
- `59e9fc73c9794861a31b85a0f67d39f9/FIRST-FAIL.json`981/3FFC4888…，carrier12860/5D55E6EF…。加入CONTROL-1.json确认normal为live-or-unknown保护、recorded_guard_calls为空；只匹配双backslash的断言仍未适配WQL与JSON双层转义。最终夹具使用编码脚本中固定own PROJECT的正斜杠路径校验，保真实guard字节不改。

最终carrier12940/46ED0395…还修正夹具日志每次invoke独立编号，避免FAILED保史拒再次调用时guard计数不增导致CONTROL同名；mklink的实际Popen审核兼容Windows命令行串，与原列表仅允同一个own junction构造，不开放其他进程。

新7分支此前没有任何已过分支被重跑：前两run均normal首步失败，completed_cases为空；修夹具后一次完成全部7。没有修改Root控制代码或旧历史。最终RESULT中first_unexpected_failures=[]只指最终run，不能解读成整体没有两首夹具失败。

实际Windows junction位于最终run的junction/backups/source52-native，目标为同run junction/own-junction-destination。两resolved绝对路径均在自有run内；目录symlink权限不足后仅创建这一own junction，产物保留，0recursive delete/move。installer本层门拒，目的地无UUID子目录或backup写入。该mklink是自有夹具结构创建，不是PowerShell/CIM或原账户进程查询。

所有权限与进程metadata为录制；实际文件操作限自有fixture PROJECT/WORK/AUDITS/OWN/targets/backup。audit只允许该run写/rename/remove和这一个junction命令，禁止网络、DB和其他实际Popen。该逻辑fence不是OS安全沙箱。未安装正式薄入口，未运行业务52CAS/原App/GUI/SDK/平台，不能以此说明客户原机idle或完整商业验收。
