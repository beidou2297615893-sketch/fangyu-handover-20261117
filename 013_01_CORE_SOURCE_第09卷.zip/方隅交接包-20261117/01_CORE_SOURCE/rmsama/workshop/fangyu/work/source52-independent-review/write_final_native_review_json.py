from pathlib import Path
import hashlib,json,sys
sys.stdout.reconfigure(encoding='utf-8')
WORK=Path('C:/积木软件工坊/项目/方隅公寓客户版/work');BASE=WORK/'source52-root-integration';OWN=WORK/'source52-independent-review'
def pinned(p):
    raw=Path(p).read_bytes();return {'path':str(p),'pin':{'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest().upper()}}
rb=json.loads((OWN/'FINAL-NATIVE-PIN-READBACK.json').read_bytes());assert rb['all_checks_match'] and len(rb['checks'])==22
graph=json.loads((BASE/'FINAL-GRAPH.json').read_bytes())
report={'schema':'source52_final_native_stage_independent_review_v1','reviewer':'overnight_selfuse_non_author',
 'status':'SCOPED_FINAL_STAGE_LITERAL_GRAPH_PASS_NO_MUSTFIX',
 'eligible_next_step':'Root exact peer pin binding for final installer, followed by its required two-thin occupancy/CAS and independent actual readback; not a completed installation.',
 'graph':pinned(BASE/'FINAL-GRAPH.json'),'readback':pinned(OWN/'FINAL-NATIVE-PIN-READBACK.json'),'new_findings':[],
 'actual_fixed_pin_count':22,'full_module_AST_checks':rb['module_AST_literal_checks'],
 'reviewed_body_inheritance_guard_literal_bridges':rb['prior_reviewed_code_to_current_guard_literal_byte_bridges'],
 'closed_graph':{'schema_instance_base':True,'gate_prepared_CAS_guard':True,'manifest_gate_CAS_targets_protected':True,
   'helper_actual_manifest_pin':True,'launcher_actual_helper_pin':True,'exact_nine_parent_final_map':True,'exact_protected462':True,
   'exact_six_gate_graph_evidence_pins':True,'hash_cycle_absent':True,'dependency_direction':rb['dependency_order']},
 'accepted_evidence_pointers':graph['evidence'],'final_constants':rb['final_constants'],
 'unbound_installer':rb['unbound_installer_constants'],'not_published_or_installed_path_metadata':rb['not_published_or_installed_path_metadata'],
 'inheritance_scope':['Only BF80 prepared/manifest metadata equality, no nine business candidate or462 physical source hash.',
   'Only accepted report pins and necessary verdict limits, no old QA/story/WMI rerun.',
   'Immutable old50/51 thin bytes and original launcher parent actually checked.',
   'Native and installer actual stories remain own fixtures/recorded authority, guard transport and fresh App edges as documented; actual guard samples are only owned PID cases.'],
 'limitations':['Current real customer source idle not checked or inferred.','Stage authority True is unpublished and existing installer remains False/fourNone.',
   'No final installer invocation or thin installation, no business Source50/51/52 apply, GUI/account/platform/SDK/cloud/complete commercial acceptance.',
   'Final installer literal binding and post-install exact readback remain Root controlled subsequent steps.'],
 'bounds':{'candidate_import_or_execution':0,'actual_process_source_state_or_CIM_query':0,'QA_or_Windows_story_reruns':0,
   'real_DB_cookie_Vault_or_original_backup_reads':0,'formal_Root_central_author_Source50_Source51_mutations':0,'publish_install_business_apply_calls':0},
 'narrative':pinned(OWN/'FINAL-NATIVE-REVIEW.md')}
with (OWN/'FINAL-NATIVE-REVIEW.json').open('x',encoding='utf-8') as f:f.write(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'review':pinned(OWN/'FINAL-NATIVE-REVIEW.json'),'narrative':report['narrative'],'readback':report['readback'],'status':report['status']},ensure_ascii=False,indent=2))
