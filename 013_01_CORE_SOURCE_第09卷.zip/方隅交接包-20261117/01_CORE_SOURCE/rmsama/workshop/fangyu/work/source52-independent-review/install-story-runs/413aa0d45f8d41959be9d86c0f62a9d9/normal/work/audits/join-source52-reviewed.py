own recorded join-source52-reviewed.py metadata; never invoked
