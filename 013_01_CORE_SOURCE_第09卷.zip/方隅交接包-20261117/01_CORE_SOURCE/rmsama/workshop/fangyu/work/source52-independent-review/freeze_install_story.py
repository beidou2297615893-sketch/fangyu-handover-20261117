from pathlib import Path
import hashlib,json,sys
sys.stdout.reconfigure(encoding='utf-8')
OWN=Path(__file__).resolve().parent;BASE=OWN/'install-story-runs';RUN=BASE/'ab5c91630a2a4eccbb07c8fcf7828451'
def pinned(p):
    raw=Path(p).read_bytes();return {'path':str(p),'pin':{'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest().upper()}}
result=json.loads((RUN/'RESULT.json').read_bytes());assert result['status']=='PASS' and len(result['cases'])==7
checks=[]
for run,filename in [(RUN,'RESULT.json'),(BASE/'413aa0d45f8d41959be9d86c0f62a9d9','FIRST-FAIL.json'),(BASE/'59e9fc73c9794861a31b85a0f67d39f9','FIRST-FAIL.json')]:
    outcome=json.loads((run/filename).read_bytes())
    for name,proof in {**outcome['raw_inputs'],'carrier-snapshot.py':outcome['carrier_pin']}.items():
        actual=pinned(run/name);assert actual['pin']==proof;checks.append(actual)
assert pinned(OWN/'two_thin_install_story.py')['pin']==result['carrier_pin']
bundle={'schema':'source52_independent_two_thin_state_ready_v1','status':'SEVEN_SCOPED_OWN_FIXTURE_CASES_PASS',
 'result':pinned(RUN/'RESULT.json'),'carrier':pinned(OWN/'two_thin_install_story.py'),'raw_snapshot_checks':checks,
 'first_fixture_failures':[pinned(BASE/'x'/'FIRST-FAIL.json') for x in []],
 'first_failures':[pinned(BASE/x/'FIRST-FAIL.json') for x in ['413aa0d45f8d41959be9d86c0f62a9d9','59e9fc73c9794861a31b85a0f67d39f9']],
 'history_note':pinned(OWN/'INSTALL-STORY-HISTORY.md'),'cases':result['cases'],
 'scope':'Exact original installer proof/absent/main AST + real Source44 five helper file operations; recorded authority/proc transport, actual own target CAS/rollback and own Windows junction only.',
 'authority_and_process_edges':'Recorded True/four fixture pins/fixed graph inputs/PARENT/IMMUTABLE and PowerShell completion output; no real CIM query or customer PID read.',
 'normal_actual_bounds':{'finals':2,'old_backup_files':1,'immutable_50_51_match':True,'temporaries_remaining':0},
 'actual_guard_three_gate_representatives':True,'actual_query_of_customer_machine_idle':False,
 'limitations':['No finalGraph/Root authority or actual project native installation.','No real WQL execution here; actual owned Windows guard samples belong to platforms.','No business Source52 CAS or other existing QA rerun.','Two retained first failures are fixture-carrier setup/transport failures, not product RED.'],
 'bounds':result['bounds']}
bundle.pop('first_fixture_failures')
with (OWN/'INSTALL-STORY-READY.json').open('x',encoding='utf-8') as f:f.write(json.dumps(bundle,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'ready':pinned(OWN/'INSTALL-STORY-READY.json'),'history':bundle['history_note'],'result':bundle['result'],'carrier':bundle['carrier'],'first_failures':bundle['first_failures']},ensure_ascii=False,indent=2))
