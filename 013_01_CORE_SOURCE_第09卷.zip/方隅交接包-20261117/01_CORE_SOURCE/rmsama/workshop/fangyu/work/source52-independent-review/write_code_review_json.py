from pathlib import Path
import hashlib,json,sys
sys.stdout.reconfigure(encoding='utf-8')
BASE=Path('C:/积木软件工坊/项目/方隅公寓客户版/work/source52-store-manager')
OWN=BASE.parent/'source52-independent-review'
def pinned(path):
    b=Path(path).read_bytes()
    return {'path':str(path),'pin':{'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest().upper()}}
j=json.loads((BASE/'FROZEN.json').read_text(encoding='utf-8'))
rb=json.loads((OWN/'PIN-READBACK.json').read_text(encoding='utf-8'))
assert rb['all_selected_match'] and len(rb['checks'])==50
report={'schema':'source52_independent_exact9_code_review_v1',
 'reviewer':'overnight_selfuse_non_author','status':'CHANGES_REQUIRED_P2_RECONNECT_PERSONNEL_ENTRY',
 'freeze':pinned(BASE/'FROZEN.json'),'targets':j['targets'],
 'author_claim_is_review_verdict':False,'pin_readback':pinned(OWN/'PIN-READBACK.json'),
 'declared_pin_checks_matching':49,'existing_portal_observed_pin_rows':1,
 'findings':[{'id':'S52-P2-RECONNECT-CAP-ENTRY','priority':2,'must_fix_for_declared_offline_recovery_flow':True,
 'file':j['targets'][3]['candidate'],'lines':{'recovery':[32,51],'only_initial_probe':1312,'hide_and_menu':[129,1163,1337]},
 'trigger':'Current operator initially enters development workspace with development_local_only=true, then current me confirms remote identity and false.',
 'actual_from_exact_code':'Initial member authorization refuses probe, all team routes are hidden. Confirmed reconnect updates actor/devices/tasks but never probes members; the only probe is enterWorkspace. The current manager cannot reach fresh capability without re-entering.',
 'basis':'Static causal trace through exact frozen app, unchanged recovery seam, member module and actual transport; no new runtime execution.',
 'minimal_fix_constraints':['Use existing current-identity recovery or visible read-only capability-check seam.','Capability remains fresh members only; no cached grant or HQ access.','Do not silently release an existing unknown save hold through automatic recovery read.'],
 'necessary_new_representative':'Initial local-only refusal and hidden team -> real current transport false recovery -> normal visible read-only capability route -> current store team visible with HQ hidden; existing unknown save remains held and no resubmit.',
 'root_and_author_notified':True}],
 'reviewed_without_other_must_fix':[
 'Same-transaction authenticated fixed-store grant, ordinary own staff restrictions and three existing roles.',
 'Explicit new grant entitlement, reductions, omitted-grant same-store password preservation and target session revocation.',
 'Public DTO, old-cloud UI/backend gates, native new grant preflight and success bool/scope acknowledgement.',
 'Member UI actor/company/environment/epoch/editor scope/late reads/unknown holds and actual stable actor transport.',
 'Only members/member_save employee error mapping and existing actual AppServer response/401 seams.',
 'Normal online app init/menu/native portal identity wiring, with P2 reconnect exception.'],
 'evidence_read':{'final_main':j['final_main_result'],'final_DOM':j['final_DOM_result'],
   'current_four_carriers':j['carriers_current_bytes_read_at_freeze_not_all_historical_runtime_signatures'],
   'latest_native_bool_ack_subseam':j['latest_native_bool_ack_subseam'],
   'main_event_count':8,'DOM_check_count':11,
   'explicit_transport':'Actual createService/createStore plus synthetic JSON SDK transaction adapter and owned loopback; actual owned AppServer/Owner/Core/SQLite/DPAPI in author story; reviewed only.'},
 'limitations':['No complete browser page or GUI execution; DOM invokes module.load directly and does not prove reconnect app navigation.',
 'No production SDK/index/cloud/account/platform/model/paid/deployment/apply or real customer data.',
 'No independent rerun or old QA/matrix execution.',
 'Old f0/d7 child carrier full runtime bytes/pins not all retained; new bool seam attributed only to c281.',
 'Seat/store policy and older public dependencies reviewed at necessary seam; quota edge cases not independently exercised.',
 'Source51 service parent is a frozen future candidate, requiring real Source51 receipt and exact parent/protection checks before Root join.'],
 'bounds':{'candidate_QA_executions':0,'formal_mutations':0,'author_mutations':0,'central_document_mutations':0,
   'real_App_GUI_SDK_platform_model_calls':0,'real_DB_cookie_account_reads':0,'external_network_calls':0,
   'Source50_Source51_graph_helper_entry_mutations':0,'full_508_snapshot_hash_or_binary_QA':False,'join_authorized':False},
 'narrative':pinned(OWN/'CODE-REVIEW.md')}
(OWN/'CODE-REVIEW.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'report':pinned(OWN/'CODE-REVIEW.json'),'narrative':report['narrative'],'status':report['status']},ensure_ascii=False,indent=2))
