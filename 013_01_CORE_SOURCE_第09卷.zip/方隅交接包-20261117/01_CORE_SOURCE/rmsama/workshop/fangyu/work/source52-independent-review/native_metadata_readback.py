from pathlib import Path
import ast,hashlib,json,sys
sys.stdout.reconfigure(encoding='utf-8')
PROJECT=Path('C:/积木软件工坊/项目/方隅公寓客户版');WORK=PROJECT/'work'
BASE=WORK/'source52-root-integration';OWN=WORK/'source52-independent-review'
def pin(raw):return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest().upper()}
checks=[]
def read(path,expected,kind):
    raw=Path(path).read_bytes();actual=pin(raw);checks.append({'kind':kind,'path':str(path),'expected':expected,'actual':actual,'match':expected==actual});return raw
prepared=json.loads(read(BASE/'PREPARED.json',{'bytes':169430,'sha256':'BF80D4F7E920C2F15D2FEBB4190C7516E9728595D04CD111CD30FD034CBB7B60'},'fixed_Source52_prepared'))
base_evidence=prepared['evidence'][0]
prior=json.loads(read(base_evidence['path'],base_evidence['pin'],'fixed_Source51_prepared_metadata_only'))
r2_pointer=prepared['evidence'][1]
r2=json.loads(read(r2_pointer['path'],r2_pointer['pin'],'reviewed_r2_pointer'))
finals={Path(x['target']):x['candidate_pin'] for x in prior['targets']};old={Path(x['path']):x['pin'] for x in prior['protected']}
future={**old,**finals};targets={Path(x['target']):x for x in prepared['targets']};frozen={Path(x['target']):x for x in r2['targets']}
coverage=[]
for path,row in targets.items():
    read(row['candidate'],row['candidate_pin'],'fixed_Source52_candidate_not_business_QA')
    coverage.append({'target':str(path),'reviewed_r2_parent_final_exact':row['parent']==frozen[path]['parent'] and row['candidate_pin']==frozen[path]['candidate_pin'],
      'prior_coverage':'Source51_final' if path in finals else 'Source51_protected' if path in old else 'new_public_existing_parent',
      'prior_parent_match':row['parent']==future.get(path,row['parent'])})
expected_protected={path:value for path,value in future.items() if path not in targets}
for row in prepared['candidate_dependencies']:
    path=Path(row['path']);assert path in future and row['pin']==future[path] and path not in targets;expected_protected[path]=row['pin']
actual_protected={Path(x['path']):x['pin'] for x in prepared['protected']}
closure={'Source51_protected':len(old),'Source51_targets':len(finals),'Source52_targets':len(targets),
 'Source52_target_inherited_parent_count':sum(Path(x['target']) in future for x in prepared['targets']),
 'new_existing_parent_targets':[x['target'] for x in prepared['targets'] if Path(x['target']) not in future],
 'Source52_protected':len(actual_protected),'unique_protected':len(actual_protected)==len(prepared['protected']),
 'target_protected_disjoint':not(set(targets)&set(actual_protected)),
 'direct_public_deps':len(prepared['candidate_dependencies']),'exact_closure_match':expected_protected==actual_protected}
entry_row=next(x for x in prior['targets'] if x['target'].endswith('desktop_entry.py'))
entry=read(entry_row['candidate'],entry_row['candidate_pin'],'Source51_future_entry_readonly_AST')
tree=ast.parse(entry);host_node=next(x.value for x in tree.body if isinstance(x,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='HOST_PINS' for t in x.targets))
hosts={WORK/'app/src'/ast.literal_eval(k.right):ast.literal_eval(v) for k,v in zip(host_node.keys,host_node.values)}
host={'count':len(hosts),'Source52_target_intersection':[str(x) for x in set(hosts)&set(targets)],
 'all_unchanged_Host_pins_protected':all(actual_protected.get(p,{}).get('sha256')==s for p,s in hosts.items())}
modules=[('Dy_read',WORK/'app/src/assistant/owner_douyin_read.py','_SOURCES'),
 ('Dy_storage',WORK/'source51-root-integration/candidates/app/src/assistant/owner_douyin_source_archive.py','_SOURCES'),
 ('Wx_preview',WORK/'app/src/assistant/owner_channels_read.py','_SOURCE_FILES'),
 ('Wx_preview_storage',WORK/'app/src/assistant/owner_channels_preview_archive.py','_MATERIALS')]
revision=[]
for purpose,path,name in modules:
    raw=path.read_bytes();tree=ast.parse(raw)
    values=ast.literal_eval(next(x.value for x in tree.body if isinstance(x,ast.Assign) and any(isinstance(t,ast.Name) and t.id==name for t in x.targets)))
    paths={WORK/'app/src'/x for x in values};revision.append({'purpose':purpose,'map_module':str(path),'observed_module_pin':pin(raw),
      'declared_source_paths':list(values),'Source52_target_intersection':[str(x) for x in paths&set(targets)],
      'all_declared_sources_in_unchanged_protection':all(x in actual_protected for x in paths)})
first_native=json.loads((BASE/'NATIVE-DRAFT.json').read_bytes())
expected_native={'join-source52-reviewed.py':first_native['CAS'],'next_open_source52.py':first_native['helper'],'source_idle_guard.py':first_native['source_guard'],
 'source_next_open_launcher.py':{'bytes':4897,'sha256':'07545078E773134223590806A00A17DAB05B30EFFD75945C41FECED1322682E9'}}
native=[]
for name,proof in expected_native.items():
    raw=(BASE/name).read_bytes();native.append({'file':str(BASE/name),'first_declared_pin':proof,'observed_pin':pin(raw),'matches_first_declared':pin(raw)==proof})
result={'schema':'source52_native_code_metadata_readback_v1','checks':checks,'candidate_parent_coverage':coverage,'protection_closure':closure,'Host_intersection':host,
 'four_source_revision_intersections':revision,'native_first_declared_vs_observed':native,
 'all_business_graph_metadata_match':all(x['match'] for x in checks) and all(x['reviewed_r2_parent_final_exact'] and x['prior_parent_match'] for x in coverage) and closure['exact_closure_match'] and host['all_unchanged_Host_pins_protected'],
 'only_public_metadata_and_code_read':True,'protected_462_physical_files_hashed':False,'actual_process_queries':0,'App_or_QA_executions':0,'formal_mutations':0}
(OWN/'NATIVE-METADATA-READBACK.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:result[k] for k in ['all_business_graph_metadata_match','protection_closure','Host_intersection','four_source_revision_intersections','native_first_declared_vs_observed']},ensure_ascii=False,indent=2))
