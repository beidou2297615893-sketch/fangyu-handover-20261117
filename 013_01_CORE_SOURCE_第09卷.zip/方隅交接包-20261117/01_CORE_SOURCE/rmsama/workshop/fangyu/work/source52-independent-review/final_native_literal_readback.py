from pathlib import Path
import ast,copy,hashlib,json,os,sys
sys.stdout.reconfigure(encoding='utf-8')
PROJECT=Path('C:/积木软件工坊/项目/方隅公寓客户版');WORK=PROJECT/'work';BASE=WORK/'source52-root-integration';OWN=WORK/'source52-independent-review';AUDITS=WORK/'product-upgrade-20261009/audits'
def pin(raw):return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest().upper()}
checks=[]
def read(p,expected=None,label='fixed_input'):
    raw=Path(p).read_bytes();actual=pin(raw);assert expected is None or actual==expected
    checks.append({'path':str(p),'expected':expected,'actual':actual,'match':expected is None or actual==expected,'kind':label});return raw
graph=json.loads(read(BASE/'FINAL-GRAPH.json',{'bytes':3306,'sha256':'66A2C256FC8C31278F7C0354AC6A69DD3D0D9EE5BB102E0B21266D206E86ABEA'}))
cas=read(BASE/'join-source52-reviewed-final.py',graph['CAS_pin']);gate=json.loads(read(BASE/'authority-stage/source52-final-root-read.json',graph['gate_pin']))
manifest=json.loads(read(BASE/'authority-stage/source52-manifest.json',graph['manifest_pin']))
helper=read(BASE/'next_open_source52-final.py',graph['helper_candidate_pin']);launcher=read(BASE/'source_next_open_launcher-final.py',graph['launcher_candidate_pin'])
prepared=json.loads(read(BASE/'PREPARED.json',graph['prepared_pin']));read(BASE/'source_idle_guard.py',graph['source_guard_pin'])
read(AUDITS/'source51-manifest.json',graph['base_manifest_pin'],'fixed_Source51_metadata')
assert graph['schema']=='source52_root_final_graph_uninstalled_v1' and graph['source_batch']==52
assert all(graph[x] is False for x in ('published','installed','customer_database_opened','session_copied','platform_grants_changed','commercial_complete')) and graph['business_apply_calls']==0
assert (graph['targets'],graph['existing'],graph['new'],graph['protected'],graph['candidate_dependencies'])==(9,9,0,462,17)
assert manifest['schema']=='source52_next_open_manifest_v1' and gate['schema']=='source52_final_root_read'
assert manifest['source_batch']==gate['source_batch']==prepared['source_batch']==52
assert manifest['instance_id']==gate['instance_id']==prepared['instance_id']=='d075ac9c039e44038ddbc6f3e753d73c'
assert manifest['base_manifest_pin']==gate['base_manifest_pin']==prepared['base_manifest_pin']==graph['base_manifest_pin']
assert manifest['join_authorized'] is True and gate['join_authorized'] is True and prepared['join_authorized'] is False
assert manifest['approval_pin']==graph['gate_pin'] and manifest['join_script_pin']==gate['join_script_pin']==graph['CAS_pin']
assert manifest['source_guard_pin']==gate['source_guard_pin']==graph['source_guard_pin'] and gate['prepared_manifest_pin']==graph['prepared_pin']
assert all(gate[x] is True for x in ('independent_code_review_passed','independent_actual_qa_review_passed','join_script_review_passed','next_normal_open_only'))
assert all(gate[x] is False for x in ('customer_database_opened','session_copied','deployment_or_packaging_performed'))
assert manifest['protected']==prepared['protected'] and len(manifest['protected'])==462
assert {x['path']:(x['parent_pin'],x['final_pin']) for x in manifest['targets']}=={x['target']:(x['parent'],x['candidate_pin']) for x in prepared['targets']}
assert len(manifest['targets'])==9 and len(prepared['candidate_dependencies'])==17
assert graph['evidence']==gate['additional_evidence'] and len(graph['evidence'])==6
for e in graph['evidence']:read(e['path'],e['pin'],'accepted_evidence_report_pin_only')
def constants(raw):
    return {t.id:ast.literal_eval(x.value) for x in ast.parse(raw).body if isinstance(x,ast.Assign) for t in x.targets if isinstance(t,ast.Name) and t.id in ('JOIN_AUTHORIZED','MANIFEST_PIN','LATEST_PIN','GUARD_PIN','SOURCE_GUARD_PIN','BASE_MANIFEST_PIN','INSTALL_AUTHORIZED','PEER_PIN','GRAPH_PIN','HELPER_PIN','LAUNCHER_PIN')}
pairs=[('join-source52-reviewed.py','join-source52-reviewed-final.py',{'JOIN_AUTHORIZED':True}),
 ('next_open_source52.py','next_open_source52-final.py',{'JOIN_AUTHORIZED':True,'MANIFEST_PIN':graph['manifest_pin']}),
 ('source_next_open_launcher.py','source_next_open_launcher-final.py',{'LATEST_PIN':graph['helper_candidate_pin']})]
ast_checks=[]
guard_bridges=[]
old_guard={'bytes':5688,'sha256':'A8B4475C9E0EB3FDB57C5CAE791A0D7953F432E434FE4F21AFB1C9D2B93DF398'}
old_reviewed_pins={'join-source52-reviewed.py':{'bytes':30340,'sha256':'55B81D09EA8A4E133631195F45EF9036A25BE7B6D64AA30DCCE48FCC25E08BCC'},
 'next_open_source52.py':{'bytes':15374,'sha256':'CBD8C9A58CFA264DB403726BBC21C9047AFB3CDA42AAEC4F0E3DEFFA164CF81E'}}
for draft,final,allowed in pairs:
    a=read(BASE/draft,label='existing_reviewed_draft_observed_pin');b=(BASE/final).read_bytes();tree=ast.parse(a);final_tree=ast.parse(b);changed=[]
    for node in tree.body:
        if isinstance(node,ast.Assign) and len(node.targets)==1 and isinstance(node.targets[0],ast.Name) and node.targets[0].id in allowed:
            name=node.targets[0].id;node.value=ast.parse(repr(allowed[name]),mode='eval').body;changed.append(name)
    assert set(changed)==set(allowed)
    assert ast.dump(tree,include_attributes=False)==ast.dump(final_tree,include_attributes=False)
    ast_checks.append({'draft':draft,'final':final,'only_allowed_assignment_values':allowed,'entire_module_AST_equal_after_exact_allowed_literals':True})
    if draft in old_reviewed_pins:
        new_literal=repr(graph['source_guard_pin']).encode('utf-8');old_literal=repr(old_guard).encode('utf-8')
        assert a.count(new_literal)==1
        reconstructed=a.replace(new_literal,old_literal)
        assert pin(reconstructed)==old_reviewed_pins[draft]
        guard_bridges.append({'draft':draft,'only_guard_literal_update_from_reviewed_PIN':True,'reconstructed_prior_exact_pin':pin(reconstructed),'expected_prior_reviewed_pin':old_reviewed_pins[draft]})
c,h,l=constants(cas),constants(helper),constants(launcher)
assert c['JOIN_AUTHORIZED'] is True and h['JOIN_AUTHORIZED'] is True and h['MANIFEST_PIN']==graph['manifest_pin'] and l['LATEST_PIN']==graph['helper_candidate_pin']
assert c['SOURCE_GUARD_PIN']==h['GUARD_PIN']==graph['source_guard_pin'] and c['BASE_MANIFEST_PIN']==h['BASE_MANIFEST_PIN']==graph['base_manifest_pin']
read(WORK/'desktop-self-use-entry/source_next_open_launcher.py',graph['launcher_parent_pin'],'original_thin_launcher_parent')
read(WORK/'desktop-self-use-entry/next_open_source.py',{'bytes':18590,'sha256':'6DD31FBCB9864272C329C146DD7EA3E9F74F334131F84DDFEB5E3D63ED8BB611'},'immutable50_thin')
read(WORK/'desktop-self-use-entry/next_open_source51.py',{'bytes':14697,'sha256':'8540B5A0AE7572E5C2DC8A550AD74BA0918FF931C09945E7F802E0FB00F6EEF0'},'immutable51_thin')
install=read(BASE/'install_native.py',{'bytes':8555,'sha256':'E365AFAD4AD3E1E7C45A5882652983AC6A88A6ED3243E8BDBE43A1B9ACB74378'},'unbound_installer')
ic=constants(install);assert ic['INSTALL_AUTHORIZED'] is False and all(ic[x] is None for x in ('PEER_PIN','GRAPH_PIN','HELPER_PIN','LAUNCHER_PIN')) and ic['GUARD_PIN']==graph['source_guard_pin']
paths=[AUDITS/'source52-final-root-read.json',AUDITS/'source52-manifest.json',AUDITS/'join-source52-reviewed.py',WORK/'desktop-self-use-entry/next_open_source52.py']
absence=[{'path':str(p),'lexists':os.path.lexists(p)} for p in paths];assert all(not x['lexists'] for x in absence)
report={'schema':'source52_final_native_literal_readback_v1','all_checks_match':True,'checks':checks,'module_AST_literal_checks':ast_checks,
 'prior_reviewed_code_to_current_guard_literal_byte_bridges':guard_bridges,
 'manifest_prepared_target_mapping_equal':True,'manifest_prepared_protected_equal':True,'gate_graph_evidence_exact_six_equal':True,
 'final_constants':{'CAS':c,'helper':h,'launcher':l},'unbound_installer_constants':ic,'not_published_or_installed_path_metadata':absence,
 'dependency_order':'CAS -> gate -> manifest -> helper -> launcher -> FINAL-GRAPH -> final-peer -> installer; graph/gate evidence excludes final-peer, no hash cycle.',
 'bounds':{'candidate_import_or_QA_or_install':0,'actual_process_source_state_or_CIM_query':0,'business_source_or_462_physical_file_hash':0,'Root_formal_author_mutations':0}}
(OWN/'FINAL-NATIVE-PIN-READBACK.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'pin_count':len(checks),'AST_changes':ast_checks,'path_absence':absence,'all_checks_match':True},ensure_ascii=False,indent=2))
