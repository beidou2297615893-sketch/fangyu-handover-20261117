from pathlib import Path
import hashlib,json,sys
sys.stdout.reconfigure(encoding='utf-8')
BASE=Path('C:/积木软件工坊/项目/方隅公寓客户版/work/source52-store-manager')
R2=BASE/'revision2';OWN=BASE.parent/'source52-independent-review'
def pinned(p):
    b=Path(p).read_bytes();return {'path':str(p),'pin':{'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest().upper()}}
j=json.loads((R2/'FROZEN.json').read_bytes());rb=json.loads((OWN/'REVISION2-PIN-READBACK.json').read_bytes())
assert rb['all_selected_match'] and len(rb['pin_checks'])==60 and len(rb['graph_checks'])==9 and len(rb['new_seam_source_checks'])==3
report={'schema':'source52_revision2_independent_delta_review_v1','reviewer':'overnight_selfuse_non_author',
 'status':'SCOPED_DELTA_PASS_P2_CLOSED_NO_NEW_MUSTFIX',
 'meaning':'Only necessary three-delta code/causal review and exact-nine inheritance; eligible for Root successor binding, not apply or full app/GUI/production approval.',
 'freeze':pinned(R2/'FROZEN.json'),'first_freeze_retained':j['first_candidate_freeze'],
 'first_changes_required_retained':pinned(OWN/'CODE-REVIEW.md'),
 'pin_readback':pinned(OWN/'REVISION2-PIN-READBACK.json'),'pin_count':60,'graph_count':9,'raw_function_pin_count':3,
 'targets':j['targets'],'delta_targets':j['delta_targets'],
 'new_findings':[],'closed_findings':[{'id':'S52-P2-RECONNECT-CAP-ENTRY','scope':'Original confirmed current development identity recovery -> fresh scoped capability -> reachable personnel entry.',
   'code':['app.mjs 38-46 accepts same-session me false, puts top-level false into actor, awaits probe with sameSession, rechecks before device/task continuation.',
           'app.mjs 1166 calls real module probe; 1461 retains actual cloud transport/context/onScope binding.',
           'Both member modules 60/83/110 reuse full load acceptance with releaseUnknown=false for automatic probe; explicit load alone releases existing needsRead.'],
   'result':'Closed in exact revision2 necessary scope; no cached grant, write replay or expanded HQ rights.'}],
 'new_causal_evidence':j['new_seam_evidence'],
 'evidence_assessment':{'RED':'Original first candidate recovery sends only me; no members and hidden team.',
   'GREEN_four':'Exact app function bodies + actual module/WorkspaceCloud; one current members after recovery, existing unknown hold kept until explicit read, late epoch denied, ordinary 403 denied.',
   'GREEN_401_only':'Only new 401 branch; actual transport clears frontend user/token/epoch; stale personnel values absent.',
   'raw_snapshot_and_result_pins_match':True,'raw_source_function_pin_recomputed_without_execution':True,
   'GUI':False,'HTTP':False,'complete_app_import':False,
   'recorded_edges':['browser me/members/503/403/401 replies','DOM shell','refreshDevices/refreshTasks/profile/latest'],
   'HQ_limit':'New nav function did not open initially hidden review/maintenance; full page HQ gates inherited from previous static review, not a new complete page proof.'},
 'inheritance':{'other_six_exact_first_bytes':True,'all_nine_formal_join_parent_metadata_equal_first_freeze':True,
   'both_new_modules_exact_bytes_equal':True,'c281_not_rerun_for_revision2':True,
   'inherited_actual_HTTP_scope':j['inherited_actual_HTTP_evidence_scope']},
 'limitations':['No new actual AppServer/Owner HTTP or full app/GUI/production SDK execution.',
   'No old c281/Source51/other-six business rerun or full 508 dependency hash.',
   'Old f0/d7 child carrier historical bytes/pins remain incompletely retained; new snapshots do not repair history.',
   'No actual Source52 installation, production cloud/account permissions or user acceptance.',
   'Root must verify real Source51 success receipt, service parent C4D44315 and protection graph, bind revision2 exact-nine pins and separately review successor loader/CAS.'],
 'bounds':{'candidate_or_QA_executions':0,'formal_author_central_mutations':0,'Source50_Source51_graph_helper_entry_mutations':0,
   'real_App_GUI_SDK_platform_model_calls':0,'real_DB_cookie_account_reads':0,'external_network_calls':0,'join_authorized':False},
 'narrative':pinned(OWN/'REVISION2-REVIEW.md')}
(OWN/'REVISION2-REVIEW.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'report':pinned(OWN/'REVISION2-REVIEW.json'),'narrative':report['narrative'],'pin_readback':report['pin_readback'],'status':report['status']},ensure_ascii=False,indent=2))
