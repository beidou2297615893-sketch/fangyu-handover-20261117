"""Own fixture only: exact installer body/Source44 I/O; recorded authority and PS transport."""
import ast,base64,contextlib,hashlib,io,json,os,stat,subprocess,sys,traceback,types,uuid,tempfile
from pathlib import Path
from unittest.mock import patch
sys.stdout.reconfigure(encoding='utf-8')
OWN=Path(__file__).resolve().parent
RUN=OWN/'install-story-runs'/uuid.uuid4().hex
RUN.mkdir(parents=True,exist_ok=False)
ROOT=Path('C:/积木软件工坊/项目/方隅公寓客户版/work')
INPUTS={
 'installer-snapshot.py':(ROOT/'source52-root-integration/install_native.py',8555,'E365AFAD4AD3E1E7C45A5882652983AC6A88A6ED3243E8BDBE43A1B9ACB74378'),
 'guard-snapshot.py':(ROOT/'source52-root-integration/source_idle_guard.py',5948,'1E97220595CCD6954F67FAABFCAE83E52734D4EE59188F0657C9B0363FBA3AA1'),
 'source44-snapshot.py':(ROOT/'product-upgrade-20261009/audits/join-source44-reviewed.py',9601,'5F5E3EA22AF7C1FA0FEA71CFEFDA12A9D669C190D5470960901029BF8F4750FB')}
def pin(raw):return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest().upper()}
def save(p,value):
    with p.open('x',encoding='utf-8') as f:f.write(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
raws={}
for name,(source,size,sha) in INPUTS.items():
    raw=source.read_bytes();assert pin(raw)=={'bytes':size,'sha256':sha}
    with (RUN/name).open('xb') as f:f.write(raw)
    raws[name]=raw
carrier_raw=Path(__file__).read_bytes()
with (RUN/'carrier-snapshot.py').open('xb') as f:f.write(carrier_raw)
names={'blob','pin','expected','no_link_parent','prepared_temp'}
helpers=[n for n in ast.parse(raws['source44-snapshot.py']).body if isinstance(n,ast.FunctionDef) and n.name in names]
controls=[n for n in ast.parse(raws['installer-snapshot.py']).body if isinstance(n,ast.FunctionDef) and n.name in {'proof','absent','main'}]
assert len(helpers)==5 and len(controls)==3
helper_code=compile(ast.Module(body=helpers,type_ignores=[]),str(RUN/'source44-snapshot.py'),'exec')
control_code=compile(ast.Module(body=controls,type_ignores=[]),str(RUN/'installer-snapshot.py'),'exec')
audit=[];allowed_junction=None
def within(p):return Path(p).absolute().is_relative_to(RUN.absolute())
def fence(event,args):
    if event=='open' and not isinstance(args[0],int):
        p,mode,flags=args
        writing=bool(flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND))
        if writing:
            if not within(p) or not Path(p).resolve().is_relative_to(RUN.resolve()):raise PermissionError('fixture-only write')
            audit.append({'op':'open_write','path':str(p)})
    elif event in ('os.remove','os.rename','os.mkdir','os.symlink'):
        paths=args[:2] if event in ('os.rename','os.symlink') else args[:1]
        for p in paths:
            if not isinstance(p,(str,bytes)) or not within(os.fsdecode(p)):raise PermissionError('fixture-only mutation')
        audit.append({'op':event,'paths':[os.fsdecode(p) for p in paths]})
    elif event=='subprocess.Popen':
        command=args[1]
        if command!=allowed_junction:raise PermissionError('no actual process/query except own junction construction')
    elif event in ('socket.connect','sqlite3.connect'):raise PermissionError('no network or database')
sys.addaudithook(fence)
FOREIGN=b'# independent synthetic foreign helper, preserve\n'
results=[]
def fixture(name):
    project=RUN/name;work=project/'work';own=work/'candidate';audits=work/'audits';thin=work/'desktop-self-use-entry'
    for p in (own,audits,thin):p.mkdir(parents=True,exist_ok=True)
    guard=own/'source_idle_guard.py';guard.write_bytes(raws['guard-snapshot.py'])
    helper=thin/'next_open_source52.py';launcher=thin/'source_next_open_launcher.py'
    old=b'# own synthetic old launcher\n';new_helper=b'# own synthetic new helper\n';new_launcher=b'# own synthetic new launcher\n'
    launcher.write_bytes(old)
    (own/'next_open_source52-final.py').write_bytes(new_helper);(own/'source_next_open_launcher-final.py').write_bytes(new_launcher)
    immutable=[]
    for file in ('next_open_source.py','next_open_source51.py'):
        path=thin/file;path.write_bytes(('# own synthetic immutable '+file+'\n').encode());immutable.append((path,pin(path.read_bytes())))
    peer=work/'peer.md';peer.write_bytes(b'own recorded final review input, no Root authority\n')
    graph=own/'FINAL-GRAPH.json'
    graph_value={'schema':'source52_root_final_graph_uninstalled_v1','targets':9,'protected':462,
      'helper_candidate_pin':pin(new_helper),'launcher_candidate_pin':pin(new_launcher),'source_guard_pin':pin(raws['guard-snapshot.py'])}
    for file,key in [('source52-final-root-read.json','gate_pin'),('source52-manifest.json','manifest_pin'),('join-source52-reviewed.py','CAS_pin')]:
        path=audits/file;path.write_bytes(('own recorded '+file+' metadata; never invoked\n').encode());graph_value[key]=pin(path.read_bytes())
    graph.write_text(json.dumps(graph_value)+'\n',encoding='utf-8')
    g={'__name__':'own_fixed_installer_control','ast':ast,'hashlib':hashlib,'json':json,'os':os,'stat':stat,'subprocess':subprocess,'tempfile':tempfile,'types':types,'uuid':uuid,'Path':Path,
      'PROJECT':project,'WORK':work,'OWN':own,'AUDITS':audits,'RECEIPT':audits/'source52-native-installed.json','FAILED':audits/'source52-native-install-failed.json',
      'GUARD':guard,'GUARD_PIN':pin(raws['guard-snapshot.py']),'PEER':peer,'PEER_PIN':pin(peer.read_bytes()),'GRAPH':graph,'GRAPH_PIN':pin(graph.read_bytes()),
      'HELPER_PIN':pin(new_helper),'LAUNCHER_PIN':pin(new_launcher),'INSTALL_AUTHORIZED':True,'NEW_HELPER':helper,'LAUNCHER':launcher,
      'SOURCE50':immutable[0][0],'SOURCE51':immutable[1][0],'IMMUTABLE':tuple(immutable),'PARENT_PIN':pin(old)}
    exec(helper_code,g);exec(control_code,g)
    return types.SimpleNamespace(name=name,project=project,work=work,own=own,audits=audits,g=g,helper=helper,launcher=launcher,old=old,new_helper=new_helper,new_launcher=new_launcher,immutable=immutable,calls=[])
def transport(f,states=None,hooks=None):
    states=states or {};hooks=hooks or {}
    def run(args,**kwargs):
        assert len(args)==5 and args[1:4]==['-NoProfile','-NonInteractive','-EncodedCommand']
        script=base64.b64decode(args[4]).decode('utf-16le')
        assert str(f.helper).replace('\\','\\\\') in script or str(f.helper) in script
        assert 'C:/积木软件工坊/项目/方隅公寓客户版/work/desktop-self-use-entry' not in script
        number=len(f.calls)+1;state=states.get(number,'idle')
        f.calls.append({'call':number,'transport':'recorded PowerShell completion, no process launched','state':state})
        if number in hooks:hooks[number]()
        value={'scope':'fangyu_customer_source_metadata_v1','state':state,'live_count':int(state=='live'),'unknown_count':int(state=='unknown')}
        return subprocess.CompletedProcess(args,0,json.dumps(value),'')
    return run
def invoke(f,states=None,hooks=None):
    error=None;captured=io.StringIO()
    with patch.object(subprocess,'run',transport(f,states,hooks)),contextlib.redirect_stdout(captured):
        try:f.g['main']()
        except BaseException as e:error=e
    return error
def immutable(f):assert all(pin(p.read_bytes())==proof for p,proof in f.immutable)
def no_temp(f):assert not list(f.project.rglob('.source44-*.tmp'))
def expected_rejection(f,error):
    assert isinstance(error,ValueError)
    save(f.project/'EXPECTED-REJECTION.json',{'error_type':type(error).__name__,'reason':str(error),'recorded_guard_transport':f.calls})
def record(f,case,**details):
    immutable(f);no_temp(f)
    results.append({'case':case,'passed':True,'project':str(f.project),'recorded_guard_calls':f.calls,**details})
try:
    assert os.name=='nt'
    normal=fixture('normal');assert invoke(normal) is None
    assert normal.helper.read_bytes()==normal.new_helper and normal.launcher.read_bytes()==normal.new_launcher
    receipt=json.loads(normal.g['RECEIPT'].read_bytes());assert len(receipt['files'])==2
    backups=[x['backup'] for x in receipt['files'] if x['backup'] is not None];assert len(backups)==1 and Path(backups[0]).read_bytes()==normal.old
    assert not normal.g['FAILED'].exists();record(normal,'actual two-thin backup/temp/fsync/CAS/2final/1oldbackup/immutable/0temp',receipt_pin=pin(normal.g['RECEIPT'].read_bytes()))
    for state in ('live','unknown'):
        f=fixture('initial-'+state);error=invoke(f,{1:state});expected_rejection(f,error)
        assert not f.helper.exists() and f.launcher.read_bytes()==f.old and not (f.project/'backups').exists() and not f.g['RECEIPT'].exists()
        record(f,'initial recorded '+state+' holds before backup and target mutation')
    f=fixture('junction');base=f.project/'backups/source52-native';base.parent.mkdir();destination=f.project/'own-junction-destination';destination.mkdir()
    assert base.absolute().is_relative_to(RUN.absolute()) and destination.resolve().is_relative_to(RUN.resolve())
    mode='directory_symlink'
    try:os.symlink(destination,base,target_is_directory=True)
    except OSError:
        mode='Windows_junction';allowed_junction=['cmd.exe','/d','/c','mklink','/J',str(base),str(destination)]
        made=subprocess.run(allowed_junction,capture_output=True,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0));allowed_junction=None
        assert made.returncode==0,made.stderr
    assert getattr(base.lstat(),'st_file_attributes',0)&0x400
    error=invoke(f);expected_rejection(f,error)
    assert not list(destination.iterdir()) and not f.helper.exists() and f.launcher.read_bytes()==f.old and not f.g['RECEIPT'].exists()
    record(f,'own backup_base actual reparse rejects before UUID directory or backup writes',reparse_mode=mode,reparse_path=str(base),destination=str(destination),artifact_preserved=True)
    f=fixture('seal-drift');error=invoke(f,hooks={4:lambda:f.helper.write_bytes(FOREIGN)});expected_rejection(f,error)
    assert not f.g['RECEIPT'].exists() and f.g['FAILED'].exists() and f.helper.read_bytes()==FOREIGN and f.launcher.read_bytes()==f.old
    record(f,'final guard transport helper drift cannot seal; foreign preserved and own launcher restored')
    f=fixture('rollback-foreign');before=len(audit);error=invoke(f,{3:'live'},{4:lambda:f.helper.write_bytes(FOREIGN)});expected_rejection(f,error)
    assert f.helper.read_bytes()==FOREIGN and f.g['FAILED'].exists() and not f.g['RECEIPT'].exists()
    removes=[x for x in audit[before:] if x['op']=='os.remove' and Path(x['paths'][0])==f.helper];assert removes==[]
    record(f,'rollback guard transport foreign new helper preserved with zero target unlink',target_unlink_calls=0)
    f=fixture('rollback-live');error=invoke(f,{3:'live',4:'live'});expected_rejection(f,error)
    assert f.helper.read_bytes()==f.new_helper and f.g['FAILED'].exists() and not f.g['RECEIPT'].exists()
    failure_raw=f.g['FAILED'].read_bytes();calls=len(f.calls);error=invoke(f);assert isinstance(error,ValueError) and len(f.calls)==calls and f.g['FAILED'].read_bytes()==failure_raw
    record(f,'own recorded guard live refuses rollback and FAILED prevents any retry',failure_pin=pin(failure_raw))
    result={'schema':'source52_independent_two_thin_install_story_v1','status':'PASS','cases':results,
      'raw_inputs':{name:pin(raw) for name,raw in raws.items()},'carrier_pin':pin(carrier_raw),
      'body':'Exact original installer proof/absent/main AST; original Source44 five helpers, actual own ordinary-file I/O/temp/fsync/rename/replace/rollback.',
      'authority_inputs':'recorded fixture INSTALL_AUTHORIZED=True/four fixture pins/PARENT/IMMUTABLE and fixed graph counts, not Root authority',
      'process_transport':'subprocess.run PowerShell completion recorded; no actual CIM/PID/customer query',
      'bounds':{'business_CAS_calls':0,'actual_customer_process_queries':0,'real_App_GUI_DB_cookie_Vault_platform_model_SDK_calls':0,'formal_Root_author_mutations':0,'actual_project_native_installations':0},
      'junction':'Own preserved reparse artifact only; no recursive deletion or move', 'first_unexpected_failures':[]}
    save(RUN/'RESULT.json',result)
    print(json.dumps({'run':str(RUN),'result':str(RUN/'RESULT.json'),'pin':pin((RUN/'RESULT.json').read_bytes()),'cases':len(results)},ensure_ascii=False))
except BaseException:
    save(RUN/'FIRST-FAIL.json',{'status':'FAIL','traceback':traceback.format_exc(),'completed_cases':results,'raw_inputs':{name:pin(raw) for name,raw in raws.items()},'carrier_pin':pin(carrier_raw)})
    print(json.dumps({'run':str(RUN),'first_failure':str(RUN/'FIRST-FAIL.json')},ensure_ascii=False))
    raise
