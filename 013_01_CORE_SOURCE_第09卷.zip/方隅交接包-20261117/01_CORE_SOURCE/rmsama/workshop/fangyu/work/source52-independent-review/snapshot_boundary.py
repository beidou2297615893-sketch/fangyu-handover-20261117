from pathlib import Path
import hashlib,json
HERE=Path(__file__).resolve().parent;WORK=HERE.parent;ROOT=WORK/'source52-store-manager'
def pin(path):
    raw=Path(path).read_bytes();return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest().upper()}
inputs=[]
for name,size,prefix in [('PROPOSAL.md',7648,'972FC0F0'),('PARENTS.json',5020,'622C7094'),('MANAGER-GAP-c1b25e0d-2ca3-446a-93c0-0b6a39618201.json',1130,'70D47A87')]:
    path=ROOT/name;actual=pin(path);assert actual['bytes']==size and actual['sha256'].startswith(prefix)
    inputs.append({'path':str(path),'pin':actual,'provided_prefix_match':True})
parents=json.loads((ROOT/'PARENTS.json').read_bytes());verified=[]
for row in parents['targets']:
    actual=pin(row['parent_source']);assert actual==row['parent'];verified.append({'path':row['parent_source'],'pin':actual})
seams=[WORK/'app/src/assistant/employee_workspace.py',WORK/'app/src/integrations.py',WORK/'app/src/app.py',WORK/'app/src/web/workspace/local-transport.mjs',WORK/'owner-admin-20261004/owner_admin.py']
report={'schema':'source52_pre_implementation_boundary_review_v1','result':'P1_EMPLOYEE_MEMBER_UNKNOWN_MAPPED_TO_400',
    'inputs':inputs,'original_seams_read_snapshot':[{'path':str(path),'pin':pin(path)}for path in seams],
    'proposal_parents':verified,'report':{'path':str(HERE/'BOUNDARY-REVIEW.md'),'pin':pin(HERE/'BOUNDARY-REVIEW.md')},
    'Root_accepted_minimal_eighth_target':'app/src/assistant/employee_workspace.py',
    'final_CODE_or_implementation_PASS':False,'candidate_code_read':False,'QA_executed':False,
    'formal_or_central_or_author_writes':0,'App_or_real_data_or_platform_SDK_actions':0}
dest=HERE/'BOUNDARY-REVIEW.json';dest.write_bytes((json.dumps(report,ensure_ascii=False,indent=2)+'\n').encode())
print(json.dumps({'path':str(dest),'pin':pin(dest),'report':report['report'],'inputs':inputs},ensure_ascii=False,indent=2))
