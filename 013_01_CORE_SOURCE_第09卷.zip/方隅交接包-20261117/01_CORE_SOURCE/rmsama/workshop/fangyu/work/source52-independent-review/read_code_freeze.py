from pathlib import Path
import hashlib,json
ROOT=Path('C:/积木软件工坊/项目/方隅公寓客户版/work/source52-store-manager')
file=ROOT/'FROZEN.json';raw=file.read_bytes()
assert len(raw)==20306 and hashlib.sha256(raw).hexdigest().upper()=='44446145C039640067278B2247A5ACAC6709753E6FA3DA7F836B63BFA20C3465'
j=json.loads(raw)
print(json.dumps({'keys':list(j),'schema':j.get('schema'),'targets':j.get('targets'),
    'evidence':j.get('evidence'),'carriers':j.get('carriers'),'actual_results':j.get('actual_results')},ensure_ascii=False,indent=2))
