from pathlib import Path
import hashlib,json,sys
sys.stdout.reconfigure(encoding='utf-8')
BASE=Path('C:/积木软件工坊/项目/方隅公寓客户版/work/source52-store-manager')
OWN=BASE.parent/'source52-independent-review'
def pin(path):
    b=Path(path).read_bytes()
    return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest().upper()}
j=json.loads((BASE/'FROZEN.json').read_text(encoding='utf-8'))
rows=[]
def check(path,expected,kind):
    actual=pin(path)
    rows.append({'kind':kind,'path':str(path),'expected':expected,'actual':actual,'match':actual==expected})
check(BASE/'FROZEN.json',{'bytes':20306,'sha256':'44446145C039640067278B2247A5ACAC6709753E6FA3DA7F836B63BFA20C3465'},'authority_pointer')
for t in j['targets']:
    check(t['candidate'],t['candidate_pin'],'candidate')
    check(t['parent_source'],t['parent'],'parent_copy')
    check(t['original_parent_source'],t['parent'],'declared_original_parent')
for t in j['Source51_other_three_unchanged_dependencies']:
    check(t['candidate'],t['pin'],'necessary_Source51_dependency')
for t in j['documents']:
    check(t['path'],t['pin'],'frozen_document_pointer')
for k in ['final_main_result','final_DOM_result']:
    t=j[k];check(t['path'],t['pin'],k)
for t in j['carriers_current_bytes_read_at_freeze_not_all_historical_runtime_signatures']:
    check(t['path'],t['pin'],'current_carrier')
dependencies=json.loads((BASE/'DEPENDENCIES.json').read_text(encoding='utf-8'))
needed={str(BASE/'candidate/work/cloud/workspace/product_entitlements.cjs').replace('\\','/'),
        str(BASE/'runtime/app/src/app.py').replace('\\','/'),
        str(BASE/'runtime/app/src/integrations.py').replace('\\','/'),
        str(BASE/'runtime/app/src/assistant/employee_workspace.py').replace('\\','/'),
        str(BASE/'tests/local-transport-candidate.mjs').replace('\\','/')}
selected=[t for t in dependencies['files'] if t['path'].replace('\\','/') in needed]
assert len(selected)==5
for t in selected:
    check(t['path'],t['pin'],'necessary_current_carrier_dependency')
portal=BASE.parent/'owner-admin-20261004/site/owner-admin.mjs'
check(portal,pin(portal),'readonly_existing_portal_wiring_observed_pin_not_FROZEN_authority')
out={'schema':'source52_independent_pin_readback_v1','candidate_runtime_executions':0,'formal_mutations':0,'all_selected_match':all(x['match'] for x in rows),'checks':rows,'full_dependency_snapshot_hashed':False}
(OWN/'PIN-READBACK.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'all_selected_match':out['all_selected_match'],'check_count':len(rows),'mismatches':[x for x in rows if not x['match']]},ensure_ascii=False,indent=2))
