# independent synthetic foreign helper, preserve
