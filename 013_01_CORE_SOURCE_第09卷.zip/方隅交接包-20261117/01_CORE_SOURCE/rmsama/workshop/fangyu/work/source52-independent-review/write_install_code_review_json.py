from pathlib import Path
import hashlib,json,sys
sys.stdout.reconfigure(encoding='utf-8')
WORK=Path('C:/积木软件工坊/项目/方隅公寓客户版/work');BASE=WORK/'source52-root-integration';OWN=WORK/'source52-independent-review'
def pinned(p):
    raw=Path(p).read_bytes();return {'path':str(p),'pin':{'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest().upper()}}
report={'schema':'source52_two_thin_installer_first_code_review_v1','reviewer':'overnight_selfuse_non_author','status':'CHANGES_REQUIRED_THREE_INSTALLER_GATES',
 'reviewed_input':{'path':str(BASE/'install_native.py'),'pin':{'bytes':8293,'sha256':'B3C0FD2095237BCE1636611E16A746B62333623AF9995EF57F63609264F50E3A'},
   'verified_during_initial_full_code_read':True,'candidate_import_or_execution':False},
 'findings':[{'id':'S52-INSTALL-P1-FOREIGN-UNLINK','priority':1,'must_fix':True,'first_lines':[112,116],
   'cause':'New helper rollback reads own current bytes before potentially slow absent guard, then unlinks without fresh final/ordinary check.',
   'impact':'Foreign replacement during guard wait can be deleted.',
   'minimal_fix':'After absent succeeds, require no_link_parent and expected(target,row.final) immediately before unlink; drift held.'},
  {'id':'S52-INSTALL-P2-FINAL-SEAL','priority':2,'must_fix':True,'first_lines':[96,105],
   'cause':'Final guard and immutable old50/51 checks omit fresh exact reads of both installed thin target finals before receipt.',
   'impact':'First new thin file can drift while second/final guard waits and receipt still claims two files installed.',
   'minimal_fix':'After final absent, expected both fixed target finals/ordinary files immediately before receipt preparation.'},
  {'id':'S52-INSTALL-P1-BACKUP-ROOT','priority':1,'must_fix':True,'first_lines':[76,82],
   'cause':'no_link_parent(backup.parent) excludes backup_base itself; mkdir(parents=True) can follow existing source52-native reparse root.',
   'impact':'UUID directory and original launcher backup can be written beyond intended project backup root.',
   'minimal_fix':'Use mature backup_base ancestor check and mkdir(exist_ok=True), then no_link_parent(backup) including base before backup.mkdir and any backup writes.'}],
 'Root_notified_all_three':True,
 'reviewed_without_other_mustfix':['INSTALL_AUTHORIZED False and four pins None reject before consumer query or mutations.',
   'Exactly new helper52 and fixed parent launcher targets; old50/51 immutable reads only.',
   'Pinned Source44 five AST helpers and guard raw compile; fixed candidate/peer/graph/gate/manifest/CAS paths.',
   'Wrapper-only four paths/Python alias/runtime occupancy scope, original App live may remain; no business source-idle claim.',
   'Existing receipt/FAILED preserved, no auto retry; own guard live/unknown refuses rollback, foreign drift held subject to missing unlink freshness.'],
 'preparation_state':{'INSTALL_AUTHORIZED':False,'PEER_PIN':None,'GRAPH_PIN':None,'HELPER_PIN':None,'LAUNCHER_PIN':None},
 'narrow_guard_scope':['source_next_open_launcher.py','next_open_source.py','next_open_source51.py','next_open_source52.py'],
 'guard_details_and_actual_windows_WQL_scope':'Reviewed separately by platforms; no actual query here.',
 'limitations':['No final graph/literal binding, guard actual PID representative, two-thin CAS or actual installation.',
   'First source exact pin is review history; parallel revised installer is not automatically reviewed.',
   'No helper/businessCAS/r2/462/guard official repeat or old Source51 occupancy reuse.',
   'Suggested only new thin representative cases; no executed tests or fixtures.'],
 'bounds':{'actual_process_query_installer_guard_QA_state_calls':0,'original_backup_business_source_DB_cookie_Vault_reads':0,
   'formal_author_Root_central_Source50_Source51_mutations':0,'actual_installations':0,'external_calls':0},
 'narrative':pinned(OWN/'INSTALL-CODE-REVIEW.md')}
(OWN/'INSTALL-CODE-REVIEW.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'report':pinned(OWN/'INSTALL-CODE-REVIEW.json'),'narrative':report['narrative'],'status':report['status']},ensure_ascii=False,indent=2))
