from pathlib import Path
import hashlib,json,sys
sys.stdout.reconfigure(encoding='utf-8')
PROJECT=Path('C:/积木软件工坊/项目/方隅公寓客户版');WORK=PROJECT/'work'
BASE=WORK/'source52-root-integration';OWN=WORK/'source52-independent-review'
def pinned(p):
    raw=Path(p).read_bytes();return {'path':str(p),'pin':{'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest().upper()}}
meta=json.loads((OWN/'NATIVE-METADATA-READBACK.json').read_bytes());assert meta['all_business_graph_metadata_match']
report={'schema':'source52_native_first_draft_independent_code_review_v1','reviewer':'overnight_selfuse_non_author',
 'status':'CHANGES_REQUIRED_FIRST_NATIVE_P1_PREDECESSOR_BACKUP_GATE',
 'first_declared_native_pins':json.loads((BASE/'NATIVE-DRAFT.json').read_bytes()),
 'fixed_prepared':pinned(BASE/'PREPARED.json'),'metadata_readback':pinned(OWN/'NATIVE-METADATA-READBACK.json'),
 'findings':[{'id':'S52-NATIVE-P1-BACKUPS-BEFORE-WRITE','priority':1,'must_fix':True,
   'file':str(BASE/'next_open_source52.py'),'first_draft_lines':{'validating_layer':[80,125],'cumulative_readback':[127,151],'predecessor_only_old_readback':211,'first_52_invoke':215,'too_late_52_full_readback':216},
   'related_file':str(BASE/'join-source52-reviewed.py'),'related_first_draft_lines':{'predecessor':[165,234],'write_path':[290,339]},
   'cause':'New cumulative original backup validation runs only after 52 CAS. Old Source51 readback and first 52 predecessor gate check raw lineage/current finals/protected without original backup addresses/bytes.',
   'impact':'Missing/corrupt/wrong-batch predecessor backup can permit Source52 STARTED/apply9 before final cumulative readback holds.',
   'minimal_fix':'Reuse new fixed _layer for predecessor-only 50/51 backup and raw lineage readback before 52 STARTED and before any 52 backup/temp/replace; keep legacy50/51 immutable.',
   'Root_notified_and_accepted':True,
   'Root_reported_fix_pending_exact_delta_review':{'helper':{'bytes':15374,'sha256':'CBD8C9A58CFA264DB403726BBC21C9047AFB3CDA42AAEC4F0E3DEFFA164CF81E'},
     'CAS':{'bytes':30340,'sha256':'55B81D09EA8A4E133631195F45EF9036A25BE7B6D64AA30DCCE48FCC25E08BCC'},
     'guard':{'bytes':5688,'sha256':'A8B4475C9E0EB3FDB57C5CAE791A0D7953F432E434FE4F21AFB1C9D2B93DF398'}},
   'new_state_representative_suggestion':'Synthetic public-source predecessor backups: corrupt/misdirect 51 backup -> held with no 52 STARTED/backup/temp/source writes; normal cumulative chain and invoke failure unknown remain required. Not executed by reviewer.'}],
 'reviewed_first_draft_without_other_must_fix':['Exact nine parent/final fixed whitelist and protection graph binding.',
   'Future cumulative _layer address/raw lineage/50 via51 backup/51 via52 backup logic, except its late first invocation.',
   'Same original byte OS lock low-level50->51->52 and fresh native -X utf8 -B -I entry after source joining.',
   'Unknown STARTED/FAILED no reapply, any invocation failure reports unknown source mutations.',
   'CAS Source44 five helpers, fixed parent backup CAS and own rollback refusing foreign drift.',
   'Pinned bytes compile invocation; launcher fixed flags/check-only without guard query/write/apply/business import.'],
 'metadata_findings':{'protection_closure':meta['protection_closure'],'Host_intersection':meta['Host_intersection'],'four_source_revision_intersections':meta['four_source_revision_intersections'],
   'first_declared_vs_observed_drift':meta['native_first_declared_vs_observed']},
 'limitations':['No final literal authorization or actual installation pass.',
   'Root native changed during first review; newly reported stable fix pins remain unreviewed until exact delta dispatch.',
   'Guard WQL detailed review delegated by Root to platforms; only guard caller contract reviewed here.',
   'No actual native/CAS/byte-lock state story executed; no current process query or original physical backup read.',
   'Business revision2/other9/Source51 QA not repeated; protection closure metadata only, not 462 physical file hash.'],
 'bounds':{'join_authorized':False,'actual_process_queries':0,'App_GUI_CIM_SDK_platform_model_calls':0,
   'real_DB_cookie_Vault_account_or_original_backup_reads':0,'QA_or_CAS_executions':0,'formal_author_central_Source50_Source51_mutations':0},
 'narrative':pinned(OWN/'NATIVE-CODE-REVIEW.md')}
(OWN/'NATIVE-CODE-REVIEW.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'report':pinned(OWN/'NATIVE-CODE-REVIEW.json'),'narrative':report['narrative'],'metadata':report['metadata_readback']},ensure_ascii=False,indent=2))
