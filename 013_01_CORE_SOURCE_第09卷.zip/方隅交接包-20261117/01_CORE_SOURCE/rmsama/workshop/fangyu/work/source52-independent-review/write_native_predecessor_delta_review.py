from pathlib import Path
import ast,hashlib,json,sys
sys.stdout.reconfigure(encoding='utf-8')
WORK=Path('C:/积木软件工坊/项目/方隅公寓客户版/work');BASE=WORK/'source52-root-integration';OWN=WORK/'source52-independent-review'
def pin(raw):return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest().upper()}
def pinned(p):return {'path':str(p),'pin':pin(Path(p).read_bytes())}
expected={'join-source52-reviewed.py':{'bytes':30340,'sha256':'55B81D09EA8A4E133631195F45EF9036A25BE7B6D64AA30DCCE48FCC25E08BCC'},
 'next_open_source52.py':{'bytes':15374,'sha256':'CBD8C9A58CFA264DB403726BBC21C9047AFB3CDA42AAEC4F0E3DEFFA164CF81E'},
 'source_idle_guard.py':{'bytes':5688,'sha256':'A8B4475C9E0EB3FDB57C5CAE791A0D7953F432E434FE4F21AFB1C9D2B93DF398'}}
rows=[];constants={}
for n,p in expected.items():
    raw=(BASE/n).read_bytes();actual=pin(raw);rows.append({'path':str(BASE/n),'expected':p,'actual':actual,'match':actual==p});assert actual==p
    if n!='source_idle_guard.py':
        constants[n]={t.id:ast.literal_eval(x.value) for x in ast.parse(raw).body if isinstance(x,ast.Assign) for t in x.targets if isinstance(t,ast.Name) and t.id in ('JOIN_AUTHORIZED','MANIFEST_PIN','GUARD_PIN','SOURCE_GUARD_PIN')}
assert constants['next_open_source52.py']['JOIN_AUTHORIZED'] is False and constants['next_open_source52.py']['MANIFEST_PIN'] is None
assert constants['join-source52-reviewed.py']['JOIN_AUTHORIZED'] is False
assert constants['next_open_source52.py']['GUARD_PIN']==expected['source_idle_guard.py']==constants['join-source52-reviewed.py']['SOURCE_GUARD_PIN']
first=pinned(OWN/'NATIVE-CODE-REVIEW.md');assert first['pin']=={'bytes':6375,'sha256':'16D8A4DBDB31BBB0C1ACD2858FD17D40229FF42633509290ED3D5D7A4D638B78'}
pin_report={'schema':'source52_native_predecessor_delta_pin_readback_v1','exact_checks':rows,'preparation_constants':constants,
 'first_changes_required_retained':first,'all_match':True,'candidate_runtime_executions':0,'actual_process_queries':0,'original_backup_reads':0}
(OWN/'NATIVE-PREDECESSOR-DELTA-PIN.json').write_text(json.dumps(pin_report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
review={'schema':'source52_native_predecessor_delta_independent_review_v1','status':'SCOPED_CODE_DELTA_PASS_P1_CLOSED_NO_NEW_MUSTFIX',
 'reviewer':'overnight_selfuse_non_author','exact_inputs':rows,'first_review':first,'pin_readback':pinned(OWN/'NATIVE-PREDECESSOR-DELTA-PIN.json'),
 'closed_finding':{'id':'S52-NATIVE-P1-BACKUPS-BEFORE-WRITE','priority':1,'closed_at_code_level':True,
   'helper_lines':[128,136,223,227],'CAS_lines':[110,131,169,171,247,249,319,353,367,375],
   'proof':'Both helper before52 STARTED and CAS before52 backup/temp/replace now validate actual fixed50/51 parent backup addresses/bytes and original raw receipt lineage. Per-replace and success seal repeat predecessor-only gate against51 eleven parents.'},
 'new_findings':[],'preparation_authority':constants,'guard_review_scope':'Literal pin equality and caller order only; platforms independently reviews guard official WQL details.',
 'ordering_assessment':['Same byte lock, original51 current readback, predecessor backup readback, fresh guard,52STARTED,CAS.',
   'CAS verified original backups before any52 file mutation; guard before backup/temp, everyreplace and success seal.',
   'Perreplace/seal backup checks use fixed51 authority, never52 nine parents or overlaid current source bytes.',
   'Beforeinvoke failure held; after anyinvoke source mutations remain unknown, STARTED/FAILED no retry.'],
 'limitations':['No new native state story/actualOSlock/CAS/processquery/installation/finalGraph.',
   'No repeated9/462/17/8HOST/fourrevision tuple or businessrevision2 QA.',
   'No realDB/Cookie/Vault/actualoriginalbackup/platform/model/SDK/App/GUI/CIM actions.',
   'CODE P1 closure does not replace Root final literal binding and necessary independent native evidence review.'],
 'bounds':{'join_authorized':False,'52_manifest_pin':None,'formal_author_Root_central_Source50_Source51_mutations':0,
   'QA_CAS_App_CIM_process_or_external_calls':0,'real_DB_cookie_Vault_originalbackup_reads':0},
 'narrative':pinned(OWN/'NATIVE-PREDECESSOR-DELTA-REVIEW.md')}
(OWN/'NATIVE-PREDECESSOR-DELTA-REVIEW.json').write_text(json.dumps(review,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'report':pinned(OWN/'NATIVE-PREDECESSOR-DELTA-REVIEW.json'),'narrative':review['narrative'],'pin_report':review['pin_readback'],'status':review['status']},ensure_ascii=False,indent=2))
