"""Reuse the existing public Source50 joint snapshot for independent Source51."""
from pathlib import Path
import hashlib,json,shutil

HERE=Path(__file__).resolve().parent
WORK=HERE.parent
PREP=WORK/'overnight-commercial-20261014/source50-preparation'
INPUTS=PREP/'evidence/JOINT-INPUTS.json'
MANIFEST=PREP/'PREPARED.json'
PIN=lambda raw:{'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest().upper()}

def main():
    index_raw=INPUTS.read_bytes()
    assert PIN(index_raw)=={'bytes':312784,'sha256':'DFE218A4770ED34D867E009BEAF9F84153B5AD2B8B19B6D82DB7CD62BCBEEEC3'}
    prepared_raw=MANIFEST.read_bytes()
    assert PIN(prepared_raw)=={'bytes':165442,'sha256':'5613B97635D7DD386DCE6E88D0B31C50D563F71BC8D970D3033A82882FC3BBD0'}
    record=json.loads(index_raw);snapshot=Path(record['joint_root'])
    assert snapshot==PREP/'joint'
    targets=['assistant/self_operating_read.py','assistant/self_operating_source_intent.py',
        'assistant/owner_douyin_source_archive.py','web/workspace/self-operating-read.mjs']
    if (HERE/'app').exists() or (HERE/'guarded-cli').exists():raise ValueError('existing candidate preserved')
    # Copy only public paths already enumerated in the verified Source50 index;
    # no data, accounts, Cookie, secrets, .lnk, original pilot or DB traversal.
    for row in record['inputs']:
        relative=Path(row['relative'])
        assert not relative.is_absolute() and '..' not in relative.parts
        assert relative.parts[0] in ('app','guarded-cli')
        source=snapshot/relative;target=HERE/relative
        assert source.is_file() and not source.is_symlink()
        target.parent.mkdir(parents=True,exist_ok=True)
        shutil.copyfile(source,target)
    parents=[]
    for name in targets:
        source=HERE/'app/src'/name;raw=source.read_bytes()
        preserved=HERE/'parents'/name;preserved.parent.mkdir(parents=True,exist_ok=True)
        preserved.write_bytes(raw)
        parents.append({'relative':name,'target':str(WORK/'app/src'/name),'parent_pin':PIN(raw),'parent_preserved':str(preserved)})
    evidence=HERE/'evidence';evidence.mkdir(exist_ok=True)
    report={'schema':'source51_public_baseline_v1','source50_dependency_pin':PIN(prepared_raw),
        'source50_snapshot_index_pin':PIN(index_raw),
        'scope':'public Source50 owned verified joint snapshot reused; Source50 actual apply not performed',
        'copied_public_paths':len(record['inputs']),'initial_candidate_targets':parents,
        'original_data_read':False,'original_source_write':False,'purpose_granted':False}
    (evidence/'BASELINE.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'result':'ASSEMBLED_PUBLIC_BASELINE','public_paths':len(record['inputs']),'targets':len(parents)}))

if __name__=='__main__':main()
