"""Apply the single fixed-platform source-page validator change to own candidate."""
from pathlib import Path
HERE=Path(__file__).resolve().parent
path=HERE/'app/src/web/workspace/self-operating-read.mjs'
parent=HERE/'parents/web/workspace/self-operating-read.mjs'
text=parent.read_bytes()
def replace(before,after,count=1):
    global text
    before=before.encode();after=after.encode()
    assert text.count(before)==count,(before,text.count(before))
    text=text.replace(before,after)
replace("source.platform!=='xiaohongshu'", "!(source.platform==='xiaohongshu'||source.platform==='douyin'&&state.dy.primary&&state.accounts.some(a=>a.id===source.account_id&&a.platform==='douyin'))",3)
replace("value.contract==='owner_xhs_source_locator_v1'", "['owner_xhs_source_locator_v1','owner_source_locator_v2'].includes(value.contract)")
replace("a.id===state.acqPair?.account_id&&a.platform==='xiaohongshu'", "a.id===state.acqPair?.account_id&&(a.platform==='xiaohongshu'||a.platform==='douyin'&&state.dy.primary)")
replace("function sourceLocatorResult(value,pair){const keys=", "function sourceLocatorResult(value,pair){const account=state.accounts.find(a=>a.id===pair.account_id),validURL=account?.platform==='douyin'&&state.dy.primary?/^https:\\/\\/www\\.douyin\\.com\\/video\\/[0-9]{1,24}$/.test(value?.canonical_url):account?.platform==='xiaohongshu'&&/^https:\\/\\/www\\.xiaohongshu\\.com\\/explore\\/[A-Za-z0-9_-]{1,160}$/.test(value?.canonical_url);const keys=")
replace("!/^https:\\/\\/www\\.xiaohongshu\\.com\\/explore\\/[A-Za-z0-9_-]{1,160}$/.test(value.canonical_url)", "!validURL")
replace("`作品读取组 ${groups.size+1}`", "`${source.platform==='douyin'?'抖音':'小红书'} · 作品读取组 ${groups.size+1}`")
path.write_bytes(text)
