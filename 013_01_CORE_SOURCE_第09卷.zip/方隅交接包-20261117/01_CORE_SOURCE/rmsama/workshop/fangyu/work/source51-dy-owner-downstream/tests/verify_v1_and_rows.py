"""Narrow v1 preserved boundary using a fresh normal AppServer/Core instance."""
from pathlib import Path
import hashlib,json,sys,uuid,time
HERE=Path(__file__).resolve().parents[1];SOURCE=HERE/'app/src';sys.path.insert(0,str(SOURCE))
from app import AppServer
from assistant.self_operating_read import open_owner_read_instance
from assistant.platform_receipt_archive import SOURCES,_hash
from core import CoreError

run=HERE/'v1-boundary'/uuid.uuid4().hex;run.mkdir(parents=True)
instance=open_owner_read_instance(str(run/'instance'),HERE,hashlib.sha256((SOURCE/'platform_cli.py').read_bytes()).hexdigest(),product='xiaohongshu_v1')
server=None
try:
    server=AppServer(('127.0.0.1',0),instance.directory/'data',employee_workspace=True,self_operating_instance=instance,guarded_cli_runtime=str(HERE/'guarded-cli'))
    entered=server.core.handle('personal_enter',{});token=entered['token'];user=server.core.store.get('users',entered['user']['id'])
    w=server._self_operating_reads;state=w.dispatch(token,'workspace_state',{})
    assert state.get('owner_primary_platforms',False) is False and w._douyin is None and w._douyin_archive is None
    assert state['owner_source_locator']['contract']=='owner_xhs_source_locator_v1'
    try:w.dispatch(token,'account_create',{'name':'synthetic-v1-rejected-Dy','platform':'douyin','expected_uid':'765432100123'})
    except CoreError:pass
    else:raise AssertionError('v1 permitted new Dy registration')
    uid='douyin:synthetic-v1';lead_id=_hash('synthetic-v1-lead');account_id=uuid.uuid4().hex
    server.core.store.put('accounts',{'id':account_id,'tenant_id':user['tenant_id'],'cloud_owner':user['username'],
        'platform':'douyin','platform_uid':'765432100123','conn_id':'synthetic','status':'ready'})
    server.core.store.put('leads',{'id':lead_id,'tenant_id':user['tenant_id'],'cloud_owner':user['username'],
        'platform':'douyin','source_uid':uid,'readonly_archive':True})
    server.core.store.put(SOURCES,{'id':_hash([user['tenant_id'],uid]),'tenant_id':user['tenant_id'],'cloud_owner':user['username'],
        'lead_id':lead_id,'source_uid':uid,'platform':'douyin','account_id':account_id,'created_at':time.time()})
    assert w.dispatch(token,'owner_source_pool_page',{'limit':50,'cursor':None})['leads']==[]
    for action,data in (
        ('source_intent_analyze_selected',{'lead_ids':[lead_id],'city':'上海','area':'全市','idempotency_key':'synthetic_v1_block'}),
        ('owner_source_locator_get',{'account_id':account_id,'lead_id':lead_id})):
        try:w.dispatch(token,'product_action',{'action':action,'data':data})
        except CoreError:pass
        else:raise AssertionError('v1 Dy downstream should reject '+action)
    result={'result':'PASS V1 BOUNDARY','normal_AppServer_Core':True,'source_locator_contract':'owner_xhs_source_locator_v1',
        'new_Dy_registration_rejected':True,'persisted_Dy_not_in_pool':True,'Dy_analysis_and_locator_rejected':True,
        'real_platform_model_or_company_calls':0,'original_instance_changed':False}
finally:
    if server is not None:
        closed=server.close_owned_jobs();server.server_close()
        if 'result' in globals():result['owned_jobs_closed']=closed
output=run/'RESULT.json';output.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
(HERE/'evidence/LATEST-V1.txt').write_text(str(output)+'\n',encoding='utf-8');print(json.dumps(result))
