// Evaluate the actual unchanged-shape row/locator validators, not mirrored code.
const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),assert=require('node:assert/strict');
const root=path.resolve(__dirname,'..'),source=fs.readFileSync(path.join(root,'app/src/web/workspace/self-operating-read.mjs'),'utf8');
const line=(prefix)=>{const found=source.split(/\r?\n/).filter(x=>x.startsWith(prefix));assert.equal(found.length,1);return found[0];};
const code=[line('const acqId='),line('const acqHex='),line('const acqExact='),line('function sourcePageRows('),line('function sourceLocatorResult(')].join('\n');
const state={dy:{primary:true},accounts:[{id:'synthetic-dy',platform:'douyin'},{id:'synthetic-xhs',platform:'xiaohongshu'}]};
const context={state};vm.createContext(context);vm.runInContext(code,context);
const row={id:'a'.repeat(64),account_id:'synthetic-dy',group_id:'b'.repeat(64),platform:'douyin',title:'合成作品',text:'合成评论',author:'合成人',
    grade:'C',analysis_status:'pending_analysis',analysis_verified:false,intent_level:null,analysis_reason:'',readonly_archive:true,can_reply:false};
assert.equal(context.sourcePageRows([row]).length,1);
state.dy.primary=false;assert.throws(()=>context.sourcePageRows([row]));state.dy.primary=true;
assert.throws(()=>context.sourcePageRows([{...row,account_id:'synthetic-xhs'}]));
assert.throws(()=>context.sourcePageRows([{...row,platform:'wechat_channels'}]));
const pair={account_id:'synthetic-dy',lead_id:row.id},locator={purpose:'owner_source_locator_get',...pair,
    canonical_url:'https://www.douyin.com/video/7654321001234567890',read_only:true,mutation_committed:false,
    platform_requests_started:false,platform_reply_verified:false,auto_retry:false};
assert.equal(context.sourceLocatorResult(locator,pair).canonical_url,locator.canonical_url);
assert.throws(()=>context.sourceLocatorResult({...locator,canonical_url:'https://www.xiaohongshu.com/explore/same-public-id'},pair));
assert.throws(()=>context.sourceLocatorResult({...locator,canonical_url:locator.canonical_url+'?secret=synthetic'},pair));
state.dy.primary=false;assert.throws(()=>context.sourceLocatorResult(locator,pair));
const output={result:'PASS ACTUAL FRONTEND VALIDATORS ONLY',valid_v2_Dy:true,v1_Dy_rejected:true,foreign_account_rejected:true,
    Wx_transport_preview_rejected:true,actual_platform_locator_only:true,query_context_rejected:true,GUI:false,normal_browser_executed:false};
fs.writeFileSync(path.join(root,'evidence/FRONTEND-ROWS-RESULT.json'),JSON.stringify(output,null,2)+'\n');console.log(JSON.stringify(output));
