"""Freeze six public successors; never import, start or write the formal App."""
from pathlib import Path
import ast
import difflib
import hashlib
import json

HERE = Path(__file__).resolve().parent
WORK = HERE.parent
SOURCE = HERE / 'app/src'
PREP = WORK / 'overnight-commercial-20261014/source50-preparation'
PIN = lambda raw: {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest().upper()}
NAMES = (
    'assistant/self_operating_read.py',
    'assistant/self_operating_source_intent.py',
    'assistant/source_intent_analysis.py',
    'assistant/owner_douyin_source_archive.py',
    'assistant/self_operating_acquisition.py',
    'web/workspace/self-operating-read.mjs',
)


def file_record(path):
    return {'path': str(path), 'pin': PIN(path.read_bytes())}


def write_new(path, raw):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as out:
        out.write(raw)


def json_new(path, value):
    write_new(path, (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode('utf-8'))


def delta(before, after, old, new):
    return ''.join(difflib.unified_diff(
        before.decode('utf-8').splitlines(True), after.decode('utf-8').splitlines(True),
        fromfile=old, tofile=new)).encode('utf-8')


def constant(relative, name):
    tree = ast.parse((SOURCE / relative).read_bytes())
    for node in tree.body:
        if isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and t.id == name for t in node.targets):
            return ast.literal_eval(node.value)
    raise ValueError('missing fixed constant: ' + name)


def main():
    assert not (HERE / 'evidence/FROZEN.json').exists(), 'existing freeze preserved'
    prepared_raw = (PREP / 'PREPARED.json').read_bytes()
    assert PIN(prepared_raw) == {'bytes': 165442, 'sha256': '5613B97635D7DD386DCE6E88D0B31C50D563F71BC8D970D3033A82882FC3BBD0'}
    prepared = json.loads(prepared_raw)
    assert prepared['join_authorized'] is False and len(prepared['targets']) == 55
    frozen50 = PREP / 'evidence/FROZEN.json'
    assert PIN(frozen50.read_bytes()) == {'bytes': 38282, 'sha256': '112A691234634690E70EF4D3CAEDAD026D21882E762EE6F13F398F7A770CC67D'}
    index_path = PREP / 'evidence/JOINT-INPUTS.json'
    assert PIN(index_path.read_bytes()) == {'bytes': 312784, 'sha256': 'DFE218A4770ED34D867E009BEAF9F84153B5AD2B8B19B6D82DB7CD62BCBEEEC3'}
    index = json.loads(index_path.read_bytes())
    joint = Path(index['joint_root'])
    assert joint == PREP / 'joint' and len(index['inputs']) == 781
    prior = {row['relative']: row for row in index['inputs']}
    overlay = {Path(row['target']): row for row in prepared['targets']}
    target_rows, parent_records, all_diffs = [], [], []
    for name in NAMES:
        target = WORK / 'app/src' / name
        parent = HERE / 'parents' / name
        parent_raw = parent.read_bytes()
        assert PIN(parent_raw) == prior['app/src/' + name]['pin']
        expected = overlay[target]['candidate_pin'] if target in overlay else PIN(target.read_bytes())
        assert PIN(parent_raw) == expected, 'not the actual current/source50 successor parent: ' + name
        raw = (SOURCE / name).read_bytes()
        assert raw != parent_raw
        if name.endswith('.py'):
            ast.parse(raw)
        candidate = HERE / 'frozen-candidate/app/src' / name
        write_new(candidate, raw)
        row = {'target': str(target), 'candidate': str(candidate),
               'parent': PIN(parent_raw), 'candidate_pin': PIN(raw)}
        target_rows.append(row)
        parent_records.append({'path': str(parent), 'pin': PIN(parent_raw),
            'formal_current': file_record(target),
            'phase': 'Source50 candidate successor' if target in overlay else 'current formal public parent'})
        change = delta(parent_raw, raw, 'parent/' + name, 'source51/' + name)
        diff_path = HERE / 'evidence/diffs' / (name.replace('/', '__') + '.diff')
        write_new(diff_path, change)
        all_diffs.append(change)
    combined = HERE / 'evidence/candidate.diff'
    write_new(combined, b'\n'.join(all_diffs))

    # Entry is a separate integration proposal, outside this six-business-file scope.
    entry_row = next(row for row in prepared['targets'] if Path(row['target']).name == 'desktop_entry.py')
    entry_parent = Path(entry_row['candidate'])
    entry_raw = entry_parent.read_bytes()
    assert PIN(entry_raw) == {'bytes': 15900, 'sha256': '1FF419A6987C205642472CABB3E96A4F8091865AF399757EE33E36A9B034F094'}
    old_host = target_rows[0]['parent']['sha256'].encode('ascii')
    new_host = target_rows[0]['candidate_pin']['sha256'].encode('ascii')
    assert entry_raw.count(old_host) == 1
    entry_new = entry_raw.replace(old_host, new_host)
    assert len(entry_new) == len(entry_raw) and entry_new.count(new_host) == 1
    ast.parse(entry_new)
    entry_candidate = HERE / 'integration-proposals/desktop_entry.py'
    entry_diff = HERE / 'evidence/entry-HOST-only.diff'
    write_new(entry_candidate, entry_new)
    write_new(entry_diff, delta(entry_raw, entry_new, 'source50/desktop_entry.py', 'source51/desktop_entry.py'))
    entry_proposal = {'target': entry_row['target'], 'candidate': str(entry_candidate),
        'parent': PIN(entry_raw), 'candidate_pin': PIN(entry_new),
        'parent_file': file_record(entry_parent), 'diff': file_record(entry_diff),
        'only_literal': 'HOST_PINS assistant/self_operating_read.py',
        'old_sha256': old_host.decode(), 'new_sha256': new_host.decode(),
        'outside_six_business_targets': True, 'installed': False}

    # Only the public seams used by these six files, not a new 781-file inventory.
    dep_names = (
        'app.py', 'account_connections.py', 'integrations.py',
        'core/__init__.py', 'core/adapters.py', 'core/platform_reads.py',
        'core/runtime_license_policy.py', 'core/service_plans.py', 'core/wechat_channels.py',
        'wechat_channels_connection.py',
        'assistant/platform_receipt_archive.py', 'assistant/self_operating_archive.py',
        'assistant/owner_douyin_read.py', 'assistant/douyin_connection_service.py',
        'assistant/ai_workflow.py', 'assistant/ai_attempts.py', 'assistant/product_receipts.py',
        'assistant/owner_contact_handoff_package.py', 'assistant/owner_handoff_followup.py',
        'assistant/owner_company_receipt_bridge.py', 'assistant/acquisition_exports.py',
        'assistant/owner_channels_read.py', 'assistant/owner_channels_preview_archive.py',
    )
    dependencies, dependency_origin = [], []
    for name in dep_names:
        path = SOURCE / name
        raw = path.read_bytes()
        assert PIN(raw) == prior['app/src/' + name]['pin'], 'public dependency changed: ' + name
        dependencies.append(file_record(path))
        dependency_origin.append({'path': str(path), 'snapshot_input': prior['app/src/' + name]['input'],
                                  'formal_target': str(WORK / 'app/src' / name)})
    # The receiver invoked the actual public company service, with only Map SDK storage.
    company_files = ['service.cjs', 'auth.cjs', 'owner-origin-policy.cjs']
    company_dependencies = []
    cloud = WORK / 'cloud/workspace'
    for name in company_files:
        if (cloud / name).is_file():
            company_dependencies.append(file_record(cloud / name))
    # All remaining direct relative requires of the service are also small public code files.
    import re
    pending, seen = [cloud / 'service.cjs'], set()
    while pending:
        path = pending.pop()
        if path in seen:
            continue
        seen.add(path)
        text = path.read_text(encoding='utf-8')
        for relative in re.findall(r"require\(['\"](\.[^'\"]+)['\"]\)", text):
            following = (path.parent / relative).resolve()
            if not following.suffix:
                following = following.with_suffix('.cjs')
            assert following.is_relative_to(cloud.resolve()) and following.is_file()
            pending.append(following)
    company_dependencies = [file_record(path) for path in sorted(seen)]
    dependencies.extend(company_dependencies)

    revision_specs = (
        ('Dy_read', 'assistant/owner_douyin_read.py', '_SOURCES', True),
        ('Dy_storage', 'assistant/owner_douyin_source_archive.py', '_SOURCES', False),
        ('Wx_preview', 'assistant/owner_channels_read.py', '_SOURCE_FILES', True),
        ('Wx_preview_storage', 'assistant/owner_channels_preview_archive.py', '_MATERIALS', False),
    )
    revisions = []
    for label, module, const_name, sorted_keys in revision_specs:
        names = constant(module, const_name)
        def revision_at(root):
            mapping = {name: hashlib.sha256((root / name).read_bytes()).hexdigest() for name in names}
            raw = json.dumps(mapping, sort_keys=sorted_keys, ensure_ascii=False, separators=(',', ':')).encode('utf-8')
            return hashlib.sha256(raw).hexdigest(), mapping
        before, old_map = revision_at(joint / 'app/src')
        after, new_map = revision_at(SOURCE)
        revisions.append({'purpose': label, 'module': module, 'fixed_sources_constant': const_name,
            'source_files': list(names), 'digest_sort_keys': sorted_keys,
            'source50_revision': before, 'six_business_candidate_revision': after,
            'changed_paths': [name for name in names if old_map[name] != new_map[name]],
            'candidate_sha256_lower': new_map,
            'scope': 'static six-file successor only; Root must recompute after any other combined target intersects this list; no real purpose grant'})

    result_paths = [
        Path((HERE / 'evidence/LATEST-ANALYSIS.txt').read_text(encoding='utf-8').strip()),
        HERE / 'analysis-story-/a61be8f2ea5d48fdb95b9440ac1fa4ae/RECEIVER-RESULT.json',
        HERE / 'baseline-red-/2fa4c79161354eef83bd098325cc9eb4/RESULT.json',
        Path((HERE / 'evidence/LATEST-V1.txt').read_text(encoding='utf-8').strip()),
        HERE / 'evidence/FRONTEND-ROWS-RESULT.json',
        HERE / 'evidence/FIRST-V1-HARNESS-HOLD.json',
    ]
    actual = json.loads(result_paths[0].read_bytes())
    assert actual['recorded_model_dispatches'] == 2 and len(actual['events']) == 9
    assert all(row['passed'] is True for row in actual['events'])
    assert actual['real_platform_calls'] == 0 and actual['real_model_calls'] == 0
    assert actual['owned_receiver_exit_code'] == 0 and actual['owned_jobs_closed'] is True
    carrier_names = ['tests/verify_dy_owner_analysis.py', 'tests/verify_v1_and_rows.py',
        'tests/verify_source_rows.cjs', 'tests/receiver_fixture.cjs',
        'assemble_source51.py', 'apply_source51_ui.py', 'freeze_source51.py']
    failures = [file_record(path) for path in sorted((HERE / 'analysis-story-').glob('*/RESULT.json'))
                if path != result_paths[0]]
    # No own fixture DB, account config, Cookie, purpose file or session is distributed.
    frozen = {
        'schema': 'source51_dy_owner_downstream_frozen_v1',
        'scope': 'six public business successors plus one separate entry HOST literal proposal',
        'source_batch': 51, 'required_source_parent': 50,
        'target_count': 6, 'targets': target_rows, 'parents_preserved': parent_records,
        'diff': file_record(combined), 'entry_proposal': entry_proposal,
        'public_dependencies': dependencies, 'public_dependency_origin': dependency_origin,
        'source50_dependency': {
            'prepared': file_record(PREP / 'PREPARED.json'), 'frozen': file_record(frozen50),
            'public_snapshot_index': file_record(index_path), 'public_snapshot_root': str(joint),
            'public_snapshot_paths': 781,
            'overlay_existing_count': prepared['existing_source_count'],
            'overlay_new_runtime_count': prepared['new_runtime_file_count'],
            'overlay_targets': prepared['targets'],
            'runtime_root': prepared['new_runtime_root'],
            'readback_or_apply_performed_by_this_candidate': False,
            'precondition': 'Source50 actual next-open CAS and independent 55-target readback before Source51 apply; then explicit Root successor graph',
            'protected_367_rehashed': False,
        },
        'source_revision_impacts': revisions,
        'actual_evidence': [file_record(path) for path in result_paths],
        'carrier_files': [file_record(HERE / name) for name in carrier_names],
        'prior_story_results_preserved': failures,
        'final_mjs_text_delta': 'After the Green story/validator run only source group heading changed to mention Dy/XHS; tested validator function bodies unchanged; syntax checked separately.',
        'validation_scope': 'normal owned AppServer/Handler/Core/SQLite and original company createService; synthetic archive/account/purpose and recorded AI transport; Map SDK fixture; actual frontend functions in VM, not GUI',
        'boundary': {'join_authorized': False, 'independent_review_required': True,
            'Source50_applied_by_this_candidate': False, 'Source_written': False,
            'original_data_or_cookie_read': False, 'original_App_started': False,
            'real_platform_calls': 0, 'real_model_calls': 0, 'real_platform_purpose_granted': False,
            'real_customer_consent_verified': False, 'real_cloud_SDK': False,
            'real_company_send_or_payment': False, 'GUI_verified': False,
            'commercial_acceptance': False, 'v1_Dy_or_Wx_enabled': False,
            'Wx_transport_identity_promoted': False, 'runtime_or_V6_changed': False},
        'root_successors_required': [
            'Independent review of the six frozen targets and new causal evidence.',
            'Source50 actual apply/readback, then 51 exact 11-target CAS with store four and entry one; source scope added only by Root store candidate.',
            'Recompute source revision closures against the final combined candidate without creating real platform/account usage grants.',
            'Explicit Source50 helper/receipt successor or retirement; existing 55-target integrity checks cannot silently accept Source51 drift.',
            'Real account/platform identity, permissible purpose and user GUI/business acceptance remain separate, unverified.'
        ],
    }
    synopsis = ['Source51 六业务目标冻结；未合入、未启动正式 App。', '']
    for row in target_rows:
        synopsis += [row['target'], 'parent ' + json.dumps(row['parent']),
                     'candidate ' + json.dumps(row['candidate_pin']), '']
    synopsis += ['额外 entry 提案（Root 第十一目标）：', json.dumps(entry_proposal, ensure_ascii=False, indent=2),
                 '', '依赖 Source50 5 既有 + 50 新 runtime 实际 next-open/独立读回；不能先覆盖正式。',
                 '静态 source_revision 值仅本六目标叠加，Root 联合图须按实际所有目标重算；不生成真实用途批准。']
    synopsis_path = HERE / 'TARGETS-AND-CLOSURE.md'
    write_new(synopsis_path, ('\n'.join(synopsis) + '\n').encode('utf-8'))
    frozen['readme'] = file_record(HERE / 'README.md')
    frozen['targets_and_closure'] = file_record(synopsis_path)
    path = HERE / 'evidence/FROZEN.json'
    json_new(path, frozen)
    print(json.dumps({'result': 'FROZEN SIX BUSINESS + SEPARATE ENTRY',
        'frozen': file_record(path), 'targets': target_rows, 'entry': entry_proposal}, ensure_ascii=False))


if __name__ == '__main__':
    main()
