"""One causal owned HTTP/SQLite story with recorded archive and AI transport.

No account check/platform read/model is performed. Synthetic four-entity source
records start the story; all source/actor/purpose/AI ledger guards run normally.
"""
from pathlib import Path
import argparse,hashlib,http.client,json,subprocess,sys,threading,time,uuid
from copy import deepcopy
from unittest.mock import patch
from urllib.parse import urlsplit

HERE=Path(__file__).resolve().parents[1]
WORK=HERE.parent
parser=argparse.ArgumentParser();parser.add_argument('--baseline',action='store_true');args=parser.parse_args()
SOURCE=(WORK/'overnight-commercial-20261014/source50-preparation/joint/app/src') if args.baseline else HERE/'app/src'
sys.path.insert(0,str(SOURCE))
from app import AppServer
from assistant.self_operating_read import open_owner_read_instance
from assistant.owner_douyin_read import _FIXED_MATERIALS,_LIMITS,_OWNER_RUNTIME_RELATIVE,source_revision
from assistant.platform_receipt_archive import SOURCES,BATCHES,RECEIPTS,_hash
from assistant.ai_workflow import digest
from core.platform_reads import normalize_sources,_digest
import integrations
import assistant.self_operating_source_intent as intent_module

PORTS=set();SPAWNS=set()
def fence(event,values):
    if event=='socket.connect' and (values[1][0]!='127.0.0.1' or values[1][1] not in PORTS):raise PermissionError('no external transport')
    if event=='socket.getaddrinfo' and values[0] not in ('127.0.0.1','localhost'):raise PermissionError('no external DNS')
    if event=='sqlite3.connect' and not Path(values[0]).resolve().is_relative_to(HERE):raise PermissionError('only fresh owned SQLite')
    if event=='subprocess.Popen':
        command=values[1]
        if type(command) is list:command=subprocess.list2cmdline(command)
        if command not in SPAWNS:
            raise PermissionError('only fixed owned company receiver process')
sys.addaudithook(fence)

class PublicError(RuntimeError):
    def __init__(self,status,body):
        super().__init__(body.get('error','HTTP rejected'));self.status=status;self.body=body

def main():
    run=HERE/('baseline-red-' if args.baseline else 'analysis-story-')/uuid.uuid4().hex;run.mkdir(parents=True)
    events=[];actions=[];transport=[];server=None;thread=None;receiver=None;requests={};late=False;account=None;company_wire=[]
    report={'schema':'source51_dy_owner_analysis_owned_story_v1','baseline':args.baseline,
        'normal_AppServer_Handler_Core':True,'synthetic_initial_archive_records':True,
        'purpose_material_fixture_only':True,'account_check_performed':False,'real_platform_calls':0,
        'real_model_calls':0,'original_data_or_cookie_read':False,'GUI':False,
        'events':events,'HTTP_actions':actions,'recorded_transport_operations':transport}
    original_transport=integrations.request_json;original_connect=intent_module.request_json
    def recorded(url,payload,token=''):
        nonlocal late
        assert url=='https://recorded.invalid/api' and payload['environment_id']=='recorded-env'
        operation=payload['operation'];transport.append(operation)
        envelope={'contract':'fangyu-workspace-v1','environment_id':'recorded-env','company_id':'recorded-company'}
        if operation=='login':
            return {**envelope,'user':{'username':'recorded-member','role':'operator','disabled':False},
                'token':'synthetic-recorded-session','expires':time.time()+3600}
        if operation=='ai_profile':
            return {**envelope,'config':{'revision':1,'rules_version':'apartment-intent-v2','provider':'recorded-fixture','model':'recorded-fixture','reasoning_effort':'none'}}
        if operation=='intent_analyze':
            assert payload['request_id'] not in requests,'same original model key must not be dispatched again'
            requests[payload['request_id']]={'unknown':late}
            if late:
                changed=deepcopy(server.core.store.get('accounts',account['id']));changed['conn_id']='synthetic-late-connection'
                server.core.store.put('accounts',changed)
            return {**envelope,'rules_version':'apartment-intent-v2','results':[
                {'id':row['id'],'status':'graded','level':'high','reason':'原评论明确上海租房需求',
                 'evidence':['上海租房'],'region_status':'matched','content_region':'上海','key_info':[]}
                for row in payload['comments']]}
        if operation=='ai_attempt_status':
            unknown=requests[payload['request_id']]['unknown']
            return {**envelope,'request_id':payload['request_id'],'operation_kind':'intent_analyze',
                'state':'unknown' if unknown else 'succeeded','execution_confirmed':None if unknown else True,
                'execution_kind':'unknown' if unknown else 'provider_result','result_available':not unknown,
                'requires_revalidation':unknown,'reservation_retained':True,'read_only':True,
                'retry_allowed':False,'billing_verified':False}
        raise AssertionError('unrecorded operation '+operation)
    def checkpoint(name,**values):events.append({'step':name,'passed':True,**values});print(name,flush=True)
    try:
        instance=open_owner_read_instance(str(run/'instance'),HERE,
            hashlib.sha256((SOURCE/'platform_cli.py').read_bytes()).hexdigest(),product='primary_platforms_v2')
        guarded=(SOURCE.parents[1]/'guarded-cli')
        server=AppServer(('127.0.0.1',0),instance.directory/'data',employee_workspace=True,
            self_operating_instance=instance,guarded_cli_runtime=str(guarded))
        PORTS.add(server.server_port);origin='http://127.0.0.1:'+str(server.server_port);cookie=''
        def api(action,data=None):
            nonlocal cookie
            connection=http.client.HTTPConnection('127.0.0.1',server.server_port,timeout=20)
            try:
                connection.request('POST','/api',json.dumps({'action':action,'data':data or {}}),
                    {'Origin':origin,'X-Local-App':'1','Content-Type':'application/json','Cookie':cookie})
                response=connection.getresponse();body=json.loads(response.read());status=response.status
                value=response.getheader('Set-Cookie')
                if value:
                    assert 'HttpOnly' in value and 'SameSite=Strict' in value;cookie=value.split(';',1)[0]
            finally:connection.close()
            actions.append({'action':action,'operation':(data or {}).get('operation'),'product_action':(data or {}).get('action'),'status':status})
            if status!=200:raise PublicError(status,body)
            return body
        dispatch=lambda operation,data=None:api('desktop_workspace',{'operation':operation,**(data or {})})
        product=lambda action,data=None:dispatch('product_action',{'action':action,'data':data or {}})['result']
        thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
        user=server.core.store.get('users',api('personal_enter')['user']['id'])
        dispatch('workspace_state');w=server._self_operating_reads
        account=dispatch('account_create',{'name':'合成Dy归档起点','platform':'douyin','expected_uid':'765432100123'})
        account=deepcopy(server.core.store.get('accounts',account['id']));account.update(status='ready',conn_id='synthetic-recorded-connection')
        server.core.store.put('accounts',account)
        iid=instance.check()['selfOperatingRead']['instance_id'];tenant=user['tenant_id']
        def seed(cid):
            post='7654321001234567890';url='https://www.douyin.com/video/'+post
            text=('想在上海租房 预算三千 下个月入住' if cid=='100001' else
                  '上海租房 预算四千 下周入住')
            source_uid='douyin:'+_digest(['comment',post,cid]);lead_id=_hash([tenant,user['username'],source_uid]);source_id=_hash([tenant,source_uid])
            lead={'id':lead_id,'tenant_id':tenant,'cloud_owner':user['username'],'platform':'douyin','source_id':_hash(['douyin',post,cid]),
                'source_uid':source_uid,'source_type':'comment','text':text,'title':'合成上海租房公开作品','author':'合成咨询人',
                'region':'上海','published_at':'','url':url,'note_url':url,'parent_id':'','comment_id':'','author_id':'',
                'target_comment_id':'','target_author_id':'','can_reply':False,'readonly_archive':True,'reply_target_status':'not_verified',
                'privacy_redacted':False,'analysis_status':'pending','verification_status':'pending','grade':'C','created_at':time.time(),'updated_at':time.time()}
            account_digest=_digest({k:account.get(k) for k in ('id','tenant_id','cloud_owner','platform','platform_uid','conn_id')})
            source={'id':source_id,'tenant_id':tenant,'cloud_owner':user['username'],'lead_id':lead_id,'source_uid':source_uid,'platform':'douyin',
                'post_id':post,'comment_id':cid,'author_id':'','author_identity':'not_provided','original_text_hash':_hash(text),'safe_text_hash':_hash(text),
                'privacy_redacted':False,'lead_text_hash':_hash(text),'lead_source_digest':_hash({k:lead.get(k) for k in
                    ('platform','source_id','source_type','note_url','url','comment_id','author_id','target_comment_id','target_author_id')}),
                'device_id':iid,'actor_id':user['id'],'actor_role':user['role'],'account_id':account['id'],'account_uid':account['platform_uid'],
                'account_binding_digest':account_digest,'connection_digest':_digest([account['conn_id']]),'license_digest':_hash('recorded-license'),
                'input_digest':_hash(['recorded-input',cid]),'read_operation_id':_hash(['recorded-read',cid]),'created_at':time.time(),
                'reply_target_verified':False,'evidence_level':'transport_reported','real_platform_verified':False,'storage_scope':'this_device'}
            actor={k:user.get(k) for k in ('id','tenant_id','username','role','cloud_bound')};batch_id=_hash(['recorded-batch',cid]);receipt_id=_hash(['recorded-receipt',cid])
            batch={'id':batch_id,'tenant_id':tenant,'cloud_owner':user['username'],'device_id':iid,'actor':actor,'batch_digest':_hash(['recorded-batch-digest',cid]),
                'input_digest':source['input_digest'],'source_count':1,'lead_ids':[lead_id],'created_at':time.time()}
            result={k:False for k in ('reply_allowed','reply_target_verified','customer_identity_verified','auto_retry','platform_requests_started',
                'cross_machine_verified','resource_receipt_verified','real_platform_verified')}
            result.update(inserted=1,duplicate_count=0,accepted_count=1,privacy_redacted_count=0,lead_ids=[lead_id],local_only=True,storage_scope='this_device')
            scope={'schema':'local_owner_douyin_archive_v1','local_instance_id':iid,'account_id':account['id'],'account_digest':account_digest,
                'actor_digest':_digest({k:user.get(k) for k in ('id','tenant_id','username','role','cloud_bound','personal_owner')})}
            receipt={'id':receipt_id,'tenant_id':tenant,'cloud_owner':user['username'],'device_id':iid,'actor':actor,'state':'succeeded',
                'payload_digest':_hash(['recorded-payload',cid]),'batch_id':batch_id,'result':result,'local_owner_scope':scope,'created_at':time.time()}
            for entity,value in (('leads',lead),(SOURCES,source),(BATCHES,batch),(RECEIPTS,receipt)):server.core.store.put(entity,value)
            return lead_id,receipt
        lead_id,archive_receipt=seed('100001')
        selection={'lead_ids':[lead_id],'city':'上海','area':'全市','idempotency_key':'analysis_'+uuid.uuid4().hex}
        if args.baseline:
            pool=dispatch('owner_source_pool_page',{'limit':50,'cursor':None})
            assert pool['leads']==[]
            try:product('source_intent_analyze_selected',selection)
            except PublicError as error:assert error.status==400 and '小红书' in str(error)
            else:raise AssertionError('baseline unexpectedly supports owner Dy')
            checkpoint('RED: saved Dy excluded from ordinary pool and rejected by XHS-only owner analysis')
            report['result']='BASELINE GAP CONFIRMED';return
        integrations.request_json=intent_module.request_json=recorded
        product('owner_source_ai_connect',{'endpoint':'https://recorded.invalid/api','environment_id':'recorded-env','company_id':'recorded-company',
            'username':'recorded-member','password':'[REDACTED:assigned_secret]'})
        try:product('source_intent_analyze_selected',selection)
        except PublicError as error:assert error.status==400
        else:raise AssertionError('absent Dy purpose should reject analysis')
        assert not requests;checkpoint('absent Dy purpose rejects before recorded model dispatch')
        purpose={'schema':1,'purpose':'owner_douyin_connection_video_comments_v1','scope':'internal_self_use_read',
            'instance_id':iid,'company_id':server.company['id'],'source_revision':source_revision(),'runtime_relative':_OWNER_RUNTIME_RELATIVE,
            'limits':_LIMITS,'materials':list(_FIXED_MATERIALS),'decision':{'id':'synthetic_source51_material_fixture',
                'reviewer':'recorded owned QA only; not a Root/account/production grant','internal_technical_use':True,
                'production_distribution':False,'account_authorization':False,'real_platform_verified':False}}
        (instance.directory/'owner-douyin-read-review.json').write_text(json.dumps(purpose),encoding='utf-8')
        bad=deepcopy(archive_receipt);bad['local_owner_scope']['schema']='local_owner_archive_v2';server.core.store.put(RECEIPTS,bad)
        assert dispatch('owner_source_pool_page',{'limit':50,'cursor':None})['leads']==[]
        try:product('source_intent_analyze_selected',selection)
        except PublicError as error:assert error.status==400
        else:raise AssertionError('XHS proof must not be accepted as Dy')
        assert not requests;checkpoint('wrong XHS archive proof rejects both pool and analysis before model')
        server.core.store.put(RECEIPTS,archive_receipt)
        canonical_lead=deepcopy(server.core.store.get('leads',lead_id))
        canonical_source=deepcopy(server.core.store.get(SOURCES,_hash([tenant,canonical_lead['source_uid']])))
        for field,value in (('actor_id','foreign-synthetic-actor'),('device_id','0'*32),('account_id','foreign-synthetic-account')):
            changed=deepcopy(canonical_source);changed[field]=value;server.core.store.put(SOURCES,changed)
            assert dispatch('owner_source_pool_page',{'limit':50,'cursor':None})['leads']==[]
            try:product('source_intent_analyze_selected',selection)
            except PublicError as error:assert error.status==400
            else:raise AssertionError('foreign '+field+' must not be accepted')
            assert not requests;server.core.store.put(SOURCES,canonical_source)
        aliased=deepcopy(canonical_lead);aliased['platform']='xiaohongshu'
        # Same public source_id never substitutes for the full platform/uid/id
        # custody binding. Keep it unchanged while changing the platform.
        server.core.store.put('leads',aliased)
        assert dispatch('owner_source_pool_page',{'limit':50,'cursor':None})['leads']==[]
        try:product('source_intent_analyze_selected',selection)
        except PublicError as error:assert error.status==400
        else:raise AssertionError('same public source_id cannot borrow another platform')
        assert not requests;server.core.store.put('leads',canonical_lead)
        checkpoint('same public source id and foreign account / actor / instance cannot substitute complete Dy proof')
        # Preserve the canonical source digest, then retain a later deduplicated
        # successful receipt/batch whose input digest differs from that source.
        original_batch=server.core.store.get(BATCHES,archive_receipt['batch_id'])
        later_batch=deepcopy(original_batch);later_batch.update(id=_hash('recorded-later-dedupe-batch'),input_digest=_hash('recorded-later-input'))
        later_receipt=deepcopy(archive_receipt);later_receipt.update(id=_hash('recorded-later-dedupe-receipt'),batch_id=later_batch['id'],payload_digest=_hash('recorded-later-payload'))
        later_receipt['result'].update(inserted=0,duplicate_count=1)
        server.core.store.put(BATCHES,later_batch);server.core.store.put(RECEIPTS,later_receipt)
        with server.core.store.connect() as db:
            db.execute('DELETE FROM records WHERE entity=? AND id=? AND tenant_id=?',(BATCHES,original_batch['id'],tenant))
            db.execute('DELETE FROM records WHERE entity=? AND id=? AND tenant_id=?',(RECEIPTS,archive_receipt['id'],tenant))
        assert canonical_source['input_digest']!=later_batch['input_digest']
        pool=dispatch('owner_source_pool_page',{'limit':50,'cursor':None})
        if len(pool['leads'])!=1:
            source=server.core.store.get(SOURCES,_hash([tenant,server.core.store.get('leads',lead_id)['source_uid']]))
            w._douyin_archive.source_pool_item(cookie.split('=',1)[1],user,account,lead_id,source)
            raise AssertionError('pool withheld a valid canonical Dy source')
        assert pool['leads'][0]['platform']=='douyin'
        outcome=product('source_intent_analyze_selected',selection)
        assert outcome['state']=='succeeded' and outcome['analysis_complete'] is True and outcome['analyzed']==1
        assert len(requests)==1;checkpoint('normal HTTP Dy saved source enters pool and explicit analysis persists original ledger')
        checkpoint('later dedupe PRA accepted without replacing canonical source input digest')
        pool=dispatch('owner_source_pool_page',{'limit':50,'cursor':None});assert pool['leads'][0]['analysis_verified'] is True
        status=product('source_intent_analysis_status',{'idempotency_key':selection['idempotency_key']})
        assert status['state']=='succeeded' and status['original_request_id']==outcome['original_request_id']
        replay=product('source_intent_analyze_selected',selection)
        assert replay['state']=='succeeded' and replay['original_request_id']==outcome['original_request_id'] and len(requests)==1
        checkpoint('saved Dy rating / original status / same-key replay preserve one recorded model dispatch')
        later_id,_=seed('100002');later={'lead_ids':[later_id],'city':'上海','area':'全市','idempotency_key':'analysis_'+uuid.uuid4().hex};late=True
        try:product('source_intent_analyze_selected',later)
        except PublicError as error:assert error.status==500 and error.body.get('mutation_committed') is None
        else:raise AssertionError('late account change should hold result')
        assert not server.core.store.get('leads',later_id).get('ai_intent')
        count=len(requests)
        try:product('source_intent_analyze_selected',later)
        except PublicError as error:assert error.status==500
        else:raise AssertionError('unknown original key must not retry')
        assert len(requests)==count==2
        server.core.store.put('accounts',account)
        unknown=product('source_intent_analysis_status',{'idempotency_key':later['idempotency_key']})
        assert unknown['state']=='unknown' and unknown['analysis_complete'] is False and len(requests)==2
        checkpoint('late account change retains unknown original request / zero rating / no repeated model dispatch')
        # Continue the SAME successful Dy source into the mature acquisition,
        # protected contact, original package and original company bridge.
        common={'account_id':account['id'],'lead_id':lead_id};operation_key=lambda:'op_'+uuid.uuid4().hex
        locator=product('owner_source_locator_get',common)
        assert locator['canonical_url']=='https://www.douyin.com/video/7654321001234567890'
        processing=product('owner_source_processing_detail',common|{'limit':20,'cursor':None})
        assert processing['source']['platform']=='douyin'
        consent={'status':'granted','evidence_reference':'consent:'+uuid.uuid4().hex,'notice_version':'notice_v1'}
        contact_body=common|{'recipient_id':'resource_department','purpose':'租房咨询对接','consent':consent,
            'phone':'[REDACTED:phone_cn]','wechat':'SyntheticWX123','voluntarily_provided':True,'idempotency_key':operation_key()}
        invalid=deepcopy(later_receipt);invalid['local_owner_scope']['schema']='local_owner_archive_v2'
        server.core.store.put(RECEIPTS,invalid)
        before_contacts=len(server.core.store.list('acquisition_contacts',tenant))
        try:product('contact_create',contact_body)
        except PublicError as error:assert error.status==400
        else:raise AssertionError('Dy contact must not borrow XHS proof')
        assert len(server.core.store.list('acquisition_contacts',tenant))==before_contacts
        server.core.store.put(RECEIPTS,later_receipt)
        contact=product('contact_create',contact_body);reference=contact['result']['contact_reference'];handoff_key=operation_key()
        draft=product('handoff_create',common|{'recipient_id':'resource_department','purpose':'租房咨询对接',
            'consent':consent,'contact_reference':reference,'idempotency_key':handoff_key})
        history=product('owner_acquisition_history_detail',{'operation_id':draft['operation']['operation_id']})
        assert history['source']['platform']=='douyin'
        package=product('owner_handoff_package_create',{'drafts':[common|{'operation_id':draft['operation']['operation_id'],
            'draft_id':draft['result']['item']['id'],'handoff_key':handoff_key}],
            'recipient_id':'resource_department','purpose':'租房咨询对接','idempotency_key':operation_key(),'confirmed':True})
        assert package['state']=='succeeded'
        checkpoint('same analyzed Dy source / canonical locator / history / protected voluntary contact / original package')
        config={'instance_id':package['instance_id'],
            'local_recipient_label_digest':hashlib.sha256(package['recipient_id'].encode()).hexdigest(),
            'local_purpose_digest':hashlib.sha256(package['handoff_purpose'].encode()).hexdigest()}
        (run/'NODE-INPUT.json').write_text(json.dumps(config),encoding='utf-8')
        receiver_command=['C:/Program Files/nodejs/node.exe',str(HERE/'tests/receiver_fixture.cjs'),
            str(WORK/'cloud/workspace'),str(run/'NODE-INPUT.json'),str(run/'RECEIVER-RESULT.json')]
        assert all(Path(value).resolve().is_relative_to(HERE) for value in receiver_command[3:])
        SPAWNS.add(subprocess.list2cmdline(receiver_command))
        receiver=subprocess.Popen(receiver_command,
            stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,encoding='utf-8',creationflags=subprocess.CREATE_NO_WINDOW)
        ready_line=receiver.stdout.readline()
        if not ready_line:raise AssertionError('owned receiver bootstrap failed: '+receiver.stderr.read())
        ready=json.loads(ready_line);address=urlsplit(ready['url']);PORTS.add(address.port);remote='https://recorded.invalid/workspace'
        def wire(expected,payload,remote_token=''):
            assert expected==remote
            connection=http.client.HTTPConnection('127.0.0.1',address.port,timeout=15)
            try:
                connection.request('POST','/api',json.dumps(payload),{'Content-Type':'application/json','Authorization':'Bearer '+remote_token})
                response=connection.getresponse();body=json.loads(response.read());status=response.status
            finally:connection.close()
            company_wire.append({'operation':payload['operation'],'status':status})
            if status!=200:raise integrations.IntegrationError('owned company refused')
            return body
        with patch('integrations.request_json',wire):
            connected=product('owner_company_receipt_login',{'package_id':package['package_id'],'company_id':'fangyu-apartment-client',
                'admission_id':ready['admission_id'],'username':'synthetic-partner','password':'[REDACTED:assigned_secret]',
                'endpoint':remote,'environment_id':ready['environment_id']})
            assert connected['scope']['kind']=='owner_origin_only_v1'
            detail=product('owner_handoff_followup_detail',{'package_id':package['package_id']})
            row={'package_id':package['package_id'],'row_id':detail['rows'][0]['row_id']}
            company=lambda name,extra=None:product('owner_company_receipt_'+name,row|(extra or {}))
            company('register',{'idempotency_key':hashlib.sha256(b'source51-Dy-register').hexdigest()})
            synced=company('consent_sync',{'expected_consent_version':0,'idempotency_key':hashlib.sha256(b'source51-Dy-sync').hexdigest()})
            submitted=company('submit',{'expected_revision':synced['item']['revision'],
                'expected_consent_version':synced['item']['consent']['version'],'idempotency_key':hashlib.sha256(b'source51-Dy-submit').hexdigest()})
            assert submitted['item']['status']=='submitted'
            receiver_login=wire(remote,{'environment_id':ready['environment_id'],'operation':'login',
                'username':'synthetic-receiver','password':'[REDACTED:assigned_secret]'});receiver_token=receiver_login['token']
            assert receiver_login['user']['role']=='operator'
            accepted=wire(remote,{'environment_id':ready['environment_id'],'operation':'acquisition_handoff_receipt',
                'channel_id':submitted['item']['channel_id'],'expected_revision':submitted['item']['revision'],
                'idempotency_key':operation_key(),'decision':'accept','evidence_reference':'evidence:'+uuid.uuid4().hex},receiver_token)
            ack=company('channel_get');assert ack['item']['status']=='accepted'
            assert accepted['item']['receipt']['authenticated_receiver_decision'] is True
            assert ack['remote_original_package_verified'] is False and ack['financial_receipt_verified'] is False
            product('contact_revoke',common|{'contact_reference':reference,'expected_revision':1,'idempotency_key':operation_key()})
            withdrawn=company('withdraw',{'expected_consent_version':ack['item']['consent']['version'],
                'idempotency_key':hashlib.sha256(b'source51-Dy-withdraw').hexdigest()})
            assert withdrawn['item']['status']=='withdrawn'
            assert sum(row['operation']=='owner_origin_submit' for row in company_wire)==1
        checkpoint('same Dy original package / real local company single submit / another operator ACK / withdrawal')
        report.update(result='PASS OWNED HTTP + SYNTHETIC ARCHIVE + RECORDED AI',recorded_model_dispatches=len(requests),
            original_success_request=outcome['original_request_id'],original_unknown_request=unknown['original_request_id'],
            company_HTTP_operations=company_wire,real_company_service_createService=True,cloud_SDK='Map transaction fixture',
            real_platform_purpose_or_account_authorization=False,real_customer_consent_or_financial_verified=False)
    except Exception as error:
        report.update(result='FAILED',error_type=type(error).__name__,error=str(error));raise
    finally:
        integrations.request_json=original_transport;intent_module.request_json=original_connect
        if server is not None:
            report['owned_jobs_closed']=server.close_owned_jobs();server.shutdown();server.server_close()
        if thread is not None:thread.join(timeout=10);report['server_thread_closed']=not thread.is_alive()
        if receiver is not None:
            receiver.communicate('STOP\n',timeout=15);report['owned_receiver_exit_code']=receiver.returncode
        output=run/'RESULT.json';output.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
        (HERE/'evidence/LATEST-ANALYSIS.txt').write_text(str(output)+'\n',encoding='utf-8')
        print(json.dumps({'result':report.get('result'),'recorded_model_dispatches':len(requests),'report':str(output)},ensure_ascii=False))

if __name__=='__main__':main()
