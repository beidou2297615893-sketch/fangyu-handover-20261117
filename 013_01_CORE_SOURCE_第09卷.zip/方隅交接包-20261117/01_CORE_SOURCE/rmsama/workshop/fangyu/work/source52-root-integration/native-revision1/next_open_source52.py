"""Root Source52 successor candidate. No action at import; no reviewed authority yet."""
import json,os,sys,types
from pathlib import Path
PROJECT=Path('C:/积木软件工坊/项目/方隅公寓客户版')
WORK=PROJECT/'work'
AUDITS=WORK/'product-upgrade-20261009/audits'
OWN=WORK/'source52-root-integration'
ENTRY=WORK/'desktop-self-use-entry/desktop_entry.py'
PILOT=WORK/'self-operating-pilot'
PREPARED=OWN/'PREPARED.json'
MANIFEST=AUDITS/'source52-manifest.json'
APPROVAL=AUDITS/'source52-final-root-read.json'
JOIN=AUDITS/'join-source52-reviewed.py'
RECEIPT=AUDITS/'source52-joined.json'
STARTED=AUDITS/'source52-next-open-started.json'
FAILED=AUDITS/'source52-join-failed.json'
GUARD=OWN/'source_idle_guard.py'
GUARD_PIN={'bytes': 5136, 'sha256': 'F33EAD3479444187CE79DD12BDD32ADDC9E5AB653A5C0887FAEF809A12A98F3D'}
BASE_PREPARED=WORK/'source51-root-integration/PREPARED.json'
PRIOR_PREPARED=WORK/'overnight-commercial-20261014/source50-preparation/PREPARED.json'
INSTANCE_ID='d075ac9c039e44038ddbc6f3e753d73c'
BASE_MANIFEST_PIN={'bytes':160775,'sha256':'7E9ACEC49AAF60D216A05F57B4C640348948CD501FEA6527F2B30391B232BB10'}
JOIN_AUTHORIZED=False
MANIFEST_PIN=None
TARGET_RELATIVE=('cloud/workspace/service.cjs','app/src/web/workspace/member-admin-ui.mjs',
 'owner-admin-20261004/site/member-admin-ui.mjs','app/src/web/workspace/app.mjs',
 'app/src/web/workspace/index.html','owner-admin-20261004/owner_admin.py',
 'owner-admin-20261004/site/index.html','app/src/assistant/employee_workspace.py',
 'app/src/web/workspace/local-transport.mjs')

def _proof(value):
    return (type(value) is dict and set(value)=={'bytes','sha256'}
        and type(value['bytes']) is int and value['bytes']>0
        and type(value['sha256']) is str and len(value['sha256'])==64
        and all(c in '0123456789ABCDEF' for c in value['sha256']))

def _plan(legacy,successor):
    if JOIN_AUTHORIZED is not True or not _proof(MANIFEST_PIN) or not _proof(GUARD_PIN):
        raise ValueError('Source52 reviewed fixed authority absent')
    base,prior=successor._plan(legacy)
    if successor.MANIFEST_PIN!=BASE_MANIFEST_PIN:raise ValueError('fixed Source51 predecessor changed')
    manifest=json.loads(legacy.expected(MANIFEST,MANIFEST_PIN))
    if (manifest.get('schema')!='source52_next_open_manifest_v1' or manifest.get('source_batch')!=52
        or manifest.get('join_authorized') is not True or manifest.get('instance_id')!=INSTANCE_ID
        or manifest.get('base_manifest_pin')!=BASE_MANIFEST_PIN or not _proof(manifest.get('approval_pin'))
        or not _proof(manifest.get('join_script_pin')) or manifest.get('source_guard_pin')!=GUARD_PIN):
        raise ValueError('fixed Source52 authority changed')
    gate=json.loads(legacy.expected(APPROVAL,manifest['approval_pin']))
    if (gate.get('schema')!='source52_final_root_read' or gate.get('source_batch')!=52
        or gate.get('join_authorized') is not True or gate.get('base_manifest_pin')!=BASE_MANIFEST_PIN
        or any(gate.get(x) is not True for x in ('independent_code_review_passed',
            'independent_actual_qa_review_passed','join_script_review_passed','next_normal_open_only'))
        or any(gate.get(x) is not False for x in ('customer_database_opened','session_copied','deployment_or_packaging_performed'))
        or gate.get('join_script_pin')!=manifest['join_script_pin'] or gate.get('source_guard_pin')!=GUARD_PIN
        or not _proof(gate.get('prepared_manifest_pin'))):
        raise ValueError('Source52 Root reviewed gate changed')
    prepared=json.loads(legacy.expected(PREPARED,gate['prepared_manifest_pin']))
    if (prepared.get('schema')!='source52_owner_prepared_v1' or prepared.get('source_batch')!=52
        or prepared.get('join_authorized') is not False or prepared.get('instance_id')!=INSTANCE_ID
        or prepared.get('base_manifest_pin')!=BASE_MANIFEST_PIN or prepared.get('new_directories')!=[]):
        raise ValueError('Source52 reviewed prepared graph changed')
    rows=manifest.get('targets');stored=prepared.get('targets')
    if (type(rows) is not list or len(rows)!=9 or type(stored) is not list or len(stored)!=9
        or any(type(x) is not dict or set(x)!={'path','parent_pin','final_pin'}
            or not _proof(x['parent_pin']) or not _proof(x['final_pin']) for x in rows)
        or len({x['path'] for x in rows})!=9
        or {Path(x['path']) for x in rows}!={WORK/x for x in TARGET_RELATIVE}
        or {Path(x['target']):(x['parent'],x['candidate_pin']) for x in stored}
            !={Path(x['path']):(x['parent_pin'],x['final_pin']) for x in rows}):
        raise ValueError('Source52 exact nine parent/final graph changed')
    protected=manifest.get('protected')
    if (type(protected) is not list or protected!=prepared.get('protected')
        or any(type(x) is not dict or set(x)!={'path','pin'} or not _proof(x['pin']) for x in protected)
        or len({Path(x['path']) for x in protected})!=len(protected)
        or {WORK/x for x in TARGET_RELATIVE}&{Path(x['path']) for x in protected}):
        raise ValueError('Source52 exact protection graph changed')
    legacy.expected(JOIN,manifest['join_script_pin']);legacy.expected(GUARD,GUARD_PIN)
    return manifest,base,prior

def _layer(legacy,batch,authority,authority_pin,gate_path,prepared_path,receipt_path):
    """Validate immutable raw authority, preparation and receipt, without current-source assumptions."""
    gate=json.loads(legacy.expected(gate_path,authority['approval_pin']))
    prepared=json.loads(legacy.expected(prepared_path,gate['prepared_manifest_pin']))
    if (prepared.get('schema')!=f'source{batch}_owner_prepared_v1' or prepared.get('source_batch')!=batch
        or prepared.get('join_authorized') is not False or prepared.get('instance_id')!=INSTANCE_ID):
        raise ValueError('ancestor prepared metadata changed')
    raw=legacy.blob(receipt_path);receipt=json.loads(raw)
    if (receipt.get('schema')!=f'source{batch}_owner_joined_v1' or receipt.get('source_batch')!=batch
        or receipt.get('approval_sha256')!=authority['approval_pin']['sha256']
        or receipt.get('authority_manifest_pin')!=authority_pin
        or receipt.get('prepared_manifest_pin')!=gate['prepared_manifest_pin']
        or receipt.get('protected')!=prepared.get('protected')
        or any(receipt.get(x) is not False for x in ('App_restarted','marker_changed',
            'customer_database_opened','session_copied','deployed','real_GUI_verified','commercial_complete'))):
        raise ValueError('actual original ancestor success receipt changed')
    prep=prepared.get('targets');rows=receipt.get('targets')
    if (type(prep) is not list or type(rows) is not list or len(rows)!=len(prep)
        or len({x['target'] for x in prep})!=len(prep)
        or any(type(x) is not dict or set(x)!={'target','parent','candidate','backup'} for x in rows)
        or len({x['target'] for x in rows})!=len(rows)):
        raise ValueError('ancestor target record set changed')
    targets={Path(x['target']):x for x in prep};records={Path(x['target']):x for x in rows}
    final={Path(x['path']):x['final_pin'] for x in authority['targets']}
    if set(targets)!=set(records) or {p:x['candidate_pin'] for p,x in targets.items()}!=final:
        raise ValueError('ancestor final graph changed')
    if batch>=51:
        if receipt.get('new_directories')!=[] or authority.get('protected')!=prepared['protected']:
            raise ValueError('successor directory/protection metadata changed')
        if {Path(x['path']):x['parent_pin'] for x in authority['targets']}!={p:x['parent'] for p,x in targets.items()}:
            raise ValueError('successor original parent graph changed')
    root=Path(receipt['backup']);relative=root.relative_to(PROJECT/f'backups/source{batch}-owner')
    if (len(relative.parts)!=1 or len(relative.name)!=32
        or any(c not in '0123456789abcdef' for c in relative.name)):
        raise ValueError('ancestor backup root changed')
    # Validate all original parent backups, not an alternate batch's plausible path.
    for path,row in records.items():
        pin=targets[path]['parent']
        if row['parent']!=pin or row['candidate']!=final[path]:raise ValueError('ancestor target pin changed')
        if pin is None:
            if row['backup'] is not None:raise ValueError('new target falsely has original parent')
        else:
            backup=root/path.relative_to(WORK)
            if row['backup']!=str(backup):raise ValueError('ancestor backup address changed')
            legacy.expected(backup,pin)
    return raw,receipt,records,final,prepared['protected']

def _readback(legacy,successor,manifest,base,prior):
    """50 through 51 backups; 51 through 52 backups; 52 remains the current exact bytes."""
    if any(os.path.lexists(x) for x in (FAILED,successor.FAILED,legacy.PROJECT/'work/product-upgrade-20261009/audits/source50-join-failed.json')):
        raise ValueError('original failure evidence requires Root recovery')
    p_raw,p_receipt,p_records,p_final,p_protected=_layer(legacy,50,prior,legacy.ROOT_MANIFEST_PIN,
        legacy.APPROVAL,PRIOR_PREPARED,legacy.RECEIPT)
    b_raw,b_receipt,b_records,b_final,b_protected=_layer(legacy,51,base,BASE_MANIFEST_PIN,
        successor.APPROVAL,BASE_PREPARED,successor.RECEIPT)
    raw,receipt,records,final,protected=_layer(legacy,52,manifest,MANIFEST_PIN,APPROVAL,PREPARED,RECEIPT)
    if b_receipt.get('base_receipt_pin')!=legacy.pin(p_raw) or receipt.get('base_receipt_pin')!=legacy.pin(b_raw):
        raise ValueError('original raw receipt lineage changed')
    def old_bytes(path,proof,overlays):
        for overlay in overlays:
            if path in overlay:
                row=overlay[path]
                if row['parent']!=proof or row['backup'] is None:raise ValueError('original layer overlay parent changed')
                legacy.expected(Path(row['backup']),proof);return
        legacy.expected(path,proof)
    for path,proof in list(p_final.items())+[(Path(x['path']),x['pin']) for x in p_protected]:
        old_bytes(path,proof,(b_records,records))
    for path,proof in list(b_final.items())+[(Path(x['path']),x['pin']) for x in b_protected]:
        old_bytes(path,proof,(records,))
    for path,proof in final.items():legacy.expected(path,proof)
    for row in protected:legacy.expected(Path(row['path']),row['pin'])
    return legacy.pin(raw)

def _source_idle(legacy,phase):
    if not _proof(GUARD_PIN):raise ValueError('fixed source guard absent')
    raw=legacy.expected(GUARD,GUARD_PIN)
    module=types.ModuleType('source52_fixed_source_guard')
    module.__file__=str(GUARD)
    exec(compile(raw,str(GUARD),'exec'),module.__dict__)
    result=module.source_state(os.getpid())
    if (type(result) is not dict or result.get('state')!='idle'
        or result.get('scope')!='fangyu_customer_source_metadata_v1'):
        raise ValueError('customer source live or unknown at '+phase)
    return result

def _start_once(legacy,manifest,base_pin):
    if any(os.path.lexists(x) for x in (STARTED,FAILED,RECEIPT)):raise ValueError('original Source52 invocation requires Root recovery')
    value={'schema':'source52_next_open_started_v1','source_batch':52,'instance_id':INSTANCE_ID,
        'approval_sha256':manifest['approval_pin']['sha256'],'manifest_pin':MANIFEST_PIN,
        'base_receipt_pin':base_pin,'pid':os.getpid(),'auto_retry':False}
    temporary=legacy.prepared_temp(STARTED,(json.dumps(value,ensure_ascii=False,sort_keys=True)+'\n').encode('utf-8'))
    try:os.rename(temporary,STARTED)
    finally:temporary.unlink(missing_ok=True)

def reviewed_entry_pin_if_joined(legacy,successor):
    """Metadata only, no process/source guard query, lock, apply or business import."""
    manifest,base,prior=_plan(legacy,successor)
    if os.path.lexists(RECEIPT):
        _readback(legacy,successor,manifest,base,prior)
        return next(x['final_pin'] for x in base['targets'] if Path(x['path'])==ENTRY)
    if os.path.lexists(STARTED) or os.path.lexists(FAILED):raise ValueError('original Source52 invocation has no verified success')
    return successor.reviewed_entry_pin_if_joined(legacy)

def before_normal_open(entry,legacy,successor):
    held={'decision':'held','source_mutations':0,'automatic_retry':False}
    if (os.name!='nt' or getattr(sys,'frozen',False) or Path(entry.__file__)!=ENTRY or entry.PILOT!=PILOT):return held
    invoked=False
    try:
        report=entry.preflight()
        if report.get('state')!='ready_for_original_native_main' or report.get('instance_id')!=INSTANCE_ID:return held
        manifest,base,prior=_plan(legacy,successor)
        if os.path.lexists(RECEIPT):
            _readback(legacy,successor,manifest,base,prior)
            return {'decision':'continue','source_mutations':0,'automatic_retry':False}
        if any(os.path.lexists(x) for x in (STARTED,FAILED,successor.FAILED,successor.BASE_FAILED)):return held
        with legacy._exclusive_existing_lock(entry):
            again=entry.preflight()
            if again.get('state')!='ready_for_original_native_main' or again.get('instance_id')!=INSTANCE_ID:return held
            manifest,base,prior=_plan(legacy,successor)
            _source_idle(legacy,'before_source_chain')
            if not os.path.lexists(legacy.RECEIPT):
                if os.path.lexists(legacy.STARTED):return held
                legacy._start_once(prior);invoked=True
                successor._invoke(legacy,legacy.JOIN,prior['join_script_pin'],prior['approval_pin']['sha256'])
            # Never rerun legacy current-50 readback after a verified 51 overlay.
            if not os.path.lexists(successor.RECEIPT):
                if os.path.lexists(successor.STARTED):return {**held,'source_mutations':None if invoked else 0,'join_invoked':invoked}
                legacy._readback(prior)
                prior_pin=successor._base_receipt(legacy,base,prior,False)
                successor._start_once(legacy,base,prior_pin);invoked=True
                successor._invoke(legacy,successor.JOIN,base['join_script_pin'],base['approval_pin']['sha256'])
            successor._readback(legacy,base,prior)
            base_pin=legacy.pin(legacy.blob(successor.RECEIPT))
            _source_idle(legacy,'before_source52_started')
            _start_once(legacy,manifest,base_pin);invoked=True
            successor._invoke(legacy,JOIN,manifest['join_script_pin'],manifest['approval_pin']['sha256'])
            _readback(legacy,successor,manifest,base,prior)
        os.execv(sys.executable,[sys.executable,'-X','utf8','-B','-I',str(ENTRY)])
        return {**held,'source_mutations':None,'join_invoked':True}
    except Exception:
        return {**held,'source_mutations':None if invoked else 0,'join_invoked':invoked}
