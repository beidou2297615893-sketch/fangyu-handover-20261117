"""Preserve drafts; add required predecessor backups before first 52 mutation."""
import ast,hashlib,json
from pathlib import Path
OWN=Path('C:/积木软件工坊/项目/方隅公寓客户版/work/source52-root-integration')
def pin(raw):return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest().upper()}
snapshot=OWN/'native-revision2';snapshot.mkdir()
for name in ('join-source52-reviewed.py','next_open_source52.py','source_idle_guard.py','source_next_open_launcher.py','NATIVE-GUARD-REVISION.json'):
    with (snapshot/name).open('xb') as stream:stream.write((OWN/name).read_bytes())
path=OWN/'source_idle_guard.py';guard=path.read_text(encoding='utf-8')
needle="ambiguous=f'{runtimes} AND (CommandLine IS NULL OR '+ ' OR '.join(names)+')'"
replacement="""blanks=['CommandLine = '+_wql_like('')]
    blanks.extend('CommandLine LIKE '+_wql_like(x+'%') for x in (' ', '\\t', '\\r', '\\n', '\\v', '\\f'))
    ambiguous=f'{runtimes} AND (CommandLine IS NULL OR '+ ' OR '.join(blanks+names)+')'"""
if guard.count(needle)!=1:raise ValueError('guard empty-line anchor changed')
guard=guard.replace(needle,replacement,1);ast.parse(guard);path.write_text(guard,encoding='utf-8',newline='\n')
guard_pin=pin(path.read_bytes())
for name,key in (('join-source52-reviewed.py','SOURCE_GUARD_PIN'),('next_open_source52.py','GUARD_PIN')):
    path=OWN/name;lines=path.read_text(encoding='utf-8').splitlines(keepends=True)
    found=0
    for i,line in enumerate(lines):
        if line.startswith(key+'='):lines[i]=key+'='+repr(guard_pin)+'\n';found+=1
    if found!=1:raise ValueError('fixed guard binding anchor changed')
    text=''.join(lines)
    if name.startswith('next_open'):
        at='\ndef _readback(legacy,successor,manifest,base,prior):'
        body='''
def _predecessor_backups(legacy,successor,base,prior):
    # The original 51 current-byte readback is not proof that its backups still
    # exist. Validate those physical original parents before writing 52 STARTED.
    p_raw,_,_,_,_=_layer(legacy,50,prior,legacy.ROOT_MANIFEST_PIN,
        legacy.APPROVAL,PRIOR_PREPARED,legacy.RECEIPT)
    b_raw,b_receipt,_,_,_=_layer(legacy,51,base,BASE_MANIFEST_PIN,
        successor.APPROVAL,BASE_PREPARED,successor.RECEIPT)
    if b_receipt.get('base_receipt_pin')!=legacy.pin(p_raw):raise ValueError('original predecessor raw lineage changed')
    return legacy.pin(b_raw)

'''
        if text.count(at)!=1:raise ValueError('helper predecessor function anchor changed')
        text=text.replace(at,'\n'+body+at,1)
        text=text.replace("base_pin=legacy.pin(legacy.blob(successor.RECEIPT))", "base_pin=_predecessor_backups(legacy,successor,base,prior)",1)
    else:
        at='\ndef source50_ancestor():'
        body='''
def verified_original_backups(receipt,parents,batch):
    root=Path(receipt['backup']);relative=root.relative_to(PROJECT/f'backups/source{batch}-owner')
    if (len(relative.parts)!=1 or len(relative.name)!=32
        or any(c not in '0123456789abcdef' for c in relative.name)):
        raise ValueError('original predecessor backup root changed')
    for row in receipt['targets']:
        target=Path(row['target']);value=parents[target]
        if row.get('parent')!=value:raise ValueError('original predecessor parent changed')
        if value is None:
            if row.get('backup') is not None:raise ValueError('new target has false original parent')
        else:
            backup=root/target.relative_to(WORK)
            if row.get('backup')!=str(backup):raise ValueError('original predecessor backup address changed')
            expected(backup,value)

'''
        if text.count(at)!=1:raise ValueError('CAS backup function anchor changed')
        text=text.replace(at,'\n'+body+at,1)
        text=text.replace("return raw,finals,prepared['protected']", "parents={Path(row['target']):row['parent'] for row in prepared['targets']}\n    if set(parents)!=set(finals):raise ValueError('original fifty parent graph changed')\n    verified_original_backups(receipt,parents,50)\n    return raw,finals,prepared['protected']",1)
        text=text.replace("prior_raw,prior_finals,prior_protected=source50_ancestor()", "verified_original_backups(receipt,parents,51)\n    prior_raw,prior_finals,prior_protected=source50_ancestor()",1)
        text=text.replace("require_source_idle('before_replace')", "require_source_idle('before_replace')\n            expected(BASE_RECEIPT,base_pin)\n            verified_original_backups(json.loads(blob(BASE_RECEIPT)),{path:row[0] for path,row in finals.items() if path in base_finals},51)" ,0) if False else text
        # Original predecessor rows and parents come from the immutable base
        # authority. Re-run that exact proof immediately before replacement,
        # never substitute the nine 52 parents for the eleven 51 parents.
        text=text.replace("require_source_idle('before_replace')", "require_source_idle('before_replace')\n            predecessor=json.loads(expected(BASE_RECEIPT,base_pin))\n            base_authority=json.loads(expected(BASE_AUTHORITY,BASE_MANIFEST_PIN))\n            verified_original_backups(predecessor,{Path(row['path']):row['parent_pin'] for row in base_authority['targets']},51)\n            source50_ancestor()",1)
    ast.parse(text);path.write_text(text,encoding='utf-8',newline='\n')
result={'schema':'source52_root_native_predecessor_revision_v1','source_guard':guard_pin,
 'CAS':pin((OWN/'join-source52-reviewed.py').read_bytes()),'helper':pin((OWN/'next_open_source52.py').read_bytes()),
 'launcher':pin((OWN/'source_next_open_launcher.py').read_bytes()),'prepared':pin((OWN/'PREPARED.json').read_bytes()),
 'join_authorized':False,'manifest_pin':None,'formal_mutations':0,'actual_process_queries':0,'native_story_run':False}
with (OWN/'NATIVE-PREDECESSOR-REVISION.json').open('x',encoding='utf-8') as stream:stream.write(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(result,ensure_ascii=False))
