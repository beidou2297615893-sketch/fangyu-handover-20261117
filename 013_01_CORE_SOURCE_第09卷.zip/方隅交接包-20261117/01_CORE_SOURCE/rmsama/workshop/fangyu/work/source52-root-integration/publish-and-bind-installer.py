"""Root publishes approved source authority, then binds only the reviewed two-thin installer."""
import ast,hashlib,json,os
from pathlib import Path
PROJECT=Path('C:/积木软件工坊/项目/方隅公寓客户版')
WORK=PROJECT/'work';OWN=WORK/'source52-root-integration';AUDITS=WORK/'product-upgrade-20261009/audits'
PUBLISH_AUTHORIZED=True
FINAL_PEER_PIN={'bytes':4539,'sha256':'5760E4A2D10E2C7F40CF50EFB6AB8662B73AA789DA698FE37E55C46EA27F006D'}
GRAPH_PIN={'bytes':3306,'sha256':'66A2C256FC8C31278F7C0354AC6A69DD3D0D9EE5BB102E0B21266D206E86ABEA'}
PEER=WORK/'source52-independent-review/FINAL-NATIVE-REVIEW.md'
def pin(raw):return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest().upper()}
def exact(path,proof):
    raw=path.read_bytes()
    if pin(raw)!=proof:raise ValueError('fixed publication input changed')
    return raw
if PUBLISH_AUTHORIZED is not True or type(FINAL_PEER_PIN) is not dict:raise ValueError('Root final peer acceptance absent')
exact(PEER,FINAL_PEER_PIN)
graph=json.loads(exact(OWN/'FINAL-GRAPH.json',GRAPH_PIN))
if graph['schema']!='source52_root_final_graph_uninstalled_v1' or graph['targets']!=9 or graph['protected']!=462:raise ValueError('fixed final graph scope changed')
files=[(OWN/'join-source52-reviewed-final.py',AUDITS/'join-source52-reviewed.py',graph['CAS_pin']),
 (OWN/'authority-stage/source52-final-root-read.json',AUDITS/'source52-final-root-read.json',graph['gate_pin']),
 (OWN/'authority-stage/source52-manifest.json',AUDITS/'source52-manifest.json',graph['manifest_pin'])]
# The mature helpers perform ordinary ancestor/file checks for every public copy.
raw=exact(AUDITS/'join-source44-reviewed.py',{'bytes':9601,'sha256':'5F5E3EA22AF7C1FA0FEA71CFEFDA12A9D669C190D5470960901029BF8F4750FB'})
names={'blob','expected','no_link_parent','prepared_temp','pin'}
nodes=[x for x in ast.parse(raw).body if isinstance(x,ast.FunctionDef) and x.name in names]
import stat,tempfile
exec(compile(ast.Module(body=nodes,type_ignores=[]),'fixed-source44-public-promotion','exec'),globals())
payloads=[]
for source,target,proof in files:
    no_link_parent(target)
    if os.path.lexists(target):raise ValueError('original Source52 authority path already present; no automatic overwrite')
    payloads.append((target,expected(source,proof),proof))
for target,raw,proof in payloads:
    temporary=prepared_temp(target,raw)
    try:os.rename(temporary,target);expected(target,proof)
    finally:temporary.unlink(missing_ok=True)
installer=exact(OWN/'install_native.py',{'bytes':8555,'sha256':'E365AFAD4AD3E1E7C45A5882652983AC6A88A6ED3243E8BDBE43A1B9ACB74378'}).decode('utf-8')
values={'PEER_PIN':FINAL_PEER_PIN,'GRAPH_PIN':GRAPH_PIN,'HELPER_PIN':graph['helper_candidate_pin'],
 'LAUNCHER_PIN':graph['launcher_candidate_pin'],'INSTALL_AUTHORIZED':True}
lines=installer.splitlines(keepends=True);found=set()
for i,line in enumerate(lines):
    if '=' not in line:continue
    key=line.split('=',1)[0]
    if key in values:
        if key in found:raise ValueError('duplicate installer fixed binding')
        current=ast.literal_eval(line.split('=',1)[1])
        if current is not (False if key=='INSTALL_AUTHORIZED' else None):raise ValueError('installer staged literal changed')
        lines[i]=key+'='+repr(values[key])+'\n';found.add(key)
if found!=set(values):raise ValueError('installer fixed binding set changed')
bound=''.join(lines).encode('utf-8');ast.parse(bound)
with (OWN/'install-native-authorized.py').open('xb') as stream:stream.write(bound)
receipt={'schema':'source52_authority_published_v1','source_batch':52,'graph_pin':GRAPH_PIN,'final_peer_pin':FINAL_PEER_PIN,
 'files':[{'path':str(path),'pin':proof} for _,path,proof in files],'bound_installer_pin':pin(bound),
 'thin_files_installed':False,'business_apply_calls':0,'source_or_private_data_mutations':0}
with (OWN/'AUTHORITY-PUBLISHED.json').open('x',encoding='utf-8') as stream:stream.write(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'published_public_authority_files':3,'bound_installer':pin(bound),'thin_files_installed':False,'business_apply_calls':0},ensure_ascii=False))
