"""Preserve first installer draft and close the three exact byte/path gaps."""
import ast,hashlib,json
from pathlib import Path
OWN=Path('C:/积木软件工坊/项目/方隅公寓客户版/work/source52-root-integration')
path=OWN/'install_native.py';raw=path.read_bytes()
def pin(value):return {'bytes':len(value),'sha256':hashlib.sha256(value).hexdigest().upper()}
if pin(raw)!={'bytes':8293,'sha256':'B3C0FD2095237BCE1636611E16A746B62333623AF9995EF57F63609264F50E3A'}:raise ValueError('first installer changed')
snapshot=OWN/'install-revision1';snapshot.mkdir()
with (snapshot/'install_native.py').open('xb') as stream:stream.write(raw)
text=raw.decode('utf-8')
old="backup=PROJECT/'backups/source52-native'/uuid.uuid4().hex\n    no_link_parent(backup.parent);backup.mkdir(parents=True)"
new="backup_base=PROJECT/'backups/source52-native'\n    no_link_parent(backup_base);backup_base.mkdir(exist_ok=True)\n    backup=backup_base/uuid.uuid4().hex\n    no_link_parent(backup);backup.mkdir()"
if text.count(old)!=1:raise ValueError('backup path anchor changed')
text=text.replace(old,new,1)
text=text.replace("if before is None:target.unlink()", "if before is None:\n                    no_link_parent(target);expected(target,row['final']);target.unlink()",1)
text=text.replace("absent()\n        value={'schema'", "absent()\n        for row,_,_ in changes:\n            no_link_parent(row['target']);expected(row['target'],row['final'])\n        value={'schema'",1)
ast.parse(text);path.write_text(text,encoding='utf-8',newline='\n')
result={'schema':'source52_installer_revision_v1','prior':pin(raw),'candidate':pin(path.read_bytes()),
 'install_authorized':False,'pins_unbound':True,'install_calls':0,'actual_process_queries':0,'formal_mutations':0}
with (OWN/'INSTALLER-REVISION.json').open('x',encoding='utf-8') as stream:stream.write(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(result,ensure_ascii=False))
