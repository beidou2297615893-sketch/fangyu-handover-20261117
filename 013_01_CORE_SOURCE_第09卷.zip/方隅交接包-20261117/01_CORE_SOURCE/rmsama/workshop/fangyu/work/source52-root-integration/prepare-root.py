"""Root-only isolated preparation; no formal source, data, or process access."""
import hashlib,json,stat
from pathlib import Path
PROJECT=Path('C:/积木软件工坊/项目/方隅公寓客户版')
WORK=PROJECT/'work'
OWN=WORK/'source52-root-integration'
BASE=WORK/'source51-root-integration/PREPARED.json'
FROZEN=WORK/'source52-store-manager/revision2/FROZEN.json'
BASE_PIN={'bytes':182535,'sha256':'FAACF573300DCEBD6E7AF453DF7850003DE950962A5B013FD15C6A1E88A973ED'}
FREEZE_PIN={'bytes':20693,'sha256':'737719494423FEB5F5F928735264629188C7A94F24C19B7C680811480DB94517'}
MANIFEST_PIN={'bytes':160775,'sha256':'7E9ACEC49AAF60D216A05F57B4C640348948CD501FEA6527F2B30391B232BB10'}
def pin(raw):return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest().upper()}
def read(path,proof=None):
    path.relative_to(PROJECT)
    cur=PROJECT
    for part in ('',*path.relative_to(PROJECT).parts):
        if part:cur=cur/part
        info=cur.lstat()
        if cur.is_symlink() or getattr(info,'st_file_attributes',0)&0x400:raise ValueError('ordinary project path required')
    if not stat.S_ISREG(info.st_mode) or info.st_nlink!=1:raise ValueError('ordinary single-link file required')
    raw=path.read_bytes()
    if proof is not None and pin(raw)!=proof:raise ValueError('pinned preparation input changed: '+str(path))
    return raw
def create(path,raw):
    path.relative_to(OWN)
    path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('xb') as stream:stream.write(raw)
    read(path,pin(raw))
base=json.loads(read(BASE,BASE_PIN));freeze=json.loads(read(FROZEN,FREEZE_PIN))
if base['schema']!='source51_owner_prepared_v1' or len(base['targets'])!=11 or len(base['protected'])!=459:raise ValueError('fixed base graph changed')
if freeze['target_count']!=9 or freeze['existing_count']!=9 or freeze['new_count']!=0 or freeze['formal_mutations']!=0:raise ValueError('fixed r2 scope changed')
future={Path(row['path']):row['pin'] for row in base['protected']}
for row in base['targets']:
    path=Path(row['target'])
    if path in future:raise ValueError('base final/protected overlap')
    future[path]=row['candidate_pin']
targets=[];coverage=[]
for row in freeze['targets']:
    target=Path(row['target']);relative=target.relative_to(WORK)
    parent=read(Path(row['parent_source']),row['parent'])
    after=read(Path(row['candidate']),row['candidate_pin'])
    if target in future:
        if future[target]!=row['parent']:raise ValueError('future parent mismatch')
        kind='Source51_future_final_or_protected'
    else:
        if relative.as_posix()!='app/src/web/workspace/local-transport.mjs':raise ValueError('unexpected newly covered public parent')
        read(target,row['parent']);kind='newly_covered_public_existing_parent'
    destination=OWN/'candidates'/relative
    create(destination,after)
    targets.append({'target':str(target),'candidate':str(destination),'parent':row['parent'],'candidate_pin':row['candidate_pin']})
    coverage.append({'path':str(target),'kind':kind})
if len({x['target'] for x in targets})!=9 or sum(x['kind'].startswith('Source51') for x in coverage)!=8:raise ValueError('exact nine coverage changed')
excluded={Path(row['target']) for row in targets}
# These direct public prerequisites already belong to the fixed future graph.
# No real database, credentials, fixture runtime, or full dependency-index walk.
relative_dependencies=(
 'app/src/app.py','app/src/core/engine.py','app/src/integrations.py',
 'cloud/workspace/index.js','cloud/workspace/devices.cjs',
 'cloud/workspace/device_permission_snapshot.cjs','cloud/workspace/shared_leads_v2.cjs',
 'cloud/workspace/shared_feature.cjs','cloud/workspace/ai_enterprise.cjs',
 'cloud/workspace/contact_ledger.cjs','cloud/workspace/handoff-ledger.cjs',
 'cloud/workspace/business_reconciliation.cjs','cloud/workspace/channel_candidates.cjs',
 'cloud/workspace/source_binding.cjs','cloud/workspace/contact_delivery.cjs',
 'cloud/workspace/product_entitlements.cjs','cloud/workspace/shared_store_scope.cjs')
deps=[{'path':str(WORK/x),'pin':future[WORK/x]} for x in relative_dependencies]
protected={path:proof for path,proof in future.items() if path not in excluded}
for row in deps:
    path=Path(row['path'])
    if path in excluded:raise ValueError('dependency/target conflict')
    if path in protected and protected[path]!=row['pin']:raise ValueError('dependency pin conflict')
    protected[path]=row['pin']
evidence=[{'path':str(BASE),'pin':BASE_PIN},{'path':str(FROZEN),'pin':FREEZE_PIN},
 {'path':str(WORK/'source52-independent-review/CODE-REVIEW.md'),'pin':{'bytes':8089,'sha256':'2CF932B4E6FED3A1AEE8B4BC5430833F66510D8B95B61B5AFA77D77899F2CE08'}},
 {'path':str(WORK/'source52-independent-review/REVISION2-REVIEW.md'),'pin':{'bytes':5853,'sha256':'3ADC52C526F8AEC7535E1D77E99F91D4BE1CDEAD802BE116BF3F148708E9BE8D'}}]
evidence.extend([freeze['first_candidate_freeze'],freeze['inherited_final_main'],freeze['inherited_final_DOM']])
evidence.extend({'path':x['path'],'pin':x['pin']} for x in freeze['new_seam_evidence'])
for row in evidence:read(Path(row['path']),row['pin'])
result={'schema':'source52_owner_prepared_v1','source_batch':52,'join_authorized':False,
 'instance_id':base['instance_id'],'base_manifest_pin':MANIFEST_PIN,'targets':targets,
 'protected':[{'path':str(path),'pin':protected[path]} for path in sorted(protected,key=lambda x:str(x).casefold())],
 'candidate_dependencies':deps,'evidence':evidence,'new_directories':[]}
raw=(json.dumps(result,ensure_ascii=False,indent=2)+'\n').encode('utf-8')
create(OWN/'PREPARED.json',raw)
note={'schema':'source52_root_prepared_scope_v1','prepared_pin':pin(raw),'targets':9,'existing':9,'new':0,
 'protected_count':len(protected),'direct_public_dependencies':len(deps),'parent_coverage':coverage,
 'formal_mutations':0,'process_queries':0,'customer_database_opened':False,'session_copied':False}
create(OWN/'PREPARATION.json',(json.dumps(note,ensure_ascii=False,indent=2)+'\n').encode('utf-8'))
print(json.dumps({k:note[k] for k in ('prepared_pin','targets','existing','new','protected_count','direct_public_dependencies','formal_mutations','process_queries')},ensure_ascii=False))
