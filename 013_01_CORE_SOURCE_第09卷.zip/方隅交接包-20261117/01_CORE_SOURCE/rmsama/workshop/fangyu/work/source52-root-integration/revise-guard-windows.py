"""Root changes only the two actual InvalidQuery causes and PS progress transport."""
import ast,hashlib,json
from pathlib import Path
OWN=Path('C:/积木软件工坊/项目/方隅公寓客户版/work/source52-root-integration')
path=OWN/'source_idle_guard.py';raw=path.read_bytes()
def pin(value):return {'bytes':len(value),'sha256':hashlib.sha256(value).hexdigest().upper()}
old_pin={'bytes':5688,'sha256':'A8B4475C9E0EB3FDB57C5CAE791A0D7953F432E434FE4F21AFB1C9D2B93DF398'}
if pin(raw)!=old_pin:raise ValueError('fixed Windows RED guard changed')
snapshot=OWN/'native-windows-red';snapshot.mkdir()
for name in ('source_idle_guard.py','join-source52-reviewed.py','next_open_source52.py','install_native.py'):
    with (snapshot/name).open('xb') as stream:stream.write((OWN/name).read_bytes())
text=raw.decode('utf-8')
old='''    # MS-WMI: backslash escaping excludes LIKE clauses. A Windows source path
    # cannot contain a double quote; single quotes are ordinary here.
    if '"' in value:raise ValueError('fixed LIKE literal delimiter changed')
    return '"'+value+'"'
'''
new='''    # The owned Windows WMI trace rejected literal single backslashes before
    # LIKE evaluation. Escape that string-parser layer, then retain the fixed
    # bracket quoting used by LIKE. Single quotes are ordinary inside double quotes.
    if '"' in value:raise ValueError('fixed LIKE literal delimiter changed')
    return '"'+value.replace('\\\\','\\\\\\\\')+'"'
'''
if text.count(old)!=1:raise ValueError('LIKE string-parser anchor changed')
text=text.replace(old,new,1)
old="blanks.extend('CommandLine LIKE '+_wql_like(x+'%') for x in (' ', '\\t', '\\r', '\\n', '\\v', '\\f'))"
new="blanks.append('CommandLine LIKE '+_wql_like('[^!-~]%'))"
if text.count(old)!=1:raise ValueError('raw control literal anchor changed')
text=text.replace(old,new,1)
text=text.replace("program=\"\"\"$ErrorActionPreference='Stop'", "program=\"\"\"$ErrorActionPreference='Stop'\n$ProgressPreference='SilentlyContinue'",1)
text=text.replace("# Both filtered sets may include a known live consumer. Live has priority;", "# Non-printable/Unicode leading characters are conservatively unknown;\n    # no raw control characters are interpolated into WMI query literals.\n    # Both filtered sets may include a known live consumer. Live has priority;",1)
ast.parse(text);path.write_text(text,encoding='utf-8',newline='\n')
new_pin=pin(path.read_bytes())
for name,key in (('join-source52-reviewed.py','SOURCE_GUARD_PIN'),('next_open_source52.py','GUARD_PIN'),('install_native.py','GUARD_PIN')):
    path=OWN/name;lines=path.read_text(encoding='utf-8').splitlines(keepends=True);count=0
    for i,line in enumerate(lines):
        if line.startswith(key+'='):
            if ast.literal_eval(line.split('=',1)[1])!=old_pin:raise ValueError('prior guard literal changed')
            lines[i]=key+'='+repr(new_pin)+'\n';count+=1
    if count!=1:raise ValueError('guard binding anchor changed')
    code=''.join(lines);ast.parse(code);path.write_text(code,encoding='utf-8',newline='\n')
result={'schema':'source52_windows_guard_correction_v1','prior_guard':old_pin,'source_guard':new_pin,
 'CAS':pin((OWN/'join-source52-reviewed.py').read_bytes()),'helper':pin((OWN/'next_open_source52.py').read_bytes()),
 'installer':pin((OWN/'install_native.py').read_bytes()),'formal_mutations':0,'actual_customer_process_queries':0,
 'Windows_compat_passed':False,'join_authorized':False,'install_authorized':False}
with (OWN/'NATIVE-WINDOWS-CORRECTION.json').open('x',encoding='utf-8') as stream:stream.write(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(result,ensure_ascii=False))
