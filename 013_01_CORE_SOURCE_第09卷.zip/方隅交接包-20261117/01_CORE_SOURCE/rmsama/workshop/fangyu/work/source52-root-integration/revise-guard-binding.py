"""Preserve the first draft and bind the official-WQL guard correction, no invocation."""
import ast,hashlib,json
from pathlib import Path
OWN=Path('C:/积木软件工坊/项目/方隅公寓客户版/work/source52-root-integration')
def pin(raw):return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest().upper()}
guard=(OWN/'source_idle_guard.py').read_text(encoding='utf-8')
new_pin=pin(guard.encode('utf-8'))
if new_pin!={'bytes':5536,'sha256':'6D3F7F336E350F83ED6F28D23FBD257B684BBCAC8E01FC3AF684D55B0FC983CC'}:raise ValueError('corrected guard changed')
old=guard.replace('''
def _wql_like(value):
    # MS-WMI: backslash escaping excludes LIKE clauses. A Windows source path
    # cannot contain a double quote; single quotes are ordinary here.
    if '"' in value:raise ValueError('fixed LIKE literal delimiter changed')
    return '"'+value+'"'
''','',1)
old=old.replace("_wql_like('%'+_like_literal(value)+'%')","_wql_string('%'+_like_literal(value)+'%')")
old=old.replace("_wql_like('%'+_like_literal(x)+'%')","_wql_string('%'+_like_literal(x)+'%')")
old=old.replace("names.extend('CommandLine LIKE '+_wql_like(x) for x in ('%-m%','%-c%','%-e%','%--eval%'))", "names.extend('CommandLine LIKE '+_wql_string(x) for x in ('% -m app%','% -c %','% -e %','% --eval %'))")
old=old.replace('''    # Both filtered sets may include a known live consumer. Live has priority;
    # no unsupported NOT-of-an-OR expression is needed to suppress duplicates.
    ambiguous=f'{runtimes} AND (CommandLine IS NULL OR '+ ' OR '.join(names)+')'
''',"    ambiguous=f'{runtimes} AND (CommandLine IS NULL OR '+ ' OR '.join(names)+') AND NOT '+live\n",1)
old_pin={'bytes':5136,'sha256':'F33EAD3479444187CE79DD12BDD32ADDC9E5AB653A5C0887FAEF809A12A98F3D'}
if pin(old.encode('utf-8'))!=old_pin:raise ValueError('first guard recovery mismatch; do not invent history')
snapshot=OWN/'native-revision1';snapshot.mkdir()
with (snapshot/'source_idle_guard.py').open('xb') as stream:stream.write(old.encode('utf-8'))
for name in ('join-source52-reviewed.py','next_open_source52.py','source_next_open_launcher.py','NATIVE-DRAFT.json'):
    with (snapshot/name).open('xb') as stream:stream.write((OWN/name).read_bytes())
for name,key in (('join-source52-reviewed.py','SOURCE_GUARD_PIN'),('next_open_source52.py','GUARD_PIN')):
    path=OWN/name;lines=path.read_text(encoding='utf-8').splitlines(keepends=True)
    count=0
    for i,line in enumerate(lines):
        if line.startswith(key+'='):
            if ast.literal_eval(line.split('=',1)[1])!=old_pin:raise ValueError('first guard binding changed')
            lines[i]=key+'='+repr(new_pin)+'\n';count+=1
    if count!=1:raise ValueError('guard binding anchor changed')
    text=''.join(lines);ast.parse(text);path.write_text(text,encoding='utf-8',newline='\n')
result={'schema':'source52_root_native_guard_revision_v1','prior_guard':old_pin,'source_guard':new_pin,
 'CAS':pin((OWN/'join-source52-reviewed.py').read_bytes()),'helper':pin((OWN/'next_open_source52.py').read_bytes()),
 'launcher':pin((OWN/'source_next_open_launcher.py').read_bytes()),'prepared':pin((OWN/'PREPARED.json').read_bytes()),
 'join_authorized':False,'manifest_pin':None,'formal_mutations':0,'actual_process_queries':0}
with (OWN/'NATIVE-GUARD-REVISION.json').open('x',encoding='utf-8') as stream:stream.write(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(result,ensure_ascii=False))
