"""Isolated Root launcher candidate, new helper pin will be filled after review."""
import ast,hashlib,json
from pathlib import Path
WORK=Path('C:/积木软件工坊/项目/方隅公寓客户版/work')
OWN=WORK/'source52-root-integration'
source=WORK/'desktop-self-use-entry/source_next_open_launcher.py'
raw=source.read_bytes()
def pin(value):return {'bytes':len(value),'sha256':hashlib.sha256(value).hexdigest().upper()}
if pin(raw)!={'bytes':4626,'sha256':'AA029206565CA20227131E06C200FBAA385C909CA5C21B274CA83477F1992176'}:raise ValueError('actual Source51 launcher parent changed')
text=raw.decode('utf-8')
text=text.replace('"""Uninstalled Source51 successor draft; its reviewed coordinator pin is absent."""','"""Root Source52 normal opening candidate. No final reviewed coordinator pin yet."""',1)
at='SUCCESSOR_PIN = '
lines=text.splitlines(keepends=True)
for i,line in enumerate(lines):
    if line.startswith(at):
        lines.insert(i+1,"LATEST = PROJECT/'work/desktop-self-use-entry/next_open_source52.py'\nLATEST_PIN = None\n");break
else:raise ValueError('fixed successor anchor absent')
text=''.join(lines)
text=text.replace("entry_pin = successor.reviewed_entry_pin_if_joined(helper) or entry_pin", "latest = _load(LATEST, LATEST_PIN, 'source52_fixed_next_open_metadata')\n                entry_pin = latest.reviewed_entry_pin_if_joined(helper, successor) or entry_pin",1)
text=text.replace("entry_pin = successor.reviewed_entry_pin_if_joined(helper) or entry_pin", "latest = _load(LATEST, LATEST_PIN, 'source52_fixed_next_open')\n        entry_pin = latest.reviewed_entry_pin_if_joined(helper, successor) or entry_pin",1)
text=text.replace('result = successor.before_normal_open(entry, helper)','result = latest.before_normal_open(entry, helper, successor)',1)
ast.parse(text)
path=OWN/'source_next_open_launcher.py'
with path.open('xb') as stream:stream.write(text.encode('utf-8'))
print(json.dumps({'launcher_candidate':pin(path.read_bytes()),'latest_pin':None,'actual_parent':pin(raw),'formal_mutations':0,'App_control':False},ensure_ascii=False))
