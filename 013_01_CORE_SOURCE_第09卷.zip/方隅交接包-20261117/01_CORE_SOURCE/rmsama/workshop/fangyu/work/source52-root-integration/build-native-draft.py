"""Root isolates and rebinds reviewed candidates; does not install or invoke."""
import ast,hashlib,json
from pathlib import Path
OWN=Path('C:/积木软件工坊/项目/方隅公寓客户版/work/source52-root-integration')
WORK=OWN.parent
def pin(raw):return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest().upper()}
source=WORK/'source52-store-manager/cas-draft/join-source52-reviewed.py'
raw=source.read_bytes()
if pin(raw)!={'bytes':27414,'sha256':'2678AA33373EF0B166B05BCA562B134151F87F8E64FEFAE70CE56F1725E7772F'}:raise ValueError('CAS draft changed')
prepared=json.loads((OWN/'PREPARED.json').read_bytes())
guard=(OWN/'source_idle_guard.py').read_bytes();guard_pin=pin(guard)
text=raw.decode('utf-8')
base={'bytes':160775,'sha256':'7E9ACEC49AAF60D216A05F57B4C640348948CD501FEA6527F2B30391B232BB10'}
text=text.replace('BASE_MANIFEST_PIN=None','BASE_MANIFEST_PIN='+repr(base),1)
lines=text.splitlines(keepends=True)
replacement={Path(x['target']).relative_to(WORK).as_posix():(x['parent'],x['candidate_pin']) for x in prepared['targets']}
for i,line in enumerate(lines):
    if line.startswith('EXPECTED_TARGET_PINS='):lines[i]='EXPECTED_TARGET_PINS='+repr(replacement)+'\n'
text=''.join(lines)
text=text.replace('JOIN_AUTHORIZED=False','JOIN_AUTHORIZED=False\nSOURCE_GUARD=OWN/\'source_idle_guard.py\'\nSOURCE_GUARD_PIN='+repr(guard_pin),1)
marker='\n\ndef existing_lock_is_held():'
guard_function='''

def require_source_idle(phase):
    # Same fixed guard as normal opening. No business code or private state.
    import types
    if not proof(SOURCE_GUARD_PIN):raise ValueError('fixed source guard absent')
    raw=expected(SOURCE_GUARD,SOURCE_GUARD_PIN)
    module=types.ModuleType('source52_cas_source_guard');module.__file__=str(SOURCE_GUARD)
    exec(compile(raw,str(SOURCE_GUARD),'exec'),module.__dict__)
    value=module.source_state(os.getpid())
    if (type(value) is not dict or value.get('scope')!='fangyu_customer_source_metadata_v1'
        or value.get('state')!='idle'):raise ValueError('source live or unknown at '+phase)
    return value
'''
if text.count(marker)!=1:raise ValueError('guard insertion anchor changed')
text=text.replace(marker,guard_function+marker,1)
text=text.replace("or gate.get('deployment_or_packaging_performed') is not False):", "or gate.get('deployment_or_packaging_performed') is not False\n        or gate.get('source_guard_pin')!=SOURCE_GUARD_PIN):",1)
text=text.replace("or authority.get('approval_pin')!=pin(approval_raw) or authority.get('join_script_pin')!=gate['join_script_pin']", "or authority.get('approval_pin')!=pin(approval_raw) or authority.get('join_script_pin')!=gate['join_script_pin']\n        or authority.get('source_guard_pin')!=SOURCE_GUARD_PIN",1)
text=text.replace("original_pid=original_main_dead();existing_lock_is_held()", "original_pid=original_main_dead();existing_lock_is_held()\n        require_source_idle('before_backups_and_temps')",1)
text=text.replace("attempted.append((item,target,before,after))\n            os.replace", "require_source_idle('before_replace')\n            attempted.append((item,target,before,after))\n            os.replace",1)
text=text.replace("existing_lock_is_held()\n        result=", "existing_lock_is_held()\n        require_source_idle('before_success_receipt')\n        result=",1)
text=text.replace("expected(target,item['candidate_pin']);no_link_parent(target);os.replace(restore,target)", "expected(target,item['candidate_pin']);no_link_parent(target);require_source_idle('before_own_rollback');os.replace(restore,target)",1)
ast.parse(text)
cas=OWN/'join-source52-reviewed.py'
with cas.open('xb') as stream:stream.write(text.encode('utf-8'))
helper_path=OWN/'next_open_source52.py'
helper=helper_path.read_text(encoding='utf-8')
if helper.count('GUARD_PIN=None')!=1:raise ValueError('helper guard insertion changed')
helper=helper.replace('GUARD_PIN=None','GUARD_PIN='+repr(guard_pin),1)
ast.parse(helper);helper_path.write_text(helper,encoding='utf-8',newline='\n')
result={'schema':'source52_root_native_draft_v1','join_authorized':False,'manifest_pin':None,
 'prepared':pin((OWN/'PREPARED.json').read_bytes()),'source_guard':guard_pin,
 'CAS':pin(cas.read_bytes()),'helper':pin(helper_path.read_bytes()),'targets':9,'protected':len(prepared['protected']),
 'formal_mutations':0,'native_story_run':False,'actual_process_queries':0}
with (OWN/'NATIVE-DRAFT.json').open('x',encoding='utf-8') as stream:stream.write(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(result,ensure_ascii=False))
