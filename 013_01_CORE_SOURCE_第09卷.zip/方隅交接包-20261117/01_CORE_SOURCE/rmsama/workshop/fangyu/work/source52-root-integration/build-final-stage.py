"""Root stages fixed authority only after accepted exact review inputs; no publication/install/apply."""
import ast,hashlib,json
from pathlib import Path
PROJECT=Path('C:/积木软件工坊/项目/方隅公寓客户版')
WORK=PROJECT/'work';OWN=WORK/'source52-root-integration';AUDITS=WORK/'product-upgrade-20261009/audits'
def pin(raw):return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest().upper()}
def exact(path,proof):
    raw=path.read_bytes()
    if pin(raw)!=proof:raise ValueError('fixed final input changed: '+str(path))
    return raw
def dump(path,value):
    raw=(json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode('utf-8')
    with path.open('xb') as stream:stream.write(raw)
    return pin(raw)
inputs=json.loads((OWN/'FINAL-ACCEPTED-INPUTS.json').read_bytes())
if inputs.get('Root_has_read_and_accepted_actual_reviews') is not True:raise ValueError('Root actual reviews not accepted')
prep_pin={'bytes':169430,'sha256':'BF80D4F7E920C2F15D2FEBB4190C7516E9728595D04CD111CD30FD034CBB7B60'}
prep=json.loads(exact(OWN/'PREPARED.json',prep_pin))
guard_pin={'bytes':5948,'sha256':'1E97220595CCD6954F67FAABFCAE83E52734D4EE59188F0657C9B0363FBA3AA1'}
exact(OWN/'source_idle_guard.py',guard_pin)
base_pin={'bytes':160775,'sha256':'7E9ACEC49AAF60D216A05F57B4C640348948CD501FEA6527F2B30391B232BB10'}
exact(AUDITS/'source51-manifest.json',base_pin)
evidence=[
 {'path':str(WORK/'source52-independent-review/REVISION2-REVIEW.md'),'pin':{'bytes':5853,'sha256':'3ADC52C526F8AEC7535E1D77E99F91D4BE1CDEAD802BE116BF3F148708E9BE8D'}},
 {'path':str(WORK/'source52-independent-review/NATIVE-PREDECESSOR-DELTA-REVIEW.md'),'pin':{'bytes':3527,'sha256':'0ADD9A70360D742482D6B2BBA23C2E6BC31046E57B46BA3477F9D948FB62DAF1'}},
 {'path':str(WORK/'source52-independent-review/INSTALL-DELTA-REVIEW.md'),'pin':{'bytes':2652,'sha256':'4B4AD6045344DB925DE44E3686C8685E0319A22B93ADD904114ABEBB55F65969'}},
 {'path':str(WORK/'source52-native-proposal/SOURCE-IDLE-GUARD-1E97-REVIEW.md'),'pin':{'bytes':6162,'sha256':'6A61997131FBC86C8C1261BEB4C0D5EB2BFDB2E58089180E277C5AAE2C03C630'}},
 {'path':str(WORK/'source52-native-proposal/NATIVE-STATE-ACTUAL-REVIEW.md'),'pin':{'bytes':7576,'sha256':'787035FF11887FBAA22F9A0B29569770C3B9C63AD847887C6027402299AF5796'}},
 inputs['install_actual_review']]
for row in evidence:
    Path(row['path']).relative_to(WORK);exact(Path(row['path']),row['pin'])
old_cas=exact(OWN/'join-source52-reviewed.py',{'bytes':30340,'sha256':'DAA27AA127AC0FA9EE08DA4DD32EC274743352D2DFE7FD5DD18786610892B245'})
code=old_cas.decode('utf-8')
if code.count('JOIN_AUTHORIZED=False')!=1:raise ValueError('fixed CAS authorization anchor changed')
final_cas=code.replace('JOIN_AUTHORIZED=False','JOIN_AUTHORIZED=True',1).encode('utf-8');ast.parse(final_cas)
cas_path=OWN/'join-source52-reviewed-final.py'
with cas_path.open('xb') as stream:stream.write(final_cas)
cas_pin=pin(final_cas)
stage=OWN/'authority-stage';stage.mkdir()
gate={'schema':'source52_final_root_read','source_batch':52,'join_authorized':True,
 'independent_code_review_passed':True,'independent_actual_qa_review_passed':True,'join_script_review_passed':True,
 'next_normal_open_only':True,'instance_id':prep['instance_id'],'base_manifest_pin':base_pin,
 'join_script_pin':cas_pin,'prepared_manifest_pin':prep_pin,'source_guard_pin':guard_pin,'additional_evidence':evidence,
 'customer_database_opened':False,'session_copied':False,'deployment_or_packaging_performed':False,
 'scope_note':'Reviewed local code and owned causal fixtures only. Real source-state is fresh within the original normal-open lock; platform grants, GUI and commercial acceptance are not inferred.'}
gate_pin=dump(stage/'source52-final-root-read.json',gate)
manifest={'schema':'source52_next_open_manifest_v1','source_batch':52,'instance_id':prep['instance_id'],
 'join_authorized':True,'base_manifest_pin':base_pin,'approval_pin':gate_pin,'join_script_pin':cas_pin,
 'source_guard_pin':guard_pin,'targets':[{'path':x['target'],'parent_pin':x['parent'],'final_pin':x['candidate_pin']} for x in prep['targets']],
 'protected':prep['protected']}
manifest_pin=dump(stage/'source52-manifest.json',manifest)
helper=exact(OWN/'next_open_source52.py',{'bytes':15374,'sha256':'D9250FC3DCD2ED859DAF2CD5A98D54291A7D3681A3F8B3AF9813667E528B51BF'}).decode('utf-8')
if helper.count('JOIN_AUTHORIZED=False')!=1 or helper.count('MANIFEST_PIN=None')!=1:raise ValueError('helper fixed binding anchors changed')
helper=helper.replace('JOIN_AUTHORIZED=False','JOIN_AUTHORIZED=True',1).replace('MANIFEST_PIN=None','MANIFEST_PIN='+repr(manifest_pin),1)
ast.parse(helper);helper_raw=helper.encode('utf-8');helper_pin=pin(helper_raw)
with (OWN/'next_open_source52-final.py').open('xb') as stream:stream.write(helper_raw)
launcher=exact(OWN/'source_next_open_launcher.py',{'bytes':4897,'sha256':'07545078E773134223590806A00A17DAB05B30EFFD75945C41FECED1322682E9'}).decode('utf-8')
if launcher.count('LATEST_PIN = None')!=1:raise ValueError('launcher fixed helper anchor changed')
launcher=launcher.replace('LATEST_PIN = None','LATEST_PIN = '+repr(helper_pin),1);ast.parse(launcher)
launcher_raw=launcher.encode('utf-8');launcher_pin=pin(launcher_raw)
with (OWN/'source_next_open_launcher-final.py').open('xb') as stream:stream.write(launcher_raw)
graph={'schema':'source52_root_final_graph_uninstalled_v1','source_batch':52,'targets':9,'existing':9,'new':0,
 'protected':462,'candidate_dependencies':17,'parent_coverage':'8 Source51 future + newly covered public local-transport',
 'prepared_pin':prep_pin,'base_manifest_pin':base_pin,'source_guard_pin':guard_pin,'CAS_pin':cas_pin,
 'gate_pin':gate_pin,'manifest_pin':manifest_pin,'helper_candidate_pin':helper_pin,'launcher_candidate_pin':launcher_pin,
 'launcher_parent_pin':{'bytes':4626,'sha256':'AA029206565CA20227131E06C200FBAA385C909CA5C21B274CA83477F1992176'},
 'evidence':evidence,'published':False,'installed':False,'business_apply_calls':0,
 'customer_database_opened':False,'session_copied':False,'platform_grants_changed':False,'commercial_complete':False}
graph_pin=dump(OWN/'FINAL-GRAPH.json',graph)
print(json.dumps({'CAS':cas_pin,'gate':gate_pin,'manifest':manifest_pin,'helper':helper_pin,'launcher':launcher_pin,
 'graph':graph_pin,'staged_only':True,'published':False,'installed':False,'business_apply_calls':0},ensure_ascii=False))
