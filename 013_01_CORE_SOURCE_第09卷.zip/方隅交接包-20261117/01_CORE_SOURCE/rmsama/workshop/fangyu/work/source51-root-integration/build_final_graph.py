"""Assemble the reviewed 11-file graph and uninstalled native pin successors."""
import hashlib
import json
from pathlib import Path

PROJECT = Path('C:/积木软件工坊/项目/方隅公寓客户版')
WORK = PROJECT/'work'
OWN = WORK/'source51-root-integration'
AUDITS = WORK/'product-upgrade-20261009/audits'


def pin(raw):
    return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest().upper()}


def read(path, proof):
    raw = path.read_bytes()
    if pin(raw) != proof:raise ValueError('fixed reviewed input changed: '+str(path))
    return raw


def create(path, raw):
    if path.exists():
        if path.read_bytes() != raw:raise ValueError('preserve existing final graph: '+str(path))
        return
    with path.open('xb') as out:out.write(raw)


def document(path, value):
    raw = (json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode('utf-8')
    create(path,raw)
    return pin(raw)


def main():
    prepared_pin = {'bytes':182535,'sha256':'FAACF573300DCEBD6E7AF453DF7850003DE950962A5B013FD15C6A1E88A973ED'}
    prepared = json.loads(read(OWN/'PREPARED.json',prepared_pin))
    reviews = [
        (WORK/'source51-independent-review/SCOPE-REVIEW.json',{'bytes':4043,'sha256':'DBCC661F37E56F2BA283264F58D51ED67B6AD387F51E36C9D25B93E34EA77CBC'}),
        (WORK/'source51-independent-review/DY-REVIEW.json',{'bytes':8808,'sha256':'6A041C7B4E1B7458A7658F0741F8415CDB332E46187AF25837022808550DD480'}),
        (WORK/'source51-native-independent-review/REVIEW.md',{'bytes':7080,'sha256':'035503852C170154CE1F85F9A8870D0B7BD6DE62C88008434B45F3F55F115D86'}),
        (WORK/'source51-native-independent-review/READBACK.json',{'bytes':19861,'sha256':'6FA8E1110B5F22F77CF17A4DC33894B1255F44BEC7BA4B6F7001032E44ABDBB4'}),
    ]
    for path,proof in reviews:read(path,proof)
    cas = read(WORK/'source51-root-cas-candidate/join-source51-reviewed.py',
        {'bytes':19503,'sha256':'C66479414675043C6EA09D91F0C16B64CA8BB77B2726886B99E38C3F64A3CC72'})
    assert cas.count(b'JOIN_AUTHORIZED=False') == 1
    cas = cas.replace(b'JOIN_AUTHORIZED=False',b'JOIN_AUTHORIZED=True')
    compile(cas,str(AUDITS/'join-source51-reviewed.py'),'exec')
    create(AUDITS/'join-source51-reviewed.py',cas)
    cas_pin = pin(cas)
    gate = {'schema':'source51_final_root_read','source_batch':51,'join_authorized':True,
        'independent_code_review_passed':True,'independent_actual_qa_review_passed':True,
        'join_script_review_passed':True,'next_normal_open_only':True,
        'base_manifest_pin':prepared['base_manifest_pin'],'join_script_pin':cas_pin,
        'prepared_manifest_pin':prepared_pin,
        'additional_evidence':[{'path':str(path),'pin':proof} for path,proof in reviews],
        'customer_database_opened':False,'session_copied':False,'deployment_or_packaging_performed':False,
        'root_scope':'11 reviewed local source targets; actual Source50 success required as predecessor',
        'native_final_delta_review_and_install_readback_required':True,
        'real_GUI_verified':False,'real_platform_or_model_calls':0,'commercial_complete':False}
    gate_pin = document(AUDITS/'source51-final-root-read.json',gate)
    manifest = {'schema':'source51_next_open_manifest_v1','source_batch':51,'join_authorized':True,
        'instance_id':prepared['instance_id'],'base_manifest_pin':prepared['base_manifest_pin'],
        'approval_pin':gate_pin,'join_script_pin':cas_pin,
        'targets':[{'path':row['target'],'parent_pin':row['parent'],'final_pin':row['candidate_pin']} for row in prepared['targets']],
        'protected':prepared['protected']}
    manifest_pin = document(AUDITS/'source51-manifest.json',manifest)
    helper = read(OWN/'next_open_source51.py',
        {'bytes':13940,'sha256':'3030F92CB80387191460F568DC008119A2BDE7876D489B447A41DB83879A70C6'})
    helper_text = helper.decode('utf-8')
    for old,new in (('JOIN_AUTHORIZED = False','JOIN_AUTHORIZED = True'),
        ('MANIFEST_PIN = None','MANIFEST_PIN = '+repr(manifest_pin)),
        ('TARGET_PATHS = ()','TARGET_PATHS = (\n'+''.join("    PROJECT/"+repr(Path(row['target']).relative_to(PROJECT).as_posix())+',\n' for row in prepared['targets'])+')')):
        assert helper_text.count(old) == 1
        helper_text = helper_text.replace(old,new,1)
    final_helper = helper_text.encode('utf-8')
    compile(final_helper,str(OWN/'next_open_source51-final.py'),'exec')
    create(OWN/'next_open_source51-final.py',final_helper)
    helper_pin = pin(final_helper)
    launcher = read(OWN/'source_next_open_launcher.py',
        {'bytes':4536,'sha256':'8388EF1B36B0CD979270D93EE3B2BB576E755C77D324B238EBB095ED298CD958'})
    assert launcher.count(b'SUCCESSOR_PIN = None') == 1
    final_launcher = launcher.replace(b'SUCCESSOR_PIN = None',('SUCCESSOR_PIN = '+repr(helper_pin)).encode())
    compile(final_launcher,str(OWN/'source_next_open_launcher-final.py'),'exec')
    create(OWN/'source_next_open_launcher-final.py',final_launcher)
    graph = {'schema':'source51_root_final_graph_uninstalled_v1','targets':11,'parents':10,'new':1,
        'protected':len(prepared['protected']),'prepared_pin':prepared_pin,'gate_pin':gate_pin,
        'manifest_pin':manifest_pin,'CAS_pin':cas_pin,'helper_candidate_pin':helper_pin,
        'launcher_candidate_pin':pin(final_launcher),'reviewed_function_bodies_changed':False,
        'native_final_delta_review_required':True,'installed':False,'source50_applied':False,
        'source51_applied':False,'real_GUI_or_platform_or_model_started':False,'commercial_complete':False}
    document(OWN/'FINAL-GRAPH.json',graph)
    print(json.dumps(graph,ensure_ascii=False))


if __name__ == '__main__':main()
