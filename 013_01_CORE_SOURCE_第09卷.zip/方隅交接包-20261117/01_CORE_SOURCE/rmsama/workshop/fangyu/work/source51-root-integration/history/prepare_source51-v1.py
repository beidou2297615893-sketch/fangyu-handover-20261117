"""Root-only fixed candidate assembly. No formal source, gate or instance write."""
import ast
import hashlib
import json
import os
import stat
from pathlib import Path

PROJECT = Path('C:/积木软件工坊/项目/方隅公寓客户版')
WORK = PROJECT/'work'
OWN = WORK/'source51-root-integration'
DY = WORK/'source51-dy-owner-downstream'
STORE = WORK/'source51-store-scope'
BASE = WORK/'overnight-commercial-20261014/source50-preparation/PREPARED.json'
BASE_AUTHORITY = WORK/'product-upgrade-20261009/audits/source50-manifest.json'
INSTANCE = 'd075ac9c039e44038ddbc6f3e753d73c'
BASE_PIN = {'bytes':165442,'sha256':'5613B97635D7DD386DCE6E88D0B31C50D563F71BC8D970D3033A82882FC3BBD0'}
AUTHORITY_PIN = {'bytes':17143,'sha256':'FA18DE22A451370BD49417A6315ED317134B261D615BED0622031379BEF57267'}
DY_PIN = {'bytes':81390,'sha256':'03D999555B7CA29A5C5B1E6317D85D9E768BB1631755D5D557F310EE325FF430'}
STORE_PIN = {'bytes':14804,'sha256':'D6287074B1ACD2FB9A0AB84D043289EAD5A740435F6A26871F5E6D5E9BB9D646'}
ALLOW = (
    'app/src/assistant/self_operating_read.py',
    'app/src/assistant/self_operating_source_intent.py',
    'app/src/assistant/owner_douyin_source_archive.py',
    'app/src/web/workspace/self-operating-read.mjs',
    'app/src/assistant/source_intent_analysis.py',
    'app/src/assistant/self_operating_acquisition.py',
    'cloud/workspace/service.cjs', 'cloud/workspace/shared_leads_v2.cjs',
    'cloud/workspace/index.js', 'cloud/workspace/shared_store_scope.cjs',
    'desktop-self-use-entry/desktop_entry.py',
)


def pin(raw):
    return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest().upper()}


def blob(path):
    path = Path(path)
    path.relative_to(WORK)
    current = PROJECT
    for part in ('', *path.relative_to(PROJECT).parts):
        if part:current = current/part
        info = current.lstat()
        if current.is_symlink() or getattr(info,'st_file_attributes',0)&0x400:
            raise ValueError('candidate path alias refused')
    if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1:
        raise ValueError('ordinary single-link candidate file required')
    return path.read_bytes()


def expected(path, proof):
    raw = blob(path)
    if pin(raw) != proof:raise ValueError('fixed input changed: '+str(path))
    return raw


def write_owned(path, raw):
    path.relative_to(OWN)
    path.parent.mkdir(parents=True, exist_ok=True)
    if os.path.lexists(path):
        if blob(path) != raw:raise ValueError('preserve prior Root assembly: '+str(path))
        return
    with path.open('xb') as out:out.write(raw)


def document(path, value):
    write_owned(path, (json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode('utf-8'))


def main():
    base = json.loads(expected(BASE, BASE_PIN))
    authority = json.loads(expected(BASE_AUTHORITY, AUTHORITY_PIN))
    dy_path = DY/'evidence/FROZEN.json'
    store_path = STORE/'FROZEN.json'
    dy = json.loads(expected(dy_path, DY_PIN))
    store = json.loads(expected(store_path, STORE_PIN))
    base_finals = {Path(row['path']):row['final_pin'] for row in authority['targets']}
    base_inputs = {Path(row['target']):row for row in base['targets']}
    assert len(base_finals) == len(base_inputs) == 55
    assert all(base_inputs[path]['candidate_pin'] == value for path,value in base_finals.items())
    old_protected = {Path(row['path']):row['pin'] for row in base['protected']}
    assert len(old_protected) == 367
    rows = dy['targets']+store['targets']+[dy['entry_proposal']]
    by_target = {Path(row['target']):row for row in rows}
    assert len(rows) == len(by_target) == 11
    assert {path.relative_to(WORK).as_posix() for path in by_target} == set(ALLOW)
    targets = []
    final_bytes = {}
    for relative in ALLOW:
        target = WORK/relative
        row = by_target[target]
        parent = row['parent']
        if target in base_finals:
            assert parent == base_finals[target]
            expected(Path(base_inputs[target]['candidate']), parent)
        elif target in old_protected:
            assert parent == old_protected[target]
            expected(target, parent)
        elif parent is not None:
            expected(target, parent)
        else:
            assert relative == 'cloud/workspace/shared_store_scope.cjs' and not os.path.lexists(target)
        raw = expected(Path(row['candidate']), row['candidate_pin'])
        output = OWN/'candidates'/relative
        write_owned(output, raw)
        final_bytes[target] = raw
        targets.append({'target':str(target),'candidate':str(output),'parent':parent,'candidate_pin':pin(raw)})
    assert sum(row['parent'] is None for row in targets) == 1
    # The proposed entry is exactly the already-approved Source50 entry with
    # one new self-read host pin. No marker, flags or permission are rebuilt.
    entry = WORK/'desktop-self-use-entry/desktop_entry.py'
    before = expected(Path(dy['entry_proposal']['parent_file']['path']),dy['entry_proposal']['parent'])
    old = dy['entry_proposal']['old_sha256'].encode()
    new = dy['entry_proposal']['new_sha256'].encode()
    assert before.count(old) == 1 and before.replace(old,new) == final_bytes[entry]

    origins = {Path(row['path']):Path(row['formal_target']) for row in dy['public_dependency_origin']}
    dependencies = {}
    for row in dy['public_dependencies']+store['unchanged_public_dependencies']:
        source = Path(row['path'])
        expected(source,row['pin'])
        target = origins.get(source,source)
        target.relative_to(WORK)
        assert target.is_relative_to(WORK/'app/src') or target.is_relative_to(WORK/'cloud/workspace')
        if target in dependencies:assert dependencies[target] == row['pin']
        dependencies[target] = row['pin']
        if target in base_finals:assert base_finals[target] == row['pin']
        elif target in old_protected:assert old_protected[target] == row['pin']
        else:expected(target,row['pin'])
    values = {}
    for mapping in (old_protected,dependencies,base_finals):
        for path,value in mapping.items():
            if path in by_target:continue
            if path in values:assert values[path] == value
            values[path] = value
    protected = [{'path':str(path),'pin':value} for path,value in sorted(values.items(),key=lambda row:str(row[0]))]

    revisions = []
    for impact in dy['source_revision_impacts']:
        module = WORK/'app/src'/impact['module']
        if module in final_bytes:module_raw = final_bytes[module]
        elif module in base_inputs:module_raw = expected(Path(base_inputs[module]['candidate']),base_finals[module])
        else:module_raw = expected(module,dependencies.get(module,old_protected[module]))
        assigns = [node for node in ast.parse(module_raw).body if isinstance(node,ast.Assign)
            and any(isinstance(target,ast.Name) and target.id == impact['fixed_sources_constant'] for target in node.targets)]
        assert len(assigns) == 1
        assert list(ast.literal_eval(assigns[0].value)) == impact['source_files']
        hashes = {}
        for relative in impact['source_files']:
            path = WORK/'app/src'/relative
            if path in final_bytes:value = pin(final_bytes[path])
            elif path in base_finals:value = base_finals[path]
            else:value = dependencies.get(path,old_protected.get(path))
            assert value is not None
            hashes[relative] = value['sha256'].lower()
        assert hashes == impact['candidate_sha256_lower']
        result = hashlib.sha256(json.dumps(hashes,ensure_ascii=False,sort_keys=impact['digest_sort_keys'],
            separators=(',',':')).encode()).hexdigest()
        assert result == impact['six_business_candidate_revision']
        revisions.append({'purpose':impact['purpose'],'module':impact['module'],'sources':impact['source_files'],
            'source_revision':result,'sort_keys':impact['digest_sort_keys'],
            'store_or_entry_changes_affect_revision':False,'platform_purpose_granted':False})
    revision_file = OWN/'source-revision-readback.json'
    document(revision_file,{'schema':'source51_root_combined_revision_readback_v1','source_batch':51,
        'source50_manifest_pin':AUTHORITY_PIN,'dy_frozen_pin':DY_PIN,'store_frozen_pin':STORE_PIN,
        'root_targets':11,'revision_maps':revisions,'real_platform_purpose_granted':False,
        'instance_marker_modified':False,'formal_source_written':False,'business_modules_imported':False})
    evidence = [{'path':str(dy_path),'pin':DY_PIN},{'path':str(store_path),'pin':STORE_PIN},
        {'path':str(revision_file),'pin':pin(blob(revision_file))}]
    for row in dy['actual_evidence']+[dy['diff'],dy['readme'],dy['targets_and_closure'],dy['entry_proposal']['diff']]+store['evidence']:
        expected(Path(row['path']),row['pin'])
        if row not in evidence:evidence.append(row)
    prepared = {'schema':'source51_owner_prepared_v1','source_batch':51,'join_authorized':False,
        'instance_id':INSTANCE,'base_manifest_pin':AUTHORITY_PIN,'targets':targets,'protected':protected,
        'candidate_dependencies':[{'path':str(path),'pin':value} for path,value in sorted(dependencies.items(),key=lambda row:str(row[0]))],
        'evidence':evidence,'new_directories':[]}
    document(OWN/'PREPARED.json',prepared)
    print(json.dumps({'prepared_only':True,'targets':11,'parents':10,'new':1,'protected':len(protected),
        'dependencies':len(dependencies),'revisions':len(revisions),'formal_mutations':0,
        'prepared_pin':pin(blob(OWN/'PREPARED.json'))},ensure_ascii=False))


if __name__ == '__main__':main()
