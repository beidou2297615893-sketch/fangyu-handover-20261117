"""Root fixed two-file native successor promotion; no business source apply."""
from pathlib import Path
import ast, hashlib, json, os, stat, subprocess, tempfile, uuid

PROJECT=Path('C:/积木软件工坊/项目/方隅公寓客户版')
WORK=PROJECT/'work';AUDITS=WORK/'product-upgrade-20261009/audits'
OWN=WORK/'source51-root-integration'
RECEIPT=AUDITS/'source51-native-installed.json'
FAILED=AUDITS/'source51-native-install-failed.json'
NEW_HELPER=WORK/'desktop-self-use-entry/next_open_source51.py'
LAUNCHER=WORK/'desktop-self-use-entry/source_next_open_launcher.py'
INSTALL_AUTHORIZED=False

raw=(AUDITS/'join-source44-reviewed.py').read_bytes()
assert len(raw)==9601 and hashlib.sha256(raw).hexdigest().upper()=='5F5E3EA22AF7C1FA0FEA71CFEFDA12A9D669C190D5470960901029BF8F4750FB'
names={'blob','pin','expected','no_link_parent','prepared_temp'}
nodes=[x for x in ast.parse(raw).body if isinstance(x,ast.FunctionDef) and x.name in names]
assert len(nodes)==5 and {x.name for x in nodes}==names
exec(compile(ast.Module(body=nodes,type_ignores=[]),'source44-five-reviewed-helpers','exec'),globals())

command="$ErrorActionPreference='Stop'; Get-CimInstance Win32_Process | Where-Object { $_.Name -in @('python.exe','pythonw.exe') } | ForEach-Object { if ([string]::IsNullOrWhiteSpace($_.CommandLine)) { 'unknown' } elseif ($_.CommandLine -like '*方隅公寓客户版*desktop-self-use-entry*source_next_open_launcher.py*' -or $_.CommandLine -like '*方隅公寓客户版*desktop-self-use-entry*next_open_source51.py*' -or $_.CommandLine -like '*方隅公寓客户版*desktop-self-use-entry*next_open_source.py*') { 'normal-opening-live' } } | ConvertTo-Json -Compress"


def absent():
    result=subprocess.run(['powershell.exe','-NoProfile','-NonInteractive','-Command',command],
        capture_output=True,encoding='utf-8',errors='replace',timeout=15,
        creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
    if result.returncode or result.stderr.strip() or result.stdout.strip():
        raise ValueError('normal wrapper opening live or unknown; preserved')


def main():
    if INSTALL_AUTHORIZED is not True:raise ValueError('native promotion draft is not authorized')
    if os.name!='nt':raise ValueError('fixed Windows native promotion only')
    if os.path.lexists(RECEIPT) or os.path.lexists(FAILED):raise ValueError('prior installation evidence preserved')
    peer=WORK/'source51-native-independent-review/FINAL-DELTA-REVIEW.md'
    peer_pin={'bytes':5640,'sha256':'8DA31D0A05F0DBCD3619991F4B526780818F8A14067BBBC557D10BF9E62B7899'}
    expected(peer,peer_pin)
    original_helper=WORK/'desktop-self-use-entry/next_open_source.py'
    original_pin={'bytes':18590,'sha256':'6DD31FBCB9864272C329C146DD7EA3E9F74F334131F84DDFEB5E3D63ED8BB611'}
    expected(original_helper,original_pin)
    graph=json.loads(expected(OWN/'FINAL-GRAPH.json',{'bytes':1143,'sha256':'CA2BE24A9E46191526521ADFFEFEE32D5F6B75F86F8A026028B5647B825BFE21'}))
    assert graph['schema']=='source51_root_final_graph_uninstalled_v1' and graph['targets']==11 and graph['protected']==459
    for filename,key in (('source51-final-root-read.json','gate_pin'),('source51-manifest.json','manifest_pin'),
        ('join-source51-reviewed.py','CAS_pin')):expected(AUDITS/filename,graph[key])
    items=[
        {'target':NEW_HELPER,'candidate':OWN/'next_open_source51-final.py','parent':None,
            'final':{'bytes':14697,'sha256':'8540B5A0AE7572E5C2DC8A550AD74BA0918FF931C09945E7F802E0FB00F6EEF0'}},
        {'target':LAUNCHER,'candidate':OWN/'source_next_open_launcher-final.py',
            'parent':{'bytes':4238,'sha256':'ACDC026618A717A8F87CDE4FDD654819D0B2DC7EF87CF517FB8FFFF57682D599'},
            'final':{'bytes':4626,'sha256':'AA029206565CA20227131E06C200FBAA385C909CA5C21B274CA83477F1992176'}},
    ]
    assert graph['helper_candidate_pin']==items[0]['final'] and graph['launcher_candidate_pin']==items[1]['final']
    changes=[]
    for row in items:
        no_link_parent(row['target'])
        if row['parent'] is None:
            if os.path.lexists(row['target']):raise ValueError('new helper already exists')
            before=None
        else:before=expected(row['target'],row['parent'])
        changes.append((row,before,expected(row['candidate'],row['final'])))
    absent()
    backup=PROJECT/'backups/source51-native'/uuid.uuid4().hex
    no_link_parent(backup.parent);backup.mkdir(parents=True)
    temporaries=[];attempted=[];records=[]
    try:
        for row,before,after in changes:
            saved=backup/row['target'].name
            if before is not None:
                saved.write_bytes(before);expected(saved,row['parent'])
            records.append({'path':str(row['target']),'parent':row['parent'],'pin':row['final'],
                'backup':str(saved) if before is not None else None})
            temporaries.append(prepared_temp(row['target'],after))
        absent();expected(original_helper,original_pin)
        for (row,before,after),temporary in zip(changes,temporaries):
            target=row['target'];no_link_parent(target);expected(temporary,row['final'])
            if before is None:
                if os.path.lexists(target):raise ValueError('new helper appeared before rename')
            else:expected(target,row['parent'])
            attempted.append((row,before,after))
            if before is None:os.rename(temporary,target)
            else:os.replace(temporary,target)
            expected(target,row['final'])
        expected(original_helper,original_pin)
        value={'schema':'source51_native_installed_v1','source_batch':51,'files':records,
            'graph_pin':pin(blob(OWN/'FINAL-GRAPH.json')),'final_delta_review_pin':peer_pin,
            'source50_helper_pin':original_pin,'source50_business_apply_calls':0,'source51_business_apply_calls':0,
            'original_App_started_or_stopped':False,'marker_or_platform_grants_changed':False,
            'database_or_session_copied':False,'desktop_shortcuts_changed':False,
            'fixed_flags':['-X','utf8','-B','-I'],'commercial_complete':False}
        temp=prepared_temp(RECEIPT,(json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode('utf-8'))
        temporaries.append(temp);os.rename(temp,RECEIPT)
        print(json.dumps({'installed':True,'files':2,'backup':str(backup),'receipt_pin':pin(blob(RECEIPT)),
            'business_apply_calls':0},ensure_ascii=False))
    except BaseException as error:
        rollback=[]
        for row,before,after in reversed(attempted):
            try:
                target=row['target'];no_link_parent(target)
                current=blob(target) if target.exists() else None
                if current==before:rollback.append({'path':str(target),'no_change':True});continue
                if current!=after:raise ValueError('foreign drift retained')
                if before is None:target.unlink()
                else:
                    restore=prepared_temp(target,before);temporaries.append(restore)
                    expected(target,row['final']);os.replace(restore,target);expected(target,row['parent'])
                rollback.append({'path':str(target),'restored':True})
            except BaseException as fault:
                rollback.append({'path':str(row['target']),'held':True,'error_type':type(fault).__name__})
        with FAILED.open('x',encoding='utf-8') as out:
            out.write(json.dumps({'schema':'source51_native_install_failed_v1','failed':True,
                'error_type':type(error).__name__,'backup':str(backup),'rollback':rollback},ensure_ascii=False,indent=2)+'\n')
        raise
    finally:
        for temporary in temporaries:temporary.unlink(missing_ok=True)


if __name__=='__main__':main()
