"""Build an uninstalled successor from the exact reviewed native loader."""
import hashlib
from pathlib import Path

PROJECT = Path('C:/积木软件工坊/项目/方隅公寓客户版')
PARENT = PROJECT/'work/desktop-self-use-entry/source_next_open_launcher.py'
OUTPUT = PROJECT/'work/source51-root-integration/source_next_open_launcher.py'
raw = PARENT.read_bytes()
assert len(raw) == 4238
assert hashlib.sha256(raw).hexdigest().upper() == 'ACDC026618A717A8F87CDE4FDD654819D0B2DC7EF87CF517FB8FFFF57682D599'
text = raw.decode('utf-8')
replacements = (
    ('"""Prepared fixed wrapper; no execution or installation has been authorized here."""',
     '"""Uninstalled Source51 successor draft; its reviewed coordinator pin is absent."""'),
    ("HELPER = PROJECT/'work/desktop-self-use-entry/next_open_source.py'",
     "HELPER = PROJECT/'work/desktop-self-use-entry/next_open_source.py'\nSUCCESSOR = PROJECT/'work/desktop-self-use-entry/next_open_source51.py'\nSUCCESSOR_PIN = None"),
)
# Two call sites have different indentation; transform them separately so the
# reviewed _load function is not reconstructed or changed.
for old, new in replacements:
    assert text.count(old) == 1
    text = text.replace(old, new, 1)
old = "                entry_pin = helper.reviewed_entry_pin_if_joined() or entry_pin"
assert text.count(old) == 1
text = text.replace(old, "                successor = _load(SUCCESSOR, SUCCESSOR_PIN, 'source51_fixed_next_open_metadata')\n                entry_pin = successor.reviewed_entry_pin_if_joined(helper) or entry_pin", 1)
old = "        entry_pin = helper.reviewed_entry_pin_if_joined() or entry_pin"
assert text.count(old) == 1
text = text.replace(old, "        successor = _load(SUCCESSOR, SUCCESSOR_PIN, 'source51_fixed_next_open')\n        entry_pin = successor.reviewed_entry_pin_if_joined(helper) or entry_pin", 1)
old = '        result = helper.before_normal_open(entry)'
assert text.count(old) == 1
text = text.replace(old, '        result = successor.before_normal_open(entry, helper)', 1)
compile(text, str(OUTPUT), 'exec')
OUTPUT.write_bytes(text.encode('utf-8'))
print('uninstalled draft built; _load reused verbatim; successor pin absent')
