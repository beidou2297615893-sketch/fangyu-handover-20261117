# Source51 后继装载约束

Root 仅做两路作者候选之外的接线准备，未改当前 App/SOURCE/入口或实际装载。本轮仅新增这一计划，不是装载通过证据。

实际父约束已定位：Source50 的 PREPARED.json 保护 cloud/workspace/service.cjs；当前 desktop_entry.py 的 HOST_PINS 固定 self_operating_read.py；Source50 helper 永久复核其55目标且其 entry_pin 检查接口由当前薄launcher调用。因此店级云service不能提前改，Dy来源接线也不能仅复制Python/MJS后留下旧HOST pin。

候选开发、必要行为代表、非作者CODE/因果审核可以持续独立推进，不等待现窗切换。正式合入必须读取真实Source50receipt并绑定真实50结果为父；Source51最小目标以两作者最后冻结集合为准，再加必要原生entry pin目标，不能借此重扫既过矩阵。

后继薄入口优先复用已经审核的Source50正常下一开/原实例启动锁/固定 -X utf8 -B -I/已检查原始字节执行/备份CAS/未知不重apply机制。允许原正常开启先完成50，再在业务加载之前、真实父和同原启动锁下装载已独审51；若51尚未审核准备好，正常打开50，后续另次正常开启51。两种状态不得混淆，不要求用户反复人工回答，不强停/F5/额外窗口。

后继入口须处理已应用51的未来正常打开：不能让旧50 helper以55目标必须仍是50的要求误拒已审51，也不能绕开50失败或未知状态。只凭真实完整51receipt/固定manifest/entry pin决定后继，缺少回执或STARTED未知保持原号；禁止基于SOURCE版本字符串/PID/elapsed猜测合入。旧50图、回执、失败与备份保留，不能直接改旧批准门使其看似通过。

check-only保持0业务导入/源修改/锁写/平台模型；普通打开不得自动平台升级/恢复、改marker或授新用途。当前正式仍49+49b，Source50本体尚未核到实际receipt，Source51尚未冻结与独审；本计划不能成为先改源的授权回执。

Source51 code封闭后，Root只准备最小后继入口差异，非作者审该差异及自有OS锁/状态代表，完成一次必要检查后直接准备激活；不重50旧QA，也不把录制、本机工程或源码装载称完整商业验收。

2026-10-14 Root已读原helper的真实常量和调用点：STARTED固定source50-next-open-started.json，失败文件由CAS写为source50-join-failed.json；此前只检查过猜测source50-next-open-failed.json不存在，不能据该猜测证明无失败。正常51协调器保持原50 helper/script字节，复用其固定_plan/_readback/_exclusive_existing_lock/_start_once，只接正常开启中的先50后51。50 helper原before_normal_open在成功后直接exec entry，故后继协调器须复用其必要接口而不是在其exec之后猜测续接。51已成功的后续开启按真实50原回执与55目标图、51实际覆盖集合组合核对；不能调用旧50全55物理字节相等来误拒51，也不能放松50原回执或未知规则。外置协调器/launcher不进入50业务目标图，其自身安装另做精确备份与非作者读回。

Root已全文读取独立REVIEW-FOCUS.md（8471 / 9897D0059BA20461FFB7D76E390A6AAF1839ACF0796E6F9103F6B4EE4540B369），向两作者转交完整来源身份和共享fresh/混合batch/DTO风险。商业作者报告本轮legacy/v2最难代表通过，正在补exact FROZEN；该消息不是Root冻结审或正式合入通过。
