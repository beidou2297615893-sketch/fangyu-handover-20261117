"""One supplemental real Windows unknown-process seam; no repeated stories."""
import ast,hashlib,json,traceback,uuid
from pathlib import Path
OWN=Path(__file__).absolute().parent
CARRIER=OWN/'state-story.py'
tree=ast.parse(CARRIER.read_bytes());body=[]
for node in tree.body:
    if isinstance(node,ast.Assign) and isinstance(node.targets[0],ast.Name) and node.targets[0].id=='RESULTS':break
    body.append(node)
scope={'__name__':'owned_fixture_definitions','__file__':str(CARRIER)}
exec(compile(ast.Module(body=body,type_ignores=[]),str(CARRIER),'exec'),scope)
f=scope['Fixture']('real-unknown-windows-process');path=scope['RUN']/('UNKNOWN-OS-'+uuid.uuid4().hex+'.json')
try:
    f.seed50();count=f.counts.copy();scope['put'](f.data/'running.json',json.dumps({**f.running,'pid':4}).encode())
    entry=f.entry_module();actual=entry.pid_state(4);report=entry.preflight();outcome=f.normal()
    assert actual=='unknown' and report['state']=='held_unknown_process' and outcome['decision']=='held' and f.counts==count
    value={'schema':'source51_unknown_real_Windows_state_v1','status':'PASS','real_Windows_pid_state':'unknown',
        'process_metadata_query_only':True,'preflight_state':report['state'],'outcome':outcome,'delta_invocations':0,
        'fixture':f.result(),'carrier_pin':scope['pin'](CARRIER.read_bytes()),'supplement_pin':scope['pin'](Path(__file__).read_bytes())}
except BaseException:
    scope['js'](path,{'status':'FAIL','traceback':traceback.format_exc()});raise
finally:f.close()
scope['js'](path,value);print(json.dumps({'path':str(path),'pin':scope['pin'](path.read_bytes()),'status':'PASS'}))
