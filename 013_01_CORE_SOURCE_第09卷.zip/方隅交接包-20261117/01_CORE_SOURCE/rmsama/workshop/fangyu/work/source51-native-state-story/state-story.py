"""New Source51 state seams only. All constants bind synthetic owned files.

Source50 CAS is an explicit recorder. Source51 CAS/coord/launcher/legacy lock
and original entry control functions are not patched. Exec and faulting FS
edges are recorded/injected, not real App actions. Each run preserves evidence.
"""
import ast,contextlib,ctypes,hashlib,importlib.util,json,msvcrt,os,stat,subprocess,sys,traceback,types,uuid
from pathlib import Path
OWN=Path(__file__).absolute().parent
SNAP=OWN/'snapshot'
RUN=OWN/'runs'/uuid.uuid4().hex
RUN.mkdir(parents=True)
SNAPSHOT=json.loads((OWN/'SNAPSHOT.json').read_bytes())
AST_CHECKS=[]
def pin(raw):return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest().upper()}
def js(path,value):
    path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('x',encoding='utf-8') as stream:stream.write(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
    return pin(path.read_bytes())
def put(path,raw):path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(raw);return pin(raw)
def exp(value):
    if isinstance(value,Path):return ast.Call(func=ast.Name(id='Path',ctx=ast.Load()),args=[ast.Constant(str(value))],keywords=[])
    if isinstance(value,dict):return ast.Dict(keys=[exp(x) for x in value],values=[exp(x) for x in value.values()])
    if isinstance(value,tuple):return ast.Tuple(elts=[exp(x) for x in value],ctx=ast.Load())
    if isinstance(value,list):return ast.List(elts=[exp(x) for x in value],ctx=ast.Load())
    if isinstance(value,frozenset):return ast.Call(func=ast.Name(id='frozenset',ctx=ast.Load()),args=[ast.Set(elts=[exp(x) for x in sorted(value)])],keywords=[])
    return ast.Constant(value)
def skeleton(tree,names):
    tree=ast.parse(ast.unparse(tree))
    for node in tree.body:
        if isinstance(node,ast.Assign) and isinstance(node.targets[0],ast.Name) and node.targets[0].id in names:node.value=ast.Constant(None)
    return ast.dump(tree)
def bound(name,path,constants):
    raw=(SNAP/name).read_bytes();tree=ast.parse(raw);original=skeleton(tree,set(constants));seen=set()
    for node in tree.body:
        if isinstance(node,ast.Assign) and isinstance(node.targets[0],ast.Name) and node.targets[0].id in constants:
            key=node.targets[0].id;node.value=exp(constants[key]);seen.add(key)
    assert seen==set(constants),(name,set(constants)-seen)
    ast.fix_missing_locations(tree)
    assert skeleton(tree,set(constants))==original
    data=(ast.unparse(tree)+'\n').encode('utf-8');compile(data,str(path),'exec');put(path,data)
    AST_CHECKS.append({'snapshot':name,'bound_path':str(path),'snapshot_pin':pin(raw),'fixture_pin':pin(data),
        'assignment_bindings_only':sorted(constants),'control_AST_unchanged':True})
    return data
def load(path):
    module=types.ModuleType('fixture_'+uuid.uuid4().hex);module.__file__=str(path)
    exec(compile(path.read_bytes(),str(path),'exec'),module.__dict__);return module
def dead_pid():
    child=subprocess.Popen([sys.executable,'-B','-c','pass'],creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0));child.wait();return child.pid
class FreshExecRecorded(BaseException):pass

class Fixture:
    def __init__(self,name):
        self.root=RUN/name;self.work=self.root/'work';self.audits=self.work/'product-upgrade-20261009/audits'
        self.audits.mkdir(parents=True);(self.root/'backups').mkdir()
        self.pilot=self.work/'self-operating-pilot';self.data=self.pilot/'data';self.data.mkdir(parents=True)
        self.entry=self.work/'desktop-self-use-entry/desktop_entry.py';self.entry.parent.mkdir()
        self.src=self.work/'app/src';self.cloud=self.work/'cloud/workspace';self.cloud.mkdir(parents=True)
        self.iid='d075ac9c039e44038ddbc6f3e753d73c';self.counts={'50':0,'51':0};self.events=[];self.execs=[]
        self.paths51=[self.work/path for path in ast.literal_eval(next(n.value for n in ast.parse((SNAP/'join-source51-reviewed.py').read_bytes()).body if isinstance(n,ast.Assign) and n.targets[0].id=='TARGET_RELATIVE'))]
        self.new=self.cloud/'shared_store_scope.cjs'
        host_rel=('app.py','desktop.py','platform_cli.py','assistant/self_operating_read.py','assistant/owner_normal_close.py','assistant/owner_primary_entry.py','assistant/owner_instance_platform_upgrade.py','assistant/owner_instance_platform_upgrade_writer.py')
        self.host=[self.src/x for x in host_rel]
        for path in set(self.paths51[:-1]+self.host)-{self.new}:put(path,('# SYNTHETIC parent '+path.name+'\n').encode())
        self.before51={path:path.read_bytes() for path in self.paths51 if path not in (self.new,self.entry)}
        self.after51={path:('# SYNTHETIC final51 '+path.name+'\n').encode() for path in self.paths51 if path!=self.entry}
        self.app50=b'# SYNTHETIC Source50 app fixture; never executed\n'
        runtime=self.work/'synthetic-runtime';runtime.mkdir();put(runtime/'platform-cli.exe',b'synthetic metadata only, not executable')
        put(self.data/'workspace.sqlite3',b'SYNTHETIC empty metadata stand-in; no SQLite connection')
        put(self.data/'instance.lock',b'original synthetic byte lock')
        self.dead=dead_pid();self.running={'pid':self.dead,'url':'http://127.0.0.1:18001','mode':'headless-test'}
        put(self.data/'running.json',(json.dumps(self.running)+'\n').encode())
        marker=(json.dumps({'schema':'owner_read_instance_v1','instance_id':self.iid,'company':'SYNTHETIC contract fixture'})+'\n').encode()
        put(self.pilot/'self-operating-instance.json',marker)
        binding=(json.dumps({'schema':'owner_read_data_v1','instance_id':self.iid})+'\n').encode();put(self.data/'owner-data-instance.json',binding)
        review=b'SYNTHETIC public metadata review stand-in\n';put(self.pilot/'component-review.json',review)
        # Original entry preflight find_spec only; no GUI library imported.
        put(self.root/'webview.py',b'# synthetic availability marker only; not GUI\n')
        base_constants={'PROJECT':self.root,'SOURCE':self.src,'PILOT':self.pilot,'RUNTIME':runtime,'REVIEW':self.pilot/'component-review.json',
            'REVIEW_SHA':pin(review)['sha256'],'ORIGINAL_MARKER_SHA':pin(marker)['sha256'],
            'PINS':{self.data/'owner-data-instance.json':pin(binding)['sha256'],self.pilot/'component-review.json':pin(review)['sha256']},
            '_HOST_PATHS':frozenset(self.host)}
        def entry_bytes(phase):
            host_values={p:pin(p.read_bytes())['sha256'] for p in self.host}
            if phase>=50:host_values[self.src/'app.py']=pin(self.app50)['sha256']
            if phase>=51:host_values[self.src/'assistant/self_operating_read.py']=pin(self.after51[self.src/'assistant/self_operating_read.py'])['sha256']
            return bound('desktop_entry.py',self.root/('entry'+str(phase)+'.py'),{**base_constants,'HOST_PINS':host_values})
        self.entry_before=entry_bytes(49);self.entry50=entry_bytes(50);self.entry51=entry_bytes(51);put(self.entry,self.entry_before)
        self.after51[self.entry]=self.entry51
        self.base_existing=[self.src/'assistant/owner_company_receipt_bridge.py',self.src/'web/workspace/self-operating-read.mjs',self.src/'app.py',self.src/'assistant/owner_douyin_read.py',self.entry]
        for path in self.base_existing:
            if not path.exists():put(path,('# SYNTHETIC parent50 '+path.name+'\n').encode())
        self.base_parents={p:p.read_bytes() for p in self.base_existing}
        self.base_final={p:('# SYNTHETIC final50 '+p.name+'\n').encode() for p in self.base_existing}
        self.base_final[self.src/'app.py']=self.app50;self.base_final[self.entry]=self.entry50
        for number in range(50):self.base_final[self.work/f'synthetic-source50-runtime/file-{number:02}.txt']=f'SYNTHETIC new50 {number}\n'.encode()
        self.base_paths=list(self.base_final);assert len(self.base_paths)==55
        overlap=set(self.base_paths)&set(self.paths51)
        for path in overlap:self.before51[path]=self.base_final[path]
        original_paths=[p for p in self.paths51 if p not in overlap and p!=self.new]
        original_paths += [p for p in self.host if p not in original_paths and p not in self.base_paths]
        original_paths += [self.pilot/'self-operating-instance.json',self.pilot/'component-review.json',self.data/'owner-data-instance.json']
        for number in range(367-len(original_paths)):
            p=self.work/f'synthetic-protected/source-{number:03}.txt';put(p,f'SYNTHETIC protected {number}\n'.encode());original_paths.append(p)
        assert len(set(original_paths))==367
        self.original_protected=[{'path':str(p),'pin':pin(p.read_bytes())} for p in original_paths]
        self.protected_probe=next(p for p in original_paths if p not in self.paths51 and 'synthetic-protected' in str(p))
        self.prepared50=self.work/'overnight-commercial-20261014/source50-preparation/PREPARED.json'
        prep50={'schema':'source50_owner_prepared_v1','source_batch':50,'join_authorized':False,'instance_id':self.iid,'protected':self.original_protected,
            'targets':[{'target':str(p),'parent':pin(self.base_parents[p]) if p in self.base_parents else None,'candidate_pin':pin(raw)} for p,raw in self.base_final.items()]}
        prepared50_pin=js(self.prepared50,prep50)
        plan_path=self.root/'RECORDED-50-PLAN.json'
        js(plan_path,{'synthetic_recorded_CAS':True,'targets':[{'target':str(p),'before_hex':self.base_parents[p].hex() if p in self.base_parents else None,'after_hex':raw.hex()} for p,raw in self.base_final.items()]})
        recorder=("# EXPLICIT SYNTHETIC Source50 CAS recorder, not original CAS.\nimport json,os,hashlib\nfrom pathlib import Path\nROOT=Path("+repr(str(self.root))+" )\n"
          "def pin(v):return {'bytes':len(v),'sha256':hashlib.sha256(v).hexdigest().upper()}\n"
          "A=ROOT/'work/product-upgrade-20261009/audits'\nM=json.loads((A/'source50-manifest.json').read_bytes())\nG=json.loads((A/'source50-final-root-read.json').read_bytes())\nP=json.loads((ROOT/'RECORDED-50-PLAN.json').read_bytes())\nB=ROOT/'backups/recorded-source50';B.mkdir()\nrows=[]\n"
          "for row in P['targets']:\n t=Path(row['target']);before=bytes.fromhex(row['before_hex']) if row['before_hex'] is not None else None;after=bytes.fromhex(row['after_hex']);bp=None\n if before is not None:\n  assert t.read_bytes()==before;bp=B/t.relative_to(ROOT/'work');bp.parent.mkdir(parents=True,exist_ok=True);bp.write_bytes(before)\n t.parent.mkdir(parents=True,exist_ok=True);t.write_bytes(after)\n rows.append({'target':str(t),'parent':pin(before) if before is not None else None,'candidate':pin(after),'backup':str(bp) if bp is not None else None})\n"
          "prepared=ROOT/'work/overnight-commercial-20261014/source50-preparation/PREPARED.json'\nV={'schema':'source50_owner_joined_v1','source_batch':50,'approval_sha256':M['approval_pin']['sha256'],'authority_manifest_pin':pin((A/'source50-manifest.json').read_bytes()),'prepared_manifest_pin':pin(prepared.read_bytes()),'targets':rows,'protected':json.loads(prepared.read_bytes())['protected'],'App_restarted':False,'marker_changed':False,'customer_database_opened':False,'session_copied':False,'deployed':False,'commercial_complete':False,'synthetic_recorded_CAS':True}\n"
          "with (A/'source50-joined.json').open('x',encoding='utf-8') as stream:stream.write(json.dumps(V,ensure_ascii=False,indent=2)+'\\n')\n")
        self.join50=self.audits/'join-source50-reviewed.py';put(self.join50,recorder.encode())
        common={'join_authorized':True,'independent_code_review_passed':True,'independent_actual_qa_review_passed':True,'join_script_review_passed':True,
            'next_normal_open_only':True,'customer_database_opened':False,'session_copied':False,'deployment_or_packaging_performed':False,'fixture_only_synthetic_authorization':True,'additional_evidence':[]}
        gate50={'schema':'source50_final_root_read','source_batch':50,**common,'join_script_pin':pin(self.join50.read_bytes()),'prepared_manifest_pin':prepared50_pin}
        gate50_pin=js(self.audits/'source50-final-root-read.json',gate50)
        base={'schema':'source50_next_open_manifest_v1','source_batch':50,'join_authorized':True,'instance_id':self.iid,
            'approval_pin':gate50_pin,'join_script_pin':pin(self.join50.read_bytes()),'targets':[{'path':str(p),'final_pin':pin(v)} for p,v in self.base_final.items()]}
        self.base_pin=js(self.audits/'source50-manifest.json',base)
        put(self.audits/'join-source44-reviewed.py',(SNAP/'join-source44-reviewed.py').read_bytes())
        self.join51=self.audits/'join-source51-reviewed.py'
        bound('join-source51-reviewed.py',self.join51,{'PROJECT':self.root,'BASE_MANIFEST_PIN':self.base_pin,'JOIN_AUTHORIZED':True})
        own51=self.work/'source51-root-integration';candidates=own51/'candidates';candidates.mkdir(parents=True)
        targets=[]
        for path in self.paths51:
            candidate=candidates/path.relative_to(self.work);put(candidate,self.after51[path])
            targets.append({'target':str(path),'candidate':str(candidate),'parent':None if path==self.new else pin(self.before51[path]),'candidate_pin':pin(self.after51[path])})
        closed={Path(x['path']):x['pin'] for x in self.original_protected}
        closed.update({p:pin(v) for p,v in self.base_final.items()})
        for p in self.paths51:closed.pop(p,None)
        self.protected=[{'path':str(p),'pin':v} for p,v in sorted(closed.items())]
        deps=[x for x in self.protected if 'synthetic-protected' in x['path']][:2]
        prep={'schema':'source51_owner_prepared_v1','source_batch':51,'join_authorized':False,'instance_id':self.iid,'base_manifest_pin':self.base_pin,
            'targets':targets,'protected':self.protected,'candidate_dependencies':deps,'evidence':[],'new_directories':[],'fixture_only_synthetic_authorization':True}
        prepared_pin=js(own51/'PREPARED.json',prep)
        gate51={'schema':'source51_final_root_read','source_batch':51,**common,'base_manifest_pin':self.base_pin,'join_script_pin':pin(self.join51.read_bytes()),'prepared_manifest_pin':prepared_pin}
        gate51_pin=js(self.audits/'source51-final-root-read.json',gate51)
        self.authority={'schema':'source51_next_open_manifest_v1','source_batch':51,'join_authorized':True,'instance_id':self.iid,'base_manifest_pin':self.base_pin,
            'approval_pin':gate51_pin,'join_script_pin':pin(self.join51.read_bytes()),'targets':[{'path':x['target'],'parent_pin':x['parent'],'final_pin':x['candidate_pin']} for x in targets],'protected':self.protected}
        self.authority_pin=js(self.audits/'source51-manifest.json',self.authority)
        self.legacy_path=self.entry.parent/'next_open_source.py'
        bound('next_open_source.py',self.legacy_path,{'PROJECT':self.root,'ROOT_MANIFEST_PIN':self.base_pin,'TARGET_PATHS':tuple(self.base_paths)})
        self.coord_path=self.entry.parent/'next_open_source51.py'
        bound('next_open_source51.py',self.coord_path,{'PROJECT':self.root,'BASE_MANIFEST_PIN':self.base_pin,'JOIN_AUTHORIZED':True,'MANIFEST_PIN':self.authority_pin,'TARGET_PATHS':tuple(self.paths51)})
        self.launcher_path=self.entry.parent/'source_next_open_launcher.py'
        bound('source_next_open_launcher.py',self.launcher_path,{'PROJECT':self.root,'SUCCESSOR_PIN':pin(self.coord_path.read_bytes()),'HELPER_PIN':pin(self.legacy_path.read_bytes()),'ENTRY_PARENT_PIN':pin(self.entry_before)})
        self.launcher=load(self.launcher_path)
        self.legacy=self.launcher._load(self.legacy_path,pin(self.legacy_path.read_bytes()),'legacy_'+uuid.uuid4().hex)
        self.coord=self.launcher._load(self.coord_path,pin(self.coord_path.read_bytes()),'coord_'+uuid.uuid4().hex)
        self.old_sys_path=list(sys.path);sys.path.insert(0,str(self.root))
    def close(self):sys.path[:]=self.old_sys_path
    def entry_module(self):return self.launcher._load(self.entry,pin(self.entry.read_bytes()),'entry_'+uuid.uuid4().hex)
    def profile(self,frame,event,arg):
        if event!='call':return
        path=frame.f_globals.get('__file__')
        if path==str(self.join50) and frame.f_code.co_name=='<module>':self.counts['50']+=1
        if path==str(self.join51) and frame.f_code.co_name=='main':self.counts['51']+=1
    @contextlib.contextmanager
    def io(self,fault=None,foreign=False):
        real_replace,real_rename,real_exec=os.replace,os.rename,os.execv
        def replace(source,target):
            result=real_replace(source,target)
            if Path(target) in self.paths51:self.events.append({'operation':'replace','target':str(target)})
            return result
        def rename(source,target):
            result=real_rename(source,target)
            if Path(target) in self.paths51:self.events.append({'operation':'rename','target':str(target)})
            if fault=='bad_parent_after_started' and Path(target)==self.audits/'source51-next-open-started.json':
                put(self.cloud/'index.js',b'SYNTHETIC BAD PARENT\n')
            if fault=='after_new_rename' and Path(target)==self.new:
                if foreign:self.paths51[0].write_bytes(b'SYNTHETIC FOREIGN CHANGE; must not rollback\n')
                raise OSError('synthetic OS interruption after actual new-source rename')
            return result
        def execv(executable,argv):
            assert argv==[sys.executable,'-X','utf8','-B','-I',str(self.entry)]
            with (self.data/'instance.lock').open('r+b') as stream:
                stream.seek(0);msvcrt.locking(stream.fileno(),msvcrt.LK_NBLCK,1)
                stream.seek(0);msvcrt.locking(stream.fileno(),msvcrt.LK_UNLCK,1)
            self.execs.append({'argv':argv,'original_byte_lock_released':True,'real_App_started':False})
            raise FreshExecRecorded()
        os.replace,os.rename,os.execv=replace,rename,execv;sys.setprofile(self.profile)
        try:yield
        finally:sys.setprofile(None);os.replace,os.rename,os.execv=real_replace,real_rename,real_exec
    def normal(self,use_launcher=False,fault=None,foreign=False):
        prior=list(sys.argv);sys.argv=[str(self.launcher_path)]
        try:
            with self.io(fault,foreign):
                try:return self.launcher.main() if use_launcher else self.coord.before_normal_open(self.entry_module(),self.legacy)
                except FreshExecRecorded:return {'decision':'fresh_exec_edge_recorded','App_started':False}
        finally:sys.argv=prior
    def seed50(self):
        with self.legacy._exclusive_existing_lock(self.entry_module()):
            base=self.legacy._plan();self.legacy._start_once(base)
            with self.io():self.coord._invoke(self.legacy,self.join50,base['join_script_pin'],base['approval_pin']['sha256'])
            self.legacy._readback(base)
    def actual51_direct(self,fault=None,foreign=False):
        prior=list(sys.argv)
        try:
            with self.legacy._exclusive_existing_lock(self.entry_module()):
                manifest,base=self.coord._plan(self.legacy);base_pin=self.coord._base_receipt(self.legacy,manifest,base,False)
                with self.io(fault,foreign):
                    self.coord._start_once(self.legacy,manifest,base_pin)
                    self.coord._invoke(self.legacy,self.join51,manifest['join_script_pin'],manifest['approval_pin']['sha256'])
        finally:sys.argv=prior
    def result(self):
        receipt=self.audits/'source51-joined.json';failure=self.audits/'source51-join-failed.json'
        value={'root':str(self.root),'invocations':dict(self.counts),'exec_edges':self.execs,'OS_events':self.events,
            'source50_receipt_pin':pin((self.audits/'source50-joined.json').read_bytes()) if (self.audits/'source50-joined.json').exists() else None,
            'source51_receipt_pin':pin(receipt.read_bytes()) if receipt.exists() else None,'failure_pin':pin(failure.read_bytes()) if failure.exists() else None,
            'staging_count':len(list(self.root.rglob('.source44-*.tmp'))),'new_exists':self.new.exists(),
            'source50_recorded':True,'fixture_only_synthetic_authorization':True,'real_App_started':False,'formal_mutations':0}
        return value
    def assert_success(self):
        receipt=json.loads((self.audits/'source51-joined.json').read_bytes())
        assert len(receipt['targets'])==11 and sum(x['backup'] is not None for x in receipt['targets'])==10
        for row in receipt['targets']:
            assert pin(Path(row['target']).read_bytes())==row['candidate']
            if row['backup'] is not None:assert pin(Path(row['backup']).read_bytes())==row['parent']
        assert receipt['protected']==self.protected
        for row in self.protected:assert pin(Path(row['path']).read_bytes())==row['pin']
        assert self.result()['staging_count']==0 and self.new.exists()
        assert [x['target'] for x in self.events if Path(x['target']) in self.paths51][-1]==str(self.entry)
        base=json.loads((self.audits/'source50-joined.json').read_bytes())
        assert len(base['targets'])==55 and sum(x['backup'] is not None for x in base['targets'])==5
        for row in base['targets']:
            if row['backup'] is not None:assert pin(Path(row['backup']).read_bytes())==row['parent']
        return {'actual_51_targets':11,'actual_51_parent_backups':10,'actual_51_new':1,'base_55_receipt':55,'base_recorded_parent_backups':5,
            'actual_original_protected_count':367,'actual_successor_protected_count':len(self.protected),'entry_last':True,'staging':0}

RESULTS=[]
def story(name,function):
    item={'name':name,'status':'running'}
    try:item.update(function());item['status']='PASS'
    except BaseException as error:
        item.update(status='FAIL',error_type=type(error).__name__,traceback=traceback.format_exc())
        js(RUN/(name+'-FIRST-FAIL-'+uuid.uuid4().hex+'.json'),item);raise
    js(RUN/(name+'-'+uuid.uuid4().hex+'.json'),item);RESULTS.append(item)

def first():
    f=Fixture('normal50to51')
    try:
        before=f.counts.copy();assert f.entry_module().preflight()['state']=='ready_for_original_native_main'
        outcome=f.normal(use_launcher=True)
        assert outcome['decision']=='fresh_exec_edge_recorded' and f.counts=={'50':1,'51':1}
        checks=f.assert_success();assert len(f.execs)==1 and f.execs[0]['original_byte_lock_released']
        return {'checks':checks,'normal_launcher_load':True,'outcome':outcome,'fixture':f.result()}
    finally:f.close()

def second():
    f=Fixture('already50-and-future-state');events=[]
    try:
        f.seed50();assert f.counts=={'50':1,'51':0}
        outcome=f.normal();assert outcome['decision']=='fresh_exec_edge_recorded' and f.counts=={'50':1,'51':1};f.assert_success()
        events.append({'case':'50_already_success_only51','delta_invoke50':0,'delta_invoke51':1})
        count=f.counts.copy();assert f.normal()['decision']=='continue' and f.counts==count
        assert f.coord.reviewed_entry_pin_if_joined(f.legacy)==pin(f.entry51)
        events.append({'case':'51_success_future_metadata_and_normal','decision':'continue','delta_invocations':0})
        for label,path in [('old50_protected',f.protected_probe),('final51',f.paths51[0]),('source50_original_receipt',f.audits/'source50-joined.json')]:
            raw=path.read_bytes();path.write_bytes(raw+b'\nSYNTHETIC TAMPER\n')
            assert f.normal()['decision']=='held' and f.counts==count
            try:f.coord.reviewed_entry_pin_if_joined(f.legacy)
            except Exception:pass
            else:raise AssertionError('metadata tamper accepted')
            js(RUN/(label+'-TAMPER-'+uuid.uuid4().hex+'.json'),{'case':label,'tampered_pin':pin(path.read_bytes()),'held':True,'delta_invocations':0})
            path.write_bytes(raw);events.append({'case':label,'decision':'held','delta_invocations':0})
        return {'events':events,'fixture':f.result()}
    finally:f.close()

def third():
    cases=[]
    for label,mode in [('unknown_started','started'),('failed_preserved','failed'),('live_original_main','alive'),('unknown_main_metadata','unknown'),('OS_lock_busy','busy')]:
        f=Fixture(label);holder=None
        try:
            f.seed50();count=f.counts.copy()
            if mode in ('started','failed'):js(f.audits/('source51-next-open-started.json' if mode=='started' else 'source51-join-failed.json'),{'SYNTHETIC_unknown':True})
            if mode=='alive':put(f.data/'running.json',json.dumps({**f.running,'pid':os.getpid()}).encode())
            if mode=='unknown':put(f.data/'running.json',json.dumps({**f.running,'pid':'unknown metadata'}).encode())
            if mode=='busy':
                code="import msvcrt,sys;f=open(sys.argv[1],'r+b');f.seek(0);msvcrt.locking(f.fileno(),msvcrt.LK_NBLCK,1);print('held',flush=True);sys.stdin.read(1);f.seek(0);msvcrt.locking(f.fileno(),msvcrt.LK_UNLCK,1);f.close()"
                holder=subprocess.Popen([sys.executable,'-B','-c',code,str(f.data/'instance.lock')],stdin=subprocess.PIPE,stdout=subprocess.PIPE,text=True,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0));assert holder.stdout.readline().strip()=='held'
            assert f.normal()['decision']=='held' and f.counts==count
            cases.append({'case':label,'held':True,'delta_invocations':0,'fixture':f.result()})
        finally:
            if holder is not None:holder.stdin.write('x');holder.stdin.flush();holder.wait(timeout=10)
            f.close()
    for label,fault,foreign in [('bad_parent','bad_parent_after_started',False),('after_actual_new_rename','after_new_rename',False),('foreign_change_rollback_refused','after_new_rename',True)]:
        f=Fixture(label)
        try:
            f.seed50()
            try:f.actual51_direct(fault,foreign)
            except Exception:pass
            else:raise AssertionError('failure accepted')
            assert (f.audits/'source51-next-open-started.json').exists() and (f.audits/'source51-join-failed.json').exists()
            failure=json.loads((f.audits/'source51-join-failed.json').read_bytes());failure_pin=pin((f.audits/'source51-join-failed.json').read_bytes())
            assert not (f.audits/'source51-joined.json').exists() and not f.new.exists() and f.result()['staging_count']==0
            if label=='bad_parent':assert not f.events and failure['backup'] is None and failure['rollback']==[]
            else:
                assert failure['backup'] is not None and len(failure['rollback'])==10
                assert sum(x['restored'] is False for x in failure['rollback'])==(1 if foreign else 0)
                for p in f.paths51:
                    if p==f.new:continue
                    if foreign and p==f.paths51[0]:assert p.read_bytes()==b'SYNTHETIC FOREIGN CHANGE; must not rollback\n'
                    else:assert p.read_bytes()==f.before51[p]
                assert len([p for p in Path(failure['backup']).rglob('*') if p.is_file() and p.name!='PREPARED.json'])==10
            count=f.counts.copy();assert f.normal()['decision']=='held' and f.counts==count
            assert pin((f.audits/'source51-join-failed.json').read_bytes())==failure_pin
            cases.append({'case':label,'actual_OS_fault':fault,'foreign_refused':foreign,'failure':failure,'second_open_held':True,'delta_invocations':0,'fixture':f.result()})
        finally:f.close()
    return {'cases':cases}

try:
    selected=[('03-unknown-and-rollback',third)] if sys.argv[1:]==['--story3-only'] else [('01-normal50to51',first),('02-future-readback',second),('03-unknown-and-rollback',third)]
    for name,fn in selected:story(name,fn)
    js(RUN/'AST-BINDINGS.json',{'checks':AST_CHECKS,'all_control_AST_unchanged':all(x['control_AST_unchanged'] for x in AST_CHECKS)})
    summary={'schema':'source51_native_owned_state_story_v1','status':'PASS','run':str(RUN),'stories':RESULTS,'story_selection':[x[0] for x in selected],
        'snapshot_pin':pin((OWN/'SNAPSHOT.json').read_bytes()),'carrier_pin':pin(Path(__file__).read_bytes()),
        'synthetic_source50_recorded_CAS':True,'source51_real_CAS_and_byte_OS_lock':True,'platforms_frozen_functionality_verified':False,
        'real_App_GUI_platform_or_model_started':False,'formal_source_or_data_mutations':0,'old_QA_rerun':False}
    js(RUN/'RESULT.json',summary);print(json.dumps({'status':'PASS','run':str(RUN),'result_pin':pin((RUN/'RESULT.json').read_bytes()),'story_count':3}))
except BaseException:
    js(RUN/('RUN-FAILED-'+uuid.uuid4().hex+'.json'),{'status':'FAIL','run':str(RUN),'completed':RESULTS,'traceback':traceback.format_exc()})
    raise
