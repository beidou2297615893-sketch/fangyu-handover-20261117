"""Uninstalled Source51 successor draft; fixed reviewed pins are still absent.

Only the normal native launcher will call this coordinator.  The original
Source50 helper and CAS remain byte-for-byte unchanged.  Nothing runs at import.
"""
import json
import os
import sys
from pathlib import Path

PROJECT = Path('C:/积木软件工坊/项目/方隅公寓客户版')
AUDITS = PROJECT/'work/product-upgrade-20261009/audits'
ENTRY = PROJECT/'work/desktop-self-use-entry/desktop_entry.py'
PILOT = PROJECT/'work/self-operating-pilot'
MANIFEST = AUDITS/'source51-manifest.json'
APPROVAL = AUDITS/'source51-final-root-read.json'
JOIN = AUDITS/'join-source51-reviewed.py'
RECEIPT = AUDITS/'source51-joined.json'
STARTED = AUDITS/'source51-next-open-started.json'
FAILED = AUDITS/'source51-join-failed.json'
BASE_FAILED = AUDITS/'source50-join-failed.json'
BASE_PREPARED = PROJECT/'work/overnight-commercial-20261014/source50-preparation/PREPARED.json'
INSTANCE_ID = 'd075ac9c039e44038ddbc6f3e753d73c'
BASE_MANIFEST_PIN = {'bytes': 17143, 'sha256': 'FA18DE22A451370BD49417A6315ED317134B261D615BED0622031379BEF57267'}

# Root fills these only after exact CODE/representative/CAS review.  This
# draft cannot authorize an invocation, even if somebody imports it manually.
JOIN_AUTHORIZED = False
MANIFEST_PIN = None
TARGET_PATHS = ()


def _proof(value):
    return (type(value) is dict and set(value) == {'bytes', 'sha256'}
        and type(value['bytes']) is int and value['bytes'] >= 0
        and type(value['sha256']) is str and len(value['sha256']) == 64
        and all(c in '0123456789ABCDEF' for c in value['sha256']))


def _plan(legacy):
    if JOIN_AUTHORIZED is not True or not _proof(MANIFEST_PIN) or not TARGET_PATHS:
        raise ValueError('fixed Source51 reviewed authority is absent')
    base = legacy._plan()
    if legacy.ROOT_MANIFEST_PIN != BASE_MANIFEST_PIN:
        raise ValueError('Source50 fixed predecessor changed')
    manifest = json.loads(legacy.expected(MANIFEST, MANIFEST_PIN))
    if (manifest.get('schema') != 'source51_next_open_manifest_v1'
        or manifest.get('source_batch') != 51 or manifest.get('join_authorized') is not True
        or manifest.get('instance_id') != INSTANCE_ID
        or manifest.get('base_manifest_pin') != BASE_MANIFEST_PIN
        or not _proof(manifest.get('approval_pin'))
        or not _proof(manifest.get('join_script_pin'))):
        raise ValueError('fixed successor manifest changed')
    targets = manifest.get('targets')
    if (type(targets) is not list or len(targets) != len(TARGET_PATHS)
        or any(type(row) is not dict or set(row) != {'path', 'parent_pin', 'final_pin'}
            or type(row['path']) is not str or not _proof(row['final_pin'])
            or (row['parent_pin'] is not None and not _proof(row['parent_pin'])) for row in targets)
        or {Path(row['path']) for row in targets} != set(TARGET_PATHS)
        or len({row['path'] for row in targets}) != len(targets) or ENTRY not in TARGET_PATHS):
        raise ValueError('exact successor target set changed')
    if any(path == PILOT or path.is_relative_to(PILOT) for path in TARGET_PATHS):
        raise ValueError('source successor cannot target the instance or data')
    protected = manifest.get('protected')
    if (type(protected) is not list
        or any(type(row) is not dict or set(row) != {'path', 'pin'}
            or type(row['path']) is not str or not _proof(row['pin']) for row in protected)
        or len({Path(row['path']) for row in protected}) != len(protected)
        or set(TARGET_PATHS) & {Path(row['path']) for row in protected}):
        raise ValueError('fixed successor protection set changed')
    gate = json.loads(legacy.expected(APPROVAL, manifest['approval_pin']))
    if (gate.get('schema') != 'source51_final_root_read' or gate.get('source_batch') != 51
        or gate.get('join_authorized') is not True
        or gate.get('independent_code_review_passed') is not True
        or gate.get('independent_actual_qa_review_passed') is not True
        or gate.get('join_script_review_passed') is not True
        or gate.get('next_normal_open_only') is not True
        or gate.get('base_manifest_pin') != BASE_MANIFEST_PIN
        or not _proof(gate.get('prepared_manifest_pin'))
        or gate.get('customer_database_opened') is not False
        or gate.get('session_copied') is not False
        or gate.get('deployment_or_packaging_performed') is not False
        or gate.get('join_script_pin') != manifest['join_script_pin']):
        raise ValueError('fixed Source51 deferred scope has not been approved')
    legacy.expected(JOIN, manifest['join_script_pin'])
    return manifest, base


def _base_receipt(legacy, manifest, base, applied):
    """Preserve the actual 50 receipt while validating only approved 51 overlays."""
    if os.path.lexists(BASE_FAILED):
        raise ValueError('Source50 original failure evidence requires Root recovery')
    raw = legacy.blob(legacy.RECEIPT)
    receipt = json.loads(raw)
    gate = json.loads(legacy.expected(legacy.APPROVAL, base['approval_pin']))
    prepared_pin = gate.get('prepared_manifest_pin')
    if not _proof(prepared_pin):
        raise ValueError('Source50 reviewed protection authority is absent')
    prepared = json.loads(legacy.expected(BASE_PREPARED, prepared_pin))
    if prepared.get('schema') != 'source50_owner_prepared_v1' or prepared.get('source_batch') != 50:
        raise ValueError('Source50 original protection graph changed')
    if (receipt.get('schema') != 'source50_owner_joined_v1'
        or receipt.get('source_batch') != 50
        or receipt.get('approval_sha256') != base['approval_pin']['sha256']
        or receipt.get('authority_manifest_pin') != BASE_MANIFEST_PIN
        or receipt.get('prepared_manifest_pin') != prepared_pin
        or receipt.get('protected') != prepared.get('protected')
        or any(receipt.get(key) is not False for key in ('App_restarted', 'marker_changed',
            'customer_database_opened', 'session_copied', 'deployed', 'commercial_complete'))):
        raise ValueError('actual Source50 success receipt is absent or changed')
    records = receipt.get('targets')
    pins = {Path(row['path']): row['final_pin'] for row in base['targets']}
    if (type(records) is not list or len(records) != len(pins)
        or any(type(row) is not dict or type(row.get('target')) is not str for row in records)
        or len({row['target'] for row in records}) != len(records)
        or {Path(row['target']) for row in records} != set(pins)):
        raise ValueError('Source50 original receipt target set changed')
    overlays = {Path(row['path']): row for row in manifest['targets']} if applied else {}
    for row in records:
        target = Path(row['target'])
        if row.get('candidate') != pins[target]:
            raise ValueError('Source50 original candidate proof changed')
        overlay = overlays.get(target)
        if overlay is not None and overlay['parent_pin'] != pins[target]:
            raise ValueError('Source51 overlay is not the actual Source50 successor')
        legacy.expected(target, overlay['final_pin'] if overlay is not None else pins[target])
    protected = prepared.get('protected')
    if (type(protected) is not list
        or any(type(row) is not dict or set(row) != {'path', 'pin'}
            or type(row['path']) is not str or not _proof(row['pin']) for row in protected)
        or len({row['path'] for row in protected}) != len(protected)):
        raise ValueError('Source50 fixed protection set changed')
    for row in protected:
        target = Path(row['path'])
        overlay = overlays.get(target)
        if overlay is not None and overlay['parent_pin'] != row['pin']:
            raise ValueError('Source51 overlay is not the actual Source50 protected parent')
        legacy.expected(target, overlay['final_pin'] if overlay is not None else row['pin'])
    return legacy.pin(raw)


def _readback(legacy, manifest, base):
    if os.path.lexists(FAILED):
        raise ValueError('Source51 original failure evidence requires Root recovery')
    receipt = json.loads(legacy.blob(RECEIPT))
    base_pin = _base_receipt(legacy, manifest, base, True)
    gate = json.loads(legacy.expected(APPROVAL, manifest['approval_pin']))
    if (receipt.get('schema') != 'source51_owner_joined_v1'
        or receipt.get('source_batch') != 51
        or receipt.get('approval_sha256') != manifest['approval_pin']['sha256']
        or receipt.get('authority_manifest_pin') != MANIFEST_PIN
        or receipt.get('prepared_manifest_pin') != gate['prepared_manifest_pin']
        or receipt.get('base_receipt_pin') != base_pin
        or receipt.get('protected') != manifest['protected']
        or any(receipt.get(key) is not False for key in ('App_restarted', 'marker_changed',
            'customer_database_opened', 'session_copied', 'deployed', 'commercial_complete'))):
        raise ValueError('actual Source51 success receipt changed')
    records = receipt.get('targets')
    targets = {Path(row['path']): row for row in manifest['targets']}
    if (type(records) is not list or len(records) != len(targets)
        or any(type(row) is not dict or type(row.get('target')) is not str for row in records)
        or len({row['target'] for row in records}) != len(records)
        or {Path(row['target']) for row in records} != set(targets)):
        raise ValueError('Source51 success receipt target set changed')
    for row in records:
        target = Path(row['target'])
        proof = targets[target]
        if row.get('candidate') != proof['final_pin'] or row.get('parent') != proof['parent_pin']:
            raise ValueError('Source51 success target proof changed')
        legacy.expected(target, proof['final_pin'])
    for row in manifest['protected']:
        legacy.expected(Path(row['path']), row['pin'])


def _start_once(legacy, manifest, base_pin):
    if os.path.lexists(STARTED) or os.path.lexists(FAILED) or os.path.lexists(RECEIPT):
        raise ValueError('Source51 original invocation requires Root recovery')
    value = {'schema': 'source51_next_open_started_v1', 'source_batch': 51,
        'instance_id': INSTANCE_ID, 'approval_sha256': manifest['approval_pin']['sha256'],
        'manifest_pin': MANIFEST_PIN, 'base_receipt_pin': base_pin,
        'pid': os.getpid(), 'auto_retry': False}
    temporary = legacy.prepared_temp(STARTED,
        (json.dumps(value, ensure_ascii=False, sort_keys=True)+'\n').encode('utf-8'))
    try:
        os.rename(temporary, STARTED)
    finally:
        temporary.unlink(missing_ok=True)


def _invoke(legacy, path, proof, approval_sha256):
    original_args = sys.argv
    sys.argv = [str(path), '--apply', approval_sha256]
    try:
        raw = legacy.expected(path, proof)
        try:
            exec(compile(raw, str(path), 'exec'), {'__name__': '__main__', '__file__': str(path)})
        except SystemExit as result:
            if result.code is not None and not (type(result.code) is int and result.code == 0):
                raise ValueError('fixed source CAS did not complete')
    finally:
        sys.argv = original_args


def reviewed_entry_pin_if_joined(legacy):
    """Metadata only: no business import, lock, apply, marker or platform action."""
    manifest, base = _plan(legacy)
    if os.path.lexists(RECEIPT):
        _readback(legacy, manifest, base)
        return next(row['final_pin'] for row in manifest['targets'] if Path(row['path']) == ENTRY)
    if os.path.lexists(STARTED) or os.path.lexists(FAILED):
        raise ValueError('Source51 original invocation has no verified success')
    if os.path.lexists(BASE_FAILED):
        raise ValueError('Source50 original failure requires Root recovery')
    return legacy.reviewed_entry_pin_if_joined()


def before_normal_open(entry, legacy):
    """One reviewed 50 -> 51 sequence before native business source is imported."""
    held = {'decision': 'held', 'source_mutations': 0, 'automatic_retry': False}
    if (os.name != 'nt' or getattr(sys, 'frozen', False)
        or Path(entry.__file__) != ENTRY or entry.PILOT != PILOT):
        return held
    report = entry.preflight()
    if report.get('state') != 'ready_for_original_native_main' or report.get('instance_id') != INSTANCE_ID:
        return held
    invoked = False
    try:
        manifest, base = _plan(legacy)
        if os.path.lexists(RECEIPT):
            _readback(legacy, manifest, base)
            return {'decision': 'continue', 'source_mutations': 0, 'automatic_retry': False}
        if os.path.lexists(STARTED) or os.path.lexists(FAILED) or os.path.lexists(BASE_FAILED):
            return held
        with legacy._exclusive_existing_lock(entry):
            again = entry.preflight()
            if again.get('state') != 'ready_for_original_native_main' or again.get('instance_id') != INSTANCE_ID:
                return held
            manifest, base = _plan(legacy)
            if not os.path.lexists(legacy.RECEIPT):
                legacy._start_once(base)
                invoked = True
                _invoke(legacy, legacy.JOIN, base['join_script_pin'], base['approval_pin']['sha256'])
            legacy._readback(base)
            base_pin = _base_receipt(legacy, manifest, base, False)
            _start_once(legacy, manifest, base_pin)
            invoked = True
            _invoke(legacy, JOIN, manifest['join_script_pin'], manifest['approval_pin']['sha256'])
            _readback(legacy, manifest, base)
        # No previous Python module cache, instance grant or upgrade flag crosses
        # this boundary. The original main reacquires its own lock normally.
        os.execv(sys.executable, [sys.executable, '-X', 'utf8', '-B', '-I', str(ENTRY)])
        return {**held, 'source_mutations': None, 'join_invoked': True}
    except Exception:
        return {**held, 'source_mutations': None if invoked else 0, 'join_invoked': invoked}
