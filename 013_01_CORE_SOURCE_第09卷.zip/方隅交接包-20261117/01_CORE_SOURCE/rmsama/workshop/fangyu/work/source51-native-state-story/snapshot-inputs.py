import hashlib,json
from pathlib import Path
OWN=Path(__file__).absolute().parent
PROJECT=Path('C:/积木软件工坊/项目/方隅公寓客户版')
SOURCES={
 'next_open_source51.py':PROJECT/'work/source51-root-integration/next_open_source51.py',
 'source_next_open_launcher.py':PROJECT/'work/source51-root-integration/source_next_open_launcher.py',
 'next_open_source.py':PROJECT/'work/desktop-self-use-entry/next_open_source.py',
 'desktop_entry.py':PROJECT/'work/desktop-self-use-entry/desktop_entry.py',
 'join-source51-reviewed.py':PROJECT/'work/source51-root-cas-candidate/join-source51-reviewed.py',
 'join-source44-reviewed.py':PROJECT/'work/product-upgrade-20261009/audits/join-source44-reviewed.py',
}
def pin(raw):return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest().upper()}
directory=OWN/'snapshot';directory.mkdir(exist_ok=True)
rows=[]
for name,path in SOURCES.items():
 raw=path.read_bytes();target=directory/name
 with target.open('xb') as stream:stream.write(raw)
 assert target.read_bytes()==raw
 rows.append({'source':str(path),'snapshot':str(target),'pin':pin(raw)})
value={'schema':'source51_native_story_fixed_snapshot_v1','inputs':rows,'snapshot_only':True,'formal_mutations':0}
path=OWN/'SNAPSHOT.json'
with path.open('x',encoding='utf-8') as stream:stream.write(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'snapshot_pin':pin(path.read_bytes()),'inputs':[{ 'name':Path(row['snapshot']).name,'pin':row['pin']} for row in rows]}))
