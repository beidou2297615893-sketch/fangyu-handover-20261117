首 run d5e72e3f8b974a81b8068bd4055803eb 的正常 50→51 与未来状态两组已经 PASS。该 run 的第三组到 bad_parent 时失败，是夹具把 index.js 坏父放在协调器 _base_receipt 前；它属于原 Source50 protected，原门禁先拒，因此既未写 Source51 STARTED，也未进入 Source51 CAS。之后要求存在 CAS failed 的断言不成立。首唯一 FIRST-FAIL、RUN-FAILED、全部自有 fixtures 和原 carrier-v1 字节保留，没有覆盖原记录。

续跑只选择 --story3-only，OS rename seam 在 STARTED 真正落盘之后改坏父，再实际调用原 Source51 main。续跑成功后保 RESULT.json 原字节；它的 story_selection 只有第三组。终端打印 story_count=3 是 carrier 的计划总组数常量，不是该续跑 JSON 的实际组数；实际三组来自首两 PASS 文件及这次唯一第三组 PASS，本次整理不重跑首两组。

Windows PID4 supplemental 仅使用成熟 Win32 pid_state 的同步查询；实际返回 unknown，原 preflight held_unknown_process 且 51 调用为零。它没有启动/读取系统进程业务数据。
