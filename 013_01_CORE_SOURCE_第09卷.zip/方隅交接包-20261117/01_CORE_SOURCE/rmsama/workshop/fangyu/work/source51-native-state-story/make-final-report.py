"""Read saved owned evidence and freeze it; no CAS/lock/QA execution."""
import ast,hashlib,json
from pathlib import Path
OWN=Path(__file__).absolute().parent
FIRST=OWN/'runs/d5e72e3f8b974a81b8068bd4055803eb'
THIRD=OWN/'runs/8035b9e79e7c4b42a77f559a835cbb2b'
UNKNOWN=OWN/'runs/1bfa5e50511045e58d5b42348a6d7753/UNKNOWN-OS-283d8f458cad440fa352e990a4fa74fc.json'
def pin(raw):return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest().upper()}
def write(path,value):
    raw=(json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode() if isinstance(value,dict) else value.encode()
    with path.open('xb') as stream:stream.write(raw)
    return pin(raw)
def record(path):return {'path':str(path),'pin':pin(path.read_bytes())}
one=FIRST/'01-normal50to51-5ce6413c445a418ba5914bd295ea2538.json'
two=FIRST/'02-future-readback-29599c30a37243dcab4fca7c6e449a5b.json'
three=THIRD/'RESULT.json'
data=[json.loads(p.read_bytes()) for p in (one,two,three,UNKNOWN)]
assert all(x['status']=='PASS' for x in data)
assert data[2]['story_selection']==['03-unknown-and-rollback'] and len(data[2]['stories'])==1
assert data[2]['carrier_pin']==pin((OWN/'state-story.py').read_bytes())
keys={
 'join-source51-reviewed.py':{'PROJECT','BASE_MANIFEST_PIN','JOIN_AUTHORIZED'},
 'next_open_source51.py':{'PROJECT','BASE_MANIFEST_PIN','JOIN_AUTHORIZED','MANIFEST_PIN','TARGET_PATHS'},
 'next_open_source.py':{'PROJECT','ROOT_MANIFEST_PIN','TARGET_PATHS'},
 'source_next_open_launcher.py':{'PROJECT','SUCCESSOR_PIN','HELPER_PIN','ENTRY_PARENT_PIN'},
 'desktop_entry.py':{'PROJECT','SOURCE','PILOT','RUNTIME','REVIEW','REVIEW_SHA','ORIGINAL_MARKER_SHA','PINS','_HOST_PATHS','HOST_PINS'},
}
def normalized(raw,names):
    tree=ast.parse(raw)
    for node in tree.body:
        if isinstance(node,ast.Assign) and isinstance(node.targets[0],ast.Name) and node.targets[0].id in names:node.value=ast.Constant(None)
    return ast.dump(tree).encode()
shapes=[];docs=[]
for name,names in keys.items():
    base=(OWN/'snapshot'/name).read_bytes();control=normalized(base,names)
    for path in sorted((OWN/'runs').rglob(name)):
        raw=path.read_bytes();assert normalized(raw,names)==control,(name,path)
        shapes.append({**record(path),'snapshot':name,'assignment_bindings_only':sorted(names),'control_AST_pin':pin(control),'control_AST_unchanged':True})
for path in sorted((OWN/'runs').rglob('*.json')):
    if path.name in ('source50-manifest.json','source50-final-root-read.json','source50-joined.json','source50-next-open-started.json',
        'source51-manifest.json','source51-final-root-read.json','source51-joined.json','source51-next-open-started.json','source51-join-failed.json','PREPARED.json'):
        docs.append(record(path))
shape_pin=write(OWN/'CONTROL-AST-READBACK.json',{'schema':'source51_owned_control_ast_readback_v1','control_functions_not_changed':True,'count':len(shapes),'items':shapes})
document_pin=write(OWN/'FIXTURE-DOCUMENT-PINS.json',{'schema':'source51_owned_fixture_documents_v1','all_authority_synthetic':True,'items':docs})
history='''首 run d5e72e3f8b974a81b8068bd4055803eb 的正常 50→51 与未来状态两组已经 PASS。该 run 的第三组到 bad_parent 时失败，是夹具把 index.js 坏父放在协调器 _base_receipt 前；它属于原 Source50 protected，原门禁先拒，因此既未写 Source51 STARTED，也未进入 Source51 CAS。之后要求存在 CAS failed 的断言不成立。首唯一 FIRST-FAIL、RUN-FAILED、全部自有 fixtures 和原 carrier-v1 字节保留，没有覆盖原记录。

续跑只选择 --story3-only，OS rename seam 在 STARTED 真正落盘之后改坏父，再实际调用原 Source51 main。续跑成功后保 RESULT.json 原字节；它的 story_selection 只有第三组。终端打印 story_count=3 是 carrier 的计划总组数常量，不是该续跑 JSON 的实际组数；实际三组来自首两 PASS 文件及这次唯一第三组 PASS，本次整理不重跑首两组。

Windows PID4 supplemental 仅使用成熟 Win32 pid_state 的同步查询；实际返回 unknown，原 preflight held_unknown_process 且 51 调用为零。它没有启动/读取系统进程业务数据。
'''
write(OWN/'HISTORY-NOTE.md',history)
report='''Source51 三组新装载状态代表通过，范围限定于合成文件装载契约。Source50 CAS 明确录制成熟接口，生成真实自有 55 件回执与 5 件 dummy 原父备份；Source51 CAS 原控制逻辑实际执行，自有原 byte OS 排他锁实际持有、child probe 实际检验。全部 PROJECT/WORK/AUDITS/PILOT/ENTRY 固定于本目录 runs 的合成根，不指真实原实例。

正常故事通过原 launcher._load checked raw→compile/exec、成熟原 entry preflight 与协调器普通路径。50 与 51 各调用一次；实际后继 11 target / 10 原父备份 / 1 新 scope / 0 staging，入口最后。原 367 protected 的未覆盖源与合成后继 412 protection 均核。释放锁后 exec 边缘只记录固定 -X utf8 -B -I，真实检查原 byte 锁已释放；没有运行真实 App、GUI、业务 main、平台、模型或云 SDK。preflight 所需 runtime/webview/SQLite 占位仅为明示合成 metadata，不是实际能力验收。

第二组从已成功的合成 Source50 回执开始，只调用 51；未来 Source51 成功后 metadata readback 与正常路径均 0 invoke。分别篡改未覆盖原 50 protected、51 final、原 50 receipt，每个 held / 0 invoke，metadata 同时拒。当前原 Source50 的原保护回执数组、prepared pin、51 authority/receipt 保护数组绑定均触达；没有修改旧 Source50 helper/CAS。

第三组覆盖未知 STARTED、已有 FAILED、live 原 main、未知元数据、另一自有进程实际占用 byte 锁，均 held / 0 invoke。补充真实 Win32 unknown 进程状态同样 held。坏父在实际 STARTED 写入之后注入，51 main 实际拒且 0 replacement，留下独立失败回执。actual scope rename 后的 OS IO 中断触发真实回滚：自己的已提交源恢复，new scope 撤销，10 原父备份/STARTED/FAILED 保史、0 staging；foreign 修改拒回滚、其余自己的项继续恢复。再次打开不自动重试，失败原 pin 不变。

首失败属于注入时序错误，完整限制见 HISTORY-NOTE.md；首通过故事未重跑。脚本、协调器、launcher、legacy helper 与原 entry 控制 AST 只替换已列固定常量，逐 saved 文件读回均一致。没有改动冻结店级代码、正式 SOURCE/中心文件或 Source50 待合图；没有重复原商业、门店、平台功能 QA。

本次不能证明平台六源功能、真实 SDK/索引、GUI、原 App 正常重开、实际 Source50/51 apply 或全商业完成。平台尚未最终冻结，dummy 字节只验证新装载边界。后续仍须 Root 最终真实图与非作者审，不将本作者的代表当最终独审。
'''
write(OWN/'REPORT.md',report)
evidence=[record(p) for p in (one,two,three,UNKNOWN,OWN/'SNAPSHOT.json',OWN/'CONTROL-AST-READBACK.json',OWN/'FIXTURE-DOCUMENT-PINS.json',OWN/'HISTORY-NOTE.md',OWN/'REPORT.md',OWN/'state-story.py',OWN/'carrier-history/state-story-v1.py',OWN/'unknown-os-story.py',OWN/'snapshot-inputs.py',Path(__file__))]
evidence += [record(p) for p in sorted(FIRST.glob('*FIRST-FAIL*.json'))]+[record(p) for p in sorted(FIRST.glob('RUN-FAILED*.json'))]
frozen={'schema':'source51_owned_native_state_story_frozen_v1','status':'PASS','story_groups':3,'source50_CAS_recorded':True,
    'source51_actual_CAS_and_byte_lock':True,'dummy_authority_only':True,'real_App_GUI_platform_or_model_started':False,
    'formal_mutations':0,'original_QA_rerun':False,'independent_final_review_required':True,'evidence':evidence}
frozen_pin=write(OWN/'FROZEN.json',frozen)
print(json.dumps({'FROZEN':frozen_pin,'REPORT':pin((OWN/'REPORT.md').read_bytes()),'saved_control_files':len(shapes),'fixed_synthetic_documents':len(docs),'actual_stories':3}))
