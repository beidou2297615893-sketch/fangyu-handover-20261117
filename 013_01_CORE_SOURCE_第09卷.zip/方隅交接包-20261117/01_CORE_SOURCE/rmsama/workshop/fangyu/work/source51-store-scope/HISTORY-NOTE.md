Source51 首个固定文件名读 tracer 的证据限制，独立补记；不改变 FROZEN、业务候选或当前结果，不重跑失败。

最初正常 createService/createStore 读 tracer 的工具输出确为 staff-a/store-a 读到 A/B 两店，属于真实旧代码 RED。但首文件使用固定 `evidence/READ-RED.json` 名称，后续中间一次仅接读过滤、尚未接来源写入标签的 RED 覆盖了该文件。不能称首次失败文件完整保留，当前这个首路径不再代表最初两店互读。

现 `READ-RED.json` 的 actual_source_ids 为 []，expected_source_ids 为 [synthetic-source51-a]，实义为“读过滤已收紧，但来源写入标签尚未接入，因此本店来源也不可见”。其中 reason 仍是旧“staff-a 读到 store-b”文字，与空实际列表不符，应忽略该旧 reason；不能用该文件证明现生产泄露或最初互读行为。

真实旧基线以首工具输出和已独立保存的 `work/overnight-commercial-20261014/store-scope-gap/RESULT.json` 为准：2579 字节 / SHA `D277227587CF5F70B2DAAEA48FC1C5A5E00D761813C27055755BD2BDA35297EB`，默认共享423，只有受信开启的合成两门店夹具互读/互改200。后续读 tracer 已改为每轮唯一文件；v2 唯一 RED 与最终正常两种存储12行为事件 GREEN、未知门店及默认关闭证据没有因此覆盖。

README 的“首工具输出保留”仅指会话工具记录存在；不意味着首 on-disk 文件仍完整。Root 及非作者审查应以准确旧基线、唯一后继结果和此限制为准，不修饰历史、不伪造首文件 pin，也不为补历史重复旧 QA。
