'use strict';
const assert=require('node:assert/strict');
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const {fixture,lead}=require('./public-fixture.cjs');
const {cleanLead}=require('../candidate/cloud/workspace/service.cjs');
const hash=x=>crypto.createHash('sha256').update(x).digest('hex');
async function story(v2){
 const f=await fixture({v2});let revision=0;const evidence=[];
 const list=async token=>f.ok(await f.call('list',{},token));
 const publish=async (token,items)=>{const response=await f.call('publish',{revision,items},token);
  if(response.status===200)revision=response.data.revision;return response;};
 f.ok(await publish(f.a.token,[lead('a')]));f.ok(await publish(f.b.token,[lead('b')]));
 const own=await list(f.a.token),peer=await list(f.peer.token),other=await list(f.b.token),hq=await list(f.admin.token);
 assert.deepEqual(own.items.map(row=>row.source_id),[lead('a').source_id]);
 assert.deepEqual(peer.items.map(row=>row.source_id),[lead('a').source_id]);
 assert.deepEqual(other.items.map(row=>row.source_id),[lead('b').source_id]);assert.equal(hq.items.length,2);
 for(const page of [own,peer,other,hq])for(const row of page.items)assert.equal(Object.hasOwn(row,'source_store_id'),false);
 f.ok(await publish(f.peer.token,[{...lead('a'),text:'same store updated'}]));
 assert.equal((await list(f.a.token)).items[0].text,'same store updated');
 evidence.push('normal staff and same-store colleague read/edit; HQ sees both; old public DTO has no internal scope field');
 const beforeRevision=revision;
 const denied=await publish(f.a.token,[{...lead('b'),text:'must not overwrite'}]);
 assert.equal(denied.status,403);assert.equal(denied.data.mutation_committed,false);
 const atomic=await publish(f.a.token,[lead('uncommitted'),{...lead('b'),text:'must not partially commit'}]);
 assert.equal(atomic.status,403);const unchanged=await list(f.admin.token);
 assert.equal(unchanged.revision,beforeRevision);assert.equal(unchanged.items.length,2);
 assert.equal((await list(f.b.token)).items[0].text,'synthetic b');
 const spoof=await publish(f.a.token,[{...lead('spoofed'),source_store_id:'store-b'}]);assert.equal(spoof.status,400);
 const spoofRead=await f.call('list',{store_id:'store-b'},f.a.token);assert.equal(spoofRead.status,400);
 evidence.push('cross-store and mixed batch rejected without revision/data change; client scope spoof rejected');
 f.ok(await publish(f.admin.token,[{...lead('b'),text:'HQ managed existing B'}]));
 assert.equal((await list(f.b.token)).items[0].text,'HQ managed existing B');
 const hqNew=await publish(f.admin.token,[lead('unbound-hq-new')]);assert.equal(hqNew.status,403);
 evidence.push('HQ without a store edits existing source but cannot create unknown-store source');
 // Explicit synthetic old record only, not a real-data migration. The original
 // server DTO has no source_store_id and must not be assigned by updatedBy.
 const legacy={...cleanLead(lead('legacy')),updatedBy:'staff-a',updatedAt:1};
 if(v2){
  let sequence;f.db.mutateCompany(f.COMPANY,state=>{sequence=++state.sharedLeadSequence;});
  await f.db.collection('fangyu_shared_leads').doc(f.COMPANY+'--'+legacy.id).set({companyId:f.COMPANY,leadId:legacy.id,sequence,lead:legacy});
 }else f.db.mutateCompany(f.COMPANY,state=>state.items.push(legacy));
 assert.equal((await list(f.a.token)).items.some(row=>row.source_id===lead('legacy').source_id),false);
 assert.equal((await list(f.admin.token)).items.some(row=>row.source_id===lead('legacy').source_id),true);
 assert.equal((await publish(f.a.token,[lead('legacy')])).status,403);
 f.ok(await publish(f.admin.token,[{...lead('legacy'),text:'HQ edits old unassigned'}]));
 assert.equal((await list(f.a.token)).items.some(row=>row.source_id===lead('legacy').source_id),false);
 evidence.push('legacy unassigned source stays HQ-only even with current staff-a label; no store inference');
 // Existing company-wide handoff manager grants do not grant shared-store HQ.
 f.db.mutateCompany(f.COMPANY,state=>state.acquisitionPolicy={managers:['staff-a']});
 assert.equal((await list(f.a.token)).items.some(row=>row.source_id===lead('b').source_id),false);
 f.ok(await f.call('member_save',{username:'staff-a',role:'operator',store_id:'store-b',member_mode:'update'},f.admin.token));
 assert.equal((await f.call('list',{},f.a.token)).status,401);
 const moved=await f.login('staff-a');const movedPage=await list(moved.token);
 assert.deepEqual(movedPage.items.map(row=>row.source_id),[lead('b').source_id]);
 assert.equal((await publish(moved.token,[lead('a')])).status,403);
 assert.equal((await list(f.peer.token)).items[0].source_id,lead('a').source_id);
 evidence.push('handoff manager is no shared HQ grant; transfer revokes old session and does not migrate old source');
 if(v2){
  f.db.afterSharedQuery(()=>f.db.mutateCompany(f.COMPANY,state=>{state.users.find(row=>row.username==='staff-b').store_id='store-a';}));
  const changed=await f.call('list',{},f.b.token);assert.equal(changed.status,409);assert.equal(Object.hasOwn(changed.data,'items'),false);
  evidence.push('normal v2 list withheld when current member store changes between query and final validation');
  f.db.afterSharedQuery(async()=>f.ok(await f.call('member_save',{username:'staff-a',role:'operator',
   store_id:'store-a',member_mode:'update'},f.admin.token)));
  const revokedPage=await f.call('list',{},moved.token);assert.equal(revokedPage.status,409);
  assert.equal(Object.hasOwn(revokedPage.data,'items'),false);
  assert.equal((await f.call('list',{},moved.token)).status,401);
  evidence.push('pending v2 page withheld after normal member_save transfer with unchanged shared revision and revoked original session');
 }
 return {mode:v2?'v2':'legacy',result:'PASS',events:evidence,
  query_records:v2?f.db.operations.filter(row=>row.operation==='query').map(row=>({collection:row.collection,filters:row.filters})):[],
  public_scope_source_ids:{same_store:own.items.map(row=>row.source_id),other_store:other.items.map(row=>row.source_id)}};
}
async function main(){
 const result={schema:'source51_store_scope_normal_requests_v1',seams:['createService','createStore with fresh JSON SDK transaction adapter'],
  cloud_or_platform_or_model_calls:0,App_start_or_restart:0,formal_source_writes:0,old_QA_rerun:false,
  real_SDK:false,Casbin_installed_or_integrated:false,stories:[]};
 try{
  result.stories.push(await story(false));result.stories.push(await story(true));
  const unknown=await fixture();
  unknown.ok(await unknown.call('member_save',{username:'unbound-staff',password:'[REDACTED:assigned_secret]',
   role:'operator',member_mode:'create',can_reply:false},unknown.admin.token));
  const noStore=await unknown.login('unbound-staff');
  assert.equal((await unknown.call('list',{},noStore.token)).status,403);
  assert.equal((await unknown.call('publish',{revision:0,items:[lead('unbound')]},noStore.token)).status,403);
  result.unknown_store_denied='PASS';
  const held=await fixture({enabled:false});assert.equal((await held.call('list',{},held.a.token)).status,423);
  assert.equal((await held.call('publish',{revision:0,items:[lead('held')]},held.a.token)).status,423);
  result.default_disabled='PASS';result.result='PASS';
 }catch(error){result.result='FAILED';result.error=error.stack;process.exitCode=1;}
 const file=path.resolve(__dirname,'../evidence/SCOPE-STORY-'+Date.now()+'.json');fs.writeFileSync(file,JSON.stringify(result,null,2)+'\n');
 fs.writeFileSync(path.resolve(__dirname,'../evidence/LATEST.txt'),file);console.log(JSON.stringify({result:result.result,
  modes:result.stories.map(row=>row.mode),events:result.stories.map(row=>row.events.length),file,error:result.error}));
}
main().catch(error=>{console.error(error.stack);process.exitCode=2;});
