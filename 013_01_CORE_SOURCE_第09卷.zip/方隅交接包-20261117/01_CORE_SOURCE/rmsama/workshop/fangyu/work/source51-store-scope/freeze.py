"""Freeze four owned candidate targets and exact unchanged public inputs."""
from pathlib import Path
import hashlib,json,difflib,stat
HERE=Path(__file__).resolve().parent
WORK=HERE.parent
BASE=WORK/'cloud/workspace'
CANDIDATE=HERE/'candidate/cloud/workspace'
pin=lambda raw:{'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest().upper()}
def plain(path):
    info=path.lstat()
    assert stat.S_ISREG(info.st_mode) and not path.is_symlink() and info.st_nlink==1
    return path.read_bytes()
names=('service.cjs','shared_leads_v2.cjs','index.js','shared_store_scope.cjs')
targets=[];diff=[]
for name in names:
    target=BASE/name;candidate=CANDIDATE/name;raw=plain(candidate)
    if name=='shared_store_scope.cjs':
        assert not target.exists() and not target.is_symlink();before=b'';parent=None
    else:
        before=plain(HERE/'parents'/name);assert plain(target)==before;parent=pin(before)
    targets.append({'target':str(target),'candidate':str(candidate),'parent':parent,'candidate_pin':pin(raw)})
    diff.extend(difflib.unified_diff(before.decode().splitlines(True),raw.decode().splitlines(True),fromfile='parent/'+name,tofile='candidate/'+name))
inputs=json.loads(plain(HERE/'INPUTS.json'));dependencies=[]
for item in inputs['inputs']:
    path=Path(item['path']);assert pin(plain(path))==item['pin']
    if item['relative'] not in names:
        assert pin(plain(CANDIDATE/item['relative']))==item['pin'];dependencies.append(item)
source50_path=WORK/'overnight-commercial-20261014/source50-preparation/PREPARED.json'
source50_raw=plain(source50_path);source50=json.loads(source50_raw)
service=next(row for row in targets if Path(row['target']).name=='service.cjs')
protection=next(row for row in source50['protected'] if Path(row['path'])==Path(service['target']))
assert protection['pin']==service['parent']
result=Path((HERE/'evidence/LATEST.txt').read_text('utf-8'));story=json.loads(plain(result))
assert story['result']=='PASS' and len(story['stories'])==2 and story['unknown_store_denied']=='PASS' and story['default_disabled']=='PASS'
assert [len(row['events']) for row in story['stories']]==[5,7]
diff_path=HERE/'evidence/candidate.diff';diff_path.write_text(''.join(diff),'utf-8')
evidence=[HERE/'README.md',HERE/'INPUTS.json',HERE/'prepare.py',HERE/'freeze.py',HERE/'tests/public-fixture.cjs',
    HERE/'tests/scope-story.cjs',HERE/'tests/one-read-story.cjs',diff_path,result,
    WORK/'overnight-commercial-20261014/store-scope-gap/RESULT.json']
evidence += sorted((HERE/'evidence').glob('READ-*.json'))
records=[{'path':str(path),'pin':pin(plain(path))} for path in evidence]
manifest={'schema':'source51_store_scope_candidate_frozen_v1','source_batch':51,'join_authorized':False,
    'targets':targets,'physical_target_count':4,'existing_parents':3,'new_files':1,
    'unchanged_public_dependencies':dependencies,'evidence':records,
    'source50_prepared_path':str(source50_path),'source50_prepared_pin':pin(source50_raw),
    'source50_protected_service_parent':protection,'source50_actual_apply_performed_here':False,
    'must_not_join_before_source50_protection_readback':True,'default_shared_feature_enabled':False,
    'public_DTO_extra_scope_fields':False,'manager_role_or_device_platform_permissions_added':False,
    'real_CloudBase_SDK_or_deployment_verified':False,'Casbin_model_reference_only':True,
    'App_or_platform_or_model_calls':0,'formal_source_or_private_data_changed':False,
    'old_QA_or_matrix_repeated':False,'independent_review_required':True,
    'actual_scope_story_path':str(result),'actual_scope_events':[5,7]}
frozen=HERE/'FROZEN.json'
with frozen.open('x',encoding='utf-8') as stream:stream.write(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'FROZEN_pin':pin(plain(frozen)),'targets':targets,'dependencies':len(dependencies),
    'actual_result_pin':pin(plain(result)),'default_shared':False,'formal_writes':0}))
