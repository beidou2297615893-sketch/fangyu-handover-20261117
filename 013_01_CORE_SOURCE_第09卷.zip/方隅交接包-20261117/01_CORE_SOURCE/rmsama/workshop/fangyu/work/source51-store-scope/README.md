# Source51 门店共享范围候选

当前是隔离候选代码与合成正常请求代表通过，正式 SOURCE/客户数据/Source50 待合图变更为0，未部署、启动 App、触平台或模型。作者不自签最终交付；需 Root 非作者审与后继备份装载。这里只有门店共享数据范围，未补完整店长人员管理、部门分权或总部经营体系。

4 个目标：既有 cloud/workspace/service.cjs、shared_leads_v2.cjs、index.js；新 shared_store_scope.cjs。复用既有公司会话、成员门店字段、事务、原来源 id/版本及分页，以及既有 HQ admin。原角色 admin/operator/origin_partner、成员/门店额度模块、设备/平台账号归属、handoff 的公司级受托审核人与默认共享关闭均未改。

普通员工必须有当前服务器保存的有效 store_id；同门店员工可读/改原共享来源，他店不可读、不可按相同 id 覆盖。新增来源以当前成员门店固定内部 source_store_id，不接收请求根或单条来源的门店范围字段。原来源门店在修改后保留，即使成员转店或总部修改亦不迁移。混合批次包含任一他店/未知来源即整批拒绝，版本不动。HQ 保持公司读/修改范围；HQ 未绑定门店不能新增未知门店来源。旧无范围来源仅 HQ 管理，不按 updatedBy 或当前员工门店猜归属，员工不能认领。

source_store_id 只持久保存，不加入原公开共享 DTO。legacy 读件和正常 v2 页都按原投影返回，现旧公开客户端不必接新字段。v2 文档顶层和 lead 内部范围必须相同，查询按 companyId + source_store_id + sequence，在读页前后 fresh 核当前原会话、role/store、disabled 和共享 revision；实际 member_save 不增加共享 revision，转店/撤会话期间查页仍不能返回旧权限页。

正常代表只走 createService + 实际 createStore 公开 Interface；SDK 是独立 JSON transaction/query Adapter，candidate/node_modules 的 SDK 入口是只准拒绝 init 的 QA stub，绝不属于正式4目标。所有登录、密码散列、成员编辑、共享读/写、跨店拒绝、原 revision 门禁均走真实旧 module，没有 patch actor/权限判断或直接测试新 helper。合成旧无门店记录与 v2 空存储状态只是自有 fixture 设置，不是实际客户迁移。

实际因果：已保存的两店原功能 RESULT 在旧默认关闭时423、受信共享夹具开启后两店互读/互改200；Source51 原正常员工读 tracer 首次也读到两店而 RED（首工具输出保留）。一轮中间仅加读过滤、未接写入来源时 own 来源不可见，随后接服务端固定来源写入后 legacy GREEN；该中间 RED 不是声称真实云泄露。v2 原候选正常读两店仍 RED，接查询过滤及 fresh 身份复核后 GREEN。当前最终 SCOPE-STORY 2种存储12个行为事件，加未知门店拒绝/默认关闭保持通过。每轮新修改后才必要复核，没有重跑旧成员、平台、GUI或全矩阵。

Root 已公开参考 Casbin domains：<https://github.com/apache/casbin-node-casbin>、<https://casbin.apache.org/docs/rbac-with-domains/>；Apache-2.0，模型要求 domain 同时进入身份与资源匹配。本候选仅按该模型适配现公司/门店会话及成熟存储，没有安装集成 Casbin/enforcer 或新策略存储依赖。实际调用最小 codebase-design 与 tdd 工作法，Seam 由已授权正常 createService/createStore 确定。

真实 CloudBase SDK 查询及 companyId/source_store_id/sequence 组合索引尚未部署/实测；门店标签来自公司管理员的服务器成员事实，未证明实体门店或自然人审批。默认 shared=false，旧云不因候选存在而视为支持店级隔离；不能仅把开关打开称完整商用。

装载依赖：三个父仍正式 Source49+49b 的当前公共 cloud 字节。其中 service.cjs 是 Source50 PREPARED 的保护对象，不能先合 Source51 破坏 Source50 图；Root 会安排正常下一开、同原实例锁、备份 CAS 的后继，Source50 实际父与保护核对必须先按其原图完成。本文不执行升级、不修改该图，也不要求人类再回答或重复操作。INPUTS/FROZEN 保存全部26公共依赖、3父/4候选 SHA、必要结果和默认关闭证明。
