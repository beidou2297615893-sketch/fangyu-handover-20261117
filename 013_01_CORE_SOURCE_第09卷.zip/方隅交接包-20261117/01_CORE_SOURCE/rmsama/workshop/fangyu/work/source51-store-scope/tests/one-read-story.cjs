'use strict';
const assert=require('node:assert/strict');
const fs=require('node:fs'),path=require('node:path');
const {fixture,lead}=require('./public-fixture.cjs');
async function main(){
 const v2=process.argv.includes('--v2');
 const f=await fixture({v2});f.ok(await f.call('publish',{revision:0,items:[lead('a')]},f.a.token));
 f.ok(await f.call('publish',{revision:1,items:[lead('b')]},f.b.token));
 const read=f.ok(await f.call('list',{},f.a.token));
 const report={schema:'source51_store_scope_first_read_tracer_v1',backend_mode:v2?'v2':'legacy',seam:'normal createService + createStore JSON SDK transaction adapter',
  expected_source_ids:[lead('a').source_id],actual_source_ids:read.items.map(row=>row.source_id),formal_source_writes:0,
  cloud_or_platform_or_model_calls:0,old_QA_rerun:false};
 try{assert.deepEqual(report.actual_source_ids,report.expected_source_ids);report.result='GREEN';}
 catch(error){report.result='RED';report.reason=report.actual_source_ids.includes(lead('b').source_id)?'staff-a/store-a reads the store-b source through normal authenticated list':'own store source unavailable while source stamping is incomplete';}
 fs.writeFileSync(path.resolve(__dirname,'../evidence/READ-'+report.result+'-'+Date.now()+'.json'),JSON.stringify(report,null,2)+'\n');
 console.log(JSON.stringify(report));process.exitCode=report.result==='GREEN'?0:1;
}
main().catch(error=>{console.error(error.stack);process.exitCode=2;});
