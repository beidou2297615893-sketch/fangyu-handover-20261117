"""Copy the current public require closure; no formal source writes."""
from pathlib import Path
import hashlib,json,re,stat
HERE=Path(__file__).resolve().parent
SOURCE=HERE.parent/'cloud/workspace'
DEST=HERE/'candidate/cloud/workspace'
records=[];pending=['service.cjs','shared_leads_v2.cjs','index.js'];seen=set()
pin=lambda raw:{'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest().upper()}
while pending:
    name=pending.pop()
    if name in seen:continue
    seen.add(name);path=SOURCE/name;info=path.lstat()
    assert stat.S_ISREG(info.st_mode) and not path.is_symlink() and info.st_nlink==1
    raw=path.read_bytes();target=DEST/name;target.parent.mkdir(parents=True,exist_ok=True)
    with target.open('xb') as stream:stream.write(raw)
    for dependency in re.findall(r"require\(['\"]\./([^'\"]+)['\"]\)",raw.decode('utf-8')):
        assert '/' not in dependency and '..' not in dependency
        pending.append(dependency)
    records.append({'path':str(path),'relative':name,'pin':pin(raw)})
original=HERE/'parents';original.mkdir()
for name in ('service.cjs','shared_leads_v2.cjs','index.js'):
    (original/name).write_bytes((DEST/name).read_bytes())
(HERE/'INPUTS.json').write_text(json.dumps({'schema':'source51_store_scope_public_inputs_v1','inputs':records,
    'formal_source_writes':0,'real_customer_data_or_cookie_read':False},ensure_ascii=False,indent=2)+'\n','utf-8')
# The public createStore factory accepts an SDK database. The SDK package
# entry is a fail-closed test seam; getService/main must never initialise it.
stub=HERE/'candidate/node_modules/@cloudbase/node-sdk/index.js';stub.parent.mkdir(parents=True)
stub.write_text("module.exports={init(){throw Error('fixture refuses real CloudBase init');}};\n",'utf-8')
print(json.dumps({'public_inputs':len(records),'formal_writes':0}))
