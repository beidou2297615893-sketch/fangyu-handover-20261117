# 第三次实际组件合成验收批准

2026-10-27，Astra，独立静态审查。

APPROVED_FOR_ONE_COMPILED_LOOPBACK_FIXTURE_RUN_03

批准 root 对新目录 binary-e2e/compiled-03 执行一次现有 --compiled-reviewed 路线。此批准只针对以下精确文件，原项目/发布参数继续使用前两次批准的 ba1ea294 只读基线。不是云部署或客户端安装批准。

- harness.py：e6990325850597d64241b13b6b0e34a23f4c15594c2f79da3ef69e6f73c68253
- safety.py：08c0419c06a1fb10dfffd08166659f7f2d56004223f8bb207c5dd2d821cea980
- tests/loopback_tls_fixture.py：502a925a3b489bd4063c5fb8a5940123519fb54759bec6c2620175a6e9969edf
- platform-cli-customer-read.exe：161252d023f6744894f05d689bb64aa7d973417916fba71e43314b35a7cf4533

当前 harness 在 fixture 中先固定原始客户 UID，再分配账号，沿原编辑接口写入合成精确正文；使用原 Adapters.account_spec，保留其平台 guard、账号 HOME 和运行环境，普通无 scope 路线必须仍阻断，旧 helper A 仍在原 manifest 中，只有私有注册选择 helper B。失败诊断落 RESULT，包含阶段、child starts 与已经记录的本地 wire；诊断计数不是 OS 级网络审计。

本次仍仅四个合成案例：公开资料读取与采用、单条成功、错误 UID 零 POST、响应身份冲突 unknown 且禁止重放。远端 lease 明确为 synthetic test object，不属于真实云许可验收。

沿用原边界：独立空 HOME/临时凭据、固定可执行文件和两个私有 flags、隐藏进程、捕获协议管道、临时 CA 仅 child 环境、所有代理固定 loopback 且 NO_PROXY 为空、响应器不转发。父 Python audit 不覆盖原生 child，不声称操作系统网络沙箱。禁止真实平台、模型、登录、生产数据写入与凭据读取；不得修改或放宽 frozen helper。

compiled-01/02 都是 fixture 前置失败，均未验收通过。新运行失败时保留原目录及诊断，不自动重跑；任何上述哈希变化重新审查。

## 本次实际结果

已读取 compiled-03/RESULT.json：FAIL。read 案例启动了 1 个实际编译 child，但本地响应器记录 HTTP/GET/POST 都为 0；业务状态 unknown，错误码 CLI_PAGE_UNCONFIRMED。没有完成任一案例。本批准已经消费，不能自动沿用重跑。需要取得 child 启动/协议 stderr 证据后定位；尚不能判断为平台响应问题，也不能称新 EXE 验收通过。
