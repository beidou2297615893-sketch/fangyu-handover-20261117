from pathlib import Path
import ast,importlib.util,json,hashlib
T=Path(__file__).resolve().parent.parent
spec=importlib.util.spec_from_file_location('strict_checker',T/'review_source_closure.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
positive=['class C:\n @property\n def x(self):pass\n @x.setter\n def x(self,v):pass\n @x.deleter\n def x(self):pass','class C:\n @property\n def x(self):pass\n @x.getter\n def x(self):pass']
negative=['def f():pass\ndef f():pass','class C:pass\nclass C:pass','class C:\n def f(self):pass\n def f(self):pass','class C:\n @property\n def x(self):pass\n def x(self):pass','class C:\n @property\n def x(self):pass\n @x.setter\n def x(self,v):pass\n @x.setter\n def x(self,v):pass','class C:\n @property\n def x(self):pass\n @other.setter\n def x(self,v):pass']
for s in positive:m.assert_unique_definitions(ast.parse(s),'positive')
for s in negative:
 try:m.assert_unique_definitions(ast.parse(s),'negative')
 except AssertionError:pass
 else:raise AssertionError('Invalid duplicate allowed')
changes=json.loads((T/'assembly/CHANGES.final.json').read_text('utf-8-sig'))['files'];errors=[];checked=0
for name in changes:
 p=T/'assembly/project'/name
 if p.suffix=='.py':
  checked+=1
  try:m.assert_unique_definitions(ast.parse(p.read_text('utf-8-sig')),name)
  except AssertionError as e:errors.append(str(e))
report={'positiveCases':len(positive),'negativeCases':len(negative),'changedPythonFilesChecked':checked,'remainingDuplicates':errors,'checkerSha256':hashlib.sha256((T/'review_source_closure.py').read_bytes()).hexdigest(),'frozenSourcesModified':False,'fullClosureReviewExecuted':False}
(T/'binary-debug/STRICT-PROPERTY-CHECKER-TEST.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n','utf-8');print(json.dumps(report))
