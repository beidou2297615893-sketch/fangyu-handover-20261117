"""Parent-only guard for an explicitly reviewed compiled test child.

This is not an OS network sandbox. Child containment depends on the reviewed
fixed HTTPX path, explicit loopback proxies and the non-forwarding TLS fixture.
"""
import hashlib, os, subprocess, threading
from pathlib import Path
from urllib.parse import urlsplit
FLAGS=('--owned-xhs-cli-pages','--owned-xhs-reviewed-reply')
def require(value,message):
 if not value:raise AssertionError(message)
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
class ChildGuard:
 def __init__(self,exe,pin,root,*,reviewed=False,popen=None):
  self.exe=Path(exe).resolve();self.pin=pin;self.root=Path(root).resolve();self.reviewed=reviewed;self.real=popen or subprocess.Popen;self.local=threading.local();self.starts=[]
 def validate(self,argv,options):
  require(self.reviewed,'Compiled child requires explicit --compiled-reviewed')
  require(type(argv) in (list,tuple) and len(argv)==2 and Path(argv[0]).resolve()==self.exe and argv[1] in FLAGS,'Only pinned exe and two fixed helper flags allowed')
  require(self.exe.is_file() and sha(self.exe)==self.pin,'Compiled executable SHA changed')
  require(not options.get('shell',False) and options.get('executable') is None,'Shell and executable overrides forbidden')
  env=options.get('env');require(type(env) is dict,'Explicit child environment required')
  homes=[]
  for name in ('HOME','USERPROFILE','XDG_CONFIG_HOME','APPDATA','LOCALAPPDATA'):
   home=Path(env.get(name,'')).resolve();require(home.is_relative_to(self.root),'Child home must stay inside synthetic run');homes.append(home)
  require(homes[0]==homes[1],'HOME and USERPROFILE must select same synthetic account')
  proxies=[]
  for name in ('HTTP_PROXY','HTTPS_PROXY','ALL_PROXY','http_proxy','https_proxy','all_proxy'):
   proxy=urlsplit(env.get(name,''));require(proxy.scheme=='http' and proxy.hostname=='127.0.0.1' and proxy.port and not proxy.username and not proxy.password,'Every proxy must be explicit loopback');proxies.append(env[name])
  require(len(set(proxies))==1 and env.get('NO_PROXY')==env.get('no_proxy')=='','Proxy bypass forbidden')
  require(Path(env.get('SSL_CERT_FILE','')).resolve().is_relative_to(self.root),'Only temporary child TLS CA allowed')
  require(env.get('LEADSTUDIO_ISOLATED')=='1','Owned helper isolation marker required')
  require(Path(env.get('WORKSPACE_ACTIVITY_LOG','')).resolve().is_relative_to(homes[0]),'Activity log must stay inside synthetic account HOME')
  require(env.get('WORKSPACE_ACTIVITY_KIND') in ('whoami','user','user-posts','reply','other'),'Activity kind must be fixed')
  for name in ('TEMP','TMP'):require(Path(env.get(name,'')).resolve().is_relative_to(homes[0]),'Child temp must stay inside synthetic account HOME')
  require(all(options.get(k)==subprocess.PIPE for k in ('stdin','stdout','stderr')),'Only captured protocol pipes allowed')
  cwd=Path(options.get('cwd','')).resolve()
  require(cwd==(homes[0] if argv[1]=='--owned-xhs-cli-pages' else self.exe.parent),'Fixed helper CWD required')
  require(options.get('creationflags',0)==getattr(subprocess,'CREATE_NO_WINDOW',0),'Hidden process creation required')
  require(all(not k.upper().startswith(('OPENAI_','AZURE_OPENAI_','CODEX_')) for k in env),'Model/provider overrides forbidden')
  require(not any(env.get(k) for k in ('PYTHONPATH','PYTHONHOME','NODE_OPTIONS','NODE_PATH')),'Runtime injection forbidden')
 def popen(self,argv,*a,**kw):
  # PageWorker/bridge merge os.environ in production. Strip host provider and
  # runtime overrides in the test child only, without changing parent env.
  kw=dict(kw)
  if type(kw.get('env')) is dict:kw['env']={k:v for k,v in kw['env'].items() if not k.upper().startswith(('OPENAI_','AZURE_OPENAI_','CODEX_')) and k not in ('PYTHONPATH','PYTHONHOME','NODE_OPTIONS','NODE_PATH')}
  self.validate(argv,kw);self.local.argv=tuple(map(str,argv))
  try:
   p=self.real(argv,*a,**kw);self.starts.append({'argv':list(argv),'pid':p.pid,'home':kw['env']['HOME']});return p
  finally:self.local.argv=None
 def audit_process(self,exe,argv):
  checked=getattr(self.local,'argv',None);require(checked is not None,'Popen must pass current-thread exact guard')
  require(exe is None or Path(exe).resolve()==self.exe,'Audit executable mismatch')
  require((tuple(map(str,argv))==checked if isinstance(argv,(list,tuple)) else argv==subprocess.list2cmdline(checked)),'Audit argv mismatch')
def child_env(home,proxy):
 home=Path(home).resolve();home.mkdir(parents=True,exist_ok=True)
 env={k:v for k,v in os.environ.items() if not k.upper().startswith(('OPENAI_','AZURE_OPENAI_','CODEX_')) and k not in ('PYTHONPATH','PYTHONHOME','NODE_OPTIONS','NODE_PATH')}
 env.update({k:str(home) for k in ('HOME','USERPROFILE','XDG_CONFIG_HOME','APPDATA','LOCALAPPDATA')})
 for k in ('HTTP_PROXY','HTTPS_PROXY','ALL_PROXY'):env[k]=env[k.lower()]=proxy[k]
 env.update(NO_PROXY='',no_proxy='',SSL_CERT_FILE=proxy['SSL_CERT_FILE'],PYTHONUTF8='1')
 temporary=home/'tmp';temporary.mkdir(exist_ok=True)
 env.update(LEADSTUDIO_ISOLATED='1',WORKSPACE_ACTIVITY_LOG=str(home/'platform-activity.jsonl'),WORKSPACE_ACTIVITY_KIND='other',TEMP=str(temporary),TMP=str(temporary))
 return env
