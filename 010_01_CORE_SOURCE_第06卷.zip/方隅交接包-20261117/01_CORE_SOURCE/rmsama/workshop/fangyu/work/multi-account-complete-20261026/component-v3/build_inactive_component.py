"""Explicitly reviewed, non-overwriting component build. Never run the CLI.



No default action. A separate non-author report and root-written pins are

required before --build. This is not an installer or original runtime update.

"""

from pathlib import Path

import argparse

import hashlib

import importlib.util

import json

import os

import shutil

import stat

import subprocess

import sys

import base64



HERE = Path(__file__).resolve().parent

PROJECT = Path('C:\\积木软件工坊\\项目\\方隅公寓客户版')

STAGE = HERE.parent

BUILD = HERE / 'build-work'

ARTIFACTS = HERE / 'artifacts'

COMPONENT = ARTIFACTS / 'platform-cli-customer-read'

INPUT = HERE / 'INPUTS.json'

SELF = Path(__file__).resolve()

TOOL = HERE / 'build_tool_entry.py'

CHILD_TOOL = HERE / 'build_child_entry.py'

IO_FENCE = HERE / 'build_io_fence.py'





def sha(path):

    h = hashlib.sha256()

    with Path(path).open('rb') as stream:

        for chunk in iter(lambda: stream.read(1024 * 1024), b''):

            h.update(chunk)

    return h.hexdigest().upper()





def plain(path, root, exists=True):

    path, root = Path(path), Path(root)

    if not path.is_absolute() or not path.is_relative_to(root):

        raise ValueError('path escaped fixed root')

    at = root

    for part in path.relative_to(root).parts:

        at /= part

        if at.exists() and at.stat().st_file_attributes & stat.FILE_ATTRIBUTE_REPARSE_POINT:

            raise ValueError('reparse path refused')

    if exists and not path.is_file():

        raise ValueError('fixed file missing: ' + str(path))

    return path





def reviewed(path):

    pins = json.loads(plain(path, STAGE).read_text('utf-8'))

    if set(pins) != {'schema', 'inputs_sha256', 'script_sha256', 'tool_entry_sha256', 'child_entry_sha256', 'io_fence_sha256', 'review'} or pins['schema'] != 'inactive_cli_build_review_pins_v1':

        raise ValueError('fixed review pins required')

    if (pins['inputs_sha256'] != sha(INPUT) or pins['script_sha256'] != sha(SELF)

            or pins['tool_entry_sha256'] != sha(TOOL)

            or pins['child_entry_sha256'] != sha(CHILD_TOOL)

            or pins['io_fence_sha256'] != sha(IO_FENCE)):

        raise ValueError('reviewed build source changed')

    review = pins['review']

    if set(review) != {'path', 'sha256'}:

        raise ValueError('review report pin required')

    report = plain(Path(review['path']), STAGE)

    if report.is_relative_to(HERE) or sha(report) != review['sha256']:

        raise ValueError('non-author report absent or changed')

    text = report.read_text('utf-8')

    if ('STATIC_APPROVED_FOR_ISOLATED_COMPONENT_BUILD' not in text

            or pins['inputs_sha256'] not in text or pins['script_sha256'] not in text):

        raise ValueError('specific non-author build review not approved')





def verify_inputs(manifest):

    if (manifest['schema'] != 'inactive_cli_build_inputs_v1'

            or manifest['project'] != str(PROJECT) or manifest['production_approval'] is not False

            or manifest['wrapper_sha256'] != '1513B1672C72811E0400C4B8806180C986E301EB50ECF9C332C767E22CD2986F'):

        raise ValueError('different fixed component inputs')

    roots = [HERE / 'inputs-source', PROJECT / 'work/product-upgrade-20261009/cli-backup/source',

             PROJECT / 'work/qa-cli-source-20260926', PROJECT / 'work/desktop-python/Lib/site-packages']

    targets = set()

    for item in manifest['inputs']:

        p = Path(item['path'])

        root = next((r for r in roots if p.is_relative_to(r)), None)

        if root is None:

            raise ValueError('input outside permitted public/source roots')

        plain(p, root)

        if p.stat().st_size != item['bytes'] or sha(p) != item['sha256']:

            raise ValueError('fixed input changed: ' + str(p))

        target = item['target']

        if target is not None:

            rel = Path(target)

            if rel.is_absolute() or '..' in rel.parts or target in targets or rel.parts[0] not in ('source','site'):

                raise ValueError('snapshot target invalid')

            targets.add(target)

    # Only the six already reviewed public Python image/DLL pins, not any

    # original CLI runtime or full machine scan.

    for item in manifest['python_native_pins']:

        p = Path(item['path'])

        if not p.is_file() or sha(p) != item['sha256']:

            raise ValueError('fixed public Python image changed')

    python = Path(manifest['python'])

    if python != PROJECT / 'work/desktop-python/Scripts/python.exe':

        raise ValueError('fixed compiler Python changed')





def main():

    parser = argparse.ArgumentParser()

    parser.add_argument('--build', action='store_true')

    parser.add_argument('--review-pins', type=Path)

    args = parser.parse_args()

    if not args.build or args.review_pins is None:

        parser.error('explicit --build plus non-author --review-pins required')

    reviewed(args.review_pins)

    manifest = json.loads(INPUT.read_text('utf-8'))

    if BUILD.exists() or ARTIFACTS.exists():

        raise ValueError('owned build/artifact target already exists; no overwrite or automatic retry')

    plain(BUILD, HERE, False)

    plain(ARTIFACTS, HERE, False)

    verify_inputs(manifest)

    BUILD.mkdir()

    for item in manifest['inputs']:

        if item['target'] is None:

            continue

        target = BUILD / item['target']

        target.parent.mkdir(parents=True, exist_ok=True)

        shutil.copyfile(item['path'], target)

        if target.stat().st_size != item['bytes'] or sha(target) != item['sha256']:

            raise ValueError('snapshot copy changed')

    (BUILD / 'inputs-snapshot.json').write_bytes(INPUT.read_bytes())

    for name in ('temp','cache','dist','spec','work','pycache'):

        (BUILD / name).mkdir()

    env = {k:v for k,v in os.environ.items() if not k.upper().startswith(('PYTHON','PIP','UV_','HTTP_PROXY','HTTPS_PROXY','ALL_PROXY'))}

    env.update(PYTHONDONTWRITEBYTECODE='1',

               PYINSTALLER_CONFIG_DIR=str(BUILD/'cache'), TEMP=str(BUILD/'temp'), TMP=str(BUILD/'temp'),

               NO_PROXY='*', PIP_NO_INDEX='1', PIP_DISABLE_PIP_VERSION_CHECK='1')

    command = [manifest['python'], '-X', 'utf8', '-B', '-I', '-S',

               '-X', 'pycache_prefix=' + str(BUILD/'pycache'), str(TOOL),

               '--onedir','--console','--noupx','--name','platform-cli-customer-read',

               '--distpath',str(BUILD/'dist'),'--workpath',str(BUILD/'work'),

               '--specpath',str(BUILD/'spec'),'--paths',str(BUILD/'source'),

               '--paths',str(BUILD/'site'),'--collect-all','xhs_cli',

               '--collect-all','webview','--log-level','WARN']

    for excluded in manifest['excludes']:

        command += ['--exclude-module', excluded]

    # The recovery protocol hashes this exact source at runtime, including frozen CLI.

    command += ['--add-data',str(BUILD/'source/core/xhs_identity_recovery.py')+os.pathsep+'core']
    command += ['--hidden-import','assistant.xhs_cli_page_worker']
    command += ['--hidden-import','assistant.xhs_reply_worker','--hidden-import','core.reply_execution_policy','--hidden-import','assistant.reply_read_session']
    command += ['--hidden-import','core.acquisition_extension.contracts','--hidden-import','core.acquisition_extension.guarded_port']

    command.append(str(BUILD/'source/platform_cli.py'))

    with (BUILD/'compiler.log').open('wb') as log:

        result = subprocess.run(command, cwd=BUILD, env=env, stdin=subprocess.DEVNULL,

                                stdout=log, stderr=subprocess.STDOUT)

    if result.returncode != 0:

        raise RuntimeError('compiler failed; retain owned build evidence, no retry')

    reviewed(args.review_pins)

    verify_inputs(manifest)

    dist = BUILD/'dist/platform-cli-customer-read'

    if not (dist/'platform-cli-customer-read.exe').is_file():

        raise ValueError('new component executable missing')

    ARTIFACTS.mkdir()

    shutil.copytree(dist, COMPONENT)

    # --collect-all keeps vendor source as data. Refuse a silently incomplete

    # vendor collection rather than treating only an executable as complete.

    for item in manifest['inputs']:

        if item['role'] != 'original_guard_vendor':

            continue

        vendor = COMPONENT / '_internal' / Path(item['target']).relative_to('site')

        if not vendor.is_file() or vendor.stat().st_size != item['bytes'] or sha(vendor) != item['sha256']:

            raise ValueError('compiled vendor source missing or changed')

    # Load only the original pure tree digest utility from the verified source

    # snapshot; importing App or executing a platform CLI is a later review.

    guard_source = BUILD/'source/core/runtime_guards.py'

    spec = importlib.util.spec_from_file_location('_inactive_tree_digest', guard_source)

    module = importlib.util.module_from_spec(spec)

    spec.loader.exec_module(module)

    guard = {'purpose':'internal_qa_only', 'request_transport':'single_attempt_all',

             'activity_recording':'account_local_v1','risk_stop':'review_required',

             'automatic_action_replay':False, 'sub_comments_query':'upstream_pr81',

             'source_sha256':manifest['wrapper_sha256'].lower(),

             'exe_sha256':sha(COMPONENT/'platform-cli-customer-read.exe').lower(),

             'runtime_tree_sha256':module.cli_runtime_tree_sha256(COMPONENT)}

    recovery_source=COMPONENT/'_internal/core/xhs_identity_recovery.py'

    expected_recovery=next(row['sha256'] for row in manifest['inputs'] if row['target']=='source/core/xhs_identity_recovery.py')

    if not recovery_source.is_file() or sha(recovery_source)!=expected_recovery:

        raise ValueError('recovery protocol source missing or changed in frozen CLI')

    guard['cli_page_worker']='task-bound-read-v1'
    guard['source_read_pages']='xhs-source-read-v1'
    guard['reply_profile_pages']='xhs-reply-profile-read-v1'
    guard['scoped_reply_transport']='reviewed-reply-v1'
    guard['reply_worker_sha256']='679867bbd21979e1796701afa806aacb9b38b5bfd02888b8cb51b99391d3451f'
    guard['profile_worker_sha256']='07b840298caf36a30a0c047387865e0989a5b7cce3f6c046aea18b4d0d33a13c'
    guard.update(identity_recovery='xhs-identity-revalidation-v1',

        identity_recovery_module_sha256=expected_recovery.lower())

    (COMPONENT/'guard-manifest.json').write_text(json.dumps(guard,indent=2)+'\n', encoding='utf-8')

    files = [{'relative':p.relative_to(COMPONENT).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p)}

             for p in sorted(COMPONENT.rglob('*')) if p.is_file()]

    artifact = {'schema':'inactive_guarded_cli_component_v1','files':files,'guard':guard,

                'input_manifest_sha256':sha(INPUT),'production_approval':False,

                'compiled_component_prepared':True,'original_validator_checked':False,

                'cli_executed':False,'platform_actions':0,'native_loaded_bytes_verified':False}

    material_dir = ARTIFACTS/'materials'

    material_dir.mkdir()

    license_records = []

    for item in manifest['inputs']:

        target = item['target']

        if not target:

            continue

        name = Path(target).name.lower()

        if item['role']=='source_license_original' or name in ('license','license.txt','license.md','copying','copying.txt'):

            data = (BUILD/target).read_bytes()

            license_records.append({'source':item['path'],'sha256':item['sha256'],

                                    'original_bytes_base64':base64.b64encode(data).decode('ascii')})

    # Preserve real bytes. The known standalone xhs license gap stays unknown;

    # the file role/name is not an approval, nor synthesized license wording.

    license_bundle = {'schema':'actual_known_license_bytes_v1','originals':license_records,

                      'unresolved':['xiaohongshu-cli 0.6.4 standalone original LICENSE/NOTICE'],

                      'production_approval':False}

    (material_dir/'license_text.txt').write_text(json.dumps(license_bundle,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

    notice = {'schema':'inactive_component_notice_v1','wrapper_sha256':manifest['wrapper_sha256'],

              'vendor':'original guard-reviewed xhs source snapshot, not the 1F0 subcomments candidate',

              'distributions':manifest['distributions'],

              'metadata_license_is_not_authoritative_license_text':True,

              'proxy_tools_upstream_license':'BSD-3-Clause; preserve source original, metadata differs',

              'production_approval':False,'platform_authorization':'unknown'}

    inventory = {'schema':'compiled_component_inventory_v1','files':files,

                 'input_manifest_sha256':sha(INPUT),

                 'analysis_toc_sha256':sha(BUILD/'work/platform-cli-customer-read/Analysis-00.toc'),

                 'running_loaded_bytes_verified':False,'production_approval':False}

    evidence = {'schema':'inactive_component_build_evidence_v1','compiler_returncode':result.returncode,

                'original_validator_checked':False,'help_or_cli_executed':False,

                'platform_actions':0,'production_approval':False,

                'review_pins_sha256':sha(args.review_pins)}

    for name, value in [('component_notice.json',notice),('actual_dependency_inventory.json',inventory),('review_evidence.json',evidence)]:

        (material_dir/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

    artifact['materials'] = {role:{'relative':'materials/'+name,'bytes':(material_dir/name).stat().st_size,'sha256':sha(material_dir/name)}

        for role,name in [('license_text','license_text.txt'),('component_notice','component_notice.json'),

                          ('actual_dependency_inventory','actual_dependency_inventory.json'),('review_evidence','review_evidence.json')]}

    (ARTIFACTS/'artifact-manifest.json').write_text(json.dumps(artifact,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

    frozen = {'schema':'inactive_built_component_frozen_v1',

              'input_manifest_sha256':sha(INPUT),

              'review_pins_sha256':sha(args.review_pins),

              'production_approval':False,

              'outputs':[{'relative':p.relative_to(ARTIFACTS).as_posix(),

                          'bytes':p.stat().st_size,'sha256':sha(p)}

                         for p in sorted(ARTIFACTS.rglob('*')) if p.is_file()]}

    (ARTIFACTS/'FROZEN.json').write_text(json.dumps(frozen,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

    print(json.dumps({'component':str(COMPONENT),'files':len(files),'compiled':True,

                      'validator_checked':False,'cli_executed':False,'production_approval':False}))





if __name__ == '__main__':

    main()

