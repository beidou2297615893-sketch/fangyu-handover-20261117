# 正常受控回复的远端许可

2026-10-26，Astra。已只读检查本次真实云端 ZIP 内 customer_read_release.cjs 与 devices.cjs；云端基线树为 `843361adb2bf456a4c23ea86bdd2dad6904c7e92634001978226f8d74ed7a84b`。只从该后继版本增量修改，不能以旧候选覆盖后继。

## 实际安装兼容补充（优先于下文仅 1.2 的初始描述）

已只读取证当前 ba1ea294 的 work/app/company.json：releaseVersion 为 `1.1.8-pilot.1`、portable_employee_release=true、workbench_source_release=`fangyu-admin-local-v1`。其原正常读取权限来自 employee/source-admin 心跳，不是 frozen customer 1.2 read request。不得为接新功能盲改 company 版本和许可配置。

因此服务器固定材料 allowlist 允许两个精确版本分支，仍共用独立 reviewed_reply 协议：

1. `1.2.0-read.1`：原 customerReadPolicy、matching customer-read request、read lease allowed 均成立。
2. `1.1.8-pilot.1`：原 employeeRelease(device).allowed=true、continuous_read=true；且既有 `adminWorkbenchFor(company,device,owner)` 实际返回 true，复用现有固定 owner/device/source marker 的已审 policy。请求、设备与 employee lease 的版本匹配，source marker 为 fangyu-admin-local-v1。仅请求自报 marker 不够。

两个分支共同保留当前认证设备/员工、正常有效 can_reply、非 QA、前次心跳新鲜度以及新固定材料 digest 检查。响应 version 为实际匹配的精确版本；其他字段不变。旧 read grant、远端 commands 和三个本地 flags 不改。这是服务器新增独立发送许可的版本兼容，不是拿 employee/read lease 当作发送权。

公开资料读取也可接受当前原有效 employee/source-admin 读取许可，但需校验 core.employee_release_device_id 等于当前 claim 的实际设备、monotonic deadline、原 version/source marker 与当前员工会话，另核新受控读材料。发送始终再要求独立 SendLease。

## 接口

在既有认证 device_poll 增加两个请求字段，不增加公开授权端点：

```json
{"reviewed_reply_protocol":"fangyu-reviewed-reply-v1","material_sha256":"64位小写十六进制"}
```

响应中的独立 `reviewed_reply_release` 严格包含：

```json
{
  "schema":"fangyu_reviewed_reply_lease_v1",
  "allowed":true,
  "company_id":"fangyu-apartment-client",
  "device_id":"当前认证设备",
  "owner":"该设备实际员工",
  "version":"1.2.0-read.1",
  "purpose":"reviewed_reply",
  "permission_revision":"64位小写十六进制",
  "material_sha256":"64位小写十六进制",
  "lease_seconds":45,
  "public_send_allowed":true
}
```

拒绝时 allowed=false、lease_seconds=0、public_send_allowed=false；拒绝不修改设备、用户权限或企业配置。不要把错误细节、凭据或用户数据放进许可。

材料摘要采用发送 Registration.manifest_digest 的规范 JSON SHA256，云端固定 allowlist 同时绑定 protocol、client version、material digest。编译后由已审材料填写固定值；请求中的 digest 只能用于查固定表，不能加入表或自行创建 grant。客户端对响应 digest 与原固定材料精确核对，并在每个 wire 前验证实际文件。

材料 digest 是服务器允许的客户端发布身份，不是可信硬件远端证明。实际文件完整性由本机固定材料、封闭装配和注册检查保证，不能声称云端已经测量了客户端可执行文件。

## 服务器正常权限判定

同一认证事务内，全部满足才允许：

- 方隅企业及原 customerReadPolicy 有效；原 customer_read_protocol 请求匹配且该设备本次 read lease 合法。
- 当前设备 bearer 通过原认证；设备未撤销，心跳时间合法且在线，device owner 与实际活跃用户相符。
- 用户角色为既有 admin/operator；有效 can_reply 沿现有 `owner.can_reply !== false` 语义，明确 false 必须拒绝。不要为了新字段改数据库中的旧权限默认值。
- 请求版本为既有 read client version，新增协议和材料在固定 reviewed allowlist 中。
- 非 QA 设备/QA 协议，不借 reply_trial，不因新许可改变原远端命令规则。

permission_revision 为稳定的有效权限元组摘要，包含用户名、角色、disabled、有效 can_reply 和已有 permission_revision（若存在）。同一次 poll 的 owner_permissions 回传该 revision 与 can_reply；不得用当前时间当 revision，避免每次心跳无意义撤销正在执行的相同权限。为保护旧客户端形状，仅新协议响应需要附加 revision。

保留原 customer_read_release.public_send_allowed=false、accept_commands=false、commandHeld、command_submit、QA trial 和任何已有客户端路径。新许可只表示当前设备员工可进行本地已明确确认的受控评论队列；不开放通用远端命令、不授权账号创建/登录/关注/私信/任意发布。

## 客户端消费

只由原 Runner 的认证 cloud.call(device_poll) 返回创建独立 sealed 内存 lease；先同步本次 owner_permissions，再校验整个许可。deadline 使用 poll_started + min(45, lease_seconds)，不是收到响应后的时间；延迟已过期的响应拒绝。

绑定原 Service/Runner/Executor/_DeviceSession、公司、device、owner、client version、permission revision、固定材料摘要。每次 wire 重新验证；缺失、拒绝、过期、版本/材料/身份不符、权限变化、任何认证 poll 异常均清空旧许可并停止后续回复。read lease 不可充当 send lease。

不把队列正文/客户资料或每个账号上传给新增心跳。账号由原云端 device_account_claim 与本地 sealed queue、批准快照、routing CAS、独立会话实际 UID 共同约束；远端许可不替代这层绑定。

Host 必须在原 Service 启动前安装经审查材料，或在每次 poll 通过相同固定 authority 安全重新取得请求对象；不得因为启动时 request_for=None 就永久不再请求新许可。

## 最小验收

正确既有只读 heartbeat + 新固定材料得到独立 send grant，旧 read grant 内容及远端 command 行为不变。协议/版本/材料任一错误、其他企业、owner/设备错配、停用或 can_reply=false、QA、过期/晚到/异常poll、旧grant重放均零 POST。权限撤销和材料更新后旧在途批次下一 wire 必须停止。服务端改动仅新模块与原设备心跳接线，不修改配置、用户权限或数据库结构。
