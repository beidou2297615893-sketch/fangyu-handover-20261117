# 第三版组件精确编译审查

2026-10-27，Astra，非脚本作者。

STATIC_APPROVED_FOR_ISOLATED_COMPONENT_BUILD

批准 root 在新 component-v3 目录按以下精确输入执行一次既有离线 --build。原 component、component-v2 与 compiled-01/02/03/04 原样保留。本条仅编译，不授权执行生成 CLI、真实登录/平台/GUI、云部署或客户端安装。

- INPUTS.json：7F3933FBACF877D075A6D1F2860CE5CAACC196BFB1CD59DA83E0B7881227B5B0
- build_inactive_component.py：0980255EBC312DA7A5DCA7E8658216624BA1CC726076102ED2F1DF38519AF536
- build_tool_entry.py：18C9723ED1148CE80AD6358F6A7C33ACA3B452D665B361655E0541398CA16718
- build_child_entry.py：D71912D41A68F18B04BF64C8C647BD59934A6BEF166B358F4DDB82C6CAE9833E
- build_io_fence.py：FCF713D589E9262E903B9AED6AB893D17F155087B8CFD7F8F0A41EA0E00AF4AD
- 新 page worker：07B840298CAF36A30A0C047387865E0989A5B7CCE3F6C046AEA18B4D0D33A13C

独立核对全部 3533 INPUTS 的真实大小与 SHA256，零不匹配。对比 v2 的具名 inputs 仅 source/assistant/xhs_cli_page_worker.py 改变；build_inactive_component.py 唯一变化为 profile_worker_sha256 常量随之更新，其他三个 builder 哈希不变。wrapper 和其余 256 source 不变，sender worker、core engine 未扩大修改。

已审查新 worker：每页重置私有 binding；仅在严格 endpoint/query gate 成功且当前 parent wire_allow 精确匹配后生成本页 binding。公开 user 缺 UID 需要该绑定；错误 query、父拒绝、无 wire 均不能生成证明。显式 UID 冲突或非法类型拒绝，red_id 不用于身份；whoami/帖子/发送规则保持原约束。原文输出明确区分 response_uid/request_bound_subject，后者没有伪造 user_id。

父 valid_profile_subject 校验精确形状、subjectId 与源种类；profile 输出及采用后的证据保留 identitySource。已独立执行 test_profile_subject_compat.py（7/7）及 test_profile_subject_evidence.py（1 项含两子场景）均 PASS，实际固定 Python、无真实平台请求。测试覆盖成功精确 wire、错误 query、拒绝 allow、无 wire、冲突/畸形身份、父形状与采用保留。

保留原 fixed interpreter、隔离构建目录、-I -S -B 与 build_io_fence 全边界。生成后须重新核对输出冻结树和 EXE，单独批准新 harness-v3 单次 loopback 验收；此前 compiled-04 仍 FAIL，不替代 v3 验收。
