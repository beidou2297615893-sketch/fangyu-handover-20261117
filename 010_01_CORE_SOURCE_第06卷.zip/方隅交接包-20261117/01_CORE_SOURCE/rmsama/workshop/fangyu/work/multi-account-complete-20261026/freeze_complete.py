"""Prepare auditable provenance and stage an already overlaid isolated candidate.
Explicit execution only. No install, promote, GUI, platform or production writes.
"""
from pathlib import Path
import ast,hashlib,importlib.util,json,subprocess,sys
sys.dont_write_bytecode=True
T=Path(__file__).resolve().parent;P=T.parents[1];PROJECT=T/'assembly/project'
read=lambda p:json.loads(p.read_text('utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,v):
 p.parent.mkdir(parents=True,exist_ok=True)
 with p.open('x',encoding='utf-8') as f:json.dump(v,f,ensure_ascii=False,indent=2);f.write('\n')
def load_assembler():
 spec=importlib.util.spec_from_file_location('reply_complete_assembler',T/'assemble_complete.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m

def main():
 assert sys.argv[1:]==['--stage-prepared-candidate'],'Explicit candidate staging argument required'
 assert not (T/'FROZEN-PINS.json').exists()
 base=read(T/'assembly/BASE-COPY.complete.json');baseline=base['files'];original=Path(base['source'])
 canonical=read(T/'BASELINE.json')['canonical']
 def check_live():
  for n,h in canonical.items():assert sha(P/'work/ui-native-r57'/n)==h,n
 check_live()
 mapping={target.relative_to(PROJECT).as_posix():source for source,target in load_assembler().plan()}
 # Before modifying candidate metadata, require every copied/overlaid byte to
 # come from the exact baseline or the declared independent candidate source.
 current={p.relative_to(PROJECT).as_posix():sha(p) for p in PROJECT.rglob('*') if p.is_file()}
 material_names={'work/ui-native-r57/'+n for n in ('reply_public_read_materials.json','reviewed_reply_materials.json')}
 assert set(current)==set(baseline)|set(mapping)|material_names
 for n,h in current.items():
  if n in material_names:continue
  assert h==(sha(mapping[n]) if n in mapping else baseline[n]),n
 for n,h in baseline.items():assert sha(original/n)==h,n
 # Maintain historical upstream hashes; only candidate provenance is refreshed.
 source_name='work/shared-backend-integration/vendor-src/SOURCE.json'
 source=read(PROJECT/source_name)
 assert isinstance(source.get('files'),dict),'Unsupported existing provenance shape'
 for p in sorted((PROJECT/'work/shared-backend-integration/vendor-src').rglob('*.py')):
  relative=p.relative_to(PROJECT/'work/shared-backend-integration/vendor-src').as_posix()
  digest=sha(p);row=source['files'].get(relative)
  if row is None:source['files'][relative]={'source_sha256':None,'candidate_sha256':digest}
  elif isinstance(row,dict):row['candidate_sha256']=digest
  else:raise AssertionError('Unsupported provenance entry: '+relative)
 generated=T/'assembly/generated';generated.mkdir(parents=True,exist_ok=True)
 provenance=generated/'shared-vendor-SOURCE.json';write(provenance,source)
 (PROJECT/source_name).write_bytes(provenance.read_bytes());mapping[source_name]=provenance
 for n in material_names:
  independent=T/'materials'/Path(n).name;independent.parent.mkdir(parents=True,exist_ok=True)
  with independent.open('xb') as f:f.write((PROJECT/n).read_bytes())
  mapping[n]=independent
 current={p.relative_to(PROJECT).as_posix():sha(p) for p in PROJECT.rglob('*') if p.is_file()}
 changes={}
 for n,h in sorted(current.items()):
  before=baseline.get(n)
  if before==h:continue
  candidate=mapping[n];assert candidate.resolve()!=(PROJECT/n).resolve();assert sha(candidate)==h,n
  row=dict(projectRelativePath=n,sourcePath=str(original/n),candidatePath=str(candidate),candidateSha256=h,sourceSha256=before,before=before,after=h,publishedRelativePath=None,owner='multi-account-complete')
  if n.startswith('work/ui-native-r57/') and Path(n).name!='freeze_ui.py':row['publishedRelativePath']=Path(n).name
  elif n.startswith('work/ui-approved-implementation/ui-preview/'):row['publishedRelativePath']='web/'+n.split('ui-preview/',1)[1]
  elif n.startswith('work/shared-backend-integration/'):row['publishedRelativePath']='resources/platform-runtime/'+n.split('shared-backend-integration/',1)[1]
  elif n.startswith('work/ui-runtime-r55/src/'):row['backendDependencyRelativePath']=n.split('ui-runtime-r55/src/',1)[1]
  elif n.startswith('work/app/src/'):
   row['mirrorOf']='work/ui-runtime-r55/src/'+n.split('work/app/src/',1)[1];assert sha(PROJECT/row['mirrorOf'])==h,n
  elif n.startswith('work/reply-complete-worker/'):row['externalRuntimeMaterial']=True
  elif n!='work/ui-native-r57/freeze_ui.py':raise AssertionError('Unclassified change '+n)
  changes[n]=row
 expected={**baseline,**{n:r['after'] for n,r in changes.items()}}
 assert current==expected
 write(T/'assembly/CHANGES.final.json',dict(files=changes,baselineFiles=len(baseline),sourceFiles=len(expected),productionDataAccess=False))
 write(generated/'FINAL-SOURCE-MAP.json',{'files':{n:{'candidatePath':str(p),'sha256':sha(p)} for n,p in sorted(mapping.items())}})
 # Fixed approved interpreter, isolated candidate-only freezer; stage never promotes.
 native=PROJECT/'work/ui-native-r57'
 code="import importlib.util,sys;from pathlib import Path;sys.dont_write_bytecode=True;native=Path(sys.argv[1]);sys.path.insert(0,str(native));spec=importlib.util.spec_from_file_location('reply_complete_freezer',native/'freeze_ui.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);m.VENV=Path(sys.argv[2]);raise SystemExit(m.main(['--stage']))"
 run=subprocess.run([str(P/'work/desktop-python/Scripts/python.exe'),'-B','-c',code,str(native),str(P/'work/desktop-python')],capture_output=True,text=True,encoding='utf-8',errors='strict',timeout=300,check=True)
 stage=json.loads(run.stdout);write(T/'assembly/STAGED.json',stage);release=Path(stage['release'])
 for n,h in expected.items():assert sha(PROJECT/n)==h,'Source changed during freezing: '+n
 files=[dict(path=p.relative_to(PROJECT).as_posix(),bytes=p.stat().st_size,sha256=sha(p)) for p in sorted(PROJECT.rglob('*')) if p.is_file()]
 write(T/'assembly/UNIFIED-PINS.json',dict(schema='fangyu-inactive-customer-closure-v1',root='project',files=files,release=stage,production_data_access=False,promoted=False))
 pins=dict(status='STAGED_NOT_INSTALLED',project=str(PROJECT),release=str(release),releaseId=stage['release_id'],manifestSha256=sha(release/'RELEASE.json'),stagedSha256=sha(T/'assembly/STAGED.json'),launcherPath=stage['launcher'],launcherSha256=sha(Path(stage['launcher'])),unifiedPinsSha256=sha(T/'assembly/UNIFIED-PINS.json'),changesSha256=sha(T/'assembly/CHANGES.final.json'),installed=False,automaticSendingEnabled=False,productionWrites=0)
 write(T/'FROZEN-PINS.json',pins);check_live()
 print(json.dumps({'status':pins['status'],'changedFiles':len(changes),'releaseId':pins['releaseId']}))
if __name__=='__main__':main()
