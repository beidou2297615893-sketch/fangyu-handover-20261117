# 编译组件首请求断线：根因与第二版路线

2026-10-27，Astra。

compiled-03 已 ready、随后 exit 2、没有 wire_allow，符合 serve 在 runner(args) 之前失败的分支。exact_source_gate 会首次导入 core.acquisition_extension；core/__init__.py 立即导入 engine，再导入 store。冻结 store.py 第8行引用 customer_intent_dirty，而 prepare_component.py 仅沿旧组件 source 文件清单复制，未自动纳入后来新增的依赖文件。独立源码 probe 已由 Sol 复现缺失模块。contracts/guarded_port/worker 在 Analysis-00.toc 内均存在，不是这三个 hidden-import 遗漏。

明确修复：保留原 component 及 compiled-01/02/03，创建 component-v2。优先复制第一版精确输入，只增补缺失静态依赖闭包；customer_intent_dirty 还静态依赖 customer_intent_materials。新增模块取确认同源的最终候选/已审基线并固定原始字节与来源。不得删掉原 store guard、stub core、绕过包初始化或放宽 exact_source_gate。

不因本故障无差别刷新全部255模块。父宿主的新 lease/read registration/adapter 调整不等于子 helper 必须同时更换；父子私有协议与实际 worker 保持已审代码，新增变化必须由依赖证据或真实协议需要说明。若后续 probe 证明需要更多依赖，则一次补齐证明成立的闭包。

编译前代表性验证：全新 Python 进程从新快照导入真实 core/__init__，禁止外联、进程、业务数据库与非测试目录写入；执行 whoami/user/user-posts exact_source_gate，以及发送 worker import 和 fake transport 协议。不能预先注入 stub core 或借用已加载的其他工程模块。加入静态依赖闭包核查，避免再次把旧文件列表误认为完整依赖。

本条批准离线准备与源码小样路线，不是第二次编译或 EXE 运行批准；v2 INPUTS、脚本、完整差异及通过结果固定后另行精确批准。再次直接运行现有 exe hello/page 不会显示被吞异常，诊断增益不足，当前不批准这种重跑。
