from pathlib import Path
import ast,json
T=Path(__file__).resolve().parent.parent;ROOT=T.parents[1]
tree=ast.parse((T/'verify_integrated.py').read_text('utf-8-sig'));main=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='main')
statements=[];active=False
for node in main.body:
 if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='values' for t in node.targets):active=True
 if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='env' for t in node.targets):break
 if active:statements.append(node)
project=T/'assembly/project';release=project/'work/ui-native-r57/releases/PLANNED_FINAL_RELEASE'
g={'TASK':T,'ROOT':ROOT,'Path':Path,'read':lambda p:json.loads(p.read_text('utf-8-sig')),'project':project,'release':release,'py':str(ROOT/'work/desktop-python/Scripts/python.exe'),'pins':{'launcherPath':str(project/'work/ui-native-r57/run_candidate.PLANNED.py')},'output':T/'verification/PLANNED'}
exec(compile(ast.Module(body=statements,type_ignores=[]),'<argv-construction-only>','exec'),g)
missing=[];order=[]
for name,argv in g['jobs']:
 order.append(name)
 for arg in argv:
  if Path(arg).suffix in ('.py','.mjs','.cjs') and '*' not in arg and not Path(arg).is_file():missing.append({'job':name,'path':arg,'plannedReleaseDependent':str(release) in arg or arg.endswith('run_candidate.PLANNED.py')})
report={'executedTests':False,'constructedJobs':len(g['jobs']),'missingScriptPaths':missing,'ownerOrder':[n for n in order if n.startswith(('backend-','frontend-'))],'sourceTargetConcerns':['profile-subject-binding-compatibility passes final worker but test hardcodes component-v2 source path and candidate parent module; add explicit final parent/runtime arguments','per-account-original-login-entry new DOM test imports candidate module statically; pass --release and import actual release module for final evidence'],'ownerExportsSerializedBeforeIndependentFixtures':True}
(T/'binary-debug/INTEGRATED-ARGV-STATIC-REVIEW.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n','utf-8')
print(json.dumps(report,ensure_ascii=False))

