from pathlib import Path
import sys,json,hashlib,traceback,socket,subprocess
sys.dont_write_bytecode=True
T=Path(__file__).resolve().parent.parent;D=T/'binary-debug'
def blocked(*a,**k):raise RuntimeError('diagnostic forbids network/process')
socket.socket.connect=socket.socket.connect_ex=socket.create_connection=socket.getaddrinfo=blocked
subprocess.Popen=blocked
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
report={'compiledChildExecuted':False,'platformCalls':0}
inputs=json.loads((T/'component/INPUTS.json').read_text('utf-8-sig'))
rows=[r for r in inputs['inputs'] if str(r.get('target') or '').startswith('source/')]
report['sourceInputCount']=len(rows);report['inputRowKeys']=list(rows[0]);report['inputMismatches']=[]
for r in rows:
 p=Path(r['path']);h=r.get('sha256',r.get('hash','')).lower()
 if sha(p)!=h:report['inputMismatches'].append(r['target'])
report['snapshotDiffs']=[]
for root in [T/'candidate/worker',T/'candidate/runtime']:
 for p in root.rglob('*.py'):
  rel=p.relative_to(root);q=T/'component/inputs-source'/rel
  if not q.is_file() or sha(q)!=sha(p):report['snapshotDiffs'].append(str(rel))
sys.path[:0]=[str(T/'component/inputs-source'),str(T/'component/build-work/site')]
try:
 from assistant.xhs_cli_page_worker import exact_source_gate
 gate=exact_source_gate(['whoami','--json','--phase','before'])
 report['exactGate']='PASS';report['gateType']=str(type(gate))
except Exception as e:report['exactGate']='FAIL';report['gateError']=traceback.format_exc()
(D/'PROBE.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),'utf-8');print(json.dumps(report,ensure_ascii=False))

