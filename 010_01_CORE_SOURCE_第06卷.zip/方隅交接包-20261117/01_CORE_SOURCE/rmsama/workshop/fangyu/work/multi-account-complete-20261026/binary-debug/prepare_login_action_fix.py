from pathlib import Path
T=Path(__file__).resolve().parent.parent
p=T/'candidate/web/pages/reply-public-read.mjs';s=p.read_text('utf-8')
assert s.count("await ctx.actions.accountWebsiteOpen({accountId:el.dataset.sessionLogin});")==1
s=s.replace("await ctx.actions.accountWebsiteOpen({accountId:el.dataset.sessionLogin});","await ctx.actions.connectAccount('xiaohongshu',el.dataset.sessionLogin);")
s=s.replace('打开该账号原登录窗口','登录或检查该账号连接').replace('已提交该账号原登录窗口请求，请完成登录后重新核对独立会话。','请在账号页完成该原账号登录或检查连接，再返回核对本组独立会话。')
p.write_text(s,'utf-8')
