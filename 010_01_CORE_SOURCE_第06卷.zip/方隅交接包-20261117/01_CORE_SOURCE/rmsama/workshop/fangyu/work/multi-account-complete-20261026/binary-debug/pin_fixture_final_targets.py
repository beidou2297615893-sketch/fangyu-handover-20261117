from pathlib import Path
import hashlib
T=Path(__file__).resolve().parent.parent
p=T/'tests/backend/test_profile_subject_compat.py';s=p.read_text('utf-8-sig');needle="sys.path[:0]=[str(runtime)]"
s=s.replace(needle,needle+"\nimport core,core.acquisition_extension.contracts,core.acquisition_extension.guarded_port\nfor module in (core,core.acquisition_extension.contracts,core.acquisition_extension.guarded_port):\n assert Path(module.__file__).resolve().is_relative_to(runtime.resolve()),'Contract dependency escaped requested runtime'")
p.write_text(s,'utf-8')
for n in ('tests/backend/test_profile_subject_compat.py','tests/test_session_login_dom.mjs'):print(n,hashlib.sha256((T/n).read_bytes()).hexdigest())
