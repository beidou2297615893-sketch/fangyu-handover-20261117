"""Local public-read admission and same-session sequence; network/process forbidden."""
from pathlib import Path
import importlib.util,sys,os,json,time,unittest
from types import SimpleNamespace
from copy import deepcopy
from unittest.mock import patch
import argparse
parser=argparse.ArgumentParser(add_help=False)
for arg in ('project','release','candidate','runtime','shared'):parser.add_argument('--'+arg)
cli,remaining=parser.parse_known_args();sys.argv=[sys.argv[0],*remaining]
T=Path(__file__).resolve().parents[2];P=Path(cli.project) if cli.project else T.parent/'multi-account-reply-20261026/assembly/project';R=Path(cli.release) if cli.release else P/'work/ui-native-r57/releases/ui-r57-20261026T130202Z-ba1ea294';C=Path(cli.candidate) if cli.candidate else T/'candidate';RT=Path(cli.runtime) if cli.runtime else T/'candidate/runtime';SHARED=Path(cli.shared) if cli.shared else T/'candidate/shared'
os.environ.update(MULTI_REPLY_PROJECT=str(P),MULTI_REPLY_RELEASE=str(R),MULTI_REPLY_CANDIDATE=str(C))
previous=T.parent/'multi-account-reply-20261026/tests/backend/test_multi_account_integration.py'
spec=importlib.util.spec_from_file_location('old_multi_fixtures',previous);fixtures=importlib.util.module_from_spec(spec);spec.loader.exec_module(fixtures);fixtures.TASK=T
sys.path[:0]=[str(C),str(R),str(P/'work/ui-runtime-r55/src')]
import assistant
assistant.__path__.insert(0,str(RT/'assistant'))
from reply_public_profile import PublicReadWorkflow,JOBS
from reply_account_profiles import AUTOMATIC_EVIDENCE
from assistant.reply_read_session import run_registered_read,ReplyReadError,register_read

class PublicReadTests(unittest.TestCase):
 def setUp(self):
  f=self.f=fixtures.MultiTests('test_six_accounts_pet_recommends_B_and_workflow_confirms_without_send');f.setUp();self.addCleanup(f.doCleanups)
  self.calls=[];self.held=False;self.mismatch=False;self.cancel_during=False
  for aid in 'ABCDEF':
   account=f.store.get('accounts',aid);account['status']='ready';f.store.put('accounts',account)
  session=SimpleNamespace(check=lambda:None);executor=SimpleNamespace(_xhs_app_session=session)
  service=SimpleNamespace(device={'id':'device'},state='online',closed=False,executor=executor);runtime=SimpleNamespace(closed=False,core=f.core,service=service)
  runtime._customer_read_lease_current=lambda purpose:purpose=='xiaohongshu_natural_read'
  runtime._principal=lambda user:user;runtime._executor=lambda user,**kw:executor
  runtime._account=lambda user,aid:f.store.get('accounts',aid);runtime._device=lambda user:{'bound':True}
  runtime._readiness=lambda user,account,**kw:('held','原安全暂停') if self.held else ('','')
  runtime.server=SimpleNamespace(_platform_execution_guard=lambda platform:None)
  class Adapters:
   def __init__(inner):inner.xhs_cli_page_tasks={}
   def require_account_safe(inner,*a,**k):return None
   def manifest(inner,platform):return {'executable':str(Path(f.tmp.name)/'inert.exe'),'isolation_guard':True,'prefix_args':['xiaohongshu']}
   def begin_xhs_cli_pages(inner,job,home,scope,guard,**kw):
    inner.guard=guard;self.assertIs(kw['reply_profile'],True);inner.xhs_cli_page_tasks[job]={'home':home,'scope':scope,'guard':guard,'reply_profile':True}
   def end_xhs_cli_pages(inner,job):inner.xhs_cli_page_tasks.pop(job,None)
   def execute(inner,platform,args,home,job,**kw):
    claim=kw['_reply_profile_call'];claim.check_adapter(inner,platform,args,home,job);self.calls.append(deepcopy(args))
    if args[0]=='whoami':data={'user':{'id':'other' if self.mismatch else 'uidB'}}
    elif args[0]=='user':data={'subjectId':'customer-uid','identitySource':'response_uid','user_id':'customer-uid','desc':'想租一室，可以养猫吗'}
    else:data={'notes':[{'note_id':'n1','user_id':'customer-uid','title':'找房','desc':'预算两千'}]}
    if self.cancel_during:self.reader.controls[job]['cancel']=True
    return {'ok':True,'schema_version':'1','data':data}
  from core.continuous import AccountModeLeases
  f.core.continuous=SimpleNamespace(leases=AccountModeLeases(f.store,'offline-read-runtime'))
  f.core.adapters=Adapters();f.core.remote_safety_hold=False;f.core.deployment_config={'runtime':{'public_send_hold':True,'public_reply_hold':True,'xiaohongshu_automation':'hold'}};f.b.platform_runtime=runtime;self.runtime=runtime
  runtime.project=Path(f.tmp.name)
  material=Path(f.tmp.name);(material/'inert.exe').write_bytes(b'offline-inert-helper');(material/'source.py').write_text('offline',encoding='utf-8')
  import hashlib
  sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
  register_read(f.core,material,{'version':1,'protocol':'reply-profile-read-v1','helperFlag':'--owned-xhs-cli-pages','executable':'inert.exe','executableSha256':sha(material/'inert.exe'),'sources':{'source.py':sha(material/'source.py')}})
  self.reader=PublicReadWorkflow(f.b)
 def start(self,kind='profile',request='public1'):
  data={**self.f.base,'accountId':'B','requestId':request}
  action='reply_session_check'
  if kind=='profile':action='reply_public_profile_start';data.update(customerId='c',limitPosts=3)
  self.start_data=data
  value=self.reader.dispatch(action,data,'token')['replyPublicRead'];self.jobid=value['id']
  deadline=time.monotonic()+25
  while self.jobid in self.reader.controls:
   if time.monotonic()>=deadline:
    current=self.reader.dispatch('reply_read_status',{**self.f.base,'jobId':self.jobid},'token')['replyPublicRead']
    self.fail('Source fake read exceeded 25 seconds: '+json.dumps(current,ensure_ascii=False))
   time.sleep(.005)
  return self.reader.dispatch('reply_read_status',{**self.f.base,'jobId':self.jobid},'token')['replyPublicRead']
 def install_real_runtime_gates(self):
  import types,core
  core.__path__.insert(0,str(RT/'core'))
  shared=SHARED/'platform_runtime.py';spec=importlib.util.spec_from_file_location('read_gate_runtime',shared);module=importlib.util.module_from_spec(spec);sys.modules[spec.name]=module;spec.loader.exec_module(module)
  rt=self.runtime;rt.data_dir=self.f.store.directory
  rt.server.company={'releaseVersion':'1.2.0-read.1','runtime':{'xiaohongshu_automation':'hold','public_send_hold':True,'public_reply_hold':True},'platforms':['xiaohongshu']}
  rt.server._customer_read_authority=object();rt._customer_read_lease_current=lambda purpose:purpose=='xiaohongshu_natural_read'
  rt.core._employee_release_allowed=lambda:False;rt.core._page_read_allowed=lambda:False
  ex=rt.service.executor;ex.core=rt.core;ex.owner='owner';ex.tenant='t';ex.user_id='u'
  for name in ('_executor','_readiness','_reply_purpose_decision'):setattr(rt,name,types.MethodType(getattr(module.PlatformRuntime,name),rt))
  return module
 def install_real_app_guard(self):
  import types,core
  core.__path__.insert(0,str(RT/'core'))
  engine_spec=importlib.util.spec_from_file_location('core.read_gate_test_engine',RT/'core/engine.py');engine=importlib.util.module_from_spec(engine_spec);sys.modules[engine_spec.name]=engine;engine_spec.loader.exec_module(engine)
  for name in ('_platform_execution_guard','_reply_purpose_read_allowed','_reviewed_reply_allowed'):setattr(self.f.core,name,types.MethodType(getattr(engine.Core,name),self.f.core))
  app_spec=importlib.util.spec_from_file_location('read_gate_real_app',SHARED/'vendor-src/app.py');app=importlib.util.module_from_spec(app_spec);app.__FANGYU_SOURCE_ROOT__=str(P/'work/ui-runtime-r55/src');app.__FANGYU_RUNTIME_ROOT__=str(P/'work/app/work/runtime');app.__FANGYU_GUARDED_CLI_RUNTIME_ROOT__=str(P/'work/source-v66-worker/component/artifacts/platform-cli-guarded');app.__FANGYU_DOUYIN_RUNTIME_ROOT__=str(P/'work/ui-runtime-r55/work/runtime/douyin-bridge');sys.modules[app_spec.name]=app;app_spec.loader.exec_module(app)
  server=self.runtime.server;server.self_operating_read=False;server.manual_owned_read_start=False;server.private_evaluation_capability=None;server.employee_workspace_mode=True;server.core=self.f.core;server.assistant_service=self.runtime.service
  self.f.core.deployment_config.update(id='fangyu-apartment-client',releaseVersion='1.2.0-read.1')
  server._platform_execution_guard=types.MethodType(app.AppServer._platform_execution_guard,server)
 def test_real_app_and_core_guards_keep_three_holds_but_allow_exact_read_scope(self):
  self.install_real_runtime_gates();self.install_real_app_guard();before=deepcopy(self.runtime.server.company)
  with self.assertRaises(ValueError):self.runtime.server._platform_execution_guard('xiaohongshu')
  result=self.start();self.assertEqual(result['state'],'completed');self.assertEqual(self.runtime.server.company,before)
  with self.assertRaises(ValueError):self.runtime.server._platform_execution_guard('xiaohongshu')
 def test_real_app_remote_hold_and_qa_or_expired_read_lease_have_zero_wires(self):
  self.install_real_runtime_gates();self.install_real_app_guard()
  self.f.core.remote_safety_hold=True;self.assertEqual(self.start(request='remote-held')['state'],'blocked');self.assertEqual(self.calls,[])
  self.f.core.remote_safety_hold=False;self.f.core.deployment_config['runtime']['platform_qa_device_id']='device';self.assertEqual(self.start(request='qa-held')['state'],'blocked');self.assertEqual(self.calls,[])
  self.f.core.deployment_config['runtime'].pop('platform_qa_device_id');self.runtime._customer_read_lease_current=lambda purpose:False;self.assertEqual(self.start(request='expired-lease')['state'],'blocked');self.assertEqual(self.calls,[])
 def test_real_runtime_local_hold_gates_only_allow_current_reviewed_read_scope(self):
  self.install_real_runtime_gates()
  with self.assertRaises(ValueError):self.runtime._executor(self.f.user)
  before=deepcopy(self.runtime.server.company)
  result=self.start();self.assertEqual(result['state'],'completed');self.assertEqual(self.runtime.server.company,before)
  with self.assertRaises(ValueError):self.runtime._executor(self.f.user)
 def test_read_material_change_blocks_before_identity_wire(self):
  (Path(self.f.tmp.name)/'source.py').write_text('tampered',encoding='utf-8');result=self.start();self.assertEqual(result['state'],'blocked');self.assertEqual(self.calls,[])
 def test_start_response_loss_recovers_by_original_request_id(self):
  self.start();before=deepcopy(self.calls)
  recovered=self.reader.dispatch('reply_read_status',{**self.f.base,'requestId':self.start_data['requestId']},'token')['replyPublicRead'];self.assertEqual(recovered['id'],self.jobid);self.assertEqual(self.calls,before)
  missing=self.reader.dispatch('reply_read_status',{**self.f.base,'requestId':'not-created'},'token')['replyPublicRead'];self.assertEqual(missing['state'],'not_found')
 def test_adopt_receipt_is_observable_after_response_loss(self):
  self.start();self.reader.dispatch('reply_public_profile_apply',{**self.f.base,'jobId':self.jobid,'requestId':'adopt-response-lost','expectedEvidenceRevision':0},'token')
  recovered=self.reader.dispatch('reply_read_status',{**self.f.base,'jobId':self.jobid},'token')['replyPublicRead'];self.assertTrue(recovered['applied']);self.assertEqual(recovered['applyReceipt'],{'requestId':'adopt-response-lost','state':'accepted','evidenceRevision':1})
 def independent_backend(self):
  from core.engine import Core
  from core.store import Store
  from core.contact_journal import ContactJournal
  from reply_workbench import ReplyWorkbench
  f=self.f;store=Store(f.tmp.name);core2=Core.__new__(Core);core2.store=store;core2.lock=__import__('threading').RLock();core2.contact_journal=ContactJournal(store)
  b=SimpleNamespace(**vars(f.b));b.lock=__import__('threading').RLock();b.core=core2;b.reply_workbench=ReplyWorkbench(core2,fixtures.Customers(core2));return b
 def test_two_independent_backends_claim_one_read_request_atomically(self):
  import threading
  barrier=threading.Barrier(2);calls=[];out=[]
  def injected(user,row,guard):guard();calls.append(row['id']);return {'actorUid':'uidB','identityProofDigest':'a'*64}
  readers=[PublicReadWorkflow(self.f.b,injected),PublicReadWorkflow(self.independent_backend(),injected)]
  for reader in readers:
   original=reader._account;seen=set()
   def account(user,scope,aid,original=original,seen=seen):
    name=threading.current_thread().name
    if name.startswith('admit-') and name not in seen:seen.add(name);barrier.wait(3)
    return original(user,scope,aid)
   reader._account=account
  data={**self.f.base,'accountId':'B','customerId':'c','limitPosts':3,'requestId':'race-admission'}
  def start(reader):out.append(reader.dispatch('reply_public_profile_start',data,'token')['replyPublicRead']['id'])
  threads=[threading.Thread(target=start,args=(reader,),name='admit-'+str(i)) for i,reader in enumerate(readers)]
  for thread in threads:thread.start()
  for thread in threads:thread.join(5)
  self.assertFalse(any(t.is_alive() for t in threads))
  for _ in range(200):
   if not any(r.controls for r in readers):break
   time.sleep(.005)
  self.assertEqual(len(set(out)),1);self.assertEqual(len(calls),1)
 def test_other_backend_cancel_stops_after_current_identity_wire(self):
  import threading
  entered=threading.Event();release=threading.Event();original=self.f.core.adapters.execute
  def paused(*args,**kwargs):
   result=original(*args,**kwargs)
   if len(self.calls)==1:entered.set();release.wait(3)
   return result
  self.f.core.adapters.execute=paused
  data={**self.f.base,'accountId':'B','customerId':'c','limitPosts':3,'requestId':'cross-cancel'}
  value=self.reader.dispatch('reply_public_profile_start',data,'token')['replyPublicRead'];self.assertTrue(entered.wait(2))
  other=PublicReadWorkflow(self.independent_backend())
  cancelled=other.dispatch('reply_read_cancel',{**self.f.base,'jobId':value['id']},'token')['replyPublicRead'];self.assertEqual(cancelled['state'],'cancelled');release.set()
  for _ in range(200):
   if value['id'] not in self.reader.controls:break
   time.sleep(.005)
  result=self.reader.dispatch('reply_read_status',{**self.f.base,'jobId':value['id']},'token')['replyPublicRead'];self.assertEqual(result['state'],'cancelled');self.assertEqual(len(self.calls),1);self.assertNotIn('profile',result)
 def test_parent_dispatch_selects_reviewed_new_exe_without_changing_old_manifest(self):
  import types,core
  source=RT/'core/adapters.py' if (RT/'core/adapters.py').exists() else T/'candidate/worker/core/adapters.py';spec=importlib.util.spec_from_file_location('core.public_profile_dispatch_test',source);module=importlib.util.module_from_spec(spec);sys.modules[spec.name]=module;spec.loader.exec_module(module)
  adapter=self.f.core.adapters;old=Path(self.f.tmp.name)/'old-ordinary.exe';old.write_bytes(b'old-not-launched');new=Path(self.f.tmp.name)/'inert.exe'
  default={'executable':str(old),'isolation_guard':True,'prefix_args':['xiaohongshu']};adapter.manifest=lambda platform:deepcopy(default)
  adapter._owner_xhs_current=lambda *a:None;adapter._guard_platform=lambda *a:None;adapter.xhs_page_runtime=object()
  adapter.account_spec=lambda platform,home,args,**kw:{'argv':[str(old),'xiaohongshu',*args],'cwd':str(home),'env':{'HOME':str(home),'USERPROFILE':str(home),'LEADSTUDIO_ISOLATED':'1'}}
  original=adapter.execute;selected=[]
  def parent(platform,args,home,job,**kw):
   adapter._cli_page_result=lambda spec,args2,home2,job2,timeout:(selected.append(deepcopy(spec)) or original(platform,args,home,job,**kw))
   return module.Adapters._execute(adapter,platform,args,home,job,_reply_profile_call=kw['_reply_profile_call'])
  adapter.execute=parent;result=self.start();self.assertEqual(result['state'],'completed');self.assertEqual(len(selected),4)
  self.assertTrue(all(Path(spec['argv'][0])==new for spec in selected));self.assertEqual(adapter.manifest('xiaohongshu'),default)
  adapter.xhs_page_runtime=None;adapter.xhs_cli_page_tasks['ordinary-task']={'home':self.f.store.directory/'accounts/t/B'};ordinary=[]
  adapter._cli_page_result=lambda spec,*args:ordinary.append(spec) or {}
  module.Adapters._execute(adapter,'xiaohongshu',['search','rent','--json','--page','1'],self.f.store.directory/'accounts/t/B','ordinary-task')
  self.assertEqual(Path(ordinary[0]['argv'][0]),old);self.assertEqual(adapter.manifest('xiaohongshu'),default)
 def test_factory_receiver_restart_has_profile_binding_without_opening_ai(self):
  import ast
  from workbench_backend import WorkbenchBackend
  from reply_workbench import ReplyWorkbench
  f=self.f;f.generate();f.confirm();draft=f.store.list('replies','t')[0]
  new=WorkbenchBackend.__new__(WorkbenchBackend);new.core=f.core;new.lock=__import__('threading').RLock();new.customer_workbench=fixtures.Customers(f.core)
  # Execute the actual constructor factory-selection block only; full constructor
  # would connect real cloud/runtime and is intentionally excluded from this test.
  source=C/'workbench_backend.py';tree=ast.parse(source.read_text(encoding='utf-8-sig'));cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='WorkbenchBackend');init=next(n for n in cls.body if isinstance(n,ast.FunctionDef) and n.name=='__init__')
  def target(node,name):return isinstance(node,ast.Assign) and any(isinstance(t,ast.Attribute) and isinstance(t.value,ast.Name) and t.value.id=='self' and t.attr==name for t in node.targets)
  begin=next(i for i,n in enumerate(init.body) if target(n,'reply_workbench'));end=next(i for i,n in enumerate(init.body) if target(n,'delivery_integrations'))
  block=ast.Module(body=init.body[begin:end],type_ignores=[]);namespace={'self':new,'reply_factory':ReplyWorkbench};exec(compile(block,str(source),'exec'),namespace)
  self.assertFalse(hasattr(new,'context_reply_workflow'));self.assertIsNotNone(new.reply_workbench.account_profiles)
  view=new.reply_workbench.read(f.user,'s','c',platform='xiaohongshu');self.assertTrue(view['comments'][0]['reviewCurrent']);new.reply_workbench.validate_routing(f.user,'s','c','l',draft)
 def test_actual_source_118_uses_original_employee_heartbeat_read_lease(self):
  import types,core,assistant,time
  vendor=P/'work/shared-backend-integration/vendor-src/assistant/employee_distribution.py';spec=importlib.util.spec_from_file_location('assistant.employee_distribution',vendor);distribution=importlib.util.module_from_spec(spec);sys.modules[spec.name]=distribution;spec.loader.exec_module(distribution);assistant.employee_distribution=distribution
  self.install_real_runtime_gates();self.install_real_app_guard()
  company={'id':distribution.COMPANY_ID,'edition':'customer','personalMode':False,'authMode':'managed','releaseVersion':'1.1.8-pilot.1','platforms':['xiaohongshu','douyin'],'managedWorkspace':{'environment_id':distribution.ENVIRONMENT_ID,'endpoint':distribution.ENDPOINT},'updateFeed':{'enabled':False},'runtime':{'role':'local_assistant_only','ui_entry':'employee_workspace','executable':distribution.EXE_NAME,'xiaohongshu_read_transport':'guarded_cli_v1','cli_source_sha256':distribution.WORKBENCH_SOURCE_SHA256,'release_approved':False,'xiaohongshu_automation':'hold','portable_employee_release':True,'public_send_hold':True,'public_reply_hold':True,'workbench_source_release':'fangyu-admin-local-v1'}}
  self.assertTrue(distribution.runtime_config_valid(company))
  self.runtime.server.company=deepcopy(company);self.f.core.deployment_config=deepcopy(company);self.runtime._customer_read_lease_current=lambda purpose:False
  from core.read_gate_test_engine import Core
  self.f.core._employee_release_allowed=types.MethodType(Core._employee_release_allowed,self.f.core)
  service=self.runtime.service;service.server=self.runtime.server;service._employee_release_heartbeat=lambda *args:None
  # This is the original Service callback that only the authenticated Runner calls.
  service_spec=importlib.util.spec_from_file_location('assistant.read_gate_original_service',P/'work/shared-backend-integration/vendor-src/assistant/service.py');service_mod=importlib.util.module_from_spec(service_spec);sys.modules[service_spec.name]=service_mod;service_spec.loader.exec_module(service_mod)
  self.f.core.employee_release_device_id='';self.f.core.employee_release_until_monotonic=0;self.f.core.stop_owned_reply_queues=lambda *args:None
  service_mod.AssistantService._employee_release_heartbeat(service,self.runtime.service.executor,True,40,time.monotonic())
  before=deepcopy(self.runtime.server.company);self.assertTrue(self.f.core._employee_release_allowed())
  result=self.start(request='native-source-lease');self.assertEqual(result['state'],'completed');self.assertEqual(self.runtime.server.company,before)
  self.f.core.employee_release_device_id='other-device';self.assertEqual(self.start(request='wrong-source-device')['state'],'blocked')
  self.f.core.employee_release_device_id='device';self.f.core.employee_release_until_monotonic=time.monotonic()-1;self.assertEqual(self.start(request='expired-source-lease')['state'],'blocked')
 def test_real_registered_session_sequence_and_bounded_profile_result(self):
  result=self.start();self.assertEqual(result['state'],'completed');self.assertEqual([x[0] for x in self.calls],['whoami','user','user-posts','whoami']);self.assertNotEqual(self.calls[0],self.calls[-1])
  self.assertEqual(result['actorUid'],'uidB');self.assertEqual(len(result['posts']),1);self.assertFalse(result['capability']['publicSendAllowed']);self.assertFalse(result['capability']['sessionSwitchAllowed'])
 def test_actual_uid_mismatch_blocks_before_any_public_text(self):
  self.mismatch=True;result=self.start();self.assertEqual(result['state'],'blocked');self.assertEqual(len(self.calls),1);self.assertNotIn('profile',result)
 def test_remote_hold_blocks_zero_wire(self):
  self.held=True;result=self.start();self.assertEqual(result['state'],'blocked');self.assertEqual(self.calls,[])
 def test_session_check_only_two_actual_identity_calls(self):
  result=self.start('session');self.assertEqual(result['state'],'completed');self.assertEqual([x[0] for x in self.calls],['whoami','whoami']);self.assertNotIn('posts',result)
 def test_replay_same_request_no_new_wire(self):
  self.start();before=deepcopy(self.calls);value=self.reader.dispatch('reply_public_profile_start',self.start_data,'token')['replyPublicRead'];self.assertEqual(value['id'],self.jobid);self.assertEqual(self.calls,before)
 def test_apply_uses_separate_automatic_slot_and_preserves_manual(self):
  result=self.start();s=['t','u','owner','s','xiaohongshu'];profiles=self.f.service;profiles.customer(self.f.user,s,'c')
  before=profiles.evidence(s,'c')
  applied=self.reader.dispatch('reply_public_profile_apply',{**self.f.base,'jobId':self.jobid,'requestId':'adopt1','expectedEvidenceRevision':before['revision']},'token')['replyPublicRead'];self.assertTrue(applied['applied'])
  after=profiles.evidence(s,'c');self.assertEqual(after['items'],before['items']);self.assertEqual(len(after['automaticItems']),2);self.assertTrue(all(x['source']=='guarded_public_read' for x in after['automaticItems']))
  with self.assertRaises(ValueError):self.reader.dispatch('reply_public_profile_apply',{**self.f.base,'jobId':self.jobid,'requestId':'adopt2','expectedEvidenceRevision':before['revision']},'token')
 def test_cancel_discards_late_result(self):
  self.cancel_during=True;result=self.start();self.assertEqual(result['state'],'blocked');self.assertNotIn('profile',result)
 def test_arbitrary_uid_or_url_input_rejected(self):
  for extra in ({'userId':'someone'},{'url':'https://evil.test'}):
   with self.assertRaises(ValueError):self.reader.dispatch('reply_public_profile_start',{**self.f.base,'accountId':'B','customerId':'c','limitPosts':3,'requestId':'bad',**extra},'token')
  self.assertEqual(self.calls,[])
 def test_new_instance_observes_interrupted_job_without_dispatch(self):
  result=self.start();raw=self.f.store.get(JOBS,self.jobid);raw['state']='running';raw.pop('rawResult',None);self.f.store.put(JOBS,raw);before=deepcopy(self.calls)
  fresh=PublicReadWorkflow(self.f.b);view=fresh.dispatch('reply_read_status',{**self.f.base,'jobId':self.jobid},'token')['replyPublicRead'];self.assertEqual(view['state'],'unknown');self.assertEqual(self.calls,before)
if __name__=='__main__':unittest.main(verbosity=2)
