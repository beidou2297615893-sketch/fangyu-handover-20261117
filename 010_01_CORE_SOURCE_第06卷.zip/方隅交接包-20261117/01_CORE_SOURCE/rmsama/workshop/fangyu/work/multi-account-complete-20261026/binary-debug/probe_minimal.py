"""Source-only minimal missing-dependency probe; no component files mutated."""
from pathlib import Path
import sys,socket,subprocess,importlib.abc,importlib.util,json,traceback
sys.dont_write_bytecode=True
T=Path(__file__).resolve().parent.parent

def blocked(*a,**k):raise RuntimeError('No network/process allowed')
socket.socket.connect=socket.socket.connect_ex=socket.create_connection=socket.getaddrinfo=blocked
subprocess.Popen=blocked
sys.path[:0]=[str(T/'component/inputs-source'),str(T/'component/build-work/site')]
loaded=[]
class MissingOnly(importlib.abc.MetaPathFinder):
 def find_spec(self,fullname,path=None,target=None):
  if fullname not in ('core.customer_intent_dirty','core.customer_intent_materials'):return None
  p=T/'assembly/project/work/ui-runtime-r55/src'/Path(*fullname.split('.')).with_suffix('.py')
  loaded.append(fullname)
  return importlib.util.spec_from_file_location(fullname,p)
sys.meta_path.insert(0,MissingOnly())
r={'compiledChildExecuted':False,'platformCalls':0,'modifiedComponent':False}
try:
 from assistant.xhs_cli_page_worker import exact_source_gate
 gate=exact_source_gate(['whoami','--json','--phase','before'])
 import assistant.xhs_reply_worker as sender
 import core.reply_execution_policy
 import assistant.reply_read_session
 import core.engine
 import importlib.util,os
 entry=T/'component/inputs-source/platform_cli.py'
 spec=importlib.util.spec_from_file_location('readonly_dispatch_probe',entry);wrapper=importlib.util.module_from_spec(spec);spec.loader.exec_module(wrapper)
 main=sys.modules['__main__']
 for name in ('install_xhs_write_guards','install_xhs_profile_avatar_compat','install_xhs_sub_comments_compat'):
  setattr(main,name,getattr(wrapper,name))
 os.environ['LEADSTUDIO_ISOLATED']='1';os.environ['WORKSPACE_ACTIVITY_LOG']=str(T/'binary-debug/never-called-activity.jsonl')
 from assistant.xhs_cli_page_worker import _setup
 runner=_setup(lambda *a,**k:blocked());runner.close()
 for args in (['whoami','--json','--phase','after'],['user','c'*24,'--json'],['user-posts','c'*24,'--json','--max-items','3']):exact_source_gate(args)
 from xhs_cli.client import XhsClient
 r['status']='PASS';r['gateType']=type(gate).__name__;r['sourcePageSetup']='PASS_NO_RUNNER_CALL';r['senderAndCoreImports']='PASS';r['allFourReadGates']='PASS'
except Exception:r['status']='FAIL';r['traceback']=traceback.format_exc()
r['missingDependenciesLoadedFromExactBaseline']=loaded
(T/'binary-debug/MINIMAL-DEPENDENCY-PROBE.json').write_text(json.dumps(r,ensure_ascii=False,indent=2),'utf-8');print(json.dumps(r,ensure_ascii=False))

