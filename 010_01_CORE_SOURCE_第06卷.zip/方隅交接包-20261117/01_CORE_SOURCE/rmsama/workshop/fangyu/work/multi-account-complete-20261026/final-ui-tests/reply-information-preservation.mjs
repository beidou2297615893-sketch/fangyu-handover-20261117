import assert from 'node:assert/strict';
import {renderConnected} from 'file:///C:/%E7%A7%AF%E6%9C%A8%E8%BD%AF%E4%BB%B6%E5%B7%A5%E5%9D%8A/%E9%A1%B9%E7%9B%AE/%E6%96%B9%E9%9A%85%E5%85%AC%E5%AF%93%E5%AE%A2%E6%88%B7%E7%89%88/work/multi-account-complete-20261026/assembly/project/work/ui-approved-implementation/ui-preview/pages/reply-connected.mjs';
import {renderAI} from 'file:///C:/%E7%A7%AF%E6%9C%A8%E8%BD%AF%E4%BB%B6%E5%B7%A5%E5%9D%8A/%E9%A1%B9%E7%9B%AE/%E6%96%B9%E9%9A%85%E5%85%AC%E5%AF%93%E5%AE%A2%E6%88%B7%E7%89%88/work/multi-account-complete-20261026/assembly/project/work/ui-approved-implementation/ui-preview/pages/reply-ai.mjs';
import {makeReplyCustomersState} from './reply-customers-fixture.mjs';
const s=makeReplyCustomersState({page:'reply',scenario:'ai-done',count:2}),v=s.replyLive;
v.uiView='manual';v.items[0].contactLabel='历史发送未确认';v.detail.comments[0].sourceNotice='帖子日期未提供，范围待核实';v.detail.comments[0].publishedAt='2026-09-18T03:14:00+08:00';
let html=renderConnected(s);assert.ok(html.includes('历史发送未确认'));assert.ok(html.includes('帖子日期未提供，范围待核实'));assert.ok(html.includes('2026-09-18'));
const r=v.ai.job.rows[0];r.confirmation={state:'closed',pending:false,message:'原草稿或确认账号已变化，请核对'};html=renderAI(s,v);assert.ok(html.includes('确认已关闭'));assert.ok(html.includes('原草稿或确认账号已变化，请核对'));
r.confirmation={state:'not_started',pending:false,message:'上下文已变化'};assert.ok(renderAI(s,v).includes('上下文已变化'));
console.log('PASS: original contactLabel, full source date/notice, all confirmation messages and closed state remain reachable; render only');
