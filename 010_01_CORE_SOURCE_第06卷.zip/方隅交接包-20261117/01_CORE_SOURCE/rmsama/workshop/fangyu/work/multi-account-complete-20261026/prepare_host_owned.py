from pathlib import Path
import ast
T=Path(__file__).resolve().parent
B=T/'assembly/project/work/ui-native-r57'
C=T/'candidate'
h=(B/'ui_native_host.py').read_text('utf-8')
h=h.replace("'reply_read', 'reply_save'", "'reply_session_check','reply_public_profile_start','reply_read_status','reply_read_cancel','reply_public_profile_apply','reply_read', 'reply_save'",1)
h=h.replace("'reply_account_profiles.py','reply_ai_workflow.py'", "'reply_account_profiles.py','reply_public_profile.py','reviewed_reply_bridge.py','reply_public_read_materials.json','reviewed_reply_materials.json','reply_ai_workflow.py'")
h=h.replace("'reply_account_profiles','reply_ai_workflow'", "'reply_account_profiles','reply_public_profile','reviewed_reply_bridge','reply_ai_workflow'")
needle="    try:\n        live_entry=files.get('resources/livestream/livestream_workbench.py')"
replacement="""    try:
        # Only RELEASE-pinned bytes can create this private registration.
        material_entry=files.get('reviewed_reply_materials.json')
        if material_entry is None:
            raise UIHostError('审核回复组件来源材料不完整。')
        material_raw=read_public(root/material_entry['path'],material_entry['sha256'],material_entry['size'])
        reviewed_manifest=json.loads(material_raw)
        from core.reply_execution_policy import register,digest
        register(backend.core,project,reviewed_manifest,
            sys.modules['reviewed_reply_bridge'].transport,
            expected_manifest_digest=digest(reviewed_manifest))
        live_entry=files.get('resources/livestream/livestream_workbench.py')"""
assert needle in h
h=h.replace(needle,replacement,1)
ast.parse(h);(C/'ui_native_host.py').write_text(h,'utf-8')
f=(B/'freeze_ui.py').read_text('utf-8')
needle="    copy_public(HERE / 'workbench_backend.py', release / 'workbench_backend.py')"
assert needle in f
f=f.replace(needle,needle+"\n    for name in ('reply_public_profile.py','reviewed_reply_bridge.py','reply_public_read_materials.json','reviewed_reply_materials.json'):\n        body=copy_public(HERE/name,release/name)\n        source_pins[str(HERE/name)]=sha(body)",1)
ast.parse(f);(C/'freeze_ui.py').write_text(f,'utf-8')
print('candidate host/freeze prepared')
