from pathlib import Path
import subprocess,json,hashlib,re,sys,argparse
from datetime import datetime,timezone
D=Path(__file__).resolve().parent
NODE='C:/Program Files/nodejs/node.exe'
CLI='C:/Users/rmsama/AppData/Roaming/npm/node_modules/@cloudbase/cli/bin/tcb'
ENV='fh6-d5ga45c0ddae7008c';FN='fangyu-workspace'
def api(op,body):
 r=subprocess.run([NODE,CLI,'api','scf',op,'-e',ENV,'--body',json.dumps(body,separators=(',',':')),'--json'],capture_output=True,timeout=60,cwd=D)
 if r.returncode:raise RuntimeError('official_api_failed_'+op)
 raw=re.sub(r'\x1b\[[0-9;]*[a-zA-Z]','',r.stdout.decode('utf-8',errors='replace'))
 v=json.loads(raw[raw.index('{'):raw.rindex('}')+1])
 def find(o):
  if isinstance(o,dict):
   if 'FunctionName' in o:return o
   for x in o.values():
    y=find(x)
    if y is not None:return y
  if isinstance(o,list):
   for x in o:
    y=find(x)
    if y is not None:return y
 obj=find(v);assert obj and obj.get('FunctionName')==FN
 return obj
def protected(obj):
 keys=['Handler','Runtime','MemorySize','Timeout','Environment','VpcConfig','Role','Layers','DeadLetterConfig','PublicNetConfig','CfsConfig','DnsCache','AutoDeployClsTopicIndex','Type','Namespace','Triggers']
 return {k:hashlib.sha256(json.dumps(obj.get(k),sort_keys=True,separators=(',',':')).encode()).hexdigest() for k in keys}
SOURCE_SHA='9f688a51ac7b3a7a9501b8e4e8799295a8ab09ddcb445d856c9f6887c8487f23'

def pins():
 names=('deploy.py','verify_readback.py','read_live_code_once.py','COMPOSITION.json')
 return {name:hashlib.sha256((D/name).read_bytes()).hexdigest() for name in names}

def readback(name):
 out=D/name
 assert not out.exists(),'Never reuse readback evidence'
 r=subprocess.run([sys.executable,'-B',str(D/'read_live_code_once.py'),'--check-current-auth','--out',str(out)],capture_output=True,timeout=150,cwd=D)
 assert r.returncode==0,'Code readback failed; stop without retry'
 return out

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--prepare-only',action='store_true');ap.add_argument('--approved-pins',type=Path)
 args=ap.parse_args()
 composition=json.loads((D/'COMPOSITION.json').read_text('utf-8'))
 from verify_readback import local_material,verify
 local_material(composition)
 request={'status':'PENDING_ASTRA_EXACT_REVIEW','pins':pins(),'beforeTree':composition['beforeTree'],'afterTree':composition['afterTree'],'materialReady':composition['materialReady'],'sourceDeploymentSha256':SOURCE_SHA,'externalCalls':0,'deploymentExecuted':False}
 if args.prepare_only:
  (D/'DEPLOY-PREPARED.json').write_text(json.dumps(request,indent=2),'utf-8');print(json.dumps(request));return
 assert args.approved_pins is not None,'Exact Astra pins required'
 approval=json.loads(args.approved_pins.read_text('utf-8'))
 assert approval.get('status')=='ASTRA_APPROVED_EXACT_CODE_ONLY_DEPLOY' and approval.get('pins')==pins(),'Exact reviewed script/composition pins mismatch'
 assert approval.get('beforeTree')==composition['beforeTree'] and approval.get('afterTree')==composition['afterTree']
 assert composition['materialReady'] and re.fullmatch('[0-9a-f]{64}',composition['materialSha256']),'Final reviewed sender material required'
 assert not (D/'DEPLOYMENT.json').exists(),'No automatic redeployment'
 config=api('GetFunction',{'FunctionName':FN,'Namespace':ENV,'ShowCode':'FALSE'})
 assert config.get('Type') in ('Event','HTTP')
 if config.get('Type')=='HTTP':assert (D/'candidate/scf_bootstrap').is_file()
 before=protected(config)
 (D/'CONFIG-PROTECTED-BEFORE.json').write_text(json.dumps(before,indent=2),'utf-8')
 pre=readback('readback-precommit')
 live=json.loads((pre/'LIVE-READBACK.json').read_text('utf-8'))
 assert live['treeSha256']==composition['beforeTree'] and live['files']==composition['beforeFiles'],'Fresh source CAS mismatch; preserve remote successor'
 # Recheck exact local scripts/material immediately before the sole code update.
 assert pins()==approval['pins'];local_material(composition)
 report={'utc':datetime.now(timezone.utc).isoformat(),'operation':'official fn code update','environment':ENV,'function':FN,'expectedTree':composition['afterTree'],'configurationWritten':False,'businessDatabaseReadOrWritten':False,'modelCalls':0,'realSends':0,'status':'SUBMITTING'}
 def save():(D/'DEPLOYMENT.json').write_text(json.dumps(report,indent=2),'utf-8')
 save()
 try:
  run=subprocess.run([NODE,CLI,'fn','code','update',FN,'--dir',str(D/'candidate'),'--deployMode','cos','-e',ENV,'--json'],capture_output=True,timeout=180,cwd=D)
  report['cliExitCode']=run.returncode
  report['status']='SUBMITTED_NEEDS_READBACK' if run.returncode==0 else 'FAILED_OR_UNKNOWN_READBACK_REQUIRED'
 except subprocess.TimeoutExpired:report['status']='TIMEOUT_READBACK_REQUIRED'
 except Exception as error:report.update(status='FAILED_OR_UNKNOWN_READBACK_REQUIRED',errorClass=type(error).__name__)
 save()
 try:
  after=protected(api('GetFunction',{'FunctionName':FN,'Namespace':ENV,'ShowCode':'FALSE'}))
  (D/'CONFIG-PROTECTED-AFTER.json').write_text(json.dumps(after,indent=2),'utf-8')
  report['protectedConfigurationUnchanged']=before==after
  report['changedProtectedFields']=[k for k in before if before[k]!=after[k]]
  save()
  post=readback('readback-postcommit');checked=verify(post,composition)
  report['readback']=checked
  report['status']='VERIFIED_CODE_ONLY_DEPLOYMENT' if before==after and checked['status']=='PASS' else 'VERIFICATION_FAILED_STOP'
 except Exception as error:report.update(status='VERIFICATION_FAILED_OR_UNKNOWN_STOP',verificationErrorClass=type(error).__name__)
 save();print(json.dumps(report))
 if report['status']!='VERIFIED_CODE_ONLY_DEPLOYMENT':raise SystemExit(3)
if __name__=='__main__':main()
