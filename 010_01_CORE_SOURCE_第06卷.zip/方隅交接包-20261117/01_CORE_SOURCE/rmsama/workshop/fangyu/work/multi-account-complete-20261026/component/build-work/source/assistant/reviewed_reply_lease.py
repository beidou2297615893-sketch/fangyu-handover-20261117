"""Independent short-lived reviewed-send lease from the original authenticated poll."""
from dataclasses import dataclass
import hashlib,json,math,time,re
from .xhs_app_context import _DeviceSession,_session_snapshot,_SEAL as _APP_SEAL

_SEAL=object();PROTOCOL='fangyu-reviewed-reply-v1';PURPOSE='reviewed_reply'
_FIELDS=frozenset(('schema','allowed','company_id','device_id','owner','version','purpose','permission_revision','lease_seconds','public_send_allowed','material_sha256'))
def _digest(v):return hashlib.sha256(json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
def _revision(v):return isinstance(v,str) and re.fullmatch(r'[a-f0-9]{64}',v) is not None

@dataclass(eq=False)
class SendRequest:
 seal:object
 service:object
 executor:object
 session:object
 company_digest:str
 device_id:str
 version:str
 registration:object
 material_sha256:str
 def valid(self,runner):
  from .service import AssistantService
  from .business import BusinessExecutor
  from .runner import AssistantRunner
  try:
   s=self.service;e=self.executor;server=s.server;core=server.core;device=s.device or {}
   if (self.seal is not _SEAL or type(s) is not AssistantService or type(e) is not BusinessExecutor or type(runner) is not AssistantRunner or type(self.session) is not _DeviceSession or self.session.seal is not _APP_SEAL
       or s.closed or s.stop_event.is_set() or s.executor is not e or runner.execute is not e or runner.revoked
       or getattr(runner,'reviewed_reply_request',None) is not self or getattr(s,'_reviewed_reply_runner',None) is not runner
       or getattr(s,'_reviewed_reply_request',None) is not self or e.core is not core or e.server is not server
       or getattr(e,'_xhs_app_session',None) is not self.session or self.session.service is not s or self.session.core is not core
       or self.session.principal!=(e.owner,e.tenant,e.user_id) or _session_snapshot(s,s.vault.read())!=self.session.binding
       or device.get('id')!=self.device_id or device.get('owner')!=e.owner or device.get('revoked') is True
       or _digest(server.company)!=self.company_digest or server.company!=core.deployment_config
       or server.company.get('id')!='fangyu-apartment-client' or runner.version!=self.version or server.company.get('releaseVersion')!=self.version):return False
   from core.reply_execution_policy import _Registration,_SEAL as registration_seal
   registration=getattr(core,'_reviewed_reply_registration',None)
   if type(registration) is not _Registration or registration.seal is not registration_seal or registration is not self.registration or registration.manifest_digest!=self.material_sha256:return False
   registration.check()
   user=core.store.get('users',e.user_id)
   return bool(user and user.get('cloud_bound') is True and not user.get('disabled') and user.get('development_local_only') is not True and user.get('role') in ('operator','admin') and (user.get('id'),user.get('tenant_id'),user.get('username'))==(e.user_id,e.tenant,e.owner))
  except (OSError,ValueError,TypeError,KeyError,AttributeError):return False

def request_for(service,executor,saved):
 try:
  session=getattr(executor,'_xhs_app_session',None);server=service.server
  if (type(session) is not _DeviceSession or session.seal is not _APP_SEAL or session.service is not service or session.executor is not executor or session.core is not server.core or _session_snapshot(service,saved)!=session.binding or service.vault.read()!=saved or not isinstance(saved.get('device'),dict) or not saved['device'].get('id') or server.company.get('id')!='fangyu-apartment-client' or (server.company.get('runtime') or {}).get('platform_qa_device_id')):return None
  version=server.company.get('releaseVersion')
  if not isinstance(version,str) or not version:return None
  from core.reply_execution_policy import _Registration,_SEAL as registration_seal
  registration=getattr(server.core,'_reviewed_reply_registration',None)
  if type(registration) is not _Registration or registration.seal is not registration_seal:return None
  registration.check()
  return SendRequest(_SEAL,service,executor,session,_digest(server.company),saved['device']['id'],version,registration,registration.manifest_digest)
 except (OSError,ValueError,TypeError,KeyError,AttributeError):return None

def refresh_request(runner):
 """Original poll can discover a later host-reviewed registration; never rebinds a device."""
 from .runner import AssistantRunner
 from .business import BusinessExecutor
 try:
  if type(runner) is not AssistantRunner or type(runner.execute) is not BusinessExecutor:return None
  executor=runner.execute;session=getattr(executor,'_xhs_app_session',None)
  if type(session) is not _DeviceSession:return None
  service=session.service;current=getattr(runner,'reviewed_reply_request',None)
  if type(current) is SendRequest and current.valid(runner):return current
  value=request_for(service,executor,service.vault.read())
  with service.lock:
   if service.executor is not executor or service.closed:return None
   runner.reviewed_reply_request=value;service._reviewed_reply_request=value;service._reviewed_reply_runner=runner if value is not None else None
  return value
 except (OSError,ValueError,TypeError,KeyError,AttributeError):return None

def poll_fields(request,runner):
 return {'reviewed_reply_protocol':PROTOCOL,'material_sha256':request.material_sha256} if type(request) is SendRequest and request.valid(runner) else {}

@dataclass(eq=False)
class SendLease:
 seal:object
 request:object
 runner:object
 permission_revision:object
 deadline:float
 issued_at:float

def from_heartbeat(request,runner,response,poll_started):
 try:
  if type(request) is not SendRequest or not request.valid(runner) or type(response) is not dict or response.get('safety_hold') is not False or type(poll_started) not in (int,float) or not math.isfinite(poll_started) or poll_started>time.monotonic():return None
  grant=response.get('reviewed_reply_release');user=request.service.server.core.store.get('users',request.executor.user_id)
  if (type(grant) is not dict or set(grant)!=_FIELDS or grant.get('schema')!='fangyu_reviewed_reply_lease_v1' or grant.get('allowed') is not True or grant.get('public_send_allowed') is not True or grant.get('material_sha256')!=request.material_sha256 or grant.get('purpose')!=PURPOSE or grant.get('company_id')!=request.service.company_id or grant.get('device_id')!=request.device_id or grant.get('owner')!=request.executor.owner or grant.get('version')!=request.version or not _revision(grant.get('permission_revision')) or grant['permission_revision']!=user.get('permission_revision') or user.get('can_reply') is not True or type(grant.get('lease_seconds')) is not int or not 1<=grant['lease_seconds']<=45 or poll_started+grant['lease_seconds']<=time.monotonic()):return None
  return SendLease(_SEAL,request,runner,grant['permission_revision'],poll_started+grant['lease_seconds'],poll_started)
 except (OSError,ValueError,TypeError,KeyError,AttributeError):return None

def require_current(server,actor,account,device_id):
 service=getattr(server,'assistant_service',None);lease=getattr(service,'_reviewed_reply_lease',None)
 if type(lease) is not SendLease or lease.seal is not _SEAL or type(lease.request) is not SendRequest or lease.request.service is not service or not lease.request.valid(lease.runner) or time.monotonic()>=lease.deadline:raise ValueError('远端已审核回复发送许可尚未确认或已过期，请等待原设备连接恢复')
 request=lease.request;core=server.core;user=core.store.get('users',request.executor.user_id);runtime=core.deployment_config.get('runtime') or {}
 if (core.remote_safety_hold or runtime.get('platform_qa_device_id') or service.state!='online' or device_id!=request.device_id or (actor.get('id'),actor.get('tenant_id'),actor.get('username'))!=(user.get('id'),user.get('tenant_id'),user.get('username')) or user.get('can_reply') is not True or user.get('permission_revision')!=lease.permission_revision or account.get('tenant_id')!=user['tenant_id'] or account.get('cloud_owner')!=user['username'] or account.get('platform')!='xiaohongshu'):raise ValueError('远端员工、设备或回复权限已变化，已停止发送')
 request.session.check();return lease
