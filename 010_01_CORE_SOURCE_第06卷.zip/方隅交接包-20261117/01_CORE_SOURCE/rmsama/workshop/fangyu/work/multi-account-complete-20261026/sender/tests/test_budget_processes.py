"""ROOT-ONLY local process fixture: never invokes platform or CLI. Review then run."""
import importlib.util,sys,tempfile,subprocess,json,os,time
from pathlib import Path
T=Path(__file__).resolve().parents[2]
def module():
 s=importlib.util.spec_from_file_location('budget_policy',T/'candidate/runtime/core/reply_execution_policy.py');m=importlib.util.module_from_spec(s);sys.modules[s.name]=m;s.loader.exec_module(m);return m
if len(sys.argv)>1 and sys.argv[1]=='--child':
 m=module();db,barrier,number=sys.argv[2:]
 while not Path(barrier).exists():time.sleep(.01)
 try:m.consume_budget(db,'tenant','customer','reply'+number,'attempt'+number,'a'*64)
 except m.ReplyPolicyError:print('BLOCKED',flush=True)
 else:print('CONSUMED',flush=True)
 # Exit without a terminal receipt. Restart must still refuse the customer.
 os._exit(0)
if __name__=='__main__':
 with tempfile.TemporaryDirectory(dir=T/'sender') as temp:
  root=Path(temp);db=root/'budget.sqlite3';barrier=root/'start.flag'
  children=[subprocess.Popen([sys.executable,'-X','utf8','-B',str(Path(__file__).resolve()),'--child',str(db),str(barrier),str(n)],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,encoding='utf8') for n in range(2)]
  barrier.write_text('start',encoding='ascii');outputs=[]
  for p in children:
   out,err=p.communicate(timeout=30);assert p.returncode==0,(out,err);outputs.append(out.strip())
  assert sorted(outputs)==['BLOCKED','CONSUMED'],outputs
  m=module()
  try:m.consume_budget(db,'tenant','customer','different-reply','restart-attempt','b'*64)
  except m.ReplyPolicyError:pass
  else:raise AssertionError('Restart retried unknown send')
  print(json.dumps({'status':'PASS','OSProcesses':2,'persistentPOSTAllowances':1,'restartAllowances':0,'realPlatformWires':0}))
