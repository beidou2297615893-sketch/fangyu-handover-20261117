"""Pure source fake-queue probe. No executable or external endpoint is used."""
import ast,importlib.util,json,sys
from pathlib import Path
sys.dont_write_bytecode=True
D=Path(__file__).resolve().parent;T=D.parent

def load(name,path):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);sys.modules[name]=m;s.loader.exec_module(m);return m
fixture=load('adapterbusy_source_fixture',T/'sender/tests/test_reviewed_delivery.py')
old=fixture.em.AdapterBusy
adapters=load('core.adapters',T/'candidate/worker/core/adapters.py')
bridge=load('adapterbusy_source_bridge',T/'candidate/send/reviewed_reply_bridge.py')
oldfile=T.parent/'multi-account-reply-20261026/assembly/project/work/ui-runtime-r55/src/core/adapters.py'
newfile=T/'candidate/worker/core/adapters.py'
def class_ast(path):return ast.dump(next(n for n in ast.parse(path.read_text('utf-8')).body if isinstance(n,ast.ClassDef) and n.name=='AdapterBusy'),include_attributes=False)
assert class_ast(oldfile)==class_ast(newfile)
assert old is not adapters.AdapterBusy and bridge.AdapterBusy is adapters.AdapterBusy
result={'sourceOnly':True,'compiledChildExecuted':False,'classAstEqual':True,'identityBeforeFix':old is bridge.AdapterBusy,'cases':[]}
fixture.em.AdapterBusy=adapters.AdapterBusy
assert fixture.em.AdapterBusy is bridge.AdapterBusy is adapters.AdapterBusy
result['identityAfterFix']=True
assert not isinstance(RuntimeError('ordinary'),adapters.AdapterBusy)
for kind,error,expected in [('busy',adapters.AdapterBusy('synthetic blocked before POST'),'approved'),('ordinary',RuntimeError('synthetic ordinary failure'),'unknown')]:
 d=fixture.DeliveryTests('test_original_confirmed_B_queue_sends_exactly_one_with_three_holds');d.setUp()
 try:
  def transport(decision,request,authorize):
   if kind=='ordinary':
    from assistant.xhs_reply_worker import post_body
    authorize('post',{'method':'POST','path':'/api/sns/web/v1/comment/post','query':'','body':post_body(request)})
   raise error
  d.core._reviewed_reply_registration.transport=transport
  view=d.start(d.prepare('probe-'+kind))
  assert view['items'][0]['status']==expected,view
  assert d.wires==[],d.wires
  result['cases'].append({'kind':kind,'status':expected,'wireCalls':0,'postCalls':0})
 finally:d.doCleanups()
result['status']='PASS';(D/'ADAPTERBUSY-SOURCE-PROBE.json').write_text(json.dumps(result,indent=2),'utf-8');print(json.dumps(result))
