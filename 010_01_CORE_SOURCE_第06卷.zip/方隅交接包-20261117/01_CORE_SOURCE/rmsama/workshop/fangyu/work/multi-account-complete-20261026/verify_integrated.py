"""Run owner contracts and preserved regressions against the exact inactive release."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import subprocess
import sys
from concurrent.futures import ThreadPoolExecutor, as_completed

sys.dont_write_bytecode = True
TASK = Path(__file__).resolve().parent
ROOT = TASK.parents[1]
read = lambda p: json.loads(p.read_text('utf-8-sig'))
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()

def main():
    pins = read(TASK / 'FROZEN-PINS.json')
    project, release = Path(pins['project']), Path(pins['release'])
    output = TASK / 'verification' / ('integrated-' + datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ'))
    output.mkdir(parents=True, exist_ok=False)
    closure = read(TASK / 'assembly/UNIFIED-PINS.json')
    assert sha(TASK / 'assembly/UNIFIED-PINS.json') == pins['unifiedPinsSha256']
    expected = {row['path']: row['sha256'] for row in closure['files']}
    def verify_closure():
        actual = {p.relative_to(project).as_posix() for p in project.rglob('*') if p.is_file()}
        assert actual == set(expected), 'Closure file-set changed.'
        for name, digest in expected.items():
            assert sha(project / name) == digest, name
    verify_closure()
    py = str(ROOT / 'work/desktop-python/Scripts/python.exe')
    values = dict(project=str(project), release=str(release), task=str(TASK), python=py)
    jobs = []
    for owner in ('backend', 'frontend'):
        spec = TASK.parent / 'reply-complete-20261026' / owner / 'TEST-COMMANDS.json'
        for job in read(spec)['jobs']:
            jobs.append((owner + '-' + job['name'], [arg.format(**values) for arg in job['argv']]))
    for owner in ('backend','frontend'):
        spec=TASK.parent/'multi-account-reply-20261026'/owner/'NEW-TEST-COMMANDS.json'
        for job in read(spec)['jobs']:
            jobs.append((owner+'-new-'+job['name'],[arg.format(**values) for arg in job['argv']]))
    for owner, spec_name in (('backend', 'TEST-COMMANDS.json'), ('frontend', 'NEW-TEST-COMMANDS.json')):
        for job in read(TASK/owner/spec_name)['jobs']:
            jobs.append((owner+'-complete-'+job['name'], [arg.format(**values) for arg in job['argv']]))
    sender_env = dict(SENDER_PROJECT=str(project), SENDER_NATIVE=str(release),
        SENDER_RUNTIME=str(project/'work/ui-runtime-r55/src'), SENDER_SEND=str(release), SENDER_CANDIDATE=str(release))
    for job in read(TASK/'sender/TEST-COMMANDS.json')['pure']:
        argv = [arg.format(**values) for arg in job['argv']]
        jobs.append(('sender-'+Path(argv[-1]).stem, argv))
    jobs.append(('sender-budget-two-os-processes', [py, '-X', 'utf8', '-B', str(TASK/'sender/tests/test_budget_processes.py')]))
    jobs.append(('compiled-fixture-loopback-tls', [py, '-X', 'utf8', '-B', str(TASK/'tests/test_tls_fixture.py')]))
    jobs.append(('cloud-independent-grant-contract', ['node', str(TASK/'cloud/tests/verify_candidate.cjs')]))
    jobs.append(('per-account-original-login-entry', ['node', str(TASK/'tests/test_session_login_dom.mjs'), '--release', str(release)]))
    jobs.append(('native-complete-real-startup', [py, '-X', 'utf8', '-B', str(TASK/'tests/test_native_complete_startup.py'), '--pins', str(TASK/'FROZEN-PINS.json')]))
    jobs.append(('profile-subject-binding-compatibility', [py, '-X', 'utf8', '-B', str(TASK/'tests/backend/test_profile_subject_compat.py'), '--worker-path', str(project/'work/ui-runtime-r55/src/assistant/xhs_cli_page_worker.py'), '--runtime', str(project/'work/ui-runtime-r55/src'), '--parent-path', str(project/'work/ui-runtime-r55/src/assistant/reply_read_session.py')]))
    jobs.append(('profile-subject-binding-evidence', [py, '-X', 'utf8', '-B', str(TASK/'tests/backend/test_profile_subject_evidence.py'), '--project', str(project), '--release', str(release), '--candidate', str(release), '--runtime', str(project/'work/ui-runtime-r55/src'), '--shared', str(project/'work/shared-backend-integration')]))
    jobs.append(('actual-compiled-four-case-evidence', [py, '-X', 'utf8', '-B', str(TASK/'verify_compiled_evidence.py')]))
    jobs.extend([
        ('delivery-routing-boundary', [py,'-X','utf8','-B',str(TASK/'tests/test_delivery_routing.py'),str(release/'reply_delivery.py')]),
        ('official-reply-provider-20', [py,'-X','utf8','-B',str(TASK/'tests/test_reply_official_codex.py')]),
        ('complete-context', [py,'-X','utf8','-B',str(TASK/'tests/test_complete_context.py')]),
        ('complete-write-guard', [py,'-X','utf8','-B',str(TASK/'tests/test_complete_write_guard.py')]),
        ('complete-concurrency', [py,'-X','utf8','-B',str(TASK/'tests/test_complete_concurrency.py')]),
    ])
    old = ROOT / 'work/home-login-cleanup-20261026'
    legacy = ROOT / 'work/ui-fidelity-correction-20261025'
    tests = TASK / 'tests'
    jobs.extend([
        ('legacy-verification-outcomes', [py, '-X', 'utf8', '-B', str(tests / 'test_verification_outcomes.py')]),
        ('management-navigation', ['node', str(old / 'audit/test_management_navigation.cjs')]),
        ('canvas-style-preservation', ['node', str(old / 'audit/test_canvas_cleanup.cjs')]),
        ('served-source-closure', [py, '-X', 'utf8', '-B', str(TASK / 'test_served_closure.py')]),
        ('existing-backend', [py, '-X', 'utf8', '-B', str(ROOT / 'work/local-browse-decoupling-20261025/backend/test_local_browse.py'), '--project', str(project), '--native', str(release), '--output', str(output / 'backend-tests.txt')]),
        ('preserved-learning', [py, '-X', 'utf8', '-B', '-m', 'unittest', 'discover', '-s', str(ROOT / 'work/confirmed-tone-learning-20261025'), '-p', 'test_*.py']),
        ('workflow', [py, '-X', 'utf8', '-B', str(tests / 'test_workflow.py')]),
        ('context-relations', [py, '-X', 'utf8', '-B', str(tests / 'test_context_relations.py')]),
        ('confirmation-recovery', [py, '-X', 'utf8', '-B', str(tests / 'test_confirmation_recovery.py')]),
        ('ui-confirmation', ['node', str(tests / 'test_ui.mjs')]),
        ('network-recovery', ['node', str(tests / 'test_network_recovery.mjs')]),
        ('ui-display-contracts', [py, '-X', 'utf8', '-B', str(TASK / 'run_final_ui_contracts.py')]),
        ('native-check', [py, '-X', 'utf8', '-I', '-B', pins['launcherPath'], '--check']),
        ('native-self-test', [py, '-X', 'utf8', '-I', '-B', pins['launcherPath'], '--self-test']),
        ('closed-update-guards', [py, '-X', 'utf8', '-B', str(legacy / 'test_closed_update_guard.py')]),
        ('update-deferral', [py, '-X', 'utf8', '-B', str(legacy / 'test_update_deferral.py')]),
        ('next-launch-safety', [py, '-X', 'utf8', '-B', str(tests / 'test_next_launch_update.py')]),
    ])
    env = {**os.environ, 'PYTHONDONTWRITEBYTECODE': '1', 'PYTHONUTF8': '1',
        'SCOPE_TEST_PROJECT': str(project), 'SCOPE_TEST_NATIVE': str(release),
        'SCOPE_TEST_OVERLAY': str(release), 'TONE_TEST_PROJECT': str(project),
        'TONE_TEST_NATIVE': str(release), 'BROWSER_FIRST_PROJECT': str(project),
        'BROWSER_FIRST_RELEASE': str(release), **sender_env}
    checks = []
    source_pins = {str(Path(arg)): sha(Path(arg)) for _, argv in jobs for arg in argv
        if Path(arg).suffix in ('.py', '.mjs', '.cjs') and Path(arg).is_file()}
    (output/'TEST-SOURCE-PINS.json').write_text(json.dumps(source_pins,ensure_ascii=False,indent=2)+'\n','utf-8')
    def run_job(job):
        name, argv = job
        try:
            run = subprocess.run(argv, capture_output=True, text=True, encoding='utf-8',
                                 errors='replace', timeout=300, env=env)
            code, message = run.returncode, run.stdout+'\n'+run.stderr
        except subprocess.TimeoutExpired:
            code, message = 124, 'Verification child exceeded the fixed 300 second deadline.'
        log = output / (name + '.log')
        log.write_text(message, 'utf-8')
        return dict(name=name, exitCode=code, log=str(log), sha256=sha(log)), message
    def record(result):
        item, message = result
        checks.append(item)
        name = item['name']
        print(json.dumps(dict(name=name, exitCode=item['exitCode'],
            tail=message[-450:]), ensure_ascii=False), flush=True)
    # Owner tests generate their shared contract fixture, so keep that dependency ordered.
    owners = [job for job in jobs if job[0].startswith(('backend-', 'frontend-'))]
    for job in owners:
        record(run_job(job))
    safety_names = {'closed-update-guards', 'update-deferral', 'next-launch-safety'}
    independent = [job for job in jobs if job not in owners and job[0] not in safety_names]
    with ThreadPoolExecutor(max_workers=4) as executor:
        for future in as_completed([executor.submit(run_job, job) for job in independent]):
            record(future.result())
    # Process-global updater/mutex tests remain serialized.
    for job in jobs:
        if job[0] in safety_names:
            record(run_job(job))
    order = {job[0]: i for i, job in enumerate(jobs)}
    checks.sort(key=lambda item: order[item['name']])
    verify_closure()
    for name, digest in source_pins.items():
        assert sha(Path(name)) == digest, 'Test source changed during verification: '+name
    for name, digest in read(TASK / 'REGRESSION-SOURCE-PINS.json').items():
        assert sha(Path(name)) == digest, name
    for name, digest in read(TASK / 'BASELINE.json')['canonical'].items():
        assert sha(ROOT / 'work/ui-native-r57' / name) == digest, name
    result = dict(status='PASS' if all(c['exitCode'] == 0 for c in checks) else 'FAIL',
        releaseId=pins['releaseId'], checks=checks, closureVerified=True,
        closureFiles=len(expected), canonicalUnchanged=True, productionDataAccess=False,
        realPlatformCollection=False, automaticSendingEnabled=False)
    (output / 'RESULT.json').write_text(json.dumps(result, ensure_ascii=False, indent=2)+'\n', 'utf-8')
    result['realModelAcceptanceIncluded']=False
    if result['status'] == 'PASS':
        final = TASK / 'verification/integrated'
        final.mkdir(exist_ok=False)
        with (final / 'RESULT.json').open('x', encoding='utf-8') as stream:
            json.dump({**result, 'originalRun': str(output)}, stream, ensure_ascii=False, indent=2)
            stream.write('\n')
    print(json.dumps(dict(status=result['status'], checks=len(checks), report=str(output / 'RESULT.json'))))
    return 0 if result['status'] == 'PASS' else 1

if __name__ == '__main__':
    raise SystemExit(main())
