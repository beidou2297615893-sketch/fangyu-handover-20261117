'use strict';
const fs=require('node:fs');
const path=require('node:path');
const Module=require('node:module');
const tests=__dirname;
const source=path.resolve(tests,'../../../cloud-prompt-deployment-20261025/test_service.cjs');
const target=path.resolve(tests,'../candidate');
const code=fs.readFileSync(source,'utf8').replace("D=__dirname,ROOT=path.join(D,'approved-code')","D="+JSON.stringify(tests)+",ROOT="+JSON.stringify(target)).replace('if(require.main===module)main().catch','main().catch');
const m=new Module(source,module);m.filename=source;m.paths=Module._nodeModulePaths(path.dirname(source));m._compile(code,source);
