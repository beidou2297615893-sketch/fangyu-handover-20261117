# 新版合成验收脚本静态审查

2026-10-27，Astra。

harness-v3.py SHA256：bccc99621b84600f7a07ed8f00091aa29c7b01e5931bcad681ee903cad2b9c60。

已对照冻结 e699 harness 完整 diff：只在新文件扩充原 read fixture 的 otherinfo 响应，删除 user_id/userid、保留公开简介；成功结果须明示 request_bound_subject、不含虚构 response UID 或 user_id/userid，采用后的唯一简介自动证据仍保留该身份来源。

read 测试总等待由 100 秒改为 180 秒，覆盖原业务 claim 150 秒上限，不改变业务时限。send 从原 fake fixture 的短等待转为原 delivery.status 轮询至终态，上限 100 秒；发送次数、错误身份零 POST、响应冲突 unknown、禁止自动重放等原断言保留。成功结果增加真实 child/GET/POST 统计，并固定自身源码路径。

安全脚本、响应器、child 白名单、空 HOME、代理与原固定源约束未改；四案例边界不扩大。此文件静态通过，尚未授权启动新 EXE。必须待 v3 产物精确冻结核对后单独签单次运行批准。旧 compiled-01/02/03/04 均保持未通过事实，不改写或删除。
