"""Adapt the existing reviewed offline PyInstaller builder; do not compile or run CLI."""
from pathlib import Path
import ast,hashlib,json,shutil,sys
sys.dont_write_bytecode=True
T=Path(__file__).resolve().parent;P=T.parents[1]
OLD=P/'work/commercial-integration-20261022/source-v66-cli/component'
BASE=T/'assembly/project/work/ui-runtime-r55/src'
C=T/'component';S=C/'inputs-source'
read=lambda p:json.loads(p.read_text('utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest().upper()
def write(p,v):
 p.parent.mkdir(parents=True,exist_ok=True)
 with p.open('x',encoding='utf-8') as f:json.dump(v,f,ensure_ascii=False,indent=2);f.write('\n')
assert not C.exists();S.mkdir(parents=True)
old=read(OLD/'INPUTS.json');source_origin={}
for row in old['inputs']:
 target=row.get('target')
 if not target or not target.startswith('source/'):continue
 rel=Path(target).relative_to('source');src=BASE/rel
 assert src.is_file(),str(src)
 assert src.suffix.lower() not in ('.sqlite','.sqlite3','.db')
 dest=S/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dest);source_origin[rel.as_posix()]=str(src)
for group in ('runtime','worker'):
 for src in sorted((T/'candidate'/group).rglob('*')):
  if not src.is_file() or src.suffix!='.py':continue
  rel=src.relative_to(T/'candidate'/group);dest=S/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dest);source_origin[rel.as_posix()]=str(src)
entry=T/'candidate/entry/platform_cli_customer_read.py'
assert entry.is_file(),'Sender entry must be ready before preparing immutable compiler inputs'
shutil.copyfile(entry,S/'platform_cli.py');source_origin['platform_cli.py']=str(entry)
# Root merges the sender adapter patch into candidate/worker before this script.
assert (S/'assistant/xhs_reply_worker.py').is_file()
wrapper=sha(S/'platform_cli.py')
rows=[r for r in old['inputs'] if not (r.get('target') or '').startswith('source/')]
for p in sorted(S.rglob('*')):
 if p.is_file():rows.append(dict(path=str(p),target='source/'+p.relative_to(S).as_posix(),bytes=p.stat().st_size,sha256=sha(p),role='app_source',digest_basis='actual_bytes'))
manifest={**old,'wrapper_sha256':wrapper,'inputs':rows,'source_closure_sha256':hashlib.sha256(json.dumps({p:sha(S/p) for p in source_origin},sort_keys=True).encode()).hexdigest().upper()}
write(C/'INPUTS.json',manifest)
script_origins={}
for name in ('build_inactive_component.py','build_tool_entry.py','build_child_entry.py','build_io_fence.py'):
 src=OLD/name;text=src.read_text('utf-8-sig');script_origins[name]=sha(src)
 if name=='build_inactive_component.py':
  text=text.replace(old['wrapper_sha256'],wrapper)
  old_source="PROJECT / 'work/parallel-integration-20261018/final-integration/stage-02/project/work/ui-runtime-r55/src'"
  assert text.count(old_source)==1
  text=text.replace(old_source,"HERE / 'inputs-source'")
  text=text.replace("'platform-cli-guarded'","'platform-cli-customer-read'")
  text=text.replace("'platform-cli'","'platform-cli-customer-read'").replace("'platform-cli.exe'","'platform-cli-customer-read.exe'").replace("'dist/platform-cli'","'dist/platform-cli-customer-read'").replace("'work/platform-cli/Analysis-00.toc'","'work/platform-cli-customer-read/Analysis-00.toc'")
  needle="command += ['--hidden-import','assistant.xhs_cli_page_worker']"
  assert text.count(needle)==1
  text=text.replace(needle,needle+"\n    command += ['--hidden-import','assistant.xhs_reply_worker','--hidden-import','core.reply_execution_policy','--hidden-import','assistant.reply_read_session']")
  needle="guard['source_read_pages']='xhs-source-read-v1'"
  assert text.count(needle)==1
  text=text.replace(needle,needle+"\n    guard['reply_profile_pages']='xhs-reply-profile-read-v1'\n    guard['scoped_reply_transport']='reviewed-reply-v1'\n    guard['reply_worker_sha256']='"+sha(S/'assistant/xhs_reply_worker.py').lower()+"'\n    guard['profile_worker_sha256']='"+sha(S/'assistant/xhs_cli_page_worker.py').lower()+"'")
 ast.parse(text);(C/name).write_text(text,'utf-8')
write(T/'COMPONENT-PREPARATION.json',dict(status='PREPARED_NOT_BUILT',sourceOrigins=source_origin,originalBuilder=str(OLD),originalBuilderSha256=script_origins,inputsSha256=sha(C/'INPUTS.json'),wrapperSha256=wrapper,publicPackageInputs=len(rows)-len(source_origin),productionApproval=False,platformCalls=0,networkCalls=0))
print(json.dumps(dict(status='PREPARED_NOT_BUILT',inputs=len(rows),sourceFiles=len(source_origin),wrapperSha256=wrapper)))
