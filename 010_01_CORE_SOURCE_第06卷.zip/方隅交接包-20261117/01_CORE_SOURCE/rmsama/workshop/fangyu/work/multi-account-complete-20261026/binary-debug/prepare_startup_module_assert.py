from pathlib import Path
import ast
T=Path(__file__).resolve().parent.parent
p=T/'tests/test_native_complete_startup.py';s=p.read_text('utf-8-sig')
needle="  require(type(backend.platform_runtime).__name__=='PlatformRuntime' and backend.platform_runtime.core is backend.core,'Actual owned PlatformRuntime absent')"
new=needle+"""
  state['stage']='one actual core adapters module graph'
  actual_engine=sys.modules.get(type(backend.core).__module__)
  canonical_engine=sys.modules.get('core.engine')
  adapters_module=sys.modules.get('core.adapters')
  bridge_module=sys.modules.get('reviewed_reply_bridge')
  require(actual_engine is not None and actual_engine is canonical_engine,'Actual Core must belong to canonical core.engine module')
  require(getattr(actual_engine,'Core',None) is type(backend.core),'Actual Core class does not match its defining engine')
  require(adapters_module is not None and bridge_module is not None,'Canonical adapter or reviewed bridge module absent')
  require(actual_engine.AdapterBusy is bridge_module.AdapterBusy is adapters_module.AdapterBusy,'Duplicate AdapterBusy classes: actual engine, reviewed bridge and adapters must share one module graph')
  state['singleCoreAdaptersModuleGraph']=True"""
assert needle in s;s=s.replace(needle,new,1);ast.parse(s);p.write_text(s,'utf-8')
print('startup module-graph assertion prepared, not executed')
