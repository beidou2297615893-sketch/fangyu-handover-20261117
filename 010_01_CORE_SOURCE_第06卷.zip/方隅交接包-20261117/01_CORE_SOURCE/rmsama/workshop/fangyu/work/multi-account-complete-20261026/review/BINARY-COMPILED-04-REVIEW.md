# 第四次实际组件合成验收批准

2026-10-27，Astra 独立审查。

APPROVED_FOR_ONE_COMPILED_LOOPBACK_FIXTURE_RUN_04

仅批准 root 对新目录 binary-e2e/compiled-04 执行一次现有 --compiled-reviewed 路线，原项目/发布参数保持前次 ba1ea294 只读基线。新 helper 路径固定为 component-v2/artifacts/platform-cli-customer-read/platform-cli-customer-read.exe。

- harness.py：e6990325850597d64241b13b6b0e34a23f4c15594c2f79da3ef69e6f73c68253
- safety.py：08c0419c06a1fb10dfffd08166659f7f2d56004223f8bb207c5dd2d821cea980
- tests/loopback_tls_fixture.py：502a925a3b489bd4063c5fb8a5940123519fb54759bec6c2620175a6e9969edf
- 新 EXE：592154b01d641f3b16499d098621187bf306406b0c7eb1353b60e4f45533713c
- guard runtime_tree_sha256：61003ba72ed63c51212c9a1b8fa0c6843c0d3d0e42d5e182bad2c06426a54a97
- component-v2/artifacts/FROZEN.json：86678C5C0DBFB3BD2E46D00DE041BAB9EF927805DB887B085AD44D3732B1D89E
- v2 INPUTS：1BC58A959F8CE5E157D5DD790912D9E400C8C9F4481919EFBC94E6B945C013A0

独立重算 FROZEN 全部 296 个输出的 SHA256 与大小，零不匹配；实际 artifacts 共 297 文件（含 FROZEN 本身）。组件运行目录 291 文件。上述 harness、safety、TLS fixture、EXE 已重新取哈希。v2 根因与两份新增源的范围见 COMPONENT-V2-BUILD-REVIEW.md；原 255 源及 4 builder 保持原字节，未放宽 helper 的业务或网络 guards。

沿用 BINARY-COMPILED-03-REVIEW.md 的四个合成案例及全部边界：空临时 HOME、合成凭据、固定私有 flags、隐藏 child、捕获协议、临时 CA 仅 child 环境、所有代理固定 loopback 且 NO_PROXY 为空、响应器不转发；禁止真实平台、登录、模型与生产数据操作。父 Python audit 不是原生 child 的操作系统网络沙箱。原普通路线仍须阻断，私有注册必须签入本次新 component 的路径及哈希。

前 01/02/03 均未通过，记录保留。此次仅批准一次验收执行，不预先认定 PASS，不批准云部署、客户端安装或生产使用。失败保留诊断，不自动重跑；任一固定文件变化须重新审查。

## 实际结果：批准已消费

独立读取 compiled-04/RESULT.json，状态 FAIL：Compiled reader timeout。实际启动 1 个 v2 child，loopback 响应器收到 3 个 GET（whoami、user/otherinfo、user_posted），0 POST；尚无完成案例。这个结果证明已越过前次 early import failure，但不能认定完整读取、最后身份复核或发送通过。原 harness 整体等待 100 秒，下一版允许仅测试等待预算增至 180 秒以覆盖业务 150 秒上限，生产 guard 不延长。原目录及 e699 harness 保留，不再复用本批准执行 v2。
