'use strict';
const fs=require('node:fs');
const path=require('node:path');
const {spawnSync}=require('node:child_process');
const candidate=path.resolve(__dirname,'../candidate');
const checks=[
 {name:'new reviewed reply synthetic service cases',args:['--test',path.join(__dirname,'reviewed_reply_release.test.cjs')]},
 {name:'existing customer read and legacy synthetic service suite',args:[path.join(__dirname,'run_existing_service_tests.cjs')]},
 {name:'devices syntax',args:['--check',path.join(candidate,'devices.cjs')]},
 {name:'reviewed release syntax',args:['--check',path.join(candidate,'reviewed_reply_release.cjs')]}
];
for(const check of checks){const result=spawnSync(process.execPath,check.args,{encoding:'utf8',timeout:60000});check.exitCode=result.status;check.passed=result.status===0;check.output=(result.stdout||'')+(result.stderr||'');if(result.error)check.error=result.error.message;console.log(check.name+': '+(check.passed?'PASS':'FAIL'));}
const result={status:checks.every(c=>c.passed)?'PASS':'FAIL',atUtc:new Date().toISOString(),checks,syntheticOnly:true,externalCloudRequests:0,platformRequests:0,productionWrites:0,npmTestLimitation:'Upstream package.json references missing service.test.cjs; use these preserved existing service fixtures and new reviewed fixtures.'};
fs.writeFileSync(path.join(__dirname,'TEST-RESULTS.json'),JSON.stringify(result,null,2)+'\n');
process.exitCode=result.status==='PASS'?0:1;
