import hashlib
import json
import os
from pathlib import Path
import sqlite3
import subprocess
import sys
import tempfile
import unittest
from copy import deepcopy
from contextlib import closing
from unittest.mock import patch
from concurrent.futures import ThreadPoolExecutor
import threading

sys.dont_write_bytecode = True
sys.path.insert(0, os.environ['SCOPE_TEST_NATIVE'])
try:
    from reply_official_codex import ReplyOfficialCodexAdapter, ProviderReviewRequired, ENTITY
except ImportError:
    ReplyOfficialCodexAdapter = None
    ProviderReviewRequired = ValueError
    ENTITY = 'local_reply_codex_attempts_v1'


def material():
    request = {'request_id': 'ui-job-1', 'scope': {'tenant_id': 't', 'owner': 'alice',
        'actor_id': 'employee1', 'store_id': 's', 'account_id': 'a',
        'platform': 'xiaohongshu', 'customer_id': 'c', 'lead_id': 'l'},
        'source_digest': 'a'*64, 'context': {'conversation': {
            'target': {'id': 'comment1', 'authorId': 'uid1', 'text': '这里可以养猫吗'},
            'post': {'title': '出租', 'text': '两房'}, 'missing': []},
            'sameCustomerHistory': [{'id': 'l', 'sourceDigest': 'a'*64,
                'conversation': {'target': {'id': 'comment1', 'authorId': 'uid1', 'text': '这里可以养猫吗'}}}]},
        'tone_snapshot': {'version': 1, 'effectiveStyle': {'resolvedTone': 'friendly'}},
        'style_references': ['自然一些'], 'evidence_guard_version': 'reply-guard-v1',
        'model': 'gpt-6.1-sol'}
    request['context']['sameCustomerHistory'][0]['conversation'] = deepcopy(request['context']['conversation'])
    return request


def output():
    return {'relationship': '本人询问帖子', 'need': '养猫', 'fit': '只能介绍个人感受',
        'reason': '原文询问宠物', 'reply': '也可以看看我住的方隅，我感觉对宠物蛮友好。',
        'unknown': ['当前房源和具体规则未知'], 'shouldReply': True}


class ProviderTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.db = self.root/'core.sqlite'
        with closing(sqlite3.connect(self.db)) as db, db:
            db.execute('CREATE TABLE records(entity TEXT,id TEXT,tenant_id TEXT,body TEXT,PRIMARY KEY(entity,id))')
        self.exe = self.root/'OpenAI'/'Codex'/'bin'/'fixture'/'codex.exe'
        self.exe.parent.mkdir(parents=True)
        self.exe.write_bytes(b'fake official executable')
        self.calls, self.auth_calls = [], []

    def adapter(self, **overrides):
        self.assertIsNotNone(ReplyOfficialCodexAdapter, 'reply-specific durable official adapter is missing')
        options = {'contract_prompt': 'Frozen reply facts: only real resident experience.',
            'output_validator': lambda data, request: True, 'executable': self.exe,
            'executable_sha256': hashlib.sha256(self.exe.read_bytes()).hexdigest(),
            'executable_provenance': 'OpenAI desktop fixture pin', 'runner': self.run_process,
            'auth_probe': self.auth_process}
        options.update(overrides)
        return ReplyOfficialCodexAdapter(self.db, self.root/'receipts', **options)

    def rows(self):
        with closing(sqlite3.connect(self.db)) as db, db:
            return [json.loads(x[0]) for x in db.execute('SELECT body FROM records WHERE entity=?', (ENTITY,))]

    def auth_process(self, argv, **kw):
        self.auth_calls.append((argv, kw))
        return subprocess.CompletedProcess(argv, 0, 'Logged in using ChatGPT\n', '')

    def run_process(self, argv, **kw):
        self.calls.append((argv, kw))
        self.assertTrue(self.rows(), 'execution must be durably registered before dispatch')
        Path(argv[argv.index('-o')+1]).write_text(json.dumps(output(), ensure_ascii=False), 'utf-8')
        return subprocess.CompletedProcess(argv, 0, 'real stdout fixture', 'model: gpt-6.1-sol\n')

    def test_timeout_and_changed_ui_job_and_prompt_do_not_redispatch(self):
        def timeout(argv, **kw):
            self.calls.append((argv, kw))
            raise subprocess.TimeoutExpired(argv, 1, output='partial', stderr='model: gpt-6.1-sol')
        with self.assertRaises(ProviderReviewRequired):
            self.adapter(runner=timeout).execute(material(), authorize=lambda: True)
        changed = material(); changed['request_id'] = 'new-ui-job'
        with self.assertRaises(ProviderReviewRequired):
            self.adapter().execute(changed, authorize=lambda: True)
        changed['tone_snapshot']['effectiveStyle']['resolvedTone'] = 'concise'
        with self.assertRaises(ProviderReviewRequired):
            self.adapter(contract_prompt='changed version').execute(changed, authorize=lambda: True)
        self.assertEqual(len(self.calls), 1)
        self.assertEqual(self.rows()[0]['state'], 'unknown')

    def test_complete_raw_guard_upgrade_recovers_without_auth_or_model(self):
        with self.assertRaises(ProviderReviewRequired):
            self.adapter(output_validator=lambda data, request: False).execute(material(), authorize=lambda: True)
        changed = material(); changed['request_id'] = 'new-ui'; changed['evidence_guard_version'] = 'reply-guard-v2'
        self.calls.clear(); self.auth_calls.clear()
        result = self.adapter().execute(changed, authorize=lambda: True)
        self.assertTrue(result['recovered'])
        self.assertEqual(result['output'], output())
        self.assertEqual(self.calls, []); self.assertEqual(self.auth_calls, [])

    def test_authority_revoked_during_auth_does_not_dispatch(self):
        allowed = [True]
        def auth(argv, **kw):
            allowed[0] = False
            return self.auth_process(argv, **kw)
        with self.assertRaises(PermissionError):
            self.adapter(auth_probe=auth).execute(material(), authorize=lambda: allowed[0])
        self.assertEqual(self.calls, [])
        self.assertEqual(self.rows()[0]['state'], 'not_dispatched')

    def test_unknown_cannot_escape_with_owner_store_account_or_source_changes(self):
        def timeout(argv, **kw):
            self.calls.append((argv, kw)); raise subprocess.TimeoutExpired(argv, 1)
        with self.assertRaises(ProviderReviewRequired):
            self.adapter(runner=timeout).execute(material(), authorize=lambda: True)
        for key, value in [('owner','bob'), ('store_id','other'), ('account_id','other'), ('actor_id','other')]:
            changed = material(); changed['scope'][key] = value
            with self.assertRaises(ProviderReviewRequired):
                self.adapter().execute(changed, authorize=lambda: True)
        self.assertEqual(len(self.calls), 1)

    def test_env_auth_proof_and_model_command_are_bound_and_secret_free(self):
        secret = 'never-save-this-token'
        with patch.dict(os.environ, {'OPENAI_API_KEY': secret, 'AZURE_OPENAI_ENDPOINT': secret,
                                    'CODEX_HOME': secret, 'NORMAL_FIXTURE': 'retained'}):
            result = self.adapter().execute(material(), authorize=lambda: True)
        self.assertEqual(len(self.auth_calls), 2)
        for argv, kw in self.calls + self.auth_calls:
            self.assertFalse(any(k.upper().startswith(('OPENAI_', 'AZURE_OPENAI_', 'CODEX_')) for k in kw['env']))
            self.assertEqual(kw['env']['NORMAL_FIXTURE'], 'retained')
            self.assertNotIn('forced_login_method', ' '.join(argv))
        argv = self.calls[0][0]
        for arg in ('--ignore-user-config','--ephemeral','model_provider="openai"',
                    'model_reasoning_effort="medium"','features.shell_tool=false',
                    'web_search="disabled"','project_doc_max_bytes=0'):
            self.assertIn(arg, argv)
        self.assertFalse(result['receipt']['human_confirmed'])
        for file in (self.root/'receipts').rglob('*'):
            if file.is_file(): self.assertNotIn(secret, file.read_text('utf-8'))

    def test_api_login_never_dispatches_or_saves_auth_output(self):
        secret = 'api-key-fragment-must-not-save'
        def api_auth(argv, **kw):
            return subprocess.CompletedProcess(argv, 0, 'Logged in using an API key '+secret, '')
        with self.assertRaises(ProviderReviewRequired):
            self.adapter(auth_probe=api_auth).execute(material(), authorize=lambda: True)
        self.assertEqual(self.calls, [])
        for file in (self.root/'receipts').rglob('*'):
            if file.is_file(): self.assertNotIn(secret, file.read_text('utf-8'))

    def test_returned_model_mismatch_and_strict_reply_schema_reject_without_retry(self):
        for kind in ('model', 'extra', 'false_nonempty', 'empty_true', 'duplicate'):
            with self.subTest(kind=kind):
                request = material(); request['scope']['lead_id'] += kind
                request['context']['sameCustomerHistory'][0]['id'] = request['scope']['lead_id']
                def runner(argv, **kw):
                    self.calls.append((argv, kw))
                    data = output()
                    if kind == 'extra': data['human_confirmed'] = True
                    if kind == 'false_nonempty': data['shouldReply'] = False
                    if kind == 'empty_true': data['reply'] = ''
                    raw = json.dumps(data, ensure_ascii=False)
                    if kind == 'duplicate': raw = raw[:-1]+',"reply":"duplicate"}'
                    Path(argv[argv.index('-o')+1]).write_text(raw, 'utf-8')
                    return subprocess.CompletedProcess(argv, 0, '', 'model: '+('other' if kind=='model' else 'gpt-6.1-sol'))
                with self.assertRaises(ProviderReviewRequired): self.adapter(runner=runner).execute(request, authorize=lambda: True)
                count = len(self.calls)
                with self.assertRaises(ProviderReviewRequired): self.adapter().execute(request, authorize=lambda: True)
                self.assertEqual(len(self.calls), count)

    def test_complete_receipt_tamper_and_foreign_tenant_attempt_fail_closed(self):
        result = self.adapter().execute(material(), authorize=lambda: True)
        row = self.rows()[0]
        with closing(sqlite3.connect(self.db)) as db, db:
            row['tenant_id'] = 'foreign'
            db.execute('UPDATE records SET body=? WHERE entity=?', (json.dumps(row), ENTITY))
        with self.assertRaises(ProviderReviewRequired): self.adapter().execute(material(), authorize=lambda: True)
        self.assertEqual(len(self.calls), 1)

    def test_authority_revoked_after_model_retains_raw_but_returns_no_output(self):
        allowed = [True]
        def runner(argv, **kw):
            result = self.run_process(argv, **kw); allowed[0] = False; return result
        with self.assertRaises(PermissionError): self.adapter(runner=runner).execute(material(), authorize=lambda: allowed[0])
        self.assertTrue((Path(self.rows()[0]['receipt_directory'])/'EXECUTION-RECEIPT.json').is_file())

    def test_executable_sha_failure_has_zero_auth_and_dispatch(self):
        with self.assertRaises(ProviderReviewRequired):
            self.adapter(executable_sha256='0'*64).execute(material(), authorize=lambda: True)
        self.assertEqual(self.calls, []); self.assertEqual(self.auth_calls, [])

    def test_timeout_preserves_actual_process_and_unknown_receipt(self):
        def timeout(argv, **kw):
            raise subprocess.TimeoutExpired(argv, 1, output=b'partial stdout', stderr=b'partial stderr')
        with self.assertRaises(ProviderReviewRequired): self.adapter(runner=timeout).execute(material(), authorize=lambda: True)
        row = self.rows()[0]; folder = Path(row['receipt_directory'])
        self.assertEqual((folder/'stdout.log').read_bytes(), b'partial stdout')
        self.assertTrue((folder/'process.json').is_file())
        self.assertTrue((folder/'UNKNOWN-RECEIPT.json').is_file())
        receipt = json.loads((folder/'UNKNOWN-RECEIPT.json').read_text('utf-8'))
        self.assertTrue(receipt['timeout']); self.assertIsNone(receipt['returncode'])
        self.assertEqual(row['unknown_receipt_sha256'], hashlib.sha256((folder/'UNKNOWN-RECEIPT.json').read_bytes()).hexdigest())

    def test_return_receipt_sha_tamper_and_concurrent_same_request_never_redispatch(self):
        started = threading.Event(); finish = threading.Event()
        def runner(argv, **kw):
            started.set(); self.assertTrue(finish.wait(5)); return self.run_process(argv, **kw)
        with ThreadPoolExecutor(max_workers=2) as pool:
            first = pool.submit(self.adapter(runner=runner).execute, material(), authorize=lambda: True)
            self.assertTrue(started.wait(5))
            try:
                with self.assertRaises(ProviderReviewRequired): self.adapter().execute(material(), authorize=lambda: True)
            finally: finish.set()
            result = first.result(5)
        self.assertEqual(len(self.calls), 1)
        row = self.rows()[0]; receipt = Path(row['receipt_directory'])/'RECEIPT.json'
        receipt.write_text('{}', 'utf-8')
        with self.assertRaises(ProviderReviewRequired): self.adapter().execute(material(), authorize=lambda: True)
        self.assertEqual(len(self.calls), 1)

    def test_source_and_actor_cas_callback_and_fact_guard_reject_no_business_output(self):
        expected = material()['source_digest']; state = [expected]
        def changed(argv, **kw):
            state[0] = 'b'*64; return self.run_process(argv, **kw)
        with self.assertRaises(PermissionError):
            self.adapter(runner=changed).execute(material(), authorize=lambda: state[0] == expected)
        self.assertEqual(len(self.calls), 1)
        seen = []
        def fact_guard(data, request):
            seen.append((data, request)); return False
        with self.assertRaises(ProviderReviewRequired):
            self.adapter(output_validator=fact_guard).execute(material(), authorize=lambda: True)
        self.assertTrue(seen)
        self.assertEqual(len(self.calls), 1)

    def test_missing_source_provenance_and_invalid_model_fail_before_auth(self):
        for mutate in ('history', 'source', 'model'):
            request = material()
            if mutate == 'history': request['context']['sameCustomerHistory'] = []
            if mutate == 'source': request['source_digest'] = 'missing'
            if mutate == 'model': request['model'] = 'other'
            with self.assertRaises(ValueError): self.adapter().execute(request, authorize=lambda: True)
        self.assertEqual(self.calls, []); self.assertEqual(self.auth_calls, [])

    def test_complete_fixed_prompt_schema_digest_and_minimal_canonical_model_prompt(self):
        import reply_official_codex as module
        first = self.adapter()
        with patch.object(module, 'GUIDANCE', module.GUIDANCE+' changed fixed guidance'):
            self.assertNotEqual(first.contract_digest, self.adapter().contract_digest)
        changed_schema = deepcopy(module.OUTPUT_SCHEMA); changed_schema['description'] = 'changed schema'
        with patch.object(module, 'OUTPUT_SCHEMA', changed_schema):
            self.assertNotEqual(first.contract_digest, self.adapter().contract_digest)
        request = material(); changed = deepcopy(request)
        changed['request_id'] = 'other-job'; changed['evidence_guard_version'] = 'other-guard'
        self.assertEqual(first.build_prompt(request), first.build_prompt(changed))
        self.assertNotIn('ui-job-1', first.build_prompt(request))
        self.assertNotIn('employee1', first.build_prompt(request))
        self.assertIn('comment1', first.build_prompt(request))

    def test_target_history_exact_binding_distinct_platform_id_is_valid(self):
        request = material()
        self.assertNotEqual(request['scope']['lead_id'], request['context']['conversation']['target']['id'])
        self.assertEqual(self.adapter().execute(request, authorize=lambda: True)['output'], output())
        for kind in ('different_conversation', 'duplicate_id', 'invalid_history_sha', 'missing_conversation'):
            changed = material()
            if kind == 'different_conversation': changed['context']['sameCustomerHistory'][0]['conversation']['target']['text'] = '另一人原文'
            if kind == 'duplicate_id': changed['context']['sameCustomerHistory'].append(deepcopy(changed['context']['sameCustomerHistory'][0]))
            if kind == 'invalid_history_sha': changed['context']['sameCustomerHistory'][0]['sourceDigest'] = 'invalid'
            if kind == 'missing_conversation': changed['context']['sameCustomerHistory'][0].pop('conversation')
            with self.subTest(kind=kind), self.assertRaises(ValueError):
                self.adapter().execute(changed, authorize=lambda: True)
        self.assertEqual(len(self.calls), 1)

    def test_offline_recovery_rebuilds_exact_model_prompt_instead_of_self_hash_only(self):
        import reply_official_codex as module
        self.adapter().execute(material(), authorize=lambda: True)
        self.calls.clear(); self.auth_calls.clear()
        with patch.object(module.ReplyOfficialCodexAdapter, 'build_prompt', return_value='changed canonical prompt'):
            with self.assertRaises(ProviderReviewRequired):
                self.adapter().execute(material(), authorize=lambda: True)
        self.assertEqual(self.calls, []); self.assertEqual(self.auth_calls, [])

    def test_pre_runner_failure_does_not_claim_process_dispatch(self):
        import reply_official_codex as module
        original = module._write
        failed = [False]
        def fail_once(path, value):
            if Path(path).name == 'schema.json' and not failed[0]:
                failed[0] = True; raise OSError('fixture preparation disk error')
            return original(path, value)
        with patch.object(module, '_write', side_effect=fail_once):
            with self.assertRaises(ProviderReviewRequired): self.adapter().execute(material(), authorize=lambda: True)
        self.assertEqual(self.calls, []); self.assertEqual(self.auth_calls, [])
        folder = Path(self.rows()[0]['receipt_directory'])
        self.assertFalse(json.loads((folder/'process.json').read_text('utf-8'))['dispatch_invoked'])

    def test_existing_only_never_starts_missing_or_not_dispatched_attempt(self):
        with self.assertRaises(ProviderReviewRequired):
            self.adapter().execute(material(), authorize=lambda: True, existing_only=True)
        self.assertEqual(self.rows(), [])
        allowed = [True]
        def auth(argv, **kw):
            allowed[0] = False; return self.auth_process(argv, **kw)
        with self.assertRaises(PermissionError):
            self.adapter(auth_probe=auth).execute(material(), authorize=lambda: allowed[0])
        self.auth_calls.clear()
        with self.assertRaises(ProviderReviewRequired):
            self.adapter().execute(material(), authorize=lambda: True, existing_only=True)
        self.assertEqual(self.calls, []); self.assertEqual(self.auth_calls, [])

    def test_existing_only_recovers_complete_raw_unknown_without_auth_or_model(self):
        self.adapter().execute(material(), authorize=lambda: True)
        row = self.rows()[0]; row['state'] = 'unknown'; row.pop('receipt_sha256')
        (Path(row['receipt_directory'])/'RECEIPT.json').unlink()
        with closing(sqlite3.connect(self.db)) as db, db:
            db.execute('UPDATE records SET body=? WHERE entity=?', (json.dumps(row), ENTITY))
        self.calls.clear(); self.auth_calls.clear()
        result = self.adapter().execute(material(), authorize=lambda: True, existing_only=True)
        self.assertTrue(result['recovered'])
        self.assertEqual(self.calls, []); self.assertEqual(self.auth_calls, [])


if __name__ == '__main__':
    unittest.main(verbosity=2)
