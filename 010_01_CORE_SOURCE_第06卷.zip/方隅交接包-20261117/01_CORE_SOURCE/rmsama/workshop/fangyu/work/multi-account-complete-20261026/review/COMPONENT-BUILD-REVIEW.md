# 独立组件构建静态审查

审查者：Astra（非构建脚本作者），2026-10-26。

STATIC_APPROVED_FOR_ISOLATED_COMPONENT_BUILD

本批准仅允许一次按已冻结输入执行离线组件构建；不批准运行平台 CLI、联网、登录、真实采集、发送、安装或替换现有客户运行目录。

## 精确输入

- INPUTS.json SHA256：`35649DAB7FB5F060BDA23726DE39571E3400CC10873C12B1A0CF316C835DB3CF`
- build_inactive_component.py SHA256：`8F255D71196A3412D31E08377312A47EC95A3ABE0B7F382648840F3E468914C2`
- build_tool_entry.py SHA256：`18C9723ED1148CE80AD6358F6A7C33ACA3B452D665B361655E0541398CA16718`
- build_child_entry.py SHA256：`D71912D41A68F18B04BF64C8C647BD59934A6BEF166B358F4DDB82C6CAE9833E`
- build_io_fence.py SHA256：`FCF713D589E9262E903B9AED6AB893D17F155087B8CFD7F8F0A41EA0E00AF4AD`
- wrapper SHA256：`1513B1672C72811E0400C4B8806180C986E301EB50ECF9C332C767E22CD2986F`

独立重算全部 3531 个输入文件大小及 SHA256，另核六个公开 Python 原生映像摘要，全部一致。其中 255 个 app 源文件、27 个原厂 guard vendor 文件、3216 个公开依赖文件、32 个 distribution records、1 个只作证据而不解包的 wheel。没有读取账号凭据或生产数据库。

## 静态结论

构建器只向本 task/component/build-work 与 artifacts 写新产物，目标已存在则拒绝覆盖；输入根限定公开依赖与固定源码快照。固定 Python 以 -I -S -B 启动，不使用个人 .pth。编译主进程和隔离 probe 均安装 Python I/O/process/network fence；只允许固定 PyInstaller probe，不执行应用 helper。该 fence 是 Python 层防线，不声称操作系统沙箱。

三个编译入口与既有 commercial-integration-20261022/source-v66-cli/component 中成熟版本摘要相同。已发现并由 root 修正输出目录名：--name platform-cli-customer-read 对应 dist/platform-cli-customer-read。当前 builder 摘要包含此修复。

wrapper 普通命令仍限 status/whoami/search/read/comments/sub-comments；新增发送只通过精确 --owned-xhs-reviewed-reply 私有 stdin 协议，公开资料扩展通过原 --owned-xhs-cli-pages。构建过程不会调用这些 helper。

本批准不代表新可执行文件已通过运行验收、不代表远端发送 grant 或最终客户端源已通过审查。新 exe 出现后，须固定输出摘要并单独审查合成本地 TLS harness；最终客户端 policy/lease 及组件材料还需完成精确源审查。任一上述输入或脚本摘要变化需重新审查，失败不自动换参数重跑。
