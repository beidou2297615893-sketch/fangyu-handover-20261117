import importlib.util, pathlib, unittest
P=pathlib.Path(__file__).resolve().parents[2]/'candidate/reply_account_profiles.py'
class ContractTests(unittest.TestCase):
 def test_explicit_needs_and_no_demographic_inference(self):
  self.assertTrue(P.exists(),'account routing implementation missing')
  spec=importlib.util.spec_from_file_location('profiles',P);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
  self.assertEqual(m.explicit_topics('我是外国女生，IP上海，头像有猫'),[])
  self.assertIn('pet',m.explicit_topics('租房可以养猫吗？'))
  self.assertEqual(m.explicit_topics('喜欢猫猫'),[])
if __name__=='__main__':unittest.main()
