"""Small representative complete-context failures; no model or platform I/O."""
from copy import deepcopy
import importlib.util
from pathlib import Path
import sys,unittest

W=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(W/'assembly/project/work/ui-native-r57'))
from reply_context import conversation
from reply_ai_workflow import Workflow,ENTITY
path=W.parents[1]/'work/context-reply-workflow-20261025/tests/test_workflow.py'
spec=importlib.util.spec_from_file_location('complete_context_original_fixture',path)
legacy=importlib.util.module_from_spec(spec);spec.loader.exec_module(legacy)

class CompleteContext(unittest.TestCase):
    def fixture(self):
        f=legacy.Tests('runTest');f.setUp();self.addCleanup(f.release.set)
        return f
    def history(self):
        return {'id':'history','sourceDigest':'history-v1','canSave':False,'pendingRequestId':'','draft':None,'accounts':[],
            'conversation':conversation({'text':'还在找房','comment_id':'old','content_title':'原来的求租帖'})}

    def test_content_body_is_acquired_material_with_explicit_origin(self):
        value=conversation({'text':'请问房型','content_body':'真实采集的正文'})
        self.assertEqual(value['post']['text'],'真实采集的正文')
        self.assertEqual(value['post'].get('materialSource'),'content_body')

    def test_conflicting_body_aliases_are_not_silently_chosen(self):
        value=conversation({'text':'请问房型','content_text':'正文A','content_body':'另一份正文B'})
        self.assertEqual(value['post']['text'],'')
        self.assertTrue(any('冲突' in reason for reason in value['missing']))

    def test_complete_history_is_supplied_even_without_fast_raw_reader(self):
        f=self.fixture();comments=[f.row,self.history()]
        f.b.reply_workbench.read=lambda *a,**kw:{'item':{'name':'momo'},'comments':deepcopy(comments)}
        job=f.finish(f.start())
        self.assertEqual(len(f.calls[0][0]['sameCustomerHistory']),2)
        self.assertEqual(job['rows'][0]['status'],'ready')

    def test_history_source_change_during_model_cannot_publish_old_reply(self):
        f=self.fixture();comments=[f.row,self.history()]
        f.b.reply_workbench.read=lambda *a,**kw:{'item':{'name':'momo'},'comments':deepcopy(comments)}
        job=f.start()
        comments[1]['sourceDigest']='history-v2'
        comments[1]['conversation']=conversation({'text':'已经租好了，不找了','comment_id':'old','content_title':'原来的求租帖'})
        done=f.finish(job)
        self.assertEqual(done['rows'][0]['status'],'error');self.assertFalse(done['rows'][0]['selected'])

    def test_new_same_customer_member_during_model_rejects_old_reply(self):
        f=self.fixture();comments=[f.row]
        f.b.reply_workbench.read=lambda *a,**kw:{'item':{'name':'momo'},'comments':deepcopy(comments)}
        job=f.start();comments.append(self.history())
        done=f.finish(job)
        self.assertEqual(done['rows'][0]['status'],'error');self.assertFalse(done['rows'][0]['selected'])

    def test_exact_approved_sample_snapshot_is_durable(self):
        f=self.fixture();job=f.start();f.finish(job)
        stored=f.store.get(ENTITY,job['id'])
        self.assertEqual(stored['styleReferences'],['可以看看呀～'])
        self.assertEqual(stored['sampleSnapshot'][0]['reference_text'],'可以看看呀～')
        self.assertTrue(stored['sampleDigest'])

if __name__=='__main__':unittest.main(verbosity=2)
