import assert from 'node:assert/strict';
import {renderContext,renderAI,bindAI} from '../assembly/project/work/ui-approved-implementation/ui-preview/pages/reply-ai.mjs';
const context={label:'二级回复 · 回应评论',level:2,post:{title:'<script>已租到</script>',author:'帖主',text:''},parent:{author:'甲',text:'这是两房'},target:{author:'乙',text:'哪里多少钱'},missing:['帖子正文未采集'],coverage:'已采集上下文'};
assert.ok(renderContext(context).includes('&lt;script&gt;'));
assert.ok(renderContext(context).includes('这是两房'));
function setup(){
 const row={customerId:'c',leadId:'l',sourceDigest:'d',context,name:'乙',status:'ready',selected:true,text:'  Hello，可以看看这里呀！  ',analysis:{relationship:'问甲',need:'位置价格',fit:'未知',reason:'提供备选',unknown:[]}};
 const v={items:[{id:'c'}],selectedId:'c',leadId:'l',detail:{comments:[{id:'l',accounts:[{id:'a',name:'本人'}]}]},ai:{accountId:'a',tone:'自然',job:{id:'j',revision:1,state:'done',completed:1,total:1,sampleCount:0,rows:[row]}}};
 const state={user:'owner',storeId:'s',activePlatform:'xiaohongshu',authEpoch:1,page:'reply',replyLive:v};
 const handlers={},element=key=>({addEventListener:(event,fn)=>handlers[key]=fn});
 const root={querySelector:selector=>element(selector),querySelectorAll:()=>[]};
 const calls=[];let modal,draft=null;
 const ctx={state,update:()=>{},toast:()=>{},modal:value=>{modal=value;},
 replyAI:async(action,data)=>{calls.push(action);if(action==='reply_ai_read')return {replyAI:{tone:'',job:null,savedTone:{revision:1,tone:'friendly',toneLabel:'自然友好',salutation:'你好',focus:[],customerTemplate:'',identityRule:'真实住户'},effectiveStyle:{mode:'store',resolvedTone:'friendly',label:'自然友好',storeToneRevision:1},styleModes:[{id:'store',label:'跟随本店'}]}};const job=structuredClone(v.ai.job);job.revision++;for(const r of job.rows)r.confirmationKey='key';if(action==='reply_ai_confirm'){job.rows[0].confirmation={state:'confirmed'};job.rows[0].selected=false;}return {replyAI:job};},
 replyRead:async()=>({replyWorkspace:{comments:[{id:'l',sourceDigest:'d',draft}]}}),
 replySave:async data=>{calls.push('save');draft={id:'draft',version:1,text:data.text.trim()};return {replyWorkspace:{comments:[{id:'l',sourceDigest:'d',draft}]}};},
 replyReview:async data=>{calls.push('review');draft.review_account_id=data.accountId;return {replyWorkspace:{comments:[{id:'l',sourceDigest:'d',draft,reviewCurrent:true}]}};},
 deliveryAction:()=>{throw Error('MUST NEVER SEND');}};
 bindAI(root,ctx,v);
 return {v,state,handlers,calls,ctx,get modal(){return modal;}};
}
const a=setup();a.handlers['[data-ai-confirm]']();assert.equal(await a.modal.onConfirm(),true);
assert.deepEqual(a.calls.filter(action=>action!=='reply_ai_read'),['reply_ai_edit','reply_ai_confirm']);
assert.equal(a.calls.filter(action=>action==='reply_ai_read').length,1);
assert.equal(a.calls.some(action=>/send|delivery/.test(action)),false);
assert.equal(a.v.ai.job.rows[0].selected,false);assert.equal(a.v.ai.job.rows[0].text,'Hello，可以看看这里呀！');
const b=setup();b.handlers['[data-ai-confirm]']();b.v.ai.accountId='other';assert.equal(await b.modal.onConfirm(),false);assert.equal(b.calls.length,0);
const c=setup();c.handlers['[data-ai-confirm]']();c.state.authEpoch++;assert.equal(await c.modal.onConfirm(),false);assert.equal(c.calls.length,0);
assert.ok(renderAI(a.state,a.v).includes('自动发送已关闭'));
console.log('PASS: escaped context, server confirmation without client-side legacy mutation or delivery, whitespace normalization, account and session change guards');
