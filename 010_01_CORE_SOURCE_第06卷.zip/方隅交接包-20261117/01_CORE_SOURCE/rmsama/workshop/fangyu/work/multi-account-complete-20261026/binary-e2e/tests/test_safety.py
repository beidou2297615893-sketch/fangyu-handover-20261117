import tempfile,unittest,sys
import subprocess
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from safety import ChildGuard,child_env,sha
class SafetyTests(unittest.TestCase):
 def test_guard_rejects_all_unreviewed_or_inexact_children(self):
  with tempfile.TemporaryDirectory(dir=Path(__file__).resolve().parent) as d:
   root=Path(d);exe=root/'test.exe';exe.write_bytes(b'inert never run');ca=root/'ca.pem';ca.write_text('inert')
   env=child_env(root/'account',dict(HTTP_PROXY='http://127.0.0.1:12345',HTTPS_PROXY='http://127.0.0.1:12345',ALL_PROXY='http://127.0.0.1:12345',SSL_CERT_FILE=str(ca)))
   called=[];g=ChildGuard(exe,sha(exe),root,reviewed=False,popen=lambda *a,**k:called.append(a))
   with self.assertRaises(AssertionError):g.popen([str(exe),'--owned-xhs-cli-pages'],env=env)
   g.reviewed=True
   options=dict(env=env,cwd=env['HOME'],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
   g.validate([str(exe),'--owned-xhs-cli-pages'],options)
   for argv in ([str(exe),'reply'],[str(exe),'--owned-xhs-reviewed-reply','extra'],['cmd.exe','/c'],[str(root/'other.exe'),'--owned-xhs-cli-pages']):
    with self.assertRaises(AssertionError):g.popen(argv,env=env)
   for changes in ({'shell':True},{'env':{**env,'no_proxy':'*'}},{'env':{**env,'HOME':str(root.parent)}},{'env':{**env,'https_proxy':'https://external.test'}},{'env':{**env,'WORKSPACE_ACTIVITY_LOG':str(root.parent/'production.jsonl')}},{'env':{**env,'TEMP':str(root.parent)}},{'env':{**env,'LEADSTUDIO_ISOLATED':'0'}},{'stdout':None}):
    with self.assertRaises(AssertionError):g.popen([str(exe),'--owned-xhs-cli-pages'],**{**options,**changes})
   exe.write_bytes(b'changed')
   with self.assertRaises(AssertionError):g.popen([str(exe),'--owned-xhs-cli-pages'],env=env)
   self.assertEqual(called,[])
if __name__=='__main__':unittest.main(verbosity=2)
