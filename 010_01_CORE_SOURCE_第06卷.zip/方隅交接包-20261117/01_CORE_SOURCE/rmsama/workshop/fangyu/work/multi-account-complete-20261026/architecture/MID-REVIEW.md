# 实现中期关键审查

2026-10-26，Astra；只读审查候选源码，未运行平台、CLI 或模型。

## 需关闭的阻塞

1. 当前实际 sharedvendor Runner 的 customer_read_release 明确 public_send_allowed=False、只读 request、accept_commands=False。online、remote_safety_hold=False 和 can_reply 不足以升级这份只读许可。正常发送需来自原认证 heartbeat 的独立明确发送 grant；不得由本地 manifest 或读 lease 伪造。已经交 root 定位服务端实现并接原控制面，sender 保留每 wire 检查接口。
2. 发送 worker 首个 UID 优先可能忽略同一响应其他明确身份字段冲突；需 GETME 多位置身份一致、回复 sender 多位置一致，并检查顶层及嵌套 comment ID 冲突。GETME 冲突零 POST；发送后冲突 unknown。已交 sender。
3. PublicReadWorkflow 的 requestId reservation 只有内存锁。跨 Store/进程可同时创建相同任务并先后读取。应原子 SQLite insert-if-absent，只有成功插入方启动。
4. 读取取消只检查本进程 controls；另一进程持久化取消后，原 worker 仍可继续 wire。每 wire 检查持久任务状态和 generation，完成写入 CAS；历史 completed 的显式 apply 单独保留。已交 backend。
5. 公开读取投影也需拒绝明确身份字段互相矛盾，不能因为第一个字段等于请求对象就标 verified。已交 backend。

## 已核定的实现判断

- 资料 apply 是历史证据采用，不要求读取时身份 capability TTL 仍有效；需完整完成状态、当前 actor/store/customer/accountIdentity、evidence revision CAS，保存 observedAt。不能拿它证明当前登录，更不能授权发送。
- 正常公开资料读可以复用现有效 content_read 远端 lease 的权限子集；新 CLI 材料选择通过目的限定的 reviewed registration，与原 natural material 校验独立，不全局放宽旧 _snapshot，也不禁用自然浏览器路线。
- 发送桥子进程 result ACK 发生在 Core 业务结果持久化之前。安全性依赖先行持久预算及原 sending 崩溃恢复为 unknown；文案不得说 ACK 已代表 Core 业务回执完成持久化。

## 实际可执行文件的本地 TLS 验证方法

已读 tests/loopback_tls_fixture.py，SHA256 `502a925a3b489bd4063c5fb8a5940123519fb54759bec6c2620175a6e9969edf`。该源码只绑定 127.0.0.1，自行终止 TLS 并生成固定合成响应；不存在外联或代理转发实现。认可此方法作为实际 exe 协议测试。

最终运行仍需核 exact INPUTS/exe 与测试 harness：专属空 HOME、合成会话、仅 child 注入大小写全部代理变量及临时 CA、清空 NO_PROXY、无系统证书修改、固定 Popen argv/摘要、不读生产凭据、不 shipping 测试钩子，确认所有 HTTP 经原 HTTPX 客户端且没有代理失败 fallback。

父 Python audit 只约束父进程，不能声称它约束了原生子进程或提供 OS 网络沙箱。该方法的边界是已审代码的固定代理路由和无外联响应器。当前仅批准测试方法；实际 child harness 和编译输入尚待精确审查后批准执行。
