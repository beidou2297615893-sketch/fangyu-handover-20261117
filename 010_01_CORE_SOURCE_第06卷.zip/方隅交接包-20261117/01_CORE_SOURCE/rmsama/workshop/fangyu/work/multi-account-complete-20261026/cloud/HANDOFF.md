# 云端受控回复许可候选：离线交接

已使用既有 fresh live-before（tree 843361adb2bf456a4c23ea86bdd2dad6904c7e92634001978226f8d74ed7a84b）增量实现。仅 devices.cjs 接线与新增 reviewed_reply_release.cjs；5617 个既有文件原字节保留。摘要占位阶段 candidate tree 为 60ace1d385d69db8f7093d9cf97b4e06b1a4d8fb58aa2212ec9dff55ec5c4d31。

固定 allowlist 只绑定 protocol/clientVersion/materialSha256；占位不是合法 hex，默认拒绝。材料摘要仅为版本准入，不是远程可信硬件证明。只有本地已审核队列可消费该独立许可，普通远程 reply_send 指令仍不开放。原 customer read/public_send=false、reply_trial、commandHeld、submit、accept_commands 与状态机代码均未修改。

owner_permissions.permission_revision 只在 reviewed_reply_protocol 精确匹配时新增。revision 为固定字段 JSON SHA256：username、role、disabled、effectiveCanReply、已有 permission_revision（不存在 null）；旧 can_reply !== false 语义保留。读取设备原 last_seen 快照，防止原心跳刷新掩盖本次过期；旧 last_seen 更新逻辑仍保留，下次正常新心跳可以恢复。原始配置 platformQaDeviceId 命中即拒绝，即使请求试图上报 read 版本。

## 验证

- 先写合成 service tests，红灯 7 组中 5 失败（新许可/revision缺失），实现后 7/7 PASS。
- 复用已成熟 read 客户端 service suite：10 组、43 次合成 service 请求，包含真实内存 login/pair/enroll/legacy 比较；PASS。
- 2 个修改模块 node --check PASS。
- 原云包 package.json 的 npm test 指向不存在的 service.test.cjs，该上游脚本不可执行；未改 package。完整可重复验证入口为下方 verify_candidate。
- 外部云请求、生产数据库读写、生产配置读写、平台请求、模型调用、部署均为 0。

## 最终材料写入与审核

在项目 cloud 目录运行：

```powershell
python .\prepare_candidate.py --material-sha256 <已审senderRegistration.manifest_digest>
node .\tests\verify_candidate.cjs
```

prepare_candidate 只允许首次占位替换或相同摘要幂等确认；不接受格式错误或静默替换已固定的不同摘要。脚本核实完整 fresh 基线、只允许两个文件变化，更新 COMPOSITION.json。摘要写入后需由 root / Astra 精确审核并按新 afterTree 做后续 CAS、字节更新与读回；本子任务没有执行或授权部署。verify_candidate 在内存中替换合成固定表跑全合成准入矩阵，并直接使用候选固定表测试默认拒绝/最终摘要正常许可。

## 基线元数据纠正

BASELINE.json 的 priorDeploymentChangedFiles 已使用正确 project/work/cloud-prompt-deployment-20261025/approved-code 重新计算；正确差异列表为空，两份均为 5618 文件。只纠正路径和比较报告；fresh ZIP、live-before、候选拷贝均未重新下载或替换。

## 文件

- candidate/devices.cjs
- candidate/reviewed_reply_release.cjs
- tests/reviewed_reply_release.test.cjs
- tests/run_existing_service_tests.cjs
- tests/verify_candidate.cjs
- tests/TEST-RESULTS.json
- tests/CLOUD-SERVICE-TEST-RESULTS.json（仅合成心跳证据）
- prepare_candidate.py / COMPOSITION.json / BASELINE.json

## 实际原生客户端兼容补充（Astra / root 新定案）

固定表现在为同 protocol/material 的两个明确版本：1.2.0-read.1 和 1.1.8-pilot.1。前者保持既有 customerReadPolicy/matching request/readLease.allowed；后者必须满足原 employeeRelease.allowed、continuous_read、version 与本次版本一致，且真实 adminWorkbenchFor(company,device,owner) 固定策略为 true，payload 与 device source marker 均为 fangyu-admin-local-v1。共同认证、owner/role/can_reply、前次90秒心跳、nonQA 与材料条件保持。响应 version 采用实际允许版本。没有改旧策略、配置、设备表、commandHeld 或远程submit。

此轮新增正例先失败（10组中1失败），补实现后10/10 reviewed tests PASS；旧10组43请求、两语法检查仍PASS。增加实际native固定策略正例与错设备/账号/角色/marker/employee配置/材料/过期/canreply拒绝、native旧响应与fresh live完全同形。最终真实固定摘要写入后，验证入口同时直接测实际固定表的两个版本正例。

最新占位代码SHA：devices.cjs b2cc587b6a07f0d185d6599a1ef2944c4e9cf020beb93292998e4f8e7d0228bc；reviewed_reply_release.cjs d0cb116565eb65c314b6bff87f424bc77eac17f6a983edbfcec3c21a1a9413f7。仍5617旧文件原字节不变。
