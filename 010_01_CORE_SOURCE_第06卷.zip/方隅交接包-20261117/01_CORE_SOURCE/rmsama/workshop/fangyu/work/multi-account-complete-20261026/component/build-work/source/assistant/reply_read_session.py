"""Purpose-bound public profile/session reader over the original registered PageWorker."""
from dataclasses import dataclass,field
from contextvars import ContextVar
from contextlib import contextmanager
from pathlib import Path
from datetime import datetime,timezone
from copy import deepcopy
import hashlib,json,secrets,time,threading

_SEAL=object();_CURRENT=ContextVar('reply_public_profile_read',default=None)
def digest(value):return hashlib.sha256(json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
def identity(account):return {k:account.get(k) for k in ('id','tenant_id','cloud_owner','store_id','platform','platform_uid','conn_id','auth_generation','identity_revalidation_generation')}
class ReplyReadError(ValueError):
 def __init__(self,code,message):super().__init__(message);self.code=code

@dataclass(eq=False)
class ReadRegistration:
 seal:object
 root:Path
 manifest:dict
 manifest_digest:str
 def check(self):
  m=self.manifest
  if self.seal is not _SEAL or digest(m)!=self.manifest_digest or m.get('version')!=1 or m.get('protocol')!='reply-profile-read-v1' or m.get('helperFlag')!='--owned-xhs-cli-pages' or not isinstance(m.get('sources'),dict) or not m['sources']:raise ReplyReadError('READ_MATERIAL_UNREVIEWED','公开资料读取组件尚未完成来源核验')
  items={m.get('executable'):m.get('executableSha256'),**m['sources']}
  if m.get('runtimeTree') is not None:
   if not isinstance(m['runtimeTree'],dict) or not m['runtimeTree']:raise ReplyReadError('READ_MATERIAL_UNREVIEWED','公开资料运行闭包未核验')
   items.update(m['runtimeTree'])
  for relative,expected in items.items():
   if not isinstance(relative,str) or Path(relative).is_absolute() or not isinstance(expected,str) or len(expected)!=64:raise ReplyReadError('READ_MATERIAL_INVALID','公开资料组件来源无效')
   file=(self.root/relative).resolve()
   if not file.is_relative_to(self.root) or not file.is_file():raise ReplyReadError('READ_MATERIAL_INVALID','公开资料组件路径无效')
   for part in (self.root/relative,*list((self.root/relative).parents)):
    if part.exists() and (part.is_symlink() or getattr(part.lstat(),'st_file_attributes',0)&0x400):raise ReplyReadError('READ_MATERIAL_INVALID','公开资料组件路径无法核验')
   if hashlib.sha256(file.read_bytes()).hexdigest()!=expected.lower():raise ReplyReadError('READ_MATERIAL_CHANGED','公开资料组件内容已变化，请更新后再操作')
  return self

def register_read(core,root,manifest):
 registration=ReadRegistration(_SEAL,Path(root).resolve(),deepcopy(manifest),digest(manifest));registration.check();core._reply_read_registration=registration;return registration

def current_read_decision(core):
 value=_CURRENT.get()
 if value is None:return None
 if type(value) is not ReplyReadClaim or value.seal is not _SEAL or value.owner.core is not core:raise ReplyReadError('READ_SCOPE_INVALID','公开资料读取用途不符')
 value.check_policy();return value

@contextmanager
def read_scope(value):
 if type(value) is not ReplyReadClaim or value.seal is not _SEAL:raise ReplyReadError('READ_SCOPE_INVALID','必须使用本次私有读取用途')
 value.check_policy();token=_CURRENT.set(value)
 try:yield value
 finally:_CURRENT.reset(token)

@dataclass(eq=False)
class ReplyReadClaim:
 seal:object
 owner:object
 executor:object
 session:object
 actor:dict
 account:dict
 home:Path
 job_id:str
 subject_uid:str
 purpose:str
 current_guard:object
 deadline:float
 device_id:str
 operations:tuple
 registration:object=None
 active:bool=True
 current_args:list|None=None
 index:int=0
 registration_scope:str=''
 thread:object=field(default_factory=threading.current_thread)
 def check_policy(self):
  runtime=self.owner
  if self.seal is not _SEAL or self.thread is not threading.current_thread() or not self.active or time.monotonic()>=self.deadline or runtime.closed:raise ReplyReadError('READ_AUTH_EXPIRED','本次读取授权已结束，请保留原操作结果')
  if type(self.registration) is not ReadRegistration or getattr(runtime.core,'_reply_read_registration',None) is not self.registration:raise ReplyReadError('READ_MATERIAL_UNREVIEWED','原公开资料读取注册已变化')
  self.registration.check();self.current_guard()
  if self.registration.root!=Path(runtime.project).resolve():raise ReplyReadError('READ_MATERIAL_ROOT_CHANGED','公开资料组件不属于当前固定项目')
  selected=runtime.core.adapters.manifest('xiaohongshu')
  expected_exe=(self.registration.root/self.registration.manifest['executable']).resolve()
  if Path(selected.get('executable','')).resolve()!=expected_exe or selected.get('isolation_guard') is not True or selected.get('prefix_args')!=['xiaohongshu']:raise ReplyReadError('READ_MATERIAL_ROUTE_CHANGED','公开资料读取没有选择已核验的独立组件')
  if not (runtime._customer_read_lease_current('xiaohongshu_guarded_read') or runtime._customer_read_lease_current('xiaohongshu_natural_read')):raise ReplyReadError('READ_REMOTE_LEASE_REQUIRED','远端公开内容读取许可已失效，请等待原设备连接恢复')
  config=getattr(runtime.core,'deployment_config',{}).get('runtime') or {}
  if runtime.core.remote_safety_hold or config.get('platform_qa_device_id'):raise ReplyReadError('READ_REMOTE_HELD','远端安全暂停或只读验收用途不允许本次操作')
  user=runtime._principal(self.actor)
  if any(user.get(k)!=self.actor.get(k) for k in ('id','tenant_id','username','role','_workbench_store_id')) or user.get('disabled') or user.get('can_reply') is False:raise ReplyReadError('READ_ACTOR_CHANGED','原员工权限或门店已变化')
  service=runtime.service
  if service.closed or service.state!='online' or service.executor is not self.executor or getattr(self.executor,'_xhs_app_session',None) is not self.session or (service.device or {}).get('id')!=self.device_id:raise ReplyReadError('READ_SESSION_CHANGED','原设备员工会话已变化，已停止读取')
  self.session.check()
  account=runtime._account(user,self.account['id'])
  if identity(account)!=self.account or account.get('status')!='ready' or account.get('requires_review') or account.get('identity_recovery_pending'):raise ReplyReadError('READ_ACCOUNT_CHANGED','账号身份或安全状态已变化，请核对后再操作')
  if self.home!=(runtime.core.store.directory/'accounts'/user['tenant_id']/account['id']).resolve():raise ReplyReadError('READ_SESSION_CHANGED','原独立会话路径已变化')
  if not runtime._device(user).get('bound'):raise ReplyReadError('READ_DEVICE_CHANGED','设备绑定已变化，读取已停止')
  runtime.core.adapters.require_account_safe('xiaohongshu',self.home)
  if self.index:
   entry=runtime.core.adapters.xhs_cli_page_tasks.get(self.job_id)
   if (not entry or entry.get('reply_profile') is not True or entry.get('scope')!=self.registration_scope or Path(entry.get('home','')).resolve()!=self.home or getattr(entry.get('guard'),'__self__',None) is not self):raise ReplyReadError('READ_SCOPE_CHANGED','原资料读取注册已结束，已停止后续请求')
  return self
 def check(self):
  self.check_policy();runtime=self.owner;user=runtime._principal(self.actor)
  if runtime._executor(user,read_purpose=self.purpose) is not self.executor:raise ReplyReadError('READ_DEVICE_CHANGED','设备员工会话已变化，已停止读取')
  code,message=runtime._readiness(user,runtime._account(user,self.account['id']),read_purpose=self.purpose)
  if code:raise ReplyReadError(str(code).upper(),message)
  runtime.server._platform_execution_guard('xiaohongshu')
 def check_adapter(self,adapters,platform,args,account_dir,job_id):
  self.check()
  if (adapters is not self.owner.core.adapters or platform!='xiaohongshu' or job_id!=self.job_id or Path(account_dir).resolve()!=self.home or args!=self.current_args or self.index<1 or self.index>len(self.operations) or tuple(args)!=self.operations[self.index-1]):raise ReplyReadError('READ_SCOPE_CHANGED','本次读取参数与原账号用途不一致')
 def enter(self,args):
  self.check()
  if self.index>=len(self.operations) or tuple(args)!=self.operations[self.index]:raise ReplyReadError('READ_BUDGET_EXCEEDED','本次只允许固定的一次资料读取')
  self.current_args=list(args);self.index+=1

def _unwrap(payload):
 for _ in range(4):
  if not isinstance(payload,dict) or payload.get('ok') is False or payload.get('error') is not None or payload.get('success') is False:raise ReplyReadError('PUBLIC_READ_REJECTED','平台原文未读取成功，请核对当前账号')
  if isinstance(payload.get('data'),dict):payload=payload['data']
  else:return payload
 raise ReplyReadError('PUBLIC_READ_INVALID','读取结果结构尚未核对，未保存资料')

def _actor_uid(payload,expected):
 data=_unwrap(payload);user=data.get('user',{});uid=user.get('id',user.get('user_id','')) if isinstance(user,dict) else ''
 if not isinstance(uid,str) or uid!=expected:raise ReplyReadError('READ_IDENTITY_MISMATCH','该独立会话实际登录身份与所选账号不一致，请登录该账号后重新核对')
 return uid

def run_registered_read(runtime,user,job,guard):
 """No login, cookie import, fallback route, sender or model exists here."""
 from core.adapters import account_execution_lock
 actor=runtime._principal(user);executor=runtime._executor(actor,online=False);account=runtime._account(actor,job['accountId'])
 if account.get('platform')!='xiaohongshu' or not account.get('platform_uid'):raise ReplyReadError('READ_IDENTITY_REQUIRED','请先连接并核对当前实际平台账号')
 home=(runtime.core.store.directory/'accounts'/actor['tenant_id']/account['id']).resolve()
 operations=[('whoami','--json','--phase','before')]
 if job['kind']=='profile':operations += [('user',job['subjectId'],'--json'),('user-posts',job['subjectId'],'--json','--max-items',str(job['limitPosts']))]
 operations += [('whoami','--json','--phase','after')]
 device=(runtime.service.device or {}).get('id','')
 claim=ReplyReadClaim(_SEAL,runtime,executor,getattr(executor,'_xhs_app_session',None),dict(actor),identity(account),home,job['id'],job.get('subjectId',''),'reply_public_profile' if job['kind']=='profile' else 'reply_session_check',guard,time.monotonic()+150,device,tuple(operations))
 claim.registration=getattr(runtime.core,'_reply_read_registration',None)
 adapters=runtime.core.adapters;owner='reply-read:'+job['id'];registered=False;released=False
 with read_scope(claim),account_execution_lock(home):
  claim.check()
  runtime.core.acquire_account_mode(account['id'],actor['tenant_id'],'collection',owner)
  try:
   claim.registration_scope=digest([job['scope'],identity(account),job['fingerprint']])
   adapters.begin_xhs_cli_pages(job['id'],home,claim.registration_scope,claim.check,reply_profile=True);registered=True
   received=[]
   for args in operations:
    claim.enter(list(args))
    payload=adapters.execute('xiaohongshu',list(args),home,job['id'],timeout=35,_reply_profile_call=claim)
    claim.check();received.append(_unwrap(payload))
    if args[0]=='whoami':_actor_uid(payload,account['platform_uid'])
   observed=datetime.now(timezone.utc).isoformat()
   output={'actorUid':account['platform_uid'],'identityProofDigest':digest([job['scope'],identity(account),received[0],received[-1],job['id']]),'observedAt':observed,
    'capability':{'identityVerified':True,'isolatedSession':True,'accountId':account['id'],'actorUid':account['platform_uid'],'expiresAt':datetime.fromtimestamp(time.time()+60,timezone.utc).isoformat(),'publicSendAllowed':False,'sessionSwitchAllowed':False}}
   if job['kind']=='profile':
    profile=received[1];posts=received[2]
    if profile.get('user_id')!=job['subjectId'] or not isinstance(profile.get('desc'),str) or len(profile['desc'])>4000 or not isinstance(posts.get('notes'),list) or len(posts['notes'])>job['limitPosts']:raise ReplyReadError('PUBLIC_SUBJECT_UNVERIFIED','公开原文作者身份未核对，未保存资料')
    output['profile']={'sourceUrl':'https://www.xiaohongshu.com/user/profile/'+job['subjectId'],'subjectId':job['subjectId'],'text':profile['desc'],'observedAt':observed}
    output['posts']=[]
    for item in posts['notes']:
     if item.get('user_id')!=job['subjectId'] or not isinstance(item.get('note_id'),str):raise ReplyReadError('PUBLIC_SUBJECT_UNVERIFIED','公开作品作者身份未核对，未保存资料')
     text='\n'.join(x for x in (item.get('title'),item.get('desc')) if isinstance(x,str) and x)
     if len(text)>7001:raise ReplyReadError('PUBLIC_TEXT_TOO_LARGE','公开原文超出保存范围')
     output['posts'].append({'id':item['note_id'],'sourceUrl':'https://www.xiaohongshu.com/explore/'+item['note_id'],'subjectId':job['subjectId'],'text':text,'observedAt':observed})
   claim.check();return output
  finally:
   try:
    if registered:adapters.end_xhs_cli_pages(job['id'])
    released=True
   finally:
    claim.active=False
    if released:runtime.core.release_account_mode(account['id'],actor['tenant_id'],owner)
