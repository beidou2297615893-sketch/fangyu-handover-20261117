"""Offline six-account integration: real Core/Store/ReplyWorkbench, injected draft provider."""
from pathlib import Path
import sys,os,tempfile,threading,time,unittest,socket,subprocess
from types import SimpleNamespace
from unittest.mock import patch
from copy import deepcopy
import argparse
parser=argparse.ArgumentParser(add_help=False);parser.add_argument('--project');parser.add_argument('--release');parser.add_argument('--candidate');cli,remaining=parser.parse_known_args();sys.argv=[sys.argv[0],*remaining]
if cli.project:os.environ['MULTI_REPLY_PROJECT']=cli.project
if cli.release:os.environ['MULTI_REPLY_RELEASE']=cli.release
if cli.candidate:os.environ['MULTI_REPLY_CANDIDATE']=cli.candidate
TASK=Path(__file__).resolve().parents[2]
PROJECT=Path(os.environ.get('MULTI_REPLY_PROJECT',str(TASK.parent/'reply-complete-20261026/assembly/project')))
RELEASE=Path(os.environ.get('MULTI_REPLY_RELEASE',str(PROJECT/'work/ui-native-r57/releases/ui-r57-20261026T101643Z-fa72ab42')))
CANDIDATE=Path(os.environ.get('MULTI_REPLY_CANDIDATE',str(TASK/'candidate')))
sys.path[:0]=[str(CANDIDATE),str(RELEASE),str(PROJECT/'work/ui-runtime-r55/src')]
from core.engine import Core
from core.store import Store
from core.contact_journal import ContactJournal
from reply_workbench import ReplyWorkbench,digest,ROUTING
from reply_account_profiles import AccountProfiles,ProfileError,ASSIGNMENTS,PROFILES,explicit_topics
from reply_ai_workflow import Workflow,ENTITY
from reply_ai_provider import provider_prompt,create_provider,legacy_provider_prompt
from reply_official_codex import ReplyOfficialCodexAdapter

class Customers:
 def __init__(self,core):self.core=core
 def platform_filter(self,data):return data.get('platform')
 def detail_context(self,user,store,customer,platform=None):
  if store!='s' or customer not in ('c','alias'):raise ValueError('scope')
  lead=self.core.store.get('leads','l')
  return user,{},dict(name='合成客户',platform='xiaohongshu',rank=2,contactState='none'),dict(comments=[dict(lead_id='l',text=lead['text'])])
 def detail(self,*a,**k):return self.detail_context(*a,**k)
 def _media_url(self,*a):return ''

class MultiTests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory(dir=TASK/'tests/backend');self.addCleanup(self.tmp.cleanup)
  self.net=patch.object(socket.socket,'connect',side_effect=AssertionError('network prohibited'));self.net.start();self.addCleanup(self.net.stop)
  self.proc=patch.object(subprocess,'Popen',side_effect=AssertionError('process prohibited'));self.proc.start();self.addCleanup(self.proc.stop)
  self.store=Store(self.tmp.name);self.user=dict(id='u',username='owner',tenant_id='t',role='operator',cloud_bound=True)
  self.store.put('users',self.user)
  self.core=Core.__new__(Core);self.core.store=self.store;self.core.lock=threading.RLock();self.core.contact_journal=ContactJournal(self.store)
  self.core.handle=lambda action,data,user:self.core._reply(action,data,user,'t')
  for n in 'ABCDEF':self.store.put('accounts',dict(id=n,tenant_id='t',cloud_owner='owner',store_id='s',platform='xiaohongshu',platform_uid='uid'+n,name='合成'+n))
  self.lead=dict(id='l',tenant_id='t',cloud_owner='owner',platform='xiaohongshu',source_type='comment',comment_id='comment',author_id='customer-uid',author='合成客户',note_url='https://www.xiaohongshu.com/explore/note',text='带猫找一室，预算2000',comment_level=1)
  self.store.put('leads',self.lead)
  self.b=SimpleNamespace(lock=threading.RLock(),closed=False,core=self.core,_identity=lambda token:(self.user,{'can_reply':True}),_selected_store=lambda *a:'s',_analysis_local_identity=lambda token:(self.user,{}),_voice_samples_dispatch=lambda *a,**k:{'voiceSamples':{'items':[]}})
  self.b._tone_preferences=lambda *a,**k:{'preferences':dict(revision=1,tone='friendly',salutation='',focus=[],templates={'customer':''})}
  self.b.reply_workbench=ReplyWorkbench(self.core,Customers(self.core))
  def dispatch(action,data,token):return {'replyWorkspace':self.b.reply_workbench.execute(action,self.user,'s',data)}
  self.b._dispatch=dispatch;self.service=AccountProfiles(self.b);self.b.reply_workbench.account_profiles=self.service
  self.base={'storeId':'s','platform':'xiaohongshu'};self.seq=0;self.calls=[]
  for n in 'ABCDEF':self.save_profile(n,['pet'] if n=='B' else ['commute'])
  self.assign('B')
 def req(self):self.seq+=1;return 'request'+str(self.seq)
 def save_profile(self,account,topics=None):
  profile=self.service.profile(['t','u','owner','s','xiaohongshu'],account)
  return self.service.dispatch('reply_account_profile_save',{**self.base,'accountId':account,'expectedRevision':profile['revision'],'requestId':self.req(),'profile':dict(displayName='合成'+account,roleFacts='本人提供的租房交流账号，不声明住户经历',tone='简短自然'+str(self.seq),topics=topics or profile['topics'],confirmed=True)},'token')
 def assign(self,account,customer='c'):
  user,scope=self.service.scope('token',self.base);self.service.customer(user,scope,customer);a=self.service.assignment(scope,customer);p=self.service.profile(scope,account);e=self.service.evidence(scope,customer)
  return self.service.dispatch('reply_assignment_save',{**self.base,'customerId':customer,'accountId':account,'expectedRevision':a['revision'],'expectedProfileRevision':p['revision'],'expectedEvidenceRevision':e['revision'],'requestId':self.req()},'token')
 def generate(self):
  def provider(packet,tone,refs):
   self.calls.append(deepcopy(tone));return dict(relationship='客户明确询问租房',need='带猫租一室',fit='待核实',reason='明确宠物需求',reply='可以看看方隅，宠物政策请以门店确认为准。',unknown=['宠物政策未核实'],shouldReply=True)
  self.w=Workflow(self.b,provider);self.args={**self.base,'accountId':'B','customerIds':['c'],'tone':'','requestId':self.req()}
  j=self.w.dispatch('reply_ai_start',self.args,'token')['replyAI']
  for _ in range(200):
   if j['id'] not in self.w.running:break
   time.sleep(.005)
  self.job=self.w.dispatch('reply_ai_status',{**self.args,'jobId':j['id']},'token')['replyAI'];self.assertEqual(self.job['rows'][0]['status'],'ready')
  return self.job
 def confirm(self):
  r=self.job['rows'][0]
  return self.w.dispatch('reply_ai_confirm',{**self.args,'jobId':self.job['id'],'leadId':'l','confirmationKey':r['confirmationKey'],'confirmed':True},'token')['replyAI']
 def test_six_accounts_pet_recommends_B_and_workflow_confirms_without_send(self):
  preview=self.service.dispatch('reply_route_preview',{**self.base,'customerIds':['c']},'token')['replyAccounts']
  self.assertEqual(len(preview['accounts']),6);self.assertEqual(preview['routes'][0]['recommendedAccountId'],'B');self.assertEqual(preview['groups'],[{'accountId':'B','customerIds':['c']}])
  self.generate();self.assertEqual(self.calls[0]['accountProfile']['profile']['displayName'],'合成B')
  result=self.confirm();self.assertEqual(result['rows'][0]['confirmation']['state'],'confirmed')
  self.assertEqual(self.store.list('replies','t')[0]['review_account_id'],'B');self.assertEqual(self.store.list('reply_queues','t'),[])
 def test_profile_change_invalidates_confirmation(self):
  self.generate();self.save_profile('B')
  with self.assertRaises(ValueError):self.confirm()
  self.assertEqual(self.store.list('replies','t'),[])
 def test_assignment_change_invalidates_confirmation(self):
  self.generate();self.assign('A')
  with self.assertRaises(ValueError):self.confirm()
  self.assertEqual(self.store.list('replies','t'),[])
 def test_manual_evidence_change_invalidates_confirmation(self):
  self.generate();self.service.dispatch('reply_evidence_save',{**self.base,'customerId':'c','expectedRevision':0,'requestId':self.req(),'items':[dict(sourceUrl='https://www.xiaohongshu.com/user/profile/customer-uid',observedAt='2026-10-26T12:00:00+08:00',quote='希望英文沟通租房',subjectId='customer-uid')]},'token')
  with self.assertRaises(ValueError):self.confirm()
 def test_original_review_entry_rechecks_persisted_binding(self):
  self.generate();self.confirm();draft=self.store.list('replies','t')[0]
  # Original editor creates a new version, retaining account binding.
  saved=self.b.reply_workbench.execute('reply_save',self.user,'s',{**self.base,'customerId':'c','leadId':'l','sourceDigest':digest(self.lead),'expectedVersion':draft['version'],'expectedReplyId':draft['id'],'text':'新的人工编辑，仍不编身份','requestId':self.req()})
  new=saved['comments'][0]['draft'];self.assertGreater(new['version'],draft['version']);self.save_profile('B')
  with self.assertRaises(ValueError):self.b.reply_workbench.execute('reply_review',self.user,'s',{**self.base,'customerId':'c','leadId':'l','sourceDigest':digest(self.lead),'expectedVersion':new['version'],'expectedReplyId':new['id'],'accountId':'B','confirmed':True,'requestId':self.req()})
  self.assertEqual(self.store.get('replies',new['id'])['status'],'draft')
 def test_alias_and_other_actor_use_one_canonical_assignment(self):
  self.assign('A','alias');u,s=self.service.scope('token',self.base);self.service.customer(u,s,'c');self.assertEqual(self.service.assignment(s,'c')['accountId'],'A')
  s2=[s[0],'other-actor',s[2],s[3],s[4]];self.assertEqual(self.service.key(s,'assignment','c'),self.service.key(s2,'assignment','alias'))
 def test_ties_require_manual_choice(self):
  self.save_profile('A',['pet']);r=self.service.dispatch('reply_route_preview',{**self.base,'customerIds':['c']},'token')['replyAccounts']['routes'][0]
  self.assertTrue(r['needsManualChoice']);self.assertEqual(r['recommendedAccountId'],'')
 def test_profile_CAS_and_receipt_replay(self):
  request={**self.base,'accountId':'B','expectedRevision':1,'requestId':self.req(),'profile':dict(displayName='B',roleFacts='真实资料',tone='自然',topics=['pet'],confirmed=True)}
  first=self.service.dispatch('reply_account_profile_save',request,'token');second=self.service.dispatch('reply_account_profile_save',request,'token')
  self.assertEqual(first['mutationReceipt']['revision'],second['mutationReceipt']['revision']);self.assertTrue(second['mutationReceipt']['replayed'])
  with self.assertRaises(ValueError):self.service.dispatch('reply_account_profile_save',{**request,'requestId':self.req()},'token')
 def test_spoofed_subject_and_unsafe_source_rejected(self):
  for subject,url in [('wrong','https://www.xiaohongshu.com/explore/note'),('customer-uid','https://evil.test/user/a')]:
   with self.assertRaises(ValueError):self.service.dispatch('reply_evidence_save',{**self.base,'customerId':'c','expectedRevision':0,'requestId':self.req(),'items':[dict(subjectId=subject,sourceUrl=url,observedAt='2026-10-26T12:00:00+08:00',quote='可以养猫吗')]},'token')
 def test_actual_official_adapter_prompt_uses_account_contract(self):
  self.generate();raw=self.store.get(ENTITY,self.job['id']);scope=raw['scope'];request=self.w.execution_request(raw,raw['rows'][0],self.user,scope)
  adapter=create_provider(self.store)
  prompt=adapter.build_prompt(request)
  self.assertNotIn('回复者只是真实住户，不是客服中介',prompt)
  self.assertIn('当accountProfile存在时，旧版身份和主观体验全部不适用',prompt);self.assertIn('profile.tone是当前账号已确认的措辞',prompt);self.assertIn('合成B',prompt)
 def reopen(self):
  draft=max(self.store.list('replies','t'),key=lambda x:x['version'])
  old=self.store.get('replies',draft['id'])
  data={**self.args,'requestId':self.req(),'reopenDraft':dict(customerId='c',leadId='l',expectedReplyId=draft['id'],expectedVersion=draft['version'],sourceDigest=digest(self.lead))}
  j=self.w.dispatch('reply_ai_start',data,'token')['replyAI']
  for _ in range(200):
   if j['id'] not in self.w.running:break
   time.sleep(.005)
  self.args=data;self.job=self.w.dispatch('reply_ai_status',{**data,'jobId':j['id']},'token')['replyAI']
  self.assertEqual(self.job['rows'][0]['status'],'ready');self.assertEqual(self.store.get('replies',draft['id']),old)
 def test_explicit_reopen_keeps_old_until_new_confirmation(self):
  self.generate();self.confirm();old=self.store.list('replies','t')[0];self.save_profile('B');self.assign('B');self.reopen()
  self.assertEqual(len(self.store.list('replies','t')),1)
  result=self.confirm();self.assertEqual(result['rows'][0]['confirmation']['state'],'confirmed')
  rows=self.store.list('replies','t');self.assertEqual(len(rows),2);self.assertEqual(self.store.get('replies',old['id'])['text'],old['text'])
 def test_plain_start_never_overwrites_formal_draft(self):
  self.generate();self.confirm();before=self.store.list('replies','t')
  with self.assertRaises(ValueError):self.w.dispatch('reply_ai_start',{**self.args,'requestId':self.req()},'token')
  self.assertEqual(self.store.list('replies','t'),before)
 def test_profile_change_old_request_not_adopted(self):
  self.generate();self.save_profile('B');self.assign('B')
  with self.assertRaises(ValueError):self.w.dispatch('reply_ai_start',self.args,'token')
  self.assertEqual(len(self.calls),1)
 def test_same_account_id_rebound_uid_requires_reconfirmation(self):
  account=self.store.get('accounts','B');account['platform_uid']='different-uid';self.store.put('accounts',account)
  with self.assertRaises(ValueError):self.generate()
 def test_assignment_can_be_explicitly_cleared(self):
  self.service.dispatch('reply_assignment_save',{**self.base,'customerId':'c','accountId':'','expectedRevision':1,'expectedProfileRevision':0,'expectedEvidenceRevision':0,'requestId':self.req()},'token')
  result=self.service.dispatch('reply_route_preview',{**self.base,'customerIds':['c']},'token')['replyAccounts'];self.assertEqual(result['groups'],[])
 def test_pending_routing_after_committed_save_recovers_from_original_check(self):
  self.generate();original=self.store.put;broken=[False]
  def lose(entity,row):
   if entity==ROUTING and row.get('state')=='ready' and not broken[0]:broken[0]=True;raise OSError('interrupted before ready binding')
   return original(entity,row)
  with patch.object(self.store,'put',side_effect=lose):result=self.confirm()
  self.assertEqual(result['rows'][0]['confirmation']['state'],'save_pending')
  self.job=self.w.dispatch('reply_ai_reconcile',{**self.args,'jobId':self.job['id']},'token')['replyAI']
  self.assertEqual(self.job['rows'][0]['confirmation']['state'],'saved');self.assertEqual(self.confirm()['rows'][0]['confirmation']['state'],'confirmed')
 def test_two_independent_receivers_do_not_both_replace_same_version(self):
  self.generate();self.confirm();draft=self.store.list('replies','t')[0]
  store2=Store(self.tmp.name);core2=Core.__new__(Core);core2.store=store2;core2.lock=threading.RLock();core2.contact_journal=ContactJournal(store2)
  core2.handle=lambda action,data,user:core2._reply(action,data,user,'t')
  b2=SimpleNamespace(**vars(self.b));b2.core=core2;b2.lock=threading.RLock();b2.reply_workbench=ReplyWorkbench(core2,Customers(core2));b2.reply_workbench.account_profiles=AccountProfiles(b2)
  barrier=threading.Barrier(2);out=[]
  def execute(receiver,label):
   original=receiver._routing
   def synchronized(*a,**k):
    result=original(*a,**k);barrier.wait(timeout=3);return result
   receiver._routing=synchronized
   payload={**self.base,'customerId':'c','leadId':'l','sourceDigest':digest(self.lead),'expectedVersion':draft['version'],'expectedReplyId':draft['id'],'text':'并发人工编辑'+label,'requestId':'parallel'+label}
   try:out.append(('ok',receiver.execute('reply_save',self.user,'s',payload)))
   except ValueError:out.append(('blocked',None))
  threads=[threading.Thread(target=execute,args=(receiver,label)) for receiver,label in [(self.b.reply_workbench,'one'),(b2.reply_workbench,'two')]]
  for t in threads:t.start()
  for t in threads:t.join(5)
  self.assertFalse(any(t.is_alive() for t in threads));self.assertEqual([x[0] for x in out].count('ok'),1);self.assertEqual(len(self.store.list('replies','t')),2)
 def rejected_rebase_restores_prior(self,uncertain,target):
  self.generate();self.confirm();draft=self.store.list('replies','t')[0]
  prior=self.b.reply_workbench.routing_binding(self.user,'s','xiaohongshu','l')
  self.save_profile('B');self.assign(target)
  request={**self.base,'customerId':'c','leadId':'l','sourceDigest':digest(self.lead),'expectedVersion':draft['version'],'expectedReplyId':draft['id'],'text':'这是新资料下拟保存的新正文','requestId':self.req()}
  error=OSError('interrupted before Core') if uncertain else ValueError('definite refusal before Core')
  with patch.object(self.core,'handle',side_effect=error),self.assertRaises(ValueError):self.b.reply_workbench.execute('reply_save',self.user,'s',request)
  if uncertain:
   pending=self.b.reply_workbench.routing_binding(self.user,'s','xiaohongshu','l');self.assertEqual(pending['state'],'pending');self.assertEqual(pending['priorBinding'],prior)
   self.b.reply_workbench.execute('reply_check',self.user,'s',{**self.base,'customerId':'c','leadId':'l','requestId':request['requestId']})
  restored=self.b.reply_workbench.routing_binding(self.user,'s','xiaohongshu','l')
  self.assertEqual(restored,prior);self.assertEqual(self.store.get('replies',draft['id']),draft)
  self.assertFalse(self.b.reply_workbench.read(self.user,'s','c',platform='xiaohongshu')['comments'][0]['reviewCurrent'])
  with self.assertRaises(ValueError):self.b.reply_workbench.validate_routing(self.user,'s','c','l',draft)
 def test_definitely_refused_same_account_rebase_restores_original_binding(self):self.rejected_rebase_restores_prior(False,'B')
 def test_unsubmitted_same_account_rebase_check_restores_original_binding(self):self.rejected_rebase_restores_prior(True,'B')
 def test_definitely_refused_account_change_restores_original_binding(self):self.rejected_rebase_restores_prior(False,'A')
 def test_unsubmitted_account_change_check_restores_original_binding(self):self.rejected_rebase_restores_prior(True,'A')
 def test_assigned_customer_cannot_downgrade_to_unconfigured_account(self):
  self.assign('A');scope=['t','u','owner','s','xiaohongshu'];self.store.delete(PROFILES,self.service.key(scope,'profile','B'))
  calls=[];workflow=Workflow(self.b,lambda *a:calls.append(1))
  with self.assertRaises(ValueError):workflow.dispatch('reply_ai_start',{**self.base,'accountId':'B','customerIds':['c'],'tone':'','requestId':self.req()},'token')
  self.assertEqual(calls,[]);self.assertEqual(self.store.list('replies','t'),[])
 def test_legacy_contract_is_byte_identical_to_frozen_baseline(self):
  import importlib.util
  spec=importlib.util.spec_from_file_location('frozen_legacy_reply_provider',RELEASE/'reply_ai_provider.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
  # A final integrated release may already contain the new selector; source baseline
  # remains the fa72 exact frozen prompt for this independent digest comparison.
  frozen=Path(__file__).resolve().parents[3]/'reply-complete-20261026/assembly/project/work/ui-native-r57/releases/ui-r57-20261026T101643Z-fa72ab42/reply_ai_provider.py'
  spec=importlib.util.spec_from_file_location('fa72_provider',frozen);old=importlib.util.module_from_spec(spec);spec.loader.exec_module(old)
  self.assertEqual(legacy_provider_prompt(),old.provider_prompt())
  factory=create_provider(self.store);legacy=ReplyOfficialCodexAdapter(self.store.path,self.store.directory/'reply-codex-receipts',contract_prompt=old.provider_prompt(),output_validator=old.validate_output)
  self.assertEqual(factory.legacy.contract_digest,legacy.contract_digest)
 def test_explicit_needs_no_demographic_inference(self):
  cases={'带猫找一室，预算2000':{'pet','space','budget'},'我有一只猫，想租附近的房':{'pet'},'要地铁附近，预算两千':{'commute','budget'},'可以用 English 沟通吗':{'language'}}
  for text,expected in cases.items():self.assertTrue(expected.issubset(explicit_topics(text)),text)
  self.assertNotIn('pet',explicit_topics('我不养猫，也不考虑宠物房，想租一室'));self.assertIn('pet',explicit_topics('能不能养猫'))
  for text in ['不需要英文沟通服务','喜欢猫猫','头像有猫','我是外国女生，IP上海，年龄25','今天晒猫，好可爱']:self.assertEqual(explicit_topics(text),[],text)
if __name__=='__main__':unittest.main(verbosity=2)
