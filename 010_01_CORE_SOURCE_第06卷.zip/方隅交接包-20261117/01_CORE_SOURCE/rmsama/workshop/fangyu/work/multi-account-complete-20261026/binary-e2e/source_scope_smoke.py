"""Source fake only: no child executable, no platform requests."""
import importlib.util,sys,time,json
from pathlib import Path
HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('source_scope_fixture',HERE.parent/'tests/backend/test_public_read.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
t=m.PublicReadTests('test_real_app_and_core_guards_keep_three_holds_but_allow_exact_read_scope');t.setUp()
try:
 t.install_real_runtime_gates();t.install_real_app_guard()
 try:t.runtime.server._platform_execution_guard('xiaohongshu')
 except ValueError:pass
 else:raise AssertionError('Unscoped platform guard unexpectedly allowed')
 original=dict(t.runtime.server.company);started=time.monotonic();v=t.start();initial=v['state'];deadline=started+25
 while v['state']=='running' and time.monotonic()<deadline:
  time.sleep(.05);v=t.reader.dispatch('reply_read_status',{**t.f.base,'jobId':t.jobid},'token')['replyPublicRead']
 assert v['state']=='completed',v
 assert t.runtime.server.company==original
 assert [call[0] for call in t.calls]==['whoami','user','user-posts','whoami'],t.calls
 try:t.runtime.server._platform_execution_guard('xiaohongshu')
 except ValueError:pass
 else:raise AssertionError('Scope leaked after registered read')
 result={'status':'PASS','sourceFakeOnly':True,'compiledChildExecuted':False,'externalRequests':0,'initialStateAfterLegacyWait':initial,'elapsedSeconds':round(time.monotonic()-started,3),'operations':[c[0] for c in t.calls],'holdsPreserved':True,'scopeDidNotLeak':True}
 (HERE/'SOURCE-SCOPE-SMOKE.json').write_text(json.dumps(result,indent=2),'utf-8');print(json.dumps(result))
finally:
 if getattr(t,'jobid',None) not in t.reader.controls:t.doCleanups()
