"""Recover metadata from a completed immutable stage after stdout decoding failed."""
from pathlib import Path
import hashlib,json,sys
sys.dont_write_bytecode=True
T=Path(__file__).resolve().parent;P=T.parents[1];PROJECT=T/'assembly/project'
read=lambda p:json.loads(p.read_text('utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8') as f:json.dump(v,f,ensure_ascii=False,indent=2);f.write('\n')
def main():
    assert sys.argv[1:]==['--recover-completed-stage']
    assert not (T/'FROZEN-PINS.json').exists() and not (T/'assembly/STAGED.json').exists() and not (T/'assembly/UNIFIED-PINS.json').exists()
    for n,h in read(T/'BASELINE.json')['canonical'].items():assert sha(P/'work/ui-native-r57'/n)==h
    base=read(T/'assembly/BASE-COPY.complete.json');changes=read(T/'assembly/CHANGES.final.json')['files']
    expected={**base['files'],**{n:r['after'] for n,r in changes.items()}}
    for n,h in expected.items():assert sha(PROJECT/n)==h,n
    for n,h in base['files'].items():assert sha(Path(base['source'])/n)==h,n
    for n,r in changes.items():assert sha(Path(r['candidatePath']))==r['after'],n
    native=PROJECT/'work/ui-native-r57';candidates=list((native/'candidates').glob('*.json'))
    assert len(candidates)==1
    stage=read(candidates[0]);assert stage['status']=='STAGED'
    assert stage['release_id']=='ui-r57-20261027T005628Z-067cb696'
    release=Path(stage['release']);launcher=Path(stage['launcher'])
    assert release==native/'releases'/stage['release_id']
    assert launcher.parent==native and sha(launcher)==stage['launcher_sha256'].lower()
    assert sha(release/'RELEASE.json')==stage['manifest_sha256'].lower()
    manifest=read(release/'RELEASE.json')
    assert manifest['release_id']==stage['release_id']
    declared={row['path']:row for row in manifest['files']}
    actual={p.relative_to(release).as_posix() for p in release.rglob('*') if p.is_file()}
    assert actual==set(declared)|{'RELEASE.json'}
    for n,r in declared.items():assert (release/n).stat().st_size==r['size'] and sha(release/n)==r['sha256'].lower(),n
    allowed=set(expected)|{launcher.relative_to(PROJECT).as_posix(),candidates[0].relative_to(PROJECT).as_posix()}
    allowed|={(release/n).relative_to(PROJECT).as_posix() for n in actual}
    assert {p.relative_to(PROJECT).as_posix() for p in PROJECT.rglob('*') if p.is_file()}==allowed,'Unexpected staged closure files'
    write(T/'assembly/STAGED.json',stage)
    files=[dict(path=p.relative_to(PROJECT).as_posix(),bytes=p.stat().st_size,sha256=sha(p)) for p in sorted(PROJECT.rglob('*')) if p.is_file()]
    write(T/'assembly/UNIFIED-PINS.json',dict(schema='fangyu-inactive-customer-closure-v1',root='project',files=files,release=stage,production_data_access=False,promoted=False))
    pins=dict(status='STAGED_NOT_INSTALLED',project=str(PROJECT),release=str(release),releaseId=stage['release_id'],manifestSha256=sha(release/'RELEASE.json'),stagedSha256=sha(T/'assembly/STAGED.json'),launcherPath=str(launcher),launcherSha256=sha(launcher),unifiedPinsSha256=sha(T/'assembly/UNIFIED-PINS.json'),changesSha256=sha(T/'assembly/CHANGES.final.json'),installed=False,automaticSendingEnabled=False,productionWrites=0)
    write(T/'FROZEN-PINS.json',pins)
    print(json.dumps(dict(status='EXISTING_STAGE_METADATA_RECOVERED',releaseId=pins['releaseId'],closureFiles=len(files),sourceEdited=False,refrozen=False,canonicalEdited=False)))
if __name__=='__main__':main()
