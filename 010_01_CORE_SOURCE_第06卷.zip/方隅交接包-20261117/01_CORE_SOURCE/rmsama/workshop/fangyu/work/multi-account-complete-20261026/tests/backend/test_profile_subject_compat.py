from pathlib import Path
import sys,importlib.util,json,unittest,io
T=Path(__file__).resolve().parents[2]
import argparse
parser=argparse.ArgumentParser(add_help=False)
parser.add_argument('--runtime',type=Path)
parser.add_argument('--parent-path',type=Path)
parser.add_argument('--worker-path',type=Path)
cli,remaining=parser.parse_known_args();sys.argv=[sys.argv[0],*remaining]
runtime=cli.runtime or T/'component-v3/inputs-source'
sys.path[:0]=[str(runtime)]
import core,core.acquisition_extension.contracts,core.acquisition_extension.guarded_port
for module in (core,core.acquisition_extension.contracts,core.acquisition_extension.guarded_port):
 assert Path(module.__file__).resolve().is_relative_to(runtime.resolve()),'Contract dependency escaped requested runtime'
path=cli.worker_path or T/'candidate/worker/assistant/xhs_cli_page_worker.py'
parent_path=cli.parent_path or T/'candidate/runtime/assistant/reply_read_session.py'
assert path.is_file() and parent_path.is_file() and (runtime/'core/__init__.py').is_file()
if cli.runtime:
 assert (runtime/'core/acquisition_extension/contracts.py').is_file()
 assert (runtime/'core/acquisition_extension/guarded_port.py').is_file()
def load(name,p):
 spec=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m);return m
w=load('compat_worker',path);parent=load('compat_parent',parent_path)
class Compat(unittest.TestCase):
 def project(self,data,binding=None):return json.loads(w.project_reply_read(['user','target','--json'],json.dumps({'data':data}),binding))['data']
 def wire(self,query='target_user_id=target',allow=True):
  args=['user','target','--json'];nonce='1'*64;scope='2'*64
  class Stream:
   def __init__(self):self.queue=[{'type':'hello','version':1,'nonce':nonce,'scope':scope,'task':'job','account':'account'},{'type':'page','nonce':nonce,'page':w.page_key(args),'args':args}];self.results=[]
   def readline(self,*a):return json.dumps(self.queue.pop(0))+'\n'
   def write(self,line):
    p=json.loads(line)
    if p['type']=='wire_ready':self.queue.append({'type':'wire_allow' if allow else 'deny','nonce':nonce,'page':p['page'],'wire':p['wire']})
    elif p['type']=='result':self.results.append(p);self.queue.extend([{'type':'ack','nonce':nonce,'page':p['page'],'digest':p['digest']},{'type':'close','nonce':nonce}])
   def flush(self):pass
  stream=Stream()
  def setup(gate):
   def run(args):
    gate('GET','https://edith.xiaohongshu.com/api/sns/web/v1/user/otherinfo?'+query)
    return w.project_reply_read(args,json.dumps({'data':{'basic_info':{'desc':'找房','red_id':'not-a-uid'}}}),gate.profile_binding()),'',0
   return run
  self.assertEqual(w.serve(stream,stream,setup=setup),0)
  return json.loads(stream.results[0]['stdout'])['data']
 def test_matching_explicit_uid(self):self.assertEqual(self.project({'user_id':'target','desc':'找房'}),{'user_id':'target','subjectId':'target','identitySource':'response_uid','desc':'找房'})
 def test_exact_wire_missing_uid(self):self.assertEqual(self.wire(),{'subjectId':'target','identitySource':'request_bound_subject','desc':'找房'})
 def test_missing_uid_no_wire(self):
  with self.assertRaises(ValueError):self.project({'desc':'找房'})
 def test_wrong_query_or_denied_parent(self):
  with self.assertRaises(ValueError):self.wire(query='target_user_id=other')
  with self.assertRaises(ValueError):self.wire(allow=False)
 def test_conflicting_or_malformed_explicit_uid(self):
  for data in ({'user_id':'other'},{'user_id':'target','basic_info':{'userid':'other'}},{'user_id':42},{'user_id':[]},{'user_id':False}):
   with self.subTest(data=data),self.assertRaises(ValueError):self.project(data)
 def test_whoami_still_requires_uid(self):
  with self.assertRaises(ValueError):w.project_reply_read(['whoami','--json'],json.dumps({'data':{'user':{'nickname':'a'}}}))
 def test_parent_exact_shapes(self):
  for data in ({'subjectId':'target','identitySource':'request_bound_subject','desc':'text'},{'subjectId':'target','identitySource':'response_uid','user_id':'target','desc':'text'}):self.assertTrue(parent.valid_profile_subject(data,'target'))
  for data in ({'subjectId':'target','identitySource':'forged','desc':'text'},{'subjectId':'other','identitySource':'request_bound_subject','desc':'text'},{'subjectId':'target','identitySource':'request_bound_subject','user_id':'target','desc':'text'},{'subjectId':'target','identitySource':'response_uid','desc':'text'},{'user_id':'target','desc':'legacy'}):self.assertFalse(parent.valid_profile_subject(data,'target'))
if __name__=='__main__':unittest.main()

