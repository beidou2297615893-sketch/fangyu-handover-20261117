"""Export current frozen workflow's synthetic frontend transport contract."""
import argparse,hashlib,importlib.util,json,socket,sys
from pathlib import Path

parser=argparse.ArgumentParser()
parser.add_argument('--project',type=Path,required=True)
parser.add_argument('--release',type=Path,required=True)
parser.add_argument('--contract',type=Path,required=True)
args=parser.parse_args()
socket.socket.connect=lambda *a,**k:(_ for _ in ()).throw(AssertionError('network forbidden'))
sys.path.insert(0,str(args.release))
sys.argv=[__file__,'--project',str(args.project)]
spec=importlib.util.spec_from_file_location('current_synthetic_tone_contract',Path(__file__).with_name('test_tone_integration.py'))
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
for name in ('reply_ai_workflow','reply_ai_provider'):
    loaded=Path(sys.modules[name].__file__)
    assert loaded.read_bytes()==(args.release/loaded.name).read_bytes(),name
fixture=module.ToneTests('test_read_uses_saved_store_preferences_without_employee_sop')
fixture.setUp()
read=fixture.w.dispatch('reply_ai_read',fixture.data,'token')['replyAI']
styles={}
try:
    for style in ('store','friendly','concise','patient'):
        fixture.data.update(styleMode=style,requestId='synthetic-contract-'+style)
        styles[style]=fixture.finish(fixture.start())
finally:fixture.release.set();fixture.doCleanups()
assert len(fixture.calls)==4
assert not fixture.store.list('replies','t')
args.contract.parent.mkdir(parents=True,exist_ok=True)
args.contract.write_text(json.dumps({'replyAI':read,'jobStyle':styles['store'],'styles':styles},ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'passed':True,'fakeCalls':4,'realModelCalls':0,'contract':str(args.contract),'sha256':hashlib.sha256(args.contract.read_bytes()).hexdigest()}))
