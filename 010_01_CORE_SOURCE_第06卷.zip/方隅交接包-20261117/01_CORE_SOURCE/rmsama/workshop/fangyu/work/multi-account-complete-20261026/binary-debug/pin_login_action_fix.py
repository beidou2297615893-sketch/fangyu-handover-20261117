from pathlib import Path
import json,hashlib
T=Path(__file__).resolve().parent.parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
p=T/'frontend/CHANGES.json';v=json.loads(p.read_text('utf-8-sig'));v['files']['web/pages/reply-public-read.mjs']=sha(T/'candidate/web/pages/reply-public-read.mjs');v.setdefault('features',[]).append('group login uses original connectAccount(xiaohongshu, exact group account), then user returns to recheck; no automatic switching/read/send');v.setdefault('tests',[]).append('tests/test_session_login_dom.mjs');p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n','utf-8')
p=T/'FINAL-CANDIDATE-PINS.json';v=json.loads(p.read_text('utf-8-sig'))
for f in (T/'candidate').rglob('*'):
 if f.is_file() and '__pycache__' not in f.parts and f.suffix!='.pyc':v['files'][f.relative_to(T).as_posix()]={'sha256':sha(f),'size':f.stat().st_size}
v['count']=len(v['files']);p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n','utf-8')
print(json.dumps({'sourceSha256':sha(T/'candidate/web/pages/reply-public-read.mjs'),'testSha256':sha(T/'tests/test_session_login_dom.mjs'),'frontendChangesSha256':sha(T/'frontend/CHANGES.json')}))
