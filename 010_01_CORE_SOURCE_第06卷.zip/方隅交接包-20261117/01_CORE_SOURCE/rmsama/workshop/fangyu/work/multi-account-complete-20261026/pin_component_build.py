from pathlib import Path
import hashlib,json
T=Path(__file__).resolve().parent;C=T/'component'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest().upper()
report=T/'review/COMPONENT-BUILD-REVIEW.md'
body=report.read_text('utf-8')
assert 'STATIC_APPROVED_FOR_ISOLATED_COMPONENT_BUILD' in body
assert sha(C/'INPUTS.json') in body and sha(C/'build_inactive_component.py') in body
value={'schema':'inactive_cli_build_review_pins_v1','inputs_sha256':sha(C/'INPUTS.json'),'script_sha256':sha(C/'build_inactive_component.py'),'tool_entry_sha256':sha(C/'build_tool_entry.py'),'child_entry_sha256':sha(C/'build_child_entry.py'),'io_fence_sha256':sha(C/'build_io_fence.py'),'review':{'path':str(report),'sha256':sha(report)}}
with (T/'COMPONENT-BUILD-REVIEW-PINS.json').open('x',encoding='utf-8') as f:json.dump(value,f,indent=2);f.write('\n')
print(json.dumps(dict(status='REVIEW_PINS_FIXED',inputs=value['inputs_sha256'],builder=value['script_sha256'])))
