"""Exact source-copy of the current installed release, with no business import."""
from pathlib import Path
import hashlib,json,shutil,sys
sys.dont_write_bytecode=True
T=Path(__file__).resolve().parent;P=T.parents[1];B=T.parent/'multi-account-reply-20261026'
read=lambda p:json.loads(p.read_text('utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,v):
 p.parent.mkdir(parents=True,exist_ok=True)
 with p.open('x',encoding='utf-8') as f:json.dump(v,f,ensure_ascii=False,indent=2);f.write('\n')
frozen=read(P/'work/ui-native-r57/FROZEN.json')
assert frozen['release_id']=='ui-r57-20261026T130202Z-ba1ea294'
assert Path(frozen['runtime_project_root'])==B/'assembly/project'
pins=read(B/'FROZEN-PINS.json')
canonical={n:sha(P/'work/ui-native-r57'/n) for n in ('run_workbench.py','FROZEN.json','state/production-workspace.json')}
write(T/'LIVE-BASELINE.json',dict(releaseId=frozen['release_id'],canonical=canonical))
write(T/'BASELINE.json',dict(canonical=canonical,productionChanged=False))
expected=dict(read(B/'assembly/BASE-COPY.complete.json')['files'])
expected.update({n:r['after'] for n,r in read(B/'assembly/CHANGES.final.json')['files'].items()})
closure={r['path']:r['sha256'] for r in read(B/'assembly/UNIFIED-PINS.json')['files']}
target=T/'assembly/project';assert not target.exists()
for name,h in expected.items():
 source=B/'assembly/project'/name
 assert source.suffix.lower() not in ('.db','.sqlite','.sqlite3')
 assert sha(source)==closure[name]==h,name
 dest=target/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,dest)
 assert sha(dest)==h
write(T/'assembly/BASE-COPY.complete.json',dict(source=str(B/'assembly/project'),files=expected,status='EXACT_INSTALLED_PUBLIC_SOURCE_COPY'))
for name in ('closed_update_guard.py','next_launch_update.py','verify_next_launch_entry.py','review_source_closure.py'):
 shutil.copyfile(B/name,T/name)
for n,h in canonical.items():assert sha(P/'work/ui-native-r57'/n)==h,n
write(T/'FILES-PLAN.json',dict(baseline=frozen['release_id'],source=str(B/'assembly/project'),productionWrites=0,guiOperations=False,realPlatformCalls=False,goal='Complete bounded public-profile reading and account-specific controlled reply execution',owners={'backend':'registered bounded profile read + session capability','frontend':'capability/state UI and original reviewed reply entry','astra':'architecture and critical final review','root':'source assembly, original delivery integration, build validation and next-launch update'}))
print(json.dumps(dict(status='PREPARED',sourceFiles=len(expected),baseline=frozen['release_id'])))
