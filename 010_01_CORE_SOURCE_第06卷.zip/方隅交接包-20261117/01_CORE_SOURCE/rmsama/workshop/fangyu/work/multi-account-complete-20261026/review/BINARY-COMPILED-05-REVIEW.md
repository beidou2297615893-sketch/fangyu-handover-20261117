# 第五次实际组件合成验收批准

2026-10-27，Astra，独立静态与哈希审查。

APPROVED_FOR_ONE_COMPILED_LOOPBACK_FIXTURE_RUN_05

仅批准 root 在新 binary-e2e/compiled-05 目录执行一次 harness-v3 --compiled-reviewed 路线。原项目/发布参数保持已审 ba1ea294 只读基线。helper 精确路径为 component-v3/artifacts/platform-cli-customer-read/platform-cli-customer-read.exe。

- EXE：998831579f4f2a729039d3d0924d69fb9da09f820e965403a93681ed03452d31
- harness-v3.py：bccc99621b84600f7a07ed8f00091aa29c7b01e5931bcad681ee903cad2b9c60
- safety.py：08c0419c06a1fb10dfffd08166659f7f2d56004223f8bb207c5dd2d821cea980
- tests/loopback_tls_fixture.py：502a925a3b489bd4063c5fb8a5940123519fb54759bec6c2620175a6e9969edf
- FROZEN.json：A18B38179DB7F06A6A2DE21B0BF5A382DD370C80145DBA579BF2D71D0A9B6462
- runtime_tree_sha256：62aa0e018951d05714e89d84901f67db3e1c35e6d549b5ba5a50586d086b8a31
- INPUTS：7F3933FBACF877D075A6D1F2860CE5CAACC196BFB1CD59DA83E0B7881227B5B0
- profile_worker：07b840298caf36a30a0c047387865e0989a5b7cce3f6c046aea18b4d0d33a13c

独立重算全部 296 项 FROZEN 输出 SHA256/大小，零差异；artifacts 实际 297 文件含 FROZEN，组件运行目录 291 文件。EXE、harness、安全与 TLS 文件重新取哈希。新私有注册必须绑定 v3 精确路径/哈希。源与脚本内容分别见 COMPONENT-V3-BUILD-REVIEW.md、HARNESS-V3-STATIC-REVIEW.md。

四案例保持公开资料读取采用、单条发送、错误 UID 零 POST、响应身份冲突 unknown 禁重放；公开简介使用无响应 UID fixture，必须保留 request_bound_subject 至采用证据。180/100 秒等待仅属测试，不修改业务 lease/claim。沿用原空 HOME、合成凭据、固定私有 flags、隐藏进程、临时 CA、全部 loopback 代理、清空 NO_PROXY、响应器绝不转发等边界。不访问真实平台/登录/模型/生产数据；父 audit 不冒充原生 child OS 网络沙箱。

此前 01/02/03/04 均未通过，原记录保留。本条不预判本次 PASS，不授权云部署、安装或真实业务运行。失败保留本次完整结果，不自动重复执行；任何精确文件变化须重新审查。

## 实际结果：批准已消费

独立读取 compiled-05/RESULT.json：整体 FAIL，成功完成两个案例：read 为 4 GET、state completed、缺 UID 简介以 request_bound_subject 读取并采用；send 为 1 GET + 1 POST、state completed、原队列发送成功。wrong-uid 实际 1 GET、0 POST，但队列返回 unknown，未满足 approved 断言；response-conflict 尚未执行。

因此可以保留前两项精确 v3 的独立 PASS 证据，但不得把 compiled-05 整体改成 PASS。根因静态确认：测试先加载 engine 捕获旧 AdapterBusy，再替换 sys.modules['core.adapters']，bridge 取得新 AdapterBusy；Core.send 的 except AdapterBusy 识别不到新类，落到原 unknown 路线。两源类定义均为 class AdapterBusy(RuntimeError): pass。允许在后续独立 harness-v4 只统一 fixture 的异常类身份并证明修前/后差异，不改生产 catch 或队列语义；补跑剩余两个负向案例须另行精确批准。
