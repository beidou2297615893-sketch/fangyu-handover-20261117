import sys
from pathlib import Path
import unittest
import threading
import time
from copy import deepcopy
from types import SimpleNamespace
import os
sys.path.insert(0,os.environ.get('SCOPE_TEST_NATIVE',str(Path(__file__).resolve().parents[1]/'assembly/project/work/ui-native-r57')))
from reply_context import conversation
from reply_ai_workflow import Workflow,ENTITY

class Store:
    def __init__(self):self.rows={}
    def get(self,e,i):return deepcopy(self.rows.get((e,i)))
    def put(self,e,r):self.rows[e,r['id']]=deepcopy(r)
    def list(self,e,t):return [deepcopy(r) for (entity,_),r in self.rows.items() if entity==e and r['tenant_id']==t]

class Tests(unittest.TestCase):
    def setUp(self):
        self.user={'id':'u','username':'owner','tenant_id':'t'}
        self.store=Store();self.store.put('accounts',{'id':'a','tenant_id':'t','cloud_owner':'owner','store_id':'s','platform':'xiaohongshu'})
        self.lead={'id':'l','author':'momo','text':'这是哪里的多少钱','comment_level':2,'parent_id':'p','parent_text':'这个是两房的\n[视频]29s','content_title':'转租（已租到）'}
        self.row={'id':'l','sourceDigest':'digest','canSave':True,'pendingRequestId':'','draft':None,'accounts':[{'id':'a'}],'conversation':conversation(self.lead)}
        self.auth=True
        def identity(token):
            if not self.auth:raise ValueError('权限撤销')
            return self.user,{'can_reply':True}
        # New read projection uses the same authorized tenant/store preference
        # reader; this legacy fixture supplies that boundary, not a fallback in
        # production. Original generation/review assertions remain unchanged.
        def tone_preferences(user,profile,data,token,*,save):
            self.assertEqual((user['id'],user['tenant_id'],user['username']),('u','t','owner'))
            self.assertEqual(data,{'storeId':'s'});self.assertEqual(token,'token')
            self.assertIs(profile.get('can_reply'),True);self.assertIs(save,False)
            return {'preferences':{'revision':1,'identity':'真实住户','tone':'friendly',
                'salutation':'你好','focus':['housing'],'templates':{'employee':'','customer':''}}}
        self.b=SimpleNamespace(lock=threading.RLock(),closed=False,_identity=identity,_selected_store=lambda u,p:'s',
            _tone_preferences=tone_preferences,
            core=SimpleNamespace(store=self.store,_account_access=lambda u,a:None),
            reply_workbench=SimpleNamespace(read=lambda *a,**k:{'item':{'name':'momo'},'comments':[deepcopy(self.row)]}),
            _voice_samples_dispatch=lambda *a:{'voiceSamples':{'items':[{'reference_text':'可以看看呀～'},{'text':'未确认，不参考'}]}})
        self.enter=threading.Event();self.release=threading.Event();self.calls=[]
        def provider(packet,tone,refs):
            self.calls.append((packet,tone,refs));self.enter.set();self.release.wait(3)
            return {'relationship':'客户在问父评论','need':'位置和价格','fit':'尚未确认','reason':'不能把帖主已租到归客户','reply':'也可以看看方隅呀','unknown':['视频内容'],'shouldReply':True}
        self.w=Workflow(self.b,provider)
        self.data={'storeId':'s','accountId':'a','platform':'xiaohongshu','customerIds':['c'],'tone':'友善一点','requestId':'r'}
    def start(self):
        j=self.w.dispatch('reply_ai_start',self.data,'token')['replyAI'];self.assertTrue(self.enter.wait(2));return j
    def finish(self,j):
        self.release.set()
        for _ in range(100):
            if j['id'] not in self.w.running:break
            time.sleep(.01)
        return self.w.dispatch('reply_ai_status',{**self.data,'jobId':j['id']},'token')['replyAI']
    def test_context_distinguishes_authors_and_gaps(self):
        c=conversation(self.lead)
        self.assertEqual(c['level'],2);self.assertEqual(c['target']['text'],'这是哪里的多少钱')
        self.assertIn('已租到',c['post']['title']);self.assertNotIn('已租到',c['target']['text'])
        self.assertIn('图片或视频内容尚未解析',c['missing'])
    def test_missing_level_not_assumed_first(self):
        self.assertIsNone(conversation({'text':'多少钱'})['level'])
        self.assertIn('被回复的评论正文缺失',conversation({'parent_id':'x'})['missing'])
    def test_generation_is_draft_only_and_confirmed_references(self):
        j=self.finish(self.start())
        self.assertEqual(j['state'],'done');self.assertEqual(j['rows'][0]['status'],'ready')
        self.assertEqual(self.calls[0][2],['可以看看呀～'])
        self.assertFalse(j['automaticSending']);self.assertFalse(self.store.list('replies','t'))
    def test_repeated_start_is_idempotent(self):
        j=self.start();again=self.w.dispatch('reply_ai_start',self.data,'token')['replyAI']
        self.assertEqual(j['id'],again['id']);self.finish(j);self.assertEqual(len(self.calls),1)
    def test_cancel_discards_inflight_result(self):
        j=self.start();self.w.dispatch('reply_ai_cancel',{**self.data,'jobId':j['id']},'token')
        done=self.finish(j);self.assertEqual(done['state'],'stopped');self.assertEqual(done['rows'][0]['text'],'')
    def test_changed_source_rejects_result(self):
        j=self.start();self.row['sourceDigest']='changed';done=self.finish(j)
        self.assertEqual(done['rows'][0]['status'],'error');self.assertFalse(done['rows'][0]['selected'])
    def test_stopped_pending_rows_do_not_block_edit(self):
        j=self.start();self.w.dispatch('reply_ai_cancel',{**self.data,'jobId':j['id']},'token');j=self.finish(j)
        self.assertFalse(j['rows'][0]['selected'])
        self.w.dispatch('reply_ai_edit',{**self.data,'jobId':j['id'],'revision':j['revision'],'edits':[{'leadId':'l','text':'','selected':False}]},'token')
    def test_existing_draft_not_overwritten(self):
        self.row['draft']={'text':'人工原稿'}
        with self.assertRaises(ValueError):self.w.dispatch('reply_ai_start',self.data,'token')
        self.assertFalse(self.calls)
    def test_other_account_cannot_read_job(self):
        j=self.finish(self.start());self.store.put('accounts',{'id':'b','tenant_id':'t','cloud_owner':'owner','store_id':'s','platform':'xiaohongshu'})
        with self.assertRaises(ValueError):self.w.dispatch('reply_ai_status',{**self.data,'accountId':'b','jobId':j['id']},'token')
    def test_edits_revision_checked_and_survive_new_instance(self):
        j=self.finish(self.start());data={**self.data,'jobId':j['id'],'revision':j['revision'],'edits':[{'leadId':'l','text':'  Hello，可以看看这边呀！  ','selected':True}]}
        self.w.dispatch('reply_ai_edit',data,'token')
        with self.assertRaises(ValueError):self.w.dispatch('reply_ai_edit',data,'token')
        result=Workflow(self.b).dispatch('reply_ai_read',self.data,'token')['replyAI']
        self.assertEqual(result['job']['rows'][0]['text'],data['edits'][0]['text'].strip())
        self.assertEqual(result['tone'],'友善一点')

if __name__=='__main__':unittest.main(verbosity=2)
