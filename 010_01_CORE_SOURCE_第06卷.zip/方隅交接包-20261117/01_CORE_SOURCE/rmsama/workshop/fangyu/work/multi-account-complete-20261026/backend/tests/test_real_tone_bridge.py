"""Actual SQLite tone save/read and original draft/review/learning; model is fake."""
from pathlib import Path
import hashlib,importlib.util,json,os,socket,sys,time,unittest
TASK=Path(__file__).resolve().parents[2]
BASE=Path(r'C:/积木软件工坊/项目/方隅公寓客户版/work/unified-intent-recheck-20261026/software/stage-v4/assembly/project')
PROJECT=TASK/'backend/candidate/project'
if '--project' in sys.argv:
 i=sys.argv.index('--project');PROJECT=Path(sys.argv[i+1]);del sys.argv[i:i+2]
RELEASE=BASE/'work/ui-native-r57/releases/ui-r57-20261026T080318Z-d63e3655'
if '--release' in sys.argv:
 i=sys.argv.index('--release');RELEASE=Path(sys.argv[i+1]);del sys.argv[i:i+2]
os.environ['TONE_TEST_PROJECT']=str(BASE);os.environ['TONE_TEST_NATIVE']=str(RELEASE)
sys.path[:0]=[str(PROJECT/'work/ui-native-r57'),str(BASE/'work/ui-native-r57'),str(BASE/'work/ui-runtime-r55/src'),str(RELEASE/'resources/voice-samples')]
import workbench_backend as wb
from reply_ai_workflow import Workflow
path=Path(r'C:/积木软件工坊/项目/方隅公寓客户版/work/confirmed-tone-learning-20261025/test_backend_learning.py')
spec=importlib.util.spec_from_file_location('real_learning_fixture',path);fixture_module=importlib.util.module_from_spec(spec);spec.loader.exec_module(fixture_module)

class RealToneBridge(unittest.TestCase):
 def test_saved_tone_to_draft_to_original_review_without_sending(self):
  f=fixture_module.BackendLearningTests('test_review_collects_final_text_through_real_loader_and_replay_is_idempotent');f.setUp();self.addCleanup(f.doCleanups)
  # Partial overlays contain only changed files; reuse the original pinned
  # sample library fixture instead of pretending the overlay is a full release.
  if not (Path(wb.__file__).parent/'voice_samples.py').is_file() and not (Path(wb.__file__).parent/'resources/voice-samples/voice_samples.py').is_file():
   f.b._voice_sample_component=lambda:(sys.modules['voice_samples'],fixture_module.VOICE_NATIVE/'voice_samples_vendor')
  f.user['role']='admin';f.profile['role']='admin';f.store.put('users',f.user)
  saved=f.b._tone_preferences(f.user,f.profile,{'storeId':'store1','expectedRevision':0,'identity':'管理员填写的顾问称呼','tone':'concise','salutation':'你好','focus':['housing'],'templates':{'employee':'仅内部员工SOP','customer':'措辞自然，不承诺现房。'}},'fixture-token',save=True)['preferences']
  self.assertEqual(saved['revision'],1)
  f.user['role']='operator';f.profile['role']='operator';f.store.put('users',f.user);f.store.delete('replies','reply1')
  original=f.b.reply_workbench.customers.detail_context
  def context(*a,**kw):
   user,public,item,person=original(*a,**kw);return user,public,{'name':'示例客户'},person
  f.b.reply_workbench.customers.detail_context=context
  f.b.reply_workbench.customers.detail=lambda *a,**kw:context(*a,**kw)
  calls=[]
  def provider(packet,tone,refs):
   calls.append(tone)
   return {'relationship':'客户问另一位评论者','need':'价格','fit':'尚未核对','reason':'提供另一个选择','reply':'也可以看看我住的方隅。','unknown':['价格'],'shouldReply':True}
  f.b.context_reply_workflow=Workflow(f.b,provider)
  data={'storeId':'store1','accountId':'account1','platform':'xiaohongshu','customerIds':['customer1'],'tone':'不要感叹号','requestId':'tone-real','styleMode':'store','expectedToneRevision':1}
  view=f.b.dispatch('reply_ai_read',{'storeId':'store1','accountId':'account1','platform':'xiaohongshu'},'fixture-token')['replyAI']
  self.assertEqual(view['savedTone']['tone'],'concise')
  job=f.b.dispatch('reply_ai_start',data,'fixture-token')['replyAI']
  for _ in range(150):
   if job['id'] not in f.b.context_reply_workflow.running:break
   time.sleep(.01)
  job=f.b.dispatch('reply_ai_status',{**data,'jobId':job['id']},'fixture-token')['replyAI']
  self.assertEqual(job['state'],'done');self.assertEqual(calls[0]['effectiveStyle']['resolvedTone'],'concise');self.assertEqual(calls[0]['savedTone']['customerTemplate'],'措辞自然，不承诺现房。')
  self.assertNotIn('仅内部员工SOP',json.dumps(calls,ensure_ascii=False));self.assertNotIn('顾问称呼',json.dumps(calls,ensure_ascii=False))
  row=job['rows'][0]
  done=f.b.dispatch('reply_ai_confirm',{**data,'jobId':job['id'],'leadId':row['leadId'],'confirmationKey':row['confirmationKey'],'confirmed':True},'fixture-token')['replyAI']
  self.assertEqual(done['rows'][0]['confirmation']['state'],'confirmed')
  self.assertEqual(f.store.list('replies','t')[0]['status'],'approved');self.assertEqual(f.store.list('reply_queues','t'),[])
  self.assertFalse(done['automaticSending']);self.assertEqual(f.library.read(f.user,f.scope)['count'],1)
  before=len(f.store.list('ui_context_reply_jobs_v1','t'))
  for payload,code in (({**data,'requestId':'stale','expectedToneRevision':0},'REPLY_TONE_REVISION_CONFLICT'),({**data,'requestId':'empty','customerIds':[]},'REPLY_AI_NOT_CREATED')):
   with self.assertRaises(wb.WorkbenchError) as caught:f.b.dispatch('reply_ai_start',payload,'fixture-token')
   self.assertEqual(caught.exception.code,code);self.assertIs(caught.exception.mutation_committed,False)
  self.assertEqual(len(f.store.list('ui_context_reply_jobs_v1','t')),before);self.assertEqual(len(calls),1)
  f.b._tone_preferences(f.user,f.profile,{'storeId':'store1'},'fixture-token',save=False)
  with f.store.connect() as db:db.execute('DELETE FROM sessions')
  with self.assertRaises(wb.WorkbenchError):f.b.dispatch('reply_ai_read',data,'fixture-token')

if __name__=='__main__':
 socket.socket.connect=lambda *a,**k:(_ for _ in ()).throw(AssertionError('network forbidden'))
 unittest.main(verbosity=2)

