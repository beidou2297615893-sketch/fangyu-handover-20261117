"""Offline full-file verification of an official code readback; no network calls."""
from pathlib import Path
import argparse,hashlib,json,zipfile
D=Path(__file__).resolve().parent

def files(root):
 result={}
 for p in root.rglob('*'):
  assert not p.is_symlink(),'Symlink forbidden'
  if p.is_file():result[p.relative_to(root).as_posix()]={'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size}
 return result

def tree(rows):
 return hashlib.sha256(''.join(k+'\0'+rows[k]['sha256']+'\n' for k in sorted(rows)).encode()).hexdigest()

def local_material(composition):
 before=files(D/'live-before');after=files(D/'candidate')
 assert len(before)==composition['beforeFiles']==5618 and len(after)==composition['afterFiles']==5619
 assert tree(before)==composition['beforeTree'] and tree(after)==composition['afterTree']
 changes={k for k in set(before)|set(after) if before.get(k)!=after.get(k)}
 assert changes=={'devices.cjs','reviewed_reply_release.cjs'}
 assert sum(k in after and after[k]==v for k,v in before.items())==5617
 assert set(before)-set(after)==set() and set(after)-set(before)=={'reviewed_reply_release.cjs'}
 for row in composition['changedFiles']:
  k=row['path'];assert row['beforeSha256']==(before[k]['sha256'] if k in before else None) and row['afterSha256']==after[k]['sha256']
 return after

def verify(readback,composition):
 expected=local_material(composition);readback=Path(readback).resolve()
 assert readback.parent==D.resolve(),'Owned readback directory required'
 report=json.loads((readback/'LIVE-READBACK.json').read_text('utf-8'))
 rows=json.loads((readback/'LIVE-CODE-FILES.json').read_text('utf-8'))
 actual={r['path']:{'sha256':r['sha256'],'bytes':r['bytes']} for r in rows}
 assert len(actual)==len(rows)==5619 and actual==expected,'Full readback manifest differs'
 assert tree(actual)==report['treeSha256']==composition['afterTree']
 assert report['files']==5619 and report['freshFullBackupCreated']
 body=(readback/'live-function-code.zip').read_bytes()
 assert hashlib.sha256(body).hexdigest()==report['codeZipSha256']
 archived={}
 with zipfile.ZipFile(readback/'live-function-code.zip') as z:
  for info in z.infolist():
   if info.is_dir():continue
   assert info.filename not in archived,'Duplicate archive entry'
   data=z.read(info);archived[info.filename]={'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)}
 assert archived==expected,'Readback ZIP bytes differ'
 result={'status':'PASS','treeSha256':tree(actual),'verifiedFiles':5619,'unchangedOriginalFiles':5617,'archiveBytesVerified':True,'externalCallsByVerifier':0}
 (readback/'FULL-READBACK-VERIFICATION.json').write_text(json.dumps(result,indent=2),'utf-8');return result

def main():
 p=argparse.ArgumentParser();p.add_argument('--readback',type=Path);p.add_argument('--prepare-only',action='store_true');args=p.parse_args()
 c=json.loads((D/'COMPOSITION.json').read_text('utf-8'))
 if args.prepare_only:
  local_material(c);print(json.dumps({'status':'LOCAL_MATERIAL_VERIFIED_NOT_DEPLOYED','files':5619,'unchangedOriginalFiles':5617,'materialReady':c['materialReady'],'externalCalls':0}));return
 assert args.readback is not None
 print(json.dumps(verify(args.readback,c)))
if __name__=='__main__':main()
