"""Offline candidate preparation only. No CloudBase, SDK, DB or config calls."""
from pathlib import Path
import argparse, hashlib, json, re
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
D=Path(__file__).resolve().parent
PRIOR=D.parents[1]/'cloud-prompt-deployment-20261025'/'approved-code'
def inventory(root):
    assert root.is_dir(), f'missing directory: {root.name}'
    paths=[p for p in root.rglob('*') if p.is_file()]
    def item(p):return p.relative_to(root).as_posix(),hashlib.sha256(p.read_bytes()).hexdigest()
    with ThreadPoolExecutor(max_workers=16) as pool:return dict(pool.map(item,paths))
def tree(files):return hashlib.sha256(''.join(k+'\0'+files[k]+'\n' for k in sorted(files)).encode()).hexdigest()
def changes(before,after):return sorted(k for k in before.keys()|after.keys() if before.get(k)!=after.get(k))
def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--material-sha256',help='Approved canonical sender Registration manifest digest (lower hex). Writes only the fixed candidate allowlist.')
    args=parser.parse_args()
    live=inventory(D/'live-before');assert tree(live)=='843361adb2bf456a4c23ea86bdd2dad6904c7e92634001978226f8d74ed7a84b'
    module=D/'candidate'/'reviewed_reply_release.cjs'
    source=module.read_text(encoding='utf8')
    matches=re.findall(r"materialSha256:'([^']+)'",source);assert len(matches)==2 and len(set(matches))==1
    current=matches[0]
    if args.material_sha256 is not None:
        assert re.fullmatch('[a-f0-9]{64}',args.material_sha256),'material must be exact 64 lower hex'
        assert current in ('PENDING_REVIEWED_SENDER_MATERIAL_SHA256',args.material_sha256),'refuse to silently replace different reviewed material'
        source=source.replace("materialSha256:'"+current+"'", "materialSha256:'"+args.material_sha256+"'")
        module.write_text(source,encoding='utf8',newline='')
    current=re.search(r"materialSha256:'([^']+)'",source)[1]
    candidate=inventory(D/'candidate');changed=changes(live,candidate)
    assert changed==['devices.cjs','reviewed_reply_release.cjs'],changed
    prior=inventory(PRIOR)
    baseline=json.loads((D/'BASELINE.json').read_text(encoding='utf-8-sig'))
    baseline['priorDeploymentChangedFiles']=changes(prior,live)
    baseline['priorDeploymentComparison']={'corrected':True,'priorFiles':len(prior),'currentFiles':len(live),'priorTreeSha256':tree(prior),'currentTreeSha256':tree(live),'source':'project/work/cloud-prompt-deployment-20261025/approved-code','note':'Metadata path corrected only; fresh backup and live-before/candidate baseline remain unchanged.'}
    (D/'BASELINE.json').write_text(json.dumps(baseline,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
    report={'status':'PREPARED_NOT_DEPLOYED','atUtc':datetime.now(timezone.utc).isoformat(),'beforeTree':tree(live),'afterTree':tree(candidate),'beforeFiles':len(live),'afterFiles':len(candidate),'changedFiles':[{'path':k,'beforeSha256':live.get(k),'afterSha256':candidate.get(k)} for k in changed],
        'unchangedOriginalFiles':sum(candidate.get(k)==v for k,v in live.items()),'materialSha256':current,'materialReady':bool(re.fullmatch('[a-f0-9]{64}',current)),
        'databaseReadOrWritten':False,'configurationReadOrWritten':False,'platformRequests':0,'productionWrites':0,'deploymentExecuted':False}
    (D/'COMPOSITION.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf8')
    print(json.dumps(report))
if __name__=='__main__':main()

