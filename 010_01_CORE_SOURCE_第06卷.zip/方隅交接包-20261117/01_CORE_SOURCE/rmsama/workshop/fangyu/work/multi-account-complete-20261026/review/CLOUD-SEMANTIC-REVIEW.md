# 云端独立许可语义审查

2026-10-26，Astra，非代码作者。

已只读审查 cloud/candidate/reviewed_reply_release.cjs、devices.cjs 与 cloud/tests/reviewed_reply_release.test.cjs，并核对 COMPOSITION.json 所引用的真实后继基线 `843361adb2bf456a4c23ea86bdd2dad6904c7e92634001978226f8d74ed7a84b`。

当前语义无阻塞：新模块的固定材料占位不能匹配有效 digest，默认拒绝；新许可需原认证设备、合法只读企业许可、同一活跃员工、正常角色、有效回复权限、心跳新鲜度与版本/协议/材料全部相符。权限 revision 稳定且与同一次 owner_permissions 一致。不提升原 read grant、不开放远端 command、不修改用户权限、企业配置或数据库结构。

现有七组源码合成测试覆盖完整服务接线、拒绝条件、旧客户端响应等价、权限 revision 稳定/变更和普通发送命令仍被拒绝；允许分支在内存内替换合成材料摘要，不改生产文件。生产占位只验证拒绝分支。

这不是部署批准。最终编译材料 digest 固定后，需重跑真实候选 allowlist 分支、重新计算两文件与完整候选树摘要；确认其他 5617 原文件逐字保留，并在部署前从真实云端再读取树摘要执行 CAS。远端已变则停止，保留新后继，不覆盖。最终精确源审查另行签发。

## 实际 native source 分支复核

已进一步读取双版本候选及新增三组测试。1.1.8-pilot.1 分支必须同时满足原 employeeRelease 真许可、continuous_read、既有固定设备 adminWorkbenchFor、请求与设备的 source marker、一致版本；没有仅凭 marker 放行。1.2 read 分支保留原合同。双分支仍共同核固定材料、正常员工权限、认证设备、前次心跳与非 QA。

此兼容与实际安装 company.json 一致，无新增语义阻塞；待最终固定材料摘要和完整树的精确审查。对应本地 source_employee 读取分支的双配置、设备 ID、原有效 deadline 及独立发送 lease 也已核对；发送 decision 已冻结 permission_revision，权限版本变化会使旧批次下一 wire 失效。
