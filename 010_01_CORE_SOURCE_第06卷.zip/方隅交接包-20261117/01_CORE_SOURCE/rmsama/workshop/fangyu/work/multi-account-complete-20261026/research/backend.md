# 后端可实施接口与复用链路

基线只读：`C:/积木软件工坊/项目/方隅公寓客户版/work/multi-account-reply-20261026/assembly/project`；发布源 `work/ui-native-r57/releases/ui-r57-20261026T130202Z-ba1ea294`。本次仅源码读取，没有平台请求、CLI/App/模型启动、Cookie或真实账户数据读取。

## 最难链路已有部分

1. `work/ui-runtime-r55/src/assistant/xhs_cli_page_worker.py` 已允许 `user-posts UID --json [--cursor CURSOR]`，`exact_source_gate()`映射 `ReadRequest(user_posts)`；`_setup()`在原固定wrapper内注册上游命令。不是直接启动CLI包。
2. `core/acquisition_extension/guarded_port.py` 将user_posts严格限定GET `https://edith.xiaohongshu.com/api/sns/web/v1/user_posted?num=30&cursor=...&user_id=UID&image_scenes=FD_WM_WEBP`；SinglePageWireGate禁止第二次wire/retry。
3. `core/adapters.py:begin_xhs_cli_pages/_cli_page_result` 是注册PageWorker的既有入口。验证HOME、account directory、manifest cli_page_worker/source_read_pages；注册process受原lifecycle lock管理。
4. `core/xhs_page_process.py:PageWorker` 使用原固定executable `--owned-xhs-cli-pages`，绑定HOME/session credential fingerprint，单页scope+args digest、parent每wire授权、durable receive/ack。unknown不自动重读。
5. `platform_cli_customer_read.py` 允许该owned helper，但普通CLI allowlist无user/user-posts。扩helper才是原安全链，不能借普通命令绕allowlist。

## 需新增的精确只读操作

上游已装源码 `work/login-cli-refresh-20261018/component/artifacts/platform-cli-guarded/_internal/xhs_cli/client_mixins.py`：

- get_self_info → GET `/api/sns/web/v2/user/me`，无query。
- get_user_info(uid) → GET `/api/sns/web/v1/user/otherinfo?target_user_id=uid`。
- get_user_notes(uid,cursor) → 上述user_posted。

在原ReadRequest操作目录/compile_xhs_request、worker.validate_args/exact_source_gate/_setup、adapter registered op中增加固定 `whoami --json` 与 `user UID --json`。_setup需显式导入auth命令并复用同一client；不能授予login/send/follow等命令。普通wrapper命令allowlist仍可保持不扩。重建customer-read组件并更新manifest/source pins，代码修改不能冒充已有exe。

公开资料读取建议为独立受控read job：UI传accountId/customerId/expectedIdentityRevision/requestId/limitPosts(1-5)，server从原可见客户解析UID，不接任意目标UID或URL执行。注册job沿原账号目录、hold、device session、owner权限、账号mode；先实际whoami并严格等指定账号UID，再profile一页、recentposts最多一页，最后whoami复核。最多显示limitPosts条原文与稳定noteId/sourceURL/observedAt；不分页扩读或自动评论采集。subject响应缺UID/作者不符时显式待核验/失败，不把请求UID写成已验证响应UID。

状态/回执建议动作：`reply_public_profile_start/status/cancel`。status恢复原requestId/原job，不隐式新起；结果含actorAccountId/actorUid/subjectId/profileText/posts/evidence/identityProofDigest/sourceBindingDigest/notice，绝不回传Cookie或本机路径。成功原文转入新独立evidence槽，保留manual槽；不把手工原文标为自动核验。

## session选择与实际身份

- `core/adapters.py:account_spec()`已按accounts/tenant/account隔离HOME/USERPROFILE/XDG/APPDATA；`account_execution_lock()`跨进程锁可复用。
- 不能把metadata UID/云claim或已有status=ready当成当前actual whoami。session capability需要原guarded worker返回实际get_self_info，核UID+fresh account identity+会话指纹+actor/store，短时有效并绑定scope，不附带发送许可。
- `assistant/tracked_reply_service.py:_context()` 使用独立 `accounts/tenant/account/xhs-browser-profile` 与ReplyWindowSpec(account_uid)；`tracked_reply_window.py`通过getme响应核实际UID并将sender_uid写回执；此为人工输入/提交受管窗口，不是自动发送器。
- `shared-backend-integration/vendor-src/app.py`已有tracked_reply_start/status端点，但native Workbench尚未转接。可转接固定动作，不创建另一浏览器profile，不复制CLI凭据。

## 不可混用的既有权限

`assistant/xhs_app_context.py`的sealed device session、original executor_call、_TASK_CALLS/任务scope均有用途约束；身份观察/recovery的status-only capability不能借给profile读取。新增read job必须有独立固定用途许可并保留原执行guard，不伪装成另一个已授权采集任务。`xhs_page_runtime`现只解析status/search/comments/subcomments且可能优先截获execute；本新任务需选择明确CLI注册路径，不能随意设为None或静默fallback。

## 重建入口

外部现成builder：`C:/积木软件工坊/项目/方隅公寓客户版/work/login-cli-refresh-20261018/component/` 与其 `prepare_new_component.py`，复用 `work/overnight-integration/identity-recovery-cli-candidate` 的 `prepare_inputs.py/build_inactive_component.py/build_tool_entry.py/build_child_entry.py/build_io_fence.py`。冻结source closure只带artifact，重建应在新task专属candidate/component，先复制builder并按来源hash更新，不修改旧component/生产。

最终能否真实读到平台资料，在当前禁止实采边界内不能验证；应完成可执行注册链与隔离协议验证，并明确actual platform验收仍未执行。失败必须是明确状态，不返回合成资料或借手工paste充数。
