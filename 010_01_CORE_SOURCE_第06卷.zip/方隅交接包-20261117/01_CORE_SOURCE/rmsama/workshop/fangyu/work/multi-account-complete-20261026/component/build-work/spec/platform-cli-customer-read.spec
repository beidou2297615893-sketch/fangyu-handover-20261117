# -*- mode: python ; coding: utf-8 -*-
from PyInstaller.utils.hooks import collect_all

datas = [('C:/积木软件工坊/项目/方隅公寓客户版/work/multi-account-complete-20261026/component/build-work/source/core/xhs_identity_recovery.py', 'core')]
binaries = []
hiddenimports = ['assistant.xhs_cli_page_worker', 'assistant.xhs_reply_worker', 'core.reply_execution_policy', 'assistant.reply_read_session', 'core.acquisition_extension.contracts', 'core.acquisition_extension.guarded_port']
tmp_ret = collect_all('xhs_cli')
datas += tmp_ret[0]; binaries += tmp_ret[1]; hiddenimports += tmp_ret[2]
tmp_ret = collect_all('webview')
datas += tmp_ret[0]; binaries += tmp_ret[1]; hiddenimports += tmp_ret[2]


a = Analysis(
    ['C:/积木软件工坊/项目/方隅公寓客户版/work/multi-account-complete-20261026/component/build-work/source/platform_cli.py'],
    pathex=['C:/积木软件工坊/项目/方隅公寓客户版/work/multi-account-complete-20261026/component/build-work/source', 'C:/积木软件工坊/项目/方隅公寓客户版/work/multi-account-complete-20261026/component/build-work/site'],
    binaries=binaries,
    datas=datas,
    hiddenimports=hiddenimports,
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=['camoufox', 'playwright', 'browserforge', 'browser_cookie3', 'weibo_cli', 'PIL'],
    noarchive=False,
    optimize=0,
)
pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name='platform-cli-customer-read',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=False,
    console=True,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
)
coll = COLLECT(
    exe,
    a.binaries,
    a.datas,
    strip=False,
    upx=False,
    upx_exclude=[],
    name='platform-cli-customer-read',
)
