import assert from 'node:assert/strict';
import {openSettings} from 'file:///C:/%E7%A7%AF%E6%9C%A8%E8%BD%AF%E4%BB%B6%E5%B7%A5%E5%9D%8A/%E9%A1%B9%E7%9B%AE/%E6%96%B9%E9%9A%85%E5%85%AC%E5%AF%93%E5%AE%A2%E6%88%B7%E7%89%88/work/multi-account-complete-20261026/assembly/project/work/ui-approved-implementation/ui-preview/pages/management-tools.mjs';
class Control{constructor(dataset={}){this.dataset=dataset;this.events={}}addEventListener(k,f){this.events[k]=f}async click(){return this.events.click?.()}}
function fixture({role='operator',preview=false,refresh}={}){const state={authEpoch:1,connection:preview?'preview':'connected',user:'fixture-user',storeId:'fixture-store',activePlatform:'xiaohongshu',session:{user:{username:'fixture-user',role}},stores:[{id:'fixture-store',name:'示例门店'}],runtimeMetadata:{status:'ready',value:{profile:'fixture',mode:'development',release:'fixture'}}};let draws=0;const dialog={open:true,__modalOwner:null,controls:{},tabs:[],close(){this.open=false},querySelector(s){return this.controls[s]||(this.controls[s]=new Control())},querySelectorAll(){return this.tabs}};const ctx={state,modal(o){draws++;dialog.__modalOwner={};dialog.options=o;dialog.controls={};dialog.tabs=['general','tools','help'].map(id=>new Control({settingsTab:id}));return dialog},reloadWorkspace:refresh||(async()=>true),refreshSettingsPlatform:async()=>true,refreshRuntimeStatus:async()=>true,logout:async()=>true,navigate:()=>{},toast:()=>{},replyError:()=>{}};return {state,dialog,ctx,get draws(){return draws}}}
{
 const f=fixture();openSettings(f.ctx);assert.ok(!f.dialog.options.html.includes('data-settings-rule-files'));assert.ok(f.dialog.options.html.includes('data-settings-workspace'));await f.dialog.tabs[1].click();assert.equal(f.state.settingsTool.tab,'tools');assert.ok(f.dialog.options.html.includes('data-settings-logout'));
}
{
 const f=fixture({role:'admin'});openSettings(f.ctx);assert.ok(f.dialog.options.html.includes('data-settings-rule-files'));
}
{
 let requests=0;const f=fixture({preview:true,refresh:async()=>{requests++;return true}});openSettings(f.ctx);await f.dialog.querySelector('[data-settings-workspace]').click();assert.equal(requests,0);
}
{
 let resolve;const f=fixture({refresh:()=>new Promise(r=>resolve=r)});openSettings(f.ctx);const pending=f.dialog.querySelector('[data-settings-workspace]').click();assert.equal(f.state.settingsTool.busy,true);f.ctx.modal({title:'新弹窗',html:'新内容'});const draws=f.draws;resolve(true);await pending;assert.equal(f.draws,draws);assert.equal(f.dialog.options.title,'新弹窗');
}
{
 const f=fixture({refresh:async()=>false});openSettings(f.ctx);await f.dialog.querySelector('[data-settings-workspace]').click();assert.ok(f.dialog.options.html.includes('未确认'));
 f.state.platformError='授权已撤回，请联系管理员';f.dialog.tabs[2].click();assert.ok(f.dialog.options.html.includes('授权已撤回，请联系管理员'));
}
console.log('PASS: settings original role/action visibility, preview zero requests, stale refresh never overwrites newer dialog, failed refresh and authorization alert remain visible');
