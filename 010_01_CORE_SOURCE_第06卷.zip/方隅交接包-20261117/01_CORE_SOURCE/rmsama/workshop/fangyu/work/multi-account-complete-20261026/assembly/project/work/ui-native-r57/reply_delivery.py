"""Explicit snapshot authorization around the preserved sequential reply queue.

The scheduler, account lease, contact journal and unknown-result rules remain
the original implementation. Only r57 employee/store/source validation is added.
"""
import threading,hashlib,json,re,time
from core.continuous import process_alive,stamp
from uuid import uuid4
from datetime import datetime,timezone
from core import CoreError
from core.adapters import AdapterBusy
from core.review_queue import ReviewedReplyQueues, require_reply_permission, snapshot
KEY=re.compile(r'[A-Za-z0-9_-]{1,160}\Z')
class DeliveryError(ValueError):
    def __init__(self,code,message,status=400):
        super().__init__(message);self.code,self.status=code,status
def fail(code,message,status=400):raise DeliveryError(code,message,status)
def digest(value):return hashlib.sha256(json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()

ENTITY='ui_reply_delivery_v1'
CUSTOMER_GUARD='ui_customer_reply_guard_v1'
ACTIONS=frozenset(('reply_delivery_prepare','reply_delivery_start','reply_delivery_status','reply_delivery_cancel'))


class ScopedReviewedQueues(ReviewedReplyQueues):
    def __init__(self, core, owner):
        super().__init__(core,defer_startup_recovery=True)
        self.owner=owner
        # Only an explicit .start below creates a worker; construction never
        # resumes any ready or historical queue.
        self.autostart=True

    def _validate(self, reply, user, tenant, account, expected=None):
        result=super()._validate(reply,user,tenant,account,expected)
        if expected is not None:
            callback=self.owner.validation(reply['id'],expected)
            callback(False)
            if getattr(self.owner.local,'processing',False):self.owner.local.callback=callback
        return result

    def process(self, ident):
        self.owner.local.processing=True
        try:
            value=next((v for v in self.owner.active.values() if v['plan']['queueId']==ident),None)
            if value and value.get('decision') is not None:
                from core.reply_execution_policy import reviewed_scope
                with reviewed_scope(value['decision']):return self._process_guarded(ident)
            return self._process_guarded(ident)
        finally:
            self.owner.local.processing=False
            self.owner.local.callback=None


    def _process_guarded(self, ident):
        queue = self.core.store.get('reply_queues', ident)
        if not queue or not queue.get('reviewed'):
            return
        tenant, owner = queue['tenant_id'], 'review-queue:'+ident
        leased = False
        deadline = time.monotonic()+self.collection_wait_seconds
        try:
            while True:
                queue = self.core._get('reply_queues', ident, tenant)
                if queue['status'] != 'awaiting_collection' or self._stop.is_set():
                    return
                mode = self.core.account_mode_status(queue['account_id'], tenant)
                if mode.get('status') != 'active' or not process_alive(mode.get('pid')):
                    break
                if mode.get('mode') != 'collection':
                    raise ValueError('账号已有其他回复正在执行')
                if time.monotonic() >= deadline:
                    queue.update(wait_expired=True, message='采集本批仍在结束，已确认内容保留；结束后可继续发送', updated_at=stamp())
                    self.core.store.put('reply_queues', queue)
                    return
                self._stop.wait(.2)
            with self.core.lock:
                self.core.acquire_account_mode(queue['account_id'], tenant, 'replies', owner)
                leased = True
                queue = self.core._get('reply_queues', ident, tenant)
                if queue['status'] != 'awaiting_collection':
                    return
                queue.update(status='running', message='正在顺序发送已确认回复', updated_at=stamp())
                self.core.store.put('reply_queues', queue)
            for value in queue['snapshots']:
                with self.core.lock:
                    queue = self.core._get('reply_queues', ident, tenant)
                    if queue['status'] != 'running' or self._stop.is_set():
                        return
                    user = self.core.store.get('users', queue['authorized_by'])
                    if not user or user.get('disabled'):
                        raise ValueError('队列授权员工已停用')
                    self._access(queue, user)
                    account = self.core._get('accounts', queue['account_id'], tenant)
                    self.core._public_reply_guard(account.get('platform'))
                    reply = self.core._get('replies', value['reply_id'], tenant)
                    lead = self.core._get('leads',reply['lead_id'],tenant)
                    conflict = self.owner.customer_conflict(tenant,lead)
                    if not conflict:
                        lead, _ = self._validate(reply, user, tenant, account, value)
                result = ({'status':'skipped','last_error':conflict} if conflict else
                    self.core._send_reply({'id': reply['id'], 'account_id': account['id'], 'authorized': True},
                        user, tenant, reply, lead, mode_owner=owner))
                with self.core.lock:
                    queue = self.core._get('reply_queues', ident, tenant)
                    queue['processed'] += 1
                    if result['status'] == 'sent':
                        queue['sent'] += 1
                    elif result['status'] == 'skipped':
                        queue['skipped']=queue.get('skipped',0)+1
                        queue.setdefault('skipped_reasons',{})[reply['id']]=result['last_error']
                    elif queue['status'] == 'running':
                        queue.update(status='stopped', message='发送结果未知，队列已停止，禁止自动重试' if result['status'] == 'unknown' else '本条未发送，队列已停止，请检查账号')
                    self.core.store.put('reply_queues', queue)
                    if queue['status'] != 'running':
                        return
            with self.core.lock:
                queue=self.core._get('reply_queues',ident,tenant)
                if queue.get('status')=='running':
                    queue.update(status='completed', message='已确认队列处理完成', updated_at=stamp())
                    self.core.store.put('reply_queues', queue)
        except Exception as exc:
            with self.core.lock:
                queue = self.core.store.get('reply_queues', ident)
                if queue and queue.get('status') not in ('cancelled', 'interrupted'):
                    queue.update(status='stopped', message=str(exc), updated_at=stamp())
                    self.core.store.put('reply_queues', queue)
        finally:
            if leased:
                self.core.release_account_mode(queue['account_id'], tenant, owner)
            with self.core.lock:
                self._workers.pop(ident, None)


class ReplyDelivery:
    def __init__(self,core,replies,runtime):
        self.core,self.replies,self.runtime=core,replies,runtime
        self.active={}
        self.local=threading.local()
        previous=core.reviewed_reply_queues
        if previous._workers:fail('DELIVERY_BUSY','原回复队列仍在运行，不能替换运行组件',409)
        core.reviewed_reply_queues=ScopedReviewedQueues(core,self)
        send=core._send_reply
        def customer_guarded(data,user,tenant,reply,lead,mode_owner=None):
            claim,reason=self._customer_claim(tenant,lead,reply,data.get('account_id'))
            if reason:return {'status':'skipped','last_error':reason}
            try:return send(data,user,tenant,reply,lead,mode_owner=mode_owner)
            finally:self._finish_claim(claim)
        core._send_reply=customer_guarded
        original=core.adapters.platform_guard
        def guarded(platform):
            if callable(original):original(platform)
            callback=getattr(self.local,'callback',None)
            if callback:
                # Adapters also invokes this immediately before Popen while
                # holding lifecycle_lock. Never wait for Core in that order:
                # cancel/close can already hold Core while waiting lifecycle.
                # Outside lifecycle the normal Core lock order is safe; a
                # routine read should not make these earlier checks fail.
                if not core.lock.acquire(blocking=not core.adapters.lifecycle_lock.locked()):
                    raise AdapterBusy('原后台正在变更账号状态；本条未启动CLI，本批已停止，请核对')
                try:callback(True)
                finally:core.lock.release()
        core.adapters.platform_guard=guarded


    def _customer_key(self,tenant,lead):
        author=str(lead.get('author_id') or '').strip()
        if not author:fail('CUSTOMER_ID_REQUIRED','缺少客户平台身份，不能确认是否已回复；请先核对来源',409)
        return digest([tenant,lead.get('platform'),author])

    @staticmethod
    def _conflict_message(state):
        return ('该客户已有账号回复成功，本条自动跳过' if state=='sent' else
            '该客户正在发送或上次结果待核对，本条自动跳过，避免跨账号重复联系')

    def _customer_claim(self,tenant,lead,reply=None,account_id=None):
        # BEGIN IMMEDIATE serializes reservations even across independent Core
        # instances. No database transaction is held during the platform call.
        key=self._customer_key(tenant,lead)
        with self.core.store.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            row=db.execute('SELECT body FROM records WHERE entity=? AND id=?',
                (CUSTOMER_GUARD,key)).fetchone()
            prior=json.loads(row['body']) if row else None
            if prior and prior.get('state')!='released':
                return None,self._conflict_message(prior.get('state'))
            # Include pre-upgrade history, across accounts, employees and posts.
            history=db.execute("""SELECT r.body FROM records r JOIN records l
                ON l.entity='leads' AND l.tenant_id=r.tenant_id
                AND l.id=json_extract(r.body,'$.lead_id')
                WHERE r.entity='replies' AND r.tenant_id=?
                AND json_extract(l.body,'$.platform')=?
                AND CAST(json_extract(l.body,'$.author_id') AS TEXT)=?
                AND json_extract(r.body,'$.status') IN ('sent','sending','unknown')""",
                (tenant,lead.get('platform'),str(lead.get('author_id')))).fetchall()
            if history:
                states=[json.loads(r['body']).get('status') for r in history]
                return None,self._conflict_message('sent' if 'sent' in states else 'unknown')
            if reply is None:return None,''
            claim={'id':key,'tenant_id':tenant,'state':'reserved','reservation':uuid4().hex,
                'reply_id':reply['id'],'account_id':account_id,'created_at':stamp()}
            db.execute('INSERT OR REPLACE INTO records VALUES(?,?,?,?)',
                (CUSTOMER_GUARD,key,tenant,json.dumps(claim,ensure_ascii=False)))
            return claim,''

    def customer_conflict(self,tenant,lead):
        return self._customer_claim(tenant,lead)[1]

    def _finish_claim(self,claim):
        with self.core.store.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            row=db.execute('SELECT body FROM records WHERE entity=? AND id=?',
                (CUSTOMER_GUARD,claim['id'])).fetchone()
            current=json.loads(row['body']) if row else {}
            if current.get('reservation')!=claim['reservation']:return
            row=db.execute("SELECT body FROM records WHERE entity='replies' AND id=? AND tenant_id=?",
                (claim['reply_id'],claim['tenant_id'])).fetchone()
            reply=json.loads(row['body']) if row else {}
            # A definite pre-send refusal is safe to release. Interrupted or
            # uncertain sends never expire into an automatic retry.
            state=('sent' if reply.get('status')=='sent' else 'released'
                if reply.get('status')=='approved' and not reply.get('attempted_at') else 'unknown')
            current.update(state=state,updated_at=stamp())
            db.execute('UPDATE records SET body=? WHERE entity=? AND id=?',
                (json.dumps(current,ensure_ascii=False),CUSTOMER_GUARD,claim['id']))

    def validation(self,reply_id,expected):
        values=[value for value in list(self.active.values()) if any(
            row['replyId']==reply_id and row['snapshot']==expected for row in value['plan']['items'])]
        if len(values)!=1:fail('DELIVERY_AUTH_EXPIRED','本批授权已失效；重开后不会自动续发',409)
        value=values[0]
        row=next(r for r in value['plan']['items'] if r['replyId']==reply_id)
        def fresh(boundary):
            user,profile=value['refresh']()
            if profile.get('_workbench_store_id',profile.get('store_id'))!=value['plan']['storeId']:
                fail('STORE_FORBIDDEN','门店范围已变化，本批已停止',403)
            queue=self.core._get('reply_queues',value['plan']['queueId'],user['tenant_id'])
            plan=value['plan']
            if (queue.get('snapshots')!=[r['snapshot'] for r in plan['items']]
                    or queue.get('reply_ids')!=[r['replyId'] for r in plan['items']]
                    or queue.get('account_id')!=row['accountId'] or queue.get('authorized_by')!=user['id']
                    or queue.get('status') not in ('ready','awaiting_collection','running')):
                fail('DELIVERY_AUTH_CHANGED','原队列授权或快照已变化，本批已停止',409)
            self._target(user,value['plan']['storeId'],row,allow_sending=boundary)
            if self.runtime is None:fail('PLATFORM_UNAVAILABLE','平台后台尚未就绪',503)
            self.runtime.reply_guard(user,row['accountId'])
        return fresh

    def _target(self,user,store_id,row,*,allow_sending=False,allow_completed=False):
        actor,_,_,person=self.replies._context(user,store_id,row['customerId'])
        if row['leadId'] not in {c['lead_id'] for c in person.get('comments') or []}:
            fail('DELIVERY_SCOPE_CHANGED','原评论已不在客户可见范围',403)
        lead=self.core._get('leads',row['leadId'],user['tenant_id'])
        reply=self.core._get('replies',row['replyId'],user['tenant_id'])
        account=self.core._get('accounts',row['accountId'],user['tenant_id'])
        require_reply_permission(self.core,actor,lead,reply)
        self.core._account_access(actor,account)
        allowed=('approved','sending') if allow_sending else ('approved',)
        if allow_completed:allowed=(*allowed,'sent')
        if (digest(lead)!=row['sourceDigest'] or reply.get('status') not in allowed
                or reply.get('lead_id')!=row['leadId'] or reply.get('version')!=row['version']
                or reply.get('text')!=row['text'] or reply.get('review_account_id')!=row['accountId']
                or account.get('store_id') not in (None,'',store_id)
                or snapshot(self.core,reply,lead,account,user=actor)!=row['snapshot']
                or reply.get('approval_snapshot')!=row['snapshot']):
            fail('DELIVERY_SNAPSHOT_CHANGED','原评论、草稿或执行账号已变化，本批已停止；请重新核对',409)
        routing_guard=getattr(self.replies,'validate_routing',None)
        if callable(routing_guard):
            routing_guard(actor,store_id,row['customerId'],row['leadId'],reply)
        return reply

    def _plan(self,user,store_id,ident,platform=None):
        if not isinstance(ident,str) or not KEY.fullmatch(ident):fail('INPUT_INVALID','回复批次编号无效')
        plan=self.core.store.get(ENTITY,ident)
        if (not plan or plan.get('tenant_id')!=user['tenant_id'] or plan.get('userId')!=user['id']
                or plan.get('owner')!=user['username'] or plan.get('storeId')!=store_id):
            fail('DELIVERY_FORBIDDEN','回复批次不存在或不在当前员工门店范围',403)
        for row in plan['items']:
            _,_,_,person=self.replies._context(user,store_id,row['customerId'])
            if platform is not None and person.get('platform')!=platform:
                fail('DELIVERY_PLATFORM_FORBIDDEN','本批回复不属于当前平台',403)
            if row['leadId'] not in {c['lead_id'] for c in person.get('comments') or []}:
                fail('DELIVERY_FORBIDDEN','本批原评论可见范围已变化',403)
        return plan

    def status(self,user,store_id,plan):
        queue=self.core.handle('reviewed_reply_queue_status',{'id':plan['queueId']},user)
        state=queue['status']
        if state in ('completed','stopped','cancelled','interrupted'):self.active.pop(plan['id'],None)
        if plan['state']=='prepared' and state=='ready':state='prepared'
        elif plan['state']=='blocked' and state=='ready':state='blocked'
        elif state in ('ready','awaiting_collection','running') and plan['id'] not in self.active:
            state='authorization_expired'
        rows=[]
        for row in plan['items']:
            reply=self.core._get('replies',row['replyId'],user['tenant_id'])
            rows.append({k:v for k,v in row.items() if k!='snapshot'}|{
                'status':'skipped' if row['replyId'] in queue.get('skipped_reasons',{}) else reply.get('status'),
                'message':queue.get('skipped_reasons',{}).get(row['replyId'],str(reply.get('last_error') or '')),
                'receipt':self.core.contact_journal.receipt(user['tenant_id'],user['username'],reply['id'],row['leadId']),
                'identityState':'preflight_verified' if reply.get('reviewed_transport_receipt') else 'unknown' if reply.get('status')=='unknown' else 'verify_before_send',
                'identityMessage':'同客户端发送前已核对实际身份' if reply.get('reviewed_transport_receipt') else '发送前将核对该独立会话的实际登录身份',
                **(reply.get('reviewed_transport_receipt') or {})})
        return {'id':plan['id'],'actor':{'username':user['username'],'storeId':store_id},
            'state':state,'snapshotDigest':plan['snapshotDigest'],'items':rows,
            'prepareRequestId':plan['prepareRequestId'],
            'requestId':plan.get('requestId',''),'processed':queue.get('processed',0),'sent':queue.get('sent',0),'skipped':queue.get('skipped',0),
            'message':plan.get('error') or queue.get('message',''),'canStart':state=='prepared',
            'canCancel':state in ('prepared','ready','awaiting_collection','running','authorization_expired')}

    def execute(self,action,user,store_id,data,refresh):
        if not isinstance(data,dict):fail('INPUT_INVALID','回复发送参数无效')
        platform=self.replies.customers.platform_filter(data)
        data={key:value for key,value in data.items() if key!='platform'}
        fields={'reply_delivery_prepare':{'storeId','items','requestId'},'reply_delivery_start':{
            'storeId','id','snapshotDigest','confirmed','requestId'},'reply_delivery_status':{'storeId','id'},
            'reply_delivery_cancel':{'storeId','id'}}[action]
        lookup=action=='reply_delivery_status' and isinstance(data,dict) and set(data)=={'storeId','requestId'}
        recent=action=='reply_delivery_status' and isinstance(data,dict) and set(data)=={'storeId'}
        if not isinstance(data,dict) or (set(data)!=fields and not lookup and not recent):fail('INPUT_INVALID','回复发送参数无效')
        if 'requestId' in data and (not isinstance(data['requestId'],str) or not KEY.fullmatch(data['requestId'])):
            fail('INPUT_INVALID','本批操作编号无效')
        if lookup:
            prior=next((p for p in self.core.store.list(ENTITY,user['tenant_id']) if p.get('userId')==user['id']
                and p.get('storeId')==store_id and p.get('prepareRequestId')==data['requestId']),None)
            if prior:return self.status(user,store_id,self._plan(user,store_id,prior['id'],platform))
            return {'actor':{'username':user['username'],'storeId':store_id},'state':'not_found','prepareRequestId':data['requestId']}
        if recent:
            values=[p for p in self.core.store.list(ENTITY,user['tenant_id']) if p.get('userId')==user['id'] and p.get('storeId')==store_id]
            values.sort(key=lambda p:p.get('createdAt',''))
            history=[];chosen=None
            for value in reversed(values):
                try:
                    plan=self._plan(user,store_id,value['id'],platform)
                    current=self.status(user,store_id,plan)
                except (ValueError,CoreError):continue
                if chosen is None:chosen=current
                history.append({'id':current['id'],'state':current['state'],'count':len(current['items'])})
                if len(history)>=20:break
            return {**(chosen or {'actor':{'username':user['username'],'storeId':store_id},'state':'empty'}),'history':history}
        if action=='reply_delivery_prepare':
            items=data['items']
            if not isinstance(items,list) or not 1<=len(items)<=20:fail('INPUT_INVALID','每批请选择1至20条原评论与已审核草稿')
            prior=next((p for p in self.core.store.list(ENTITY,user['tenant_id']) if p.get('userId')==user['id']
                and p.get('storeId')==store_id and p.get('prepareRequestId')==data['requestId']),None)
            if prior:
                if prior.get('prepareSignature')!=digest(items):fail('DELIVERY_REQUEST_CONFLICT','同一准备编号的内容已变化',409)
                return self.status(user,store_id,self._plan(user,store_id,prior['id'],platform))
            rows=[]
            with self.core.lock:
                for value in items:
                    expected={'customerId','leadId','sourceDigest','replyId','version','accountId'}
                    if not isinstance(value,dict) or set(value)!=expected:fail('INPUT_INVALID','请逐条选择原评论、已审核草稿与本人账号')
                    if (type(value['version']) is not int or value['version']<1
                            or any(not isinstance(value[k],str) or not KEY.fullmatch(value[k]) for k in expected-{'version'})):
                        fail('INPUT_INVALID','原评论、草稿版本或账号格式无效')
                    read=(self.replies.read(user,store_id,value['customerId'],platform=platform)
                          if platform is not None else self.replies.read(user,store_id,value['customerId']))
                    source=next((r for r in read['comments'] if r['id']==value['leadId']),None)
                    if (not source or not source['reviewCurrent'] or not source['draft']
                            or source['sourceDigest']!=value['sourceDigest'] or source['draft']['id']!=value['replyId']
                            or source['draft']['version']!=value['version']
                            or source['draft']['review_account_id']!=value['accountId']):
                        fail('DELIVERY_REVIEW_REQUIRED','请先逐条保存并核对当前原评论、草稿与本人账号',409)
                    reply=self.core._get('replies',value['replyId'],user['tenant_id'])
                    lead=self.core._get('leads',value['leadId'],user['tenant_id'])
                    account=self.core._get('accounts',value['accountId'],user['tenant_id'])
                    rows.append({**value,'text':reply['text'],'customerName':read['item']['name'],
                        'comment':source['text'],'postTitle':source['postTitle'],'postUrl':source['postUrl'],
                        'recipient':self.core._reply_recipient(lead,'comment',user=user,account=account),
                        'authorId':str(lead.get('author_id') or ''),'accountName':str(account.get('platform_nickname') or account.get('name') or '本人账号'),
                        'accountUid':str(account.get('platform_uid') or ''),'snapshot':reply['approval_snapshot']})
                if len({r['replyId'] for r in rows})!=len(rows):fail('INPUT_INVALID','本批原评论草稿不能重复')
                if len({r['accountId'] for r in rows})!=1:fail('INPUT_INVALID','本批请选择同一个本人执行账号；不同账号请分别准备')
                for previous in self.core.store.list(ENTITY,user['tenant_id']):
                    if previous.get('userId')==user['id'] and previous.get('state')=='submitted':
                        prior=self.core._get('reply_queues',previous['queueId'],user['tenant_id'])
                        if prior.get('status') in ('ready','awaiting_collection','running') and any(
                            r['replyId'] in {x['replyId'] for x in previous['items']} for r in rows):
                            fail('DELIVERY_UNCONFIRMED','所选草稿已有待核对发送批次，请先查看或取消原批次',409)
                queue=self.core.handle('prepare_reply_queue',{'reply_ids':[r['replyId'] for r in rows],
                    'account_id':rows[0]['accountId'],'confirmed':True},user)
                ident=uuid4().hex
                plan={'id':ident,'tenant_id':user['tenant_id'],'userId':user['id'],'owner':user['username'],
                    'createdAt':datetime.now(timezone.utc).isoformat(),
                    'storeId':store_id,'state':'prepared','items':rows,'queueId':queue['id'],
                    'prepareRequestId':data['requestId'],'prepareSignature':digest(items),
                    'snapshotDigest':digest([ident,rows])}
                self.core.store.put(ENTITY,plan)
            return self.status(user,store_id,plan)
        plan=self._plan(user,store_id,data['id'],platform)
        if action=='reply_delivery_status':return self.status(user,store_id,plan)
        if action=='reply_delivery_cancel':
            self.core.handle('cancel_reviewed_reply_queue',{'id':plan['queueId']},user)
            return self.status(user,store_id,plan)
        if (data['confirmed'] is not True or data['snapshotDigest']!=plan['snapshotDigest']
                or not isinstance(data['requestId'],str) or not KEY.fullmatch(data['requestId'])):
            fail('DELIVERY_CONFIRM_REQUIRED','请完整核对本批对象、原评论、正文和账号后明确授权',409)
        if plan['state']!='prepared':
            if data['requestId']==plan.get('requestId'):return self.status(user,store_id,plan)
            fail('DELIVERY_ALREADY_AUTHORIZED','本批已经授权或结果待核对；不会重复发送',409)
        if self.runtime is None:fail('PLATFORM_UNAVAILABLE','平台后台尚未就绪',503)
        with self.core.lock:
            for row in plan['items']:self._target(user,store_id,row)
            for ident,active in list(self.active.items()):
                previous=self.core._get('reply_queues',active['plan']['queueId'],user['tenant_id'])
                if previous.get('status') in ('ready','awaiting_collection','running'):
                    if any(r['replyId'] in {p['replyId'] for p in active['plan']['items']} for r in plan['items']):
                        fail('DELIVERY_BUSY','原草稿已有正在授权的批次，请先核对或取消原批次',409)
                else:self.active.pop(ident,None)
            plan={**plan,'state':'submitted','requestId':data['requestId']}
            self.core.store.put(ENTITY,plan)
            self.active[plan['id']]={'plan':plan,'refresh':refresh}
        try:
            is_xhs=(platform=='xiaohongshu' or self.core._get('accounts',plan['items'][0]['accountId'],user['tenant_id']).get('platform')=='xiaohongshu')
            if is_xhs and hasattr(self.core,'_reviewed_reply_registration'):
                from core.reply_execution_policy import mint,reviewed_scope
                def live_guard():
                    current_user,current_profile=refresh()
                    if current_profile.get('_workbench_store_id',current_profile.get('store_id'))!=plan['storeId']:
                        fail('STORE_FORBIDDEN','门店范围已变化，本批已停止',403)
                    if not self.core.lock.acquire(blocking=not self.core.adapters.lifecycle_lock.locked()):
                        raise AdapterBusy('原后台正在变更账号状态，本条尚未放行')
                    try:
                        active=self.active.get(plan['id'])
                        if not active or active['plan']!=plan:fail('DELIVERY_AUTH_EXPIRED','本批原授权已结束',409)
                        for value in plan['items']:
                            current=self.core._get('replies',value['replyId'],current_user['tenant_id'])
                            if current.get('status')!='sent':self._target(current_user,store_id,value,allow_sending=True)
                    finally:self.core.lock.release()
                decision=mint(self.core,self.runtime,plan,user,live_guard)
                self.active[plan['id']]['decision']=decision
                with reviewed_scope(decision):self.runtime.start_reply_queue(user,plan['queueId'])
            else:self.runtime.start_reply_queue(user,plan['queueId'])
        except Exception as error:
            queue=self.core._get('reply_queues',plan['queueId'],user['tenant_id'])
            if queue.get('status')=='ready':
                plan={**plan,'state':'blocked','error':str(error)};self.core.store.put(ENTITY,plan)
                self.active.pop(plan['id'],None)
            else:
                fail('DELIVERY_RESULT_UNCONFIRMED','发送授权结果待核对，请只读取本批状态；不会重复提交',409)
        return self.status(user,store_id,plan)
