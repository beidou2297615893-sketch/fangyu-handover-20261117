from pathlib import Path
import hashlib,json,shutil,ast
T=Path(__file__).resolve().parent.parent;OLD=T/'component';NEW=T/'component-v2'
assert not NEW.exists()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest().upper()
read=lambda p:json.loads(p.read_text('utf-8-sig'))
before={p.relative_to(OLD).as_posix():sha(p) for p in (OLD/'inputs-source').rglob('*') if p.is_file()}
for n in ('INPUTS.json','build_inactive_component.py','build_tool_entry.py','build_child_entry.py','build_io_fence.py'):before[n]=sha(OLD/n)
NEW.mkdir();shutil.copytree(OLD/'inputs-source',NEW/'inputs-source')
for n in ('build_inactive_component.py','build_tool_entry.py','build_child_entry.py','build_io_fence.py'):
 shutil.copy2(OLD/n,NEW/n);ast.parse((NEW/n).read_bytes())
manifest=read(OLD/'INPUTS.json')
for row in manifest['inputs']:
 if str(row.get('target') or '').startswith('source/'):row['path']=str(NEW/'inputs-source'/Path(row['target']).relative_to('source'))
added=[]
for rel in ('core/customer_intent_dirty.py','core/customer_intent_materials.py'):
 source=T/'assembly/project/work/ui-runtime-r55/src'/rel;target=NEW/'inputs-source'/rel
 assert not target.exists();shutil.copy2(source,target)
 row={'path':str(target),'target':'source/'+rel,'bytes':target.stat().st_size,'sha256':sha(target),'role':'app_source','digest_basis':'actual_bytes'}
 manifest['inputs'].append(row);added.append({**row,'finalSourcePath':str(source),'finalSourceSha256':sha(source)})
sourcepins={p.relative_to(NEW/'inputs-source').as_posix():sha(p) for p in (NEW/'inputs-source').rglob('*') if p.is_file()}
manifest['source_closure_sha256']=hashlib.sha256(json.dumps(sourcepins,sort_keys=True).encode()).hexdigest().upper()
(NEW/'INPUTS.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n','utf-8')
for n,h in before.items():assert sha(OLD/n)==h,n
report={'status':'PREPARED_NOT_BUILT','inputs':len(manifest['inputs']),'sourceFiles':len(sourcepins),'addedSources':added,'inputSha256':sha(NEW/'INPUTS.json'),'sourceClosureSha256':manifest['source_closure_sha256'],'unchangedOriginalComponent':before,'builders':{n:sha(NEW/n) for n in ('build_inactive_component.py','build_tool_entry.py','build_child_entry.py','build_io_fence.py')},'wrapperSha256':manifest['wrapper_sha256'],'compiled':False,'platformCalls':0}
(NEW/'SOURCE-ORIGINS.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n','utf-8')
print(json.dumps({k:v for k,v in report.items() if k not in ('unchangedOriginalComponent','addedSources','builders')},ensure_ascii=False))
