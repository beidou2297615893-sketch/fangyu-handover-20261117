"""Real SQLite, existing receiver, and lock-order regressions. No model I/O."""
from copy import deepcopy
import importlib.util
from pathlib import Path
from types import SimpleNamespace
import os,sys,tempfile,threading,time,unittest

W=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('reply_complete_concurrency_harness',W.parent/'reply-complete-20261026/real-e2e/harness.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
BASE=W/'assembly/project'
RELEASE=Path(os.environ['SCOPE_TEST_NATIVE'])
MODULES=h.load_modules(SimpleNamespace(candidate=RELEASE,project=BASE,release=RELEASE,
    provider_file=RELEASE/'reply_official_codex.py'))

class CompleteConcurrency(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(dir=W/'evidence');self.addCleanup(self.temp.cleanup)
        source=next(r for r in h.read(h.SOURCE) if r['sequence']==59)
        self.f=h.BackendFixture(Path(self.temp.name),MODULES,[source])
        output={'relationship':'本人询问','need':'按原话','fit':'待核实','reason':'隔离测试',
            'reply':'可以看看我住的方隅。','unknown':[],'shouldReply':True}
        self.workflow=MODULES['workflow'].Workflow(self.f.b,lambda *a:deepcopy(output),local_identity=self.f.identity)
        self.f.b.context_reply_workflow=self.workflow
        self.data={'storeId':'store1','accountId':'account1','platform':'xiaohongshu',
            'tone':'自然简短','styleMode':'store','customerIds':['case59'],'requestId':'concurrency'}
        view=self.f.dispatch('reply_ai_read',self.data)['replyAI']
        self.data['expectedToneRevision']=view['savedTone']['revision']
        job=self.f.dispatch('reply_ai_start',self.data)['replyAI']
        self.job=h.wait_job(self.f,self.data,job,self.workflow,timeout=5)
        self.assertEqual(self.job['rows'][0]['status'],'ready')

    def test_new_member_between_confirmation_check_and_legacy_write_blocks_receiver(self):
        row=self.job['rows'][0];original=self.f.b._dispatch;changed=[]
        def race(action,payload,token):
            if action=='reply_save' and not changed:
                lead=deepcopy(self.f.store.get('leads',row['leadId']))
                lead.update(id='new-history-member',comment_id='new-platform-comment',text='已经租好了，别联系了')
                self.f.store.put('leads',lead)
                self.f.customers['case59']['ids'].append(lead['id']);changed.append(True)
            return original(action,payload,token)
        self.f.b._dispatch=race
        self.f.dispatch('reply_ai_confirm',{**self.data,'jobId':self.job['id'],
            'leadId':row['leadId'],'confirmationKey':row['confirmationKey'],'confirmed':True})
        self.assertTrue(changed)
        self.assertFalse(any(r['lead_id']==row['leadId'] for r in self.f.store.list('replies',self.f.user['tenant_id'])))
        self.assertEqual(self.f.store.list('voice_samples',self.f.user['tenant_id']),[])
        self.assertEqual(self.f.store.list('reply_queues',self.f.user['tenant_id']),[])

    def test_transaction_authorize_never_waits_for_ui_or_core_lock(self):
        row=deepcopy(self.f.store.get(MODULES['workflow'].ENTITY,self.job['id'])['rows'][0])
        scope=self.f.store.get(MODULES['workflow'].ENTITY,self.job['id'])['scope']
        for lock in (self.f.b.lock,self.f.core.lock):
            with self.subTest(lock='ui' if lock is self.f.b.lock else 'core'):
                held=threading.Event();begin=threading.Event();finished=threading.Event();errors=[]
                def cancel_like_writer():
                    try:
                        with lock:
                            held.set()
                            if not begin.wait(2):raise AssertionError('registration did not begin')
                            # This writer waits on the adapter reservation while
                            # holding the outer lock, exactly like UI cancel.
                            self.f.store.put('isolated_cancel_marker',{'id':'marker','tenant_id':scope[0]})
                    except BaseException as e:errors.append(e)
                    finally:finished.set()
                thread=threading.Thread(target=cancel_like_writer);thread.start()
                self.assertTrue(held.wait(1))
                with self.f.store.connect() as db:
                    db.execute('BEGIN IMMEDIATE');begin.set();start=time.monotonic()
                    allowed=self.workflow.provider_authorized(self.job['id'],row,h.TOKEN,self.data,scope)
                    elapsed=time.monotonic()-start
                    self.assertFalse(allowed);self.assertLess(elapsed,.5)
                thread.join(2);self.assertFalse(thread.is_alive());self.assertTrue(finished.is_set());self.assertEqual(errors,[])

if __name__=='__main__':unittest.main(verbosity=2)
