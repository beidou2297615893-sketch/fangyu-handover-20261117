"""Relocate already accepted synthetic regressions; preserve their assertions."""
from pathlib import Path
import hashlib, json

T = Path(__file__).resolve().parent
B = T.parent / 'multi-account-reply-20261026'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
pins = {}
for sub in ('tests', 'backend/tests', 'frontend/tests'):
    target = T / sub
    target.mkdir(parents=True, exist_ok=True)
    for p in (B / sub).iterdir():
        if not p.is_file() or p.suffix not in ('.py', '.mjs', '.cjs', '.json'):
            continue
        out = target / p.name
        body = p.read_text('utf-8-sig')
        body = body.replace(str(B).replace('\\', '/'), str(T).replace('\\', '/'))
        body = body.replace(str(B).replace('\\', '\\\\'), str(T).replace('\\', '\\\\'))
        if p.name in ('test_frontend.mjs', 'test_frontend_browser.mjs'):
            body = body.replace("root+'/candidate/web/", "root+'/assembly/project/work/ui-approved-implementation/ui-preview/")
        # The previous task already relocated concurrency's legacy harness.
        out.write_text(body, 'utf-8')
        pins[str(p)] = sha(p)
for name in ('test_served_closure.py', 'run_final_ui_contracts.py', 'verify_integrated.py'):
    p = B / name
    (T / name).write_bytes(p.read_bytes())
    pins[str(p)] = sha(p)
for sub in ('evidence', 'shared', 'verification'):
    (T / sub).mkdir(exist_ok=True)
(T / 'REGRESSION-SOURCE-PINS.json').write_text(json.dumps(pins, indent=2), 'utf-8')
print(json.dumps(dict(prepared=len(pins), assertionsPreserved=True)))
