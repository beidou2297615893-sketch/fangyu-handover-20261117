# 实际 host 合成启动夹具修正批准

2026-10-27，Astra。

批准当前批次完成后，将 startup-fixture-fix.py 精确内容复制至 tests/test_native_complete_startup.py，并用新的 --run-name 执行一次启动验证。批准 SHA256：d2fa2c2ba3b6f5f471d1c34567caae43234d548a4ac709b28c7570825153d370。该文件不能从其临时根目录直接运行，因为 T 基于 tests 位置计算。

已阅读完整最终脚本及 patch。原产品使用本地 SQLite file URI；原 audit 把 URI 当普通文件系统路径而误拒绝。修正仅接受无 netloc/fragment 的 file URI、唯一 mode=rw 或 mode=ro，URL 解码并 resolve 后仍必须位于新合成 fixture 目录。所有真实数据库、凭据、network、Popen/UI 与外部写入仍拒绝。新增自身源码及两个材料文件的精确只读许可，替代先前整个 materials 目录许可。

实际测试仍通过 frozen host.create_backend、真实 Core/PlatformRuntime 与原工厂，检查五个 API、sender registration、lazy reader registration、完整材料及 holds；新增 engine/bridge/adapters 的 AdapterBusy 必须同一对象，无重绑定生产异常。完成后必须正常关闭 backend。

此次仅修测试夹具，不修改 source/release/材料；旧失败结果保留，未预判重试 PASS。源 URI 小例由作者验证 4 允许/4 拒绝，已取得报告；最终实际 host 结果另行核对。
