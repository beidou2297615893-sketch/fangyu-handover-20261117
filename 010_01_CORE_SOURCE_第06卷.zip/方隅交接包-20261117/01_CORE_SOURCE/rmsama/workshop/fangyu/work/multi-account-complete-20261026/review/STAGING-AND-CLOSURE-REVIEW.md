# 候选固化与闭包核验审查

2026-10-27，Astra。

APPROVED_FOR_ISOLATED_CANDIDATE_STAGING_AFTER_V2_MATERIAL_REPLACEMENT

已审 freeze_complete.py SHA256 11554b807a62f96d0fcd3f50bed7b412edd9d4e2e60b8887b7cbe91ea8af5b15 与 review_source_closure.py SHA256 3bc4223ca5270c4a74545da8c7f576e9fdcf3934de671ae7e2d02a23c0456da4。

允许 root 在 component-v2 独立构建与真实本地合成验收完成、候选中的新 helper 全树及两个材料替换为该版本后，执行本 task 的 --stage-prepared-candidate。装配映射须仍只落 task/assembly/project；若 assembler 代码变化，先审新差异。当前失败的161252组件不得作为最终放行材料。

脚本先核完整 baseline/overlay/材料集合、原基线及 live canonical 摘要，仅改独立候选 provenance；SOURCE 既有 source_sha256 和 previous_provenance 保留，仅刷新 candidate_sha256，新增项 source_sha256=null。材料复制到独立证据路径而不以目标文件自身充当来源。固定解释器只运行候选 freezer --stage，不 promote、不安装、不开业务窗口。

最终 UNIFIED-PINS 枚举候选整个项目，包含新 work/reply-complete-worker 外置 helper；闭包复核已增加 externalRuntimeMaterial 与所有 work/app/src 镜像的明确映射，并检查两份材料中的每个来源/运行文件、完整 helper runtimeTree 集合、RELEASE 中材料原字节、原Coordinator/Journal保护以及上游 SOURCE 历史摘要。

注意：本批准是候选固化与静态核验步骤的执行批准，不能当最终运行验收或安装批准。固化后仍须合成整合回归、精确源批准、云许可材料对齐及 next-launch 审查。脚本不得把 production business_data_access 的旧 plan 展示字段误当已运行生产业务。

另已复核 backend/SOURCE-PINS 当前18项全部与candidate一致，DELIVERY已更新读取20/发送租约7，前一报告的这项元数据阻断现已关闭。

## 第二版装配来源更新

重新通读 assemble_complete.py，当前SHA256 9753c2d8a14de4166f9f2d3b8c7542399a0b9561af1cf575dfd89f70ddfc9660 可用。helper来源改为 component-v2/artifacts/platform-cli-customer-read，目标仍为独立候选 work/reply-complete-worker/component/artifacts/platform-cli-customer-read；其余映射、材料生成、只改候选边界保持。批准在v2完整输出核对并完成实际合成验收后再次 --apply-candidate-only；若旧helper在目标留下v2不存在的额外文件，必须作为明确候选残留处理，不能将其悄悄纳入新材料；固化的完整集合检查应拒绝该残留。
# v3 候选刷新补充（2026-10-27）

最新 assembler SHA256 为 9ea218d91313cd813b90cdbdb0e42832dad47de9a25123e0500bbfbf75f1ce96，helper 源仅进一步更新为 component-v3/artifacts/platform-cli-customer-read，原 NEW/component/artifacts/platform-cli-customer-read 目标保持。此前 staging 条件继续适用，v3 编译及真实 loopback 验收通过后可按此 assembler 更新候选并执行已审 freeze；尚不是最终安装批准。

此次相关最终候选 pins：reply_read_session.py 2641e5c9bb9d3227e31adecab1c7519319ee4bb4c2a08d28dc1e5af8d030bbfb；reply_public_profile.py f90b0e06d3d6f58a066a80af2667b3ba7b8b6a25d74e92a480be2291a9ff2f08；worker 07b840298caf36a30a0c047387865e0989a5b7cce3f6c046aea18b4d0d33a13c。应纳入最终 metadata/source closure，不沿用旧的父读模块 pins。

