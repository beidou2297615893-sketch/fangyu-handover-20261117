from pathlib import Path
T=Path(__file__).resolve().parent.parent
p=T/'tests/backend/test_public_read.py';s=p.read_text('utf-8-sig');s=s.replace("data={'user_id':'customer-uid','desc':'想租一室，可以养猫吗'}","data={'subjectId':'customer-uid','identitySource':'response_uid','user_id':'customer-uid','desc':'想租一室，可以养猫吗'}");p.write_text(s,'utf-8')
p=T/'tests/backend/test_public_worker.py';s=p.read_text('utf-8-sig');s=s.replace("{'user_id':'target','desc':'明确找租房'})","{'subjectId':'target','identitySource':'response_uid','user_id':'target','desc':'明确找租房'})");p.write_text(s,'utf-8')
p=T/'assemble_complete.py';s=p.read_text('utf-8-sig');assert s.count("T/'component-v2/artifacts/platform-cli-customer-read'")==1;s=s.replace("T/'component-v2/artifacts/platform-cli-customer-read'","T/'component-v3/artifacts/platform-cli-customer-read'");p.write_text(s,'utf-8')
