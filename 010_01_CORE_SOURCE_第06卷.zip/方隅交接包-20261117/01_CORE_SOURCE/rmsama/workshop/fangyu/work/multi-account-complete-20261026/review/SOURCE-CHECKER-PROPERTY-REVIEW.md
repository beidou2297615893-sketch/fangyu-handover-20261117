# 源码闭环检查器 property 规则修正

2026-10-27，Astra。

批准以 review_source_closure.py 最终 SHA256 af26396ffba320a92031e0b6d8a52f5a8f6d7066377de677837f8795583d7176 重新执行原只读 source closure 检查。

已审新增 assert_unique_definitions：仅 class 内同步方法允许合法 property 重复名称，首次必须外层 @property，后续必须外层同名 getter/setter/deleter 且每种最多一次；普通重复、异名 modifier、重复 setter 等继续拒绝。改动纠正已冻结第三方 webview/dom/element.py 的正常 property/setter 被误判，不改 frozen/vendor 源码。其余闭环、来源和哈希检查保持。

已读独立小例结果：2 正向、6 负向，以及 114 个变更 Python 文件的 AST 检查通过，无剩余重复。此次只批准检查器运行，不把尚未执行的全 source closure 当作通过。
