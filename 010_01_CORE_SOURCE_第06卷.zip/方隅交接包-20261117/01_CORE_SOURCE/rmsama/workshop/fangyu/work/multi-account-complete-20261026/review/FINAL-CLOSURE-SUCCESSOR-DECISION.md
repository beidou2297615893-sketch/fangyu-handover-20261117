# 最终闭环后继候选决策

2026-10-27，Astra。

ui-r57-20261027T005628Z-067cb696 保持不可变，但不能安装：CustomerWorkbench.DEPENDENCY_SHA256 仍将 assistant/business.py 固定为旧 06F6B87C3ABCEB8048362B6E887FB7772A55C74B5EDCFCC3B4BF3657A611DDF2；新模块实际为 8a41ef172662c5c3f684cb4dcc9fe1050c786eb48971bf8d6abd7c0f4a3a9d3c。真实 customer constructor 会拒绝，是产品集成阻断，不是启动夹具误报。

独立扫描 CHANGES.final 中全部变更 Python 文件的旧 SHA，在 assembly 非 release Python 全树查引用，唯一残留为 customer_workbench.py 上述条目。无依据扩大改动或解除信任检查。

批准新后继目录 C:/积木软件工坊/项目/方隅公寓客户版/work/multi-account-complete-20261027-final：从已核 ba1 基线 clean bootstrap，复用本任务已审候选，仅增加 customer_workbench.py 的该一行 expected hash 更新。先修对应测试夹具的旧文案/路径与已审 SQLite URI audit，在冻结前跑代表性现有 backend 和启动依赖验证。不得原地修改旧冻结 source。

复用 v3 EXE 998831579f4f2a729039d3d0924d69fb9da09f820e965403a93681ed03452d31 及完整 291 文件 tree；不重编，不重复派发已通过四个组件场景。复用证据表必须写旧结果路径及 SHA，不能把旧任务的整体 FAIL 或审批拷贝成新任务 PASS。

新候选目录标准结构继续为 assembly/project，相对 helper 路径不变；所有 sources/material/closure/canonical digest 重新计算，云 allowlist 随新材料重审。只有新候选最终 source closure、完整回归、真实 host 单模块图通过后才能签新云部署及 next-launch 精确批准。当前任务尚未批准云部署或客户端安装。
