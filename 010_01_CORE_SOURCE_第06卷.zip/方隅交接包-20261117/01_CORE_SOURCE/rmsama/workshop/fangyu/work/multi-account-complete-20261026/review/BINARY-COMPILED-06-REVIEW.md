# 第六次实际组件负向验收批准

2026-10-27，Astra 独立审查。

APPROVED_FOR_ONE_COMPILED_LOOPBACK_FIXTURE_RUN_06

仅批准 root 在新 binary-e2e/compiled-06 目录执行一次 harness-v4 --compiled-reviewed，仅 wrong-uid、response-conflict 两个负向案例。仍使用 component-v3/artifacts/platform-cli-customer-read/platform-cli-customer-read.exe 及 ba1ea294 原只读基线，不重编组件、不修改生产代码。

- harness-v4.py：40c9fb845d0e54bce3cd5c582a7d19d7507da548abaad02272f7483431c0eedd
- EXE：998831579f4f2a729039d3d0924d69fb9da09f820e965403a93681ed03452d31
- safety.py：08c0419c06a1fb10dfffd08166659f7f2d56004223f8bb207c5dd2d821cea980
- tests/loopback_tls_fixture.py：502a925a3b489bd4063c5fb8a5940123519fb54759bec6c2620175a6e9969edf
- 复用 compiled-05/RESULT.json：4533E9952215F542327CAC110793B8F3398507C71EA0F8DCEBF7DFFB7254C361
- 复用 compiled-05/SYNTHETIC-COMPONENT-REGISTRATION.json：1ABFF5F5CAC05ACFB3189FA5AA8523E738D8714F02FB80F506D4212481A1AFFE

已独立复核上述实际哈希，v3 FROZEN 与 runtime tree 沿用 BINARY-COMPILED-05-REVIEW.md。已完整审查 v3→v4 diff：唯一 fixture 语义修正是 test.em.AdapterBusy 指向当前 adapters_module.AdapterBusy，并断言 engine fixture、bridge、adapters 使用同一个类。没有更改 catch、原队列状态判定或吞掉异常。两源 AdapterBusy AST 均为 RuntimeError 的空子类。已读取纯源 probe 脚本和 PASS 结果：修前类身份不同、修后相同；合成 AdapterBusy 返回 approved 且零 POST，普通 RuntimeError 保持 unknown。最终生产 host 单模块图身份仍须独立验证，不用此重绑定替代。

本次明确只执行两负向案例；read/send 复用 compiled-05 同一 EXE 的两项已通过证据，脚本校验原注册 EXE 哈希并记录来源路径/证据哈希，不能称本次重新执行四项。compiled-05 整体 FAIL 保持不改。

沿用全部空 HOME/合成凭据、固定 child flags、隐藏进程、loopback TLS、代理/NO_PROXY、禁止响应器转发及真实平台/账号/模型/生产数据操作的边界。仅一次运行；失败保留诊断，不自动重跑。本条不是安装、部署或真实业务授权。
