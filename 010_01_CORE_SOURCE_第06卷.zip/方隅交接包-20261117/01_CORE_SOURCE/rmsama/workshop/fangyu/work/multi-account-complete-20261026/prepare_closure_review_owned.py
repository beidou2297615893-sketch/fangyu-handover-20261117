from pathlib import Path
import ast
T=Path(__file__).resolve().parent
p=T/'review_source_closure.py';s=p.read_text('utf-8')
needle="    for name, row in changes.items():\n        path = project / name"
new="""    # Independently verify both published source/runtime contracts, including
    # the new external worker closure. No local JSON grants send permission.
    material_coverage={}
    for filename,protocol,flag in (
        ('reply_public_read_materials.json','reply-profile-read-v1','--owned-xhs-cli-pages'),
        ('reviewed_reply_materials.json','reviewed-reply-v1','--owned-xhs-reviewed-reply')):
        material=read(release/filename)
        assert material['version']==1 and material['protocol']==protocol and material['helperFlag']==flag
        assert sha(project/'work/ui-native-r57'/filename)==sha(release/filename)
        assert isinstance(material['sources'],dict) and material['sources']
        assert isinstance(material['runtimeTree'],dict) and material['runtimeTree']
        assert not any(Path(n).name in ('reply_public_read_materials.json','reviewed_reply_materials.json') for n in material['sources'])
        for n,h in {material['executable']:material['executableSha256'],**material['sources'],**material['runtimeTree']}.items():
            target=(project/n).resolve()
            assert not Path(n).is_absolute() and target.is_relative_to(project.resolve())
            assert closure_map[n]==h==sha(target),n
            material_coverage[n]=h
        helper_prefix='work/reply-complete-worker/component/artifacts/platform-cli-customer-read/'
        assert {n for n in closure_map if n.startswith(helper_prefix)}==set(material['runtimeTree'])
    provenance_name='work/shared-backend-integration/vendor-src/SOURCE.json'
    provenance=read(project/provenance_name)
    old_provenance=read(Path(read(TASK/'assembly/BASE-COPY.complete.json')['source'])/provenance_name)
    for n,row in provenance['files'].items():
        assert sha(project/'work/shared-backend-integration/vendor-src'/n)==row['candidate_sha256'],n
        assert row.get('source_sha256')==old_provenance['files'].get(n,{}).get('source_sha256'),n
    for name, row in changes.items():
        path = project / name"""
assert needle in s;s=s.replace(needle,new,1)
s=s.replace("            assert name=='work/app/src/core/store.py' and row['mirrorOf']=='work/ui-runtime-r55/src/core/store.py'", "            assert name.startswith('work/app/src/')\n            assert row['mirrorOf']=='work/ui-runtime-r55/src/'+name.split('work/app/src/',1)[1]")
s=s.replace("        elif name != 'work/ui-native-r57/freeze_ui.py':", "        elif row.get('externalRuntimeMaterial'):\n            assert name.startswith('work/reply-complete-worker/')\n            assert material_coverage[name]==row['after'],name\n        elif name != 'work/ui-native-r57/freeze_ui.py':",1)
ast.parse(s);p.write_text(s,'utf-8')
ast.parse((T/'freeze_complete.py').read_text('utf-8-sig'))
print('freeze/review scripts syntax PASS; no freeze executed')
