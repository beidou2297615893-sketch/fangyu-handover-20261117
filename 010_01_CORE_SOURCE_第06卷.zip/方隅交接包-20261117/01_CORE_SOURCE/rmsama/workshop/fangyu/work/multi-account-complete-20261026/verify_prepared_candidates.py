from pathlib import Path
import ast,hashlib,json
T=Path(__file__).resolve().parent
pins={}
for p in sorted((T/'candidate').rglob('*')):
 if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc':
  if p.suffix=='.py':ast.parse(p.read_bytes(),filename=str(p))
  pins[p.relative_to(T).as_posix()]={'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'size':p.stat().st_size}
(T/'FINAL-CANDIDATE-PINS.json').write_text(json.dumps({'files':pins,'source':'current candidate bytes; no assembly applied','count':len(pins)},ensure_ascii=False,indent=2)+'\n','utf-8')
print(len(pins))
