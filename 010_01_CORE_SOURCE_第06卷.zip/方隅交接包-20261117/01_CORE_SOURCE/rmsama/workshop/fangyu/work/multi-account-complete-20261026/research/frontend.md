# 多账号完整链：前端现状与最小接法

基线：已安装 ba1ea294 发布闭包，读取 `work/multi-account-reply-20261026/assembly/project/work/ui-native-r57/releases/ui-r57-20261026T130202Z-ba1ea294`。本轮未操作真实窗口、平台、采集或发送；旧闭包只读。

## 已有可复用链

- `web/pages/reply-delivery.mjs` 已有原队列：`prepareReviewedBatch(state,ctx,v,items)`→`reply_delivery_prepare`→逐条全文、账号、原评论最终授权modal→`reply_delivery_start`；状态/停止沿 `reply_delivery_status/cancel`。每项绑定customerId/leadId/sourceDigest/replyId/version/accountId，未知结果只能查询，最大20条。无需第二套队列。
- AI视图当前只露草稿保存与确认，未露原发送队列。最小补在已确认AI行/本组末尾增加“进入发送审核”，从原 `reply_read` 重新取approved/current快照，再调用原prepareReviewedBatch。确认草稿不等于发送授权；准备队列不等于发送成功；保留原最终确认。
- `runtime-r55/src/app.py:907` 原 `tracked_reply_start/status` 仅旧本机员工HTTP；native Workbench尚未暴露。其输入start为 `{reply_id,account_id,authorized:true,reply_trial?}`，status为 `{job_id}`。`TrackedReplyService` 已绑定原account/profile/UID、审核snapshot、已发送去重、权限配额时段、hold，暂停当前账号采集并等在途结束，打开指定受管网页观察。不可直接从web绕过去或把打开窗口算成功发送。
- 原 `account_verification_open`/account_job 是登录验证生命周期；`browser_session_open/check/status` 为原受管网页登录身份。静态account selection不证明session身份，不能直接标“已切换”。

## 本轮最小UI

1. 原推荐卡增加“读取公开主页资料”，从服务端解析的稳定subjectID发起；显示读取账号、准备/读取/完成/受限/待核对、来源URL、连续原文、读取时间与平台UID。手工原文与真实读取来源分清。未返回UID绑定/来源证据不显示“已读取”。完成后重新预览，已有assignment变旧需重选保存。
2. 每个已保存账号组增加“选择本组受管账号/打开本组账号窗口”及原操作状态查询。自动选择只有服务端exact独立session证明时显示“当前受管账号已核对”；需要登录、正在使用、UID不符、无隔离session均具体说明下一步。不能标成登录成功或放行发送。
3. AI已确认组增加原发送审核入口。显示当前账号身份核对状态与待处理数量；重新验证原稿后进入原queue最终modal。blocked/hold显示理由及“核对状态”，不放宽限制。需要单条受控网页路径时通过native受控契约桥接TrackedReplyService，并复用原job回执，不另造发送记录。
4. 保留profile/assignment/单条reopen/旧job兼容。读取/切号/准备队列分别使用原requestID与状态；未知结果不换ID自动重试。旧版本确认不搬号，改派后按上轮reopen显式生成新版本。

## 等后端冻结的契约

公开读与受管账号动作需返回：actor/store/platform/accountId/accountUid/subjectId、requestId、state、message、canStart/canRefresh、原status定位符；资料记录还需来源URL/连续原文/读取时间及不可伪造来源标记，session结果需exact session证明的产品化状态（不向人暴露本机路径或token）。状态字段必须区分操作已提交、身份已核对、资料已取得、受控发送已观察。

原queue动作及发送授权不改名。新capability action命名与payload等待Astra/后端确认后实现，不自造并行协议。

## 验证

新增实际DOM点击与mock原queue调用；离线headless宽/窄布局；空/过期/未知状态；cross-account/UID/来源变化阻断；单条reopen与原29组回归保留。发布版四类接口与源码sha核对，最终tests实际读release。合成截图仅技术验证，不当用户认可或平台真实验收。
