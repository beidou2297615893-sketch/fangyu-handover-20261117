import importlib.util,unittest,tempfile,sqlite3,json,time,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
S=importlib.util.spec_from_file_location('reply_policy',ROOT/'candidate/runtime/core/reply_execution_policy.py');m=importlib.util.module_from_spec(S);sys.modules[S.name]=m;S.loader.exec_module(m)
class PolicyTests(unittest.TestCase):
 def test_budget_is_durable_and_customer_scoped(self):
  with tempfile.TemporaryDirectory() as temp:
   db=Path(temp)/'budget.sqlite'
   m.consume_budget(db,'tenant','customer','reply','attempt','a'*64)
   with self.assertRaises(m.ReplyPolicyError):m.consume_budget(db,'tenant','customer','otherReply','newAttempt','b'*64)
   conn=sqlite3.connect(db);rows=conn.execute('select state from reviewed_reply_budget').fetchall();conn.close();self.assertEqual(rows,[('unknown',)])
 def test_forged_or_absent_context_has_no_permission(self):
  core=object();self.assertIsNone(m.current_decision(core))
  with self.assertRaises(m.ReplyPolicyError):
   with m.reviewed_scope({'authorized':True}):pass
 def test_registration_checks_actual_files(self):
  with tempfile.TemporaryDirectory() as temp:
   root=Path(temp);(root/'helper.exe').write_bytes(b'synthetic');(root/'worker.py').write_bytes(b'worker')
   manifest={'version':1,'protocol':'reviewed-reply-v1','helperFlag':'--owned-xhs-reviewed-reply','executable':'helper.exe','executableSha256':m.file_digest(root/'helper.exe'),'sources':{'worker.py':m.file_digest(root/'worker.py')}}
   reg=m.verify_registration(root,manifest,lambda *a:None);reg.check();(root/'worker.py').write_bytes(b'changed')
   with self.assertRaises(m.ReplyPolicyError):reg.check()
if __name__=='__main__':unittest.main()
