"""Independent source/overlay/publication verification; imports no business code."""
from pathlib import Path
from datetime import datetime, timezone
import ast
import hashlib
import json
import re
import subprocess

TASK = Path(__file__).resolve().parent
read = lambda p: json.loads(p.read_text('utf-8-sig'))
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()

def assert_unique_definitions(tree,filename):
    for scope in ast.walk(tree):
        body=getattr(scope,'body',None)
        if not isinstance(body,list):continue
        groups={}
        for node in body:
            if isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef)):
                groups.setdefault(node.name,[]).append(node)
        for name,nodes in groups.items():
            if len(nodes)==1:continue
            # A property decorator returns a new descriptor with the same
            # Python name. Accept only one initial getter and nonrepeated
            # same-name descriptor modifiers, never ordinary redefinitions.
            valid=isinstance(scope,ast.ClassDef) and all(isinstance(n,ast.FunctionDef) for n in nodes)
            first=nodes[0];seen=set()
            initial=[d for d in first.decorator_list if isinstance(d,ast.Name) and d.id=='property']
            valid=valid and len(initial)==1 and first.decorator_list[0] is initial[0] and not any(isinstance(d,ast.Attribute) and d.attr in ('getter','setter','deleter') for d in first.decorator_list)
            for node in nodes[1:]:
                modifiers=[d.attr for d in node.decorator_list if isinstance(d,ast.Attribute) and isinstance(d.value,ast.Name) and d.value.id==name and d.attr in ('getter','setter','deleter')]
                valid=valid and len(modifiers)==1 and isinstance(node.decorator_list[0],ast.Attribute) and isinstance(node.decorator_list[0].value,ast.Name) and node.decorator_list[0].value.id==name and node.decorator_list[0].attr==modifiers[0] and modifiers[0] not in seen and not any(isinstance(d,ast.Name) and d.id=='property' for d in node.decorator_list)
                seen.update(modifiers)
            assert valid,'Same-scope duplicate: '+filename+' :: '+name

def main():
    pins = read(TASK / 'FROZEN-PINS.json')
    project, release = Path(pins['project']), Path(pins['release'])
    baseline = read(TASK / 'assembly/BASE-COPY.complete.json')['files']
    changes = read(TASK / 'assembly/CHANGES.final.json')['files']
    closure = read(TASK / 'assembly/UNIFIED-PINS.json')
    assert sha(TASK / 'assembly/CHANGES.final.json') == pins['changesSha256']
    assert sha(TASK / 'assembly/UNIFIED-PINS.json') == pins['unifiedPinsSha256']
    expected_source = {**baseline, **{name: row['after'] for name, row in changes.items()}}
    closure_map = {row['path']: row['sha256'] for row in closure['files']}
    actual_files = {p.relative_to(project).as_posix() for p in project.rglob('*') if p.is_file()}
    assert actual_files == set(closure_map), 'Unexpected/missing closure files.'
    for name, digest in closure_map.items():
        assert sha(project / name) == digest, name
    for name, digest in expected_source.items():
        assert closure_map[name] == digest, name
    protected = ('work/ui-runtime-r55/src/assistant/browser_login_coordinator.py',
        'work/ui-runtime-r55/src/assistant/browser_session_commit.py')
    for name in protected:
        assert sha(project / name) == baseline[name], 'Core guard changed: ' + name
    checked = []
    dependency = read(release / 'resources/backend-dependencies.json')
    dependency_rows = {r['path']: r for r in dependency['files']}
    runtime_root = release / 'resources/platform-runtime'
    runtime_text = (runtime_root / 'platform_runtime.py').read_text('utf-8-sig')
    for key, name in (('_BROWSER_FIRST_SHA', 'browser_first.py'), ('_BROWSER_DRIVER_SHA', 'browser_first_driver.py')):
        match = re.search(key + r"\s*=\s*['\"]([0-9a-fA-F]{64})['\"]", runtime_text)
        assert match and match[1].lower() == sha(runtime_root / name), key
    driver_text = (runtime_root / 'browser_first_driver.py').read_text('utf-8-sig')
    helper_match = re.search(r"HELPER_SHA\s*=\s*['\"]([0-9a-fA-F]{64})['\"]", driver_text)
    assert helper_match and helper_match[1].lower() == sha(runtime_root / 'vendor-src/assistant/browser_first_window.py')
    helper_text = (runtime_root / 'vendor-src/assistant/browser_first_window.py').read_text('utf-8-sig')
    support_match = re.search(r"SUPPORT_SHA\s*=\s*['\"]([0-9a-fA-F]{64})['\"]", helper_text)
    assert support_match and support_match[1].lower() == sha(runtime_root / 'vendor-src/assistant/browser_login_window.py')
    # Independently verify both published source/runtime contracts, including
    # the new external worker closure. No local JSON grants send permission.
    material_coverage={}
    for filename,protocol,flag in (
        ('reply_public_read_materials.json','reply-profile-read-v1','--owned-xhs-cli-pages'),
        ('reviewed_reply_materials.json','reviewed-reply-v1','--owned-xhs-reviewed-reply')):
        material=read(release/filename)
        assert material['version']==1 and material['protocol']==protocol and material['helperFlag']==flag
        assert sha(project/'work/ui-native-r57'/filename)==sha(release/filename)
        assert isinstance(material['sources'],dict) and material['sources']
        assert isinstance(material['runtimeTree'],dict) and material['runtimeTree']
        assert not any(Path(n).name in ('reply_public_read_materials.json','reviewed_reply_materials.json') for n in material['sources'])
        for n,h in {material['executable']:material['executableSha256'],**material['sources'],**material['runtimeTree']}.items():
            target=(project/n).resolve()
            assert not Path(n).is_absolute() and target.is_relative_to(project.resolve())
            assert closure_map[n]==h==sha(target),n
            material_coverage[n]=h
        helper_prefix='work/reply-complete-worker/component/artifacts/platform-cli-customer-read/'
        assert {n for n in closure_map if n.startswith(helper_prefix)}==set(material['runtimeTree'])
    provenance_name='work/shared-backend-integration/vendor-src/SOURCE.json'
    provenance=read(project/provenance_name)
    old_provenance=read(Path(read(TASK/'assembly/BASE-COPY.complete.json')['source'])/provenance_name)
    for n,row in provenance['files'].items():
        assert sha(project/'work/shared-backend-integration/vendor-src'/n)==row['candidate_sha256'],n
        assert row.get('source_sha256')==old_provenance['files'].get(n,{}).get('source_sha256'),n
    for name, row in changes.items():
        path = project / name
        assert sha(Path(row['candidatePath'])) == row['after'] == sha(path), name
        if row['before'] is None:
            assert name not in baseline
        else:
            assert sha(Path(row['sourcePath'])) == baseline[name] == row['before'], name
        published = row['publishedRelativePath']
        if published is not None:
            assert sha(release / published) == row['after'], published
        elif row.get('mirrorOf'):
            assert name.startswith('work/app/src/')
            assert row['mirrorOf']=='work/ui-runtime-r55/src/'+name.split('work/app/src/',1)[1]
            assert sha(project/row['mirrorOf'])==row['after']
        elif row.get('externalRuntimeMaterial'):
            assert name.startswith('work/reply-complete-worker/')
            assert material_coverage[name]==row['after'],name
        elif name != 'work/ui-native-r57/freeze_ui.py':
            relative = row['backendDependencyRelativePath']
            assert name == dependency['source'] + '/' + relative
            assert dependency_rows[relative]['sha256'].lower() == row['after'], name
        if path.suffix == '.py':
            tree = ast.parse(path.read_text('utf-8-sig'), filename=name)
            assert_unique_definitions(tree,name)
        elif path.suffix == '.mjs':
            run = subprocess.run(['node', '--check', str(path)], capture_output=True,
                text=True, encoding='utf-8', errors='replace', timeout=30)
            assert run.returncode == 0, name + ': ' + run.stderr[-500:]
        checked.append(dict(path=name, published=published, sha256=row['after'],
                            sourceBefore=row['before'], owner=row['owner']))
    manifest = read(release / 'RELEASE.json')
    for row in manifest['files']:
        assert sha(release / row['path']).upper() == row['sha256'].upper(), row['path']
    report = dict(status='PASS_STATIC_SOURCE_CLOSURE', atUtc=datetime.now(timezone.utc).isoformat(),
        releaseId=pins['releaseId'], baselineSourceFiles=len(baseline),
        finalSourceFiles=len(expected_source), exactClosureFiles=len(closure_map),
        releaseFiles=len(manifest['files']), unchangedSourceFiles=len(baseline)-sum(r['before'] is not None for r in changes.values()),
        changedFiles=checked, originalCoordinatorAndJournalByteIdentical=True,
        productionDataAccess=False, realPlatformActions=False,
        limitation='Static closure/syntax checks only; behavioral evidence and Astra risk review required separately.')
    folder = TASK / 'independent'
    folder.mkdir(exist_ok=True)
    with (folder / 'ROOT-SOURCE-CLOSURE.json').open('x', encoding='utf-8') as stream:
        json.dump(report, stream, ensure_ascii=False, indent=2)
        stream.write('\n')
    print(json.dumps({key: value for key, value in report.items() if key not in ('changedFiles',)}, ensure_ascii=False))

if __name__ == '__main__':
    main()

