from pathlib import Path
T=Path(__file__).resolve().parent.parent
s=(T/'binary-debug/probe_minimal.py').read_text('utf-8-sig')
s=s.replace("T/'component/inputs-source'","T/'component-v2/inputs-source'")
s=s.replace("sys.meta_path.insert(0,MissingOnly())", "# No dependency injection: imports use real new snapshot only.\nimport sqlite3\nsqlite3.connect=blocked\nprobe_active=[True]\ndef audit(event,args):\n if probe_active[0] and event=='open':\n  mode=args[1];flags=args[2]\n  if (isinstance(mode,str) and any(c in mode for c in 'wax+')) or (isinstance(flags,int) and flags & (1|2|64|512|1024)):\n   raise RuntimeError('Source probe forbids writes')\nsys.addaudithook(audit)")
s=s.replace("r['status']='PASS';", """request={'attemptId':'synthetic_attempt','expectedUid':'b'*24,'noteId':'a'*24,'commentId':'c'*24,'text':'synthetic reply','requestDigest':'1'*64}
 auth=[]
 wire=sender.ExactWireGate(request,lambda phase,details:auth.append(phase))
 class Fake:
  def get_self_info(self):
   wire('GET','https://edith.xiaohongshu.com/api/sns/web/v2/user/me',{})
   return {'user_id':'b'*24}
  def reply_comment(self,*args):
   wire('POST','https://edith.xiaohongshu.com/api/sns/web/v1/comment/post',{'content':json.dumps(sender.post_body(request))})
   return {'id':'synthetic_response','user':{'user_id':'b'*24}}
 receipt=sender.run_once(Fake(),request,lambda *a:None,wire)
 assert receipt['success'] and auth==['identity','post']
 r['senderFakeProtocol']='PASS_NO_NETWORK'
 r['status']='PASS';""")
s=s.replace("r['missingDependenciesLoadedFromExactBaseline']=loaded", "probe_active[0]=False\nr['missingDependenciesLoadedFromExactBaseline']=loaded\nr['snapshot']='component-v2/inputs-source';r['networkProcessDatabaseWritesForbiddenDuringProbe']=True")
s=s.replace("MINIMAL-DEPENDENCY-PROBE.json","V2-SOURCE-PROBE.json")
(T/'binary-debug/probe_v2.py').write_text(s,'utf-8')
