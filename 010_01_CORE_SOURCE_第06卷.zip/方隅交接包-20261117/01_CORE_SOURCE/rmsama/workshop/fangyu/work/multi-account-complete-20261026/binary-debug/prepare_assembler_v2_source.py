from pathlib import Path
import ast,hashlib,json
T=Path(__file__).resolve().parent.parent
p=T/'assemble_complete.py';s=p.read_text('utf-8-sig')
old="addtree(T/'component/artifacts/platform-cli-customer-read',NEW+'/component/artifacts/platform-cli-customer-read')"
new="addtree(T/'component-v2/artifacts/platform-cli-customer-read',NEW+'/component/artifacts/platform-cli-customer-read')"
assert s.count(old)==1
before=hashlib.sha256(p.read_bytes()).hexdigest();s=s.replace(old,new);ast.parse(s);p.write_text(s,'utf-8')
report={'status':'SCRIPT_ONLY_NOT_APPLIED','file':str(p),'beforeSha256':before,'afterSha256':hashlib.sha256(p.read_bytes()).hexdigest(),'oldLine':old,'newLine':new,'targetUnchanged':'work/reply-complete-worker/component/artifacts/platform-cli-customer-read','assemblyApplied':False,'freezeExecuted':False}
(T/'binary-debug/ASSEMBLER-V2-SOURCE-DIFF.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n','utf-8')
pins={}
for f in sorted((T/'candidate').rglob('*')):
 if f.is_file() and '__pycache__' not in f.parts and f.suffix!='.pyc':pins[f.relative_to(T).as_posix()]={'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'size':f.stat().st_size}
(T/'FINAL-CANDIDATE-PINS.json').write_text(json.dumps({'files':pins,'source':'current candidate bytes; no assembly applied','count':len(pins),'assemblyScript':{'path':str(p),'sha256':report['afterSha256']},'helperSource':'component-v2/artifacts/platform-cli-customer-read','helperTarget':report['targetUnchanged']},ensure_ascii=False,indent=2)+'\n','utf-8')
print(json.dumps(report))
