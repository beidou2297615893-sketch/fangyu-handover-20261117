"""Extract fresh read-only backup into an owned candidate. Never deploy or read DB."""
from pathlib import Path,PurePosixPath
import hashlib,json,shutil,stat,zipfile
T=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_text('utf-8-sig'))
sha=lambda b:hashlib.sha256(b).hexdigest()
report=read(T/'readback-before/LIVE-READBACK.json')
assert report['productionWrites'] is False and report['freshFullBackupCreated']
archive=T/'readback-before/live-function-code.zip'
assert sha(archive.read_bytes())==report['codeZipSha256']
base=T/'live-before';candidate=T/'candidate';assert not base.exists() and not candidate.exists()
rows={r['path']:r for r in read(T/'readback-before/LIVE-CODE-FILES.json')};seen=set()
with zipfile.ZipFile(archive) as z:
 for info in z.infolist():
  if info.is_dir():continue
  name=info.filename;rel=PurePosixPath(name)
  assert not rel.is_absolute() and '..' not in rel.parts and '\\' not in name and ':' not in name and name.casefold() not in seen and not stat.S_ISLNK(info.external_attr>>16)
  seen.add(name.casefold());body=z.read(info);row=rows[name]
  assert len(body)==row['bytes'] and sha(body)==row['sha256']
  dest=base/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(body)
assert len(seen)==len(rows)==report['files']
shutil.copytree(base,candidate)
previous=T.parents[2]/'cloud-prompt-deployment-20261025/approved-code'
diff=[]
for name,row in rows.items():
 old=previous/name
 if not old.exists() or sha(old.read_bytes())!=row['sha256']:diff.append(name)
receipt=dict(status='FRESH_CURRENT_SOURCE_COPIED',treeSha256=report['treeSha256'],files=len(rows),priorDeploymentChangedFiles=diff,configRead=False,databaseRead=False,productionWrites=False)
(T/'BASELINE.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n','utf-8')
print(json.dumps(dict(status=receipt['status'],files=len(rows),priorChangedFiles=diff),ensure_ascii=False))
