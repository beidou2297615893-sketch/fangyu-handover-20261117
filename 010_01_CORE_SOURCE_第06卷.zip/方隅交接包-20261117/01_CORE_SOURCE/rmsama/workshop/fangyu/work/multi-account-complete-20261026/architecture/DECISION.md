# 完整多账号回复链：实现决策

日期：2026-10-26。基线：ba1ea294。决策者：Astra。仅代码与全合成隔离验证；本轮真实平台读取、登录窗口、对外发送均为零。

## 决定

复用注册 PageWorker 读取公开资料，复用既有账号独立 CLI 会话，复用 ReviewedReplyQueues 的明确确认、单账号顺序执行和原回执。发送采用同一客户端先核实际 UID、再最多执行一次精确回复的薄适配。不得把普通 CLI reply 全局解禁。现 tracked 人工窗口仅为已有手工工具，不作为新链身份阻断证据：其窗口在身份确认前可交互，观察器是事后观察，返回服务的结果还会丢失 sender UID。

终局入口：读取公开资料 → 查看证据与推荐 → 确定唯一账号 → 核对当前账号 → 生成及编辑 → 原审核 → 按账号确认发送。登录过期时沿原账号登录入口恢复，重新检查；不复制凭据，不自动修改绑定 UID。六账号切换是选择各自受管会话，不是对共享浏览器盲目点切号。

## 资料与会话边界

新增明确目的 reply_public_profile 和 reply_session_check。不伪装 task_run，不借身份恢复许可。动作名和字段以 backend/CONTRACT 为准，旧五个动作不变。

UI 只能提供已可见的 accountId、customerId、revision、requestId 和有界 limit；目标 UID、主页 URL、会话路径由服务端解析。私有 sealed claim 绑定 tenant、store、owner、device、account identity digest、canonical customer UID、requestId、过期时间和操作预算。每次 wire 重新校验主体、远端安全、账号使用权、会话、身份版本与 lease。

同一注册 worker、相同 HOME 与账号 OS 锁：whoami → user → 最多一页 user-posts → whoami。缺失或错误 actual UID 后不得继续读取。最多保存五条作者匹配的公开内容；没有正文就不声称已读正文。响应未给目标作者 UID 的内容不能以请求 UID 补成已核验。原文、来源 URL、抓取时间、对象及身份摘要落独立自动证据槽，手工槽保留且来源状态明确。完成时 CAS 校验 evidence revision 和 customer binding；取消及未知状态不得重新执行原请求。

adapters.execute 可增加私有 exact-type sealed claim 分支，在 xhs_page_runtime 之前明确选择注册 CLI 路线；无该 claim 的普通采集继续原中性浏览器优先路线。不得置空 runtime、静默 fallback 或借浏览器 Cookie。

## 发送能力与旧保护

本地 portable_employee_release、public_send_hold、xiaohongshu_automation=hold 是原产品未接通 gate。只允许新的、经过源和可执行文件摘要核验的正常能力决定，对一个已确认队列的精确回复范围放行这些本地 gate；配置值保持原状。platform_qa_device_id 内部只读模式不得借正常能力放行；不借 QA trial proof。

能力不是 UI 的 authorized 布尔值。服务端在原批次明确确认后创建私有 sealed generation/claim，绑定当前 actor/device/session、queue ID 与版本、账号 UID 与身份摘要、每条 reply ID/version/approval snapshot/routing digest、customer UID、note ID/comment ID、正文摘要、有效期、最多一次 POST。scope 在队列线程内明确传递；不得用全局开关或普通可构造字典。只读身份 proof 不携带发送权。

必须打通并同样校验的原路径：platform_runtime.reply_guard / start_reply_queue，BusinessExecutor 命令 guard，ReviewedReplyQueues.start/process，Core._public_reply_guard / _prepare_send / _send_reply，adapter/worker wire gate。本地 automation gate 可接受目的限定的 reviewed decision；remote_safety_hold、runtime unavailable、产品权限、can_reply、主体和设备状态、账户归属、原客户去重、原批准快照、routing CAS、账号 lease、额度、时间段、安全检查均继续运行。旧 legacy queue 的方隅拒绝保留。

原 manifest.reply_contract_verified=False 不全局翻真；新路径校验独立受控发送 manifest、源与 exe hash及对应 worker 协议，旧普通 reply 仍无能力。新 manifest 描述代码协议验证，不冒充真实平台验收。

## 单条真实传输契约

发送仍由原 _send_reply 将 sending 与 contact journal 持久化，再执行一次外部调用。新薄适配使用精确账号独立 HOME、账号 OS 锁、单一 XhsClient 与固定会话；先 GET /api/sns/web/v2/user/me，实际 UID 必须等于批准账号 UID。然后在第二个 wire 前再次校验 live claim、当前批准/routing/account fingerprint，只允许 POST /api/sns/web/v1/comment/post，目标 note/comment 与正文完全等于批准快照，at_users 空，不允许发布新评论、私信、关注或任意 URL。POST 预算在持久状态中先消费；没有自动重试、重定向或账号 fallback。

返回结构保留 platformCommentId、actualUid、responseSenderUid（平台未给则为 null）、identityProofSource、requestDigest、attemptId。明确平台成功且有唯一有效 comment ID 才可成功；响应有 sender UID 时必须相符。未给 sender UID 时只能记录同客户端前置 whoami 证据，不能伪造响应 UID。会话发生变化、响应冲突、超时、发送后持久化失败均进入原 unknown，禁止别账号或新 requestId 重试同一客户。只有可证明 POST 尚未放行的失败可以恢复可重试的待处理状态。

## 文件归属

- Backend Sol：reply read/session 服务、既有注册 PageWorker/ReadRequest 的 whoami/user 有界扩展、证据持久化与接口；保持旧五动作。
- Root：原队列正常能力决定、发送薄适配/专用 owned worker、相关原 guard 衔接、组件真实重编及闭包发布。
- Frontend Sol：资料读取、身份状态、原登录恢复入口、推荐/草稿/审核/分组确认串联，不自行生成授权能力。
- Astra：关键语义审查、独立最难链验收、最终精确源批准。

## 先验最难链与交付门

1. 六个全合成账号；客户推荐 B，实际会话 A：读取零 user/posts、发送零 POST。正确 B 只按 B 会话进行；A 的会话和中性采集会话不变。
2. 相同实例内正确 proof 后换 HOME/UID/账号身份、profile/assignment/evidence、批准正文或评论目标：下一 wire 拒绝；读取 proof 不可用于发送。
3. 默认本地三个 hold 均保持 true，正确 reviewed capability + 原明确确认可完成合成新传输；缺失/伪造/过期/其他 actor/store/device/queue 的 capability 均零 POST；远端 hold 及 QA 只读仍零 POST。
4. 两个独立 OS 进程竞争同条/同客户/同队列，仅一个 POST 被放行；持久化消费后进程死亡，恢复为 unknown，不重放。
5. 平台成功后本地写入失败、HTTP 超时、响应 sender 不符、缺 comment ID，全部 unknown；通过另一个账号、重新生成或新 requestId 不得重发。
6. 读取过程中主体变更、重复 wire、重定向、越界 cursor/limit、错误作者、注入文本、证据 CAS 竞争：拒绝或明确未知，保留旧证据/旧稿。
7. 默认采集、旧 approved/legacy 稿、原官方模型回执和 unknown锁、旧队列权限/额度/停止逻辑全部回归。
8. 实际重编后的受管 CLI 用注入的本地合成 transport 跑完整 helper 注册/协议；不能只测试 Python 源码而出旧 exe。测试保证平台 wire 为零。

以上通过可交付可操作代码链。真实平台响应兼容性与六个真实账号的登录配置仍由用户后续实际操作验证，不能在本轮伪称已经发送或已实采。
