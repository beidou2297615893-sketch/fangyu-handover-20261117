# 按账号人工登录与独立会话衔接审查

2026-10-27，Astra 静态审查。未打开浏览器，未登录或读取真实账号 cookie。

实际 native 1.1.8-pilot.1 的原账号页具备建立本次 CLI 独立会话的后端路径，无需增加自动切账号能力：platform_runtime.connect_account → AssistantService.start_account_login → browser_login_service → xhs_browser_login.start_persistent_login。source employee 原权限、远端状态及账号访问检查保留。每个账号使用 accounts/<tenant>/<account>/xhs-browser-profile；原成功捕获、身份核对与云端 claim 流程调用 browser_session_commit.commit_browser_session，将候选 cookie 经事务提交至同账号 .xiaohongshu-cli/cookies.json。这正是新 read/sender 所使用的 HOME；不会复制首页当前浏览器身份来冒充其他账号。

原 account_verification_open 是已有 owned profile 的人工验证窗口，缺少 profile 时拒绝，不能替代首次登录与 cookie 提交完整流程。新分组页原先将“打开该账号原登录窗口”接到 accountWebsiteOpen，存在入口误导；已由 Sol 最小修复。

审查修后 candidate/web/pages/reply-public-read.mjs（SHA256 6459631e83d1b3066de0de54d4ebb71b3958d05fbbe6b57dc354ae068fa6bc0c）：分组按钮调用现有公开动作 connectAccount('xiaohongshu', exactAccountId)，平台和组账号明确，不改默认其他组账号。用户可在原账号页完成登录或检查连接，再返回核对本组独立会话；文案没有将 null 返回误报为登录成功。此修改不新增后端授权，不自动读取或发送。

已读取 tests/test_session_login_dom.mjs：默认 A、点击 B 精确传小红书+B，accountWebsiteOpen 错误路线不可调用，pending/stale scope 拒绝，null 返回不显示已提交。Sol 提供 PASS 证据；此处为独立代码审查，未再次执行该测试。

因此，实际 native 1.1.8 人工按账号分组路线在静态调用链上成立。仍须最终 assembly 纳入该源码并检查 source closure；此结论不等于真实账号登录成功、平台验收或未来 1.2 natural browser 登录与 CLI cookie 转换已验收。
