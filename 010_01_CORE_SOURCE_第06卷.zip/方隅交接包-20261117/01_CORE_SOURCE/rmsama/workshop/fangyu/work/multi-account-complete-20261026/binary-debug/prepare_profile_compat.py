from pathlib import Path
T=Path(__file__).resolve().parent.parent
p=T/'candidate/worker/assistant/xhs_cli_page_worker.py';s=p.read_text('utf-8')
s=s.replace('def project_reply_read(args,stdout):',"""_PROFILE_SEAL=object()
class _ProfileBinding:
    def __init__(self,args):self.seal=_PROFILE_SEAL;self.args=tuple(args)

def project_reply_read(args,stdout,binding=None):""")
old="""        values={v for entry in positions if isinstance(entry,dict) for key in ('user_id','userid') for v in [entry.get(key)] if isinstance(v,str) and v}
        if len(values)!=1:raise ValueError('Public subject ambiguous')
        uid=next(iter(values))
        if uid!=args[1]:raise ValueError('Public profile subject identity missing or mismatched')
        result={'user_id':uid,'desc':bounded(basic.get('desc',''),4000)}"""
new="""        values=set()
        for entry in positions:
            if not isinstance(entry,dict):continue
            for key in ('user_id','userid','id'):
                value=entry.get(key)
                if value is None or value=='':continue
                if not isinstance(value,str) or not _IDENT.fullmatch(value):raise ValueError('Malformed explicit public subject')
                values.add(value)
        if values and (len(values)!=1 or next(iter(values))!=args[1]):raise ValueError('Public profile subject mismatched')
        result={'subjectId':args[1],'identitySource':'response_uid' if values else 'request_bound_subject','desc':bounded(basic.get('desc',''),4000)}
        if values:result['user_id']=args[1]
        elif type(binding) is not _ProfileBinding or binding.seal is not _PROFILE_SEAL or binding.args!=tuple(args):raise ValueError('Public subject requires exact authorized page binding')"""
assert old in s;s=s.replace(old,new,1)
s=s.replace('project_reply_read(args,stdout.getvalue()) if code==0',"project_reply_read(args,stdout.getvalue(),getattr(gate,'profile_binding',lambda:None)()) if code==0",1)
s=s.replace('current_args=None;strict_gate=None','current_args=None;strict_gate=None;profile_binding=None',1)
s=s.replace('    def gate(method,url=None):\n        if active', '    def gate(method,url=None):\n        nonlocal profile_binding\n        if active',1)
needle="            raise ValueError('Original parent did not authorize this request')\n    runner=None"
replacement="""            raise ValueError('Original parent did not authorize this request')
        # Mint only after this exact request passed SinglePageWireGate and the
        # parent explicitly allowed its wire. Reset for every original page.
        if operation=='user' and strict_gate is not None:profile_binding=_ProfileBinding(current_args)
    gate.profile_binding=lambda:profile_binding
    runner=None"""
assert needle in s;s=s.replace(needle,replacement,1)
s=s.replace('strict_gate=exact_source_gate(args)\n            os.environ', 'strict_gate=exact_source_gate(args);profile_binding=None\n            os.environ',1)
p.write_text(s,'utf-8')
p=T/'candidate/runtime/assistant/reply_read_session.py';s=p.read_text('utf-8')
old="if profile.get('user_id')!=job['subjectId'] or not isinstance(profile.get('desc'),str) or len(profile['desc'])>4000 or not isinstance(posts.get('notes'),list) or len(posts['notes'])>job['limitPosts']:"
new="if not valid_profile_subject(profile,job['subjectId']) or not isinstance(posts.get('notes'),list) or len(posts['notes'])>job['limitPosts']:"
assert old in s;s=s.replace(old,new)
needle='def run_registered_read('
index=s.index(needle)
s=s[:index]+"""def valid_profile_subject(profile,subject):
 if not isinstance(profile,dict) or profile.get('subjectId')!=subject or not isinstance(profile.get('desc'),str) or len(profile['desc'])>4000:return False
 source=profile.get('identitySource')
 if source=='response_uid':return set(profile)=={'subjectId','identitySource','desc','user_id'} and profile['user_id']==subject
 if source=='request_bound_subject':return set(profile)=={'subjectId','identitySource','desc'}
 return False

"""+s[index:]
s=s.replace("'text':profile['desc'],'observedAt':observed}","'text':profile['desc'],'observedAt':observed,'identitySource':profile['identitySource']}",1)
p.write_text(s,'utf-8')
p=T/'candidate/reply_public_profile.py';s=p.read_text('utf-8')
needle="'identityProofDigest':output['identityProofDigest']})"
assert s.count(needle)==1
s=s.replace(needle,"'identityProofDigest':output['identityProofDigest'],**({'identitySource':source['identitySource']} if source is output.get('profile') and source.get('identitySource') in ('response_uid','request_bound_subject') else {})})")
p.write_text(s,'utf-8')
