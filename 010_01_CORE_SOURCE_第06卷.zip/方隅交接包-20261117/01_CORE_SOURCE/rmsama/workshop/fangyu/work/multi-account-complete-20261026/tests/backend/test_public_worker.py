from pathlib import Path
import unittest,sys,importlib.util
import argparse
parser=argparse.ArgumentParser(add_help=False);parser.add_argument('--project');parser.add_argument('--worker');cli,remaining=parser.parse_known_args();sys.argv=[sys.argv[0],*remaining]
TASK=Path(__file__).resolve().parents[2];BASE=Path(cli.project) if cli.project else TASK.parent/'multi-account-reply-20261026/assembly/project';WORKER=Path(cli.worker) if cli.worker else TASK/'candidate/worker'
sys.path[:0]=[str(WORKER),str(BASE/'work/ui-runtime-r55/src')]
import core,core.acquisition_extension
core.__path__.insert(0,str(WORKER/'core'));core.acquisition_extension.__path__.insert(0,str(WORKER/'core/acquisition_extension'))
class WorkerContract(unittest.TestCase):
 def worker(self):
  candidate=WORKER/'assistant/xhs_cli_page_worker.py'
  spec=importlib.util.spec_from_file_location('profile_worker_candidate',candidate);worker=importlib.util.module_from_spec(spec);spec.loader.exec_module(worker);return worker
 def test_identity_phases_have_distinct_durable_page_keys(self):
  w=self.worker();self.assertNotEqual(w.page_key(['whoami','--json','--phase','before']),w.page_key(['whoami','--json','--phase','after']))
 def test_before_receipts_public_page_prunes_to_cap_and_matching_author(self):
  import json
  w=self.worker();notes=[{'note_id':'bad','user':{'user_id':'other'},'desc':'wrong author'}]+[{'note_id':'n'+str(i),'user':{'user_id':'target'},'title':'找房'+str(i),'desc':'预算2000','private':'omit'} for i in range(30)]
  result=json.loads(w.project_reply_read(['user-posts','target','--json','--max-items','3'],json.dumps({'ok':True,'schema_version':'1','data':{'notes':notes,'has_more':True,'cursor':'next'}})))
  self.assertEqual(len(result['data']['notes']),3);self.assertTrue(all(n['user_id']=='target' and 'private' not in n for n in result['data']['notes']));self.assertFalse(result['data']['has_more'])
 def test_profile_and_whoami_projection_excludes_demographics(self):
  import json
  w=self.worker();p=json.loads(w.project_reply_read(['user','target','--json'],json.dumps({'data':{'basic_info':{'user_id':'target','desc':'明确找租房','gender':1,'ip_location':'somewhere','nickname':'do not infer'}}})))
  self.assertEqual(p['data'],{'subjectId':'target','identitySource':'response_uid','user_id':'target','desc':'明确找租房'})
  with self.assertRaises(ValueError):w.project_reply_read(['user','target','--json'],json.dumps({'data':{'basic_info':{'desc':'unbound text'}}}))
 def test_conflicting_explicit_identity_locations_never_verify(self):
  import json
  w=self.worker()
  payloads=[(['whoami','--json'],{'user':{'id':'a','user_id':'b'}}),(['user','target','--json'],{'basic_info':{'user_id':'target','desc':'text'},'user_id':'other'})]
  for args,payload in payloads:
   with self.assertRaises(ValueError):w.project_reply_read(args,json.dumps({'ok':True,'data':payload}))
 def test_conflicting_post_author_ids_are_excluded(self):
  import json
  w=self.worker();payload={'notes':[{'note_id':'valid-note','user':{'user_id':'target','userid':'other'},'title':'do not adopt'}]}
  result=json.loads(w.project_reply_read(['user-posts','target','--json','--max-items','3'],json.dumps({'ok':True,'data':payload})));self.assertEqual(result['data']['notes'],[])
 def test_only_fixed_public_and_identity_shapes(self):
  w=self.worker()
  for args in [['user','target','--json','--url','https://evil.test'],['whoami','--json','--phase','other'],['user-posts','target','--json','--max-items','6'],['reply','note','--json']]:
   with self.assertRaises(ValueError):w.validate_args(args)

 def test_new_read_ops_registered_and_wire_exact(self):
  candidate=WORKER/'assistant/xhs_cli_page_worker.py'
  self.assertTrue(candidate.exists(),'new profile worker not implemented')
  spec=importlib.util.spec_from_file_location('profile_worker_candidate',candidate);worker=importlib.util.module_from_spec(spec);spec.loader.exec_module(worker)
  self.assertEqual(worker.validate_args(['whoami','--json']),['whoami','--json'])
  self.assertEqual(worker.validate_args(['user','target','--json']),['user','target','--json'])
  gate=worker.exact_source_gate(['user','target','--json']);gate('GET','https://edith.xiaohongshu.com/api/sns/web/v1/user/otherinfo?target_user_id=target')
  with self.assertRaises(ValueError):gate('GET','https://edith.xiaohongshu.com/api/sns/web/v1/user/otherinfo?target_user_id=target')
if __name__=='__main__':unittest.main()
