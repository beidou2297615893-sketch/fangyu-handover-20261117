/* Purpose-limited release identity for local, explicitly reviewed reply queues.
 * The material digest is version admission, not remote executable attestation.
 * This module never grants remote command execution or changes stored policy. */
'use strict';
const crypto=require('node:crypto');
const PROTOCOL='fangyu-reviewed-reply-v1';
const VERSION='1.2.0-read.1';
const NATIVE_VERSION='1.1.8-pilot.1';
const COMPANY='fangyu-apartment-client';
const SCHEMA='fangyu_reviewed_reply_lease_v1';
// Replace only after the compiled sender Registration canonical manifest is approved.
// Non-hex placeholders cannot authorize any request, including literal replay.
const ALLOWLIST=Object.freeze([Object.freeze({protocol:PROTOCOL,clientVersion:VERSION,
 materialSha256:'211d8ebfe97e62a63325fc85334f2862e5e3263411a51100b29b2d4c34ef7757'}),Object.freeze({protocol:PROTOCOL,clientVersion:NATIVE_VERSION,
 materialSha256:'211d8ebfe97e62a63325fc85334f2862e5e3263411a51100b29b2d4c34ef7757'})]);
const isDigest=value=>typeof value==='string'&&/^[a-f0-9]{64}$/.test(value);
function requestMatches(payload){return payload?.reviewed_reply_protocol===PROTOCOL;}
function permissionRevision(owner){
 const tuple={username:typeof owner?.username==='string'?owner.username:'',
  role:typeof owner?.role==='string'?owner.role:'',disabled:!!owner?.disabled,
  effectiveCanReply:!!owner&&owner.can_reply!==false,
  permission_revision:owner?.permission_revision??null};
 return crypto.createHash('sha256').update(JSON.stringify(tuple)).digest('hex');
}
function leaseForDevice({companyId,customerReadPolicy,matchingCustomerReadRequest,readLease,employeeLease,adminWorkbenchAllowed=false,
 authenticatedDevice,device,owner,previousLastSeen,now,payload,qaDevice=false}){
 const version=payload?.version===NATIVE_VERSION?NATIVE_VERSION:VERSION;
 const base={schema:SCHEMA,allowed:false,company_id:COMPANY,device_id:device?.id||'',
  owner:owner?.username||'',version,purpose:'reviewed_reply',
  permission_revision:permissionRevision(owner),material_sha256:isDigest(payload?.material_sha256)?payload.material_sha256:'',
  lease_seconds:0,public_send_allowed:false};
 const customerReadAllowed=version===VERSION&&customerReadPolicy===true&&matchingCustomerReadRequest===true&&readLease?.allowed===true;
 const nativeSourceAllowed=version===NATIVE_VERSION&&employeeLease?.allowed===true&&employeeLease.continuous_read===true
  &&employeeLease.version===NATIVE_VERSION&&adminWorkbenchAllowed===true
  &&payload?.workbench_source_release==='fangyu-admin-local-v1'&&device?.workbench_source_release==='fangyu-admin-local-v1';
 if(companyId!==COMPANY||!(customerReadAllowed||nativeSourceAllowed))return base;
 if(authenticatedDevice!==true||!device||device.revoked||!owner||owner.disabled||owner.username!==device.owner)return base;
 if(!['admin','operator'].includes(owner.role)||owner.can_reply===false||qaDevice)return base;
 if(!Number.isSafeInteger(now)||!Number.isSafeInteger(previousLastSeen)||previousLastSeen<=0||previousLastSeen>now||now-previousLastSeen>90)return base;
 if(device.version!==version||!isDigest(payload?.material_sha256)||!ALLOWLIST.some(entry=>
  isDigest(entry.materialSha256)&&entry.protocol===payload.reviewed_reply_protocol&&
  entry.clientVersion===payload.version&&entry.materialSha256===payload.material_sha256))return base;
 return {...base,allowed:true,lease_seconds:45,public_send_allowed:true};
}
module.exports={PROTOCOL,VERSION,NATIVE_VERSION,COMPANY,SCHEMA,requestMatches,permissionRevision,leaseForDevice};
