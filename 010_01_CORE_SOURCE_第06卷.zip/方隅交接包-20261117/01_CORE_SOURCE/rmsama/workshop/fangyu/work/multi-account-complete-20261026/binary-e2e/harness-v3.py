"""Compiled helper acceptance against a non-forwarding loopback TLS responder.

Prepare-only is the default. Root/Astra must approve the rebuilt component SHA
and command before --compiled-reviewed. No platform or model is contacted.
"""
import argparse,copy,hashlib,importlib.util,json,os,shutil,socket,subprocess,sys,threading,time,traceback
from pathlib import Path
from types import SimpleNamespace
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent;TASK=HERE.parent
from safety import ChildGuard,child_env,require,sha
def write(path,value):Path(path).write_text(json.dumps(value,ensure_ascii=False,indent=2),'utf-8')
def module(name,path):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m);return m
def parse():
 p=argparse.ArgumentParser(description=__doc__);base=TASK.parent/'multi-account-reply-20261026/assembly/project'
 p.add_argument('--project',type=Path,default=base);p.add_argument('--release',type=Path,default=base/'work/ui-native-r57/releases/ui-r57-20261026T130202Z-ba1ea294')
 p.add_argument('--component',type=Path,help='Exact NEW rebuilt helper .exe, never an old baseline helper');p.add_argument('--component-sha',help='Root/Astra reviewed rebuilt executable sha256')
 p.add_argument('--run-dir',type=Path,required=True);p.add_argument('--compiled-reviewed',action='store_true',help='Root only after source/exe/transport approval')
 return p.parse_args()
def synthetic_cookie(home):
 path=Path(home)/'.xiaohongshu-cli';path.mkdir(parents=True,exist_ok=True);write(path/'cookies.json',{'a1':'a'*52,'web_session':'b'*40,'saved_at':time.time()})
def app_pins(roots):
 paths={Path(__file__).resolve(),HERE/'safety.py',TASK/'tests/loopback_tls_fixture.py'}
 for m in list(sys.modules.values()):
  path=getattr(m,'__file__',None)
  if path and Path(path).suffix=='.py' and any(Path(path).resolve().is_relative_to(root.resolve()) for root in roots):paths.add(Path(path).resolve())
 return {str(p):sha(p) for p in sorted(paths)}
DIAGNOSTICS={}

def failure_result(error):
 run=DIAGNOSTICS.get("run");result=DIAGNOSTICS.get("result")
 if run is None or result is None:return
 child=DIAGNOSTICS.get("child");responders=DIAGNOSTICS.get("responders",[])
 records=[record for responder in responders for record in responder.records]
 starts=list(child.starts) if child else []
 result.update(status="FAIL",compiledChildExecuted=bool(starts),childStarts=starts,dispatchStatistics={"childStarts":len(starts),"httpRequests":len(records),"getRequests":sum(r["method"]=="GET" for r in records),"postRequests":sum(r["method"]=="POST" for r in records)},failure={"stage":DIAGNOSTICS.get("stage"),"case":DIAGNOSTICS.get("case"),"type":type(error).__name__,"message":str(error),"traceback":traceback.format_exc()},partialWires=records)
 write(run/"RESULT.json",result)

def main():
 a=parse();run=a.run_dir.resolve();require(run.is_relative_to(HERE) and not run.exists(),'Fresh run must stay under binary-e2e');run.mkdir(parents=True)
 result={'status':'PREPARED_NOT_EXECUTED','compiledChildExecuted':False,'platformCalls':0,'modelCalls':0,'productionWrites':False,'productionDataRead':False,'remoteLease':'synthetic test object; not remote authorization acceptance','networkBoundary':'Parent audit only. Child uses reviewed fixed HTTPX client plus explicit loopback proxies; TLS responder never forwards; this is not an OS network sandbox.','cases':[]}
 DIAGNOSTICS.update(run=run,result=result,stage='initialization',responders=[])
 write(run/'RESULT.json',result)
 if not a.compiled_reviewed:
  write(run/'SOURCE-PINS.json',app_pins([TASK,a.project]));write(run/'RESULT.json',result);print(json.dumps(result));return
 require(a.component is not None and a.component_sha is not None,'Reviewed NEW exe and SHA mandatory')
 exe=a.component.resolve();require(exe.is_relative_to(TASK) and sha(exe)==a.component_sha,'Exact newly rebuilt component must be under this task')
 original_popen=subprocess.Popen;gate={'child':None}
 production_home=Path(os.environ.get('USERPROFILE',str(Path.home()))).resolve()
 allowed_home_sources=[TASK.resolve(),a.project.resolve(),Path(sys.prefix).resolve(),Path(sys.base_prefix).resolve()]
 def audit(event,values):
  if event=='socket.connect':
   address=values[1];require(isinstance(address,tuple) and address[0] in ('127.0.0.1','::1'),'Parent external network prohibited')
  if event in ('os.system','os.startfile'):raise AssertionError('Other process/UI launch forbidden')
  if event=='subprocess.Popen':require(gate['child'] is not None,'No process before registered child guard');gate['child'].audit_process(values[0],values[1])
  if event=='sqlite3.connect':require(str(values[0])==':memory:' or Path(values[0]).resolve().is_relative_to(run),'Production DB prohibited')
  if event=='open':
   path,mode,flags=values
   if isinstance(path,int):return
   path=Path(path).resolve();writing=(isinstance(mode,str) and any(c in mode for c in 'wax+')) or (isinstance(flags,int) and flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND))
   if writing:require(path.is_relative_to(run),'Writes outside synthetic run prohibited: '+str(path))
   else:
    if path.is_relative_to(production_home):require(path.is_relative_to(run) or any(path.is_relative_to(root) for root in allowed_home_sources),'Production user HOME reads prohibited: '+str(path))
    if path.name.lower() in ('auth.json','cookies.json','login data') or path.suffix.lower() in ('.db','.sqlite','.sqlite3'):require(path.is_relative_to(run),'Production database or credential read prohibited')
 sys.addaudithook(audit)
 # Reuse established synthetic fixture; paths are explicit source only. Its
 # socket/Popen traps are replaced with the stricter reviewed guards below.
 os.environ.update(SENDER_PROJECT=str(a.project),SENDER_NATIVE=str(a.release),SENDER_CANDIDATE=str(TASK/'candidate'),SENDER_RUNTIME=str(TASK/'candidate/runtime'),SENDER_SEND=str(TASK/'candidate/send'))
 test=module('compiled_sender_fixture',TASK/'sender/tests/test_reviewed_delivery.py')
 test.fmod.TASK=run; (run/'tests/backend').mkdir(parents=True)
 import assistant,core
 adapters_module=module('core.adapters',TASK/'candidate/worker/core/adapters.py')
 assistant.__path__.insert(0,str(TASK/'candidate/worker/assistant'))
 # Import the fixed worker before PageWorker binds its arg validators.
 module('assistant.xhs_cli_page_worker',TASK/'candidate/worker/assistant/xhs_cli_page_worker.py')
 from core.xhs_page_process import PageWorker
 from assistant.reply_read_session import register_read
 from reply_public_profile import PublicReadWorkflow
 bridge=module('compiled_actual_reply_bridge',TASK/'candidate/send/reviewed_reply_bridge.py')
 responder_module=module('compiled_loopback_tls_fixture',TASK/'tests/loopback_tls_fixture.py')
 fixture_generate=test.fmod.MultiTests.generate
 def prepared_generate(f):
  for index,aid in enumerate('ABCDEF',1):
   account=f.store.get('accounts',aid);account['platform_uid']=format(index,'x')*24;f.store.put('accounts',account);f.save_profile(aid,['pet'] if aid=='B' else ['commute'])
  lead=copy.deepcopy(f.lead);lead.update(comment_id='e'*24,author_id='c'*24,note_url='https://www.xiaohongshu.com/explore/'+'d'*24)
  f.lead=lead;f.store.put('leads',lead);f.assign('B');job=fixture_generate(f)
  f.job=f.w.dispatch('reply_ai_edit',{**f.args,'jobId':job['id'],'revision':job['revision'],'edits':[{'leadId':'l','text':'Synthetic reviewed reply','selected':True}]},'token')['replyAI'];return f.job
 test.fmod.MultiTests.generate=prepared_generate
 # Manifest is a TEST registration of real file hashes, not a production
 # approval. Full compiled runtime directory is hashed without copying it.
 root=TASK
 sources={str(p.relative_to(root)).replace('\\','/'):sha(p) for p in (TASK/'candidate/runtime/assistant/xhs_reply_worker.py',TASK/'candidate/runtime/core/reply_execution_policy.py',TASK/'candidate/worker/assistant/xhs_cli_page_worker.py')}
 tree={str(p.relative_to(root)).replace('\\','/'):sha(p) for p in exe.parent.rglob('*') if p.is_file() and p!=exe}
 manifest={'version':1,'protocol':'reviewed-reply-v1','helperFlag':'--owned-xhs-reviewed-reply','executable':exe.relative_to(root).as_posix(),'executableSha256':a.component_sha,'sources':sources,'runtimeTree':tree}
 write(run/'SYNTHETIC-COMPONENT-REGISTRATION.json',{'notice':'Test-only registration; no production approval invented','manifest':manifest})
 child=ChildGuard(exe,a.component_sha,run,reviewed=True,popen=original_popen);gate['child']=child;DIAGNOSTICS['child']=child
 for kind in ('read','send','wrong-uid','response-conflict'):
  DIAGNOSTICS.update(case=kind,stage='fixture setup')
  case_root=run/kind;case_root.mkdir();responder=responder_module.LocalResponder(case_root/'tls',actor_uid='2'*24,subject_uid='c'*24)
  DIAGNOSTICS['responders'].append(responder)
  if kind=='read':
   profile_answer=responder.answer
   def profile_without_response_uid(method,target,body):
    value=profile_answer(method,target,body)
    if method=='GET' and target.split('?',1)[0]=='/api/sns/web/v1/user/otherinfo':
     def remove_uid(entry):
      if isinstance(entry,dict):
       for key in ('user_id','userid'):entry.pop(key,None)
       for child in entry.values():remove_uid(child)
      elif isinstance(entry,list):
       for child in entry:remove_uid(child)
     remove_uid(value)
     require(value['data']['basic_info'].get('desc'),'Missing synthetic profile description')
    return value
   responder.answer=profile_without_response_uid
  if kind=='wrong-uid':responder.actor_uid='1'*24
  if kind=='response-conflict':
   original_answer=responder.answer
   def conflict(method,target,body):
    value=original_answer(method,target,body)
    if method=='POST':value['data']['user_id']='1'*24;value['data']['user_info']={'user_id':'1'*24};value['data']['comment']['user_info']={'user_id':'1'*24};value['data']['comment']['user_id']='1'*24
    return value
   responder.answer=conflict
  with responder.serve() as proxy:
   d=test.DeliveryTests('test_original_confirmed_B_queue_sends_exactly_one_with_three_holds');d.setUp();f=d.f
   # Detach temporary finalizer to preserve the actual SQLite evidence.
   f.tmp._finalizer.detach();f.net.stop();f.proc.stop()
   subprocess.Popen=child.popen;subprocess.run=lambda *a,**kw:(_ for _ in ()).throw(AssertionError('Other subprocess prohibited'))
   adapters=adapters_module.Adapters(None);d.core.adapters=adapters;adapters.platform_guard=d.core._platform_execution_guard
   # Original manifest deliberately selects helper A, not the new helper B.
   # Only the private registration may select B. A is inert synthetic material
   # because the source-only baseline project contains no compiled old helper.
   old_helper=case_root/'old-helper-A-inert.exe';old_helper.write_bytes(b'inert old manifest route; must never execute')
   old_manifest={'id':'xiaohongshu','available':True,'executable':str(old_helper),'isolation_guard':True,'prefix_args':['xiaohongshu'],'reply_contract_verified':False,'env':{}}
   adapters.manifest=lambda p:copy.deepcopy(old_manifest)
   original_spec=adapters.account_spec
   def with_loopback_only(platform,home,args,**options):
    spec=original_spec(platform,home,args,**options)
    # Preserve real account_spec argv/cwd/isolated HOME and activity semantics.
    injected=child_env(home,proxy)
    for key in ('HTTP_PROXY','HTTPS_PROXY','ALL_PROXY','http_proxy','https_proxy','all_proxy','NO_PROXY','no_proxy','SSL_CERT_FILE','TEMP','TMP'):spec['env'][key]=injected[key]
    return spec
   adapters.account_spec=with_loopback_only
   for aid in 'ABCDEF':synthetic_cookie(f.store.directory/'accounts/t'/aid)
   # Outside a private registered scope, the original hold MUST reject.
   # Checking the manifest does not manufacture a read decision or bypass it.
   DIAGNOSTICS['stage']='ordinary route remains held'
   try:adapters.account_spec('xiaohongshu',f.store.directory/'accounts/t/B',['whoami','--json'])
   except (ValueError,RuntimeError):pass
   else:raise AssertionError('Original unscoped account_spec unexpectedly allowed')
   require(Path(adapters.manifest('xiaohongshu')['executable'])==old_helper and old_helper!=exe,'Original manifest must retain old helper A')
   test.register(d.core,root,manifest,bridge.transport,expected_manifest_digest=test.digest(manifest))
   DIAGNOSTICS['stage']='registered scoped workflow'
   if kind=='read':
    runtime=d.runtime;runtime.project=root;runtime._customer_read_lease_current=lambda p:p in ('xiaohongshu_natural_read','xiaohongshu_guarded_read');runtime._readiness=lambda *a,**kw:('','');runtime.server=SimpleNamespace(_platform_execution_guard=d.core._platform_execution_guard);f.b.platform_runtime=runtime
    register_read(d.core,root,{**manifest,'protocol':'reply-profile-read-v1','helperFlag':'--owned-xhs-cli-pages'})
    reader=PublicReadWorkflow(f.b);data={**f.base,'accountId':'B','customerId':'c','limitPosts':3,'requestId':'compiled-profile'}
    view=reader.dispatch('reply_public_profile_start',data,'token')['replyPublicRead'];deadline=time.monotonic()+180
    while view['id'] in reader.controls:require(time.monotonic()<deadline,'Compiled reader timeout');time.sleep(.02)
    view=reader.dispatch('reply_read_status',{**f.base,'jobId':view['id']},'token')['replyPublicRead'];require(view['state']=='completed','Actual compiled public reader failed: '+json.dumps(view,ensure_ascii=False))
    require(view.get('profile',{}).get('identitySource')=='request_bound_subject','Profile must disclose request-bound subject')
    require(all(not view['profile'].get(key) for key in ('responseUID','responseUid','responseUserId','responseSubjectId','response_user_id','user_id','userid')),'Profile fabricated a response UID')
    before=len(responder.records);reader.dispatch('reply_public_profile_start',data,'token');require(len(responder.records)==before,'Read replay generated extra wire')
    manual=copy.deepcopy(f.service.evidence(['t','u','owner','s','xiaohongshu'],'c')['items'])
    applied=reader.dispatch('reply_public_profile_apply',{**f.base,'jobId':view['id'],'expectedEvidenceRevision':0,'requestId':'compiled-apply'},'token')['replyPublicRead']
    evidence=f.service.evidence(['t','u','owner','s','xiaohongshu'],'c');require(applied['applied'] and evidence['items']==manual and len(evidence['automaticItems'])==2,'Separate automatic evidence slot failed')
    profile_evidence=[entry for entry in evidence['automaticItems'] if entry.get('sourceUrl')==view['profile']['sourceUrl']]
    require(len(profile_evidence)==1 and profile_evidence[0].get('identitySource')=='request_bound_subject','Adopted profile evidence lost request-bound identity source')
    require([r['method'] for r in responder.records]==['GET']*4 and 'user/me' in responder.records[0]['path'] and 'user/me' in responder.records[-1]['path'],'Expected whoami/user/posts/whoami sequence')
    item={'kind':kind,'view':view,'applied':applied,'evidence':evidence}
   else:
    plan=d.prepare('compiled-prepare');view=d.start(plan);deadline=time.monotonic()+100
    while view['state'] in ('ready','awaiting_collection','running'):
     require(time.monotonic()<deadline,'Compiled sender timeout: '+json.dumps(view,ensure_ascii=False))
     time.sleep(.05);view=d.delivery.status(f.user,'s',d.delivery._plan(f.user,'s',plan['id']))
    posts=[r for r in responder.records if r['method']=='POST']
    expected='sent' if kind=='send' else 'approved' if kind=='wrong-uid' else 'unknown'
    require(view['items'][0]['status']==expected,'Unexpected original queue status: '+json.dumps(view,ensure_ascii=False))
    require(len(posts)==(0 if kind=='wrong-uid' else 1),'Actual compiled helper POST count mismatch')
    if kind=='send':require(view['items'][0]['actualUid']=='2'*24 and view['items'][0]['responseSenderUid']=='2'*24,'Actual sender UID receipt missing')
    count=len(responder.records)
    try:d.start(plan)
    except ValueError:pass
    require(len(responder.records)==count,'Repeated UI request generated extra wire')
    if kind=='response-conflict':
     try:d.prepare('new-after-conflict')
     except ValueError:pass
     else:raise AssertionError('Unknown customer was requeued')
    item={'kind':kind,'view':view,'plan':plan}
   require(not responder.errors,'Synthetic responder route error: '+str(responder.errors));require(all(not r['forwarded'] for r in responder.records),'Responder forwarded external traffic')
   item.update(wires=responder.records,database=str(f.store.path),status='PASS');result['cases'].append(item);write(run/'RESULT.json',result)
   d.core.reviewed_reply_queues.close()
 records=[record for responder in DIAGNOSTICS['responders'] for record in responder.records]
 result.update(status='PASS',compiledChildExecuted=bool(child.starts),childStarts=child.starts,dispatchStatistics={'childStarts':len(child.starts),'httpRequests':len(records),'getRequests':sum(r['method']=='GET' for r in records),'postRequests':sum(r['method']=='POST' for r in records)},sourcePins=app_pins([TASK,a.project]),componentSha256=sha(exe));write(run/'SOURCE-PINS.json',result['sourcePins']);write(run/'RESULT.json',result);print(json.dumps({'status':'PASS','compiledChildren':len(child.starts),'cases':len(result['cases']),'platformCalls':0,'modelCalls':0}))
if __name__=='__main__':
 try:main()
 except BaseException as error:
  failure_result(error)
  raise
