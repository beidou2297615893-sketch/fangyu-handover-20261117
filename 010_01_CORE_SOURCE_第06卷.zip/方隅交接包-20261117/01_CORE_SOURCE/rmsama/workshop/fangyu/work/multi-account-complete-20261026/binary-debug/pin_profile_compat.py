from pathlib import Path
import hashlib,json,ast
T=Path(__file__).resolve().parent.parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
p=T/'FINAL-CANDIDATE-PINS.json';v=json.loads(p.read_text('utf-8-sig'))
for f in (T/'candidate').rglob('*'):
 if f.is_file() and '__pycache__' not in f.parts and f.suffix!='.pyc':
  if f.suffix=='.py':ast.parse(f.read_bytes())
  v['files'][f.relative_to(T).as_posix()]={'sha256':sha(f),'size':f.stat().st_size}
v['count']=len(v['files']);v['helperSource']='component-v3/artifacts/platform-cli-customer-read';v['assemblyScript']={'path':str(T/'assemble_complete.py'),'sha256':sha(T/'assemble_complete.py')};p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n','utf-8')
changed=['candidate/worker/assistant/xhs_cli_page_worker.py','candidate/runtime/assistant/reply_read_session.py','candidate/reply_public_profile.py','assemble_complete.py']
report={'status':'SOURCE_VERIFIED_V3_PREPARED_NOT_BUILT','sourcePins':{n:sha(T/n) for n in changed},'tests':{'public_read':20,'public_worker':7,'profile_subject_compat':7,'profile_subject_evidence':1,'evidenceSourceSubcases':2,'totalUnittestCases':35},'componentSourceFiles':257,'componentInputs':3533,'candidateFileCount':v['count'],'compiled':False,'applied':False,'freezeExecuted':False,'platformCalls':0,'whoamiSenderPostsRulesUnchanged':True}
(T/'binary-debug/PROFILE-COMPAT-DELIVERY.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n','utf-8')
print(json.dumps(report))
