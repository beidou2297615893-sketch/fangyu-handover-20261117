# 最终材料及实际组件组合证据

2026-10-27，Astra 独立复核。

最终 v3 EXE SHA256 为 998831579f4f2a729039d3d0924d69fb9da09f820e965403a93681ed03452d31。compiled-05 中 read（4 GET，完整前后身份核验、缺 UID 简介 request_bound_subject、原文采用）和 send（1 GET、1 精确 POST、原队列 sent、实际身份回执）分案 PASS；compiled-06 中 wrong-uid（1 GET、0 POST、原草稿 approved）与 response-conflict（1 GET、1 POST、unknown 且禁止重放）PASS。四场景由两次运行组合覆盖；compiled-05 整体 FAIL 保留，compiled-06 仅实际执行两个负向案例，不能表述为单次四场景通过。

独立重算 assembly/project/work/ui-native-r57 材料 canonical digest：

- reviewed_reply_materials.json：211d8ebfe97e62a63325fc85334f2862e5e3263411a51100b29b2d4c34ef7757。
- reply_public_read_materials.json：aafeac7bdf1d12a3acaffe96d978818b6e9db9aeb891f957e4d64ed61b77a334。

两材料各 114 项 sources、291 项 runtimeTree，逐项对照真实 assembly 文件，SHA256 零差异。source-only 与 compiled fixture 仍不代表真实账号、平台、远端 lease 或云部署验收。

云候选完整树独立核对：before 843361adb2bf456a4c23ea86bdd2dad6904c7e92634001978226f8d74ed7a84b（5618文件）；after 6e82626ab82f5951d86ce13b564b32a05f50757ac56272937b653c0451992b3f（5619文件）。只变 devices.cjs 与新 reviewed_reply_release.cjs，其他 5617 原文件逐字保持。固定 allowlist 的双版本材料均为上述 sender digest；新 10 项许可测试及旧 10 组/43 次服务合成请求 PASS，均无真实云/平台请求。

云部署机制已审：仅官方 fn code update，前置 fresh 全码读回与批准基线比较，不一致停止；部署后全 5619 文件及 ZIP 字节验证、受保护配置字段哈希比较。此前称 CAS 的检查是部署前基线比较，并非云 API 原子条件更新。没有引入数据库变更、权限配置写入、真实发送或自动重试。

本文件记录已取得的证据。最终冻结 source closure、host 单模块图、集成回归及精确部署/下次启动审批另行记录，不能由此文件代替。
