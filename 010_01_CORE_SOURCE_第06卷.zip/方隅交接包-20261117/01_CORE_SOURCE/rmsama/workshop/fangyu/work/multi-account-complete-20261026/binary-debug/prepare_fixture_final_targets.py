from pathlib import Path
T=Path(__file__).resolve().parent.parent
p=T/'tests/backend/test_profile_subject_compat.py';s=p.read_text('utf-8-sig')
old="""sys.path[:0]=[str(T/'component-v2/inputs-source')]
path=Path(sys.argv[sys.argv.index('--worker-path')+1]) if '--worker-path' in sys.argv else T/'candidate/worker/assistant/xhs_cli_page_worker.py'
if '--worker-path' in sys.argv:sys.argv=sys.argv[:sys.argv.index('--worker-path')]"""
new="""import argparse
parser=argparse.ArgumentParser(add_help=False)
parser.add_argument('--runtime',type=Path)
parser.add_argument('--parent-path',type=Path)
parser.add_argument('--worker-path',type=Path)
cli,remaining=parser.parse_known_args();sys.argv=[sys.argv[0],*remaining]
runtime=cli.runtime or T.parent/'multi-account-reply-20261026/assembly/project/work/ui-runtime-r55/src'
sys.path[:0]=[str(runtime)]
path=cli.worker_path or T/'candidate/worker/assistant/xhs_cli_page_worker.py'
parent_path=cli.parent_path or T/'candidate/runtime/assistant/reply_read_session.py'
assert path.is_file() and parent_path.is_file() and (runtime/'core/__init__.py').is_file()
if cli.runtime:
 assert (runtime/'core/acquisition_extension/contracts.py').is_file()
 assert (runtime/'core/acquisition_extension/guarded_port.py').is_file()"""
assert old in s;s=s.replace(old,new)
s=s.replace("parent=load('compat_parent',T/'candidate/runtime/assistant/reply_read_session.py')","parent=load('compat_parent',parent_path)")
p.write_text(s,'utf-8')
p=T/'tests/test_session_login_dom.mjs';s=p.read_text('utf-8-sig')
old="import {bindPublicRead,renderSessionCheck} from '../candidate/web/pages/reply-public-read.mjs';"
new="""import path from 'node:path';
import {readFile} from 'node:fs/promises';
import {fileURLToPath,pathToFileURL} from 'node:url';
import {createHash} from 'node:crypto';
const task=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const release=process.argv.includes('--release')?process.argv[process.argv.indexOf('--release')+1]:null;
const candidate=path.join(task,'candidate/web/pages/reply-public-read.mjs');
const modulePath=release?path.join(release,'web/pages/reply-public-read.mjs'):candidate;
if(release)assert.equal(createHash('sha256').update(await readFile(modulePath)).digest('hex'),createHash('sha256').update(await readFile(candidate)).digest('hex'),'Final served login module equals reviewed candidate');
const {bindPublicRead,renderSessionCheck}=await import(pathToFileURL(modulePath));"""
assert old in s;s=s.replace(old,new);p.write_text(s,'utf-8')
