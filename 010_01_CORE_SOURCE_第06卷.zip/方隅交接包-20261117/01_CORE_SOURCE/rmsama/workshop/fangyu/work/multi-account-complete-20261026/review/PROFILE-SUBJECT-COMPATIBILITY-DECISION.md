# 公开简介缺少响应 UID 的兼容决策

2026-10-27，Astra。决策允许实施最小兼容；尚未批准任何修改后的编译、安装或部署。

本地精确 INPUTS 所引用 xhs_cli/commands/reading.py 的 user --json 直接调用 client.get_user_info(user_id)，其 get_user_info 使用 /api/sns/web/v1/user/otherinfo?target_user_id=请求UID；JSON 路线不经 formatter 补 UID。pinned formatter_normalizers.py 的 normalize_user_info 明确允许 user_id 缺失并默认为空字符串。没有真实平台响应证据可判断缺失频率，不声称已复现真实平台故障。

当前 project_reply_read 对所有缺 UID 的公开简介拒绝。为了与 vendored 库允许的数据形状兼容，可以接受成功完成精确请求的简介原文，但必须区分身份依据：

- 统一返回 subjectId、identitySource、desc；identitySource 仅 response_uid 或 request_bound_subject。
- response_uid 必须存在匹配的 user_id；request_bound_subject 不得伪造 user_id。
- 仅 user 公开简介可以使用 request_bound_subject，必须有本页成功通过 SinglePageWireGate 和父 wire_allow 的内部证据。仅传入 args、构造 gate、无 wire 或父拒绝均不够。projection 默认无可信证据时拒绝缺 UID。
- 任何响应中显式不匹配、多 UID 或非法类型身份都拒绝；red_id 不当作 UID。登录 whoami、发送前身份、公开帖子作者维持原严格规则。
- 父解析只接受两种精确 shape，subjectId 必须等于原 job subject，响应分支 UID 同值，请求分支禁止伪造 response UID。identitySource 保留到原始读取结果及采用后的自动证据记录。
- 测试覆盖匹配 UID、缺 UID+成功精确 wire、缺 UID 无 wire/错误 query/拒绝 allow、冲突/多值/畸形 UID、父端未知 identitySource/shape、采用后来源保留、whoami 缺 UID 继续拒绝。

实施采用 v3 最小增量 snapshot，保留 v2 及 compiled-04 证据；只变必要 worker、父解析与证据保留、测试，不重置无关冻结源。源小样通过后重新固定输入并审查编译。compiled-04 继续验证既有 v2 核心链，不能替代 v3 验收。
