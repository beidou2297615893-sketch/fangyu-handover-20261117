from pathlib import Path
import hashlib,json,shutil,ast,re
T=Path(__file__).resolve().parent.parent;OLD=T/'component-v2';NEW=T/'component-v3'
assert not NEW.exists()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest().upper()
read=lambda p:json.loads(p.read_text('utf-8-sig'))
protected={p.relative_to(OLD).as_posix():sha(p) for p in (OLD/'inputs-source').rglob('*') if p.is_file()}
for n in ('INPUTS.json','build_inactive_component.py','build_tool_entry.py','build_child_entry.py','build_io_fence.py'):protected[n]=sha(OLD/n)
NEW.mkdir();shutil.copytree(OLD/'inputs-source',NEW/'inputs-source')
for n in ('build_inactive_component.py','build_tool_entry.py','build_child_entry.py','build_io_fence.py'):shutil.copy2(OLD/n,NEW/n)
relative='assistant/xhs_cli_page_worker.py';source=T/'candidate/worker'/relative;target=NEW/'inputs-source'/relative;before=sha(target);shutil.copy2(source,target);after=sha(target)
p=NEW/'build_inactive_component.py';s=p.read_text('utf-8-sig');pattern=r"guard\['profile_worker_sha256'\]='[0-9a-f]{64}'";s,count=re.subn(pattern,"guard['profile_worker_sha256']='"+after.lower()+"'",s);assert count==1;ast.parse(s);p.write_text(s,'utf-8')
manifest=read(OLD/'INPUTS.json')
for row in manifest['inputs']:
 if str(row.get('target') or '').startswith('source/'):
  p=NEW/'inputs-source'/Path(row['target']).relative_to('source');row['path']=str(p)
  if row['target']=='source/'+relative:row['bytes']=p.stat().st_size;row['sha256']=sha(p)
sourcepins={p.relative_to(NEW/'inputs-source').as_posix():sha(p) for p in (NEW/'inputs-source').rglob('*') if p.is_file()}
manifest['source_closure_sha256']=hashlib.sha256(json.dumps(sourcepins,sort_keys=True).encode()).hexdigest().upper()
(NEW/'INPUTS.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n','utf-8')
for n,h in protected.items():assert sha(OLD/n)==h,n
report={'status':'PREPARED_NOT_BUILT','inputs':len(manifest['inputs']),'sourceFiles':len(sourcepins),'changedSource':{'relative':relative,'candidatePath':str(source),'before':before,'after':after},'builderChange':'profile_worker_sha256 constant only; wrapper unchanged','inputSha256':sha(NEW/'INPUTS.json'),'sourceClosureSha256':manifest['source_closure_sha256'],'v2Preserved':protected,'builders':{n:sha(NEW/n) for n in ('build_inactive_component.py','build_tool_entry.py','build_child_entry.py','build_io_fence.py')},'wrapperSha256':manifest['wrapper_sha256'],'compiled':False,'platformCalls':0}
(NEW/'SOURCE-ORIGINS.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n','utf-8')
p=T/'FINAL-CANDIDATE-PINS.json';pins=read(p)
for f in (T/'candidate').rglob('*'):
 if f.is_file() and '__pycache__' not in f.parts and f.suffix!='.pyc':pins['files'][f.relative_to(T).as_posix()]={'sha256':sha(f).lower(),'size':f.stat().st_size}
p.write_text(json.dumps(pins,ensure_ascii=False,indent=2)+'\n','utf-8')
print(json.dumps({k:v for k,v in report.items() if k!='v2Preserved'},ensure_ascii=False))
