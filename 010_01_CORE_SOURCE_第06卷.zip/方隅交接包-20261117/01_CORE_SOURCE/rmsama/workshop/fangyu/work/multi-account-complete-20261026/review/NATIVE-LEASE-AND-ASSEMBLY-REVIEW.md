# 原生许可与候选装配审查

2026-10-27，Astra；只读源码审查及纯合成 Python 回归。未运行平台、登录、模型、云部署或生产安装。

## 当前语义结论

reply_read_session.py SHA256 5d199be93244e1a4ecb5c9cc9de4007121c8ba84fc7fc485b34ff930b0e60c58：实际 native 1.1.8-pilot.1 source_employee 分支同时校验 server/core 两配置的版本、两 source marker、两份 employee runtime_config_valid、当前 device ID、原 _employee_release_allowed。后者保留原 heartbeat deadline 及 remote hold。随后仍核 actor、service online、executor、原 session.check、账号身份、安全状态、HOME、设备绑定；每次 wire 重验。1.2 read 路线仍只能由原 customer_read_lease.current 接受两个既有读取目的，未用 source marker 替代原许可。

reviewed_reply_lease.py SHA256 4eaadb387bc415cd25dc2accce4eb91fb6ca079bc8edadec0ff0c7ed47c05ca6：独立发送 grant 绑定确切 Runner/Service/BusinessExecutor/_DeviceSession、公司/设备/员工/版本/材料、permission revision 与短期限。同次 owner_permissions 在验证 grant 前同步。每 wire 继续核 remote hold、QA、实际 actor、账号 owner 与原 session。不存在将 read lease 转换成发送权的路径。

独立执行当前候选 test_public_read.py：20/20 PASS，25.635 秒；test_reviewed_send_lease.py：7/7 PASS，0.981 秒。全为合成 fixture，不是实际平台或真实云许可验收。

## 候选装配

APPROVED_FOR_CANDIDATE_ONLY_ASSEMBLY

允许 root 对 assemble_complete.py SHA256 43987f31816ab99804bdfb48fdcf39843bf5329c7b518a6e5abceac930f80828 执行 --apply-candidate-only，目标固定本 task/assembly/project。此次只覆盖独立候选源，不推广、不安装、不启动、不改 data/outputs 或原 source-v66-worker。

已核对 host SHA256 794ede19381f24950986bb0a1de656bb9a071713d3ffabb594ca7274a839c70d 与 freezer SHA256 a571c6c5ef0a16e221c9b988b1522ddb18caaf87802fb151c2cd24d333e6df8f：新的 public-profile 与 bridge 在 backend 构造前按 RELEASE-pinned bytes 预载；sender 注册只消费 RELEASE 核验后的材料，read 注册同样检查 RELEASE 中材料条目。父 runtime 全部 .py 仍由 backend-dependencies 与既有 pinned importer 核验。

装配将当前 overlay Python 映射至原三份运行源和 native host，shared 明确优先；新 helper 进入独立 reply-complete-worker 目录。两个材料 sources 包含此次全部 overlay Python，runtimeTree 包含完整新 helper 文件树，不自我引用材料 JSON，父未改运行源依靠 RELEASE 全量 pin。此范围可接受，但最终必须核验 ASSEMBLY 每项哈希与两材料 digest、完整 helper 树、冻结后 RELEASE 与 update closure 的路径覆盖，尤其新 work/reply-complete-worker 必须在 next-launch payload 内。

## 尚未关闭的交付项

本次检查时 backend/SOURCE-PINS 5 项过时：workbench_backend.py、runtime/assistant/reply_read_session.py、runtime/assistant/reviewed_reply_lease.py、worker/core/adapters.py、shared/vendor-src/assistant/reviewed_reply_lease.py。DELIVERY 中 public-read=17/send-lease=6 也未反映当前20/7。FILES 条目覆盖范围没有因此缺失。需冻结后重算，不可把旧元数据用于最终精确批准。

尚无 compiled-03 通过证据；compiled-01/02 保持失败。最终云固定材料 allowlist、完整 afterTree/其他文件不变、部署前 live CAS 与部署后读回待单独审核。此报告不批准云部署或 source-only next-launch 安装。
