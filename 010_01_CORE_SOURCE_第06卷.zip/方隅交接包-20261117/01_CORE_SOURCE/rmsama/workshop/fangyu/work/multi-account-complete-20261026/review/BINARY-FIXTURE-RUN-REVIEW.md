# 实际组件的本地合成运行审查

2026-10-26，Astra。

APPROVED_FOR_ONE_COMPILED_LOOPBACK_FIXTURE_RUN

批准 root 执行一次 binary-e2e/harness.py，使用 --compiled-reviewed、下列精确组件及摘要、全新 --run-dir binary-e2e/compiled-01。project/release 使用 ba1ea294 的只读源码基线，候选覆盖父代码；最终冻结发布源还需独立回归。本批准不含任何真实平台、模型、云写入或安装操作。

- component/artifacts/platform-cli-customer-read/platform-cli-customer-read.exe SHA256：`161252D023F6744894F05D689BB64AA7D973417916FBA71E43314B35A7CF4533`
- binary-e2e/harness.py SHA256：`191DE1204089DF30DD184AD4F7BF8F47947DF4143BAE499391071B3E4CE70728`
- binary-e2e/safety.py SHA256：`08C0419C06A1FB10DFFFD08166659F7F2D56004223F8BB207C5DD2D821CEA980`
- tests/loopback_tls_fixture.py SHA256：`502A925A3B489BD4063C5FB8A5940123519FB54759BEC6C2620175A6E9969EDF`

已独立验证 artifacts/FROZEN.json 中 296 个输出文件大小与摘要全部一致，实际 exe 摘要匹配；此前批准的离线构建成功回执未执行 CLI。

## 本次边界

只启动该 exe 的两个固定 owned helper flags；所有 HOME/USERPROFILE/应用配置目录、活动日志、TEMP/TMP 都在本次合成运行目录。使用合成账号与会话，禁止读取生产凭据、生产数据库；只保留 captured pipes，固定 cwd，隐藏窗口。全部大小写 HTTP/HTTPS/ALL proxy 固定为 127.0.0.1，NO_PROXY 清空，临时 CA 只由子进程环境使用，不安装系统证书。模型/provider 环境与运行时注入变量剔除。

TLS 响应器只监听 loopback，自行终止 TLS 并返回严格固定的合成 GET/POST 响应，不连接或转发至平台。父进程 audit 不覆盖原生子进程，不声称 OS 网络沙箱；子进程边界依据已审代码全部 HTTP 经原固定 HTTPX 客户端并使用显式 loopback 代理，无失败 fallback。

本次使用真实 Adapters/account_spec/private registered read route/PageWorker 和真实发送 bridge；保留原 helper A 的普通 manifest，新能力才选择新 helper B。四案例为公开资料读取、单条成功、实际 UID 错误零 POST、回执身份冲突 unknown 且不重放。remote lease 是明确标记的合成 test object，不能把本次当成真实云授权验收；真实 Runner/lease 测试另计。

失败时保留日志与原 run 目录，先定位原因；不自动重跑、换平台通道或扩大网络范围。文件摘要变化需重新审查。

## compiled-02 局部修正批准

compiled-01 在合成数据准备阶段被 canonical customer UID 绑定检查阻断，尚未启动 helper。该目录没有 RESULT.json，不能把缺失结果说成 PASS；保留原目录与错误日志。

已独立核对 harness 的唯一变化：先保存合成 lead 的 author_id，再执行 f.assign('B')。将这两处次序变更反向还原后，计算出的完整文件 SHA256 正好等于前次已审 `191DE1204089DF30DD184AD4F7BF8F47947DF4143BAE499391071B3E4CE70728`，不存在其他变化。

新 harness SHA256：`177E200E609F1245FC802F2B84B05F4D854BFF790BECDA028A0DE3E4D016EE96`。

批准 root 在全新 binary-e2e/compiled-02 执行一次相同精确组件及所有原边界的 --compiled-reviewed 测试。exe、safety 和 TLS fixture 摘要沿用上文；不扩大平台、数据或网络范围。
