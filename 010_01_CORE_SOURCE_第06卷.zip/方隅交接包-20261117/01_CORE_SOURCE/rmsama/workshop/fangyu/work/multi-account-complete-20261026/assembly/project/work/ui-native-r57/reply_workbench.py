"""Narrow draft/review bridge over the preserved customer and Core interfaces.

No send/copy/manual-contact actions are exposed. Mutation receipts are written
before calling the non-idempotent legacy Core; uncertain calls are read only.
"""
from reply_context import conversation
from contextlib import contextmanager, nullcontext
from contextvars import ContextVar
from copy import deepcopy
import hashlib
import json
import re
from core import CoreError
from core.review_queue import require_reply_permission, snapshot

ENTITY = 'ui_reply_requests_v1'
ROUTING='ui_reply_draft_routing_v1'
_ROUTING_CONTEXT=ContextVar('reply_routing_context_v1',default=None)
KEY = re.compile(r'[A-Za-z0-9_-]{1,160}\Z')


class ReplyWorkbenchError(ValueError):
    def __init__(self, code, message, status=400):
        super().__init__(message)
        self.code, self.status = code, status


def fail(code, message, status=400):
    raise ReplyWorkbenchError(code, message, status)


def digest(value):
    return hashlib.sha256(json.dumps(value,ensure_ascii=False,sort_keys=True,
        separators=(',',':'),allow_nan=False).encode()).hexdigest()


class ReplyWorkbench:
    def __init__(self, core, customers):
        self.core, self.customers = core, customers

    @contextmanager
    def routing_context(self,value,user,scope,reopen=None):
        token=_ROUTING_CONTEXT.set({'snapshot':deepcopy(value),'scope':list(scope),'reopen':deepcopy(reopen)})
        try:yield
        finally:_ROUTING_CONTEXT.reset(token)

    def routing_binding(self,user,store_id,platform,lead_id):
        return self.core.store.get(ROUTING,self._routing_key(user,store_id,platform,lead_id))

    def _routing_key(self,user,store_id,platform,lead_id):
        return digest([user['tenant_id'],store_id,platform,lead_id])

    def _routing(self,user,store_id,platform,data,draft,action):
        key=self._routing_key(user,store_id,platform,data['leadId'])
        existing=self.core.store.get(ROUTING,key)
        original_binding=deepcopy(existing)
        if existing and existing.get('state')=='rejected' and not draft:existing=None
        context=_ROUTING_CONTEXT.get()
        selected=context or existing
        if context and context.get('reopen') and action=='reply_save':
            reopen=context['reopen']
            if draft!=reopen['draft'] or digest(existing)!=reopen['bindingDigest']:fail('REPLY_REOPEN_CHANGED','原稿或账号绑定已变化，请重新读取',409)
        if not selected:return None
        profiles=getattr(self,'account_profiles',None)
        if profiles is None:fail('REPLY_ROUTING_UNAVAILABLE','账号资料核验暂不可用，原稿保留',409)
        if existing and not context and action=='reply_save' and existing.get('state')=='ready':
            # Explicit original-editor save creates a new version from the current
            # manually confirmed assignment; the earlier version stays historical.
            decision_scope=[user['tenant_id'],user['id'],user['username'],store_id,platform]
            profiles.customer(user,decision_scope,data['customerId'])
            assigned=profiles.assignment(decision_scope,data['customerId']).get('accountId')
            if not assigned:fail('REPLY_ROUTING_CHANGED','请先重新选择客户回复账号，再保存新版本',409)
            fresh_scope=[user['tenant_id'],user['id'],store_id,assigned,platform]
            selected={'scope':fresh_scope,'snapshot':profiles.capture(user,fresh_scope,data['customerId'])}
        profiles.check(user,selected['scope'],data['customerId'],selected['snapshot'])
        if existing:
            if existing['snapshot']!=selected['snapshot'] and action!='reply_save':fail('REPLY_ROUTING_CHANGED','原稿属于另一账号资料版本，请保留原稿并核对',409)
            if (existing.get('state')!='ready' or not draft or existing.get('draftId')!=draft['id'] or existing.get('draftVersion')!=draft['version']):
                fail('REPLY_ROUTING_PENDING','原稿账号绑定结果待核对，不能绕过原操作审核',409)
        if action=='reply_review' and data['accountId']!=selected['snapshot']['accountId']:
            fail('REPLY_ROUTING_CHANGED','本稿已绑定选定账号，请重新核对客户分配',409)
        return {'id':key,'tenant_id':user['tenant_id'],'scope':selected['scope'],'snapshot':selected['snapshot'],
            'customerId':data['customerId'],'leadId':data['leadId'],'state':'pending',
            'requestId':data['requestId'],'expectedVersion':data['expectedVersion'],'text':data.get('text',draft.get('text','') if draft else ''),'_priorBinding':original_binding}

    def validate_routing(self,user,store_id,customer_id,lead_id,reply):
        lead=self.core._get('leads',lead_id,user['tenant_id'])
        require_reply_permission(self.core,user,lead,reply)
        binding=self.core.store.get(ROUTING,self._routing_key(user,store_id,lead['platform'],lead_id))
        if not binding:return
        if (binding.get('state')!='ready' or binding.get('draftId')!=reply.get('id')
                or binding.get('draftVersion')!=reply.get('version')
                or binding['snapshot']['accountId']!=reply.get('review_account_id')):
            fail('REPLY_ROUTING_CHANGED','草稿账号绑定已变化，请重新选择账号并保存审核',409)
        profiles=getattr(self,'account_profiles',None)
        if profiles is None:fail('REPLY_ROUTING_UNAVAILABLE','账号资料核验不可用',409)
        profiles.check(user,binding['scope'],customer_id,binding['snapshot'])

    def _cas_routing(self,expected,updated,expected_draft):
        # Restore only this operation's reservation and the exact unchanged draft.
        with self.core.store.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            found=db.execute('SELECT body FROM records WHERE entity=? AND id=?',(ROUTING,expected['id'])).fetchone()
            if not found or json.loads(found['body'])!=expected:return
            latest=db.execute("SELECT body FROM records WHERE entity='replies' AND tenant_id=? AND json_extract(body,'$.lead_id')=? ORDER BY CAST(json_extract(body,'$.version') AS INTEGER) DESC,id DESC LIMIT 1",(expected['tenant_id'],expected['leadId'])).fetchone()
            current=json.loads(latest['body']) if latest else None
            if (self._public(current) if current else None)!=expected_draft:return
            if updated is None:db.execute('DELETE FROM records WHERE entity=? AND id=?',(ROUTING,expected['id']))
            else:db.execute('INSERT OR REPLACE INTO records VALUES(?,?,?,?)',(ROUTING,updated['id'],updated['tenant_id'],json.dumps(updated,ensure_ascii=False)))

    def _reconcile_routing(self,user,store_id,data,receipt,draft):
        lead=self.core._get('leads',data['leadId'],user['tenant_id'])
        key=self._routing_key(user,store_id,lead['platform'],data['leadId'])
        binding=self.core.store.get(ROUTING,key)
        if not binding or binding.get('state')!='pending' or binding.get('requestId')!=data['requestId']:return
        if (binding.get('customerId')!=data['customerId'] or binding.get('leadId')!=data['leadId']
                or binding.get('expectedVersion')!=(receipt.get('intent') or {}).get('expectedVersion')):return
        state=receipt.get('state');updated=None;resolved=False
        if state in ('accepted','observed') and draft:
            intent=receipt['intent'];bound=receipt.get('reply') or {}
            if any(bound.get(k)!=draft.get(k) for k in ('id','version','text')):return
            if receipt['action']=='reply_save' and (draft['version']!=intent['expectedVersion']+1 or draft['text']!=binding['text'].strip()):return
            if receipt['action']=='reply_review' and (draft['id']!=intent['expectedReplyId'] or draft.get('review_account_id')!=binding['snapshot']['accountId']):return
            updated={**{k:v for k,v in binding.items() if k!='priorBinding'},'state':'ready','draftId':draft['id'],'draftVersion':draft['version']};resolved=True
        elif state in ('not_applied','rejected'):
            original=receipt.get('expectedDraft')
            if draft!=original:return
            if 'priorBinding' not in binding:return
            updated=deepcopy(binding['priorBinding']);resolved=True
        if resolved:self._cas_routing(binding,updated,draft)

    def _context(self, user, store_id, customer_id, platform=None):
        # Use exactly the existing employee/customer/task/store range.
        return self.customers.detail_context(user,store_id,customer_id,platform=platform)

    def _latest(self, actor, lead):
        rows = [row for row in self.core.store.list('replies',actor['tenant_id'])
                if row.get('lead_id')==lead['id']]
        if any(type(row.get('version')) is not int or row['version']<1 for row in rows):
            fail('REPLY_VERSION_INVALID','历史草稿版本需核对',409)
        return max(rows,key=lambda row:(row['version'],row['id']),default=None)

    def visible_sources(self, user, store_id, platform=None):
        """Reuse the original history's per-lead/task/store authorization once.

        Narrow fixture implementations may omit the history interface; callers
        then revalidate each selected customer through read(), never infer access.
        """
        if not all(hasattr(self.customers,name) for name in ('_actor','_history')):
            return None
        with self.core.lock:
            actor,_=self.customers._actor(user,store_id)
            history=self.customers._history(actor,store_id,platform)
            history._user(actor)
            return {row['id']:row for row in history._visible(actor)}

    def confirmation_current(self,user,store_id,lead_id,attempt,latest):
        """Exact old review receipt and approval snapshot, without rebuilding UI."""
        try:
            if hasattr(self.customers,'_actor'):user,_=self.customers._actor(user,store_id)
            if (not latest or latest.get('id')!=attempt.get('draftId')
                or latest.get('version')!=attempt.get('draftVersion')
                or latest.get('text')!=attempt.get('text') or latest.get('status')!='approved'
                or latest.get('author_id')!=user['id']
                or latest.get('review_account_id')!=attempt.get('accountId')):return False
            lead=self.core._get('leads',lead_id,user['tenant_id'])
            account=self.core._get('accounts',attempt['accountId'],user['tenant_id'])
            self.core._account_access(user,account)
            require_reply_permission(self.core,user,lead,latest)
            if account.get('store_id')!=store_id:return False
            request=attempt.get('review',{}).get('payload',{})
            receipt=self.core.store.get(ENTITY,self._receipt_id(user,store_id,request.get('requestId','')))
            return bool(receipt and receipt.get('action')=='reply_review'
                and receipt.get('state') in ('accepted','observed')
                and (receipt.get('reply') or {}).get('id')==latest['id']
                and (receipt.get('intent') or {}).get('sourceDigest')==digest(lead)
                and latest.get('approval_snapshot')==snapshot(self.core,latest,lead,account,user=user))
        except (ValueError,CoreError,KeyError):return False

    @staticmethod
    def _public(reply):
        if reply is None: return None
        return {key:reply.get(key) for key in ('id','text','version','status','review_account_id')}

    def read(self, user, store_id, customer_id, *, platform=None, _routing_check=True):
        with self.core.lock:
            actor, public, item, person = self._context(user,store_id,customer_id,platform)
            visible_sources=self.visible_sources(user,store_id,platform)
            receipts = [r for r in self.core.store.list(ENTITY,actor['tenant_id'])
                if r.get('owner')==actor['username'] and r.get('storeId')==store_id
                and r.get('customerId')==customer_id]
            pending = [r for r in receipts if r.get('state')=='submitted']
            comments = []
            replies_by_lead={}
            for saved in self.core.store.list('replies',actor['tenant_id']):
                replies_by_lead.setdefault(saved.get('lead_id'),[]).append(saved)
            visible_accounts=[]
            for account in self.core.store.list('accounts',actor['tenant_id']):
                try:self.core._account_access(actor,account)
                except CoreError:continue
                if account.get('store_id') in (None,'',store_id):visible_accounts.append(account)
            for original in person.get('comments') or []:
                # History intentionally strips owner/store internals. Fetch the
                # exact visible original only after its scoped membership check.
                lead = self.core._get('leads',original['lead_id'],actor['tenant_id'])
                saved=replies_by_lead.get(lead['id'],[])
                if any(type(row.get('version')) is not int or row['version']<1 for row in saved):
                    fail('REPLY_VERSION_INVALID','历史草稿版本需核对',409)
                reply=max(saved,key=lambda row:(row['version'],row['id']),default=None)
                reason = ''
                try:
                    require_reply_permission(self.core,actor,lead,reply)
                    self.core._reply_recipient(lead,'comment',user=actor)
                    if lead.get('source_type')!='comment': raise ValueError('此来源不是原评论')
                    if reply and reply.get('status') not in ('draft','approved'):
                        raise ValueError('此评论已有联系记录或未知结果，不能另存或审核')
                except (ValueError,CoreError) as error: reason = str(error)
                accounts = []
                for account in visible_accounts:
                    if account.get('platform')==lead.get('platform'):
                        accounts.append({'id':account['id'],'name':str(account.get('platform_nickname') or account.get('name') or '平台账号'),
                            'platformNickname':str(account.get('platform_nickname') or ''),'remarks':str(account.get('remarks') or ''),
                            'platform':account['platform']})
                review_current = False
                if reply and reply.get('status')=='approved' and not reason:
                    review_current = any(r.get('action')=='reply_review' and r.get('state') in ('accepted','observed')
                        and (r.get('reply') or {}).get('id')==reply['id']
                        and (r.get('intent') or {}).get('sourceDigest')==digest(lead) for r in receipts)
                    try:
                        account=self.core._get('accounts',reply.get('review_account_id'),actor['tenant_id'])
                        self.core._account_access(actor,account)
                        binding=self.core.store.get(ROUTING,self._routing_key(actor,store_id,lead['platform'],lead['id']))
                        if binding and _routing_check:
                            if getattr(self,'account_profiles',None) is None:raise ValueError('账号资料核验不可用')
                            self.account_profiles.check(actor,binding['scope'],customer_id,binding['snapshot'])
                            if binding.get('state')!='ready' or binding.get('draftId')!=reply['id'] or binding.get('draftVersion')!=reply['version']:raise ValueError('账号绑定待核对')
                        review_current=bool(review_current and account['id'] in {a['id'] for a in accounts}
                            and reply.get('approval_snapshot')==snapshot(self.core,reply,lead,account,user=actor))
                    except (CoreError,ValueError): review_current=False
                from assistant.reply_wording import review_saved_wording
                wording=review_saved_wording(reply.get('text')) if reply and reply.get('author_id')==actor['id'] else None
                if wording is not None:
                    wording.update(draftId=reply['id'],draftVersion=reply['version'],sourceDigest=digest(lead))
                comments.append({'id':lead['id'],'text':str(original.get('text') or ''),
                    'publishedAt':str(original.get('published_at') or ''),
                    'sourceNotice':'帖子日期未提供，时间范围待核实' if lead.get('post_date_status')=='unverified' else '',
                    'postTitle':str(lead.get('content_title') or lead.get('title') or '帖子标题未提供'),
                    'postUrl':str(original.get('note_url') or ''),'platform':lead.get('platform'),
                    'coverUrl':self.customers._media_url(store_id,lead['id'],'cover'),
                    'avatarUrl':self.customers._media_url(store_id,lead['id'],'author'),
                    'postAuthorAvatarUrl':self.customers._media_url(store_id,lead['id'],'post_author'),
                    'sourceDigest':digest(lead),'draft':self._public(reply) if not reply or reply.get('author_id')==actor['id'] else None,
                    'conversation':conversation(lead,visible_sources),
                    'wordingHints':wording,
                    'pendingRequestId':next((r['requestId'] for r in pending if r.get('leadId')==lead['id']),''),
                    'canSave':not reason,'reason':reason,'accounts':accounts,
                    'reviewCurrent':review_current,
                    'canReview':not reason and bool(reply and reply.get('status')=='draft' and accounts)})
            return {'actor':public,'scope':'employee-local-history','customerId':customer_id,
                'item':item,'comments':comments,'sendAvailable':False}

    def _receipt_id(self, actor, store_id, request_id):
        return digest([actor['tenant_id'],actor['id'],store_id,request_id])

    def check(self, user, store_id, data):
        result = self.read(user,store_id,data['customerId'])
        if data['leadId'] not in {row['id'] for row in result['comments']}:
            fail('REPLY_SOURCE_UNAVAILABLE','原评论不在当前客户可见范围',404)
        receipt = self.core.store.get(ENTITY,self._receipt_id(user,store_id,data['requestId']))
        if receipt and (receipt.get('customerId')!=data['customerId'] or receipt.get('leadId')!=data['leadId']):
            fail('REPLY_REQUEST_CONFLICT','操作编号与原评论不一致',409)
        if receipt and receipt['state']=='submitted':
            row = next(row for row in result['comments'] if row['id']==data['leadId'])
            draft, intent = row['draft'],receipt['intent']
            observed = draft and row['sourceDigest']==intent['sourceDigest'] and (
                receipt['action']=='reply_save' and draft['version']==intent['expectedVersion']+1
                and draft['status']=='draft' and draft['text']==intent['text'].strip()
                or receipt['action']=='reply_review' and draft['id']==intent['expectedReplyId']
                and draft['version']==intent['expectedVersion'] and draft['status']=='approved'
                and draft['review_account_id']==intent['accountId'])
            if observed:
                receipt={**receipt,'state':'observed','reply':draft}
                self.core.store.put(ENTITY,receipt)
                result=self.read(user,store_id,data['customerId'])
            elif draft==receipt.get('expectedDraft'):
                # No draft/review change persisted. An explicit check closes
                # this attempt; the next change is a new user decision.
                receipt={**receipt,'state':'not_applied'}
                self.core.store.put(ENTITY,receipt)
                result=self.read(user,store_id,data['customerId'])
            else:
                # The source/current version has since changed. Close only the
                # receipt after this explicit read; retain the current draft and
                # original submitted text, without declaring the old action valid.
                receipt={**receipt,'state':'changed'}
                self.core.store.put(ENTITY,receipt)
                result=self.read(user,store_id,data['customerId'])
        if receipt:
            current_row=next(r for r in result['comments'] if r['id']==data['leadId'])
            self._reconcile_routing(user,store_id,data,receipt,current_row['draft'])
            result=self.read(user,store_id,data['customerId'])
        result['receipt'] = {'requestId':data['requestId'],'state':receipt['state'] if receipt else 'not_found',
            'reply':receipt.get('reply') if receipt else None,
            'attemptText':((receipt.get('intent') or {}).get('text') or
                (receipt.get('expectedDraft') or {}).get('text','')) if receipt else ''}
        return result

    def execute(self, action, user, store_id, data):
        if not isinstance(data,dict):fail('INPUT_INVALID','回复操作参数无效')
        platform=self.customers.platform_filter(data)
        data={key:value for key,value in data.items() if key!='platform'}
        fields = {'reply_read':{'storeId','customerId'},
            'reply_check':{'storeId','customerId','leadId','requestId'},
            'reply_save':{'storeId','customerId','leadId','text','expectedVersion','expectedReplyId','sourceDigest','requestId'},
            'reply_review':{'storeId','customerId','leadId','expectedVersion','expectedReplyId','sourceDigest','requestId','accountId','confirmed'}}[action]
        if not isinstance(data,dict) or set(data)!=fields:
            fail('INPUT_INVALID','回复操作参数无效')
        for key in ('leadId','requestId','accountId'):
            if key in data and (not isinstance(data[key],str) or not KEY.fullmatch(data[key])):
                fail('INPUT_INVALID','原评论、账号或操作编号无效')
        if action=='reply_read': return self.read(user,store_id,data['customerId'],platform=platform)
        with self.core.lock:
            if platform is not None:
                self.customers.detail(user,store_id,data['customerId'],platform=platform)
            if action=='reply_check': return self.check(user,store_id,data)
            if (type(data['expectedVersion']) is not int or data['expectedVersion']<0
                    or not isinstance(data['expectedReplyId'],str)
                    or not isinstance(data['sourceDigest'],str)
                    or not re.fullmatch(r'[0-9a-f]{64}',data['sourceDigest'])):
                fail('INPUT_INVALID','请先读取当前原评论和草稿版本')
            if action=='reply_save' and (not isinstance(data['text'],str) or not data['text'].strip()
                    or len(data['text'])>1000 or re.search(r'[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]',data['text'])):
                fail('INPUT_INVALID','请填写1至1000字的回复草稿')
            if action=='reply_review' and data['confirmed'] is not True:
                fail('CONFIRM_REQUIRED','请逐条确认原评论、草稿内容和回复账号')
            current = self.read(user,store_id,data['customerId'])
            row = next((row for row in current['comments'] if row['id']==data['leadId']),None)
            if not row: fail('REPLY_SOURCE_UNAVAILABLE','原评论不在当前客户可见范围',404)
            ident = self._receipt_id(user,store_id,data['requestId'])
            prior = self.core.store.get(ENTITY,ident)
            signature = digest([action,data])
            if prior:
                if prior.get('signature')!=signature: fail('REPLY_REQUEST_CONFLICT','同一操作编号的内容已经变化',409)
                if prior['state'] in ('accepted','observed'):
                    current['receipt']={'requestId':data['requestId'],'state':prior['state'],'reply':prior['reply']}
                    return current
                if prior['state'] in ('rejected','not_applied','changed'):
                    fail('REPLY_REQUEST_CLOSED','原操作已核对关闭，请阅读当前版本后明确发起下一次修改',409)
                fail('REPLY_RESULT_UNCONFIRMED','上次草稿操作结果待核对，请读取原评论；不会重复变更',409)
            if row['sourceDigest']!=data['sourceDigest']:
                fail('REPLY_SOURCE_CHANGED','原评论来源或内容已变化，请重新读取',409)
            draft = row['draft']
            if ((draft['id'] if draft else '')!=data['expectedReplyId']
                    or (draft['version'] if draft else 0)!=data['expectedVersion']):
                fail('REPLY_VERSION_CONFLICT','草稿已在其他窗口更新，请先读取并逐条核对',409)
            if not row['canSave']: fail('REPLY_FORBIDDEN',row['reason'],403)
            if row['pendingRequestId']:
                fail('REPLY_RESULT_UNCONFIRMED','原评论上次操作结果待核对，请先核对上次操作',409)
            if action=='reply_review' and (not draft or draft['status']!='draft'
                    or data['accountId'] not in {a['id'] for a in row['accounts']}):
                fail('REPLY_REVIEW_REQUIRED','请选择本人同平台账号，并先保存当前草稿',409)
            platform_for_binding=next((c.get('platform') for c in current['comments'] if c['id']==data['leadId']),platform)
            routing=self._routing(user,store_id,platform_for_binding,data,draft,action)
            prior_binding=routing.pop('_priorBinding',None) if routing else None
            if routing:routing['priorBinding']=deepcopy(prior_binding)
            receipt = {'id':ident,'tenant_id':user['tenant_id'],'owner':user['username'],
                'customerId':data['customerId'],'leadId':data['leadId'],'signature':signature,'state':'submitted',
                'storeId':store_id,'requestId':data['requestId'],'action':action,
                'expectedDraft':draft,
                'intent':{**data,'expectedStatus':draft['status'] if draft else None}}
            # Only confirmations made through this version opt into collection.
            # Historical receipts remain historical even if later replayed.
            if action=='reply_review':
                receipt['voice_learning_contract']='fangyu-confirmed-reply-learning-v1'
            self.core.store.put(ENTITY,receipt)
            before = self._latest(user,self.core._get('leads',data['leadId'],user['tenant_id']))
            try:
                args = ({'lead_id':data['leadId'],'text':data['text'],'channel':'comment'} if action=='reply_save'
                    else {'id':draft['id'],'account_id':data['accountId'],'confirmed':True})
                expected_routing=deepcopy(prior_binding)
                def routing_guard(_db):
                    if routing:
                        self.account_profiles.check(user,routing['scope'],routing['customerId'],routing['snapshot'])
                        found=_db.execute('SELECT body FROM records WHERE entity=? AND id=?',(ROUTING,routing['id'])).fetchone()
                        actual=json.loads(found['body']) if found else None
                        if actual!=expected_routing:raise ValueError('草稿账号绑定已被其他窗口更新，请重新读取')
                        latest=_db.execute("SELECT body FROM records WHERE entity='replies' AND tenant_id=? AND json_extract(body,'$.lead_id')=? ORDER BY CAST(json_extract(body,'$.version') AS INTEGER) DESC,id DESC LIMIT 1",(user['tenant_id'],data['leadId'])).fetchone()
                        current=json.loads(latest['body']) if latest else None
                        unchanged=(self._public(current) if current else None)==draft
                        ours=current and current.get('author_id')==user['id'] and current.get('text')==routing['text'].strip() and current.get('version')==data['expectedVersion']+(1 if action=='reply_save' else 0) and current.get('status') in ('draft','approved')
                        if not unchanged and not ours:raise ValueError('原稿版本已被其他窗口更新，请重新读取')
                scoped=getattr(self.core.store,'scoped_write_guard',None)
                with scoped(routing_guard) if routing and callable(scoped) else nullcontext():
                    if routing:
                        self.core.store.put(ROUTING,routing)
                        expected_routing=deepcopy(routing)
                    result = self.core.handle('draft_reply' if action=='reply_save' else 'review_reply',args,user)
                    if routing:
                        ready={**{k:v for k,v in routing.items() if k!='priorBinding'},'state':'ready','draftId':result['id'],'draftVersion':result['version']}
                        self.core.store.put(ROUTING,ready)
                        expected_routing=deepcopy(ready)
                self.core.store.put(ENTITY,{**receipt,'state':'accepted','reply':self._public(result)})
            except Exception as error:
                # Core may already have committed before an audit/receipt error.
                after=self._latest(user,self.core._get('leads',data['leadId'],user['tenant_id']))
                if isinstance(error,(CoreError,ValueError)) and before==after:
                    if routing:
                        current_binding=self.core.store.get(ROUTING,routing['id'])
                        if current_binding==routing:
                            self._cas_routing(routing,deepcopy(prior_binding),draft)
                    self.core.store.put(ENTITY,{**receipt,'state':'rejected'})
                    fail('REPLY_REJECTED',str(error),409)
                fail('REPLY_RESULT_UNCONFIRMED','草稿操作结果待核对，请读取原评论；不会自动重试',409)
            current = self.read(user,store_id,data['customerId'])
            current['receipt']={'requestId':data['requestId'],'state':'accepted','reply':self._public(result)}
            return current
