import importlib.util,unittest,json,io,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
SPEC=importlib.util.spec_from_file_location('reply_worker',ROOT/'candidate/runtime/assistant/xhs_reply_worker.py')
m=importlib.util.module_from_spec(SPEC);SPEC.loader.exec_module(m)

class WorkerTests(unittest.TestCase):
 def request(self):return {'attemptId':'a1','expectedUid':'accountB','noteId':'note1','commentId':'comment1','text':'合成回复','requestDigest':'a'*64}
 def test_same_client_exact_wire(self):
  calls=[]
  class Client:
   def get_self_info(self):calls.append('me');return {'user_id':'accountB'}
   def reply_comment(self,*args):calls.append(args);return {'comment':{'id':'newComment'}}
  auth=[];r=m.run_once(Client(),self.request(),lambda *a:auth.append(a))
  self.assertEqual(calls,['me',('note1','comment1','合成回复')]);self.assertEqual(r['responseSenderUid'],None)
  self.assertEqual(r['identityProofSource'],'same_client_preflight_user_me');self.assertEqual(len(auth),2)
 def test_wrong_uid_zero_post(self):
  class Client:
   def get_self_info(self):return {'user_id':'accountA'}
   def reply_comment(self,*args):raise AssertionError('POST forbidden')
  with self.assertRaises(m.PreflightDenied):m.run_once(Client(),self.request(),lambda *a:None)
 def test_gate_rejects_changed_body_query_redirect_and_repeat(self):
  r=self.request();g=m.ExactWireGate(r,lambda *a:None)
  g('GET','https://edith.xiaohongshu.com/api/sns/web/v2/user/me',{})
  g.prove('accountB');body=m.post_body(r)
  for url,b in [('https://edith.xiaohongshu.com/api/sns/web/v1/comment/post?x=1',body),('https://other.invalid/api/sns/web/v1/comment/post',body),('https://edith.xiaohongshu.com/api/sns/web/v1/comment/post',{**body,'content':'changed'})]:
   with self.assertRaises(ValueError):g('POST',url,{'content':json.dumps(b)})
  g('POST','https://edith.xiaohongshu.com/api/sns/web/v1/comment/post',{'content':json.dumps(body)})
  with self.assertRaises(ValueError):g('POST','https://edith.xiaohongshu.com/api/sns/web/v1/comment/post',{'content':json.dumps(body)})
 def test_conflicting_sender_missing_id_unknown(self):
  for response in ({'comment':{'id':'newComment','user_info':{'user_id':'wrong'}}},{'content':'no id'}, {'user_id':'accountA','comment':{'id':'newComment','user_info':{'user_id':'accountB'}}},{'comment':{'id':'newComment','user_info':{'user_id':'accountB','id':'accountA'}}},{'id':'conflict','comment':{'id':'newComment'}}):
   class Client:
    def get_self_info(self):return {'user_id':'accountB'}
    def reply_comment(self,*a):return response
   with self.assertRaises(m.UnknownOutcome):m.run_once(Client(),self.request(),lambda *a:None)
 def test_conflicting_GETME_zero_POST(self):
  class Client:
   def get_self_info(self):return {'id':'accountB','user_id':'accountA'}
   def reply_comment(self,*a):raise AssertionError('POST forbidden')
  with self.assertRaises(m.PreflightDenied):m.run_once(Client(),self.request(),lambda *a:None)

if __name__=='__main__':unittest.main()
