from pathlib import Path
import ast
T=Path(__file__).resolve().parent.parent
p=T/'review_source_closure.py';s=p.read_text('utf-8-sig')
index=s.index('def main():')
helper="""def assert_unique_definitions(tree,filename):
    for scope in ast.walk(tree):
        body=getattr(scope,'body',None)
        if not isinstance(body,list):continue
        groups={}
        for node in body:
            if isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef)):
                groups.setdefault(node.name,[]).append(node)
        for name,nodes in groups.items():
            if len(nodes)==1:continue
            # A property decorator returns a new descriptor with the same
            # Python name. Accept only one initial getter and nonrepeated
            # same-name descriptor modifiers, never ordinary redefinitions.
            valid=isinstance(scope,ast.ClassDef) and all(isinstance(n,ast.FunctionDef) for n in nodes)
            first=nodes[0];seen=set()
            initial=[d for d in first.decorator_list if isinstance(d,ast.Name) and d.id=='property']
            valid=valid and len(initial)==1
            for node in nodes[1:]:
                modifiers=[d.attr for d in node.decorator_list if isinstance(d,ast.Attribute) and isinstance(d.value,ast.Name) and d.value.id==name and d.attr in ('getter','setter','deleter')]
                valid=valid and len(modifiers)==1 and modifiers[0] not in seen and not any(isinstance(d,ast.Name) and d.id=='property' for d in node.decorator_list)
                seen.update(modifiers)
            assert valid,'Same-scope duplicate: '+filename+' :: '+name

"""
s=s[:index]+helper+s[index:]
old="""            for scope in ast.walk(tree):
                body = getattr(scope, 'body', None)
                if not isinstance(body, list):
                    continue
                names = [node.name for node in body if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef))]
                assert len(names) == len(set(names)), 'Same-scope duplicate: ' + name"""
assert old in s;s=s.replace(old,"            assert_unique_definitions(tree,name)",1);ast.parse(s);p.write_text(s,'utf-8')
