"""Reuse the mature reply job fixture; models and delivery never execute."""
from pathlib import Path
from copy import deepcopy
import importlib.util,json,socket,sys,unittest
TASK=Path(__file__).resolve().parents[2]
BASE=Path(r'C:/积木软件工坊/项目/方隅公寓客户版/work/unified-intent-recheck-20261026/software/stage-v4/assembly/project')
PROJECT=TASK/'backend/candidate/project'
if '--project' in sys.argv:
 i=sys.argv.index('--project');PROJECT=Path(sys.argv[i+1]);del sys.argv[i:i+2]
sys.path[:0]=[str(PROJECT/'work/ui-native-r57'),str(BASE/'work/ui-native-r57')]
import reply_ai_workflow,reply_ai_provider
path=Path(r'C:/积木软件工坊/项目/方隅公寓客户版/work/context-reply-workflow-20261025/tests/test_workflow.py')
spec=importlib.util.spec_from_file_location('mature_reply_fixture',path);legacy=importlib.util.module_from_spec(spec);spec.loader.exec_module(legacy)

class ToneTests(legacy.Tests):
 def setUp(self):
  super().setUp()
  self.preferences={'revision':3,'identity':'管理员填的顾问身份不应覆盖住户','tone':'friendly','salutation':'你好','focus':['housing'],'templates':{'employee':'秘密员工SOP不得混入','customer':'自然说明条件，不保证现房。'}}
  self.reads=0
  def preferences(user,profile,data,token,save=False):
   self.assertEqual(data,{'storeId':'s'});self.assertFalse(save);self.reads+=1
   return {'preferences':deepcopy(self.preferences)}
  self.b._tone_preferences=preferences
  self.data.update(styleMode='store',expectedToneRevision=3)
 def test_read_uses_saved_store_preferences_without_employee_sop(self):
  result=self.w.dispatch('reply_ai_read',self.data,'token')['replyAI']
  self.assertEqual(result['savedTone']['revision'],3);self.assertEqual(result['savedTone']['tone'],'friendly')
  self.assertNotIn('秘密员工SOP',json.dumps(result,ensure_ascii=False));self.assertNotIn('管理员填的顾问',json.dumps(result,ensure_ascii=False))
  self.assertEqual([x['id'] for x in result['styleModes']],['store','friendly','concise','patient'])
 def test_batch_snapshot_is_fixed_and_retry_does_not_regenerate(self):
  first=self.start();snapshot=deepcopy(first['styleSnapshot']);self.preferences.update(tone='patient',revision=4)
  reads=self.reads;again=self.w.dispatch('reply_ai_start',self.data,'token')['replyAI']
  self.assertEqual(again['styleSnapshot'],snapshot);self.assertEqual(self.reads,reads)
  done=self.finish(first);self.assertEqual(done['styleSnapshot'],snapshot);self.assertEqual(len(self.calls),1)
  self.assertEqual(self.calls[0][1],snapshot)
  with self.assertRaises(ValueError):self.w.dispatch('reply_ai_start',{**self.data,'requestId':'new'},'token')
  self.assertEqual(len(self.calls),1)
 def test_styles_reach_provider_with_same_identity_rules(self):
  self.data['styleMode']='concise';first=self.finish(self.start());first_style=self.calls[0][1]
  self.data.update(styleMode='patient',requestId='second');second=self.finish(self.start());second_style=self.calls[1][1]
  self.assertNotEqual(first_style['effectiveStyle']['resolvedTone'],second_style['effectiveStyle']['resolvedTone'])
  self.assertEqual(first_style['savedTone']['identityRule'],second_style['savedTone']['identityRule'])
  self.assertEqual(first_style['savedTone']['identityRule'],'真实住户')
 def test_invalid_enum_revision_and_client_snapshot_are_rejected(self):
  for values in ({'styleMode':'admin'},{'expectedToneRevision':True},{'savedTone':self.preferences},{'styleSnapshot':{}}):
   with self.subTest(values=values),self.assertRaises(ValueError):self.w.dispatch('reply_ai_start',{**self.data,**values},'token')
  self.assertFalse(self.calls)
 def test_legacy_start_keeps_original_contract_and_missing_half_is_rejected(self):
  for field in ('styleMode','expectedToneRevision'):
   values={k:v for k,v in self.data.items() if k!=field}
   with self.assertRaises(ValueError):self.w.dispatch('reply_ai_start',values,'token')
  self.data.pop('styleMode');self.data.pop('expectedToneRevision')
  done=self.finish(self.start());self.assertNotIn('styleSnapshot',done);self.assertEqual(self.calls[0][1],'友善一点')
 def test_prompt_two_styles_differ_but_fixed_resident_identity_remains(self):
  self.data['styleMode']='concise';first=self.finish(self.start())
  self.data.update(styleMode='patient',requestId='next');second=self.finish(self.start())
  p1=reply_ai_provider.build_prompt({'synthetic':'context'},first['styleSnapshot'],[])
  p2=reply_ai_provider.build_prompt({'synthetic':'context'},second['styleSnapshot'],[])
  self.assertNotEqual(p1,p2);self.assertIn('简洁直接',p1);self.assertIn('耐心解释',p2)
  for prompt in (p1,p2):
   self.assertIn('实际住在方隅的普通住户',prompt);self.assertNotIn('秘密员工SOP',prompt);self.assertNotIn('管理员填的顾问',prompt)
   self.assertIn('不默认追问预算入住时间',prompt)
 def test_explicit_empty_precheck_can_be_adjusted_without_pending_job(self):
  self.row['draft']={'text':'原人工草稿'}
  with self.assertRaises(reply_ai_workflow.ReplyBatchNotCreated) as caught:self.w.dispatch('reply_ai_start',self.data,'token')
  self.assertEqual(caught.exception.code,'REPLY_AI_NOT_CREATED');self.assertIs(caught.exception.mutation_committed,False)
  self.assertFalse(self.store.list(reply_ai_workflow.ENTITY,'t'));self.assertFalse(self.calls)
  self.row['draft']=None;self.finish(self.start());self.assertEqual(len(self.calls),1)
 def test_error_after_put_is_not_reported_as_not_created(self):
  original=self.w.put
  def lost(row):original(row);raise ValueError('synthetic lost write response')
  self.w.put=lost
  with self.assertRaises(ValueError) as caught:self.w.dispatch('reply_ai_start',self.data,'token')
  self.assertNotIsInstance(caught.exception,reply_ai_workflow.ReplyBatchNotCreated)
  self.assertEqual(len(self.store.list(reply_ai_workflow.ENTITY,'t')),1);self.assertFalse(self.calls)

if __name__=='__main__':
 socket.socket.connect=lambda *a,**k:(_ for _ in ()).throw(AssertionError('network forbidden'))
 unittest.main(verbosity=2)
