"""Run in a fresh Python OS process after final freeze. No GUI/child/platform calls."""
import argparse,hashlib,importlib.util,json,os,re,sys,traceback
from urllib.parse import urlsplit,parse_qsl
from urllib.request import url2pathname
from pathlib import Path
sys.dont_write_bytecode=True
T=Path(__file__).resolve().parents[1]

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def require(ok,message):
 if not ok:raise AssertionError(message)
def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--pins',type=Path,required=True);ap.add_argument('--fixture-dir',type=Path);ap.add_argument('--run-name',default='native-complete-startup');ap.add_argument('--expected-material-sha256')
 a=ap.parse_args();require(not any(n in sys.modules for n in ('core','assistant','workbench_backend','reply_public_profile')),'Use a fresh OS process')
 pins=json.loads(a.pins.read_text('utf-8'));project=Path(pins['project']).resolve();release=Path(pins['release']).resolve()
 require(project==(T/'assembly/project').resolve() and release.is_relative_to(project),'Final inactive assembly only')
 require(sha(release/'RELEASE.json')==pins['manifestSha256'],'Frozen RELEASE changed')
 require(re.fullmatch(r'[A-Za-z0-9_-]{1,100}',a.run_name) is not None,'Simple fresh run name required')
 fixture=(a.fixture_dir or T/'verification'/a.run_name).resolve()
 require(fixture.is_relative_to((T/'verification').resolve()) and not fixture.exists(),'Fresh verification fixture required');fixture.mkdir(parents=True)
 for key in ('HOME','USERPROFILE','LOCALAPPDATA','APPDATA','XDG_CONFIG_HOME','TEMP','TMP'):os.environ[key]=str(fixture)
 allowed=[project,release,Path(sys.prefix).resolve(),Path(sys.base_prefix).resolve()]
 exact_readonly={Path(__file__).resolve(),(T/'materials/reviewed_reply_materials.json').resolve(),(T/'materials/reply_public_read_materials.json').resolve()}
 state={'status':'RUNNING','stage':'audit installed','networkAttempts':0,'processAttempts':0,'compiledChildExecuted':False,'productionDataRead':False,'productionWrites':False}
 def inside(p,roots):return any(p.is_relative_to(r) for r in roots)
 def checked_database(raw):
  raw=os.fsdecode(raw)
  if raw==':memory:':return
  if raw.startswith('file:'):
   parsed=urlsplit(raw)
   require(parsed.scheme=='file' and parsed.netloc=='' and not parsed.fragment,'Only local SQLite file URI permitted')
   require(parse_qsl(parsed.query,keep_blank_values=True) in ([('mode','rw')],[('mode','ro')]),'Only fixed SQLite rw/ro URI modes permitted')
   path=Path(url2pathname(parsed.path)).resolve()
  else:path=Path(raw).resolve()
  require(path.is_relative_to(fixture),'Production DB forbidden')
 def audit(event,args):
  if event in ('socket.connect','socket.getaddrinfo'):
   state['networkAttempts']+=1;raise AssertionError('Network forbidden: '+event)
  if event in ('subprocess.Popen','os.system','os.startfile','os.posix_spawn'):
   state['processAttempts']+=1;raise AssertionError('Child/UI process forbidden: '+event)
  if event=='sqlite3.connect':checked_database(args[0])
  if event=='open':
   path,mode,flags=args
   if isinstance(path,int):return
   path=Path(path).resolve();writing=(isinstance(mode,str) and any(c in mode for c in 'wax+')) or (isinstance(flags,int) and flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND))
   if writing:require(path.is_relative_to(fixture),'Write outside fixture: '+str(path))
   elif not path.is_relative_to(fixture):
    require(path.name.lower() not in ('auth.json','cookies.json','company.json','login data') and path.suffix.lower() not in ('.db','.sqlite','.sqlite3'),'Production credentials/config/DB forbidden: '+str(path))
    require(path in exact_readonly or inside(path,allowed),'Read outside source/runtime whitelist: '+str(path))
  if event in ('os.mkdir','os.remove','os.rmdir','os.chmod','os.truncate') and not isinstance(args[0],int):require(Path(args[0]).resolve().is_relative_to(fixture),'Mutation outside fixture: '+str(args[0]))
  if event in ('os.rename','os.replace'):
   for path in args[:2]:require(Path(path).resolve().is_relative_to(fixture),'Move outside fixture')
  if event.startswith('winreg.') and event not in ('winreg.OpenKey','winreg.OpenKey/result','winreg.QueryValue','winreg.QueryInfoKey','winreg.EnumKey','winreg.EnumValue','winreg.CloseKey'):raise AssertionError('Registry mutation forbidden')
 sys.addaudithook(audit)
 backend=None
 try:
  state['stage']='load frozen host';spec=importlib.util.spec_from_file_location('native_complete_host',release/'ui_native_host.py');host=importlib.util.module_from_spec(spec);sys.modules[spec.name]=host;spec.loader.exec_module(host)
  state['stage']='verify full RELEASE';manifest,files=host.verify_release(release,pins['manifestSha256'])
  company={'id':'fangyu-apartment-client','edition':'customer','personalMode':False,'authMode':'managed','releaseVersion':'1.1.8-pilot.1','workbench_source_release':'fangyu-admin-local-v1','managedWorkspace':{'environment_id':'synthetic-offline-startup','endpoint':'https://example.invalid'},'runtime':{'portable_employee_release':True,'public_send_hold':True,'public_reply_hold':True,'xiaohongshu_automation':'hold'}}
  holds=dict(company['runtime']);state['stage']='real create_backend factories'
  backend=host.create_backend(release,files,project_root=project,data_dir=fixture/'data',company=company)
  require(backend is not None and type(backend.core).__name__=='Core','Actual Core absent')
  require(type(backend.platform_runtime).__name__=='PlatformRuntime' and backend.platform_runtime.core is backend.core,'Actual owned PlatformRuntime absent')
  state['stage']='one actual core adapters module graph'
  actual_engine=sys.modules.get(type(backend.core).__module__)
  canonical_engine=sys.modules.get('core.engine')
  adapters_module=sys.modules.get('core.adapters')
  bridge_module=sys.modules.get('reviewed_reply_bridge')
  require(actual_engine is not None and actual_engine is canonical_engine,'Actual Core must belong to canonical core.engine module')
  require(getattr(actual_engine,'Core',None) is type(backend.core),'Actual Core class does not match its defining engine')
  require(adapters_module is not None and bridge_module is not None,'Canonical adapter or reviewed bridge module absent')
  require(actual_engine.AdapterBusy is bridge_module.AdapterBusy is adapters_module.AdapterBusy,'Duplicate AdapterBusy classes: actual engine, reviewed bridge and adapters must share one module graph')
  state['singleCoreAdaptersModuleGraph']=True
  require(type(backend.reply_workbench).__name__=='ReplyWorkbench','Actual ReplyWorkbench absent')
  from reply_account_profiles import AccountProfiles
  require(type(backend.reply_workbench.account_profiles) is AccountProfiles and backend.reply_workbench.account_profiles.b is backend,'AccountProfiles factory attachment missing')
  state['stage']='five real API routes without auth or dispatch'
  from reply_public_profile import ACTIONS,PublicReadWorkflow
  expected={'reply_session_check','reply_public_profile_start','reply_read_status','reply_read_cancel','reply_public_profile_apply'};require(set(ACTIONS)==expected and expected.issubset(host.API_ACTIONS),'Five API contract mismatch')
  for action in sorted(expected):
   try:backend.dispatch(action,{},'')
   except ValueError as error:require(getattr(error,'code',None)=='READ_INPUT_INVALID','API route not reached: '+action+' '+str(error))
   else:raise AssertionError('Empty API input accepted: '+action)
  require(type(backend.reply_public_reader) is PublicReadWorkflow,'Actual public reader not mounted')
  state['stage']='full sender registration material verification'
  from core.reply_execution_policy import digest
  registration=backend.core._reviewed_reply_registration;registration.check()
  declared=json.loads((release/'reviewed_reply_materials.json').read_text('utf-8'))
  independent=json.loads((T/'materials/reviewed_reply_materials.json').read_text('utf-8'))
  expected_digest=a.expected_material_sha256 or digest(independent)
  require(digest(declared)==digest(independent)==registration.manifest_digest==expected_digest,'Final sender material digest mismatch')
  require(registration.root==project and registration.manifest==declared,'Sender registration root/material mismatch')
  executable=(project/declared['executable']).resolve();require(executable.suffix.lower()=='.exe' and sha(executable)==declared['executableSha256'],'Actual compiled sender hash mismatch')
  require(bool(declared.get('runtimeTree')),'Compiled runtime closure absent')
  state['stage']='first lazy read registration from actual RELEASE'
  require(getattr(backend.core,'_reply_read_registration',None) is None,'Read registration unexpectedly eager')
  backend.reply_public_reader._ensure_read_registration();readreg=backend.core._reply_read_registration;readreg.check()
  require(readreg.root==project and readreg.manifest==json.loads((release/'reply_public_read_materials.json').read_text('utf-8')),'Read registration RELEASE mismatch')
  require(backend.core.deployment_config['runtime']==holds and backend.company['runtime']==holds,'Original holds changed')
  state.update(status='PASS',materialSha256=expected_digest,releaseId=pins['releaseId'],registeredSenderExecutableSha256=sha(executable),readMaterialSha256=readreg.manifest_digest,apiRoutes=sorted(expected),originalHoldsPreserved=True)
 except BaseException as error:
  state.update(status='FAIL',errorClass=type(error).__name__,error=str(error),traceback=traceback.format_exc());raise
 finally:
  if backend is not None:
   try:backend.close();require(backend.closed,'Backend close incomplete');state['closedNormally']=True
   except BaseException as error:
    state.update(status='FAIL',closeErrorClass=type(error).__name__,closeError=str(error));(fixture/'RESULT.json').write_text(json.dumps(state,ensure_ascii=False,indent=2),'utf-8');raise
  (fixture/'RESULT.json').write_text(json.dumps(state,ensure_ascii=False,indent=2),'utf-8')
 print(json.dumps(state,ensure_ascii=True))
if __name__=='__main__':main()
