"""Source-bound derived customer aggregate; original AI/manual remain authority.

All reads use the caller's existing authorized store/snapshot. This module never
writes, calls a model or authorizes a reply. Importers build the same fingerprint
with make_record after preserving original AI history and applying source CAS.
"""
from copy import deepcopy
from datetime import datetime
import hashlib
import json

from intent_contract import contract_digest, AGGREGATION_VERSION

ENTITY = 'customer_intent_projection_v1'
SCOPE_ENTITY = 'customer_intent_projection_scope_v1'
SCHEMA = 'fangyu-customer-intent-projection-v1'
SOURCE_FIELDS = ('id', 'tenant_id', 'cloud_owner', 'store_id', 'task_id', 'platform',
    'author_id', 'author', 'comment_id', 'source_id', 'source_type', 'text',
    'title', 'content_title', 'content_text', 'content_body', 'post_text',
    'parent_text', 'parent_id', 'target_comment_id', 'target_author_id', 'comment_level',
    'content_author', 'content_author_id', 'published_at', 'content_published_at',
    'created_at', 'note_url', 'url', 'live_source', 'is_post_author',
    'source_context', 'post_date_status')
TASK_FIELDS = ('id', 'tenant_id', 'cloud_owner', 'store_id', 'city', 'area',
    'platform', 'account_id', 'content_title', 'content_text', 'post_text',
    'content_body', 'note_url', 'url', 'scope')
ANALYSIS_FIELDS = ('ai_intent', 'manual_intent', 'analysis_status')
LEVELS = frozenset(('super_high', 'high', 'medium', 'low', 'very_low'))
STALE = '客户证据或判断有变化，需要重新汇总'


def evidence_guard_version():
    from core import intent_policy
    return getattr(intent_policy, 'EVIDENCE_GUARD_VERSION', intent_policy.POLICY_VERSION)


def digest(value):
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True,
        separators=(',', ':'), allow_nan=False).encode('utf-8')).hexdigest()


def source_digest(lead, task):
    from core.customer_intent_materials import source_digest as canonical_source_digest
    return canonical_source_digest(lead,task)


def analysis_digest(lead):
    return digest({key: deepcopy(lead.get(key)) for key in ANALYSIS_FIELDS})


def record_id(tenant, owner, store_id, platform, customer_id):
    return digest([SCHEMA, tenant, owner, store_id, platform, customer_id])


def scope_id(tenant, owner, store_id):
    return digest([SCOPE_ENTITY, tenant, owner, store_id])


def policy_binding(store, tenant, owner):
    from core.intent_policy import normalize_policy, policy_digest
    ident = policy_digest(['intent-policy-v1', tenant, owner])
    saved = store.get('intent_rule_policies', ident)
    if saved is None:
        return {'revision': 0, 'digest': policy_digest(normalize_policy({}))}
    normalized = normalize_policy(saved.get('policy'))
    if (saved.get('tenant_id') != tenant or saved.get('owner') != owner
            or type(saved.get('revision')) is not int or saved['revision'] < 1
            or saved.get('digest') != policy_digest(normalized)):
        raise ValueError('invalid current intent policy')
    return {'revision': saved['revision'], 'digest': saved['digest']}


def members(leads, tasks):
    if len({lead['id'] for lead in leads}) != len(leads):
        raise ValueError('duplicate projection member')
    return [{'lead_id': lead['id'],
             'source_digest': source_digest(lead, tasks.get(lead.get('task_id'), {})),
             'analysis_digest': analysis_digest(lead)}
            for lead in sorted(leads, key=lambda value: value['id'])]


def validate_customer(value, leads):
    if not isinstance(value, dict) or set(value) != {'status', 'level', 'demandState',
            'representativeLeadId', 'evidence', 'reason', 'closedLeadIds', 'needsConfirmation'}:
        raise ValueError('invalid customer aggregate fields')
    by_id = {lead['id']: lead for lead in leads}
    state, status, level = value['demandState'], value['status'], value['level']
    allowed = (state == 'active' and status == 'graded' and level in LEVELS
        or state == 'future' and status == 'graded' and level in ('low', 'very_low')
        or state in ('historical', 'unknown') and status == 'uncertain' and level is None
        or state in ('ended', 'unrelated') and status == 'unrelated' and level is None)
    if (not allowed or value['needsConfirmation'] is not True
            or value['representativeLeadId'] not in by_id
            or not isinstance(value['reason'], str) or not value['reason'].strip()
            or len(value['reason']) > 8000):
        raise ValueError('invalid customer aggregate state')
    quotes = value['evidence']
    if not isinstance(quotes, list) or len(quotes) > 100 or status == 'graded' and not quotes:
        raise ValueError('invalid customer aggregate evidence')
    for item in quotes:
        if (not isinstance(item, dict) or set(item) != {'leadId', 'quote'}
                or item.get('leadId') not in by_id or not isinstance(item.get('quote'), str)
                or not item['quote'].strip() or len(item['quote']) > 32000
                or item['quote'] not in str(by_id[item['leadId']].get('text') or '')):
            raise ValueError('aggregate quote is not its own original comment')
    closed = value['closedLeadIds']
    if (not isinstance(closed, list) or len(closed) != len(set(closed))
            or any(ident not in by_id for ident in closed)
            or closed and not quotes):
        raise ValueError('invalid closed demand references')
    if state == 'ended' and not quotes:
        raise ValueError('ended demand requires original ending evidence')
    # Semantic truth and chronology are reviewed by the model and Astra; these
    # structural checks never fabricate a keyword classifier or a human vote.
    return deepcopy(value)


def make_record(*, tenant, owner, store_id, platform, customer_id, leads, tasks,
                customer, batch_id, as_of, model, policy, provider='Codex'):
    if (not leads or provider != 'Codex' or not isinstance(model, str) or not model.strip()
            or any(not isinstance(value, str) or not value for value in
                   (tenant, owner, store_id, platform, customer_id, batch_id, as_of))
            or platform not in ('xiaohongshu', 'douyin')):
        raise ValueError('invalid aggregate provenance')
    stamp = datetime.fromisoformat(as_of.replace('Z', '+00:00'))
    if stamp.tzinfo is None:
        raise ValueError('aggregate time requires timezone')
    for lead in leads:
        task = tasks.get(lead.get('task_id'), {})
        if (lead.get('tenant_id') != tenant or lead.get('cloud_owner') != owner
                or lead.get('platform') != platform
                or (lead.get('store_id') or task.get('store_id')) != store_id
                or task.get('tenant_id') != tenant or task.get('cloud_owner') != owner):
            raise ValueError('aggregate source scope mismatch')
    return {'id': record_id(tenant, owner, store_id, platform, customer_id),
        'tenant_id': tenant, 'cloud_owner': owner, 'store_id': store_id,
        'platform': platform, 'customer_id': customer_id, 'schema': SCHEMA,
        'contract_digest': contract_digest(), 'aggregation_version': AGGREGATION_VERSION,
        'evidence_guard_version': evidence_guard_version(),
        'policy_binding': deepcopy(policy), 'batch_id': batch_id, 'as_of': as_of,
        'provider': provider, 'model': model, 'human_confirmed': False,
        'members': members(leads, tasks), 'customer': validate_customer(customer, leads)}


def read_for_people(store, actor, tenant, store_id, people):
    """Only authenticated history membership can expose a stored aggregate."""
    owner = actor['username']
    records = {row.get('customer_id'): row for row in store.list(ENTITY, tenant)
        if row.get('tenant_id') == tenant and row.get('cloud_owner') == owner
        and row.get('store_id') == store_id}
    marker = store.get(SCOPE_ENTITY, scope_id(tenant, owner, store_id))
    managed = (isinstance(marker, dict) and marker.get('tenant_id') == tenant
        and marker.get('cloud_owner') == owner and marker.get('store_id') == store_id
        and marker.get('active') is True)
    if not records and not managed:
        return {}
    raw = {lead['id']: lead for lead in store.list('leads', tenant)}
    tasks = {task['id']: task for task in store.list('tasks', tenant)}
    try:
        current_policy = policy_binding(store, tenant, owner)
    except (ValueError, TypeError, KeyError):
        current_policy = None
    results = {}
    expected_contract = contract_digest()
    expected_guard = evidence_guard_version()
    for ident, person in people.items():
        record = records.get(ident)
        if record is None and not managed:
            continue
        result = {'state': 'stale', 'reason': STALE}
        results[ident] = result
        try:
            ids = [comment['lead_id'] for comment in person.get('comments') or []]
            leads = [raw[lead_id] for lead_id in ids]
            if (not record or not ids or len(ids) != len(set(ids))
                    or record.get('id') != record_id(tenant, owner, store_id, person['platform'], ident)
                    or record.get('schema') != SCHEMA or record.get('contract_digest') != expected_contract
                    or record.get('evidence_guard_version') != expected_guard
                    or record.get('aggregation_version') != AGGREGATION_VERSION
                    or record.get('policy_binding') != current_policy or current_policy is None
                    or record.get('platform') != person['platform']
                    or record.get('provider') != 'Codex' or record.get('human_confirmed') is not False
                    or not isinstance(record.get('model'), str) or not record['model'].strip()
                    or record.get('members') != members(leads, tasks)):
                continue
            for lead in leads:
                task = tasks.get(lead.get('task_id'), {})
                if (lead.get('tenant_id') != tenant or lead.get('cloud_owner') != owner
                        or (lead.get('store_id') or task.get('store_id')) != store_id
                        or task.get('tenant_id') != tenant or task.get('cloud_owner') != owner):
                    raise ValueError('aggregate source no longer visible')
            validate_customer(record.get('customer'), leads)
            result.update(state='current', record=deepcopy(record))
        except (ValueError, TypeError, KeyError, OverflowError):
            continue
    return results
