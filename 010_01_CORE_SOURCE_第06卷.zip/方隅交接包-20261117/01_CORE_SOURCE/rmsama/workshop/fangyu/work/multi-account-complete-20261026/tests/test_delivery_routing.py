"""Final original delivery boundary must recheck a prepared draft's routing."""
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
import importlib.util,os,sys,unittest
T=Path(__file__).resolve().parents[1]
B=T.parent/'reply-complete-20261026/assembly/project'
N=Path(os.environ.get('SCOPE_TEST_NATIVE',str(B/'work/ui-native-r57/releases/ui-r57-20261026T101643Z-fa72ab42')))
sys.path[:0]=[str(N),str(B/'work/ui-runtime-r55/src')]
target=Path(sys.argv[1]) if len(sys.argv)>1 else T/'candidate/reply_delivery.py'
if len(sys.argv)>1:del sys.argv[1]
spec=importlib.util.spec_from_file_location('delivery_routing_under_test',target)
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)

class Boundary(unittest.TestCase):
 def setUp(self):
  self.user={'tenant_id':'t'};self.lead={'id':'l'}
  self.reply={'lead_id':'l','version':2,'text':'reviewed','status':'approved','review_account_id':'B','approval_snapshot':{'original':'snapshot'}}
  self.account={'store_id':'s'};self.calls=[]
  self.row={'customerId':'c','leadId':'l','replyId':'r','accountId':'B','sourceDigest':m.digest(self.lead),'version':2,'text':'reviewed','snapshot':self.reply['approval_snapshot']}
  records={'leads':self.lead,'replies':self.reply,'accounts':self.account}
  self.d=m.ReplyDelivery.__new__(m.ReplyDelivery)
  self.d.core=SimpleNamespace(_get=lambda entity,*args:records[entity],_account_access=lambda *a:None)
  self.d.replies=SimpleNamespace(_context=lambda *a:(self.user,None,None,{'comments':[{'lead_id':'l'}]}),validate_routing=self.validate)
 def validate(self,*args):
  self.calls.append(args)
  if getattr(self,'changed',False):raise ValueError('routing changed after preparation')
 def test_unchanged_prepared_draft_rechecks_routing(self):
  with patch.object(m,'require_reply_permission'),patch.object(m,'snapshot',return_value=self.row['snapshot']):
   self.assertIs(self.d._target(self.user,'s',self.row),self.reply)
  self.assertEqual(self.calls,[(self.user,'s','c','l',self.reply)])
 def test_changed_profile_blocks_at_final_boundary(self):
  self.changed=True
  with patch.object(m,'require_reply_permission'),patch.object(m,'snapshot',return_value=self.row['snapshot']),self.assertRaisesRegex(ValueError,'routing changed'):
   self.d._target(self.user,'s',self.row)
  self.assertEqual(len(self.calls),1)
 def test_original_snapshot_failure_still_blocks_before_routing(self):
  self.reply['text']='changed'
  with patch.object(m,'require_reply_permission'),self.assertRaises(ValueError):
   self.d._target(self.user,'s',self.row)
  self.assertEqual(self.calls,[])

if __name__=='__main__':unittest.main(verbosity=2)
