"""Authorized incremental UID pipeline; provider transport is separately injected."""
from copy import deepcopy
from datetime import datetime,timezone
import json

from core.customer_intent_materials import scope,source_digest,canonical_comment,digest
from core.customer_intent_dirty import ENTITY,mark_lead,mark_scope,key as dirty_key,read_record,write_record
from assistant.ai_attempts import _digest as attempt_digest
import customer_intent_projection as projection
from intent_contract import contract_digest

ROW_FIELDS=('status','level','reason','evidence','region_status','content_region','key_info')
ACTOR_FIELDS=('id','tenant_id','username','role','cloud_bound')
LEVELS=('super_high','high','medium','low','very_low')

def now():return datetime.now(timezone.utc).isoformat()

def approved_store_scope(tasks):
    from core.intent_policy import GUBEI_STORE_ID,resolved_task_city,task_analysis_rules,GUBEI_ANALYSIS_RULES
    return bool(tasks) and all(task.get('store_id')==GUBEI_STORE_ID and
        resolved_task_city(task) in ('上海','上海市') and task_analysis_rules(task)==GUBEI_ANALYSIS_RULES
        for task in tasks.values())

def make_pipeline(runtime,*,authorize,lead_access):
    """Trusted release factory; construction never starts the official CLI."""
    from official_codex import OfficialCodexAdapter
    from intent_contract import review_prompt
    from core.intent_policy import GUBEI_STORE_ID
    pipeline=CustomerIntentPipeline(runtime.core,None,authorize=authorize,lead_access=lead_access,
        scope_validator=approved_store_scope)
    pipeline.provider=OfficialCodexAdapter(runtime.core.store.path,
        runtime.core.store.directory/'local-codex-intent-receipts',
        contract_prompt=review_prompt(GUBEI_STORE_ID,'上海'),
        output_validator=pipeline.validate_provider_output)
    return pipeline

class PipelineReview(ValueError):pass

class CustomerIntentPipeline:
    def __init__(self,core,provider,*,authorize,lead_access,cancellation=lambda:False,scope_validator=lambda tasks:True):
        self.core,self.provider=core,provider
        self.authorize,self.lead_access,self.cancellation=authorize,lead_access,cancellation
        self.scope_validator=scope_validator

    def enqueue_lead(self,lead):
        with self.core.lock,self.core.store.connect() as db:
            db.execute('BEGIN IMMEDIATE');return mark_lead(db,lead)

    def reconcile_stale(self,user,store_id,*,recover=False):
        """One inventory on an explicit new local authorization, never upgrade.

        Current v3 projections do not create work. Later events use the durable
        dirty hook instead of repeatedly rechecking the whole store.
        """
        with self.core.lock,self.core.store.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            if not self._authorized(db,user):return {'queued':0,'state':'paused'}
            recovered=0
            if recover:
                for raw_job in db.execute("SELECT body FROM records WHERE entity=? AND tenant_id=? AND json_extract(body,'$.owner')=? AND json_extract(body,'$.scope.store_id')=?",
                        (ENTITY,user['tenant_id'],user['username'],store_id)).fetchall():
                    job=json.loads(raw_job['body'])
                    if job.get('state') in ('processing','waiting_original_request','needs_preparation','paused'):
                        write_record(db,ENTITY,{**job,'state':'pending','reason':'recover_original_request'})
                        recovered+=1
            people={};scopes={}
            raw=db.execute("SELECT body FROM records WHERE entity='leads' AND tenant_id=? AND json_extract(body,'$.cloud_owner')=?",
                (user['tenant_id'],user['username'])).fetchall()
            for item in raw:
                lead=json.loads(item['body']);task=read_record(db,'tasks',lead.get('task_id')) or {}
                value=scope(lead,task)
                if not value or not value['uid'] or value['store_id']!=store_id or self.lead_access(user,lead,task) is not True:continue
                ident=value['customer_id'];scopes[ident]=value
                person=people.setdefault(ident,{'platform':value['platform'],'comments':[]})
                person['comments'].append({'lead_id':lead['id']})
            states=projection.read_for_people(self.core.store,user,user['tenant_id'],store_id,people)
            queued=recovered
            for ident,state in states.items():
                if state.get('state')=='current':continue
                value=scopes[ident];job=read_record(db,ENTITY,dirty_key(value))
                if job and job.get('state') not in ('completed',):
                    if recover and job.get('state') in ('processing','waiting_original_request'):
                        write_record(db,ENTITY,{**job,'state':'pending','reason':'recover_original_request'})
                        queued+=1
                    continue
                mark_scope(db,value,'aggregate_stale');queued+=1
            return {'queued':queued}

    def _authorized(self,db,user):
        current=read_record(db,'users',user.get('id'))
        return bool(self.authorize() and not self.cancellation() and current and
            not current.get('disabled') and current.get('cloud_bound') is True and
            current.get('role') in ('operator','admin') and current.get('can_analyze') is not False and
            all(current.get(k)==user.get(k) for k in ACTOR_FIELDS))

    def _members(self,db,user,value):
        tasks={};leads=[]
        # Select only the UID; no unrelated customer material enters a request.
        rows=db.execute("SELECT body FROM records WHERE entity='leads' AND tenant_id=? "
            "AND json_extract(body,'$.cloud_owner')=? AND json_extract(body,'$.platform')=? "
            "AND trim(CAST(json_extract(body,'$.author_id') AS TEXT))=?",
            (value['tenant_id'],value['owner'],value['platform'],value['uid'])).fetchall()
        for row in rows:
            lead=json.loads(row['body']);task=read_record(db,'tasks',lead.get('task_id')) or {}
            if scope(lead,task)!=value or lead.get('demo'):continue
            if (task.get('tenant_id')!=value['tenant_id'] or task.get('cloud_owner')!=value['owner']
                    or task.get('store_id')!=value['store_id'] or task.get('platform')!=value['platform']
                    or self.lead_access(user,lead,task) is not True):
                raise PipelineReview('source_authority_changed')
            tasks[task['id']]=task;leads.append(lead)
        return sorted(leads,key=lambda row:row['id']),tasks

    @staticmethod
    def _fingerprints(leads,tasks):
        return [{'lead_id':row['id'],'source_digest':source_digest(row,tasks[row['task_id']]),
            'analysis_digest':projection.analysis_digest(row)} for row in leads]

    def _overlap(self,db,value,members,*,include_local=True):
        wanted={attempt_digest([value['tenant_id'],value['owner'],row['lead_id']]) for row in members}
        for entity,states in (('ai_attempts',('submitted','unknown','response_received')),
                              ('local_codex_attempts',('submitted','unknown','review_required'))):
            if entity=='local_codex_attempts' and not include_local:continue
            for raw in db.execute('SELECT body FROM records WHERE entity=? AND tenant_id=?',
                    (entity,value['tenant_id'])).fetchall():
                row=json.loads(raw['body'])
                if (row.get('owner')==value['owner'] and row.get('state') in states and
                        wanted.intersection(row.get('lead_digests') or [])):return True
        return False

    def _state(self,db,job,state,reason=''):
        current=read_record(db,ENTITY,job['id'])
        if not current or current['generation']!=job['generation']:return False
        write_record(db,ENTITY,{**current,'state':state,'reason':reason,'updated_at':now()});return True

    def run_one(self,user,store_id):
        with self.core.lock,self.core.store.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            if not self._authorized(db,user):return {'state':'paused'}
            rows=db.execute("SELECT body FROM records WHERE entity=? AND tenant_id=? "
                "AND json_extract(body,'$.owner')=? AND json_extract(body,'$.scope.store_id')=? "
                "AND json_extract(body,'$.state')='pending' ORDER BY id LIMIT 1",
                (ENTITY,user['tenant_id'],user['username'],store_id)).fetchall()
            if not rows:return {'state':'idle'}
            job=json.loads(rows[0]['body']);value=job['scope']
            leads,tasks=self._members(db,user,value)
            if not leads:
                self._state(db,job,'completed','no_current_members');return {'state':'completed'}
            if not self.scope_validator(tasks):
                self._state(db,job,'review_required','unsupported_rule_scope');return {'state':'review_required'}
            members=self._fingerprints(leads,tasks)
            # Only the adapter knows whether its exact local UNKNOWN has a
            # complete recoverable receipt. Do not prevent that offline path.
            if self._overlap(db,value,members,include_local=False):
                self._state(db,job,'waiting_original_request','unresolved_member_request')
                return {'state':'waiting_original_request'}
            if any(lead.get('ai_intent') and not lead.get('manual_intent') and
                    not isinstance(lead['ai_intent'].get('reviewed_source_digest'),str) for lead in leads):
                self._state(db,job,'review_required','legacy_analysis_source_binding_missing')
                return {'state':'review_required'}
            binding=projection.policy_binding(self.core.store,user['tenant_id'],user['username'])
            comments=[canonical_comment(lead,tasks[lead['task_id']]) for lead in leads]
            pending=[]
            for row in leads:
                if row.get('manual_intent'):continue
                ai=row.get('ai_intent')
                if (not ai or ai.get('reviewed_source_digest')!=source_digest(row,tasks[row['task_id']])
                        or ai.get('local_policy_digest',binding['digest'])!=binding['digest']):
                    pending.append(row['id'])
            if any(row['missing_materials'] for row in comments if row['id'] in pending):
                self._state(db,job,'needs_materials','acquired_context_incomplete')
                return {'state':'needs_materials'}
            from core.intent_policy import normalize_policy,policy_digest,EVIDENCE_GUARD_VERSION,resolved_task_city,task_analysis_rules
            policy_id=policy_digest(['intent-policy-v1',user['tenant_id'],user['username']])
            policy_record=read_record(db,'intent_rule_policies',policy_id) or {}
            policy=normalize_policy(policy_record.get('policy') or {})
            request={'request_id':digest([job['id'],job['generation'],members]),'scope':value,
                'members':members,'pending_comment_ids':pending,'contract_digest':contract_digest(),
                'evidence_guard_version':EVIDENCE_GUARD_VERSION,
                'context':{'comments':comments,'tasks':{ident:{'store_id':task.get('store_id'),
                    'city':resolved_task_city(task),'area':task.get('area') or '',
                    'rules':task_analysis_rules(task)} for ident,task in tasks.items()},
                    'policy':{'criteria':deepcopy(policy['criteria'])},'policy_binding':binding},
                'model':'gpt-6.1-sol'}
            self._state(db,job,'processing')
        def authorized():
            with self.core.store.connect() as db:
                if not self._authorized(db,user):return False
                try:current,current_tasks=self._members(db,user,value)
                except (ValueError,KeyError):return False
                return {row['id'] for row in leads}.issubset({row['id'] for row in current})
        def blocked(value,members):
            with self.core.store.connect() as db:return self._overlap(db,value,members)
        try:
            response=self.provider.execute(request,authorize=authorized,blocked_members=blocked)
            resolved,customer=self._validate_response(response,request,leads,tasks,policy)
        except Exception as error:
            code=getattr(error,'code','')
            state=('paused' if not authorized() else 'needs_preparation' if code=='LOCAL_CODEX_PREPARATION_REQUIRED'
                else 'waiting_original_request' if code in ('LOCAL_CODEX_UNKNOWN','PRODUCT_REQUEST_UNKNOWN') else 'review_required')
            with self.core.lock,self.core.store.connect() as db:
                db.execute('BEGIN IMMEDIATE');self._state(db,job,state,str(error)[:300])
            return {'state':state}
        return self._commit(user,job,leads,tasks,members,binding,resolved,customer,response)

    def _validate_response(self,response,request,leads,tasks,policy):
        output=response.get('output');receipt=response.get('receipt')
        if not isinstance(output,dict) or set(output)!={'comments','customer'} or not isinstance(receipt,dict):
            raise PipelineReview('provider_output_shape')
        if (receipt.get('provider')!='official_codex_local' or receipt.get('human_confirmed') is not False
                or receipt.get('model')!=request['model'] or receipt.get('scope')!=request['scope']
                or receipt.get('members')!=request['members'] or receipt.get('contract_digest')!=request['contract_digest']
                or (receipt.get('revalidated_guard_version') or receipt.get('evidence_guard_version'))!=request['evidence_guard_version']
                or not isinstance(receipt.get('request_id'),str) or not receipt['request_id']
                or not isinstance(receipt.get('receipt_sha256'),str) or len(receipt['receipt_sha256'])!=64):
            raise PipelineReview('provider_provenance_invalid')
        return self._validate_output(output,request,leads,tasks,policy)

    def validate_provider_output(self,output,request):
        """Called inside the provider before releasing its durable attempt.

        These canonical materials are part of the provider input fingerprint;
        only source/authority CAS can subsequently publish the result.
        """
        leads=[]
        for row in request['context']['comments']:
            leads.append({'id':row['id'],'task_id':row['task_id'],'text':row['text'],
                'content_title':row['post']['title'],'content_text':row['post']['text'],
                'parent_text':row['parent_text'],'is_post_author':row['is_post_author'],
                'ai_intent':row['saved_ai'],'manual_intent':row['manual_intent']})
        self._validate_output(output,request,leads,request['context']['tasks'],request['context']['policy'])
        return True

    def _validate_output(self,output,request,leads,tasks,policy):
        if not isinstance(output,dict) or set(output)!={'comments','customer'}:
            raise PipelineReview('provider_output_shape')
        rows=output['comments']
        if (not isinstance(rows,list) or any(not isinstance(row,dict) or set(row)!={'id',*ROW_FIELDS} for row in rows)
                or len({row['id'] for row in rows})!=len(rows)
                or {row['id'] for row in rows}!=set(request['pending_comment_ids'])):
            raise PipelineReview('pending_comment_coverage_invalid')
        from core.intent_policy import apply_intent_policy,task_analysis_rules,resolved_task_city
        by_id={lead['id']:lead for lead in leads};resolved={}
        for row in rows:
            lead=by_id[row['id']];task=tasks[lead['task_id']];material=canonical_comment(lead,task)
            context={'post':material['post'],'rules':task.get('rules',task_analysis_rules(task)),
                'city':resolved_task_city(task),'area':task.get('area') or ''}
            result=apply_intent_policy({**lead,'is_post_author':lead.get('is_post_author',material['is_post_author'])},row,policy,context)
            if any(result.get(key)!=row[key] for key in ROW_FIELDS):
                raise PipelineReview('new_comment_requires_semantic_review')
            resolved[row['id']]=result
        customer=projection.validate_customer(output['customer'],leads)
        if customer['status']=='graded':
            evidence_ids={x['leadId'] for x in customer['evidence']}
            representative=by_id[customer['representativeLeadId']]
            representative_intent=(representative.get('manual_intent') or
                resolved.get(representative['id']) or representative.get('ai_intent') or {})
            if (representative['id'] not in evidence_ids or representative['id'] in customer['closedLeadIds']
                    or representative_intent.get('status')!='graded'
                    or representative_intent.get('level') not in LEVELS
                    or LEVELS.index(representative_intent['level'])>LEVELS.index(customer['level'])):
                raise PipelineReview('aggregate_representative_not_supported')
            supported=False
            for lead in leads:
                effective=lead.get('manual_intent') or resolved.get(lead['id']) or lead.get('ai_intent') or {}
                if (lead['id'] in evidence_ids and lead['id'] not in customer['closedLeadIds'] and
                        effective.get('status')=='graded' and effective.get('level') in LEVELS and
                        LEVELS.index(effective['level'])<=LEVELS.index(customer['level'])):supported=True
            if not supported:raise PipelineReview('aggregate_not_supported_by_effective_comment')
        return resolved,customer

    def _commit(self,user,job,before,tasks,members,binding,resolved,customer,response):
        with self.core.lock,self.core.store.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            if not self._authorized(db,user):
                self._state(db,job,'paused','authority_changed');return {'state':'paused'}
            current,current_tasks=self._members(db,user,job['scope'])
            if projection.policy_binding(self.core.store,user['tenant_id'],user['username'])!=binding:
                self._state(db,job,'pending','policy_changed');return {'state':'source_changed'}
            same_members=self._fingerprints(current,current_tasks)==members
            by_id={lead['id']:lead for lead in current};old={lead['id']:lead for lead in before}
            stamp=now();receipt=response['receipt'];written=0
            for ident,result in resolved.items():
                actual=by_id.get(ident)
                expected=next(row for row in members if row['lead_id']==ident)
                if (actual is None or actual.get('manual_intent') or
                        source_digest(actual,current_tasks[actual['task_id']])!=expected['source_digest'] or
                        projection.analysis_digest(actual)!=expected['analysis_digest']):continue
                updated=deepcopy(actual)
                if actual.get('ai_intent'):
                    history=actual.get('ai_intent_history',[])
                    if not isinstance(history,list):raise PipelineReview('history_shape_invalid')
                    updated['ai_intent_history']=[*history,{**{key:deepcopy(actual.get(key)) for key in
                        ('ai_intent','analysis_status','content_region','verification_status','analysis_error','analysis_source_digest')},'archived_at':stamp}]
                updated['ai_intent']={**result,'provider':'Codex','model':receipt['model'],'human_confirmed':False,
                    'transport_provider':receipt['provider'],
                    'local_policy_revision':binding['revision'],'local_policy_digest':binding['digest'],
                    'validation_guard_version':projection.evidence_guard_version(),
                    'reviewed_source_digest':source_digest(actual,current_tasks[actual['task_id']]),
                    'review_batch_id':receipt['request_id'],'incremental_receipt_sha256':receipt.get('receipt_sha256'),
                    'analyzed_at':stamp}
                updated['analysis_status']=result['status'];updated['content_region']=result.get('content_region') or ''
                if result.get('region_status')=='unknown':updated['verification_status']='pending'
                write_record(db,'leads',updated);by_id[ident]=updated;written+=1
            if not same_members:
                # Valid individual source-CAS writes survive; only the stale
                # aggregate is rejected. The next job omits these saved rows.
                self._state(db,job,'pending','members_changed')
                current_job=read_record(db,ENTITY,job['id'])
                if current_job and current_job.get('state')=='processing':
                    write_record(db,ENTITY,{**current_job,'state':'pending','reason':'members_changed'})
                return {'state':'source_changed','analyzed':written}
            after=[by_id[row['id']] for row in current]
            value=job['scope']
            record=projection.make_record(tenant=value['tenant_id'],owner=value['owner'],store_id=value['store_id'],
                platform=value['platform'],customer_id=value['customer_id'],leads=after,tasks=current_tasks,
                customer=customer,batch_id=receipt['request_id'],as_of=stamp,model=receipt['model'],policy=binding)
            write_record(db,projection.ENTITY,record)
            self._state(db,job,'completed')
            return {'state':'completed','analyzed':written,'customer_id':value['customer_id']}
