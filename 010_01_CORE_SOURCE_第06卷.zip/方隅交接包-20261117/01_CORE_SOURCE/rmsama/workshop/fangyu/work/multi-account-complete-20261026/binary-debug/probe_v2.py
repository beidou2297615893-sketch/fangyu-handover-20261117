"""Source-only minimal missing-dependency probe; no component files mutated."""
from pathlib import Path
import sys,socket,subprocess,importlib.abc,importlib.util,json,traceback
sys.dont_write_bytecode=True
T=Path(__file__).resolve().parent.parent

def blocked(*a,**k):raise RuntimeError('No network/process allowed')
socket.socket.connect=socket.socket.connect_ex=socket.create_connection=socket.getaddrinfo=blocked
subprocess.Popen=blocked
sys.path[:0]=[str(T/'component-v2/inputs-source'),str(T/'component/build-work/site')]
loaded=[]
class MissingOnly(importlib.abc.MetaPathFinder):
 def find_spec(self,fullname,path=None,target=None):
  if fullname not in ('core.customer_intent_dirty','core.customer_intent_materials'):return None
  p=T/'assembly/project/work/ui-runtime-r55/src'/Path(*fullname.split('.')).with_suffix('.py')
  loaded.append(fullname)
  return importlib.util.spec_from_file_location(fullname,p)
# No dependency injection: imports use real new snapshot only.
import sqlite3
sqlite3.connect=blocked
probe_active=[True]
def audit(event,args):
 if probe_active[0] and event=='open':
  mode=args[1];flags=args[2]
  if (isinstance(mode,str) and any(c in mode for c in 'wax+')) or (isinstance(flags,int) and flags & (1|2|64|512|1024)):
   raise RuntimeError('Source probe forbids writes')
sys.addaudithook(audit)
r={'compiledChildExecuted':False,'platformCalls':0,'modifiedComponent':False}
try:
 from assistant.xhs_cli_page_worker import exact_source_gate
 gate=exact_source_gate(['whoami','--json','--phase','before'])
 import assistant.xhs_reply_worker as sender
 import core.reply_execution_policy
 import assistant.reply_read_session
 import core.engine
 import importlib.util,os
 entry=T/'component/inputs-source/platform_cli.py'
 spec=importlib.util.spec_from_file_location('readonly_dispatch_probe',entry);wrapper=importlib.util.module_from_spec(spec);spec.loader.exec_module(wrapper)
 main=sys.modules['__main__']
 for name in ('install_xhs_write_guards','install_xhs_profile_avatar_compat','install_xhs_sub_comments_compat'):
  setattr(main,name,getattr(wrapper,name))
 os.environ['LEADSTUDIO_ISOLATED']='1';os.environ['WORKSPACE_ACTIVITY_LOG']=str(T/'binary-debug/never-called-activity.jsonl')
 from assistant.xhs_cli_page_worker import _setup
 runner=_setup(lambda *a,**k:blocked());runner.close()
 for args in (['whoami','--json','--phase','after'],['user','c'*24,'--json'],['user-posts','c'*24,'--json','--max-items','3']):exact_source_gate(args)
 from xhs_cli.client import XhsClient
 request={'attemptId':'synthetic_attempt','expectedUid':'b'*24,'noteId':'a'*24,'commentId':'c'*24,'text':'synthetic reply','requestDigest':'1'*64}
 auth=[]
 wire=sender.ExactWireGate(request,lambda phase,details:auth.append(phase))
 class Fake:
  def get_self_info(self):
   wire('GET','https://edith.xiaohongshu.com/api/sns/web/v2/user/me',{})
   return {'user_id':'b'*24}
  def reply_comment(self,*args):
   wire('POST','https://edith.xiaohongshu.com/api/sns/web/v1/comment/post',{'content':json.dumps(sender.post_body(request))})
   return {'id':'synthetic_response','user':{'user_id':'b'*24}}
 receipt=sender.run_once(Fake(),request,lambda *a:None,wire)
 assert receipt['success'] and auth==['identity','post']
 r['senderFakeProtocol']='PASS_NO_NETWORK'
 r['status']='PASS';r['gateType']=type(gate).__name__;r['sourcePageSetup']='PASS_NO_RUNNER_CALL';r['senderAndCoreImports']='PASS';r['allFourReadGates']='PASS'
except Exception:r['status']='FAIL';r['traceback']=traceback.format_exc()
probe_active[0]=False
r['missingDependenciesLoadedFromExactBaseline']=loaded
r['snapshot']='component-v2/inputs-source';r['networkProcessDatabaseWritesForbiddenDuringProbe']=True
(T/'binary-debug/V2-SOURCE-PROBE.json').write_text(json.dumps(r,ensure_ascii=False,indent=2),'utf-8');print(json.dumps(r,ensure_ascii=False))

