"""Client-local Store guard is same-transaction, thread-scoped and reversible."""
from pathlib import Path
import importlib.util,json,sys,tempfile,threading,time,unittest
W=Path(__file__).resolve().parents[1]
BASE=W.parents[1]/'work/reply-tone-integration-20261026-final/assembly/project'
sys.path.insert(0,str(BASE/'work/ui-runtime-r55/src'))
import core
spec=importlib.util.spec_from_file_location('core.reply_complete_guard_store',W/'assembly/project/work/ui-runtime-r55/src/core/store.py')
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)

class WriteGuard(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(dir=W/'evidence');self.addCleanup(self.temp.cleanup)
        self.store=module.Store(self.temp.name)
    def test_guard_runs_in_write_transaction_and_restores_after_exit(self):
        seen=[]
        def guard(db):seen.append(db.in_transaction);raise ValueError('source changed')
        with self.store.scoped_write_guard(guard):
            for operation in (lambda:self.store.put('replies',{'id':'one','tenant_id':'t'}),
                    lambda:self.store.put_many('replies',[{'id':'two','tenant_id':'t'}]),
                    lambda:self.store.put_records([('replies',{'id':'three','tenant_id':'t'})])):
                with self.assertRaises(ValueError):operation()
        self.assertEqual(seen,[True,True,True]);self.assertEqual(self.store.list('replies','t'),[])
        self.store.put('replies',{'id':'safe','tenant_id':'t'})
        self.assertEqual(len(self.store.list('replies','t')),1)
    def test_source_writer_cannot_change_between_guard_and_approved_write(self):
        self.assertTrue(callable(getattr(self.store,'scoped_write_guard',None)))
        self.store.put('leads',{'id':'source','tenant_id':'t','text':'原话'})
        entered=threading.Event();started=threading.Event();finished=threading.Event()
        def writer():
            if not entered.wait(2):return
            started.set()
            self.store.put('leads',{'id':'source','tenant_id':'t','text':'已租到'})
            finished.set()
        thread=threading.Thread(target=writer);thread.start()
        def guard(db):
            entered.set();self.assertTrue(started.wait(1));time.sleep(.03)
            self.assertFalse(finished.is_set())
            row=db.execute("SELECT body FROM records WHERE entity='leads' AND id='source'").fetchone()
            self.assertEqual(json.loads(row['body'])['text'],'原话')
        with self.store.scoped_write_guard(guard):self.store.put('replies',{'id':'approved','tenant_id':'t','status':'approved'})
        thread.join(2);self.assertFalse(thread.is_alive());self.assertTrue(finished.is_set())
        self.assertEqual(self.store.get('replies','approved')['status'],'approved')
    def test_changed_source_before_guard_blocks_approval(self):
        self.store.put('leads',{'id':'source','tenant_id':'t','text':'已租到'})
        def guard(db):
            row=db.execute("SELECT body FROM records WHERE entity='leads' AND id='source'").fetchone()
            if json.loads(row['body'])['text']!='原话':raise ValueError('source changed')
        with self.store.scoped_write_guard(guard),self.assertRaises(ValueError):
            self.store.put('replies',{'id':'approved','tenant_id':'t','status':'approved'})
        self.assertIsNone(self.store.get('replies','approved'))

if __name__=='__main__':unittest.main(verbosity=2)
