"""Crash/restart and scope regressions over real isolated Core receipts."""
import os,sys,time,unittest
from pathlib import Path
from unittest.mock import patch
ROOT=Path(__file__).resolve().parents[1]
PROJECT=Path(os.environ.get('TONE_TEST_PROJECT',str(ROOT/'assembly/project')))
NATIVE=Path(os.environ.get('TONE_TEST_NATIVE',str(PROJECT/'work/ui-native-r57')))
os.environ['TONE_TEST_PROJECT']=str(PROJECT);os.environ['TONE_TEST_NATIVE']=str(NATIVE)
sys.path.insert(0,str(ROOT.parent/'confirmed-tone-learning-20261025'))
import test_backend_learning as fixtures
from reply_ai_workflow import Workflow,digest,ENTITY
from reply_context import conversation
from copy import deepcopy

class Recovery(unittest.TestCase):
    def setUp(self):
        f=self.f=fixtures.BackendLearningTests('test_review_collects_final_text_through_real_loader_and_replay_is_idempotent');f.setUp();self.addCleanup(f.doCleanups)
        f.store.delete('replies','reply1')
        f.lead.update(comment_level=2,parent_id='p',parent_text='这个是两房的',target_comment_id='p',content_title='示例转租帖')
        f.store.put('leads',f.lead)
        original=f.b.reply_workbench.customers.detail_context
        self.visible=True;self.model_calls=0
        def context(*args,**kwargs):
            if not self.visible:raise ValueError('客户范围已撤销')
            actor,public,item,person=original(*args,**kwargs)
            return actor,public,{'name':'示例客户'},person
        f.b.reply_workbench.customers.detail_context=context
        f.b.reply_workbench.customers.detail=lambda user,store,customer,platform=None:context(user,store,customer,platform=platform)
        def provider(*_args):
            self.model_calls+=1
            return {'relationship':'客户问父评论作者','need':'问价格','fit':'尚不确定','reason':'分享另一个选择','reply':'你也可以看看我住的方隅呀','unknown':['实时价格未知'],'shouldReply':True}
        self.provider=provider;self.w=Workflow(f.b,provider);f.b.context_reply_workflow=self.w
        self.args={'storeId':'store1','accountId':'account1','platform':'xiaohongshu','customerIds':['customer1'],'tone':'友善简短','requestId':'request-ai'}
        self.job=self.w.dispatch('reply_ai_start',self.args,'fixture-token')['replyAI']
        for _ in range(100):
            if self.job['id'] not in self.w.running:break
            time.sleep(.01)
        self.reload()
        self.assertEqual(self.job['rows'][0]['status'],'ready')
    def reload(self):
        self.job=self.w.dispatch('reply_ai_status',{**self.args,'jobId':self.job['id']},'fixture-token')['replyAI'];return self.job
    def confirm(self):
        row=self.job['rows'][0]
        self.job=self.w.dispatch('reply_ai_confirm',{**self.args,'jobId':self.job['id'],'leadId':row['leadId'],'confirmationKey':row['confirmationKey'],'confirmed':True},'fixture-token')['replyAI']
        return self.job['rows'][0]['confirmation']['state']
    def reconcile_after_restart(self):
        self.w=Workflow(self.f.b,self.provider);self.f.b.context_reply_workflow=self.w
        self.job=self.w.dispatch('reply_ai_reconcile',{**self.args,'jobId':self.job['id']},'fixture-token')['replyAI']
        return self.job['rows'][0]['confirmation']['state']
    def assert_no_send(self):self.assertEqual(self.f.store.list('reply_queues','t'),[])
    def test_confirm_learns_exactly_once(self):
        self.assertEqual(self.confirm(),'confirmed');self.assertEqual(self.confirm(),'confirmed')
        self.assertEqual(self.f.library.read(self.f.user,self.f.scope)['count'],1);self.assert_no_send()
    def test_lost_save_receipt_reconciles_without_new_approval(self):
        original=self.f.b._dispatch
        def lost(action,data,token):
            result=original(action,data,token)
            if action=='reply_save':raise OSError('lost response after commit')
            return result
        with patch.object(self.f.b,'_dispatch',side_effect=lost):self.assertEqual(self.confirm(),'save_pending')
        self.assertEqual(self.reconcile_after_restart(),'saved')
        self.assertTrue(all(r['status']=='draft' for r in self.f.store.list('replies','t')))
        self.assertEqual(self.f.library.read(self.f.user,self.f.scope)['count'],0)
        self.assertEqual(self.confirm(),'confirmed');self.assert_no_send()
    def test_not_applied_requires_new_explicit_attempt(self):
        original=self.f.b._dispatch
        def before(action,data,token):
            if action=='reply_save':raise OSError('never submitted')
            return original(action,data,token)
        with patch.object(self.f.b,'_dispatch',side_effect=before):self.assertEqual(self.confirm(),'save_pending')
        self.assertEqual(self.reconcile_after_restart(),'closed')
        self.assertEqual(self.f.store.list('replies','t'),[])
        self.assertEqual(self.confirm(),'confirmed')
        raw=self.f.store.get('ui_context_reply_jobs_v1',self.job['id'])
        attempts=raw['rows'][0]['attempts'];self.assertEqual(len(attempts),2)
        self.assertNotEqual(attempts[0]['save']['payload']['requestId'],attempts[1]['save']['payload']['requestId']);self.assert_no_send()
    def test_lost_review_receipt_does_not_repeat_approval_or_learning(self):
        original=self.f.b._dispatch;approvals=[]
        def lost(action,data,token):
            result=original(action,data,token)
            if action=='reply_review':approvals.append(1);raise OSError('lost after review')
            return result
        with patch.object(self.f.b,'_dispatch',side_effect=lost):self.assertEqual(self.confirm(),'review_pending')
        self.assertEqual(self.reconcile_after_restart(),'confirmed')
        self.assertEqual(len(approvals),1);self.assertEqual(self.f.library.read(self.f.user,self.f.scope)['count'],1)
        self.assertEqual(self.confirm(),'confirmed');self.assert_no_send()
    def test_learning_failure_recovers_via_check_only(self):
        with patch.object(self.f.b,'_voice_sample_component',side_effect=OSError('missing')):
            self.assertEqual(self.confirm(),'confirmed')
        self.assertEqual(self.f.library.read(self.f.user,self.f.scope)['count'],0)
        self.assertEqual(self.reconcile_after_restart(),'confirmed')
        self.assertEqual(self.f.library.read(self.f.user,self.f.scope)['count'],1);self.assert_no_send()
    def test_unowned_same_text_draft_is_never_adopted(self):
        self.f.store.put('replies',{**self.f.reply,'text':self.job['rows'][0]['text']})
        with self.assertRaisesRegex(ValueError,'不属于本批'):self.confirm()
        self.assertEqual(self.f.store.get('replies','reply1')['status'],'draft');self.assert_no_send()
    def test_edit_after_confirmation_requires_new_confirmation(self):
        self.assertEqual(self.confirm(),'confirmed')
        row=self.job['rows'][0]
        self.job=self.w.dispatch('reply_ai_edit',{**self.args,'jobId':self.job['id'],'revision':self.job['revision'],'edits':[{'leadId':row['leadId'],'text':'Hello，也可以看看这边呀！','selected':True}]},'fixture-token')['replyAI']
        self.assertEqual(self.job['rows'][0]['confirmation']['state'],'not_started')
        self.assertEqual(self.job['confirmationCounts']['confirmed'],0)
        self.assertEqual(self.confirm(),'confirmed');self.assert_no_send()
    def test_external_draft_change_invalidates_old_confirmation(self):
        self.assertEqual(self.confirm(),'confirmed')
        saved=self.f.store.list('replies','t')[0]
        self.f.store.put('replies',{**saved,'id':'external2','version':saved['version']+1,'status':'draft','text':'原编辑器另写的内容'})
        job=self.reload();self.assertEqual(job['confirmationCounts']['confirmed'],0)
        with self.assertRaisesRegex(ValueError,'状态已变化'):self.confirm()
        self.assertEqual(self.f.store.get('replies','external2')['text'],'原编辑器另写的内容');self.assert_no_send()
    def test_changed_first_row_does_not_block_second_receipt(self):
        lead2={**self.f.lead,'id':'lead2','comment_id':'comment2','text':'可以养猫吗'};self.f.store.put('leads',lead2)
        old_context=self.f.b.reply_workbench.customers.detail_context
        def two(*args,**kwargs):
            actor,public,item,person=old_context(*args,**kwargs)
            person['comments'].append({'lead_id':'lead2','text':lead2['text']})
            return actor,public,item,person
        self.f.b.reply_workbench.customers.detail_context=two
        # Adding a same-customer member invalidates the old generation snapshot.
        # Obtain both rows through the real start boundary rather than copying
        # an old row while silently omitting its complete-history proof.
        self.args['requestId']='two-receipt-fixture'
        self.job=self.w.dispatch('reply_ai_start',self.args,'fixture-token')['replyAI']
        for _ in range(100):
            if self.job['id'] not in self.w.running:break
            time.sleep(.01)
        self.reload()
        self.assertEqual([row['status'] for row in self.job['rows']],['ready','ready'])
        original=self.f.b._dispatch
        def lost(action,data,token):
            result=original(action,data,token)
            if action=='reply_save':raise OSError('lost after commit')
            return result
        with patch.object(self.f.b,'_dispatch',side_effect=lost):
            self.confirm();self.reload();second=self.job['rows'][1]
            self.w.dispatch('reply_ai_confirm',{**self.args,'jobId':self.job['id'],'leadId':'lead2','confirmationKey':second['confirmationKey'],'confirmed':True},'fixture-token')
        self.f.store.put('leads',{**self.f.lead,'text':'来源已更新'})
        calls=[]
        def record(action,data,token):calls.append(action);return original(action,data,token)
        with patch.object(self.f.b,'_dispatch',side_effect=record):self.reconcile_after_restart()
        raw=self.f.store.get(ENTITY,self.job['id'])
        self.assertEqual(raw['rows'][0]['attempts'][-1]['state'],'closed')
        self.assertEqual(raw['rows'][1]['attempts'][-1]['state'],'saved')
        self.assertEqual(calls,['reply_check','reply_check']);self.assert_no_send()
    def test_permission_removed_hides_saved_context(self):
        self.visible=False;job=self.reload();row=job['rows'][0]
        self.assertIsNone(row['context']);self.assertEqual(row['text'],'');self.assertIsNone(row['analysis'])
        self.assertEqual(row['confirmationKey'],'');self.assertFalse(row['selected'])
    def test_permission_removed_before_provider_prevents_call(self):
        self.visible=False;raw=self.f.store.get('ui_context_reply_jobs_v1',self.job['id']);raw['state']='running';raw['rows'][0].update(status='pending',analysis=None,text='',selected=False)
        self.f.store.put('ui_context_reply_jobs_v1',raw);before=self.model_calls
        self.w.running.add(raw['id']);self.w.run(raw['id'],self.args,'fixture-token',raw['scope'],[])
        self.assertEqual(self.model_calls,before)

if __name__=='__main__':unittest.main(verbosity=2)
