"""Six synthetic accounts through original draft, prepare, start and queue."""
import importlib.util,sys,os,time,json,threading,unittest,socket,subprocess
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
T=Path(__file__).resolve().parents[2];P=Path(os.environ.get('SENDER_PROJECT',str(T.parent/'multi-account-reply-20261026/assembly/project')));R=Path(os.environ.get('SENDER_NATIVE',str(P/'work/ui-native-r57/releases/ui-r57-20261026T130202Z-ba1ea294')));C=Path(os.environ.get('SENDER_CANDIDATE',str(T/'candidate')));RT=Path(os.environ.get('SENDER_RUNTIME',str(C/'runtime')));SEND=Path(os.environ.get('SENDER_SEND',str(C/'send')))
os.environ.update(MULTI_REPLY_PROJECT=str(P),MULTI_REPLY_RELEASE=str(R),MULTI_REPLY_CANDIDATE=str(C))
sys.path[:0]=[str(C),str(SEND),str(R),str(P/'work/ui-runtime-r55/src')]
import core,assistant
core.__path__.insert(0,str(RT/'core'));assistant.__path__.insert(0,str(RT/'assistant'))
spec=importlib.util.spec_from_file_location('old_fixture',T.parent/'multi-account-reply-20261026/tests/backend/test_multi_account_integration.py');fmod=importlib.util.module_from_spec(spec);spec.loader.exec_module(fmod);fmod.TASK=T
spec=importlib.util.spec_from_file_location('core.reviewed_test_engine',RT/'core/engine.py');em=importlib.util.module_from_spec(spec);spec.loader.exec_module(em);Core=em.Core
from core.review_queue import ReviewedReplyQueues
from core.continuous import AccountModeLeases
from core.reply_execution_policy import register,file_digest,digest,current_decision
from assistant.xhs_reply_worker import run_once,ExactWireGate,post_body
spec=importlib.util.spec_from_file_location('candidate_reply_delivery',SEND/'reply_delivery.py');dm=importlib.util.module_from_spec(spec);spec.loader.exec_module(dm);ReplyDelivery=dm.ReplyDelivery

class DeliveryTests(unittest.TestCase):
 def setUp(self):
  fmod.Core=Core
  f=self.f=fmod.MultiTests('test_six_accounts_pet_recommends_B_and_workflow_confirms_without_send');f.setUp();self.addCleanup(f.doCleanups)
  f.user.update(can_reply=True,permission_revision='a'*64);f.store.put('users',f.user)
  self.core=f.core;self.wires=[];self.actual='uidB';self.timeout=False;self.before_post=None;self.send_lease=True
  for aid in 'ABCDEF':a=f.store.get('accounts',aid);a['status']='ready';a['daily_send_limit']=20;f.store.put('accounts',a)
  core=f.core;core.remote_safety_hold=False;core.deployment_config={'id':'fangyu-apartment-client','runtime':{'portable_employee_release':True,'public_send_hold':True,'xiaohongshu_automation':'hold'}}
  core.require_platform=lambda p:None;core._employee_quota=lambda *a:None
  core.continuous=SimpleNamespace(leases=AccountModeLeases(f.store,'synthetic-send'),runtime_id='synthetic-send',status=lambda task:{},close=lambda **k:None)
  core.reviewed_reply_queues=ReviewedReplyQueues(core,defer_startup_recovery=True)
  previous_handle=core.handle
  def handle(action,data,user):
   if action=='prepare_reply_queue':return core.reviewed_reply_queues.prepare(data,user,'t')
   if action=='reviewed_reply_queue_status':return core.store.get('reply_queues',data['id'])
   if action=='cancel_reviewed_reply_queue':return core.reviewed_reply_queues.cancel(core.store.get('reply_queues',data['id']),user)
   return previous_handle(action,data,user)
  core.handle=handle
  core.adapters=SimpleNamespace(platform_guard=None,lifecycle_lock=threading.Lock(),manifest=lambda p:{'reply_contract_verified':False,'isolation_guard':True},require_account_safe=lambda *a:None)
  session=SimpleNamespace(check=lambda:None);executor=SimpleNamespace(_xhs_app_session=session)
  self.runtime=SimpleNamespace(closed=False,core=core,service=SimpleNamespace(state='online',closed=False,executor=executor,device={'id':'device'}),_principal=lambda u:f.store.get('users',u['id']),_executor=lambda *a,**k:executor,_device=lambda u:{'bound':True},_account=lambda u,aid:f.store.get('accounts',aid))
  def require_synthetic_server_lease(*a):
   if not self.send_lease:raise ValueError('synthetic server public send lease missing or expired')
  self.runtime.require_current_reviewed_send_lease=require_synthetic_server_lease
  self.runtime.reply_guard=lambda u,aid:core._public_reply_guard('xiaohongshu')
  self.runtime.start_reply_queue=lambda u,qid:core.reviewed_reply_queues.start(f.store.get('reply_queues',qid),{'authorized':True},u)
  self.delivery=ReplyDelivery(core,f.b.reply_workbench,self.runtime)
  original_context=f.b.reply_workbench._context
  def context(*args,**kwargs):
   actor,a,b,person=original_context(*args,**kwargs);return actor,a,b,{**person,'platform':'xiaohongshu'}
  f.b.reply_workbench._context=context
  self.addCleanup(core.reviewed_reply_queues.close)
  root=Path(f.tmp.name);(root/'fake.exe').write_bytes(b'inert fixture');(root/'worker.py').write_bytes(b'fake source')
  manifest={'version':1,'protocol':'reviewed-reply-v1','helperFlag':'--owned-xhs-reviewed-reply','executable':'fake.exe','executableSha256':file_digest(root/'fake.exe'),'sources':{'worker.py':file_digest(root/'worker.py')}}
  register(core,root,manifest,self.transport,expected_manifest_digest=digest(manifest))
  f.generate();f.confirm()
 def transport(self,decision,r,authorize):
  gate=ExactWireGate(r,authorize);outer=self
  class Client:
   def get_self_info(self):gate('GET','https://edith.xiaohongshu.com/api/sns/web/v2/user/me',{});outer.wires.append(('GET',outer.actual));return {'user_id':outer.actual}
   def reply_comment(self,*a):
    if outer.before_post:outer.before_post()
    gate('POST','https://edith.xiaohongshu.com/api/sns/web/v1/comment/post',{'content':json.dumps(post_body(r))});outer.wires.append(('POST',a))
    if outer.timeout:raise TimeoutError('synthetic only')
    return {'comment':{'id':'synthetic_receipt'}}
  return run_once(Client(),r,authorize,gate)
 def prepare(self,request='prep'):
  f=self.f;draft=f.store.list('replies','t')[0]
  return self.delivery.execute('reply_delivery_prepare',f.user,'s',{'storeId':'s','platform':'xiaohongshu','requestId':request,'items':[{'customerId':'c','leadId':'l','sourceDigest':digest(f.lead),'replyId':draft['id'],'version':draft['version'],'accountId':'B'}]},lambda:(f.user,{'store_id':'s'}))
 def start(self,p):
  f=self.f;result=self.delivery.execute('reply_delivery_start',f.user,'s',{'storeId':'s','platform':'xiaohongshu','id':p['id'],'snapshotDigest':p['snapshotDigest'],'confirmed':True,'requestId':'start'},lambda:(f.user,{'store_id':'s'}))
  for _ in range(300):
   queue=f.store.get('reply_queues',self.delivery._plan(f.user,'s',p['id'])['queueId'])
   if queue['status'] not in ('awaiting_collection','running'):break
   time.sleep(.01)
  return self.delivery.status(f.user,'s',self.delivery._plan(f.user,'s',p['id']))
 def test_original_confirmed_B_queue_sends_exactly_one_with_three_holds(self):
  p=self.prepare();self.assertEqual(p['items'][0]['identityState'],'verify_before_send');self.assertEqual(p['items'][0]['accountUid'],'uidB')
  result=self.start(p);self.assertEqual(result['state'],'completed',result);self.assertEqual([x[0] for x in self.wires],['GET','POST']);self.assertEqual(result['items'][0]['actualUid'],'uidB');self.assertIsNone(result['items'][0]['responseSenderUid'])
  self.assertEqual(self.core.deployment_config['runtime'],{'portable_employee_release':True,'public_send_hold':True,'xiaohongshu_automation':'hold'})
  self.assertIsNone(current_decision(self.core));self.assertEqual(len(self.f.store.list('accounts','t')),6)
 def test_wrong_session_zero_post(self):
  self.actual='uidA';result=self.start(self.prepare());self.assertEqual([x[0] for x in self.wires],['GET']);self.assertEqual(result['items'][0]['status'],'approved')
 def test_timeout_unknown_and_new_request_cannot_resend_customer(self):
  self.timeout=True;result=self.start(self.prepare());self.assertEqual(result['items'][0]['status'],'unknown');self.assertEqual([x[0] for x in self.wires],['GET','POST'])
  with self.assertRaises(ValueError):self.prepare('new')
 def test_route_change_before_post_zero_post(self):
  self.before_post=lambda:self.f.save_profile('B');result=self.start(self.prepare());self.assertEqual([x[0] for x in self.wires],['GET']);self.assertEqual(result['items'][0]['status'],'approved')
 def test_remote_hold_zero_wire(self):
  p=self.prepare();self.core.remote_safety_hold=True;result=self.start(p);self.assertEqual(self.wires,[]);self.assertEqual(result['state'],'blocked')
 def test_remote_read_only_release_does_not_grant_send(self):
  p=self.prepare();self.send_lease=False;old=[];original=self.runtime.start_reply_queue
  self.runtime.start_reply_queue=lambda *a:(old.append('old'),original(*a))[1]
  result=self.start(p);self.assertEqual(self.wires,[]);self.assertEqual(result['state'],'blocked');self.assertEqual(old,[])
 def test_no_registration_keeps_original_path_and_local_holds(self):
  del self.core._reviewed_reply_registration;p=self.prepare();old=[];original=self.runtime.start_reply_queue
  self.runtime.start_reply_queue=lambda *a:(old.append('old'),original(*a))[1]
  result=self.start(p);self.assertEqual(self.wires,[]);self.assertEqual(result['state'],'blocked');self.assertEqual(old,['old'])
 def test_existing_tampered_registration_never_falls_back(self):
  (self.core._reviewed_reply_registration.root/'worker.py').write_bytes(b'tampered');old=[]
  self.runtime.start_reply_queue=lambda *a:old.append('old')
  result=self.start(self.prepare());self.assertEqual(result['state'],'blocked');self.assertEqual(self.wires,[]);self.assertEqual(old,[])
 def test_remote_send_lease_expires_after_identity_zero_post(self):
  self.before_post=lambda:setattr(self,'send_lease',False)
  result=self.start(self.prepare());self.assertEqual([x[0] for x in self.wires],['GET']);self.assertEqual(result['items'][0]['status'],'approved')
 def test_QA_mode_zero_wire(self):
  p=self.prepare();self.core.deployment_config['runtime']['platform_qa_device_id']='qa';result=self.start(p);self.assertEqual(self.wires,[]);self.assertEqual(result['state'],'blocked')
 def test_expired_decision_zero_wire(self):
  original=self.runtime.start_reply_queue
  def expire(*a):
   current_decision(self.core).deadline=time.monotonic()-1
   return original(*a)
  self.runtime.start_reply_queue=expire
  result=self.start(self.prepare());self.assertEqual(self.wires,[]);self.assertEqual(result['state'],'blocked')
 def test_same_process_identity_change_after_GET_zero_POST(self):
  def mutate():
   account=self.f.store.get('accounts','B');account['platform_uid']='uidOther';self.f.store.put('accounts',account)
  self.before_post=mutate;result=self.start(self.prepare());self.assertEqual([x[0] for x in self.wires],['GET']);self.assertEqual(result['items'][0]['status'],'approved')
 def test_permission_epoch_change_with_send_permission_still_true_zero_POST(self):
  def update():
   user=self.f.store.get('users','u');user['permission_revision']='b'*64;user['can_reply']=True;self.f.store.put('users',user)
  self.before_post=update;result=self.start(self.prepare());self.assertEqual([x[0] for x in self.wires],['GET']);self.assertEqual(result['items'][0]['status'],'approved')
 def test_same_permission_epoch_refresh_still_sends_once(self):
  self.before_post=lambda:self.f.store.put('users',self.f.store.get('users','u'))
  result=self.start(self.prepare());self.assertEqual(result['state'],'completed');self.assertEqual([x[0] for x in self.wires],['GET','POST'])
 def real_runner_lease(self):
  deps=T.parent/'commercial-integration-20261022/source-v66-cli/component/build-work/site'
  if deps.is_dir():sys.path.insert(0,str(deps))
  spec=importlib.util.spec_from_file_location('actual_lease_fixture',T/'tests/backend/test_reviewed_send_lease.py');lm=importlib.util.module_from_spec(spec)
  previous_argv=sys.argv[:]
  try:
   sys.argv=[previous_argv[0],'--project',str(P),'--release',str(R),'--candidate',str(C),'--runtime',str(RT)]
   spec.loader.exec_module(lm)
  finally:sys.argv=previous_argv
  lf=lm.SendLeaseTests('test_only_exact_authenticated_poll_grant_mints_independent_lease');lf.setUp();self.addCleanup(lf.doCleanups)
  lf.server.core=self.core;lf.executor.core=self.core
  self.core.deployment_config=json.loads(json.dumps(lf.company))
  del lf.executor._xhs_app_session
  lm.bind_executor_session(lf.service,lf.executor,lf.saved)
  request=lm.request_for(lf.service,lf.executor,lf.saved);self.assertIsNotNone(request)
  lf.runner.reviewed_reply_request=request;lf.service._reviewed_reply_request=request;lf.service._reviewed_reply_runner=lf.runner
  lf.response['reviewed_reply_release']['material_sha256']=self.core._reviewed_reply_registration.manifest_digest
  self.runtime.service=lf.service;self.runtime._executor=lambda *a,**k:lf.executor
  self.runtime.require_current_reviewed_send_lease=lambda actor,account,device:lm.require_current(lf.server,actor,account,device)
  lf.runner.step();return lf
 def test_real_Runner_sealed_lease_and_original_queue_send_once(self):
  lf=self.real_runner_lease();result=self.start(self.prepare());self.assertEqual(result['state'],'completed',result);self.assertEqual([x[0] for x in self.wires],['GET','POST']);self.assertIsNotNone(lf.service._reviewed_reply_lease)
 def test_real_Runner_permission_epoch_renewed_true_stops_old_confirmed_batch(self):
  lf=self.real_runner_lease()
  def renewed():
   lf.response['owner_permissions']['permission_revision']='b'*64;lf.response['reviewed_reply_release']['permission_revision']='b'*64;lf.runner.step()
   self.assertIsNotNone(lf.service._reviewed_reply_lease)
  self.before_post=renewed;result=self.start(self.prepare());self.assertEqual([x[0] for x in self.wires],['GET']);self.assertEqual(result['items'][0]['status'],'approved')
 def test_real_Runner_lease_missing_at_mint_zero_wire(self):
  lf=self.real_runner_lease();lf.service._reviewed_reply_lease=None
  result=self.start(self.prepare());self.assertEqual(result['state'],'blocked');self.assertEqual(self.wires,[])
 def test_real_Runner_lease_expired_before_POST_zero_POST(self):
  lf=self.real_runner_lease();self.before_post=lambda:setattr(lf.service._reviewed_reply_lease,'deadline',time.monotonic()-1)
  result=self.start(self.prepare());self.assertEqual([x[0] for x in self.wires],['GET']);self.assertEqual(result['items'][0]['status'],'approved')
 def test_success_then_local_journal_failure_becomes_unknown(self):
  original=self.core._contact_record
  def persist(kind,*a,**k):
   if kind=='sent':raise OSError('synthetic persistence failure')
   return original(kind,*a,**k)
  self.core._contact_record=persist
  result=self.start(self.prepare());self.assertEqual([x[0] for x in self.wires],['GET','POST']);self.assertEqual(result['items'][0]['status'],'unknown')
  with self.assertRaises(ValueError):self.prepare('new-after-save-failure')
if __name__=='__main__':unittest.main(verbosity=2)
