"""Real two-file CAS against temporary workspaces; no production data or UI."""
from pathlib import Path
from unittest.mock import patch
import hashlib,importlib.util,json,shutil,sqlite3,tempfile,unittest

TASK=Path(__file__).resolve().parents[1]
ROOT=TASK.parents[1]
spec=importlib.util.spec_from_file_location('next_launch_update_test_target',TASK/'next_launch_update.py')
updater=importlib.util.module_from_spec(spec);spec.loader.exec_module(updater)
spec=importlib.util.spec_from_file_location('next_launch_readonly_guard',TASK/'closed_update_guard.py')
guard=importlib.util.module_from_spec(spec);spec.loader.exec_module(guard)
GENERIC=ROOT/'work/parallel-integration-20261018/integration/entry/install_canonical_delegation.py'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()

class Mutex:
    closed=[]
    def create(self,name):return 1,False
    def close(self,handle):self.closed.append(handle)
class BusyMutex(Mutex):
    def create(self,name):return 1,True

class UpdateTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(dir=TASK/'verification')
        self.addCleanup(self.temp.cleanup)
        self.root=Path(self.temp.name)/'client'
        self.task=self.root/'work/entry-repair'
        self.native=self.root/'work/ui-native-r57'
        self.project=self.task/'assembly/project'
        self.release=self.project/'work/ui-native-r57/releases/ui-r57-20000101T000000Z-11111111'
        self.release_id=self.release.name
        self.db=self.root/'data/workspace.sqlite3'
        def write(p,v):
            p.parent.mkdir(parents=True,exist_ok=True)
            p.write_text(json.dumps(v),'utf-8')
        self.write=write
        self.db.parent.mkdir(parents=True)
        with sqlite3.connect(self.db) as db:
            db.execute('CREATE TABLE records(entity TEXT,id TEXT,tenant_id TEXT,body TEXT)')
            db.execute('INSERT INTO records VALUES(?,?,?,?)',('tasks','old-task','test','{"read":65,"analyzed":1}'))
        db.close()
        write(self.root/'work/app/company.json',{'id':'test'})
        write(self.native/'state/production-workspace.json',{'data_dir':str(self.db.parent)})
        write(self.project/'work/ui-native-r57/state/production-workspace.json',{'data_dir':str(self.db.parent)})
        self.old_launcher=b'# old launcher\n'
        (self.native/'run_workbench.py').write_bytes(self.old_launcher)
        write(self.native/'FROZEN.json',{'release_id':'old-release'})
        self.old_frozen=(self.native/'FROZEN.json').read_bytes()
        write(self.native/'state/active.json',{'pid':1234,'release':'old-release'})
        self.active=(self.native/'state/active.json').read_bytes()
        write(self.release/'RELEASE.json',{})
        self.launcher=self.project/'work/ui-native-r57'/('run_candidate.'+self.release_id+'.py')
        body="RELEASE = ROOT / 'releases/"+self.release_id+"'\ndef run():\n        pinned(RELEASE / 'RELEASE.json', MANIFEST_SHA256)\n        return module.main(project_root=ROOT.parent.parent)\n"
        self.launcher.write_text(body,'utf-8')
        stage={'release_id':self.release_id,'release':str(self.release),'manifest_sha256':sha(self.release/'RELEASE.json').upper(),
               'launcher':str(self.launcher),'launcher_sha256':sha(self.launcher).upper()}
        write(self.task/'assembly/STAGED.json',stage)
        files=[{'path':p.relative_to(self.project).as_posix(),'sha256':sha(p),'bytes':p.stat().st_size}
               for p in self.project.rglob('*') if p.is_file()]
        write(self.task/'assembly/UNIFIED-PINS.json',{'files':files})
        self.baseline={'canonical':{n:sha(self.native/n) for n in ('run_workbench.py','FROZEN.json','state/production-workspace.json')}}
        write(self.task/'BASELINE.json',self.baseline)
        self.pins={'project':str(self.project),'release':str(self.release),'releaseId':self.release_id,
                   'manifestSha256':sha(self.release/'RELEASE.json'),'launcherPath':str(self.launcher),'launcherSha256':sha(self.launcher),
                   'stagedSha256':sha(self.task/'assembly/STAGED.json'),'unifiedPinsSha256':sha(self.task/'assembly/UNIFIED-PINS.json')}
        self.snapshot=guard.logical_snapshot(self.db)
        self.override=patch.multiple(updater,TASK=self.task,ROOT=self.root,NATIVE=self.native,GENERIC=GENERIC)
        self.override.start();self.addCleanup(self.override.stop)

    def untouched(self):
        self.assertEqual((self.native/'run_workbench.py').read_bytes(),self.old_launcher)
        self.assertEqual((self.native/'FROZEN.json').read_bytes(),self.old_frozen)
        self.assertEqual(guard.logical_snapshot(self.db),self.snapshot)
        self.assertEqual((self.native/'state/active.json').read_bytes(),self.active)

    def test_real_cas_changes_only_next_entry_and_preserves_running_instance(self):
        result=updater.install(guard,self.pins,Mutex)
        self.assertEqual(result['status'],'NEXT_LAUNCH_INSTALLED')
        self.assertEqual(result['currentRunningRelease'],'old-release')
        self.assertEqual(json.loads((self.native/'FROZEN.json').read_text('utf-8'))['release_id'],self.release_id)
        self.assertEqual((self.native/'state/active.json').read_bytes(),self.active)
        self.assertEqual(guard.logical_snapshot(self.db),self.snapshot)
        backup=self.task/'next-launch-transaction/canonical-entry-before'
        self.assertEqual((backup/'run_workbench.py').read_bytes(),self.old_launcher)
        self.assertEqual((backup/'FROZEN.json').read_bytes(),self.old_frozen)
        self.assertFalse(result['nativeWindowOpened']);self.assertFalse(result['realCollectionStarted'])

    def test_busy_updater_refuses_before_any_write(self):
        with self.assertRaises(RuntimeError):updater.install(guard,self.pins,BusyMutex)
        self.untouched();self.assertFalse((self.task/'next-launch-transaction').exists())

    def test_old_hash_change_refuses_before_any_write(self):
        (self.native/'run_workbench.py').write_bytes(b'# changed by another updater\n')
        with self.assertRaises(AssertionError):updater.install(guard,self.pins,Mutex)
        self.assertFalse((self.task/'next-launch-transaction').exists())
        self.assertEqual((self.native/'FROZEN.json').read_bytes(),self.old_frozen)

    def test_tampered_closure_refuses_before_any_write(self):
        self.launcher.write_bytes(b'# changed source\n')
        with self.assertRaises(AssertionError):updater.install(guard,self.pins,Mutex)
        self.untouched();self.assertFalse((self.task/'next-launch-transaction').exists())

    def test_second_file_failure_rolls_back_only_the_two_entry_files(self):
        real_loader=updater.module
        def load(name,path):
            item=real_loader(name,path)
            if name=='reviewed_next_launch_cas':
                real_replace=item.replace;calls=[]
                def replace(p,raw):
                    calls.append(p)
                    if len(calls)==2:raise OSError('synthetic second target write failure')
                    return real_replace(p,raw)
                item.replace=replace
            return item
        with patch.object(updater,'module',load):
            with self.assertRaises(OSError):updater.install(guard,self.pins,Mutex)
        self.untouched()
        journal=json.loads((self.task/'next-launch-transaction/CANONICAL-DELEGATION-INSTALL.json').read_text('utf-8'))
        self.assertEqual(journal['status'],'ROLLED_BACK')

    def test_approval_binds_the_exact_old_baseline(self):
        shutil.copyfile(TASK/'closed_update_guard.py',self.task/'closed_update_guard.py')
        self.write(self.task/'FROZEN-PINS.json',self.pins)
        self.write(self.task/'verification/integrated/RESULT.json',{'status':'PASS'})
        self.write(self.task/'independent/FINAL-SOURCE-REVIEW.json',{'fixture':True})
        self.write(self.task/'review/NEXT-LAUNCH-REVIEW.json',dict(
            approvedForNextLaunchUpdate=True,blockingFindings=[],updaterSha256=sha(Path(updater.__file__)),
            genericInstallerSha256=updater.GENERIC_SHA,guardReaderSha256=updater.GUARD_SHA,
            rootPinsSha256=sha(self.task/'FROZEN-PINS.json'),baselineSha256=sha(self.task/'BASELINE.json'),
            rootVerificationSha256=sha(self.task/'verification/integrated/RESULT.json'),
            sourceReviewSha256=sha(self.task/'independent/FINAL-SOURCE-REVIEW.json'),releaseId=self.release_id))
        updater.reviewed_inputs()
        altered=json.loads(json.dumps(self.baseline));altered['canonical']['run_workbench.py']='0'*64
        self.write(self.task/'BASELINE.json',altered)
        with self.assertRaises(AssertionError):updater.reviewed_inputs()
        self.untouched()

    def test_concurrent_external_instance_change_is_not_reported_as_clean(self):
        real_loader=updater.module
        def load(name,path):
            item=real_loader(name,path)
            if name=='reviewed_next_launch_cas':
                real_main=item.main
                def main():
                    real_main()
                    self.write(self.native/'state/active.json',{'pid':5678,'release':'external-user-start'})
                item.main=main
            return item
        with patch.object(updater,'module',load):result=updater.install(guard,self.pins,Mutex)
        self.assertEqual(result['status'],'NEXT_LAUNCH_INSTALLED_POSTCHECK_REVIEW_REQUIRED')
        self.assertFalse(result['currentInstanceUnchanged'])
        self.assertTrue(result['allBusinessDataUnchanged'])
        self.assertEqual(guard.logical_snapshot(self.db),self.snapshot)

if __name__=='__main__':unittest.main(verbosity=2)
