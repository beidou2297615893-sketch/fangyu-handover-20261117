# 代表链与复用证据

- 已读 READINESS 与两处 pinned 源码。复制的纯函数来自 upgrade-model.mjs SHA256 `4CAE160CFDF1E5F8D9B84B990B8A4D1199332123871D9EFADCEBB75791585E68`；原覆盖/input链来自 upgrade-shell.mjs SHA256 `33BC096FFFBECAC7195B8AF13FD4A87D6D142D921C8DC6AB67ADC5C38B3D157A`。原文件不改，三口吻与错误语义等价验证通过。
- 首条前端公开 render/bind 代表链在新增模块前 ERR_MODULE_NOT_FOUND；落地后，完整预览→覆盖确认前零写入→原 input/dirty→原 replySave 正文一致通过。运行元数据公开 transport 在方法前 runtimeStatus not a function，接原只读端点后通过。
- 只读审查指出设置 manual 请求乱序后，deferred 外部 transport 先真实复现“过期的旧回执”覆盖“较新的安全暂停回执”；补 actor/attempt/platformGeneration 后，旧成功、旧错误与不清新loading通过。无新轮询。
- 前端实际应用并送到原保存边界的文本单独保留 applied-template.json；新一条隔离 Core/SQLite 公开保存→正常重开→读取相同 draft 通过，没有复制权限/草稿/发送逻辑。
