'use strict';
// Reuses the established code-only CloudBase publication route. No config updates.
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const project=path.resolve(__dirname,'../..');
const task=path.join(project,'work/central-store-config');
const {compare,digest}=require('../cloud/verify_live_function_tree.cjs');
const freezeHash='8B58728B155BB33D2A020A631B2C91B4698F0CF82C3D04538458A26D2A114AD2';
const ENV='fh6-d5ga45c0ddae7008c',FUNCTION='fangyu-workspace',COMPANY='fangyu-apartment-client';
const reportFile=path.join(__dirname,'CENTRAL-CODE-DEPLOYMENT-20261017.json');
const sha=v=>crypto.createHash('sha256').update(v).digest('hex').toUpperCase();
function local(){
 const bytes=fs.readFileSync(path.join(task,'cloud-freeze.json'));
 if(sha(bytes)!==freezeHash)throw Error('freeze_changed');
 const plan=JSON.parse(bytes);
 for(const row of plan.changed){
  if(sha(fs.readFileSync(path.join(plan.baseline,row.path)))!==row.baseline_sha256||sha(fs.readFileSync(path.join(plan.candidate,row.path)))!==row.candidate_sha256)throw Error('changed_file_mismatch');
 }
 for(const row of plan.new)if(sha(fs.readFileSync(path.join(plan.candidate,row.path)))!==row.sha256)throw Error('new_file_mismatch');
 for(const row of plan.tools)if(sha(fs.readFileSync(path.join(task,row.path)))!==row.sha256)throw Error('tool_mismatch');
 const difference=compare(plan.baseline,plan.candidate);
 const expectedPaths=[...plan.changed,...plan.new].map(r=>r.path).sort();
 if(difference.missing_count!==0||difference.changed_count!==plan.changed.length||difference.extra_count!==plan.new.length||JSON.stringify(difference.sample_mismatch.sort())!==JSON.stringify(expectedPaths))throw Error('unreviewed_tree_change');
 return {...plan,candidateTree:digest(plan.candidate),baselineTree:digest(plan.baseline)};
}
function environmentFingerprint(detail){
 if(detail?.FunctionName!==FUNCTION||detail.Runtime!=='Nodejs20.19'||detail.Handler!=='index.main'||!Array.isArray(detail.Environment?.Variables))throw Error('function_identity_changed');
 const variables={};
 for(const row of detail.Environment.Variables){
  if(typeof row.Key!=='string'||typeof row.Value!=='string'||Object.hasOwn(variables,row.Key))throw Error('environment_invalid');
  variables[row.Key]=row.Value;
 }
 if(variables.TCB_ENV!==ENV||variables.COMPANY_ID!==COMPANY)throw Error('environment_identity_changed');
 return sha(JSON.stringify(Object.entries(variables).sort(([a],[b])=>a.localeCompare(b))));
}
async function connect(){
 const {getCredentialWithoutCheck}=require('../cloud-tools/node_modules/@cloudbase/toolbox');
 const CloudBase=require('../cloud-tools/node_modules/@cloudbase/manager-node');
 const identity=await getCredentialWithoutCheck();
 if(!identity?.secretId||!identity?.secretKey)throw Error('deployment_identity_unavailable');
 return new CloudBase({secretId:identity.secretId,secretKey:identity.secretKey,token:identity.token,envId:ENV,region:'ap-shanghai'});
}
async function download(manager,label){
 const base=path.join(__dirname,'central-live-reviews');fs.mkdirSync(base,{recursive:true});
 const dest=fs.mkdtempSync(path.join(base,label+'-'));
 await manager.functions.downloadFunctionCode({envId:ENV,functionName:FUNCTION,destPath:dest});
 return dest;
}
function save(report,first=false){fs.writeFileSync(reportFile,JSON.stringify(report,null,2)+'\n',{flag:first?'wx':'w'});}
async function verify(manager,plan,report){
 const detail=await manager.functions.getFunctionDetail(FUNCTION);
 if(detail.Status!=='Active'||environmentFingerprint(detail)!==report.environment_sha256)throw Error('post_environment_mismatch');
 const directory=await download(manager,'after');
 const result=compare(plan.candidate,directory);
 if(!result.matching)throw Error('live_candidate_not_exact');
 if(environmentFingerprint(await manager.functions.getFunctionDetail(FUNCTION))!==report.environment_sha256)throw Error('post_environment_changed');
 Object.assign(report,{phase:'complete',completed:true,completed_at:new Date().toISOString(),after_code_review:directory,live_tree_sha256:result.downloaded_tree_sha256});
 save(report);return report;
}
async function main(){
 const arg=process.argv[2];
 if(process.argv.length!==3||!['--check-local','--apply','--verify'].includes(arg))throw Error('arguments_invalid');
 const plan=local();
 if(arg==='--check-local'){console.log(JSON.stringify({local_verified:true,changed:plan.changed.map(r=>r.path),added:plan.new.map(r=>r.path),candidate_tree_sha256:plan.candidateTree}));return;}
 const manager=await connect();
 if(arg==='--verify'){
  const report=JSON.parse(fs.readFileSync(reportFile));
  if(report.freeze_sha256!==freezeHash||report.candidate_tree_sha256!==plan.candidateTree)throw Error('report_mismatch');
  await verify(manager,plan,report);console.log(JSON.stringify({completed:true,code_only:true,environment_unchanged:true,reportFile}));return;
 }
 if(fs.existsSync(reportFile))throw Error('existing_deployment_report_inspect_before_any_retry');
 const detail=await manager.functions.getFunctionDetail(FUNCTION);
 if(detail.Status!=='Active')throw Error('function_not_active');
 const fingerprint=environmentFingerprint(detail),directory=await download(manager,'before');
 if(!compare(plan.baseline,directory).matching)throw Error('live_baseline_changed');
 if(environmentFingerprint(await manager.functions.getFunctionDetail(FUNCTION))!==fingerprint)throw Error('concurrent_environment_change');
 const report={environment:ENV,companyId:COMPANY,functionName:FUNCTION,freeze_sha256:freezeHash,
  baseline_tree_sha256:plan.baselineTree,candidate_tree_sha256:plan.candidateTree,environment_sha256:fingerprint,
  before_code_backup:directory,phase:'before_code_update',started_at:new Date().toISOString(),completed:false,
  config_changed:false,platform_requested:false,automatic_retry:false,automatic_rollback:false,
  rollback:{code_directory:directory,environment:'preserve current environment'}};
 save(report,true);
 try{
  const response=await manager.functions.updateFunctionCode({func:{name:FUNCTION,runtime:'Nodejs20.19',handler:'index.main',installDependency:false},functionRootPath:task,functionPath:plan.candidate,deployMode:'cos'});
  report.code_request_id=response?.RequestId||null;report.phase='code_update_returned_pending_verification';save(report);
  await verify(manager,plan,report);
  console.log(JSON.stringify({completed:true,code_only:true,environment_unchanged:true,reportFile}));
 }catch{report.stopped_at=new Date().toISOString();save(report);throw Error('publication_outcome_requires_readback');}
}
if(require.main===module)main().catch(()=>{console.error(JSON.stringify({stopped:true,reportFile,automaticRetry:false,automaticRollback:false}));process.exitCode=1;});
module.exports={local,environmentFingerprint};
