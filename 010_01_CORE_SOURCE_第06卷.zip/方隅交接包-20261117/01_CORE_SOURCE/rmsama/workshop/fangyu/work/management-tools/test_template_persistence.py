"""One cross-seam payload proof; no host, device, platform or real HTTP boot."""
from pathlib import Path
import json,sys,tempfile,unittest
from unittest.mock import patch
TASK=Path(__file__).resolve().parent
ROOT=TASK.parents[1]
sys.dont_write_bytecode=True
sys.path[:0]=[str(ROOT/'work/ui-native-r57'),str(ROOT/'work/ui-runtime-r55/src')]
from test_workbench_backend import CloudFixture
from customer_workbench import CustomerWorkbench
from workbench_backend import WorkbenchBackend

class TemplatePersistence(unittest.TestCase):
    def test_applied_public_frontend_payload_saves_and_restores_as_unsent_draft(self):
        payload=json.loads((TASK/'applied-template.json').read_text('utf-8'))
        self.assertEqual(payload['text'],'你好呀，我是方隅顾问 小王。看到你在找房，想先了解一下你更在意的区域、预算和入住时间，我们再一起看看适合的选择。')
        cloud=CloudFixture();cloud.user['can_reply']=True
        backends=[]
        with tempfile.TemporaryDirectory(dir=TASK) as directory,patch('integrations.request_json',side_effect=cloud):
            company={'id':'fangyu-apartment-client','edition':'customer','personalMode':False,'authMode':'managed',
                'managedWorkspace':{'environment_id':'fixture-env','endpoint':'https://example.invalid/workspace'}}
            def open_backend():
                backend=WorkbenchBackend(ROOT,data_dir=directory,company=company,customer_factory=CustomerWorkbench);backends.append(backend);return backend
            try:
                backend=open_backend();token=backend.dispatch('login',{'username':'fixture-employee','password':'[REDACTED:assigned_secret]','rememberUsername':False})['token']
                tenant=backend.core.session(token)['tenant_id']
                backend.core.store.put('leads',{'id':'template-comment','tenant_id':tenant,'cloud_owner':'fixture-employee',
                    'platform':'xiaohongshu','source_type':'comment','source_id':'template-comment','comment_id':'template-comment',
                    'author_id':'template-user','author':'模板持久验证客户','text':'希望周末看房',
                    'content_title':'隔离真实来源','note_url':'https://www.xiaohongshu.com/explore/123456789012345678901234'})
                customer=backend.dispatch('customers',{},token)['customers']['items'][0]['id']
                base={'storeId':'fixture-store-a','customerId':customer}
                initial=backend.dispatch('reply_read',base,token)['replyWorkspace']['comments'][0]
                saved=backend.dispatch('reply_save',{**base,'leadId':'template-comment','text':payload['text'],
                    'sourceDigest':initial['sourceDigest'],'expectedVersion':0,'expectedReplyId':'','requestId':'actual-template-payload'},token)['replyWorkspace']['comments'][0]['draft']
                self.assertEqual((saved['text'],saved['version'],saved['status']),(payload['text'],1,'draft'))
                backend.close();backend=open_backend()
                restored=backend.dispatch('reply_read',base,token)['replyWorkspace']['comments'][0]['draft']
                self.assertEqual(restored,saved)
                customer=backend.dispatch('customer_detail',{'id':customer},token)['customer']['item']
                self.assertEqual(customer['contactState'],'uncontacted');self.assertFalse(customer['replied'])
            finally:
                for backend in backends:backend.close()

if __name__=='__main__':
    result=unittest.TextTestRunner(verbosity=1).run(unittest.defaultTestLoader.loadTestsFromTestCase(TemplatePersistence))
    (TASK/'persistence-checks.json').write_text(json.dumps({'status':'PASS' if result.wasSuccessful() else 'FAIL','passed':result.testsRun,
        'scope':'Actual frontend applied save text consumed by public reply_save/read, real Core/SQLite and normal close/reopen; external enterprise HTTP fixture only, zero host/device/platform/real HTTP.'},ensure_ascii=False,indent=2),'utf-8')
    raise SystemExit(0 if result.wasSuccessful() else 1)
