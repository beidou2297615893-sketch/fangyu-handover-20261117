"""Frontend regressions and exact source hashes only; no business runtime boot."""
from pathlib import Path
import hashlib,importlib.util,json,subprocess
TASK=Path(__file__).resolve().parent
PROJECT=TASK.parents[1]

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest().upper()

def main():
 logs=TASK/'check-logs';logs.mkdir(exist_ok=True)
 frontend=[]
 for relative in ('work/reply-integration/check_reply_frontend.mjs','work/reply-delivery/check_delivery_frontend.mjs',
                  'work/customer-handoff/check_handoff_frontend.mjs','work/customer-handoff/check_modal_compat.mjs'):
  result=subprocess.run(['node',str(PROJECT/relative)],cwd=PROJECT,capture_output=True,text=True,encoding='utf-8',timeout=30)
  log=logs/(Path(relative).stem+'.log');log.write_text(result.stdout+result.stderr,'utf-8')
  row={'test':relative,'passed':result.returncode==0,'log':str(log)};frontend.append(row);print(json.dumps(row,ensure_ascii=False),flush=True)
 for report,name in (('frontend-checks.json','check_tools.mjs'),('manual-refresh-checks.json','check_manual_refresh.mjs')):
  data=json.loads((TASK/report).read_text('utf-8'))
  frontend.append({'test':'work/management-tools/'+name,'passed':data['status']=='PASS','checks':data['passed'],'existingEvidence':True,'reportSha256':sha(TASK/report)})
 web=PROJECT/'work/ui-approved-implementation/ui-preview';syntax=[]
 for name in ('app.mjs','backend.mjs','pages/reply-connected.mjs','pages/acquire.mjs','pages/management-tools.mjs','pages/reply-templates.mjs'):
  result=subprocess.run(['node','--check',str(web/name)],capture_output=True,text=True,encoding='utf-8',timeout=15)
  syntax.append({'file':name,'passed':result.returncode==0,'error':result.stderr})
 freeze_path=PROJECT/'work/ui-native-r57/freeze_ui.py';compile(freeze_path.read_text('utf-8'),str(freeze_path),'exec')
 spec=importlib.util.spec_from_file_location('handoff_tools_freeze_readonly',freeze_path);freeze=importlib.util.module_from_spec(spec);spec.loader.exec_module(freeze)
 collected={p.relative_to(web).as_posix() for p in freeze.collect_source_files(web)}
 dependency={'passed':{'pages/management-tools.mjs','pages/reply-templates.mjs'}.issubset(collected),'sourceFiles':len(collected),'newModulesIncluded':True}
 frozen=json.loads((PROJECT/'work/ui-native-r57/FROZEN.json').read_text('utf-8'));assert frozen['release_id']=='ui-r57-20261016T181855Z-1c05e28f'
 release=Path(frozen['release']);manifest=json.loads((release/'RELEASE.json').read_text('utf-8'));preserved=[]
 for item in manifest['files']:
  relative=item['path']
  if not relative.endswith('.py'):continue
  if '/' not in relative:source=PROJECT/'work/ui-native-r57'/relative
  elif relative.startswith('resources/platform-runtime/'):source=PROJECT/'work/shared-backend-integration'/relative.removeprefix('resources/platform-runtime/')
  else:continue
  preserved.append({'path':str(source),'unchanged':sha(source)==item['sha256'],'sha256':item['sha256']})
 pins=json.loads((release/'resources/backend-dependencies.json').read_text('utf-8'))
 selected={'core/engine.py','core/store.py','core/review_queue.py','core/contact_journal.py','core/adapters.py',
           'assistant/business.py','assistant/customer_list.py','assistant/acquisition_operations.py','integrations.py'}
 for item in pins['files']:
  if item['path'] in selected:
   source=PROJECT/'work/ui-runtime-r55/src'/item['path'];preserved.append({'path':str(source),'unchanged':sha(source)==item['sha256'],'sha256':item['sha256']})
 templates=[]
 for name,expected in [('upgrade-model.mjs','4CAE160CFDF1E5F8D9B84B990B8A4D1199332123871D9EFADCEBB75791585E68'),('upgrade-shell.mjs','33BC096FFFBECAC7195B8AF13FD4A87D6D142D921C8DC6AB67ADC5C38B3D157A')]:
  path=PROJECT/'work/ui-runtime-r55/src/web/workspace'/name;templates.append({'path':str(path),'sha256':expected,'unchanged':sha(path)==expected})
 visual_pins=json.loads((PROJECT/'work/auth-presets-integration/baseline/visual-pins.json').read_text('utf-8'))
 visual=[{'path':r['path'],'unchanged':sha(Path(r['path']))==r['sha256']} for r in visual_pins]
 report={'status':'PASS' if all(r['passed'] for r in frontend+syntax+[dependency]) and all(r['unchanged'] for r in preserved+templates+visual) else 'FAIL',
  'frontend':frontend,'mjsSyntax':syntax,'freezePythonSyntax':True,'freezeDependencyCollection':dependency,
  'preservedNonWebModules':preserved,'preservedTemplateSources':templates,'approvedVisualPins':visual,
  'scope':'Public frontend render/bind/backend with external DOM/transport fixtures and readonly hash checks. No backend/Core boot or new full backend regression; no real HTTP/cloud/platform/browser/native/send/AI/fee/stage/promote/package.'}
 persistence=json.loads((TASK/'persistence-checks.json').read_text('utf-8'))
 report['supplementaryPersistence']={'passed':persistence['status']=='PASS','checks':persistence['passed'],
  'command':'work/desktop-python/Scripts/python.exe -B -X utf8 work/management-tools/test_template_persistence.py',
  'reportSha256':sha(TASK/'persistence-checks.json'),'existingEvidence':True}
 if not report['supplementaryPersistence']['passed']:report['status']='FAIL'
 report['scope']='Public frontend render/bind/backend and external DOM/transport fixtures, readonly hashes, plus one actual frontend payload -> public reply_save/read -> normal Core/SQLite reopen proof with external enterprise HTTP fixture. No full backend rerun, host/device/platform/native/browser/live HTTP/send/AI/fee/stage/promote/package.'
 (TASK/'checks.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),'utf-8')
 print(json.dumps({'status':report['status'],'newFrontendChecks':14,'existingFrontendChecks':28,'nonWebModulesUnchanged':len(preserved),'visualFilesUnchanged':len(visual)},ensure_ascii=False),flush=True)
 return 0 if report['status']=='PASS' else 1

if __name__=='__main__':raise SystemExit(main())
