"""Fixed author handoff hashes only; never stage/promote or launch the app."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
TASK=Path(__file__).resolve().parent
PROJECT=TASK.parents[1]
PRODUCTS=[
 'work/ui-approved-implementation/ui-preview/app.mjs',
 'work/ui-approved-implementation/ui-preview/backend.mjs',
 'work/ui-approved-implementation/ui-preview/pages/reply-connected.mjs',
 'work/ui-approved-implementation/ui-preview/pages/acquire.mjs',
 'work/ui-approved-implementation/ui-preview/pages/management-tools.mjs',
 'work/ui-approved-implementation/ui-preview/pages/reply-templates.mjs',
 'work/ui-native-r57/freeze_ui.py',
]
def entry(relative):
 path=PROJECT/relative;raw=path.read_bytes()
 return {'path':str(path),'relativePath':relative,'size':len(raw),'sha256':hashlib.sha256(raw).hexdigest().upper()}

def main():
 checks=json.loads((TASK/'checks.json').read_text('utf-8'));assert checks['status']=='PASS'
 frozen=json.loads((PROJECT/'work/ui-native-r57/FROZEN.json').read_text('utf-8'))
 assert frozen['release_id']=='ui-r57-20261016T181855Z-1c05e28f' and frozen['files']==96
 preserved=checks['preservedNonWebModules']+checks['preservedTemplateSources']+checks['approvedVisualPins']
 assert all(row['unchanged'] for row in preserved)
 for row in checks['preservedNonWebModules']+checks['preservedTemplateSources']:
  assert hashlib.sha256(Path(row['path']).read_bytes()).hexdigest().upper()==row['sha256']
 files=[entry(path) for path in PRODUCTS]
 fingerprint=hashlib.sha256(json.dumps([{k:row[k] for k in ('relativePath','sha256')} for row in files],sort_keys=True,separators=(',',':')).encode()).hexdigest().upper()
 evidence=[entry(path) for path in (
  'work/management-tools/check_tools.mjs','work/management-tools/check_manual_refresh.mjs',
  'work/management-tools/test_template_persistence.py','work/management-tools/run_checks.py',
  'work/management-tools/checks.json','work/management-tools/frontend-checks.json',
  'work/management-tools/manual-refresh-checks.json','work/management-tools/persistence-checks.json',
  'work/management-tools/applied-template.json','work/management-tools/RED-GREEN.md',
  'work/management-tools/HANDOFF.md','outputs/管理入口与话术工具/本批交付.md')]
 report={'status':'FIXED_AUTHOR_STOPPED','fixedUtc':datetime.now(timezone.utc).isoformat(),
  'fixedCodeSha256':fingerprint,'baseRelease':frozen['release_id'],'baseManifestSha256':frozen['manifest_sha256'],
  'stageOrPromotePerformed':False,'nativeClientTouched':False,'liveCloudOrPlatformOperationPerformed':False,
  'files':files,'evidence':evidence,
  'verification':{'newFrontend':14,'existingFrontend':28,'realSQLitePayloadReopen':1,'mjsSyntax':6,
    'freezePythonSyntax':True,'newSourceCollection':'PASS','nonWebModulesUnchanged':21,'templateSourcesUnchanged':2,'visualFilesUnchanged':9},
  'sourceReuse':checks['preservedTemplateSources'],'preservedNonWebModules':checks['preservedNonWebModules'],
  'limitations':['CloudBase InsufficientBalance remains; real employee login and native/clipboard acceptance are pending.',
    'No live send, AI, platform, browser/native window, package, stage or promote was performed.',
    'Current actual c0 window unchanged; root goal remains unfinished.'],
  'rootNext':'Final candidate integrity/static HTTP, source/version checks and unified acceptance; reuse unchanged backend evidence.'}
 (TASK/'FIXED.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),'utf-8')
 print(json.dumps({'status':report['status'],'files':len(files),'fixedCodeSha256':fingerprint,'manifest':str(TASK/'FIXED.json')},ensure_ascii=False))

if __name__=='__main__':main()
