// Actual app refresh hook, real frontend transport, external HTTP/DOM fixtures.
// No app startup, polling timer, browser, cloud or platform operation.
import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
import vm from 'node:vm';
import {createBackend} from '../ui-approved-implementation/ui-preview/backend.mjs';
const source=await readFile(new URL('../ui-approved-implementation/ui-preview/app.mjs',import.meta.url),'utf8');
const start=source.indexOf('let platformTimer,'),end=source.indexOf("let customerScope=",start);assert.ok(start>=0&&end>start);
const waiting=[],backend=createBackend((url)=>new Promise((resolve,reject)=>waiting.push({url,resolve,reject})));
const state={connection:'connected',session:{user:{username:'alice',role:'operator'}},user:'alice',storeId:'store-a',page:'presets'};
const sandbox={state,backend,document:{visibilityState:'visible',activeElement:null},render:()=>{},setTimeout:()=>{throw Error('manual refresh must not start polling');},clearTimeout:()=>{}};
vm.createContext(sandbox);vm.runInContext(source.slice(start,end)+'\nglobalThis.refreshSettings=()=>refreshPlatform({manual:true});',sandbox);
const respond=(request,message)=>request.resolve({ok:true,json:async()=>({ok:true,platform:{actor:{username:'alice',storeId:'store-a'},device:{state:'held',message},platforms:[]}})});
const first=sandbox.refreshSettings(),second=sandbox.refreshSettings();assert.equal(waiting.length,2);respond(waiting[1],'较新的安全暂停回执');await second;respond(waiting[0],'过期的旧回执');await first;
assert.equal(state.platform.device.message,'较新的安全暂停回执');assert.equal(state.platformError,'');assert.equal(state.platformLoading,false);
const older=sandbox.refreshSettings(),newer=sandbox.refreshSettings();waiting[2].reject(new Error('older external failure'));await older;assert.equal(state.platformLoading,true);assert.equal(state.platformError,'');respond(waiting[3],'最后一次有效回执');await newer;assert.equal(state.platform.device.message,'最后一次有效回执');
assert.ok(waiting.every(r=>r.url==='/api/workbench/platform'));
console.log('PASS manual settings refresh ignores older snapshot/error and cannot clear a newer loading state');
await writeFile(new URL('./manual-refresh-checks.json',import.meta.url),JSON.stringify({status:'PASS',passed:1,checks:['Manual settings refresh ignores older snapshot/error and never clears newer loading state.'],scope:'Actual existing app hook + createBackend at external HTTP/DOM boundary; zero polling or live requests.'},null,2));
