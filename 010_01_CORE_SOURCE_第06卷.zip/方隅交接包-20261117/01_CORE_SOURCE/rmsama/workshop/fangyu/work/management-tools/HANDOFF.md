# 管理入口与话术工具固定交接

- 输入：canonical/FROZEN `ui-r57-20261016T181855Z-1c05e28f`，96 文件；当前 c0 窗口未操作。
- 7 产品文件见 FIXED.json：app/backend/reply-connected/acquire、两个新窄 MJS、freeze 元数据。未改后台业务/发送/平台模块，21 个非 web 模块、2 旧模板源、9 视觉文件保持哈希。
- 复用 pinned upgrade-model.mjs 的 replyTones/replyTemplate；原纯函数语义与 SHA 已比对。复用 upgrade-shell preview→explicit overwrite→input/dirty 方式，目标绑定 actor/store/customer/lead/source/version/generation/text/dirty，pending/locked 拒绝，旧弹窗不写新目标。
- 预览/复制可独立使用；缺目标让本人选；应用不自动保存/审核/发送。官方服务口吻不代表官方授权提示保留。
- 设置只读真实 bootstrap/platform 状态并调用已有刷新、账号、退出动作，无管理权限/地址/门店/AI/hold 编辑。手动刷新 actor+attempt+platformGeneration，旧回执不覆盖、不清新loading，无新轮询。
- 日期本机实时取值，聚焦/可见时更新；版本只读原 /__workbench_status，预览/未知明确标识。获客“查看客户清单”直接导航；“账号与团队”更名平台账号。
- 新前端14 + 单条真实 SQLite 保存/正常重开1 + 旧前端28 PASS；MJS6/Python freeze编译/收集 PASS。checks.json 与各子报告保留。跨缝读取 actual applied-template.json，由公开 reply_save/read 验证恢复draft，未发。
- read review 已结束无阻断；不是其他代码作者。未跑整套后台、未 stage/promote/打包/开真实后台、浏览器、设备、平台或云请求。
- 交付 outputs/管理入口与话术工具/本批交付.md。真实云欠费/真人原生验收仍待，完整成品 goal 未 complete。
- 作者在 FIXED.json 写出后明确停写，root 可接候选完整性/静态HTTP和版本核验。
