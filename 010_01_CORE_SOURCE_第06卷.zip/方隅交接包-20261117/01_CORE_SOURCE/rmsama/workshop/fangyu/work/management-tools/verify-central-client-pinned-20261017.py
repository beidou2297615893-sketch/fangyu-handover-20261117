"""Representative existing fixtures on the exact pinned 99-file candidate; no network/UI."""
import hashlib,importlib.util,json,sys,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parents[2]
ID='ui-r57-20261017T045320Z-4a673681'
release=ROOT/'work/ui-native-r57/releases'/ID
spec=importlib.util.spec_from_file_location('central_pinned_host',release/'ui_native_host.py')
host=importlib.util.module_from_spec(spec);sys.modules[spec.name]=host;spec.loader.exec_module(host)
sha=hashlib.sha256((release/'RELEASE.json').read_bytes()).hexdigest().upper()
assert sha=='6B014B711A1172325F9C3698D0B319E47A78BE5496741AD7FD922FA17BA826FA'
_,files=host.verify_release(release,sha)
runs=ROOT/'work/central-store-config/test-runs';runs.mkdir(exist_ok=True)
with tempfile.TemporaryDirectory(dir=runs) as folder, patch('socket.socket.connect',side_effect=AssertionError('network forbidden')):
    company={'id':'fangyu-apartment-client','edition':'customer','personalMode':False,'authMode':'managed',
        'managedWorkspace':{'environment_id':'central-fixture','endpoint':'https://example.invalid/workspace'}}
    backend=host.create_backend(release,files,project_root=ROOT,data_dir=folder,company=company)
    backend.close()
    spec=importlib.util.spec_from_file_location('central_client_existing_fixture',ROOT/'work/central-store-config/test_central_client.py')
    fixture=importlib.util.module_from_spec(spec);spec.loader.exec_module(fixture)
    def pinned_backend(project,data,company,**_ignored):
        result=host.create_backend(release,files,project_root=ROOT,data_dir=data,company=company)
        fixture.WorkbenchError=sys.modules['fangyu_workbench_backend'].WorkbenchError
        assert Path(sys.modules['integrations'].__file__).is_relative_to(release)
        return result
    fixture.WorkbenchBackend=pinned_backend
    names=['test_store_a_b_roundtrip_restores_only_each_stores_words_policy_and_local_preferences',
        'test_customers_and_drafts_cannot_cross_the_server_selected_store',
        'test_unavailable_server_keeps_login_and_does_not_offer_local_catalog_as_authority']
    result=unittest.TextTestRunner(verbosity=2).run(unittest.TestSuite(fixture.CentralClient(name) for name in names))
record={'candidate':ID,'manifest_sha256':sha,'testsRun':result.testsRun,'passed':result.wasSuccessful(),
    'pinnedBackendAndFactories':True,'networkCalls':0,'realData':False,'uiOpened':False}
(Path(__file__).parent/'CENTRAL-CLIENT-PINNED-20261017.json').write_text(json.dumps(record,indent=2),'utf-8')
print(json.dumps(record))
raise SystemExit(0 if result.wasSuccessful() else 1)
