'use strict';
// One bounded own-admin login/read/logout. No platform calls or credential output.
const fs=require('node:fs'),path=require('node:path'),{execFileSync}=require('node:child_process');
const project=path.resolve(__dirname,'../..'),cloud=path.join(project,'work/cloud');
const {build}=require('../central-store-config/catalog_build.cjs');
const {hash}=require('../central-store-config/cloud-candidate/store_config.cjs');
const ENV='fh6-d5ga45c0ddae7008c',COMPANY='fangyu-apartment-client';
const endpoint='https://fh6-d5ga45c0ddae7008c-1439321968.ap-shanghai.app.tcloudbase.com/fangyu-workspace';
const reportFile=path.join(__dirname,'CENTRAL-LIVE-VERIFIED-20261017.json');
const must=(value,code)=>{if(!value)throw Error(code);};
async function request(operation,token='',rest={}){
 const response=await fetch(endpoint,{method:'POST',headers:{'Content-Type':'application/json',...(token?{Authorization:'Bearer '+token}:{})},
  body:JSON.stringify({environment_id:ENV,operation,...rest}),signal:AbortSignal.timeout(30000),redirect:'error'});
 const data=await response.json();must(data.contract==='fangyu-workspace-v1'&&data.environment_id===ENV&&data.company_id===COMPANY,'response_identity');
 return {status:response.status,data};
}
function credential(){
 const python=path.join(project,'work/desktop-python/Scripts/python.exe');
 const cipher=fs.readFileSync(path.join(cloud,'private-backups/fangyu-admin-current-login.dpapi'));
 const bytes=execFileSync(python,[path.join(cloud,'dpapi_stream.py'),'decrypt'],{input:cipher,windowsHide:true,maxBuffer:65536});
 try{const record=JSON.parse(bytes.toString('utf8'));
  must(record.format==='fangyu-admin-current-login-v1'&&record.environment===ENV&&record.companyId===COMPANY&&record.username==='rmsama'&&record.cloudCommitConfirmed===true&&record.loginVerified===true,'credential_identity');return record;
 }finally{bytes.fill(0);}
}
async function main(){
 must(process.argv.length===3&&process.argv[2]==='--verify-own-admin','arguments');
 must(!fs.existsSync(reportFile),'existing_report_inspect_first');
 const compiled=build();let token='';
 const report={started_at:new Date().toISOString(),environment:ENV,companyId:COMPANY,completed:false,
  real_collection:false,paid_ai:false,real_send:false,operator_live_login:false,device_register_or_claim:false,credential_saved_plaintext:false};
 try{
  const anonymous=await request('store_config_read');must(anonymous.status===401,'anonymous_not_denied');
  const record=credential();
  const login=await request('login','',{username:record.username,password:record.password});record.password='';
  must(login.status===200&&login.data.user?.role==='admin','admin_login');token=login.data.token;
  const directory=await request('store_config_read',token);
  must(directory.status===200&&directory.data.read_only===true&&directory.data.mutation_committed===false&&directory.data.scope?.type==='company','directory_scope');
  must(directory.data.catalog_revision===compiled.manifest.active_revision&&directory.data.catalog_digest===compiled.manifest.catalog_digest,'directory_version');
  must(hash(directory.data.stores)===hash(compiled.manifest.stores)&&directory.data.stores.length===14,'directory_exact');
  const stores=[];
  for(const entry of directory.data.stores){
   const answer=await request('store_config_read',token,{store_id:entry.id});
   const expected=compiled.documents.find(row=>row.doc_type==='store_config_version'&&row.store_id===entry.id);
   must(answer.status===200&&answer.data.config_digest===entry.config_digest&&hash(answer.data.config)===hash(expected.config),'store_exact');
   must(answer.data.config.package.keywords.every(row=>!row.bindings||row.bindings.every(binding=>binding.materialKey===entry.materialKey)),'store_binding_projection');
   stores.push({id:entry.id,name:entry.name,materialKey:entry.materialKey,config_digest:entry.config_digest,priceVerified:entry.priceVerified,exact_config_matched:true});
  }
  const unknown=await request('store_config_read',token,{store_id:'fy_s_'+'0'.repeat(24)});must(unknown.status===403,'unknown_store_not_denied');
  const snapshot=await request('device_permission_snapshot',token);must(snapshot.status===401&&snapshot.data.schema==='device-permission-snapshot-v1','device_token_separation');
  Object.assign(report,{anonymous_denied:true,admin_login_verified:true,admin_role_preserved:true,directory_scope:'company',
   catalog_revision:compiled.manifest.active_revision,catalog_digest:compiled.manifest.catalog_digest,counts:compiled.manifest.counts,stores,
   unknown_store_denied:true,device_user_token_rejected:true,read_only_flags_verified:true,completed:true});
 }catch(error){report.failure_code=/^[a-z_]{1,80}$/.test(error.message)?error.message:'verification_failed';process.exitCode=1;}
 finally{
  if(token){try{const logout=await request('logout',token);report.test_logout_verified=logout.status===200;}catch{report.test_logout_verified=false;}}
  report.finished_at=new Date().toISOString();fs.writeFileSync(reportFile,JSON.stringify(report,null,2)+'\n',{flag:'wx'});
 }
 console.log(JSON.stringify({completed:report.completed,stores_verified:report.stores?.length||0,counts:report.counts,logout:report.test_logout_verified,failure_code:report.failure_code,reportFile}));
}
if(require.main===module)main().catch(()=>{console.error(JSON.stringify({stopped:true,reportFile,automaticRetry:false}));process.exitCode=1;});
