"""Exact running release, isolated local profile, own real cloud auth. No UI/platform."""
import importlib.util,json,sys,tempfile
from pathlib import Path
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parents[2]
release=ROOT/'work/ui-native-r57/releases/ui-r57-20261017T045320Z-4a673681'
spec=importlib.util.spec_from_file_location('live_trial_pinned_host',release/'ui_native_host.py')
host=importlib.util.module_from_spec(spec);sys.modules[spec.name]=host;spec.loader.exec_module(host)
_,files=host.verify_release(release,'6B014B711A1172325F9C3698D0B319E47A78BE5496741AD7FD922FA17BA826FA')
credential=json.loads(sys.stdin.buffer.read())
assert credential['username']=='rmsama' and credential['cloudCommitConfirmed'] and credential['loginVerified']
company={'id':'fangyu-apartment-client','edition':'customer','personalMode':False,'authMode':'managed',
    'managedWorkspace':{'environment_id':'fh6-d5ga45c0ddae7008c',
    'endpoint':'https://fh6-d5ga45c0ddae7008c-1439321968.ap-shanghai.app.tcloudbase.com/fangyu-workspace'}}
report={'release':release.name,'completed':False,'isolatedLocalProfile':True,'productionLocalProfileChanged':False,
    'platformPrepared':False,'realCollection':False,'paidAi':False,'realSend':False}
runs=ROOT/'work/software-trial/live-checks';runs.mkdir(parents=True,exist_ok=True)
with tempfile.TemporaryDirectory(dir=runs) as folder:
    backend=host.create_backend(release,files,project_root=ROOT,data_dir=folder,company=company)
    token=''
    try:
        boot=backend.dispatch('login',{'username':credential['username'],'password':credential['password']})
        credential['password']='';token=boot['token']
        assert boot['session']['user']['role']=='admin' and len(boot['stores'])==14
        report['realLogin']=True;report['stores']=len(boot['stores'])
        selected=[]
        for store in boot['stores'][:2]:
            current=backend.dispatch('bootstrap',{},token)
            chosen=backend.dispatch('select_store',{'storeId':store['id'],'expectedRevision':current['selection']['revision']},token)
            assert chosen['selection']['storeId']==store['id']
            assert chosen['materials']['central']['storeId']==store['id']
            assert chosen['materials']['currentSelection']['currentBindingConfirmed']
            assert len(chosen['materials']['materials'])==1
            selected.append({'name':store['name'],'id':store['id'],'materialKey':chosen['materials']['currentSelection']['materialKey']})
        assert selected[0]['materialKey']!=selected[1]['materialKey']
        assert backend.platform_runtime.service.executor is None
        report.update(completed=True,selectedStores=selected,platformExecutorNotStarted=True)
    except Exception as error:
        report['errorType']=type(error).__name__;report['code']=getattr(error,'code','verification_failed')
    finally:
        credential['password']=''
        if token:
            try:report['testLogout']=backend.dispatch('logout',{},token).get('session') is None
            except Exception:report['testLogout']=False
        backend.close()
path=ROOT/'work/management-tools/TRIAL-BACKEND-LIVE-20261017.json'
path.write_text(json.dumps(report,ensure_ascii=False,indent=2),'utf-8')
print(json.dumps(report,ensure_ascii=False))
raise SystemExit(0 if report['completed'] else 1)
