import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
import vm from 'node:vm';
import {openToneTools,openSettings,localDates,versionLabel} from '../ui-approved-implementation/ui-preview/pages/management-tools.mjs';
import {replyTemplate,replyTones} from '../ui-approved-implementation/ui-preview/pages/reply-templates.mjs';
import * as preserved from '../ui-runtime-r55/src/web/workspace/upgrade-model.mjs';
import {render,bind} from '../ui-approved-implementation/ui-preview/pages/reply.mjs';
import * as acquire from '../ui-approved-implementation/ui-preview/pages/acquire.mjs';
import {createBackend} from '../ui-approved-implementation/ui-preview/backend.mjs';
const checks=[];const test=async(name,fn)=>{await fn();checks.push(name);console.log('PASS '+name);};
const tick=()=>new Promise(r=>setImmediate(r));
class Element{
 constructor(){this.value='';this.textContent='';this.disabled=false;this.readOnly=false;this.listeners={};this.open=true;this.__modalOwner={};}
 addEventListener(kind,fn){this.listeners[kind]=fn;}fire(kind='click'){return this.listeners[kind]?.({target:this});}dispatchEvent(event){return this.fire(event.type);}focus(){}select(){}close(){this.open=false;}querySelector(key){return this.fields?.get(key)||null;}
}
function setup(){
 const state={connection:'connected',session:{user:{username:'alice',role:'operator'}},page:'reply',user:'alice',storeId:'store-a',store:'store-a',stores:[{id:'store-a',name:'真实门店A'}],capabilities:{customers:true}};
 render(state);const source={id:'comment-a',text:'原评论<&>',sourceDigest:'a'.repeat(64),postTitle:'真实帖子',canSave:true,canReview:false,accounts:[],draft:null};
 Object.assign(state.replyLive,{status:'ready',selectedId:'customer-a',leadId:'comment-a',text:'原手写内容',dirty:true,generation:1,detail:{actor:{username:'alice',storeId:'store-a'},customerId:'customer-a',item:{name:'客户甲<&>'},comments:[source]}});
 const elements=new Map(['[data-live-draft]','[data-live-count]','[data-live-save]','[data-live-review]'].map(k=>[k,new Element()]));elements.get('[data-live-draft]').value='原手写内容';
 const dialog=new Element(),modals=[],writes=[],copies=[],nav=[];
 const ctx={state,update:fn=>fn(state),toast:()=>{},navigate:page=>nav.push(page),replyError:()=>{},replyEditor:()=>elements.get('[data-live-draft]'),hasUnconfirmed:()=>false,copyText:async text=>copies.push(text),
 modal:data=>{modals.push(data);dialog.open=true;dialog.__modalOwner={};dialog.fields=new Map(['[data-tone-identity]','[data-tone-choice]','[data-tone-preview]','[data-tone-apply]','[data-tone-copy]','[data-tone-target]','[data-tone-text]','[data-tone-feedback]',...['workspace','platform','version','accounts','logout'].map(k=>`[data-settings-${k}]`)].map(k=>[k,new Element()]));dialog.fields.get('[data-tone-choice]').value='friendly';return dialog;},
 replySave:async data=>{writes.push(data);return {replyWorkspace:{actor:{username:'alice',storeId:'store-a'},customerId:'customer-a',item:{name:'客户甲<&>'},comments:[{...source,draft:{id:'draft-a',version:1,status:'draft',text:data.text}}]}};}};
 bind({querySelector:k=>elements.get(k)||null,querySelectorAll:()=>[]},ctx);
 return {state,ctx,dialog,modals,elements,writes,copies,nav};
}
await test('preserved tone preview needs exact target and final consent before original dirty/save path',async()=>{
 const h=setup();openToneTools(h.ctx);h.dialog.querySelector('[data-tone-identity]').value='方隅顾问 小王';h.dialog.querySelector('[data-tone-choice]').value='friendly';h.dialog.querySelector('[data-tone-preview]').fire();
 const text=preserved.replyTemplate({tone:'friendly',identity:'方隅顾问 小王'});assert.equal(h.dialog.querySelector('[data-tone-text]').value,text);assert.match(h.modals[0].html,/不代表.*官方授权/);
 h.dialog.querySelector('[data-tone-apply]').fire();assert.equal(h.state.replyLive.text,'原手写内容');assert.match(h.modals.at(-1).html,/原评论&lt;&amp;&gt;/);assert.equal(h.writes.length,0);
 await h.modals.at(-1).onConfirm();assert.equal(h.state.replyLive.text,text);assert.equal(h.state.replyLive.dirty,true);assert.equal(h.writes.length,0);
 await h.elements.get('[data-live-save]').fire();assert.equal(h.writes.length,1);assert.equal(h.writes[0].text,text);assert.equal(h.state.replyLive.detail.comments[0].draft.status,'draft');assert.equal(h.state.replyLive.dirty,false);
 await writeFile(new URL('./applied-template.json',import.meta.url),JSON.stringify({text:h.writes[0].text,tone:'friendly',identity:'方隅顾问 小王',source:'Actual tone confirmation -> existing textarea input/dirty -> public replySave payload; owned DOM/transport fixture.'},null,2));
});
await test('runtime metadata reads only the existing local endpoint and validates actual release fields',async()=>{
 const calls=[],fetcher=async(url,options)=>{calls.push([url,options]);return {ok:true,status:200,json:async()=>({instanceId:'a'.repeat(32),profile:'production',mode:'stable',release:'ui-r57-20261016T181855Z-1c05e28f',token:'must-not-project'})};};
 const backend=createBackend(fetcher);const value=await backend.runtimeStatus();assert.equal(calls[0][0],'/__workbench_status');assert.equal(calls[0][1].method,'GET');assert.equal(calls[0][1].cache,'no-store');assert.equal(value.release,'ui-r57-20261016T181855Z-1c05e28f');assert.equal(value.token,undefined);
 const bad=createBackend(async()=>({ok:true,json:async()=>({mode:'stable',release:'v1.0'})}));await assert.rejects(bad.runtimeStatus(),error=>error.code==='runtime_metadata_invalid');
});
await test('all three copied templates and identity validation remain equivalent to the pinned functions',()=>{
 assert.deepEqual(replyTones,preserved.replyTones);
 for(const tone of Object.keys(replyTones))for(const identity of ['方隅顾问 小王','  本人真实身份  ','人'.repeat(80),'<&>'])assert.equal(replyTemplate({tone,identity}),preserved.replyTemplate({tone,identity}));
 for(const input of [{identity:''},{identity:'人'.repeat(81)},{identity:'两行\n身份'},{identity:'真实身份',tone:'invented'}]){let message;try{preserved.replyTemplate(input);}catch(e){message=e.message;}assert.throws(()=>replyTemplate(input),e=>e.message===message);}
});
await test('pending busy unknown sent and unavailable editors cannot be overwritten',async()=>{
 const variants=[h=>h.state.replyLive.pending={},h=>h.state.replyLive.busy=true,h=>h.state.replyLive.detailLoading=true,h=>h.state.busy=true,h=>h.ctx.hasUnconfirmed=()=>true,h=>h.state.replyLive.detail.comments[0].canSave=false,...['sending','unknown','sent','copied','superseded'].map(status=>h=>h.state.replyLive.detail.comments[0].draft={id:'locked',version:1,status}),h=>h.state.replyDelivery={attempt:{requestId:'unknown'}},h=>h.state.replyDelivery={plan:{state:'running',items:[{leadId:'comment-a',status:'approved'}]}}];
 for(const change of variants){const h=setup();change(h);openToneTools(h.ctx);h.dialog.querySelector('[data-tone-identity]').value='真实身份';h.dialog.querySelector('[data-tone-preview]').fire();h.dialog.querySelector('[data-tone-apply]').fire();assert.equal(h.modals.length,1);assert.equal(h.state.replyLive.text,'原手写内容');assert.equal(h.writes.length,0);}
 for(const key of ['disabled','readOnly']){const h=setup();openToneTools(h.ctx);h.dialog.querySelector('[data-tone-identity]').value='真实身份';h.dialog.querySelector('[data-tone-preview]').fire();h.dialog.querySelector('[data-tone-apply]').fire();h.elements.get('[data-live-draft]')[key]=true;assert.equal(await h.modals.at(-1).onConfirm(),false);assert.equal(h.state.replyLive.text,'原手写内容');}
});
await test('final consent is bound to the same employee store customer comment version and text',async()=>{
 for(const change of [h=>h.state.user='bob',h=>h.state.storeId='store-b',h=>h.state.replyLive.selectedId='customer-b',h=>h.state.replyLive.leadId='comment-b',h=>h.state.replyLive.generation++,h=>h.state.replyLive.text='另一窗口的新文字',h=>h.state.replyLive.detail.comments[0].sourceDigest='b'.repeat(64),h=>h.state.replyLive.detail.comments[0].draft={id:'new-draft',version:2,status:'draft'},h=>h.state.replyLive.pending={}]){
  const h=setup();openToneTools(h.ctx);h.dialog.querySelector('[data-tone-identity]').value='真实身份';h.dialog.querySelector('[data-tone-preview]').fire();h.dialog.querySelector('[data-tone-apply]').fire();const confirm=h.modals.at(-1).onConfirm;change(h);assert.equal(await confirm(),false);assert.equal(h.elements.get('[data-live-draft]').value,'原手写内容');assert.equal(h.writes.length,0);
 }
});
await test('preview and copy work independently while no target is guessed or applied',async()=>{
 const h=setup();h.state.page='presets';openToneTools(h.ctx);h.dialog.querySelector('[data-tone-identity]').value='本人真实身份';h.dialog.querySelector('[data-tone-preview]').fire();await h.dialog.querySelector('[data-tone-copy]').fire();assert.equal(h.copies[0],preserved.replyTemplate({identity:'本人真实身份'}));assert.equal(h.dialog.querySelector('[data-tone-apply]').disabled,true);h.dialog.querySelector('[data-tone-apply]').fire();assert.equal(h.modals.length,1);assert.equal(h.writes.length,0);h.dialog.querySelector('[data-tone-target]').fire();assert.deepEqual(h.nav,['reply']);
});
await test('editing identity or tone invalidates the old preview and never persists a preference',()=>{
 const h=setup();openToneTools(h.ctx);h.dialog.querySelector('[data-tone-identity]').value='真实身份';h.dialog.querySelector('[data-tone-preview]').fire();assert.ok(h.dialog.querySelector('[data-tone-text]').value);h.dialog.querySelector('[data-tone-identity]').fire('input');assert.equal(h.dialog.querySelector('[data-tone-text]').value,'');assert.equal(h.dialog.querySelector('[data-tone-apply]').disabled,true);h.dialog.querySelector('[data-tone-identity]').value='人'.repeat(81);h.dialog.querySelector('[data-tone-preview]').fire();assert.match(h.dialog.querySelector('[data-tone-feedback]').textContent,/80字/);assert.equal(h.writes.length,0);
});
await test('settings show only actual scoped status and delegate existing refresh accounts and logout actions',async()=>{
 const h=setup(),calls=[];h.state.runtimeMetadata={status:'ready',value:{release:'ui-r57-20261016T181855Z-1c05e28f',profile:'production',mode:'stable'}};
 h.state.platform={actor:{username:'alice',storeId:'store-a'},device:{state:'held',message:'企业安全暂停<&>'},platforms:[{id:'xiaohongshu',name:'小红书',enabled:true,status:'held',reasonCode:'qa_hold',message:'当前平台保持暂停<&>'}]};
 h.ctx.reloadWorkspace=async()=>{calls.push('bootstrap');return true;};h.ctx.refreshSettingsPlatform=async()=>{calls.push('platform');h.state.platformError='隔离刷新失败<&>';return null;};h.ctx.refreshRuntimeStatus=async()=>{calls.push('metadata');h.state.runtimeMetadata={status:'error',error:'版本回执未取得'};return false;};h.ctx.logout=async()=>{calls.push('logout');h.state.user='';h.state.storeId='';h.state.session=null;return true;};
 openSettings(h.ctx);let html=h.modals.at(-1).html;assert.match(html,/alice/);assert.match(html,/真实门店A/);assert.match(html,/企业安全暂停&lt;&amp;&gt;/);assert.match(html,/qa_hold/);assert.doesNotMatch(html,/<input|AI密钥|开关/);
 await h.dialog.querySelector('[data-settings-workspace]').fire();await h.dialog.querySelector('[data-settings-platform]').fire();html=h.modals.at(-1).html;assert.match(html,/隔离刷新失败&lt;&amp;&gt;/);assert.match(html,/上次已读取/);await h.dialog.querySelector('[data-settings-version]').fire();assert.match(h.modals.at(-1).html,/运行版本未核对/);h.dialog.querySelector('[data-settings-accounts]').fire();assert.deepEqual(h.nav,['accounts']);openSettings(h.ctx);const count=h.modals.length;await h.dialog.querySelector('[data-settings-logout]').fire();assert.equal(h.modals.length,count+1);assert.deepEqual(calls,['bootstrap','platform','metadata','logout']);
});
await test('foreign platform state and stale settings responses cannot cross an employee or newer modal',async()=>{
 const h=setup();h.state.platform={actor:{username:'bob',storeId:'other'},device:{message:'他人私有设备信息'}};let resolve;h.ctx.reloadWorkspace=()=>new Promise(r=>resolve=r);openSettings(h.ctx);assert.doesNotMatch(h.modals.at(-1).html,/他人私有设备信息/);const pending=h.dialog.querySelector('[data-settings-workspace]').fire();const count=h.modals.length;h.state.user='bob';h.dialog.__modalOwner={};resolve(true);await pending;assert.equal(h.modals.length,count);
});
await test('preview settings label missing real state and never invoke business refresh or logout',async()=>{
 const h=setup();h.state.connection='preview';const calls=[];for(const key of ['reloadWorkspace','refreshSettingsPlatform','refreshRuntimeStatus','logout'])h.ctx[key]=async()=>calls.push(key);openSettings(h.ctx);assert.match(h.modals.at(-1).html,/界面预览/);assert.doesNotMatch(h.modals.at(-1).html,/真实门店A|当前员工<\/dt><dd>alice/);for(const key of ['workspace','platform','version','logout'])await h.dialog.querySelector(`[data-settings-${key}]`).fire();assert.equal(calls.length,0);
});
await test('local date and actual runtime metadata replace fixed dates and v1.0 in the real shell/login renderer',async()=>{
 const fixture=localDates(new Date(2026,9,17,12));assert.equal(fixture.iso,'2026-10-17');assert.equal(fixture.long,'2026年10月17日　星期六');
 const h=setup();h.state.page='presets';h.state.runtimeMetadata={status:'ready',value:{profile:'production',mode:'stable',release:'ui-r57-20261016T181855Z-1c05e28f'}};
 const source=await readFile(new URL('../ui-approved-implementation/ui-preview/app.mjs',import.meta.url),'utf8'),start=source.indexOf('function navButton('),end=source.indexOf('function tools()',start);
 const sandbox={state:h.state,esc:v=>String(v??''),icon:()=>'',titles:{presets:['门店预设','真实配置']},localDates:()=>fixture,versionLabel,backend:{unconfirmed:false}};vm.createContext(sandbox);vm.runInContext(source.slice(start,end)+'\nglobalThis.shellHook=shell;globalThis.loginHook=login;',sandbox);
 const shell=sandbox.shellHook('');assert.match(shell,/2026年10月17日　星期六/);assert.match(shell,/平台账号/);assert.doesNotMatch(shell,/2026-10-16|账号与团队/);assert.match(sandbox.loginHook(),/稳定界面 · 1c05e28f/);assert.doesNotMatch(sandbox.loginHook(),/v1\.0/);h.state.connection='preview';assert.match(sandbox.loginHook(),/界面预览 · 无运行版本/);
});
await test('connected acquisition customer-list entry navigates to the existing real customer page',()=>{
 const button=new Element(),nav=[],state={connection:'connected',user:'alice',storeId:'store-a',session:{user:{username:'alice'}},stores:[],catalog:{search:[],intent:[]}};
 const cleanup=acquire.bind({querySelector:k=>k==='[data-acquire-customers]'?button:null,querySelectorAll:()=>[]},{state,actions:{},navigate:page=>nav.push(page),update:fn=>fn(state),modal:()=>{throw Error('old placeholder should not open');}});button.fire();assert.deepEqual(nav,['customers']);cleanup?.();
});
await test('read-only runtime metadata cannot clear or replay an unknown business mutation',async()=>{
 const calls=[],backend=createBackend(async(url,options)=>{calls.push(url);if(url==='/__workbench_status')return {ok:true,json:async()=>({profile:'production',mode:'stable',instanceId:'a'.repeat(32),release:'ui-r57-owned-12345678'})};throw new TypeError('owned response lost');});
 await assert.rejects(backend.deliveryStart({id:'batch',requestId:'request'}),error=>error.code==='RESULT_UNCONFIRMED');assert.equal(backend.unconfirmed,true);await backend.runtimeStatus();assert.equal(backend.unconfirmed,true);assert.deepEqual(calls,['/api/workbench','/__workbench_status']);
});
await writeFile(new URL('./frontend-checks.json',import.meta.url),JSON.stringify({status:'PASS',passed:checks.length,checks},null,2));
