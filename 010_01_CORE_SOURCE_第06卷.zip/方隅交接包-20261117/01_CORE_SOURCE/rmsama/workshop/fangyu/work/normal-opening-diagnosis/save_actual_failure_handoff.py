"""Root records new human opening failure; no source/app/guard actions."""
import datetime
import json
from pathlib import Path
import tomllib
import uuid

root = Path('C:/积木软件工坊/项目/方隅公寓客户版')
own = root/'work/normal-opening-diagnosis'
config = tomllib.loads(Path('C:/Users/rmsama/.codex/automations/automation-14/automation.toml').read_text(encoding='utf-8'))
assert config['status'] == 'ACTIVE'
assert config['rrule'] == 'FREQ=MINUTELY;INTERVAL=5'
assert config['target_thread_id'] == '01a13a0e-b66c-72a3-a82a-8ad950462a6b'
assert config['prompt'].startswith('2026-10-15最新真实人类反馈：')
receipt = {
    'schema': 'fangyu_automation_opening_failure_update_readback_v1',
    'updated_through_app_tool': True,
    'configuration_read_only': True,
    'id': config['id'], 'name': config['name'], 'status': config['status'],
    'rrule': config['rrule'], 'target_thread_id': config['target_thread_id'],
    'new_human_failure_prefix_verified': True,
    'original_goal_status_changed': False,
    'other_automations_changed': False,
}
with (own/'AUTOMATION-OPENING-FAILURE-UPDATE-READBACK.json').open('x', encoding='utf-8') as stream:
    stream.write(json.dumps(receipt, ensure_ascii=False, indent=2)+'\n')

prefix = '''# 2026-10-15 新真实打开故障：52保护空文件误拒，正在隔离修复

用户实际反馈「我打不开来啊」，并确认双击「完全没反应」。两个桌面lnk已只读核同一原启动入口；Root必要一次12个50–53 shared business收据/STARTED/FAILED路径快照缺席，四helper/entry/launcher固定pins匹配。只执行拒private/write/process/guard/PID的fixed public metadata隔离读，实际5ce5c8抛Source52 exact protection graph changed；d6c1c1确认manifest/prepared462保护列表完全相同，其中8合法零字节E3B0保护pins被52helper bytes>0误拒。ordinary launcher又吞异常，解释无提示早退。实际记录work/normal-opening-diagnosis/ACTUAL-OPENING-FAILURE.json。

这是新的真实代码缺口。所属author正在source52-empty-protection-candidate做仅保护空pin验证器及当前53launcher新H52绑定/固定失败提示；非作者必要窄审，新normal-opening-repair-native-candidate准备2 existing thin targets的独立原父备份/receipt事务。Root尚未签发/安装该修复、未调用任何原guard/PID/preflight/check-only/installer或App，不能冒称已可打开。原business源码/controls/native52/53 raw及原父backup保持，不倒填旧native receipts；54仍False/None、无Stage3。无强停/绕门/自动重apply/旧QA，0真实DBCookieVault/平台模型发送/打包部署付费。

该新故障优先于下方旧「无新缺口/等待」历史。52→53原薄安装历史保持，但本新打开失败尚未修复验证；GUI/正常启动与完整商业目标仍未验。automation ACTIVE原5分钟/本线程保持，goal历史blocked不伪造恢复或完成。

以下原记录保史。

'''
paths = [
    root/'work/product-upgrade-20261009/handoff/CURRENT.md',
    root/'memory/STATUS.md',
    root/'outputs/产品升级/当前执行事实.md',
    root/'work/source53-root-integration/NEXT.md',
    root/'work/product-upgrade-20261009/audits/source52-current.md',
    root/'work/product-upgrade-20261009/audits/source53-current.md',
]
backup = own/'document-backups'/uuid.uuid4().hex
backup.mkdir(parents=True)
for index, path in enumerate(paths):
    before = path.read_bytes()
    assert not before.startswith(prefix.encode('utf-8'))
    (backup/f'{index}-{path.name}').write_bytes(before)
    assert path.read_bytes() == before
    path.write_bytes(prefix.encode('utf-8')+before)
print(json.dumps({'documents': len(paths), 'backup': str(backup), 'source_actions': 0}, ensure_ascii=False))
