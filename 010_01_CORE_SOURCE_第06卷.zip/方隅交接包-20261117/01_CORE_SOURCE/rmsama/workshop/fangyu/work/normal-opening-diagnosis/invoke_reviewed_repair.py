"""Execute exactly the newly reviewed two-thin repair, never normal opening."""
import hashlib
from pathlib import Path
import stat

root = Path('C:/积木软件工坊/项目/方隅公寓客户版')
path = root/'work/normal-opening-repair-native-r1/install_normal_opening_repair.py'
current = root
for part in ('', *path.relative_to(root).parts):
    if part:
        current /= part
    item = current.lstat()
    assert not current.is_symlink() and not getattr(item, 'st_file_attributes', 0)&0x400
assert stat.S_ISREG(item.st_mode) and item.st_nlink == 1
raw = path.read_bytes()
assert len(raw) == 13613
assert hashlib.sha256(raw).hexdigest().upper() == 'D890238DB9A69D8CE1953C3B24AB54D9D85D81217794B72EBA3A58C9D05CC74A'
exec(compile(raw, str(path), 'exec'), {'__name__':'__main__','__file__':str(path)})
