"""Root-only exclusive local publication. Does not run an installer or App."""
import ast
import hashlib
import json
import re
import stat
from pathlib import Path

ROOT = Path('C:/积木软件工坊/项目/方隅公寓客户版')
OWN = ROOT/'work/normal-opening-diagnosis'
PAYLOAD = ROOT/'work/source52-empty-protection-candidate/revision2'
PAYLOAD_FREEZE = {'bytes':3416,'sha256':'9F04435C46D947198370F79675FD991C70A9BF4FD10D51BF03D4A1AF56FDFD95'}
NATIVE = ROOT/'work/normal-opening-repair-native-candidate/revision2'
NATIVE_FREEZE = {'bytes':2580,'sha256':'ABAB7EFD931B7FBA598D4FF057E49A82E1633037EB4D1716998A5F8327B366C5'}
REVIEW_FILES = (
    (ROOT/'work/source53-collection-ui-review/SOURCE52-EMPTY-PROTECTION-PAYLOAD-REVIEW.md',
     {'bytes':3090,'sha256':'B2CDB2239C90CCC217A46026BDFB0FD995B19CDADE1F180937B1F1D1CA6EE44E'}),
    (ROOT/'work/source53-collection-ui-review/NORMAL-OPENING-REPAIR-NATIVE-REVIEW.md',
     {'bytes':3244,'sha256':'26D261FE6E1721DE225F0D802E09D131B7968A97C40843342CB8813EB3FD4C10'}),
)

def pin(raw):
    return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest().upper()}

def expected(path, proof):
    assert path.is_relative_to(ROOT)
    current = ROOT
    for part in ('', *path.relative_to(ROOT).parts):
        if part:
            current /= part
        item = current.lstat()
        assert not current.is_symlink() and not getattr(item, 'st_file_attributes', 0)&0x400
        assert stat.S_ISREG(item.st_mode) and item.st_nlink == 1 if current == path else stat.S_ISDIR(item.st_mode)
    raw = path.read_bytes()
    assert pin(raw) == proof, str(path)
    return raw

def frozen(path, proof):
    value = json.loads(expected(path, proof))
    value['files'] = {str(Path(name) if Path(name).is_absolute() else path.parent/name): file_pin
                      for name, file_pin in value['files'].items()}
    for name, file_pin in value['files'].items():
        expected(Path(name), file_pin)
    return value

def json_raw(value):
    return (json.dumps(value, ensure_ascii=False, indent=2)+'\n').encode('utf-8')

def function_segments(raw):
    text = raw.decode('utf-8')
    return {node.name:ast.get_source_segment(text,node)
            for node in ast.parse(text).body if isinstance(node,ast.FunctionDef)}

def safe_parent(path):
    assert path.is_relative_to(ROOT/'work')
    current = ROOT
    for part in ('', *path.parent.relative_to(ROOT).parts):
        if part:
            current /= part
        if not current.exists():
            current.mkdir()
        item = current.lstat()
        assert stat.S_ISDIR(item.st_mode) and not current.is_symlink()
        assert not getattr(item, 'st_file_attributes', 0)&0x400

def main():
    assert NATIVE is not None and NATIVE_FREEZE is not None and REVIEW_FILES is not None
    payload_freeze = frozen(PAYLOAD/'FROZEN.json', PAYLOAD_FREEZE)
    native_freeze = frozen(NATIVE/'FROZEN.json', NATIVE_FREEZE)
    reviews = []
    for path, proof in REVIEW_FILES:
        expected(path, proof)
        reviews.append({'path':str(path),'pin':proof,'Root_full_read_accepted':True})
    plan_path = PAYLOAD/'PLAN.json'
    plan = json.loads(expected(plan_path,payload_freeze['files'][str(plan_path)]))
    assert len(plan['files']) == 2 and len(plan['native_targets']) == 2
    outputs = []
    for row in plan['files']:
        candidate = Path(row['candidate'])
        outputs.append((Path(row['target']),expected(candidate,row['pin'])))
    graph_path = NATIVE/'GRAPH.json'
    graph_raw = expected(graph_path,native_freeze['files'][str(graph_path)])
    graph = json.loads(graph_raw)
    assert graph['targets'] == [
        {'target':row['target'],'candidate':row['candidate_public'],
         'parent':row['parent'],'final':row['final']} for row in plan['native_targets']]
    gate_path = NATIVE/'NATIVE-ROOT-APPROVAL.json'
    gate = json.loads(expected(gate_path,native_freeze['files'][str(gate_path)]))
    assert gate['install_authorized'] is False
    assert gate['graph_pin'] == pin(graph_raw)
    gate.update(status='ROOT_APPROVED_NEW_THIN_REPAIR_ONLY',
                install_authorized=True,independent_native_review_passed=True,
                Root_review_evidence=reviews,full_product_complete=False,
                actual_App_or_GUI_acceptance=False)
    gate_raw = json_raw(gate)
    installer_path = NATIVE/'install_normal_opening_repair.py'
    before = expected(installer_path,native_freeze['files'][str(installer_path)])
    source = before.decode('utf-8')
    assert source.count('INSTALL_AUTHORIZED=False') == 1
    assert source.count('GATE_PIN=None') == 1
    source = source.replace('INSTALL_AUTHORIZED=False','INSTALL_AUTHORIZED=True')
    source = source.replace('GATE_PIN=None','GATE_PIN='+repr(pin(gate_raw)))
    after = source.encode('utf-8')
    assert function_segments(before) == function_segments(after)
    public_native = ROOT/'work/normal-opening-repair-native-r1'
    outputs += [(public_native/'GRAPH.json',graph_raw),
                (public_native/'NATIVE-ROOT-APPROVAL.json',gate_raw),
                (public_native/'install_normal_opening_repair.py',after)]
    assert len(outputs) == 5 and len({path for path,_ in outputs}) == 5
    assert all(path.is_relative_to(ROOT/'work') and not path.exists() for path,_ in outputs)
    receipt = {
        'schema':'fangyu_empty_protection_repair_Root_accepted_v1',
        'human_opening_failure_evidence':'ACTUAL-OPENING-FAILURE.json',
        'payload_freeze':{'path':str(PAYLOAD/'FROZEN.json'),'pin':PAYLOAD_FREEZE},
        'native_freeze':{'path':str(NATIVE/'FROZEN.json'),'pin':NATIVE_FREEZE},
        'reviews':reviews,'native_targets':plan['native_targets'],
        'installer_candidate_to_signed_delta':['INSTALL_AUTHORIZED','GATE_PIN'],
        'installer_functions_byte_identical':True,
        'review_notice_correction':'Reviewer withdrew its misread assertion that the first candidate claimed no update; revision2 is adopted as a neutral wording refinement.',
        'formal_business_writes':0,'original_App_calls':0,
        'Source54_Stage3_authorized':False,'native_install_authorized':True,
        'native_installed':False,'business_applied':False,'GUI_accepted':False,
        'commercial_complete':False,
        'publication_files':[{'path':str(path),'pin':pin(raw)} for path,raw in outputs],
    }
    with (OWN/'ROOT-REPAIR-ACCEPTED.json').open('xb') as stream:
        stream.write(json_raw(receipt))
    for path, raw in outputs:
        safe_parent(path)
        with path.open('xb') as stream:
            stream.write(raw)
        expected(path,pin(raw))
    receipt['exclusive_local_publication_completed'] = True
    with (OWN/'REPAIR-PUBLISHED.json').open('xb') as stream:
        stream.write(json_raw(receipt))
    print(json.dumps({'local_publication_files':5,'installer_pin':pin(after),
                      'installer':str(public_native/'install_normal_opening_repair.py'),
                      'App_calls':0,'business_apply_calls':0},ensure_ascii=False))

if __name__ == '__main__':
    main()
