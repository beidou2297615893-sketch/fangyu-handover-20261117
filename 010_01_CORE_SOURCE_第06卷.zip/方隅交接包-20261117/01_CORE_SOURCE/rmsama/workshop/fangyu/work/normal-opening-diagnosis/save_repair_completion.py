"""Root accepts actual repair readback and saves precise handoff; no App calls."""
import hashlib
import json
from pathlib import Path
import tomllib
import uuid

root = Path('C:/积木软件工坊/项目/方隅公寓客户版')
own = root/'work/normal-opening-diagnosis'
review = root/'work/source53-collection-ui-review/NORMAL-OPENING-REPAIR-ACTUAL-NATIVE-READBACK.md'
raw = review.read_bytes()
assert len(raw) == 1438
assert hashlib.sha256(raw).hexdigest().upper() == '63EE53FBF5AD52A3EC35341FB1F1EB3EB15CB3BA37EEB3097BF32C0B323CFADE'
post = json.loads((own/'POST-REPAIR-ACTUAL-METADATA-READ.json').read_bytes())
assert post['state'] == 'metadata_passed' and post['blocked_actions'] == []
actual = root/'work/product-upgrade-20261009/audits/normal-opening-repair-native-installed.json'
native_raw = actual.read_bytes()
assert len(native_raw) == 4844
assert hashlib.sha256(native_raw).hexdigest().upper() == 'B46138E939ACBEB7F9FB622F0C590964A9CDA60AF34C6C29A43BF25624ACA6D7'
record = {
    'schema':'fangyu_root_actual_opening_repair_read_accepted_v1',
    'actual_installer_tool':'0bc593', 'actual_installer_exit_code':0,
    'native_receipt':{'path':str(actual),'bytes':4844,'sha256':'B46138E939ACBEB7F9FB622F0C590964A9CDA60AF34C6C29A43BF25624ACA6D7'},
    'independent_actual_readback_tool':'fa08e7',
    'Root_full_read_tool':'cf9f74',
    'independent_report':{'path':str(review),'bytes':1438,'sha256':'63EE53FBF5AD52A3EC35341FB1F1EB3EB15CB3BA37EEB3097BF32C0B323CFADE'},
    'actual_backup':'backups/normal-opening-repair-native/cdb7a1d64be541af8108c16352b06a1d',
    'current_helper52':{'bytes':16027,'sha256':'B4F6BE4903F7E25F7C25B11F1CEAB96779CC60D26F511C1511E8257D012072A4'},
    'current_launcher':{'bytes':5910,'sha256':'EC31A4C07FE485BF020B94287847EACEA03D50EE42AF8714AF1ACB32A36DF86E'},
    'original_native_raws_backfilled':False,
    'original_guard_controls_backups_and_other_helpers_preserved':True,
    'Root_fixed_public_metadata_verification_tool':'37add6',
    'Root_fixed_public_metadata_state':'metadata_passed',
    'original_App_control_calls':0,'normal_open_wrapper_calls':0,
    'business_apply_calls':0,'GUI_verified':False,'commercial_complete':False,
    'Source54_Stage3_authorized':False,
    'original54_false_frozen_preserved':True,
    'future54_native_consumer_must_recognize_new_repair_overlay':True,
    'reviewer_false_no_update_wording_P2_withdrawn':True,
    'automatic_retry_authorized':False,
}
with (own/'ROOT-REPAIR-ACTUAL-READ-ACCEPTED.json').open('x', encoding='utf-8') as stream:
    stream.write(json.dumps(record,ensure_ascii=False,indent=2)+'\n')

prefix = '''# 2026-10-15 真实启动故障已修复：两份原入口更新及独审读回完成

用户实际「打不开/完全没反应」的阻塞是52保护pin校验误拒8个合法空文件；原462保护集合/实际8文件均匹配，没有删保护或绕过检查。新H52仅保护列表接受严格0/E3B0 pin，9target/authority/guard原非空要求保持；launcher绑定新H52并补固定普通失败提示。原文案『本次未更新』P2是审者乱码误读，已ASCII实核撤回；中性提示r2合理采用，不冒已证额外代码P2。

Root891950/9ebc93全文接受payload/native两审；5ef7dd exclusive新5control签发，非作者11a8f4精确冷读，Root6964b5全文接受。唯一新repair实际0bc593 exit0，desktop H52=16027/B4F6BE49、launcher=5910/EC31A4C0。原raw normal-opening-repair-native-installed.json4844/B46138E9；实际backup cdb7a1d64be541af8108c16352b06a1d保存原H52 1C919E94与原53launcher994ED84B。原native52/53 raw613E43/644B8086与AA029/E813旧父备份保持，旧pins通过新ownbackup→新current闭合，绝不倒填旧收据。原50/51/53helpers/ENTRY、18pubr2、guard/业务源码/客户数据保持。

非作者fa08e7 actual新raw/2parentbackup/current/原native/旧父/new5+old18controls/保护/temp联合PASS，Rootcf9f74全文接受。必要一次实际fixed publicmetadata37add6已PASS，entrypinNone合法使用原ENTRY父fallback；0main/preflight/guard/PID/业务apply。接受事实work/normal-opening-diagnosis/ROOT-REPAIR-ACTUAL-READ-ACCEPTED.json；原实际RED5ce5c8与全部r1/r2冻结/审查/载体失败保史。

现在用户可再点原桌面「方隅工作台」正常打开；两个图标同一入口，Root没有替用户开App。此次Root真实installer仅窄five-thin/Python5 fresh占用门，未声称business/App空闲；Root0正常开wrapper/App控制、0真实DBCookieVault/平台模型发送/打包部署付费。实际GUI、打开后50–53 business raw/backup/current与完整商业目标仍未验，只新实际打开/成功/失败证据才必要相应联合读回；STARTED无success/FAILED保原号，无自动reapply/旧installer或guard/preflight/check-only/metadata轮询。

本次所有所属作者/审者已完成，不重派该修复/旧QA充进度。54仍False/None、无Stage3/签发/安装，原冻与此前有限审保历史；将来native消费绑定须明确认识本新repair overlay，不能假定旧H52/launcher仍在current，有真正新代码缺口才沿原模块隔离处理。automation ACTIVE原5分钟/本线程、goal历史blocked不伪造恢复/完成；无新信息安静，只有关键成果/失败/必需动作通知。

下方旧进行中与其它快照仅保史，精确事实以上段与新actual记录优先。

'''
paths = [root/'work/product-upgrade-20261009/handoff/CURRENT.md',
         root/'memory/STATUS.md',root/'outputs/产品升级/当前执行事实.md',
         root/'work/source53-root-integration/NEXT.md',
         root/'work/product-upgrade-20261009/audits/source52-current.md',
         root/'work/product-upgrade-20261009/audits/source53-current.md',
         root/'work/product-upgrade-20261009/audits/source54-current.md',
         root/'work/source54-root-integration/NEXT.md',
         root/'memory/sessions/2026-10-14-新聊天接续采集界面修复.md']
backup = own/'document-backups'/uuid.uuid4().hex
backup.mkdir(parents=True)
for index,path in enumerate(paths):
    before = path.read_bytes()
    (backup/f'{index}-{path.name}').write_bytes(before)
    assert path.read_bytes() == before
    path.write_bytes(prefix.encode('utf-8')+before)
config = tomllib.loads(Path('C:/Users/rmsama/.codex/automations/automation-14/automation.toml').read_text(encoding='utf-8'))
assert config['prompt'].startswith('2026-10-15最新真实完成：')
assert config['status'] == 'ACTIVE' and config['rrule'] == 'FREQ=MINUTELY;INTERVAL=5'
assert config['target_thread_id'] == '01a13a0e-b66c-72a3-a82a-8ad950462a6b'
with (own/'AUTOMATION-REPAIR-COMPLETION-READBACK.json').open('x',encoding='utf-8') as stream:
    stream.write(json.dumps({'updated_through_app_tool':True,'configuration_read_only':True,
        'status':config['status'],'rrule':config['rrule'],'target_thread_id':config['target_thread_id'],
        'actual_repair_completion_prefix_verified':True,'other_automations_changed':False,
        'goal_resumed_or_completed':False},ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'documents':len(paths),'backup':str(backup),'actual_repair_accepted':True,
                  'GUI_verified':False,'App_calls':0},ensure_ascii=False))
