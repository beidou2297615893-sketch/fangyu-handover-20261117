"""Human-triggered read of fixed public opening metadata; never main/preflight."""
import ast
import ctypes
from ctypes import wintypes
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import stat
import sys
import tempfile
import types
import uuid

ROOT = Path('C:/积木软件工坊/项目/方隅公寓客户版')
LAUNCHER = ROOT/'work/desktop-self-use-entry/source_next_open_launcher.py'
reads = []
blocked = []

def audit(event, args):
    if event == 'open':
        path, mode, flags = args
        if isinstance(path, (str, bytes, os.PathLike)):
            normalized = os.fsdecode(path).replace('\\', '/').lower()
            root = str(ROOT).replace('\\', '/').lower()
            if normalized.startswith(root):
                relative = normalized[len(root):]
                if ('/self-operating-pilot/' in relative or '/data/' in relative
                        or relative.endswith(('.sqlite3', '.sqlite', '.db'))
                        or '/cookies' in relative or '/vault/' in relative):
                    blocked.append(event)
                    raise RuntimeError('private read denied in metadata diagnosis')
                reads.append(relative)
            if flags & (os.O_WRONLY | os.O_RDWR | os.O_CREAT | os.O_TRUNC):
                blocked.append(event)
                raise RuntimeError('write denied in metadata diagnosis')
    if event in ('subprocess.Popen', 'os.system', 'os.exec', 'os.posix_spawn',
                 'os.remove', 'os.rename', 'os.mkdir', 'os.rmdir', 'os.chdir',
                 'ctypes.dlopen', 'ctypes.dlsym', 'socket.connect'):
        blocked.append(event)
        raise RuntimeError('active action denied in metadata diagnosis')

sys.addaudithook(audit)
tree = ast.parse(LAUNCHER.read_text(encoding='utf-8'), filename=str(LAUNCHER))
nodes = [node for node in tree.body
         if isinstance(node, (ast.Import, ast.ImportFrom, ast.Assign))
         or isinstance(node, ast.FunctionDef) and node.name == '_load']
namespace = {'__name__': 'fixed_open_metadata_diagnosis', '__file__': str(LAUNCHER)}
exec(compile(ast.Module(body=nodes, type_ignores=[]), str(LAUNCHER), 'exec'), namespace)
stage = 'fixed_loaders'
result = {'normal_main_called': False, 'preflight_called': False,
          'guard_or_pid_called': False, 'business_apply_called': False}
try:
    legacy = namespace['_load'](namespace['HELPER'], namespace['HELPER_PIN'], 'diagnosis_legacy')
    prior = namespace['_load'](namespace['SUCCESSOR'], namespace['SUCCESSOR_PIN'], 'diagnosis_prior')
    latest = namespace['_load'](namespace['LATEST'], namespace['LATEST_PIN'], 'diagnosis_latest')
    newest = namespace['_load'](namespace['NEWEST'], namespace['NEWEST_PIN'], 'diagnosis_newest')
    stage = 'fixed_public_metadata'
    entry_pin = newest.reviewed_entry_pin_if_joined(legacy, prior, latest)
    result.update(state='metadata_passed', entry_pin=entry_pin)
except Exception as error:
    result.update(state='metadata_rejected', stage=stage,
                  error_type=type(error).__name__, error=str(error))
result.update(public_reads=list(dict.fromkeys(reads)), blocked_actions=blocked)
print(json.dumps(result, ensure_ascii=False, indent=2))
