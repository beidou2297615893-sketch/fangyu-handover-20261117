// Static CSS/scope/serving verification; does not open or control a browser.
const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),crypto=require('node:crypto');
const here=__dirname,root=path.resolve(here,'../..');
const parserContext={};vm.createContext(parserContext);
vm.runInContext(fs.readFileSync(path.join(here,'tools/csstree.js'),'utf8'),parserContext);
const css=parserContext.csstree;
const source=path.join(root,'work/app/src/web/workspace'),mirror=path.join(root,'work/cloud/workspace/site');
const sha=p=>crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex');
const overlay=fs.readFileSync(path.join(here,'brand-overlay.css'),'utf8');
const before=fs.readFileSync(path.join(here,'before/site.css'));
const after=fs.readFileSync(path.join(source,'site.css'));
if(!after.equals(Buffer.concat([before,Buffer.from(overlay)])))throw Error('Not a pure appended overlay');
if(!after.equals(fs.readFileSync(path.join(mirror,'site.css'))))throw Error('Mirror mismatch');
const allowed=new Set(['background','background-color','background-image','border-color','border-top-color','border-right-color','border-bottom-color','border-left-color','color','box-shadow','filter','accent-color','outline-color']);
let declarations=0,rules=0;const syntax=[];
const ast=css.parse(overlay,{positions:true,onParseError:e=>syntax.push(e.message)});
css.walk(ast,{visit:'Declaration',enter(node){
 declarations++;if(!node.property.startsWith('--')&&!allowed.has(node.property))throw Error(`Layout/behavior property forbidden: ${node.property}`);
 if(!node.property.startsWith('--')){const match=css.lexer.matchProperty(node.property,node.value);if(match.error)syntax.push(match.error.message);}
}});
css.walk(ast,{visit:'Rule',enter(){rules++;}});
if(syntax.length)throw Error(JSON.stringify(syntax));
const baseline=JSON.parse(fs.readFileSync(path.join(here,'before/source-hashes.json')));
const changes=[],verified=[];
for(const [relative,hash] of Object.entries(baseline)){
 if(relative.includes('/node_modules/'))continue;
 const current=sha(path.join(root,relative));
 if(current!==hash)changes.push(relative);else verified.push(relative);
}
const expected=['work/app/src/web/workspace/site.css','work/cloud/workspace/site/site.css'];
if(JSON.stringify(changes.sort())!==JSON.stringify(expected.sort()))throw Error(`Unexpected edits: ${changes}`);
const assets=JSON.parse(fs.readFileSync(path.join(here,'integrated-assets.json')));
const {serveSite}=require(path.join(root,'work/cloud/workspace/site.cjs'));
const served=[];
for(const a of assets){
 if(sha(path.join(source,'assets',a.asset))!==a.sha256||sha(path.join(mirror,'assets',a.asset))!==a.sha256)throw Error('Source asset modified');
 const r=serveSite({queryStringParameters:{asset:a.asset}});
 if(r.statusCode!==200||!r.isBase64Encoded||!Buffer.from(r.body,'base64').equals(fs.readFileSync(path.join(source,'assets',a.asset))))throw Error('Asset serving mismatch');
 served.push({asset:a.asset,status:r.statusCode,original_bytes:true});
}
function luminance(hex){const v=hex.match(/[0-9a-f]{2}/gi).map(x=>parseInt(x,16)/255).map(x=>x<=.04045?x/12.92:((x+.055)/1.055)**2.4);return .2126*v[0]+.7152*v[1]+.0722*v[2];}
const contrasts=[['primary','#212721','#fac828'],['primary hover','#212721','#ffe28a'],['metadata','#62686f','#faf9f5'],['source link','#17446b','#ffffff'],['selected keyword','#212721','#fff5d8'],['focus','#806017','#ffffff']].map(([name,fg,bg])=>{const a=luminance(fg),b=luminance(bg);return {name,ratio:Number(((Math.max(a,b)+.05)/(Math.min(a,b)+.05)).toFixed(2))};});
if(contrasts.some(x=>x.ratio<4.5))throw Error('Insufficient contrast');
const report={css_syntax_and_values:'passed',overlay_declarations:declarations,overlay_rules:rules,layout_and_behavior_properties_added:0,existing_unchanged_files:verified.length,existing_changed_files:changes,original_asset_serving:served,text_contrast:contrasts,dom_js_backend_unchanged:true,production_platform_requests:0,paid_ai_requests:0,visual_qa:'pending_actual_screenshot'};
fs.writeFileSync(path.join(here,'verification.json'),JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify(report));
