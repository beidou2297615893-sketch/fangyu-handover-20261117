"""Static design inventory; inspect supplied brand assets without executing app code."""
import json,re,collections
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
here=Path(__file__).resolve().parent
root=here/'unpacked'
config=json.loads((root/'app-config.json').read_text('utf-8'))
own_images=sorted((root/'public/imgs').glob('*'))
font=ImageFont.truetype('C:/Windows/Fonts/msyh.ttc',12)
sheet_images=[]
for item in own_images:
    if item.suffix.lower() not in ('.png','.gif','.jpg','.jpeg','.webp'):continue
    with Image.open(item) as image:
        sheet_images.append((item,image.convert('RGBA'),image.size))
for offset in range(0,len(sheet_images),36):
    part=sheet_images[offset:offset+36]
    canvas=Image.new('RGB',(900,((len(part)+5)//6)*155),'#f5f5f5')
    draw=ImageDraw.Draw(canvas)
    for i,(item,image,size) in enumerate(part):
        x=(i%6)*150;y=(i//6)*155
        draw.rectangle((x+4,y+3,x+146,y+121),fill='white')
        image.thumbnail((134,110))
        canvas.paste(image,(x+75-image.width//2,y+60-image.height//2),image)
        draw.text((x+6,y+124),item.stem[:20],font=font,fill='#252525')
        draw.text((x+6,y+140),f'{size[0]} x {size[1]}',font=font,fill='#666666')
    canvas.save(here/'design'/f'assets-{offset//36+1}.png')
styles=(root/'app-wxss.js').read_text('utf-8')
colors=collections.Counter(x.lower() for x in re.findall(r'#[0-9a-fA-F]{3,8}\b',styles))
bar=config.get('tabBar') or {}
report={'appid':'wx2be3bf5dd4b31b98','pages':len(config.get('pages',[])),
 'global_window':config.get('global',{}).get('window',{}),
 'navigation':{'color':bar.get('color'),'selectedColor':bar.get('selectedColor'),'backgroundColor':bar.get('backgroundColor')},
 'tab_labels':[{'text':x.get('text'),'pagePath':x.get('pagePath')} for x in bar.get('list',[])],
 'common_colors':colors.most_common(35),
 'public_images':[{'path':item.relative_to(root).as_posix(),'width':size[0],'height':size[1]} for item,image,size in sheet_images],
 'source_identifies_brand':bool(re.search('方隅',json.dumps(config,ensure_ascii=False))),
 'network_images_not_extracted':True,'executed_package_code':False}
(here/'design-inventory.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n','utf-8')
print(json.dumps({key:report[key] for key in ('pages','global_window','navigation','tab_labels','common_colors','source_identifies_brand')},ensure_ascii=False))
