"""Retrieve a local, integrity-checked open-source CSS parser for static QA only."""
from pathlib import Path
from urllib.request import urlopen
import base64, hashlib, json, tarfile, io
here=Path(__file__).resolve().parent/'tools'
with urlopen('https://registry.npmjs.org/css-tree/latest',timeout=20) as response:
    meta=json.load(response)
with urlopen(meta['dist']['tarball'],timeout=30) as response:
    blob=response.read(4000000)
assert 'sha512-'+base64.b64encode(hashlib.sha512(blob).digest()).decode()==meta['dist']['integrity']
with tarfile.open(fileobj=io.BytesIO(blob),mode='r:gz') as archive:
    for name in ('package/dist/csstree.js','package/LICENSE'):
        data=archive.extractfile(name).read()
        (here/('csstree.js' if name.endswith('.js') else 'css-tree-LICENSE')).write_bytes(data)
(here/'css-tree-metadata.json').write_text(json.dumps({k:meta[k] for k in ('name','version','license','dist')},indent=2)+'\n','utf-8')
print(json.dumps({'name':meta['name'],'version':meta['version'],'license':meta['license'],'registry_integrity_verified':True,'production_dependency_added':False}))
