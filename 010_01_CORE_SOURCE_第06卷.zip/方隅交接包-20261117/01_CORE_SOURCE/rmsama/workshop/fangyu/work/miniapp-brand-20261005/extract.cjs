// Offline adapter. Decrypt algorithm adapted from MIT-licensed seeWxapkg:
// https://github.com/Leslie-SSS/seeWxapkg/blob/main/backend/internal/pipeline/decrypt/decrypt.go
// Format decoder reused from MIT-package dzqdzq/dwxapkg (tools/dwxapkg-package.json).
// No JavaScript contained in a mini-program package is evaluated or executed.
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const Wxapkg=require('./tools/dwxapkg-index.js');
const file=path.join(__dirname,'source/wx2be3bf5dd4b31b98-v201.wxapkg');
const appid='wx2be3bf5dd4b31b98',output=path.join(__dirname,'unpacked');
if(fs.existsSync(output))throw Error('output_already_exists');
const raw=fs.readFileSync(file);let buf=raw;
if(raw.subarray(0,6).toString()==='V1MMWX'){
 const key=crypto.pbkdf2Sync(appid,'saltiest',1000,32,'sha1');
 const cipher=crypto.createDecipheriv('aes-256-cbc',key,Buffer.from('the iv: 16 bytes'));
 cipher.setAutoPadding(false);
 const header=Buffer.concat([cipher.update(raw.subarray(6,1030)),cipher.final()]).subarray(0,1023);
 const tail=Buffer.from(raw.subarray(1030)),xor=appid.charCodeAt(appid.length-2);
 for(let i=0;i<tail.length;i++)tail[i]^=xor;
 buf=Buffer.concat([header,tail]);
}
if(buf[0]!==0xbe||buf[13]!==0xed)throw Error('package_header_invalid');
const decoder=new Wxapkg(buf);
const log=console.log;let entries;
try{console.log=()=>{};entries=decoder._decode();}finally{console.log=log;}
if(entries.length>100000)throw Error('entry_count_invalid');
const names=new Set(),safe=[],originals=new Map();let duplicateEntries=0;
for(const item of entries){
 let name=Buffer.from(item.name,'latin1').toString('utf8').replace(/^\/+/,''),parts=name.split('/');
 if(!name||parts.some(p=>!p||p==='.'||p==='..')||/[\\:\x00-\x1f]/.test(name))throw Error('unsafe_package_path '+JSON.stringify(name).slice(0,220));
 const originalName=name;
 if(originals.has(name)){
  duplicateEntries++;
  const prior=originals.get(name);
  if(buf.subarray(item.offset,item.offset+item.size).equals(buf.subarray(prior.offset,prior.offset+prior.size)))continue;
  name='__variants__/'+duplicateEntries+'/'+name;
 }else originals.set(name,item);
 const dest=path.resolve(output,name);
 if(!dest.startsWith(output+path.sep)||item.offset<0||item.size<0||item.offset+item.size>buf.length)throw Error('invalid_package_bounds');
 names.add(name);safe.push({name,originalName,dest,offset:item.offset,size:item.size});
}
fs.mkdirSync(output);
const counts={},manifest=[];
for(const item of safe){
 fs.mkdirSync(path.dirname(item.dest),{recursive:true});
 const body=buf.subarray(item.offset,item.offset+item.size);fs.writeFileSync(item.dest,body);
 const ext=path.extname(item.name).toLowerCase();counts[ext]=(counts[ext]||0)+1;
 manifest.push({path:item.name,original_path:item.originalName,bytes:item.size,sha256:crypto.createHash('sha256').update(body).digest('hex')});
}
fs.writeFileSync(path.join(__dirname,'asset-manifest.json'),JSON.stringify({appid,version:201,
 source_sha256:crypto.createHash('sha256').update(raw).digest('hex'),entries:manifest.length,
 duplicate_entries:duplicateEntries,extensions:counts,files:manifest,executed_package_code:false,source_cache_modified:false},null,2)+'\n');
console.log(JSON.stringify({appid,entries:manifest.length,duplicate_entries:duplicateEntries,extensions:counts,executed_package_code:false}));
