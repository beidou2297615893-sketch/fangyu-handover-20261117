import base64,hashlib,json,tarfile
from pathlib import Path
here=Path(__file__).resolve().parent
metadata=json.loads((here/'acorn-package-metadata.json').read_text('utf-8-sig'))
algorithm,expected=metadata['dist']['integrity'].split('-',1)
actual=base64.b64encode(hashlib.new(algorithm,(here/'acorn.tgz').read_bytes()).digest()).decode()
if actual!=expected:raise ValueError('package_integrity_mismatch')
with tarfile.open(here/'acorn.tgz','r:gz') as archive:
    for member,output in [('package/dist/acorn.js','acorn.js'),('package/LICENSE','acorn-LICENSE')]:
        entry=archive.getmember(member)
        if not entry.isfile() or entry.size>1_000_000:raise ValueError('invalid_archive_member')
        (here/output).write_bytes(archive.extractfile(entry).read())
print(json.dumps({'parser_integrity_verified':True,'version':metadata['version']}))
