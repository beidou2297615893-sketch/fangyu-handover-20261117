"""Install only the reviewed visual overlay and original company PNGs."""
from pathlib import Path
import hashlib, json, shutil

here = Path(__file__).resolve().parent
root = here.parents[1]
source = root / 'work/app/src/web/workspace'
mirror = root / 'work/cloud/workspace/site'
backup = here / 'before'
if backup.exists():
    raise SystemExit('Baseline already captured; do not overwrite it')
backup.mkdir()
digest = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
frozen = {}
for tree in (root / 'work/app/src', root / 'work/cloud/workspace'):
    for p in tree.rglob('*'):
        if p.is_file() and '__pycache__' not in p.parts:
            frozen[p.relative_to(root).as_posix()] = digest(p)
(backup/'source-hashes.json').write_text(json.dumps(frozen,indent=2)+'\n','utf-8')
assert (source/'site.css').read_bytes() == (mirror/'site.css').read_bytes(), 'Source/mirror baseline mismatch'
shutil.copy2(source/'site.css',backup/'site.css')
overlay = (here/'brand-overlay.css').read_bytes()
assert b'End Fangyu mini-program brand v201.' in overlay
newcss = (source/'site.css').read_bytes() + overlay
for tree in (source,mirror):
    (tree/'site.css').write_bytes(newcss)
assets = {
    'logo4040.png':'fy-brand-logo-v201.png',
    'home.png':'fy-brand-home-v201.png',
    'home_selected.png':'fy-brand-home-selected-v201.png',
}
records=[]
for srcname,destname in assets.items():
    original=here/'unpacked/public/imgs'/srcname
    for tree in (source,mirror):
        target=tree/'assets'/destname
        if target.exists():
            raise SystemExit(f'New asset name is already in use: {destname}')
        shutil.copy2(original,target)
    records.append({'source':srcname,'asset':destname,'sha256':digest(original),'modified':False})
(here/'integrated-assets.json').write_text(json.dumps(records,ensure_ascii=False,indent=2)+'\n','utf-8')
out=root/'outputs/界面设计/11-方隅小程序品牌换肤-20261005.png'
shutil.copy2(Path('C:/Users/rmsama/.codex/generated_images/01a0d6f2-dc7b-7e10-b872-69cdbce27acc/exec-3a974706-4d6e-486d-aafc-9485ed7cff25.png'),out)
bundle=root/'outputs/方隅小程序设计素材'
bundle.mkdir(exist_ok=True)
shutil.copytree(here/'unpacked/public/imgs',bundle/'原版图片与图标',dirs_exist_ok=True)
shutil.copytree(here/'recovered-styles/pages',bundle/'页面样式静态还原',dirs_exist_ok=True)
print(json.dumps({'frozen_files':len(frozen),'css_sha256':digest(source/'site.css'),'assets':len(records),'original_public_images':len(list((bundle/'原版图片与图标').rglob('*'))),'design_target':str(out)},ensure_ascii=False))
