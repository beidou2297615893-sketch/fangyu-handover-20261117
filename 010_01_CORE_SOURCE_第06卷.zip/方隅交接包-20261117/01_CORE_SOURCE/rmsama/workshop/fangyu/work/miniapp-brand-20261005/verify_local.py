"""Read only the opened local app's health and public theme assets."""
from pathlib import Path
from urllib.request import urlopen
import json, hashlib, re
here=Path(__file__).resolve().parent
root=here.parents[1]
runtime=json.loads((root/'work/assistant/qa-cloud-pairing-pc1-20260926/running.json').read_text('utf-8'))
base=runtime['url']
assert re.fullmatch(r'http://127\.0\.0\.1:[0-9]{1,5}',base)
with urlopen(base+'/health',timeout=10) as response:
    health=json.load(response)
assets=['site.css','index.html','app.mjs','enterprise-ui.mjs','fy-brand-logo-v201.png','fy-brand-home-v201.png','fy-brand-home-selected-v201.png']
checks=[]
for name in assets:
    with urlopen(base+'/workspace?asset='+('' if name=='index.html' else name),timeout=12) as response:
        data=response.read(2000000)
        expected=(root/'work/app/src/web/workspace'/('assets/'+name if name.endswith('.png') else name)).read_bytes()
        if name=='index.html':
            expected=expected.replace(b'<section id="login-panel"',b'<section id="login-panel" hidden',1)
        checks.append({'asset':name,'status':response.status,'matches_source':data==expected,'sha256':hashlib.sha256(data).hexdigest(),'cache_control':response.headers.get('Cache-Control')})
assert all(c['status']==200 and c['matches_source'] for c in checks)
report={'pid':runtime['pid'],'url':base,'health':health,'assets':checks,'business_api_calls':0,'paid_ai_calls':0,'platform_calls':0,'actual_screenshot_captured':False}
(here/'local-runtime.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n','utf-8')
print(json.dumps({'pid':runtime['pid'],'url':base,'assets_match':len(checks),'health':health,'visual_qa':'not_performed'},ensure_ascii=False))
