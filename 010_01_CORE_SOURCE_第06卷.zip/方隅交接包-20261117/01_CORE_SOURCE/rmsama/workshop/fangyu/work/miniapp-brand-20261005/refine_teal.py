"""Apply user correction: teal, apartment imagery and single-line action labels."""
from pathlib import Path
import shutil,json,hashlib
here=Path(__file__).resolve().parent
root=here.parents[1]
phase=root/'work/teal-ui-refinement-20261005'
phase.mkdir(exist_ok=True)
source=root/'work/app/src/web/workspace'
mirror=root/'work/cloud/workspace/site'
before=phase/'before'
before.mkdir(exist_ok=True)
if not (before/'site.css').exists():
    shutil.copy2(source/'site.css',before/'site.css')
if not (before/'brand-overlay.css').exists():
    shutil.copy2(here/'brand-overlay.css',before/'brand-overlay.css')
old=(before/'brand-overlay.css').read_text('utf-8')
palette={
 '#212721':'#173a40','#343638':'#23474d','#fac828':'#176d79',
 '#ffe28a':'#115864','#fff5d8':'#e6f4f3','#e5e5df':'#d8e7e6',
 '#e5dfcd':'#d8e7e6','#62686f':'#526970','#faf9f5':'#eef6f5',
 '#f4f1e7':'#edf6f5','#ece5ce':'#d3e8e8','#b58408':'#176d79',
 '#806017':'#176d79','#655019':'#17616b','#d7d7cc':'#cbdddd',
 '#e2c96f':'#9bc6c9','#dfb13f':'#115864','#fffdf6':'#f6fbfb',
 '#f4f4f0':'#f1f6f6','#faf8f0':'#f3f9f8','#d1d3cc':'#bfd4d6',
 '#aaa99f':'#80a9ae','#e9e9e4':'#e2eeee','#eaeae5':'#e7f1f1',
 '#4c4b3d':'#315c63','#f2f2ee':'#edf4f4','#70540014':'#176d7914',
 '#5a3d1e':'#245762',
}
# Replace complete color tokens once, without cascading replacement of longer hex values.
import re
new=re.sub(r'#[0-9a-fA-F]{3,8}\b',lambda m:palette.get(m[0].lower(),m[0]),old)
new=new.replace('--fy-brand-gold-soft','--fy-brand-soft').replace('--fy-brand-gold','--fy-brand-accent')
new=new.replace('Fangyu mini-program brand, v201. Visual-only overlay: no layout or behavior changes.',
 'Fangyu visual refinement. User-selected teal; existing apartment photo and one-line actions.')
extra='''
/* Main actions use teal/white; disabled and safety states retain their own meaning. */
#page-tasks #suggest-keywords,#page-tasks #create-task,#page-tasks #continuous-toggle,#collection-dialog #collection-dialog-done,#page-leads #reply-confirm,#page-devices .platform-account-primary{color:#fff}
#page-tasks #suggest-keywords:hover:not(:disabled),#page-tasks #create-task:hover:not(:disabled),#page-tasks #continuous-toggle:hover:not(:disabled),#collection-dialog #collection-dialog-done:hover:not(:disabled),#page-leads #reply-confirm:hover:not(:disabled),#page-devices .platform-account-primary:hover:not(:disabled){color:#fff}
#page-tasks #suggest-keywords:disabled,#page-tasks #create-task:disabled,#page-tasks #continuous-toggle:disabled,#collection-dialog #collection-dialog-done:disabled,#page-leads #reply-confirm:disabled,#page-devices .platform-account-primary:disabled{color:#526970}
#page-devices .platform-account-steps .is-current .platform-account-step-number,#page-devices .platform-account-steps .is-done .platform-account-step-number{color:#fff}

/* Keep the established controls; allow adequate width instead of breaking action text. */
#workspace button:not(.work-comment):not(.discovery-comment):not(.discovery-person):not(.discovery-row):not(.platform-account-switch){white-space:nowrap;word-break:keep-all;overflow-wrap:normal}
#task .demand-row{grid-template-columns:minmax(0,1fr) max-content;align-items:center}
#page-tasks #suggest-keywords{min-width:190px;padding-inline:14px;gap:8px;flex-wrap:nowrap;line-height:1.2;font-size:16px}
#page-tasks #suggest-keywords::before{width:20px;height:20px}
#task .collection-summary{gap:12px;line-height:1.5}
#page-tasks #collection-adjust{min-width:126px}
#collection-dialog .collection-dialog-actions,#task-list-card .continuous-actions,#page-leads .queue-actions,#page-devices .platform-account-detail-actions{flex-wrap:wrap}
#collection-dialog .collection-dialog-actions button{flex-shrink:0}

/* Real existing apartment image: decorative only, never a fabricated post cover/avatar. */
#workspace .nav-main::after{content:"";display:block;height:156px;margin:22px 12px 0;border-radius:9px;background:#e6f4f3 url('?asset=fy-login-apartment-photo.webp') center/cover no-repeat;pointer-events:none}
#task .collection-brief{position:relative;isolation:isolate}
#task .collection-brief::before{content:"";position:absolute;top:0;right:0;bottom:0;width:42%;z-index:-1;background:url('?asset=fy-login-apartment-photo.webp') right center/cover no-repeat;opacity:.1;pointer-events:none}
@media(max-width:980px) and (min-width:651px){#workspace .nav-main::after{height:126px;margin-inline:6px}}
@media(max-width:650px){#workspace .nav-main::after{display:none}#task .demand-row{grid-template-columns:1fr}#page-tasks #suggest-keywords{width:100%;min-width:0}#task .collection-brief::before{width:60%}#collection-dialog .collection-dialog-actions{row-gap:10px}#collection-dialog #collection-dialog-done{min-width:166px;flex:1}}
'''
new=new.replace('/* End Fangyu mini-program brand v201. */',extra+'\n/* End Fangyu mini-program brand v201. */')
(here/'brand-overlay.css').write_bytes(new.encode('utf-8'))
(phase/'theme.css').write_bytes(new.encode('utf-8'))
content=(here/'before/site.css').read_bytes()+new.encode()
for tree in (source,mirror):
    (tree/'site.css').write_bytes(content)
shutil.copy2(Path('C:/Users/rmsama/.codex/generated_images/01a0d6f2-dc7b-7e10-b872-69cdbce27acc/exec-6c4f16fb-d620-4925-8361-baf1f4f8d08e.png'),root/'outputs/界面设计/12-蓝绿配色与房屋背景修订-20261005.png')
report={'theme':'teal','primary':'#176d79','primary_text':'#ffffff','canvas':'#eef6f5','new_network_image_requests':0,'photo':'existing fy-login-apartment-photo.webp','photo_source':'existing workbench asset; not claimed as miniprogram dynamic community image','html_js_backend_changes':0,'controls_added_or_removed':0,'main_button_min_width':190,'original_gold_backup':str(before),'css_sha256':hashlib.sha256(content).hexdigest()}
(phase/'implementation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n','utf-8')
print(json.dumps(report,ensure_ascii=False))
