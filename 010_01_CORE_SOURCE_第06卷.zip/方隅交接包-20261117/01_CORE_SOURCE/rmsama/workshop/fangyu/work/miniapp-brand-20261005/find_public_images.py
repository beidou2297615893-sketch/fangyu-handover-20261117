from pathlib import Path
import re,json
root=Path(__file__).resolve().parent/'unpacked'
urls=set()
for name in ('app-service.js','app-wxss.js'):
    text=(root/name).read_text('utf-8',errors='replace').replace('\\/','/')
    urls.update(re.findall(r'https?://[^\s\"\'<>]+',text))
images=sorted(u for u in urls if re.search(r'\.(png|jpe?g|webp)(\?|$)',u,re.I) and len(u)<280 and not re.search(r'token|secret|password|key=',u,re.I))
(root.parent/'public-image-urls.json').write_text(json.dumps(images,ensure_ascii=False,indent=2)+'\n','utf-8')
print('\n'.join(images[:30]))
