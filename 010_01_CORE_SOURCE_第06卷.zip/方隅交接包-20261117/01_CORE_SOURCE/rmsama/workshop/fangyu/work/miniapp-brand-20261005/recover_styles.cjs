// Static JSON-literal recovery of wxss arrays; never eval/VM package content.
const fs=require('node:fs'),path=require('node:path');
const acorn=require('./tools/acorn.js');
function staticValue(node){
 if(!node)return null;
 if(node.type==='Literal')return node.value;
 if(node.type==='ArrayExpression')return node.elements.map(staticValue);
 if(node.type==='UnaryExpression'&&node.operator==='-'&&node.argument.type==='Literal'&&typeof node.argument.value==='number')return -node.argument.value;
 throw Error('non_literal_expression '+node.type+' '+JSON.stringify(source.slice(node.start,node.end)).slice(0,100));
}
const root=__dirname,source=fs.readFileSync(path.join(root,'unpacked/app-wxss.js'),'utf8');
const destination=path.join(root,'recovered-styles');fs.mkdirSync(destination,{recursive:true});
const assignment=/__wxAppCode__\[['"]([^'"]+\.wxss)['"]\]\s*=\s*setCssToHead\(/g;
const result=[];let match;
while(match=assignment.exec(source)){
 const start=source.indexOf('[',assignment.lastIndex);
 let parts;try{let node=acorn.parseExpressionAt(source,start,{ecmaVersion:2020});if(node.type==='SequenceExpression')node=node.expressions[0];if(node.type!=='ArrayExpression')throw Error('style_argument_not_array');parts=staticValue(node);}catch(error){result.push({path:match[1],status:'non_static_literal',diagnostic:error.message.slice(0,180)});continue;}
 let imports=0;
 const css=parts.map(item=>typeof item==='string'?item:Array.isArray(item)&&item[0]===0?`${item[1]}rpx`:Array.isArray(item)&&item[0]===1?'':(imports++,`/* unresolved shared-style reference ${JSON.stringify(item)} */`)).join('');
 const target=path.resolve(destination,match[1]);if(!target.startsWith(destination+path.sep))throw Error('unsafe_style_path');
 fs.mkdirSync(path.dirname(target),{recursive:true});fs.writeFileSync(target,css);
 const colors={},colorMatches=css.match(/#[a-f\d]{3,8}\b/gi)||[];for(const color of colorMatches)colors[color.toLowerCase()]=(colors[color.toLowerCase()]||0)+1;
 result.push({path:match[1],status:imports?'partial_static':'static_literals_recovered',unresolved_imports:imports,bytes:Buffer.byteLength(css),colors});
}
fs.writeFileSync(path.join(root,'style-recovery.json'),JSON.stringify({executed_package_code:false,styles:result},null,2)+'\n');
console.log(JSON.stringify(result.filter(x=>/^pages\/(brand|store|login|index|found|discover|service)\//.test(x.path))));
