"""Prepare a TUF-signed Fangyu assistant feed; never publish private keys.

Private signing keys are encrypted with the current Windows user's DPAPI.
The first root is immutable here: rotating root keys needs a separate ceremony.
"""
import argparse
from datetime import datetime, timedelta, timezone
import json
import hashlib
import zipfile
from pathlib import Path
import sys

from cryptography.hazmat.primitives.serialization import load_pem_private_key
from securesystemslib.signer import CryptoSigner, SSlibKey
from tuf.api.metadata import Metadata, MetaFile, Root, Snapshot, TargetFile, Targets, Timestamp

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'app' / 'src'))
from integrations import protect
sys.path.insert(0,str(Path(__file__).resolve().parent))
from release_authorization import authorized_release_company

ROLES = ('root', 'targets', 'snapshot', 'timestamp')
ROOT = Path(__file__).resolve().parents[2]
RELEASE_BLOCK = ROOT / 'work' / 'packaging' / 'RELEASE_BLOCKED.txt'


def signers(private_dir, root_metadata=None):
    private_dir.mkdir(parents=True, exist_ok=True)
    if root_metadata is None:
        if any(private_dir.iterdir()):
            raise ValueError('签名目录已有内容，不能重新生成根密钥')
        keys = {role: CryptoSigner.generate_ed25519() for role in ROLES}
        for role, signer in keys.items():
            (private_dir / (role + '.dpapi')).write_bytes(protect(signer.private_bytes))
        return keys

    keys = {}
    for role in ROLES:
        keyids = root_metadata.signed.roles[role].keyids
        if len(keyids) != 1:
            raise ValueError('此发布工具只支持每个角色一把签名密钥')
        keyid = keyids[0]
        public = SSlibKey.from_dict(keyid, root_metadata.signed.keys[keyid].to_dict())
        raw = protect((private_dir / (role + '.dpapi')).read_bytes(), decrypt=True)
        signer = CryptoSigner(load_pem_private_key(raw, None), public)
        if signer.public_key.keyid != keyid:
            raise ValueError('私钥与受信任根不匹配')
        keys[role] = signer
    return keys


def signed_custom(company,release,compatibility):
    """Validate public compatibility data without keys, signing or file writes."""
    if type(release) is not int or release<1:
        raise ValueError('发布序号无效')
    if not isinstance(company,dict) or not isinstance(company.get('id'),str) or not company['id']:
        raise ValueError('发布企业标识缺失')
    if not isinstance(compatibility,dict) or set(compatibility)!={'min_installed_release','max_installed_release','data_schema'}:
        raise ValueError('发布前必须明确兼容的程序序号与数据库增量迁移')
    minimum,maximum=compatibility['min_installed_release'],compatibility['max_installed_release']
    if type(minimum) is not int or type(maximum) is not int or not 1<=minimum<=maximum<release:
        raise ValueError('兼容的旧程序发布序号无效')
    schema=compatibility['data_schema']
    if not isinstance(schema,dict) or set(schema)!={'from','to','operations'}:
        raise ValueError('数据库兼容信息无效')
    before,after,operations=schema['from'],schema['to'],schema['operations']
    if (type(before) is not int or type(after) is not int or not 0<=before<=after<=65535
            or not isinstance(operations,list) or len(operations)>128 or before==after and operations):
        raise ValueError('数据库兼容版本无效')
    from assistant.update_coordinator import _identifier,_column
    for operation in operations:
        if not isinstance(operation,dict):raise ValueError('数据库增量迁移无效')
        kind=operation.get('op')
        if kind=='add_column' and set(operation)=={'op','table','column'}:
            _identifier(operation['table']);_column(operation['column'])
        elif kind=='create_table' and set(operation)=={'op','table','columns'}:
            _identifier(operation['table'])
            columns=operation['columns']
            if not isinstance(columns,list) or not 1<=len(columns)<=64:raise ValueError('新表列定义无效')
            for column in columns:_column(column)
        elif kind=='create_index' and set(operation)=={'op','name','table','columns'}:
            _identifier(operation['name']);_identifier(operation['table'])
            columns=operation['columns']
            if not isinstance(columns,list) or not 1<=len(columns)<=16:raise ValueError('索引列定义无效')
            for column in columns:_identifier(column)
        else:raise ValueError('发布只允许兼容的声明式增量迁移')
    return {'release':release,'channel':'stable','platform':'windows-x64','company_id':company['id'],
            **json.loads(json.dumps(compatibility))}


CANDIDATE_RELEASE=ROOT/'work/packaging/candidate-release.json'


def approved_update_archive(target,company):
    """Read only the exact completed candidate's app ZIP, not its installer ZIP."""
    target=Path(target).resolve()
    if not CANDIDATE_RELEASE.is_file():
        raise ValueError('正式更新组件构建证据缺失')
    report=json.loads(CANDIDATE_RELEASE.read_text('utf-8-sig'))
    recorded=report.get('update_zip')
    expected=report.get('update_zip_sha256')
    if (not isinstance(recorded,str) or Path(recorded).resolve()!=target
            or not target.is_file() or not target.is_relative_to((ROOT/'outputs/正式交付').resolve())
            or not isinstance(expected,str) or len(expected)!=64
            or any(char not in '0123456789abcdef' for char in expected)):
        raise ValueError('待签名文件不是已验收候选的更新组件')
    digest=hashlib.sha256()
    with target.open('rb') as stream:
        for block in iter(lambda:stream.read(1024*1024),b''):
            digest.update(block)
    if digest.hexdigest()!=expected:
        raise ValueError('正式更新组件与构建记录不一致')
    runtime=company.get('runtime') or {}
    executable=runtime.get('executable')
    if (not isinstance(executable,str) or not executable.lower().endswith('.exe')
            or Path(executable).name!=executable or any(c in executable for c in '\\/:')):
        raise ValueError('正式更新组件程序名无效')
    with zipfile.ZipFile(target) as archive:
        names=archive.namelist()
        if names.count(executable)!=1 or names.count('company.json')!=1:
            raise ValueError('签名更新需使用应用组件ZIP，不能使用安装器或分版本便携ZIP')
        entry=archive.getinfo('company.json')
        if entry.file_size>256*1024:
            raise ValueError('更新组件企业配置过大')
        packaged=json.loads(archive.read(entry).decode('utf-8-sig'))
    actual=packaged.get('runtime') or {}
    if (packaged.get('id')!=company.get('id') or packaged.get('releaseVersion')!=company.get('releaseVersion') or packaged.get('releaseSequence')!=company.get('releaseSequence')
            or any(actual.get(key)!=runtime.get(key) for key in ('executable','ui_entry','release_approved','cli_source_sha256','xiaohongshu_automation'))
            or 'platform_qa_device_id' in actual):
        raise ValueError('更新组件与已批准发布配置不一致')
    return expected


def publish_metadata(target, release, feed_dir, private_dir, compatibility=None):
    company = authorized_release_company()
    target, feed_dir, private_dir = Path(target), Path(feed_dir), Path(private_dir)
    if not target.is_file() or type(release) is not int or release < 1:
        raise ValueError('目标ZIP或发布序号无效')
    if type(company.get('releaseSequence')) is not int or company['releaseSequence']!=release:
        raise ValueError('签名发布序号必须与已批准更新组件一致')
    custom=signed_custom(company,release,compatibility if compatibility is not None else company.get('updateCompatibility'))
    approved_digest=approved_update_archive(target,company)
    name=target.name
    info=TargetFile.from_file(name,str(target),['sha256'])
    if info.hashes.get('sha256')!=approved_digest:
        raise ValueError('签名读取时更新组件发生变化')
    metadata_dir = feed_dir / 'metadata'
    metadata_dir.mkdir(parents=True, exist_ok=True)
    existing_root = metadata_dir / 'root.json'
    root = Metadata.from_file(str(existing_root)) if existing_root.exists() else None
    keys = signers(private_dir, root)
    now = datetime.now(timezone.utc)
    if root is None:
        root = Metadata(Root(expires=now + timedelta(days=365), consistent_snapshot=False))
        for role in ROLES:
            root.signed.add_key(keys[role].public_key, role)
        root.sign(keys['root'])
        root.to_file(str(existing_root))
    elif root.signed.is_expired(now):
        raise ValueError('根元数据已过期，需要独立的根密钥轮换流程')

    old_targets = metadata_dir / 'targets.json'
    previous = Metadata.from_file(str(old_targets)) if old_targets.exists() else None
    version = previous.signed.version + 1 if previous else 1
    if previous:
        old_releases = [item.custom.get('release', 0) for item in previous.signed.targets.values()]
        if release <= max(old_releases, default=0):
            raise ValueError('发布序号必须递增')
        if any(item.hashes == info.hashes for item in previous.signed.targets.values()):
            raise ValueError('新发布包与已有版本内容相同')
    info.unrecognized_fields['custom'] = custom
    targets = Metadata(Targets(version=version, expires=now + timedelta(days=30), targets={name: info}))
    snapshot = Metadata(Snapshot(version=version, expires=now + timedelta(days=7),
                                 meta={'targets.json': MetaFile(version)}))
    timestamp = Metadata(Timestamp(version=version, expires=now + timedelta(days=1),
                                   snapshot_meta=MetaFile(version)))
    for role, metadata in [('targets', targets), ('snapshot', snapshot), ('timestamp', timestamp)]:
        metadata.sign(keys[role])
        metadata.to_file(str(metadata_dir / (role + '.json')))
    result = {'release': release, 'target': name, 'version': version,
              'sha256': info.hashes['sha256'], 'length': info.length,
              'metadata_dir': str(metadata_dir), 'root': str(existing_root)}
    (feed_dir / 'publication.json').write_text(json.dumps(result, ensure_ascii=False, indent=2), 'utf-8')
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('target', type=Path)
    parser.add_argument('release', type=int)
    parser.add_argument('feed_dir', type=Path)
    parser.add_argument('private_dir', type=Path)
    parser.add_argument('--compatibility',type=Path,help='明确旧程序序号与声明式数据库迁移的JSON文件')
    args = parser.parse_args()
    compatibility=json.loads(args.compatibility.read_text('utf-8-sig')) if args.compatibility else None
    print(json.dumps(publish_metadata(args.target, args.release, args.feed_dir, args.private_dir,compatibility), ensure_ascii=False))


if __name__ == '__main__':
    main()
