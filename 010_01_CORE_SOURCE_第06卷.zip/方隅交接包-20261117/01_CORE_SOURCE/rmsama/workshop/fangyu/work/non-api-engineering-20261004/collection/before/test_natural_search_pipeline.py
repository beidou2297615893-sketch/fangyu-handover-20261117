"""Persistent DOM range semantics through the existing task pipeline."""
import copy
from pathlib import Path
import sys
import unittest
from types import SimpleNamespace
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'src'))
from core.pipeline import collect_batch
from xhs_search_range import initial_checkpoint, mark_delivered
from xhs_natural_search import validate_result, map_notes, validate_range


def row(ident):
    return {'note_id':ident, 'xsec_token':'actual-link-token', 'xsec_source':'',
            'title':'上海求租', 'author':'博主',
            'url':'https://www.xiaohongshu.com/search_result/'+ident+'?xsec_token=actual-link-token',
            'author_avatar_url':'https://sns-avatar.xhscdn.com/real.jpg',
            'cover_url':'https://sns-webpic-qc.xhscdn.com/cover.jpg'}


def result(ident=None, *, state='more', keyword='上海租房', prior=None):
    checkpoint=copy.deepcopy(prior or initial_checkpoint(keyword))
    checkpoint['range_state']=state
    checkpoint['scan_step']+=1
    if ident:
        for field in ('observed_ids','ready_ids'):
            if ident not in checkpoint[field]:checkpoint[field].append(ident)
        checkpoint=mark_delivered(checkpoint,[ident])
    return {'code':0,'_transport':'natural_dom','data':{
        'items':[row(ident)] if ident else [],
        'range':{'state':state,'checkpoint':checkpoint,
                 'delivered_ids':list(checkpoint['delivered_ids'])}}}


class NaturalSearchPipelineTests(unittest.TestCase):
    def test_real_link_media_preserved_and_no_fabricated_metadata(self):
        envelope=result('a'*24)
        note=map_notes(envelope)[0]
        self.assertEqual(note['url'],row('a'*24)['url'])
        self.assertEqual(note['author_avatar_url'],row('a'*24)['author_avatar_url'])
        self.assertEqual(note['published_at'],'')
        self.assertEqual(note['author_id'],'')
        self.assertNotIn('has_more',validate_result(envelope))
        damaged=copy.deepcopy(envelope)
        damaged['data']['range']['delivered_ids']=[]
        with self.assertRaises(ValueError):validate_result(damaged)

    def task(self):
        return {'platform':'xiaohongshu','scope':'search_comments','continuous_enabled':True,
                'keywords':['上海租房','古北租房'],'comment_depth':'main'}

    def step(self,task,adapters):
        rows=collect_batch(adapters,task,lambda:None)
        task['pipeline']=task.pop('_pipeline_next')
        return rows

    def test_duplicate_batch_then_new_note_advances_without_api_has_more(self):
        task=self.task();queries=[]
        envelopes=[result('a'*24),result('a'*24),result('b'*24),
                   result(state='plateau')]
        def search(platform,query):
            queries.append(copy.deepcopy(query))
            env=envelopes.pop(0)
            query['_page_info']={'mode':'natural_dom','range_state':env['data']['range']['state'],
                                 'search_range':env['data']['range']}
            return map_notes(env)
        def comments(platform,query):
            query['_page_info']={'has_more':False}
            return [{'source_id':query['note_url'],'author':'租客','text':'什么时候能看房'}]
        adapters=SimpleNamespace(search=search,comments=comments)
        self.assertEqual(len(self.step(task,adapters)),1)
        self.assertEqual(self.step(task,adapters),[])
        self.assertEqual(task['pipeline']['keyword_index'],0)
        self.assertEqual(len(self.step(task,adapters)),1)
        self.assertEqual([q['next_page'] for q in queries],[1,2,3])
        self.assertIsNotNone(queries[1]['search_range'])
        self.assertEqual(self.step(task,adapters),[])
        self.assertEqual(task['pipeline']['keyword_index'],1)
        self.assertNotIn('search_range',task['pipeline'])

    def test_unknown_scanning_not_stopped_by_duplicate_fingerprint(self):
        task=self.task()
        def search(platform,query):
            env=result('a'*24,state='unknown')
            query['_page_info']={'mode':'natural_dom','range_state':'unknown',
                                 'search_range':env['data']['range']}
            return map_notes(env)
        def comments(platform,query):
            query['_page_info']={'has_more':False};return []
        adapters=SimpleNamespace(search=search,comments=comments)
        for _ in range(6):self.step(task,adapters)
        self.assertEqual(task['pipeline']['keyword_index'],0)
        self.assertTrue(task['pipeline']['search_more'])
        self.assertEqual(task['pipeline']['search_page'],7)

    def test_restart_passes_saved_range_and_empty_current_range_rotates(self):
        task=self.task()
        task['pipeline']={'keyword_index':0,'search_page':9,'notes':None,'note_index':0,
            'cursor':'','reply_queue':[],'search_range':result('a'*24)['data']['range']}
        saved=copy.deepcopy(task['pipeline']['search_range'])
        def search(platform,query):
            self.assertEqual(query['search_range'],saved)
            env=result(state='explicit_end',prior=saved['checkpoint'])
            query['_page_info']={'mode':'natural_dom','range_state':'explicit_end',
                                 'search_range':env['data']['range']};return []
        self.step(task,SimpleNamespace(search=search))
        self.assertEqual(task['pipeline']['keyword_index'],1)
        self.assertEqual(task['pipeline']['search_page'],1)

    def test_legacy_cli_reply_checkpoint_finishes_before_saved_main_cursor(self):
        task=self.task()
        task['comment_depth']='all'
        note=row('a'*24)['url']
        task['pipeline']={'keyword_index':0,'search_page':3,
            'notes':[{'url':note,'title':'合成帖','author':'合成博主','author_id':'author'}],
            'note_index':0,'cursor':'','cursor_history':[],
            'reply_queue':[{'id':'root','cursor':'sub-next',
                            'cursor_history':['sub-next'],'parent_text':'合成主评'}],
            'after_replies':{'has_more':True,'cursor':'main-next'},
            'search_more':True}
        calls=[]
        def sub_comments(platform,query):
            calls.append(('sub',query['next_cursor'],query['note_url']))
            query['_page_info']={'has_more':False,'cursor':''}
            return [{'source_id':'comment:reply','comment_id':'reply','parent_id':'root',
                     'text':'合成回复'}]
        def comments(platform,query):
            calls.append(('main',query['next_cursor'],query['note_url']))
            query['_page_info']={'has_more':False,'cursor':''}
            query['_reply_roots']=[]
            return [{'source_id':'comment:later','comment_id':'later','text':'合成评论'}]
        adapters=SimpleNamespace(sub_comments=sub_comments,comments=comments)
        self.assertEqual(len(self.step(task,adapters)),1)
        self.assertEqual(task['pipeline']['cursor'],'main-next')
        self.assertEqual(len(self.step(task,adapters)),1)
        self.assertEqual(calls,[('sub','sub-next',note),('main','main-next',note)])
        self.assertEqual(task['pipeline']['search_page'],4)

    def test_legacy_cli_page_without_dom_range_scans_zero_new_then_next_keyword(self):
        task=self.task()
        task['pipeline']={'keyword_index':0,'search_page':5,'notes':None,'note_index':0,
            'cursor':'','reply_queue':[],'seen_note_urls':['xhs:'+'a'*24]}
        queries=[]
        envelopes=[result('a'*24,state='more'),result(state='plateau'),
                   result('b'*24,keyword='古北租房',state='more')]
        def search(platform,query):
            queries.append((query['keywords'][0],query['next_page'],
                            'search_range' in query))
            env=envelopes.pop(0)
            query['_page_info']={'mode':'natural_dom',
                'range_state':env['data']['range']['state'],
                'search_range':env['data']['range']}
            return map_notes(env)
        def comments(platform,query):
            query['_page_info']={'has_more':False,'cursor':''}
            return [{'source_id':'comment:new','text':'合成评论'}]
        adapters=SimpleNamespace(search=search,comments=comments)
        self.assertEqual(self.step(task,adapters),[])
        self.assertEqual(task['pipeline']['keyword_index'],0)
        self.assertEqual(task['pipeline']['search_page'],6)
        self.assertEqual(self.step(task,adapters),[])
        self.assertEqual(task['pipeline']['keyword_index'],1)
        self.assertNotIn('search_range',task['pipeline'])
        self.assertEqual(len(self.step(task,adapters)),1)
        self.assertEqual(queries,[('上海租房',5,False),('上海租房',6,True),
                                  ('古北租房',1,False)])


if __name__=='__main__':unittest.main()
