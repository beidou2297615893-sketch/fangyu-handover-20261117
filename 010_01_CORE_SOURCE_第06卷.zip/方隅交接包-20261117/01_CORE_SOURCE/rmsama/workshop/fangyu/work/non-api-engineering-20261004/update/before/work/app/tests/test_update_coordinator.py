import io
import json
from contextlib import closing
from datetime import datetime,timedelta,timezone
from functools import partial
from http.server import SimpleHTTPRequestHandler,ThreadingHTTPServer
from pathlib import Path
import sqlite3
import sys
import tempfile
import threading
import unittest
from unittest.mock import patch
import zipfile

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from securesystemslib.signer import CryptoSigner
from tuf.api.metadata import Metadata,Root,Targets,Timestamp,Snapshot,TargetFile,MetaFile
from assistant.update_coordinator import UpdateCoordinator,_file_lock,installed_executable,migrate_additive


class Quiet(SimpleHTTPRequestHandler):
    def log_message(self,*args):pass


class UpdateCoordinatorTests(unittest.TestCase):
    """Synthetic signed loopback feed; no production accounts/data/processes."""
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root=Path(self.temp.name)
        self.data=self.root/'data'
        self.data.mkdir()
        (self.data/'assistant').mkdir()
        self.database=self.data/'workspace.sqlite3'
        with closing(sqlite3.connect(self.database)) as db:
            db.executescript('CREATE TABLE records(entity TEXT,id TEXT,body TEXT); CREATE TABLE sessions(token TEXT);')
            for entity in ('accounts','leads','replies'):
                db.execute('INSERT INTO records VALUES(?,?,?)',(entity,entity+'1',json.dumps({'text':entity,'status':'approved'})))
            db.execute('INSERT INTO sessions VALUES(?)',('local-session',))
            db.commit()
        with closing(sqlite3.connect(self.data/'assistant/executions.sqlite3')) as db:
            db.execute('CREATE TABLE executions(id TEXT,status TEXT)')
            db.execute('INSERT INTO executions VALUES(?,?)',('job1','completed'))
            db.commit()
        self.device=self.data/'assistant/device.dpapi'
        self.device.write_bytes(b'opaque-pairing-do-not-touch')
        self.cookie=self.data/'platform-cookie.txt'
        self.cookie.write_bytes(b'opaque-account-do-not-touch')
        self.repo=self.root/'repo'
        self.meta=self.repo/'metadata'
        self.targets=self.repo/'targets'
        self.meta.mkdir(parents=True)
        self.targets.mkdir()
        self.keys={role:CryptoSigner.generate_ed25519() for role in ('root','targets','snapshot','timestamp')}
        self.expiry=datetime.now(timezone.utc)+timedelta(days=1)
        root=Metadata(Root(expires=self.expiry,consistent_snapshot=False))
        for role,key in self.keys.items():root.signed.add_key(key.public_key,role)
        root.sign(self.keys['root'])
        self.trusted=self.root/'trusted-root.json'
        root.to_file(str(self.trusted))
        self.server=ThreadingHTTPServer(('127.0.0.1',0),partial(Quiet,directory=str(self.repo)))
        self.thread=threading.Thread(target=self.server.serve_forever,daemon=True)
        self.thread.start()
        self.addCleanup(self.close_server)
        url='http://127.0.0.1:'+str(self.server.server_port)
        self.company={'id':'fixture-company','releaseVersion':'1.0',
                      'updateFeed':{'enabled':True,'metadata_url':url+'/metadata/',
                                    'targets_url':url+'/targets/','trusted_root':str(self.trusted),'target':'latest.zip'}}
        self.coordinator=UpdateCoordinator(self.root/'install',self.data,self.company,idle_check=lambda:True,
                                           allow_test_http=True,executable='assistant.exe')
        first=self.root/'first.zip'
        first.write_bytes(self.package(1))
        self.coordinator.store.install_verified(first,1,lambda *_:True)
        self.publish()
        self.before=self.records()

    def close_server(self):
        self.server.shutdown()
        self.server.server_close()
        self.thread.join()

    def package(self,release,company_id='fixture-company'):
        content=io.BytesIO()
        with zipfile.ZipFile(content,'w') as archive:
            archive.writestr('assistant.exe',('fixture-'+str(release)).encode())
            archive.writestr('company.json',json.dumps({'id':company_id}))
        return content.getvalue()

    def publish(self,release=2,metadata_version=1,custom=None,company_id='fixture-company'):
        content=self.package(release,company_id)
        (self.targets/'latest.zip').write_bytes(content)
        target=TargetFile.from_data('latest.zip',content)
        target.unrecognized_fields['custom']={'release':release,'platform':'windows-x64','channel':'stable',
            'company_id':'fixture-company','min_installed_release':1,'max_installed_release':release-1,
            'data_schema':{'from':0,'to':1,'operations':[{'op':'create_table','table':'update_notes',
                                                       'columns':[{'name':'note','type':'TEXT'}]}]},**(custom or {})}
        targets=Metadata(Targets(version=metadata_version,expires=self.expiry,targets={'latest.zip':target}))
        targets.sign(self.keys['targets'])
        raw_targets=targets.to_bytes()
        snapshot=Metadata(Snapshot(version=metadata_version,expires=self.expiry,
                                    meta={'targets.json':MetaFile.from_data(metadata_version,raw_targets,['sha256'])}))
        snapshot.sign(self.keys['snapshot'])
        timestamp=Metadata(Timestamp(version=metadata_version,expires=self.expiry,
                                      snapshot_meta=MetaFile.from_data(metadata_version,snapshot.to_bytes(),['sha256'])))
        timestamp.sign(self.keys['timestamp'])
        for role,document in [('targets',targets),('snapshot',snapshot),('timestamp',timestamp)]:
            document.to_file(str(self.meta/(role+'.json')))

    def records(self):
        with closing(sqlite3.connect(self.database)) as db:
            return {'records':db.execute('SELECT * FROM records ORDER BY entity').fetchall(),
                    'sessions':db.execute('SELECT * FROM sessions').fetchall(),
                    'schema':db.execute('PRAGMA user_version').fetchone()[0],
                    'tables':db.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name").fetchall()}

    def queue(self):
        self.assertEqual(self.coordinator.check(download=True)['status'],'staged')
        self.assertEqual(self.coordinator.request_install()['status'],'pending_restart')

    def assert_preserved(self):
        self.assertEqual(self.records()['records'],self.before['records'])
        self.assertEqual(self.records()['sessions'],self.before['sessions'])
        self.assertEqual(self.device.read_bytes(),b'opaque-pairing-do-not-touch')
        self.assertEqual(self.cookie.read_bytes(),b'opaque-account-do-not-touch')
        with closing(sqlite3.connect(self.data/'assistant/executions.sqlite3')) as db:
            self.assertEqual(db.execute('SELECT * FROM executions').fetchall(),[('job1','completed')])

    def test_check_does_not_download_and_busy_cannot_queue(self):
        result=self.coordinator.check()
        self.assertEqual(result['status'],'available')
        self.assertEqual(result['candidate_release'],2)
        self.assertFalse(list((self.coordinator.directory/'tuf/downloads').iterdir()))
        self.coordinator.check(download=True)
        self.coordinator.idle_check=lambda:False
        self.assertEqual(self.coordinator.request_install()['status'],'busy')
        self.assertFalse(self.coordinator.pending_path.exists())
        self.assertEqual(self.records(),self.before)

    def test_healthy_apply_and_startup_confirmation_preserve_customer_state(self):
        self.queue()
        def health(executable,folder,data):
            self.assertEqual(executable.read_bytes(),b'fixture-2')
            self.assertFalse((data/'assistant/device.dpapi').exists())
            with closing(sqlite3.connect(data/'workspace.sqlite3')) as db:
                self.assertEqual(db.execute('PRAGMA user_version').fetchone()[0],1)
                # Probe writes must never reach real customer data.
                db.execute('DELETE FROM records')
                db.commit()
            return True
        self.assertEqual(self.coordinator.apply_pending_on_launch(health)['status'],'awaiting_confirmation')
        self.assertEqual(self.coordinator.store.active()['release'],2)
        self.assertEqual(self.records()['schema'],1)
        self.assert_preserved()
        self.assertEqual(self.coordinator.confirm_healthy(2)['status'],'installed')
        self.assertFalse(self.coordinator.journal_path.exists())
        self.assertFalse(self.coordinator.pending_path.exists())

    def test_running_app_blocks_install_and_rollback(self):
        self.queue()
        with _file_lock(self.data/'instance.lock'):
            result=self.coordinator.apply_pending_on_launch(lambda *_:self.fail('must not probe live app'))
            self.assertEqual(result['status'],'awaiting_close')
            self.assertEqual(self.coordinator.recover_interrupted()['status'],'awaiting_close')
        self.assertEqual(self.coordinator.store.active()['release'],1)
        self.assertEqual(self.records(),self.before)
        self.assertTrue(self.coordinator.pending_path.exists())

    def test_failed_candidate_keeps_old_program_and_database_usable(self):
        self.queue()
        with self.assertRaisesRegex(ValueError,'启动检查失败'):
            self.coordinator.apply_pending_on_launch(lambda *_:False)
        self.assertEqual(self.coordinator.store.active()['release'],1)
        self.assertEqual(self.records(),self.before)
        self.assert_preserved()
        self.assertEqual(self.coordinator.check()['status'],'update_rejected')
        self.publish(release=3,metadata_version=2)
        self.assertEqual(self.coordinator.check(download=True)['status'],'staged')

    def test_interrupted_commit_recovers_original_databases_and_program(self):
        self.queue()
        real_activate=self.coordinator.store.activate_prepared
        def power_loss(release):
            real_activate(release)
            raise KeyboardInterrupt('simulate power loss after pointer and DB swaps')
        with patch.object(self.coordinator.store,'activate_prepared',side_effect=power_loss):
            with self.assertRaises(KeyboardInterrupt):self.coordinator.apply_pending_on_launch(lambda *_:True)
        self.assertEqual(self.coordinator.store.active()['release'],2)
        self.assertEqual(self.records()['schema'],1)
        fresh=UpdateCoordinator(self.root/'install',self.data,self.company,allow_test_http=True,executable='assistant.exe')
        self.assertEqual(fresh.recover_interrupted()['status'],'rolled_back')
        self.assertEqual(fresh.store.active()['release'],1)
        self.assertEqual(self.records(),self.before)
        self.assert_preserved()
        with closing(sqlite3.connect(self.database)) as db:
            db.execute('INSERT INTO records VALUES(?,?,?)',('leads','after-rollback','{}'))
            db.commit()
        self.assertEqual(len(self.records()['records']),4)

    def test_interrupted_between_database_swaps_restores_both_snapshots(self):
        self.queue()
        replace=self.coordinator._replace_database
        calls=0
        def power_loss(source,destination):
            nonlocal calls
            replace(source,destination)
            calls+=1
            if calls==1:raise KeyboardInterrupt('simulate power loss after first database swap')
        with patch.object(self.coordinator,'_replace_database',side_effect=power_loss):
            with self.assertRaises(KeyboardInterrupt):
                self.coordinator.apply_pending_on_launch(lambda *_:True)
        self.assertEqual(calls,1)
        self.assertEqual(self.records()['schema'],1)
        self.assertEqual(self.coordinator.store.active()['release'],1)
        fresh=UpdateCoordinator(self.root/'install',self.data,self.company,
                                allow_test_http=True,executable='assistant.exe')
        self.assertEqual(fresh.recover_interrupted()['status'],'rolled_back')
        self.assertEqual(fresh.store.active()['release'],1)
        self.assertEqual(self.records(),self.before)
        self.assert_preserved()

    def test_unconfirmed_boot_rolls_back_but_confirmed_boot_never_drops_new_work(self):
        self.queue()
        self.coordinator.apply_pending_on_launch(lambda *_:True)
        self.assertEqual(self.coordinator.recover_interrupted()['status'],'rolled_back')
        self.assertEqual(self.records(),self.before)
        self.publish(release=3,metadata_version=2)
        self.queue()
        self.coordinator.apply_pending_on_launch(lambda *_:True)
        self.coordinator.confirm_healthy(3)
        with closing(sqlite3.connect(self.database)) as db:
            db.execute('INSERT INTO records VALUES(?,?,?)',('leads','new-work','{}'))
            db.commit()
        self.assertEqual(self.coordinator.recover_interrupted()['status'],'installed')
        self.assertEqual(len(self.records()['records']),4)

    def test_bad_migration_package_company_and_tampered_staging_are_rejected(self):
        self.publish(custom={'data_schema':{'from':0,'to':1,'operations':[{'op':'drop_table','table':'records'}]}})
        self.queue()
        with self.assertRaisesRegex(ValueError,'只允许兼容'):
            self.coordinator.apply_pending_on_launch(lambda *_:True)
        self.assertEqual(self.records(),self.before)
        self.publish(release=3,metadata_version=2,company_id='another-company')
        self.queue()
        with self.assertRaisesRegex(ValueError,'企业配置'):
            self.coordinator.apply_pending_on_launch(lambda *_:True)
        self.assertEqual(self.records(),self.before)
        self.publish(release=4,metadata_version=3)
        self.coordinator.check(download=True)
        staged=self.coordinator._state()['staged']
        Path(staged['path']).write_bytes(b'tampered')
        with self.assertRaises(Exception):self.coordinator.request_install()
        self.assertEqual(self.records(),self.before)

    def test_signed_wrong_tenant_and_incompatible_schema_rejected_before_download(self):
        self.publish(custom={'company_id':'other-company'})
        with self.assertRaisesRegex(ValueError,'客户公司'):self.coordinator.check(download=True)
        self.publish(metadata_version=2,custom={'data_schema':{'from':9,'to':10,'operations':[]}})
        with self.assertRaisesRegex(ValueError,'数据库版本'):self.coordinator.check(download=True)
        self.assertFalse(list((self.coordinator.directory/'tuf/downloads').iterdir()))
        self.assertEqual(self.records(),self.before)

    def test_wal_snapshot_includes_committed_frames(self):
        connection=sqlite3.connect(self.database)
        self.addCleanup(connection.close)
        connection.execute('PRAGMA journal_mode=WAL')
        connection.execute('INSERT INTO records VALUES(?,?,?)',('leads','wal-row','{}'))
        connection.commit()
        transaction=self.root/'wal-snapshot'
        self.coordinator._snapshot(transaction)
        with closing(sqlite3.connect(transaction/'backup/workspace.sqlite3')) as snapshot:
            self.assertEqual(snapshot.execute("SELECT COUNT(*) FROM records WHERE id='wal-row'").fetchone()[0],1)
        connection.close()
        self.queue()
        self.coordinator.apply_pending_on_launch(lambda *_:True)
        self.coordinator.recover_interrupted()
        self.assertTrue(any(row[1]=='wal-row' for row in self.records()['records']))

    def test_corrupted_recovery_backup_leaves_candidate_untouched(self):
        self.queue()
        self.coordinator.apply_pending_on_launch(lambda *_:True)
        journal=json.loads(self.coordinator.journal_path.read_text('utf-8'))
        backup=self.coordinator._transaction_dir(journal)/'backup/workspace.sqlite3'
        backup.write_bytes(b'corrupt')
        with self.assertRaisesRegex(ValueError,'摘要不一致'):self.coordinator.recover_interrupted()
        self.assertEqual(self.coordinator.store.active()['release'],2)
        self.assertEqual(self.records()['schema'],1)
        self.assertTrue(self.coordinator.journal_path.exists())

    def test_corrupted_secondary_backup_blocks_partial_rollback(self):
        self.queue()
        self.coordinator.apply_pending_on_launch(lambda *_:True)
        journal=json.loads(self.coordinator.journal_path.read_text('utf-8'))
        backup=self.coordinator._transaction_dir(journal)/'backup/assistant/executions.sqlite3'
        backup.write_bytes(b'corrupt')
        with self.assertRaisesRegex(ValueError,'摘要不一致'):
            self.coordinator.recover_interrupted()
        self.assertEqual(self.coordinator.store.active()['release'],2)
        self.assertEqual(self.records()['schema'],1)
        self.assertTrue(self.coordinator.journal_path.exists())

    def test_pending_release_number_tamper_and_disabled_feed_never_install(self):
        self.queue()
        pending=json.loads(self.coordinator.pending_path.read_text('utf-8'))
        pending['release']=99
        self.coordinator.pending_path.write_text(json.dumps(pending),'utf-8')
        with self.assertRaisesRegex(ValueError,'发布序号'):
            self.coordinator.apply_pending_on_launch(lambda *_:True)
        self.assertEqual(self.records(),self.before)
        self.queue()
        self.company['updateFeed']['enabled']=False
        self.assertEqual(self.coordinator.apply_pending_on_launch(lambda *_:True)['status'],'updates_disabled')
        self.assertEqual(self.coordinator.store.active()['release'],1)

    def test_tuf_metadata_rollback_still_rejected_by_orchestrated_checks(self):
        self.publish(metadata_version=2)
        self.coordinator.check()
        self.publish(metadata_version=1)
        with self.assertRaises(Exception):self.coordinator.check()
        self.assertEqual(self.records(),self.before)


class AdditiveMigrationTests(unittest.TestCase):
    def test_add_column_transaction_failure_keeps_all_original_rows_and_schema(self):
        with tempfile.TemporaryDirectory() as directory:
            path=Path(directory)/'database.sqlite3'
            with closing(sqlite3.connect(path)) as db:
                db.executescript("CREATE TABLE notes(text TEXT); INSERT INTO notes VALUES('preserved');")
            schema={'from':0,'to':1,'operations':[
                {'op':'add_column','table':'notes','column':{'name':'label','type':'TEXT','default':'new'}},
                {'op':'create_index','name':'bad_index','table':'missing','columns':['text']}]}
            with self.assertRaises(sqlite3.OperationalError):migrate_additive(path,schema)
            with closing(sqlite3.connect(path)) as db:
                self.assertEqual(db.execute('SELECT * FROM notes').fetchall(),[('preserved',)])
                self.assertEqual(db.execute('PRAGMA user_version').fetchone()[0],0)
            schema['operations'].pop()
            migrate_additive(path,schema)
            with closing(sqlite3.connect(path)) as db:
                self.assertEqual(db.execute('SELECT * FROM notes').fetchall(),[('preserved','new')])


class InstalledExecutableTests(unittest.TestCase):
    def test_fixed_manifest_names_customer_executable_and_rejects_unsafe_layout(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory)
            self.assertEqual(installed_executable(root,'fixture-company'),'方隅采集助手.exe')
            manifest=root/'installation.json'
            layout={'company_id':'fixture-company','executable':'方隅公寓本地助手.exe',
                    'launcher':'方隅固定入口.exe'}
            manifest.write_text(json.dumps(layout,ensure_ascii=False),'utf-8')
            self.assertEqual(installed_executable(root,'fixture-company'),layout['executable'])
            with self.assertRaisesRegex(ValueError,'客户不一致'):
                installed_executable(root,'another-company')
            for value in ('../other.exe','C:/other.exe','con.exe','bad .exe','bad.exe ',42):
                with self.subTest(value=value):
                    layout['executable']=value
                    manifest.write_text(json.dumps(layout,ensure_ascii=False),'utf-8')
                    with self.assertRaisesRegex(ValueError,'无效程序名称'):
                        installed_executable(root,'fixture-company')


if __name__=='__main__':unittest.main()
