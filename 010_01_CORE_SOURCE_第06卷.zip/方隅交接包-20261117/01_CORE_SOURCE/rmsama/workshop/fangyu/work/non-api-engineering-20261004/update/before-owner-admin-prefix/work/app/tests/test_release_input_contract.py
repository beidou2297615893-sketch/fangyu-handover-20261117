"""Synthetic release input/ZIP contracts; no builds, keys, network or real data."""
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import Mock,patch
import zipfile

PROJECT=Path(__file__).resolve().parents[3]
sys.path.insert(0,str(PROJECT/'work/assistant'))
import release_authorization as authorization
spec=importlib.util.spec_from_file_location('fangyu_sign_input_contract',PROJECT/'work/assistant/sign_update_feed.py')
signer=importlib.util.module_from_spec(spec);spec.loader.exec_module(signer)


def approved_company():
    return {'id':'fangyu-apartment-client','edition':'customer','authMode':'managed','releaseVersion':'1.1.7','releaseSequence':2,
            'runtime':{'role':'local_assistant_only','executable':'方隅公寓本地助手.exe','ui_entry':'employee_workspace',
                       'release_approved':True,'xiaohongshu_automation':'enabled','cli_source_sha256':'a'*64}}


class ReleaseInputTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup)
        self.root=Path(self.temp.name);self.source=self.root/'company.json'
        self.source.write_text(json.dumps({'id':'fangyu-apartment-client','runtime':{'xiaohongshu_automation':'hold'}}),'utf-8')
        self.before=self.source.read_bytes();self.generated=[]
        self.builder=SimpleNamespace(APP=self.root,preflight=Mock(return_value={'ready':True}),
            release_company_config=Mock(side_effect=self.materialize),validate_release_config=Mock())
        self.addCleanup(patch.stopall)
        patch.object(authorization,'RELEASE_BLOCK',self.root/'RELEASE_BLOCKED.txt').start()
        patch.object(authorization,'_release_builder',return_value=self.builder).start()
    def materialize(self,source,ready):
        self.assertTrue(ready);self.assertEqual(source['runtime']['xiaohongshu_automation'],'hold')
        self.generated.append(source);return approved_company()
    def test_approved_copy_does_not_activate_source(self):
        result=authorization.authorized_release_company()
        self.assertEqual(result['runtime']['xiaohongshu_automation'],'enabled')
        self.assertEqual(self.source.read_bytes(),self.before)
        self.builder.validate_release_config.assert_called_once_with(result)
    def test_release_hold_stops_before_preflight_or_materialization(self):
        (self.root/'RELEASE_BLOCKED.txt').write_text('held','utf-8')
        with self.assertRaisesRegex(RuntimeError,'仍暂停'):authorization.authorized_release_company()
        self.builder.preflight.assert_not_called();self.builder.release_company_config.assert_not_called()
    def test_technical_checks_do_not_replace_approval(self):
        self.builder.preflight.return_value={'technical_ready':True,'ready':False}
        with self.assertRaisesRegex(RuntimeError,'批准未通过'):authorization.authorized_release_company()
        self.builder.release_company_config.assert_not_called()
    def test_ready_must_be_true_boolean(self):
        self.builder.preflight.return_value={'ready':'true'}
        with self.assertRaises(RuntimeError):authorization.authorized_release_company()
    def test_wrong_company_or_ui_or_qa_marker_is_rejected(self):
        for field,value in [('id','other-client'),('ui_entry','assistant'),('platform_qa_device_id','qa-device')]:
            with self.subTest(field=field):
                company=approved_company()
                if field=='id':company[field]=value
                else:company['runtime'][field]=value
                self.builder.release_company_config.side_effect=None
                self.builder.release_company_config.return_value=company
                with self.assertRaisesRegex(RuntimeError,'单窗口'):authorization.authorized_release_company()
    def test_private_field_validation_failure_cannot_return_release(self):
        self.builder.validate_release_config.side_effect=ValueError('private data')
        with self.assertRaisesRegex(ValueError,'private data'):authorization.authorized_release_company()
        self.assertEqual(self.source.read_bytes(),self.before)


class UpdateArchiveTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup)
        self.root=Path(self.temp.name);self.delivery=self.root/'outputs/正式交付/candidate';self.delivery.mkdir(parents=True)
        self.archive=self.delivery/'update-component.zip';self.company=approved_company()
        self.report=self.root/'candidate-release.json'
        self.addCleanup(patch.stopall);patch.object(signer,'ROOT',self.root).start()
        patch.object(signer,'CANDIDATE_RELEASE',self.report).start()
        self.package()
    def package(self,company=None,managed=False,extra=None):
        company=copy.deepcopy(self.company if company is None else company)
        with zipfile.ZipFile(self.archive,'w') as archive:
            archive.writestr(('releases/1/' if managed else '')+self.company['runtime']['executable'],b'synthetic-not-executable')
            archive.writestr('company.json',json.dumps(company))
            if extra:archive.writestr(extra,b'synthetic-only')
        digest=hashlib.sha256(self.archive.read_bytes()).hexdigest()
        self.report.write_text(json.dumps({'update_zip':str(self.archive),'update_zip_sha256':digest}),'utf-8')
        return digest
    def test_exact_app_component_matches_candidate(self):
        expected=hashlib.sha256(self.archive.read_bytes()).hexdigest()
        self.assertEqual(signer.approved_update_archive(self.archive,self.company),expected)
    def test_maintainer_state_cannot_be_signed_even_in_recorded_candidate(self):
        for name in ('private/grant.dpapi','owner-admin/portal.js','assets/window.dpapi'):
            with self.subTest(name=name):
                self.package(extra=name)
                with self.assertRaisesRegex(ValueError,'维护者私有文件'):
                    signer.approved_update_archive(self.archive,self.company)
    def test_managed_installer_zip_is_not_an_update_component(self):
        self.package(managed=True)
        with self.assertRaisesRegex(ValueError,'不能使用安装器'):signer.approved_update_archive(self.archive,self.company)
    def test_changed_candidate_bytes_rejected(self):
        with self.archive.open('ab') as stream:stream.write(b'changed')
        with self.assertRaisesRegex(ValueError,'构建记录不一致'):signer.approved_update_archive(self.archive,self.company)
    def test_other_company_or_internal_qa_package_rejected(self):
        for key,value in [('id','other-client'),('platform_qa_device_id','device')]:
            with self.subTest(key=key):
                candidate=copy.deepcopy(self.company)
                if key=='id':candidate[key]=value
                else:candidate['runtime'][key]=value
                self.package(company=candidate)
                with self.assertRaisesRegex(ValueError,'发布配置不一致'):signer.approved_update_archive(self.archive,self.company)
    def test_unrecorded_or_outside_delivery_file_rejected(self):
        unrelated=self.root/'unrelated.zip';unrelated.write_bytes(self.archive.read_bytes())
        with self.assertRaisesRegex(ValueError,'不是已验收候选'):signer.approved_update_archive(unrelated,self.company)
    def test_old_candidate_record_without_update_component_rejected(self):
        self.report.write_text(json.dumps({'portable_zip':str(self.archive)}),'utf-8')
        with self.assertRaises(ValueError):signer.approved_update_archive(self.archive,self.company)
    def test_signing_sequence_cannot_relabel_old_component(self):
        company=copy.deepcopy(self.company);company['releaseSequence']=1
        with patch.object(signer,'authorized_release_company',return_value=company),patch.object(signer,'signers') as keys:
            with self.assertRaisesRegex(ValueError,'发布序号'):signer.publish_metadata(self.archive,2,self.root/'feed',self.root/'keys',{})
            keys.assert_not_called()
        self.assertFalse((self.root/'feed').exists());self.assertFalse((self.root/'keys').exists())
    def test_rejection_happens_before_keys_and_feed_directories(self):
        self.package(managed=True)
        compatibility={'min_installed_release':1,'max_installed_release':1,'data_schema':{'from':0,'to':0,'operations':[]}}
        with patch.object(signer,'authorized_release_company',return_value=self.company),patch.object(signer,'signers') as keys:
            with self.assertRaises(ValueError):signer.publish_metadata(self.archive,2,self.root/'feed',self.root/'keys',compatibility)
            keys.assert_not_called()
        self.assertFalse((self.root/'feed').exists());self.assertFalse((self.root/'keys').exists())


if __name__=='__main__':unittest.main()
