"""TUF performs trust/expiry/rollback/hash verification. This module only stages.
Installation and task-idle gating must be performed by the separate supervisor.
"""
from pathlib import Path,PurePosixPath
from urllib.parse import urlsplit
from tuf.ngclient import Updater

def checked_url(value,allow_test_http=False):
    u=urlsplit(value)
    test=allow_test_http and u.scheme=='http' and u.hostname=='127.0.0.1'
    if (u.scheme!='https' and not test) or not u.hostname or u.username or u.password or u.query or u.fragment:
        raise ValueError('更新地址必须为预设HTTPS地址')
    return value

class VerifiedUpdates:
    def __init__(self,state_dir,trusted_root,metadata_url,targets_url,channel='stable',allow_test_http=False):
        self.directory=Path(state_dir);self.channel=channel
        meta=self.directory/'metadata';targets=self.directory/'downloads'
        meta.mkdir(parents=True,exist_ok=True);targets.mkdir(exist_ok=True)
        self.root=Path(trusted_root)
        self.arguments=(str(meta),checked_url(metadata_url,allow_test_http))
        self.options={'target_dir':str(targets),'target_base_url':checked_url(targets_url,allow_test_http)}

    def inspect(self,target_name):
        """Refresh persisted TUF trust and inspect one configured signed target.

        This performs no package download and accepts no feed URL from a remote
        command. The caller decides whether the release is newer/compatible.
        """
        if not isinstance(target_name,str):raise ValueError('更新目标路径无效')
        path=PurePosixPath(target_name)
        if path.is_absolute() or '..' in path.parts or '\\' in target_name or ':' in target_name or not target_name.endswith('.zip'):
            raise ValueError('更新目标路径无效')
        # TUF Updater is one refresh cycle; reopen it with persisted trust for every
        # check, including repeat checks during the same assistant process.
        bootstrap=None if (self.directory/'metadata/root.json').exists() else self.root.read_bytes()
        self.updater=Updater(*self.arguments,**self.options,bootstrap=bootstrap)
        self.updater.refresh()
        info=self.updater.get_targetinfo(target_name)
        if info is None:raise ValueError('目标不在受信任发布清单中')
        custom=info.custom or {};release=custom.get('release')
        if custom.get('platform')!='windows-x64' or custom.get('channel')!=self.channel or type(release) is not int or release<1:
            raise ValueError('更新平台、通道或递增版本不匹配')
        self.targetinfo=info
        return {'target':target_name,'release':release,'hashes':dict(info.hashes),'length':info.length,
                'custom':dict(custom),'verified':True}

    def download(self,inspected):
        """Download only the TargetFile inspected in this refresh cycle."""
        info=getattr(self,'targetinfo',None)
        if info is None or inspected.get('target')!=info.path or inspected.get('hashes')!=info.hashes:
            raise ValueError('下载目标与受信任清单不一致')
        filename=self.updater.find_cached_target(info) or self.updater.download_target(info)
        return {**inspected,'path':filename}

    def stage(self,target_name,installed_release):
        inspected=self.inspect(target_name)
        if type(installed_release) is not int or inspected['release']<=installed_release:
            raise ValueError('更新平台、通道或递增版本不匹配')
        return self.download(inspected)
