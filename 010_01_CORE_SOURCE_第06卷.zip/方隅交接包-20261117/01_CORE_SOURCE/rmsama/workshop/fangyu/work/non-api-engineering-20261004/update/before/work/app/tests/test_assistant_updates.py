import sys,unittest,tempfile,threading
from functools import partial
from pathlib import Path
from datetime import datetime,timedelta,timezone
from http.server import SimpleHTTPRequestHandler,ThreadingHTTPServer
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from tuf.api.metadata import Metadata,Root,Timestamp,Snapshot,Targets,TargetFile,MetaFile
from securesystemslib.signer import CryptoSigner
from assistant.updates import VerifiedUpdates

class Quiet(SimpleHTTPRequestHandler):
    def log_message(self,*args):pass

class SignedUpdateTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.root=Path(self.temp.name);self.repo=self.root/'repo';self.meta=self.repo/'metadata';self.targets=self.repo/'targets'
        self.meta.mkdir(parents=True);self.targets.mkdir();self.name='assistant-2.zip';self.content=b'fixture update bytes'
        (self.targets/self.name).write_bytes(self.content)
        self.keys={role:CryptoSigner.generate_ed25519() for role in ('root','targets','snapshot','timestamp')}
        expires=datetime.now(timezone.utc)+timedelta(days=1)
        root=Metadata(Root(expires=expires,consistent_snapshot=False))
        for role,key in self.keys.items():root.signed.add_key(key.public_key,role)
        root.sign(self.keys['root']);self.trusted=self.root/'trusted.json';root.to_file(str(self.trusted))
        self.write_metadata(expires)
        self.server=ThreadingHTTPServer(('127.0.0.1',0),partial(Quiet,directory=str(self.repo)));self.thread=threading.Thread(target=self.server.serve_forever,daemon=True);self.thread.start()
        self.url='http://127.0.0.1:'+str(self.server.server_port)

    def write_metadata(self,expires,version=1,bad_signature=False):
        info=TargetFile.from_data(self.name,self.content);info.unrecognized_fields['custom']={'release':2,'channel':'stable','platform':'windows-x64'}
        targets=Metadata(Targets(version=version,expires=expires,targets={self.name:info}))
        snapshot=Metadata(Snapshot(version=version,expires=expires,meta={'targets.json':MetaFile(version)}))
        timestamp=Metadata(Timestamp(version=version,expires=expires,snapshot_meta=MetaFile(version)))
        for role,obj in [('targets',targets),('snapshot',snapshot),('timestamp',timestamp)]:
            obj.sign(CryptoSigner.generate_ed25519() if bad_signature and role=='timestamp' else self.keys[role]);obj.to_file(str(self.meta/(role+'.json')))

    def client(self):return VerifiedUpdates(self.root/'cache',self.trusted,self.url+'/metadata/',self.url+'/targets/',allow_test_http=True)
    def tearDown(self):self.server.shutdown();self.server.server_close();self.thread.join();self.temp.cleanup()

    def test_trusted_update_stages_but_does_not_execute(self):
        client=self.client();result=client.stage(self.name,1)
        self.assertTrue(result['verified']);self.assertEqual(Path(result['path']).read_bytes(),self.content)
        self.assertEqual(client.stage(self.name,1)['path'],result['path'])

    def test_tampered_target_rejected(self):
        (self.targets/self.name).write_bytes(b'not signed payload')
        with self.assertRaises(Exception):self.client().stage(self.name,1)

    def test_wrong_signer_rejected(self):
        self.write_metadata(datetime.now(timezone.utc)+timedelta(days=1),bad_signature=True)
        with self.assertRaises(Exception):self.client().stage(self.name,1)

    def test_expired_metadata_rejected(self):
        self.write_metadata(datetime.now(timezone.utc)-timedelta(days=1))
        with self.assertRaises(Exception):self.client().stage(self.name,1)

    def test_metadata_rollback_rejected_after_trusted_new_version(self):
        expiry=datetime.now(timezone.utc)+timedelta(days=1)
        self.write_metadata(expiry,version=2);self.client().stage(self.name,1)
        self.write_metadata(expiry,version=1)
        with self.assertRaises(Exception):self.client().stage(self.name,1)

    def test_installed_release_downgrade_and_plain_http_rejected(self):
        with self.assertRaises(ValueError):self.client().stage(self.name,2)
        with self.assertRaises(ValueError):VerifiedUpdates(self.root/'unsafe',self.trusted,self.url+'/metadata/',self.url+'/targets/')

if __name__=='__main__':unittest.main()
