import sys
import tempfile
import unittest
import zipfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'src'))
from assistant.release import ReleaseStore


class ReleaseStoreTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.store = ReleaseStore(self.root / 'install', executable='assistant.exe')

    def archive(self, name, entries=None):
        path = self.root / name
        with zipfile.ZipFile(path, 'w') as archive:
            for filename, data in (entries or {'assistant.exe': b'bin', 'company.json': b'{}'}).items():
                archive.writestr(filename, data)
        return path

    def test_healthy_release_activates_and_can_rollback(self):
        first = self.archive('first.zip')
        self.store.install_verified(first, 1, lambda exe, folder: exe.read_bytes() == b'bin')
        second = self.archive('second.zip', {'assistant.exe': b'new', 'company.json': b'{}'})
        self.store.install_verified(second, 2, lambda exe, folder: exe.read_bytes() == b'new')
        self.assertEqual(self.store.active()['release'], 2)
        self.assertEqual(self.store.rollback(2).name, '1')
        self.assertEqual(self.store.active()['release'], 1)

    def test_failed_healthcheck_keeps_previous_and_cleans_pending(self):
        self.store.install_verified(self.archive('first.zip'), 1, lambda *_: True)
        with self.assertRaisesRegex(ValueError, '启动检查失败'):
            self.store.install_verified(self.archive('bad.zip'), 2, lambda *_: False)
        self.assertEqual(self.store.active()['release'], 1)
        self.assertFalse((self.store.releases / '2').exists())
        self.assertFalse(list(self.store.releases.glob('.pending-*')))

    def test_traversal_and_downgrade_rejected(self):
        with self.assertRaisesRegex(ValueError, '不安全路径'):
            self.store.install_verified(self.archive('traversal.zip', {'../outside': b'bad'}), 1, lambda *_: True)
        self.assertFalse((self.root / 'outside').exists())
        self.store.install_verified(self.archive('first.zip'), 1, lambda *_: True)
        with self.assertRaisesRegex(ValueError, '回退'):
            self.store.install_verified(self.archive('second.zip'), 1, lambda *_: True)

    def test_windows_case_collision_rejected(self):
        archive = self.archive('collision.zip', {
            'assistant.exe': b'bin', 'company.json': b'{}',
            'Assets/icon.png': b'1', 'assets/ICON.png': b'2'})
        with self.assertRaisesRegex(ValueError, '重复路径'):
            self.store.install_verified(archive, 1, lambda *_: True)

    def test_maintainer_state_never_enters_release(self):
        for name in ('private/grant.dpapi','owner-admin/portal.js','assets/window.dpapi'):
            with self.subTest(name=name):
                archive=self.archive('private.zip', {
                    'assistant.exe':b'bin','company.json':b'{}',name:b'synthetic-only'})
                with self.assertRaisesRegex(ValueError,'不安全路径'):
                    self.store.install_verified(archive,1,lambda *_:True)
                self.assertFalse((self.store.releases/'1').exists())

    def test_corrupt_previous_release_pointer_rejected(self):
        self.store.install_verified(self.archive('first.zip'), 1, lambda *_: True)
        self.store.pointer.write_text('{"release":1,"previous":"../other"}', 'utf-8')
        with self.assertRaisesRegex(ValueError, '上一版本记录损坏'):
            self.store.active()

    def test_windows_device_and_ambiguous_paths_rejected(self):
        for name in ('CON.txt','assets/COM1 .png','assets/LPT¹.png','assets/trailing.','assets/a?.png','assets//icon.png'):
            with self.subTest(path=name):
                entries={'assistant.exe':b'bin','company.json':b'{}',name:b'bad'}
                with self.assertRaisesRegex(ValueError,'不安全路径'):
                    self.store.install_verified(self.archive('unsafe.zip',entries),1,lambda *_:True)


if __name__ == '__main__':
    unittest.main()
