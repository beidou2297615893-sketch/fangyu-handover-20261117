"""Local, transactional release staging after TUF has verified an archive.

The running assistant never replaces its own executable. A separate launcher can
switch active.json after a candidate passes its health check, and restore the
previous pointer if the first real launch fails.
"""
import json
import os
import re
from pathlib import Path, PurePosixPath
import shutil
import socket
import stat
import subprocess
import tempfile
import time
import urllib.request
import uuid
import zipfile
from contextlib import ExitStack


class ReleaseStore:
    def __init__(self, root, executable='方隅采集助手.exe'):
        self.root = Path(root)
        self.releases = self.root / 'releases'
        self.pointer = self.root / 'active.json'
        self.executable = executable
        self.releases.mkdir(parents=True, exist_ok=True)

    def active(self):
        if not self.pointer.exists():
            return None
        value = json.loads(self.pointer.read_text('utf-8'))
        release = value.get('release')
        if type(release) is not int or release < 1:
            raise ValueError('当前版本记录损坏')
        previous = value.get('previous')
        if previous is not None and (type(previous) is not int or previous < 1 or previous >= release):
            raise ValueError('上一版本记录损坏')
        folder = self.releases / str(release)
        if not (folder / self.executable).is_file():
            raise ValueError('当前版本文件缺失')
        return value

    def _write_pointer(self, value):
        temp = self.root / ('active.' + uuid.uuid4().hex + '.tmp')
        try:
            with temp.open('w',encoding='utf-8') as stream:
                stream.write(json.dumps(value, ensure_ascii=False))
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(temp, self.pointer)
        finally:
            temp.unlink(missing_ok=True)

    def prepare_verified(self, staged, release, healthcheck):
        """Extract/probe a verified archive without changing the active pointer."""
        if type(release) is not int or release < 1:
            raise ValueError('发布序号无效')
        current = self.active()
        if current and release <= current['release']:
            raise ValueError('不允许回退或重复安装')
        final = self.releases / str(release)
        if final.exists():
            raise ValueError('目标发布目录已存在')
        pending = self.releases / ('.pending-' + uuid.uuid4().hex)
        pending.mkdir()
        try:
            with zipfile.ZipFile(staged) as archive:
                entries = archive.infolist()
                if not entries or len(entries) > 10000:
                    raise ValueError('更新包文件数量无效')
                total = 0
                names = set()
                for item in entries:
                    path = PurePosixPath(item.filename)
                    mode = (item.external_attr >> 16)
                    if (not item.filename or path.is_absolute() or '..' in path.parts
                            or '\\' in item.filename or ':' in item.filename
                            or stat.S_ISLNK(mode)
                            or str(path)!=item.filename.rstrip('/')
                            or any(part.endswith((' ','.')) or any(ord(c)<32 or c in '<>"|?*' for c in part)
                                   or re.fullmatch(r'(con|prn|aux|nul|com[1-9¹²³]|lpt[1-9¹²³])',part.split('.')[0].rstrip(' .'),re.I)
                                   for part in path.parts)):
                        raise ValueError('更新包包含不安全路径')
                    normalized = str(path).rstrip('/').casefold()
                    if normalized in names:
                        raise ValueError('更新包包含重复路径')
                    names.add(normalized)
                    total += item.file_size
                    if total > 4 * 1024**3:
                        raise ValueError('更新包解压尺寸过大')
                for item in entries:
                    target = pending.joinpath(*PurePosixPath(item.filename).parts)
                    if item.is_dir():
                        target.mkdir(parents=True, exist_ok=True)
                    else:
                        target.parent.mkdir(parents=True, exist_ok=True)
                        with archive.open(item) as source, target.open('wb') as dest:
                            shutil.copyfileobj(source, dest)
            executable = pending / self.executable
            if not executable.is_file() or not (pending / 'company.json').is_file():
                raise ValueError('更新包缺少助手或企业配置')
            if not healthcheck(executable, pending):
                raise ValueError('新版本启动检查失败')
            os.replace(pending, final)
            return final
        finally:
            if pending.exists():
                shutil.rmtree(pending)

    def activate_prepared(self, release):
        current=self.active()
        if type(release) is not int or release<1 or current and release<=current['release']:
            raise ValueError('不允许回退或重复安装')
        final=self.releases/str(release)
        if final.is_symlink() or not (final/self.executable).is_file() or not (final/'company.json').is_file():
            raise ValueError('准备好的版本文件缺失')
        self._write_pointer({'release':release,'previous':current['release'] if current else None})
        return final

    def install_verified(self, staged, release, healthcheck):
        """Legacy program-only install; schema-changing updates use the coordinator."""
        self.prepare_verified(staged,release,healthcheck)
        return self.activate_prepared(release)

    def rollback(self, failed_release):
        current = self.active()
        if not current or current['release'] != failed_release or not current.get('previous'):
            raise ValueError('没有可回退的上一版本')
        previous = current['previous']
        if not (self.releases / str(previous) / self.executable).is_file():
            raise ValueError('上一版本文件缺失')
        self._write_pointer({'release': previous, 'previous': None})
        return self.releases / str(previous)


def probe_assistant(executable, folder, timeout=30, data_dir=None):
    """Start the packaged assistant with throwaway data and require its real API."""
    executable, folder = Path(executable), Path(folder)
    with socket.socket() as sock:
        sock.bind(('127.0.0.1', 0))
        port = sock.getsockname()[1]
    flags = getattr(subprocess, 'CREATE_NO_WINDOW', 0)
    with ExitStack() as resources:
        data=str(data_dir) if data_dir is not None else resources.enter_context(tempfile.TemporaryDirectory(prefix='fangyu-release-probe-'))
        process = subprocess.Popen(
            [str(executable), '--assistant', '--headless', '--port', str(port), '--data-dir', data],
            cwd=str(folder), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
            creationflags=flags,
        )
        try:
            deadline = time.monotonic() + timeout
            request = urllib.request.Request(
                f'http://127.0.0.1:{port}/api',
                data=b'{"action":"assistant_status"}',
                headers={'Content-Type': 'application/json', 'X-Local-App': '1'},
                method='POST',
            )
            while time.monotonic() < deadline:
                if process.poll() is not None:
                    return False
                try:
                    with urllib.request.urlopen(request, timeout=1) as response:
                        state = json.load(response)
                    return response.status == 200 and state.get('state') == 'unbound'
                except (OSError, ValueError):
                    time.sleep(.25)
            return False
        finally:
            if process.poll() is None:
                process.terminate()
            try:
                process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait(timeout=5)
