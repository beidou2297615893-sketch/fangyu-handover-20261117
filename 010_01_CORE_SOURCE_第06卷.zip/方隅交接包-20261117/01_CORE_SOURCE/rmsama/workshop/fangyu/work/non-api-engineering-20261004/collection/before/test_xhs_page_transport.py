"""Synthetic loopback IPC only; no browser, account data, or platform requests."""

import json
import os
import subprocess
import sys
import tempfile
import threading
import time
import unittest
import urllib.error
import urllib.request
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from xhs_page_transport import PageTransportError, XhsPageTransport
from xhs_page_window import load_spec

ACCOUNT_A = "a" * 32
ACCOUNT_B = "b" * 32


FAKE_HELPER = r'''
import json,sys,time,urllib.request,urllib.error
from pathlib import Path
spec=json.loads(Path(sys.argv[1]).read_text('utf-8'))
mode=sys.argv[2]
if mode=='never_connect':
    time.sleep(.2)
    sys.exit(0)
def post(path,body):
    data=json.dumps(body).encode()
    req=urllib.request.Request(spec['endpoint']+path,data=data,headers={'Content-Type':'application/json'})
    try:
        with urllib.request.urlopen(req,timeout=3) as res:return json.load(res)
    except urllib.error.HTTPError as err:return json.load(err)
epoch=1
connected=post('/connect',{'secret':spec['bootstrap_secret'],'tenant_id':spec['tenant_id'],'account_id':spec['account_id'],'bound_uid':spec['bound_uid'],'doc_epoch':epoch})
if not connected.get('ok'):sys.exit(2)
session=connected['session_token']
while True:
    command=post('/poll',{'session_token':session,'doc_epoch':epoch})
    action=command.get('action')
    if action=='stop' or Path(spec['cancel_file']).exists():break
    if action in ('idle','hold'):
        time.sleep(.005)
        continue
    if action=='status':
        uid='other-uid' if mode=='wrong_uid' else spec['bound_uid']
        if mode=='guest_uid':envelope={'code':0,'success':True,'data':{'user_id':uid,'guest':True}}
        elif mode=='not_auth':envelope={'status':401,'data':{'code':-100,'success':False,'data':{}}}
        elif mode=='status_verification':envelope={'status':461,'data':{'code':-461,'success':False}}
        elif mode=='basic_uid':envelope={'status':200,'data':{'code':0,'success':True,'data':{'basic_info':{'user_id':uid}}}}
        elif mode=='top_uid':envelope={'user_id':uid}
        else:envelope={'status':200,'data':{'code':0,'success':True,'data':{'user_id':uid}}}
    elif action=='search':
        if mode=='page_unavailable':envelope={'_page_error':'page_client_unavailable'}
        else:envelope={'code':0,'success':True,'data':{'items':[],'has_more':False,'request_page':command['params']['page']}}
    else:
        if mode=='late':time.sleep(.2)
        envelope={'code':0,'success':True,'data':{'comments':[],'has_more':False,'cursor':'','echo':command['params']}}
    if mode=='natural':
        task_epoch=command['task_epoch']
        route='home' if action=='status' else 'search' if action=='search' else 'note'
        context={'session_token':session,'doc_epoch':epoch,'call_id':command['call_id'],
                 'task_epoch':task_epoch}
        if not post('/begin_navigation',{**context,'route_kind':route}).get('ok'):sys.exit(3)
        if not post('/invalidate',context).get('ok'):sys.exit(4)
        if not post('/rebind',{'session_token':session,'old_epoch':epoch,'new_epoch':epoch+1,
                               'call_id':command['call_id'],'task_epoch':task_epoch}).get('ok'):sys.exit(5)
        epoch+=1
        identity={'code':0,'data':{'basic_info':{'user_id':spec['bound_uid'],'guest':False}}}
        if not post('/identity',{**context,'doc_epoch':epoch,'envelope':identity}).get('ok'):sys.exit(6)
        if action=='status':envelope['data']['data']['guest']=False
        if not post('/result',{**context,'doc_epoch':epoch,'envelope':envelope}).get('ok'):sys.exit(7)
    else:
        post('/result',{'session_token':session,'doc_epoch':epoch,'call_id':command['call_id'],'envelope':envelope})
'''


def post(endpoint, path, body):
    data = json.dumps(body).encode()
    request = urllib.request.Request(endpoint + path, data=data, headers={"Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(request, timeout=2) as response:
            return json.load(response)
    except urllib.error.HTTPError as error:
        return json.load(error)


class PageTransportTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="xhs-page-ipc-test-")
        self.root = Path(self.temp.name)
        self.account = self.root / "accounts" / "tenant-A" / ACCOUNT_A
        self.account.mkdir(parents=True)
        self.live = []

    def tearDown(self):
        for transport in self.live:
            if transport.opened and not transport.closed:
                try:
                    transport.close(timeout=3)
                except PageTransportError:
                    pass
        self.temp.cleanup()

    def build(self, mode="normal", *, timeout=.5, account=None, account_id=ACCOUNT_A, uid="uid-A",
              natural_mode=False):
        def factory(spec_path):
            flags = subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0
            return subprocess.Popen([sys.executable, "-c", FAKE_HELPER, str(spec_path), mode],
                                    stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                                    stderr=subprocess.DEVNULL, creationflags=flags)
        timing = {"connect_timeout": 2}
        if timeout is not None:
            timing["call_timeout"] = timeout
        transport = XhsPageTransport(account or self.account, "tenant-A", account_id, uid,
                                     lambda _event, _scope: True, factory,
                                     natural_mode=natural_mode, **timing)
        self.live.append(transport)
        return transport

    def assert_code(self, code, function):
        with self.assertRaises(PageTransportError) as raised:
            function()
        self.assertEqual(raised.exception.code, code)

    def test_real_loopback_fake_helper_raw_pages_and_fixed_actions(self):
        transport = self.build()
        status = transport.open()
        parsed_spec = load_spec(transport.spec_path)
        self.assertEqual(parsed_spec.account_id, ACCOUNT_A)
        self.assertEqual(parsed_spec.endpoint, transport.server_endpoint)
        self.assertEqual(status["data"]["data"]["user_id"], "uid-A")
        search = transport.call("search", call_id="s1", keyword="合成", page=101)
        self.assertEqual(search["data"]["request_page"], 101)
        comments = transport.call("comments", call_id="c1", note_id="note-A", cursor="cur-A",
                                  source_token="synthetic-note-token", xsec_source="pc_search")
        self.assertEqual(comments["data"]["echo"], {"noteId": "note-A", "cursor": "cur-A", "token": "synthetic-note-token"})
        children = transport.call("sub_comments", call_id="r1", note_id="note-A", root_comment_id="root-A",
                                  source_token="synthetic-note-token", xsec_source="pc_search")
        self.assertEqual(children["data"]["echo"]["rootCommentId"], "root-A")
        self.assert_code("action_denied", lambda: transport.call("eval", call_id="bad"))
        self.assert_code("replay_denied", lambda: transport.call("search", call_id="s1", keyword="合成", page=101))
        self.assert_code("source_mismatch", lambda: transport.call("comments", call_id="c2", note_id="note-A",
                          source_token="different", xsec_source="pc_search"))
        transport.close()
        self.assertTrue(transport.closed)
        self.assertIsNotNone(transport.process.poll())

    def test_natural_real_loopback_fake_helper_migrates_same_call(self):
        transport = self.build('natural', natural_mode=True, timeout=2)
        status = transport.open()
        self.assertEqual(status['data']['data']['user_id'], 'uid-A')
        self.assertEqual(transport.state.doc_epoch, 2)
        search = transport.call('search', call_id='natural-search', keyword='合成', page=1)
        self.assertEqual(search['data']['request_page'], 1)
        self.assertEqual(transport.state.doc_epoch, 3)
        comments = transport.call('comments', call_id='natural-comment', note_id='note-A',
                                  source_token='synthetic-note-token', xsec_source='pc_search')
        self.assertEqual(comments['data']['comments'], [])
        self.assertEqual(comments['data']['echo']['source'], 'pc_search')
        self.assertEqual(transport.state.doc_epoch, 4)
        self.assert_code('replay_denied', lambda: transport.call(
            'search', call_id='natural-search', keyword='合成', page=1))
        transport.close(timeout=3)
        self.assertIsNotNone(transport.process.poll())

    def test_timeout_poison_retains_helper_until_real_exit(self):
        transport = self.build("late", timeout=.03)
        transport.open()
        self.assert_code("timeout", lambda: transport.call("comments", call_id="slow", note_id="note-A",
                         source_token="synthetic-note-token", xsec_source="pc_search"))
        self.assert_code("paused", lambda: transport.call("search", call_id="later", keyword="合成", page=1))
        self.assert_code("helper_alive", lambda: transport.close(timeout=.001))
        self.assertFalse(transport.closed)
        self.assertIsNone(transport.process.poll())
        transport.close(timeout=3)
        self.assertTrue(transport.closed)

    def test_default_call_budget_covers_synthetic_page_delay(self):
        transport = self.build("late", timeout=None)
        self.assertEqual(transport.call_timeout, 60.0)
        transport.open()
        result = transport.call("comments", call_id="slow-but-valid", note_id="note-A",
                                source_token="synthetic-note-token", xsec_source="pc_search")
        self.assertEqual(result["data"]["comments"], [])

    def test_wrong_uid_and_cross_account_session_are_rejected(self):
        bad = self.build("wrong_uid")
        self.assert_code("identity_mismatch", bad.open)
        self.assert_code("invalid_state", lambda: bad.call("search", call_id="s1", keyword="合成", page=1))
        bad.close()
        first = self.build()
        second_account = self.root / "accounts" / "tenant-A" / ACCOUNT_B
        second_account.mkdir()
        second = self.build(account=second_account, account_id=ACCOUNT_B, uid="uid-B")
        first.open()
        second.open()
        wrong = post(second.server_endpoint, "/poll", {"session_token": first.state.session_token,
                                                       "doc_epoch": second.state.doc_epoch})
        self.assertEqual(wrong["code"], "session_denied")
        wrong_epoch = post(first.server_endpoint, "/poll", {"session_token": first.state.session_token,
                                                             "doc_epoch": 999})
        self.assertEqual(wrong_epoch["code"], "document_changed")

    def test_status_accepts_only_real_user_id_paths_including_basic_info(self):
        basic = self.build("basic_uid")
        self.assertEqual(basic.open()["data"]["data"]["basic_info"]["user_id"], "uid-A")
        basic.close()
        top = self.build("top_uid")
        self.assertEqual(top.open()["user_id"], "uid-A")
        top.close()

    def test_guest_and_not_authenticated_status_are_fixed_rejections(self):
        guest = self.build("guest_uid")
        self.assert_code("not_authenticated", guest.open)
        guest.close()
        unauthorized = self.build("not_auth")
        self.assert_code("not_authenticated", unauthorized.open)
        unauthorized.close()

    def test_status_verification_holds_owned_helper_until_explicit_close(self):
        transport = self.build("status_verification")
        self.assert_code("verification_required", transport.open)
        self.assertTrue(transport.opened)
        self.assertFalse(transport.closed)
        self.assertIsNone(transport.process.poll())
        hold = post(transport.server_endpoint, "/poll", {
            "session_token": transport.state.session_token, "doc_epoch": transport.state.doc_epoch})
        self.assertEqual(hold["action"], "hold")
        self.assertEqual(hold["reason"], "verification_required")
        self.assert_code("paused", lambda: transport.call("search", call_id="after-verify", keyword="合成", page=1))
        transport.close(timeout=3)
        self.assertTrue(transport.closed)
        self.assertIsNotNone(transport.process.poll())

    def test_factory_failure_and_connect_timeout_release_or_remain_closable(self):
        def bad_factory(_spec_path):
            raise RuntimeError("private helper failure")
        failed = XhsPageTransport(self.account, "tenant-A", ACCOUNT_A, "uid-A",
                                  lambda _event, _context: True, bad_factory)
        self.assert_code("helper_start_failed", failed.open)
        self.assertFalse(failed.spec_path.exists())
        self.assertTrue(failed.closed)
        self.assertFalse(failed.job_dir.exists())
        waiting = self.build("never_connect", timeout=.05)
        waiting.connect_timeout = .02
        self.assert_code("connect_timeout", waiting.open)
        self.assertTrue(waiting.closed or waiting.opened)
        if not waiting.closed:
            waiting.close(timeout=2)
        self.assertFalse(waiting.spec_path.exists())

    def test_guard_context_and_fixed_finished_on_failure(self):
        seen = []
        transport = self.build()
        transport.guard = lambda event, context: seen.append((event, context)) or True
        transport.open()
        transport.call("search", call_id="search-1", keyword="合成", page=1)
        self.assert_code("action_denied", lambda: transport.call("eval", call_id="bad"))
        status_pairs = [(event, ctx) for event, ctx in seen if ctx.get("action") == "status"]
        self.assertTrue(any(event == "before_call" and ctx["call_id"] == "open" for event, ctx in status_pairs))
        self.assertTrue(any(event == "after_result" and ctx["call_id"] == "open" and ctx["outcome"] == "ok" for event, ctx in status_pairs))
        self.assertTrue(any(event == "before_call" and ctx["action"] == "search" and ctx["call_id"] == "search-1" for event, ctx in seen))
        self.assertTrue(any(event == "after_result" and ctx["action"] == "search" and ctx["call_id"] == "search-1" and ctx["outcome"] == "ok" for event, ctx in seen))
        transport.close()

    def test_before_network_page_failure_finishes_with_fixed_context(self):
        seen = []
        transport = self.build("page_unavailable")
        transport.guard = lambda event, context: seen.append((event, context)) or True
        transport.open()
        self.assert_code("page_client_unavailable", lambda: transport.call("search", call_id="search-fail",
                                                                          keyword="合成", page=1))
        finished = [ctx for event, ctx in seen if event == "after_result" and ctx["call_id"] == "search-fail"]
        self.assertEqual(len(finished), 1)
        self.assertEqual(finished[0]["code"], "page_client_unavailable")
        self.assertFalse(finished[0]["network_attempted"])

    def test_preflight_guard_rejection_does_not_write_orphan_finished(self):
        events = []
        transport = self.build()
        def guard(event, context):
            events.append((event, context["call_id"]))
            return not (event == "before_call" and context["call_id"] == "reject-me")
        transport.guard = guard
        transport.open()
        self.assert_code("guard_rejected", lambda: transport.call("search", call_id="reject-me", keyword="合成", page=1))
        self.assertIn(("before_call", "reject-me"), events)
        self.assertNotIn(("after_result", "reject-me"), events)

    def test_ipc_rejects_nonfinite_json(self):
        transport = self.build()
        transport.open()
        req = urllib.request.Request(transport.server_endpoint + "/poll", data=b'{"session_token":NaN,"doc_epoch":1}',
                                     headers={"Content-Type": "application/json"})
        with self.assertRaises(urllib.error.HTTPError) as raised:
            urllib.request.urlopen(req, timeout=2)
        self.assertEqual(json.load(raised.exception)["code"], "invalid_request")

    def test_old_document_result_cannot_complete_new_call(self):
        transport = self.build("late", timeout=1)
        transport.open()
        result = []
        worker = threading.Thread(target=lambda: self._capture(result, lambda: transport.call(
            "comments", call_id="old", note_id="note-A", source_token="synthetic-note-token",
            xsec_source="pc_search")))
        worker.start()
        until = time.monotonic() + 1
        while time.monotonic() < until:
            with transport.state.cv:
                if transport.state.pending and transport.state.pending["delivered"]:
                    break
            time.sleep(.005)
        invalidated = post(transport.server_endpoint, "/invalidate", {
            "session_token": transport.state.session_token, "doc_epoch": 1})
        self.assertTrue(invalidated["ok"])
        worker.join(timeout=2)
        self.assertEqual(result, ["document_changed"])
        rejected = post(transport.server_endpoint, "/rebind", {
            "session_token": transport.state.session_token, "old_epoch": 1, "new_epoch": 3})
        self.assertEqual(rejected["code"], "rebind_denied")

    def test_request_stop_unblocks_inflight_without_releasing_live_helper(self):
        transport = self.build("late", timeout=1)
        transport.open()
        result = []
        worker = threading.Thread(target=lambda: self._capture(result, lambda: transport.call(
            "comments", call_id="stop-call", note_id="note-A", source_token="synthetic-note-token",
            xsec_source="pc_search")))
        worker.start()
        until = time.monotonic() + 1
        while time.monotonic() < until:
            with transport.state.cv:
                if transport.state.pending and transport.state.pending["delivered"]:
                    break
            time.sleep(.005)
        self.assertEqual(transport.request_stop(), "requested")
        worker.join(timeout=.2)
        self.assertEqual(result, ["cancelled"])
        self.assertFalse(transport.closed)
        self.assertIsNone(transport.process.poll())
        transport.close(timeout=3)
        self.assertTrue(transport.closed)

    def test_request_stop_interrupts_connect_wait(self):
        transport = self.build("never_connect")
        outcome = []
        worker = threading.Thread(target=lambda: self._capture(outcome, transport.open))
        worker.start()
        until = time.monotonic() + 1
        while time.monotonic() < until and not transport.opened:
            time.sleep(.005)
        self.assertTrue(transport.opened)
        self.assertEqual(transport.request_stop(), "requested")
        worker.join(timeout=2)
        self.assertEqual(outcome, ["cancelled"])
        self.assertTrue(transport.closed or transport.state.poisoned)

    def natural_state(self, guard=None):
        class LiveProcess:
            @staticmethod
            def poll():
                return None
        transport = XhsPageTransport(
            self.account, 'tenant-A', ACCOUNT_A, 'uid-A',
            guard or (lambda _event, _context: True), lambda _spec: None,
            natural_mode=True, call_timeout=.5)
        transport.opened = True
        transport.process = LiveProcess()
        transport.state.connected = True
        transport.state.doc_epoch = 1
        transport.state.session_token = 'synthetic-native-session'
        return transport

    def test_current_natural_failure_during_navigation_settles_without_waiting_for_timeout(self):
        events=[]
        transport=self.natural_state(lambda event,context:events.append((event,context)) or True)
        outcome=[]
        worker=threading.Thread(target=lambda:self._capture(outcome,
            lambda:transport.call('status',call_id='navigation-failure')))
        worker.start();self.wait_pending(transport)
        auth={'session_token':transport.state.session_token,'doc_epoch':1}
        command=transport._ipc('/poll',auth)
        scope={**auth,'call_id':'navigation-failure','task_epoch':command['task_epoch']}
        transport._ipc('/begin_navigation',{**scope,'route_kind':'home'})
        transport._ipc('/invalidate',scope)
        self.assert_code('failure_denied',lambda:transport._ipc('/failure',{
            **scope,'task_epoch':command['task_epoch']+1,'code':'document_changed',
            'network_attempted':True}))
        transport._ipc('/failure',{**scope,'code':'document_changed','network_attempted':True})
        worker.join(timeout=.5)
        self.assertFalse(worker.is_alive())
        self.assertEqual(outcome,['document_changed'])
        finished=[context for event,context in events if event=='after_result']
        self.assertEqual(len(finished),1)
        self.assertTrue(transport.state.poisoned)

    @staticmethod
    def wait_pending(transport):
        until = time.monotonic() + 1
        while time.monotonic() < until:
            with transport.state.cv:
                if transport.state.pending is not None:
                    return
            time.sleep(.005)
        raise AssertionError('pending not observed')

    def test_planned_navigation_keeps_one_call_across_epoch_and_identity(self):
        events = []
        transport = self.natural_state(lambda event, context: events.append(
            (event, context['action'], context['call_id'])) or True)
        result = []
        worker = threading.Thread(target=lambda: result.append(transport.call(
            'status', call_id='natural-status')))
        worker.start()
        self.wait_pending(transport)
        auth = {'session_token': transport.state.session_token}
        command = transport._ipc('/poll', {**auth, 'doc_epoch': 1})
        self.assertEqual(command['call_id'], 'natural-status')
        task_epoch = command['task_epoch']
        nav = {**auth, 'doc_epoch': 1, 'call_id': 'natural-status',
               'task_epoch': task_epoch, 'route_kind': 'home'}
        transport._ipc('/begin_navigation', nav)
        transport._ipc('/invalidate', {**nav, 'doc_epoch': 1})
        self.assertEqual(transport._ipc('/rebind', {**auth, 'old_epoch': 1,
            'new_epoch': 2, 'call_id': 'natural-status', 'task_epoch': task_epoch}), {})
        profile = {'code': 0, 'data': {'basic_info': {'user_id': 'uid-A', 'guest': False}}}
        self.assert_code('result_denied', lambda: transport._ipc('/result', {
            **auth, 'doc_epoch': 2, 'call_id': 'natural-status',
            'task_epoch': task_epoch, 'envelope': profile}))
        transport._ipc('/identity', {**auth, 'doc_epoch': 2,
            'call_id': 'natural-status', 'task_epoch': task_epoch, 'envelope': profile})
        self.assert_code('document_changed', lambda: transport._ipc('/result', {
            **auth, 'doc_epoch': 1, 'call_id': 'natural-status',
            'task_epoch': task_epoch, 'envelope': profile}))
        transport._ipc('/result', {**auth, 'doc_epoch': 2,
            'call_id': 'natural-status', 'task_epoch': task_epoch, 'envelope': profile})
        self.assert_code('identity_denied', lambda: transport._ipc('/identity', {
            **auth, 'doc_epoch': 2, 'call_id': 'natural-status',
            'task_epoch': task_epoch, 'envelope': profile}))
        worker.join(timeout=1)
        self.assertFalse(worker.is_alive())
        self.assertEqual(result, [profile])
        self.assertEqual([name for name, _, _ in events].count('before_call'), 1)
        self.assertEqual([name for name, _, _ in events].count('after_result'), 1)
        self.assertTrue(transport.state.uid_verified)

    def test_unknown_navigation_and_stale_task_cannot_migrate(self):
        transport = self.natural_state()
        outcome = []
        worker = threading.Thread(target=lambda: self._capture(outcome, lambda: transport.call(
            'status', call_id='unexpected')))
        worker.start(); self.wait_pending(transport)
        auth = {'session_token': transport.state.session_token}
        command = transport._ipc('/poll', {**auth, 'doc_epoch': 1})
        self.assert_code('navigation_denied', lambda: transport._ipc('/begin_navigation', {
            **auth, 'doc_epoch': 1, 'call_id': 'unexpected',
            'task_epoch': command['task_epoch'], 'route_kind': 'note'}))
        self.assert_code('navigation_denied', lambda: transport._ipc('/begin_navigation', {
            **auth, 'doc_epoch': 1, 'call_id': 'unexpected',
            'task_epoch': command['task_epoch'] + 1, 'route_kind': 'home'}))
        transport._ipc('/invalidate', {**auth, 'doc_epoch': 1})
        self.assert_code('rebind_denied', lambda: transport._ipc('/rebind', {
            **auth, 'old_epoch': 1, 'new_epoch': 2, 'call_id': 'unexpected',
            'task_epoch': command['task_epoch']}))
        worker.join(timeout=1)
        self.assertEqual(outcome, ['document_changed'])
        self.assertTrue(transport.state.poisoned)

    def test_planned_navigation_wrong_identity_and_cancel_fail_closed(self):
        events = []
        transport = self.natural_state(lambda event, context: events.append(
            (event, dict(context))) or True)
        outcome = []
        worker = threading.Thread(target=lambda: self._capture(outcome, lambda: transport.call(
            'status', call_id='identity-fail')))
        worker.start(); self.wait_pending(transport)
        auth = {'session_token': transport.state.session_token}
        command = transport._ipc('/poll', {**auth, 'doc_epoch': 1})
        common = {**auth, 'call_id': 'identity-fail', 'task_epoch': command['task_epoch']}
        transport._ipc('/begin_navigation', {**common, 'doc_epoch': 1, 'route_kind': 'home'})
        transport._ipc('/invalidate', {**common, 'doc_epoch': 1})
        transport._ipc('/rebind', {**common, 'old_epoch': 1, 'new_epoch': 2})
        self.assert_code('identity_mismatch', lambda: transport._ipc('/identity', {
            **common, 'doc_epoch': 2, 'envelope': {'code': 0,
            'data': {'user_id': 'other-user', 'guest': False}}}))
        worker.join(timeout=1)
        self.assertEqual(outcome, ['identity_mismatch'])
        self.assertTrue(transport.state.poisoned)
        finished = [context for event, context in events if event == 'after_result']
        self.assertEqual(len(finished), 1)
        self.assertEqual(finished[0]['outcome'], 'identity_mismatch')
        self.assertTrue(finished[0]['network_attempted'])
        self.assert_code('paused', lambda: transport.call('status', call_id='again'))

        stopped = self.natural_state()
        stop_outcome = []
        stop_worker = threading.Thread(target=lambda: self._capture(stop_outcome,
            lambda: stopped.call('status', call_id='cancelled-natural')))
        stop_worker.start(); self.wait_pending(stopped)
        stopped.request_stop()
        stop_worker.join(timeout=1)
        self.assertEqual(stop_outcome, ['cancelled'])
        self.assertTrue(stopped.state.poisoned)

    def test_planned_navigation_guest_identity_and_stale_rebind_fail_closed(self):
        transport = self.natural_state()
        outcome = []
        worker = threading.Thread(target=lambda: self._capture(outcome, lambda: transport.call(
            'status', call_id='guest-natural')))
        worker.start(); self.wait_pending(transport)
        auth = {'session_token': transport.state.session_token}
        command = transport._ipc('/poll', {**auth, 'doc_epoch': 1})
        common = {**auth, 'call_id': 'guest-natural', 'task_epoch': command['task_epoch']}
        transport._ipc('/begin_navigation', {**common, 'doc_epoch': 1, 'route_kind': 'home'})
        self.assert_code('navigation_denied', lambda: transport._ipc('/begin_navigation', {
            **common, 'doc_epoch': 1, 'route_kind': 'home'}))
        transport._ipc('/invalidate', {**common, 'doc_epoch': 1})
        self.assert_code('rebind_denied', lambda: transport._ipc('/rebind', {
            **common, 'old_epoch': 1, 'new_epoch': 2, 'task_epoch': command['task_epoch'] + 1}))
        transport._ipc('/rebind', {**common, 'old_epoch': 1, 'new_epoch': 2})
        self.assert_code('not_authenticated', lambda: transport._ipc('/identity', {
            **common, 'doc_epoch': 2, 'envelope': {'code': 0,
            'data': {'user_id': 'uid-A', 'guest': True}}}))
        worker.join(timeout=1)
        self.assertEqual(outcome, ['not_authenticated'])
        self.assertTrue(transport.state.poisoned)

    def test_natural_identity_requires_explicit_false_guest_and_unique_uid(self):
        cases = (
            ({'code': 0, 'data': {'basic_info': {'user_id': 'uid-A'}}},
             'not_authenticated'),
            ({'code': 0, 'data': {'user_id': 'uid-A', 'guest': False,
                                'basic_info': {'user_id': 'other-user', 'guest': False}}},
             'identity_mismatch'),
            ({'code': 0, 'data': {'user_id': 'uid-A', 'guest': 'false'}},
             'not_authenticated'),
        )
        for index, (profile, expected) in enumerate(cases):
            with self.subTest(index=index):
                transport = self.natural_state()
                outcome = []
                worker = threading.Thread(target=lambda: self._capture(outcome,
                    lambda: transport.call('status', call_id='strict-natural')))
                worker.start(); self.wait_pending(transport)
                auth = {'session_token': transport.state.session_token}
                command = transport._ipc('/poll', {**auth, 'doc_epoch': 1})
                common = {**auth, 'call_id': 'strict-natural',
                          'task_epoch': command['task_epoch']}
                transport._ipc('/begin_navigation', {**common, 'doc_epoch': 1,
                                                      'route_kind': 'home'})
                transport._ipc('/invalidate', {**common, 'doc_epoch': 1})
                transport._ipc('/rebind', {**common, 'old_epoch': 1, 'new_epoch': 2})
                self.assert_code(expected, lambda: transport._ipc('/identity', {
                    **common, 'doc_epoch': 2, 'envelope': profile}))
                worker.join(timeout=1)
                self.assertFalse(worker.is_alive())
                self.assertEqual(outcome, [expected])
                self.assertTrue(transport.state.poisoned)

    def test_natural_status_result_cannot_replace_verified_identity(self):
        transport = self.natural_state()
        outcome = []
        worker = threading.Thread(target=lambda: self._capture(outcome,
            lambda: transport.call('status', call_id='swapped-status')))
        worker.start(); self.wait_pending(transport)
        auth = {'session_token': transport.state.session_token}
        command = transport._ipc('/poll', {**auth, 'doc_epoch': 1})
        common = {**auth, 'call_id': 'swapped-status',
                  'task_epoch': command['task_epoch']}
        transport._ipc('/begin_navigation', {**common, 'doc_epoch': 1,
                                              'route_kind': 'home'})
        transport._ipc('/invalidate', {**common, 'doc_epoch': 1})
        transport._ipc('/rebind', {**common, 'old_epoch': 1, 'new_epoch': 2})
        verified = {'code': 0, 'data': {'user_id': 'uid-A', 'guest': False}}
        transport._ipc('/identity', {**common, 'doc_epoch': 2, 'envelope': verified})
        transport._ipc('/result', {**common, 'doc_epoch': 2,
            'envelope': {'code': 0, 'data': {'user_id': 'uid-A'}}})
        worker.join(timeout=1)
        self.assertFalse(worker.is_alive())
        self.assertEqual(outcome, ['not_authenticated'])
        self.assertTrue(transport.state.poisoned)

    def test_planned_timeout_rejects_late_epoch_and_result(self):
        transport = self.natural_state()
        transport.call_timeout = .05
        outcome = []
        worker = threading.Thread(target=lambda: self._capture(outcome, lambda: transport.call(
            'status', call_id='slow-navigation')))
        worker.start(); self.wait_pending(transport)
        auth = {'session_token': transport.state.session_token}
        command = transport._ipc('/poll', {**auth, 'doc_epoch': 1})
        common = {**auth, 'call_id': 'slow-navigation',
                  'task_epoch': command['task_epoch']}
        transport._ipc('/begin_navigation', {**common, 'doc_epoch': 1,
                                              'route_kind': 'home'})
        transport._ipc('/invalidate', {**common, 'doc_epoch': 1})
        worker.join(timeout=1)
        self.assertEqual(outcome, ['timeout'])
        self.assertTrue(transport.state.poisoned)
        self.assert_code('rebind_denied', lambda: transport._ipc('/rebind', {
            **common, 'old_epoch': 1, 'new_epoch': 2}))
        self.assert_code('result_denied', lambda: transport._ipc('/result', {
            **common, 'doc_epoch': 1, 'envelope': {'user_id': 'uid-A'}}))

    @staticmethod
    def _capture(target, action):
        try:
            action()
        except PageTransportError as error:
            target.append(error.code)


if __name__ == "__main__":
    unittest.main()
