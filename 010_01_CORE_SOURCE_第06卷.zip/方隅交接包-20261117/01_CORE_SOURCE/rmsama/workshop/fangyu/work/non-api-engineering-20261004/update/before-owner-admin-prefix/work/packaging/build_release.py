"""Build the Fangyu customer assistant using the existing PyInstaller toolchain."""
from pathlib import Path
import datetime,hashlib,ipaddress,json,os,re,shutil,stat,subprocess,sys,zipfile
from urllib.parse import urlparse
from pathlib import PurePosixPath
PROJECT=Path(__file__).resolve().parents[2]
APP=PROJECT/'work/app';BUILD=PROJECT/'work/packaging';OUT=PROJECT/'outputs/正式交付'
sys.path.insert(0,str(APP/'src'))
from core.runtime_guards import cli_runtime_tree_sha256
from assistant.release import is_private_release_entry
PYTHON=PROJECT/'work/desktop-python/Scripts/python.exe'
NAME='方隅公寓本地助手';VERSION='1.1.7'
LAUNCHER='方隅助手启动器.exe';DISPLAY_NAME='方隅公寓工作台';RELEASE_SEQUENCE=1
RELEASE_BLOCK=BUILD/'RELEASE_BLOCKED.txt'
RELEASE_APPROVAL=BUILD/'RELEASE_APPROVED.json'
SHARED_LEADS_VERIFICATION=BUILD/'SHARED_LEADS_V2_VERIFIED.json'
SHARED_LEADS_DISABLED_VERIFICATION=BUILD/'SHARED_LEADS_DISABLED_VERIFIED.json'
SHARED_LEADS_DISABLED_SOURCES=('work/cloud/workspace/shared_feature.cjs',
                               'work/cloud/workspace/index.js','work/cloud/workspace/service.cjs',
                               'work/app/src/assistant/employee_workspace.py')
SHARED_LEADS_SOURCES=('work/cloud/workspace/shared_leads_v2.cjs','work/cloud/workspace/service.cjs',
                      'work/cloud/workspace/index.js','work/cloud/workspace/site/app.mjs',
                      'work/app/src/integrations.py','work/app/src/web/customer-workspace.js')
XHS_LICENSE=PROJECT/'work/licenses/Apache-2.0.txt'
XHS_LICENSE_SHA256='cfc7749b96f63bd31c3c42b5c471bf756814053e847c10f3eb003417bc523d30'
RELEASE_EVIDENCE=('cli_risk_accepted','real_xhs_flow_accepted','second_windows_pc_accepted',
                  'staff_ui_accepted','final_audit_accepted','production_cloud_accepted')
BUILD_MODULES=('PyInstaller','webview','pythonnet','clr_loader','PIL.Image',
               'cryptography','securesystemslib','tuf')

def validate_build_environment(python=None):
 """Import dependencies in the actual isolated compiler, not the test host."""
 executable=Path(PYTHON if python is None else python)
 if not executable.is_file():raise ValueError('客户项目 Python 构建依赖环境缺失')
 script=('import importlib,json,struct,sys\n'
         'modules='+repr(BUILD_MODULES)+'\n'
         'missing=[]\n'
         'for name in modules:\n'
         ' try: importlib.import_module(name)\n'
         ' except Exception: missing.append(name)\n'
         "print(json.dumps({'version':1,'windows_x64':sys.platform=='win32' and struct.calcsize('P')==8,"
         "'checked':list(modules),'missing':missing}))\n")
 try:
  child=subprocess.run([str(executable),'-I','-c',script],stdin=subprocess.DEVNULL,
        stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,encoding='utf-8',
        timeout=30,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
  if child.returncode!=0 or len(child.stdout)>8192:raise ValueError
  report=json.loads(child.stdout)
  if (not isinstance(report,dict) or type(report.get('version')) is not int
      or report['version']!=1 or report.get('windows_x64') is not True
      or report.get('checked')!=list(BUILD_MODULES) or not isinstance(report.get('missing'),list)
      or any(name not in BUILD_MODULES for name in report['missing'])):raise ValueError
 except (OSError,ValueError,subprocess.SubprocessError,UnicodeError):
  raise ValueError('客户项目 Python 构建依赖检查未通过') from None
 if report['missing']:raise ValueError('客户项目 Python 构建依赖缺失：'+', '.join(report['missing']))
 return report
def digest(path):
 h=hashlib.sha256()
 with path.open('rb') as source:
  for block in iter(lambda:source.read(1024*1024),b''):h.update(block)
 return h.hexdigest()
def validate_xhs_license(path=XHS_LICENSE):
 if not path.is_file() or digest(path)!=XHS_LICENSE_SHA256:
  raise ValueError('小红书 CLI 的 Apache-2.0 许可证正文缺失或与已核对版本不一致')
 return path
def stage_xhs_license(portable,license_path=XHS_LICENSE):
 source=validate_xhs_license(license_path)
 destination=portable/'第三方许可'
 destination.mkdir()
 shutil.copy2(source,destination/'Apache-2.0.txt')
 (destination/'小红书CLI来源说明.txt').write_text(
  '组件：xiaohongshu-cli 0.6.4\n'
  '来源：https://github.com/jackwener/xiaohongshu-cli\n'
  '上游声明许可证：Apache-2.0；许可证正文见同目录 Apache-2.0.txt。\n'
  '方隅客户端使用独立的 platform_cli.py 包装入口，限制请求重试、记录账号异常；没有修改此版本上游 Python 源文件。\n',
  encoding='utf-8')
def run(args,log):
 with (BUILD/log).open('w',encoding='utf-8') as stream:
  subprocess.run([str(a) for a in args],cwd=BUILD,stdout=stream,stderr=subprocess.STDOUT,check=True)
def audit_copy_source(source,allowed_root=APP):
 """Reject nested links and paths that resolve outside this customer's source."""
 base=allowed_root.resolve()
 def check(path):
  attributes=getattr(path.lstat(),'st_file_attributes',0)
  if path.is_symlink() or attributes&getattr(stat,'FILE_ATTRIBUTE_REPARSE_POINT',0):
   raise ValueError('Do not package links or junctions: '+str(path))
  if not path.resolve().is_relative_to(base):
   raise ValueError('Package source is outside customer project: '+str(path))
 check(source)
 if not source.is_dir():raise ValueError('Package source is not a directory: '+str(source))
 for directory,folders,files in os.walk(source,followlinks=False):
  for name in folders+files:check(Path(directory)/name)

def validate_release_config(config,strip_local_cli_paths=False):
 """Do not put credential-looking fields into the distributed company config."""
 def walk(value):
  if isinstance(value,dict):
   for key,item in value.items():
    compact=''.join(char for char in str(key).lower() if char.isalnum())
    if any(term in compact for term in ('password','passwd','cookie','secret','token','apikey','credential','authorization','session')):
     raise ValueError('Private configuration field cannot be packaged: '+str(key))
    walk(item)
  elif isinstance(value,list):
   for item in value:walk(item)
 sanitized=dict(config)
 if strip_local_cli_paths:sanitized.pop('localCliPaths',None)
 walk(sanitized)

def _formal_https_url(value,description):
 """Validate a fixed formal domain without performing any network action."""
 if not isinstance(value,str) or not value or value!=value.strip() or any(char.isspace() for char in value) or '\\' in value:
  raise ValueError(description+'必须使用正式 HTTPS 域名')
 try:
  parsed=urlparse(value)
  hostname=parsed.hostname
  parsed.port  # Reject malformed ports before returning the URL.
 except ValueError:
  raise ValueError(description+'必须使用正式 HTTPS 域名') from None
 if (parsed.scheme!='https' or not hostname or not parsed.netloc
     or parsed.username is not None or parsed.password is not None
     or '?' in value or '#' in value or '%' in parsed.netloc
     or hostname.endswith('.') or '.' not in hostname or hostname=='tcloudbase.com'
     or hostname.endswith('.tcloudbase.com') or hostname=='localhost'
     or hostname.endswith('.localhost') or hostname.endswith('.local')):
  raise ValueError(description+'必须使用正式 HTTPS 域名')
 try:ipaddress.ip_address(hostname)
 except ValueError:pass
 else:raise ValueError(description+'必须使用正式 HTTPS 域名')
 return value.rstrip('/')

def production_site_url(config):
 """An optional public site, when configured, needs its own formal domain."""
 value=config.get('publicSiteUrl')
 if not isinstance(value,str) or not value.strip():
  raise ValueError('正式网页自定义域名尚未配置')
 try:return _formal_https_url(value,'正式网页入口')
 except ValueError:raise ValueError('正式网页入口必须使用已验收的 HTTPS 自定义域名') from None

def production_workspace_endpoint(config):
 """The approved assistant API endpoint is independent of any public site."""
 managed=config.get('managedWorkspace')
 endpoint=managed.get('endpoint') if isinstance(managed,dict) else None
 return _formal_https_url(endpoint,'电脑助手 API 地址')

def release_company_config(source,ready=False):
 """Materialize an active client only after every preflight gate passed."""
 if ready is not True or (source.get('runtime') or {}).get('xiaohongshu_automation')!='hold':
  raise ValueError('未完成正式验收，不能生成启用小红书的客户端配置')
 if (source.get('id')!='fangyu-apartment-client' or source.get('edition')!='customer'
     or source.get('personalMode') is not False or source.get('authMode')!='managed'
     or set(source.get('platforms') or [])!={'xiaohongshu'}):
  raise ValueError('正式客户配置必须保持方隅企业身份、托管登录和小红书首版范围')
 production_workspace_endpoint(source)
 if 'publicSiteUrl' in source:production_site_url(source)
 config=json.loads(json.dumps(source))
 config.pop('localCliPaths',None)
 config.pop('updateFeed',None)
 config['dataNotice']='本企业专属客户端；员工使用管理员分配的账号登录。平台账号在本机单独连接。'
 sequence=source.get('releaseSequence',RELEASE_SEQUENCE)
 if type(sequence) is not int or sequence<1:raise ValueError('正式发布序号必须为正整数')
 config['releaseVersion']=VERSION
 config['releaseSequence']=sequence
 config.setdefault('runtime',{}).pop('platform_qa_device_id',None)
 config['runtime']['executable']=NAME+'.exe'
 config['runtime']['role']='local_assistant_only'
 config['runtime']['ui_entry']='employee_workspace'
 config['runtime']['xiaohongshu_read_transport']='natural_page_v1'
 config['runtime']['cli_source_sha256']=digest(APP/'src/platform_cli.py')
 config['runtime']['xiaohongshu_automation']='enabled'
 config['runtime']['release_approved']=True
 return config

def release_launch_instructions(config):
 """Build the employee-facing instructions from the approved release config."""
 runtime=config.get('runtime') or {}
 if (config.get('id')!='fangyu-apartment-client' or runtime.get('role')!='local_assistant_only'
     or runtime.get('ui_entry')!='employee_workspace' or runtime.get('release_approved') is not True):
  raise ValueError('只有已批准的方隅单窗口包才能生成员工启动说明')
 production_workspace_endpoint(config)
 if 'publicSiteUrl' in config:production_site_url(config)
 return (f'双击 {LAUNCHER}，或使用桌面的方隅公寓工作台快捷方式。员工在同一个窗口登录、准备采集任务、连接平台账号并处理回复草稿。\n'
         '首次使用由管理员提供员工账号；平台账号、Cookie 和客户数据不会随包提供。\n'
         '页面若提示账号安全暂停，请按页面提示处理，不要重复扫码或恢复采集。\n'
         '需要 Windows 10/11 x64 及 .NET Framework 4.6.2 以上。内附微软 WebView2 离线安装程序，安装器在缺少运行时时自动准备；便携版可从 prerequisites 手动安装。\n'
         '软件数据独立存放于 %LOCALAPPDATA%/fangyu-apartment-clientAssistant；升级程序不覆盖该目录。\n'
         f'可替换图片和文案见 releases/{config["releaseSequence"]}/客户定制/先看这里.md。升级保留企业资料、自定规则和客户定制目录；平台范围与登录权限以新版为准。\n'
         '此包未购买代码签名证书，系统可能提示未知发布者；微软附带运行时已校验微软签名。\n')

def stage_managed_layout(flat,launcher,config,release_sequence=None):
 """Turn an approved flat app bundle into a fixed-launcher install tree."""
 flat=Path(flat);launcher=Path(launcher)
 if release_sequence is None:release_sequence=config.get('releaseSequence')
 runtime=config.get('runtime') or {}
 base=flat.resolve()
 def checked(path):
  attributes=getattr(path.lstat(),'st_file_attributes',0)
  if path.is_symlink() or attributes&getattr(stat,'FILE_ATTRIBUTE_REPARSE_POINT',0):
   raise ValueError('受控安装源不能包含链接或重解析点')
  if not path.resolve().is_relative_to(base):
   raise ValueError('受控安装源越界')
 if not flat.is_dir():raise ValueError('受控安装源目录不存在')
 checked(flat)
 for parent,folders,files in os.walk(flat,followlinks=False):
  for name in folders+files:checked(Path(parent)/name)
 if launcher.is_symlink() or getattr(launcher.lstat(),'st_file_attributes',0)&getattr(stat,'FILE_ATTRIBUTE_REPARSE_POINT',0):
  raise ValueError('固定启动器不能是链接或重解析点')
 if launcher.resolve().is_relative_to(base):raise ValueError('固定启动器不能位于待搬移的应用目录')
 if (config.get('id')!='fangyu-apartment-client' or runtime.get('executable')!=NAME+'.exe'
     or runtime.get('ui_entry')!='employee_workspace' or runtime.get('role')!='local_assistant_only'
     or runtime.get('release_approved') is not True or type(release_sequence) is not int
     or release_sequence<1 or config.get('releaseSequence')!=release_sequence):
  raise ValueError('受控安装布局需要已批准且发布序号一致的方隅工作台')
 if not (flat/runtime['executable']).is_file() or not (flat/'company.json').is_file() or not launcher.is_file():
  raise ValueError('受控安装缺少客户程序、企业配置或固定启动器')
 if json.loads((flat/'company.json').read_text('utf-8-sig'))!=config:
  raise ValueError('待装配企业配置与正式发布配置不一致')
 if any((flat/name).exists() for name in ('releases','installation.json','active.json',LAUNCHER)):
  raise ValueError('待装配目录已包含固定启动器状态')
 release=base/'releases'/str(release_sequence)
 if not release.resolve().is_relative_to(base):raise ValueError('受控安装目标越界')
 release.mkdir(parents=True)
 for item in tuple(flat.iterdir()):
  if item.name not in ('releases','prerequisites','启动与升级说明.txt'):
   target=release/item.name
   if not target.resolve().is_relative_to(base):raise ValueError('受控安装目标越界')
   shutil.move(str(item),str(target))
 shutil.copy2(launcher,flat/LAUNCHER)
 (flat/'company.json').write_text(json.dumps(config,ensure_ascii=False,indent=2),'utf-8')
 (flat/'installation.json').write_text(json.dumps({'company_id':config['id'],
      'executable':runtime['executable'],'launcher':LAUNCHER},ensure_ascii=False,indent=2),'utf-8')
 (flat/'active.json').write_text(json.dumps({'release':release_sequence,'previous':None},ensure_ascii=False,indent=2),'utf-8')
 # update-config.json is intentionally absent until an approved signed feed exists.
 return release

def validate_update_feed_source(feed):
 """Verify only public feed metadata before copying its trust root."""
 if feed is None:return None
 if not isinstance(feed,dict):raise ValueError('更新源配置必须是公开字段对象')
 if feed.get('enabled') is not True:return None
 if set(feed)-{'enabled','metadata_url','targets_url','trusted_root','target','channel'}:
  raise ValueError('更新源只能包含已审核的公开字段')
 from assistant.updates import checked_url
 from tuf.api.metadata import Metadata,Root
 checked_url(feed.get('metadata_url'))
 checked_url(feed.get('targets_url'))
 target=feed.get('target')
 path=PurePosixPath(target) if isinstance(target,str) else None
 if (not path or path.is_absolute() or '..' in path.parts or '\\' in target
     or ':' in target or not target.endswith('.zip')):
  raise ValueError('更新目标路径无效')
 if feed.get('channel','stable')!='stable':raise ValueError('方隅首版仅允许稳定更新通道')
 source=Path(feed.get('trusted_root',''))
 if not source.is_file() or source.is_symlink() or getattr(source.lstat(),'st_file_attributes',0)&getattr(stat,'FILE_ATTRIBUTE_REPARSE_POINT',0):
  raise ValueError('公开TUF根元数据缺失或为链接')
 if source.stat().st_size>1024*1024:raise ValueError('公开TUF根元数据过大')
 try:
  metadata=Metadata.from_file(str(source))
  if not isinstance(metadata.signed,Root):raise ValueError('不是TUF根元数据')
  metadata.signed.verify_delegate('root',metadata.signed_bytes,metadata.signatures)
  if metadata.signed.expires<=datetime.datetime.now(datetime.timezone.utc):
   raise ValueError('TUF根元数据已过期')
 except Exception as error:raise ValueError('公开TUF根元数据验签或有效期失败') from error
 return source

def stage_update_policy(install_root,feed):
 """Copy a verified public trust root into a portable install."""
 source=validate_update_feed_source(feed)
 if source is None:return None
 install_root=Path(install_root).resolve()
 if source.resolve().is_relative_to(install_root):raise ValueError('公开TUF根元数据不能取自待发布目录')
 trusted=install_root/'update-trust'/'root.json'
 if trusted.parent.exists() or (install_root/'update-config.json').exists():
  raise ValueError('受控安装更新策略目标已存在')
 public={key:value for key,value in feed.items() if key!='trusted_root'}
 public['trusted_root']='update-trust/root.json'
 trusted.parent.mkdir()
 shutil.copyfile(source,trusted)
 (install_root/'update-config.json').write_text(json.dumps({'company_id':'fangyu-apartment-client',
  'updateFeed':public},ensure_ascii=False,indent=2),'utf-8')
 return trusted

def validate_customization_source(source,allowed_root=APP):
 audit_copy_source(source,allowed_root)
 expected={'全部素材槽位.json','素材映射.json','文案.json','先看这里.md','主题.json','图片'}
 if {item.name for item in source.iterdir()}!=expected:
  raise ValueError('Customer customization contains unreviewed files')
 images=source/'图片'
 if not images.is_dir():raise ValueError('Customer image folder is missing')
 for item in images.iterdir():
  if not item.is_file() or item.suffix.lower() not in ('.png','.jpg','.jpeg','.webp','.gif') or item.stat().st_size>20*1024*1024:
   raise ValueError('Customer customization contains an unreviewed image: '+str(item))
 for name in ('全部素材槽位.json','素材映射.json','文案.json','主题.json'):
  validate_release_config(json.loads((source/name).read_text('utf-8-sig')))

def validate_bundled_sources(app=APP):
 """PyInstaller copies these whole folders; check them before starting a build."""
 forbidden={'cookies.json','credentials.json','config.local.json','storage_state.json',
            'session.json','workspace.sqlite3','.env','instance.lock'}
 for relative in ('src/web','src/resources'):
  source=app/relative
  audit_copy_source(source,app)
  for path in source.rglob('*'):
   if any(part.lower() in ('private','owner-admin') for part in path.relative_to(source).parts):
    raise ValueError('Private maintenance folder cannot be bundled: '+str(path))
   if path.is_file() and (path.name.lower() in forbidden or path.suffix.lower() in ('.sqlite','.sqlite3','.db','.pem','.pfx','.key','.dpapi')):
    raise ValueError('Private file cannot be bundled: '+str(path))
 for relative in ('src/resources/adapters/xiaohongshu.json','src/resources/companies/apartment.json'):
  validate_release_config(json.loads((app/relative).read_text('utf-8-sig')))

def validate_private_payload(folder):
 """Check assembled bytes before ZIP creation, independent of input audits."""
 for path in Path(folder).rglob('*'):
  if is_private_release_entry(path.relative_to(folder).as_posix()):
   raise ValueError('Maintainer private state cannot enter employee payload: '+str(path))

def validate_runtime_payload(source,allowed_root=APP):
 audit_copy_source(source,allowed_root)
 forbidden={'cookies.json','credentials.json','config.local.json','storage_state.json',
            'session.json','workspace.sqlite3','.env','instance.lock','running.json'}
 public_vendor_files={

  '_internal/certifi/cacert.pem':'9cc2a774b5198dcff14d9be1e66091f538975d867ce029a96bce15a55dfd730f'}
 for path in source.rglob('*'):
  if not path.is_file():continue
  relative=path.relative_to(source).as_posix().lower()
  if source.name=='platform-cli-guarded' and relative.startswith(('_internal/camoufox/','_internal/playwright/','_internal/browserforge/','_internal/browser_cookie3/','_internal/weibo_cli/')):
   raise ValueError('小红书首版运行库含未审查的浏览器辅助或其他平台模块：'+relative)
  if source.name=='platform-cli-guarded' and relative in public_vendor_files:
   if digest(path)!=public_vendor_files[relative]:raise ValueError('Bundled vendor data hash changed: '+relative)
   continue
  if path.name.lower() in forbidden or path.suffix.lower() in ('.sqlite','.sqlite3','.db','.pem','.pfx','.key','.dpapi'):
   raise ValueError('Private runtime file cannot be packaged: '+relative)

def validate_guarded_cli_runtime(source,source_file=APP/'src/platform_cli.py',purpose='release_verified'):
 """Require a build of the current all-request safety entrypoint, not an older write-only guard."""
 executable=source/'platform-cli.exe';marker=source/'guard-manifest.json'
 try:guard=json.loads(marker.read_text('utf-8'))
 except (OSError,ValueError):raise ValueError('小红书 CLI 缺少可验证的防护清单') from None
 if isinstance(guard,dict) and purpose=='release_verified' and guard.get('purpose')=='internal_qa_only':
  raise ValueError('小红书 CLI 已接入内部 QA 运行库，尚未完成正式验收与发布冻结')
 if (not isinstance(guard,dict) or guard.get('request_transport')!='single_attempt_all'
     or guard.get('activity_recording')!='account_local_v1'
     or guard.get('risk_stop')!='review_required'
     or guard.get('purpose')!=purpose
     or guard.get('automatic_action_replay') is not False
     or not executable.is_file() or not source_file.is_file()
     or guard.get('exe_sha256')!=digest(executable)
     or guard.get('runtime_tree_sha256')!=cli_runtime_tree_sha256(source)
     or guard.get('source_sha256')!=digest(source_file)):
  raise ValueError('小红书 CLI 运行库仍是旧版或防护能力与当前源码不一致')

def validate_release_approval(path=RELEASE_APPROVAL,project=PROJECT):
 """Require current, local evidence for every final business sign-off."""
 try:approval=json.loads(path.read_text('utf-8'))
 except (OSError,ValueError):raise ValueError('正式业务验收与用户认可记录尚未提交') from None
 if (not isinstance(approval,dict) or approval.get('company_id')!='fangyu-apartment-client'
     or approval.get('platforms')!=['xiaohongshu'] or not isinstance(approval.get('evidence'),dict)):
  raise ValueError('正式放行记录的企业或平台范围不正确')
 root=project.resolve()
 for gate in RELEASE_EVIDENCE:
  entry=approval['evidence'].get(gate)
  if not isinstance(entry,dict) or entry.get('accepted') is not True:
   raise ValueError('正式放行记录缺少验收项：'+gate)
  relative=entry.get('path');expected=entry.get('sha256')
  if not isinstance(relative,str) or not relative or not isinstance(expected,str) or len(expected)!=64:
   raise ValueError('正式放行证据路径或哈希无效：'+gate)
  candidate=(root/relative).resolve()
  if not candidate.is_relative_to(root) or not candidate.is_file() or digest(candidate)!=expected:
   raise ValueError('正式放行证据缺失或内容已改变：'+gate)
 return approval

def validate_shared_leads_v2_proof(path=SHARED_LEADS_VERIFICATION,project=PROJECT):
 """Require real-cloud migration and both-client evidence for the current candidate."""
 try:proof=json.loads(path.read_text('utf-8'))
 except (OSError,ValueError):raise ValueError('共享清单分记录迁移、索引与真实云端分页尚未验收') from None
 if (not isinstance(proof,dict) or proof.get('company_id')!='fangyu-apartment-client'
     or proof.get('schema')!='shared-leads-v2' or proof.get('collection')!='fangyu_shared_leads'
     or proof.get('index')!=['companyId','sequence']
     or any(proof.get(gate) is not True for gate in ('production_cloud_verified','migration_verified','two_clients_verified'))
     or type(proof.get('migrated_count')) is not int or proof['migrated_count']<0):
  raise ValueError('共享清单分记录正式验收记录不完整')
 root=project.resolve();evidence=proof.get('evidence')
 if not isinstance(evidence,dict):evidence={}
 relative=evidence.get('path');expected=evidence.get('sha256')
 if not isinstance(relative,str) or not relative.startswith('outputs/产品审计/') or not isinstance(expected,str) or len(expected)!=64:
  raise ValueError('共享清单分记录验收证据路径或哈希无效')
 candidate=(root/relative).resolve()
 if not candidate.is_relative_to(root) or not candidate.is_file() or digest(candidate)!=expected:
  raise ValueError('共享清单分记录验收证据缺失或内容已改变')
 sources=proof.get('source_sha256')
 if not isinstance(sources,dict) or set(sources)!=set(SHARED_LEADS_SOURCES):
  raise ValueError('共享清单分记录候选源码清单不完整')
 for relative in SHARED_LEADS_SOURCES:
  source=root/relative
  if not source.is_file() or digest(source)!=sources[relative]:
   raise ValueError('共享清单分记录候选源码已变化：'+relative)
 return proof


def shared_leads_release_route(project=PROJECT):
 """Choose only an explicit flag and a wired runtime; never execute JS source."""
 root=Path(project).resolve()
 try:
  flag=(root/SHARED_LEADS_DISABLED_SOURCES[0]).read_text('utf-8')
  index=(root/SHARED_LEADS_DISABLED_SOURCES[1]).read_text('utf-8')
 except OSError:
  raise ValueError('共享功能发布开关或云端入口缺失') from None
 match=re.fullmatch(r"\s*(?:/\*[^*]*\*/\s*)?const\s+SHARED_FEATURE_ENABLED\s*=\s*(false|true)\s*;\s*module\.exports\s*=\s*\{\s*SHARED_FEATURE_ENABLED\s*\}\s*;\s*",flag)
 if not match:raise ValueError('共享功能发布开关未知或格式不受控')
 if (index.count("require('./shared_feature.cjs')")!=1
     or not re.search(r"const\s*\{\s*SHARED_FEATURE_ENABLED\s*\}\s*=\s*require\('./shared_feature\.cjs'\)",index)
     or index.count('createService({')!=1
     or not re.search(r"function\s+getService\(\)\s*\{[\s\S]*?service\s*=\s*createService\(\{[\s\S]*?sharedFeatureEnabled:\s*SHARED_FEATURE_ENABLED\s*\}\)",index)):
  raise ValueError('共享功能开关没有接入云端正式入口')
 if match.group(1)=='true':return 'enabled'
 try:
  service=(root/SHARED_LEADS_DISABLED_SOURCES[2]).read_text('utf-8')
  gateway=(root/SHARED_LEADS_DISABLED_SOURCES[3]).read_text('utf-8')
 except OSError:
  raise ValueError('共享关闭路线缺少云端或本机网关源码') from None
 cloud_guard=re.search(r"if\s*\(!sharedFeatureEnabled\s*&&\s*\(payload\.operation\s*===\s*'list'\s*\|\|\s*payload\.operation\s*===\s*'publish'\)\)\s*\{\s*return\s+finish\(423,\s*\{error:\s*'feature_disabled'\}\);?\s*\}",service)
 local_guard=re.search(r"if\s+operation\s+in\s*\('list',\s*'publish'\):\s*raise\s+WorkspaceError\('feature_disabled',\s*423\)",gateway)
 if (service.count("require('./shared_feature.cjs')")!=1 or
     not re.search(r"const\s*\{\s*SHARED_FEATURE_ENABLED\s*\}\s*=\s*require\('./shared_feature\.cjs'\)",service)
     or not re.search(r"sharedFeatureEnabled\s*=\s*SHARED_FEATURE_ENABLED",service)
     or cloud_guard is None or local_guard is None
     or cloud_guard.start()>service.find("if (payload.operation === 'list')")
     or local_guard.start()>gateway.find('return public(_cloud(server')):
  raise ValueError('共享关闭路线的云端或本机默认拒绝逻辑缺失')
 return 'disabled'

def validate_shared_leads_disabled_proof(path=SHARED_LEADS_DISABLED_VERIFICATION,project=PROJECT):
 """Bind real deployed denial and preserved data evidence to exact source files."""
 root=Path(project).resolve()
 try:proof=json.loads(Path(path).read_text('utf-8'))
 except (OSError,ValueError):raise ValueError('共享功能关闭的真实云端验收证明缺失') from None
 gates=('production_cloud_verified','authenticated_list_disabled','authenticated_publish_disabled',
        'existing_shared_data_preserved','local_leads_preserved','employee_gateway_verified')
 if (not isinstance(proof,dict) or set(proof)!={'company_id','schema',*gates,'evidence','source_sha256'}
     or proof.get('company_id')!='fangyu-apartment-client' or proof.get('schema')!='shared-leads-disabled-v1'
     or any(proof.get(gate) is not True for gate in gates)):
  raise ValueError('共享功能关闭正式验收记录不完整')
 evidence=proof.get('evidence')
 if not isinstance(evidence,dict) or set(evidence)!={'path','sha256'}:
  raise ValueError('共享功能关闭验收证据路径或哈希无效')
 relative=evidence['path'];expected=evidence['sha256']
 if (not isinstance(relative,str) or not relative.startswith('outputs/产品审计/')
     or '\\' in relative or '..' in PurePosixPath(relative).parts
     or not isinstance(expected,str) or not re.fullmatch('[0-9a-f]{64}',expected)):
  raise ValueError('共享功能关闭验收证据路径或哈希无效')
 candidate=(root/relative).resolve();allowed=(root/'outputs/产品审计').resolve()
 if not candidate.is_relative_to(allowed) or not candidate.is_file() or digest(candidate)!=expected:
  raise ValueError('共享功能关闭验收证据缺失或内容已改变')
 sources=proof.get('source_sha256')
 if not isinstance(sources,dict) or set(sources)!=set(SHARED_LEADS_DISABLED_SOURCES):
  raise ValueError('共享功能关闭候选源码清单不完整')
 for relative in SHARED_LEADS_DISABLED_SOURCES:
  source=root/relative;expected=sources[relative]
  if not isinstance(expected,str) or not re.fullmatch('[0-9a-f]{64}',expected):
   raise ValueError('共享功能关闭候选源码哈希无效：'+relative)
  if not source.is_file() or digest(source)!=expected:
   raise ValueError('共享功能关闭候选源码已变化：'+relative)
 return proof

def validate_shared_leads_release_proof(project=PROJECT,disabled_path=SHARED_LEADS_DISABLED_VERIFICATION,
                                        enabled_path=SHARED_LEADS_VERIFICATION):
 route=shared_leads_release_route(project)
 if route=='disabled':return validate_shared_leads_disabled_proof(disabled_path,project)
 return validate_shared_leads_v2_proof(enabled_path,project)

def copytree(source,destination):
 audit_copy_source(source)
 shutil.copytree(source,destination,ignore=shutil.ignore_patterns('__pycache__','*.pyc','.git','.env','*.log','.pytest_cache'))
def prune_customer_resources(portable):
 """Keep only the first-release platform and apartment rules in the staged payload."""
 base=portable.resolve()
 for relative,allowed in (
     ('_internal/resources/adapters',{'xiaohongshu.json'}),
     ('_internal/resources/companies',{'apartment.json'})):
  folder=(portable/relative).resolve()
  if not folder.is_relative_to(base) or not folder.is_dir():raise ValueError('Missing staged customer resources: '+relative)
  for item in folder.iterdir():
   if item.is_symlink() or not item.is_file():raise ValueError('Unexpected staged customer resource: '+str(item))
   if item.name not in allowed:item.unlink()
  if {item.name for item in folder.iterdir()}!=allowed:raise ValueError('Required customer resource is missing: '+relative)
def preflight():
 """Read-only checks; never create a release or modify the running assistant."""
 issues=[]
 config=json.loads((APP/'company.json').read_text('utf-8-sig'))
 try:validate_release_config(config,strip_local_cli_paths=True)
 except ValueError as error:issues.append(str(error))
 feed=config.get('updateFeed')
 if not isinstance(feed,dict) or feed.get('enabled') is not True:
  issues.append('正式包缺少已启用且受信的远程更新源')
 else:
  try:validate_update_feed_source(feed)
  except (ValueError,OSError,TypeError) as error:issues.append(str(error))
 try:production_workspace_endpoint(config)
 except ValueError as error:issues.append(str(error))
 if 'publicSiteUrl' in config:
  try:production_site_url(config)
  except ValueError as error:issues.append(str(error))
 platforms=set(config.get('platforms') or [])
 if platforms!={'xiaohongshu'}:issues.append('方隅首版只允许小红书平台')
 runtime=APP/'work/runtime'
 # The user selected the third-party Xiaohongshu CLI as a core candidate.
 # Keep release and platform-action holds until risk and product gates pass.
 needed=[]
 if 'xiaohongshu' in platforms:needed.append('platform-cli-guarded')
 if platforms&{'douyin','kuaishou'}:needed.append('douyin-bridge')
 if 'kuaishou' in platforms:needed.append('kuaishou-bridge')
 if 'wechat_channels' in platforms:needed.append('wechat-channels')
 if not PYTHON.is_file():issues.append('客户项目 Python 构建环境缺失')
 else:
  try:validate_build_environment()
  except ValueError as error:issues.append(str(error))
 if not (BUILD/'brand.ico').is_file():issues.append('客户图标缺失')
 for name in needed:
  if not (runtime/name).is_dir():issues.append('客户项目运行库缺失：'+name)
  else:
   try:validate_runtime_payload(runtime/name)
   except (OSError,ValueError) as error:issues.append(str(error))
 if 'platform-cli-guarded' in needed and (runtime/'platform-cli-guarded').is_dir():
  try:validate_guarded_cli_runtime(runtime/'platform-cli-guarded')
  except (OSError,ValueError) as error:issues.append(str(error))
 if 'xiaohongshu' in platforms:
  try:validate_xhs_license()
  except (OSError,ValueError) as error:issues.append(str(error))
 try:validate_customization_source(APP/'客户定制')
 except (OSError,ValueError) as error:issues.append(str(error))
 try:validate_bundled_sources()
 except (OSError,ValueError) as error:issues.append(str(error))
 try:validate_shared_leads_release_proof()
 except ValueError as error:issues.append(str(error))
 if (config.get('runtime') or {}).get('xiaohongshu_automation')!='hold':
  issues.append('客户源码必须保持小红书自动化暂停，正式启用只在验收后的安装包内生成')
 if 'wechat_channels' in platforms:
  wx=runtime/'wechat-channels';marker=wx/'workbench-loopback-build.json';binary=wx/'wx_channel.exe'
  try:
   approved=json.loads(marker.read_text('utf-8'))
   if approved.get('loopback_only') is not True or approved.get('exe_sha256')!=digest(binary):
    issues.append('视频号运行库未通过本地绑定校验，禁止分发')
  except (OSError,ValueError):issues.append('视频号运行库缺少可验证的本地绑定构建，禁止分发')
 prereq=BUILD/'prerequisites/MicrosoftEdgeWebView2RuntimeInstallerX64.exe'
 if not prereq.is_file():issues.append('客户项目 WebView2 离线安装程序缺失')
 powershells=list(dict.fromkeys(filter(None,[shutil.which('pwsh.exe'),shutil.which('powershell.exe')])))
 if not powershells:issues.append('缺少 PowerShell，无法验证 WebView2 签名')
 if prereq.is_file() and powershells:
  command="$s=Get-AuthenticodeSignature -LiteralPath '"+str(prereq).replace("'","''")+"';if($s.Status -ne 'Valid' -or $s.SignerCertificate.Subject -notmatch 'Microsoft Corporation'){exit 2}"
  if not any(subprocess.run([shell,'-NoProfile','-NonInteractive','-Command',command],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode==0 for shell in powershells):
   issues.append('WebView2 安装程序签名未能验证')
 technical_ready=not issues
 try:validate_release_approval()
 except ValueError as error:issues.append(str(error))
 if RELEASE_BLOCK.is_file():issues.append('正式打包暂停：'+str(RELEASE_BLOCK))
 return {'ready':not issues,'technical_ready':technical_ready,'platforms':sorted(platforms),'required_runtime':needed,'issues':issues}
def main():
 report=preflight()
 if '--preflight' in sys.argv:
  print(json.dumps(report,ensure_ascii=True,indent=2));return
 if not report['ready']:raise RuntimeError('构建预检未通过：'+'；'.join(report['issues']))
 tag=datetime.datetime.now().strftime('%Y%m%d_%H%M%S');release=OUT/(DISPLAY_NAME+'_'+VERSION+'_'+tag)
 portable=release/'便携客户端';installers=release/'安装包'
 portable.mkdir(parents=True);installers.mkdir()
 # No broad copy from work: only frozen code/resources, reviewed runtimes,
 # external customization defaults and a sanitized deployment config.
 base=[PYTHON,'-m','PyInstaller','--noconfirm','--clean','--distpath',BUILD/'dist','--workpath',BUILD/'pyinstaller','--specpath',BUILD]
 run(base+['--onedir','--windowed','--name',NAME,'--paths',APP/'src','--collect-all','webview','--collect-all','pythonnet','--collect-all','clr_loader','--collect-all','PIL','--add-data',str(APP/'src/web')+';web','--add-data',str(APP/'src/resources')+';resources','--icon',BUILD/'brand.ico',APP/'src/app.py'],'client-build.log')
 shutil.copytree(BUILD/'dist'/NAME,portable,dirs_exist_ok=True)
 for rel in ['_internal/resources/references']:
  item=(portable/rel).resolve()
  if portable.resolve() not in item.parents:raise ValueError('Invalid stage path')
  if item.is_dir():shutil.rmtree(item)
  elif item.exists():item.unlink()
 prune_customer_resources(portable)
 runtime=APP/'work/runtime'
 for name in report['required_runtime']:copytree(runtime/name,portable/name)
 if 'xiaohongshu' in report['platforms']:stage_xhs_license(portable)
 if (portable/'platform-cli').exists():
  raise ValueError('方隅客户包只能包含已审计的隔离版平台 CLI')
 validate_customization_source(APP/'客户定制')
 copytree(APP/'客户定制',portable/'客户定制')
 source_config=json.loads((APP/'company.json').read_text('utf-8-sig'))
 config=release_company_config(source_config,ready=report['ready'])
 (portable/'company.json').write_text(json.dumps(config,ensure_ascii=False,indent=2),'utf-8')
 prereq=BUILD/'prerequisites/MicrosoftEdgeWebView2RuntimeInstallerX64.exe'
 if not prereq.is_file():raise FileNotFoundError('Official WebView2 offline prerequisite missing')
 signature='Microsoft Corporation (verified Authenticode)'
 (portable/'prerequisites').mkdir();shutil.copy2(prereq,portable/'prerequisites'/prereq.name)
 (portable/'启动与升级说明.txt').write_text(release_launch_instructions(config),encoding='utf-8-sig')
 validate_private_payload(portable)
 update_zip=release/(DISPLAY_NAME+'_更新组件.zip')
 with zipfile.ZipFile(update_zip,'w',zipfile.ZIP_DEFLATED,compresslevel=5) as archive:
  for path in sorted(portable.rglob('*')):
   if path.is_file():archive.write(path,path.relative_to(portable).as_posix())
 with zipfile.ZipFile(update_zip) as archive:
  if archive.testzip():raise RuntimeError('Update component ZIP failed verification')
 sys.path.insert(0,str(PROJECT/'work/assistant'))
 from build_launcher import build_launcher
 stage_managed_layout(portable,build_launcher(),config)
 stage_update_policy(portable,source_config.get('updateFeed'))
 validate_private_payload(portable)
 files=[]
 for path in sorted(portable.rglob('*')):
  if not path.is_file():continue
  relative=path.relative_to(portable).as_posix()
  lowered=relative.lower()
  if path.name.lower() in ['cookies.json','config.local.json','storage_state.json','.env','running.json','instance.lock'] or (path.suffix.lower() in ['.sqlite','.sqlite3','.db']):
   raise ValueError('Unexpected private/runtime-state file in payload: '+relative)
  if path.is_symlink():raise ValueError('Symlink in payload')
  files.append({'path':relative,'bytes':path.stat().st_size,'sha256':digest(path)})
 manifest={'name':DISPLAY_NAME,'version':VERSION,'built_at':tag,'file_count':len(files),'payload_bytes':sum(f['bytes'] for f in files),'files':files,'private_data_included':False,'code_signed':False,'webview2':{'source':'https://go.microsoft.com/fwlink/?linkid=2124701','documentation':'https://learn.microsoft.com/microsoft-edge/webview2/concepts/distribution','signature':signature,'sha256':digest(prereq)},'system_prerequisites':['Windows 10/11 x64','.NET Framework 4.6.2+'],'bundled_dependencies':['Python/PyWebView/pythonnet frozen runtime',*report['required_runtime'],'Microsoft WebView2 Evergreen standalone x64']}
 (release/'离线依赖与文件清单.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),'utf-8')
 portable_zip=release/(DISPLAY_NAME+'_便携版.zip')
 with zipfile.ZipFile(portable_zip,'w',zipfile.ZIP_DEFLATED,compresslevel=5) as archive:
  for entry in files:archive.write(portable/entry['path'],entry['path'])
 with zipfile.ZipFile(portable_zip) as archive:
  if archive.testzip():raise RuntimeError('Portable ZIP failed verification')
 installer_name=DISPLAY_NAME+'_安装程序'
 run(base+['--onefile','--windowed','--name',installer_name,'--icon',BUILD/'brand.ico','--add-data',str(BUILD/'brand.ico')+';.',BUILD/'installer.py'],'installer-build.log')
 installer=installers/(installer_name+'.exe');shutil.copy2(BUILD/'dist'/(installer_name+'.exe'),installer)
 with installer.open('ab') as dest,portable_zip.open('rb') as source:shutil.copyfileobj(source,dest)
 with zipfile.ZipFile(installer) as archive:
  if archive.testzip():raise RuntimeError('Embedded installer ZIP failed verification')
 probe=BUILD/('payload-probe-'+tag+'.txt')
 subprocess.run([str(installer),'--verify-payload',str(probe)],check=True,timeout=180)
 if not probe.exists():raise RuntimeError('Frozen installer payload test did not finish')
 final={'release':str(release),'release_sequence':config['releaseSequence'],'portable':str(portable),'portable_zip':str(portable_zip),'update_zip':str(update_zip),'update_zip_sha256':digest(update_zip),'installer':str(installer),'installer_sha256':digest(installer),'portable_zip_sha256':digest(portable_zip),'file_count':len(files),'payload_integrity':'passed','installer_self_probe':probe.read_text('utf-8')}
 (release/'构建结果.json').write_text(json.dumps(final,ensure_ascii=False,indent=2),'utf-8')
 (BUILD/'candidate-release.json').write_text(json.dumps(final,ensure_ascii=False,indent=2),'utf-8')
 print(json.dumps(final,ensure_ascii=True),flush=True)
if __name__=='__main__':main()













