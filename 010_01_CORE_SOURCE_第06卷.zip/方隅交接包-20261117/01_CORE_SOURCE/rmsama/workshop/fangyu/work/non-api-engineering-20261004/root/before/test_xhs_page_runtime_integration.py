import sys
import tempfile
import threading
import time
import unittest
from pathlib import Path
from types import SimpleNamespace

SRC = Path(__file__).resolve().parents[1] / 'src'
sys.path.insert(0, str(SRC))

from assistant.xhs_page_runtime import _data, _request, XhsPageRuntime
from xhs_page_transport import PageTransportError
from core.adapters import Adapters, PageUnavailable
from core.store import Store
from core.engine import Core, CoreError
from core.page_errors import PageOperationFailure
from assistant.browser_login_service import start_browser_account_login


class PageEnvelopeContractTests(unittest.TestCase):
    def test_real_status_profile_is_preserved(self):
        for raw in (
            {'status': 200, 'data': {'success': True, 'data': {'user_id': 'uid1', 'nickname': 'Alice'}}},
            {'code': 0, 'success': True, 'data': {'user_id': 'uid1', 'nickname': 'Alice'}},
            {'user_id': 'uid1', 'nickname': 'Alice'},
            {'status': 200, 'data': {'data': {'user_id': 'uid1', 'basic_info': {'nickname': 'Alice'}}}},
        ):
            with self.subTest(raw=raw):
                result = _data(raw, 'status', 'uid1')['data']
                self.assertTrue(result['authenticated'])
                self.assertEqual(result['user']['id'], 'uid1')
                self.assertEqual(result['user']['nickname'], 'Alice')

    def test_search_shapes_and_page_flag(self):
        payload = {'items': [{'id': 'note1', 'note_card': {}}], 'has_more': True}
        for raw in ({'status': 200, 'data': {'success': True, 'data': payload}},
                    {'code': 0, 'success': True, 'data': payload}, payload):
            self.assertEqual(_data(raw, 'search', 'uid1')['data'], payload)
        with self.assertRaises(PageTransportError):
            _data({'status': 200, 'data': {'items': []}}, 'search', 'uid1')

    def test_rejected_result_never_maps_as_success(self):
        with self.assertRaises(PageTransportError):
            _data({'status': 200, 'data': {'success': False, 'data': {'items': [], 'has_more': False}}}, 'search', 'uid1')

    def test_fixed_comment_source_contract(self):
        action, params = _request(['comments',
            'https://www.xiaohongshu.com/explore/note1?xsec_token=token&xsec_source=pc_search', '--json'])
        self.assertEqual(action, 'comments')
        self.assertEqual(params['note_id'], 'note1')
        self.assertEqual(params['xsec_source'], 'pc_search')
        with self.assertRaises(ValueError):
            _request(['comments', 'https://www.xiaohongshu.com/explore/note1', '--json'])

    def test_search_token_round_trips_into_root_and_reply_pages(self):
        token = 'a+/= &b'
        mapped = Adapters.map_items({'data': {'items': [{'id': 'note1', 'xsec_token': token,
            'note_card': {'user': {}}}]}}, 'xhs_v1', 'xiaohongshu')
        url = mapped[0]['url']
        self.assertEqual(_request(['comments', url, '--json'])[1]['source_token'], token)
        adapter = Adapters(None)
        adapter.xhs_page_runtime = object()
        sent = []
        def fake_execute(_platform, args, *_a, **_kw):
            sent.append(args)
            return {'data': {'comments': [], 'has_more': False, 'cursor': ''}}
        adapter.execute = fake_execute
        self.assertEqual(adapter.sub_comments('xiaohongshu', {'note_url': url,
            'root_comment_id': 'root1', '_account_dir': 'unused'}), [])
        self.assertEqual(_request(sent[0])[1]['source_token'], token)
        self.assertEqual(_request(sent[0])[1]['xsec_source'], 'pc_search')


class _FakeTransport:
    instances = []
    next_error = ''
    close_error = ''

    def __init__(self, account_dir, tenant, account_id, uid, guard, helper_factory):
        self.guard = guard
        self.uid = uid
        self.calls = []
        self.closed = False
        self.__class__.instances.append(self)

    def open(self):
        if self.__class__.next_error:
            code = self.__class__.next_error
            self.__class__.next_error = ''
            raise PageTransportError(code)
        return {'status': 200, 'data': {'data': {'user_id': self.uid, 'nickname': 'Alice'}}}

    def call(self, action, **params):
        self.calls.append((action, params))
        if action == 'search':
            return {'status': 200, 'data': {'data': {'items': [], 'has_more': False}}}
        return {'status': 200, 'data': {'data': {'comments': [], 'has_more': False, 'cursor': ''}}}

    def close(self):
        if self.__class__.close_error:
            raise PageTransportError(self.__class__.close_error)
        self.closed = True

    def request_stop(self):
        return 'requested'


class _HangingTransport(_FakeTransport):
    started = threading.Event()
    stopped = threading.Event()

    def call(self, action, **params):
        self.calls.append((action, params))
        self.__class__.started.set()
        self.__class__.stopped.wait(2)
        raise PageTransportError('cancelled')

    def request_stop(self):
        self.__class__.stopped.set()
        return 'requested'


class PageRuntimeTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.store = Store(Path(self.tmp.name))
        self.root = self.store.directory / 'accounts' / 'tenant1' / 'account1'
        self.root.mkdir(parents=True)
        self.store.put('accounts', {'id': 'account1', 'tenant_id': 'tenant1', 'platform': 'xiaohongshu',
                                    'platform_uid': 'uid1', 'status': 'ready', 'requires_review': False})
        self.adapters = Adapters(None)
        self.core = SimpleNamespace(store=self.store, adapters=self.adapters,
                                    _platform_execution_guard=lambda _p: None)
        self.runtime = XhsPageRuntime(self.core, lambda _p: None, transport_factory=_FakeTransport,
                                      clock=lambda: 100.0, sleeper=lambda _t: None)
        self.adapters.xhs_page_runtime = self.runtime
        _FakeTransport.instances = []
        _FakeTransport.next_error = ''
        _FakeTransport.close_error = ''

    def test_read_route_is_persistent_and_no_cli_fallback(self):
        def forbidden(*_a, **_kw):
            self.fail('CLI fallback invoked')
        self.adapters._execute = forbidden
        result = self.adapters.execute('xiaohongshu', ['status', '--json'], self.root)
        self.assertEqual(result['data']['user']['nickname'], 'Alice')
        self.adapters.execute('xiaohongshu', ['search', '租房', '--json', '--page', '1'], self.root)
        self.assertEqual(len(_FakeTransport.instances), 1)
        self.assertEqual(_FakeTransport.instances[0].calls[0][0], 'search')
        with self.assertRaises(PageUnavailable):
            self.adapters.execute('xiaohongshu', ['reply', 'anything'], self.root)

    def test_natural_read_activity_is_not_a_fabricated_http_200(self):
        import json
        from core.account_safety import summarize_activity
        self.runtime.natural_mode = True
        context = {'action':'search','call_id':'natural-log-only'}
        self.assertTrue(self.runtime._guard(self.root,'before_call',context))
        self.assertTrue(self.runtime._guard(self.root,'after_result',{
            **context,'outcome':'ok','network_attempted':True}))
        path = self.root/'platform-activity.jsonl'
        records = [json.loads(line) for line in path.read_text(encoding='utf-8').splitlines()]
        self.assertEqual(records[-2]['method'],'BROWSER')
        self.assertEqual(records[-1]['status'],'page_read_complete')
        self.assertEqual(summarize_activity(path)['state'],'observe')

    def test_local_helper_error_keeps_saved_identity(self):
        _FakeTransport.next_error = 'page_client_unavailable'
        with self.assertRaises(PageUnavailable):
            self.adapters.execute('xiaohongshu', ['status', '--json'], self.root)
        account = self.store.get('accounts', 'account1')
        self.assertEqual(account['status'], 'ready')
        self.assertEqual(account['platform_uid'], 'uid1')

    def test_verification_page_stays_until_review_clears(self):
        _FakeTransport.next_error = 'verification_required'
        with self.assertRaises(Exception):
            self.runtime.execute(self.root, ['status', '--json'])
        first = _FakeTransport.instances[0]
        self.assertFalse(first.closed)
        account = self.store.get('accounts', 'account1')
        account['requires_review'] = True
        self.store.put('accounts', account)
        with self.assertRaises(Exception):
            self.runtime.execute(self.root, ['status', '--json'])
        self.assertFalse(first.closed)
        # The existing review gate is authoritative. Only the later explicit
        # request after that gate clears may close and reopen the old page.
        account['requires_review'] = False
        self.store.put('accounts', account)
        self.assertEqual(self.runtime.execute(self.root, ['status', '--json'])['data']['user']['id'], 'uid1')
        self.assertTrue(first.closed)

    def test_login_reservation_waits_for_real_helper_exit(self):
        self.runtime.execute(self.root, ['status', '--json'])
        _FakeTransport.close_error = 'helper_alive'
        with self.assertRaises(PageTransportError):
            self.runtime.begin_login(self.root)
        with self.assertRaises(Exception):
            self.runtime.execute(self.root, ['status', '--json'])
        _FakeTransport.close_error = ''
        # The failed reservation remains held; retry must prove real exit.
        reservation = self.runtime.begin_login(self.root)
        entry = self.runtime._entry(self.root)[1]
        self.assertIs(reservation, entry)
        self.runtime.finish_login(self.root, reservation)
        self.assertFalse(entry.login_reserved)

    def test_cancel_wakes_pending_call_before_profile_close(self):
        _HangingTransport.started.clear(); _HangingTransport.stopped.clear()
        self.runtime.transport_factory = _HangingTransport
        failures = []
        thread = threading.Thread(target=lambda: self._run_hanging(failures))
        thread.start()
        self.assertTrue(_HangingTransport.started.wait(1))
        started = time.monotonic()
        self.assertTrue(self.adapters.cancel('job1'))
        thread.join(1)
        self.assertFalse(thread.is_alive())
        self.assertLess(time.monotonic() - started, 1)
        self.assertEqual(len(_HangingTransport.instances[-1].calls), 1)
        self.assertEqual(failures, ['cancelled'])

    def _run_hanging(self, failures):
        try:
            self.adapters.execute('xiaohongshu', ['search', '租房', '--json', '--page', '1'], self.root, 'job1')
        except PageUnavailable as exc:
            failures.append(exc.code)

    def test_activity_before_network_failure_is_finished_without_risk(self):
        context = {'action': 'search', 'call_id': 'req1', 'outcome': '', 'network_attempted': False}
        self.assertTrue(self.runtime._guard(self.root, 'before_call', context))
        context.update(outcome='page_client_unavailable')
        self.assertTrue(self.runtime._guard(self.root, 'after_result', context))
        events = [(item['stage'], item.get('status')) for item in
                  ( __import__('json').loads(line) for line in
                    (self.root / 'platform-activity.jsonl').read_text('utf-8').splitlines())]
        self.assertEqual(events, [('started', None), ('finished', 'cancelled_before_send')])

    def test_account_check_local_helper_failure_preserves_binding(self):
        core = Core(Path(self.tmp.name) / 'check')
        core.store.put('tenants', {'id': 'tenant1', 'tenant_id': 'tenant1'})
        user = {'id': 'user1', 'tenant_id': 'tenant1', 'username': 'admin', 'role': 'admin'}
        core.store.put('users', user)
        core.store.put('accounts', {'id': 'account1', 'tenant_id': 'tenant1',
            'platform': 'xiaohongshu', 'platform_uid': 'uid1', 'status': 'ready'})
        core.store.put('tasks', {'id': 'task1', 'tenant_id': 'tenant1',
            'account_id': 'account1', 'status': 'paused', 'last_message': '旧断点'})
        core.adapters.manifest = lambda _p: {'status_args': ['status', '--json']}
        core.adapters.execute = lambda *_a, **_kw: (_ for _ in ()).throw(PageUnavailable('page_client_unavailable'))
        with self.assertRaises(PageOperationFailure) as caught:
            core.handle('account_check', {'id': 'account1'}, user)
        self.assertEqual(caught.exception.code,'page_client_unavailable')
        self.assertEqual(core.store.get('accounts', 'account1')['status'], 'ready')
        self.assertEqual(core.store.get('accounts', 'account1')['platform_uid'], 'uid1')
        self.assertEqual(core.store.get('tasks', 'task1')['last_message'], '旧断点')

    def test_browser_login_refuses_profile_while_page_helper_is_alive(self):
        core = Core(Path(self.tmp.name) / 'login')
        core.store.put('accounts', {'id': 'account1', 'tenant_id': 'tenant1',
            'platform': 'xiaohongshu', 'platform_uid': 'uid1', 'status': 'ready'})
        def still_alive(_root):
            raise PageTransportError('helper_alive')
        server = SimpleNamespace(core=core, company={'runtime': {}}, closing=False,
            job_lock=threading.Lock(), jobs={}, xhs_page_runtime=SimpleNamespace(begin_login=still_alive))
        service = SimpleNamespace(server=server, closed=False, state='online',
            _local_user=lambda: {'tenant_id': 'tenant1', 'id': 'user1', 'role': 'admin'})
        helper = SRC / 'assistant' / 'browser_login_window.py'
        with self.assertRaises(ValueError):
            start_browser_account_login(service, 'account1', helper)
        self.assertEqual(server.jobs, {})


if __name__ == '__main__':
    unittest.main()
