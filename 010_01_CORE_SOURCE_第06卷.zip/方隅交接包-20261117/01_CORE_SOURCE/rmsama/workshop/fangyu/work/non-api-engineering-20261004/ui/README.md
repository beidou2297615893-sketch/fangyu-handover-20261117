# 员工界面非 API 修复记录

范围：仅方隅公寓客户版员工采集、待处理界面的现有源码与对应云站点源码镜像。修改前文件保存在 `before/`；等待动效微调前的样式与测试另存 `before-waiting-motion/`。没有修改 OpenAI API 接入配置、部署文件、运行数据或其他客户实例。

## 已复现并修复

1. 持续任务进入 `waiting` 后，界面仍使用上一轮 `reading_comments` 阶段，旋转图标与扫描条继续播放；`running` 时如果还带有下一次读取时间，也会显示等待倒计时。现在 `waiting` 和 `queued` 使用真实任务状态，处理动效只在 `running` 播放，倒计时只在 `waiting` 显示。暂停与停止状态不再高亮旧阶段。
2. “按时间分组”的评论页原本沿意向排序后的首条评论排列分组，导致较早日期排在较新日期前。现在日期分组按评论日期从新到旧排列；无效日期显示“时间未提供”并置后。帖子与博主分组、高意向未处理优先的后端顺序没有改变。
3. 主审补充等待阶段仍需可见轻动效。现在只在 `waiting` 阶段的文字前显示低强度呼吸点，和 `running` 的读取扫描区分；`paused`、`failed`、`blocked` 不显示此动效。系统启用减少动态效果时，呼吸点保持静态。

两项均先增加离线用例并确认失败，修改后通过。新增用例的精确名称：

- `waiting collection shows its actual phase without a reading animation`
- `date groups follow comment dates instead of first high-intent row`
- `waiting has a gentle status cue distinct from reading and stops for reduced motion`

既有 `AI key stays blank, never enters localStorage; fields clear on success/error/dialog close; reduced motion has fallback` 用例中的样式选择器断言随处理态类名更新。

## 验证

最终命令：

```powershell
node --test 'C:\积木软件工坊\项目\方隅公寓客户版\work\cloud\workspace\enterprise-ui.test.cjs'
```

最终结果：34 项通过，0 项失败。源码与云站点镜像的三个文件逐字 SHA-256 一致；数值见 `evidence.json`。空列表权威清引用、保存未知结果门禁、账号复核与恢复、来源字段及高意向未处理顺序沿用已有实现与已有离线用例，本轮没有为这些路径制造额外改动。

未启动真实浏览器或原生客户端，未调用平台或付费 API，未部署，未做真实视觉截图或用户视觉验收。本结果只证明本轮源码与离线行为检查。
