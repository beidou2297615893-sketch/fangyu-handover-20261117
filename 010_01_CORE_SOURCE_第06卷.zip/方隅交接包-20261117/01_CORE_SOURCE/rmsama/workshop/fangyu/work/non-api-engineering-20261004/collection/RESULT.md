# 自然网页采集离线断点核验（2026-10-04）

## 范围和结果

- 只运行本地合成 fixture，没有启动 WebView、helper、平台请求、AI、云端或真实账号操作。
- 新增 `work/app/tests/test_natural_search_pipeline.py` 的代表性持久断点用例：自然搜索第一页/第二页、同帖主评两页、楼中楼两页、跨帖子、跨关键词。每批从已提交任务状态重建；楼中楼第二页首次模拟 `helper_exited`，确认已提交游标保持，下一次从同一游标继续。6 条合成结果均唯一，最终关键词索引为 2。
- `python -m unittest tests.test_natural_search_pipeline.NaturalSearchPipelineTests.test_saved_natural_range_replays_nested_cursor_then_crosses_posts_and_keywords -v`：1/1 通过。
- 设置 `PYTHONPATH=tests` 后运行自然搜索、worker 纵向与 page transport 的轻量测试：43/43 通过。直接按包运行这三组时已有测试的 `from test_natural_search_pipeline import row` 需要 tests 在 Python 搜索路径。

## 对 `helper_exited` 的判断

现有脱敏元数据只证明父层在楼中楼调用期间收到 `helper_exited`，没有子进程固定退出码或栈。上述合成错误可验证业务断点不前进且允许后续恢复；它不能证明子进程退出的原始原因，也不能证明真实网页楼中楼可稳定续读。

父层原来只保存通用 `helper_exited`，未保留子进程退出码以及 `/failure` 是否成功送达，属于可复现的诊断缺口。现于 `xhs_page_transport.py` 中保留固定白名单事实：`stage`、整数 `return_code`、`failure_received`、白名单 `failure_code`、整数 `doc_epoch`/`task_epoch`、固定 `phase`。同一份快照通过 `transport.last_failure_diagnostic` 和 `after_result` guard context 的 `diagnostic` 可读取。两项无 GUI fakeprocess 测试分别证明直接退出和成功收到结构化 `/failure` 的快照；修复前均因字段不存在而失败。未读取/记录子进程 stdout、平台内容、URL、Cookie、账号身份。现有 `assistant/xhs_page_runtime.py` 未把 context 中的 `diagnostic` 写入 activity，需主任务按白名单接线才能形成运行时留痕。

## 改动与边界

主任务后续接线已完成：`assistant/xhs_page_runtime.py` 的 after_result 与连接前退出记录按固定白名单写入 `page_diagnostic`。root临时库16项专项与44项合并检查通过；未重开用户运行中的Python后台，尚未取得真实运行诊断。此前“需主任务接线”描述为分工交付时状态，不是本轮最终代码状态。

- 修改 `work/app/src/xhs_page_transport.py`、`work/app/tests/test_natural_search_pipeline.py` 和 `work/app/tests/test_xhs_page_transport.py`，改动前备份在本目录 `before/`。
- 未修改其他客户、自用、工坊核心、运行数据或正式包。
- 如需继续定位真实 `helper_exited`，由主任务串行安排唯一 native 夹具，并把以上固定快照接入本地 activity；不得据本用例推断平台风控。
