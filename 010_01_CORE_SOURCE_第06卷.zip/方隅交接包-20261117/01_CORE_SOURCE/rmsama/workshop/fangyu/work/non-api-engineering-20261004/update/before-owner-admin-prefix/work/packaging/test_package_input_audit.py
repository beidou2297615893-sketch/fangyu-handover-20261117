import json
import hashlib
import os
import shutil
import stat
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
import build_release

from build_release import audit_copy_source, preflight, production_site_url, production_workspace_endpoint, release_company_config, validate_bundled_sources, validate_private_payload, validate_customization_source, validate_guarded_cli_runtime, validate_release_approval, validate_shared_leads_v2_proof, validate_shared_leads_disabled_proof, validate_shared_leads_release_proof, shared_leads_release_route, validate_release_config, validate_runtime_payload, validate_xhs_license, stage_xhs_license, RELEASE_EVIDENCE, SHARED_LEADS_SOURCES, SHARED_LEADS_DISABLED_SOURCES, PROJECT
from core.runtime_guards import cli_runtime_tree_sha256


class PackageInputAuditTests(unittest.TestCase):
    def test_build_environment_checks_actual_compiler_and_rejects_missing_pillow(self):
        with patch('build_release.subprocess.run',return_value=SimpleNamespace(
                returncode=0,stdout=json.dumps({'version':1,'windows_x64':True,
                'checked':list(build_release.BUILD_MODULES),'missing':['PIL.Image']}),stderr='')) as child:
            with self.assertRaisesRegex(ValueError,'PIL.Image'):
                build_release.validate_build_environment()
        self.assertEqual(child.call_args.args[0][0],str(build_release.PYTHON))
        self.assertEqual(child.call_args.args[0][1],'-I')

    def test_build_environment_rejects_failed_or_incomplete_probe(self):
        for code,raw in ((1,'{}'),(0,'{}'),(0,'not json'),
                         (0,json.dumps({'version':1,'windows_x64':False,'missing':[]}))):
            with self.subTest(code=code,raw=raw),patch('build_release.subprocess.run',
                    return_value=SimpleNamespace(returncode=code,stdout=raw,stderr='')):
                with self.assertRaisesRegex(ValueError,'构建依赖'):
                    build_release.validate_build_environment()

    def test_xhs_license_is_checked_and_staged_with_attribution(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory)
            license_copy=root/'Apache-2.0.txt'
            license_copy.write_bytes(validate_xhs_license().read_bytes())
            portable=root/'portable';portable.mkdir()
            stage_xhs_license(portable,license_copy)
            staged=portable/'第三方许可'
            self.assertEqual((staged/'Apache-2.0.txt').read_bytes(),license_copy.read_bytes())
            self.assertIn('xiaohongshu-cli 0.6.4',(staged/'小红书CLI来源说明.txt').read_text('utf-8'))
            license_copy.write_text('altered',encoding='utf-8')
            with self.assertRaisesRegex(ValueError,'许可证正文缺失'):
                validate_xhs_license(license_copy)

    def test_production_site_requires_custom_https_domain(self):
        with self.assertRaisesRegex(ValueError, '尚未配置'):
            production_site_url({})
        with self.assertRaisesRegex(ValueError, '自定义域名'):
            production_site_url({'publicSiteUrl': 'https://example.ap-shanghai.app.tcloudbase.com/fangyu-workspace'})
        with self.assertRaisesRegex(ValueError, '自定义域名'):
            production_site_url({'publicSiteUrl': 'http://apartment.example.com/workspace'})
        self.assertEqual(production_site_url({'publicSiteUrl': 'https://apartment.example.com/workspace/'}),
                         'https://apartment.example.com/workspace')

    def test_assistant_endpoint_uses_independent_formal_https_api(self):
        endpoint='https://api.fangyu.example.com/employee'
        self.assertEqual(production_workspace_endpoint({'managedWorkspace':{'endpoint':endpoint+'/'}}),endpoint)
        self.assertEqual(production_workspace_endpoint({'publicSiteUrl':'https://site.fangyu.example.com/',
                                                        'managedWorkspace':{'endpoint':endpoint}}),endpoint)
        for invalid in ('https://example.ap-shanghai.app.tcloudbase.com/workspace',
                        'https://example.ap-shanghai.app.tcloudbase.com./workspace',
                        'http://api.fangyu.example.com/employee',
                        'https://localhost/employee','https://127.0.0.1/employee',
                        'https://[::1]/employee','https://user@api.fangyu.example.com/employee',
                        'https://@api.fangyu.example.com/employee',
                        'https://api.fangyu.example.com/employee?token=',
                        'https://api.fangyu.example.com/employee#',
                        'https://api.fangyu.example.com:bad/employee'):
            with self.subTest(endpoint=invalid),self.assertRaisesRegex(ValueError,'API 地址'):
                production_workspace_endpoint({'managedWorkspace':{'endpoint':invalid}})


    def test_fangyu_release_requires_guarded_cli_but_keeps_release_blocked(self):
        report = preflight()
        self.assertIn('platform-cli-guarded', report['required_runtime'])
        self.assertFalse(report['ready'])
        self.assertTrue(any('正式业务验收' in issue for issue in report['issues']))
        self.assertTrue(any('内部 QA 运行库' in issue for issue in report['issues']))
        self.assertTrue(any('共享功能关闭的真实云端验收证明缺失' in issue for issue in report['issues']))
        self.assertTrue(any('远程更新源' in issue for issue in report['issues']))

    def test_shared_leads_release_proof_is_bound_to_sources_and_real_evidence(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory)
            for relative in SHARED_LEADS_SOURCES:
                source=root/relative;source.parent.mkdir(parents=True,exist_ok=True);source.write_text('fixture '+relative,encoding='utf-8')
            evidence=root/'outputs/产品审计/fixture.md';evidence.parent.mkdir(parents=True);evidence.write_text('real-cloud fixture',encoding='utf-8')
            proof={'company_id':'fangyu-apartment-client','schema':'shared-leads-v2','collection':'fangyu_shared_leads',
                   'index':['companyId','sequence'],'production_cloud_verified':True,'migration_verified':True,
                   'two_clients_verified':True,'migrated_count':3,
                   'evidence':{'path':'outputs/产品审计/fixture.md','sha256':hashlib.sha256(evidence.read_bytes()).hexdigest()},
                   'source_sha256':{relative:hashlib.sha256((root/relative).read_bytes()).hexdigest() for relative in SHARED_LEADS_SOURCES}}
            marker=root/'verified.json';marker.write_text(json.dumps(proof),encoding='utf-8')
            self.assertEqual(validate_shared_leads_v2_proof(marker,root)['migrated_count'],3)
            (root/SHARED_LEADS_SOURCES[0]).write_text('changed',encoding='utf-8')
            with self.assertRaisesRegex(ValueError,'源码已变化'):
                validate_shared_leads_v2_proof(marker,root)

    def _shared_fixture(self,root):
        for relative in set(SHARED_LEADS_DISABLED_SOURCES)|set(SHARED_LEADS_SOURCES):
            source=root/relative;source.parent.mkdir(parents=True,exist_ok=True)
            shutil.copy2(PROJECT/relative,source)
        evidence=root/'outputs/产品审计/fixture.md';evidence.parent.mkdir(parents=True,exist_ok=True)
        evidence.write_text('synthetic proof fixture; not real cloud evidence',encoding='utf-8')
        return evidence

    def _disabled_proof(self,root,evidence):
        return {'company_id':'fangyu-apartment-client','schema':'shared-leads-disabled-v1',
                'production_cloud_verified':True,'authenticated_list_disabled':True,
                'authenticated_publish_disabled':True,'existing_shared_data_preserved':True,
                'local_leads_preserved':True,'employee_gateway_verified':True,
                'evidence':{'path':'outputs/产品审计/fixture.md','sha256':hashlib.sha256(evidence.read_bytes()).hexdigest()},
                'source_sha256':{relative:hashlib.sha256((root/relative).read_bytes()).hexdigest()
                                 for relative in SHARED_LEADS_DISABLED_SOURCES}}

    def test_shared_disabled_proof_requires_real_evidence_and_exact_source_hashes(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory);evidence=self._shared_fixture(root)
            marker=root/'SHARED_LEADS_DISABLED_VERIFIED.json'
            with self.assertRaisesRegex(ValueError,'证明缺失'):
                validate_shared_leads_release_proof(root,disabled_path=marker)
            proof=self._disabled_proof(root,evidence)
            marker.write_text(json.dumps(proof),encoding='utf-8')
            self.assertEqual(validate_shared_leads_release_proof(root,disabled_path=marker)['schema'],
                             'shared-leads-disabled-v1')
            for changed in ({'authenticated_list_disabled':1},{'authenticated_publish_disabled':'true'},
                            {'local_leads_preserved':False},{'schema':'shared-leads-v2'},
                            {'company_id':'other'}):
                bad={**proof,**changed};marker.write_text(json.dumps(bad),encoding='utf-8')
                with self.subTest(changed=changed),self.assertRaisesRegex(ValueError,'记录不完整'):
                    validate_shared_leads_disabled_proof(marker,root)
            marker.write_text(json.dumps(proof),encoding='utf-8')
            (root/SHARED_LEADS_DISABLED_SOURCES[1]).write_text('changed',encoding='utf-8')
            with self.assertRaisesRegex(ValueError,'源码已变化'):
                validate_shared_leads_disabled_proof(marker,root)
            shutil.copy2(PROJECT/SHARED_LEADS_DISABLED_SOURCES[1],root/SHARED_LEADS_DISABLED_SOURCES[1])
            evidence.write_text('changed',encoding='utf-8')
            with self.assertRaisesRegex(ValueError,'证据缺失或内容已改变'):
                validate_shared_leads_disabled_proof(marker,root)

    def test_shared_route_never_falls_back_on_unknown_or_unwired_flag(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory);evidence=self._shared_fixture(root)
            flag=root/SHARED_LEADS_DISABLED_SOURCES[0]
            original=flag.read_text('utf-8')
            self.assertEqual(shared_leads_release_route(root),'disabled')
            flag.write_text(original.replace('= false;','= maybe;'),encoding='utf-8')
            with self.assertRaisesRegex(ValueError,'开关未知'):
                shared_leads_release_route(root)
            flag.write_text(original,encoding='utf-8')
            index=root/SHARED_LEADS_DISABLED_SOURCES[1];wired=index.read_text('utf-8')
            index.write_text(wired.replace('sharedFeatureEnabled: SHARED_FEATURE_ENABLED','sharedFeatureEnabled: true'),encoding='utf-8')
            with self.assertRaisesRegex(ValueError,'没有接入'):
                shared_leads_release_route(root)
            index.write_text(wired,encoding='utf-8')
            gateway=root/SHARED_LEADS_DISABLED_SOURCES[3];closed=gateway.read_text('utf-8')
            gateway.write_text(closed.replace("raise WorkspaceError('feature_disabled', 423)","raise WorkspaceError('other', 423)"),encoding='utf-8')
            with self.assertRaisesRegex(ValueError,'默认拒绝逻辑缺失'):
                shared_leads_release_route(root)
            gateway.write_text(closed,encoding='utf-8')
            flag.write_text(original.replace('= false;','= true;'),encoding='utf-8')
            self.assertEqual(shared_leads_release_route(root),'enabled')
            with self.assertRaisesRegex(ValueError,'共享清单分记录迁移'):
                validate_shared_leads_release_proof(root,enabled_path=root/'missing-v2.json')
            proof={'company_id':'fangyu-apartment-client','schema':'shared-leads-v2','collection':'fangyu_shared_leads',
                   'index':['companyId','sequence'],'production_cloud_verified':True,'migration_verified':True,
                   'two_clients_verified':True,'migrated_count':3,
                   'evidence':{'path':'outputs/产品审计/fixture.md','sha256':hashlib.sha256(evidence.read_bytes()).hexdigest()},
                   'source_sha256':{relative:hashlib.sha256((root/relative).read_bytes()).hexdigest()
                                    for relative in SHARED_LEADS_SOURCES}}
            marker=root/'SHARED_LEADS_V2_VERIFIED.json';marker.write_text(json.dumps(proof),encoding='utf-8')
            self.assertEqual(validate_shared_leads_release_proof(root,enabled_path=marker)['schema'],'shared-leads-v2')

    def test_release_config_activates_only_after_preflight_and_source_stays_held(self):
        source={'id':'fangyu-apartment-client','edition':'customer','personalMode':False,
                'authMode':'managed','publicSiteUrl':'https://fangyu.example/fangyu-workspace',
                'managedWorkspace':{'endpoint':'https://fangyu.example/fangyu-workspace'},
                'platforms':['xiaohongshu'],'localCliPaths':{},
                'runtime':{'xiaohongshu_automation':'hold'}}
        with self.assertRaisesRegex(ValueError,'未完成正式验收'):
            release_company_config(source)
        output=release_company_config(source,ready=True)
        self.assertEqual(source['runtime']['xiaohongshu_automation'],'hold')
        self.assertEqual(output['runtime']['xiaohongshu_automation'],'enabled')
        self.assertIs(output['runtime']['release_approved'],True)
        self.assertEqual(output['runtime']['role'],'local_assistant_only')
        self.assertEqual(output['runtime']['cli_source_sha256'],
                         hashlib.sha256((Path(__file__).resolve().parents[1]/'app/src/platform_cli.py').read_bytes()).hexdigest())
        self.assertNotIn('localCliPaths',output)
        without_site=dict(source);without_site.pop('publicSiteUrl')
        without_site['managedWorkspace']={'endpoint':'https://api.fangyu.example.com/v1'}
        generated=release_company_config(without_site,ready=True)
        with_site=dict(without_site);with_site['publicSiteUrl']='https://site.fangyu.example.com/workspace'
        self.assertEqual(release_company_config(with_site,ready=True)['publicSiteUrl'],with_site['publicSiteUrl'])
        self.assertNotIn('publicSiteUrl',generated)
        self.assertEqual(generated['managedWorkspace']['endpoint'],'https://api.fangyu.example.com/v1')
        with self.assertRaisesRegex(ValueError,'未完成正式验收'):
            release_company_config({**source,'runtime':{'xiaohongshu_automation':'enabled'}},ready=True)

    def test_release_approval_checks_each_evidence_file_hash(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory);proof=root/'outputs'/'proof.md';proof.parent.mkdir();proof.write_text('fixture evidence',encoding='utf-8')
            evidence={gate:{'accepted':True,'path':'outputs/proof.md',
                            'sha256':hashlib.sha256(proof.read_bytes()).hexdigest()} for gate in RELEASE_EVIDENCE}
            approval=root/'approval.json'
            approval.write_text(json.dumps({'company_id':'fangyu-apartment-client','platforms':['xiaohongshu'],
                                            'evidence':evidence}),encoding='utf-8')
            self.assertEqual(validate_release_approval(approval,root)['company_id'],'fangyu-apartment-client')
            proof.write_text('changed',encoding='utf-8')
            with self.assertRaisesRegex(ValueError,'内容已改变'):
                validate_release_approval(approval,root)
            proof.write_text('fixture evidence',encoding='utf-8')
            evidence['second_windows_pc_accepted']['accepted']=False
            approval.write_text(json.dumps({'company_id':'fangyu-apartment-client','platforms':['xiaohongshu'],
                                            'evidence':evidence}),encoding='utf-8')
            with self.assertRaisesRegex(ValueError,'second_windows_pc_accepted'):
                validate_release_approval(approval,root)

    def test_guarded_cli_manifest_must_match_current_source_and_executable(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory);runtime=root/'platform-cli-guarded';runtime.mkdir()
            source=root/'platform_cli.py';source.write_text('current source',encoding='utf-8')
            executable=runtime/'platform-cli.exe';executable.write_bytes(b'fixture executable')
            marker=runtime/'guard-manifest.json'
            old={'write_transport':'single_attempt','automatic_action_replay':False,
                 'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),
                 'exe_sha256':hashlib.sha256(executable.read_bytes()).hexdigest()}
            marker.write_text(json.dumps(old),encoding='utf-8')
            with self.assertRaisesRegex(ValueError,'旧版'):
                validate_guarded_cli_runtime(runtime,source)
            current={**old,'request_transport':'single_attempt_all',
                     'activity_recording':'account_local_v1','risk_stop':'review_required',
                     'runtime_tree_sha256':cli_runtime_tree_sha256(runtime),
                     'purpose':'release_verified'}
            marker.write_text(json.dumps(current),encoding='utf-8')
            validate_guarded_cli_runtime(runtime,source)
            marker.write_text(json.dumps({**current,'purpose':'internal_qa_only'}),encoding='utf-8')
            with self.assertRaisesRegex(ValueError,'内部 QA 运行库'):
                validate_guarded_cli_runtime(runtime,source)
            marker.write_text(json.dumps(current),encoding='utf-8')
            dependency=runtime/'_internal'/'xhs_cli.pyd'
            dependency.parent.mkdir()
            dependency.write_bytes(b'changed dependency')
            with self.assertRaisesRegex(ValueError,'不一致'):
                validate_guarded_cli_runtime(runtime,source)
            dependency.unlink()
            source.write_text('changed source',encoding='utf-8')
            with self.assertRaisesRegex(ValueError,'不一致'):
                validate_guarded_cli_runtime(runtime,source)

    def customization(self, root):
        source = root / '客户定制'
        source.mkdir()
        for name in ('全部素材槽位.json', '素材映射.json', '文案.json', '主题.json'):
            (source / name).write_text('{}', encoding='utf-8')
        (source / '先看这里.md').write_text('说明', encoding='utf-8')
        (source / '图片').mkdir()
        (source / '图片' / 'fixture.png').write_bytes(b'\x89PNG\r\n\x1a\n')
        return source

    def test_reviewed_customization_passes_and_extra_file_fails(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            source = self.customization(root)
            validate_customization_source(source, root)
            (source / 'credentials.json').write_text('{}', encoding='utf-8')
            with self.assertRaisesRegex(ValueError, 'unreviewed files'):
                validate_customization_source(source, root)

    def test_nested_credential_field_and_outside_source_fail(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            source = self.customization(root)
            (source / '文案.json').write_text(json.dumps({'theme': {'apiKey': 'fixture'}}), encoding='utf-8')
            with self.assertRaisesRegex(ValueError, 'Private configuration field'):
                validate_customization_source(source, root)
            with self.assertRaisesRegex(ValueError, 'outside customer project'):
                audit_copy_source(source, root / 'unrelated')
            with self.assertRaisesRegex(ValueError, 'Private configuration field'):
                validate_release_config({'runtime': {'access_token': 'fixture'}})
            with self.assertRaisesRegex(ValueError, 'Private configuration field'):
                validate_release_config({'localCliPaths': {'apiKey': 'fixture'}})
            validate_release_config({'localCliPaths': {'apiKey': 'fixture'}}, strip_local_cli_paths=True)

    def test_nested_symlink_cannot_follow_an_external_folder(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            source = self.customization(root)
            outside = root / 'outside'
            outside.mkdir()
            link = source / '图片' / 'external'
            try:
                os.symlink(outside, link, target_is_directory=True)
            except OSError:
                self.skipTest('Windows symlink creation is not available')
            with self.assertRaisesRegex(ValueError, 'links or junctions'):
                validate_customization_source(source, root)

    def test_bundled_web_assets_reject_private_runtime_file(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            web = root / 'src/web'
            adapters = root / 'src/resources/adapters'
            companies = root / 'src/resources/companies'
            web.mkdir(parents=True)
            adapters.mkdir(parents=True)
            companies.mkdir(parents=True)
            (web / 'app.js').write_text('const ready=true;', encoding='utf-8')
            (adapters / 'xiaohongshu.json').write_text('{}', encoding='utf-8')
            (companies / 'apartment.json').write_text('{}', encoding='utf-8')
            validate_bundled_sources(root)
            (web / 'cookies.json').write_text('{}', encoding='utf-8')
            with self.assertRaisesRegex(ValueError, 'Private file cannot be bundled'):
                validate_bundled_sources(root)

    def test_bundled_web_assets_reject_maintainer_credentials(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory)
            web=root/'src/web';web.mkdir(parents=True)
            adapters=root/'src/resources/adapters';adapters.mkdir(parents=True)
            companies=root/'src/resources/companies';companies.mkdir(parents=True)
            (adapters/'xiaohongshu.json').write_text('{}','utf-8')
            (companies/'apartment.json').write_text('{}','utf-8')
            credential=web/'grant.dpapi';credential.write_bytes(b'synthetic-only')
            with self.assertRaisesRegex(ValueError,'Private file cannot be bundled'):
                validate_bundled_sources(root)
            credential.unlink()
            hidden=web/'owner-admin/private';hidden.mkdir(parents=True)
            (hidden/'README.txt').write_text('synthetic-only','utf-8')
            with self.assertRaisesRegex(ValueError,'Private maintenance folder'):
                validate_bundled_sources(root)

    def test_final_employee_payload_rejects_private_state_before_zip(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory)
            (root/'company.json').write_text('{}','utf-8')
            validate_private_payload(root)
            secret=root/'_internal/owner-admin/private/grant.dpapi'
            secret.parent.mkdir(parents=True)
            secret.write_bytes(b'synthetic-only')
            with self.assertRaisesRegex(ValueError,'Maintainer private state'):
                validate_private_payload(root)

    def test_windows_reparse_attribute_rejects_nested_junction(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            source = self.customization(root)
            target = source / '图片'
            original = Path.lstat
            def fake_lstat(path, *args, **kwargs):
                if path == target:
                    return SimpleNamespace(st_file_attributes=stat.FILE_ATTRIBUTE_REPARSE_POINT,
                                           st_mode=stat.S_IFDIR)
                return original(path, *args, **kwargs)
            with patch.object(Path, 'lstat', fake_lstat):
                with self.assertRaisesRegex(ValueError, 'links or junctions'):
                    validate_customization_source(source, root)

    def test_runtime_rejects_private_file_and_browser_database(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            runtime = root / 'platform-cli-guarded'
            runtime.mkdir()
            validate_runtime_payload(runtime, root)
            (runtime / 'cookies.json').write_text('{}', encoding='utf-8')
            with self.assertRaisesRegex(ValueError, 'Private runtime file'):
                validate_runtime_payload(runtime, root)
            (runtime / 'cookies.json').unlink()
            vendor = runtime / '_internal/camoufox/webgl/webgl_data.db'
            vendor.parent.mkdir(parents=True)
            vendor.write_bytes(b'not the reviewed vendor file')
            with self.assertRaisesRegex(ValueError, '浏览器辅助'):
                validate_runtime_payload(runtime, root)


if __name__ == '__main__':
    unittest.main()


