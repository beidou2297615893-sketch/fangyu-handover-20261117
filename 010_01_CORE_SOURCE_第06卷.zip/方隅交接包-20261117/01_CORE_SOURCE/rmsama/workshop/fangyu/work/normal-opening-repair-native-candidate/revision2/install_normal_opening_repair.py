"""Independent two-existing-thin repair. Root authorization is deliberately absent."""
import ast,hashlib,json,os,stat,subprocess,tempfile,types,uuid
from pathlib import Path
PROJECT=Path('C:/积木软件工坊/项目/方隅公寓客户版')
WORK=PROJECT/'work';OWN=WORK/'normal-opening-repair-native-r1';AUDITS=WORK/'product-upgrade-20261009/audits'
RECEIPT=AUDITS/'normal-opening-repair-native-installed.json'
FAILED=AUDITS/'normal-opening-repair-native-failed.json'
BACKUP_BASE=PROJECT/'backups/normal-opening-repair-native'
GUARD=WORK/'source52-root-integration/guard-token-r2/source_idle_guard.py'
GUARD_PIN={'bytes':6243,'sha256':'EC86C01DA85F6AC984CAC4BBA78DEB400D32C2E92FDCA30409CF007A0DA08B0F'}
INSTALL_AUTHORIZED=False
SOURCE52=WORK/'desktop-self-use-entry/next_open_source52.py'
NEW_HELPER=WORK/'desktop-self-use-entry/next_open_source53.py'
LAUNCHER=WORK/'desktop-self-use-entry/source_next_open_launcher.py'
SOURCE50=WORK/'desktop-self-use-entry/next_open_source.py'
SOURCE51=WORK/'desktop-self-use-entry/next_open_source51.py'
ENTRY=WORK/'desktop-self-use-entry/desktop_entry.py'
IMMUTABLE=(
 (SOURCE50,{'bytes':18590,'sha256':'6DD31FBCB9864272C329C146DD7EA3E9F74F334131F84DDFEB5E3D63ED8BB611'}),
 (SOURCE51,{'bytes':14697,'sha256':'8540B5A0AE7572E5C2DC8A550AD74BA0918FF931C09945E7F802E0FB00F6EEF0'}),
 (NEW_HELPER,{'bytes':5903,'sha256':'93DE3F1E74D9B010DBF5D68FD45AA836F19130F20B37CEB0CDFE9FA07DA6F4E1'}),
 (ENTRY,{'bytes':15900,'sha256':'C2FEE1D2355A7A6605E807BFCC71E339D1C23B83D23E92913849DA4E96B980B3'}))
HELPER_PARENT_PIN={'bytes':15623,'sha256':'1C919E94AA3477E6ABC17EA6B4BC348ACD2E13161FA96E9CC0622AE112FF1FAF'}
PARENT_PIN={'bytes':5405,'sha256':'994ED84BB4AB1154290AB1AA8E291B1976E0C03C3076C7B22ACF73C189D83D26'}
PARENT_RECEIPTS=(
 (AUDITS/'source52-native-installed.json',{'bytes':1874,'sha256':'613E43C5461A775FB5BFABE45E2A36178E0CB03CB9AD9DDF1A2F3BC0C3196E51'}),
 (AUDITS/'source53-native-installed.json',{'bytes':2175,'sha256':'644B80863EA5E452438A062FAC902EA1902B69F0D1087B4E98F8C69C3C6DDF8E'}))
LINEAGE_BACKUPS=(
 (PROJECT/'backups/source52-native/c6cb3e367157496fa9f46855849cc496/source_next_open_launcher.py',{'bytes':4626,'sha256':'AA029206565CA20227131E06C200FBAA385C909CA5C21B274CA83477F1992176'}),
 (PROJECT/'backups/source53-native/598bf82b4ac84a05bb19b3b1c7d63c9d/source_next_open_launcher.py',{'bytes':4985,'sha256':'E8138AD0126C3F5F93747651CDD2106188567C47E6FDD356E9E0F3229CCB6236'}))
PAYLOAD_EVIDENCE=(
 (WORK/'source52-empty-protection-candidate/revision2/PLAN.json',{'bytes': 3050, 'sha256': '5C04168AD9352903C6A4759EB2851A37C714824A6CCB7F485DBF8CF2B087038C'}),
 (WORK/'source52-empty-protection-candidate/revision2/FROZEN.json',{'bytes': 3416, 'sha256': '9F04435C46D947198370F79675FD991C70A9BF4FD10D51BF03D4A1AF56FDFD95'}))
GRAPH=OWN/'GRAPH.json'
GRAPH_PIN={'bytes': 5103, 'sha256': '09CFAB6EEDD3B82CA3E2740F76E8FE3A68AC823112092F768594FE04FA5BB043'}
GATE=OWN/'NATIVE-ROOT-APPROVAL.json'
GATE_PIN=None
STAGE=WORK/'source52-root-integration/empty-protection-r3'
HELPER_PIN={'bytes':16027,'sha256':'B4F6BE4903F7E25F7C25B11F1CEAB96779CC60D26F511C1511E8257D012072A4'}
LAUNCHER_PIN={'bytes': 5910, 'sha256': 'EC31A4C07FE485BF020B94287847EACEA03D50EE42AF8714AF1ACB32A36DF86E'}


def blob(path):
    current=PROJECT
    for part in path.relative_to(PROJECT).parts:
        current=current/part
        info=current.lstat()
        if current.is_symlink() or getattr(info,'st_file_attributes',0)&0x400:
            raise ValueError('reparse path changed')
    if not stat.S_ISREG(info.st_mode) or info.st_nlink!=1:
        raise ValueError('file kind changed')
    return path.read_bytes()

def pin(value):
    return {'bytes':len(value),'sha256':hashlib.sha256(value).hexdigest().upper()}

def expected(path,proof):
    value=blob(path)
    if pin(value)!=proof:
        raise ValueError('pinned file changed: '+str(path))
    return value

def no_link_parent(path):
    current=PROJECT
    for part in path.parent.relative_to(PROJECT).parts:
        current=current/part
        info=current.lstat()
        if (not stat.S_ISDIR(info.st_mode) or current.is_symlink()
                or getattr(info,'st_file_attributes',0)&0x400):
            raise ValueError('new-source parent changed')

def prepared_temp(target,value):
    no_link_parent(target)
    descriptor,name=tempfile.mkstemp(prefix='.source44-',suffix='.tmp',dir=target.parent)
    temporary=Path(name)
    try:
        with os.fdopen(descriptor,'wb') as stream:
            stream.write(value)
            stream.flush()
            os.fsync(stream.fileno())
        if blob(temporary)!=value:
            raise ValueError('complete temporary write mismatch')
        return temporary
    except BaseException:
        # This explicit temporary file is new and private to this join.
        temporary.unlink(missing_ok=True)
        raise

def proof(value):
    return (type(value) is dict and set(value)=={'bytes','sha256'} and type(value['bytes']) is int
        and value['bytes']>0 and type(value['sha256']) is str and len(value['sha256'])==64
        and all(x in '0123456789ABCDEF' for x in value['sha256']))

def absent():
    # Only these thin Python opening paths are promoted. The old main may stay
    # live because no business/app/portal/cloud source is changed by this file.
    # Reuse the reviewed WQL/JSON transport with an explicit narrower fixed set;
    # this is a wrapper-consumer check, never a claim the business source is idle.
    module=types.ModuleType('source52_thin_consumer_guard');module.__file__=str(GUARD)
    exec(compile(expected(GUARD,GUARD_PIN),str(GUARD),'exec'),module.__dict__)
    module.SOURCE_PATHS=(LAUNCHER,SOURCE50,SOURCE51,SOURCE52,NEW_HELPER)
    module.ALIASES=tuple(x.name for x in module.SOURCE_PATHS)
    module.RUNTIMES=('python.exe','pythonw.exe','py.exe','pypy.exe','pypy3.exe')
    result=module.source_state(os.getpid())
    if type(result) is not dict or result.get('scope')!='fangyu_customer_source_metadata_v1' or result.get('state')!='idle':
        raise ValueError('normal thin opening live or unknown; preserve it')

def business_absent():
    if any(os.path.lexists(AUDITS/('source%d-%s.json'%(batch,name)))
            for batch in (50,51,52,53) for name in ('next-open-started','join-failed','joined')):
        raise ValueError('original business evidence preserved; repair cannot reapply')
    if any(os.path.lexists(AUDITS/('source%d-native-install-failed.json'%batch)) for batch in (52,53)):
        raise ValueError('original native failure preserved')

def dependencies():
    business_absent()
    expected(GATE,GATE_PIN);expected(GRAPH,GRAPH_PIN)
    expected(GUARD,GUARD_PIN)
    for path,value in IMMUTABLE+PARENT_RECEIPTS+LINEAGE_BACKUPS+PAYLOAD_EVIDENCE:expected(path,value)

def main():
    # The first operation is an in-memory authorization/proof check. No metadata
    # read, PID lookup, guard execution or filesystem query is allowed before it.
    if INSTALL_AUTHORIZED is not True or not all(proof(x) for x in
            (GATE_PIN,GRAPH_PIN,HELPER_PIN,LAUNCHER_PIN,HELPER_PARENT_PIN,PARENT_PIN,GUARD_PIN)):
        raise ValueError('normal opening repair unbound; metadata/guard not permitted')
    if os.name!='nt' or os.path.lexists(RECEIPT) or os.path.lexists(FAILED):
        raise ValueError('independent repair evidence preserved; no automatic retry')
    business_absent()
    gate=json.loads(expected(GATE,GATE_PIN));graph=json.loads(expected(GRAPH,GRAPH_PIN))
    items=[{'target':SOURCE52,'candidate':STAGE/'next_open_source52.py','parent':HELPER_PARENT_PIN,'final':HELPER_PIN},
        {'target':LAUNCHER,'candidate':STAGE/'source_next_open_launcher.py','parent':PARENT_PIN,'final':LAUNCHER_PIN}]
    if (gate.get('schema')!='normal_opening_repair_native_gate_v1'
        or gate.get('install_authorized') is not True or gate.get('graph_pin')!=GRAPH_PIN
        or gate.get('independent_native_review_passed') is not True
        or gate.get('payload_evidence')!=[{'path':str(p),'pin':v} for p,v in PAYLOAD_EVIDENCE]
        or gate.get('business_apply_authorized') is not False or gate.get('App_control_authorized') is not False
        or graph.get('schema')!='normal_opening_repair_native_graph_v1' or graph.get('join_authorized') is not False
        or graph.get('targets')!=[{'target':str(x['target']),'candidate':str(x['candidate']),'parent':x['parent'],'final':x['final']} for x in items]
        or graph.get('source_guard')!={'path':str(GUARD),'pin':GUARD_PIN}
        or graph.get('immutable_files')!=[{'path':str(p),'pin':v} for p,v in IMMUTABLE]
        or graph.get('parent_receipts')!=[{'path':str(p),'pin':v} for p,v in PARENT_RECEIPTS]
        or graph.get('lineage_backups')!=[{'path':str(p),'pin':v} for p,v in LINEAGE_BACKUPS]
        or graph.get('payload_evidence')!=[{'path':str(p),'pin':v} for p,v in PAYLOAD_EVIDENCE]
        or graph.get('business_apply_calls')!=0 or graph.get('App_control_authorized') is not False
        or graph.get('no_reverse_native_graph_binding') is not True):
        raise ValueError('fixed two-existing-file repair graph/gate changed')
    changes=[]
    for row in items:
        no_link_parent(row['target'])
        changes.append((row,expected(row['target'],row['parent']),expected(row['candidate'],row['final'])))
    records=[];completed=set()
    def fresh():
        if os.path.lexists(RECEIPT) or os.path.lexists(FAILED):raise ValueError('repair evidence appeared')
        dependencies()
        for row,_,_ in changes:
            no_link_parent(row['target']);expected(row['target'],row['final'] if row['target'] in completed else row['parent'])
            expected(row['candidate'],row['final'])
        for row in records:expected(Path(row['backup']),row['parent'])
        absent()
    fresh()
    no_link_parent(BACKUP_BASE);BACKUP_BASE.mkdir(exist_ok=True)
    backup=BACKUP_BASE/uuid.uuid4().hex
    no_link_parent(backup);backup.mkdir()
    temporaries=[];attempted=[]
    try:
        for row,before,after in changes:
            fresh()
            saved=backup/row['target'].name
            with saved.open('xb') as stream:stream.write(before)
            expected(saved,row['parent'])
            records.append({'path':str(row['target']),'parent':row['parent'],'pin':row['final'],'backup':str(saved)})
            temporaries.append(prepared_temp(row['target'],after))
        for (row,before,after),temporary in zip(changes,temporaries):
            fresh();expected(temporary,row['final'])
            attempted.append((row,before,after))
            os.replace(temporary,row['target']);expected(row['target'],row['final']);completed.add(row['target'])
        fresh()
        value={'schema':'normal_opening_repair_native_installed_v1','files':records,'graph_pin':GRAPH_PIN,'native_gate_pin':GATE_PIN,
            'parent_native_receipts':[{'path':str(p),'pin':v} for p,v in PARENT_RECEIPTS],
            'preserved_launcher_lineage':[{'path':str(p),'pin':v} for p,v in LINEAGE_BACKUPS],
            'payload_evidence':[{'path':str(p),'pin':v} for p,v in PAYLOAD_EVIDENCE],
            'immutable_files':[{'path':str(p),'pin':v} for p,v in IMMUTABLE],
            'source50_business_apply_calls':0,'source51_business_apply_calls':0,'source52_business_apply_calls':0,'source53_business_apply_calls':0,
            'original_App_started_or_stopped':False,'marker_or_platform_grants_changed':False,'database_or_session_copied':False,
            'desktop_shortcuts_changed':False,'fixed_flags':['-X','utf8','-B','-I'],'commercial_complete':False}
        temp=prepared_temp(RECEIPT,(json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode('utf-8'));temporaries.append(temp)
        fresh();expected(temp,pin((json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode('utf-8')))
        os.rename(temp,RECEIPT)
        print(json.dumps({'installed':True,'files':2,'backup':str(backup),'receipt_pin':pin(blob(RECEIPT)),'business_apply_calls':0},ensure_ascii=False))
    except BaseException as error:
        rollback=[]
        for row,before,after in reversed(attempted):
            try:
                target=row['target'];no_link_parent(target);current=blob(target)
                if current==before:rollback.append({'path':str(target),'no_change':True});continue
                if current!=after:raise ValueError('foreign thin target drift retained')
                dependencies();absent()
                saved=backup/target.name;restore=prepared_temp(target,expected(saved,row['parent']));temporaries.append(restore)
                dependencies();expected(target,row['final']);absent()
                os.replace(restore,target);expected(target,row['parent'])
                rollback.append({'path':str(target),'restored':True})
            except BaseException as fault:rollback.append({'path':str(row['target']),'held':True,'error_type':type(fault).__name__})
        no_link_parent(FAILED)
        with FAILED.open('x',encoding='utf-8') as stream:stream.write(json.dumps({'schema':'normal_opening_repair_native_failed_v1',
            'failed':True,'automatic_retry':False,'error_type':type(error).__name__,'backup':str(backup),'rollback':rollback},ensure_ascii=False,indent=2)+'\n')
        raise
    finally:
        for temporary in temporaries:temporary.unlink(missing_ok=True)

if __name__=='__main__':main()
