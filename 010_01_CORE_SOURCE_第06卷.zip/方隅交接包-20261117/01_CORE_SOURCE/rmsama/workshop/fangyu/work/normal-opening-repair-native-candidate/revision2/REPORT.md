# 正常打开修复 native：最终候选 revision2

状态：FROZEN_FINAL_CANDIDATE_UNAUTHORIZED。仍`INSTALL_AUTHORIZED=False`、`GATE_PIN=None`；Root独审、填正新gate、绑定新code后才可另行安装。本候选没有执行真实guard/query/PID/preflight/installer/App/API/DB或生产替换。

文件：C:/积木软件工坊/项目/方隅公寓客户版/work/normal-opening-repair-native-candidate/revision2/FROZEN.json
文件夹：C:/积木软件工坊/项目/方隅公寓客户版/work/normal-opening-repair-native-candidate/revision2

原r1冻结2870/385CAF173D72D5576B6D653115F58BF5BC79EF16F402EF31204E631C18FF6AD7保留。r2只改3个安装器常量：LAUNCHER_PIN、PAYLOAD_EVIDENCE、GRAPH_PIN；所有函数源码与r1完全相同，包括main内fresh及rollback。七个底层安全函数仍来自已审原native53 14503/D08CF3FF…；窄五thin/Python5 EC86 absent保持。本轮只核新exact绑定及一条owned两文件事务GREEN185d28，未重复r1九项事务/拒绝/回滚验证及旧业务QA。

最终作者绑定：revision2/PLAN.json3050/5C04168AD9352903C6A4759EB2851A37C714824A6CCB7F485DBF8CF2B087038C，revision2/FROZEN.json3416/9F04435C46D947198370F79675FD991C70A9BF4FD10D51BF03D4A1AF56FDFD95。H52仍16027/B4F6BE4903F7E25F7C25B11F1CEAB96779CC60D26F511C1511E8257D012072A4；launcher改5910/EC31A4C07FE485BF020B94287847EACEA03D50EE42AF8714AF1ACB32A36DF86E。未来两candidate路径仍`work/source52-root-integration/empty-protection-r3`。声明pin与实际作者owned文件字节已核；逐fresh/rollback核作者PLAN/FROZEN exact bytes，graph+gate同时绑定，independent_review flag不足以接受任意新payload。

两个existing targets父为desktop H52 15623/1C919E94…及current53launcher5405/994ED84B…。独立receipt/FAILED仍原audits下normal-opening-repair-native-installed.json / normal-opening-repair-native-failed.json；独立backupbase为backups/normal-opening-repair-native。拟独立public controls为work/normal-opening-repair-native-r1；地址只声明，未创建生产控制或回执。新备份必须保存H52旧1C及launcher旧994E。

原50/51/53helper与entry保持；原native52raw1874/613E43C5…、native53raw2175/644B8086…以及native52 c6cb旧51AA、native53 598bf新52E813的父launcher备份lineage固定保留，绝不改旧raw或auto reapply。12原50–53business STARTED/FAILED/success任一存在即拒；backup/replace/seal前复核固定依赖、当前parent/final与新parent backups，再核窄guard。失败回滚仍要求idle及固定依赖、当前本次after字节，live/unknown或外来漂移则held并保FAILED；无自动重试。

历史口径更正：reviewer已通过ASCII/AST实核撤回原r1包含『本次未更新』及其P2断言，原01106文字并无该表述。r2采用更通用中性失败提示属于合理文案改进，本报告不把它记为已证代码P2修复。原H52保护合法empty pin的真实修复与已留RED/GREEN证据不受此撤回影响。

验证限度：本轮main使用实际candidate事务函数及完全owned文件，系统guard/OS故障边界合成；没有真实占用检测、运行打开、生产安装或业务QA结论。既有r1九项样例包含false/None授权0IO、live/unknown0mutation、12证据拒绝、失败rollback和live/unknown held；r2函数源码相同，代表性txn成功与parent backups/独立receipt已再次通过。断电崩溃恢复和外部并发改写不由owned样例证明。
