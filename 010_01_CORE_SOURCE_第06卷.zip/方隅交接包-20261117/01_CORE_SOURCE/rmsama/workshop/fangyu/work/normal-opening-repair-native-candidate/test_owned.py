"""Public main seam. All filesystem data is owned; guard boundary is synthetic."""
import contextlib,io,json,os,tempfile,types,unittest
from pathlib import Path
FOLDER=Path(__file__).resolve().parent
class OwnedOS:
    name='nt'
    def __init__(self):self.replacements=0;self.fail_replace=None;self.on_failure=None;self.after_replace=None
    def __getattr__(self,name):
        if name=='getpid':raise AssertionError('PID boundary forbidden')
        return getattr(os,name)
    def replace(self,a,b):
        self.replacements+=1
        if self.replacements==self.fail_replace:
            if self.on_failure:self.on_failure()
            raise OSError('owned second replacement failure')
        result=os.replace(a,b)
        if self.after_replace:self.after_replace(Path(b))
        return result
class RepairTests(unittest.TestCase):
    def setUp(self):
        (FOLDER/'owned-runs').mkdir(exist_ok=True)
        self.tmp=tempfile.TemporaryDirectory(dir=FOLDER/'owned-runs');self.addCleanup(self.tmp.cleanup)
        self.root=Path(self.tmp.name);self.m=types.ModuleType('owned_repair')
        exec(compile((FOLDER/'install_normal_opening_repair.py').read_bytes(),'owned-candidate','exec'),self.m.__dict__)
        m=self.m;m.PROJECT=self.root;m.WORK=self.root/'work';m.WORK.mkdir();m.OWN=m.WORK/'control';m.OWN.mkdir()
        m.AUDITS=m.WORK/'audits';m.AUDITS.mkdir();m.STAGE=m.WORK/'payload';m.STAGE.mkdir()
        thin=m.WORK/'thin';thin.mkdir();(self.root/'backups').mkdir()
        m.SOURCE52=thin/'next_open_source52.py';m.LAUNCHER=thin/'source_next_open_launcher.py'
        m.SOURCE50=thin/'next_open_source.py';m.SOURCE51=thin/'next_open_source51.py';m.NEW_HELPER=thin/'next_open_source53.py'
        m.ENTRY=thin/'desktop_entry.py'
        self.old=[b'old source52\n',b'old source53 launcher\n'];self.new=[b'repaired source52\n',b'repaired source53 launcher\n']
        m.SOURCE52.write_bytes(self.old[0]);m.LAUNCHER.write_bytes(self.old[1])
        m.HELPER_PARENT_PIN=m.pin(self.old[0]);m.PARENT_PIN=m.pin(self.old[1])
        m.HELPER_PIN=m.pin(self.new[0]);m.LAUNCHER_PIN=m.pin(self.new[1])
        (m.STAGE/'next_open_source52.py').write_bytes(self.new[0]);(m.STAGE/'source_next_open_launcher.py').write_bytes(self.new[1])
        immutable=[]
        for i,path in enumerate([m.SOURCE50,m.SOURCE51,m.NEW_HELPER,m.ENTRY]):
            path.write_bytes(('unchanged immutable %s\n'%i).encode());immutable.append((path,m.pin(path.read_bytes())))
        m.IMMUTABLE=tuple(immutable)
        parents=[]
        for i,name in enumerate(['source52-native-installed.json','source53-native-installed.json']):
            path=m.AUDITS/name;path.write_bytes(('owned historical receipt %s\n'%i).encode());parents.append((path,m.pin(path.read_bytes())))
        m.PARENT_RECEIPTS=tuple(parents)
        lineage=[]
        for i,name in enumerate(['source52-native/old51/source_next_open_launcher.py','source53-native/old52/source_next_open_launcher.py']):
            path=self.root/'backups'/name;path.parent.mkdir(parents=True);path.write_bytes(('owned lineage %s\n'%i).encode());lineage.append((path,m.pin(path.read_bytes())))
        m.LINEAGE_BACKUPS=tuple(lineage)
        evidence=[]
        for name in ('PAYLOAD-PLAN.json','PAYLOAD-FROZEN.json'):
            path=m.OWN/name;path.write_bytes(('owned payload evidence '+name).encode());evidence.append((path,m.pin(path.read_bytes())))
        m.PAYLOAD_EVIDENCE=tuple(evidence)
        m.RECEIPT=m.AUDITS/'normal-opening-repair-installed.json';m.FAILED=m.AUDITS/'normal-opening-repair-failed.json'
        m.BACKUP_BASE=self.root/'backups'/'normal-opening-repair-native'
        m.GUARD=m.OWN/'owned_guard.py';m.GUARD.write_bytes(b'# never executed owned guard boundary\n');m.GUARD_PIN=m.pin(m.GUARD.read_bytes())
        m.GRAPH=m.OWN/'GRAPH.json';m.GATE=m.OWN/'GATE.json'
        items=[{'target':str(t),'candidate':str(c),'parent':p,'final':f} for t,c,p,f in [(m.SOURCE52,m.STAGE/'next_open_source52.py',m.HELPER_PARENT_PIN,m.HELPER_PIN),(m.LAUNCHER,m.STAGE/'source_next_open_launcher.py',m.PARENT_PIN,m.LAUNCHER_PIN)]]
        graph={'schema':'normal_opening_repair_native_graph_v1','join_authorized':False,'targets':items,'source_guard':{'path':str(m.GUARD),'pin':m.GUARD_PIN},'immutable_files':[{'path':str(p),'pin':v} for p,v in m.IMMUTABLE],'parent_receipts':[{'path':str(p),'pin':v} for p,v in m.PARENT_RECEIPTS],'lineage_backups':[{'path':str(p),'pin':v} for p,v in m.LINEAGE_BACKUPS],'business_apply_calls':0,'App_control_authorized':False,'no_reverse_native_graph_binding':True,'payload_evidence':[{'path':str(p),'pin':v} for p,v in m.PAYLOAD_EVIDENCE]}
        m.GRAPH.write_text(json.dumps(graph),encoding='utf-8');m.GRAPH_PIN=m.pin(m.GRAPH.read_bytes())
        gate={'schema':'normal_opening_repair_native_gate_v1','install_authorized':True,'independent_native_review_passed':True,'business_apply_authorized':False,'App_control_authorized':False,'graph_pin':m.GRAPH_PIN,'payload_evidence':graph['payload_evidence']}
        m.GATE.write_text(json.dumps(gate),encoding='utf-8');m.GATE_PIN=m.pin(m.GATE.read_bytes());m.INSTALL_AUTHORIZED=True
        self.guard_calls=0;self.guard_states=['idle'];self.owned_os=OwnedOS();m.os=self.owned_os
        def owned_absent():
            self.guard_calls+=1;state=getattr(self,'guard_state',self.guard_states[min(self.guard_calls-1,len(self.guard_states)-1)])
            if state!='idle':raise ValueError('owned thin state '+state)
        m.absent=owned_absent
    def run_main(self):
        with contextlib.redirect_stdout(io.StringIO()) as out:self.m.main()
        return json.loads(out.getvalue())
    def tree(self):return {str(p.relative_to(self.root)):p.read_bytes() for p in self.root.rglob('*') if p.is_file()}
    def test_two_existing_files_repaired_with_original_backups_and_independent_receipt(self):
        before=[(p,p.read_bytes()) for p,_ in self.m.IMMUTABLE+self.m.PARENT_RECEIPTS+self.m.LINEAGE_BACKUPS]
        result=self.run_main()
        self.assertEqual((result['installed'],result['files']),(True,2))
        self.assertEqual([self.m.SOURCE52.read_bytes(),self.m.LAUNCHER.read_bytes()],self.new)
        receipt=json.loads(self.m.RECEIPT.read_bytes())
        self.assertEqual([Path(row['backup']).read_bytes() for row in receipt['files']],self.old)
        self.assertEqual([row['parent'] for row in receipt['files']],[self.m.HELPER_PARENT_PIN,self.m.PARENT_PIN])
        for path,raw in before:self.assertEqual(path.read_bytes(),raw)
        self.assertFalse(self.m.FAILED.exists())
    def test_authorization_false_or_unbound_performs_no_io_or_pid_or_guard(self):
        class ForbiddenOS:
            def __getattribute__(self,name):raise AssertionError('filesystem/PID/OS access before authorization')
        def forbidden(*args):raise AssertionError('metadata/guard boundary before authorization')
        self.m.os=ForbiddenOS();self.m.blob=forbidden;self.m.expected=forbidden;self.m.absent=forbidden
        self.m.INSTALL_AUTHORIZED=False
        with self.assertRaisesRegex(ValueError,'unbound'):self.m.main()
        self.m.INSTALL_AUTHORIZED=True;self.m.GATE_PIN=None
        with self.assertRaisesRegex(ValueError,'unbound'):self.m.main()
    def test_live_and_unknown_before_backup_leave_no_mutation(self):
        before=self.tree()
        for state in ('live','unknown'):
            self.guard_state=state
            with self.assertRaisesRegex(ValueError,'owned thin'):self.run_main()
            self.assertEqual(self.tree(),before);self.assertFalse(self.m.BACKUP_BASE.exists())
    def test_each_original_business_marker_refuses_before_metadata(self):
        expected=self.m.expected
        def forbidden(*args):raise AssertionError('metadata read after original business evidence')
        self.m.expected=forbidden
        for batch in (50,51,52,53):
            for name in ('next-open-started','join-failed','joined'):
                path=self.m.AUDITS/('source%d-%s.json'%(batch,name));path.write_bytes(b'owned original business evidence')
                before=self.tree()
                with self.assertRaisesRegex(ValueError,'original business evidence'):self.run_main()
                self.assertEqual(self.tree(),before);path.unlink()
        self.m.expected=expected;self.assertFalse(self.m.BACKUP_BASE.exists());self.assertEqual(self.guard_calls,0)
    def test_second_replace_failure_restores_both_originals_and_records_failure(self):
        self.owned_os.fail_replace=2
        with self.assertRaisesRegex(OSError,'owned second'):self.run_main()
        self.assertEqual([self.m.SOURCE52.read_bytes(),self.m.LAUNCHER.read_bytes()],self.old)
        self.assertFalse(self.m.RECEIPT.exists())
        failure=json.loads(self.m.FAILED.read_bytes());self.assertFalse(failure['automatic_retry'])
        self.assertTrue(any(row.get('restored') for row in failure['rollback']))
        self.assertEqual([(Path(failure['backup'])/p.name).read_bytes() for p in (self.m.SOURCE52,self.m.LAUNCHER)],self.old)
    def test_rollback_live_or_unknown_holds_changed_file_and_preserves_original_backup(self):
        self.owned_os.fail_replace=2;self.owned_os.on_failure=lambda:setattr(self,'guard_state',self.rollback_state)
        for state in ('live','unknown'):
            self.rollback_state=state;self.guard_state='idle';self.owned_os.replacements=0
            with self.assertRaisesRegex(OSError,'owned second'):self.run_main()
            self.assertEqual([self.m.SOURCE52.read_bytes(),self.m.LAUNCHER.read_bytes()],[self.new[0],self.old[1]])
            failure=json.loads(self.m.FAILED.read_bytes());self.assertTrue(any(row.get('held') for row in failure['rollback']))
            self.assertFalse(self.m.RECEIPT.exists())
            self.assertEqual((Path(failure['backup'])/self.m.SOURCE52.name).read_bytes(),self.old[0])
            # Reset only exact owned fixture files to make the next scenario independent.
            self.m.SOURCE52.write_bytes(self.old[0]);self.m.FAILED.unlink()
    def test_fixed_dependency_drift_before_second_replace_refuses_and_holds(self):
        original=self.m.PARENT_RECEIPTS[0][0].read_bytes()
        def drift(path):
            if path==self.m.SOURCE52:self.m.PARENT_RECEIPTS[0][0].write_bytes(b'owned drifted historical receipt')
        self.owned_os.after_replace=drift
        with self.assertRaisesRegex(ValueError,'pinned file changed'):self.run_main()
        self.assertEqual([self.m.SOURCE52.read_bytes(),self.m.LAUNCHER.read_bytes()],[self.new[0],self.old[1]])
        self.assertFalse(self.m.RECEIPT.exists());self.assertTrue(self.m.FAILED.exists())
        self.assertNotEqual(self.m.PARENT_RECEIPTS[0][0].read_bytes(),original)
    def test_preexisting_repair_failure_or_receipt_cannot_retry(self):
        for path in (self.m.FAILED,self.m.RECEIPT):
            path.write_bytes(b'owned earlier repair evidence');before=self.tree()
            with self.assertRaisesRegex(ValueError,'evidence preserved'):self.run_main()
            self.assertEqual(self.tree(),before);path.unlink()
        self.assertFalse(self.m.BACKUP_BASE.exists())
    def test_independent_review_flag_without_exact_payload_evidence_cannot_authorize(self):
        graph=json.loads(self.m.GRAPH.read_bytes());graph.pop('payload_evidence')
        self.m.GRAPH.write_text(json.dumps(graph),encoding='utf-8');self.m.GRAPH_PIN=self.m.pin(self.m.GRAPH.read_bytes())
        gate=json.loads(self.m.GATE.read_bytes());gate['graph_pin']=self.m.GRAPH_PIN;gate.pop('payload_evidence')
        self.m.GATE.write_text(json.dumps(gate),encoding='utf-8');self.m.GATE_PIN=self.m.pin(self.m.GATE.read_bytes())
        before=self.tree()
        with self.assertRaisesRegex(ValueError,'graph/gate changed'):self.run_main()
        self.assertEqual(self.tree(),before);self.assertFalse(self.m.BACKUP_BASE.exists())
if __name__=='__main__':unittest.main()
