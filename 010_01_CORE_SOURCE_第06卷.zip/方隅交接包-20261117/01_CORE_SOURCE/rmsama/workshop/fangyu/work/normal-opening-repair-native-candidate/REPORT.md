# 正常打开修复：独立两文件 native 草稿

状态：FROZEN_UNAUTHORIZED_DRAFT。`INSTALL_AUTHORIZED=False`、`GATE_PIN=None`；不构成 Root 签发或生产安装。仅消费作者已冻结保护空文件修复及 launcher 提示修复，不修改任何业务 SOURCE、既有公共 controls、原 native 回执或54。

父安装器：`work/source53-root-integration/guard-token-r2/native/install_native53.py`，14503 B / D08CF3FFB567C0CB2F942E7B1881E608660962EB07E906C3DBC56167599F8CC5。`blob/pin/expected/no_link_parent/prepared_temp/proof/absent` 七函数源码保持；保留EC86窄五thin文件+Python5守卫。未执行该守卫、查询进程或PID。

两个 existing targets：desktop H52父15623/1C919E94… → 16027/B4F6BE49…；current53launcher父5405/994ED84B… → 5949/01106E9C…。两候选未来路径固定在`work/source52-root-integration/empty-protection-r3`。50/51/53helpers和desktop_entry作为immutable，绝不替换。

GRAPH、gate、代码常量共同绑定作者`work/source52-empty-protection-candidate/PLAN.json` 2735/B48F569E…及`FROZEN.json` 5015/D689B2CA…；每次fresh及rollback重新验精确证据字节。独审flag不能代替固定payload/evidence。Root最终只需按独审结果填正新gate并将安装器INSTALL_AUTHORIZED、GATE_PIN绑定；其他函数字节无需改。

新独立public control拟为`work/normal-opening-repair-native-r1`。新receipt/FAILED为原audits目录下`normal-opening-repair-native-installed.json`及`normal-opening-repair-native-failed.json`，新backupbase为`backups/normal-opening-repair-native`。这些地址仅声明，未创建生产目录或回执。

原native52 raw1874/613E43C5…与native53 raw2175/644B8086…固定绑定；旧native52 c6cb…备份4626/AA029206…、native53 598bf…备份4985/E8138AD0…固定保留。新备份同时保存H52旧1C及launcher旧994E，不倒填旧raw。全部完整pins见GRAPH及FROZEN。

任何原50–53 business STARTED/FAILED/success共12项存在均拒绝，原native失败及本repair历史证据也拒绝。backup前、逐replace前、receipt seal前重新核controls/evidence/guard字节、全部targets当前父或已完成final、immutable、原raw、旧lineage与已写新parent backups，再调用窄absent。发生异常只在guard idle、固定依赖仍在且target仍为本次after时回滚；live/unknown、外来target/原raw漂移保持并记FAILED，禁止自动retry。

TDD实际公共边界为`main()`，未写镜像事务adapter。第一RED14595e→GREEN01dafa；payload证据缺失反例RED03cd1b→最终GREEN019b39。9 tests包含两文件成功/parentbackup+receipt、false或None授权0IO、live/unknown0mutation、全部12business证据早拒、第二replace失败idle回滚、rollback live/unknown拒、原raw漂移停止及held、既有repair证据拒、review flag缺固定payload证据拒。

测试全部在自有owned-runs临时目录，合成文件/权限pins；替代系统guard结果与OS replace故障边界。测试不调用真实guard、原安装器、query/PID、App/API/DB，未复跑旧业务QA。未验证真实占用检测或生产安装，也未把测试的合成idle当实际idle；崩溃断电恢复及并发外部改写不由本样例证明。

文件：C:/积木软件工坊/项目/方隅公寓客户版/work/normal-opening-repair-native-candidate/FROZEN.json
文件夹：C:/积木软件工坊/项目/方隅公寓客户版/work/normal-opening-repair-native-candidate
