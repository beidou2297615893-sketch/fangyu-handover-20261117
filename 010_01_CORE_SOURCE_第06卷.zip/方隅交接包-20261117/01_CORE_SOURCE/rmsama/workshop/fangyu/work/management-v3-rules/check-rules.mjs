import assert from 'node:assert/strict';
import {readFileSync,writeFileSync,existsSync} from 'node:fs';
import {render,bind} from '../ui-approved-implementation/ui-preview/pages/management-rules.mjs';
const results=[];
async function check(name,fn){await fn();results.push({name,ok:true});}
function fixture(){
 const keywords=[...Array.from({length:106},(_,i)=>({id:'p'+i,keyword:'门店租房'+i,eligible:true,bindings:[{materialKey:'m1',presetIds:['precise']}]})),...Array.from({length:3},(_,i)=>({id:'c'+i,keyword:'沿线通勤'+i,eligible:true,bindings:[{materialKey:'m1',presetIds:['commute']}]})),{id:'held',keyword:'待核价格',eligible:false,bindings:[{materialKey:'m1',presetIds:['precise','commute']}]}];
 return {connection:'connected',user:'fixture-admin',storeId:'s1',store:'验证门店',stores:[{id:'s1',name:'验证门店'},{id:'s2',name:'第二门店'}],busy:false,capabilities:{presets:true},catalog:{search:[{id:'precise',name:'精准获客'},{id:'commute',name:'通勤拓展'}],intent:[{id:'standard',name:'标准意向',description:'本机显示偏好；中央判断规则状态保持原值'},{id:'recent',name:'优先近期入住'},{id:'rental-evidence',name:'租房与预算',assessmentEnabled:false}]},selection:{storeId:'s1',searchPresetId:'precise',intentPresetId:'standard',revision:1},presets:{search:'precise',intent:'standard',materialKey:'m1',keywordIds:['p0']},materials:{currentSelection:{storeId:'s1',materialKey:'m1',selectedKeywordIds:['p0'],revision:0},materials:[{key:'m1',name:'验证资料',priceVerified:false,keywords}],rulesSummary:{enabled:false,priceVerified:false},intentRule:{enabled:false,currentPricesVerified:false,signals:['真实草稿依据一','真实草稿依据二'],budgetPrinciples:['保留客户预算原话与周期']}}};
}
class Element{
 constructor(dataset={},value=''){this.dataset=dataset;this.value=value;this.listeners={};}
 addEventListener(type,fn){this.listeners[type]=fn;}
 async fire(type,event={}){return this.listeners[type]?.({target:this,...event});}
}
function harness(state,actions={}){
 render(state);const elements=new Map(),groups=new Map(),calls=[],modals=[];
 const add=(selector,dataset={},value='')=>{const el=new Element(dataset,value);elements.set(selector,el);return el;};
 const search=state.catalog.search.map(item=>new Element({},item.id)),intent=state.catalog.intent.map(item=>new Element({},item.id));
 groups.set('[data-mr-search]',search);groups.set('[data-mr-intent]',intent);
 groups.set('[data-mr-detail]',['exclude','words','evidence','budget'].map(kind=>new Element({mrDetail:kind})));
 const store=add('[data-mr-store]',{},'s1'),switcher=add('[data-mr-switch]'),save=add('[data-mr-save]');
 const ctx={state,update:fn=>fn(state),actions:{selectStore:async id=>{calls.push(['store',id]);state.storeId=id;state.store='第二门店';},applyPreset:async()=>{calls.push(['save']);state.selection={storeId:state.storeId,searchPresetId:state.presets.search,intentPresetId:state.presets.intent,revision:state.selection.revision+1};},...actions},modal:options=>modals.push(options)};
 const root={querySelector:selector=>elements.get(selector)||null,querySelectorAll:selector=>groups.get(selector)||[]};
 const cleanup=bind(root,ctx);return {ctx,root,store,switcher,save,search,intent,details:groups.get('[data-mr-detail]'),calls,modals,cleanup};
}
await check('approved v3 structure, existing assets and conservative source status',()=>{
 const s=fixture(),html=render(s);assert.match(html,/mr-store-bar/);assert.match(html,/mr-columns/);assert.match(html,/mr-save-bar/);
 assert.match(html,/未提供统一排除项/);assert.match(html,/中央规则未启用/);assert.match(html,/待核实/);assert.doesNotMatch(html,/中介同行|招聘|<svg|style=/);
 assert.match(html,/value="rental-evidence"[^>]*disabled/);
 const refs=[...html.matchAll(/src="\/assets\/([^"]+)"/g)].map(m=>m[1]);
 const base=new URL('../ui-approved-implementation/ui-preview/assets/',import.meta.url),fallback=new URL('../ui-runtime-r56/src/web/workspace/assets/',import.meta.url);
 assert(refs.every(name=>existsSync(new URL(name,base))||existsSync(new URL(name,fallback))));
});
await check('search picks only current eligible matching bindings, <=100, leaves every source word intact',async()=>{
 const s=fixture(),original=JSON.stringify(s.materials),h=harness(s);
 await h.search[0].fire('click');assert.equal(s.presets.keywordIds.length,100);assert(s.presets.keywordIds.every(id=>id.startsWith('p')));
 await h.search[1].fire('click');assert.deepEqual(s.presets.keywordIds,['c0','c1','c2']);assert.equal(s.presets.search,'commute');assert.equal(JSON.stringify(s.materials),original);
});
await check('default initial source selection uses bounded matching words without mutating source',async()=>{
 const s=fixture();s.presets.keywordIds=[];s.materials.currentSelection.selectedKeywordIds=[];
 const h=harness(s);assert.match(render(s),/100个搜索词/);await h.save.fire('click');assert.equal(s.presets.keywordIds.length,100);assert.equal(s.materials.materials[0].keywords.length,110);
});
await check('only exposed enabled intent choices can be selected',async()=>{
 const s=fixture(),h=harness(s);await h.intent[2].fire('click');assert.equal(s.presets.intent,'standard');await h.intent[1].fire('click');assert.equal(s.presets.intent,'recent');
});
await check('store dropdown and switch use existing action with an authorized store only',async()=>{
 const s=fixture(),h=harness(s);h.store.value='s2';await h.store.fire('change');await h.switcher.fire('click');assert.deepEqual(h.calls,[['store','s2']]);
 const other=fixture(),g=harness(other);g.store.value='not-authorized';await g.store.fire('change');await g.switcher.fire('click');assert.equal(g.calls.length,0);
});
await check('save reuses existing apply action and confirms actual revision receipt',async()=>{
 const s=fixture(),h=harness(s);await h.save.fire('click');assert.deepEqual(h.calls,[['save']]);assert.equal(s.managementRules.phase,'saved');assert.match(render(s),/方案已保存/);
});
await check('no receipt or rejected save stays a concise failure and never reports success',async()=>{
 const s=fixture(),h=harness(s,{applyPreset:async()=>undefined});await h.save.fire('click');assert.equal(s.managementRules.phase,'error');assert.match(render(s),/保存结果待确认/);assert.doesNotMatch(render(s),/方案已保存/);
 const t=fixture(),g=harness(t,{applyPreset:async()=>{throw new Error('保存失败');}});await g.save.fire('click');assert.equal(t.managementRules.phase,'error');assert.match(render(t),/保存失败/);
});
await check('loading/empty/no material/stale store disable save rather than fabricate data',()=>{
 for(const adjust of [s=>{s.connection='loading';},s=>{s.stores=[];s.storeId='';},s=>{s.materials.materials=[];},s=>{s.materials.currentSelection.storeId='other';},s=>{s.materials.currentSelection.materialKey='other';}]){
  const s=fixture();adjust(s);const html=render(s);assert.match(html,/data-mr-save disabled/);assert.doesNotMatch(html,/古北店|预算3500/);
 }
});
await check('busy and detached/stale actor handlers cannot apply or change intent',async()=>{
 const s=fixture(),h=harness(s);s.busy=true;await h.save.fire('click');await h.intent[1].fire('click');assert.equal(h.calls.length,0);assert.equal(s.presets.intent,'standard');
 s.busy=false;s.storeId='s2';await h.intent[1].fire('click');assert.equal(s.presets.intent,'standard');h.cleanup();await h.save.fire('click');assert.equal(h.calls.length,0);
});
await check('real source details are escaped, short and use modal only',async()=>{
 const s=fixture();s.materials.intentRule.signals=['<script>草稿</script>'];const h=harness(s);
 for(const el of h.details)await el.fire('click');assert.equal(h.modals.length,4);
 assert.match(h.modals.find(item=>item.title==='判断依据').html,/&lt;script&gt;/);assert.doesNotMatch(h.modals.find(item=>item.title==='判断依据').html,/<script>/);
 assert.match(h.modals.find(item=>item.title==='排除内容').html,/未提供统一排除项/);assert.match(h.modals.find(item=>item.title==='预算依据').html,/尚未核实/);
});
await check('long source values stay in bounded column scroll and never create inline brands',()=>{
 const s=fixture();s.materials.materials[0].keywords[0].keyword='很长的实际源关键词'.repeat(200);
 const html=render(s),css=readFileSync(new URL('../ui-approved-implementation/ui-preview/pages/management-rules.css',import.meta.url),'utf8');
 assert.match(html,/很长的实际源关键词/);assert.doesNotMatch(html,/style=|<svg/);
 assert.match(css,/height:calc\(784px \* var\(--space-y,1\)\)/);assert.match(css,/mr-column-content\{[^}]*min-height:0;overflow:auto/);assert.match(css,/overflow-wrap:anywhere/);
});
const result={passed:results.length,checks:results,scope:'Synthetic render and stub interactions only; no browser, real customer data, cloud or platform requests. Root owns route/shell/CSS loading and browser visual QA.'};
writeFileSync(new URL('./checks.json',import.meta.url),JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result,null,2));

