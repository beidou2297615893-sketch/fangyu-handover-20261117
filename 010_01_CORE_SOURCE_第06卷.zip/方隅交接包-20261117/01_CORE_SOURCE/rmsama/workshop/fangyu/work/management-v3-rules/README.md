# 获客规则 v3 · 作者固定回执

2026-10-17。只新增management-rules.mjs/css，实际查看已认可01-获客规则-v3.png后实现。完整文件哈希与接口见FIXED-RECEIPT.json。已固定并停写。

11项合成render/交互stub/CSS约束检查、JS语法通过；没有开浏览器、访问真实客户、调用云或平台。视觉QA尚待根冻结组合并同尺寸对照，不能把这些fixture写为用户已验收真实界面。

最小接口：现有ctx.actions.selectStore、ctx.actions.applyPreset、ctx.modal和ctx.update。不需要新增backend。applyPreset当前成功会navigate acquire；模块沿用该行为，保存成功只依据明确返回或selection revision的真实回执；吞掉异常且无回执时显示未确认，不假成功。

数据核验来源：ui-preview/pages/presets.mjs、ui-preview/app.mjs acceptBootstrap/selectStore/applyPreset、ui-native-r57/workbench_backend.py _catalog/_bootstrap、store_materials.py catalog/_chosen_keywords/_public_selection。当前公开state没有统一exclude字段；排除区为不可编辑的短概览。中央规则enabled=false与未核价状态保留，租房与预算disabled不开放。不改Core过滤逻辑。

搜索模式变更默认取当前material中eligible且bindings包含该preset的前100词；所有原始material/keywords和其他源词未变。空态/加载/缺材料/无权门店/禁用意向禁保存，切店/保存中禁重复操作，旧scope或已卸载handler不再修改当前方案。

外壳由根连接rules路由、CSS与品牌摄影。模块body为784×space-y；列内容内滚、底部保存栏固定。根已确认heading175×space-y并隐藏rules全局footer。引用现有图标、tokens与字体，没有自造品牌或inline SVG。

