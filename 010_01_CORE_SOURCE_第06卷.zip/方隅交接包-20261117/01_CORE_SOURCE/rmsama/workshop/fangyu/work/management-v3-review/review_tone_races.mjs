// Read-only product audit. Extract unchanged app functions and control only async responses.
import assert from 'node:assert/strict';
import {readFileSync,writeFileSync,copyFileSync,existsSync} from 'node:fs';
import path from 'node:path';
import {fileURLToPath,pathToFileURL} from 'node:url';
import vm from 'node:vm';
import {createHash} from 'node:crypto';
const HERE=path.dirname(fileURLToPath(import.meta.url)),ROOT=path.resolve(HERE,'../..');
const UI=path.join(ROOT,'work/ui-approved-implementation/ui-preview');
const source=readFileSync(path.join(UI,'app.mjs'),'utf8');
const tone=await import(pathToFileURL(path.join(UI,'pages/management-tone.mjs')));
const backendModule=await import(pathToFileURL(path.join(UI,'backend.mjs')));
const prefs=(revision,identity='fixture identity',storeId='store-a')=>({actor:{username:'admin-a',storeId},
 revision,identity,tone:'friendly',salutation:'你好',focus:['budget','moveIn','housing']});
const choice=(identity='fixture identity',expectedRevision=0)=>({expectedRevision,identity,tone:'friendly',salutation:'你好',focus:['budget','moveIn','housing']});
const state=()=>({connection:'connected',user:'admin-a',storeId:'store-a',store:'Store A',session:{user:{username:'admin-a',role:'admin'}},
 page:'tone',busy:false,stores:[{id:'store-a',name:'Store A'},{id:'store-b',name:'Store B'}],tonePreferences:prefs(0)});
const deferred=()=>{let resolve,reject;const promise=new Promise((a,b)=>{resolve=a;reject=b;});return {promise,resolve,reject};};
const boot=storeId=>({session:{user:{username:'admin-a',role:'admin'}},stores:[{id:'store-a',name:'Store A'},{id:'store-b',name:'Store B'}],selection:{storeId},catalog:{search:[],intent:[]}});
function harness(backend,s=state()){
 const code=source.slice(source.indexOf('function acceptBootstrap('),source.indexOf('function showActionError('))+'\n'+
  source.slice(source.indexOf('let toneReadGeneration='),source.indexOf('async function checkAccount('))+'\n'+
  'globalThis.api={readTonePreferences,saveTonePreferences,acceptBootstrap};';
 const errors=[],context={state:s,backend,document:{getElementById:()=>({close(){}})},render(){},
  actorKey:()=>JSON.stringify([s.user,s.storeId||'']),
  platformActorMatches:(value,key)=>Boolean(value?.actor&&JSON.stringify([value.actor.username,value.actor.storeId||''])===key),
  showActionError:error=>errors.push({message:error.message,code:error.code}),verifyPending:async()=>{},console};
 vm.runInNewContext(code,context,{filename:'app-extracted-tone-audit.mjs'});
 return {s,api:context.api,errors};
}
const cases=[];
async function record(name,fn){try{cases.push({name,...await fn()});}catch(error){cases.push({name,status:'AUDIT_ERROR',error:error.stack});}}

await record('read generation blocks same-actor out-of-order reads',async()=>{
 const a=deferred(),b=deferred();let index=0;
 const h=harness({tonePreferencesRead:()=>[a,b][index++].promise});
 const first=h.api.readTonePreferences(),second=h.api.readTonePreferences();
 b.resolve({preferences:prefs(2,'new')});await second;
 a.resolve({preferences:prefs(1,'old')});assert.equal(await first,null);assert.equal(h.s.tonePreferences.revision,2);
 return {status:'PASS'};
});
await record('read A to B to A is blocked by bootstrap generation',async()=>{
 const old=deferred();const h=harness({tonePreferencesRead:()=>old.promise});
 const reading=h.api.readTonePreferences();h.api.acceptBootstrap(boot('store-b'));h.api.acceptBootstrap(boot('store-a'));
 h.s.tonePreferences=prefs(2,'current A');old.resolve({preferences:prefs(0,'old A')});
 assert.equal(await reading,null);assert.equal(h.s.tonePreferences.revision,2);return {status:'PASS'};
});
await record('older in-flight read can roll back successful save cache',async()=>{
 const oldRead=deferred();const h=harness({tonePreferencesRead:()=>oldRead.promise,
  tonePreferencesSave:async()=>({preferences:prefs(1,'saved identity')})});
 const reading=h.api.readTonePreferences();await h.api.saveTonePreferences(choice('saved identity'));
 assert.equal(h.s.tonePreferences.revision,1);
 oldRead.resolve({preferences:prefs(0,'old identity')});await reading;
 return {status:h.s.tonePreferences.revision===0?'REPRODUCED_P2':'PASS',actualRevision:h.s.tonePreferences.revision,
  expectedRevision:1,actualIdentity:h.s.tonePreferences.identity,file:'app.mjs',lines:'340-345,354-357'};
});
await record('save A to B to A can roll back freshly read A cache',async()=>{
 const oldSave=deferred();const h=harness({tonePreferencesSave:()=>oldSave.promise});
 const saving=h.api.saveTonePreferences(choice('old accepted save'));
 h.api.acceptBootstrap(boot('store-b'));h.api.acceptBootstrap(boot('store-a'));
 h.s.tonePreferences=prefs(2,'current A revision 2');
 oldSave.resolve({preferences:prefs(1,'old accepted save')});await saving;
 return {status:h.s.tonePreferences.revision===1?'REPRODUCED_P2':'PASS',actualRevision:h.s.tonePreferences.revision,
  expectedRevision:2,actualIdentity:h.s.tonePreferences.identity,file:'app.mjs',lines:'352-357'};
});
await record('read started during pending save cannot overwrite successful save when returned later',async()=>{
 const savingResponse=deferred(),readingResponse=deferred();
 const h=harness({tonePreferencesSave:()=>savingResponse.promise,tonePreferencesRead:()=>readingResponse.promise});
 const saving=h.api.saveTonePreferences(choice('saved identity'));
 const reading=h.api.readTonePreferences();
 savingResponse.resolve({preferences:prefs(1,'saved identity')});await saving;
 readingResponse.resolve({preferences:prefs(0,'old identity')});assert.equal(await reading,null);
 assert.equal(h.s.tonePreferences.revision,1);assert.equal(h.s.tonePreferences.identity,'saved identity');
 assert.equal(h.s.tonePreferencesLoading,false);return {status:'PASS'};
});
await record('higher revision read during save is retained when lower save result returns',async()=>{
 const pending=deferred();const h=harness({tonePreferencesSave:()=>pending.promise,
  tonePreferencesRead:async()=>({preferences:prefs(2,'newer revision')})});
 const saving=h.api.saveTonePreferences(choice('older save'));
 await h.api.readTonePreferences();pending.resolve({preferences:prefs(1,'older save')});
 assert.equal(await saving,null);assert.equal(h.s.tonePreferences.revision,2);
 assert.equal(h.s.tonePreferences.identity,'newer revision');assert.match(h.s.tonePreferencesError,/已有更新/);
 return {status:'PASS'};
});
await record('save A to B to A stale authentication failure cannot affect new A session',async()=>{
 const pending=deferred();const h=harness({tonePreferencesSave:()=>pending.promise});
 const saving=h.api.saveTonePreferences(choice());h.api.acceptBootstrap(boot('store-b'));h.api.acceptBootstrap(boot('store-a'));
 h.s.tonePreferences=prefs(2,'current A');const error=new Error('old session expired');error.code='AUTH_REQUIRED';
 pending.reject(error);assert.equal(await saving,null);assert.equal(h.errors.length,0);
 assert.equal(h.s.session.user.username,'admin-a');assert.equal(h.s.tonePreferences.revision,2);return {status:'PASS'};
});
await record('unknown-save bootstrap recovery A to B to A stops before old bootstrap or read applies',async()=>{
 const bootstrap=deferred();let reads=0;
 const h=harness({tonePreferencesSave:async()=>{const error=new Error('unknown');error.code='RESULT_UNCONFIRMED';throw error;},
  bootstrap:()=>bootstrap.promise,tonePreferencesRead:async()=>{reads++;return {preferences:prefs(1)};}});
 const saving=h.api.saveTonePreferences(choice());await Promise.resolve();
 h.api.acceptBootstrap(boot('store-b'));h.api.acceptBootstrap(boot('store-a'));h.s.tonePreferences=prefs(2,'current A');
 bootstrap.resolve(boot('store-a'));assert.equal(await saving,null);assert.equal(reads,0);
 assert.equal(h.s.tonePreferences.revision,2);assert.equal(h.errors.length,0);return {status:'PASS'};
});
await record('CAS conflict keeps draft but exposes no reload action',async()=>{
 const h=harness({tonePreferencesSave:async()=>{const error=new Error('IP口吻已在其他窗口更新，请重新读取');error.code='TONE_REVISION_CONFLICT';throw error;}});
 const s=h.s;tone.render(s);
 const fields=new Map();
 for(const name of ['identity','salutation','preview','feedback','summary','form','save','reset','reload','store','switch']){
  fields.set(`[data-mt-${name}]`,{value:s.toneDraft[name]||'',listeners:{},classList:{toggle(){}},
   addEventListener(event,handler){this.listeners[event]=handler;},setAttribute(){}});
 }
 const root={ownerDocument:{activeElement:null},querySelector:key=>fields.get(key)||null,querySelectorAll:()=>[]};
 tone.bind(root,{state:s,actions:{saveTonePreferences:h.api.saveTonePreferences},update:fn=>{fn(s);tone.render(s);}});
 const identity=fields.get('[data-mt-identity]');identity.value='unsaved identity';identity.listeners.input({target:identity});
 await fields.get('[data-mt-form]').listeners.submit({preventDefault(){}});
 assert.equal(h.errors.at(-1).code,'TONE_REVISION_CONFLICT');
 const html=tone.render(s);
 return {status:!html.includes('data-mt-reload')?'REPRODUCED_P2':'PASS',draftRetained:s.toneDraft.identity==='unsaved identity',
  errorVisible:html.includes('IP口吻已在其他窗口更新'),reloadVisible:html.includes('data-mt-reload'),
  file:'pages/management-tone.mjs',lines:'80,133-140'};
});
await record('unknown local save checks persisted revision and exact values without resubmitting',async()=>{
 let saves=0,reads=0;const s=state();
 const h=harness({tonePreferencesSave:async()=>{saves++;const e=new Error('unknown');e.code='RESULT_UNCONFIRMED';throw e;},
  bootstrap:async()=>boot('store-a'),tonePreferencesRead:async()=>{reads++;return {preferences:prefs(1,'saved identity')};}},s);
 const saved=await h.api.saveTonePreferences(choice('saved identity'));
 assert.equal(saved.revision,1);assert.equal(saves,1);assert.equal(reads,1);return {status:'PASS'};
});
await record('transport permits tone read during unknown mutation and blocks repeat mutation',async()=>{
 let posts=0;const requests=[];
 const client=backendModule.createBackend(async(url,options)=>{
  requests.push({url,options});if(url==='/api/workbench/bootstrap')return {ok:true,status:200,json:async()=>({ok:true,csrfToken:'fixture-csrf'})};
  const body=JSON.parse(options.body);if(body.action==='tone_preferences_save'){posts++;throw Error('synthetic response lost');}
  return {ok:true,status:200,json:async()=>({ok:true,preferences:prefs(1)})};
 });
 await client.bootstrap();await assert.rejects(client.tonePreferencesSave({storeId:'store-a',...choice()}),e=>e.code==='RESULT_UNCONFIRMED');
 assert.equal(client.unconfirmed,true);await client.tonePreferencesRead({storeId:'store-a'});
 await assert.rejects(client.tonePreferencesSave({storeId:'store-a',...choice()}),e=>e.code==='RESULT_UNCONFIRMED');
 assert.equal(posts,1);assert.equal(requests.at(-1).options.method,'POST');
 assert.equal(requests.at(-1).options.headers['X-Fangyu-CSRF'],'fixture-csrf');return {status:'PASS'};
});
const productFiles=['app.mjs','backend.mjs','pages/management-tools.mjs','pages/management-tone.mjs','pages/reply-connected.mjs'];
const report={status:cases.every(x=>x.status==='PASS')?'PASS':cases.some(x=>x.status==='REPRODUCED_P2')?'FINDINGS':'AUDIT_ERROR',scope:'Only new tone integration; no product writes, instance, network or cloud.',
 cases,files:productFiles.map(file=>({path:path.join(UI,file),sha256:createHash('sha256').update(readFileSync(path.join(UI,file))).digest('hex')})),
 contract:{hostActions:['tone_preferences_read','tone_preferences_save'],
  requestRead:['storeId'],requestSave:['storeId','expectedRevision','identity','tone','salutation','focus'],
  responseEnvelope:'preferences.actor + revision + identity/tone/salutation/focus',
  consistent:true,backendGuardEvidence:'work/management-v3-backend/HANDOFF.json'},
 product_sources_modified:false,instance_started:false,cloud_calls:false};
const output=path.join(HERE,'TONE-COMPOSITION-REVIEW.json'),initial=path.join(HERE,'INITIAL-FINDINGS.json');
if(existsSync(output)&&!existsSync(initial))copyFileSync(output,initial);
writeFileSync(output,JSON.stringify(report,null,2));
console.log(JSON.stringify(report,null,2));
if(cases.some(x=>x.status==='AUDIT_ERROR'))process.exitCode=1;
