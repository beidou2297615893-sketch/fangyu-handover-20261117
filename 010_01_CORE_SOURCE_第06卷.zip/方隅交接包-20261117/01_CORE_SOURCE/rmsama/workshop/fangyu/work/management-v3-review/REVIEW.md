# 本批IP口吻组合独立复核

最终结论：根修复后的11项定点组合检查全部通过，初审3条P2均已关闭，无本次新增的未解决P0/P1/P2。本次只读产品文件，未启动实例或连接云。

追加浏览器核验说明：根在9f2521ef验收中发现CAS409后的普通鼠标自动点击短“重新读取”按钮失准；Enter与force点击均弹出未保存确认，确认后真实读取最新revision。根定位到第二tab引起工具坐标不一致：DOM报1586×992，截图实际953×992且横向截断。此项记录为自动化坐标局限，无新增产品缺陷证据；详见RELOAD-MOUSE-CHECK.json。Node夹具仅覆盖状态/竞态与入口渲染，不声称覆盖原生指针几何。

复验：运行本目录 `review_tone_races.mjs`（Node内置vm提取原app函数、原tone.render/bind和原backend.mjs；仅控制合成异步响应）。最终结果见 TONE-COMPOSITION-REVIEW.json，包含对应产品文件的SHA256。当前最终通过的app为16ea26fd8320ec87efa179e38969f29c55a7ce0a6c53ed799ea90128c0104396，tone为5cb5279067a85c114a2f1ed1e4140646bf5b1910c2bb71862b05245f2dd7c16c。初审原始证据保留INITIAL-FINDINGS.json；下述三项为已关闭历史问题。

修复复核覆盖：保存前已存在读取、保存期间新发且晚于保存返回的读取、保存期间已取得更高revision、保存A→B→A旧成功/旧认证失败、unknown-save恢复bootstrap A→B→A、CAS409保草稿且显示重读入口。所有场景通过；未知变更仍只读核对不重发。

## [P2] 旧读取响应可回滚刚保存的全局口吻

app.mjs 340–345只用toneReadGeneration保护读取；354–357保存成功没有使已有读取失效，也没有拒绝低于当前缓存的revision。复现顺序：read(rev0)在途→save(rev1)成功→旧read返还；最终全局tonePreferences从rev1降为rev0，identity回到旧值。管理页自己的draft引用可能保留新值，但reply-connected.mjs按actor匹配后直接使用全局prefs，回复身份会暂时回退。

建议在保存开始与成功后处理在途读取，并用共享scope epoch/读写代次和revision单调检查阻止降级。只在保存开始递增读generation仍不足以覆盖保存期间新发读取的情况。

## [P2] 保存结果在A→B→A后可覆盖较新A方案

app.mjs 352–357保存只捕获actorKey字符串。复现：A保存(rev1)在途→acceptBootstrap切B→切回A→已读取A rev2→旧A保存响应rev1返还；actor字符串重新相等，当前全局rev2被降到rev1。读路径的toneReadGeneration挡住相同ABA场景；保存路径没有同等epoch检查。陈旧错误回调也应一起挡住，避免影响当前重新登录的同名身份。

## [P2] CAS冲突提示重新读取，但页面未提供重读入口

management-tone.mjs表单保存经真实app.saveTonePreferences返回TONE_REVISION_CONFLICT后，只设置d.error，loadStatus保持ready，缓存revision仍旧。render只有loadStatus=error或已知更新revision时显示data-mt-reload。复现中未保存文字保留、冲突文字可见，但reload按钮不存在；用户只能反复冲突或自行切店/刷新。

建议为CAS冲突明确提供保留当前草稿的重新读取操作，继续复用现有丢弃草稿确认；不要自动覆盖未保存文本。

## 已通过

- read同actor乱序、read A→B→A迟到均被generation挡住。
- 未确认保存通过bootstrap+read核对expectedRevision+1和逐字段相等，整个流程没有重发save。
- backend.mjs将tone read识别为只读，未确认变更后仍可读、禁止再次变更；POST同源CSRF头和动作形状正确。
- 前端tone_preferences_read/save动作、host.API_ACTIONS、WorkbenchBackend请求字段与preferences响应形状一致；后台真admin写、operator按中央门店读、当前选择与session事务复查及CAS沿用已通过的8项真实Backend隔离证据。
- management-tools本地预览/复制/应用不调用保存或发送；应用保留当前actor/store/customer/comment/generation/sourceDigest/replyId/version/text/dirty与模态框owner检查，回复编辑框写入后仍须保存/审核/最终授权。
- 本次未修改app/backend/management-tools/reply-connected/host或后台源码。
