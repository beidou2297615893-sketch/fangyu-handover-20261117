"""Consistent, credential-free business backup and manual-reply read projection.

Production is opened SQLite mode=ro/query_only; no App/Core constructors,
no account checks, provider calls, collection or sending.
"""
from pathlib import Path
from collections import Counter
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import sqlite3
import sys
import threading

sys.dont_write_bytecode = True
sys.stdout.reconfigure(encoding='utf-8')
P = Path(r'C:/积木软件工坊/项目/方隅公寓客户版')
W = Path(__file__).resolve().parent
F = P/'work/parallel-integration-20261018/final-integration/candidate-unified-v99'
stage = json.loads((F/'STAGED.json').read_text('utf-8'))
N = Path(stage['release'])
helper = P/'work/complete-product-resume-20261024/live-review-deployment-20261024/data-preflight/review_safety.py'
spec = importlib.util.spec_from_file_location('manual_reply_readonly_safety', helper)
s = importlib.util.module_from_spec(spec)
spec.loader.exec_module(s)
s.PROJECT = F/'project'
s.RELEASE = N
binding_raw = s.read_plain(s.BINDING, 65536)
assert s.sha(binding_raw) == s.BINDING_SHA
binding = json.loads(binding_raw)
data = Path(binding['data_dir'])
archive_raw = s.read_plain(data/'codex-reviews/latest.json')
scope = s.scope(binding, json.loads(archive_raw))
run = W/'private'/datetime.now(timezone.utc).strftime('snapshot-%Y%m%dT%H%M%S%fZ')
run.mkdir(parents=True, exist_ok=False)

business_entities = ('leads','tasks','replies','ai_cache','rental_assessments_v1',
    'rental_task_context_v1','ui_reply_requests_v1','ui_reply_delivery_v1','reply_queues',
    'ui_workbench_preferences_v1','ui_workbench_store_presets_v2','ui_workbench_tone_preferences_v1')

class RestrictedStore(s.ReadOnlyStore):
    def list(self, entity, tenant=None):
        extra = {'rental_task_context_v1':('id','tenant_id','owner','store_id'),
            'customer_outcome_events':('id','tenant_id','owner','userId','storeId','platform',
                'customerId','version','operation','targetEventId','kind')}
        if entity not in extra:
            return super().list(entity, tenant)
        selected = ','.join("'"+k+"',json_extract(body,'$."+k+"')" for k in extra[entity])
        sql = 'SELECT json_object('+selected+') FROM records WHERE entity=?'
        args = [entity]
        if tenant is not None:
            sql += ' AND tenant_id=?'
            args.append(tenant)
        return [json.loads(row[0]) for row in self.db.execute(sql,args)]

db = sqlite3.connect((data/'workspace.sqlite3').as_uri()+'?mode=ro',uri=True,timeout=3)
db.row_factory = sqlite3.Row
try:
    db.execute('PRAGMA query_only=ON')
    db.execute('BEGIN')
    before = s.protected(db,scope['tenantId'],scope['owner'])
    backup = {'capturedAtUtc':datetime.now(timezone.utc).isoformat(),'scope':scope,
        'productionSourceReadOnly':True,'credentialsOrSessionsIncluded':False,'records':[],'tables':{}}
    counts = {}
    for entity in business_entities:
        rows = db.execute('SELECT entity,id,tenant_id,body FROM records WHERE tenant_id=? AND entity=? ORDER BY id',
            (scope['tenantId'],entity)).fetchall()
        counts[entity] = len(rows)
        backup['records'].extend(dict(row) for row in rows)
    for table in ('unique_leads','contact_events'):
        sql = 'SELECT * FROM '+table+' WHERE tenant_id=?'
        args = [scope['tenantId']]
        if table == 'contact_events':
            sql += ' AND cloud_owner=?'
            args.append(scope['owner'])
        backup['tables'][table] = [dict(row) for row in db.execute(sql,args)]
    backup_path = run/'customer-business-backup.json'
    backup_path.write_text(json.dumps(backup,ensure_ascii=False,separators=(',',':'))+'\n','utf-8')
    for name in ('latest.json','supplemental-v2.json'):
        raw = s.read_plain(data/'codex-reviews'/name)
        (run/('archived-review-'+name)).write_bytes(raw)
    accounts = [dict(row) for row in db.execute("SELECT id,json_extract(body,'$.platform') AS platform,"
        "json_extract(body,'$.store_id') AS storeId,json_extract(body,'$.status') AS status,"
        "json_extract(body,'$.name') AS name FROM records WHERE entity='accounts' AND tenant_id=? "
        "AND json_extract(body,'$.cloud_owner')=? ORDER BY id",(scope['tenantId'],scope['owner']))]
    (run/'account-metadata-only.json').write_text(json.dumps(accounts,ensure_ascii=False,indent=2)+'\n','utf-8')

    # Reuse the already-verified local read model with a single RO transaction.
    _, Core, Workbench, Reply = s.modules()
    from customer_read_store import ReadRequestStore, _READ_SNAPSHOT
    restricted = RestrictedStore(db,data)
    restricted.path = data/'workspace.sqlite3'
    token = _READ_SNAPSHOT.set((restricted.path.resolve(),db))
    core = Core.__new__(Core)
    core.lock = threading.RLock()
    core.store = ReadRequestStore(restricted)
    company = json.loads((s.PROJECT/'work/app/company.json').read_text('utf-8'))
    wb = Workbench(core,company,s.PROJECT)
    user = next(row for row in core.store.list('users',wb.tenant)
        if row['username']==binding['owner'] and row['cloud_bound'])
    if user['role']=='admin':
        user['_workbench_store_id'] = scope['storeId']
    projected, stats = wb._matching(user,scope['storeId'],wb._options({'platform':'xiaohongshu'}))
    people = [item for _,item in projected]
    high = [item for item in people if item['intentLevel']=='high']
    illegal = sorted({key for item in people for key in item
        if key.startswith(('codex','priority','automatic','followup'))})
    assert not illegal
    preserved_keys = ('id','name','quote','level','intentLevel','analysisStatus','contactState','representativeLeadId')
    (run/'manual-reply-high-people.json').write_text(json.dumps([
        {k:item.get(k) for k in preserved_keys} for item in high],ensure_ascii=False,indent=2)+'\n','utf-8')
    selected = high[0] if high else people[0]
    detail = wb.detail(user,scope['storeId'],selected['id'],platform='xiaohongshu')
    reply = Reply(core,wb).read(user,scope['storeId'],selected['id'],platform='xiaohongshu')
    selected_detail = {k:reply.get(k) for k in ('canSave','canReview','reason','state') if k in reply}
    selected_detail['returnedKeys'] = list(reply.keys())
    manual_ready = []
    for person in high:
        response = Reply(core,wb).read(user,scope['storeId'],person['id'],platform='xiaohongshu')
        usable = [c for c in response['comments'] if c.get('canSave') and c.get('accounts')]
        manual_ready.append({'customerId':person['id'],'comments':len(response['comments']),
            'readableAndDraftable':bool(usable),'draftableComments':len(usable),
            'eligibleAccounts':len({a['id'] for c in usable for a in c['accounts']}),
            'blockedReasons':sorted({c.get('reason','') for c in response['comments']
                if not c.get('canSave') and c.get('reason')})})
    (run/'manual-reply-readiness.json').write_text(json.dumps(manual_ready,ensure_ascii=False,indent=2)+'\n','utf-8')
    after = s.protected(db,scope['tenantId'],scope['owner'])
    assert before == after
finally:
    if 'token' in locals():
        _READ_SNAPSHOT.reset(token)
    db.close()

report = {'status':'PASS_PRODUCTION_READ_ONLY_BACKUP_AND_CUSTOMER_PROJECTION',
    'atUtc':datetime.now(timezone.utc).isoformat(),'releaseId':stage['release_id'],
    'businessCounts':counts,'customers':len(people),
    'softwareIntentCounts':dict(Counter(item['intentLevel'] for item in people)),
    'highPeople':len(high),'highContactStates':dict(Counter(item['contactState'] for item in high)),
    'manualReplyReadReadyPeople':sum(r['readableAndDraftable'] for r in manual_ready),
    'manualReplyReadBlockedPeople':sum(not r['readableAndDraftable'] for r in manual_ready),
    'accountMetadata':accounts,'selectedReplyRead':selected_detail,
    'softwareCodexOrPriorityFields':illegal,'businessBefore':before,'businessAfter':after,
    'backup':str(backup_path),'backupSha256':s.sha(backup_path.read_bytes()),
    'coreOrBackendConstructedOnFormalDb':False,'credentialsOrSessionsSelected':False,
    'productionWrites':0,'platformOrProviderOrSendCalls':0}
(W/'FORMAL-DATA-AND-MANUAL-REPLY.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n','utf-8')
print(json.dumps({k:v for k,v in report.items() if k not in
    ('businessBefore','businessAfter','accountMetadata')},ensure_ascii=False))
