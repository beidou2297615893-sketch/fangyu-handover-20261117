# 前端独立核对：发送账号选择

只读核对F99，并在本目录形成一个最小候选补丁。没有修改冻结包、正式入口、运行数据或用户窗口；没有采集、发送、发布、调用平台、恢复Codex筛选。

## 已复现的阻碍

在单条回复里选择第二个发送账号后，编辑草稿再点“保存草稿”或“保存并核对”，保存回执经 `accept → choose` 把已选账号改回草稿审核账号或账号列表第一项。随后确认框显示被换掉的账号。无脏值刷新、显式清空账号、已选账号在回执中不可用，也存在静默替换。

最小失败步骤：双账号甲/乙 → 选择乙 → 修改正文 → 保存 → 后台保存正文正确，但界面账号变回甲。F99定向8项中5项失败，失败原因均可在 `red/SENDER-SELECTION.json` 看到。

## 候选修正

仅在 `web/pages/reply-connected.mjs` 的 `accept` 新增两行：记录当前原评论的账号选择；接受同一原评论的新回执后，仍有该账号时保留，账号失效或本人明确清空则保持未选择。首次读取或切换到其他原评论沿用原流程。没有添加UI或业务功能。

- 可复用补丁：`SENDER-SELECTION.patch`
- 完整候选文件：`candidate/web/pages/reply-connected.mjs`
- 原SHA256：`3123601746dc39a7fae081c2c1c54db5e1962291cbb994009673d21bfda30b7f`
- 候选SHA256：`92bda4b28c8fe91ae3ae789c137e14a940a16ce68e1ffc2dbeb521267b1476f5`
- 131个Web文件逐个比对，仅上述文件不同，见 `CANDIDATE-PINS.json`。

## 本轮验证

- F99既有回归：45/45，通过；含16项可见性矩阵，源pins完全吻合。证据 `baseline/DOM-REQUESTS.json`。
- 定向RED：3/8通过、5项已复现失败；定向候选GREEN：8/8通过。证据 `red/SENDER-SELECTION.json` 和 `green/SENDER-SELECTION.json`。
- 候选再跑原回归：45/45，通过；含原16矩阵。证据 `candidate-regression/DOM-REQUESTS.json`。这里复用原脚本但未复制旧pins，因此其 `sourcePinsMatch=null`；候选与F99的真实差异单列在 `CANDIDATE-PINS.json`，不能称旧pins吻合。
- 保存成功后再切账号，仍要求核对新账号；旧账号已审核草稿换账号，也需新确认。确认框打开后再切账号，旧确认被拒绝。三项都没有调用模拟review/delivery端口，没有留下pending或未知发送状态。
- 所有验证为headless合成页面。真实API请求0、外联0、生产访问0、可见浏览器窗口0。模拟保存仅修改合成对象，不写正式DB。

## 仍未验证

本轮不操作本人Native窗口或真实平台，因此不能写成人工验收、实际账号发送成功、客户统计已由本轮核验。用户现有DeepSeek/人工分析和高意向133位由Root的数据核对负责，本代理未读生产DB、未重新分析或修改筛选结果。批量统一账号逻辑只做源码查看，本轮未扩大重复测试。候选未安装，是否合入与入口更新由Root统一处理。
