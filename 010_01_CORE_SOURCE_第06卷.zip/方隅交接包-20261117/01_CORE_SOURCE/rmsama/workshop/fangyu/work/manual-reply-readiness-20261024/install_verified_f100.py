"""Reviewed next-open sender-selection fix; no runtime restart or business writes."""
from pathlib import Path
import hashlib
import importlib.util
import json
import sys

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
P = W.parents[1]
N = P/'work/ui-native-r57'
PACK = W/'package'
F = P/'work/parallel-integration-20261018/final-integration/candidate-unified-v100'
GEN = P/'work/parallel-integration-20261018/integration/entry/install_canonical_delegation.py'
BINDING = '14cf53964f5d44d123e989805ea741669ab3f05054e730ddcb299a0aac51a9cb'
sha = lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read = lambda p:json.loads(p.read_text('utf-8'))

assert sys.argv[1:] == ['--install']
assert sha(GEN) == '9909f60d16ad3eaed54b9f97ea0d275ad38510c679ba651ce05af44d920ed0f6'
assert sha(N/'run_workbench.py') == '4e912e9456d0cadf379c51a69acda55c7ad5930451ddd15d30d3a488fc760633'
assert sha(N/'FROZEN.json') == 'a8db5b46a7dd635738d32f7a8eefdba1f424ca11d8025c43579984ad43fe8c87'
assert read(N/'FROZEN.json')['release_id'] == 'ui-r57-20261024T070458Z-6b382ca0'
assert sha(N/'state/production-workspace.json') == BINDING
pins = read(PACK/'ROOT-FINAL-PINS-V100.json')
stage = read(F/'STAGED.json')
release = Path(stage['release'])
assert sha(F/'STAGED.json') == pins['stagedSha256'] and stage['release_id'] == pins['releaseId']
assert sha(F/'UNIFIED-PINS.json') == pins['unifiedPinsSha256']
assert sha(release/'RELEASE.json') == pins['manifestSha256']
assert sha(release/'web/pages/reply-connected.mjs') == '92bda4b28c8fe91ae3ae789c137e14a940a16ce68e1ffc2dbeb521267b1476f5'

gates = read(PACK/'ROOT-GATES-V100.json')
review = read(PACK/'FINAL-PACKAGE-REVIEW-V100.json')
assert gates['status'] == 'PASS_F100_MANUAL_REPLY_SENDER_FIX' and gates['releaseId'] == pins['releaseId']
for row in gates['evidence']:
    assert sha(Path(row['path'])) == row['sha256']
assert review['blockingFindings'] == [] and review['approvedForRootInstall'] is True
assert review['releaseId'] == pins['releaseId'] and review['unifiedPinsSha256'] == pins['unifiedPinsSha256']
assert review['manifestSha256'] == pins['manifestSha256']
assert review['rootPinsSha256'] == sha(PACK/'ROOT-FINAL-PINS-V100.json')
assert review['rootGatesSha256'] == sha(PACK/'ROOT-GATES-V100.json')
assert review['installerSha256'] == sha(Path(__file__).resolve())
closure = read(F/'UNIFIED-PINS.json')
for row in closure['files']:
    assert sha(F/'project'/row['path']) == row['sha256'], row['path']
assert sha(Path(stage['launcher'])) == stage['launcher_sha256'].lower()
body = Path(stage['launcher']).read_text('utf-8')
needle = "RELEASE = ROOT / 'releases/"+stage['release_id']+"'"
assert body.count(needle) == 1 and body.count('project_root=ROOT.parent.parent') == 1
body = body.replace(needle,"PROJECT_ROOT = ROOT.parent.parent / 'work/parallel-integration-20261018/final-integration/candidate-unified-v100/project'\nRELEASE = PROJECT_ROOT / 'work/ui-native-r57/releases/"+stage['release_id']+"'\nBINDING_SHA256 = '"+BINDING.upper()+"'")
body = body.replace('project_root=ROOT.parent.parent','project_root=PROJECT_ROOT')
needle = "        pinned(RELEASE / 'RELEASE.json', MANIFEST_SHA256)"
assert body.count(needle) == 1
body = body.replace(needle,"        pinned(ROOT / 'state/production-workspace.json', BINDING_SHA256)\n        pinned(PROJECT_ROOT / 'work/ui-native-r57/state/production-workspace.json', BINDING_SHA256)\n"+needle)
compile(body,'reviewed_f100_launcher.py','exec')
raw = body.encode('utf-8')
candidate = N/('run_delegated_candidate.'+stage['release_id']+'.py')
entry = PACK/'entry-v100'
assert not entry.exists()
with candidate.open('xb') as stream:
    stream.write(raw)
entry.mkdir()
plan = {'status':'PREPARED_NOT_INSTALLED','release_id':stage['release_id'],'release':stage['release'],
    'manifest_sha256':stage['manifest_sha256'],'launcher':str(candidate),
    'launcher_sha256':hashlib.sha256(raw).hexdigest().upper(),
    'expected_previous_launcher_sha256':sha(N/'run_workbench.py'),
    'expected_previous_frozen_sha256':sha(N/'FROZEN.json'),
    'runtime_project_root':str(F/'project'),'installation_state_root':str(N/'state'),
    'workspace_binding_sha256':BINDING,'full_closure_files_verified':len(closure['files']),
    'full_closure_manifest_sha256':sha(F/'UNIFIED-PINS.json'),
    'validation':str(PACK/'ROOT-GATES-V100.json')}
(entry/'CANONICAL-DELEGATION-PREPARED.json').write_text(json.dumps(plan,ensure_ascii=False,indent=2)+'\n','utf-8')
spec = importlib.util.spec_from_file_location('existing_f100_entry_installer',GEN)
installer = importlib.util.module_from_spec(spec)
spec.loader.exec_module(installer)
installer.HERE = entry
installer.P = P
installer.NATIVE = N
installer.OUT = F
sys.argv = [str(GEN),'--install']
installer.main()
