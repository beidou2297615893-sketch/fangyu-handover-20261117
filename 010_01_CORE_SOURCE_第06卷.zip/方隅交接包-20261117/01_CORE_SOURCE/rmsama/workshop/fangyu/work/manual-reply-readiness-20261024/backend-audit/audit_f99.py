"""Read-only F99 source audit plus owned SQLite fixtures; external IO is denied."""
from pathlib import Path
import hashlib, importlib.util, io, json, socket, subprocess, sys, tempfile, threading, unittest
from unittest.mock import patch

sys.dont_write_bytecode = True
TASK = Path(__file__).resolve().parent
PROJECT = Path('C:/积木软件工坊/项目/方隅公寓客户版/work/parallel-integration-20261018/final-integration/candidate-unified-v99/project')
RELEASE = PROJECT/'work/ui-native-r57/releases/ui-r57-20261024T070458Z-6b382ca0'
SOURCE = PROJECT/'work/ui-runtime-r55/src'
manifest = json.loads((RELEASE/'RELEASE.json').read_text('utf-8'))
entries = {item['path']: item for item in manifest['files']}
pins = []

def checked(path, expected):
    raw = path.read_bytes()
    assert len(raw) == expected['size'] and hashlib.sha256(raw).hexdigest().upper() == expected['sha256'].upper(), str(path)
    pins.append({'path':str(path),'sha256':hashlib.sha256(raw).hexdigest(),'size':len(raw)})
    return raw

dependencies = json.loads(checked(RELEASE/'resources/backend-dependencies.json', entries['resources/backend-dependencies.json']))
for item in dependencies['files']:
    checked(SOURCE/item['path'], item)
sys.path.insert(0,str(SOURCE))
from core.engine import Core

def release_module(name):
    path = RELEASE/(name+'.py')
    raw = checked(path,entries[name+'.py'])
    spec = importlib.util.spec_from_loader('audit_f99_'+name,loader=None)
    mod = importlib.util.module_from_spec(spec)
    mod.__file__ = str(path)
    sys.modules[spec.name] = mod
    exec(compile(raw,str(path),'exec'),mod.__dict__)
    return mod

customers_mod = release_module('customer_workbench')
replies_mod = release_module('reply_workbench')
delivery_mod = release_module('reply_delivery')

def deny(*args,**kwargs):
    raise AssertionError('External network/process IO forbidden by this audit')

class RuntimeFixture:
    def __init__(self): self.calls=[]
    def start_reply_queue(self,user,ident): self.calls.append(ident)

class Audit(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='fixture-',dir=TASK)
        self.addCleanup(self.temp.cleanup)
        self.cores=[]
        self.company={'id':'fangyu-apartment-client','edition':'customer','personalMode':False,'authMode':'managed',
            'managedWorkspace':{'environment_id':'fixture-env','endpoint':'https://example.invalid/workspace'}}
        self.open()
        self.store='fixture-store'
        self.user={'id':'fixture-user','tenant_id':self.customers.tenant,'username':'fixture-employee','role':'operator','cloud_bound':True,'can_reply':True}
        self.core.store.put('users',self.user)
        self.tenant=self.user['tenant_id']
        self.core.store.put('tenants',{'id':self.tenant,'tenant_id':self.tenant,'name':'隔离企业'})
        for ident,platform,owner,store in [('account-a','xiaohongshu','fixture-employee','fixture-store'),
                ('account-b','xiaohongshu','fixture-employee','fixture-store'),
                ('foreign-owner','xiaohongshu','other-employee','fixture-store'),
                ('foreign-store','xiaohongshu','fixture-employee','other-store'),
                ('douyin-account','douyin','fixture-employee','fixture-store')]:
            self.core.store.put('accounts',{'id':ident,'tenant_id':self.tenant,'platform':platform,'cloud_owner':owner,
                'store_id':store,'name':'隔离账号备注','platform_nickname':'隔离昵称-'+ident,'platform_uid':'fixture-'+ident,'status':'ready'})
        for ident in ('comment-a','comment-b'):
            self.core.store.put('leads',{'id':ident,'tenant_id':self.tenant,'cloud_owner':'fixture-employee',
                'store_id':'fixture-store','platform':'xiaohongshu','source_type':'comment','source_id':ident,
                'comment_id':ident,'author_id':'fixture-author','author':'隔离客户','text':'隔离评论正文 '+ident,
                'content_title':'隔离原帖','note_url':'https://www.xiaohongshu.com/explore/123456789012345678901234'})
        items=self.customers.list(self.user,self.store,{})['items']
        self.assertEqual(len(items),1)
        self.customer=items[0]['id']

    def open(self):
        self.core=Core(self.temp.name,defer_startup_recovery=True)
        self.cores.append(self.core)
        self.addCleanup(self.core.close_continuous_scheduler)
        self.customers=customers_mod.CustomerWorkbench(self.core,self.company,PROJECT)
        self.replies=replies_mod.ReplyWorkbench(self.core,self.customers)
        self.runtime=RuntimeFixture()
        self.delivery=delivery_mod.ReplyDelivery(self.core,self.replies,self.runtime)

    def call(self,action,**data):
        return self.replies.execute(action,self.user,self.store,{'storeId':self.store,'customerId':self.customer,**data})

    def row(self,lead='comment-a'):
        return next(row for row in self.call('reply_read')['comments'] if row['id']==lead)

    def payload(self,request='save-a',lead='comment-a'):
        row=self.row(lead)
        draft=row['draft']
        return dict(leadId=lead,sourceDigest=row['sourceDigest'],expectedVersion=draft['version'] if draft else 0,
            expectedReplyId=draft['id'] if draft else '',requestId=request)

    def approved(self,lead='comment-a',account='account-a'):
        self.call('reply_save',**self.payload('save-'+lead,lead),text='请问预计什么时候入住？')
        self.call('reply_review',**self.payload('review-'+lead,lead),accountId=account,confirmed=True)
        row=self.row(lead);draft=row['draft']
        return dict(customerId=self.customer,leadId=lead,sourceDigest=row['sourceDigest'],replyId=draft['id'],version=draft['version'],accountId=account)

    def prepare(self,item,request='prepare-a'):
        return self.delivery.execute('reply_delivery_prepare',self.user,self.store,
            {'storeId':self.store,'items':[item],'requestId':request},lambda:(self.user,{'_workbench_store_id':self.store}))

    def test_draft_exact_comment_saved_reopen_and_read_no_send(self):
        before=self.core.store.list('leads',self.tenant)
        payload=self.payload()
        saved=self.call('reply_save',**payload,text='请问预计什么时候入住？')
        draft=self.row()['draft']
        self.assertEqual((draft['version'],draft['status']),(1,'draft'))
        self.assertIsNone(self.row('comment-b')['draft'])
        self.assertEqual(self.core.store.list('leads',self.tenant),before)
        self.assertEqual(self.runtime.calls,[])
        self.open()
        self.assertEqual(self.row()['draft'],draft)
        self.assertEqual(self.call('reply_check',leadId='comment-a',requestId='save-a')['receipt']['state'],'accepted')
        self.assertFalse(self.customers.list(self.user,self.store,{})['items'][0]['replied'])

    def test_idempotency_version_conflict_and_source_conflict(self):
        payload=self.payload()
        first=self.call('reply_save',**payload,text='何时入住？')['receipt']
        second=self.call('reply_save',**payload,text='何时入住？')['receipt']
        self.assertEqual(first,second)
        self.assertEqual(len(self.core.store.list('replies',self.tenant)),1)
        with self.assertRaises(replies_mod.ReplyWorkbenchError) as caught:
            self.call('reply_save',**{**payload,'requestId':'stale-version'},text='新草稿')
        self.assertEqual(caught.exception.code,'REPLY_VERSION_CONFLICT')
        latest=self.payload('stale-source')
        lead=self.core.store.get('leads','comment-a');lead['text']='原评论已修改'
        self.core.store.put('leads',lead)
        with self.assertRaises(replies_mod.ReplyWorkbenchError) as caught:
            self.call('reply_save',**latest,text='新草稿')
        self.assertEqual(caught.exception.code,'REPLY_SOURCE_CHANGED')

    def test_account_nicknames_owned_platform_store_and_selected_review(self):
        accounts=self.row()['accounts']
        self.assertEqual({a['id'] for a in accounts},{'account-a','account-b'})
        self.assertTrue(all(a['name']=='隔离昵称-'+a['id'] for a in accounts))
        self.call('reply_save',**self.payload(),text='何时入住？')
        for ident in ('foreign-owner','foreign-store','douyin-account'):
            with self.subTest(account=ident),self.assertRaises(replies_mod.ReplyWorkbenchError):
                self.call('reply_review',**self.payload('review-'+ident),accountId=ident,confirmed=True)
        self.call('reply_review',**self.payload('review-b'),accountId='account-b',confirmed=True)
        self.assertTrue(self.row()['reviewCurrent'])
        self.assertEqual(self.row()['draft']['review_account_id'],'account-b')
        account=self.core.store.get('accounts','account-b');account['platform_uid']='changed-identity'
        self.core.store.put('accounts',account)
        self.assertFalse(self.row()['reviewCurrent'])
        self.assertEqual(self.runtime.calls,[])

    def test_prepare_snapshot_tamper_confirmation_and_account_change_fail_closed(self):
        item=self.approved()
        plan=self.prepare(item)
        self.assertEqual(plan['state'],'prepared')
        self.assertEqual(plan['items'][0]['accountName'],'隔离昵称-account-a')
        self.assertEqual(self.runtime.calls,[])
        start={'storeId':self.store,'id':plan['id'],'snapshotDigest':plan['snapshotDigest'],'confirmed':True,'requestId':'send-a'}
        for change in ({'confirmed':False},{'snapshotDigest':'tampered'}):
            with self.subTest(change=change),self.assertRaises(delivery_mod.DeliveryError):
                self.delivery.execute('reply_delivery_start',self.user,self.store,{**start,**change},lambda:(self.user,{'_workbench_store_id':self.store}))
        account=self.core.store.get('accounts','account-a');account['platform_uid']='changed-identity'
        self.core.store.put('accounts',account)
        with self.assertRaises(delivery_mod.DeliveryError) as caught:
            self.delivery.execute('reply_delivery_start',self.user,self.store,start,lambda:(self.user,{'_workbench_store_id':self.store}))
        self.assertEqual(caught.exception.code,'DELIVERY_SNAPSHOT_CHANGED')
        self.assertEqual(self.runtime.calls,[])

    def test_review_persists_after_reopen_and_requires_explicit_confirmation(self):
        self.call('reply_save',**self.payload(),text='何时入住？')
        with self.assertRaises(replies_mod.ReplyWorkbenchError) as caught:
            self.call('reply_review',**self.payload('unconfirmed'),accountId='account-a',confirmed=False)
        self.assertEqual(caught.exception.code,'CONFIRM_REQUIRED')
        self.call('reply_review',**self.payload('confirmed'),accountId='account-a',confirmed=True)
        draft=self.row()['draft']
        self.open()
        self.assertEqual(self.row()['draft'],draft)
        self.assertTrue(self.row()['reviewCurrent'])
        self.assertEqual(self.runtime.calls,[])

    def test_revoked_or_disabled_actor_cannot_change_drafts(self):
        before=self.core.store.list('replies',self.tenant)
        payload=self.payload()
        self.user['can_reply']=False
        self.core.store.put('users',self.user)
        self.assertFalse(self.row()['canSave'])
        with self.assertRaises(replies_mod.ReplyWorkbenchError) as caught:
            self.call('reply_save',**payload,text='何时入住？')
        self.assertEqual(caught.exception.code,'REPLY_FORBIDDEN')
        disabled={**self.user,'disabled':True};self.core.store.put('users',disabled)
        with self.assertRaises(customers_mod.CustomerWorkbenchError):self.call('reply_read')
        self.assertEqual(self.core.store.list('replies',self.tenant),before)

    def test_failed_audit_receipt_observed_without_replay(self):
        payload=self.payload('lost-audit')
        with self.core.store.connect() as db:
            db.execute("CREATE TRIGGER fixture_audit_fail BEFORE INSERT ON records WHEN NEW.entity='audit' BEGIN SELECT RAISE(ABORT,'fixture audit failure'); END")
        with self.assertRaises(replies_mod.ReplyWorkbenchError) as caught:
            self.call('reply_save',**payload,text='何时入住？')
        self.assertEqual(caught.exception.code,'REPLY_RESULT_UNCONFIRMED')
        with self.core.store.connect() as db:db.execute('DROP TRIGGER fixture_audit_fail')
        self.assertEqual(self.row()['pendingRequestId'],'lost-audit')
        with self.assertRaises(replies_mod.ReplyWorkbenchError):
            self.call('reply_save',**self.payload('new-must-not-replay'),text='何时入住？')
        checked_result=self.call('reply_check',leadId='comment-a',requestId='lost-audit')
        self.assertEqual(checked_result['receipt']['state'],'observed')
        self.assertEqual(len(self.core.store.list('replies',self.tenant)),1)

    def test_two_independent_cores_cross_account_atomic_customer_reservation(self):
        first_core,first_delivery=self.core,self.delivery
        first_lead=first_core.store.get('leads','comment-a')
        second_lead=first_core.store.get('leads','comment-b')
        self.open()
        second_delivery=self.delivery
        barrier=threading.Barrier(2);results=[];errors=[]
        def claim(delivery,lead,reply,account):
            try:
                barrier.wait(3)
                results.append(delivery._customer_claim(self.tenant,lead,{'id':reply},account))
            except Exception as error: errors.append(repr(error))
        threads=[threading.Thread(target=claim,args=(first_delivery,first_lead,'reply-a','account-a')),
            threading.Thread(target=claim,args=(second_delivery,second_lead,'reply-b','account-b'))]
        for thread in threads:thread.start()
        for thread in threads:thread.join(5)
        self.assertFalse(any(t.is_alive() for t in threads))
        self.assertEqual(errors,[])
        self.assertEqual(sum(bool(claim) for claim,reason in results),1)
        self.assertEqual(sum(bool(reason) for claim,reason in results),1)
        self.assertEqual(len(self.core.store.list(delivery_mod.CUSTOMER_GUARD,self.tenant)),1)
        self.open()
        self.assertTrue(self.delivery.customer_conflict(self.tenant,first_lead))
        self.assertEqual(self.runtime.calls,[])

    def test_sent_unknown_history_cross_account_and_missing_identity_block(self):
        lead=self.core.store.get('leads','comment-a')
        other=self.core.store.get('leads','comment-b')
        for state in ('sent','sending','unknown'):
            self.core.store.put('replies',{'id':'old-reply','tenant_id':self.tenant,'lead_id':lead['id'],'account_id':'account-a','status':state})
            claim,reason=self.delivery._customer_claim(self.tenant,other,{'id':'next-reply'},'account-b')
            self.assertIsNone(claim);self.assertTrue(reason)
        with self.assertRaises(delivery_mod.DeliveryError) as caught:
            self.delivery._customer_claim(self.tenant,{**lead,'author_id':''},{'id':'no-author'},'account-b')
        self.assertEqual(caught.exception.code,'CUSTOMER_ID_REQUIRED')

    def test_claim_terminal_state_release_only_definite_no_send(self):
        lead=self.core.store.get('leads','comment-a')
        for reply_state,attempted,expected in [('approved',False,'released'),('approved',True,'unknown'),('sent',True,'sent'),('unknown',True,'unknown')]:
            key=self.delivery._customer_key(self.tenant,lead)
            self.core.store.delete(delivery_mod.CUSTOMER_GUARD,key)
            reply={'id':'finish-reply','tenant_id':self.tenant,'lead_id':lead['id'],'status':reply_state}
            if attempted:reply['attempted_at']='fixture-time'
            self.core.store.put('replies',reply)
            # Reserve with a clean pre-send state, then commit simulated result.
            self.core.store.delete('replies',reply['id'])
            claim,reason=self.delivery._customer_claim(self.tenant,lead,reply,'account-a')
            self.assertEqual(reason,'')
            self.core.store.put('replies',reply)
            self.delivery._finish_claim(claim)
            self.assertEqual(self.core.store.get(delivery_mod.CUSTOMER_GUARD,key)['state'],expected)

if __name__=='__main__':
    stream=io.StringIO()
    with patch.object(socket.socket,'connect',deny),patch.object(socket.socket,'connect_ex',deny),patch('subprocess.Popen',side_effect=deny):
        suite=unittest.defaultTestLoader.loadTestsFromTestCase(Audit)
        result=unittest.TextTestRunner(stream=stream,verbosity=2).run(suite)
    log=stream.getvalue()
    (TASK/'isolated-tests.log').write_text(log,'utf-8')
    report={'status':'PASS' if result.wasSuccessful() else 'FAIL','testsRun':result.testsRun,
        'release':str(RELEASE),'runtimeCoreSource':str(SOURCE),'verifiedSourceFiles':len(pins),
        'scope':'Exact release CustomerWorkbench/ReplyWorkbench/ReplyDelivery + actual pinned Core and SQLite. All records synthetic and temp files confined to this audit folder. No WorkbenchBackend constructor, live DB, credentials, session files, network, CLI, browser or real sending.',
        'sourcePins':pins,'log':str(TASK/'isolated-tests.log')}
    (TASK/'isolated-results.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),'utf-8')
    print(log)
    print(json.dumps({k:v for k,v in report.items() if k!='sourcePins'},ensure_ascii=False))
    raise SystemExit(0 if result.wasSuccessful() else 1)
