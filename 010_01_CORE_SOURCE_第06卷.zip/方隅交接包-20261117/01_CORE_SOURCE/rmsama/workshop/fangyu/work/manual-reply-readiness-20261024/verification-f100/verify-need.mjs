import {readFile,writeFile,mkdir} from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import {createRequire} from 'node:module';
const require=createRequire(import.meta.url);
const {chromium}=require('C:/Users/rmsama/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const D=path.dirname(new URL(import.meta.url).pathname.replace(/^\/(?:([A-Za-z]:))/,'$1'));
const opt=key=>process.argv[process.argv.indexOf(key)+1];
const output=path.resolve(opt('--output'));
const helper=path.resolve(opt('--helper'));
const web='C:/积木软件工坊/项目/方隅公寓客户版/work/parallel-integration-20261018/final-integration/candidate-unified-v100/project/work/ui-native-r57/releases/ui-r57-20261024T082845Z-a2ad4ba4/web';
await mkdir(output,{recursive:true});
const html=await readFile(path.join(web,'canvas.html'),'utf8');
const styles=[...html.matchAll(/<link\b[^>]*rel=["']stylesheet["'][^>]*>/g)].map(x=>x[0]);
const browser=await chromium.launch({headless:true});
const page=await browser.newPage({viewport:{width:1280,height:1050}});
let external=0;
await page.route('**/*',async route=>{
 const u=new URL(route.request().url());
 if(u.hostname!=='fixture.test'){external++;return route.abort();}
 if(u.pathname==='/fixture.html')return route.fulfill({contentType:'text/html',body:`<!doctype html><html lang="zh-CN"><head><meta charset="utf-8">${styles.join('')}</head><body><div id="root"></div></body></html>`});
 if(u.pathname==='/pages/customers-data.mjs')return route.fulfill({contentType:'text/javascript',body:await readFile(helper)});
 if(u.pathname.startsWith('/assets/'))return route.fulfill({status:204,body:''});
 const file=path.resolve(web,'.'+u.pathname);if(!file.startsWith(path.resolve(web)+path.sep))return route.abort();
 try{return route.fulfill({contentType:file.endsWith('.mjs')?'text/javascript':file.endsWith('.css')?'text/css':'application/octet-stream',body:await readFile(file)});}catch{return route.fulfill({status:404,body:''});}
});
await page.goto('http://fixture.test/fixture.html');
const checks=await page.evaluate(async()=>{
 const Q=await import('/pages/customers-data.mjs'),R=await import('/pages/reply-connected.mjs'),C=await import('/pages/customers.mjs');
 const results=[],root=document.querySelector('#root');
 const actor={username:'fixture-user',storeId:'fixture-store'},id='a'.repeat(64);
 const row=data=>({id,name:'合成客户',platform:'xiaohongshu',channel:'小红书',postTitle:'合成测试帖子',level:'信息不足',tone:'muted',contactLabel:'未回复',analysisStatus:'uncertain',...data});
 const state=p=>({authEpoch:1,user:actor.username,storeId:actor.storeId,activePlatform:'xiaohongshu',connection:'connected',session:{user:{username:actor.username,tenant_id:'fixture-tenant',role:'employee'}},page:'reply',capabilities:{customers:true},customerView:{actor,status:'ready',items:[p],total:1,page:1,pages:1,stats:{total:1}}});
 const draw=p=>{const s=state(p);R.renderConnected(s);Object.assign(s.replyLive,{status:'ready',items:[p],total:1,page:1,pages:1,loadedAt:Date.now()});root.innerHTML=R.renderConnected(s);return{state:s,text:root.querySelector('.rp-comment-copy>span').textContent};};
 const test=(name,fn)=>{try{fn();results.push({name,pass:true});}catch(e){results.push({name,pass:false,reason:e.message});}};
 const equal=(a,b)=>{if(a!==b)throw Error(`Expected ${JSON.stringify(b)}; got ${JSON.stringify(a)}`);};
 const cases=[
  ['saved_placeholder_uses_original_quote',{need:'需求待补充',quote:'请问周末可以看房吗？'},'请问周末可以看房吗？'],
  ['export_placeholder_uses_original_quote',{need:'需求信息尚未整理',quote:'附近有没有一居室？'},'附近有没有一居室？'],
  ['row_placeholder_uses_original_quote',{need:'需求待了解',quote:'下周想入住。'},'下周想入住。'],
  ['placeholder_short_need_uses_valid_need',{shortNeed:' 需求待补充 ',need:'一居室 · 合成区域',quote:'合成原评论'},'一居室 · 合成区域'],
  ['valid_short_need_precedes_need',{shortNeed:'近地铁的一居室',need:'合成完整需求',quote:'合成原评论'},'近地铁的一居室'],
  ['valid_saved_fact_precedes_quote',{need:'预算两千 · 一居室',quote:'合成原评论'},'预算两千 · 一居室'],
  ['quote_only_normalizes_whitespace',{quote:'  周末\n  想看房  '},'周末 想看房'],
  ['empty_row_is_neutral_not_loading',{},'原评论未提供'],
  ['real_summary_containing_placeholder_words_is_preserved',{need:'预算和需求待补充，但周末想看房',quote:'合成原评论'},'预算和需求待补充，但周末想看房'],
  ['literal_original_comment_is_never_dropped',{need:'需求待补充',quote:'需求待补充'},'需求待补充'],
  ['malformed_summary_does_not_mask_quote',{need:{unexpected:true},quote:'这是合成原评论'},'这是合成原评论']
 ];
 for(const [name,data,expected]of cases)test(name,()=>{const p=row(data),before=JSON.stringify(p),{text}=draw(p);equal(text,expected);equal(JSON.stringify(p),before);equal(root.querySelector('.rp-badge').textContent,'信息不足');if(root.querySelector('[data-live-save],[data-live-review]'))throw Error('List row created sending qualification');});
 test('malicious_html_is_escaped_in_actual_reply_dom',()=>{const html='<img src=x onerror="window.__injected=1">',p=row({need:'需求待补充',quote:html});const {text}=draw(p);equal(text,html);if(root.querySelector('.rp-comment-copy img, .rp-comment-copy [onerror]')||window.__injected)throw Error('Unescaped HTML');});
 test('customer_list_uses_same_safe_display_mapping',()=>{const p=row({need:'需求待补充',quote:'请问能短租三个月吗？'}),s=state(p);s.page='customers';root.innerHTML=C.render(s);equal(root.querySelector('.cs-person-cell>span>span').textContent,'请问能短租三个月吗？');});
 test('unicode_truncation_preserves_characters_and_original',()=>{const text='🏠'.repeat(61),p=row({quote:text}),before=p.quote;equal(Q.customerShortNeed(p),'🏠'.repeat(60)+'…');equal(p.quote,before);});
 draw(row({need:'需求待补充',quote:'请问周末可以看房吗？'}));
 return results;
});
await page.screenshot({path:path.join(output,'reply-placeholder-reproduction.png'),fullPage:true});
await browser.close();
const bytes=await readFile(helper);const result={status:checks.every(x=>x.pass)&&!external?'PASS':'FAIL',helper,helperSha256:crypto.createHash('sha256').update(bytes).digest('hex'),actualRenderers:['reply-connected.mjs:renderConnected','customers.mjs:render'],cssLinkCount:styles.length,checks,total:checks.length,passed:checks.filter(x=>x.pass).length,externalRequests:external,productionAccess:0,visibleBrowserWindows:0,sourceWrites:0};
await writeFile(path.join(output,'DOM-RESULT.json'),JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify(result,null,2));if(result.status!=='PASS')process.exitCode=1;
