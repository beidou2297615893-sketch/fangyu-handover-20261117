"""Check the real desktop entry and preserve business data without opening UI."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import sqlite3
import subprocess
import sys
import urllib.request

sys.dont_write_bytecode = True
sys.stdout.reconfigure(encoding='utf-8')
W = Path(__file__).resolve().parent
P = W.parents[1]
N = P/'work/ui-native-r57'
sha = lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read = lambda p:json.loads(p.read_text('utf-8'))
pins = read(W/'package/ROOT-FINAL-PINS-V100.json')
installed = read(N/'FROZEN.json')
journal = read(W/'package/entry-v100/CANONICAL-DELEGATION-INSTALL.json')
assert journal['status']=='INSTALLED_AWAITING_ACTUAL_ORIGINAL_ENTRY_VERIFICATION'
assert installed['release_id']==pins['releaseId']
assert sha(N/'run_workbench.py')==installed['launcher_sha256'].lower()
assert installed['full_closure_manifest_sha256']==pins['unifiedPinsSha256']
assert sha(N/'state/production-workspace.json')=='14cf53964f5d44d123e989805ea741669ab3f05054e730ddcb299a0aac51a9cb'
result = subprocess.run([str(P/'work/desktop-python/Scripts/python.exe'),'-X','utf8','-I','-B',
    str(N/'run_workbench.py'),'--check'],capture_output=True,text=True,encoding='utf-8',timeout=300)
(W/'package/CANONICAL-CHECK-F100.log').write_text(result.stdout+'\n'+result.stderr,'utf-8')
assert result.returncode==0
check = json.loads(result.stdout)
assert check['status']=='PASS' and check['release_id']==pins['releaseId']
assert check['native_windows_opened']==0 and check['business_app_imported'] is False
(W/'package/CANONICAL-CHECK-F100.json').write_text(json.dumps(check,ensure_ascii=False,indent=2)+'\n','utf-8')

formal = read(W/'FORMAL-DATA-AND-MANUAL-REPLY.json')
helper = P/'work/complete-product-resume-20261024/live-review-deployment-20261024/data-preflight/review_safety.py'
spec = importlib.util.spec_from_file_location('post_install_ro_preservation',helper)
s = importlib.util.module_from_spec(spec)
spec.loader.exec_module(s)
binding = read(N/'state/production-workspace.json')
tenant = 'cloud-'+hashlib.sha256((binding['environment_id']+'\n'+binding['company_id']).encode()).hexdigest()[:24]
db = sqlite3.connect((Path(binding['data_dir'])/'workspace.sqlite3').as_uri()+'?mode=ro',uri=True,timeout=3)
db.row_factory = sqlite3.Row
try:
    db.execute('PRAGMA query_only=ON')
    db.execute('BEGIN')
    protected = s.protected(db,tenant,binding['owner'])
    account_count = db.execute("SELECT count(*) FROM records WHERE entity='accounts' AND tenant_id=? "
        "AND json_extract(body,'$.cloud_owner')=?",(tenant,binding['owner'])).fetchone()[0]
finally:
    db.close()
assert protected==formal['businessAfter']
assert account_count==len(formal['accountMetadata'])==3
assert sha(Path(formal['backup']))==formal['backupSha256']

actual = {'running':False,'reason':'No canonical active runtime marker; no window was opened by this check.'}
active = N/'state/active.json'
if active.exists():
    a = read(active)
    port = a.get('stablePort')
    if a.get('profile')=='production' and type(port) is int and 0<port<65536:
        try:
            with urllib.request.urlopen('http://127.0.0.1:'+str(port)+'/__workbench_status',timeout=3) as response:
                public = json.load(response)
            if public.get('instanceId')==a.get('instanceId') and public.get('profile')=='production':
                actual={'running':True,'releaseId':public.get('release'),'matchesInstalled':public.get('release')==pins['releaseId'],'pid':a.get('pid')}
        except Exception as error:
            actual={'running':False,'reason':'Recorded public local runtime is not reachable.','errorType':type(error).__name__}
report={'status':'PASS_INSTALLED_ORIGINAL_ENTRY_AND_DATA_PRESERVED','atUtc':datetime.now(timezone.utc).isoformat(),
    'installedReleaseId':pins['releaseId'],'canonicalLauncherSha256':sha(N/'run_workbench.py'),
    'canonicalFrozenSha256':sha(N/'FROZEN.json'),'canonicalCheck':check,
    'commentsPreserved':formal['businessCounts']['leads'],'customersPreserved':formal['customers'],
    'softwareHighPeople':formal['highPeople'],'highManualReadReadyPeople':formal['manualReplyReadReadyPeople'],
    'accountsPreserved':account_count,'businessProtectedClassesUnchanged':True,
    'originalAnalysisAndDraftsChanged':False,'backupHashVerified':True,'actualRuntime':actual,
    'actualNativeOrPlatformSendVerified':False,'currentWindowOperatedOrRestarted':False,
    'productionWrites':0,'platformOrProviderOrSendOperations':0}
(W/'INSTALLED-VERIFICATION.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n','utf-8')
print(json.dumps(report,ensure_ascii=False),flush=True)
