"""Compose only the proven sender-preservation fix; retain F99 and all data."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import shutil
import sys

sys.dont_write_bytecode = True
sys.stdout.reconfigure(encoding='utf-8')
W = Path(__file__).resolve().parent
P = W.parents[1]
F = P/'work/parallel-integration-20261018/final-integration'
OLD = F/'candidate-unified-v99'
PUBLIC = P/'work/complete-product-resume-20261024/live-acquisition-acceptance-20261024/project'
sha = lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read = lambda p:json.loads(p.read_text('utf-8'))
baseline = read(OLD/'INPUT-SNAPSHOT.json')
assert Path(baseline['source']) == PUBLIC
pins = read(W/'frontend-audit/CANDIDATE-PINS.json')
assert len(pins['differences']) == 1
row = pins['differences'][0]
assert row['relativePath'].replace('\\','/') == 'pages/reply-connected.mjs'
source = Path(pins['candidate'])/'pages/reply-connected.mjs'
target = PUBLIC/'work/ui-approved-implementation/ui-preview/pages/reply-connected.mjs'
assert sha(source) == row['candidateSha256'] == '92bda4b28c8fe91ae3ae789c137e14a940a16ce68e1ffc2dbeb521267b1476f5'
assert sha(target) == row['baselineSha256'] == '3123601746dc39a7fae081c2c1c54db5e1962291cbb994009673d21bfda30b7f'
assert not (F/'candidate-unified-v100').exists()
spec = importlib.util.spec_from_file_location('existing_root_f100_freezer',F/'freeze_unified.py')
builder = importlib.util.module_from_spec(spec)
spec.loader.exec_module(builder)
builder.SOURCE = PUBLIC
actual = {p.relative_to(PUBLIC).as_posix():sha(p) for p in builder.input_files()}
changed = sorted(k for k in actual.keys() | baseline['files'].keys()
    if actual.get(k) != baseline['files'].get(k))
assert not changed, ('Unreviewed public source change', changed)
pack = W/'package'
pack.mkdir(exist_ok=True)
with (pack/'public-before-reply-connected.mjs').open('xb') as stream:
    stream.write(target.read_bytes())
shutil.copy2(source,target)
assert sha(target) == row['candidateSha256']
composition = {'atUtc':datetime.now(timezone.utc).isoformat(),'source':str(PUBLIC),
    'baselineInputFiles':len(actual),'baselineInputsMatchF99':True,
    'changedFiles':[{'relativePath':'web/pages/reply-connected.mjs',
        'beforeSha256':row['baselineSha256'],'afterSha256':row['candidateSha256']}],
    'productionDataWrites':0,'frozenOrRuntimeMutated':False}
(pack/'ROOT-COMPOSITION-V100.json').write_text(json.dumps(composition,ensure_ascii=False,indent=2)+'\n','utf-8')
print(json.dumps({'stage':'source_checked_and_single_patch_merged','sourceFiles':len(actual)},ensure_ascii=False),flush=True)
sys.argv = [str(F/'freeze_unified.py'),'--candidate','candidate-unified-v100']
builder.main()
out = F/'candidate-unified-v100'
stage = read(out/'STAGED.json')
native = Path(stage['release'])
old_native = Path(read(OLD/'STAGED.json')['release'])
old_files = {p.relative_to(old_native).as_posix():sha(p) for p in old_native.rglob('*') if p.is_file()}
new_files = {p.relative_to(native).as_posix():sha(p) for p in native.rglob('*') if p.is_file()}
assert old_files.keys() == new_files.keys()
delta = sorted(k for k in old_files if old_files[k] != new_files[k])
assert delta == ['RELEASE.json','web/pages/reply-connected.mjs'], delta
assert sha(native/'web/pages/reply-connected.mjs') == row['candidateSha256']
final = {'status':'FROZEN_PENDING_VERIFICATION','releaseId':stage['release_id'],
    'release':str(native),'project':str(out/'project'),
    'unifiedPinsSha256':sha(out/'UNIFIED-PINS.json'),'stagedSha256':sha(out/'STAGED.json'),
    'manifestSha256':sha(native/'RELEASE.json'),'changedProductSourceFiles':1,
    'changedReleaseFiles':delta,'productionWrites':0,'installed':False,'actualNewNativeVerified':False}
(pack/'ROOT-FINAL-PINS-V100.json').write_text(json.dumps(final,ensure_ascii=False,indent=2)+'\n','utf-8')
print(json.dumps(final,ensure_ascii=False),flush=True)
