"""Validate every result; retain the failed invocation and corrected recheck."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json

W = Path(__file__).resolve().parent
P = W.parents[1]
PACK = W/'package'
F = P/'work/parallel-integration-20261018/final-integration/candidate-unified-v100'
OLD = F.parent/'candidate-unified-v99'
OUT = W/'verification-f100'
read = lambda p:json.loads(p.read_text('utf-8'))
sha = lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
pins = read(PACK/'ROOT-FINAL-PINS-V100.json')
stage = read(F/'STAGED.json')
N = Path(stage['release'])
old_native = Path(read(OLD/'STAGED.json')['release'])
first = read(OUT/'ROOT-RESULT.json')
assert first['releaseId']==pins['releaseId']
for row in first['checks']:
    assert sha(Path(row['path']))==row['sha256']
    assert row['exitCode']==(1 if row['name']=='original-comment' else 0)
native = json.loads((OUT/'native-check.log').read_text('utf-8').strip())
self_test = json.loads((OUT/'native-self-test.log').read_text('utf-8').strip())
assert native['status']=='PASS' and native['release_id']==pins['releaseId']
assert native['native_windows_opened']==0 and native['business_app_imported'] is False
assert self_test['status']=='PASS' and self_test['checks']==144
assert self_test['native_windows_opened']==0 and self_test['business_app_imported'] is False
sender = read(OUT/'sender/SENDER-SELECTION.json')
ui = read(OUT/'ui/DOM-REQUESTS.json')
need_files = list((OUT/'need-v2').glob('*.json'))
assert len(need_files)==1
need = read(need_files[0])
assert sender['status']=='PASS' and sender['passed']==sender['total']==8
assert sender['replyConnectedSha256']==sha(N/'web/pages/reply-connected.mjs')
assert ui['status']=='PASS' and ui['passed']==ui['total']==45 and ui['sourcePinsMatch'] is True
assert len(ui['matrix'])==16 and all(row['pass'] for row in ui['matrix'])
assert need['status']=='PASS' and need['passed']==need['total']==14
assert Path(need['helper'])==N/'web/pages/customers-data.mjs'
assert need['helperSha256']==sha(N/'web/pages/customers-data.mjs')
assert need['externalRequests']==need['productionAccess']==need['visibleBrowserWindows']==0
correction = {'status':'PASS_WITH_FAILED_HARNESS_INVOCATION_RETAINED',
    'atUtc':datetime.now(timezone.utc).isoformat(),'releaseId':pins['releaseId'],
    'firstAttempt':str(OUT/'ROOT-RESULT.json'),
    'firstFailure':'First original-comment invocation failed with page.evaluate: Target page, context or browser has been closed. That invocation also omitted --helper; the error text alone does not establish the cause.',
    'correction':'A separate rerun with --helper pointing to the exact F100 frozen customers-data.mjs passed 14/14 without any product change. Both attempts are retained.',
    'correctedEvidence':str(need_files[0]),'correctedHelperSha256':need['helperSha256'],
    'nativeCheckPassed':True,'selfTestChecksPassed':144,'senderPassed':8,'uiPassed':45,
    'originalCommentPassed':14,'firstFailedLogPreserved':True,'productChangesForHarnessFix':0}
(OUT/'ROOT-CORRECTED-RESULT.json').write_text(json.dumps(correction,ensure_ascii=False,indent=2)+'\n','utf-8')
backend_path = W/'backend-audit/isolated-results.json'
backend = read(backend_path)
assert backend['status']=='PASS' and backend['testsRun']==10
mapped = []
for row in backend['sourcePins']:
    old_path = Path(row['path'])
    target = N/old_path.relative_to(old_native) if old_path.is_relative_to(old_native) else F/'project'/old_path.relative_to(OLD/'project')
    assert sha(target)==row['sha256'], str(target)
    mapped.append({'path':str(target),'sha256':row['sha256']})
binding = {'status':'PASS_UNCHANGED_TESTED_BACKEND_BYTES','files':len(mapped),
    'backendEvidenceSha256':sha(backend_path),'newRelease':pins['releaseId'],'mappedSources':mapped}
(OUT/'UNCHANGED-BACKEND-BINDING.json').write_text(json.dumps(binding,ensure_ascii=False,indent=2)+'\n','utf-8')
formal_path = W/'FORMAL-DATA-AND-MANUAL-REPLY.json'
formal = read(formal_path)
assert formal['productionWrites']==formal['platformOrProviderOrSendCalls']==0
assert formal['highPeople']==formal['manualReplyReadReadyPeople']==133
assert formal['manualReplyReadBlockedPeople']==0 and formal['businessBefore']==formal['businessAfter']
evidence = [OUT/'ROOT-RESULT.json',OUT/'ROOT-CORRECTED-RESULT.json',
    OUT/'native-check.log',OUT/'native-self-test.log',
    OUT/'sender/SENDER-SELECTION.json',OUT/'ui/DOM-REQUESTS.json',need_files[0],
    OUT/'UNCHANGED-BACKEND-BINDING.json',formal_path,backend_path,
    W/'frontend-audit/CANDIDATE-PINS.json',W/'frontend-audit/red/SENDER-SELECTION.json',
    PACK/'ROOT-COMPOSITION-V100.json']
gates = {'status':'PASS_F100_MANUAL_REPLY_SENDER_FIX','releaseId':pins['releaseId'],
    'atUtc':datetime.now(timezone.utc).isoformat(),'unifiedPinsSha256':pins['unifiedPinsSha256'],
    'manifestSha256':pins['manifestSha256'],'changedProductSourceFiles':1,
    'senderCasesPassed':8,'uiCasesPassed':45,'originalCommentCasesPassed':14,
    'backendIsolatedChecksPassed':10,'nativeStaticChecksPassed':144,
    'manualReplyReadReadyPeople':133,'businessPreserved':True,
    'harnessFailureRetainedAndCorrected':True,
    'evidence':[{'path':str(path),'sha256':sha(path)} for path in evidence],
    'productionWrites':0,'actualCurrentWindowOperated':False,'automaticSendOperations':0}
(PACK/'ROOT-GATES-V100.json').write_text(json.dumps(gates,ensure_ascii=False,indent=2)+'\n','utf-8')
print(json.dumps({'status':gates['status'],'releaseId':gates['releaseId'],
    'gatesSha256':sha(PACK/'ROOT-GATES-V100.json'),'mappedBackendFiles':len(mapped)},ensure_ascii=False))
