"""Independent static/package review only. Never executes the installer."""
from pathlib import Path, PurePosixPath
import ast, difflib, hashlib, json
from datetime import datetime,timezone

T=Path(__file__).resolve().parent
W=T.parent
P=W.parents[1]
PACK=W/'package'
F=P/'work/parallel-integration-20261018/final-integration/candidate-unified-v100'
N=P/'work/ui-native-r57'
GEN=P/'work/parallel-integration-20261018/integration/entry/install_canonical_delegation.py'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text('utf-8'))
pins=read(PACK/'ROOT-FINAL-PINS-V100.json')
gates=read(PACK/'ROOT-GATES-V100.json')
installer=W/'install_verified_f100.py'
findings=[]
checks=[]

def check(label,condition):
    checks.append({'name':label,'pass':bool(condition)})
    if not condition:findings.append(label)

check('expected-root-gates-pin',sha(PACK/'ROOT-GATES-V100.json')=='5bcfbec913d0399864e7833ba96ab37088fdc8ff8a1832f4f47d88ba5cd725c1')
check('root-gates-pass-release-and-pins',gates['status']=='PASS_F100_MANUAL_REPLY_SENDER_FIX'
    and gates['releaseId']==pins['releaseId'] and gates['unifiedPinsSha256']==pins['unifiedPinsSha256']
    and gates['manifestSha256']==pins['manifestSha256'])
stage=read(F/'STAGED.json')
release=Path(stage['release'])
check('stage-hash-and-release-id',sha(F/'STAGED.json')==pins['stagedSha256'] and stage['release_id']==pins['releaseId'])
check('unified-pins-hash',sha(F/'UNIFIED-PINS.json')==pins['unifiedPinsSha256'])
check('release-manifest-hash',sha(release/'RELEASE.json')==pins['manifestSha256'])
closure=read(F/'UNIFIED-PINS.json')
bad=[]
for item in closure['files']:
    relative=PurePosixPath(item['path'])
    if relative.is_absolute() or '..' in relative.parts or '\\' in item['path']:
        bad.append(item['path']);continue
    path=F/'project'/item['path']
    if not path.is_file() or sha(path)!=item['sha256'].lower():bad.append(item['path'])
check('all-f100-closure-file-hashes',not bad)
evidence_bad=[]
for item in gates['evidence']:
    path=Path(item['path'])
    if not path.is_file() or sha(path)!=item['sha256'].lower():evidence_bad.append(item['path'])
check('every-root-gate-evidence-hash',not evidence_bad)

old_project=P/'work/parallel-integration-20261018/final-integration/candidate-unified-v99/project'
old_release=old_project/'work/ui-native-r57/releases/ui-r57-20261024T070458Z-6b382ca0'
old_manifest=read(old_release/'RELEASE.json')
new_manifest=read(release/'RELEASE.json')
old_entries={v['path']:v for v in old_manifest['files']}
new_entries={v['path']:v for v in new_manifest['files']}
changed=sorted(k for k in old_entries.keys()|new_entries.keys()
    if old_entries.get(k,{}).get('sha256')!=new_entries.get(k,{}).get('sha256'))
check('only-reply-connected-changes-in-release-payload',changed==['web/pages/reply-connected.mjs'])
before=(old_release/'web/pages/reply-connected.mjs').read_text('utf-8')
after=(release/'web/pages/reply-connected.mjs').read_text('utf-8')
diff=''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='F99/reply-connected.mjs',tofile='F100/reply-connected.mjs'))
(T/'F99-F100-reply-connected.diff').write_text(diff,'utf-8')
print(diff)
check('frontend-reviewed-bytes',sha(release/'web/pages/reply-connected.mjs')=='92bda4b28c8fe91ae3ae789c137e14a940a16ce68e1ffc2dbeb521267b1476f5')
backend=read(T/'isolated-results.json')
mapped=[]
for item in backend['sourcePins']:
    old=Path(item['path'])
    if old.is_relative_to(old_release):new=release/old.relative_to(old_release)
    elif old.is_relative_to(old_project):new=F/'project'/old.relative_to(old_project)
    else:raise AssertionError('unexpected backend pin path')
    mapped.append({'path':str(new),'matches':sha(new)==item['sha256']})
check('all-286-tested-backend-source-pins-unchanged',backend['status']=='PASS' and backend['testsRun']==10
    and len(mapped)==286 and all(row['matches'] for row in mapped))
check('backend-dispatch-and-delivery-unchanged',all(sha(old_release/name)==sha(release/name)
    for name in ('workbench_backend.py','reply_workbench.py','reply_delivery.py','customer_workbench.py')))

sender=read(W/'verification-f100/sender/SENDER-SELECTION.json')
ui=read(W/'verification-f100/ui/DOM-REQUESTS.json')
original=read(W/'verification-f100/need-v2/DOM-RESULT.json')
check('sender-evidence-8-pass-exact-source',sender['status']=='PASS' and sender['passed']==sender['total']==8
    and all(v['pass'] for v in sender['checks']) and sender['replyConnectedSha256']==sha(release/'web/pages/reply-connected.mjs'))
check('ui-evidence-45-pass-source-matches',ui['status']=='PASS' and ui['passed']==ui['total']==45
    and ui['sourcePinsMatch'] is True and all(v['pass'] for v in ui['checks'])
    and all(sha(release/item['relativePath'])==item['sha256'] for item in ui['verifiedSourcePins']))
check('original-comment-corrected-14-pass-exact-helper',original['status']=='PASS' and original['passed']==original['total']==14
    and all(v['pass'] for v in original['checks']) and original['helperSha256']==sha(release/'web/pages/customers-data.mjs'))
root_initial=read(W/'verification-f100/ROOT-RESULT.json')
root_corrected=read(W/'verification-f100/ROOT-CORRECTED-RESULT.json')
check('failed-harness-run-retained-and-corrected',root_initial['status']=='FAIL'
    and root_corrected['status']=='PASS_WITH_FAILED_HARNESS_INVOCATION_RETAINED'
    and root_corrected['productChangesForHarnessFix']==0
    and root_corrected['correctedHelperSha256']==original['helperSha256'])
for row in root_initial['checks']:
    check('initial-log-preserved-'+row['name'],sha(Path(row['path']))==row['sha256'])
failed_log=(W/'verification-f100/original-comment.log').read_text('utf-8')
check('first-failure-documented-without-unproven-causation',
    'Target page, context or browser has been closed' in failed_log
    and 'error text alone does not establish the cause' in root_corrected['firstFailure'])
native=read(W/'verification-f100/native-check.log')
native_self=read(W/'verification-f100/native-self-test.log')
check('native-readonly-checks-pass',native['status']==native_self['status']=='PASS' and native_self['checks']==144
    and native['release_id']==pins['releaseId'] and native['native_windows_opened']==native_self['native_windows_opened']==0)

check('canonical-F99-launcher-CAS-precondition',sha(N/'run_workbench.py')=='4e912e9456d0cadf379c51a69acda55c7ad5930451ddd15d30d3a488fc760633')
check('canonical-F99-frozen-CAS-precondition',sha(N/'FROZEN.json')=='a8db5b46a7dd635738d32f7a8eefdba1f424ca11d8025c43579984ad43fe8c87'
    and read(N/'FROZEN.json')['release_id']=='ui-r57-20261024T070458Z-6b382ca0')
binding='14cf53964f5d44d123e989805ea741669ab3f05054e730ddcb299a0aac51a9cb'
check('existing-and-candidate-workspace-binding-identical',sha(N/'state/production-workspace.json')==binding
    and sha(F/'project/work/ui-native-r57/state/production-workspace.json')==binding)
check('generic-installer-pinned',sha(GEN)=='9909f60d16ad3eaed54b9f97ea0d275ad38510c679ba651ce05af44d920ed0f6')
check('stage-launcher-hash',sha(Path(stage['launcher']))==stage['launcher_sha256'].lower())
ast.parse(installer.read_text('utf-8'));ast.parse(GEN.read_text('utf-8'))
check('installer-python-parses',True)
check('no-candidate-install-created',not (PACK/'entry-v100').exists())
delivery_code=(release/'reply_delivery.py').read_text('utf-8')
backend_code=(release/'workbench_backend.py').read_text('utf-8')
platform_code=(release/'resources/platform-runtime/platform_runtime.py').read_text('utf-8')
queue_code=(F/'project/work/ui-runtime-r55/src/core/review_queue.py').read_text('utf-8')
check('restart-queues-require-new-live-explicit-authorization',
    'self.active={}' in delivery_code and "state='authorization_expired'" in delivery_code
    and "DELIVERY_AUTH_EXPIRED" in delivery_code
    and 'defer_startup_recovery=True, defer_platform_setup=True' in platform_code
    and 'defer_startup_recovery=True)' in backend_code
    and 'self.autostart=not defer_startup_recovery' in queue_code)

report={'status':'PASS_INDEPENDENT_REVIEW' if not findings else 'BLOCKED_INDEPENDENT_REVIEW',
    'reviewedAtUtc':datetime.now(timezone.utc).isoformat(),'blockingFindings':findings,'approvedForRootInstall':not findings,
    'releaseId':pins['releaseId'],'unifiedPinsSha256':pins['unifiedPinsSha256'],'manifestSha256':pins['manifestSha256'],
    'rootPinsSha256':sha(PACK/'ROOT-FINAL-PINS-V100.json'),'rootGatesSha256':sha(PACK/'ROOT-GATES-V100.json'),
    'installerSha256':sha(installer),'genericInstallerSha256':sha(GEN),'checks':checks,
    'closureFilesVerified':len(closure['files']),'gateEvidenceFilesVerified':len(gates['evidence']),
    'unchangedBackendSourcePinsVerified':len(mapped),'releasePayloadChangedFiles':changed,
    'reviewedFrontendEffect':'Preserves the explicit draft sender choice through saved-draft replacement; clears missing choices instead of silently choosing another account. Existing explicit confirmation, stale-confirmation rejection, backend approval snapshot and atomic customer reservation remain unchanged.',
    'installerReview':'Wrapper binds old F99 launcher/FROZEN, F100 stage/unified/release hashes, gates/evidence/review hash, and both workspace bindings. Pinned generic installer exclusively backs up canonical launcher and FROZEN, CAS-checks immediately before each replace, checks new hashes and company preservation, and rolls back only matching old/new bytes. It writes only entry/package evidence and these two next-open entry files; no restart, database migration, credential read, platform CLI or message call.',
    'harnessNote':'First original-comment runner failed with browser/context closed; Root also reports missing --helper in that invocation, but its log alone does not establish causation. The failure and result are retained. A separate explicit-helper rerun passed 14/14 against the exact F100 helper without product changes; the corrected record states this distinction.',
    'restartSafetyStaticReview':'PlatformRuntime constructs AppServer with defer_startup_recovery=True and defer_platform_setup=True; backend fallback also constructs Core with defer_startup_recovery=True. ReplyDelivery starts with active={} and its queue constructor creates no worker. Worker creation is confined to ReviewedReplyQueues.start after explicit authorization. A persisted ready/awaiting/running plan without RAM authorization is exposed as authorization_expired and validation fails DELIVERY_AUTH_EXPIRED. Persisted prepared plans can be shown but do not run until an explicit confirmed start. Existing two local plans/queues therefore do not replay merely by reopening. This is static code inspection, not another production read or restart test.',
    'limitations':['No live Native window opened or operated by this reviewer.','No real platform send tested or performed; runtime/cloud/account readiness remains a real-use dependency.','Root production RO/manual-reply readiness evidence was hash-checked only; this reviewer did not open the formal DB.'],
    'reviewScope':'Static code/diff, immutable package/evidence hashes, and existing test-result inspection only. Installer not run; no suites rerun; no production data changes.'}
(PACK/'FINAL-PACKAGE-REVIEW-V100.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n','utf-8')
print(json.dumps({'status':report['status'],'approvedForRootInstall':report['approvedForRootInstall'],
    'blockingFindings':findings,'checks':len(checks),'closureFilesVerified':len(closure['files']),
    'reviewFile':str(PACK/'FINAL-PACKAGE-REVIEW-V100.json')},ensure_ascii=False))
raise SystemExit(1 if findings else 0)
