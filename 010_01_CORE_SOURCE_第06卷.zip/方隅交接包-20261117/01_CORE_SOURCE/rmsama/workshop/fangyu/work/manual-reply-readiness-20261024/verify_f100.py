"""Focused checks of the actual F100 package, using existing proven runners."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
import hashlib
import json
import os
import shutil
import subprocess
import sys

sys.dont_write_bytecode = True
sys.stdout.reconfigure(encoding='utf-8')
W = Path(__file__).resolve().parent
P = W.parents[1]
PACK = W/'package'
F = P/'work/parallel-integration-20261018/final-integration/candidate-unified-v100'
OLD = F.parent/'candidate-unified-v99'
read = lambda p:json.loads(p.read_text('utf-8'))
sha = lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
pins = read(PACK/'ROOT-FINAL-PINS-V100.json')
stage = read(F/'STAGED.json')
N = Path(stage['release'])
OUT = W/'verification-f100'
OUT.mkdir(exist_ok=False)
PY = P/'work/desktop-python/Scripts/python.exe'
NODE = Path(r'C:/Users/rmsama/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node.exe')
ui_old = P/'work/reply-draft-calibration/verification-f99'
shutil.copy2(ui_old/'verify-ui.mjs',OUT/'verify-ui.mjs')
ui_pins = read(ui_old/'SOURCE-PINS.json')
for row in ui_pins['changedFiles']:
    actual = sha(N/row['relativePath'])
    if row['relativePath'] == 'web/pages/reply-connected.mjs':
        assert actual == '92bda4b28c8fe91ae3ae789c137e14a940a16ce68e1ffc2dbeb521267b1476f5'
        row['sha256'] = actual
    else:
        assert actual == row['sha256']
(OUT/'SOURCE-PINS.json').write_text(json.dumps(ui_pins,ensure_ascii=False,indent=2)+'\n','utf-8')
need = (ui_old/'verify-need.mjs').read_text('utf-8')
old_native = Path(read(OLD/'STAGED.json')['release'])
old_web = str(old_native/'web').replace('\\','/')
assert need.count(old_web) == 1
(OUT/'verify-need.mjs').write_text(need.replace(old_web,str(N/'web').replace('\\','/')),'utf-8')

jobs = [
    ('native-check',[str(PY),'-X','utf8','-I','-B',stage['launcher'],'--check']),
    ('native-self-test',[str(PY),'-X','utf8','-I','-B',stage['launcher'],'--self-test']),
    ('sender-selection',[str(NODE),str(W/'frontend-audit/verify-sender-selection.mjs'),
        '--web',str(N/'web'),'--output',str(OUT/'sender')]),
    ('ui-regression',[str(NODE),str(OUT/'verify-ui.mjs'),'--web',str(N/'web'),'--output',str(OUT/'ui')]),
    ('original-comment',[str(NODE),str(OUT/'verify-need.mjs'),
        '--helper',str(N/'web/pages/customers-data.mjs'),'--output',str(OUT/'need')]),
]
def run(job):
    name,cmd = job
    result = subprocess.run(cmd,capture_output=True,text=True,encoding='utf-8',
        env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'},timeout=300)
    log = OUT/(name+'.log')
    log.write_text(result.stdout+'\n'+result.stderr,'utf-8')
    row = {'name':name,'exitCode':result.returncode,'path':str(log),'sha256':sha(log)}
    print(json.dumps(row,ensure_ascii=False),flush=True)
    return row

with ThreadPoolExecutor(max_workers=3) as pool:
    checks = list(pool.map(run,jobs))
summary = {'status':'PASS' if all(x['exitCode']==0 for x in checks) else 'FAIL',
    'atUtc':datetime.now(timezone.utc).isoformat(),'releaseId':pins['releaseId'],'checks':checks,
    'actualPlatformOrProviderOrSendCalls':0,'actualNativeWindowsOpened':0,'productionWrites':0}
(OUT/'ROOT-RESULT.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n','utf-8')
assert summary['status']=='PASS', checks
sender = read(OUT/'sender/SENDER-SELECTION.json')
ui = read(OUT/'ui/DOM-REQUESTS.json')
need_files = list((OUT/'need').glob('*.json'))
assert len(need_files)==1
need_result = read(need_files[0])
assert sender['status']=='PASS' and sender['passed']==sender['total']==8
assert ui['status']=='PASS' and ui['passed']==ui['total']==45 and ui['sourcePinsMatch'] is True
assert len(ui['matrix'])==16 and all(x['pass'] for x in ui['matrix'])
assert need_result['status']=='PASS' and need_result['passed']==need_result['total']==14
backend_path = W/'backend-audit/isolated-results.json'
backend = read(backend_path)
assert backend['status']=='PASS' and backend['testsRun']==10
old_project = OLD/'project'
new_project = F/'project'
mapped = []
for row in backend['sourcePins']:
    old_path = Path(row['path'])
    target = N/old_path.relative_to(old_native) if old_path.is_relative_to(old_native) else new_project/old_path.relative_to(old_project)
    assert sha(target)==row['sha256'], str(target)
    mapped.append({'path':str(target),'sha256':row['sha256']})
binding_report = {'status':'PASS_UNCHANGED_TESTED_BACKEND_BYTES','files':len(mapped),
    'backendEvidenceSha256':sha(backend_path),'newRelease':pins['releaseId'],'mappedSources':mapped}
(OUT/'UNCHANGED-BACKEND-BINDING.json').write_text(json.dumps(binding_report,ensure_ascii=False,indent=2)+'\n','utf-8')
formal_path = W/'FORMAL-DATA-AND-MANUAL-REPLY.json'
formal = read(formal_path)
assert formal['productionWrites']==formal['platformOrProviderOrSendCalls']==0
assert formal['highPeople']==formal['manualReplyReadReadyPeople']==133
assert formal['manualReplyReadBlockedPeople']==0 and formal['businessBefore']==formal['businessAfter']
evidence = [OUT/'ROOT-RESULT.json',OUT/'sender/SENDER-SELECTION.json',OUT/'ui/DOM-REQUESTS.json',
    need_files[0],OUT/'UNCHANGED-BACKEND-BINDING.json',formal_path,backend_path,
    W/'frontend-audit/CANDIDATE-PINS.json',W/'frontend-audit/red/SENDER-SELECTION.json',
    PACK/'ROOT-COMPOSITION-V100.json']
gates = {'status':'PASS_F100_MANUAL_REPLY_SENDER_FIX','releaseId':pins['releaseId'],
    'atUtc':datetime.now(timezone.utc).isoformat(),'unifiedPinsSha256':pins['unifiedPinsSha256'],
    'manifestSha256':pins['manifestSha256'],'changedProductSourceFiles':1,
    'senderCasesPassed':8,'uiCasesPassed':45,'originalCommentCasesPassed':14,
    'manualReplyReadReadyPeople':133,'businessPreserved':True,
    'evidence':[{'path':str(p),'sha256':sha(p)} for p in evidence],
    'productionWrites':0,'actualCurrentWindowOperated':False,'automaticSendOperations':0}
(PACK/'ROOT-GATES-V100.json').write_text(json.dumps(gates,ensure_ascii=False,indent=2)+'\n','utf-8')
print(json.dumps({'status':gates['status'],'releaseId':gates['releaseId'],
    'gatesSha256':sha(PACK/'ROOT-GATES-V100.json')},ensure_ascii=False),flush=True)
