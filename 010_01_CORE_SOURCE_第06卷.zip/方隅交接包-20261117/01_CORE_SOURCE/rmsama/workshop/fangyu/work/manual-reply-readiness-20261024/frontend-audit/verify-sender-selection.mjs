import {createRequire} from 'node:module';
import {readFile,writeFile,mkdir,stat} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
const D=path.dirname(fileURLToPath(import.meta.url));
const flag=n=>process.argv[process.argv.indexOf(n)+1];
const W=path.resolve(flag('--web')),OUT=path.resolve(flag('--output'));
await mkdir(OUT,{recursive:true});
const require=createRequire(import.meta.url);
const {chromium}=require('C:/Users/rmsama/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const browser=await chromium.launch({headless:true}),page=await browser.newPage();
let external=0,api=0;
await page.route('**/*',async route=>{
 const u=new URL(route.request().url());
 if(u.hostname!=='fixture.test'){external++;return route.abort();}
 if(u.pathname==='/fixture.html')return route.fulfill({contentType:'text/html',body:'<!doctype html><html><body><div id="root"></div></body></html>'});
 if(u.pathname.startsWith('/api/')){api++;return route.abort();}
 const file=path.resolve(W,'.'+u.pathname);if(!file.startsWith(W+path.sep))return route.abort();
 try{await stat(file);return route.fulfill({contentType:path.extname(file)==='.mjs'?'text/javascript':'application/octet-stream',body:await readFile(file)});}catch{return route.fulfill({status:404,body:''});}
});
await page.goto('https://fixture.test/fixture.html');
const checks=await page.evaluate(async()=>{
 const R=await import('/pages/reply-connected.mjs'),root=document.querySelector('#root');
 const checks=[],assert=(v,m)=>{if(!v)throw Error(m);},settle=()=>new Promise(r=>setTimeout(r,25));
 const actor={username:'fixture-user',storeId:'fixture-store'},id='a'.repeat(64),lead='b'.repeat(32);
 const accounts=[{id:'fixture-account-1',platform:'xiaohongshu',status:'ready',platformNickname:'合成发送账号甲'},{id:'fixture-account-2',platform:'xiaohongshu',status:'ready',platformNickname:'合成发送账号乙'}];
 function state(){
  const s={authEpoch:1,user:actor.username,storeId:actor.storeId,activePlatform:'xiaohongshu',connection:'connected',session:{user:{username:actor.username,tenant_id:'fixture-tenant',role:'employee'}},page:'reply',platform:{accounts}};
  R.renderConnected(s);const p={id,name:'合成客户',platform:'xiaohongshu',channel:'小红书',postTitle:'合成原帖',postUrl:'https://www.xiaohongshu.com/explore/fixture',quote:'合成原评论',shortNeed:'需求待补充',level:'高意向',tone:'high',contactLabel:'待回复'};
  Object.assign(s.replyLive,{status:'ready',items:[p],total:1,page:1,pages:1,stats:{total:1,replied:0},loadedAt:Date.now(),selectedId:id,leadId:lead,text:'后台已存草稿',accountId:accounts[0].id,detail:{actor,customerId:id,item:p,comments:[{id:lead,text:'合成原评论',platform:'xiaohongshu',postTitle:p.postTitle,postUrl:p.postUrl,sourceDigest:'fixture-digest',accounts,canSave:true,canReview:true,reviewCurrent:false,draft:{id:'fixture-draft',version:1,text:'后台已存草稿',status:'draft'}}]}});
  return s;
 }
 function draw(s,extras={}){root.innerHTML=R.renderConnected(s);const ctx={state:s,update:fn=>fn?.(s),toast:()=>{},modal:()=>{},replyError:()=>{},...extras};R.bindConnected(root,ctx);return ctx;}
 function account(id){const el=root.querySelector('[data-live-account]');el.value=id;el.dispatchEvent(new Event('change',{bubbles:true}));}
 function edit(text){const el=root.querySelector('[data-live-draft]');el.value=text;el.dispatchEvent(new Event('input',{bubbles:true}));}
 async function test(name,fn){try{checks.push({name,pass:true,details:await fn()});}catch(e){checks.push({name,pass:false,error:e.message});}}
 function savePort(s,calls){return async payload=>{calls.push(payload);const detail=structuredClone(s.replyLive.detail);Object.assign(detail.comments[0],{reviewCurrent:false,canReview:true});detail.comments[0].draft={id:'fixture-draft',version:2,text:payload.text,status:'draft'};return{replyWorkspace:detail};};}
 await test('chosen_second_sender_survives_save_dirty_draft',async()=>{
  const s=state(),calls=[];draw(s,{replySave:savePort(s,calls)});account(accounts[1].id);edit('本人修改后的草稿');root.querySelector('[data-live-save]').click();await settle();
  const actual=s.replyLive.accountId;assert(calls.length===1&&calls[0].text==='本人修改后的草稿','save did not persist exact edited text');assert(!s.replyLive.dirty&&!s.replyLive.pending,'save left draft dirty or pending');
  assert(actual===accounts[1].id,`selected ${accounts[1].id}, after saving became ${actual}`);return{actual,saves:calls.length,pending:s.replyLive.pending};
 });
 await test('save_and_review_confirmation_keeps_explicit_second_sender',async()=>{
  const s=state(),saves=[],modals=[];let reviewCalls=0,deliveryCalls=0;draw(s,{replySave:savePort(s,saves),replyReview:async()=>{reviewCalls++;},deliveryAction:async()=>{deliveryCalls++;},modal:m=>modals.push(m)});account(accounts[1].id);edit('需要核对的本人草稿');root.querySelector('[data-live-review]').click();await settle();
  const modal=modals.find(m=>m.title==='确认回复 · 逐条核对');assert(modal,'review confirmation missing');assert(modal.html.includes('合成发送账号乙')&&!modal.html.includes('合成发送账号甲'),`confirmation displays wrong sender: ${s.replyLive.accountId}`);assert(reviewCalls===0&&deliveryCalls===0,'save/review click skipped confirmation');return{sender:s.replyLive.accountId,reviewCalls,deliveryCalls};
 });
 await test('explicit_empty_sender_is_not_silently_reselected_after_save',async()=>{
  const s=state(),calls=[];draw(s,{replySave:savePort(s,calls)});account('');edit('仅保存、不指定账号');root.querySelector('[data-live-save]').click();await settle();assert(s.replyLive.accountId==='',`empty account silently became ${s.replyLive.accountId}`);return{saves:calls.length};
 });
 await test('refresh_preserves_chosen_sender_with_unchanged_saved_draft',async()=>{
  const s=state(),detail=structuredClone(s.replyLive.detail);draw(s,{replyCustomers:async()=>({customers:{actor,items:s.replyLive.items,total:1,page:1,pages:1,stats:s.replyLive.stats}}),replyRead:async()=>({replyWorkspace:detail})});account(accounts[1].id);root.querySelector('[data-live-reload]').click();await settle();assert(s.replyLive.accountId===accounts[1].id,`refresh replaced chosen sender with ${s.replyLive.accountId}`);return{sender:s.replyLive.accountId};
 });
 await test('removed_sender_clears_choice_instead_of_substituting_first',async()=>{
  const s=state(),calls=[];draw(s,{replySave:async payload=>{const response=await savePort(s,calls)(payload);response.replyWorkspace.comments[0].accounts=[accounts[0]];return response;}});account(accounts[1].id);edit('账号权限刚变更时保存');root.querySelector('[data-live-save]').click();await settle();assert(s.replyLive.accountId==='',`removed sender silently substituted with ${s.replyLive.accountId}`);return{saves:calls.length,sender:s.replyLive.accountId};
 });
 await test('changing_sender_after_confirmation_rejects_stale_confirm_without_send',async()=>{
  const s=state(),modals=[];let reviewCalls=0,deliveryCalls=0;draw(s,{modal:m=>modals.push(m),replyReview:async()=>{reviewCalls++;},deliveryAction:async()=>{deliveryCalls++;}});root.querySelector('[data-live-review]').click();await settle();const modal=modals.find(m=>m.title==='确认回复 · 逐条核对');assert(modal,'confirmation missing');account(accounts[1].id);const result=await modal.onConfirm();assert(result===false&&reviewCalls===0&&deliveryCalls===0,'stale account confirmation reached mutation/delivery');return{reviewCalls,deliveryCalls,pending:s.replyLive.pending};
 });
 await test('sender_changed_after_successful_save_requires_confirmation_without_unknown_send',async()=>{
  const s=state(),calls=[],modals=[];let reviewCalls=0,deliveryCalls=0;draw(s,{replySave:savePort(s,calls),modal:m=>modals.push(m),replyReview:async()=>{reviewCalls++;},deliveryAction:async()=>{deliveryCalls++;}});edit('先保存，再换账号');root.querySelector('[data-live-save]').click();await settle();account(accounts[1].id);root.querySelector('[data-live-review]').click();await settle();const modal=modals.find(m=>m.title==='确认回复 · 逐条核对');assert(modal?.html.includes('合成发送账号乙'),'new sender not confirmed');assert(reviewCalls===0&&deliveryCalls===0&&!s.replyLive.pending&&!s.replyDelivery.attempt,'sender change caused unknown or automatic send');return{reviewCalls,deliveryCalls,pending:s.replyLive.pending,deliveryAttempt:s.replyDelivery.attempt};
 });
 await test('switching_sender_on_old_approved_draft_reconfirms_new_sender',async()=>{
  const s=state(),modals=[];s.replyLive.detail.comments[0].reviewCurrent=true;Object.assign(s.replyLive.detail.comments[0].draft,{status:'approved',review_account_id:accounts[0].id});let reviewCalls=0,deliveryCalls=0;draw(s,{modal:m=>modals.push(m),replyReview:async()=>{reviewCalls++;},deliveryAction:async()=>{deliveryCalls++;}});account(accounts[1].id);root.querySelector('[data-live-review]').click();await settle();const modal=modals.find(m=>m.title==='确认回复 · 逐条核对');assert(modal?.html.includes('合成发送账号乙'),'old approval bypassed new account confirmation');assert(reviewCalls===0&&deliveryCalls===0&&!s.replyLive.pending&&!s.replyDelivery.attempt,'old approval initiated unknown or automatic send');return{reviewCalls,deliveryCalls,pending:s.replyLive.pending,deliveryAttempt:s.replyDelivery.attempt};
 });
 return checks;
});
await browser.close();
const sha256=createHash('sha256').update(await readFile(path.join(W,'pages/reply-connected.mjs'))).digest('hex');
const report={status:checks.every(c=>c.pass)&&external===0&&api===0?'PASS':'FAIL',verifiedWeb:W,replyConnectedSha256:sha256,checks,passed:checks.filter(c=>c.pass).length,total:checks.length,externalRequests:external,actualApiRequests:api,productionAccess:0,visibleBrowserWindows:0,scope:'Headless synthetic fixtures only; no native window or platform validation.'};
await writeFile(path.join(OUT,'SENDER-SELECTION.json'),JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report,null,2));if(report.status!=='PASS')process.exitCode=1;
