from pathlib import Path
import shutil
W=Path(__file__).resolve().parents[1]
R=W.parents[1]/'region-followup-20261027/assembly/project/work/ui-native-r57/releases/ui-r57-20261027T060342Z-7716d199'
F=W/'tests/fixture-web'
for source in (R/'web').rglob('*.mjs'):
    target=F/source.relative_to(R/'web');target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,target)
for source in (W/'overlay/web').rglob('*.mjs'):
    shutil.copyfile(source,F/source.relative_to(W/'overlay/web'))
