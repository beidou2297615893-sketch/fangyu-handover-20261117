"""Exercise original isolated suite with these three overlay modules preloaded."""
from pathlib import Path
import importlib
import sys
import unittest

sys.dont_write_bytecode = True
root = Path(__file__).parent
previous = root.parents[1] / 'region-followup-20261027'
sys.path[:0] = [str(root / 'overlay/work/ui-native-r57'),
               str(previous / 'assembly/project/work/ui-native-r57')]
for module in ('resident_tone_preset', 'reply_handoff', 'reply_ai_provider', 'reply_ai_workflow'):
    importlib.import_module(module)
suite = unittest.TestSuite()
suite.addTests(unittest.defaultTestLoader.discover(str(previous / 'inbox'), pattern='test_*.py'))
result = unittest.TextTestRunner(verbosity=2).run(suite)
sys.exit(not result.wasSuccessful())
