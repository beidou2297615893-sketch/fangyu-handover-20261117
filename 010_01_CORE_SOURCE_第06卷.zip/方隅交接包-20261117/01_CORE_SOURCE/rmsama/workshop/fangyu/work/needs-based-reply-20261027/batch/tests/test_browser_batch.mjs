import assert from 'node:assert/strict';
import http from 'node:http';
import path from 'node:path';
import {readFile,mkdir,writeFile} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import {createRequire} from 'node:module';
const require=createRequire(import.meta.url),{chromium}=require('C:/Users/rmsama/.codex/skills/xhs-note-creator/node_modules/playwright');
const W=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..'),F=path.join(W,'tests/fixture-web'),B='C:/积木软件工坊/项目/方隅公寓客户版/work/region-followup-20261027/assembly/project/work/ui-native-r57/releases/ui-r57-20261027T060342Z-7716d199/web',out=path.join(W,'evidence/browser');
await mkdir(out,{recursive:true});
const html=`<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>隔离批量草稿核对</title><link rel="stylesheet" href="/styles.css"><link rel="stylesheet" href="/reference-ai.css"><style>body{margin:0;padding:16px;background:#f7fbfa;color:#193b37}body>div{max-width:1300px;margin:auto}main{min-width:0}*{box-sizing:border-box}button,select,input,textarea{font:inherit}</style><div class="reply-page rp-reference"><div class="rp-reference-ai"><main></main></div></div><script type="module">
import {renderAI,bindAI} from '/pages/reply-ai.mjs';
const accounts=[{id:'a',name:'合成本人账号',profile:{configured:true,confirmed:true,roleFacts:'本人是租房交流者，不声称住户身份',topics:[],revision:1}}],v={items:Array.from({length:605},(_,i)=>({id:'c'+i,name:'合成客户'+i,aggregateState:'current',interestStatus:'graded',interestLevel:'low',demandState:'active',regionMatch:{state:'match'},storeEligibility:{state:'no_known_exclusion',role:'demand'},contactState:'none'})),selectedId:'c0',ai:{open:true,accountId:'a',range:'qualified',styleReadAccount:'a',styleInfo:{savedTone:{revision:1},accountProfile:accounts[0].profile,styleModes:[]}},accountRouting:{data:{accounts,routes:[],groups:[]}}},s={user:'synthetic',storeId:'s',authEpoch:1,page:'reply',activePlatform:'xiaohongshu',session:{user:{id:'u'}},replyLive:v};
window.calls=[];const ctx={state:s,update:paint,toast:()=>{},replyAI:async(action,data)=>{window.calls.push({action,data});return {replyAI:{id:'job',state:'done',rows:[]}};},followupAction:async(action,data)=>({context:{...data,actorId:'u',scopeKey:'a'.repeat(64)},preferences:{firstReplyOffer:{enabled:false}}})};
function paint(){document.querySelector('main').innerHTML=renderAI(s,v);bindAI(document.querySelector('main'),ctx,v);}paint();</script>`;
const server=http.createServer(async(q,r)=>{try{const name=decodeURIComponent(new URL(q.url,'http://localhost').pathname);if(name==='/'){r.setHeader('content-type','text/html;charset=utf-8');return r.end(html);}if(name.includes('..'))throw Error('path');let data;try{data=await readFile(path.join(F,name));}catch{data=await readFile(path.join(B,name));}r.setHeader('content-type',name.endsWith('.mjs')?'text/javascript':name.endsWith('.css')?'text/css':name.endsWith('.svg')?'image/svg+xml':'application/octet-stream');r.end(data);}catch{r.writeHead(404);r.end();}});
await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
const browser=await chromium.launch({headless:true}),errors=[],external=[];
try{
 const page=await browser.newPage({viewport:{width:1440,height:1000}}),origin='http://127.0.0.1:'+server.address().port;
 page.on('pageerror',e=>errors.push(e.message));await page.route('**/*',r=>r.request().url().startsWith(origin)?r.continue():(external.push(r.request().url()),r.abort()));
 await page.goto(origin);await page.waitForSelector('[data-ai-scope-count]');
 assert.equal(await page.locator('[data-ai-scope-count]').getAttribute('data-selected-count'),'300');
 await page.locator('[data-ai-batch-next]').click();await page.locator('[data-ai-start]').click();
 await page.waitForFunction(()=>window.calls.some(c=>c.action==='reply_ai_start'));
 const call=await page.evaluate(()=>window.calls.find(c=>c.action==='reply_ai_start'));assert.equal(call.data.customerIds[0],'c300');assert.deepEqual(call.data.gradeBands,['super_high','high','medium','low','very_low']);
 assert.match(await page.locator('[data-ai-handoff-state]').innerText(),/已关闭/);
 for(const width of [1440,800]){await page.setViewportSize({width,height:1000});await page.screenshot({path:path.join(out,'batch-'+width+'.png'),fullPage:true});const fits=await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth);if(!fits)console.log(await page.evaluate(()=>[...document.querySelectorAll('main *')].filter(e=>e.getBoundingClientRect().right>innerWidth).map(e=>({tag:e.tagName,cls:e.className,width:e.getBoundingClientRect().width,right:e.getBoundingClientRect().right})).slice(0,15)));assert.ok(fits,'no horizontal overflow at '+width);}
 assert.deepEqual(errors,[]);assert.deepEqual(external,[]);assert.ok(!(await page.evaluate(()=>window.calls)).some(c=>/send|save|delivery|connect/.test(c.action)));
 await writeFile(path.join(out,'RESULT.json'),JSON.stringify({status:'PASS',widths:[1440,800],minimumViewport:760,errors,external,realPlatformCalls:0,actualModelCalls:0,request:call},null,2));
 console.log('PASS isolated headless real browser, original CSS, qualified second batch c300 with five-level gate, account-off state, 1440/800 screenshots (existing desktop CSS minimum 760), no external/model/platform/sending');
}finally{await browser.close();await new Promise(resolve=>server.close(resolve));}
