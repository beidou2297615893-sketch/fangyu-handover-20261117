'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict');
const {fixture,H,UUID}=require('./followup_fixture.cjs');
const {createService}=require('../candidate/service.cjs');
const MATERIAL='67c3b2cf6f8babda9fb5516ff2aeaed9b138d58cb898908d8729ae768d14f914';
function serviceFor(f,options={}){return createService({store:f.store,environmentId:'test-env',companyId:'fangyu-apartment-client',clock:f.clock,...options});}
function serviceCall(service,operation,payload={}){return service({environment_id:'test-env',operation,...payload},'local-test-device-token');}
async function authorize(f,{native=false,options={},material=MATERIAL}={}){
 const config=native?{employeeReleaseEnabled:true,employeeReleaseVersion:'1.1.8-pilot.1'}:{customerReadReleaseEnabled:true,customerReadReleaseVersion:'1.2.0-read.1'};
 const service=serviceFor(f,{...config,...options});
 const request={version:native?'1.1.8-pilot.1':'1.2.0-read.1',reviewed_reply_protocol:'fangyu-reviewed-reply-v1',material_sha256:material,accept_commands:false,
  ...(native?{workbench_source_release:'fangyu-admin-local-v1'}:{customer_read_protocol:'fangyu-customer-read-v1'})};
 const poll=await serviceCall(service,'device_poll',request);
 return {service,poll,request,config};
}
async function start(f,p,{attempt=p.attempt_id,digest=p.request_digest,metadata=true,text='宝宝留个手机号，我让销售联系你呀。'}={}){
 const event={event_id:UUID(),kind:'send_started',occurred_at:1793099950,lead:{...f.lead,text:'可以，把销售微信给我。',comment_id:'incoming-comment',parent_id:'incoming-comment'},
  reply:{id:p.reply_id,text,...(metadata?{followup_attempt_id:attempt,followup_request_digest:digest}:{})},sender:f.sender};
 assert.equal((await f.call('contact_events_sync',{events:[event]})).status,200);return event;
}
test('both admitted versions require real authenticated poll before a one-use consume',async()=>{for(const native of [false,true]){const f=fixture({native}),s=await f.initial(),p=f.payload(s);const a=await authorize(f,{native});assert.equal(a.poll.status,200);assert.equal(a.poll.data.reviewed_reply_release.allowed,true);assert.equal(a.poll.data.customer_read_release?.public_send_allowed??false,false);const r=await serviceCall(a.service,'contact_followup_consume',p);assert.equal(r.status,200);assert.equal(r.data.newlyConsumed,true);assert.equal((await serviceCall(a.service,'contact_followup_consume',p)).status,409);}});
test('new frozen sender material and retained previous material both admit only their exact digest',async()=>{for(const native of [false,true])for(const material of [MATERIAL,'0b393c8b352571b639326c17078cdf3aa2550dc50fc10ecc5d2fbbb1356baf85']){const f=fixture({native}),s=await f.initial(),p={...f.payload(s),material_sha256:material},a=await authorize(f,{native,material});assert.equal(a.poll.data.reviewed_reply_release.allowed,true);assert.equal(a.poll.data.reviewed_reply_release.material_sha256,material);const result=await serviceCall(a.service,'contact_followup_consume',p);assert.equal(result.status,200);assert.equal(result.data.scope.materialSha256,material);}});
test('same prepared start already synchronized is the only open start allowed',async()=>{const f=fixture({strictReads:true}),s=await f.initial(),p=f.payload(s);await start(f,p);const a=await authorize(f);assert.equal(a.poll.data.reviewed_reply_release.allowed,true);const r=await serviceCall(a.service,'contact_followup_consume',p);assert.equal(r.status,200);assert.equal(r.data.scope.replyTextSha256,p.reply_text_sha256);});
test('consume before start is also valid and exact paired terminal closes the cloud lock',async()=>{const f=fixture({strictReads:true}),s=await f.initial(),p=f.payload(s),a=await authorize(f);assert.equal((await serviceCall(a.service,'contact_followup_consume',p)).status,200);const begun=await start(f,p);const sent={...begun,event_id:UUID(),kind:'sent',occurred_at:1793099951,reply:{...begun.reply,platform_reply_id:'our-followup'},sender:{...begun.sender,platform_uid:'self-uid'}};assert.equal((await f.call('contact_events_sync',{events:[sent]})).status,200);const stored=[...f.docs().values()].filter(x=>x.scope?.attemptId===p.attempt_id&&x.state==='sent');assert.equal(stored.length,2);});
test('old metadata-free start, different attempt, request digest or text remains blocking',async()=>{for(const options of [{metadata:false},{attempt:'f'.repeat(32)},{digest:'e'.repeat(64)},{text:'不同的正文'}]){const f=fixture(),s=await f.initial(),p=f.payload(s);await start(f,p,options);const a=await authorize(f);const r=await serviceCall(a.service,'contact_followup_consume',p);assert.equal(r.status,409);assert.equal(r.data.code,'CONTACT_FOLLOWUP_BUSY');}});
test('two same-metadata new starts do not become one reusable wire attempt',async()=>{const f=fixture(),s=await f.initial(),p=f.payload(s);await start(f,p);await start(f,p);const a=await authorize(f);assert.equal((await serviceCall(a.service,'contact_followup_consume',p)).status,409);});
test('closed policy, QA, wrong native source, invalid admin identity and old poll deny without a turn write',async()=>{
 const cases=[{native:false,options:{customerReadReleaseEnabled:false}},
  {native:false,options:{platformQaDeviceId:'device-one'}},
  {native:true,options:{employeeReleaseEnabled:false}},
  {native:true,alterRequest:r=>({...r,workbench_source_release:'wrong'})},
  {native:true,mutate:f=>f.mutate(s=>s.users[0].role='operator')},
  {native:false,after:f=>f.advance(46)},
  {native:false,after:f=>f.mutate(s=>s.users[0].can_reply=false)},
  {native:false,after:f=>f.mutate(s=>s.users[0].permission_revision=77)},
  {native:false,after:f=>f.mutate(s=>s.devices[0].version='1.1.8-pilot.1')}];
 for(const c of cases){const f=fixture({native:c.native}),s=await f.initial(),p=f.payload(s);c.mutate?.(f);let a=await authorize(f,{native:c.native,options:c.options});if(c.alterRequest)a.poll=await serviceCall(a.service,'device_poll',c.alterRequest(a.request));c.after?.(f);const r=await serviceCall(a.service,'contact_followup_consume',p);assert.notEqual(r.status,200);assert.equal([...f.docs().values()].filter(x=>x.turnKey).length,0);}
});
test('release or QA policy changed after an admitted poll immediately invalidates its grant',async()=>{for(const options of [{customerReadReleaseEnabled:false},{platformQaDeviceId:'device-one'},{employeeReleaseEnabled:true,employeeReleaseVersion:'wrong'}]){const f=fixture(),s=await f.initial(),p=f.payload(s);const a=await authorize(f);assert.equal(a.poll.data.reviewed_reply_release.allowed,true);const changed=serviceFor(f,{...a.config,...options});assert.equal((await serviceCall(changed,'contact_followup_consume',p)).status,403);}});
test('malformed or truncated history counter/page fails closed',async()=>{for(const mutate of [docs=>{for(const d of docs.values())if(d.author_id==='customer-uid'&&'timeline_count'in d)d.timeline_count=-1;},docs=>{for(const d of docs.values())if(d.items?.some(x=>x.kind==='send_started'))d.items=[];},docs=>{for(const d of docs.values())if(d.author_id==='customer-uid'&&'response_count'in d)d.response_count=NaN;}]){const f=fixture(),s=await f.initial(),p=f.payload(s);mutate(f.docs());assert.notEqual((await f.call('contact_followup_consume',p)).status,200);}});
