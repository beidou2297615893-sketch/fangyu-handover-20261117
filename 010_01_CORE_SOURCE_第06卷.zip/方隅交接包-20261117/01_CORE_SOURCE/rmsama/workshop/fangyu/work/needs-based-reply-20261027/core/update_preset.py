import importlib.util
import json
import hashlib
from pathlib import Path

root = Path(__file__).parent
path = root / 'overlay/work/ui-native-r57/resident_tone_preset.py'
spec = importlib.util.spec_from_file_location('old_preset', path)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
data = module.PRESET
data['version'] = 2
data['prompt'] = '''每条用宝宝起头，通常一两句自然短口气话。先抓目标客户本人评论的具体需求：价格、预算、宠物、低楼层、电梯、户型、租期、停车、朝向或看房；目标原评论优先，再补同一客户已保存且不冲突的其他留言。帖子作者、root、parent、replyTo和其他人的经历与需求不能算到客户身上；直接回复对象未知时不猜。客户没提的诉求不强塞，已知条件不反问，别每条机械问预算入住时间。
先接具体需求，再根据本条firstReplyOfferSnapshot.policy决定是否由当前账号本人承接。仅firstReplyOffer.enabled=true且policy.action为offer_help、sales_contact或request_phone时，才自然接一句我帮你问、我帮你约或我帮你联系销售。只有policy.capabilities.canIntroduceDiscount=true时才可说我介绍可优惠或我介绍还能便宜；未确认这段关系只说本人帮问或帮约，不保证结果。开关关闭时只回应需求，不加介绍优惠、约看、帮问销售、联系本人等承接句。blocked时不推销；clarify时先核需求时效和是否考虑古北，不因旧high或低中高等级越过资格。
原帖就是方隅时直接接话，其他房源用另一个选择自然切入，不能冒充原房源回答。明确其他片区、拒绝公寓或拒绝古北先暂缓；地点未知仅澄清古北接受度。询价不等于低预算。低楼层疑虑不等于怕没电梯，先分清在意楼层还是电梯。
对应账号已确认roleFacts是身份和个人事实唯一来源；小北住户、推荐有积分、本人介绍可优惠和方隅有电梯均是用户提供的账号限定事实，未经当前账号确认不移植，也不把默认referralName当身份。缺事实照样能拟无身份声明的需求回复；开关与资格允许时可本人帮问。宠物政策、具体折扣价、房源库存和约看结果不可编造。参考示例仅借口气，不继承身份、优惠、电梯、宠物或房源事实。47条AI稿仍待校准，不能当用户认可语料。'''
feedback = root.parents[1] / 'region-followup-20261027/voice-review-47/hook-revision/user-feedback.json'
raw = json.loads(feedback.read_text(encoding='utf-8-sig'))
data['calibrationReferences'] = [dict(text=text, origin='user_spoken', userProvided=True,
    modelDraft=False, approvedReply=False, accountScopedFacts=True,
    source='voice-review-47/hook-revision/user-feedback.json', sourceAtUtc=raw['atUtc'],
    speechRecognition=raw['speechRecognition']) for text in raw['userExamples']]
data['calibrationNotice'] = '继续微调中；新示范来自用户口述，不代表47条AI草稿已认可，个人事实需当前账号独立确认。'
data['sourceContractVersion'] = 'needs-based-personal-handoff-v2'
data.setdefault('legacyDerivedContractSha256', data['derivedContractSha256'])
data['derivedContractSha256'] = hashlib.sha256(json.dumps({k:v for k,v in data.items() if k != 'derivedContractSha256'}, ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
old = path.read_text(encoding='utf-8')
tail = old[old.index('\n\ndef preset_snapshot'):]
path.write_text('"""Fixed user-sourced wording; references never establish account facts."""\nfrom copy import deepcopy\n\nPRESET = ' + repr(data) + '\n' + tail, encoding='utf-8')
