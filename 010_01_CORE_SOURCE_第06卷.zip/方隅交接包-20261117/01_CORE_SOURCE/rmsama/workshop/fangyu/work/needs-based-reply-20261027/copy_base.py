"""Clone the exact previously verified project for an isolated incremental release."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,shutil,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;P=W.parents[1];old=P/'work/region-followup-20261027'
read=lambda p:json.loads(p.read_text('utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 assert sys.argv[1:]==['--clone-exact-base']
 pins=read(old/'FROZEN-PINS.json');index=old/'assembly/UNIFIED-PINS.json'
 assert sha(index)==pins['unifiedPinsSha256'];source=Path(pins['project']);target=W/'assembly/project'
 rows=read(index)['files'];expected={x['path'] for x in rows};actual={x.relative_to(source).as_posix() for x in source.rglob('*') if x.is_file()}
 assert len(rows)==len(expected)==9298 and actual==expected,'Prior project closure changed.'
 assert not target.exists()
 target.mkdir(parents=True)
 for row in rows:
  s=source/row['path'];d=target/row['path']
  assert not s.is_symlink() and s.stat().st_size==row['bytes'] and sha(s)==row['sha256'],row['path']
  d.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(s,d)
  assert d.stat().st_size==row['bytes'] and sha(d)==row['sha256'],row['path']
 result={'status':'EXACT_PREVIOUS_PROJECT_COPIED','atUtc':datetime.now(timezone.utc).isoformat(),
  'sourcePinsSha256':sha(old/'FROZEN-PINS.json'),'sourceIndexSha256':sha(index),'files':len(rows),
  'sourceProject':str(source),'targetProject':str(target),'priorReleaseId':pins['releaseId'],
  'productionWrites':False,'realMessagesSent':False}
 with (W/'BASE-COPY.json').open('x',encoding='utf-8') as f:json.dump(result,f,ensure_ascii=False,indent=2)
 print(json.dumps({'status':result['status'],'files':len(rows)}))
if __name__=='__main__':main()
