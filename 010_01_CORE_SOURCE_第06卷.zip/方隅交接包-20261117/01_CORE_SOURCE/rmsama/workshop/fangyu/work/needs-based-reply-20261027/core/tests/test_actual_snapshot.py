"""Use the installed backend's existing temporary SQLite fixture, not production."""
import copy
import importlib.util
from pathlib import Path
import sys
import unittest

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[1]
PREVIOUS = ROOT.parents[1] / 'region-followup-20261027'
sys.path[:0] = [str(ROOT / 'overlay/work/ui-native-r57'), str(PREVIOUS / 'assembly/project/work/ui-native-r57')]
# Preload the exclusive overlay before the original fixtures add their source path.
import resident_tone_preset
import reply_handoff
import reply_ai_provider
import reply_ai_workflow
spec = importlib.util.spec_from_file_location('old_cas_fixture', PREVIOUS / 'inbox/test_handoff_snapshot_cas.py')
old = importlib.util.module_from_spec(spec)
spec.loader.exec_module(old)
from reply_ai_workflow import Workflow


class ActualSnapshotTests(unittest.TestCase):
    def setUp(self):
        self.case = old.HandoffSnapshotCASTests()
        self.case.setUp()
        self.addCleanup(self.case.doCleanups)

    def test_account_scoped_discount_capability_is_frozen_into_real_workflow_request(self):
        f = self.case
        row = f.b.core.store.get(old.PROFILES, f.profile_key)
        row['value']['roleFacts'] = '我是小北，真实租户，本人介绍可优惠，推荐方隅有积分，方隅有电梯。'
        f.b.core.store.put(old.PROFILES, row)
        f.prefs(firstReplyOffer={'enabled': True, 'mode': 'request_phone', 'shareContactApproved': False})
        for level in ('high', 'medium', 'low'):
            f.item['interestLevel'] = level
            s = f.snapshot()
            self.assertEqual(s['scope']['accountId'], 'a1')
            self.assertTrue(s['policy']['capabilities']['canIntroduceDiscount'])
            self.assertEqual(s['qualification']['interestLevel'], level)
        workflow = Workflow(f.b, provider=lambda *args: None, local_identity=f.b._identity)
        target = {'target': {'id': 'comment-id', 'authorId': 'customer1', 'text': '低楼层有吗？'},
                  'root': {'authorId': 'other-person', 'text': '有宠物'}, 'post': {'title': '古北求租'}}
        item = {'customerId': f.f.cid, 'leadId': 'l1', 'sourceDigest': 'a' * 64,
                'context': target, 'sourceBinding': {'history': [{'id': 'l1', 'sourceDigest': 'a' * 64,
                    'conversation': target}], 'packetDigest': 'b' * 64}}
        item['handoffSnapshot'] = f.snapshot(item)
        job = {'tone': '口吻', 'styleSnapshot': {'savedTone': {'stylePresetId': 'resident_seeding_v1'}},
               'styleReferences': [], 'sampleDigest': 'c' * 64, 'requestId': 'request-needs'}
        request = workflow.execution_request(job, item, f.user, f.scope)
        handoff = request['tone_snapshot']['firstReplyOfferSnapshot']
        self.assertTrue(handoff['policy']['capabilities']['canIntroduceDiscount'])
        self.assertEqual(handoff['scope']['accountId'], 'a1')
        self.assertEqual(request['context']['conversation']['target']['text'], '低楼层有吗？')

    def test_role_and_uid_changes_revoke_personal_capability_without_overwriting_old_record(self):
        f = self.case
        profile = f.b.core.store.get(old.PROFILES, f.profile_key)
        profile['value']['roleFacts'] += '，本人介绍可优惠'
        f.b.core.store.put(old.PROFILES, profile)
        f.prefs(firstReplyOffer={'enabled': True, 'mode': 'request_phone', 'shareContactApproved': False})
        original = f.snapshot()
        self.assertTrue(original['policy']['capabilities']['canIntroduceDiscount'])
        account = copy.deepcopy(f.f.fixture.account)
        account['platform_uid'] = 'replacement-uid'
        f.b.core.store.put('accounts', account)
        current = f.snapshot()
        self.assertFalse(current['roleProfile']['configured'])
        self.assertFalse(current['policy']['capabilities']['canIntroduceDiscount'])
        self.assertTrue(original['policy']['capabilities']['canIntroduceDiscount'])
        with self.assertRaises(old.HandoffExpired):
            old.revalidate(f.b, f.user, f.scope, f.f.cid, f.f.token, original)

    def test_actual_edit_then_confirm_cannot_bypass_preset_off_fact_guards(self):
        f = self.case
        from core.customer_followup_targets import customer_id
        f.f.fixture.lead={**f.f.fixture.lead,'author_id':'fresh-needs-customer'}
        f.f.cid=customer_id(f.f.fixture.lead)
        f.item['id']=f.f.cid
        lead = {**f.f.fixture.lead, 'id': 'l2', 'comment_id': 'new-needs-comment', 'reply_status': 'unreplied'}
        f.b.core.store.put('leads', lead)
        detail_original = f.b.customer_workbench.detail_context
        def detail(user, store, customer, platform=None):
            a, p, item, person = detail_original(user, store, customer, platform=platform)
            person['comments']=[{'lead_id': 'l2', 'text': '古北低楼层有吗'}]
            return a, p, item, person
        f.b.customer_workbench.detail_context = detail
        f.b.customer_workbench.detail = lambda user, store, customer, platform=None: detail(user, store, customer, platform=platform)[2]
        workflow = Workflow(f.b, provider=lambda *args: None, local_identity=f.b._identity)
        workspace = f.b.reply_workbench.read(f.user, 's1', f.f.cid, platform='xiaohongshu')
        target = next(x for x in workspace['comments'] if x['id'] == 'l2')
        row = {'customerId': f.f.cid, 'leadId': 'l2', 'name': '客户', 'sourceDigest': target['sourceDigest'],
               'context': target['conversation'], 'historySources': {x['id']: x['sourceDigest'] for x in workspace['comments']},
               'text': '宝宝想要低楼层呀？', 'status': 'ready', 'routingSnapshot': None, 'selected': True, 'analysis': None}
        row['packet'], row['sourceBinding'] = workflow.capture_packet(f.user, f.scope, row, workspace=workspace)
        row['handoffSnapshot'] = f.snapshot(row)
        job = {'id': 'edit-confirm-needs', 'tenant_id': 't1', 'scope': f.scope, 'rows': [row], 'cancel': False,
               'revision': 1, 'state': 'completed', 'tone': '', 'requestId': 'edit-confirm-request',
               'styleSnapshot': {'savedTone': {'stylePresetId': 'resident_seeding_v1'}},
               'styleReferences': [], 'sampleDigest': old.digest([])}
        workflow.put(job)
        base = {'storeId': 's1', 'accountId': 'a1', 'platform': 'xiaohongshu', 'jobId': job['id']}
        with self.assertRaises(ValueError):
            workflow.dispatch('reply_ai_edit', {**base, 'revision': 1, 'edits': [{'leadId': 'l2', 'text': '宝宝介绍可优惠', 'selected': True}]}, f.f.token)
        job['rows'][0]['text']='宝宝介绍可优惠'
        workflow.put(job)
        invalid = f.b.core.store.get(old.ENTITY, job['id'])
        key = workflow.confirmation_key(invalid, invalid['rows'][0])
        with self.assertRaises(ValueError):
            workflow.dispatch('reply_ai_confirm', {**base, 'leadId': 'l2', 'confirmed': True, 'confirmationKey': key}, f.f.token)
        self.assertEqual(len(f.b.core.store.list('replies', 't1')), 1)
        self.assertEqual(f.b.core.store.get('replies', 'r1')['status'], 'sent')
        workflow.dispatch('reply_ai_edit', {**base, 'revision': invalid['revision'], 'edits': [{'leadId': 'l2', 'text': '宝宝想要低楼层呀？', 'selected': True}]}, f.f.token)
        valid = f.b.core.store.get(old.ENTITY, job['id'])
        key = workflow.confirmation_key(valid, valid['rows'][0])
        workflow.dispatch('reply_ai_confirm', {**base, 'leadId': 'l2', 'confirmed': True, 'confirmationKey': key}, f.f.token)
        final = f.b.core.store.get(old.ENTITY, job['id'])
        self.assertEqual(final['rows'][0]['attempts'][-1]['state'], 'confirmed')
        self.assertEqual(len(f.b.core.store.list('replies', 't1')), 2)
        self.assertEqual(f.b.core.store.get('replies', 'r1')['status'], 'sent')


if __name__ == '__main__': unittest.main()
