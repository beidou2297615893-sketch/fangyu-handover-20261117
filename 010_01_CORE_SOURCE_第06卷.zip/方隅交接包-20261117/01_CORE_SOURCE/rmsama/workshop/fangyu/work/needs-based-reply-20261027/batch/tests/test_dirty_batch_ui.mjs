import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {renderAI,bindAI} from './fixture-web/pages/reply-ai.mjs';
const require=createRequire('C:/积木软件工坊/项目/方隅公寓客户版/work/region-followup-20261027/assembly/project/work/ui-native-r57/public_article_generic/package.json');
const {JSDOM}=require('jsdom'),dom=new JSDOM('<main></main>');globalThis.document=dom.window.document;globalThis.CSS={escape:s=>s};
const main=document.querySelector('main'),calls=[];
const job={id:'job',state:'done',revision:1,rows:[{leadId:'lead',customerId:'c0',name:'合成客户',status:'ready',text:'原草稿',selected:false}]};
const v={items:Array.from({length:301},(_,i)=>({id:'c'+i})),selectedId:'c0',ai:{accountId:'a',range:'list',styleInfo:{savedTone:{revision:1}},styleReadAccount:'a',handoffReadAccount:'a',job}};
const s={user:'u',storeId:'s',authEpoch:1,activePlatform:'xiaohongshu',page:'reply',replyLive:v};
const ctx={state:s,update:paint,toast:()=>{},replyAI:async(action,data)=>{calls.push({action,data});if(action==='reply_ai_edit')return {replyAI:{...job,rows:job.rows.map(r=>({...r,...data.edits[0]}))}};return {replyAI:{id:'newjob',state:'done',rows:[]}};}};
function paint(){main.innerHTML=renderAI(s,v);bindAI(main,ctx,v);}
const tick=()=>new Promise(r=>setTimeout(r,5));paint();
const originalJob=v.ai.job,input=main.querySelector('[data-ai-text]');input.value='本人未保存的微调';input.dispatchEvent(new dom.window.Event('input',{bubbles:true}));
// Changing page or reloading/generating a different job must not discard current edits.
assert.equal(v.ai.draftDirty,true,'typing an unsaved edit must establish dirty state');
for(const selector of ['[data-ai-start]','[data-ai-load]','[data-ai-account]','[data-ai-range]','[data-ai-batch-next]']){
 assert.equal(main.querySelector(selector).disabled,true,selector+' must preserve unsaved edits');main.querySelector(selector).click();
}
await tick();assert.equal(calls.length,0);assert.equal(v.ai.job,originalJob);assert.equal(v.ai.job.rows[0].text,'本人未保存的微调');
main.querySelector('[data-ai-save]').click();await tick();
assert.equal(calls[0].action,'reply_ai_edit');assert.equal(calls[0].data.edits[0].text,'本人未保存的微调');assert.equal(v.ai.draftDirty,false);
assert.equal(main.querySelector('[data-ai-batch-next]').disabled,false);main.querySelector('[data-ai-batch-next]').click();assert.equal(v.ai.batchPage,1);
main.querySelector('[data-ai-pick]').click();assert.equal(v.ai.draftDirty,true,'changed review selection is also an unsaved edit');
assert.equal(main.querySelector('[data-ai-start]').disabled,true);assert.equal(main.querySelector('[data-ai-load]').disabled,true);
// An already-open regeneration dialog cannot replace edits made before its confirmation.
v.ai.draftDirty=false;v.ai.styleInfo.accountProfile={configured:true};v.leadId='lead';v.detail={item:{name:'合成客户'},comments:[{id:'lead',canSave:true,draft:{id:'old',version:1,status:'draft'},sourceDigest:'source'}]};
v.accountRouting={data:{accounts:[],routes:[{customerId:'c0',assignment:{accountId:'a'}}]},open:false};
let modal;ctx.modal=options=>{modal=options;};paint();main.querySelector('[data-ai-regenerate]').click();assert.ok(modal?.onConfirm);
const duringDialog=main.querySelector('[data-ai-text]');duringDialog.value='弹窗后本人修改';duringDialog.dispatchEvent(new dom.window.Event('input',{bubbles:true}));
const beforeConfirm=calls.length;assert.equal(await modal.onConfirm(),false);assert.equal(calls.length,beforeConfirm);assert.equal(v.ai.job.rows[0].text,'弹窗后本人修改');
console.log('PASS unsaved text and selection survive page/new-generation/reload/account changes; real edit payload saves before unlocking');
