"""Verify exact code-only delta and full readback without network access."""
from pathlib import Path
import hashlib,json,zipfile
D=Path(__file__).resolve().parent;W=D.parent
read=lambda p:json.loads(p.read_text('utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def files(root):return {p.relative_to(root).as_posix():{'sha256':sha(p),'bytes':p.stat().st_size} for p in root.rglob('*') if p.is_file()}
def tree(rows):return hashlib.sha256(''.join(k+'\0'+rows[k]['sha256']+'\n' for k in sorted(rows)).encode()).hexdigest()
def archive_files(folder):
 folder=Path(folder);r=read(folder/'LIVE-READBACK.json');entries=read(folder/'LIVE-CODE-FILES.json')
 index={x['path']:{'sha256':x['sha256'],'bytes':x['bytes']} for x in entries}
 assert len(index)==len(entries)==r['files'] and sha(folder/'live-function-code.zip')==r['codeZipSha256']
 actual={}
 with zipfile.ZipFile(folder/'live-function-code.zip') as z:
  for info in z.infolist():
   if info.is_dir():continue
   assert info.filename not in actual
   raw=z.read(info);actual[info.filename]={'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw)}
 assert index==actual and tree(actual)==r['treeSha256']
 return actual
def local_material():
 c=read(D/'COMPOSITION.json');base=read(D/'BASE.json');current=files(D/'candidate')
 assert base['treeSha256']==c['beforeTree'] and len(base['sourceIndex'])==5620
 assert len(current)==5620 and tree(current)==c['afterTree']
 delta={k for k in current.keys()|base['sourceIndex'].keys() if current.get(k)!=base['sourceIndex'].get(k)}
 assert delta=={'reviewed_reply_release.cjs'} and c['unchangedOriginalFiles']==5619
 for row in c['changedFiles']:
  assert base['sourceIndex'][row['path']]['sha256']==row['beforeSha256'] and current[row['path']]['sha256']==row['afterSha256']
 pins=read(W/'FROZEN-PINS.json');assert sha(W/'FROZEN-PINS.json')==c['rootPinsSha256']
 release=Path(pins['release']);assert sha(release/'RELEASE.json')==pins['manifestSha256']
 material=read(release/'reviewed_reply_materials.json')
 canonical=hashlib.sha256(json.dumps(material,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
 assert canonical==c['registrationMaterialDigest'] and sha(release/'reviewed_reply_materials.json')==c['registrationMaterialFileSha256']
 return current
def verify(folder):
 expected=local_material();actual=archive_files(folder);assert expected==actual
 return {'status':'PASS','treeSha256':tree(actual),'verifiedFiles':len(actual),'unchangedOriginalFiles':5619,'archiveBytesVerified':True}
