"""Independently rerun core behavior and preserved regression suites."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime,timezone
import hashlib,json,subprocess,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;C=W/'core';out=W/'verification/core';out.mkdir(parents=True,exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def run(case):
 name,args=case
 r=subprocess.run([sys.executable,'-B','-X','utf8',*args],capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=120)
 log=out/(name+'.log');log.write_text(r.stdout+'\n'+r.stderr,'utf-8')
 return {'name':name,'exitCode':r.returncode,'logSha256':sha(log),'outputTail':(r.stdout+r.stderr)[-300:]}
def main():
 manifest=C/'evidence/FINAL-CORE-MANIFEST.json';before=sha(manifest)
 cases=[('new-behaviors',['-m','unittest','discover','-s',str(C/'tests'),'-p','test_*.py']),('preserved-inbox',[str(C/'run_regression.py')])]
 with ThreadPoolExecutor(max_workers=2) as e:results=list(e.map(run,cases))
 assert before==sha(manifest) and all(x['exitCode']==0 for x in results),results
 data={'status':'PASS','atUtc':datetime.now(timezone.utc).isoformat(),'coreManifestSha256':before,'checks':results,'realPlatformCalls':0,'modelCalls':0,'productionWrites':False}
 (out/'RESULT.json').write_text(json.dumps(data,ensure_ascii=False,indent=2),'utf-8');print(json.dumps(data,ensure_ascii=False))
if __name__=='__main__':main()
