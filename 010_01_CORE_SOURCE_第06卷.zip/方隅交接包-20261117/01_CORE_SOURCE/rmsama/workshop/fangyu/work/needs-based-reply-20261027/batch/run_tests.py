from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess,sys,os,re
W=Path(__file__).resolve().parent
R=W.parents[1]/'region-followup-20261027/assembly/project/work/ui-native-r57/releases/ui-r57-20261027T060342Z-7716d199'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','PYTHONIOENCODING':'utf-8'}
prepared=subprocess.run([sys.executable,'-B',str(W/'tests/prepare_ui_fixture.py')],cwd=W,env=env,capture_output=True)
assert prepared.returncode==0,prepared.stderr.decode('utf-8','replace')
commands=[('qualified-routing',[sys.executable,'-B',str(W/'tests/test_qualified_routing.py'),'-v'])]+[(name,['node',str(W/'tests'/name)]) for name in ['test_batch_ui.mjs','test_dirty_batch_ui.mjs','test_save_recovery_ui.mjs','test_resident_examples.mjs','test_browser_batch.mjs']]
checks=[]
for name,cmd in commands:
    result=subprocess.run(cmd,cwd=W,env=env,capture_output=True,timeout=60)
    log=W/'evidence'/('final-'+name+'.log');log.write_bytes(result.stdout+b'\n'+result.stderr)
    checks.append({'name':name,'exitCode':result.returncode,'log':str(log),'logSha256':sha(log)})
    print(name,result.returncode)
assert all(c['exitCode']==0 for c in checks),checks
legacy=[]
for name in ('legacy-multi-account.log','legacy-multi-account-baseline.log'):
    p=W/'evidence'/name;s=p.read_text(encoding='utf-8-sig')
    legacy.append({'path':str(p),'sha256':sha(p),'failures':re.findall(r'^(?:ERROR|FAIL): (\S+)',s,re.M),'result':re.findall(r'^FAILED .*',s,re.M)})
assert legacy[0]['failures']==legacy[1]['failures']
files=[]
for path in sorted((W/'overlay').rglob('*')):
    if not path.is_file():continue
    rel=path.relative_to(W/'overlay').as_posix();baseline=R/rel
    files.append({'relativePath':rel,'path':str(path),'sha256':sha(path),'bytes':path.stat().st_size,'baselinePath':str(baseline),'baselineSha256':sha(baseline)})
assert len(files)==4
result={'status':'PASS_CURRENT_SCOPED_CHECKS','atUtc':datetime.now(timezone.utc).isoformat(),'checks':checks,'legacyHarnessComparison':{'sameFailingNames':True,'checks':legacy,'note':'Copied older 20261026 harness is incompatible with current baseline source-binding/paths. Same 3 failures + 8 errors on unmodified baseline and overlay; not counted as passing current validation.'},'realModelCalls':0,'realPlatformCalls':0,'realSending':0,'productionOrCloudWrites':0,'browserWidths':[1440,800],'desktopMinimumViewport':760,'userVisualAcceptance':False,'sourceFiles':files}
(W/'RESULT.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
manifest={'status':'FROZEN_FOR_REVIEW','baseRelease':'ui-r57-20261027T060342Z-7716d199','atUtc':result['atUtc'],'files':files,'resultPath':str(W/'RESULT.json'),'resultSha256':sha(W/'RESULT.json'),'newQualifiedStartContract':{'selectionMode':'qualified','gradeBands':['super_high','high','medium','low','very_low'],'legacyCallsOmitBothFields':True},'semanticLimits':['Only currently loaded customer rows; explicit batch navigation and 50/100/200/300 size.','Qualified backend creation gate is owned by core overlay and must be integrated together.','Old default recommendation retains high-only behavior; no new clarification-only batch mode.','Unknown save receipts reconcile by read of exact same job/text/selected/source only; conflicts preserve local text.','Original sends, account facts/UID binding, formal old drafts and review queue are not bypassed.','Only synthetic DOM/browser and temporary local Store tests; no user approval or live platform acceptance.']}
(W/'OVERLAY-MANIFEST.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
print('MANIFEST',sha(W/'OVERLAY-MANIFEST.json'))
