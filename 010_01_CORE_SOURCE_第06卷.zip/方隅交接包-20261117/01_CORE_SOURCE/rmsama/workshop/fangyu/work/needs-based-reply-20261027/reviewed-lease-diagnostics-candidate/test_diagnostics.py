import logging
import json
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from reviewed_reply_diagnostic import classify, observe, CODES
from customer_read_store import TimingRecorder

class DiagnosticTest(unittest.TestCase):
    def setUp(self):
        revision='a'*64
        self.scope={'material_sha256':'synthetic-secret-material', 'purpose':'reviewed_reply',
            'company_id':'synthetic-company','device_id':'synthetic-device',
            'owner':'synthetic-owner','version':'synthetic-version'}
        grant={**self.scope,'schema':'fangyu_reviewed_reply_lease_v1', 'allowed':True,
            'public_send_allowed':True, 'permission_revision':revision, 'lease_seconds':45}
        self.kw=dict(attached=True,response={'safety_hold':False,'reviewed_reply_release':grant},
            request_valid=True,request_values=self.scope,user_values={'permission_revision':revision,'can_reply':True},
            poll_started=100,now=101,lease_accepted=False)

    def test_all_decision_boundaries(self):
        k=self.kw
        self.assertEqual(classify(**{**k,'attached':False}), 'REQUEST_NOT_ATTACHED')
        self.assertEqual(classify(**{**k,'response':None}), 'HEARTBEAT_ERROR')
        self.assertEqual(classify(**{**k,'response':{}}), 'CLOUD_NO_GRANT')
        self.assertEqual(classify(**{**k,'response':{'reviewed_reply_release':{'allowed':False}}}), 'CLOUD_DENIED')
        self.assertEqual(classify(**{**k,'request_valid':False}), 'LOCAL_REQUEST_INVALID')
        self.assertEqual(classify(**{**k,'response':{**k['response'],'safety_hold':True}}), 'LOCAL_SAFETY_HOLD')
        g=k['response']['reviewed_reply_release']
        def gcase(field,value): return {**k,'response':{**k['response'],'reviewed_reply_release':{**g,field:value}}}
        self.assertEqual(classify(**gcase('schema','wrong')), 'LOCAL_GRANT_FORMAT')
        self.assertEqual(classify(**gcase('device_id','different')), 'LOCAL_GRANT_SCOPE')
        self.assertEqual(classify(**gcase('permission_revision','wrong')), 'LOCAL_PERMISSION')
        self.assertEqual(classify(**gcase('lease_seconds',46)), 'LOCAL_EXPIRY')
        self.assertEqual(classify(**{**k,'now':145}), 'LOCAL_EXPIRY')
        self.assertEqual(classify(**k), 'LOCAL_UNCLASSIFIED')
        self.assertEqual(classify(**{**k,'lease_accepted':True}), 'LEASE_ACCEPTED')

    def test_logger_contains_only_fixed_code(self):
        records=[]
        class Handler(logging.Handler):
            def emit(self, record): records.append(record)
        logger=logging.getLogger('fangyu.fixed_control_stage'); handler=Handler()
        oldlevel=logger.level; logger.addHandler(handler); logger.setLevel(logging.INFO)
        try:
            fake=SimpleNamespace(valid=lambda runner: False)
            observe(False, None, fake, None, 100, None)
        finally:
            logger.removeHandler(handler);logger.setLevel(oldlevel)
        self.assertEqual(len(records),1)
        self.assertEqual(records[0].msg,'reviewed_reply_stage')
        self.assertEqual(records[0].diagnostic_code,'REQUEST_NOT_ATTACHED')
        self.assertIn(records[0].diagnostic_code,CODES)
        self.assertNotIn('synthetic-secret',repr(records[0].__dict__))

    def test_observer_exception_does_not_escape(self):
        class Broken:
            def valid(self,runner): raise ValueError('sensitive value')
        self.assertIsNone(observe(True,{},Broken(),None,100,None))

    def test_file_handler_sanitizes_untrusted_extra(self):
        logger=logging.getLogger('fangyu.fixed_control_stage')
        handlers=logger.handlers[:];level=logger.level;propagate=logger.propagate
        try:
            with tempfile.TemporaryDirectory() as directory:
                path=Path(directory)/'timing.jsonl'
                TimingRecorder(path).attach_control_logger()
                logger.info('reviewed_reply_stage',extra={'diagnostic_code':'synthetic-secret-token'})
                logger.info('reviewed_reply_stage',extra={'diagnostic_code':'CLOUD_DENIED','unsafe':'synthetic-secret-token'})
                raw=path.read_text(encoding='ascii')
                rows=[json.loads(line) for line in raw.splitlines()]
                self.assertNotIn('synthetic-secret-token',raw)
                self.assertEqual([r['error_code'] for r in rows],['DIAGNOSTIC_ERROR','CLOUD_DENIED'])
        finally:
            logger.handlers[:]=handlers;logger.setLevel(level);logger.propagate=propagate

if __name__ == '__main__': unittest.main()
