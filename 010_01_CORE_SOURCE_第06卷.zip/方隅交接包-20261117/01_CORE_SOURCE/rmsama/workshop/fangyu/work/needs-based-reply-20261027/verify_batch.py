"""Rerun scoped batch, editing, examples and responsive-browser tests independently."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,subprocess,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;B=W/'batch';out=W/'verification/batch';out.mkdir(parents=True,exist_ok=False)
read=lambda p:json.loads(p.read_text('utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 manifest=B/'OVERLAY-MANIFEST.json';before=sha(manifest);data=read(manifest)
 for row in data['files']:
  assert sha(Path(row['path']))==row['sha256']
  if row['relativePath'].startswith('web/'):
   assert sha(B/'tests/fixture-web'/row['relativePath'][4:])==row['sha256']
 env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','PYTHONIOENCODING':'utf-8'}
 commands=[('qualified-routing',[sys.executable,'-B',str(B/'tests/test_qualified_routing.py'),'-v'])]
 commands += [(x,['node',str(B/'tests'/x)]) for x in ('test_batch_ui.mjs','test_dirty_batch_ui.mjs','test_save_recovery_ui.mjs','test_resident_examples.mjs','test_browser_batch.mjs')]
 checks=[]
 for name,command in commands:
  r=subprocess.run(command,cwd=B,env=env,capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=120)
  log=out/(name+'.log');log.write_text(r.stdout+'\n'+r.stderr,'utf-8')
  checks.append({'name':name,'exitCode':r.returncode,'logSha256':sha(log),'outputTail':(r.stdout+r.stderr)[-300:]})
 assert before==sha(manifest) and all(x['exitCode']==0 for x in checks),checks
 for row in data['files']:assert sha(Path(row['path']))==row['sha256']
 result={'status':'PASS','atUtc':datetime.now(timezone.utc).isoformat(),'batchManifestSha256':before,
  'checks':checks,'realPlatformCalls':0,'modelCalls':0,'productionWrites':False}
 (out/'RESULT.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),'utf-8');print(json.dumps(result,ensure_ascii=False))
if __name__=='__main__':main()
