'use strict';
// Offline official packer only; CLI entry and all network are disabled.
const fs=require('node:fs'),path=require('node:path'),Module=require('node:module'),vm=require('node:vm');
for(const name of ['node:http','node:https']){const m=require(name);m.request=m.get=()=>{throw Error('NETWORK_FORBIDDEN');};}
const net=require('node:net');net.connect=net.createConnection=()=>{throw Error('NETWORK_FORBIDDEN');};
const bundle='C:/Users/rmsama/AppData/Roaming/npm/node_modules/@cloudbase/cli/dist/standalone/cli.js';
const s=fs.readFileSync(bundle,'utf8'),bootstrap='var __webpack_exports__ = __webpack_require__(__webpack_require__.s = 89357);';
if(s.split(bootstrap).length!==2)throw Error('bootstrap changed');
const m=new Module(bundle,module);m.filename=bundle;m.paths=Module._nodeModulePaths(path.dirname(bundle));m._compile(s.replace(bootstrap,'var __webpack_exports__ = __webpack_require__;'),bundle);
const W=path.dirname(__dirname),candidate=path.join(W,'cloud','candidate'),out=path.join(__dirname,'corrected-package-proof');
if(fs.existsSync(out))throw Error('do not overwrite evidence');
const start=s.indexOf('    updateWithConfig(options) {',s.indexOf('let CodeUpdate = class CodeUpdate')),end=s.indexOf('\n    updateWithoutConfig(options)',start);
if(start<0||end<0)throw Error('method missing');
const sandbox={process,Promise,path_1:{default:path},i18n_1:{t:x=>x},constant_1:{},common_utils_1:{resolveFuncPathWithConfig({dir}){if(!path.isAbsolute(dir))throw Error('absolute required');return dir;}},__awaiter:function(self,args,P,gen){return new Promise((resolve,reject)=>{const it=gen.apply(self,args||[]);function step(k,v){let r;try{r=it[k](v);}catch(e){reject(e);return;}if(r.done)resolve(r.value);else Promise.resolve(r.value).then(x=>step('next',x),e=>step('throw',e));}step('next');});}};
const obj=vm.runInNewContext('({'+s.slice(start,end)+'})',sandbox);obj.doUpdateCode=x=>x;
(async()=>{const forwarded=await obj.updateWithConfig({name:'fangyu-workspace',dir:candidate,envId:'offline',config:{functionRoot:'.'},functions:[{name:'fangyu-workspace',installDependency:false,isWaitInstall:true}],log:{info(){}}});
if(forwarded.functionPath!==candidate)throw Error('wrong path');
const {FunctionPacker,CodeType}=m.exports(10654);const p=new FunctionPacker({root:forwarded.functionRootPath,functionPath:forwarded.functionPath,name:'fangyu-workspace',ignore:[],codeType:CodeType.File});
// The official clean target is explicitly confined to this new evidence directory.
p.tmpPath=out;if(path.dirname(path.resolve(p.tmpPath))!==path.resolve(__dirname))throw Error('unsafe temp path');
const zip=await p.compressFiles();fs.writeFileSync(path.join(__dirname,'CORRECTED-PACKER-PROBE.json'),JSON.stringify({status:'OFFLINE_OFFICIAL_PACKER_COMPLETED',functionPath:p.funcPath,zip,networkCalls:0,uploads:0,updates:0},null,2),{flag:'wx'});console.log(zip);
})().catch(e=>{console.error(e);process.exitCode=1;});
