# Core handoff

All four overlay files map to the same paths under assembly/project, stripping the `overlay/` prefix:
- work/ui-native-r57/reply_ai_provider.py
- work/ui-native-r57/reply_ai_workflow.py
- work/ui-native-r57/reply_handoff.py
- work/ui-native-r57/resident_tone_preset.py

Final source hashes: evidence/FINAL-CORE-MANIFEST.json. No further source mutations after freeze.

Validation in PowerShell:
```powershell
$env:PYTHONDONTWRITEBYTECODE='1'
python -m unittest discover -s 'C:/积木软件工坊/项目/方隅公寓客户版/work/needs-based-reply-20261027/core/tests'
python 'C:/积木软件工坊/项目/方隅公寓客户版/work/needs-based-reply-20261027/core/run_regression.py'
```
Environment: existing C:/Users/rmsama/miniconda3/python.exe; import overlay before the existing region-followup-20261027/assembly/project modules. All tests use temporary SQLite or synthetic records; no production writes, real provider execution, cloud mutation or platform sends. 34 new tests and 42 original regressions pass. The original red logs remain intact. The positive edit/save/confirm fixture now has a distinct synthetic customer because the original sent customer is correctly protected by the existing duplicate-send guard.

Creation-only qualification rejection now maps through the actual backend to REPLY_AI_NOT_CREATED with mutation_committed=False at all three checkpoints. Runtime rejection remains HandoffExpired. Red/green evidence is retained.
