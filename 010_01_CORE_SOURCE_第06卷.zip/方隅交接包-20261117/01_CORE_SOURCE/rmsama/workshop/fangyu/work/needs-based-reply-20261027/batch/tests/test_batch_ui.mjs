import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {renderAI,bindAI} from './fixture-web/pages/reply-ai.mjs';
const req=createRequire('C:/积木软件工坊/项目/方隅公寓客户版/work/region-followup-20261027/assembly/project/work/ui-native-r57/public_article_generic/package.json');
const {JSDOM}=req('jsdom');
const dom=new JSDOM('<main></main>');globalThis.document=dom.window.document;globalThis.CSS={escape:s=>s};
const main=document.querySelector('main'),calls=[];
const person=(id,level='low',changes={})=>({id,name:id,aggregateState:'current',analysisStatus:'graded',intentLevel:level,interestStatus:'graded',interestLevel:level,demandState:'active',regionMatch:{state:'match'},storeEligibility:{state:'no_known_exclusion',role:'demand'},contactState:'none',...changes});
const accounts=[{id:'a',name:'当前真人账号',profile:{configured:true,confirmed:true,revision:1,identityCurrent:true,roleFacts:'本人是租房交流者',topics:['pet']}}];
const info={savedTone:{revision:1},styleModes:[],accountProfile:accounts[0].profile};
const v={items:[person('super','super_high'),person('high','high'),person('middle','medium'),person('low'),person('verylow','very_low'),
 person('wrong','high',{regionMatch:{state:'other'}}),person('supply','high',{storeEligibility:{state:'excluded',role:'supply'}}),
 person('reject','high',{storeEligibility:{state:'excluded',role:'demand'}}),person('ended','high',{demandState:'ended'}),
 person('unknown','high',{regionMatch:{state:'unknown'}}),person('stale','high',{aggregateState:'stale'})],selectedId:'middle',ai:{accountId:'a',styleInfo:info,styleReadAccount:'a',range:'current',styleMode:'store'}};
const s={user:'owner',storeId:'s',activePlatform:'xiaohongshu',authEpoch:1,page:'reply',session:{user:{id:'u'}},replyLive:v};
const ctx={state:s,update:()=>paint(),toast:()=>{},replyAI:async(action,data)=>{calls.push({action,data});
 if(action==='reply_ai_start')return {replyAI:{id:'job'+calls.length,state:'done',rows:[],total:0,completed:0}};
 if(action==='reply_ai_read')return {replyAI:{...info,job:null}};
 return {replyAccounts:{accounts,customers:[],routes:[],groups:[]}};},
 followupAction:async(action,data)=>{calls.push({action,data});return {context:{...data,actorId:'u',scopeKey:'a'.repeat(64)},preferences:{firstReplyOffer:{enabled:false}}};}};
function paint(){main.innerHTML=renderAI(s,v);bindAI(main,ctx,v);}
const tick=()=>new Promise(r=>setTimeout(r,5));
function change(selector,value){const el=main.querySelector(selector);assert.ok(el,selector);el.value=value;el.dispatchEvent(new dom.window.Event('change',{bubbles:true}));}
paint();
// Without the new explicit mode, medium/low demand cannot be selected as a safe batch.
assert.ok(main.querySelector('[data-ai-range] option[value="qualified"]'),'qualified range must be a real selectable option');
change('[data-ai-range]','qualified');
assert.equal(main.querySelector('[data-ai-scope-count]').dataset.selectedCount,'5');
assert.equal(main.querySelector('[data-ai-scope-count]').dataset.loadedCount,'11');
assert.equal(main.querySelectorAll('[data-ai-grade]:checked').length,3);
main.querySelector('[data-ai-grade="high"]').click();main.querySelector('[data-ai-grade="low"]').click();
assert.equal(main.querySelector('[data-ai-scope-count]').dataset.selectedCount,'1');
main.querySelector('[data-ai-start]').click();await tick();
assert.deepEqual(calls.find(x=>x.action==='reply_ai_start').data.customerIds,['middle']);
assert.equal(calls.find(x=>x.action==='reply_ai_start').data.selectionMode,'qualified','qualified selection must bind the fresh backend eligibility gate');
assert.deepEqual(calls.find(x=>x.action==='reply_ai_start').data.gradeBands,['medium']);
assert.ok(!calls.some(x=>/send|delivery|connect|save/.test(x.action)),'scope/start does not send or alter account settings');
main.querySelector('[data-routing-preview]').click();await tick();
assert.equal(calls.find(x=>x.action==='reply_route_preview').data.selectionMode,'qualified');
v.accountRouting.data.groups=[{accountId:'a',customerIds:['middle']}];paint();
main.querySelector('[data-routing-group="a"]').click();await tick();
assert.equal(v.ai.range,'group');main.querySelector('[data-ai-start]').click();await tick();
assert.equal(calls.filter(x=>x.action==='reply_ai_start').at(-1).data.selectionMode,'qualified');
assert.deepEqual(calls.filter(x=>x.action==='reply_ai_start').at(-1).data.gradeBands,['medium'],'qualified account group retains original grade selection');
assert.equal(main.querySelector('[data-ai-range] option[value="clarify"]'),null,'no unbound clarification-only batch promise');
v.selectedId='unknown';change('[data-ai-range]','current');
main.querySelector('[data-ai-start]').click();await tick();
assert.deepEqual(calls.filter(x=>x.action==='reply_ai_start').at(-1).data.customerIds,['unknown']);
assert.ok(!Object.hasOwn(calls.filter(x=>x.action==='reply_ai_start').at(-1).data,'selectionMode'),'legacy manual current selection is unchanged');
// No automatic all-library claim; one user-selected page is bounded at 300 customers.
v.items=Array.from({length:605},(_,i)=>person('c'+i));v.ai.gradeBands=['high','medium','low'];v.ai.range='qualified';v.ai.batchPage=0;paint();
assert.equal(main.querySelector('[data-ai-scope-count]').dataset.selectedCount,'300');
main.querySelector('[data-ai-start]').click();await tick();
assert.equal(calls.filter(x=>x.action==='reply_ai_start').at(-1).data.customerIds.length,300);
assert.deepEqual(calls.filter(x=>x.action==='reply_ai_start').at(-1).data.gradeBands,['super_high','high','medium','low','very_low'],'all three bands expand to all five actual levels');
main.querySelector('[data-ai-batch-next]').click();main.querySelector('[data-ai-start]').click();await tick();
assert.equal(calls.filter(x=>x.action==='reply_ai_start').at(-1).data.customerIds[0],'c300');
main.querySelector('[data-ai-batch-next]').click();main.querySelector('[data-ai-start]').click();await tick();
assert.deepEqual(calls.filter(x=>x.action==='reply_ai_start').at(-1).data.customerIds,['c600','c601','c602','c603','c604']);
assert.ok(main.textContent.includes('已载入 605')&&main.textContent.includes('600 条评论'));
// A comment-heavy batch can be reduced explicitly without losing later customers.
change('[data-ai-batch-size]','50');
assert.equal(main.querySelector('[data-ai-scope-count]').dataset.selectedCount,'50');
main.querySelector('[data-ai-batch-next]').click();main.querySelector('[data-ai-start]').click();await tick();
assert.deepEqual(calls.filter(x=>x.action==='reply_ai_start').at(-1).data.customerIds,[...Array(50)].map((_,i)=>'c'+(50+i)));
// Configured-off is visible and never silently enabled by selecting the resident preset.
main.querySelector('[data-ai-handoff-refresh]').click();await tick();
assert.ok(main.querySelector('[data-ai-handoff-state]').textContent.includes('已关闭'));
assert.ok(!calls.some(x=>x.action==='followup_preferences_save'));
const originalFollowup=ctx.followupAction;ctx.followupAction=async(action,data)=>({context:{...data,accountId:'wrong',actorId:'u',scopeKey:'a'.repeat(64)},preferences:{firstReplyOffer:{enabled:true}}});
main.querySelector('[data-ai-handoff-refresh]').click();await tick();
assert.equal(v.ai.handoffInfo,null,'another account response must not present its enabled state as current');
assert.ok(main.querySelector('[data-ai-handoff-state]').textContent.includes('未核对'));
ctx.followupAction=originalFollowup;
// Unknown start results freeze the exact selected scope until original-result reconciliation.
const original=ctx.replyAI;ctx.replyAI=async(action,data)=>{if(action==='reply_ai_start'){calls.push({action,data});throw Error('synthetic unknown result');}return original(action,data);};
main.querySelector('[data-ai-start]').click();await tick();
assert.ok(v.ai.startPending?.requestId);assert.equal(main.querySelector('[data-ai-range]').disabled,true);
assert.deepEqual(v.ai.startPending.gradeBands,['super_high','high','medium','low','very_low']);
assert.equal(main.querySelector('[data-ai-batch-next]').disabled,true);
const beforeRetry=calls.filter(x=>x.action==='reply_ai_start').length;main.querySelector('[data-ai-start]').click();await tick();
assert.equal(calls.filter(x=>x.action==='reply_ai_start').length,beforeRetry,'unknown request must not regenerate');
ctx.replyAI=original;v.ai.startPending=null;paint();
const start=main.querySelector('[data-ai-start]'),count=calls.length;s.authEpoch++;start.click();await tick();
assert.equal(calls.length,count,'stale handlers may not generate after auth changes');
console.log('PASS batch UI: qualified grade filters and group snapshot expand all five levels, excluded axes, legacy current unknown selection, 300/50 paging, actual qualified start request, configured-off/foreign-account states, unknown-result freeze, no sending/settings mutation, stale-auth guard');
