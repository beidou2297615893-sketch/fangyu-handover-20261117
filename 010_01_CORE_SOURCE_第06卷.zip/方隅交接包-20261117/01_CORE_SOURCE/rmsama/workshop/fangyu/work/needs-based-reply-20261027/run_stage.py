"""Stage an already reviewed candidate only after the dry-run succeeds."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess,sys
W=Path(__file__).resolve().parent;out=W/'verification/staging';out.mkdir(parents=True,exist_ok=False)
checks=[]
for mode in ('--dry-run','--stage-prepared-candidate'):
 r=subprocess.run([sys.executable,'-B','-X','utf8',str(W/'closure/stage_inactive.py'),mode],capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=400)
 log=out/(mode[2:]+'.log');log.write_text(r.stdout+'\n'+r.stderr,'utf-8')
 checks.append({'mode':mode,'exitCode':r.returncode,'logSha256':hashlib.sha256(log.read_bytes()).hexdigest(),'output':r.stdout[-1400:]})
 print(json.dumps({'mode':mode,'exitCode':r.returncode}),flush=True)
 if r.returncode:break
status='PASS' if len(checks)==2 and all(x['exitCode']==0 for x in checks) else 'FAILED_STOP'
(out/'RESULT.json').write_text(json.dumps({'status':status,'atUtc':datetime.now(timezone.utc).isoformat(),'checks':checks,'productionWrites':False},ensure_ascii=False,indent=2),'utf-8')
if status!='PASS':raise SystemExit(1)
