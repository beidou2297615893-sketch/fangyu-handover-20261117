"""Verify exact assembled closure and source-bound tests before installation."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;read=lambda p:json.loads(p.read_text('utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 pins=read(W/'FROZEN-PINS.json');A=Path(pins['project']);closure=read(W/'assembly/UNIFIED-PINS.json')
 assert sha(W/'assembly/UNIFIED-PINS.json')==pins['unifiedPinsSha256']
 expected={x['path'] for x in closure['files']};actual={p.relative_to(A).as_posix() for p in A.rglob('*') if p.is_file()}
 assert expected==actual and len(expected)==len(closure['files'])
 for row in closure['files']:
  f=A/row['path'];assert not f.is_symlink() and f.stat().st_size==row['bytes'] and sha(f)==row['sha256'],row['path']
 assert sha(Path(pins['release'])/'RELEASE.json')==pins['manifestSha256'] and sha(Path(pins['launcherPath']))==pins['launcherSha256']
 assert sha(W/'assembly/STAGED.json')==pins['stagedSha256'] and sha(W/'assembly/CHANGES.final.json')==pins['changesSha256']
 core=read(W/'core/evidence/FINAL-CORE-MANIFEST.json');batch=read(W/'batch/OVERLAY-MANIFEST.json')
 assert read(W/'review/independent-core/REVIEW.json')['manifestSha256']==sha(W/'core/evidence/FINAL-CORE-MANIFEST.json')
 assert read(W/'review/independent-batch/REVIEW.json')['manifestSha256']==sha(W/'batch/OVERLAY-MANIFEST.json')
 for rel,h in core['files'].items():assert sha(A/rel.removeprefix('overlay/'))==h,rel
 for row in batch['files']:
  n=row['relativePath'];rel='work/ui-native-r57/'+n if not n.startswith('web/') else 'work/ui-approved-implementation/ui-preview/'+n[4:]
  assert sha(A/rel)==row['sha256'],rel
 mapping=read(W/'assembly/generated/FINAL-SOURCE-MAP.json')['files']
 for n,row in mapping.items():assert sha(A/n)==sha(Path(row['candidatePath']))==row['sha256'],n
 evidence=['verification/core/RESULT.json','verification/batch/RESULT.json','verification/preserved-bound/RESULT.json','verification/staging/RESULT.json','verification/entry-final/RESULT.json']
 for n in evidence:assert read(W/n)['status']=='PASS',n
 assert read(W/evidence[0])['coreManifestSha256']==sha(W/'core/evidence/FINAL-CORE-MANIFEST.json')
 assert read(W/evidence[1])['batchManifestSha256']==sha(W/'batch/OVERLAY-MANIFEST.json')
 for n in evidence[:3]:
  record=read(W/n);folder=(W/n).parent
  for check in record['checks']:assert check['exitCode']==0 and sha(folder/(check['name']+'.log'))==check['logSha256']
 preserved=read(W/evidence[2])
 for n,h in preserved['sourceSha256'].items():assert sha(A/n)==h,n
 for n,h in preserved['testInputSha256'].items():assert sha(Path(n))==h,n
 assert preserved['runnerSha256']==sha(W/'verify_preserved_bound.py')
 for check in read(W/evidence[3])['checks']:
  assert check['exitCode']==0 and sha(W/'verification/staging'/(check['mode'][2:]+'.log'))==check['logSha256']
 entry=read(W/evidence[-1]);assert entry['rootPinsSha256']==sha(W/'FROZEN-PINS.json') and entry['releaseId']==pins['releaseId']
 assert entry['sourceUnmodified'] and entry['canonicalUnchanged']
 for c in entry['checks']:assert c['exitCode']==0 and c['result']['status']=='PASS' and sha(W/'verification/entry-final'/(c['name'][2:]+'.log'))==c['logSha256']
 result={'status':'PASS','atUtc':datetime.now(timezone.utc).isoformat(),'rootPinsSha256':sha(W/'FROZEN-PINS.json'),
  'releaseId':pins['releaseId'],'completeClosureFiles':len(expected),'changedSourceFiles':len(mapping),
  'sourceBoundEvidence':{n:sha(W/n) for n in evidence},'independentCoreReviewSha256':sha(W/'review/independent-core/REVIEW.json'),
  'independentBatchReviewSha256':sha(W/'review/independent-batch/REVIEW.json'),
  'productionWrites':False,'realModelCalls':0,'realPlatformCalls':0,'realMessagesSent':0,
  'notVerified':['Live platform send/receive','User acceptance of all 47 drafts','Small-screen native UI']}
 out=W/'verification/integrated';out.mkdir(parents=True,exist_ok=False)
 (out/'RESULT.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),'utf-8')
 print(json.dumps({'status':'PASS','completeClosureFiles':len(expected),'resultSha256':sha(out/'RESULT.json')}))
if __name__=='__main__':main()
