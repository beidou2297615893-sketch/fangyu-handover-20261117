"""Run existing workflow and tone regressions against the integrated candidate."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime,timezone
import hashlib,json,os,subprocess,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;P=W.parents[1];A=W/'assembly/project';native=A/'work/ui-native-r57'
old=P/'work/reply-tone-integration-20261026-final';prior=P/'work/region-followup-20261027'
out=W/'verification/preserved';out.mkdir(parents=True,exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','PYTHONUTF8':'1','SCOPE_TEST_NATIVE':str(native),'TONE_TEST_NATIVE':str(native),'SCOPE_TEST_PROJECT':str(A),'TONE_TEST_PROJECT':str(A)}
def run(case):
 name,args=case;r=subprocess.run([sys.executable,'-B','-X','utf8',*args],env=env,capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=120)
 log=out/(name+'.log');log.write_text(r.stdout+'\n'+r.stderr,'utf-8')
 return {'name':name,'exitCode':r.returncode,'logSha256':sha(log),'outputTail':(r.stdout+r.stderr)[-350:]}
def main():
 cases=[('workflow',[str(old/'tests/test_workflow.py')]),
  ('confirmation',[str(prior/'inbox/first-reply-verification/adapted/test_confirmation_recovery.py')]),
  ('tone-provider',[str(old/'backend/tests/test_tone_integration.py'),'--project',str(A)])]
 with ThreadPoolExecutor(max_workers=3) as e:results=list(e.map(run,cases))
 result={'status':'PASS' if all(x['exitCode']==0 for x in results) else 'FAILED_REVIEW_REQUIRED',
  'atUtc':datetime.now(timezone.utc).isoformat(),'checks':results,'productionWrites':False,'realPlatformCalls':0,'modelCalls':0}
 (out/'RESULT.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),'utf-8');print(json.dumps(result,ensure_ascii=False))
 if result['status']!='PASS':raise SystemExit(1)
if __name__=='__main__':main()
