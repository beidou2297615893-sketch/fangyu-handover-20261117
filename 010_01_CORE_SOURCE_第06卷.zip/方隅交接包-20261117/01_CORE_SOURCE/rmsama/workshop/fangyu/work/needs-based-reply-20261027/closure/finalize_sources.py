"""Build exact incremental source closure inside this work area only.

--dry-run reads sources and prints a plan; --prepare-inactive-only changes only A
and writes independent review evidence. Neither mode freezes/installs/launches UI.
"""
from pathlib import Path, PurePosixPath
import ast, hashlib, json, re, sys

sys.dont_write_bytecode = True
C = Path(__file__).resolve().parent
W = C.parent
P = W.parents[1]
A = W / 'assembly/project'
OLD = P / 'work/region-followup-20261027'
SOURCE = 'work/shared-backend-integration/vendor-src/SOURCE.json'
MATERIALS = ['work/ui-native-r57/reply_public_read_materials.json', 'work/ui-native-r57/reviewed_reply_materials.json']
EXE_SHA = '998831579f4f2a729039d3d0924d69fb9da09f820e965403a93681ed03452d31'
RX = re.compile(r'(?<![0-9a-fA-F])[0-9a-fA-F]{64}(?![0-9a-fA-F])')
HISTORY_PREFIX = 'work/ui-native-r57/releases/'

def read(p): return json.loads(p.read_text('utf-8-sig'))
def digest(b): return hashlib.sha256(b).hexdigest()
def sha(p):
    h = hashlib.sha256()
    with p.open('rb') as f:
        for block in iter(lambda: f.read(1048576), b''): h.update(block)
    return h.hexdigest()
def encoded(x): return (json.dumps(x, ensure_ascii=False, indent=2)+'\n').encode('utf-8')
def require(v, msg):
    if not v: raise RuntimeError(msg)
def valid(p): return True  # Every declared bytecode/vendor file is part of the closure.
def historical(n): return n.startswith(HISTORY_PREFIX)
def safe_name(n):
    p=PurePosixPath(n)
    require(not p.is_absolute() and '..' not in p.parts and '\\' not in n, 'Unsafe relative path: '+n)
    return n
def inventory(root):
    result={}
    for p in sorted(root.rglob('*')):
        require(not p.is_symlink(), 'Symlink forbidden in closure: '+str(p))
        if p.is_file(): result[p.relative_to(root).as_posix()]=sha(p)
    return result
def check_canonical():
    for n,h in read(W/'BASELINE.json')['canonical'].items():
        require(sha(P/'work/ui-native-r57'/n)==h, 'Canonical mismatch: '+n)

def baseline():
    pins=read(OLD/'FROZEN-PINS.json'); index=OLD/'assembly/UNIFIED-PINS.json'
    require(sha(index)==pins['unifiedPinsSha256'], 'Prior unified pins changed')
    origin=Path(pins['project']).resolve(); rows=read(index)['files']
    base={safe_name(r['path']):r['sha256'] for r in rows}
    require(len(rows)==len(base)==9298, 'Unexpected exact baseline size')
    require(inventory(origin)==base, 'Prior exact 9298-file closure changed')
    for row in rows: require((origin/row['path']).stat().st_size==row['bytes'], 'Prior file size mismatch: '+row['path'])
    copy=read(W/'BASE-COPY.json')
    require(copy['sourcePinsSha256']==sha(OLD/'FROZEN-PINS.json') and copy['sourceIndexSha256']==sha(index), 'Base copy provenance mismatch')
    require(Path(copy['targetProject']).resolve()==A.resolve() and Path(copy['sourceProject']).resolve()==origin, 'Base copy path mismatch')
    # Independently re-read the older 6298 declared source bytes, rather than trust a receipt.
    older=read(OLD/'assembly/BASE-COPY.complete.json')
    require(len(older['files'])==6298, 'Unexpected old source count')
    older_root=Path(older['source'])
    for n,h in older['files'].items(): require(sha(older_root/safe_name(n))==h, 'Older source changed: '+n)
    return base,origin

def closure_check(m):
    tree=m['runtimeTree']; exe=m['executable']
    require(len(tree)==291 and m['executableSha256']==EXE_SHA, 'Unexpected fixed executable closure')
    root=(A/exe).parent
    files={p.relative_to(A).as_posix() for p in root.rglob('*') if p.is_file()}
    require(set(tree)==files, 'Executable runtimeTree file-set mismatch')
    require(sha(A/exe)==EXE_SHA, 'Executable digest mismatch')
    for n,h in tree.items(): require(sha(A/safe_name(n))==h, 'Executable runtimeTree digest mismatch: '+n)

def stale_scan(hashes, base, virtual):
    old={}
    for n,h in hashes.items():
        if base.get(n) and base[n]!=h: old.setdefault(base[n].lower(),[]).append({'target':n,'newSha256':h})
    hits=[]; scanned=0; exemptions=[]
    for n in hashes:
        if not n.endswith('.py'): continue
        if historical(n):
            require(hashes[n]==base.get(n), 'Historical release edited: '+n)
            exemptions.append(n); continue
        raw=virtual[n] if n in virtual else (A/n).read_bytes()
        text=raw.decode('utf-8-sig',errors='replace'); scanned+=1
        for m in RX.finditer(text):
            if m.group().lower() in old: hits.append({'consumer':n,'line':text.count('\n',0,m.start())+1,'oldSha256':m.group(),'targets':old[m.group().lower()]})
    return hits,scanned,exemptions

def plan():
    check_canonical(); base,origin=baseline(); current=inventory(A)
    require(set(base)<=set(current), 'Baseline files were deleted')
    require(all(current[n]==h for n,h in base.items() if historical(n)), 'Immutable historical release changed')
    virtual={}; mirrors=[]
    srcroot=A/'work/ui-runtime-r55/src'
    for p in sorted(srcroot.rglob('*.py')):
        rel=p.relative_to(srcroot)
        if 'tests' in rel.parts: continue
        sr=p.relative_to(A).as_posix(); raw=p.read_bytes(); h=digest(raw)
        if base.get(sr)==h: continue
        targets=[A/'work/app/src'/rel]
        if (A/'work/shared-backend-integration/vendor-src'/rel.parts[0]).is_dir(): targets.append(A/'work/shared-backend-integration/vendor-src'/rel)
        for target in targets:
            n=target.relative_to(A).as_posix(); before=current.get(n)
            require(before in {base.get(n),h}, 'Unexpected mirror target change: '+n)
            virtual[n]=raw; mirrors.append({'source':sr,'target':n,'beforeSha256':before,'afterSha256':h})
    hashes={**current,**{n:digest(raw) for n,raw in virtual.items()}}
    source=read(A/SOURCE); require(isinstance(source.get('files'),dict), 'Unsupported vendor provenance')
    vendor='work/shared-backend-integration/vendor-src/'
    for n,h in sorted(hashes.items()):
        if n.startswith(vendor) and n.endswith('.py'):
            relative=n[len(vendor):]; row=source['files'].get(relative)
            if row is None: source['files'][relative]={'source_sha256':None,'candidate_sha256':h}
            else:
                require(isinstance(row,dict), 'Unsupported vendor row: '+relative)
                row['candidate_sha256']=h
    proposed=encoded(source)
    # Preserve original serialization when the provenance content is unchanged.
    if source!=read(origin/SOURCE): virtual[SOURCE]=proposed; hashes[SOURCE]=digest(proposed)
    materials=[]
    for n in MATERIALS:
        original=read(origin/n); closure_check(original)
        require(current.get(n)==base[n], 'Material changed before preparation: '+n)
        require(all(k in hashes for k in original['sources']), 'Original material source missing: '+n)
        sources={k:hashes[k] for k in original['sources']}
        for k,h in sorted(hashes.items()):
            if k.endswith('.py') and not historical(k) and 'tests' not in Path(k).parts and base.get(k)!=h: sources[k]=h
        original['sources']=sources
        virtual[n]=encoded(original); hashes[n]=digest(virtual[n])
        materials.append({'path':n,'fileSha256':hashes[n],'registrationDigest':digest(json.dumps(original,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode()),'sources':len(sources)})
    changed={n:h for n,h in hashes.items() if base.get(n)!=h}
    hits,scanned,exemptions=stale_scan(hashes,base,virtual)
    require(not hits, 'Stale 64-hex source fingerprints: '+json.dumps(hits,ensure_ascii=False))
    for n in changed:
        if n.endswith('.py'): ast.parse(virtual[n] if n in virtual else (A/n).read_bytes(),filename=n)
    return {'base':base,'origin':origin,'current':current,'virtual':virtual,'hashes':hashes,'changed':changed,'mirrors':mirrors,'materials':materials,'scanned':scanned,'exemptions':exemptions}

def classify(row,n):
    require(not historical(n), 'Historical release may not be changed: '+n)
    if n.startswith('work/ui-native-r57/') and Path(n).name!='freeze_ui.py': row['publishedRelativePath']=n.split('work/ui-native-r57/',1)[1]
    elif n.startswith('work/ui-approved-implementation/ui-preview/'): row['publishedRelativePath']='web/'+n.split('ui-preview/',1)[1]
    elif n.startswith('work/shared-backend-integration/'): row['publishedRelativePath']='resources/platform-runtime/'+n.split('shared-backend-integration/',1)[1]
    elif n.startswith('work/ui-runtime-r55/src/'): row['backendDependencyRelativePath']=n.split('ui-runtime-r55/src/',1)[1]
    elif n.startswith('work/app/src/'): row['mirrorOf']='work/ui-runtime-r55/src/'+n.split('work/app/src/',1)[1]
    elif n.startswith('work/reply-complete-worker/'): row['externalRuntimeMaterial']=True
    elif n!='work/ui-native-r57/freeze_ui.py': raise RuntimeError('Unclassified change: '+n)
    return row
def save_new(path,raw):
    require(path.resolve().is_relative_to(W.resolve()), 'Write escapes isolated work area')
    path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('xb') as f: f.write(raw)

def main():
    require(sys.argv[1:] in (['--dry-run'],['--prepare-inactive-only']), 'Use --dry-run or --prepare-inactive-only')
    result=plan()
    for n in result['changed']: classify({},n)
    print(json.dumps({'mode':sys.argv[1],'baseFiles':len(result['base']),'olderSourcesRehashed':6298,'candidateFiles':len(result['hashes']),'changedFiles':len(result['changed']),'mirrorTargets':len(result['mirrors']),'pythonScanned':result['scanned'],'immutableHistoricalPythonExemptions':len(result['exemptions']),'allBytecodeIncluded':True,'materials':result['materials']},ensure_ascii=False))
    if sys.argv[1]=='--dry-run': return
    output=C/'final-sources'; changesfile=W/'assembly/CHANGES.final.json'; mapfile=W/'assembly/generated/FINAL-SOURCE-MAP.json'; digestfile=C/'FINAL-MATERIAL-DIGESTS.json'
    require(not any(p.exists() for p in (output,changesfile,mapfile,digestfile,W/'FROZEN-PINS.json')), 'Prepared output already exists; do not overwrite')
    require(inventory(A)==result['current'], 'Candidate changed during preparation')
    for n,raw in result['virtual'].items():
        p=A/safe_name(n); before=result['current'].get(n)
        require((sha(p) if p.is_file() else None)==before, 'Concurrent target change: '+n)
        p.parent.mkdir(parents=True,exist_ok=True); p.write_bytes(raw)
        require(sha(p)==digest(raw), 'Target verification failed: '+n)
    require(inventory(A)==result['hashes'], 'Candidate changed while preparing')
    rows={}; mapping={}
    for n,h in sorted(result['changed'].items()):
        src=A/n; candidate=output/n
        require(sha(src)==h, 'Candidate changed during snapshot: '+n)
        save_new(candidate,src.read_bytes()); require(sha(candidate)==h, 'Snapshot mismatch: '+n)
        row={'projectRelativePath':n,'sourcePath':str(result['origin']/n),'candidatePath':str(candidate),'candidateSha256':h,'sourceSha256':result['base'].get(n),'before':result['base'].get(n),'after':h,'publishedRelativePath':None,'owner':'needs-based-reply'}
        rows[n]=classify(row,n); mapping[n]={'candidatePath':str(candidate),'sha256':h}
    save_new(mapfile,encoded({'files':mapping}))
    save_new(changesfile,encoded({'files':rows,'baselineFiles':len(result['base']),'sourceFiles':len(result['hashes']),'productionDataAccess':False}))
    save_new(digestfile,encoded({'materials':result['materials'],'executableSha256':EXE_SHA,'runtimeTreeCount':291,'mirrors':result['mirrors'],'immutableHistoricalPythonExemptions':result['exemptions'],'allBytecodeIncluded':True}))
    check_canonical()

if __name__=='__main__': main()
