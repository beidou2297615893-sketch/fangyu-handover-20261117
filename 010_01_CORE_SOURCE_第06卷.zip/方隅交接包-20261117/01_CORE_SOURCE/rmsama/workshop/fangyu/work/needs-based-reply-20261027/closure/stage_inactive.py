"""Stage only an already prepared isolated source closure. No promotion or UI launch."""
from pathlib import Path
import ast,json,subprocess,sys
sys.dont_write_bytecode=True
from finalize_sources import A,C,W,P,MATERIALS,SOURCE,EXE_SHA,baseline,check_canonical,closure_check,digest,encoded,inventory,read,require,sha,save_new,stale_scan,historical

CHANGE=W/'assembly/CHANGES.final.json'
MAP=W/'assembly/generated/FINAL-SOURCE-MAP.json'
VENV=P/'work/desktop-python'
PYTHON=VENV/'Scripts/python.exe'

def verify_prepared():
    check_canonical(); base,origin=baseline(); changes=read(CHANGE)
    mapping=read(MAP)['files']; rows=changes['files']
    require(changes['baselineFiles']==len(base), 'Baseline count changed')
    require(set(rows)==set(mapping), 'Changes and independent source map differ')
    expected=dict(base)
    for n,row in rows.items():
        require(not historical(n), 'Immutable historical release changed: '+n)
        require(row['projectRelativePath']==n and row['before']==base.get(n) and row['sourceSha256']==base.get(n), 'Incorrect change baseline: '+n)
        snapshot=(C/'final-sources'/n).resolve()
        require(snapshot.is_relative_to((C/'final-sources').resolve()), 'Snapshot escapes final-sources')
        require(Path(row['candidatePath']).resolve()==snapshot and Path(mapping[n]['candidatePath']).resolve()==snapshot, 'Snapshot path differs: '+n)
        require(snapshot.is_file() and sha(snapshot)==row['after']==row['candidateSha256']==mapping[n]['sha256'], 'Snapshot digest mismatch: '+n)
        expected[n]=row['after']
        if n.endswith('.py'): ast.parse(snapshot.read_bytes(),filename=n)
    require(len(expected)==changes['sourceFiles'], 'Source count mismatch')
    actual=inventory(A)
    require(actual==expected, 'Assembly source set or digest differs from baseline plus declared changes')
    for n,row in rows.items():
        if row.get('mirrorOf'): require(actual.get(row['mirrorOf'])==row['after'], 'Mirror divergence: '+n)
    for n in MATERIALS:
        mat=read(A/n); closure_check(mat)
        require(set(read(origin/n)['sources'])<=set(mat['sources']), 'Original material sources dropped: '+n)
        for source,h in mat['sources'].items(): require(actual.get(source)==h, 'Material source mismatch: '+source)
        for source,h in actual.items():
            if source.endswith('.py') and not historical(source) and 'tests' not in Path(source).parts and base.get(source)!=h:
                require(mat['sources'].get(source)==h, 'Changed Python missing from materials: '+source)
    provenance=read(A/SOURCE)['files']; prefix='work/shared-backend-integration/vendor-src/'
    for n,h in actual.items():
        if n.startswith(prefix) and n.endswith('.py'):
            require(provenance.get(n[len(prefix):],{}).get('candidate_sha256')==h, 'Vendor provenance mismatch: '+n)
    hits,scanned,exemptions=stale_scan(actual,base,{})
    require(not hits, 'Stale source digest consumers: '+json.dumps(hits,ensure_ascii=False))
    return expected,rows

def verify_release_inventory(release):
    manifest=read(release/'RELEASE.json')
    rows=manifest['files']; declared={r['path']:r for r in rows}
    actual={p.relative_to(release).as_posix():p for p in release.rglob('*') if p.is_file()}
    require(len(rows)==len(declared) and set(actual)==set(declared)|{'RELEASE.json'}, 'Release manifest full file-set differs')
    for n,row in declared.items():
        require(sha(actual[n]).lower()==row['sha256'].lower() and actual[n].stat().st_size==row['size'], 'Release file differs: '+n)
    return {'declaredFiles':len(declared),'actualFiles':len(actual),'bytecodeFiles':sum(n.endswith(('.pyc','.pyo')) for n in actual)}

def main():
    require(sys.argv[1:] in (['--dry-run'],['--stage-prepared-candidate']), 'Use --dry-run or --stage-prepared-candidate')
    if sys.argv[1]=='--dry-run' and (not CHANGE.exists() or not MAP.exists()):
        check_canonical(); b,_=baseline()
        print(json.dumps({'mode':'--dry-run','status':'AWAITING_PREPARED_SOURCES','baselineFiles':len(b),'olderSourcesRehashed':6298,'baselineBytecode':sum(n.endswith(('.pyc','.pyo')) for n in b),'pythonExists':PYTHON.is_file()}))
        return
    expected,rows=verify_prepared()
    require(PYTHON.is_file(), 'Fixed desktop-python interpreter missing')
    output=[W/'assembly/STAGED.json',W/'assembly/UNIFIED-PINS.json',W/'FROZEN-PINS.json']
    require(not any(p.exists() for p in output), 'Staging output already exists; do not overwrite')
    if sys.argv[1]=='--dry-run':
        print(json.dumps({'mode':'--dry-run','status':'READY','sourceFiles':len(expected),'changedFiles':len(rows)})); return
    native=A/'work/ui-native-r57'
    code="import importlib.util,sys;from pathlib import Path;sys.dont_write_bytecode=True;native=Path(sys.argv[1]);sys.path.insert(0,str(native));spec=importlib.util.spec_from_file_location('candidate_freezer',native/'freeze_ui.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);m.VENV=Path(sys.argv[2]);raise SystemExit(m.main(['--stage']))"
    try:
        run=subprocess.run([str(PYTHON),'-X','utf8','-B','-c',code,str(native),str(VENV)],capture_output=True,text=True,encoding='utf-8',errors='strict',timeout=300,check=True)
        stage=json.loads(run.stdout); require(stage.get('status')=='STAGED', 'Freezer did not report STAGED')
        release=Path(stage['release']).resolve(); launcher=Path(stage['launcher']).resolve()
        require(release.parent==(native/'releases').resolve() and launcher.parent==native.resolve(), 'Unexpected stage output path')
        require(sha(release/'RELEASE.json').upper()==stage['manifest_sha256'].upper(), 'Release manifest digest mismatch')
        require(sha(launcher).upper()==stage['launcher_sha256'].upper(), 'Candidate launcher digest mismatch')
        release_inventory=verify_release_inventory(release)
        actual=inventory(A)
        for n,h in expected.items(): require(actual.get(n)==h, 'Source changed during staging: '+n)
        permitted=(f'work/ui-native-r57/releases/{release.name}/', f'work/ui-native-r57/candidates/{stage["release_id"]}.json', f'work/ui-native-r57/{launcher.name}')
        extras=set(actual)-set(expected)
        require(all(n.startswith(permitted[0]) or n in permitted[1:] for n in extras), 'Unexpected stage additions: '+str(extras))
        require(release.name==stage['release_id'], 'Release ID mismatch')
        check_canonical()
        save_new(output[0],encoded(stage))
        files=[{'path':n,'bytes':(A/n).stat().st_size,'sha256':h} for n,h in sorted(actual.items())]
        unified={'schema':'fangyu-inactive-customer-closure-v1','root':'project','files':files,'release':stage,'releaseInventory':release_inventory,'baselineBytecodePreserved':sum(n.endswith(('.pyc','.pyo')) for n in expected),'production_data_access':False,'promoted':False}
        save_new(output[1],encoded(unified))
        pins={'status':'STAGED_NOT_INSTALLED','project':str(A),'release':str(release),'releaseId':stage['release_id'],'manifestSha256':sha(release/'RELEASE.json'),'stagedSha256':sha(output[0]),'launcherPath':str(launcher),'launcherSha256':sha(launcher),'unifiedPinsSha256':sha(output[1]),'changesSha256':sha(CHANGE),'installed':False,'automaticSendingEnabled':False,'productionWrites':0}
        save_new(output[2],encoded(pins))
        print(json.dumps({'status':pins['status'],'changedFiles':len(rows),'releaseId':pins['releaseId'],'fullClosureFiles':len(files),'releaseInventory':release_inventory}))
    finally: check_canonical()

if __name__=='__main__': main()
