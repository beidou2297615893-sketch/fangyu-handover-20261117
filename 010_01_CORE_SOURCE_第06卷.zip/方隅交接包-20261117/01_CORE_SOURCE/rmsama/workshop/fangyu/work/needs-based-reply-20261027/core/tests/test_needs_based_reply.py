"""Local payload/guard tests; no model, live customer, or platform calls."""
import copy
import json
from pathlib import Path
import sys
import unittest

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT.parents[1] / 'region-followup-20261027/assembly/project/work/ui-native-r57'
sys.path[:0] = [str(ROOT / 'overlay/work/ui-native-r57'), str(BASE)]
from resident_tone_preset import PRESET, preset_snapshot
from reply_ai_provider import build_prompt, provider_prompt, validate_output, BASE_INSTRUCTIONS
from reply_handoff import strategy


FACTS = '我是小北，真实住户，住在方隅。本人介绍可优惠，推荐方隅有积分。方隅有电梯。'


def snapshot(facts=FACTS, enabled=True, level='high', **qualification):
    return {'scope': {'accountId': 'account-a'},
            'firstReplyOffer': {'enabled': enabled, 'mode': 'request_phone', 'shareContactApproved': False},
            'qualification': {'aggregateState': 'current', 'interestStatus': 'graded',
                              'interestLevel': level, 'demandState': 'active', 'regionMatch': 'match',
                              'eligibility': 'no_known_exclusion', 'role': 'demand', **qualification},
            'roleProfile': {'configured': True, 'confirmed': True, 'roleFacts': facts},
            'privateReceiverVerified': False, 'selectedContact': {}, 'privatePhoneHashes': []}


def tone(s=None, selected=True):
    s = snapshot() if s is None else s
    return {'version': 1, 'effectiveStyle': {'resolvedTone': 'friendly'},
            'savedTone': {'stylePresetId': PRESET['id']} if selected else {},
            'firstReplyOfferSnapshot': s}


def output(reply):
    return {'relationship': '客户本人', 'need': '低楼层', 'fit': '待核对',
            'reason': '客户原话', 'reply': reply, 'unknown': [], 'shouldReply': bool(reply)}


class NeedsBasedReplyTests(unittest.TestCase):
    def test_v2_preserves_six_original_examples_and_separates_new_user_sources(self):
        p = preset_snapshot({'stylePresetId': 'resident_seeding_v1'}, {'accountId': 'a'})
        self.assertEqual(p['version'], 2)
        self.assertEqual(p['status'], 'calibrating')
        self.assertEqual(len(p['references']), 6)
        self.assertEqual(p['references'][-1]['text'], '宝宝你要租吗？我是租户，有积分的啊')
        self.assertEqual(len(p['calibrationReferences']), 5)
        self.assertTrue(all(x['origin'] == 'user_spoken' and not x['approvedReply']
                            and x['accountScopedFacts'] for x in p['calibrationReferences']))
        p['references'][0]['text'] = 'changed'
        self.assertNotEqual(PRESET['references'][0]['text'], 'changed')

    def test_confirmed_account_and_all_graded_levels_expose_personal_discount_capability(self):
        for level in ['high', 'medium', 'low']:
            with self.subTest(level=level):
                p = strategy(snapshot(level=level))
                self.assertEqual(p['action'], 'offer_help')
                self.assertTrue(p['capabilities']['canIntroduceDiscount'])
                self.assertTrue(p['capabilities']['canDiscloseResident'])
                self.assertTrue(p['capabilities']['canStateElevator'])
                self.assertIn('我介绍可优惠', p['preview'])

    def test_off_keeps_facts_but_does_not_allow_personal_handoff(self):
        p = strategy(snapshot(enabled=False))
        self.assertEqual(p['action'], 'off')
        self.assertEqual(p['preview'], '')
        self.assertFalse(p['capabilities']['canIntroduceDiscount'])
        self.assertFalse(p['capabilities']['canOfferHelp'])
        self.assertTrue(p['capabilities']['qualificationEligible'])

    def test_other_account_does_not_inherit_xiaobei_or_discount_or_elevator(self):
        p = strategy(snapshot(facts='我是销售员工，不是住户，没有推荐积分，不能介绍优惠，电梯情况未知。'))
        self.assertTrue(p['capabilities']['canOfferHelp'])
        for key in ['canIntroduceDiscount', 'canDiscloseResident', 'canDisclosePoints', 'canStateElevator']:
            self.assertFalse(p['capabilities'][key], key)
        self.assertNotIn('小北', p['preview'])

    def test_unconfirmed_rolefacts_do_not_enable_personal_claims(self):
        s = snapshot(); s['roleProfile']['confirmed'] = False
        p = strategy(s)
        self.assertFalse(p['capabilities']['canIntroduceDiscount'])
        self.assertFalse(p['capabilities']['canDiscloseResident'])
        self.assertTrue(p['capabilities']['canOfferHelp'])

    def test_natural_user_facts_support_resident_discount_but_not_negations(self):
        p = strategy(snapshot(facts='我住方隅，我给你介绍还能便宜'))
        self.assertTrue(p['capabilities']['canDiscloseResident'])
        self.assertTrue(p['capabilities']['canIntroduceDiscount'])
        self.assertTrue(validate_output(output('宝宝我是方隅住户，我给你介绍还能便宜。'),
            {'tone_snapshot': tone(snapshot(facts='我住方隅，我给你介绍还能便宜'))}))
        for facts in ['我不是住户，我不住方隅，我介绍没有优惠', '我不住方隅，本人介绍无优惠',
                      '我没有住方隅，推荐优惠未确认']:
            with self.subTest(facts=facts):
                p = strategy(snapshot(facts=facts))
                self.assertFalse(p['capabilities']['canDiscloseResident'])
                self.assertFalse(p['capabilities']['canIntroduceDiscount'])

    def test_third_party_wishes_and_past_residence_never_become_current_personal_facts(self):
        for facts in ['我朋友住方隅，他介绍可优惠', '我想住方隅，别人能介绍优惠',
                      '我以前住过方隅，我不再住，别人介绍便宜', '我不再住方隅，没有优惠']:
            with self.subTest(facts=facts):
                p = strategy(snapshot(facts=facts))
                self.assertFalse(p['capabilities']['canDiscloseResident'])
                self.assertFalse(p['capabilities']['canIntroduceDiscount'])
        p = strategy(snapshot(facts='我住方隅，我介绍可便宜'))
        self.assertTrue(p['capabilities']['canIntroduceDiscount'])
        self.assertFalse(strategy(snapshot(facts='我想住方隅，我给你介绍能便宜'))['capabilities']['canDiscloseResident'])

    def test_omitted_subject_and_brand_do_not_bypass_fact_or_offer_guards(self):
        for s in [snapshot(facts='', enabled=False), snapshot(facts=''), snapshot(facts='', regionMatch='other')]:
            for reply in ['宝宝介绍可优惠', '宝宝报小北名字有优惠', '宝宝这里带电梯的']:
                with self.subTest(reply=reply, s=s), self.assertRaises(ValueError):
                    validate_output(output(reply), {'tone_snapshot': tone(s)})
        for s in [snapshot(enabled=False), snapshot(regionMatch='other')]:
            with self.subTest(s=s), self.assertRaises(ValueError):
                validate_output(output('宝宝介绍可优惠'), {'tone_snapshot': tone(s)})

    def test_region_time_role_and_unrelated_guards_keep_discount_disabled(self):
        cases = [({'regionMatch': 'other'}, 'blocked'), ({'demandState': 'ended'}, 'blocked'),
                 ({'role': 'supply'}, 'blocked'), ({'interestStatus': 'unrelated'}, 'blocked'),
                 ({'regionMatch': 'unknown'}, 'clarify'), ({'aggregateState': 'stale'}, 'clarify')]
        for q, action in cases:
            with self.subTest(q=q):
                p = strategy(snapshot(**q))
                self.assertEqual(p['action'], action)
                self.assertFalse(p['capabilities']['canOfferHelp'])
                self.assertFalse(p['capabilities']['canIntroduceDiscount'])

    def test_selected_preset_rejects_unsupported_claims_even_when_offer_off(self):
        s = snapshot(facts='', enabled=False)
        for text in ['宝宝我住方隅', '宝宝我就住这儿', '宝宝我是这里住户', '宝宝推荐有积分', '宝宝方隅带电梯的']:
            with self.subTest(text=text), self.assertRaises(ValueError):
                validate_output(output(text), {'tone_snapshot': tone(s)})

    def test_off_rejects_new_personal_sales_hook_but_allows_need_question(self):
        s = snapshot(enabled=False)
        for text in ['宝宝我介绍能便宜', '宝宝我帮你约看', '宝宝我帮你联系销售']:
            with self.subTest(text=text), self.assertRaises(ValueError):
                validate_output(output(text), {'tone_snapshot': tone(s)})
        self.assertTrue(validate_output(output('宝宝你是想找低楼层吗？'), {'tone_snapshot': tone(s)}))

    def test_enabled_confirmed_facts_allow_need_hook_without_exact_quote_or_inventory(self):
        s = snapshot()
        self.assertTrue(validate_output(output('宝宝想找低楼层呀，方隅有电梯，我帮你问问，介绍可优惠。'),
                                        {'tone_snapshot': tone(s)}))

    def test_missing_discount_fact_still_allows_help_but_not_discount_claim(self):
        s = snapshot(facts='我是销售员工')
        self.assertTrue(validate_output(output('宝宝宠物能不能带我帮你问问。'), {'tone_snapshot': tone(s)}))
        with self.assertRaises(ValueError):
            validate_output(output('宝宝带宠物我帮你问，我介绍能便宜。'), {'tone_snapshot': tone(s)})

    def test_unselected_enabled_handoff_also_rejects_unsupported_personal_discount(self):
        with self.assertRaises(ValueError):
            validate_output(output('宝宝我介绍能便宜'), {'tone_snapshot': tone(snapshot(facts='我是销售员工'), selected=False)})

    def test_default_referral_name_never_establishes_xiaobei_identity(self):
        s = snapshot(facts='我是销售员工'); s['referralName'] = '小北'
        for reply in ['宝宝我就是小北', '宝宝找小北介绍能便宜']:
            with self.subTest(reply=reply), self.assertRaises(ValueError):
                validate_output(output(reply), {'tone_snapshot': tone(s)})

    def test_unconfirmed_personal_lived_experience_is_not_invented(self):
        s = snapshot(facts='', enabled=False)
        for reply in ['宝宝我在方隅住了很久', '宝宝我也是这里的租户']:
            with self.subTest(reply=reply), self.assertRaises(ValueError):
                validate_output(output(reply), {'tone_snapshot': tone(s)})

    def test_questions_do_not_assert_unknown_elevator_or_pet_policy(self):
        s = snapshot(facts='我是销售员工')
        self.assertTrue(validate_output(output('宝宝你要电梯房吗？宠物政策我帮你问。'), {'tone_snapshot': tone(s)}))
        with self.assertRaises(ValueError):
            validate_output(output('宝宝方隅肯定能养狗，我帮你约。'), {'tone_snapshot': tone(s)})

    def test_discount_fact_does_not_authorize_made_up_exact_discount(self):
        with self.assertRaises(ValueError):
            validate_output(output('宝宝我介绍保证优惠500元。'), {'tone_snapshot': tone(snapshot())})

    def test_target_and_other_speaker_material_remain_separate_at_model_boundary(self):
        packet = {'target': {'authorId': 'customer-a', 'text': '想要低楼层'},
                  'root': {'authorId': 'other', 'text': '我养两只猫'},
                  'replyTo': {'known': False}, 'post': {'title': '古北租房'}}
        before = copy.deepcopy(packet)
        prompt = build_prompt(packet, tone(), [])
        material = json.loads(prompt.split('材料：', 1)[1])
        self.assertEqual(material['context'], before)
        self.assertEqual(packet, before)
        self.assertIn('同一客户', prompt)
        self.assertIn('低楼层', prompt)
        self.assertNotIn('也可以看看我住的方隅', prompt)
        self.assertIn('calibrationReferences', provider_prompt())
        self.assertIn('未选择表达预设', provider_prompt())

    def test_unselected_legacy_style_and_old_unguarded_result_contract_remain_compatible(self):
        legacy = {'version': 1, 'effectiveStyle': {'resolvedTone': 'friendly'}}
        prompt = build_prompt({}, legacy, [])
        self.assertIn(BASE_INSTRUCTIONS, prompt)
        self.assertNotIn('calibrationReferences', prompt)
        self.assertTrue(validate_output(output('宝宝我住方隅'), {'tone_snapshot': legacy}))


if __name__ == '__main__': unittest.main()
