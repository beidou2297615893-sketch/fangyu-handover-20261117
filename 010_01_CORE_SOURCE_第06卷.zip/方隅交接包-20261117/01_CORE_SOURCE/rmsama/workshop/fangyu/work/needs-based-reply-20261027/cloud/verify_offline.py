"""Verify the official offline package and prior cloud behavior against candidate."""
from pathlib import Path,PurePosixPath
from datetime import datetime,timezone
import hashlib,json,shutil,subprocess,sys,zipfile
sys.dont_write_bytecode=True
D=Path(__file__).resolve().parent;W=D.parent;P=W.parents[1];OLD=P/'work/region-followup-20261027/cloud'
from verify_candidate import local_material
read=lambda p:json.loads(p.read_text('utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 assert sys.argv[1:]==['--verify-only']
 expected=local_material();composition=read(D/'COMPOSITION.json')
 package=W/'review/corrected-package-proof/fangyu-workspace.zip';rows={}
 with zipfile.ZipFile(package) as z:
  for info in z.infolist():
   if info.is_dir():continue
   n=info.filename;path=PurePosixPath(n);assert not path.is_absolute() and '..' not in path.parts and n not in rows
   data=z.read(info);rows[n]={'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)}
 assert rows==expected and len(rows)==5620
 folder=D/'tests';assert not folder.exists();folder.mkdir()
 names=['followup_consume.test.cjs','followup_policy_race.test.cjs','followup_fixture.cjs','reviewed_reply_release.test.cjs']
 copied={}
 for name in names:
  source=OLD/'tests'/name;target=folder/name;shutil.copyfile(source,target);assert sha(source)==sha(target);copied[name]=sha(target)
 loader=(OLD/'tests/legacy_service_loader.cjs').read_text('utf-8')
 before=json.dumps(str(OLD/'candidate'));after=json.dumps(str(D/'candidate'))
 assert loader.count(before)==1;loader=loader.replace(before,after);(folder/'legacy_service_loader.cjs').write_text(loader,'utf-8')
 material=composition['registrationMaterialDigest'];previous=composition['priorMaterialPreserved']
 js="const a=require("+json.dumps(str(D/'candidate/reviewed_reply_release.cjs'))+");const d="+json.dumps(previous+[material])+";for(const x of d)for(const v of [a.VERSION,a.NATIVE_VERSION])if(!a.materialAllowed(x,v))throw Error('missing admitted digest');if(a.materialAllowed('f'.repeat(64),a.VERSION))throw Error('unknown admitted');console.log('PASS all current and previous materials, both versions');"
 cmds=[('followup-consume',['--test',str(folder/'followup_consume.test.cjs')]),('policy-race',['--test',str(folder/'followup_policy_race.test.cjs')]),('lease-compat',['--test',str(folder/'reviewed_reply_release.test.cjs')]),('legacy-service',[str(folder/'legacy_service_loader.cjs')]),('material-allowlist',['-e',js])]
 checks=[]
 for name,args in cmds:
  r=subprocess.run(['node',*args],capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=90)
  log=folder/(name+'.log');log.write_text(r.stdout+'\n'+r.stderr,'utf-8');checks.append({'name':name,'exitCode':r.returncode,'logSha256':sha(log)})
  if r.returncode:print((r.stdout+r.stderr)[-2000:])
 assert all(x['exitCode']==0 for x in checks),checks
 result={'status':'PASS','atUtc':datetime.now(timezone.utc).isoformat(),'candidateTree':composition['afterTree'],'packageSha256':sha(package),
  'officialPacker':True,'files':len(rows),'sourceTestHashes':copied,'checks':checks,'cloudCalls':0,'platformCalls':0,'realMessagesSent':0}
 (D/'OFFLINE-VERIFICATION.json').write_text(json.dumps(result,indent=2),'utf-8');print(json.dumps(result))
if __name__=='__main__':main()
