"""Independent post-install evidence audit; no external calls or database access."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,importlib.util,json,sys,zipfile
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parents[1];P=W.parents[1];D=W/'cloud';N=P/'work/ui-native-r57'
read=lambda p:json.loads(p.read_text('utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    assert sha(W/'FROZEN-PINS.json')=='5a124a3e81e25800b805055f7b3601fde11d3d20f3bddbc0557ea0747711b57e'
    assert sha(W/'independent/FINAL-SOURCE-REVIEW.json')=='bd1150c3266f5f524c408b0fb7dc097d4b463a937540f628ed242883e063e738'
    assert sha(W/'review/NEXT-LAUNCH-REVIEW.json')=='7dabb26054db52878916082237a045309511e13e69bf33ac51f03e4f7868a031'
    assert sha(D/'DEPLOY-REVIEW.json')=='57411683cc0b426b973112483cab365f3fb6148f8e779f1d4f71b59c7eb3b919'
    sys.path.insert(0,str(D));import execute_code_only as cloud
    approval=read(D/'DEPLOY-REVIEW.json');assert approval['pins']==cloud.pins()
    result=read(D/'update-once/RESULT.json');assert result['status']=='VERIFIED_CODE_ONLY_UPDATE'
    assert result['updateCommands']==1 and result['cliExitCode']==0 and result['cliSuccessMessageObserved']
    assert result['protectedConfigurationUnchanged'] and result['installDependency']=='FALSE'
    assert result['approvalSha256']==sha(D/'DEPLOY-REVIEW.json')
    assert result['databaseAccess'] is False and result['realMessagesSent']==0
    assert result['invocationConfigSha256']==sha(D/'update-once/cloudbaserc.json')
    config=read(D/'update-once/cloudbaserc.json')
    assert config['functionRoot']=='.' and config['envId']==cloud.base.ENV
    assert len(config['functions'])==1 and config['functions'][0]['name']==cloud.base.FN
    assert config['functions'][0]['installDependency'] is False and config['functions'][0]['ignore']==[]
    before=cloud.archive_files(D/'readback-precommit');after=cloud.archive_files(D/'readback-postcommit')
    assert before==read(D/'BASE.json')['sourceIndex'] and after==cloud.local_material()
    assert cloud.verify(D/'readback-postcommit')==result['readback']
    with zipfile.ZipFile(D/'readback-precommit/live-function-code.zip') as z:old=z.read('reviewed_reply_release.cjs').decode()
    with zipfile.ZipFile(D/'readback-postcommit/live-function-code.zip') as z:new=z.read('reviewed_reply_release.cjs').decode()
    comp=read(D/'COMPOSITION.json');material=comp['registrationMaterialDigest'];stripped=new
    for version in ['VERSION','NATIVE_VERSION']:
        addition=",Object.freeze({protocol:PROTOCOL,clientVersion:"+version+",materialSha256:'"+material+"'})"
        assert stripped.count(addition)==1;stripped=stripped.replace(addition,'')
    assert stripped==old
    for digest in comp['priorMaterialPreserved']:assert new.count(digest)==old.count(digest)==2
    tx=W/'next-launch-transaction';biz1=read(tx/'READONLY-BUSINESS-BEFORE.json');biz2=read(tx/'READONLY-BUSINESS-AFTER.json')
    assert biz1==biz2 and biz1['sourceReadOnly'] and not biz1['databaseRestored']
    pins=read(W/'FROZEN-PINS.json');install=read(W/'NEXT-LAUNCH-INSTALLATION.json');entry=read(W/'NEXT-LAUNCH-ENTRY-CHECK.json')
    assert install['status']=='NEXT_LAUNCH_INSTALLED' and entry['status']=='NEXT_LAUNCH_ENTRY_VERIFIED'
    for obj in [install,entry]:
        assert obj['releaseId']==pins['releaseId'] and obj['allBusinessDataUnchanged'] and obj['currentInstanceUnchanged']
    assert not install['nativeWindowOpened'] and not install['processesStopped'] and not install['realCollectionStarted']
    assert not install['databaseMigrated'] and not install['databaseRestored']
    assert entry['nativeWindowsOpened']==0 and not entry['processesStopped'] and entry['realPlatformRequests']==0
    assert not entry['realCollectionStarted'] and entry['originalDesktopEntryVerified']
    assert sha(N/'run_workbench.py')==install['canonicalLauncherSha256'] and sha(N/'FROZEN.json')==install['canonicalFrozenSha256']
    baseline=read(W/'BASELINE.json');frozen=read(N/'FROZEN.json');plan=read(tx/'CANONICAL-DELEGATION-PREPARED.json')
    assert frozen['release_id']==pins['releaseId'] and frozen['runtime_project_root']==pins['project']
    assert sha(Path(plan['launcher']))==plan['launcher_sha256'].lower()==install['canonicalLauncherSha256']
    assert sha(N/'state/production-workspace.json')==baseline['canonical']['state/production-workspace.json']
    for row in read(tx/'CANONICAL-DELEGATION-INSTALL.json')['targets']:
        p=Path(row['path']);assert sha(p)==row['new_sha256'].lower()
        assert row['old_sha256'].lower()==baseline['canonical'][p.name]
        assert sha(tx/'canonical-entry-before'/p.name)==row['old_sha256'].lower()
    er=read(W/'review/NEXT-LAUNCH-REVIEW.json');assert sha(W/'verify_next_launch_entry.py')==er['nextLaunchVerifierSha256']
    logs={}
    for check in entry['checks']:
        assert check['exitCode']==0;name=check['option'][2:];path=W/'verification/next-launch-entry'/(name+'.log')
        payload=json.loads(path.read_text('utf-8').strip());assert payload['status']=='PASS'
        assert payload['native_windows_opened']==0 and payload['business_app_imported'] is False
        if name=='check':assert payload['release_id']==pins['releaseId'] and payload['files']==2908
        else:assert name=='self-test' and payload['checks']==225
        logs[name]=sha(path)
    assert set(logs)=={'check','self-test'}
    evidence=['FROZEN-PINS.json','independent/FINAL-SOURCE-REVIEW.json','review/NEXT-LAUNCH-REVIEW.json','cloud/DEPLOY-REVIEW.json','cloud/update-once/RESULT.json','cloud/readback-precommit/LIVE-READBACK.json','cloud/readback-precommit/LIVE-CODE-FILES.json','cloud/readback-postcommit/LIVE-READBACK.json','cloud/readback-postcommit/LIVE-CODE-FILES.json','NEXT-LAUNCH-INSTALLATION.json','NEXT-LAUNCH-ENTRY-CHECK.json','next-launch-transaction/READONLY-BUSINESS-BEFORE.json','next-launch-transaction/READONLY-BUSINESS-AFTER.json','next-launch-transaction/CANONICAL-DELEGATION-INSTALL.json']
    final=dict(status='PASS_FINAL_DELIVERY_REVIEW',atUtc=datetime.now(timezone.utc).isoformat(),blockingFindings=[],releaseId=pins['releaseId'],
        evidenceSha256={n:sha(W/n) for n in evidence},reviewScriptSha256=sha(Path(__file__)),
        cloud={'exactRemoteFilesVerified':len(after),'unchangedOriginalFiles':5619,'treeSha256':comp['afterTree'],'precommitZipSha256':sha(D/'readback-precommit/live-function-code.zip'),'postcommitZipSha256':sha(D/'readback-postcommit/live-function-code.zip'),'updateCommands':1,'allPreviousMaterialEntriesPreserved':True,'newMaterialBothVersionsPresent':True,'protectedConfigurationUnchanged':True,'protectedConfigurationEvidence':'Pinned executor asserts pre/post configuration hashes against the pinned prior configuration; successful execution receipt records the result. Reviewer made no fresh cloud call.'},
        local={'nextLaunchInstalled':True,'originalEntryCheckPassed':True,'originalEntrySelfTestChecks':225,'entryLogSha256':logs,'businessSnapshotsExactEqual':True,'recordCount':sum(biz1['counts'].values()),'workspaceBindingUnchanged':True,'currentInstanceReceiptUnchanged':True,'currentRunningRelease':install.get('currentRunningRelease')},
        scopeLimitations=['Next-launch entry installed; no current-window reload or runtime-version claim (currentRunningRelease receipt is null)','47 draft calibration remains in progress','No real platform send/receive, live model batch, or small-screen native acceptance verified','Legacy readback helper status label is superseded by this exact pre/post full ZIP comparison'],
        reviewerActions={'externalCalls':0,'productionWrites':0,'platformCalls':0,'modelCalls':0,'messagesSent':0})
    out=W/'review/FINAL-DELIVERY-REVIEW.json'
    with out.open('x',encoding='utf-8') as f:json.dump(final,f,ensure_ascii=False,indent=2);f.write('\n')
    print(json.dumps({'status':final['status'],'sha256':sha(out),'cloudFiles':len(after),'businessRecords':final['local']['recordCount']}))
if __name__=='__main__':main()
