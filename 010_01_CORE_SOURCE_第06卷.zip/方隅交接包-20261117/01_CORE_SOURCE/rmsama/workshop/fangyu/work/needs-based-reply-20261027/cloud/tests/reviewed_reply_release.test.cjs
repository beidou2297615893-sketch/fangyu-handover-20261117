'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const crypto=require('node:crypto');
const Module=require('node:module');
const ROOT=path.resolve(__dirname,'../candidate');
const LIVE="C:\\\u79ef\u6728\u8f6f\u4ef6\u5de5\u574a\\\u9879\u76ee\\\u65b9\u9685\u516c\u5bd3\u5ba2\u6237\u7248\\work\\multi-account-complete-20261027-final\\cloud\\live-before";
const MATERIAL='a'.repeat(64),VERSION='1.2.0-read.1',PROTOCOL='fangyu-reviewed-reply-v1';
const NOW=1793000000,TOKEN='synthetic-device-token',ID='synthetic_device_123456',ENV='synthetic-env';
const sha=x=>crypto.createHash('sha256').update(x).digest('hex');
const request={operation:'device_poll',environment_id:ENV,version:VERSION,customer_read_protocol:'fangyu-customer-read-v1',reviewed_reply_protocol:PROTOCOL,material_sha256:MATERIAL,accept_commands:false};
// Compile the real service and device module with only a synthetic fixed allowlist
// in memory. No production file, environment, network or database is mutated.
function compile(file,overrides={},transform=x=>x){const m=new Module(file,module);m.filename=file;m.paths=Module._nodeModulePaths(path.dirname(file));const req=m.require.bind(m);m.require=id=>Object.hasOwn(overrides,id)?overrides[id]:req(id);m._compile(transform(fs.readFileSync(file,'utf8')),file);return m.exports;}
function factory({synthetic=true,root=ROOT}={}){
 if(!synthetic)return require(path.join(root,'service.cjs')).createService;
 const filename=path.join(root,'reviewed_reply_release.cjs');
 if(!fs.existsSync(filename))return require(path.join(root,'service.cjs')).createService;
 const reviewed=compile(filename,{},s=>s.replace(/materialSha256:'[^']+'/g,"materialSha256:'"+MATERIAL+"'"));
 const devices=compile(path.join(root,'devices.cjs'),{'./reviewed_reply_release.cjs':reviewed});
 return compile(path.join(root,'service.cjs'),{'./devices.cjs':devices}).createService;
}
function fixture({mutate=()=>{},config={},create=factory()}={}){
 let state={companyId:'fangyu-apartment-client',revision:0,users:[{username:'synthetic-owner',role:'operator',disabled:false}],sessions:[],rememberedDevices:[],attempts:{},items:[],audit:[],devices:[{id:ID,name:'synthetic device',owner:'synthetic-owner',digest:sha(TOKEN),last_seen:NOW-10,version:VERSION,revoked:false}],pairings:[],commands:[],xhs_claims:[]};mutate(state);
 const store={transaction:async fn=>{const out=await fn(structuredClone(state));state=out.state;return out.result;}};
 const service=create({store,environmentId:ENV,companyId:state.companyId,clock:()=>NOW*1000,releaseApproved:false,customerReadReleaseEnabled:true,customerReadReleaseVersion:VERSION,...config});
 return {call:(body={},token=TOKEN)=>service({...request,...body},token),snapshot:()=>structuredClone(state)};
}
function denied(out){assert.equal(out.data.reviewed_reply_release?.allowed,false);assert.equal(out.data.reviewed_reply_release.lease_seconds,0);assert.equal(out.data.reviewed_reply_release.public_send_allowed,false);}
test('normal authenticated read heartbeat gets an independent exact 45 second reply lease',async()=>{
 const f=fixture(),out=await f.call();assert.equal(out.status,200);const r=out.data.reviewed_reply_release;
 assert.equal(r?.allowed,true);assert.deepEqual(Object.keys(r).sort(),['schema','allowed','company_id','device_id','owner','version','purpose','permission_revision','material_sha256','lease_seconds','public_send_allowed'].sort());
 assert.deepEqual({...r,permission_revision:'revision'},{schema:'fangyu_reviewed_reply_lease_v1',allowed:true,company_id:'fangyu-apartment-client',device_id:ID,owner:'synthetic-owner',version:VERSION,purpose:'reviewed_reply',permission_revision:'revision',material_sha256:MATERIAL,lease_seconds:45,public_send_allowed:true});
 assert.match(r.permission_revision,/^[a-f0-9]{64}$/);assert.equal(r.permission_revision,out.data.owner_permissions.permission_revision);assert.equal(out.data.owner_permissions.can_reply,true);
 assert.equal(out.data.customer_read_release.public_send_allowed,false);assert.equal(out.data.safety_hold,false);assert.equal(out.data.command,null);assert.deepEqual(f.snapshot().users,[{username:'synthetic-owner',role:'operator',disabled:false}]);
});
test('unauthenticated, revoked and disabled identities cannot receive any grant',async()=>{
 for(const opts of [{token:'wrong'},{mutate:s=>s.devices[0].revoked=true},{mutate:s=>s.users[0].disabled=true},{mutate:s=>s.devices[0].owner='missing'}]){const f=fixture(opts),out=await f.call({},opts.token||TOKEN);assert.equal(out.status,401);assert.notEqual(out.data.reviewed_reply_release?.allowed,true);}
});
test('every policy, owner, freshness, QA and request mismatch denies the independent lease',async()=>{
 const cases=[{mutate:s=>s.users[0].role='viewer'},{mutate:s=>s.users[0].can_reply=false},{mutate:s=>s.devices[0].last_seen=NOW-91},{mutate:s=>s.devices[0].last_seen=NOW+1},{mutate:s=>s.devices[0].last_seen=0},{mutate:s=>s.companyId='synthetic-other'},{config:{customerReadReleaseEnabled:false}},{config:{customerReadReleaseVersion:'wrong'}},{config:{platformQaDeviceId:ID}},{body:{version:'1.1.7-qa.1'}},{body:{version:'1.2.0-read.2'}},{body:{customer_read_protocol:'wrong'}},{body:{reviewed_reply_protocol:'wrong'}},{body:{material_sha256:'b'.repeat(64)}},{body:{material_sha256:MATERIAL.toUpperCase()}},{body:{material_sha256:'not-a-digest'}},{body:{material_sha256:undefined}}];
 for(const opts of cases)denied(await fixture(opts).call(opts.body||{}));
});
test('fixed production allowlist refuses the placeholder and accepts only a finalized approved digest',async()=>{
 const f=fixture({create:factory({synthetic:false})});
 const source=fs.readFileSync(path.join(ROOT,'reviewed_reply_release.cjs'),'utf8');
 const fixed=source.match(/materialSha256:'([^']+)'/)[1];
 denied(await f.call({material_sha256:'PENDING_REVIEWED_SENDER_MATERIAL_SHA256'}));
 if(/^[a-f0-9]{64}$/.test(fixed)){
  const out=await f.call({material_sha256:fixed});assert.equal(out.data.reviewed_reply_release.allowed,true);assert.equal(out.data.reviewed_reply_release.material_sha256,fixed);
  const native=await nativeFixture({create:factory({synthetic:false})}).call({...nativeRequest,material_sha256:fixed});assert.equal(native.data.reviewed_reply_release.allowed,true);assert.equal(native.data.reviewed_reply_release.version,'1.1.8-pilot.1');
  denied(await f.call({material_sha256:fixed==='b'.repeat(64)?'c'.repeat(64):'b'.repeat(64)}));
 }else denied(await f.call());
});
test('only reviewed protocol adds permission revision; old client response is byte equivalent to live baseline',async()=>{
 const f=fixture();
 // Absence (rather than undefined fields) mirrors an old JSON client.
 const payload={...request};delete payload.reviewed_reply_protocol;delete payload.material_sha256;
 const run=async create=>{let state=f.snapshot();const store={transaction:async fn=>{const out=await fn(state);state=out.state;return out.result;}};return create({store,environmentId:ENV,companyId:state.companyId,clock:()=>NOW*1000,customerReadReleaseEnabled:true,customerReadReleaseVersion:VERSION})(payload,TOKEN);};
 assert.deepEqual(await run(factory()),await run(factory({synthetic:false,root:LIVE})));
 const wrong=await f.call({reviewed_reply_protocol:'wrong'});assert.equal(Object.hasOwn(wrong.data.owner_permissions,'permission_revision'),false);
});
test('permission revision is stable across polls, changes on each effective permission change, and keeps prior revision',async()=>{
 const f=fixture(),a=await f.call(),b=await f.call();assert.match(a.data.owner_permissions.permission_revision,/^[a-f0-9]{64}$/);assert.equal(a.data.owner_permissions.permission_revision,b.data.owner_permissions.permission_revision);
 for(const mutate of [s=>s.users[0].can_reply=false,s=>s.users[0].role='admin',s=>s.users[0].permission_revision='existing-2',s=>{s.users[0].username='other-owner';s.devices[0].owner='other-owner';}]){const out=await fixture({mutate}).call();assert.notEqual(out.data.owner_permissions.permission_revision,a.data.owner_permissions.permission_revision);}
 const explicit=await fixture({mutate:s=>s.users[0].can_reply=true}).call();assert.equal(explicit.data.owner_permissions.permission_revision,a.data.owner_permissions.permission_revision);
});
test('reply grant neither dispatches held queued commands nor permits ordinary command_submit',async()=>{
 const mutate=s=>{s.sessions.push({digest:sha('synthetic-session'),username:s.users[0].username,expires:NOW+300});s.commands.push({id:'synthetic_command_123456',device_id:ID,requested_by:s.users[0].username,action:'reply_send',data:{reply_id:'r',account_id:'a',authorized:true},status:'queued',expires:NOW+300});};
 const f=fixture({mutate}),out=await f.call();assert.equal(out.data.reviewed_reply_release?.allowed,true);assert.equal(out.data.command,null);assert.equal(f.snapshot().commands[0].status,'cancelled');
 const result=await f.call({operation:'command_submit',device_id:ID,request_id:'synthetic_request_123456',action:'reply_send',data:{reply_id:'r',account_id:'a',authorized:true}},'synthetic-session');assert.equal(result.status,423);
});
function nativeFixture(options={}){
 const bound=require(path.join(ROOT,'admin_workbench_policy.cjs')).REVIEWED;
 return fixture({...options,config:{employeeReleaseEnabled:true,employeeReleaseVersion:'1.1.8-pilot.1',...options.config},mutate:s=>{
  s.users[0].username=bound.owner;s.users[0].role='admin';s.devices[0].id=bound.device_id;s.devices[0].owner=bound.owner;s.devices[0].version='1.1.8-pilot.1';s.devices[0].workbench_source_release='fangyu-admin-local-v1';options.mutate?.(s);
 }});
}
const nativeRequest={version:'1.1.8-pilot.1',workbench_source_release:'fangyu-admin-local-v1',customer_read_protocol:undefined};
test('actual native source admin gets independent reply lease from the original fixed admin policy',async()=>{
 const out=await nativeFixture().call(nativeRequest);assert.equal(out.status,200);assert.equal(out.data.reviewed_reply_release.allowed,true);assert.equal(out.data.reviewed_reply_release.version,'1.1.8-pilot.1');assert.equal(out.data.reviewed_reply_release.lease_seconds,45);assert.equal(out.data.employee_release.allowed,true);assert.equal(out.data.employee_release.continuous_read,true);assert.equal(out.data.safety_hold,false);assert.equal(out.data.customer_read_release.allowed,false);assert.equal(out.data.customer_read_release.public_send_allowed,false);
});
test('native source requires original bound admin device, source marker, enabled employee release and material',async()=>{
 for(const opts of [{mutate:s=>s.devices[0].id='synthetic_wrong_device_123456'},{mutate:s=>s.users[0].role='operator'},{mutate:s=>{s.users[0].username='synthetic_other';s.devices[0].owner='synthetic_other';}},{config:{employeeReleaseEnabled:false}},{config:{employeeReleaseVersion:'wrong'}},{body:{workbench_source_release:'wrong'}},{body:{workbench_source_release:undefined}},{body:{material_sha256:'c'.repeat(64)}},{mutate:s=>s.devices[0].last_seen=NOW-91},{mutate:s=>s.users[0].can_reply=false}])denied(await nativeFixture(opts).call({...nativeRequest,...opts.body}));
});
test('native source old client response is byte equivalent to fresh live code',async()=>{
 const payload={...nativeRequest};delete payload.reviewed_reply_protocol;delete payload.material_sha256;
 // fixture default adds new fields; explicitly remove at service boundary for old JSON.
 function oldFactory(create){return config=>{const service=create(config);return (body,token)=>{delete body.reviewed_reply_protocol;delete body.material_sha256;delete body.customer_read_protocol;return service(body,token);};};}
 const current=nativeFixture({create:oldFactory(factory())});
 const original=nativeFixture({create:oldFactory(factory({synthetic:false,root:LIVE}))});
 assert.deepEqual(await current.call(payload),await original.call(payload));
});
