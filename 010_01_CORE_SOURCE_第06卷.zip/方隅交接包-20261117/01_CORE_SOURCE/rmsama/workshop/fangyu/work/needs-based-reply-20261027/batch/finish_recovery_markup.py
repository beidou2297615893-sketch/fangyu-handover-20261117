from pathlib import Path
p=Path(__file__).resolve().parent/'overlay/web/pages/reply-ai.mjs'
s=p.read_text(encoding='utf-8').replace("${s.busy?'disabled':''}><img src=\"/assets/brand-${id}", "${s.busy||scopeLock?'disabled':''}><img src=\"/assets/brand-${id}")
s=s.replace("data-ai-reconcile ${lock?'disabled':''}>核对确认进度", "data-ai-reconcile ${lock?'disabled':''}>${a.draftDirty?'核对保存结果':'核对确认进度'}")
p.write_text(s,encoding='utf-8')
