"""One exact independently reviewed cloud code update, with fresh full CAS."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,re,subprocess,sys,time
import deploy as base
from verify_candidate import local_material,archive_files,verify
sys.dont_write_bytecode=True
D=Path(__file__).resolve().parent;W=D.parent;P=W.parents[1];TX=D/'update-once'
read=lambda p:json.loads(p.read_text('utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def pins():
 names=['execute_code_only.py','deploy.py','read_live_code_once.py','verify_candidate.py','verify_offline.py','prepare_candidate.py','COMPOSITION.json','BASE.json','OFFLINE-VERIFICATION.json']
 result={name:sha(D/name) for name in names}
 result['cliExecutable']=sha(Path(base.CLI))
 result['cliBundle']=sha(Path('C:/Users/rmsama/AppData/Roaming/npm/node_modules/@cloudbase/cli/dist/standalone/cli.js'))
 result['priorProtectedConfiguration']=sha(P/'work/region-followup-20261027/cloud/CONFIG-PROTECTED-AFTER.json')
 result['officialPackerScript']=sha(W/'review/pack_corrected_candidate.cjs')
 result['verifiedOfflinePackage']=sha(W/'review/corrected-package-proof/fangyu-workspace.zip')
 return result
def main():
 assert sys.argv[1:]==['--execute-reviewed']
 approval=read(D/'DEPLOY-REVIEW.json');composition=read(D/'COMPOSITION.json');local_material()
 offline=read(D/'OFFLINE-VERIFICATION.json');assert offline['status']=='PASS' and offline['candidateTree']==composition['afterTree']
 assert offline['packageSha256']==sha(W/'review/corrected-package-proof/fangyu-workspace.zip')
 assert approval['status']=='ASTRA_APPROVED_EXACT_CODE_ONLY' and approval['pins']==pins()
 assert approval['rootPinsSha256']==sha(W/'FROZEN-PINS.json') and approval['beforeTree']==composition['beforeTree'] and approval['afterTree']==composition['afterTree']
 assert not TX.exists(),'This transaction has already been attempted; no automatic retry.'
 TX.mkdir();result={'status':'PRECHECK','updateCommands':0,'databaseAccess':False,'realMessagesSent':0}
 def save():(TX/'RESULT.json').write_text(json.dumps(result,indent=2),'utf-8')
 save()
 try:
  config=base.api('GetFunction',{'FunctionName':base.FN,'Namespace':base.ENV,'ShowCode':'FALSE'})
  result['functionStatus']=config.get('Status');result['installDependency']=config.get('InstallDependency');save()
  assert config.get('Status')=='Active' and config.get('InstallDependency')=='FALSE'
  assert config.get('Type') in ('Event','HTTP') and isinstance(config.get('Runtime'),str) and isinstance(config.get('Handler'),str)
  if config['Type']=='HTTP':assert (D/'candidate/scf_bootstrap').is_file()
  protected=base.protected(config);old=read(P/'work/region-followup-20261027/cloud/CONFIG-PROTECTED-AFTER.json')
  assert protected==old,'Protected configuration changed since prior release.'
  prior=base.readback('readback-precommit');assert archive_files(prior)==read(D/'BASE.json')['sourceIndex'],'Fresh full-source CAS failed.'
  runconfig={'envId':base.ENV,'functionRoot':'.','functions':[{'name':base.FN,'type':config['Type'],'runtime':config['Runtime'],'handler':config['Handler'],'installDependency':False,'isWaitInstall':True,'ignore':[]}]}
  (TX/'cloudbaserc.json').write_text(json.dumps(runconfig,indent=2),'utf-8')
  assert approval['pins']==pins();local_material()
  result.update(status='SUBMITTING',updateCommands=1,invocationConfigSha256=sha(TX/'cloudbaserc.json'));save()
  try:
   run=subprocess.run([base.NODE,base.CLI,'fn','code','update',base.FN,'--dir',str((D/'candidate').resolve()),'--deployMode','cos','-e',base.ENV,'--json'],stdin=subprocess.DEVNULL,capture_output=True,timeout=240,cwd=TX)
   result.update(cliExitCode=run.returncode,stdoutSha256=hashlib.sha256(run.stdout).hexdigest(),stderrSha256=hashlib.sha256(run.stderr).hexdigest(),
    cliSuccessMessageObserved=bool(re.search(rb'"message"\s*:\s*"Code updated"',run.stdout)))
  except subprocess.TimeoutExpired:result.update(cliExitCode=None,timeout=True)
  save()
  after=None
  for n in range(4):
   after=base.api('GetFunction',{'FunctionName':base.FN,'Namespace':base.ENV,'ShowCode':'FALSE'})
   assert base.protected(after)==protected and after.get('InstallDependency')=='FALSE','Protected configuration changed.'
   if after.get('Status')=='Active':break
   if n<3:time.sleep(5)
  assert after and after.get('Status')=='Active'
  post=base.readback('readback-postcommit');result['readback']=verify(post)
  result.update(status='VERIFIED_CODE_ONLY_UPDATE',protectedConfigurationUnchanged=True)
 except Exception as e:
  result.update(status='FAILED_OR_UNKNOWN_STOP',errorClass=type(e).__name__,error=str(e)[:160])
 result['atUtc']=datetime.now(timezone.utc).isoformat();result['approvalSha256']=sha(D/'DEPLOY-REVIEW.json');save()
 print(json.dumps(result))
 if result['status']!='VERIFIED_CODE_ONLY_UPDATE':raise SystemExit(3)
if __name__=='__main__':main()
