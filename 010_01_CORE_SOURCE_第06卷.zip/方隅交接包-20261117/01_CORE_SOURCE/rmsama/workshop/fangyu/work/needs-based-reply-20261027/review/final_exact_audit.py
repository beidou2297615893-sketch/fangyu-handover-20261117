"""Independent offline closure audit. Writes review records only, never deploys."""
from pathlib import Path, PurePosixPath
from datetime import datetime, timezone
import hashlib, importlib.util, json, sys, zipfile
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parents[1]; P=W.parents[1]; D=W/'cloud'
read=lambda p:json.loads(p.read_text('utf-8-sig'))
def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1048576),b''):h.update(b)
    return h.hexdigest()
def load(name,p):
    spec=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
def save(p,obj):
    p.parent.mkdir(exist_ok=True,parents=True)
    with p.open('x',encoding='utf-8') as f:json.dump(obj,f,ensure_ascii=False,indent=2);f.write('\n')
def main():
    rootsha='5a124a3e81e25800b805055f7b3601fde11d3d20f3bddbc0557ea0747711b57e'
    intsha='fcd47908dcc05c75a2a678061ee754330b228ae05cbc5c6dcb333a6a490f65db'
    assert sha(W/'FROZEN-PINS.json')==rootsha
    assert sha(W/'verification/integrated/RESULT.json')==intsha
    pins=read(W/'FROZEN-PINS.json'); A=Path(pins['project']); R=Path(pins['release'])
    # Execute the reviewed verifier's read-only assertions; remove only its evidence writer.
    src=(W/'verify_final_integrated.py').read_text('utf-8-sig')
    cut=" out=W/'verification/integrated';out.mkdir(parents=True,exist_ok=False)"
    assert src.count(cut)==1
    src=src.split(cut)[0]+' return result\n'
    ns={'__file__':str(W/'verify_final_integrated.py'),'__name__':'independent_assertions'}
    exec(compile(src,str(W/'verify_final_integrated.py'),'exec'),ns)
    checked=ns['main'](); original=read(W/'verification/integrated/RESULT.json')
    assert {k:v for k,v in checked.items() if k!='atUtc'}=={k:v for k,v in original.items() if k!='atUtc'}
    changes=read(W/'assembly/CHANGES.final.json')['files']; assert len(changes)==10
    closure={r['path']:r['sha256'] for r in read(W/'assembly/UNIFIED-PINS.json')['files']}
    old=P/'work/region-followup-20261027'; oldpins=read(old/'FROZEN-PINS.json')
    assert sha(old/'assembly/UNIFIED-PINS.json')==oldpins['unifiedPinsSha256']
    prior=read(old/'assembly/UNIFIED-PINS.json')['files']; assert len(prior)==9298
    assert {r['path'] for r in prior}<=closure.keys()
    for row in prior:
        n=row['path']; assert sha(Path(oldpins['project'])/n)==row['sha256'],n
        if n not in changes:assert closure[n]==row['sha256'],n
        else:assert changes[n]['before']==row['sha256'] and changes[n]['after']==closure[n]
    for n,row in changes.items(): assert sha(R/row['publishedRelativePath'])==row['after'],n
    materials={}
    for name in ['reviewed_reply_materials.json','reply_public_read_materials.json']:
        m=read(R/name); oldm=read(Path(oldpins['project'])/'work/ui-native-r57'/name)
        assert {k:v for k,v in m.items() if k!='sources'}=={k:v for k,v in oldm.items() if k!='sources'}
        assert oldm['sources'].keys()<=m['sources'].keys()
        for n,h in m['sources'].items():assert sha(A/n)==h,n
        for n,h in m['runtimeTree'].items():assert sha(A/n)==h,n
        materials[name]={'sha256':sha(R/name),'sourceCount':len(m['sources']),'runtimeCount':len(m['runtimeTree'])}
    sys.path.insert(0,str(D))
    cloud=load('exact_cloud_executor',D/'execute_code_only.py')
    candidate=cloud.local_material(); composition=read(D/'COMPOSITION.json'); offline=read(D/'OFFLINE-VERIFICATION.json')
    package=W/'review/corrected-package-proof/fangyu-workspace.zip'
    assert offline['status']=='PASS' and offline['candidateTree']==composition['afterTree'] and sha(package)==offline['packageSha256']
    zipped={}
    with zipfile.ZipFile(package) as z:
        for info in z.infolist():
            if info.is_dir():continue
            n=info.filename; rel=PurePosixPath(n)
            assert not rel.is_absolute() and '..' not in rel.parts and n not in zipped
            data=z.read(info);zipped[n]={'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)}
    assert zipped==candidate and len(zipped)==5620
    for c in offline['checks']:assert c['exitCode']==0 and sha(D/'tests'/(c['name']+'.log'))==c['logSha256']
    for n,h in offline['sourceTestHashes'].items():assert sha(D/'tests'/n)==h==sha(old/'cloud/tests'/n)
    before=read(D/'BASE.json')['sourceIndex']
    # Independently verify the textual delta is exactly the two new version entries.
    oldcode=old/'cloud/candidate/reviewed_reply_release.cjs'; newcode=D/'candidate/reviewed_reply_release.cjs'
    assert sha(oldcode)==before['reviewed_reply_release.cjs']['sha256']
    material=composition['registrationMaterialDigest']
    stripped=newcode.read_text('utf-8')
    assert stripped.count(material)==2
    for version in ['VERSION','NATIVE_VERSION']:
        addition=",Object.freeze({protocol:PROTOCOL,clientVersion:"+version+",materialSha256:'"+material+"'})"
        assert stripped.count(addition)==1
        stripped=stripped.replace(addition,'')
    assert stripped==oldcode.read_text('utf-8')
    for digest in composition['priorMaterialPreserved']:assert newcode.read_text('utf-8').count(digest)==2
    updater=load('exact_next_launch',W/'next_launch_update.py')
    assert sha(updater.GENERIC)==updater.GENERIC_SHA and sha(W/'closed_update_guard.py')==updater.GUARD_SHA
    now=datetime.now(timezone.utc).isoformat()
    source=dict(status='APPROVED_EXACT_FROZEN_SOURCE',approved=True,atUtc=now,reviewer='independent closure_audit',
        rootPinsSha256=rootsha,releaseId=pins['releaseId'],rootVerificationSha256=intsha,
        completeClosureFiles=checked['completeClosureFiles'],baselineFilesVerified=9298,changedSourceFiles=10,
        changedSources={n:row['after'] for n,row in changes.items()},materials=materials,
        independentCoreReviewSha256=sha(W/'review/independent-core/REVIEW.json'),
        independentBatchReviewSha256=sha(W/'review/independent-batch/REVIEW.json'),
        integratedEvidence=checked['sourceBoundEvidence'],entryVerificationSha256=sha(W/'verification/entry-final/RESULT.json'),
        auditScriptSha256=sha(Path(__file__)),blockingFindings=[],
        reviewedBoundaries=['Account-bound first-person resident and introduction claims even when offer is off','Customer-owned needs separated from other authors','Qualified five-grade selection bound through workflow fingerprint, fresh classification/contact checks and later CAS','605 loaded customers paginate without loss; dirty edits and unknown save receipts protected','Historical release and both material runtime closures preserved'],
        limitations=['47 draft calibration remains pending; no universal Chinese semantic guarantee','No real platform send/receive or real model batch tested','No small-screen native UI or new user visual acceptance'],
        auditEffects={'productionWrites':0,'cloudCalls':0,'platformCalls':0,'realModelCalls':0,'realMessagesSent':0})
    save(W/'independent/FINAL-SOURCE-REVIEW.json',source)
    entry=dict(approvedForNextLaunchUpdate=True,blockingFindings=[],atUtc=now,releaseId=pins['releaseId'],
        updaterSha256=sha(W/'next_launch_update.py'),genericInstallerSha256=updater.GENERIC_SHA,
        guardReaderSha256=updater.GUARD_SHA,rootPinsSha256=rootsha,baselineSha256=sha(W/'BASELINE.json'),
        rootVerificationSha256=intsha,sourceReviewSha256=sha(W/'independent/FINAL-SOURCE-REVIEW.json'),
        nextLaunchVerifierSha256=sha(W/'verify_next_launch_entry.py'),
        scope='One CAS-bound source-only next-launch entry update. No restart, current-window control, database write/restore, collection, model generation or platform send.',
        requiredPostcheck='Run reviewed verify_next_launch_entry.py and stop on drift or unknown result; approval is not proof of installation.')
    save(W/'review/NEXT-LAUNCH-REVIEW.json',entry)
    approval=dict(status='ASTRA_APPROVED_EXACT_CODE_ONLY',atUtc=now,pins=cloud.pins(),rootPinsSha256=rootsha,
        beforeTree=composition['beforeTree'],afterTree=composition['afterTree'],blockingFindings=[],
        sourceReviewSha256=sha(W/'independent/FINAL-SOURCE-REVIEW.json'),
        scope='Exactly one execute_code_only.py --execute-reviewed transaction for the pinned candidate. Fresh Active configuration, protected configuration and full ZIP CAS required before update; complete readback after; never retry an unknown outcome.',
        delta='Only two version entries for the new material in reviewed_reply_release.cjs; 5619 original files and all previous material entries preserved.',
        exclusions=['No business database access','No live model batch','No platform message or collection','No configuration permission expansion','No alternate deploy.py main invocation'],
        deploymentPerformedByReviewer=False)
    save(D/'DEPLOY-REVIEW.json',approval)
    for f in ['independent/FINAL-SOURCE-REVIEW.json','review/NEXT-LAUNCH-REVIEW.json','cloud/DEPLOY-REVIEW.json']:
        print(json.dumps({'path':f,'sha256':sha(W/f)},ensure_ascii=False))
if __name__=='__main__':main()
