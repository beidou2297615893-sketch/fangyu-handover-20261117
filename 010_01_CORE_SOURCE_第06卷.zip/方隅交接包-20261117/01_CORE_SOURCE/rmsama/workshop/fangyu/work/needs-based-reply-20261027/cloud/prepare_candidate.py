"""Add one newly frozen sender material to the verified current cloud code."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,re,sys
sys.dont_write_bytecode=True
D=Path(__file__).resolve().parent;W=D.parent
read=lambda p:json.loads(p.read_text('utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def files(root):return {p.relative_to(root).as_posix():{'sha256':sha(p),'bytes':p.stat().st_size} for p in root.rglob('*') if p.is_file()}
def tree(rows):return hashlib.sha256(''.join(k+'\0'+rows[k]['sha256']+'\n' for k in sorted(rows)).encode()).hexdigest()
def main():
 assert sys.argv[1:]==['--prepare-only']
 base=read(D/'BASE.json');assert base['status']=='CLOUD_VERIFIED_BASE_COPIED'
 candidate=D/'candidate';before=files(candidate);assert before==base['sourceIndex'] and tree(before)==base['treeSha256']
 pins=read(W/'FROZEN-PINS.json');release=Path(pins['release']);assert sha(release/'RELEASE.json')==pins['manifestSha256']
 source=read(release/'reviewed_reply_materials.json')
 registration=hashlib.sha256(json.dumps(source,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
 assert re.fullmatch('[a-f0-9]{64}',registration)
 path=candidate/'reviewed_reply_release.cjs';original=path.read_text('utf-8')
 oldhash='0b393c8b352571b639326c17078cdf3aa2550dc50fc10ecc5d2fbbb1356baf85'
 ending="materialSha256:'"+oldhash+"'})]);"
 assert original.count(ending)==1 and registration not in original
 added="materialSha256:'"+oldhash+"'}),Object.freeze({protocol:PROTOCOL,clientVersion:VERSION,materialSha256:'"+registration+"'}),Object.freeze({protocol:PROTOCOL,clientVersion:NATIVE_VERSION,materialSha256:'"+registration+"'})]);"
 path.write_text(original.replace(ending,added),encoding='utf-8',newline='\n')
 after=files(candidate);changed={k for k in before.keys()|after.keys() if before.get(k)!=after.get(k)}
 assert changed=={'reviewed_reply_release.cjs'} and len(after)==5620
 matches=re.findall(r"materialSha256:'([a-f0-9]{64})'",path.read_text('utf-8'))
 assert sorted(matches)==sorted(['67c3b2cf6f8babda9fb5516ff2aeaed9b138d58cb898908d8729ae768d14f914']*2+[oldhash]*2+[registration]*2)
 result={'status':'PREPARED_NOT_DEPLOYED','atUtc':datetime.now(timezone.utc).isoformat(),
  'beforeTree':base['treeSha256'],'afterTree':tree(after),'beforeFiles':5620,'afterFiles':5620,
  'changedFiles':[{'path':k,'beforeSha256':before[k]['sha256'],'afterSha256':after[k]['sha256']} for k in sorted(changed)],
  'unchangedOriginalFiles':5619,'registrationMaterialDigest':registration,'registrationMaterialFileSha256':sha(release/'reviewed_reply_materials.json'),
  'rootPinsSha256':sha(W/'FROZEN-PINS.json'),'priorMaterialPreserved':[oldhash,'67c3b2cf6f8babda9fb5516ff2aeaed9b138d58cb898908d8729ae768d14f914'],
  'deploymentExecuted':False,'productionWrites':False,'realMessagesSent':False}
 with (D/'COMPOSITION.json').open('x',encoding='utf-8') as f:json.dump(result,f,indent=2)
 print(json.dumps({'status':result['status'],'afterTree':result['afterTree'],'registrationMaterialDigest':registration}))
if __name__=='__main__':main()
