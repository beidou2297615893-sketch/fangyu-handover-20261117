import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {residentPresetMarkup,residentReferences} from './fixture-web/pages/resident-tone-preset.mjs';
const require=createRequire('C:/积木软件工坊/项目/方隅公寓客户版/work/region-followup-20261027/assembly/project/work/ui-native-r57/public_article_generic/package.json');
const {JSDOM}=require('jsdom');
const dom=new JSDOM(residentPresetMarkup({stylePresetId:'resident_seeding_v1'}));
const text=dom.window.document.body.textContent;
// A stale hard-coded page would hide the user's new first-person assistance wording.
for(const quote of ['宝宝我住方隅，我能给你介绍便宜','宝宝一房的话你可以看一下方隅，我给你介绍能便宜','宝宝方隅带电梯的，你要了解一下不？可以加我，我帮你联系销售']){
 assert.ok(text.includes(quote),'show the exact user-spoken wording with only the brand normalized: '+quote);
}
assert.equal(residentReferences.length,6,'retain the original wording-reference set');
assert.ok(text.includes('来自你的口述')&&text.includes('校准中'));
assert.ok(text.includes('仅适用于小北本人')&&text.includes('其他账号'));
assert.ok(!text.includes('宝宝我住方隅，我给你介绍还能便宜'),'AI draft is not relabeled as verbatim user speech');
console.log('PASS resident UI shows three exact new user-spoken references, six originals retained, calibrated/account facts separated from draft approval');
