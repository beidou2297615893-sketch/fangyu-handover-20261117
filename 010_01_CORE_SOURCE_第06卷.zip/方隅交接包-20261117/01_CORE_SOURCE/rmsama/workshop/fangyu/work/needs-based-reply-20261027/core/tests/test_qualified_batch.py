import copy
from unittest.mock import patch
import test_actual_snapshot as fixtures
from test_actual_snapshot import old, Workflow
import unittest
import reply_ai_workflow as wf

class QualifiedBatchTests(unittest.TestCase):
    def setUp(self):
        self.case=old.HandoffSnapshotCASTests()
        self.case.setUp()
        self.addCleanup(self.case.doCleanups)
        f=self.case
        f.item['contactState']='unreplied'
        f.b.core.store.put('leads',{**f.f.fixture.lead,'id':'l2','comment_id':'batch-new','reply_status':'unreplied'})
        original=f.b.customer_workbench.detail_context
        def detail(user,store,customer,platform=None):
            a,p,i,person=original(user,store,customer,platform=platform)
            person['comments'].append({'lead_id':'l2','text':'古北低楼层'})
            return a,p,i,person
        f.b.customer_workbench.detail_context=detail
        f.b.customer_workbench.detail=lambda user,store,customer,platform=None:detail(user,store,customer,platform=platform)[2]
        f.b._voice_samples_dispatch=lambda *args:{'voiceSamples':{'items':[]}}
        self.workflow=Workflow(f.b,provider=lambda *args:None,local_identity=f.b._identity)
        self.data={'storeId':'s1','accountId':'a1','platform':'xiaohongshu','customerIds':[f.f.cid],'tone':'','requestId':'qualified','selectionMode':'qualified','gradeBands':['high']}
    def start(self,data=None):
        with patch.object(wf.AccountProfiles,'capture',return_value=None),patch.object(wf.threading.Thread,'start',return_value=None):
            return self.workflow.dispatch('reply_ai_start',data or self.data,self.case.f.token)
    def test_qualified_start_accepts_and_binds_selection(self):
        result=self.start()['replyAI']
        self.assertEqual(result['selectionMode'],'qualified')
        self.assertEqual(result['gradeBands'],['high'])
        self.assertEqual(result['rows'][0]['qualifiedSelection']['gradeBands'],['high'])
        self.workflow.running.clear()
        with self.assertRaises(ValueError):self.start({**self.data,'gradeBands':['high','medium']})
    def test_rejects_each_stale_axis_before_any_job_write(self):
        f=self.case
        cases=[('aggregateState','stale'),('interestStatus','uncertain'),('interestLevel','medium'),('regionMatch',{'state':'unknown'}),('demandState','ended'),('storeEligibility',{'state':'no_known_exclusion','role':'supply'}),('contactState','sent'),('contactState','unknown'),('contactState','sending')]
        initial=copy.deepcopy(f.item)
        for key,value in cases:
            f.item.clear();f.item.update(copy.deepcopy(initial));f.item[key]=value
            with self.subTest(key=key,value=value),self.assertRaises(ValueError):self.start()
            self.assertEqual(f.b.core.store.list(wf.ENTITY,'t1'),[])
    def test_missing_snapshot_and_invalid_schema_fail_closed(self):
        with patch.object(wf,'capture_handoff',return_value=None),self.assertRaises(ValueError):self.start()
        for fields in [{'selectionMode':'qualified'},{'gradeBands':['high']},{'selectionMode':'all','gradeBands':['high']},{'selectionMode':'qualified','gradeBands':[]},{'selectionMode':'qualified','gradeBands':['high','high']}]:
            data={k:v for k,v in self.data.items() if k not in ('selectionMode','gradeBands')};data.update(fields)
            with self.subTest(fields=fields),self.assertRaises(ValueError):self.start(data)
    def test_second_capture_change_aborts_without_job(self):
        original=wf.capture_handoff;calls=[]
        def capture(*args,**kwargs):
            result=original(*args,**kwargs);calls.append(1)
            if len(calls)>1:result['qualification']['contextDigest']='changed'
            return result
        with patch.object(wf,'capture_handoff',side_effect=capture),self.assertRaises(ValueError):self.start()
        self.assertEqual(self.case.b.core.store.list(wf.ENTITY,'t1'),[])
    def test_contact_change_before_provider_is_rejected(self):
        public=self.start()['replyAI'];job=self.case.b.core.store.get(wf.ENTITY,public['id']);row=job['rows'][0]
        self.case.item['contactState']='sent'
        self.assertFalse(self.workflow.provider_authorized(job['id'],row,self.case.f.token,self.data,self.case.scope))
    def test_legacy_request_omits_new_fields(self):
        data={k:v for k,v in self.data.items() if k not in ('selectionMode','gradeBands')}
        job=self.start(data)['replyAI']
        self.assertNotIn('selectionMode',job)
        self.assertNotIn('qualifiedSelection',job['rows'][0])

    def test_qualification_change_at_commit_and_confirmation_preserves_old_drafts(self):
        public=self.start()['replyAI'];job=self.case.b.core.store.get(wf.ENTITY,public['id']);row=job['rows'][0]
        self.case.item['regionMatch']={'state':'other'}
        with self.assertRaises(ValueError):
            self.workflow.commit_generation(job['id'],0,row,{'reply':'宝宝要低楼层吗','shouldReply':True},None,self.case.f.token,self.data,self.case.scope)
        with self.assertRaises(ValueError):
            self.workflow.checked_row(job,row,self.case.user,self.case.scope,self.case.f.token)
        current=self.case.b.core.store.get(wf.ENTITY,job['id'])
        self.assertEqual(current['rows'][0]['text'],'')
        self.assertEqual(self.case.b.core.store.get('replies','r1')['status'],'sent')

    def test_contact_change_at_commit_and_confirmation_is_rejected(self):
        public=self.start()['replyAI'];job=self.case.b.core.store.get(wf.ENTITY,public['id']);row=job['rows'][0]
        self.case.item['contactState']='unknown'
        with self.assertRaises(ValueError):
            self.workflow.commit_generation(job['id'],0,row,{'reply':'宝宝要低楼层吗','shouldReply':True},None,self.case.f.token,self.data,self.case.scope)
        with self.assertRaises(ValueError):
            self.workflow.checked_row(job,row,self.case.user,self.case.scope,self.case.f.token)

    def test_each_grade_code_and_legacy_fingerprint(self):
        for band in ('super_high','high','medium','low','very_low'):
            self.case.item['interestLevel']=band
            job=self.start({**self.data,'requestId':'grade-'+band,'gradeBands':[band]})['replyAI']
            self.assertEqual(job['gradeBands'],[band])
            self.workflow.running.clear()
        data={k:v for k,v in self.data.items() if k not in ('selectionMode','gradeBands')};data['requestId']='legacy-fingerprint'
        snapshot=wf.capture_handoff(self.case.b,self.case.user,self.case.scope,self.case.f.cid,self.case.f.token)
        base=wf.digest([data['customerIds'],data['tone']])
        expected=wf.digest([base,{self.case.f.cid:wf.digest({k:v for k,v in snapshot.items() if k not in ('sourceDigest','contextBindingDigest')})}])
        self.assertEqual(self.start(data)['replyAI']['requestFingerprint'],expected)

    def test_backend_start_qualification_rejection_is_definitely_not_created(self):
        f=self.case
        f.b.context_reply_workflow=self.workflow
        original=self.workflow.check_qualified
        for checkpoint in (1,2,3):
            calls=[]
            def check(*args,**kwargs):
                calls.append(1)
                if len(calls)==checkpoint:
                    snapshot=copy.deepcopy(args[3]);snapshot['qualification']['regionMatch']='other'
                    args=(*args[:3],snapshot,*args[4:])
                return original(*args,**kwargs)
            with self.subTest(checkpoint=checkpoint),patch.object(self.workflow,'check_qualified',side_effect=check),patch.object(wf.AccountProfiles,'capture',return_value=None),patch.object(wf.threading.Thread,'start',return_value=None):
                with self.assertRaises(old.fixture.backend.WorkbenchError) as caught:
                    f.b.dispatch('reply_ai_start',self.data,f.f.token)
                self.assertEqual(caught.exception.code,'REPLY_AI_NOT_CREATED')
                self.assertIs(caught.exception.mutation_committed,False)
            self.assertEqual(f.b.core.store.list(wf.ENTITY,'t1'),[])
        # The unchanged request can be retried after reloading, because no job exists.
        self.assertEqual(self.start()['replyAI']['state'],'running')

    def test_runtime_qualification_rejection_remains_expired(self):
        f=self.case;snapshot=f.snapshot();snapshot['qualification']['regionMatch']='other'
        with self.assertRaises(wf.HandoffExpired):
            self.workflow.check_qualified(f.user,f.scope,f.f.cid,snapshot,['high'])
