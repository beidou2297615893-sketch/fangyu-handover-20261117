"""Offline actual Store/Core/ReplyWorkbench boundary; no model or platform."""
import os, sys, tempfile, threading, unittest, socket
from pathlib import Path
from types import SimpleNamespace
from copy import deepcopy
from unittest.mock import patch

W=Path(__file__).resolve().parents[1]
P=W.parents[1]
R=P/'region-followup-20261027/assembly/project/work/ui-native-r57/releases/ui-r57-20261027T060342Z-7716d199'
PROJECT=P/'region-followup-20261027/assembly/project'
sys.path[:0]=[str(W/'overlay'),str(R),str(PROJECT/'work/ui-runtime-r55/src')]
from core.engine import Core
from core.store import Store
from core.contact_journal import ContactJournal
from reply_workbench import ReplyWorkbench
from reply_account_profiles import AccountProfiles, ProfileError

def item(level='low',**changes):
    value=dict(name='合成客户',platform='xiaohongshu',rank=0,contactState='none',aggregateState='current',
        analysisStatus='graded',intentLevel=level,interestStatus='graded',interestLevel=level,
        demandState='active',regionMatch={'state':'match'},storeEligibility={'state':'no_known_exclusion','role':'demand'})
    value.update(changes);return value

class Customers:
    def __init__(self,core,items):self.core=core;self.items=items
    def _media_url(self,*a):return ''
    def detail_context(self,user,store,customer,platform=None):
        if store!='s' or customer not in self.items:raise ValueError('scope')
        lead=self.core.store.get('leads',customer)
        return user,{},deepcopy(self.items[customer]),{'comments':[{'lead_id':customer,'text':lead['text']}]}

class QualifiedRoutingTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(dir=W/'tests');self.addCleanup(self.tmp.cleanup)
        block=patch.object(socket.socket,'connect',side_effect=AssertionError('network forbidden'));block.start();self.addCleanup(block.stop)
        self.store=Store(self.tmp.name);self.user=dict(id='u',username='owner',tenant_id='t',role='operator',cloud_bound=True)
        self.store.put('users',self.user)
        self.core=Core.__new__(Core);self.core.store=self.store;self.core.lock=threading.RLock();self.core.contact_journal=ContactJournal(self.store)
        self.store.put('accounts',dict(id='a',tenant_id='t',cloud_owner='owner',store_id='s',platform='xiaohongshu',platform_uid='uid-a',name='真实合成账号'))
        self.items={};customers=Customers(self.core,self.items)
        self.b=SimpleNamespace(lock=threading.RLock(),core=self.core,_identity=lambda token:(self.user,{'can_reply':True}),_selected_store=lambda *a:'s')
        self.b.reply_workbench=ReplyWorkbench(self.core,customers);self.service=AccountProfiles(self.b)
        self.base={'storeId':'s','platform':'xiaohongshu'}
        self.service.dispatch('reply_account_profile_save',{**self.base,'accountId':'a','expectedRevision':0,'requestId':'profile',
            'profile':dict(displayName='宠物话题',roleFacts='本人只提供已确认的信息，不声明住户身份',tone='自然',topics=['pet'],confirmed=True)},'token')
    def add(self,ident,value):
        self.items[ident]=value
        self.store.put('leads',dict(id=ident,tenant_id='t',cloud_owner='owner',platform='xiaohongshu',source_type='comment',comment_id=ident,author_id='uid-'+ident,
            author='合成客户',note_url='https://www.xiaohongshu.com/explore/note',text='租房可以养猫吗？',comment_level=1))
    def preview(self,ids,mode=None):
        try:return self.service.dispatch('reply_route_preview',{**self.base,'customerIds':ids,**({'selectionMode':mode} if mode is not None else {})},'token')['replyAccounts']
        except ProfileError:
            if mode=='qualified':self.fail('explicit safe batch selection mode is not supported')
            raise
    def test_explicit_qualified_mode_includes_all_five_levels_with_current_axes(self):
        # Removing the explicit-mode branch or retaining rank>=2 would lose real low/medium demand.
        for level in ('super_high','high','medium','low','very_low'):self.add(level,item(level))
        routes=self.preview(list(self.items),'qualified')['routes']
        self.assertEqual([r['customerId'] for r in routes if r['eligible']],list(self.items))
        self.assertEqual([r['recommendedAccountId'] for r in routes],['a']*5)
    def test_high_history_cannot_override_disqualifying_current_axes(self):
        cases={'ended':item('high',rank=3,demandState='ended'),'other':item('high',rank=3,regionMatch={'state':'other'}),
            'supply':item('high',rank=3,storeEligibility={'state':'excluded','role':'supply'}),
            'reject':item('high',rank=3,storeEligibility={'state':'excluded','role':'demand'}),
            'stale':item('high',rank=3,aggregateState='stale'),'unknown':item('high',rank=3,regionMatch={'state':'unknown'}),
            'sent':item('high',rank=3,contactState='sent'),'unrelated':item('high',rank=3,interestStatus='unrelated')}
        for ident,value in cases.items():self.add(ident,value)
        routes=self.preview(list(cases),'qualified')['routes']
        self.assertEqual([r['eligible'] for r in routes],[False]*8)
        self.assertTrue(all(not r['recommendedAccountId'] and not r['candidates'] for r in routes))
    def test_default_remains_high_only_and_unknown_modes_fail_closed(self):
        self.add('low',item());self.add('high',item('high',rank=2))
        routes=self.preview(['low','high'])['routes']
        self.assertEqual([r['eligible'] for r in routes],[False,True])
        for unsupported in ('all','clarify'):
            with self.assertRaises(ProfileError):self.preview(['high'],unsupported)
    def test_profile_uid_binding_and_stale_assignment_remain_enforced(self):
        self.add('low',item())
        self.service.dispatch('reply_assignment_save',{**self.base,'customerId':'low','accountId':'a','expectedRevision':0,'expectedEvidenceRevision':0,'expectedProfileRevision':1,'requestId':'assign'},'token')
        self.assertEqual(self.preview(['low'],'qualified')['groups'],[{'accountId':'a','customerIds':['low']}])
        a=self.store.get('accounts','a');a['platform_uid']='rebound';self.store.put('accounts',a)
        result=self.preview(['low'],'qualified')
        self.assertEqual(result['groups'],[]);self.assertEqual(result['routes'][0]['recommendedAccountId'],'')
        with self.assertRaises(ProfileError):self.service.capture(self.user,['t','u','s','a','xiaohongshu'],'low')
    def test_draft_and_queue_records_untouched_by_preview(self):
        self.add('low',item());self.store.put('replies',{'id':'old','tenant_id':'t','text':'旧稿保留'})
        before=self.store.list('replies','t');self.preview(['low'],'qualified')
        self.assertEqual(self.store.list('replies','t'),before);self.assertEqual(self.store.list('reply_queues','t'),[])

if __name__=='__main__':unittest.main()
