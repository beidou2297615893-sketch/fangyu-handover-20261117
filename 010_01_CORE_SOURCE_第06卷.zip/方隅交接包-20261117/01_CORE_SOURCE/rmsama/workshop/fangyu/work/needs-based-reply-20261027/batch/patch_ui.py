from pathlib import Path
W=Path(__file__).resolve().parent
p=W/'overlay/web/pages/reply-account-routing.mjs'
s=p.read_text(encoding='utf-8')
s=s.replace('根据高意向客户的明确需求推荐一个回复账号，可逐人改选。仅整理当前所选范围；原有草稿继续保留。',"${draftScope(v).selectionMode==='qualified'?'按本批高、中、低有效需求推荐账号；地域、时效和供需资格分别核对。':draftScope(v).selectionMode==='clarify'?'本批只核对待澄清需求，请逐人手工选择账号；不推荐推销。':'默认仅根据高意向客户的明确需求推荐一个回复账号，可逐人改选。'}仅整理当前所选批次；原有草稿继续保留。")
s=s.replace("const m=model(v),d=m.data,locked=", "const m=model(v),scopeKey=JSON.stringify([draftScope(v).selectionMode,ids(v)]),d=m.scopeKey&&m.scopeKey!==scopeKey?null:m.data,locked=")
s=s.replace("accountName:accountName(m.data.accounts.find(a=>a.id===group.accountId))", "accountName:accountName(m.data.accounts.find(a=>a.id===group.accountId)),selectionMode")
p.write_text(s,encoding='utf-8')
p=W/'overlay/web/pages/reply-ai.mjs'
s=p.read_text(encoding='utf-8').replace("import {renderRouting,bindRouting}","import {renderRouting,bindRouting,draftScope}")
s=s.replace("import {customerAvatar", "import {acceptFollowupResponse,openCustomerFollowup} from './customer-followup.mjs';\nimport {customerAvatar",1)
s=s.replace("lock=a.busy||run,scopeLock=lock,reopen=", "lock=a.busy||run,scopeLock=lock||Boolean(a.startPending)||Boolean(v.accountRouting?.busy||v.accountRouting?.pending),reopen=")
s=s.replace("<select data-ai-range ${lock?'disabled':''}>","<select data-ai-range ${scopeLock?'disabled':''}>")
s=s.replace('>当前客户</option><option value="list"', '>当前客户（人工核对）</option><option value="qualified" ${a.range===\'qualified\'?\'selected\':\'\'}>有效意向：高 / 中 / 低</option><option value="clarify" ${a.range===\'clarify\'?\'selected\':\'\'}>待澄清需求（不推销）</option><option value="list"')
s=s.replace("a.range!=='list'&&a.range!=='group'", "!['list','group','qualified','clarify'].includes(a.range)")
s=s.replace('>当前列表（${v.items.length}位）</option></select></div></label>${renderStyle(a)}','>已加载列表（人工核对 ${v.items.length}位）</option></select></div></label>${renderDraftScope(v,scopeLock)}${renderStyle(a)}${renderHandoffState(a,scopeLock)}')
s=s.replace("a.groupName=group.accountName;a.range='group';", "a.groupName=group.accountName;a.groupSelectionMode=group.selectionMode||'recommended';a.batchPage=0;a.range='group';")
s=s.replace("a.groupCustomerIds=null;a.groupName='';", "a.groupCustomerIds=null;a.groupName='';a.groupSelectionMode='recommended';a.batchPage=0;a.handoffInfo=null;a.handoffReadAccount='';")
s=s.replace("a.range=e.target.value;", "if(!owns()||scopeLocked())return;a.range=e.target.value;a.batchPage=0;resetRouting();refresh();")
s=s.replace("const ids=a.range==='group'?[...(a.groupCustomerIds||[])]:a.range==='list'?v.items.map(x=>x.id):[v.selectedId];", "if(!owns())return;const ids=draftScope(v).customerIds;")
s=s.replace("const s=ctx.state,a=model(v),origin=stamp(s),accountAtBind=a.accountId,owns=", "const s=ctx.state,a=model(v),origin=stamp(s),accountAtBind=a.accountId,owns=")
p.write_text(s,encoding='utf-8')
