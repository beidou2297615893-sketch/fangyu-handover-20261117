"""Final frozen entry checks, durable full logs, no GUI or production App."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import hashlib,json,os,subprocess
W=Path(__file__).resolve().parent;read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'));sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
pins=read(W/'FROZEN-PINS.json');P=W.parents[1];out=W/'verification/entry-final';out.mkdir(parents=True,exist_ok=False)
def run(flag):
 args=[str(P/'work/desktop-python/Scripts/python.exe'),'-X','utf8','-I','-B',pins['launcherPath'],flag]
 result=subprocess.run(args,encoding='utf-8',errors='replace',capture_output=True,timeout=180,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'})
 name=flag.lstrip('-');log=out/(name+'.log');log.write_text(result.stdout+'\n'+result.stderr,encoding='utf-8')
 parsed=json.loads(result.stdout);assert result.returncode==0 and parsed['status']=='PASS'
 assert parsed.get('business_app_imported') is False and parsed.get('native_windows_opened')==0
 return {'name':flag,'exitCode':result.returncode,'result':parsed,'logSha256':sha(log)}
with ThreadPoolExecutor(max_workers=2) as pool:checks=list(pool.map(run,['--check','--self-test']))
assert sha(Path(pins['launcherPath']))==pins['launcherSha256']
assert sha(Path(pins['release'])/'RELEASE.json')==pins['manifestSha256']
assert sha(W/'assembly/UNIFIED-PINS.json')==pins['unifiedPinsSha256']
for name,h in read(W/'BASELINE.json')['canonical'].items():assert sha(P/'work/ui-native-r57'/name)==h
result={'status':'PASS','rootPinsSha256':sha(W/'FROZEN-PINS.json'),'releaseId':pins['releaseId'],'checks':checks,
 'productionDataAccess':False,'nativeWindowsOpened':0,'realPlatformCalls':0,'sourceUnmodified':True,'canonicalUnchanged':True}
(out/'RESULT.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'status':'PASS','checks':len(checks),'publicAssertions':checks[1]['result']['checks'],'rootPinsSha256':result['rootPinsSha256']}))
