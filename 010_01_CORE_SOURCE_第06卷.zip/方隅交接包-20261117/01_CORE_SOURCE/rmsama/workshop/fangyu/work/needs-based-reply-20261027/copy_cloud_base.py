"""Copy only the exact previously verified cloud code; no network or deployment."""
from pathlib import Path,PurePosixPath
from datetime import datetime,timezone
import hashlib,json,shutil,sys,zipfile
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;P=W.parents[1];O=P/'work/region-followup-20261027/cloud'
read=lambda p:json.loads(p.read_text('utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 assert sys.argv[1:]==['--copy-verified-base']
 source=O/'readback-correction-postcommit';report=read(source/'LIVE-READBACK.json');verified=read(source/'FULL-READBACK-VERIFICATION.json')
 expected='e451a5761b9ec70184c14901cbb4d162afa9061a50ebb5eea365d54de11670cc'
 assert report['treeSha256']==verified['treeSha256']==expected and verified['status']=='PASS'
 archive=source/'live-function-code.zip';assert sha(archive)==report['codeZipSha256']
 target=W/'cloud/candidate';assert not target.exists();target.mkdir(parents=True)
 rows={}
 with zipfile.ZipFile(archive) as z:
  for info in z.infolist():
   if info.is_dir():continue
   name=info.filename;q=PurePosixPath(name);assert not q.is_absolute() and '..' not in q.parts and '\\' not in name and ':' not in name and name not in rows
   data=z.read(info);path=target.joinpath(*q.parts);path.parent.mkdir(parents=True,exist_ok=True)
   with path.open('xb') as f:f.write(data)
   rows[name]={'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)}
 assert len(rows)==5620
 tree=hashlib.sha256(''.join(k+'\0'+rows[k]['sha256']+'\n' for k in sorted(rows)).encode()).hexdigest();assert tree==expected
 result={'status':'CLOUD_VERIFIED_BASE_COPIED','atUtc':datetime.now(timezone.utc).isoformat(),'treeSha256':tree,'files':len(rows),
  'sourceZipSha256':sha(archive),'sourceReceiptSha256':sha(source/'FULL-READBACK-VERIFICATION.json'),
  'sourceIndex':rows,'networkCalls':0,'deployed':False}
 with (W/'cloud/BASE.json').open('x',encoding='utf-8') as f:json.dump(result,f,indent=2)
 print(json.dumps({'status':result['status'],'files':len(rows)}))
if __name__=='__main__':main()
