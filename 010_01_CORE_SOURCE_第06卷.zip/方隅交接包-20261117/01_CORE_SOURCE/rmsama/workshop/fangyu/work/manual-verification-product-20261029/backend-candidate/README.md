# 人工验证后同窗核对候选

状态：仅隔离源码候选和离线测试，未替换原版、启动客户软件、接管窗口、访问账号、修改数据库或请求平台；不能称为产品已验收。

修改文件：`src/assistant/browser_login_window.py`、`src/assistant/native_login_observer.py`。其余 src 文件是现有工程依赖快照，没有业务修改。

## 已实现

- 自然身份观察遇验证要求后保留原 WebView，不创建新窗口、不导航、不刷新、不注入验证码处理。
- 丢弃验证前身份及未读响应体，保留作业、绑定账号、原文档 frame/loader，增加观察任务代次；后续仅被动记录页面自然产生的新身份响应。
- 受管窗口原生“账号操作”菜单提供“我已完成验证，核对一次”，直接调用此窗口 controller；无网页 JS bridge，无远端控制端点。
- `LoginWindowController.confirm_manual_verification()` 单次消耗；pending/rejected 后重复点击不能再核验。已观察到的新自然身份才能复用现有 finish → cookie scoped capture → bind → stage → proof 事务入口。身份变化/取消/关闭会阻止或清理候选。
- 人工等待期间自动计时轮询不会自行核对或提交；原240秒QR超时不会关闭人工等待。
- 人工初始化、等待、核对与未通过阶段仍由原观察循环周期检查本作业取消文件及主管guard；只有本地主管IPC/文件安全检查，不轮询平台身份。主管连接失效或另一条bridge取消文件通过真实session guard闭包传播后，关闭子窗并结束等待。
- 初始化先发布不可确认的状态，观察器重置完成后才开放唯一确认，避免菜单线程抢先消耗确认。
- 核对前及未取证/未通过后调用本机pywebview `Window.set_title`，以原生标题显示固定业务提示和“取消后重新登录”。已核实安装依赖中的调用路径为Window.set_title → WinForms set_title → UI线程Invoke；没有网页JS。真实桌面显示尚未实测，不能把测试替身记录标题等同屏幕验收。

## 关键边界与接线缺口

真实自然链路是 xhs_natural_window → xhs_session_window.run_session_recovery_window → run_login_window，因此本候选所改 controller 是真实链路复用的组件。没有运行真实链路。

原主管和授权仍有效：legacy browser_login_service 有300秒总截止；自然链 xhs_session_context 创建300秒 sealed claim，xhs_session_transport 按其 deadline 停止，worker 的 Coordinator 继续使用同一 deadline。候选没有延长或绕过它们。因此“原QR240秒不关闭人工等待”不代表“可无限等待”。初版人工状态跳过guard，曾存在主管终止后子窗未响应清理的缺陷；本次已补周期guard检查。离线真实session guard闭包测试覆盖两条不同取消文件与主管IPC停止，不能据此声称真实300秒到期的完整进程清理已验收。若用户目标要求越过该授权期限仍保留页面，须先设计保持窗口与失效执行能力分离、明确重新授权及同一会话绑定的流程，不能静默续期或重放原 claim。

本机原生菜单与真实 controller 的绑定经离线测试；实际 WebView 菜单显示、网站验证完成后是否自然产生新 getMe、cookie/身份实时绑定、主管到期提示、原子提交、平台完整链路均未实测。若页面不自然产生新身份响应，此实现返回 manual_identity_pending，不主动请求、不重发、不宣称成功。

## API

- `controller.phase == 'manual_verification_required'`：需本人完成原网页验证并点原生菜单。
- `controller.confirm_manual_verification()`：同步返回当前 phase；身份快照读取一次，复用原 cookie 读取上限10秒与既有证明门禁；不发送平台请求。
- `manual_identity_pending`：本次没有完整新身份，已消耗本次确认，需取消并重新开始登录作业。
- `manual_identity_rejected`：新身份已失效/变化/异常，禁止提交。
- `candidate_staged_natural_verified`：仅原临时候选与证明完成；最终账号提交仍由原 Coordinator/claim/commit 控制，不表示已登录成功。
- `NativeLoginObserver.begin_manual_wait()`：仅允许已 attach、未 close、verification_required 时重置被动证据；不能复活取消或关闭的观察器。

## 验证

在本目录执行：`python -B -X utf8 -m unittest discover -s tests -v`。

24项通过。首轮在原始快照观察到保留窗口和QR超时两项断言失败，以及人工入口缺失；实现后通过。原生菜单绑定另行先红后绿。另用真实纯身份解析器验证旧响应不能形成新身份、新页面自然请求及完整Cookie证据才可绑定；首次该补充测试遗漏必需webId字段，修正合成夹具后通过。审查补充测试先复现7处失败，覆盖等待/确认期guard失效、取消、初始化并发和原生标题反馈，修复后通过。真实session窗口入口的guard闭包还覆盖本地取消文件、不同路径bridge取消文件及主管IPC停止，IPC与窗口仍为隔离测试替身，没有模拟成云端claim实测。测试只用合成身份和窗口；真实平台/磁盘凭据读取/原暂存与证明写盘依赖由明确的测试替身隔离。验证了本次控制层的事务调用与中断行为，不把替身成功等同生产持久化成功。

待办：设计授权过期后的页面保留与重新授权；主管/用户状态通俗提示；受控离线WebView运行验收；在用户独立授权的新账号作业内执行平台链验收。未经这些验收，不部署或替换原版。

标题并发补修：等待标题迟到不能覆盖更晚核对结果，新增可控交错测试先失败后通过；标题写入由独立锁串行化，并核验预期状态。调用本机set_title前释放controller锁，锁可用性测试通过。已核实当前WinForms原生菜单在Python新线程执行回调；该方案用于当前Windows受管入口，未宣称其他GUI后端已验证。

补充并发验证：旧setter已进入并阻塞时，新确认线程等待标题锁；释放后最后仍显示较新失败提示。setter阻塞期间cancel/on_closed仍可转换controller终态，释放后不生成候选；setter抛异常也不把失败身份变为候选。以上由Event控制的合成setter验证，不代表真实WinForms卡死已验证。当前Window.set_title底层同步Invoke没有deadline；若真实UI线程卡死，标题调用和其他依赖UI Invoke的关闭操作仍可能阻塞，独立标题锁不能解决native死锁或保证物理窗口一定关闭。该运行时风险仍未验收，不能据离线测试宣称已解决。
