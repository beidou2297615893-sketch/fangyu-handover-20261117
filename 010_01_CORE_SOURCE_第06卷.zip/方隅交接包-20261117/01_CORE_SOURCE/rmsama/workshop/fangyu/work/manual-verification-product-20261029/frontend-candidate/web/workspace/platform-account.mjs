const ACTIONS = new Set(['assistant_manual_permission_snapshot','assistant_status','assistant_workspace_state','assistant_account_safety',
  'assistant_wechat_preview_configure','assistant_wechat_preview_check','assistant_account_signal','assistant_account_slot_create','assistant_douyin_connection_start','assistant_douyin_connection_status','assistant_bilibili_setup_observe','assistant_bilibili_setup_confirm','assistant_bilibili_setup_status','assistant_bilibili_setup_cancel','assistant_account_identity_observe','assistant_account_login','assistant_new_account_login','assistant_job_status','assistant_cancel_login']);
const QR_JOB = /^[a-f0-9]{24}$/;

export class AssistantRequestError extends Error {
  constructor(message,{status,sessionExpired=false}={}){super(message);this.status=status;this.sessionExpired=sessionExpired;}
}
const employeeSessionError=()=>new AssistantRequestError('员工工作台登录已失效，请重新登录。重新登录后请刷新状态。',{status:401,sessionExpired:true});

export async function localAssistantCall(action,data={},fetcher=fetch){
  if(!ACTIONS.has(action)||!data||typeof data!=='object'||Array.isArray(data))throw Error('账号请求无效');
  const response=await fetcher('/api',{method:'POST',credentials:'same-origin',redirect:'error',cache:'no-store',
    headers:{'Content-Type':'application/json','X-Local-App':'1'},body:JSON.stringify({action,data})});
  let value;
  try{value=await response.json();}catch{if(response.status===401)throw employeeSessionError();throw Error('本机助手响应无法读取，请核对状态');}
  if(response.status===401)throw employeeSessionError();
  if(!response.ok)throw new AssistantRequestError(value?.error||'本机助手暂时无法连接',{status:response.status});
  return value;
}

export function safeXhsImageUrl(value){
  if(typeof value!=='string'||value.length>2048)return '';
  try{
    const url=new URL(value);
    const host=url.hostname.toLowerCase();
    if(url.protocol!=='https:'||url.username||url.password||!url.pathname||
      !(host==='xhscdn.com'||host.endsWith('.xhscdn.com')||host==='xiaohongshu.com'||host.endsWith('.xiaohongshu.com')))return '';
    return value;
  }catch{return '';}
}

export function reviewSignal(accountId,safety){
  if(typeof accountId!=='string'||!accountId||safety?.state!=='review_required'||
    !Number.isSafeInteger(safety.activity_revision_bytes)||safety.activity_revision_bytes<0)throw Error('请先刷新账号复核记录');
  return {account_id:accountId,kind:'review_completed',revision:safety.activity_revision_bytes};
}

export async function recoverConnection(accountId,safety,record,check){
  if(typeof record!=='function'||typeof check!=='function')throw Error('连接检查暂不可用');
  const data=reviewSignal(accountId,safety);
  await record(data);
  return check(accountId);
}

const make=(tag,text,className)=>{const element=document.createElement(tag);if(text!==undefined)element.textContent=String(text);if(className)element.className=className;return element;};
export function selectedAccountId(accounts,current=''){
  const saved=accounts.find(item=>item.id===current);
  if(saved&&(saved.status||saved.platform_nickname||saved.requires_review))return saved.id;
  return accounts.find(item=>item.requires_review)?.id||accounts.find(item=>item.status||item.platform_nickname)?.id||accounts[0]?.id||'';
}
const reasonText=reason=>({verification_required:'平台要求核对电脑端请求。请查看手机小红书是否有提示，并核对上次操作结果。',
  ip_blocked:'平台访问受限，请先人工核实账号。',not_authenticated:'登录状态失效，请先核对手机与账号。',
  manual_signal:'此前有人记录了安全提醒，请核对账号与上次操作。',other_risk:'账号出现异常，请先人工核实。',
  unknown:'操作结果或记录尚不确定，请核对后再决定。'})[reason]||'请核对账号状态与上次操作结果。';
export function accountRecovery(account){
  const blocked=account?.requires_review===true;
  const verification=blocked&&account.review_reason==='verification_required';
  const expired=blocked&&account.review_reason==='not_authenticated'&&account.status==='login_required';
  const reportedLogout=blocked&&account.review_reason==='manual_signal'&&account.status==='login_required';
  const reauth=expired||reportedLogout;
  const readFailure=blocked&&account.review_reason==='other_risk'&&account.status==='ready';
  return {blocked,verification,reauth,canLogin:!blocked&&account?.status!=='logging_in',label:expired?'电脑登录已失效':reportedLogout?'电脑登录需要更新':verification?(account?.status==='login_required'?'登录验证未完成':'连接需要验证'):readFailure?'采集需要核对':blocked?'等待账号确认':'',
    message:expired?'这台电脑的登录已失效。请先核对手机状态，再在此扫码更新登录。':reportedLogout?'这台电脑当前需要登录。请先核对手机状态，再为此账号重新登录。':verification?(account?.status==='login_required'?'小红书未放行电脑端登录。请查看手机小红书提示和账号记录，核对后检查连接。':'电脑登录已保存，平台要求核对本次请求。请查看手机小红书提示和账号记录，核对后检查连接。'):readFailure?'登录记录仍保留，上次采集未完成。请先查看失败详情，再核对采集状态。':blocked?'请先核实账号和上次操作结果，再确认复核。':'',
    reviewLabel:reauth?'已核对手机，重新扫码登录':'账号已核实，检查连接'};
}
const statusText=account=>account.requires_review?(account.status==='ready'&&account.review_reason==='other_risk'?'采集待核对':'需要确认'):({ready:'已连接',logging_in:'连接中',
  login_required:'需要登录',identity_mismatch:'扫码身份不一致',identity_unverified:'账号身份待核实',
  duplicate_identity:'账号记录重复',duplicate_identity_remote:'企业身份登记冲突',
  identity_cloud_unavailable:'企业身份校验不可用',session_recovery_required:'登录需要恢复'})[account.status]||'状态待核对';
export function accountVisualState(account,status,{loginActive=false,loginInterrupted=false}={}){
  if(account?.requires_review===true||status?.safety_hold===true||status?.state==='held'||loginInterrupted)return 'attention';
  if(['identity_mismatch','duplicate_identity','duplicate_identity_remote'].includes(account?.status))return 'error';
  if(account?.status==='login_required'||account?.status==='session_recovery_required'||account?.status==='identity_unverified')return 'attention';
  if(loginActive||account?.status==='logging_in'||account?.status==='identity_cloud_unavailable'||status?.state!=='online')return 'waiting';
  return account?.status==='ready'?'connected':'waiting';
}
const accountName=account=>String(account.platform_nickname||account.name||'小红书账号');
const validCount=value=>Number.isSafeInteger(value)&&value>=0;
export function safetyView(record){
  const scope=record?.history_scope;
  const complete=validCount(record?.phone_report_count)&&validCount(record?.computer_incident_count)&&
    validCount(record?.phone_report_counts?.unexpected_logout)&&validCount(record?.phone_report_counts?.phone_verification)&&
    Array.isArray(record?.incident_history)&&scope?.days===30&&scope?.timeline_limit===20&&
    validCount(scope?.record_limit)&&typeof scope?.truncated_by_time==='boolean'&&typeof scope?.truncated_by_records==='boolean';
  return {complete:!!complete,phoneCount:complete?record.phone_report_count:null,
    computerCount:complete?record.computer_incident_count:null,
    phoneState:record?.phone_state==='reported_issue'?'已报送手机异常':record?.phone_state==='reviewed'?'已人工复核':'手机状态未确认'};
}
export function shanghaiTime(seconds){
  if(!Number.isFinite(seconds)||seconds<0||seconds>253402300799)return '尚无记录';
  return new Intl.DateTimeFormat('zh-CN',{timeZone:'Asia/Shanghai',year:'numeric',month:'2-digit',day:'2-digit',
    hour:'2-digit',minute:'2-digit',hour12:false}).format(new Date(seconds*1000));
}
const sourceText=source=>({phone_report:'员工报送',computer_http:'电脑请求',computer_cli:'电脑连接',computer_http_cli:'电脑请求与连接'})[source]||'来源待核对';
const gapText=seconds=>Number.isFinite(seconds)&&seconds>0?(seconds>=60?`${new Intl.NumberFormat('zh-CN',{maximumFractionDigits:1}).format(seconds/60)} 分钟`:`${new Intl.NumberFormat('zh-CN',{maximumFractionDigits:1}).format(seconds)} 秒`):'暂无可用间隔';
const sessionRecoveryAvailable=(status,accountId,scope)=>!!accountId&&!!scope&&status?.account_safety_available===true&&status?.session_recovery?.status==='available'&&status.session_recovery.purpose==='session_recovery';
export function accountNextStep(account,status){
  if(status?.safety_hold===true||status?.state==='held'){
    if(status?.session_recovery?.status==='available'&&status.session_recovery.purpose==='session_recovery')return accountRecovery(account).blocked?'请先核实手机与上次操作，再恢复此账号登录。采集仍需核对账号与安全状态。':'可以恢复此账号登录；采集仍需核对账号与安全状态。';
    return '平台操作暂停中；账号记录仍可查看。';
  }
  if(status?.state!=='online'||status?.account_safety_available!==true)return '正在连接工作台，请稍候。';
  const recovery=accountRecovery(account);
  if(recovery.blocked){
    if(account?.review_reason==='not_authenticated')return '电脑登录已失效。核对手机状态后重新扫码。';
    if(account?.review_reason==='manual_signal'&&recovery.reauth)return '手机异常退出。核对手机状态后重新扫码。';
    if(recovery.verification)return '查看手机小红书提示，核实上次操作后检查连接。';
    if(account?.review_reason==='other_risk')return '上次采集未完成。先核对失败详情与采集状态。';
    return '核实账号和上次操作结果后检查连接。';
  }
  if(account?.status==='ready')return '';
  if(account?.status==='logging_in')return '正在核对电脑连接。';
  if(account?.status==='identity_mismatch')return '扫码账号不一致，请核对当前账号。';
  if(account?.status==='identity_unverified')return '账号身份待核实，请核对后再登录。';
  if(['duplicate_identity','duplicate_identity_remote'].includes(account?.status))return '账号身份记录冲突，请先核对账号。';
  if(account?.status==='identity_cloud_unavailable')return '企业身份校验暂不可用，请稍后重试。';
  if(account?.status==='session_recovery_required')return '登录需要恢复，请重新扫码。';
  return '用小红书 App 扫码并确认。';
}

export function identityObservationResult(value){
  if(!value||value.purpose!=='identity_observation'||value.read_only!==true||value.account_ready!==false)throw Error('身份核对结果尚未确认');
  if(value.status==='running')return {running:true};
  if(value.status==='cancelled')return {running:false,message:'身份核对已取消，账号原状态保留。'};
  if(value.status==='failed')return {running:false,message:'身份核对未完成，账号原状态保留。请核实窗口提示后再试。'};
  const identity=value.observed_identity;
  if(value.status!=='completed'||value.pending_manual_review!==true||!identity||identity.guest!==false||
    typeof identity.id!=='string'||!identity.id.length||identity.id.length>160||/[^A-Za-z0-9_-]/u.test(identity.id)||typeof identity.nickname!=='string'||![...identity.nickname].length||[...identity.nickname].length>160||/[\x00-\x1f\x7f]/u.test(identity.nickname)||
    !Number.isFinite(value.observed_at)||value.observed_at<=0||value.observed_at>=253402300800)throw Error('身份核对结果尚未确认');
  return {running:false,message:`身份已读取，待人工核实：${identity.nickname||'小红书账号'}（${identity.id}） · ${shanghaiTime(Math.floor(value.observed_at))}。账号原状态保留。`};
}

const PRIMARY_PLATFORMS=new Set(['xiaohongshu','douyin','wechat_channels']);
const NEW_SLOT_PLATFORMS=new Set(['douyin','wechat_channels']);
const SLOT_PLATFORMS={douyin:'抖音',zhihu:'知乎',wechat_channels:'视频号',bilibili:'哔哩哔哩',kuaishou:'快手',weibo:'微博'};
export function accountSlotResult(value,platform){
  const account=value?.account;
  if(value?.purpose!=='account_slot_create'||value.status!=='created'||value.account_ready!==false||value.credentials_verified!==false||value.platform_requests_started!==false||value.mutation_committed!==true||value.auto_retry!==false||
    !account||typeof account.id!=='string'||!account.id.length||account.id.length>160||account.platform!==platform||account.status!=='login_required'||typeof account.name!=='string'||!account.name.trim()||account.name.length>100)throw Error('账号创建结果未确认，请先核对账号目录。');
  return account;
}

const BILI_STATES=new Set(['observing','pending_confirmation','confirming','saved','failed','cancelled','cleanup_pending']);
export function bilibiliSetupResult(value,accountId,setupId){
  const fields=['platform','purpose','account_id','setup_id','state','observed_uid','nickname','credential_saved','uid_saved','account_ready','cleanup_complete','worker_active','auto_retry','real_platform_verified'];
  if(value?.platform!=='bilibili'||value.purpose!=='owned_credential_setup'||value.account_id!==accountId||value.setup_id!==setupId||!BILI_STATES.has(value.state)||
    value.account_ready!==false||value.auto_retry!==false||value.real_platform_verified!==false||typeof value.cleanup_complete!=='boolean'||typeof value.worker_active!=='boolean'||typeof value.credential_saved!=='boolean'||value.uid_saved!==value.credential_saved||
    typeof value.observed_uid!=='string'||value.observed_uid&&!/^[1-9][0-9]{0,31}$/.test(value.observed_uid)||typeof value.nickname!=='string'||[...value.nickname].length>160||/[\p{Cc}\p{Cs}]/u.test(value.nickname)||
    value.state==='pending_confirmation'&&(!value.observed_uid||value.worker_active||value.credential_saved)||value.state==='saved'&&!value.credential_saved||
    Object.keys(value).some(key=>!fields.includes(key)))throw Error('B站配置回执尚未确认，请核对原编号。');
  return value;
}
const newSetupId=()=>[...globalThis.crypto.getRandomValues(new Uint8Array(16))].map(value=>value.toString(16).padStart(2,'0')).join('');

const DOUYIN_CONNECTION_STATES=new Set(['waiting_login','checking','choose_window','ready','failed','disconnected']);
export function douyinConnectionResult(value,accountId,savedUid=''){
  const fields=['platform','purpose','account_id','state','platform_login_confirmed','binding_verified','owned_window_active','observed_identity','account_ready','platform_read_only','auto_retry'];
  if(value?.platform!=='douyin'||value.purpose!=='douyin_owned_connection'||value.account_id!==accountId||!DOUYIN_CONNECTION_STATES.has(value.state)||
    value.account_ready!==false||value.platform_read_only!==true||value.auto_retry!==false||
    typeof value.platform_login_confirmed!=='boolean'||typeof value.binding_verified!=='boolean'||typeof value.owned_window_active!=='boolean'||
    Object.keys(value).some(key=>!fields.includes(key)))throw Error('抖音本人连接回执尚未确认');
  const identity=value.observed_identity;
  if(value.state==='ready'){
    if(!value.platform_login_confirmed||!value.binding_verified||!value.owned_window_active||!identity||typeof identity!=='object'||Array.isArray(identity)||
      Object.keys(identity).length!==2||typeof identity.uid!=='string'||!/^[0-9]{1,160}$/.test(identity.uid)||/^0+$/.test(identity.uid)||
      typeof identity.nickname!=='string'||[...identity.nickname].length>160||/[\p{Cc}\p{Cs}]/u.test(identity.nickname)||
      savedUid&&String(savedUid)!==identity.uid)throw Error('抖音本人身份回执尚未确认');
  }else if(value.platform_login_confirmed||value.binding_verified||identity!==null||value.state==='disconnected'&&value.owned_window_active)throw Error('抖音本人连接回执尚未确认');
  return value;
}

export function manualPermissionSnapshotResult(value){
  const keys=['purpose','status','reason','permission_snapshot_observed','snapshot_at','platform_actions_allowed','automatic_tasks'];
  if(!value||Object.keys(value).length!==keys.length||Object.keys(value).some(key=>!keys.includes(key))||
    value.purpose!=='manual_owned_read'||value.status!=='held'||value.platform_actions_allowed!==false||value.automatic_tasks!==false||
    value.permission_snapshot_observed!==true||value.reason!=='execution_authority_not_activated'||!Number.isSafeInteger(value.snapshot_at)||value.snapshot_at<0)throw Error('设备权限查询尚未确认，采集和发送保持暂停。');
  return value;
}

const WX_PURPOSE='wechat_channels_single_session_preview';
const wxSignature=account=>JSON.stringify([account.id,account.platform,account.platform_uid,account.conn_id,account.tenant_id,account.cloud_owner,account.requires_review,account.risk_state,account.disabled,account.revoked]);
export function wechatPreviewResult(value,accountId){
  const fields=['platform','purpose','account_id','state','identity_verified','account_isolation','account_ready','platform_read_only','auto_retry','archive_available','external_tool_started'];
  if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length!==fields.length||fields.some(name=>!Object.hasOwn(value,name))||value.platform!=='wechat_channels'||value.purpose!==WX_PURPOSE||value.account_id!==accountId||!['connected_unverified','failed','server_online','disconnected'].includes(value.state)||value.platform_read_only!==true||['identity_verified','account_isolation','account_ready','auto_retry','archive_available','external_tool_started'].some(name=>value[name]!==false))throw Error('视频号预览连接回执尚未确认');
  return value;
}
const wxDescriptor=value=>{const fields=['platform','purpose','status','identity_verified','account_isolation','account_ready','platform_read_only','archive_available','external_tool_started'];return !!value&&typeof value==='object'&&!Array.isArray(value)&&Object.keys(value).length===fields.length&&fields.every(name=>Object.hasOwn(value,name))&&value.platform==='wechat_channels'&&value.purpose===WX_PURPOSE&&value.status==='available'&&value.platform_read_only===true&&['identity_verified','account_isolation','account_ready','archive_available','external_tool_started'].every(name=>value[name]===false);};

export function createPlatformAccount({root,onAccountsChanged=()=>{},onOpenCollection=()=>{},onSessionExpired=()=>{},checkAccount,getScope=()=>'',fetcher=fetch,confirmReview=message=>window.confirm(message)}){
  if(!root)throw Error('缺少小红书账号页面');
  const legacy=root.querySelector('.account-layout');
  if(legacy)legacy.hidden=true;
  const shell=make('section',undefined,'platform-account-shell');
  shell.innerHTML='<div class="platform-account-list" hidden></div><div class="platform-account-detail"></div><div class="platform-account-qr" hidden><div class="platform-account-qr-head"><strong>等待扫码</strong><button type="button" class="text-button platform-account-qr-close">取消</button></div><span class="platform-account-spinner" aria-hidden="true"></span><p class="platform-account-qr-message" role="status" aria-live="polite"></p><img class="platform-account-qr-image" alt="小红书登录二维码" hidden></div><p class="platform-account-alert" role="status" aria-live="polite"></p>';
  root.prepend(shell);
  const toolbar=make('div',undefined,'platform-account-actions');shell.prepend(toolbar);
  const primaryDirectory=make('section',undefined,'platform-account-main-directory upgrade-operation-form');shell.append(primaryDirectory);
  const slotDirectory=make('details',undefined,'platform-account-other');shell.append(slotDirectory);
  const alert=shell.querySelector('.platform-account-alert'),list=shell.querySelector('.platform-account-list'),
    detail=shell.querySelector('.platform-account-detail'),qr=shell.querySelector('.platform-account-qr'),
    qrImage=shell.querySelector('.platform-account-qr-image'),qrMessage=shell.querySelector('.platform-account-qr-message');
  let accounts=[],allAccounts=[],status=null,selectedId='',safety=null,safetyId='',revision=0,loginJob='',loginMode='qr',pollTimer=0,refreshSerial=0,busy=false,accountsLoaded=false,loading=false,loadError='',reportMenuOpen=false,timelineOpen=false,auditOpen=false,recordOpen=false,adviceOpen=false,flowStage=0,loginInterrupted=false;
  let viewEpoch=0,loginEpoch=0,loginAttempt=null;
  let slotCapabilities=null,slotOpen=false,slotPlatform='douyin',slotName='',slotReviewRequired=false;
  let biliSetup=null,biliEpoch=0,biliSerial=0;
  let dyConnection=null,dyEpoch=0,dySnapshotScope='';
  let wxConnection=null,wxEpoch=0,wxSnapshotScope='';
  let manualQuery=null,manualMessage='',manualMessageScope='';
  const scopeValue=()=>{try{const value=getScope();return typeof value==='string'?value:'';}catch{return '';}};
  const viewToken=(accountId='')=>({viewEpoch,scope:scopeValue(),accountId});
  const viewCurrent=token=>token.viewEpoch===viewEpoch&&token.scope===scopeValue()&&(!token.accountId||(token.accountId===selectedId&&accounts.some(item=>item.id===token.accountId)));
  const scopedCall=async(token,action,data)=>{
    try{return await localAssistantCall(action,data,fetcher);}
    catch(error){if(error.sessionExpired&&viewCurrent(token))onSessionExpired(error);throw error;}
  };
  const call=(action,data)=>scopedCall(viewToken(),action,data);
  const manualAvailable=()=>!!scopeValue()&&status?.startup_mode==='manual_owned_read'&&status.manual_read?.status==='held'&&
    status.manual_read.platform_actions_allowed===false&&status.manual_read.automatic_tasks===false&&status.manual_read.automatic_analysis===false&&status.manual_read.contact_sync===false;
  const manualCurrent=attempt=>manualQuery===attempt&&viewCurrent(attempt.token)&&manualAvailable();
  function expireManualQuery(){if(manualQuery&&!manualCurrent(manualQuery))manualQuery=null;if(manualMessageScope!==scopeValue()||status?.startup_mode!=='manual_owned_read'){manualMessage='';manualMessageScope='';}}
  async function requestManualSnapshot(){
    expireManualQuery();if(manualQuery||loading||!manualAvailable())return;
    const attempt={token:viewToken()};manualQuery=attempt;manualMessage='';manualMessageScope=attempt.token.scope;renderAccounts();renderDetail();
    try{
      const value=await scopedCall(attempt.token,'assistant_manual_permission_snapshot',{});
      if(!manualCurrent(attempt))return;manualPermissionSnapshotResult(value);
      await refresh();if(!manualCurrent(attempt))return;
      manualMessage=status.manual_read.permission_snapshot_observed===true?'本次设备权限已读取，执行权限尚未启用。':'设备权限查询尚未确认，采集和发送保持暂停。';
    }catch(error){if(manualCurrent(attempt))manualMessage='设备权限查询尚未确认，采集和发送保持暂停。';}
    finally{if(manualCurrent(attempt)){manualQuery=null;renderAccounts();renderDetail();}}
  }

  const loginCurrent=attempt=>!!attempt&&attempt===loginAttempt&&attempt.epoch===loginEpoch&&viewCurrent(attempt);
  const loginCall=async(attempt,action,data)=>{
    try{return await localAssistantCall(action,data,fetcher);}
    catch(error){if(error.sessionExpired&&loginCurrent(attempt))onSessionExpired(error);throw error;}
  };
  function clearLogin(){stopPolling();loginEpoch++;loginAttempt=null;loginJob='';}
  function expireLoginScope(){if(loginAttempt&&!loginCurrent(loginAttempt)){clearLogin();busy=false;qr.hidden=true;qrImage.hidden=true;qrImage.removeAttribute('src');}}
  let identityAttempt=null,identityOutcome=null,identityEpoch=0,identityTimer=0;
  const identityScope=()=>{try{const value=getScope();return typeof value==='string'?value:'';}catch{return '';}};
  const identityCurrent=attempt=>!!attempt&&attempt===identityAttempt&&attempt.epoch===identityEpoch&&
    !!attempt.scope&&attempt.scope===identityScope()&&attempt.accountId===selectedId&&accounts.some(item=>item.id===attempt.accountId);
  function clearIdentity(){clearTimeout(identityTimer);identityTimer=0;identityEpoch++;identityAttempt=null;identityOutcome=null;}
  function expireIdentityScope(){
    const value=identityAttempt||identityOutcome;
    if(value&&(value.scope!==identityScope()||value.accountId!==selectedId||!accounts.some(item=>item.id===value.accountId)))clearIdentity();
  }
  const identityAllowed=()=>!!identityScope()&&status?.identity_observation?.status==='available'&&
    status.identity_observation.purpose==='identity_observation'&&status.identity_observation.read_only===true&&status.identity_observation.account_ready===false;
  const identityCall=async(attempt,action,data)=>{
    try{return await localAssistantCall(action,data,fetcher);}
    catch(error){if(error.sessionExpired&&identityCurrent(attempt))onSessionExpired(error);throw error;}
  };
  let messageKind='';
  const message=(text,error=false,kind='action')=>{messageKind=kind;alert.textContent=text||'';alert.classList.toggle('is-error',error);};
  const legacyLoginAllowed=()=>status?.state==='online'&&status?.safety_hold!==true&&status?.account_safety_available===true;
  const loginAllowed=(accountId='')=>legacyLoginAllowed()||sessionRecoveryAvailable(status,accountId,scopeValue());
  const biliCurrent=entry=>!!entry&&entry===biliSetup&&entry.epoch===biliEpoch&&entry.scope===scopeValue()&&allAccounts.some(item=>item.id===entry.account_id&&item.platform==='bilibili');
  const biliAvailable=()=>false; // New B站 setup is outside this round; original status/cancel remain available.
  const biliOccupied=()=>!!biliSetup&&(biliSetup.requestPending||biliSetup.state!=='input'&&!(biliSetup.cleanup_complete===true&&biliSetup.worker_active===false&&['saved','failed','cancelled'].includes(biliSetup.state)));
  function expireBiliScope(){if(biliSetup&&!biliCurrent(biliSetup)){biliEpoch++;biliSerial++;biliSetup=null;}}
  const dyCurrent=entry=>!!entry&&entry===dyConnection&&entry.epoch===dyEpoch&&entry.viewEpoch===viewEpoch&&entry.scope===scopeValue()&&allAccounts.some(item=>item.id===entry.account_id&&item.platform==='douyin');
  const dyAvailable=()=>!!scopeValue()&&dySnapshotScope===scopeValue()&&status?.douyin_connection?.platform==='douyin'&&status.douyin_connection.purpose==='douyin_owned_connection'&&status.douyin_connection.status==='available'&&status.douyin_connection.account_ready===false&&status.douyin_connection.platform_read_only===true;
  const dyAccountAllowed=account=>!!account&&account.platform==='douyin'&&(account.requires_review==null||account.requires_review===false)&&(account.risk_state==null||['','normal','safe'].includes(account.risk_state));
  function expireDyScope(){if(dyConnection&&!dyCurrent(dyConnection)){dyEpoch++;dyConnection=null;}}
  const wxAccountAllowed=account=>!!account&&account.platform==='wechat_channels'&&account.disabled!==true&&account.revoked!==true&&!['disabled','session_recovery_required'].includes(account.status)&&(account.requires_review==null||account.requires_review===false)&&(account.risk_state==null||['','normal','safe'].includes(account.risk_state));
  const wxCurrent=entry=>!!entry&&entry===wxConnection&&entry.epoch===wxEpoch&&entry.viewEpoch===viewEpoch&&!!entry.scope&&entry.scope===scopeValue()&&allAccounts.some(item=>item.id===entry.account_id&&item.platform==='wechat_channels'&&wxSignature(item)===entry.signature);
  const wxAvailable=()=>!!scopeValue()&&wxSnapshotScope===scopeValue()&&status?.state==='online'&&status?.safety_hold!==true&&wxDescriptor(status?.wechat_preview);
  function expireWxScope(){if(wxConnection&&!wxCurrent(wxConnection)){wxEpoch++;wxConnection=null;}}
  const accountBusy=()=>!!wxConnection?.requestPending||!!manualQuery||!!dyConnection?.requestPending||biliOccupied()||busy||!!loginJob||!!identityAttempt||accounts.some(item=>item.status==='logging_in');
  const browserLogin=()=>status?.login_method==='browser';
  const reviewAllowed=()=>['online','held'].includes(status?.state)&&status?.account_safety_available===true;
  function stopPolling(){clearTimeout(pollTimer);pollTimer=0;}
  function reset(){wxEpoch++;wxConnection=null;wxSnapshotScope='';manualQuery=null;manualMessage='';manualMessageScope='';dyEpoch++;dyConnection=null;dySnapshotScope='' ;biliEpoch++;biliSerial++;biliSetup=null;viewEpoch++;clearIdentity();clearLogin();refreshSerial++;revision++;loginMode='qr';accounts=[];allAccounts=[];status=null;slotCapabilities=null;slotOpen=false;slotPlatform='douyin';slotName='';slotReviewRequired=false;slotDirectory.replaceChildren();primaryDirectory.replaceChildren();selectedId='';safety=null;safetyId='';busy=false;accountsLoaded=false;loading=false;loadError='';reportMenuOpen=false;timelineOpen=false;auditOpen=false;recordOpen=false;adviceOpen=false;flowStage=0;loginInterrupted=false;shell.removeAttribute('data-tone');shell.classList.toggle('is-connected',false);shell.classList.toggle('is-login-active',false);toolbar.replaceChildren();list.replaceChildren();detail.replaceChildren();qr.hidden=true;qrImage.hidden=true;qrImage.removeAttribute('src');message('');}
  function renderActions(){
    expireManualQuery();toolbar.replaceChildren();
    if(status?.startup_mode==='manual_owned_read'){
      const note=make('p',manualMessage||'手动核对模式：原任务保持原样，采集和发送暂停。','platform-account-manual-note');note.setAttribute('role','status');note.setAttribute('aria-live','polite');toolbar.append(note);
      const check=make('button',manualQuery?'正在核对…':'核对设备权限','secondary platform-account-permission-check');check.type='button';check.disabled=loading||!!manualQuery||!manualAvailable();
      check.addEventListener('click',()=>void requestManualSnapshot());toolbar.append(check);
    }
    const add=make('button','添加小红书账号','secondary platform-account-new');add.type='button';add.hidden=!accounts.length;add.disabled=!accountsLoaded||!loginAllowed()||accountBusy();
    add.addEventListener('click',()=>void beginLogin());toolbar.append(add);
    const retry=make('button',loading?'正在刷新…':loadError?'重试读取账号':'刷新账号','secondary platform-account-refresh');retry.type='button';retry.disabled=loading||accountBusy();
    retry.addEventListener('click',()=>void refresh().catch(()=>{}));toolbar.append(retry);
  }
  function renderAccounts(){
    expireWxScope();expireDyScope();
    expireBiliScope();
    expireManualQuery();expireLoginScope();expireIdentityScope();shell.setAttribute('aria-busy',String(accountBusy()));list.replaceChildren();list.hidden=!accounts.length;
    for(const account of accounts){
      const action=make('button',undefined,'secondary platform-account-switch');action.type='button';action.disabled=accountBusy();
      action.append(make('strong',accountName(account)),make('span',statusText(account),'platform-account-switch-state'));
      action.setAttribute('aria-pressed',String(account.id===selectedId));
      action.addEventListener('click',()=>void selectAccount(account.id));list.append(action);
    }
    renderActions();renderSlotDirectory();
    if(messageKind==='state')message('');
  }
  function slotAllowed(){return !!scopeValue()&&accountsLoaded&&slotCapabilities?.canCreateAccountSlot===true&&slotCapabilities.canAddAccount===true&&Array.isArray(slotCapabilities.platforms);}
  function renderSlotDirectory(){
    primaryDirectory.replaceChildren();slotDirectory.replaceChildren();slotDirectory.open=slotOpen;
    const directoryToken=viewToken(),directoryCurrent=()=>viewCurrent(directoryToken);
    primaryDirectory.append(make('h3','主平台 · 小红书 / 抖音 / 视频号'),make('p','小红书为当前重点；抖音和视频号为次重点。先添加账号，再完成登录；是否能采集会单独显示。','upgrade-muted'));
    const rows=allAccounts.filter(item=>!PRIMARY_PLATFORMS.has(item.platform)),main=allAccounts.filter(item=>NEW_SLOT_PLATFORMS.has(item.platform));
    slotDirectory.append(make('summary',`其他已有账号 · ${rows.length}`));
    const history=make('section',undefined,'upgrade-operation-form');slotDirectory.append(history);
    history.append(make('p','知乎、B站、微博退出本轮新建和读取入口，快手仅保留演示。原账号记录、登录与风险状态均保留；本轮不开发这些平台。','upgrade-muted'));
    const record=(host,account)=>{
      const label=SLOT_PLATFORMS[account.platform]||account.platform;
      host.append(make('p',`${label} · ${String(account.name||'未命名账号')} · 原记录状态：${String(account.status||'unknown')} · ${account.requires_review===true?'需要人工核对':'复核标记按原记录保留'}${account.risk_state?` · 风险记录：${String(account.risk_state)}`:''}`));
    };
    for(const account of rows){
      record(history,account);
      if(account.platform==='bilibili'&&biliSetup?.account_id===account.id){
        history.append(make('p','本次原配置仅可核对结果或取消清理，不能新读身份或确认保存。','upgrade-muted'));renderBiliSetup(history);
      }
    }
    if(!rows.length)history.append(make('p','没有其他平台的已有账号记录。','upgrade-muted'));
    for(const account of main){
      record(primaryDirectory,account);
      if(account.platform==='wechat_channels'){
        const open=make('button','配置视频号预览','secondary platform-account-wx-open');open.type='button';open.disabled=accountBusy()||loading||!wxAvailable()||!wxAccountAllowed(account)||wxConnection?.state==='unknown';
        open.addEventListener('click',()=>{const current=allAccounts.find(item=>item.id===account.id&&item.platform==='wechat_channels');if(!directoryCurrent()||accountBusy()||loading||!wxAvailable()||!wxAccountAllowed(current)||wxConnection?.state==='unknown')return;wxEpoch++;wxConnection={account_id:account.id,scope:scopeValue(),viewEpoch,epoch:wxEpoch,signature:wxSignature(current),state:'input',port:'2026',requestPending:false,result:null};renderAccounts();});primaryDirectory.append(open);
        if(wxConnection?.account_id===account.id)renderWechatPreview(primaryDirectory);
        else primaryDirectory.append(make('small','仅本人本机127.0.0.1单页面预览；连接身份未核，不保存客户或分析意向。入口不可用时先刷新账号与设备状态。','upgrade-muted'));
      }
      if(account.platform==='douyin'){
        const configure=make('button','配置本人抖音连接','secondary platform-account-dy-configure');configure.type='button';configure.disabled=accountBusy()||loading||!dyAvailable()||!dyAccountAllowed(account)||dyConnection?.state==='unknown';
        configure.addEventListener('click',()=>{if(!directoryCurrent()||accountBusy()||loading||!dyAvailable()||!dyAccountAllowed(allAccounts.find(item=>item.id===account.id))||dyConnection?.state==='unknown')return;dyEpoch++;dyConnection={account_id:account.id,scope:scopeValue(),viewEpoch,epoch:dyEpoch,state:'input',requestPending:false,result:null};renderAccounts();});primaryDirectory.append(configure);
        if(dyConnection?.account_id===account.id)renderDyConnection(primaryDirectory);
      }
    }
    if(!main.length)primaryDirectory.append(make('p','尚未添加抖音或视频号账号。','upgrade-muted'));
    primaryDirectory.append(make('p','添加后还需完成本人账号连接；是否能采集会单独显示。视频号仅配置本机预览，不新增平台登录、可靠本人身份或采集资格。','upgrade-muted'));
    const form=make('form',undefined,'upgrade-operation-form'),platformLabel=make('label','添加主平台账号'),platform=make('select'),nameLabel=make('label','账号备注'),name=make('input');
    platform.name='account_slot_platform';name.name='account_slot_name';name.maxLength=100;name.value=slotName;name.autocomplete='off';
    const allowed=Array.isArray(slotCapabilities?.platforms)?slotCapabilities.platforms.filter(value=>NEW_SLOT_PLATFORMS.has(value)):[];
    if(!allowed.includes(slotPlatform))slotPlatform=allowed[0]||'';
    for(const key of allowed){const option=make('option',SLOT_PLATFORMS[key]);option.value=key;platform.append(option);}platform.value=slotPlatform;
    const disabled=accountBusy()||loading||!slotAllowed()||slotReviewRequired||!allowed.length;platform.disabled=name.disabled=disabled;
    platform.addEventListener('change',()=>{if(!directoryCurrent())return;slotPlatform=allowed.includes(platform.value)?platform.value:allowed[0]||'';platform.value=slotPlatform;});name.addEventListener('input',()=>{if(directoryCurrent())slotName=name.value;});
    platformLabel.append(platform);nameLabel.append(name);form.append(platformLabel,nameLabel);
    const submit=make('button','添加平台账号','secondary platform-account-slot-create');submit.type='submit';submit.disabled=disabled;form.append(submit);
    form.addEventListener('submit',event=>{event.preventDefault();if(directoryCurrent())void createSlot(platform.value,name.value);});primaryDirectory.append(form);
    if(slotReviewRequired){
      primaryDirectory.append(make('p','上次创建结果未确认。先刷新账号，核对目录；确认需要新账号后再解除本次等待。','upgrade-muted'));
      const release=make('button','已核对目录，准备添加新账号','secondary platform-account-slot-reviewed');release.type='button';release.disabled=accountBusy()||loading||!accountsLoaded||!!loadError;
      release.addEventListener('click',()=>{if(!directoryCurrent())return;slotReviewRequired=false;renderSlotDirectory();});primaryDirectory.append(release);
    }else if(!slotAllowed()||!allowed.length)primaryDirectory.append(make('p',accountsLoaded?'当前主平台创建权限或剩余席位尚未开放。':'请先刷新账号目录。','upgrade-muted'));
    const demo=make('section',undefined,'upgrade-operation-form platform-account-kuaishou-demo');primaryDirectory.append(demo);
    demo.append(make('h4','快手 · 演示预留 / 未接真实账号'),make('p','未接真实账号：仅查看固定本地演示样例，不连接平台、不采集实际数据，不保存客户或发送消息。','upgrade-muted'));
    const show=make('button','查看快手演示样例','secondary platform-account-kuaishou-demo-open');show.type='button';demo.append(show);
    const samples=make('section',undefined,'platform-account-kuaishou-demo-samples');samples.hidden=true;demo.append(samples);const token=viewToken();
    show.addEventListener('click',()=>{if(!viewCurrent(token))return;samples.hidden=!samples.hidden;show.textContent=samples.hidden?'查看快手演示样例':'收起演示样例';samples.replaceChildren();if(!samples.hidden)samples.append(make('p','演示样例 · 非真实客户 / 非平台返回'),make('p','[演示样例] 作品：公寓看房流程介绍；评论：想了解房型和看房安排。'),make('p','演示流程：选择范围 → 预览样例 → 人工核对；账号连接、真实读取、客户保存和发送均待接入。','upgrade-muted'));});
  }
  function renderBiliSetup(host){
    const entry=biliSetup;if(!biliCurrent(entry))return;
    const section=make('section',undefined,'upgrade-operation-form platform-account-bili-setup');host.append(section);
    section.append(make('h3','B站本人配置 · 高级配置'),make('p','本机配置本人连接。先核对平台返回的本人身份，再明确确认保存；保存不等于可以采集。','upgrade-muted'));
    if(entry.state==='input'){
      const form=make('form'),label=make('label','本人 Cookie JSON'),input=make('textarea');input.name='bilibili_owned_credential';input.autocomplete='off';input.spellcheck=false;input.maxLength=65536;label.append(input);form.append(label);
      const submit=make('button','读取本人身份','secondary platform-account-bili-observe');submit.type='submit';submit.disabled=!biliAvailable()||entry.requestPending;form.append(submit);section.append(form);
      form.addEventListener('submit',event=>{event.preventDefault();if(!biliCurrent(entry)||entry.requestPending||!biliAvailable())return;
        let credential;try{
          credential=JSON.parse(input.value);const keys=['SESSDATA','bili_jct','DedeUserID','DedeUserID__ckMd5','sid','buvid3','buvid4'];
          if(!credential||Array.isArray(credential)||typeof credential!=='object'||!credential.SESSDATA||Object.keys(credential).some(key=>!keys.includes(key))||Object.values(credential).some(value=>typeof value!=='string'||!value.length||value.length>8192||/[^\x21-\x7e]|[;,]/.test(value))||new TextEncoder().encode(JSON.stringify(credential)).length>65536)throw Error();
        }catch{entry.message='请填写本人 B站 Cookie JSON，包含 SESSDATA；内容格式未通过，尚未提交。';renderBiliSetupMessage(section,entry);return;}
        input.value='';void biliRequest(entry,'observe',{account_id:entry.account_id,setup_id:entry.setup_id,credential});credential=null;
      });
    }else{
      section.append(make('p',`本次配置编号：${entry.setup_id}`,'upgrade-muted'));
      if(entry.observed_uid)section.append(make('p',`平台本人身份：${entry.nickname||'B站用户'} · UID ${entry.observed_uid}`));
      if(entry.state==='pending_confirmation'){
        const confirm=make('button','确认这是本人账号并保存','secondary platform-account-bili-confirm');confirm.type='button';confirm.disabled=entry.requestPending||!biliAvailable();
        confirm.addEventListener('click',()=>void biliRequest(entry,'confirm',{account_id:entry.account_id,setup_id:entry.setup_id,observed_uid:entry.observed_uid,confirmed:true}));section.append(confirm);
      }
      const check=make('button','核对原配置结果','secondary platform-account-bili-status');check.type='button';check.addEventListener('click',()=>void biliRequest(entry,'status',{account_id:entry.account_id,setup_id:entry.setup_id}));section.append(check);
      if(!(entry.cleanup_complete===true&&entry.worker_active===false&&['saved','failed','cancelled'].includes(entry.state))){
        const cancel=make('button','取消并清理本次配置','secondary platform-account-bili-cancel');cancel.type='button';cancel.addEventListener('click',()=>void biliRequest(entry,'cancel',{account_id:entry.account_id,setup_id:entry.setup_id}));section.append(cancel);
      }
    }
    renderBiliSetupMessage(section,entry);
    const close=make('button','返回账号目录','secondary platform-account-bili-close');close.type='button';close.disabled=entry.requestPending||entry.state!=='input'&&!(entry.cleanup_complete===true&&entry.worker_active===false&&['saved','failed','cancelled'].includes(entry.state));
    close.addEventListener('click',()=>{if(!biliCurrent(entry)||close.disabled)return;biliEpoch++;biliSerial++;biliSetup=null;renderAccounts();});section.append(close);
  }
  function renderBiliSetupMessage(host,entry){
    let label=host.querySelector('.platform-account-bili-message');if(!label){label=make('p',undefined,'platform-account-bili-message');label.setAttribute('role','status');label.setAttribute('aria-live','polite');host.append(label);}label.textContent=entry.message||'';
  }
  async function biliRequest(entry,operation,data){
    if(!biliCurrent(entry)||!['observe','confirm','status','cancel'].includes(operation)||['observe','confirm'].includes(operation)&&(entry.requestPending||!biliAvailable()))return;
    const serial=++biliSerial,token=viewToken();entry.requestPending=true;entry.message=operation==='observe'?'正在读取本人身份…':operation==='confirm'?'正在再次核对本人身份并保存…':operation==='cancel'?'正在取消并清理…':'正在核对原结果…';
    if(operation==='observe')entry.state='observing';renderAccounts();renderDetail();
    try{
      const result=await scopedCall(token,`assistant_bilibili_setup_${operation}`,data);
      if(!biliCurrent(entry)||serial!==biliSerial)return;
      Object.assign(entry,bilibiliSetupResult(result,entry.account_id,entry.setup_id));
      entry.message=entry.credential_saved?(entry.cleanup_complete?'本人凭据与 UID 已保存。账号和采集状态仍须分别核对。':'本人凭据与 UID 已保存，清理仍待核对。'):entry.state==='pending_confirmation'?'身份已读取。请核对 UID 和昵称，确认本人后保存。':entry.state==='cancelled'?'本次配置已取消；原账号记录保留。':entry.state==='failed'?'本次配置未完成；请核对原账号和结果。':'操作或清理仍在进行，请核对原编号。';
      if(entry.credential_saved)await refresh().catch(()=>{});
    }catch{if(biliCurrent(entry)&&serial===biliSerial)entry.message='配置结果未确认。仅核对或取消同一原编号；不会自动重新提交。';}
    finally{if(biliCurrent(entry)&&serial===biliSerial){entry.requestPending=false;renderAccounts();renderDetail();}}
  }
  slotDirectory.addEventListener('toggle',()=>{slotOpen=slotDirectory.open;});
  function renderDyConnection(panel){
    const entry=dyConnection,box=make('section',undefined,'platform-account-dy-connection upgrade-operation-form');panel.append(box);
    const allowed=dyAccountAllowed(allAccounts.find(item=>item.id===entry.account_id));
    box.append(make('h4','本人抖音连接'),make('p','账号记录是一个槽位。连接会使用本人的独立窗口；连接不等于平台已登录，也不代表可采集。','upgrade-muted'));
    const texts={input:'先打开本人抖音窗口，在该窗口登录，再点击检查。',waiting_login:'请在本人抖音窗口完成登录，再显式检查本人登录身份。',checking:'本次身份检查尚未完成，请等待页面加载后再检查。',choose_window:'尚未唯一绑定本人窗口。请在本人窗口核对页面后重新检查，不能手填连接编号。',failed:'本次连接或身份核对未通过。账号风险记录保留，请核对原窗口后检查。',disconnected:'本人窗口已断开。需要重新连接时，请显式打开本人抖音窗口。',unknown:'连接结果尚未确认。请检查同一账号的现有连接；不会自动重新打开窗口。'};
    if(entry.state==='ready')box.append(make('p',`本人登录身份已核对：${entry.result.observed_identity.nickname||'抖音账号'}（${entry.result.observed_identity.uid}）。本次只读事实不代表可采集；请到读取页核对权限与实际状态。`));
    else box.append(make('p',texts[entry.state]||texts.unknown));
    const start=make('button',entry.requestPending?'正在核对…':'打开本人抖音窗口','secondary platform-account-dy-start');start.type='button';start.disabled=accountBusy()||loading||!dyAvailable()||!allowed||!['input','disconnected'].includes(entry.state);
    start.addEventListener('click',()=>void requestDyConnection(entry,'assistant_douyin_connection_start'));box.append(start);
    const check=make('button','检查本人登录身份','secondary platform-account-dy-status');check.type='button';check.disabled=accountBusy()||loading||!dyAvailable()||!allowed;
    check.addEventListener('click',()=>void requestDyConnection(entry,'assistant_douyin_connection_status'));box.append(check);
    const close=make('button','收起连接面板','secondary platform-account-dy-close');close.type='button';close.disabled=entry.requestPending||entry.state==='unknown';
    close.addEventListener('click',()=>{if(!dyCurrent(entry)||entry.requestPending||entry.state==='unknown')return;dyEpoch++;dyConnection=null;renderAccounts();});box.append(close);
    box.append(make('small','收起只隐藏此面板，不会关闭平台窗口。连接与身份核对不会自动采集、发信或清除风险。','upgrade-muted'));
  }
  async function requestDyConnection(entry,action){
    expireDyScope();if(!dyCurrent(entry)||accountBusy()||loading||!dyAvailable()||!dyAccountAllowed(allAccounts.find(item=>item.id===entry.account_id))||action==='assistant_douyin_connection_start'&&!['input','disconnected'].includes(entry.state))return;
    entry.requestPending=true;renderAccounts();
    try{
      const value=await localAssistantCall(action,{account_id:entry.account_id},fetcher);if(!dyCurrent(entry))return;
      const account=allAccounts.find(item=>item.id===entry.account_id&&item.platform==='douyin');
      entry.result=douyinConnectionResult(value,entry.account_id,account?.platform_uid||'');entry.state=entry.result.state;
      await refresh();
    }catch(error){if(!dyCurrent(entry))return;entry.result=null;entry.state='unknown';if(error.sessionExpired)onSessionExpired(error);}
    finally{if(dyCurrent(entry)){entry.requestPending=false;renderAccounts();renderDetail();}}
  }
  function renderWechatPreview(host){
    const entry=wxConnection;if(!wxCurrent(entry))return;
    const box=make('section',undefined,'upgrade-operation-form platform-account-wx-preview');host.append(box);
    box.append(make('h3','视频号 · 本机单页面预览'),make('p','本机地址固定127.0.0.1，默认端口2026。由本人自行运行外部工具；工作台不安装、启动工具，不安装证书或改变代理。此连接只绑定当前页面，身份与账号隔离均未核实。','upgrade-muted'));
    const labels={input:'请明确配置或检查本机连接。',connected_unverified:'本机页面已连接，身份未核；仅预览，不可保存客户或分析意向。',server_online:'本机服务有响应，页面或读取能力仍待核对。',failed:'本机页面核对未完成，原风险与身份记录保留。',disconnected:'未确认本机页面连接，请核对本人外部工具。',unknown:'原配置结果待核对；请检查同一原账号，不自动重新配置。'};
    box.append(make('p',labels[entry.state]||labels.unknown));
    const label=make('label','本机端口（1024–65535）'),port=make('input');port.name='wechat_preview_port';port.type='number';port.min='1024';port.max='65535';port.step='1';port.value=entry.port;port.disabled=accountBusy()||loading||entry.state==='unknown';label.append(port);box.append(label);
    port.addEventListener('input',()=>{if(wxCurrent(entry)&&!entry.requestPending&&entry.state!=='unknown')entry.port=port.value;});
    const configure=make('button','保存端口并检查预览','secondary platform-account-wx-configure');configure.type='button';configure.disabled=accountBusy()||loading||!wxAvailable()||!wxAccountAllowed(allAccounts.find(item=>item.id===entry.account_id))||entry.state==='unknown';
    configure.addEventListener('click',()=>void requestWechatPreview(entry,'configure'));box.append(configure);
    const check=make('button','检查原账号本机预览','secondary platform-account-wx-check');check.type='button';check.disabled=accountBusy()||loading||!wxAvailable()||!wxAccountAllowed(allAccounts.find(item=>item.id===entry.account_id));check.addEventListener('click',()=>void requestWechatPreview(entry,'check'));box.append(check);
    const close=make('button','收起预览配置','secondary platform-account-wx-close');close.type='button';close.disabled=entry.requestPending||entry.state==='unknown';close.addEventListener('click',()=>{if(!wxCurrent(entry)||entry.requestPending||entry.state==='unknown')return;wxEpoch++;wxConnection=null;renderAccounts();});box.append(close);
    box.append(make('small','检查会请求本机服务并可能更新临时连接状态；不核实微信本人UID、登录成功或商业二进制许可。确认连接后，到主平台读取页明确读取一页，最多20条。','upgrade-muted'));
  }
  async function requestWechatPreview(entry,operation){
    expireWxScope();if(!wxCurrent(entry)||accountBusy()||loading||!wxAvailable()||!wxAccountAllowed(allAccounts.find(item=>item.id===entry.account_id))||operation==='configure'&&entry.state==='unknown')return;
    let data={account_id:entry.account_id};
    if(operation==='configure'){if(!/^\d+$/.test(entry.port)||!Number.isSafeInteger(Number(entry.port))||Number(entry.port)<1024||Number(entry.port)>65535){message('本机端口须为1024–65535的整数。',true);return;}data.port=Number(entry.port);}
    entry.requestPending=true;entry.result=null;renderAccounts();const token=viewToken();
    try{
      const value=await scopedCall(token,'assistant_wechat_preview_'+operation,data);if(!wxCurrent(entry))return;
      const result=wechatPreviewResult(value,entry.account_id);await refresh();if(!wxCurrent(entry))return;
      entry.result=result;entry.state=result.state;
    }catch(error){if(wxCurrent(entry)){entry.result=null;entry.state='unknown';}}
    finally{if(wxCurrent(entry)){entry.requestPending=false;renderAccounts();renderDetail();}}
  }
  async function createSlot(platform,name){
    if(accountBusy()||loading||!slotAllowed()||slotReviewRequired||!slotCapabilities.platforms.includes(platform)||!NEW_SLOT_PLATFORMS.has(platform))return;
    const value=typeof name==='string'?name.trim():'';
    if(!value||value.length>100||/[\p{Cc}\p{Cs}]/u.test(value)){message('请填写 1–100 字的账号备注。',true);return;}
    const token=viewToken();slotPlatform=platform;slotName=value;busy=true;renderAccounts();renderDetail();message('正在添加账号…');
    try{
      const result=await scopedCall(token,'assistant_account_slot_create',{platform,name:value});if(!viewCurrent(token))return;
      const saved=accountSlotResult(result,platform);slotName='';await refresh();if(!viewCurrent(token))return;
      if(!allAccounts.some(item=>item.id===saved.id&&item.platform===platform))throw Error('账号已保存，目录仍待核对。请刷新账号。');
      message(`${SLOT_PLATFORMS[platform]}账号已添加，尚未登录。请配置本人连接后核对读取状态。`);
    }catch(error){
      if(!viewCurrent(token))return;slotReviewRequired=true;
      message(error.message||'创建结果未确认，请先刷新并核对账号目录；不会自动重试。',true);await refresh().catch(()=>{});
    }finally{if(viewCurrent(token)){busy=false;renderAccounts();renderDetail();}}
  }
  function renderDetail(){
    expireManualQuery();expireLoginScope();expireIdentityScope();detail.replaceChildren();const account=accounts.find(item=>item.id===selectedId)||{id:'',name:'小红书账号',status:'login_required'};
    detail.hidden=false;
    if(!accountsLoaded&&!accounts.length){
      detail.append(make('p',loadError?'账号读取失败，请点击“重试读取账号”。':loading?'正在读取账号…':'点击“刷新账号”读取账号。','platform-account-loading'));
      return;
    }
    const record=safetyId===account.id?safety:null,view=safetyView(record),recovery=accountRecovery(account);
    const heading=make('div',undefined,'platform-account-detail-head');
    const avatar=make('img',undefined,'platform-account-avatar');avatar.alt='';avatar.referrerPolicy='no-referrer';avatar.onerror=()=>{avatar.onerror=null;avatar.src='?asset=fy-icon-16-user.png';};avatar.src=safeXhsImageUrl(account.platform_avatar_url)||'?asset=fy-icon-16-user.png';
    const title=make('div',undefined,'platform-account-detail-title');title.append(make('h3',accountName(account)),make('span',loginJob?(loginInterrupted?'连接中断':flowStage===1?'正在核对':'等待扫码'):recovery.label||statusText(account),'platform-account-state'));
    heading.append(avatar,title);detail.append(heading);
    const connected=account.status==='ready'&&!recovery.blocked&&!loginJob;
    const visualState=accountVisualState(account,status,{loginActive:!!loginJob||busy&&!qr.hidden,loginInterrupted});
    shell.setAttribute('data-tone',visualState);
    shell.classList.toggle('is-connected',visualState==='connected');shell.classList.toggle('is-login-active',!loginInterrupted&&(!!loginJob||busy&&!qr.hidden));
    const intro=make('div',undefined,'platform-account-intro');
    const nextStep=accountNextStep(account,status);intro.hidden=!qr.hidden||!nextStep;
    if(nextStep)intro.append(make('p',nextStep));
    detail.append(intro);
    const primary=make('button',connected?'去采集':recovery.reauth?'核实后重登':recovery.blocked?'核实后检查':account.status==='logging_in'?'正在连接…':'登录小红书','platform-account-primary');primary.type='button';
    primary.disabled=accountBusy()||(connected?!legacyLoginAllowed():recovery.blocked?!reviewAllowed()||safetyId!==account.id:!loginAllowed(account.id));
    primary.hidden=!!loginJob||busy&&!qr.hidden;
    primary.addEventListener('click',()=>connected?onOpenCollection():recovery.blocked?void completeReview(account.id,browserLogin()&&loginAllowed(account.id)):void beginLogin(account.id));
    detail.append(primary);
    if(account.id)renderIdentity(account);
    const audit=make('details',undefined,'platform-account-audit');audit.open=auditOpen;
    const auditSummary=make('summary');auditSummary.setAttribute('aria-label','更多账号操作');auditSummary.title='更多账号操作';
    const moreIcon=make('img');moreIcon.src='?asset=fy-icon-64-more.png';moreIcon.alt='';moreIcon.setAttribute('aria-hidden','true');auditSummary.append(moreIcon);audit.append(auditSummary);
    audit.addEventListener('toggle',()=>{auditOpen=audit.open;});
    const panel=make('div',undefined,'platform-account-more-panel');
    audit.addEventListener('keydown',event=>{
      if(event.key!=='Escape'||!audit.open)return;
      event.preventDefault();event.stopPropagation();
      if(reportMenuOpen){reportMenuOpen=false;renderDetail();detail.querySelector('.platform-account-report-trigger')?.focus?.();return;}
      audit.open=false;auditSummary.focus();
    });
    audit.append(panel);detail.append(audit);
    const maintenance=make('div',undefined,'platform-account-detail-actions');
    if(account.id&&loginAllowed()&&!recovery.blocked&&account.status==='ready'){
      const check=make('button','检查连接','secondary');check.type='button';check.disabled=accountBusy();
      check.addEventListener('click',()=>void checkConnection(account.id));maintenance.append(check);
    }
    panel.append(maintenance);
    const stats=make('div',undefined,'platform-account-stats');
    for(const [label,count] of [['近30天已记录手机异常',view.phoneCount],['近 30 天电脑错误',view.computerCount]]){
      const card=make('div',undefined,'platform-account-stat');card.append(make('span',label),make('strong',count===null?'记录尚不完整':`${count} 次`));
      if(view.complete&&label==='近30天已记录手机异常')card.append(make('small',`异常退出 ${record.phone_report_counts.unexpected_logout} 次 · 提示验证 ${record.phone_report_counts.phone_verification} 次`));
      stats.append(card);
    }
    const actions=make('div',undefined,'platform-account-detail-actions');
    const report=make('button','报告手机异常','secondary platform-account-report-trigger');report.type='button';report.disabled=accountBusy()||!account.id;
    report.setAttribute('aria-expanded',String(reportMenuOpen));report.setAttribute('aria-controls','platform-account-report-menu');
    report.addEventListener('click',()=>{reportMenuOpen=!reportMenuOpen;renderDetail();detail.querySelector('.platform-account-report-trigger')?.focus?.();});actions.append(report);
    panel.append(actions);
    const menu=make('div',undefined,'platform-account-report-menu');menu.id='platform-account-report-menu';menu.hidden=!reportMenuOpen;
    menu.append(make('p','只记录实际遇到的情况。报送后暂停相关操作，等待人工核实。'));
    for(const [kind,label] of [['unexpected_logout','手机异常退出'],['phone_verification','手机提示验证']]){
      const button=make('button',label,'secondary');button.type='button';button.disabled=busy;
      button.addEventListener('click',()=>void reportSignal(account.id,kind,label));menu.append(button);
    }
    panel.append(menu);
    const recordBox=make('details',undefined,'platform-account-record-box');recordBox.open=recordOpen;recordBox.addEventListener('toggle',()=>{recordOpen=recordBox.open;});recordBox.append(make('summary','账号记录'));
    if(!record){recordBox.append(make('p',account.id?'正在读取账号记录…':'登录后会保留异常记录。'));panel.append(recordBox);return;}
    recordBox.append(make('p',view.phoneState,'platform-account-phone-state'),stats);
    if(!view.complete)recordBox.append(make('p','记录尚不完整。请刷新；旧版服务暂不能提供手机与电脑的完整统计。','platform-account-incomplete'));
    if(record.state==='review_required')recordBox.append(make('p',record.message||reasonText(account.review_reason),'platform-account-review-note'));
    const times=make('div',undefined,'platform-account-times');
    for(const [label,value] of [['上次手机异常',record.previous_phone_anomaly_at],['本次手机异常',record.last_phone_anomaly_at]]){
      const item=make('div');item.append(make('span',label),make('strong',view.complete?shanghaiTime(value):'记录尚不完整'));times.append(item);
    }
    recordBox.append(times);
    const timeline=make('details',undefined,'platform-account-timeline');timeline.open=timelineOpen;
    timeline.addEventListener('toggle',()=>{timelineOpen=timeline.open;});timeline.append(make('summary','查看最近记录'));
    if(view.complete){
      if(!record.incident_history.length)timeline.append(make('p','近 30 天暂无已记录事件。'));
      for(const event of record.incident_history.slice(0,20)){
        const row=make('div',undefined,'platform-account-event');
        row.append(make('time',shanghaiTime(event?.at)),make('strong',typeof event?.kind==='string'?event.kind:'事件待核对'),
          make('span',sourceText(event?.source),'platform-account-event-source'),make('p',typeof event?.label==='string'?event.label:'记录说明缺失'));
        timeline.append(row);
      }
      const scope=record.history_scope;
      if(scope.truncated_by_time||scope.truncated_by_records)timeline.append(make('small','这里只展示近 30 天、最多 20 条最近事件；部分旧记录未纳入统计。'));
    }else timeline.append(make('p','旧版记录尚不完整，暂不能展示可靠时间线。'));
    recordBox.append(timeline);panel.append(recordBox);
    const advice=make('details',undefined,'platform-account-advice');advice.open=adviceOpen;advice.addEventListener('toggle',()=>{adviceOpen=advice.open;});advice.append(make('summary','专业建议'));
    if(view.complete){
      for(const [key,label] of [['collection','采集间隔'],['reply','回复间隔']]){
        const item=record.interval_advice?.[key],card=make('div',undefined,'platform-account-advice-card');
        card.append(make('strong',label),make('p',typeof item?.recommendation==='string'&&item.recommendation?item.recommendation:'暂无法给出具体间隔建议。'));
        card.append(make('small',`最近观察：${gapText(item?.observed_gap_seconds)}；建议先试：${gapText(item?.suggested_trial_gap_seconds)}`));
        if(typeof item?.reason==='string'&&item.reason){const why=make('details');why.append(make('summary','为什么这样建议？'),make('p',item.reason));card.append(why);}
        advice.append(card);
      }
      const loginAdvice=make('p',typeof record.next_login_recommendation==='string'&&record.next_login_recommendation?record.next_login_recommendation:'登录建议尚未提供。','platform-account-login-advice');advice.append(loginAdvice);
      if(typeof record.next_login_reason==='string'&&record.next_login_reason){const why=make('details');why.append(make('summary','查看登录建议依据'),make('p',record.next_login_reason));advice.append(why);}
    }else advice.append(make('p','记录尚不完整，先核对账号和手机提示；暂不推荐具体间隔。'));
    const caveat=make('details',undefined,'platform-account-caveat');caveat.append(make('summary','建议如何使用？'),make('p','这些间隔是根据已记录操作给出的谨慎试行建议，不代表平台官方安全阈值。遇到验证或异常退出时，先暂停并核实上次操作。'));
    advice.append(caveat);panel.append(advice);
  }
  function renderIdentity(account){
    const panel=make('section',undefined,'platform-account-identity-observation');
    const attempt=identityAttempt,outcome=identityOutcome;
    const run=make('button',attempt?'正在核对本人身份…':'核对本人身份','secondary platform-account-identity-observe');run.type='button';
    run.disabled=accountBusy()||!identityAllowed();run.addEventListener('click',()=>void beginIdentity(account.id));panel.append(run);
    const note=make('p',undefined,'platform-account-identity-message');note.setAttribute('role','status');note.setAttribute('aria-live','polite');
    if(attempt){
      note.textContent=attempt.cancelRequested?'正在关闭身份核对窗口…':attempt.interrupted?'核对状态暂未确认，请刷新核对状态或取消。':'正在读取当前小红书账号的本人身份，请完成窗口中的验证。';
      if(attempt.job){
        const cancel=make('button','取消核对','text-button platform-account-identity-cancel');cancel.type='button';cancel.disabled=!!attempt.cancelRequested;
        cancel.addEventListener('click',()=>void cancelIdentity(attempt));panel.append(cancel);
        if(attempt.interrupted){const retry=make('button','刷新核对状态','text-button platform-account-identity-retry');retry.type='button';retry.addEventListener('click',()=>{if(identityCurrent(attempt)){attempt.interrupted=false;void pollIdentity(attempt);}});panel.append(retry);}
      }
    }else if(outcome){note.textContent=outcome.message;}
    else note.textContent=identityAllowed()?'只读取本人身份；核对结果需人工确认，账号原状态保留。':'本人身份核对暂不可用，请刷新账号状态。';
    panel.append(note);detail.append(panel);
  }
  async function beginIdentity(accountId){
    expireIdentityScope();
    if(accountBusy()||!accountsLoaded||!identityAllowed()||selectedId!==accountId||!accounts.some(item=>item.id===accountId))return;
    const attempt={accountId,scope:identityScope(),epoch:++identityEpoch,job:'',cancelRequested:false,interrupted:false};
    identityAttempt=attempt;identityOutcome=null;renderAccounts();renderDetail();
    try{
      const value=await identityCall(attempt,'assistant_account_identity_observe',{account_id:accountId});
      if(!identityCurrent(attempt))return;
      if(!QR_JOB.test(value?.login_job||'')||value.mode!=='browser'||value.purpose!=='identity_observation'||value.read_only!==true||value.account_ready!==false)throw Error('身份核对任务尚未确认，请刷新账号状态。');
      attempt.job=value.login_job;renderAccounts();renderDetail();void pollIdentity(attempt);
    }catch(error){
      if(!identityCurrent(attempt))return;
      identityOutcome={accountId,scope:attempt.scope,message:error.message||'身份核对未开始，请刷新状态后再试。'};identityAttempt=null;renderAccounts();renderDetail();
    }
  }
  async function pollIdentity(attempt){
    expireIdentityScope();
    clearTimeout(identityTimer);identityTimer=0;if(!identityCurrent(attempt)||!attempt.job)return;
    try{
      const value=await identityCall(attempt,'assistant_job_status',{job_id:attempt.job});
      if(!identityCurrent(attempt))return;
      const result=identityObservationResult(value);
      if(result.running){renderAccounts();renderDetail();identityTimer=setTimeout(()=>void pollIdentity(attempt),1500);return;}
      identityOutcome={accountId:attempt.accountId,scope:attempt.scope,message:result.message};identityAttempt=null;renderAccounts();renderDetail();
      // Observation does not update accounts or invoke the login/review/claim actions.
    }catch(error){if(!identityCurrent(attempt))return;attempt.interrupted=true;renderAccounts();renderDetail();}
  }
  async function cancelIdentity(attempt){
    expireIdentityScope();
    if(!identityCurrent(attempt)||!attempt.job||attempt.cancelRequested)return;
    attempt.cancelRequested=true;renderAccounts();renderDetail();
    try{await identityCall(attempt,'assistant_cancel_login',{job_id:attempt.job});if(identityCurrent(attempt)){attempt.interrupted=false;void pollIdentity(attempt);}}
    catch(error){if(identityCurrent(attempt)){attempt.cancelRequested=false;attempt.interrupted=true;renderAccounts();renderDetail();}}
  }
  async function refresh(){
    const current=++refreshSerial,token=viewToken();loading=true;loadError='';renderAccounts();renderDetail();
    const timedCall=action=>{let timer;return Promise.race([scopedCall(token,action),new Promise((_,reject)=>{timer=setTimeout(()=>reject(Error('读取账号超时，请重试')),15000);})]).finally(()=>clearTimeout(timer));};
    try{
      const nextStatus=await timedCall('assistant_status');
      if(current!==refreshSerial||!viewCurrent(token))return;
      status=nextStatus;
      const snapshot=await timedCall('assistant_workspace_state');
      if(current!==refreshSerial||!viewCurrent(token))return;
      if(!Array.isArray(snapshot?.accounts))throw Error('账号列表响应无效，请重试');
      wxSnapshotScope=token.scope;dySnapshotScope=token.scope;slotCapabilities=snapshot.capabilities&&typeof snapshot.capabilities==='object'?snapshot.capabilities:null;
      status=nextStatus;allAccounts=snapshot.accounts.filter(item=>item&&typeof item.id==='string'&&typeof item.platform==='string');accounts=allAccounts.filter(item=>item.platform==='xiaohongshu');
      const nextId=selectedAccountId(accounts,selectedId);if(nextId!==selectedId){selectedId=nextId;safety=null;safetyId='';reportMenuOpen=false;timelineOpen=false;}
      accountsLoaded=true;loading=false;loadError='';if(messageKind==='load')message('');onAccountsChanged([...allAccounts],selectedId);renderAccounts();renderDetail();
      if(selectedId)await loadSafety(selectedId);
    }catch(error){if(current!==refreshSerial||!viewCurrent(token))return;loading=false;loadError=error.message||'账号状态读取失败';renderAccounts();renderDetail();message(loadError,true,'load');throw error;}
  }
  async function selectAccount(accountId){if(accountBusy()||!accounts.some(item=>item.id===accountId))return;selectedId=accountId;safety=null;safetyId='';reportMenuOpen=false;timelineOpen=false;recordOpen=false;adviceOpen=false;onAccountsChanged([...allAccounts],selectedId);renderAccounts();renderDetail();await loadSafety(accountId);}
  async function loadSafety(accountId){
    if(!accountId)return;const current=++revision,token=viewToken(accountId);
    try{const value=await scopedCall(token,'assistant_account_safety',{account_id:accountId});
      if(current!==revision||!viewCurrent(token))return;safety=value;safetyId=accountId;renderDetail();
    }catch(error){if(current!==revision||!viewCurrent(token))return;safety=null;safetyId='';renderDetail();message(error.message||'复核记录读取失败',true);}
  }
  async function completeReview(accountId,browserReauth=false){
    let data;try{if(safetyId!==accountId)throw Error('请先刷新账号复核记录');data=reviewSignal(accountId,safety);}catch(error){message(error.message,true);return;}
    if(accountBusy())return;
    if(!confirmReview(browserReauth?'手机小红书能正常浏览，且没有待完成的验证或限制吗？确认后扫码，电脑会自动核对连接。':'手机小红书已恢复正常，并且上次操作结果已核实吗？确认后会检查电脑连接。'))return;
    const token=viewToken(accountId),reauth=browserReauth||accountRecovery(accounts.find(item=>item.id===accountId)).reauth;
    busy=true;renderAccounts();renderDetail();
    try{
      message(reauth?(browserLogin()?'正在准备网页登录…':'正在准备二维码…'):'正在检查连接…');
      await scopedCall(token,'assistant_account_signal',data);if(!viewCurrent(token))return;
      safety=null;safetyId='';await refresh();if(!viewCurrent(token))return;
      if(reauth)await beginLogin(accountId,true);else{await verifyConnection(accountId,token);if(viewCurrent(token))await refresh();}
    }catch(error){if(!viewCurrent(token))return;safety=null;safetyId='';message(error.message||'连接未确认，采集保持暂停。请先核对手机提示。',true);await refresh().catch(()=>{});}
    finally{if(viewCurrent(token)){busy=false;renderAccounts();renderDetail();}}
  }
  async function verifyConnection(accountId,token=viewToken(accountId)){
    if(typeof checkAccount!=='function')throw Error('连接检查暂不可用，请稍后再试');
    const checked=await checkAccount(accountId);if(!viewCurrent(token))return;
    if(checked?.status==='ready'&&checked.requires_review!==true){message('登录仍可用，无需扫码。采集是否可继续请查看采集页。');return checked;}
    throw Error(checked?.requires_review?'电脑端请求仍未通过，请核对手机提示与本次操作；采集保持暂停。':browserLogin()?'登录需要更新，请使用此页的网页登录。':'登录需要更新，请使用此页的扫码登录。');
  }
  async function checkConnection(accountId){
    if(accountBusy())return;const token=viewToken(accountId);busy=true;renderAccounts();renderDetail();message('正在检查连接…');
    try{await verifyConnection(accountId,token);if(viewCurrent(token))await refresh();}
    catch(error){if(viewCurrent(token)){message(error.message||'连接检查未完成，请稍后再试',true);await refresh().catch(()=>{});}}
    finally{if(viewCurrent(token)){busy=false;renderAccounts();renderDetail();}}
  }
  async function reportSignal(accountId,kind,label){
    if(accountBusy())return;
    if(!confirmReview(`确认${label}？记录后该账号相关平台操作会暂停，需人工核实。`))return;
    const token=viewToken(accountId);reportMenuOpen=false;busy=true;renderAccounts();renderDetail();
    try{await scopedCall(token,'assistant_account_signal',{account_id:accountId,kind});if(!viewCurrent(token))return;message('安全提醒已记录，相关操作将暂停。');await refresh();}
    catch(error){if(viewCurrent(token)){message(error.message||'提醒未记录，请核对状态',true);await loadSafety(accountId);}}
    finally{if(viewCurrent(token)){busy=false;renderAccounts();renderDetail();}}
  }
  async function beginLogin(accountId='',afterReview=false){
    expireLoginScope();expireIdentityScope();
    if(!accountsLoaded||!loginAllowed(accountId)||identityAttempt||loginAttempt||loginJob||accounts.some(item=>item.status==='logging_in')||busy&&!afterReview)return;
    const account=accounts.find(item=>item.id===accountId);
    if(accountId&&!account)return;
    if(account&&!accountRecovery(account).canLogin){message('请先完成手机验证并核实账号，暂勿重复扫码。',true);return;}
    const attempt={...viewToken(accountId),epoch:++loginEpoch,job:'',purpose:sessionRecoveryAvailable(status,accountId,scopeValue())?'session_recovery':'',pollSerial:0,cancelRequested:false};
    loginAttempt=attempt;
    busy=true;flowStage=0;loginInterrupted=false;loginMode=browserLogin()?'browser':'qr';qr.hidden=false;qrImage.hidden=true;message('');shell.querySelector('.platform-account-qr-head strong').textContent='准备登录';shell.querySelector('.platform-account-qr-close').textContent='取消';shell.querySelector('.platform-account-qr-close').disabled=true;qrMessage.textContent='正在准备小红书二维码…';renderAccounts();renderDetail();
    try{
      const result=await loginCall(attempt,accountId?'assistant_account_login':'assistant_new_account_login',accountId?{account_id:accountId}:{});if(!loginCurrent(attempt))return;
      if(!QR_JOB.test(result?.login_job||''))throw Error('登录任务编号无效，请核对助手状态');
      loginJob=attempt.job=result.login_job;
      if(attempt.purpose==='session_recovery'&&(result.purpose!=='session_recovery'||result.mode!=='browser'))throw Error('登录恢复任务尚未确认');
      loginMode=result.mode==='browser'?'browser':'qr';shell.querySelector('.platform-account-qr-close').disabled=false;void pollLogin(attempt);await refresh();
    }catch(error){if(!loginCurrent(attempt))return;if(attempt.job)loginInterrupted=true;else clearLogin();busy=false;shell.querySelector('.platform-account-qr-head strong').textContent=attempt.job?'结果待确认':'登录未完成';qrMessage.textContent=error.message||'二维码未准备好，请稍后再试。';shell.querySelector('.platform-account-qr-close').textContent=attempt.job?'取消':'返回';shell.querySelector('.platform-account-qr-close').disabled=false;renderAccounts();renderDetail();}
    finally{if(loginCurrent(attempt)){busy=false;renderAccounts();renderDetail();}}
  }
  async function pollLogin(attempt){
    if(!loginCurrent(attempt)||!attempt.job||qr.hidden)return;stopPolling();const serial=++attempt.pollSerial;
    try{
      const value=await loginCall(attempt,'assistant_job_status',{job_id:attempt.job});
      if(!loginCurrent(attempt)||serial!==attempt.pollSerial||qr.hidden)return;
      if(attempt.purpose==='session_recovery'&&(value.purpose!=='session_recovery'||value.mode!=='browser'))throw Error('登录恢复结果尚未确认');
      if(!['running','completed','failed','cancelled'].includes(value.status))throw Error('登录结果尚未确认');
      if(value.mode==='browser')loginMode='browser';
      if(value.status==='running'){
        if(attempt.cancelRequested){flowStage=1;qrImage.hidden=true;shell.querySelector('.platform-account-qr-head strong').textContent='正在关闭登录';qrMessage.textContent='正在关闭本次登录窗口并清理临时记录，请稍候。';}
        else if(loginMode==='browser'&&value.phase==='waiting_browser'){message('');flowStage=0;qrImage.hidden=true;shell.querySelector('.platform-account-qr-head strong').textContent='请在登录窗口完成操作';qrMessage.textContent='请在小红书登录窗口完成扫码及平台要求的验证。平台验证请按窗口提示处理；是否连接成功，请以工作台核对结果为准。';}
        else if(loginMode==='browser'&&value.phase==='opening_browser'){flowStage=0;qrImage.hidden=true;qrMessage.textContent='正在准备小红书二维码…';}
        else if(value.phase==='closing_previous_login'){message('');flowStage=0;qrImage.hidden=true;shell.querySelector('.platform-account-qr-head strong').textContent='正在准备登录';qrMessage.textContent='正在关闭上一个登录窗口，随后自动打开…';}
        else if(value.phase==='verifying_identity'){message('');flowStage=1;qrImage.hidden=true;shell.querySelector('.platform-account-qr-head strong').textContent='正在自动核对';qrMessage.textContent='已收到扫码确认，正在核对电脑连接…';}
        else if(value.phase==='confirming_connection'){message('');flowStage=1;qrImage.hidden=true;shell.querySelector('.platform-account-qr-head strong').textContent='正在自动连接';qrMessage.textContent='账号已确认，正在连接工作台…';}
        else if(['saving_session','cleaning_candidate','closing_window'].includes(value.phase)){message('');flowStage=1;qrImage.hidden=true;shell.querySelector('.platform-account-qr-head strong').textContent='正在完成登录';qrMessage.textContent='正在保存登录并完成窗口清理，请稍候。';}
        else if(value.qr_ready){message('');flowStage=0;shell.querySelector('.platform-account-qr-head strong').textContent='等待扫码';if(qrImage.hidden){qrImage.src=`/assistant-qr/${attempt.job}?t=${Date.now()}`;qrImage.hidden=false;}qrMessage.textContent='用小红书 App 扫码并确认，随后自动连接。';}
        else qrMessage.textContent='正在等待登录结果…';
        renderAccounts();renderDetail();pollTimer=setTimeout(()=>void pollLogin(attempt),1500);return;
      }
      if(attempt.purpose==='session_recovery'&&(value.cleanup_confirmed!==true||(value.status==='completed'&&value.session_committed!==true)))throw Error('登录保存与窗口清理结果尚未确认');
      const completed=value.status==='completed',recovered=completed&&attempt.purpose==='session_recovery';
      clearLogin();busy=false;loginInterrupted=false;qrImage.hidden=true;shell.querySelector('.platform-account-qr-head strong').textContent=value.status==='cancelled'?'登录已取消':'登录未完成';shell.querySelector('.platform-account-qr-close').textContent='返回';shell.querySelector('.platform-account-qr-close').disabled=false;qrMessage.textContent=value.status==='cancelled'?'本次登录已取消，账号原记录保留。':value.error||'连接未完成，请查看手机提示后再试。';
      if(completed){qr.hidden=true;flowStage=2;message(recovered?'登录已保存；采集资格仍以账号与安全状态为准。':'');}
      await refresh();
    }catch(error){if(!loginCurrent(attempt)||serial!==attempt.pollSerial)return;loginInterrupted=true;qrImage.hidden=true;shell.querySelector('.platform-account-qr-head strong').textContent='结果待确认';qrMessage.textContent=error.message||'扫码结果尚未确认，请取消后再试。';shell.querySelector('.platform-account-qr-close').disabled=false;shell.querySelector('.platform-account-qr-close').textContent=attempt.cancelRequested?'重新核对关闭':'取消';renderAccounts();renderDetail();}
  }
  shell.querySelector('.platform-account-qr-close').addEventListener('click',async()=>{
    expireLoginScope();const attempt=loginAttempt;
    if(!attempt){if(busy)return;qr.hidden=true;qrImage.hidden=true;qrImage.removeAttribute('src');renderAccounts();renderDetail();return;}
    if(!loginCurrent(attempt)||!attempt.job)return;
    if(attempt.cancelRequested){if(loginInterrupted){loginInterrupted=false;shell.querySelector('.platform-account-qr-close').disabled=true;qrMessage.textContent='正在重新核对本次登录窗口的关闭结果…';void pollLogin(attempt);}return;}
    if(loginMode!=='browser'&&attempt.purpose!=='session_recovery'){clearLogin();busy=false;flowStage=0;qr.hidden=true;qrImage.hidden=true;qrImage.removeAttribute('src');void refresh().catch(()=>{});return;}
    attempt.cancelRequested=true;stopPolling();shell.querySelector('.platform-account-qr-close').disabled=true;qrMessage.textContent='正在关闭本次登录窗口并清理临时记录，请稍候。';renderAccounts();renderDetail();
    try{await loginCall(attempt,'assistant_cancel_login',{job_id:attempt.job});if(loginCurrent(attempt)){loginInterrupted=false;void pollLogin(attempt);}}
    catch(error){if(loginCurrent(attempt)){attempt.cancelRequested=false;shell.querySelector('.platform-account-qr-close').disabled=false;message('登录窗口关闭结果尚未确认，请重试取消。',true);renderAccounts();renderDetail();}}
  });
  return {refresh,reset,openReview(accountId=''){
    if(accountId){selectedId=accountId;safety=null;safetyId='';}
    if(accountId&&!accounts.some(item=>item.id===accountId))return;
    const target=accounts.find(item=>item.id===selectedId)||accounts.find(item=>item.requires_review)||accounts[0];
    if(target)void selectAccount(target.id);
  },setAccounts(items){if(!Array.isArray(items))return;allAccounts=items.filter(item=>item&&typeof item.id==='string'&&typeof item.platform==='string');accounts=allAccounts.filter(item=>item.platform==='xiaohongshu');accountsLoaded=true;selectedId=selectedAccountId(accounts,selectedId);renderAccounts();renderDetail();}};
}
