import sys,json,time,tempfile,unittest
from pathlib import Path
from types import SimpleNamespace as NS
from unittest.mock import patch
from contextlib import nullcontext
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'backend-candidate/src'))
sys.path.append('C:/积木软件工坊/项目/方隅公寓客户版/work/combined-full-candidate-20261027/project/work/ui-runtime-r55/src')
from core.store import Store
from assistant.browser_login_coordinator import BrowserLoginCoordinator
from assistant.browser_session_commit import commit_browser_session,recover_browser_session,account_revision
from assistant.cli_staging import stage_cli_candidate_once
from assistant.browser_login_window import LoginWindowController
from assistant.native_login_observer import NativeLoginObserver
from assistant.auth_candidate import OwnedCookie
from assistant.login_natural_proof import create_spec,verified_status


from assistant.xhs_session_transport import SessionRecoveryTransport
from xhs_page_transport import _State,PageTransportError
URL='https://www.xiaohongshu.com/explore'
class Window:
    def __init__(self):self.destroyed=0
    def destroy(self):self.destroyed+=1
    def set_title(self,title):pass
    def get_current_url(self):return URL
class BoundaryTests(unittest.TestCase):
    def test_real_manual_observer_stage_proof_and_tamper(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as tmp:
            store=Store(Path(tmp));account={'id':'account','tenant_id':'tenant','platform':'xiaohongshu','platform_uid':'owner','status':'needs_login'};store.put('accounts',account)
            root=Path(tmp)/'accounts/tenant/account';stage=root/'work/browser-login'/('a'*24);stage.mkdir(parents=True)
            create_spec(stage,job_id=stage.name,bound_uid='owner')
            observer=NativeLoginObserver(None,job_id=stage.name,bound_uid='owner')
            observer.attached=True;observer.current_url=URL
            observer.native=NS(invoke=lambda f:f(),core=lambda:(None,NS(Source=URL)))
            observer.identity.doc_epoch=1;observer.identity.frame='frame';observer.identity.loader='loader'
            observer.identity._fail('verification_required')
            w=Window();c=LoginWindowController(mode='live',initial_url=URL,staging_root=stage,cancel_file=stage/'cancel.flag',natural_observer=observer)
            c.attach(w);c.check_authenticated()
            self.assertEqual(c.phase,'manual_verification_required');self.assertEqual(w.destroyed,0)
            i=observer.identity;url='https://edith.xiaohongshu.com/api/sns/web/v2/user/me'
            i.request_will_be_sent(json.dumps({'requestId':'fresh','frameId':'frame','loaderId':'loader','type':'Fetch','request':{'url':url,'method':'GET'}}))
            i.request_extra_info(json.dumps({'requestId':'fresh','headers':{'Cookie':'a1=synthetic-a; [REDACTED:cookie_kv]; [REDACTED:cookie_kv]'}}))
            i.response_received(json.dumps({'requestId':'fresh','frameId':'frame','loaderId':'loader','response':{'url':url,'status':200}}))
            i.loading_finished(json.dumps({'requestId':'fresh','encodedDataLength':100}))
            i.response_body('fresh',json.dumps({'base64Encoded':False,'body':json.dumps({'success':True,'data':{'is_guest':False,'user_id':'owner','nickname':'Synthetic'}})}))
            raw=[OwnedCookie(k,v,'.xiaohongshu.com','/',True,False,True,'') for k,v in {'a1':'synthetic-a','webId':'synthetic-web','web_session':'synthetic-session'}.items()]
            with patch('assistant.browser_login_window.read_owned_window_cookies',return_value=raw):
                self.assertEqual(c.confirm_manual_verification(),'candidate_staged_natural_verified')
            cookie=stage/'.xiaohongshu-cli/cookies.json'
            self.assertIsNotNone(verified_status(stage,cookie));self.assertEqual(w.destroyed,1)
            snapshot={**account,'exists':True,'revision':account_revision(account)}
            coordinator=BrowserLoginCoordinator(stage=lambda:stage,status=lambda s:verified_status(s,cookie),local_accounts=lambda:store.list('accounts','tenant'),claim=lambda uid:True,commit=lambda s,d,o:commit_browser_session(store,root,account,d,cookie,lambda:True)=='committed',discard=lambda s:None,current=lambda:snapshot,cancelled=lambda:False,deadline=time.monotonic()+5)
            self.assertEqual(coordinator.run().state,'completed')
            self.assertEqual(store.get('accounts','account')['status'],'ready')
            self.assertEqual((root/'.xiaohongshu-cli/cookies.json').read_bytes(),cookie.read_bytes())
            cookie.write_text('{}');self.assertIsNone(verified_status(stage,cookie))
    def test_original_coordinator_and_sqlite_commit(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as tmp:
            store=Store(Path(tmp));a={'id':'account','tenant_id':'tenant','platform':'xiaohongshu','platform_uid':'owner','status':'needs_login'}
            store.put('accounts',a);root=Path(tmp)/'accounts/tenant/account';stage=root/'work/browser-login'/('b'*24);stage.mkdir(parents=True)
            cookie=stage_cli_candidate_once({'a1':'synthetic-a','webId':'synthetic-web','web_session':'synthetic-session'},staging_root=stage,cancel_file=stage/'cancel.flag')
            snapshot={**a,'exists':True,'revision':account_revision(a)};events=[]
            def commit(s,d,o):
                events.append('commit');return commit_browser_session(store,root,a,d,cookie,lambda:True)=='committed'
            coordinator=BrowserLoginCoordinator(stage=lambda:stage,status=lambda s:{'data':{'authenticated':True,'user':{'id':'owner','nickname':'Synthetic','guest':False}}},local_accounts=lambda:store.list('accounts','tenant'),claim=lambda uid:events.append('synthetic_cloud_boundary') or True,commit=commit,discard=lambda s:None,current=lambda:snapshot,cancelled=lambda:False,deadline=time.monotonic()+5)
            result=coordinator.run();self.assertEqual(result.state,'completed')
            self.assertEqual(store.get('accounts','account')['status'],'ready')
            self.assertEqual((root/'.xiaohongshu-cli/cookies.json').read_bytes(),cookie.read_bytes())
            self.assertEqual(recover_browser_session(store,root,'account','tenant'),'clean')
            self.assertFalse((root/'.xiaohongshu-cli/.browser-session-commit.json').exists())
    def test_original_transaction_late_guard_rolls_back_files_and_db(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as tmp:
            store=Store(Path(tmp));a={'id':'account','tenant_id':'tenant','platform':'xiaohongshu','platform_uid':'owner','status':'needs_login'};store.put('accounts',a)
            root=Path(tmp)/'accounts/tenant/account';stage=root/'work/browser-login'/('c'*24);stage.mkdir(parents=True)
            cookie=stage_cli_candidate_once({'a1':'synthetic-a','webId':'synthetic-web','web_session':'synthetic-session'},staging_root=stage,cancel_file=stage/'cancel.flag')
            active=root/'.xiaohongshu-cli/cookies.json';active.parent.mkdir();active.write_bytes(b'synthetic-old');before=active.read_bytes();calls=[]
            def guard():calls.append(1);return len(calls)<3
            decision={'verified':True,'status':'ready','uid':'owner','nickname':'Synthetic','avatar':''}
            self.assertEqual(commit_browser_session(store,root,a,decision,cookie,guard),'guard_failed')
            self.assertEqual(active.read_bytes(),before);self.assertEqual(store.get('accounts','account'),a)
            self.assertEqual(recover_browser_session(store,root,'account','tenant'),'clean')
    def transport(self,deadline):
        t=SessionRecoveryTransport.__new__(SessionRecoveryTransport)
        t.state=_State('synthetic',None);t.state.connected=True;t.state.session_token='s'*32;t.state.doc_epoch=1
        t.ready_guard=NS(issue=lambda:nullcontext());t._guard=lambda *a:None
        t.session_scope=NS(app_context=NS(claim=NS(deadline=deadline)))
        t.process=NS(poll=lambda:None)
        return t
    def test_real_transport_timeout_and_cancel_fail_closed(self):
        for stopped in (False,True):
            t=self.transport(time.monotonic()-1);t.state.stopping=stopped
            with self.assertRaises(PageTransportError):t._run_session_recovery()
    def test_real_transport_bound_result_once(self):
        t=self.transport(time.monotonic()+5)
        t.state.pending={'action':'session_recovery','call_id':'recover','task_epoch':1,'delivered':False,'result':None,'error':None}
        body={'session_token':'s'*32,'doc_epoch':1}
        self.assertEqual(t._ipc('/poll',body)['call_id'],'recover')
        result={**body,'call_id':'recover','task_epoch':1,'code':'candidate_staged_natural_verified'}
        t._ipc('/session_result',result)
        with self.assertRaises(PageTransportError):t._ipc('/session_result',result)
        with self.assertRaises(PageTransportError):t._ipc('/session_current',{**body,'call_id':'recover','task_epoch':2})
if __name__=='__main__':unittest.main(verbosity=2)





