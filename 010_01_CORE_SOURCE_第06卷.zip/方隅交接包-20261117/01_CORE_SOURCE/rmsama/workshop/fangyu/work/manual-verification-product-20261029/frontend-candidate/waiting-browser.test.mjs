import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import vm from 'node:vm';

const source=readFileSync(new URL('./web/workspace/platform-account.mjs',import.meta.url),'utf8');
function renderWaiting(){
  // Execute the actual production waiting-browser branch with its DOM ports.
  const branch=source.match(/else if\(loginMode==='browser'&&value\.phase==='waiting_browser'\)\{([^}]+)\}/);
  assert.ok(branch,'waiting_browser branch must exist');
  const title={textContent:''}, qrMessage={textContent:''}, qrImage={hidden:false};
  const scope={message:()=>{},flowStage:9,qrMessage,qrImage,shell:{querySelector:()=>title}};
  vm.runInNewContext(branch[1],scope);
  return {title:title.textContent,message:qrMessage.textContent,hidden:qrImage.hidden,stage:scope.flowStage};
}
test('browser wait names both scan and platform verification without promising success',()=>{
  const result=renderWaiting();
  assert.match(result.message,/登录窗口/);
  assert.match(result.message,/扫码/);
  assert.match(result.message,/平台验证/);
  assert.doesNotMatch(result.message,/随后自动连接|必定|验证完成，重新检查|菜单/);
  assert.match(result.message,/核对结果/);
  assert.equal(result.title,'请在登录窗口完成操作');
});
test('browser wait still hides embedded QR and preserves the waiting flow',()=>{
  const result=renderWaiting();
  assert.equal(result.hidden,true);
  assert.equal(result.stage,0);
});
