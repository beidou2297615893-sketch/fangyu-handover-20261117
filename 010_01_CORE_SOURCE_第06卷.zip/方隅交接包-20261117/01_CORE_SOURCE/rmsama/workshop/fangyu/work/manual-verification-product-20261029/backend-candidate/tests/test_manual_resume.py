import sys
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
from contextlib import ExitStack
from threading import Event, Thread

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'src'))
from assistant.browser_login_window import LoginWindowController
from assistant.native_login_observer import NativeLoginObserver, NativeLoginError
import assistant.browser_login_window as login_module


class Window:
    def __init__(self):
        self.destroyed = 0
        self.titles = []
    def destroy(self):
        self.destroyed += 1
    def get_current_url(self):
        return 'https://www.xiaohongshu.com/explore'
    def set_title(self, title):
        self.titles.append(title)


class Observer:
    def __init__(self):
        self.code = 'verification_required'
        self.resets = 0
        self.polls = 0
    def poll(self):
        self.polls += 1
        return self.code
    def begin_manual_wait(self):
        self.resets += 1
        self.code = 'pending'
    def cancel(self):
        pass
    def bind_candidate(self, cookies):
        return {'user': {'id': 'synthetic-owner'}}
    def evidence_current(self, evidence, cookies):
        return self.code == 'identity_observed'


class ManualResumeTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.observer = Observer()
        root = Path(self.temp.name)
        self.controller = LoginWindowController(
            mode='live', initial_url='https://www.xiaohongshu.com/explore',
            staging_root=root, cancel_file=root / 'cancel', natural_observer=self.observer)
        self.window = Window()
        self.controller.attach(self.window)

    def enter_manual(self):
        self.controller.check_authenticated()

    def test_challenge_keeps_same_window_and_resets_passive_evidence(self):
        self.enter_manual()
        self.assertEqual(self.controller.phase, 'manual_verification_required')
        self.assertEqual(self.window.destroyed, 0)
        self.assertFalse(self.controller.finished.is_set())
        self.assertEqual(self.observer.resets, 1)

    def test_old_qr_timeout_does_not_close_manual_wait(self):
        self.enter_manual()
        with patch.object(self.controller.finished, 'wait', return_value=False):
            self.controller.timeout()
        self.assertEqual(self.window.destroyed, 0)

    def test_timer_does_not_poll_or_submit_during_manual_wait(self):
        self.enter_manual()
        self.observer.code = 'identity_observed'
        before = self.observer.polls
        self.controller.check_authenticated()
        self.controller.finish()
        self.assertEqual(self.observer.polls, before)
        self.assertEqual(self.controller.finish_count, 0)

    def test_explicit_confirmation_is_single_attempt_even_if_pending(self):
        self.enter_manual()
        self.assertEqual(self.controller.confirm_manual_verification(), 'manual_identity_pending')
        before = self.observer.polls
        self.controller.confirm_manual_verification()
        self.assertEqual(self.observer.polls, before)
        self.assertEqual(self.window.destroyed, 0)

    def test_cancel_or_closed_cannot_confirm(self):
        for action in ('cancel', 'on_closed'):
            with self.subTest(action=action):
                self.setUp()
                self.enter_manual()
                getattr(self.controller, action)()
                before = self.observer.polls
                self.controller.confirm_manual_verification()
                self.assertEqual(self.observer.polls, before)
                self.assertEqual(self.controller.finish_count, 0)

    def test_identity_change_cannot_submit(self):
        self.enter_manual()
        self.observer.code = 'identity_mismatch'
        self.assertEqual(self.controller.confirm_manual_verification(), 'manual_identity_rejected')
        self.assertEqual(self.controller.finish_count, 0)

    def capture_dependencies(self):
        stack = ExitStack()
        self.addCleanup(stack.close)
        base = 'assistant.browser_login_window.'
        stack.enter_context(patch(base + 'read_owned_window_cookies', return_value=[]))
        stack.enter_context(patch(base + 'extract_xhs_candidate', return_value={'web_session': 'synthetic'}))
        path = Path(self.temp.name) / 'synthetic-stage'
        stage = stack.enter_context(patch(base + 'stage_cli_candidate_once', return_value=path))
        proof = stack.enter_context(patch(base + 'write_proof'))
        discard = stack.enter_context(patch(base + 'discard_cli_candidate'))
        return stage, proof, discard

    def test_explicit_success_uses_existing_stage_and_proof_once(self):
        self.enter_manual()
        self.observer.code = 'identity_observed'
        stage, proof, _ = self.capture_dependencies()
        self.assertEqual(self.controller.confirm_manual_verification(), 'candidate_staged_natural_verified')
        self.controller.confirm_manual_verification()
        self.assertEqual(stage.call_count, 1)
        self.assertEqual(proof.call_count, 1)
        self.assertEqual(self.controller.finish_count, 1)
        self.assertEqual(self.window.destroyed, 1)

    def test_identity_change_during_staging_discards_candidate(self):
        self.enter_manual()
        self.observer.code = 'identity_observed'
        stage, proof, discard = self.capture_dependencies()
        def change_identity(*args, **kwargs):
            self.observer.code = 'identity_mismatch'
            return Path(self.temp.name) / 'synthetic-stage'
        stage.side_effect = change_identity
        self.controller.confirm_manual_verification()
        self.assertEqual(self.controller.phase, 'natural_identity_unverified')
        self.assertEqual(proof.call_count, 0)
        self.assertEqual(discard.call_count, 1)

    def test_cancel_during_staging_never_writes_proof(self):
        self.enter_manual()
        self.observer.code = 'identity_observed'
        stage, proof, discard = self.capture_dependencies()
        def cancel(*args, **kwargs):
            self.controller.cancel()
            return Path(self.temp.name) / 'synthetic-stage'
        stage.side_effect = cancel
        self.controller.confirm_manual_verification()
        self.assertEqual(self.controller.phase, 'cancelled')
        self.assertEqual(proof.call_count, 0)
        self.assertTrue(discard.called)

    def test_native_menu_confirmation_calls_this_controller_only(self):
        self.enter_manual()
        class Menu:
            def __init__(self, title, actions):
                self.actions = actions
        class Action:
            def __init__(self, label, callback):
                self.callback = callback
        builder = getattr(login_module, 'build_login_menu', None)
        self.assertTrue(callable(builder), 'native menu must bind controller confirmation')
        menu = builder(self.controller, Menu, Action)
        self.assertEqual(menu[0].actions[0].callback(), 'manual_identity_pending')
        self.assertTrue(self.controller.manual_attempted)
        menu[0].actions[-1].callback()
        self.assertEqual(self.controller.phase, 'cancelled')

    def test_manual_wait_still_honors_parent_guard_cancellation_or_expiry(self):
        for reason in ('parent_cancel_flag', 'parent_claim_expired'):
            with self.subTest(reason=reason):
                self.setUp()
                self.enter_manual()
                before = self.observer.polls
                self.controller.guard = lambda: False
                self.controller.check_authenticated()
                self.assertEqual(self.controller.phase, 'safety_hold')
                self.assertTrue(self.controller.finished.is_set())
                self.assertEqual(self.window.destroyed, 1)
                self.assertEqual(self.observer.polls, before)

    def test_manual_wait_honors_local_cancel_marker(self):
        self.enter_manual()
        self.controller.cancel_file.touch()
        self.controller.check_authenticated()
        self.assertEqual(self.controller.phase, 'cancelled')
        self.assertEqual(self.window.destroyed, 1)

    def test_initializing_observer_cannot_consume_confirmation(self):
        entered, release = Event(), Event()
        original = self.observer.begin_manual_wait
        def blocked_reset():
            entered.set()
            self.assertTrue(release.wait(2))
            original()
        self.observer.begin_manual_wait = blocked_reset
        thread = Thread(target=self.controller.check_authenticated)
        thread.start()
        self.assertTrue(entered.wait(2))
        try:
            self.controller.confirm_manual_verification()
            self.assertFalse(self.controller.manual_attempted)
        finally:
            release.set()
            thread.join(2)
        self.assertEqual(self.controller.phase, 'manual_verification_required')

    def test_guard_loss_during_confirmation_blocks_capture(self):
        self.enter_manual()
        entered, release = Event(), Event()
        def blocked_poll():
            entered.set()
            self.assertTrue(release.wait(2))
            return 'identity_observed'
        self.observer.poll = blocked_poll
        thread = Thread(target=self.controller.confirm_manual_verification)
        thread.start()
        self.assertTrue(entered.wait(2))
        try:
            self.controller.guard = lambda: False
            self.controller.check_authenticated()
            self.assertEqual(self.controller.phase, 'safety_hold')
        finally:
            release.set()
            thread.join(2)
        self.assertEqual(self.controller.finish_count, 0)

    def test_pending_and_rejected_are_visible_in_native_window_title(self):
        for code in ('pending', 'identity_mismatch'):
            with self.subTest(code=code):
                self.setUp()
                self.enter_manual()
                self.observer.code = code
                self.controller.confirm_manual_verification()
                self.assertTrue(self.window.titles)
                self.assertIn('取消后重新登录', self.window.titles[-1])
                self.assertNotIn('成功', self.window.titles[-1])

    def test_late_wait_title_cannot_overwrite_newer_confirmation_result(self):
        entered, release = Event(), Event()
        original = self.controller._show_manual_status
        def delayed_wait_title(message, *args, **kwargs):
            if '当前网页完成验证' in message:
                entered.set()
                self.assertTrue(release.wait(2))
            return original(message, *args, **kwargs)
        self.controller._show_manual_status = delayed_wait_title
        thread = Thread(target=self.controller.check_authenticated)
        thread.start()
        self.assertTrue(entered.wait(2))
        try:
            self.controller.confirm_manual_verification()
            self.assertEqual(self.controller.phase, 'manual_identity_pending')
            self.assertIn('取消后重新登录', self.window.titles[-1])
        finally:
            release.set()
            thread.join(2)
        self.assertIn('取消后重新登录', self.window.titles[-1])

    def test_native_title_write_does_not_hold_controller_lock(self):
        lock_free = []
        def title(message):
            acquired = self.controller.lock.acquire(blocking=False)
            lock_free.append(acquired)
            if acquired:
                self.controller.lock.release()
        self.window.set_title = title
        self.enter_manual()
        self.controller.confirm_manual_verification()
        self.assertEqual(lock_free, [True, True, True])

    def test_inflight_old_native_title_finishes_before_newer_result(self):
        entered, release, newer_started = Event(), Event(), Event()
        def setter(message):
            if '当前网页完成验证' in message:
                entered.set()
                if not release.wait(2):
                    raise TimeoutError('synthetic setter release missing')
            self.window.titles.append(message)
        self.window.set_title = setter
        original = self.controller._show_manual_status
        def observe_newer(message, *args):
            if '正在核对' in message:
                newer_started.set()
            original(message, *args)
        self.controller._show_manual_status = observe_newer
        old = Thread(target=self.controller.check_authenticated)
        new = Thread(target=self.controller.confirm_manual_verification)
        old.start()
        self.assertTrue(entered.wait(2))
        try:
            new.start()
            self.assertTrue(newer_started.wait(2))
            self.assertEqual(self.controller.phase, 'manual_verification_checking')
            self.assertEqual(self.observer.polls, 1)
        finally:
            release.set()
            old.join(2)
            if new.ident is not None:
                new.join(2)
        self.assertFalse(old.is_alive())
        self.assertFalse(new.is_alive())
        self.assertEqual(self.controller.phase, 'manual_identity_pending')
        self.assertIn('取消后重新登录', self.window.titles[-1])
        self.assertEqual(self.controller.finish_count, 0)

    def test_blocked_setter_does_not_prevent_cancel_close_or_generate_candidate(self):
        for action in ('cancel', 'on_closed'):
            with self.subTest(action=action):
                self.setUp()
                self.enter_manual()
                entered, release = Event(), Event()
                def setter(message):
                    entered.set()
                    if not release.wait(2):
                        raise TimeoutError('synthetic setter release missing')
                self.window.set_title = setter
                self.observer.code = 'identity_observed'
                thread = Thread(target=self.controller.confirm_manual_verification)
                thread.start()
                self.assertTrue(entered.wait(2))
                try:
                    getattr(self.controller, action)()
                    expected = 'cancelled' if action == 'cancel' else 'closed'
                    self.assertEqual(self.controller.phase, expected)
                    self.assertTrue(self.controller.finished.is_set())
                    self.assertEqual(self.controller.finish_count, 0)
                finally:
                    release.set()
                    thread.join(2)
                self.assertFalse(thread.is_alive())
                self.assertEqual(self.controller.phase, expected)
                self.assertEqual(self.controller.finish_count, 0)
                self.assertIsNone(self.controller.stage_path)

    def test_native_setter_exception_cannot_turn_rejected_identity_into_candidate(self):
        self.enter_manual()
        self.observer.code = 'identity_mismatch'
        def setter(message):
            raise RuntimeError('synthetic native title failure')
        self.window.set_title = setter
        self.assertEqual(self.controller.confirm_manual_verification(), 'manual_identity_rejected')
        self.assertEqual(self.controller.finish_count, 0)
        self.assertIsNone(self.controller.stage_path)
        self.controller.cancel()
        self.assertTrue(self.controller.finished.is_set())


class NativeManualResetTests(unittest.TestCase):
    def test_stale_response_cannot_supply_new_identity_but_new_page_request_can(self):
        observer = NativeLoginObserver(None, job_id='a' * 24, bound_uid='owner')
        observer.attached = True
        observer.identity.doc_epoch = 1
        observer.identity.frame, observer.identity.loader = 'frame', 'loader'
        observer.identity._fail('verification_required')
        observer.begin_manual_wait()
        identity = observer.identity
        url = 'https://edith.xiaohongshu.com/api/sns/web/v2/user/me'
        identity.response_received(json.dumps({'requestId': 'old', 'frameId': 'frame',
            'loaderId': 'loader', 'response': {'url': url, 'status': 200}}))
        self.assertIsNone(identity.bind_candidate({}))
        self.assertEqual(identity.code, 'pending')
        identity.request_will_be_sent(json.dumps({'requestId': 'fresh', 'frameId': 'frame',
            'loaderId': 'loader', 'type': 'Fetch', 'request': {'url': url, 'method': 'GET'}}))
        identity.request_extra_info(json.dumps({'requestId': 'fresh',
            'headers': {'Cookie': 'a1=synthetic-a; [REDACTED:cookie_kv]; [REDACTED:cookie_kv]'}}))
        identity.response_received(json.dumps({'requestId': 'fresh', 'frameId': 'frame',
            'loaderId': 'loader', 'response': {'url': url, 'status': 200}}))
        self.assertEqual(identity.loading_finished(json.dumps({'requestId': 'fresh',
            'encodedDataLength': 100})), 'fresh')
        identity.response_body('fresh', json.dumps({'base64Encoded': False,
            'body': json.dumps({'success': True, 'data': {'is_guest': False,
            'user_id': 'owner', 'nickname': 'Synthetic'}})}))
        self.assertEqual(identity.code, 'identity_observed')
        self.assertIsNotNone(identity.bind_candidate({'a1': 'synthetic-a',
            'webId': 'synthetic-web', 'web_session': 'synthetic-session'}))

    def test_reset_retains_job_and_document_but_invalidates_old_evidence(self):
        observer = NativeLoginObserver(None, job_id='a' * 24, bound_uid='owner')
        observer.attached = True
        old = observer.identity
        old.doc_epoch, old.task_epoch, old.generation = 3, 2, 7
        old.frame, old.loader = 'frame', 'loader'
        old._fail('verification_required')
        observer._pending = [('stale', object())]
        observer.begin_manual_wait()
        current = observer.identity
        self.assertIsNot(current, old)
        self.assertEqual((current.job_id, current.bound_uid), ('a' * 24, 'owner'))
        self.assertEqual((current.doc_epoch, current.task_epoch, current.generation), (3, 3, 7))
        self.assertEqual((current.frame, current.loader), ('frame', 'loader'))
        self.assertEqual(current.code, 'pending')
        self.assertEqual(observer._pending, [])
        self.assertIsNone(current.bind_candidate({}))

    def test_reset_cannot_resurrect_cancelled_or_closed_observer(self):
        for closed, code in ((False, 'cancelled'), (True, 'verification_required')):
            observer = NativeLoginObserver(None, job_id='a' * 24)
            observer.attached = True
            observer.closed = closed
            observer.identity._fail(code)
            with self.assertRaises(NativeLoginError):
                observer.begin_manual_wait()


class SessionGuardWiringTests(unittest.TestCase):
    def test_real_session_guard_propagates_each_cancel_path_and_parent_ipc_loss(self):
        from assistant import xhs_session_window as session_window
        from xhs_page_window import BridgeSpec
        for reason in ('local_cancel', 'bridge_cancel', 'parent_ipc_expired'):
            with self.subTest(reason=reason), tempfile.TemporaryDirectory() as temp:
                root = Path(temp)
                job_id = 'b' * 24
                spec_path = root / 'work' / 'xhs-page-bridge' / job_id / 'spec.json'
                spec_path.parent.mkdir(parents=True)
                stage = root / 'work' / 'browser-login' / job_id
                stage.mkdir(parents=True)
                bridge_cancel = spec_path.parent / 'cancel.flag'
                spec = BridgeSpec('http://127.0.0.1:1', 'synthetic', 'tenant', 'account',
                    'owner', root / 'xhs-browser-profile', bridge_cancel, spec_path,
                    'natural', 'session_recovery')
                expired = [False]
                def ipc(spec_arg, route, body, **kwargs):
                    if route == '/connect':
                        return {'session_token': 's' * 32}
                    if route == '/poll':
                        return {'ok': True, 'action': 'session_recovery',
                                'call_id': 'recover', 'task_epoch': 1}
                    if route == '/session_current':
                        if expired[0]:
                            raise ConnectionError('synthetic parent transport stopped')
                        return {'action': 'continue'}
                    return {}
                def owned_window_boundary(**kwargs):
                    observer = Observer()
                    observer.native = None
                    window = Window()
                    kwargs['before_navigation'](window, observer)
                    controller = LoginWindowController(mode='live',
                        initial_url='https://www.xiaohongshu.com/explore',
                        staging_root=stage, cancel_file=kwargs['cancel_file'],
                        guard=kwargs['guard'], natural_observer=observer)
                    controller.attach(window)
                    controller.check_authenticated()
                    self.assertEqual(controller.phase, 'manual_verification_required')
                    before = observer.polls
                    if reason == 'local_cancel':
                        (stage / 'cancel.flag').touch()
                    elif reason == 'bridge_cancel':
                        bridge_cancel.touch()
                    else:
                        expired[0] = True
                    controller.check_authenticated()
                    self.assertTrue(controller.finished.is_set())
                    self.assertEqual(window.destroyed, 1)
                    self.assertEqual(observer.polls, before)
                    self.assertEqual(controller.finish_count, 0)
                    return controller.phase
                with patch.object(session_window, '_post', side_effect=ipc), \
                     patch.object(session_window, 'run_login_window', side_effect=owned_window_boundary), \
                     patch('owned_window_sources.collect_window_facts', return_value={}):
                    code = session_window.run_session_recovery_window(spec)
                self.assertEqual(code, 'cancelled' if reason == 'local_cancel' else 'safety_hold')


if __name__ == '__main__':
    unittest.main()
