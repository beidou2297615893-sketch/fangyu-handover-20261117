"""Owned WebView2 passive natural getMe observer for one login job.

The page sends its own getMe. Native CDP only observes request, request
extra-info, response and body; this component never sends a platform request.
"""

from __future__ import annotations

import json
from threading import RLock
import time

from owned_natural_reader import _NativeOwner

from .login_natural_identity import LoginNaturalIdentity, _site_url


class NativeLoginError(RuntimeError):
    def __init__(self, code):
        self.code = code
        super().__init__(code)


class NativeLoginObserver:
    def __init__(self, window, *, job_id: str, bound_uid: str | None = None,
                 native=None):
        self.window = window
        self.identity = LoginNaturalIdentity(job_id, bound_uid=bound_uid)
        self.native = native
        self.lock = RLock()
        self.attached = False
        self.closed = False
        self.current_url = 'about:blank'
        self._pending = []
        self._refs = None

    def attach(self):
        if self.closed or self.attached:
            raise NativeLoginError('native_state_invalid')
        deadline = time.monotonic() + 6
        while True:
            try:
                if self.native is None:
                    self.native = _NativeOwner(self.window)
                self.native.invoke(self._attach_ui)
                break
            except Exception as error:
                if self.native is None and time.monotonic() < deadline:
                    time.sleep(.1)
                    continue
                if isinstance(error, NativeLoginError) and error.code == 'native_pending' and time.monotonic() < deadline:
                    time.sleep(.1)
                    continue
                raise NativeLoginError('native_cdp_unavailable') from None
        try:
            task = self._enable_task
            if not task.Wait(10000) or task.IsCanceled or task.IsFaulted:
                raise NativeLoginError('native_cdp_unavailable')
            _ = task.Result
        except NativeLoginError:
            self.close()
            raise
        except Exception:
            self.close()
            raise NativeLoginError('native_cdp_unavailable') from None
        self.attached = True
        return self

    def _attach_ui(self):
        control, core = self.native.core()
        if core is None or not str(core.Source):
            raise NativeLoginError('native_pending')
        if str(core.Source) != 'about:blank':
            raise NativeLoginError('native_initial_source_invalid')
        receivers = []

        def subscribe(name, handler):
            receiver = core.GetDevToolsProtocolEventReceiver(name)
            receiver.DevToolsProtocolEventReceived += handler
            receivers.append((receiver, handler))

        def navigation(_sender, args):
            uri = str(args.Uri)
            with self.lock:
                if self.closed or not _site_url(uri):
                    args.Cancel = True
                    self.identity._fail('document_untrusted')
                    return
                self.current_url = uri
                self.identity.navigate(uri)
                self._pending.clear()

        def request(_sender, args):
            with self.lock:
                if not self.closed:
                    self.identity.request_will_be_sent(
                        str(args.ParameterObjectAsJson), session_id=str(args.SessionId))

        def extra(_sender, args):
            with self.lock:
                if not self.closed:
                    self.identity.request_extra_info(
                        str(args.ParameterObjectAsJson), session_id=str(args.SessionId))

        def response(_sender, args):
            with self.lock:
                if not self.closed:
                    self.identity.response_received(
                        str(args.ParameterObjectAsJson), session_id=str(args.SessionId))

        def finished(_sender, args):
            with self.lock:
                if self.closed:
                    return
                rid = self.identity.loading_finished(
                    str(args.ParameterObjectAsJson), session_id=str(args.SessionId))
                if rid:
                    try:
                        task = core.CallDevToolsProtocolMethodAsync(
                            'Network.getResponseBody',
                            json.dumps({'requestId': rid}, separators=(',', ':')))
                        self._pending.append((rid, task))
                    except Exception:
                        self.identity._fail('body_unavailable')

        control.NavigationStarting += navigation
        try:
            subscribe('Network.requestWillBeSent', request)
            subscribe('Network.requestWillBeSentExtraInfo', extra)
            subscribe('Network.responseReceived', response)
            subscribe('Network.loadingFinished', finished)
            self._enable_task = core.CallDevToolsProtocolMethodAsync(
                'Network.enable', json.dumps({'maxResourceBufferSize': 4 * 1024 * 1024,
                                              'maxTotalBufferSize': 8 * 1024 * 1024,
                                              'maxPostDataSize': 0}, separators=(',', ':')))
        except Exception:
            control.NavigationStarting -= navigation
            for receiver, handler in receivers:
                receiver.DevToolsProtocolEventReceived -= handler
            raise NativeLoginError('native_cdp_unavailable') from None
        self._refs = (control, navigation, receivers)

    def poll(self):
        with self.lock:
            if not self.attached or self.closed:
                return 'native_state_invalid'
            remaining = []
            for rid, task in self._pending:
                if not task.IsCompleted:
                    remaining.append((rid, task))
                    continue
                if task.IsCanceled or task.IsFaulted:
                    self.identity._fail('body_unavailable')
                    continue
                try:
                    raw = str(task.Result)
                except Exception:
                    self.identity._fail('body_unavailable')
                    continue
                self.identity.response_body(rid, raw)
            self._pending = remaining
            return self.identity.code

    def begin_manual_wait(self):
        """Keep native subscriptions and document, discard all pre-challenge proof.

        This does not navigate, solve a challenge, reload or send a request.
        Only subsequent page-generated identity traffic can supply new proof.
        """
        with self.lock:
            if self.closed or not self.attached or self.identity.code != 'verification_required':
                raise NativeLoginError('native_state_invalid')
            previous = self.identity
            identity = LoginNaturalIdentity(previous.job_id, bound_uid=previous.bound_uid)
            identity.doc_epoch = previous.doc_epoch
            identity.task_epoch = previous.task_epoch + 1
            identity.generation = previous.generation
            identity.frame, identity.loader = previous.frame, previous.loader
            self._pending.clear()
            self.identity = identity

    def bind_candidate(self, cookies: dict):
        self.poll()
        try:
            source = self.native.invoke(lambda: str(self.native.core()[1].Source))
        except Exception:
            return None
        with self.lock:
            if self.identity.code != 'identity_observed':
                return None
            if source != self.current_url or not _site_url(source):
                return None
            evidence = self.identity.bind_candidate(cookies)
            if evidence is None or not self.identity.evidence_current(evidence, cookies):
                return None
            return evidence

    def evidence_current(self, evidence: dict, cookies: dict) -> bool:
        self.poll()
        try:
            source = self.native.invoke(lambda: str(self.native.core()[1].Source))
        except Exception:
            return False
        with self.lock:
            return (source == self.current_url and _site_url(source)
                    and self.identity.evidence_current(evidence, cookies))

    def cancel(self):
        with self.lock:
            self.identity.cancel()
            self._pending.clear()

    def close(self):
        with self.lock:
            if self.closed:
                return
            self.closed = True
            refs, self._refs = self._refs, None
            self._pending.clear()
        if refs is None:
            return
        control, navigation, receivers = refs
        def detach():
            control.NavigationStarting -= navigation
            for receiver, handler in receivers:
                receiver.DevToolsProtocolEventReceived -= handler
        try:
            self.native.invoke(detach)
        except Exception:
            pass
