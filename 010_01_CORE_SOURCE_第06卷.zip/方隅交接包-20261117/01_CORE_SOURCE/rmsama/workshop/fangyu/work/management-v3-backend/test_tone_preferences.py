"""Real local Backend and original central Cloud fixture; no real outbound."""
from copy import deepcopy
import concurrent.futures
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import tempfile
import time
import unittest
from unittest.mock import patch

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
sys.dont_write_bytecode=True
spec=importlib.util.spec_from_file_location('tone_central_fixture',ROOT/'work/central-store-config/test_central_client.py')
central=importlib.util.module_from_spec(spec);spec.loader.exec_module(central)
from workbench_backend import WorkbenchBackend,WorkbenchError,TONE_PREF_ENTITY,_digest


class TonePreferencesTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(dir=HERE)
        self.cloud=central.Cloud()
        self.outbound=patch('integrations.request_json',side_effect=self.cloud)
        self.outbound.start()
        self.company={'id':'fangyu-apartment-client','edition':'customer','personalMode':False,'authMode':'managed',
            'managedWorkspace':{'environment_id':'central-fixture','endpoint':'https://example.invalid/workspace'}}
        self.backends=[];self.backend=self.open_backend()
        logged=self.login();self.token=logged['token']
        self.a,self.b=[row['id'] for row in self.cloud.manifest['stores'] if row['status']!='expired'][:2]
        self.choose(self.a)

    def tearDown(self):
        for backend in self.backends:backend.close()
        self.outbound.stop();self.temp.cleanup()

    def open_backend(self):
        backend=WorkbenchBackend(ROOT,self.temp.name,self.company)
        self.backends.append(backend);return backend

    def login(self):
        return self.backend.dispatch('login',{'username':'fixture-admin' if self.cloud.role=='admin' else 'fixture-operator',
            'password':'[REDACTED:assigned_secret]'})

    def choose(self,store):
        boot=self.backend.dispatch('bootstrap',{},self.token)
        return self.backend.dispatch('select_store',{'storeId':store,'expectedRevision':boot['selection']['revision']},self.token)

    def read(self,backend=None,**data):
        return (backend or self.backend).dispatch('tone_preferences_read',{'storeId':self.a,**data},self.token)['preferences']

    def payload(self,**data):
        return {'storeId':self.a,'expectedRevision':0,'identity':'方隅公寓前台顾问','tone':'friendly',
            'salutation':'你好','focus':['budget','moveIn','housing'],**data}

    def save(self,backend=None,**data):
        return (backend or self.backend).dispatch('tone_preferences_save',self.payload(**data),self.token)['preferences']

    def assert_error(self,action,data,code=None,status=None,token=None):
        with self.assertRaises(WorkbenchError) as caught:
            self.backend.dispatch(action,data,self.token if token is None else token)
        if code:self.assertEqual(caught.exception.code,code)
        if status:self.assertEqual(caught.exception.status,status)

    def test_default_read_save_shared_reopen_and_store_isolation(self):
        self.assertEqual(self.read(),{'actor':{'username':'fixture-admin','storeId':self.a},'revision':0,
            'identity':'','tone':'friendly','salutation':'你好','focus':['budget','moveIn','housing']})
        self.assertEqual(self.backend.core.store.list(TONE_PREF_ENTITY),[])
        untouched={name:self.backend.core.store.list(name) for name in ('accounts','tasks','leads','replies','keyword_libraries','tenants')}
        saved=self.save(identity='  门店房源顾问  ',tone='patient',salutation=' 您好 ',focus=['housing','budget'])
        self.assertEqual(saved['revision'],1);self.assertEqual(saved['identity'],'门店房源顾问')
        self.assertEqual(saved['salutation'],'您好')
        reopened=self.open_backend();self.assertEqual(self.read(reopened),saved)
        self.choose(self.b);self.assertEqual(self.read(storeId=self.b)['revision'],0)
        self.backend.dispatch('tone_preferences_save',self.payload(storeId=self.b,identity='第二店顾问',focus=[]),self.token)
        self.choose(self.a);self.assertEqual(self.read(),saved)
        self.assertEqual(len(self.backend.core.store.list(TONE_PREF_ENTITY)),2)
        for name,rows in untouched.items():self.assertEqual(self.backend.core.store.list(name),rows,name)
        self.assertEqual(set(self.cloud.calls),{'login','me','store_config_read'})
        self.backend.close();self.backend=self.open_backend()
        self.assertEqual(self.read(),saved)

    def test_strict_input_rejects_missing_unknown_controls_lengths_repeats_and_bool_revision(self):
        cases=[{'identity':''},{'identity':'   '},{'identity':'x'*81},{'identity':'a\nb'},
            {'identity':'a\u2028b'},{'identity':'a\u202eb'},{'salutation':'a\tb'},
            {'salutation':'a\x7fb'},{'salutation':'x'*21},{'tone':'sales'},
            {'focus':['budget','budget']},{'focus':['other']},{'focus':[{}]},
            {'focus':'budget'},{'expectedRevision':True},{'expectedRevision':-1},
            {'extra':True},{'storeId':'../other'}]
        for change in cases:
            with self.subTest(change=change):self.assert_error('tone_preferences_save',self.payload(**change),'INPUT_INVALID',400)
        missing=self.payload();missing.pop('salutation')
        self.assert_error('tone_preferences_save',missing,'INPUT_INVALID',400)
        self.assert_error('tone_preferences_read',{'storeId':self.a,'role':'admin'},'INPUT_INVALID',400)
        self.assert_error('tone_preferences_read',{},'INPUT_INVALID',400)
        self.assertEqual(self.backend.core.store.list(TONE_PREF_ENTITY),[])

    def test_admin_cannot_read_or_save_cross_selected_store(self):
        self.assert_error('tone_preferences_read',{'storeId':self.b},'STORE_FORBIDDEN',403)
        self.assert_error('tone_preferences_save',self.payload(storeId=self.b),'STORE_FORBIDDEN',403)
        self.assertEqual(self.backend.core.store.list(TONE_PREF_ENTITY),[])

    def test_assigned_operator_reads_shared_preferences_but_cannot_write_and_revoked_scope_denies_read(self):
        saved=self.save()
        self.cloud.role='operator';self.cloud.grants=[self.a]
        self.token=self.login()['token']
        read=self.read();self.assertEqual(read['identity'],saved['identity'])
        self.assertEqual(read['actor'],{'username':'fixture-operator','storeId':self.a})
        self.assert_error('tone_preferences_save',self.payload(expectedRevision=1),'ADMIN_REQUIRED',403)
        self.cloud.grants=[]
        self.assert_error('tone_preferences_read',{'storeId':self.a},status=403)
        self.assertEqual(len(self.backend.core.store.list(TONE_PREF_ENTITY)),1)

    def test_expired_missing_cloud_revoked_and_bad_central_version_cannot_write(self):
        self.assert_error('tone_preferences_save',self.payload(),status=401,token='')
        from integrations import IntegrationError
        def revoked(url,data,token=''):
            error=IntegrationError('synthetic user session revoked');error.http_status=401;raise error
        with patch('integrations.request_json',side_effect=revoked):
            self.assert_error('tone_preferences_save',self.payload(),'AUTH_REQUIRED',401)
        self.cloud.detail_bad=True
        self.assert_error('tone_preferences_save',self.payload(),'WORKSPACE_DATA_UNAVAILABLE',503)
        self.cloud.detail_bad=False
        self.cloud.unavailable=True
        self.assert_error('tone_preferences_save',self.payload(),status=403)
        self.cloud.unavailable=False
        with self.backend.core.store.connect() as db:
            db.execute('UPDATE sessions SET expires=0')
        self.assert_error('tone_preferences_save',self.payload(),status=401)
        self.assertEqual(self.backend.core.store.list(TONE_PREF_ENTITY),[])
        self.backend.close()
        self.assert_error('tone_preferences_read',{'storeId':self.a},'BACKEND_CLOSED',503)

    def test_concurrent_same_revision_commits_once_and_reopen_keeps_winner(self):
        other=self.open_backend()
        def write(backend):
            try:return self.save(backend)['revision']
            except WorkbenchError as error:return error.code
        with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
            results=list(pool.map(write,[self.backend,other]))
        self.assertCountEqual(results,[1,'TONE_REVISION_CONFLICT'])
        self.assertEqual(self.read(self.open_backend())['revision'],1)
        self.assert_error('tone_preferences_save',self.payload(),'TONE_REVISION_CONFLICT',409)
        self.assertEqual(len(self.backend.core.store.list(TONE_PREF_ENTITY)),1)

    def test_atomic_recheck_refuses_session_expiring_during_central_lookup(self):
        original=self.cloud.__call__
        def expire_on_config(url,data,token=''):
            result=original(url,data,token)
            if data['operation']=='store_config_read' and data.get('store_id'):
                with self.backend.core.store.connect() as db:db.execute('UPDATE sessions SET expires=0')
            return result
        with patch('integrations.request_json',side_effect=expire_on_config):
            self.assert_error('tone_preferences_save',self.payload(),'AUTH_REQUIRED',401)
        self.assertEqual(self.backend.core.store.list(TONE_PREF_ENTITY),[])

    def test_atomic_recheck_refuses_selection_changed_during_central_lookup(self):
        original=self.cloud.__call__;changed=False
        def switch_on_config(url,data,token=''):
            nonlocal changed
            result=original(url,data,token)
            if not changed and data['operation']=='store_config_read' and data.get('store_id'):
                changed=True
                user=self.backend.core.session(self.token)
                pref_id=self.backend._preference_id(user)
                row=self.backend.core.store.get('ui_workbench_preferences_v1',pref_id)
                row['storeId']=self.b;row['revision']+=1
                self.backend.core.store.put('ui_workbench_preferences_v1',row)
            return result
        with patch('integrations.request_json',side_effect=switch_on_config):
            self.assert_error('tone_preferences_save',self.payload(),'STORE_FORBIDDEN',403)
        self.assertEqual(self.backend.core.store.list(TONE_PREF_ENTITY),[])


if __name__=='__main__':unittest.main(verbosity=2)
