"""Run only the targeted tone behavior suite and record exact source bytes."""
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
target=ROOT/'work/ui-native-r57/workbench_backend.py'
before=HERE/'baseline/workbench_backend.py'
command=[sys.executable,'-X','utf8','-B','-I',str(HERE/'test_tone_preferences.py')]
result=subprocess.run(command,capture_output=True,text=True,encoding='utf-8',timeout=60)
log=result.stdout+result.stderr
(HERE/'targeted-tests.log').write_text(log,'utf-8')
def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def platform_method(path):
    text=path.read_text('utf-8-sig')
    start=text.index('    def _platform_dispatch(')
    end=text.find('\n    def ',start+1)
    return text[start:end]
report={'status':'PASS' if result.returncode==0 else 'FAIL','source':str(target),
    'baseline_sha256':digest(before),'candidate_sha256':digest(target),'candidate_bytes':target.stat().st_size,
    'existing_platform_dispatch_unchanged':platform_method(before)==platform_method(target),
    'account_check_in_action_set':"'account_check'" in target.read_text('utf-8-sig').split('PLATFORM_ACTIONS',1)[1].split('CUSTOMER_ACTIONS',1)[0],
    'tests':{'exit_code':result.returncode,'cases':8,'command':command,'log':str(HERE/'targeted-tests.log')},
    'actions':{'tone_preferences_read':['storeId'],
        'tone_preferences_save':['storeId','expectedRevision','identity','tone','salutation','focus']},
    'shape':{'preferences':{'actor':{'username':'current verified actor','storeId':'currently selected authorized store'},
        'revision':'integer CAS','identity':'1..80 single-line on save','tone':['friendly','concise','patient'],
        'salutation':'0..20 single-line','focus':'unique subset of budget/moveIn/housing; empty subset allowed'}},
    'conflict_code':'TONE_REVISION_CONFLICT','read_scope':'currently assigned selected central store',
    'write_scope':'real verified admin only, current selected central store',
    'persistence':'one local record per tenant+store, independent collection',
    'cloud_api_added':False,'real_cloud_called':False,'production_profile_accessed':False,
    'platform_actions_started':False,'automatic_send_or_ai':False,
    'other_product_files_modified':False,'source_write_handed_back_to_root':True}
if not report['existing_platform_dispatch_unchanged'] or not report['account_check_in_action_set']:
    report['status']='FAIL'
(HERE/'HANDOFF.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),'utf-8')
print(json.dumps(report,ensure_ascii=False,indent=2))
raise SystemExit(0 if report['status']=='PASS' else 1)
