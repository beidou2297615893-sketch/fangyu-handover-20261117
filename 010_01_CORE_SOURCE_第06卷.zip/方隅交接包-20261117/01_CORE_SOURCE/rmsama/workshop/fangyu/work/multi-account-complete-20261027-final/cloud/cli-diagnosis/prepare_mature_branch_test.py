from pathlib import Path
D=Path(__file__).resolve().parent
s=(D/'test_cli_branch.cjs').read_text('utf-8-sig')
s=s.replace("config:configured?{functions:[{name:'fangyu-workspace',dir:'.'}],functionRoot:dir}:{}","config:configured?JSON.parse(fs.readFileSync(__dirname+'/submit-v3/cloudbaserc.json','utf8')):{}")
s=s.replace("assert.equal(o.func.name,'fangyu-workspace');","assert.equal(o.func.name,'fangyu-workspace');if(configured){assert.equal(o.func.installDependency,false);assert.deepEqual(Array.from(o.func.ignore),[]);}")
(D/'test_mature_config_branch.cjs').write_text(s,'utf-8')
