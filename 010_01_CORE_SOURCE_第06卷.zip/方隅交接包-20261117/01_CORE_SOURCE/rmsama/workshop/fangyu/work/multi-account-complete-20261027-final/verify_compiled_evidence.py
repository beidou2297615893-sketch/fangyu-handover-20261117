"""Combine successful cases without changing any earlier failed run."""
from pathlib import Path
import hashlib,json
T=Path(__file__).resolve().parent
ORIGINAL=T.parent/'multi-account-complete-20261026'
read=lambda p:json.loads(p.read_text('utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()

def main():
    folder=ORIGINAL/'binary-e2e'
    a=read(folder/'compiled-05/RESULT.json');b=read(folder/'compiled-06/RESULT.json')
    assert a['status']=='FAIL' and b['status']=='PASS'
    first={c['kind']:c for c in a['cases']};second={c['kind']:c for c in b['cases']}
    assert set(first)=={'read','send'} and set(second)=={'wrong-uid','response-conflict'}
    cases={**first,**second}
    assert all(c['status']=='PASS' for c in cases.values())
    assert cases['read']['view']['profile']['identitySource']=='request_bound_subject'
    assert len(cases['read']['wires'])==4 and all(w['method']=='GET' for w in cases['read']['wires'])
    assert cases['read']['applied']['applied'] is True
    assert cases['send']['view']['items'][0]['status']=='sent'
    assert [w['method'] for w in cases['send']['wires']]==['GET','POST']
    assert cases['send']['view']['items'][0]['actualUid']=='2'*24
    assert cases['wrong-uid']['view']['items'][0]['status']=='approved'
    assert [w['method'] for w in cases['wrong-uid']['wires']]==['GET']
    assert cases['response-conflict']['view']['items'][0]['status']=='unknown'
    assert [w['method'] for w in cases['response-conflict']['wires']]==['GET','POST']
    for v in (a,b):
        assert v['platformCalls']==v['modelCalls']==0 and not v['productionWrites'] and not v['productionDataRead']
    for c in cases.values():
        assert all(w['peer']=='127.0.0.1' and w['forwarded'] is False for w in c['wires'])
    executable=ORIGINAL/'component-v3/artifacts/platform-cli-customer-read/platform-cli-customer-read.exe'
    digest=sha(executable)
    assert digest=='998831579f4f2a729039d3d0924d69fb9da09f820e965403a93681ed03452d31'
    for run in ('compiled-05','compiled-06'):
        registration=read(folder/run/'SYNTHETIC-COMPONENT-REGISTRATION.json')['manifest']
        assert registration['executableSha256']==digest
    if (T/'FROZEN-PINS.json').exists():
        pins=read(T/'FROZEN-PINS.json');material=read(Path(pins['release'])/'reviewed_reply_materials.json')
        assert material['executableSha256']==digest
        assert sha(Path(pins['project'])/material['executable'])==digest
    result=dict(status='PASS_FOUR_COMPILED_CASES',componentSha256=digest,
        cases={kind:dict(status='PASS',sourceRun='compiled-05' if kind in first else 'compiled-06',methods=[w['method'] for w in case['wires']]) for kind,case in cases.items()},
        evidence={run:sha(folder/run/'RESULT.json') for run in ('compiled-05','compiled-06')},
        priorFailedRunsPreserved=True,reusedEvidenceRoot=str(ORIGINAL),freshRealPlatformExecution=False,compiled05OverallStatus='FAIL',
        realPlatformRequests=0,realModelCalls=0,productionDataAccess=False,
        boundary='Fixed executable with non-forwarding local TLS fixture; actual cloud permission covered separately by authenticated synthetic tests.')
    target=T/'evidence/compiled-acceptance.json'
    target.parent.mkdir(exist_ok=True)
    if target.exists():assert read(target)==result
    else:target.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n','utf-8')
    print(json.dumps(result,ensure_ascii=True))
if __name__=='__main__':main()
