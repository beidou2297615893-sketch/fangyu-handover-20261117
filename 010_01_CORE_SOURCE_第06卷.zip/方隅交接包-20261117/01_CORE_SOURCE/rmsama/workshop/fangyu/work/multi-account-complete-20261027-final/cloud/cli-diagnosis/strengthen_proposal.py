from pathlib import Path
import ast,json,hashlib
D=Path(__file__).resolve().parent;p=D/'submit_code_only_v2.py';s=p.read_text('utf-8-sig')
needle='def protected(obj):'
index=s.index(needle)
s=s[:index]+"""def explicit_code_updated(stdout):
 raw=re.sub(r'\\x1b\\[[0-9;]*[a-zA-Z]','',stdout.decode('utf-8',errors='replace'))
 if len(raw)>1048576:return False
 decoder=json.JSONDecoder();found=[]
 for match in re.finditer(r'\\{',raw):
  try:value,_=decoder.raw_decode(raw,match.start())
  except ValueError:continue
  if isinstance(value,dict) and set(value).issubset({'data','meta'}) and isinstance(value.get('data'),dict) and value['data']=={'message':'Code updated'}:found.append(value)
 return len(found)==1

"""+s[index:]
s=s.replace("report['cliReportedCodeUpdated']=b'Code updated' in run.stdout","report['cliReportedCodeUpdated']=explicit_code_updated(run.stdout)")
s=s.replace("'SUBMITTED_NEEDS_READBACK' if run.returncode==0 else", "'SUBMITTED_NEEDS_READBACK' if run.returncode==0 and report['cliReportedCodeUpdated'] else")
needle="  after=protected(api('GetFunction',{'FunctionName':FN,'Namespace':ENV,'ShowCode':'FALSE'}))"
s=s.replace(needle,"  try:local_material(composition);report['localCandidateUnchanged']=True\n  except Exception:report['localCandidateUnchanged']=False\n"+needle)
s=s.replace("if before==after and checked['status']=='PASS' else", "if before==after and checked['status']=='PASS' and report.get('cliReportedCodeUpdated') is True and report.get('localCandidateUnchanged') is True else")
ast.parse(s);p.write_text(s,'utf-8')
# Exercise just the pure parser AST; never import the proposed deployment script.
tree=ast.parse(s);node=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='explicit_code_updated')
import re
scope={'re':re,'json':json};exec(compile(ast.Module(body=[node],type_ignores=[]),'<pure-parser-test>','exec'),scope);f=scope['explicit_code_updated']
assert f(b'logs\n{"data":{"message":"Code updated"}}')
for payload in (b'',b'Code updated',b'{"message":"Code updated"}',b'{"data":{"message":"other"}}',b'{"data":{"message":"Code updated","extra":true}}'):assert not f(payload)
r=json.loads((D/'DIAGNOSIS.json').read_text('utf-8'));r['proposedV2ScriptSha256']=hashlib.sha256(p.read_bytes()).hexdigest();r['strictSuccessParserTests']=6;r['managerCodeAPIOnly']=True;r['dependencyCaveat']='CLI preserves live InstallDependency. If TRUE, packer omits node_modules and remote retains its dependency installation behavior; require full ZIP tree equality afterward; no assertion of dependency byte preservation before actual readback.';(D/'DIAGNOSIS.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n','utf-8')
print(json.dumps({'scriptSha256':r['proposedV2ScriptSha256'],'strictParserTests':6,'executedDeploymentScript':False}))
