from pathlib import Path
import subprocess,json,re,hashlib
D=Path(__file__).resolve().parent
argv=['C:/Program Files/nodejs/node.exe','C:/Users/rmsama/AppData/Roaming/npm/node_modules/@cloudbase/cli/bin/tcb','fn','list','-e','fh6-d5ga45c0ddae7008c','--json']
r=subprocess.run(argv,capture_output=True,timeout=75,cwd=D/'submit-v2')
raw=re.sub(r'\x1b\[[0-9;]*[a-zA-Z]','',(r.stdout+b'\n'+r.stderr).decode('utf-8',errors='replace'))
signals={name:(needle.lower() in raw.lower()) for name,needle in [('schema','schema'),('validation','validat'),('required','required'),('envId','envId'),('functionRoot','functionRoot'),('dir','"dir"'),('unknownProperty','unknown'),('configuration','配置'),('login','登录'),('ReferenceError','ReferenceError'),('TypeError','TypeError'),('SyntaxError','SyntaxError'),('CannotFindModule','Cannot find module'),('zod','Zod'),('permission','permission'),('tcbError','CloudBaseError')]}
codes=[]
for pattern in [r'"(?:code|errorCode|ErrorCode)"\s*:\s*"([A-Za-z][A-Za-z0-9_.-]{0,90})"',r'\b((?:Type|Syntax|Reference|Validation|Zod|CloudBase)Error)\b']:
 codes+=re.findall(pattern,raw)
# Keep only bounded non-sensitive snippets surrounding known validation field
# names. Each snippet is mapped to a fixed diagnostic phrase, never persisted.
phrases=[]
for token in ('envId','functionRoot','functions','dir'):
 if token in raw and re.search(r'(required|必填|缺少|不能为空)',raw,re.I):phrases.append('validation mentions '+token+' and a required field')
result={'operation':'read-only fn list from exact new config cwd','exitCode':r.returncode,'stdoutBytes':len(r.stdout),'stderrBytes':len(r.stderr),'safeSignals':signals,'errorCodesOrClasses':sorted(set(codes)),'safePhrases':phrases,'rawOutputPersisted':False,'mutatingCommandExecuted':False}
(D/'V2-READONLY-LIST-DIAGNOSTIC.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n','utf-8');print(json.dumps(result,ensure_ascii=False))
