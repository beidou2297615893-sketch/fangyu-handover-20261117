from pathlib import Path
import json,hashlib,ast
N=Path(__file__).resolve().parent
report=json.loads((N/'CONSUMER-HASH-AUDIT.json').read_text('utf-8-sig'))
report['excludedNonClosureOccurrences']=[r for r in report['staleHashOccurrences'] if not (N/'assembly/project'/r['consumer']).is_file()]
report['staleHashOccurrences']=[r for r in report['staleHashOccurrences'] if (N/'assembly/project'/r['consumer']).is_file()]
report['allCurrentConsumerReferencesMatchChangedSources']=not report['staleHashOccurrences']
(N/'CONSUMER-HASH-AUDIT.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n','utf-8')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
files={}
for p in (N/'candidate').rglob('*'):
 if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc':files[p.relative_to(N).as_posix()]={'sha256':sha(p),'size':p.stat().st_size}
scriptnames=('bootstrap.py','assemble_complete.py','freeze_complete.py','review_source_closure.py','verify_next_launch_entry.py','closed_update_guard.py','next_launch_update.py')
for name in scriptnames:ast.parse((N/name).read_bytes())
sourceplan={'status':'OVERLAID_NOT_STAGED','candidateCount':len(files),'files':files,'scripts':{n:sha(N/n) for n in scriptnames},'consumerHashAuditSha256':sha(N/'CONSUMER-HASH-AUDIT.json'),'baselineSourceCount':5987,'plannedOverlayCount':338,'materials':json.loads((N/'assembly/ASSEMBLY.json').read_text('utf-8-sig'))['materials'],'sourcePins':115,'runtimePins':291,'productionEdited':False,'frozen':False}
(N/'FINAL-CANDIDATE-PINS.json').write_text(json.dumps(sourceplan,ensure_ascii=False,indent=2)+'\n','utf-8');print(json.dumps({k:v for k,v in sourceplan.items() if k!='files'}))
