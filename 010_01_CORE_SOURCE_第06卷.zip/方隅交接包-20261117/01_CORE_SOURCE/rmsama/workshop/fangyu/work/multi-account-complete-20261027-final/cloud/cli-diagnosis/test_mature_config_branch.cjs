const fs=require('fs'),vm=require('vm'),path=require('path'),assert=require('assert');
const source='C:/Users/rmsama/AppData/Roaming/npm/node_modules/@cloudbase/cli/dist/standalone/cli.js';
const text=fs.readFileSync(source,'utf8');const start=text.indexOf('let CodeUpdate = class CodeUpdate');const end=text.indexOf('\n__decorate([',start);const body=text.slice(start,end)+'\nCodeUpdate;';
let pending=[];
function __awaiter(thisArg,args,P,generator){return new Promise((resolve,reject)=>{const g=generator.apply(thisArg,args||[]);function step(v){let r;try{r=g.next(v);}catch(e){reject(e);return;}if(r.done)resolve(r.value);else Promise.resolve(r.value).then(step,reject);}step();});}
function runCase(configured,yes){let prompts=0,updates=0,done=false;const dir='D:/reviewed-fixed-source';const context={__awaiter,process:{cwd:()=> 'D:/submit-v2'},common_1:{Command:class{}},path_1:{default:path},fs_1:{default:{existsSync:()=>configured}},inquirer_1:{default:{prompt:()=>{prompts++;return new Promise(()=>{});}}},common_utils_1:{validateImageDeploy:()=>{},resolveFuncPathWithConfig:o=>{assert.equal(o.dir,dir);return dir;},resolveAndValidateFunctionDir:o=>o.dir},i18n_1:{t:x=>x},constant_1:{DefaultFunctionDeployConfig:{}},error_1:{CloudBaseError:Error}};
 const Class=vm.runInNewContext(body,context);const instance=new Class();instance.inferFunctionConfig=()=>null;instance.printFunctionConfig=()=>{};instance.doUpdateCode=async o=>{updates++;assert.equal(o.func.name,'fangyu-workspace');if(configured){assert.equal(o.func.installDependency,false);assert.deepEqual(Array.from(o.func.ignore),[]);}assert.equal(o.functionPath,dir);};
 instance.execute({envId:'fh6-d5ga45c0ddae7008c',config:configured?JSON.parse(fs.readFileSync(__dirname+'/submit-v3/cloudbaserc.json','utf8')):{},options:{dir,deployMode:'cos'},globalOptions:{yes,json:true}},['fangyu-workspace'],{info:()=>{},warn:()=>{}}).then(()=>{done=true;});
 pending.push(()=>({configured,yes,prompts,updates,promiseResolved:done}));
}
runCase(false,false);runCase(false,true);runCase(true,false);
process.on('beforeExit',()=>{const result=pending.map(f=>f());assert.deepEqual(result.map(x=>[x.prompts,x.updates,x.promiseResolved]),[[1,0,false],[1,0,false],[0,1,true]]);console.log(JSON.stringify({status:'PASS_OFFLINE_BUNDLED_CLASS_BRANCH_TEST',realCLIInvoked:false,networkCalls:0,cases:result}));});
