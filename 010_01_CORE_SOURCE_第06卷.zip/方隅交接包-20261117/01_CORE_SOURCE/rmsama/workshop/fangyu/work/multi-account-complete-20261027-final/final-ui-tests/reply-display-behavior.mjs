import assert from 'node:assert/strict';
import {bindConnected} from 'file:///C:/%E7%A7%AF%E6%9C%A8%E8%BD%AF%E4%BB%B6%E5%B7%A5%E5%9D%8A/%E9%A1%B9%E7%9B%AE/%E6%96%B9%E9%9A%85%E5%85%AC%E5%AF%93%E5%AE%A2%E6%88%B7%E7%89%88/work/multi-account-complete-20261027-final/assembly/project/work/ui-approved-implementation/ui-preview/pages/reply-connected.mjs';
import {bindAI,renderAI} from 'file:///C:/%E7%A7%AF%E6%9C%A8%E8%BD%AF%E4%BB%B6%E5%B7%A5%E5%9D%8A/%E9%A1%B9%E7%9B%AE/%E6%96%B9%E9%9A%85%E5%85%AC%E5%AF%93%E5%AE%A2%E6%88%B7%E7%89%88/work/multi-account-complete-20261027-final/assembly/project/work/ui-approved-implementation/ui-preview/pages/reply-ai.mjs';
import {replyScopeBlocked} from 'file:///C:/%E7%A7%AF%E6%9C%A8%E8%BD%AF%E4%BB%B6%E5%B7%A5%E5%9D%8A/%E9%A1%B9%E7%9B%AE/%E6%96%B9%E9%9A%85%E5%85%AC%E5%AF%93%E5%AE%A2%E6%88%B7%E7%89%88/work/multi-account-complete-20261027-final/assembly/project/work/ui-approved-implementation/ui-preview/pages/reply-scope-guard.mjs';
import {makeReplyCustomersState} from './reply-customers-fixture.mjs';
class E{
 constructor(dataset={}){this.dataset=dataset;this.listeners={};this.open=false;this.textContent='';}
 addEventListener(k,f){(this.listeners[k]||=[]).push(f);}
 async fire(k,event={}){for(const f of this.listeners[k]||[])await f(event);}
}
function setup(){
 const state=makeReplyCustomersState({page:'reply',scenario:'ai-done',count:2}),v=state.replyLive;
 v.uiView='manual';v.ai.job.rows.forEach((r,i)=>{r.leadId='lead-'+i;r.customerId=v.items[i].id;});
 const modes=[new E({liveMode:'ai'}),new E({liveMode:'manual'})],store=new E(),platform=new E(),panel=new E();panel.open=true;
 const title=new E(),label=new E(),counter=new E(),count=new E();title.textContent='客户姓名与需求必须保留';
 const rowNodes=v.ai.job.rows.map((r,i)=>new E({aiRowPanel:String(i)}));rowNodes[0].open=true;
 rowNodes[0].querySelector=s=>s==='.rp-ai-customer-state'?label:s==='summary > span'?title:null;
 const input=new E({aiText:'0'});input.value='修改后的已确认回复';input.closest=()=>rowNodes[0];
 const map=new Map([['[data-ref-store]',store],['[data-ref-platform]',platform],['[data-ai-panel]',panel],['[data-ai-text-count="0"]',counter],['[data-ai-confirmed-count]',count]]);
 const root={querySelector:s=>map.get(s)||null,querySelectorAll:s=>s==='[data-live-mode]'?modes:s==='[data-ai-row-panel]'?rowNodes:s==='[data-ai-row-panel][open]'?rowNodes.filter(n=>n.open):s==='[data-ai-text]'?[input]:[]};
 const calls=[],ctx={state,update:fn=>{fn(state);},toast:text=>calls.push(['toast',text]),selectStore:id=>calls.push(['store',id]),switchPlatform:id=>calls.push(['platform',id]),replyRead:async()=>{calls.push(['read']);return {replyWorkspace:v.detail};},modal:()=>{throw Error('Unexpected modal');},deliveryAction:()=>{throw Error('MUST NEVER SEND');}};
 return {state,v,modes,store,platform,panel,title,label,counter,count,rowNodes,input,root,calls,ctx};
}
const locks=[
 ['busy',(s,v)=>v.busy=true],['pending',(s,v)=>v.pending={requestId:'original-request'}],
 ['batchBusy',(s,v)=>v.batchBusy=true],['batchPending',(s,v)=>v.batchPending={requestId:'batch'}],
 ['aiBusy',(s,v)=>v.ai.busy=true],['deliveryBusy',(s,v)=>s.replyDelivery.busy=true],
 ['deliveryAttempt',(s,v)=>s.replyDelivery.attempt={kind:'start',id:'original-delivery'}],
];
for(const [name,lock] of locks){
 const t=setup();bindConnected(t.root,t.ctx);lock(t.state,t.v);
 assert.equal(replyScopeBlocked(t.state,t.v),true,name);
 await t.modes[0].fire('click');assert.equal(t.v.uiView,'manual',name+' must keep the recovery view');
 assert.equal(t.calls.some(c=>['store','platform','read'].includes(c[0])),false,name+' new view switch does not change actor or read');
}
{
 const t=setup();t.state.replyDelivery={plan:{state:'prepared',canStart:true}};
 assert.equal(replyScopeBlocked(t.state,t.v),false,'prepared plan does not lock read-only navigation');
}
{
 const t=setup();t.v.uiView='ai';bindConnected(t.root,t.ctx);t.v.ai.busy=true;t.panel.open=false;
 await t.panel.fire('toggle');assert.equal(t.panel.open,true);assert.equal(t.v.uiView,'ai');
}
{
 const t=setup();t.v.text='未保存人工稿';t.v.dirty=true;const detail=t.v.detail,id=t.v.selectedId,account=t.v.accountId;
 bindConnected(t.root,t.ctx);await t.modes[0].fire('click');assert.equal(t.v.uiView,'ai');await t.modes[1].fire('click');
 assert.equal(t.v.uiView,'manual');assert.equal(t.v.text,'未保存人工稿');assert.equal(t.v.dirty,true);
 assert.equal(t.v.detail,detail);assert.equal(t.v.selectedId,id);assert.equal(t.v.accountId,account);assert.equal(t.calls.length,0);
}
{
 const t=setup();delete t.v.ai;bindConnected(t.root,t.ctx);await t.modes[0].fire('click');
 assert.equal(typeof t.v.ai.tone,'string');assert.doesNotThrow(()=>renderAI(t.state,t.v));
}
{
 const t=setup();const row=t.v.ai.job.rows[0];row.confirmation={state:'confirmed'};t.v.ai.job.confirmationCounts={confirmed:1,pending:0,notStarted:1};
 bindAI(t.root,t.ctx,t.v);await t.input.fire('input');
 assert.equal(t.title.textContent,'客户姓名与需求必须保留');assert.equal(t.label.textContent,'待重新确认');
 assert.equal(t.counter.textContent,t.input.value.length);assert.equal(t.count.textContent,0);
 assert.equal(t.v.ai.job.confirmationCounts.confirmed,0);assert.equal(row.confirmation.state,'not_started');assert.equal(t.calls.length,0);
 t.rowNodes[1].open=true;await t.rowNodes[1].fire('toggle');assert.deepEqual(t.v.ai.openRows,['lead-0','lead-1']);
}
{
 const t=setup(),c=t.v.ai.job.rows[0].context;
 c.root={id:'root-id',author:'根作者唯一名',text:'根评论唯一正文'};
 c.replyTo={id:'direct-id',known:true,author:'',text:'直接目标唯一正文'};
 const html=renderAI(t.state,t.v);
 assert.ok(html.includes('<small>讨论起始评论 · 根作者唯一名</small><span>根评论唯一正文</span>'));
 assert.ok(html.includes('<small>上级评论</small><span>直接目标唯一正文</span>'));
 assert.equal(html.includes('<small>上级评论 · 根作者唯一名</small>'),false);
}
console.log('PASS: 7 new-view locks, prepared-plan navigation, blocked native AI fold, dirty-view preservation, fresh AI defaults, confirmed-edit identity/counts, real lead-ID disclosures, anonymous direct-target attribution; zero writes/sends');

{const t=setup();bindConnected(t.root,t.ctx);t.v.ai.busy=true;await t.platform.fire('change',{target:{value:'douyin'}});assert.ok(t.calls.some(x=>x[0]==='platform'&&x[1]==='douyin'),'relocated platform control delegates to unchanged global action');}
