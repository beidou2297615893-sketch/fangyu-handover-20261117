from pathlib import Path
import ast,json,hashlib
D=Path(__file__).resolve().parent;C=D.parent
config={'functionRoot':str(C/'candidate'),'functions':[{'name':'fangyu-workspace','dir':'.'}]}
(D/'submit-v2/cloudbaserc.json').write_text(json.dumps(config,ensure_ascii=False,indent=2)+'\n','utf-8')
s=(C/'deploy.py').read_text('utf-8-sig')
s=s.replace("D=Path(__file__).resolve().parent","SELF=Path(__file__).resolve()\nD=SELF.parents[1]\nSUBMIT=SELF.parent/'submit-v2'\nsys.path.insert(0,str(D))",1)
s=s.replace("names=('deploy.py','verify_readback.py','read_live_code_once.py','COMPOSITION.json')","names=('cli-diagnosis/submit_code_only_v2.py','cli-diagnosis/submit-v2/cloudbaserc.json','verify_readback.py','read_live_code_once.py','COMPOSITION.json')")
s=s.replace(" return {name:hashlib.sha256((D/name).read_bytes()).hexdigest() for name in names}"," result={name:hashlib.sha256((D/name).read_bytes()).hexdigest() for name in names}\n result['installed_cli_bundle']=hashlib.sha256(Path('C:/Users/rmsama/AppData/Roaming/npm/node_modules/@cloudbase/cli/dist/standalone/cli.js').read_bytes()).hexdigest()\n return result")
s=s.replace("ASTRA_APPROVED_EXACT_CODE_ONLY_DEPLOY","ASTRA_APPROVED_EXACT_CODE_ONLY_DEPLOY_V2_WITH_LOCAL_CONFIG")
for old,new in [('DEPLOY-PREPARED.json','DEPLOY-V2-PREPARED.json'),('DEPLOYMENT.json','DEPLOYMENT-V2.json'),('CONFIG-PROTECTED-BEFORE.json','CONFIG-PROTECTED-V2-BEFORE.json'),('CONFIG-PROTECTED-AFTER.json','CONFIG-PROTECTED-V2-AFTER.json'),('readback-precommit','readback-v2-precommit'),('readback-postcommit','readback-v2-postcommit')]:s=s.replace(old,new)
s=s.replace("'operation':'official fn code update'","'operation':'official fn code update via exact local-config branch'")
needle="  run=subprocess.run([NODE,CLI,'fn','code','update',FN,'--dir',str(D/'candidate'),'--deployMode','cos','-e',ENV,'--json'],capture_output=True,timeout=180,cwd=D)"
replacement="""  expected_config={'functionRoot':str(D/'candidate'),'functions':[{'name':FN,'dir':'.'}]}
  assert json.loads((SUBMIT/'cloudbaserc.json').read_text('utf-8'))==expected_config
  run=subprocess.run([NODE,CLI,'fn','code','update',FN,'--dir',str(D/'candidate'),'--deployMode','cos','-e',ENV,'--json'],capture_output=True,timeout=180,cwd=SUBMIT)
  # Only predefined signals are persisted; never store raw URLs, auth, or output.
  report['cliReportedCodeUpdated']=b'Code updated' in run.stdout"""
assert needle in s;s=s.replace(needle,replacement,1)
ast.parse(s);(D/'submit_code_only_v2.py').write_text(s,'utf-8')
report={'status':'OFFLINE_DIAGNOSIS_AND_PROPOSED_V2_ONLY','cliVersion':'3.5.5','cliBundleSha256':hashlib.sha256(Path('C:/Users/rmsama/AppData/Roaming/npm/node_modules/@cloudbase/cli/dist/standalone/cli.js').read_bytes()).hexdigest(),'cause':'CodeUpdate.updateWithoutConfig unconditionally awaits inquirer.prompt; --json and global --yes do not bypass this branch. Offline extracted installed-class test reproduces unresolved prompt, zero update, normal Node exit. Cloud no-op cause highly consistent, not proved by actual server request tracing.','lineEvidence':{'globalYesDeclaration':186,'updateWithoutConfigPrompt':15881,'doUpdateCodeOnlyCodeHelper':15965,'updateFunctionCodeHelper':40725,'sdkUpdateFunctionCodeRequest':83412,'explicitDirWins':16076},'v2LocalConfig':config,'proposedV2ScriptSha256':hashlib.sha256((D/'submit_code_only_v2.py').read_bytes()).hexdigest(),'configSha256':hashlib.sha256((D/'submit-v2/cloudbaserc.json').read_bytes()).hexdigest(),'externalActions':0,'approvedOriginalScriptsModified':False,'v2Executed':False,'directOfficialAPIAlternative':'tcb api scf UpdateFunctionCode with Namespace/FunctionName, exact known existing Handler/InstallDependency and Code.ZipFile of reviewed ZIP; no UpdateFunctionConfiguration. Requires newly reviewed script/pins and sole-submit authorization before action.'}
(D/'DIAGNOSIS.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n','utf-8');print(json.dumps(report))
