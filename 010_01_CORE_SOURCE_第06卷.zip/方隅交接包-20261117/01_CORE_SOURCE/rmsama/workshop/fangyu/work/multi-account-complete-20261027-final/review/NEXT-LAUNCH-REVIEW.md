# 最终下次启动更新审查

2026-10-27，Astra。

已独立核对 V3 云端成功回执及全部 5619 份读回 manifest、ZIP 实际文件字节，与最终候选完全一致；受保护云配置（含 InstallDependency）前后哈希一致。目标树为 76fa656fa451619b2824cd0dcd9861fcb8d1db1c8ea31b2fe5003bf07bdc5c23。旧提交记录保留，只有 V3 记 VERIFIED_CODE_ONLY_DEPLOYMENT。

新本地固定版本 ui-r57-20261027T010509Z-24a7aafb 已通过 9199 文件独立闭环、45 项集成检查、实际 frozen host 单模块图与完整工厂注册；四个组件场景用同一 v3 二进制在两次合成运行中补齐，来源清楚，不冒充真实平台验收。

独立重新取 updater、generic installer、guard、FROZEN-PINS、BASELINE、最终源码审查、集成结果哈希均一致，并确认目前 canonical 入口仍为原基线。批准文件为 NEXT-LAUNCH-REVIEW.json，所有必要 exact fields 已填。只允许 root 一次执行已审 next_launch_update.py --install：原两入口文件 expected-old CAS、独占备份与冲突保留；来源指向新 assembly，业务数据库只读前后核对；当前实例不关闭、不重启。

安装后须核对 logical snapshot/count/entity hashes、active 状态及实际原入口 check/self-test。此批准不包含真实账号登录、平台发送、GUI 验收或软件分发；下一次用户正常启动时生效。
