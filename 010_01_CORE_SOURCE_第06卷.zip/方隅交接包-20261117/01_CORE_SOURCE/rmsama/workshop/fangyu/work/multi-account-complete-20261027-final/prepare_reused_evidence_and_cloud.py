"""Reuse immutable binary evidence and prepare a fresh code-only cloud candidate."""
from pathlib import Path
import hashlib,json,shutil
N=Path(__file__).resolve().parent;OLD=N.parent/'multi-account-complete-20261026'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
cloud=N/'cloud';assert not cloud.exists();cloud.mkdir()
for name in ('prepare_candidate.py','deploy.py','verify_readback.py','read_live_code_once.py'):
    shutil.copyfile(OLD/'cloud'/name,cloud/name)
shutil.copytree(OLD/'cloud/live-before',cloud/'live-before')
shutil.copytree(OLD/'cloud/candidate',cloud/'candidate')
module=cloud/'candidate/reviewed_reply_release.cjs';text=module.read_text('utf-8')
old_digest='211d8ebfe97e62a63325fc85334f2862e5e3263411a51100b29b2d4c34ef7757'
assert text.count("materialSha256:'"+old_digest+"'")==2
module.write_text(text.replace(old_digest,'PENDING_REVIEWED_SENDER_MATERIAL_SHA256'),'utf-8',newline='')
(cloud/'tests').mkdir()
for p in (OLD/'cloud/tests').iterdir():
    if p.is_file() and p.suffix in ('.cjs','.py'):
        shutil.copyfile(p,cloud/'tests'/p.name)
baseline=json.loads((OLD/'cloud/BASELINE.json').read_text('utf-8-sig'))
baseline['reusedImmutableCodeReadback']={'path':str(OLD/'cloud/readback-before/LIVE-READBACK.json'),'sha256':sha(OLD/'cloud/readback-before/LIVE-READBACK.json'),'note':'Fresh precommit code verification remains mandatory; this is only the candidate source baseline.'}
(cloud/'BASELINE.json').write_text(json.dumps(baseline,ensure_ascii=False,indent=2)+'\n','utf-8')
body=(OLD/'verify_compiled_evidence.py').read_text('utf-8')
body=body.replace("T=Path(__file__).resolve().parent", "T=Path(__file__).resolve().parent\nORIGINAL=T.parent/'multi-account-complete-20261026'")
body=body.replace("folder=T/'binary-e2e'", "folder=ORIGINAL/'binary-e2e'")
body=body.replace("executable=T/'component-v3/", "executable=ORIGINAL/'component-v3/")
body=body.replace("target=folder/'ACCEPTANCE.json'", "target=T/'evidence/compiled-acceptance.json'\n    target.parent.mkdir(exist_ok=True)")
body=body.replace("priorFailedRunsPreserved=True,", "priorFailedRunsPreserved=True,reusedEvidenceRoot=str(ORIGINAL),freshRealPlatformExecution=False,")
(N/'verify_compiled_evidence.py').write_text(body,'utf-8')
report={'status':'PREPARED_ONLY','originalTask':str(OLD),'binaryExecutableSha256':sha(OLD/'component-v3/artifacts/platform-cli-customer-read/platform-cli-customer-read.exe'),'sourceEvidence':{name:sha(OLD/name) for name in ('binary-e2e/compiled-05/RESULT.json','binary-e2e/compiled-06/RESULT.json','review/BINARY-COMPILED-05-REVIEW.md','review/BINARY-COMPILED-06-REVIEW.md')},'sourceCloudModuleBeforeReset':sha(OLD/'cloud/candidate/reviewed_reply_release.cjs'),'cloudSourceUntouchedOriginalFiles':5617,'copiedOldSuccessReports':False,'deploymentExecuted':False}
(N/'REUSED-EVIDENCE-PLAN.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n','utf-8')
print(json.dumps({'status':'PREPARED_FRESH_CLOUD_AND_EVIDENCE_REFERENCES','cloudDeployed':False,'binaryRerun':False}))
