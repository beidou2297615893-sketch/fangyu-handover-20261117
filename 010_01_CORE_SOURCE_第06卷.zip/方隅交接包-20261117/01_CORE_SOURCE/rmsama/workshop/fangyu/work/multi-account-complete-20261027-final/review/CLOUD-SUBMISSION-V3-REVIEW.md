# 原成熟配置的独立第三提交审查

2026-10-27，Astra。

批准 cloud/DEPLOY-V3-APPROVED-PINS.json 精确绑定的一次新提交。V1/V2 记录及旧代码读回保留，不覆盖或改称成功。

V2 缺失 envId，实际官方配置加载器在命令行 -e 覆盖前拒绝；之前离线分支测试没有覆盖配置加载器，这一审核遗漏已明确。V3 精确复用原 192 字节成熟配置，包含目标 envId、functionRoot='.'、唯一函数名、installDependency=false、ignore=[]。同一新 cwd 的真实只读 fn list 已 exit 0；离线实际 CodeUpdate 分支验证 prompt=0/update=1。绝对 --dir 仍明确指向已审 N/cloud/candidate，配置文件位于包外。

已完整对照 V2→V3 diff：仅新目录/批准 schema/日志及读回路径、成熟配置断言、预定义脱敏错误信号。明确 Code updated、InstallDependency FALSE、fresh beforeTree、完整候选与 post ZIP、受保护字段哈希全部保持；新增诊断不持久化 raw stdout/stderr、URL 或凭据。所有六个精确 pins 独立取哈希一致。

批准脚本 19657ebd7b1aea72fc034398b704f954b1a401caaa3caa6b8e563fd0c4619b89，配置 6ddf8cfe2766b09b531819e24c5b4fae30ce581f540523a3c49bf3a598230e3a；目标 afterTree 76fa656fa451619b2824cd0dcd9861fcb8d1db1c8ea31b2fe5003bf07bdc5c23 不变。仅一次 root 提交，不自动重试，不改业务数据库/权限配置，不执行真实登录或平台发送。客户端安装仍须成功代码读回后另批。
