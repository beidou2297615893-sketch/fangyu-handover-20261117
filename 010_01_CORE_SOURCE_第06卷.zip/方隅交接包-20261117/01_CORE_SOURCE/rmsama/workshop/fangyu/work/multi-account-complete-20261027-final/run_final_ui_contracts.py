"""Run the UI owner's synthetic contracts against the assembled client sources."""
from pathlib import Path
import hashlib,json,subprocess,sys
sys.dont_write_bytecode=True
T=Path(__file__).resolve().parent;R=T.parents[1]
source=R/'work/ui-reference-fidelity-20261025/tests'
web=T/'assembly/project/work/ui-approved-implementation/ui-preview'
out=T/'final-ui-tests';out.mkdir(exist_ok=True)
names=['reply-display-behavior.mjs','reply-information-preservation.mjs','settings-ui-preservation.mjs']
dependencies=['reply-customers-fixture.mjs']
pins={}
for name in names+dependencies:
    p=source/name;raw=p.read_bytes();pins[name]=hashlib.sha256(raw).hexdigest()
    text=raw.decode('utf-8-sig')
    # Only relocate module URLs; fixture data and assertions remain byte-equivalent.
    text=text.replace("from '../web/", "from '"+web.as_uri()+'/')
    (out/name).write_text(text,'utf-8')
checks=[]
for name in names:
    run=subprocess.run(['node',str(out/name)],capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=45)
    (out/(name+'.log')).write_text(run.stdout+'\n'+run.stderr,'utf-8')
    checks.append({'name':name,'exitCode':run.returncode})
    print(run.stdout+run.stderr,end='',flush=True)
for name,digest in pins.items():assert hashlib.sha256((source/name).read_bytes()).hexdigest()==digest, 'UI test changed during execution'
(out/'RESULT.json').write_text(json.dumps({'sourceTestSha256':pins,'targetWeb':str(web),'checks':checks,'productionAccess':False,'delivery':False},ensure_ascii=False,indent=2),'utf-8')
raise SystemExit(any(x['exitCode'] for x in checks))
