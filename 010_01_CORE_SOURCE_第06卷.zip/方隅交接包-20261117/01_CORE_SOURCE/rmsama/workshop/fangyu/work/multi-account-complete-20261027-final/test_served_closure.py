"""Exercise the actual native static server without constructing any business backend."""
from pathlib import Path
import hashlib, http.client, importlib.util, json, sys, threading

sys.dont_write_bytecode = True
TASK = Path(__file__).resolve().parent
pins = json.loads((TASK/'FROZEN-PINS.json').read_text('utf-8'))
release = Path(pins['release'])
sys.path.insert(0, str(release))
spec = importlib.util.spec_from_file_location('repair_static_server_test', release/'ui_native_host.py')
host = importlib.util.module_from_spec(spec)
spec.loader.exec_module(host)
manifest, files = host.verify_release(release, pins['manifestSha256'])
server = host.StaticServer(release, files)
thread = threading.Thread(target=server.serve_forever, daemon=True)
thread.start()
checks = []
try:
    for name, row in files.items():
        if not name.startswith('web/') or Path(name).suffix not in ('.mjs', '.js', '.css', '.html'):
            continue
        connection = http.client.HTTPConnection('127.0.0.1', server.server_port, timeout=5)
        try:
            connection.request('GET', '/' + name[4:])
            response = connection.getresponse()
            raw = response.read()
            assert response.status == 200, (name, response.status)
            assert hashlib.sha256(raw).hexdigest().upper() == row['sha256'].upper(), name
            checks.append(name)
        finally:
            connection.close()
    assert 'web/pages/management-nav.mjs' in checks
finally:
    server.shutdown()
    server.server_close()
    thread.join(5)
result = dict(status='PASS', actualNativeStaticServer=True, modulesAndStyles=len(checks),
              newSharedModuleServed=True, productionDataAccess=False, checks=checks)
(TASK/'verification/served-closure.json').write_text(json.dumps(result, ensure_ascii=False, indent=2)+'\n', 'utf-8')
print(json.dumps({k:v for k,v in result.items() if k != 'checks'}))
