from pathlib import Path
import ast,json,hashlib
D=Path(__file__).resolve().parent;p=D/'submit_code_only_v2.py';s=p.read_text('utf-8-sig');s=s.replace("keys=['Handler','Runtime'","keys=['InstallDependency','Handler','Runtime'",1)
needle=" assert config.get('Type') in ('Event','HTTP')"
s=s.replace(needle,needle+"\n assert config.get('InstallDependency')=='FALSE','Dependency behavior changed; stop without update'",1)
ast.parse(s);p.write_text(s,'utf-8')
r=json.loads((D/'DIAGNOSIS.json').read_text('utf-8'));r['proposedV2ScriptSha256']=hashlib.sha256(p.read_bytes()).hexdigest();r['dependencyCaveat']='Read-only GetFunction evidence confirms InstallDependency FALSE. Proposed script explicitly requires FALSE before sole submit and includes InstallDependency in protected before/after hashes; otherwise zero update. Existing FALSE means CLI includes node_modules without dependency installation.';(D/'DIAGNOSIS.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n','utf-8')
print(json.dumps({'proposedV2ScriptSha256':r['proposedV2ScriptSha256'],'configSha256':r['configSha256'],'approvedOriginalModified':False,'executed':False}))
p=D/'诊断与最小提交方案.md';s=p.read_text('utf-8-sig');s+='\n最新只读核验已确认当前 InstallDependency 为 FALSE。提议脚本现明确要求该字段严格等于 FALSE，且将其纳入提交前后配置摘要；发生变化则停止，不修改远端配置。保持 FALSE 时不触发依赖安装，现有 node_modules 随完整代码包保留，最终仍以完整 ZIP 回读一致为准。\n';p.write_text(s,'utf-8')
