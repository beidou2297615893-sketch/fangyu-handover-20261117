from pathlib import Path
import os,socket,sys,tempfile,unittest
from unittest.mock import patch
import httpx
from loopback_tls_fixture import LocalResponder
T=Path(__file__).resolve().parents[1]
class LoopbackTests(unittest.TestCase):
 def test_exact_synthetic_tls_without_forwarding_or_os_certificate_changes(self):
  with tempfile.TemporaryDirectory(dir=T/'tests') as directory:
   f=LocalResponder(Path(directory)/'certs')
   with f.serve() as env,patch.dict(os.environ,env,clear=False):
    with httpx.Client(timeout=5) as client:
     value=client.get('https://edith.xiaohongshu.com/api/sns/web/v2/user/me').json()
     self.assertEqual(value['data']['user_id'],'b'*24)
   self.assertEqual(len(f.records),1);self.assertEqual(f.errors,[])
   self.assertFalse(f.records[0]['forwarded'])
if __name__=='__main__':
 def audit(event,args):
  if event=='socket.connect':
   address=args[1]
   if not isinstance(address,tuple) or address[0] not in ('127.0.0.1','::1'):raise AssertionError('External network forbidden')
 sys.addaudithook(audit);unittest.main(verbosity=2)
