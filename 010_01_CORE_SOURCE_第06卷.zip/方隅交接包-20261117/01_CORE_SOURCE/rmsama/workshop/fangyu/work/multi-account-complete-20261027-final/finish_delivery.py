"""Record the installed, verified result with explicit live-operation limits."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,shutil
N=Path(__file__).resolve().parent;P=N.parents[1]
read=lambda p:json.loads(p.read_text('utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,v):
    p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('x',encoding='utf-8') as f:json.dump(v,f,ensure_ascii=False,indent=2);f.write('\n')
pins=read(N/'FROZEN-PINS.json');checks=read(N/'verification/integrated/RESULT.json')
binary=read(N/'evidence/compiled-acceptance.json');cloud=read(N/'cloud/DEPLOYMENT-V3.json')
entry=read(N/'NEXT-LAUNCH-ENTRY-CHECK.json');install=read(N/'NEXT-LAUNCH-INSTALLATION.json')
assert checks['status']=='PASS' and len(checks['checks'])==45 and all(c['exitCode']==0 for c in checks['checks'])
assert binary['status']=='PASS_FOUR_COMPILED_CASES' and len(binary['cases'])==4
assert cloud['status']=='VERIFIED_CODE_ONLY_DEPLOYMENT' and cloud['protectedConfigurationUnchanged'] is True and cloud['cliReportedCodeUpdated'] is True
assert entry['status']=='NEXT_LAUNCH_ENTRY_VERIFIED' and entry['allBusinessDataUnchanged'] and entry['currentInstanceUnchanged']
assert install['status']=='NEXT_LAUNCH_INSTALLED' and install['allBusinessDataUnchanged']
folder=P/'outputs/多账号回复';folder.mkdir(parents=True,exist_ok=True)
body=(N/'USER-GUIDE-DRAFT.md').read_text('utf-8')+'\n程序检查和本地模拟链路已通过；未替本人登录、采集或对外发评论。更新已接到原软件入口，正常退出并重新打开后使用。现有客户、账号、任务断点和草稿保持。\n'
doc=folder/'完整链路使用说明.md'
with doc.open('x',encoding='utf-8') as f:f.write(body)
previous=folder/'使用说明.md'
if previous.exists():
    backup=N/'evidence/previous-user-guide.md';shutil.copyfile(previous,backup)
previous.write_text(body,'utf-8')
core=Path('C:/积木软件工坊/核心组件/work/reviewed-account-reply-20261027-candidate')
assert not core.exists();core.mkdir(parents=True)
archived={}
for rel in ('reply_account_profiles.py','reply_public_profile.py','send/reviewed_reply_bridge.py','runtime/core/reply_execution_policy.py','runtime/assistant/xhs_reply_worker.py','worker/assistant/xhs_cli_page_worker.py','web/pages/reply-public-read.mjs'):
    src=N/'candidate'/rel;target=core/rel;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,target);assert sha(src)==sha(target);archived[rel]=sha(target)
write(core/'CANDIDATE.json',dict(status='GENERIC_SOURCE_CANDIDATE_ONLY',files=archived,customerDataIncluded=False,credentialsIncluded=False,promoted=False,otherInstancesUpdated=False,requires='Existing owned account sessions, exact reviewed capability registration and original queue',evidence=str(N/'verification/integrated/RESULT.json')))
note=('\n\n## 2026-10-27 多账号回复完整代码链路交付\n'
    f"下次启动 {pins['releaseId']}。沿ba1保留既有首页当前浏览器身份、客户意向增量及口吻学习，新增受控公开简介/近期帖子读取与采纳、独立账号实际身份核对、原账号连接入口及原审核队列发送。每账号真实定位/语气和手工改分组保留；不从年龄/IP猜人设。\n"
    '客户历史模块原有business指纹更新到真实已审源，原_lead_access AST未改变；完整后端25与最终45组整合验证PASS，9199文件闭包精确审核。实际编译v3在非转发本地TLS上通过读取/正常单POST/错UID零POST/冲突unknown防重四案例；05整体FAIL保留，以05两成功分案+06两负向成功组合，未冒称生产平台验收。\n'
    '云端仅更新devices与独立受控回复许可模块，5617原文件逐字保留，固定材料双版本准入；官方代码更新后全量ZIP读回匹配，保护配置不变，未改数据库/账号权限。源入口两文件CAS下次启动更新，原入口check/selftest通过，业务全快照与当前实例前后不变；未GUI/重启/实采/真实评论发送/新模型调用。\n'
    f'证据：{N.as_posix()}；人用outputs/多账号回复/完整链路使用说明.md（同步使用说明.md）。真实账号登录、实际平台应答与本人语气认可仍由本人实际操作核验。通用部分仅核心组件work候选归档，不推广其他实例。\n')
for path in (P/'memory/STATUS.md',Path('C:/积木软件工坊/项目/方隅公寓/memory/STATUS.md')):
    with path.open('a',encoding='utf-8') as f:f.write(note)
with (P/'memory/sessions/20261027-multi-account-complete.md').open('x',encoding='utf-8') as f:f.write(note)
result=dict(status='DELIVERED_REVIEWED_ACCOUNT_REPLY_NEXT_LAUNCH',atUtc=datetime.now(timezone.utc).isoformat(),releaseId=pins['releaseId'],regressionGroups=45,compiledCases=4,compiledBinaryEvidenceReused=True,cloudCodeDeployed=True,cloudConfigurationUnchanged=True,productionDatabaseWrites=0,realPlatformRequests=0,realMessagesSent=0,realModelCalls=0,readOnlyBusinessCheckpoint=True,businessDataUnchanged=True,currentInstanceUnchanged=True,userRestartRequired=True,userToneAccepted=False,livePlatformAcceptancePerformed=False,guide=str(doc),folder=str(folder),genericCandidate=str(core),sourceReviewSha256=sha(N/'independent/FINAL-SOURCE-REVIEW.json'),entryCheckSha256=sha(N/'NEXT-LAUNCH-ENTRY-CHECK.json'),cloudReceiptSha256=sha(N/'cloud/DEPLOYMENT-V3.json'))
write(N/'DELIVERY.json',result);print(json.dumps(result,ensure_ascii=True))
