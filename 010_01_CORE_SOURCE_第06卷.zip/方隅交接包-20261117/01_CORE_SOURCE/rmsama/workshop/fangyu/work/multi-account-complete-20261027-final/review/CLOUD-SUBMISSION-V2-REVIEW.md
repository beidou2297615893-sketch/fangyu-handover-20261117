# 独立第二提交方案精确审查

2026-10-27，Astra。

已批准 cloud/DEPLOY-V2-APPROVED-PINS.json 所绑定的新脚本一次提交。原 deploy.py/DEPLOYMENT.json 和两次旧代码读回保持原样，不把首次 exit 0 改称成功。

独立读取本机官方 CLI 3.5.5 实际代码：无配置分支无条件等待 inquirer；--json 不跳过该分支。离线 VM 记录无配置（包括 yes=true）prompt=1/update=0、进程退出，与原代码未变及 ModTime 未更新吻合。新本地配置只包含 functionRoot、单目标 name/dir，固定独立 cwd 和绝对 --dir 选择 updateWithConfig，不混入候选代码包。

已独立检查 manager 代码更新路径：沿用远端 Type/Handler/Runtime/InstallDependency，实际提交 UpdateFunctionCode，未调用配置更新。新脚本强制 InstallDependency=FALSE，提交前后受保护摘要包含该字段，避免 node_modules 被排除或远端安装依赖。新脚本 SHA eb83888db9fb18e82935e2e01adb136ec154fd79072f9c9b8057b53d2ebcef3e；本地配置 SHA 57c22761396d6517841049acb5a835ea0847117b7da08c9b861c2ffab6745826；CLI bundle SHA 89e254ad573608a6b3bdddbd648e23d91829a2e9e9bb6faba310b0c08d70ae6b。

新脚本继承精确文件审批、最新完整代码读回基线检查、候选完整树校验、sole update、配置哈希比对和 5619 文件/ZIP 全核验。新目录/DEPLOYMENT-V2 防重复，保留先前证据。必须同时得到明确唯一 data.message=Code updated、完整候选读回、配置及本地候选不变才成功；退出码本身不足。无 GUI、登录、业务数据库或真实平台动作。

已由审查方执行 --prepare-only，真实重算六 pins 与完整本地候选树通过，externalCalls=0。只准 root 使用批准文件进行一次提交；任何不匹配或未知状态停止，不自动更换 API 或重复提交。本地 next-launch 更新仍待云端验证结果。
