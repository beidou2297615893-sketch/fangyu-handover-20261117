from pathlib import Path
import shutil,json,hashlib
N=Path(__file__).resolve().parent;O=N.parent/'multi-account-complete-20261026'
pins={}
for owner in ('backend','frontend'):
    target=N/owner;target.mkdir(exist_ok=True)
    for p in (O/owner).iterdir():
        if p.is_file() and p.suffix=='.json':
            # Source catalogs and executable commands are reused, not success receipts.
            if p.name.startswith(('DELIVERY','TEST-RESULT','SOURCE-PINS.before')):continue
            out=target/p.name
            if out.exists():continue
            text=p.read_text('utf-8-sig').replace(str(O).replace('\\','/'),str(N).replace('\\','/')).replace(str(O).replace('\\','\\\\'),str(N).replace('\\','\\\\'))
            out.write_text(text,'utf-8');pins[str(p)]=hashlib.sha256(p.read_bytes()).hexdigest()
(N/'sender').mkdir(exist_ok=True)
shutil.copytree(O/'sender/tests',N/'sender/tests',ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
spec=O/'sender/TEST-COMMANDS.json';body=spec.read_text('utf-8-sig').replace(str(O).replace('\\','/'),str(N).replace('\\','/')).replace(str(O).replace('\\','\\\\'),str(N).replace('\\','\\\\'))
(N/'sender/TEST-COMMANDS.json').write_text(body,'utf-8');pins[str(spec)]=hashlib.sha256(spec.read_bytes()).hexdigest()
(N/'OWNER-SPEC-REUSE.json').write_text(json.dumps({'sourcePins':pins,'copiedSuccessResults':False},indent=2)+'\n','utf-8')
shutil.copyfile(O/'USER-GUIDE-DRAFT.md',N/'USER-GUIDE-DRAFT.md')
print(json.dumps({'status':'OWNER_SOURCE_CATALOGS_READY','successReceiptsCopied':False}))
