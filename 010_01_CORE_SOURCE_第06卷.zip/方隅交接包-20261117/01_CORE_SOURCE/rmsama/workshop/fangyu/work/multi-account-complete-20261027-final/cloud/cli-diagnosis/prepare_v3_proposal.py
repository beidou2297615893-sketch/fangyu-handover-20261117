from pathlib import Path
import ast,json,hashlib
D=Path(__file__).resolve().parent;p=D/'submit_code_only_v3.py';s=(D/'submit_code_only_v2.py').read_text('utf-8-sig')
for a,b in [('submit-v2','submit-v3'),('submit_code_only_v2.py','submit_code_only_v3.py'),('DEPLOY-V2-PREPARED','DEPLOY-V3-PREPARED'),('DEPLOYMENT-V2','DEPLOYMENT-V3'),('CONFIG-PROTECTED-V2','CONFIG-PROTECTED-V3'),('readback-v2-','readback-v3-'),('ASTRA_APPROVED_EXACT_CODE_ONLY_DEPLOY_V2_WITH_LOCAL_CONFIG','ASTRA_APPROVED_EXACT_CODE_ONLY_DEPLOY_V3_WITH_MATURE_CONFIG')]:s=s.replace(a,b)
s=s.replace("expected_config={'functionRoot':str(D/'candidate'),'functions':[{'name':FN,'dir':'.'}]}","expected_config={'envId':ENV,'functionRoot':'.','functions':[{'name':FN,'installDependency':False,'ignore':[]}]}")
index=s.index('def protected(obj):')
helper="""def safe_cli_signals(run):
 text=(run.stdout+b'\\n'+run.stderr).decode('utf-8',errors='replace')
 classes=[name for name in ('CloudBaseError','TypeError','SyntaxError','ReferenceError','TimeoutError') if name in text]
 codes=[]
 for value in re.findall(r'"(?:code|errorCode|ErrorCode)"\\s*:\\s*"([A-Za-z][A-Za-z0-9_.-]{0,90})"',text):
  if re.fullmatch(r'(?:InvalidParameter|ResourceNotFound|AuthFailure|FailedOperation|InternalError|MissingParameter|LimitExceeded|UnauthorizedOperation)(?:\\.[A-Za-z0-9_-]+)*',value):codes.append(value)
 signals={'missingLocalConfigEnvId':'无效的配置文件，配置文件必须包含环境 Id(envId) 字段' in text,'codeUpdatedJSON':explicit_code_updated(run.stdout),'permissionDenied':any(v in text for v in ('AccessDenied','UnauthorizedOperation','AuthFailure')),'uploadFailed':('COS' in text or 'cos' in text) and any(v in text for v in ('failed','失败','Error'))}
 return {'stdoutBytes':len(run.stdout),'stderrBytes':len(run.stderr),'errorClasses':classes,'errorCodes':sorted(set(codes)),'signals':signals,'rawOutputPersisted':False}

"""
s=s[:index]+helper+s[index:]
s=s.replace("  report['cliExitCode']=run.returncode","  report['cliExitCode']=run.returncode\n  report['cliDiagnostics']=safe_cli_signals(run)")
s=s.replace("except subprocess.TimeoutExpired:report['status']='TIMEOUT_READBACK_REQUIRED'","except subprocess.TimeoutExpired:report.update(status='TIMEOUT_READBACK_REQUIRED',cliDiagnostics={'errorClasses':['TimeoutExpired'],'rawOutputPersisted':False})")
ast.parse(s);p.write_text(s,'utf-8')
# Syntax/test pure helpers only. The proposed submit script is never imported.
tree=ast.parse(s);nodes=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in ('explicit_code_updated','safe_cli_signals')]
import re
from types import SimpleNamespace
scope={'re':re,'json':json};exec(compile(ast.Module(body=nodes,type_ignores=[]),'<safe-helper-test>','exec'),scope)
a=scope['safe_cli_signals'](SimpleNamespace(stdout=b'',stderr='CloudBaseError: 无效的配置文件，配置文件必须包含环境 Id(envId) 字段'.encode()));assert a['signals']['missingLocalConfigEnvId'] and a['errorClasses']==['CloudBaseError']
a=scope['safe_cli_signals'](SimpleNamespace(stdout=b'{"data":{"message":"Code updated"}}',stderr=b''));assert a['signals']['codeUpdatedJSON']
a=scope['safe_cli_signals'](SimpleNamespace(stdout=b'{"errorCode":"secret-token-value"}',stderr=b''));assert not a['errorCodes']
source=D.parents[2]/'cloud-prompt-deployment-20261025/cloudbaserc.json'
assert (D/'submit-v3/cloudbaserc.json').read_bytes()==source.read_bytes()
report={'status':'PREPARED_NOT_SUBMITTED','scriptSha256':hashlib.sha256(p.read_bytes()).hexdigest(),'configSha256':hashlib.sha256(source.read_bytes()).hexdigest(),'matureConfigExactBytes':192,'newApprovalSchema':'ASTRA_APPROVED_EXACT_CODE_ONLY_DEPLOY_V3_WITH_MATURE_CONFIG','configActualReadOnlyCLIValidation':'fn list exit0 from fixed submit-v3 cwd','safeDiagnosticTests':3,'remoteMutationExecuted':False}
(D/'V3-PROPOSAL.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n','utf-8');print(json.dumps(report))
