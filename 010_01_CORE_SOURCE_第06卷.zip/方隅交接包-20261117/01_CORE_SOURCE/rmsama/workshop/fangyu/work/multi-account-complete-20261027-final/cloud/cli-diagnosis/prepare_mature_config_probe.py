from pathlib import Path
import shutil,json,hashlib
D=Path(__file__).resolve().parent
source=D.parents[2]/'cloud-prompt-deployment-20261025/cloudbaserc.json'
assert source.stat().st_size==192
config=json.loads(source.read_text('utf-8-sig'))
assert config=={'envId':'fh6-d5ga45c0ddae7008c','functionRoot':'.','functions':[{'name':'fangyu-workspace','installDependency':False,'ignore':[]}]}
(D/'submit-v3').mkdir(exist_ok=False);shutil.copyfile(source,D/'submit-v3/cloudbaserc.json')
s=(D/'read_only_list_probe.py').read_text('utf-8-sig').replace("cwd=D/'submit-v2'","cwd=D/'submit-v3'").replace("V2-READONLY-LIST-DIAGNOSTIC.json","V3-MATURE-CONFIG-READONLY-LIST-DIAGNOSTIC.json")
s=s.replace("'rawOutputPersisted':False", "'configMissingEnvIdLiteral':('无效的配置文件，配置文件必须包含环境 Id(envId) 字段' in raw),'rawOutputPersisted':False")
(D/'read_only_mature_config_probe.py').write_text(s,'utf-8')
print(json.dumps({'copiedMatureConfigExactBytes':True,'bytes':192,'sha256':hashlib.sha256(source.read_bytes()).hexdigest()}))
