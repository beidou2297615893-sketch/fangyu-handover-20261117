from pathlib import Path
import sys,importlib.util,unittest
T=Path(__file__).resolve().parents[2]
spec=importlib.util.spec_from_file_location('compat_original_fixture',T/'tests/backend/test_public_read.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
class Evidence(unittest.TestCase):
 def test_profile_binding_source_survives_return_and_adoption(self):
  for source in ('response_uid','request_bound_subject'):
   with self.subTest(source=source):
    t=m.PublicReadTests('test_apply_uses_separate_automatic_slot_and_preserves_manual');t.setUp()
    try:
     adapter=t.f.core.adapters;old=adapter.execute
     def execute(platform,args,*a,**kw):
      value=old(platform,args,*a,**kw)
      if args[0]=='user':value['data']={'subjectId':'customer-uid','identitySource':source,'desc':'想租一室，可以养猫吗',**({'user_id':'customer-uid'} if source=='response_uid' else {})}
      return value
     adapter.execute=execute
     view=t.start();self.assertEqual(view['state'],'completed');self.assertEqual(view['profile']['identitySource'],source)
     applied=t.reader.dispatch('reply_public_profile_apply',{**t.f.base,'jobId':t.jobid,'requestId':'adopt-'+source,'expectedEvidenceRevision':0},'token')['replyPublicRead'];self.assertTrue(applied['applied'])
     saved=t.f.service.evidence(['t','u','owner','s','xiaohongshu'],'c')
     item=next(x for x in saved['automaticItems'] if '/user/profile/' in x['sourceUrl']);self.assertEqual(item['identitySource'],source)
    finally:t.doCleanups()
if __name__=='__main__':unittest.main()

