from pathlib import Path
import ast,hashlib,json,re
N=Path(__file__).resolve().parent;B=N.parent/'multi-account-reply-20261026/assembly/project';C=N/'candidate'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
# Map only runtime/native changed targets; scan executable Python consumers,
# excluding historical provenance and immutable reviewed third-party resources.
changes={}
for group,prefix in [('runtime','work/ui-runtime-r55/src'),('worker','work/ui-runtime-r55/src'),('shared','work/shared-backend-integration')]:
 for p in (C/group).rglob('*.py'):
  name=prefix+'/'+p.relative_to(C/group).as_posix();q=B/name
  if q.is_file() and sha(q)!=sha(p):changes[sha(q)]=(name,sha(p))
for p in C.glob('*.py'):
 q=B/'work/ui-native-r57'/p.name
 if q.is_file() and sha(q)!=sha(p):changes[sha(q)]=('work/ui-native-r57/'+p.name,sha(p))
hits=[]
for root in [B/'work/ui-native-r57',B/'work/ui-runtime-r55/src',B/'work/shared-backend-integration']:
 for p in root.rglob('*.py'):
  if '/releases/' in p.as_posix() or '__pycache__' in p.parts:continue
  name=p.relative_to(B).as_posix();candidate=C/p.name if root==B/'work/ui-native-r57' and p.parent==root else None
  if root==B/'work/ui-runtime-r55/src':
   relative=p.relative_to(root)
   for group in ('runtime','worker'):
    if (C/group/relative).is_file():candidate=C/group/relative
  if root==B/'work/shared-backend-integration' and (C/'shared'/p.relative_to(root)).is_file():candidate=C/'shared'/p.relative_to(root)
  actual=candidate if candidate and candidate.is_file() else p
  for match in re.finditer(r"(?<![0-9a-fA-F])[0-9a-fA-F]{64}(?![0-9a-fA-F])",actual.read_text('utf-8-sig',errors='replace')):
   if match[0].lower() in changes:
    target,new=changes[match[0].lower()];hits.append({'consumer':name,'actualSource':str(actual),'oldHash':match[0],'changedTarget':target,'newHash':new})
report={'changedSourceHashes':len(changes),'staleHashOccurrences':hits,'scanScope':'executable Python source consumers in baseline native/runtime/shared with candidate overlay substituted; historical JSON/source provenance excluded'}
(N/'CONSUMER-HASH-AUDIT.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n','utf-8');print(json.dumps(report,ensure_ascii=False))
