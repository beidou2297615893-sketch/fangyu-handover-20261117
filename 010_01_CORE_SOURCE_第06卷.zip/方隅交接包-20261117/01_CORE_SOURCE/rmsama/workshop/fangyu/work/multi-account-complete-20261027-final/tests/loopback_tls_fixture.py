"""Test-only TLS CONNECT responder. It never connects or forwards to any host.

The CA is temporary and trusted only by each test child's environment. Nothing
is installed in the Windows certificate store or shipped in the application.
"""
from contextlib import contextmanager
from datetime import datetime,timedelta,timezone
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from pathlib import Path
import ipaddress,json,os,ssl,threading
from urllib.parse import urlsplit,parse_qs

def certificates(root):
 from cryptography import x509
 from cryptography.x509.oid import NameOID,ExtendedKeyUsageOID
 from cryptography.hazmat.primitives import hashes,serialization
 from cryptography.hazmat.primitives.asymmetric import rsa
 root=Path(root);root.mkdir(parents=True,exist_ok=True)
 now=datetime.now(timezone.utc)
 ca_key=rsa.generate_private_key(public_exponent=65537,key_size=2048)
 ca_name=x509.Name([x509.NameAttribute(NameOID.COMMON_NAME,'Local synthetic test CA')])
 ca=x509.CertificateBuilder().subject_name(ca_name).issuer_name(ca_name).public_key(ca_key.public_key()).serial_number(x509.random_serial_number()).not_valid_before(now-timedelta(minutes=5)).not_valid_after(now+timedelta(days=1)).add_extension(x509.BasicConstraints(ca=True,path_length=0),critical=True).add_extension(x509.KeyUsage(digital_signature=True,content_commitment=False,key_encipherment=False,data_encipherment=False,key_agreement=False,key_cert_sign=True,crl_sign=True,encipher_only=None,decipher_only=None),critical=True).add_extension(x509.SubjectKeyIdentifier.from_public_key(ca_key.public_key()),critical=False).sign(ca_key,hashes.SHA256())
 key=rsa.generate_private_key(public_exponent=65537,key_size=2048)
 name=x509.Name([x509.NameAttribute(NameOID.COMMON_NAME,'edith.xiaohongshu.com')])
 leaf=x509.CertificateBuilder().subject_name(name).issuer_name(ca_name).public_key(key.public_key()).serial_number(x509.random_serial_number()).not_valid_before(now-timedelta(minutes=5)).not_valid_after(now+timedelta(days=1)).add_extension(x509.BasicConstraints(ca=False,path_length=None),critical=True).add_extension(x509.SubjectAlternativeName([x509.DNSName('edith.xiaohongshu.com')]),critical=False).add_extension(x509.ExtendedKeyUsage([ExtendedKeyUsageOID.SERVER_AUTH]),critical=False).add_extension(x509.AuthorityKeyIdentifier.from_issuer_public_key(ca_key.public_key()),critical=False).sign(ca_key,hashes.SHA256())
 cert=root/'server.pem';private=root/'server-key.pem';trust=root/'test-ca.pem'
 cert.write_bytes(leaf.public_bytes(serialization.Encoding.PEM)+ca.public_bytes(serialization.Encoding.PEM))
 private.write_bytes(key.private_bytes(serialization.Encoding.PEM,serialization.PrivateFormat.PKCS8,serialization.NoEncryption()))
 trust.write_bytes(ca.public_bytes(serialization.Encoding.PEM))
 return cert,private,trust

class LocalResponder:
 def __init__(self,root,actor_uid='b'*24,subject_uid='c'*24):
  self.root=Path(root);self.actor_uid=actor_uid;self.subject_uid=subject_uid;self.records=[];self.errors=[]
 def answer(self,method,target,body):
  parsed=urlsplit(target);query=parse_qs(parsed.query)
  if parsed.netloc:raise ValueError('absolute request forbidden after local TLS')
  if method=='GET' and parsed.path=='/api/sns/web/v2/user/me' and not parsed.query:
   return {'success':True,'code':0,'data':{'user_id':self.actor_uid,'id':self.actor_uid,'nickname':'Synthetic account','user':{'id':self.actor_uid,'user_id':self.actor_uid,'nickname':'Synthetic account'},'basic_info':{'user_id':self.actor_uid,'nickname':'Synthetic account'}}}
  if method=='GET' and parsed.path=='/api/sns/web/v1/user/otherinfo' and query.get('target_user_id')==[self.subject_uid]:
   return {'success':True,'code':0,'data':{'user_id':self.subject_uid,'basic_info':{'user_id':self.subject_uid,'nickname':'Synthetic customer','desc':'我带猫，正在找一室出租房，预算两千。'},'interactions':[]}}
  if method=='GET' and parsed.path=='/api/sns/web/v1/user_posted' and query.get('user_id')==[self.subject_uid] and query.get('cursor',[''])==['']:
   return {'success':True,'code':0,'data':{'notes':[{'note_id':'d'*24,'id':'d'*24,'user_id':self.subject_uid,'user':{'user_id':self.subject_uid},'note_card':{'title':'带猫找一室','display_title':'带猫找一室','desc':'正在找房，预算两千。','user':{'user_id':self.subject_uid}}}], 'has_more':False,'cursor':''}}
  if method=='POST' and parsed.path=='/api/sns/web/v1/comment/post' and not parsed.query:
   if (not isinstance(body,dict) or set(body)!={'note_id','content','target_comment_id','at_users'} or body['note_id']!='d'*24 or body['target_comment_id']!='e'*24 or body['at_users']!=[] or body['content']!='Synthetic reviewed reply'):raise ValueError('POST differed from exact synthetic authorization')
   ident='f'*24;user={'user_id':self.actor_uid,'id':self.actor_uid}
   return {'success':True,'code':0,'data':{'id':ident,'comment_id':ident,'user_id':self.actor_uid,'user_info':user,'comment':{'id':ident,'user_info':user,'user_id':self.actor_uid}}}
  raise ValueError('unexpected synthetic route')
 @contextmanager
 def serve(self):
  cert,key,trust=certificates(self.root);context=ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER);context.load_cert_chain(cert,key)
  fixture=self
  class Handler(BaseHTTPRequestHandler):
   protocol_version='HTTP/1.1'
   def log_message(self,*args):pass
   def do_CONNECT(self):
    if self.path!='edith.xiaohongshu.com:443':fixture.errors.append('unexpected CONNECT');self.send_error(403);return
    self.send_response(200,'Connection established');self.end_headers()
    self.connection=context.wrap_socket(self.connection,server_side=True)
    self.rfile=self.connection.makefile('rb');self.wfile=self.connection.makefile('wb');self.close_connection=False
    try:
     while not self.close_connection:self.handle_one_request()
    finally:self.connection.close()
   def respond(self):
    try:
     if self.headers.get('Host')!='edith.xiaohongshu.com':raise ValueError('host mismatch')
     count=int(self.headers.get('Content-Length','0'))
     if count<0 or count>10000:raise ValueError('body limit')
     raw=self.rfile.read(count);body=json.loads(raw) if raw else None
     value=fixture.answer(self.command,self.path,body)
     fixture.records.append({'method':self.command,'path':self.path,'body':body,'peer':'127.0.0.1','forwarded':False})
     payload=json.dumps(value,ensure_ascii=False).encode()
     self.send_response(200);self.send_header('Content-Type','application/json');self.send_header('Content-Length',str(len(payload)));self.end_headers();self.wfile.write(payload);self.wfile.flush()
    except Exception as error:fixture.errors.append(type(error).__name__+': '+str(error));self.send_error(403);self.close_connection=True
   do_GET=respond;do_POST=respond
  server=ThreadingHTTPServer(('127.0.0.1',0),Handler);server.daemon_threads=True
  thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
  proxy='http://127.0.0.1:'+str(server.server_port)
  try:yield {'HTTP_PROXY':proxy,'HTTPS_PROXY':proxy,'ALL_PROXY':proxy,'NO_PROXY':'','SSL_CERT_FILE':str(trust)}
  finally:server.shutdown();server.server_close();thread.join(3)
