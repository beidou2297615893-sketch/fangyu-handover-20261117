from pathlib import Path
import ast,hashlib,json,shutil
P=Path(__file__).resolve().parents[2];OLD=P/'work/multi-account-complete-20261026';N=P/'work/multi-account-complete-20261027-final'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
pins=json.loads((OLD/'FINAL-CANDIDATE-PINS.json').read_text('utf-8-sig'))['files']
for name,row in pins.items():
 source=OLD/name;assert sha(source)==row['sha256'],name
 target=N/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,target)
for name in ('bootstrap.py','assemble_complete.py','freeze_complete.py','review_source_closure.py','verify_next_launch_entry.py','closed_update_guard.py','next_launch_update.py'):shutil.copy2(OLD/name,N/name)
p=N/'bootstrap.py';s=p.read_text('utf-8-sig');start=s.index("for name in ('closed_update_guard.py'");end=s.index('for n,h in canonical.items()',start);s=s[:start]+s[end:];p.write_text(s,'utf-8')
p=N/'assemble_complete.py';s=p.read_text('utf-8-sig');old="T/'component-v3/artifacts/platform-cli-customer-read'";new="T.parent/'multi-account-complete-20261026/component-v3/artifacts/platform-cli-customer-read'";assert s.count(old)==1;s=s.replace(old,new);p.write_text(s,'utf-8')
p=N/'freeze_complete.py';s=p.read_text('utf-8-sig');needle="[str(P/'work/desktop-python/Scripts/python.exe'),'-B','-c'";assert s.count(needle)==1;s=s.replace(needle,"[str(P/'work/desktop-python/Scripts/python.exe'),'-X','utf8','-B','-c'");p.write_text(s,'utf-8')
base=OLD.parent/'multi-account-reply-20261026/assembly/project'
before=base/'work/ui-runtime-r55/src/assistant/business.py';after=N/'candidate/runtime/assistant/business.py'
def method(p):
 tree=ast.parse(p.read_text('utf-8-sig'));cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='BusinessExecutor');return ast.dump(next(n for n in cls.body if isinstance(n,ast.FunctionDef) and n.name=='_lead_access'),include_attributes=False)
assert method(before)==method(after)
source=base/'work/ui-native-r57/customer_workbench.py';s=source.read_text('utf-8-sig');old=sha(before).upper();new=sha(after).upper();assert s.count(old)==1;s=s.replace(old,new);target=N/'candidate/customer_workbench.py';target.write_text(s,'utf-8')
for p in N.glob('*.py'):ast.parse(p.read_bytes())
report={'status':'PREPARED_NOT_FROZEN','copiedValidatedCandidates':len(pins),'newCandidates':1,'customerDependency':{'sourcePath':str(source),'sourceSha256':sha(source),'candidateSha256':sha(target),'oldBusinessSha256':old,'newBusinessSha256':new,'leadAccessASTIdentical':True},'componentArtifactSource':str(OLD/'component-v3/artifacts/platform-cli-customer-read'),'freezeInterpreter':'fixed desktop-python -X utf8 -B','oldTaskEdited':False}
(N/'PREPARATION.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n','utf-8');print(json.dumps(report))
