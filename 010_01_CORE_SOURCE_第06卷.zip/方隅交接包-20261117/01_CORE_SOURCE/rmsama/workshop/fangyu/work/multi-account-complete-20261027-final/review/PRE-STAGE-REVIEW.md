# 新最终候选冻结前审查

2026-10-27，Astra。本报告对新任务独立签发，未复制旧版本的批准状态。

APPROVED_FOR_FINAL_CANDIDATE_STAGE_ONLY

允许 root 在本任务已组装的 assembly/project 执行一次 freeze_complete.py --stage-prepared-candidate。此批准不包含安装、云部署、真实平台或 GUI。

精确脚本及计划 SHA256：

- bootstrap.py：dd7008c1b267d5d6aab7a629dc7f9e9a205cb7aa90c907b224e569dcdc595a9f
- assemble_complete.py：f12be19a10b736fb38a4528676adc9e639b781c54d6e1652adf413eb039d6d0c
- freeze_complete.py：97eab6aa93c97424350e4dc58e575eeb524999c43af86273ca53fa41a008fe27
- review_source_closure.py：af26396ffba320a92031e0b6d8a52f5a8f6d7066377de677837f8795583d7176
- next_launch_update.py（仅静态复核，执行待批准）：7ffb95efa4b9a86b9001142b370631ca6019cef72c4ab1f7f94307b04cd52ccc
- FINAL-CANDIDATE-PINS.json：a431c2facbdb8a15a66dc5614e1aabacb3432bc0dac6c78121eb1012abd3351f

已对照旧任务检查所有相关脚本差异：bootstrap 保留精确 active ba1 的 5987 源文件复制校验，仅不再用旧版本覆盖本任务已准备审查脚本；assembler 只将 helper 来源指向旧任务已冻结 component-v3；freezer 只给固定 Python 增加 -X utf8，解决控制台编码，不改发布逻辑。source closure 和 next-launch updater 字节保持其已审版本。

36 候选逐项核对当前 SHA/size 无差异；其中复制的原 35 候选与旧任务字节完全相同。唯一新增 customer_workbench.py SHA 4f015bf29ce32758e3281234ef446cba4637efc8a6822dac9b62b1db3a20b52d，独立完整 diff 确认只更新 assistant/business.py 的 trusted hash，未改访问控制或功能。消费者哈希审计无残留失效引用；此前失败的 existing-backend 25 项已全部通过，前端代表样例已取得通过结果。

独立重算组装材料：sender canonical 67c3b2cf6f8babda9fb5516ff2aeaed9b138d58cb898908d8729ae768d14f914；read canonical 73d0240ff619ab95eac9c4b27b15d44e557d3a0224f6a9b63fc949fc53d6ec01。各 115 源及 291 runtime 项全部真实哈希匹配。EXE 仍为已验收 v3 998831579f4f2a729039d3d0924d69fb9da09f820e965403a93681ed03452d31，不重编。已通过组件场景用旧 05/06 原始证据路径和 SHA 明示复用，不伪造新运行。

继续保持历史 SOURCE 原 source_sha256；新 candidate_sha256 独立记录，完整 external helper 纳入材料与 UNIFIED closure。冻结后必须对本任务实际 release 做 source closure、完整回归、无平台/GUI 的真实 host 启动及单模块图检查。通过后才签云部署与 next-launch 最终精确批准。
