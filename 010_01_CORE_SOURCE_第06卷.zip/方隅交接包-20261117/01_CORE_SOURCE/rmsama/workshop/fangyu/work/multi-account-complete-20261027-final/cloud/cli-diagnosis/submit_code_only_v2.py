from pathlib import Path
import subprocess,json,hashlib,re,sys,argparse
from datetime import datetime,timezone
SELF=Path(__file__).resolve()
D=SELF.parents[1]
SUBMIT=SELF.parent/'submit-v2'
sys.path.insert(0,str(D))
NODE='C:/Program Files/nodejs/node.exe'
CLI='C:/Users/rmsama/AppData/Roaming/npm/node_modules/@cloudbase/cli/bin/tcb'
ENV='fh6-d5ga45c0ddae7008c';FN='fangyu-workspace'
def api(op,body):
 r=subprocess.run([NODE,CLI,'api','scf',op,'-e',ENV,'--body',json.dumps(body,separators=(',',':')),'--json'],capture_output=True,timeout=60,cwd=D)
 if r.returncode:raise RuntimeError('official_api_failed_'+op)
 raw=re.sub(r'\x1b\[[0-9;]*[a-zA-Z]','',r.stdout.decode('utf-8',errors='replace'))
 v=json.loads(raw[raw.index('{'):raw.rindex('}')+1])
 def find(o):
  if isinstance(o,dict):
   if 'FunctionName' in o:return o
   for x in o.values():
    y=find(x)
    if y is not None:return y
  if isinstance(o,list):
   for x in o:
    y=find(x)
    if y is not None:return y
 obj=find(v);assert obj and obj.get('FunctionName')==FN
 return obj
def explicit_code_updated(stdout):
 raw=re.sub(r'\x1b\[[0-9;]*[a-zA-Z]','',stdout.decode('utf-8',errors='replace'))
 if len(raw)>1048576:return False
 decoder=json.JSONDecoder();found=[]
 for match in re.finditer(r'\{',raw):
  try:value,_=decoder.raw_decode(raw,match.start())
  except ValueError:continue
  if isinstance(value,dict) and set(value).issubset({'data','meta'}) and isinstance(value.get('data'),dict) and value['data']=={'message':'Code updated'}:found.append(value)
 return len(found)==1

def protected(obj):
 keys=['InstallDependency','Handler','Runtime','MemorySize','Timeout','Environment','VpcConfig','Role','Layers','DeadLetterConfig','PublicNetConfig','CfsConfig','DnsCache','AutoDeployClsTopicIndex','Type','Namespace','Triggers']
 return {k:hashlib.sha256(json.dumps(obj.get(k),sort_keys=True,separators=(',',':')).encode()).hexdigest() for k in keys}
SOURCE_SHA='9f688a51ac7b3a7a9501b8e4e8799295a8ab09ddcb445d856c9f6887c8487f23'

def pins():
 names=('cli-diagnosis/submit_code_only_v2.py','cli-diagnosis/submit-v2/cloudbaserc.json','verify_readback.py','read_live_code_once.py','COMPOSITION.json')
 result={name:hashlib.sha256((D/name).read_bytes()).hexdigest() for name in names}
 result['installed_cli_bundle']=hashlib.sha256(Path('C:/Users/rmsama/AppData/Roaming/npm/node_modules/@cloudbase/cli/dist/standalone/cli.js').read_bytes()).hexdigest()
 return result

def readback(name):
 out=D/name
 assert not out.exists(),'Never reuse readback evidence'
 r=subprocess.run([sys.executable,'-B',str(D/'read_live_code_once.py'),'--check-current-auth','--out',str(out)],capture_output=True,timeout=150,cwd=D)
 assert r.returncode==0,'Code readback failed; stop without retry'
 return out

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--prepare-only',action='store_true');ap.add_argument('--approved-pins',type=Path)
 args=ap.parse_args()
 composition=json.loads((D/'COMPOSITION.json').read_text('utf-8'))
 from verify_readback import local_material,verify
 local_material(composition)
 request={'status':'PENDING_ASTRA_EXACT_REVIEW','pins':pins(),'beforeTree':composition['beforeTree'],'afterTree':composition['afterTree'],'materialReady':composition['materialReady'],'sourceDeploymentSha256':SOURCE_SHA,'externalCalls':0,'deploymentExecuted':False}
 if args.prepare_only:
  (D/'DEPLOY-V2-PREPARED.json').write_text(json.dumps(request,indent=2),'utf-8');print(json.dumps(request));return
 assert args.approved_pins is not None,'Exact Astra pins required'
 approval=json.loads(args.approved_pins.read_text('utf-8'))
 assert approval.get('status')=='ASTRA_APPROVED_EXACT_CODE_ONLY_DEPLOY_V2_WITH_LOCAL_CONFIG' and approval.get('pins')==pins(),'Exact reviewed script/composition pins mismatch'
 assert approval.get('beforeTree')==composition['beforeTree'] and approval.get('afterTree')==composition['afterTree']
 assert composition['materialReady'] and re.fullmatch('[0-9a-f]{64}',composition['materialSha256']),'Final reviewed sender material required'
 assert not (D/'DEPLOYMENT-V2.json').exists(),'No automatic redeployment'
 config=api('GetFunction',{'FunctionName':FN,'Namespace':ENV,'ShowCode':'FALSE'})
 assert config.get('Type') in ('Event','HTTP')
 assert config.get('InstallDependency')=='FALSE','Dependency behavior changed; stop without update'
 if config.get('Type')=='HTTP':assert (D/'candidate/scf_bootstrap').is_file()
 before=protected(config)
 (D/'CONFIG-PROTECTED-V2-BEFORE.json').write_text(json.dumps(before,indent=2),'utf-8')
 pre=readback('readback-v2-precommit')
 live=json.loads((pre/'LIVE-READBACK.json').read_text('utf-8'))
 assert live['treeSha256']==composition['beforeTree'] and live['files']==composition['beforeFiles'],'Fresh source CAS mismatch; preserve remote successor'
 # Recheck exact local scripts/material immediately before the sole code update.
 assert pins()==approval['pins'];local_material(composition)
 report={'utc':datetime.now(timezone.utc).isoformat(),'operation':'official fn code update via exact local-config branch','environment':ENV,'function':FN,'expectedTree':composition['afterTree'],'configurationWritten':False,'businessDatabaseReadOrWritten':False,'modelCalls':0,'realSends':0,'status':'SUBMITTING'}
 def save():(D/'DEPLOYMENT-V2.json').write_text(json.dumps(report,indent=2),'utf-8')
 save()
 try:
  expected_config={'functionRoot':str(D/'candidate'),'functions':[{'name':FN,'dir':'.'}]}
  assert json.loads((SUBMIT/'cloudbaserc.json').read_text('utf-8'))==expected_config
  run=subprocess.run([NODE,CLI,'fn','code','update',FN,'--dir',str(D/'candidate'),'--deployMode','cos','-e',ENV,'--json'],capture_output=True,timeout=180,cwd=SUBMIT)
  # Only predefined signals are persisted; never store raw URLs, auth, or output.
  report['cliReportedCodeUpdated']=explicit_code_updated(run.stdout)
  report['cliExitCode']=run.returncode
  report['status']='SUBMITTED_NEEDS_READBACK' if run.returncode==0 and report['cliReportedCodeUpdated'] else 'FAILED_OR_UNKNOWN_READBACK_REQUIRED'
 except subprocess.TimeoutExpired:report['status']='TIMEOUT_READBACK_REQUIRED'
 except Exception as error:report.update(status='FAILED_OR_UNKNOWN_READBACK_REQUIRED',errorClass=type(error).__name__)
 save()
 try:
  try:local_material(composition);report['localCandidateUnchanged']=True
  except Exception:report['localCandidateUnchanged']=False
  after=protected(api('GetFunction',{'FunctionName':FN,'Namespace':ENV,'ShowCode':'FALSE'}))
  (D/'CONFIG-PROTECTED-V2-AFTER.json').write_text(json.dumps(after,indent=2),'utf-8')
  report['protectedConfigurationUnchanged']=before==after
  report['changedProtectedFields']=[k for k in before if before[k]!=after[k]]
  save()
  post=readback('readback-v2-postcommit');checked=verify(post,composition)
  report['readback']=checked
  report['status']='VERIFIED_CODE_ONLY_DEPLOYMENT' if before==after and checked['status']=='PASS' and report.get('cliReportedCodeUpdated') is True and report.get('localCandidateUnchanged') is True else 'VERIFICATION_FAILED_STOP'
 except Exception as error:report.update(status='VERIFICATION_FAILED_OR_UNKNOWN_STOP',verificationErrorClass=type(error).__name__)
 save();print(json.dumps(report))
 if report['status']!='VERIFIED_CODE_ONLY_DEPLOYMENT':raise SystemExit(3)
if __name__=='__main__':main()
