"""Explicit, candidate-only source assembly. Default is a read-only plan.
Never freezes, promotes, installs, launches a helper, touches data, or edits holds.
"""
from pathlib import Path
import argparse,hashlib,json,shutil,ast
T=Path(__file__).resolve().parent
TARGET=T/'assembly/project'
C=T/'candidate'
NEW='work/reply-complete-worker'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def files(root):return sorted(p for p in root.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc')
def plan():
 pairs=[]
 def addtree(source,destination):
  for p in files(source):pairs.append((p,TARGET/destination/p.relative_to(source)))
 for p in C.glob('*.py'):pairs.append((p,TARGET/'work/ui-native-r57'/p.name))
 addtree(C/'send','work/ui-native-r57')
 addtree(C/'web','work/ui-approved-implementation/ui-preview')
 for tree in ('runtime','worker'):
  for p in files(C/tree):
   rel=p.relative_to(C/tree)
   for dest in ('work/ui-runtime-r55/src','work/app/src'):
    pairs.append((p,TARGET/dest/rel))
   # vendor-src contains the same runtime packages; add newly introduced
   # modules only when their original package already exists.
   vendor=TARGET/'work/shared-backend-integration/vendor-src'
   if (vendor/rel.parent).is_dir():pairs.append((p,vendor/rel))
 addtree(C/'sharedvendor','work/shared-backend-integration/vendor-src')
 # This explicit tree wins over mirrors above.
 addtree(C/'shared','work/shared-backend-integration')
 addtree(C/'entry',NEW+'/source')
 addtree(T.parent/'multi-account-complete-20261026/component-v3/artifacts/platform-cli-customer-read',NEW+'/component/artifacts/platform-cli-customer-read')
 result={}
 for source,target in pairs:
  rel=target.relative_to(TARGET).as_posix()
  assert not rel.startswith(('data/','outputs/','work/source-v66-worker/'))
  result[rel]=(source,target)
 return [result[k] for k in sorted(result)]
def main():
 parser=argparse.ArgumentParser();parser.add_argument('--apply-candidate-only',action='store_true');options=parser.parse_args()
 pairs=plan()
 report={'target':str(TARGET),'plannedFiles':len(pairs),'applied':False,'productionEdited':False,'freezeExecuted':False}
 if not options.apply_candidate_only:
  print(json.dumps(report,ensure_ascii=False,indent=2));return
 if not (T/'assembly/BASE-COPY.complete.json').is_file():raise RuntimeError('Missing exact baseline completion marker')
 for source,target in pairs:
  target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,target)
 # Material source maps refer to final copied source bytes. Neither JSON
 # includes itself or the other material JSON: no circular source pin.
 sources={target.relative_to(TARGET).as_posix():sha(target) for _,target in pairs if target.suffix=='.py'}
 helper=TARGET/NEW/'component/artifacts/platform-cli-customer-read'
 tree={p.relative_to(TARGET).as_posix():sha(p) for p in files(helper)}
 exe=helper/'platform-cli-customer-read.exe'
 if not exe.is_file() or not tree:raise RuntimeError('Missing complete new helper runtime')
 native=TARGET/'work/ui-native-r57'
 material_digests={}
 for filename,protocol,flag in [('reply_public_read_materials.json','reply-profile-read-v1','--owned-xhs-cli-pages'),('reviewed_reply_materials.json','reviewed-reply-v1','--owned-xhs-reviewed-reply')]:
  material={'version':1,'protocol':protocol,'helperFlag':flag,'executable':exe.relative_to(TARGET).as_posix(),'executableSha256':sha(exe),'sources':sources,'runtimeTree':tree}
  (native/filename).write_text(json.dumps(material,ensure_ascii=False,indent=2)+'\n','utf-8')
  material_digests[filename]=hashlib.sha256(json.dumps(material,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
 for _,target in pairs:
  if target.suffix=='.py':ast.parse(target.read_bytes(),filename=str(target))
 report.update(applied=True,materials=material_digests,sourcePins=len(sources),runtimePins=len(tree),overlays={target.relative_to(TARGET).as_posix():sha(target) for _,target in pairs})
 (T/'assembly/ASSEMBLY.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n','utf-8')
 print(json.dumps({k:v for k,v in report.items() if k!='overlays'},ensure_ascii=False,indent=2))
if __name__=='__main__':main()

