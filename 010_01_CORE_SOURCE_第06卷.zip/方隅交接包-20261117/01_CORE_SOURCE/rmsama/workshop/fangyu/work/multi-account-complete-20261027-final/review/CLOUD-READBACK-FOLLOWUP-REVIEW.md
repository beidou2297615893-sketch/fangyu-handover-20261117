# 云代码更新后只读诊断批准

2026-10-27，Astra。

独立读取 DEPLOYMENT.json 与 readback-precommit/readback-postcommit：官方 code update CLI exit 0，受保护配置哈希不变；约 2.8 秒后的首次读回仍是原 843361adb2bf456a4c23ea86bdd2dad6904c7e92634001978226f8d74ed7a84b / 5618 文件，ZIP 也与提交前相同。现状态 VERIFICATION_FAILED_OR_UNKNOWN_STOP 是准确的，不能宣称部署通过，也不能仅凭此判断传播或更新失败原因。

批准以下有限只读跟进，不批准第二次更新：

1. 官方 GetFunction 仅提取 Status、LastModifiedTime、CodeSize、CodeSha256，以及 RequestId/错误码；不输出环境变量等原配置值。
2. 状态稳定为 Active 后，使用精确 read_live_code_once.py（3937480deecb679b141a0fb90cf5d617ac9f5c17d40373206e7a3c5e077785ab），在新的 readback-postcommit-stable 目录做一次完整 code readback；再由原 verify_readback.py（7b0ebcb074dd9f0f05341bd896288927afc88a73864b6d1ce8dc5967f1cb39e2）核对新候选 5619 文件/ZIP。
3. 若仍旧 baseline 或其他不匹配，保留证据并停止，转查实际 CLI 行为与参数，不自动重复 update 或无界轮询。

只有候选完整读回及配置不变证据成立，才能认定代码部署完成并继续本地更新审批。
