"""Synthetic scope rejection cases; no real profile or cookie access."""
import json,os,sys,tempfile
from pathlib import Path
from unittest.mock import patch
from types import SimpleNamespace
PROJECT=Path(__file__).resolve().parents[3]
SOURCE=PROJECT/'work/ui-runtime-r55/src'
VENDOR=PROJECT/'work/shared-backend-integration/vendor-src'
sys.path[:0]=[str(SOURCE),str(PROJECT/'work/shared-backend-integration')]
from platform_runtime import _load
_load('assistant.employee_distribution',VENDOR/'assistant/employee_distribution.py')
_load('assistant.business',VENDOR/'assistant/business.py')
_load('assistant.browser_login_window',VENDOR/'assistant/browser_login_window.py')
_load('assistant.browser_login_service',VENDOR/'assistant/browser_login_service.py')
xhs=_load('assistant.xhs_browser_login',VENDOR/'assistant/xhs_browser_login.py')
from core.store import Store
from core.adapters import Adapters
checks=[]
def check(name,fn,rejected=False):
    try:
        result=fn()
        assert not rejected
    except ValueError:
        assert rejected
    checks.append({'name':name,'passed':True})
temporary_parent=Path(__file__).parent
if '--merged-alias' in sys.argv:
    temporary_parent=Path(os.environ['LOCALAPPDATA'])/'fangyu-xhs-login-isolated-tests'
    temporary_parent.mkdir(exist_ok=True)
with tempfile.TemporaryDirectory(dir=temporary_parent) as folder:
    store=Store(folder)
    account=store.directory/'accounts/fixture-tenant/fixture-account'
    staging=account/'work/browser-login/abcdef012345678901234567'
    root=staging/'attempt-000001'
    cookie=root/'.xiaohongshu-cli/cookies.json'
    cookie.parent.mkdir(parents=True)
    cookie.write_text('synthetic-not-platform-credentials','ascii')
    native_resolve=Path.resolve
    def merged_resolve(path,*args,**kwargs):
        if path.absolute()==store.directory.absolute(): return path.absolute()
        return native_resolve(path,*args,**kwargs)
    def scope(root_arg=root,cookie_arg=cookie):
        if '--merged-alias' in sys.argv:
            assert store.directory!=native_resolve(store.directory)
            with patch.object(Path,'resolve',merged_resolve):
                return xhs._canonical_candidate_scope(store,account,staging,root_arg,cookie_arg)
        return xhs._canonical_candidate_scope(store,account,staging,root_arg,cookie_arg)
    view,canonical_account,canonical_root,canonical_cookie=scope()
    check('same original Store connection and database with canonical coordinates',lambda: (
        view._store is store and view.directory==store.directory.resolve() and
        view.connect.__self__ is view and canonical_cookie==cookie.resolve()) or (_ for _ in ()).throw(AssertionError()))
    check('original Adapters still validates canonical candidate',lambda: Adapters._validated_candidate_home('xiaohongshu',['status','--json'],canonical_account,canonical_root))
    outside=store.directory/'outside';outside.mkdir()
    check('outside candidate rejected before status or commit',lambda:scope(outside,cookie),True)
    other=root/'other.json';other.write_text('synthetic','ascii')
    check('wrong cookie name rejected',lambda:scope(root,other),True)
    cookie.unlink();os.link(other,cookie)
    check('actual hardlinked cookie rejected',scope,True)
    cookie.unlink();cookie.write_text('synthetic','ascii')
    database_link=store.directory/'database-hardlink';os.link(store.path,database_link)
    check('actual hardlinked original database rejected',scope,True)
    database_link.unlink()
    original_lstat=xhs.os.lstat
    def reparse(path,*args,**kwargs):
        info=original_lstat(path,*args,**kwargs)
        if Path(path)==root:
            return SimpleNamespace(st_mode=info.st_mode,st_nlink=info.st_nlink,
                st_file_attributes=getattr(info,'st_file_attributes',0)|0x400)
        return info
    with patch.object(xhs.os,'lstat',side_effect=reparse):
        check('reparse candidate rejected before resolving away lexical evidence',scope,True)
    check('plain scope remains valid after rejected alternatives',scope)
report={'status':'PASS','checks':checks,'real_profile_access':False,'real_cli':False,'real_network':False}
Path(__file__).with_name('MERGED-CANONICAL-SCOPE-BOUNDARIES.json' if '--merged-alias' in sys.argv else 'CANONICAL-SCOPE-BOUNDARIES.json').write_text(json.dumps(report,indent=2),'utf-8')
print(json.dumps(report))
