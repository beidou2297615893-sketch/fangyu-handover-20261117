// Evaluate the actual page hint against synthetic visible link DOM fixtures.
const fs=require('node:fs');
const vm=require('node:vm');
const path=require('node:path');
const project=path.resolve(__dirname,'../../..');
const file=path.join(project,'work/shared-backend-integration/vendor-src/assistant/browser_login_window.py');
const body=fs.readFileSync(file,'utf8');
const original=body.match(/OWN_PROFILE_MARKER_JS = r"""([\s\S]*?)"""/)[1];
const candidate=body.match(/OWN_PROFILE_CANDIDATE_JS = r"""([\s\S]*?)"""/)[1];
function run(script,label,href,visible=true){
  const link={innerText:label,closest:()=>null,getAttribute:name=>name==='href'?href:'',
    getBoundingClientRect:()=>({width:visible?60:0,height:24})};
  return vm.runInNewContext(script,{URL,location:{origin:'https://www.xiaohongshu.com',
    href:'https://www.xiaohongshu.com/explore'},document:{querySelectorAll:()=>[link]},
    getComputedStyle:()=>({display:'block',visibility:'visible',opacity:'1'})});
}
const checks=[
 ['old DOM wrapper requirement misses a visible own profile',run(original,'我','/user/profile/1234567890abcdef')===false],
 ['visible own profile without nav wrapper publishes only a candidate hint',run(candidate,'我','/user/profile/1234567890abcdef')===true],
 ['current personal-home label is accepted',run(candidate,'个人主页','/user/profile/1234567890abcdef')===true],
 ['whitespace in my-home label is normalized',run(candidate,'我 的 主 页','/user/profile/1234567890abcdef')===true],
 ['guest login link cannot trigger a candidate',run(candidate,'登录','/login')===false],
 ['another author link cannot trigger a candidate',run(candidate,'作者','/user/profile/1234567890abcdef')===false],
 ['hidden profile cannot trigger a candidate',run(candidate,'我','/user/profile/1234567890abcdef',false)===false],
 ['cross-origin profile cannot trigger a candidate',run(candidate,'我','https://example.com/user/profile/1234567890abcdef')===false],
 ['unresolved me link cannot trigger a candidate',run(candidate,'我','/user/profile/me')===false],
];
const report={status:checks.every(c=>c[1])?'PASS':'FAIL',authority:'DOM hint only; original CLI identity, claim and journal commit remain mandatory',
 real_browser:false,real_network:false,checks:checks.map(([name,passed])=>({name,passed}))};
fs.writeFileSync(path.join(__dirname,'PROFILE-HINT.json'),JSON.stringify(report,null,2));
process.stdout.write(JSON.stringify(report,null,2)+'\n');
process.exitCode=report.status==='PASS'?0:1;
