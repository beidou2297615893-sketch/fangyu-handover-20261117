"""Fixed diagnostic mappings; synthetic errors and directory metadata only."""
import json
from pathlib import Path
import sys
import tempfile
import time
from types import SimpleNamespace
PROJECT=Path(__file__).resolve().parents[3]
SOURCE=PROJECT/'work/ui-runtime-r55/src'
VENDOR=PROJECT/'work/shared-backend-integration/vendor-src'
sys.path[:0]=[str(SOURCE),str(PROJECT/'work/shared-backend-integration')]
from platform_runtime import _load
_load('assistant.employee_distribution',VENDOR/'assistant/employee_distribution.py')
_load('assistant.business',VENDOR/'assistant/business.py')
_load('assistant.browser_login_window',VENDOR/'assistant/browser_login_window.py')
_load('assistant.browser_login_service',VENDOR/'assistant/browser_login_service.py')
module=_load('assistant.xhs_browser_login',VENDOR/'assistant/xhs_browser_login.py')
from core.page_errors import CoreError
checks=[]
with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as folder:
    account=Path(folder).resolve()
    candidate=account/'work/browser-login/fixture/attempt-000001'
    candidate.mkdir(parents=True)
    core=SimpleNamespace(remote_safety_hold=False,employee_release_device_id='fixture',employee_release_until_monotonic=time.monotonic()+45)
    service=SimpleNamespace(server=SimpleNamespace(core=core),state='online')
    samples=[(ValueError('候选登录目录无效'),'candidate_path_validation',False),
             (CoreError('企业连接尚未确认，请稍后再试'),'enterprise_connection',True),
             (CoreError('企业云端未确认平台操作可用；本机已暂停小红书登录、采集与发送'),'safety_hold',True),
             (CoreError('方隅小红书自动登录、采集与发送已暂停；第三方 CLI 保护与真实流程尚未验收'),'release_lease',True),
             (ValueError('SYNTHETIC-SECRET-MUST-NOT-BE-LOGGED'),'other',False)]
    for error,stage,is_core in samples:
        result=module._status_failure_context(error,service,account,candidate)
        assert result['preflight_stage']==stage and result['error_is_core'] is is_core
        assert all(result[key] is True for key in ('candidate_lexical_is_canonical','candidate_lexical_under_resolved_account','candidate_resolved_under_resolved_account','candidate_is_directory','employee_lease_alive'))
        encoded=json.dumps(result)
        assert 'SYNTHETIC' not in encoded and 'fixture' not in encoded and str(account) not in encoded
        checks.append({'stage':stage,'passed':True})
    def _validated_candidate_home():
        raise ValueError('SYNTHETIC-SECRET-MUST-NOT-BE-LOGGED')
    try: _validated_candidate_home()
    except ValueError as error:
        result=module._status_failure_context(error,service,account,candidate)
        assert result['preflight_stage']=='candidate_path_validation'
        checks.append({'stage':'fixed_function_projection','passed':True})
    core.remote_safety_hold=True
    core.employee_release_until_monotonic=0
    service.state='offline'
    result=module._status_failure_context(CoreError('企业连接尚未确认，请稍后再试'),service,account,candidate)
    assert result['remote_safety_hold'] is True and result['employee_lease_alive'] is False and result['service_state']=='offline'
    checks.append({'stage':'current_guard_facts','passed':True})
report={'status':'PASS','checks':checks,'real_cookie_read':False,'real_cli':False,'real_network':False}
Path(__file__).with_name('PREFLIGHT-CONTEXT-MAPPINGS.json').write_text(json.dumps(report,indent=2),'utf-8')
print(json.dumps(report))
