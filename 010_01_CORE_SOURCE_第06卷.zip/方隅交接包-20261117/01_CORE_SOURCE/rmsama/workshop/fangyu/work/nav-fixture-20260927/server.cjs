'use strict';
// Loopback-only navigation reproduction. All service results are invented.
// Product HTML, app.mjs, CSS and assets are served unchanged from the source site.
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const {serveSite} = require('../cloud/workspace/site.cjs');
const config = {environmentId:'fixture-env',companyId:'fangyu-apartment-client',
  safetyHold:true,releaseVersion:'',pairingAllowed:true,pairingVersion:'1.1.7-qa.1'};
const fixtureTransport = `/* Fictional transport for local navigation reproduction only. */
export class WorkspaceError extends Error { constructor(message,details={}){super(message);Object.assign(this,details);} }
export class WorkspaceCloud {
 constructor(config){Object.assign(this,config);this.token='';this.user=null;}
 async call(operation){
  const base={contract:'fangyu-workspace-v1',environment_id:'fixture-env',company_id:'fangyu-apartment-client'};
  if(operation==='logout')return base;
  if(!this.user)throw new WorkspaceError('虚构测试页：请先登录',{status:401});
  if(operation==='devices')return {...base,devices:[]};
  if(operation==='list')return {...base,items:[],revision:1,total:0,count:0,max_batch:100,next_cursor:''};
  if(operation==='members')return {...base,users:[this.user]};
  throw new WorkspaceError('本地导航复现页不执行此操作');
 }
 async login(username,password){
  if(username!=='fixture-staff'||password!=='Fixture-Only-1234')throw new WorkspaceError('请使用页面复现专用虚构账号',{status:401});
  this.token='fixture-memory-only';this.user={username:'fixture-staff',role:'operator',disabled:false};return this.user;
 }
 async logout(){this.token='';this.user=null;}
 async submit(){throw new WorkspaceError('本地导航复现页没有设备，不执行任务');}
 async inspect(){throw new WorkspaceError('本地导航复现页没有任务');}
}
`;
const server = http.createServer((req,res)=>{
 try {
  if(req.method!=='GET'){res.writeHead(405);res.end('Fixture is read-only');return;}
  const url = new URL(req.url,'http://127.0.0.1');
  const asset = url.searchParams.get('asset')||'';
  if(asset==='config.mjs'||asset==='transport.mjs'){
   res.writeHead(200,{'Content-Type':'text/javascript; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});
   res.end(asset==='config.mjs'?'export const config='+JSON.stringify(config)+';':fixtureTransport);return;
  }
  const result=serveSite({queryStringParameters:{asset}});
  res.writeHead(result.statusCode,result.headers);
  res.end(result.isBase64Encoded?Buffer.from(result.body,'base64'):result.body);
 }catch{res.writeHead(500);res.end('Local fixture error');}
});
server.listen(0,'127.0.0.1',()=>{
 const ready={url:'http://127.0.0.1:'+server.address().port+'/',pid:process.pid,
  username:'fixture-staff',password:'[REDACTED:assigned_secret]',fictional:true};
 fs.writeFileSync(path.join(__dirname,'ready.json'),JSON.stringify(ready,null,2));
 process.stdout.write(JSON.stringify(ready)+'\n');
});
