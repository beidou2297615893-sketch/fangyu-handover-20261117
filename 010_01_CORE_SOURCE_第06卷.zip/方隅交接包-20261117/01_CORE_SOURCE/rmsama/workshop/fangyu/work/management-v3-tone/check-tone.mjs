import assert from 'node:assert/strict';
import {readFileSync,writeFileSync,existsSync} from 'node:fs';
import {fileURLToPath} from 'node:url';
import {render,bind,toneChoices,tonePreview} from '../ui-approved-implementation/ui-preview/pages/management-tone.mjs';

const checks=[];
async function check(name,fn){await fn();checks.push({name,ok:true});console.log('PASS '+name);}
const preferences=(extra={})=>({actor:{username:'admin-a',storeId:'store-a'},revision:4,identity:'方隅门店顾问',tone:'friendly',salutation:'你好',focus:['budget','moveIn','housing'],...extra});
const state=(extra={})=>({page:'tone',connection:'connected',user:'admin-a',storeId:'store-a',store:'验证门店',session:{user:{username:'admin-a',role:'admin'}},stores:[{id:'store-a',name:'验证门店'},{id:'store-b',name:'第二门店'}],tonePreferences:preferences(),...extra});
const deferred=()=>{let resolve,reject;const promise=new Promise((a,b)=>{resolve=a;reject=b;});return {promise,resolve,reject};};
class Element{
  constructor(value=''){this.value=value;this.checked=false;this.listeners={};this.textContent='';this.attrs={};this.classList={toggle:()=>{}};this.selectionStart=1;this.selectionEnd=2;}
  addEventListener(name,fn){this.listeners[name]=fn;}
  fire(name){return this.listeners[name]?.({target:this,preventDefault(){}});}
  setAttribute(k,v){this.attrs[k]=v;}
  closest(){return {classList:{toggle(){}}};}
  focus(){this.focused=true;}
  setSelectionRange(a,b){this.range=[a,b];}
}
function harness(s=state(),actions={}){
  const elements=new Map(),groups=new Map(),calls=[],modals=[],doc={activeElement:null};
  const root={ownerDocument:doc,querySelector:k=>elements.get(k)||null,querySelectorAll:k=>groups.get(k)||[]};
  const ctx={state:s,actions,update:fn=>{calls.push('render');fn(s);render(s);},modal:options=>{modals.push(options);return options;}};
  const add=(key,value='')=>{const el=new Element(value);elements.set(`[data-mt-${key}]`,el);return el;};
  render(s);for(const key of ['identity','salutation','preview','feedback','summary','form','save','reset','reload','store','switch'])add(key,s.toneDraft[key]||'');
  const tones=Object.keys(toneChoices).map(k=>{const el=new Element(k);el.checked=s.toneDraft.tone===k;return el;});
  const focuses=['budget','moveIn','housing'].map(k=>{const el=new Element(k);el.checked=s.toneDraft.focus.includes(k);return el;});
  groups.set('[data-mt-tone]',tones);groups.set('[data-mt-focus]',focuses);
  const cleanup=bind(root,ctx);return {s,ctx,root,doc,calls,modals,tones,focuses,cleanup,element:key=>elements.get(`[data-mt-${key}]`)};
}

await check('canonical choices and three local styles',()=>{
  assert.deepEqual(toneChoices,{friendly:'自然友好',concise:'简洁直接',patient:'耐心解答'});
  const texts=Object.keys(toneChoices).map(tone=>tonePreview(preferences({tone})));
  assert.equal(new Set(texts).size,3);texts.forEach(text=>{assert.match(text,/你好，我是方隅门店顾问/);assert.match(text,/预算和入住时间/);assert.match(text,/房源/);});
});
await check('optional greeting and focus materially change the preview',()=>{
  assert.doesNotMatch(tonePreview(preferences({salutation:'',focus:[]})),/你好|预算|入住时间|匹配房源/);
  assert.match(tonePreview(preferences({salutation:'您好，',focus:['budget']})),/^您好，我是/);
  assert.doesNotMatch(tonePreview(preferences({focus:['budget']})),/入住时间|合适的房源/);
});
await check('invalid identity, multiline, long text and unknown options reject',()=>{
  for(const extra of [{identity:''},{identity:'x'.repeat(81)},{identity:'甲\n乙'},{salutation:'x'.repeat(21)},{salutation:'甲\u2028乙'},{tone:'official'},{focus:['income']},{focus:'budget'}])assert.throws(()=>tonePreview(preferences(extra)));
});
await check('unconfigured identity stays blank and all user content is escaped',()=>{
  const empty=render(state({tonePreferences:preferences({identity:''})}));assert.match(empty,/value="" placeholder="请如实填写身份"/);assert.match(empty,/请先填写向客户说明的真实身份/);assert.doesNotMatch(empty,/我是方隅/);
  const html=render(state({tonePreferences:preferences({identity:'<img onerror="x">'})}));assert.match(html,/&lt;img onerror=&quot;x&quot;&gt;/);assert.doesNotMatch(html,/<img onerror=/);
});
await check('operator controls and submit stay read-only',async()=>{
  let saves=0;const s=state({session:{user:{username:'admin-a',role:'operator'}}});const h=harness(s,{saveTonePreferences:()=>{saves++;}});
  assert.match(render(s),/data-mt-identity[\s\S]*?disabled/);h.element('identity').value='篡改';h.element('identity').fire('input');await h.element('form').fire('submit');assert.equal(saves,0);assert.equal(s.toneDraft.identity,'方隅门店顾问');
});
await check('dirty values and revision survive background refresh',()=>{
  const h=harness();h.element('identity').value='编辑中的真实身份';h.element('identity').fire('input');h.s.tonePreferences=preferences({revision:5,identity:'服务器新版'});
  const html=render(h.s);assert.equal(h.s.toneDraft.identity,'编辑中的真实身份');assert.equal(h.s.toneDraft.expectedRevision,4);assert.match(html,/重新读取已保存方案/);assert.match(h.element('preview').textContent,/编辑中的真实身份/);
});
await check('actor and store changes reject previous configuration and draft',()=>{
  for(const extra of [{user:'admin-b',session:{user:{username:'admin-b',role:'admin'}}},{storeId:'store-b',store:'第二门店'}]){const s=state();render(s);s.toneDraft.identity='旧私有草稿';s.toneDraft.dirty=true;Object.assign(s,extra);const html=render(s);assert.equal(s.toneDraft.identity,'');assert.doesNotMatch(html,/旧私有草稿|方隅门店顾问/);}
});
await check('initial read runs once and accepts the actor envelope',async()=>{
  const pending=deferred();let reads=0;const s=state({tonePreferences:null});const h=harness(s,{readTonePreferences:()=>{reads++;return pending.promise;}});
  bind(h.root,h.ctx);await Promise.resolve();assert.equal(reads,1);assert.equal(s.toneDraft.loadStatus,'loading');s.tonePreferences=preferences();pending.resolve(s.tonePreferences);await pending.promise;await new Promise(setImmediate);assert.equal(s.toneDraft.loadStatus,'ready');assert.equal(s.toneDraft.identity,'方隅门店顾问');
});
await check('blank identity save validates locally without backend write',async()=>{
  let saves=0;const h=harness(state({tonePreferences:preferences({identity:''})}),{saveTonePreferences:()=>{saves++;}});await h.element('form').fire('submit');assert.equal(saves,0);assert.match(h.s.toneDraft.error,/真实身份/);
});
await check('save carries expected revision, blocks duplicates and reports success',async()=>{
  const pending=deferred(),calls=[];const h=harness(state(),{saveTonePreferences:p=>{calls.push(p);return pending.promise;}});
  h.element('identity').value='门店同事';h.element('identity').fire('input');const first=h.element('form').fire('submit');await h.element('form').fire('submit');assert.equal(calls.length,1);assert.deepEqual(calls[0],{identity:'门店同事',tone:'friendly',salutation:'你好',focus:['budget','moveIn','housing'],expectedRevision:4});
  h.s.tonePreferences=preferences({identity:'门店同事',revision:5});pending.resolve(h.s.tonePreferences);await first;assert.equal(h.s.toneDraft.dirty,false);assert.equal(h.s.toneDraft.expectedRevision,5);assert.equal(h.s.toneDraft.feedback,'方案已保存。');assert.equal(h.s.toneDraft.saving,false);
});
await check('failed save keeps the actual draft and exposes inline failure',async()=>{
  const h=harness(state(),{saveTonePreferences:()=>null});h.element('identity').value='仍需保留的身份';h.element('identity').fire('input');await h.element('form').fire('submit');assert.equal(h.s.toneDraft.identity,'仍需保留的身份');assert.equal(h.s.toneDraft.dirty,true);assert.match(render(h.s),/role="alert"[^>]*>保存失败/);
});
await check('stale save revision cannot claim success',async()=>{
  const h=harness(state(),{saveTonePreferences:()=>preferences()});h.element('identity').value='修改';h.element('identity').fire('input');await h.element('form').fire('submit');assert.equal(h.s.toneDraft.dirty,true);assert.match(h.s.toneDraft.error,/保存失败/);
});
await check('late save cannot update a different store draft',async()=>{
  const pending=deferred();const h=harness(state(),{saveTonePreferences:()=>pending.promise});h.element('identity').value='旧门店编辑';h.element('identity').fire('input');const saving=h.element('form').fire('submit');h.s.storeId='store-b';h.s.store='第二门店';render(h.s);const newDraft=h.s.toneDraft;pending.resolve(preferences({revision:5,identity:'旧门店编辑'}));await saving;assert.equal(h.s.toneDraft,newDraft);assert.equal(newDraft.identity,'');assert.equal(newDraft.feedback,'');
});
await check('late read cannot update a different employee draft',async()=>{
  const pending=deferred();const h=harness(state({tonePreferences:null}),{readTonePreferences:()=>pending.promise});await Promise.resolve();h.s.user='admin-b';h.s.session.user.username='admin-b';render(h.s);pending.resolve(preferences());await pending.promise;await new Promise(setImmediate);assert.equal(h.s.toneDraft.identity,'');assert.equal(h.s.toneDraft.loadStatus,'idle');
});
await check('root loading and failed read never trigger automatic retry loops',async()=>{
  for(const extra of [{tonePreferencesLoading:true},{tonePreferencesError:'连接未完成'}]){let reads=0;const h=harness(state({tonePreferences:null,...extra}),{readTonePreferences:()=>{reads++;return null;}});bind(h.root,h.ctx);await new Promise(setImmediate);assert.equal(reads,0);if(extra.tonePreferencesError)assert.match(render(h.s),/连接未完成[\s\S]*data-mt-reload/);}
});
await check('leaving the page during save does not leave a stuck saving flag',async()=>{
  const pending=deferred();const h=harness(state(),{saveTonePreferences:()=>pending.promise});const saving=h.element('form').fire('submit');h.s.page='reply';h.s.tonePreferences=preferences({revision:5});pending.resolve(h.s.tonePreferences);await saving;assert.equal(h.s.toneDraft.saving,false);assert.equal(h.s.toneDraft.expectedRevision,5);
});
await check('reset changes editable values but retains concurrency revision',()=>{
  const h=harness();h.element('reset').fire('click');assert.equal(h.s.toneDraft.identity,'');assert.equal(h.s.toneDraft.salutation,'你好');assert.equal(h.s.toneDraft.expectedRevision,4);assert.equal(h.s.toneDraft.dirty,true);
});
await check('dirty reload requires the concrete discard modal before reading',async()=>{
  let reads=0;const h=harness(state(),{readTonePreferences:()=>{reads++;return preferences();}});h.element('identity').value='未保存';h.element('identity').fire('input');h.element('reload').fire('click');assert.equal(reads,0);assert.equal(h.modals.length,1);h.modals[0].onConfirm();await new Promise(setImmediate);assert.equal(reads,1);
});
await check('cleanup preserves in-progress text and focus across a redraw',()=>{
  const h=harness();h.doc.activeElement=h.element('identity');h.element('identity').value='尚在输入的中文';h.cleanup();render(h.s);assert.equal(h.s.toneDraft.identity,'尚在输入的中文');assert.equal(h.s.toneDraft.focusedField,'identity');bind(h.root,h.ctx);assert.equal(h.element('identity').focused,true);assert.deepEqual(h.element('identity').range,[1,2]);
});
await check('all declared visual assets already exist and CSS stays page-scoped',()=>{
  const html=render(state()),local='../ui-approved-implementation/ui-preview',legacy='../ui-runtime-r56/src/web/workspace';
  for(const file of Array.from(html.matchAll(/src="\/assets\/([^"?]+)/g),m=>m[1]))assert.ok(existsSync(fileURLToPath(new URL(`${local}/assets/${file}`,import.meta.url)))||existsSync(fileURLToPath(new URL(`${legacy}/assets/${file}`,import.meta.url))),file);
  const css=readFileSync(new URL(`${local}/pages/management-tone.css`,import.meta.url),'utf8');assert.doesNotMatch(css,/(?:^|\n)\s*(?:\.shell|body|html|:root)\s*[{.]/);assert.doesNotMatch(html,/<svg/);
});
writeFileSync(new URL('./checks.json',import.meta.url),JSON.stringify({method:'Node pure-function, render and bind fixtures; no server, browser, cloud or actual sends',passed:checks.length,checks},null,2)+'\n');
console.log(`PASS ${checks.length} checks`);
