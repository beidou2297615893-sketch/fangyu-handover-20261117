# IP与口吻 v3 接入交接

本分支仅新增两个页面文件和本工作目录内的验证材料，未修改 app/backend/旧 reply-templates、其他产品文件或业务数据。

## 文件与入口

- `C:/积木软件工坊/项目/方隅公寓客户版/work/ui-approved-implementation/ui-preview/pages/management-tone.mjs`：`render(state)`、`bind(root, ctx)`、`toneChoices`、`tonePreview(preferences)`。
- `C:/积木软件工坊/项目/方隅公寓客户版/work/ui-approved-implementation/ui-preview/pages/management-tone.css`：全部选择器限于 `.management-tone-page`，沿用宿主字体、图片和图标；宿主负责 tone route/nav、管理253px侧栏和标题区域。
- 参考图：`C:/积木软件工坊/项目/方隅公寓客户版/outputs/管理页面设计/02-IP与口吻-v3.png`，实际读取后实施。

`toneChoices` 为冻结对象：`{friendly:'自然友好', concise:'简洁直接', patient:'耐心解答'}`，可用 `Object.entries` 建选项。

`tonePreview` 为纯字符串模板函数，复用既有 reply-templates 的真实身份校验与租房提问文案思路，无AI、无保存、无覆盖、无发送。身份必填1—80字，称呼0—20字，均要求单行；focus只允许budget/moveIn/housing，可为空数组。非法参数抛中文Error。身份默认空时管理页显示未配置提示，不捏造身份。

## 后端约定

读取 `ctx.state.tonePreferences={actor:{username,storeId},revision,identity,tone,salutation,focus}`。只有actor匹配才显示。调用 `ctx.actions.readTonePreferences()`，读取失败给手动重读，不自动循环。兼容根 `tonePreferencesLoading` / `tonePreferencesError`。

保存调用 `ctx.actions.saveTonePreferences({identity,tone,salutation,focus,expectedRevision})`，成功返回新preferences，失败返回null。页面负责成功/失败反馈、同步draft/revision/dirty和ctx.update重绘。只有真实已登录admin可修改保存；operator只读。默认身份可为空，但保存要求填写。

`state.toneDraft` 仅保存本页稿：scope、identity、tone、salutation、focus、expectedRevision、loadedRevision、dirty、saving、loadStatus、error、feedback、focusedField、selectionStart/End。背景刷新不覆盖dirty字段；重新读取或切店遇dirty时先确认丢弃修改；跨actor/门店晚回不修改新draft。初次读取用微任务，避免bind内同步render导致旧cleanup覆盖。

## 验证与限制

命令：`node C:/积木软件工坊/项目/方隅公寓客户版/work/management-v3-tone/check-tone.mjs`。

20项Node检查全部通过，结果为同目录checks.json：三口吻/可选重点称呼、非法输入、空身份/XSS、operator只读、dirty刷新保留、跨人跨店晚回、首读去重、Loading/Error不自动重试、保存重复与失败、版本守卫、离页保存、默认重置、丢弃确认、输入/光标保留、现有资产存在与CSS作用域。

未启动服务器、浏览器、云或平台；真实截图、外壳整合、页面视觉及后端端到端仍由主任务验收。已认可设计图不等于本次实现已获用户认可。未使用localStorage。
