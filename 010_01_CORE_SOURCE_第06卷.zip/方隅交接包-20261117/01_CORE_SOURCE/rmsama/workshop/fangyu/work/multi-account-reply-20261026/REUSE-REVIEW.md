# 本轮复用判断

本轮使用已有 fa72ab42 工程作增量，不引入新的账号、浏览器、消息队列或模型执行框架。

- 已公开查阅 jackwener/xiaohongshu-cli 与 Yht20927/douyin-cli 的 GitHub 资料，并核对本地原有适配资料。小红书固定版本 0.6.4，Apache-2.0，要求 Python >=3.10；当前工作台 Python 3.11 与现有账号目录隔离结构可继续复用。抖音本地适配声明版本 2.0.0；本轮不替换其二进制及许可证包。
- GitHub CLI 本机已安装，但未认证；公开资料检索沿 web 工具完成，未要求用户登录、未读取凭据。
- 上游的用户资料命令存在，不等于当前正式受控接口已支持。当前 allowlist 无 user/user-posts，本轮不绕过受控接口去读主页，不引入自动提取其他浏览器登录资料的行为。
- 原 Workflow、账号作用域、审核事务、语气样本、重复客户保护和发送暂停全部复用。缺口仅为账号真实资料、明确需求证据、可解释推荐、唯一指派与分组界面，因此新增本地薄层。
- 界面复用原项目表单、原生选择框和弹窗，保持已认可布局。新增依赖为零。UI 资源库已评估，无须迁移 shadcn/Ant Design 或重做页面。

本轮验收为本地代码和隔离测试，不代表平台真实主页读取、自动切号或外发已经验证。

来源：
- https://github.com/jackwener/xiaohongshu-cli
- https://github.com/Yht20927/douyin-cli
- 原固定源 resources/licenses/xiaohongshu-cli-upstream-metadata.toml
- 原固定源 resources/adapters/douyin.json
