"""Account facts and explicit rental needs only. No platform/model/sending operations."""
from copy import deepcopy
from contextlib import contextmanager
from datetime import datetime
import hashlib,json,re
from urllib.parse import urlsplit

ACTIONS=frozenset(('reply_accounts_read','reply_account_profile_save','reply_route_preview','reply_assignment_save','reply_evidence_save'))
PROFILES='ui_reply_account_profiles_v1'; EVIDENCE='ui_reply_customer_evidence_v1'; ASSIGNMENTS='ui_reply_customer_assignment_v1'; RECEIPTS='ui_reply_account_receipts_v1'
TOPICS=('pet','commute','budget','space','movein','language')
KEY=re.compile(r'[A-Za-z0-9_:\-]{1,300}\Z')
def digest(x):return hashlib.sha256(json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
class ProfileError(ValueError):
 code='REPLY_ACCOUNT_CONFLICT';status=409;mutation_committed=False

def explicit_topics(text):
 if not isinstance(text,str):return []
 patterns={'pet':r'(能|可以|允许|可不可以|能不能).{0,8}(养猫|养狗|养宠物|带猫|带狗|宠物)|(带猫|带狗|养猫|养狗|宠物|有.{0,4}[猫狗]).{0,20}(租|找|房|入住|可|允许)',
 'commute':r'(租房|找房|房子|通勤|上班).{0,16}(地铁|通勤|公司|上班|分钟)|(近|靠近|步行).{0,8}地铁|要.{0,6}地铁.{0,4}附近',
 'budget':r'(预算|租金|月租|房租).{0,12}([0-9零一二两三四五六七八九千万百]+|便宜|低|贵|实惠)',
 'space':r'(租|找|房|需要|想要).{0,12}(两房|二房|三房|一房|一室|两室|二室|三室|卧室|平米|平方|大一点|独居)',
 'movein':r'(入住|搬家|起租|租期|短租|长租).{0,12}(时间|[0-9一二三四五六七八九十]+|月|年|周|天|马上|近期)|(下月|下周|月底|近期|马上).{0,8}(入住|搬家|起租)',
 'language':r'(需要|希望|可以|能|支持|想).{0,12}(英文|英语|English|中文|普通话).{0,8}(沟通|交流|服务)|(沟通|交流|服务).{0,8}(英文|英语|English|中文|普通话)'}
 found=[k for k in TOPICS if re.search(patterns[k],text,re.I)]
 negatives={'pet':r'(不养|没养|没有养|不带).{0,4}(猫|狗|宠物)|不(需要|考虑|要).{0,6}宠物', 'language':r'(不需要|不用|不想|不要).{0,8}(英文|英语|English|中文|普通话)'}
 return [k for k in found if not re.search(negatives.get(k,r'(?!)'),text,re.I)]

class AccountProfiles:
 def __init__(self,backend):self.b=backend;self.subjects={}
 def scope(self,token,data):
  if not isinstance(data,dict) or data.get('platform') not in ('xiaohongshu','douyin'):raise ProfileError('请选择当前平台')
  user,profile=self.b._identity(token);store=self.b._selected_store(user,profile)
  if data.get('storeId')!=store or profile.get('can_reply') is False or user.get('can_reply') is False:raise ProfileError('当前门店或回复权限已变化')
  return user,[user['tenant_id'],user['id'],user['username'],store,data['platform']]
 def key(self,scope,kind,subject):
  subject=self.subjects.get(subject,subject) if kind in ('assignment','evidence') else subject
  return digest([scope if kind=='request' else [scope[0],scope[3],scope[4]],kind,subject])
 def identity_binding(self,a):return digest({k:a.get(k) for k in ('id','tenant_id','cloud_owner','store_id','platform','platform_uid','conn_id')})
 def account(self,user,scope,ident):
  a=self.b.core.store.get('accounts',ident)
  if not a or any(a.get(k)!=v for k,v in {'tenant_id':scope[0],'cloud_owner':scope[2],'store_id':scope[3],'platform':scope[4]}.items()):raise ProfileError('请选择本人当前门店的实际账号')
  self.b.core._account_access(user,a);return a
 def accounts(self,user,scope):
  out=[]
  for a in self.b.core.store.list('accounts',scope[0]):
   try:self.account(user,scope,a['id'])
   except ValueError:continue
   p=self.profile(scope,a['id'])
   if p['configured']:
    p['identityCurrent']=p.get('accountIdentity')==self.identity_binding(a)
    p['identityNotice']='本人确认资料，未独立核验' if a.get('platform_uid') else '平台身份待核对，仅本地草稿'
   out.append({'id':a['id'],'name':str(a.get('platform_nickname') or a.get('name') or '实际账号'),'platform':scope[4],'profile':p})
  return out
 def profile(self,scope,ident):
  row=self.b.core.store.get(PROFILES,self.key(scope,'profile',ident))
  return deepcopy(row['value']) if row else {'revision':0,'configured':False,'displayName':'','roleFacts':'','tone':'','topics':[],'confirmed':False}
 def customer(self,user,scope,ident):
  w=self.b.reply_workbench.read(user,scope[3],ident,platform=scope[4],_routing_check=False)
  if w.get('item',{}).get('platform',scope[4])!=scope[4]:raise ProfileError('客户不属于当前平台')
  # Resolve subject only from the original authorized lead; never infer from label.
  subjects=set()
  for c in w.get('comments',[]):
   lead=self.b.core.store.get('leads',c['id']) or {}
   if lead.get('tenant_id')==scope[0] and lead.get('platform')==scope[4] and lead.get('author_id'):subjects.add(str(lead['author_id']))
  if len(subjects)!=1:raise ProfileError('客户稳定平台身份缺失或不一致，请先核对原评论')
  uid=next(iter(subjects));self.subjects[ident]=uid
  return w,uid
 def record(self,entity,scope,kind,ident,default):
  r=self.b.core.store.get(entity,self.key(scope,kind,ident));return deepcopy(r['value']) if r else deepcopy(default)
 def evidence(self,scope,ident):return self.record(EVIDENCE,scope,'evidence',ident,{'revision':0,'items':[]})
 def assignment(self,scope,ident):return self.record(ASSIGNMENTS,scope,'assignment',ident,{'revision':0,'accountId':''})
 def customer_view(self,user,scope,ident):
  w,uid=self.customer(user,scope,ident)
  return {'customerId':ident,'subjectId':uid,'name':w['item'].get('name','客户'),'evidence':self.evidence(scope,ident),'assignment':self.assignment(scope,ident)}
 @contextmanager
 def transaction(self):
  store=self.b.core.store
  if hasattr(store,'connect'):
   with store.connect() as db:
    db.execute('BEGIN IMMEDIATE');yield db
  else:yield None
 def put(self,db,entity,row):
  if db is None:self.b.core.store.put(entity,row)
  else:db.execute('INSERT OR REPLACE INTO records VALUES(?,?,?,?)',(entity,row['id'],row['tenant_id'],json.dumps(row,ensure_ascii=False,allow_nan=False)))
 def mutate(self,action,data,user,scope,entity,kind,subject,value,validate=None):
  req=data.get('requestId')
  if not isinstance(req,str) or not KEY.fullmatch(req):raise ProfileError('操作编号无效')
  if type(data.get('expectedRevision')) is not int or data['expectedRevision']<0:raise ProfileError('请读取当前版本')
  rid=self.key(scope,'request',req);key=self.key(scope,kind,subject);finger=digest([action,data])
  with self.transaction() as db:
   prior=self.b.core.store.get(RECEIPTS,rid)
   if prior:
    if prior.get('fingerprint')!=finger:raise ProfileError('原操作编号已用于不同内容，请核对原操作')
    return {'requestId':req,'state':'accepted','revision':prior['revision'],'replayed':True}
   if validate:validate()
   current=self.b.core.store.get(entity,key);rev=current['value']['revision'] if current else 0
   if rev!=data['expectedRevision']:raise ProfileError('资料版本已变化，请重新读取后保存')
   value={**deepcopy(value),'revision':rev+1}
   self.put(db,entity,{'id':key,'tenant_id':scope[0],'scope':scope,'subject':subject,'value':value})
   self.put(db,RECEIPTS,{'id':rid,'tenant_id':scope[0],'scope':scope,'action':action,'fingerprint':finger,'revision':rev+1})
   return {'requestId':req,'state':'accepted','revision':rev+1,'replayed':False}
 def preview(self,user,scope,ids):
  accounts=self.accounts(user,scope);routes=[]
  for ident in ids:
   w,uid=self.customer(user,scope,ident);view=self.customer_view(user,scope,ident);ev=[]
   for c in w['comments']:
    for topic in explicit_topics(c.get('text','')):ev.append({'topic':topic,'quote':c['text'],'source':'comment','sourceUrl':c.get('postUrl',''),'subjectId':uid})
   for item in view['evidence']['items']:
    for topic in explicit_topics(item['quote']):ev.append({'topic':topic,'quote':item['quote'],'source':'manual','sourceUrl':item['sourceUrl'],'subjectId':uid})
   eligible=type(w.get('item',{}).get('rank')) is int and w['item']['rank']>=2 and w['item'].get('contactState') not in ('sent','unknown','sending')
   topics=sorted({e['topic'] for e in ev}) if eligible else [];candidates=[]
   for a in accounts:
    p=a['profile'];overlap=sorted(set(topics)&set(p['topics']))
    if p['configured'] and p['confirmed'] and p.get('identityCurrent',True):candidates.append({'accountId':a['id'],'score':len(overlap),'reasons':overlap})
   candidates.sort(key=lambda x:(-x['score'],x['accountId']))
   tied=bool(len(candidates)>1 and candidates[0]['score']>0 and candidates[0]['score']==candidates[1]['score'])
   routes.append({'customerId':ident,'name':view['name'],'subjectId':uid,'evidenceRevision':view['evidence']['revision'],'assignmentRevision':view['assignment']['revision'],'assignment':view['assignment'],'recommendedAccountId':candidates[0]['accountId'] if candidates and candidates[0]['score']>0 and not tied else '','topics':topics,'evidence':ev,'candidates':candidates,'needsManualChoice':tied,'eligible':eligible,'notice':'' if eligible else '仅高意向且未联系客户可推荐'})
  groups={}
  for r in routes:
   a=r['assignment'].get('accountId')
   profile=next((item['profile'] for item in accounts if item['id']==a),None)
   current=bool(profile and profile.get('identityCurrent',True) and profile['revision']==r['assignment'].get('profileRevision') and r['evidenceRevision']==r['assignment'].get('evidenceRevision'))
   r['assignmentCurrent']=current
   if a and r['eligible'] and current:groups.setdefault(a,[]).append(r['customerId'])
  return {'accounts':accounts,'routes':routes,'groups':[{'accountId':a,'customerIds':v} for a,v in groups.items()],'topics':list(TOPICS)}
 def dispatch(self,action,data,token):
  with self.b.lock,getattr(self.b.core,'lock',self.b.lock):
   user,scope=self.scope(token,data)
   common={'storeId','platform'}
   fields={'reply_accounts_read':{'customerIds'},'reply_route_preview':{'customerIds'},'reply_account_profile_save':{'accountId','expectedRevision','requestId','profile'},'reply_evidence_save':{'customerId','expectedRevision','requestId','items'},'reply_assignment_save':{'customerId','accountId','expectedRevision','expectedProfileRevision','expectedEvidenceRevision','requestId'}}
   if action not in fields or set(data)-(common|fields[action]):raise ProfileError('账号回复参数无效')
   ids=data.get('customerIds',[])
   if action in ('reply_accounts_read','reply_route_preview'):
    if not isinstance(ids,list) or len(ids)>300 or any(not isinstance(x,str) or not x for x in ids) or len(set(ids))!=len(ids):raise ProfileError('请选择不重复的客户')
    if action=='reply_route_preview':return {'replyAccounts':self.preview(user,scope,ids)}
    return {'replyAccounts':{'accounts':self.accounts(user,scope),'customers':[self.customer_view(user,scope,x) for x in ids],'topics':list(TOPICS)}}
   if action=='reply_account_profile_save':
    subject=data.get('accountId');actual_account=self.account(user,scope,subject);p=data.get('profile')
    if not isinstance(p,dict) or set(p)!={'displayName','roleFacts','tone','topics','confirmed'}:raise ProfileError('账号资料字段无效')
    if any(not isinstance(p[k],str) or len(p[k])>({'displayName':100,'roleFacts':2000,'tone':2000}[k]) for k in ('displayName','roleFacts','tone')) or not isinstance(p['topics'],list) or len(set(p['topics']))!=len(p['topics']) or any(x not in TOPICS for x in p['topics']) or p['confirmed'] is not True or not p['roleFacts'].strip():raise ProfileError('请填写真实账号事实并明确确认，主题只能使用公开租房需求')
    value={**p,'configured':True,'verification':'user_confirmed_not_independently_verified','accountIdentity':self.identity_binding(actual_account),'identityKnown':bool(actual_account.get('platform_uid'))};entity,kind=PROFILES,'profile'
   else:
    subject=data.get('customerId');w,uid=self.customer(user,scope,subject)
    if action=='reply_evidence_save':
     items=data.get('items')
     if not isinstance(items,list) or len(items)>20:raise ProfileError('公开原文最多20条')
     value={'items':[]}
     for item in items:
      if not isinstance(item,dict) or set(item)!={'sourceUrl','observedAt','quote','subjectId'} or item['subjectId']!=uid or not isinstance(item['quote'],str) or not item['quote'].strip() or len(item['quote'])>4000:raise ProfileError('请保留客户稳定身份、公开来源与原文')
      try:
       url=urlsplit(item['sourceUrl']);stamp=datetime.fromisoformat(item['observedAt'].replace('Z','+00:00'))
       host='xiaohongshu.com' if scope[4]=='xiaohongshu' else 'douyin.com'
       if scope[4]=='xiaohongshu' and url.path.startswith('/user/profile/') and url.path.rstrip('/').rsplit('/',1)[-1]!=uid:raise ValueError()
       if scope[4]=='douyin' and url.path.startswith('/user/') and url.path.rstrip('/').rsplit('/',1)[-1]!=uid:raise ValueError()
       if url.scheme!='https' or url.username or url.password or not (url.hostname==host or url.hostname=='www.'+host) or not url.path.startswith(('/user/','/explore/','/video/')) or stamp.tzinfo is None:raise ValueError()
      except (ValueError,TypeError,AttributeError):raise ProfileError('请填写对应平台公开主页/作品HTTPS链接和含时区的记录时间')
      value['items'].append({**item,'source':'manual','verified':False,'notice':'本人提供，未自动核验'})
     entity,kind=EVIDENCE,'evidence'
    else:
     aid=data.get('accountId');e=self.evidence(scope,subject)
     a=self.account(user,scope,aid) if aid else {'id':''};p=self.profile(scope,aid) if aid else {'revision':0,'configured':True,'confirmed':True}
     if aid and p.get('accountIdentity')!=self.identity_binding(a):raise ProfileError('实际账号身份已变化，请重新确认账号资料')
     if not p['configured'] or not p['confirmed'] or p['revision']!=data.get('expectedProfileRevision') or e['revision']!=data.get('expectedEvidenceRevision'):raise ProfileError('账号资料或公开原文已变化，请重新预览后选择')
     value={'accountId':a['id'],'profileRevision':p['revision'],'evidenceRevision':e['revision'],'subjectId':uid};entity,kind=ASSIGNMENTS,'assignment'
   def validate():
    current_user,current_scope=self.scope(token,data)
    if current_scope!=scope or any(current_user.get(k)!=user.get(k) for k in ('id','tenant_id','username')):raise ProfileError('员工或门店权限已变化，请重新读取')
    if action=='reply_account_profile_save':
     current_account=self.account(user,scope,subject)
     if self.identity_binding(current_account)!=value['accountIdentity']:raise ProfileError('账号身份已变化，请重新读取')
    else:
     _,current_uid=self.customer(user,scope,subject)
     if current_uid!=uid:raise ProfileError('客户稳定身份已变化，请重新读取原文')
    if action=='reply_assignment_save':
     current=self.profile(scope,data['accountId']) if data['accountId'] else {'revision':0}
     if data['accountId'] and current.get('accountIdentity')!=self.identity_binding(self.account(user,scope,data['accountId'])):raise ProfileError('账号身份已变化，请重新确认')
     ev=self.evidence(scope,subject)
     if current['revision']!=data['expectedProfileRevision'] or ev['revision']!=data['expectedEvidenceRevision']:raise ProfileError('账号资料或原文已变化，请重新读取')
   receipt=self.mutate(action,data,user,scope,entity,kind,subject,value,validate)
   result={'accounts':self.accounts(user,scope),'customers':[],'topics':list(TOPICS)}
   if action!='reply_account_profile_save':result['customers']=[self.customer_view(user,scope,subject)]
   return {'replyAccounts':result,'mutationReceipt':receipt}
 def capture(self,user,workflow_scope,customer_id):
  s=[workflow_scope[0],workflow_scope[1],user['username'],workflow_scope[2],workflow_scope[4]];aid=workflow_scope[3]
  p=self.profile(s,aid)
  if not p['configured']:return None
  a=self.account(user,s,aid)
  if p.get('accountIdentity')!=self.identity_binding(a):raise ProfileError('实际账号身份已变化，请重新确认资料后选择账号')
  w,uid=self.customer(user,s,customer_id);assignment=self.assignment(s,customer_id);evidence=self.evidence(s,customer_id)
  if not p['confirmed'] or assignment.get('accountId')!=aid or assignment.get('profileRevision')!=p['revision'] or assignment.get('evidenceRevision')!=evidence['revision'] or assignment.get('subjectId')!=uid:raise ProfileError('请先核对资料并为该客户选择当前账号；旧草稿保留')
  return {'version':1,'accountId':aid,'accountUid':str(a.get('platform_uid') or ''),'accountBinding':digest({k:a.get(k) for k in ('id','tenant_id','cloud_owner','store_id','platform','platform_uid')}),'profile':p,'assignment':assignment,'evidence':evidence,'customerId':customer_id,'subjectId':uid}
 def check(self,user,scope,customer_id,snapshot):
  if snapshot is not None and self.capture(user,scope,customer_id)!=snapshot:raise ProfileError('账号资料、客户选择或公开原文已变化；请重新预览生成，原稿保留')
