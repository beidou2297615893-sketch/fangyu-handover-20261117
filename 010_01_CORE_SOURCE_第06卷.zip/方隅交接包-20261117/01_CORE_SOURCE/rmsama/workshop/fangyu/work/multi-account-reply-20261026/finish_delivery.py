"""Record the actually verified scoped feature and its explicit limits."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,shutil
T=Path(__file__).resolve().parent;P=T.parents[1]
read=lambda p:json.loads(p.read_text('utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,v):
 p.parent.mkdir(parents=True,exist_ok=True)
 with p.open('x',encoding='utf-8') as f:json.dump(v,f,ensure_ascii=False,indent=2);f.write('\n')
pins=read(T/'FROZEN-PINS.json');checks=read(T/'verification/integrated/RESULT.json')
real=read(T/'real-e2e/real-final/RESULT.json');ledger=read(T/'real-e2e/real-final/DISPATCH-LEDGER.json')
review=read(T/'review/NEXT-LAUNCH-REVIEW.json');entry=read(T/'NEXT-LAUNCH-ENTRY-CHECK.json')
assert checks['status']=='PASS' and len(checks['checks'])==29
assert real['status']=='PASS' and real['execAttempts']==ledger['execAttempts']==2
assert real['messagesSent']==real['platformCalls']==0 and not real['productionWrites'] and not real['productionDataRead']
assert len(real['cases'])==2 and {c['account'] for c in real['cases']}=={'A','B'}
assert review['approvedForNextLaunchUpdate'] and review['blockingFindings']==[]
assert entry['status']=='NEXT_LAUNCH_ENTRY_VERIFIED' and entry['allBusinessDataUnchanged'] and entry['currentInstanceUnchanged']
output=P/'outputs/多账号回复';output.mkdir(parents=True,exist_ok=True)
doc=output/'使用说明.md'
with doc.open('x',encoding='utf-8') as f:
 f.write((T/'USER-GUIDE-DRAFT.md').read_text('utf-8'))
 f.write('\n已接到原软件的下次启动入口，正常关闭并重新打开后使用。本次未操作平台窗口，现有客户数据与草稿保持不变。\n')
 f.write('\n验证已通过：账号推荐、手工分配、按组生成、不同账号口吻、单条重新生成、原编辑审核及失败恢复。两次真实模型样例使用全合成数据，只验证技术链路，不代表本人已认可示例语气。\n')
core=Path('C:/积木软件工坊/核心组件/work/multi-account-reply-20261026-candidate')
assert not core.exists();core.mkdir(parents=True)
archived={}
for rel in ('reply_account_profiles.py','web/pages/reply-account-routing.mjs'):
 src=T/'candidate'/rel;target=core/rel;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,target)
 assert sha(src)==sha(target);archived[rel]=sha(target)
write(core/'CANDIDATE.json',dict(status='GENERIC_SOURCE_CANDIDATE_ONLY',files=archived,customerDataIncluded=False,accountCredentialsIncluded=False,promoted=False,otherInstancesUpdated=False,requires='Original scoped customer/reply interfaces; not a standalone sender',evidence=str(T/'verification/integrated/RESULT.json')))
note=('\n\n## 2026-10-26 多账号定位与口吻分组回复\n'
 f"已沿fa72增量交付，下次启动 {pins['releaseId']}。账号真实事实/口吻/需求主题独立保存；已有评论与手工公开原文可解释推荐，每客户唯一指派，可暂缓/改选并按账号分组，复用原生成编辑审核。单条显式reopen保留旧版本；UID重绑、资料/证据/分配变化、旧入口及失败恢复均核对版本，准备队列边界也重验绑定。\n"
 '29组最终发布版隔离回归PASS；六合成账号、两次官方真实模型经原Workflow/receiver编辑保存确认PASS，0平台调用/发送。Astra审核完整8879闭包与回执；source-only更新及原入口check/self-test PASS，业务全快照与当前实例前后相同，无重启或生产写入。\n'
 '主页自动读取未接通，原文仅本人提供未自动核验；真实自动切号及发送未接通，默认人工切号；六个真人账号资料及本人语气认可待本人配置/校准。不能称平台全自动链已通过。旧legacy prompt/GUIDANCE/contract_digest保持；无自动批量覆盖现有草稿。\n'
 f'证据：{T.as_posix()}；人用说明 outputs/多账号回复/使用说明.md。通用薄层仅候选归档至核心组件/work，不推广其他实例。\n')
for path in (P/'memory/STATUS.md',Path('C:/积木软件工坊/项目/方隅公寓/memory/STATUS.md')):
 with path.open('a',encoding='utf-8') as f:f.write(note)
session=P/'memory/sessions/20261026-multi-account-reply.md'
with session.open('x',encoding='utf-8') as f:f.write(note)
result=dict(status='DELIVERED_GROUPED_REPLY_NEXT_LAUNCH',atUtc=datetime.now(timezone.utc).isoformat(),releaseId=pins['releaseId'],regressionGroups=29,syntheticOfficialModelCalls=2,platformCalls=0,messagesSent=0,businessDataUnchanged=True,currentInstanceUnchanged=True,userRestartRequired=True,automaticProfileFetchConnected=False,automaticAccountSwitchVerified=False,automaticSendingEnabled=False,userAccountProfilesConfigured=False,userToneAccepted=False,guide=str(doc),folder=str(output),genericCandidate=str(core),entryCheckSha256=sha(T/'NEXT-LAUNCH-ENTRY-CHECK.json'),reviewSha256=sha(T/'review/NEXT-LAUNCH-REVIEW.json'),realResultSha256=sha(T/'real-e2e/real-final/RESULT.json'))
write(T/'DELIVERY.json',result);print(json.dumps(result,ensure_ascii=False))
