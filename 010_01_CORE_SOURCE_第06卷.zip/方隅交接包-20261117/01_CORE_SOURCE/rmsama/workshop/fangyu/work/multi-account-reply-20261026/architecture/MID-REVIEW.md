# 中期关键审查（只读，Astra）

状态：实现仍在修正，本记录不是最终通过。冻结5actions，不另建路由或发送框架。本轮人工账号分组草稿；不验收实际whoami、自动切号或发送，原public_send_hold/portable不变。

## 已直接发实现agent的阻塞

1. 原reply_check只收敛mutation receipt，没有收敛新增ROUTING pending；Core已提交但ready绑定落盘失败会让稿永久不能再编辑/审核。须同request/旧稿基线精确恢复，不能误修别人操作。
2. 更新profile/evidence或重新指派后，原稿强绑定旧快照，save/review均被拒；Workflow同时skip已有稿，形成死路。已核定最小显式reopen：原reply_ai_start可选单条reopenDraft，冻结旧稿/旧binding，生成仍用原job；确认精准CAS新版本并保留旧历史，普通批量不碰已有稿。
3. 两个独立实例在相同旧稿基线上可能同时通过检查，routing_guard只查profile不查当前draft/reservation；需SQLite事务内CAS reservation、旧稿基线及ready回执，仅本request可收敛。
4. Profile仅按accountId保存，若同槽位重新绑定另一platform_uid，旧roleFacts可被静默套给新人。须保存身份摘要并在改变后明确要求重新确认。
5. 真正官方adapter GUIDANCE仍固定普通住户身份；仅改provider_prompt不足。现测试替换guidance漏测了生产条款。已核定guidance可选构造参数+薄型请求分派：原请求走完全相同legacy prompt/GUIDANCE，新请求走真实资料规则。
6. contract_digest包含prompt/guidance；统一换prompt会令旧持久回执无法查回。分派依据原executionRequest，legacy字段形状/字符串/digest保持逐字一致；不改原execute和unknown交叉目标锁。

附加问题：UI暂缓空账号与后端不匹配（双方已约定CAS清空）；推荐明确否定需求不应正向命中；主页自动读取直接标未接通；原文更正/删除应可用。

## 最终前的独立验证

- 真Core/Store/ReplyWorkbench路径：六合成账号、明确需求推荐B、只用B资料/样本生成、原编辑保存审核；platform sender/account_connect/CLI/Popen/network调用为0，未创建发送队列。
- 原receiver失效注入：分别在pending后、Core提交后、ready绑定后、receipt前失败；原check后结果明确，旧内容保留，不重复Core变更，后续明确操作可继续。
- 两个独立Store/backend/Core锁共享SQLite，通过barrier制造同版本并发；profile/evidence/assignment分别只能一成功；同requestId重放不多写，异payload同id拒绝；receiver新稿版本不重复，reservation不串。
- 跨账号/跨身份：客户别名同UID只有一个assignment；错subjectId、错平台/门店/员工权限拒绝；同accountId换UID后旧真实资料不能继续使用；身份未知不宣称已验证。
- 显式reopen：profile改、证据改、A改B后可逐条新生成；生成时旧replies逐字不变，确认后旧正文仍在历史；确认前另一窗口改稿则阻断。无reopen标志的批量继续跳过旧稿，legacy166稿全量hash不变。
- 防降级：多账号稿换原编辑器仍受账号绑定；手工编辑新版本继承绑定；原请求省字段不能绕过；重启后绑定仍能检查。
- 真实production prompt材料：不替换guidance，非住户profile无强加住户/主观居住经历，profile.tone正确传入；所有资料作为不可信输入；姓名/头像/IP/年龄/国籍不生成推荐信号；否定及并列需求保守处理。
- 历史兼容：fa72 provider contract_digest完全相等，旧executionRequest结构相同；旧validated/unknown/response_received回执existing_only离线恢复不调用runner；原23组回归。
- UI最终源码哈希绑定的DOM/headless检查：推荐与指派不同，采用/清空、原文新增/删除、分组加载、单条reopen、pending回执、scope变化晚到响应、窄窗口，明确主页读取/自动切号/发送未接通。

这些是代码和隔离验证，不等于实际平台验收、用户视觉认可或真实身份核验。
