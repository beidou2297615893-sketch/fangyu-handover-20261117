import {renderRouting,bindRouting} from './reply-account-routing.mjs';
import {customerAvatar,postCover} from '../avatar.mjs';
import {customerShortNeed} from './customers-data.mjs';
const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const stamp=s=>JSON.stringify([s.authEpoch,s.user,s.storeId,s.activePlatform]);
const block=(label,text)=>`<div style="padding:9px 12px;border-left:3px solid #b7d7d0;margin:8px 0;background:#f5faf8"><small>${esc(label)}</small><div style="white-space:pre-wrap;overflow-wrap:anywhere">${esc(text||'尚未采集')}</div></div>`;
export function renderContext(c){
 if(!c)return '<p>原上下文已变化或不在当前可见范围，请重新读取。</p>';
 const root=c.root||c.parent||{},direct=c.replyTo||{},same=direct.known&&direct.id&&direct.id===root.id;
 return `<section class="rp-comment-context" aria-label="评论上下文" style="padding:12px;border:1px solid #d4e4df;border-radius:10px;margin:10px 0"><strong>${esc(c.label)}</strong>${block('原帖子'+(c.post.author?' · '+c.post.author:''),c.post.title)}<details><summary>帖子正文</summary>${block('正文',c.post.text)}</details>${c.level===2?block('讨论起始评论'+(same?' · 客户直接回复此条':'')+(root.author?' · '+root.author:''),root.text):''}${c.level===2&&!same?(direct.known?block('对方回复的评论'+(direct.author?' · '+direct.author:''),direct.text):'<p role="status" class="rp-ai-unknown">对方回复了谁尚未核实。</p>'):''}${block('本次回复对象 · '+(c.target.author||'客户'),c.target.text)}${c.missing.length?`<p style="color:#906b25">待补上下文：${esc(c.missing.join('；'))}</p>`:''}<small>${esc(c.coverage)}</small></section>`;
}
function model(v){const a=v.ai ||= {};a.tone??='';a.job??=null;a.busy??=false;a.error??='';a.pending??=false;a.styleMode??='store';return a;}
const styleNames={store:'跟随本店',friendly:'自然友好',concise:'简洁直接',patient:'耐心解答'};
const focusNames={budget:'预算',moveIn:'入住时间',housing:'房源匹配'};
function styleDetails(saved,effective){if(!saved)return '<p>口吻资料尚未载入。</p>';return `<p><strong>${esc(effective?.label||saved.toneLabel||'本店口吻')}</strong> · ${esc(saved.identityRule||'按本人确认资料回复')}</p><p>称呼：${esc(saved.salutation||'不加称呼')} · 关注：${esc((saved.focus||[]).map(x=>focusNames[x]||x).join('、')||'按实际问题')}</p>${saved.customerTemplate?`<details><summary>SOP 措辞参考</summary><p style="white-space:pre-wrap;overflow-wrap:anywhere">${esc(saved.customerTemplate)}</p></details>`:'<p>SOP 措辞参考：未配置</p>'}`;}
function renderAccountProfile(p){return p?.configured?`<section aria-label="当前账号定位"><strong>${esc(p.displayName||'本人账号定位')}</strong><p>身份与事实：${esc(p.roleFacts)}</p><p>说话口吻：${esc(p.tone)}</p><small>本人确认提供的资料；未进行平台身份或居住经历核验。</small></section>`:'';}
function renderStyle(a){const info=a.styleInfo,saved=info?.savedTone,mode=a.styleMode,effective=mode==='store'?{mode,resolvedTone:saved?.tone,label:saved?.toneLabel,storeToneRevision:saved?.revision}:{mode,label:info?.styleModes?.find(x=>x.id===mode)?.label||styleNames[mode]};return `<label><span>本批口吻</span><div class="rp-ai-select-wrap"><select data-ai-style-mode ${a.busy||a.job?.state==='running'||a.startPending?'disabled':''}>${Object.entries(styleNames).map(([id,label])=>`<option value="${id}" ${mode===id?'selected':''}>${label}</option>`).join('')}</select></div></label><section data-ai-style-preview aria-label="本批口吻预览" role="status">${renderAccountProfile(info?.accountProfile)}${a.styleReading?'<p>正在读取本店口吻…</p>':a.styleError?`<p>${esc(a.styleError)}</p>`:styleDetails(saved,effective)}<button type="button" data-ai-style-refresh ${!a.accountId||a.styleReading||a.busy?'disabled':''}>刷新口吻</button></section>`;}
function renderBatchStyle(j){if(!j)return '';const snapshot=j.styleSnapshot;return `<section data-ai-batch-style aria-label="此批实际使用的口吻"><h3>此批实际使用的口吻</h3>${renderAccountProfile(j.rows?.find(r=>r.routingSnapshot?.profile)?.routingSnapshot?.profile)}${snapshot?styleDetails(snapshot.savedTone,snapshot.effectiveStyle||j.effectiveStyle):'<p>旧批次未记录口吻快照，原草稿保留。</p>'}${snapshot?.additionalTone?`<p>补充要求：${esc(snapshot.additionalTone)}</p>`:''}</section>`;}
function renderCompactContext(c,person){
 if(!c)return '<p class="rp-ai-unknown" role="status">原上下文已变化，请重新读取。</p>';
 const root=c.root||c.parent||{},direct=c.replyTo||{},same=direct.known&&direct.id&&direct.id===root.id;
 const line=(label,author,text)=>`<div class="rp-ai-context-line"><img class="rp-ai-context-avatar" src="/assets/approved-icon-user-round.svg" alt=""><small>${esc(label)}${author?' · '+esc(author):''}</small><span>${esc(text||'尚未采集')}</span></div>`;
 return `<div class="rp-ai-context-slots"><div class="rp-ai-post-reference">${postCover(person,'rp-ai-post-cover')}<div><strong>${esc(c.post.title||'帖子标题待核实')}</strong><p>${esc(person.postDescription||person.postSummary||'帖子说明待补充')}</p></div></div>${c.level===2?`${!same?line('讨论起始评论',root.author,root.text):''}${direct.known?line('上级评论',direct.author,direct.text):'<p class="rp-ai-unknown" role="status">对方回复了谁尚未核实。</p>'}`:''}<div class="rp-ai-target-reference">${customerAvatar({name:c.target.author||person.name,avatarUrl:person.avatarUrl},'rp-ai-target-avatar')}<strong>${esc(c.target.author||person.name)}</strong><span>${esc(c.target.text)}</span></div>${c.missing?.length?`<p class="rp-ai-unknown">待补上下文：${esc(c.missing.join('；'))}</p>`:''}</div>`;
}
function renderAIRow(r,i,a,lock,v){
 const key=r.leadId||String(i),open=a.openRows?a.openRows.includes(key):i===0;
 const person=r.context&&r.status!=='error'?(v.items.find(p=>p.id===r.customerId)||{}):{},publishedAt=r.context?.target?.publishedAt||'',status=r.confirmation?.state==='confirmed'?'已确认 · 未发送':r.confirmation?.state==='closed'?'确认已关闭':r.confirmation?.pending?'确认进度待核对':r.confirmation?.state==='not_started'&&r.confirmation?.message?'待确认':r.status==='pending'?'分析中':r.status==='error'?'未完成':publishedAt&&!Number.isNaN(new Date(publishedAt).getTime())?new Date(publishedAt).toLocaleTimeString('zh-CN',{hour:'2-digit',minute:'2-digit'}):'';
 return `<details class="rp-ai-row" data-ai-row-panel="${i}" ${open?'open':''}><summary><input type="checkbox" data-ai-pick="${i}" aria-label="选择${esc(r.name)}" ${r.selected?'checked':''} ${lock||r.status!=='ready'?'disabled':''}>${customerAvatar({...person,name:r.name},'rp-ai-customer-avatar')}<span class="rp-ai-customer-title"><strong>${esc(r.name)}</strong><small>${esc(customerShortNeed(person)||'需求待了解')}</small></span><span class="rp-ai-customer-state">${esc(status)}</span><img class="rp-ai-fold-icon" src="/assets/tabler-chevron-down.svg" alt=""></summary><div class="rp-ai-row-body">${renderCompactContext(r.context,{...person,name:r.name})}${r.error?`<p role="alert">${esc(r.error)}</p>`:''}${r.confirmation?.message||r.confirmation?.pending?`<p class="rp-ai-row-recovery" role="status">${esc(r.confirmation.message||'上次确认结果待核对。')}</p>`:''}<label class="rp-ai-draft-label"><span>回复草稿</span><div><textarea rows="3" data-ai-text="${i}" maxlength="1000" aria-label="${esc(r.name)}的回复草稿" ${lock||r.status!=='ready'?'disabled':''}>${esc(r.text)}</textarea><small><span data-ai-text-count="${i}">${r.text.length}</span>/1000</small></div></label><details class="rp-ai-reason"><summary><img src="/assets/tabler-upgrade-file.svg" alt="">回复依据${r.analysis?.unknown?.length?`<small>待核实 ${r.analysis.unknown.length} 项</small>`:''}<img class="rp-ai-fold-icon" src="/assets/tabler-chevron-down.svg" alt=""></summary>${r.analysis?`<p><b>对话关系：</b>${esc(r.analysis.relationship)}</p><p><b>客户需求：</b>${esc(r.analysis.need)}</p><p><b>方隅匹配：</b>${esc(r.analysis.fit)}</p><p>${esc(r.analysis.reason)}</p>`:''}${r.analysis?.unknown?.length?`<p class="rp-ai-unknown">待核实：${esc(r.analysis.unknown.join('；'))}</p>`:''}${renderContext(r.context)}</details></div></details>`;
}
function reopenCandidate(v,a){
 const row=v.detail?.comments?.find(x=>x.id===v.leadId),assignment=v.accountRouting?.data?.routes?.find(x=>x.customerId===v.selectedId)?.assignment;
 if(v.dirty||v.detailLoading||v.detailSnapshot||v.readUnavailable||!row?.canSave||row.pendingRequestId||!row.draft||!['draft','approved'].includes(row.draft.status)||!a.styleInfo?.accountProfile?.configured||assignment?.accountId!==a.accountId)return null;
 return {customerId:v.selectedId,leadId:row.id,expectedReplyId:row.draft.id,expectedVersion:row.draft.version,sourceDigest:row.sourceDigest};
}
export function renderAI(s,v){
 const a=model(v),j=a.job,run=j?.state==='running',lock=a.busy||run,scopeLock=lock,reopen=reopenCandidate(v,a);
 if(a.openRowsJob!==j?.id){a.openRowsJob=j?.id;delete a.openRows;}
 const choices=v.accountRouting?.data?.accounts||v.detail?.comments?.find(x=>x.id===v.leadId)?.accounts||[];
 return `${renderRouting(s,v)}<details class="rp-ai-workflow" data-ai-panel ${a.open||run||a.error||j?.error?'open':''} aria-label="AI上下文回复工作流"><summary><img class="rp-ai-title-icon" src="/assets/reference-icon-sparkles.svg" alt=""><strong>AI 回复草稿</strong><img class="rp-ai-fold-icon" src="/assets/tabler-chevron-down.svg" alt=""></summary><div class="rp-ai-workflow-body rp-ai-grid"><div class="rp-ai-setup"><label><span>回复账号</span><div class="rp-ai-select-wrap"><img src="/assets/approved-icon-user-round.svg" alt=""><select data-ai-account ${scopeLock?'disabled':''}><option value="">请选择</option>${choices.map(x=>`<option value="${esc(x.id)}" ${x.id===a.accountId?'selected':''}>${esc(x.name)}</option>`).join('')}</select></div></label><label><span>回复范围</span><div class="rp-ai-select-wrap"><img src="/assets/reference-icon-target.svg" alt=""><select data-ai-range ${lock?'disabled':''}>${a.range==='group'?`<option value="group" selected>账号分组：${esc(a.groupName)}（${a.groupCustomerIds?.length||0}位）</option>`:''}<option value="current" ${a.range!=='list'&&a.range!=='group'?'selected':''}>当前客户</option><option value="list" ${a.range==='list'?'selected':''}>当前列表（${v.items.length}位）</option></select></div></label>${renderStyle(a)}<label class="rp-ai-tone-label"><span>补充要求</span><div><textarea data-ai-tone rows="5" maxlength="4000" placeholder="可补充本批回复要求，不改变真实身份与事实约束。" ${lock?'disabled':''}>${esc(a.tone)}</textarea><small><span data-ai-tone-count>${a.tone.length}</span>/4000</small></div></label><button class="rp-primary" data-ai-start ${lock||!a.accountId||!a.styleInfo||a.styleReading||a.styleError||a.startPending?'disabled':''}><img src="/assets/reference-icon-sparkles.svg" alt="">${run?'正在逐条分析…':'生成回复草稿'}</button><button data-ai-load ${lock||!a.accountId?'disabled':''}>加载上次草稿</button><button type="button" data-ai-regenerate ${lock||!reopen||!a.styleInfo||a.styleReading||a.styleError||a.startPending?'disabled':''}>按当前账号重新生成这一条</button><small>${reopen?'当前客户旧稿版本 '+esc(reopen.expectedVersion)+'；只重做这一条候选，需本人确认。':'如需重做旧稿，请先选中该客户旧稿，并保存当前账号的分配。'}</small>${run?'<button data-ai-stop>停止后续分析</button>':''}${j?`<small class="rp-ai-sample-count">语气参考：${esc(j.sampleCount??0)} 条已确认回复</small><p class="rp-ai-job-state" role="status">已处理 ${j.completed} / ${j.total} 条 · ${esc({running:'分析中',done:'待确认',stopped:'已停止',interrupted:'上次已中断'}[j.state]||j.state)}</p>`:''}${a.error||j?.error?`<p role="alert">${esc(a.error||j.error)}</p>`:''}</div><div class="rp-ai-results">${j?.rows?.length?`<div class="rp-ai-review-list">${renderBatchStyle(j)}${a.startPending?'<p role="status">上次生成结果待核对；请加载原批次，不会重复生成。</p>':''}${j.rows.map((r,i)=>renderAIRow(r,i,a,lock,v)).join('')}</div><div class="rp-ai-review-footer"><div class="rp-ai-review-actions"><button data-ai-save ${lock?'disabled':''}>保存修改</button><button class="rp-primary" data-ai-confirm ${lock||!j.rows.some(r=>r.selected&&r.status==='ready')?'disabled':''}>确认选中草稿</button></div><div class="rp-ai-platforms"><span>发送平台</span>${[['xiaohongshu','小红书'],['douyin','抖音']].map(([id,name])=>`<button type="button" data-ai-platform="${id}" aria-pressed="${(s.activePlatform||'xiaohongshu')===id}" ${s.busy?'disabled':''}><img src="/assets/brand-${id}.svg" alt="">${name}</button>`).join('')}</div><p class="rp-ai-send-note">自动发送已关闭</p><div class="rp-ai-confirm-progress">${j.confirmationCounts?`<span role="status">已确认 <b data-ai-confirmed-count>${j.confirmationCounts.confirmed}</b> 条 · 待核对 ${j.confirmationCounts.pending} 条 · 未开始 ${j.confirmationCounts.notStarted} 条</span>`:''}<button data-ai-reconcile ${lock?'disabled':''}>核对确认进度</button></div></div>`:`<div class="rp-ai-empty">${renderBatchStyle(j)}${a.startPending?'<p role="status">上次生成结果待核对；请加载原批次，不会重复生成。</p>':''}<strong>回复草稿会显示在这里</strong><p>选择账号和范围后生成。</p></div>`}</div></div></details>`;
}

export function bindAI(root,ctx,v){
 const s=ctx.state,a=model(v),origin=stamp(s),accountAtBind=a.accountId,owns=()=>s.replyLive===v&&stamp(s)===origin&&a.accountId===accountAtBind;
 bindRouting(root,ctx,v,{loadGroup:group=>{if(a.busy||a.job?.state==='running'||a.startPending)return;a.groupJobs??={};if(a.job&&a.accountId)a.groupJobs[a.accountId]=a.job;a.accountId=group.accountId;a.job=a.groupJobs[group.accountId]||null;a.groupCustomerIds=[...group.customerIds];a.groupName=group.accountName;a.range='group';a.styleInfo=null;a.styleReading=false;a.styleError='';a.styleReadAccount='';a.error='';ctx.update(()=>{});}});
 root.querySelectorAll('[data-ai-platform]').forEach(el=>el.addEventListener('click',()=>ctx.switchPlatform(el.dataset.aiPlatform)));
 const panel=root.querySelector('[data-ai-panel]');panel?.addEventListener('toggle',()=>{a.open=panel.open;});
 root.querySelectorAll('[data-ai-row-panel]').forEach(node=>node.addEventListener('toggle',()=>{const i=Number(node.dataset.aiRowPanel),key=a.job?.rows?.[i]?.leadId||String(i);a.openRows??=[...root.querySelectorAll('[data-ai-row-panel][open]')].map(n=>a.job?.rows?.[Number(n.dataset.aiRowPanel)]?.leadId||String(n.dataset.aiRowPanel));a.openRows=a.openRows.filter(x=>x!==key);if(node.open)a.openRows.push(key);}));
 const refresh=()=>{if(owns())ctx.update(()=>{});};
 const params=()=>({storeId:s.storeId,platform:s.activePlatform||'xiaohongshu',accountId:a.accountId});
 const call=(action,data={})=>ctx.replyAI(action,{...params(),...data});
 const fail=e=>{if(owns()){a.error=e.message;refresh();}};
 async function readStyle(){if(!a.accountId||a.styleReading)return;const account=a.accountId;a.styleReading=true;a.styleError='';refresh();try{const result=await call('reply_ai_read');if(!owns()||a.accountId!==account)return;const info=result.replyAI;if(!Number.isSafeInteger(info?.savedTone?.revision)||info.savedTone.revision<0||!Array.isArray(info.styleModes))throw Error('本店口吻资料尚未核对，请刷新。');a.styleInfo={savedTone:info.savedTone,effectiveStyle:info.effectiveStyle,styleModes:info.styleModes,accountProfile:info.accountProfile};}catch(e){if(owns()){a.styleError=e.message;}}finally{if(owns()){a.styleReading=false;refresh();}}}
 root.querySelector('[data-ai-style-refresh]')?.addEventListener('click',readStyle);
 root.querySelector('[data-ai-style-mode]')?.addEventListener('change',e=>{if(!a.startPending&&Object.hasOwn(styleNames,e.target.value)){a.styleMode=e.target.value;refresh();}});

 root.querySelector('[data-ai-account]')?.addEventListener('change',e=>{if(a.job&&a.accountId){a.groupJobs??={};a.groupJobs[a.accountId]=a.job;}a.accountId=e.target.value;a.job=a.groupJobs?.[a.accountId]||null;a.groupCustomerIds=null;a.groupName='';if(a.range==='group')a.range='current';a.startPending=null;a.error='';a.styleInfo=null;a.styleReading=false;a.styleError='';a.styleReadAccount='';ctx.update(()=>{});});
 root.querySelector('[data-ai-range]')?.addEventListener('change',e=>{a.range=e.target.value;});
 root.querySelector('[data-ai-tone]')?.addEventListener('input',e=>{a.tone=e.target.value;const counter=root.querySelector('[data-ai-tone-count]');if(counter)counter.textContent=a.tone.length;});
 root.querySelectorAll('[data-ai-text]').forEach(el=>el.addEventListener('input',()=>{const row=a.job.rows[+el.dataset.aiText];row.text=el.value;const counter=root.querySelector(`[data-ai-text-count="${el.dataset.aiText}"]`);if(counter)counter.textContent=el.value.length;if(row.confirmation?.state==='confirmed'){row.confirmation={state:'not_started',pending:false,message:'文字已修改，请重新确认'};if(a.job.confirmationCounts){a.job.confirmationCounts.confirmed=Math.max(0,a.job.confirmationCounts.confirmed-1);const count=root.querySelector('[data-ai-confirmed-count]');if(count)count.textContent=a.job.confirmationCounts.confirmed;}const label=el.closest('[data-ai-row-panel]')?.querySelector('.rp-ai-customer-state');if(label)label.textContent='待重新确认';}}));
 root.querySelectorAll('[data-ai-pick]').forEach(el=>el.addEventListener('change',()=>{a.job.rows[+el.dataset.aiPick].selected=el.checked;refresh();}));
 async function guarded(fn){if(a.busy)return;a.busy=true;a.error='';refresh();try{await fn();}catch(e){fail(e);}finally{if(owns()){a.busy=false;refresh();}}}
 root.querySelector('[data-ai-load]')?.addEventListener('click',()=>guarded(async()=>{const result=await call('reply_ai_read');if(!owns())return;a.job=result.replyAI.job;if(a.job?.requestId===a.startPending?.requestId)a.startPending=null;}));
 root.querySelector('[data-ai-start]')?.addEventListener('click',()=>guarded(async()=>{
   if(v.dirty)throw Error('请先保存当前手写草稿。');
   const ids=a.range==='group'?[...(a.groupCustomerIds||[])]:a.range==='list'?v.items.map(x=>x.id):[v.selectedId];
   if(!ids.length||ids.some(x=>!x))throw Error('请先选客户。');
   if(!a.styleInfo||a.styleReading||a.styleError)throw Error('请先载入并核对本店口吻。');
   a.startPending ||= {customerIds:[...new Set(ids)],tone:a.tone,styleMode:a.styleMode,expectedToneRevision:a.styleInfo.savedTone.revision,requestId:crypto.randomUUID()};
   try{const result=await call('reply_ai_start',a.startPending);if(owns()){a.job=result.replyAI;a.startPending=null;}}catch(e){if(owns()&&(e.mutationCommitted===false||['REPLY_TONE_REVISION_CONFLICT','REPLY_AI_NOT_CREATED'].includes(e.code))){a.startPending=null;if(e.code==='REPLY_TONE_REVISION_CONFLICT'){a.styleInfo=null;await readStyle();}}throw e;}
 }));
 root.querySelector('[data-ai-regenerate]')?.addEventListener('click',()=>{
   const original=reopenCandidate(v,a);if(!owns()||a.busy||a.job?.state==='running'||a.startPending||!original||!a.styleInfo||a.styleReading||a.styleError)return;
   const accountId=a.accountId,expected=JSON.stringify(original);
   ctx.modal({title:'重新生成当前客户这一条',html:`<p>将按当前已分配账号重新生成这一条回复候选。保留旧版本；新稿需重新审核，不发送。</p><p>客户：${esc(v.detail?.item?.name||v.items.find(x=>x.id===original.customerId)?.name||'当前客户')} · 原稿版本 ${esc(original.expectedVersion)}</p><p>这里只生成候选；本人确认新文字时才会保存新的回复版本。</p>`,confirmLabel:'保留旧版本，生成新候选',onConfirm:async()=>{
     if(!owns()||a.accountId!==accountId||a.busy||a.startPending||JSON.stringify(reopenCandidate(v,a))!==expected)return false;
     await guarded(async()=>{
       if(!a.styleInfo||a.styleReading||a.styleError)throw Error('请先刷新当前口吻。');
       a.startPending={customerIds:[original.customerId],tone:a.tone,styleMode:a.styleMode,expectedToneRevision:a.styleInfo.savedTone.revision,requestId:crypto.randomUUID(),reopenDraft:original};
       try{const result=await call('reply_ai_start',a.startPending);if(owns()){a.job=result.replyAI;a.startPending=null;}}catch(e){if(owns()&&(e.mutationCommitted===false||['REPLY_TONE_REVISION_CONFLICT','REPLY_AI_NOT_CREATED'].includes(e.code))){a.startPending=null;if(e.code==='REPLY_TONE_REVISION_CONFLICT'){a.styleInfo=null;await readStyle();}}throw e;}
     });return !a.error;
   }});
 });
 root.querySelector('[data-ai-stop]')?.addEventListener('click',()=>guarded(async()=>{const result=await call('reply_ai_cancel',{jobId:a.job.id});if(owns())a.job=result.replyAI;}));
 async function save(){
   for(const row of a.job.rows){row.text=row.text.trim();if(row.text.length>1000)throw Error('每条回复最多1000字，请缩短后保存。');}
   const result=await call('reply_ai_edit',{jobId:a.job.id,revision:a.job.revision,edits:a.job.rows.map(r=>({leadId:r.leadId,text:r.text,selected:r.selected}))});
   if(!owns())throw Error('当前账号已变化');a.job=result.replyAI;
 }
 root.querySelector('[data-ai-reconcile]')?.addEventListener('click',()=>guarded(async()=>{const result=await call('reply_ai_reconcile',{jobId:a.job.id});if(owns())a.job=result.replyAI;}));
 root.querySelector('[data-ai-save]')?.addEventListener('click',()=>guarded(save));
 root.querySelector('[data-ai-confirm]')?.addEventListener('click',()=>{
   if(a.busy||a.job?.state==='running')return;
   const batchId=a.job.id,accountId=a.accountId;
   const rows=a.job.rows.filter(r=>r.selected&&r.status==='ready');
   if(!rows.length||rows.some(r=>!r.text.trim())){fail(Error('选中的回复不能留空。'));return;}
   ctx.modal({title:`统一确认 ${rows.length} 条回复`,html:'<p>将保存当前文字、标记为本人已核对，并收录为当前账号语气参考。不会发送。确认后如修改正文，须重新核对。</p>',confirmLabel:'确认这些文字，不发送',onConfirm:async()=>{
     if(!owns()||a.busy||a.job?.id!==batchId||a.accountId!==accountId)return false;a.busy=true;a.error='';refresh();
     try{
       await save();
       const plan=rows.map(item=>{const current=a.job.rows.find(r=>r.leadId===item.leadId);if(!current||current.text!==item.text||!current.confirmationKey)throw Error('本批文字或来源已变化，请重新核对');return {leadId:current.leadId,name:current.name,confirmationKey:current.confirmationKey};});
       for(const item of plan){
         if(!owns()||a.accountId!==accountId||a.job.id!==batchId)return false;
         const result=await call('reply_ai_confirm',{jobId:batchId,leadId:item.leadId,confirmationKey:item.confirmationKey,confirmed:true});
         if(!owns())return false;a.job=result.replyAI;
         const checked=a.job.rows.find(r=>r.leadId===item.leadId);
         if(checked?.confirmation?.state!=='confirmed')throw Error(item.name+' 的确认结果待核对，后续已停止；请点击核对确认进度。');
       }
       ctx.toast('选中回复已确认，尚未发送。');return true;
     }catch(e){fail(e);return false;}finally{if(owns()){a.busy=false;refresh();}}
   }});
 });
 if(root.querySelector('[data-ai-panel]')&&a.accountId&&a.styleReadAccount!==a.accountId){a.styleReadAccount=a.accountId;queueMicrotask(()=>{if(owns())readStyle();});}
 if(a.job?.state==='running'&&!a.polling){
   a.polling=true;setTimeout(async()=>{try{if(!owns()||s.page!=='reply')return;const id=a.job.id,result=await call('reply_ai_status',{jobId:id});if(owns()&&a.job.id===id)a.job=result.replyAI;}catch(e){fail(e);}finally{a.polling=false;refresh();}},2000);
 }
}
