"""Relocate prior isolated regression fixtures, retaining their assertions."""
from pathlib import Path
import hashlib,json,shutil
T=Path(__file__).resolve().parent;B=T.parent/'reply-complete-20261026'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
pins={}
for sub in ('tests','backend/tests','frontend/tests'):
    target=T/sub;target.mkdir(parents=True,exist_ok=True)
    for p in (B/sub).iterdir():
        if not p.is_file() or p.suffix not in ('.py','.mjs','.cjs','.json'):continue
        body=p.read_text('utf-8-sig')
        if p.name=='test_complete_context.py':
            body=body.replace("str(W/'candidate')","str(W/'assembly/project/work/ui-native-r57')")
        if p.name=='test_complete_write_guard.py':
            body=body.replace("W/'candidate/core/store.py'","W/'assembly/project/work/ui-runtime-r55/src/core/store.py'")
        if p.name=='test_complete_concurrency.py':
            body=body.replace("W/'real-e2e/harness.py'","W.parent/'reply-complete-20261026/real-e2e/harness.py'")
        out=target/p.name
        assert not out.exists(),str(out)
        out.write_text(body,'utf-8');pins[str(p)]=sha(p)
for sub in ('evidence','shared','verification'): (T/sub).mkdir(exist_ok=True)
(T/'REGRESSION-SOURCE-PINS.json').write_text(json.dumps(pins,indent=2),'utf-8')
print(json.dumps(dict(prepared=len(pins),originalAssertionsRetained=True)))
