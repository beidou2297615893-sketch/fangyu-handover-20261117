"""Exact installed graph copy, minimal overlay and inactive freeze; no business writes."""
from pathlib import Path
from contextlib import redirect_stdout
import hashlib, importlib.util, io, json, shutil, sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent
P=W.parents[1]
BASE=P/'work/reply-complete-20261026'
PROJECT=W/'assembly/project'
read=lambda p:json.loads(p.read_text('utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,v):
    p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('x',encoding='utf-8') as f:json.dump(v,f,ensure_ascii=False,indent=2);f.write('\n')
def check_live():
    for n,h in read(W/'BASELINE.json')['canonical'].items():assert sha(P/'work/ui-native-r57'/n)==h,n
def prepare():
    assert not PROJECT.exists()
    live=read(W/'LIVE-BASELINE.json');frozen=read(P/'work/ui-native-r57/FROZEN.json')
    assert live['releaseId']==frozen['release_id']=='ui-r57-20261026T101643Z-fa72ab42'
    write(W/'BASELINE.json',dict(canonical=live['canonical'],productionChanged=False))
    check_live();source=BASE/'assembly/project'
    assert Path(frozen['runtime_project_root'])==source
    expected=dict(read(BASE/'assembly/BASE-COPY.complete.json')['files'])
    expected.update({n:r['after'] for n,r in read(BASE/'assembly/CHANGES.final.json')['files'].items()})
    closure={r['path']:r['sha256'] for r in read(BASE/'assembly/UNIFIED-PINS.json')['files']}
    for n,h in expected.items():
        assert Path(n).suffix.lower() not in ('.db','.sqlite','.sqlite3')
        assert closure[n]==h==sha(source/n),n
        target=PROJECT/n;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source/n,target)
        assert sha(target)==h,n
    write(W/'assembly/BASE-COPY.complete.json',dict(source=str(source),files=expected,status='EXACT_INSTALLED_PUBLIC_SOURCE_COPY'))
    for n in ('closed_update_guard.py','next_launch_update.py','prepare_regressions.py','review_source_closure.py','verify_next_launch_entry.py'):
        shutil.copyfile(BASE/n,W/n)
    check_live();print(json.dumps(dict(status='PREPARED',sourceFiles=len(expected))))
def freeze():
    assert not (W/'FROZEN-PINS.json').exists()
    check_live();copied=read(W/'assembly/BASE-COPY.complete.json')['files'];source=Path(read(W/'assembly/BASE-COPY.complete.json')['source'])
    assert {p.relative_to(PROJECT).as_posix() for p in PROJECT.rglob('*') if p.is_file()}==set(copied)
    for n,h in copied.items():assert sha(PROJECT/n)==h,n
    overlay={}
    for file in sorted((W/'candidate').rglob('*')):
        if not file.is_file() or '__pycache__' in file.parts:continue
        rel=file.relative_to(W/'candidate').as_posix()
        if rel.startswith('web/'):
            n='work/ui-approved-implementation/ui-preview/'+rel[4:];published=rel
        elif rel=='core/store.py':
            n='work/ui-runtime-r55/src/core/store.py';published=None
        else:
            assert '/' not in rel and file.suffix=='.py',rel
            n='work/ui-native-r57/'+rel;published=None if rel=='freeze_ui.py' else rel
        overlay[n]=(file,published,'workflow')
    if (W/'candidate/core/store.py').exists():
        overlay['work/app/src/core/store.py']=(W/'candidate/core/store.py',None,'workflow')
    changes={}
    for n,(file,published,owner) in overlay.items():
        before=copied.get(n);after=sha(file)
        if before==after:continue
        if before is not None:assert sha(source/n)==before
        target=PROJECT/n;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(file,target)
        changes[n]=dict(projectRelativePath=n,sourcePath=str(source/n),candidatePath=str(file),candidateSha256=after,sourceSha256=before,before=before,after=after,publishedRelativePath=published,owner=owner)
        if n=='work/ui-runtime-r55/src/core/store.py':changes[n]['backendDependencyRelativePath']='core/store.py'
        if n=='work/app/src/core/store.py':changes[n]['mirrorOf']='work/ui-runtime-r55/src/core/store.py'
    expected={**copied,**{n:r['after'] for n,r in changes.items()}}
    for n,h in expected.items():assert sha(PROJECT/n)==h,n
    write(W/'assembly/CHANGES.final.json',dict(files=changes,baselineFiles=len(copied),sourceFiles=len(expected),productionDataAccess=False))
    native=PROJECT/'work/ui-native-r57';sys.path.insert(0,str(native))
    spec=importlib.util.spec_from_file_location('complete_reply_freezer',native/'freeze_ui.py');builder=importlib.util.module_from_spec(spec);spec.loader.exec_module(builder)
    builder.VENV=P/'work/desktop-python'
    with redirect_stdout(io.StringIO()) as output:assert builder.main(['--stage'])==0
    stage=json.loads(output.getvalue());write(W/'assembly/STAGED.json',stage);release=Path(stage['release'])
    for n,r in changes.items():
        if r['publishedRelativePath'] is not None:assert sha(release/r['publishedRelativePath'])==r['after'],n
        elif n=='work/ui-runtime-r55/src/core/store.py':
            deps=read(release/'resources/backend-dependencies.json')
            assert next(row['sha256'].lower() for row in deps['files'] if row['path']=='core/store.py')==r['after']
    files=[dict(path=p.relative_to(PROJECT).as_posix(),bytes=p.stat().st_size,sha256=sha(p)) for p in sorted(PROJECT.rglob('*')) if p.is_file()]
    write(W/'assembly/UNIFIED-PINS.json',dict(schema='fangyu-inactive-customer-closure-v1',root='project',files=files,release=stage,production_data_access=False,promoted=False))
    pins=dict(status='STAGED_NOT_INSTALLED',project=str(PROJECT),release=str(release),releaseId=stage['release_id'],manifestSha256=sha(release/'RELEASE.json'),stagedSha256=sha(W/'assembly/STAGED.json'),launcherPath=stage['launcher'],launcherSha256=sha(Path(stage['launcher'])),unifiedPinsSha256=sha(W/'assembly/UNIFIED-PINS.json'),changesSha256=sha(W/'assembly/CHANGES.final.json'),installed=False,automaticSendingEnabled=False,productionWrites=0)
    write(W/'FROZEN-PINS.json',pins);check_live();print(json.dumps(dict(status=pins['status'],releaseId=pins['releaseId'],changedFiles=len(changes),sourceFiles=len(expected),closureFiles=len(files))))
if __name__=='__main__':{'prepare':prepare,'freeze':freeze}[sys.argv[1]]()
