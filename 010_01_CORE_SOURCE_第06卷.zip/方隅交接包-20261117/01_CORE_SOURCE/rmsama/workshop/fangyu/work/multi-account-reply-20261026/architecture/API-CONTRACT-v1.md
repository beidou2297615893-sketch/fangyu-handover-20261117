> 状态：本文是早期语义建议，不是实现接口命名依据。已采用任务根 CONTRACT.json 的5个接口：reply_accounts_read、reply_account_profile_save、reply_route_preview、reply_assignment_save、reply_evidence_save。不得按本文旧命名新增/替换路由。以下唯一指派、CAS、证据绑定、历史兼容与发送关闭语义仍供审查参考。
# 多账号回复最小接口契约 v1（Astra，2026-10-26）

## 本轮交付决定

正式wrapper没有user/user-posts能力，本轮不改CLI。完整交付范围是：账号真实资料设置、已有评论与手工公开正文证据、明确业务需求推荐、客户唯一账号指派、按账号分组、原Workflow口吻生成及原草稿审核。主页自动读取未接通；平台发送本轮不接通。sourceURL是来源引用，不代表软件已访问或核验该网页。

沿用现有backend身份/门店/客户detail_context/账号访问校验；全部字段camelCase，所有写接口拒绝未知字段。tenant/owner/actor不接受客户端指定。revision为非负整数，创建期望0；每次成功变更递增1。相同requestId+相同请求返回原回执，不重新递增；相同requestId不同内容拒绝。revision过期返回409及业务提示，不覆盖。

## 1. reply_routing_read

请求：{storeId, platform, customerIds?: string[]}
无customerIds读当前授权范围的轻量分组计数；有customerIds仅读这些已授权客户。最多300，拒绝重复。不要为此额外读取全量私有平台资料。

响应replyRouting：
{
 contract: "reply-routing.v1",
 capabilities: {profileAutoRead:false, manualEvidence:true, automaticAccountSwitch:false, platformSending:false},
 accounts: [{accountId, displayName, platform, profile:{revision, enabled, positioning, verifiedFacts, specialties, languages, styleMode, additionalTone, forbiddenClaims}}],
 customers: [{customerId, displayName, evidenceRevision, evidenceDigest,
   evidence:[{id, sourceType, sourceUrl, text, verification, needs:[{kind,value,quote}]}],
   assignment:{revision, accountId:null|string, profileRevision:null|number, evidenceRevision, evidenceDigest, updatedAt},
   recommendation:{state:"recommended"|"choose_manually"|"insufficient_evidence", recommendedAccountId:null|string, candidates:[{accountId,reasons:[{needKind,evidenceId,quote,matchedSpecialty}]}], gaps:string[]}}],
 groups:[{accountId:null|string, customerIds:string[], count:number}]
}

profiles仅返回当前授权且当前门店/平台账号；displayName仅展示。group accountId=null代表未指派。recommendation为实时只读计算，无账号权限或已停用者绝不列入候选。推荐无证据或并列不虚构最优及置信百分比。响应不带cookie、HOME、本机路径或平台凭据。

## 2. reply_account_profile_save

请求：{storeId, platform, accountId, expectedRevision, requestId,
 profile:{enabled:boolean, positioning:string, verifiedFacts:string[], specialties:string[], languages:string[], styleMode:string, additionalTone:string, forbiddenClaims:string[]}}

响应：{accountProfile:{accountId,revision,...profile}}

账号必须已有、本人可管理、门店与平台匹配。styleMode沿现有已支持枚举，不新造模型风格体系；缺省读值store。enabled缺省false，新资料不冒称已配置。positioning/verifiedFacts由用户提供，不能程序填充住户/外籍经历。specialties仅支持pet/commute/budget/layout/move_in/language六项；语言能力是账号真实服务能力，由用户设置，不推断国籍。

## 3. reply_customer_evidence_save

请求：{storeId, platform, customerId, expectedEvidenceRevision, requestId,
 evidence:[{id?:string, sourceUrl:string, text:string, needs:[{kind:string,value:string,quote:string}]}]}

响应：{customerEvidence:{customerId,evidenceRevision,evidenceDigest,evidence:[...]}}

此接口仅替换该客户的手工证据集合，已有评论只读证据由服务器从原detail_context取出，不接受客户端改写。sourceType固定manual_public_text；verification固定user_provided。必须sourceUrl和非空text，URL仅允许https/http的合法平台公开链接；只保存引用，不联网、不fetch。quote必须是该条text的连续原文，kind必须业务白名单。字段value不能引入quote没有支持的身份/需求；首版宁可仅使用quote执行匹配。

对象绑定由服务器取当前客户既有平台身份/稳定person key并保存，不接受客户端authorId覆盖。绑定不确定则标需核对，不自动关联同昵称客户。新证据不会自动改变assignment.accountId；标旧推荐依据已变化，重新指派/确认才采用。

所有原文为不可信资料。姓名/头像/IP/年龄/国籍/族群/宗教等不进入需求匹配及推荐输入；正文含这些内容也不生成对应needs。原评论需要同一白名单提取。语言仅接受明确沟通语言偏好，禁止从姓名或国籍猜测。

## 4. reply_customer_assign

请求：{storeId, platform, customerId, accountId:null|string, expectedAssignmentRevision, expectedEvidenceRevision, expectedAccountProfileRevision:null|number, requestId}

响应：{customerAssignment:{customerId,revision,accountId,profileRevision,evidenceRevision,evidenceDigest,updatedAt}}

唯一记录键=服务端tenant+store+platform+canonicalCustomerKey；不得包含accountId或actorId导致同一客户出现两个当前指派。actor仅审计/权限字段。确认账号必须当前授权；清空时accountId及expectedAccountProfileRevision均null。普通指定账号需profileRevision精确匹配；允许用户手工选择资料不全账号，但必须明确标资料不足，生成使用中性表达，禁止补身份事实。

assignment/evidence/profile版本检查与指派写入须同一锁/数据库事务。两个并发改派最多一个成功。一次改派只更新当前指派记录，不改replies正文、review_account_id、approval_snapshot、旧job、旧receipts。新的当前指派与旧稿不同则原稿保留、展示“原稿属于另一账号，请重新核对”。不能再把旧稿重新归属给当前账号。

## 5. 原 reply_ai_start 的增量（不另建模型调用）

现有参数保留；多账号分组入口新增可选字段routingContext：
{accountProfileRevision:number, customers:[{customerId,assignmentRevision,evidenceRevision}]}

routingContext出现时：必须完整覆盖本批customerIds且无重复；每个客户当前assigned account与请求accountId一致；全部版本当前。服务器固定profile/assignment/白名单needs与原证据摘要进入job快照、requestFingerprint和执行上下文摘要。客户端不能直接提交profile正文或已提取“系统指令”。按账号组逐一调用原Workflow，每批仍一个账号。

确认/接收生成结果复核该快照；profile/assignment/evidence变更则拒绝自动确认，旧文本保留供查看。原无routingContext单账号历史流程不变；但通过新分组入口生成的稿不得去掉routingContext降级绕过检查。生成job上固定routingRequired=true，后续操作以job为准。

新profile缺省不等于真实住户；仅新批次按用户verifiedFacts生成，旧styleSnapshot不改。账号B的样本只能由现有scope读B；禁止混用其他账号历史样本。

## 最小交互与验收

账号设置→客户详情已有评论/粘贴公开正文→显示原文与来源（手工提供）→给推荐及理由→用户采用或改选→账号任务组→生成→原编辑保存/审核。

显式文案：“主页自动读取尚未接通，可粘贴公开正文作为参考。”“手工提供，未自动核验来源。”本轮不提供新增发送按钮，也不承诺自动切号。UI显示账号分组不代表平台当前身份。

新增4个API动作足够。推荐和分组是read派生结果，不额外保存可漂移的推荐实体；不要构造第二套消息队列。原23组+多账号CAS/未知资料/来源绑定/跨scope/旧稿不动/固定B样本/敏感推断禁用隔离检查通过后可交付代码。真实自动主页读取、自动切号、平台发送保持未验且关闭。

