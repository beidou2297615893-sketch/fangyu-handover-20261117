"""Reuse existing regression orchestration plus new feature contracts."""
from pathlib import Path
T=Path(__file__).resolve().parent;B=T.parent/'reply-complete-20261026'
text=(B/'verify_integrated.py').read_text('utf-8')
text=text.replace("spec = TASK / owner / 'TEST-COMMANDS.json'", "spec = TASK.parent / 'reply-complete-20261026' / owner / 'TEST-COMMANDS.json'")
anchor="    jobs.extend([\n    ])"
assert text.count(anchor)==1
text=text.replace(anchor,"""    for owner in ('backend','frontend'):
        spec=TASK/owner/'NEW-TEST-COMMANDS.json'
        for job in read(spec)['jobs']:
            jobs.append((owner+'-new-'+job['name'],[arg.format(**values) for arg in job['argv']]))
    jobs.extend([
        ('complete-context', [py,'-X','utf8','-B',str(TASK/'tests/test_complete_context.py')]),
        ('complete-write-guard', [py,'-X','utf8','-B',str(TASK/'tests/test_complete_write_guard.py')]),
        ('complete-concurrency', [py,'-X','utf8','-B',str(TASK/'tests/test_complete_concurrency.py')]),
    ])""")
text=text.replace("provider_result=read(TASK/'provider/evidence/TEST-RESULTS.json')","PROVIDER=TASK.parent/'reply-complete-20261026/provider'\n    provider_result=read(PROVIDER/'evidence/TEST-RESULTS.json')")
text=text.replace("sha(TASK/'provider'/name)","sha(PROVIDER/name)")
text=text.replace("str(TASK/'provider/evidence/tests.log')","str(PROVIDER/'evidence/tests.log')").replace("sha(TASK/'provider/evidence/tests.log')","sha(PROVIDER/'evidence/tests.log')")
start=text.index("    workflow_path=TASK/'evidence/WORKFLOW-TEST-RESULTS.json'")
end=text.index("    order = {job[0]: i",start)
text=text[:start]+text[end:]
text=text.replace("    order['complete-workflow-11-hash-verified']=len(order)\n",'')
(T/'verify_integrated.py').write_text(text,'utf-8')
print('runner ready')
