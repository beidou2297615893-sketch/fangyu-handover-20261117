"""Copy the exact installed source graph, never running or changing business data."""
from pathlib import Path
import hashlib,json,shutil,sys
sys.dont_write_bytecode=True
T=Path(__file__).resolve().parent
P=T.parents[1]
B=P/'work/reply-complete-20261026'
read=lambda p:json.loads(p.read_text('utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,v):
    p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('x',encoding='utf-8') as f:json.dump(v,f,ensure_ascii=False,indent=2);f.write('\n')
frozen=read(P/'work/ui-native-r57/FROZEN.json')
assert frozen['release_id']=='ui-r57-20261026T101643Z-fa72ab42'
assert Path(frozen['runtime_project_root'])==B/'assembly/project'
canonical={n:sha(P/'work/ui-native-r57'/n) for n in ('run_workbench.py','FROZEN.json','state/production-workspace.json')}
write(T/'LIVE-BASELINE.json',dict(releaseId=frozen['release_id'],canonical=canonical))
code=(B/'prepare_build.py').read_text('utf-8')
code=code.replace("BASE=P/'work/reply-tone-integration-20261026-final'","BASE=P/'work/reply-complete-20261026'")
code=code.replace('ui-r57-20261026T082343Z-06a7dee0','ui-r57-20261026T101643Z-fa72ab42')
needle="    overlay['work/ui-native-r57/reply_official_codex.py']=(W/'provider/reply_official_codex.py','reply_official_codex.py','provider')\n"
assert code.count(needle)==1
code=code.replace(needle,'')
(T/'prepare_build.py').write_text(code,'utf-8')
for name in ('closed_update_guard.py','next_launch_update.py','review_source_closure.py','verify_next_launch_entry.py','prepare_regressions.py','test_served_closure.py','run_final_ui_contracts.py'):
    shutil.copyfile(B/name,T/name)
native=B/'assembly/project/work/ui-native-r57'
for name in ('ui_native_host.py','freeze_ui.py'):
    text=(native/name).read_text('utf-8')
    text=text.replace("'reply_ai_workflow.py'","'reply_account_profiles.py','reply_ai_workflow.py'")
    text=text.replace("'reply_ai_workflow')","'reply_account_profiles','reply_ai_workflow')")
    if name=='ui_native_host.py':
        needle="API_ACTIONS = API_ACTIONS | MEDIA_ACTIONS | frozenset("
        assert text.count(needle)==1
        pos=text.index('\n',text.index(needle))
        text=text[:pos]+"\nAPI_ACTIONS |= frozenset(('reply_accounts_read','reply_account_profile_save','reply_route_preview','reply_assignment_save','reply_evidence_save'))"+text[pos:]
    (T/'candidate'/name).write_text(text,'utf-8')
write(T/'PLAN.json',dict(baseline=frozen['release_id'],source=str(B/'assembly/project'),scope='existing comments + user-provided public text -> explainable routing -> one account/customer -> original per-account draft workflow',excluded=['automatic profile fetching','automatic account switch','real collection','platform sending','customer data migration'],steps=['exact source copy','profile and assignment CAS tests','frontend profile / routing / grouping','original draft workflow snapshot checks','retained regressions','Astra review','source-only next-launch update'],owners={'backend':['reply_account_profiles.py','reply_ai_workflow.py','reply_ai_provider.py','reply_workbench.py','workbench_backend.py'],'frontend':['web/'],'root':['ui_native_host.py','freeze_ui.py','assembly','verification','entry update'],'astra':['architecture','final risk review']}))
print(json.dumps(dict(status='READY',baseline=frozen['release_id'])))
