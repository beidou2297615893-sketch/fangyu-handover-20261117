"""Relocate existing isolated regressions without changing their assertions."""
from pathlib import Path
import hashlib
import json
import shutil

TASK = Path(__file__).resolve().parent
ROOT = TASK.parents[1]
OLD = ROOT / 'work/home-login-cleanup-20261026'
PREVIOUS = ROOT / 'work/verification-account-switch-20261026'
TONE_BASE = ROOT / 'work/reply-tone-integration-20261026-final'
tests = TASK / 'tests'
tests.mkdir(exist_ok=True)
(TASK / 'verification').mkdir(exist_ok=True)
pins = {}
for name in ('test_workflow.py', 'test_context_relations.py',
             'test_confirmation_recovery.py', 'test_ui.mjs', 'test_network_recovery.mjs'):
    source = (TONE_BASE if name in ('test_workflow.py', 'test_ui.mjs') else OLD) / 'tests' / name
    target = tests / name
    expected = source.read_bytes()
    if name == 'test_confirmation_recovery.py':
        # Retain the original recovery assertions; source proofs must be
        # obtained again after the fixture adds another same-person member.
        before = "        raw=self.f.store.get(ENTITY,self.job['id']);row2=deepcopy(raw['rows'][0]);row2.update(leadId='lead2',sourceDigest=digest(lead2),context=conversation(lead2),text='这边对宠物蛮友好的',attempts=[]);raw['rows'].append(row2);self.f.store.put(ENTITY,raw)"
        after = """        # Adding a same-customer member invalidates the old generation snapshot.
        # Obtain both rows through the real start boundary rather than copying
        # an old row while silently omitting its complete-history proof.
        self.args['requestId']='two-receipt-fixture'
        self.job=self.w.dispatch('reply_ai_start',self.args,'fixture-token')['replyAI']
        for _ in range(100):
            if self.job['id'] not in self.w.running:break
            time.sleep(.01)
        self.reload()
        self.assertEqual([row['status'] for row in self.job['rows']],['ready','ready'])"""
        text = expected.decode('utf-8')
        assert text.count(before) == 1
        expected = text.replace(before, after).encode('utf-8')
    if not target.exists():
        target.write_bytes(expected)
    if name == 'test_confirmation_recovery.py':
        assert target.read_text('utf-8') == expected.decode('utf-8').replace('\r\n', '\n'), name
    else:
        assert target.read_bytes() == expected, name
    pins[str(source)] = hashlib.sha256(source.read_bytes()).hexdigest()
for name in ('test_served_closure.py', 'run_final_ui_contracts.py'):
    source = PREVIOUS / name
    target = TASK / name
    if not target.exists():
        shutil.copyfile(source, target)
    assert target.read_bytes() == source.read_bytes(), name
    pins[str(source)] = hashlib.sha256(source.read_bytes()).hexdigest()
source = ROOT / 'work/verification-live-recovery-20261026/tests/test_verification_outcomes.py'
text = source.read_text('utf-8')
old_root = "ROOT=Path('C:/积木软件工坊/项目/方隅公寓客户版/work/home-login-cleanup-20261026/assembly/project')"
assert text.count(old_root) == 1
text = text.replace(old_root, 'ROOT=Path(__file__).resolve().parents[1]/\'assembly/project\'')
assert text.count("CANDIDATE=TASK/'candidate/project'") == 1
text = text.replace("CANDIDATE=TASK/'candidate/project'", "CANDIDATE=ROOT")
target = tests / source.name
if not target.exists():
    target.write_text(text, 'utf-8')
assert target.read_text('utf-8') == text
pins[str(source)] = hashlib.sha256(source.read_bytes()).hexdigest()
source = PREVIOUS / 'tests/test_next_launch_update.py'
target = tests / source.name
if not target.exists():
    shutil.copyfile(source, target)
assert source.read_bytes() == target.read_bytes()
pins[str(source)] = hashlib.sha256(source.read_bytes()).hexdigest()
target = TASK / 'REGRESSION-SOURCE-PINS.json'
if not target.exists():
    target.write_text(json.dumps(pins, ensure_ascii=False, indent=2)+'\n', 'utf-8')
assert json.loads(target.read_text('utf-8')) == pins
print(json.dumps({'copiedRegressionFiles': len(pins), 'assertionsChanged': False}))
