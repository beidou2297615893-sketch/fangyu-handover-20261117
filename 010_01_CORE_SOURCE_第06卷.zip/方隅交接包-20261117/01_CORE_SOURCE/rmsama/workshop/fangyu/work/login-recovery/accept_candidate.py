"""Accept the exact login candidate against the last accepted release."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
NATIVE = ROOT / 'work/ui-native-r57'
OLD = 'ui-r57-20261016T142520Z-848b1168'
NEW = 'ui-r57-20261016T165638Z-4fb95e1c'
allowed = {'workbench_backend.py', 'ui_native_host.py', 'web/app.mjs'}


def files(release):
    root = NATIVE / 'releases' / release
    manifest = json.loads((root / 'RELEASE.json').read_text('utf-8'))
    result = {}
    for row in manifest['files']:
        body = (root / row['path']).read_bytes()
        assert len(body) == row['size']
        assert hashlib.sha256(body).hexdigest().upper() == row['sha256'].upper()
        result[row['path']] = row['sha256']
    return result


old, new = files(OLD), files(NEW)
assert old.keys() == new.keys()
changed = {key for key in old if old[key] != new[key]}
assert changed == allowed, changed
visual = [key for key in new if key.startswith('web/') and
          (key.endswith('.css') or key in ('web/fit.mjs', 'web/canvas-fit.mjs'))]
assert len(visual) == 9
assert all(old[key] == new[key] for key in visual)
report = {'status': 'PASS', 'previous': OLD, 'candidate': NEW, 'files': len(new),
          'changed': sorted(changed), 'approved_visual_files_unchanged': visual,
          'targeted_tests': {'count': 52, 'status': 'PASS',
                             'log': 'work/login-recovery/targeted-tests.log'},
          'candidate_check': 'PASS', 'candidate_http_checks': 78,
          'javascript_syntax': 'PASS', 'readonly_review': 'PASS',
          'real_employee_login_restored': False,
          'cloud_service': 'InsufficientBalance; administrator action required',
          'native_window_observed_on_new_release': False,
          'production_collection_ai_or_sending_executed': False}
(ROOT / 'work/login-recovery/ACCEPTED.json').write_text(
    json.dumps(report, ensure_ascii=False, indent=2) + '\n', 'utf-8')
print(json.dumps(report, ensure_ascii=False))
