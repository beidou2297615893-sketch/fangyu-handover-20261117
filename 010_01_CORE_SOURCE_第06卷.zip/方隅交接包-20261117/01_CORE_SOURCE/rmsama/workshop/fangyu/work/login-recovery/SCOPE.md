# 登录恢复：当前总控写入范围

2026-10-17，用户要求修复“不能登录”并继续完成成品。门店作者已回执停写待命，REA保持暂停；本批总控是唯一代码写入者。

范围：work/ui-native-r57/workbench_backend.py、ui_native_host.py、ui-approved-implementation/ui-preview/app.mjs的资料失败提示与重载按钮、登录公开行为测试，以及本任务work/outputs证据和阶段冻结记录。保留既有UI/CSS/fit；不改r55 pinned组件、自用、核心或其他客户，不触发真实采集、AI或发送。

沿用本项目已认可测试缝：WorkbenchBackend.dispatch员工登录→会话/bootstrap；同源宿主HTTP登录→Cookie→后续读取。系统边界仅替换企业HTTP，不替换判断或权限实现，数据库使用隔离临时目录。无需重复索要已授权的常规测试批准。

直接证据：当前本地bootstrap=200；企业endpoint一次匿名GET返回HTTP400，固定停服标记Function is Unavailable, AvailableStatus = InsufficientBalance。没有使用真人账号密码。腾讯云官方计费状态文档明确此状态代表欠费导致函数不可用。

本轮先让软件准确显示停服原因，且停服不消耗密码错误次数；真实企业登录恢复仍依赖云账户管理员恢复服务，不能用演示账号或免登录绕过。
