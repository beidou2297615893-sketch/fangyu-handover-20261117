"""One explicit no-credential health check; never a poll or login attempt."""
from pathlib import Path
from datetime import datetime, timezone
import json
import urllib.error
import urllib.parse
import urllib.request

PROJECT = Path(__file__).resolve().parents[2]
managed = json.loads((PROJECT/'work/app/company.json').read_text('utf-8-sig'))['managedWorkspace']
endpoint = managed['endpoint']
parts = urllib.parse.urlsplit(endpoint)
assert parts.scheme == 'https' and parts.hostname == 'fh6-d5ga45c0ddae7008c-1439321968.ap-shanghai.app.tcloudbase.com'
assert parts.path == '/fangyu-workspace' and not any((parts.username, parts.password, parts.query, parts.fragment))
assert managed['environment_id'] == 'fh6-d5ga45c0ddae7008c'

class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *args, **kwargs):
        return None

request = urllib.request.Request(endpoint, method='POST',
    data=json.dumps({'operation':'health','environment_id':managed['environment_id']}).encode('utf-8'),
    headers={'Content-Type':'application/json','Accept':'application/json'})
report = {'checkedUtc':datetime.now(timezone.utc).isoformat(), 'operation':'health',
          'authorizationUsed':False, 'automaticRetries':0, 'redirectsAllowed':False}
try:
    try:
        with urllib.request.build_opener(NoRedirect).open(request, timeout=15) as response:
            status, raw = response.status, response.read(8193)
    except urllib.error.HTTPError as error:
        status, raw = error.code, error.read(8193)
    report['httpStatus'] = status
    if len(raw)>8192:
        report['state'] = 'health_unconfirmed_oversized_response'
    else:
        text = raw.decode('utf-8', errors='replace')
        if status == 400 and 'Function is Unavailable' in text and 'InsufficientBalance' in text:
            report['state'] = 'cloud_unavailable_insufficient_balance'
        else:
            try:
                value = json.loads(raw)
            except (ValueError, UnicodeError):
                value = None
            report['state'] = ('healthy_entrypoint' if status == 200 and isinstance(value,dict)
                               and value.get('ok') is True else 'health_unconfirmed')
except Exception as error:
    report.update(state='health_unconfirmed', errorType=type(error).__name__)

report['scope'] = 'One final-release event check of the existing public health operation; no login credentials, billing-console access or platform command.'
target = PROJECT/'outputs/登录故障处理/最终健康核验.json'
target.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n','utf-8')
print(json.dumps(report,ensure_ascii=False))
