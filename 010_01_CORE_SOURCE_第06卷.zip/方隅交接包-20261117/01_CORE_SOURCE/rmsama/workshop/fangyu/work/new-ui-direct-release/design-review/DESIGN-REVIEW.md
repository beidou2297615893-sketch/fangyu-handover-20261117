# 独立 UI/core 版本直启：限定设计审查

结论：可采用 `PROJECT/work/ui-runtime-r55/src` 独立版本，原 venv 的 pythonw 直接执行新 `run_workbench.py`，新进程校验本版本公开文件清单后 `import app; app.main()`。这是对独立代码版本的启动，不写旧共享 SOURCE，不需要在每次启动时重放 50→55 更新链，也不应通过把 EC86 unknown 改成 idle 来实现。此结论是源码与架构审查，未启动原 App、查询原进程或读取真实数据库；GUI、真实账号/模型功能仍未验证。

## 具体边界

- 新目录必须保持 `work/<版本>/src` 深度。原 `app.ROOT.parents[1]` 被 owner instance、guarded CLI runtime 和 runtime review 用作项目 work 根；此目录布局仍指向原 `PROJECT/work`。任意再嵌套 release/app/src 会改变这些权限边界。
- 55 的 472 protected 清单只有 43 项位于 app/src，并非完整应用包。构建须另列完整公开 Python、web、resources 文件清单，再覆盖已审 55 的 8 个本地 payload；第 9 项 cloud CSS 是配套镜像，不能把它算作已经部署的云页面。禁止整目录复制 pilot、账号或业务数据。
- `employee_workspace.asset()` 运行时 `from app import ROOT`；`desktop.py` 也按自身路径找 resources。新进程应只从新 src 导入一次命名为 `app` 的模块，保持 `app`、`assistant`、`desktop` 同源。不能先加载旧 app 再改 ROOT，或以 runpy 的 __main__ 造成第二份 app 类与全局状态。
- 保留 platform_cli.py 原字节、固定原 pilot instance、owner marker、data marker、原 guarded CLI runtime 和 component-review 绑定。原 `xiaohongshu_v1` 权限不因换界面扩大。source 55 的 provenance 可作为构建来源证据，发布使用独立版本收据，不写或伪造 source55 joined。
- 独立版本采用新目录和完整 manifest；不修改已运行版本、不使用指回旧 SOURCE 的链接。所谓 immutable 是本发布流程不原位修改；未施加和验证 OS 写保护时，不应称其为操作系统不可变。

## 原数据与实例锁

原 app main 在获取 `acquire_owner_instance_lock()` 前调用 `prepare_data()`，但该方法只检查/必要时建立目录和 owner-data marker，并 lstat DB 文件及 sidecars；真正 Core/SQLite 初始化位于获取原锁后的 AppServer。AppServer 在 Core 前还会再次执行 prepare_data。因此此顺序不会让两次正常启动在锁外并发打开数据库。

采用 Root 选择的“保已审 app.py 原字节”方案可行：新入口先要求原 pilot/data、两种 marker 与 DB 路径存在且身份正常，使用原 `open_owner_read_instance(existing_only=True)` 核实原 instance id；缺失就拒绝。原 main 获取同一个 `pilot/data/instance.lock` 的 byte 0/length 1 OS 锁一次，保原退出释放和 owner close 逻辑；入口不能再加第二把相同锁。

上述前检不是原子锁定文件树：检查后若外部把整个 data 目录移走，旧 main 的创建分支仍可能发生。此为保留代码原有的文件系统竞态，不应声称前检完全消除了所有重建可能。若以后要求对这类外部并发删除也严格拒绝，最小改动应落在新版本 app 的原实例初始化处：固定 existing_only，取原锁前只验证已有 data，复用 AppServer 内锁后的 prepare_data；不再外包一层锁或复制权限体系。本轮正常打开范围不需要为此假设扩展实现。

## 资源、运行时与诊断

- 新版本完整保留 ROOT/web/workspace、web/assets、resources 及公开 helper 模块。Python 相对导入闭合与 asset allowlist 应用静态/owned 验证；不以仅 9 个覆盖文件齐全代替整个运行图齐全。
- `owner_douyin_read.owner_runtime_root()` 用源码父目录派生 app/work/runtime/dy，新目录下会发生位置变化。当前 XHS v1 的界面启动不要求启动 Dy；不要因此复制新的平台许可或宣称 Dy 已可用。若需启用，另做明确的已验证 runtime 位置绑定。
- 独立入口可省去更新事务专用的全机 WMI/source idle/PID dead 分支；原共享源更新机制仍保持原拒绝条件。原 OS 实例锁和 account/risk/source_id/actor 权限仍由原业务代码执行。
- 失败日志用本 attempt id、固定短码、exception type 与脱敏相对 traceback 文件/函数/行号；不记录 exception message、locals、环境或数据库内容。对语法错误等无普通 traceback 的情况使用固定位置表示，不把不完整日志误报为成功。
- 若 hook 原 desktop.run_desktop 的 ready_callback，必须链式保留原 callback，先让它成功，再记录该 attempt 的原生 loaded 事件。原 on_loaded 已先检查 edgechromium 并附加 navigation guard。记录仅证明到达该原生加载阶段，不证明界面操作、真实账号或模型业务成功；独立诊断日志失败也不应使本可打开的窗口失败。

## 必要验证范围

只需新增边界验证：新 ROOT/work 根映射、完整 manifest 与模块身份、固定原 instance/runtime/review 参数、owned 实例上的原 OS 锁竞争及释放、固定入口无共享 SOURCE 写入和旧更新调用。已经通过的旧 50–55 QA、22 个 pending fallback 接缝不重做。最终新入口源码与实际发布文件仍应单独窄审；此文不批准未见源码或任何实际启动。

使用了 codebase-design/SKILL.md 与 DEEPENING.md 的模块边界方法：入口对外仅选择已核版本并启动；构建来源、版本完整性与原业务权限分别留在其所属边界。本轮未引入第三方启动框架，也未重新研究已核的 UI 组件路线。
