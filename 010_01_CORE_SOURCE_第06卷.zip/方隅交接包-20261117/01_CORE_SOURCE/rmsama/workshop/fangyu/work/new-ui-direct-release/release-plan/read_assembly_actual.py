"""Builder-author cross-check of actual public release; no App or data calls."""
from pathlib import Path
import datetime,hashlib,json,os,stat
P=Path('C:/积木软件工坊/项目/方隅公寓客户版');O=P/'work/new-ui-direct-release/release-plan';R=P/'work/ui-runtime-r55'
MANIFEST_PIN={'bytes':598108,'sha256':'E4E33FDA9699EB610F7E092A2F23C4A39AD3AB2F8505895BB194BD9D09606CF5'}
PLAN_PIN={'bytes':748303,'sha256':'AA86F33234D938509D4965ECA40F266EE7972D3A1696DE9AFB698B1EE9D1F637'}
def pin(raw):return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest().upper()}
def safe_read(path):
    for x in (path,*path.parents):
        s=x.lstat()
        assert not x.is_symlink() and not (getattr(s,'st_file_attributes',0)&0x400)
    b=path.lstat();assert stat.S_ISREG(b.st_mode) and b.st_nlink==1
    with path.open('rb') as f:
        opened=os.fstat(f.fileno());assert (b.st_dev,b.st_ino)==(opened.st_dev,opened.st_ino)
        data=f.read();afterfd=os.fstat(f.fileno())
    a=path.lstat();key=lambda x:(x.st_dev,x.st_ino,x.st_size,x.st_mtime_ns)
    assert key(b)==key(opened)==key(afterfd)==key(a)
    return data
manifest_raw=safe_read(R/'RELEASE.json');assert pin(manifest_raw)==MANIFEST_PIN
plan_raw=safe_read(O/'PUBLIC-RELEASE-MANIFEST-DESIGN.json');assert pin(plan_raw)==PLAN_PIN
m=json.loads(manifest_raw);plan=json.loads(plan_raw)
assert m['schema']=='fangyu_local_code_release_v1' and m['release_id']=='ui-core-r55' and m['project']==str(P) and m['source_root']=='src'
rows=plan['copy_app_src']+plan['copy_declared_public_runtime']+plan['copy_optional_mirror'];byrel={r['release_relative']:r for r in rows}
assert len(rows)==len(byrel)==len(m['files'])==853 and len({r['path'] for r in m['files']})==853
observed=[]
for r in m['files']:
    p=Path(r['path']);assert not p.is_absolute() and '..' not in p.parts and ':' not in r['path'] and '\\' not in r['path']
    ref=byrel[r['path']]
    assert r['source']==str(Path(ref['source'])) and r['sha256']==ref['pin']['sha256'].lower() and r['source_sha256']==r['sha256'] and r['size']==r['source_size']==ref['pin']['bytes'] and r['origin']==ref['origin']
    assert pin(safe_read(R/p))==ref['pin']
    observed.append(r['path'])
actual={str(p.relative_to(R)).replace('\\','/') for p in R.rglob('*') if p.is_file()}
assert actual==set(observed)|{'RELEASE.json'}, sorted(actual-set(observed)-{'RELEASE.json'})
assert all(not any(part.lower() in {'data','vault','cookies','sessions','profiles','.env','webview2'} for part in Path(path).parts) for path in observed)
assert all(not Path(path).name.lower().endswith(('.sqlite3','.sqlite','.db','.db-wal','.db-shm')) for path in observed)
prep=json.loads(safe_read(Path(plan['prepared']['path'])));assert pin(safe_read(Path(plan['prepared']['path'])))==plan['prepared']['pin']
payloads=[];parents=[];new_absent=[]
for t in prep['targets']:
    target=Path(t['target']);source=str(Path(t['candidate']))
    entries=[r for r in m['files'] if r['source']==source]
    assert len(entries)==1
    entry=entries[0];assert {'bytes':entry['size'],'sha256':entry['sha256'].upper()}==t['candidate_pin']
    payloads.append({'original_target':str(target),'release_relative':entry['path'],'pin':t['candidate_pin']})
    if t['parent'] is None:
        assert not os.path.lexists(target);new_absent.append(str(target))
    else:
        assert pin(safe_read(target))==t['parent'];parents.append({'path':str(target),'pin':t['parent']})
assert len([p for p in payloads if p['release_relative'].startswith('src/')])==8 and len(parents)==6 and len(new_absent)==3
assert safe_read(R/'RELEASE.json')==manifest_raw
summary={'schema':'fangyu_actual_release_author_cross_readback_v1','status':'PASS_ACTUAL_RELEASE_READBACK','review_role':'Builder author performing separate read-only cross-check; not independent non-author approval.','at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'manifest':{'path':str(R/'RELEASE.json'),'pin':MANIFEST_PIN},'plan':{'path':str(O/'PUBLIC-RELEASE-MANIFEST-DESIGN.json'),'pin':PLAN_PIN},'public_file_counts':{'all':853,'src':752,'runtime':100,'cloud_companion':1},'all_manifest_paths_pins_and_source_origins_exact':True,'no_unlisted_release_files':True,'no_private_data_subtrees_copied':True,'source55_payloads':payloads,'original_existing_payload_parents_unchanged':parents,'original_three_new_paths_absent_at_readback':new_absent,'same_depth_work_root':str((R/'src').parents[1]),'original_pilot_data_path_preserved':str(P/'work/self-operating-pilot'),'original_App_wrapper_preflight_guard_PID_calls':0,'original_data_db_cookie_vault_key_reads':0,'original_files_modified':0,'source55_original_business_apply_called':False,'GUI_verified':False}
out=O/'ACTUAL-RELEASE-READBACK.json'
with out.open('x',encoding='utf-8',newline='\n') as f:json.dump(summary,f,ensure_ascii=False,indent=2);f.write('\n')
print(json.dumps({'status':summary['status'],'path':str(out),'pin':pin(out.read_bytes()),'files':853,'local_payloads':8,'original_parent_pins':6,'original_new_absent':3},ensure_ascii=False))
