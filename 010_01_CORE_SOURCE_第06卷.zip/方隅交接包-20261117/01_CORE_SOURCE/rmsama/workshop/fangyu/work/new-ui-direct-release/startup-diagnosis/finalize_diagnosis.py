from pathlib import Path
import json,hashlib,ast
OWN=Path(__file__).resolve().parent;PROJECT=Path('C:/积木软件工坊/项目/方隅公寓客户版')
def pin(b):return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest().upper()}
def main():
    inputs={}
    paths={'current_app':PROJECT/'work/app/src/app.py','new_app':PROJECT/'work/ui-core-completion/source/app/src/app.py','desktop_entry':PROJECT/'work/desktop-self-use-entry/desktop_entry.py','desktop':PROJECT/'work/app/src/desktop.py','owner_runtime':PROJECT/'work/app/src/assistant/owner_douyin_read.py'}
    for k,p in paths.items():inputs[k]={'path':str(p),'pin':pin(p.read_bytes())}
    result=json.loads((OWN/'ACTUAL-OWNED-STARTUP.json').read_bytes());assert result['status']=='PASS_LIMITED_ACTUAL_OWNED_IMPORT_CORE_HTTP' and not result['blocked_events']
    contract=json.loads((OWN/'ENTRY-ERROR-CONTRACT.json').read_bytes());assert len(contract['cases'])==4
    report='''只读定位结论：尚未捕获实际人类打开失败的原异常，不能把pywebview缺失、WebView2问题或新UI错误当作已确定根因。实际确认的缺口是desktop_entry.py:285–298的broad except把GUI前各类异常统一HELD；run_original_main:203–215只处理SystemExit，App导入/owner/runtime/Core构造错误会进入这个catch。owned复制入口对ImportError、SyntaxError、FileNotFoundError、RuntimeError四类实际复现同一固定HELD，无原callbacks。

206eee真实owned代表不是全部构造mock：按本轮公开PREPARED9叠payload，并补齐public src Python/resources/web至own synthetic work/version/src，实际import app及其公共传递模块；actual open_owner_read_instance创建并校验own marker/数据目录；actual AppServer→Core→Store创建own SQLite并绑定loopback HTTP。/health、/workspace、/workspace?asset=app.mjs、/workspace?asset=upgrade-ui.css全部200，响应新MJS440888和CSS108452的SHA与本轮candidate一致。audit boundary拒原目录文件/外部network/process/PID/GUI/private访问，实际blocked0。只有guarded_cli_runtime_valid为recorded True用于惰性own inert exe、HTTP owner请求运输为普通ThreadingHTTPServer；未签review、未给真实平台权限。没有调用App.main/desktop_entry.main/原preflight/guard/PID/installer，未import pywebview、未创建GUI、不读取原DB/Cookie/Vault/APIkey/状态。没有证明真实运行解释器或WebView2 renderer正常。

独立版最小路径布局应为PROJECT/work/<唯一版本>/src，与原work/app/src同深度；app.py:41 ROOT仍指本版src，ROOT.parents[1]仍原work，原owner实例与guarded runtime的work约束无需改。此前担心的更深app/src布局不采用即可；AST运输载体首RED是argparse读取real argv而载体只设namespace argv导致NameError，并非产品故障，原件保留且不作通过证据。真实owned代表采用了正确同深度布局。

Root新的immutable入口仍需固定：SOURCE/sys.path/App与desktop来自同一版本；原PILOT/RUNTIME/REVIEW/argv保持原号；本版platform_cli.py/resources/web必须完整，不能只放9个delta。AppServer:1537/177/226/458的work/material边界在同深度布局保持。desktop.run_desktop:168的icon资源跟随本版src。workspace HTML仍成熟?asset=app.mjs，App:767明确切到self-operating-read.mjs，CSS通过local_workspace.asset从同版ROOT取，actual owned HTTP已证该接线。

另一个最少依赖适配点：owner_douyin_read.owner_runtime_root():33–35由_SOURCE.parent/work/runtime计算，即新版本自己的work/runtime/dy/douyin-bridge-source-cid-v1；App:370/385/634的默认bridge/runtime亦随version根。初始UI构造不要求这些Node存在，但真实显式抖音连接等功能不能悄悄丢失；应在Root批准的新release固定复用已审公共runtime完整bytes及固定路径绑定，或明确逐个固定原runtime路径，不能用任意env路径、链接或伪许可绕原review。原PILOT/私态不复制，原existing OS lock仍独占。

最小可观测修复建议仅供Root新direct入口：在各启动阶段前设置固定phase(enum import/owner/runtime/core/native)，失败只显示固定phase短码并保留原异常传播给受控诊断；不要展示str(error)/私路径/原配置，不声称未更新；native阶段仍原WebView2、无外部浏览器回退。当前没有新证据需要修改业务或UI payload，也不建议盲改pywebview/API。原实际user失败根因仍未定，Root后续完整新release可在独立own环境继续同一最难seam；本目录不签发或安装任何源码。
'''
    (OWN/'REPORT.md').write_text(report,encoding='utf-8')
    output={'schema':'new_ui_direct_startup_public_diagnosis_v1','status':'LIMITED_ACTUAL_OWNED_STARTUP_PASS_REAL_FAILURE_NOT_IDENTIFIED','public_inputs':inputs,
        'confirmed_gap':'desktop broad exception loses startup phase and exception kind','no_new_import_Core_static_UI_failure_in_owned':True,
        'safe_layout':'PROJECT/work/<unique-version>/src','required_runtime_path_review':['owner_douyin_read.owner_runtime_root','App default bridge/runtime and opencli fallback'],
        'production_files_controls_states_modified':False,'original_callbacks_called':False,
        'evidence':[{'path':str(OWN/n),'pin':pin((OWN/n).read_bytes())} for n in ('ACTUAL-OWNED-STARTUP.json','ENTRY-ERROR-CONTRACT.json','OWNED-COPY.json','PUBLIC-IMPORT-SUPPLEMENT.json','REPORT.md')]}
    (OWN/'SUMMARY.json').write_text(json.dumps(output,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({n:pin((OWN/n).read_bytes()) for n in ('SUMMARY.json','REPORT.md','ACTUAL-OWNED-STARTUP.json','ENTRY-ERROR-CONTRACT.json')}))
if __name__=='__main__':main()
