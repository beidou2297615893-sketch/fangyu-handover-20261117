"""Commit one verified browser login into one existing XHS account.

The caller holds the account's exclusive service lock throughout commit/recover.
No platform, cloud, task, or logging operation is performed here.  A small
credential-free journal bridges the SQLite transaction and filesystem renames;
these two resources cannot form a genuinely atomic transaction.
"""

from __future__ import annotations

import hashlib
import json
import math
import os
from pathlib import Path
import secrets
import shutil
import stat
import time
from typing import Callable, Mapping

from core.adapters import xhs_image_url


_COOKIES = frozenset({
    'a1', 'webId', 'web_session', 'web_session_sec', 'id_token',
    'websectiga', 'sec_poison_id', 'xsecappid', 'gid',
    'abRequestId', 'webBuild', 'loadts',
})
_REQUIRED = frozenset({'a1', 'webId', 'web_session'})
_JOURNAL = '.browser-session-commit.json'


class _GuardRejected(Exception):
    pass


def account_revision(account: Mapping) -> str:
    """Canonical full-record revision; never return or log the record itself."""
    raw = json.dumps(account, sort_keys=True, ensure_ascii=False,
                     separators=(',', ':'), allow_nan=False).encode('utf-8')
    return hashlib.sha256(raw).hexdigest()


def _safe_component(value: object) -> bool:
    return (isinstance(value, str) and bool(value) and value not in ('.', '..')
            and len(value) <= 128 and all(ch.isalnum() or ch in '-_' for ch in value))


def _reparse(path: Path) -> bool:
    if path.is_symlink():
        return True
    try:
        attrs = getattr(path.stat(follow_symlinks=False), 'st_file_attributes', 0)
        return bool(attrs & getattr(stat, 'FILE_ATTRIBUTE_REPARSE_POINT', 0))
    except FileNotFoundError:
        return False


def _paths(store, account_dir: Path, account_id: str, tenant_id: str):
    if not _safe_component(account_id) or not _safe_component(tenant_id):
        raise ValueError('scope_invalid')
    base = Path(store.directory)
    expected = base / 'accounts' / tenant_id / account_id
    if Path(account_dir).absolute() != expected.absolute():
        raise ValueError('scope_invalid')
    config = expected / '.xiaohongshu-cli'
    for path in (base, base / 'accounts', base / 'accounts' / tenant_id,
                 expected, config, config / 'cookies.json', config / _JOURNAL):
        if _reparse(path):
            raise ValueError('scope_invalid')
    return config, config / 'cookies.json', config / _JOURNAL


def _valid_candidate(path: Path) -> bool:
    if _reparse(path) or not path.is_file() or path.stat().st_size > 65536:
        return False
    data = json.loads(path.read_text(encoding='utf-8'))
    if not isinstance(data, dict) or not _REQUIRED.issubset(data) or not set(data).issubset(_COOKIES | {'saved_at'}):
        return False
    stamp = data.get('saved_at')
    if type(stamp) not in (int, float) or not math.isfinite(stamp):
        return False
    total = 0
    for key in data.keys() - {'saved_at'}:
        value = data[key]
        if not isinstance(value, str) or not value or any(ord(ch) < 32 or ord(ch) == 127 or ch == ';' for ch in value):
            return False
        size = len(value.encode('utf-8'))
        total += len(key.encode('utf-8')) + size
        if size > 8192 or total > 32768:
            return False
    return True


def _controlled_candidate(account_dir: Path, source: Path) -> bool:
    """Accept only this account's isolated browser-login HOME cookie file."""
    try:
        root = account_dir.absolute()
        source = source.absolute()
        parts = source.relative_to(root).parts
        if (len(parts) < 5 or parts[:2] != ('work', 'browser-login')
                or parts[-2:] != ('.xiaohongshu-cli', 'cookies.json')
                or not all(_safe_component(part) for part in parts[2:-2])):
            return False
        if source.resolve(strict=True) != source or not source.is_file():
            return False
        # A Windows junction or another reparse point may not report as a
        # symlink. Reject every component, including the candidate itself.
        cursor = root
        for part in parts:
            cursor = cursor / part
            if _reparse(cursor):
                return False
        return True
    except (OSError, ValueError):
        return False


def _sync_dir(path: Path):
    # Windows does not allow opening directories this way.  Process-crash
    # recovery is tested; power-loss durability depends on the filesystem.
    if os.name != 'nt':
        fd = os.open(path, os.O_RDONLY)
        try:
            os.fsync(fd)
        finally:
            os.close(fd)


def _write_journal(path: Path, data: dict):
    temp = path.with_name(path.name + '.tmp')
    with temp.open('x', encoding='utf-8') as stream:
        json.dump(data, stream, ensure_ascii=False, sort_keys=True, separators=(',', ':'))
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(temp, path)
    _sync_dir(path.parent)


def _read_journal(path: Path):
    if _reparse(path) or path.stat().st_size > 4096:
        raise ValueError('journal_invalid')
    data = json.loads(path.read_text(encoding='utf-8'))
    if (not isinstance(data, dict) or data.get('version') != 1
            or not _safe_component(data.get('account_id'))
            or not _safe_component(data.get('tenant_id'))
            or not isinstance(data.get('nonce'), str)
            or len(data['nonce']) != 32
            or any(ch not in '0123456789abcdef' for ch in data['nonce'])
            or not isinstance(data.get('old_generation'), str)
            or not isinstance(data.get('new_generation'), str)
            or data['new_generation'] != data['nonce']
            or type(data.get('old_exists')) is not bool):
        raise ValueError('journal_invalid')
    return data


def _db_account(db, account_id: str, tenant_id: str):
    row = db.execute('SELECT body FROM records WHERE entity=? AND id=? AND tenant_id=?',
                     ('accounts', account_id, tenant_id)).fetchone()
    return json.loads(row['body']) if row else None


def recover_browser_session(store, account_dir, account_id: str, tenant_id: str) -> str:
    """Resolve a prior interrupted commit while the caller holds the lock.

    Returns a fixed code: clean, old_restored, new_kept, or recovery_required.
    A conflict never guesses which credential belongs to a changed account.
    """
    try:
        config, active, journal_path = _paths(store, Path(account_dir), account_id, tenant_id)
        if not journal_path.exists():
            return 'clean'
        journal = _read_journal(journal_path)
        if journal['account_id'] != account_id or journal['tenant_id'] != tenant_id:
            return 'recovery_required'
        backup = config / ('.cookies.auth-backup-' + journal['nonce'] + '.json')
        staged = config / ('.cookies.auth-new-' + journal['nonce'] + '.json')
        if any(_reparse(path) for path in (active, journal_path, backup, staged)):
            return 'recovery_required'
        with store.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            account = _db_account(db, account_id, tenant_id)
            if account is None or account.get('id') != account_id or account.get('tenant_id') != tenant_id:
                return 'recovery_required'
            generation = str(account.get('auth_generation') or '')
            if generation == journal['new_generation']:
                if not active.exists():
                    if not staged.exists():
                        return 'recovery_required'
                    os.replace(staged, active)
                backup.unlink(missing_ok=True)
                staged.unlink(missing_ok=True)
                journal_path.unlink()
                _sync_dir(config)
                return 'new_kept'
            if generation != journal['old_generation']:
                return 'recovery_required'
            if journal['old_exists']:
                if backup.exists():
                    os.replace(backup, active)
                else:
                    # Without the old rename target we cannot prove that an
                    # existing active file is the old credential. Stop rather
                    # than label a possibly new file as restored.
                    return 'recovery_required'
            else:
                active.unlink(missing_ok=True)
            staged.unlink(missing_ok=True)
            journal_path.unlink()
            _sync_dir(config)
            return 'old_restored'
    except Exception:
        return 'recovery_required'


def commit_browser_session(store, account_dir, expected_account: Mapping,
                           decision: Mapping, candidate_cookie_path,
                           guard: Callable[[], bool]) -> str:
    """Return committed or a fixed failure code; never disclose credentials.

    The guard must recheck cancellation, cloud pause, claim validity and the
    service's account lock. It is called before staging and immediately before
    the database update. The caller must run recovery under that same lock
    before starting another login, even after a failed result.
    """
    journal_path = None
    staged = None
    try:
        account_id, tenant_id = expected_account['id'], expected_account['tenant_id']
        config, active, journal_path = _paths(store, Path(account_dir), account_id, tenant_id)
        if (expected_account.get('platform') != 'xiaohongshu'
                or decision.get('verified') is not True or decision.get('status') != 'ready'
                or not isinstance(decision.get('uid'), str) or not decision['uid']
                or not callable(guard)):
            return 'identity_invalid'
        bound = expected_account.get('platform_uid')
        if bound and bound != decision['uid']:
            return 'identity_mismatch'
        nickname = decision.get('nickname')
        avatar = decision.get('avatar')
        if not isinstance(nickname, str) or not nickname or nickname == 'Unknown' or len(nickname) > 100:
            return 'identity_invalid'
        if not isinstance(avatar, str) or len(avatar) > 2048 or (avatar and xhs_image_url(avatar) != avatar):
            return 'identity_invalid'
        if recover_browser_session(store, account_dir, account_id, tenant_id) != 'clean':
            return 'recovery_required'
        if guard() is not True:
            return 'guard_failed'
        source = Path(candidate_cookie_path)
        if not _controlled_candidate(Path(account_dir), source):
            return 'candidate_invalid'
        if not _valid_candidate(source):
            return 'candidate_invalid'
        if _reparse(active) or _reparse(journal_path):
            return 'scope_invalid'
        config.mkdir(parents=True, exist_ok=True)
        nonce = secrets.token_hex(16)
        backup = config / ('.cookies.auth-backup-' + nonce + '.json')
        staged = config / ('.cookies.auth-new-' + nonce + '.json')
        if any(path.exists() or _reparse(path) for path in (backup, staged, journal_path)):
            return 'recovery_required'
        with store.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            current = _db_account(db, account_id, tenant_id)
            if current is None:
                return 'account_deleted'
            if (current.get('id') != account_id or current.get('tenant_id') != tenant_id
                    or current.get('platform') != 'xiaohongshu'):
                return 'scope_invalid'
            if account_revision(current) != account_revision(expected_account):
                return 'account_changed'
            if current.get('platform_uid') and current['platform_uid'] != decision['uid']:
                return 'identity_mismatch'
            duplicate = db.execute('SELECT body FROM records WHERE entity=? AND tenant_id=? AND id<>?',
                                   ('accounts', tenant_id, account_id)).fetchall()
            if any((other := json.loads(row['body'])).get('platform') == 'xiaohongshu'
                   and other.get('platform_uid') == decision['uid'] for row in duplicate):
                return 'duplicate_identity'
            if guard() is not True:
                return 'guard_failed'
            journal = {'version': 1, 'account_id': account_id, 'tenant_id': tenant_id,
                       'nonce': nonce, 'old_generation': str(current.get('auth_generation') or ''),
                       'new_generation': nonce, 'old_exists': active.exists()}
            _write_journal(journal_path, journal)
            # The journal must exist before staging any credential file so a
            # process crash can always identify and remove a partial copy.
            # Only the new verified candidate is copied. Old credentials are
            # never read, copied, serialized, or included in the journal.
            with source.open('rb') as incoming, staged.open('xb') as outgoing:
                shutil.copyfileobj(incoming, outgoing)
                outgoing.flush()
                os.fsync(outgoing.fileno())
            staged.chmod(0o600)
            if not _valid_candidate(staged):
                raise ValueError('candidate_invalid')
            _sync_dir(config)
            if journal['old_exists']:
                os.replace(active, backup)
            os.replace(staged, active)
            _sync_dir(config)
            if guard() is not True:
                raise _GuardRejected()
            updated = dict(current)
            updated.update(status='ready', checked_at=time.strftime('%Y-%m-%dT%H:%M:%S'),
                           platform_uid=decision['uid'], platform_nickname=nickname,
                           auth_generation=nonce)
            if avatar:
                updated['platform_avatar_url'] = avatar
            db.execute('UPDATE records SET body=? WHERE entity=? AND id=? AND tenant_id=?',
                       (json.dumps(updated, ensure_ascii=False), 'accounts', account_id, tenant_id))
        result = recover_browser_session(store, account_dir, account_id, tenant_id)
        return 'committed' if result == 'new_kept' else 'recovery_required'
    except _GuardRejected:
        result = recover_browser_session(store, account_dir, account_id, tenant_id)
        return 'guard_failed' if result == 'old_restored' else 'recovery_required'
    except Exception:
        # The persisted journal tells recovery which generation is authoritative.
        if journal_path is not None and journal_path.exists():
            result = recover_browser_session(store, account_dir, account_id, tenant_id)
            if result not in ('old_restored', 'new_kept'):
                return 'recovery_required'
            return 'committed' if result == 'new_kept' else 'commit_failed'
        return 'commit_failed'
    finally:
        if staged is not None and journal_path is not None and not journal_path.exists():
            try:
                staged.unlink(missing_ok=True)
            except OSError:
                pass
