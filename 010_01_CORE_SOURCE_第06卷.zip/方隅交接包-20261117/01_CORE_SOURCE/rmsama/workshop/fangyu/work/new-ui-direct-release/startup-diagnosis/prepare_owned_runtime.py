from pathlib import Path
import json,hashlib,shutil
OWN=Path(__file__).resolve().parent;PROJECT=Path('C:/积木软件工坊/项目/方隅公寓客户版')
def pin(b):return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest().upper()}
def main():
    prepared=PROJECT/'work/ui-core-completion/release/PREPARED.json';d=json.loads(prepared.read_bytes());base=PROJECT/'work/app/src'
    dest=OWN/'owned-runtime/work/version/src';dest.mkdir(parents=True,exist_ok=False);rows=[]
    sources={}
    for row in d['protected']+d['candidate_dependencies']:
        p=Path(row['path'])
        if p.is_relative_to(base):sources[p]=(p,row['pin'])
    for row in d['targets']:
        p=Path(row['target'])
        if p.is_relative_to(base):sources[p]=(Path(row['candidate']),row['candidate_pin'])
    for target,(source,proof) in sources.items():
        raw=source.read_bytes();assert pin(raw)==proof,(source,pin(raw),proof)
        out=dest/target.relative_to(base);out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(raw)
        rows.append({'public_source':str(source),'owned_copy':str(out),'pin':proof})
    (OWN/'OWNED-COPY.json').write_text(json.dumps({'prepared':{'path':str(prepared),'pin':pin(prepared.read_bytes())},'files':rows,'original_private_or_state_copied':False},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'files':len(rows),'owned_source':str(dest)},ensure_ascii=True))
if __name__=='__main__':main()
