# 独立新版公开代码装配方案

可装配。采用 `C:/积木软件工坊/项目/方隅公寓客户版/work/ui-runtime-r55/src`，保持与原 `work/app/src` 相同深度。不要多嵌一层 `releases/<id>/app/src`：现有 `app.ROOT.parents[1]` 必须仍指向原项目 `work`，否则原 pilot 和 guarded CLI 会被正确的路径校验拒绝。此布局不需要改 `_OwnerReadInstance`、原 marker、原数据路径或原权限代码。

## 精确清单与装配入口

- `PUBLIC-RELEASE-MANIFEST-DESIGN.json`：748303 字节，SHA256 `AA86F33234D938509D4965ECA40F266EE7972D3A1696DE9AFB698B1EE9D1F637`。逐文件指定公开来源、相对目标、完整 pin 和来源类别。
- `build_public_release.py`：Root 执行的固定目标装配脚本，本审者仅语法解析，未执行。新版本目录必须不存在；独占创建，拒绝合并或覆盖。只写新版本目录及本 release-plan 的装配回执。
- 新根 `RELEASE.json` 使用 `fangyu_local_code_release_v1`，`release_id=ui-core-r55`，`source_root=src`。`files` 含相对 `path`、小写 `sha256`、`size`、完整 `source`、`source_sha256`、来源类别。launcher 由 Root 单独管理，不纳入循环自签清单。

| 分类 | 来源 → 新版相对路径 | 数量 |
|---|---|---:|
| 完整 App 公开代码/资源 | 原 `work/app/src/**` → `src/**`，按固定文件清单而非复制整个目录 | 749 原文件 |
| 55 本地覆盖 | 已审 `work/ui-core-completion/source/app/src/**` → `src/**` | 覆盖 5 原文件、新增 3 文件 |
| 完整新版 src | 包含全部 Python、Web、SVG/PNG、资源规则、许可、XlsxWriter 及其 dist-info | 752 文件，39398958 字节 |
| 两套公开 Node bridge | 55 保护表中的 `work/app/work/runtime/**` → `work/runtime/**` | 100 文件，175137876 字节 |
| 云 CSS companion | 已审云 CSS → `mirrors/cloud/workspace/site/upgrade-ui.css` | 1 文件 |

总计 853 文件。第 9 个 payload 是云 CSS companion，仅保留镜像材料，不写原 cloud 目录、不开云服务、不部署。其余 8 项进入新本地 src。

55 的 472 项保护表不是完整 App 安装表：其中只有 43 项在 `app/src`。完整新 src 中还有 701 个当前公开文件，已按本次实际稳定读取的哈希进入装配清单；它们没有因本方案被修改。13 个直接依赖全部已由新 src 覆盖且与已审 pin 一致。静态 AST 共解析 1172 条本地导入边，未发现缺少的 `core`/`assistant` 本地模块。这是静态完整性证据，不是运行或 GUI 验收。

## 资源和路径结论

1. `app.py:1537` 原实例工作根、`:177` guarded CLI 选择、`:226` 组件审核路径根均由同深度布局保持为原 `PROJECT/work`。`assistant/original_browser_identity_maintenance.py:29` 的原 PROJECT 推导也保持一致；其受限能力不因此启用。
2. `employee_workspace.asset()` 读取 `src/web/workspace`；owner App 单独读取 `self-operating-read.mjs`；全部 Web/图标/公共素材在完整 src 清单中。`desktop.py` 的 `resources/brand.ico` 同样包含。
3. `app.py:370,634`、`owner_douyin_read.owner_runtime_root()` 依赖版本根下 `work/runtime`。复制已审两套 100 项材料保持这些相对路径。只复制原批准的公开文件，不递归带入 runtime 里可能出现的 state/cache/profile。
4. 原 guarded CLI 保持外部固定位置 `PROJECT/work/product-upgrade-20261009/cli-current-wrapper-component-candidate-v6/artifacts/platform-cli-guarded`，清单中 290 个公开保护项保留为外部引用。新 `platform_cli.py` 复制后字节不变，正常入口仍必须完成原运行库/组件审核核对；未执行 CLI。
5. Python/pywebview 继续使用已有 `work/desktop-python`，不复制 venv，不安装依赖，不开窗口。
6. `客户定制` **不是本次正常启动必须资源**。`ui_customization.load_customization()` 对缺少主题/文案/素材映射返回空默认配置；公开 BDF 新 CSS 和内置资产已在 src。此方案不读或复制原客户定制目录。原自营配置来自原 owner marker，因此不需要复制 `work/app/company.json`。
7. 可选 opencli、快手和微博备用运行库不在 55 的 100 项 Node 清单中，不能据此宣称它们已移植或可运行。原 v1 自营实例仍仅小红书，独立新版不得加 primary/upgrade flags；抖音、微信等各自原许可与用途条件保留，不能把公开代码/资源齐全当作真实平台已启用。

## 原数据与证据边界

`work/self-operating-pilot` 的 `component-review.json`、`self-operating-instance.json`、`data/owner-data-instance.json` 仅在方案中引用已审 pin，**本次没有读取其文件内容，也绝不复制**。所有真实 DB、Cookie、Vault、key、profile、会话和原 `running`/lock 留原址。原 ENTRY 只作历史证据，不复制为新入口。另 325 项公开 cloud/admin/CLI 保护项作为外部引用；不伪装成新代码根已包含的文件。原 source、raw、backups、authority 和 shortcut 本阶段均无写入。

## 最小必要验证路线

1. Root 阅读固定装配脚本与完整清单后执行一次。它先检查所有来源固定 pin，独占创建新版本目录；逐文件 `xb`、flush/fsync、目标读回，最后再次验证所有来源/目标 pin。出现异常保留部分目录与失败记录，不删除或自动重装。
2. 新版所有 Python 只做 AST/compile，JS/MJS 只做语法检查；检查新源导入解析不回落到原 `work/app/src`。无需再次运行旧 QA 矩阵。
3. 用隔离临时 pilot、合成 marker/fixture 和显式阻断平台/模型/外发的 adapter 验证新入口 argv、同深度 work 根、原 OS 锁互斥、Web 资源/API 请求、退出路径。原 App 不作为测试夹具，不导入旧 launcher 的自动更新链。
4. 由 Root 新入口在用户正常打开时调用完整新版，保原数据路径和原 OS 实例锁。启动前清楚区分版本清单损坏、已有实例和窗口失败；不能重用“等待切换”的模糊提示。实际 GUI 和用户认可仍须该正常打开反馈，不以装配或 fixture 成功代替。

本项只做计划、公开源/清单读取和 AST 分析。0 原 App/wrapper/preflight/guard/PID、0 私人数据读取、0 真实平台或模型调用。
