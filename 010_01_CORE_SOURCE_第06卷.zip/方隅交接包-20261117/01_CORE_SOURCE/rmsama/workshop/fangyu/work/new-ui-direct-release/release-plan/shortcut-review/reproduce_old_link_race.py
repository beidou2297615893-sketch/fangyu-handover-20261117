from pathlib import Path
import contextlib,hashlib,io,json,types,uuid
OWN=Path(__file__).resolve().parent
SOURCE=OWN.parent.parent/'root/install_desktop_entry.py'
raw=SOURCE.read_bytes()
def sha(b):return hashlib.sha256(b).hexdigest().upper()
def write(p,b):p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
RUN=OWN/'owned'/uuid.uuid4().hex;RUN.mkdir(parents=True)
snapshot=OWN/'installer-first-reviewed.py'
with snapshot.open('xb') as f:f.write(raw)
m=types.ModuleType('owned_shortcut_installer_review');m.__file__=str(SOURCE);exec(compile(raw,str(SOURCE),'exec'),m.__dict__)
m.PROJECT=RUN/'project';m.OWN=m.PROJECT/'work/review';m.SOURCE=m.OWN/'root/run_workbench.py';m.TARGET=m.PROJECT/'work/ui-runtime-r55/run_workbench.py';m.PYTHONW=m.PROJECT/'work/pythonw.exe';m.SHORTCUT=RUN/'desktop/Workbench.lnk';m.OLD_LAUNCHER=m.PROJECT/'work/old.py'
m.NEW_ARGS='-X utf8 -B -I "'+m.TARGET.as_posix()+'"';m.OLD_ARGS='-X utf8 -B -I "'+m.OLD_LAUNCHER.as_posix()+'"'
code=('from pathlib import Path\nRELEASE=Path('+repr(str(m.TARGET.parent))+')\nMANIFEST_SHA256="owned-recorded"\n_calls=0\ndef verify_release():\n global _calls\n _calls+=1\n if _calls==2:Path('+repr(str(m.SHORTCUT))+').write_bytes(b"USER_CHANGED_DURING_RELEASE_VERIFY")\n').encode()
write(m.SOURCE,code);m.SOURCE_SHA=sha(code)
write(m.PYTHONW,b'owned pythonw placeholder not executed');write(m.SHORTCUT,b'OLD_LINK');m.OLD_SHORTCUT_SHA=sha(b'OLD_LINK')
write(m.PROJECT/'work/ui-runtime-r55/src/resources/brand.ico',b'owned icon')
def shortcut_info(path):
 return {'target':str(m.PYTHONW),'arguments':m.NEW_ARGS if Path(path).read_bytes()==b'NEW_LINK' else m.OLD_ARGS,'working_directory':str(m.PROJECT),'icon':'owned','window_style':1}
def powershell(_):
 backups=list((m.OWN/'desktop-backup').iterdir());assert len(backups)==1
 write(backups[0]/'new.lnk',b'NEW_LINK');return {'saved':True}
m.shortcut_info=shortcut_info;m.powershell=powershell
with contextlib.redirect_stdout(io.StringIO()):m.main()
assert m.SHORTCUT.read_bytes()==b'NEW_LINK'
result={'schema':'owned_shortcut_concurrent_change_red_v1','status':'RED_CONFIRMED','installer_pin':{'bytes':len(raw),'sha256':sha(raw)},'owned_run':str(RUN),'trigger':'Recorded public verify_release second call changes owned original link after installer last read_pin but before os.replace.','observed':'Installer reports INSTALLED and overwrites USER_CHANGED_DURING_RELEASE_VERIFY with NEW_LINK.','expected':'Reject and retain concurrently changed link.','real_shortcut_COM_calls':0,'real_App_guard_PID_calls':0,'original_project_writes':0}
out=OWN/'CONCURRENT-LINK-RED.json'
with out.open('x',encoding='utf-8') as f:json.dump(result,f,ensure_ascii=False,indent=2)
print(json.dumps({'report':str(out),'bytes':out.stat().st_size,'sha256':sha(out.read_bytes()),'installer':result['installer_pin']},ensure_ascii=False))
