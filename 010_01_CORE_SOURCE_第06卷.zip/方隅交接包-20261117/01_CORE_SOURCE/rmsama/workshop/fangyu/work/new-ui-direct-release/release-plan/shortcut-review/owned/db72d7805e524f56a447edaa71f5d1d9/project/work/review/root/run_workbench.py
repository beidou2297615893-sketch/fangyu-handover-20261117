from pathlib import Path
RELEASE=Path('C:\\积木软件工坊\\项目\\方隅公寓客户版\\work\\new-ui-direct-release\\release-plan\\shortcut-review\\owned\\db72d7805e524f56a447edaa71f5d1d9\\project\\work\\ui-runtime-r55')
MANIFEST_SHA256="owned-recorded"
_calls=0
def verify_release():
 global _calls
 _calls+=1
 if _calls==2:Path('C:\\积木软件工坊\\项目\\方隅公寓客户版\\work\\new-ui-direct-release\\release-plan\\shortcut-review\\owned\\db72d7805e524f56a447edaa71f5d1d9\\desktop\\Workbench.lnk').write_bytes(b"USER_CHANGED_DURING_RELEASE_VERIFY")
