"""One reversible local shortcut switch; never starts any application."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import stat
import subprocess
import types
import uuid

PROJECT = Path('C:/积木软件工坊/项目/方隅公寓客户版')
OWN = PROJECT / 'work/new-ui-direct-release'
SOURCE = OWN / 'root/run_workbench.py'
TARGET = PROJECT / 'work/ui-runtime-r55/run_workbench.py'
PYTHONW = PROJECT / 'work/desktop-python/Scripts/pythonw.exe'
SHORTCUT = Path('C:/Users/rmsama/Desktop/方隅工作台.lnk')
SOURCE_SHA = 'F674EBFA031019169CD0441B5066E7B4A2DDAE8774269C171B3E846A2516A3C5'
OLD_SHORTCUT_SHA = 'F6B9CFFF37D8523413AD16ABE374F9E849843D3B6EEA5643629D8CBA20F8CE4B'
OLD_LAUNCHER = PROJECT / 'work/desktop-self-use-entry/source_next_open_launcher.py'
NEW_ARGS = '-X utf8 -B -I "' + TARGET.as_posix() + '"'
OLD_ARGS = '-X utf8 -B -I "' + OLD_LAUNCHER.as_posix() + '"'


def plain(path):
    path = Path(path)
    for q in (path, *path.parents):
        info = q.lstat()
        if q.is_symlink() or getattr(info, 'st_file_attributes', 0) & 0x400:
            raise ValueError('redirected install path')
    info = path.lstat()
    if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1:
        raise ValueError('ordinary file required')
    return info


def read_pin(path, expected=None):
    before = plain(path)
    with Path(path).open('rb') as stream:
        opened = os.fstat(stream.fileno())
        data = stream.read()
        ended = os.fstat(stream.fileno())
    after = plain(path)
    identity = lambda s: (s.st_dev, s.st_ino, s.st_size, s.st_mtime_ns)
    if not identity(before) == identity(opened) == identity(ended) == identity(after):
        raise ValueError('install input changed')
    digest = hashlib.sha256(data).hexdigest().upper()
    if expected is not None and digest != expected:
        raise ValueError('install input hash changed')
    return data, {'size': len(data), 'sha256': digest,
                  'file_identity': [after.st_dev, after.st_ino]}


def ps_quote(value):
    return "'" + str(value).replace("'", "''") + "'"


def powershell(code):
    prefix = "$ErrorActionPreference='Stop'; $ProgressPreference='SilentlyContinue'; [Console]::OutputEncoding=[System.Text.UTF8Encoding]::new($false); "
    result = subprocess.run(['powershell.exe', '-NoLogo', '-NoProfile', '-NonInteractive', '-Command', prefix + code],
        capture_output=True, encoding='utf-8', timeout=30,
        creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
    if result.returncode:
        raise RuntimeError('shortcut operation failed')
    return json.loads(result.stdout.lstrip('\ufeff'))


def shortcut_info(path):
    plain(path)
    return powershell("$w=New-Object -ComObject WScript.Shell; $s=$w.CreateShortcut(" + ps_quote(path) + "); "
        "[ordered]@{target=$s.TargetPath;arguments=$s.Arguments;working_directory=$s.WorkingDirectory;icon=$s.IconLocation;window_style=$s.WindowStyle}|ConvertTo-Json -Compress")


def verify_shortcut(info, args):
    if (Path(info['target']) != PYTHONW or info['arguments'] != args
            or Path(info['working_directory']) != PROJECT):
        raise ValueError('shortcut binding changed')


def write_exclusive(path, data):
    with path.open('xb') as stream:
        stream.write(data)
        stream.flush()
        os.fsync(stream.fileno())


def write_json(path, value):
    write_exclusive(path, (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode('utf-8'))


def main():
    if os.path.lexists(TARGET) or (OWN / 'ACTUAL-DESKTOP-INSTALLED.json').exists():
        raise ValueError('new launcher or receipt already exists; no repeat install')
    candidate, candidate_pin = read_pin(SOURCE, SOURCE_SHA)
    old_bytes, old_pin = read_pin(SHORTCUT, OLD_SHORTCUT_SHA)
    original = shortcut_info(SHORTCUT)
    verify_shortcut(original, OLD_ARGS)
    plain(PYTHONW)
    module = types.ModuleType('reviewed_new_release_installer_check')
    module.__file__ = str(SOURCE)
    exec(compile(candidate, str(SOURCE), 'exec'), module.__dict__)
    module.verify_release()  # Public release only; not main/owner/preflight.
    backup = OWN / 'desktop-backup' / uuid.uuid4().hex
    backup.mkdir(parents=True)
    write_exclusive(backup / 'original.lnk', old_bytes)
    write_json(backup / 'original.json', {'shortcut': str(SHORTCUT), 'pin': old_pin, 'fields': original})
    write_exclusive(TARGET, candidate)
    read_pin(TARGET, SOURCE_SHA)
    staged = backup / 'new.lnk'
    icon = PROJECT / 'work/ui-runtime-r55/src/resources/brand.ico'
    plain(icon)
    powershell("$w=New-Object -ComObject WScript.Shell; $s=$w.CreateShortcut(" + ps_quote(staged) + "); "
        "$s.TargetPath=" + ps_quote(PYTHONW) + "; $s.Arguments=" + ps_quote(NEW_ARGS) + "; "
        "$s.WorkingDirectory=" + ps_quote(PROJECT) + "; $s.IconLocation=" + ps_quote(str(icon) + ',0') + "; "
        "$s.WindowStyle=1; $s.Description='方隅工作台 · 新界面与核心功能'; $s.Save(); @{saved=$true}|ConvertTo-Json -Compress")
    new_fields = shortcut_info(staged)
    verify_shortcut(new_fields, NEW_ARGS)
    staged_bytes, staged_pin = read_pin(staged)
    read_pin(SOURCE, SOURCE_SHA)
    read_pin(TARGET, SOURCE_SHA)
    module.verify_release()
    # Long verification is finished. Preserve both paths if another writer
    # replaced either file, including replacement with byte-identical content.
    _, fresh_staged = read_pin(staged, staged_pin['sha256'])
    _, fresh_shortcut = read_pin(SHORTCUT, OLD_SHORTCUT_SHA)
    if (fresh_staged['file_identity'] != staged_pin['file_identity']
            or fresh_shortcut['file_identity'] != old_pin['file_identity']):
        raise ValueError('shortcut owner changed; preserve both files')
    os.replace(staged, SHORTCUT)  # Same C: volume, one desktop link, atomic switch.
    actual_bytes, actual_pin = read_pin(SHORTCUT, staged_pin['sha256'])
    actual_fields = shortcut_info(SHORTCUT)
    verify_shortcut(actual_fields, NEW_ARGS)
    result = {'schema': 'fangyu_direct_release_desktop_install_v1', 'status': 'INSTALLED',
        'time_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'shortcut': str(SHORTCUT), 'previous': {'pin': old_pin, 'fields': original},
        'current': {'pin': actual_pin, 'fields': actual_fields},
        'backup': str(backup), 'launcher': {'path': str(TARGET), **candidate_pin},
        'manifest': {'path': str(module.RELEASE / 'RELEASE.json'), 'sha256': module.MANIFEST_SHA256},
        'original_source_writes': 0, 'original_control_receipt_writes': 0,
        'original_data_reads_or_copies': 0, 'app_launches': 0, 'original_source55_apply_calls': 0,
        'new_release_files_installed': 853, 'GUI_verified': False, 'real_platform_model_verified': False}
    write_json(OWN / 'ACTUAL-DESKTOP-INSTALLED.json', result)
    print(json.dumps(result, ensure_ascii=False))


if __name__ == '__main__':
    main()
