"""Copy missing public module/resource files only; never copy original data."""
from pathlib import Path
import json,hashlib
OWN=Path(__file__).resolve().parent;BASE=Path('C:/积木软件工坊/项目/方隅公寓客户版/work/app/src');DEST=OWN/'owned-runtime/work/version/src'
def main():
    rows=[];suffixes={'.py','.json','.html','.mjs','.css','.js','.svg','.ico','.png','.webp'}
    for source in BASE.rglob('*'):
        if not source.is_file() or source.suffix.lower() not in suffixes or '__pycache__' in source.parts:continue
        rel=source.relative_to(BASE)
        if source.suffix.lower()!='.py' and rel.parts[0] not in ('resources','web'):continue
        target=DEST/rel
        if target.exists():continue
        raw=source.read_bytes();target.parent.mkdir(parents=True,exist_ok=True)
        with target.open('xb') as stream:stream.write(raw)
        rows.append({'public_source':str(source),'owned_copy':str(target),'pin':{'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest().upper()}})
    (OWN/'PUBLIC-IMPORT-SUPPLEMENT.json').write_text(json.dumps({'files':rows,'scope':'public work/app/src Python modules and web/resources only; no DB/secret/runtime state','original_functions_executed':False},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'supplemental_public_files':len(rows)}))
if __name__=='__main__':main()
