"""One new-release metadata/runtime binding check; never App.main or a DB open."""
from pathlib import Path
import hashlib, importlib.util, json, os, sys, types

PROJECT=Path('C:/积木软件工坊/项目/方隅公寓客户版')
OWN=PROJECT/'work/new-ui-direct-release'
SOURCE=PROJECT/'work/ui-runtime-r55/src'
RUNTIME=PROJECT/'work/product-upgrade-20261009/cli-current-wrapper-component-candidate-v6/artifacts/platform-cli-guarded'
PILOT=PROJECT/'work/self-operating-pilot'
OUT=OWN/'ACTUAL-NEW-RELEASE-BINDING.json'
LAUNCHER=OWN/'root/run_workbench.py'
allowed_files={PILOT/'self-operating-instance.json', PILOT/'component-review.json',
               PILOT/'data/owner-data-instance.json', LAUNCHER}
blocked=[]

def audit(event,args):
    if event in ('sqlite3.connect','subprocess.Popen','os.system','socket.connect','socket.bind'):
        blocked.append(event);raise RuntimeError('no business/native/network/DB operation')
    if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):
        p=Path(os.fsdecode(args[0])).absolute()
        if p==OUT and not OUT.exists():return
        if p.is_relative_to(PROJECT):
            flags=args[2] if len(args)>2 else 0
            if flags & (os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND):
                blocked.append('project_write');raise RuntimeError('read-only check')
            if not (p in allowed_files or p.is_relative_to(SOURCE) or p.is_relative_to(RUNTIME)):
                blocked.append('unlisted_project_read');raise RuntimeError('public fixed scope only')
sys.addaudithook(audit)
stage='launcher'
result={'schema':'new_release_original_metadata_binding_v1','original_App_main_calls':0,
        'DB_Cookie_Vault_key_reads':0,'process_guard_PID_calls':0,'GUI_calls':0}
try:
    raw=LAUNCHER.read_bytes()
    assert hashlib.sha256(raw).hexdigest()=='f674ebfa031019169cd0441b5066e7b4a2ddae8774269c171b3e846a2516a3c5'
    launch=types.ModuleType('bound_public_launcher');launch.__file__=str(LAUNCHER)
    exec(compile(raw,str(LAUNCHER),'exec'),launch.__dict__)
    sys.path.insert(0,str(SOURCE))
    import app
    stage='original_owner_metadata'
    product=launch.verify_existing_owner()
    from assistant.self_operating_read import open_owner_read_instance
    instance=open_owner_read_instance(str(PILOT),str(PROJECT/'work'),
        hashlib.sha256((SOURCE/'platform_cli.py').read_bytes()).hexdigest(),product=product,existing_only=True)
    stage='actual_guarded_runtime_bytes'
    company,selected=app.source_guarded_cli_selection(str(RUNTIME),instance.check(),owner_instance=instance)
    stage='actual_review_binding'
    binding=app._TrustedStartupRuntimeReview(str(launch.REVIEW),launch.REVIEW_SHA256,company,owner_instance=instance)
    assert binding.current(company)
    result.update(status='PASS_READONLY_BINDING',product=product,
                  code_work_root_matches=app.ROOT.parents[1]==PROJECT/'work',
                  runtime_path_matches=selected==RUNTIME,review_binding_valid=True)
except Exception as exc:
    result.update(status='FAIL_READONLY_BINDING',stage=stage,exception_type=type(exc).__name__)
result['blocked_events']=blocked
with OUT.open('x',encoding='utf-8') as f:json.dump(result,f,ensure_ascii=False,indent=2)
print(json.dumps(result,ensure_ascii=False))
raise SystemExit(0 if result['status']=='PASS_READONLY_BINDING' else 1)
