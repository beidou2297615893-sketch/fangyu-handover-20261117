"""Own copied public imports/Core/SQLite/listener/assets; never original startup."""
from pathlib import Path
import sys,os,json,hashlib,traceback,threading,urllib.request,http.server
sys.dont_write_bytecode=True
OWN=Path(__file__).resolve().parent
ROOT=OWN/'owned-runtime/work/version/src';WORK=ROOT.parents[1]
allowed_roots=[OWN.resolve(),Path(sys.prefix).resolve(),Path(sys.base_prefix).resolve()]
blocked=[];events=[];owned_port=None
def permitted(value,write=False):
    if isinstance(value,int):return True
    if not isinstance(value,(str,bytes,os.PathLike)):return False
    text=os.fsdecode(value)
    if text.startswith('file:'):text=text.removeprefix('file:///').split('?',1)[0].replace('/',os.sep)
    p=Path(text).resolve()
    return p.is_relative_to(allowed_roots[0]) if write else any(p.is_relative_to(r) for r in allowed_roots)
def audit(event,args):
    deny=False
    if event=='open':
        path,mode,flags=args;write=bool(flags & (os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND))
        deny=not permitted(path,write)
    elif event in ('sqlite3.connect',):deny=not permitted(args[0],True)
    elif event in ('os.listdir','os.scandir'):deny=not permitted(args[0])
    elif event in ('os.mkdir','os.remove','os.rmdir','os.rename','os.replace'):deny=any(not permitted(v,True) for v in args[:2] if isinstance(v,(str,bytes,os.PathLike)))
    elif event in ('subprocess.Popen','os.system','os.startfile','webbrowser.open'):deny=True
    elif event=='socket.bind':deny=args[1][0]!='127.0.0.1'
    elif event=='socket.connect':deny=not (args[1][0]=='127.0.0.1' and args[1][1]==owned_port)
    elif event=='socket.getaddrinfo':deny=args[0] not in ('127.0.0.1',None)
    elif event=='ctypes.dlsym':deny=str(args[1]) in ('OpenProcess','GetCommandLineW','CryptUnprotectData','MessageBoxW','CreateWindowExW')
    if deny:blocked.append(event);raise PermissionError('OWNED_BOUNDARY:'+event)
sys.addaudithook(audit)
sys.path.insert(0,str(ROOT))
result={'schema':'actual_owned_public_startup_v1','original_App_guard_PID_preflight_state_DB_GUI_calls':0,'GUI_created':False,'platform_model_network_called':False}
server=None;thread=None
try:
    import app
    events.append('actual_copied_app_and_transitive_public_module_imports')
    from assistant.self_operating_read import open_owner_read_instance
    pilot=WORK/'synthetic-pilot'
    wrapper=hashlib.sha256((ROOT/'platform_cli.py').read_bytes()).hexdigest()
    instance=open_owner_read_instance(str(pilot),str(WORK),wrapper)
    instance.prepare_data();events.append('actual_owned_synthetic_marker_instance_check_prepare_data')
    runtime=WORK/'owned-runtime';runtime.mkdir()
    (runtime/'platform-cli.exe').write_bytes(b'OWNED_INERT_EXECUTION_BLOCKED')
    (runtime/'guard-manifest.json').write_bytes(b'{"owned":true}')
    # Only external CLI validation is recorded, not module/Core/instance/HTTP setup.
    app.guarded_cli_runtime_valid=lambda *a,**k:True
    class OwnedServer(app.AppServer):
        # Static asset transport only; no auth/product APIs or old normal-open callbacks.
        process_request=http.server.ThreadingHTTPServer.process_request
    server=OwnedServer(('127.0.0.1',0),pilot/'data',employee_workspace=True,
        guarded_cli_runtime=str(runtime),self_operating_instance=instance)
    events.append('actual_AppServer_Core_Store_owned_SQLite_and_loopback_listener_constructed')
    owned_port=server.server_port
    thread=threading.Thread(target=server.serve_forever,kwargs={'poll_interval':.05},daemon=True);thread.start()
    opener=urllib.request.build_opener(urllib.request.ProxyHandler({}));assets=[]
    for route in ('/health','/workspace','/workspace?asset=app.mjs','/workspace?asset=upgrade-ui.css'):
        with opener.open('http://127.0.0.1:'+str(owned_port)+route,timeout=4) as response:
            raw=response.read();assert response.status==200 and raw
            assets.append({'route':route,'status':response.status,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest().upper(),'content_type':response.headers.get('Content-Type')})
    result.update(status='PASS_LIMITED_ACTUAL_OWNED_IMPORT_CORE_HTTP',assets=assets)
except Exception as error:
    result.update(status='ACTUAL_OWNED_STARTUP_RED',error_type=type(error).__name__,error_text=str(error),traceback=traceback.format_exc())
finally:
    if server is not None:
        if thread is not None:server.shutdown();thread.join(timeout=4)
        http.server.ThreadingHTTPServer.server_close(server)
    result.update(events=events,blocked_events=blocked,
        recorded=['guarded_cli_runtime_valid returns owned synthetic acceptance; inert exe is never run','HTTP request ownership transport uses ThreadingHTTPServer directly for public static assets only','GUI/normal main/original close lifecycle not run'],
        not_proven=['actual desktop user failure cause','actual original interpreter/webview/WebView2 native load','genuine reviewed runtime/license and owner authority','real normal-open lock/resource lifecycle','GUI JS execution or platform/model/business operations'])
    (OWN/'ACTUAL-OWNED-STARTUP.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'status':result['status'],'events':events,'error_type':result.get('error_type'),'blocked_events':blocked}))
