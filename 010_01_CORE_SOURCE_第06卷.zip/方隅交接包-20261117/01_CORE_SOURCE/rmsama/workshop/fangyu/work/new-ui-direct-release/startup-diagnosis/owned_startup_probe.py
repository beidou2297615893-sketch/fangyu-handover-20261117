"""Execute copied AST functions against own paths and recorded host leaves only."""
from pathlib import Path
import ast,types,sys,json,hashlib,argparse,os,stat,re,logging
sys.dont_write_bytecode=True
OWN=Path(__file__).resolve().parent
PROJECT=Path('C:/积木软件工坊/项目/方隅公寓客户版')
APP=PROJECT/'work/ui-core-completion/source/app/src/app.py'
ENTRY=PROJECT/'work/desktop-self-use-entry/desktop_entry.py'
OWNER=PROJECT/'work/ui-core-completion/source/app/src/assistant/self_operating_read.py'

def pin(b):return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest().upper()}
def extracted(path,names):
    raw=path.read_bytes();tree=ast.parse(raw)
    nodes=[n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef)) and n.name in names]
    assert set(n.name for n in nodes)==set(names)
    return ast.Module(body=nodes,type_ignores=[])
class ConstructorBoundary(Exception):pass
def main():
    root=OWN/'owned-fixture';work=root/'work';pilot=work/'self-operating-pilot';runtime=work/'runtime'
    pilot.mkdir(parents=True,exist_ok=False);runtime.mkdir()
    (runtime/'platform-cli.exe').write_bytes(b'OWNED_INERT_NEVER_EXECUTED')
    (runtime/'guard-manifest.json').write_bytes(b'{"owned":true}')
    base=work/'app/src';relocated=work/'new-ui-direct-release/immutable/app/src'
    for path in (base,relocated):path.mkdir(parents=True);(path/'platform_cli.py').write_bytes(b'OWNED_WRAPPER_NEVER_EXECUTED')
    ns={'Path':Path,'stat':stat};exec(compile(extracted(OWNER,['_plain_directory']),str(OWN/'copied_owner_path_function.py'),'exec'),ns)
    actual_plain=ns['_plain_directory']
    config={'id':'owned-startup','name':'Owned','edition':'owner','personalMode':True,'authMode':'local','runtime':{},'platforms':['xiaohongshu']}
    events=[]
    class Owner:
        def __init__(self):self.directory=pilot
        def check(self):return config
        def prepare_data(self):events.append('recorded_prepare_data_no_DB')
    owner=Owner()
    def open_owner(path,work_root,wrapper,**kwargs):
        assert Path(path)==pilot;actual_plain(pilot,Path(work_root));events.append('actual_own_path_closure');return owner
    assistant=types.ModuleType('assistant');assistant.__path__=[]
    read=types.ModuleType('assistant.self_operating_read');read.open_owner_read_instance=open_owner;read._OwnerReadInstance=Owner
    dispatch=types.ModuleType('assistant.owned_helper_dispatch');dispatch.dispatch_owned_helper=lambda args:None
    for module in (assistant,read,dispatch):sys.modules[module.__name__]=module
    class Review:
        def __init__(self,*args,**kw):events.append('recorded_review_no_private_read');self.review={}
    class Mutex:
        _server=None
        def release(self):events.append('recorded_mutex_release')
    close=types.ModuleType('assistant.owner_normal_close');close.acquire_owner_instance_lock=lambda instance:Mutex();sys.modules[close.__name__]=close
    def constructor(*args,**kwargs):
        events.append('AppServer_boundary_before_Core_DB_socket_GUI');raise ConstructorBoundary()
    log=types.SimpleNamespace(basicConfig=lambda **kw:events.append('recorded_logging_no_IO'))
    env={'__name__':'owned_ast_app','__file__':str(base/'app.py'),'argparse':argparse,'sys':types.SimpleNamespace(argv=[]),
        'ROOT':base,'Path':Path,'hashlib':hashlib,'json':json,'os':os,'re':re,'stat':stat,'logging':log,
        '_TrustedStartupRuntimeReview':Review,'employee_distribution':types.SimpleNamespace(packaged_workspace=lambda *a,**k:False),
        'private_evaluation_workspace':lambda *a,**k:False,'production_employee_workspace':lambda *a,**k:False,
        'production_natural_workspace':lambda *a,**k:False,'guarded_cli_runtime_valid':lambda *a,**k:True,'AppServer':constructor}
    # Only copied function bytes; no original App import/module initialization/main.
    exec(compile(extracted(APP,['main','source_guarded_cli_selection']),str(OWN/'copied_app_startup_functions.py'),'exec'),env)
    argv=[str(base/'app.py'),'--self-operating-read',str(pilot),'--guarded-cli-runtime',str(runtime),'--runtime-license-review',str(pilot/'component-review.json'),'--runtime-license-review-sha256','0'*64]
    def attempt(source,adapt=False):
        events.clear();env['ROOT']=source;env['sys'].argv=list(argv)
        if adapt:
            tree=extracted(APP,['main','source_guarded_cli_selection'])
            class BindWorkRoot(ast.NodeTransformer):
                def visit_Subscript(self,node):
                    if ast.unparse(node)=='ROOT.parents[1]':return ast.copy_location(ast.Name(id='OWNER_WORK_ROOT',ctx=ast.Load()),node)
                    return self.generic_visit(node)
            tree=ast.fix_missing_locations(BindWorkRoot().visit(tree));env['OWNER_WORK_ROOT']=work
            exec(compile(tree,str(OWN/'candidate_explicit_workroot_functions.py'),'exec'),env)
        try:env['main']()
        except ConstructorBoundary:return 'constructor_boundary',list(events)
        except ValueError:return 'path_closure_refused',list(events)
        raise AssertionError('unexpected startup result')
    status,trace=attempt(base);assert status=='constructor_boundary'
    current={'case':'same_layout_original_argv_parses_to_before_AppServer','status':status,'trace':trace}
    status,trace=attempt(relocated);assert status=='path_closure_refused' and 'AppServer_boundary_before_Core_DB_socket_GUI' not in trace
    relocation={'case':'naive_deeper_immutable_source_deterministically_rejects_original_pilot_before_DB_GUI','status':status,'trace':trace}
    status,trace=attempt(relocated,True);assert status=='constructor_boundary'
    adapted={'case':'explicit_original_WORK_ROOT_for_owner_and_runtime_selection_restores_owned_startup_boundary','status':status,'trace':trace}
    # Copy desktop main, but all original callbacks replaced before calling it.
    notices=[];desktop={'__name__':'owned_desktop_AST','argparse':argparse,'sys':types.SimpleNamespace(argv=['OWNED_ENTRY']),
        'preflight':lambda:{'state':'ready_for_original_native_main','instance_product':'xiaohongshu_v1'},
        'message':notices.append,'LIVE_MESSAGE':'LIVE','HELD_MESSAGE':'HELD',
        'run_original_main':lambda **kw:(_ for _ in ()).throw(ImportError('OWNED_MODULE_IMPORT_SENTINEL'))}
    exec(compile(extracted(ENTRY,['main']),str(OWN/'copied_entry_main.py'),'exec'),desktop)
    assert desktop['main']()==1 and notices==['HELD']
    cases=[current,relocation,adapted,{'case':'desktop_main_collapses_injected_import_error_to_HELD','caught_type':'ImportError','recorded_notice':'HELD'}]
    output={'schema':'owned_synthetic_startup_diagnosis_v1','status':'PASS_LIMITED_OWNED_STARTUP_BOUNDARIES','cases':cases,
        'public_inputs':[{'path':str(p),'pin':pin(p.read_bytes())} for p in (APP,ENTRY,OWNER)],
        'actual':['copied current candidate App.main argparse/branch/control flow through AppServer boundary','copied source_guarded_cli_selection path/ordinary-file checks on OWNED synthetic runtime','copied owner _plain_directory on owned paths','copied entry.main error-collapse control flow'],
        'recorded':['owner marker/check/prepare_data, runtime cryptographic acceptance, trusted review, original lock and AppServer constructor; no real Core/SQLite/server','original run_original_main injected ImportError; no App import/runpy','no pywebview imported or GUI created'],
        'not_proven':['actual user failure root cause','real Python imports/webview availability/WebView2 renderer/argv process','GUI or platform behavior; original business state'],
        'original_App_main_entry_main_preflight_guard_PID_state_DB_GUI_network_calls':0,'production_files_changed':False}
    (OWN/'OWNED-STARTUP-RESULT.json').write_text(json.dumps(output,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'status':output['status'],'cases':len(cases),'original_calls':0}))
if __name__=='__main__':main()
