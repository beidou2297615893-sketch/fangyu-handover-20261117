from pathlib import Path
import ast,argparse,types,json,sys,hashlib
sys.dont_write_bytecode=True
OWN=Path(__file__).resolve().parent
SOURCE=Path('C:/积木软件工坊/项目/方隅公寓客户版/work/desktop-self-use-entry/desktop_entry.py')
def main():
    raw=SOURCE.read_bytes();tree=ast.parse(raw);fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='main')
    messages=[]
    env={'__name__':'owned_entry_error_contract','argparse':argparse,'sys':types.SimpleNamespace(argv=['OWNED_ENTRY']),
        'preflight':lambda:{'state':'ready_for_original_native_main','instance_product':'xiaohongshu_v1'},
        'message':messages.append,'LIVE_MESSAGE':'FIXED_LIVE','HELD_MESSAGE':'FIXED_HELD'}
    exec(compile(ast.Module(body=[fn],type_ignores=[]),str(OWN/'copied_entry_error_contract.py'),'exec'),env)
    results=[]
    for kind in (ImportError,SyntaxError,FileNotFoundError,RuntimeError):
        messages.clear()
        def fail(**kw):raise kind('OWNED_PRIVATE_DETAIL_MUST_NOT_DISPLAY')
        env['run_original_main']=fail
        original=sys.argv;sys.argv=['OWNED_ENTRY']
        try:code=env['main']()
        finally:sys.argv=original
        assert code==1 and messages==['FIXED_HELD']
        results.append({'injected_owned_exception':kind.__name__,'return_code':code,'only_fixed_held_notice':True})
    result={'schema':'owned_desktop_error_collapse_contract_v1','status':'PASS_REPRODUCED_ERROR_OBSERVABILITY_GAP','cases':results,
        'public_source':{'path':str(SOURCE),'pin':{'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest().upper()}},
        'actual':'copied desktop main control flow only','recorded':'preflight,run_original_main,message; no original callbacks','original_calls':0,
        'actual_user_exception_not_observed':True}
    (OWN/'ENTRY-ERROR-CONTRACT.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print(json.dumps({'status':result['status'],'cases':len(results),'original_calls':0}))
if __name__=='__main__':main()
