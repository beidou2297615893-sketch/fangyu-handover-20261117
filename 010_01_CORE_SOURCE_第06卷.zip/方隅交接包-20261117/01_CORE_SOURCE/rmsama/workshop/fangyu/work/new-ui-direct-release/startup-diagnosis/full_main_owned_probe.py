"""Exact release app.main + own OS byte lock/Core/HTTP; GUI/runtime leaves recorded."""
from pathlib import Path
import sys,os,json,hashlib,types,threading,urllib.request,importlib,traceback
sys.dont_write_bytecode=True
OWN=Path(__file__).resolve().parent
PLAN=json.loads((OWN/'FULL-MAIN-INPUTS.json').read_bytes())
PROJECT=Path(PLAN['owned_project']);RELEASE=Path(PLAN['owned_release']);SOURCE=RELEASE/'src';WORK=PROJECT/'work'
allowed=[OWN.resolve(),Path(sys.prefix).resolve(),Path(sys.base_prefix).resolve()]
port=None;blocked=[];events=[];captured={};statuses=[]
def allowed_path(value,write=False):
    if isinstance(value,int):return True
    if not isinstance(value,(str,bytes,os.PathLike)):return False
    s=os.fsdecode(value)
    if s.startswith('file:'):s=s.removeprefix('file:///').split('?',1)[0].replace('/',os.sep)
    p=Path(s).resolve()
    return p.is_relative_to(allowed[0]) if write else any(p.is_relative_to(r) for r in allowed)
def audit(event,args):
    refuse=False
    if event=='open':refuse=not allowed_path(args[0],bool(args[2] & (os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND)))
    elif event=='sqlite3.connect':refuse=not allowed_path(args[0],True)
    elif event in ('os.listdir','os.scandir'):refuse=not allowed_path(args[0])
    elif event in ('os.mkdir','os.remove','os.rmdir','os.rename','os.replace'):refuse=any(not allowed_path(v,True) for v in args[:2] if isinstance(v,(str,bytes,os.PathLike)))
    elif event in ('subprocess.Popen','os.system','os.startfile','webbrowser.open'):refuse=True
    elif event=='socket.bind':refuse=args[1][0]!='127.0.0.1'
    elif event=='socket.connect':refuse=not (args[1][0]=='127.0.0.1' and args[1][1]==port)
    elif event=='socket.getaddrinfo':refuse=args[0] not in ('127.0.0.1',None)
    elif event=='ctypes.dlsym':refuse=str(args[1]) in ('OpenProcess','GetCommandLineW','CryptUnprotectData','MessageBoxW','CreateWindowExW')
    if refuse:blocked.append(event);raise PermissionError('OWNED_BOUNDARY:'+event)
sys.addaudithook(audit)
sys.path.insert(0,str(SOURCE))
result={'schema':'full_release_app_main_owned_v1','interpreter':{'executable':sys.executable,'prefix':sys.prefix,'base_prefix':sys.base_prefix,'version':sys.version.split()[0]},'original_callbacks_App_data_guard_PID_GUI_calls':0,'GUI_created':False}
class OwnedCloseUnconfirmed(Exception):pass
try:
    app=importlib.import_module('app');desktop=importlib.import_module('desktop')
    from assistant.self_operating_read import open_owner_read_instance
    from assistant.owner_normal_close import acquire_owner_instance_lock
    pilot=WORK/'synthetic-pilot';runtime=WORK/'synthetic-cli-runtime'
    wrapper=hashlib.sha256((SOURCE/'platform_cli.py').read_bytes()).hexdigest()
    instance=open_owner_read_instance(str(pilot),str(WORK),wrapper);instance.prepare_data()
    bootstrap=app.Core(pilot/'data',SOURCE/'resources',defer_startup_recovery=True)
    bootstrap.adapters.close()
    runtime.mkdir();(runtime/'platform-cli.exe').write_bytes(b'OWNED_INERT_NEVER_EXECUTED');(runtime/'guard-manifest.json').write_bytes(b'{"owned":true}')
    review=pilot/'component-review.json';review.write_bytes(b'{}')
    class RecordedStartupReview:
        def __init__(self,*args,**kwargs):self.review={};events.append('recorded_startup_review_no_authority')
    app._TrustedStartupRuntimeReview=RecordedStartupReview
    app.guarded_cli_runtime_valid=lambda *args,**kwargs:True
    launcher=types.ModuleType('owned_exact_run_workbench');launcher.__file__=str(OWN/'full-main-owned/run_workbench_owned_bytes.py')
    exec(compile(Path(launcher.__file__).read_bytes(),launcher.__file__,'exec'),launcher.__dict__)
    bindings={'PROJECT':PROJECT,'RELEASE':RELEASE,'SOURCE':SOURCE,'MANIFEST_SHA256':PLAN['owned_manifest_pin']['sha256'],
        'PILOT':pilot,'RUNTIME':runtime,'REVIEW':review,'REVIEW_SHA256':hashlib.sha256(review.read_bytes()).hexdigest().upper(),
        'OWNER_DATA_SHA256':hashlib.sha256((pilot/'data/owner-data-instance.json').read_bytes()).hexdigest().upper(),
        'STATUS_ROOT':PROJECT/'work/owned-launch-status'}
    for name,value in bindings.items():setattr(launcher,name,value)
    assert all(value.is_relative_to(PROJECT) for value in bindings.values() if isinstance(value,Path))
    launcher.notify_failure=lambda stage,error:statuses.append({'stage':stage,'exception_type':type(error).__name__})
    original_event=launcher.write_event
    def event(attempt,name,**facts):
        if name=='native_ready':
            value=original_event(None,name,**facts);assert value is False
            events.append('actual_write_event_failure_returns_false_native_callback_continues');return value
        return original_event(attempt,name,**facts)
    launcher.write_event=event
    def close_retry(code):raise OwnedCloseUnconfirmed(code)
    desktop.request_owner_close_retry=close_retry
    desktop.show_desktop_error=lambda error:statuses.append({'stage':'desktop','exception_type':type(error).__name__})
    def native_stub(server,url,data_dir,title,ready_callback=None,ready_timeout=None):
        global port
        assert sys.modules['app'] is app and type(server) is app.AppServer and Path(app.__file__)==SOURCE/'app.py'
        assert list(sys.argv)[1:]==['--self-operating-read',str(pilot),'--guarded-cli-runtime',str(runtime),'--runtime-license-review',str(review),'--runtime-license-review-sha256',bindings['REVIEW_SHA256']]
        assert server.core.store.directory==pilot/'data' and server.self_operating_instance.directory==pilot
        mutex=server._owner_instance_mutex;captured['mutex']=mutex
        # A real second handle tries the same owned byte under the same main thread.
        try:second=acquire_owner_instance_lock(server.self_operating_instance)
        except OSError:events.append('actual_samebyte_OS_lock_contention_refused')
        else:second.release();raise AssertionError('own main OS lock did not exclude second handle')
        window=types.SimpleNamespace(_workspace_startup_cancelled=False)
        thread=threading.Thread(target=server.serve_forever,kwargs={'poll_interval':.05},daemon=True)
        mutex.bind_desktop(window,thread);mutex.native_creation_submitted(window);thread.start();port=server.server_port
        if ready_callback is not None:ready_callback(window)
        opener=urllib.request.build_opener(urllib.request.ProxyHandler({}));assets=[]
        for route in ('/health','/workspace','/workspace?asset=app.mjs','/workspace?asset=upgrade-ui.css'):
            with opener.open(url.split('/workspace')[0]+route,timeout=4) as response:
                raw=response.read();assert response.status==200 and raw
                assets.append({'route':route,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest().upper()})
        captured['assets']=assets
        events.append('actual_release_main_Core_HTTP_new_assets_and_app_module_identity')
        # GUI lifecycle signals are recorded; resource drain, HTTP join and unlock are actual.
        assert server.close_owned_jobs() is True
        server.shutdown();thread.join(4);assert not thread.is_alive()
        closed=threading.Thread(target=lambda:mutex.native_closed(window))
        closed.start();closed.join(4);assert not closed.is_alive()
        events.append('recorded_GUI_closed_callback_actual_HTTP_jobs_drained')
    desktop.run_desktop=native_stub
    code=launcher.main();assert code==0 and not statuses
    assert captured['mutex']._released and captured['mutex']._file.closed
    reacquired=acquire_owner_instance_lock(instance);reacquired.release()
    events.append('actual_app_finally_normal_close_released_OS_lock_reacquired')
    result.update(status='PASS_LIMITED_REAL_VENV_APP_MAIN_OWNED',launcher_return=code,assets=captured['assets'],normal_main_closed=True,lock_competition_refused=True,lock_reacquired_after_main=True,app_module_identity_preserved=True,native_diagnostic_failure_nonblocking=True)
except Exception as error:
    result.update(status='FULL_MAIN_OWNED_RED',error_type=type(error).__name__,error_text=str(error),traceback=traceback.format_exc(),captured_failures=statuses)
finally:
    result.update(events=events,blocked_events=blocked,
        recorded=['external guarded CLI validation leaf and synthetic {} startup review: no production authority','desktop window creation/readiness/closed signals only; no webview GUI'],
        actual=['Root launcher functions on constants rebound to own project before all calls','release app.main argparse and original owner lock/normal close functions on own marker/SQLite','original AppServer/Core/Store and original owner HTTP transport; no constructor substitutes','new assets HTTP responses and original lock contention/refusal/reacquisition'],
        not_proven=['real WebView2 renderer and visible native GUI','original owner/real data or original runtime review availability','user acceptance and any platform/model/API behavior'])
    (OWN/'FULL-MAIN-RESULT.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'status':result['status'],'error_type':result.get('error_type'),'events':events,'blocked':blocked}))
