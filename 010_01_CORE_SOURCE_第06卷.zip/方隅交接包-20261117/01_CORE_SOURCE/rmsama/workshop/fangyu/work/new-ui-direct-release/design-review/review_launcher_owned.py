"""Independent direct-launcher seams; all App/native/owner operations are owned doubles."""
from pathlib import Path
import hashlib
import json
import sys
import types
import uuid

ROOT = Path(__file__).resolve().parent
CANDIDATE = ROOT.parent / 'root/run_workbench.py'
RAW = CANDIDATE.read_bytes()
PIN = hashlib.sha256(RAW).hexdigest().upper()
OWNED = ROOT / ('owned-launcher-' + uuid.uuid4().hex)
OWNED.mkdir()
RESULTS = []


def module(name):
    m = types.ModuleType('review_' + name)
    exec(compile(RAW, str(CANDIDATE), 'exec'), m.__dict__)
    project = OWNED / name
    project.mkdir()
    m.PROJECT = project
    m.RELEASE = project / 'work/ui-runtime-r55'
    m.SOURCE = m.RELEASE / 'src'
    m.PILOT = project / 'work/pilot'
    m.RUNTIME = project / 'work/runtime'
    m.REVIEW = m.PILOT / 'component-review.json'
    m.STATUS_ROOT = project / 'work/direct/launch-status'
    m.STATUS_ROOT.parent.mkdir(parents=True)
    m.sys = types.SimpleNamespace(path=[], argv=[])
    return m


def passed(name, **facts):
    RESULTS.append({'name': name, 'passed': True, **facts})


def expect_error(action, cls, code):
    try:
        action()
    except cls as e:
        assert e.code == code, (e.code, code)
    else:
        raise AssertionError('Expected rejection ' + code)


def release_fixture(m):
    for subtree in ('src', 'mirrors', 'work/runtime'):
        (m.RELEASE / subtree).mkdir(parents=True)
    files = {'src/app.py': b'# owned app placeholder\n',
             'src/platform_cli.py': b'# owned wrapper\n',
             'src/empty.py': b'', 'mirrors/upgrade-ui.css': b'/* owned */',
             'work/runtime/README.txt': b'owned public runtime placeholder'}
    items = []
    for rel, raw in files.items():
        path = m.RELEASE / rel
        path.write_bytes(raw)
        items.append({'path': rel, 'size': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()})
    manifest = {'schema': 'fangyu_local_code_release_v1', 'release_id': 'ui-core-r55',
                'project': str(m.PROJECT), 'source_root': 'src', 'files': items}
    raw = json.dumps(manifest).encode()
    (m.RELEASE / 'RELEASE.json').write_bytes(raw)
    m.MANIFEST_SHA256 = hashlib.sha256(raw).hexdigest()
    return manifest


m = module('manifest')
manifest = release_fixture(m)
assert m.verify_release() == manifest
assert m.SOURCE.parents[1] == m.PROJECT / 'work'
passed('actual_owned_manifest_accepts_empty_public_file_and_correct_work_root', file_count=len(manifest['files']))
target = m.SOURCE / 'app.py'
saved = target.read_bytes()
target.write_bytes(b'changed')
expect_error(m.verify_release, m.LaunchError, 'HASH')
target.write_bytes(saved)
extra = m.SOURCE / 'unexpected.py'
extra.write_bytes(b'')
expect_error(m.verify_release, m.LaunchError, 'CONTENTS')
extra.unlink()
passed('actual_owned_manifest_rejects_changed_and_unlisted_files')

m = module('owner')
release_fixture(m)
(m.PILOT / 'data').mkdir(parents=True)
(m.PILOT / 'data/workspace.sqlite3').write_bytes(b'NOT A DATABASE; owned metadata-only fixture')
data_marker = json.dumps({'schema': 'owner_read_data_v1', 'instance_id': 'a' * 32}).encode()
(m.PILOT / 'data/owner-data-instance.json').write_bytes(data_marker)
m.OWNER_DATA_SHA256 = hashlib.sha256(data_marker).hexdigest()
m.REVIEW.write_bytes(b'{"owned":true}')
m.REVIEW_SHA256 = hashlib.sha256(m.REVIEW.read_bytes()).hexdigest()
(m.PILOT / 'self-operating-instance.json').write_text('{"schema":"owner_read_instance_v1"}', encoding='utf-8')
calls = []
fake_owner = types.ModuleType('assistant.self_operating_read')
def open_owned(path, root, wrapper, **kwargs):
    calls.append({'path': path, 'root': root, 'wrapper': wrapper, **kwargs})
    return types.SimpleNamespace(check=lambda: {'selfOperatingRead': {'instance_id': 'a' * 32}})
fake_owner.open_owner_read_instance = open_owned
saved_modules = {key: sys.modules.get(key) for key in ('assistant', 'assistant.self_operating_read')}
sys.modules['assistant'] = types.ModuleType('assistant')
sys.modules['assistant'].__path__ = []
sys.modules['assistant.self_operating_read'] = fake_owner
real_checked = m.checked_bytes
def no_database_reads(path, *args, **kwargs):
    assert 'sqlite' not in str(path), 'Database contents must never be read'
    return real_checked(path, *args, **kwargs)
m.checked_bytes = no_database_reads
try:
    assert m.verify_existing_owner() == 'xiaohongshu_v1'
    assert calls[-1]['existing_only'] is True
    assert calls[-1]['product'] == 'xiaohongshu_v1'
finally:
    for key, previous in saved_modules.items():
        if previous is None:
            sys.modules.pop(key, None)
        else:
            sys.modules[key] = previous
passed('owned_owner_binding_uses_existing_only_and_never_reads_database', original_owner_constructor='recorded')


def main_fixture(name, *, original_callback_fails=False, exit_code=None, wrong_app=False, broken_diagnostics=False):
    m = module(name)
    trace = []
    app = types.SimpleNamespace(__file__=str(m.SOURCE / ('wrong.py' if wrong_app else 'app.py')))
    desktop = types.SimpleNamespace(__file__=str(m.SOURCE / 'desktop.py'))
    def original_native(server, url, data_dir, title, ready_callback=None, ready_timeout=None):
        trace.append('native_enter')
        ready_callback(object())
        trace.append('native_return')
    desktop.run_desktop = original_native
    def original_callback(window):
        trace.append('original_ready')
        if original_callback_fails:
            raise RuntimeError('SECRET must not be logged')
    def app_main():
        trace.append('app_main')
        if exit_code is not None:
            raise SystemExit(exit_code)
        desktop.run_desktop(object(), 'owned://no-network', m.PILOT / 'data', 'owned', ready_callback=original_callback)
    app.main = app_main
    def imports(name):
        trace.append('import_' + name)
        return {'app': app, 'desktop': desktop}[name]
    m.importlib = types.SimpleNamespace(import_module=imports)
    m.verify_release = lambda: trace.append('files')
    m.verify_existing_owner = lambda: trace.append('owner') or 'xiaohongshu_v1'
    original_write = m.write_event
    def observed_write(attempt, event, **facts):
        trace.append(event)
        return original_write(attempt, event, **facts)
    m.write_event = observed_write
    m.notify_failure = lambda stage, error: trace.append('notice_' + stage)
    if broken_diagnostics:
        original_plain = m.plain
        def plain(path, **kwargs):
            if path == m.STATUS_ROOT.parent:
                raise PermissionError('owned diagnostics unavailable')
            return original_plain(path, **kwargs)
        m.plain = plain
    return m, trace


m, trace = main_fixture('routing')
assert m.main() == 0
assert trace.count('import_app') == trace.count('import_desktop') == trace.count('app_main') == 1
assert trace.index('original_ready') < trace.index('native_ready') < trace.index('native_return')
assert m.sys.path == [str(m.SOURCE)]
assert m.sys.argv == [str(m.SOURCE / 'app.py'), '--self-operating-read', str(m.PILOT),
                      '--guarded-cli-runtime', str(m.RUNTIME), '--runtime-license-review', str(m.REVIEW),
                      '--runtime-license-review-sha256', m.REVIEW_SHA256]
passed('candidate_main_single_import_fixed_argv_original_ready_then_event', trace=trace,
       app_native='recorded only')

m, trace = main_fixture('ready_reject', original_callback_fails=True)
assert m.main() == 1 and 'native_ready' not in trace and trace[-1] == 'notice_application'
failure = next(m.STATUS_ROOT.glob('*/failed.json')).read_text(encoding='utf-8')
assert 'SECRET' not in failure and 'RuntimeError' in failure
assert json.loads(failure)['stage'] == 'application'
passed('original_ready_rejection_never_claims_native_ready_and_error_is_sanitized', trace=trace)

m, trace = main_fixture('wrong_module', wrong_app=True)
assert m.main() == 1 and 'app_main' not in trace and 'owner' not in trace
assert trace[-1] == 'notice_imports'
passed('wrong_app_origin_rejected_before_owner_or_app', trace=trace)

m, trace = main_fixture('no_diagnostics', broken_diagnostics=True)
assert m.main() == 0 and 'native_return' in trace
assert m.write_event(None, 'test') is False
assert m.write_event(m.PROJECT / 'missing', 'test') is False
passed('diagnostic_directory_and_event_failure_do_not_block_native', trace=trace)

for code in (0, 2):
    m, trace = main_fixture('system_exit_' + str(code), exit_code=code)
    assert m.main() == (0 if code == 0 else 1)
    assert ('notice_application' in trace) is (code != 0)
    if code:
        failure = json.loads(next(m.STATUS_ROOT.glob('*/failed.json')).read_text(encoding='utf-8'))
        assert failure['exception_type'] == 'SystemExit' and failure['stage'] == 'application'
    passed('system_exit_' + str(code) + '_classified', trace=trace)

assert hashlib.sha256(CANDIDATE.read_bytes()).hexdigest().upper() == PIN, 'Candidate changed during independent tests'
report = {'schema': 'direct_launcher_independent_owned_review_v1', 'candidate': str(CANDIDATE),
          'candidate_bytes': len(RAW), 'candidate_sha256': PIN, 'owned_root': str(OWNED),
          'cases': RESULTS, 'passed': True,
          'limits': {'original_app_calls': 0, 'original_guard_pid_calls': 0,
                     'real_database_reads': 0, 'native_gui_calls': 0,
                     'app_native_owner_calls': 'recorded doubles; not production verification'}}
out = ROOT / ('LAUNCHER-OWNED-' + PIN[:8] + '.json')
out.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'passed': True, 'cases': len(RESULTS), 'candidate_sha256': PIN, 'report': str(out)}, ensure_ascii=False))
