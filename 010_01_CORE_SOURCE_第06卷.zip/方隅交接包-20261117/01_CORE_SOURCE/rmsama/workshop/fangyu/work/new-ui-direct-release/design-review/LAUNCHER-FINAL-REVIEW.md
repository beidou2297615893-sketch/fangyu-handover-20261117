# 新直启入口：最终限定源码审查

结论：**PASS_LIMITED；未发现新的 P1/P2 打开阻断问题。** 审查对象为 Root 候选 `root/run_workbench.py`，10192 bytes / `F674EBFA031019169CD0441B5066E7B4A2DDAE8774269C171B3E846A2516A3C5`。未修改候选源码。

绑定的 `work/ui-runtime-r55/RELEASE.json` 为 598108 bytes / `E4E33FDA9699EB610F7E092A2F23C4A39AD3AB2F8505895BB194BD9D09606CF5`，853 项公开文件。本次核实 manifest 本身与入口 pin 一致；完整发布来源/全文件实际读回由 Root 的发布审查承担，本报告不冒充已独立逐项读回 853 文件。

静态全读确认：

- 入口没有 WMI、PID dead 缓存、50–55 更新调用、旧 raw/backup 写入或旧版本自动 fallback；入口自身的写入仅独立 attempt 诊断。正常 App 后续的数据读写仍是原 App 行为。
- manifest 读前/打开句柄/读后身份与字节核对、完整文件集合匹配、拒绝重定向与多硬链接，允许合法零字节公开文件；每次启动执行验证。
- `work/ui-runtime-r55/src` 保持 `app.ROOT.parents[1] == PROJECT/work`。在业务导入前设置新 src；app 与 desktop 各一次命名导入，并核实来源文件。原 app 在 main 内动态导入 desktop.run_desktop，所以本入口 hook 可达且没有第二份 app 模块。
- 原 pilot/data、data marker、DB 路径、review 要求存在；DB 仅 stat。原 owner 构造器使用 existing_only=True，数据 marker 的 instance_id 必须与原配置一致。原 app.py 未改：128213 / `BA6C6FABD8C3544713F52AC9806E4F857EAB964BCAF3F0799EBFBB3C80F3854C`。
- 原 desktop.py 8854 / `3747B0F2CD3AD13172AB49F86A4077F861E7A2FC5BE456C62A6679ADC5A0CE37` 与原 owner_normal_close.py 34848 / `C148ECA142B8374F7D47A43ED1B124D77066FD35108DAC4D635288058B5493FB` 在新旧公开源中分别相同。没有额外外层实例锁；正常 App 仍只获取原 pilot/data/instance.lock，保原 owner 账号/risk/source_id 权限与收尾行为。
- 固定 argv 只指原 owner/runtime/review，不接受外部恢复/升级参数；仅已存在的 v2 marker 才保持原 primary-platforms 参数，不进行自动升级。
- 原 ready_callback 先执行；它失败时不写 native_ready。原 desktop 的 renderer/navigation guard 先于 callback；独立日志失败被吞掉，不影响窗口。日志包含 phase、exception type、相对 trace location，不写异常消息或局部变量。SystemExit 0/None 正常退出，非零固定失败阶段。

实际独立 owned 验证由 `review_launcher_owned.py` 执行，工具 `29e36c` exit 0，9 组通过：完整性接受及改动/额外文件拒绝、owner existing-only 与 DB 禁读、单模块与固定 argv、原 ready 顺序及失败、错误模块早拒、诊断失败不阻窗、SystemExit 0/2。实际执行的是候选入口与 owned 文件校验；App/native/owner 构造器是 recorded doubles。结果 `LAUNCHER-OWNED-F674EBFA.json` 3491 / `196BD95F4F15D9921474C1EC1E4742D111AA5115DEB50371F07D42E3619689FB`。

发布需把快捷方式参数 `-X utf8 -B -I` 一并固定并读回。尤其缺少 -B 时，新 src 可能生成 __pycache__，下次会被严格文件集合拒绝；这由安装参数确保，不能在本源码审查中冒称快捷方式已生效。

保留设计审查中的范围限制：前检不是对外部并发移走整个 data 目录的原子保证；native_ready 是原生加载阶段证据，不是用户视觉/操作认可或真实平台/模型成功。0 原 App、原 guard/PID/preflight/check-only/installer、CUA、真实 DB/会话内容调用；不重旧 pending fallback QA。
