# 2026-10-15 最新：完整新版已独立安装，桌面已改为新版直接入口（真实窗口未代开）

用户明确要求“要新UI，不要再开旧版；桌面仍打不开”。本次已实际完成本地新版接回，不能再按下方旧“55更新待下一开/只开旧53”推进。当前桌面代码根为 C:/积木软件工坊/项目/方隅公寓客户版/work/ui-runtime-r55/src；当前启动器为同版本目录 run_workbench.py。后续改动须先识别此真正桌面入口，不能再把 work/app/src 或 D19D/3CCA 旧launcher当当前桌面运行代码。

原55已审8个本地payload（新版UI A02D/962D、app BA6C、workspace5D65、关键词/CSV/按客户归并等）装入独立完整版本：752源码资源 + 100公开runtime + 1配套云CSS = 853项，RELEASE.json598108/E4E33FDA9699EB610F7E092A2F23C4A39AD3AB2F8505895BB194BD9D09606CF5。云CSS仅本地companion，不是云部署。新入口10192/F674EBFA031019169CD0441B5066E7B4A2DDAE8774269C171B3E846A2516A3C5，每次验证本版文件后单一 import app; app.main，不调用50–55更新链/WMI全机动态进程扫描/旧版fallback，不伪unknown为idle。原shared SOURCE/55原raw/所有旧backup与D19D3CCA均保留；旧source55 CAS apply仍未由Root执行，不能写伪joined。此为独立版本安装。

同深度 work/<version>/src 保原work根；原pilot数据路径、marker、review和XHS runtime路径不变。正常App仍原单实例OS锁、账号与risk权限、source_id和收尾代码，无自动升级三平台。实际安装0db767 exit0，ACTUAL-DESKTOP-INSTALLED.json2581/FD63A27DF71368EE3D1E748BAA2B7A1BBC69ABA8C922341856375AF729AF7382。桌面唯一“方隅工作台.lnk”2263/67CBF1DDDBCE956CD38E3B411E20CBE45C0F371C16DCDE7C92D7693FE07198F9，固定原venv pythonw与-X utf8 -B -I，新args指ui-runtime-r55/run_workbench.py；原lnk2341/F6B9原字节在 work/new-ui-direct-release/desktop-backup/695aee016bd4409ca61995ed21edeeb1/original.lnk。

必要新验证：Root35f381实际853校验+同venv import webview零窗口；a8366f新代码对原owner metadata/runtime public bytes/review只读绑定PASS、0DB。作者1b00e8同款venv3.11.15完整owned app.main→真实Core/SQLite/HTTP→原OS锁竞争拒/正常close释放/再取锁PASS，新MJS/CSS响应exact；GUI与许可leaf明确recorded，不冒真实窗口。新入口独审825B/9owned，installer独审CBA8/4owned并发保护PASS。原installer晚期hash/身份缝已修35C6，最初fixture期待旧RED但实际加载已修版仅fixture失配，未冒生产失败。Root接受与实际读回见 work/new-ui-direct-release/ROOT-CODE-ACCEPTED.json、ROOT-ACTUAL-INSTALL-ACCEPTED.json；首原始记录保留。

此前确定的问题是全机dynamic解释器unknown阻止共享源码更新、旧入口把各种启动异常吞为等待；未捕获用户原异常，不冒已确定具体WebView故障。新入口失败会保存固定阶段/异常类别/脱敏代码位置，原native loaded通过后才写native_ready；诊断写失败不阻窗口。launch-status/<attempt>/仅本版本产生的正常打开事件，native_ready不是UI精确认可/真实平台/模型成功。

非作者实际桌面读回 eb0158 已通过，报告9098/F37327D3A92AC63F7040E7C09652AE9051DCF8ED1522DA277DD612511137A553；Root590619全文读并以8c8cd9保存 ROOT-ACTUAL-INSTALL-ACCEPTED.json2225/EA54CE102223EA5043295BA464CCD5379969252968CD8D7BD0139D923A435909。真实COM字段/新lnk/原lnk备份/new launcher/manifest/8payload及原D19D3CCA和55原raw保持已核，未重做853或新GUI。

用户随后表示当前UI与之前生成原图差距大，明确要求“找原图”和启动修复分开，不打断任务。图片查找是独立只读并行事项，不能因技术安装完成宣称视觉获认可，也不能未经定位就改已安装包。原始设计图定位后需展示；当前没有新的确切打开成功/失败阶段或GUI验收证据。

本批实际本地安装完成；下一次正常点桌面同一图标将直接加载已安装的新UI，不再等待旧55切换，无需重启。Root全程0ComputerUse/截图绕行/原App控制/原数据库CookieVaultAPIkey读取复制hash/平台模型发送/打包部署付费，未替用户开窗，不能宣称真实GUI已显示、账号/模型整链或R01–R25验收。保所有原数据/记录，不强停、不清原号、不自动retry/reapply。

本任务作者和必要审查结束后，不重派旧55/UI/入口QA；只有新的真实打开成功/失败或人类新任务才必要读取本次独立launch event或定点修复，不轮询不变旧guard/PID/state/metadata/receipts/installer。无变化安静，关键成果/失败/必需动作才通知。goal不create替代、不伪active/complete；automation原ACTIVE/5分钟/name/target保持。完整长期目标及初版二版/三平台先XHS/真实账号模型/资源部与第二实体机/SDK/KMS/商业R01–R25均仍按原目标逐项验收。

以下为保留历史，与上文冲突时以上述实际新版直接入口为准。

