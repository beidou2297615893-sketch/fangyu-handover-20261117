from pathlib import Path
import os
RELEASE=Path('C:\\积木软件工坊\\项目\\方隅公寓客户版\\work\\new-ui-direct-release\\release-plan\\shortcut-review\\owned\\fixed-390ed2b200b344b9b7b95d3d00d8bafa\\same_pin_foreign_shortcut\\project\\work\\ui-runtime-r55')
MANIFEST_SHA256="owned-recorded"
_calls=0
def verify_release():
 global _calls
 _calls+=1
 if _calls==2:
  p=Path('C:\\积木软件工坊\\项目\\方隅公寓客户版\\work\\new-ui-direct-release\\release-plan\\shortcut-review\\owned\\fixed-390ed2b200b344b9b7b95d3d00d8bafa\\same_pin_foreign_shortcut\\desktop\\Workbench.lnk'); q=p.with_suffix(".foreign"); q.write_bytes(p.read_bytes()); os.replace(q,p)
