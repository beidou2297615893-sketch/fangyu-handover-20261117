from pathlib import Path
import json,hashlib
OWN=Path(__file__).resolve().parent;SOURCE=Path('C:/积木软件工坊/项目/方隅公寓客户版/work/ui-runtime-r55')
def pin(b):return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest().upper()}
def main():
    raw=(SOURCE/'RELEASE.json').read_bytes();assert pin(raw)=={'bytes':598108,'sha256':'E4E33FDA9699EB610F7E092A2F23C4A39AD3AB2F8505895BB194BD9D09606CF5'}
    d=json.loads(raw);assert len(d['files'])==853
    project=OWN/'full-main-owned/project';dest=project/'work/ui-runtime-r55';dest.mkdir(parents=True,exist_ok=False)
    for row in d['files']:
        rel=Path(row['path']);assert not rel.is_absolute() and '..' not in rel.parts
        b=(SOURCE/rel).read_bytes();assert len(b)==row['size'] and hashlib.sha256(b).hexdigest()==row['sha256']
        p=dest/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
    d['project']=str(project);local=(json.dumps(d,ensure_ascii=False,indent=2)+'\n').encode('utf-8');(dest/'RELEASE.json').write_bytes(local)
    launcher=Path('C:/积木软件工坊/项目/方隅公寓客户版/work/new-ui-direct-release/root/run_workbench.py')
    lr=launcher.read_bytes();(OWN/'full-main-owned/run_workbench_owned_bytes.py').write_bytes(lr)
    plan={'schema':'full_main_owned_exact_release_clone_v1','public_release':{'path':str(SOURCE),'manifest_pin':pin(raw),'files':853},'owned_project':str(project),'owned_release':str(dest),'owned_manifest_pin':pin(local),'launcher_public':{'path':str(launcher),'pin':pin(lr)},'launcher_original_functions_changed':False,'owned_constants_rebound_before_calls':True,'data_copied':False}
    (OWN/'FULL-MAIN-INPUTS.json').write_text(json.dumps(plan,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'copied_public_files':853,'data_copied':False,'owned_manifest_pin':pin(local)}))
if __name__=='__main__':main()
