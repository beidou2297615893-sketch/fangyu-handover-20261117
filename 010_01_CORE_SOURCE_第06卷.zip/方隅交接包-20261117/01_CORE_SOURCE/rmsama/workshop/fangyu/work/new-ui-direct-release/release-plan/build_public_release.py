"""Root-run fixed public code assembly. No original App/data/process operations."""
from pathlib import Path
import datetime,hashlib,json,os,stat

PROJECT=Path('C:/积木软件工坊/项目/方隅公寓客户版')
OWN=PROJECT/'work/new-ui-direct-release/release-plan'
DEST=PROJECT/'work/ui-runtime-r55'
PLAN=OWN/'PUBLIC-RELEASE-MANIFEST-DESIGN.json'
PLAN_PIN={'bytes':748303,'sha256':'AA86F33234D938509D4965ECA40F266EE7972D3A1696DE9AFB698B1EE9D1F637'}
SRC=PROJECT/'work/app/src'
PAYLOAD=PROJECT/'work/ui-core-completion/source'
RUNTIME=PROJECT/'work/app/work/runtime'

def pin(raw):return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest().upper()}
def plain(path,directory=False):
    path=Path(path)
    path.relative_to(PROJECT)
    if '..' in path.parts:raise ValueError('parent traversal refused')
    for q in (path,*path.parents):
        st=q.lstat()
        if q.is_symlink() or getattr(st,'st_file_attributes',0)&0x400:raise ValueError('redirected path refused')
    st=path.lstat()
    if not (stat.S_ISDIR(st.st_mode) if directory else stat.S_ISREG(st.st_mode)) or (not directory and st.st_nlink!=1):raise ValueError('ordinary path required')
    return st
def stable_read(path,expected):
    before=plain(path)
    with Path(path).open('rb') as stream:
        opened=os.fstat(stream.fileno())
        if (opened.st_dev,opened.st_ino)!=(before.st_dev,before.st_ino):raise ValueError('source replaced while opening')
        raw=stream.read();after_fd=os.fstat(stream.fileno())
    after=plain(path)
    sample=lambda s:(s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns)
    if sample(before)!=sample(opened) or sample(opened)!=sample(after_fd) or sample(after_fd)!=sample(after):raise ValueError('source changed while reading')
    if pin(raw)!=expected:raise ValueError('fixed public source pin changed: '+str(path))
    return raw
def write_json_exclusive(path,value):
    with path.open('x',encoding='utf-8',newline='\n') as f:
        json.dump(value,f,ensure_ascii=False,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
def main():
    if os.path.lexists(DEST):raise ValueError('fixed new release directory exists; no retry or overwrite')
    plan=json.loads(stable_read(PLAN,PLAN_PIN))
    if plan['schema']!='new_ui_direct_public_manifest_design_v1':raise ValueError('fixed reviewed public plan required')
    if (plan['summary']['public_src_files_after'],plan['summary']['runtime_declared_files'],plan['summary']['cloud_mirror_files'])!=(752,100,1):raise ValueError('fixed public scope changed')
    rows=plan['copy_app_src']+plan['copy_declared_public_runtime']+plan['copy_optional_mirror']
    names=set();sources=set()
    for row in rows:
        rel=Path(row['release_relative']);source=Path(row['source'])
        if rel.is_absolute() or '..' in rel.parts or not rel.parts or ':' in row['release_relative'] or '\\' in row['release_relative']:raise ValueError('release relative path required')
        if row['release_relative'] in names:raise ValueError('duplicate release destination')
        names.add(row['release_relative']);sources.add(str(source))
        if not any(source.is_relative_to(root) for root in (SRC,PAYLOAD,RUNTIME)):raise ValueError('source outside fixed public allowlist')
        if not (rel.parts[0]=='src' or rel.parts[:2]==('work','runtime') or rel.parts[:3]==('mirrors','cloud','workspace')):raise ValueError('unexpected release subtree')
        stable_read(source,row['pin'])
    if len(rows)!=853 or len(names)!=853:raise ValueError('fixed 853 public file map required')
    plain(DEST.parent,True)
    if os.path.lexists(DEST):raise ValueError('new release appeared; preserve')
    DEST.mkdir()  # Deliberately exclusive; never reset, merge, replace, or remove.
    plain(DEST,True);root_info=DEST.stat();root_identity=(root_info.st_dev,root_info.st_ino)
    copied=[]
    try:
        for row in rows:
            source=Path(row['source']);target=DEST/row['release_relative']
            if (DEST.stat().st_dev,DEST.stat().st_ino)!=root_identity:raise ValueError('release owner changed')
            raw=stable_read(source,row['pin'])
            target.parent.mkdir(parents=True,exist_ok=True);plain(target.parent,True)
            with target.open('xb') as stream:
                stream.write(raw);stream.flush();os.fsync(stream.fileno())
            stable_read(target,row['pin'])
            # A second source observation is stat-only; byte hashes already bound
            # the same stable source read immediately before this exclusive write.
            copied.append({'path':row['release_relative'],'sha256':row['pin']['sha256'].lower(),'size':row['pin']['bytes'],'source':str(source),'source_sha256':row['pin']['sha256'].lower(),'source_size':row['pin']['bytes'],'origin':row['origin']})
        for row in rows:
            stable_read(Path(row['source']),row['pin']);stable_read(DEST/row['release_relative'],row['pin'])
        manifest={'schema':'fangyu_local_code_release_v1','release_id':'ui-core-r55','project':str(PROJECT),'source_root':'src','created_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'files':copied,'public_plan':{'path':str(PLAN),'pin':PLAN_PIN},'prepared':plan['prepared'],'authority':plan['authority'],'payloads':[r for r in copied if r['origin'].startswith('source55_')],'public_dependencies':{'source55_direct_count':13,'all13_in_src':True,'runtime_files':100,'runtime_relative_root':'work/runtime','existing_guarded_cli_path':str(PROJECT/'work/product-upgrade-20261009/cli-current-wrapper-component-candidate-v6/artifacts/platform-cli-guarded')},'excluded':plan['never_copy_original_metadata'],'external_public_references':plan['external_public_references'],'runtime_data_policy':{'owner_instance_path':str(PROJECT/'work/self-operating-pilot'),'owner_work_root':str(PROJECT/'work'),'copy_private_data':False,'mutate_original_source':False,'mutate_original_receipts':False,'original55_apply_called':False,'original_App_started':False},'validation':{'assembly_and_all_file_pin_readback':True,'GUI_verified':False,'real_platform_model_verified':False}}
        write_json_exclusive(DEST/'RELEASE.json',manifest)
        receipt={'schema':'fangyu_public_release_assembly_v1','status':'ASSEMBLED_PUBLIC_FILES_ONLY','release_root':str(DEST),'manifest':{'path':str(DEST/'RELEASE.json'),'pin':pin((DEST/'RELEASE.json').read_bytes())},'files':len(copied),'src_files':752,'runtime_files':100,'companion_files':1,'original_private_data_reads':0,'original_source_mutations':0,'original_App_guard_PID_preflight_calls':0,'original_business_apply_calls':0}
        write_json_exclusive(OWN/'ACTUAL-ASSEMBLY.json',receipt)
        print(json.dumps(receipt,ensure_ascii=False))
    except BaseException as exc:
        if (DEST.stat().st_dev,DEST.stat().st_ino)==root_identity:
            write_json_exclusive(DEST/'ASSEMBLY-FAILED.json',{'schema':'fangyu_public_release_failed_v1','failure_type':type(exc).__name__,'files_copied':len(copied),'automatic_retry':False,'partial_directory_preserved':True})
        raise
if __name__=='__main__':main()
