"""Read approved public code/materials; write a plan only, never copy private data."""
from pathlib import Path
from collections import Counter
import ast,hashlib,json,os,stat,sys
P=Path('C:/积木软件工坊/项目/方隅公寓客户版')
O=P/'work/new-ui-direct-release/release-plan'
S=P/'work/app/src'
R=P/'work/new-ui-direct-release'
PREP=P/'work/ui-core-completion/release/PREPARED.json'
AUTH=P/'work/ui-core-completion/release/AUTHORITY-PROPOSAL.json'
def pin(raw):return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest().upper()}
def ordinary(path):
    for q in (path,*path.parents):
        st=q.lstat()
        if q.is_symlink() or getattr(st,'st_file_attributes',0)&0x400:raise ValueError('redirected path: '+str(q))
    st=path.lstat()
    if not stat.S_ISREG(st.st_mode) or st.st_nlink!=1:raise ValueError('not ordinary file: '+str(path))
def read_public(path):ordinary(path);return path.read_bytes()
prepared_raw=read_public(PREP);authority_raw=read_public(AUTH)
assert pin(prepared_raw)=={'bytes':177596,'sha256':'511579149EB690B94779D2A9ECD42C32826AD5FB95C5F8C3392523621906700F'}
assert pin(authority_raw)=={'bytes':166698,'sha256':'6E7077095534E91E320D1F28BC656FE16E52A2C6F9C8A3867D59F956AE53728B'}
d=json.loads(prepared_raw);a=json.loads(authority_raw)
assert (len(d['targets']),len(d['protected']),len(d['candidate_dependencies']))==(9,472,13)
assert a['targets']==[{'path':r['target'],'parent_pin':r['parent'],'final_pin':r['candidate_pin']} for r in d['targets']]
assert a['protected']==d['protected']
known={str(Path(r['path'])):r['pin'] for r in d['protected']}
deps={str(Path(r['path'])):r['pin'] for r in d['candidate_dependencies']}
overlay={str(Path(r['target'])):r for r in d['targets']}
allowed_suffixes={'.py','.ico','.html','.cjs','.ps1','.js','.LICENSE','.json','.svg','.txt','.csv','.toml','.md','.PSF','.ncurses','.markdown-it','.0','.APACHE','.BSD','.rst','.css','.png','.mjs','.webp',''}
allowed_dirs={'assistant','core','resources','web','xlsxwriter','xlsxwriter-3.2.9.dist-info','_vendor_export'}
inventory=[];rejected=[];contents={};pathset=set()
for file in sorted(S.rglob('*')):
    if not file.is_file():continue
    rel=file.relative_to(S)
    if '__pycache__' in rel.parts or file.suffix=='.pyc':continue
    if len(rel.parts)>1 and rel.parts[0] not in allowed_dirs:raise ValueError('unlisted source folder: '+str(rel))
    if len(rel.parts)==1 and file.suffix!='.py':raise ValueError('unlisted source root resource: '+str(rel))
    if file.suffix not in allowed_suffixes or any(part.lower() in {'data','vault','cookies','sessions','profiles','.env'} for part in rel.parts):
        rejected.append(str(rel));continue
    current_raw=read_public(file);current_pin=pin(current_raw)
    expected=known.get(str(file)) or deps.get(str(file))
    if expected is not None and current_pin!=expected:raise ValueError('approved public predecessor changed: '+str(rel))
    row=overlay.get(str(file));source=Path(row['candidate']) if row else file
    raw=read_public(source) if row else current_raw;p=pin(raw)
    if row and p!=row['candidate_pin']:raise ValueError('approved payload changed: '+str(rel))
    inventory.append({'source':str(source),'release_relative':('src/'+rel.as_posix()),'pin':p,'origin':'source55_payload' if row else 'approved_protected' if str(file) in known else 'approved_direct_dependency' if str(file) in deps else 'additional_public_source','original_source':str(file),'original_source_pin':current_pin})
    pathset.add(str(file));contents[rel.as_posix()]=raw
for target,row in overlay.items():
    t=Path(target)
    if t.is_relative_to(S) and target not in pathset:
        assert row['parent'] is None
        raw=read_public(Path(row['candidate']));assert pin(raw)==row['candidate_pin']
        rel=t.relative_to(S).as_posix();contents[rel]=raw
        inventory.append({'source':row['candidate'],'release_relative':'src/'+rel,'pin':row['candidate_pin'],'origin':'source55_payload_new','original_source':target,'original_source_pin':None})
assert not rejected
runtime=[];references=[];excluded=[];mirrors=[]
runtime_root=P/'work/app/work/runtime'
for row in d['protected']:
    p=Path(row['path'])
    if p.is_relative_to(S):continue
    if p.is_relative_to(runtime_root):
        runtime.append({'source':str(p),'release_relative':'work/runtime/'+p.relative_to(runtime_root).as_posix(),'pin':row['pin'],'origin':'approved_runtime_material'})
    elif p.is_relative_to(P/'work/self-operating-pilot'):
        excluded.append({'source':str(p),'release_relative':None,'reason':'Original instance-local metadata; retain fixed original path, never copy into release. Existing approved pin is provenance only; not read by this plan.','approved_metadata_pin':row['pin']})
    elif p==P/'work/desktop-self-use-entry/desktop_entry.py':
        excluded.append({'source':str(p),'release_relative':None,'reason':'Historical entry must not become the new release entry. Preserve original file and receipts.','approved_metadata_pin':row['pin']})
    else:
        references.append({'source':str(p),'release_relative':None,'pin':row['pin'],'reason':'Existing approved public auxiliary/cloud/CLI material; not an app/src copy. Guarded CLI continues at exact original selected path.'})
for row in d['targets']:
    if not Path(row['target']).is_relative_to(S):
        raw=read_public(Path(row['candidate']));assert pin(raw)==row['candidate_pin']
        mirrors.append({'source':row['candidate'],'release_relative':'mirrors/cloud/workspace/site/upgrade-ui.css','pin':row['candidate_pin'],'original_source':row['target'],'origin':'source55_cloud_mirror_no_cloud_deploy'})
# Static import discovery covers import edges only; no module import or execution.
modules={k[:-3].replace('/','.'):(k) for k in contents if k.endswith('.py')}
for name,k in list(modules.items()):
    if name.endswith('.__init__'):modules[name[:-9]]=k
missing=[];edge_count=0
for rel,raw in contents.items():
    if not rel.endswith('.py'):continue
    tree=ast.parse(raw,filename=rel)
    package=rel[:-3].replace('/','.').split('.')[:-1]
    for n in ast.walk(tree):
        names=[]
        if isinstance(n,ast.Import):names=[x.name for x in n.names]
        elif isinstance(n,ast.ImportFrom):
            prefix=package[:len(package)-n.level+1] if n.level else []
            module='.'.join(prefix+([n.module] if n.module else []))
            names=[module] if module else []
            for x in n.names:
                if x.name!='*':names.append((module+'.' if module else '')+x.name)
        for name in names:
            top=name.split('.')[0]
            if name in modules:edge_count+=1
            elif top in modules and '.' in name:
                # Could be imported symbol, so absence is not reported as a module error.
                pass
            elif top in ('core','assistant'):
                missing.append({'file':rel,'line':n.lineno,'import':name,'reason':'Potential local module or symbol; static inspection required'})
covered={r['original_source']:r['pin'] for r in inventory}
assert all(covered[p]==proof for p,proof in deps.items())
summary={'public_src_files_before':len(pathset),'public_src_files_after':len(inventory),'src_bytes':sum(r['pin']['bytes'] for r in inventory),'runtime_declared_files':len(runtime),'runtime_declared_bytes':sum(r['pin']['bytes'] for r in runtime),'external_public_reference_files':len(references),'excluded_original_metadata_or_entry':len(excluded),'cloud_mirror_files':len(mirrors),'payloads':9,'protected':472,'direct_dependencies':13,'all13_dependencies_covered':True,'source_origin_counts':dict(Counter(r['origin'] for r in inventory)),'local_import_edges_resolved':edge_count,'potential_unresolved_imports':missing}
plan={'schema':'new_ui_direct_public_manifest_design_v1','status':'READ_ONLY_DESIGN_NOT_ASSEMBLED_NOT_LAUNCHED','release_root':str(R),'layout_constraint':'release_root must be PROJECT/work/<one-directory-name>; src must be its direct child. Then app.ROOT.parents[1] stays original PROJECT/work and assistant original PROJECT derivation stays correct.','prepared':{'path':str(PREP),'pin':pin(prepared_raw)},'authority':{'path':str(AUTH),'pin':pin(authority_raw)},'summary':summary,'copy_app_src':inventory,'copy_declared_public_runtime':runtime,'copy_optional_mirror':mirrors,'external_public_references':references,'never_copy_original_metadata':excluded,'copy_policy':'Copy only exact manifest rows using ordinary-file validation, reject unexpected paths/reparse/hardlinks; compare source read bytes to fixed pin and post-copy bytes to same pin. Do not glob-copy any original data directory or root work tree. Runtime rows are copied only after fixed pin validation; plan does not hash runtime binaries again.','validation_limit':'Static read/hash/AST only; zero original App/wrapper/preflight/guard/PID/platform/data calls; not installed or GUI verified.'}
O.mkdir(parents=True,exist_ok=True)
out=O/'PUBLIC-RELEASE-MANIFEST-DESIGN.json'
with out.open('x',encoding='utf-8',newline='\n') as f:json.dump(plan,f,ensure_ascii=False,indent=2);f.write('\n')
print(json.dumps({'path':str(out),'pin':pin(out.read_bytes()),'summary':summary},ensure_ascii=False))
