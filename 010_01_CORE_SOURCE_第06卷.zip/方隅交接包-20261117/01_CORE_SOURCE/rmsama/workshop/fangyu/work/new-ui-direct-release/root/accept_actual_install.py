from pathlib import Path
import json, hashlib, datetime, uuid
p=Path("C:/积木软件工坊/项目/方隅公寓客户版")
w=p/"work/new-ui-direct-release"
expected=[
("ACTUAL-DESKTOP-INSTALLED.json",2581,"FD63A27DF71368EE3D1E748BAA2B7A1BBC69ABA8C922341856375AF729AF7382"),
("release-plan/shortcut-review/ACTUAL-DESKTOP-READBACK.json",9098,"F37327D3A92AC63F7040E7C09652AE9051DCF8ED1522DA277DD612511137A553"),
("release-plan/shortcut-review/SHORTCUT-INSTALLER-REVIEW.json",4333,"CBA88395F6C528EAF1CDC56D1E55F8D6926BFBC02F3265C7BC0CF5E90B3922C9"),
("ROOT-CODE-ACCEPTED.json",2692,"804A519D768E9B43B228F2AC7C27F378AE483E37E8C2E96946D4ED2F1E0185CE")]
records=[]
for rel,n,digest in expected:
    q=w/rel
    b=q.read_bytes()
    assert len(b)==n and hashlib.sha256(b).hexdigest().upper()==digest,rel
    records.append(dict(path=str(q),bytes=n,sha256=digest))
target=w/"ROOT-ACTUAL-INSTALL-ACCEPTED.json"
record=dict(schema="root_independent_new_ui_actual_install_acceptance_v1",accepted_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),status="ACCEPTED_LOCAL_INSTALL_AND_INDEPENDENT_READBACK",records=records,actual_install_tool="0db767",independent_actual_readback_tool="eb0158",root_full_readback_tool="590619",desktop_entry="C:/Users/rmsama/Desktop/方隅工作台.lnk",current_launcher=str(p/"work/ui-runtime-r55/run_workbench.py"),current_code_root=str(p/"work/ui-runtime-r55/src"),original_source55_cas_called=False,original_private_data_read_or_copied=False,actual_App_started=False,actual_new_GUI_verified=False,real_platform_model_verified=False,full_R01_R25_accepted=False,limitations=["Same-venv owned full app.main/HTTP/SQLite/OS lock passed; GUI leaves recorded.","Actual desktop target, backup and new release pins independently verified.","No claim that actual new native window or real account/model flow has been verified."])
with target.open("x",encoding="utf-8") as f:
    json.dump(record,f,ensure_ascii=False,indent=2)
b=target.read_bytes()
print(json.dumps(dict(path=str(target),bytes=len(b),sha256=hashlib.sha256(b).hexdigest()),ensure_ascii=False))

