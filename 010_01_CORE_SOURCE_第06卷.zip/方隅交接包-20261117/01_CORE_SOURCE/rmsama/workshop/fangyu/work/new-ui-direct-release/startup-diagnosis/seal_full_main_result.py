from pathlib import Path
import json,hashlib
OWN=Path(__file__).resolve().parent
def pin(b):return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest().upper()}
def main():
    result=json.loads((OWN/'FULL-MAIN-RESULT.json').read_bytes());assert result['status']=='PASS_LIMITED_REAL_VENV_APP_MAIN_OWNED' and not result['blocked_events']
    inputs=json.loads((OWN/'FULL-MAIN-INPUTS.json').read_bytes())
    report='''唯一新增完整启动代表1b00e8：使用实际桌面venv C:/积木软件工坊/项目/方隅公寓客户版/work/desktop-python/Scripts/python.exe -X utf8 -B -I，CPython3.11.15。853件public release逐件核RELEASE598108/E4E33FDA原pin后全部复制至自有full-main-owned/project/work/ui-runtime-r55（保持work/<version>/src同深度）。不复制任何原owner数据。Root launcher保持公开源函数字节，仅所有PROJECT/SOURCE/PILOT/RUNTIME/REVIEW/status/manifest pins在任何调用前重定址到owned synthetic project；manifest仅project字段own重绑定，业务源码853字节不变。

真实执行Root launcher→单一import app→app.main，原argv解析、自有synthetic marker/owner实例校验、原OS existing byte lock、原AppServer/Core/Store/SQLite与原owner HTTP worker运输、原normalclose finally与锁释放均实际。没有AppServer/Core构造替身，也没有把原close资源验收替换为True。desktop接缝中第二句柄真实调用同一acquire_owner_instance_lock，被实际OS锁OSError拒绝；main正常返回后原mutex已released且file关闭，同一owner instance可再真实acquire/release。实例是owned新v1/xiaohongshu_v1 synthetic分支，不冒原owner/v2升级真实联跑。

GUI创建、readiness/closed事件为显式运输替身：在own desktop seam用真实mutex.bind_desktop/native_creation_submitted，own HTTP thread与原worker真实服务；记录GUI closed信号在线程内完成并真实join。随后原App.main自己的finish_owner_main/close_owned_jobs/HTTP drain/listener关闭/OS unlock收尾实际完成，不手动篡改close字段或强制解锁。全程无webview/GUI/平台进程。external CLI validation leaf recorded True，review为synthetic {} recorded binding，RuntimeLicensePolicy无真实批准；惰性exe未执行、不授平台许可。

newUI路由实际HTTP200：/workspace HTML39731/8E259093，app.mjs440888/A02D7D6B，upgrade-ui.css108452/962D6D95，另/health53bytes。均来自本版单一app.ROOT；type(server) is app.AppServer、sys.modules['app']身份与SOURCE/app.py精确匹配，原启动argv也精确匹配own重绑定值。

唯一附加诊断接缝：Root observed_native wrapper的on_ready真实调用write_event(None,'native_ready')，原write_event实际返回False；回调继续，App/main正常返回0，证明“写记录失败False不挡打开”的现有契约。没有以任意异常替换为False，也没有宣称真实native渲染成功。Root原外部runtime审核与实际原owner不是本代表核验对象。

audit记录blocked0，拒绝原项目私态文件、外部连接/进程/PID/GUI入口。所有production App/main/entry/preflight/guard/installer/private DB/Cookie/Vault/APIkey动作0。没有重旧22/20/业务矩阵。真实WebView2可见窗口、人类认可、原数据、平台与模型行为仍未验证；这条代表不能反推此前用户桌面异常根因，也不授权本目录发布或安装。
'''
    with (OWN/'FULL-MAIN-REPORT.md').open('xb') as f:f.write(report.encode('utf-8'))
    names=['FULL-MAIN-INPUTS.json','FULL-MAIN-RESULT.json','FULL-MAIN-REPORT.md','prepare_full_main_owned.py','full_main_owned_probe.py','seal_full_main_result.py']
    freeze={'schema':'full_main_owned_fixed_venv_evidence_freeze_v1','status':'FROZEN_LIMITED_OWNED_MAIN_PASS','files':[{'path':str(OWN/n),'pin':pin((OWN/n).read_bytes())} for n in names],
        'public_release':inputs['public_release'],'public_launcher':inputs['launcher_public'],'owned_clone_release_pin':inputs['owned_manifest_pin'],'no_original_actions':True,'installation_authorized':False}
    with (OWN/'FULL-MAIN-FROZEN.json').open('xb') as f:f.write((json.dumps(freeze,ensure_ascii=False,indent=2)+'\n').encode('utf-8'))
    print(json.dumps({n:pin((OWN/n).read_bytes()) for n in ('FULL-MAIN-FROZEN.json','FULL-MAIN-REPORT.md','FULL-MAIN-RESULT.json','FULL-MAIN-INPUTS.json')}))
if __name__=='__main__':main()
