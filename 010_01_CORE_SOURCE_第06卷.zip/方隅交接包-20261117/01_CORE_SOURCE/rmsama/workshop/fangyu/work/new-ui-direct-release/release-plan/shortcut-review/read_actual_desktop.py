from pathlib import Path
import datetime, hashlib, json, os, stat, subprocess

PROJECT = Path('C:/积木软件工坊/项目/方隅公寓客户版')
OWN = PROJECT / 'work/new-ui-direct-release'
RELEASE = PROJECT / 'work/ui-runtime-r55'
SHORTCUT = Path('C:/Users/rmsama/Desktop/方隅工作台.lnk')
BACKUP = OWN / 'desktop-backup/695aee016bd4409ca61995ed21edeeb1'
OUT = Path(__file__).parent / 'ACTUAL-DESKTOP-READBACK.json'

def pin(path, size=None, digest=None):
    path = Path(path)
    def regular():
        for part in (path, *path.parents):
            s = part.lstat()
            assert not part.is_symlink() and not (getattr(s, 'st_file_attributes', 0) & 0x400), str(path)
        s = path.lstat()
        assert stat.S_ISREG(s.st_mode) and s.st_nlink == 1, str(path)
        return s
    before = regular()
    with path.open('rb') as f:
        opened = os.fstat(f.fileno())
        raw = f.read()
        ended = os.fstat(f.fileno())
    after = regular()
    identity = lambda s: (s.st_dev, s.st_ino, s.st_size, s.st_mtime_ns)
    assert identity(before) == identity(opened) == identity(ended) == identity(after), str(path)
    actual = {'size': len(raw), 'sha256': hashlib.sha256(raw).hexdigest().upper(), 'file_identity': [after.st_dev, after.st_ino]}
    assert size is None or actual['size'] == size, str(path)
    assert digest is None or actual['sha256'] == digest.upper(), str(path)
    return raw, {'path': str(path), 'pin': actual}

receipt_raw, receipt_record = pin(OWN / 'ACTUAL-DESKTOP-INSTALLED.json')
receipt = json.loads(receipt_raw)
assert receipt['schema'] == 'fangyu_direct_release_desktop_install_v1' and receipt['status'] == 'INSTALLED'
assert Path(receipt['shortcut']) == SHORTCUT and Path(receipt['backup']) == BACKUP
link_raw, link_record = pin(SHORTCUT, 2263, '67CBF1DDDBCE956CD38E3B411E20CBE45C0F371C16DCDE7C92D7693FE07198F9')
assert link_record['pin'] == receipt['current']['pin']
old_raw, old_record = pin(BACKUP / 'original.lnk', 2341, 'F6B9CFFF37D8523413AD16ABE374F9E849843D3B6EEA5643629D8CBA20F8CE4B')
old_meta_raw, old_meta_record = pin(BACKUP / 'original.json')
old_meta = json.loads(old_meta_raw)
assert old_meta['pin'] == receipt['previous']['pin'] and old_meta['fields'] == receipt['previous']['fields']
assert Path(old_meta['shortcut']) == SHORTCUT
assert not os.path.lexists(BACKUP / 'new.lnk')

quoted = "'" + str(SHORTCUT).replace("'", "''") + "'"
ps = ("$ErrorActionPreference='Stop'; $ProgressPreference='SilentlyContinue'; [Console]::OutputEncoding=[System.Text.UTF8Encoding]::new($false); "
      "$w=New-Object -ComObject WScript.Shell; $s=$w.CreateShortcut(" + quoted + "); "
      "[ordered]@{target=$s.TargetPath;arguments=$s.Arguments;working_directory=$s.WorkingDirectory;icon=$s.IconLocation;window_style=$s.WindowStyle}|ConvertTo-Json -Compress")
result = subprocess.run(['powershell.exe', '-NoLogo', '-NoProfile', '-NonInteractive', '-Command', ps],
                        capture_output=True, encoding='utf-8', timeout=30,
                        creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
assert result.returncode == 0, 'read-only COM shortcut read failed'
fields = json.loads(result.stdout.lstrip('\ufeff'))
assert fields == receipt['current']['fields']
assert Path(fields['target']) == PROJECT / 'work/desktop-python/Scripts/pythonw.exe'
assert fields['arguments'] == '-X utf8 -B -I "' + (RELEASE / 'run_workbench.py').as_posix() + '"'
assert Path(fields['working_directory']) == PROJECT
icon_path, icon_index = fields['icon'].rsplit(',', 1)
assert Path(icon_path) == RELEASE / 'src/resources/brand.ico' and icon_index == '0'
assert fields['window_style'] == 1
link_after_raw, link_after_record = pin(SHORTCUT, 2263, link_record['pin']['sha256'])
assert link_after_raw == link_raw and link_after_record == link_record

launcher_raw, launcher_record = pin(RELEASE / 'run_workbench.py', 10192, 'F674EBFA031019169CD0441B5066E7B4A2DDAE8774269C171B3E846A2516A3C5')
assert Path(receipt['launcher']['path']) == RELEASE / 'run_workbench.py'
assert receipt['launcher']['size'] == 10192 and receipt['launcher']['sha256'] == launcher_record['pin']['sha256']
manifest_raw, manifest_record = pin(RELEASE / 'RELEASE.json', 598108, 'E4E33FDA9699EB610F7E092A2F23C4A39AD3AB2F8505895BB194BD9D09606CF5')
manifest = json.loads(manifest_raw)
assert manifest['schema'] == 'fangyu_local_code_release_v1' and manifest['release_id'] == 'ui-core-r55'
assert Path(manifest['project']) == PROJECT and manifest['source_root'] == 'src'
assert len(manifest['files']) == 853
expected_payloads = {'src/app.py', 'src/assistant/self_operating_read.py', 'src/integrations.py',
                     'src/web/workspace/self-operating-read.mjs', 'src/web/workspace/upgrade-ui.css',
                     'src/assistant/owner_keyword_workflow.py', 'src/assistant/owner_source_export.py',
                     'src/assistant/owner_source_people.py'}
payloads = [x for x in manifest['payloads'] if x['path'].startswith('src/')]
assert len(payloads) == 8 and {x['path'] for x in payloads} == expected_payloads
payload_records = []
for item in payloads:
    assert Path(item['source']).is_relative_to(PROJECT / 'work/ui-core-completion/source/app/src')
    assert item['sha256'] == item['source_sha256']
    _, entry = pin(RELEASE / item['path'], item['size'], item['sha256'])
    entry['approved_payload_source'] = item['source']
    payload_records.append(entry)
icon = next(x for x in manifest['files'] if x['path'] == 'src/resources/brand.ico')
_, icon_record = pin(RELEASE / icon['path'], icon['size'], icon['sha256'])

legacy_specs = [
    ('work/desktop-self-use-entry/next_open_source55.py', 10026, 'D19D44601F75E67D9E26D7BDE4A3A630B739E7548814A4559133A39FB668CC0F'),
    ('work/desktop-self-use-entry/source_next_open_launcher.py', 12357, '3CCAA99F51F7CF596F7CDF1A6274966697C8D25CBB699600B7ED62BC70F3F27A'),
    ('work/product-upgrade-20261009/audits/source55-native-installed.json', 2636, 'AAB373D03A2AA078E45C93E7292FD985BDA3267FB79E0C15F931C27D192FE114')]
legacy = [pin(PROJECT / p, size, digest)[1] for p, size, digest in legacy_specs]
assert pin(OWN / 'ACTUAL-DESKTOP-INSTALLED.json')[0] == receipt_raw
report = {
    'schema': 'fangyu_direct_release_desktop_independent_readback_v1',
    'status': 'PASS_ACTUAL_DESKTOP_READBACK',
    'at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'independent_of_installer_author': True,
    'receipt': receipt_record,
    'shortcut': link_record,
    'shortcut_actual_COM_fields': fields,
    'backup': {'original_lnk': old_record, 'original_fields_record': old_meta_record, 'staged_new_lnk_absent': True},
    'launcher': launcher_record,
    'manifest': manifest_record,
    'payloads': payload_records,
    'icon': icon_record,
    'legacy_unchanged': legacy,
    'scope': 'One necessary post-install actual readback of link, raw backup, launcher, manifest, eight local payloads and original two thins plus original55 native raw. Original state and process status not polled.',
    'full_853_hash_repeat': False,
    'original_App_guard_PID_preflight_calls': 0,
    'original_business_apply_calls': 0,
    'database_cookie_vault_key_reads': 0,
    'COM_writes': 0,
    'formal_mutations': 0,
    'GUI_verified': False,
    'real_platform_model_verified': False,
    'source55_business_apply_current_state': 'not queried'
}
with OUT.open('x', encoding='utf-8', newline='\n') as f:
    json.dump(report, f, ensure_ascii=False, indent=2)
    f.write('\n')
raw = OUT.read_bytes()
print(json.dumps({'report': str(OUT), 'size': len(raw), 'sha256': hashlib.sha256(raw).hexdigest().upper(),
                  'status': report['status'], 'local_payload_count': len(payload_records)}, ensure_ascii=False))
