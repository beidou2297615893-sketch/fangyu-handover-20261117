"""Explicit, replaceable command adapters. Never access browser cookies."""
import json
import hashlib
import shutil
import subprocess
import os
import re
import time
import threading
import stat
from contextlib import contextmanager, nullcontext
from datetime import datetime
from html import unescape
from pathlib import Path
from urllib.parse import parse_qs, parse_qsl, urlencode, urlsplit
from uuid import uuid4
from .douyin_pages import page_request, finish_page
from . import zhihu, wechat_channels
from .account_safety import summarize_activity
from .xhs_display_probe import record_report as record_xhs_display_report

PLATFORMS = [('xiaohongshu','小红书'),('douyin','抖音'),('kuaishou','快手'),('weibo','微博'),('zhihu','知乎'),('wechat_channels','视频号')]
BUILTIN_IDS={item[0] for item in PLATFORMS}

_XHS_COMMENT_ID=re.compile(r'[A-Za-z0-9_-]{1,160}')

def _xhs_comment_id(value):
    return value if isinstance(value,str) and _XHS_COMMENT_ID.fullmatch(value) else ''

def _xhs_reply_target(item):
    """Only an explicit direct target in the platform comment can identify a reply."""
    target=item.get('target_comment')
    if target is not None and not isinstance(target,dict):return {}
    target=target or {}
    for value in (item.get('target_comment_id'),target.get('id'),target.get('comment_id')):
        if value not in (None,'') and not _xhs_comment_id(value):return {}
    ids={value for value in (_xhs_comment_id(item.get('target_comment_id')),
                             _xhs_comment_id(target.get('id')),
                             _xhs_comment_id(target.get('comment_id'))) if value}
    if len(ids)!=1:return {}
    result={'target_comment_id':next(iter(ids))}
    authors_raw=[item.get('target_author_id')]
    for field in ('user_info','user'):
        author=target.get(field)
        if author is not None and not isinstance(author,dict):return {}
        if author is not None:authors_raw.append(author.get('user_id'))
    if any(value not in (None,'') and not _xhs_comment_id(value) for value in authors_raw):return {}
    authors={value for value in authors_raw if value}
    if len(authors)>1:return {}
    if len(authors)==1:result['target_author_id']=next(iter(authors))
    return result

def _xhs_sent_comment_id(payload):
    """Read only the platform's own returned reply ID, never the request target."""
    raw=payload.get('data') if isinstance(payload,dict) else None
    if (not isinstance(raw,dict) or raw.get('success') is not True
            or type(raw.get('code')) is not int or raw['code']!=0):return ''
    data=raw.get('data')
    if not isinstance(data,dict):return ''
    comment=data.get('comment')
    if comment is not None and not isinstance(comment,dict):return ''
    comment=comment or {}
    for value in (data.get('id'),data.get('comment_id'),comment.get('id'),comment.get('comment_id')):
        if value not in (None,'') and not _xhs_comment_id(value):return ''
    ids={value for value in (_xhs_comment_id(data.get('id')),_xhs_comment_id(data.get('comment_id')),
                             _xhs_comment_id(comment.get('id')),_xhs_comment_id(comment.get('comment_id'))) if value}
    return next(iter(ids)) if len(ids)==1 else ''

def xhs_image_url(value):
    """Keep only image URLs actually returned by the XHS response."""
    if isinstance(value,dict):
        candidates=[value.get(key) for key in ('url_default','url_pre','url')]
        info=value.get('info_list')
        if isinstance(info,list):
            for item in info[:8]:
                if isinstance(item,dict):
                    candidates.extend(item.get(key) for key in ('url_default','url_pre','url'))
        for candidate in candidates:
            if isinstance(candidate,str):
                accepted=xhs_image_url(candidate)
                if accepted:return accepted
        return ''
    if (not isinstance(value,str) or len(value)>2048 or '\\' in value or re.search(r'\s',value)
            or any(ord(char)<33 or ord(char)==127 for char in value)):return ''
    try:
        parsed=urlsplit(value)
        port=parsed.port
    except ValueError:return ''
    host=(parsed.hostname or '').lower()
    cdn=host=='xhscdn.com' or host.endswith('.xhscdn.com')
    site=host=='xiaohongshu.com' or host.endswith('.xiaohongshu.com')
    if ('@' in parsed.netloc or parsed.username or parsed.password or not parsed.path
            or parsed.scheme=='https' and (port not in (None,443) or not (cdn or site))
            or parsed.scheme=='http' and (port is not None or not cdn)
            or parsed.scheme not in ('https','http')):return ''
    return 'https://'+value[len('http://'):] if parsed.scheme=='http' else value

def xhs_first_image(*values):
    for value in values:
        url=xhs_image_url(value)
        if url:return url
    return ''

def _record_xhs_display(account_dir, kind, payload, mapped=None, status='mapped'):
    try:
        record_xhs_display_report(account_dir,kind,payload,mapped,status,xhs_image_url)
    except Exception:
        # Diagnostics must not interrupt a successful read or change its error.
        pass

def _xhs_page_diagnostic(args):
    """Return only a bounded, opaque page identity for read-only comment commands."""
    if not isinstance(args,(list,tuple)) or not args or args[0] not in ('comments','sub-comments'):
        return {}
    kind=args[0]
    required=2 if kind=='comments' else 3
    if len(args)<required or len(args)>9 or any(not isinstance(value,str) for value in args):
        return {}
    options={}; index=required
    allowed={'--json','--cursor'} | ({'--xsec-token'} if kind=='sub-comments' else set())
    while index<len(args):
        option=args[index]
        if option not in allowed or option in options:return {}
        if option=='--json':
            options[option]=True; index+=1
        else:
            if index+1>=len(args):return {}
            options[option]=args[index+1]; index+=2
    cursor=options.get('--cursor','')
    if len(cursor)>512 or any(ord(char)<32 or ord(char)==127 for char in cursor):return {}
    if kind=='comments':
        url=args[1]
        if len(url)>4096 or re.search(r'%(?![0-9A-Fa-f]{2})',url):return {}
        try:parsed=urlsplit(url)
        except ValueError:return {}
        if (parsed.scheme!='https' or parsed.netloc not in ('www.xiaohongshu.com','xiaohongshu.com')
                or parsed.fragment or parsed.username or parsed.password):return {}
        match=re.fullmatch(r'/explore/([A-Za-z0-9]{1,128})/?',parsed.path)
        if not match:return {}
        try:query=parse_qsl(parsed.query,keep_blank_values=True,strict_parsing=True)
        except ValueError:return {}
        if (len(query)>2 or len({key for key,_ in query})!=len(query)
                or any(key not in ('xsec_token','xsec_source') or len(value)>2048
                       or any(ord(char)<32 or ord(char)==127 for char in value)
                       for key,value in query)):return {}
        note_id=match.group(1); root_id=''
        token_present=bool(dict(query).get('xsec_token'))
    else:
        note_id,root_id=args[1:3]
        if not re.fullmatch(r'[A-Za-z0-9]{1,128}',note_id) or not re.fullmatch(r'[A-Za-z0-9]{1,128}',root_id):return {}
        token=options.get('--xsec-token','')
        if len(token)>2048 or any(ord(char)<32 or ord(char)==127 for char in token):return {}
        token_present=bool(token)
    digest=hashlib.sha256(json.dumps([note_id,root_id,cursor],separators=(',',':')).encode('utf-8')).hexdigest()
    return {'page_fingerprint_sha256':digest,'cursor_present':bool(cursor),'token_present':token_present}

_XHS_CLI_ERRORS={
    'not_authenticated':'小红书登录已失效，请在本地助手核实账号后重新扫码登录',
    'verification_required':'平台暂未放行本次请求，请核对账号提示与接口兼容性',
    'ip_blocked':'平台限制了当前网络访问，请先核实网络和账号状态',
    'signature_error':'平台请求签名校验失败，请检查 CLI 兼容性',
    'api_error':'平台接口返回失败，需结合账号安全记录核查原因',
    'unsupported_operation':'当前 CLI 不支持此操作，请检查命令兼容性',
    'protocol_error':'平台返回格式无效，无法确认操作结果',
    'transport_error':'平台连接失败，无法确认操作结果',
    'unknown_error':'CLI 执行异常，尚无可确认的平台原因',
}

def _cli_json(stdout):
    # Python accepts NaN/Infinity by default, although they are not valid JSON.
    def invalid_constant(_value):raise ValueError('Invalid JSON constant')
    return json.loads(stdout,parse_constant=invalid_constant)

def _xhs_error_code(payload):
    error=payload.get('error') if isinstance(payload,dict) else None
    code=error.get('code') if isinstance(error,dict) else None
    return code if isinstance(code,str) and code in _XHS_CLI_ERRORS else ''

def _raise_xhs_cli_error(code):
    message=f'小红书 CLI 返回失败（{code}）：{_XHS_CLI_ERRORS[code]}；本次已停止，请先人工核实。'
    error_type=AdapterAuthRequired if code=='not_authenticated' else RuntimeError
    raise error_type(message)

def safe_platform_id(value):
    return isinstance(value,str) and re.fullmatch(r'[a-z][a-z0-9_-]{1,63}',value) is not None

class AdapterBusy(RuntimeError): pass

class _BilibiliOwnedCleanupPending(RuntimeError):
    """Exact fixed-stdin process retained until the original owner confirms exit."""
    def __init__(self,adapters,process,key,job_id):
        super().__init__('B站本人核对进程仍待清理，请安全停止后再操作')
        self.adapters,self.process,self.key,self.job_id=adapters,process,key,job_id
    def finish(self):
        process=self.process
        try:
            if process.poll() is None:
                try:process.terminate()
                except OSError:pass
                try:process.wait(timeout=0.5)
                except subprocess.TimeoutExpired:
                    process.kill();process.wait(timeout=0.5)
            if process.poll() is None:return False
        except (OSError,subprocess.TimeoutExpired):return False
        with self.adapters.lifecycle_lock:
            if self.adapters.processes.get(self.key) is process:self.adapters.processes.pop(self.key,None)
            if self.adapters.job_processes.get(self.job_id) is process:self.adapters.job_processes.pop(self.job_id,None)
        return True

class _OwnerXhsReadJob:
    """Private original-worker facts; metadata never releases its resources."""
    def __init__(self, scope, reads, entry, binding):
        from assistant.self_operating_read import _OwnerXhsRequestScope
        if type(scope) is not _OwnerXhsRequestScope or scope.reads is not reads:
            raise ValueError('本人采集必须使用原私有请求范围')
        self.scope,self.reads,self.entry,self.binding=scope,reads,entry,binding
        self.adapters=reads.core.adapters
        self.thread=threading.get_ident()
        self.process=None;self.process_key=None;self.directory=None
        self.adapter_started=False;self.adapter_done=False
        self.channel_acquired=False;self.channel_released=False
        self.lock_entered=False;self.lock_exited=False
        self.process_finished=False;self.cleanup_pending=False;self.spawn_attempted=False
        self.lease_acquired=False;self.mode_released=True;self.worker_done=False

    def check(self, platform, args, directory, job_id):
        if (threading.get_ident()!=self.thread or platform!='xiaohongshu'
                or not isinstance(args,list) or not args or args[0]!='comments'
                or job_id!=self.entry['operation_id'] or self.entry.get('cancelled')
                or self.reads.core.adapters is not self.adapters):
            raise ValueError('本人本次采集范围已失效')
        expected=self.reads.core.store.directory/'accounts'/self.reads.tenant/self.entry['account_id']
        if directory is None or Path(directory).resolve()!=expected.resolve():
            raise ValueError('本人本次采集目录已变化')
        self.scope.execution_check(self.entry)

    def cancel(self):
        # Request a stop on this retained exact child. The original worker alone
        # waits, releases its OS mutex/channel and records the mode-release fact.
        process=self.process
        if process is not None:
            try:
                if process.poll() is None:process.terminate()
            except OSError:pass

    def finish_process(self):
        if threading.get_ident()!=self.thread:raise RuntimeError('只能原采集线程收尾')
        if self.process is None:return
        pending=_BilibiliOwnedCleanupPending(self.adapters,self.process,self.process_key,self.entry['operation_id'])
        while True:
            try:finished=pending.finish()
            except Exception:finished=False
            if finished:
                with self.adapters.lifecycle_lock:
                    if self.adapters.process_accounts.get(self.process_key)==self.directory:
                        self.adapters.process_accounts.pop(self.process_key,None)
                self.process_finished=True;self.cleanup_pending=False
                return
            self.cleanup_pending=True
            time.sleep(0.1)

    @contextmanager
    def account_lock(self,directory):
        manager=account_execution_lock(directory)
        manager.__enter__()
        self.lock_entered=True
        try:yield
        finally:
            # Includes failures between Popen and registry insertion. Retained
            # object ownership does not depend on a registry still being present.
            self.finish_process()
            manager.__exit__(None,None,None)
            self.lock_exited=True

    def cleanup_confirmed(self):
        return bool(self.worker_done and (not self.adapter_started or self.adapter_done)
            and (not self.spawn_attempted or self.process is not None and self.process_finished)
            and (not self.lock_entered or self.lock_exited)
            and (not self.channel_acquired or self.channel_released)
            and (not self.lease_acquired or self.mode_released))

def _douyin_comments_call_fn(adapters,platform,args,account_dir,job_id,call):
    if call is None:return None
    from .douyin_owned_comments import _DouyinCommentsCall
    from assistant.owner_douyin_read import _OwnerDouyinCommentsCall
    if type(call) not in (_DouyinCommentsCall,_OwnerDouyinCommentsCall):raise ValueError('抖音指定视频读取必须使用原私有通道')
    call.check(adapters,platform,args,account_dir,job_id)
    return call

def _douyin_owned_call_fn(adapters,platform,args,account_dir,job_id,comments,search):
    if comments is not None and search is not None:raise ValueError('抖音本次读取不能合并两个用途')
    if search is None:return _douyin_comments_call_fn(adapters,platform,args,account_dir,job_id,comments)
    from .douyin_owned_search import _DouyinSearchCall
    if type(search) is not _DouyinSearchCall:raise ValueError('抖音搜索必须使用本次可信私有通道')
    search.check(adapters,platform,args,account_dir,job_id)
    return search


def _bilibili_owned_input(adapters,platform,args,account_dir,job_id,raw,stop):
    if raw is None and stop is None:return None
    from bilibili_read_contract import owned_credential_input,_number
    from .bilibili_read import configured
    if (platform!='bilibili' or not account_dir or not job_id or type(args) is not list
            or len(args)!=3 or args[:2]!=['self','--expected-uid'] or type(args[2]) is not str
            or args[2] and str(_number(args[2]))!=args[2] or type(stop) is not threading.Event
            or not configured(adapters.manifest(platform))):raise ValueError('B站本人核对必须使用固定输入通道')
    owned_credential_input(raw)
    return raw.decode('utf-8')

def _zhihu_identity_call_fn(adapters,platform,args,account_dir,job_id,call):
    if call is None:return None
    from .zhihu_owned_identity import _ZhihuIdentityCall
    if type(call) is not _ZhihuIdentityCall:raise ValueError('知乎本人核对必须使用固定内部通道')
    call.check(adapters,platform,args,account_dir,job_id)
    return call

class AdapterSafetyRequired(ValueError):
    """A local account risk stopped work before a platform request began."""

class AdapterAuthRequired(RuntimeError):
    """The selected platform account must be logged in again."""

class _OwnerXhsLocalCredentialMissing(AdapterAuthRequired):
    """Only a checked owner status call, before any process has been created."""
    def __init__(self, call):
        self.call=call
        super().__init__('本机尚未建立登录会话')


def _owner_xhs_local_status(call, adapters, platform, args, directory, job_id, spec):
    from assistant.self_operating_read import _OwnerXhsLocalStatusCall
    if type(call) is not _OwnerXhsLocalStatusCall:raise ValueError('本人状态核对需要原私有调用')
    call.check(adapters,platform,args,directory,job_id,spec)
    owned=call.directory.resolve()
    channel=adapters.channel_locks.get(platform+':'+str(owned))
    if (owned not in getattr(_account_lock_owner,'paths',set())
            or channel is None or not channel.locked()):
        raise ValueError('本人状态核对未持有原账号锁')
    # account_spec has created the ordinary account directory under the original
    # channel/account OS lock. The known V6 reads only this HOME cookie file.
    root=call.workspace.instance.directory
    relative=call.directory.relative_to(root)
    current=root
    parts=(*relative.parts,'.xiaohongshu-cli','cookies.json')
    for index,part in enumerate(('',*parts)):
        if part:current=current/part
        try:attrs=current.lstat()
        except FileNotFoundError:
            if index < len(relative.parts)+1:raise ValueError('本人账号目录在核对期间变化') from None
            raise _OwnerXhsLocalCredentialMissing(call) from None
        is_cookie=index==len(parts)
        if (stat.S_ISLNK(attrs.st_mode)
                or getattr(attrs,'st_file_attributes',0)&getattr(stat,'FILE_ATTRIBUTE_REPARSE_POINT',0)
                or (not stat.S_ISREG(attrs.st_mode) if is_cookie else not stat.S_ISDIR(attrs.st_mode))
                or is_cookie and attrs.st_nlink!=1):
            raise ValueError('本人状态核对不读取链接或不明凭据路径')

class PageUnavailable(RuntimeError):
    """Local page helper/protocol failed; platform login identity is unchanged."""

    def __init__(self, code):
        self.code = code
        super().__init__('页面采集连接不可用（%s），已保留账号绑定与采集断点' % code)

_account_locks_guard=threading.Lock()
_account_locks={}
_account_lock_owner=threading.local()

@contextmanager
def account_execution_lock(account_dir):
    """Keep one account exclusive across processes, with same-thread nesting."""
    root=Path(account_dir).resolve()
    root.mkdir(parents=True,exist_ok=True)
    with _account_locks_guard:
        local_lock=_account_locks.setdefault(root,threading.RLock())
    if not local_lock.acquire(blocking=False):
        raise AdapterBusy('该账号正在另一助手操作中；本次未执行')
    try:
        held=getattr(_account_lock_owner,'paths',None)
        if held is None:
            held=set();_account_lock_owner.paths=held
        if root in held:
            yield
            return
        handle=os.open(root/'platform-command.lock',os.O_CREAT|os.O_RDWR,0o600)
        locked=False
        try:
            if os.fstat(handle).st_size==0:os.write(handle,b'\0')
            os.lseek(handle,0,os.SEEK_SET)
            try:
                if os.name=='nt':
                    import msvcrt
                    msvcrt.locking(handle,msvcrt.LK_NBLCK,1)
                else:
                    import fcntl
                    fcntl.flock(handle,fcntl.LOCK_EX|fcntl.LOCK_NB)
            except OSError as exc:
                raise AdapterBusy('该账号正在另一助手进程执行操作；本次未执行') from exc
            locked=True
            held.add(root)
            yield
        finally:
            held.discard(root)
            try:
                if locked:
                    if os.name=='nt':
                        os.lseek(handle,0,os.SEEK_SET)
                        msvcrt.locking(handle,msvcrt.LK_UNLCK,1)
                    else:fcntl.flock(handle,fcntl.LOCK_UN)
            finally:os.close(handle)
    finally:local_lock.release()

class Adapters:
    def __init__(self, root, local_root=None):
        self.root = Path(root) if root else None
        self.local_root = Path(local_root) if local_root else None
        self.processes={}
        self.process_accounts={}
        self.job_processes={}
        self.http_jobs={}
        self.lifecycle_lock=threading.Lock()
        self.closed=False
        self.profile_checker=None
        self.close_event=threading.Event()
        self.channel_locks={}
        self.channel_guard=threading.Lock()
        self.last_send={}
        self.platform_guard=None
        self.xhs_page_runtime=None
        self._owner_xhs_context=threading.local()

    def _guard_platform(self,platform):
        if callable(self.platform_guard):self.platform_guard(platform)

    @staticmethod
    def require_account_safe(platform,account_dir):
        if platform=='xiaohongshu':
            safety=summarize_activity(Path(account_dir).resolve()/'platform-activity.jsonl')
            if safety['state']=='review_required':
                raise AdapterSafetyRequired('此账号有待核实的限流、验证或异常退出记录；请先在本地助手完成账号安全复核，再重新登录或继续任务')

    @staticmethod
    def _record_cli_outcome(spec,args,status,returncode=None,stdout=''):
        """Account-local outcome only; never persist arguments or process output."""
        destination=(spec.get('env') or {}).get('WORKSPACE_ACTIVITY_LOG')
        if not destination:return
        kind=str(args[0]) if args else 'other'
        if kind not in {'login','status','whoami','search','read','comments','sub-comments','reply'}:kind='other'
        code=''
        if status!='completed' and isinstance(stdout,str) and len(stdout)<65536:
            try:
                candidate=_xhs_error_code(_cli_json(stdout))
                if candidate and candidate!='unknown_error':
                    code=candidate
            except (ValueError,AttributeError,TypeError):pass
        event={'at':time.time(),'stage':'cli_finished','kind':kind,
               'status':code or status,'exit_code':int(returncode) if isinstance(returncode,int) else None}
        try:event.update(_xhs_page_diagnostic(args))
        except Exception:pass
        payload=(json.dumps(event,separators=(',',':'))+'\n').encode('utf-8')
        handle=os.open(destination,os.O_CREAT|os.O_APPEND|os.O_WRONLY,0o600)
        try:
            if os.write(handle,payload)!=len(payload):raise OSError('Activity record was incomplete')
            os.fsync(handle)
        finally:os.close(handle)

    def manifest(self,platform):
        if not safe_platform_id(platform): raise RuntimeError('平台 ID 不安全或格式无效')
        item=next((x for x in self.manifests() if x['id']==platform),None)
        if not item or not item.get('available'): raise RuntimeError('平台 CLI 未安装或路径未配置')
        return item

    @staticmethod
    def _validated_candidate_home(platform,args,account_dir,candidate_home):
        """Only a status probe may use a private HOME under its real account."""
        if candidate_home is None:return None
        if platform!='xiaohongshu' or list(args)!=['status','--json'] or not account_dir:
            raise ValueError('候选登录目录无效')
        try:
            account=Path(account_dir).resolve()
            candidate=Path(candidate_home)
            if not candidate.is_absolute() or '..' in candidate.parts:
                raise ValueError('候选登录目录无效')
            allowed=account/'work'/'browser-login'
            resolved=candidate.resolve(strict=True)
            if not resolved.is_dir() or not resolved.is_relative_to(allowed) or resolved==allowed:
                raise ValueError('候选登录目录无效')
            # Check the lexical path as well: resolve() alone erases evidence of
            # a symlink/junction that may redirect the candidate outside HOME.
            lexical=candidate.relative_to(account)
            current=account
            for part in lexical.parts:
                current=current/part
                if current.is_symlink() or (hasattr(current,'is_junction') and current.is_junction()):
                    raise ValueError('候选登录目录无效')
        except (OSError,RuntimeError,ValueError,TypeError):
            raise ValueError('候选登录目录无效') from None
        return resolved

    def account_spec(self,platform,account_dir,args,*,candidate_home=None,_zhihu_identity_call=None):
        self._guard_platform(platform)
        self.require_account_safe(platform,account_dir)
        manifest=self.manifest(platform)
        generic=platform not in BUILTIN_IDS
        if not manifest.get('isolation_guard') or (generic and manifest.get('account_mode')!='isolated_home'):
            raise RuntimeError('此适配器尚未验证账号隔离保护，不能使用员工账号执行')
        if generic and manifest.get('mapper')!='standard_json': raise RuntimeError('通用适配器必须显式声明 standard_json，不能借用未验证的平台协议')
        root=Path(account_dir).resolve(); root.mkdir(parents=True,exist_ok=True)
        candidate=self._validated_candidate_home(platform,args,root,candidate_home)
        env={**(manifest.get('env',{}) if not generic else {}),'HOME':str(root),'USERPROFILE':str(root),'XDG_CONFIG_HOME':str(root/'.config'),'APPDATA':str(root/'AppData'/'Roaming'),'LOCALAPPDATA':str(root/'AppData'/'Local'),'LEADSTUDIO_ISOLATED':'1','PYTHONUTF8':'1','PYTHONIOENCODING':'utf-8'}
        if platform=='xiaohongshu':
            env['WORKSPACE_ACTIVITY_LOG']=str(root/'platform-activity.jsonl')
            env['WORKSPACE_ACTIVITY_KIND']=str(args[0]) if args else 'other'
            if candidate is not None:
                env.update(HOME=str(candidate),USERPROFILE=str(candidate),
                           XDG_CONFIG_HOME=str(candidate/'.config'),
                           APPDATA=str(candidate/'AppData'/'Roaming'),
                           LOCALAPPDATA=str(candidate/'AppData'/'Local'))
        if platform=='douyin':
            config_dir=root.parents[2]/'bridge'/root.parent.name
            if not (config_dir/'config.json').is_file(): raise RuntimeError('请先在工作台开启本企业独立抖音 Bridge')
            env.update(DOUYIN_CONFIG=str(config_dir/'config.json'),DOUYIN_LOG_DIR=str(config_dir/'logs'),DOUYIN_STORAGE_DIR=str(config_dir/'storage'))
        elif platform=='kuaishou':
            config_dir=root.parents[2]/'kuaishou_bridge'/root.parent.name
            if not (config_dir/'config.json').is_file(): raise RuntimeError('请先在工作台开启本企业独立快手 Bridge')
            env['KUAISHOU_CONFIG']=str(config_dir/'config.json')
        elif platform=='zhihu':
            if len(args)<4 or args[0]!='--profile':raise RuntimeError('知乎操作必须明确指定浏览器窗口')
            zhihu.profile_id(args[1])
            if args[2]!='zhihu' or args[3] not in ('search','answer-comments','answer','whoami'):
                raise RuntimeError('知乎操作不在工作台已接入范围')
            if args[3]=='whoami':
                if candidate_home is not None or _zhihu_identity_call is None:raise ValueError('知乎本人核对必须使用固定内部通道')
                from .zhihu_owned_identity import _ZhihuIdentityCall
                if type(_zhihu_identity_call) is not _ZhihuIdentityCall:raise ValueError('知乎本人核对必须使用固定内部通道')
                _zhihu_identity_call.check(self,platform,args,account_dir,_zhihu_identity_call.entry['job_id'])
            elif _zhihu_identity_call is not None:raise ValueError('知乎本人核对不授予其他操作')
            if not callable(self.profile_checker):raise RuntimeError('知乎连接管理器尚未就绪')
            if args[3]=='answer':
                if not manifest.get('publication_transport_verified'):raise RuntimeError('知乎发布运行链尚未通过单次执行验证')
                if len(args)!=10 or args[5]!='--file' or args[7:]!=['--execute','-f','json']:
                    raise RuntimeError('知乎发布必须使用已审核正文文件')
                from .publication import zhihu_question_url
                zhihu_question_url(args[4])
                body=Path(args[6]).resolve()
                allowed=(root.parents[2]/'work/publication-images'/root.parent.name).resolve()
                if not body.is_relative_to(allowed) or not body.is_file():raise RuntimeError('知乎正文文件不属于当前企业发布目录')
                self.profile_checker(args[1],for_write=True)
            else:self.profile_checker(args[1])
            config=root/'.opencli-workbench';config.mkdir(parents=True,exist_ok=True)
            (config/'browser-profiles.json').write_text('{"aliases":{}}','utf-8')
            env.update(OPENCLI_CONFIG_DIR=str(root/'.opencli-workbench'),OPENCLI_PROFILE=args[1],CI='1',NODE_OPTIONS='',NODE_PATH='')
        return {'argv':[manifest['executable']]+list(manifest.get('prefix_args',[]))+list(args),'env':env,'cwd':str(root)}

    def _owner_xhs_current(self,platform,args,directory,job_id):
        job=getattr(self._owner_xhs_context,'job',None)
        if job is not None:
            if type(job) is not _OwnerXhsReadJob:raise ValueError('本人采集私有任务无效')
            job.check(platform,args,directory,job_id)
        return job

    def _execute_owner_xhs(self,job,platform,args,directory,job_id,timeout=35):
        if type(job) is not _OwnerXhsReadJob or job.adapters is not self:
            raise ValueError('本人采集必须沿原私有任务')
        if getattr(self._owner_xhs_context,'job',None) is not None:
            raise ValueError('本人采集不能嵌套')
        job.check(platform,args,directory,job_id)
        self._owner_xhs_context.job=job;job.adapter_started=True
        try:return self.execute(platform,args,directory,job_id,timeout)
        finally:
            job.adapter_done=True
            if getattr(self._owner_xhs_context,'job',None) is job:del self._owner_xhs_context.job

    def execute(self,platform,args,account_dir=None,job_id=None,timeout=35,*,candidate_home=None,
                bilibili_credential_input=None,bilibili_stop_event=None,_zhihu_identity_call=None,_douyin_comments_call=None,_douyin_search_call=None,_owner_keyword_call=None,_owner_xhs_status_call=None):
        if _owner_xhs_status_call is not None and (candidate_home is not None or self.xhs_page_runtime is not None
                or any(value is not None for value in (bilibili_credential_input,_zhihu_identity_call,
                    _douyin_comments_call,_douyin_search_call,_owner_keyword_call))):
            raise ValueError('本人本机状态核对不混用其他用途')
        owner_job=self._owner_xhs_current(platform,args,account_dir,job_id)
        owner_search=None
        if _owner_keyword_call is not None:
            from assistant.owner_single_keyword_search import check_adapter_call
            owner_search=check_adapter_call(self,platform,args,account_dir,job_id,_owner_keyword_call)
        dy_call=_douyin_owned_call_fn(self,platform,args,account_dir,job_id,_douyin_comments_call,_douyin_search_call)
        _zhihu_identity_call_checked=_zhihu_identity_call_fn(self,platform,args,account_dir,job_id,_zhihu_identity_call)
        _bilibili_owned_input(self,platform,args,account_dir,job_id,bilibili_credential_input,bilibili_stop_event)
        self._validated_candidate_home(platform,args,account_dir,candidate_home)
        self._guard_platform(platform)
        with self.lifecycle_lock:
            if self.closed: raise RuntimeError('工作台正在关闭，不能启动新的 CLI 操作')
        if platform in ('douyin','kuaishou') and account_dir:
            # A private Bridge process is conservatively one channel, including
            # multiple account records bound to the same browser connection.
            channel=platform+':'+str(Path(account_dir).resolve().parent)
        else: channel=platform+':'+str(Path(account_dir).resolve() if account_dir else 'unscoped')
        with self.channel_guard: lock=self.channel_locks.setdefault(channel,threading.Lock())
        if not lock.acquire(blocking=False): raise AdapterBusy('该账号或浏览器连接正在执行其他操作，请稍后重试；本次未执行')
        if owner_job is not None:owner_job.channel_acquired=True
        try:
            process_lock=(owner_job.account_lock(account_dir) if owner_job is not None else account_execution_lock(account_dir)
                          if (platform in ('xiaohongshu','bilibili') or _zhihu_identity_call_checked is not None or dy_call is not None) and account_dir else nullcontext())
            with process_lock:
                if owner_job is not None and self.xhs_page_runtime is not None:
                    raise ValueError('本人CLI采集不借页面用途')
                if platform=='xiaohongshu' and self.xhs_page_runtime is not None and candidate_home is None:
                    # Keep the existing channel, platform and cross-process account
                    # guards. The page route has no CLI/HTTP fallback or send path.
                    if not account_dir:raise AdapterSafetyRequired('页面采集必须绑定独立账号')
                    self.require_account_safe(platform,account_dir)
                    return self.xhs_page_runtime.execute(account_dir,args,job_id)
                is_send=platform=='xiaohongshu' and 'reply' in args
                if is_send:
                    wait=2-(time.monotonic()-self.last_send.get(channel,0))
                    if wait>0 and self.close_event.wait(wait): raise RuntimeError('工作台正在关闭，已取消发送等待')
                try:
                    if owner_search is not None:
                        if candidate_home is not None or bilibili_credential_input is not None or _zhihu_identity_call_checked is not None or dy_call is not None:
                            raise ValueError("本人首作品页搜索不借其他用途")
                        return self._execute(platform,args,account_dir,job_id,timeout,_owner_keyword_call=owner_search)
                    if dy_call is not None:
                        if candidate_home is not None or bilibili_credential_input is not None or _zhihu_identity_call_checked is not None:
                            raise ValueError('抖音指定视频读取不使用其他授权通道')
                        return self._execute(platform,args,account_dir,job_id,timeout,
                            _douyin_comments_call=_douyin_comments_call,_douyin_search_call=_douyin_search_call)
                    if _zhihu_identity_call_checked is not None:
                        if bilibili_credential_input is not None or candidate_home is not None:raise ValueError('知乎本人核对不使用其他输入通道')
                        return self._execute(platform,args,account_dir,job_id,timeout,_zhihu_identity_call=_zhihu_identity_call_checked)
                    if bilibili_credential_input is not None:
                        if candidate_home is not None:raise ValueError('B站本人核对不使用候选登录目录')
                        return self._execute(platform,args,account_dir,job_id,timeout,
                            bilibili_credential_input=bilibili_credential_input,bilibili_stop_event=bilibili_stop_event)
                    if candidate_home is None:
                        return self._execute(platform,args,account_dir,job_id,timeout,
                            **({'_owner_xhs_status_call':_owner_xhs_status_call} if _owner_xhs_status_call is not None else {}))
                    return self._execute(platform,args,account_dir,job_id,timeout,candidate_home=candidate_home)
                finally:
                    if is_send: self.last_send[channel]=time.monotonic()
        finally:
            lock.release()
            if owner_job is not None:owner_job.channel_released=True

    def _execute(self,platform,args,account_dir=None,job_id=None,timeout=35,*,candidate_home=None,
                 bilibili_credential_input=None,bilibili_stop_event=None,_zhihu_identity_call=None,_douyin_comments_call=None,_douyin_search_call=None,_owner_keyword_call=None,_owner_xhs_status_call=None):
        owner_job=self._owner_xhs_current(platform,args,account_dir,job_id)
        owner_search=None
        if _owner_keyword_call is not None:
            from assistant.owner_single_keyword_search import check_adapter_call
            owner_search=check_adapter_call(self,platform,args,account_dir,job_id,_owner_keyword_call)
        dy_call=_douyin_owned_call_fn(self,platform,args,account_dir,job_id,_douyin_comments_call,_douyin_search_call)
        zhihu_call=_zhihu_identity_call_fn(self,platform,args,account_dir,job_id,_zhihu_identity_call)
        owned_input=_bilibili_owned_input(self,platform,args,account_dir,job_id,bilibili_credential_input,bilibili_stop_event)
        self._guard_platform(platform)
        manifest=self.manifest(platform)
        if platform=='zhihu' and not account_dir:raise RuntimeError('知乎操作必须选择独立账号')
        if platform not in BUILTIN_IDS and not account_dir: raise RuntimeError('通用平台执行必须明确选择独立账号目录')
        spec=(self.account_spec(platform,account_dir,args,candidate_home=candidate_home)
              if account_dir and candidate_home is not None else
              self.account_spec(platform,account_dir,args,_zhihu_identity_call=zhihu_call) if account_dir and zhihu_call is not None else
              self.account_spec(platform,account_dir,args) if account_dir else
              {'argv':[manifest['executable']]+list(manifest.get('prefix_args',[]))+args,'env':manifest.get('env',{}),'cwd':None})
        if _owner_xhs_status_call is not None:
            _owner_xhs_local_status(_owner_xhs_status_call,self,platform,args,account_dir,job_id,spec)
        process_key=uuid4().hex
        # Spawn and registration share the shutdown lock: close cannot take a
        # snapshot between process creation and ownership registration.
        if zhihu_call is not None:zhihu_call.check(self,platform,args,account_dir,job_id)
        with (owner_search.launch() if owner_search is not None else dy_call.launch() if dy_call is not None else zhihu_call.launch() if zhihu_call is not None else nullcontext()),self.lifecycle_lock:
            if self.closed: raise RuntimeError('工作台正在关闭，不能启动新的 CLI 操作')
            if owned_input is not None and bilibili_stop_event.is_set():raise RuntimeError('B站本人核对已取消，本次未启动')
            self._guard_platform(platform)
            # Close the gap between the earlier account_spec check and spawn:
            # a phone warning may have been recorded by another request thread.
            if platform=='xiaohongshu' and account_dir:
                self.require_account_safe(platform,account_dir)
            if dy_call is not None:
                dy_call.check(self,platform,args,account_dir,job_id)
                self.require_account_safe(platform,account_dir)
                dy_call.check_spec(spec)
            if owner_search is not None:
                owner_search.check(self,platform,args,account_dir,job_id)
                owner_search.check_spec(spec)
            env=dict(os.environ)
            if platform=='zhihu' or dy_call is not None:
                for key in list(env):
                    if key.upper().startswith('OPENCLI_') or key.upper() in ('NODE_OPTIONS','NODE_PATH'):env.pop(key)
            stdin={'stdin':subprocess.PIPE} if owned_input is not None else {}
            if owner_job is not None:owner_job.spawn_attempted=True
            try:process=subprocess.Popen(spec['argv'],shell=False,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,encoding='utf-8',errors='replace',env={**env,**spec['env']},cwd=spec['cwd'],creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0),**stdin)
            except OSError:
                if platform=='xiaohongshu':self._record_cli_outcome(spec,args,'start_failed')
                raise
            if owner_job is not None:
                owner_job.process,owner_job.process_key=process,process_key
                owner_job.directory=Path(account_dir).resolve()
            self.processes[process_key]=process
            if platform=='xiaohongshu' and account_dir:
                self.process_accounts[process_key]=Path(account_dir).resolve()
            if job_id: self.job_processes[job_id]=process
        try:
            stdout,stderr=(process.communicate(input=owned_input,timeout=timeout) if owned_input is not None
                           else process.communicate(timeout=timeout))
            if owner_search is not None and (type(stdout) is not str or len(stdout.encode('utf8'))>1048576):raise ValueError('本人首作品页输出超界')
            if zhihu_call is not None and (type(stdout) is not str or len(stdout.encode('utf8'))>65536):raise ValueError('知乎本人输出超出固定范围')
            if dy_call is not None and (type(stdout) is not str or len(stdout.encode('utf8')) > 131072):
                raise ValueError('抖音单页评论输出超出本次范围')
            if platform=='zhihu' and process.returncode==66:return []
            if platform=='zhihu' and process.returncode in (69,75,77):
                raise RuntimeError({69:'知乎窗口连接不可用，请回到账号向导检查连接',75:'知乎操作超时；涉及发布时请人工核实结果，不要重复发送',77:'知乎账号需要登录，请在独立账号窗口完成登录'}[process.returncode])
            if process.returncode:
                if platform=='xiaohongshu':
                    try:
                        failure=_cli_json(stdout)
                    except (ValueError,TypeError):
                        self._record_cli_outcome(spec,args,'protocol_error',process.returncode)
                        raise RuntimeError('CLI 返回无效结果（protocol_error）；请核实账号和操作结果，不会自动重试') from None
                    self._record_cli_outcome(spec,args,'process_failed',process.returncode,stdout)
                    code=_xhs_error_code(failure)
                    if code:_raise_xhs_cli_error(code)
                raise RuntimeError('CLI 执行失败或已取消（退出码 %s）；请检查登录及配置。'%process.returncode)
            try:payload=_cli_json(stdout) if platform=='xiaohongshu' or zhihu_call is not None else json.loads(stdout)
            except (ValueError,TypeError):
                if platform=='xiaohongshu':self._record_cli_outcome(spec,args,'protocol_error')
                raise RuntimeError('CLI 返回无效结果；请核实账号和操作结果') from None
            if dy_call is not None:
                from assistant.owner_douyin_read import _OwnerDouyinCommentsCall
                if type(dy_call) is _OwnerDouyinCommentsCall:dy_call.validate_payload(payload)
            code=_xhs_error_code(payload) if platform=='xiaohongshu' else ''
            if isinstance(payload,dict) and (payload.get('ok') is False or code
                    or platform=='xiaohongshu' and payload.get('error') is not None):
                if platform=='xiaohongshu':self._record_cli_outcome(spec,args,'protocol_error',process.returncode,stdout)
                if code:_raise_xhs_cli_error(code)
                raise RuntimeError('CLI 返回失败，请检查账号登录与平台限制')
            if platform=='xiaohongshu' and not isinstance(payload,(dict,list)):
                self._record_cli_outcome(spec,args,'protocol_error')
                raise RuntimeError('CLI 返回无效结果；请核实账号和操作结果，不会自动重试')
            if platform=='xiaohongshu' and args and args[0]=='reply' and (not isinstance(payload,dict) or payload.get('ok') is not True):
                self._record_cli_outcome(spec,args,'protocol_error')
                raise RuntimeError('回复结果不明确，请人工核实，不会自动重试')
            if platform=='xiaohongshu':self._record_cli_outcome(spec,args,'completed',process.returncode)
            return payload
        except subprocess.TimeoutExpired:
            if owner_job is not None:
                raise RuntimeError('本人本次采集超时，保留原进程等待收尾') from None
            if owner_search is not None:
                raise RuntimeError("本人首作品页超时，保留原进程直至物理收尾确认") from None
            if dy_call is not None:
                # Original finally retains this exact owned process and
                # performs bounded terminate/wait/kill/wait cleanup. Pipes
                # held after timeout must not block that owner indefinitely.
                raise RuntimeError('抖音本次只读读取超时，请先完成进程收尾；结果未确认') from None
            if zhihu_call is not None:
                # Same-owner bounded cleanup in finally; do not wait forever
                # for communicate() before retaining the unknown process.
                raise RuntimeError('知乎本人只读核对超时，请先完成进程收尾') from None
            process.kill(); process.communicate()
            if platform=='xiaohongshu':self._record_cli_outcome(spec,args,'timeout',process.returncode)
            raise RuntimeError('CLI 超时，已终止；外部操作结果需人工核实')
        finally:
            if owner_job is not None:
                owner_job.finish_process()
            elif owner_search is not None:
                from assistant.owner_single_keyword_search import _XhsOwnerSearchCleanupPending
                pending=_XhsOwnerSearchCleanupPending(self,process,process_key,job_id,account_dir)
                if not pending.finish():raise pending
            elif zhihu_call is not None:
                from .zhihu_owned_identity import _ZhihuIdentityCleanupPending
                pending=_ZhihuIdentityCleanupPending(self,process,process_key,job_id)
                if not pending.finish():raise pending
            elif dy_call is not None:
                from .douyin_owned_comments import _DouyinCommentCleanupPending
                pending=_DouyinCommentCleanupPending(self,process,process_key,job_id)
                if not pending.finish():raise pending
            elif owned_input is not None:
                pending=_BilibiliOwnedCleanupPending(self,process,process_key,job_id)
                if not pending.finish():raise pending
            else:
                with self.lifecycle_lock:
                    self.processes.pop(process_key,None)
                    self.process_accounts.pop(process_key,None)
                    if job_id and self.job_processes.get(job_id) is process: self.job_processes.pop(job_id,None)

    def cancel(self,job_id):
        page_cancelled=self.xhs_page_runtime.cancel(job_id) if self.xhs_page_runtime else False
        with self.lifecycle_lock:
            event=self.http_jobs.get(job_id)
            if event:event.set()
            process=self.job_processes.get(job_id)
        if process and process.poll() is None:
            try: process.terminate(); return True
            except OSError: return False
        return bool(event) or page_cancelled

    def abort_active(self):
        """Terminate current CLI processes; a later cloud release can start new work."""
        with self.lifecycle_lock:
            owned=list(self.processes.values())
        stopped=0
        for process in owned:
            if process.poll() is None:
                try:process.terminate();stopped+=1
                except OSError:pass
        return stopped+(self.xhs_page_runtime.abort_active() if self.xhs_page_runtime else 0)

    def abort_account(self,account_dir):
        """Stop only CLI processes using this Xiaohongshu account directory."""
        target=Path(account_dir).resolve()
        with self.lifecycle_lock:
            owned=[process for key,process in self.processes.items()
                   if self.process_accounts.get(key)==target]
        stopped=0
        for process in owned:
            if process.poll() is None:
                try:process.terminate();stopped+=1
                except OSError:pass
        return stopped+(self.xhs_page_runtime.abort_account(account_dir) if self.xhs_page_runtime else 0)

    def close(self):
        with self.lifecycle_lock:
            self.closed=True; self.close_event.set()
            owned=list(self.processes.values())
            self.processes.clear(); self.job_processes.clear()
            self.process_accounts.clear()
        for process in owned:
            if process.poll() is None:
                try: process.terminate()
                except OSError: pass
        deadline=time.monotonic()+2
        for process in owned:
            try: process.wait(timeout=max(0,deadline-time.monotonic()))
            except subprocess.TimeoutExpired:
                try: process.kill()
                except OSError: pass
            except OSError: pass
        if self.xhs_page_runtime:self.xhs_page_runtime.close()
        return {'closed':True,'owned_processes':len(owned)}

    def manifests(self):
        result = {key: {'id':key,'name':name,'verified':False,'status':'待配置'} for key,name in PLATFORMS}
        for root in (self.root,self.local_root):
            if not root or not root.exists(): continue
            for path in sorted(root.glob('*.json')):
                try:
                    item=json.loads(path.read_text(encoding='utf-8-sig'))
                    if isinstance(item,dict) and safe_platform_id(item.get('id')):
                        result[item['id']]={**result.get(item['id'],{}),**item}
                except (ValueError,OSError):
                    continue
        for item in result.values():
            executable=item.get('executable','')
            item['available']=item.get('id')=='wechat_channels' and item.get('transport')=='wx_channel_http' or bool(executable and shutil.which(executable))
            item['status']='可运行' if item.get('search_verified') and item['available'] else '待验证/待安装'
        return list(result.values())

    def _wechat_read(self,operation,task):
        with self.lifecycle_lock:
            if self.closed: raise RuntimeError('工作台正在关闭')
        self.manifest('wechat_channels')
        with self.channel_guard: lock=self.channel_locks.setdefault('wechat_channels:single-local-session',threading.Lock())
        if not lock.acquire(blocking=False): raise AdapterBusy('视频号本机单会话正在读取，请稍后重试')
        try:
            event=threading.Event()
            with self.lifecycle_lock:
                if self.closed:raise RuntimeError('工作台正在关闭')
                if task.get('id'):self.http_jobs[task['id']]=event
            preview=task.get('_wechat_preview_call')
            client=wechat_channels.Client(task.get('_account_dir'),lambda:self.close_event.is_set() or event.is_set(),
                _preview_call=preview)
            return client.check() if operation=='check' else getattr(client,operation)(task)
        finally:
            with self.lifecycle_lock:self.http_jobs.pop(task.get('id'),None)
            lock.release()

    def search(self, platform, task, verification=False):
        self._guard_platform(platform)
        call=task.get('_douyin_search_call')
        if call is not None:
            from .douyin_owned_search import _DouyinSearchCall
            if type(call) is not _DouyinSearchCall or platform!='douyin':
                raise ValueError('抖音搜索不能借其他用途或平台')
            call.check()
            payload=self.execute(platform,list(call.args),task.get('_account_dir'),task.get('id'),
                _douyin_search_call=call)
            if (type(payload) is not list or len(payload)>task['daily_limit']
                    or any(type(x) is not dict or set(x)!={'aweme_id','desc','author','uid','time','plays'}
                        or type(x['aweme_id']) is not str or re.fullmatch(r'[0-9]{1,24}',x['aweme_id']) is None
                        or type(x['desc']) is not str or len(x['desc'])>80
                        or type(x['author']) is not str or len(x['author'])>160
                        or type(x['uid']) is not str or len(x['uid'])>160
                        or x['uid'] and re.fullmatch(r'[0-9]{1,160}',x['uid']) is None
                        or type(x['time']) is not int or x['time']<0
                        or type(x['plays']) is not int or x['plays']<0 for x in payload)):
                raise RuntimeError('抖音首作品页输出或数量不明确，结果未接受')
            rows=self.map_items(payload,'douyin_bridge','douyin')
            task['_page_info']={'has_more':None,'cursor':'','bounded':True}
            return rows
        if platform=='wechat_channels': return self._wechat_read('search',task)
        if platform=='kuaishou': raise RuntimeError('快手适配器仅支持指定作品评论采集，不支持关键词搜索')
        manifest=next((x for x in self.manifests() if x['id']==platform),None)
        page_route=(platform=='xiaohongshu' and self.xhs_page_runtime is not None)
        if not manifest or not manifest.get('available') and not page_route:
            raise RuntimeError('没有找到此平台工具，请到账号页面检查平台连接。')
        if platform=='xiaohongshu' and self.xhs_page_runtime is not None:
            from assistant.xhs_page_read_policy import current_read_decision
            runtime=self.xhs_page_runtime
            decision=current_read_decision(runtime.core)
            # The global legacy CLI bool cannot skip this route/account review.
            task_id=task.get('id')
            current=runtime.core.store.get('tasks',task_id) if task_id else None
            with runtime.lock:
                scope=runtime.jobs.get(task_id)
            user=(runtime.core.store.get('users',scope.user_id)
                  if current is not None and scope is not None else None)
            if decision is None or not verification and (not user or not decision.is_verified(user,current)):
                raise RuntimeError('当前页面路线和账号尚未通过首次只读搜索验证')
        elif not manifest.get('search_verified') and not verification and task.get('_xhs_owner_search_call') is None:
            raise RuntimeError('此平台尚未验证搜索，请管理员到账号页面点击验证搜索后继续。')
        if platform=='zhihu':
            payload=self.execute(platform,zhihu.search_args(task),task.get('_account_dir'),task.get('id'),timeout=140)
            task['_page_info']={'has_more':False,'bounded':True}
            return zhihu.map_search(payload)
        arguments=manifest.get('search_args',[])
        if not isinstance(arguments,list) or not arguments or not all(isinstance(x,str) for x in arguments):
            raise RuntimeError('适配器缺少安全的 search_args 参数数组')
        values={'keyword':' '.join(task.get('keywords',[])), 'limit':str(task.get('daily_limit',20)), 'date_from':task.get('date_from',''),'date_to':task.get('date_to',''),'page':str(task.get('next_page',1))}
        if manifest.get('mapper')=='douyin_bridge':
            if not task.get('_conn_id'): raise RuntimeError('请先明确选择抖音浏览器连接 conn_id')
            values.update(conn_id=task['_conn_id'],limit='20')
        args=[x.format_map(values) for x in arguments]
        if manifest.get('mapper')=='douyin_bridge':
            offset=str((max(1,int(task.get('next_page',1)))-1)*20)
            if '--offset' in args:args[args.index('--offset')+1]=offset
            else:args+=['--offset',offset]
        if manifest.get('mapper')=='xhs_v1' and '--page' not in args: args+=['--page',values['page']]
        natural_search=(platform=='xiaohongshu' and getattr(self.xhs_page_runtime,'natural_mode',False))
        if natural_search and task.get('search_range') is not None:
            args+=['--range-checkpoint',json.dumps(task['search_range'],ensure_ascii=True,separators=(',',':'))]
        owner_search=task.get('_xhs_owner_search_call')
        if owner_search is None:payload=self.execute(platform,args,task.get('_account_dir'),task.get('id'))
        else:
            from assistant.owner_single_keyword_search import check_adapter_call,validate_payload
            check_adapter_call(self,platform,args,task.get('_account_dir'),task.get('id'),owner_search)
            payload=self.execute(platform,args,task.get('_account_dir'),task.get('id'),_owner_keyword_call=owner_search)
            validate_payload(payload)
        raw=payload.get('data',payload) if isinstance(payload,dict) else {}
        task['_page_info']={'has_more':raw.get('has_more') if isinstance(raw,dict) else None}
        try:
            if natural_search and isinstance(payload,dict) and payload.get('_transport')=='natural_dom':
                from xhs_natural_search import map_notes,validate_result
                data=validate_result(payload)
                items=map_notes(payload)
                task['_page_info']={'mode':'natural_dom','range_state':data['range']['state'],
                                    'search_range':data['range']}
            else:items=self.map_items(payload,manifest.get('mapper'),platform)
            if manifest.get('mapper')=='douyin_bridge':
                page=int(task.get('next_page',1));limit=int(task.get('search_pages',3))
                task['_page_info']={'has_more':bool(items) and page<limit,'bounded':page>=limit}
            if not isinstance(items,list) or not all(isinstance(x,dict) for x in items):
                raise RuntimeError('CLI 输出不符合规范 JSON 列表')
            if platform not in BUILTIN_IDS and any(not (item.get('source_id') or item.get('url')) for item in items): raise RuntimeError('通用标准数据每条必须包含 source_id 或 url')
        except Exception:
            if platform=='xiaohongshu':_record_xhs_display(task.get('_account_dir'),'search',payload,status='unrecognized')
            raise
        if platform=='xiaohongshu':_record_xhs_display(task.get('_account_dir'),'search',payload,items)
        return items

    def comments(self,platform,task):
        self._guard_platform(platform)
        if platform=='wechat_channels': return self._wechat_read('comments',task)
        if platform=='zhihu':
            payload=self.execute(platform,zhihu.comment_args(task),task.get('_account_dir'),task.get('id'),timeout=180)
            task['_page_info']={'has_more':False,'bounded':True}
            return zhihu.map_comments(payload,task['note_url'])
        if platform=='kuaishou':
            manifest=self.manifest(platform)
            if not task.get('_conn_id'): raise RuntimeError('快手评论采集必须明确绑定浏览器连接 conn_id')
            pages=int(task.get('max_pages',3))
            if not 1<=pages<=10: raise RuntimeError('快手单批评论页数必须为 1—10')
            values={'note_url':task['note_url'],'conn_id':task['_conn_id'],'pages':str(pages)}
            arguments=manifest.get('comments_args')
            if not isinstance(arguments,list) or not arguments: raise RuntimeError('快手评论命令尚未配置')
            payload=self.execute(platform,[x.format_map(values) for x in arguments],task.get('_account_dir'),task.get('id'),timeout=140)
            task['_page_info']={'has_more':False}
            return self.map_kuaishou_comments(payload)
        if platform=='douyin':
            manifest=self.manifest(platform)
            if not task.get('_conn_id'): raise RuntimeError('缺少固定抖音连接 conn_id')
            match=re.search(r'/video/(\d+)',task['note_url'])
            if not match: raise RuntimeError('抖音评论任务需要完整 /video/数字ID 链接')
            if manifest.get('paged_comments'):
                state,request=page_request(task)
                parent_text=state['replies'][0].get('text','') if request['parent'] else ''
                values={'source_id':match.group(1),'limit':str(min(20,int(task.get('daily_limit',20)))),'conn_id':task['_conn_id'],'cursor':request['cursor']}
                args=[x.format_map(values) for x in manifest['comments_args']]
                if request['parent']: args+=['--parent',request['parent']]
                payload=self.execute(platform,args,task.get('_account_dir'),task.get('id'),
                    _douyin_comments_call=task.get('_douyin_comments_call'))
                task['_page_info']=finish_page(state,request,payload,task.get('comment_depth','all')=='all')
                return [{'platform':platform,'source_id':'comment:'+str(x['cid']),'comment_id':str(x['cid']),
                    'note_url':task['note_url'],'url':task['note_url'],'title':str(x.get('text',''))[:100],
                    'text':x.get('text',''),'author':(x.get('user') or {}).get('nickname',''),
                    'author_id':str((x.get('user') or {}).get('uid','')),'published_at':self.timestamp(x.get('time')),
                    'region':x.get('region',''),'source_type':'comment','stage':'待核实评论',
                    'parent_id':request['parent'],'parent_text':parent_text,'comment_level':2 if request['parent'] else 1}
                    for x in payload['comments'] if x.get('cid')]
            values={'source_id':match.group(1),'limit':str(min(20,int(task.get('daily_limit',20)))),'conn_id':task['_conn_id']}
            payload=self.execute(platform,[x.format_map(values) for x in manifest['comments_args']],task.get('_account_dir'),task.get('id'))
            task['_page_info']={'has_more':False}
            if not isinstance(payload,list): raise RuntimeError('抖音评论数据结构不匹配')
            return [{'platform':platform,'source_id':'comment:'+str(x['cid']),'comment_id':str(x['cid']),'note_url':task['note_url'],'url':task['note_url'],'title':str(x.get('text',''))[:100],'text':x.get('text',''),'author':x.get('user',{}).get('nickname',''),'author_id':x.get('user',{}).get('uid',''),'published_at':self.timestamp(x.get('time')),'region':'','source_type':'comment','stage':'待核实评论'} for x in payload if x.get('cid')]
        if platform!='xiaohongshu': raise RuntimeError('当前评论采集适配器支持小红书；其他平台待接入')
        args=['comments',task['note_url'],'--json']
        if task.get('next_cursor'): args+=['--cursor',task['next_cursor']]
        owner_job=task.get('_owner_xhs_job')
        payload=(self._execute_owner_xhs(owner_job,platform,args,task.get('_account_dir'),task.get('id'))
                 if owner_job is not None else self.execute(platform,args,task.get('_account_dir'),task.get('id')))
        try:
            raw=payload.get('data',payload)
            task['_page_info']={'has_more':raw.get('has_more'),'cursor':raw.get('cursor','')}
            def incomplete_replies(item):
                if not isinstance(item,dict) or not item.get('id'):return False
                try:count=int(item.get('sub_comment_count') or 0)
                except (TypeError,ValueError):count=0
                return count>len(item.get('sub_comments') or []) or item.get('sub_comment_has_more') is True
            roots=[item for item in raw.get('comments',[]) if incomplete_replies(item)]
            task['_reply_roots']=[str(item['id']) for item in roots]
            task['_reply_pages']=[]
            for item in roots:
                inline=item.get('sub_comments')
                cursor=item.get('sub_comment_cursor')
                # The root comment's cursor follows replies already embedded in
                # this page. With no embedded replies, start at the first page.
                resume=(item.get('sub_comment_has_more') is True
                        and isinstance(inline,list) and bool(inline)
                        and all(isinstance(child,dict) and child.get('id') for child in inline)
                        and isinstance(cursor,str) and 0<len(cursor)<=512
                        and not any(char.isspace() or ord(char)<32 or ord(char)==127 for char in cursor))
                task['_reply_pages'].append({
                    'root_id':str(item['id']),
                    'cursor':cursor if resume else '',
                    'parent_text':item.get('content') if isinstance(item.get('content'),str) else ''})
            rows=self.map_comments(payload,task['note_url'])
        except Exception:
            _record_xhs_display(task.get('_account_dir'),'comments',payload,status='unrecognized')
            raise
        _record_xhs_display(task.get('_account_dir'),'comments',payload,rows)
        return rows if task.get('comment_depth','all')=='all' else [row for row in rows if not row['parent_id']]

    def sub_comments(self,platform,task):
        if platform!='xiaohongshu':raise RuntimeError('当前仅小红书支持楼中楼分页')
        note_url=task.get('note_url','')
        note_id=re.fullmatch(r'/(?:explore|search_result)/([A-Za-z0-9]+)/?',urlsplit(note_url).path)
        root_id=str(task.get('root_comment_id') or '')
        if not note_id or not root_id:raise RuntimeError('楼中楼缺少笔记或主评论 ID')
        args=['sub-comments',note_id.group(1),root_id,'--json']
        if task.get('next_cursor'):args+=['--cursor',task['next_cursor']]
        accepts_token=self.xhs_page_runtime is not None
        if not accepts_token:
            # Only a frozen runtime declaring the reviewed PR81 contract accepts
            # this flag. Unmodified 0.6.4 exits at argument parsing instead.
            manifest=next((item for item in self.manifests() if item['id']==platform),{})
            executable=manifest.get('executable')
            if executable:
                try:
                    guard=json.loads((Path(executable).parent/'guard-manifest.json').read_text('utf-8'))
                    accepts_token=isinstance(guard,dict) and guard.get('sub_comments_query')=='upstream_pr81'
                except (OSError,ValueError,TypeError):pass
        if accepts_token:
            token=parse_qs(urlsplit(note_url).query).get('xsec_token',[''])[0]
            if token:args+=['--xsec-token',token]
        if self.xhs_page_runtime is not None:
            source=parse_qs(urlsplit(note_url).query).get('xsec_source',[''])[0]
            if source:args+=['--xsec-source',source]
            if getattr(self.xhs_page_runtime,'natural_mode',False):args+=['--note-url',note_url]
        payload=self.execute(platform,args,task.get('_account_dir'),task.get('id'))
        try:
            raw=payload.get('data',payload)
            if not isinstance(raw,dict) or not isinstance(raw.get('comments'),list):
                raise RuntimeError('楼中楼输出结构未识别，停止导入')
            response_root=raw.get('comment_id') or raw.get('root_comment_id')
            if response_root and str(response_root)!=root_id:
                raise RuntimeError('楼中楼返回的主评论 ID 不匹配，已保留断点')
            task['_page_info']={'has_more':raw.get('has_more'),'cursor':raw.get('cursor','')}
            rows=self.map_comments(payload,task['note_url'],parent_id=root_id)
        except Exception:
            _record_xhs_display(task.get('_account_dir'),'comments',payload,status='unrecognized')
            raise
        _record_xhs_display(task.get('_account_dir'),'comments',payload,rows)
        return rows

    @staticmethod
    def map_kuaishou_comments(payload):
        data=payload.get('data') if isinstance(payload,dict) and payload.get('ok') is True else None
        if not isinstance(data,dict) or not isinstance(data.get('comments'),list) or not data.get('photoId'): raise RuntimeError('快手评论输出结构不符合契约')
        photo_id=str(data['photoId']); url='https://www.kuaishou.com/short-video/'+photo_id
        result=[]
        for item in data['comments']:
            if not isinstance(item,dict) or not item.get('commentId'): continue
            published=item.get('createdAt') or Adapters.timestamp(item.get('timestamp'))
            result.append({'platform':'kuaishou','source_id':str(item['commentId']),'comment_id':str(item['commentId']),'parent_id':photo_id,'note_url':url,'url':url,'title':str(item.get('text',''))[:100],'text':item.get('text',''),'author':item.get('author',''),'author_id':item.get('authorId',''),'published_at':published,'region':'','source_type':'comment','stage':'待核实评论'})
        return result

    @staticmethod
    def map_comments(payload,note_url,parent_id=''):
        data=payload.get('data',payload) if isinstance(payload,dict) else None
        comments=data.get('comments') if isinstance(data,dict) else None
        if not isinstance(comments,list): raise RuntimeError('评论输出结构未识别，停止导入')
        result=[]
        queue=[(item,parent_id) for item in comments]
        while queue:
            item,parent=queue.pop(0)
            if not isinstance(item,dict): continue
            queue.extend((child,str(item.get('id') or parent)) for child in (item.get('sub_comments') or []))
            comment_id=item.get('id')
            if not comment_id: continue
            stamp=item.get('create_time'); published=''
            if isinstance(stamp,(int,float)):
                try: published=datetime.fromtimestamp(stamp/1000 if stamp>100000000000 else stamp).isoformat(timespec='seconds')
                except (ValueError,OSError,OverflowError): pass
            user=item.get('user_info') if isinstance(item.get('user_info'),dict) else {}
            result.append({'platform':'xiaohongshu','source_id':'comment:'+str(comment_id),'comment_id':str(comment_id),'parent_id':parent,'comment_level':2 if parent else 1,'note_url':note_url,'url':note_url,'title':str(item.get('content',''))[:100],'text':item.get('content',''),'author':user.get('nickname',''),'author_id':user.get('user_id',''),'author_avatar_url':xhs_first_image(user.get('image'),user.get('avatar'),user.get('avatar_url')),'region':item.get('ip_location',''),'published_at':published,'stage':'待核实评论','source_type':'comment',**_xhs_reply_target(item)})
        return result

    def send(self,platform,lead,text,account_dir):
        self._guard_platform(platform)
        if platform=='wechat_channels': raise RuntimeError('视频号当前只支持读取，不支持发送回复或私信')
        if platform=='kuaishou': raise RuntimeError('快手当前只读采集，不支持自动发送，请复制审核后的回复到原帖人工处理')
        manifest=self.manifest(platform)
        if lead.get('_message_channel')=='dm':
            if platform!='douyin' or not manifest.get('dm_contract_verified') or not lead.get('_conn_id'):
                raise RuntimeError('此账号私信能力尚未准备好')
            recipient=str(lead.get('author_id') or '')
            if not re.fullmatch(r'[1-9]\d*',recipient): raise RuntimeError('缺少有效的抖音客户用户 ID')
            entry=manifest['search_args'][0]
            payload=self.execute(platform,[entry,'dm','send',recipient,text,'--conn-id',lead['_conn_id'],'--no-store','--no-log'],account_dir,timeout=95)
            if not isinstance(payload,dict) or payload.get('status')!='sent' or not re.fullmatch(r'[1-9]\d*',str(payload.get('message_id') or '')):
                raise RuntimeError('私信结果不明，禁止重试')
            return {'success':True,'source_id':str(payload['message_id'])}
        if platform=='douyin':
            if not manifest.get('reply_contract_verified') or not lead.get('_conn_id'): raise RuntimeError('抖音发送契约或固定连接未准备好')
            match=re.search(r'/video/(\d+)',lead.get('note_url',''))
            if not match or not lead.get('comment_id'): raise RuntimeError('缺少抖音视频或评论 ID')
            # The packaged CLI's search first argument is its absolute cli.js path.
            entry=manifest['search_args'][0]
            payload=self.execute(platform,[entry,'post',match.group(1),text,'--reply-to',lead['comment_id'],'--conn-id',lead['_conn_id'],'--no-store'],account_dir,timeout=95)
            if not isinstance(payload,dict) or payload.get('status')!='published' or not payload.get('cid'): raise RuntimeError('抖音回复结果不明，禁止重试')
            return {'success':True,'source_id':str(payload['cid'])}
        if platform!='xiaohongshu' or not manifest.get('reply_contract_verified'):
            raise RuntimeError('此平台回复命令契约尚未验证')
        if not lead.get('comment_id') or not lead.get('note_url'): raise RuntimeError('仅支持回复已采集评论，缺少评论 ID 或笔记链接')
        payload=self.execute(platform,['reply',lead['note_url'],'--comment-id',lead['comment_id'],'--content',text,'--json'],account_dir,timeout=35)
        if not isinstance(payload,dict) or payload.get('ok') is not True: raise RuntimeError('回复结果不明确，请人工核实，不会自动重试')
        comment_id=_xhs_sent_comment_id(payload)
        return {'success':True,**({'platform_comment_id':comment_id} if comment_id else {})}

    @staticmethod
    def timestamp(value):
        if not isinstance(value,(int,float)) or value<=0: return ''
        try: return datetime.fromtimestamp(value/1000 if value>100000000000 else value).isoformat(timespec='seconds')
        except (ValueError,OSError,OverflowError): return ''

    @staticmethod
    def map_items(payload,mapper,platform):
        if mapper=='douyin_bridge':
            if not isinstance(payload,list): raise RuntimeError('抖音 Bridge 搜索输出不是数组')
            return [{'platform':platform,'source_id':str(x['aweme_id']),'title':x.get('desc',''),'text':x.get('desc',''),'author':x.get('author',''),'author_id':x.get('uid',''),'url':'https://www.douyin.com/video/'+str(x['aweme_id']),'published_at':Adapters.timestamp(x.get('time')),'region':'','source_type':'note','stage':'待核实视频'} for x in payload if x.get('aweme_id')]
        if mapper=='xhs_v1':
            data=payload.get('data',payload) if isinstance(payload,dict) else payload
            items=data.get('items') if isinstance(data,dict) else data
            if not isinstance(items,list): raise RuntimeError('小红书搜索输出结构已变化，不能猜测映射')
            result=[]
            for item in items:
                card=item.get('note_card')
                if not isinstance(card,dict) or not item.get('id'): continue
                token=item.get('xsec_token') or card.get('xsec_token') or ''
                user=card.get('user') if isinstance(card.get('user'),dict) else {}
                cover=card.get('cover')
                images=card.get('image_list') if isinstance(card.get('image_list'),list) else []
                first_image=images[0] if images else None
                mapped={'platform':platform,'source_id':str(item['id']),'title':card.get('display_title') or card.get('title',''),'author':user.get('nickname',''),'author_id':user.get('user_id',''),'author_avatar_url':xhs_first_image(user.get('avatar'),user.get('image'),user.get('avatar_url')),'cover_url':xhs_first_image(cover,first_image),'text':card.get('desc',''),'url':'https://www.xiaohongshu.com/explore/'+str(item['id'])+('?' + urlencode({'xsec_token':token,'xsec_source':'pc_search'}) if token else ''),'grade':'C','stage':'待核实（笔记，非已确认客户）','source_type':'note'}
                published=Adapters.timestamp(card.get('create_time') or card.get('publish_time') or card.get('time'))
                if published:mapped['published_at']=published
                result.append(mapped)
            return result
        if mapper=='weibo_cards':
            data=payload.get('data',payload)
            if isinstance(data,dict) and isinstance(data.get('data'),dict): data=data['data']
            cards=data.get('cards') if isinstance(data,dict) else None
            if not isinstance(cards,list): raise RuntimeError('微博搜索输出结构已变化，不能猜测映射')
            posts=[]
            for card in cards:
                if card.get('mblog'): posts.append(card['mblog'])
                posts.extend(x['mblog'] for x in card.get('card_group',[]) if x.get('mblog'))
            result=[]
            for post in posts:
                source_id=str(post.get('idstr') or post.get('id') or '')
                if not source_id: continue
                text=unescape(re.sub('<[^>]+>','',post.get('text','')))
                result.append({'platform':platform,'source_id':source_id,'title':text[:100],'text':text,'author':post.get('user',{}).get('screen_name',''),'url':'https://weibo.com/'+str(post.get('user',{}).get('id',''))+'/'+str(post.get('bid',source_id)),'published_at':post.get('created_at',''),'region':post.get('region_name',''),'stage':'待核实','source_type':'note'})
            return result
        if mapper=='opencli_douyin':
            if not isinstance(payload,list): raise RuntimeError('抖音搜索输出结构已变化，不能猜测映射')
            result=[]
            for item in payload:
                url=item.get('url',''); match=re.search(r'/video/(\d+)',url)
                if not match: continue
                result.append({'platform':platform,'source_id':match.group(1),'title':item.get('desc',''),'text':item.get('desc',''),'author':item.get('author',''),'url':url,'stage':'待核实'})
            return result
        return payload.get('items') if isinstance(payload,dict) else payload

    def verify(self,platform,keyword,account_dir=None,conn_id=None,*,read_scope=None,page_read_decision=None):
        page_route=(platform=='xiaohongshu' and self.xhs_page_runtime is not None)
        if page_route or page_read_decision is not None:
            from assistant.xhs_page_read_policy import _PageReadDecision,current_read_decision
            if (not page_route or type(page_read_decision) is not _PageReadDecision
                    or read_scope is None or read_scope.runtime is not self.xhs_page_runtime
                    or current_read_decision(read_scope.runtime.core) is not page_read_decision):
                raise ValueError('页面搜索验证须使用原私有只读审查和结果范围')
        with read_scope if read_scope is not None else nullcontext():
            self.search(platform,{'keywords':[keyword],'daily_limit':1,'_account_dir':account_dir,'_conn_id':conn_id},verification=True)
        def commit():
            self.local_root.mkdir(parents=True,exist_ok=True)
            path=self.local_root/(platform+'.json')
            previous=json.loads(path.read_text(encoding='utf-8')) if path.exists() else {'id':platform}
            previous['search_verified']=True
            path.write_text(json.dumps(previous,ensure_ascii=False,indent=2),encoding='utf-8')
        if page_read_decision is not None:
            read_scope.commit_result(lambda:page_read_decision.record_verified(read_scope))
        elif read_scope is None:
            commit()
        else:
            read_scope.commit_result(commit)
        return {'verified':True,'platform':platform,'message':'只读搜索与输出结构验证通过；未发送任何消息'}
