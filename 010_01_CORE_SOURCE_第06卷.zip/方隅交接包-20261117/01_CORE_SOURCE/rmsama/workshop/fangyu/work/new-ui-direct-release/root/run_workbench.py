"""Launch one installed code release using the existing owner's normal App.

No update transaction, process-wide WMI scan, PID cache, or old-version fallback.
The App retains its original instance lock and all account/business checks.
"""
from pathlib import Path, PurePosixPath
import ctypes
from ctypes import wintypes
import datetime
import hashlib
import importlib
import json
import os
import stat
import sys
import uuid

PROJECT = Path('C:/积木软件工坊/项目/方隅公寓客户版')
RELEASE = PROJECT / 'work/ui-runtime-r55'
SOURCE = RELEASE / 'src'
MANIFEST_SHA256 = 'E4E33FDA9699EB610F7E092A2F23C4A39AD3AB2F8505895BB194BD9D09606CF5'
PILOT = PROJECT / 'work/self-operating-pilot'
RUNTIME = PROJECT / 'work/product-upgrade-20261009/cli-current-wrapper-component-candidate-v6/artifacts/platform-cli-guarded'
REVIEW = PILOT / 'component-review.json'
REVIEW_SHA256 = 'C689C9F4CDF3A6030284C48E2164E18D7910B6AEE49BD989D6D07E7C2CDE1857'
OWNER_DATA_SHA256 = 'DBFCBB2C4C0A1ED481930F03332711A39FB478DB834D234EF35A562C0DA504A9'
STATUS_ROOT = PROJECT / 'work/new-ui-direct-release/launch-status'


class LaunchError(RuntimeError):
    def __init__(self, code):
        self.code = code
        super().__init__(code)


def plain(path, *, directory=False):
    path = Path(path)
    path.relative_to(PROJECT)
    for ancestor in (path, *path.parents):
        info = ancestor.lstat()
        if ancestor.is_symlink() or getattr(info, 'st_file_attributes', 0) & 0x400:
            raise LaunchError('PATH')
    info = path.lstat()
    if not (stat.S_ISDIR(info.st_mode) if directory else stat.S_ISREG(info.st_mode)):
        raise LaunchError('PATH')
    if not directory and info.st_nlink != 1:
        raise LaunchError('PATH')
    return info


def checked_bytes(path, expected=None, max_bytes=None):
    before = plain(path)
    if max_bytes is not None and before.st_size > max_bytes:
        raise LaunchError('SIZE')
    with Path(path).open('rb') as stream:
        opened = os.fstat(stream.fileno())
        if (opened.st_dev, opened.st_ino) != (before.st_dev, before.st_ino):
            raise LaunchError('CHANGED')
        raw = stream.read()
        after_fd = os.fstat(stream.fileno())
    after = plain(path)
    identity = lambda s: (s.st_dev, s.st_ino, s.st_size, s.st_mtime_ns)
    if not identity(before) == identity(opened) == identity(after_fd) == identity(after):
        raise LaunchError('CHANGED')
    if expected is not None and hashlib.sha256(raw).hexdigest().upper() != expected.upper():
        raise LaunchError('HASH')
    return raw


def verify_release():
    if len(MANIFEST_SHA256) != 64:
        raise LaunchError('UNBOUND')
    manifest = json.loads(checked_bytes(RELEASE / 'RELEASE.json', MANIFEST_SHA256, 2_000_000))
    if (manifest.get('schema') != 'fangyu_local_code_release_v1'
            or manifest.get('release_id') != 'ui-core-r55'
            or Path(manifest.get('project', '')) != PROJECT
            or manifest.get('source_root') != 'src'
            or type(manifest.get('files')) is not list):
        raise LaunchError('MANIFEST')
    expected_paths = set()
    for item in manifest['files']:
        rel = PurePosixPath(item['path'])
        if (rel.is_absolute() or not rel.parts or '..' in rel.parts
                or ':' in str(rel) or '\\' in str(rel) or str(rel) in expected_paths):
            raise LaunchError('MANIFEST')
        if not (rel.parts[0] in ('src', 'mirrors') or rel.parts[:2] == ('work', 'runtime')):
            raise LaunchError('MANIFEST')
        expected_paths.add(str(rel))
        raw = checked_bytes(RELEASE / str(rel), item['sha256'])
        if len(raw) != item['size']:
            raise LaunchError('SIZE')
    actual_paths = set()
    for subtree in ('src', 'work/runtime', 'mirrors'):
        plain(RELEASE / subtree, directory=True)
        for path in (RELEASE / subtree).rglob('*'):
            info = path.lstat()
            if stat.S_ISDIR(info.st_mode):
                plain(path, directory=True)
            else:
                plain(path)
                actual_paths.add(path.relative_to(RELEASE).as_posix())
    if actual_paths != expected_paths:
        raise LaunchError('CONTENTS')
    return manifest


def verify_existing_owner():
    # Metadata only. Never read/hash/copy a database or platform session here.
    plain(PILOT, directory=True)
    plain(PILOT / 'data', directory=True)
    checked_bytes(PILOT / 'data/owner-data-instance.json', OWNER_DATA_SHA256, 4096)
    plain(PILOT / 'data/workspace.sqlite3')
    checked_bytes(REVIEW, REVIEW_SHA256, 16384)
    marker = json.loads(checked_bytes(PILOT / 'self-operating-instance.json', max_bytes=8192))
    product = {'owner_read_instance_v1': 'xiaohongshu_v1',
               'owner_read_instance_v2': 'primary_platforms_v2'}.get(marker.get('schema'))
    if product is None:
        raise LaunchError('OWNER')
    from assistant.self_operating_read import open_owner_read_instance
    wrapper = hashlib.sha256(checked_bytes(SOURCE / 'platform_cli.py')).hexdigest()
    instance = open_owner_read_instance(str(PILOT), str(PROJECT / 'work'), wrapper,
                                        product=product, existing_only=True)
    config = instance.check()
    binding = json.loads(checked_bytes(PILOT / 'data/owner-data-instance.json', OWNER_DATA_SHA256, 4096))
    if binding['instance_id'] != config['selfOperatingRead']['instance_id']:
        raise LaunchError('OWNER')
    return product


def write_event(attempt, event, **facts):
    # Each event is exclusive and contains only version, phase and code locations.
    if attempt is None:
        return False
    try:
        plain(attempt, directory=True)
        value = {'schema': 'fangyu_direct_launch_event_v1', 'event': event,
                 'release_id': 'ui-core-r55', 'pid': os.getpid(),
                 'time_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), **facts}
        with (attempt / (event + '.json')).open('x', encoding='utf-8') as stream:
            json.dump(value, stream, ensure_ascii=False, indent=2)
            stream.write('\n')
        return True
    except Exception:
        # Diagnostics must never prevent a working window from opening/closing.
        return False


def safe_error(error):
    frames = []
    tb = error.__traceback__
    while tb is not None:
        code = tb.tb_frame.f_code
        path = Path(code.co_filename)
        label = path.relative_to(PROJECT).as_posix() if path.is_relative_to(PROJECT) else path.name
        frames.append({'file': label, 'function': code.co_name, 'line': tb.tb_lineno})
        tb = tb.tb_next
    return {'exception_type': type(error).__name__, 'frames': frames[-12:]}


def notify_failure(stage, error):
    reasons = {
        'files': '新版程序文件不完整或已被改动。',
        'imports': '新版程序所需的运行组件加载失败。',
        'owner': '当前工作台的数据绑定或运行许可未通过校验。',
        'application': '程序启动或窗口运行发生错误。',
    }
    reason = reasons.get(stage, '无法创建启动诊断记录。')
    code = 'R55-' + stage.upper()
    if isinstance(error, OSError):
        reason = '程序访问文件或运行组件时失败。'
    if os.name == 'nt':
        user32 = ctypes.WinDLL('user32', use_last_error=True)
        user32.MessageBoxW.argtypes = (wintypes.HWND, wintypes.LPCWSTR, wintypes.LPCWSTR, wintypes.UINT)
        user32.MessageBoxW(None, reason + '\n\n错误编号：' + code + '\n本次启动已结束。',
                          '方隅工作台 · 启动失败', 0x10)


def main():
    stage, attempt = 'diagnostics', None
    try:
        try:
            plain(STATUS_ROOT.parent, directory=True)
            STATUS_ROOT.mkdir(exist_ok=True)
            plain(STATUS_ROOT, directory=True)
            attempt = STATUS_ROOT / uuid.uuid4().hex
            attempt.mkdir()
        except Exception:
            attempt = None
        write_event(attempt, 'started')
        stage = 'files'
        verify_release()
        write_event(attempt, 'files_verified', manifest_sha256=MANIFEST_SHA256)
        stage = 'imports'
        # Fresh -I process: one app module, one ROOT, no historic helper imports.
        sys.path.insert(0, str(SOURCE))
        app = importlib.import_module('app')
        desktop = importlib.import_module('desktop')
        if Path(app.__file__) != SOURCE / 'app.py' or Path(desktop.__file__) != SOURCE / 'desktop.py':
            raise LaunchError('MODULE')
        stage = 'owner'
        product = verify_existing_owner()
        write_event(attempt, 'owner_verified')
        native_run = desktop.run_desktop
        def observed_native(server, url, data_dir, title, ready_callback=None, ready_timeout=None):
            def on_ready(window):
                if ready_callback is not None:
                    ready_callback(window)
                write_event(attempt, 'native_ready')
            return native_run(server, url, data_dir, title, ready_callback=on_ready,
                              ready_timeout=ready_timeout)
        desktop.run_desktop = observed_native
        sys.argv = [str(SOURCE / 'app.py'), '--self-operating-read', str(PILOT),
                    '--guarded-cli-runtime', str(RUNTIME), '--runtime-license-review', str(REVIEW),
                    '--runtime-license-review-sha256', REVIEW_SHA256]
        if product == 'primary_platforms_v2':
            sys.argv.append('--owner-primary-platforms')
        stage = 'application'
        app.main()
        write_event(attempt, 'closed')
        return 0
    except SystemExit as error:
        if error.code is None or error.code == 0:
            return 0
        if attempt is not None:
            write_event(attempt, 'failed', stage=stage, **safe_error(error))
        notify_failure(stage, error)
        return 1
    except Exception as error:
        if attempt is not None:
            try:
                write_event(attempt, 'failed', stage=stage, **safe_error(error))
            except OSError:
                pass
        notify_failure(stage, error)
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
