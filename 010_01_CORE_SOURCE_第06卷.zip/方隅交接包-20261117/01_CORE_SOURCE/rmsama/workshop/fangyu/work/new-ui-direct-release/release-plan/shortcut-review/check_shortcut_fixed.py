from pathlib import Path
import ast, contextlib, hashlib, io, json, os, types, uuid

OWN = Path(__file__).resolve().parent
INSTALLER = OWN.parent.parent / 'root/install_desktop_entry.py'
RAW = INSTALLER.read_bytes()
RUN = OWN / 'owned' / ('fixed-' + uuid.uuid4().hex)
RUN.mkdir(parents=True)

def digest(data):
    return hashlib.sha256(data).hexdigest().upper()

def write(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as stream:
        stream.write(data)

def run_case(name):
    case = RUN / name
    m = types.ModuleType('owned_installer_' + name)
    m.__file__ = str(INSTALLER)
    exec(compile(RAW, str(INSTALLER), 'exec'), m.__dict__)
    m.PROJECT = case / 'project'
    m.OWN = m.PROJECT / 'work/review'
    m.SOURCE = m.OWN / 'root/run_workbench.py'
    m.TARGET = m.PROJECT / 'work/ui-runtime-r55/run_workbench.py'
    m.PYTHONW = m.PROJECT / 'work/pythonw.exe'
    m.SHORTCUT = case / 'desktop/Workbench.lnk'
    m.OLD_LAUNCHER = m.PROJECT / 'work/old.py'
    m.NEW_ARGS = '-X utf8 -B -I "' + m.TARGET.as_posix() + '"'
    m.OLD_ARGS = '-X utf8 -B -I "' + m.OLD_LAUNCHER.as_posix() + '"'
    hook = ''
    if name == 'changed_shortcut':
        hook = 'Path(' + repr(str(m.SHORTCUT)) + ').write_bytes(b"USER_CHANGED")'
    elif name == 'same_pin_foreign_shortcut':
        hook = ('p=Path(' + repr(str(m.SHORTCUT)) + '); q=p.with_suffix(".foreign"); '
                'q.write_bytes(p.read_bytes()); os.replace(q,p)')
    elif name == 'same_pin_foreign_staged':
        hook = ('p=next(Path(' + repr(str(m.OWN / 'desktop-backup')) + ').glob("*/new.lnk")); '
                'q=p.with_suffix(".foreign"); q.write_bytes(p.read_bytes()); os.replace(q,p)')
    code = ('from pathlib import Path\nimport os\nRELEASE=Path(' + repr(str(m.TARGET.parent)) + ')\n'
            'MANIFEST_SHA256="owned-recorded"\n_calls=0\ndef verify_release():\n'
            ' global _calls\n _calls+=1\n if _calls==2:\n  ' + (hook or 'pass') + '\n').encode()
    write(m.SOURCE, code)
    m.SOURCE_SHA = digest(code)
    write(m.PYTHONW, b'owned-placeholder-never-executed')
    write(m.SHORTCUT, b'OLD_LINK')
    m.OLD_SHORTCUT_SHA = digest(b'OLD_LINK')
    write(m.PROJECT / 'work/ui-runtime-r55/src/resources/brand.ico', b'owned-icon')
    counts = {'recorded_COM_save': 0, 'recorded_COM_read': 0}
    def shortcut_info(path):
        counts['recorded_COM_read'] += 1
        return {'target': str(m.PYTHONW),
                'arguments': m.NEW_ARGS if Path(path).read_bytes() == b'NEW_LINK' else m.OLD_ARGS,
                'working_directory': str(m.PROJECT), 'icon': 'owned', 'window_style': 1}
    def powershell(command):
        counts['recorded_COM_save'] += 1
        assert '$s.Save()' in command
        backups = list((m.OWN / 'desktop-backup').iterdir())
        assert len(backups) == 1
        write(backups[0] / 'new.lnk', b'NEW_LINK')
        return {'saved': True}
    m.shortcut_info, m.powershell = shortcut_info, powershell
    caught = None
    with contextlib.redirect_stdout(io.StringIO()):
        try:
            m.main()
        except ValueError as error:
            caught = str(error)
    backups = list((m.OWN / 'desktop-backup').iterdir())
    assert len(backups) == 1
    assert (backups[0] / 'original.lnk').read_bytes() == b'OLD_LINK'
    assert json.loads((backups[0] / 'original.json').read_text('utf-8'))['pin']['sha256'] == m.OLD_SHORTCUT_SHA
    receipt = m.OWN / 'ACTUAL-DESKTOP-INSTALLED.json'
    if name == 'normal':
        assert caught is None and m.SHORTCUT.read_bytes() == b'NEW_LINK'
        result = json.loads(receipt.read_text('utf-8'))
        assert result['status'] == 'INSTALLED' and result['app_launches'] == 0
        assert not (backups[0] / 'new.lnk').exists()
    else:
        assert caught is not None and not receipt.exists()
        assert (backups[0] / 'new.lnk').read_bytes() == b'NEW_LINK'
        assert m.SHORTCUT.read_bytes() == (b'USER_CHANGED' if name == 'changed_shortcut' else b'OLD_LINK')
        assert caught == ('install input hash changed' if name == 'changed_shortcut' else 'shortcut owner changed; preserve both files')
    assert m.TARGET.read_bytes() == code
    return {'case': name, 'status': 'PASS', 'caught': caught, 'original_backup_exact': True,
            'owned_root': str(case), **counts}

cases = [run_case(n) for n in ('normal', 'changed_shortcut', 'same_pin_foreign_shortcut', 'same_pin_foreign_staged')]
assert INSTALLER.read_bytes() == RAW
tree = ast.parse(RAW)
function_names = {n.name for n in tree.body if isinstance(n, ast.FunctionDef)}
assert {'plain','read_pin','powershell','main'} <= function_names
report = {
    'schema': 'fangyu_shortcut_installer_independent_review_v1',
    'status': 'PASS_SHORTCUT_INSTALLER_LIMITED',
    'installer': {'path': str(INSTALLER), 'pin': {'size': len(RAW), 'sha256': digest(RAW)}},
    'review_scope': 'Root authored installer only: fixed binding, reversible original link backup, late concurrent changes, checked-source execution, no original App invocation.',
    'cases': cases,
    'static': {
        'original_shortcut': 'C:/Users/rmsama/Desktop/方隅工作台.lnk',
        'original_shortcut_pin': {'size': 2341, 'sha256': 'F6B9CFFF37D8523413AD16ABE374F9E849843D3B6EEA5643629D8CBA20F8CE4B'},
        'new_launcher_pin': {'size': 10192, 'sha256': 'F674EBFA031019169CD0441B5066E7B4A2DDAE8774269C171B3E846A2516A3C5'},
        'new_target': 'C:/积木软件工坊/项目/方隅公寓客户版/work/ui-runtime-r55/run_workbench.py',
        'arguments': '-X utf8 -B -I with fixed absolute target',
        'original_backup': 'Exact old link bytes plus old fields/pin written before desktop replacement; unique project-owned backup.',
        'fixed_issue': 'Final staged and desktop hash plus initial identity are checked after the long public release verification; checked candidate bytes are compiled directly.',
        'process_scope': 'Only hidden noninteractive PowerShell COM link save/read; no Start-Process, App, launcher main, original guard or PID invocation.',
        'failure_scope': 'No automatic retry or rollback. Failed fixture cases retain new launcher and recoverable link backups; installation receipt is absent.'
    },
    'first_capture_note': 'reproduce_old_link_race.py loaded the already fixed current installer, so its old-success expectation failed with ValueError install input hash changed. This is fixture expectation mismatch, not old-version RED and not production failure. installer-first-reviewed.py preserves the actual captured revision.',
    'limits': ['COM save/read and full public-release verification are recorded in owned fixtures.',
               'No original desktop link was read or changed by this review.',
               'No repeat of 853 public file hashes; parent already obtained actual verify_release PASS.',
               'Final check then os.replace is a narrow optimistic concurrency check, not an OS-wide writer lock.',
               'No GUI or real business success is claimed.'],
    'real_App_guard_PID_preflight_calls': 0,
    'real_COM_calls': 0,
    'original_project_source_or_private_reads': 0,
    'original_desktop_writes': 0
}
out = OWN / 'SHORTCUT-INSTALLER-REVIEW.json'
write(out, (json.dumps(report, ensure_ascii=False, indent=2) + '\n').encode('utf-8'))
print(json.dumps({'report': str(out), 'size': out.stat().st_size, 'sha256': digest(out.read_bytes()),
                  'installer': report['installer'], 'cases': len(cases)}, ensure_ascii=False))
