"""Reuse the verified code stage; copy only three reviewed code deltas."""
from pathlib import Path
import json, shutil

here=Path(__file__).resolve().parent
root=here.parents[1]
target=root/'work/ai-connectivity-repair-20261005'
target.mkdir(exist_ok=True)
source=(here/'deploy.cjs').read_text('utf-8')
source=source.replace("../ai-config-repair-20261004/deployment.json", "../ai-workflow-repair-20261005/deployment.json")
source=source.replace("stage=path.join(__dirname,'stage')", "stage=path.join(__dirname,'../ai-workflow-repair-20261005/stage')")
source=source.replace("const allowed=['ai_contract.cjs','ai_provider.cjs','site/app.mjs','site/enterprise-ui.mjs','site/index.html'];", "const allowed=['ai_enterprise.cjs','ai_provider.cjs','site/enterprise-ui.mjs'];")
(target/'deploy.cjs').write_text(source,'utf-8')
for relative in ('ai_enterprise.cjs','ai_provider.cjs','site/enterprise-ui.mjs'):
    stage=here/'stage'/relative
    if not stage.resolve().is_relative_to((here/'stage').resolve()):
        raise ValueError('invalid_stage_target')
    shutil.copyfile(root/'work/cloud/workspace'/relative, stage)
print(json.dumps({'stage_reused':True,'copied_code_files':3,'private_data_copied':False}))
