const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const ui=fs.readFileSync(path.join(__dirname,'site/enterprise-ui.mjs'),'utf8');
const labelSource=ui.match(/export function aiModelStatus\([^]*?\n\}/)[0].replace('export ','');
const aiModelStatus=vm.runInNewContext(`${labelSource};aiModelStatus`);
const matchSource=ui.match(/export function aiConfigFieldsMatch\([^]*?\n\}/)[0].replace('export ','');
const aiConfigFieldsMatch=vm.runInNewContext(`${matchSource};aiConfigFieldsMatch`);
const financialSource=ui.match(/export function employeeAiFinancialText\([^]*?\n\}/)[0].replace('export ','');
const employeeAiFinancialText=vm.runInNewContext(`${financialSource};employeeAiFinancialText`);
const statusSource=ui.match(/export function analysisStatusView\([^]*?\n\}/)[0].replace('export ','');
const analysisStatusView=vm.runInNewContext(`${financialSource};${statusSource};analysisStatusView`);
const catalog=[{id:'gpt-6.1-sol',provider:'openai',label:'GPT-6.1 Sol',reasoning_efforts:['low','medium','high','xhigh','max']},
 {id:'gpt-5.4-mini',provider:'openai',label:'GPT-5.4 Mini',reasoning_efforts:['none','low','medium','high','xhigh']},
 {id:'deepseek-flash',provider:'deepseek',label:'DeepSeek Flash',reasoning_efforts:[]}];
const config={provider:'openai',model:'gpt-6.1-sol',enabled:true,configured:true,reasoning_effort:'low',revision:2,model_catalog:catalog,
 providers:{openai:{configured:true,model:'gpt-6.1-sol',reasoning_effort:'low'},deepseek:{configured:true,model:'deepseek-flash'}}};
test('model status follows configured, busy and actual identity and refuses invented names',()=>{
 assert.equal(aiModelStatus(),'AI 待配置');
 assert.equal(aiModelStatus({profile:{...config,enabled:false}}),'GPT‑6.1 Sol · 未启用');
 assert.equal(aiModelStatus({profile:config}),'GPT‑6.1 Sol · 已配置');
 assert.equal(aiModelStatus({profile:config,keywordBusy:true}),'GPT‑6.1 Sol · 正在联想关键词');
 assert.equal(aiModelStatus({profile:config,analysis:{status:'running',model:'gpt-5.4-mini-2026-03-17'}}),'GPT‑5.4 mini（2026-03-17） · 正在分析');
 assert.equal(aiModelStatus({profile:{...config,model:'gpt-6.6'}}),'AI 模型待核对');
 assert.doesNotMatch(aiModelStatus({profile:{...config,model:'secret-do-not-render'}}),/secret/);
});
test('employee AI status and error channels hide financial causes',()=>{
 assert.match(employeeAiFinancialText('AI 余额不足，请充值'),/暂不可用/);
 assert.doesNotMatch(employeeAiFinancialText('AI 预算 ¥5 已用完'),/预算|¥/);
 assert.equal(employeeAiFinancialText('请核对账号'),'请核对账号');
 for(const code of ['AI_PROVIDER_BALANCE','AI_DAILY_BUDGET','AI_BILLING_UNKNOWN']){
  const status=analysisStatusView({analysis:{code,message:'余额 ¥0，今日预算已用完'},profileStatus:'enabled',pending:2,imported:2,taskId:'task'});
  assert.match(status.summary+status.state,/暂不可用/);
  assert.doesNotMatch(status.summary+status.state,/余额|预算|¥|费用|充值/);
 }
});
test('AI config readback compares every submitted field',()=>{
 const expected={provider:'openai',model:'gpt-6.1-sol',reasoning_effort:'low',enabled:true,daily_budget_cny:5,usd_cny_rate:7.5,rules_version:'rules'};
 assert.equal(aiConfigFieldsMatch(expected,{...expected,daily_budget_cny:5.0}),true);
 for(const field of Object.keys(expected))assert.equal(aiConfigFieldsMatch(expected,{...expected,[field]:field==='enabled'?false:'wrong'}),false,field);
});
test('employee profile never renders budget while administrator retains spend visibility',async()=>{
 const source=ui.slice(ui.indexOf('async function profile(){'),ui.indexOf('async function latest(){'));
 const run=async role=>{
  const budget={hidden:false,textContent:'old admin amount'},user={role};
  const profile=Function('deps',`const {$,cloud,getUser,renderContinuous}=deps;let aiProfile={},aiProfileStatus='unknown';${source};return profile;`)({$:()=>budget,getUser:()=>user,renderContinuous:()=>{},cloud:{call:async()=>({config:{provider:'openai',model:'gpt-6.1-sol',enabled:true,configured:true},budget:{spent_cny:1.25,limit_cny:5,remaining_cny:3.75}})}});
  await profile();return budget;
 };
 assert.equal((await run('operator')).textContent,'');assert.equal((await run('operator')).hidden,true);
 assert.match((await run('admin')).textContent,/¥1\.250.*¥5.*¥3\.750/);
 assert.match(fs.readFileSync(path.join(__dirname,'site/index.html'),'utf8'),/id="ai-budget-state" hidden/);
});
function makeHarness(){
 const elements=new Map();
 const get=id=>{
  if(!elements.has(id))elements.set(id,{value:'',checked:false,hidden:false,disabled:false,textContent:'',href:'',classList:{remove(){}},replaceChildren(...items){this.options=items;this.value=items[0]?.value||'';}});
  return elements.get(id);
 };
 get('ai-provider').value='openai';
 const source=ui.slice(ui.indexOf('function renderAiProvider('),ui.indexOf('async function openAi('));
 const render=Function('deps',`const {$,el,initial}=deps;let aiConfig=initial;${source};return {renderAiProvider,renderAiEffort};`)({$:get,el:(_,text)=>({textContent:text,value:''}),initial:config});
 return {...render,get};
}
test('switching provider clears typed credentials and restores its own model and key status',()=>{
 const h=makeHarness();h.get('ai-key').value='fake-openai-secret';h.get('ai-clear-key').checked=true;
 h.renderAiProvider(true);assert.equal(h.get('ai-key').value,'');assert.equal(h.get('ai-clear-key').checked,false);
 assert.equal(h.get('ai-model').value,'gpt-6.1-sol');assert.equal(h.get('ai-effort').value,'low');
 h.get('ai-key').value='another-fake-openai-secret';h.get('ai-provider').value='deepseek';h.renderAiProvider(true);
 assert.equal(h.get('ai-key').value,'');assert.equal(h.get('ai-model').value,'deepseek-flash');
 assert.equal(h.get('ai-effort-label').hidden,true);assert.equal(h.get('ai-usd-rate-label').hidden,true);
 assert.match(h.get('ai-key-help').href,/platform\.deepseek\.com/);
 h.get('ai-provider').value='openai';h.renderAiProvider(true);assert.equal(h.get('ai-model').value,'gpt-6.1-sol');
 h.get('ai-model').value='gpt-5.4-mini';h.renderAiEffort();assert.equal(h.get('ai-effort').value,'none');
});
test('configuration submission locks provider and clears key after network failure',async()=>{
 const h=makeHarness();h.renderAiProvider(true);h.get('ai-key').value='fake-key-for-test';h.get('ai-enabled').checked=true;
 h.get('ai-daily-budget').value='5';h.get('ai-rules-version').value='rules';h.get('ai-usd-rate').value='7.5';
 const ids=['ai-provider','ai-model','ai-effort','ai-key','ai-enabled','ai-daily-budget','ai-usd-rate','ai-rules-version'];
 h.get('ai-config-form').elements=ids.map(h.get);let captured;
 const source=ui.slice(ui.indexOf('async function saveAi(){'),ui.indexOf('function renderUpdate(){'));
 const save=Function('deps',`const {$,cloud,profile,renderAiProvider,aiConfigFieldsMatch,initial}=deps;let aiConfig=initial;${source};return saveAi;`)({$:h.get,initial:config,profile:async()=>{},renderAiProvider:h.renderAiProvider,aiConfigFieldsMatch,
  cloud:{call:async(name,data)=>{if(name==='ai_config_read')throw Error('offline');captured={name,data};assert.ok(ids.every(id=>h.get(id).disabled));assert.equal(h.get('ai-key').value,'');throw Error('offline');}}});
 await assert.rejects(save(),/保存结果待核对/);assert.equal(captured.name,'ai_config_save');
 assert.equal(captured.data.config.provider,'openai');assert.equal(captured.data.config.reasoning_effort,'low');
 assert.equal(captured.data.api_key,'fake-key-for-test');assert.equal(h.get('ai-key').value,'');
 assert.ok(ids.every(id=>!h.get(id).disabled));
});
test('configuration save only succeeds after exact readback and preserves draft on mismatch',async()=>{
 const h=makeHarness();h.renderAiProvider(true);h.get('ai-model').value='gpt-5.4-mini';h.renderAiEffort();
 h.get('ai-enabled').checked=true;h.get('ai-daily-budget').value='5';h.get('ai-rules-version').value='rules';h.get('ai-usd-rate').value='7.5';
 const ids=['ai-provider','ai-model','ai-effort','ai-key','ai-enabled','ai-daily-budget','ai-usd-rate','ai-rules-version'];h.get('ai-config-form').elements=ids.map(h.get);
 let readback={...config,model:'gpt-6.1-sol',reasoning_effort:'low',daily_budget_cny:5,usd_cny_rate:7.5,rules_version:'rules'};
 const source=ui.slice(ui.indexOf('async function saveAi(){'),ui.indexOf('function renderUpdate(){'));
 const save=Function('deps',`const {$,cloud,profile,renderAiProvider,aiConfigFieldsMatch,initial}=deps;let aiConfig=initial;${source};return saveAi;`)({$:h.get,initial:config,profile:async()=>{},renderAiProvider:h.renderAiProvider,aiConfigFieldsMatch,cloud:{call:async(name)=>name==='ai_config_read'?{config:readback}:{config:{model:'gpt-5.4-mini'}}}});
 await assert.rejects(save(),/回读配置与填写内容不一致/);
 assert.equal(h.get('ai-model').value,'gpt-5.4-mini');assert.ok(ids.every(id=>!h.get(id).disabled));
 readback={...readback,model:'gpt-5.4-mini',reasoning_effort:'none'};
 await save();assert.match(h.get('ai-configured').textContent,/已回读核对/);
});
test('unknown save with a new key keeps draft, clears secret, and never claims the key was saved',async()=>{
 const h=makeHarness();h.renderAiProvider(true);h.get('ai-key').value='secret-fixture';h.get('ai-enabled').checked=true;
 h.get('ai-daily-budget').value='5';h.get('ai-rules-version').value='rules';h.get('ai-usd-rate').value='7.5';
 const ids=['ai-provider','ai-model','ai-effort','ai-key','ai-enabled','ai-daily-budget','ai-usd-rate','ai-rules-version'];h.get('ai-config-form').elements=ids.map(h.get);
 const source=ui.slice(ui.indexOf('async function saveAi(){'),ui.indexOf('function renderUpdate(){'));
 const readback={...config,daily_budget_cny:5,usd_cny_rate:7.5,rules_version:'rules'};
 const save=Function('deps',`const {$,cloud,profile,renderAiProvider,aiConfigFieldsMatch,initial}=deps;let aiConfig=initial;${source};return saveAi;`)({$:h.get,initial:config,profile:async()=>{},renderAiProvider:h.renderAiProvider,aiConfigFieldsMatch,cloud:{call:async(name)=>name==='ai_config_read'?{config:readback}:Promise.reject(Error('lost response'))}});
 await assert.rejects(save(),/密钥写入结果无法回读确认/);
 assert.equal(h.get('ai-key').value,'');assert.equal(h.get('ai-model').value,'gpt-6.1-sol');
 assert.equal(h.get('ai-rules-version').value,'rules');assert.ok(ids.every(id=>!h.get(id).disabled));
});
