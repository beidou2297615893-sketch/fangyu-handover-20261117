# 2026-10-05 员工 AI 工作流 UI 修复

范围：`work/app/src/web/workspace/{enterprise-ui.mjs,app.mjs}` 及 `work/cloud/workspace/site/` 同名镜像；`work/cloud/workspace/{enterprise-ui.test.cjs,openai-ui.test.cjs}`。原件位于 `before/`。没有改后台、模型、平台采集或视觉素材。

只读审查发现：原「推荐词」按钮可见，但仅点击按钮才运行 `keyword_recommend`；「开始采集」直接走任务保存与持续采集。独立管理员修改企业 AI 后，已有员工采集页也不会在导航时重读 `ai_profile`。评论意向由本机 `AIWorker` 每约 15 秒扫描待分析评论，`workspace_state` 回传分析状态、清单回传 `ai_intent`；当前清空后的空任务/空评论无法展示评级。

修复：首次点击开始且没有人工选词时，只进行 AI 关键词联想并打开原有调整弹窗；必须点「完成调整」确认所选词，再点击开始才进入原采集安全门。已有人工选词、词库选择及恢复任务无需强制调用 AI；需求城市、区域、种子词、推荐数量或选词发生变化时，要求重新推荐或在弹窗明确核对并确认。弹窗需要重新推荐时，内部显示「重新推荐词」按钮，避免模态层遮挡外部入口。一次同条件推荐失败或返回但尚无选词时，不由「开始」暗中重复提交；用户仍可明确点击推荐按钮。采集页导航与窗口重新获焦重读只读 AI 配置，并防止旧响应覆盖新配置。

离线验证：`node --check` 两个修改模块通过；`node --test` 对 `enterprise-ui.test.cjs`、`openai-ui.test.cjs`、`collection-progress-wiring.test.cjs`、`site.test.cjs` 共 51/51 通过。两项源文件与云候选镜像 SHA256 一致；最终哈希见交给主任务的冻结通知。

未调用真实 AI、平台或用户浏览器，未部署。模型响应、合成意向与原生 UI 仍由主任务整合验收。
