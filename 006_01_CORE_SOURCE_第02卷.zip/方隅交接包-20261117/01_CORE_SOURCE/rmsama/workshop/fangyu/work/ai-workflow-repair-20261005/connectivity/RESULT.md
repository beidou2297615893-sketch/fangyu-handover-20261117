# 管理员非计费连通性探针：离线实现与核验

日期：2026-10-05。仅改 `work/cloud/workspace/ai_enterprise.cjs`、`ai_provider.cjs`、`ai_enterprise.test.cjs`。原文件在 `before/`，验证后的文件及 SHA-256 在 `frozen/`。未部署云端、未调用真实 OpenAI/DeepSeek、未读取真实 API key。

## 行为

- 普通 `ai_profile` 保持不发网络请求；仅传 `connectivity_check: true` 时走云端现有 session 和 admin 角色校验。员工返回 403、未登录返回 401；网络操作在事务外，结果返回前再次验 session。
- 固定无凭据 `GET https://api.openai.com/v1/models`；无请求体、无 Authorization，`redirect: 'error'`，5 秒硬截止，响应体最多读取 1024 字节且只丢弃。
- 返回固定 `reachability`、`http_status`、受限 `error.cause.code`；不返回响应体、原始异常、账号或密钥。401/403 等 HTTP 响应仅说明目标可达，不能证明密钥、地区或服务可用。
- 不创建集合、不记预算或账本、不调用付费模型、不重试。

## 证据

- 新增 5 项针对性离线测试先红后绿：管理员 401 可达；固定 GET/无凭据/禁跳转；网络白名单码与超时；大响应体上限；探针中途撤销 session 不返回结果。
- `node --test ai_enterprise.test.cjs`：46/46 通过。全部使用注入的 fake fetch/provider，无真实供应商网络调用。
- 官方 OpenAI API [支持地区](https://developers.openai.com/api/docs/supported-countries) 当前名单不含 China；[错误码文档](https://developers.openai.com/api/docs/guides/error-codes) 将 403 地区不支持列为一种原因。此文档事实不能替代云端 egress 实测，也不能把当前 `AI_PROVIDER_UNAVAILABLE` 断定为地区原因。

## 交接

主任务可部署冻结的两个 `.cjs` 源码文件，并仅在管理员会话下调用一次 `ai_profile` + `connectivity_check: true`。返回 `reachable/http_status=401` 表示云端能收到官方 HTTP 响应；`unreachable` 或 `timeout` 需结合安全码排查出口。真实云端探针尚未执行。
