"""Source-only, device-bound local workspace identity for Fangyu QA."""
import hashlib
import sys
import threading
import time

from integrations import IntegrationError
from .employee_workspace import WorkspaceError, require_owner

QA_DEVICE_ID='0NS21nyCTKWlHKY0EkQScYYl'


def enabled(company, employee_workspace, device_id, address):
    runtime = company.get('runtime') or {}
    return bool(not getattr(sys, 'frozen', False) and employee_workspace
                and company.get('id') == 'fangyu-apartment-client'
                and company.get('authMode') == 'managed'
                and company.get('edition') == 'customer'
                and company.get('personalMode') is False
                and runtime.get('release_approved') is not True
                and runtime.get('xiaohongshu_automation') == 'hold'
                and device_id == QA_DEVICE_ID
                and address[0] in ('127.0.0.1', 'localhost'))


def running_scope(server):
    """Check the already activated source QA instance, whose runtime is enabled."""
    company=server.company
    runtime=company.get('runtime') or {}
    managed=company.get('managedWorkspace') or {}
    return bool(not getattr(sys,'frozen',False)
                and getattr(server,'development_workspace',False)
                and getattr(server,'employee_workspace_mode',False)
                and server.server_address[0] in ('127.0.0.1','localhost')
                and company.get('id')=='fangyu-apartment-client'
                and company.get('edition')=='customer'
                and company.get('personalMode') is False
                and company.get('authMode')=='managed'
                and company.get('releaseVersion')=='1.1.7-qa.1'
                and runtime.get('release_approved') is not True
                and runtime.get('xiaohongshu_automation')=='enabled'
                and runtime.get('platform_qa_device_id')==QA_DEVICE_ID
                and managed.get('environment_id') and managed.get('endpoint'))


def local_operator(server):
    """Return only the already paired operator; never create an identity."""
    if not getattr(server, 'development_workspace', False) or getattr(server, 'development_signed_out', False):
        return None
    assistant = getattr(server, 'assistant_service', None)
    if assistant is None:
        return None
    try:
        saved = assistant.vault.read()
    except (ValueError, OSError):
        return None
    device = (saved or {}).get('device') or {}
    live = assistant.device or {}
    owner, device_id = device.get('owner'), device.get('id')
    managed = server.company.get('managedWorkspace') or {}
    env, company = managed.get('environment_id'), server.company.get('id')
    expected_tenant = 'cloud-' + hashlib.sha256((str(env)+'\n'+str(company)).encode()).hexdigest()[:24]
    if (not env or (saved or {}).get('state') != 'bound' or not owner or not device_id
            or device_id != (server.company.get('runtime') or {}).get('platform_qa_device_id')
            or live.get('id') != device_id or live.get('owner') != owner
            or assistant.environment_id != env or assistant.company_id != company):
        return None
    uid = hashlib.sha256((expected_tenant+'\n'+owner).encode()).hexdigest()
    user = server.core.store.get('users', uid)
    if (not user or user.get('id') != uid or user.get('tenant_id') != expected_tenant
            or user.get('username') != owner or user.get('role') != 'operator'
            or user.get('disabled') or user.get('cloud_bound') is not True):
        return None
    return {**server.core._public(user), 'development_local_only': True}


def same_owner(server, expected):
    fresh=local_operator(server)
    if not fresh or any(fresh.get(key)!=expected.get(key)
                        for key in ('id','tenant_id','username','role')):
        return False
    try:
        return require_owner(server,fresh)['owner']==expected['username']
    except WorkspaceError:
        return False


def reauth(server, password):
    """Reauthenticate only the existing paired operator inside the live source server."""
    if not running_scope(server):
        raise WorkspaceError('开发员工会话恢复未启用', 403)
    owner=local_operator(server)
    if owner is None or owner.get('role') != 'operator':
        raise WorkspaceError('本机绑定员工身份不可用', 403)
    require_owner(server, owner)
    if not isinstance(password,str) or not password or len(password)>256:
        raise WorkspaceError('请提供有效的员工密码', 400)
    with server.development_reauth_lock:
        now=time.monotonic()
        if server.development_reauth_pending or now-server.development_reauth_last_attempt<60:
            raise WorkspaceError('员工身份恢复正在进行或尝试过于频繁，请稍后再试', 429)
        server.development_reauth_pending=True
        server.development_reauth_last_attempt=now
    with server.development_identity_lock:
        server.development_identity_generation+=1
        generation=server.development_identity_generation
        server.development_identity_snapshot=None
        server.development_identity_last_failure=time.monotonic()
    with server.integrations.lock:
        server.integrations.identity_cache.pop(owner['id'],None)
    try:
        server.integrations.enter({'username':owner['username'],'password':password},
                                  expected_user=owner,
                                  expected_guard=lambda:same_owner(server,owner))
        current=server.core.store.get('users',owner['id'])
        verified=server.integrations.verify_identity(current,expected_user=owner)
        if (not verified or verified.get('role')!='operator'
                or verified.get('id')!=owner['id']
                or verified.get('tenant_id')!=owner['tenant_id']
                or verified.get('username')!=owner['username']
                or not same_owner(server,owner)):
            raise WorkspaceError('云端员工身份未通过校验；本机资料仍可查看', 401)
        with server.integrations.lock:
            cached=server.integrations.identity_cache.get(owner['id'])
        if not cached or cached[0]<=time.monotonic():
            raise WorkspaceError('云端员工身份未通过校验；本机资料仍可查看', 401)
        with server.development_identity_lock:
            if server.development_identity_generation!=generation:
                raise WorkspaceError('员工身份恢复状态已变化，请刷新核对', 409)
            server.development_identity_snapshot=(cached[0],verified)
            server.development_identity_last_failure=-1e9
        return {'user':verified}
    except (IntegrationError,ValueError,OSError):
        raise WorkspaceError('员工会话恢复未通过，请核对密码或企业连接；本机资料仍可查看', 401) from None
    finally:
        with server.development_reauth_lock:
            server.development_reauth_pending=False


def verified_or_local(server, local):
    """Never wait on remote identity during a source workspace HTTP request."""
    with server.development_identity_lock:
        now=time.monotonic()
        cached=server.development_identity_snapshot
        current=None
        if cached and cached[0]>now:
            verified=cached[1]
            if (verified.get('id')==local['id'] and verified.get('tenant_id')==local['tenant_id']
                    and verified.get('username')==local['username'] and verified.get('role')=='operator'
                    and not verified.get('disabled')):
                current=verified
        needs_refresh=current is None or cached[0]-now<=5
        if (needs_refresh and not server.development_identity_pending
                and not getattr(server,'development_reauth_pending',False)
                and now-server.development_identity_last_failure>=60):
            server.development_identity_pending=True
            generation=getattr(server,'development_identity_generation',0)
            def probe():
                verified=None; expiry=None
                try:
                    # Only the background worker waits on this lock. Force a
                    # fresh check before the original 30-second permission
                    # cache expires; never extend a cached result's lifetime.
                    with server.integrations.lock:
                        server.integrations.identity_cache.pop(local['id'],None)
                    verified=server.integrations.verify_identity(local)
                    with server.integrations.lock:
                        cloud_cached=server.integrations.identity_cache.get(local['id'])
                        if cloud_cached:expiry=cloud_cached[0]
                except Exception:
                    verified=None
                finally:
                    with server.development_identity_lock:
                        if generation!=getattr(server,'development_identity_generation',0):
                            server.development_identity_pending=False
                            return
                        if (verified and expiry and expiry>time.monotonic() and verified.get('id')==local['id']
                                and verified.get('tenant_id')==local['tenant_id']
                                and verified.get('username')==local['username']
                                and verified.get('role')=='operator'
                                and not verified.get('disabled')):
                            server.development_identity_snapshot=(expiry,verified)
                        else:
                            server.development_identity_snapshot=None
                            server.development_identity_last_failure=time.monotonic()
                        server.development_identity_pending=False
            threading.Thread(target=probe,daemon=True,name='fangyu-dev-identity').start()
    return current or local
