"""Bounded normal-service AI acceptance; no platform requests or key access.

Keyword acceptance uses the owned employee command queue and reusable library.
Intent acceptance sends two clearly synthetic comments to the existing cloud AI
operation using the authenticated maintainer transport; no synthetic leads are
inserted into the employee comment database. Each billable action is recorded
before submission and cannot be silently replayed.
"""
import importlib.util,json,sys,uuid
from pathlib import Path

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
DEVICE='0NS21nyCTKWlHKY0EkQScYYl'

def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m

def output(name,report):
    (HERE/(name+'.json')).write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n','utf-8')
    print(json.dumps(report,ensure_ascii=False))

def employee():return module('workbench_normal_api',ROOT/'work/auto-intent-fix-20261002/verify-live-analysis.py')

def keyword_submit():
    file=HERE/'keyword-command.json'
    if file.exists():raise ValueError('already_submitted')
    record={'request_id':str(uuid.uuid4()),'device_id':DEVICE,'data':{'city':'上海','area':'古北','seeds':['古北租房'],'count':50}}
    with file.open('x',encoding='utf-8') as f:json.dump(record,f,ensure_ascii=False)
    result=employee().call('command_submit',device_id=DEVICE,action='keyword_recommend',data=record['data'],request_id=record['request_id'])
    if not result.get('command_id'):raise ValueError('submission_unconfirmed')
    record['command_id']=result['command_id'];file.write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n','utf-8')
    output('keyword-submit-proof',{'submitted':True,'status':result.get('status'),'platform_calls':0,'automatic_replay':False})

def keyword_status():
    record=json.loads((HERE/'keyword-command.json').read_text('utf-8'))
    c=employee().call('command_get',command_id=record['command_id']).get('command') or {}
    r=c.get('result') or {};words=r.get('keywords') or []
    allowed=('AI_PROVIDER_BALANCE','AI_PROVIDER_AUTH','AI_PROVIDER_TIMEOUT','AI_PROVIDER_REJECTED','AI_INVALID_OUTPUT','AI_BILLING_UNKNOWN','AI_DAILY_BUDGET','AI_UNAVAILABLE')
    raw=str(c.get('error') or '')
    report={'status':c.get('status'),'keyword_count':len(words),'unique_count':len({w.get('keyword') for w in words if isinstance(w,dict)}),'recommended_count':sum(w.get('recommended') is True for w in words if isinstance(w,dict)),'library_saved':bool(r.get('library_id')),'provider':r.get('provider'),'model':r.get('model'),'source':r.get('source'),'cache_hit':r.get('cache_hit'),'safe_code':r.get('code') if r.get('code') in allowed else next((code for code in allowed if code in raw),'unclassified' if raw else ''),'platform_calls':0,'automatic_replay':False}
    output('keyword-result',report)

def intent():
    marker=HERE/'synthetic-intent-attempt.json'
    if marker.exists():raise ValueError('already_submitted')
    portal=module('owner_ai_acceptance',ROOT/'work/owner-admin-20261004/owner_admin.py')
    owner=portal.Owner();user=owner.user()
    with owner.integrations.lock:config=owner.integrations._read(user['tenant_id'])
    profile=owner.integrations._cloud(config,user,'ai_profile')['config']
    if profile.get('provider')!='openai' or profile.get('model')!='gpt-6.1-sol' or not profile.get('enabled') or not profile.get('configured'):raise ValueError('profile_not_ready')
    data={'city':'上海','area':'古北','post':{'id':'synthetic-ai-acceptance-20261005','title':'上海古北租房交流（合成验收数据）','author':'合成验收'},'comments':[{'id':'synthetic-demand','text':'下个月要搬到上海古北，想租一居室，预算3500，周末可以看房，有合适的房源吗？','parent_text':'','published_at':'2026-10-05','ip_location':'上海'},{'id':'synthetic-unrelated','text':'这家店服务不好，我投诉了，希望商家改进。','parent_text':'','published_at':'2026-10-05','ip_location':'上海'}],'expected_revision':profile['revision']}
    marker.write_text(json.dumps({'synthetic':True,'comment_count':2,'model':profile['model'],'profile_revision':profile['revision'],'platform_calls':0,'automatic_replay':False},ensure_ascii=False,indent=2)+'\n','utf-8')
    try:
        result=owner.integrations._cloud(config,user,'intent_analyze',**data)
        rows=result.get('results') or []
        output('intent-result',{'succeeded':len(rows)==2,'provider':result.get('provider'),'model':result.get('model'),'results':[{k:r.get(k) for k in ('id','status','level','key_info')} for r in rows],'billing':result.get('billing'),'synthetic':True,'employee_leads_inserted':0,'platform_calls':0,'automatic_replay':False})
    except Exception as error:
        output('intent-result',{'succeeded':False,'safe_code':getattr(error,'code','AI_CALL_UNCONFIRMED'),'http_status':getattr(error,'http_status',None),'synthetic':True,'employee_leads_inserted':0,'platform_calls':0,'automatic_replay':False})
        raise SystemExit(1)

if __name__=='__main__':
    try:
        mode=sys.argv[1]
        if mode=='keyword-submit':keyword_submit()
        elif mode=='keyword-status':keyword_status()
        elif mode=='intent':intent()
        else:raise ValueError('invalid_mode')
    except Exception as error:
        print(json.dumps({'stopped':True,'safe_code':getattr(error,'code','AI_ACCEPTANCE_UNCONFIRMED'),'error_type':type(error).__name__,'automatic_replay':False}));raise SystemExit(1)
