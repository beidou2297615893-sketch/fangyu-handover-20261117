"""Prepare the existing reviewed, code-only deployment with a narrow allowlist."""
from pathlib import Path

folder=Path(__file__).resolve().parent
root=folder.parents[1]
source=root/'work/ai-config-repair-20261004/deploy.cjs'
code=source.read_text('utf-8')
changes={
    "../openai-integration-20261004/deployment.json":"../ai-config-repair-20261004/deployment.json",
    "const files=['ai_contract.cjs','ai_provider.cjs','ai_enterprise.cjs','site/index.html','site/app.mjs','site/enterprise-model.mjs','site/enterprise-ui.mjs','site/site.css'];":
    "const allowed=['ai_contract.cjs','ai_provider.cjs','site/app.mjs','site/enterprise-ui.mjs','site/index.html'];\nconst files=allowed.filter(rel=>!fs.readFileSync(path.join(baseline,rel)).equals(fs.readFileSync(path.join(cloud,'workspace',rel))));",
    "User explicitly requested fixing enterprise configuration saves, hiding employee budgets, tracking usage and locking the selected model on 2026-10-04.":
    "User requested implementing and repairing keyword recommendations and automatic comment intent analysis on 2026-10-05; existing authorization covers the AI integration and cloud code changes."
}
for old,new in changes.items():
    if code.count(old)!=1:raise RuntimeError('deployment_template_changed')
    code=code.replace(old,new)
out=folder/'deploy.cjs'
if out.exists():raise RuntimeError('deployment_script_already_exists')
out.write_text(code,'utf-8')
print('code-only deployment prepared; cloud unchanged')
