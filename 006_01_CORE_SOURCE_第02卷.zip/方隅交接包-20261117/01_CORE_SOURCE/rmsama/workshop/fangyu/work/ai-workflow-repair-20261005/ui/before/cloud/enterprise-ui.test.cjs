const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');
const {pathToFileURL}=require('node:url');
const root=path.join(__dirname,'site');
const load=()=>import(pathToFileURL(path.join(root,'enterprise-model.mjs')));

test('financial AI failures stay pending and use neutral employee copy',async()=>{
 const ui=fs.readFileSync(path.join(root,'enterprise-ui.mjs'),'utf8');
 const functions=['employeeAiFinancialText','displayIntent','analysisStatusView','commandFailure'].map(name=>
  ui.match(new RegExp(`export function ${name}\\([^]*?\\n\\}`))[0].replace('export ',''));
 const failureText=ui.match(/const ANALYSIS_FAILURE_TEXT=Object\.freeze\(\{[^]*?\}\);/)[0];
 const keywordFailureText=ui.match(/const KEYWORD_FAILURE_TEXT=Object\.freeze\(\{[^]*?\}\);/)[0];
 const {effectiveIntent}=await load();
 const {analysisStatusView,displayIntent,commandFailure}=vm.runInNewContext(
  `${failureText}\n${keywordFailureText}\n${functions.join('\n')};({analysisStatusView,displayIntent,commandFailure})`,{effectiveIntent});
 const base={profileStatus:'enabled',pending:12,imported:12,taskId:'task',city:'上海'};
 const balance=analysisStatusView({...base,analysis:{status:'paused',code:'AI_PROVIDER_BALANCE',message:'请管理员充值后继续分析'}});
 assert.equal(balance.summary,'AI 暂不可用');assert.match(balance.state,/评论已保存.*待分析/);
 assert.doesNotMatch(balance.state,/余额|预算|充值|费用|员工登录|小红书/);
 assert.equal(balance.retryVisible,true);assert.equal(balance.retryLabel,'继续分析');
 const auth=analysisStatusView({...base,analysis:{status:'paused',code:'AI_PROVIDER_AUTH'}});
 assert.equal(auth.summary,'AI 密钥需检查');assert.match(auth.state,/企业 AI 密钥.*管理员检查/);
 assert.equal(auth.retryVisible,true);assert.doesNotMatch(auth.state,/员工登录|小红书/);
 const budget=analysisStatusView({...base,analysis:{status:'pending',code:'AI_DAILY_BUDGET'}});
 assert.equal(budget.summary,'AI 暂不可用');assert.equal(budget.retryVisible,false);
 const context=analysisStatusView({...base,city:'',analysis:{status:'pending',code:'AI_CONTEXT_REQUIRED'}});
 assert.match(context.state,/补充任务城市后自动分析/);
 const missing=analysisStatusView({...base,pending:0,analysis:{status:'pending',excluded_missing_text:1}});
 assert.equal(missing.summary,'无正文待核实');assert.match(missing.state,/补齐后自动分析/);
 const lead={analysis_status:'missing_text',text:'',grade:'C'};
 assert.equal(displayIntent(lead).label,'待核实');
 assert.equal(displayIntent(lead).reason,'评论正文缺失，补齐后自动分析');
 assert.equal(displayIntent({...lead,manual_intent:{status:'graded',level:'high'}}).label,'高意向');
 for(const [code,pattern] of [['AI_PROVIDER_BALANCE',/AI 暂不可用.*仍待分析/],
                              ['AI_PROVIDER_AUTH',/密钥.*不是员工登录/],
                              ['AI_DAILY_BUDGET',/AI 暂不可用.*仍待分析/],
                              ['AI_BILLING_UNKNOWN',/AI 暂不可用.*仍待分析/]]){
  const error=commandFailure('intent_analyze_pending',{status:'failed',error:'',result:{code,error:'SDK token=do-not-show'}});
  assert.match(error.message,pattern);assert.equal(error.code,code);
  assert.doesNotMatch(error.message,/SDK|token/);
 }
 const unknown=commandFailure('intent_analyze_pending',{status:'failed',error:'',result:{code:'execution_error',error:'provider raw'}});
 assert.equal(unknown.message,'操作尚未完成，请核对状态');assert.equal(unknown.code,undefined);
 for(const [code,pattern] of [['AI_PROVIDER_BALANCE',/AI 暂不可用.*重新推荐/],
                              ['AI_PROVIDER_AUTH',/企业 AI 密钥.*管理员检查.*重新推荐/],
                              ['AI_DAILY_BUDGET',/AI 暂不可用.*重新推荐/],
                              ['AI_BILLING_UNKNOWN',/AI 暂不可用.*重新推荐/]]){
  const error=commandFailure('keyword_recommend',{status:'failed',error:'',result:{code,error:'SDK token=do-not-show'}});
  assert.match(error.message,pattern);assert.equal(error.code,code);
  assert.doesNotMatch(error.message,/SDK|token/);
 }
 assert.equal(commandFailure('keyword_recommend',{status:'failed',error:'',result:{code:'execution_error',error:'provider raw'}}).message,'操作尚未完成，请核对状态');
 assert.equal(commandFailure('task_save',{status:'failed',error:'原操作错误'}).message,'原操作错误');
 assert.equal(commandFailure('reply_send',{status:'failed',error:'原操作错误',result:{code:'AI_PROVIDER_BALANCE',error:'provider raw'}}).message,'原操作错误');
 assert.match(ui,/analysis-retry'\)\.addEventListener\('click'.*intent_analyze_pending/);
 assert.equal((ui.match(/action\('intent_analyze_pending'/g)||[]).length,1);
});

test('same collection conditions reuse the continuous checkpoint and keep changed conditions distinct',async()=>{
 const {continuousPayload,matchingContinuousTask,continuousStartAction}=await load();
 const values={city:'杭州',area:'滨江',comment_date_range:'3',account_id:'account-a'};
 const data=continuousPayload(values,['杭州租房']);
 const base={...data,id:'existing',name:'旧名称',unknown_policy:'keep',daily_limit:20,search_pages:3,target_count:100,time_start:'00:00',time_end:'23:59',continuous:{status:'paused'}};
 assert.equal(matchingContinuousTask([base],{...data,name:'改过名称'})?.id,'existing');
 const shallow={...base,id:'newer-failure',continuous:{status:'blocked',batches:1,read:15,updated_at:'2026-10-01T17:25:00+08:00'}};
 const deeper={...base,id:'older-checkpoint',continuous:{status:'paused',batches:2,read:18,updated_at:'2026-10-01T17:17:00+08:00'}};
 assert.equal(matchingContinuousTask([shallow,deeper],data)?.id,'older-checkpoint');
 assert.equal(continuousStartAction(base),'continuous_resume');
 assert.equal(continuousStartAction({...base,continuous:{status:'blocked'}}),'continuous_resume');
 for(const status of ['queued','running','waiting'])assert.equal(continuousStartAction({...base,continuous:{status}}),'display');
 for(const changed of [
  {...data,keywords:['其他关键词']},{...data,area:'西湖'},
  {...data,comment_date_range:'6months'},{...data,account_id:'account-b'},
  {...data,comment_depth:'main'},{...data,excludes:['中介']},
  {...data,intent_mode:'A'},
 ])assert.equal(matchingContinuousTask([base],changed),null);
 assert.equal(matchingContinuousTask([{...base,continuous_enabled:false}],data),null);
 assert.equal(continuousStartAction({...base,continuous:undefined}),'continuous_start');
});
test('fresh active task replaces stale blocked progress unless collection conditions are being edited',async()=>{
 const ui=fs.readFileSync(path.join(root,'enterprise-ui.mjs'),'utf8');
 const source=ui.slice(ui.indexOf('function syncSnapshot(snapshot){'),ui.indexOf('async function start(event){'));
 assert.ok(source.startsWith('function syncSnapshot(snapshot){'));
 const {continuousPayload,matchingContinuousTask}=await load();
 const data=continuousPayload({city:'上海',area:'古北',comment_date_range:'3',account_id:'account'},['公寓']);
 const blocked={...data,id:'old',continuous_enabled:true,continuous:{status:'blocked',read:33,batches:3},keywords:['公寓']};
 const waiting={...data,id:'new',continuous_enabled:true,continuous:{status:'waiting',read:68,batches:9},keywords:['公寓']};
 const create=()=>{
  const fields=new Map(['city','area','comment_date_range','comment_date_from','comment_date_to','account_id','keywords'].map(name=>[name,{value:''}]));
  const controls=new Map([['keyword-options',{open:true}],['custom-comment-dates',{hidden:true}],['keyword-seed',{value:''}]]);
  class FormData{*[Symbol.iterator](){for(const [name,field] of fields)yield [name,field.value];}}
  const reports=[],scheduled=[];
  const deps={fields,controls,FormData,continuousPayload,matchingContinuousTask,reports,scheduled};
  const view=Function('deps',`const {${Object.keys(deps).join(',')}}=deps;let task=null,taskId='',hydratedTaskId='',keywords=[],selected=new Set(),clockTimer=0,pollTimer=0,savedForStart=null,savedForStartDevice='',pendingSave=null,snapshotUnconfirmed=false;const clearTimeout=()=>{},clearInterval=()=>{};const settingsDialog={open:false},$=id=>controls.get(id),field=name=>fields.get(name),form={},chosen=()=>[...selected],report=value=>reports.push(value),renderKeywords=()=>{},renderContinuous=()=>{},syncKeywordAdjustment=()=>{},schedule=()=>scheduled.push(taskId),setInterval=()=>1;${source};return {syncSnapshot,taskId:()=>taskId,task:()=>task,markUnconfirmed:()=>{snapshotUnconfirmed=true;},setDialogOpen:value=>{settingsDialog.open=value;},setPendingSave:value=>{pendingSave=value;}};`)(deps);
  return {view,fields,controls,reports,scheduled};
 };
 const current=create();current.view.syncSnapshot({tasks:[blocked]});
 current.view.syncSnapshot({tasks:[blocked,waiting]});
 assert.equal(current.view.taskId(),'new');assert.equal(current.view.task().continuous.read,68);
 const editing=create();editing.view.syncSnapshot({tasks:[blocked]});editing.fields.get('city').value='杭州';
 editing.view.syncSnapshot({tasks:[blocked,waiting]});
 assert.equal(editing.view.taskId(),'old');assert.equal(editing.fields.get('city').value,'杭州');
 const reviewing=create();reviewing.view.syncSnapshot({tasks:[blocked]});reviewing.fields.get('city').value='杭州';reviewing.controls.get('keyword-options').open=true;
 const scheduledBefore=reviewing.scheduled.length;
 reviewing.view.setDialogOpen(true);reviewing.view.syncSnapshot({tasks:[{...blocked,continuous:{...blocked.continuous,read:34}},waiting],authoritative:true});
 assert.equal(reviewing.view.taskId(),'old');assert.equal(reviewing.view.task().continuous.read,34);
 assert.equal(reviewing.fields.get('city').value,'杭州');assert.equal(reviewing.controls.get('keyword-options').open,true);
 assert.equal(reviewing.scheduled.length,scheduledBefore+1);
 reviewing.view.setDialogOpen(false);reviewing.view.syncSnapshot({tasks:[blocked,waiting]});
 assert.equal(reviewing.view.taskId(),'old');assert.equal(reviewing.scheduled.length,scheduledBefore+2);
 current.view.markUnconfirmed();current.view.syncSnapshot({tasks:[blocked,waiting],authoritative:true});
 assert.deepEqual(current.reports,['']);
 // Only a confirmed full empty snapshot can remove a deleted task while editing.
 for(const dialogOpen of [false,true]){
  const cleared=create();cleared.view.syncSnapshot({tasks:[blocked]});
  cleared.fields.get('city').value='杭州';cleared.view.setDialogOpen(dialogOpen);
  cleared.view.syncSnapshot({tasks:[],authoritative:true});
  assert.equal(cleared.view.taskId(),'');assert.equal(cleared.view.task(),null);
  assert.equal(cleared.fields.get('city').value,'杭州');
 }
 for(const snapshot of [{tasks:[]},{tasks:[],authoritative:true,truncated:true}]){
  const incomplete=create();incomplete.view.syncSnapshot({tasks:[blocked]});
  incomplete.fields.get('city').value='杭州';incomplete.view.syncSnapshot(snapshot);
  assert.equal(incomplete.view.taskId(),'old');
 }
 const saving=create();saving.view.syncSnapshot({tasks:[blocked]});
 saving.view.setPendingSave({commandId:'unconfirmed-save'});
 saving.view.syncSnapshot({tasks:[],authoritative:true});
 assert.equal(saving.view.taskId(),'old');
});
test('local progress refresh applies fresh account review only for the selected device',async()=>{
 const ui=fs.readFileSync(path.join(root,'enterprise-ui.mjs'),'utf8');
 const source=ui.slice(ui.indexOf('async function refreshContinuous(){'),ui.indexOf('function syncSnapshot(snapshot){'));
 assert.ok(source.startsWith('async function refreshContinuous(){'));
 const state={selected:'device-a'},updates=[],accounts=[];
 let resolveRead,rejectRead;
 const staleNotices=[];
 const deps={state,updates,accounts,staleNotices,action:()=>new Promise((resolve,reject)=>{resolveRead=resolve;rejectRead=reject;})};
 const harness=Function('deps',`const {${Object.keys(deps).join(',')}}=deps;let taskId='task',task={id:'task',continuous:{status:'blocked',read:33}},disposed=false;const localWorkspace=true,getState=()=>state,renderContinuous=()=>updates.push(task.continuous.read),schedule=()=>{},syncSnapshot=snapshot=>{task=snapshot.tasks[0];updates.push(task.continuous.read);},onWorkspaceAccounts=value=>accounts.push(value),markSnapshotUnconfirmed=()=>staleNotices.push('stale'),$=()=>({dataset:{page:'tasks'}}),latest=()=>{};${source};return {refreshContinuous};`)(deps);
 const stale=harness.refreshContinuous();state.selected='device-b';resolveRead({tasks:[{id:'task',continuous:{status:'waiting',read:68}}],accounts:[{id:'account',requires_review:true}]});await stale;
 assert.deepEqual(updates,[]);assert.deepEqual(accounts,[]);
 state.selected='device-a';const fresh=harness.refreshContinuous();resolveRead({tasks:[{id:'task',continuous:{status:'waiting',read:68}}],accounts:[{id:'account',requires_review:true}]});await fresh;
 assert.deepEqual(updates,[68]);assert.equal(accounts.length,1);assert.equal(accounts[0][0].requires_review,true);
 const failed=harness.refreshContinuous();rejectRead(Error('offline'));await assert.rejects(failed,/offline/);
 assert.deepEqual(staleNotices,['stale']);assert.deepEqual(updates,[68]);
 const oldDeviceFailure=harness.refreshContinuous();state.selected='device-b';rejectRead(Error('old device offline'));await assert.rejects(oldDeviceFailure,/old device offline/);
 assert.deepEqual(staleNotices,['stale']);
});
test('one collection dialog holds the original form controls and leaves progress visible',()=>{
 const html=fs.readFileSync(path.join(root,'index.html'),'utf8');
 const ui=fs.readFileSync(path.join(root,'enterprise-ui.mjs'),'utf8');
 const page=html.slice(html.indexOf('<section id="page-tasks"'),html.indexOf('<section id="page-leads"'));
 const ancestry=new Map(),stack=[],voidTags=new Set(['input','img','br','hr','meta','link']);
 for(const match of page.matchAll(/<(\/)?([a-z][a-z0-9-]*)([^>]*)>/gi)){
  const [,closing,tag,attrs]=match;
  if(closing){assert.equal(stack.pop()?.tag,tag);continue;}
  const id=attrs.match(/\bid="([^"]+)"/)?.[1];
  if(id)ancestry.set(id,stack.map(item=>item.id).filter(Boolean));
  if(!voidTags.has(tag))stack.push({tag,id});
 }
 assert.deepEqual(stack,[]);
 for(const id of ['city','comment_date_range'])assert.ok(page.includes(`name="${id}"`));
 for(const id of ['keyword-count','custom-comment-dates','collection-more','keyword-options','task-device','task-account','keyword-library','continuous-add-keywords'])assert.ok(ancestry.get(id).includes('collection-dialog'),id);
 for(const id of ['keyword-count','custom-comment-dates'])assert.ok(ancestry.get(id).includes('collection-more'),id);
 for(const id of ['keywords-recommended','keywords-all','open-keyword-library','save-keywords','continuous-add-keywords','keyword-library'])assert.ok(ancestry.get(id).includes('keyword-options'),id);
 for(const id of ['continuous-duplicates','refresh-tasks','ai-budget-state','task-history','continuous-error-text'])assert.ok(ancestry.get(id).includes('collection-details'),id);
 for(const id of ['collection-summary-text','collection-adjust','create-task','continuous-toggle','continuous-message','continuous-source','continuous-imported','continuous-elapsed','continuous-read','continuous-next','continuous-steps','latest-discoveries'])assert.ok(!ancestry.get(id).includes('collection-dialog')&&!ancestry.get(id).includes('collection-details'),id);
 assert.match(page,/<ol id="continuous-steps" class="continuous-steps"><li>搜索<\/li><li>读取<\/li><li>分析<\/li><\/ol>/);
 assert.match(page,/<details id="keyword-options" class="keyword-options">/);
 assert.match(page,/<section id="collection-more" class="collection-more">/);
 assert.match(page,/<dialog id="collection-dialog"[^>]+>/);
 assert.equal((page.match(/<dialog\b/g)||[]).length,1);
 assert.match(page,/<details id="collection-details" class="collection-details">/);
 assert.equal((page.match(/id="create-task"/g)||[]).length,1);
 assert.equal((page.match(/id="continuous-toggle"/g)||[]).length,1);
 const syncSource=ui.match(/function syncKeywordAdjustment\(\)\{[^\n]+/)[0];
 const wire=ui.match(/\$\('keyword-adjust'\)\.addEventListener\('click',[^\n]+/)[0];
 const button={textContent:'调整',setAttribute(name,value){this[name]=value;},addEventListener(name,fn){this[name]=fn;}},options={open:false,addEventListener(name,fn){this[name]=fn;}};
 Function('$',`${syncSource};${wire};return 0;`)(id=>id==='keyword-adjust'?button:options);
 button.click();assert.equal(options.open,true);assert.equal(button.textContent,'收起');assert.equal(button['aria-expanded'],'true');
 button.click();assert.equal(options.open,false);assert.equal(button.textContent,'调整');
 const range={value:'custom',addEventListener(name,fn){this[name]=fn;}},dates={hidden:true};
 const rangeWire=ui.match(/field\('comment_date_range'\)\.addEventListener\('change',[^\n]+/)[0];
 Function('field','$',`${rangeWire};return 0;`)(()=>range,()=>dates);
 range.change();assert.equal(dates.hidden,false);
 const addWire=ui.match(/\$\('continuous-add-keywords'\)\.addEventListener\('click',[^\n]+/)[0];
 const manual={open:false},input={closest:()=>manual,focus(){this.focused=true;}},add={addEventListener(name,fn){this[name]=fn;}};
 Function('$','field','syncKeywordAdjustment',`${addWire};return 0;`)(id=>id==='continuous-add-keywords'?add:options,()=>input,()=>{});
 add.click();assert.equal(options.open,true);assert.equal(manual.open,true);assert.equal(input.focused,true);
});
test('closed-dialog native invalid opens settings, keeps the draft, and restores focus on close',()=>{
 const ui=fs.readFileSync(path.join(root,'enterprise-ui.mjs'),'utf8');
 const helpers=ui.slice(ui.indexOf('function renderCollectionSummary(){'),ui.indexOf('async function action(name,data'));
 const invalidWire=ui.match(/form\.addEventListener\('invalid',[^\n]+/)[0];
 const closeWire=ui.match(/settingsDialog\.addEventListener\('close',[^\n]+/)[0];
 const fields={city:{value:'',inDialog:true,focus(){this.focused=true;}},comment_date_range:{value:'3'},keywords:{value:'手动草稿'}};
 const create={focus(){this.focused=true;}},adjust={focus(){this.focused=true;}},options={open:false},summary={textContent:''},dialogFeedback={textContent:''};
 const controls={'create-task':create,'keyword-options':options,'collection-summary-text':summary,'collection-dialog-feedback':dialogFeedback};
 const settingsDialog={open:false,contains:target=>target.inDialog===true,showModal(){this.open=true;},close(){this.open=false;this.handlers.close?.();},handlers:{},addEventListener(name,fn){this.handlers[name]=fn;}};
 const form={handlers:{},addEventListener(name,fn,capture){this.handlers[name]={fn,capture};}};
 const refreshes=[];
 const deps={settingsDialog,form,fields,controls,requestAnimationFrame:fn=>fn(),syncKeywordAdjustment:()=>{},document:{activeElement:adjust},queueMicrotask,refreshes};
 const harness=Function('deps',`const {${Object.keys(deps).join(',')}}=deps;const $=id=>controls[id],field=name=>fields[name],chosen=()=>['已选词'],refreshContinuous=async()=>refreshes.push('closed'),onError=()=>{};let settingsReturnFocus=null,invalidQueued=false,taskId='task',disposed=false;${helpers};${invalidWire};${closeWire};return {openCollectionDialog,closeCollectionDialog};`)(deps);
 assert.equal(form.handlers.invalid.capture,true);
 let prevented=false;form.handlers.invalid.fn({target:fields.city,preventDefault(){prevented=true;}});
 assert.equal(prevented,true);assert.equal(settingsDialog.open,true);assert.equal(options.open,true);assert.equal(fields.city.focused,true);
 assert.equal(dialogFeedback.textContent,'请补全采集条件');
 fields.city.value='上海';harness.closeCollectionDialog();
 assert.equal(settingsDialog.open,false);assert.equal(fields.city.value,'上海');assert.equal(fields.keywords.value,'手动草稿');assert.equal(create.focused,true);assert.deepEqual(refreshes,['closed']);
 harness.openCollectionDialog(adjust,fields.city);settingsDialog.close();assert.equal(adjust.focused,true);assert.deepEqual(refreshes,['closed','closed']);
 assert.match(ui,/reset\(\)\{settingsReturnFocus=null;closeCollectionDialog\(\)/);
 assert.match(ui,/dispose\(\)\{settingsReturnFocus=null;closeCollectionDialog\(\)/);
});
test('AI recommendation opens keyword review and never starts collection',async()=>{
 const ui=fs.readFileSync(path.join(root,'enterprise-ui.mjs'),'utf8');
 const source=ui.slice(ui.indexOf('async function recommend(){'),ui.indexOf('async function restoreLibrary('));
 for(const count of [50,100]){
  const calls=[],opened=[],reports=[],seeds=['古北租房'];
  const controls={'suggest-keywords':{},'keyword-groups':{querySelector:()=>({id:'first-keyword'})}};
  let city='';
  const deps={controls,calls,opened,reports,count,seeds,profile:async()=>{},renderContinuous:()=>{},renderKeywords:()=>{},feedback:{textContent:'',hidden:false},task:null,
   action:async(name,data)=>{calls.push({name,data});return {keywords:[{keyword:'古北一居室租房',recommended:true},{keyword:'十号线租房',recommended:false}]};},
   openCollectionDialog:(...args)=>opened.push(args),context:()=>({city,seeds,count}),field:()=>({id:'city'}),$:id=>controls[id],report:message=>reports.push(message)};
  const run=Function('deps',`const {${Object.keys(deps).join(',')}}=deps;let keywords=[],keywordsExpanded=false,libraryId='',selected=new Set(),keywordBusy=false;${source};return {recommend,selected:()=>[...selected]};`)(deps);
  await run.recommend();assert.deepEqual(calls,[]);assert.equal(opened.length,1);
  city='上海';await run.recommend();assert.deepEqual(calls.map(item=>item.name),['keyword_recommend']);assert.equal(calls[0].data.count,count);
  assert.deepEqual(run.selected(),['古北一居室租房']);assert.equal(opened.length,2);assert.match(opened[1][2],/核对后点“完成调整”/);
 }
});

async function startHarness({tasks=[],values={city:'杭州',area:'滨江',comment_date_range:'3',account_id:'account-a'},accounts=[{id:'account-a',platform:'xiaohongshu',status:'ready',requires_review:false}],saved=null,held=false,saveError=null,truncated=false,changeDuringGate=false,changeDuringSave=false,dialogOpen=false}={}){
 const model=await load(),ui=fs.readFileSync(path.join(root,'enterprise-ui.mjs'),'utf8');
 const source=ui.slice(ui.indexOf('async function start(event)'),ui.indexOf('async function toggle()'));
 const gateSource=ui.match(/export async function confirmFreshCollectionAccess\([\s\S]*?\n\}/)?.[0];
 const gate=Function(gateSource.replace(/^export /,'')+';return confirmFreshCollectionAccess;')();
 const checks=[],state={selected:'device-a',accounts},form={elements:{namedItem:name=>({value:values[name]||''})}},controls=new Map([['create-task',{dataset:{}}],['keyword-options',{open:true}]]);
 const deps={checks,continuousPayload:model.continuousPayload,matchingContinuousTask:model.matchingContinuousTask,continuousStartAction:model.continuousStartAction,localWorkspace:true,
  confirmFreshCollectionAccess:gate,requireAccountReviewClear:(list,id)=>{if(list.find(item=>item.id===id)?.requires_review)throw Error('review required');},
  getState:()=>state,collectionHeld:()=>held,beforeStart:async()=>{checks.push('beforeStart');if(accounts.find(item=>item.id===values.account_id)?.requires_review)throw Error('review required');if(changeDuringGate)values.area='西湖';},
  chosen:()=>['杭州租房'],FormData:class{constructor(){return Object.entries(values);}},form,field:name=>({value:values[name]||''}),$:id=>controls.get(id)||{open:false},
  action:async(name,data)=>{checks.push(name);if(name==='workspace_state')return {tasks,accounts,truncated};if(name==='task_save'){if(saveError)throw saveError;if(changeDuringSave)values.area='西湖';return {...data,id:'new-task'};}if(['continuous_start','continuous_resume'].includes(name))return {task:{id:data.task_id},continuous:{status:'queued'}};throw Error(name);},
  renderContinuous:()=>{},schedule:()=>{},profile:async()=>{},report:()=>{},setInterval:()=>1};
 const harness=Function('deps',`const {${Object.keys(deps).join(',')}}=deps;let pendingSave=null,savedForStart=deps.initialSaved||null,savedForStartDevice=savedForStart?'device-a':'',taskId='',hydratedTaskId='',task=null,clockTimer=0;const settingsDialog={open:deps.dialogOpen},closeCollectionDialog=()=>{settingsDialog.open=false;checks.push('dialog_close');},openCollectionDialog=()=>{};${source};return {start,read:()=>({pendingSave,savedForStart,taskId,task})};`)({...deps,initialSaved:saved,dialogOpen});
 return {...harness,checks,state,values,run:()=>harness.start({currentTarget:form})};
}

test('start button resumes the deeper matching checkpoint without saving, while active only displays',async()=>{
 const {continuousPayload}=await load(),data=continuousPayload({city:'杭州',area:'滨江',comment_date_range:'3',account_id:'account-a'},['杭州租房']);
 const older={...data,id:'deep',continuous:{status:'paused',batches:2,read:18}},newer={...data,id:'shallow',continuous:{status:'blocked',batches:1,read:15}};
 const paused=await startHarness({tasks:[newer,older]});await paused.run();
 assert.deepEqual(paused.checks,['beforeStart','workspace_state','continuous_resume']);assert.equal(paused.read().taskId,'deep');
 const active=await startHarness({tasks:[{...older,continuous:{status:'running',batches:2,read:18}}]});await active.run();
 assert.deepEqual(active.checks,['beforeStart','workspace_state']);assert.equal(active.read().taskId,'deep');
 const alreadyRunning=await startHarness({tasks:[older,{...newer,continuous:{status:'running',batches:1,read:15}}]});await alreadyRunning.run();
 assert.deepEqual(alreadyRunning.checks,['beforeStart','workspace_state']);assert.equal(alreadyRunning.read().taskId,'shallow');
});
test('Enter inside the adjustment dialog closes review without starting collection',async()=>{
 const reviewing=await startHarness({dialogOpen:true});await reviewing.run();
 assert.deepEqual(reviewing.checks,['dialog_close']);assert.equal(reviewing.read().taskId,'');
});

test('changed conditions create once; review, hold and uncertain saves never reuse the wrong task',async()=>{
 const {continuousPayload}=await load(),data=continuousPayload({city:'杭州',area:'滨江',comment_date_range:'3',account_id:'account-a'},['杭州租房']);
 const old={...data,id:'old',continuous:{status:'paused'}};
 const changed=await startHarness({tasks:[old],values:{city:'杭州',area:'西湖',comment_date_range:'3',account_id:'account-a'},saved:old});await changed.run();
 assert.deepEqual(changed.checks,['beforeStart','workspace_state','task_save','continuous_start']);assert.equal(changed.read().taskId,'new-task');
 const saved=await startHarness({saved:old});await saved.run();assert.deepEqual(saved.checks,['beforeStart','workspace_state','continuous_resume']);assert.equal(saved.read().taskId,'old');
 const savedIdle=await startHarness({saved:{...data,id:'saved-idle'}});await savedIdle.run();assert.deepEqual(savedIdle.checks,['beforeStart','workspace_state','continuous_start']);
 const review=await startHarness({tasks:[old],accounts:[{id:'account-a',platform:'xiaohongshu',status:'ready',requires_review:true}]});await assert.rejects(review.run(),/review required/);assert.deepEqual(review.checks,['beforeStart']);
 const expired=await startHarness({tasks:[old],held:true});await assert.rejects(expired.run(),/未开放或已到期/);assert.deepEqual(expired.checks,['beforeStart']);
 const unknown=Error('保存结果待核对');unknown.requestId='request';unknown.commandId='command';
 const uncertain=await startHarness({saveError:unknown});await assert.rejects(uncertain.run(),/保存结果待核对/);assert.equal(uncertain.read().pendingSave.commandId,'command');
 await assert.rejects(uncertain.run(),/保存结果待核对/);assert.equal(uncertain.checks.filter(item=>item==='task_save').length,1);
 const incomplete=await startHarness({truncated:true});await assert.rejects(incomplete.run(),/任务列表未完整读取/);
 assert.deepEqual(incomplete.checks,['beforeStart','workspace_state']);
 const changedMidflight=await startHarness({tasks:[old],changeDuringGate:true});await assert.rejects(changedMidflight.run(),/采集条件已变化/);
 assert.deepEqual(changedMidflight.checks,['beforeStart']);
 const changedAfterSave=await startHarness({changeDuringSave:true});await assert.rejects(changedAfterSave.run(),/旧条件已保存/);
 assert.deepEqual(changedAfterSave.checks,['beforeStart','workspace_state','task_save']);assert.equal(changedAfterSave.read().savedForStart.id,'new-task');
});
test('continuous start and resume refresh device capability before any save; pause remains available',async()=>{
 // The site module loads assets through query URLs. In Node those URLs resolve
 // back to this module, so evaluate only the exact pure gate in this fixture.
 const ui=fs.readFileSync(path.join(root,'enterprise-ui.mjs'),'utf8');
 const source=ui.match(/export async function confirmFreshCollectionAccess\([\s\S]*?\n\}/)?.[0];
 assert.ok(source);
 const confirmFreshCollectionAccess=Function(source.replace(/^export /,'')+';return confirmFreshCollectionAccess;')();
 const events=[];
 let held=true;
 await confirmFreshCollectionAccess('continuous_start',async()=>{events.push('refresh');held=false;},()=>{events.push('gate');return held;});
 events.push('save','start');
 assert.deepEqual(events,['refresh','gate','save','start'],'stale held state must not block newly granted QA');
 held=false;const revoked=[];
 await assert.rejects(confirmFreshCollectionAccess('continuous_start',async()=>{revoked.push('refresh');held=true;},()=>{revoked.push('gate');return held;}),/未开放或已到期/);
 assert.deepEqual(revoked,['refresh','gate'],'revocation must block before save or start');
 await assert.rejects(confirmFreshCollectionAccess('continuous_resume',async()=>{throw Error('device refresh failed');},()=>false),/device refresh failed/);
 let pauseRefresh=false;
 await confirmFreshCollectionAccess('continuous_pause',async()=>{pauseRefresh=true;throw Error('offline');},()=>true);
 assert.equal(pauseRefresh,false,'pause must work during hold or cloud disconnection');
 const start=ui.slice(ui.indexOf('async function start(event)'),ui.indexOf('async function toggle()'));
 assert.ok(start.indexOf('continuousPayload(')<start.indexOf("confirmFreshCollectionAccess('continuous_start'"));
 assert.ok(start.indexOf("confirmFreshCollectionAccess('continuous_start'")<start.indexOf("action('task_save'"));
 assert.ok(start.indexOf("action('task_save'")<start.indexOf("action('continuous_start'"));
 assert.match(ui,/async function toggle\(\).*confirmFreshCollectionAccess\(name,\(\)=>beforeStart\(accountId,name\),collectionHeld\);.*const result=await action\(name/);
});
test('fresh per-account review blocks start/resume, clears after review, and never gates pause',async()=>{
 const ui=fs.readFileSync(path.join(root,'enterprise-ui.mjs'),'utf8'),app=fs.readFileSync(path.join(root,'app.mjs'),'utf8');
 const gateSource=ui.match(/export async function confirmFreshCollectionAccess\([\s\S]*?\n\}/)?.[0],accountSource=ui.match(/export function requireAccountReviewClear\([\s\S]*?\n\}/)?.[0];
 assert.ok(gateSource&&accountSource);
 const gate=Function(gateSource.replace(/^export /,'')+';return confirmFreshCollectionAccess;')();
 const check=Function(accountSource.replace(/^export /,'')+';return requireAccountReviewClear;')();
 const owned={id:'own',platform:'xiaohongshu',status:'ready',requires_review:false,review_reason:'none'},other={...owned,id:'other',requires_review:true,review_reason:'manual_signal'};
 assert.equal(check([owned,other],'own').id,'own','another account must not affect this account');
 const events=[];
 await assert.rejects(gate('continuous_start',async()=>{events.push('workspace_state');check([{...owned,requires_review:true,review_reason:'verification_required'}],'own');},()=>false),/采集请求.*核对/);
 assert.deepEqual(events,['workspace_state'],'new review must block before task_save');
 await assert.rejects(gate('continuous_resume',async()=>check([{...owned,requires_review:true,review_reason:'unknown'}],'own'),()=>false),/安全记录暂无法核对/);
 await gate('continuous_resume',async()=>check([owned],'own'),()=>false);
 await gate('continuous_start',async()=>check([{id:'own',platform:'xiaohongshu',status:'ready'}],'own'),()=>false);
 let pausedRefresh=false;await gate('continuous_pause',async()=>{pausedRefresh=true;throw Error('offline');},()=>true);assert.equal(pausedRefresh,false);
 assert.match(app,/async function confirmContinuousDevice\([\s\S]*?await confirmTaskDevice\(deviceId,generation\);[\s\S]*?execute\('workspace_state',\{\},deviceId\)/);
 assert.match(app,/deviceId!==state.selected\|\|generation!==state.deviceGeneration\|\|action==='continuous_start'&&\$\('task-account'\)\.value!==accountId/);
 assert.match(app,/return requireAccountReviewClear\(state.accounts,accountId,config.localWorkspace\)/);
 assert.match(app,/if\(config\.localWorkspace&&\$\('task-prerequisite-action'\)\.dataset\.target==='account-safety'\)\{const accountId=\$\('task-account'\)\.value;renderPage\('devices'\);platformAccount\?\.openReview\(accountId\)/);
 assert.match(app,/\$\('task-account'\)\.addEventListener\('change',updateTaskPrerequisite\)/);
});
test('returning to workspace refreshes account review and re-enables collection after authoritative clearance',()=>{
 const app=fs.readFileSync(path.join(root,'app.mjs'),'utf8');
 assert.match(app,/async function enterWorkspace\(\)[\s\S]*?if\(state\.selected\)await refreshTasks\(\)/);
 assert.match(app,/if\(page==='tasks'\)await refreshTasks\(\)/);
 assert.match(app,/\$\('refresh-tasks'\)\.addEventListener\('click',run\(async\(\)=>\{await refreshTasks\(\)/);
 assert.match(app,/function renderTaskSnapshot\(result\)[\s\S]*?state\.accounts=accounts;[\s\S]*?updateTaskPrerequisite\(\)/);
 assert.match(app,/function renderTaskSnapshot\(result\)[\s\S]*?syncSnapshot\(\{tasks:state\.tasks,accounts:state\.accounts,authoritative:true\}\)/);
 assert.match(app,/if\(outcome\.timeout\)[\s\S]*?markSnapshotUnconfirmed\(\)/);
 assert.match(app,/function showTaskReadError\(error\)[^\n]*markSnapshotUnconfirmed\(\)/);
 assert.match(app,/if\(result\.status!=='succeeded'\)[\s\S]*?markSnapshotUnconfirmed\(\)/);
 assert.match(app,/if\(config\.localWorkspace\)platformAccount=createPlatformAccount\(\{root:\$\('page-devices'\),[\s\S]*?onAccountsChanged\(accounts\)\{[\s\S]*?state\.accounts=accounts;[\s\S]*?updateTaskPrerequisite\(\)/);
 const source=app.match(/function updateTaskPrerequisite\(\)\{[\s\S]*?\n\}/)?.[0];assert.ok(source);
 const elements=new Map();for(const id of ['task-prerequisite','task-prerequisite-text','task-prerequisite-action','task-account','create-task','page-tasks'])elements.set(id,{hidden:id==='page-tasks',textContent:'',dataset:{},disabled:false,getAttribute(){return null;}});
 elements.get('task-account').value='selected';
 const state={selected:'device',accounts:[{id:'selected',platform:'xiaohongshu',status:'ready',requires_review:true,review_reason:'verification_required'}]};
 const update=Function('state','elements',`const $=id=>elements.get(id),desktopBindingBlocked=false,config={localWorkspace:true},pendingTaskSave=null,window={gsap:null};const platformActionsHeld=()=>false,selectedDeviceOnline=()=>true,arrangeTaskCards=()=>{},matchMedia=()=>({matches:false});${source};return updateTaskPrerequisite;`)(state,elements);
 update();assert.equal(elements.get('create-task').disabled,true);assert.equal(elements.get('task-prerequisite-action').dataset.target,'account-safety');
 state.accounts=[{id:'selected',platform:'xiaohongshu',status:'ready',requires_review:false,review_reason:'none'}];update();
 assert.equal(elements.get('create-task').disabled,false,'fresh workspace_state clearance must unlock start');
 assert.equal(elements.get('task-prerequisite').hidden,true);assert.equal(elements.get('task-prerequisite-action').dataset.target,'');
});
test('start requires the selected Xiaohongshu account even when another account is ready',()=>{
 const app=fs.readFileSync(path.join(root,'app.mjs'),'utf8');
 const source=app.match(/function updateTaskPrerequisite\(\)\{[\s\S]*?\n\}/)?.[0];assert.ok(source);
 const elements=new Map();for(const id of ['task-prerequisite','task-prerequisite-text','task-prerequisite-action','task-account','create-task','page-tasks'])elements.set(id,{hidden:id==='page-tasks',textContent:'',dataset:{},disabled:false,getAttribute(){return null;}});
 const state={selected:'device',accounts:[{id:'ready',platform:'xiaohongshu',status:'ready',requires_review:false},
  {id:'expired',platform:'xiaohongshu',status:'login_required',requires_review:false}]};
 const update=Function('state','elements',`const $=id=>elements.get(id),desktopBindingBlocked=false,config={localWorkspace:true},pendingTaskSave=null,window={gsap:null};const platformActionsHeld=()=>false,selectedDeviceOnline=()=>true,arrangeTaskCards=()=>{},matchMedia=()=>({matches:false});${source};return updateTaskPrerequisite;`)(state,elements);
 const account=elements.get('task-account'),button=elements.get('create-task'),box=elements.get('task-prerequisite'),message=elements.get('task-prerequisite-text');
 account.value='';update();assert.equal(button.disabled,true);assert.equal(box.hidden,false);assert.match(message.textContent,/选择.*小红书账号/);
 account.value='expired';update();assert.equal(button.disabled,true);assert.equal(box.hidden,false);assert.match(message.textContent,/所选.*账号.*登录|重新选择/);
 account.value='ready';update();assert.equal(button.disabled,false);assert.equal(box.hidden,true);
});
test('submit finally restores account and pending-save gates on the external start button',async()=>{
 const app=fs.readFileSync(path.join(root,'app.mjs'),'utf8');
 const prerequisite=app.match(/function updateTaskPrerequisite\(\)\{[\s\S]*?\n\}/)?.[0];
 const runner=app.match(/function run\(fn,after\)\{[^\n]+/)?.[0];assert.ok(prerequisite&&runner);
 class Button{constructor(){this.id='create-task';this.dataset={};this.disabled=false;this.attributes=new Map();this.classList={add(){},remove(){}};}setAttribute(name,value){this.attributes.set(name,value);}removeAttribute(name){this.attributes.delete(name);}getAttribute(name){return this.attributes.get(name)||null;}}
 const button=new Button(),elements=new Map([['create-task',button]]);
 for(const id of ['task-prerequisite','task-prerequisite-text','task-prerequisite-action','task-account','page-tasks'])elements.set(id,{hidden:id==='page-tasks',textContent:'',dataset:{},getAttribute(){return null;}});
 elements.get('task-account').value='account';
 const state={selected:'device',accounts:[{id:'account',platform:'xiaohongshu',status:'ready',requires_review:false}]};
 const deps={state,elements,HTMLButtonElement:Button,window:{gsap:null},matchMedia:()=>({matches:false}),
  platformActionsHeld:()=>false,selectedDeviceOnline:()=>true,arrangeTaskCards:()=>{}};
 const harness=Function('deps',`const {${Object.keys(deps).join(',')}}=deps;const $=id=>elements.get(id),desktopBindingBlocked=false,config={localWorkspace:true};let pendingTaskSave=null;const pageGeneration=1,handle=()=>{};${prerequisite}\n${runner};return {run,updateTaskPrerequisite,setPending(value){pendingTaskSave=value;}};`)(deps);
 harness.updateTaskPrerequisite();assert.equal(button.disabled,false);
 const event={currentTarget:{querySelector:()=>null},submitter:button,preventDefault(){}};
 await harness.run(async()=>{state.accounts[0].requires_review=true;throw Error('review changed');})(event);
 assert.equal(button.disabled,true);assert.equal(elements.get('task-prerequisite').hidden,false);
 state.accounts[0].requires_review=false;harness.updateTaskPrerequisite();assert.equal(button.disabled,false);
 await harness.run(async()=>{button.dataset.uncertain='true';throw Error('save uncertain');})(event);
 assert.equal(button.disabled,true);assert.equal(button.getAttribute('aria-busy'),null);
});
test('account review entry stays local on desktop and routes cloud users to account page',()=>{
 const app=fs.readFileSync(path.join(root,'app.mjs'),'utf8'),ui=fs.readFileSync(path.join(root,'enterprise-ui.mjs'),'utf8');
 const source=app.match(/function updateTaskPrerequisite\(\)\{[\s\S]*?\n\}/)?.[0];assert.ok(source);
 const view=localWorkspace=>{const elements=new Map();for(const id of ['task-prerequisite','task-prerequisite-text','task-prerequisite-action','task-account','create-task','page-tasks'])elements.set(id,{hidden:id==='page-tasks',textContent:'',dataset:{},disabled:false,getAttribute(){return null;}});elements.get('task-account').value='selected';const state={selected:'device',accounts:[{id:'selected',platform:'xiaohongshu',status:'ready',requires_review:true,review_reason:'verification_required'}]};Function('state','elements','localWorkspace',`const $=id=>elements.get(id),desktopBindingBlocked=false,config={localWorkspace},pendingTaskSave=null,window={gsap:null};const platformActionsHeld=()=>false,selectedDeviceOnline=()=>true,arrangeTaskCards=()=>{},matchMedia=()=>({matches:false});${source};updateTaskPrerequisite();`)(state,elements,localWorkspace);return elements;};
 const local=view(true),remote=view(false);assert.equal(local.get('task-prerequisite-action').dataset.target,'account-safety');assert.match(local.get('task-prerequisite-text').textContent,/小红书账号页/);assert.equal(remote.get('task-prerequisite-action').dataset.target,'account');assert.match(remote.get('task-prerequisite-text').textContent,/对应电脑的方隅工作台/);
 const accountSource=ui.match(/export function requireAccountReviewClear\([\s\S]*?\n\}/)?.[0];const check=Function(accountSource.replace(/^export /,'')+';return requireAccountReviewClear;')();const account=[{id:'selected',platform:'xiaohongshu',status:'ready',requires_review:true,review_reason:'verification_required'}];assert.throws(()=>check(account,'selected',true),/左侧「小红书账号」/);assert.throws(()=>check(account,'selected',false),/对应电脑的方隅工作台/);
 assert.match(ui,/el\('button','去小红书账号','text-button'\)/);assert.match(ui,/safetyLink\.addEventListener\('click',\(\)=>onPage\('devices'\)\)/);
 assert.match(app,/if\(config\.localWorkspace&&\$\('task-prerequisite-action'\)\.dataset\.target==='account-safety'\)\{const accountId=\$\('task-account'\)\.value;renderPage\('devices'\);platformAccount\?\.openReview\(accountId\)/);
 assert.match(app,/renderPage\('devices'\);await refreshDevices\(\);if\(canReadDeviceData\(\)\)await refreshTasks\(\)/);
});

test('blocked account review keeps the main start visible but disabled with its prerequisite',async()=>{
 const ui=fs.readFileSync(path.join(root,'enterprise-ui.mjs'),'utf8');
 const app=fs.readFileSync(path.join(root,'app.mjs'),'utf8');
 const css=fs.readFileSync(path.join(root,'site.css'),'utf8');
 const renderSource=ui.slice(ui.indexOf('function renderContinuous(){'),ui.indexOf('async function refreshContinuous(){'));
 const prerequisiteSource=app.slice(app.indexOf('function updateTaskPrerequisite(){'),app.indexOf('function devicePresentationSignature('));
 assert.ok(renderSource.startsWith('function renderContinuous(){'));
 assert.ok(prerequisiteSource.startsWith('function updateTaskPrerequisite(){'));
 const {continuousPresentation}=await load();
 const check=({status,accountStatus='ready',review=false,pending=false,busy=false,sameConditions=true})=>{
  const elements=new Map(),make=id=>({id,dataset:{},hidden:false,disabled:false,textContent:'',classList:{toggle(){},contains(){return false}},lastElementChild:{hidden:false},replaceChildren(){},getAttribute(name){return name==='aria-busy'&&busy?'true':null;}});
  const $=id=>{if(!elements.has(id))elements.set(id,make(id));return elements.get(id);};
  $('keyword-count').value='50';$('collection-more').querySelector=()=>({textContent:''});
  const account={id:'account',platform:'xiaohongshu',status:accountStatus,requires_review:review,review_reason:'verification_required'};
  const state={selected:'device',accounts:[account]},task={id:'task',account_id:'account',scope:'search',city:'上海',continuous:{status}};
  $('task-account').value='account';$('page-tasks').hidden=true;
  if(pending)$('create-task').dataset.uncertain='true';
  const appDeps={$ ,state,desktopBindingBlocked:false,config:{localWorkspace:true},pendingTaskSave:pending?{deviceId:'device'}:null,
   platformActionsHeld:()=>false,selectedDeviceOnline:()=>true,arrangeTaskCards:()=>{},window:{gsap:null},matchMedia:()=>({matches:false})};
  const update=Function('deps',`const {${Object.keys(appDeps).join(',')}}=deps;${prerequisiteSource};return updateTaskPrerequisite;`)(appDeps);
  const uiDeps={$ ,field:()=>({value:''}),renderCollectionSummary:()=>{},getState:()=>state,getUser:()=>({role:'operator'}),employeeAiFinancialText:message=>message,continuousPresentation,task,feedback:{classList:{contains:()=>false},textContent:''},
   localWorkspace:true,progressSteps:{dataset:{},lastElementChild:{hidden:false}},sourceStepLabel:{textContent:''},
   matchingContinuousTask:()=>sameConditions?task:null,continuousPayload:()=>({}),FormData:class{*[Symbol.iterator](){}},chosen:()=>[],form:{},
   taskId:'task',safetyLink:{hidden:true},continuousStartAction:()=> 'continuous_resume',
   analysisStatusView:()=>({summary:'分析状态',state:'等待',enabled:true,retryVisible:false,retryLabel:''}),aiProfileStatus:'enabled',aiProfile:{},keywordBusy:false,analysisBusy:false,aiModelStatus:()=>'',sourceLink:()=>({})};
  const render=Function('deps',`const {${Object.keys(uiDeps).join(',')}}=deps;${renderSource};return renderContinuous;`)(uiDeps);
  update();render();update();
  return {button:$('create-task'),toggle:$('continuous-toggle'),prerequisite:$('task-prerequisite'),accountAction:$('task-prerequisite-action')};
 };
 const blocked=check({status:'blocked',review:true});
 assert.equal(blocked.button.hidden,false);assert.equal(blocked.button.disabled,true);
 assert.equal(blocked.button.textContent,'开始采集');
 assert.equal(blocked.prerequisite.hidden,false);assert.equal(blocked.accountAction.dataset.target,'account-safety');
 assert.equal(blocked.toggle.hidden,true,'one account entry remains in the prerequisite');
 const changed=check({status:'blocked',review:true,sameConditions:false});
 assert.equal(changed.button.hidden,false);assert.equal(changed.button.disabled,true);
 assert.equal(changed.prerequisite.hidden,false);assert.equal(changed.toggle.hidden,true,'changed conditions must not duplicate account actions');
 const login=check({status:'blocked',accountStatus:'login_required',review:true});
 assert.equal(login.button.hidden,false);assert.equal(login.button.disabled,true);assert.equal(login.prerequisite.hidden,false);
 assert.equal(login.button.textContent,'开始采集');
 const resumable=check({status:'paused'});
 assert.equal(resumable.button.hidden,false);assert.equal(resumable.button.disabled,false);
 assert.equal(resumable.button.textContent,'恢复采集');
 const active=check({status:'running'});
 assert.equal(active.button.hidden,true);assert.equal(active.toggle.hidden,false);assert.equal(active.toggle.textContent,'暂停采集');
 for(const condition of [{status:'blocked',pending:true},{status:'blocked',busy:true}]){
  const result=check(condition);assert.equal(result.button.hidden,false);assert.equal(result.button.disabled,true);
 }
 assert.doesNotMatch(css,/#task-prerequisite\[data-account-gate="true"\]\s*\{display:none\}/);
});
test('continuous UI form requires city and uses real Core ranges without page/batch/count controls',async()=>{
 const {continuousPayload}=await load();const values={city:'杭州',area:'滨江',comment_date_range:'6',account_id:'acc'};
 const result=continuousPayload(values,['杭州租房']);assert.equal(result.comment_date_range,'6months');assert.equal(result.continuous_enabled,true);assert.equal(result.city,'杭州');
 for(const key of ['search_pages','target_count','daily_limit','max_batches'])assert.equal(Object.hasOwn(result,key),false);
 assert.throws(()=>continuousPayload({...values,city:''},['杭州租房']));assert.throws(()=>continuousPayload(values,[]));
 assert.throws(()=>continuousPayload({...values,comment_date_range:'custom',comment_date_from:'2026-09-29',comment_date_to:'2026-01-01'},['杭州租房']));
 assert.equal(continuousPayload({...values,comment_date_range:'custom',comment_date_from:'2026-01-01',comment_date_to:'2026-09-29'},['杭州租房']).comment_date_from,'2026-01-01');
});
test('waiting collection shows its actual phase without a reading animation',async()=>{
 const {continuousPresentation}=await load();
 const now=Date.parse('2026-10-04T10:00:00+08:00');
 const waiting=continuousPresentation({continuous:{status:'waiting',next_run_epoch:now/1000+90},progress:{phase:'reading_comments'}},now);
 assert.equal(waiting.phase,'waiting');
 assert.equal(waiting.processing,false);
 assert.equal(waiting.nextSeconds,90);
 const running=continuousPresentation({continuous:{status:'running',next_run_epoch:now/1000+90},progress:{phase:'reading_comments'}},now);
 assert.equal(running.processing,true);
 assert.equal(running.nextSeconds,null);
 const ui=fs.readFileSync(path.join(root,'enterprise-ui.mjs'),'utf8');
 const render=ui.slice(ui.indexOf('function renderContinuous(){'),ui.indexOf('async function refreshContinuous(){'));
 assert.match(render,/classList\.toggle\('is-processing',view\.processing\)/);
 assert.match(render,/continuous-spinner'\)\.hidden=!view\.processing/);
 assert.match(render,/progressSteps\.dataset\.phase=view\.processing\?view\.phase:view\.status/);
});
test('waiting has a gentle status cue distinct from reading and stops for reduced motion',()=>{
 const css=fs.readFileSync(path.join(root,'site.css'),'utf8');
 assert.match(css,/#continuous-panel\[data-state=waiting\] #continuous-phase::before\{[^}]*animation:waiting-breathe 2\.4s ease-in-out infinite/);
 assert.match(css,/@keyframes waiting-breathe\{/);
 assert.match(css,/@media\(prefers-reduced-motion:reduce\)\{#page-tasks #continuous-panel\[data-state=waiting\] #continuous-phase::before\{animation:none/);
 assert.doesNotMatch(css,/#continuous-panel\[data-state=(?:paused|failed|blocked)\] #continuous-phase::before/);
 assert.match(css,/continuous-panel:not\(\.is-processing\) \.continuous-track span\{display:none\}/);
});
test('semantic five levels remain distinct; uncertainty and legacy grades do not masquerade as AI',async()=>{
 const {effectiveIntent}=await load();for(const level of ['super_high','high','medium','low','very_low'])assert.equal(effectiveIntent({ai_intent:{status:'graded',level}}).kind,level);
 assert.equal(effectiveIntent({grade:'A',score:99}).status,'pending');assert.match(effectiveIntent({grade:'A'}).reason,/历史规则/);
 assert.equal(effectiveIntent({ai_intent:{status:'uncertain',level:null}}).level,null);
 assert.equal(effectiveIntent({manual_intent:{status:'graded',level:'low'},ai_intent:{status:'graded',level:'high'}}).kind,'low');
 assert.equal(effectiveIntent({ai_intent:{status:'graded',level:'high'},verification_status:'pending'}).kind,'high');
});
test('opaque backend group identity matches whole-list counts and normalizes signed post URLs in fallback',async()=>{
 const {groupComments}=await load();const post={content_title:'杭州租房讨论',content_author:'同名博主'};
 const grouped=groupComments([{...post,id:'a',group_key:'opaque-A',url:'https://www.xiaohongshu.com/explore/abc?token=a'},
  {...post,id:'b',group_key:'opaque-A',url:'https://www.xiaohongshu.com/discovery/item/abc?token=b'}]);assert.equal(grouped.length,1);assert.equal(grouped[0].key,'opaque-A');
 const fallback=groupComments([{...post,id:'a',url:'https://www.xiaohongshu.com/explore/abc?token=a'}, {...post,id:'b',url:'https://www.xiaohongshu.com/discovery/item/abc?token=b'}]);assert.equal(fallback.length,1);
 const authors=groupComments([{...post,content_author_id:'uidA'},{...post,content_author_id:'uidB'}],'blogger');assert.equal(authors.length,2);
 for(const mode of ['blogger','date','intent']){const groups=groupComments([{...post,url:'https://www.xiaohongshu.com/explore/abc',published_at:'2026-09-29T09:20:00'}],mode);assert.equal(groups[0].url,'');assert.equal(groups[0].author,'');}
});
test('date groups follow comment dates instead of first high-intent row',async()=>{
 const {groupComments}=await load();
 const rows=[{id:'high-old',group_key:'old',published_at:'2026-09-01T09:00:00',ai_intent:{status:'graded',level:'high'}},
  {id:'unknown',group_key:'unknown',published_at:'2026-19-03T09:00:00'},
  {id:'new',group_key:'new',published_at:'2026-10-03T09:00:00',ai_intent:{status:'graded',level:'low'}}];
 assert.deepEqual(groupComments(rows,'date').map(group=>group.label),['2026-10-03','2026-09-01','时间未提供']);
});
test('comment body is not projected as a post title in cloud or local grouping',async()=>{
 const {groupComments}=await load();
 const local=fs.readFileSync(path.join(__dirname,'../../app/src/web/workspace/enterprise-model.mjs'),'utf8');
 const cloud=fs.readFileSync(path.join(root,'enterprise-model.mjs'),'utf8');
 assert.equal(cloud,local,'local and cloud grouping projections must match');
 const base={group_key:'opaque-post',source_type:'comment',comment_id:'fixture',text:'新水电账单出来了[笑哭R]',title:'新水电账单出来了[笑哭R]'};
 const label=item=>groupComments([item])[0].label;
 assert.equal(label(base),'帖子标题未提供');
 assert.equal(label({...base,content_title:'真实帖子标题'}),'真实帖子标题');
 assert.equal(label({...base,title:'历史帖子标题'}),'历史帖子标题');
 assert.equal(label({...base,title:'历史帖子标题',text:''}),'帖子标题未提供');
 assert.equal(label({...base,source_type:'',comment_id:'fixture'}),'帖子标题未提供');
 assert.equal(label({source_type:'note',title:'普通帖子标题'}),'普通帖子标题');
 const upgraded=groupComments([base,{...base,id:'confirmed',content_title:'真实帖子标题'}]);
 assert.equal(upgraded[0].label,'真实帖子标题');
});
test('update controls follow coordinator trust, staging, idle and restart states',async()=>{
 const {updatePresentation}=await load(),base={feed_configured:true,installed_release:5,installed_version:'1.1.0',candidate_release:6};
 assert.equal(updatePresentation({status:'not_configured',feed_configured:false}).canCheck,false);
 for(const status of ['ready','up_to_date','update_rejected','rolled_back']){const view=updatePresentation({...base,status});assert.equal(view.canCheck,true);assert.equal(view.canDownload,false);assert.equal(view.canInstall,false);}
 assert.equal(updatePresentation({...base,status:'available'}).canDownload,true);assert.equal(updatePresentation({...base,status:'available'}).canInstall,false);
 for(const status of ['staged','busy'])assert.equal(updatePresentation({...base,status}).canInstall,true);
 for(const status of ['pending_restart','awaiting_close','awaiting_confirmation']){const view=updatePresentation({...base,status,requires_restart:true});assert.equal(view.canCheck,false);assert.equal(view.canInstall,false);}
 assert.equal(updatePresentation({...base,status:'staged',feed_configured:false}).canInstall,false);
 const ui=fs.readFileSync(path.join(root,'enterprise-ui.mjs'),'utf8');for(const action of ['update_status','update_check','update_download','update_install'])assert.match(ui,new RegExp(action));assert.doesNotMatch(ui,/fetch\(.+update|location\.reload/);
});
test('display dates preserve supplied local date and minute, while missing or invalid dates stay uncertain',async()=>{
 const {displayCommentDate}=await load();assert.equal(displayCommentDate('2026-09-29T09:20:00'),'2026-09-29 09:20');assert.equal(displayCommentDate('2026-09-29'),'2026-09-29');
 for(const value of ['',null,'2026-02-30T09:20:00','2026-09-29T25:20:00'])assert.equal(displayCommentDate(value),'待核实');
});
test('progress renders real stage/counts and blocked/interrupted/recovery states with no invented values',async()=>{
 const {continuousPresentation}=await load();const now=Date.parse('2026-09-30T10:00:00+08:00');
 const active=continuousPresentation({continuous:{status:'waiting',wait_reason:'range_exhausted',next_run_epoch:now/1000+1800,read:15,imported:0,duplicates:15,created_at:'2026-09-30T09:57:00+08:00'},analysis:{pending:7}},now);
 assert.equal(active.nextSeconds,1800);assert.equal(active.imported,0);assert.equal(active.read,15);assert.equal(active.analysisPending,7);assert.equal(active.heading,'等待新内容');
 const blocked=continuousPresentation({continuous:{status:'blocked',message:'请核对账号'}},now);assert.equal(blocked.active,false);assert.match(blocked.heading,/暂停/);assert.equal(blocked.read,null);
 const paused=continuousPresentation({continuous:{status:'paused',created_at:'2026-09-30T09:00:00+08:00',updated_at:'2026-09-30T09:15:00+08:00'}},now);assert.equal(paused.elapsed,900);
});
test('verification failure stays visibly stopped; sanitized diagnostic is folded and stale active errors do not mislabel progress',async()=>{
 const {continuousPresentation}=await load(),error='小红书 CLI 返回失败（verification_required）：平台要求验证；Cookie=private-value';
 for(const status of ['blocked','paused']){const view=continuousPresentation({continuous:{status,last_error:error,read:15,imported:0,duplicates:15}});assert.equal(view.active,false);assert.equal(view.heading,'本次采集请求被拒绝');assert.doesNotMatch(view.heading+view.message,/完成验证|重新登录|封号|风控/);assert.doesNotMatch(view.message,/CLI|Cookie|verification_required/);assert.match(view.detail,/verification_required/);assert.doesNotMatch(view.detail,/private-value/);assert.equal(view.imported,0);}
 const active=continuousPresentation({continuous:{status:'running',last_error:error}});assert.equal(active.active,true);assert.match(active.heading,/采集/);assert.equal(active.detail,'');
 const waiting=continuousPresentation({continuous:{status:'waiting',last_error:error,read:68,imported:48,duplicates:20}},Date.now(),{requires_review:false,review_reason:'none'});
 assert.equal(waiting.active,true);assert.equal(waiting.detail,'');assert.equal(waiting.read,68);
 const cleared=continuousPresentation({continuous:{status:'paused',last_error:error,message:'已暂停'}},Date.now(),{requires_review:false,review_reason:'none'});assert.doesNotMatch(cleared.heading,/验证|复核/);assert.match(cleared.message,/复核已记录/);assert.match(cleared.detail,/verification_required/);
 const stillReviewing=continuousPresentation({continuous:{status:'paused',last_error:error}},Date.now(),{requires_review:true,review_reason:'verification_required'});assert.equal(stillReviewing.heading,'本次采集请求被拒绝');
 const otherRisk=continuousPresentation({continuous:{status:'paused'}},Date.now(),{requires_review:true,review_reason:'manual_signal'});assert.match(otherRisk.heading,/人工复核/);
 const generic=continuousPresentation({continuous:{status:'blocked',message:'分页断点未前进，已暂停以避免重复请求'}});assert.match(generic.heading,/需要处理/);assert.match(generic.detail,/分页断点/);
 const html=fs.readFileSync(path.join(root,'index.html'),'utf8'),ui=fs.readFileSync(path.join(root,'enterprise-ui.mjs'),'utf8'),css=fs.readFileSync(path.join(root,'site.css'),'utf8');
 assert.match(html,/<details id="continuous-error-details"[^>]* hidden>/);assert.match(ui,/errorDetails\.hidden=!detail/);
 assert.match(ui,/aiProfileStatus==='disabled'/);assert.match(ui,/aiProfileStatus==='not_configured'/);assert.match(ui,/aiProfileStatus='unknown';aiProfile=\{\};aiConfig=null;keywordBusy=false;analysisBusy=false;updateState/);
 assert.match(css,/\.continuous-steps li\[hidden\]\{display:none\}/);
});
test('last verification stop becomes a neutral saved checkpoint only after this account is ready',async()=>{
 const {continuousPresentation}=await load();
 const error='小红书 CLI 返回失败（verification_required）：平台要求验证；Cookie=private-value';
 const ready={status:'ready',requires_review:false,review_reason:'none'};
 for(const status of ['blocked','paused']){
  const task={continuous:{status,last_error:error,read:48,imported:48,inflight:false}};
  const view=continuousPresentation(task,Date.now(),ready);
  assert.equal(view.active,false);assert.equal(view.historyResolved,true);assert.equal(view.heading,'上次采集已停止');
  assert.match(view.message,/断点已保留/);assert.match(view.message,/恢复采集/);
  assert.match(view.detail,/verification_required/);assert.doesNotMatch(view.detail,/private-value/);
  for(const account of [null,{status:'ready',requires_review:true},{status:'login_required',requires_review:false}])
   assert.notEqual(continuousPresentation(task,Date.now(),account).historyResolved,true);
  assert.notEqual(continuousPresentation({continuous:{...task.continuous,inflight:true}},Date.now(),ready).historyResolved,true);
 }
 const newError=continuousPresentation({continuous:{status:'blocked',last_error:'分页断点未前进，已暂停以避免重复请求',message:error}},Date.now(),ready);
 assert.equal(newError.historyResolved,false);assert.match(newError.heading,/需要处理/);
 const active=continuousPresentation({continuous:{status:'running',last_error:error}},Date.now(),ready);
 assert.equal(active.historyResolved,false);assert.equal(active.detail,'');
 const ui=fs.readFileSync(path.join(root,'enterprise-ui.mjs'),'utf8'),css=fs.readFileSync(path.join(root,'site.css'),'utf8');
 assert.match(ui,/host\.dataset\.historyResolved=String\(view\.historyResolved\)/);
 assert.match(css,/#page-tasks #continuous-panel\[data-history-resolved=true\]/);
});
test('collection source row appears only when this task reports a real post title',()=>{
 const html=fs.readFileSync(path.join(root,'index.html'),'utf8'),ui=fs.readFileSync(path.join(root,'enterprise-ui.mjs'),'utf8');
 assert.match(html,/<p id="continuous-source" hidden><\/p>/);
 assert.match(ui,/const source=task\?\.progress\?\.current_source\|\|task\?\.progress\|\|\{\},title=source\.content_title\|\|source\.note_title\|\|'';\$\('continuous-source'\)\.hidden=!title/);
 assert.doesNotMatch(ui,/结果返回后显示来源帖子/);
});
test('all DOM references exist uniquely; selected screen reuses original account/login flow and two nav entries',()=>{
 const html=fs.readFileSync(path.join(root,'index.html'),'utf8'),app=fs.readFileSync(path.join(root,'app.mjs'),'utf8'),ui=fs.readFileSync(path.join(root,'enterprise-ui.mjs'),'utf8');
 const ids=[...html.matchAll(/\bid="([^"]+)"/g)].map(x=>x[1]);assert.equal(new Set(ids).size,ids.length,'duplicate DOM ID');
 const refs=[...ui.matchAll(/\$\('([^']+)'\)/g)].map(x=>x[1]);for(const id of refs)assert.ok(ids.includes(id),`missing ${id}`);
 assert.match(html,/<button data-page="tasks"[^>]*>采集<\/button>/);assert.match(html,/<button data-page="leads">待处理/);
 assert.match(app,/renderPage\('leads'\);showLoggedIn/);assert.match(app,/createEnterpriseWorkspace/);assert.match(app,/onSessionExpired:expireSession/);
 assert.match(html,/id="legacy-comment-ui" hidden/);assert.match(app,/\$\('admin-nav'\)\.hidden=true/);
});
test('reply review accumulates per-row confirmations and sends only explicit prepared queue under current permissions',()=>{
 const ui=fs.readFileSync(path.join(root,'enterprise-ui.mjs'),'utf8');
 assert.match(ui,/confirmedReplies\.add\(reply.id\)/);assert.match(ui,/reply_ids:\[\.\.\.confirmedReplies\]/);assert.match(ui,/confirmedReplies.size>=20/);
 assert.match(ui,/reply_review'.*confirmed:true/);assert.match(ui,/reply_queue_send.*authorized:true/);
 assert.match(ui,/can_reply!==false/);assert.match(ui,/\$\('queue-send'\)\.disabled=!canReply\(\)\|\|held\(\)/);
 assert.match(ui,/queue.status==='ready'\|\|queue.status==='awaiting_collection'&&queue.wait_expired===true/);assert.match(ui,/interrupted','cancelled','unknown'/);assert.match(ui,/scheduleQueue/);
 assert.match(ui,/updateReply\(false\);renderQueue\(\)/);assert.match(ui,/账号已变化，请重新确认/);
 assert.match(ui,/reply.status==='approved'.*reply.review_account_id!==accountId/);assert.match(ui,/refreshSelectedReply\(\)/);assert.match(ui,/replyNeedsCheck\|\|!canReply\(\)/);
});
test('legacy grade appears once and reply actions remain anchored inside the detail scrollport',async()=>{
 const {effectiveIntent}=await load(),ui=fs.readFileSync(path.join(root,'enterprise-ui.mjs'),'utf8'),css=fs.readFileSync(path.join(root,'site.css'),'utf8');
 assert.match(effectiveIntent({grade:'B'}).reason,/历史规则 B.*尚未完成 AI 分析/);
 assert.match(ui,/legacy-intent-note'\)\.textContent=''/);
 assert.match(ui,/reply-detail'\)\.append\(\$\('reply-detail'\)\.querySelector\('\.detail-reply-actions'\)\)/);
 assert.match(css,/\.reply-detail>\.detail-reply-actions\{position:sticky;bottom:0/);
 assert.match(css,/#reply-reason:empty,#legacy-intent-note:empty\{display:none\}/);
 assert.match(ui,/getBoundingClientRect\(\)\.top/);
 assert.match(ui,/window\.innerHeight-top-16/);
 assert.match(ui,/window\.addEventListener\('resize',scheduleDetailViewport\)/);
 assert.match(ui,/window\.addEventListener\('scroll',scheduleDetailViewport,\{passive:true\}\)/);
 assert.match(ui,/selectLead\(lead\).*?scheduleDetailViewport\(\)/s);
 assert.match(css,/max-height:var\(--reply-visible-height,calc\(100vh - 30px\)\)/);
 assert.match(css,/@media\(max-width:980px\)\{\.reply-detail\{max-height:none\}\.reply-detail>\.detail-reply-actions\{position:static/);
});
test('AI key stays blank, never enters localStorage; fields clear on success/error/dialog close; reduced motion has fallback',()=>{
 const html=fs.readFileSync(path.join(root,'index.html'),'utf8'),ui=fs.readFileSync(path.join(root,'enterprise-ui.mjs'),'utf8'),css=fs.readFileSync(path.join(root,'site.css'),'utf8');
 assert.match(html,/id="ai-key" type="password"/);assert.doesNotMatch(ui,/localStorage/);assert.match(ui,/finally\{\$\('ai-key'\)\.value=''/);
 assert.match(ui,/ai-dialog'\)\.addEventListener\('close'.*ai-key/);assert.match(css,/@media\(prefers-reduced-motion:reduce\).*continuous-spinner/);
 assert.match(css,/continuous-panel.is-processing.*continuous-track/);assert.doesNotMatch(html,/aria-valuenow="(?:\d+)"/);
});
