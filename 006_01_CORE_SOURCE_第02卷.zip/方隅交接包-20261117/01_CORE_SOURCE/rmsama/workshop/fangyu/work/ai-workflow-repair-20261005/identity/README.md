# 云命令首击身份核对竞态修复（离线候选）

范围：`work/app/src/app.py`、`work/app/src/assistant/development_workspace.py`、`work/app/src/assistant/employee_workspace.py`、`work/app/tests/test_development_workspace.py`。修改前副本在 `identity/before/`。未使用真实账号、平台、付费 AI、UI 或部署。

原行为：30 秒云身份快照过期后，`Handler.user()` 即刻返回仅本机身份，并启动后台只读 `me` 验证；同次云 `command_submit` 进入 gateway 后立即返回 503。新增测试在背景验证尚未完成时复现红灯：云命令过早结束。

修复：仅云端成员操作在已有身份验证 pending 时最多等待 4 秒；本机资料读取、设备概览仍即刻响应。不启动第二次验证，不重放云命令。等待后重新核对验证代次、当前绑定员工、角色和权限、本机设备归属、云身份缓存及其原始到期时间；验证失败、超时、退出、权限变化或缓存过期仍返回 503。正常完成时使用云验证身份进入原 gateway 与服务端权限检查。

离线验证：首击测试红灯后转绿；`python -m unittest tests.test_development_workspace` 12/12；与员工网关和客户集成合跑 31/31；身份恢复专项 8/8；三个源码 `py_compile` 通过。覆盖 pending 成功、超时无云命令、owner 改变、有效快照刷新中等待、过期快照拒绝。本轮未重开现用客户端，实际同一 UUID 命令完成状态由主任务核对。
