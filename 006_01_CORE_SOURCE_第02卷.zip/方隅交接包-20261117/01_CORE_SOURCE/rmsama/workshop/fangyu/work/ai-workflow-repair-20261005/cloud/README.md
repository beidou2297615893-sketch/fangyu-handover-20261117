# Sol 可选用量字段兼容修复（离线候选）

修改范围：`work/cloud/workspace/ai_provider.cjs`、`ai_contract.cjs`、`ai_enterprise.test.cjs`。修改前副本在 `cloud/before/`。未调用 OpenAI、平台或云部署接口，未读取密钥。

官方依据（2026-10-05 查阅）：

- [Chat Completions API Reference](https://developers.openai.com/api/reference/resources/chat/subresources/completions/methods/create)：`prompt_tokens_details.cache_write_tokens`、`cached_tokens` 均为可选字段；示例响应只有 `cached_tokens: 0`，没有 `cache_write_tokens`。`service_tier: default` 表示标准计费；请求显式指定档位时响应包含实际档位，Fast 返回 `priority`。
- 同页 `prompt_cache_options.mode=explicit`：适用于 GPT-5.6 及更新模型；没有显式断点时不使用提示缓存。
- [GPT-6.1 Sol 模型页](https://developers.openai.com/api/docs/models/gpt-6.1-sol)：Chat Completions 支持无工具调用；标准输入、缓存读、缓存写、输出价格各异，因此不能把未知缓存写入量直接当零。

实现：仅 Sol 请求加 `prompt_cache_options: {mode: 'explicit'}`，不设断点；Sol 的合法缺失缓存字段按已禁用的缓存计 0。若响应报告正缓存读/写、非标准服务档位、不同模型、token 总量不一致，仍保持用量未知且不提交分析。GPT-5.4 Mini 与 DeepSeek 路径保持原计费规则。本地结果缓存未变。

离线验证：`node --check ai_provider.cjs`、`node --check ai_contract.cjs`、`node --check ai_enterprise.test.cjs`；`node --test ai_enterprise.test.cjs` 通过。测试覆盖官方示例形状、正缓存矛盾、模型/档位/总量错误，以及 Sol 关键词和单条意向分析合成闭环。真实供应商返回形状、实际费用与内容质量仍待受限样本核验。
