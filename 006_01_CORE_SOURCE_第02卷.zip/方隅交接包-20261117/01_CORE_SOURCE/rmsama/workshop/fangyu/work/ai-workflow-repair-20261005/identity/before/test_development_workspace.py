"""Offline checks for source-only, paired-owner workspace entry."""
import hashlib
import sys
import tempfile
import threading
import time
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'src'))
from app import AppServer, Handler
from assistant import development_workspace as dev
from assistant import employee_workspace as workspace
from assistant.business import BusinessExecutor


ENV='synthetic-env'
COMPANY='fangyu-apartment-client'
DEVICE=dev.QA_DEVICE_ID
TENANT='cloud-'+hashlib.sha256((ENV+'\n'+COMPANY).encode()).hexdigest()[:24]
UID=hashlib.sha256((TENANT+'\n'+'synthetic-operator').encode()).hexdigest()


class Store:
    def __init__(self,user):self.user=user
    def get(self,entity,ident):return self.user if entity=='users' and ident==UID else None


def fixture():
    user={'id':UID,'tenant_id':TENANT,'username':'synthetic-operator',
          'role':'operator','cloud_bound':True,'disabled':False}
    device={'id':DEVICE,'owner':user['username'],'name':'QA','version':'1.1.7-qa.1'}
    assistant=SimpleNamespace(vault=SimpleNamespace(read=lambda:{'state':'bound','device':device}),
                              device=device,state='offline',environment_id=ENV,company_id=COMPANY)
    company={'id':COMPANY,'authMode':'managed','edition':'customer','personalMode':False,
             'runtime':{'release_approved':False,'xiaohongshu_automation':'hold',
                        'platform_qa_device_id':DEVICE},
             'managedWorkspace':{'environment_id':ENV}}
    core=SimpleNamespace(store=Store(user),_public=lambda value:value.copy(),session=lambda token:None)
    server=SimpleNamespace(company=company,core=core,assistant_service=assistant,
                           development_workspace=True,development_signed_out=False,
                           employee_workspace_mode=True,
                           integrations=SimpleNamespace(verify_identity=lambda value:None,
                                                        lock=threading.RLock(),identity_cache={}),
                           development_identity_lock=threading.Lock(),
                           development_identity_pending=False,
                           development_identity_last_failure=-1e9,
                           development_identity_snapshot=None)
    return server,user,device


class DevelopmentWorkspaceTests(unittest.TestCase):
    def test_explicit_source_and_scope(self):
        server,_,_=fixture()
        self.assertTrue(dev.enabled(server.company,True,DEVICE,('127.0.0.1',0)))
        self.assertFalse(dev.enabled(server.company,False,DEVICE,('127.0.0.1',0)))
        self.assertFalse(dev.enabled(server.company,True,DEVICE,('0.0.0.0',0)))
        self.assertFalse(dev.enabled(server.company,True,'wrong-device',('127.0.0.1',0)))
        for key,value in (('authMode','local'),('edition','owner'),('id','other-customer')):
            altered={**server.company,key:value}
            self.assertFalse(dev.enabled(altered,True,DEVICE,('127.0.0.1',0)))
        with patch.object(dev.sys,'frozen',True,create=True):
            self.assertFalse(dev.enabled(server.company,True,DEVICE,('127.0.0.1',0)))

    def test_only_saved_matching_operator_and_signout(self):
        server,user,device=fixture()
        self.assertEqual(dev.local_operator(server)['id'],UID)
        for key,value in (('role','admin'),('tenant_id','other'),('username','other'),
                          ('cloud_bound',False),('disabled',True)):
            changed={**user,key:value};server.core.store.user=changed
            self.assertIsNone(dev.local_operator(server),key)
        server.core.store.user=user
        server.assistant_service.device={**device,'id':'other-device'}
        self.assertIsNone(dev.local_operator(server))
        server.assistant_service.device=device
        server.development_signed_out=True
        self.assertIsNone(dev.local_operator(server))

    def test_valid_cloud_session_priority_and_expired_fallback(self):
        server,user,_=fixture()
        verified={**user,'can_reply':False}
        server.core.session=lambda token:None
        done=threading.Event();calls=[]
        def verify(candidate):
            calls.append(candidate['id'])
            server.integrations.identity_cache[candidate['id']]=(time.monotonic()+30,verified)
            done.set()
            return verified
        server.integrations.verify_identity=verify
        handler=SimpleNamespace(server=server,token=lambda:'')
        began=time.monotonic()
        self.assertTrue(Handler.user(handler)['development_local_only'])
        self.assertLess(time.monotonic()-began,0.2)
        self.assertTrue(done.wait(1))
        for _ in range(100):
            if not server.development_identity_pending:break
            time.sleep(.001)
        self.assertIs(Handler.user(handler),verified)
        server.integrations._read=lambda tenant:{}
        server.integrations._cloud=lambda config,member,operation,**data:{'devices':[{'id':DEVICE,'platform_qa':True}]}
        self.assertTrue(workspace.gateway(server,Handler.user(handler),'devices',{})['devices'][0]['platform_qa'])
        self.assertEqual(calls,[UID])
        server.development_identity_snapshot=None
        server.development_identity_last_failure=time.monotonic()
        self.assertTrue(Handler.user(handler)['development_local_only'])
        self.assertEqual(calls,[UID])
        server.development_identity_snapshot=(time.monotonic()+30,{**verified,'role':'admin'})
        self.assertEqual(Handler.user(handler)['role'],'operator')
        server.core.session=lambda token:{**user,'role':'admin'}
        self.assertEqual(Handler.user(handler)['role'],'operator')

    def test_slow_cloud_probe_never_blocks_or_duplicates(self):
        server,_,_=fixture()
        release=threading.Event();entered=threading.Event();calls=[]
        def slow(_):
            with server.integrations.lock:
                calls.append(1);entered.set();release.wait(1)
        server.integrations.verify_identity=slow
        handler=SimpleNamespace(server=server,token=lambda:'')
        try:
            self.assertTrue(Handler.user(handler)['development_local_only'])
            self.assertTrue(entered.wait(1))
            began=time.monotonic()
            for _ in range(10):
                user=Handler.user(handler)
                self.assertTrue(user['development_local_only'])
                self.assertEqual(workspace.gateway(server,user,'devices',{})['devices'][0]['owner'],user['username'])
            self.assertLess(time.monotonic()-began,0.2)
            self.assertEqual(len(calls),1)
        finally:release.set()

    def test_local_only_blocks_cloud_and_unknown_without_retry(self):
        server,_,_=fixture()
        user=dev.local_operator(server)
        calls=[]
        server.integrations._cloud=lambda *args,**kwargs:calls.append(args)
        result=workspace.gateway(server,user,'devices',{})
        self.assertEqual(result['devices'][0]['owner'],'synthetic-operator')
        self.assertFalse(result['devices'][0]['platform_qa'])
        for operation in ('members','command_submit','ai_profile','unknown_operation'):
            with self.assertRaises(workspace.WorkspaceError):
                workspace.gateway(server,user,operation,{'device_id':DEVICE})
        self.assertEqual(calls,[])
        self.assertTrue(workspace.gateway(server,user,'logout',{})['ok'])
        self.assertTrue(server.development_signed_out)
        self.assertIsNone(dev.local_operator(server))

    def test_success_refresh_and_failure_cooldown_have_separate_clocks(self):
        server,user,_=fixture()
        clock=[100.0];calls=[];fail=[False]
        verified={**user,'can_reply':False}
        def verify(candidate):
            calls.append(clock[0])
            if fail[0]:return None
            server.integrations.identity_cache[candidate['id']]=(clock[0]+30,verified)
            return verified
        server.integrations.verify_identity=verify
        def settled():
            for _ in range(1000):
                if not server.development_identity_pending:return
                threading.Event().wait(.001)
            self.fail('background identity check did not finish')
        local=dev.local_operator(server)
        with patch.object(dev.time,'monotonic',side_effect=lambda:clock[0]):
            self.assertTrue(dev.verified_or_local(server,local)['development_local_only'])
            settled()
            self.assertIs(dev.verified_or_local(server,local),verified)
            clock[0]=126
            self.assertIs(dev.verified_or_local(server,local),verified)
            settled()
            self.assertEqual(calls,[100,126])
            self.assertEqual(server.development_identity_snapshot[0],156)
            clock[0]=131
            self.assertIs(dev.verified_or_local(server,local),verified)
            fail[0]=True;clock[0]=155
            dev.verified_or_local(server,local);settled()
            self.assertIsNone(server.development_identity_snapshot)
            clock[0]=214
            self.assertTrue(dev.verified_or_local(server,local)['development_local_only'])
            self.assertEqual(calls,[100,126,155])
            clock[0]=215
            dev.verified_or_local(server,local);settled()
            self.assertEqual(calls,[100,126,155,215])

    def test_offline_comment_read_keeps_owner_and_platform_hold(self):
        with tempfile.TemporaryDirectory() as directory:
            server=AppServer(('127.0.0.1',0),directory,
                             platform_qa_device_id=DEVICE,employee_workspace=True,
                             development_workspace=True)
            try:
                env=server.company['managedWorkspace']['environment_id']
                owner='synthetic-operator'
                executor=BusinessExecutor(server,env,COMPANY,owner)
                user=executor.principal({'owner':owner,'principal':{'username':owner,'role':'operator'},
                                         'action':'workspace_state'})
                lead=server.core.handle('save',{'entity':'leads','record':{
                    'platform':'xiaohongshu','source_type':'comment','source_id':'synthetic-comment',
                    'comment_id':'synthetic-comment','author':'synthetic','text':'synthetic text'}},user)
                device={'id':DEVICE,'owner':owner,'name':'QA','version':'1.1.7-qa.1'}
                server.assistant_service=SimpleNamespace(
                    vault=SimpleNamespace(read=lambda:{'state':'bound','device':device}),
                    device=device,state='offline',executor=None,environment_id=env,
                    company_id=COMPANY,lock=__import__('threading').RLock())
                local=dev.local_operator(server)
                self.assertTrue(local['development_local_only'])
                self.assertIn(b'id="login-panel" hidden',workspace.asset(server,'')[0])
                self.assertIn(b'"developmentWorkspace":true',workspace.asset(server,'config.mjs')[0])
                with patch.object(server.integrations,'_cloud',side_effect=AssertionError('cloud request')), \
                     patch.object(server.core.adapters,'execute',side_effect=AssertionError('platform request')):
                    result=workspace.gateway(server,local,'local_read',
                        {'action':'leads_list','data':{}})['result']
                    self.assertEqual(result['total'],1)
                    self.assertEqual(result['items'][0]['id'],lead['id'])
                    with self.assertRaises(workspace.WorkspaceError):
                        workspace.gateway(server,local,'command_submit',{'device_id':DEVICE})
                self.assertTrue(server.core.remote_safety_hold)
            finally:
                server.assistant_service=None
                server.close_owned_jobs();server.server_close()


if __name__=='__main__':unittest.main()
