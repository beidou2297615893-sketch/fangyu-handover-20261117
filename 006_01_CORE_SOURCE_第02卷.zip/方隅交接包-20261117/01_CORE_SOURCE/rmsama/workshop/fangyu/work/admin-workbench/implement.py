"""One local adaptation pass; original r55 and canonical release remain untouched."""
from pathlib import Path
import hashlib,json
ROOT=Path(__file__).resolve().parents[2]
def edit(rel, changes):
    p=ROOT/rel;s=p.read_text('utf-8')
    for old,new,count in changes:
        if s.count(old)!=count:raise RuntimeError(f'{rel}: expected {count}, got {s.count(old)}: {old[:65]}')
        s=s.replace(old,new)
    p.write_text(s,'utf-8',newline='\n')

# All components in a release use one locally adapted integration module.
base=ROOT/'work/ui-runtime-r55/src/integrations.py'
vendor=ROOT/'work/shared-backend-integration/vendor-src/integrations.py'
s=base.read_text('utf-8')
s=s.replace("expected_user.get('role') != 'operator'", "expected_user.get('role') not in ('operator', 'admin')")
s=s.replace("profile.get('username') != name or profile.get('role') != 'operator'", "profile.get('username') != name or profile.get('role') != expected_user.get('role')")
s=s.replace("current.get('role') != 'operator'", "current.get('role') != expected_user.get('role')")
s=s.replace("or profile.get('role') != 'operator'):", "or profile.get('role') != expected_user.get('role')):")
vendor.write_text(s,'utf-8',newline='\n')

edit('work/ui-native-r57/ui_native_host.py',[
 ("    module_name = 'fangyu_workbench_backend'", """    # Load the pinned r57 role-preserving adapter before any business import.
    integration_entry = files.get('resources/platform-runtime/vendor-src/integrations.py')
    if integration_entry:
        integration_path = root / integration_entry['path']
        previous = sys.modules.get('integrations')
        if previous is not None and Path(previous.__file__).resolve() != integration_path.resolve():
            raise UIHostError('已有身份组件来源不同，请独立重开候选验收。')
        if previous is None:
            child = importlib.util.module_from_spec(importlib.util.spec_from_loader('integrations',loader=None))
            child.__file__ = str(integration_path)
            sys.modules['integrations'] = child
            raw = read_public(integration_path,integration_entry['sha256'],integration_entry['size'])
            exec(compile(raw,child.__file__,'exec'),child.__dict__)
    module_name = 'fangyu_workbench_backend'""",1),
 ("if user.get('role') != 'operator':", "if user.get('role') not in ('operator', 'admin'):",1),
 ("'storeId': stores[0].get('id', '') if stores else ''}", "'storeId': (result.get('selection') or {}).get('storeId', '')}",1)])

edit('work/ui-native-r57/workbench_backend.py',[
 ("user.get('role') != 'operator'", "user.get('role') not in ('operator', 'admin')",1),
 ("verified.get('role') != 'operator'", "verified.get('role') not in ('operator', 'admin')",1),
 ("profile.get('role') != 'operator'", "profile.get('role') != verified.get('role')",1),
 ("        return verified, profile\n\n    def _stores(self, profile):", """        profile = deepcopy(profile)
        if verified['role'] == 'admin':
            config = integration._read(verified['tenant_id'])
            directory = integration._cloud(config, verified, 'members')
            scope = directory.get('member_management') or {}
            actor = scope.get('actor') or {}
            if (directory.get('contract') != 'fangyu-workspace-v1'
                    or directory.get('company_id') != COMPANY_ID
                    or directory.get('environment_id') != self.company['managedWorkspace']['environment_id']
                    or scope.get('version') != 'store-members-v1'
                    or actor.get('username') != verified['username'] or actor.get('role') != 'admin'
                    or (scope.get('scope') or {}).get('type') != 'company'
                    or (scope.get('scope') or {}).get('store_id') != ''
                    or not isinstance(directory.get('users'), list)):
                raise WorkbenchError('STORE_DIRECTORY_UNAVAILABLE', '企业门店分组目录未通过身份核对', 503)
            ids = {row['store_id'] for row in directory['users']
                if isinstance(row,dict) and row.get('role') == 'operator' and row.get('disabled') is False
                and isinstance(row.get('store_id'),str) and STORE_ID.fullmatch(row['store_id'])}
            if isinstance(profile.get('store_id'),str) and STORE_ID.fullmatch(profile['store_id']):
                ids.add(profile['store_id'])
            profile['_workbench_stores'] = [{'id':ident,'name':ident,
                'description':'云端成员已绑定门店分组','region':''} for ident in sorted(ids)]
        stores = self._stores(profile)
        selected = self._load_selection(verified, stores)['storeId']
        verified = {**verified, '_workbench_store_id':selected}
        profile['_workbench_store_id'] = selected
        return verified, profile

    def _stores(self, profile):
        if profile.get('role') == 'admin':
            return deepcopy(profile.get('_workbench_stores', []))""",1),
 ("selection = {'storeId': stores[0]['id'] if stores else '',", "selection = {'storeId': stores[0]['id'] if stores and user.get('role') == 'operator' else '',",1),
 ("            catalog = self._catalog(user, selection['storeId'])", "            user = {**user, '_workbench_store_id':selection['storeId']} if user else None\n            catalog = self._catalog(user, selection['storeId'])",1),
 ("'presets': bool(user and stores)", "'presets': bool(user and selection['storeId'])",1),
 ("'materials': bool(user and stores)", "'materials': bool(user and selection['storeId'])",1),
 ("'rentalAssessment': bool(user and stores)", "'rentalAssessment': bool(user and selection['storeId'])",1),
 ("'reason': '' if user and stores else '请管理员先分配门店' if user else '请先登录'", "'reason': '' if user and selection['storeId'] else ('请先明确选择云端已绑定门店分组' if stores else '云端暂无已绑定门店分组，请在原管理后台核对成员门店') if user else '请先登录'",1),
 ("    def _save_selection(self, user, stores, data, *, apply):", """    def _selected_store(self, user, profile):
        selected = self._load_selection(user, self._stores(profile))['storeId']
        if not selected:
            raise WorkbenchError('STORE_REQUIRED', '请先明确选择云端已绑定门店分组', 403)
        return selected

    def _save_selection(self, user, stores, data, *, apply):""",1),
 ("        if apply and (data.get('searchPresetId')", "        if apply and data.get('storeId') != self._load_selection(user, stores)['storeId']:\n            raise WorkbenchError('STORE_FORBIDDEN', '请先切换当前门店再应用预设', 403)\n        if apply and (data.get('searchPresetId')",1),
 ("actor = {'username': user['username'], 'storeId': (profile or {}).get('store_id', '')}", "actor = {'username': user['username'], 'storeId': self._load_selection(user, self._stores(profile))['storeId'] if profile else ''}",1),
 ("            if action == 'platform_snapshot':", "            if action == 'platform_snapshot':",1),
 ("            if self.platform_runtime is None:\n                raise WorkbenchError('PLATFORM_UNAVAILABLE'", "            if user.get('role') == 'admin':\n                self._selected_store(user, profile)\n            if self.platform_runtime is None:\n                raise WorkbenchError('PLATFORM_UNAVAILABLE'",1),
 ("                if data.get('storeId') not in {store['id'] for store in stores}:", "                if data.get('storeId') != self._selected_store(user, profile):",1),
 ("payload = {'platform': platform, 'accountId': account, 'region': data.get('region', ''),", "payload = {'platform': platform, 'accountId': account, 'region': data.get('region', ''), 'storeId':data['storeId'],",1),
 ("            actor = dict(user)", "            store_id = self._selected_store(user, profile)\n            actor = dict(user)",1)])

p=ROOT/'work/ui-native-r57/workbench_backend.py';s=p.read_text('utf-8')
start=s.index('    def _customer_dispatch(');end=s.index('    def dispatch(',start)
part=s[start:end];assert part.count("stores[0]['id']")==5
s=s[:start]+part.replace("stores[0]['id']",'store_id')+s[end:]
old="""                    if data['storeId'] not in {row['id'] for row in stores}:
                        raise WorkbenchError('STORE_FORBIDDEN','当前门店已变化，请重新读取',403)"""
new="""                    store_id = self._selected_store(user, profile)
                    if data['storeId'] != store_id:
                        raise WorkbenchError('STORE_FORBIDDEN','当前门店已变化，请重新读取',403)"""
assert s.count(old)==1;s=s.replace(old,new)
assert s.count("stores[0]['id']")==3
s=s.replace("self.reply_delivery.execute(action,user,stores[0]['id'],data,",'self.reply_delivery.execute(action,user,store_id,data,')
s=s.replace("self.reply_workbench.execute(action,user,stores[0]['id'],data)",'self.reply_workbench.execute(action,user,store_id,data)')
s=s.replace("employee_only=True)","employee_only=False)")
p.write_text(s,'utf-8',newline='\n')

edit('work/ui-native-r57/customer_workbench.py',[
 ("saved.get('role') != 'operator'", "saved.get('role') not in ('operator','admin')",1),
 ("        return saved, {'username':saved['username'], 'storeId':store_id}", """        if saved['role'] == 'admin' and user.get('_workbench_store_id') != store_id:
            _fail('STORE_FORBIDDEN','请先选择当前已授权门店分组',403)
        return {**saved,'_workbench_store_id':store_id}, {'username':saved['username'], 'storeId':store_id}""",1),
 ("            for record in (lead, task):", """            if actor.get('role') == 'admin' and not any(record.get('store_id') for record in (lead,task)):
                raise CoreError('历史客户未核实来源门店，管理员多店视图不推断归属')
            for record in (lead, task):""",1)])
edit('work/ui-native-r57/store_materials.py',[("current.get('role') != 'operator'", "current.get('role') not in ('operator','admin')",1)])
edit('work/ui-native-r57/reply_delivery.py',[("profile.get('store_id')!=value['plan']['storeId']", "profile.get('_workbench_store_id',profile.get('store_id'))!=value['plan']['storeId']",1)])

edit('work/shared-backend-integration/platform_runtime.py',[
 ("saved.get('role') != 'operator'", "saved.get('role') not in ('operator','admin')",1),
 ("        return self.core._public(saved)", "        return {**self.core._public(saved),'_workbench_store_id':user.get('_workbench_store_id','')}",1),
 ("            self.core._account_access(user,account)", """            self.core._account_access(user,account)
            if user.get('role') == 'admin' and (account.get('cloud_owner') != user['username']
                    or account.get('store_id') not in (None,'',user.get('_workbench_store_id'))):
                raise ValueError('账号不属于当前管理员与门店')""",1),
 ("            self.core._task_access(user,task,user['tenant_id'])\n            return task", """            self.core._task_access(user,task,user['tenant_id'])
            if user.get('role') == 'admin' and (task.get('cloud_owner') != user['username']
                    or not user.get('_workbench_store_id') or task.get('store_id') != user['_workbench_store_id']):
                raise ValueError('任务未绑定当前管理员与门店')
            return task""",1),
 ("        tasks.sort(key=lambda row:", """        if user.get('role') == 'admin':
            selected=user.get('_workbench_store_id')
            accounts=[row for row in accounts if selected and row.get('cloud_owner')==user['username']
                and row.get('store_id') in (None,'',selected)]
            tasks=[row for row in tasks if selected and row.get('cloud_owner')==user['username']
                and row.get('store_id')==selected]
        tasks.sort(key=lambda row:""",1),
 ("'principal':{'username':user['username'],'role':'operator'}", "'principal':{'username':user['username'],'role':user['role']}",1),
 ("'taskName','time','rentalAssessment'}", "'taskName','time','rentalAssessment','storeId'}",1),
 ("            if data.get('rentalAssessment'):", """            if data.get('storeId'):
                with self.core.lock:
                    record=self.core._get('tasks',saved['id'],user['tenant_id'])
                    record['store_id']=data['storeId']
                    self.core.store.put('tasks',record)
            if data.get('rentalAssessment'):""",1)])
# Never manufacture the owner as operator. The actual saved/cloud-verified role
# is carried unchanged through local account helpers and executor commands.
edit('work/shared-backend-integration/vendor-src/assistant/service.py',[
 ("        # A local loopback request has no cloud role assertion. Give it only\n        # the owner's operator scope; cloud commands carry their verified role.\n        command={'owner': owner, 'principal': {'username': owner, 'role': 'operator'}}", """        tenant='cloud-'+hashlib.sha256((self.environment_id+'\\n'+self.company_id).encode()).hexdigest()[:24]
        ident=hashlib.sha256((tenant+'\\n'+owner).encode()).hexdigest()
        saved=self.server.core.store.get('users',ident)
        if (not saved or saved.get('username')!=owner or saved.get('tenant_id')!=tenant
                or saved.get('disabled') or saved.get('cloud_bound') is not True
                or saved.get('role') not in ('admin','operator')):
            raise ValueError('本机绑定身份尚未核实')
        verified=self.server.integrations.verify_identity(saved,expected_user=saved)
        if not verified or verified.get('role')!=saved['role']:
            raise ValueError('本机绑定身份已变化')
        command={'owner': owner, 'principal': {'username': owner, 'role': verified['role']}}""",1),
 ("'role': 'operator'", "'role': user['role']",3),
 ("'role':'operator'", "'role':user['role']",1)])

edit('work/ui-approved-implementation/ui-preview/app.mjs',[
 ("const store=state.stores.find(item=>item.id===state.selection?.storeId)||state.stores[0];", "const store=state.stores.find(item=>item.id===state.selection?.storeId);",1),
 ("登录成功，门店待管理员分配", "登录成功，请到管理页选择已授权门店分组",1),
 ("使用管理员分配的员工账号与密码登录。", "使用已开通的管理员或员工账号与密码登录。管理员需明确选择云端已绑定门店分组。",1)])

metadata=ROOT/'work/shared-backend-integration/vendor-src/SOURCE.json'
value=json.loads(metadata.read_text('utf-8'))
value['reason'] += '; r57 admin role preserved with exact expected_user checks and own-device identity; original platform guards retained'
for name in ('integrations.py','assistant/service.py'):
    value['files'][name]={'source_sha256':hashlib.sha256((ROOT/'work/ui-runtime-r55/src'/name).read_bytes()).hexdigest(),
        'candidate_sha256':hashlib.sha256((metadata.parent/name).read_bytes()).hexdigest()}
metadata.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n','utf-8')
print('local adaptation sources prepared; canonical untouched')
