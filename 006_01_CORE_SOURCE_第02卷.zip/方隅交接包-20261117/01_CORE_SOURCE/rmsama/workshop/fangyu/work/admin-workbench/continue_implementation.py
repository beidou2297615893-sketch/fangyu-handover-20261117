from pathlib import Path
script=Path(__file__).with_name('implement.py').read_text('utf-8')
exec(compile(script[:script.index('# All components')],__file__,'exec'))
exec(compile(script[script.index("edit('work/shared-backend-integration/platform_runtime.py'"):],__file__,'exec'))
