"""Isolated r57 admin/operator fixtures. No real network/platform/AI/send."""
import hashlib,importlib.util,sys,tempfile,time,unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
ROOT=Path(__file__).resolve().parents[2]
sys.dont_write_bytecode=True
sys.path[:0]=[str(ROOT/'work/ui-native-r57'),str(ROOT/'work/shared-backend-integration/vendor-src'),str(ROOT/'work/ui-runtime-r55/src')]
from workbench_backend import WorkbenchBackend,WorkbenchError
from customer_workbench import CustomerWorkbench
from integrations import IntegrationError

class Cloud:
    def __init__(self):
        self.role='admin';self.old=False;self.stores=['store-a','store-b'];self.calls=[];self.own_store=None
    def __call__(self,url,data,token=''):
        op=data['operation'];self.calls.append(op)
        if op not in ('login','me','members','logout'):raise AssertionError('unapproved fixture action')
        user={'username':'fixture-admin' if self.role=='admin' else 'fixture-operator','role':self.role,
            'disabled':False,'can_reply':False}
        if self.role=='operator':user['store_id']='store-a'
        elif self.own_store:user['store_id']=self.own_store
        result={'contract':'fangyu-workspace-v1','environment_id':'admin-fixture','company_id':'fangyu-apartment-client','user':user}
        if op=='login':result.update(token='synthetic-access',expires=time.time()+3600)
        if op=='members':
            result['users']=[{'username':'staff-'+str(i),'role':'operator','disabled':False,'store_id':ident} for i,ident in enumerate(self.stores)]
            if not self.old:result['member_management']={'version':'store-members-v1','actor':{'username':user['username'],'role':'admin'},'scope':{'type':'company','store_id':'','stamp':'not-a-directory-version'}}
        return result

class AdminWorkbench(unittest.TestCase):
    def setUp(self):
        run=ROOT/'work/admin-workbench/test-runs';run.mkdir(exist_ok=True)
        self.temp=tempfile.TemporaryDirectory(dir=run);self.cloud=Cloud()
        self.patch=patch('integrations.request_json',side_effect=self.cloud);self.patch.start()
        self.company={'id':'fangyu-apartment-client','edition':'customer','personalMode':False,'authMode':'managed',
            'managedWorkspace':{'environment_id':'admin-fixture','endpoint':'https://example.invalid/workspace'}}
        self.backend=WorkbenchBackend(ROOT,self.temp.name,self.company,customer_factory=CustomerWorkbench)
    def tearDown(self):self.backend.close();self.patch.stop();self.temp.cleanup()
    def login(self):
        result=self.backend.dispatch('login',{'username':'fixture-admin' if self.cloud.role=='admin' else 'fixture-operator','password':'[REDACTED:assigned_secret]'})
        self.token=result['token'];return result
    def choose(self,ident):
        boot=self.backend.dispatch('bootstrap',{},self.token)
        return self.backend.dispatch('select_store',{'storeId':ident,'expectedRevision':boot['selection']['revision']},self.token)
    def lead(self,ident,store=None,owner='fixture-admin'):
        user=self.backend.core.session(self.token)
        row={'id':ident,'tenant_id':user['tenant_id'],'cloud_owner':owner,'platform':'xiaohongshu',
            'source_type':'comment','source_id':ident,'comment_id':ident,'author_id':ident,'author':ident,
            'text':'合成求租需求','content_title':'合成来源','published_at':'2026-10-16T09:00:00+08:00',
            'created_at':'2026-10-16T09:00:00+08:00'}
        if store is not None:row['store_id']=store
        self.backend.core.store.put('leads',row)
    def test_admin_modern_directory_requires_explicit_selection_and_revocation_is_immediate(self):
        boot=self.login();self.assertEqual(boot['session']['user']['role'],'admin')
        self.assertEqual(boot['selection']['storeId'],'');self.assertFalse(boot['capabilities']['presets'])
        self.assertEqual([r['id'] for r in boot['stores']],['store-a','store-b'])
        chosen=self.choose('store-b');self.assertEqual(chosen['selection']['storeId'],'store-b')
        self.assertEqual(chosen['materials']['authorizedStores'][1]['id'],'store-b')
        user=self.backend.core.session(self.token)
        self.backend.workflow.keyword_state(user,{'mode':'save','city':'测试市','area':'测试区',
            'expected_revision':0,'keywords':['合成搜索词'],'selected':['合成搜索词']})
        applied=self.backend.dispatch('apply_preset',{'storeId':'store-b','searchPresetId':'precise',
            'intentPresetId':'standard','expectedRevision':chosen['selection']['revision']},self.token)
        self.assertEqual(applied['selection']['storeId'],'store-b')
        self.assertEqual(applied['selection']['applied']['selectedKeywords'],['合成搜索词'])
        with self.assertRaises(WorkbenchError):self.backend.dispatch('apply_preset',{'storeId':'store-a',
            'searchPresetId':'precise','intentPresetId':'standard','expectedRevision':applied['selection']['revision']},self.token)
        with self.assertRaises(WorkbenchError):self.choose('material-only-id')
        self.cloud.stores=['store-a']
        fresh=self.backend.dispatch('bootstrap',{},self.token)
        self.assertEqual(fresh['selection']['storeId'],'');self.assertEqual(fresh['session']['user']['role'],'admin')
        self.assertEqual(self.backend.dispatch('customers',{},self.token)['customers']['items'],[])
    def test_old_cloud_directory_preserves_login_and_returns_explicit_empty_state(self):
        self.cloud.old=True;boot=self.login()
        self.assertEqual(boot['session']['user']['role'],'admin');self.assertEqual(boot['stores'],[])
        self.assertEqual(boot['selection']['storeId'],'');self.assertIn('目录版本',boot['notice'])
        self.assertFalse(boot['capabilities']['presets']);self.assertIsNotNone(self.backend.core.session(self.token))
        with self.assertRaises(WorkbenchError):self.backend.dispatch('platform_prepare',{},self.token)
        self.assertEqual(self.backend.dispatch('customers',{},self.token)['customers']['total'],0)
        self.cloud.own_store='self-confirmed-store'
        fresh=self.backend.dispatch('bootstrap',{},self.token)
        self.assertEqual([row['id'] for row in fresh['stores']],['self-confirmed-store'])
        self.assertEqual(fresh['selection']['storeId'],'')
    def test_customers_and_replies_do_not_cross_store_or_assign_unbound_admin_history(self):
        self.login();self.choose('store-a')
        self.lead('own-a','store-a');self.lead('own-b','store-b');self.lead('unbound')
        self.lead('foreign-a','store-a','other-operator')
        first=self.backend.dispatch('customers',{},self.token)['customers']
        self.assertEqual([r['name'] for r in first['items']],['own-a'])
        with self.assertRaises(WorkbenchError):self.backend.dispatch('reply_read',{'storeId':'store-b','customerId':first['items'][0]['id']},self.token)
        self.backend.dispatch('reply_read',{'storeId':'store-a','customerId':first['items'][0]['id']},self.token)
        self.choose('store-b')
        second=self.backend.dispatch('customers',{},self.token)['customers']
        self.assertEqual([r['name'] for r in second['items']],['own-b'])
        with self.assertRaises(WorkbenchError):self.backend.dispatch('customer_detail',{'id':first['items'][0]['id']},self.token)
    def test_expected_user_keeps_admin_role_and_rejects_different_role(self):
        self.login();user=self.backend.core.session(self.token)
        verified=self.backend.integrations.verify_identity(user,expected_user=user)
        self.assertEqual(verified['role'],'admin')
        forged={**user,'role':'operator'}
        self.assertIsNone(self.backend.integrations.verify_identity(user,expected_user=forged))
        self.assertEqual(self.backend.core.store.get('users',user['id'])['role'],'admin')
        result=self.backend.integrations.enter({'username':'fixture-admin','password':'[REDACTED:assigned_secret]'},expected_user=user,expected_guard=lambda:True)
        self.assertEqual(result['user']['role'],'admin')
    def test_operator_original_single_store_and_unbound_own_history_are_retained(self):
        self.cloud.role='operator';boot=self.login()
        self.assertEqual(boot['selection']['storeId'],'store-a');self.assertNotIn('members',self.cloud.calls)
        self.lead('operator-history',owner='fixture-operator')
        rows=self.backend.dispatch('customers',{},self.token)['customers']['items']
        self.assertEqual([r['name'] for r in rows],['operator-history'])
        self.assertEqual(self.backend.core.session(self.token)['role'],'operator')
    def test_platform_principal_preserves_role_and_original_hold_guards(self):
        self.login();self.choose('store-a');user,_=self.backend._identity(self.token)
        spec=importlib.util.spec_from_file_location('isolated_platform_runtime',ROOT/'work/shared-backend-integration/platform_runtime.py')
        module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
        runtime=module.PlatformRuntime.__new__(module.PlatformRuntime)
        runtime.closed=False;runtime.core=self.backend.core;runtime.server=SimpleNamespace(company=self.company)
        self.assertEqual(runtime._principal(user)['role'],'admin')
        with self.assertRaises(module.PlatformRuntimeError):runtime._principal({**user,'role':'operator'})
        seen=[];runtime._execute(lambda command:seen.append(command),user,'account_create',{})
        self.assertEqual(seen[0]['principal']['role'],'admin')
        runtime._device=lambda actor:{'bound':True,'state':'online','message':''}
        runtime.service=SimpleNamespace(state='online',executor=object())
        runtime.server.company['platforms']=['xiaohongshu'];runtime.server.company['runtime']={}
        runtime.core.remote_safety_hold=True
        self.assertEqual(runtime._readiness(user,{'platform':'xiaohongshu','id':'fixture-account'})[0],'platform_held')

if __name__=='__main__':unittest.main(verbosity=2)
