# 最新状态

身份里程碑已由中央门店版4a673681承继并晋级、实际打开。rmsama可在中央14门店中切换；本文件下方无中央目录/尚未晋级是身份批历史。以 ../../memory/sessions/2026-10-17-central-store-config.md 和 ../central-store-config/ROOT-ACCEPTED.json 为准。

---

# 管理员工作台：身份批候选交接

当前候选 `ui-r57-20261017T044043Z-131cdcd1`，99 文件。尚未晋级，尚未打开、关闭或切换任何实际窗口。canonical 仍为 `ui-r57-20261016T184155Z-cc4246f5`。

- manifest SHA256：`328E775012EDE42EAB1F38516468D259FB14521F020423373D7D5845D83E9F4B`
- launcher SHA256：`010737AFD2AF9071D632718C8D39E2A138D669D67DBD228E3323BEECAB8E089F`
- 候选目录：`C:/积木软件工坊/项目/方隅公寓客户版/work/ui-native-r57/releases/ui-r57-20261017T044043Z-131cdcd1`
- 启动文件：`C:/积木软件工坊/项目/方隅公寓客户版/work/ui-native-r57/run_candidate.ui-r57-20261017T044043Z-131cdcd1.py`
- 启动文件所在文件夹：`C:/积木软件工坊/项目/方隅公寓客户版/work/ui-native-r57`

本批行为：

- 允许云端实际 `admin` 与原 `operator` 登录，始终保留真实角色。r57 独立 vendor 身份副本对 expected_user 比较真实角色；冻结 r55 原件不变。平台执行命令、本地助手、客户、资料、回复和开发入口不再将管理员伪装成 operator。
- 管理员没有默认第一门店。每次请求重新核对身份及授权目录，再从持久明确选择取得当前门店；选店撤销后清空有效上下文，不自动转到另一门店。客户、预设、平台和回复使用同一当前选择。
- 当前线上旧 members 缺少可信多店 scope，且根任务已核实真实两账号都无门店绑定。此时管理员仍可进入五页，但显示无绑定空态，不从本地资料包补造门店。客户列表返回明确空结果，业务写入和平台准备保持阻止。
- 若以后 me 返回管理员本人已核实的 store_id，可将其作为单店候选，仍要求明确选择；旧 members 不能授权其他门店。
- 管理员本机客户/任务/账号仍受本人所有权限制；明确跨店来源拒绝。未绑定历史客户和账号不随切店自动归店，operator 原单店历史行为保持。
- 云端 ROLE_INELIGIBLE、设备所有权、平台许可、hold、租约、验证码与发送守卫保持。登录管理员并不表示其设备已经获得平台读取或发送许可。

目录衔接点是 `workbench_backend.py` 的 `_read_admin_store_directory(integration, user, profile)`。现阶段只读兼容 me/members；下一批应串行接入唯一中央云目录，并用真实云 scope 替换此兼容读取。它不是资料包授权接口，也没有把本地选店/预设保存冒充云端保存。

用户最新授权覆盖先选单店方向：14 组已有资料、搜索词、采集词、意向与预算配置应统一归同一上海环境管理，不逐店向用户索要资料。此身份批未部署中央目录、未导入资料、未把本地 14 组资料当真实云授权。下一批以根提供的基于实际 live-backup 的有界云契约为准，禁止整包覆盖较新 workspace 源码。

验证命令：

```powershell
& 'C:/积木软件工坊/项目/方隅公寓客户版/work/desktop-python/Scripts/python.exe' -B .\test_admin_workbench.py
& 'C:/积木软件工坊/项目/方隅公寓客户版/work/desktop-python/Scripts/python.exe' -B .\verify_candidate.py ui-r57-20261017T044043Z-131cdcd1
```

结果：6 项新隔离 fixture 通过；原员工应用预设/重开恢复、退出远端回执丢失两项代表行为通过；前端 app.mjs 语法通过。候选实际固定导入通过，9 个 CSS/fit 哈希全部与 canonical 相同，冻结 r55 依赖逐文件核验通过。仅使用合成隔离数据；未登录真实 r57 管理员、未采集、未调用付费 AI、未发送、未写真实资料，也没有 UI 图审或用户试用验收。

本目录 baseline 是本批前的轻量源码回退依据；implement.py、continue_implementation.py、finalize_scope.py 是已执行的一次性工作记录，不能用作正常启动或重复迁移入口。
