from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
p=ROOT/'work/ui-native-r57/workbench_backend.py';s=p.read_text('utf-8')
start=s.index("        if verified['role'] == 'admin':\n")
end=s.index('        stores = self._stores(profile)\n',start)
s=s[:start]+"""        if verified['role'] == 'admin':
            rows, directory_notice = self._read_admin_store_directory(integration, verified, profile)
            profile['_workbench_stores'] = rows
            profile['_workbench_directory_notice'] = directory_notice
"""+s[end:]
marker='    def _stores(self, profile):\n'
helper="""    def _read_admin_store_directory(self, integration, user, profile):
        \"\"\"Trusted directory seam; a central cloud directory will replace this compatibility reader.

        Existing members is only a bound-group fallback, never a material catalog.
        Missing old-cloud scope cannot revoke an already verified administrator.
        \"\"\"
        own = profile.get('store_id')
        ids = {own} if isinstance(own,str) and STORE_ID.fullmatch(own) else set()
        notice = ''
        try:
            config = integration._read(user['tenant_id'])
            directory = integration._cloud(config, user, 'members')
        except IntegrationError:
            directory = {}
        scope = directory.get('member_management') or {}
        actor = scope.get('actor') or {}
        valid = (directory.get('contract') == 'fangyu-workspace-v1'
            and directory.get('company_id') == COMPANY_ID
            and directory.get('environment_id') == self.company['managedWorkspace']['environment_id']
            and scope.get('version') == 'store-members-v1'
            and actor.get('username') == user['username'] and actor.get('role') == 'admin'
            and (scope.get('scope') or {}).get('type') == 'company'
            and (scope.get('scope') or {}).get('store_id') == ''
            and isinstance(directory.get('users'), list))
        if valid:
            ids.update(row['store_id'] for row in directory['users']
                if isinstance(row,dict) and row.get('role') == 'operator' and row.get('disabled') is False
                and isinstance(row.get('store_id'),str) and STORE_ID.fullmatch(row['store_id']))
        else:
            notice = ('已以管理员身份登录；云端目录版本尚不含多店授权范围，仅可选择本人已核实绑定' if ids
                else '已以管理员身份登录；云端门店目录版本尚未提供可核实授权范围，中央门店配置接入前保持无绑定空态')
        return ([{'id':ident,'name':ident,'description':'云端已核实门店分组','region':''}
            for ident in sorted(ids)], notice)

"""
assert s.count(marker)==1;s=s.replace(marker,helper+marker)
old="""            if not stores:
                raise WorkbenchError('STORE_REQUIRED', '请管理员先分配门店', 403)"""
new="""            if not stores or not self._load_selection(user,stores)['storeId']:
                if action == 'customers' and user.get('role') == 'admin':
                    return {'customers':{'actor':{'username':user['username'],'storeId':''},
                        'scope':'employee-local-history','items':[],'stats':{'total':0,'high':0,'replied':0,'handoff':0},
                        'total':0,'page':1,'pageSize':20,'pages':0,
                        'scopeNotice':profile.get('_workbench_directory_notice') or '请先选择已授权门店分组'}}
                raise WorkbenchError('STORE_REQUIRED', '请先选择已核实门店分组', 403)"""
assert s.count(old)==1;s=s.replace(old,new);p.write_text(s,'utf-8',newline='\n')
p=ROOT/'work/ui-native-r57/store_materials.py';s=p.read_text('utf-8')
s=s.replace("else stores[0]['id'] if stores else None", "else stores[0]['id'] if stores and user.get('role') == 'operator' else None")
p.write_text(s,'utf-8',newline='\n')
p=ROOT/'work/shared-backend-integration/platform_runtime.py';s=p.read_text('utf-8')
s=s.replace("or account.get('store_id') not in (None,'',user.get('_workbench_store_id')))","or not user.get('_workbench_store_id') or account.get('store_id') != user['_workbench_store_id'])")
s=s.replace("and row.get('store_id') in (None,'',selected)]", "and row.get('store_id') == selected]")
old="""        self._account(user,ident)
        return {'result':{'accountId':ident,'status':'created'"""
new="""        if user.get('role') == 'admin':
            record=self.core._get('accounts',ident,user['tenant_id'])
            selected=user.get('_workbench_store_id')
            if (not selected or record.get('cloud_owner') != user['username']
                    or record.get('store_id') not in (None,'',selected)):
                raise PlatformRuntimeError('ACCOUNT_SCOPE_UNCONFIRMED','新账号归属未核实，请保留原结果核对',503,mutation_committed=True)
            record['store_id']=selected
            self.core.store.put('accounts',record)
        self._account(user,ident)
        return {'result':{'accountId':ident,'status':'created'"""
assert s.count(old)==1;s=s.replace(old,new);p.write_text(s,'utf-8',newline='\n')
print('directory seam, legacy empty state and strict admin source scope finalized')
