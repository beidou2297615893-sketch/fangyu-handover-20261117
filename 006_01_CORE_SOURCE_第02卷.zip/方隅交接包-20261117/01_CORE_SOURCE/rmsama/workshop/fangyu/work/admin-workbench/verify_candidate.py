"""Pinned import and visual-byte verification with synthetic data; never starts UI/services."""
import hashlib,importlib.util,json,sys,tempfile
from pathlib import Path
from unittest.mock import patch
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parents[2]
release_id=sys.argv[1]
release=ROOT/'work/ui-native-r57/releases'/release_id
manifest=json.loads((release/'RELEASE.json').read_text('utf-8'))
spec=importlib.util.spec_from_file_location('isolated_candidate_host',release/'ui_native_host.py')
host=importlib.util.module_from_spec(spec);sys.modules[spec.name]=host;spec.loader.exec_module(host)
manifest_sha=hashlib.sha256((release/'RELEASE.json').read_bytes()).hexdigest().upper()
_,files=host.verify_release(release,manifest_sha)
host.verify_backend_dependencies(release,files,ROOT)
visual=json.loads((ROOT/'work/admin-workbench/baseline/visual-hashes.json').read_text('utf-8-sig'))
assert len(visual)==9
for row in visual:assert hashlib.sha256((release/row['path']).read_bytes()).hexdigest().upper()==row['sha256']
run=ROOT/'work/admin-workbench/test-runs';run.mkdir(exist_ok=True)
with tempfile.TemporaryDirectory(dir=run) as temp, patch('socket.socket.connect',side_effect=AssertionError('network forbidden')):
    company={'id':'fangyu-apartment-client','edition':'customer','personalMode':False,'authMode':'managed',
        'platforms':['xiaohongshu','douyin'],'managedWorkspace':{'environment_id':'isolated-host-fixture','endpoint':'https://example.invalid/workspace'}}
    backend=host.create_backend(release,files,project_root=ROOT,data_dir=temp,company=company)
    try:
        assert backend.dispatch('bootstrap',{})['session'] is None
        assert Path(sys.modules['integrations'].__file__).is_relative_to(release)
        assert backend.platform_runtime.service.executor is None
        assert backend.platform_runtime.service.state=='unbound'
    finally:backend.close()
canonical=json.loads((ROOT/'work/ui-native-r57/FROZEN.json').read_text('utf-8'))
assert canonical['release_id']=='ui-r57-20261016T184155Z-cc4246f5'
result={'candidate':release_id,'files':len(files),'manifest_sha256':manifest_sha,
    'visualBytesUnchanged':9,'pinnedBackendImport':True,'networkCalls':0,'servicesStarted':False,
    'canonicalUnchanged':canonical['release_id'],'uiOpened':False,'realDataAccess':False}
print(json.dumps(result))
