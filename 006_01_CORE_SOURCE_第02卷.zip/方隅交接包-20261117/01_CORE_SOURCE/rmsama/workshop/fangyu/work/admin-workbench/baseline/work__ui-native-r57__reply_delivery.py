"""Explicit snapshot authorization around the preserved sequential reply queue.

The scheduler, account lease, contact journal and unknown-result rules remain
the original implementation. Only r57 employee/store/source validation is added.
"""
import threading,hashlib,json,re
from uuid import uuid4
from datetime import datetime,timezone
from core import CoreError
from core.adapters import AdapterBusy
from core.review_queue import ReviewedReplyQueues, require_reply_permission, snapshot
KEY=re.compile(r'[A-Za-z0-9_-]{1,160}\Z')
class DeliveryError(ValueError):
    def __init__(self,code,message,status=400):
        super().__init__(message);self.code,self.status=code,status
def fail(code,message,status=400):raise DeliveryError(code,message,status)
def digest(value):return hashlib.sha256(json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()

ENTITY='ui_reply_delivery_v1'
ACTIONS=frozenset(('reply_delivery_prepare','reply_delivery_start','reply_delivery_status','reply_delivery_cancel'))


class ScopedReviewedQueues(ReviewedReplyQueues):
    def __init__(self, core, owner):
        super().__init__(core,defer_startup_recovery=True)
        self.owner=owner
        # Only an explicit .start below creates a worker; construction never
        # resumes any ready or historical queue.
        self.autostart=True

    def _validate(self, reply, user, tenant, account, expected=None):
        result=super()._validate(reply,user,tenant,account,expected)
        if expected is not None:
            callback=self.owner.validation(reply['id'],expected)
            callback(False)
            if getattr(self.owner.local,'processing',False):self.owner.local.callback=callback
        return result

    def process(self, ident):
        self.owner.local.processing=True
        try:return super().process(ident)
        finally:
            self.owner.local.processing=False
            self.owner.local.callback=None


class ReplyDelivery:
    def __init__(self,core,replies,runtime):
        self.core,self.replies,self.runtime=core,replies,runtime
        self.active={}
        self.local=threading.local()
        previous=core.reviewed_reply_queues
        if previous._workers:fail('DELIVERY_BUSY','原回复队列仍在运行，不能替换运行组件',409)
        core.reviewed_reply_queues=ScopedReviewedQueues(core,self)
        original=core.adapters.platform_guard
        def guarded(platform):
            if callable(original):original(platform)
            callback=getattr(self.local,'callback',None)
            if callback:
                # Adapters also invokes this immediately before Popen while
                # holding lifecycle_lock. Never wait for Core in that order:
                # cancel/close can already hold Core while waiting lifecycle.
                # Outside lifecycle the normal Core lock order is safe; a
                # routine read should not make these earlier checks fail.
                if not core.lock.acquire(blocking=not core.adapters.lifecycle_lock.locked()):
                    raise AdapterBusy('原后台正在变更账号状态；本条未启动CLI，本批已停止，请核对')
                try:callback(True)
                finally:core.lock.release()
        core.adapters.platform_guard=guarded

    def validation(self,reply_id,expected):
        values=[value for value in list(self.active.values()) if any(
            row['replyId']==reply_id and row['snapshot']==expected for row in value['plan']['items'])]
        if len(values)!=1:fail('DELIVERY_AUTH_EXPIRED','本批授权已失效；重开后不会自动续发',409)
        value=values[0]
        row=next(r for r in value['plan']['items'] if r['replyId']==reply_id)
        def fresh(boundary):
            user,profile=value['refresh']()
            if profile.get('store_id')!=value['plan']['storeId']:
                fail('STORE_FORBIDDEN','门店范围已变化，本批已停止',403)
            queue=self.core._get('reply_queues',value['plan']['queueId'],user['tenant_id'])
            plan=value['plan']
            if (queue.get('snapshots')!=[r['snapshot'] for r in plan['items']]
                    or queue.get('reply_ids')!=[r['replyId'] for r in plan['items']]
                    or queue.get('account_id')!=row['accountId'] or queue.get('authorized_by')!=user['id']
                    or queue.get('status') not in ('ready','awaiting_collection','running')):
                fail('DELIVERY_AUTH_CHANGED','原队列授权或快照已变化，本批已停止',409)
            self._target(user,value['plan']['storeId'],row,allow_sending=boundary)
            if self.runtime is None:fail('PLATFORM_UNAVAILABLE','平台后台尚未就绪',503)
            self.runtime.reply_guard(user,row['accountId'])
        return fresh

    def _target(self,user,store_id,row,*,allow_sending=False):
        actor,_,_,person=self.replies._context(user,store_id,row['customerId'])
        if row['leadId'] not in {c['lead_id'] for c in person.get('comments') or []}:
            fail('DELIVERY_SCOPE_CHANGED','原评论已不在客户可见范围',403)
        lead=self.core._get('leads',row['leadId'],user['tenant_id'])
        reply=self.core._get('replies',row['replyId'],user['tenant_id'])
        account=self.core._get('accounts',row['accountId'],user['tenant_id'])
        require_reply_permission(self.core,actor,lead,reply)
        self.core._account_access(actor,account)
        allowed=('approved','sending') if allow_sending else ('approved',)
        if (digest(lead)!=row['sourceDigest'] or reply.get('status') not in allowed
                or reply.get('lead_id')!=row['leadId'] or reply.get('version')!=row['version']
                or reply.get('text')!=row['text'] or reply.get('review_account_id')!=row['accountId']
                or account.get('store_id') not in (None,'',store_id)
                or snapshot(self.core,reply,lead,account,user=actor)!=row['snapshot']
                or reply.get('approval_snapshot')!=row['snapshot']):
            fail('DELIVERY_SNAPSHOT_CHANGED','原评论、草稿或执行账号已变化，本批已停止；请重新核对',409)
        return reply

    def _plan(self,user,store_id,ident):
        if not isinstance(ident,str) or not KEY.fullmatch(ident):fail('INPUT_INVALID','回复批次编号无效')
        plan=self.core.store.get(ENTITY,ident)
        if (not plan or plan.get('tenant_id')!=user['tenant_id'] or plan.get('userId')!=user['id']
                or plan.get('owner')!=user['username'] or plan.get('storeId')!=store_id):
            fail('DELIVERY_FORBIDDEN','回复批次不存在或不在当前员工门店范围',403)
        for row in plan['items']:
            _,_,_,person=self.replies._context(user,store_id,row['customerId'])
            if row['leadId'] not in {c['lead_id'] for c in person.get('comments') or []}:
                fail('DELIVERY_FORBIDDEN','本批原评论可见范围已变化',403)
        return plan

    def status(self,user,store_id,plan):
        queue=self.core.handle('reviewed_reply_queue_status',{'id':plan['queueId']},user)
        state=queue['status']
        if state in ('completed','stopped','cancelled','interrupted'):self.active.pop(plan['id'],None)
        if plan['state']=='prepared' and state=='ready':state='prepared'
        elif plan['state']=='blocked' and state=='ready':state='blocked'
        elif state in ('ready','awaiting_collection','running') and plan['id'] not in self.active:
            state='authorization_expired'
        rows=[]
        for row in plan['items']:
            reply=self.core._get('replies',row['replyId'],user['tenant_id'])
            rows.append({k:v for k,v in row.items() if k!='snapshot'}|{
                'status':reply.get('status'),'message':str(reply.get('last_error') or ''),
                'receipt':self.core.contact_journal.receipt(user['tenant_id'],user['username'],reply['id'],row['leadId'])})
        return {'id':plan['id'],'actor':{'username':user['username'],'storeId':store_id},
            'state':state,'snapshotDigest':plan['snapshotDigest'],'items':rows,
            'prepareRequestId':plan['prepareRequestId'],
            'requestId':plan.get('requestId',''),'processed':queue.get('processed',0),'sent':queue.get('sent',0),
            'message':plan.get('error') or queue.get('message',''),'canStart':state=='prepared',
            'canCancel':state in ('prepared','ready','awaiting_collection','running','authorization_expired')}

    def execute(self,action,user,store_id,data,refresh):
        fields={'reply_delivery_prepare':{'storeId','items','requestId'},'reply_delivery_start':{
            'storeId','id','snapshotDigest','confirmed','requestId'},'reply_delivery_status':{'storeId','id'},
            'reply_delivery_cancel':{'storeId','id'}}[action]
        lookup=action=='reply_delivery_status' and isinstance(data,dict) and set(data)=={'storeId','requestId'}
        recent=action=='reply_delivery_status' and isinstance(data,dict) and set(data)=={'storeId'}
        if not isinstance(data,dict) or (set(data)!=fields and not lookup and not recent):fail('INPUT_INVALID','回复发送参数无效')
        if 'requestId' in data and (not isinstance(data['requestId'],str) or not KEY.fullmatch(data['requestId'])):
            fail('INPUT_INVALID','本批操作编号无效')
        if lookup:
            prior=next((p for p in self.core.store.list(ENTITY,user['tenant_id']) if p.get('userId')==user['id']
                and p.get('storeId')==store_id and p.get('prepareRequestId')==data['requestId']),None)
            if prior:return self.status(user,store_id,self._plan(user,store_id,prior['id']))
            return {'actor':{'username':user['username'],'storeId':store_id},'state':'not_found','prepareRequestId':data['requestId']}
        if recent:
            values=[p for p in self.core.store.list(ENTITY,user['tenant_id']) if p.get('userId')==user['id'] and p.get('storeId')==store_id]
            values.sort(key=lambda p:p.get('createdAt',''))
            history=[];chosen=None
            for value in reversed(values):
                try:
                    plan=self._plan(user,store_id,value['id'])
                    current=self.status(user,store_id,plan)
                except (ValueError,CoreError):continue
                if chosen is None:chosen=current
                history.append({'id':current['id'],'state':current['state'],'count':len(current['items'])})
                if len(history)>=20:break
            return {**(chosen or {'actor':{'username':user['username'],'storeId':store_id},'state':'empty'}),'history':history}
        if action=='reply_delivery_prepare':
            items=data['items']
            if not isinstance(items,list) or not 1<=len(items)<=20:fail('INPUT_INVALID','每批请选择1至20条原评论与已审核草稿')
            prior=next((p for p in self.core.store.list(ENTITY,user['tenant_id']) if p.get('userId')==user['id']
                and p.get('storeId')==store_id and p.get('prepareRequestId')==data['requestId']),None)
            if prior:
                if prior.get('prepareSignature')!=digest(items):fail('DELIVERY_REQUEST_CONFLICT','同一准备编号的内容已变化',409)
                return self.status(user,store_id,self._plan(user,store_id,prior['id']))
            rows=[]
            with self.core.lock:
                for value in items:
                    expected={'customerId','leadId','sourceDigest','replyId','version','accountId'}
                    if not isinstance(value,dict) or set(value)!=expected:fail('INPUT_INVALID','请逐条选择原评论、已审核草稿与本人账号')
                    if (type(value['version']) is not int or value['version']<1
                            or any(not isinstance(value[k],str) or not KEY.fullmatch(value[k]) for k in expected-{'version'})):
                        fail('INPUT_INVALID','原评论、草稿版本或账号格式无效')
                    read=self.replies.read(user,store_id,value['customerId'])
                    source=next((r for r in read['comments'] if r['id']==value['leadId']),None)
                    if (not source or not source['reviewCurrent'] or not source['draft']
                            or source['sourceDigest']!=value['sourceDigest'] or source['draft']['id']!=value['replyId']
                            or source['draft']['version']!=value['version']
                            or source['draft']['review_account_id']!=value['accountId']):
                        fail('DELIVERY_REVIEW_REQUIRED','请先逐条保存并核对当前原评论、草稿与本人账号',409)
                    reply=self.core._get('replies',value['replyId'],user['tenant_id'])
                    lead=self.core._get('leads',value['leadId'],user['tenant_id'])
                    account=self.core._get('accounts',value['accountId'],user['tenant_id'])
                    rows.append({**value,'text':reply['text'],'customerName':read['item']['name'],
                        'comment':source['text'],'postTitle':source['postTitle'],'postUrl':source['postUrl'],
                        'recipient':self.core._reply_recipient(lead,'comment',user=user,account=account),
                        'authorId':str(lead.get('author_id') or ''),'accountName':str(account.get('name') or '本人账号'),'snapshot':reply['approval_snapshot']})
                if len({r['replyId'] for r in rows})!=len(rows):fail('INPUT_INVALID','本批原评论草稿不能重复')
                if len({r['accountId'] for r in rows})!=1:fail('INPUT_INVALID','本批请选择同一个本人执行账号；不同账号请分别准备')
                for previous in self.core.store.list(ENTITY,user['tenant_id']):
                    if previous.get('userId')==user['id'] and previous.get('state')=='submitted':
                        prior=self.core._get('reply_queues',previous['queueId'],user['tenant_id'])
                        if prior.get('status') in ('ready','awaiting_collection','running') and any(
                            r['replyId'] in {x['replyId'] for x in previous['items']} for r in rows):
                            fail('DELIVERY_UNCONFIRMED','所选草稿已有待核对发送批次，请先查看或取消原批次',409)
                queue=self.core.handle('prepare_reply_queue',{'reply_ids':[r['replyId'] for r in rows],
                    'account_id':rows[0]['accountId'],'confirmed':True},user)
                ident=uuid4().hex
                plan={'id':ident,'tenant_id':user['tenant_id'],'userId':user['id'],'owner':user['username'],
                    'createdAt':datetime.now(timezone.utc).isoformat(),
                    'storeId':store_id,'state':'prepared','items':rows,'queueId':queue['id'],
                    'prepareRequestId':data['requestId'],'prepareSignature':digest(items),
                    'snapshotDigest':digest([ident,rows])}
                self.core.store.put(ENTITY,plan)
            return self.status(user,store_id,plan)
        plan=self._plan(user,store_id,data['id'])
        if action=='reply_delivery_status':return self.status(user,store_id,plan)
        if action=='reply_delivery_cancel':
            self.core.handle('cancel_reviewed_reply_queue',{'id':plan['queueId']},user)
            return self.status(user,store_id,plan)
        if (data['confirmed'] is not True or data['snapshotDigest']!=plan['snapshotDigest']
                or not isinstance(data['requestId'],str) or not KEY.fullmatch(data['requestId'])):
            fail('DELIVERY_CONFIRM_REQUIRED','请完整核对本批对象、原评论、正文和账号后明确授权',409)
        if plan['state']!='prepared':
            if data['requestId']==plan.get('requestId'):return self.status(user,store_id,plan)
            fail('DELIVERY_ALREADY_AUTHORIZED','本批已经授权或结果待核对；不会重复发送',409)
        if self.runtime is None:fail('PLATFORM_UNAVAILABLE','平台后台尚未就绪',503)
        with self.core.lock:
            for row in plan['items']:self._target(user,store_id,row)
            for ident,active in list(self.active.items()):
                previous=self.core._get('reply_queues',active['plan']['queueId'],user['tenant_id'])
                if previous.get('status') in ('ready','awaiting_collection','running'):
                    if any(r['replyId'] in {p['replyId'] for p in active['plan']['items']} for r in plan['items']):
                        fail('DELIVERY_BUSY','原草稿已有正在授权的批次，请先核对或取消原批次',409)
                else:self.active.pop(ident,None)
            plan={**plan,'state':'submitted','requestId':data['requestId']}
            self.core.store.put(ENTITY,plan)
            self.active[plan['id']]={'plan':plan,'refresh':refresh}
        try:
            self.runtime.start_reply_queue(user,plan['queueId'])
        except Exception as error:
            queue=self.core._get('reply_queues',plan['queueId'],user['tenant_id'])
            if queue.get('status')=='ready':
                plan={**plan,'state':'blocked','error':str(error)};self.core.store.put(ENTITY,plan)
                self.active.pop(plan['id'],None)
            else:
                fail('DELIVERY_RESULT_UNCONFIRMED','发送授权结果待核对，请只读取本批状态；不会重复提交',409)
        return self.status(user,store_id,plan)
