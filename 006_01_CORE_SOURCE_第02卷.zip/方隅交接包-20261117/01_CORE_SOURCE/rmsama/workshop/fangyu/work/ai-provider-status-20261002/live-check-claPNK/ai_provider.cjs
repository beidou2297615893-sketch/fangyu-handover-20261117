/* DeepSeek transport: fixed official origin, no redirects, no provider errors in responses/logs. */
class ProviderError extends Error {
  constructor(code, {knownUnbilled = false, retryable = false, httpStatus = 0} = {}) {
    super(code); this.code = code; this.knownUnbilled = knownUnbilled; this.retryable = retryable; this.httpStatus = httpStatus;
  }
}
function createProvider({fetchImpl = globalThis.fetch, timeoutMs = 45000} = {}) {
  return async function complete({apiKey, model, messages, maxTokens, tenantId, timeoutMs: remainingTimeoutMs}) {
    const requestTimeout = Math.floor(Math.min(timeoutMs, remainingTimeoutMs === undefined ? timeoutMs : remainingTimeoutMs));
    if (!Number.isFinite(requestTimeout) || requestTimeout <= 0) {
      throw new ProviderError('AI_PROVIDER_TIMEOUT', {knownUnbilled: true});
    }
    const abort = new AbortController(), timer = setTimeout(() => abort.abort(), requestTimeout);
    try {
      const response = await fetchImpl('https://api.deepseek.com/chat/completions', {
        method: 'POST', redirect: 'error', signal: abort.signal,
        headers: {'Content-Type': 'application/json', Authorization: `Bearer ${apiKey}`},
        body: JSON.stringify({model, messages, max_tokens: maxTokens, temperature: 0.1, stream: false,
          thinking: {type: 'disabled'}, response_format: {type: 'json_object'}, user_id: tenantId})
      });
      if (!response.ok) {
        const status = response.status;
        if (status === 402) throw new ProviderError('AI_PROVIDER_BALANCE', {httpStatus: status, knownUnbilled: true, retryable: false});
        if (status === 401) throw new ProviderError('AI_PROVIDER_AUTH', {httpStatus: status, knownUnbilled: true, retryable: false});
        throw new ProviderError('AI_PROVIDER_REJECTED', {httpStatus: status,
          knownUnbilled: [400, 401, 402, 403, 404, 422, 429].includes(status), retryable: status === 429});
      }
      // Stream the HTTP body with a hard bound; corrupted/overlarge replies have unknown usage.
      let data;
      if (response.body?.getReader) {
        const reader = response.body.getReader(); let bytes = 0, pieces = [];
        while (true) {
          const part = await reader.read();
          if (part.done) break;
          bytes += part.value.byteLength;
          if (bytes > 1000000) { await reader.cancel(); throw new ProviderError('AI_PROVIDER_BODY_TOO_LARGE'); }
          pieces.push(Buffer.from(part.value));
        }
        try { data = JSON.parse(Buffer.concat(pieces).toString('utf8')); }
        catch { throw new ProviderError('AI_PROVIDER_INVALID_RESPONSE'); }
      } else {
        // Used by minimal test transports; production fetch exposes getReader.
        data = await response.json();
      }
      return data;
    } catch (error) {
      if (error instanceof ProviderError) throw error;
      throw new ProviderError(abort.signal.aborted ? 'AI_PROVIDER_TIMEOUT' : 'AI_PROVIDER_UNAVAILABLE');
    } finally { clearTimeout(timer); }
  };
}
module.exports = {createProvider, ProviderError};
