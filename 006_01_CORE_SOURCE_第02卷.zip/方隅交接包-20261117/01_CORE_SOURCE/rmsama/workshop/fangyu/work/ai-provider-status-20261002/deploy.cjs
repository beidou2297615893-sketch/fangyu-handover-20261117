const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const {spawnSync}=require('node:child_process');
const project=path.resolve(__dirname,'../..'),cloud=path.join(project,'work/cloud');
const guards=require('../continuous-qa-deploy/deploy.cjs');
const {digest,compare}=require(path.join(cloud,'verify_live_function_tree.cjs'));
const priorReport=JSON.parse(fs.readFileSync(path.join(project,'work/ai-ledger-compat-20261002/deployment.json')));
const baseline=priorReport.verified_code_copy;
const stage=path.join(__dirname,'stage'),reportFile=path.join(__dirname,'deployment.json');
const BASE='7fad45ac46373a9cc5b9ef221bd1e859911f123e4109518a5863dd3170521007';
const ENV='fh6-d5ga45c0ddae7008c',FN='fangyu-workspace',COMPANY='fangyu-apartment-client';
const canonical=o=>JSON.stringify(Object.entries(o).sort(([a],[b])=>a.localeCompare(b)));
const hash=value=>crypto.createHash('sha256').update(value).digest('hex');
const save=value=>fs.writeFileSync(reportFile,JSON.stringify(value,null,2)+'\n');
async function connect(){
 const {getCredentialWithoutCheck}=require(path.join(project,'work/cloud-tools/node_modules/@cloudbase/toolbox'));
 const Manager=require(path.join(project,'work/cloud-tools/node_modules/@cloudbase/manager-node'));
 const sdk=require(path.join(baseline,'node_modules/@cloudbase/node-sdk'));
 const credential=await getCredentialWithoutCheck();
 if(!credential?.secretId||!credential.secretKey)throw Error('credential_unavailable');
 const options={env:ENV,secretId:credential.secretId,secretKey:credential.secretKey};
 if(credential.token)options.sessionToken=credential.token;
 return {manager:new Manager({secretId:credential.secretId,secretKey:credential.secretKey,token:credential.token,envId:ENV,region:'ap-shanghai'}),
  db:sdk.init(options).database()};
}
async function idle(manager,db){
 const acl=await manager.commonService().call({Action:'DescribeDatabaseACL',Param:{CollectionName:'fangyu_workspace_private',EnvId:ENV}});
 if(acl.AclTag!=='ADMINONLY')throw Error('private_acl_differs');
 const response=await db.collection('fangyu_workspace_private').doc(COMPANY).get();
 const state=response?.data?.[0]?.state;
 if(response.code||state?.companyId!==COMPANY||!Array.isArray(state.commands)
   ||state.commands.some(c=>['queued','claimed','running'].includes(c.status))
   ||state.enterpriseAi?.enabled!==true||state.enterpriseAi?.revision!==1)throw Error('idle_or_ai_gate_differs');
 const pending=await db.collection('fangyu_ai_ledger').where({companyId:COMPANY,status:'reserved'}).limit(100).get();
 if(pending.code||pending.data.some(row=>row.attempts?.length))throw Error('provider_may_be_in_flight');
}
function seal(value){
 const plain=Buffer.from(JSON.stringify(value)),python=path.join(project,'work/desktop-python/Scripts/python.exe');
 const helper=path.join(cloud,'dpapi_stream.py');
 const encrypted=spawnSync(python,[helper,'encrypt'],{input:plain,windowsHide:true,maxBuffer:2097152});
 if(encrypted.status!==0||!encrypted.stdout.length)throw Error('config_backup_failed');
 const checked=spawnSync(python,[helper,'decrypt'],{input:encrypted.stdout,windowsHide:true,maxBuffer:2097152});
 if(checked.status!==0||!checked.stdout.equals(plain))throw Error('config_backup_mismatch');
 fs.writeFileSync(path.join(__dirname,'before-config.dpapi'),encrypted.stdout,{flag:'wx'});
 plain.fill(0);checked.stdout.fill(0);
}
function localCheck(){
 if(digest(baseline)!==BASE)throw Error('baseline_differs');
 const delta=compare(baseline,stage);
 if(delta.missing_count||delta.extra_count||delta.changed_count!==2
   ||delta.sample_mismatch.some(item=>!['ai_enterprise.cjs','ai_provider.cjs'].includes(item)))
  throw Error('candidate_delta_differs');
 return digest(stage);
}
async function download(manager,label,expected){
 const folder=fs.mkdtempSync(path.join(__dirname,'live-'+label+'-'));
 await manager.functions.downloadFunctionCode({envId:ENV,functionName:FN,destPath:folder});
 if(digest(folder)!==expected)throw Error('live_tree_differs');
 return folder;
}
async function main(){
 const mode=process.argv[2];
 if(!['--prepare','--deploy','--rollback'].includes(mode))throw Error('invalid_phase');
 const candidate=localCheck(),{manager,db}=await connect();
 if(mode==='--prepare'){
  if(fs.existsSync(reportFile))throw Error('review_already_exists');
  await idle(manager,db);
  const detail=await manager.functions.getFunctionDetail(FN);
  if(detail.Status!=='Active')throw Error('function_not_active');
  const flags=guards.flagsOf(detail),stable=guards.stableConfig(detail);
  const before=await download(manager,'before',BASE);
  seal({flags,stable});
  const report={phase:'prepared',authorization:'User authorized automatic intention analysis and cloud integration. Exact provider balance/auth status compatibility patch; customer config and platform/reply flags remain unchanged.',
   before_sha:BASE,candidate_sha:candidate,before_copy:before,changed_files:['ai_enterprise.cjs','ai_provider.cjs'],
   environment_sha:hash(canonical(flags)),stable_sha:hash(JSON.stringify(stable)),prepared_at:new Date().toISOString()};
  save(report);return {phase:report.phase,candidate_sha:candidate,changed_files:report.changed_files,backups_verified:true};
 }
 const report=JSON.parse(fs.readFileSync(reportFile));
 if(report.candidate_sha!==candidate)throw Error('candidate_changed');
 const detail=await manager.functions.getFunctionDetail(FN);
 if(hash(canonical(guards.flagsOf(detail)))!==report.environment_sha
   ||hash(JSON.stringify(guards.stableConfig(detail)))!==report.stable_sha)throw Error('configuration_changed');
 const desired=mode==='--rollback'?baseline:stage;
 if(mode==='--deploy'){
  if(report.phase!=='prepared')throw Error('phase_differs');
  await idle(manager,db);await download(manager,'pre-upload',BASE);
 }
 report.phase=mode==='--rollback'?'rollback_started':'upload_started';save(report);
 const upload=await manager.functions.updateFunctionCode({func:{name:FN,runtime:'Nodejs20.19',handler:'index.main',installDependency:false},
  functionRootPath:cloud,functionPath:desired,deployMode:'cos'});
 report.request_id=upload.RequestId||null;save(report);
 const expected=mode==='--rollback'?BASE:candidate;
 let verified=null;
 for(let i=0;i<5;i++){
  const fresh=await manager.functions.getFunctionDetail(FN);
  if(fresh.Status==='Active'){
   const folder=fs.mkdtempSync(path.join(__dirname,'live-check-'));
   await manager.functions.downloadFunctionCode({envId:ENV,functionName:FN,destPath:folder});
   const current=digest(folder);
   if(current===expected){verified=folder;break;}
   if(current!==BASE&&current!==candidate)throw Error('unknown_live_code');
  }
  if(i<4)await new Promise(resolve=>setTimeout(resolve,2500));
 }
 if(!verified)throw Error('uploaded_tree_not_verified');
 const final=await manager.functions.getFunctionDetail(FN);
 if(hash(canonical(guards.flagsOf(final)))!==report.environment_sha
   ||hash(JSON.stringify(guards.stableConfig(final)))!==report.stable_sha)throw Error('configuration_changed_after_upload');
 report.phase=mode==='--rollback'?'rolled_back':'active';report.verified_code_copy=verified;report.finished_at=new Date().toISOString();
 save(report);return {phase:report.phase,code_sha:expected,environment_unchanged:true,stable_configuration_unchanged:true};
}
if(require.main===module)main().then(result=>console.log(JSON.stringify(result))).catch(()=>{console.error(JSON.stringify({stopped:true,error:'deployment_verification_failed',no_automatic_retry:true}));process.exitCode=1;});
