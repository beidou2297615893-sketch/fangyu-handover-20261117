# F100 采集与分析队列审计

结论：200条是已有背压线，不是根因。F100把本任务分析线程的生命周期与采集暂停事件绑定，并把一个历史未知分析请求扩大为整个任务的分析暂停。当前显式本地工作台又关闭了旧版独立AIWorker，没有暴露单独分析入口，形成“要先分析才能采集，但暂停后没有分析入口”的闭环。

本审计只读F100源码，未打开正式数据库、未构造正式Core/Backend、未读取凭据、未运行实际平台/云/模型。9项合成Store复现见REPRODUCTION.json、REPRODUCTION.log。第一次fixture遗漏server依赖已修正，失败日志保留为FIXTURE-MISSING-SERVER.log；不是产品缺陷。

## 固定实际路径

- release：`work/parallel-integration-20261018/final-integration/candidate-unified-v100/project/work/ui-native-r57/releases/ui-r57-20261024T082845Z-a2ad4ba4`。
- runtime：release下`resources/platform-runtime/platform_runtime.py`。
- BusinessExecutor、AssistantService、AssistantRunner由runtime._modules从release的`resources/platform-runtime/vendor-src/assistant/`固定加载。
- LocalAIWorkflow、AIWorker、LocalAIAttempts来自同一候选project的`work/ui-runtime-r55/src/assistant/`。相关六份源码SHA256写入REPRODUCTION.json。

## 实际调用链与失败条件

1. 每页采集确认后，`_bounded_collection`在2667调用`_queue_collection_analysis`，把本任务待分析lead_ids写入`workbench_collection_page_analysis_v1`。前一pending队列的ID会合并，不删除已保存评论。
2. `_bounded_collection`的内嵌`analyze_saved`在2584建立analysis_stop；2587循环要求采集event未set。2604先同步`_drain_collection_analysis`；成功后2613左右才启动`task-analysis-<id>`线程。未知结果发生时，该线程会停止，本批可进入analysis_hold采集模式。
3. `_drain_collection_analysis`在2755读取同任务队列；未建队列时只恢复本任务已有原评论。它先本地租住评估，再进入`_analyze_collection_page`。完成后才从队列删除已确认ID，保留新增ID。
4. `_analyze_collection_page.visible`在2864把`task.status == paused`、采集control.event和analysis_stop视为分析停止，直接抛`AI_CONTEXT_REQUIRED / 采集已暂停，不再提交新的分析请求`，尚未进入任何cloud调用。人工点暂停`pause_acquisition`在3064将同一event set，再执行task_stop。因此暂停采集必然阻止该分析线程继续提交后续小批。
5. 自然任务完成不同：`visible`本身不拒绝completed，`_bounded_collection`2700之后finished/wake并join正常worker，已有队列可以排空。本审计复现completed仍可进行只读ai_profile检查，未发现“所有终态都直接停止分析”的统一条件。
6. `_analyze_collection_page`2881以整个`ai_jobs[task_id]`的paused+REVIEW_CODES决定review；review且非reconcile就在2888拒绝。该判断未先检查新lead_ids是否与未知attempt重叠。合成复现显示，即使新评论没有任何对应attempt，也会因同任务旧job的PRODUCT_REQUEST_UNKNOWN被挡在任何status查询之前。
7. reconcile=True时，该方法对第一个同帖20条组传`existing_only=True`，不是重建原请求。LocalAIAttempts要求精确payload映射；不能把新增274条或改组后的新批次拿来“恢复原19条”。

## 谁算200以及为何不能只放开

- `_collection_analysis_backlog`2737按本任务非demo评论中`manual_intent or ai_intent`是否符合`_analysis_confirmed`统计，不使用`ai_jobs.pending`。确认含graded+合法level，以及uncertain/unrelated且level=None；已有但非法的结果、缺正文同样会贡献未确认数。
- `snapshot`795–827以当前可见新增数减已确认数投影pending，843展示200提示。因此旧job.pending=19可以与更大的真实backlog并存。
- 持有analysis_hold时，采集循环2634/2675达到200暂停。`resume_acquisition`3132在hold code且backlog>=200时直接抛ANALYSIS_BACKLOG_LIMIT，发生在_start_task/drain之前。
- `analysis_blocks_new_batch`51及snapshot.canStart另外以pending队列阻止新批次，不能用新任务绕开未确认原分析。

## 可复用且已存在的安全能力

- `assistant/ai_worker.py::AIWorker.step`与采集线程分开，读取可见任务，不要求task运行。逐次调用`BusinessExecutor.analyze_pending`，每tick最多同帖20条；保留PRODUCT_REVIEW_CODES，未知请求不会自动重试。
- 但`AssistantService._run`739仅在`not explicit_local`时启动它；本工作台`PlatformRuntime.__init__`使用`AssistantService(...explicit_local=True)`。因此F100显式本地模式不启动它。
- `BusinessExecutor.analyze_pending(user, {task_id}, explicit_retry=False)`只选本任务无AI/人工结果且有正文的评论，每次同帖最多20条，不要求采集运行。现有`intent_analyze_pending`命令会传explicit_retry=True，可允许“已证明未计费”后的新请求，不应用作未知请求的盲恢复。
- runtime._execute白名单及workbench/host动作集合没有intent_analyze_pending/独立analysis drain的公开入口。
- `LocalAIAttempts.status(user, {request_id: 原UUID})`在ai_attempts.py273只调用cloud的`ai_attempt_status`，校验只读回执，无本地mutation、不执行模型、不释放额度。参数是记录内36字UUID，64位attempt记录ID不是该参数。
- `LocalAIAttempts.call`已有按lead_digests相交保护（80和152附近，含BEGIN IMMEDIATE内再次核对），未重叠的新评论本来能安全独立请求。合成测试证实新请求保留旧unknown记录、使用新键；重叠评论或existing_only重塑批次则拒绝。此处可复用，不需削弱原账本保护。

## 修复建议与边界

应为用户当前已授权任务增加独立分析控制与恢复入口，复用现有LocalAIWorkflow、20条同帖批次、LocalAIAttempts及已有CAS；采集暂停只关闭采集，新分析任务只因本人暂停分析、关闭应用、员工/门店/原任务范围失效而暂停。不要把explicit_local改False、不要全局启动扫描该员工所有历史任务的AIWorker。

未知请求先以原UUID只读查询。对状态未知、无结果或需重新核验的原lead_digests保持隔离，禁止清空attempt、替换原request_id、标已分析或覆盖已有AI/人工结论。对不重叠的新评论可用replace_existing=False、explicit_retry=False继续；任务级状态应分别展示可继续待分析量、原请求待核量、缺正文量。原请求若有可用结果，仍走原请求/原payload的结果校验和CAS回填。

本审计没有制作安装包、改入口、改200上限或操作当前Native。正式数据的计数与只读status恢复由Root负责；本报告不把合成测试当成正式恢复或真实模型验收。
