import {senderName} from './reply-account.mjs';
import {openInteractionInbox} from './interaction-inbox.mjs';
import {openKeywordEffect,canReadKeywordEffect} from './keyword-effect.mjs';
const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const labels={keywords:'关键词搜索',note_links:'指定笔记',profiles:'博主主页',own_interactions:'我的互动',preset:'已存预设'};
const identity=s=>JSON.stringify([globalThis.location?.origin||'',s.session?.user?.tenant_id||'',s.user,s.session?.user?.role||'',s.storeId,s.activePlatform||'xiaohongshu']);
const sourceForms=new Map(),sourcePending=new Map();
const receiptStorage=actor=>'fangyu-source-receipt-v1:'+actor;
const receiptFields={source_preset_save:'sourcePreset',source_schedule_save:'sourceSchedule',source_execution_enable:'sourceExecution'};
const ordered=v=>Array.isArray(v)?v.map(ordered):v&&typeof v==='object'?Object.fromEntries(Object.keys(v).sort().map(k=>[k,ordered(v[k])])):v;
async function requestDigest(data){const hash=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(JSON.stringify(ordered(data))));return [...new Uint8Array(hash)].map(v=>v.toString(16).padStart(2,'0')).join('');}
function restorePending(actor){
  if(sourcePending.has(actor))return sourcePending.get(actor);
  try{const p=JSON.parse(globalThis.localStorage?.getItem(receiptStorage(actor))||'null');
    if(p?.actor===actor&&receiptFields[p.action]===p.resultKey&&/^[A-Za-z0-9_-]{16,80}$/.test(p.requestId||'')&&/^[a-f0-9]{64}$/.test(p.digest||'')){
      const value={...p,data:null,reconstruct:false,lookupState:''};sourcePending.set(actor,value);return value;
    }
  }catch{}return null;
}
function rememberPending(actor,p){
  sourcePending.set(actor,p);
  try{if(p){const value=JSON.stringify({actor,action:p.action,resultKey:p.resultKey,requestId:p.requestId,digest:p.digest});globalThis.localStorage?.setItem(receiptStorage(actor),value);return globalThis.localStorage?.getItem(receiptStorage(actor))===value;}globalThis.localStorage?.removeItem(receiptStorage(actor));return true;}catch{return false;}
}
const accounts=s=>(s.platform?.accounts||[]).filter(a=>a.platform===(s.activePlatform||'xiaohongshu'));
export function sourceSelection(s){const v=s.acquire?.sourceSelection;return v?.actor===identity(s)?v:null;}
export function interactionScanChoice(s){
  const a=s.platform?.acquisition,t=a?.taskScope,platform=s.activePlatform||'xiaohongshu';
  if(!s.session||!s.storeId||s.sourceInteractionPending||a?.canCheckInteractions!==true||t?.source?.kind!=='own_interactions'
    ||s.platform?.actor?.username!==s.user||s.platform.actor.storeId!==s.storeId||t.storeId!==s.storeId||t.platform!==platform
    ||!a.taskId||!Number.isSafeInteger(a.sourceScan)||a.sourceScan<1||a.sourceScan>=1000000||!accounts(s).some(row=>row.id===t.accountId))return null;
  return {actor:identity(s),epoch:s.authEpoch||0,storeId:s.storeId,platform,accountId:t.accountId,taskId:a.taskId,scan:a.sourceScan+1};
}
export function openInteractionCheck(ctx){
  const s=ctx.state;if(s.sourceInteractionPending){return ctx.verifySourceInteractions?.();}
  const choice=interactionScanChoice(s);if(!choice||s.busy)return;
  const account=accounts(s).find(row=>row.id===choice.accountId);
  return ctx.modal({title:'检查新增互动',confirmLabel:'用此账号检查',canClose:()=>!s.busy,
    html:`<p class="as-context">${esc(s.store)} · ${choice.platform==='douyin'?'抖音':'小红书'}</p><p>本次采集账号：<strong>${esc(senderName(account))}</strong></p><p>继续检查这个账号在原任务中的新增互动，已记录的互动不会重复新增客户。</p><p class="as-hint">沿用原任务开始时确定的评论时间范围。若需更新为此刻最近一小时，请新建来源任务；这次检查不会自动更改范围。</p><p class="as-hint">仅检查本人可见互动。赞、收藏和关注不直接算作客户；有明确原文的评论才进入分析。</p>`,
    onConfirm:()=>{
      const current=interactionScanChoice(s);
      if(!current||JSON.stringify(current)!==JSON.stringify(choice)){ctx.toast('原任务状态已变化，请刷新后重新确认。');return false;}
      return ctx.checkSourceInteractions?.(choice);
    }});
}
export function renderSourceBar(s,locked=false){
  if(s.page==='acquire'){const selected=sourceSelection(s),rows=accounts(s),task=s.platform?.acquisition?.taskScope;const id=s.platformAccountSelections?.[s.activePlatform||'xiaohongshu']||selected?.accountId||s.platform?.platforms?.find(p=>p.id===(s.activePlatform||'xiaohongshu'))?.accountId;const next=rows.find(a=>a.id===id),current=rows.find(a=>a.id===task?.accountId);return `<div class="as-source-bar da-keyword-source"><div><strong>关键词搜索</strong><span class="as-account-name">下次采集账号 <b>${esc(senderName(next))}</b></span>${current?`<span class="as-account-name">当前任务账号 <b>${esc(senderName(current))}</b></span>`:''}</div><div><button type="button" data-keyword-account ${locked?'disabled':''}>选择关键词采集账号</button><button type="button" data-diversified-nav>多样化获客 →</button></div></div>`;}
  const v=sourceSelection(s),live=s.platform?.acquisition?.taskScope,kind=v?(v.source?.kind||'keywords'):(live?.source?.kind||'keywords');
  const account=accounts(s).find(a=>a.id===(v?.accountId||s.platformAccountSelections?.[s.activePlatform||'xiaohongshu']||live?.accountId||s.platform?.platforms?.find(p=>p.id===(s.activePlatform||'xiaohongshu'))?.accountId));
  const next=Boolean(v&&live&&(!['running','queued','pausing','resuming','stopping'].includes(s.platform?.acquisition?.status)||v.accountId!==live.accountId));
  const pending=s.sourceInteractionPending,choice=interactionScanChoice(s),original=accounts(s).find(a=>a.id===(pending?.accountId||live?.accountId));
  const check=pending||choice?`<button type="button" data-interaction-check ${s.busy||s.sourceInteractionChecking?'disabled':''}>${pending?(s.sourceInteractionChecking?'正在核对原检查…':'核对原互动检查'):'检查新增互动'}</button>`:'';
  return `<div class="as-source-bar"><div><span>获客来源</span><strong>${esc(labels[kind]||'来源待核对')}</strong>${v?.preview?.sourceCount?`<small>${esc(v.preview.sourceCount)} 个来源</small>`:''}<span class="as-account-name">${next?'下次采集账号':'采集账号'} <b>${esc(senderName(account))}</b></span>${check?`<span class="as-account-name">${pending?'待核对':'新增检查'}账号 <b>${esc(original?senderName(original):pending?.platform==='douyin'?'抖音原任务账号':'小红书原任务账号')}</b></span>`:''}</div><div><button type="button" data-acquisition-sources ${locked||pending?'disabled':''}>选择来源与账号</button><button type="button" data-interaction-inbox data-inbox-account="${esc(account?.id||'')}" ${(s.activePlatform||'xiaohongshu')!=='xiaohongshu'||!s.session||!s.storeId?'disabled':''}>已保存互动</button>${check}<button type="button" data-keyword-effect ${canReadKeywordEffect(s)?'':'disabled'}>查看词效</button></div></div>${pending?'<p class="as-hint" role="status">原检查结果尚未确认，已保留原任务与轮次。核对只读取状态，不会重复发起采集。</p>':''}`;
}
export function bindSourceBar(root,ctx){root.querySelector('[data-keyword-account]')?.addEventListener('click',()=>openAcquisitionSources(ctx,{kinds:['keywords'],initialKind:'keywords',expectedPage:'acquire',selectionContext:{selectedFor:'acquire',selectedAuthEpoch:ctx.state.authEpoch||0}}));root.querySelector('[data-diversified-nav]')?.addEventListener('click',()=>ctx.navigate('diversified'));root.querySelector('[data-keyword-effect]')?.addEventListener('click',()=>openKeywordEffect(ctx));root.querySelector('[data-interaction-inbox]')?.addEventListener('click',e=>openInteractionInbox(ctx,e.currentTarget.dataset.inboxAccount||''));root.querySelector('[data-acquisition-sources]')?.addEventListener('click',()=>openAcquisitionSources(ctx));root.querySelector('[data-interaction-check]')?.addEventListener('click',()=>openInteractionCheck(ctx));}
export function openAcquisitionSources(ctx,options={}){
  const s=ctx.state,actor=identity(s);
  if(!s.session||!s.storeId){ctx.toast('请先选择已授权门店。');return;}
  let u=s.acquisitionSourceUI?.actor===actor?s.acquisitionSourceUI:sourceForms.get(actor);
  if(!u||u.actor!==actor){const selected=sourceSelection(s);u=s.acquisitionSourceUI={actor,kind:selected?.source?.kind||'keywords',accountId:selected?.accountId||s.platformAccountSelections?.[s.activePlatform||'xiaohongshu']||'',links:selected?.source?.links?.join('\n')||'',profiles:selected?.source?.profiles?.join('\n')||'',types:selected?.source?.types||['mentions'],baseline:selected?.source?.baseline||'from_now',presetId:selected?.source?.id||'',presetVersion:selected?.source?.version||0,presetName:selected?.preview?.name||'',window:selected?.commentWindow?.mode==='rolling'?String(selected.commentWindow.minutes):'all',presets:[],schedules:[],executions:[],executionDraft:null,name:'',busy:false,pending:null,preview:null,message:''};}
  const allowed=Array.isArray(options.kinds)?options.kinds.filter(k=>labels[k]&&k!=='preset'):Object.keys(labels).filter(k=>k!=='preset');
  if(options.initialKind&&allowed.includes(options.initialKind)&&u.kind!==options.initialKind){u.kind=options.initialKind;u.preview=null;u.message='';}
  if(!allowed.includes(u.kind)&&u.kind!=='preset'){u.kind=allowed[0]||'keywords';u.preview=null;}
  s.acquisitionSourceUI=u;sourceForms.set(actor,u);u.pending=restorePending(actor)||u.pending;
  const expectedEpoch=s.authEpoch||0;
  const valid=()=>identity(s)===actor&&s.acquisitionSourceUI===u&&Boolean(s.session)&&(s.authEpoch||0)===expectedEpoch&&(!options.expectedPage||s.page===options.expectedPage);
  const source=()=>u.kind==='keywords'?null:u.kind==='preset'?{kind:'preset',id:u.presetId,version:u.presetVersion}:u.kind==='note_links'?{kind:u.kind,links:u.links.split(/\r?\n/).map(v=>v.trim()).filter(Boolean)}:u.kind==='profiles'?{kind:u.kind,profiles:u.profiles.split(/\r?\n/).map(v=>v.trim()).filter(Boolean)}:{kind:u.kind,types:[...u.types],baseline:u.baseline};
  const payload=()=>({storeId:s.storeId,platform:s.activePlatform||'xiaohongshu',accountId:u.accountId,source:source(),commentWindow:u.window==='all'?{mode:'all'}:{mode:'rolling',minutes:Number(u.window)},execution:{mode:'once'}});
  const stamp=()=>JSON.stringify(payload());
  const confirmed=()=>u.preview&&u.previewStamp===stamp();
  const currentAccount=()=>accounts(s).find(a=>a.id===u.accountId);
  const dialog=ctx.modal({title:'新建获客任务',html:'',confirmLabel:'应用来源',canClose:()=>!u.busy,onConfirm:()=>{
    if(!valid()||u.busy||u.pending)return false;
    if(!currentAccount()){u.message='请选择本店的采集账号。';paint();return false;}
    if(u.kind!=='keywords'&&!confirmed()){u.message='请先核对来源，再应用本次设置。';paint();return false;}
    ctx.update(state=>{state.acquire??={};state.acquire.sourceSelection={actor,...(options.selectionContext||{}),accountId:u.accountId,source:source(),commentWindow:payload().commentWindow,execution:{mode:'once'},previewDigest:u.preview?.previewDigest,preview:u.preview?{...u.preview}:null};state.platformAccountSelections??={};state.platformAccountSelections[state.activePlatform||'xiaohongshu']=u.accountId;});
    ctx.toast(u.kind==='keywords'?'已选用当前门店词库。':u.preview.canStart?'来源已应用，请在当前页面明确开始。':'配置已保留；此来源的受控读取尚未接通。');return true;
  }});
  dialog.classList.add('acquisition-source-modal');
  const owner=dialog.__modalOwner,oldClose=dialog.onclose;
  dialog.onclose=e=>{if(dialog.__modalOwner===owner)dialog.classList.remove('acquisition-source-modal');oldClose?.call(dialog,e);};
  function paint(){
    if(!valid())return;
    if(dialog.__modalOwner!==owner){if(u.repaint!==paint)u.repaint?.();return;}
    const disabled=u.busy||Boolean(u.pending&&!u.pending.reconstruct),preview=confirmed()?u.preview:null;
    const active=u.kind;
    dialog.querySelector('.modal-content').innerHTML=`<p class="as-context">${esc(s.store)} · ${s.activePlatform==='douyin'?'抖音':'小红书'}</p><div class="as-types" role="group" aria-label="获客来源">${Object.entries(labels).filter(([k])=>allowed.includes(k)).map(([k,v])=>`<button type="button" data-as-kind="${k}" aria-pressed="${active===k}" ${disabled?'disabled':''}>${esc(v)}</button>`).join('')}</div><div class="as-form"><label for="as-account">采集账号</label><select id="as-account" ${disabled?'disabled':''}><option value="">请选择账号</option>${accounts(s).map(a=>`<option value="${esc(a.id)}" ${a.id===u.accountId?'selected':''}>${esc(senderName(a))}${a.status==='ready'?'':' · 未连接'}</option>`).join('')}</select>${u.kind==='keywords'?'<div class="as-wide as-hint">沿用当前门店搜索词、排除词和最近7／30／90天的帖子范围；本页不会自动开始采集。</div>':u.kind==='own_interactions'?`<label>互动类型</label><div class="as-checks">${[['mentions','评论与@'],['likes','赞与收藏'],['connections','新关注']].map(([k,v])=>`<label><input type="checkbox" data-as-type="${k}" ${u.types.includes(k)?'checked':''} ${disabled?'disabled':''}> ${v}</label>`).join('')}<p class="as-hint">赞、收藏、关注只留作互动记录；有明确原文的评论才进入客户分析。</p></div><label for="as-baseline">首次读取</label><div><select id="as-baseline" ${disabled?'disabled':''}><option value="from_now" ${u.baseline==='from_now'?'selected':''}>从现在开始，只找之后新增</option><option value="visible_history" ${u.baseline==='visible_history'?'selected':''}>包含当前可见的历史互动</option></select><p class="as-hint">从现在开始会先记住现有互动，首轮不会把历史互动算作新增客户。此后可点击检查新增，也可在保存预设后明确开启定期检查。</p></div>`:u.kind==='preset'?`<label>已存来源</label><div>${esc(u.presetName||'获客预设')}<p>评论范围：${esc({'all':'不限','30':'近30分钟','60':'近1小时','1440':'近24小时'}[u.window]||'原预设范围')}</p><p class="as-hint">复用服务器保存的来源与账号范围，开始前仍会核对原版本。</p></div>`:`<label for="as-links">${u.kind==='profiles'?'博主主页':'笔记链接'}</label><div><textarea id="as-links" rows="5" maxlength="210000" placeholder="${u.kind==='profiles'?'每行一个官方主页链接或账号编号':'每行一条完整官方笔记链接'}" ${disabled?'disabled':''}>${esc(u.kind==='profiles'?u.profiles:u.links)}</textarea><p class="as-hint">${u.kind==='profiles'?'从这些博主的可见笔记读取评论，仍使用当前门店的筛选规则。核对来源后会显示此平台是否支持开始。':'已有评论保留原文与来源，不重复新增客户。短链接请先在本人网页展开。'}</p></div>`}${u.kind!=='keywords'&&u.kind!=='preset'?`<label for="as-window">评论范围</label><select id="as-window" ${disabled?'disabled':''}>${[['all','不限'],['30','近30分钟'],['60','近1小时'],['1440','近24小时']].map(([k,v])=>`<option value="${k}" ${u.window===k?'selected':''}>${v}</option>`).join('')}</select><p class="as-wide as-hint">按评论真实发表时间筛选；未知时间单独保留。仅筛选所选来源，不表示全网评论搜索。</p>`:''}</div>${u.kind!=='keywords'?`<div class="as-verify"><button type="button" data-as-preview ${disabled?'disabled':''}>${u.busy?'正在核对…':'核对来源'}</button>${preview?`<span>${esc(preview.message)}${preview.sourceCount?' · '+esc(preview.sourceCount)+'个来源':''}</span>`:''}</div>${preview?.items?.length?`<div class="as-results">${preview.items.slice(0,8).map(item=>`<p class="${item.status==='invalid'?'as-error':''}">${esc(item.line)}. ${esc(item.status==='valid'?'已解析':item.status==='duplicate'?'重复来源已合并':item.message||'待核对')} <small>${esc(item.publicUrl||'')}</small></p>`).join('')}${preview.items.length>8?'<p>其余来源已一并核对。</p>':''}</div>`:''}<div class="as-presets"><label for="as-preset-name">预设名称</label><input id="as-preset-name" maxlength="80" value="${esc(u.name)}" placeholder="如：古北周边出租笔记" ${disabled?'disabled':''}><button type="button" data-as-save ${disabled||!preview?'disabled':''}>保存为预设</button></div>`:''}<details class="as-saved"><summary>已保存预设与检查计划</summary>${u.presets.length?u.presets.map(p=>`<div class="as-saved-row"><span>${esc(p.name)} <small>版本${esc(p.version)}</small></span><button type="button" data-as-load="${esc(p.id)}" ${disabled?'disabled':''}>使用</button><button type="button" data-as-plan="${esc(p.id)}" ${disabled?'disabled':''}>保存每小时提醒</button>${(s.activePlatform||'xiaohongshu')==='xiaohongshu'?`<button type="button" data-as-execute="${esc(p.id)}" ${disabled?'disabled':''}>定期检查</button>`:''}</div>`).join(''):'<p class="as-hint">尚无本店预设。</p>'}<p class="as-hint">旧检查提醒仅保存配置，不会自动启用。需要定期读取时，请重新选择原账号和频率并确认。</p>${u.schedules.map(p=>`<p>${esc(p.name)} · 每${esc(p.interval_minutes)}分钟 · 待本人开始</p>`).join('')}</details>${executionPanel(disabled)}<p class="as-feedback" role="status" aria-live="polite">${esc(u.message)}</p>${u.pending?`<button type="button" data-as-check ${u.busy?'disabled':''}>核对原保存结果</button>${u.pending.data?`<button type="button" data-as-retry ${u.busy?'disabled':''}>按原编号重新提交</button>`:u.pending.lookupState==='not_found'?`<button type="button" data-as-reconstruct ${u.busy?'disabled':''}>按原内容重新填写</button>`:''}`:''}`;
    dialog.querySelector('.modal-confirm').disabled=disabled||Boolean(u.pending)||!currentAccount()||(u.kind!=='keywords'&&!preview);
    const content=dialog.querySelector('.modal-content');
    content.querySelectorAll('[data-as-kind]').forEach(b=>b.onclick=()=>{u.kind=b.dataset.asKind;u.preview=null;u.message='';paint();});
    content.querySelector('#as-account').onchange=e=>{u.accountId=e.target.value;u.preview=null;paint();};
    content.querySelector('#as-links')?.addEventListener('input',e=>{u[u.kind==='profiles'?'profiles':'links']=e.target.value;u.preview=null;dialog.querySelector('.modal-confirm').disabled=true;});
    content.querySelector('#as-window')?.addEventListener('change',e=>{u.window=e.target.value;u.preview=null;paint();});
    content.querySelector('#as-baseline')?.addEventListener('change',e=>{u.baseline=e.target.value;u.preview=null;paint();});
    content.querySelectorAll('[data-as-type]').forEach(b=>b.onchange=()=>{u.types=[...content.querySelectorAll('[data-as-type]:checked')].map(n=>n.dataset.asType);u.preview=null;paint();});
    content.querySelector('#as-preset-name')?.addEventListener('input',e=>u.name=e.target.value);
    content.querySelector('[data-as-preview]')?.addEventListener('click',previewSource);
    content.querySelector('[data-as-save]')?.addEventListener('click',()=>save('source_preset_save',{...payload(),name:u.name.trim(),expectedVersion:0},'sourcePreset'));
    content.querySelector('[data-as-check]')?.addEventListener('click',checkPending);
    content.querySelector('[data-as-retry]')?.addEventListener('click',()=>u.pending?.data&&save(u.pending.action,u.pending.data,u.pending.resultKey,true));
    content.querySelector('[data-as-reconstruct]')?.addEventListener('click',()=>{if(u.pending&&!u.pending.data&&u.pending.lookupState==='not_found'){u.pending.reconstruct=true;u.message='请重新填写原保存内容。内容完全一致才会按原编号提交；不会另建操作。';paint();}});
    content.querySelectorAll('[data-as-load]').forEach(b=>b.onclick=()=>{const p=u.presets.find(p=>p.id===b.dataset.asLoad);if(!p)return;u.kind='preset';u.presetId=p.id;u.presetVersion=p.version;u.presetName=p.name;u.accountId=p.account_id;u.window=p.source?.commentWindow?.mode==='rolling'?String(p.source.commentWindow.minutes):'all';u.preview=null;u.message='已选预设，请核对来源后应用。';paint();});
    content.querySelectorAll('[data-as-execute]').forEach(b=>b.onclick=()=>prepareExecution(u.presets.find(p=>p.id===b.dataset.asExecute)));
    content.querySelectorAll('[data-as-execution-confirm]').forEach(b=>b.onclick=()=>{const row=u.executions.find(r=>r.id===b.dataset.asExecutionConfirm);prepareExecution(u.presets.find(p=>p.id===row?.presetId),row);});
    content.querySelectorAll('[data-as-execution-pause]').forEach(b=>b.onclick=()=>pauseExecution(u.executions.find(r=>r.id===b.dataset.asExecutionPause)));
    content.querySelector('#as-execution-account')?.addEventListener('change',e=>{u.executionDraft.accountId=e.target.value;u.executionDraft.confirmed=false;paint();});
    content.querySelector('#as-execution-interval')?.addEventListener('change',e=>{u.executionDraft.intervalMinutes=e.target.value;u.executionDraft.confirmed=false;paint();});
    content.querySelector('#as-execution-confirm')?.addEventListener('change',e=>{u.executionDraft.confirmed=e.target.checked;paint();});
    content.querySelector('[data-as-execution-cancel]')?.addEventListener('click',()=>{u.executionDraft=null;paint();});
    content.querySelector('[data-as-execution-enable]')?.addEventListener('click',()=>{const d=u.executionDraft,p=u.presets.find(p=>p.id===d?.presetId);if(!d?.confirmed||!p||d.accountId!==p.account_id||!d.intervalMinutes)return;save('source_execution_enable',{storeId:s.storeId,id:d.id||undefined,accountId:d.accountId,presetId:p.id,presetVersion:p.version,intervalMinutes:Number(d.intervalMinutes),confirmed:true,expectedVersion:d.version||0},'sourceExecution');});
    content.querySelectorAll('[data-as-plan]').forEach(b=>b.onclick=()=>{const p=u.presets.find(p=>p.id===b.dataset.asPlan);if(p)save('source_schedule_save',{storeId:s.storeId,name:p.name+'检查提醒',presetId:p.id,presetVersion:p.version,intervalMinutes:60,timezone:'Asia/Shanghai',expectedVersion:0},'sourceSchedule');});
  }
  function prepareExecution(p,row=null){
    if(!p||!valid()||u.busy||u.pending)return;
    const existing=row||u.executions.find(r=>r.presetId===p.id);
    if(existing?.enabled){u.message='此预设已开启定期检查，请先暂停原计划。';paint();return;}
    u.executionDraft={presetId:p.id,id:existing?.id,version:existing?.version||0,accountId:'',intervalMinutes:'',confirmed:false};u.message='请核对当前门店，重新选择原账号和检查频率。';paint();
  }
  function executionPanel(disabled){
    if((s.activePlatform||'xiaohongshu')!=='xiaohongshu')return '';
    const d=u.executionDraft,p=u.presets.find(p=>p.id===d?.presetId),a=accounts(s).find(a=>a.id===p?.account_id);
    return `<section class="as-saved as-execution"><h3>当前会话定期检查</h3><p class="as-hint">仅在当前工作台打开且员工、门店与账号授权有效时，每次读取一页。休眠错过的检查合并一轮；关闭或失效后暂停，重开需本人确认。不会自动登录。</p>${(u.executions||[]).map(r=>`<div class="as-saved-row"><span>${esc(u.presets.find(p=>p.id===r.presetId)?.name||'原获客预设')} · 每${esc(r.intervalMinutes)}分钟<br><small>${esc({waiting:'等待下次检查',running:'本轮正在读取',paused:'已暂停',needs_confirmation:'需要本人确认'}[r.state]||'待核对')} · ${esc(r.message)}</small></span>${r.enabled?`<button type="button" data-as-execution-pause="${esc(r.id)}" ${disabled?'disabled':''}>暂停</button>`:`<button type="button" data-as-execution-confirm="${esc(r.id)}" ${disabled?'disabled':''}>核对后继续</button>`}</div>`).join('')}${d&&p?`<div class="as-form"><p class="as-wide"><strong>${esc(p.name)}</strong> · 当前门店：${esc(s.store)}</p><label for="as-execution-account">原采集账号</label><select id="as-execution-account" ${disabled?'disabled':''}><option value="">请本人选择原账号</option>${a?`<option value="${esc(a.id)}" ${d.accountId===a.id?'selected':''}>${esc(senderName(a))}</option>`:''}</select><label for="as-execution-interval">检查频率</label><select id="as-execution-interval" ${disabled?'disabled':''}><option value="">请选择频率</option>${[['30','每30分钟'],['60','每小时'],['180','每3小时'],['1440','每天'],['10080','每周']].map(([k,v])=>`<option value="${k}" ${d.intervalMinutes===k?'selected':''}>${v}</option>`).join('')}</select><label class="as-wide"><input id="as-execution-confirm" type="checkbox" ${d.confirmed?'checked':''} ${disabled?'disabled':''}> 我已核对本店、原账号与频率，同意仅在当前工作台会话内检查</label><div class="as-wide"><button type="button" data-as-execution-enable ${disabled||!d.confirmed||!d.accountId||!d.intervalMinutes?'disabled':''}>确认开启定期检查</button> <button type="button" data-as-execution-cancel ${disabled?'disabled':''}>取消</button></div></div>`:''}</section>`;
  }
  async function pauseExecution(row){
    if(!valid()||!row||u.busy||u.pending)return;u.busy=true;paint();
    try{const r=await ctx.sourceAction('source_execution_pause',{storeId:s.storeId,id:row.id,expectedVersion:row.version});if(!valid())return;if(r.actor?.username!==s.user||r.actor?.storeId!==s.storeId||r.sourceExecution?.id!==row.id||r.sourceExecution?.state!=='paused')throw Error('暂停结果待核对，请重新打开来源窗口查看原计划。');u.message='定期检查已暂停，原任务与断点保留。';}
    catch(e){if(valid())u.message=e.message;}finally{u.busy=false;if(valid())await reload();}
  }
  async function previewSource(){
    if(!valid()||u.busy||u.pending&&!u.pending.reconstruct||!currentAccount())return;
    const data=payload(),key=stamp();if(new TextEncoder().encode(JSON.stringify({action:'acquisition_source_preview',data})).length>299000){u.message='链接内容较多，请分成较小的任务。';paint();return;}
    u.busy=true;u.message='正在核对本地来源格式与账号归属…';paint();
    try{const r=await ctx.sourceAction('acquisition_source_preview',data);if(!valid()||r.actor?.username!==s.user||r.actor?.storeId!==s.storeId)return;if(key!==stamp())return;u.preview=r.sourcePreview;u.previewStamp=key;u.message=u.preview?.message||'来源核对完成。';}
    catch(e){if(valid())u.message=e.message;}finally{u.busy=false;if(valid())paint();}
  }
  async function reload(){
    const result=await Promise.allSettled([ctx.sourceAction('source_preset_read',{storeId:s.storeId}),ctx.sourceAction('source_schedule_read',{storeId:s.storeId}),ctx.sourceAction('source_execution_read',{storeId:s.storeId})]);
    if(!valid())return;
    result.forEach((r,i)=>{if(r.status==='fulfilled'&&r.value.actor?.username===s.user&&r.value.actor?.storeId===s.storeId)u[['presets','schedules','executions'][i]]=(r.value[['sourcePresets','sourceSchedules','sourceExecutions'][i]]?.items||[]).filter(row=>row.platform===(s.activePlatform||'xiaohongshu'));});paint();
  }
  async function save(action,data,resultKey,retry=false){
    if(!valid()||u.busy||u.pending&&!retry&&!u.pending.reconstruct)return;
    if(action!=='source_execution_enable'&&!data.name){u.message='请填写预设名称。';paint();return;}
    const request={...data};if(action==='source_preset_save')delete request.execution;
    request.requestId||=u.pending?.requestId||crypto.randomUUID();u.busy=true;paint();
    try{
      const digest=await requestDigest(request);if(!valid())return;
      if(u.pending&&(u.pending.action!==action||u.pending.requestId!==request.requestId||u.pending.digest!==digest)){u.message='填写内容与原操作不同，尚未提交。请核对原保存结果，或完整填写原内容。';return;}
      u.pending={action,data:request,resultKey,requestId:request.requestId,digest,reconstruct:false,lookupState:''};
      if(!rememberPending(actor,u.pending))throw Object.assign(Error('无法保存本机核对断点，本次尚未提交；请重开工作台后再试。'),{mutationCommitted:false});
      u.message='正在保存配置…';paint();
      const r=await ctx.sourceAction(action,request);if(!valid())return;const item=r[resultKey];
      if(r.actor?.username!==s.user||r.actor?.storeId!==s.storeId||(action==='source_execution_enable'?(item?.requestId!==request.requestId||item?.found!==true):(item?.receipt?.requestId!==request.requestId||item?.receipt?.found!==true||item?.receipt?.state!=='succeeded')))throw Error('保存回执尚未确认，请核对原操作。');
      u.pending=null;rememberPending(actor,null);u.message=action==='source_execution_enable'?'已开启定期检查，仅在当前工作台会话内运行。':action==='source_schedule_save'?'检查提醒已保存；尚未启动自动采集。':'预设已保存。';if(action==='source_execution_enable')u.executionDraft=null;await reload();
    }catch(e){if(e.mutationCommitted===false){u.pending=null;rememberPending(actor,null);}if(valid())u.message=e.message;}
    finally{u.busy=false;if(valid())paint();}
  }
  async function checkPending(){
    if(!valid()||!u.pending||u.busy)return;const p=u.pending;u.busy=true;paint();
    try{const read=p.action==='source_execution_enable'?'source_execution_read':p.action==='source_schedule_save'?'source_schedule_read':'source_preset_read',key=p.action==='source_execution_enable'?'sourceExecutions':p.action==='source_schedule_save'?'sourceSchedules':'sourcePresets';const r=await ctx.sourceAction(read,{storeId:s.storeId,requestId:p.requestId});if(!valid()||r.actor?.username!==s.user||r.actor?.storeId!==s.storeId)return;const receipt=r[key]?.receipt;if(receipt?.requestId!==p.requestId)throw Error('原保存结果尚未确认。');
      if(receipt.found===true&&(p.action==='source_execution_enable'||receipt.state==='succeeded')){u.pending=null;rememberPending(actor,null);u.message='原保存已确认，没有重复提交。';}
      else if(receipt.found===false&&receipt.state==='not_found'){p.lookupState='not_found';u.message=p.data?'暂未查到原编号；可按原编号重试，不会自动重新保存。':'暂未查到原编号。已保留核对断点；可重新填写完全相同的内容，按原编号提交。';}
      else throw Error('原保存回执格式不完整，继续保留核对断点。');await reload();
    }catch(e){if(valid())u.message=e.message;}finally{u.busy=false;if(valid())paint();}
  }
  u.repaint=paint;paint();if(u.pending)checkPending();else reload().catch(e=>{if(valid()){u.message=e.message;paint();}});
}
