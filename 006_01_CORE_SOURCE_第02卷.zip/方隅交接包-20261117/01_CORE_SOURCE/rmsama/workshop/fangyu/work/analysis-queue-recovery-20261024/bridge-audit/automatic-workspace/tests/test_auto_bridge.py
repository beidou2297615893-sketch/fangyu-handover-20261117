"""Real Backend identity/bootstrap methods with synthetic authority only."""
import ast,copy,hashlib,re,threading,time,types,unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
NATIVE=ROOT/'candidate/work/ui-native-r57'
class Failure(ValueError):
    def __init__(self,code,message,status=400):super().__init__(message);self.code,self.status=code,status
class Integration:
    def __init__(self,f):self.f=f;self.identity_cache={};self.last_verified_profile=None;self.last_verification_error=None
    def verify_identity(self,user,**kw):
        self.f.authority_calls+=1;self.last_verified_profile=copy.deepcopy(self.f.profile);return copy.deepcopy(user)
class Controller:
    def __init__(self,runtime):self.authorizations=[];self.closed=False;self.actions=[]
    def authorize_workspace(self,user,store,refresh,factory):self.authorizations.append((user,store,refresh,factory));return self
    def execute_workspace(self,action,user,store,data,refresh,factory):
        refresh(fresh=action=='analysis_workspace_resume');self.actions.append(action)
        return {'actor':{'username':user['username'],'storeId':store},'taskId':'workspace','status':'waiting','running':False,
            'counts':{'total':274,'pending':244,'processing':0,'held':9,'analyzed':0,'missingText':21},'autoEnabled':True,'autoPaused':False,
            'remaining':244,'canPause':True,'canResume':False,'message':'已开启自动分析','phase':'','code':''}
    def close(self):self.closed=True
def method(name):
    tree=ast.parse((NATIVE/'workbench_backend.py').read_text('utf-8-sig'))
    cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='WorkbenchBackend')
    node=next((n for n in cls.body if isinstance(n,ast.FunctionDef) and n.name==name),None)
    if node is None:raise AssertionError('Missing automatic workspace bridge: '+name)
    scope={'WorkbenchError':Failure,'_CloudServiceUnavailable':RuntimeError,'deepcopy':copy.deepcopy,'re':re,'Path':Path,'STORE_ID':re.compile(r'[A-Za-z0-9_-]{1,80}\Z'),
           'threading':threading,'hashlib':hashlib,'time':time,'_MediaReadIntegrations':lambda core:Integration(core.fixture),
           '_stamp':lambda:'fixture','ANALYSIS_WORKSPACE_ACTIONS':{'analysis_workspace_read','analysis_workspace_pause','analysis_workspace_resume'}}
    exec(compile(ast.Module(body=[node],type_ignores=[]),'<actual-backend-method>','exec'),scope)
    return scope[name]
def fixture():
    f=types.SimpleNamespace(closed=False,lock=threading.RLock(),_analysis_queue=None,_analysis_queue_factory=Controller,
      _analysis_authority_lock=threading.RLock(),_analysis_authorities={},authority_calls=0)
    f.user={'id':'user1','tenant_id':'tenant','username':'tester','role':'operator','cloud_bound':True}
    f.profile={'username':'tester','role':'operator','can_analyze':True,'_workbench_store_id':'store1'}
    f.selected='store1'
    f.core=types.SimpleNamespace(lock=threading.RLock(),session=lambda token:copy.deepcopy(f.user),fixture=f)
    f.platform_runtime=types.SimpleNamespace(core=f.core)
    f.integrations=Integration(f)
    f._read_store_directory=lambda integration,user:([{'id':'store1'},{'id':'store2'}],'',{'fixture':True})
    f._stores=lambda profile:[{'id':'store1'},{'id':'store2'}]
    f._load_selection=lambda user,stores:{'storeId':f.selected,'revision':0,'applied':None}
    f._activate_central_config=lambda *args,**kwargs:None
    f._catalog=lambda *args,**kwargs:{'search':[],'intent':[]}
    f.materials=types.SimpleNamespace(catalog=lambda *args:None,central=None)
    f._remembered=lambda:'';f.customer_workbench=None;f.rental_factory=None
    for name in ('_remember_analysis_authority','_analysis_local_identity','_analysis_controller','_analysis_queue_refresh',
                 '_analysis_workspace_refresh','_sync_analysis_workspace','_analysis_workspace_dispatch','_identity','_bootstrap'):
        setattr(f,name,types.MethodType(method(name),f))
    return f
class AutomaticBridge(unittest.TestCase):
    def test_real_bootstrap_on_reply_page_authorizes_workspace_without_button(self):
        f=fixture();f.page='reply'
        response=f._bootstrap('fixture-token')
        self.assertEqual(response['session']['user']['username'],'tester')
        self.assertTrue(f._analysis_queue.authorizations)
        self.assertEqual(f._analysis_queue.authorizations[-1][1],'store1')
        self.assertEqual(f.authority_calls,1)
    def test_workspace_signal_has_no_synchronous_refresh_or_task_factory_call(self):
        f=fixture();f._identity('fixture-token')
        self.assertEqual(f.authority_calls,1)
        user,store,refresh,factory=f._analysis_queue.authorizations[-1]
        before=f.authority_calls;refresh(fresh=False);factory('task1')
        self.assertEqual(f.authority_calls,before)
    def test_workspace_refresh_remains_bound_to_employee_and_selected_store(self):
        f=fixture();f._identity('fixture-token')
        refresh=f._analysis_queue.authorizations[-1][2]
        f.selected='store2'
        with self.assertRaises(Failure):refresh(fresh=False)
    def test_local_identity_poll_does_not_emit_automatic_authorization(self):
        f=fixture();f._identity('fixture-token');count=len(f._analysis_queue.authorizations)
        for _ in range(10):f._analysis_local_identity('fixture-token')
        self.assertEqual(len(f._analysis_queue.authorizations),count)
        self.assertEqual(f.authority_calls,1)
if __name__=='__main__':unittest.main(verbosity=2)
