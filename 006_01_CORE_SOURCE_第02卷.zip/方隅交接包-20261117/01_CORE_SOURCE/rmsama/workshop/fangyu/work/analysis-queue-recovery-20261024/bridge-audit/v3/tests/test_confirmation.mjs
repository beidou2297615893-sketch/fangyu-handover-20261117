import fs from 'node:fs';
import path from 'node:path';
import {createRequire} from 'node:module';
import {pathToFileURL} from 'node:url';
import assert from 'node:assert/strict';
const root=path.resolve(import.meta.dirname,'..');
const project='C:/积木软件工坊/项目/方隅公寓客户版/work/parallel-integration-20261018/final-integration/candidate-unified-v101/project';
const option=name=>{const index=process.argv.indexOf(name);return index>=0?process.argv[index+1]:null;};
const appFile=option('--app')||process.env.FANGYU_APP||project+'/work/ui-approved-implementation/ui-preview/app.mjs';
const moduleFile=option('--module')||process.env.FANGYU_ANALYSIS_MODULE||root+'/candidate/work/ui-approved-implementation/ui-preview/pages/saved-comment-analysis.mjs';
const ui=path.dirname(appFile);
const require=createRequire(project+'/work/ui-native-r57/public_article_generic/package.json');
const {JSDOM}=require('jsdom');
const fixture=fs.mkdtempSync(path.join(root,'work-fixture-'));fs.mkdirSync(fixture+'/pages');
for(const folder of ['', '/pages'])for(const entry of fs.readdirSync(ui+folder,{withFileTypes:true}))if(entry.isFile()&&entry.name.endsWith('.mjs'))fs.copyFileSync(ui+folder+'/'+entry.name,fixture+folder+'/'+entry.name);
fs.copyFileSync(moduleFile,fixture+'/pages/saved-comment-analysis.mjs');
const acquire=await import(pathToFileURL(fixture+'/pages/acquire.mjs'));
const app=fs.readFileSync(appFile,'utf8');
const modalSource=app.slice(app.indexOf('function modal('),app.indexOf('\nconst viewModel=state;'));
assert.ok(modalSource.includes('__modalOwner'));
const sleep=()=>new Promise(resolve=>setTimeout(resolve,0));
const receipt=()=>({analysisQueue:{actor:{username:'tester',storeId:'store1'},taskId:'task1',status:'paused',running:false,
 counts:{total:209,pending:186,held:9,analyzed:0,missingText:14},canResume:true,canPause:false,message:'已保存评论',requestId:'',code:''}});
function setup(){
 const dom=new JSDOM('<div id="page-content"></div><dialog id="modal"></dialog>',{url:'http://127.0.0.1:12345'});
 globalThis.document=dom.window.document;
 const dialog=document.getElementById('modal');
 dialog.showModal=()=>{dialog.setAttribute('open','');};
 dialog.close=()=>{dialog.removeAttribute('open');dialog.dispatchEvent(new dom.window.Event('close'));};
 const modal=new Function('document','esc','icon',`let lastFocus;${modalSource};return modal;`)(document,x=>String(x),()=>'<i></i>');
 const state={connection:'connected',page:'acquire',authEpoch:1,user:'tester',storeId:'store1',store:'门店一',activePlatform:'xiaohongshu',
   stores:[{id:'store1',name:'门店一'}],session:{user:{tenant_id:'tenant',role:'operator'}},platform:{platforms:[{id:'xiaohongshu',enabled:true,accountId:'account1'}],
   acquisition:{taskId:'task1',status:'paused',taskScope:{storeId:'store1',platform:'xiaohongshu',accountId:'account1'},analysis:{status:'paused',hold:true,code:'PRODUCT_REQUEST_UNKNOWN'}}}};
 let calls=[],notices=[],cleanup;
 const ctx={state,actions:{},modal,toast:x=>notices.push(x),analysisQueueAction:async(action,data)=>{calls.push({action,data});return receipt();},update:fn=>fn(state),navigate:()=>{}};
 function mount(){cleanup?.();document.getElementById('page-content').innerHTML=acquire.render(state);cleanup=acquire.bind(document.getElementById('page-content'),ctx);}
 mount();
 function clickResume(){document.querySelector('[data-analysis-resume]').click();assert.equal(dialog.open,true);}
 return {state,ctx,dialog,calls,notices,mount,clickResume,finish:()=>{cleanup?.();dom.window.close();}};
}
const cases=[];
async function test(name,run){try{await run();cases.push({name,pass:true});}catch(error){cases.push({name,pass:false,error:error.stack});}}
await test('same actor/store/task rerender does not discard explicit confirmation',async()=>{
 const f=setup();try{await sleep();f.clickResume();f.mount();await sleep();await f.dialog.querySelector('.modal-confirm').onclick();
 assert.equal(f.calls.filter(x=>x.action==='analysis_queue_resume').length,1);assert.equal(f.calls.at(-1).data.confirmed,true);}finally{f.finish();}
});
await test('confirmation during poll waits then submits exactly once across rerender and double click',async()=>{
 const f=setup();try{
  await sleep();f.clickResume();let release;
  f.ctx.analysisQueueAction=async(action,data)=>{f.calls.push({action,data});if(action==='analysis_queue_read')return new Promise(r=>release=()=>r(receipt()));return receipt();};
  document.querySelector('[data-analysis-read]').click();f.mount();
  const click=f.dialog.querySelector('.modal-confirm').onclick;
  const a=click(),b=click();assert.equal(f.calls.filter(x=>x.action==='analysis_queue_resume').length,0);
  release();await Promise.all([a,b]);
  assert.equal(f.calls.filter(x=>x.action==='analysis_queue_resume').length,1);
 }finally{f.finish();}
});
await test('changed store rejects old confirmation',async()=>{
 const f=setup();try{await sleep();f.clickResume();const click=f.dialog.querySelector('.modal-confirm').onclick;f.state.storeId='store2';f.mount();await click();assert.equal(f.calls.filter(x=>x.action==='analysis_queue_resume').length,0);}finally{f.finish();}
});
await test('replaced modal rejects saved old confirmation callback',async()=>{
 const f=setup();try{await sleep();f.clickResume();const click=f.dialog.querySelector('.modal-confirm').onclick;
 f.ctx.modal({title:'另一弹窗',html:'<p>其他操作</p>',onConfirm:()=>false});await click();assert.equal(f.calls.filter(x=>x.action==='analysis_queue_resume').length,0);}finally{f.finish();}
});
await test('modal changed while waiting for poll never submits',async()=>{
 const f=setup();try{await sleep();f.clickResume();let release;
 f.ctx.analysisQueueAction=async(action,data)=>{f.calls.push({action,data});if(action==='analysis_queue_read')return new Promise(r=>release=()=>r(receipt()));return receipt();};
 document.querySelector('[data-analysis-read]').click();const pending=f.dialog.querySelector('.modal-confirm').onclick();
 f.ctx.modal({title:'另一弹窗',html:'<p>其他操作</p>',onConfirm:()=>false});release();await pending;
 assert.equal(f.calls.filter(x=>x.action==='analysis_queue_resume').length,0);}finally{f.finish();}
});
await test('API failure is visible inside the confirmation modal and cannot double submit',async()=>{
 const f=setup();try{await sleep();f.clickResume();let reject;
 f.ctx.analysisQueueAction=(action,data)=>{f.calls.push({action,data});return new Promise((_,r)=>reject=r);};
 const click=f.dialog.querySelector('.modal-confirm').onclick;
 const pending=click();assert.match(f.dialog.querySelector('.modal-confirm').textContent,/正在提交/);
 reject(Object.assign(Error('企业分析服务暂不可用，请稍后核对'),{code:'ANALYSIS_UNAVAILABLE'}));await pending;
 assert.equal(f.dialog.open,true);assert.match(f.dialog.querySelector('[role="alert"]').textContent,/企业分析服务暂不可用/);
 await click();assert.equal(f.calls.filter(x=>x.action==='analysis_queue_resume').length,1);
 }finally{f.finish();}
});
await test('in-flight resume survives same-scope repaint and updates current panel',async()=>{
 const f=setup();try{await sleep();f.clickResume();let release;
 f.ctx.analysisQueueAction=(action,data)=>{f.calls.push({action,data});return new Promise(r=>release=r);};
 const pending=f.dialog.querySelector('.modal-confirm').onclick();f.mount();
 const result=receipt();result.analysisQueue.status='running';result.analysisQueue.running=true;result.analysisQueue.canPause=true;result.analysisQueue.canResume=false;
 release(result);await pending;
 assert.equal(f.calls.filter(x=>x.action==='analysis_queue_resume').length,1);
 assert.equal(f.state.savedCommentAnalysis.value.running,true);assert.ok(document.querySelector('[data-analysis-pause]'));assert.equal(f.dialog.open,false);
 }finally{f.finish();}
});
await test('failed in-flight poll shows its error inside modal without submitting analysis',async()=>{
 const f=setup();try{await sleep();f.clickResume();let reject;
 f.ctx.analysisQueueAction=(action,data)=>{f.calls.push({action,data});return new Promise((_,r)=>reject=r);};
 document.querySelector('[data-analysis-read]').click();const pending=f.dialog.querySelector('.modal-confirm').onclick();
 reject(Error('原分析状态未核实，请刷新后再试'));await pending;
 assert.equal(f.dialog.open,true);assert.match(f.dialog.querySelector('[role="alert"]').textContent,/原分析状态未核实/);
 assert.equal(f.calls.filter(x=>x.action==='analysis_queue_resume').length,0);
 }finally{f.finish();}
});
console.log(JSON.stringify({passed:cases.every(x=>x.pass),moduleFile,appFile,cases},null,2));
process.exitCode=cases.every(x=>x.pass)?0:1;
