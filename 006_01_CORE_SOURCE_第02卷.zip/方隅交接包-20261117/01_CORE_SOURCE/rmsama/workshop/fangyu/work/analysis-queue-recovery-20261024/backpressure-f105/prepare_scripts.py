"""Prepare next version scripts; no install or product-source mutation."""
from pathlib import Path
D=Path(__file__).resolve().parent;W=D.parent
body=(W/'compose_f104.py').read_text('utf-8')
body=body.replace('candidate-unified-v104','__NEXT_CANDIDATE__').replace('candidate-unified-v103','candidate-unified-v104').replace('__NEXT_CANDIDATE__','candidate-unified-v105')
body=body.replace('V104','V105').replace('f104','f105').replace('F103','F104')
body=body.replace("W/'core-audit'","W/'backpressure-f105/core'").replace("W/'bridge-audit'","W/'backpressure-f105/bridge'")
body=body.replace("allowed={'work/shared-backend-integration/analysis_queue_runtime.py',","allowed={'work/shared-backend-integration/platform_runtime.py',")
old="assert {'work/shared-backend-integration/analysis_queue_runtime.py','work/ui-native-r57/workbench_backend.py',\n    'work/ui-native-r57/ui_native_host.py','work/ui-approved-implementation/ui-preview/backend.mjs',\n    'work/ui-approved-implementation/ui-preview/pages/saved-comment-analysis.mjs'}<=relatives"
new="assert {'work/shared-backend-integration/platform_runtime.py','work/ui-approved-implementation/ui-preview/pages/acquire.mjs','work/ui-approved-implementation/ui-preview/pages/saved-comment-analysis.mjs'}==relatives"
assert old in body;body=body.replace(old,new)
for name,text in [('compose_f105.py',body)]:
 compile(text,name,'exec')
 with (W/name).open('x',encoding='utf-8') as f:f.write(text)
body=(W/'install_verified_f104.py').read_text('utf-8')
for old,new in {
 'candidate-unified-v104':'candidate-unified-v105','V104':'V105','entry-v104':'entry-v105',
 'PASS_F104_AUTOMATIC_WORKSPACE_ANALYSIS':'PASS_F105_DURABLE_ANALYSIS_COLLECTION_DECOUPLED',
 '9660abf97c29f4b8816f79822386768cdc27a0ad9cc3aef8ee9a4fa99bf428a3':'8aa9d33a3a6feb1497cb0a670331ef1449f0652206e1bc7cfb3aa9cfd3869b5b',
 '075647e7911e7fa6cf160180b2d75e32c9e27d731c749250332937b1315df92c':'9d4d2580c22e7c6160df0457473e719ef3fdd9f3ad81bd8824136afd0789363b',
 'ui-r57-20261024T144455Z-0597e0ca':'ui-r57-20261024T153411Z-4c9dd686',
}.items():
 assert old in body,old
 body=body.replace(old,new)
compile(body,'install_verified_f105.py','exec')
with (W/'install_verified_f105.py').open('x',encoding='utf-8') as f:f.write(body)
for name in ('formal_preservation','check_installed'):
 body=(W/(name+'_f104.py')).read_text('utf-8')
 body=body.replace('V104','V105').replace('F104','F105').replace('entry-v104','entry-v105').replace('formal_preservation_f104','formal_preservation_f105')
 compile(body,name+'_f105.py','exec')
 with (W/(name+'_f105.py')).open('x',encoding='utf-8') as f:f.write(body)
print('F105_COMPOSITION_AND_CAS_SCRIPTS_PREPARED_NOT_EXECUTED')
