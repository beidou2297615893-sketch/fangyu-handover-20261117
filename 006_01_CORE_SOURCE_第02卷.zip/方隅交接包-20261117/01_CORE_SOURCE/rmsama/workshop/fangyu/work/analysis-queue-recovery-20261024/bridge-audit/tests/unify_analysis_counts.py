from pathlib import Path
p=Path(__file__).resolve().parents[1]/'candidate/work/ui-approved-implementation/ui-preview/pages/acquire.mjs'
s=p.read_text(encoding='utf-8')
changes=[
('AI分析待核 · ${count(live.analysis.pending)} 条待分析；','原分析请求待核对；'),
('<span>待分析 ${count(live.analysis?.pending)} 条</span>', '<span>待分析 ${count(savedCommentAnalysisView(state,live.taskId)?.counts.pending)} 条 · 原请求待核 ${count(savedCommentAnalysisView(state,live.taskId)?.counts.held)} 条</span>'),
('const analysis=live.analysis||{},pending=count(analysis.pending);', 'const analysis=live.analysis||{},queue=savedCommentAnalysisView(state,live.taskId),pending=count(queue?.counts.pending);'),
('<dt>本批待分析</dt><dd>${pending} · ${escape(analysisStatus)}${analysisReason?', '<dt>当前任务待分析 / 原请求待核</dt><dd>${pending} / ${count(queue?.counts.held)} · ${queue?escape(queue.running?\'正在分析已保存评论\':queue.message):\'请刷新上方分析状态\'}${analysisReason?')]
for old,new in changes:
    assert s.count(old)==1,(old,s.count(old))
    s=s.replace(old,new)
p.write_text(s,encoding='utf-8',newline='\n')
