"""One synthetic saved CLI page; no platform process, cloud or Native window."""
from pathlib import Path
import hashlib,io,json,os,socket,subprocess,sys,threading,time,unittest
from types import SimpleNamespace
from unittest.mock import patch
from test_analysis_queue import QueueTests,load,HERE,R,EVIDENCE,deny
BASELINE='--baseline' in sys.argv
runtime_path=R/'resources/platform-runtime/platform_runtime.py' if BASELINE else Path(os.environ.get('ANALYSIS_QUEUE_RUNTIME',str(HERE/'platform_runtime.py')))
runtime=load('audit_runtime_queue_integration',runtime_path)

class Integration(QueueTests):
    def setUp(self):
        super().setUp()
        self.rt=object.__new__(runtime.PlatformRuntime)
        self.rt.core=self.core;self.rt.closed=False;self.rt.server=self.server;self.rt.service=self.runtime.service
        self.rt._run_lock=threading.RLock();self.rt._runs={};self.rt._run_cancels={};self.rt._verification_waits={}
        self.rt._principal=lambda user:user
        self.rt._task=lambda user,ident:self.core._get('tasks',ident,user['tenant_id'])
        self.rt._account=lambda user,ident:self.core._get('accounts',ident,user['tenant_id'])
        self.rt._collection_binding=self.runtime._collection_binding
        self.rt._current_comment_policy=lambda task:True
        self.rt._executor=lambda *a,**kw:self.executor
        self.rt._collection_read_purpose=lambda platform:'fixture-read-purpose'
        self.rt._collection_readiness=lambda user,account:('','')
        self.rt._collection_diagnostic=lambda *a,**kw:None
        self.rt.snapshot=lambda user:{'acquisition':{'taskId':'fixture-task'}}
        self.rt._task_leads=lambda user,ident:self.core.store.list_task_leads(user['tenant_id'],ident)
        self.rt._collection_lead_snapshot=lambda user,ident,executor:{row['id']:row['text'] for row in self.core.store.list_task_leads(user['tenant_id'],ident)}
        self.rt._collection_checkpoint=lambda task:json.dumps(task.get('fixture_page',0))
        self.rt._begin_cli_pages=lambda *a:SimpleNamespace(end_xhs_cli_pages=lambda ident:None)

    def test_saved_page_and_collection_cancel_do_not_cancel_authorized_analysis(self):
        ready={**self.task,'status':'ready'};self.core.store.put('tasks',ready)
        self.manager.authorize_collection(self.user,'fixture-store','fixture-task',self.refresh)
        self.rt._analysis_queue_controller=self.manager
        control={'event':threading.Event(),'attempt':'fixture-attempt','binding':self.rt._collection_binding(ready)}
        def legacy(*a,**kw):self.fail('Legacy page analysis consumer must be replaced for an owned task')
        self.rt._drain_collection_analysis=legacy
        def page(executor,user,action,data):
            self.assertEqual(action,'task_run')
            self.leads(21)
            self.core.store.put('tasks',{**ready,'status':'paused','fixture_page':1})
            control['event'].set()
            return {'status':'stopped','summary':{'read':21,'filtered':0,'imported':21,'duplicates':0,'can_continue':False,'exhausted':False}}
        self.rt._execute=page
        self.rt._bounded_collection(self.executor,self.user,'fixture-task',control)
        final=self.wait()
        self.assertTrue(control['event'].is_set())
        self.assertEqual(final['counts']['analyzed'],21)
        self.assertEqual(self.core.store.get(runtime._COLLECTION_ANALYSIS_ENTITY,'fixture-task')['status'],'completed')
        # Another explicit continuation/new saved page wakes the same authorization.
        self.leads(1,start=21)
        self.rt._queue_collection_analysis(self.user,'fixture-task',['lead-21'])
        self.assertEqual(self.wait()['counts']['analyzed'],22)

    def test_start_hook_runs_locally_before_collection_thread_and_never_from_read(self):
        ready={**self.task,'status':'ready'};self.core.store.put('tasks',ready)
        self.executor._explicit_task_ids=set();order=[]
        self.rt._analysis_collection_authorization=threading.local()
        def authorize(user,ident):
            order.append('authorized')
            return self.manager.authorize_collection(user,'fixture-store',ident,self.refresh)
        self.rt._analysis_collection_authorization.callback=authorize
        self.rt._bounded_collection=lambda *a,**kw:order.append('collection-thread')
        before=self.refresh_calls
        result=self.rt._start_task(self.executor,self.user,'fixture-task')
        self.rt._runs['fixture-task'].join(3)
        self.assertEqual(order,['authorized','collection-thread'])
        self.assertEqual(self.refresh_calls,before)
        self.assertEqual(self.calls,[])
        self.assertTrue(result['result']['accepted'])

    def test_no_authorized_controller_preserves_legacy_pending_error(self):
        self.core.store.put(runtime._COLLECTION_ANALYSIS_ENTITY,{'id':'fixture-task','tenant_id':'fixture-tenant','owner':'fixture-owner',
            'binding':self.rt._collection_binding(self.task),'lead_ids':['old-lead'],'status':'pending','code':'PRODUCT_REQUEST_UNKNOWN'})
        with self.assertRaises(runtime.PlatformRuntimeError) as error:
            self.rt._queue_collection_analysis(self.user,'fixture-task',['new-lead'])
        self.assertEqual(error.exception.code,'PRODUCT_REQUEST_UNKNOWN')

    def test_authorized_new_page_keeps_unknown_journal_and_does_not_dispatch_held_ids(self):
        self.leads(20);old=self.unknown(['lead-0'])
        self.core.store.put(runtime._COLLECTION_ANALYSIS_ENTITY,{'id':'fixture-task','tenant_id':'fixture-tenant','owner':'fixture-owner',
            'binding':self.rt._collection_binding(self.task),'lead_ids':['lead-0'],'status':'pending','code':'PRODUCT_REQUEST_UNKNOWN'})
        self.manager.authorize_collection(self.user,'fixture-store','fixture-task',self.refresh)
        self.rt._analysis_queue_controller=self.manager
        self.rt._queue_collection_analysis(self.user,'fixture-task',['lead-'+str(i) for i in range(20)])
        final=self.wait()
        self.assertEqual(final['counts']['held'],1);self.assertEqual(final['counts']['analyzed'],19)
        queued=self.core.store.get(runtime._COLLECTION_ANALYSIS_ENTITY,'fixture-task')
        self.assertEqual(queued['lead_ids'],['lead-0']);self.assertEqual(queued['code'],'PRODUCT_REQUEST_UNKNOWN')
        self.assertEqual(self.core.store.get('ai_attempts',old['id']),old)

    def test_200_backpressure_stops_collection_but_keeps_independent_analysis(self):
        ready={**self.task,'status':'ready'};self.core.store.put('tasks',ready)
        self.leads(200);entered=threading.Event();release=threading.Event()
        self.model_gate=lambda:(entered.set(),release.wait(3))
        self.manager.authorize_collection(self.user,'fixture-store','fixture-task',self.refresh)
        self.rt._analysis_queue_controller=self.manager
        self.rt._execute=lambda *a,**kw:self.fail('Backlog200 must not read another platform page')
        control={'event':threading.Event(),'attempt':'fixture-limit','binding':self.rt._collection_binding(ready)}
        self.rt._bounded_collection(self.executor,self.user,'fixture-task',control)
        self.assertTrue(entered.wait(3))
        receipt=self.core.store.get(runtime._COLLECTION_RUN_ENTITY,'fixture-task')
        self.assertEqual(receipt['stop_reason'],'analysis_backlog')
        self.assertFalse(control['event'].is_set())
        release.set();final=self.wait()
        self.assertEqual(final['counts']['analyzed'],200)

if __name__=='__main__':
    names=[n for n in Integration.__dict__ if n.startswith('test_')]
    stream=io.StringIO()
    with patch.object(socket.socket,'connect',deny),patch('subprocess.Popen',side_effect=deny):
        result=unittest.TextTestRunner(stream=stream,verbosity=2).run(unittest.TestSuite(Integration(n) for n in names))
    log=stream.getvalue();(EVIDENCE/('RUNTIME-RED.log' if BASELINE else 'RUNTIME-GREEN.log')).write_text(log,'utf-8')
    report={'status':'PASS' if result.wasSuccessful() else 'FAIL','tests':result.testsRun,'errors':len(result.errors),'failures':len(result.failures),
        'runtime':str(runtime_path),'runtimeSha256':hashlib.sha256(runtime_path.read_bytes()).hexdigest(),
        'realNetworkOrProviderOrCliCalls':0,'productionDataAccess':0,'syntheticPageSaved':True}
    (EVIDENCE/('RUNTIME-BASELINE-CHECKS.json' if BASELINE else 'RUNTIME-CHECKS.json')).write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n','utf-8');print(log)
    raise SystemExit(0 if result.wasSuccessful() else 1)
