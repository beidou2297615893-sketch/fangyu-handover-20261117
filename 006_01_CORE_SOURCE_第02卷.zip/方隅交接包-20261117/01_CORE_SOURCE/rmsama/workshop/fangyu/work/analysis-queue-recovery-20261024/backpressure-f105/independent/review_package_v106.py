"""Independent read-only F106 closed-package/CAS review; never installs."""
from pathlib import Path,PurePosixPath
from datetime import datetime,timezone
import ast,hashlib,json,sys
sys.dont_write_bytecode=True
A=Path(__file__).resolve().parent;D=A.parent;W=D.parent;P=W.parents[1];PACK=W/'package'
F=P/'work/parallel-integration-20261018/final-integration/candidate-unified-v106'
OLD=F.parent/'candidate-unified-v104';N=P/'work/ui-native-r57'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text('utf-8-sig'))
pins=read(PACK/'ROOT-FINAL-PINS-V106.json');stage=read(F/'STAGED.json');R=Path(stage['release'])
checks=[]
def check(name,value,detail=None):
    checks.append({'name':name,'pass':bool(value),**({'detail':detail} if detail is not None else {})})
    assert value,name
def file_at(base,rel):
    q=PurePosixPath(rel);assert not q.is_absolute() and '..' not in q.parts and '\\' not in rel
    p=(base/rel).resolve();assert p.is_relative_to(base.resolve());return p
def methods(path):
    t=ast.parse(path.read_text('utf-8-sig'));c=next(v for v in t.body if isinstance(v,ast.ClassDef) and v.name=='PlatformRuntime')
    return {v.name:ast.dump(v,include_attributes=False) for v in c.body if isinstance(v,ast.FunctionDef)}
installer=W/'install_verified_f106.py';gates_path=PACK/'ROOT-GATES-V106.json'
initial={str(p):sha(p) for p in (PACK/'ROOT-FINAL-PINS-V106.json',F/'STAGED.json',F/'UNIFIED-PINS.json',R/'RELEASE.json',installer,gates_path)}
check('root-staged-manifest-unified-pins-exact',pins['releaseId']==stage['release_id']==R.name and
      sha(F/'STAGED.json')==pins['stagedSha256'] and sha(F/'UNIFIED-PINS.json')==pins['unifiedPinsSha256'] and
      sha(R/'RELEASE.json')==pins['manifestSha256']==stage['manifest_sha256'].lower())
closure=read(F/'UNIFIED-PINS.json');paths=[]
for row in closure['files']:
    p=file_at(F/'project',row['path']);paths.append(row['path'])
    assert p.is_file() and p.stat().st_size==row['bytes'] and sha(p)==row['sha256'].lower(),row['path']
check('full-closure-byte-size-and-path-verified',len(paths)==len(set(paths)),len(paths))
manifest=read(R/'RELEASE.json');release_map={}
for row in manifest['files']:
    p=file_at(R,row['path']);assert p.is_file() and p.stat().st_size==row['size'] and sha(p)==row['sha256'].lower(),row['path']
    assert row['path'] not in release_map;release_map[row['path']]=row['sha256'].lower()
check('complete-release-manifest-no-unlisted-files',set(release_map)=={p.relative_to(R).as_posix() for p in R.rglob('*') if p.is_file() and p!=R/'RELEASE.json'},len(release_map))
comp=read(PACK/'ROOT-COMPOSITION-V106.json')
expected={'resources/platform-runtime/platform_runtime.py','web/pages/acquire.mjs','web/pages/saved-comment-analysis.mjs'}
check('only-three-reviewed-product-sources',len(comp['changes'])==3 and {r['releaseRelativePath'] for r in comp['changes']}==expected)
for row in comp['changes']:assert sha(Path(row['candidate']))==sha(F/'project'/row['relativePath'])==sha(R/row['releaseRelativePath'])==row['sha256']
O=Path(read(OLD/'STAGED.json')['release']);old_manifest=read(O/'RELEASE.json');old_map={r['path']:r['sha256'].lower() for r in old_manifest['files']}
check('frozen-release-delta-exactly-three-sources',set(k for k in old_map.keys()|release_map.keys() if old_map.get(k)!=release_map.get(k))==expected)
old_closure={r['path']:r['sha256'] for r in read(OLD/'UNIFIED-PINS.json')['files']};new_closure={r['path']:r['sha256'] for r in closure['files']}
check('shared-project-delta-exactly-three-sources',{k for k in old_closure.keys()&new_closure.keys() if old_closure[k]!=new_closure[k]}=={r['relativePath'] for r in comp['changes']})
protected_release=['resources/platform-runtime/analysis_queue_runtime.py','resources/platform-runtime/vendor-src/assistant/business.py',
    'resources/platform-runtime/vendor-src/assistant/service.py','resources/platform-runtime/vendor-src/app.py',
    'workbench_backend.py','ui_native_host.py','customer_read_store.py','web/pages/reply-connected.mjs']
check('F104-real-verified-analysis-reply-and-host-bytes-preserved',all(sha(O/r)==sha(R/r) for r in protected_release))
for rel in ('work/ui-runtime-r55/src/assistant/ai_attempts.py','work/ui-runtime-r55/src/assistant/ai_workflow.py'):
    assert sha(OLD/'project'/rel)==sha(F/'project'/rel)
old_methods,new_methods=methods(O/'resources/platform-runtime/platform_runtime.py'),methods(R/'resources/platform-runtime/platform_runtime.py')
protected=['__init__','_principal','_task','_account','_executor','_collection_readiness','_collection_binding',
    '_pending_collection_analysis','_execute','_current_comment_policy','_verified_task_pages','_verified_scope',
    '_drain_collection_analysis','_analyze_collection_page']
check('fourteen-original-scope-platform-policy-methods-AST-preserved',all(old_methods.get(k)==new_methods.get(k) for k in protected))
check('actual-service-default-mode-still-supported',
      'manual_owned_read_start=False' in (R/'resources/platform-runtime/vendor-src/app.py').read_text('utf-8-sig') and
      'explicit_local=True' in (R/'resources/platform-runtime/platform_runtime.py').read_text('utf-8-sig'))

core_validation=read(Path(comp['coreValidation']));ui_validation=read(Path(comp['bridgeValidation']))
for folder,v in ((D/'core/v2',core_validation),(D/'bridge',ui_validation)):
    seal=read(folder/'SEALED.json');assert seal['sealed'] and seal['passed'] and seal['authorStopped']
    path=folder/'evidence/VALIDATION.json';assert sha(path)==seal['validationSha256']
    for row in v['files']:assert sha(Path(row['candidate']))==row['sha256']
check('core-v2-and-UI-seals-match-frozen-candidates',core_validation['passed'] and ui_validation['passed'])
accept=read(A/'CANDIDATE-V2-ACCEPTANCE.json');lock=read(A/'LOCK-ORDER-V2-REVIEW.json')
runtime_pin=sha(R/'resources/platform-runtime/platform_runtime.py')
check('independent-six-critical-chains-pass-final-frozen-bytes',accept['passed'] and accept['cases']==6 and accept['sourceStable'] and accept['runtimeSha256']==runtime_pin)
check('new-lock-order-reverse-edge-removed',lock['status']=='PASS_NEW_RUNTIME_PATH_NO_REVERSE_EDGE' and lock['runtimeSha256']==runtime_pin
      and ['Core.lock','Controller.lock'] not in lock['observedEdges'])
helper=next(n for n in ast.walk(ast.parse((R/'resources/platform-runtime/platform_runtime.py').read_text('utf-8-sig'))) if isinstance(n,ast.FunctionDef) and n.name=='_automatic_collection_analysis')
check('automatic-helper-never-calls-controller-mutex-methods',not any(isinstance(n,ast.Attribute) and n.attr in ('lock','owns_collection') and isinstance(n.value,ast.Name) and n.value.id=='controller' for n in ast.walk(helper)))
old_ui=(O/'web/pages/acquire.mjs').read_text('utf-8-sig');new_ui=(R/'web/pages/acquire.mjs').read_text('utf-8-sig');mark='function bindConnected(root,ctx)'
check('actual-acquisition-click-handlers-byte-preserved',old_ui[old_ui.index(mark):]==new_ui[new_ui.index(mark):])

gates=read(gates_path)
check('root-frozen-targeted-gates-pass',gates['status']=='PASS_F106_DURABLE_ANALYSIS_COLLECTION_DECOUPLED' and gates['releaseId']==pins['releaseId'] and
      gates['unifiedPinsSha256']==pins['unifiedPinsSha256'] and gates['manifestSha256']==pins['manifestSha256'])
for row in gates['evidence']:assert sha(Path(row['path']))==row['sha256']
check('all-gate-artifacts-pinned',True,len(gates['evidence']))
result=read(W/'verification-f106/ROOT-RESULT.json')
check('exact-frozen-core-UI-native-check-selftest-executions-pass',result['status']=='PASS' and result['releaseId']==pins['releaseId'] and
      len(result['checks'])==4 and all(r['exitCode']==0 for r in result['checks']))
for row in result['checks']:assert sha(Path(row['path']))==row['sha256']
body=installer.read_text('utf-8');compile(body,str(installer),'exec')
gen=P/'work/parallel-integration-20261018/integration/entry/install_canonical_delegation.py'
check('fixed-CAS-transaction-original-digest',sha(gen)=='9909f60d16ad3eaed54b9f97ea0d275ad38510c679ba651ce05af44d920ed0f6')
binding='14cf53964f5d44d123e989805ea741669ab3f05054e730ddcb299a0aac51a9cb'
check('CAS-starts-from-actual-canonical-F104-not-inactive-F105',
      sha(N/'run_workbench.py')=='8aa9d33a3a6feb1497cb0a670331ef1449f0652206e1bc7cfb3aa9cfd3869b5b' and
      sha(N/'FROZEN.json')=='9d4d2580c22e7c6160df0457473e719ef3fdd9f3ad81bd8824136afd0789363b' and
      read(N/'FROZEN.json')['release_id']=='ui-r57-20261024T153411Z-4c9dd686' and
      sha(N/'state/production-workspace.json')==sha(F/'project/work/ui-native-r57/state/production-workspace.json')==binding)
check('wrapper-pins-self-review-gates-full-closure-before-write',all(s in body for s in (
    "review['blockingFindings']==[]","review['approvedForRootInstall'] is True","review['installerSha256']==sha(Path(__file__).resolve())",
    "review['rootPinsSha256']==sha(PACK/'ROOT-FINAL-PINS-V106.json')","review['rootGatesSha256']==sha(PACK/'ROOT-GATES-V106.json')",
    "for row in closure['files']:assert sha(F/'project'/row['path'])==row['sha256']","for row in gates['evidence']:assert sha(Path(row['path']))==row['sha256']")))
check('wrapper-exclusive-entry-only-no-process-or-business-db-operations',
      "candidate.open('xb')" in body and 'assert not entry.exists()' in body and 'installer.main()' in body
      and not any(s in body for s in ('subprocess.','taskkill','terminate(','sqlite3.','Core(','PlatformRuntime(')))
text=Path(stage['launcher']).read_text('utf-8');assert sha(Path(stage['launcher']))==stage['launcher_sha256'].lower()
needle="RELEASE = ROOT / 'releases/"+stage['release_id']+"'";assert text.count(needle)==1
text=text.replace(needle,"PROJECT_ROOT = ROOT.parent.parent / 'work/parallel-integration-20261018/final-integration/candidate-unified-v106/project'\nRELEASE = PROJECT_ROOT / 'work/ui-native-r57/releases/"+stage['release_id']+"'\nBINDING_SHA256 = '"+binding.upper()+"'")
assert text.count('project_root=ROOT.parent.parent')==1;text=text.replace('project_root=ROOT.parent.parent','project_root=PROJECT_ROOT')
needle="        pinned(RELEASE / 'RELEASE.json', MANIFEST_SHA256)";assert text.count(needle)==1
text=text.replace(needle,"        pinned(ROOT / 'state/production-workspace.json', BINDING_SHA256)\n        pinned(PROJECT_ROOT / 'work/ui-native-r57/state/production-workspace.json', BINDING_SHA256)\n"+needle)
compile(text,'reviewed-v106-next-open.py','exec')
check('exact-version-launcher-rewrite-compiles-and-checks-both-bindings',True)
check('exclusive-install-targets-not-created-yet',not (PACK/'entry-v106').exists() and not (N/('run_delegated_candidate.'+stage['release_id']+'.py')).exists())
check('all-final-review-input-pins-stable',all(sha(Path(p))==h for p,h in initial.items()))
report={'status':'PASS_INDEPENDENT_F106_PACKAGE_REVIEW','blockingFindings':[],'approvedForRootInstall':True,
    'reviewedAtUtc':datetime.now(timezone.utc).isoformat(),'releaseId':pins['releaseId'],'unifiedPinsSha256':sha(F/'UNIFIED-PINS.json'),
    'manifestSha256':sha(R/'RELEASE.json'),'rootPinsSha256':sha(PACK/'ROOT-FINAL-PINS-V106.json'),'rootGatesSha256':sha(gates_path),
    'installerSha256':sha(installer),'checks':checks,'closureFilesVerified':len(paths),'directGateEvidenceFilesVerified':len(gates['evidence']),
    'runtimeSha256':runtime_pin,'changedSourceFiles':[r['relativePath'] for r in comp['changes']],
    'knownBlockedCandidate':'F105 ff2 introduced a Core/controller reverse lock edge and remains inactive, not approved for install. F106 v2 removes that edge; old reproduction evidence retained.',
    'scopeDecision':'Old unknown14 ledger and request remain intact, original cursor advances on confirmed synthetic pages, automatic mode is independent of the legacy200 gate; legacy mode and original account/store/task/platform verification remain protected.',
    'installerReview':'Reviewed wrapper still CAS-starts from canonical F104, pins both workspace bindings/full F106 closure/gates/this review/its own bytes, and delegates only next-open launcher/FROZEN changes to the unchanged exclusive-backup atomic transaction with bounded rollback.',
    'currentExecutionLimit':'Targeted transport fixtures and static/byte verification; no real F106 collection, new Native version or real model billing claim.',
    'productionDataWrites':0,'realCloudOrProviderOrCliCalls':0,'nativeWindowsOperated':0,'installerExecuted':False}
(PACK/'FINAL-PACKAGE-REVIEW-V106.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n','utf-8')
print(json.dumps({'status':report['status'],'reviewSha256':sha(PACK/'FINAL-PACKAGE-REVIEW-V106.json'),'checks':len(checks),'closureFiles':len(paths)},ensure_ascii=False))
