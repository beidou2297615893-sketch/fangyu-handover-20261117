"""WebView2 stable snapshot and editable local UI over one employee backend."""
from __future__ import annotations

import argparse
import ctypes
import hashlib
import importlib.metadata
import json
import math
import os
from pathlib import Path, PurePosixPath
import stat
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import unquote, urlsplit, parse_qs
import uuid
import http.client
import hmac
from contextlib import nullcontext
import importlib.util
import re
import secrets
from http.cookies import SimpleCookie

SCHEMA = 'fangyu_native_ui_release_v1'
COMPANY_ID = 'fangyu-apartment-client'
CSP = ("default-src 'self'; connect-src 'none'; img-src 'self' data:; media-src 'self' blob:; "
       "style-src 'self' 'unsafe-inline'; script-src 'self'; font-src 'self'; "
       "object-src 'none'; frame-src 'self'; form-action 'none'; base-uri 'none'")
MIME = {'.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8',
        '.mjs': 'text/javascript; charset=utf-8', '.js': 'text/javascript; charset=utf-8',
        '.png': 'image/png', '.webp': 'image/webp', '.jpg': 'image/jpeg',
        '.jpeg': 'image/jpeg', '.svg': 'image/svg+xml', '.woff2': 'font/woff2'}
API_ACTIONS = frozenset(('login', 'logout', 'select_store', 'apply_preset', 'open_development',
    'platform_prepare', 'account_create', 'account_connect', 'account_check', 'account_cancel',
    'account_metadata_read','account_metadata_save','account_delete','account_delete_request',
    'account_safety', 'account_verification_open', 'account_review_confirm',
    'acquisition_start', 'acquisition_pause', 'acquisition_resume', 'acquisition_verification_open', 'acquisition_verification_resume', 'customer_export', 'refresh_assessments',
    'reply_read', 'reply_save', 'reply_review', 'reply_check', 'reply_delivery_prepare',
    'reply_delivery_start','reply_delivery_status','reply_delivery_cancel','customer_handoff_read','customer_handoff_save','customer_memo_export','customer_intent_read','customer_intent_correct','customer_intent_cancel',
    'tone_preferences_read','tone_preferences_save',
    'voice_samples_read','voice_samples_save','voice_samples_context',
    'rule_bundle_status','rule_bundle_export_chunk','rule_bundle_import_begin','rule_bundle_import_chunk',
    'rule_bundle_import_prepare','rule_bundle_import_commit','rule_bundle_import_status',
    'ai_readiness_read','ai_rules_read','ai_local_rules_save','ai_rules_export')) | frozenset(('dm_workspace_read','dm_listen_start','dm_listen_stop','dm_request_read','dm_draft_save','dm_draft_review','dm_queue_prepare','dm_queue_start','dm_queue_cancel','dm_queue_read'))
API_ACTIONS = API_ACTIONS | frozenset(('livestream_capture','livestream_request_read','livestream_sources_read','livestream_source_select','livestream_window_prepare','livestream_window_open','livestream_window_read'))
API_ACTIONS = API_ACTIONS | frozenset(('customer_public_contact_read','customer_public_contact_save','customer_public_contact_cancel'))
API_ACTIONS = API_ACTIONS | frozenset(('keyword_effect_read','customer_outcome_read','customer_outcome_save','customer_outcome_cancel','customer_outcome_report'))
API_ACTIONS = API_ACTIONS | frozenset(('remote_ai_config_read','remote_config_read','remote_ai_config_save',
    'remote_policy_publish','remote_policy_status','software_update_status','software_update_check',
    'software_update_download','software_update_prepare'))
SESSION_COOKIE = 'fangyu_workbench_r57'
API_ACTIONS = API_ACTIONS | frozenset(('content_workspace_read','content_persona_save',
    'content_topic_save','content_draft_save','content_draft_audit','content_schedule_save',
    'content_metrics_save','content_export','content_prompt_prepare','content_asset_import','content_render_cards',
    'content_guided_catalog_read','content_guided_read','content_guided_save','content_chain_save','content_experience_save',
    'content_methods_read','content_knowledge_import','content_knowledge_search',
    'content_task_prepare','content_chain_run','content_task_run','content_task_reconcile','content_task_apply','content_package_build','content_task_archive','content_task_history','content_publish_prepare','content_publish_confirm','content_publish_read','content_publish_reconcile','content_schedule_plan','content_schedule_read','content_schedule_arm','content_schedule_control','content_schedule_tick','content_schedule_reconcile'))
API_ACTIONS = API_ACTIONS | frozenset(('interaction_inbox_read','interaction_inbox_state_save','interaction_inbox_request_read'))
API_ACTIONS = API_ACTIONS | frozenset(('analysis_queue_read','analysis_queue_resume','analysis_queue_pause'))
API_ACTIONS = API_ACTIONS | frozenset(('analysis_workspace_read','analysis_workspace_resume','analysis_workspace_pause'))
MEDIA_ACTIONS=frozenset('media_services_status media_ocr_preview media_speech_preview media_speech_cancel media_speech_save media_speech_read media_status media_upload_begin media_upload_read media_upload_chunk media_upload_complete media_upload_cancel media_prepare media_read media_preview media_start media_cancel media_recover media_request'.split())
API_ACTIONS = API_ACTIONS | MEDIA_ACTIONS
API_ACTIONS = API_ACTIONS | frozenset(('content_knowledge_file_preview','content_store_context_read'))
API_ACTIONS = API_ACTIONS | frozenset(('content_public_article_preview','content_public_article_read','content_public_article_import','content_public_article_cancel'))
API_ACTIONS = API_ACTIONS | frozenset(('content_public_research_preview','content_public_research_read','content_public_research_import'))
CONTENT_JSON_ACTIONS = frozenset(action for action in API_ACTIONS if action.startswith('content_'))
API_ACTIONS = API_ACTIONS | frozenset(('acquisition_source_preview','source_preset_read',
    'source_preset_save','source_schedule_read','source_schedule_save','source_interactions_check','source_execution_enable','source_execution_read','source_execution_pause'))


class UIHostError(RuntimeError):
    pass


class RuntimeRequestError(ValueError):
    def __init__(self, code, message, status):
        super().__init__(message)
        self.code, self.status = code, status


def load_support(name):
    """Load only a fixed sibling included in the release integrity manifest."""
    if name not in ('workspace_binding', 'lifecycle_log'):
        raise UIHostError('启动组件名称无效。')
    path = Path(__file__).resolve().parent / (name + '.py')
    key = 'fangyu_ui_' + name + '_' + hashlib.sha256(str(path).encode()).hexdigest()[:16]
    if key in sys.modules:
        return sys.modules[key]
    raw = read_public(path)
    module = importlib.util.module_from_spec(importlib.util.spec_from_loader(key, loader=None))
    module.__file__ = str(path)
    sys.modules[key] = module
    try:
        exec(compile(raw, str(path), 'exec'), module.__dict__)
    except BaseException:
        sys.modules.pop(key, None)
        raise
    return module


def production_workspace(project_root, data_dir=None):
    # Trusted callers may supply an explicit isolated fixture. Normal launchers
    # supply no override and must resolve the declared existing production data.
    if data_dir is not None:
        return Path(data_dir)
    try:
        return load_support('workspace_binding').resolve_workspace(project_root, company_id=COMPANY_ID)
    except Exception as error:
        if type(error).__name__ == 'WorkspaceBindingError':
            failure = UIHostError(str(error))
            failure.code = error.code
            raise failure from error
        raise UIHostError('工作资料位置尚未确认，请管理员修复启动组件后重新打开。') from error


class _NoLifecycleLog:
    def record(self, *args, **kwargs):
        return False


def make_lifecycle_log(state_root, release_id, *, hooks=False):
    try:
        module = load_support('lifecycle_log')
        log = module.LifecycleLog(state_root, release_id)
        if hooks:
            module.install_hooks(log)
        return log
    except Exception:
        return _NoLifecycleLog()


def checked_path(path: Path, *, directory=False):
    """Reject links/reparse points before touching public release files."""
    for item in (path, *path.parents):
        info = item.lstat()
        if item.is_symlink() or getattr(info, 'st_file_attributes', 0) & 0x400:
            raise UIHostError('界面文件路径不能是链接或重定向。')
    info = path.stat()
    if directory:
        if not stat.S_ISDIR(info.st_mode):
            raise UIHostError('界面目录不存在。')
    elif not stat.S_ISREG(info.st_mode) or info.st_nlink != 1:
        raise UIHostError('界面文件必须是独立的普通文件。')
    return info


def read_public(path: Path, expected_hash=None, expected_size=None):
    before = checked_path(path)
    with path.open('rb') as stream:
        opened = os.fstat(stream.fileno())
        body = stream.read()
        ended = os.fstat(stream.fileno())
    after = checked_path(path)
    identity = lambda item: (item.st_dev, item.st_ino, item.st_size, item.st_mtime_ns)
    if not identity(before) == identity(opened) == identity(ended) == identity(after):
        raise UIHostError('界面文件在检查时发生变化，请重新打开。')
    digest = hashlib.sha256(body).hexdigest().upper()
    if ((expected_hash is not None and digest != expected_hash.upper())
            or (expected_size is not None and len(body) != expected_size)):
        raise UIHostError('界面文件校验失败，请重新固化界面版本。')
    return body


def verify_release(root: Path, manifest_sha256: str):
    root = Path(root).absolute()
    checked_path(root, directory=True)
    raw = read_public(root / 'RELEASE.json', manifest_sha256)
    manifest = json.loads(raw)
    if (manifest.get('schema') != SCHEMA or manifest.get('company_id') != COMPANY_ID
            or type(manifest.get('files')) is not list):
        raise UIHostError('界面版本清单不匹配。')
    files = {}
    for entry in manifest['files']:
        name = entry.get('path', '')
        relative = PurePosixPath(name)
        if (not name or relative.is_absolute() or '..' in relative.parts
                or '\\' in name or ':' in name or name in files
                or relative.as_posix() != name
                or not (name.startswith('web/') or name.startswith('resources/')
                        or name in ('customer_read_store.py','priority_followup.py','ui_native_host.py', 'workspace_binding.py', 'lifecycle_log.py', 'workbench_backend.py', 'customer_workbench.py', 'codex_review.py', 'keyword_effect_workbench.py', 'customer_outcomes_workbench.py', 'customer_public_contacts.py', 'customer_intent_workbench.py',
                                    'store_materials.py','store_materials_catalog.json','approved_intent_policy.json','store_search_profiles.json',
                                    'rental_assessment.py','reply_workbench.py','reply_delivery.py','dm_workbench.py'))):
            raise UIHostError('界面版本包含无效文件名。')
        if (type(entry.get('size')) is not int or entry['size'] < 0
                or not isinstance(entry.get('sha256'), str)
                or len(entry['sha256']) != 64):
            raise UIHostError('界面版本文件记录不完整。')
        read_public(root / name, entry['sha256'], entry['size'])
        files[name] = entry
    required = {'ui_native_host.py', 'web/index.html', 'web/app.mjs', 'web/styles.css'}
    if not required.issubset(files):
        raise UIHostError('界面版本缺少入口或样式。')
    actual = set()
    for tree in ('web', 'resources'):
        checked_path(root / tree, directory=True)
        for item in (root / tree).rglob('*'):
            checked_path(item, directory=item.is_dir())
            if item.is_file():
                actual.add(item.relative_to(root).as_posix())
    actual.add('ui_native_host.py')
    if (root / 'workbench_backend.py').exists():
        checked_path(root / 'workbench_backend.py')
        actual.add('workbench_backend.py')
    if (root / 'customer_workbench.py').exists():
        checked_path(root / 'customer_workbench.py')
        actual.add('customer_workbench.py')
    for extra in ('customer_read_store.py','priority_followup.py','codex_review.py','customer_intent_workbench.py','keyword_effect_workbench.py', 'customer_outcomes_workbench.py','customer_public_contacts.py','store_materials.py','store_materials_catalog.json','rental_assessment.py','reply_workbench.py','reply_delivery.py','dm_workbench.py',
                  'workspace_binding.py','lifecycle_log.py','approved_intent_policy.json','store_search_profiles.json'):
        if (root / extra).exists():
            checked_path(root / extra)
            actual.add(extra)
    if actual != set(files):
        raise UIHostError('界面版本文件集合与清单不一致。')
    return manifest, files


class StaticServer(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = False

    def __init__(self, root, files, *, backend=None, cookie_name=SESSION_COOKIE, runtime=None):
        self.root = Path(root)
        self.runtime = runtime
        self.backend = backend
        if not re.fullmatch(r'[A-Za-z0-9_-]{1,100}', cookie_name):
            raise UIHostError('本地会话名称无效。')
        self.session_cookie = cookie_name
        self.mode = 'stable'
        self.csrf_token = secrets.token_urlsafe(32)
        self.csp = CSP.replace("connect-src 'none'", "connect-src 'self'") if backend else CSP
        self.login_failures = []
        self.api_lock = runtime.api_lock if runtime else threading.RLock()
        self.public = {'/' + name[4:]: entry for name, entry in files.items()
                       if name.startswith('web/') and Path(name).suffix in MIME}
        self.public['/'] = self.public['/index.html']
        self.counters = {'static': 0, 'blocked': 0}
        super().__init__(('127.0.0.1', 0), StaticHandler)

    def read_static(self, path):
        entry = self.public.get(path)
        if entry is None:
            raise FileNotFoundError(path)
        return (read_public(self.root / entry['path'], entry['sha256'], entry['size']),
                MIME[Path(entry['path']).suffix])


class DevelopmentServer(StaticServer):
    """Serve only editable public UI source; reuse the stable API transport."""
    def __init__(self, root, files, *, source_root, assets_root, **kwargs):
        self.source_root = Path(source_root).absolute()
        self.assets_root = Path(assets_root).absolute()
        checked_path(self.source_root, directory=True)
        super().__init__(root, files, **kwargs)
        self.mode = 'development'

    def read_static(self, path):
        name = 'index.html' if path == '/' else path.lstrip('/')
        relative = PurePosixPath(name)
        parts = relative.parts
        if (not parts or relative.is_absolute() or relative.as_posix() != name
                or any(not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.-]*', part) for part in parts)
                or any(re.search(r'(?i)(credential|secret|cookie|password|vault|token)', part) for part in parts)):
            raise FileNotFoundError(path)
        code = {'.html', '.css', '.js', '.mjs'}
        images = {'.png', '.webp', '.jpg', '.jpeg', '.svg', '.woff2'}
        if len(parts) == 1 and relative.suffix in code:
            target = self.source_root / name
        elif len(parts) == 2 and parts[0] == 'pages' and relative.suffix in code:
            target = self.source_root / name
        elif len(parts) >= 2 and parts[0] == 'assets' and relative.suffix in images:
            target = self.source_root / name
            if not target.exists():
                target = self.assets_root.joinpath(*parts[1:])
        else:
            raise FileNotFoundError(path)
        return read_public(target), MIME[relative.suffix]


class StaticHandler(BaseHTTPRequestHandler):
    server_version = 'FangyuUI'
    sys_version = ''

    def log_message(self, *_):
        pass

    def finish_response(self, status, body=b'', content_type='text/plain; charset=utf-8', *, cookie=None, location=None, extra_headers=None):
        self.send_response(status)
        self.send_header('Content-Type', content_type)
        self.send_header('Content-Length', str(len(body)))
        for key,value in (extra_headers or {}).items():self.send_header(key,value)
        self.send_header('Cache-Control', 'no-store')
        self.send_header('Content-Security-Policy', self.server.csp)
        if cookie is not None:
            self.send_header('Set-Cookie', cookie)
        if location is not None:
            self.send_header('Location', location)
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.send_header('Referrer-Policy', 'no-referrer')
        self.send_header('Cross-Origin-Resource-Policy', 'same-origin')
        self.send_header('Connection', 'close')
        self.end_headers()
        if self.command != 'HEAD' and body:
            self.wfile.write(body)
        self.close_connection = True

    def reject(self, status=403):
        self.server.counters['blocked'] += 1
        self.finish_response(status, '此入口仅提供本机工作台页面。'.encode('utf-8'))

    def api_response(self, status, value, *, cookie=None):
        self.finish_response(status, json.dumps(value, ensure_ascii=False, allow_nan=False).encode('utf-8'),
                             'application/json; charset=utf-8', cookie=cookie)

    def session_token(self):
        try:
            cookies = SimpleCookie(self.headers.get('Cookie', ''))
            name = self.server.session_cookie
            value = cookies[name].value if name in cookies else ''
            return value if re.fullmatch(r'[A-Za-z0-9_-]{1,256}', value) else ''
        except Exception:
            return ''

    def dispatch_api(self, action, data):
        # Native authenticates task_run under its own short lock, and its
        # component revalidates authority when committing the model result.
        # Waiting for that model must not block unrelated local HTTP actions.
        long_action=action in ('content_public_article_preview','content_public_research_preview','content_chain_run','content_task_run','content_task_reconcile','content_publish_confirm','content_publish_reconcile','content_schedule_tick','content_schedule_reconcile','livestream_capture','livestream_source_select') or action=='livestream_sources_read' and data.get('refreshWindows') is True
        local_customer_read=action in ('customers','customer_detail','reply_read','analysis_queue_read','analysis_queue_resume','analysis_queue_pause','analysis_workspace_read','analysis_workspace_resume','analysis_workspace_pause')
        with (nullcontext() if long_action or local_customer_read else self.server.api_lock):
            try:
                if self.server.runtime is not None and self.server.runtime.closed:
                    raise RuntimeRequestError('BACKEND_CLOSED', '本地服务已关闭。', 503)
                if action == 'login':
                    now = time.monotonic()
                    self.server.login_failures = [stamp for stamp in self.server.login_failures if now-stamp < 300]
                    if len(self.server.login_failures) >= 10:
                        return self.api_response(429, {'ok': False, 'error': {'code': 'LOGIN_RATE_LIMIT', 'message': '登录尝试较多，请5分钟后再试。'}})
                if action == 'open_development':
                    if data or self.server.runtime is None:
                        raise RuntimeRequestError('ACTION_FORBIDDEN', '当前入口不能打开开发页面。', 403)
                    result = self.server.runtime.open_development(self.session_token())
                else:
                    result = dict(self.server.backend.dispatch(action, data, token=self.session_token()))
                token = result.pop('token', None)
                max_age = result.pop('cookie_max_age', None)
                cookie = None
                if action == 'login' and token:
                    if not isinstance(token, str) or not re.fullmatch(r'[A-Za-z0-9_-]{1,256}', token):
                        raise UIHostError('登录会话响应无效。')
                    cookie = self.server.session_cookie + '=' + token + '; Path=/; HttpOnly; SameSite=Strict'
                    if isinstance(max_age, (int, float)) and math.isfinite(max_age):
                        cookie += '; Max-Age=' + str(max(1, min(int(max_age), 30*86400)))
                    self.server.login_failures = []
                elif action == 'logout':
                    cookie = self.server.session_cookie + '=; Path=/; HttpOnly; SameSite=Strict; Max-Age=0'
                self.api_response(200, {'ok': True, **result, 'csrfToken': self.server.csrf_token}, cookie=cookie)
            except Exception as error:
                known = isinstance(getattr(error, 'code', None), str)
                status = getattr(error, 'status', 400) if known else 503
                if type(status) is not int or status not in (400, 401, 403, 404, 409, 413, 422, 429, 503):
                    status = 400
                # An unavailable service is not a rejected employee credential.
                # Keep the existing limit for confirmed authentication failures.
                if action == 'login' and status == 401:
                    self.server.login_failures.append(time.monotonic())
                error_body={
                    'code': error.code if known else 'WORKBENCH_UNAVAILABLE',
                    'message': str(error) if known else '暂时无法完成操作，请稍后重试。'}
                if known and type(getattr(error,'mutation_committed',None)) is bool:
                    error_body['mutation_committed']=error.mutation_committed
                self.api_response(status, {'ok': False, 'error': error_body})

    def do_POST(self):
        origin = 'http://127.0.0.1:' + str(self.server.server_port)
        if (self.server.backend is None or self.path != '/api/workbench'
                or self.headers.get('Host') != origin[7:]
                or self.headers.get('Origin') != origin
                or self.headers.get('Upgrade') or self.headers.get('Transfer-Encoding')
                or self.headers.get('Content-Type', '').split(';')[0].strip() != 'application/json'
                or not hmac.compare_digest(self.headers.get('X-Fangyu-CSRF', ''), self.server.csrf_token)):
            return self.reject()
        try:
            size = int(self.headers.get('Content-Length', '0'))
            if not 1 <= size <= 3000000:
                return self.reject(413)
            value = json.loads(self.rfile.read(size))
            if (not isinstance(value, dict) or set(value) - {'action', 'data'}
                    or value.get('action') not in API_ACTIONS or not isinstance(value.get('data'), dict)):
                return self.reject()
            action=value['action']
            source_start=action=='acquisition_start' and isinstance(value['data'].get('source'),dict)
            limit=(3000000 if action in ('content_knowledge_file_preview','media_ocr_preview') else
                500000 if action=='content_knowledge_import' else
                300000 if action in ('content_asset_import','acquisition_source_preview','source_preset_save') or source_start else
                133120 if action=='rule_bundle_import_chunk' or action in CONTENT_JSON_ACTIONS or action=='media_upload_chunk' else 16384)
            if size>limit:return self.reject(413)
        except (ValueError, UnicodeError, TypeError, RecursionError):
            return self.reject(400)
        self.dispatch_api(value['action'], value['data'])

    def do_GET(self):
        expected_host = '127.0.0.1:' + str(self.server.server_port)
        if self.headers.get('Host') != expected_host or self.headers.get('Upgrade'):
            return self.reject()
        try:
            parsed = urlsplit(self.path)
            path = unquote(parsed.path, errors='strict')
        except (ValueError, UnicodeError):
            return self.reject()
        if (parsed.scheme or parsed.netloc or '\\' in path or '\x00' in path
                or any(part in ('.', '..') for part in path.split('/'))):
            return self.reject()
        if path == '/favicon.ico':
            return self.finish_response(204)
        if path == '/__workbench_status' and self.server.runtime is not None and not parsed.query:
            return self.api_response(200, self.server.runtime.public_status(self.server))
        if path == '/__open' and self.server.runtime is not None and self.server.mode == 'development':
            if self.command != 'GET':
                return self.finish_response(405)
            try:
                query = parse_qs(parsed.query, strict_parsing=True)
                if set(query) != {'ticket'} or len(query['ticket']) != 1:
                    return self.reject(400)
                token = self.server.runtime.consume_ticket(query['ticket'][0])
                cookie = self.server.session_cookie + '=' + token + '; Path=/; HttpOnly; SameSite=Strict'
                return self.finish_response(303, cookie=cookie, location='/')
            except RuntimeRequestError as error:
                return self.api_response(error.status, {'ok': False, 'error': {'code': error.code, 'message': str(error)}})
            except (ValueError, UnicodeError):
                return self.reject(400)
            except Exception:
                return self.api_response(503, {'ok': False, 'error': {'code': 'WORKBENCH_UNAVAILABLE', 'message': '暂时无法确认员工登录，请返回工作台重试。'}})
        if path == '/api/workbench/bootstrap' and self.server.backend is not None and not parsed.query:
            return self.dispatch_api('bootstrap', {})
        if path == '/api/workbench/platform' and self.server.backend is not None:
            try:
                query=parse_qs(parsed.query,strict_parsing=True,keep_blank_values=True) if parsed.query else {}
                if set(query)-{'platform'} or any(len(values)!=1 for values in query.values()):
                    return self.reject(400)
                return self.dispatch_api('platform_snapshot',{key:values[0] for key,values in query.items()})
            except (ValueError,UnicodeError):
                return self.reject(400)
        if path == '/api/workbench/content-video' and self.server.backend is not None:
            try:
                query=parse_qs(parsed.query,strict_parsing=True,keep_blank_values=True)
                if set(query)!={'storeId','accountId','platform','jobId','download'} or any(len(v)!=1 for v in query.values()):return self.reject(400)
                status,body,headers=self.server.backend.content_video(self.session_token(),{k:v[0] for k,v in query.items()},self.headers.get('Range',''))
                return self.finish_response(status,body,'video/mp4',extra_headers=headers)
            except Exception as error:
                status=getattr(error,'status',503)
                if type(status) is not int or status not in (400,401,403,404,409,503):status=503
                return self.finish_response(status)
        if path == '/api/workbench/media' and self.server.backend is not None:
            try:
                query=parse_qs(parsed.query,strict_parsing=True,keep_blank_values=True)
                if set(query)!={'storeId','leadId','kind'} or any(len(values)!=1 for values in query.values()):
                    return self.reject(400)
                body,mime=self.server.backend.media(self.session_token(),{key:values[0] for key,values in query.items()})
                return self.finish_response(200,body,mime)
            except Exception as error:
                status=getattr(error,'status',404)
                if type(status) is not int or status not in (400,401,403,404,503):status=404
                return self.finish_response(status)
        if path in ('/api/workbench/customers', '/api/workbench/customer') and self.server.backend is not None:
            try:
                query = parse_qs(parsed.query, strict_parsing=True, keep_blank_values=True) if parsed.query else {}
                allowed = ({'query', 'filter', 'sort', 'sortDirection', 'page', 'pageSize','audience','platform','intent','acquiredDate','leaseGroup','review'}
                           if path.endswith('/customers') else {'id','platform'})
                if set(query) - allowed or any(len(values) != 1 for values in query.values()):
                    return self.reject(400)
                data = {key: values[0] for key, values in query.items()}
                if path.endswith('/customer'):
                    if 'id' not in data or not re.fullmatch(r'[0-9a-f]{64}', data['id']):
                        return self.reject(400)
                else:
                    if 'review' in data and data['review'] not in ('all','priority','reviewed'):
                        return self.reject(400)
                    for key in ('page', 'pageSize'):
                        if key in data:
                            if not re.fullmatch(r'[1-9][0-9]{0,5}', data[key]):
                                return self.reject(400)
                            data[key] = int(data[key])
                return self.dispatch_api('customers' if path.endswith('/customers') else 'customer_detail', data)
            except (ValueError, UnicodeError):
                return self.reject(400)
        if path == '/api/workbench/account-job' and self.server.backend is not None:
            try:
                query = parse_qs(parsed.query, strict_parsing=True)
                if (set(query) != {'jobId'} or len(query['jobId']) != 1
                        or not re.fullmatch(r'[A-Za-z0-9_-]{1,100}', query['jobId'][0])):
                    return self.reject(400)
                return self.dispatch_api('account_job', {'jobId': query['jobId'][0]})
            except ValueError:
                return self.reject(400)
        try:
            body, mime = self.server.read_static(path)
        except FileNotFoundError:
            return self.reject(403 if path.startswith('/api') else 404)
        except (OSError, UIHostError):
            return self.finish_response(503, '界面资源校验失败，请关闭后重新打开。'.encode('utf-8'))
        self.server.counters['static'] += 1
        self.finish_response(200, body, mime)

    do_HEAD = do_GET
    do_PUT = reject
    do_PATCH = reject
    do_DELETE = reject
    do_OPTIONS = reject
    do_CONNECT = reject
    do_TRACE = reject


def create_state_directory(root: Path):
    root.mkdir(parents=True, exist_ok=True)
    checked_path(root, directory=True)
    return root


def _install_pinned_source_imports(groups):
    """Scope original Python imports to verified source bytes, never pyc.

    FileFinder is source-only for these exact directories. Explicit
    SourceFileLoader calls use the same pins. Other Python paths retain their
    original loaders; this is an import-integrity guard, not an OS sandbox.
    """
    import importlib.machinery
    key=lambda value:os.path.normcase(os.path.abspath(os.fspath(value)))
    within=lambda path,root:path==root or path.startswith(root+os.sep)
    loader=importlib.machinery.SourceFileLoader
    previous=loader.get_code
    state=getattr(previous,'_fangyu_pinned_source_state',None)
    if state is None:
        state={'roots':{},'lock':threading.RLock()}
        def source_code(self,fullname):
            path=key(self.path)
            with state['lock']:
                roots=tuple(state['roots'].items())
            for scope,entries in roots:
                if within(path,scope):
                    entry=entries.get(path)
                    if entry is None:raise UIHostError('运行组件不在本版本源码清单中。')
                    raw=read_public(Path(self.path),entry[0],entry[1])
                    return compile(raw,self.path,'exec',dont_inherit=True,optimize=0)
            return previous(self,fullname)
        def source_path_hook(path):
            selected=key(path)
            with state['lock']:
                protected=any(within(selected,scope) for scope in state['roots'])
            if not protected:raise ImportError
            checked_path(Path(path),directory=True)
            return importlib.machinery.FileFinder(path,(loader,('.py',)))
        source_code._fangyu_pinned_source_state=state
        state['code']=source_code;state['path_hook']=source_path_hook
    prepared={key(scope):{key(Path(scope)/name):(entry['sha256'],entry['size'])
        for name,entry in entries.items()} for scope,entries in groups}
    with state['lock']:
        for scope,entries in prepared.items():
            old=state['roots'].get(scope)
            if old is not None and old!=entries:raise UIHostError('已载入的运行组件版本不同，请独立重开。')
        state['roots'].update(prepared)
        loader.get_code=state['code']
        if state['path_hook'] not in sys.path_hooks:sys.path_hooks.insert(0,state['path_hook'])
        # Do not retain a default extension/cache finder created before pins.
        for cached in tuple(sys.path_importer_cache):
            if any(within(key(cached),scope) for scope in prepared):sys.path_importer_cache.pop(cached,None)


def verify_backend_dependencies(root, files, project):
    """Read-only hash checks; never construct a Core or access customer records."""
    if 'workbench_backend.py' not in files:
        return None
    dependency = files.get('resources/backend-dependencies.json')
    if dependency is None:
        raise UIHostError('登录组件缺少依赖清单。')
    config = json.loads(read_public(root / dependency['path'], dependency['sha256'], dependency['size']))
    if config.get('schema') != 'fangyu-existing-login-components-v1':
        raise UIHostError('登录组件依赖清单不匹配。')
    source = project / 'work/ui-runtime-r55/src'
    expected = set(); source_pins = {}
    for item in config.get('files', []):
        name = item.get('path', '')
        relative = PurePosixPath(name)
        if (not name or relative.is_absolute() or '..' in relative.parts or '\\' in name
                or ':' in name or relative.as_posix() != name or relative.suffix != '.py'
                or name in expected):
            raise UIHostError('登录组件包含无效路径。')
        read_public(source / name, item['sha256'], item['size'])
        expected.add(name); source_pins[name] = item
    actual = set()
    for path in source.rglob('*'):
        checked_path(path,directory=path.is_dir())
        if (any(part.casefold()=='__pycache__' for part in path.relative_to(source).parts)
                or path.suffix.lower() in ('.pyc','.pyo','.pyd','.so','.dll','.dylib','.exe')):
            raise UIHostError('运行组件包含未列入清单的代码或缓存，请重新核验本版本。')
        if path.is_file() and path.suffix.lower()=='.py':actual.add(path.relative_to(source).as_posix())
    if not expected or actual != expected:
        raise UIHostError('已有登录组件发生变化，请重新核验本版本。')
    # Registration completes before create_backend inserts the original source
    # into sys.path. Later caches/native files cannot become an import choice;
    # a later source change still fails the original read_public hash check.
    release_pins={name:entry for name,entry in files.items() if PurePosixPath(name).suffix=='.py'}
    _install_pinned_source_imports(((source,source_pins),(root,release_pins)))
    return source


def load_customer_intent_factory(root, files):
    """Load only manifest-pinned helper bytes; never rely on release sys.path."""
    entry=files.get('customer_intent_workbench.py')
    if entry is None:return None
    raw=read_public(root / entry['path'],entry['sha256'],entry['size'])
    name='fangyu_customer_intent_workbench_'+hashlib.sha256(raw).hexdigest()[:16]
    child=importlib.util.module_from_spec(importlib.util.spec_from_loader(name,loader=None))
    child.__file__=str(root / entry['path'])
    exec(compile(raw,child.__file__,'exec'),child.__dict__)
    return child.IntentCorrectionWorkbench


def _media_factory(root,files):
    # Fixed manifest entries, private namespace, compiled from verified bytes.
    # Does not rely on the launcher's sys.path or a same-name global module.
    names=('cpu_media_engine.py','media_production.py','media_native.py','windows_media_services.py')
    prefix='resources/content-media/'
    if not any(prefix+name in files for name in names):return None
    package_name='_fangyu_native_media_'+uuid.uuid4().hex
    package=importlib.util.module_from_spec(importlib.util.spec_from_loader(package_name,loader=None,is_package=True))
    package.__path__=[];sys.modules[package_name]=package
    loaded={}
    try:
        for filename in names:
            entry=files.get(prefix+filename)
            if entry is None:raise UIHostError('视频制作资源不完整，请重新固化。')
            raw=read_public(root/entry['path'],entry['sha256'],entry['size'])
            name=package_name+'.'+filename[:-3]
            module=importlib.util.module_from_spec(importlib.util.spec_from_loader(name,loader=None))
            module.__package__=package_name;module.__file__=str(root/entry['path'])
            sys.modules[name]=module;loaded[name]=module
            exec(compile(raw,module.__file__,'exec'),module.__dict__)
        for helper in ('windows_media_bridge.ps1','LICENSE-microsoft-samples.txt'):
            entry=files.get(prefix+helper)
            if entry is None:raise UIHostError('系统媒体资源不完整，请重新固化。')
            read_public(root/entry['path'],entry['sha256'],entry['size'])
        return loaded[package_name+'.media_native'].NativeMedia
    except Exception:
        for name in (*loaded,package_name):sys.modules.pop(name,None)
        raise


def _keyword_effect_factory(root, files):
    entry=files.get('keyword_effect_workbench.py')
    if entry is None:return None
    # Read only the manifest-verified original bytes. The launcher execs
    # this host without adding the release directory to sys.path. Keep
    # the helper module local to this factory; no global same-name cache.
    raw=read_public(root/entry['path'],entry['sha256'],entry['size'])
    name='fangyu_keyword_effect_'+entry['sha256'][:16]
    module=importlib.util.module_from_spec(importlib.util.spec_from_loader(name,loader=None))
    module.__file__=str(root/entry['path'])
    exec(compile(raw,module.__file__,'exec'),module.__dict__)
    return module.KeywordEffectWorkbench


def _customer_outcomes_factory(root, files):
    entry=files.get('customer_outcomes_workbench.py')
    if entry is None:return None
    # Read only the manifest-verified original bytes. The launcher execs
    # this host without adding the release directory to sys.path. Keep
    # the helper module local to this factory; no global same-name cache.
    raw=read_public(root/entry['path'],entry['sha256'],entry['size'])
    name='fangyu_customer_outcomes_'+entry['sha256'][:16]
    module=importlib.util.module_from_spec(importlib.util.spec_from_loader(name,loader=None))
    module.__file__=str(root/entry['path'])
    exec(compile(raw,module.__file__,'exec'),module.__dict__)
    return module.CustomerOutcomesWorkbench


def _public_contacts_factory(root,files,outcomes_factory):
    entry=files.get('customer_public_contacts.py')
    if entry is None or outcomes_factory is None:return None
    raw=read_public(root/entry['path'],entry['sha256'],entry['size'])
    module=importlib.util.module_from_spec(importlib.util.spec_from_loader('fangyu_public_contacts_'+entry['sha256'][:16],loader=None))
    module.__file__=str(root/entry['path'])
    exec(compile(raw,module.__file__,'exec'),module.__dict__)
    return lambda core,customers: module.PublicContactsWorkbench(core,customers,outcomes_factory)


def _knowledge_file_factory(root,files,media=None):
    entry=files.get('resources/knowledge-file-import/knowledge_file_import.py')
    if entry is None:return None
    raw=read_public(root/entry['path'],entry['sha256'],entry['size'])
    module=importlib.util.module_from_spec(importlib.util.spec_from_loader('fangyu_knowledge_file_'+entry['sha256'][:16],loader=None))
    module.__file__=str(root/entry['path'])
    exec(compile(raw,module.__file__,'exec'),module.__dict__)
    scan_entry=files.get('resources/knowledge-file-import/scanned_pdf_ocr.py')
    if scan_entry is None:return module.preview
    if media is None:raise UIHostError('扫描PDF依赖的系统媒体组件不完整。')
    scan_raw=read_public(root/scan_entry['path'],scan_entry['sha256'],scan_entry['size'])
    child=importlib.util.module_from_spec(importlib.util.spec_from_loader('fangyu_scanned_pdf_'+scan_entry['sha256'][:16],loader=None))
    child.__file__=str(root/scan_entry['path']);exec(compile(scan_raw,child.__file__,'exec'),child.__dict__)
    engine=sys.modules[media.__class__.__module__.rsplit('.',1)[0]+'.cpu_media_engine']
    def resource(name):
        if name not in ('resources/knowledge-file-import/scanned_pdf_ocr.py','resources/knowledge-file-import/windows_pdf_bridge.ps1','resources/content-media/LICENSE-microsoft-samples.txt'):raise UIHostError('扫描PDF资源路径无效。')
        item=files.get(name)
        if item is None:raise UIHostError('扫描PDF资源不完整。')
        return read_public(root/item['path'],item['sha256'],item['size'])
    scanner=child.ScannedPdfOcr(resource,engine._WindowsJob,engine.checked_file,temp_dir=media.root/'pdf-import-temp',reserve=media.storage_limit,checked_directory=media.checked_directory)
    return lambda filename,raw:module.preview(filename,raw,scan_ocr=scanner)


def create_backend(root, files, *, project_root, data_dir=None, company=None, content_model_adapter=None, publication_factory=None):
    """Reuse the pinned customer components without importing app/main or schedulers."""
    entry = files.get('workbench_backend.py')
    if entry is None:
        return None
    project = Path(project_root).absolute()
    source = verify_backend_dependencies(root, files, project)
    sys.path.insert(0, str(source))
    # Load the pinned r57 role-preserving adapter before any business import.
    integration_entry = files.get('resources/platform-runtime/vendor-src/integrations.py')
    if integration_entry:
        integration_path = root / integration_entry['path']
        previous = sys.modules.get('integrations')
        if previous is not None and Path(previous.__file__).resolve() != integration_path.resolve():
            raise UIHostError('已有身份组件来源不同，请独立重开候选验收。')
        if previous is None:
            child = importlib.util.module_from_spec(importlib.util.spec_from_loader('integrations',loader=None))
            child.__file__ = str(integration_path)
            sys.modules['integrations'] = child
            raw = read_public(integration_path,integration_entry['sha256'],integration_entry['size'])
            exec(compile(raw,child.__file__,'exec'),child.__dict__)
    # Display-only cache and derived screen are exact release-pinned helpers.
    # No sys.path fallback or unverified same-name cached module is accepted.
    for helper_name in ('customer_read_store', 'priority_followup'):
        helper_entry=files.get(helper_name+'.py')
        if helper_entry is None:
            raise UIHostError('客户本地读取组件不完整，请重新固化。')
        helper_path=str(root/helper_entry['path'])
        helper_raw=read_public(root/helper_entry['path'],helper_entry['sha256'],helper_entry['size'])
        previous=sys.modules.get(helper_name)
        if previous is not None and getattr(previous,'__file__',None)!=helper_path:
            raise UIHostError('已有客户本地组件来源不同，请独立重开。')
        if previous is None:
            helper_module=importlib.util.module_from_spec(importlib.util.spec_from_loader(helper_name,loader=None))
            helper_module.__file__=helper_path
            sys.modules[helper_name]=helper_module
            try:
                exec(compile(helper_raw,helper_path,'exec'),helper_module.__dict__)
            except Exception:
                sys.modules.pop(helper_name,None)
                raise
    module_name = 'fangyu_workbench_backend'
    module = importlib.util.module_from_spec(importlib.util.spec_from_loader(module_name, loader=None))
    module.__file__ = str(root / entry['path'])
    sys.modules[module_name] = module
    raw = read_public(root / entry['path'], entry['sha256'], entry['size'])
    exec(compile(raw, module.__file__, 'exec'), module.__dict__)
    extra = {}
    media_factory=_media_factory(root,files)
    if media_factory is not None:extra['media_factory']=media_factory
    if any(name in files for name in ('store_materials.py','store_materials_catalog.json','rental_assessment.py')):
        if not all(name in files for name in ('store_materials.py','store_materials_catalog.json','rental_assessment.py')):
            raise UIHostError('门店词库和判断模块不完整，请重新固化。')
        loaded = {}
        for filename in ('store_materials.py','rental_assessment.py'):
            item=files[filename]
            name='fangyu_'+Path(filename).stem
            child=importlib.util.module_from_spec(importlib.util.spec_from_loader(name,loader=None))
            child.__file__=str(root/item['path'])
            if filename=='rental_assessment.py':
                previous=sys.modules.get('rental_assessment')
                if previous is not None and getattr(previous,'__file__',None)!=child.__file__:
                    raise UIHostError('已有租住判断组件来源不同，请独立重开。')
            sys.modules[name]=child
            source_bytes=read_public(root/item['path'],item['sha256'],item['size'])
            exec(compile(source_bytes,child.__file__,'exec'),child.__dict__)
            loaded[filename]=child
            if filename=='rental_assessment.py':
                # The continuous screen imports this canonical name lazily;
                # it is the exact already read_public-verified evaluator.
                sys.modules['rental_assessment']=child
        catalog=files['store_materials_catalog.json']
        builtin=files.get('store_search_profiles.json')
        extra['materials_factory']=lambda core: loaded['store_materials.py'].StoreMaterials(
            core,root/catalog['path'],expected_sha256=catalog['sha256'],
            **({'builtin_search_path':root/builtin['path'],'expected_builtin_sha256':builtin['sha256']} if builtin else {}))
        extra['rental_factory']=loaded['rental_assessment.py'].RentalAssessmentService
    customer_entry = files.get('customer_workbench.py')
    if customer_entry is not None:
        review_entry = files.get('codex_review.py')
        if review_entry is None:
            raise UIHostError('客户复核组件不完整，请重新固化。')
        review_path = str(root / review_entry['path'])
        existing_review = sys.modules.get('codex_review')
        if existing_review is not None and getattr(existing_review, '__file__', None) != review_path:
            raise UIHostError('已有客户复核组件来源不同，请独立重开。')
        review_raw = read_public(root / review_entry['path'], review_entry['sha256'], review_entry['size'])
        review_module = importlib.util.module_from_spec(importlib.util.spec_from_loader('codex_review', loader=None))
        review_module.__file__ = review_path
        sys.modules['codex_review'] = review_module
        try:
            exec(compile(review_raw, review_path, 'exec'), review_module.__dict__)
        except Exception:
            sys.modules.pop('codex_review', None)
            raise
        customer_name = 'fangyu_customer_workbench'
        customer_module = importlib.util.module_from_spec(importlib.util.spec_from_loader(customer_name, loader=None))
        customer_module.__file__ = str(root / customer_entry['path'])
        sys.modules[customer_name] = customer_module
        customer_raw = read_public(root / customer_entry['path'], customer_entry['sha256'], customer_entry['size'])
        exec(compile(customer_raw, customer_module.__file__, 'exec'), customer_module.__dict__)
        extra['customer_factory'] = customer_module.CustomerWorkbench
    intent_factory=load_customer_intent_factory(root,files)
    if intent_factory is not None:
        extra['customer_intent_factory']=intent_factory
    keyword_factory = _keyword_effect_factory(root,files)
    if keyword_factory is not None:
        extra['keyword_factory'] = keyword_factory
    outcomes_factory = _customer_outcomes_factory(root,files)
    if outcomes_factory is not None:
        extra['outcomes_factory'] = outcomes_factory
    contacts_factory=_public_contacts_factory(root,files,outcomes_factory)
    if contacts_factory is not None:
        extra['public_contacts_factory']=contacts_factory
    reply_entry = files.get('reply_workbench.py')
    if reply_entry is not None:
        reply_module = importlib.util.module_from_spec(importlib.util.spec_from_loader('fangyu_reply_workbench',loader=None))
        reply_module.__file__ = str(root/reply_entry['path'])
        raw = read_public(root/reply_entry['path'],reply_entry['sha256'],reply_entry['size'])
        exec(compile(raw,reply_module.__file__,'exec'),reply_module.__dict__)
        extra['reply_factory'] = reply_module.ReplyWorkbench
    delivery_entry=files.get('reply_delivery.py')
    if delivery_entry is not None:
        delivery_module=importlib.util.module_from_spec(importlib.util.spec_from_loader('fangyu_reply_delivery',loader=None))
        delivery_module.__file__=str(root/delivery_entry['path'])
        raw=read_public(root/delivery_entry['path'],delivery_entry['sha256'],delivery_entry['size'])
        exec(compile(raw,delivery_module.__file__,'exec'),delivery_module.__dict__)
        extra['delivery_factory']=delivery_module.ReplyDelivery
    dm_entry=files.get('dm_workbench.py')
    if dm_entry is not None:
        dm_module=importlib.util.module_from_spec(importlib.util.spec_from_loader('fangyu_scoped_dm',loader=None))
        dm_module.__file__=str(root/dm_entry['path'])
        dm_raw=read_public(root/dm_entry['path'],dm_entry['sha256'],dm_entry['size'])
        exec(compile(dm_raw,dm_module.__file__,'exec'),dm_module.__dict__)
        extra['dm_factory']=dm_module.DMWorkbench
    platform_entry = files.get('resources/platform-runtime/platform_runtime.py')
    if platform_entry is not None:
        platform_name = 'fangyu_platform_runtime'
        platform_module = importlib.util.module_from_spec(importlib.util.spec_from_loader(platform_name, loader=None))
        platform_module.__file__ = str(root / platform_entry['path'])
        sys.modules[platform_name] = platform_module
        platform_raw = read_public(root / platform_entry['path'], platform_entry['sha256'], platform_entry['size'])
        exec(compile(platform_raw, platform_module.__file__, 'exec'), platform_module.__dict__)
        extra['platform_factory'] = platform_module.PlatformRuntime
        analysis_entry=files.get('resources/platform-runtime/analysis_queue_runtime.py')
        if analysis_entry is not None:
            # Host-provided factory only, loaded from the exact verified manifest.
            analysis_path=root/analysis_entry['path']
            analysis_name='fangyu_analysis_queue_runtime'
            previous=sys.modules.get(analysis_name)
            if previous is not None and Path(previous.__file__).resolve()!=analysis_path.resolve():
                raise UIHostError('已有评论分析组件来源不同，请正常重开。')
            analysis_module=importlib.util.module_from_spec(importlib.util.spec_from_loader(analysis_name,loader=None))
            analysis_module.__file__=str(analysis_path)
            analysis_raw=read_public(analysis_path,analysis_entry['sha256'],analysis_entry['size'])
            exec(compile(analysis_raw,str(analysis_path),'exec'),analysis_module.__dict__)
            sys.modules[analysis_name]=analysis_module
            extra['analysis_factory']=analysis_module.AnalysisQueueRuntime
        index_entry=files.get('resources/customer-read/review-index.json')
        if index_entry is not None and getattr(sys,'frozen',False):
            authority_entry=files.get('resources/platform-runtime/customer_read_distribution.py')
            if authority_entry is None:raise UIHostError('客户读取用途材料不完整。')
            authority_path=root/authority_entry['path']
            authority_name='fangyu_customer_read_distribution'
            authority_module=sys.modules.get(authority_name)
            if authority_module is not None and Path(authority_module.__file__).resolve()!=authority_path.resolve():
                raise UIHostError('已有客户读取用途组件来源不同。')
            authority_raw=read_public(authority_path,authority_entry['sha256'],authority_entry['size'])
            if authority_module is None:
                authority_module=importlib.util.module_from_spec(importlib.util.spec_from_loader(authority_name,loader=None))
                authority_module.__file__=str(authority_path)
                sys.modules[authority_name]=authority_module
                try:exec(compile(authority_raw,str(authority_path),'exec'),authority_module.__dict__)
                except BaseException:
                    sys.modules.pop(authority_name,None);raise
            def read_review_document(name):
                item=files.get(name)
                if item is None:raise UIHostError('客户读取用途材料不完整。')
                return read_public(root/item['path'],item['sha256'],item['size'])
            authority=authority_module.load_authority(project,root,
                read_public(root/index_entry['path'],index_entry['sha256'],index_entry['size']),read_review_document)
            extra['platform_factory']=lambda **kwargs:platform_module.PlatformRuntime(
                **kwargs,customer_read_authority=authority)
    remote_entry = files.get('resources/remote_management.py')
    if remote_entry is not None:
        remote_name = 'fangyu_remote_management'
        remote_module = importlib.util.module_from_spec(importlib.util.spec_from_loader(remote_name,loader=None))
        remote_module.__file__ = str(root/remote_entry['path'])
        remote_raw = read_public(root/remote_entry['path'],remote_entry['sha256'],remote_entry['size'])
        exec(compile(remote_raw,remote_module.__file__,'exec'),remote_module.__dict__)
        extra['remote_factory'] = remote_module.RemoteManagement
    backend=module.WorkbenchBackend(project_root=project, data_dir=data_dir, company=company,
        content_model_adapter=content_model_adapter, publication_factory=publication_factory,
        initialize_customer_revision=True, **extra)
    try:
        live_entry=files.get('resources/livestream/livestream_workbench.py')
        if live_entry is not None:
            live_module=importlib.util.module_from_spec(importlib.util.spec_from_loader('fangyu_live_admission',loader=None))
            live_module.__file__=str(root/live_entry['path'])
            exec(compile(read_public(root/live_entry['path'],live_entry['sha256'],live_entry['size']),live_module.__file__,'exec'),live_module.__dict__)
            backend.livestream_dispatch=live_module.dispatch
        backend.knowledge_file_preview_factory=_knowledge_file_factory(root,files,backend.media_workbench)
        return backend
    except Exception:
        backend.close();raise


class SharedRuntime:
    """One backend instance with stable and editable same-origin HTTP surfaces."""
    def __init__(self, root, files, state_root, *, project_root, release_id,
                 profile='production', source_root=None, assets_root=None,
                 data_dir=None, company=None, backend_factory=None, clock=time.monotonic, startup_gate=None):
        if profile not in ('production', 'fixture') or (profile == 'fixture' and backend_factory is None):
            raise UIHostError('测试运行必须显式提供隔离后台。')
        self.root, self.files = Path(root), files
        self.project = Path(project_root).absolute()
        self.state_root = Path(state_root).absolute()
        self.profile, self.release_id = profile, str(release_id)
        self.instance_id = uuid.uuid4().hex
        self.lifecycle = make_lifecycle_log(self.state_root, self.release_id)
        self.source_root = Path(source_root) if source_root else self.project / 'work/ui-approved-implementation/ui-preview'
        self.assets_root = Path(assets_root) if assets_root else self.project / 'work/ui-runtime-r56/src/web/workspace/assets'
        self.data_dir = production_workspace(self.project, data_dir) if profile == 'production' else data_dir
        self.company = company
        self.backend_factory = backend_factory or (lambda **kwargs: create_backend(self.root, self.files, **kwargs))
        self.clock = clock
        self.startup_gate = startup_gate
        self.api_lock = threading.RLock()
        self.backend = self.stable = self.development = None
        self.threads = []
        self.mutex = None
        self.closed = False
        self.tickets = {}

    def start(self):
        if self.closed or self.backend is not None:
            raise UIHostError('本地服务不能重复启动。')
        self.lifecycle.record('runtime_start', instance_id=self.instance_id)
        try:
            if self.profile == 'production' and os.name == 'nt':
                kernel = ctypes.WinDLL('kernel32', use_last_error=True)
                kernel.CreateMutexW.argtypes = (ctypes.c_void_p, ctypes.c_bool, ctypes.c_wchar_p)
                kernel.CreateMutexW.restype = ctypes.c_void_p
                self.mutex = kernel.CreateMutexW(None, False, 'Local\\Fangyu.Backend.R57.production')
                if not self.mutex or ctypes.get_last_error() == 183:
                    raise UIHostError('方隅真实后台已经运行，请使用当前服务。')
            self.backend = self.backend_factory(project_root=self.project, data_dir=self.data_dir, company=self.company)
            if self.profile == 'production' and self.backend is not None and hasattr(self.backend,'customer_read_store'):
                timing_module=sys.modules.get('customer_read_store')
                if timing_module is None or not callable(getattr(timing_module,'TimingRecorder',None)):
                    raise UIHostError('客户读取诊断组件不完整，请重新固化。')
                diagnostics=create_state_directory(self.state_root/'diagnostics')
                self.backend._local_read_timing=timing_module.TimingRecorder(diagnostics/'customer-read-timing.jsonl')
                self.backend._local_read_timing.attach_control_logger()
                with self.backend._local_read_timing.span('host_attach'):pass
            cookie = SESSION_COOKIE if self.profile == 'production' else SESSION_COOKIE + '_fixture_' + self.instance_id[:12]
            self.stable = StaticServer(self.root, self.files, backend=self.backend, cookie_name=cookie, runtime=self)
            self.development = DevelopmentServer(self.root, self.files, source_root=self.source_root,
                assets_root=self.assets_root, backend=self.backend, cookie_name=cookie, runtime=self)
            if self.startup_gate is not None:
                self.startup_gate(self)
            for server in (self.stable, self.development):
                thread = threading.Thread(target=server.serve_forever, kwargs={'poll_interval': .1}, daemon=True)
                thread.start()
                self.threads.append((server, thread))
            create_state_directory(self.state_root)
            self.write_active()
            self.lifecycle.record('runtime_ready', instance_id=self.instance_id)
            return self
        except Exception as error:
            self.lifecycle.record('runtime_failed', error=error, instance_id=self.instance_id)
            self.close()
            raise

    def write_active(self):
        value = {'schema': 'fangyu-shared-runtime-v1', 'instanceId': self.instance_id,
                 'pid': os.getpid(), 'profile': self.profile, 'mode': 'shared-runtime',
                 'release': self.release_id, 'stablePort': self.stable.server_port,
                 'developmentPort': self.development.server_port}
        target = self.state_root / 'active.json'
        temporary = target.with_name('active.' + uuid.uuid4().hex + '.tmp')
        with temporary.open('x', encoding='utf-8') as stream:
            stream.write(json.dumps(value, ensure_ascii=False, indent=2))
        os.replace(temporary, target)

    def public_status(self, server):
        return {'instanceId': self.instance_id, 'profile': self.profile,
                'mode': server.mode, 'release': self.release_id}

    def _confirmed_employee(self, token):
        if not isinstance(token, str) or not re.fullmatch(r'[A-Za-z0-9_-]{1,256}', token):
            raise RuntimeRequestError('AUTH_REQUIRED', '请先登录员工账号。', 401)
        result = self.backend.dispatch('bootstrap', {}, token=token)
        user = (result.get('session') or {}).get('user') or {}
        if user.get('role') not in ('operator', 'admin'):
            raise RuntimeRequestError('AUTH_REQUIRED', '请先登录有效的员工账号。', 401)
        stores = result.get('stores') or []
        return {'username': user.get('username', ''),
                'storeId': (result.get('selection') or {}).get('storeId', '')}

    def open_development(self, token):
        with self.api_lock:
            actor = self._confirmed_employee(token)
            now = self.clock()
            self.tickets = {key: value for key, value in self.tickets.items() if value[0] > now}
            if len(self.tickets) >= 128:
                raise RuntimeRequestError('TOO_MANY_LINKS', '开发链接较多，请稍后重试。', 429)
            ticket = secrets.token_urlsafe(32)
            self.tickets[ticket] = (now + 30, token)
            return {'developmentURL': 'http://127.0.0.1:' + str(self.development.server_port) +
                    '/__open?ticket=' + ticket, 'expiresIn': 30, 'actor': actor}

    def consume_ticket(self, ticket):
        with self.api_lock:
            if not re.fullmatch(r'[A-Za-z0-9_-]{32,100}', ticket):
                raise RuntimeRequestError('LINK_EXPIRED', '开发链接已失效，请重新打开。', 410)
            value = self.tickets.pop(ticket, None)
            if value is None or value[0] <= self.clock():
                raise RuntimeRequestError('LINK_EXPIRED', '开发链接已失效，请重新打开。', 410)
            self._confirmed_employee(value[1])
            return value[1]

    def close(self):
        if self.closed:
            return
        self.lifecycle.record('shutdown_start', instance_id=self.instance_id)
        self.closed = True
        self.tickets.clear()
        for server, thread in self.threads:
            server.shutdown()
            thread.join(timeout=3)
        for server in (self.stable, self.development):
            if server is not None:
                server.server_close()
        try:
            with self.api_lock:
                if self.backend is not None:
                    self.backend.close()
        finally:
            if self.mutex is not None:
                kernel = ctypes.WinDLL('kernel32', use_last_error=True)
                kernel.CloseHandle.argtypes = (ctypes.c_void_p,)
                kernel.CloseHandle(self.mutex)
                self.mutex = None
            target = self.state_root / 'active.json'
            try:
                if json.loads(target.read_text('utf-8')).get('instanceId') == self.instance_id:
                    target.unlink()
            except (OSError, ValueError):
                pass
        self.lifecycle.record('shutdown_complete', instance_id=self.instance_id)


def http_self_test(root, files):
    """Exercise the real loopback handler; no window or business modules involved."""
    server = StaticServer(root, files)
    worker = threading.Thread(target=server.serve_forever,
                              kwargs={'poll_interval': .05}, daemon=True)
    worker.start()
    checks = []
    def request(method, path, expected, *, headers=None):
        connection = http.client.HTTPConnection('127.0.0.1', server.server_port, timeout=4)
        try:
            connection.request(method, path, headers=headers or {})
            response = connection.getresponse()
            body = response.read()
            assert response.status == expected, (method, path, response.status)
            assert response.getheader('Content-Security-Policy') == CSP
            checks.append({'method': method, 'path': path, 'status': response.status})
            return body
        finally:
            connection.close()
    try:
        body = request('GET', '/', 200)
        assert body == read_public(Path(root) / 'web/index.html')
        request('HEAD', '/app.mjs', 200)
        for path in sorted(server.public):
            request('GET', path, 200)
        request('GET', '/api', 403)
        request('POST', '/api', 403)
        request('PUT', '/index.html', 403)
        request('OPTIONS', '/', 403)
        request('GET', '/RELEASE.json', 404)
        request('GET', '/ui_native_host.py', 404)
        request('GET', '/%2e%2e/RELEASE.json', 403)
        request('GET', '/assets/%2e%2e/%2e%2e/RELEASE.json', 403)
        request('GET', '/', 403, headers={'Host': 'external.invalid'})
        request('GET', '/', 403, headers={'Upgrade': 'websocket'})
        return {'status': 'PASS', 'checks': len(checks), 'public_urls': len(server.public),
                'business_app_imported': 'app' in sys.modules,
                'native_windows_opened': 0, 'requests': checks}
    finally:
        server.shutdown()
        server.server_close()
        worker.join(timeout=3)


def write_status(path: Path, stage: str, **extra):
    # Only lifecycle and public DOM metrics; never form values or customer content.
    value = {'schema': 'fangyu_native_ui_status_v1', 'stage': stage, 'pid': os.getpid(),
             'time_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()), **extra}
    temporary = path.with_suffix('.tmp')
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding='utf-8')
    os.replace(temporary, path)


DOM_PROBE = """(() => {
    const outerDoc = document.documentElement;
    const frame = document.getElementById('workspace-frame');
    const content = frame ? frame.contentDocument : document;
    const contentWindow = frame ? frame.contentWindow : window;
    const doc = content?.documentElement;
    const app = content?.getElementById('app');
    const images = [...(content?.images || [])];
    const page = content?.body?.dataset.page || '';
    const rect = frame?.getBoundingClientRect();
    const viewport = (win, element) => ({width: win?.innerWidth || 0,
        height: win?.innerHeight || 0, client_width: element?.clientWidth || 0,
        client_height: element?.clientHeight || 0, scroll_width: element?.scrollWidth || 0,
        scroll_height: element?.scrollHeight || 0, device_pixel_ratio: win?.devicePixelRatio || 0});
    return {
        page, ready_state: content?.readyState || 'loading',
        app_children: app?.children.length || 0,
        primary_present: !!content?.querySelector(page === 'login' ? '#login-form' : '.shell'),
        font_status: content?.fonts?.status || 'unsupported',
        images: {total: images.length, pending: images.filter(i => !i.complete).length,
                 failed: images.filter(i => i.complete && i.naturalWidth === 0).length},
        viewport: viewport(window, outerDoc),
        content_viewport: viewport(contentWindow, doc),
        fit: frame ? {enabled: true, x: rect.x, y: rect.y, right: rect.right,
            bottom: rect.bottom, width: rect.width, height: rect.height,
            layout_width: frame.offsetWidth, layout_height: frame.offsetHeight,
            scale_x: rect.width / frame.offsetWidth, scale_y: rect.height / frame.offsetHeight,
            covers_viewport: Math.abs(rect.x) <= 1 && Math.abs(rect.y) <= 1
                && Math.abs(rect.right - innerWidth) <= 1
                && Math.abs(rect.bottom - innerHeight) <= 1}
            : {enabled: false}
    };
})()"""


def validate_dom_report(report, expected_page):
    """Validate a read-only WebView2 probe; an HTML load alone is insufficient."""
    if not isinstance(report, dict):
        raise UIHostError('界面渲染状态不可读取。')
    expected_pages = (expected_page,) if isinstance(expected_page, str) else expected_page
    if (report.get('page') not in expected_pages or report.get('app_children', 0) < 1
            or not report.get('primary_present')):
        raise UIHostError('界面模块未完成渲染。')
    if report.get('ready_state') != 'complete' or report.get('font_status') != 'loaded':
        raise UIHostError('界面文档或字体尚未完成加载。')
    images = report.get('images', {})
    if images.get('pending', 1) or images.get('failed', 1):
        raise UIHostError('界面图片尚未完整加载。')
    viewport = report.get('viewport', {})
    if min(viewport.get('width', 0), viewport.get('height', 0)) <= 0:
        raise UIHostError('界面内容尺寸无效。')
    if viewport.get('scroll_width', 0) > viewport['width'] + 1:
        raise UIHostError('界面内容出现横向溢出。')
    fit = report.get('fit', {})
    if fit.get('enabled'):
        numeric = ('x', 'y', 'right', 'bottom', 'width', 'height',
                   'layout_width', 'layout_height', 'scale_x', 'scale_y')
        if any(type(fit.get(key)) not in (int, float)
               or not math.isfinite(fit[key]) for key in numeric):
            raise UIHostError('界面缩放尺寸无效。')
        if (min(fit[key] for key in ('width', 'height', 'layout_width',
                                    'layout_height', 'scale_x', 'scale_y')) <= 0
                or abs(fit['scale_x'] - fit['scale_y']) > .003):
            raise UIHostError('界面未按相同比例缩放。')
        if (fit['x'] < -1 or fit['y'] < -1 or fit['right'] > viewport['width'] + 1
                or fit['bottom'] > viewport['height'] + 1
                or viewport.get('scroll_height', 0) > viewport['height'] + 1):
            raise UIHostError('缩放后的完整界面超出窗口。')
        if (fit.get('covers_viewport') is not True or abs(fit['x']) > 1
                or abs(fit['y']) > 1 or abs(fit['right'] - viewport['width']) > 1
                or abs(fit['bottom'] - viewport['height']) > 1):
            raise UIHostError('界面没有填满当前窗口。')
        content = report.get('content_viewport', {})
        if (min(content.get('width', 0), content.get('height', 0)) <= 0
                or content.get('scroll_width', 0) > content['width'] + 1
                or content.get('scroll_height', 0) > content['height'] + 1):
            raise UIHostError('界面画布仍有未显示的内容。')
    return report


def inspect_native_dom(window, expected_page, timeout=10):
    # pywebview 6.2's loaded handlers run on a worker thread. Keep evaluate_js
    # here, outside native.Invoke/WinForms UI callbacks, so its result can return.
    deadline = time.monotonic() + timeout
    report = None
    while True:
        report = window.evaluate_js(DOM_PROBE)
        try:
            return validate_dom_report(report, expected_page)
        except UIHostError as error:
            if ((isinstance(report, dict) and report.get('images', {}).get('failed', 0))
                    or time.monotonic() >= deadline):
                raise UIHostError(str(error)) from error
            time.sleep(.1)


XLSX_MIME = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'


def _native_download_origin(stable_url):
    parsed = urlsplit(stable_url)
    if (parsed.scheme != 'http' or parsed.hostname != '127.0.0.1'
            or not parsed.port or parsed.netloc != '127.0.0.1:' + str(parsed.port)):
        raise UIHostError('桌面下载来源不是本机稳定界面。')
    return parsed.scheme, parsed.netloc


def _native_same_origin(value, origin):
    try:
        parsed = urlsplit(str(value))
        return (parsed.scheme, parsed.netloc) == origin
    except (TypeError, ValueError):
        return False


def _native_own_blob(value, origin):
    value = str(value)
    if not value.startswith('blob:'):
        return False
    try:
        blob = urlsplit(value[5:])
        return ((blob.scheme, blob.netloc) == origin and not blob.query and not blob.fragment
                and re.fullmatch(r'/[0-9a-fA-F]{8}(?:-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12}', blob.path)
                is not None)
    except ValueError:
        return False


def _native_xlsx_name(value, extension='.xlsx'):
    import ntpath
    name = ntpath.basename(str(value))
    if (not name or len(name) > 180 or name != name.strip()
            or not name.lower().endswith(extension) or name.lower() == extension
            or any(character in '<>:"/\\|?*' or ord(character) < 32
                   or ord(character) == 127 or '\u202a' <= character <= '\u202e'
                   or '\u2066' <= character <= '\u2069' for character in name)
            or name.split('.')[0].upper() in {'CON', 'PRN', 'AUX', 'NUL',
                *(f'COM{number}' for number in range(1, 10)),
                *(f'LPT{number}' for number in range(1, 10))}):
        return None
    return name


def native_navigation_handler(stable_url):
    """Keep navigation on the stable origin; only its UUID blobs may download."""
    origin = _native_download_origin(stable_url)

    def guard(sender, args):
        try:
            target = str(args.Uri)
            if target == 'about:blank' or _native_same_origin(target, origin):
                return
            if (_native_own_blob(target, origin)
                    and _native_same_origin(sender.Source, origin)):
                return
        except Exception:
            pass
        args.Cancel = True
    return guard


def native_xlsx_download_handler(stable_url, owner, winforms):
    """Permit a supported business export only through the native save dialog.

    Reuses pywebview's WinForms SaveFileDialog approach, without changing its
    process-wide ALLOW_DOWNLOADS=False policy. Nothing here writes a file.
    """
    origin = _native_download_origin(stable_url)

    def download(sender, args):
        args.Cancel = True
        args.Handled = True
        dialog = None
        try:
            operation = args.DownloadOperation
            mime=str(operation.MimeType).partition(';')[0].strip().lower()
            formats = {
                XLSX_MIME: ('.xlsx', '保存客户 Excel', 'Excel 工作簿 (*.xlsx)|*.xlsx'),
                'video/mp4': ('.mp4', '保存视频成片', 'MP4 视频 (*.mp4)|*.mp4'),
                'application/json': ('.json', '保存规则 JSON', '规则文件 (*.json)|*.json'),
                'text/html': ('.html', '保存业务说明', '业务说明网页 (*.html)|*.html'),
                'application/vnd.openxmlformats-officedocument.presentationml.presentation':
                    ('.pptx', '保存规则演示', 'PowerPoint 演示文稿 (*.pptx)|*.pptx'),
            }
            selected = formats.get(mime)
            if selected is None:
                return
            extension, title, file_filter = selected
            name = _native_xlsx_name(args.ResultFilePath,extension)
            if (not _native_same_origin(sender.Source, origin)
                    or not _native_own_blob(operation.Uri, origin)
                    or not name):
                return
            dialog = winforms.SaveFileDialog()
            dialog.Title = title
            dialog.Filter = file_filter
            dialog.DefaultExt = extension[1:]
            dialog.AddExtension = True
            dialog.CheckPathExists = True
            dialog.ValidateNames = True
            dialog.OverwritePrompt = True
            dialog.RestoreDirectory = True
            dialog.FileName = name
            if dialog.ShowDialog(owner) != winforms.DialogResult.OK:
                return
            import ntpath
            chosen = str(dialog.FileName)
            drive, tail = ntpath.splitdrive(chosen)
            if (not drive or not ntpath.isabs(chosen) or ':' in tail
                    or not _native_xlsx_name(chosen,extension)):
                return
            args.ResultFilePath = chosen
            args.Cancel = False
        except Exception:
            # Cancellation is the only safe fallback; never use a browser default.
            args.Cancel = True
        finally:
            if dialog is not None:
                try:
                    dialog.Dispose()
                except Exception:
                    args.Cancel = True
    return download


def attach_native_download_policy(window, stable_url, *, winforms=None):
    """Run on WinForms UI thread after CoreWebView2 has initialized."""
    if winforms is None:
        from webview.platforms.edgechromium import WinForms as winforms
    browser = window.native.browser
    core = browser.webview.CoreWebView2
    download = native_xlsx_download_handler(stable_url, browser.form, winforms)
    navigation = native_navigation_handler(stable_url)
    # Fail closed if the installed pywebview event binding cannot be replaced.
    core.DownloadStarting.__iadd__(download)
    default_removed = False
    try:
        core.DownloadStarting.__isub__(browser.on_download_starting)
        default_removed = True
        browser.webview.NavigationStarting.__iadd__(navigation)
    except Exception as error:
        if default_removed:
            core.DownloadStarting.__iadd__(browser.on_download_starting)
        core.DownloadStarting.__isub__(download)
        raise UIHostError('无法准备桌面 Excel 保存入口。') from error
    # Keep Python delegates alive for this window only.
    window._fangyu_ui_download_handler = download
    window._fangyu_ui_navigation_guard = navigation
    return True


def attach_native_lifecycle(window, lifecycle):
    """Use the available public WebView2 event; never inspect descriptions."""
    try:
        core = window.native.browser.webview.CoreWebView2
        def failed(sender, args):
            try:
                kind = str(getattr(args, 'ProcessFailedKind', ''))
                code = getattr(args, 'ExitCode', None)
                if code is not None:
                    code = int(code)
                lifecycle.record('native_process_failed', kind=kind, exit_code=code)
            except Exception:
                pass
        core.ProcessFailed.__iadd__(failed)
        window._fangyu_ui_process_failed_handler = failed
        return True
    except Exception:
        lifecycle.record('native_diagnostic_unavailable')
        return False


def native_window(root, files, state_root, initial_page='login', *, project_root, release_id, data_dir=None, startup_gate=None):
    lifecycle = make_lifecycle_log(state_root, release_id)
    lifecycle.record('native_opening')
    import webview
    state_root = create_state_directory(state_root)
    storage = create_state_directory(state_root / 'webview2')
    logs = create_state_directory(state_root / 'launches')
    status_path = logs / (uuid.uuid4().hex + '.json')
    write_status(status_path, 'verified')
    mutex = None
    if os.name == 'nt':
        kernel = ctypes.WinDLL('kernel32', use_last_error=True)
        kernel.CreateMutexW.argtypes = (ctypes.c_void_p, ctypes.c_bool, ctypes.c_wchar_p)
        kernel.CreateMutexW.restype = ctypes.c_void_p
        mutex = kernel.CreateMutexW(None, False, 'Local\\Fangyu.UIReview.R57')
        if not mutex:
            raise UIHostError('无法准备界面窗口，请稍后重试。')
        if ctypes.get_last_error() == 183:
            kernel.CloseHandle.argtypes = (ctypes.c_void_p,)
            kernel.CloseHandle(mutex)
            raise UIHostError('方隅新界面已经打开，请查看已有窗口。')
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID('Fangyu.Workbench.UIReview.R57')
    server = None
    backend = None
    runtime = None
    try:
        runtime = SharedRuntime(root, files, state_root, project_root=project_root,
                                release_id=release_id, data_dir=data_dir, startup_gate=startup_gate).start()
        server, backend = runtime.stable, runtime.backend
        url = 'http://127.0.0.1:' + str(server.server_port) + '/#' + initial_page
        window = webview.create_window('方隅工作台', url=url, width=1440, height=960,
            min_size=(720, 480), background_color='#F2FAFB', text_select=True, zoomable=False, maximized=True)
        accepted = {'renderer': False, 'loaded': False, 'error': None, 'dom': None}

        def initialized(renderer):
            accepted['renderer'] = renderer == 'edgechromium'
            return accepted['renderer']

        def loaded():
            if accepted['loaded'] or accepted['error']:
                return
            try:
                if not accepted['renderer']:
                    raise UIHostError('需要 WebView2 桌面运行时。')
                from System import Action
                def attach():
                    attach_native_download_policy(window, url)
                    attach_native_lifecycle(window, lifecycle)
                window.native.Invoke(Action(attach))
                accepted['dom'] = inspect_native_dom(window,
                    ('login', 'acquire', 'reply', 'customers', 'presets', 'accounts') if backend else initial_page)
                if accepted['error']:
                    raise accepted['error']
                accepted['loaded'] = True
                lifecycle.record('native_ready', instance_id=runtime.instance_id)
                write_status(status_path, 'native_ready', port=server.server_port,
                             development_port=runtime.development.server_port,
                             instance_id=runtime.instance_id, release_id=release_id,
                             renderer='edgechromium', dom=accepted['dom'],
                             native_xlsx_download='guarded_save_dialog',
                             business_connected=backend is not None,
                             connected_features=['employee_login', 'store_presets', 'platform_accounts', 'collection', 'customers', 'customer_export', 'reply_drafts', 'reply_review', 'explicit_reply_delivery', 'reviewed_reply_batch', 'reply_delivery_status_cancel', 'customer_internal_handoff'] if backend else [])
            except Exception as error:
                lifecycle.record('native_failed', error=error, instance_id=runtime.instance_id)
                accepted['error'] = error
                window.destroy()

        window.events.initialized += initialized
        window.events.loaded += loaded
        webview.settings['ALLOW_DOWNLOADS'] = False
        write_status(status_path, 'opening', port=server.server_port,
                     development_port=runtime.development.server_port,
                     instance_id=runtime.instance_id, release_id=release_id)
        startup_finished = threading.Event()
        def startup_monitor():
            if not startup_finished.wait(45) and not accepted['loaded']:
                lifecycle.record('startup_timeout', instance_id=runtime.instance_id)
                accepted['error'] = UIHostError('界面加载超时，请关闭后重新打开。')
                try:
                    window.destroy()
                except Exception:
                    pass
        watchdog = threading.Thread(target=startup_monitor, daemon=True)
        watchdog.start()
        icon = root / 'resources' / 'brand.ico'
        try:
            webview.start(gui='edgechromium', debug=False, private_mode=False,
                          storage_path=str(storage), icon=str(icon) if icon.is_file() else None)
        finally:
            startup_finished.set()
        if accepted['error']:
            raise accepted['error']
        if not accepted['renderer'] or not accepted['loaded']:
            raise UIHostError('WebView2 窗口未完成加载，请确认桌面运行时可用。')
        write_status(status_path, 'closed', requests=server.counters,
                     renderer='edgechromium', dom=accepted['dom'],
                     business_connected=backend is not None,
                     connected_features=['employee_login', 'store_presets', 'platform_accounts', 'collection', 'customers', 'customer_export', 'reply_drafts', 'reply_review', 'explicit_reply_delivery', 'reviewed_reply_batch', 'reply_delivery_status_cancel', 'customer_internal_handoff'] if backend else [])
        lifecycle.record('native_closed', instance_id=runtime.instance_id)
        return 0
    except Exception as error:
        lifecycle.record('native_failed', error=error,
                         instance_id=runtime.instance_id if runtime is not None else '')
        write_status(status_path, 'failed', error_type=type(error).__name__,
                     error=str(error) if isinstance(error, UIHostError) else None)
        raise
    finally:
        if runtime is not None:
            runtime.close()
        if mutex is not None:
            kernel.CloseHandle.argtypes = (ctypes.c_void_p,)
            kernel.CloseHandle(mutex)


def serve_runtime(root, files, state_root, *, project_root, release_id, stop_event=None, **kwargs):
    """Headless lifecycle for the same backend and two UI surfaces."""
    runtime = SharedRuntime(root, files, state_root, project_root=project_root,
                            release_id=release_id, **kwargs).start()
    try:
        print(json.dumps({'status': 'running', **runtime.public_status(runtime.stable),
                          'stableURL': 'http://127.0.0.1:' + str(runtime.stable.server_port) + '/',
                          'developmentURL': 'http://127.0.0.1:' + str(runtime.development.server_port) + '/'}, ensure_ascii=False), flush=True)
        try:
            (stop_event or threading.Event()).wait()
        except KeyboardInterrupt:
            pass
        return 0
    finally:
        runtime.close()


def main(release_root, manifest_sha256, state_root, argv=None, *, project_root=None, data_dir=None, startup_gate=None):
    parser = argparse.ArgumentParser(description='方隅工作台本地界面')
    parser.add_argument('--check', action='store_true', help='仅核验资源和原生依赖，不打开窗口')
    parser.add_argument('--self-test', action='store_true', help='核验静态HTTP及业务隔离，不打开窗口')
    parser.add_argument('--serve', action='store_true', help='仅运行同一真实后台与网页服务，不打开桌面窗口')
    parser.add_argument('--project-root', help='明确指定本客户项目根目录')
    parser.add_argument('--page', choices=('login', 'acquire', 'reply', 'customers', 'presets', 'rules', 'tone', 'accounts'), default='login')
    options = parser.parse_args(argv)
    manifest, files = verify_release(Path(release_root), manifest_sha256)
    lifecycle = make_lifecycle_log(state_root, manifest['release_id'], hooks=True)
    lifecycle.record('host_start')
    project = Path(options.project_root).absolute() if options.project_root else (Path(project_root).absolute() if project_root else None)
    if 'workbench_backend.py' in files:
        if project is None:
            raise UIHostError('启动器需明确指定方隅客户项目目录。')
        verify_backend_dependencies(Path(release_root), files, project)
    lifecycle.record('host_verified')
    if options.self_test:
        print(json.dumps(http_self_test(Path(release_root), files), ensure_ascii=False))
        return 0
    if options.check:
        import webview
        report = {'status': 'PASS', 'release_id': manifest['release_id'], 'files': len(files),
                  'webview_version': importlib.metadata.version('pywebview'),
                  'native_windows_opened': 0, 'business_app_imported': False}
        print(json.dumps(report, ensure_ascii=False))
        return 0
    if project is None:
        raise UIHostError('桌面启动器需明确指定方隅客户项目目录。')
    try:
        data_dir = production_workspace(project, data_dir)
        lifecycle.record('workspace_bound')
        if options.serve:
            return serve_runtime(Path(release_root), files, Path(state_root), project_root=project,
                                 release_id=manifest['release_id'], data_dir=data_dir, startup_gate=startup_gate)
        return native_window(Path(release_root), files, Path(state_root), options.page,
                             project_root=project, release_id=manifest['release_id'], data_dir=data_dir, startup_gate=startup_gate)
    except Exception as error:
        lifecycle.record('runtime_failed', error=error)
        raise


def notify_error(error):
    message = str(error) if isinstance(error, UIHostError) else '界面未能启动，请查看本版本的启动状态。'
    if os.name == 'nt':
        ctypes.windll.user32.MessageBoxW(None, message, '方隅工作台 · 打开提示', 0x10)
    else:
        print(message, file=sys.stderr)
