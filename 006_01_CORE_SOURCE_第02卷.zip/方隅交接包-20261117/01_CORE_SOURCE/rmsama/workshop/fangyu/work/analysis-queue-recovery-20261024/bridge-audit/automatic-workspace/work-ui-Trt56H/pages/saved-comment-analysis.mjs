// The trusted backend owns automatic work. Rendering and polling only read it.
const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const num=v=>Number.isSafeInteger(v)&&v>=0;
const phases={workspace_scan:'检查已保存评论',workspace_authorization:'核对后台分析授权',workspace_connect:'连接已有工作台',scope_check:'核对账号与门店',original_request_status:'核对原分析记录',ai_profile:'读取企业分析配置',intent_analyze:'分析评论意向',ai_attempt_status:'核对本批结果'};
const reasons={AI_DAILY_BUDGET:'今日AI预算已用完，自动分析已暂停，原评论保留。',AI_PROVIDER_BALANCE:'企业AI余额不足，原评论保留，请管理员处理后恢复。',AI_NOT_CONFIGURED:'企业AI尚未配置，原评论已保留。',AI_DISABLED:'企业AI已暂停，原评论已保留。',AI_PROVIDER_AUTH:'企业AI认证未通过，请管理员核对配置。',AI_PROVIDER_TIMEOUT:'原分析请求超时，结果待核，暂不重复提交。',PRODUCT_REQUEST_UNKNOWN:'原分析结果尚未核实，本批已暂停以免重复提交。',ANALYSIS_DEVICE_UNAVAILABLE:'当前员工的电脑绑定尚未核实，原评论保留。',ANALYSIS_RUNTIME_REQUIRED:'分析工作连接尚未就绪，原评论保留。',ANALYSIS_PERMISSION_DENIED:'当前员工没有分析权限，原评论保留。',ANALYSIS_FORBIDDEN:'当前员工的分析权限已撤销，原评论保留。',ANALYSIS_AUTH_CHANGED:'员工或设备授权已变化，自动分析已停止。',ANALYSIS_SCOPE_CHANGED:'当前门店或原任务范围已变化，自动分析已停止。'};
function scope(s){
  if(s.connection!=='connected'||s.page!=='acquire'||!s.session||!s.user||!s.storeId)return null;
  return {key:JSON.stringify(['workspace',s.authEpoch||0,s.session.user?.tenant_id,s.user,s.session.user?.role,s.storeId]),storeId:s.storeId};
}
function model(s){
  const target=scope(s);if(!target)return null;
  if(s.savedCommentAnalysis?.key!==target.key)s.savedCommentAnalysis={...target,value:null,busy:false,error:'',uncertain:false,lastRead:0};
  return s.savedCommentAnalysis;
}
function displayValue(v){
  if(!v)return null;
  const processing=v.processing||0;
  return {...v,processing,counts:{...v.counts,pending:v.counts.pending+processing,held:v.counts.held-processing}};
}
export function savedCommentAnalysisView(s){const target=scope(s),u=s.savedCommentAnalysis;return target&&u?.key===target.key?displayValue(u.value):null;}
function content(u){
  const v=displayValue(u.value),c=v?.counts,disabled=u.busy?'disabled':'';
  const blocked=Boolean(v&&!v.running&&!v.autoPaused&&(v.status==='blocked'||v.code));
  const status=u.error?'自动分析状态待核对':!v?'正在读取自动分析状态':v.autoPaused?'自动分析已暂停':blocked?'自动分析异常暂停':v.running?'正在处理已保存评论':c.pending===0?(c.held||c.missingText?'可分析队列已清空':'已清空'):'自动分析已开启';
  const resume=Boolean(v?.canResume&&(v.autoPaused||blocked||v.autoEnabled===false));
  const counts=c?`<span>${u.error?'上次核对 · ':''}待分析 ${c.pending} 条${v.processing?`（其中分析中 ${v.processing} 条）`:''}</span><span>原请求待核 ${c.held} 条</span><span>缺正文 ${c.missingText} 条</span><span>已分析 ${c.analyzed} 条</span>`:'<span>登录后自动处理当前门店中本人的已保存评论</span>';
  const note=u.error||reasons[v?.code]||v?.message||'后台队列由工作台登录授权，切换回复或客户页面仍会继续。';
  return `<div><strong>${esc(status)}</strong>${counts}${v?.phase&&phases[v.phase]?`<small>${u.error?'上次阶段':'当前阶段'}：${esc(phases[v.phase])}</small>`:''}<small role="${u.error||blocked?'alert':'status'}" aria-live="polite">${esc(note)}</small></div><div>${resume?`<button type="button" data-analysis-resume ${disabled||u.uncertain?'disabled':''}>恢复自动分析</button>`:v?.canPause?`<button type="button" data-analysis-pause ${disabled||u.uncertain?'disabled':''}>暂停自动分析</button>`:''}<button type="button" data-analysis-read ${disabled}>${u.busy?'正在核对…':'刷新分析状态'}</button></div>`;
}
export function renderSavedCommentAnalysis(s){const u=model(s);return u?`<div class="as-source-bar" data-saved-analysis-panel aria-label="本店后台自动分析">${content(u)}</div>`:'';}
export function analysisBufferMessage(s,live){
  if(live?.platformError?.category||!['paused','blocked','held','stopped'].includes(live?.status)||!/待分析.{0,12}200|200\s*条(?:上限|暂停|缓冲)|ANALYSIS_BACKLOG_LIMIT|analysis_backlog/.test([live.message,live.reasonCode,live.stopReason].join(' ')))return '';
  const v=savedCommentAnalysisView(s);
  if(v?.autoPaused)return '待分析缓冲达到200条，仅暂停采集；自动分析已由本人暂停，可在上方恢复。';
  if(v?.status==='blocked')return '待分析缓冲达到200条，仅限制继续采集；后台分析异常原因已显示在上方，原评论保留。';
  return v?.autoEnabled?'待分析缓冲达到200条，仅暂停采集，后台分析继续；已保存评论会按队列处理。':'待分析缓冲达到200条，仅限制继续采集；后台分析状态正在读取。';
}
function validate(s,u,v){
  if(!v||v.actor?.username!==s.user||v.actor.storeId!==u.storeId||v.taskId!=='workspace'
      ||!['idle','starting','scanning','waiting','running','paused','held','completed','blocked'].includes(v.status)||typeof v.running!=='boolean'
      ||typeof v.autoEnabled!=='boolean'||typeof v.autoPaused!=='boolean'||typeof v.canPause!=='boolean'||typeof v.canResume!=='boolean'
      ||!v.counts||!['total','pending','held','analyzed','missingText'].every(k=>num(v.counts[k]))
      ||!num(v.processing??0)||(v.processing||0)>v.counts.held
      ||v.remaining!==undefined&&(!num(v.remaining)||v.remaining!==v.counts.pending+(v.processing||0))
      ||v.counts.total!==v.counts.pending+v.counts.held+v.counts.analyzed+v.counts.missingText)
    throw Error('当前员工与门店的自动分析状态尚未核实，请重新读取。');
  return v;
}
export function bindSavedCommentAnalysis(root,ctx){
  const s=ctx.state,u=model(s),panel=root.querySelector('[data-saved-analysis-panel]');
  if(!u||!panel||typeof ctx.analysisQueueAction!=='function')return ()=>{};
  let closed=false,timer=null;
  const sameScope=()=>scope(s)?.key===u.key&&s.savedCommentAnalysis===u;
  const valid=()=>!closed&&panel.isConnected&&sameScope();
  const paint=()=>{if(valid()){panel.innerHTML=content(u);bind();}};
  const schedule=()=>{clearTimeout(timer);if(valid())timer=setTimeout(()=>void perform('analysis_workspace_read'),u.value?.running?3000:10000);};
  function perform(action){
    if(!valid()||u.busy||action!=='analysis_workspace_read'&&u.uncertain)return Promise.resolve(false);
    u.busy=true;u.error='';paint();
    const operation={action,promise:null};u.operation=operation;
    operation.promise=(async()=>{try{
      const result=await ctx.analysisQueueAction(action,{storeId:u.storeId});
      if(!sameScope())return false;
      u.value=validate(s,u,result.analysisQueue);u.uncertain=false;u.lastRead=Date.now();return true;
    }catch(error){
      if(sameScope()){u.error=error?.message||'自动分析状态暂不可读，原评论已保留。';if(action!=='analysis_workspace_read')u.uncertain=true;}
      return false;
    }finally{if(u.operation===operation){u.busy=false;delete u.operation;}if(sameScope()){u.repaint?.();u.reschedule?.();}}})();
    return operation.promise;
  }
  function bind(){
    panel.querySelector('[data-analysis-read]')?.addEventListener('click',()=>void perform('analysis_workspace_read'));
    panel.querySelector('[data-analysis-pause]')?.addEventListener('click',()=>void perform('analysis_workspace_pause'));
    panel.querySelector('[data-analysis-resume]')?.addEventListener('click',()=>void perform('analysis_workspace_resume'));
  }
  u.repaint=paint;u.reschedule=schedule;
  bind();if(!u.busy&&Date.now()-u.lastRead>2000)void perform('analysis_workspace_read');else schedule();
  return ()=>{closed=true;clearTimeout(timer);if(u.repaint===paint){delete u.repaint;delete u.reschedule;}};
}
