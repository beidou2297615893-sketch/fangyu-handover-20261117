// Display public account identity; sending still binds the immutable account ID.
export function senderName(account){
  if(!account)return '尚未选择';
  const nickname=String(account.platformNickname||account.platform_nickname||account.name||'昵称未读取').trim();
  const remark=String(account.remarks||'').trim();
  return remark&&remark!==nickname?`${nickname}（${remark}）`:nickname;
}
export function batchAccounts(state,v){
  const platform=state.activePlatform||'xiaohongshu';
  const accounts=state.platform?.accounts;
  if(Array.isArray(accounts))return accounts.filter(a=>a.platform===platform&&['ready','connected','online'].includes(a.status));
  return (v.detail?.comments?.find(r=>r.id===v.leadId)?.accounts||[]).filter(a=>!a.platform||a.platform===platform);
}
