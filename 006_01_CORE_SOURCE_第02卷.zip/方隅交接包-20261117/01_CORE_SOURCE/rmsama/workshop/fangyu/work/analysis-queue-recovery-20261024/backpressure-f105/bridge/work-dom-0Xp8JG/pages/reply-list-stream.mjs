// Local-history paging only: no platform collection or sending is triggered.
const actor=s=>JSON.stringify([s.authEpoch||0,s.user,s.storeId,s.activePlatform]);
const filter=v=>JSON.stringify([v.query,v.tab,v.intent||'all',v.review||'all',v.groupBy]);
export async function loadMoreReplies(state,ctx,v){
  if(v.status!=='ready'||v.refreshing||v.loadingMore||v.page>=(v.pages||0)||v.busy||v.pending||v.batchBusy||v.batchPending)return;
  const origin=actor(state),generation=v.generation,query=filter(v),token={};
  const same=()=>state.replyLive===v&&actor(state)===origin&&state.connection==='connected'&&Boolean(state.session);
  const owns=()=>same()&&v.generation===generation&&filter(v)===query;
  const redraw=()=>{if(same()&&state.page==='reply')ctx.update(()=>{});};
  v.streamRequest=token;v.loadingMore=true;v.listError='';redraw();
  try{
    const result=await ctx.replyCustomers({query:v.query,filter:v.tab,sort:v.groupBy,page:v.page+1,pageSize:50,audience:'all',intent:v.intent||'all',review:'all'});
    if(!owns())return;
    const data=result.customers;
    if(data?.actor?.username!==state.user||data?.actor?.storeId!==state.storeId)throw Error('客户范围已变化，请重新读取。');
    if(!Array.isArray(data.items)||!Number.isSafeInteger(data.page)||data.page<=v.page)throw Error('后续客户暂未确认，请刷新列表。');
    v.items=[...new Map([...v.items,...data.items].map(row=>[row.id,row])).values()];
    v.page=data.page;v.pages=data.pages;v.total=data.total;v.stats=data.stats;
  }catch(error){if(owns()){v.listError=error.message;v.autoFillBudget=0;v.readUnavailable=true;if(v.detail)v.detailSnapshot=true;if(error.code==='AUTH_REQUIRED')ctx.replyError(error);}}
  finally{if(v.streamRequest===token){v.loadingMore=false;v.streamRequest=null;redraw();}}
}
export function bindReplyStream(root,ctx,v){
  const state=ctx.state,list=root.querySelector('[data-live-list]');
  root.querySelector('[data-live-more]')?.addEventListener('click',()=>{v.autoFillBudget=3;loadMoreReplies(state,ctx,v);});
  if(!list)return;
  list.scrollTop=v.listScrollTop||0;
  list.addEventListener('scroll',()=>{
    v.listScrollTop=list.scrollTop;
    if(list.scrollHeight-list.scrollTop-list.clientHeight<100)loadMoreReplies(state,ctx,v);
  },{passive:true});
  requestAnimationFrame(()=>{
    if(state.replyLive===v&&state.page==='reply'&&list.isConnected&&!v.listError&&v.autoFillBudget>0&&list.scrollHeight<=list.clientHeight+4){
      v.autoFillBudget--;loadMoreReplies(state,ctx,v);
    }
  });
}
