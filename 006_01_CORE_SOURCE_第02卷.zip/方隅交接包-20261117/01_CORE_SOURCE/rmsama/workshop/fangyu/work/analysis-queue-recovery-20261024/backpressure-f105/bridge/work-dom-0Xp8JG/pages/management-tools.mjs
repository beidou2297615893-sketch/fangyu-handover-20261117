import {openRuleFiles,openCentralRuleFiles} from './rule-files.mjs';
export {openRuleFiles,openCentralRuleFiles};
import {sopText, personaChoices} from './management-tone.mjs';
const esc=value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const scope=s=>JSON.stringify([s.authEpoch||0,s.connection,s.user,s.storeId||'',s.activePlatform||'xiaohongshu']);
const matches=(s,value)=>value?.actor?.username===s.user&&value?.actor?.storeId===s.storeId;
function target(ctx){
  const s=ctx.state,v=s.replyLive,row=v?.detail?.comments?.find(r=>r.id===v.leadId);
  const locked=['sending','unknown','sent','copied','superseded'];
  const delivery=s.replyDelivery,deliveryRow=delivery?.plan?.items?.find(r=>r.leadId===v?.leadId);
  if(s.connection!=='connected'||!s.session||s.session.user?.username!==s.user||!['admin','operator'].includes(s.session.user?.role)||s.page!=='reply'||s.busy||ctx.hasUnconfirmed?.()
      ||!s.storeId||v?.actor!==`${s.authEpoch||0}|${s.user}|${s.storeId||''}|${s.activePlatform||'xiaohongshu'}`||v.status!=='ready'||v.busy||v.pending||v.detailLoading
      ||!matches(s,v.detail)||v.detail.customerId!==v.selectedId||!v.selectedId||!v.leadId||!row?.canSave||locked.includes(row.draft?.status)
      ||delivery?.busy||delivery?.attempt||deliveryRow&&(locked.includes(deliveryRow.status)||['running','awaiting_collection','authorization_expired'].includes(delivery.plan.state)))return null;
  return {view:v,scope:scope(s),customerId:v.selectedId,leadId:v.leadId,generation:v.generation,sourceDigest:row.sourceDigest,
    replyId:row.draft?.id||'',version:row.draft?.version||0,text:v.text,dirty:Boolean(v.dirty),name:v.detail.item?.name||'客户',comment:row.text};
}
function sameTarget(ctx,expected){const current=target(ctx);return current&&expected&&current.view===expected.view&&['scope','customerId','leadId','generation','sourceDigest','replyId','version','text','dirty'].every(k=>current[k]===expected[k]);}
function own(ctx,h){return ctx.state.toneTool===h&&scope(ctx.state)===h.scope&&h.dialog?.open!==false&&h.owner===h.dialog?.__modalOwner;}
export async function openToneTools(ctx){
  const openingScope=scope(ctx.state);
  if(ctx.state.connection==='connected'&&ctx.state.storeId&&ctx.readTonePreferences){
    const result=await ctx.readTonePreferences();
    if(openingScope!==scope(ctx.state))return;
    if(!result&&ctx.state.tonePreferencesError){ctx.toast(ctx.state.tonePreferencesError);return;}
  }
  const prefs=matches(ctx.state,ctx.state.tonePreferences)?ctx.state.tonePreferences:{};
  const h={scope:scope(ctx.state),target:target(ctx),preview:''};ctx.state.toneTool=h;
  const dialog=ctx.modal({title:'选择回复 SOP',html:`<div class="sop-picker"><label>回复方式<select data-tone-choice>${Object.entries(personaChoices).map(([key,label])=>`<option value="${key}">${label}</option>`).join('')}</select></label><textarea data-tone-text readonly rows="6" aria-label="SOP正文"></textarea><p role="status" data-tone-feedback></p><div class="rp-editor-actions"><button type="button" class="rp-secondary" data-tone-copy disabled>复制</button><button type="button" class="rp-primary" data-tone-apply disabled>填入草稿</button></div></div>`});
  h.dialog=dialog;h.owner=dialog?.__modalOwner;
  const field=key=>dialog?.querySelector(`[data-tone-${key}]`),feedback=text=>{const element=field('feedback');if(element)element.textContent=text;};
  const preview=()=>{if(!own(ctx,h))return;try{h.preview=sopText(prefs,field('choice')?.value);field('text').value=h.preview;field('copy').disabled=false;field('apply').disabled=!sameTarget(ctx,h.target);feedback(h.target?'':'请先选择需要回复的评论。');}catch(error){h.preview='';field('text').value='';field('copy').disabled=true;field('apply').disabled=true;feedback(error.message);}};
  field('choice')?.addEventListener('change',preview);preview();
  field('copy')?.addEventListener('click',async()=>{if(!own(ctx,h)||!h.preview)return;try{await (ctx.copyText?ctx.copyText(h.preview):globalThis.navigator.clipboard.writeText(h.preview));if(own(ctx,h))feedback('完整话术已复制，未保存或发送。');}catch{if(own(ctx,h)){field('text')?.select();feedback('请手动复制已选中的完整话术。');}}});
  field('target')?.addEventListener('click',()=>{if(!own(ctx,h))return;dialog.close();ctx.navigate('reply');});
  field('apply')?.addEventListener('click',()=>{
    if(!own(ctx,h)||!h.preview||!sameTarget(ctx,h.target)){feedback('目标或草稿状态已变化，请重新选择当前原评论。');return;}
    const text=h.preview,expected=h.target;
    const apply=()=>{
      if(!own(ctx,h)||!sameTarget(ctx,expected)){ctx.toast('当前员工、门店、原评论或草稿状态已变化，本次未应用。');return false;}
      const editor=ctx.replyEditor?.();if(!editor||editor.disabled||editor.readOnly||editor.value!==expected.text){ctx.toast('当前回复编辑框不可写，本次未应用。');return false;}
      editor.value=text;editor.dispatchEvent(new Event('input',{bubbles:true}));
      if(ctx.state.replyLive?.text!==text){ctx.toast('编辑框未接收文字，请保留预览后重新选择。');return false;}
      ctx.toast('已填入草稿。');dialog.close();return true;
    };
    if(!expected.text.trim()){apply();return;}
    const confirm=ctx.modal({title:'替换当前草稿？',html:`<blockquote style="white-space:pre-wrap">${esc(text)}</blockquote>`,confirmLabel:'替换草稿',onConfirm:apply});h.dialog=confirm;h.owner=confirm?.__modalOwner;
  });
}

export function localDates(now=new Date()){
  const iso=[now.getFullYear(),String(now.getMonth()+1).padStart(2,'0'),String(now.getDate()).padStart(2,'0')].join('-');
  const day=['日','一','二','三','四','五','六'][now.getDay()];
  return {iso,long:`${now.getFullYear()}年${now.getMonth()+1}月${now.getDate()}日　星期${day}`,short:`${iso}　周${day}`};
}
export function versionLabel(state,full=false){
  if(state.connection==='preview')return '界面预览 · 无运行版本';
  const metadata=state.runtimeMetadata;
  if(metadata?.status!=='ready')return metadata?.status==='error'?'运行版本未核对':'运行版本待读取';
  const value=metadata.value,label=value.profile==='fixture'?'隔离测试':value.mode==='development'?'开发界面':'稳定界面';
  return `${label} · ${full?value.release:value.release.split('-').at(-1)}`;
}
function settingsHtml(state,h){
  const preview=state.connection==='preview',user=state.session?.user,platform=matches(state,state.platform)?state.platform:null;
  const store=(state.stores||[]).find(r=>r.id===state.storeId),device=platform?.device;
  const deviceLabel={unbound:'未绑定',pending:'待确认',binding:'连接中',offline:'离线',online:'企业连接已确认',held:'安全暂停',revoked:'授权已撤回',error:'连接未完成',stopped:'连接已停止',other_owner:'其他员工绑定'};
  return `<div style="max-height:55vh;overflow:auto;overflow-wrap:anywhere"><p role="status">${esc(h.message||'')}</p>${preview?'<p>当前为界面预览，没有真实员工、门店或设备回执。</p>':`<dl><dt>当前员工</dt><dd>${esc(user?.username===state.user?user.username:'身份尚未核对')}</dd><dt>已分配门店</dt><dd>${esc(store?store.name+' · '+store.id:'门店尚未分配或待核对')}</dd></dl>${state.workspaceError||state.workspaceRefreshError?`<p role="alert">${esc(state.workspaceRefreshError||state.workspaceError?.message)}</p>`:''}<p>设备：${esc(device?deviceLabel[device.state]||'状态待核对':'状态待读取')}</p><p>${esc(state.platformError||device?.message||'尚未取得当前员工门店的设备回执。')}</p>${state.platformError&&platform?'<p>下列为上次已读取的状态，本次刷新未确认。</p>':''}${(platform?.platforms||[]).map(row=>`<section><h3>${esc(row.name||row.id)}</h3><p>${row.enabled?'企业已开通':'企业未开通'} · ${esc(row.status||'状态未记录')}</p><p>${esc(row.message||'状态说明未提供')}</p>${row.reasonCode?`<p>原因：${esc(row.reasonCode)}</p>`:''}</section>`).join('')}`}
    <p>运行版本：${esc(versionLabel(state,true))}</p>${state.runtimeMetadata?.status==='error'?`<p role="alert">${esc(state.runtimeMetadata.error)}</p>`:''}<p>本机日期：${esc(localDates().long)}</p><div class="rp-editor-actions"><button type="button" class="rp-secondary" data-settings-workspace ${preview||h.busy?'disabled':''}>刷新员工与门店资料</button><button type="button" class="rp-secondary" data-settings-platform ${preview||h.busy?'disabled':''}>刷新设备与平台状态</button><button type="button" class="rp-secondary" data-settings-version ${preview||h.busy?'disabled':''}>刷新运行版本</button>${!preview&&user?.role==='admin'?'<button type="button" class="rp-secondary" data-settings-rule-files>管理员规则文件</button>':''}<button type="button" class="rp-secondary" data-settings-accounts ${h.busy?'disabled':''}>前往平台账号</button><button type="button" class="rp-secondary" data-settings-logout ${preview||h.busy||!user?'disabled':''}>退出登录</button></div></div>`;
}
export function openSettings(ctx){
  const h={scope:scope(ctx.state),busy:false,message:''};ctx.state.settingsTool=h;
  const current=()=>ctx.state.settingsTool===h&&scope(ctx.state)===h.scope&&h.dialog?.open!==false&&h.owner===h.dialog?.__modalOwner;
  const show=()=>{
    if(ctx.state.settingsTool!==h||scope(ctx.state)!==h.scope)return;
    const dialog=ctx.modal({title:'工作台设置与真实状态',html:settingsHtml(ctx.state,h)});h.dialog=dialog;h.owner=dialog?.__modalOwner;
    const run=async(action,name)=>{
      if(!current()||h.busy||ctx.state.connection==='preview'||typeof action!=='function')return;
      h.busy=true;h.message='正在'+name+'…';show();
      try{const result=await action();if(current())h.message=result===false||result===null?name+'未确认，请保留上次状态并重试。':'已完成'+name+'，显示取得的真实状态。';}
      catch(error){if(current()){h.message=error.message;ctx.replyError?.(error);}}
      finally{if(ctx.state.settingsTool===h){h.busy=false;if(current())show();}}
    };
    for(const [key,action,name] of [['workspace',ctx.reloadWorkspace,'刷新员工与门店资料'],['platform',ctx.refreshSettingsPlatform,'刷新设备与平台状态'],['version',ctx.refreshRuntimeStatus,'刷新运行版本'],['logout',ctx.logout,'退出登录']])dialog?.querySelector(`[data-settings-${key}]`)?.addEventListener('click',()=>run(action,name));
    dialog?.querySelector('[data-settings-rule-files]')?.addEventListener('click',()=>{if(current()&&!h.busy)openCentralRuleFiles(ctx);});
    dialog?.querySelector('[data-settings-accounts]')?.addEventListener('click',()=>{if(!current()||h.busy)return;dialog.close();ctx.navigate('accounts');});
  };show();
}
