import http.client,importlib.util,json,threading,unittest
from http.server import ThreadingHTTPServer
from test_auto_bridge import fixture,NATIVE
spec=importlib.util.spec_from_file_location('automatic_bridge_host',NATIVE/'ui_native_host.py');host=importlib.util.module_from_spec(spec);spec.loader.exec_module(host)
class Routes(unittest.TestCase):
 def setUp(self):
  self.backend=fixture();self.backend._identity('fixture-token');self.backend.dispatch=self.backend._analysis_workspace_dispatch
  self.server=ThreadingHTTPServer(('127.0.0.1',0),host.StaticHandler)
  for k,v in {'backend':self.backend,'runtime':None,'csp':host.CSP,'csrf_token':'fixture-only','session_cookie':host.SESSION_COOKIE,
              'api_lock':threading.RLock(),'counters':{'blocked':0},'login_failures':[]}.items():setattr(self.server,k,v)
  self.thread=threading.Thread(target=self.server.serve_forever,daemon=True);self.thread.start()
 def tearDown(self):self.server.shutdown();self.server.server_close();self.thread.join(2)
 def request(self,action='analysis_workspace_read',data=None,headers=None):
  h={'Content-Type':'application/json','Origin':f'http://127.0.0.1:{self.server.server_port}','X-Fangyu-CSRF':'fixture-only','Cookie':host.SESSION_COOKIE+'=fixture-token'};h.update(headers or {})
  c=http.client.HTTPConnection('127.0.0.1',self.server.server_port,timeout=2);c.request('POST','/api/workbench',json.dumps({'action':action,'data':data or {'storeId':'store1'}}),h)
  r=c.getresponse();body=r.read();status=r.status;c.close();return status,body
 def test_read_and_pause_are_local_and_do_not_reauthorize(self):
  before=len(self.backend._analysis_queue.authorizations)
  self.assertEqual(self.request()[0],200);self.assertEqual(self.request('analysis_workspace_pause')[0],200)
  self.assertEqual(self.backend.authority_calls,1);self.assertEqual(len(self.backend._analysis_queue.authorizations),before)
 def test_scope_and_injected_fields_fail_before_controller(self):
  self.assertEqual(self.request(data={'storeId':'store2'})[0],403)
  self.assertEqual(self.request(data={'storeId':'store1','owner':'other'})[0],400)
  self.assertEqual(self.backend._analysis_queue.actions,[])
 def test_origin_host_and_csrf_still_fail_closed(self):
  for h in ({'Host':'external.invalid'},{'Origin':'https://external.invalid'},{'X-Fangyu-CSRF':'bad'}):self.assertEqual(self.request(headers=h)[0],403)
  self.assertEqual(self.backend._analysis_queue.actions,[])
 def test_status_does_not_wait_for_unrelated_host_lock(self):
  with self.server.api_lock:self.assertEqual(self.request()[0],200)
if __name__=='__main__':unittest.main(verbosity=2)
