// Local file bytes are preview data. Saving uses the existing workflow request and receipt.
const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const MAX_FILE=2*1024*1024;
const style=`<style>.wf-file-import{font-size:17px;line-height:1.55;border:1px solid #cfe1de;border-radius:14px;background:#f4faf8;padding:18px;margin:0 0 20px}.wf-file-import p{margin:6px 0 12px}.wf-file-import small{font-size:17px}.wf-file-import .wf-file-source{display:block;color:#356b65;margin-bottom:5px}.wf-file-import .wf-file-text{white-space:pre-wrap;overflow-wrap:anywhere;margin:0;font:inherit}.wf-file-import .wf-file-preview{max-height:420px;overflow:auto;background:#fff;border:1px solid #dbe8e5;border-radius:10px;padding:14px;margin:12px 0}.wf-file-import .wf-file-block+.wf-file-block{border-top:1px solid #e4eeec;margin-top:14px;padding-top:14px}.wf-file-import *{box-sizing:border-box}.wf-file-import label.wf-file-choice{font-size:17px;position:relative;display:inline-flex;cursor:pointer}.wf-file-import .wf-file-choice:focus-within{outline:2px solid #008a91;outline-offset:3px}.wf-file-import .wf-file-input{position:absolute;inset:0;width:100%!important;height:100%;opacity:0;cursor:pointer}.wf-file-import .wf-file-choice[aria-disabled=true]{opacity:.55;cursor:default}.wf-text-import>summary{cursor:pointer;font-size:17px;padding:10px 0}.wf-file-import .co-field{margin-top:12px}.wf-file-import select,.wf-file-import input,.wf-file-import button{font-size:17px}.wf-file-import .co-check-line{font-size:17px;align-items:flex-start;margin:14px 0;gap:9px}.wf-file-import .wf-file-notice{color:#49615d}</style>`;
export function renderKnowledgeFileImport(f){
  const t=f.fileImport,p=t?.preview,locked=!!(t?.busy||f.pending||f.localUnknown);
  return `${style}<section class="wf-file-import" aria-label="从文件导入资料"><strong>从文件导入</strong><p>选择文档或PNG/JPG扫描图片，先预览提取文字，再确认保存。</p><label class="co-button wf-file-choice" aria-disabled="${locked}"><span>选择资料文件（2MB以内）</span><input class="wf-file-input" aria-label="选择资料文件" type="file" data-kf-file accept=".pdf,.docx,.pptx,.txt,.md,.png,.jpg,.jpeg" ${locked?'disabled':''}></label><p class="wf-file-notice">PDF优先读取文字；普通扫描PDF和PNG/JPG可用本机中文提字。扫描PDF最多10页提字，需逐页核对；录音转写尚未启用。</p>${t?.busy&&!f.pending?'<p role="status">正在读取原文…</p>':''}${t?.error?`<p role="alert">${esc(t.error)}</p>`:''}${p?`<p><strong>${esc(p.filename)}</strong> · ${p.blocks.length} 段原文</p><p class="wf-file-notice">${esc(p.notice)}</p><div class="wf-file-preview" tabindex="0" aria-label="可核对的资料原文">${p.blocks.map(b=>`<div class="wf-file-block"><strong class="wf-file-source">${esc(b.location)}</strong><pre class="wf-file-text">${esc(b.text)}</pre></div>`).join('')}</div><label class="co-field"><span>资料名称</span><input data-kf-title maxlength="120" value="${esc(t.title)}" ${locked?'disabled':''}></label><label class="co-field"><span>由本人选择资料类型</span><select data-kf-kind ${locked?'disabled':''}><option value="">请选择</option><option value="fact" ${t.kind==='fact'?'selected':''}>资料原文（仍需核实）</option><option value="hypothesis" ${t.kind==='hypothesis'?'selected':''}>待验证假设</option></select></label><label class="co-check-line"><input type="checkbox" data-kf-check ${t.checked?'checked':''} ${locked?'disabled':''}><span>我已核对原文、来源和资料类型，确认保存到当前账号。</span></label><div class="co-actions"><button type="button" class="co-button co-primary" data-kf-save ${locked||!t.checked||!['fact','hypothesis'].includes(t.kind)?'disabled':''}>确认保存资料</button><button type="button" class="co-button" data-kf-clear ${locked?'disabled':''}>取消本次导入</button></div><p class="wf-file-notice">文件中的命令、链接和宏不会执行。预览尚未保存。</p>`:''}</section>`;
}
const encode=raw=>{const bytes=new Uint8Array(raw),parts=[];for(let i=0;i<bytes.length;i+=16384)parts.push(String.fromCharCode(...bytes.subarray(i,i+16384)));return btoa(parts.join(''));};
export function bindKnowledgeFileImport(root,{f,valid,update,preview,save}){
  const current=t=>valid()&&f.fileImport===t;
  root.querySelector('[data-kf-file]')?.addEventListener('change',async event=>{
    if(!valid()||f.pending||f.localUnknown||f.fileImport?.busy)return;
    const file=event.target.files?.[0];if(!file)return;
    const t={busy:true,error:'',preview:null,kind:'',checked:false,title:''};
    update(()=>{f.fileImport=t;f.error='';f.notice='';});
    try{
      if(!/\.(pdf|docx|pptx|txt|md|png|jpe?g)$/i.test(file.name))throw Error('支持PDF、DOCX、PPTX、TXT、MD及PNG/JPG；扫描PDF需要系统中文提字，录音转写尚未启用。');
      if(file.size<1||file.size>MAX_FILE)throw Error('请选择2MB以内的非空文件。');
      const raw=await file.arrayBuffer();if(!current(t))return;
      if(raw.byteLength!==file.size||raw.byteLength>MAX_FILE)throw Error('文件内容未完整读取，请重新选择。');
      const p=await preview({filename:file.name,dataBase64:encode(raw)});if(!current(t))return;
      if(!p||p.previewOnly!==true||p.filename!==file.name||p.requiresManualKindConfirmation!==true||!Array.isArray(p.blocks)||!p.blocks.length||typeof p.text!=='string'||p.text.length>100000)throw Error('原文预览尚未核对，请重新选择文件。');
      update(()=>{t.preview=p;t.title=p.title;t.busy=false;});
    }catch(error){if(current(t))update(()=>{t.busy=false;t.error=error?.message||'资料文件暂时无法读取。';});}
  });
  const t=f.fileImport;if(!t?.preview)return;
  root.querySelector('[data-kf-title]')?.addEventListener('input',event=>{if(current(t)&&!t.busy)t.title=event.target.value;});
  root.querySelector('[data-kf-kind]')?.addEventListener('change',event=>{if(current(t)&&!t.busy)update(()=>{t.kind=event.target.value;t.checked=false;});});
  root.querySelector('[data-kf-check]')?.addEventListener('change',event=>{if(current(t)&&!t.busy)update(()=>{t.checked=event.target.checked;});});
  root.querySelector('[data-kf-clear]')?.addEventListener('click',()=>{if(current(t)&&!t.busy&&!f.pending&&!f.localUnknown)update(()=>{f.fileImport=null;});});
  root.querySelector('[data-kf-save]')?.addEventListener('click',async()=>{
    if(!current(t)||t.busy||f.pending||f.localUnknown||!t.checked||!['fact','hypothesis'].includes(t.kind))return;
    const title=t.title.trim();if(!title){update(()=>{t.error='请填写资料名称。';});return;}
    update(()=>{t.busy=true;t.error='';});
    try{await save({title,text:t.preview.text,kind:t.kind,sourceLabel:t.preview.sourceLabel});}
    catch(error){if(current(t))update(()=>{t.error=error?.message||'资料尚未保存，请核对原操作。';});}
    finally{if(current(t))update(()=>{t.busy=false;});}
  });
}
