// Only original visible comments; confirmation never sends or records a lead fact.
import {requestDigest} from './customer-outcomes.mjs';
const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const key=v=>typeof v==='string'&&/^[a-f0-9]{64}$/.test(v);
const owner=s=>JSON.stringify([s.session?.user?.tenant_id||'',s.session?.user?.id||'',s.user||'',s.session?.user?.role||'',s.storeId||'']);
const scope=s=>JSON.stringify([s.authEpoch||0,owner(s),s.activePlatform||'xiaohongshu',s.page]);
const storageKey=(s,id,platform)=>'fangyu-public-contact-request-v1:'+owner(s)+':'+platform+':'+id;
const owns=(ctx,x)=>ctx.state.publicContactsUI===x&&!x.closed&&scope(ctx.state)===x.scope&&ctx.state.customerDetail?.id===x.id&&(!x.dialogOwner||x.dialog?.__modalOwner===x.dialogOwner);
const base=(ctx,x)=>({storeId:ctx.state.storeId,customerId:x.id,platform:x.platform});
const labels={stale:'原文已变，旧核对不可用',pending:'待本人核对',confirm:'本人已确认线索',reject:'本人已拒绝',revoke:'已撤销核对'};
const style='<style>.public-contact-ui{font-size:17px;line-height:1.6;overflow-wrap:anywhere}.public-contact-ui article{border-top:1px solid #dce9eb;padding:14px 0}.public-contact-ui blockquote{margin:8px 0;padding:10px;background:#edf7f8;white-space:pre-wrap}.public-contact-ui mark{background:#ffecb3}.public-contact-ui button{font:inherit;min-height:44px;margin:6px;padding:8px 12px;border:1px solid #bbd8dd;border-radius:9px;background:#f1faf9;color:#234e58}.public-contact-ui button:disabled{opacity:.5}.public-contact-ui label{display:flex;gap:8px;align-items:flex-start;margin-top:10px}.public-contact-ui small{display:block;color:#526c75}.public-contact-ui input{margin-top:7px}</style>';

function stored(ctx,id,platform){
  const raw=localStorage.getItem(storageKey(ctx.state,id,platform));if(!raw)return null;
  const p=JSON.parse(raw);
  if(p?.owner!==owner(ctx.state)||p.customerId!==id||p.platform!==platform||typeof p.requestId!=='string'||!/^[A-Za-z0-9_-]{8,100}$/.test(p.requestId)||!key(p.requestDigest))throw Error('原操作核对信息无法读取，请先核对原登记，避免重复操作。');
  return p;
}
function persist(ctx,x,data,signature){
  const p={owner:owner(ctx.state),customerId:x.id,platform:x.platform,requestId:data.requestId,requestDigest:signature},raw=JSON.stringify(p);
  localStorage.setItem(storageKey(ctx.state,x.id,x.platform),raw);
  if(localStorage.getItem(storageKey(ctx.state,x.id,x.platform))!==raw)throw Error('无法保存原操作编号，本次尚未提交。');
  x.pending=p;
}
function clear(ctx,x){localStorage.removeItem(storageKey(ctx.state,x.id,x.platform));x.pending=null;x.notFound=false;}
function validate(ctx,x,v){
  if(v?.actor?.username!==ctx.state.user||v.actor.storeId!==ctx.state.storeId||ctx.state.session?.user?.id&&v.actor.id!==ctx.state.session.user.id||v.customerId!==x.id||v.platform!==x.platform||!Number.isSafeInteger(v.version)||v.version<0||!key(v.sourceDigest)||!Array.isArray(v.candidates)||!Array.isArray(v.history)||v.candidateOnly!==true||v.contactSharedFactRecorded!==false)throw Error('原员工、门店或客户回执不匹配，请回原范围核对。');
  for(const c of v.candidates){
    if(!key(c.id)||!['phone','wechat'].includes(c.kind)||typeof c.value!=='string'||!['pending','confirm','reject'].includes(c.state)||!Array.isArray(c.sources)||!c.sources.length||c.state!=='pending'&&!key(c.eventId))throw Error('原文线索回执不完整。');
    for(const s of c.sources){const chars=Array.from(s.originalText||''),p=s.span;if(s.author_key!==x.id||s.platform!==x.platform||typeof s.leadId!=='string'||s.offsetUnit!=='unicode-code-point'||!Number.isInteger(p?.start)||!Number.isInteger(p.end)||p.start<0||p.end<=p.start||p.end>chars.length||chars.slice(p.start,p.end).join('')!==p.text||p.text!==c.value)throw Error('联系方式与原文位置不匹配，请重新核对。');}
  }
  for(const row of v.history){if(!key(row.id)||!key(row.candidateId)||!['confirm','reject','revoke'].includes(row.operation)||typeof row.canRevoke!=='boolean'||typeof row.withdrawn!=='boolean'||!['phone','wechat'].includes(row.kind))throw Error('原核对历史无法核实，请重新读取。');}
  if(x.pending&&(v.receipt?.requestId!==x.pending.requestId||!['accepted','cancelled','not_found'].includes(v.receipt.state)||v.receipt.state!=='not_found'&&v.receipt.requestDigest!==x.pending.requestDigest))throw Error('原操作回执尚未核实，请保留原编号。');
  return v;
}
function sourceHTML(s){
  const chars=Array.from(s.originalText),p=s.span;
  return `<blockquote>${esc(chars.slice(0,p.start).join(''))}<mark>${esc(p.text)}</mark>${esc(chars.slice(p.end).join(''))}</blockquote><small>${s.platform==='xiaohongshu'?'小红书':'抖音'} · 原账号评论 · 第${p.start+1}—${p.end}字</small>`;
}
function html(x){
  const disabled=x.busy||x.pending?'disabled':'';
  return `${style}<section class="public-contact-ui" data-public-contact-editor><p>仅整理客户在原评论中自愿留下的联系方式线索。本人确认仍不代表已联系、已留资或身份已核实。</p><p role="status">${esc(x.message)}</p>${x.pending?`<aside><strong>原操作待核对</strong><p>保留原编号，不会重复提交。</p><button data-public-contact-recover ${x.busy?'disabled':''}>核对原操作</button>${x.notFound?`<button data-public-contact-cancel ${x.busy?'disabled':''}>取消尚未落盘的原操作</button>`:''}</aside>`:''}${(x.view?.candidates||[]).map(c=>`<article><strong>${c.kind==='phone'?'手机':'微信'}：${esc(c.value)}</strong><small>${esc(c.requiresPriorRevoke?labels.stale:labels[c.state])}</small><details><summary>核对原评论（${c.sources.length}处）</summary>${c.sources.map(sourceHTML).join('')}</details><label><input type="checkbox" data-public-contact-confirm="${esc(c.id)}" ${disabled}><span>本人已逐条核对原文，确认本次${c.state==='pending'&&!c.requiresPriorRevoke?'确认或拒绝':'撤销'}操作。</span></label>${c.state==='pending'&&!c.requiresPriorRevoke?`<button data-public-contact-decision="confirm" data-candidate="${esc(c.id)}" ${disabled}>确认此线索</button><button data-public-contact-decision="reject" data-candidate="${esc(c.id)}" ${disabled}>拒绝此线索</button>`:`<button data-public-contact-decision="revoke" data-candidate="${esc(c.id)}" ${disabled}>撤销原核对</button>`}</article>`).join('')}${x.view&&!x.view.candidates.length?'<p>当前原评论中没有明确自愿留下的联系方式。昵称、笔记编号、泛称“私我”及有歧义的文字不会推断为联系方式。</p>':''}<button data-public-contact-refresh ${disabled}>重新读取原评论</button><details><summary>本人核对历史（${x.view?.history.length||0}）</summary>${(x.view?.history||[]).map(r=>`<article><strong>${r.withdrawn?'原文已变、旧线索不可用':esc(labels[r.operation])}${r.revoked?' · 后已撤销':''}</strong><small>${r.kind==='phone'?'原手机线索':r.kind==='wechat'?'原微信线索':'原核对'} · ${esc(r.createdAt)}</small>${r.withdrawn?'<p>历史保留，不再展示旧联系方式或原文；旧确认不作为当前有效线索。</p>':''}${r.canRevoke?`<label><input type="checkbox" data-public-contact-history-confirm="${esc(r.id)}" ${disabled}><span>本人确认撤销这条原核对，保留历史。</span></label><button data-public-contact-history-revoke="${esc(r.id)}" data-candidate="${esc(r.candidateId)}" ${disabled}>撤销这条原核对</button>`:''}</article>`).join('')||'<p>尚未核对。</p>'}</details></section>`;
}
function show(ctx,x){
  if(!owns(ctx,x))return;
  x.dialog=ctx.modal({title:'原文中的联系方式',html:html(x),canClose:()=>!x.busy});
  x.dialogOwner=x.dialog.__modalOwner;
  const shownOwner=x.dialogOwner,dialog=x.dialog;
  dialog.addEventListener('close',()=>{if(dialog.__modalOwner===shownOwner){x.closed=true;x.view=null;dialog.querySelector('[data-public-contact-editor]')?.remove();}},{once:true});
  x.dialog.querySelector('[data-public-contact-refresh]')?.addEventListener('click',()=>void read(ctx,x));
  x.dialog.querySelector('[data-public-contact-recover]')?.addEventListener('click',()=>void read(ctx,x));
  x.dialog.querySelector('[data-public-contact-cancel]')?.addEventListener('click',()=>void cancel(ctx,x));
  x.dialog.querySelectorAll('[data-public-contact-history-revoke]').forEach(button=>button.addEventListener('click',()=>{const eventId=button.dataset.publicContactHistoryRevoke,checked=x.dialog.querySelector(`[data-public-contact-history-confirm="${eventId}"]`)?.checked;if(!checked){x.message='请先勾选本人确认撤销。';show(ctx,x);return;}void decide(ctx,x,button.dataset.candidate,'revoke',eventId);}));
  x.dialog.querySelectorAll('[data-public-contact-decision]').forEach(button=>button.addEventListener('click',()=>{
    const id=button.dataset.candidate,checked=x.dialog.querySelector(`[data-public-contact-confirm="${id}"]`)?.checked;
    if(!checked){x.message='请先逐条核对原文，并勾选本人确认。';show(ctx,x);return;}
    void decide(ctx,x,id,button.dataset.publicContactDecision);
  }));
}
async function read(ctx,x){
  if(!owns(ctx,x)||x.busy)return;x.busy=true;x.message=x.pending?'正在核对原操作…':'正在读取当前可见原评论…';show(ctx,x);
  try{
    const result=await ctx.actions.publicContactAction('customer_public_contact_read',{...base(ctx,x),...(x.pending?{requestId:x.pending.requestId}:{})});
    if(!owns(ctx,x))return;x.view=validate(ctx,x,result.publicContacts);
    if(x.pending){
      x.notFound=x.view.receipt.state==='not_found';
      if(x.notFound)x.message='原操作尚未落盘；可取消原操作以阻止迟到保存。';
      else{const state=x.view.receipt.state;clear(ctx,x);x.message=state==='accepted'?'原核对已保存；没有重复提交。':'原操作已取消，没有新增核对。';}
    }else x.message='请逐条核对原文，再选择确认或拒绝。';
  }catch(e){if(owns(ctx,x)){x.view=null;x.message=e.message;ctx.actions.replyError?.(e);}}
  finally{if(owns(ctx,x)){x.busy=false;show(ctx,x);}}
}
async function decide(ctx,x,id,operation,target=null){
  if(!owns(ctx,x)||x.busy||x.pending||!x.view)return;
  const candidate=x.view.candidates.find(c=>c.id===id),history=target&&x.view.history.find(r=>r.id===target&&r.candidateId===id&&r.canRevoke);if(!candidate&&!history)return;if(operation==='revoke'&&target&&!history)return;
  x.busy=true;x.message='正在保存本人核对…';show(ctx,x);
  try{
    const data={...base(ctx,x),requestId:crypto.randomUUID(),expectedVersion:x.view.version,sourceDigest:x.view.sourceDigest,candidateId:id,operation,targetEventId:operation==='revoke'?(target||candidate?.eventId):null,confirmed:true};
    const signature=await requestDigest(data);if(!owns(ctx,x))return;persist(ctx,x,data,signature);
    const result=await ctx.actions.publicContactAction('customer_public_contact_save',data);
    if(!owns(ctx,x))return;x.view=validate(ctx,x,result.publicContacts);
    if(x.view.receipt.state==='not_found')throw Error('保存回执尚未核实，请继续核对原操作。');
    const state=x.view.receipt.state;clear(ctx,x);x.message=state==='accepted'?'本人核对已保存；原评论、意向和留资事实未改。':'原操作已取消，没有新增核对。';
  }catch(e){if(owns(ctx,x)){if(e.mutationCommitted===false)clear(ctx,x);x.view=null;x.message=e.message;ctx.actions.replyError?.(e);}}
  finally{if(owns(ctx,x)){x.busy=false;show(ctx,x);}}
}
async function cancel(ctx,x){
  if(!owns(ctx,x)||x.busy||!x.pending||!x.notFound)return;x.busy=true;x.message='正在取消原操作…';show(ctx,x);
  try{
    const result=await ctx.actions.publicContactAction('customer_public_contact_cancel',{...base(ctx,x),requestId:x.pending.requestId,requestDigest:x.pending.requestDigest});
    if(!owns(ctx,x))return;x.view=validate(ctx,x,result.publicContacts);
    if(x.view.receipt.state==='not_found')throw Error('取消结果尚未核实，请继续核对。');
    const state=x.view.receipt.state;clear(ctx,x);x.message=state==='accepted'?'原核对已保存，取消没有删除原记录。':'原操作已取消，迟到保存不会新增核对。';
  }catch(e){if(owns(ctx,x)){x.view=null;x.message=e.message;ctx.actions.replyError?.(e);}}
  finally{if(owns(ctx,x)){x.busy=false;show(ctx,x);}}
}
export function openPublicContacts(ctx,id,platform){
  if(ctx.state.connection!=='connected'||!ctx.state.session||!ctx.state.user||!ctx.state.storeId||ctx.state.page!=='customers'||ctx.state.customerDetail?.id!==id||!key(id)||!['xiaohongshu','douyin'].includes(platform)||platform!==(ctx.state.activePlatform||'xiaohongshu'))return;
  let pending;try{pending=stored(ctx,id,platform);}catch(e){ctx.toast(e.message);return;}
  const x={id,platform,scope:scope(ctx.state),closed:false,busy:false,pending,notFound:false,view:null,message:''};
  ctx.state.publicContactsUI=x;show(ctx,x);void read(ctx,x);return x;
}
