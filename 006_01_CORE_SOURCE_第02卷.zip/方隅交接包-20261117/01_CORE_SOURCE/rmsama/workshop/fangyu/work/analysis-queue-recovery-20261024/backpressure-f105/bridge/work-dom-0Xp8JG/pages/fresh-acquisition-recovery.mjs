import {sourceSelection} from './acquisition-source.mjs';
import {senderName} from './reply-account.mjs';
const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const ordered=v=>Array.isArray(v)?v.map(ordered):v&&typeof v==='object'?Object.fromEntries(Object.keys(v).sort().map(k=>[k,ordered(v[k])])):v;
const stamp=v=>JSON.stringify(ordered(v));
const active=['running','queued','pausing','resuming','stopping'];
const kinds={keywords:'关键词搜索',note_links:'指定笔记',profiles:'博主主页',own_interactions:'我的互动'};
export function freshSourceKind(s){
  const selected=sourceSelection(s),kind=selected?.source?.kind||'keywords';
  if(s.page==='acquire')return kind==='keywords'?'keywords':null;
  if(s.page==='diversified'&&selected?.selectedFor==='diversified'&&selected.selectedAuthEpoch===(s.authEpoch||0)&&['note_links','profiles','own_interactions'].includes(kind))return kind;
  return null;
}
export function freshAcquisitionCapture(s){
  const p=s.platform,a=p?.acquisition,last=p?.lastRequest,kind=freshSourceKind(s),platformId=s.activePlatform||'xiaohongshu';
  if(s.connection!=='connected'||!s.session||!s.user||!s.storeId||!kind||s.busy||s.connectionRecovering||s.platformError||s.sourceInteractionPending||s.deviceReconnecting||s.acquisitionAttempt?.unconfirmed||s.pendingAction?.unconfirmed||last?.state!=='accepted')return null;
  if(p?.actor?.username!==s.user||p.actor.storeId!==s.storeId||p.device?.bound!==true||p.device.state!=='online')return null;
  const retired=a?.accountRemoved===true&&a.taskScope==null&&a.taskStoreId===s.storeId&&a.taskPlatform===platformId;
  if(!a?.taskId||a.canPause!==false||active.includes(a.status)||!['paused','stopped','failed','blocked','held'].includes(a.status)||(!retired&&(a.taskScope?.storeId!==s.storeId||a.taskScope.platform!==platformId)))return null;
  if(last.job?.taskId&&last.job.taskId!==a.taskId)return null;
  const held=a.analysis?.hold===true||['AI_CONTEXT_REQUIRED','PRODUCT_REQUEST_UNKNOWN','AI_BILLING_UNKNOWN','AI_PROVIDER_TIMEOUT','AI_INVALID_OUTPUT'].includes(a.analysis?.scopeCode||a.analysis?.code);
  const platform=p.platforms?.find(row=>row.id===platformId&&row.enabled),accountId=s.platformAccountSelections?.[platformId]||platform?.accountId;
  const account=p.accounts?.find(row=>row.id===accountId&&row.platform===platformId);
  if(!platform||!accountId||account?.status!=='ready'||s.acquire?.selectedPlatform!==platformId||!Number.isSafeInteger(s.selection?.revision))return null;
  const differentAccount=Boolean((retired||a.taskScope?.accountId&&accountId!==a.taskScope.accountId)&&account.collectionReady===true);
  if(!differentAccount&&(a.reasonCode||!held||p.capabilities?.collection!==true))return null;
  const source=sourceSelection(s),applied=s.selection?.applied;
  if(kind==='keywords'&&(!Array.isArray(applied?.selectedKeywords)||!applied.selectedKeywords.length||applied.selectedKeywords.some(v=>typeof v!=='string'||!v.trim())))return null;
  if(kind!=='keywords'&&(!source?.source||source.accountId!==accountId||source.preview?.canStart!==true||!source.previewDigest))return null;
  const store=s.stores?.find(row=>row.id===s.storeId);if(!store)return null;
  const capture={transition:differentAccount?'different_account':'analysis_hold',actor:[s.authEpoch||0,s.session.user?.tenant_id,s.user,s.session.user?.role,s.storeId,platformId],route:s.page,kind,store:{id:store.id,name:store.name,region:store.region,city:store.city,area:store.area},account:{id:account.id,uid:account.platform_uid||account.platformUid||'',name:senderName(account),status:account.status},revision:s.selection.revision,applied:applied||null,region:s.acquire?.region||'',time:s.acquire?.time||'最近30天',source:kind==='keywords'?null:source,last:{requestId:last.requestId,state:last.state,taskId:last.job?.taskId||''},old:{taskId:a.taskId,accountRemoved:a.accountRemoved===true,status:a.status,taskScope:a.taskScope,analysis:a.analysis,canPause:a.canPause}};
  return {signature:stamp(capture),...JSON.parse(JSON.stringify(capture))};
}
export function renderFreshAcquisition(s){
  const capture=freshAcquisitionCapture(s);if(!capture)return '';
  if(capture.transition==='different_account')return `<section class="acquire-card" aria-label="账号切换说明" style="padding:16px;min-width:0"><p style="margin:0;overflow-wrap:anywhere">原任务与断点保留。点击上方按钮，将使用 <strong>${esc(capture.account.name)}</strong> 按当前条件新建采集；不会把原账号断点移给新账号。客户与评论仍统一保存。</p></section>`;
  return '<section class="acquire-card" aria-label="新建采集" style="padding:16px;min-width:0"><p style="margin:0 0 12px;overflow-wrap:anywhere">旧批次保留待核对。可按当前条件新建任务，已入库评论不会重复进入新任务分析。</p><button type="button" class="acquire-link" data-acquire-fresh style="white-space:normal;max-width:100%;text-align:left">保留旧任务，按当前条件新建采集</button></section>';
}
export function openFreshAcquisition(ctx){
  const s=ctx.state,capture=freshAcquisitionCapture(s);
  if(!capture||ctx.actions.hasUnconfirmed?.()){ctx.toast('当前状态或来源尚未核对，请刷新后重新确认。');return;}
  const source=capture.source?.source,details=capture.kind==='keywords'?capture.applied.selectedKeywords.join('、'):capture.kind==='note_links'?source.links.join('\n'):capture.kind==='profiles'?source.profiles.join('\n'):(source.types||[]).map(v=>({mentions:'评论与提及',likes:'赞与收藏',connections:'新增关注'}[v]||'待核对互动类型')).join('、')+'；'+(source.baseline==='visible_history'?'检查当前可见历史':'从本次起检查新增互动');
  const window=capture.source?.commentWindow,windowLabel=!window||window.mode==='all'?'全部评论时间':`最近 ${window.minutes} 分钟评论`;
  const differentAccount=capture.transition==='different_account';
  let pending=false,dialog;
  dialog=ctx.modal({title:differentAccount?'切换执行账号，新建采集':'保留旧任务，新建采集',confirmLabel:'确认新建采集',canClose:()=>!pending,
    html:`<div style="min-width:0;overflow-wrap:anywhere"><p>门店：<strong>${esc(capture.store.name)}</strong></p><p>平台：${capture.actor[5]==='douyin'?'抖音':'小红书'}</p><p>采集账号：<strong>${esc(capture.account.name)}</strong></p><p>本次来源：${esc(kinds[capture.kind])}</p><p style="white-space:pre-wrap">${esc(details)}</p><p>${capture.kind==='keywords'?`帖子时间：${esc(capture.time)}`:esc(windowLabel)}</p>${differentAccount?`<p>${capture.old.accountRemoved?'原执行账号已从软件移除，原任务与客户记录保留。':'原账号的验证提示、任务和断点继续保留。'}本次使用已选账号新建独立执行批次；不会复制原账号会话或断点，也不会自动回复。</p>`:''}<p>保留旧任务及其待核批次，不重发原分析请求。只让本次新入库的评论进入新任务分析；已见评论仍沿用原记录。</p><p>这不会自动解决旧批次的待核结果。个别新评论如仍命中原待核请求，仍会等待核对，不会绕过保护重复分析。</p><label style="display:flex;align-items:flex-start;gap:8px"><input type="checkbox" data-fresh-ack><span>我已核对以上当前条件，同意保留旧任务并新建采集。</span></label></div>`,
    onConfirm:async()=>{
      if(pending)return false;
      if(!dialog?.querySelector('[data-fresh-ack]')?.checked){ctx.toast('请先勾选确认当前采集条件。');return false;}
      const current=freshAcquisitionCapture(s);
      if(!current||current.signature!==capture.signature||ctx.actions.hasUnconfirmed?.()){ctx.toast('账号、门店、来源或原任务状态已变化，请关闭后重新确认。');return false;}
      pending=true;
      try{return Boolean(await ctx.actions.startAcquisition({fresh:capture}));}finally{pending=false;}
    }});
  return dialog;
}
