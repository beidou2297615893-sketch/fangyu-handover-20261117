const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const labels={absolute_claim:'承诺需核实',hype_phrase:'夸张表述',hard_cta:'引流措辞',ai_voice:'书面套话',generic_open:'泛化开场',conditional_claim:'缺少具体依据'};
export function renderWordingHints(row,v){
  const h=row?.wordingHints,d=row?.draft;
  if(!h||!d||v.dirty||v.text!==d.text||h.draftId!==d.id||h.draftVersion!==d.version||h.sourceDigest!==row.sourceDigest)return '';
  const flags=(h.flags||[]).slice(0,4),copy=h.status==='unavailable'?'措辞提示暂不可用，草稿已保留。':flags.length
    ?flags.map(x=>(labels[x.category]||'请核对')+'：'+x.phrase).join('；'):'未命中常见措辞提示，房源事实仍需人工核对。';
  return '<div data-live-wording role="note" style="font-size:14px;line-height:1.6;padding:8px 10px;margin:4px 0;border-radius:5px;background:#f2f8f8;color:#536e78;overflow-wrap:anywhere"><strong>措辞提示</strong> '+esc(copy)+'</div>';
}
