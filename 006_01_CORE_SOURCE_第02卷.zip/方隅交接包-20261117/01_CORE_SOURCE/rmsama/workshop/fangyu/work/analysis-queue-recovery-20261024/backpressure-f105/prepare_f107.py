"""Supersede inactive F106 for cold-mode capability; canonical stays F104."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,shutil
D=Path(__file__).resolve().parent;W=D.parent;P=W.parents[1];PACK=W/'package'
read=lambda p:json.loads(p.read_text('utf-8-sig'));sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert read(P/'work/ui-native-r57/FROZEN.json')['release_id']=='ui-r57-20261024T153411Z-4c9dd686'
pins=read(PACK/'ROOT-FINAL-PINS-V106.json');assert pins['installed'] is False
rows=read(PACK/'ROOT-COMPOSITION-V106.json')['changes'];assert len(rows)==3
public=P/'work/complete-product-resume-20261024/live-acquisition-acceptance-20261024/project'
backup=PACK/'public-before-f106'
for row in rows:
 rel=row['relativePath'];assert sha(public/rel)==row['sha256'];assert sha(backup/rel)==row['baselineSha256']
for row in rows:shutil.copy2(backup/row['relativePath'],public/row['relativePath'])
for row in rows:assert sha(public/row['relativePath'])==row['baselineSha256']
pins.update(status='SUPERSEDED_COLD_CAPABILITY_NOT_FOR_INSTALL',supersededReason='Separate trusted automatic queue mode from cold executor availability. Existing acquire/accounts UI auto-prepare may warm the service; not a claim of permanent production lock.')
(PACK/'ROOT-FINAL-PINS-V106.json').write_text(json.dumps(pins,ensure_ascii=False,indent=2)+'\n','utf-8')
report={'atUtc':datetime.now(timezone.utc).isoformat(),'sourceFilesCASRestoredToActualF104':[r['relativePath'] for r in rows],
 'inactiveF106Preserved':True,'canonicalUnchangedF104':True,'productionWrites':0,'nativeWindowsOperated':0,
 'reason':pins['supersededReason']}
with (D/'F106-SUPERSEDED-AND-PUBLIC-RESTORED.json').open('x',encoding='utf-8') as f:f.write(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
for old,new in [('compose_f106.py','compose_f107.py'),('install_verified_f106.py','install_verified_f107.py'),('verify_f106.py','verify_f107.py'),('formal_preservation_f106.py','formal_preservation_f107.py'),('check_installed_f106.py','check_installed_f107.py')]:
 body=(W/old).read_text('utf-8')
 body=body.replace('candidate-unified-v106','candidate-unified-v107').replace('V106','V107').replace('F106','F107')
 body=body.replace('public-before-f106','public-before-f107').replace('entry-v106','entry-v107').replace('verification-f106','verification-f107')
 body=body.replace('existing_f106_freezer','existing_f107_freezer').replace('formal_preservation_f106','formal_preservation_f107')
 if old=='verify_f106.py':
  body=body.replace("D/'core/v2/SEALED.json'","D/'core/v3/SEALED.json'")
  body=body.replace('CANDIDATE-V2-ACCEPTANCE','CANDIDATE-V3-ACCEPTANCE')
  body=body.replace("W/'compose_f106.py'","W/'compose_f107.py'")
 compile(body,new,'exec')
 with (W/new).open('x',encoding='utf-8') as f:f.write(body)
print(json.dumps(report,ensure_ascii=False))
