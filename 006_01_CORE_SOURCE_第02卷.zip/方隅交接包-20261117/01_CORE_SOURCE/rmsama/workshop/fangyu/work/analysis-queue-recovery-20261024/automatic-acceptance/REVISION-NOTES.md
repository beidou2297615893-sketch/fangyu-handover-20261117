# 已接通持久业务revision复用证据

来源：F103冻结 `customer_read_store.py`，不是新建migration。`CustomerReadStore._revision(db, scope, identity, generation)`约419行。

- `scope.actor`含tenant_id、username及当前actor；缓存key另含actor ID/role与store。
- 文件identity使用`(stat.st_dev,stat.st_ino)`，不包含mtime/size。schema按`(identity, PRAGMA schema_version)`验证并缓存。
- 真实表：`customer_read_epoch_v1(singleton,version,epoch)`和`customer_read_revision_v1(tenant_id,revision)`。
- 已验证DDL后，以同一只读快照读取`version=1, epoch32hex, tenant revision`，token含`('durable-v1',schema_version,epoch,revision)`，无5秒强制body重扫。
- 原watched实体包含leads、tasks、accounts、replies及租赁/业务资料；不包含users、ai_jobs、analysis controller/workspace metadata。普通心跳和控制写不使它失效。
- 仅复用有效durable token；无有效schema时可回退stream、不伪造cache命中，不在本轮新迁移。
- 不使用新连接的`PRAGMA data_version`；该值跨新连接不能作为提交业务版本。

held计数依赖`ai_attempts`，该实体不在原business revision监听范围。真实`core/store.py`的put/put_many/put_records使用`INSERT OR REPLACE`，因此scope覆盖索引上的`COUNT(*), MAX(rowid)`可作为正常writer尝试状态变更的廉价附加签名。不要只用lead revision而把新unknown仍缓存成processable。该签名只查询索引与数值，不解码全历史attempt body；需要在同一BEGIN内与business token/计数建立一致快照。正式文件替换由file identity/epoch使旧缓存失效。

缓存只覆盖counts；running、paused、phase、权限与当前门店仍即时读取/验证。禁止整份workspace回执缓存而漏掉用户暂停。
