// Approved preparation card and two platform rows; existing actions own login and checks.
const escape=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const slots=[{id:'xiaohongshu',name:'小红书',aliases:['xhs','xiaohongshu'],description:'笔记与评论获客'},{id:'douyin',name:'抖音',aliases:['douyin','dy'],description:'视频与评论获客'}];
// The local authoring helper inserts the existing project's vector paths.
const brandPaths={xiaohongshu:'M22.405 9.879c.002.016.01.02.07.019h.725a.797.797 0 0 0 .78-.972.794.794 0 0 0-.884-.618.795.795 0 0 0-.692.794c0 .101-.002.666.001.777zm-11.509 4.808c-.203.001-1.353.004-1.685.003a2.528 2.528 0 0 1-.766-.126.025.025 0 0 0-.03.014L7.7 16.127a.025.025 0 0 0 .01.032c.111.06.336.124.495.124.66.01 1.32.002 1.981 0 .01 0 .02-.006.023-.015l.712-1.545a.025.025 0 0 0-.024-.036zM.477 9.91c-.071 0-.076.002-.076.01a.834.834 0 0 0-.01.08c-.027.397-.038.495-.234 3.06-.012.24-.034.389-.135.607-.026.057-.033.042.003.112.046.092.681 1.523.787 1.74.008.015.011.02.017.02.008 0 .033-.026.047-.044.147-.187.268-.391.371-.606.306-.635.44-1.325.486-1.706.014-.11.021-.22.03-.33l.204-2.616.022-.293c.003-.029 0-.033-.03-.034zm7.203 3.757a1.427 1.427 0 0 1-.135-.607c-.004-.084-.031-.39-.235-3.06a.443.443 0 0 0-.01-.082c-.004-.011-.052-.008-.076-.008h-1.48c-.03.001-.034.005-.03.034l.021.293c.076.982.153 1.964.233 2.946.05.4.186 1.085.487 1.706.103.215.223.419.37.606.015.018.037.051.048.049.02-.003.742-1.642.804-1.765.036-.07.03-.055.003-.112zm3.861-.913h-.872a.126.126 0 0 1-.116-.178l1.178-2.625a.025.025 0 0 0-.023-.035l-1.318-.003a.148.148 0 0 1-.135-.21l.876-1.954a.025.025 0 0 0-.023-.035h-1.56c-.01 0-.02.006-.024.015l-.926 2.068c-.085.169-.314.634-.399.938a.534.534 0 0 0-.02.191.46.46 0 0 0 .23.378.981.981 0 0 0 .46.119h.59c.041 0-.688 1.482-.834 1.972a.53.53 0 0 0-.023.172.465.465 0 0 0 .23.398c.15.092.342.12.475.12l1.66-.001c.01 0 .02-.006.023-.015l.575-1.28a.025.025 0 0 0-.024-.035zm-6.93-4.937H3.1a.032.032 0 0 0-.034.033c0 1.048-.01 2.795-.01 6.829 0 .288-.269.262-.28.262h-.74c-.04.001-.044.004-.04.047.001.037.465 1.064.555 1.263.01.02.03.033.051.033.157.003.767.009.938-.014.153-.02.3-.06.438-.132.3-.156.49-.419.595-.765.052-.172.075-.353.075-.533.002-2.33 0-4.66-.007-6.991a.032.032 0 0 0-.032-.032zm11.784 6.896c0-.014-.01-.021-.024-.022h-1.465c-.048-.001-.049-.002-.05-.049v-4.66c0-.072-.005-.07.07-.07h.863c.08 0 .075.004.075-.074V8.393c0-.082.006-.076-.08-.076h-3.5c-.064 0-.075-.006-.075.073v1.445c0 .083-.006.077.08.077h.854c.075 0 .07-.004.07.07v4.624c0 .095.008.084-.085.084-.37 0-1.11-.002-1.304 0-.048.001-.06.03-.06.03l-.697 1.519s-.014.025-.008.036c.006.01.013.008.058.008 1.748.003 3.495.002 5.243.002.03-.001.034-.006.035-.033v-1.539zm4.177-3.43c0 .013-.007.023-.02.024-.346.006-.692.004-1.037.004-.014-.002-.022-.01-.022-.024-.005-.434-.007-.869-.01-1.303 0-.072-.006-.071.07-.07l.733-.003c.041 0 .081.002.12.015.093.025.16.107.165.204.006.431.002 1.153.001 1.153zm2.67.244a1.953 1.953 0 0 0-.883-.222h-.18c-.04-.001-.04-.003-.042-.04V10.21c0-.132-.007-.263-.025-.394a1.823 1.823 0 0 0-.153-.53 1.533 1.533 0 0 0-.677-.71 2.167 2.167 0 0 0-1-.258c-.153-.003-.567 0-.72 0-.07 0-.068.004-.068-.065V7.76c0-.031-.01-.041-.046-.039H17.93s-.016 0-.023.007c-.006.006-.008.012-.008.023v.546c-.008.036-.057.015-.082.022h-.95c-.022.002-.028.008-.03.032v1.481c0 .09-.004.082.082.082h.913c.082 0 .072.128.072.128V11.19s.003.117-.06.117h-1.482c-.068 0-.06.082-.06.082v1.445s-.01.068.064.068h1.457c.082 0 .076-.006.076.079v3.225c0 .088-.007.081.082.081h1.43c.09 0 .082.007.082-.08v-3.27c0-.029.006-.035.033-.035l2.323-.003c.098 0 .191.02.28.061a.46.46 0 0 1 .274.407c.008.395.003.79.003 1.185 0 .259-.107.367-.33.367h-1.218c-.023.002-.029.008-.028.033.184.437.374.871.57 1.303a.045.045 0 0 0 .04.026c.17.005.34.002.51.003.15-.002.517.004.666-.01a2.03 2.03 0 0 0 .408-.075c.59-.18.975-.698.976-1.313v-1.981c0-.128-.01-.254-.034-.38 0 .078-.029-.641-.724-.998z',douyin:'M12.525.02c1.31-.02 2.61-.01 3.91-.02.08 1.53.63 3.09 1.75 4.17 1.12 1.11 2.7 1.62 4.24 1.79v4.03c-1.44-.05-2.89-.35-4.2-.97-.57-.26-1.1-.59-1.62-.93-.01 2.92.01 5.84-.02 8.75-.08 1.4-.54 2.79-1.35 3.94-1.31 1.92-3.58 3.17-5.91 3.21-1.43.08-2.86-.31-4.08-1.03-2.02-1.19-3.44-3.37-3.65-5.71-.02-.5-.03-1-.01-1.49.18-1.9 1.12-3.72 2.58-4.96 1.66-1.44 3.98-2.13 6.15-1.72.02 1.48-.04 2.96-.04 4.44-.99-.32-2.15-.23-3.02.37-.63.41-1.11 1.04-1.36 1.75-.21.51-.15 1.07-.14 1.61.24 1.64 1.82 3.02 3.5 2.87 1.12-.01 2.19-.66 2.77-1.61.19-.33.4-.67.41-1.06.1-1.79.06-3.57.07-5.36.01-4.03-.01-8.05.02-12.07z'};
const scope=s=>JSON.stringify([s.authEpoch||0,s.connection,s.session?.user?.tenant_id||'',s.session?.user?.role||'',s.user||'',s.storeId||'',s.activePlatform||'xiaohongshu']);
function model(s){const key=scope(s);if(s.accountPage?.scope!==key)s.accountPage={scope:key,pending:'',feedback:{},failures:{}};return s.accountPage;}
function currentPlatform(s){const p=s.platform;return s.connection==='connected'&&s.session?.user?.username===s.user&&p?.actor?.username===s.user&&p.actor.storeId===s.storeId?p:null;}
function platforms(s){
  const p=currentPlatform(s);
  return slots.map(slot=>{const live=p?.platforms?.find(r=>slot.aliases.includes(r.id)),accountId=s.platformAccountSelections?.[live?.id]||live?.accountId,account=p?.accounts?.find(r=>r.id===accountId&&slot.aliases.includes(r.platform));return {...slot,...live,accountId,account,displayName:slot.name,status:account?.status||live?.status,message:account?.message||live?.message,requiresReview:account?.requiresReview??account?.requires_review??live?.requiresReview,accountName:account?.name||account?.platformNickname||account?.platform_nickname||live?.accountName||'尚未连接'};});
}
function status(row,s){
  if(s.connection==='preview')return '待登录';
  const p=currentPlatform(s);if(s.platformLoading&&!p)return '正在读取';if(!p||s.platformError)return '状态待读取';if(row.enabled===false)return '未开通';if(row.enabled!==true)return '状态待读取';
  const d=p.device||{};if(['held','blocked','paused','review_required'].includes(d.state)||row.requiresReview)return '暂停 · 待核验';if(!d.bound)return '待准备';if(d.state!=='online')return '电脑待连接';
  if(['ready','connected','online'].includes(row.status))return row.account?'已登录':'待核验';
  if(model(s).failures?.[row.id])return '待重新检查';
  return ({logging_in:'连接中',waiting_login:'等待扫码',checking:'核对中',held:'暂停 · 待核验',blocked:'暂停 · 待核验',login_required:'待登录',disconnected:'待连接',failed:'连接未完成',unverified:'待核验'})[row.status]||'待登录';
}
function preparation(s,pending=model(s).pending){
  const p=currentPlatform(s),d=p?.device;
  if(pending==='prepare')return {label:'准备中…',ready:false,message:'正在检查当前电脑的连接环境'};
  if(s.connection==='preview')return {label:'待准备',ready:false,message:'自动检查连接环境，准备好后再登录平台'};
  if(!p||s.platformError)return {label:s.platformLoading?'正在读取':'待读取',ready:false,message:s.platformError||'自动检查连接环境，准备好后再登录平台'};
  if(d?.bound&&d.state==='online')return {label:'已准备',ready:true,message:'本机连接已确认，可以选择平台登录'};
  return {label:['held','blocked','paused'].includes(d?.state)?'待核验':d?.state==='binding'?'准备中':'待准备',ready:false,message:d?.message||'自动检查连接环境，准备好后再登录平台'};
}
function brand(id){const path=brandPaths[id],shape=id==='douyin'?`<path d="${path}" fill="#25f4ee" transform="translate(-.7 -.1)"/><path d="${path}" fill="#fe2c55" transform="translate(.7 .5)"/><path d="${path}" fill="#fff"/>`:`<path d="${path}" fill="#fff"/>`;return `<span aria-hidden="true" style="width:80px;height:80px;display:flex;align-items:center;justify-content:center;border-radius:21px;background:${id==='douyin'?'#101214':'#ff2442'};flex-shrink:0"><svg viewBox="0 0 24 24" style="width:${id==='douyin'?51:69}px;height:${id==='douyin'?58:69}px">${shape}</svg></span>`;}
const textButton='border:0;background:transparent;padding:3px 6px;color:#087d91;font-size:17px;white-space:nowrap';
const primary='background:#007e89;color:#fff;border:1px solid #007e89;border-radius:8px;font-size:24px;font-weight:600;height:63px;padding:0 24px;white-space:nowrap';
const chip=(text,ok=false,neutral=false)=>`<span role="status" style="display:inline-block;padding:6px 20px;border-radius:24px;background:${ok?'#e5f8f3':neutral?'#eef4f8':'#fff1dc'};color:${ok?'#087f75':neutral?'#8399af':'#a45d15'};font-size:20px;line-height:1.4;font-weight:500;white-space:nowrap">${escape(text)}</span>`;
export function render(s){
  const id=s.activePlatform||'xiaohongshu',row=platforms(s).find(x=>x.id===id),p=currentPlatform(s),prep=preparation(s),ui=model(s);
  const accounts=(p?.accounts||[]).filter(a=>row.aliases.includes(a.platform)),unread=s.connection!=='preview'&&!p,loading=unread&&!s.platformError,busy=s.busy||Boolean(ui.pending)||loading;
  return `<div class="platform-accounts-page"><section class="account-platform-card card"><div class="account-platform-heading" style="flex-wrap:wrap;gap:16px"><img src="/assets/brand-${id}.svg" alt=""><div class="account-title-line" style="min-width:150px"><h2>${row.displayName}账号</h2><span class="account-help"><button type="button" data-account-help aria-label="账号使用说明" aria-describedby="account-help-text">?</button><span id="account-help-text" role="tooltip">当前工作门店由工作台所选门店决定，不是小红书自动识别。任务保存当时的门店条件；换词无需重登。登录与请求验证分别判断，验证码或人脸核验仍需本人完成。</span></span></div><button type="button" class="primary" data-account-add ${busy||unread?'disabled':''}>新增账号</button></div><div class="account-rows">${loading?'<div class="account-empty" role="status"><p>正在读取'+row.displayName+'账号…</p><span>已有账号读取后显示，无需重复新增。</span></div>':unread?'<div class="account-empty" role="alert"><p>账号清单暂未读取</p><span>请点检查本机后重试，已有账号资料保留。</span></div>':accounts.length?accounts.map(account=>{
    const selected=row.accountId===account.id,entry={...row,account,status:account.status,requiresReview:account.requiresReview??account.requires_review};
    const actual=account.platformNickname||account.platform_nickname||account.name||'',label=['ready','connected','online'].includes(account.status)?(entry.requiresReview?'已登录 · 待核验':'已登录'):status(entry,s);
    return `<article class="account-row ${selected?'is-selected':''}" style="flex-wrap:wrap;gap:16px"><img class="account-brand" src="/assets/brand-${id}.svg" alt=""><div class="account-name" style="min-width:180px"><strong>${escape(actual||'平台昵称待读取')}${selected?' <span style="font-size:17px;color:inherit">· 当前使用</span>':''}</strong><span style="font-size:17px">备注：${escape(account.remarks||'未填写')}</span><span style="font-size:17px">当前工作门店：${escape(s.store||'尚未选择')}</span>${typeof account.collectionReady==='boolean'?`<span style="font-size:17px">${escape(account.collectionReady?'采集条件已就绪':'采集暂不可用：'+(account.collectionMessage||'请检查本机和账号条件'))}</span>`:''}</div><span class="account-status" role="status">${escape(label)}</span><div class="account-row-actions" style="display:flex;align-items:center;flex-wrap:wrap;gap:10px;width:100%;font-size:17px">${account.status==='ready'?`<button type="button" data-account-select="${escape(account.id)}" ${busy||selected?'disabled':''}>${selected?'当前使用':'使用此账号'}</button>`:`<button type="button" data-account-connect="${escape(account.id)}" ${busy?'disabled':''}>${id==='douyin'?['logging_in','waiting_login','checking','unverified'].includes(account.status)?'继续连接':'连接此账号':'登录此账号'}</button>`}${id==='xiaohongshu'?`<button type="button" data-account-website="${escape(account.id)}" ${busy?'disabled':''}>打开小红书网页</button>`:''}<button type="button" class="text-button" data-account-check="${escape(account.id)}" ${busy?'disabled':''}>检查连接</button><button type="button" class="text-button" data-account-edit="${escape(account.id)}" ${busy?'disabled':''}>修改备注</button><button type="button" class="text-button" data-account-delete="${escape(account.id)}" ${busy?'disabled':''}>删除账号</button></div></article>`;
  }).join(''):'<div class="account-empty"><p>还没有'+row.displayName+'账号</p><span>新增一个账号后，在平台窗口完成登录。</span></div>'}</div><p class="account-feedback" role="status">${escape(ui.feedback[id]||s.platformError||'')}</p></section><div class="account-device"><span>${escape(prep.message)}</span><button type="button" class="text-button" data-account-prepare ${busy?'disabled':''}>${prep.ready?'检查本机':'准备本机连接'}</button></div></div>`;
}
export function bind(root,ctx){
  const help=root.querySelector('[data-account-help]');help?.addEventListener('keydown',e=>{if(e.key==='Escape'){help.blur();help.closest('.account-help')?.classList.add('is-dismissed');}});for(const name of ['focus','mouseenter'])help?.addEventListener(name,()=>help.closest('.account-help')?.classList.remove('is-dismissed'));
  const state=ctx.state,key=scope(state),id=state.activePlatform||'xiaohongshu';
  bindAccountEntry(root,ctx);
  const own=()=>scope(state)===key&&state.page==='accounts';
  async function run(kind,accountId){
    const ui=model(state);if(ui.pending||state.busy)return;
    if(state.connection==='preview'){ctx.toast('界面预览不会连接真实账号。');return;}
    ui.pending=kind;ui.feedback[id]='正在处理…';ctx.update(()=>{});
    try{
      if(accountId){state.platformAccountSelections??={};state.platformAccountSelections[id]=accountId;}
      const result=kind==='prepare'?await ctx.actions.preparePlatform():kind==='check'?await ctx.actions.checkAccount(id):await ctx.actions.connectAccount(id,accountId);
      if(!own())return;ui.feedback[id]=result?.job?.message||state.platformError||'';ui.failures??={};ui.failures[id]=['failed','cancelled','stopped'].includes(result?.job?.status);
    }catch(error){if(own())ui.feedback[id]=error.message;}
    finally{if(own()){ui.pending='';ctx.update(()=>{});}}
  }
  root.querySelector('[data-account-add]')?.addEventListener('click',()=>{
    if(!own()||state.busy||(state.connection!=='preview'&&!currentPlatform(state)))return;
    const name=id==='douyin'?'抖音':'小红书';
    const dialog=ctx.modal({title:'新增'+name+'账号',html:`<form class="account-add-form"><label>账号备注<input id="account-new-name" maxlength="80" autocomplete="off" placeholder="例如：古北店前台A" required></label><p>登录后由平台读取昵称，备注用于你自己区分账号。</p><p data-account-create-error role="alert"></p></form>`,confirmLabel:'新增并登录',onConfirm:async()=>{
      if(!own()||state.busy)return false;const input=dialog.querySelector('#account-new-name'),name=input.value.trim();if(!name){input.reportValidity();return false;}
      if(state.connection==='preview'){ctx.toast('预览不会新增真实账号');return true;}
      const button=dialog.querySelector('.modal-confirm');button.disabled=true;
      try{const result=await ctx.actions.accountCreate({platform:id,name});if(!own())return false;const accountId=result?.job?.accountId||result?.accountId;if(!accountId)throw Error('新增结果尚未确认，请刷新账号列表核对。');state.platformAccountSelections??={};state.platformAccountSelections[id]=accountId;dialog.close();await run('connect',accountId);return false;}
      catch(error){if(own())dialog.querySelector('[data-account-create-error]').textContent=error.message;return false;}
      finally{if(button.isConnected)button.disabled=false;}
    }});
  });
  root.querySelectorAll('[data-account-edit]').forEach(button=>button.addEventListener('click',async()=>{
    const accountId=button.dataset.accountEdit;let value=null,pending=false;
    const dialog=ctx.modal({title:'修改账号',html:'<p role="status">正在读取账号资料…</p>',canClose:()=>{if(pending){ctx.toast('请先重新读取，核对原账号修改结果。');return false;}return true;}});
    const modalOwner=dialog.__modalOwner,owns=()=>own()&&dialog.open&&dialog.__modalOwner===modalOwner;
    function show(message=''){
      if(!owns()||!value)return;
      dialog.querySelector('.modal-content').innerHTML=`<form class="account-add-form"><label>账号备注<input id="account-edit-name" maxlength="100" value="${escape(value.name)}"></label><label>平台昵称<input value="${escape(value.platformNickname||'登录后读取')}" readonly></label><label>登录入口<input value="${escape(value.url)}" readonly></label><p>登录入口由平台固定；修改备注不会更换登录身份。</p><p data-account-edit-message role="status">${escape(message)}</p><button type="button" data-account-edit-read>重新读取</button></form>`;
      const actions=dialog.querySelector('.modal-actions');actions.innerHTML=`<button type="button" class="modal-cancel">关闭</button><button type="button" class="primary" data-account-edit-save ${pending?'disabled':''}>保存备注</button>`;
      actions.querySelector('.modal-cancel').onclick=()=>{if(!pending)dialog.close();else ctx.toast('请先重新读取核对修改结果。');};
      dialog.querySelector('[data-account-edit-read]').onclick=()=>readMetadata();
      actions.querySelector('[data-account-edit-save]').onclick=async()=>{
        if(!owns()||pending)return;const name=dialog.querySelector('#account-edit-name').value.trim();if(!name){dialog.querySelector('[data-account-edit-message]').textContent='请填写账号备注。';return;}
        pending=true;actions.querySelector('[data-account-edit-save]').disabled=true;
        try{const result=await ctx.actions.accountMetadataSave({accountId,platform:id,name,expectedMetadataDigest:value.metadataDigest});if(!owns())return;value=result?.accountMetadata;if(!value||value.accountId!==accountId||value.platform!==id)throw Error('账号修改回执不一致，请重新读取。');pending=false;show('备注已保存。');ctx.actions.refreshPlatform({manual:true});}
        catch(error){if(!owns())return;const uncertain=['RESULT_UNCONFIRMED','ACCOUNT_METADATA_RESULT_UNCONFIRMED'].includes(error.code);pending=uncertain;dialog.querySelector('[data-account-edit-message]').textContent=error.message+(uncertain?' 请重新读取核对原账号，输入已保留。':'');actions.querySelector('[data-account-edit-save]').disabled=uncertain;}
      };
    }
    async function readMetadata(){
      try{const result=await ctx.actions.accountMetadataRead({accountId,platform:id});if(!owns())return;const next=result?.accountMetadata;if(next?.accountId!==accountId||next.platform!==id||next.urlEditable!==false)throw Error('账号资料暂未确认。');value=next;pending=false;show();}
      catch(error){if(owns()){const message=dialog.querySelector('[data-account-edit-message]');if(message)message.textContent=error.message;else dialog.querySelector('.modal-content').textContent=error.message;}}
    }
    await readMetadata();
  }));
  root.querySelector('[data-account-prepare]')?.addEventListener('click',()=>run('prepare'));
  root.querySelectorAll('[data-account-select]').forEach(button=>button.addEventListener('click',()=>{
    if(!own()||state.busy||state.pendingAction?.unconfirmed||state.acquisitionAttempt?.unconfirmed)return;
    const current=currentPlatform(state),account=current?.accounts?.find(a=>a.id===button.dataset.accountSelect&&a.platform===id);
    if(model(state).pending||['submitted','unconfirmed'].includes(current?.lastRequest?.state)){ctx.toast('请先核对上次采集状态，再选择账号。');return;}
    if(!account||account.status!=='ready'||account.requiresReview)return;
    if(['running','queued','pausing','resuming','stopping'].includes(current.acquisition?.status)){ctx.toast('请先暂停当前采集，再选择账号。');return;}
    state.platformAccountSelections??={};state.platformAccountSelections[id]=account.id;
    ctx.update(()=>{});ctx.toast('已选用本店账号，沿用现有登录。');
  }));
  root.querySelectorAll('[data-account-connect]').forEach(b=>b.addEventListener('click',()=>run('connect',b.dataset.accountConnect)));
  root.querySelectorAll('[data-account-check]').forEach(b=>b.addEventListener('click',()=>run('check',b.dataset.accountCheck)));
  return ()=>{};
}


// Every target is captured from the visible actor/store snapshot, never re-selected at send time.
export function accountEntryCapture(state,accountId){
  const platform=state.activePlatform||'xiaohongshu',p=currentPlatform(state);
  const row=p?.accounts?.find(a=>a.id===accountId&&a.platform===platform);
  if(!row||typeof row.name!=='string'||!row.name||[...row.name].length>100)return null;
  return Object.freeze({scope:scope(state),username:state.user,storeId:state.storeId,accountId:row.id,platform,selectedAccountId:state.platformAccountSelections?.[platform]||p.platforms?.find(p=>p.id===platform)?.accountId||'',
    expectedNickname:row.name,remarks:row.remarks||'',displayNickname:row.platformNickname||row.platform_nickname||row.name});
}
function bindAccountEntry(root,ctx){
  const state=ctx.state,initialScope=scope(state),ui=model(state);
  const own=()=>scope(state)===initialScope&&state.page==='accounts'&&Boolean(currentPlatform(state));
  const frozenCurrent=c=>{const {requestId,...capture}=c;return own()&&JSON.stringify(accountEntryCapture(state,c.accountId))===JSON.stringify(capture);};
  const storageKey='fangyu-account-delete-v1:'+initialScope;
  function readPending(){try{const p=JSON.parse(localStorage.getItem(storageKey)||'null');return p?.scope===initialScope&&p.storeId===state.storeId&&p.username===state.user&&p.platform===(state.activePlatform||'xiaohongshu')&&typeof p.requestId==='string'&&/^[A-Za-z0-9_-]{8,128}$/.test(p.requestId)?p:null;}catch{return null;}}
  function savePending(p){const text=JSON.stringify(p);localStorage.setItem(storageKey,text);if(localStorage.getItem(storageKey)!==text)throw Error('无法保存原删除操作，本次尚未提交。');}
  function clearPending(p){try{if(readPending()?.requestId===p.requestId)localStorage.removeItem(storageKey);}catch{}}
  function validActor(result,c){const a=result?.actor||result?.platform?.actor||result?.job?.actor;return a?.username===c.username&&a.storeId===c.storeId&&(!a.accountId||a.accountId===c.accountId)&&(!a.platform||a.platform===c.platform);}
  function confirmTarget(c,title,confirmLabel,onConfirm){
    return ctx.modal({title,html:`<p style="font-size:17px">平台昵称：<strong>${escape(c.displayNickname)}</strong></p><p style="font-size:17px">备注：${escape(c.remarks||'未填写')}</p><p style="font-size:17px">门店：${escape(state.store||'当前门店')}</p>`,confirmLabel,onConfirm});
  }
  root.querySelectorAll('[data-account-website]').forEach(button=>button.addEventListener('click',()=>{
    const c=accountEntryCapture(state,button.dataset.accountWebsite);
    if(!c||!own()||state.busy||ui.pending)return;
    if(state.connection==='preview'){ctx.toast('预览不会打开真实平台账号。');return;}
    let pending=false,dialog;
    dialog=confirmTarget(c,'打开小红书网页','打开此账号网页',async()=>{
      if(pending||!frozenCurrent(c)){ctx.toast('账号或门店资料已变化，请重新选择。');return false;}
      if(ctx.actions.hasUnconfirmed?.()){ctx.toast('请先核对上次操作的原结果。');return false;}
      pending=true;const owner=dialog.__modalOwner;ui.pending='website';
      const controls=dialog.querySelector('.modal-confirm');if(controls)controls.disabled=true;
      const visible=()=>own()&&dialog.open&&dialog.__modalOwner===owner;
      try{
        let result=await ctx.actions.accountWebsiteOpen({accountId:c.accountId});
        if(!visible())return false;if(!validActor(result,c))throw Error('账号网页归属尚未核对，请刷新账号列表。');
        let job=result.job||{},jobId=job.jobId||job.id;
        if(job.accountId!==c.accountId)throw Error('此账号窗口回执尚未核对，请刷新后查看。');
        const message=dialog.querySelector('.modal-content');
        const paint=()=>{message.innerHTML=`<p style="font-size:17px"><strong>${escape(c.displayNickname)}</strong></p><p style="font-size:17px" role="status">${escape(job.windowOpen===true?'此账号网页已打开，请本人在该网页完成登录或验证。':job.message||'正在打开此账号网页，请稍候。')}</p><p style="font-size:17px">网页打开不等于登录完成；完成后点账号页“检查连接”。</p>`;};
        paint();
        // Bounded status reads only. An opening receipt is never presented as an opened window.
        for(let i=0;i<10&&job.windowOpen!==true&&jobId&&['verification_opening','running','queued'].includes(job.status);i++){
          await new Promise(resolve=>setTimeout(resolve,700));if(!visible())return false;
          result=await ctx.actions.accountWebsiteStatus(jobId);if(!visible())return false;
          if(!validActor(result,c)||result.job?.accountId!==c.accountId||(result.job?.jobId||result.job?.id)!==jobId)throw Error('原账号窗口回执尚未核对。');
          job=result.job||{};paint();
        }
        if(!visible())return false;
        if(job.windowOpen!==true&&['failed','cancelled','completed','not_started'].includes(job.status))message.innerHTML=`<p style="font-size:17px" role="alert">${escape(job.message||'此账号网页未打开，请检查本机后重试。')}</p>`;
        if(controls){controls.textContent='关闭';controls.disabled=false;controls.onclick=()=>dialog.close();}return false;
      }catch(error){if(visible())dialog.querySelector('.modal-content').textContent=error.message;return false;}
      finally{pending=false;if(own())ui.pending='';if(controls?.isConnected)controls.disabled=false;}
    });
  }));
  function openDelete(c,p=null,retryProof=false){
    if(!own()||state.busy||ui.pending)return;
    let pending=false,dialog,original=p,owner;
    const validDialog=()=>own()&&dialog.open&&dialog.__modalOwner===owner;
    const paint=(message,queryOnly)=>{
      if(!validDialog())return;
      dialog.querySelector('.modal-content').innerHTML=`<p style="font-size:17px">平台昵称：<strong>${escape(c.displayNickname)}</strong></p><p style="font-size:17px">备注：${escape(c.remarks||'未填写')}</p><p style="font-size:17px">只移除此登录账号。已有客户、评论、回复及旧任务记录继续保留。</p><p style="font-size:17px" role="status">${escape(message)}</p>`;
      const b=dialog.querySelector('.modal-confirm');if(b)b.textContent=retryProof?'按原请求重试':queryOnly?'核对原删除结果':'确认删除此账号';
    };
    async function submit(){
      if(pending||!validDialog())return false;
      if(retryProof&&!frozenCurrent(original)){retryProof=false;paint('账号、门店、登录状态或昵称已变化；保留原编号，只能核对原结果。',true);return false;}
      if(!original&&!frozenCurrent(c)){paint('账号或门店资料已变化，请关闭后重新确认。',false);return false;}
      if(!original&&ctx.actions.hasUnconfirmed?.()){paint('请先核对上次操作的原结果。',false);return false;}
      pending=true;ui.pending='delete';const b=dialog.querySelector('.modal-confirm');if(b)b.disabled=true;
      try{
        const retrying=retryProof,querying=Boolean(original)&&!retrying;retryProof=false;
        if(!original){const next={...c,requestId:crypto.randomUUID()};savePending(next);original=next;}
        const payload={storeId:original.storeId,accountId:original.accountId,platform:original.platform,expectedNickname:original.expectedNickname,confirmed:true,requestId:original.requestId};
        const result=querying?await ctx.actions.accountDeleteRequest({storeId:original.storeId,requestId:original.requestId}):await (retrying?ctx.actions.accountDeleteRetry(payload):ctx.actions.accountDelete(payload));
        if(!validDialog())return false;
        const d=result?.accountDeletion;
        if(querying&&d?.state==='not_started'&&d.requestId===original.requestId&&result.actor?.username===original.username&&result.actor?.storeId===original.storeId&&!d.accountId&&!d.platform&&!d.nickname){
          paint((d.message||'未找到原删除回执。')+' 原编号仍保留；这不代表账号已删除，不会自动重提。',true);
          if(frozenCurrent(original)){const retry=document.createElement('button');retry.type='button';retry.textContent='按原请求重试';retry.dataset.accountDeleteRetry='';retry.onclick=()=>{if(validDialog()&&frozenCurrent(original))openDelete(original,original,true);else ctx.toast('原账号资料已变化，请继续核对原操作。');};dialog.querySelector('.modal-content').append(retry);}
          return false;
        }
        if(!validActor(result,original)||result.actor?.accountId!==original.accountId||result.actor?.platform!==original.platform||!d||d.requestId!==original.requestId||d.accountId!==original.accountId||d.platform!==original.platform||d.nickname!==original.expectedNickname||!['deleted','not_started','unknown'].includes(d.state))throw Error('原删除回执尚未核对，请保留原操作查询。');
        if(d.state==='unknown'){paint(d.message||'删除结果暂未确认；只核对原操作，不会再次删除。',true);return false;}
        clearPending(original);
        if(d.state==='deleted'){
          if(state.platformAccountSelections?.[original.platform]===original.accountId)delete state.platformAccountSelections[original.platform];
          paint(d.message||'此账号已移除。客户、评论和回复记录保留。',false);
          if(b){b.textContent='关闭';b.onclick=()=>dialog.close();}
          ui.feedback[original.platform]='此账号已移除；已有客户、评论和回复记录保留。';
          await ctx.actions.refreshPlatform({manual:true});
        }else{paint(d.message||'原删除尚未开始。请关闭后重新确认要删除的账号。',false);if(b){b.textContent='关闭';b.onclick=()=>dialog.close();}}
      }catch(error){
        if(error.mutationCommitted===false&&original){clearPending(original);original=null;}
        if(validDialog())paint(error.message+(original?' 请核对原删除结果，不会重复删除。':''),Boolean(original));
      }finally{pending=false;if(own())ui.pending='';if(b?.isConnected)b.disabled=false;}
      return false;
    }
    dialog=ctx.modal({title:retryProof?'按原请求重试删除账号':p?'核对原删除结果':'删除账号',html:'',confirmLabel:retryProof?'按原请求重试':p?'核对原删除结果':'确认删除此账号',onConfirm:submit,canClose:()=>!pending});owner=dialog.__modalOwner;
    paint(retryProof?'原查询确认尚未开始。再次确认后，只按原账号、原昵称和原编号提交一次。':p?'原删除结果尚未确认，只能查询原操作。':'请确认昵称和备注，删除后需要重新新增并登录才能再次使用。',Boolean(p));
  }
  const pending=readPending();
  if(pending){
    const note=document.createElement('p');note.className='account-feedback';note.style.fontSize='17px';note.setAttribute('role','status');note.textContent='“'+pending.displayNickname+'”的删除结果尚未确认。';
    const read=document.createElement('button');read.type='button';read.textContent='核对原删除结果';read.onclick=()=>openDelete(pending,pending);note.append(' ',read);root.querySelector('.account-rows')?.after(note);
  }
  root.querySelectorAll('[data-account-delete]').forEach(button=>button.addEventListener('click',()=>{
    const old=readPending();if(old){openDelete(old,old);return;}
    const c=accountEntryCapture(state,button.dataset.accountDelete);if(!c||!own())return;
    if(state.connection==='preview'){ctx.toast('预览不会删除真实账号。');return;}
    openDelete(c);
  }));
}
