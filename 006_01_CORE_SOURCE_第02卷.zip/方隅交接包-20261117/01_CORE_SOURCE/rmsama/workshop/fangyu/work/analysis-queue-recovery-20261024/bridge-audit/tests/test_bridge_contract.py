"""Pure extracted-route fixtures: no Core/WorkbenchBackend construction or provider."""
import ast
import copy
import importlib.util
import json
import hashlib
import time
from pathlib import Path
import re
import threading
import types
import unittest

ROOT = Path(__file__).resolve().parents[1]
NATIVE = ROOT / 'candidate/work/ui-native-r57'


class Failure(ValueError):
    def __init__(self, code, message, status=400):
        super().__init__(message)
        self.code, self.status = code, status


def extracted(name):
    tree = ast.parse((NATIVE / 'workbench_backend.py').read_text(encoding='utf-8-sig'))
    cls = next(n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == 'WorkbenchBackend')
    node = next((n for n in cls.body if isinstance(n, ast.FunctionDef) and n.name == name), None)
    if node is None:
        raise AssertionError('Independent analysis route is missing: ' + name)
    scope = {'WorkbenchError': Failure, 'STORE_ID': re.compile(r'[A-Za-z0-9_-]{1,80}\Z'),
             're': re, 'time':time,'hashlib':hashlib,'threading':threading, 'deepcopy': copy.deepcopy, '_MediaReadIntegrations': lambda core: object(),
             'ANALYSIS_QUEUE_ACTIONS': frozenset(('analysis_queue_read','analysis_queue_resume','analysis_queue_pause'))}
    exec(compile(ast.Module(body=[node], type_ignores=[]), '<extracted-real-route>', 'exec'), scope)
    return scope[name]


class Controller:
    def __init__(self, runtime):
        self.calls = []
        self.after = None
    def execute(self, action, user, store_id, data, refresh):
        refresh(fresh=action=='analysis_queue_resume')
        self.calls.append(action)
        if self.after:
            self.after()
        return {'actor': {'username': user['username'], 'storeId': store_id}, 'taskId': data['taskId'],
                'status': 'idle', 'running': False, 'counts': {'total': 200, 'pending':181, 'held':19,'analyzed':0,'missingText':0},
                'canResume':True, 'canPause':False, 'message':'已保存', 'requestId':'', 'code':''}
    def close(self):
        self.stopped = True
    def authorize_collection(self,user,store_id,task_id,refresh):
        self.authorized=(user,store_id,task_id,refresh)


def fixture():
    f = types.SimpleNamespace(closed=False, lock=threading.RLock(), _analysis_queue=None,
                              _analysis_queue_factory=Controller,_analysis_authority_lock=threading.RLock(),_analysis_authorities={})
    f.user = {'id':'u1','tenant_id':'tenant','username':'tester','role':'operator','cloud_bound':True,'_workbench_store_id':'store1'}
    f.profile = {'can_analyze': True}
    f.selected = 'store1'
    f.task = {'id':'task1','tenant_id':'tenant','cloud_owner':'tester','store_id':'store1',
              'platform':'xiaohongshu','account_id':'account1','status':'paused'}
    f.core = types.SimpleNamespace(lock=threading.RLock(), session=lambda token:copy.deepcopy(f.user))
    f._identity = lambda token,**kw:(copy.deepcopy(f.user),copy.deepcopy(f.profile))
    f._analysis_local_identity=lambda token,**kw:(copy.deepcopy(f.user),copy.deepcopy(f.profile))
    f._stores = lambda profile:[{'id':'store1'},{'id':'store2'}]
    f._load_selection = lambda user,stores:{'storeId':f.selected}
    f.platform_runtime = types.SimpleNamespace(_principal=lambda user:user,
                                               _task=lambda user,ident:copy.deepcopy(f.task))
    f._analysis_queue_dispatch = types.MethodType(extracted('_analysis_queue_dispatch'), f)
    f._analysis_queue_refresh = types.MethodType(extracted('_analysis_queue_refresh'), f)
    f._analysis_controller = types.MethodType(extracted('_analysis_controller'), f)
    f._run_collection_with_analysis = types.MethodType(extracted('_run_collection_with_analysis'), f)
    return f


class Contract(unittest.TestCase):
    def test_read_uses_owned_saved_task_even_when_collection_paused(self):
        f=fixture()
        got=f._analysis_queue_dispatch('analysis_queue_read',{'storeId':'store1','taskId':'task1'},'fixture-token')
        self.assertEqual(got['analysisQueue']['counts']['held'],19)
        self.assertEqual(f._analysis_queue.calls,['analysis_queue_read'])
        self.assertEqual(f.task['status'],'paused')

    def test_resume_requires_literal_confirmation(self):
        for confirmation in (None,False,1,'true'):
            f=fixture();data={'storeId':'store1','taskId':'task1'}
            if confirmation is not None:data['confirmed']=confirmation
            with self.assertRaises(Failure):f._analysis_queue_dispatch('analysis_queue_resume',data,'fixture-token')

    def test_scope_and_revoked_permission_fail_before_execute(self):
        for mutation in ('store','owner','tenant','task','permission'):
            f=fixture()
            if mutation=='store':f.selected='store2'
            if mutation=='owner':f.task['cloud_owner']='other'
            if mutation=='tenant':f.task['tenant_id']='other'
            if mutation=='task':f.task['id']='other'
            if mutation=='permission':f.profile['can_analyze']=False
            with self.assertRaises(Failure):
                f._analysis_queue_dispatch('analysis_queue_resume',{'storeId':'store1','taskId':'task1','confirmed':True},'fixture-token')
            self.assertTrue(f._analysis_queue is None or f._analysis_queue.calls==[])

    def test_unknown_field_cannot_supply_actor_or_endpoint(self):
        f=fixture()
        with self.assertRaises(Failure):f._analysis_queue_dispatch('analysis_queue_read',{'storeId':'store1','taskId':'task1','owner':'other'},'fixture-token')

    def test_response_is_not_returned_after_scope_switch(self):
        f=fixture();f._analysis_queue=Controller(f.platform_runtime)
        f._analysis_queue.after=lambda:setattr(f,'selected','store2')
        with self.assertRaises(Failure):f._analysis_queue_dispatch('analysis_queue_read',{'storeId':'store1','taskId':'task1'},'fixture-token')

    def test_real_dispatch_routes_analysis_before_general_action_deny(self):
        f=fixture();dispatch=extracted('_dispatch')
        self.assertEqual(dispatch(f,'analysis_queue_read',{'storeId':'store1','taskId':'task1'},'fixture-token')['analysisQueue']['taskId'],'task1')

    def test_host_whitelist_and_existing_guard_are_preserved(self):
        source=(NATIVE/'ui_native_host.py').read_text(encoding='utf-8-sig')
        tree=ast.parse(source);scope={}
        nodes=[n for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(x,ast.Name) and x.id=='API_ACTIONS' for x in n.targets)]
        for node in nodes:
            # MEDIA_ACTIONS is only a separate fixed action set in this fixture.
            scope['MEDIA_ACTIONS']=frozenset()
            exec(compile(ast.Module(body=[node],type_ignores=[]),'<host-actions>','exec'),scope)
        self.assertTrue({'analysis_queue_read','analysis_queue_resume','analysis_queue_pause'}<=scope['API_ACTIONS'])
        self.assertIn("self.headers.get('Origin') != origin",source)
        self.assertIn("hmac.compare_digest(self.headers.get('X-Fangyu-CSRF', ''), self.server.csrf_token)",source)

    def test_collection_authorization_is_local_thread_bound_and_temporary(self):
        f=fixture()
        f._identity=lambda *a,**kw:(_ for _ in ()).throw(AssertionError('synchronous authorization performed network verification'))
        def start(user,payload):
            slot=f.platform_runtime._analysis_collection_authorization
            self.assertTrue(callable(slot.callback))
            other=[]
            worker=threading.Thread(target=lambda:other.append(getattr(slot,'callback',None)))
            worker.start();worker.join(1)
            self.assertEqual(other,[None])
            controller=slot.callback(user,'task1')
            self.assertIs(controller,f._analysis_queue)
            self.assertEqual(controller.authorized[1:3],('store1','task1'))
            self.assertEqual(controller.calls,[])
            return {'taskId':'task1'}
        f.platform_runtime.start_acquisition=start
        self.assertEqual(f._run_collection_with_analysis('start_acquisition',f.user,{},'fixture-token',f.profile),{'taskId':'task1'})
        self.assertFalse(hasattr(f.platform_runtime._analysis_collection_authorization,'callback'))

    def test_collection_hook_is_removed_when_start_raises(self):
        f=fixture()
        def fail(user,payload):raise Failure('SYNTHETIC','fixture start failed',409)
        f.platform_runtime.start_acquisition=fail
        with self.assertRaises(Failure):f._run_collection_with_analysis('start_acquisition',f.user,{},'fixture-token',f.profile)
        self.assertFalse(hasattr(f.platform_runtime._analysis_collection_authorization,'callback'))


if __name__=='__main__':unittest.main(verbosity=2)
