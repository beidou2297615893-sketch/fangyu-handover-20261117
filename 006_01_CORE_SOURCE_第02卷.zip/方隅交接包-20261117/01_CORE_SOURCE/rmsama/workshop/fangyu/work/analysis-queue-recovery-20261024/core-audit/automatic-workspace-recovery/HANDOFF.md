# 自动门店分析候选交接

产品源码已封定并停止编辑：`candidate/analysis_queue_runtime.py`，SHA256 `9520b2f3d2efddfc2a2e341655c8e30a84074eb54d81bab01b13cae4c5c208b3`。机器清单为 `evidence/VALIDATION.json`，封定入口为 `SEALED.json`。基线是实际 F103 冻结模块，历史 F101/F102/F103、旧候选及证据没有覆盖。

Backend 成功登录、恢复会话或选择授权门店后调用 `authorize_workspace(user, store_id, refreshWorkspace, refreshTaskFactory)`。同步入口只登记 RAM 并唤醒独立单线程；无 SQL、网络或模型同步工作。相同员工、会话和门店回入仅更新回调，不清除本人暂停、安全阻断或唤醒已清空队列。

`execute_workspace(action, user, store_id, {storeId}, refreshWorkspace, refreshTaskFactory)` 接收 `analysis_workspace_read/pause/resume`。新 workspace 入口不要求 taskId 或二次确认。旧 task 入口继续先核原字段、确认及任务归属，再映射唯一工作区消费者，避免产生第二个 worker。

工作区按当前员工、当前授权门店查询小字段和候选任务 ID，逐任务复用原 `_work`、原 `analyze_pending`、LocalAIAttempts、同帖最多 20 条、共享 Core gate 与原权限/预算/CAS。暂停采集、验证码、页面切换不取消分析。当前门店中新页和旧积压都会进入同一队列；没有自动启动采集、CLI 或发送功能。本人暂停分析持久保存，关软件、登出或换店只撤销 RAM 授权。新超时、未知请求、权限或预算错误会阻断整条自动队列，重开不会盲目续发该失败请求。

冷开没有 executor 时，只在有可分析评论且 fresh 身份核对成功后，后台核对已绑定本机及 `explicit_local`，调用原 `AssistantService.start` 并等原 executor 就绪。没有调用平台 `prepare`、配置或下载 CLI、配对账号、开启全局 AIWorker。原只读专用模式、非本人设备、撤权和连接失败均失败关闭。

状态六类闭合：`total = pending + processing + held + analyzed + missingText`；`remaining = pending + processing`。只有本 worker 当前 UUID、submission 且仍处于 submitted/response_received、尚无判断的实际子集才算 processing；旧 unknown、其他请求和阻断后的新 unknown 都属于待核。validated 尚未写入判断时仍是 pending，未当成完成。processing 查询按已有 `(entity,id)` 主键点读最多 20 条。

计数缓存复用 Backend 注入的 `refreshWorkspace.local_revision(db,user,storeId)` 和原 CustomerReadStore 的精确 durable schema/version/epoch/revision；不新增迁移、不用 `data_version`。AI attempts 另含 count/max(rowid) 及 submitted、response_received、unknown 各状态计数，因为原 journal 的状态变更使用 UPDATE，不总换 rowid。processing/运行状态不缓存。无可信版本时回退一致只读投影。可信空队列在候选查询前命中缓存，空闲轮询不反复读历史正文或 AI 对象。

当前精确模块通过 26 个 workspace、18 个原 task、12 个旧状态窄容错测试。均为隔离 SQLite、原批次选择和请求账本，加合成权限/模型传输；真实云、模型、CLI 调用和生产数据读写均为零。2068 比例样例保留原 1794 条判断、9 条原 UUID 待核、21 条缺正文，自动新增 244 条判断，全程 0 手动 resume。首轮 15 秒样例等待超时、缓存、processing、主键查询及兼容合同的红例已保留，未写成最终通过。

Root 可用 `verify_workspace_candidate.ps1 -SourceProject <F104 project> -ReleaseDir <F104 release> -OutputDir <new directory>` 对实际冻结资源复验。该 runner 将测试副本放入新证据目录，不覆盖作者证据；不安装、不操作当前 Native。最终生产调用和真实计费/分析增长仍由 Root 在实际软件中核对，不能用这些隔离测试代替。
