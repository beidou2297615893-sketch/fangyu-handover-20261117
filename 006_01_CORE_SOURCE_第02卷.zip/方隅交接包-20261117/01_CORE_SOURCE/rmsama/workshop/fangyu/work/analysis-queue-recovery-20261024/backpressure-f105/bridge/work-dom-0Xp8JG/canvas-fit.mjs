import {DESIGN_VIEWPORTS,paneHeight} from './viewport-layout.mjs';
const sizes=DESIGN_VIEWPORTS;
function start(){
  const app=document.getElementById('app');if(!app)return;
  let queued=false,contentChanged=false,lastPage='';
  const post=message=>{if(parent!==window)parent.postMessage(message,location.origin);};
  function measure(){
    queued=false;
    const page=document.body.dataset.page;if(!Object.hasOwn(sizes,page))return;
    document.documentElement.style.setProperty('--canvas-height',sizes[page][1]+'px');
    const footer=app.querySelector('.platform-switch');
    if(footer){
      const compact=getComputedStyle(footer).position!=='fixed';
      const footerTop=footer.getBoundingClientRect().top;
      for(const [selector,variable] of [['.reply-page.rp-connected .rp-workspace','--reply-pane-height'],['.customers-page.cs-connected .cs-workspace','--customer-pane-height'],['.br-card','--rule-pane-height']]){
        const node=app.querySelector(selector);if(!node)continue;
        const height=paneHeight({viewportHeight:innerHeight,top:node.getBoundingClientRect().top,footerTop,compact});
        const value=height+'px';if(node.style.getPropertyValue(variable)!==value)node.style.setProperty(variable,value);
      }
    }

    if(contentChanged){contentChanged=false;if(page!==lastPage){lastPage=page;post({type:'fangyu-canvas-change',page});}}
    requestAnimationFrame(()=>post({type:'fangyu-canvas-size',page,
      viewportWidth:innerWidth,viewportHeight:innerHeight,
      contentHeight:Math.max(Math.ceil(app.getBoundingClientRect().height-.01),document.documentElement.scrollHeight)}));
  }
  function queue(changed=false){contentChanged ||= changed;if(!queued){queued=true;requestAnimationFrame(measure);}}
  window.addEventListener('message',event=>{
    if(event.source!==parent||event.origin!==location.origin||event.data?.type!=='fangyu-canvas-viewport')return;
    const y=event.data.layoutY;if(!Number.isFinite(y)||y<=0)return;
    document.documentElement.style.setProperty('--layout-y',String(y));queue();
  });
  new MutationObserver(()=>queue(true)).observe(app,{childList:true,subtree:true,characterData:true});
  new ResizeObserver(()=>queue()).observe(app);
  window.addEventListener('resize',()=>queue());document.fonts?.ready.then(()=>queue());queue(true);
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start,{once:true});else start();
