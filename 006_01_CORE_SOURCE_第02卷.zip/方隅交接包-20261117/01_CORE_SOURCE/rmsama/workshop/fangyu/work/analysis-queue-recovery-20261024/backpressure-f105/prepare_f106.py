"""Reject inactive F105; CAS restore only Root's three mutable sources."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,shutil
D=Path(__file__).resolve().parent;W=D.parent;P=W.parents[1];PACK=W/'package'
read=lambda p:json.loads(p.read_text('utf-8-sig'));sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert read(P/'work/ui-native-r57/FROZEN.json')['release_id']=='ui-r57-20261024T153411Z-4c9dd686'
pins=read(PACK/'ROOT-FINAL-PINS-V105.json')
assert pins['installed'] is False
rows=read(PACK/'ROOT-COMPOSITION-V105.json')['changes']
public=P/'work/complete-product-resume-20261024/live-acquisition-acceptance-20261024/project'
backup=PACK/'public-before-f105'
assert len(rows)==3
for row in rows:
 rel=row['relativePath'];assert sha(public/rel)==row['sha256'];assert sha(backup/rel)==row['baselineSha256']
for row in rows:shutil.copy2(backup/row['relativePath'],public/row['relativePath'])
for row in rows:assert sha(public/row['relativePath'])==row['baselineSha256']
pins.update(status='BLOCKED_LOCK_ORDER_NOT_FOR_INSTALL',blockedReason='Core-to-controller / controller-to-Core lock cycle in candidate; no install performed')
(PACK/'ROOT-FINAL-PINS-V105.json').write_text(json.dumps(pins,ensure_ascii=False,indent=2)+'\n','utf-8')
report={'atUtc':datetime.now(timezone.utc).isoformat(),'sourceFilesCASRestoredToActualF104':[r['relativePath'] for r in rows],
 'inactiveF105Preserved':True,'canonicalUnchangedF104':True,'productionWrites':0,'nativeWindowsOperated':0,
 'lockEvidence':str(D/'independent/LOCK-ORDER-BLOCKING.json')}
with (D/'F105-BLOCKED-AND-PUBLIC-RESTORED.json').open('x',encoding='utf-8') as f:f.write(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
for old,new in [('compose_f105.py','compose_f106.py'),('install_verified_f105.py','install_verified_f106.py'),('verify_f105.py','verify_f106.py'),('formal_preservation_f105.py','formal_preservation_f106.py'),('check_installed_f105.py','check_installed_f106.py')]:
 body=(W/old).read_text('utf-8')
 body=body.replace('candidate-unified-v105','candidate-unified-v106').replace('V105','V106').replace('F105','F106')
 body=body.replace('public-before-f105','public-before-f106').replace('entry-v105','entry-v106').replace('verification-f105','verification-f106')
 body=body.replace('existing_f105_freezer','existing_f106_freezer').replace('formal_preservation_f105','formal_preservation_f106')
 # Keep task folder backpressure-f105 as the unchanged provenance root.
 if old=='verify_f105.py':
  body=body.replace("D/'core/SEALED.json'","D/'core/v2/SEALED.json'")
  body=body.replace("D/'independent/CANDIDATE-ACCEPTANCE.json'","D/'independent/CANDIDATE-V2-ACCEPTANCE.json'")
  body=body.replace("D/'independent/CANDIDATE-ACCEPTANCE.log'","D/'independent/CANDIDATE-V2-ACCEPTANCE.log'")
  body=body.replace("W/'compose_f105.py'","W/'compose_f106.py'")
 compile(body,new,'exec')
 with (W/new).open('x',encoding='utf-8') as f:f.write(body)
print(json.dumps(report,ensure_ascii=False))
