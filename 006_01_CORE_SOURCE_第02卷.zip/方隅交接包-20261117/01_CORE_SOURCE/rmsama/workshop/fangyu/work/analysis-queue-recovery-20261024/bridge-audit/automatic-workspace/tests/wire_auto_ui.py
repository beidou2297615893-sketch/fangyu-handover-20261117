from pathlib import Path
root=Path(__file__).resolve().parents[1]/'candidate/work/ui-approved-implementation/ui-preview'
def replace(name,old,new):
 p=root/name;s=p.read_text('utf-8-sig')
 if new in s:return
 assert s.count(old)==1,(name,old,s.count(old))
 p.write_text(s.replace(old,new),'utf-8',newline='\n')
replace('backend.mjs',"const analysisLocal=['analysis_queue_read','analysis_queue_resume','analysis_queue_pause'].includes(action),analysisRead=action==='analysis_queue_read';",
 "const analysisLocal=['analysis_queue_read','analysis_queue_resume','analysis_queue_pause','analysis_workspace_read','analysis_workspace_resume','analysis_workspace_pause'].includes(action),analysisRead=['analysis_queue_read','analysis_workspace_read'].includes(action);")
replace('backend.mjs',"if(!['analysis_queue_read','analysis_queue_resume','analysis_queue_pause'].includes(action))",
 "if(!['analysis_queue_read','analysis_queue_resume','analysis_queue_pause','analysis_workspace_read','analysis_workspace_resume','analysis_workspace_pause'].includes(action))")
replace('pages/acquire.mjs','bindSavedCommentAnalysis,savedCommentAnalysisView}', 'bindSavedCommentAnalysis,savedCommentAnalysisView,analysisBufferMessage}')
replace('pages/acquire.mjs',"  const operation=state.pendingAction?.action;", "  const bufferMessage=analysisBufferMessage(state,live);if(bufferMessage){title='采集缓冲已暂停';message=bufferMessage;stage='paused';}\n  const operation=state.pendingAction?.action;")
replace('pages/acquire.mjs',":category?'已保留采集进度，请按上方提示处理。':live.analysis?.hold?", ":category?'已保留采集进度，请按上方提示处理。':bufferMessage?bufferMessage:live.analysis?.hold?")
replace('pages/acquire.mjs','<dt>当前任务待分析 / 原请求待核</dt>', '<dt>本店后台待分析 / 原请求待核</dt>')
replace('pages/acquire.mjs','<dt>本批分析来源</dt>', '<dt>原任务模型记录</dt>')
replace('pages/acquire.mjs',"  const message=state.sourceInteractionPending?", "  let message=state.sourceInteractionPending?")
replace('pages/acquire.mjs',"  const label=state.sourceInteractionPending?", "  const bufferMessage=analysisBufferMessage(state,live);if(bufferMessage&&!state.busy&&!state.platformError&&!state.connectionRecovering)message=bufferMessage;\n  const label=state.sourceInteractionPending?")
