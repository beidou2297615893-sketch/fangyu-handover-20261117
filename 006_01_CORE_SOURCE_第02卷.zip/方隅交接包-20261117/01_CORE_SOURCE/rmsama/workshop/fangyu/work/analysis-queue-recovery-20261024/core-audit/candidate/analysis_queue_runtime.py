"""Explicit, task-scoped saved-comment analysis, independent of collection.

Construction/read never starts work. The original workflow/attempt journal owns
provider policy, budgets, billing uncertainty, validation and result CAS.
"""
from copy import copy, deepcopy
from datetime import datetime, timezone
import hashlib
import json
import re
import threading
from uuid import uuid4

from assistant.ai_attempts import _digest
from assistant.ai_workflow import LocalAIWorkflow, post_identity

ACTIONS=frozenset(('analysis_queue_read','analysis_queue_resume','analysis_queue_pause'))
ENTITY='ui_task_analysis_control_v1'
PENDING_ENTITY='workbench_collection_page_analysis_v1'
UNRESOLVED=frozenset(('unknown','submitted','response_received'))
KEY=re.compile(r'[A-Za-z0-9_-]{1,160}\Z')
ACTOR_FIELDS=('id','tenant_id','username','role','cloud_bound')
_CORE_GATE_INIT=threading.Lock()

class AnalysisQueueError(ValueError):
    def __init__(self,code,message,status=409):
        super().__init__(message);self.code,self.status=code,status

def fail(code,message,status=409):raise AnalysisQueueError(code,message,status)
def stamp():return datetime.now(timezone.utc).isoformat()

class AnalysisQueueRuntime:
    def __init__(self,runtime,*,workflow_factory=None):
        if runtime is None:fail('ANALYSIS_RUNTIME_REQUIRED','分析服务尚未就绪',503)
        self.runtime,self.core=runtime,runtime.core
        self.workflow_factory=workflow_factory or LocalAIWorkflow
        self.lock=threading.RLock();self.active=None;self.closed=False;self.authorizations={}
        # Logout/store switch may replace the controller while an old request is
        # still returning. Keep one model worker on this Core across that change.
        with _CORE_GATE_INIT:
            gate=getattr(self.core,'_saved_comment_analysis_gate',None)
            if gate is None:
                gate=threading.Lock();self.core._saved_comment_analysis_gate=gate
            self.worker_gate=gate

    def close(self):
        # May be called while Backend/Core locks are held. Never join here.
        with self.lock:
            self.closed=True
            self.authorizations.clear()
            if self.active:self.active['stop'].set();self.active['wake'].set()

    def wait_for_idle(self,seconds=0):
        """Test/controlled teardown seam; never called by normal close/logout."""
        with self.lock:thread=self.active.get('thread') if self.active else None
        if thread and thread is not threading.current_thread():thread.join(seconds)
        return not thread or not thread.is_alive()

    def _scope(self,user,store_id,task_id,refresh,*,expected=None,analyzing=False,local_only=False,fresh=False):
        if self.closed or getattr(self.runtime,'closed',False):
            fail('ANALYSIS_CLOSED','本次分析已停止，请重新读取',503)
        current,profile=(dict(user),{'_workbench_store_id':store_id}) if local_only else refresh(fresh=fresh)
        if (not isinstance(current,dict) or not isinstance(profile,dict)
                or any(current.get(k)!=user.get(k) for k in ACTOR_FIELDS)
                or current.get('cloud_bound') is not True or current.get('role') not in ('operator','admin')):
            fail('ANALYSIS_AUTH_CHANGED','员工身份已变化，本次分析已停止',403)
        if profile.get('_workbench_store_id',profile.get('store_id'))!=store_id:
            fail('ANALYSIS_SCOPE_CHANGED','当前门店已变化，本次分析已停止',403)
        if analyzing and (current.get('can_analyze') is False or profile.get('can_analyze') is False):
            fail('ANALYSIS_PERMISSION_DENIED','当前员工没有分析权限',403)
        executor=getattr(getattr(self.runtime,'service',None),'executor',None)
        if executor is None or getattr(executor,'core',None) is not self.core:
            fail('ANALYSIS_RUNTIME_REQUIRED','原分析服务尚未就绪，请重新连接工作台',503)
        with self.core.lock:
            saved=self.core.store.get('users',current.get('id'))
            if (not saved or saved.get('disabled') or any(saved.get(k)!=current.get(k) for k in ACTOR_FIELDS)):
                fail('ANALYSIS_AUTH_CHANGED','员工登录已变化，本次分析已停止',403)
            if analyzing and saved.get('can_analyze') is False:
                fail('ANALYSIS_PERMISSION_DENIED','当前员工没有分析权限',403)
            task=self.core.store.get('tasks',task_id)
            if (not task or task.get('tenant_id')!=current['tenant_id']
                    or task.get('cloud_owner')!=current['username'] or task.get('store_id')!=store_id
                    or task.get('platform') not in ('xiaohongshu','douyin')
                    or getattr(executor,'tenant',None)!=current['tenant_id']
                    or getattr(executor,'owner',None)!=current['username']
                    or getattr(executor,'user_id',None)!=current['id']):
                fail('ANALYSIS_SCOPE_CHANGED','只能分析当前门店中本人的原采集任务',403)
            self.core._task_access(current,task,current['tenant_id'])
            account=self.core.store.get('accounts',task.get('account_id'))
            if (not account or account.get('tenant_id')!=current['tenant_id']
                    or account.get('cloud_owner')!=current['username'] or account.get('store_id')!=store_id
                    or account.get('platform')!=task.get('platform')):
                fail('ANALYSIS_SCOPE_CHANGED','原任务账号归属已变化，本次分析已停止',403)
            binding=self.runtime._collection_binding(task)
            # Collection status/counters/captcha are intentionally absent.
            scope={'actor':{k:current.get(k) for k in ACTOR_FIELDS},'storeId':store_id,'taskId':task_id,
                'binding':deepcopy(binding),'company':_digest(executor.server.company),
                'host':_digest(executor.ai.attempts.host_context())}
            if expected is not None and scope!=expected:
                fail('ANALYSIS_SCOPE_CHANGED','原任务、企业配置或设备范围已变化，本次分析已停止',403)
            if analyzing:executor._require_product_feature('intent_analysis')
        return current,task,executor,scope

    def authorize_collection(self,user,store_id,task_id,refresh):
        """Only the synchronous explicit start/resume hook may register this.

        No refresh callback, worker, cloud or model runs in this method.
        """
        current,task,executor,scope=self._scope(user,store_id,task_id,refresh,analyzing=True,local_only=True)
        with self.lock:
            active=self.active
            if active and active.get('thread') and active['thread'].is_alive() and active['scope']!=scope:
                if not self._retire_dormant(active):
                    fail('ANALYSIS_QUEUE_BUSY','原任务的分析尚未结束，请先暂停分析',409)
            self.authorizations[task_id]={'user':deepcopy(current),'storeId':store_id,'taskId':task_id,
                'scope':scope,'refresh':refresh,'blocked':False}
        return self

    def _retire_dormant(self,run):
        if run.get('working') or run['status'] not in ('completed','held'):return False
        run['retired']=True;run['stop'].set();run['wake'].set()
        grant=self.authorizations.get(run['taskId'])
        if grant:grant['blocked']=True
        return True

    def owns_collection(self,task_id):
        with self.lock:return not self.closed and task_id in self.authorizations

    def collection_state(self,task_id):
        """Local backpressure observation only; no identity/cloud/provider read."""
        with self.lock:
            run=self.active
            if not run or run['taskId']!=task_id:return 'idle'
            return 'running' if run.get('working') and run.get('thread') and run['thread'].is_alive() else run['status']

    def _launch(self,grant,*,collection=False):
        run={**grant,'stop':threading.Event(),'wake':threading.Event(),'requestId':uuid4().hex,
            'status':'running','code':'','working':True,'collection':collection}
        self.active=run;self._record(run,'running')
        thread=threading.Thread(target=self._work,args=(run,),name='explicit-task-analysis-'+run['taskId'],daemon=True)
        run['thread']=thread
        try:thread.start()
        except BaseException:
            self._record(run,'blocked','ANALYSIS_START_UNCONFIRMED');raise
        return run

    def notify_saved(self,task_id):
        """Wake only a pre-authorized task; never infer permission from a read."""
        with self.lock:
            grant=self.authorizations.get(task_id)
            if self.closed or not grant or grant.get('blocked'):return False
            active=self.active
            if active and active.get('thread') and active['thread'].is_alive():
                if active['scope']!=grant['scope']:
                    if not active.get('retired'):return False
                else:
                    active['working']=True;active['wake'].set();return True
            self._launch(grant,collection=True)
            return True

    def _guard(self,run,*,fresh=False):
        if run['stop'].is_set():fail('ANALYSIS_QUEUE_PAUSED','本人已暂停分析；已有结果保留')
        value=self._scope(run['user'],run['storeId'],run['taskId'],run['refresh'],expected=run['scope'],analyzing=True,fresh=fresh)
        if run['stop'].is_set():fail('ANALYSIS_QUEUE_PAUSED','本人已暂停分析；已有结果保留')
        return value

    @staticmethod
    def _confirmed(value):
        return isinstance(value,dict) and value.get('status') in ('graded','uncertain','unrelated') and (
            value.get('level') in ('super_high','high','medium','low','very_low') if value['status']=='graded' else value.get('level') is None)

    def _inventory(self,user,task,executor):
        with self.core.lock:
            reader=getattr(self.core.store,'list_task_leads',None)
            rows=reader(user['tenant_id'],task['id']) if callable(reader) else self.core.store.list('leads',user['tenant_id'])
            rows=list(executor._analysis_visible_leads(user,task,rows=rows))
            rows=[row for row in rows if row.get('task_id')==task['id'] and not row.get('demo')]
            attempts=[row for row in self.core.store.list('ai_attempts',user['tenant_id'])
                if row.get('owner')==user['username'] and row.get('operation')=='intent_analyze' and row.get('state') in UNRESOLVED]
            held_hashes=set().union(*(set(row.get('lead_digests') or []) for row in attempts)) if attempts else set()
            counts=dict(total=len(rows),pending=0,held=0,analyzed=0,missingText=0)
            pending=[];held_ids=set()
            for row in rows:
                value=row.get('manual_intent') or row.get('ai_intent')
                if self._confirmed(value):counts['analyzed']+=1
                elif row.get('manual_intent') or row.get('ai_intent'):
                    counts['held']+=1;held_ids.add(row['id'])
                elif _digest([user['tenant_id'],user['username'],row['id']]) in held_hashes:
                    counts['held']+=1;held_ids.add(row['id'])
                elif not isinstance(row.get('text'),str) or not row['text'].strip():counts['missingText']+=1
                else:counts['pending']+=1;pending.append(row)
            matching=[row for row in attempts if any(_digest([user['tenant_id'],user['username'],ident]) in set(row.get('lead_digests') or []) for ident in held_ids)]
            return counts,pending,matching

    def _record_id(self,user,store_id,task_id):return _digest([user['tenant_id'],user['id'],store_id,task_id])

    def _dispatch_batch_guard(self,user,task,executor,ids,payload):
        """Do not mistake this workflow's just-registered attempt for old hold."""
        with self.core.lock:
            rows=[self.core.store.get('leads',ident) for ident in ids]
            rows=list(executor._analysis_visible_leads(user,task,rows=[row for row in rows if row]))
            if ({row['id'] for row in rows}!=ids or any(row.get('ai_intent') or row.get('manual_intent')
                    or not isinstance(row.get('text'),str) or not row['text'].strip() for row in rows)):
                fail('ANALYSIS_SCOPE_CHANGED','本批原评论或已有判断已变化，未重新提交',409)
            hashes={_digest([user['tenant_id'],user['username'],ident]) for ident in ids}
            for row in self.core.store.list('ai_attempts',user['tenant_id']):
                if (row.get('owner')!=user['username'] or row.get('state') not in UNRESOLVED
                        or not hashes.intersection(row.get('lead_digests') or [])):continue
                own_submission=(row.get('state')=='submitted' and payload.get('request_id')
                    and row.get('request_id')==payload.get('request_id')
                    and payload.get('submission_id') and row.get('submission_id')==payload.get('submission_id'))
                if not own_submission:
                    fail('PRODUCT_REQUEST_UNKNOWN','本批原评论已有待核请求，未重新提交',409)

    def _record(self,run,status,code=''):
        row={'id':self._record_id(run['user'],run['storeId'],run['taskId']),'tenant_id':run['user']['tenant_id'],
            'owner':run['user']['username'],'userId':run['user']['id'],'storeId':run['storeId'],'taskId':run['taskId'],
            'requestId':run['requestId'],'status':status,'code':code,'updated_at':stamp()}
        self.core.store.put(ENTITY,row)
        with self.lock:run['status'],run['code']=status,code

    def _snapshot(self,user,store_id,task,executor):
        counts,_,_=self._inventory(user,task,executor)
        with self.lock:
            run=self.active
            same=bool(run and run['taskId']==task['id'] and run['storeId']==store_id and run['user']['id']==user['id'])
            thread_alive=bool(same and run.get('thread') and run['thread'].is_alive())
            running=bool(thread_alive and run.get('working',True))
            saved=self.core.store.get(ENTITY,self._record_id(user,store_id,task['id'])) or {}
            status=run['status'] if same else saved.get('status','idle')
            code=run['code'] if same else saved.get('code','')
            ident=run['requestId'] if same else saved.get('requestId','')
            if not running and status=='running':status='paused';code='ANALYSIS_AUTH_EXPIRED'
            if not running and status not in ('paused','blocked'):
                status='held' if not counts['pending'] and counts['held'] else 'completed' if not counts['pending'] and not counts['held'] else 'idle'
        message=('正在分析已保存评论；采集暂停不影响本次分析' if running else
            '原请求结果仍待核对，已保留；没有重复分析这些评论' if status=='held' else
            '可分析评论已处理，缺正文记录仍保留待核实' if status=='completed' and counts['missingText'] else
            '已保存的可分析评论已处理' if status=='completed' else
            '分析已停止，原评论与已有判断保持；请核对后手动继续' if status in ('paused','blocked') else
            '只分析本任务已保存评论；不会开始采集或发送回复')
        return {'actor':{'username':user['username'],'storeId':store_id},'taskId':task['id'],'status':status,'running':running,
            'counts':counts,'canResume':not running and (counts['pending']>0 or counts['held']>0),
            'canPause':thread_alive,'message':message,'requestId':ident,'code':code}

    def execute(self,action,user,store_id,data,refresh):
        expected={'storeId','taskId','confirmed'} if action=='analysis_queue_resume' else {'storeId','taskId'}
        if (action not in ACTIONS or not isinstance(data,dict) or set(data)!=expected
                or data.get('storeId')!=store_id or not isinstance(data.get('taskId'),str) or not KEY.fullmatch(data['taskId'])
                or not callable(refresh)):
            fail('ANALYSIS_INPUT_INVALID','请选择当前门店的原采集任务',400)
        if action=='analysis_queue_resume' and data['confirmed'] is not True:
            fail('ANALYSIS_CONFIRM_REQUIRED','请确认只分析本任务已保存评论',400)
        current,task,executor,scope=self._scope(user,store_id,data['taskId'],refresh,
            analyzing=action=='analysis_queue_resume',fresh=action=='analysis_queue_resume')
        if action=='analysis_queue_read':return self._snapshot(current,store_id,task,executor)
        if action=='analysis_queue_pause':
            with self.lock:
                run=self.active
                if run and run['taskId']==task['id'] and run['storeId']==store_id and run['user']['id']==current['id']:
                    run['stop'].set();run['wake'].set();self._record(run,'paused','ANALYSIS_QUEUE_PAUSED')
                    grant=self.authorizations.get(task['id'])
                    if grant:grant['blocked']=True
            return {**self._snapshot(current,store_id,task,executor),'accepted':True}
        with self.lock:
            active=self.active
            if active and active.get('thread') and active['thread'].is_alive():
                if active['scope']!=scope:
                    if not self._retire_dormant(active):
                        fail('ANALYSIS_QUEUE_BUSY','另一项已授权分析尚未结束，请先暂停',409)
                else:
                    if active['stop'].is_set():fail('ANALYSIS_QUEUE_STOPPING','原分析正在结束，请核对后再继续',409)
                    active['working']=True;active['wake'].set()
                    return {**self._snapshot(current,store_id,task,executor),'accepted':True}
            grant={'user':deepcopy(current),'storeId':store_id,'taskId':task['id'],'scope':scope,'refresh':refresh}
            previous=self.authorizations.get(task['id'])
            if previous:previous['blocked']=False
            self._launch(grant,collection=previous is not None)
        return {**self._snapshot(current,store_id,task,executor),'accepted':True}

    def _sync_confirmed_queue(self,user,task):
        """Only shrink confirmed IDs; preserve held IDs, source binding and code."""
        with self.core.lock:
            row=self.core.store.get(PENDING_ENTITY,task['id'])
            if (not row or row.get('tenant_id')!=user['tenant_id'] or row.get('owner')!=user['username']
                    or row.get('binding')!=self.runtime._collection_binding(task) or not isinstance(row.get('lead_ids'),list)):return
            remaining=[ident for ident in row['lead_ids'] if not self._confirmed((self.core.store.get('leads',ident) or {}).get('manual_intent')
                or (self.core.store.get('leads',ident) or {}).get('ai_intent'))]
            if remaining!=row['lead_ids']:
                self.core.store.put(PENDING_ENTITY,{**row,'lead_ids':remaining,'status':'pending' if remaining else 'completed',
                    'code':row.get('code','') if remaining else '','updated_at':stamp()})

    def _work(self,run):
        acquired=False
        try:
            while not self.worker_gate.acquire(timeout=.05):
                if run['stop'].is_set() or self.closed:
                    fail('ANALYSIS_QUEUE_PAUSED','本人已暂停分析；原请求结果仍保留')
            acquired=True
            user,task,executor,_=self._guard(run)
            _,_,held=self._inventory(user,task,executor)
            for row in held:
                self._guard(run)
                # Exact original UUID only. A status response never releases or
                # rewrites a local unknown attempt, and cannot execute a model.
                executor.ai.attempts.status(user,{'request_id':row['request_id']})
                self._guard(run)
            while True:
                run['wake'].clear()
                user,task,executor,_=self._guard(run)
                counts,pending,_=self._inventory(user,task,executor)
                if not pending:
                    self._sync_confirmed_queue(user,task)
                    self._record(run,'held' if counts['held'] else 'completed')
                    with self.lock:run['working']=False
                    if not run.get('collection'):return
                    # Dormant, explicitly authorized consumer. It makes no
                    # cloud/model request until a saved page or explicit click.
                    run['wake'].wait()
                    self._guard(run)
                    with self.lock:run['working']=True
                    self._record(run,'running')
                    continue
                group_key=post_identity(pending[0])
                batch=[row for row in pending if post_identity(row)==group_key][:20]
                ids={row['id'] for row in batch}
                original_ai=executor.ai
                def guarded_cloud(actor,operation,payload):
                    # Ordinary guards and UI polls use only the valid local
                    # session/scope snapshot. Fresh remote authority is checked
                    # around the actual provider operation, not every local read.
                    current_scope=self._guard(run,fresh=operation=='intent_analyze')
                    if operation not in ('ai_profile','intent_analyze','ai_attempt_status'):
                        fail('ANALYSIS_OPERATION_FORBIDDEN','分析操作不在当前授权范围',403)
                    if operation=='intent_analyze':
                        actor,current,active_executor,_=current_scope
                        self._dispatch_batch_guard(actor,current,active_executor,ids,payload)
                    result=original_ai.cloud(actor,operation,payload)
                    self._guard(run,fresh=operation=='intent_analyze')
                    return result
                ai=self.workflow_factory(self.core,guarded_cloud,company=original_ai.company,host_context=original_ai.attempts.host_context)
                selected=copy(executor);selected.ai=ai
                original_visible=executor._analysis_visible_leads
                selected._analysis_visible_leads=lambda actor,current,rows=None:(row for row in original_visible(actor,current,rows=rows) if row['id'] in ids)
                # Reuse original semantic selection and all workflow/attempt CAS.
                # Original default replace_existing=False remains mandatory.
                selected.analyze_pending(user,{'task_id':task['id']},explicit_retry=False)
                self._guard(run)
                after,_,_=self._inventory(user,task,executor)
                if after['analyzed']<=counts['analyzed']:
                    fail('ANALYSIS_RESULT_UNCONFIRMED','本批结果尚未完整保存，已停止；不会自动重提',409)
                self._sync_confirmed_queue(user,task)
        except Exception as error:
            code=getattr(error,'code',None)
            if not isinstance(code,str) or not re.fullmatch(r'[A-Z_]{1,80}',code):code='ANALYSIS_UNAVAILABLE'
            status='paused' if run['stop'].is_set() or code=='ANALYSIS_QUEUE_PAUSED' else 'blocked'
            try:self._record(run,status,code)
            except Exception:
                with self.lock:run['status'],run['code']=status,code
            with self.lock:
                run['working']=False
                grant=self.authorizations.get(run['taskId'])
                if grant and grant['scope']==run['scope']:grant['blocked']=True
        finally:
            if acquired:self.worker_gate.release()

__all__=['ACTIONS','AnalysisQueueError','AnalysisQueueRuntime']
