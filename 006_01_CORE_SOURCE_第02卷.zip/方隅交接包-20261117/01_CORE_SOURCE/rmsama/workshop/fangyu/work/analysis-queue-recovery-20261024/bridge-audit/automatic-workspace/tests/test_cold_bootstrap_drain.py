"""Actual Backend bootstrap/identity -> actual AssistantService.start/_run.

All Core storage is a dedicated fixture SQLite. Only external identity,
heartbeat/model transports, journal and executor factory are injected.
The service starts with executor=None; no analysis button or platform poll runs.
"""
from pathlib import Path
import ast,copy,hashlib,importlib.util,io,json,logging,os,socket,sys,threading,time,types,unittest
from unittest.mock import patch
from test_auto_bridge import fixture,method,Integration,ROOT,Failure
sys.dont_write_bytecode=True
CORE=ROOT.parents[1]/'core-audit/automatic-workspace-recovery'
PROJECT=Path('C:/积木软件工坊/项目/方隅公寓客户版/work/parallel-integration-20261018/final-integration/candidate-unified-v103/project')
os.environ['ANALYSIS_QUEUE_CONTROLLER']=os.environ.get('AUTOMATIC_CONTROLLER',str(CORE/'candidate/analysis_queue_runtime.py'))
LOADED_SHA=hashlib.sha256(Path(os.environ['ANALYSIS_QUEUE_CONTROLLER']).read_bytes()).hexdigest()
os.environ['ANALYSIS_QUEUE_EVIDENCE']=str(ROOT/'evidence/cold-fixture')
spec=importlib.util.spec_from_file_location('cold_auto_base',CORE/'test_analysis_queue_base.py')
base=importlib.util.module_from_spec(spec);sys.modules[spec.name]=base;spec.loader.exec_module(base)
base.HERE=ROOT/'work-cold-fixtures';base.HERE.mkdir(exist_ok=True)
IMPL=base.candidate
helper_spec=importlib.util.spec_from_file_location('cold_customer_read_store',PROJECT/'work/ui-native-r57/customer_read_store.py')
helper=importlib.util.module_from_spec(helper_spec);sys.modules[helper_spec.name]=helper;helper_spec.loader.exec_module(helper)

def runtime_device():
    tree=ast.parse((PROJECT/'work/shared-backend-integration/platform_runtime.py').read_text('utf-8-sig'))
    cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='PlatformRuntime')
    node=next(n for n in cls.body if isinstance(n,ast.FunctionDef) and n.name=='_device')
    scope={};exec(compile(ast.Module(body=[node],type_ignores=[]),'<actual-PlatformRuntime-device>','exec'),scope)
    return scope['_device']

def service_method(name,trace):
    p=PROJECT/'work/shared-backend-integration/vendor-src/assistant/service.py'
    tree=ast.parse(p.read_text('utf-8-sig'));cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='AssistantService')
    node=next(n for n in cls.body if isinstance(n,ast.FunctionDef) and n.name==name)
    class DummyBusiness:pass
    class CloudError(ValueError):status=503
    class Journal:
        def __init__(self,path):trace.append('journal-created')
        def close(self):trace.append('journal-closed')
    class Runner:
        def __init__(self,*args,**kwargs):
            assert kwargs['accept_commands'] is False and kwargs['contact_sync_autostart'] is False
            trace.append('controlled-heartbeat-created');self.hold_active=False
        def step(self):return .01
        def close(self):trace.append('heartbeat-closed')
    scope={'__package__':'assistant','threading':threading,'time':time,'logging':logging,'BusinessExecutor':DummyBusiness,
        'Journal':Journal,'AssistantRunner':Runner,'CloudError':CloudError,'employee_runtime_config_valid':lambda company:False}
    exec(compile(ast.Module(body=[node],type_ignores=[]),'<actual-AssistantService-'+name+'>','exec'),scope)
    return scope[name]

class ColdBootstrap(base.QueueTests):
    def test_reply_bootstrap_cold_service_drains_all_seven_tasks_without_analysis_action(self):
        self.leads(209);old=self.unknown(['lead-'+str(i) for i in range(9)])
        for i in range(195,209):self.core.store.put('leads',{**self.core.store.get('leads','lead-'+str(i)),'text':''})
        start=209
        for n,count in enumerate((10,10,10,10,10,8)):
            task_id='saved-'+str(n);self.core.store.put('tasks',{**self.task,'id':task_id})
            for i in range(start,start+count+(7 if n==0 else 0)):
                self.core.store.put('leads',{'id':'lead-'+str(i),'tenant_id':self.user['tenant_id'],'cloud_owner':self.user['username'],
                    'task_id':task_id,'platform':'xiaohongshu','text':'fixture '+str(i) if i<start+count else '',
                    'content_title':'fixture post','note_url':'https://www.xiaohongshu.com/explore/123456789012345678901234'})
            start+=count+(7 if n==0 else 0)
        originals=[]
        for i in range(1794):
            row={'id':'prior-'+str(i),'tenant_id':self.user['tenant_id'],'cloud_owner':self.user['username'],'task_id':self.task['id'],
                 'text':'original','ai_intent':{'status':'graded','level':'high','verbatim':'keep'}}
            self.core.store.put('leads',row);originals.append(row)
        self.core.store.put('replies',{'id':'manual-reply','tenant_id':self.user['tenant_id'],'text':'keep manual draft'})
        manual=self.core.store.get('replies','manual-reply');task_before=self.core.store.get('tasks',self.task['id'])
        trace=[];executor=self.executor
        service=types.SimpleNamespace(server=self.server,directory=self.core.store.directory/'assistant',environment_id='fixture-env',company_id='fangyu-apartment-client',
            explicit_local=True,manual_owned_read_start=False,closed=False,executor=None,state='offline',device={'id':'fixture-device','owner':self.user['username']},
            lock=threading.RLock(),stop_event=threading.Event(),thread=None)
        saved={'state':'bound','token':'fixture-device-token-not-real','device':service.device}
        service.vault=types.SimpleNamespace(read=lambda:copy.deepcopy(saved))
        service._cloud=lambda:types.SimpleNamespace(close=lambda:trace.append('cloud-closed'))
        def factory(*args):trace.append('executor-created-by-original-run');return executor
        service.executor_factory=factory
        executor.stop_owned_tasks=lambda:trace.append('owned-tasks-stopped')
        for name in ('_pause_platform_work','_resume_platform_work','_contact_sync_state'):
            setattr(service,name,lambda *args:None)
        for name in ('start','_run','_state'):setattr(service,name,types.MethodType(service_method(name,trace),service))
        self.runtime.service=service;self.runtime.started=False
        self.runtime._device=types.MethodType(runtime_device(),self.runtime)
        self.runtime._principal=lambda user:user
        self.runtime._task=lambda user,ident:self.core._get('tasks',ident,user['tenant_id'])
        self.runtime.prepare=lambda *a,**kw:self.fail('prepare/download/configure forbidden')
        self.server._configure_bundled=lambda:self.fail('configure/download forbidden')
        f=fixture();f.core=self.core;self.core.fixture=f;f.platform_runtime=self.runtime;f.user=self.user
        f.profile={'username':self.user['username'],'role':self.user['role'],'can_analyze':True,'_workbench_store_id':'fixture-store'}
        f.selected='fixture-store';self.core.session=lambda token:copy.deepcopy(self.user)
        f.integrations=Integration(f)
        f._read_store_directory=lambda integration,user:([{'id':'fixture-store'}],'',{'fixture':True})
        f._stores=lambda profile:[{'id':'fixture-store'}]
        f._analysis_queue_factory=lambda runtime:IMPL.AnalysisQueueRuntime(runtime,workflow_factory=base.FixtureWorkflow)
        ready=helper.prepare_business_revision(self.core.store.path,backup_directory=self.temp.name+'/revision-backups')
        self.assertTrue(ready['ready'])
        f.customer_read_store=helper.CustomerReadStore(self.core.store.path)
        f._analysis_workspace_refresh.__func__.__globals__['_revision_schema_valid']=helper._revision_schema_valid
        self.assertIsNone(service.executor)
        try:
            f.page='reply';response=f._bootstrap('fixture-session-token')
            self.assertEqual(response['session']['user']['username'],self.user['username'])
            end=time.monotonic()+90
            while time.monotonic()<end:
                view=f._analysis_workspace_dispatch('analysis_workspace_read',{'storeId':'fixture-store'},'fixture-session-token')['analysisQueue']
                if view['remaining']==0 and not view['running'] and view['status'] not in ('starting','scanning'):break
                if view['status']=='blocked':self.fail('automatic cold bootstrap blocked: '+str(view))
                time.sleep(.1)
            self.assertEqual(view['counts'],{'total':2068,'pending':0,'processing':0,'held':9,'analyzed':2038,'missingText':21})
            self.assertEqual(sum(len(d['ids']) for op,d in self.calls if op=='intent_analyze'),244)
            self.assertIn('executor-created-by-original-run',trace);self.assertTrue(self.runtime.started)
            self.assertEqual(self.core.store.get('ai_attempts',old['id']),old)
            self.assertEqual([self.core.store.get('leads',v['id']) for v in originals],originals)
            self.assertEqual(self.core.store.get('replies','manual-reply'),manual);self.assertEqual(self.core.store.get('tasks',self.task['id']),task_before)
            self.assertFalse(hasattr(service,'ai_worker'))
            director=f._analysis_queue.workspace['thread'];fresh=f.authority_calls
            for _ in range(10):f._analysis_workspace_dispatch('analysis_workspace_read',{'storeId':'fixture-store'},'fixture-session-token')
            self.assertIs(f._analysis_queue.workspace['thread'],director);self.assertEqual(f.authority_calls,fresh)
            self.assertEqual(hashlib.sha256(Path(os.environ['ANALYSIS_QUEUE_CONTROLLER']).read_bytes()).hexdigest(),LOADED_SHA,'core candidate changed during combined check')
        finally:
            if f._analysis_queue:f._analysis_queue.close();f._analysis_queue.wait_workspace_idle(3)
            f.customer_read_store.close()
            service.stop_event.set()
            if service.thread:service.thread.join(3)

if __name__=='__main__':
    stream=io.StringIO()
    with patch.object(socket.socket,'connect',base.deny),patch('subprocess.Popen',side_effect=base.deny):
        result=unittest.TextTestRunner(stream=stream,verbosity=2).run(unittest.TestSuite([ColdBootstrap('test_reply_bootstrap_cold_service_drains_all_seven_tasks_without_analysis_action')]))
    print(stream.getvalue());print(json.dumps({'passed':result.wasSuccessful(),'controllerSha256':LOADED_SHA,'coldExecutorInitiallyNone':True,'replyBootstrap':True,'realExtractedMethods':['AssistantService.start','AssistantService._run','AssistantService._state','PlatformRuntime._device'],'newlyAnalyzed':244,'heldPreserved':9,'missingTextPreserved':21,'existingAiPreserved':1794,'realNetworkOrModelCalls':0}));raise SystemExit(0 if result.wasSuccessful() else 1)
