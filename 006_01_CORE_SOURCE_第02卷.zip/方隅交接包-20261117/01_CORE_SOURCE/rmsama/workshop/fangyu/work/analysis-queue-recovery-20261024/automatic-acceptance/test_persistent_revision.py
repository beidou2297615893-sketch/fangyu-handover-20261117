"""Actual F103 revision reader on synthetic, owned SQLite only."""
from pathlib import Path
from datetime import datetime,timezone
from contextlib import contextmanager
import hashlib,importlib.util,json,sqlite3,tempfile,unittest

HERE=Path(__file__).resolve().parent
P=HERE.parents[2]
STAGE=P/'work/parallel-integration-20261018/final-integration/candidate-unified-v103/STAGED.json'
release=Path(json.loads(STAGE.read_text('utf-8'))['release'])
source=release/'customer_read_store.py'
spec=importlib.util.spec_from_file_location('acceptance_real_revision',source)
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)

@contextmanager
def writable(path):
    db=sqlite3.connect(path)
    try:
        with db:yield db
    finally:db.close()

class PersistentRevision(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(prefix='revision-fixture-',dir=HERE)
        self.directory=Path(self.temp.name).resolve()
        assert self.directory.is_relative_to(HERE.resolve())
        self.addCleanup(self.temp.cleanup)
        self.path=self.directory/'workspace.sqlite3'
        with writable(self.path) as db:
            db.execute('CREATE TABLE records(entity TEXT,id TEXT,tenant_id TEXT,body TEXT,PRIMARY KEY(entity,id))')
            db.execute('CREATE INDEX scope ON records(entity,tenant_id)')
        self.prepared=module.prepare_business_revision(self.path,backup_directory=self.directory/'schema-backup')
        self.assertTrue(self.prepared['ready'])
        self.reader=module.CustomerReadStore(self.path)
        self.addCleanup(self.reader.close)
        self.scope={'actor':{'id':'user','tenant_id':'tenant','username':'owner','role':'operator'},'storeId':'store'}
        self.lead={'id':'lead','tenant_id':'tenant','cloud_owner':'owner','task_id':'task','text':'synthetic comment'}
        self.put('leads',self.lead)

    def put(self,entity,value):
        with writable(self.path) as db:
            db.execute('INSERT OR REPLACE INTO records VALUES(?,?,?,?)',(entity,value['id'],'tenant',json.dumps(value,ensure_ascii=False)))

    def token(self):
        trace=[]
        identity=self.reader._stat(self.path,timestamp=False)[:2]
        db=sqlite3.connect(self.path.as_uri()+'?mode=ro',uri=True)
        db.row_factory=sqlite3.Row
        try:
            db.set_trace_callback(trace.append)
            db.execute('PRAGMA query_only=ON');db.execute('BEGIN')
            revision=self.reader._revision(db,self.scope,identity,0)
            attempt=tuple(db.execute("SELECT COUNT(*),COALESCE(MAX(rowid),0) FROM records INDEXED BY scope WHERE entity='ai_attempts' AND tenant_id=?",('tenant',)).fetchone())
            self.assertEqual(revision[2][0],'durable-v1')
            return revision,attempt,trace
        finally:db.close()

    def test_controller_and_regular_identity_metadata_do_not_change_business_token(self):
        before,attempt,_=self.token()
        for entity in ('ui_task_analysis_control_v1','ui_workspace_analysis_control_v1','ai_jobs','users'):
            self.put(entity,{'id':entity,'tenant_id':'tenant','phase':'fixture','updated_at':'new'})
            after,current_attempt,trace=self.token()
            self.assertEqual(after,before)
            self.assertEqual(current_attempt,attempt)
            self.assertFalse(any('SELECT entity,id,body FROM records' in sql for sql in trace))

    def test_actual_ai_result_lead_write_changes_token_and_identical_put_does_not(self):
        before,_,_=self.token()
        changed={**self.lead,'ai_intent':{'status':'graded','level':'high'}}
        self.put('leads',changed)
        after,_,_=self.token();self.assertNotEqual(after,before)
        self.put('leads',changed)
        same,_,_=self.token();self.assertEqual(same,after)

    def test_unknown_attempt_state_needs_the_auxiliary_signature(self):
        initial,none,_=self.token()
        self.put('ai_attempts',{'id':'attempt','tenant_id':'tenant','owner':'owner','state':'submitted'})
        submitted,sig1,_=self.token()
        self.assertEqual(submitted,initial);self.assertNotEqual(sig1,none)
        self.put('ai_attempts',{'id':'attempt','tenant_id':'tenant','owner':'owner','state':'unknown'})
        unknown,sig2,_=self.token()
        self.assertEqual(unknown,initial);self.assertNotEqual(sig2,sig1)

    def test_warm_revision_reads_only_schema_and_counter_metadata(self):
        self.token()
        _,_,trace=self.token()
        reads=[sql for sql in trace if sql.upper().startswith('SELECT')]
        self.assertEqual(len(reads),2)
        self.assertIn('customer_read_epoch_v1',reads[0])
        self.assertIn('COUNT(*)',reads[1])
        self.assertFalse(any('l.body' in sql or 'SELECT entity,id,body' in sql for sql in trace))

    def test_new_connection_data_version_is_not_the_business_revision(self):
        def version():
            with writable(self.path) as db:return db.execute('PRAGMA data_version').fetchone()[0]
        before=version();business,_,_=self.token()
        self.put('leads',{**self.lead,'text':'changed synthetic comment'})
        after=version();changed,_,_=self.token()
        self.assertEqual(before,after)
        self.assertNotEqual(business,changed)

if __name__=='__main__':
    import io
    stream=io.StringIO();result=unittest.TextTestRunner(stream=stream,verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(PersistentRevision))
    log=HERE/'PERSISTENT-REVISION.log';log.write_text(stream.getvalue(),'utf-8')
    report={'status':'PASS' if result.wasSuccessful() else 'FAIL','atUtc':datetime.now(timezone.utc).isoformat(),
        'checks':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),
        'source':str(source),'sourceSha256':hashlib.sha256(source.read_bytes()).hexdigest(),
        'scope':'Actual F103 revision reader and additive preparer on a self-created synthetic SQLite file. No production access, network, model, platform or Native.',
        'log':str(log),'logSha256':hashlib.sha256(log.read_bytes()).hexdigest()}
    (HERE/'PERSISTENT-REVISION.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n','utf-8')
    print(stream.getvalue());print(json.dumps(report,ensure_ascii=False));raise SystemExit(0 if result.wasSuccessful() else 1)
