"""Persist actual F104 checkpoint without changing business data or quota conditions."""
from pathlib import Path
from datetime import datetime, timezone
import json,sys
W=Path(__file__).resolve().parent; P=W.parents[1]
read=lambda p:json.loads(p.read_text('utf-8-sig'))
now=datetime.now(timezone.utc).isoformat()
installed=read(W/'INSTALLED-VERIFICATION-F104.json')
latest=sorted(W.glob('ACTUAL-ANALYSIS-*.json'))[-1]
actual=read(latest)
state=read(W/'STATE.json')
backup=W/'STATE.before-f104-checkpoint.json'
if not backup.exists():backup.write_text(json.dumps(state,ensure_ascii=False,indent=2)+'\n','utf-8')
running=actual['actualRelease']==installed['installedReleaseId']
real_results=actual['newAIResultsSinceBeforeRepair']>0
terminal=running and actual.get('workspaceBacklogTaskCounts',{}).get('pending')==0 and actual.get('submittedUnconfirmedComments',0)<=20
state.update(status=('F104_REAL_AUTOMATIC_ANALYSIS_PROCESSABLE_QUEUE_DRAINED' if terminal else 'F104_REAL_AUTOMATIC_ANALYSIS_RUNNING' if running and real_results else 'F104_AUTOMATIC_INSTALLED_AWAITING_ACTUAL_REOPEN'),updatedAtUtc=now,
 installedRelease=installed['installedReleaseId'],actualLastSeenRelease=actual['actualRelease'],actualLastSeenPid=actual['pid'],
 currentTaskCounts=actual['currentTaskCounts'],workspaceBacklogTaskCounts=actual.get('workspaceBacklogTaskCounts'),
 newAIResultsSinceBeforeRepair=actual['newAIResultsSinceBeforeRepair'],
 currentStoreProcessableBaseline=244,heldOriginal=9,missingTextOriginal=21,
 userReopenAndExplicitAnalysisRequested=False,userReopenRequested=not running,analysisButtonRequired=False,
 automaticAnalysisAfterTrustedLogin=True,automaticCollectionOrSend=False,
 actualRelease=actual['actualRelease'],actualPid=actual['pid'],
 actualVersionVerified=actual['actualRelease']==installed['installedReleaseId'],
 actualNewNativeAnalysisVerified=running and real_results,
 resumeInstruction='Person normally reopens original desktop workbench and may remain on Reply page; no analysis button. Verify public F104 version and persisted new AI results. Do not auto collect/send or replay old unknown requests.',
 sourceFixes=['workspace-scoped background analysis independent from collection','trusted login/bootstrap starts executor and queue without page/button','all current-owner/current-store task backlogs drain serially','local durable revision caching and point processing counts','original unknown request isolation without replay','manual pause persists; normal reopen automatically resumes'],
 scopeComplete=False,processableQueueDrainedObserved=terminal,fullThreeInOneGoalComplete=False)
state['evidence'].update(installedVerification=str(W/'INSTALLED-VERIFICATION-F104.json'),
 rootGates=str(W/'package/ROOT-GATES-V104.json'),packageReview=str(W/'package/FINAL-PACKAGE-REVIEW-V104.json'),
 formalBefore=str(W/'FORMAL-BEFORE-F104.json'),formalAfter=str(W/'FORMAL-AFTER-F104.json'),
 latestActualObserver=str(latest),automaticDesign=str(W/'AUTOMATIC-ANALYSIS-DESIGN.md'))
state.update(actualAIStarted=running and real_results,actualAIStartRequestRecorded=real_results,
 actualAIBlockCode='',automaticAnalysisRepairVerified=running and real_results,
 currentTaskProcessableRemaining=actual['currentTaskCounts']['pending'],
 unresolvedComments=actual.get('workspaceBacklogTaskCounts',{}).get('held'),
 missingTextComments=actual.get('workspaceBacklogTaskCounts',{}).get('missingText'),
 actualCloudModelAnalysisVerified=running and real_results,
 supplierBillingAmountVerified=False)
for name in ('STATE.json','RESULT.json'):(W/name).write_text(json.dumps(state,ensure_ascii=False,indent=2)+'\n','utf-8')
central=P/'work/quota-resume-plan-20261023/STATE.json'
if central.exists():
 c=read(central);c['analysisQueueRecovery']=state
 c['latestAuthorizedFocus']='F104 real automatic analysis verified; '+str(actual['newAIResultsSinceBeforeRepair'])+' new persisted AI results, current task pending '+str(actual['currentTaskCounts']['pending'])+'. No automatic collection or send; unresolved receipts and missing-body comments retained.'
 c['updatedAtUtc']=now
 central.write_text(json.dumps(c,ensure_ascii=False,indent=2)+'\n','utf-8')
handoff=P/'work/commercial-integration-20261022/HANDOFF-THREE-IN-ONE-LATEST.md'
text='''\n\n## F104 automatic-analysis checkpoint

- Original desktop entry now points to ui-r57-20261024T153411Z-4c9dd686. CAS backups and full closure review retained. Existing live F103 was not closed or operated.
- New requirement supersedes manual Continue Analysis: trusted login/reopen/current-store selection starts independent background analysis even on Reply page; no manual analysis action required. Acquisition/captcha do not stop saved-comment processing. Explicit user pause persists; real authority/budget/provider uncertainty remains blocked with cause.
- Real baseline: 2068 comments, 1794 original AI results, 3 accounts, 40 tasks. Current-store 7-task backlog has 244 processable, 9 original unknown-request held, 21 missing body. Current task itself has 186 processable. Do not conflate 186/244/200.
- Frozen checks: 26 workspace +18 old-task +12 legacy safety +4 real-method cold combinations +31 bridge/sender +145 Native self-tests. These are isolated model/authority fixtures, not real DeepSeek success. PowerShell final hash report writer failed; all test JSON/log evidence passed, original exit1 retained in HARNESS-REPORT-REPAIR.
- Formal before/after install 11 record classes identical. Original analysis/manual decisions, accounts, task breaks and reply drafts preserved. No automatic collection/comment/DM/post, no formal model request by the observer.
- Current actual model results were still 1794 at installation. User asked to normally reopen original desktop shortcut and stay on Reply page; then check public actual version and RO result growth. Full three-in-one remains incomplete; tone work remains paused.
- Evidence: work/analysis-queue-recovery-20261024/STATE.json, INSTALLED-VERIFICATION-F104.json, package/ROOT-GATES-V104.json and FINAL-PACKAGE-REVIEW-V104.json.
'''
if terminal:
 text='\n\n## F104 real automatic analysis verified '+now+'\n\n'+(
 '- Actual original desktop process '+str(actual['pid'])+' is running '+str(actual['actualRelease'])+'. User remains on Reply page; zero analysis-button action.\n'
 '- Real persisted AI results increased from 1794 to '+str(actual['hasAI'])+' (+'+str(actual['newAIResultsSinceBeforeRepair'])+'). Current task original 186 processable comments drained to 0. Current-store 7-task processable queue is 0.\n'
 '- 29 comments remain receipt-held (9 original unknown and 20 submitted before the previous process ended); 21 have no comment body. They are not claimed analyzed and were not replayed. Supplier billing not read.\n'
 '- Original 1794 AI/manual/source judgments and all 2068 comments preserved. Separate RO proof confirms 3 accounts and reply/draft/request/delivery data identical to install baseline; no real comment/DM/post sent.\n'
 '- See REAL-AUTOMATIC-ANALYSIS-PROOF-F104.json, latest ACTUAL-ANALYSIS evidence and STATE.json under analysis-queue-recovery-20261024. Full three-in-one scope remains incomplete.\n')
with handoff.open('a',encoding='utf-8') as f:f.write(text)
print(json.dumps({'status':state['status'],'installed':state['installedRelease'],'actual':state['actualRelease'],'newAI':state['newAIResultsSinceBeforeRepair']}))
