"""Real candidate Backend -> real F103 AssistantService -> candidate controller.

Only synthetic owned SQLite/authority/model/transport. No Native, formal DB or
real cloud is touched; service.executor starts None and original _run creates it.
"""
from pathlib import Path
from datetime import datetime, timezone
from types import SimpleNamespace, ModuleType, MethodType
import ast, copy, hashlib, importlib.util, io, json, logging, os, re, sys, threading, time, unittest
from contextlib import contextmanager
from unittest.mock import patch

HERE=Path(__file__).resolve().parent
W=HERE.parent
P=W.parents[1]
C=W/'core-audit/automatic-workspace-recovery'
B=W/'bridge-audit/automatic-workspace/candidate/work/ui-native-r57/workbench_backend.py'
RELEASE=Path(json.loads((P/'work/parallel-integration-20261018/final-integration/candidate-unified-v103/STAGED.json').read_text('utf-8'))['release'])
SERVICE=RELEASE/'resources/platform-runtime/vendor-src/assistant/service.py'
RUNTIME=RELEASE/'resources/platform-runtime/platform_runtime.py'
PINNED_PATHS=(B,C/'candidate/analysis_queue_runtime.py',SERVICE,RUNTIME,RELEASE/'customer_read_store.py')
SOURCE_HASHES={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in PINNED_PATHS}
for pinned in PINNED_PATHS:
    saved=HERE/'source-pins'/SOURCE_HASHES[str(pinned)]/pinned.name
    saved.parent.mkdir(parents=True,exist_ok=True)
    if not saved.exists():saved.write_bytes(pinned.read_bytes())
os.environ['ANALYSIS_QUEUE_SOURCE_PROJECT']=str(RELEASE.parents[3])
os.environ['ANALYSIS_QUEUE_BASE_RELEASE']=str(RELEASE)
os.environ['ANALYSIS_QUEUE_CONTROLLER']=str(C/'candidate/analysis_queue_runtime.py')
os.environ['ANALYSIS_QUEUE_EVIDENCE']=str(HERE)
sys.dont_write_bytecode=True
spec=importlib.util.spec_from_file_location('combined_owned_base',C/'test_analysis_queue_base.py')
base=importlib.util.module_from_spec(spec);sys.modules[spec.name]=base;spec.loader.exec_module(base)
base.HERE=HERE
impl=base.candidate
revision=base.load('combined_real_revision',RELEASE/'customer_read_store.py')
OBSERVATIONS=[]

class Failure(ValueError):
    def __init__(self,code,message,status=400):super().__init__(message);self.code,self.status=code,status

class Integration:
    def __init__(self,f):self.f=f;self.identity_cache={};self.last_verified_profile=None;self.last_verification_error=None
    def verify_identity(self,user,**kwargs):
        self.f.authority_calls+=1
        self.last_verified_profile=copy.deepcopy(self.f.profile)
        return copy.deepcopy(user)

def extract(path,cls,name,scope):
    tree=ast.parse(path.read_text('utf-8-sig'))
    node=next(n for n in next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name==cls).body if isinstance(n,ast.FunctionDef) and n.name==name)
    exec(compile(ast.Module(body=[node],type_ignores=[]),str(path)+':'+name,'exec'),scope)
    return scope[name]

class ExternalCloud:
    def close(self):pass
class ExternalJournal:
    def __init__(self,path):self.path=path
    def close(self):pass
class ExternalRunner:
    def __init__(self,*args,**kwargs):
        assert kwargs['accept_commands'] is False
        assert kwargs['contact_sync_autostart'] is False
        self.hold_active=False;self.qa_continuous_max_batches=0
    def step(self):return .01
    def close(self):pass
class CloudError(ValueError):
    status=503

class Combined(unittest.TestCase):
    def setUp(self):
        self.q=base.QueueTests();self.q.setUp();self.addCleanup(self.q.doCleanups)
        self.q.manager.close();self.q.manager.wait_for_idle(2)
        q=self.q
        self.token='synthetic-acceptance-token'
        self.factory_calls=[];self.states=[]
        q.core.session=lambda token: q.core.store.get('users',q.user['id']) if token==self.token else None
        f=SimpleNamespace(closed=False,lock=threading.RLock(),_analysis_queue=None,
            _analysis_authority_lock=threading.RLock(),_analysis_authorities={},authority_calls=0)
        f.core=q.core;f.core.fixture=f
        f.user=q.user;f.profile={'username':q.user['username'],'role':q.user['role'],'can_analyze':True}
        f.selected='fixture-store';f.platform_runtime=q.runtime
        f._analysis_queue_factory=lambda runtime:impl.AnalysisQueueRuntime(runtime,workflow_factory=base.FixtureWorkflow)
        f._read_store_directory=lambda integration,user:([{'id':'fixture-store'},{'id':'other-store'}],'',{})
        f._stores=lambda profile:[{'id':'fixture-store'},{'id':'other-store'}]
        f._load_selection=lambda user,stores:{'storeId':f.selected,'revision':0,'applied':None}
        f._activate_central_config=lambda *a,**k:None
        f._catalog=lambda *a,**k:{'search':[],'intent':[]}
        f.materials=SimpleNamespace(catalog=lambda *a:None,central=None)
        f._remembered=lambda:'';f.customer_workbench=None;f.rental_factory=None;f.integrations=Integration(f)
        self.prepared=revision.prepare_business_revision(q.core.store.path,backup_directory=Path(q.temp.name)/'revision')
        self.assertTrue(self.prepared['ready'])
        f.customer_read_store=revision.CustomerReadStore(q.core.store.path);self.addCleanup(f.customer_read_store.close)
        namespace={'WorkbenchError':Failure,'_CloudServiceUnavailable':RuntimeError,'deepcopy':copy.deepcopy,
            're':re,'Path':Path,'STORE_ID':re.compile(r'[A-Za-z0-9_-]{1,80}\Z'),'threading':threading,
            'hashlib':hashlib,'time':time,'_MediaReadIntegrations':lambda core:Integration(core.fixture),
            '_stamp':lambda:'fixture','_revision_schema_valid':revision._revision_schema_valid,
            'ANALYSIS_WORKSPACE_ACTIONS':{'analysis_workspace_read','analysis_workspace_pause','analysis_workspace_resume'}}
        for name in ('_remember_analysis_authority','_analysis_local_identity','_analysis_controller','_analysis_queue_refresh',
            '_analysis_workspace_refresh','_sync_analysis_workspace','_analysis_workspace_dispatch','_identity','_bootstrap'):
            setattr(f,name,MethodType(extract(B,'WorkbenchBackend',name,namespace),f))
        self.f=f
        # Real AssistantService starts with no executor. Only its real _run may
        # invoke this factory; no fixture startup callback assigns the executor.
        service=SimpleNamespace(lock=threading.RLock(),closed=False,thread=None,executor=None,state='offline',
            stop_event=threading.Event(),explicit_local=True,manual_owned_read_start=False,
            environment_id='synthetic',company_id='synthetic',server=q.server,directory=Path(q.temp.name),
            device={'id':'synthetic-device','owner':q.user['username']},
            vault=SimpleNamespace(read=lambda:{'state':'bound','device':{'id':'synthetic-device','owner':q.user['username']},'token':'synthetic'}))
        service._cloud=lambda:ExternalCloud()
        service._claim_xhs_account=lambda *a,**k:None
        service._state=lambda state:(self.states.append(state),setattr(service,'state',state))[-1]
        for name in ('_pause_platform_work','_resume_platform_work','_contact_sync_state','_qa_continuous_heartbeat',
            '_employee_release_heartbeat','_customer_read_heartbeat'):
            setattr(service,name,lambda *a,**k:None)
        def factory(*args):
            self.factory_calls.append(threading.get_ident())
            q.executor.stop_owned_tasks=lambda:None
            return q.executor
        service.executor_factory=factory
        service_scope={'__name__':'assistant.acceptance_service','__package__':'assistant','threading':threading,
            'logging':logging,'Journal':ExternalJournal,'AssistantRunner':ExternalRunner,'CloudError':CloudError,
            'BusinessExecutor':base.business.BusinessExecutor,'employee_runtime_config_valid':lambda value:False}
        for name in ('start','_run'):
            setattr(service,name,MethodType(extract(SERVICE,'AssistantService',name,service_scope),service))
        q.runtime.service=service;q.runtime._device=MethodType(extract(RUNTIME,'PlatformRuntime','_device',{}),q.runtime)
        q.runtime._principal=lambda user:user
        q.runtime._task=lambda user,task_id:q.core.store.get('tasks',task_id)
        q.runtime.prepare=lambda *a,**k:(_ for _ in ()).throw(AssertionError('platform prepare forbidden'))
        q.runtime._configure_bundled=lambda *a,**k:(_ for _ in ()).throw(AssertionError('CLI configure forbidden'))
        q.core.deployment_config={}
        self.service=service
        context=ModuleType('assistant.xhs_app_context');context.bind_executor_session=lambda *a,**k:None
        lease=ModuleType('assistant.customer_read_lease');lease.request_for=lambda *a,**k:None
        self.modules=patch.dict(sys.modules,{'assistant.xhs_app_context':context,'assistant.customer_read_lease':lease})
        self.modules.start();self.addCleanup(self.modules.stop)
        self.addCleanup(self.stop)

    def stop(self):
        if self.f._analysis_queue:
            self.f._analysis_queue.close();self.f._analysis_queue.wait_for_idle(5)
        self.service.stop_event.set()
        if self.service.thread:self.service.thread.join(5)

    def boot(self):
        self.f.page='reply'
        self.assertIsNone(self.service.executor)
        response=self.f._bootstrap(self.token)
        self.assertEqual(response['session']['user']['username'],self.q.user['username'])
        self.assertIsNotNone(self.f._analysis_queue)
        return response

    def read(self):
        response=self.f._analysis_workspace_dispatch('analysis_workspace_read',{'storeId':'fixture-store'},self.token)
        self.assertIn('analysisQueue',response,'original app dispatch envelope changed')
        return response['analysisQueue']

    def settle(self,remaining=0,timeout=25):
        end=time.monotonic()+timeout;value={}
        while time.monotonic()<end:
            value=self.read()
            if value.get('remaining')==remaining and not value.get('running') and value.get('status') not in ('starting','scanning'):
                return value
            time.sleep(.04)
        self.fail('combined startup did not settle: '+str(value))

    def test_true_cold_reply_bootstrap_creates_executor_then_drains_no_buttons(self):
        self.q.leads(21);main=threading.get_ident();self.boot();result=self.settle()
        self.assertEqual(result['counts']['analyzed'],21)
        self.assertEqual(len(self.factory_calls),1);self.assertNotEqual(self.factory_calls[0],main)
        self.assertIs(self.service.executor,self.q.executor)
        self.assertTrue(self.q.runtime.started)
        self.assertEqual(sum(len(d['ids']) for op,d in self.q.calls if op=='intent_analyze'),21)
        self.assertTrue(self.states)
        self.assertTrue(all(state in ('online','held') for state in self.states))
        self.assertIsNone(getattr(self.service,'ai_worker',None))

    def test_full_backlog_preservation_then_new_saved_page_automatic(self):
        q=self.q;q.leads(209);old=q.unknown(['lead-'+str(i) for i in range(9)])
        for i in range(195,209):q.core.store.put('leads',{**q.core.store.get('leads','lead-'+str(i)),'text':''})
        next_id=209
        for n,count in enumerate((10,10,10,10,10,8)):
            task={**q.task,'id':'saved-'+str(n)};q.core.store.put('tasks',task)
            for i in range(next_id,next_id+count+(7 if n==0 else 0)):
                q.core.store.put('leads',{'id':'lead-'+str(i),'tenant_id':q.user['tenant_id'],'cloud_owner':q.user['username'],
                    'task_id':task['id'],'platform':'xiaohongshu','text':'fixture' if i<next_id+count else '',
                    'content_title':'fixture post','note_url':'https://www.xiaohongshu.com/explore/123456789012345678901234'})
            next_id+=count+(7 if n==0 else 0)
        originals=[]
        for i in range(1794):
            value={'id':'prior-'+str(i),'tenant_id':q.user['tenant_id'],'cloud_owner':q.user['username'],
                'task_id':q.task['id'],'text':'original','ai_intent':{'status':'graded','level':'high','verbatim':'keep'}}
            q.core.store.put('leads',value);originals.append(value)
        self.boot();result=self.settle(timeout=120)
        self.assertEqual(result['counts'],{'total':2068,'pending':0,'processing':0,'held':9,'analyzed':2038,'missingText':21})
        self.assertEqual(sum(len(d['ids']) for op,d in q.calls if op=='intent_analyze'),244)
        self.assertEqual(q.core.store.get('ai_attempts',old['id']),old)
        self.assertEqual([q.core.store.get('leads',v['id']) for v in originals],originals)
        calls=len(q.calls)
        for _ in range(4):self.read()
        time.sleep(.2)
        self.assertEqual(len(q.calls),calls,'held/missing-only queue must not contact model/status')
        q.leads(2,start=10000)
        self.f._analysis_queue.notify_saved(q.task['id']);result=self.settle()
        self.assertEqual(result['counts']['analyzed'],2040)
        self.assertEqual(len(self.factory_calls),1)

    def test_inflight_submitted_validated_and_partial_apply_counts(self):
        q=self.q;q.leads(30);q.unknown(['lead-'+str(i) for i in range(9)])
        entered=threading.Event();release=threading.Event();validated=threading.Event();apply_release=threading.Event()
        fifth=threading.Event();last_release=threading.Event();saved=[]
        q.model_gate=lambda:(entered.set(),release.wait(15))
        original_validated=base.LocalAIAttempts.validated
        def validate(attempts,user,receipt):
            result=original_validated(attempts,user,receipt)
            validated.set();apply_release.wait(15)
            return result
        original_put=q.core.store.put
        def put(entity,value,*args,**kwargs):
            result=original_put(entity,value,*args,**kwargs)
            if entity=='leads' and value.get('ai_intent'):
                saved.append(value['id'])
                if len(saved)==5:fifth.set();last_release.wait(15)
            return result
        try:
            with patch.object(base.LocalAIAttempts,'validated',validate),patch.object(q.core.store,'put',put):
                self.boot();self.assertTrue(entered.wait(8),'original attempt never entered model')
                queries=[];connect=q.core.store.connect
                @contextmanager
                def traced():
                    with connect() as db:db.set_trace_callback(queries.append);yield db
                with patch.object(q.core.store,'connect',traced):submitted=self.read()
                current_queries=[sql for sql in queries if sql.lstrip().startswith('SELECT l.id AS current_id')]
                self.assertEqual(len(current_queries),1,'processing snapshot must read actual bounded current rows')
                with connect() as db:plan=[tuple(row) for row in db.execute('EXPLAIN QUERY PLAN '+current_queries[0])]
                OBSERVATIONS.append({'stage':'submitted','snapshot':submitted,'currentRowsQueryPlan':plan})
                self.assertTrue(any('SEARCH l USING INDEX' in row[-1] and 'entity=? AND id=?' in row[-1] for row in plan),
                    'processing overlay must use existing entity/id PK, not historical tenant lead scope: '+str(plan))
                self.assertEqual(submitted['counts']['pending'],1)
                self.assertEqual(submitted['counts']['held'],9)
                self.assertEqual(submitted['counts'].get('processing'),20)
                self.assertEqual(submitted['remaining'],21)
                release.set();self.assertTrue(validated.wait(8))
                just_validated=self.read();OBSERVATIONS.append({'stage':'validated-before-apply','snapshot':just_validated})
                self.assertEqual(just_validated['counts']['pending'],21)
                self.assertEqual(just_validated['counts']['held'],9)
                self.assertEqual(just_validated['counts'].get('processing',0),0)
                self.assertEqual(just_validated['remaining'],21)
                apply_release.set();self.assertTrue(fifth.wait(8))
                # Store.put returns outside its SQLite transaction. This pause
                # observes five durably applied AI results, not a synthetic UI.
                partial=self.read();OBSERVATIONS.append({'stage':'five-results-saved','snapshot':partial})
                self.assertEqual(partial['counts']['analyzed'],5)
                self.assertEqual(partial['counts']['held'],9)
                self.assertEqual(partial['remaining'],16)
                last_release.set();self.settle()
        finally:
            release.set();apply_release.set();last_release.set()

    def test_real_bridge_revision_cache_and_idle_wake_avoid_history_rescans(self):
        q=self.q;q.leads(2);self.boot();self.settle();self.read()
        queries=[];connect=q.core.store.connect
        @contextmanager
        def traced():
            with connect() as db:
                db.set_trace_callback(queries.append);yield db
        def scans():
            return [sql for sql in queries if sql.lstrip().startswith(('SELECT l.id AS id','SELECT t.id AS task_id'))]
        with patch.object(q.core.store,'connect',traced):
            for i in range(5):
                q.core.store.put('ui_auto_analysis_workspace_v1',{'id':'synthetic-meta-'+str(i),'tenant_id':q.user['tenant_id']})
                self.read()
            before=scans()
            self.assertEqual(before,[],'warm backend read scanned historical lead bodies')
            self.f._analysis_queue.workspace['wake'].set();time.sleep(.2)
            self.assertEqual(scans(),[],'empty idle director scanned historical lead bodies')
        OBSERVATIONS.append({'stage':'warm-cache-and-idle','queries':queries})

if __name__=='__main__':
    stream=io.StringIO();result=unittest.TextTestRunner(stream=stream,verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(Combined))
    report={'at':datetime.now(timezone.utc).isoformat(),'syntheticOnly':True,'realPaidCalls':0,
        'sources':SOURCE_HASHES,'sourceBytesStable':all(hashlib.sha256(p.read_bytes()).hexdigest()==SOURCE_HASHES[str(p)] for p in PINNED_PATHS),
        'testsRun':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'passed':result.wasSuccessful(),'observations':OBSERVATIONS,
        'limits':'Actual candidate methods and frozen startup control flow; authority/transport/model are synthetic; not a claim of Native/DeepSeek acceptance.'}
    (HERE/'COMBINED-STARTUP.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),'utf-8')
    (HERE/'COMBINED-STARTUP.log').write_text(stream.getvalue(),'utf-8');print(stream.getvalue());print(json.dumps(report,ensure_ascii=False))
    raise SystemExit(0 if result.wasSuccessful() else 1)
