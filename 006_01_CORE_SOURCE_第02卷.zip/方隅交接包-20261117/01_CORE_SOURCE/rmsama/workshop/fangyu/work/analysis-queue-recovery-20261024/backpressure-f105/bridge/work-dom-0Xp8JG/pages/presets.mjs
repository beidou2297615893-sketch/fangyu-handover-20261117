const escape = value => String(value ?? '').replace(/[&<>"']/g, char => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));
const icon = name => `<img src="/assets/${name}" alt="" aria-hidden="true">`;
const previewStores=[{id:'古北店',name:'古北店',description:'古北核心区 · 成熟居住圈'},{id:'浦江店',name:'浦江店',description:'浦江新城 · 潜力发展区'},{id:'徐汇店',name:'徐汇店',description:'城市生活 · 便捷通勤'}];
function model(state){if(state.connection==='preview')state.store||='古北店';state.presets??={search:'精准获客',intent:'标准意向',tab:'presets',showWords:false,showRules:false};const p=state.presets,key=state.connection==='preview'?state.store:state.storeId;if(p.foldStore!==key){p.foldStore=key;p.showWords=false;p.showRules=false;}return p;}
const words = store => store==='浦江店'?['浦江租房','附近一居','地铁通勤','周边商圈']:store==='徐汇店'?['徐汇租房','附近一居','地铁通勤','周边商圈']:['古北租房','附近一居','地铁通勤','周边商圈'];

export function render(state){
  const p=model(state),preview=state.connection==='preview',admin=state.session?.user?.role==='admin',store=state.store||'待管理员分配',stores=preview?previewStores:state.stores||[];
  const searchOptions=preview?['精准获客','通勤拓展'].map(name=>({id:name,name})):state.catalog?.search||[];
  const intentOptions=preview?['标准意向','优先近期入住'].map(name=>({id:name,name})):state.catalog?.intent||[];
  const automatic=state.materials?.currentSelection?.automaticProfile===true;
  const gubei=state.storeId==='fy_s_d343f3a378f48e1bab55df4f'&&state.materials?.central?.localApprovedOverride;
  const gubeiNotice=gubei?'<p><strong>古北店：1—12个月都收</strong>，按1—3个月、4—11个月、12个月、未说明及其他租期分组。</p><p>围绕求租、装修过渡、实习、探亲和企业住宿寻找需求。本人或亲友代找保留；供房推广、已解决需求和泛兴趣分开，不按中介、房东、短租等字眼直接删除。</p><p>意向与门店适配分别判断。费用、房源、做饭、噪声、网络、宠物和逐房设施待核实，不作承诺。付款周期不等于租期。</p><p><strong>只采集与整理，回复由你手动操作。</strong>平台要求本人验证时保留断点。</p>':'';
  const material=(state.materials?.materials||[]).find(item=>item.key===p.materialKey),chosen=(material?.keywords||[]).filter(word=>word.eligible&&(p.keywordIds||[]).includes(word.id));
  const search=searchOptions.find(item=>item.id===p.search)||searchOptions[0],intent=intentOptions.find(item=>item.id===p.intent)||intentOptions[0];
  const materialCoverage=chosen.filter(word=>p.search!=='commute'||word.bindings?.some(binding=>binding.presetIds?.includes('commute'))).map(word=>word.keyword);
  const coverage=automatic?(search?.keywords||[]):material?materialCoverage:preview?(p.search==='通勤拓展'?[...words(store).slice(0,2),'沿线通勤','相邻区域']:words(store)):(search?.keywords||[]);
  const canApply=preview||Boolean(state.capabilities?.presets&&stores.length&&(automatic?coverage.length>0:!material||coverage.length>0&&chosen.length<=100)),disabled=state.busy?'disabled':'';
  return `<div class="presets-page" data-page-presets>
    <div class="presets-tabs" role="tablist" aria-label="门店获客设置"><button role="tab" data-preset-tab="presets" aria-selected="${p.tab==='presets'}">门店预设</button><button role="tab" data-preset-tab="rules" aria-selected="${p.tab==='rules'}">规则说明</button></div>
    ${p.tab==='rules'?`<section class="preset-card preset-rules-page"><h2>规则说明</h2>${gubeiNotice}<p>搜索预设决定寻找哪些租房需求，意向预设决定优先处理哪些咨询。</p><div><h3>搜索预设</h3><p>精准获客：围绕门店附近的一居室、商圈与地铁通勤需求。通勤拓展：扩大到相邻区域及交通沿线。</p><h3>意向预设</h3><p>${preview?'标准意向：综合租房需求、预算、区域与入住时间。优先近期入住：优先显示一个月内计划入住的咨询。':'租房与预算：区分本人求租、转租供应、引用和过去需求；具体当前看房或签租推进为高意向，明确求租但尚无推进为中意向，仅了解或远期计划为低意向，证据不足为待确认。预算保留月/年、整套/人均及房租/总费用口径，收入只记录本人自报。历史预设保留原选择，不会修改云端判断策略。'}</p><h3>回复建议</h3><p>超高 / 高意向建议人工回复，中意向可批量准备回复。所有动作均由用户确认。</p></div><button class="preset-secondary" data-preset-tab="presets">返回门店预设</button></section>`:`
    <section class="preset-card preset-store-card">
      <div class="preset-store-heading"><h2>选择门店</h2><p>选择门店后，将自动匹配该门店的搜索与意向预设</p></div>
      <div class="preset-stores">${stores.slice(0,2).map(item=>`<button class="preset-store ${(preview?state.store:state.storeId)===item.id?'selected':''}" data-preset-store="${escape(item.id)}" aria-pressed="${(preview?state.store:state.storeId)===item.id}" ${disabled}><span class="preset-store-radio"></span><span><strong>${escape(item.name)}</strong><small>${escape(item.description||item.region||'已分配门店')}</small></span><img src="/assets/fy-scene-01-apartment.png" alt="" aria-hidden="true"></button>`).join('')}<select class="preset-more-stores" data-preset-more aria-label="更多门店" ${disabled||(!stores.length?'disabled':'')}><option value="">更多门店</option>${stores.slice(2).map(item=>`<option value="${escape(item.id)}" ${(preview?state.store:state.storeId)===item.id?'selected':''}>${escape(item.name)}</option>`).join('')}</select></div>
      <p class="preset-current-store">${icon('tabler-upgrade-pin.svg')}<span>${stores.length?'当前门店：<strong>'+escape(store)+'</strong>':escape(state.capabilities?.reason||'暂未分配门店，请联系管理员。')}</span></p>
    </section>
    <section class="preset-card preset-plan-card" style="height:calc(503px * var(--space-y));min-height:0">
      <div class="preset-columns" style="min-height:0;overflow-y:auto;overflow-x:hidden">
        <section class="preset-column"><div class="preset-column-heading">${icon('approved-icon-search.svg')}<div><h2>搜索预设</h2><p>围绕本店位置，匹配附近租房需求</p></div></div>
          <select class="preset-plan-select" data-preset-search aria-label="搜索预设" ${disabled||(!canApply?'disabled':'')}>${searchOptions.map(item=>`<option value="${escape(item.id)}"${p.search===item.id?' selected':''}>${escape(store)} · ${escape(item.name)}</option>`).join('')}</select>
          <div class="preset-choice-row" role="group" aria-label="搜索方案">${searchOptions.map(item=>`<button class="preset-choice ${p.search===item.id?'selected':''}" data-preset-search-choice="${escape(item.id)}" aria-pressed="${p.search===item.id}" ${disabled||(!canApply?'disabled':'')}><span>${p.search===item.id?icon('tabler-upgrade-check.svg'):''}</span>${escape(item.name)}</button>`).join('')}</div>
          <h3 class="preset-coverage-title">覆盖方向</h3><div class="preset-tags">${coverage.slice(0,4).map(word=>`<span>${escape(word)}</span>`).join('')||'<span>门店词库待配置</span>'}</div>
          <button class="preset-link" data-preset-words aria-expanded="${p.showWords}">查看完整搜索词库 <img class="preset-chevron" src="/assets/tabler-chevron-down.svg" alt="" aria-hidden="true"></button>
          ${p.showWords&&automatic?`<div class="preset-expanded" style="max-height:220px;overflow:auto"><h4>${escape(store)} · 自动搜索词</h4><p>共 ${coverage.length} 个可用词，每次最多100词，尾段结束后下一次重新轮换。来源版本 ${escape(state.materials.currentSelection.sourceRevision)}；检索假设与已核事实分开保存。</p><p>${coverage.map(escape).join('　')||'暂无合格词，保留待核原资料。'}</p></div>`:p.showWords&&material?`<div class="preset-expanded" style="max-height:220px;overflow:auto"><h4>${escape(material.name)} · 搜索词</h4><p>${material.keywords.map(word=>escape(word.keyword)+(word.eligible?'':'（待核）')).join('　')||'当前门店词库待配置。'}</p>${admin?`<details style="margin-top:12px"><summary>管理搜索词与资料状态</summary><div><button type="button" class="preset-secondary" data-material-all ${disabled}>选择全部可用词</button> <button type="button" class="preset-secondary" data-material-none ${disabled}>清空选择</button></div><div>${material.keywords.map(word=>`<label style="display:inline-block;margin:5px 12px 5px 0"><input id="material-keyword-${escape(word.id)}" type="checkbox" data-material-keyword="${escape(word.id)}" ${(p.keywordIds||[]).includes(word.id)?'checked':''} ${!word.eligible?'disabled':disabled}> ${escape(word.keyword)}${!word.eligible?'（待核）':''}</label>`).join('')}</div><p>门店资料由中央服务器对应；选词和显示偏好保存在本机，最多选择100个可用词。费用、面积及优惠待核词暂不用于采集。</p></details>`:''}</div>`:p.showWords?`<div class="preset-expanded" style="max-height:220px;overflow:auto"><h4>${escape(store)} · ${escape(search?.name||'搜索')}词库</h4><p>${(preview?[...words(store),store.replace('店','')+'找房','精装一居','近期入住','预算3500','近地铁租房','可养宠物']:coverage).map(escape).join('　')||'该门店尚未配置搜索词库，请联系管理员。'}</p></div>`:''}
        </section>
        <section class="preset-column"><div class="preset-column-heading">${icon('tabler-upgrade-user.svg')}<div><h2>意向预设</h2><p>${preview?'自动识别租房需求与入住意向':intent?.assessmentEnabled?'核对求租语境与预算，收入只记录本人自报':'沿用历史意向规则和选择偏好'}</p></div></div>
          <select class="preset-plan-select" data-preset-intent aria-label="意向预设" ${disabled||(!canApply?'disabled':'')}>${intentOptions.map(item=>`<option value="${escape(item.id)}"${p.intent===item.id?' selected':''}>${escape(store)} · ${escape(item.name)}</option>`).join('')}</select>
          <div class="preset-choice-row" role="group" aria-label="意向方案">${intentOptions.map(item=>`<button class="preset-choice ${p.intent===item.id?'selected':''}" data-preset-intent-choice="${escape(item.id)}" aria-pressed="${p.intent===item.id}" ${disabled||(!canApply?'disabled':'')}><span>${p.intent===item.id?icon('tabler-upgrade-check.svg'):''}</span>${escape(item.name)}</button>`).join('')}</div>
          <div class="preset-intent-table">${intent?.assessmentEnabled?`<div><strong>${gubei?'超高 / 高意向':'高意向'}</strong><span>${gubei?'具体推进 / 具体房源咨询':'有当前具体推进，人工跟进'}</span></div><div><strong>中意向</strong><span>明确求租，进一步确认安排</span></div><div><strong>低意向</strong><span>仅了解或远期计划</span></div><div><strong>待确认</strong><span>先核对本人需求与当前状态</span></div>`:'<div><strong>超高 / 高意向</strong><span>建议人工回复</span></div><div><strong>中意向</strong><span>可批量回复</span></div>'}</div>
          <button class="preset-link" data-preset-rules aria-expanded="${p.showRules}">查看完整判断规则 <img class="preset-chevron" src="/assets/tabler-chevron-down.svg" alt="" aria-hidden="true"></button>
          ${p.showRules?`<div class="preset-expanded" style="max-height:220px;overflow:auto"><h4>${escape(intent?.name||'意向')}判断规则</h4>${gubeiNotice}${intent?.assessmentEnabled?`<p>先区分求租与供房，再核对当前行动；否定、引用和过去经历单独处理。高、中、低和待确认分开；缺预算或收入不降低意向。</p><p>预算保留币种、周期、整套或人均及费用口径。当前门店租金尚未核价，预算适配显示待核；收入只记录本人明确自报。</p>${admin?`<details><summary>规则状态与重新评估</summary><p>这是初始判断规则，需用真实咨询持续校准；历史AI与人工评级保留。</p><button id="recalculate-current-customers" class="preset-secondary" data-assessment-refresh ${disabled||(!state.selection?.applied?.rentalAssessmentEnabled?'disabled':'')}>重新评估现有客户</button></details>`:''}`:''}<p>${preview?'明确表达租房需求，并给出区域、预算或入住时间时优先显示。'+(p.intent==='优先近期入住'?'计划在一个月内入住的咨询优先。':'结合门店覆盖区域与一居需求，区分意向程度。')+'超高及高意向由人工核对后回复。':escape(intent?.description||'该门店的意向判断规则待管理员配置。')}</p></div>`:''}
        </section>
      </div>
      <div class="preset-plan-footer"><div class="preset-combination"><span class="preset-combination-icon">${icon('tabler-upgrade-file.svg')}</span><div><strong>${escape(store)} · ${escape(search?.name||'搜索预设')} · ${escape(intent?.name||'意向预设')}</strong><p>${preview?'已选择该组合，应用后将按此预设进行内容采集与意向判断':canApply?(intent?.assessmentEnabled?'应用后使用完整自动词库，并评估本机可见客户；点击开始后才采集':'保存本店搜索预设与历史选择偏好；点击开始后才采集'):material?'请选择1至100个可用于当前搜索预设的词':'请联系管理员分配门店后使用预设'}</p></div></div><button class="preset-apply" data-preset-apply ${disabled||(!canApply?'disabled':'')}>${icon('icon-play-filled.svg')}${state.busy?'保存中…':automatic?'应用本店自动预设':material?'保存本机选词并应用':'使用此预设'}</button></div>
    </section>`}
  </div>`;
}

export function bind(root,ctx){
  const change=fn=>ctx.update(state=>fn(model(state),state));
  const selectStore=storeId=>ctx.state.connection==='preview'?change((p,state)=>{state.store=storeId;}):ctx.actions.selectStore(storeId);
  for(const button of root.querySelectorAll('[data-preset-tab]'))button.addEventListener('click',()=>change(p=>{p.tab=button.dataset.presetTab;}));
  for(const button of root.querySelectorAll('[data-preset-store]'))button.addEventListener('click',()=>selectStore(button.dataset.presetStore));
  root.querySelector('[data-preset-more]')?.addEventListener('change',event=>{if(event.target.value)selectStore(event.target.value);});
  root.querySelector('[data-preset-search]')?.addEventListener('change',event=>change(p=>{p.search=event.target.value;}));
  root.querySelector('[data-preset-intent]')?.addEventListener('change',event=>change(p=>{p.intent=event.target.value;}));
  for(const button of root.querySelectorAll('[data-preset-search-choice]'))button.addEventListener('click',()=>change(p=>{p.search=button.dataset.presetSearchChoice;}));
  for(const button of root.querySelectorAll('[data-preset-intent-choice]'))button.addEventListener('click',()=>change(p=>{p.intent=button.dataset.presetIntentChoice;}));
  root.querySelector('[data-preset-words]')?.addEventListener('click',()=>change(p=>{p.showWords=!p.showWords;}));
  root.querySelector('[data-preset-rules]')?.addEventListener('click',()=>change(p=>{p.showRules=!p.showRules;}));
  root.querySelectorAll('[data-material-keyword]').forEach(input=>input.addEventListener('change',()=>change(p=>{p.keywordIds=input.checked?[...new Set([...(p.keywordIds||[]),input.dataset.materialKeyword])]:(p.keywordIds||[]).filter(id=>id!==input.dataset.materialKeyword);})));
  root.querySelector('[data-material-all]')?.addEventListener('click',()=>change((p,state)=>{p.keywordIds=(state.materials?.materials?.find(item=>item.key===p.materialKey)?.keywords||[]).filter(word=>word.eligible).slice(0,100).map(word=>word.id);}));
  root.querySelector('[data-material-none]')?.addEventListener('click',()=>change(p=>{p.keywordIds=[];}));
  root.querySelector('[data-assessment-refresh]')?.addEventListener('click',()=>ctx.actions.refreshAssessments?.());
  root.querySelector('[data-preset-apply]')?.addEventListener('click',()=>{
    if(ctx.state.connection!=='preview'){ctx.actions.applyPreset();return;}
    const p=model(ctx.state);
    ctx.update(state=>{state.acquire??={region:'上海 · 长宁区',time:'最近7天',platforms:['小红书','抖音'],status:'idle',stage:0,tick:0,read:0,added:0,analyzed:0,duplicates:0,records:[]};if(['running','paused'].includes(state.acquire.status)){state.acquire.records.unshift({text:`${state.acquire.run?.store||state.store} · 已应用新预设，本次演示结束`,status:'已停止'});Object.assign(state.acquire,{status:'idle',stage:0,tick:0,read:0,added:0,analyzed:0,duplicates:0,run:null});}state.acquire.region=state.store==='浦江店'?'上海 · 闵行区':state.store==='徐汇店'?'上海 · 徐汇区':'上海 · 长宁区';state.acquire.searchPreset=p.search;state.acquire.intentPreset=p.intent;});
    ctx.navigate('acquire');ctx.toast(`已应用${ctx.state.store} · ${p.search} · ${p.intent}`);
  });
  return ()=>{};
}
