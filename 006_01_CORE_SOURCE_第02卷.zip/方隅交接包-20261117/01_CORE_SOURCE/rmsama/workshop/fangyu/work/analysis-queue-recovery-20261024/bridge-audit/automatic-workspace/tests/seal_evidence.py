"""Seal only the five automatic-workspace bridge sources after pinned checks."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, subprocess

ROOT = Path(__file__).resolve().parents[1]
W = ROOT.parents[1]
BASE = Path('C:/积木软件工坊/项目/方隅公寓客户版/work/parallel-integration-20261018/final-integration/candidate-unified-v103/project')
RELEASE = BASE / 'work/ui-native-r57/releases/ui-r57-20261024T144455Z-0597e0ca'
CORE = W / 'core-audit/automatic-workspace-recovery'
EVIDENCE = ROOT / 'evidence'
CORE_SHA = '9520b2f3d2efddfc2a2e341655c8e30a84074eb54d81bab01b13cae4c5c208b3'
def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def descriptor(path): return {'path':str(path),'sha256':sha(path)}
def save(path,value): path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

core_seal = json.loads((CORE/'SEALED.json').read_text('utf-8-sig'))
assert core_seal['sealed'] and core_seal['passed'] and core_seal['authorStopped']
assert sha(CORE/'candidate/analysis_queue_runtime.py') == CORE_SHA == core_seal['moduleSha256']
assert sha(CORE/'evidence/VALIDATION.json') == core_seal['validationSha256']
paths = [
 ('work/ui-native-r57/workbench_backend.py','workbench_backend.py'),
 ('work/ui-native-r57/ui_native_host.py','ui_native_host.py'),
 ('work/ui-approved-implementation/ui-preview/backend.mjs','web/backend.mjs'),
 ('work/ui-approved-implementation/ui-preview/pages/acquire.mjs','web/pages/acquire.mjs'),
 ('work/ui-approved-implementation/ui-preview/pages/saved-comment-analysis.mjs','web/pages/saved-comment-analysis.mjs'),
]
files=[]
for relative, frozen in paths:
    candidate=ROOT/'candidate'/relative; baseline=BASE/relative
    assert sha(baseline)==sha(RELEASE/frozen), ('F103 source/frozen mismatch',relative)
    assert sha(candidate)!=sha(baseline), ('unchanged source must not be composed',relative)
    files.append({'relativePath':relative,'candidate':str(candidate),'sha256':sha(candidate),
      'baselinePath':str(baseline),'baselineSha256':sha(baseline),'releaseRelativePath':frozen})
assert files[0]['sha256']=='f1dda5a7c7157935396fa26e581f8dc12718fc110e982e4e192be49e59700607'
unchanged='work/ui-approved-implementation/ui-preview/app.mjs'
assert sha(ROOT/'candidate'/unchanged)==sha(BASE/unchanged)

tests=[]
for log,cases,command in [
 ('FINAL-BACKEND.log',4,'python -m unittest discover -s tests -p test_auto_bridge.py -v'),
 ('FINAL-HOST.log',4,'python -m unittest discover -s tests -p test_auto_host.py -v'),
 ('FINAL-UI.log',11,'node tests/test_auto_ui.mjs'),
 ('FINAL-TRANSPORT.log',4,'node tests/test_auto_transport.mjs'),
 ('FINAL-COLD-9520.log',1,'python tests/test_cold_bootstrap_drain.py'),
]:
    text=(EVIDENCE/log).read_text('utf-8-sig')
    if log in ('FINAL-BACKEND.log','FINAL-HOST.log'):
        assert f'Ran {cases} tests' in text and '\nOK\n' in text
    else:
        payload=json.loads(next(line for line in reversed(text.splitlines()) if line.startswith('{')))
        assert payload['passed']
        if log=='FINAL-COLD-9520.log': assert payload['controllerSha256']==CORE_SHA
        else: assert payload['cases']==cases
    tests.append({'command':command,'passed':True,'cases':cases,'evidence':descriptor(EVIDENCE/log)})

syntax=[]
for item in files:
    path=Path(item['candidate'])
    if path.suffix=='.py': compile(path.read_text('utf-8-sig'),str(path),'exec')
    else:
        result=subprocess.run(['node','--check',str(path)],capture_output=True,text=True)
        assert result.returncode==0,result.stderr
    syntax.append({'relativePath':item['relativePath'],'passed':True})
save(EVIDENCE/'FINAL-SYNTAX.json',{'passed':True,'checks':syntax})
validation={
 'schema':'automatic-workspace-bridge-isolated-candidate-v1',
 'createdAt':datetime.now(timezone.utc).isoformat(),
 'passed':True,'authorStopped':True,'baseProject':str(BASE),'candidateRoot':str(ROOT/'candidate'),
 'files':files,'tests':tests,'syntax':descriptor(EVIDENCE/'FINAL-SYNTAX.json'),
 'coreSeal':descriptor(CORE/'SEALED.json'),'coreValidation':descriptor(CORE/'evidence/VALIDATION.json'),
 'controllerSha256':CORE_SHA,
 'unchangedApp':{'relativePath':unchanged,'sha256':sha(BASE/unchanged),'includedInComposition':False},
 'contract':{'actions':['analysis_workspace_read','analysis_workspace_pause','analysis_workspace_resume'],
   'automaticStart':'trusted bootstrap/identity -> RAM authorize -> background fresh verification -> existing service.start/_run',
   'normalAnalysisRequiresButton':False,'resumeRequiresConfirmation':False,
   'scope':'current verified employee and selected store; seven owned saved tasks in the representative fixture',
   'countInvariant':'total = pending + processing + held + analyzed + missingText; remaining = pending + processing',
   'processing':'current controlled unresolved request subset, dynamic PK point reads, never historical held inflation',
   'localReads':'poll/read/pause reuse local authority; no new identity HTTP on read',
   'coldStartup':'executor starts as None; actual extracted AssistantService.start/_run creates executor; no prepare/configure/download/platform collection',
   'cache':'existing CustomerReadStore durable revision, device/inode identity, schema cache; actual revision callback',
   'manualReply':'existing reply state, original AI, task records and old unresolved ledger preserved'},
 'representativeColdResult':{'total':2068,'newlyAnalyzed':244,'remaining':0,'processing':0,'held':9,'missingText':21,
   'analyzedAfter':2038,'existingAiPreserved':1794,'initialPage':'reply','initialExecutor':None,'analysisActions':0,'modalCount':0},
 'boundary':{'productionWrites':0,'realCloudCalls':0,'realModelCalls':0,'platformCalls':0,'nativeProcessesStarted':0},
 'unverified':['real reopened Native and enterprise provider execution; parent owns F104 freeze/install and actual readback'],
 'historicalRuns':'Prior intermediate source-drift/timeout checks are not counted as final passes; final cold log is bound to sealed 9520 bytes.'
}
save(EVIDENCE/'VALIDATION.json',validation)
seal={'schema':'automatic-workspace-bridge-seal-v1','sealed':True,'authorStopped':True,'passed':True,
 'validation':str(EVIDENCE/'VALIDATION.json'),'validationSha256':sha(EVIDENCE/'VALIDATION.json'),
 'files':files,'coreModuleSha256':CORE_SHA,'coreSealSha256':sha(CORE/'SEALED.json')}
save(ROOT/'SEALED.json',seal)
print(json.dumps({'passed':True,'validation':descriptor(EVIDENCE/'VALIDATION.json'),'seal':descriptor(ROOT/'SEALED.json'),'files':files},ensure_ascii=False))
