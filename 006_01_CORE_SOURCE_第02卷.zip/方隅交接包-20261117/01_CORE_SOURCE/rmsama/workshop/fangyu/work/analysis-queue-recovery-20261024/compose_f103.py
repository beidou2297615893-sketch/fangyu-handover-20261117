"""Isolate the retired original-status route; keep F102 and its UI immutable."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,importlib.util,json,shutil,sys
sys.dont_write_bytecode=True
sys.stdout.reconfigure(encoding='utf-8')
W=Path(__file__).resolve().parent;P=W.parents[1]
F=P/'work/parallel-integration-20261018/final-integration'
OLD=F/'candidate-unified-v102'
PUBLIC=P/'work/complete-product-resume-20261024/live-acquisition-acceptance-20261024/project'
read=lambda p:json.loads(p.read_text('utf-8-sig'));sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert len(sys.argv)==4 and sys.argv[1:3]==['--compose','--pins']
source_pins=Path(sys.argv[3]).resolve();assert source_pins.is_relative_to(W/'core-audit')
v3=read(source_pins)
assert v3['passed'] is True
rows=v3['files'];assert len(rows)==1
row=rows[0]
rel='work/shared-backend-integration/analysis_queue_runtime.py'
assert row['relativePath']==rel and sha(Path(row['candidate']))==row['sha256']
assert sha(PUBLIC/rel)==sha(OLD/'project'/rel)==row['baselineSha256']
assert not (F/'candidate-unified-v103').exists()
spec=importlib.util.spec_from_file_location('existing_f102_freezer',F/'freeze_unified.py')
builder=importlib.util.module_from_spec(spec);spec.loader.exec_module(builder);builder.SOURCE=PUBLIC
baseline=read(OLD/'INPUT-SNAPSHOT.json')
actual={p.relative_to(PUBLIC).as_posix():sha(p) for p in builder.input_files()}
assert actual==baseline['files'],'Unreviewed public source change'
pack=W/'package'
backup=pack/'public-before-f103';backup.mkdir(exist_ok=False)
shutil.copy2(PUBLIC/rel,backup/'analysis_queue_runtime.py')
shutil.copy2(Path(row['candidate']),PUBLIC/rel)
composition={'atUtc':datetime.now(timezone.utc).isoformat(),'baselineInputFiles':len(actual),
    'baselineInputsMatchF102':True,'changes':rows,'sourceValidation':str(source_pins),
    'sourceValidationSha256':sha(source_pins),'productionWrites':0,'currentWindowOperated':False}
(pack/'ROOT-COMPOSITION-V103.json').write_text(json.dumps(composition,ensure_ascii=False,indent=2)+'\n','utf-8')
sys.argv=[str(F/'freeze_unified.py'),'--candidate','candidate-unified-v103'];builder.main()
out=F/'candidate-unified-v103';stage=read(out/'STAGED.json');native=Path(stage['release'])
old_native=Path(read(OLD/'STAGED.json')['release'])
a={p.relative_to(old_native).as_posix():sha(p) for p in old_native.rglob('*') if p.is_file()}
b={p.relative_to(native).as_posix():sha(p) for p in native.rglob('*') if p.is_file()}
delta=sorted(k for k in a.keys()|b.keys() if a.get(k)!=b.get(k))
assert delta==['RELEASE.json','resources/platform-runtime/analysis_queue_runtime.py'],delta
pins={'status':'FROZEN_PENDING_VERIFICATION','releaseId':stage['release_id'],'release':str(native),
    'project':str(out/'project'),'unifiedPinsSha256':sha(out/'UNIFIED-PINS.json'),
    'stagedSha256':sha(out/'STAGED.json'),'manifestSha256':sha(native/'RELEASE.json'),
    'changedProductSourceFiles':1,'changedReleaseFiles':delta,'productionWrites':0,
    'installed':False,'actualNewNativeVerified':False}
(pack/'ROOT-FINAL-PINS-V103.json').write_text(json.dumps(pins,ensure_ascii=False,indent=2)+'\n','utf-8')
print(json.dumps(pins,ensure_ascii=False),flush=True)
