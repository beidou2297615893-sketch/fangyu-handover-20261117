import copy
import ast
import threading
import time
import types
import unittest
from test_bridge_contract import extracted, Failure, NATIVE
from test_combined_controller import combined

def local_fixture():
    f=combined()
    f._analysis_authority_lock=threading.RLock();f._analysis_authorities={}
    f._remember_analysis_authority=types.MethodType(extracted('_remember_analysis_authority'),f)
    f._analysis_local_identity=types.MethodType(extracted('_analysis_local_identity'),f)
    f.profile['_central_directory']={'catalog_digest':'fixture','scope':{'grant_revision':'fixture'}}
    return f

class LocalAuthority(unittest.TestCase):
    def test_actual_verifier_inheritance_uses_one_me_and_one_directory_call(self):
        f=local_fixture();f.profile.update(username=f.user['username'],role=f.user['role'])
        f.core._public=lambda user:copy.deepcopy(user)
        class BaseIntegrations:
            def __init__(self,core):self.core=core;self.identity_cache={};self.calls=[]
            def _read(self,tenant):return {}
            def _cloud(self,config,user,operation,**data):
                self.calls.append(operation);return {'user':copy.deepcopy(f.profile)}
        tree=ast.parse((NATIVE/'workbench_backend.py').read_text(encoding='utf-8-sig'))
        names=('_ProfileIntegrations','_ReadOnlyDeliveryIntegrations','_MediaReadIntegrations')
        nodes=[n for n in tree.body if isinstance(n,ast.ClassDef) and n.name in names]
        scope={'Integrations':BaseIntegrations,'IntegrationError':ValueError,'deepcopy':copy.deepcopy,'time':time,'_classify_cloud_failure':lambda e:e}
        exec(compile(ast.Module(body=nodes,type_ignores=[]),'<real-inheritance>','exec'),scope)
        verifier=scope['_MediaReadIntegrations'](f.core)
        def directory(integration,user):
            integration._cloud({},user,'store_config_read')
            return [{'id':'store1'}],'',f.profile['_central_directory']
        f._read_store_directory=directory
        identity=extracted('_identity')
        identity.__globals__['_CloudServiceUnavailable']=RuntimeError
        identity(f,'fixture-token',verification=verifier)
        self.assertEqual(verifier.calls,['me','store_config_read'])

    def test_local_read_reuses_only_verified_ram_snapshot_with_zero_identity_calls(self):
        f=local_fixture();f._remember_analysis_authority('fixture-token',f.user,f.profile)
        f._identity=lambda *a,**kw:(_ for _ in ()).throw(AssertionError('local read contacted identity'))
        for _ in range(10):
            v=f._analysis_queue_dispatch('analysis_queue_read',{'storeId':'store1','taskId':'task1'},'fixture-token')
            self.assertEqual(v['analysisQueue']['counts']['pending'],200)
        self.assertEqual(f.core.store.writes,0)
        self.assertIsNone(f._analysis_queue.active)

    def test_cold_and_expired_reads_fail_closed_without_network(self):
        f=local_fixture()
        f._identity=lambda *a,**kw:(_ for _ in ()).throw(AssertionError('cold read contacted identity'))
        with self.assertRaises(Failure):f._analysis_local_identity('fixture-token')
        f._remember_analysis_authority('fixture-token',f.user,f.profile)
        for v in f._analysis_authorities.values():v['expires']=time.monotonic()-1
        with self.assertRaises(Failure):f._analysis_local_identity('fixture-token')
        user,profile=f._analysis_local_identity('fixture-token',allow_expired=True)
        self.assertEqual(user['username'],'tester')

    def test_changed_actor_and_current_store_are_not_hidden_by_snapshot(self):
        f=local_fixture();f._remember_analysis_authority('fixture-token',f.user,f.profile)
        f.selected='store2'
        user,profile=f._analysis_local_identity('fixture-token')
        self.assertEqual(user['_workbench_store_id'],'store2')
        self.assertEqual(profile['_workbench_store_id'],'store2')
        f.user['username']='other'
        with self.assertRaises(Failure):f._analysis_local_identity('fixture-token')

    def test_refresh_fresh_only_performs_remote_path_when_requested(self):
        f=local_fixture();f._remember_analysis_authority('fixture-token',f.user,f.profile)
        calls=[]
        def identity(token,**kw):calls.append(token);f._remember_analysis_authority(token,f.user,f.profile);return copy.deepcopy(f.user),copy.deepcopy(f.profile)
        f._identity=identity
        refresh=f._analysis_queue_refresh('fixture-token','store1','task1',require_analysis=True)
        for _ in range(15):refresh(fresh=False)
        self.assertEqual(calls,[])
        refresh(fresh=True)
        self.assertEqual(calls,['fixture-token'])
        f.selected='store2'
        with self.assertRaises(Failure):refresh(fresh=False)

    def test_remote_failure_retains_stop_only_scope_without_authorizing_read(self):
        f=local_fixture();f._remember_analysis_authority('fixture-token',f.user,f.profile)
        def failed(*a,**kw):raise Failure('AUTH_SERVICE_UNAVAILABLE','synthetic outage',503)
        f._identity=failed
        refresh=f._analysis_queue_refresh('fixture-token','store1','task1',require_analysis=True)
        with self.assertRaises(Failure):refresh(fresh=True)
        with self.assertRaises(Failure):f._analysis_local_identity('fixture-token',allow_expired=True)
        # Pausing uses the retained original scope and local valid session only.
        got=f._analysis_queue_dispatch('analysis_queue_pause',{'storeId':'store1','taskId':'task1'},'fixture-token')
        self.assertEqual(got['analysisQueue']['taskId'],'task1')

    def test_explicit_resume_can_fresh_recover_from_cold_snapshot(self):
        f=local_fixture()
        f.core.store.rows={key:v for key,v in f.core.store.rows.items() if key[0] not in ('leads','ai_attempts','ai_jobs')}
        calls=[]
        def fresh_identity(token,**kw):
            calls.append(token);f._remember_analysis_authority(token,f.user,f.profile)
            return copy.deepcopy(f.user),copy.deepcopy(f.profile)
        f._identity=fresh_identity
        response=f._analysis_queue_dispatch('analysis_queue_resume',{'storeId':'store1','taskId':'task1','confirmed':True},'fixture-token')
        self.assertTrue(response['analysisQueue']['accepted'])
        self.assertTrue(f._analysis_queue.wait_for_idle(1))
        self.assertEqual(calls,['fixture-token'])
        f._analysis_queue.close()

    def test_outage_after_model_started_cannot_prevent_local_pause(self):
        from test_review_memory import memory
        f=memory(21)
        f._analysis_authority_lock=threading.RLock();f._analysis_authorities={}
        f._remember_analysis_authority=types.MethodType(extracted('_remember_analysis_authority'),f)
        f._analysis_local_identity=types.MethodType(extracted('_analysis_local_identity'),f)
        def fresh_identity(token,**kw):
            f._remember_analysis_authority(token,f.user,f.profile)
            return copy.deepcopy(f.user),copy.deepcopy(f.profile)
        f._identity=fresh_identity
        entered=threading.Event();release=threading.Event()
        f.on_model=lambda:(entered.set(),release.wait(2))
        f._analysis_queue_dispatch('analysis_queue_resume',{'storeId':'store1','taskId':'task1','confirmed':True},'fixture-token')
        self.assertTrue(entered.wait(1))
        def failed(*a,**kw):raise Failure('AUTH_SERVICE_UNAVAILABLE','synthetic outage',503)
        f._identity=failed
        with self.assertRaises(Failure):f._analysis_queue_refresh('fixture-token','store1','task1',require_analysis=True)(fresh=True)
        result=f._analysis_queue_dispatch('analysis_queue_pause',{'storeId':'store1','taskId':'task1'},'fixture-token')
        self.assertTrue(result['analysisQueue']['accepted'])
        self.assertTrue(f._analysis_queue.active['stop'].is_set())
        release.set();self.assertTrue(f._analysis_queue.wait_for_idle(1));f._analysis_queue.close()
        self.assertTrue(all(not row.get('ai_intent') for row in f.core.store.list('leads','tenant')))

if __name__=='__main__':unittest.main(verbosity=2)
