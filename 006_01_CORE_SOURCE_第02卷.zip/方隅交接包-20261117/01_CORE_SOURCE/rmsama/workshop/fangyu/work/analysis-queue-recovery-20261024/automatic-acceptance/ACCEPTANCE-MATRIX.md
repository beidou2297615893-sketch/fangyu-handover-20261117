# 自动分析独立验收矩阵

本审查只读产品候选和既有证据。自建 SQLite、合成身份和模型传输位于本目录；不实例化正式 Core，不操作当前 Native，不调用真实云、模型、平台或发送接口。

## 本轮验收口径

必须从真实 bootstrap/登录/门店提交接线启动，初始页面设为回复；不能先调用手动 resume、预填服务 executor 或模拟按钮来冒充自动。已知真实基线：同门店7任务，1794原分析、244可分析、9原未知待核、21缺正文，总2068。这里只能证明隔离组合行为，实际新版本与真实 DeepSeek 回执仍由 Root 验证。

| 场景 | 必须看到的证据 | 阻断条件 |
|---|---|---|
| 冷启动停留回复页 | 原 bootstrap→可信 RAM 授权→原 AssistantService.start/_run 调工厂得到 executor→分析增长；零按钮 | fixture预塞executor、等获客页poll才启动、None被永久记为身份错误 |
| 登录和换店提交 | 登录旧控制器关闭后新 token 再授权；换店保存后只处理新店 | 旧店授权后关闭且漏掉新店，旧run继续提交 |
| strong identity重入 | fresh 回入只更新回调，director/模型消费者仍单一 | 每个fresh建线程、循环自唤醒或代际不停改变 |
| 7任务积压 | 自动处理244至0；1794/9原UUID与digest/21缺正文不变 | 只处理当前186、整任务unknown冻结其他有效评论、伪造30条分析 |
| 采集暂停/验证/切客户 | 分析继续；前端 cleanup不发暂停动作 | 生命周期仍绑采集event/页面DOM |
| 分析A时采集B | 同actor/store的新采集授权与保存通过，B随后自动处理 | authorize_collection被其他分析task的Busy挡住 |
| 反向解耦 | AI暂停/预算/不可用时B仍可入库到原缓冲上限；自动分析保持暂停 | 把intent_analysis权限/预算作为采集授权前提，或采集启动偷偷恢复分析 |
| 空闲后新页/导入 | 新评论自动唤醒，无需resume | 处理完成后consumer永久结束，或只识别新row而漏已有记录的资料补全 |
| 只剩held/缺正文 | counts准确，等待期间零新模型/旧状态轮询 | 对30条反复发模型/远端profile或假显示处理中 |
| 本人暂停/重开 | 暂停偏好保留；恢复一次后持续消费；普通关闭不变永久暂停 | 每次身份hook清暂停，或正常关闭落永久blocked导致重开不恢复 |
| 真正权限/预算/新unknown | 新提交/结果应用受原fresh/预算/CAS；不盲重试和不重放 | 吞401/403或用新UUID绕旧付费不确定 |
| 全店计数缓存 | 相同业务revision的读/poll不扫历史body，metadata写不失效，lead/attempt变化后新数准确 | 每3秒扫描全历史、用新connection data_version、缓存状态而非仅计数 |

## 初步具体发现（候选未封定，已交作者）

1. F103真实 Runtime 的服务启动位于 `prepare()`，constructor/bootstrap没有隐式start。早期自动候选在executor=None时直接落持久身份blocked，必须增加后台启动已绑定服务与等待；不得调用prepare/_configure/配对/CLI来完成它。
2. 早期候选仍用旧 `authorize_collection` Busy门槛，自动处理历史A会挡新采集B。作者已接收并补同workspace授权路径。
3. 反向解耦需单独检查：AI暂停/intent特性不允许不能拒绝已有真正采集权限的入库。用户明确暂停自动分析不能被新采集解除。
4. 全店计数原为streaming，但每次仍扫描历史。Root已将复用持久revision的无变化计数cache列本轮门槛；需考虑ai_attempts不在原business revision监听范围。

以上是审查发现及必须验证的行为，未声称候选或真人已经通过。
