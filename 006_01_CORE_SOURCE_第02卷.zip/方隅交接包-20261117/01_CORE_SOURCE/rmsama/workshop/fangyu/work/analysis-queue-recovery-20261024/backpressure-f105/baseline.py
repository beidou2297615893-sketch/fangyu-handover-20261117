"""Private consistent RO backup and preservation baseline for existing F104 data."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,sqlite3,sys
D=Path(__file__).resolve().parent; W=D.parent; P=W.parents[1]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
bpath=P/'work/ui-native-r57/state/production-workspace.json'
assert sha(bpath)=='14cf53964f5d44d123e989805ea741669ab3f05054e730ddcb299a0aac51a9cb'
b=json.loads(bpath.read_text('utf-8-sig'))
tenant='cloud-'+hashlib.sha256((b['environment_id']+'\n'+b['company_id']).encode()).hexdigest()[:24]
source=Path(b['data_dir'])/'workspace.sqlite3'
private=D/'private';private.mkdir(exist_ok=True)
target=private/'workspace-before.sqlite3'
assert not target.exists()
db=sqlite3.connect(source.as_uri()+'?mode=ro',uri=True,timeout=3)
try:
 db.execute('PRAGMA query_only=ON')
 dest=sqlite3.connect(target)
 try:db.backup(dest)
 finally:dest.close()
 db.execute('BEGIN')
 result={}
 for entity in ('leads','tasks','ai_jobs','ai_attempts','ai_cache','rental_assessments_v1','rental_task_context_v1','replies','ui_reply_requests_v1','ui_reply_delivery_v1','accounts'):
  rows=db.execute('SELECT id,body FROM records WHERE entity=? AND tenant_id=? ORDER BY id',(entity,tenant)).fetchall()
  raw=json.dumps(rows,ensure_ascii=False,separators=(',',':')).encode()
  result[entity]={'count':len(rows),'sha256':hashlib.sha256(raw).hexdigest()}
finally:db.close()
report={'atUtc':datetime.now(timezone.utc).isoformat(),'data':result,'backup':str(target),'backupSha256':sha(target),'sourceWrites':0}
with (D/'FORMAL-BEFORE.json').open('x',encoding='utf-8') as f:f.write(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'baselineCounts':{k:v['count'] for k,v in result.items()},'consistentPrivateBackup':True,'sourceWrites':0}))
