param(
  [Parameter(Mandatory=$true)][string]$SourceProject,
  [Parameter(Mandatory=$true)][string]$ReleaseDir,
  [Parameter(Mandatory=$true)][string]$OutputDir,
  [string]$Python='C:/Users/rmsama/miniconda3/python.exe'
)
$ErrorActionPreference='Stop'
$controller=Join-Path $ReleaseDir 'resources/platform-runtime/analysis_queue_runtime.py'
if (-not (Test-Path -LiteralPath $controller -PathType Leaf)) { throw 'Frozen controller missing' }
if (Test-Path -LiteralPath $OutputDir) { throw 'Use a new output directory; keep prior evidence intact' }
New-Item -ItemType Directory -Path $OutputDir | Out-Null
$workspaceSources=Join-Path $OutputDir 'workspace-sources'
New-Item -ItemType Directory -Path $workspaceSources | Out-Null
Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'test_workspace.py') -Destination $workspaceSources
Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'test_analysis_queue_base.py') -Destination $workspaceSources
$env:ANALYSIS_QUEUE_CONTROLLER=$controller
$env:ANALYSIS_QUEUE_SOURCE_PROJECT=$SourceProject
$env:ANALYSIS_QUEUE_BASE_RELEASE=$ReleaseDir
$env:PYTHONDONTWRITEBYTECODE='1'
$env:PYTHONUTF8='1'
& $Python (Join-Path $workspaceSources 'test_workspace.py') *> (Join-Path $OutputDir 'workspace.stdout.log')
if ($LASTEXITCODE -ne 0) { throw 'Workspace isolated checks failed; see workspace.stdout.log' }
$env:ANALYSIS_QUEUE_EVIDENCE=Join-Path $OutputDir 'task-regression'
& $Python (Join-Path $workspaceSources 'test_analysis_queue_base.py') *> (Join-Path $OutputDir 'task.stdout.log')
if ($LASTEXITCODE -ne 0) { throw 'Task regression failed; see task.stdout.log' }
& $Python (Join-Path $PSScriptRoot 'tests/test_legacy_status.py') --module $controller --output (Join-Path $OutputDir 'legacy-regression') *> (Join-Path $OutputDir 'legacy.stdout.log')
if ($LASTEXITCODE -ne 0) { throw 'Legacy safety regression failed; see legacy.stdout.log' }
[ordered]@{passed=$true;controller=$controller;controllerSha256=(Get-FileHash -Algorithm SHA256 -LiteralPath $controller).Hash.ToLower();
  workspaceChecks=26;taskChecks=18;legacyChecks=12;realCloudModelOrCliCalls=0;productionDataAccess=0} |
  ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $OutputDir 'RESULT.json') -Encoding utf8
