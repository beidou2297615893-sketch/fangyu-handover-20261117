"""Independent review: real scheduler/runtime methods, in-memory authority only."""
import copy
import importlib.util
import threading
import time
import types
import unittest
from test_combined_controller import combined, controller, ROOT

runtime_path=ROOT.parent/'core-audit/candidate/platform_runtime.py'
spec=importlib.util.spec_from_file_location('review_real_runtime',runtime_path)
runtime_module=importlib.util.module_from_spec(spec);spec.loader.exec_module(runtime_module)

class Unknown(ValueError):code='PRODUCT_REQUEST_UNKNOWN'

class MemoryWorkflow:
    def __init__(self,core,cloud,**kw):self.core,self.cloud=core,cloud
    def analyze(self,user,task,rows,**kw):
        self.core.review_batch+=1
        ident='new-attempt-'+str(self.core.review_batch)
        row={'id':ident,'tenant_id':user['tenant_id'],'owner':user['username'],'operation':'intent_analyze',
             'state':'submitted','request_id':ident,'submission_id':ident,
             'lead_digests':[controller._digest([user['tenant_id'],user['username'],r['id']]) for r in rows]}
        with self.core.lock:self.core.store.put('ai_attempts',row)
        try:self.cloud(user,'intent_analyze',{'request_id':ident,'submission_id':ident,'ids':[r['id'] for r in rows]})
        except Exception:
            with self.core.lock:self.core.store.put('ai_attempts',{**row,'state':'unknown'})
            raise
        with self.core.lock:
            for lead in rows:
                current=self.core.store.get('leads',lead['id'])
                if not current.get('ai_intent') and not current.get('manual_intent'):
                    self.core.store.put('leads',{**current,'ai_intent':{'status':'graded','level':'medium'}})
            self.core.store.put('ai_attempts',{**row,'state':'validated'})
        return {'analyzed':len(rows)}

class MemoryExecutor:
    def analyze_pending(self,user,data,*,explicit_retry=False):
        assert explicit_retry is False
        task=self.core.store.get('tasks',data['task_id'])
        rows=list(self._analysis_visible_leads(user,task))
        return self.ai.analyze(user,task,rows,explicit_retry=explicit_retry)

def memory(count):
    f=combined();store=f.core.store
    store.rows={key:value for key,value in store.rows.items() if key[0] not in ('leads','ai_attempts','ai_jobs')}
    f.core.review_batch=0
    f.core.task_progress=lambda ident:{}
    f.core.adapters=types.SimpleNamespace(xhs_page_runtime=None)
    old=f.platform_runtime.service.executor
    executor=MemoryExecutor();executor.__dict__.update(vars(old))
    f.calls=[];f.on_model=None
    def cloud(user,op,payload):
        f.calls.append((op,copy.deepcopy(payload)))
        if f.on_model:f.on_model()
        return {'synthetic':True}
    executor.ai=types.SimpleNamespace(cloud=cloud,company=lambda:executor.server.company,
        analyze=lambda *a,**kw:None,attempts=types.SimpleNamespace(host_context=lambda:{'host':'fixture'},status=lambda *a,**kw:None))
    executor._analysis_visible_leads=lambda user,task,rows=None:(rows if rows is not None else store.list_task_leads(user['tenant_id'],task['id']))
    f.platform_runtime.service.executor=executor
    f._analysis_queue_factory=lambda runtime:controller.AnalysisQueueRuntime(runtime,workflow_factory=MemoryWorkflow)
    f.platform_runtime._task=lambda user,ident:store.get('tasks',ident)
    def add(n,start=0):
        for i in range(start,start+n):
            store.rows[('leads',str(i))]={'id':str(i),'tenant_id':'tenant','cloud_owner':'tester','task_id':'task1','text':'合成评论 '+str(i),
                'platform':'xiaohongshu','source_type':'comment','note_url':'https://www.xiaohongshu.com/explore/123456789012345678901234','content_title':'same post'}
    add(count);f.add=add
    store.rows[('replies','manual')]=dict(id='manual',tenant_id='tenant',owner='tester',text='人工回复保持')
    return f

def read(f):return f._analysis_queue_dispatch('analysis_queue_read',{'storeId':'store1','taskId':'task1'},'fixture-token')['analysisQueue']
def wait(f,count):
    limit=time.monotonic()+3
    while time.monotonic()<limit:
        v=read(f)
        if not v['running'] and v['counts']['analyzed']==count:return v
        time.sleep(.005)
    raise AssertionError('Memory scheduler did not reach target: '+str(v))

class Review(unittest.TestCase):
    def test_two_batches_use_five_fresh_boundaries_and_polling_adds_none(self):
        f=memory(21);calls=[]
        original=f._identity
        def identity(*a,**kw):calls.append(1);return original(*a,**kw)
        f._identity=identity
        f._analysis_queue_dispatch('analysis_queue_resume',{'storeId':'store1','taskId':'task1','confirmed':True},'fixture-token')
        wait(f,21)
        self.assertEqual(len(calls),5)
        for _ in range(10):read(f)
        self.assertEqual(len(calls),5)
        f._analysis_queue.close()
    def test_actual_saved_page_pauses_collection_and_still_drains_via_one_consumer(self):
        f=memory(0);rt=f.platform_runtime;executor=rt.service.executor
        f.core.store.rows[('tasks','task1')]['status']='ready'
        rt._run_lock=threading.RLock()
        for name in ('_bounded_collection','_queue_collection_analysis','_independent_analysis','_pending_collection_analysis',
                     '_collection_analysis_backlog','_task_leads','_collection_lead_snapshot','_new_collection_lead_ids'):
            setattr(rt,name,types.MethodType(getattr(runtime_module.PlatformRuntime,name),rt))
        rt._analysis_confirmed=runtime_module.PlatformRuntime._analysis_confirmed
        rt._current_comment_policy=lambda task:True
        rt._executor=lambda *a,**kw:executor
        rt._collection_read_purpose=lambda platform:'fixture'
        rt._account=lambda user,ident:f.core.store.get('accounts',ident)
        rt._collection_readiness=lambda user,account:('','')
        rt._collection_checkpoint=lambda task:str(task.get('page',0))
        rt._begin_cli_pages=lambda *a:types.SimpleNamespace(end_xhs_cli_pages=lambda ident:None)
        rt._drain_collection_analysis=lambda *a,**kw:self.fail('second legacy consumer ran')
        def start(user,payload):
            rt._analysis_queue_controller=rt._analysis_collection_authorization.callback(user,'task1')
            return {'taskId':'task1'}
        rt.start_acquisition=start
        f._run_collection_with_analysis('start_acquisition',f.user,{},'fixture-token',f.profile)
        control={'event':threading.Event(),'attempt':'fixture','binding':rt._collection_binding(rt._task(f.user,'task1'))}
        def page(executor,user,action,data):
            self.assertEqual(action,'task_run');f.add(21)
            f.core.store.rows[('tasks','task1')].update(status='paused',page=1)
            control['event'].set()
            return {'status':'stopped','summary':{'read':21,'filtered':0,'imported':21,'duplicates':0,'can_continue':False,'exhausted':False}}
        rt._execute=page
        original_reply=f.core.store.get('replies','manual')
        rt._bounded_collection(executor,f.user,'task1',control)
        final=wait(f,21)
        self.assertTrue(control['event'].is_set())
        self.assertEqual(final['counts']['pending'],0)
        self.assertEqual(sum(len(d['ids']) for op,d in f.calls if op=='intent_analyze'),21)
        self.assertEqual(f.core.store.get('replies','manual'),original_reply)
        f._analysis_queue.close();self.assertTrue(f._analysis_queue.wait_for_idle(1))

    def test_model_wait_holds_neither_core_nor_backend_lock_and_close_does_not_join(self):
        f=memory(21);entered=threading.Event();release=threading.Event()
        f.on_model=lambda:(entered.set(),release.wait(2))
        f._analysis_queue_dispatch('analysis_queue_resume',{'storeId':'store1','taskId':'task1','confirmed':True},'fixture-token')
        self.assertTrue(entered.wait(1))
        for lock in (f.core.lock,f.lock):
            self.assertTrue(lock.acquire(blocking=False));lock.release()
        started=time.monotonic();f._analysis_queue.close()
        self.assertLess(time.monotonic()-started,.2)
        release.set();self.assertTrue(f._analysis_queue.wait_for_idle(1))
        self.assertTrue(all(not row.get('ai_intent') for row in f.core.store.list('leads','tenant')))

    def test_new_unknown_stops_collection_authorized_queue_without_retry(self):
        f=memory(41)
        f.on_model=lambda:(_ for _ in ()).throw(Unknown('synthetic unknown'))
        c=f._analysis_controller()
        refresh=f._analysis_queue_refresh('fixture-token','store1','task1',require_analysis=True)
        c.authorize_collection(f.user,'store1','task1',refresh);c.notify_saved('task1')
        self.assertTrue(c.wait_for_idle(2))
        final=read(f)
        self.assertEqual(final['code'],'PRODUCT_REQUEST_UNKNOWN')
        self.assertEqual(final['counts']['held'],20)
        self.assertEqual(final['counts']['pending'],21)
        self.assertEqual(len(f.calls),1)
        self.assertFalse(c.notify_saved('task1'))
        self.assertEqual(len(f.calls),1)
        c.close()

if __name__=='__main__':unittest.main(verbosity=2)
