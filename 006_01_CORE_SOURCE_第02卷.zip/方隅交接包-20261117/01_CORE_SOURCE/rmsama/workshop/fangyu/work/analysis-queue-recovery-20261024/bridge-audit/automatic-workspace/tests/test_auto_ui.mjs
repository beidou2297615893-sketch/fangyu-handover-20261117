import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {createRequire} from 'node:module';
import {pathToFileURL} from 'node:url';
const root=path.resolve(import.meta.dirname,'..');
const project='C:/积木软件工坊/项目/方隅公寓客户版/work/parallel-integration-20261018/final-integration/candidate-unified-v103/project';
const arg=name=>{const i=process.argv.indexOf(name);return i<0?null:process.argv[i+1];};
const app=arg('--app')||project+'/work/ui-approved-implementation/ui-preview/app.mjs';
const ui=path.dirname(app),candidate=root+'/candidate/work/ui-approved-implementation/ui-preview';
const fixture=fs.mkdtempSync(path.join(root,'work-ui-'));fs.mkdirSync(fixture+'/pages');
for(const folder of ['', '/pages'])for(const e of fs.readdirSync(ui+folder,{withFileTypes:true}))if(e.isFile()&&e.name.endsWith('.mjs'))fs.copyFileSync(ui+folder+'/'+e.name,fixture+folder+'/'+e.name);
for(const name of ['pages/saved-comment-analysis.mjs','pages/acquire.mjs','backend.mjs'])fs.copyFileSync(candidate+'/'+name,fixture+'/'+name);
if(arg('--module'))fs.copyFileSync(arg('--module'),fixture+'/pages/saved-comment-analysis.mjs');
const require=createRequire(project+'/work/ui-native-r57/public_article_generic/package.json');
const {JSDOM}=require('jsdom');
const acquire=await import(pathToFileURL(fixture+'/pages/acquire.mjs'));
const dom=new JSDOM('<main id="root"></main>',{url:'http://127.0.0.1:12345'});globalThis.document=dom.window.document;
const state={connection:'connected',page:'acquire',authEpoch:1,user:'tester',store:'门店一',storeId:'store1',
 session:{user:{tenant_id:'tenant',role:'operator'}},stores:[{id:'store1',name:'门店一'}],platform:{actor:{username:'tester',storeId:'store1'},platforms:[],acquisition:{status:'paused'}}};
let calls=[],modals=0,cleanup;
const value={actor:{username:'tester',storeId:'store1'},taskId:'workspace',status:'running',running:true,
 counts:{total:2068,pending:244,processing:0,held:9,analyzed:1794,missingText:21},autoEnabled:true,automaticEnabled:true,autoPaused:false,
 remaining:244,activeTaskId:'task1',canPause:true,canResume:false,phase:'ai_profile',code:'',message:'后台持续处理本店已保存评论',requestId:'director'};
const ctx={state,actions:{},update:fn=>fn(state),navigate:()=>{},modal:()=>{modals++;throw Error('normal automatic analysis must never ask for confirmation');},toast:()=>{},
 analysisQueueAction:async(action,data)=>{calls.push({action,data});if(action==='analysis_workspace_pause')Object.assign(value,{autoPaused:true,status:'paused',running:false,canResume:true,canPause:false});if(action==='analysis_workspace_resume')Object.assign(value,{autoPaused:false,status:'running',running:true,canResume:false,canPause:true});return {analysisQueue:structuredClone(value)};}};
const rootNode=document.getElementById('root');
function mount(){cleanup?.();rootNode.innerHTML=acquire.render(state);cleanup=acquire.bind(rootNode,ctx);}
const tick=()=>new Promise(r=>setTimeout(r,0));
try{
 mount();await tick();
 assert.ok(rootNode.querySelector('[data-saved-analysis-panel]'),'workspace status must exist without a current collection task');
 assert.deepEqual(calls.map(x=>x.action),['analysis_workspace_read']);
 assert.match(rootNode.textContent,/244/);assert.match(rootNode.textContent,/正在处理/);
 rootNode.querySelector('[data-analysis-pause]').click();await tick();
 assert.equal(calls.at(-1).action,'analysis_workspace_pause');assert.deepEqual(calls.at(-1).data,{storeId:'store1'});
 assert.match(rootNode.textContent,/自动分析已暂停/);
 rootNode.querySelector('[data-analysis-resume]').click();await tick();
 assert.equal(calls.at(-1).action,'analysis_workspace_resume');assert.deepEqual(calls.at(-1).data,{storeId:'store1'});
 assert.equal(modals,0);
 state.page='reply';cleanup();assert.equal(calls.filter(x=>x.action==='analysis_workspace_pause').length,1,'leaving acquisition page must not pause backend');
 async function show(counts,extra={}){Object.assign(value,{counts,...extra});state.page='acquire';state.savedCommentAnalysis.lastRead=0;mount();await tick();}
 await show({total:2068,pending:224,processing:20,held:9,analyzed:1794,missingText:21},{remaining:244});
 assert.match(rootNode.textContent,/待分析 244 条（其中分析中 20 条）/);assert.match(rootNode.textContent,/原请求待核 9 条/);assert.doesNotMatch(rootNode.textContent,/待核 29/);
 await show({total:2068,pending:244,processing:0,held:9,analyzed:1794,missingText:21},{remaining:244});
 assert.match(rootNode.textContent,/待分析 244 条/);assert.match(rootNode.textContent,/已分析 1794 条/);
 await show({total:2068,pending:224,processing:10,held:9,analyzed:1804,missingText:21},{remaining:234});
 assert.match(rootNode.textContent,/待分析 234 条（其中分析中 10 条）/);assert.match(rootNode.textContent,/原请求待核 9 条/);
 state.platform.acquisition.message='待分析已达200条上限';state.savedCommentAnalysis.lastRead=Date.now();mount();
 assert.match(rootNode.textContent,/仅暂停采集，后台分析继续/);
 await show({total:2068,pending:224,processing:0,held:29,analyzed:1794,missingText:21},{remaining:224,status:'blocked',running:false,canResume:true,canPause:false,code:'AI_PROVIDER_TIMEOUT',phase:'intent_analyze',message:'generic'});
 assert.match(rootNode.textContent,/自动分析异常暂停/);assert.match(rootNode.textContent,/原请求待核 29 条/);assert.match(rootNode.textContent,/原分析请求超时/);assert.doesNotMatch(rootNode.textContent,/可分析队列已清空/);
 await show({total:2068,pending:244,processing:0,held:9,analyzed:1794,missingText:21},{remaining:244,status:'blocked',running:false,canResume:true,code:'AI_DAILY_BUDGET',phase:'ai_profile',message:'generic'});
 assert.match(rootNode.textContent,/今日AI预算已用完/);assert.match(rootNode.textContent,/当前阶段：读取企业分析配置/);
 await show({total:2068,pending:0,processing:0,held:9,analyzed:2038,missingText:21},{remaining:0,status:'waiting',running:false,canResume:false,canPause:true,code:'',phase:'',message:'原请求待核与缺正文记录继续保留'});
 assert.match(rootNode.textContent,/可分析队列已清空/);assert.match(rootNode.textContent,/原请求待核 9 条/);assert.match(rootNode.textContent,/缺正文 21 条/);
 console.log(JSON.stringify({passed:true,cases:11,actions:calls.map(x=>x.action),modalCount:modals}));
}finally{cleanup?.();dom.window.close();}
