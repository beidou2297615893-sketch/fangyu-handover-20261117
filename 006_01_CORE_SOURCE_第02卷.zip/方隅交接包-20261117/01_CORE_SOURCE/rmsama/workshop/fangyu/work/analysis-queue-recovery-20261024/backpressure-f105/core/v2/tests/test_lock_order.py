"""Two controlled threads, actual F104 execute/snapshot and Runtime queue.

The fixture lock times out only to make the old deadlock fail and clean up;
the product receives no nonblocking/timeout fallback implementation.
"""
from pathlib import Path
import hashlib,io,json,socket,subprocess,threading,unittest
from types import SimpleNamespace
import test_backpressure as bp
base=bp.base;runtime=bp.runtime;OUT=bp.OUT

class FixtureLockTimeout(RuntimeError):pass
class BoundedFixtureRLock:
    def __init__(self,label):self.raw=threading.RLock();self.label=label
    def acquire(self,blocking=True,timeout=-1):
        result=self.raw.acquire(blocking, .6 if blocking and timeout<0 else timeout) if blocking else self.raw.acquire(False)
        if not result:raise FixtureLockTimeout(self.label+' timed out: reproducible lock-order cycle')
        return result
    def release(self):self.raw.release()
    def __enter__(self):self.acquire();return self
    def __exit__(self,*args):self.release()
    def __getattr__(self,key):return getattr(self.raw,key)

class LockOrder(bp.Backpressure):
    def test_actual_legacy_duplicate_resume_and_page_queue_finish_without_cycle(self):
        _,_,_,scope=self.manager._scope(self.user,'fixture-store',self.task['id'],self.refresh)
        self.manager.lock=BoundedFixtureRLock('controller');self.core.lock=BoundedFixtureRLock('core')
        self.manager.active={'user':dict(self.user),'storeId':'fixture-store','taskId':self.task['id'],
            'scope':scope,'refresh':self.refresh,'thread':SimpleNamespace(is_alive=lambda:True),
            'stop':threading.Event(),'wake':threading.Event(),'working':False,'status':'running','code':'',
            'phase':'scope_check','requestId':'fixture-existing'}
        self.rt._analysis_queue_controller=self.manager
        controller_held=threading.Event();queue_in_core=threading.Event();errors=[];completed=[]
        snapshot=self.manager._snapshot
        def coordinated_snapshot(*args):
            self.assertTrue(self.manager.lock._is_owned());controller_held.set()
            self.assertTrue(queue_in_core.wait(2))
            return snapshot(*args)
        self.manager._snapshot=coordinated_snapshot
        helper=self.rt._automatic_collection_analysis
        def observed_helper(*args):
            self.assertTrue(self.core.lock._is_owned());queue_in_core.set();return helper(*args)
        self.rt._automatic_collection_analysis=observed_helper
        def resume():
            try:
                self.manager.execute('analysis_queue_resume',self.user,'fixture-store',
                    {'storeId':'fixture-store','taskId':self.task['id'],'confirmed':True},self.refresh)
                completed.append('resume')
            except BaseException as error:errors.append(type(error).__name__+': '+str(error))
        def queue():
            try:
                self.assertTrue(controller_held.wait(2))
                self.rt._queue_collection_analysis(self.user,self.task['id'],['new-saved-lead'])
                completed.append('queue')
            except BaseException as error:errors.append(type(error).__name__+': '+str(error))
        threads=[threading.Thread(target=resume,daemon=True),threading.Thread(target=queue,daemon=True)]
        for thread in threads:thread.start()
        for thread in threads:thread.join(3)
        # Avoid the original generic fixture teardown joining our alive seam.
        self.manager.active=None
        self.assertFalse(any(thread.is_alive() for thread in threads))
        self.assertEqual(errors,[],'old Core->controller and controller->Core cycle must be eliminated')
        self.assertCountEqual(completed,['resume','queue'])
        row=self.core.store.get(runtime._COLLECTION_ANALYSIS_ENTITY,self.task['id'])
        self.assertEqual(row['lead_ids'],['new-saved-lead'])

    def test_busy_controller_lock_does_not_demote_automatic_mode_to_legacy(self):
        self.automatic();self.manager.lock=BoundedFixtureRLock('controller')
        held=threading.Event();release=threading.Event();errors=[]
        def hold():
            with self.manager.lock:held.set();release.wait(2)
        thread=threading.Thread(target=hold,daemon=True);thread.start();self.assertTrue(held.wait(2))
        try:
            with self.core.lock:
                try:observed=self.rt._automatic_collection_analysis(self.user,self.task)
                except BaseException as error:errors.append(type(error).__name__+': '+str(error));observed=None
            self.assertEqual(errors,[],'capability must not wait on controller mutex while holding Core')
            self.assertIs(observed,self.manager,'mutex contention cannot silently restore the 200 cap')
        finally:release.set();thread.join(2)

if __name__=='__main__':
    cases=[name for name in LockOrder.__dict__ if name.startswith('test_')]
    log=io.StringIO();pin=hashlib.sha256(bp.RUNTIME.read_bytes()).hexdigest()
    with base.patch.object(socket.socket,'connect',base.deny),base.patch('subprocess.Popen',side_effect=base.deny):
        result=unittest.TextTestRunner(stream=log,verbosity=2).run(unittest.TestSuite(LockOrder(name) for name in cases))
    passed=result.wasSuccessful() and pin==hashlib.sha256(bp.RUNTIME.read_bytes()).hexdigest()
    tag='LOCK-GREEN' if passed else 'LOCK-RED';(OUT/(tag+'.log')).write_text(log.getvalue(),'utf-8')
    report={'passed':passed,'tests':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),
        'runtimeSha256':pin,'realCloudModelCliOrSendingCalls':0,'productionReads':0,'productionWrites':0,
        'fixture':'actual F104 legacy execute/resume->_snapshot->_inventory concurrent with actual Runtime._queue_collection_analysis, bounded test locks only'}
    (OUT/(tag+'.json')).write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n','utf-8')
    print(log.getvalue());print(json.dumps(report,ensure_ascii=False));raise SystemExit(0 if passed else 1)
