"""Pinned additive analysis fix; no formal database or running-window mutation."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import shutil
import sys

sys.dont_write_bytecode = True
sys.stdout.reconfigure(encoding='utf-8')
W = Path(__file__).resolve().parent
P = W.parents[1]
F = P/'work/parallel-integration-20261018/final-integration'
OLD = F/'candidate-unified-v100'
PUBLIC = P/'work/complete-product-resume-20261024/live-acquisition-acceptance-20261024/project'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
read = lambda p: json.loads(p.read_text('utf-8-sig'))

def main():
    assert len(sys.argv) == 4 and sys.argv[1:3] == ['--compose','--core-pins']
    core_pins = Path(sys.argv[3]).resolve()
    assert core_pins.is_relative_to(W/'core-audit')
    assert not (F/'candidate-unified-v101').exists()
    bridge = read(W/'bridge-audit/evidence/VALIDATION.json')
    core = read(core_pins)
    assert bridge['passed'] is True and core['sealed'] is True and core['version'] == 2
    assert sha(core_pins) == 'cad461f0cdee60d03df57de5367347a618472ffaaba486695698f5a6ddf1e47b'
    core_rows = [{'relativePath':'work/shared-backend-integration/'+Path(r['candidatePath']).name,
        'candidate':r['candidatePath'],'sha256':r['candidateSha256'],
        'baselinePath':r['baselinePath'],'baselineSha256':r['baselineSha256']} for r in core['files']]
    rows = list(bridge['files']) + core_rows
    expected = {
        'work/ui-approved-implementation/ui-preview/app.mjs',
        'work/ui-approved-implementation/ui-preview/backend.mjs',
        'work/ui-approved-implementation/ui-preview/pages/acquire.mjs',
        'work/ui-approved-implementation/ui-preview/pages/saved-comment-analysis.mjs',
        'work/ui-native-r57/freeze_ui.py',
        'work/ui-native-r57/ui_native_host.py',
        'work/ui-native-r57/workbench_backend.py',
        'work/shared-backend-integration/platform_runtime.py',
        'work/shared-backend-integration/analysis_queue_runtime.py',
    }
    assert len(rows) == 9 and {r['relativePath'].replace('\\','/') for r in rows} == expected
    baseline = read(OLD/'INPUT-SNAPSHOT.json')
    assert Path(baseline['source']) == PUBLIC
    spec = importlib.util.spec_from_file_location('existing_f101_freezer',F/'freeze_unified.py')
    builder = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(builder)
    builder.SOURCE = PUBLIC
    actual = {p.relative_to(PUBLIC).as_posix():sha(p) for p in builder.input_files()}
    changed = sorted(k for k in actual.keys() | baseline['files'].keys()
        if actual.get(k) != baseline['files'].get(k))
    assert not changed, ('Unreviewed public source change',changed)
    for row in rows:
        rel = row['relativePath'].replace('\\','/')
        source, target = Path(row['candidate']), PUBLIC/rel
        assert sha(source) == row['sha256'], rel
        if row['baselineSha256'] is None:
            assert not target.exists() and not (OLD/'project'/rel).exists(), rel
        else:
            assert sha(target) == sha(OLD/'project'/rel) == row['baselineSha256'], rel
    pack = W/'package'
    pack.mkdir(exist_ok=True)
    backup = pack/'public-before'
    assert not backup.exists()
    backup.mkdir()
    for row in rows:
        rel = row['relativePath'].replace('\\','/')
        target = PUBLIC/rel
        if target.exists():
            old = backup/rel
            old.parent.mkdir(parents=True,exist_ok=True)
            shutil.copy2(target,old)
        target.parent.mkdir(parents=True,exist_ok=True)
        shutil.copy2(Path(row['candidate']),target)
    composition = {'atUtc':datetime.now(timezone.utc).isoformat(),
        'source':str(PUBLIC),'baselineInputFiles':len(actual),'baselineInputsMatchF100':True,
        'changes':rows,'productionWrites':0,'cloudOrModelCalls':0,
        'frozenOrRunningRuntimeMutated':False,
        'bridgeValidationSha256':sha(W/'bridge-audit/evidence/VALIDATION.json'),
        'coreSealedPins':str(core_pins),'coreSealedPinsSha256':sha(core_pins)}
    (pack/'ROOT-COMPOSITION-V101.json').write_text(json.dumps(composition,ensure_ascii=False,indent=2)+'\n','utf-8')
    sys.argv = [str(F/'freeze_unified.py'),'--candidate','candidate-unified-v101']
    builder.main()
    out = F/'candidate-unified-v101'
    stage = read(out/'STAGED.json')
    native = Path(stage['release'])
    old_native = Path(read(OLD/'STAGED.json')['release'])
    old_files = {p.relative_to(old_native).as_posix():sha(p) for p in old_native.rglob('*') if p.is_file()}
    new_files = {p.relative_to(native).as_posix():sha(p) for p in native.rglob('*') if p.is_file()}
    delta = sorted(k for k in old_files.keys() | new_files.keys() if old_files.get(k) != new_files.get(k))
    allowed = {'RELEASE.json','web/app.mjs','web/backend.mjs','web/pages/acquire.mjs',
        'web/pages/saved-comment-analysis.mjs','ui_native_host.py',
        'workbench_backend.py','resources/platform-runtime/platform_runtime.py',
        'resources/platform-runtime/analysis_queue_runtime.py'}
    assert set(delta) == allowed, delta
    assert sha(native/'web/pages/reply-connected.mjs') == '92bda4b28c8fe91ae3ae789c137e14a940a16ce68e1ffc2dbeb521267b1476f5'
    final = {'status':'FROZEN_PENDING_VERIFICATION','releaseId':stage['release_id'],
        'release':str(native),'project':str(out/'project'),
        'unifiedPinsSha256':sha(out/'UNIFIED-PINS.json'),'stagedSha256':sha(out/'STAGED.json'),
        'manifestSha256':sha(native/'RELEASE.json'),'changedProductSourceFiles':9,
        'changedReleaseFiles':delta,'productionWrites':0,'cloudOrModelCalls':0,
        'installed':False,'actualNewNativeVerified':False}
    (pack/'ROOT-FINAL-PINS-V101.json').write_text(json.dumps(final,ensure_ascii=False,indent=2)+'\n','utf-8')
    print(json.dumps(final,ensure_ascii=False),flush=True)

if __name__ == '__main__': main()
