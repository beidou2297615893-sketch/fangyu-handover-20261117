import {workflowScope} from './workflow-summary.mjs';
const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const levels={high:'高意向',medium:'中意向',low:'低意向'};
const configFields=['enabled','provider','model','reasoning_effort','intent_policy','daily_budget_cny','usd_cny_rate'];
const softwareLabels={not_configured:'未配置可信更新',entry_unconfigured:'当前入口尚未接入可信更新',unknown:'更新状态待核对',up_to_date:'本机已是当前可信版本',ready:'可以检查更新',available:'发现可用更新',busy:'任务运行中，稍后继续',staged:'已下载并校验，尚未安装',pending_restart:'已安排下次启动安装',awaiting_confirmation:'新版本等待启动确认',installed:'本机版本已确认',rolled_back:'已恢复上一版本',update_rejected:'更新未通过校验',check_failed:'检查未完成',updates_disabled:'本机更新已关闭',awaiting_close:'等待正常关闭'};
export function softwareStateHTML(update={}){
  const status=update.status||'unknown';
  return `<p><strong>${esc(softwareLabels[status]||'更新状态待核对')}</strong></p><dl class="rm-facts"><dt>本机安装版本</dt><dd>${esc(update.installed_version||update.installed_release||'未知')}</dd><dt>候选版本</dt><dd>${esc(update.candidate_release||'未提供')}</dd><dt>更新源</dt><dd>${update.feed_configured===true?'已配置；不代表已安装':update.feed_configured===false?'未配置':'尚未核对'}</dd><dt>当前入口支持</dt><dd>${update.entry_supported===true?'支持可信更新':update.entry_supported===false?'当前入口尚未接入':'尚未核对'}</dd></dl>${update.message?`<p>${esc(update.message)}</p>`:''}${update.requires_restart?'<p class="wf-note">更新已排队。完成当前工作后正常关闭，再从原入口重开；本页不会自动重启。</p>':''}<p class="rm-note">本页只核对本机状态，其他设备和全门店安装结果尚未验证。</p>`;
}
function configHTML(h){
  const c=h.configDraft||h.remote?.aiConfig||{},disabled=h.busy||h.saveUnknown||h.publicationUnknown?'disabled':'';
  return `<p class="wf-note">修改当前公司的服务器模型配置。保存不会调用模型，也不会验证真实费用或请求成功。</p><p>服务器版本 ${esc(h.remote?.aiConfig?.revision??'未知')} · 模型规则 ${esc(h.remote?.aiConfig?.rules_version||'未知')}</p><form data-rm-config><label class="rm-checkbox"><input name="enabled" type="checkbox" ${c.enabled?'checked':''} ${disabled}>启用企业 AI</label><div class="rm-config-grid"><label>模型提供商<select name="provider" ${disabled}>${c.provider&&!['openai','deepseek'].includes(c.provider)?`<option value="${esc(c.provider)}" selected>当前提供商：${esc(c.provider)}</option>`:''}${['openai','deepseek'].map(v=>`<option value="${v}" ${c.provider===v?'selected':''}>${v==='deepseek'?'DeepSeek':'OpenAI 兼容配置'}</option>`).join('')}</select></label><label>模型名称<input name="model" maxlength="120" value="${esc(c.model||'')}" placeholder="填写已配置的模型名称" required ${disabled}></label><label>推理强度<select name="reasoning_effort" ${disabled}>${c.reasoning_effort&&!['none','minimal','low','medium','high','xhigh'].includes(c.reasoning_effort)?`<option value="${esc(c.reasoning_effort)}" selected>当前：${esc(c.reasoning_effort)}</option>`:''}${['none','minimal','low','medium','high','xhigh'].map(v=>`<option value="${v}" ${c.reasoning_effort===v?'selected':''}>${v}</option>`).join('')}</select></label><label>每日预算（元）<input name="daily_budget_cny" type="number" min="0" step="0.01" value="${esc(c.daily_budget_cny??'')}" ${disabled}></label></div><h3>服务器模型三档分级标准</h3>${Object.entries(levels).map(([key,label])=>`<label class="wf-rule-field">${label}<textarea name="intent_${key}" minlength="8" maxlength="2000" required ${disabled}>${esc(c.intent_policy?.[key]||'')}</textarea></label>`).join('')}</form><div class="rm-actions"><button type="button" data-rm-save ${disabled||!h.remote||h.draftConflict?'disabled':''}>保存服务器配置</button>${h.saveUnknown?'<button type="button" data-rm-save-check>核对原配置保存</button>':''}${h.draftConflict?'<button type="button" data-rm-load-server>载入服务器版本，放弃本页草稿</button>':''}</div>${h.draftConflict?'<p role="alert">服务器版本已变化。本页草稿已保留；请先复制需要保留的文字，再载入服务器版本重新编辑。</p>':''}`;
}
function publishHTML(h,state){
  const local=state.aiWorkbench?.scope===workflowScope(state)?state.aiWorkbench.rules?.localPolicy:null;
  const summary=local?.summary,published=h.remote?.providerPolicy;
  const ready=Boolean(h.publishedSource!==`${summary?.revision}|${summary?.digest}`&&!h.saveUnknown&&local?.policy&&Number.isSafeInteger(summary?.revision)&&/^[a-f0-9]{64}$/i.test(summary?.digest||'')&&published?.can_publish===true&&Number.isSafeInteger(published?.summary?.policy_revision)&&!h.publicationUnknown);
  return `<p class="wf-note">将当前已保存的本机五级标准发布为当前公司的规则，作用范围是公司。服务器模型三档标准在“服务器配置”中单独保存。</p><dl class="rm-facts"><dt>本机标准版本</dt><dd>${esc(summary?.revision??'尚未读取')}</dd><dt>公司发布版本</dt><dd>${esc(published?.summary?.policy_revision??'未知')}</dd><dt>本机来源摘要</dt><dd>${esc(summary?.digest||'尚未读取')}</dd></dl>${h.publishedSource===`${summary?.revision}|${summary?.digest}`?'<p>当前本机标准已取得公司提交回执；修改并保存新版本后可再次发布。</p>':!ready?'<p>发布需读取当前本机标准、版本摘要和公司发布权限；未满足时不能提交。</p>':''}<div class="rm-actions"><button type="button" data-rm-publish ${!ready||h.busy?'disabled':''}>发布当前标准为公司规则</button><button type="button" data-rm-publish-status ${!h.publicationKey||h.busy?'disabled':''}>核对原发布状态</button><button type="button" data-rm-local-refresh ${h.busy?'disabled':''}>重新读取本机标准</button></div>${h.publication?`<p>原发布编号：${esc(h.publicationKey)}</p><p>发布状态：${esc(h.publication.state||'未知')} · ${h.publication.mutation_committed===true?'已取得服务器提交回执':'尚未确认提交'}</p>`:''}<p class="rm-note">服务器回执不代表所有客户端已同步；历史评级不会据此自动改写。</p>`;
}
export function remotePanelHTML(h,state){
  const update=h.remote?.softwareUpdate||{};
  const canUpdate=update.entry_supported===true&&update.feed_configured===true;
  return `<div class="rm-panel"><p class="rm-scope">当前门店：${esc(state.store||state.storeId)} · 模型配置及公司规则作用于当前公司</p><div class="rm-tabs" role="tablist">${[['config','服务器配置'],['policy','公司规则发布'],['store','门店规则文件'],['software','本机软件更新']].map(([key,label])=>`<button type="button" data-rm-tab="${key}" role="tab" aria-selected="${h.tab===key}" ${h.busy?'disabled':''}>${label}</button>`).join('')}</div><p data-rm-message role="status" class="rm-message">${esc(h.message||'仅读取已授权配置，不请求模型。')}</p>${h.saveRequestId?`<p class="rm-receipt">配置保存编号：${esc(h.saveRequestId)}</p>`:''}${h.publicationKey?`<p class="rm-receipt">公司发布编号：${esc(h.publicationKey)}</p>`:''}${h.tab==='config'?configHTML(h):h.tab==='policy'?publishHTML(h,state):h.tab==='store'?`<p>门店资料、关键词和本机判断规则使用现有中央规则文件流程：读取完整文件 → 导出并编辑 JSON → 上传生成预览 → 核对版本后应用。</p><p>版本：${esc(h.remote?.ruleBundle?.revision||'未知')} · 摘要：${esc(h.remote?.ruleBundle?.digest||'未知')}</p><p>恢复旧内容也须通过当前版本校验后提交为新版本，保留原回执。</p><button type="button" data-rm-store>打开中央规则文件</button>`:`${softwareStateHTML(update)}<div class="rm-actions"><button type="button" data-rm-update="status" ${h.busy?'disabled':''}>刷新本机状态</button><button type="button" data-rm-update="check" ${h.busy||!canUpdate?'disabled':''}>检查可信更新</button><button type="button" data-rm-update="download" ${h.busy||!canUpdate||update.status!=='available'?'disabled':''}>下载并校验</button><button type="button" data-rm-update="prepare" ${h.busy||!canUpdate||update.status!=='staged'?'disabled':''}>安排下次启动安装</button></div>`}<div class="rm-actions"><button type="button" data-rm-read ${h.busy?'disabled':''}>重新读取服务器配置</button></div></div>`;
}
export function openRemoteManagement(ctx){
  const state=ctx.state,scope=workflowScope(state);
  const admin=()=>state.connection==='connected'&&state.session?.user?.role==='admin'&&state.session.user.username===state.user&&workflowScope(state)===scope;
  if(!admin()){ctx.toast('服务器配置仅限当前企业管理员。');return;}
  const previous=state.remoteManagementTool;
  const h=previous?.scope===scope?previous:{scope,tab:'config',remote:null,busy:false,message:'正在读取服务器配置…',configDraft:null,saveUnknown:false,publicationUnknown:false};state.remoteManagementTool=h;
  const pending=ctx.remotePending?.();if(pending?.kind==='config'){h.saveRequestId=pending.id;h.saveRevision=pending.revision;h.saveUnknown=true;}else if(pending?.kind==='policy'){h.publicationKey=pending.id;h.publicationUnknown=true;}
  const own=()=>admin()&&state.remoteManagementTool===h&&h.dialog?.open!==false&&h.dialog?.__modalOwner===h.owner;
  const check=()=>{if(!own())throw new Error('管理员、门店或弹窗已变化，请重新读取。');};
  const invoke=(action,data={})=>{check();return ctx.remoteAction(action,{storeId:state.storeId,...data});};
  const read=async()=>{const result=await invoke('remote_config_read');check();const remote=result.remote;if(remote?.actor?.username!==state.user||remote?.actor?.storeId!==state.storeId)throw new Error('配置归属已变化，请重新读取');h.remote=remote;if(h.configDraft&&h.configDraftRevision!==remote.aiConfig?.revision)h.draftConflict=true;if(h.saveUnknown&&remote.aiConfig?.last_save_id===h.saveRequestId&&remote.aiConfig?.revision===h.saveRevision+1){h.saveUnknown=false;h.configDraft=null;h.configDraftRevision=null;h.draftConflict=false;}h.message='已读取当前权限内服务器配置；未请求模型，其他设备状态未验证。';};
  const capture=()=>{const form=h.dialog?.querySelector('[data-rm-config]');if(form&&h.remote&&!h.busy){h.configDraft=readConfigForm(form,h.remote.aiConfig);h.configDraftRevision??=h.remote.aiConfig?.revision;}};
  const run=async fn=>{if(!own()||h.busy)return;try{capture();}catch(error){h.message=error.message;show();return;}h.busy=true;show();try{await fn();}catch(error){if(own()){h.message=error.message;if(['AUTH_REQUIRED','unauthenticated','session_expired'].includes(error.code))ctx.replyError?.(error);}}finally{h.busy=false;if(own())show();}};
  const policyReceipt=publication=>{if(publication?.idempotency_key!==h.publicationKey)throw new Error('发布回执编号不符；原发布结果仍待核对');h.publication=publication;if(publication.state==='succeeded'&&publication.mutation_committed===true){if(Number.isSafeInteger(publication.summary?.policy_revision)&&h.remote?.providerPolicy)h.remote.providerPolicy.summary=publication.summary;h.publishedSource=h.publicationSource;}h.publicationUnknown=!(publication?.state==='succeeded'&&publication.mutation_committed===true||['rejected','not_applied','cancelled'].includes(publication?.state)&&publication.mutation_committed===false);h.message=h.publicationUnknown?'公司规则发布结果未知，请使用原编号核对；不会自动重发。':publication.mutation_committed===true?'已取得公司规则服务器提交回执；其他设备同步尚未核对。':'原发布已确认未提交，请重新读取公司版本后再决定。';};
  function show(){
    if(!admin()||state.remoteManagementTool!==h)return;
    const dialog=ctx.modal({title:'服务器配置与可信更新',html:remotePanelHTML(h,state)});h.dialog=dialog;h.owner=dialog.__modalOwner;
    const el=name=>dialog.querySelector('[data-rm-'+name+']');
    el('read')?.addEventListener('click',()=>run(read));
    dialog.querySelectorAll('[data-rm-tab]').forEach(button=>button.addEventListener('click',()=>{if(!own()||h.busy)return;try{capture();h.tab=button.dataset.rmTab;show();}catch(error){h.message=error.message;show();}}));
    el('store')?.addEventListener('click',()=>{if(own())ctx.openCentralRuleFiles?.();});
    el('local-refresh')?.addEventListener('click',()=>run(async()=>{await ctx.refreshAIRules(true);check();h.message='已重新读取本机标准；尚未发布。';}));
    el('load-server')?.addEventListener('click',()=>{if(!own()||h.busy||h.saveUnknown)return;h.configDraft=null;h.configDraftRevision=null;h.draftConflict=false;h.message='已载入当前服务器版本，请重新编辑；尚未保存。';show();});
    el('save')?.addEventListener('click',()=>{
      if(!own()||h.busy||h.saveUnknown||h.publicationUnknown||h.draftConflict)return;
      const form=el('config');if(!form?.reportValidity())return;
      // Capture before run() rebuilds the modal and disables the form.
      const config=readConfigForm(form,h.remote?.aiConfig),revision=h.configDraftRevision??h.remote?.aiConfig?.revision;
      if(!Number.isSafeInteger(revision)){h.message='服务器配置版本未知，请先重新读取';show();return;}
      h.configDraft=config;
      run(async()=>{
        h.saveRequestId=crypto.randomUUID();h.saveRevision=revision;h.saveUnknown=true;
        try{const result=await invoke('remote_ai_config_save',{config,expected_revision:revision,request_id:h.saveRequestId});check();
          const confirmed=result.request_id===h.saveRequestId&&result.state==='succeeded'&&result.mutation_committed===true&&result.configuration?.last_save_id===h.saveRequestId&&result.configuration?.revision===revision+1;
          h.saveUnknown=!confirmed;h.message=confirmed?'服务器配置已保存；未请求模型。':'服务器配置保存结果未知，请核对原操作；不会自动重发。';
          if(confirmed){h.configDraft=null;h.configDraftRevision=null;h.draftConflict=false;await read();}
        }catch(error){if(!own())return;h.saveUnknown=error.mutationCommitted!==false;if(!h.saveUnknown)throw error;throw new Error(error.message+'；保留原保存编号，请核对结果。');}
      });
    });
    el('save-check')?.addEventListener('click',()=>run(async()=>{await read();check();if(h.remote.aiConfig?.last_save_id===h.saveRequestId&&h.remote.aiConfig?.revision===h.saveRevision+1){h.saveUnknown=false;h.configDraft=null;h.configDraftRevision=null;h.draftConflict=false;h.message='已按原保存编号核对服务器配置。'}else h.message='尚未找到原保存编号，结果仍未知；不会重复提交。';}));
    el('publish')?.addEventListener('click',()=>run(async()=>{
      const local=state.aiWorkbench?.rules?.localPolicy,summary=local?.summary;if(h.saveUnknown||h.publicationUnknown||h.remote?.providerPolicy?.can_publish!==true||!Number.isSafeInteger(h.remote?.providerPolicy?.summary?.policy_revision))throw new Error('发布权限、公司版本或原操作状态待核对');if(state.aiWorkbench?.scope!==scope||!local?.policy||!summary?.digest||!Number.isSafeInteger(summary.revision))throw new Error('本机标准版本已变化，请先重新读取');
      h.publicationKey=crypto.randomUUID();h.publicationSource=`${summary.revision}|${summary.digest}`;h.publicationUnknown=true;
      try{const result=await invoke('remote_policy_publish',{expected_policy_revision:h.remote.providerPolicy.summary.policy_revision,idempotency_key:h.publicationKey,source_local_revision:summary.revision,source_local_digest:summary.digest});check();policyReceipt(result.publication);}
      catch(error){if(!own())return;h.publicationUnknown=error.mutationCommitted!==false;if(!h.publicationUnknown)throw error;throw new Error(error.message+'；保留原发布编号，请核对原发布状态。');}
    }));
    el('publish-status')?.addEventListener('click',()=>run(async()=>{if(!h.publicationKey)throw new Error('没有待核的原发布编号');const result=await invoke('remote_policy_status',{idempotency_key:h.publicationKey});check();policyReceipt(result.publication);}));
    dialog.querySelectorAll('[data-rm-update]').forEach(button=>button.addEventListener('click',()=>run(async()=>{const kind=button.dataset.rmUpdate;if(!['status','check','download','prepare'].includes(kind))return;const u=h.remote?.softwareUpdate||{};if(kind!=='status'&&(u.entry_supported!==true||u.feed_configured!==true)||kind==='download'&&u.status!=='available'||kind==='prepare'&&u.status!=='staged')throw new Error('当前可信更新状态不支持此操作，请先刷新状态');const result=await invoke('software_update_'+kind);check();if(!result.softwareUpdate||typeof result.softwareUpdate.status!=='string')throw new Error('可信更新状态回执无效');h.remote??={};h.remote.softwareUpdate=result.softwareUpdate;h.message=result.softwareUpdate.message||'已核对本机更新状态。';})));
  }
  show();run(read);
}
export function readConfigForm(form,original={}){
  const result=Object.fromEntries(configFields.filter(key=>Object.hasOwn(original||{},key)).map(key=>[key,structuredClone(original[key])]));
  const field=name=>form.elements.namedItem(name);
  result.enabled=field('enabled').checked;result.provider=field('provider').value;result.model=field('model').value.trim();result.reasoning_effort=field('reasoning_effort').value;
  result.intent_policy=Object.fromEntries(Object.keys(levels).map(key=>[key,field('intent_'+key).value.trim()]));
  const budget=field('daily_budget_cny').value;if(budget!==''){const amount=Number(budget);if(!Number.isFinite(amount)||amount<0)throw new Error('每日预算需为非负金额');result.daily_budget_cny=amount;}
  return result;
}
