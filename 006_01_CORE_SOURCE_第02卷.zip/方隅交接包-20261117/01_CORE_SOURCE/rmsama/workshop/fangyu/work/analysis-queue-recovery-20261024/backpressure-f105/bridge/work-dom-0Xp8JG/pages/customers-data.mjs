// Public customer envelopes are accepted only for the currently authenticated actor.
export const escape=value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
export const count=value=>Number.isSafeInteger(value)&&value>=0?value:'—';
export function customerScopeKey(state){return JSON.stringify([state.authEpoch||0,state.session?.user?.tenant_id||'',state.user,state.session?.user?.role||'',state.storeId||'',state.activePlatform||'xiaohongshu']);}
export function customerShortNeed(person){
  const clean=value=>typeof value==='string'?value.replace(/\s+/g,' ').trim():'';
  const placeholders=new Set(['需求待补充','需求信息尚未整理','需求待了解']);
  const summary=[person?.shortNeed,person?.need].map(clean).find(value=>value&&!placeholders.has(value));
  const text=summary||clean(person?.quote)||'原评论未提供';
  return [...text].slice(0,60).join('')+([...text].length>60?'…':'');
}
export function actorMatches(state,envelope){return Boolean(state.user&&state.storeId&&envelope?.actor?.username===state.user&&envelope?.actor?.storeId===state.storeId&&(!envelope.readScope||envelope.readScope===customerScopeKey(state)));}
export function customerControls(state){
  const key=customerScopeKey(state);
  if(state.customers?.actorKey!==key)state.customers={actorKey:key,query:'',filter:'all',review:'all',sort:'intent',sortDirection:'desc',selectedId:'',checkedIds:[],filterOpen:false,evidenceOpen:false,page:1,pageSize:20,acquiredDate:'',leaseGroup:'all'};
  return state.customers;
}
export function customerQuery(state){const s=customerControls(state);return {platform:state.activePlatform||'xiaohongshu',query:s.query,filter:s.filter,review:'all',sort:s.sort,sortDirection:s.sortDirection,page:s.page,pageSize:s.pageSize,acquiredDate:s.acquiredDate||'',...(state.storeId==='fy_s_d343f3a378f48e1bab55df4f'?{leaseGroup:s.leaseGroup||'all'}:{})};}
export function customerModel(state){
  const controls=customerControls(state),raw=state.customerView;
  if(!state.storeId)return {controls,status:"error",error:"请先在获客页选择门店，再查看本店客户。",items:[],stats:{},total:null,page:1,pages:1};
  if(!actorMatches(state,raw))return {controls,status:'loading',items:[],stats:{},total:null,page:1,pages:1};
  return {...raw,controls,items:Array.isArray(raw.items)?raw.items.filter(item=>item&&typeof item.id==='string'&&item.id):[],stats:raw.stats||{},status:raw.status||'ready'};
}
