// Collection and saved-comment analysis have separate controls and lifetimes.
const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const num=v=>Number.isSafeInteger(v)&&v>=0;
function scope(s){
  const a=s.platform?.acquisition,t=a?.taskScope,platform=s.activePlatform||'xiaohongshu';
  if(s.connection!=='connected'||s.page!=='acquire'||!s.session||!s.user||!s.storeId||!a?.taskId||t?.storeId!==s.storeId||t.platform!==platform)return null;
  return {key:JSON.stringify([s.authEpoch||0,s.session.user?.tenant_id,s.user,s.session.user?.role,s.storeId,platform,a.taskId,t.accountId]),storeId:s.storeId,taskId:a.taskId};
}
function model(s){
  const target=scope(s);if(!target)return null;
  if(s.savedCommentAnalysis?.key!==target.key)s.savedCommentAnalysis={...target,value:null,busy:false,error:'',uncertain:false,lastRead:0};
  return s.savedCommentAnalysis;
}
function content(u){
  const v=u.value,c=v?.counts,disabled=u.busy?'disabled':'';
  const status=v?.running?'正在分析已保存评论':v?.status==='completed'?'当前任务评论已分析':v?.status==='held'?'原分析请求待核对':'已保存评论分析';
  const counts=c?`<span>待分析 ${c.pending} 条</span><span>原请求待核 ${c.held} 条</span>${c.missingText?`<span>缺正文 ${c.missingText} 条</span>`:''}<span>已分析 ${c.analyzed} 条</span>`:'<span>正在读取当前任务的已保存评论</span>';
  return `<div><strong>${esc(status)}</strong>${counts}<small role="status" aria-live="polite">${esc(u.error||v?.message||'仅读取分析状态，尚未提交分析。')}</small></div><div>${v?.canPause?`<button type="button" data-analysis-pause ${disabled}>暂停评论分析</button>`:`<button type="button" data-analysis-resume ${disabled||!u.needsAuthority&&(!v?.canResume||!c?.pending||u.uncertain)?'disabled':''}>${u.needsAuthority?'核对授权并继续分析':'继续分析已采评论'}</button>`}<button type="button" data-analysis-read ${disabled}>${u.busy?'正在核对…':'刷新分析状态'}</button></div>`;
}
export function renderSavedCommentAnalysis(s){const u=model(s);return u?`<div class="as-source-bar" data-saved-analysis-panel aria-label="已保存评论分析">${content(u)}</div>`:'';}
export function savedCommentAnalysisView(s,taskId){const target=scope(s),u=s.savedCommentAnalysis;return target&&u?.key===target.key&&u.taskId===taskId?u.value:null;}
function validate(s,u,value){
  if(!value||value.actor?.username!==s.user||value.actor.storeId!==u.storeId||value.taskId!==u.taskId
      ||!['idle','running','paused','held','completed','blocked'].includes(value.status)||typeof value.running!=='boolean'
      ||typeof value.canResume!=='boolean'||typeof value.canPause!=='boolean'
      ||!value.counts||!['total','pending','held','analyzed','missingText'].every(k=>num(value.counts[k]))
      ||value.counts.total!==value.counts.pending+value.counts.held+value.counts.analyzed+value.counts.missingText)
    throw Error('原员工、门店或评论任务的分析状态尚未核实，请重新读取。');
  return value;
}
export function bindSavedCommentAnalysis(root,ctx){
  const s=ctx.state,u=model(s),panel=root.querySelector('[data-saved-analysis-panel]');
  if(!u||!panel||typeof ctx.analysisQueueAction!=='function')return ()=>{};
  let closed=false,timer=null;
  const sameScope=()=>scope(s)?.key===u.key&&s.savedCommentAnalysis===u;
  const valid=()=>!closed&&panel.isConnected&&sameScope();
  const paint=()=>{if(!valid())return;panel.innerHTML=content(u);bind();};
  const schedule=()=>{clearTimeout(timer);if(valid())timer=setTimeout(()=>void perform('analysis_queue_read'),u.value?.running?3000:10000);};
  function perform(action){
    if(!valid()||u.busy)return Promise.resolve(false);
    if(action==='analysis_queue_resume'&&!u.needsAuthority&&(u.uncertain||!u.value?.canResume||!u.value.counts.pending))return Promise.resolve(false);
    u.busy=true;u.error='';paint();
    const operation={action,promise:null};u.operation=operation;
    operation.promise=(async()=>{try{
      const result=await ctx.analysisQueueAction(action,{storeId:u.storeId,taskId:u.taskId,...(action==='analysis_queue_resume'?{confirmed:true}:{})});
      if(!sameScope())return false;
      u.value=validate(s,u,result.analysisQueue);u.uncertain=false;u.needsAuthority=false;u.lastRead=Date.now();return true;
    }catch(error){
      if(sameScope()){u.error=error?.message||'分析状态暂不可读，请刷新后核对。';u.uncertain=true;u.needsAuthority=['ANALYSIS_AUTHORITY_REQUIRED','ANALYSIS_AUTHORITY_EXPIRED'].includes(error?.code);}
      return false;
    }finally{if(u.operation===operation){u.busy=false;delete u.operation;}if(sameScope()){u.repaint?.();u.reschedule?.();}}})();
    return operation.promise;
  }
  function confirm(){
    if(!valid()||u.busy||!u.needsAuthority&&(u.uncertain||!u.value?.canResume))return;
    const c=u.value?.counts;
    const confirmation={promise:null};u.confirmation=confirmation;
    let dialog,owner;
    const current=()=>sameScope()&&u.confirmation===confirmation&&dialog?.open&&dialog.__modalOwner===owner;
    dialog=ctx.modal({title:'继续分析已采评论',confirmLabel:'确认继续分析',
      html:`<p>${esc(s.store||'当前门店')} · ${u.needsAuthority?'将先核对当前员工与门店授权，通过后继续分析本任务已保存评论。':`当前任务有 <strong>${c.pending} 条</strong>已保存评论可继续分析。`}</p><p>采集暂停后，评论分析可以单独继续；采集状态保持当前设置。</p>${c?.held?`<p>${c.held} 条原请求结果待核对，保留原记录，本次不会重复提交。</p>`:''}`,
      onConfirm:()=>{
        if(!current())return false;
        if(confirmation.promise)return confirmation.promise;
        const button=dialog.querySelector('.modal-confirm');if(button)button.disabled=true;
        confirmation.promise=(async()=>{
          // A platform repaint replaces the panel, but not this confirmed scope.
          // Wait for a read already in flight; never lose or duplicate the click.
          if(u.operation?.action==='analysis_queue_read')await u.operation.promise;
          if(!current())return false;
          const accepted=await u.perform?.('analysis_queue_resume');
          if(accepted!==true&&current())ctx.toast?.(u.error||'分析状态已变化，请刷新后核对；本次没有重复提交。');
          return accepted===true;
        })();
        return confirmation.promise;
      }});
    owner=dialog?.__modalOwner;
  }
  function bind(){
    panel.querySelector('[data-analysis-read]')?.addEventListener('click',()=>void perform('analysis_queue_read'));
    panel.querySelector('[data-analysis-resume]')?.addEventListener('click',confirm);
    panel.querySelector('[data-analysis-pause]')?.addEventListener('click',()=>void perform('analysis_queue_pause'));
  }
  // A read can refresh counts; page mounting never starts analysis or collection.
  u.perform=perform;u.repaint=paint;u.reschedule=schedule;
  bind();if(!u.busy&&Date.now()-u.lastRead>2000)void perform('analysis_queue_read');else schedule();
  return ()=>{closed=true;clearTimeout(timer);if(u.perform===perform){delete u.perform;delete u.repaint;delete u.reschedule;}};
}
