export const platformId=value=>['douyin','dy','抖音'].includes(value)?'douyin':'xiaohongshu';
export const activePlatform=state=>platformId(state.activePlatform);
export const platformName=value=>platformId(value)==='douyin'?'抖音':'小红书';
export const platformIcon=value=>`/assets/${platformId(value)==='douyin'?'brand-douyin.svg':'brand-xiaohongshu.svg'}`;
export const personalTools=state=>state.connection==='preview'||state.session?.user?.role==='admin';
export function renderPlatformSwitch(state){return `<nav class="platform-switch" aria-label="切换平台">${['xiaohongshu','douyin'].map(id=>`<button type="button" data-switch-platform="${id}" aria-pressed="${activePlatform(state)===id}" ${state.busy?'disabled':''}><img src="${platformIcon(id)}" alt=""><span>${platformName(id)}</span></button>`).join('')}</nav>`;}
