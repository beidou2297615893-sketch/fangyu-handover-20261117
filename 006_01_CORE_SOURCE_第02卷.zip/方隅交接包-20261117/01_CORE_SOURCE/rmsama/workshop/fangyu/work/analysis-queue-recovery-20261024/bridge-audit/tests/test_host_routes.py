"""Actual HTTP handler + extracted backend route + synthetic authority only."""
import http.client
import importlib.util
import json
from http.server import ThreadingHTTPServer
import threading
import unittest
from test_bridge_contract import fixture, NATIVE

spec=importlib.util.spec_from_file_location('isolated_bridge_host',NATIVE/'ui_native_host.py')
host=importlib.util.module_from_spec(spec)
spec.loader.exec_module(host)

class Routes(unittest.TestCase):
    def setUp(self):
        self.backend=fixture()
        self.backend.dispatch=self.backend._analysis_queue_dispatch
        self.server=ThreadingHTTPServer(('127.0.0.1',0),host.StaticHandler)
        self.server.backend=self.backend
        self.server.runtime=None
        self.server.csp=host.CSP
        self.server.csrf_token='fixture-only'
        self.server.session_cookie=host.SESSION_COOKIE
        self.server.api_lock=threading.RLock()
        self.server.counters={'blocked':0}
        self.server.login_failures=[]
        self.worker=threading.Thread(target=self.server.serve_forever,daemon=True)
        self.worker.start()
    def tearDown(self):
        self.server.shutdown();self.server.server_close();self.worker.join(2)
    def request(self,changes=None,action='analysis_queue_read',data=None):
        headers={'Content-Type':'application/json','Origin':f'http://127.0.0.1:{self.server.server_port}',
                 'X-Fangyu-CSRF':'fixture-only','Cookie':host.SESSION_COOKIE+'=fixture-token'}
        headers.update(changes or {})
        body=json.dumps({'action':action,'data':data or {'storeId':'store1','taskId':'task1'}})
        connection=http.client.HTTPConnection('127.0.0.1',self.server.server_port,timeout=2)
        connection.request('POST','/api/workbench',body,headers)
        response=connection.getresponse();status=response.status;raw=response.read();connection.close()
        return status,raw
    def test_owned_paused_task_routes_over_http(self):
        status,raw=self.request();self.assertEqual(status,200)
        self.assertEqual(json.loads(raw)['analysisQueue']['counts']['pending'],181)
    def test_host_origin_csrf_cannot_be_bypassed(self):
        for change in ({'Host':'external.invalid'},{'Origin':'https://external.invalid'},{'X-Fangyu-CSRF':'bad'}):
            self.assertEqual(self.request(change)[0],403)
        self.assertIsNone(self.backend._analysis_queue)
    def test_foreign_task_never_reaches_controller(self):
        self.backend.task['cloud_owner']='other'
        status,raw=self.request();self.assertEqual(status,403)
        self.assertEqual(json.loads(raw)['error']['code'],'TASK_FORBIDDEN')
        self.assertIsNone(self.backend._analysis_queue)
    def test_analysis_does_not_wait_for_unrelated_host_action_lock(self):
        with self.server.api_lock:
            self.assertEqual(self.request()[0],200)

if __name__=='__main__':unittest.main(verbosity=2)
