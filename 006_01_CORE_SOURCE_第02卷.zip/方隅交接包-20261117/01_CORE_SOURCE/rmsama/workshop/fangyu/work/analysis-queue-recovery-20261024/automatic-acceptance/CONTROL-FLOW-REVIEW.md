# 自动分析控制流独立审查

本轮只读产品候选和冻结源；自建 SQLite、模拟身份与模型在本目录。不操作正式数据、Native、云模型、CLI、采集或发送。

## 已核对的实际接线

- `WorkbenchBackend._identity` 在真实员工核验、门店目录及选择读取成功后记 RAM 权限并发自动授权信号。`_bootstrap(token)` 同样补发信号。重复同员工、同店、同 session 的 fresh 只更新回调，不换 director、不清暂停、不自动解除真实错误。
- 登录分支先关闭旧 controller，再核新 token，最后带新 token 调 `_bootstrap`；选店分支在事务提交后关闭旧 controller，再带 token 重新 bootstrap。旧版“先授权后关闭/重建没 token”的缺口已消除。
- `authorize_workspace` 只注册 RAM、事件及后台线程。真正任务读取、身份 fresh、已绑定 service 的启动和模型工作在 director 上；无需先进入获客页或按继续分析。
- 冷启动使用冻结 F103 的 `AssistantService.start/_run`。独立组合测试最初 executor=None，由原 `_run` 调工厂创建；禁止 `PlatformRuntime.prepare`、CLI 配置/下载，不启全局 AIWorker，不接收远程采集/发送命令。
- 同一个 director 顺序消费本店同 owner 所有有效任务；采集任务暂停或验证不传递给分析取消事件。新页保存/导入只唤醒，不另建模型消费者。跨 store/员工变化和登出使旧 RAM 授权失效，原 `_guard`/attempt CAS 仍在提交及应用边界执行。
- 真实权限、预算及新未知请求导致持久 blocked，后台不盲目重试；明确暂停偏好持久化，正常关闭不记永久暂停。旧 unknown 不重放。

## 已抓到并由作者修正的具体缺口

1. 早期候选只见 executor=None 就永久报身份变化，无法冷启动。已改为只有真实可处理评论才核绑定、后台启动原 service 并等待 ready。
2. 早期旧 Busy 门槛使分析历史任务 A 阻断采集任务 B。已允许同工作区授权，把 B 保存到同队列。
3. 反向解耦：用户暂停分析、AI 预算或 intent 特性异常不能阻断本来已获授权的采集入库；仍保留原采集权限和缓冲背压。采集不得偷偷恢复本人暂停的分析。
4. 每3秒全店计数历史扫描已复用真实 customer-read durable revision 缓存；controller metadata 不失效，lead 与 attempt 的正常状态变更失效。`ai_attempts` 的 UPDATE 不换 rowid，故补三种 unresolved 状态计数，不能只依赖 COUNT/MAX。
5. 空闲 director 原每10秒仍跑 candidate 历史 JSON 查询；已用同 revision 的零 pending 缓存短路，新增业务 revision 后再扫描。
6. 正常提交中20条一度混入旧 held，数字看似又异常。现在只对当前 run、精确 request/submission UUID、真实 unresolved 且未保存结果的交集显示 processing；remaining 直到 AI 真保存才减少。
7. 新 processing 点查曾继承 `INDEXED BY scope`，每次显示仍遍历租户历史。已要求并由作者改为现有 entity/id 主键点查，保留 tenant/owner/store/task 判定；独立组合增加实际 EXPLAIN 断言。

## 验收边界

独立组合实测候选的真实 bootstrap、身份回入、原 service 启动、原批次选择/attempt journal 和实际本地写入链。外部身份、心跳、模型响应为合成传输，所以不证明正式版本已安装、当前 Native 已加载、真实 DeepSeek 计费或244条真实模型结果完成。这些由主任务另行核验。

合成比例沿用真实只读审计计数：2068总、1794原分析、244可分析、9原 unknown、21缺正文。最终应为2038已分析、9待核、21缺正文；9/21保留原因不能包装为模型成功。该比例不是重新生成真实客户数据。
