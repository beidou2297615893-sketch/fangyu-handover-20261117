"""Actual controller + original analyze_pending/attempts; transport results synthetic."""
from pathlib import Path
import hashlib,io,json,os,socket,subprocess,sys,unittest
from types import SimpleNamespace
from urllib.error import HTTPError
from unittest.mock import patch
ROOT=Path(__file__).resolve().parents[1]
W=ROOT.parents[1]
FROZEN=Path('C:/积木软件工坊/项目/方隅公寓客户版/work/parallel-integration-20261018/final-integration/candidate-unified-v102/project/work/ui-native-r57/releases/ui-r57-20261024T142602Z-eec3748c/resources/platform-runtime/analysis_queue_runtime.py')
def option(name):
    return sys.argv[sys.argv.index(name)+1] if name in sys.argv else None
MODULE=Path(option('--module') or os.environ.get('LEGACY_STATUS_MODULE') or FROZEN)
EVIDENCE=Path(option('--output') or os.environ.get('LEGACY_STATUS_EVIDENCE') or ROOT/'evidence');EVIDENCE.mkdir(parents=True,exist_ok=True)
os.environ['ANALYSIS_QUEUE_CONTROLLER']=str(MODULE)
os.environ['ANALYSIS_QUEUE_EVIDENCE']=str(EVIDENCE)
sys.path.insert(0,str(W/'core-audit/candidate'))
import test_analysis_queue as base
base.HERE=ROOT/'work';base.HERE.mkdir(exist_ok=True)

class Error(ValueError):
    def __init__(self,code,status=None):
        self.code=code
        if status is not None:self.http_status=status
        super().__init__('synthetic safe error')

class ProfileWorkflow(base.FixtureWorkflow):
    def analyze(self,user,task,rows,**kwargs):
        self.cloud(user,'ai_profile',{})
        return super().analyze(user,task,rows,**kwargs)

class LegacyStatus(base.QueueTests):
    def setUp(self):
        super().setUp()
        self.stage_calls=[];self.status_error=None;self.profile_error=None;self.new_error=None
        original=self.executor.ai.cloud
        def cloud(user,operation,data):
            self.stage_calls.append(operation)
            if operation=='ai_attempt_status' and self.status_error:raise self.status_error
            if operation=='ai_profile':
                if self.profile_error:raise self.profile_error
                return {'config':{'enabled':True,'configured':True,'revision':5}}
            if operation=='intent_analyze' and self.new_error:raise self.new_error
            return original(user,operation,data)
        host=self.executor.ai.attempts.host_context
        self.executor.ai.cloud=cloud
        self.executor.ai.attempts=base.LocalAIAttempts(self.core,cloud,host_context=host)
        self.manager.workflow_factory=ProfileWorkflow

    def prepare(self,count=4):
        self.leads(count);return self.unknown(['lead-0'])

    def test_legacy503_original_status_is_not_a_prerequisite_for_disjoint_new_leads(self):
        old=self.prepare();self.status_error=Error('AI_LEGACY_EXTENSIONS_DISABLED',503)
        self.call('analysis_queue_resume',confirmed=True);final=self.wait()
        self.assertEqual(final['counts'],{'total':4,'pending':0,'held':1,'analyzed':3,'missingText':0})
        self.assertEqual(self.core.store.get('ai_attempts',old['id']),old)
        self.assertEqual(final['heldStatusCode'],'AI_LEGACY_EXTENSIONS_DISABLED')
        self.assertEqual(self.stage_calls,['ai_attempt_status','ai_profile','intent_analyze'])

    def test_legacy_code_with_real401_still_stops_before_profile_or_new_attempt(self):
        old=self.prepare();self.status_error=Error('AI_LEGACY_EXTENSIONS_DISABLED',401)
        self.call('analysis_queue_resume',confirmed=True);final=self.wait()
        self.assertEqual(final['status'],'blocked');self.assertEqual(final['phase'],'original_request_status')
        self.assertEqual(self.stage_calls,['ai_attempt_status'])
        self.assertEqual(self.core.store.list('ai_attempts','fixture-tenant'),[old])

    def test_real403_revocation_still_stops_before_profile_or_new_attempt(self):
        old=self.prepare();self.status_error=Error('AI_ADMIN_REQUIRED',403)
        self.call('analysis_queue_resume',confirmed=True);final=self.wait()
        self.assertEqual(final['status'],'blocked');self.assertEqual(final['phase'],'original_request_status')
        self.assertEqual(self.stage_calls,['ai_attempt_status'])
        self.assertEqual(self.core.store.list('ai_attempts','fixture-tenant'),[old])

    def test_profile_legacy_failure_is_distinct_and_not_bypassed(self):
        old=self.prepare();self.profile_error=Error('AI_LEGACY_EXTENSIONS_DISABLED',503)
        self.call('analysis_queue_resume',confirmed=True);final=self.wait()
        self.assertEqual(final['status'],'blocked');self.assertEqual(final['phase'],'ai_profile')
        self.assertEqual(self.stage_calls,['ai_attempt_status','ai_profile'])
        self.assertEqual(self.core.store.list('ai_attempts','fixture-tenant'),[old])
        self.assertIn('企业AI旧接口停用',final['message'])
        self.assertIn('原评论保留',final['message'])

    def test_new_intent_legacy_failure_is_not_swallowed_and_retains_unknown_key(self):
        old=self.prepare(42);self.status_error=Error('AI_LEGACY_EXTENSIONS_DISABLED',503)
        self.new_error=Error('AI_LEGACY_EXTENSIONS_DISABLED',503)
        self.call('analysis_queue_resume',confirmed=True);final=self.wait()
        self.assertEqual(final['status'],'blocked');self.assertEqual(final['phase'],'intent_analyze')
        self.assertEqual(self.stage_calls,['ai_attempt_status','ai_profile','intent_analyze'])
        rows=self.core.store.list('ai_attempts','fixture-tenant')
        self.assertEqual(len(rows),2);self.assertEqual(self.core.store.get('ai_attempts',old['id']),old)
        fresh=next(row for row in rows if row['id']!=old['id'])
        self.assertEqual(fresh['state'],'unknown');self.assertNotEqual(fresh['request_id'],old['request_id'])
        self.assertEqual(final['counts']['analyzed'],0)

    def test_new_unknown_stops_after_first_batch_and_never_replays_old_held(self):
        old=self.prepare(42);self.status_error=Error('AI_LEGACY_EXTENSIONS_DISABLED',503)
        self.new_error=Error('AI_PROVIDER_TIMEOUT',503)
        self.call('analysis_queue_resume',confirmed=True);final=self.wait()
        self.assertEqual(final['code'],'AI_PROVIDER_TIMEOUT');self.assertEqual(final['phase'],'intent_analyze')
        self.assertEqual(self.stage_calls.count('intent_analyze'),1)
        self.assertEqual(self.core.store.get('ai_attempts',old['id']),old)
        self.assertEqual(len(self.core.store.list('ai_attempts','fixture-tenant')),2)

    def test_other_original_status_failure_remains_fail_closed(self):
        old=self.prepare();self.status_error=Error('AI_PROVIDER_UNAVAILABLE',503)
        self.call('analysis_queue_resume',confirmed=True);final=self.wait()
        self.assertEqual(final['status'],'blocked');self.assertEqual(final['phase'],'original_request_status')
        self.assertEqual(self.stage_calls,['ai_attempt_status'])
        self.assertEqual(self.core.store.list('ai_attempts','fixture-tenant'),[old])

    def test_phase_records_only_fixed_names_not_comment_text(self):
        self.prepare();self.profile_error=Error('AI_NOT_CONFIGURED',503)
        self.call('analysis_queue_resume',confirmed=True);final=self.wait()
        control=self.core.store.list(base.candidate.ENTITY,'fixture-tenant')[0]
        self.assertEqual(control['phase'],'ai_profile');self.assertEqual(final['phase'],'ai_profile')
        raw=json.dumps(control)
        self.assertNotIn('fixture text',raw);self.assertNotIn('comments',raw)

    def test_conflicting_or_non503_status_is_not_treated_as_optional_status_failure(self):
        for status in (400,401,403,429,500):
            error=Error('AI_LEGACY_EXTENSIONS_DISABLED',status)
            error.__context__=HTTPError('https://fixture.invalid',503,'fixture',None,io.BytesIO())
            self.assertFalse(base.candidate._legacy_status_unavailable(error),str(status))
        self.assertFalse(base.candidate._legacy_status_unavailable(Error('AI_LEGACY_EXTENSIONS_DISABLED')))

    def test_real_transport_http503_context_is_recognized_without_reading_body_again(self):
        transport=base.load('legacy_status_transport_503',FROZEN.parents[2]/'resources/platform-runtime/vendor-src/integrations.py')
        raw=io.BytesIO(json.dumps({'code':'AI_LEGACY_EXTENSIONS_DISABLED'}).encode())
        error=HTTPError('https://fixture.invalid',503,'fixture',None,raw)
        opener=SimpleNamespace(open=lambda *a,**kw:(_ for _ in ()).throw(error))
        with patch.object(transport,'build_opener',return_value=opener):
            with self.assertRaises(transport.IntegrationError) as caught:
                transport.request_json('https://fixture.invalid',{'operation':'ai_attempt_status'})
        self.assertEqual(caught.exception.code,'AI_LEGACY_EXTENSIONS_DISABLED')
        self.assertTrue(base.candidate._legacy_status_unavailable(caught.exception))

    def test_real_transport_http401_context_is_not_swallowed(self):
        transport=base.load('legacy_status_transport_401',FROZEN.parents[2]/'resources/platform-runtime/vendor-src/integrations.py')
        raw=io.BytesIO(json.dumps({'code':'AI_LEGACY_EXTENSIONS_DISABLED'}).encode())
        error=HTTPError('https://fixture.invalid',401,'fixture',None,raw)
        opener=SimpleNamespace(open=lambda *a,**kw:(_ for _ in ()).throw(error))
        with patch.object(transport,'build_opener',return_value=opener):
            with self.assertRaises(transport.IntegrationError) as caught:
                transport.request_json('https://fixture.invalid',{'operation':'ai_attempt_status'})
        self.assertFalse(base.candidate._legacy_status_unavailable(caught.exception))

    def test_untrusted_old_phase_and_status_code_are_not_returned(self):
        self.leads(1)
        ident=self.manager._record_id(self.user,'fixture-store','fixture-task')
        self.core.store.put(base.candidate.ENTITY,{'id':ident,'tenant_id':'fixture-tenant','status':'blocked',
            'phase':'possible customer text','heldStatusCode':'possible credential text'})
        result=self.call('analysis_queue_read')
        self.assertEqual(result['phase'],'');self.assertEqual(result['heldStatusCode'],'')

if __name__=='__main__':
    stream=io.StringIO();names=[n for n in LegacyStatus.__dict__ if n.startswith('test_')]
    if option('--test'):names=[n for n in names if n==option('--test')]
    with patch.object(socket.socket,'connect',base.deny),patch('subprocess.Popen',side_effect=base.deny):
        result=unittest.TextTestRunner(stream=stream,verbosity=2).run(unittest.TestSuite(LegacyStatus(n) for n in names))
    log=stream.getvalue();tag='GREEN' if result.wasSuccessful() else 'RED'
    (EVIDENCE/(tag+'.log')).write_text(log,'utf-8')
    report={'passed':result.wasSuccessful(),'checks':result.testsRun,'module':str(MODULE),
        'moduleSha256':hashlib.sha256(MODULE.read_bytes()).hexdigest(),'errors':len(result.errors),'failures':len(result.failures),
        'realNetworkOrCloudOrModelOrCliCalls':0,'productionAccess':0,
        'scope':'Actual controller and preserved BusinessExecutor/LocalAIAttempts with only transport/profile/model values replaced by synthetic fixtures.'}
    (EVIDENCE/(tag+'.json')).write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n','utf-8')
    print(log);print(json.dumps(report,ensure_ascii=False))
    raise SystemExit(0 if result.wasSuccessful() else 1)
