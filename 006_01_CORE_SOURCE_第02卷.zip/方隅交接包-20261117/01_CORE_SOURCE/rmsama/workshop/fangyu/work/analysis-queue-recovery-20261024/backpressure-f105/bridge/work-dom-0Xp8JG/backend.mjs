import {createCustomerReadCache} from './customer-read-cache.mjs';
// The approved UI talks to the same local workbench through this small interface.
export class WorkbenchError extends Error {
  constructor(message, code='request_failed') { super(message); this.name='WorkbenchError'; this.code=code; }
}

const MEDIA_ACTIONS=new Set('media_services_status media_ocr_preview media_speech_preview media_speech_cancel media_speech_save media_speech_read media_status media_upload_begin media_upload_read media_upload_chunk media_upload_complete media_upload_cancel media_prepare media_read media_preview media_start media_cancel media_recover media_request'.split(' '));
const MEDIA_READS=new Set(['media_services_status','media_ocr_preview','media_speech_preview','media_speech_cancel','media_speech_read','media_status','media_upload_read','media_read','media_preview','media_request']);
const LIVE_ACTIONS=new Set('livestream_sources_read livestream_source_select livestream_capture livestream_request_read livestream_window_prepare livestream_window_open livestream_window_read'.split(' '));
const DM_ACTIONS=new Set('dm_workspace_read dm_listen_start dm_listen_stop dm_request_read dm_draft_save dm_draft_review dm_queue_prepare dm_queue_start dm_queue_cancel dm_queue_read'.split(' '));
const CONTACT_ACTIONS=new Set(['customer_public_contact_read','customer_public_contact_save','customer_public_contact_cancel']);
const OUTCOME_ACTIONS=new Set(['customer_outcome_read','customer_outcome_save','customer_outcome_cancel','customer_outcome_report']);
const INBOX_ACTIONS=new Set(['interaction_inbox_read','interaction_inbox_state_save','interaction_inbox_request_read']);

export function createBackend(fetcher=globalThis.fetch.bind(globalThis),{timeoutMs=90000,readTimeoutMs=15000}={}) {
  const customerReadCache=createCustomerReadCache();
  const customerWrites=new Set('logout login select_store apply_preset refresh_assessments customer_intent_correct customer_intent_cancel customer_handoff_save customer_public_contact_save customer_public_contact_cancel customer_outcome_save customer_outcome_cancel reply_save reply_review reply_delivery_prepare reply_delivery_start reply_delivery_cancel source_interactions_check acquisition_start acquisition_resume account_delete account_metadata_save'.split(' '));
  let csrfToken='';
  let mode='loading';
  let unconfirmed=false;
  let ruleScope='',rulePending=null;
  let remotePending=null;
  // A scan is a platform mutation, separate from local source configuration receipts.
  // Persist before dispatch; only the original task's observed scan can release it.
  let interactionScope='',interactionActor=null,interactionPending=null;
  const interactionStorage=scope=>'fangyu-interaction-scan-v1:'+scope;
  function setInteractionScope(result){
    const user=result?.session?.user,storeId=result?.selection?.storeId||'';
    const next=user?.username&&storeId?JSON.stringify([globalThis.location?.origin||'',user.tenant_id||'',user.username,user.role||'',storeId]):'';
    interactionActor=next?{username:user.username,storeId}:null;
    if(next===interactionScope){customerReadCache.setScope(next);return;}
    interactionScope=next;customerReadCache.setScope(next);interactionPending=null;deleteRetryReceipt=null;
    try{const p=JSON.parse(globalThis.localStorage?.getItem(interactionStorage(next))||'null');
      if(next&&p?.scope===next&&p.username===user.username&&p.storeId===storeId&&['xiaohongshu','douyin'].includes(p.platform)
        &&typeof p.taskId==='string'&&p.taskId.length>0&&p.taskId.length<=160&&typeof p.accountId==='string'&&p.accountId.length>0&&p.accountId.length<=160
        &&Number.isSafeInteger(p.scan)&&p.scan>=2&&p.scan<=1000000)interactionPending=p;
    }catch{}
  }
  function clearInteraction(p){
    if(interactionPending!==p)return;
    try{globalThis.localStorage?.removeItem(interactionStorage(p.scope));}catch{}
    interactionPending=null;
  }
  function observeInteraction(platform,expectedScope){
    const p=interactionPending,a=platform?.acquisition,t=a?.taskScope;
    if(!p||expectedScope!==interactionScope||p.scope!==interactionScope)return false;
    if(platform?.actor?.username===p.username&&platform.actor.storeId===p.storeId&&a?.taskId===p.taskId
      &&t?.storeId===p.storeId&&t.accountId===p.accountId&&t.platform===p.platform&&t.source?.kind==='own_interactions'
      &&Number.isSafeInteger(a.sourceScan)&&a.sourceScan>=p.scan){clearInteraction(p);return true;}
    return false;
  }
  async function checkInteractions(data={}){
    if(unconfirmed||interactionPending)throw new WorkbenchError('上次新增互动检查尚未确认，请先核对原任务。','SOURCE_SCAN_RESULT_UNCONFIRMED');
    if(!interactionActor||data.storeId!==interactionActor.storeId||!['xiaohongshu','douyin'].includes(data.platform)
      ||typeof data.taskId!=='string'||!data.taskId||data.taskId.length>160||typeof data.accountId!=='string'||!data.accountId||data.accountId.length>160
      ||!Number.isSafeInteger(data.scan)||data.scan<2||data.scan>1000000){const error=new WorkbenchError('请先读取原互动任务及采集账号，再检查新增。','SOURCE_SCAN_SCOPE_REQUIRED');error.mutationCommitted=false;throw error;}
    const p={scope:interactionScope,...interactionActor,platform:data.platform,accountId:data.accountId,taskId:data.taskId,scan:data.scan};
    const serialized=JSON.stringify(p);
    try{globalThis.localStorage?.setItem(interactionStorage(p.scope),serialized);if(globalThis.localStorage?.getItem(interactionStorage(p.scope))!==serialized)throw Error('not persisted');}
    catch{const error=new WorkbenchError('无法保存本机核对断点，本次尚未开始。请重开工作台后再试。','SOURCE_SCAN_STORAGE_UNAVAILABLE');error.mutationCommitted=false;throw error;}
    interactionPending=p;
    try{
      const result=await request('source_interactions_check',{storeId:p.storeId,taskId:p.taskId,scan:p.scan},p);
      if(p.scope!==interactionScope)throw new WorkbenchError('账号或门店已变化，请回原门店核对原任务。','AUTH_SCOPE_CHANGED');
      if(interactionPending===p)throw new WorkbenchError('新增互动检查尚未确认，请核对原任务；不会重复开始。','SOURCE_SCAN_RESULT_UNCONFIRMED');
      return result;
    }catch(error){if(error.mutationCommitted===false&&p.scope===interactionScope)clearInteraction(p);throw error;}
  }
  const remoteActions=new Set(['remote_ai_config_read','remote_config_read','remote_ai_config_save','remote_policy_publish','remote_policy_status','software_update_status','software_update_check','software_update_download','software_update_prepare']);
  const remoteStorage=()=> 'fangyu-remote-receipt-v1:'+ruleScope;
  function persistRemote(){try{if(ruleScope){if(remotePending)globalThis.sessionStorage?.setItem(remoteStorage(),JSON.stringify(remotePending));else globalThis.sessionStorage?.removeItem(remoteStorage());}}catch{}}
  const ruleReads=new Set(['rule_bundle_status','rule_bundle_export_chunk','rule_bundle_import_status']);
  const ruleActions=new Set([...ruleReads,'rule_bundle_import_begin','rule_bundle_import_chunk','rule_bundle_import_prepare','rule_bundle_import_commit']);
  function ruleStorage(){return 'fangyu-rule-receipt-v1:'+ruleScope;}
  function persistRule(){try{if(ruleScope){if(rulePending)globalThis.sessionStorage?.setItem(ruleStorage(),JSON.stringify(rulePending));else globalThis.sessionStorage?.removeItem(ruleStorage());}}catch{}}
  function setRuleScope(result){
    const user=result?.session?.user,store=result?.selection?.storeId||'';
    const next=user?.role==='admin'?JSON.stringify([globalThis.location?.origin||'',user.tenant_id||'fangyu-apartment-client',user.username,user.role,store]):'';
    if(next===ruleScope)return;
    ruleScope=next;rulePending=null;remotePending=null;
    try{const value=JSON.parse(globalThis.sessionStorage?.getItem(remoteStorage())||'null');if(ruleScope&&value?.scope===ruleScope&&['config','policy'].includes(value.kind)&&typeof value.id==='string'&&/^[A-Za-z0-9_-]{8,128}$/.test(value.id)&&Number.isSafeInteger(value.revision))remotePending=value;}catch{}
    try{const value=JSON.parse(globalThis.sessionStorage?.getItem(ruleStorage())||'null');if(value?.scope===ruleScope&&typeof value.requestId==='string')rulePending=value;}catch{}
  }

  async function remoteAction(action,data={}){
    if(!remoteActions.has(action))throw new WorkbenchError('远程管理操作无效','INPUT_INVALID');
    if(!ruleScope)throw new WorkbenchError('远程管理仅限当前管理员会话','ADMIN_REQUIRED');
    const scope=ruleScope,kind=action==='remote_ai_config_save'?'config':action==='remote_policy_publish'?'policy':'';
    if(kind){
      if(remotePending)throw new WorkbenchError('上次远程提交尚未确认，请按原编号核对','REMOTE_RESULT_UNCONFIRMED');
      const id=kind==='config'?data.request_id:data.idempotency_key,revision=kind==='config'?data.expected_revision:data.expected_policy_revision;
      if(typeof id!=='string'||!/^[A-Za-z0-9_-]{8,128}$/.test(id)||!Number.isSafeInteger(revision)||revision<0)throw new WorkbenchError('缺少有效的原操作编号或版本','INPUT_INVALID');
      remotePending={scope,kind,id,revision};persistRemote();
    }
    let result;
    try{result=await request(action,data);}catch(error){if(scope===ruleScope&&error.mutationCommitted===false&&kind){remotePending=null;persistRemote();}throw error;}
    if(scope!==ruleScope)throw new WorkbenchError('管理员或门店已变化，请重新读取','AUTH_SCOPE_CHANGED');
    const p=remotePending;
    if(p?.scope===scope){
      const c=action==='remote_config_read'?result.remote?.aiConfig:['remote_ai_config_read','remote_ai_config_save'].includes(action)?result.configuration:null;
      const publication=['remote_policy_publish','remote_policy_status'].includes(action)?result.publication:null;
      const configProven=p.kind==='config'&&c?.last_save_id===p.id&&c.revision===p.revision+1;
      const policyProven=p.kind==='policy'&&publication?.idempotency_key===p.id&&publication.state==='succeeded'&&publication.mutation_committed===true;
      const rejected=(p.kind==='config'&&result.request_id===p.id||p.kind==='policy'&&publication?.idempotency_key===p.id)&&['rejected','not_applied','cancelled'].includes(publication?.state||result.state)&&(publication?.mutation_committed??result.mutation_committed)===false;
      if(configProven||policyProven||rejected){remotePending=null;persistRemote();}
    }
    return result;
  }
  function rememberRule(action,data,unknown=false){
    rulePending={...(rulePending||{}),scope:ruleScope,action,unknown,
      ...Object.fromEntries(['requestId','uploadId','expectedRevision','digest','bytes','chunkCount','previewDigest','index'].filter(k=>data?.[k]!==undefined).map(k=>[k,data[k]]))};
    persistRule();
  }
  function ruleReceipt(action,data,value,expectedScope){
    if(expectedScope!==ruleScope||!rulePending||!value)return;
    const matches=(data?.requestId&&data.requestId===rulePending.requestId&&value.requestId===rulePending.requestId)
      ||(data?.uploadId&&data.uploadId===rulePending.uploadId&&(!value.uploadId||value.uploadId===rulePending.uploadId));
    if(!matches)return;
    if(value.uploadId)rulePending.uploadId=value.uploadId;
    if(value.previewDigest)rulePending.previewDigest=value.previewDigest;
    rulePending.state=value.state;
    if(action==='rule_bundle_import_status'){
      const previous=rulePending.action;
      const proven=previous==='rule_bundle_import_begin'&&['uploading','prepared','committed','not_found'].includes(value.state)
        ||previous==='rule_bundle_import_chunk'&&Array.isArray(value.receivedIndices)
        ||previous==='rule_bundle_import_prepare'&&['prepared','committed','uploading'].includes(value.state)
        ||previous==='rule_bundle_import_commit'&&['committed','prepared'].includes(value.state)
        ||['rejected','expired','aborted'].includes(value.state);
      if(proven)rulePending.unknown=false;
    }else rulePending.unknown=false;
    if(['committed','rejected','expired','aborted','not_found'].includes(value.state)){rulePending=null;}persistRule();
  }

  let unconfirmedAction='',unconfirmedRequestId='',unconfirmedDeliveryId='',unconfirmedStoreId='',unconfirmedDeletePayload='';
  let deleteRetryReceipt=null;
  async function accountDeleteRetry(data){
    const proof=deleteRetryReceipt;
    if(!proof||proof.storeId!==data?.storeId||proof.requestId!==data?.requestId||proof.username!==interactionActor?.username||proof.storeId!==interactionActor?.storeId)throw new WorkbenchError('请先按原编号确认删除尚未开始。','ACCOUNT_DELETE_RETRY_NOT_CONFIRMED');
    if(unconfirmed&&(unconfirmedAction!=='account_delete'||JSON.stringify(data)!==unconfirmedDeletePayload))throw new WorkbenchError('原删除内容或待核操作已变化，请核对原结果。','RESULT_UNCONFIRMED');
    deleteRetryReceipt=null;return request('account_delete',data,null,true);
  }
  function unknown(action,data){if(action==='source_interactions_check')return;unconfirmed=true;unconfirmedAction=action;unconfirmedRequestId=data?.requestId||'';unconfirmedDeliveryId=data?.accountId||data?.id||'';unconfirmedStoreId=data?.storeId||'';if(action==='account_delete')unconfirmedDeletePayload=JSON.stringify(data);}
  async function runtimeStatus(){
    const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),Math.min(timeoutMs,10000));
    try{
      const response=await fetcher('/__workbench_status',{method:'GET',credentials:'same-origin',cache:'no-store',signal:controller.signal});
      if(!response.ok)throw new WorkbenchError('运行版本暂不可读，请刷新版本状态。','runtime_metadata_unavailable');
      const value=await response.json();
      if(!value||typeof value.release!=='string'||!value.release.length||value.release.length>160||!/[A-Za-z0-9_-]/.test(value.release)||!/^[A-Za-z0-9_-]+$/.test(value.release)
        ||!['production','fixture'].includes(value.profile)||!['stable','development'].includes(value.mode)||typeof value.instanceId!=='string'||!/^[a-f0-9]{32}$/.test(value.instanceId))
        throw new WorkbenchError('运行元数据尚未核对，请刷新后查看。','runtime_metadata_invalid');
      return {release:value.release,profile:value.profile,mode:value.mode,instanceId:value.instanceId};
    }catch(error){if(error instanceof WorkbenchError)throw error;throw new WorkbenchError('暂时无法读取本机运行版本，请刷新重试。','runtime_metadata_unavailable');}
    finally{clearTimeout(timer);}
  }
  async function request(action, data,interactionOperation=null,confirmedDeleteRetry=false) {
    const invalidatesCustomers=customerWrites.has(action);
    if(invalidatesCustomers)customerReadCache.invalidate();
    if(action==='logout'||action==='login')customerReadCache.setScope('');
    const scanScope=interactionScope;
    const rule=ruleActions.has(action),ruleRead=ruleReads.has(action),operationScope=ruleScope;
    if(rule&&!ruleScope)throw new WorkbenchError('规则文件仅限当前真实管理员会话。','RULE_BUNDLE_ADMIN_REQUIRED');
    if(rule&&!ruleRead&&rulePending?.unknown)throw new WorkbenchError('上次规则导入结果未知，请先核对原导入状态。','RULE_BUNDLE_RESULT_UNCONFIRMED');
    if(rule&&!ruleRead)rememberRule(action,data,true);
    const bootstrap=action==='bootstrap';
    const get=bootstrap||['platform','account_job','customers','customer_detail'].includes(action);
    // Remote writes keep their own original receipt; never clear them via bootstrap recovery.
    const content=action.startsWith('content_'),media=MEDIA_ACTIONS.has(action),mediaRead=MEDIA_READS.has(action);
    // Single-comment corrections retain their own original request receipt in the
    // detail helper. Generic bootstrap recovery must never clear that receipt.
    const intentCorrection=['customer_intent_read','customer_intent_correct','customer_intent_cancel'].includes(action);
    const intentRead=action==='customer_intent_read';
    const keywordRead=action==='keyword_effect_read';
    const analysisLocal=['analysis_queue_read','analysis_queue_resume','analysis_queue_pause','analysis_workspace_read','analysis_workspace_resume','analysis_workspace_pause'].includes(action),analysisRead=['analysis_queue_read','analysis_workspace_read'].includes(action);
    const accountDeleteRead=action==='account_delete_request';
    const contactLocal=CONTACT_ACTIONS.has(action),contactRead=action==='customer_public_contact_read';
    const outcomeLocal=OUTCOME_ACTIONS.has(action),outcomeRead=outcomeLocal&&!['customer_outcome_save','customer_outcome_cancel'].includes(action);
    const contentRead=['content_guided_catalog_read','content_guided_read','content_store_context_read','content_workspace_read','content_knowledge_search','content_methods_read','content_task_history','content_knowledge_file_preview'].includes(action);
    const inboxLocal=INBOX_ACTIONS.has(action),inboxRead=inboxLocal&&action!=='interaction_inbox_state_save';
    const sourceRead=['acquisition_source_preview','source_preset_read','source_schedule_read','source_execution_read'].includes(action);
    const sourceLocal=sourceRead||['source_preset_save','source_schedule_save','source_execution_enable','source_execution_pause'].includes(action);
    const read=analysisLocal||LIVE_ACTIONS.has(action)||DM_ACTIONS.has(action)||get||accountDeleteRead||media||contactLocal||outcomeLocal||inboxLocal||rule||content||intentCorrection||keywordRead||sourceLocal||remoteActions.has(action)||['ai_readiness_read','ai_rules_read','ai_rules_export','account_safety','customer_export','customer_handoff_read','customer_memo_export','account_metadata_read','reply_read','reply_check','reply_delivery_status','tone_preferences_read'].includes(action);
    if(!read&&((unconfirmed&&!(confirmedDeleteRetry&&action==='account_delete'&&unconfirmedAction==='account_delete'&&JSON.stringify(data)===unconfirmedDeletePayload))||interactionPending&&interactionOperation!==interactionPending))throw new WorkbenchError('上次操作结果尚未确认，请先核对状态。','RESULT_UNCONFIRMED');
    const controller=new AbortController();
    const shortRead=analysisLocal||['livestream_sources_read','livestream_request_read','livestream_window_prepare','livestream_window_read'].includes(action)||['dm_workspace_read','dm_request_read','dm_queue_read'].includes(action)||get||accountDeleteRead||mediaRead||contactRead||outcomeRead||inboxRead||ruleRead||contentRead||intentRead||keywordRead||sourceRead||['ai_readiness_read','ai_rules_read','account_safety','account_metadata_read','reply_read','reply_check','reply_delivery_status','tone_preferences_read','remote_ai_config_read','remote_config_read','remote_policy_status','software_update_status'].includes(action);
    const timeout=setTimeout(()=>controller.abort(),shortRead?Math.min(timeoutMs,readTimeoutMs):timeoutMs);
    try {
      const url=bootstrap?'/api/workbench/bootstrap':action==='platform'?'/api/workbench/platform?'+new URLSearchParams(data).toString():action==='account_job'?'/api/workbench/account-job?jobId='+encodeURIComponent(data.jobId):action==='customers'?'/api/workbench/customers?'+new URLSearchParams(data).toString():action==='customer_detail'?'/api/workbench/customer?'+new URLSearchParams(data).toString():'/api/workbench';
      const response=await fetcher(url,get
        ? {method:'GET',credentials:'same-origin',cache:'no-store',signal:controller.signal}
        : {method:'POST',credentials:'same-origin',cache:'no-store',headers:{'Content-Type':'application/json','X-Fangyu-CSRF':csrfToken},body:JSON.stringify({action,data}),signal:controller.signal});
      // The static design preview deliberately has no business interface.
      if(bootstrap&&response.status===404) { mode='preview'; return null; }
      if((content||media||sourceLocal)&&response.status===413){const error=new WorkbenchError('本次内容过大，请缩小后再提交。','INPUT_TOO_LARGE');error.mutationCommitted=false;throw error;}
      let result;
      try { result=await response.json(); }
      catch { if(analysisLocal&&!analysisRead)throw new WorkbenchError('评论分析的操作回执尚未确认，请刷新原任务分析状态。','ANALYSIS_QUEUE_RESULT_UNCONFIRMED');if(intentCorrection&&!intentRead)throw new WorkbenchError('更正结果尚未确认，请核对原操作。','CUSTOMER_INTENT_RESULT_UNCONFIRMED');if(inboxLocal&&!inboxRead)throw new WorkbenchError('互动处理结果尚未确认，请保留原编号核对。','INTERACTION_RESULT_UNCONFIRMED');if(sourceLocal&&!sourceRead)throw new WorkbenchError('预设保存结果尚未确认，请按原编号核对。','SOURCE_CONFIGURATION_UNCONFIRMED');if(content&&!contentRead)throw new WorkbenchError('内容操作结果尚未确认，请核对原操作，不会自动重复保存。','CONTENT_RESULT_UNCONFIRMED');if(rule&&!ruleRead)throw new WorkbenchError('规则导入结果未知，请核对原操作，不会自动重试。','RULE_BUNDLE_RESULT_UNCONFIRMED');if(!read)unknown(action,data);throw new WorkbenchError(read?'本地服务返回异常，请稍后重新核对。':'操作结果尚未确认，正在核对状态。',read?'invalid_response':'RESULT_UNCONFIRMED'); }
      if(remoteActions.has(action)&&operationScope!==ruleScope)throw new WorkbenchError('管理员或门店已变化，请重新读取','AUTH_SCOPE_CHANGED');
      if(result?.csrfToken)csrfToken=result.csrfToken;
      if(!response.ok||result?.ok!==true){if(rule&&!ruleRead&&result?.error?.code!=='RULE_BUNDLE_RESULT_UNCONFIRMED'&&operationScope===ruleScope&&rulePending){rulePending.unknown=false;persistRule();}if(action==='account_delete'&&result?.error?.mutation_committed===false&&unconfirmedAction==='account_delete'&&data?.requestId===unconfirmedRequestId&&data?.storeId===unconfirmedStoreId)unconfirmed=false;if(action==='account_delete'&&/(?:UNKNOWN|UNCONFIRMED)$/.test(result?.error?.code||''))unknown(action,data);if(action==='account_metadata_save'&&result?.error?.code==='ACCOUNT_METADATA_RESULT_UNCONFIRMED')unknown(action,data);if(action==='customer_handoff_save'&&['HANDOFF_RESULT_UNCONFIRMED','MEMO_RESULT_UNCONFIRMED'].includes(result?.error?.code))unknown(action,data);const failure=new WorkbenchError(result?.error?.message||'操作未完成，请稍后重试。',result?.error?.code||'request_failed');if(['customers','customer_detail','reply_read'].includes(action))failure.httpStatus=response.status;if(['AUTH_REQUIRED','unauthenticated','session_expired'].includes(failure.code)&&scanScope===interactionScope)setInteractionScope({});if((action==='account_delete'||remoteActions.has(action)||content||media||intentCorrection||contactLocal||outcomeLocal||action==='source_interactions_check')&&result?.error?.mutation_committed===false)failure.mutationCommitted=false;const uncertain=/(?:UNCONFIRMED|UNKNOWN)$/.test(failure.code)||result?.error?.mutation_committed===true;if(inboxLocal){failure.httpStatus=response.status;if(!uncertain&&['INTERACTION_INPUT_INVALID','INTERACTION_FORBIDDEN','INTERACTION_ACCOUNT_CHANGED','INTERACTION_NOT_FOUND','INTERACTION_RECORD_INVALID','INTERACTION_SOURCE_CHANGED','INTERACTION_REQUEST_CONFLICT','INTERACTION_VERSION_CONFLICT','INTERACTION_RESTORE_INVALID','INPUT_INVALID','STORE_FORBIDDEN','ACCOUNT_FORBIDDEN','AUTH_REQUIRED'].includes(failure.code))failure.mutationCommitted=false;}if((content||media||sourceLocal)&&[400,401,403,404,409,413,422].includes(response.status)&&!uncertain){failure.mutationCommitted=false;failure.httpStatus=response.status;}throw failure;}
      if(bootstrap){mode='connected';unconfirmed=false;}
      if(bootstrap||result?.session||action==='logout'){setRuleScope(result);setInteractionScope(result);}
      if(['platform','source_interactions_check'].includes(action))observeInteraction(result.platform,scanScope);
      if(rule)ruleReceipt(action,data,result.ruleBundle,operationScope);
      if(action==='reply_check'&&['reply_save','reply_review'].includes(unconfirmedAction)
        &&data?.requestId===unconfirmedRequestId&&['accepted','observed','not_applied','rejected','not_found','changed'].includes(result.replyWorkspace?.receipt?.state))unconfirmed=false;
      if(action==='account_delete_request'){const d=result.accountDeletion,a=result.actor;if(d?.state==='not_started'&&d.requestId===data?.requestId&&a?.username===interactionActor?.username&&a?.storeId===data?.storeId&&a.storeId===interactionActor?.storeId)deleteRetryReceipt={username:a.username,storeId:a.storeId,requestId:d.requestId};else deleteRetryReceipt=null;}
      if(action==='account_delete'&&result.accountDeletion?.state==='deleted'&&result.accountDeletion.requestId===data?.requestId&&result.accountDeletion.accountId===data?.accountId&&result.actor?.storeId===data?.storeId)unconfirmed=false;
      if(action==='account_delete_request'&&unconfirmedAction==='account_delete'&&data?.storeId===unconfirmedStoreId&&data?.requestId===unconfirmedRequestId&&result.accountDeletion?.requestId===unconfirmedRequestId&&result.accountDeletion?.accountId===unconfirmedDeliveryId&&['deleted','not_started'].includes(result.accountDeletion?.state))unconfirmed=false;
      if(action==='account_delete'&&result.accountDeletion?.state==='unknown')unknown(action,data);
      if(action==='account_metadata_read'&&unconfirmedAction==='account_metadata_save'&&data?.accountId===unconfirmedDeliveryId&&result.accountMetadata?.accountId===data.accountId)unconfirmed=false;
      if(action==='customer_handoff_read'&&unconfirmedAction==='customer_handoff_save'&&data?.storeId===unconfirmedStoreId&&data?.id===unconfirmedDeliveryId&&data?.requestId===unconfirmedRequestId&&result.handoff?.id===data.id&&result.handoff?.receipt?.requestId===unconfirmedRequestId&&['accepted','not_found'].includes(result.handoff.receipt.state))unconfirmed=false;
      if(action==='reply_delivery_status'&&((unconfirmedAction==='reply_delivery_prepare'&&result.delivery?.prepareRequestId===unconfirmedRequestId)||(unconfirmedAction==='reply_delivery_start'&&result.delivery?.id===unconfirmedDeliveryId&&(result.delivery?.requestId===unconfirmedRequestId||result.delivery?.state==='prepared'))||(unconfirmedAction==='reply_delivery_cancel'&&result.delivery?.id===unconfirmedDeliveryId&&['cancelled','stopped','completed','interrupted'].includes(result.delivery?.state))))unconfirmed=false;
      if(invalidatesCustomers)customerReadCache.invalidate();
      return result;
    } catch(error) {
      if(['AUTH_REQUIRED','unauthenticated','session_expired','STORE_FORBIDDEN','STORE_REQUIRED','ACCOUNT_FORBIDDEN'].includes(error?.code))customerReadCache.invalidate();
      if(error instanceof WorkbenchError)throw error;
      if(analysisLocal&&!analysisRead)throw new WorkbenchError('评论分析的操作回执尚未确认，请刷新原任务分析状态。','ANALYSIS_QUEUE_RESULT_UNCONFIRMED');
      if(intentCorrection&&!intentRead)throw new WorkbenchError('更正结果尚未确认，请核对原操作。','CUSTOMER_INTENT_RESULT_UNCONFIRMED');
      if(inboxLocal&&!inboxRead)throw new WorkbenchError('互动处理结果尚未确认，请保留原编号核对。','INTERACTION_RESULT_UNCONFIRMED');if(sourceLocal&&!sourceRead)throw new WorkbenchError('预设保存结果尚未确认，请按原编号核对。','SOURCE_CONFIGURATION_UNCONFIRMED');
      if(media&&!mediaRead)throw new WorkbenchError('视频操作结果尚未确认，请核对原操作，不会自动重新制作。','MEDIA_RESULT_UNCONFIRMED');
      if(content&&!contentRead)throw new WorkbenchError('内容操作结果尚未确认，请核对原操作，不会自动重复保存。','CONTENT_RESULT_UNCONFIRMED');
      if(rule&&!ruleRead)throw new WorkbenchError('规则导入结果未知，请核对原操作，不会自动重试。','RULE_BUNDLE_RESULT_UNCONFIRMED');
      if(!read){unknown(action,data);throw new WorkbenchError('操作结果尚未确认，正在核对状态。','RESULT_UNCONFIRMED');}
      if(error?.name==='AbortError')throw new WorkbenchError('连接超时，暂时无法核对上次操作。','timeout');
      throw new WorkbenchError('暂时无法连接本地服务，请稍后重新核对。','connection_failed');
    } finally { clearTimeout(timeout); }
  }
  async function mediaOutput(data){
    if(!data||Object.keys(data).sort().join(',')!=='accountId,jobId,platform,storeId'||!Object.values(data).every(v=>typeof v==='string'&&/^[A-Za-z0-9_-]{1,160}$/.test(v)))throw new WorkbenchError('请先读取当前账号的成片。','MEDIA_INPUT_INVALID');
    const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),timeoutMs);
    try{const response=await fetcher('/api/workbench/content-video?'+new URLSearchParams({...data,download:'1'}),{method:'GET',credentials:'same-origin',cache:'no-store',signal:controller.signal});
      if(!response.ok||response.headers.get('Content-Type')!=='video/mp4')throw new WorkbenchError('成片暂不可读取，请回原账号核对任务。','MEDIA_OUTPUT_UNAVAILABLE');
      const size=Number(response.headers.get('Content-Length'));if(!Number.isSafeInteger(size)||size<1||size>33554432)throw new WorkbenchError('成片大小未通过核对。','MEDIA_OUTPUT_INVALID');
      const raw=await response.arrayBuffer();if(raw.byteLength!==size)throw new WorkbenchError('成片尚未完整读取，请核对原任务。','MEDIA_OUTPUT_INVALID');return raw;
    }finally{clearTimeout(timer);}
  }
  const safety={accountSafety:accountId=>request('account_safety',{accountId}),
    confirmAccountReview:data=>request('account_review_confirm',data),
    openAccountVerification:accountId=>request('account_verification_open',{accountId}),openAcquisitionVerification:taskId=>request('acquisition_verification_open',{taskId}),resumeVerifiedAcquisition:taskId=>request('acquisition_verification_resume',{taskId})};
  return {...safety,analysisQueueAction:(action,data)=>{if(!['analysis_queue_read','analysis_queue_resume','analysis_queue_pause','analysis_workspace_read','analysis_workspace_resume','analysis_workspace_pause'].includes(action))throw new WorkbenchError('评论分析操作无效','INPUT_INVALID');return request(action,data);},livestreamAction:(action,data)=>{if(!LIVE_ACTIONS.has(action))throw new WorkbenchError('直播操作无效','INPUT_INVALID');return request(action,data);},dmAction:(action,data)=>{if(!DM_ACTIONS.has(action))throw new WorkbenchError('私信操作无效','INPUT_INVALID');return request(action,data);},publicContactAction:(action,data)=>{if(!CONTACT_ACTIONS.has(action))throw new WorkbenchError('原文核对操作无效','INPUT_INVALID');return request(action,data);},outcomeAction:(action,data)=>{if(!OUTCOME_ACTIONS.has(action))throw new WorkbenchError('客户结果操作无效','INPUT_INVALID');return request(action,data);},mediaOutput,mediaAction:(action,data)=>{if(!MEDIA_ACTIONS.has(action))throw new WorkbenchError('视频制作操作无效','INPUT_INVALID');return request(action,data);},interactionInboxAction:(action,data)=>{if(!INBOX_ACTIONS.has(action))throw new WorkbenchError('互动收件操作无效','INPUT_INVALID');return request(action,data);},keywordEffectAction:(action,data)=>{if(action!=='keyword_effect_read')throw new WorkbenchError('词效只支持读取','INPUT_INVALID');return request(action,data);},intentCorrectionAction:(action,data)=>{if(!['customer_intent_read','customer_intent_correct','customer_intent_cancel'].includes(action))throw new WorkbenchError('评论更正操作无效','INPUT_INVALID');return request(action,data);},sourceAction:(action,data)=>{if(!['acquisition_source_preview','source_preset_read','source_preset_save','source_schedule_read','source_schedule_save','source_interactions_check','source_execution_enable','source_execution_read','source_execution_pause'].includes(action))throw new WorkbenchError('获客来源操作无效','INPUT_INVALID');return action==='source_interactions_check'?checkInteractions(data):request(action,data);},get interactionPending(){return interactionPending?{...interactionPending}:null;},contentAction:(action,data)=>{if(!['content_schedule_plan','content_schedule_read','content_schedule_arm','content_schedule_control','content_schedule_tick','content_schedule_reconcile','content_guided_catalog_read','content_guided_read','content_guided_save','content_chain_save','content_chain_run','content_experience_save','content_store_context_read','content_workspace_read','content_persona_save','content_topic_save','content_draft_save','content_draft_audit','content_schedule_save','content_metrics_save','content_export','content_prompt_prepare','content_asset_import','content_render_cards','content_knowledge_import','content_knowledge_search','content_knowledge_file_preview','content_public_article_preview','content_public_article_read','content_public_article_import','content_public_article_cancel','content_public_research_preview','content_public_research_read','content_public_research_import','content_methods_read','content_task_prepare','content_task_run','content_task_reconcile','content_task_apply','content_package_build','content_task_archive','content_task_history'].includes(action))throw new WorkbenchError('内容操作无效','INPUT_INVALID');return request(action,data);},remoteAction,get remotePending(){return remotePending?{...remotePending}:null;},aiReadinessRead:data=>request('ai_readiness_read',data),aiRulesRead:data=>request('ai_rules_read',data),aiRulesExport:data=>request('ai_rules_export',data),aiLocalRulesSave:data=>request('ai_local_rules_save',data),ruleBundle:(action,data={})=>{if(!ruleActions.has(action))throw new WorkbenchError('规则操作无效','INPUT_INVALID');return request(action,data);},get ruleBundlePending(){return rulePending?{...rulePending}:null;},runtimeStatus,tonePreferencesRead:data=>request('tone_preferences_read',data),tonePreferencesSave:data=>request('tone_preferences_save',data),accountWebsiteOpen:data=>request('account_verification_open',{accountId:data.accountId}),accountWebsiteStatus:jobId=>request('account_job',{jobId}),accountDeleteRetry,accountDelete:data=>request('account_delete',data),accountDeleteRequest:data=>request('account_delete_request',data),accountMetadataRead:data=>request('account_metadata_read',data),accountMetadataSave:data=>request('account_metadata_save',data),memoExport:data=>request('customer_memo_export',data),handoffRead:data=>request('customer_handoff_read',data),handoffSave:data=>request('customer_handoff_save',data),get mode(){return mode;},get unconfirmed(){return unconfirmed||Boolean(interactionPending);},deliveryPrepare:data=>request('reply_delivery_prepare',data),deliveryStart:data=>request('reply_delivery_start',data),deliveryStatus:data=>request('reply_delivery_status',data),deliveryCancel:data=>request('reply_delivery_cancel',data),replyRead:data=>customerReadCache.read('reply_read',data,()=>request('reply_read',data)),replySave:data=>request('reply_save',data),replyReview:data=>request('reply_review',data),replyCheck:data=>request('reply_check',data),bootstrap:()=>request('bootstrap'),platform:(data={})=>request('platform',data),accountJob:jobId=>request('account_job',{jobId}),customerReadCache,customers:data=>customerReadCache.read('customers',data,()=>request('customers',data)),customerDetail:(id,data={})=>customerReadCache.read('customer_detail',{id,...data},()=>request('customer_detail',{id,...data})),exportCustomers:data=>request('customer_export',data),login:data=>request('login',data),logout:()=>request('logout',{}),selectStore:storeId=>request('select_store',{storeId}),applyPreset:data=>request('apply_preset',data),refreshAssessments:data=>request('refresh_assessments',data),openDevelopment:()=>request('open_development',{}),preparePlatform:(data={})=>request('platform_prepare',data),createAccount:data=>request('account_create',data),connectAccount:accountId=>request('account_connect',{accountId}),checkAccount:accountId=>request('account_check',{accountId}),cancelAccount:jobId=>request('account_cancel',{jobId}),startAcquisition:data=>request('acquisition_start',data),pauseAcquisition:taskId=>request('acquisition_pause',{taskId}),resumeAcquisition:taskId=>request('acquisition_resume',{taskId})};
}
