"""Actual Runtime page loop + F104 controller; isolated SQLite and synthetic pages."""
from pathlib import Path
from contextlib import contextmanager
import copy, hashlib, io, json, os, socket, subprocess, sys, threading, time, unittest
HERE=Path(__file__).resolve().parent;ROOT=HERE.parent
def option(name):return sys.argv[sys.argv.index(name)+1] if name in sys.argv else None
pins=json.loads(Path(option('--pins')).read_text('utf-8-sig')) if option('--pins') else {}
PROJECT=Path(option('--project') or pins.get('project') or os.environ.get('F105_PROJECT','C:/积木软件工坊/项目/方隅公寓客户版/work/parallel-integration-20261018/final-integration/candidate-unified-v104/project'))
RELEASE=Path(option('--release') or pins.get('release') or os.environ.get('F105_RELEASE',str(PROJECT/'work/ui-native-r57/releases/ui-r57-20261024T153411Z-4c9dd686')))
RUNTIME=Path(option('--module') or (str(RELEASE/'resources/platform-runtime/platform_runtime.py') if pins else os.environ.get('F105_RUNTIME',str(ROOT/'candidate/platform_runtime.py'))))
OUT=Path(option('--output') or os.environ.get('F105_EVIDENCE',str(ROOT/'evidence')));OUT.mkdir(parents=True,exist_ok=True)
os.environ.update(ANALYSIS_QUEUE_SOURCE_PROJECT=str(PROJECT),ANALYSIS_QUEUE_BASE_RELEASE=str(RELEASE),
    ANALYSIS_QUEUE_CONTROLLER=str(RELEASE/'resources/platform-runtime/analysis_queue_runtime.py'),
    ANALYSIS_QUEUE_RUNTIME=str(RUNTIME),ANALYSIS_QUEUE_EVIDENCE=str(OUT))
sys.path.insert(0,str(HERE))
import test_analysis_queue as base
import test_runtime_queue_integration as integration
runtime=integration.runtime

class Backpressure(integration.Integration):
    def setUp(self):
        super().setUp();self.user['_workbench_store_id']='fixture-store'
        self.core.store.put('accounts',{**self.core.store.get('accounts','fixture-account'),'status':'ready'})
        self.server.company['platforms']=['xiaohongshu','douyin']
        self.rt._task_running=lambda task:False;self.rt._task_active=lambda *args:False
        self.rt._readiness=lambda *args,**kwargs:('','')
        self.rt._connection_account=lambda user,account:account
        self.rt._active_login_job_id=lambda *args:''
        self.rt._device=lambda *args:{'bound':True,'state':'online'}
        self.rt._collection_history=lambda task:{}
        self.rt._collection_receipt=lambda *args:None
        self.rt._batch_resumable=lambda *args:False
        self.rt._verification_state=lambda *args:{}
        self.rt._collection_platform_error=lambda task:None
        self.rt._verified_task_pages=lambda *args:{}
        self.notifications=[]
        self.rt._drain_collection_analysis=lambda *args,**kwargs:self.fail('automatic queue must not replay old page/model')
    def automatic(self):
        # Persist the explicit fixture pause before authorizing a director. This
        # avoids a model-start race when testing collection with existing rows.
        self.manager.execute_workspace('analysis_workspace_pause',self.user,'fixture-store',{'storeId':'fixture-store'},self.refresh,lambda task_id:self.refresh)
        self.manager.authorize_workspace(self.user,'fixture-store',self.refresh,lambda task_id:self.refresh)
        self.assertTrue(self.manager.wait_workspace_idle(3))
        notify=self.manager.notify_saved
        def observed(task_id):self.notifications.append(task_id);return notify(task_id)
        self.manager.notify_saved=observed;self.rt._analysis_queue_controller=self.manager
    def ledger(self,ids,**extra):
        row={'id':self.task['id'],'tenant_id':self.user['tenant_id'],'owner':self.user['username'],
            'binding':self.rt._collection_binding(self.task),'lead_ids':list(ids),'status':'pending','code':'PRODUCT_REQUEST_UNKNOWN',**extra}
        self.core.store.put(runtime._COLLECTION_ANALYSIS_ENTITY,row);return copy.deepcopy(row)
    def snapshot(self):return runtime.PlatformRuntime.snapshot(self.rt,self.user,platform='xiaohongshu')['acquisition']
    def seed(self,n,start=0,*,graded=False,missing=False):
        rows=[]
        for i in range(start,start+n):
            row={'id':'lead-'+str(i),'tenant_id':self.user['tenant_id'],'cloud_owner':self.user['username'],
                'task_id':self.task['id'],'platform':'xiaohongshu','text':'' if missing else 'fixture '+str(i),
                'content_title':'fixture post','note_url':'https://www.xiaohongshu.com/explore/123456789012345678901234'}
            if graded:row['ai_intent']={'status':'graded','level':'medium','original':True}
            rows.append(row)
        self.core.store.put_many('leads',rows)
    def run_pages(self,*,first_add=1,initial=0,legacy_length=False):
        ready={**self.task,'status':'ready'};self.core.store.put('tasks',ready)
        if initial:self.seed(initial)
        self.automatic()
        old=self.ledger(['saved-'+str(i) for i in range(250)] if legacy_length else ['old-held'])
        if legacy_length:self.seed(250,graded=True)
        calls=[]
        def page(executor,user,action,data):
            self.assertEqual(action,'task_run');calls.append(data['task_id'])
            number=len(calls);self.seed(first_add if number==1 else 1,start=1000+number*300)
            self.core.store.put('tasks',{**ready,'fixture_page':number})
            return {'status':'completed' if number==2 else 'stopped','summary':{'read':1,'filtered':0,
                'imported':first_add if number==1 else 1,'duplicates':0,'can_continue':number<2,'exhausted':number==2}}
        self.rt._execute=page
        control={'event':threading.Event(),'attempt':'fixture-pages','binding':self.rt._collection_binding(ready)}
        # Bound the baseline's old queued-length wait without hiding the failure.
        timer=threading.Timer(1.5,control['event'].set);timer.daemon=True;timer.start()
        try:
            with base.patch.object(runtime,'wait_for_collection_slot',lambda *args:True):
                self.rt._bounded_collection(self.executor,self.user,self.task['id'],control)
        finally:timer.cancel()
        return calls,control,old

    def test_real_current_shape_old_unknown14_job19_does_not_lock_new_start(self):
        self.automatic();self.seed(487,graded=True);self.seed(9,start=487);self.seed(14,start=496,missing=True)
        old=self.unknown(['lead-'+str(i) for i in range(487,496)])
        page=self.ledger(['lead-'+str(i) for i in range(487,501)])
        job={'id':self.task['id'],'tenant_id':self.user['tenant_id'],'owner':self.user['username'],
            'status':'paused','code':'PRODUCT_REQUEST_UNKNOWN','pending':19};self.core.store.put('ai_jobs',job)
        before=self.core.store.list('leads',self.user['tenant_id'])
        with base.patch.object(self.core.store,'put',side_effect=AssertionError('snapshot must not write')):value=self.snapshot()
        self.assertTrue(value['canStart']);self.assertTrue(value['canResume'])
        self.assertIs(value.get('analysisDecoupled'),True);self.assertEqual(value.get('analysisBufferMode'),'durable_background')
        self.assertIsNone(value.get('analysisBufferLimit'))
        self.assertEqual(self.core.store.get(runtime._COLLECTION_ANALYSIS_ENTITY,self.task['id']),page)
        self.assertEqual(self.core.store.get('ai_jobs',self.task['id']),job);self.assertEqual(self.core.store.get('ai_attempts',old['id']),old)
        self.assertEqual(self.core.store.list('leads',self.user['tenant_id']),before);self.assertEqual(self.calls,[])
    def test_automatic_250_pending_is_durable_queue_without_collection_cap(self):
        self.automatic();self.seed(250);self.ledger(['lead-'+str(i) for i in range(250)])
        value=self.snapshot();self.assertTrue(value['canStart']);self.assertTrue(value['canResume'])
        self.assertIsNone(value.get('analysisBufferLimit'));self.assertEqual(self.calls,[])
    def test_legacy_still_blocks_unknown_pending_and_keeps_200_cap(self):
        self.seed(250);self.ledger(['lead-'+str(i) for i in range(250)])
        value=self.snapshot();self.assertFalse(value['canStart']);self.assertFalse(value['canResume'])
        self.assertIsNot(value.get('analysisDecoupled'),True)
        self.rt._execute=lambda *a,**kw:self.fail('legacy cap must prevent task_resume')
        with self.assertRaises(runtime.PlatformRuntimeError) as raised:self.rt.resume_acquisition(self.user,{'taskId':self.task['id']})
        self.assertEqual(raised.exception.code,'ANALYSIS_BACKLOG_LIMIT')
    def test_page_before_200_gate_no_longer_stops_automatic_collection(self):
        calls,control,old=self.run_pages(initial=250)
        self.assertEqual(len(calls),2);self.assertFalse(control['event'].is_set())
        self.assertEqual(self.core.store.get(runtime._COLLECTION_ANALYSIS_ENTITY,self.task['id']),old);self.assertEqual(self.calls,[])
    def test_page_after_200_gate_no_longer_stops_paused_analysis_collection(self):
        calls,control,old=self.run_pages(first_add=250)
        self.assertEqual(len(calls),2);self.assertFalse(control['event'].is_set())
        self.assertEqual(self.core.store.get(runtime._COLLECTION_ANALYSIS_ENTITY,self.task['id']),old);self.assertEqual(self.calls,[])
    def test_old_long_journal_never_waits_or_replays_after_successful_page_save(self):
        calls,control,old=self.run_pages(legacy_length=True)
        self.assertEqual(len(calls),2);self.assertFalse(control['event'].is_set())
        self.assertEqual(self.core.store.get(runtime._COLLECTION_ANALYSIS_ENTITY,self.task['id']),old)
        self.assertGreaterEqual(len(self.notifications),3);self.assertEqual(self.calls,[])
    def test_resume_scope_mismatch_remains_rejected_before_any_task_resume(self):
        self.automatic();self.ledger(['old-held'],binding={'wrong':'scope'})
        self.rt._execute=lambda *a,**kw:self.fail('binding mismatch cannot resume platform task')
        self.rt._start_task=lambda *a,**kw:self.fail('binding mismatch cannot start thread')
        with self.assertRaises(runtime.PlatformRuntimeError) as raised:self.rt.resume_acquisition(self.user,{'taskId':self.task['id']})
        self.assertEqual(raised.exception.code,'AI_CONTEXT_REQUIRED');self.assertEqual(self.calls,[])
    def test_new_start_allowed_but_old_resume_remains_closed_for_wrong_page_scope(self):
        self.automatic();old=self.ledger(['old-held'],binding={'wrong':'scope'})
        value=self.snapshot();self.assertTrue(value['canStart']);self.assertFalse(value['canResume'])
        self.assertEqual(self.core.store.get(runtime._COLLECTION_ANALYSIS_ENTITY,self.task['id']),old)
    def test_platform_verification_still_blocks_auto_before_next_page(self):
        self.automatic();self.seed(250)
        self.rt._collection_readiness=lambda *args:('verification_required','fixture verification')
        value=self.snapshot();self.assertFalse(value['canStart']);self.assertFalse(value['canResume'])
        self.rt._execute=lambda *a,**kw:self.fail('verification cannot read platform')
        ready={**self.task,'status':'ready'};self.core.store.put('tasks',ready)
        control={'event':threading.Event(),'attempt':'fixture-captcha','binding':self.rt._collection_binding(ready)}
        with self.assertRaises(runtime.PlatformRuntimeError) as raised:self.rt._bounded_collection(self.executor,self.user,self.task['id'],control)
        self.assertEqual(raised.exception.code,'VERIFICATION_REQUIRED');self.assertEqual(self.calls,[])
    def test_closed_or_foreign_workspace_does_not_grant_unbounded_mode(self):
        self.automatic();self.ledger(['old-held']);self.manager.close();self.manager.wait_for_idle(3)
        value=self.snapshot();self.assertFalse(value['canStart']);self.assertIsNot(value.get('analysisDecoupled'),True)

if __name__=='__main__':
    tests=[name for name in Backpressure.__dict__ if name.startswith('test_')]
    log=io.StringIO();pin=hashlib.sha256(RUNTIME.read_bytes()).hexdigest()
    with base.patch.object(socket.socket,'connect',base.deny),base.patch('subprocess.Popen',side_effect=base.deny):
        result=unittest.TextTestRunner(stream=log,verbosity=2).run(unittest.TestSuite(Backpressure(name) for name in tests))
    final=hashlib.sha256(RUNTIME.read_bytes()).hexdigest();passed=result.wasSuccessful() and pin==final
    tag='GREEN' if passed else 'RED';(OUT/(tag+'.log')).write_text(log.getvalue(),'utf-8')
    report={'passed':passed,'tests':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),
        'runtime':str(RUNTIME),'runtimeSha256':pin,'sourceStable':pin==final,'productionReads':0,'productionWrites':0,
        'realPlatformCliCloudModelOrSendingCalls':0,'scope':'Actual Runtime snapshot/resume/page loop and F104 controller on temp SQLite; synthetic page transport and paused analysis.'}
    (OUT/(tag+'.json')).write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n','utf-8')
    print(log.getvalue());print(json.dumps(report,ensure_ascii=False));raise SystemExit(0 if passed else 1)
