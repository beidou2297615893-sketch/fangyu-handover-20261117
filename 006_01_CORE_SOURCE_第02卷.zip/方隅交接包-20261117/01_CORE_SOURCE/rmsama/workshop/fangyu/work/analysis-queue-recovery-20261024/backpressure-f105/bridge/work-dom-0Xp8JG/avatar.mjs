// Only the exact saved-media route is fetched. Portraits are never guessed.
const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const FALLBACK='/assets/approved-icon-user-round.svg',COVER='/assets/tabler-external-link.svg';
function initials(person){
  const letter=[...String(person?.name||'').trim()][0]||'客';
  return 'data:image/svg+xml,'+encodeURIComponent(`<svg xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 64 64"><rect width="64" height="64" rx="16" fill="#edf2f6"/><text x="32" y="42" text-anchor="middle" font-family="Microsoft YaHei,sans-serif" font-size="28" fill="#648098">${esc(letter)}</text></svg>`);
}
function savedMediaUrl(value,kinds){
  if(typeof value!=='string'||value.length>2048||/[\s\u0000-\u001f\u007f]/.test(value))return '';
  try{
    const url=new URL(value,location.origin),keys=[...url.searchParams.keys()];
    if(url.origin!==location.origin||url.pathname!=='/api/workbench/media'||url.hash||url.username||url.password
      ||keys.length!==3||new Set(keys).size!==3||keys.some(key=>!['storeId','leadId','kind'].includes(key))
      ||!kinds.includes(url.searchParams.get('kind'))||!(/^[A-Za-z0-9_-]{1,80}$/).test(url.searchParams.get('storeId')||'')
      ||!(/^(?:[a-f0-9]{32}|[a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12})$/i).test(url.searchParams.get('leadId')||''))return '';
    return url.pathname+url.search;
  }catch{return '';}
}
let mediaScope='',generation=0,observer=null,running=0,totalBytes=0;
const cache=new Map(),pending=new Map(),queue=[],failures=new Map(),controllers=new Set(),retryTimers=new Set();
const MAX_BYTES=8*1024*1024,MAX_ITEMS=240,MAX_AGE=30*60*1000;
export function setCustomerMediaScope(value){
  const next=String(value||'');if(next===mediaScope)return;
  mediaScope=next;generation++;observer?.disconnect();
  for(const controller of controllers)controller.abort();controllers.clear();
  for(const timer of retryTimers)clearTimeout(timer);retryTimers.clear();
  for(const job of queue)job.resolve('');
  cache.clear();failures.clear();pending.clear();queue.length=0;totalBytes=0;
}
function cachedUrl(key){
  const entry=cache.get(key);if(!entry)return '';
  if(Date.now()-entry.at>MAX_AGE){cache.delete(key);totalBytes-=entry.size;return '';}
  cache.delete(key);cache.set(key,entry);return entry.url;
}
export function customerAvatarUrl(value){return savedMediaUrl(value,['author','post_author']);}
export function postCover(person,cls='',style=''){
  const url=savedMediaUrl(person?.coverUrl,['cover']);
  const ready=url&&cachedUrl(url);
  return `<img class="${cls}"${style?` style="${style}"`:''} src="${ready||COVER}" alt="${ready?'原帖图片':url?'原帖图片加载中':'原帖未保存图片'}" loading="lazy" decoding="async" referrerpolicy="no-referrer" data-post-cover${url?` data-saved-media="${esc(url)}" data-cover-remote`:''}>`;
}
export function customerAvatar(person,cls='',style=''){
  const url=customerAvatarUrl(person?.avatarUrl);
  const ready=url&&cachedUrl(url);
  return `<img class="${cls}"${style?` style="${style}"`:''} src="${ready||initials(person)}" alt="${ready?'已保存的客户头像':esc((person?.name||'客户')+'的头像')}" loading="lazy" decoding="async" referrerpolicy="no-referrer" data-customer-avatar${url?` data-saved-media="${esc(url)}" data-avatar-remote`:''}>`;
}
function remember(key,url){
  const entry={url,size:url.length,at:Date.now()};cache.set(key,entry);totalBytes+=entry.size;
  while(cache.size>MAX_ITEMS||totalBytes>MAX_BYTES){const [old,value]=cache.entries().next().value;cache.delete(old);totalBytes-=value.size;}
  return cache.get(key)?.url||'';
}
function pump(){
  while(running<3&&queue.length){
    const job=queue.shift();if(job.generation!==generation||!job.alive.some(check=>check())){pending.delete(job.key);job.resolve('');continue;}
    running++;
    (async()=>{
      // Include the backend's queue wait plus fetch budget. Avatar preloads
      // share its existing disk cache and never block the business response.
      const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),18000);controllers.add(controller);
      try{
        const response=await fetch(job.key,{credentials:'same-origin',cache:'no-store',signal:controller.signal});
        if(!response.ok||!/^image\/(?:png|jpeg|webp)(?:;|$)/i.test(response.headers.get('content-type')||''))throw new Error('saved image unavailable');
        const blob=await response.blob();if(!blob.size||blob.size>3*1024*1024)throw new Error('saved image unavailable');
        if(job.generation!==generation)return '';
        const url=await new Promise((resolve,reject)=>{const reader=new FileReader();reader.onload=()=>resolve(reader.result);reader.onerror=reject;reader.readAsDataURL(blob);});
        if(job.generation!==generation||typeof url!=='string'||!/^data:image\/(?:png|jpeg|webp);base64,/i.test(url))return '';
        return remember(job.key,url);
      }catch{if(job.generation===generation){failures.set(job.key,Date.now());while(failures.size>MAX_ITEMS)failures.delete(failures.keys().next().value);}return '';}
      finally{clearTimeout(timer);controllers.delete(controller);}
    })().then(job.resolve).finally(()=>{if(pending.get(job.key)?.promise===job.promise)pending.delete(job.key);running--;pump();});
  }
}
function request(key,alive,priority=0){
  if(!mediaScope)return Promise.resolve('');
  const ready=cachedUrl(key);if(ready)return Promise.resolve(ready);
  if(Date.now()-(failures.get(key)||0)<300000)return Promise.resolve('');
  if(pending.has(key)){const job=pending.get(key);job.alive.push(alive);return job.promise;}
  let resolve;const promise=new Promise(done=>resolve=done),job={key,generation,resolve,promise,alive:[alive],priority};pending.set(key,job);
  queue.push(job);queue.sort((a,b)=>a.priority-b.priority);pump();return promise;
}
// Data prefetch, independent of the current DOM/page. Only media routes
// returned by the already authorized customer response enter this queue.
export function warmCustomerMedia(items,scope=mediaScope){
  // Keep offscreen media out of the foreground business-read path. The
  // visible-image observer below owns bounded, deduplicated requests.
  return Promise.resolve([]);
}
export function bindCustomerAvatars(root){
  observer?.disconnect();const boundGeneration=generation;
  if(!mediaScope)return;
  const load=(image,attempt=0)=>{
    observer?.unobserve(image);const key=image.dataset.savedMedia;if(!key)return;
    const alive=()=>image.isConnected&&boundGeneration===generation;
    image.dataset.mediaState='loading';
    request(key,alive,image.hasAttribute('data-post-cover')?1:0).then(url=>{
      if(!alive())return;image.dataset.mediaState=url?'ready':'unavailable';
      if(url){image.src=url;image.alt=image.hasAttribute('data-post-cover')?'原帖图片':'已保存的客户头像';}
      else{
        image.alt=image.hasAttribute('data-post-cover')?'原帖图片暂不可用':'';
        // A failed saved route keeps its fallback. A redraw never schedules
        // another automatic retry; a later visible read can retry after TTL.
      }
    });
  };
  if(typeof IntersectionObserver==='function')observer=new IntersectionObserver(entries=>{for(const entry of entries)if(entry.isIntersecting)load(entry.target);},{rootMargin:'96px'});
  for(const image of root.querySelectorAll('[data-saved-media]')){
    if(cache.has(image.dataset.savedMedia)){load(image);continue;}
    if(observer)observer.observe(image);else load(image);
  }
}



