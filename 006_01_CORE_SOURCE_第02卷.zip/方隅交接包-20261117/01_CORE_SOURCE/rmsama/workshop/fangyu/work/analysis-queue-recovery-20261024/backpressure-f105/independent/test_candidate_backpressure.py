"""Focused independent real page-loop and unknown-ledger acceptance.
Owned Core SQLite only; no platform subprocess, cloud/model or Native actions.
"""
from pathlib import Path
from datetime import datetime,timezone
import copy,hashlib,io,json,os,socket,subprocess,sys,threading,unittest
from types import MethodType

sys.dont_write_bytecode=True
A=Path(__file__).resolve().parent;ROOT=A.parent;C=ROOT/'core'
RUNTIME=Path(os.environ.get('F105_RUNTIME',str(C/'candidate/platform_runtime.py')))
os.environ['F105_RUNTIME']=str(RUNTIME);os.environ['F105_EVIDENCE']=str(A/'fixture-evidence')
sys.path.insert(0,str(C/'tests'))
import test_backpressure as author
author.base.HERE=A
base=author.base
PIN=hashlib.sha256(RUNTIME.read_bytes()).hexdigest()
TAG=os.environ.get('F105_ACCEPTANCE_TAG','CANDIDATE-ACCEPTANCE')
snapshot=A/'source-pins'/PIN/'platform_runtime.py';snapshot.parent.mkdir(parents=True,exist_ok=True)
if not snapshot.exists():snapshot.write_bytes(RUNTIME.read_bytes())

class Independent(author.Backpressure):
    def automatic(self):
        # Persist pause through the real public action before granting the
        # workspace, avoiding an incidental consumer-start/pause fixture race.
        self.manager.execute_workspace('analysis_workspace_pause',self.user,'fixture-store',{'storeId':'fixture-store'},self.refresh,lambda task_id:self.refresh)
        self.manager.authorize_workspace(self.user,'fixture-store',self.refresh,lambda task_id:self.refresh)
        self.assertTrue(self.manager.wait_workspace_idle(3))
        notify=self.manager.notify_saved
        def observed(task_id):self.notifications.append(task_id);return notify(task_id)
        self.manager.notify_saved=observed;self.rt._analysis_queue_controller=self.manager

    def test_actual_unknown14_page_loop_advances_cursor_and_only_hands_off(self):
        original_ledger=self.ledger
        attempts=[]
        def current_ledger(*args,**kwargs):
            self.seed(9,start=8000);self.seed(5,start=8009,missing=True)
            attempts.append(self.unknown(['lead-'+str(i) for i in range(8000,8009)]))
            return original_ledger(['lead-'+str(i) for i in range(8000,8014)])
        self.ledger=current_ledger
        calls,control,old=self.run_pages(initial=250)
        self.assertEqual(len(calls),2);self.assertFalse(control['event'].is_set())
        self.assertEqual(self.core.store.get('tasks',self.task['id'])['fixture_page'],2)
        self.assertEqual(self.core.store.get(author.runtime._COLLECTION_ANALYSIS_ENTITY,self.task['id']),old)
        self.assertEqual(self.core.store.get('ai_attempts',attempts[0]['id']),attempts[0])
        self.assertGreaterEqual(len(self.notifications),3)
        self.assertTrue(self.manager.workspace['userPaused'],'collection must not resume the paused AI consumer')
        self.assertEqual(self.calls,[],'old unknown UUID or model must not be replayed')
        receipt=self.core.store.get(author.runtime._COLLECTION_RUN_ENTITY,self.task['id'])
        self.assertEqual(receipt['units'],2);self.assertEqual(receipt['stop_reason'],'range_exhausted')

    def test_cold_empty_queue_has_independent_capability_but_keeps_device_gate(self):
        self.seed(9,start=8000);self.seed(5,start=8009,missing=True)
        original=self.unknown(['lead-'+str(i) for i in range(8000,8009)])
        page=self.ledger(['lead-'+str(i) for i in range(8000,8014)])
        starts=[]
        self.rt.service.executor=None;self.rt.service.state='offline'
        self.rt.service.start=lambda:starts.append(True)
        self.rt._device=lambda actor:{'bound':True,'state':'offline','message':'synthetic connection not ready'}
        self.rt._analysis_queue_controller=self.manager
        self.manager.authorize_workspace(self.user,'fixture-store',self.refresh,lambda task_id:self.refresh)
        self.assertTrue(self.manager.wait_workspace_idle(3))
        self.assertEqual(starts,[],'empty/held-only queue must not invoke model or start collector')
        self.assertEqual(self.calls,[])
        self.rt._readiness=MethodType(author.runtime.PlatformRuntime._readiness,self.rt)
        self.rt._collection_readiness=MethodType(author.runtime.PlatformRuntime._collection_readiness,self.rt)
        value=self.snapshot()
        self.assertTrue(value['analysisDecoupled'])
        self.assertEqual(value['analysisBufferMode'],'durable_background');self.assertIsNone(value['analysisBufferLimit'])
        self.assertFalse(value['canStart']);self.assertFalse(value['canResume'])
        self.assertEqual(value['reasonCode'],'device_not_ready')
        self.assertIsNone(self.rt.service.executor)
        self.assertEqual(self.core.store.get(author.runtime._COLLECTION_ANALYSIS_ENTITY,self.task['id']),page)
        self.assertEqual(self.core.store.get('ai_attempts',original['id']),original)

    def test_present_executor_wrong_core_owner_or_user_never_grants_mode(self):
        self.automatic();self.ledger(['old-held'])
        for field,bad in (('owner','synthetic-other-owner'),('user_id','synthetic-other-user'),('core',object())):
            with self.subTest(field=field):
                original=getattr(self.executor,field)
                try:
                    setattr(self.executor,field,bad)
                    value=self.snapshot()
                    self.assertFalse(value['analysisDecoupled']);self.assertFalse(value['canStart'])
                finally:setattr(self.executor,field,original)

NAMES=['test_actual_unknown14_page_loop_advances_cursor_and_only_hands_off',
       'test_real_current_shape_old_unknown14_job19_does_not_lock_new_start',
       'test_resume_scope_mismatch_remains_rejected_before_any_task_resume',
       'test_new_start_allowed_but_old_resume_remains_closed_for_wrong_page_scope',
       'test_platform_verification_still_blocks_auto_before_next_page',
       'test_legacy_still_blocks_unknown_pending_and_keeps_200_cap']
if os.environ.get('F105_COLD_CAPABILITY')=='1':NAMES.extend(['test_cold_empty_queue_has_independent_capability_but_keeps_device_gate','test_present_executor_wrong_core_owner_or_user_never_grants_mode'])
if __name__=='__main__':
    stream=io.StringIO()
    with base.patch.object(socket.socket,'connect',base.deny),base.patch('subprocess.Popen',side_effect=base.deny):
        result=unittest.TextTestRunner(stream=stream,verbosity=2).run(unittest.TestSuite(Independent(n) for n in NAMES))
    stable=PIN==hashlib.sha256(RUNTIME.read_bytes()).hexdigest()
    report={'atUtc':datetime.now(timezone.utc).isoformat(),'passed':result.wasSuccessful() and stable,'cases':result.testsRun,
        'errors':len(result.errors),'failures':len(result.failures),'runtime':str(RUNTIME),'runtimeSha256':PIN,'sourceStable':stable,
        'formalReads':0,'formalWrites':0,'realPlatformCliCloudModelOrSendingCalls':0,'fixtureOnly':True,
        'scope':'Actual candidate Runtime snapshot/resume/bounded page loop plus actual F104 workspace controller. Real 14-ID unknown/missing ledger, cursor progress and paused analysis handoff; model/page transport synthetic.'}
    (A/(TAG+'.json')).write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n','utf-8')
    (A/(TAG+'.log')).write_text(stream.getvalue(),'utf-8')
    print(stream.getvalue());print(json.dumps(report,ensure_ascii=False));raise SystemExit(0 if report['passed'] else 1)
