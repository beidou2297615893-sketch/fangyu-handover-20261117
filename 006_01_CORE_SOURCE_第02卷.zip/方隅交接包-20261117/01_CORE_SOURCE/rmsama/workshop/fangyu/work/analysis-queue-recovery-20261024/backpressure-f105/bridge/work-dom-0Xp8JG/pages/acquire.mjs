import {helpFooter} from './acquisition-help.mjs';
import {renderFreshAcquisition,openFreshAcquisition,freshAcquisitionCapture} from './fresh-acquisition-recovery.mjs';
export {freshAcquisitionCapture,freshSourceKind,openFreshAcquisition} from './fresh-acquisition-recovery.mjs';
import {sourceSelection,renderSourceBar,bindSourceBar} from './acquisition-source.mjs';
import {renderSavedCommentAnalysis,bindSavedCommentAnalysis,savedCommentAnalysisView,analysisBufferMessage} from './saved-comment-analysis.mjs';
import {customerAvatar,bindCustomerAvatars} from '../avatar.mjs';
const escape = value => String(value ?? '').replace(/[&<>"']/g, char => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));
const asset = name => `/assets/${name}`;
const icon = (name, cls='') => `<img class="acquire-icon ${cls}" src="${asset(name)}" alt="" aria-hidden="true">`;
let progressTimer = null;

function model(state) {
  if(state.connection==='preview')state.store ||= '古北店';
  const assignedStore=state.stores?.find(item=>item.id===state.storeId);
  state.acquire ??= {region:state.connection==='preview'?'上海 · 长宁区':assignedStore?.region||'',time:'最近30天',platforms:['小红书','抖音'],status:'idle',stage:0,tick:0,read:0,added:0,analyzed:0,duplicates:0,records:[]};
  const a=state.acquire;
  if(a.run&&a.run.store!==state.store){
    if(['running','paused'].includes(a.status))a.records.unshift({text:`${a.run.store} · 已切换门店，本次演示结束`,status:'已停止'});
    Object.assign(a,{status:'idle',stage:0,tick:0,read:0,added:0,analyzed:0,duplicates:0,run:null,region:state.connection==='preview'?(state.store==='浦江店'?'上海 · 闵行区':state.store==='徐汇店'?'上海 · 徐汇区':'上海 · 长宁区'):assignedStore?.region||''});
  }
  return state.acquire;
}
const phase = a => ({idle:'待开始',running:['搜索中','读取中','分析中','即将完成'][a.stage] || '采集中',paused:'已暂停',completed:'已完成',failed:'采集已中断'})[a.status];
const selected = (value, expected) => value === expected ? ' selected' : '';
const option = (text,value) => `<option${selected(value,text)}>${escape(text)}</option>`;

function controls(state,a,locked=false,startAllowed=true,startLabel='开始获客',timeRanges,startState={}){
  const stores=state.connection==='preview'?['古北店','浦江店','徐汇店'].map(name=>({id:name,name})):state.stores||[];
  const id=state.connection==='preview'?state.store:state.storeId;
  return `<section class="acquire-card acquire-launch" aria-label="获客范围"><div class="acquire-fields">
  <label class="acquire-field"><span>门店</span><div class="acquire-select-wrap">${icon('tabler-upgrade-calendar.svg')}<select data-acquire-store aria-label="选择门店" ${locked?'disabled':''}>${!id?'<option value="">请选择门店</option>':''}${stores.map(x=>`<option value="${escape(x.id)}"${selected(id,x.id)}>${escape(x.name)}</option>`).join('')}</select></div></label>
  <div class="acquire-region" aria-label="门店区域">${icon('tabler-upgrade-pin.svg')}<span>${escape(a.region||'门店区域待配置')}</span></div>
  <label class="acquire-field"><span>帖子时间</span><div class="acquire-select-wrap">${icon('tabler-upgrade-calendar.svg')}<select data-acquire-time aria-label="选择时间范围" ${locked?'disabled':''}>${['最近90天','最近30天','最近7天'].map(x=>`<option${selected(a.time,x)}${timeRanges&&!timeRanges.includes(x)?' disabled':''}>${x}</option>`).join('')}</select></div></label>
  <button type="button" class="acquire-start" data-acquire-start aria-busy="${startState.busy===true}"${startState.reason?` title="${escape(startState.reason)}"`:''} ${startAllowed?'':'disabled'}>${icon('icon-play-filled.svg')}<span>${escape(startLabel)}</span></button></div></section>`;
}
function statusRow({status,label,message='',pause=false,resume=false,resumeLabel='继续',enabled=false,accountLink=false,reconnect=false,recover=false,recovering=false}){
  const running=['running','queued','resuming','pausing'].includes(status);
  return `<section class="acquire-card acquire-status-row ${running?'is-running':''}" data-task-status="${escape(status)}" role="status" aria-live="polite"><span class="acquire-status-icon">${icon('fy-icon-12-clock.png')}</span><div class="acquire-status-copy"><strong>${escape(label)}</strong>${message?`<span>${escape(message)}</span>`:''}</div>${recover?`<button type="button" class="acquire-link" data-acquire-recover ${recovering?'disabled aria-busy="true"':''}>${recovering?'正在检查连接…':'检查并恢复连接'}</button>`:''}${reconnect?'<button type="button" class="acquire-link" data-acquire-reconnect>重新连接</button>':''}${accountLink?'<button type="button" class="acquire-link" data-acquire-accounts>连接本店账号</button>':''}${pause||resume?`<button type="button" class="acquire-pause" data-acquire-pause ${enabled?'':'disabled'}>${icon(resume?'icon-play-filled.svg':'fy-icon-54-pause.png')}<span>${escape(resume?resumeLabel:'暂停')}</span></button>`:''}</section>`;
}
export function render(state){
  if(state.connection!=='preview')return renderConnected(state);
  const a=model(state),running=a.status==='running',resume=a.status==='paused';
  return `<div class="acquire-page" data-page-acquire>${controls(state,a,running||resume,!running,resume?'继续获客':'开始获客')}${statusRow({status:a.status,label:phase(a),pause:running,resume,enabled:true})}</div>`;
}
export function bind(root,ctx){
  if(ctx.state.connection!=='preview')return bindConnected(root,ctx);
  clearTimeout(progressTimer);const a=model(ctx.state);
  root.querySelector('[data-acquire-store]')?.addEventListener('change',e=>ctx.update(s=>{s.store=e.target.value;a.region=s.store==='浦江店'?'上海 · 闵行区':s.store==='徐汇店'?'上海 · 徐汇区':'上海 · 长宁区';}));
  root.querySelector('[data-acquire-time]')?.addEventListener('change',e=>{a.time=e.target.value;});
  root.querySelector('[data-acquire-start]')?.addEventListener('click',()=>ctx.update(()=>{a.status='running';}));
  root.querySelector('[data-acquire-pause]')?.addEventListener('click',()=>ctx.update(()=>{a.status=a.status==='running'?'paused':'running';}));
  return ()=>clearTimeout(progressTimer);
}

const count=value=>Number.isSafeInteger(value)&&value>=0?value:'—';
const livePhase=value=>({search:0,searching:0,read:1,reading:1,collect:1,collecting:1,save:2,saving:2,analyzing:2,complete:3,completed:3,finished:3})[value]??(Number.isInteger(value)&&value>=0&&value<=3?value:-1);
const liveStatus=value=>({idle:'待开始',queued:'等待执行',running:'采集中',pausing:'正在暂停',paused:'已暂停',resuming:'正在恢复',completed:'已完成',failed:'未完成',blocked:'已暂停 · 待核验',held:'已暂停 · 待核验',unconfirmed:'结果待核对',cancelled:'已取消',stopped:'已停止'})[value]||'状态待核验';
function unknownStart(state){return Boolean(state.acquisitionAttempt?.unconfirmed||['submitted','unconfirmed'].includes(state.platform?.lastRequest?.state));}
function visibleAcquisition(state,live){const last=state.platform?.lastRequest;return unknownStart(state)&&(!last?.job?.taskId||last.job.taskId!==live.taskId)?{...live,taskId:last?.job?.taskId||'',taskScope:null,status:'unconfirmed',phase:null,counts:{},records:[],canPause:false,canResume:false}:live;}
function liveModel(state){
  const store=state.stores?.find(item=>item.id===state.storeId),platforms=(state.platform?.platforms||[]).filter(row=>row.enabled);
  state.acquire??={region:store?.region||'',time:'最近30天'};
  const draft=state.acquire;draft.region??=store?.region||'';draft.time||='最近30天';
  if(unknownStart(state)){const conditions=state.acquisitionAttempt?.payload||state.platform?.lastRequest?.conditions||{};draft.region=typeof conditions.region==='string'?conditions.region:'';draft.time=typeof conditions.time==='string'?conditions.time:'';if(conditions.platform)draft.selectedPlatform=conditions.platform;}
  draft.selectedPlatform=state.activePlatform||'xiaohongshu';
  const platform=platforms.find(row=>row.id===draft.selectedPlatform);
  return {draft,store,platform,platforms,accountId:state.platformAccountSelections?.[platform?.id]||platform?.accountId||'',live:((!state.platform?.acquisition?.taskScope?.platform||state.platform.acquisition.taskScope.platform===(state.activePlatform||'xiaohongshu'))?visibleAcquisition(state,state.platform?.acquisition||{}):{status:'idle',counts:{}})};
}
const activeStatuses=['running','queued','pausing','resuming','stopping'];
const needsAcquisitionVerification=live=>!activeStatuses.includes(live.status)&&['verification_required','authentication_required'].includes(live.platformError?.category);
const currentCommentPolicy=scope=>Boolean(scope&&(scope.scope==='search_comments'||scope.scope==='comments'&&['note_links','profiles','own_interactions'].includes(scope.source?.kind)&&Number.isInteger(scope.source.count)&&scope.source.count>=1&&scope.source.count<=({note_links:100,profiles:20,own_interactions:3}[scope.source.kind]||0)&&/^[a-f0-9]{64}$/.test(scope.source.sourceDigest||''))
  &&scope.commentKeywordMode==='all'&&scope.continuousEnabled===false
  &&scope.region===''&&scope.unknownPolicy==='exclude');
const legacyTaskPolicy=live=>Boolean(live.taskScope&&!currentCommentPolicy(live.taskScope));
const canResumeTask=(state,live)=>Boolean(currentCommentPolicy(live.taskScope)&&state.storeId&&live.taskScope?.storeId===state.storeId
  &&live.taskId&&live.canResume&&['paused','stopped'].includes(live.status));
function matchesTaskScope(state,current){
  const {draft,store,platform,accountId,live}=current,scope=live.taskScope;
  const original=state.platform?.lastRequest?.job?.taskId===live.taskId?state.platform.lastRequest:null;
  if(original&&original.conditions?.expectedRevision!==state.selection?.revision)return false;
  const selectedSource=sourceSelection(state);
  const excludes=state.selection?.applied?.excludeTerms??[];
  if(!scope||!Array.isArray(excludes)||excludes.some(word=>typeof word!=='string')
    ||scope.storeId!==state.storeId||scope.platform!==platform?.id||scope.accountId!==accountId
    ||!currentCommentPolicy(scope)||(draft.region||'')!==(store?.region||'')
    ||scope.city!==(store?.city||'')||scope.area!==(store?.area||'')
    ||scope.commentDateRange!=='all'||scope.intentMode!=='all'
    ||!Array.isArray(scope.excludes)||JSON.stringify(scope.excludes)!==JSON.stringify(excludes)
    ||scope.dailyLimit!==1000||scope.targetCount!==1000)return false;
  if(scope.source){return !selectedSource||Boolean(selectedSource.source)&&selectedSource.preview?.sourceDigest===scope.source.sourceDigest;}
  if(selectedSource?.source)return false;
  const words=Array.isArray(original?.keywordBatch)?original.keywordBatch:state.selection?.applied?.selectedKeywords;
  const days={'最近3天':3,'最近7天':7,'最近30天':30,'最近90天':90}[draft.time];
  if(!days||!Array.isArray(words)||!words.length||words.some(word=>typeof word!=='string'))return false;
  const keywords=[...new Set(words.map(word=>word.trim()))];
  const today=new Date(Date.now()+8*60*60*1000).toISOString().slice(0,10);
  const from=new Date(Date.parse(today+'T00:00:00Z')-(days-1)*86400000).toISOString().slice(0,10);
  return scope.dateFrom===from&&scope.dateTo===today
    &&JSON.stringify(scope.keywords)===JSON.stringify(keywords)&&scope.scope==='search_comments';
}
function taskCaption(state,live){
  const scope=live.taskScope,platform={xiaohongshu:'小红书',douyin:'抖音'}[scope?.platform]||'原平台';
  const store=state.stores?.find(row=>row.id===scope?.storeId)?.name||'原门店';
  const date=/^\d{4}-\d{2}-\d{2}$/;
  const time=scope&&date.test(scope.dateFrom)&&date.test(scope.dateTo)?`${scope.dateFrom} 至 ${scope.dateTo}`
    :scope&&scope.dateFrom===''&&scope.dateTo===''?'全部时间':'原时间条件';
  return `${platform} · ${store} · ${time}`;
}
function recentPeople(state){const live=visibleAcquisition(state,state.platform?.acquisition||{});return live.status==='unconfirmed'?[]:Array.isArray(live.recent)?live.recent:[];}
export function renderAcquisitionProgress(state,live,now=Date.now()){
  const p=state.platform;
  if(!state.session||p?.actor?.username!==state.user||p.actor.storeId!==state.storeId)return '';
  const scoped=live.taskScope?.storeId===state.storeId&&(!live.taskScope.platform||live.taskScope.platform===(state.activePlatform||'xiaohongshu'));
  if(live.taskId&&!scoped)return '';
  const observation=live.observation||{},category=live.platformError?.category,active=activeStatuses.includes(live.status),verification=live.verification?.state;
  let stage=live.phase,title=({preparing:'正在准备采集',search:'正在搜索帖子',searching:'正在搜索帖子',read:'正在读取评论',reading:'正在读取评论',reading_comments:'正在读取评论',reading_sub_comments:'正在读取评论',collecting:'正在读取评论',filtering:'正在整理评论',analyzing:'正在分析意向',saving:'正在保存评论',waiting:'短暂等待，随后继续读取'})[stage]||liveStatus(live.status);
  let message=active?'按批次循环；评论读取和意向分析可以并行进行。':live.message||'请选择门店与账号后开始。';
  if(!active){
    if(['verification_required','authentication_required'].includes(category)){
      title=verification==='verifying'?'正在核对验证结果':verification==='resuming'?'正在恢复原任务':'等待你完成验证';
      message=live.verification?.message||'原评论和断点已保留，请在原采集账号网页完成本人验证。';stage='verification';
    }else if(category){title=({platform_rejected:'平台暂未允许读取',rate_limited:'平台限制读取频率，已暂停',transport_error:'网络请求未完成，已暂停',compatibility_error:'读取接口需要检查',protocol_error:'读取结果待核对'})[category]||'读取未完成，已保留断点';message=live.message||'查看账号提示后再处理；不会自动重发原请求。';stage='paused';}
    else if(live.status==='paused'){title='采集已暂停';stage='paused';}
  }
  const bufferMessage=analysisBufferMessage(state,live);if(bufferMessage){title='采集缓冲已暂停';message=bufferMessage;stage='paused';}
  const operation=state.pendingAction?.action;
  if(state.deviceReconnecting||state.busy&&operation==='platform_prepare'){title='正在恢复工作连接';message='核对当前员工电脑连接，保留已有平台登录。';stage='preparing';}
  else if(state.busy&&['acquisition_start','acquisition_resume'].includes(operation)){title=operation==='acquisition_start'?'正在提交采集任务':'正在恢复原任务';message='等待后台回执，请勿重复开始。';stage='preparing';}
  const parsed=value=>{const stamp=Date.parse(value);return Number.isFinite(stamp)?stamp:null;};
  const observed=typeof state.platformUpdatedAt==='number'?state.platformUpdatedAt:parsed(observation.observedAt);
  const stale=Boolean(state.platformError||observed!==null&&observed!==undefined&&now-observed>20000);
  const format=value=>{const stamp=parsed(value);return stamp===null?'尚未返回':new Intl.DateTimeFormat('zh-CN',{timeZone:'Asia/Shanghai',hour:'2-digit',minute:'2-digit',second:'2-digit',hour12:false}).format(stamp);};
  const wait=parsed(observation.nextReadAt),remaining=wait===null?null:Math.max(0,Math.ceil((wait-now)/1000));
  if(active&&stage==='waiting')message=remaining>0?`约 ${remaining} 秒后继续；这段等待可随时暂停。`:'正在等待后台确认下一次读取；不会自动重发失败请求。';
  const old=parsed(observation.progressAt),quiet=active&&old!==null&&now-old>120000;
  const account=scoped?p.accounts?.find(row=>row.id===live.taskScope.accountId):null;
  const canVerify=!active&&live.taskId&&['verification_required','authentication_required'].includes(category)&&(state.activePlatform||'xiaohongshu')==='xiaohongshu';
  const notice=stale?'状态暂未更新，以下为上次结果，请刷新核对。':quiet?'暂未有新进展，可刷新状态查看。':canVerify?'请在原账号网页完成验证。':category?'已保留采集进度，请按上方提示处理。':bufferMessage?bufferMessage:live.analysis?.hold?`原分析请求待核对；${active?'新评论仍会保存。':live.canResume===true?'原评论已保留，可继续原任务采集。':'原任务与待核评论已保留，不能直接继续；当前条件就绪后可另开新采集。'}`:'';
  const detailBody=`${message?`<p class="acquire-runflow-message">${escape(message)}</p>`:''}<div class="acquire-runflow-meta"><span>待分析 ${count(savedCommentAnalysisView(state,live.taskId)?.counts.pending)} 条 · 原请求待核 ${count(savedCommentAnalysisView(state,live.taskId)?.counts.held)} 条</span>${Number.isSafeInteger(observation.confirmedPages)?`<span>已读取 ${observation.confirmedPages} 页</span>`:''}<span>最后进展 ${escape(format(observation.progressAt))}</span><span>状态更新 ${observed?escape(format(new Date(observed).toISOString())):'尚未返回'}</span></div>${scoped&&live.taskId?renderTaskExecution(state,live):''}`;
  return `<section class="acquire-card acquire-runflow" aria-label="当前采集进度"><div class="acquire-runflow-heading"><div><span>当前采集进度</span><strong role="status" aria-live="polite">${escape(title)}</strong></div><button type="button" class="acquire-link" data-acquire-flow-refresh ${state.busy?'disabled':''}>刷新状态</button></div><div class="acquire-runflow-counts"><span>已保存评论 <b>${count(live.counts?.added)}</b></span><span>已分析 <b>${count(live.counts?.analyzed)}</b></span>${account?`<span class="acquire-runflow-account">采集账号：<strong>${escape(account.name||'尚未返回')}</strong></span>`:''}</div>${notice?`<p class="acquire-runflow-warning" role="status">${escape(notice)}</p>`:''}${live.taskId?`<details class="acquire-runflow-details" data-acquire-progress-details${state.acquire?.progressDetailsOpen?' open':''}><summary>查看详情</summary>${detailBody}</details>`:''}</section>`;
}
export function renderTaskExecution(state,live={}){
  const scope=live.taskScope;
  if(!live.taskId||!scope||scope.storeId!==state.storeId)return '<section class="acquire-execution" aria-label="当前任务执行范围"><strong>当前任务执行范围</strong><p>当前门店暂无已核对的任务条件；词库总量不代表已执行词。</p></section>';
  const words=value=>Array.isArray(value)?value.filter(v=>typeof v==='string').map(escape).join('、'):'';
  const analysis=live.analysis||{},queue=savedCommentAnalysisView(state,live.taskId),pending=count(queue?.counts.pending);
  const analysisStatus={running:'意向分析中',queued:'等待意向分析',pending:'等待意向分析',paused:'意向分析已暂停',blocked:'意向分析受阻',completed:'本批分析已结束',succeeded:'本批分析已结束',failed:'本批分析未完成',unknown:'分析结果待核对'}[analysis.status]||'分析状态未返回';
  const analysisReason={AI_INVALID_OUTPUT:'本批分析尚未完整确认',AI_DISABLED:'企业 AI 未启用',AI_NOT_CONFIGURED:'企业 AI 尚未配置',AI_BILLING_UNKNOWN:'原分析请求结果未确认，不会自动重复提交',verification_required:'平台要求重新验证登录'}[analysis.code]||(analysis.code?'本批分析状态待核对':'');
  const time=scope.dateFrom&&scope.dateTo?`${escape(scope.dateFrom)} 至 ${escape(scope.dateTo)}`:scope.dateFrom===''&&scope.dateTo===''?'全部时间':'未返回';
  return `<section class="acquire-execution" aria-label="当前任务执行范围"><strong>当前任务执行范围</strong><dl><dt>搜帖词</dt><dd>${words(scope.keywords)||'未返回'}</dd><dt>任务排除词</dt><dd>${Array.isArray(scope.excludes)?words(scope.excludes)||'未设置':'未返回'}</dd><dt>帖子日期</dt><dd>${time} · 评论范围：${scope.source?'按原任务冻结范围（检查新增不会更改）':scope.commentDateRange==='all'?'全部时间':'按原任务条件'}</dd><dt>任务目标 / 日上限</dt><dd>${count(scope.targetCount)} / ${count(scope.dailyLimit)}</dd><dt>本店后台待分析 / 原请求待核</dt><dd>${pending} / ${count(queue?.counts.held)} · ${queue?escape(queue.running?'正在分析已保存评论':queue.message):'请刷新上方分析状态'}</dd><dt>原任务模型记录</dt><dd>${analysis.provider||analysis.model?escape([analysis.provider,analysis.model].filter(Boolean).join(' · ')):'尚未返回模型来源；不能把本机判断或历史评级当成本批 AI 结果'}</dd></dl><p>以上来自已保存任务条件，不表示每个词已搜索完成；待分析数使用后台回执，模型来源不代表真实调用成功。</p></section>`;
}
function renderConnected(state){
  const current=liveModel(state),{draft,live}=current,status=live.status||'idle';
  const unconfirmed=unknownStart(state),locked=state.busy||state.connectionRecovering||unconfirmed||Boolean(state.sourceInteractionPending)||activeStatuses.includes(status),taskResume=!unconfirmed&&canResumeTask(state,live),resume=taskResume&&matchesTaskScope(state,current);
  const ready=Boolean(current.platform&&current.accountId),fresh=freshAcquisitionCapture(state),newAccount=fresh?.transition==='different_account';
  const selectedSource=sourceSelection(state),sourceBlocked=Boolean(selectedSource?.source&&selectedSource.preview?.canStart!==true);
  const canStart=!state.busy&&!state.connectionRecovering&&!state.sourceInteractionPending&&(unconfirmed||(!state.platformError&&ready&&(resume||Boolean(fresh)||(!locked&&live.canStart!==false))));
  const pauseUnknown=unconfirmed&&state.platform?.lastRequest?.job?.taskId&&live.canPause;
  const failure=['failed','blocked','held','unconfirmed','paused'].includes(status)||state.platformError;
  const blocked=!state.busy&&!unconfirmed&&!resume&&!activeStatuses.includes(status)&&live.canStart===false&&!fresh;
  const accountLink=blocked&&live.reasonCode==='account_not_ready';
  const recover=Boolean(state.platformError||state.connectionRecovering);
  const reconnect=!recover&&blocked&&!state.deviceReconnecting&&state.platform?.device?.bound===true&&['offline','stopped','error'].includes(state.platform.device.state);
  const switching=state.busy&&Boolean(state.storeSwitchTarget);
  const platformName={xiaohongshu:'小红书',douyin:'抖音'}[state.activePlatform||'xiaohongshu'];
  let message=state.sourceInteractionPending?'原互动检查结果待核对，请在来源栏核对原任务；不会重复开始。':state.connectionRecovering?'正在检查软件与工作连接，核对原任务；不会重复开始采集。':state.deviceReconnecting?'正在恢复已有工作连接，无需重新登录平台账号。':switching?'正在加载所选门店的搜索词和平台账号状态。':state.connectionRecoveryMessage||state.platformError
    ||(newAccount?'原任务已保留。可使用上方已选账号按当前条件新建采集，客户与评论统一保存。':blocked||failure?state.deviceReconnectError||live.message||'当前暂不能开始，请在账号页查看连接状态。':activeStatuses.includes(status)?'可切换回复、客户查看，采集会在后台继续；本次门店和条件已锁定。':'');
  const bufferMessage=analysisBufferMessage(state,live);if(bufferMessage&&!state.busy&&!state.platformError&&!state.connectionRecovering)message=bufferMessage;
  const label=state.sourceInteractionPending?'互动检查待核对':state.connectionRecovering?'正在检查连接':state.platformError?'连接状态暂不可用':state.deviceReconnecting?'正在恢复工作连接':switching?'正在切换门店':state.platformLoading&&!state.platform?'正在读取当前门店状态'
    :newAccount?'已选账号可新建采集':blocked?(reconnect?'工作连接未恢复':accountLink?`本店${platformName}账号未连接`:'暂不能开始')
    :live.platformError?.category==='verification_required'?'上次读取需要网页验证':live.platformError?.category==='platform_rejected'?'平台暂未允许继续读取':live.phase==='analyzing'&&status==='running'?'正在分析':liveStatus(status);
  const analysisReview=['AI_INVALID_OUTPUT','AI_BILLING_UNKNOWN','AI_PROVIDER_TIMEOUT','PRODUCT_REQUEST_UNKNOWN'].includes(live.analysis?.code);
  const verificationRequired=['verification_required','authentication_required'].includes(live.platformError?.category);
  const resumeLabel=unconfirmed?'核对采集状态':verificationRequired?'打开原账号验证':live.analysis?.hold?'继续采集':analysisReview?'核对分析并继续':'继续获客';
  const startLabel=state.busy?(switching?'切换门店中…':'处理中…'):unconfirmed?'核对采集状态':newAccount?'使用当前账号获客':resume?resumeLabel
    :activeStatuses.includes(status)?liveStatus(status):status==='completed'?'再次获客':'开始获客';
  return `<div class="acquire-page" data-page-acquire>${controls(state,draft,locked,canStart&&!sourceBlocked,startLabel,state.platform?.capabilities?.timeRanges||[],{busy:state.busy||state.connectionRecovering,reason:sourceBlocked?selectedSource.preview?.message:message})}${renderSourceBar(state,locked)}${statusRow({status,label,message,accountLink,reconnect,recover,recovering:state.connectionRecovering||state.busy,pause:Boolean(live.canPause||pauseUnknown),resume:Boolean(taskResume||pauseUnknown),resumeLabel,enabled:!state.busy&&!state.connectionRecovering&&!state.sourceInteractionPending&&(unconfirmed?pauseUnknown:live.canPause||taskResume)})}${renderSavedCommentAnalysis(state)}${renderFreshAcquisition(state)}${renderAcquisitionProgress(state,live)}${helpFooter(['verification_required','authentication_required'].includes(live.platformError?.category))}</div>`;
}
function bindConnected(root,ctx){
  const closeSavedAnalysis=bindSavedCommentAnalysis(root,ctx);
  bindSourceBar(root,ctx);
  bindCustomerAvatars(root);
  clearTimeout(progressTimer);progressTimer=null;
  const {state}=ctx,{draft,live,platforms}=liveModel(state);
  const progressDetails=root.querySelector('[data-acquire-progress-details]');
  progressDetails?.addEventListener('toggle',()=>{state.acquire??={};state.acquire.progressDetailsOpen=progressDetails.open;});
  root.querySelector('[data-acquire-store]')?.addEventListener('change',event=>{if(event.target.value)ctx.actions.selectStore(event.target.value);});
  root.querySelector('[data-acquire-region]')?.addEventListener('change',event=>ctx.update(s=>{s.acquire.region=event.target.value;}));
  root.querySelector('[data-acquire-time]')?.addEventListener('change',event=>{
    const next=event.target.value,previous=draft.time;event.target.value=previous;if(next===previous)return;
    ctx.modal({title:'切换帖子时间？',html:`<p>从 <strong>${escape(previous)}</strong> 切换为 <strong>${escape(next)}</strong>。</p><p>全部已选搜索词将使用新的帖子时间范围，搜索词本身不变。</p><p>对下一次新建任务生效；继续原暂停任务时仍沿用原条件。</p>`,confirmLabel:'确认切换',onConfirm:()=>{if(state.busy||activeStatuses.includes(liveModel(state).live.status))return false;ctx.update(s=>{s.acquire.time=next;});}});
  });
  root.querySelector('[data-acquire-fresh]')?.addEventListener('click',()=>openFreshAcquisition(ctx));
  root.querySelector('[data-acquire-reconnect]')?.addEventListener('click',()=>ctx.actions.preparePlatform?.({existingOnly:true}));
  root.querySelector('[data-acquire-recover]')?.addEventListener('click',()=>ctx.actions.recoverConnection?.());
  root.querySelector('[data-acquire-flow-refresh]')?.addEventListener('click',()=>ctx.actions.refreshPlatform?.({manual:true}));
  root.querySelector('[data-acquire-verify]')?.addEventListener('click',()=>ctx.actions.verifyBlockedAcquisition?.());
  root.querySelector('[data-acquire-presets]')?.addEventListener('click',()=>ctx.navigate('presets'));
  root.querySelector('[data-acquire-accounts]')?.addEventListener('click',()=>ctx.navigate('accounts'));
  root.querySelector('[data-acquire-customers]')?.addEventListener('click',()=>ctx.navigate('customers'));
  root.querySelector('[data-acquire-platform]')?.addEventListener('click',()=>ctx.modal({title:'选择获客平台',html:`<div class="acquire-platform-options">${platforms.map(row=>`<label><input type="radio" name="live-acquire-platform" value="${escape(row.id)}" ${draft.selectedPlatform===row.id?'checked':''}> ${escape(row.name)}</label>`).join('')||'<p>当前企业尚未开通采集平台。</p>'}</div><p class="modal-note">仅使用当前门店已授权并核验的平台账号。</p>`,confirmLabel:'确认选择',onConfirm:()=>{const value=document.querySelector('input[name="live-acquire-platform"]:checked')?.value;if(!value)return false;ctx.update(s=>{s.acquire.selectedPlatform=value;});}}));
  root.querySelector('[data-acquire-start]')?.addEventListener('click',()=>{
    if(state.busy||state.connectionRecovering)return;
    if(unknownStart(state))return ctx.actions.verifyAcquisition?.();
    const current=liveModel(state);
    if(needsAcquisitionVerification(current.live))return ctx.actions.verifyBlockedAcquisition?.();
    if(state.platformError)return;
    if(canResumeTask(state,current.live)&&matchesTaskScope(state,current))return ctx.actions.resumeAcquisition?.(current.live.taskId);
    if(freshAcquisitionCapture(state))return openFreshAcquisition(ctx);
    if(activeStatuses.includes(current.live.status)||current.live.canStart===false)return;
    return ctx.actions.startAcquisition?.();
  });
  root.querySelector('[data-acquire-pause]')?.addEventListener('click',()=>{
    if(state.busy)return;
    const current=liveModel(state),live=current.live;
    if(unknownStart(state))return ctx.actions.verifyAcquisition?.();
    if(needsAcquisitionVerification(live))return ctx.actions.verifyBlockedAcquisition?.();
    if(!canResumeTask(state,live))return live.canPause?ctx.actions.pauseAcquisition?.(live.taskId):undefined;
    if(matchesTaskScope(state,current))return ctx.actions.resumeAcquisition?.(live.taskId);
    const taskId=live.taskId,actor=JSON.stringify([state.user,state.storeId]),scope=JSON.stringify(live.taskScope);
    return ctx.modal({title:'继续原任务',html:`<p>${escape(taskCaption(state,live))}</p>`,confirmLabel:'继续原任务',onConfirm:()=>{
      const fresh=liveModel(state).live;
      if(state.busy||unknownStart(state)||actor!==JSON.stringify([state.user,state.storeId])
          ||fresh.taskId!==taskId||!canResumeTask(state,fresh)||JSON.stringify(fresh.taskScope)!==scope)return false;
      if(needsAcquisitionVerification(fresh))return ctx.actions.verifyBlockedAcquisition?.();
      return ctx.actions.resumeAcquisition?.(taskId);
    }});
  });
  root.querySelector('[data-acquire-records]')?.addEventListener('click',()=>ctx.modal({title:'采集记录',html:`<div class="acquire-records"><p>${escape(taskCaption(state,live))}</p><div class="acquire-record-summary"><strong>${escape(liveStatus(live.status))}</strong><span>本次已读 ${count(live.counts?.read)} · 新增入库 ${count(live.counts?.added)} · 已分析 ${count(live.counts?.analyzed)} · 重复 ${count(live.counts?.duplicates)}</span></div>${(Array.isArray(live.records)?live.records:[]).map(record=>`<div class="acquire-record-row"><span>${escape(record.text||record.message||'')}</span><b>${escape(record.status||'')}</b></div>`).join('')||'<p class="modal-note">当前没有可显示的真实采集记录。</p>'}</div>`,confirmLabel:'刷新状态',onConfirm:async()=>{await ctx.actions.refreshPlatform();return false;}}));
  for(const button of root.querySelectorAll('[data-live-acquire-person]'))button.onclick=()=>{const person=recentPeople(state)[Number(button.dataset.liveAcquirePerson)];if(person)ctx.modal({title:person.name||person.authorName||'采集结果',html:`<p>${escape(person.copy||person.text||person.content||'暂无正文')}</p><p class="muted">${escape(person.intent||person.level||'尚未分析')}</p>`});};
  return ()=>{closeSavedAnalysis();clearTimeout(progressTimer);progressTimer=null;};
}
