// A bounded, per-login display cache. Never persists customer data or write receipts.
const READS=new Set(['customers','customer_detail','reply_read']);
export function isCustomerReadUnavailable(error){
  const status=error?.httpStatus;
  if(['timeout','connection_failed'].includes(error?.code))return status===undefined||status>=500;
  return status===503&&['AUTH_SERVICE_UNAVAILABLE','CUSTOMERS_UNAVAILABLE','CLOUD_SERVICE_UNAVAILABLE'].includes(error?.code);
}
const PRIVATE_FIELDS=new Set(['csrfToken','session','receipt','draft','pendingRequestId','pending','delivery','authorization','review_account_id','reviewCurrent','canSave','canReview','accounts']);
const clone=value=>value==null?value:JSON.parse(JSON.stringify(value));
const stable=value=>JSON.stringify(Object.fromEntries(Object.entries(value||{}).filter(([,v])=>v!==undefined).sort(([a],[b])=>a.localeCompare(b))));
function displayOnly(value){
  if(Array.isArray(value))return value.map(displayOnly);
  if(!value||typeof value!=='object')return value;
  const out={};
  for(const [key,item]of Object.entries(value))if(!PRIVATE_FIELDS.has(key))out[key]=displayOnly(item);
  return out;
}
export function createCustomerReadCache({maxEntries=80,maxBytes=4*1024*1024,maxAgeMs=300000,now=Date.now}={}){
  let scope='',epoch=0,bytes=0;
  const entries=new Map(),flights=new Map();
  const key=(action,data)=>READS.has(action)&&scope?scope+'|'+action+'|'+stable(data):'';
  function invalidate(){epoch++;entries.clear();flights.clear();bytes=0;}
  function setScope(next){next=typeof next==='string'?next:'';if(next!==scope){invalidate();scope=next;}}
  function peek(action,data){
    const id=key(action,data),entry=entries.get(id);if(!entry)return null;
    if(now()-entry.at>maxAgeMs){entries.delete(id);bytes-=entry.size;return null;}
    entries.delete(id);entries.set(id,entry);return clone(entry.value);
  }
  async function read(action,data,load){
    const id=key(action,data),generation=epoch;
    if(!id)return load();
    if(flights.has(id))return clone(await flights.get(id));
    const promise=Promise.resolve().then(load).then(result=>{
      if(generation!==epoch||id!==key(action,data)){const error=new Error('员工、门店或平台已变化，请重新读取。');error.code='AUTH_SCOPE_CHANGED';throw error;}
      let value=displayOnly(result);
      if(action==='reply_read'&&value?.replyWorkspace){
        value.replyWorkspace.comments=(value.replyWorkspace.comments||[]).map(row=>({...row,canSave:false,canReview:false,reviewCurrent:false,accounts:[]}));
      }
      const size=JSON.stringify(value).length*2;
      const previous=entries.get(id);if(previous){bytes-=previous.size;entries.delete(id);}
      if(size<=maxBytes&&maxEntries>0){
        entries.set(id,{value,at:now(),size});bytes+=size;
        while(entries.size>maxEntries||bytes>maxBytes){const oldest=entries.keys().next().value;bytes-=entries.get(oldest).size;entries.delete(oldest);}
      }
      return result;
    }).finally(()=>{if(flights.get(id)===promise)flights.delete(id);});
    if(flights.size<maxEntries)flights.set(id,promise);
    return clone(await promise);
  }
  return {peek,read,invalidate,setScope};
}
