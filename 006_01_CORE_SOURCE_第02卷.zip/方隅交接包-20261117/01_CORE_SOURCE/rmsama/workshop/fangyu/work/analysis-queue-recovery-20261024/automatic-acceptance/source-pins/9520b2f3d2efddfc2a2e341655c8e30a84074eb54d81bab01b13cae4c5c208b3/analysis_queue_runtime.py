"""Saved-comment analysis, independent of collection and page selection.

Only a trusted authenticated workspace hook starts the automatic director.
Construction/read never authorizes work. Original workflow/attempt policy stays
responsible for budgets, billing uncertainty, validation and result CAS.
"""
from copy import copy, deepcopy
from datetime import datetime, timezone
import hashlib
import json
import re
import threading
import time
from uuid import uuid4

from assistant.ai_attempts import _digest
from assistant.ai_workflow import LocalAIWorkflow, post_identity

ACTIONS=frozenset(('analysis_queue_read','analysis_queue_resume','analysis_queue_pause'))
WORKSPACE_ACTIONS=frozenset(('analysis_workspace_read','analysis_workspace_resume','analysis_workspace_pause'))
WORKSPACE_ENTITY='ui_analysis_workspace_preferences_v1'
ENTITY='ui_task_analysis_control_v1'
PENDING_ENTITY='workbench_collection_page_analysis_v1'
UNRESOLVED=frozenset(('unknown','submitted','response_received'))
PHASES=frozenset(('scope_check','original_request_status','ai_profile','intent_analyze','ai_attempt_status'))
KEY=re.compile(r'[A-Za-z0-9_-]{1,160}\Z')
ACTOR_FIELDS=('id','tenant_id','username','role','cloud_bound')
_CORE_GATE_INIT=threading.Lock()
# Match Python str.strip used by original needs/analysis selection. SQLite's
# default trim removes only ASCII spaces and would misreport blank imports.
_SQL_WS='char(9)||char(10)||char(11)||char(12)||char(13)||char(28)||char(29)||char(30)||char(31)||char(32)||char(133)||char(160)||char(5760)||'+('||'.join('char('+str(v)+')' for v in range(8192,8203)))+'||char(8232)||char(8233)||char(8239)||char(8287)||char(12288)'
_HAS_TEXT="typeof(json_extract(l.body,'$.text'))='text' AND length(trim(json_extract(l.body,'$.text'),"+_SQL_WS+"))>0"

class AnalysisQueueError(ValueError):
    def __init__(self,code,message,status=409):
        super().__init__(message);self.code,self.status=code,status

def fail(code,message,status=409):raise AnalysisQueueError(code,message,status)
def stamp():return datetime.now(timezone.utc).isoformat()

def _legacy_status_unavailable(error):
    """Only the documented closed original-status extension's HTTP503.

    The existing transport retains HTTPError as context for AI errors instead
    of copying its status. Inspect numbers only, never its response body.
    """
    if getattr(error,'code',None)!='AI_LEGACY_EXTENSIONS_DISABLED':return False
    statuses=[];current=error
    for _ in range(4):
        if current is None:break
        statuses.extend(value for field in ('http_status','status','code')
            if type(value:=getattr(current,field,None)) is int)
        current=getattr(current,'__context__',None)
    return bool(statuses) and all(status==503 for status in statuses)

def _safe_phase(value):return value if isinstance(value,str) and value in PHASES else ''

class AnalysisQueueRuntime:
    def __init__(self,runtime,*,workflow_factory=None):
        if runtime is None:fail('ANALYSIS_RUNTIME_REQUIRED','分析服务尚未就绪',503)
        self.runtime,self.core=runtime,runtime.core
        self.workflow_factory=workflow_factory or LocalAIWorkflow
        self.lock=threading.RLock();self.active=None;self.closed=False;self.authorizations={};self.workspace=None
        self.workspace_counts_cache={}
        # Logout/store switch may replace the controller while an old request is
        # still returning. Keep one model worker on this Core across that change.
        with _CORE_GATE_INIT:
            gate=getattr(self.core,'_saved_comment_analysis_gate',None)
            if gate is None:
                gate=threading.Lock();self.core._saved_comment_analysis_gate=gate
            self.worker_gate=gate

    def close(self):
        # May be called while Backend/Core locks are held. Never join here.
        with self.lock:
            self.closed=True
            self.authorizations.clear()
            if self.workspace:self.workspace['stop'].set();self.workspace['wake'].set()
            if self.active:self.active['stop'].set();self.active['wake'].set()

    def wait_for_idle(self,seconds=0):
        """Test/controlled teardown seam; never called by normal close/logout."""
        with self.lock:
            threads={item.get('thread') for item in (self.active,self.workspace) if item and item.get('thread')}
        for thread in threads:
            if thread is not threading.current_thread():thread.join(seconds)
        return not any(thread.is_alive() for thread in threads)

    def wait_workspace_idle(self,seconds=0):
        """Isolated-test seam. The dormant director itself remains alive."""
        until=time.monotonic()+seconds
        while True:
            with self.lock:
                workspace=self.workspace
                idle=not workspace or workspace['status'] in ('waiting','paused','blocked')
                active=bool(self.active and self.active.get('working'))
            if idle and not active:return True
            if time.monotonic()>=until:return False
            time.sleep(.01)

    @staticmethod
    def _workspace_key(user,store_id,refresh):
        return tuple(user.get(k) for k in ACTOR_FIELDS)+(store_id,getattr(refresh,'session_key',None))

    def authorize_workspace(self,user,store_id,refreshWorkspace,refreshTaskFactory):
        """Trusted Backend login/store hook: RAM and signal only, never I/O.

        Fresh model guards re-enter this hook through Backend identity. Re-entry
        must not restart the director, clear pause/block, or self-wake it.
        """
        if (self.closed or not isinstance(user,dict) or user.get('cloud_bound') is not True
                or user.get('role') not in ('operator','admin') or not all(user.get(k) for k in ('id','tenant_id','username'))
                or not isinstance(store_id,str) or not KEY.fullmatch(store_id)
                or not callable(refreshWorkspace) or not callable(refreshTaskFactory)):
            fail('ANALYSIS_AUTH_CHANGED','自动分析需要当前员工和门店授权',403)
        key=self._workspace_key(user,store_id,refreshWorkspace)
        with self.lock:
            previous=self.workspace
            if previous and previous['key']==key and not previous['stop'].is_set():
                previous.update(user=deepcopy(user),refresh=refreshWorkspace,factory=refreshTaskFactory)
                return self
            if previous:previous['stop'].set();previous['wake'].set()
            if self.active:self.active['stop'].set();self.active['wake'].set()
            self.authorizations.clear()
            grant={'key':key,'user':deepcopy(user),'storeId':store_id,'refresh':refreshWorkspace,'factory':refreshTaskFactory,
                'stop':threading.Event(),'wake':threading.Event(),'status':'starting','code':'','phase':'',
                'userPaused':False,'loaded':False,'skipped':{},'requestId':uuid4().hex}
            self.workspace=grant
            thread=threading.Thread(target=self._workspace_loop,args=(grant,),name='saved-comment-workspace-analysis',daemon=True)
            grant['thread']=thread;grant['wake'].set();thread.start()
        return self

    def _workspace_check(self,user,store_id,refresh,*,fresh=False,analyzing=False,require_runtime=True):
        if self.closed or getattr(self.runtime,'closed',False):fail('ANALYSIS_CLOSED','自动分析已停止',503)
        current,profile=refresh(fresh=fresh)
        if (not isinstance(current,dict) or not isinstance(profile,dict)
                or any(current.get(k)!=user.get(k) for k in ACTOR_FIELDS)
                or current.get('cloud_bound') is not True or current.get('role') not in ('operator','admin')):
            fail('ANALYSIS_AUTH_CHANGED','员工身份已变化，自动分析已停止',403)
        if profile.get('_workbench_store_id',profile.get('store_id'))!=store_id:
            fail('ANALYSIS_SCOPE_CHANGED','当前门店已变化，自动分析已停止',403)
        executor=getattr(getattr(self.runtime,'service',None),'executor',None)
        with self.core.lock:
            saved=self.core.store.get('users',current.get('id'))
            if (not saved or saved.get('disabled') or any(saved.get(k)!=current.get(k) for k in ACTOR_FIELDS)
                    or require_runtime and (executor is None or getattr(executor,'core',None) is not self.core
                        or getattr(executor,'tenant',None)!=current['tenant_id']
                        or getattr(executor,'owner',None)!=current['username'] or getattr(executor,'user_id',None)!=current['id'])):
                fail('ANALYSIS_AUTH_CHANGED','当前登录或分析服务归属已变化',403)
            if analyzing and any(value.get('can_analyze') is False for value in (current,profile,saved)):
                fail('ANALYSIS_PERMISSION_DENIED','当前员工没有分析权限',403)
            if analyzing and executor is not None:executor._require_product_feature('intent_analysis')
        return current

    def _workspace_ready(self,workspace):
        """Start only the existing bound explicit-local assistant in background.

        Unlike platform.prepare this never configures/downloads a CLI, pairs an
        account, resumes collection, or enables global AIWorker/commands.
        """
        service=getattr(self.runtime,'service',None)
        if getattr(service,'executor',None) is not None:return
        device=self.runtime._device(workspace['user'])
        if device.get('state')=='other_owner' or device.get('bound') is not True:
            fail('ANALYSIS_DEVICE_UNAVAILABLE','请核对当前员工的电脑绑定；原评论保留',403)
        if getattr(service,'explicit_local',False) is not True or getattr(service,'manual_owned_read_start',False) is True:
            fail('ANALYSIS_RUNTIME_REQUIRED','当前分析连接模式尚未核实',503)
        service.start();self.runtime.started=True
        until=time.monotonic()+30
        while not workspace['stop'].is_set() and not workspace['userPaused']:
            if getattr(service,'executor',None) is not None and service.state in ('online','held'):return
            if service.state=='revoked':fail('ANALYSIS_AUTH_CHANGED','设备授权已撤回，自动分析已停止',403)
            if getattr(service,'closed',False) or service.state in ('error','stopped') or time.monotonic()>=until:
                fail('ANALYSIS_RUNTIME_REQUIRED','分析连接尚未就绪；原评论保留',503)
            workspace['stop'].wait(.05)
        fail('ANALYSIS_QUEUE_PAUSED','自动分析已暂停，原评论保留')

    def _workspace_pref_id(self,user,store_id):return _digest([user['tenant_id'],user['id'],store_id])

    def _workspace_pref(self,user,store_id):
        return self.core.store.get(WORKSPACE_ENTITY,self._workspace_pref_id(user,store_id)) or {}

    def _workspace_save_pref(self,workspace):
        user=workspace['user']
        self.core.store.put(WORKSPACE_ENTITY,{'id':self._workspace_pref_id(user,workspace['storeId']),
            'tenant_id':user['tenant_id'],'owner':user['username'],'storeId':workspace['storeId'],
            'userPaused':workspace['userPaused'],'blockedCode':workspace.get('blockedCode',''),
            'blockedPhase':_safe_phase(workspace.get('blockedPhase','')),'updated_at':stamp()})

    @staticmethod
    def _workspace_sql(*,point=False):
        # Both aliases stay tenant-scoped. Only projected IDs/fields are read;
        # the director does not decode the global lead history into memory.
        index='sqlite_autoindex_records_1' if point else 'scope'
        return 'FROM records AS l INDEXED BY '+index+"""
            JOIN records AS t ON t.entity='tasks' AND t.id=json_extract(l.body,'$.task_id') AND t.tenant_id=l.tenant_id
            WHERE l.entity='leads' AND l.tenant_id=?
            AND json_extract(t.body,'$.cloud_owner')=? AND json_extract(t.body,'$.store_id')=?
            AND json_extract(t.body,'$.platform') IN ('xiaohongshu','douyin')
            AND (json_extract(l.body,'$.cloud_owner') IS NULL OR json_extract(l.body,'$.cloud_owner') IN ('',?))
            AND coalesce(json_extract(l.body,'$.demo'),0)=0"""

    def _workspace_candidates(self,user,store_id):
        sql="""SELECT t.id AS task_id,count(*) AS size,max(l.rowid) AS revision """+self._workspace_sql()+"""
            AND coalesce(json_extract(l.body,'$.manual_intent'),'') IN ('','{}','[]',0)
            AND coalesce(json_extract(l.body,'$.ai_intent'),'') IN ('','{}','[]',0)
            AND """+_HAS_TEXT+" GROUP BY t.id ORDER BY t.id"
        with self.core.store.connect() as db:
            cursor=db.execute(sql,(user['tenant_id'],user['username'],store_id,user['username']))
            projected=[]
            while True:
                rows=cursor.fetchmany(64)
                if not rows:break
                projected.extend((row['task_id'],(row['size'],row['revision'])) for row in rows)
        return projected

    def _workspace_count_result(self,db,counts,user,store_id,batch):
        if batch is None:return dict(counts)
        actual=0
        ids=batch.get('ids') if isinstance(batch,dict) else None
        request=batch.get('requestId') if isinstance(batch,dict) else None
        submission=batch.get('submissionId') if isinstance(batch,dict) else None
        if (isinstance(ids,tuple) and 0<len(ids)<=20 and isinstance(request,str) and isinstance(submission,str)
                and re.fullmatch(r'[a-f0-9-]{36}',request) and re.fullmatch(r'[a-f0-9-]{36}',submission)):
            attempts=db.execute("""SELECT json_extract(body,'$.lead_digests') AS digests FROM records INDEXED BY scope
                WHERE entity='ai_attempts' AND tenant_id=? AND json_extract(body,'$.owner')=?
                AND json_extract(body,'$.operation')='intent_analyze'
                AND json_extract(body,'$.request_id')=? AND json_extract(body,'$.submission_id')=?
                AND json_extract(body,'$.state') IN ('submitted','response_received') LIMIT 2""",
                (user['tenant_id'],user['username'],request,submission)).fetchall()
            if len(attempts)==1:
                digests=json.loads(attempts[0]['digests'] or '[]')
                digests=set(digests) if isinstance(digests,list) else set()
                sql='SELECT l.id AS current_id '+self._workspace_sql(point=True)+" AND l.id IN ("+','.join('?' for _ in ids)+")"+"""
                    AND coalesce(json_extract(l.body,'$.manual_intent'),'') IN ('','{}','[]',0)
                    AND coalesce(json_extract(l.body,'$.ai_intent'),'') IN ('','{}','[]',0) AND """+_HAS_TEXT
                for row in db.execute(sql,(user['tenant_id'],user['username'],store_id,user['username'],*ids)):
                    if _digest([user['tenant_id'],user['username'],row['current_id']]) in digests:actual+=1
        # No cached phase/working flag or guessed batch size is trusted. Both
        # quantities were observed in the same RO transaction; malformed input
        # cannot manufacture negative held counts.
        if actual>counts['held']:actual=0
        return dict(counts),actual

    def _workspace_counts(self,user,store_id,revision_provider=None,*,processing=None):
        counts=dict(total=0,pending=0,held=0,analyzed=0,missingText=0)
        with self.core.store.connect() as db:
            db.execute('BEGIN')
            cache_key=None
            if callable(revision_provider):
                # The injected existing CustomerReadStore validates its exact
                # durable schema. No migrations or data_version approximation.
                try:
                    token=revision_provider(db,user,store_id)
                    durable=(isinstance(token,tuple) and len(token)==3 and isinstance(token[2],tuple)
                        and token[2] and token[2][0]=='durable-v1')
                    if durable:
                        attempts=db.execute("""SELECT count(*),coalesce(max(rowid),0),
                            coalesce(sum(json_extract(body,'$.state')='submitted'),0),
                            coalesce(sum(json_extract(body,'$.state')='response_received'),0),
                            coalesce(sum(json_extract(body,'$.state')='unknown'),0)
                            FROM records INDEXED BY scope WHERE entity='ai_attempts' AND tenant_id=?""",(user['tenant_id'],)).fetchone()
                        # Attempts are intentionally absent from customer-read
                        # business revision. Registration replaces rows, while
                        # LocalAIAttempts transitions use UPDATE without changing
                        # rowid. The three state counts cover those transitions.
                        cache_key=tuple(user.get(k) for k in ACTOR_FIELDS)+(store_id,token,tuple(attempts))
                        hash(cache_key)
                except Exception:cache_key=None
                if cache_key is not None:
                    with self.lock:cached=self.workspace_counts_cache.get(cache_key)
                    if cached is not None:return self._workspace_count_result(db,cached,user,store_id,processing)
            held=set()
            cursor=db.execute("""SELECT json_extract(body,'$.lead_digests') AS digests FROM records INDEXED BY scope
                WHERE entity='ai_attempts' AND tenant_id=? AND json_extract(body,'$.owner')=?
                AND json_extract(body,'$.operation')='intent_analyze'
                AND json_extract(body,'$.state') IN ('unknown','submitted','response_received')""",(user['tenant_id'],user['username']))
            for row in cursor:
                values=json.loads(row['digests'] or '[]')
                if isinstance(values,list):held.update(value for value in values if isinstance(value,str))
            cursor=db.execute("""SELECT l.id AS id,
                coalesce(json_extract(l.body,'$.manual_intent'),'') NOT IN ('','{}','[]',0) AS has_manual,
                json_type(l.body,'$.manual_intent') AS manual_type,
                json_extract(l.body,'$.manual_intent.status') AS manual_status,json_extract(l.body,'$.manual_intent.level') AS manual_level,
                coalesce(json_extract(l.body,'$.ai_intent'),'') NOT IN ('','{}','[]',0) AS has_ai,
                json_type(l.body,'$.ai_intent') AS ai_type,
                json_extract(l.body,'$.ai_intent.status') AS ai_status,json_extract(l.body,'$.ai_intent.level') AS ai_level,
                """+_HAS_TEXT+" AS has_text "
                +self._workspace_sql(),(user['tenant_id'],user['username'],store_id,user['username']))
            while True:
                rows=cursor.fetchmany(128)
                if not rows:break
                for row in rows:
                    counts['total']+=1
                    field='manual' if row['has_manual'] else 'ai'
                    has_value=bool(row['has_manual'] or row['has_ai'])
                    value={'status':row[field+'_status'],'level':row[field+'_level']} if has_value and row[field+'_type']=='object' else None
                    if self._confirmed(value):counts['analyzed']+=1
                    elif has_value or _digest([user['tenant_id'],user['username'],row['id']]) in held:counts['held']+=1
                    elif not row['has_text']:counts['missingText']+=1
                    else:counts['pending']+=1
            if cache_key is not None:
                with self.lock:
                    if len(self.workspace_counts_cache)>=8:self.workspace_counts_cache.clear()
                    self.workspace_counts_cache[cache_key]=dict(counts)
            return self._workspace_count_result(db,counts,user,store_id,processing)

    def _workspace_snapshot(self,user,store_id,refresh=None):
        with self.lock:
            workspace=self.workspace
            if refresh is None and workspace and workspace['storeId']==store_id:refresh=workspace['refresh']
            same=bool(workspace and workspace['key'][:len(ACTOR_FIELDS)]==tuple(user.get(k) for k in ACTOR_FIELDS)
                and workspace['storeId']==store_id and not workspace['stop'].is_set())
            run=self.active
            running=bool(same and run and run.get('workspace') is workspace and run.get('working')
                and run['status']=='running' and run.get('thread') and run['thread'].is_alive() and not run['stop'].is_set())
            batch=dict(run.get('processingBatch') or {}) if running else {}
            counts,processing=self._workspace_counts(user,store_id,getattr(refresh,'local_revision',None),processing=batch)
            counts={**counts,'held':counts['held']-processing,'processing':processing}
            pref={} if same and workspace['loaded'] else self._workspace_pref(user,store_id)
            paused=workspace['userPaused'] if same and workspace['loaded'] else pref.get('userPaused') is True
            code=workspace.get('blockedCode','') if same and workspace['loaded'] else pref.get('blockedCode','')
            code=code if isinstance(code,str) and re.fullmatch(r'[A-Z_]{1,80}',code) else ''
            phase=_safe_phase(workspace.get('phase','') if same else pref.get('blockedPhase',''))
            status='paused' if paused else 'blocked' if code else 'running' if running else workspace['status'] if same else 'idle'
            if status=='waiting':status='held' if counts['held'] and not counts['pending'] else 'waiting'
            active_id=run['taskId'] if running else ''
            ident=run['requestId'] if running else workspace['requestId'] if same else ''
            if running:phase=_safe_phase(run.get('phase',''))
        message=('正在自动分析本门店已保存的评论；暂停采集不影响分析' if running else
            '自动分析已暂停，已有结果和原评论保留' if paused else
            '自动分析已停止，请核对权限、预算或原请求；不会自动重复提交' if code else
            '可分析评论已处理，原请求待核与缺正文记录继续保留' if not counts['pending'] and (counts['held'] or counts['missingText']) else
            '自动分析已开启，正在等待已保存的新评论' if not counts['pending'] else
            '自动分析已开启，将按当前门店依次处理已保存的评论')
        if code=='AI_LEGACY_EXTENSIONS_DISABLED':message='企业AI旧接口停用，未取得本批新分析结果，原评论保留。'
        return {'actor':{'username':user['username'],'storeId':store_id},'taskId':'workspace','automatic':True,
            'automaticEnabled':not paused,'autoEnabled':not paused,'autoPaused':paused,'remaining':counts['pending']+processing,
            'processing':processing,
            'activeTaskId':active_id,'status':status,'running':running,'counts':counts,'canResume':paused or bool(code),
            'canPause':same and not paused,'message':message,'requestId':ident,'code':'ANALYSIS_QUEUE_PAUSED' if paused else code,
            'phase':phase,'heldStatusCode':''}

    def execute_workspace(self,action,user,store_id,data,refreshWorkspace,refreshTaskFactory):
        if (action not in WORKSPACE_ACTIONS or not isinstance(data,dict) or set(data)!={'storeId'} or data['storeId']!=store_id
                or not isinstance(store_id,str) or not KEY.fullmatch(store_id)
                or not callable(refreshWorkspace) or not callable(refreshTaskFactory)):
            fail('ANALYSIS_INPUT_INVALID','请选择当前授权门店',400)
        current=self._workspace_check(user,store_id,refreshWorkspace,
            fresh=action=='analysis_workspace_resume',analyzing=action=='analysis_workspace_resume',require_runtime=False)
        if action=='analysis_workspace_read':return self._workspace_snapshot(current,store_id,refreshWorkspace)
        if action=='analysis_workspace_resume':self.authorize_workspace(current,store_id,refreshWorkspace,refreshTaskFactory)
        with self.lock:
            workspace=self.workspace
            if not workspace or workspace['key']!=self._workspace_key(current,store_id,refreshWorkspace):
                # Pause remains useful before a cold bootstrap has established a
                # director. It records only the authenticated current preference.
                workspace={'user':current,'storeId':store_id,'userPaused':True}
                self._workspace_save_pref(workspace)
            else:
                if not workspace['loaded']:
                    pref=self._workspace_pref(current,store_id)
                    workspace.update(userPaused=pref.get('userPaused') is True,blockedCode=pref.get('blockedCode',''),loaded=True)
                workspace['userPaused']=action=='analysis_workspace_pause'
                if action=='analysis_workspace_resume':workspace.update(blockedCode='',blockedPhase='',code='',status='starting',skipped={})
                else:workspace['status']='paused'
                self._workspace_save_pref(workspace)
                run=self.active
                if run and run.get('workspace') is workspace and workspace['userPaused']:run['stop'].set();run['wake'].set()
                workspace['wake'].set()
        return {**self._workspace_snapshot(current,store_id,refreshWorkspace),'accepted':True}

    def _workspace_loop(self,workspace):
        while not workspace['stop'].is_set():
            workspace['wake'].clear()
            try:
                with self.lock:
                    if self.workspace is not workspace:return
                    if not workspace['loaded']:
                        pref=self._workspace_pref(workspace['user'],workspace['storeId'])
                        workspace.update(userPaused=pref.get('userPaused') is True,blockedCode=pref.get('blockedCode',''),
                            blockedPhase=_safe_phase(pref.get('blockedPhase','')),loaded=True)
                    paused=workspace['userPaused'];blocked=workspace.get('blockedCode','')
                    workspace['status']='paused' if paused else 'blocked' if blocked else 'scanning'
                if not paused and not blocked:self._workspace_drain(workspace)
                with self.lock:
                    if workspace['status'] not in ('blocked','paused'):workspace['status']='waiting'
            except Exception as error:
                code=getattr(error,'code',None)
                if not isinstance(code,str) or not re.fullmatch(r'[A-Z_]{1,80}',code):code='ANALYSIS_UNAVAILABLE'
                with self.lock:
                    if self.workspace is workspace and not workspace['stop'].is_set() and not workspace['userPaused']:
                        workspace.update(blockedCode=code,blockedPhase='scope_check',phase='scope_check',status='blocked')
                        try:self._workspace_save_pref(workspace)
                        except Exception:pass
            workspace['wake'].wait(10)

    def _workspace_drain(self,workspace):
        current=self._workspace_check(workspace['user'],workspace['storeId'],workspace['refresh'],analyzing=True,require_runtime=False)
        revision_provider=getattr(workspace['refresh'],'local_revision',None)
        # The same existing durable business revision avoids even the candidate
        # JSON scan on an unchanged empty/held-only workspace.
        if callable(revision_provider) and not self._workspace_counts(current,workspace['storeId'],revision_provider)['pending']:return
        candidates=self._workspace_candidates(current,workspace['storeId'])
        candidates=[pair for pair in candidates if workspace['skipped'].get(pair[0])!=pair[1]]
        if not candidates:return
        if getattr(self.runtime.service,'executor',None) is None:
            if not self._workspace_counts(current,workspace['storeId'])['pending']:
                workspace['skipped'].update(candidates);return
            self._workspace_check(current,workspace['storeId'],workspace['refresh'],fresh=True,analyzing=True,require_runtime=False)
            self._workspace_ready(workspace)
        for task_id,revision in candidates:
            if workspace['stop'].is_set() or workspace['userPaused'] or self.workspace is not workspace:return
            refresh=workspace['factory'](task_id)
            user,task,executor,scope=self._scope(current,workspace['storeId'],task_id,refresh,analyzing=True)
            counts,_,_=self._inventory(user,task,executor)
            if not counts['pending']:
                workspace['skipped'][task_id]=revision;continue
            # Held-only tasks never invoke freshness. An expired idle snapshot
            # is renewed only when new processable work actually exists.
            self._workspace_check(current,workspace['storeId'],workspace['refresh'],fresh=True,analyzing=True)
            user,task,executor,scope=self._scope(current,workspace['storeId'],task_id,refresh,analyzing=True)
            run={'user':deepcopy(user),'storeId':workspace['storeId'],'taskId':task_id,'scope':scope,'refresh':refresh,
                'stop':threading.Event(),'wake':threading.Event(),'requestId':uuid4().hex,'status':'running',
                'code':'','phase':'scope_check','working':True,'collection':False,'thread':threading.current_thread(),
                'workspace':workspace}
            with self.lock:
                if workspace['stop'].is_set() or workspace['userPaused'] or self.workspace is not workspace:return
                self.active=run;workspace['status']='running'
            self._record(run,'running');self._work(run)
            with self.lock:
                run['working']=False;workspace['phase']=_safe_phase(run.get('phase',''))
                if workspace['stop'].is_set() or self.workspace is not workspace or workspace['userPaused']:return
                if run['status'] in ('blocked','paused'):
                    workspace.update(blockedCode=run['code'] or 'ANALYSIS_UNAVAILABLE',blockedPhase=workspace['phase'],status='blocked')
                    self._workspace_save_pref(workspace);return

    def _scope(self,user,store_id,task_id,refresh,*,expected=None,analyzing=False,local_only=False,fresh=False):
        if self.closed or getattr(self.runtime,'closed',False):
            fail('ANALYSIS_CLOSED','本次分析已停止，请重新读取',503)
        current,profile=(dict(user),{'_workbench_store_id':store_id}) if local_only else refresh(fresh=fresh)
        if (not isinstance(current,dict) or not isinstance(profile,dict)
                or any(current.get(k)!=user.get(k) for k in ACTOR_FIELDS)
                or current.get('cloud_bound') is not True or current.get('role') not in ('operator','admin')):
            fail('ANALYSIS_AUTH_CHANGED','员工身份已变化，本次分析已停止',403)
        if profile.get('_workbench_store_id',profile.get('store_id'))!=store_id:
            fail('ANALYSIS_SCOPE_CHANGED','当前门店已变化，本次分析已停止',403)
        if analyzing and (current.get('can_analyze') is False or profile.get('can_analyze') is False):
            fail('ANALYSIS_PERMISSION_DENIED','当前员工没有分析权限',403)
        executor=getattr(getattr(self.runtime,'service',None),'executor',None)
        if executor is None or getattr(executor,'core',None) is not self.core:
            fail('ANALYSIS_RUNTIME_REQUIRED','原分析服务尚未就绪，请重新连接工作台',503)
        with self.core.lock:
            saved=self.core.store.get('users',current.get('id'))
            if (not saved or saved.get('disabled') or any(saved.get(k)!=current.get(k) for k in ACTOR_FIELDS)):
                fail('ANALYSIS_AUTH_CHANGED','员工登录已变化，本次分析已停止',403)
            if analyzing and saved.get('can_analyze') is False:
                fail('ANALYSIS_PERMISSION_DENIED','当前员工没有分析权限',403)
            task=self.core.store.get('tasks',task_id)
            if (not task or task.get('tenant_id')!=current['tenant_id']
                    or task.get('cloud_owner')!=current['username'] or task.get('store_id')!=store_id
                    or task.get('platform') not in ('xiaohongshu','douyin')
                    or getattr(executor,'tenant',None)!=current['tenant_id']
                    or getattr(executor,'owner',None)!=current['username']
                    or getattr(executor,'user_id',None)!=current['id']):
                fail('ANALYSIS_SCOPE_CHANGED','只能分析当前门店中本人的原采集任务',403)
            self.core._task_access(current,task,current['tenant_id'])
            account=self.core.store.get('accounts',task.get('account_id'))
            if (not account or account.get('tenant_id')!=current['tenant_id']
                    or account.get('cloud_owner')!=current['username'] or account.get('store_id')!=store_id
                    or account.get('platform')!=task.get('platform')):
                fail('ANALYSIS_SCOPE_CHANGED','原任务账号归属已变化，本次分析已停止',403)
            binding=self.runtime._collection_binding(task)
            # Collection status/counters/captcha are intentionally absent.
            scope={'actor':{k:current.get(k) for k in ACTOR_FIELDS},'storeId':store_id,'taskId':task_id,
                'binding':deepcopy(binding),'company':_digest(executor.server.company),
                'host':_digest(executor.ai.attempts.host_context())}
            if expected is not None and scope!=expected:
                fail('ANALYSIS_SCOPE_CHANGED','原任务、企业配置或设备范围已变化，本次分析已停止',403)
            if analyzing:executor._require_product_feature('intent_analysis')
        return current,task,executor,scope

    def authorize_collection(self,user,store_id,task_id,refresh):
        """Only the synchronous explicit start/resume hook may register this.

        No refresh callback, worker, cloud or model runs in this method.
        """
        with self.lock:workspace=self.workspace
        automatic_scope=bool(workspace and not workspace['stop'].is_set() and workspace['storeId']==store_id
            and all(workspace['user'].get(k)==user.get(k) for k in ACTOR_FIELDS))
        # Collection and analysis entitlements are independent. An automatic
        # queue pause/budget hold must not prohibit an otherwise allowed page
        # save; the original collector still enforces collect access/backlog.
        current,task,executor,scope=self._scope(user,store_id,task_id,refresh,analyzing=not automatic_scope,local_only=True)
        with self.lock:
            workspace=self.workspace
            if (workspace and not workspace['stop'].is_set() and workspace['storeId']==store_id
                    and all(workspace['user'].get(k)==current.get(k) for k in ACTOR_FIELDS)):
                # The same director owns all saved pages in this workspace.
                # Starting collection for another task must not compete with it.
                return self
            active=self.active
            if active and active.get('thread') and active['thread'].is_alive() and active['scope']!=scope:
                if not self._retire_dormant(active):
                    fail('ANALYSIS_QUEUE_BUSY','原任务的分析尚未结束，请先暂停分析',409)
            self.authorizations[task_id]={'user':deepcopy(current),'storeId':store_id,'taskId':task_id,
                'scope':scope,'refresh':refresh,'blocked':False}
        return self

    def _retire_dormant(self,run):
        if run.get('working') or run['status'] not in ('completed','held'):return False
        run['retired']=True;run['stop'].set();run['wake'].set()
        grant=self.authorizations.get(run['taskId'])
        if grant:grant['blocked']=True
        return True

    def owns_collection(self,task_id):
        with self.lock:
            workspace=self.workspace
            if self.closed:return False
            if task_id in self.authorizations:return True
        if workspace and not workspace['stop'].is_set():
            try:
                self._scope(workspace['user'],workspace['storeId'],task_id,None,local_only=True)
                return True
            except Exception:return False
        return False

    def collection_state(self,task_id):
        """Local backpressure observation only; no identity/cloud/provider read."""
        with self.lock:
            run=self.active
            if not run or run['taskId']!=task_id:return 'idle'
            return 'running' if run.get('working') and run.get('thread') and run['thread'].is_alive() else run['status']

    def _launch(self,grant,*,collection=False):
        run={**grant,'stop':threading.Event(),'wake':threading.Event(),'requestId':uuid4().hex,
            'status':'running','code':'','phase':'scope_check','working':True,'collection':collection}
        self.active=run;self._record(run,'running')
        thread=threading.Thread(target=self._work,args=(run,),name='explicit-task-analysis-'+run['taskId'],daemon=True)
        run['thread']=thread
        try:thread.start()
        except BaseException:
            self._record(run,'blocked','ANALYSIS_START_UNCONFIRMED');raise
        return run

    def notify_saved(self,task_id):
        """Signal an authorized workspace, or a legacy explicit task grant."""
        with self.lock:workspace=self.workspace
        if workspace and not workspace['stop'].is_set():
            if not self.owns_collection(task_id):return False
            with self.lock:
                if self.workspace is not workspace:return False
                workspace['skipped'].pop(task_id,None);workspace['wake'].set();return True
        with self.lock:
            grant=self.authorizations.get(task_id)
            if self.closed or not grant or grant.get('blocked'):return False
            active=self.active
            if active and active.get('thread') and active['thread'].is_alive():
                if active['scope']!=grant['scope']:
                    if not active.get('retired'):return False
                else:
                    active['working']=True;active['wake'].set();return True
            self._launch(grant,collection=True)
            return True

    def _guard(self,run,*,fresh=False):
        if run['stop'].is_set():fail('ANALYSIS_QUEUE_PAUSED','本人已暂停分析；已有结果保留')
        value=self._scope(run['user'],run['storeId'],run['taskId'],run['refresh'],expected=run['scope'],analyzing=True,fresh=fresh)
        if run['stop'].is_set():fail('ANALYSIS_QUEUE_PAUSED','本人已暂停分析；已有结果保留')
        return value

    @staticmethod
    def _confirmed(value):
        return isinstance(value,dict) and value.get('status') in ('graded','uncertain','unrelated') and (
            value.get('level') in ('super_high','high','medium','low','very_low') if value['status']=='graded' else value.get('level') is None)

    def _inventory(self,user,task,executor):
        with self.core.lock:
            reader=getattr(self.core.store,'list_task_leads',None)
            rows=reader(user['tenant_id'],task['id']) if callable(reader) else self.core.store.list('leads',user['tenant_id'])
            rows=list(executor._analysis_visible_leads(user,task,rows=rows))
            rows=[row for row in rows if row.get('task_id')==task['id'] and not row.get('demo')]
            attempts=[row for row in self.core.store.list('ai_attempts',user['tenant_id'])
                if row.get('owner')==user['username'] and row.get('operation')=='intent_analyze' and row.get('state') in UNRESOLVED]
            held_hashes=set().union(*(set(row.get('lead_digests') or []) for row in attempts)) if attempts else set()
            counts=dict(total=len(rows),pending=0,held=0,analyzed=0,missingText=0)
            pending=[];held_ids=set()
            for row in rows:
                value=row.get('manual_intent') or row.get('ai_intent')
                if self._confirmed(value):counts['analyzed']+=1
                elif row.get('manual_intent') or row.get('ai_intent'):
                    counts['held']+=1;held_ids.add(row['id'])
                elif _digest([user['tenant_id'],user['username'],row['id']]) in held_hashes:
                    counts['held']+=1;held_ids.add(row['id'])
                elif not isinstance(row.get('text'),str) or not row['text'].strip():counts['missingText']+=1
                else:counts['pending']+=1;pending.append(row)
            matching=[row for row in attempts if any(_digest([user['tenant_id'],user['username'],ident]) in set(row.get('lead_digests') or []) for ident in held_ids)]
            return counts,pending,matching

    def _record_id(self,user,store_id,task_id):return _digest([user['tenant_id'],user['id'],store_id,task_id])

    def _dispatch_batch_guard(self,user,task,executor,ids,payload):
        """Do not mistake this workflow's just-registered attempt for old hold."""
        with self.core.lock:
            rows=[self.core.store.get('leads',ident) for ident in ids]
            rows=list(executor._analysis_visible_leads(user,task,rows=[row for row in rows if row]))
            if ({row['id'] for row in rows}!=ids or any(row.get('ai_intent') or row.get('manual_intent')
                    or not isinstance(row.get('text'),str) or not row['text'].strip() for row in rows)):
                fail('ANALYSIS_SCOPE_CHANGED','本批原评论或已有判断已变化，未重新提交',409)
            hashes={_digest([user['tenant_id'],user['username'],ident]) for ident in ids}
            for row in self.core.store.list('ai_attempts',user['tenant_id']):
                if (row.get('owner')!=user['username'] or row.get('state') not in UNRESOLVED
                        or not hashes.intersection(row.get('lead_digests') or [])):continue
                own_submission=(row.get('state')=='submitted' and payload.get('request_id')
                    and row.get('request_id')==payload.get('request_id')
                    and payload.get('submission_id') and row.get('submission_id')==payload.get('submission_id'))
                if not own_submission:
                    fail('PRODUCT_REQUEST_UNKNOWN','本批原评论已有待核请求，未重新提交',409)

    def _record(self,run,status,code=''):
        row={'id':self._record_id(run['user'],run['storeId'],run['taskId']),'tenant_id':run['user']['tenant_id'],
            'owner':run['user']['username'],'userId':run['user']['id'],'storeId':run['storeId'],'taskId':run['taskId'],
            'requestId':run['requestId'],'status':status,'code':code,'phase':_safe_phase(run.get('phase','scope_check')),
            'heldStatusCode':run.get('heldStatusCode',''),'updated_at':stamp()}
        self.core.store.put(ENTITY,row)
        with self.lock:run['status'],run['code']=status,code

    def _phase(self,run,phase):
        if not _safe_phase(phase):
            fail('ANALYSIS_PHASE_INVALID','分析阶段尚未核实',409)
        with self.lock:run['phase']=phase
        self._record(run,run['status'],run.get('code',''))

    def _snapshot(self,user,store_id,task,executor):
        counts,_,_=self._inventory(user,task,executor)
        with self.lock:
            run=self.active
            same=bool(run and run['taskId']==task['id'] and run['storeId']==store_id and run['user']['id']==user['id'])
            thread_alive=bool(same and run.get('thread') and run['thread'].is_alive())
            running=bool(thread_alive and run.get('working',True))
            saved=self.core.store.get(ENTITY,self._record_id(user,store_id,task['id'])) or {}
            status=run['status'] if same else saved.get('status','idle')
            code=run['code'] if same else saved.get('code','')
            phase=_safe_phase(run.get('phase','scope_check') if same else saved.get('phase',''))
            held_status_code=run.get('heldStatusCode','') if same else saved.get('heldStatusCode','')
            held_status_code='AI_LEGACY_EXTENSIONS_DISABLED' if held_status_code=='AI_LEGACY_EXTENSIONS_DISABLED' else ''
            ident=run['requestId'] if same else saved.get('requestId','')
            if not running and status=='running':status='paused';code='ANALYSIS_AUTH_EXPIRED'
            if not running and status not in ('paused','blocked'):
                status='held' if not counts['pending'] and counts['held'] else 'completed' if not counts['pending'] and not counts['held'] else 'idle'
        message=('正在分析已保存评论；采集暂停不影响本次分析' if running else
            '原请求结果仍待核对，已保留；没有重复分析这些评论' if status=='held' else
            '可分析评论已处理，缺正文记录仍保留待核实' if status=='completed' and counts['missingText'] else
            '已保存的可分析评论已处理' if status=='completed' else
            '分析已停止，原评论与已有判断保持；请核对后手动继续' if status in ('paused','blocked') else
            '只分析本任务已保存评论；不会开始采集或发送回复')
        if code=='AI_LEGACY_EXTENSIONS_DISABLED':
            message='企业AI旧接口停用，未取得本批新分析结果，原评论保留。'
        elif held_status_code=='AI_LEGACY_EXTENSIONS_DISABLED':
            message+='；原请求核对接口暂不可用，待核评论与原请求继续保留。'
        return {'actor':{'username':user['username'],'storeId':store_id},'taskId':task['id'],'status':status,'running':running,
            'counts':counts,'canResume':not running and (counts['pending']>0 or counts['held']>0),
            'canPause':thread_alive,'message':message,'requestId':ident,'code':code,
            'phase':phase,'heldStatusCode':held_status_code}

    def execute(self,action,user,store_id,data,refresh):
        expected={'storeId','taskId','confirmed'} if action=='analysis_queue_resume' else {'storeId','taskId'}
        if (action not in ACTIONS or not isinstance(data,dict) or set(data)!=expected
                or data.get('storeId')!=store_id or not isinstance(data.get('taskId'),str) or not KEY.fullmatch(data['taskId'])
                or not callable(refresh)):
            fail('ANALYSIS_INPUT_INVALID','请选择当前门店的原采集任务',400)
        if action=='analysis_queue_resume' and data['confirmed'] is not True:
            fail('ANALYSIS_CONFIRM_REQUIRED','请确认只分析本任务已保存评论',400)
        with self.lock:workspace=self.workspace
        if (workspace and not workspace['stop'].is_set() and workspace['storeId']==store_id
                and all(workspace['user'].get(k)==user.get(k) for k in ACTOR_FIELDS) and action in ACTIONS):
            # Compatibility for an already-open task panel: one automatic
            # director remains the only consumer, including after old buttons.
            # Original task arguments/ownership remain checked before mapping.
            self._scope(user,store_id,data['taskId'],refresh)
            mapped={'analysis_queue_read':'analysis_workspace_read','analysis_queue_pause':'analysis_workspace_pause',
                'analysis_queue_resume':'analysis_workspace_resume'}[action]
            return self.execute_workspace(mapped,user,store_id,{'storeId':store_id},workspace['refresh'],workspace['factory'])
        current,task,executor,scope=self._scope(user,store_id,data['taskId'],refresh,
            analyzing=action=='analysis_queue_resume',fresh=action=='analysis_queue_resume')
        if action=='analysis_queue_read':return self._snapshot(current,store_id,task,executor)
        if action=='analysis_queue_pause':
            with self.lock:
                run=self.active
                if run and run['taskId']==task['id'] and run['storeId']==store_id and run['user']['id']==current['id']:
                    run['stop'].set();run['wake'].set();self._record(run,'paused','ANALYSIS_QUEUE_PAUSED')
                    grant=self.authorizations.get(task['id'])
                    if grant:grant['blocked']=True
            return {**self._snapshot(current,store_id,task,executor),'accepted':True}
        with self.lock:
            active=self.active
            if active and active.get('thread') and active['thread'].is_alive():
                if active['scope']!=scope:
                    if not self._retire_dormant(active):
                        fail('ANALYSIS_QUEUE_BUSY','另一项已授权分析尚未结束，请先暂停',409)
                else:
                    if active['stop'].is_set():fail('ANALYSIS_QUEUE_STOPPING','原分析正在结束，请核对后再继续',409)
                    active['working']=True;active['wake'].set()
                    return {**self._snapshot(current,store_id,task,executor),'accepted':True}
            grant={'user':deepcopy(current),'storeId':store_id,'taskId':task['id'],'scope':scope,'refresh':refresh}
            previous=self.authorizations.get(task['id'])
            if previous:previous['blocked']=False
            self._launch(grant,collection=previous is not None)
        return {**self._snapshot(current,store_id,task,executor),'accepted':True}

    def _sync_confirmed_queue(self,user,task):
        """Only shrink confirmed IDs; preserve held IDs, source binding and code."""
        with self.core.lock:
            row=self.core.store.get(PENDING_ENTITY,task['id'])
            if (not row or row.get('tenant_id')!=user['tenant_id'] or row.get('owner')!=user['username']
                    or row.get('binding')!=self.runtime._collection_binding(task) or not isinstance(row.get('lead_ids'),list)):return
            remaining=[ident for ident in row['lead_ids'] if not self._confirmed((self.core.store.get('leads',ident) or {}).get('manual_intent')
                or (self.core.store.get('leads',ident) or {}).get('ai_intent'))]
            if remaining!=row['lead_ids']:
                self.core.store.put(PENDING_ENTITY,{**row,'lead_ids':remaining,'status':'pending' if remaining else 'completed',
                    'code':row.get('code','') if remaining else '','updated_at':stamp()})

    def _work(self,run):
        acquired=False
        try:
            while not self.worker_gate.acquire(timeout=.05):
                if run['stop'].is_set() or self.closed:
                    fail('ANALYSIS_QUEUE_PAUSED','本人已暂停分析；原请求结果仍保留')
            acquired=True
            user,task,executor,_=self._guard(run)
            _,_,held=self._inventory(user,task,executor)
            for row in held:
                self._guard(run)
                # Exact original UUID only. A status response never releases or
                # rewrites a local unknown attempt, and cannot execute a model.
                self._phase(run,'original_request_status')
                try:
                    executor.ai.attempts.status(user,{'request_id':row['request_id']})
                except Exception as error:
                    # A closed optional old-status endpoint does not grant any
                    # result or retry. These exact original leads stay held;
                    # only disjoint new leads may enter the unchanged workflow.
                    if not _legacy_status_unavailable(error):raise
                    run['heldStatusCode']='AI_LEGACY_EXTENSIONS_DISABLED'
                    self._record(run,run['status'],run.get('code',''))
                self._guard(run)
            while True:
                run['wake'].clear()
                user,task,executor,_=self._guard(run)
                counts,pending,_=self._inventory(user,task,executor)
                if not pending:
                    self._sync_confirmed_queue(user,task)
                    self._record(run,'held' if counts['held'] else 'completed')
                    with self.lock:run['working']=False
                    if not run.get('collection'):return
                    # Dormant, explicitly authorized consumer. It makes no
                    # cloud/model request until a saved page or explicit click.
                    run['wake'].wait()
                    self._guard(run)
                    with self.lock:run['working']=True
                    self._record(run,'running')
                    continue
                group_key=post_identity(pending[0])
                batch=[row for row in pending if post_identity(row)==group_key][:20]
                ids={row['id'] for row in batch}
                original_ai=executor.ai
                def guarded_cloud(actor,operation,payload):
                    if operation=='intent_analyze':
                        # Observation only: original journal has already bound
                        # this exact request+submission before entering cloud.
                        # No attempt, permission, result or retry rule changes.
                        with self.lock:run['processingBatch']={'ids':tuple(sorted(ids)),
                            'requestId':payload.get('request_id'),'submissionId':payload.get('submission_id')}
                    self._phase(run,operation)
                    # Ordinary guards and UI polls use only the valid local
                    # session/scope snapshot. Fresh remote authority is checked
                    # around the actual provider operation, not every local read.
                    current_scope=self._guard(run,fresh=operation=='intent_analyze')
                    if operation not in ('ai_profile','intent_analyze','ai_attempt_status'):
                        fail('ANALYSIS_OPERATION_FORBIDDEN','分析操作不在当前授权范围',403)
                    if operation=='intent_analyze':
                        actor,current,active_executor,_=current_scope
                        self._dispatch_batch_guard(actor,current,active_executor,ids,payload)
                    result=original_ai.cloud(actor,operation,payload)
                    self._guard(run,fresh=operation=='intent_analyze')
                    return result
                ai=self.workflow_factory(self.core,guarded_cloud,company=original_ai.company,host_context=original_ai.attempts.host_context)
                selected=copy(executor);selected.ai=ai
                original_visible=executor._analysis_visible_leads
                selected._analysis_visible_leads=lambda actor,current,rows=None:(row for row in original_visible(actor,current,rows=rows) if row['id'] in ids)
                # Reuse original semantic selection and all workflow/attempt CAS.
                # Original default replace_existing=False remains mandatory.
                selected.analyze_pending(user,{'task_id':task['id']},explicit_retry=False)
                self._guard(run)
                after,_,_=self._inventory(user,task,executor)
                if after['analyzed']<=counts['analyzed']:
                    fail('ANALYSIS_RESULT_UNCONFIRMED','本批结果尚未完整保存，已停止；不会自动重提',409)
                self._sync_confirmed_queue(user,task)
        except Exception as error:
            code=getattr(error,'code',None)
            if not isinstance(code,str) or not re.fullmatch(r'[A-Z_]{1,80}',code):code='ANALYSIS_UNAVAILABLE'
            status='paused' if run['stop'].is_set() or code=='ANALYSIS_QUEUE_PAUSED' else 'blocked'
            try:self._record(run,status,code)
            except Exception:
                with self.lock:run['status'],run['code']=status,code
            with self.lock:
                run['working']=False
                grant=self.authorizations.get(run['taskId'])
                if grant and grant['scope']==run['scope']:grant['blocked']=True
        finally:
            if acquired:self.worker_gate.release()

__all__=['ACTIONS','WORKSPACE_ACTIONS','AnalysisQueueError','AnalysisQueueRuntime']
