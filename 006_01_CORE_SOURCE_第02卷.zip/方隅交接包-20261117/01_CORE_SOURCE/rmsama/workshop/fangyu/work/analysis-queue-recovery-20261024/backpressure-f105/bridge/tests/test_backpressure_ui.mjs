import assert from 'node:assert/strict';
import fs from 'node:fs';import path from 'node:path';import {pathToFileURL} from 'node:url';import {createRequire} from 'node:module';import {createHash} from 'node:crypto';
const root=path.resolve(import.meta.dirname,'..');
const baseline='C:/积木软件工坊/项目/方隅公寓客户版/work/parallel-integration-20261018/final-integration/candidate-unified-v104/project/work/ui-native-r57/releases/ui-r57-20261024T153411Z-4c9dd686/web';
const flag=n=>{const i=process.argv.indexOf(n);return i<0?null:process.argv[i+1];};
const pins=flag('--pins');
const web=path.resolve(flag('--web')||(pins?path.join(JSON.parse(fs.readFileSync(pins,'utf8')).release,'web'):baseline));
const module=await import(pathToFileURL(path.join(web,'pages/saved-comment-analysis.mjs')));
function fixture({pending=0,processing=0,held=29,missingText=21,analyzed=2018,status='waiting',running=false,autoPaused=false,code='',canResume=true}={}){
 const s={connection:'connected',page:'acquire',authEpoch:1,user:'fixture-user',storeId:'fixture-store',session:{user:{tenant_id:'fixture-tenant',role:'operator'}}};
 module.renderSavedCommentAnalysis(s);
 s.savedCommentAnalysis.value={actor:{username:s.user,storeId:s.storeId},taskId:'workspace',status,running,
   counts:{total:pending+processing+held+missingText+analyzed,pending,processing,held,missingText,analyzed},remaining:pending+processing,
   autoEnabled:!autoPaused,autoPaused,canPause:true,canResume:status==='blocked'||autoPaused,code,message:'自动队列已核对'};
 s.savedCommentAnalysis.lastRead=Date.now();
 const live={status:'paused',taskId:'old-task',canStart:false,canResume,analysisDecoupled:true,analysisBufferMode:'durable_background',analysisBufferLimit:null,message:'待分析已达200条上限；原评论与断点保留，请先完成分析或人工复核',analysis:{pending:200,hold:true}};
 return {s,live};
}
const checks=[];
function test(name,fn){try{fn();checks.push({name,passed:true});}catch(e){checks.push({name,passed:false,error:e.message});}}
test('cleared_live_queue_does_not_claim_current_200_buffer',()=>{
 const {s,live}=fixture();const text=module.analysisBufferMessage(s,live);
 assert.doesNotMatch(text,/缓冲达到200条|已达200条上限/);assert.match(text,/待分析\s*0\s*条/);assert.match(text,/待核\s*29\s*条/);assert.match(text,/缺正文\s*21\s*条/);
});
test('backend_still_denied_does_not_claim_collection_is_allowed',()=>{
 const {s,live}=fixture({canResume:false});const text=module.analysisBufferMessage(s,live);
 assert.doesNotMatch(text,/可继续原任务|可继续采集/);assert.match(text,/采集条件.*核对/);
});
test('automatic_mode_keeps_200_inflight_independent',()=>{
 const {s,live}=fixture({pending:180,processing:20,held:9,status:'running',running:true});const text=module.analysisBufferMessage(s,live);
 assert.match(text,/待分析\s*200\s*条/);assert.match(text,/分析保持开启/);assert.match(text,/待核\s*9\s*条/);assert.doesNotMatch(text,/达到200条|上限|先完成分析/);
});
test('stale_or_failed_read_never_claims_cleared',()=>{
 const {s,live}=fixture();s.savedCommentAnalysis.error='本地状态读取失败';const text=module.analysisBufferMessage(s,live);
 assert.doesNotMatch(text,/已清空|可继续原任务|可继续采集|待分析\s*0\s*条/);assert.match(text,/当前.*核对/);
});
test('analysis_error_remains_visible_when_queue_not_pressured',()=>{
 const {s,live}=fixture({status:'blocked',code:'AI_PROVIDER_TIMEOUT',canResume:true});const text=module.analysisBufferMessage(s,live);
 assert.match(text,/分析异常暂停/);assert.doesNotMatch(text,/后台分析继续/);assert.match(text,/待核\s*29\s*条/);
});
test('user_pause_is_independent_from_collection_capacity',()=>{
 const {s,live}=fixture({pending:14,held:9,autoPaused:true,status:'paused'});const text=module.analysisBufferMessage(s,live);
 assert.match(text,/本人暂停/);assert.match(text,/待分析\s*14\s*条/);assert.doesNotMatch(text,/缓冲达到200条/);
});
test('automatic_mode_above_200_does_not_reintroduce_cap',()=>{
 const {s,live}=fixture({pending:244,status:'running',running:true});const text=module.analysisBufferMessage(s,live);
 assert.match(text,/待分析\s*244\s*条/);assert.match(text,/采集与后台分析独立/);assert.doesNotMatch(text,/达到200条|上限|先完成分析/);
});
test('legacy_mode_keeps_original_contract',()=>{
 const {s,live}=fixture({pending:244,status:'running',running:true});delete live.analysisDecoupled;delete live.analysisBufferMode;delete live.analysisBufferLimit;
 assert.match(module.analysisBufferMessage(s,live),/缓冲达到200条/);
});
const owned=fs.mkdtempSync(path.join(root,'work-dom-'));fs.mkdirSync(path.join(owned,'pages'));
const closure=fs.existsSync(path.join(web,'app.mjs'))?web:baseline;
for(const folder of ['', 'pages'])for(const e of fs.readdirSync(path.join(closure,folder),{withFileTypes:true}))if(e.isFile()&&e.name.endsWith('.mjs'))fs.copyFileSync(path.join(closure,folder,e.name),path.join(owned,folder,e.name));
for(const name of ['saved-comment-analysis.mjs','acquire.mjs'])fs.copyFileSync(path.join(web,'pages',name),path.join(owned,'pages',name));
const acquire=await import(pathToFileURL(path.join(owned,'pages/acquire.mjs')));
const require=createRequire('C:/积木软件工坊/项目/方隅公寓客户版/work/parallel-integration-20261018/final-integration/candidate-unified-v104/project/work/ui-native-r57/public_article_generic/package.json');
const {JSDOM}=require('jsdom');const dom=new JSDOM('<main id="root"></main>');globalThis.document=dom.window.document;
try{
 const {s,live}=fixture({canResume:false});Object.assign(s,{stores:[{id:s.storeId,name:'合成门店'}],store:'合成门店',activePlatform:'xiaohongshu',platform:{actor:{username:s.user,storeId:s.storeId},platforms:[{id:'xiaohongshu',enabled:true,accountId:'fixture-account'}],acquisition:live}});
 const target=document.querySelector('#root');let starts=0;const ctx={state:s,actions:{startAcquisition:()=>{starts++;}},update:fn=>fn(s),navigate:()=>{},modal:()=>{},toast:()=>{}};
 target.innerHTML=acquire.render(s);let cleanup=acquire.bind(target,ctx);
 test('backend_denied_start_remains_disabled_and_handler_rechecks',()=>{const button=target.querySelector('[data-acquire-start]');assert.equal(button.disabled,true);button.removeAttribute('disabled');button.click();assert.equal(starts,0);});
 test('decoupled_progress_does_not_label_cleared_queue_as_buffer_pause',()=>{assert.doesNotMatch(target.textContent,/采集缓冲已暂停|缓冲达到200条|已达200条上限/);assert.match(target.textContent,/待分析\s*0\s*条/);assert.match(target.textContent,/待核\s*29\s*条/);});
 cleanup();live.canStart=true;target.innerHTML=acquire.render(s);cleanup=acquire.bind(target,ctx);
 test('backend_allowed_start_is_available_without_analysis_action',()=>{const button=target.querySelector('[data-acquire-start]');assert.equal(button.disabled,false);button.click();assert.equal(starts,1);});
 cleanup();live.platformError={category:'verification_required'};target.innerHTML=acquire.render(s);
 test('platform_verification_is_not_hidden_by_analysis_capability',()=>{assert.match(target.textContent,/验证/);assert.equal(module.analysisBufferMessage(s,live),'');});
}finally{dom.window.close();}
const verifiedFiles=['pages/acquire.mjs','pages/saved-comment-analysis.mjs'].map(name=>({path:path.join(web,name),sha256:createHash('sha256').update(fs.readFileSync(path.join(web,name))).digest('hex')}));
console.log(JSON.stringify({passed:checks.every(x=>x.passed),cases:checks.length,verifiedWeb:web,verifiedFiles,checks},null,2));
process.exitCode=checks.every(x=>x.passed)?0:1;
