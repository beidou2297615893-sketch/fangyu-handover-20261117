import {localDay} from '../daily-ui.mjs';

const esc=value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const count=value=>Number.isSafeInteger(value)&&value>=0;
const scope=s=>JSON.stringify([s.authEpoch||0,s.session?.user?.tenant_id||'',s.user||'',s.session?.user?.role||'',s.storeId||'',s.activePlatform||'xiaohongshu']);
const dateScope=v=>JSON.stringify([v.dateFrom,v.dateTo]);
const platformName=value=>value==='douyin'?'抖音':'小红书';
let viewSequence=0;

export const canReadKeywordEffect=s=>Boolean(s?.connection==='connected'&&s.session&&s.user&&s.storeId);

export function validateKeywordDates(from,to){
  const stamp=value=>{
    if(typeof value!=='string'||!/^\d{4}-\d{2}-\d{2}$/.test(value))return NaN;
    const date=new Date(value+'T00:00:00Z');
    return Number.isFinite(date.getTime())&&date.toISOString().slice(0,10)===value?date.getTime():NaN;
  };
  const start=stamp(from),end=stamp(to);
  return Number.isFinite(start)&&Number.isFinite(end)&&to!=='9999-12-31'&&end>=start&&end-start<=365*86400000;
}

function checkRate(rate,denominator){
  return rate&&count(rate.numerator)&&count(rate.denominator)&&rate.denominator===denominator
    &&rate.numerator<=rate.denominator&&(denominator===0?rate.value===null:
      typeof rate.value==='number'&&Number.isFinite(rate.value)&&Math.abs(rate.value-rate.numerator/denominator)<1e-9);
}
function checkMetrics(m){
  const names=['commentsSeen','newComments','uniqueCustomers','provisionalCustomers','aiAnalyzedComments','manuallyReviewedComments','judgedComments','unanalysedComments','observations'];
  if(!m||!names.every(key=>count(m[key]))||m.newComments>m.commentsSeen||m.uniqueCustomers>m.commentsSeen
    ||m.provisionalCustomers>m.uniqueCustomers||m.observations<m.commentsSeen||m.judgedComments+m.unanalysedComments!==m.commentsSeen
    ||m.aiAnalyzedComments>m.judgedComments||m.manuallyReviewedComments>m.judgedComments)return false;
  const d=m.businessDistribution;
  return d&&['high','medium','low','uncertain','unrelated','pending'].every(key=>count(d[key]))
    &&Object.values(d).reduce((sum,n)=>sum+n,0)===m.commentsSeen
    &&checkRate(m.manualHitRate,m.manuallyReviewedComments)&&checkRate(m.aiAnalysisCoverage,m.commentsSeen);
}
export function validateKeywordReport(result,request,username){
  const r=result?.keywordEffect;
  if(!r||r.schema!=='fangyu-keyword-effect-v1'||r.actor?.username!==username||r.actor?.storeId!==request.storeId
    ||r.scope?.storeId!==request.storeId||r.scope?.platform!==request.platform||r.scope?.dateFrom!==request.dateFrom
    ||r.scope?.dateTo!==request.dateTo||r.scope?.timezone!=='Asia/Shanghai'
    ||r.judgmentBasis!=='current-snapshot-for-observed-cohort'
    ||r.attributionBasis!=='saved-historical-label-not-verified-dispatched-query'
    ||r.readOnly!==true||r.modelCalled!==false||r.platformCalled!==false||!checkMetrics(r.total)
    ||!Array.isArray(r.groups)||r.groups.some(g=>!checkMetrics(g)||(g.keyword!==null&&(typeof g.keyword!=='string'||!g.keyword.trim()||[...g.keyword].length>200))
      ||g.attribution!==(g.keyword===null?'unmarked':'saved_historical_label'))
    ||!checkRate(r.coverage?.commentsWithKeywordLabel,r.total.commentsSeen)
    ||!checkRate(r.coverage?.observationsWithKeywordLabel,r.total.observations)
    ||!count(r.coverage?.unmarkedComments)||r.coverage.unmarkedComments>r.total.commentsSeen
    ||!count(r.coverage?.commentsWithBothTaggedAndUnmarkedObservations)){
    throw Error('统计回执尚未核对完整，请重新读取；不会把未知值当成零。');
  }
  const labels=new Set();for(const g of r.groups){if(labels.has(g.keyword))throw Error('统计分组重复，请重新读取。');labels.add(g.keyword);}
  const q=r.queryAttribution;
  if(q!==undefined){
    if(!q||q.schema!=='fangyu-keyword-query-effect-v1'||q.basis!=='host-requested-query-not-platform-ranking'
      ||q.dateBasis!=='first-observed-task-comment-keyword'||q.historicalLabelsNotPromoted!==true
      ||q.platformCalled!==false||!checkMetrics(q.total)||!Array.isArray(q.groups)
      ||q.groups.some(g=>!checkMetrics(g)||typeof g.keyword!=='string'||!g.keyword.trim()||[...g.keyword].length>200)
      ||new Set(q.groups.map(g=>g.keyword)).size!==q.groups.length
      ||q.groups.reduce((sum,g)=>sum+g.observations,0)!==q.total.observations
      ||q.groups.some(g=>g.commentsSeen>q.total.commentsSeen))throw Error('检索词出处尚未核对完整，请重新读取。');
  }
  const tagged=r.groups.filter(g=>g.keyword!==null),unmarked=r.groups.find(g=>g.keyword===null),c=r.coverage;
  if(r.groups.reduce((sum,g)=>sum+g.observations,0)!==r.total.observations
    ||tagged.reduce((sum,g)=>sum+g.observations,0)!==c.observationsWithKeywordLabel.numerator
    ||(unmarked?.commentsSeen||0)!==c.unmarkedComments
    ||c.commentsWithBothTaggedAndUnmarkedObservations>Math.min(c.commentsWithKeywordLabel.numerator,c.unmarkedComments)
    ||c.commentsWithKeywordLabel.numerator+c.unmarkedComments-c.commentsWithBothTaggedAndUnmarkedObservations!==r.total.commentsSeen){
    throw Error('来源覆盖的统计口径尚未核对完整，请重新读取；不会把未知值当成零。');
  }
  return r;
}

const percent=rate=>rate.denominator?`${(rate.numerator/rate.denominator*100).toLocaleString('zh-CN',{maximumFractionDigits:1})}%`:'暂无样本';
const fraction=rate=>rate.denominator?`${rate.numerator} / ${rate.denominator}`:'暂无复核样本';
function queryMarkup(q){
  if(!q)return '';
  return `<section class="ke-query"><h3>已记录的检索词</h3><p>${q.total.commentsSeen?`关联 ${q.total.commentsSeen} 条评论、${q.total.uniqueCustomers} 位去重客户。`:'新采集开始记录检索词出处，历史未记录的来源继续保留未知。'}按所选日期首次记录的“任务、评论、词”关系统计，重读不重复新增。</p>${q.groups.length?`<div class="ke-table-wrap"><table class="ke-table"><caption>本软件请求检索的词</caption><thead><tr><th scope="col">检索词</th><th scope="col">评论</th><th scope="col">客户</th><th scope="col">高意向评论</th></tr></thead><tbody>${q.groups.map(g=>`<tr><th scope="row" data-label="检索词">${esc(g.keyword)}</th><td data-label="评论">${g.commentsSeen}</td><td data-label="客户">${g.uniqueCustomers}</td><td data-label="高意向评论">${g.businessDistribution.high}</td></tr>`).join('')}</tbody></table></div>`:''}<small>各词可能关联同一客户，分组不能相加；这不是平台热度、成交归因或相关性证明。</small></section>`;
}

function reportMarkup(r,stale){
  if(!r)return '<div class="ke-empty"><strong>选择采集日期，查看本店词效</strong><p>只统计本机已有记录，不会启动采集或更改词库。</p></div>';
  const m=r.total,c=r.coverage;
  const covered=c.commentsWithKeywordLabel.numerator>0;
  return `<section class="ke-report" aria-label="词效统计结果"><p class="ke-result-date">${stale?'上次结果：':'显示日期：'}<strong>${esc(r.scope.dateFrom)} — ${esc(r.scope.dateTo)}</strong> · 北京时间采集日期${stale?'；当前筛选尚未读取完成。':''}</p>
    <dl class="ke-metrics">${[['原始评论',m.commentsSeen,`其中新增 ${m.newComments} 条`],['去重客户',m.uniqueCustomers,m.provisionalCustomers?`${m.provisionalCustomers} 位身份待核`:'按原平台身份去重'],['已有判断',`${m.judgedComments} / ${m.commentsSeen}`,`待分析 ${m.unanalysedComments} 条`],['高意向评论',m.businessDistribution.high,'含超高意向'],['人工复核',m.manuallyReviewedComments,`高/中命中 ${fraction(m.manualHitRate)}`]].map(([title,value,note])=>`<div><dt>${title}</dt><dd>${esc(value)}</dd><small>${esc(note)}</small></div>`).join('')}</dl>
    <p class="ke-analysis">AI 已分析 ${m.aiAnalyzedComments} 条 · 人工已复核 ${m.manuallyReviewedComments} 条。两者可能重叠，已有判断按评论去重。</p>
    <div class="ke-coverage ${covered?'':'ke-unmarked'}" role="note"><strong>历史词标签覆盖 ${percent(c.commentsWithKeywordLabel)}</strong><p>${covered?'关键词来自已保存的历史标签，尚不能证明实际搜索请求使用了该词。':'这段日期没有可用的历史词标签，暂不能评判哪个词带来更多客户。'}未标记不表示词无效。</p><small>有标签评论 ${c.commentsWithKeywordLabel.numerator} / ${c.commentsWithKeywordLabel.denominator} · 未标记评论 ${c.unmarkedComments}${c.commentsWithBothTaggedAndUnmarkedObservations?` · ${c.commentsWithBothTaggedAndUnmarkedObservations} 条同时存在有标签和未标记的观察关系`:''}</small></div>
    ${queryMarkup(r.queryAttribution)}
    <p class="ke-basis">下方历史标签按原采集日期统计。各词分组不能相加，上方总计已全局去重。</p>
    ${m.commentsSeen?`<div class="ke-table-wrap"><table class="ke-table"><caption>按已保存来源标签查看</caption><thead><tr><th scope="col">来源标签</th><th scope="col">原始评论</th><th scope="col">去重客户</th><th scope="col">高意向评论</th><th scope="col">人工高/中命中</th></tr></thead><tbody>${r.groups.map(g=>`<tr><th scope="row" data-label="来源标签">${esc(g.keyword===null?'未标记':g.keyword)}<small>${g.keyword===null?'暂无词来源证据':'历史标签'}</small></th><td data-label="原始评论">${g.commentsSeen}</td><td data-label="去重客户">${g.uniqueCustomers}</td><td data-label="高意向评论">${g.businessDistribution.high}</td><td data-label="人工高/中命中">${fraction(g.manualHitRate)}</td></tr>`).join('')}</tbody></table></div>`:'<div class="ke-empty"><strong>所选日期没有可核对的采集记录</strong><p>可换一个采集日期；不会自动扩大范围或编造热词。</p></div>'}
    <details class="ke-method"><summary>查看统计口径与来源覆盖</summary><p>按所选采集/观察日期范围，显示这些原评论的当前判断；不是历史当天的判断回放。</p><p>同一客户可能来自多个词，各词分组不能相加；上方总计已全局去重。高意向与人审命中均以评论为分母，不是成交转化率或模型准确率。</p><p>已保存任务观察关系 ${m.observations} 次，关系有词标签覆盖 ${percent(c.observationsWithKeywordLabel)}（${c.observationsWithKeywordLabel.numerator} / ${c.observationsWithKeywordLabel.denominator}）。观察关系不是平台返回条数；重复查看同一任务的原评论不会每天新增一条。</p><p>AI 分析覆盖 ${percent(m.aiAnalysisCoverage)}（${m.aiAnalysisCoverage.numerator} / ${m.aiAnalysisCoverage.denominator}）。缺少原文的“信息不足”不冒充已调用 AI。</p>${Object.entries(r.quality||{}).filter(([,n])=>count(n)&&n>0).map(([key,n])=>({unverifiedStoreCommentsExcluded:`未核实本店归属的历史评论未计入：${n} 条。`,unknownCollectionTimeRecordsExcluded:`采集时间无法核对的记录未计入：${n} 条。`,invalidObservationRecordsExcluded:`来源关系未通过核对的记录未计入：${n} 条。`,provisionalIdentityComments:`缺少稳定平台身份的评论按临时客户处理：${n} 条。`}[key]||'')).filter(Boolean).map(text=>`<p>${esc(text)}</p>`).join('')}</details></section>`;
}

export function renderKeywordEffect(v){
  const stale=Boolean(v.report&&(v.report.scope.dateFrom!==v.dateFrom||v.report.scope.dateTo!==v.dateTo));
  return `<div class="ke-content"><p class="ke-context"><strong>${esc(v.storeName)}</strong> · ${platformName(v.platform)}<span>北京时间 · 采集日期</span></p><form data-ke-form class="ke-filters"><label for="ke-date-from">开始日期<input id="ke-date-from" data-ke-date="from" type="date" value="${esc(v.dateFrom)}" required aria-label="词效开始采集日期"></label><label for="ke-date-to">结束日期<input id="ke-date-to" data-ke-date="to" type="date" value="${esc(v.dateTo)}" required aria-label="词效结束采集日期"></label><button type="submit" class="primary" ${v.loading?'disabled':''}>${v.loading?'正在刷新…':v.report?'重新读取':'读取统计'}</button></form><p class="ke-status" role="status" aria-live="polite">${esc(v.message||(v.loading?(v.report?'正在刷新，保留上次结果。':'正在读取本机统计…'):stale?'日期已更改，下方仍是上次结果。':''))}</p><div class="ke-results" aria-busy="${Boolean(v.loading)}">${reportMarkup(v.report,stale)}</div></div>`;
}

export function bindKeywordEffect(root,v,{read,changed}){
  root.querySelector('[data-ke-form]')?.addEventListener('submit',event=>{event.preventDefault();read();});
  root.querySelectorAll('[data-ke-date]').forEach(input=>input.addEventListener('change',event=>{
    const key=event.target.dataset.keDate==='from'?'dateFrom':'dateTo';
    if(v[key]===event.target.value)return;
    v[key]=event.target.value;v.sequence++;v.loading=false;v.message='日期已更改，请重新读取。';changed();
  }));
}

function ensureStyle(){
  if(!document.head||document.head.querySelector('[data-keyword-effect-style]'))return;
  const link=document.createElement('link');link.rel='stylesheet';link.href='/pages/keyword-effect.css';link.setAttribute('data-keyword-effect-style','');document.head.append(link);
}

export function openKeywordEffect(ctx){
  const s=ctx.state;
  if(!canReadKeywordEffect(s)){ctx.toast?.('请先登录并选择当前已授权门店。');return null;}
  ensureStyle();
  const day=localDay(),v={viewId:++viewSequence,scope:scope(s),page:s.page,storeId:s.storeId,storeName:s.store||'当前门店',username:s.user,platform:s.activePlatform||'xiaohongshu',dateFrom:day,dateTo:day,sequence:0,loading:false,report:null,message:'',closed:false};
  s.keywordEffectUI=v;
  const dialog=ctx.modal({title:'关键词带来的评论与客户',html:'',confirmLabel:'关闭'});
  const owner=dialog.__modalOwner;
  dialog.classList.add('keyword-effect-modal');
  const oldClose=dialog.onclose;
  const owns=()=>!v.closed&&dialog.open&&dialog.__modalOwner===owner&&s.keywordEffectUI===v&&scope(s)===v.scope&&s.page===v.page&&canReadKeywordEffect(s);
  const expire=()=>{if(dialog.__modalOwner===owner&&dialog.open)dialog.close();};
  dialog.onclose=event=>{if(dialog.__modalOwner===owner){v.closed=true;v.sequence++;dialog.classList.remove('keyword-effect-modal');oldClose?.call(dialog,event);}};
  function paint(){
    if(!owns())return;
    const focus=document.activeElement?.getAttribute?.('data-ke-date');
    const content=dialog.querySelector('.modal-content');content.innerHTML=renderKeywordEffect(v);
    bindKeywordEffect(content,v,{read,changed:paint});
    if(focus)content.querySelector(`[data-ke-date="${focus}"]`)?.focus?.({preventScroll:true});
  }
  async function read(){
    if(!owns()){expire();return;}
    if(v.loading)return;
    if(!validateKeywordDates(v.dateFrom,v.dateTo)){v.message='请选择有效的开始和结束日期，范围为连续 1—366 天。';paint();return;}
    const seq=++v.sequence,dates=dateScope(v),view=v.viewId;
    const request={storeId:v.storeId,platform:v.platform,dateFrom:v.dateFrom,dateTo:v.dateTo};
    const valid=()=>owns()&&s.keywordEffectUI.viewId===view&&v.sequence===seq&&dateScope(v)===dates;
    v.loading=true;v.message='';paint();
    try{
      const action=ctx.keywordEffectAction||ctx.actions?.keywordEffectAction;
      if(typeof action!=='function')throw Error('词效读取尚未装入当前界面，请正常更新后重开。');
      const result=await action('keyword_effect_read',request);
      if(!valid()){if(!owns())expire();return;}
      v.report=validateKeywordReport(result,request,v.username);v.message='已读取本机已有记录；任务和词库保持原设置。';
    }catch(error){
      if(valid()){v.message=(error?.message||'暂时无法读取统计，请稍后重试。')+(v.report?' 已保留上次结果与当前日期。':'');
        if(['AUTH_REQUIRED','STORE_FORBIDDEN','KEYWORD_SCOPE_CHANGED'].includes(error?.code))ctx.replyError?.(error);
      }else if(!owns())expire();
    }finally{if(valid()){v.loading=false;paint();}}
  }
  paint();dialog.querySelector('[data-ke-date="from"]')?.focus?.();
  void read();
  return {dialog,view:v,read};
}
