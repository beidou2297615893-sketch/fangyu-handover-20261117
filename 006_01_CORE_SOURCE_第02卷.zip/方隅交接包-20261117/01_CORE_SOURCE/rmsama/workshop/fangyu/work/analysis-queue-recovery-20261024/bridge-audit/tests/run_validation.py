from pathlib import Path
import ast
import difflib
import hashlib
import json
import subprocess
import sys
import time

root=Path(__file__).resolve().parents[1]
project=root.parents[1]/'parallel-integration-20261018/final-integration/candidate-unified-v100/project'
assert (project/'work/ui-native-r57/workbench_backend.py').is_file()
candidate=root/'candidate'
evidence=root/'evidence'
evidence.mkdir(exist_ok=True)
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
checks=[]
for command in ([sys.executable,str(root/'tests/test_bridge_contract.py')],
                [sys.executable,str(root/'tests/test_host_routes.py')],
                [sys.executable,str(root/'tests/test_combined_controller.py')],
                [sys.executable,str(root/'tests/test_review_memory.py')],
                [sys.executable,str(root/'tests/test_local_authority.py')],
                ['node',str(root/'tests/test_analysis_ui.mjs')],
                ['node',str(root/'tests/test_transport.mjs')]):
    p=subprocess.run(command,capture_output=True,text=True,encoding='utf-8',errors='replace')
    checks.append({'command':command,'exitCode':p.returncode,'output':p.stdout+p.stderr})
files=[];diff=[]
for path in sorted(candidate.rglob('*')):
    if not path.is_file() or path.suffix not in ('.py','.mjs'):continue
    rel=path.relative_to(candidate);baseline=project/rel
    if path.suffix=='.py':compile(path.read_text(encoding='utf-8-sig'),str(path),'exec')
    else:
        p=subprocess.run(['node','--check',str(path)],capture_output=True,text=True)
        checks.append({'command':['node','--check',str(rel)],'exitCode':p.returncode,'output':p.stdout+p.stderr})
    files.append({'relativePath':rel.as_posix(),'candidate':str(path),'sha256':sha(path),
                  'baselinePath':str(baseline),'baselineSha256':sha(baseline) if baseline.is_file() else None})
    diff.extend(difflib.unified_diff(baseline.read_text(encoding='utf-8-sig').splitlines(True) if baseline.is_file() else [],
                                   path.read_text(encoding='utf-8-sig').splitlines(True),
                                   fromfile=rel.as_posix()+' (F100)',tofile=rel.as_posix()+' (candidate)'))
report={'schema':'analysis-bridge-isolated-candidate-v1','time':time.time(),'baseProject':str(project),
        'candidateRoot':str(candidate),'boundary':{'productionWrites':0,'realCloudCalls':0,'modelCalls':0,'platformCalls':0,'nativeProcessesStarted':0},
        'tests':checks,'passed':all(c['exitCode']==0 for c in checks),'files':files,
        'requiresCoreCandidate':'work/shared-backend-integration/analysis_queue_runtime.py and platform_runtime.py from core-audit candidate',
        'unverified':['real enterprise/provider call','real native rendering','full normal collection/controller chain is owned by core-audit']}
(evidence/'VALIDATION.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
(evidence/'changes.diff').write_text(''.join(diff),encoding='utf-8')
print(json.dumps({'passed':report['passed'],'files':len(files),'checks':len(checks),'report':str(evidence/'VALIDATION.json')},ensure_ascii=False))
sys.exit(0 if report['passed'] else 1)
