"""Owned SQLite + original F100 analyze_pending; all cloud/model calls are fixtures."""
from pathlib import Path
import copy, hashlib, importlib.util, io, json, os, socket, subprocess, sys, tempfile, threading, time, unittest
from types import SimpleNamespace
from unittest.mock import patch
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
PR=Path(os.environ.get('ANALYSIS_QUEUE_SOURCE_PROJECT','C:/积木软件工坊/项目/方隅公寓客户版/work/parallel-integration-20261018/final-integration/candidate-unified-v100/project'))
R=Path(os.environ.get('ANALYSIS_QUEUE_BASE_RELEASE',str(PR/'work/ui-native-r57/releases/ui-r57-20261024T082845Z-a2ad4ba4')))
EVIDENCE=Path(os.environ.get('ANALYSIS_QUEUE_EVIDENCE',str(HERE)));EVIDENCE.mkdir(parents=True,exist_ok=True)
sys.path.insert(0,str(PR/'work/ui-runtime-r55/src'))
from core.engine import Core
from assistant.ai_attempts import LocalAIAttempts,_digest

def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    mod=importlib.util.module_from_spec(spec);sys.modules[name]=mod;spec.loader.exec_module(mod);return mod

business=load('assistant.audit_f100_business',R/'resources/platform-runtime/vendor-src/assistant/business.py')
candidate_path=Path(os.environ.get('ANALYSIS_QUEUE_CONTROLLER',str(HERE/'analysis_queue_runtime.py')))
candidate=load('audit_analysis_queue_candidate',candidate_path) if candidate_path.exists() else None

class FixtureWorkflow:
    """Only external model result production is replaced, not selected-batch dispatch."""
    def __init__(self,core,cloud,*,company,host_context):
        self.core,self.cloud=core,cloud
        self.attempts=LocalAIAttempts(core,cloud,host_context=host_context)
    def analyze(self,user,task,rows,replace_existing=False,explicit_retry=False,**kw):
        if replace_existing or explicit_retry:raise AssertionError('unsafe overwrite/retry')
        result,receipt=self.attempts.call(user,'intent_analyze',{'ids':[r['id'] for r in rows]},
            context={'task':task['id']},lead_ids=[r['id'] for r in rows],explicit_new=explicit_retry)
        self.attempts.validated(user,receipt)
        for row in rows:
            current=self.core.store.get('leads',row['id'])
            if current.get('ai_intent') or current.get('manual_intent'):continue
            self.core.store.put('leads',{**current,'ai_intent':{'status':'graded','level':'medium'}})
        return {'analyzed':len(rows),'fixture':result}

class MissingImplementation(unittest.TestCase):
    def test_required_independent_queue_controller_exists(self):
        self.assertIsNotNone(candidate,'Missing independent controller; F100 still binds analysis to collection pause')

@unittest.skipIf(candidate is None,'controller not implemented yet')
class QueueTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(prefix='fixture-',dir=HERE);self.addCleanup(self.temp.cleanup)
        self.core=Core(self.temp.name,defer_startup_recovery=True);self.addCleanup(self.core.close_continuous_scheduler)
        self.user={'id':'fixture-user','tenant_id':'fixture-tenant','username':'fixture-owner','role':'operator','cloud_bound':True,'can_analyze':True}
        self.core.store.put('users',self.user);self.core.store.put('tenants',{'id':'fixture-tenant','tenant_id':'fixture-tenant'})
        self.task={'id':'fixture-task','tenant_id':'fixture-tenant','cloud_owner':'fixture-owner','store_id':'fixture-store',
            'platform':'xiaohongshu','account_id':'fixture-account','status':'paused','city':'fixture-city','keywords':['fixture']}
        self.core.store.put('tasks',self.task)
        self.core.store.put('accounts',{'id':'fixture-account','tenant_id':'fixture-tenant','cloud_owner':'fixture-owner','store_id':'fixture-store','platform':'xiaohongshu','status':'captcha_required'})
        self.calls=[];self.original_statuses=[];self.changed=None;self.model_gate=None
        self.server=SimpleNamespace(core=self.core,company={'id':'fangyu-apartment-client'})
        self.executor=object.__new__(business.BusinessExecutor)
        self.executor.core=self.core;self.executor.server=self.server;self.executor.tenant='fixture-tenant'
        self.executor.owner='fixture-owner';self.executor.user_id='fixture-user'
        def cloud(user,op,data):
            self.calls.append((op,copy.deepcopy(data)))
            if op=='ai_attempt_status':
                self.original_statuses.append(data['request_id'])
                return {'request_id':data['request_id'],'operation_kind':'intent_analyze','state':'unknown','execution_confirmed':None,
                    'execution_kind':'unknown','result_available':False,'requires_revalidation':True,'reservation_retained':None,
                    'read_only':True,'retry_allowed':False,'billing_verified':False}
            if op=='intent_analyze':
                if self.model_gate:self.model_gate()
                if self.changed:self.changed()
                return {'fixture_only':True}
            raise AssertionError('Unexpected cloud fixture operation '+op)
        self.cloud=cloud
        self.executor.ai=SimpleNamespace(cloud=cloud,company=lambda:self.server.company,
            attempts=LocalAIAttempts(self.core,cloud,host_context=lambda:{'device':'fixture'}))
        self.runtime=SimpleNamespace(core=self.core,server=self.server,service=SimpleNamespace(executor=self.executor),closed=False,
            _collection_binding=lambda task:{key:task.get(key) for key in ('id','tenant_id','cloud_owner','store_id','platform','account_id','city','keywords')})
        self.manager=candidate.AnalysisQueueRuntime(self.runtime,workflow_factory=FixtureWorkflow)
        self.addCleanup(lambda:(self.manager.close(),self.manager.wait_for_idle(5)))
        self.refresh_calls=0
        self.fresh_refresh_calls=0

    def refresh(self,*,fresh=False):
        self.refresh_calls+=1
        if fresh:self.fresh_refresh_calls+=1
        return dict(self.user),{'_workbench_store_id':'fixture-store','can_analyze':self.user.get('can_analyze',True)}

    def call(self,action,**extra):
        return self.manager.execute(action,self.user,'fixture-store',{'storeId':'fixture-store','taskId':'fixture-task',**extra},self.refresh)

    def leads(self,count,start=0):
        for i in range(start,start+count):
            self.core.store.put('leads',{'id':'lead-'+str(i),'tenant_id':'fixture-tenant','cloud_owner':'fixture-owner',
                'task_id':'fixture-task','platform':'xiaohongshu','source_type':'comment','text':'fixture text '+str(i),
                'content_title':'fixture post','note_url':'https://www.xiaohongshu.com/explore/123456789012345678901234'})

    def unknown(self,ids):
        attempts=self.executor.ai.attempts;principal,host=attempts._principal(self.user)
        row={'id':'fixture-old-attempt','tenant_id':'fixture-tenant','owner':'fixture-owner','operation':'intent_analyze',
            'request_id':'11111111-2222-3333-4444-555555555555','principal_digest':principal,'host_digest':host,
            'context_digest':_digest({'context':'fixture'}),'input_digest':_digest({'input':'fixture'}),
            'lead_digests':[_digest(['fixture-tenant','fixture-owner',ident]) for ident in ids],
            'state':'unknown','created_at':'2026-10-22T00:00:00Z'}
        self.core.store.put('ai_attempts',row);return copy.deepcopy(row)

    def wait(self):
        end=time.monotonic()+20
        while time.monotonic()<end:
            row=self.call('analysis_queue_read')
            if not row['running']:return row
            time.sleep(.01)
        self.fail('fixture worker did not finish')

    def test_paused_task_and_captcha_still_drain_181_preserving_unknown19(self):
        self.leads(200);old=self.unknown(['lead-'+str(i) for i in range(19)])
        response=self.call('analysis_queue_resume',confirmed=True)
        self.assertTrue(response['accepted'])
        final=self.wait()
        self.assertEqual(final['counts'],{'total':200,'pending':0,'held':19,'analyzed':181,'missingText':0})
        self.assertEqual(final['status'],'held')
        self.assertEqual(self.core.store.get('ai_attempts',old['id']),old)
        self.assertEqual(self.original_statuses,[old['request_id']])
        model_calls=[data for op,data in self.calls if op=='intent_analyze']
        self.assertEqual(sum(len(v['ids']) for v in model_calls),181)
        self.assertTrue(all(len(v['ids'])<=20 for v in model_calls))
        self.assertEqual(self.core.store.get('tasks','fixture-task'),self.task)

    def test_read_is_local_and_never_starts_worker(self):
        self.leads(2);result=self.call('analysis_queue_read')
        self.assertFalse(result['running']);self.assertEqual(result['counts']['pending'],2);self.assertEqual(self.calls,[])

    def test_double_resume_returns_same_run_without_duplicate_model_work(self):
        self.leads(21);entered=threading.Event();release=threading.Event()
        self.model_gate=lambda:(entered.set(),release.wait(3))
        first=self.call('analysis_queue_resume',confirmed=True);self.assertTrue(entered.wait(3))
        second=self.call('analysis_queue_resume',confirmed=True)
        self.assertEqual(first['requestId'],second['requestId'])
        release.set();final=self.wait()
        self.assertEqual(final['counts']['analyzed'],21)
        self.assertEqual(sum(len(d['ids']) for op,d in self.calls if op=='intent_analyze'),21)

    def test_pause_is_independent_of_collection_event_and_prevents_result_apply(self):
        self.leads(21);entered=threading.Event();release=threading.Event();collection_event=threading.Event()
        self.runtime._run_cancels={'fixture-task':{'event':collection_event}}
        self.model_gate=lambda:(entered.set(),release.wait(3))
        self.call('analysis_queue_resume',confirmed=True);self.assertTrue(entered.wait(3))
        paused=self.call('analysis_queue_pause');self.assertFalse(collection_event.is_set())
        release.set();final=self.wait()
        self.assertEqual(final['status'],'paused');self.assertEqual(final['counts']['analyzed'],0)

    def test_existing_ai_manual_and_missing_text_are_never_overwritten(self):
        self.leads(4)
        for ident,field in [('lead-0','ai_intent'),('lead-1','manual_intent')]:
            row=self.core.store.get('leads',ident);self.core.store.put('leads',{**row,field:{'status':'graded','level':'high','fixture':'original'}})
        row=self.core.store.get('leads','lead-2');self.core.store.put('leads',{**row,'text':''})
        row=self.core.store.get('leads','lead-3');source={'status':'graded','level':'high','fixture':'original-source'}
        self.core.store.put('leads',{**row,'source_ai_intent':source})
        before=[self.core.store.get('leads','lead-'+str(i)) for i in range(3)]
        self.call('analysis_queue_resume',confirmed=True);final=self.wait()
        self.assertEqual(final['counts'],{'total':4,'pending':0,'held':0,'analyzed':3,'missingText':1})
        self.assertEqual([self.core.store.get('leads','lead-'+str(i)) for i in range(3)],before)
        self.assertEqual(self.core.store.get('leads','lead-3')['source_ai_intent'],source)

    def test_missing_confirmation_foreign_store_and_foreign_task_fail_before_cloud(self):
        self.leads(1)
        with self.assertRaises(candidate.AnalysisQueueError):self.call('analysis_queue_resume',confirmed=False)
        changed={**self.task,'store_id':'other-store'};self.core.store.put('tasks',changed)
        with self.assertRaises(candidate.AnalysisQueueError):self.call('analysis_queue_resume',confirmed=True)
        self.assertEqual(self.calls,[])

    def test_permission_revocation_during_model_call_prevents_result_apply(self):
        self.leads(1);self.changed=lambda:self.user.update(can_analyze=False)
        self.call('analysis_queue_resume',confirmed=True)
        # Do not call public read with revoked authority; wait on the worker seam.
        self.manager.wait_for_idle(5)
        self.assertIsNone(self.core.store.get('leads','lead-0').get('ai_intent'))

    def test_context_change_during_model_call_prevents_result_apply(self):
        self.leads(1)
        self.changed=lambda:self.core.store.put('tasks',{**self.task,'city':'changed-city'})
        self.call('analysis_queue_resume',confirmed=True);self.manager.wait_for_idle(5)
        self.assertIsNone(self.core.store.get('leads','lead-0').get('ai_intent'))

    def test_budget_error_stops_without_auto_retry(self):
        self.leads(41)
        class BudgetError(ValueError):code='AI_DAILY_BUDGET'
        self.changed=lambda:(_ for _ in ()).throw(BudgetError('fixture budget'))
        self.call('analysis_queue_resume',confirmed=True);final=self.wait()
        self.assertEqual(final['code'],'AI_DAILY_BUDGET');self.assertEqual(final['counts']['analyzed'],0)
        self.assertEqual(len([op for op,d in self.calls if op=='intent_analyze']),1)

    def test_authorized_saved_pages_wake_independent_worker_after_collection_pause(self):
        self.assertTrue(callable(getattr(self.manager,'authorize_collection',None)),'Missing explicit collection authorization hook')
        before=self.refresh_calls
        self.manager.authorize_collection(self.user,'fixture-store','fixture-task',self.refresh)
        self.assertEqual(self.refresh_calls,before,'Synchronous collection authorization must not contact identity/cloud')
        self.assertEqual(self.calls,[])
        self.assertTrue(self.manager.owns_collection('fixture-task'))
        self.leads(21);collection_event=threading.Event();collection_event.set()
        self.runtime._run_cancels={'fixture-task':{'event':collection_event}}
        self.manager.notify_saved('fixture-task');first=self.wait()
        self.assertEqual(first['counts']['analyzed'],21)
        self.leads(1,start=21);self.manager.notify_saved('fixture-task');second=self.wait()
        self.assertEqual(second['counts']['analyzed'],22)

    def test_new_timeout_stops_all_later_batches_and_retains_new_unknown_key(self):
        self.leads(41)
        class Timeout(ValueError):code='AI_PROVIDER_TIMEOUT'
        self.changed=lambda:(_ for _ in ()).throw(Timeout('fixture timeout'))
        self.call('analysis_queue_resume',confirmed=True);final=self.wait()
        self.assertEqual(final['code'],'AI_PROVIDER_TIMEOUT')
        self.assertEqual(len([op for op,d in self.calls if op=='intent_analyze']),1)
        rows=self.core.store.list('ai_attempts','fixture-tenant')
        self.assertEqual(len(rows),1);self.assertEqual(rows[0]['state'],'unknown')
        self.assertEqual(len(rows[0]['lead_digests']),20)
        self.assertEqual(final['counts']['held'],20)

    def test_logout_during_model_call_prevents_result_apply(self):
        self.leads(1)
        self.changed=lambda:self.core.store.put('users',{**self.user,'disabled':True})
        self.call('analysis_queue_resume',confirmed=True);self.manager.wait_for_idle(5)
        self.assertIsNone(self.core.store.get('leads','lead-0').get('ai_intent'))

    def test_current209_unknown9_ignores_old_job19_and_other_tasks(self):
        self.leads(209);self.unknown(['lead-'+str(i) for i in range(9)])
        self.core.store.put('ai_jobs',{'id':'fixture-task','tenant_id':'fixture-tenant','pending':19,'status':'paused','code':'PRODUCT_REQUEST_UNKNOWN'})
        self.core.store.put('leads',{'id':'other-task-lead','tenant_id':'fixture-tenant','task_id':'other-task','cloud_owner':'fixture-owner','text':'must remain untouched'})
        result=self.call('analysis_queue_read')
        self.assertEqual(result['counts'],{'total':209,'pending':200,'held':9,'analyzed':0,'missingText':0})
        self.assertEqual(self.calls,[])

    def test_service_entitlement_revocation_blocks_before_model(self):
        self.leads(1)
        self.server.company['productAccessPolicy']={'package':'experience','features':[]}
        with self.assertRaises(Exception):self.call('analysis_queue_resume',confirmed=True)
        self.assertEqual(self.calls,[])

    def test_replaced_manager_cannot_overlap_an_inflight_provider_call(self):
        self.leads(21);entered=threading.Event();release=threading.Event()
        self.model_gate=lambda:(entered.set(),release.wait(3))
        self.call('analysis_queue_resume',confirmed=True);self.assertTrue(entered.wait(3))
        second=candidate.AnalysisQueueRuntime(self.runtime,workflow_factory=FixtureWorkflow)
        self.addCleanup(lambda:(second.close(),second.wait_for_idle(5)))
        second.execute('analysis_queue_resume',self.user,'fixture-store',{'storeId':'fixture-store','taskId':'fixture-task','confirmed':True},self.refresh)
        time.sleep(.1)
        self.assertEqual(len([op for op,d in self.calls if op=='intent_analyze']),1,'Shared Core must retain a single provider worker across manager lifecycle')
        release.set();self.wait();second.wait_for_idle(5)

    def test_new_explicit_task_retires_completed_dormant_consumer_without_join(self):
        self.leads(1)
        self.manager.authorize_collection(self.user,'fixture-store','fixture-task',self.refresh)
        self.manager.notify_saved('fixture-task');self.wait()
        next_task={**self.task,'id':'next-task'};self.core.store.put('tasks',next_task)
        self.core.store.put('leads',{'id':'next-lead','tenant_id':'fixture-tenant','cloud_owner':'fixture-owner',
            'task_id':'next-task','platform':'xiaohongshu','text':'new explicit task','content_title':'new post',
            'note_url':'https://www.xiaohongshu.com/explore/223456789012345678901234'})
        self.manager.authorize_collection(self.user,'fixture-store','next-task',self.refresh)
        self.assertTrue(self.manager.notify_saved('next-task'))
        end=time.monotonic()+5
        while time.monotonic()<end:
            row=self.manager.execute('analysis_queue_read',self.user,'fixture-store',{'storeId':'fixture-store','taskId':'next-task'},self.refresh)
            if not row['running'] and row['counts']['analyzed']==1:break
            time.sleep(.01)
        self.assertEqual(row['counts']['analyzed'],1)

    def test_remote_identity_only_on_resume_and_provider_submission_boundaries(self):
        self.leads(21)
        for _ in range(10):self.call('analysis_queue_read')
        self.assertEqual(self.fresh_refresh_calls,0)
        self.call('analysis_queue_resume',confirmed=True);self.wait()
        models=len([op for op,data in self.calls if op=='intent_analyze'])
        self.assertEqual(models,2)
        self.assertEqual(self.fresh_refresh_calls,1+models*2,'Only resume plus provider before/after may refresh remote identity')

def deny(*a,**kw):raise AssertionError('Real network/CLI forbidden')

if __name__=='__main__':
    stream=io.StringIO()
    with patch.object(socket.socket,'connect',deny),patch('subprocess.Popen',side_effect=deny):
        result=unittest.TextTestRunner(stream=stream,verbosity=2).run(unittest.defaultTestLoader.loadTestsFromModule(sys.modules[__name__]))
    log=stream.getvalue();name='GREEN' if result.wasSuccessful() else 'RED'
    (EVIDENCE/(name+'.log')).write_text(log,'utf-8')
    report={'status':'PASS' if result.wasSuccessful() else 'FAIL','tests':result.testsRun,'errors':len(result.errors),'failures':len(result.failures),
        'controller':str(candidate_path),'controllerSha256':hashlib.sha256(candidate_path.read_bytes()).hexdigest(),
        'businessSource':str(R/'resources/platform-runtime/vendor-src/assistant/business.py'),
        'businessSha256':hashlib.sha256((R/'resources/platform-runtime/vendor-src/assistant/business.py').read_bytes()).hexdigest(),
        'realNetworkOrProviderOrCliCalls':0,'productionDataAccess':0}
    (EVIDENCE/'CONTROLLER-CHECKS.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n','utf-8');print(log)
    raise SystemExit(0 if result.wasSuccessful() else 1)
