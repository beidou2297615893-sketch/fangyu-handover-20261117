"""Consistent formal SQLite RO projections only; no Core or workflow imports."""
from pathlib import Path
from datetime import datetime,timezone
from copy import deepcopy
import ast,hashlib,json,re,sqlite3,sys

sys.dont_write_bytecode=True
A=Path(__file__).resolve().parent;W=A.parents[1];P=W.parents[1]
N=P/'work/ui-native-r57'
read=lambda p:json.loads(p.read_text('utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
binding=read(N/'state/production-workspace.json');frozen=read(N/'FROZEN.json')
R=Path(frozen['release']);source=R/'resources/platform-runtime/platform_runtime.py'
tenant='cloud-'+hashlib.sha256((binding['environment_id']+'\n'+binding['company_id']).encode()).hexdigest()[:24]
owner=binding['owner'];task_id='a7a8d0ac0aa14fbcb119d37d2f36cbc1'
tree=ast.parse(source.read_text('utf-8-sig'));cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='PlatformRuntime')
methods=[n for n in cls.body if isinstance(n,ast.FunctionDef) and n.name in ('_task_scope','_collection_binding','_analysis_confirmed')]
space={'datetime':datetime,'deepcopy':deepcopy,'json':json,'hashlib':hashlib,'re':re}
exec(compile(ast.fix_missing_locations(ast.Module(body=[ast.ClassDef(name='Projection',bases=[],keywords=[],body=methods,decorator_list=[])],type_ignores=[])),'<actual-read-only-projections>','exec'),space)
projection=space['Projection']
blockfn=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='analysis_blocks_new_batch')
exec(compile(ast.Module(body=[blockfn],type_ignores=[]),'<actual-admission-helper>','exec'),space)
hold_codes=ast.literal_eval(next(n.value.args[0] for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='_COLLECTION_ANALYSIS_HOLD_CODES' for t in n.targets)))
whitespace=''.join(chr(i) for i in range(0x3100) if chr(i).isspace())
db=sqlite3.connect((Path(binding['data_dir'])/'workspace.sqlite3').as_uri()+'?mode=ro',uri=True,timeout=3)
db.row_factory=sqlite3.Row
try:
    db.execute('PRAGMA query_only=ON');db.execute('BEGIN')
    def rows(entity):return [json.loads(r[0]) for r in db.execute('SELECT body FROM records INDEXED BY scope WHERE entity=? AND tenant_id=?',(entity,tenant))]
    tasks=rows('tasks');task=next(v for v in tasks if v['id']==task_id)
    task_lookup={r['id']:r for r in tasks}
    pages=rows('workbench_collection_page_analysis_v1')
    jobs=rows('ai_jobs');jobs_lookup={v['id']:v for v in jobs}
    runs=rows('workbench_collection_run_v1')
    attempts=rows('ai_attempts')
    controls=rows('ui_task_analysis_control_v1')
    entities=[{'entity':r[0],'count':r[1]} for r in db.execute("SELECT entity,count(*) FROM records WHERE tenant_id=? AND (entity LIKE '%collection%' OR entity LIKE '%progress%' OR entity LIKE '%analysis%') GROUP BY entity",(tenant,))]
    leads=list(db.execute("""SELECT id,json_extract(body,'$.task_id') AS task_id,
        json_extract(body,'$.cloud_owner') AS owner,coalesce(json_extract(body,'$.demo'),0) AS demo,
        coalesce(json_extract(body,'$.manual_intent'),'') NOT IN ('','{}','[]',0) AS has_manual,
        json_extract(body,'$.manual_intent.status') AS manual_status,json_extract(body,'$.manual_intent.level') AS manual_level,
        coalesce(json_extract(body,'$.ai_intent'),'') NOT IN ('','{}','[]',0) AS has_ai,
        json_extract(body,'$.ai_intent.status') AS ai_status,json_extract(body,'$.ai_intent.level') AS ai_level,
        json_type(body,'$.text')='text' AND length(trim(json_extract(body,'$.text'),?))>0 AS has_text
        FROM records INDEXED BY scope WHERE entity='leads' AND tenant_id=?""",(whitespace,tenant)))
finally:db.close()
lead_lookup={r['id']:r for r in leads}
def digest(value):return hashlib.sha256(json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
held=set()
for a in attempts:
    if a.get('owner')==owner and a.get('operation')=='intent_analyze' and a.get('state') in ('unknown','submitted','response_received'):
        held.update(a.get('lead_digests') or [])
def classified(r):
    if r is None:return 'missingRecord'
    field='manual' if r['has_manual'] else 'ai'
    if projection._analysis_confirmed({'status':r[field+'_status'],'level':r[field+'_level']}):return 'confirmed'
    if r['has_manual'] or r['has_ai'] or digest([tenant,owner,r['id']]) in held:return 'held'
    if not r['has_text']:return 'missingText'
    return 'processable'
def summarize(values):
    counts={k:0 for k in ('confirmed','held','missingText','processable','missingRecord')}
    for row in values:counts[classified(row)]+=1
    return {'total':len(values),**counts}
safe_code=lambda v:v if isinstance(v,str) and re.fullmatch('[A-Z_a-z]{0,80}',v) else 'other'
page_reports=[]
for page in pages:
    if page.get('owner')!=owner:continue
    target=task_lookup.get(page['id']);ids=page.get('lead_ids') or []
    matched=bool(target and page.get('binding')==projection._collection_binding(target))
    job=jobs_lookup.get(page['id']) or {}
    page_reports.append({'currentTask':page['id']==task_id,'taskHash':hashlib.sha256(page['id'].encode()).hexdigest()[:12],
        'ledgerStatus':page.get('status'),'ledgerCode':safe_code(page.get('code','')),'ledgerLeadIdCount':len(ids),'ledgerUniqueLeadIdCount':len(set(ids)),
        'bindingMatchesActualFrozenProjection':matched,'taskScopeProjectionValid':bool(target and projection._task_scope(target)),
        'ledgerLeadClassifications':summarize([lead_lookup.get(ident) for ident in ids]),
        'confirmedAiJob':{'status':job.get('status'),'code':safe_code(job.get('code','')),'pending':job.get('pending'),
            'sameOwner':job.get('owner')==owner,'sameTenant':job.get('tenant_id')==tenant},
        'actualAnalysisBlocksNewBatch':space['analysis_blocks_new_batch'](None if page.get('status')=='completed' else page if matched else {'status':'pending','code':'AI_CONTEXT_REQUIRED'},job),
        'ledgerUpdatedAt':page.get('updated_at')})
current=[r for r in leads if r['task_id']==task_id and r['owner']==owner and not r['demo']]
counts=summarize(current);backlog=counts['total']-counts['confirmed']
run_reports=[{'status':r.get('status'),'stopReason':safe_code(r.get('stop_reason','')),'analysisHold':r.get('analysis_hold'),
    'pages':r.get('pages'),'units':r.get('units'),'updatedAt':r.get('updated_at'),
    'messageMentions200':bool(re.search('200',str(r.get('message',''))))} for r in runs if r.get('id')==task_id and r.get('owner')==owner]
report={'atUtc':datetime.now(timezone.utc).isoformat(),'releaseId':frozen['release_id'],'frozenRuntimeSha256':sha(source),
    'consistentReadTransaction':True,'queryOnly':True,'formalCoreConstructed':False,'formalWrites':0,'cloudModelPlatformOrNativeActions':0,
    'currentTask':{'status':task.get('status'),'pauseReason':safe_code(task.get('pause_reason','')),'lastMessageMentions200':bool(re.search('200',str(task.get('last_message','')))),
        'classification':counts,'snapshotBacklogAddedMinusConfirmed':backlog,'above200BySnapshotFormula':backlog>=200},
    'collectionPendingLedgers':page_reports,'currentCollectionRunReceipts':run_reports,
    'currentUiAnalysisControls':[{k:r.get(k) for k in ('status','code','phase','heldStatusCode','updated_at')} for r in controls if r.get('taskId')==task_id and r.get('owner')==owner],
    'entityCounts':entities,'dataOutputPolicy':'Counts and safe status fields only; no comment text, names, account identifiers, credentials or raw lead IDs serialized.'}
path=A/'FORMAL-BACKPRESSURE-ROOT-CAUSE.json';path.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n','utf-8')
print(json.dumps(report,ensure_ascii=False))
