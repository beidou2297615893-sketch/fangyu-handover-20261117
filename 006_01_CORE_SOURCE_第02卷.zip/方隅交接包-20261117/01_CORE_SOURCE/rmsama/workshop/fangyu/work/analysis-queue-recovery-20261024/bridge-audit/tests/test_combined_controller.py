"""Real controller + extracted real bridge; in-memory records, no Core instance."""
import copy
import importlib.util
from pathlib import Path
import sys
import types
import unittest
from test_bridge_contract import fixture, ROOT
sys.dont_write_bytecode=True
project=ROOT.parents[1]/'parallel-integration-20261018/final-integration/candidate-unified-v100/project'
sys.path.insert(0,str(project/'work/ui-runtime-r55/src'))
path=ROOT.parent/'core-audit/candidate/analysis_queue_runtime.py'
spec=importlib.util.spec_from_file_location('combined_real_controller',path)
controller=importlib.util.module_from_spec(spec);spec.loader.exec_module(controller)

class Store:
    def __init__(self):self.rows={};self.writes=0
    def get(self,entity,ident):return copy.deepcopy(self.rows.get((entity,ident)))
    def list(self,entity,tenant):return [copy.deepcopy(v) for (e,_),v in self.rows.items() if e==entity and v.get('tenant_id')==tenant]
    def list_task_leads(self,tenant,task):return [r for r in self.list('leads',tenant) if r.get('task_id')==task]
    def put(self,entity,row):self.writes+=1;self.rows[(entity,row['id'])]=copy.deepcopy(row)

def combined():
    f=fixture();store=Store();f.core.store=store
    f.profile['_workbench_store_id']='store1'
    store.rows[('users','u1')]=copy.deepcopy(f.user)
    store.rows[('tasks','task1')]=copy.deepcopy(f.task)
    store.rows[('accounts','account1')]={'id':'account1','tenant_id':'tenant','cloud_owner':'tester','store_id':'store1','platform':'xiaohongshu'}
    for i in range(209):store.rows[('leads',str(i))]={'id':str(i),'tenant_id':'tenant','cloud_owner':'tester','task_id':'task1','text':'合成评论 '+str(i)}
    store.rows[('ai_attempts','held')]={'id':'held','tenant_id':'tenant','owner':'tester','operation':'intent_analyze','state':'unknown','lead_digests':[controller._digest(['tenant','tester',str(i)]) for i in range(9)]}
    store.rows[('ai_jobs','task1')]={'id':'task1','tenant_id':'tenant','pending':19,'status':'paused','code':'PRODUCT_REQUEST_UNKNOWN'}
    f.core._task_access=lambda *args:None
    f.plan_checks=[]
    executor=types.SimpleNamespace(core=f.core,tenant='tenant',owner='tester',user_id='u1',
        server=types.SimpleNamespace(company={'id':'fangyu-apartment-client'}),
        ai=types.SimpleNamespace(attempts=types.SimpleNamespace(host_context=lambda:{'host':'fixture'})),
        _analysis_visible_leads=lambda user,task,rows:rows,
        _require_product_feature=lambda feature:f.plan_checks.append(feature))
    f.platform_runtime.core=f.core
    f.platform_runtime.service=types.SimpleNamespace(executor=executor)
    f.platform_runtime.closed=False
    f.platform_runtime._collection_binding=lambda task:{k:task.get(k) for k in ('id','tenant_id','cloud_owner','store_id','platform','account_id')}
    f._analysis_queue_factory=controller.AnalysisQueueRuntime
    return f

class Combined(unittest.TestCase):
    def test_real_controller_read_uses_actual_inventory_and_no_authorization(self):
        f=combined()
        value=f._analysis_queue_dispatch('analysis_queue_read',{'storeId':'store1','taskId':'task1'},'fixture-token')['analysisQueue']
        self.assertEqual(value['counts'],{'total':209,'pending':200,'held':9,'analyzed':0,'missingText':0})
        self.assertIsNone(f._analysis_queue.active)
        self.assertEqual(f._analysis_queue.authorizations,{})
        self.assertEqual(f.core.store.writes,0)
        self.assertEqual(f.plan_checks,[])
        f._analysis_queue.close()
    def test_real_controller_local_authorization_does_not_start_worker(self):
        f=combined()
        f._identity=lambda *a,**kw:(_ for _ in ()).throw(AssertionError('network identity during local authorization'))
        def start(user,payload):
            c=f.platform_runtime._analysis_collection_authorization.callback(user,'task1')
            f.platform_runtime._analysis_queue_controller=c
            return {'taskId':'task1'}
        f.platform_runtime.start_acquisition=start
        f._run_collection_with_analysis('start_acquisition',f.user,{},'fixture-token',f.profile)
        self.assertIsNone(f._analysis_queue.active)
        self.assertTrue(f._analysis_queue.owns_collection('task1'))
        self.assertEqual(f.core.store.writes,0)
        self.assertEqual(f.plan_checks,['intent_analysis'])
        f._analysis_queue.close()

if __name__=='__main__':unittest.main(verbosity=2)
