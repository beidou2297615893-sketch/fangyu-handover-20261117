import * as acquire from './acquire.mjs';
import {openLivestream} from './livestream-acquisition.mjs';
import {sourceSelection,openAcquisitionSources} from './acquisition-source.mjs';
import {senderName} from './reply-account.mjs';
const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const kinds={note_links:['指定笔记','从你指定的笔记读取可见评论。'],profiles:['博主主页','从你指定博主的可见笔记读取评论。'],own_interactions:['我的互动','查看本人账号可见的评论与互动。']};
const label=kind=>kind==='keywords'||!kind?'关键词搜索':kinds[kind]?.[0]||'已保存来源';
const scope=s=>JSON.stringify([s.authEpoch||0,s.session?.user?.tenant_id||'',s.user,s.session?.user?.role||'',s.storeId,s.activePlatform||'xiaohongshu',s.platformAccountSelections?.[s.activePlatform||'xiaohongshu']||s.platform?.platforms?.find(p=>p.id===(s.activePlatform||'xiaohongshu'))?.accountId||'']);
const accounts=s=>(s.platform?.accounts||[]).filter(a=>a.platform===(s.activePlatform||'xiaohongshu'));
const live=s=>s.platform?.acquisition||{};
const unknown=s=>Boolean(s.acquisitionAttempt?.unconfirmed||s.pendingAction?.unconfirmed||['submitted','unconfirmed'].includes(s.platform?.lastRequest?.state));
const running=s=>['running','queued','pausing','resuming','stopping'].includes(live(s).status);
function chosen(s){const v=sourceSelection(s);return v&&v.selectedFor==='diversified'&&v.selectedAuthEpoch===(s.authEpoch||0)&&kinds[v.source?.kind]?v:null;}
function canStart(s,choice){return Boolean(s.connection==='connected'&&s.session&&s.storeId&&!s.busy&&!s.connectionRecovering&&!s.platformError&&!s.sourceInteractionPending&&!unknown(s)&&!running(s)&&live(s).canStart!==false&&choice?.preview?.canStart===true&&choice.previewDigest&&accounts(s).some(a=>a.id===choice.accountId&&a.status==='ready'));}
function currentTask(s){const a=live(s),t=a.taskScope;if(!a.taskId)return '<p class="da-muted">当前门店暂无采集任务。</p>';return `<p><strong>当前任务：${esc(label(t?.source?.kind))}</strong><span>${esc(accounts(s).find(a=>a.id===t?.accountId)?.name||'原任务账号')} · ${esc({running:'正在采集',paused:'已暂停',completed:'已结束',stopped:'已停止',failed:'已中断'}[a.status]||'状态待核对')}</span></p><p class="da-muted">切换页面或选择下一次来源，不会改变这个任务的方式、账号和断点。</p>`;}
function choose(ctx,kind){
  if(ctx.state.busy||unknown(ctx.state)||ctx.state.sourceInteractionPending)return ctx.toast('请先核对原操作结果；当前任务与草稿均已保留。');
  return openAcquisitionSources(ctx,{kinds:Object.keys(kinds),initialKind:kind,expectedPage:'diversified',selectionContext:{selectedFor:'diversified',selectedAuthEpoch:ctx.state.authEpoch||0}});
}
export function render(s){
  const v=chosen(s),a=live(s),account=accounts(s).find(a=>a.id===v?.accountId);
  const blocked=unknown(s)||s.sourceInteractionPending;
  const fresh=acquire.freshAcquisitionCapture?.(s);
  return `<div class="acquire-page da-page" data-page-diversified><section class="acquire-card da-current" aria-label="当前任务与下次方式">${currentTask(s)}</section><section class="acquire-card da-choices" aria-label="选择多样化获客方式"><h2>选择下一次获客方式</h2><p class="da-muted">先配置来源与账号，再核对并明确开始。仅在当前门店与平台的授权范围内读取。</p><div class="da-kind-grid">${Object.entries(kinds).map(([kind,[name,description]])=>`<button type="button" data-diverse-kind="${kind}" ${s.busy||blocked?'disabled':''}><strong>${name}</strong><span>${description}</span><small>配置来源与账号 →</small></button>`).join('')}</div><button type="button" class="cs-secondary" data-diverse-live ${s.busy?'disabled':''}>直播获客 · 明确选择房间与窗口</button></section><section class="acquire-card da-next" aria-label="下次已选方式"><div><span class="da-muted">下次已选方式</span><h2>${v?esc(label(v.source.kind)):'尚未选择'}</h2><p>${v?`${esc(senderName(account))} · 已核对 ${esc(v.preview?.sourceCount||1)} 个来源`:'请选择上方方式，核对来源后应用。'}</p><p class="da-muted">${v?'只作为下次新任务的已确认草稿，当前任务保持不变。':'关键词搜索仍在左侧“获客”页。'}</p></div><div class="da-next-actions"><button type="button" data-diverse-configure ${s.busy||blocked?'disabled':''}>${v?'修改来源与账号':'选择来源与账号'}</button><button type="button" class="acquire-start" data-diverse-start ${canStart(s,v)?'':'disabled'}>开始多样化获客</button>${fresh?'<button type="button" data-diverse-fresh>保留旧批，开始新一轮</button>':''}</div></section>${blocked?'<p class="da-warning" role="status">原操作结果尚待核对，请先按原编号核对；不会为切换方式另发请求。</p>':''}${s.platformError?`<p class="da-warning" role="alert">${esc(s.platformError)}</p>`:''}${acquire.renderAcquisitionProgress(s,a)}${a.canPause||a.canResume?`<section class="acquire-card da-task-actions"><span>操作当前原任务</span><button type="button" class="acquire-pause" data-acquire-pause ${s.busy?'disabled':''}>${a.canPause?'暂停当前任务':'继续当前原任务'}</button></section>`:''}</div>`;
}
export function bind(root,ctx){
  const cleanup=acquire.bind(root,ctx);
  root.querySelector('[data-diverse-live]')?.addEventListener('click',()=>openLivestream(ctx));
  root.querySelectorAll('[data-diverse-kind]').forEach(button=>button.addEventListener('click',()=>choose(ctx,button.dataset.diverseKind)));
  root.querySelector('[data-diverse-configure]')?.addEventListener('click',()=>choose(ctx,chosen(ctx.state)?.source?.kind));
  root.querySelector('[data-diverse-fresh]')?.addEventListener('click',()=>acquire.openFreshAcquisition?.(ctx));
  root.querySelector('[data-diverse-start]')?.addEventListener('click',()=>{
    const s=ctx.state,v=chosen(s);if(!canStart(s,v)||ctx.actions.hasUnconfirmed?.())return;
    const expected=scope(s),stamp=JSON.stringify(v),account=accounts(s).find(a=>a.id===v.accountId);
    ctx.modal({title:'确认开始多样化获客',html:`<p>本次方式：<strong>${esc(label(v.source.kind))}</strong></p><p>采集账号：<strong>${esc(senderName(account))}</strong></p><p>仅使用已核对的来源与评论范围，新建任务后以真实回执为准。</p>`,confirmLabel:'确认开始',onConfirm:()=>{
      const current=chosen(s);if(s.page!=='diversified'||scope(s)!==expected||JSON.stringify(current)!==stamp||!canStart(s,current)||ctx.actions.hasUnconfirmed?.()){ctx.toast('门店、账号、来源或原任务状态已变化，请重新核对。');return false;}
      return ctx.actions.startAcquisition?.({sourceKind:current.source.kind});
    }});
  });
  return cleanup;
}
// Compose the original page so independently reviewed acquire/fresh behavior is retained.
export const keywordPage={
 render(s){
  const selected=sourceSelection(s);
  return `<div class="da-keyword-context" role="status"><strong>本页使用关键词搜索</strong>${selected?.source?`<span>另已选“${esc(label(selected.source.kind))}”，本页开始前请明确改用关键词；可在下方选择关键词采集账号。</span>`:'<span>使用当前门店已选词库，开始前明确确认。</span>'}</div>`+acquire.render(s);
 },
 bind(root,ctx){
  const s=ctx.state,button=root.querySelector('[data-acquire-start]');
  if(sourceSelection(s)?.source&&!unknown(s)&&!running(s)&&button&&!button.disabled)button.querySelector('span').textContent='确认关键词获客';
  button?.addEventListener('click',event=>{
    if(s.connection==='preview'||unknown(s))return;
    if(live(s).canResume&&!live(s).taskScope?.source&&!sourceSelection(s)?.source)return;
    if(acquire.freshAcquisitionCapture?.(s))return;
    event.stopImmediatePropagation();
    if(s.busy||s.connectionRecovering||s.platformError||running(s)||live(s).canStart===false||ctx.actions.hasUnconfirmed?.())return;
    const expected=scope(s),selection=sourceSelection(s),stamp=JSON.stringify(selection),accountId=s.platformAccountSelections?.[s.activePlatform||'xiaohongshu']||s.platform?.platforms?.find(p=>p.id===(s.activePlatform||'xiaohongshu'))?.accountId;
    ctx.modal({title:'确认使用关键词获客',html:'<p>本次使用当前门店的已选关键词和帖子时间范围。</p><p>此前多样化来源与正在执行任务不会被悄悄复用。新任务以确认后的真实回执为准。</p>',confirmLabel:'确认关键词获客',onConfirm:()=>{
      if(s.page!=='acquire'||scope(s)!==expected||s.busy||unknown(s)||running(s)||live(s).canStart===false||ctx.actions.hasUnconfirmed?.()||JSON.stringify(sourceSelection(s))!==stamp){ctx.toast('当前范围或任务状态已变化，请重新确认。');return false;}
      ctx.update(state=>{state.acquire??={};state.acquire.sourceSelection=selection?{...selection,accountId,source:null,commentWindow:{mode:'all'},execution:{mode:'once'},preview:null,previewDigest:undefined}:null;});
      return ctx.actions.startAcquisition?.({sourceKind:'keywords'});
    }});
  },{capture:true});
  return acquire.bind(root,ctx);
 }
};
