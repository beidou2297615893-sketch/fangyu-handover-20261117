from pathlib import Path
root=Path(__file__).resolve().parents[1]/'candidate/work/ui-approved-implementation/ui-preview'
def replace(name,old,new):
    p=root/name;s=p.read_text(encoding='utf-8-sig')
    if new in s:return
    assert s.count(old)==1,(name,old,s.count(old))
    p.write_text(s.replace(old,new),encoding='utf-8',newline='\n')
replace('pages/acquire.mjs','${renderFreshAcquisition(state)}${renderAcquisitionProgress(state,live)}',
        '${renderSavedCommentAnalysis(state)}${renderFreshAcquisition(state)}${renderAcquisitionProgress(state,live)}')
replace('app.mjs','const actions={publicContactAction:',
        'const actions={analysisQueueAction:(action,data)=>backend.analysisQueueAction(action,data),publicContactAction:')
replace('backend.mjs',"const keywordRead=action==='keyword_effect_read';",
        "const keywordRead=action==='keyword_effect_read';\n    const analysisLocal=['analysis_queue_read','analysis_queue_resume','analysis_queue_pause'].includes(action),analysisRead=action==='analysis_queue_read';")
replace('backend.mjs','const read=LIVE_ACTIONS.has(action)||',
        'const read=analysisLocal||LIVE_ACTIONS.has(action)||')
replace('backend.mjs',"const shortRead=['livestream_sources_read'",
        "const shortRead=analysisLocal||['livestream_sources_read'")
replace('backend.mjs',"catch { if(intentCorrection&&!intentRead)",
        "catch { if(analysisLocal&&!analysisRead)throw new WorkbenchError('评论分析的操作回执尚未确认，请刷新原任务分析状态。','ANALYSIS_QUEUE_RESULT_UNCONFIRMED');if(intentCorrection&&!intentRead)")
replace('backend.mjs',"if(error instanceof WorkbenchError)throw error;\n      if(intentCorrection&&!intentRead)",
        "if(error instanceof WorkbenchError)throw error;\n      if(analysisLocal&&!analysisRead)throw new WorkbenchError('评论分析的操作回执尚未确认，请刷新原任务分析状态。','ANALYSIS_QUEUE_RESULT_UNCONFIRMED');\n      if(intentCorrection&&!intentRead)")
replace('backend.mjs','return {...safety,livestreamAction:',
        "return {...safety,analysisQueueAction:(action,data)=>{if(!['analysis_queue_read','analysis_queue_resume','analysis_queue_pause'].includes(action))throw new WorkbenchError('评论分析操作无效','INPUT_INVALID');return request(action,data);},livestreamAction:")
