"""Read-only independent frozen-package and CAS installer review.

Never imports/runs the installer, native entry, formal Core, cloud or platform.
The only constructor execution injects empty in-memory AppServer/Vault/Core.
"""
from pathlib import Path, PurePosixPath
from datetime import datetime,timezone
from types import SimpleNamespace, ModuleType
from unittest.mock import patch
import ast, copy, hashlib, inspect, json, os, sys, threading

sys.dont_write_bytecode=True
A=Path(__file__).resolve().parent;W=A.parent;P=W.parents[1];PACK=W/'package'
F=P/'work/parallel-integration-20261018/final-integration/candidate-unified-v104'
OLD=P/'work/parallel-integration-20261018/final-integration/candidate-unified-v103'
N=P/'work/ui-native-r57'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text('utf-8-sig'))
pins=read(PACK/'ROOT-FINAL-PINS-V104.json');stage=read(F/'STAGED.json');R=Path(stage['release'])
checks=[]
def check(name,condition,detail=None):
    checks.append({'name':name,'pass':bool(condition),**({'detail':detail} if detail is not None else {})})
    if not condition:raise AssertionError(name)
def scoped(base,relative):
    rel=PurePosixPath(relative)
    assert not rel.is_absolute() and '..' not in rel.parts and '\\' not in relative
    path=(base/relative).resolve();assert path.is_relative_to(base.resolve());return path
def extract(path,cls,name,scope):
    tree=ast.parse(path.read_text('utf-8-sig'));owner=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name==cls)
    node=next(n for n in owner.body if isinstance(n,ast.FunctionDef) and n.name==name)
    exec(compile(ast.Module(body=[node],type_ignores=[]),str(path)+':'+name,'exec'),scope)
    return scope[name],node

app=R/'resources/platform-runtime/vendor-src/app.py'
runtime=R/'resources/platform-runtime/platform_runtime.py'
service=R/'resources/platform-runtime/vendor-src/assistant/service.py'
app_init,app_node=extract(app,'AppServer','__init__',{})
signature=inspect.signature(app_init)
check('actual-AppServer-manual-owned-read-default-False',signature.parameters['manual_owned_read_start'].default is False)
check('actual-AppServer-assignment-preserves-manual-parameter',any(isinstance(n,ast.Assign) and isinstance(n.value,ast.Name) and n.value.id=='manual_owned_read_start' and any(isinstance(t,ast.Attribute) and t.attr=='manual_owned_read_start' for t in n.targets) for n in ast.walk(app_node)))

constructor_calls=[]
class Vault:
    def __init__(self,*args):pass
    def read(self):return {'state':'bound','device':{'id':'synthetic-device','owner':'synthetic-owner'},'token':'synthetic'}
class FakeServer:
    def __init__(self,*args,**kwargs):
        bound=signature.bind(None,*args,**kwargs);bound.apply_defaults();constructor_calls.append(dict(kwargs))
        self.manual_owned_read_start=bound.arguments['manual_owned_read_start']
        self.company=kwargs['trusted_company']
        self.core=SimpleNamespace(store=SimpleNamespace(directory=A/'unused-synthetic-constructor'),continuous=SimpleNamespace())
        self.integrations=SimpleNamespace()
class FakeService:pass
service_init,_=extract(service,'AssistantService','__init__',{'threading':threading,'CloudTransport':object,'BusinessExecutor':object,'DeviceVault':Vault})
FakeService.__init__=service_init
fake_scheduler=ModuleType('core.source_scheduler');fake_scheduler.SourceScheduler=lambda runtime:SimpleNamespace(tick=lambda:None)
class Runtime: 
    _acquire_instance_lock=lambda self:None
    _release_instance_lock=lambda self:None
runtime_init,runtime_node=extract(runtime,'PlatformRuntime','__init__',{
    'Path':Path,'os':os,'json':json,'deepcopy':copy.deepcopy,'threading':threading,'DIRECTORY':runtime.parent,
    'COMPANY_ID':'fangyu-apartment-client','PlatformRuntimeError':RuntimeError,
    '_modules':lambda project:(SimpleNamespace(AppServer=FakeServer),SimpleNamespace(AssistantService=FakeService)),
    '_browser_login_helper_valid':lambda *a:True})
Runtime.__init__=runtime_init
company={'id':'fangyu-apartment-client','edition':'customer','personalMode':False,'authMode':'managed',
    'managedWorkspace':{'environment_id':'synthetic','endpoint':'https://example.invalid'}}
fake_core=ModuleType('core');fake_core.__path__=[]
with patch.dict(sys.modules,{'core':fake_core,'core.source_scheduler':fake_scheduler}):
    rt=Runtime(F/'project',company=company,data_dir=A/'unused-synthetic-constructor')
check('actual-Runtime-default-construction-supports-cold-background-start',
    rt.service.manual_owned_read_start is False and rt.service.explicit_local is True and rt.service.executor is None
    and rt.started is False and constructor_calls[0]['defer_startup_recovery'] is True
    and constructor_calls[0]['defer_platform_setup'] is True and 'manual_owned_read_start' not in constructor_calls[0],
    {'manualOwnedReadStart':rt.service.manual_owned_read_start,'explicitLocal':rt.service.explicit_local,
     'deferredStartupRecovery':constructor_calls[0]['defer_startup_recovery'],'formalCoreConstructed':False})

initial={str(p):sha(p) for p in (PACK/'ROOT-FINAL-PINS-V104.json',F/'STAGED.json',F/'UNIFIED-PINS.json',R/'RELEASE.json',W/'install_verified_f104.py')}
check('root-pins-match-staged-unified-manifest',pins['releaseId']==stage['release_id']==R.name and
      pins['unifiedPinsSha256']==sha(F/'UNIFIED-PINS.json') and pins['stagedSha256']==sha(F/'STAGED.json') and
      pins['manifestSha256']==sha(R/'RELEASE.json') and stage['manifest_sha256'].lower()==pins['manifestSha256'])
closure=read(F/'UNIFIED-PINS.json');rows=closure['files'];paths=[row['path'] for row in rows]
check('full-closure-paths-unique',len(paths)==len(set(paths)))
for row in rows:
    p=scoped(F/'project',row['path'])
    assert p.is_file() and p.stat().st_size==row['bytes'] and sha(p)==row['sha256'].lower(),row['path']
check('full-frozen-closure-byte-and-size-verified',True,len(rows))
manifest=read(R/'RELEASE.json');manifest_paths=[]
for row in manifest['files']:
    p=scoped(R,row['path']);manifest_paths.append(row['path'])
    assert p.is_file() and p.stat().st_size==row['size'] and sha(p)==row['sha256'].lower(),row['path']
check('release-manifest-complete-and-unique',len(manifest_paths)==len(set(manifest_paths)) and
      set(manifest_paths)=={p.relative_to(R).as_posix() for p in R.rglob('*') if p.is_file() and p!=R/'RELEASE.json'})
composition=read(PACK/'ROOT-COMPOSITION-V104.json')
check('exact-six-product-sources-candidate-project-freeze',len(composition['changes'])==6)
for row in composition['changes']:
    assert sha(Path(row['candidate']))==sha(F/'project'/row['relativePath'])==sha(R/row['releaseRelativePath'])==row['sha256']
old_manifest=read(Path(read(OLD/'STAGED.json')['release'])/'RELEASE.json')
old_map={r['path']:r['sha256'].lower() for r in old_manifest['files']}
new_map={r['path']:r['sha256'].lower() for r in manifest['files']}
release_changed=sorted(k for k in set(old_map)|set(new_map) if old_map.get(k)!=new_map.get(k))
check('actual-release-delta-only-six-reviewed-source-files',release_changed==sorted(row['releaseRelativePath'] for row in composition['changes']))
old_closure={r['path']:r['sha256'] for r in read(OLD/'UNIFIED-PINS.json')['files']}
new_closure={r['path']:r['sha256'] for r in rows}
common_changed=sorted(k for k in old_closure.keys()&new_closure.keys() if old_closure[k]!=new_closure[k])
check('shared-project-delta-only-six-reviewed-source-files',common_changed==sorted(row['relativePath'] for row in composition['changes']))
check('reply-and-original-runtime-model-attempt-files-unchanged',
    sha(R/'web/pages/reply-connected.mjs')=='92bda4b28c8fe91ae3ae789c137e14a940a16ce68e1ffc2dbeb521267b1476f5' and
    all(old_map[k]==new_map[k] for k in ('resources/platform-runtime/platform_runtime.py','resources/platform-runtime/vendor-src/app.py','resources/platform-runtime/vendor-src/assistant/service.py','customer_read_store.py')))
acceptance=read(A/'INDEPENDENT-ACCEPTANCE.json');combined=read(A/'COMBINED-STARTUP.json')
check('independent-combination-four-passes-bind-core-and-bridge',combined['passed'] and combined['sourceBytesStable'] and combined['testsRun']==4
    and sha(R/'resources/platform-runtime/analysis_queue_runtime.py') in combined['sources'].values()
    and sha(R/'workbench_backend.py') in combined['sources'].values())
for relative in ('core-audit/automatic-workspace-recovery','bridge-audit/automatic-workspace'):
    validation=W/relative/'evidence/VALIDATION.json';sealed=W/relative/'SEALED.json'
    assert validation.is_file() and sealed.is_file()
    seal=read(sealed)
    assert seal['sealed'] and seal['passed'] and seal['authorStopped'] and sha(validation)==seal['validationSha256']
    for row in seal['files']:assert sha(Path(row['candidate']))==row['sha256']
check('both-authors-sealed-validation-artifacts-present',True)

installer=W/'install_verified_f104.py';body=installer.read_text('utf-8');compile(body,str(installer),'exec')
gen=P/'work/parallel-integration-20261018/integration/entry/install_canonical_delegation.py'
check('fixed-generic-CAS-installer-digest',sha(gen)=='9909f60d16ad3eaed54b9f97ea0d275ad38510c679ba651ce05af44d920ed0f6')
check('actual-old-launcher-FROZEN-and-workspace-bindings-still-CAS-match',
    sha(N/'run_workbench.py')=='9660abf97c29f4b8816f79822386768cdc27a0ad9cc3aef8ee9a4fa99bf428a3' and
    sha(N/'FROZEN.json')=='075647e7911e7fa6cf160180b2d75e32c9e27d731c749250332937b1315df92c' and
    sha(N/'state/production-workspace.json')==sha(F/'project/work/ui-native-r57/state/production-workspace.json')=='14cf53964f5d44d123e989805ea741669ab3f05054e730ddcb299a0aac51a9cb')
check('installer-review-self-hash-full-closure-and-gates-binding',all(s in body for s in (
    "review['blockingFindings']==[]", "review['approvedForRootInstall'] is True", "review['installerSha256']==sha(Path(__file__).resolve())",
    "review['rootPinsSha256']==sha(PACK/'ROOT-FINAL-PINS-V104.json')", "review['rootGatesSha256']==sha(PACK/'ROOT-GATES-V104.json')",
    "for row in closure['files']:assert sha(F/'project'/row['path'])==row['sha256']", "for row in gates['evidence']:assert sha(Path(row['path']))==row['sha256']")))
check('wrapper-only-creates-exclusive-next-open-entry-no-data-or-process-actions',
      "candidate.open('xb')" in body and 'assert not entry.exists()' in body and 'installer.main()' in body and
      not any(s in body for s in ('subprocess.','terminate(','taskkill','sqlite3.','Core(','PlatformRuntime(')))
launcher=Path(stage['launcher']);text=launcher.read_text('utf-8');binding='14cf53964f5d44d123e989805ea741669ab3f05054e730ddcb299a0aac51a9cb'
assert sha(launcher)==stage['launcher_sha256'].lower()
needle="RELEASE = ROOT / 'releases/"+stage['release_id']+"'";assert text.count(needle)==1
text=text.replace(needle,"PROJECT_ROOT = ROOT.parent.parent / 'work/parallel-integration-20261018/final-integration/candidate-unified-v104/project'\nRELEASE = PROJECT_ROOT / 'work/ui-native-r57/releases/"+stage['release_id']+"'\nBINDING_SHA256 = '"+binding.upper()+"'")
assert text.count('project_root=ROOT.parent.parent')==1;text=text.replace('project_root=ROOT.parent.parent','project_root=PROJECT_ROOT')
needle="        pinned(RELEASE / 'RELEASE.json', MANIFEST_SHA256)";assert text.count(needle)==1
text=text.replace(needle,"        pinned(ROOT / 'state/production-workspace.json', BINDING_SHA256)\n        pinned(PROJECT_ROOT / 'work/ui-native-r57/state/production-workspace.json', BINDING_SHA256)\n"+needle)
compile(text,'reviewed-v104-next-open.py','exec')
check('exact-version-launcher-rewrite-compiles-and-binds-both-workspaces',True)
check('exclusive-install-artifacts-absent-before-approval',not (PACK/'entry-v104').exists() and
      not (N/('run_delegated_candidate.'+stage['release_id']+'.py')).exists())

gates_path=PACK/'ROOT-GATES-V104.json'
if not gates_path.exists():
    (A/'PACKAGE-PRE-GATES-V104.json').write_text(json.dumps({'status':'WAIT_FOR_ROOT_GATES','checks':checks,'closureFilesVerified':len(rows),'rootPinsSha256':sha(PACK/'ROOT-FINAL-PINS-V104.json')},ensure_ascii=False,indent=2),'utf-8')
    print(json.dumps({'status':'WAIT_FOR_ROOT_GATES','checksPassed':len(checks),'closureFilesVerified':len(rows)}));raise SystemExit(0)
gates=read(gates_path);initial[str(gates_path)]=sha(gates_path)
check('exact-final-root-gates-pass',gates['status']=='PASS_F104_AUTOMATIC_WORKSPACE_ANALYSIS' and gates['releaseId']==stage['release_id'])
for row in gates['evidence']:assert sha(Path(row['path']))==row['sha256']
check('all-final-gate-evidence-digests-match',True,len(gates['evidence']))
frozen=read(W/'verification-f104/ROOT-RESULT.json')
frozen_checks={row['name']:row for row in frozen['checks']}
check('frozen-native-check-selftest-and-combination-processes-pass',
      frozen['releaseId']==stage['release_id'] and len(frozen_checks)==4 and
      all(frozen_checks[name]['exitCode']==0 for name in ('native-check','native-self-test','cold-start-combination'))
      and frozen['changedSourceBytesStable'] is True)
core_rows=[(W/'verification-f104/core/workspace-sources/evidence/WORKSPACE-CHECKS.json',26),
           (W/'verification-f104/core/task-regression/CONTROLLER-CHECKS.json',18),
           (W/'verification-f104/core/legacy-regression/GREEN.json',12)]
for path,cases in core_rows:
    result=read(path)
    assert result.get('passed',result.get('status')=='PASS') is True
    assert result.get('tests',result.get('checks'))==cases and result['errors']==result['failures']==0
    assert result.get('controllerSha256',result.get('moduleSha256'))==sha(R/'resources/platform-runtime/analysis_queue_runtime.py')
check('frozen-core-26-18-12-raw-success-jsons-match-exact-module',True)
core_summary_error=None
original_core_run=frozen.get('originalWrapperRun',frozen_checks.get('automatic-core',{}))
if original_core_run.get('exitCode')!=0:
    raw=(W/'verification-f104/automatic-core.log').read_text('utf-8-sig')
    wrapper=(W/'core-audit/automatic-workspace-recovery/verify_workspace_candidate.ps1').read_text('utf-8-sig')
    assert original_core_run['exitCode']==1 and "Get-FileHash' is not recognized" in raw
    assert wrapper.index("'Legacy safety regression failed")<wrapper.index('controllerSha256=(Get-FileHash')
    assert frozen['status']=='PASS' and frozen['harnessOnlyFailure']['type']=='REPORT_WRITER_COMMAND_NOT_FOUND'
    assert frozen['harnessOnlyFailure']['originalExitCode']==1 and frozen['harnessOnlyFailure']['testsActuallyPassed']==56
    original=read(Path(frozen['originalWrapperFailurePreserved']))
    assert original['status']=='FAIL' and next(row for row in original['checks'] if row['name']=='automatic-core')==original_core_run
    assert sha(Path(original_core_run['path']))==original_core_run['sha256']
    assert frozen_checks['completed-core-test-evidence-and-report-audit']['exitCode']==0
    core_summary_error={'originalExitCode':1,'phase':'post-test Get-FileHash report summary',
        'verifiedRawSuccessfulCoreCases':[26,18,12],'originalLog':str(W/'verification-f104/automatic-core.log'),
        'disclosure':'The PowerShell wrapper exited 1 after all three successful test processes; this review does not change that exit code or claim that command succeeded.'}
    check('original-post-test-summary-error-retained-and-independently-explained',True,core_summary_error)
else:check('frozen-core-wrapper-process-passed',True)
frozen_combined=read(W/'verification-f104/combined/COMBINED-STARTUP.json')
check('frozen-combination-actual-package-four-passes',frozen_combined['passed'] and frozen_combined['sourceBytesStable'] and frozen_combined['testsRun']==4
      and frozen_combined['sources'][str(R/'resources/platform-runtime/analysis_queue_runtime.py')]==sha(R/'resources/platform-runtime/analysis_queue_runtime.py')
      and frozen_combined['sources'][str(R/'workbench_backend.py')]==sha(R/'workbench_backend.py'))
check('review-input-pins-stable',all(sha(Path(path))==digest for path,digest in initial.items()))
report={'status':'PASS_INDEPENDENT_F104_PACKAGE_REVIEW','blockingFindings':[],'approvedForRootInstall':True,
    'reviewedAtUtc':datetime.now(timezone.utc).isoformat(),'releaseId':stage['release_id'],
    'unifiedPinsSha256':sha(F/'UNIFIED-PINS.json'),'manifestSha256':sha(R/'RELEASE.json'),
    'rootPinsSha256':sha(PACK/'ROOT-FINAL-PINS-V104.json'),'rootGatesSha256':sha(gates_path),'installerSha256':sha(installer),
    'checks':checks,'closureFilesVerified':len(rows),'directGateEvidenceFilesVerified':len(gates['evidence']),
    'changedSourceFiles':common_changed,'actualReleaseDelta':release_changed,'defaultStartupMode':{'manualOwnedReadStart':False,'explicitLocal':True,'executorInitiallyNone':True},
    'installerReview':'Wrapper pins old F103 launcher/FROZEN, both workspace bindings, full F104 closure, gate evidence, independent review and installer self-hash. Existing hash-pinned transaction backs up exclusively, CAS-replaces only next-open launcher/FROZEN and bounds rollback. No current process, customer data, cloud, model, collection or sending action.',
    'currentExecutionLimit':'Frozen and author/independent combination tests are owned fixtures with synthetic model transport. Current live Native is F103 until user reopens; no real F104 model result or billing proven by this review.',
    'retainedHarnessFailure':core_summary_error,
    'productionDataWrites':0,'realCloudOrProviderOrCliCalls':0,'nativeWindowsOperated':0,'installerExecuted':False}
(PACK/'FINAL-PACKAGE-REVIEW-V104.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n','utf-8')
print(json.dumps({'status':report['status'],'checksPassed':len(checks),'closureFilesVerified':len(rows),'reviewSha256':sha(PACK/'FINAL-PACKAGE-REVIEW-V104.json')},ensure_ascii=False))
