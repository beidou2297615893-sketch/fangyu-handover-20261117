"""Cold empty queue capability; real F104 director and Runtime snapshot.

Frontend's existingOnly prepare is preserved and may subsequently warm service;
this suite tests capability independently, not a claim of permanent startup lock.
"""
import hashlib,io,json,socket,subprocess,unittest
from types import SimpleNamespace
import test_backpressure as bp
base=bp.base;runtime=bp.runtime;OUT=bp.OUT

class ColdCapability(bp.Backpressure):
    def cold_empty(self):
        self.seed(487,graded=True);self.seed(9,start=487);self.seed(14,start=496,missing=True)
        old=self.unknown(['lead-'+str(i) for i in range(487,496)])
        page=self.ledger(['lead-'+str(i) for i in range(487,501)])
        self.rt.service.executor=None;self.rt.service.explicit_local=True;self.rt.service.state='offline'
        self.rt.service.start=lambda:(_ for _ in ()).throw(AssertionError('zero processable director must not start service'))
        self.manager.authorize_workspace(self.user,'fixture-store',self.refresh,lambda ident:self.refresh)
        self.rt._analysis_queue_controller=self.manager
        self.assertTrue(self.manager.wait_workspace_idle(3))
        self.assertIsNone(self.rt.service.executor);self.assertEqual(self.calls,[])
        return old,page

    def test_cold_empty_snapshot_preserves_decoupled_capability_and_readiness_guard(self):
        old,page=self.cold_empty()
        self.rt._collection_readiness=lambda *args:('device_not_ready','fixture cold device')
        with base.patch.object(self.core.store,'put',side_effect=AssertionError('snapshot must not write')):
            value=self.snapshot()
        self.assertIs(value.get('analysisDecoupled'),True,'trusted automatic workspace is independent of executor warm-up')
        self.assertEqual(value.get('analysisBufferMode'),'durable_background');self.assertIsNone(value.get('analysisBufferLimit'))
        self.assertFalse(value['canStart'],'actual platform readiness must still block')
        self.assertFalse(value['canResume']);self.assertEqual(value['reasonCode'],'device_not_ready')
        self.assertEqual(self.core.store.get(runtime._COLLECTION_ANALYSIS_ENTITY,self.task['id']),page)
        self.assertEqual(self.core.store.get('ai_attempts',old['id']),old);self.assertEqual(self.calls,[])

    def test_present_executor_still_requires_exact_core_and_employee(self):
        self.cold_empty()
        self.assertIs(self.rt._automatic_collection_analysis(self.user,self.task),self.manager)
        for executor in (SimpleNamespace(core=object(),tenant=self.user['tenant_id'],owner=self.user['username'],user_id=self.user['id']),
                SimpleNamespace(core=self.core,tenant=self.user['tenant_id'],owner='other-owner',user_id=self.user['id']),
                SimpleNamespace(core=self.core,tenant=self.user['tenant_id'],owner=self.user['username'],user_id='other-id')):
            with self.subTest(executor=executor):
                self.rt.service.executor=executor
                self.assertIsNone(self.rt._automatic_collection_analysis(self.user,self.task))
        self.rt.service.executor=self.executor
        self.assertIs(self.rt._automatic_collection_analysis(self.user,self.task),self.manager)

if __name__=='__main__':
    names=[name for name in ColdCapability.__dict__ if name.startswith('test_')]
    stream=io.StringIO();pin=hashlib.sha256(bp.RUNTIME.read_bytes()).hexdigest()
    with base.patch.object(socket.socket,'connect',base.deny),base.patch('subprocess.Popen',side_effect=base.deny):
        result=unittest.TextTestRunner(stream=stream,verbosity=2).run(unittest.TestSuite(ColdCapability(name) for name in names))
    passed=result.wasSuccessful() and pin==hashlib.sha256(bp.RUNTIME.read_bytes()).hexdigest()
    tag='COLD-GREEN' if passed else 'COLD-RED';(OUT/(tag+'.log')).write_text(stream.getvalue(),'utf-8')
    report={'passed':passed,'tests':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),
        'runtimeSha256':pin,'realCloudModelCliOrSendingCalls':0,'productionReads':0,'productionWrites':0,
        'scope':'Actual F104 director zero-processable path -> service remains None -> actual Runtime snapshot; frontend existingOnly prepare unchanged, no permanent-lock claim.'}
    (OUT/(tag+'.json')).write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n','utf-8')
    print(stream.getvalue());print(json.dumps(report,ensure_ascii=False));raise SystemExit(0 if passed else 1)
