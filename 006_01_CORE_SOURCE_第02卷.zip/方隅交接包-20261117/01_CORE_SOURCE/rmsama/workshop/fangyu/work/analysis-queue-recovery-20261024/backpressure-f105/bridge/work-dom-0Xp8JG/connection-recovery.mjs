// Explicit recovery checks the current receipt and existing binding; it never
// starts collection, submits model work, sends messages or enrolls a device.
export function createConnectionRecovery({state,scope,runtimeStatus,refresh,prepare,hasUnconfirmed,verifyPending,render}){
  let flight=null;
  return function recoverConnection(){
    if(flight)return flight;
    if(state.busy||state.connection!=='connected'||!state.session)return Promise.resolve(null);
    const actor=scope(),owner=Symbol('connection-recovery');
    const current=()=>scope()===actor;
    state.connectionRecoveryOwner=owner;state.connectionRecovering=true;state.connectionRecoveryMessage='';render();
    flight=(async()=>{
      try{
        await runtimeStatus();if(!current())return null;
        if(hasUnconfirmed()){
          await verifyPending();
          if(current())state.connectionRecoveryMessage=hasUnconfirmed()?'上次操作仍待核对，已保留任务；请点击核对采集状态，不会重复开始。':'原操作状态已核对，请查看当前任务再继续。';
          return null;
        }
        let platform=await refresh({manual:true});if(!current())return null;
        if(!platform){state.connectionRecoveryMessage='软件窗口已响应，但工作状态暂未返回。请稍后再次检查；原任务与已采集数据会保留。';return null;}
        if(platform.actor?.username!==state.user||platform.actor.storeId!==state.storeId)return null;
        const active=['running','queued','starting','pausing','resuming','analyzing','stopping'].includes(platform.acquisition?.status);
        if(!active&&!hasUnconfirmed()&&platform.device?.bound===true&&['offline','stopped','error'].includes(platform.device.state)){
          const result=await prepare({existingOnly:true});if(!current())return null;
          platform=result?.platform||await refresh({manual:true});if(!current())return null;
        }
        if(!platform){state.connectionRecoveryMessage='连接尚未取得确认，请稍后再次检查。';return null;}
        const acquisition=platform.acquisition||{};
        state.connectionRecoveryMessage=platform.device?.state!=='online'
          ?platform.device?.message||'工作连接尚未确认，请到账号页查看处理提示。'
          :['verification_required','authentication_required'].includes(acquisition.platformError?.category)
            ?'连接正常，原平台账号需要本人验证。请点击下方的原账号验证入口。'
            :active?'连接正常，原任务仍在处理；请查看采集进度，无需重复开始。'
              :acquisition.reasonCode==='account_not_ready'?'工作连接已恢复，请点击连接本店账号，完成平台登录。'
                :acquisition.canStart===true?'连接已恢复，可以点击开始获客。':'连接已核对，请按当前任务提示继续处理。';
        return platform;
      }catch(error){
        if(current()){state.platformError=error.message||'暂时无法连接工作台。';state.platformErrorCode=error.code||'connection_failed';state.connectionRecoveryMessage='连接检查未完成，请稍后重试；原任务与数据均保留。';}
        return null;
      }finally{
        if(state.connectionRecoveryOwner===owner){state.connectionRecovering=false;state.connectionRecoveryOwner=null;}
        flight=null;render();
      }
    })();
    return flight;
  };
}
