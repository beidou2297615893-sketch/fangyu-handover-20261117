// Fill the window with a fluid design viewport; text keeps a uniform scale.
import {DESIGN_VIEWPORTS,viewportMetrics} from './viewport-layout.mjs';
const sizes=DESIGN_VIEWPORTS;
const frame=document.getElementById('workspace-frame');
const route=value=>Object.hasOwn(sizes,value)?value:'login';
let page=route(location.hash.slice(1)),layoutWidth=0,layoutHeight=0;
function fit(){
  if(!innerWidth||!innerHeight)return;
  const metrics=viewportMetrics(innerWidth,innerHeight,page);
  const {scale}=metrics;layoutWidth=metrics.width;layoutHeight=metrics.height;
  frame.style.width=layoutWidth+'px';frame.style.height=layoutHeight+'px';
  frame.style.transform=`scale(${scale})`;
  document.body.dataset.page=page;document.body.dataset.scale=String(scale);
  frame.contentWindow?.postMessage({type:'fangyu-canvas-viewport',layoutY:metrics.layoutY},location.origin);
}
function reset(){fit();}
window.addEventListener('resize',reset);
window.visualViewport?.addEventListener('resize',reset);
frame.addEventListener('load',fit);
window.addEventListener('message',event=>{
  if(event.source!==frame.contentWindow||event.origin!==location.origin)return;
  const m=event.data;
  if(!Object.hasOwn(sizes,m?.page))return;
  if(m.type==='fangyu-canvas-change'){
    page=m.page;reset();
    if(location.hash!=='#'+page)history.replaceState(null,'','#'+page);
    return;
  }
  if(m.type!=='fangyu-canvas-size'||m.page!==page)return;
  if(Math.abs(m.viewportWidth-layoutWidth)>1||Math.abs(m.viewportHeight-layoutHeight)>1)return;
  frame.dataset.contentOverflow=String(Number.isFinite(m.contentHeight)&&m.contentHeight>layoutHeight+1);
  frame.dataset.ready='true';
});
window.addEventListener('hashchange',()=>{
  const next=route(location.hash.slice(1));if(next===page)return;
  page=next;reset();frame.contentWindow.location.hash=page;
});
fit();frame.src='/canvas.html#'+page;
