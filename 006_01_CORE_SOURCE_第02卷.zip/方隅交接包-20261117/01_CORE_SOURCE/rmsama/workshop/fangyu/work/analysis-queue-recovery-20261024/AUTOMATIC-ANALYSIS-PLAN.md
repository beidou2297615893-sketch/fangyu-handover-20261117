# 工作台自动分析队列 Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development or superpowers:executing-plans to implement task-by-task. 用户已授权本项目并行执行，按现有隔离候选+Root集成进行。

**Goal:** 登录后零点击持续处理本员工当前门店的所有可分析评论，分析独立于采集与页面。

**Architecture:** 在F103受控Controller上增加门店协调器，可信Backend登录/门店hook登记RAM授权并唤醒后台；复用现有AI工作流、单worker gate及错误分类。状态读取、页面缓存保持本地；实际模型提交前后fresh核权。

**Tech Stack:** 现有Python、SQLite、原生Host与JavaScript模块；不增加重型依赖、全局AIWorker或本地模型。

**Spec:** [AUTOMATIC-ANALYSIS-DESIGN.md](AUTOMATIC-ANALYSIS-DESIGN.md)

## Global Constraints

- 原2068评论、1794原AI、3账号、任务、草稿、手工判断、旧请求及账本保留。
- 只分析当前员工+当前授权门店；不自动采集/评论/私信/发布。
- 本机后台工作不是关机后的云端24小时服务；重开后自动恢复正常队列。
- 每批同帖≤20；unknown按原lead隔离，缺正文不伪造；真正权限/预算/新调用不确定不得自动重放。
- 当前F103运行不由Agent关闭/操作；源、隔离、冻结、安装和真人回执分开。

## Review Focus

1. 首次进入回复页而没有进入获客页：自动244处理仍必须启动。
2. worker内部fresh重进身份hook：不能建第二director或重复模型。
3. 队列刚空后新页或导入到达：仍能唤醒，完成不等于永久停止。
4. 登录和换店提交顺序：不能授权旧店后关闭并漏掉新店。
5. 300秒RAM快照到期、真实断网/预算/未知与用户暂停：准确区别，避免需要按钮才能恢复普通等待，避免盲重试。

---

### Task 1: 门店自动协调器（核心Agent）

**Files:** 隔离候选中的`work/shared-backend-integration/analysis_queue_runtime.py`及专属自动队列测试；F103不改。

**Interfaces:** 消费现有Runtime/Core及可信刷新函数；提供`authorize_workspace(user,store,refreshWorkspace,refreshTaskFactory)`、工作区读/暂停/恢复和现有task消费者兼容。模型只用原工作流，不直接接供应商新密钥。

- [ ] 红例：7同门店任务1794旧结果+244新正文+9held+21缺正文，登录授权后零手动resume必须自动清空244。
- [ ] 实现SQL候选taskIds/流式计数、串行task消费、无工作事件等待、新页/导入唤醒、跨任务与重开恢复。
- [ ] 验证原AI/人工结果/账本/旧请求不变，采集暂停不停止、真正权限预算新未知停、重复授权单director。
- [ ] 封定候选及精确基线/候选SHA、测试日志；独立Agent审查。

### Task 2: 真实登录与页面接线（Bridge Agent）

**Files:** 隔离候选`work/ui-native-r57/workbench_backend.py`、必要Host动作登记、`ui-preview/app.mjs/backend.mjs/pages/saved-comment-analysis.mjs/pages/acquire.mjs`。

**Interfaces:** 按双方锁定的工作区协议将本机会话/门店可信授权交给协调器；返回兼容`analysisQueue`的门店整体状态，正常无需taskId或确认弹窗。

- [ ] 红例：真实bootstrap初始回复页→自动处理，真实login/换店提交后授权正确，fresh身份重入无重复线程。
- [ ] 接线只登记RAM+signal，后续模型不占Host/Backend/Core请求锁；普通read/poll零云。
- [ ] 展示门店整体待分析244、held9、缺正文21、已有1794；200只解释采集缓冲，后台分析仍继续。
- [ ] 验证暂停/恢复、同scope重绘、切客户、登出/换店、过期/断网与真实错误可见，原手动回复链保持；封定并交叉审查。

### Task 3: Root集成、数据保全和实际运行

**Files:** 专属`work/analysis-queue-recovery-20261024`计划、冻结验收、CAS安装、只读观察和交接。

- [x] 只读真数据核准244/9/21及7任务owner/store/城市/账号/标题均有效。
- [ ] 合并唯一有来源的候选，检查PUBLIC与F103基线完全一致；新冻结版本不覆盖F103。
- [ ] 运行实际冻结零按钮bootstrap/后台组合链、核心自动队列、必要原回复缓存回归、native检查及自测；独审全包和安装器。
- [ ] CAS只更新原入口及描述，正式数据保全后由本人正常重开；不再要求点分析。
- [ ] 观察实际版本、自动控制记录、请求与新结果增长，保留1794原AI；持续到244可分析清空或准确记录需本人/服务恢复的阻碍，不伪报完成。
- [ ] 更新STATE/主交接；全三合一目标仍未整体完成，其他开发与tone不抢本轮。

Self-review：上述五项Review Focus均归入Task1/2；业务scope与真实计数一致。工作树/额外设计确认未使用，遵从本人既有自行设计并行执行偏好。
