"""Verify canonical entry and preservation; leave current native process alone."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess,sys,urllib.request

sys.dont_write_bytecode=True
sys.stdout.reconfigure(encoding='utf-8')
W=Path(__file__).resolve().parent
P=W.parents[1]
N=P/'work/ui-native-r57'
read=lambda p:json.loads(p.read_text('utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
pins=read(W/'package/ROOT-FINAL-PINS-V104.json')
installed=read(N/'FROZEN.json')
journal=read(W/'package/entry-v104/CANONICAL-DELEGATION-INSTALL.json')
assert journal['status']=='INSTALLED_AWAITING_ACTUAL_ORIGINAL_ENTRY_VERIFICATION'
assert installed['release_id']==pins['releaseId']
assert sha(N/'run_workbench.py')==installed['launcher_sha256'].lower()
assert installed['full_closure_manifest_sha256']==pins['unifiedPinsSha256']
PY=P/'work/desktop-python/Scripts/python.exe'
result=subprocess.run([str(PY),'-X','utf8','-I','-B',str(N/'run_workbench.py'),'--check'],capture_output=True,text=True,encoding='utf-8',timeout=300)
(W/'package/CANONICAL-CHECK-F104.log').write_text(result.stdout+'\n'+result.stderr,'utf-8')
assert result.returncode==0
check=json.loads(result.stdout)
assert check['status']=='PASS' and check['release_id']==pins['releaseId']
assert check['native_windows_opened']==0 and check['business_app_imported'] is False
result=subprocess.run([str(PY),'-X','utf8','-B',str(W/'formal_preservation_f104.py'),'after'],capture_output=True,text=True,encoding='utf-8',timeout=30)
assert result.returncode==0,result.stderr
formal=read(W/'FORMAL-AFTER-F104.json')
assert formal['protectedRecordsUnchanged'] is True
actual={'running':False}
active=N/'state/active.json'
if active.exists():
    a=read(active);port=a.get('stablePort')
    if a.get('profile')=='production' and type(port) is int and 0<port<65536:
        try:
            with urllib.request.urlopen('http://127.0.0.1:'+str(port)+'/__workbench_status',timeout=3) as response:public=json.load(response)
            if public.get('instanceId')==a.get('instanceId') and public.get('profile')=='production':
                actual={'running':True,'releaseId':public.get('release'),'matchesInstalled':public.get('release')==pins['releaseId'],'pid':a.get('pid')}
        except Exception as error:actual={'running':False,'errorType':type(error).__name__}
report={'status':'PASS_NEXT_OPEN_INSTALLED_DATA_PRESERVED','atUtc':datetime.now(timezone.utc).isoformat(),
    'installedReleaseId':pins['releaseId'],'canonicalLauncherSha256':sha(N/'run_workbench.py'),
    'canonicalFrozenSha256':sha(N/'FROZEN.json'),'canonicalCheck':check,
    'protectedRecordsUnchanged':True,'businessCounts':{k:v['count'] for k,v in formal['data'].items()},
    'actualRuntime':actual,'currentWindowRestarted':False,'productionWrites':0,
    'actualCloudModelOrPlatformCalls':0,'actualNewNativeAnalysisVerified':False}
(W/'INSTALLED-VERIFICATION-F104.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n','utf-8')
print(json.dumps({k:v for k,v in report.items() if k!='canonicalCheck'},ensure_ascii=False),flush=True)
