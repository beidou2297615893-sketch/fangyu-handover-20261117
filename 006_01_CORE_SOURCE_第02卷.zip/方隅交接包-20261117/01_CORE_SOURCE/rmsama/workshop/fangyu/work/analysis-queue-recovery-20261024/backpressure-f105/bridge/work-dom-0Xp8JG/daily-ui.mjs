const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
export function localDay(date=new Date()){
  const p=Object.fromEntries(new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Shanghai',year:'numeric',month:'2-digit',day:'2-digit'}).formatToParts(date).map(x=>[x.type,x.value]));return `${p.year}-${p.month}-${p.day}`;
}
export function calendarControl(kind,value,label='选择日期'){
  const date=/^\d{4}-\d{2}-\d{2}$/.test(value||'')?value:'',caption=date?`${Number(date.slice(5,7))}月${Number(date.slice(8,10))}日`:'全部日期';
  return `<span class="wb-calendar"><button type="button" data-calendar-open="${kind}" aria-label="${esc(label)}" title="${esc(label)}"><img src="/assets/tabler-upgrade-calendar.svg" alt=""><span>${caption}</span></button><input class="wb-calendar-native" type="date" data-calendar-input="${kind}" data-${kind==='acquire'?'acquire-day':'customer-day'} value="${date}" aria-label="${esc(label)}" tabindex="-1"></span>`;
}
export function bindCalendars(root){
  root.querySelectorAll('[data-calendar-open]').forEach(button=>button.addEventListener('click',()=>{
    const input=button.parentElement.querySelector('[data-calendar-input]');if(!input)return;try{if(input.showPicker)input.showPicker();else{input.focus();input.click();}}catch{input.focus();input.click();}
  }));
}
export async function collectCustomerIds({query,read,valid=()=>true,onProgress=()=>{},limit=3000}){
  const ids=new Set();let total=null,pages=1;
  for(let page=1;page<=pages;page++){
    if(!valid())throw Error('客户范围已变化，请重新全选。');
    const value=await read({...query,page,pageSize:50});
    if(!valid())throw Error('客户范围已变化，请重新全选。');
    if(!Number.isSafeInteger(value?.total)||value.total<0||!Array.isArray(value.items))throw Error('客户范围尚未确认，请重新读取。');
    if(value.total>limit)throw Error(`当前筛选超过${limit}位，请缩小范围后全选。`);
    if(total!==null&&total!==value.total)throw Error('客户清单已变化，请重新全选。');
    total=value.total;pages=Math.max(1,Math.ceil(total/50));
    for(const row of value.items){if(typeof row.id!=='string'||!row.id||ids.has(row.id))throw Error('客户清单已变化，请重新全选。');ids.add(row.id);}
    onProgress(ids.size,total);
  }
  if(ids.size!==total)throw Error('客户清单已变化，请重新全选。');return [...ids];
}

export function readablePostTime(value){
  if(typeof value!=='string'||!/^\d{4}-\d{2}-\d{2}(?:[T ]\d{2}:\d{2}(?::\d{2}(?:\.\d+)?)?(?:Z|[+-]\d{2}:?\d{2})?)?$/.test(value))return '原评论时间未提供';
  if(value.length===10)return value;
  if(/(?:Z|[+-]\d{2}:?\d{2})$/.test(value)){
    const date=new Date(value);if(!Number.isFinite(date.getTime()))return '原评论时间未提供';
    const parts=Object.fromEntries(new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Shanghai',year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',hourCycle:'h23'}).formatToParts(date).map(p=>[p.type,p.value]));
    return `${parts.year}-${parts.month}-${parts.day} ${parts.hour}:${parts.minute}`;
  }
  return value.slice(0,16).replace('T',' ');
}
