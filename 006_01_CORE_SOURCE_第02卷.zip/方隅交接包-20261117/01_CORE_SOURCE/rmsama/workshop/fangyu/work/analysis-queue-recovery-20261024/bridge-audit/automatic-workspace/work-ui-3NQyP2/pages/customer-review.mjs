// Independent, read-only Codex reference. Original AI/manual judgments remain intact.
const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
export const reviewMode=value=>['priority','reviewed'].includes(value)?value:'all';
const amount=value=>Number.isSafeInteger(value)&&value>=0?value:'—';
export function selectCustomerReview(controls,value){
  Object.assign(controls,{review:reviewMode(value),query:'',filter:'all',intent:'all',acquiredDate:'',leaseGroup:'all',page:1,checkedIds:[],selectedId:'',filterOpen:false,evidenceOpen:false});
}
export function renderReviewFilters(summary,selected='all',mode='customer',locked=false){
  selected=reviewMode(selected);
  if(!summary?.available&&!summary?.priorityScreenAvailable&&!summary?.notice&&selected==='all')return '';
  const data=mode==='reply'?'live-review-filter':'customer-review';
  const cumulative=summary?.supplementalReviewed>0;
  return `<div class="cr-filter-strip"><div class="cr-filters" role="group" aria-label="${summary?.priorityScreenAvailable?'优先筛选与独立复核客户':cumulative?'Codex复核客户':'本次 Codex 复核客户'}">${[['priority',`优先跟进 · ${amount(summary?.priority)}`],['reviewed',`${cumulative?'已复核':'本次复核'} · ${amount(summary?.reviewed)}`],['all','全部客户']].map(([key,label])=>`<button type="button" data-${data}="${key}" aria-pressed="${selected===key}" class="${selected===key?'is-active':''}" ${locked||key==='reviewed'&&!summary?.available||key==='priority'&&!summary?.available&&!summary?.priorityScreenAvailable?'disabled':''}>${label}</button>`).join('')}</div>${summary?.priorityScreenAvailable?`<p class="cr-notice">优先名单合并去重 · Codex复核 ${amount(summary.codexPriority)} 位 · 自动筛选 ${amount(summary.automaticPriority)} 位，需求待确认。</p>`:''}${summary?.notice?`<p class="cr-notice" role="status">${esc(summary.notice)}</p>`:''}${summary?.stale>0?`<p class="cr-notice">${amount(summary.stale)} 位的复核原文已变化，暂不列入本次结果。</p>`:''}</div>`;
}
export function currentCodexReview(person){
  const r=person?.codexReview;
  return r?.provider==='Codex'&&r.humanConfirmed===false&&r.needsConfirmation===true&&typeof r.evidenceLeadId==='string'&&r.evidenceLeadId?r:null;
}
export function currentPriorityScreen(person){
  const r=person?.priorityScreen;
  return r?.source==='local_rule_screen'&&r.modelReview===false&&r.humanConfirmed===false&&r.needsConfirmation===true&&typeof r.priority==='boolean'&&['priority','confirmation','excluded','ended','unsupported'].includes(r.status)&&typeof r.ruleVersion==='string'&&typeof r.reason==='string'?r:null;
}
export function reviewBadge(person){
  const r=currentCodexReview(person),s=currentPriorityScreen(person);
  const original=r?`<small class="cr-row-badge ${r.priority&&person.priorityFollowup!==false?'is-priority':''}">${r.priority?(person.priorityFollowup===false?'Codex复核 · 原优先记录':'Codex复核 · 优先跟进'):esc(r.followUpGroup||'本次已复核')}</small>`:'';
  return original+(s?.priority&&s.status==='priority'?'<small class="cr-row-badge is-priority">自动筛选 · 待确认</small>':'');
}
function renderPriorityCard(person){
  const r=currentPriorityScreen(person);
  if(!r||!['priority','confirmation'].includes(r.status))return '';
  const priority=r.priority&&r.status==='priority';
  const unknown=Array.isArray(r.unknown)?r.unknown.filter(x=>typeof x==='string').slice(0,12):[];
  const evidence=r.evidence&&typeof r.evidence==='object'?r.evidence:{};
  if(!priority)return `<details class="cr-screen-note"><summary>优先筛选：信息待补充</summary><p>${esc(r.reason)}</p>${unknown.length?`<p>需确认：${unknown.map(esc).join('；')}</p>`:''}<small>本地规则初筛 · 原分析保留 · 需本人核实</small></details>`;
  return `<section class="cr-card cr-auto-card" aria-label="持续优先筛选"><div class="cr-heading"><strong>${priority?'优先跟进':'优先筛选：待补充'}</strong><span>自动筛选 · 待确认</span></div><p class="cr-caption">本地规则持续筛选${r.leaseGroup?' · '+esc(r.leaseGroup):''} · 原分析保留</p><p class="cr-reason">${esc(r.reason)}</p><details><summary>筛选依据</summary>${typeof evidence.quote==='string'&&evidence.quote?`<blockquote>${esc(evidence.quote)}</blockquote>`:''}${unknown.length?`<p class="cr-meta"><strong>需确认：</strong>${unknown.map(esc).join('；')}</p>`:''}<p class="cr-meta">这是本地规则初筛，未经在线模型复核或本人确认。请结合原评论核实需求。</p></details></section>`;
}
export function renderReviewCard(person,options={}){return renderPriorityCard(person)+renderCodexReviewCard(person,options);}

function renderCodexReviewCard(person,{mode='customer',leadId='',locked=false,canSave=false}={}){
  const r=currentCodexReview(person);if(!r)return '';
  if(r.demandState)return renderHistoricalReview(r,{mode,leadId,locked});
  const onEvidence=leadId===r.evidenceLeadId;
  return `<section class="cr-card" aria-label="Codex 独立复核"><div class="cr-heading"><strong>Codex 独立复核</strong><span>${esc(r.followUpGroup||'本次已复核')}</span></div><p class="cr-caption">复核参考 · 当前需求待本人确认</p><p class="cr-reason">${esc(r.reason||'请结合原评论核对当前需求。')}</p><details><summary>原文与回复参考</summary><p class="cr-meta">评论当时：${esc(r.intentLabel||'待确认')}${r.leaseGroup?' · 租期 '+esc(r.leaseGroup):''}</p><blockquote>${esc(r.evidenceQuote||'请定位原评论查看完整内容。')}</blockquote><button type="button" class="cr-evidence" data-codex-evidence ${locked?'disabled':''}>${mode==='reply'?(onEvidence?'已定位复核原评论':'定位复核原评论'):'定位原评论并回复'}</button>${Array.isArray(r.unknown)&&r.unknown.length?`<p class="cr-meta"><strong>先确认：</strong>${r.unknown.filter(x=>typeof x==='string').map(esc).join('；')}</p>`:''}${r.suggestedReply?`<p class="cr-suggested">${esc(r.suggestedReply)}</p><div class="cr-actions"><button type="button" data-codex-copy ${locked?'disabled':''}>复制回复参考</button>${mode==='reply'?`<button type="button" data-codex-use ${locked||!canSave||!onEvidence?'disabled':''}>填入空草稿</button>`:''}</div>${mode==='reply'&&!onEvidence?'<p class="cr-caption">请先定位复核原评论，再填写回复。</p>':''}`:''}</details></section>`;
}
function renderHistoricalReview(r,{mode,leadId,locked}){
  const nonText=r.evidenceKind==='non_text';
  const captions={ended:'当时需求已结束',historical:'历史评论，当前需求未核实',unknown:'当时信息不足，无法判断当前需求',unrelated:'历史评论未见本人求租证据'};
  const caption=nonText?'原评论无可识别文字，无法判断':captions[r.demandState]||'历史评论，当前需求未核实';
  const stamp=typeof r.reviewedAt==='string'?r.reviewedAt.replace('T',' ').replace(/\.\d+(?=Z|\+00:00)/,'').replace(/Z|\+00:00/,' UTC'):'';
  return `<section class="cr-card" aria-label="Codex 独立复核"><div class="cr-heading"><strong>Codex 独立复核</strong><span>${esc(r.followUpGroup||'已复核')}</span></div><p class="cr-caption">${esc(caption)}</p><p class="cr-reason">${esc(r.reason)}</p>${stamp?`<p class="cr-meta">补充历史复核 · ${esc(stamp)}</p>`:''}<details><summary>${nonText?'原评论记录':'复核所据原文'}</summary><p class="cr-meta">评论当时：${esc(r.intentLabel)}${r.leaseGroup?' · 租期 '+esc(r.leaseGroup):''}</p>${nonText?'<p class="cr-meta">无可引用的文字原话。</p>':`<blockquote>${esc(r.evidenceQuote)}</blockquote>`}<button type="button" class="cr-evidence" data-codex-evidence ${locked?'disabled':''}>${mode==='reply'&&leadId===r.evidenceLeadId?'已定位复核原评论':'定位原评论'}</button>${Array.isArray(r.unknown)&&r.unknown.length?`<p class="cr-meta"><strong>信息缺口：</strong>${r.unknown.filter(x=>typeof x==='string').map(esc).join('；')}</p>`:''}</details></section>`;
}
export function useReviewSuggestion(v){
  const r=currentCodexReview(v.detail?.item),row=v.detail?.comments?.find(c=>c.id===v.leadId);
  if(v.busy||v.pending||v.batchBusy||v.batchPending)return {ok:false,message:'请先核对当前操作结果。'};
  if(!r||v.detail.item.id!==v.selectedId||r.evidenceLeadId!==v.leadId||!row?.canSave)return {ok:false,message:'请先定位这次复核的原评论，并核对回复条件。'};
  if(v.dirty||String(v.text||'').trim())return {ok:false,message:'已保留现有草稿。可复制回复参考后自行合并。'};
  const text=typeof r.suggestedReply==='string'?r.suggestedReply.trim():'';
  if(!text||text.length>1000)return {ok:false,message:'回复参考暂不可用，请自行填写。'};
  v.text=text;v.dirty=v.text!==(row.draft?.text||'');
  return {ok:true,message:'已填入回复参考；尚未保存或发送，请核实后编辑。'};
}
export async function copyReviewSuggestion(person,ctx,owns=()=>true){
  if(!owns())return;
  const text=currentCodexReview(person)?.suggestedReply;
  if(!text)return;
  try{await navigator.clipboard.writeText(text);if(owns())ctx.toast('已复制回复参考；请核实后自行发送。');}
  catch{if(owns())ctx.modal({title:'回复参考',html:`<textarea readonly aria-label="可手动复制的回复参考" style="width:100%;min-height:160px">${esc(text)}</textarea>`,confirmLabel:'知道了'});}
}
