import assert from 'node:assert/strict';
import fs from 'node:fs';import path from 'node:path';import {pathToFileURL} from 'node:url';
const root=path.resolve(import.meta.dirname,'..'),source=root+'/candidate/work/ui-approved-implementation/ui-preview';
const original='C:/积木软件工坊/项目/方隅公寓客户版/work/parallel-integration-20261018/final-integration/candidate-unified-v103/project/work/ui-approved-implementation/ui-preview';
const fixture=fs.mkdtempSync(path.join(root,'work-transport-'));
fs.copyFileSync(source+'/backend.mjs',fixture+'/backend.mjs');fs.copyFileSync(original+'/customer-read-cache.mjs',fixture+'/customer-read-cache.mjs');
const {createBackend}=await import(pathToFileURL(fixture+'/backend.mjs'));
let calls=[],fail=false;
const backend=createBackend(async(url,options)=>{calls.push({url,options});if(fail)throw Error('synthetic network failure');return {ok:true,status:200,json:async()=>({ok:true,csrfToken:'fixture-csrf',analysisQueue:{taskId:'workspace'}})};},{timeoutMs:1000});
await backend.bootstrap();
for(const action of ['analysis_workspace_read','analysis_workspace_pause','analysis_workspace_resume']){
 await backend.analysisQueueAction(action,{storeId:'store1'});const {options}=calls.at(-1);
 assert.equal(options.method,'POST');assert.equal(options.headers['X-Fangyu-CSRF'],'fixture-csrf');assert.deepEqual(JSON.parse(options.body),{action,data:{storeId:'store1'}});
}
fail=true;await assert.rejects(backend.analysisQueueAction('analysis_workspace_resume',{storeId:'store1'}),e=>e.code==='ANALYSIS_QUEUE_RESULT_UNCONFIRMED');
assert.equal(backend.unconfirmed,false,'automatic analysis must not overwrite manual reply uncertainty');
console.log(JSON.stringify({passed:true,cases:4}));
