import {installationStores} from './installation-stores.mjs';
const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function model(state){state.installationDemo??={storeId:installationStores.some(s=>s.id===state.storeId)?state.storeId:installationStores[0]?.id,step:'choose',platform:'xiaohongshu',running:false};return state.installationDemo;}
export function render(state){
  const v=model(state),store=installationStores.find(s=>s.id===v.storeId)||installationStores[0];
  if(!store)return '<p>门店展示资料暂不可用。</p>';
  const words=`<details class="install-words"><summary>查看本店 ${store.words.length} 个搜索词</summary><div>${store.words.map(w=>`<span>${esc(w)}</span>`).join('')}</div></details>`;
  if(v.step==='choose')return `<section class="install-demo"><div class="install-demo-intro"><img src="/assets/fy-approved-header-apartment.png" alt="方隅公寓的明亮客厅"><div><span class="install-demo-label">安装流程预演</span><h2>这台电脑，用于哪家门店？</h2><p>安装时选好门店，打开后就使用本店关键词。<br>员工登录自己的平台账号，即可开始工作。</p></div></div><div class="install-demo-form"><label for="installation-store">选择安装门店</label><select id="installation-store" data-install-store>${installationStores.map(s=>`<option value="${esc(s.id)}" ${s.id===store.id?'selected':''}>${esc(s.name)}</option>`).join('')}</select><div class="install-store-summary"><strong>${esc(store.name)}</strong><span>已准备 ${store.words.length} 个本店搜索词</span><p>${store.words.slice(0,5).map(esc).join('、')}</p></div>${words}<div class="install-demo-footer"><p>此页预演界面流程，不写入正式安装器或真实门店配置。</p><button type="button" class="primary" data-install-continue>完成选店，预览工作台</button></div></div></section>`;
  const platform=v.platform==='douyin'?'抖音':'小红书';
  return `<section class="install-workbench"><div class="install-preview-bar"><span class="install-demo-label">工作台界面预演</span><button type="button" class="text-button" data-install-back>返回安装选店</button></div><h2>获客截流</h2><p class="install-workbench-subtitle">发现真实租房需求</p><div class="install-demo-stats"><div><span>新增客户</span><strong>0</strong></div><div><span>高意向</span><strong>—</strong></div><div><span>已回复</span><strong>—</strong></div></div><section class="install-fixed-store"><div><span>安装门店</span><strong>${esc(store.name)}</strong><small>默认使用本店 ${store.words.length} 个关键词</small></div><div><span>当前平台</span><strong>${platform}</strong><small>员工登录自己的账号</small></div><button type="button" class="acquire-start" data-install-motion>${v.running?'停止动效预览':'开始获客'}</button></section><div class="install-motion ${v.running?'is-running':''}" role="status"><span class="install-motion-dot"></span><div><strong>${v.running?'获客动效预览中':'准备开始'}</strong><p>界面演示，不发起真实采集，也不生成客户或分析结果。</p></div></div>${words}<div class="install-platforms">${[['xiaohongshu','小红书'],['douyin','抖音']].map(([id,name])=>`<button type="button" data-install-platform="${id}" aria-pressed="${v.platform===id}"><img src="/assets/brand-${id}.svg" alt="">${name}</button>`).join('')}</div></section>`;
}
export function bind(root,ctx){
  const v=model(ctx.state);
  root.querySelector('[data-install-store]')?.addEventListener('change',e=>{if(installationStores.some(s=>s.id===e.target.value))ctx.update(()=>{v.storeId=e.target.value;v.running=false;});});
  root.querySelector('[data-install-continue]')?.addEventListener('click',()=>ctx.update(()=>{v.step='workbench';v.running=false;}));
  root.querySelector('[data-install-back]')?.addEventListener('click',()=>ctx.update(()=>{v.step='choose';v.running=false;}));
  root.querySelector('[data-install-motion]')?.addEventListener('click',()=>ctx.update(()=>{v.running=!v.running;}));
  root.querySelectorAll('[data-install-platform]').forEach(b=>b.addEventListener('click',()=>ctx.update(()=>{v.platform=b.dataset.installPlatform;v.running=false;})));
  return ()=>{};
}
