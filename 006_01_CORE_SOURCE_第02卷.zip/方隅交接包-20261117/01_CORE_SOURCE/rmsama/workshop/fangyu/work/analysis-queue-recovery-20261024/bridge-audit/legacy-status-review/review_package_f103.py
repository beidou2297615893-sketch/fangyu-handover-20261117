from pathlib import Path,PurePosixPath
import ast,datetime,hashlib,json,stat
W=Path(__file__).resolve().parents[2]
P=W.parents[1];PACK=W/'package'
F=P/'work/parallel-integration-20261018/final-integration/candidate-unified-v103'
F102=F.with_name('candidate-unified-v102')
N=P/'work/ui-native-r57'
INSTALLER=W/'install_verified_f103.py'
GEN=P/'work/parallel-integration-20261018/integration/entry/install_canonical_delegation.py'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text('utf-8-sig'))
checks=[]
def check(name,ok):
    assert ok,name
    checks.append({'name':name,'pass':True})
pin_files=[PACK/'ROOT-FINAL-PINS-V103.json',PACK/'ROOT-GATES-V103.json',INSTALLER,GEN,F/'STAGED.json',F/'UNIFIED-PINS.json']
initial={str(p):sha(p) for p in pin_files}
pins=read(pin_files[0]);gates=read(pin_files[1]);stage=read(F/'STAGED.json');closure=read(F/'UNIFIED-PINS.json')
project=F/'project';release=Path(pins['release'])
manifest=read(release/'RELEASE.json')
pin_files.append(release/'RELEASE.json');initial[str(pin_files[-1])]=sha(pin_files[-1])
check('F103-exact-release-gates-and-root-pins',pins['releaseId']==gates['releaseId']==stage['release_id']=='ui-r57-20261024T144455Z-0597e0ca' and gates['status']=='PASS_F103_LEGACY_STATUS_ISOLATION')
check('staged-unified-manifest-digests',sha(F/'STAGED.json')==pins['stagedSha256'] and sha(F/'UNIFIED-PINS.json')==pins['unifiedPinsSha256']=='c02b5a7469cbed8f5fe11847daa6f5b62a94f40e524855c21b95bde83747e5d9' and sha(release/'RELEASE.json')==pins['manifestSha256']==gates['manifestSha256'])
for row in closure['files']:
    rel=PurePosixPath(row['path']);path=project.joinpath(*rel.parts)
    assert not rel.is_absolute() and '..' not in rel.parts and '\\' not in row['path']
    info=path.lstat();assert stat.S_ISREG(info.st_mode) and not path.is_symlink() and not(getattr(info,'st_file_attributes',0)&0x400)
    assert info.st_size==row['bytes'] and sha(path)==row['sha256'],row['path']
check('entire-safe-F103-closure-byte-verified',len(closure['files'])==8686)
old_closure=read(F102/'UNIFIED-PINS.json')
old={r['path']:r['sha256'] for r in old_closure['files']};new={r['path']:r['sha256'] for r in closure['files']}
source_changes=[name for name in sorted(set(old)|set(new)) if '/releases/' not in name and old.get(name)!=new.get(name)]
derived=[name for name in source_changes if '/candidates/' in name or '/run_candidate.' in name]
product=[name for name in source_changes if name not in derived]
check('one-controller-source-plus-exact-version-derived-files',product==['work/shared-backend-integration/analysis_queue_runtime.py'] and len(derived)==4)
for folder in (F102,F):
    s=read(folder/'STAGED.json');candidate=folder/'project/work/ui-native-r57/candidates'/Path('x')
    descriptor=folder/'project/work/ui-native-r57/candidates'/(s['release_id']+'.json')
    check('version-derived-descriptor-'+s['release_id'],read(descriptor)==s and sha(Path(s['launcher']))==s['launcher_sha256'].lower())
old_release=Path(read(PACK/'ROOT-FINAL-PINS-V102.json')['release'])
old_files={p.relative_to(old_release).as_posix():sha(p) for p in old_release.rglob('*') if p.is_file()}
new_files={p.relative_to(release).as_posix():sha(p) for p in release.rglob('*') if p.is_file()}
delta=[name for name in sorted(set(old_files)|set(new_files)) if old_files.get(name)!=new_files.get(name)]
check('actual-release-delta-only-manifest-controller',delta==['RELEASE.json','resources/platform-runtime/analysis_queue_runtime.py'])
for row in manifest['files']:
    check_name=row['path'];assert new_files[check_name]==row['sha256'].lower() and (release/check_name).stat().st_size==row['size']
check('frozen-manifest-complete-and-consistent',set(new_files)=={row['path'] for row in manifest['files']}|{'RELEASE.json'})
expected_controller='a5b828b76acbd8c941d0ee7472a06e7dce652939aec9cefa7241f5bc6945cf9a'
review_path=W/'bridge-audit/LEGACY-STATUS-INDEPENDENT-REVIEW.json';review=read(review_path)
check('sealed-controller-and-independent-review-bind-exact-release',sha(project/product[0])==sha(release/'resources/platform-runtime/analysis_queue_runtime.py')==review['reviewedCandidateSha256']==expected_controller and review['approvedForComposition'] and review['blockingFindings']==[])
check('manual-reply-and-confirmation-UI-preserved',sha(release/'web/pages/reply-connected.mjs')=='92bda4b28c8fe91ae3ae789c137e14a940a16ce68e1ffc2dbeb521267b1476f5' and sha(release/'web/pages/saved-comment-analysis.mjs')=='062ae8206ac212a3812c96bdfad8b775793918ad3b5f11cee819cc53bd8dbeee')
for row in gates['evidence']:assert sha(Path(row['path']))==row['sha256'],row['path']
check('all-direct-F103-gate-evidence-hashes-match',True)
old_gates=read(PACK/'ROOT-GATES-V102.json')
for row in old_gates['evidence']:assert sha(Path(row['path']))==row['sha256'],row['path']
old_review=read(PACK/'FINAL-PACKAGE-REVIEW-V102.json')
check('exact-F102-inherited-gates-and-review-remain-valid',old_review['approvedForRootInstall'] and old_review['blockingFindings']==[] and old_review['rootGatesSha256']==sha(PACK/'ROOT-GATES-V102.json') and old_review['rootPinsSha256']==sha(PACK/'ROOT-FINAL-PINS-V102.json'))
result=read(W/'verification-f103/ROOT-RESULT.json')
for row in result['checks']:assert row['exitCode']==0 and sha(Path(row['path']))==row['sha256']
new_tests=read(W/'verification-f103/legacy/GREEN.json');regression=read(W/'verification-f103/core/CONTROLLER-CHECKS.json')
native=json.loads((W/'verification-f103/native-check.log').read_text('utf-8').strip())
http=json.loads((W/'verification-f103/native-self-test.log').read_text('utf-8').strip())
check('fresh-root-targeted12-regression18-native145-evidence',result['status']=='PASS' and new_tests['passed'] and new_tests['checks']==12 and new_tests['moduleSha256']==expected_controller and regression['status']=='PASS' and regression['tests']==18 and regression['controllerSha256']==expected_controller and native['status']=='PASS' and native['files']==2801 and http['status']=='PASS' and http['checks']==145)
check('old-F102-CAS-targets-still-exact',sha(N/'run_workbench.py')=='3bf47274263c8eb8cb33fcbc994cea946d61495191711b984b61e69166ab7169' and sha(N/'FROZEN.json')=='8f98e52e83e0c0b4e775cc55133a25b27d7e42e269908306e2d41623e39a1987' and read(N/'FROZEN.json')['release_id']=='ui-r57-20261024T142602Z-eec3748c')
binding='14cf53964f5d44d123e989805ea741669ab3f05054e730ddcb299a0aac51a9cb'
check('canonical-and-F103-workspace-bindings-unchanged',sha(N/'state/production-workspace.json')==sha(project/'work/ui-native-r57/state/production-workspace.json')==binding)
check('fixed-generic-entry-transaction-installer',sha(GEN)=='9909f60d16ad3eaed54b9f97ea0d275ad38510c679ba651ce05af44d920ed0f6')
installer=INSTALLER.read_text('utf-8');generic=GEN.read_text('utf-8')
compile(installer,str(INSTALLER),'exec')
for needle in ("assert sys.argv[1:]==['--install']","review['installerSha256']==sha(Path(__file__).resolve())","review['rootPinsSha256']==sha(PACK/'ROOT-FINAL-PINS-V103.json')","review['rootGatesSha256']==sha(PACK/'ROOT-GATES-V103.json')","for row in closure['files']:assert sha(F/'project'/row['path'])==row['sha256']"):
    assert needle in installer,needle
for needle in ("with (backup / path.name).open('xb')",'exact(path, digest(old[path]))','os.replace(temporary, path)',"if digest(path.read_bytes()) in (digest(raw), digest(new[path])):",'assert digest(company.read_bytes()) == company_before'):
    assert needle in generic,needle
check('wrapper-enforces-review-self-hash-CAS-full-closure-and-gates',True)
check('exclusive-backups-per-target-CAS-and-bounded-rollback-preserved',True)
for forbidden in ('subprocess','requests.','sqlite3','task_run','intent_analyze','kill(','terminate('):assert forbidden not in installer and forbidden not in generic,forbidden
check('installer-no-native-restart-business-db-model-or-platform-action',True)
body=Path(stage['launcher']).read_text('utf-8')
needle="RELEASE = ROOT / 'releases/"+stage['release_id']+"'"
assert body.count(needle)==1 and body.count('project_root=ROOT.parent.parent')==1
rewritten=body.replace(needle,"PROJECT_ROOT = ROOT.parent.parent / 'work/parallel-integration-20261018/final-integration/candidate-unified-v103/project'\nRELEASE = PROJECT_ROOT / 'work/ui-native-r57/releases/"+stage['release_id']+"'\nBINDING_SHA256 = '"+binding.upper()+"'")
rewritten=rewritten.replace('project_root=ROOT.parent.parent','project_root=PROJECT_ROOT')
needle="        pinned(RELEASE / 'RELEASE.json', MANIFEST_SHA256)"
assert rewritten.count(needle)==1
rewritten=rewritten.replace(needle,"        pinned(ROOT / 'state/production-workspace.json', BINDING_SHA256)\n        pinned(PROJECT_ROOT / 'work/ui-native-r57/state/production-workspace.json', BINDING_SHA256)\n"+needle)
compile(rewritten,'review-only-launcher-rewrite','exec')
check('exact-version-launcher-rewrite-compiles-with-both-bindings',True)
check('installer-not-executed-and-exclusive-targets-absent',not(PACK/'entry-v103').exists() and not(N/('run_delegated_candidate.'+stage['release_id']+'.py')).exists())
check('all-review-input-pins-stable',all(sha(Path(path))==digest for path,digest in initial.items()))
report={'status':'PASS_INDEPENDENT_F103_PACKAGE_REVIEW','blockingFindings':[],'approvedForRootInstall':True,'reviewedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'releaseId':pins['releaseId'],'unifiedPinsSha256':pins['unifiedPinsSha256'],'manifestSha256':pins['manifestSha256'],
 'rootPinsSha256':sha(PACK/'ROOT-FINAL-PINS-V103.json'),'rootGatesSha256':sha(PACK/'ROOT-GATES-V103.json'),'installerSha256':sha(INSTALLER),
 'checks':checks,'closureFilesVerified':len(closure['files']),'directGateEvidenceFilesVerified':len(gates['evidence']),'reusedF102EvidenceFilesVerified':len(old_gates['evidence']),
 'changedSourceFiles':product,'derivedVersionedEntries':derived,'actualReleaseDelta':delta,'controllerSha256':expected_controller,
 'controllerIndependentReviewSha256':sha(review_path),'sourcePolicyReadbackSha256':sha(W/'bridge-audit/remote-policy-audit/REMOTE-POLICY-FINDINGS.json'),
 'evidenceReuse':'Only RELEASE.json and the independently reviewed controller differ from byte-verified F102. Reply sender, UI confirmation repair, authority/backend, other runtime bytes and their prior fixed gate evidence remain unchanged.',
 'installationReview':'Wrapper binds old F102 launcher/FROZEN and both workspace bindings, complete F103 closure, gate artifacts, this final review and installer self hash. Fixed generic transaction exclusively backs up and CAS-replaces next-open launcher/FROZEN with bounded rollback and company preservation; no live process or business database operation.',
 'currentExecutionLimit':'Actual user F102 run was received but blocked at old ai_attempt_status503, with0 new attempts and candidate186 unchanged. All F103 model/status recovery evidence remains synthetic. Root must install and user must explicitly resume before real attempted/analyzed counts establish recovery.',
 'productionDataWrites':0,'realCloudOrProviderOrCliCalls':0,'nativeWindowsOperated':0,'installerExecuted':False}
output=PACK/'FINAL-PACKAGE-REVIEW-V103.json'
output.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n','utf-8')
print(json.dumps({'approvedForRootInstall':True,'checks':len(checks),'closure':len(closure['files']),'reviewSha256':sha(output),'installerSha256':sha(INSTALLER)}))
